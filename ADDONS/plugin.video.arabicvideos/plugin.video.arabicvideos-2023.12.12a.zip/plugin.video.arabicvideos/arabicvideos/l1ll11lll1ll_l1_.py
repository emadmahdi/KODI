# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ喩")
headers = l1l111_l1_ (u"࠭ࠧ喪")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭喫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭喬"),l1l111_l1_ (u"ࠩส่่๊ࠧ喭"),l1l111_l1_ (u"ࠪหๆ๊วๆࠩ單"),l1l111_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ喯"),l1l111_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ喰")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ喱")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ喲")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll11ll_l1_(l111l1_l1_,l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ喳"),l1l111_l1_ (u"ࠩืห์ีࠠโ๊ิ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤࠡ࠶ࡸࠫ喴"),l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠲ࡳ࡫ࡴࠨ喵"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ営"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ喷"),l1l111_l1_ (u"࠭ࠧ喸"),119,l1l111_l1_ (u"ࠧࠨ喹"),l1l111_l1_ (u"ࠨࠩ喺"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭喻"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喼"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ喽"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喾"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ喿"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ嗀"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嗁"),l1l111_l1_ (u"ࠩࠪ嗂"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗃"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ嗄"),l1l11ll_l1_,111,l1l111_l1_ (u"ࠬ࠭嗅"),l1l111_l1_ (u"࠭ࠧ嗆"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ嗇"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥ࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠩ嗈"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ嗉"),l1l111_l1_ (u"ࠪࠫ嗊"),l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭嗋"),l1l111_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ๏าวะࠢ฼๊ํอๆࠡษ็้ํู่ࠡล๋ࠤฯ฻ๅ๋็ࠣห้๋่ใ฻ࠣฮ฿๐ัࠨ嗌"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ嗍"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗎"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嗏")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ嗐"),filter)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ嗑"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嗒"),l1l111_l1_ (u"ࠬ࠭嗓"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡤࡳࡱࡳࡨࡴࡽ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ嗔"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嗕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ嗖"),l1l111_l1_ (u"ࠩࠪ嗗")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭嗘"),l1l111_l1_ (u"ࠫࠬ嗙")).strip(l1l111_l1_ (u"ࠬࠦࠧ嗚"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ嗛") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ嗜") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ嗝")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗞"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嗟")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬ嗠"),response=l1l111_l1_ (u"ࠬ࠭嗡")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嗢"),url,l1l111_l1_ (u"ࠧࠨ嗣"),headers,l1l111_l1_ (u"ࠨࠩ嗤"),l1l111_l1_ (u"ࠩࠪ嗥"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ嗦"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭嗧"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡭࡬ࡪࡦࡨࡣࡤࡹ࡬ࡪࡦࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嗨"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡩࡱࡺࡷ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠩ࠰࠭ࡃ࠮ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ嗩"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄࠧ嗪"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ嗫"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ嗬"),l1l111_l1_ (u"ࠪห฿์๊สࠩ嗭"),l1l111_l1_ (u"่๊๊ࠫษࠩ嗮"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ嗯"),l1l111_l1_ (u"࠭็ะษไࠫ嗰"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ嗱"),l1l111_l1_ (u"ࠨ฻ิฺࠬ嗲"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ嗳"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ嗴")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ嗵") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠬ࠵ࠧ嗶"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ嗷"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ嗸"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠨใํ่๊࠭嗹") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嗺"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪห้ำไใหࠪ嗻") in title and l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ嗼") not in url:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ嗽") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嗾"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸ࠯ࠨ嗿") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嘀"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ嘁") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ嘂") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ嘃")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嘄"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ嘅") in url and l1l111_l1_ (u"ࠧฮๆๅอࠬ嘆") in title:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嘇"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘈"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ嘉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ嘊"): items = re.findall(l1l111_l1_ (u"ࠬ࠮ࡵࡱࡦࡤࡸࡪࡗࡵࡦࡴࡼ࠭࠳࠰࠿࠿ࠪ࠱࠯ࡄ࠯࠼ࠨ嘋"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"࠭࠼࡭࡫ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嘌"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ嘍"):
				title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ嘎"),l1l111_l1_ (u"ࠩࠪ嘏")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭嘐"),l1l111_l1_ (u"ࠫࠬ嘑"))
				if l1l111_l1_ (u"ࠬࡅࠧ嘒") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭嘓")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠧࡀࡲࡤ࡫ࡪࡃࠧ嘔")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嘕"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ嘖")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠪࠫ嘗"),l1l111_l1_ (u"ࠫࠬ嘘"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1111lll1_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嘙"),url,l1l111_l1_ (u"࠭ࠧ嘚"),headers,l1l111_l1_ (u"ࠧࠨ嘛"),l1l111_l1_ (u"ࠨࠩ嘜"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ嘝"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠢࡧ࠱࡫ࡲࡥࡹࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嘞"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭嘟") in l11llll_l1_[0]: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l11l111l_l1_ in range(2):
		if l11l1111lll1_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嘠"),l111llll1l_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嘡"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嘢"),block,re.DOTALL)
		if l11l1111lll1_l1_ and len(items)<2:
			l11l1111lll1_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠨࠢࠪ嘣")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ嘤") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡷ࡫ࡡࡥࡥࡵࡹࡲࡨࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ嘥"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嘦"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ嘧")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嘨"),url,l1l111_l1_ (u"ࠧࠨ嘩"),headers,l1l111_l1_ (u"ࠨࠩ嘪"),l1l111_l1_ (u"ࠩࠪ嘫"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ嘬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡦࡩࡴࡪࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ嘭"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嘮"),block,re.DOTALL)
	l11l1111llll_l1_ = l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ嘯") in block
	download = l1l111_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ嘰") in block
	if   l11l1111llll_l1_ and not download: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠨࠩ嘱")
	elif not l11l1111llll_l1_ and download: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1l111_l1_ (u"ࠩࠪ嘲"),l1ll_l1_[0]
	elif l11l1111llll_l1_ and download: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ嘳"),l1l111_l1_ (u"ࠫࠬ嘴")
	if l11l1111llll_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嘵"),l11l111l1111_l1_,l1l111_l1_ (u"࠭ࠧ嘶"),headers,l1l111_l1_ (u"ࠧࠨ嘷"),l1l111_l1_ (u"ࠨࠩ嘸"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭嘹"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡰࡪࡺࠠࡴࡧࡵࡺࡪࡸࡳࠩ࠰࠭ࡃ࠮ࡶ࡬ࡢࡻࡨࡶࠬ嘺"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘻"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ嘼"),l1l111_l1_ (u"࠭࠯ࠨ嘽"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ嘾")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ嘿")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭噀"),l11l1111ll1l_l1_,l1l111_l1_ (u"ࠪࠫ噁"),headers,l1l111_l1_ (u"ࠫࠬ噂"),l1l111_l1_ (u"ࠬ࠭噃"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ噄"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩࡪࡰࡩࡳ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠨ噅"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ噆"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ噇")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ噈")+l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ噉")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ噊"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ噋"),l1l111_l1_ (u"ࠧࠬࠩ噌"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ噍")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll11ll_l1_(url,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ噎"),l1l111_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ噏"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵࠩ噐"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ噑"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ噒"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ噓"),url,l1l111_l1_ (u"ࠨࠩ噔"),headers,l1l111_l1_ (u"ࠩࠪ噕"),l1l111_l1_ (u"ࠪࠫ噖"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ噗"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡩࡱࡺࡷ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠨ噘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡵࡱࡦࡤࡸࡪࡗࡵࡦࡴࡼࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࠫ噙"),block,re.DOTALL)
		l1111lll1_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111lll1_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࡠࡸ࠰ࠨ࠯ࠬࡂ࠭ࡡࡹࠪ࠽ࠩ噚"),block,re.DOTALL)
	return items
def l1111l1l1_l1_(url):
	if l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ噛") not in url: url = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭噜")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ噝"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ噞"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ噟"),l1l111_l1_ (u"࠭࠯ࡀࠩ噠"))
	return url
l1111ll11_l1_ = [l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ噡"),l1l111_l1_ (u"ࠨࡻࡨࡥࡷ࠭噢"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ噣"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ噤")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭噥"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ噦"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ噧")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ器"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ噩"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ噪"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ噫"),l1l111_l1_ (u"ࠫࠬ噬")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ噭"))
	if type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ噮"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩ噯") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪ噰") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ噱")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭噲")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭噳")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨ噴")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ噵"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ噶")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ噷"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ噸"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ噹")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ噺"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ噻"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧ噼"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ噽"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ噾"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭噿")+l11lll11_l1_
		l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚀"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ嚁"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚂"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭嚃")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭嚄"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭嚅"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嚆"),l1l111_l1_ (u"ࠪࠫ嚇"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"่๊ࠫࠠࠨ嚈"),l1l111_l1_ (u"ࠬ࠭嚉"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"࠭࠽ࠨ嚊") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ嚋"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ嚌")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嚍"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ嚎"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚏"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭嚐"),l1lllll1_l1_,115,l1l111_l1_ (u"࠭ࠧ嚑"),l1l111_l1_ (u"ࠧࠨ嚒"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭嚓"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ嚔")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭嚕")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭嚖")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ嚗")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嚘")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嚙"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪ嚚")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠩࠪ嚛"),l1l111_l1_ (u"ࠪࠫ嚜"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫ嚝"): option = l1l111_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬ嚞")
			elif value==l1l111_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭嚟"): option = l1l111_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩ嚠")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ嚡")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ嚢")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ嚣")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭嚤")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ嚥")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ嚦")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩ嚧")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ嚨")+name
			if type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ嚩"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚪"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠫࠬ嚫"),l1l111_l1_ (u"ࠬ࠭嚬"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ嚭") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩ嚮") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嚯"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭嚰")+l11ll111_l1_
				l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚱"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚲"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠬ࠭嚳"),l1l111_l1_ (u"࠭ࠧ嚴"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠧ࠾ࠨࠪ嚵"),l1l111_l1_ (u"ࠨ࠿࠳ࠪࠬ嚶"))
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫ嚷"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬ嚸") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭嚹"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ嚺"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧ嚻")
	for key in l1111ll11_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ嚼")
		if l1l111_l1_ (u"ࠨࠧࠪ嚽") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ嚾") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ嚿"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ囀")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ囁") and value!=l1l111_l1_ (u"࠭࠰ࠨ囂"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ囃")+key+l1l111_l1_ (u"ࠨ࠿ࠪ囄")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱ࠭囅"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ囆")+key+l1l111_l1_ (u"ࠫࡂ࠭囇")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ囈"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ囉"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠧ࠾࠲ࠪ囊"),l1l111_l1_ (u"ࠨ࠿ࠪ囋"))
	return l1l1l111_l1_
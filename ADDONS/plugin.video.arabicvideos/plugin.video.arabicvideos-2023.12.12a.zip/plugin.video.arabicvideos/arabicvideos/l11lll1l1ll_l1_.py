# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ屺")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ屻")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l111ll1l11l1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l111ll1l1111_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l111llll11l1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l111lll111ll_l1_()
	elif mode==148: l1lll_l1_ = l111lll11l1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屼"),l1lllll_l1_+l1l111_l1_ (u"ࠪๆฬฬๅสࠩ屽"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌࡂ࡬࠸ࡋࡸ࠾ࡆࡉ࠺࡝ࡲ࡚ࡨࡆ࠱ࡔ࡙࠱࠼ࡍ࠳ࡃࡱࡴࡍࡾࡠࡁ࠵ࡷࡖࡅࠬ屾"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屿"),l1lllll_l1_+l1l111_l1_ (u"࠭ิฯืࠪ岀"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࡔࡄࡐࡲࡪ࡫࡯ࡣࡪࡣ࡯ࠫ岁"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岂"),l1lllll_l1_+l1l111_l1_ (u"่ࠩ์็฿ࠧ岃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࡛ࡃࡲ࠷࠼ࡥࡌࡔࡳࡲ࠻ࡥࡦ࡭ࡽࡖࡕࡳ࠴࡙ࡹࡼࡧࡸࠩ岄"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岅"),l1lllll_l1_+l1l111_l1_ (u"ࠬำำศสࠪ岆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡁࡖ࡫ࡩࡘࡵࡣࡪࡣ࡯ࡇ࡙࡜ࠧ岇"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岈"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็฽ฬฮࠧ岉"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ岊"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岋"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠪ岌"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡸࡺ࡯ࡳࡧࡩࡶࡴࡴࡴࠨ岍"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岎"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆะอหึอสࠨ岏"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ岐"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岑"),l1lllll_l1_+l1l111_l1_ (u"ࠪๆฺ๐ัสࠩ岒"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ岓"),144,l1l111_l1_ (u"ࠬ࠭岔"),l1l111_l1_ (u"࠭ࠧ岕"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ岖"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岗"),l1lllll_l1_+l1l111_l1_ (u"ࠩอูๆำࠧ岘"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭岙"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岚"),l1lllll_l1_+l1l111_l1_ (u"ࠬืฦ๋ีํอࠬ岛"),l111l1_l1_+l1l111_l1_ (u"࠭ࠧ岜"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岝"),l1lllll_l1_+l1l111_l1_ (u"ࠨำสสั࠭岞"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࡂࡦࡵࡃࠧ岟"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ岠"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ岡"),l1l111_l1_ (u"ࠬ࠭岢"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岣"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ岤"),l1l111_l1_ (u"ࠨࠩ岥"),149,l1l111_l1_ (u"ࠩࠪ岦"),l1l111_l1_ (u"ࠪࠫ岧"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ岨"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ岩"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭岪"),l1l111_l1_ (u"ࠧࠨ岫"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岬"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ岭"),l111l1_l1_+l1l111_l1_ (u"ࠪࠫ岮"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岯"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไาษษะฮ࠭岰"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ岱"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岲"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ฮฺ็อࠨ岳"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ岴"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岵"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊โึ์ิอࠬ岶"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭岷"),144,l1l111_l1_ (u"࠭ࠧ岸"),l1l111_l1_ (u"ࠧࠨ岹"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ岺"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岻"),l1lllll_l1_+l1l111_l1_ (u"้ࠪำะวาษอࠤ๏๎ส๋๊หࠫ岼"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ岽"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岾"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅฯฬสีฬะࠠศๆหี๋อๅอࠩ岿"),l1l111_l1_ (u"ࠧࠨ峀"),290)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭峁"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ峂"),l1l111_l1_ (u"ࠪࠫ峃"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峄"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢ฼ีอ๐ษࠨ峅"),l1l111_l1_ (u"࠭ࠧ峆"),147)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峇"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ峈"),l1l111_l1_ (u"ࠩࠪ峉"),148)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峊"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡ฻ิฬ๏ฯࠧ峋"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃแ๋ๆ่ࠫ峌"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峍"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤฬาๆษ์ฬࠫ峎"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡰࡳࡻ࡯ࡥࠨ峏"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峐"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึีา๐วหࠢ฼ีอ๐ษࠨ峑"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำาฯํอࠬ峒"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峓"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥ฿ัษ์ฬࠫ峔"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึุ่๊ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ峕"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峖"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ峗"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ峘"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峙"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ่อัห๊้ࠫ峚"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ไษิฮํ์ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ峛"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峜"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭峝"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭峞"),144)
	return
def l111ll1l1111_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峟"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡈࡎࡎࡍ࠼ࠣࠤࠬ峠")+name,url,144,l11l_l1_)
	return
def l111lll111ll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯อัࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ峡"))
	return
def l111lll11l1l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡵࡸࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ峢"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠧࠧࠩ峣"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111ll1lll11_l1_(yccc,url,index):
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ峤"))
	l111ll11lll1_l1_,l111ll1lll1l_l1_ = [],[]
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ峥") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡁࡤࡶ࡬ࡳࡳࡹࠧ࡞ࠤ峦"))
	if l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ峧") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࠧ峨"))
	if level==l1l111_l1_ (u"࠭࠱ࠨ峩"): l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡧࡧࡨࡨࡋ࡯࡬ࡵࡧࡵࡇ࡭࡯ࡰࡃࡣࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ峪"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峫"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࠧ峬"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡨࡲࡹࡸࡩࡦࡵࠪࡡࠧ峭"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠ࡟࠸ࡣ࡛ࠨࡩࡸ࡭ࡩ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ峮"))
	l111lll1l111_l1_,yddd,l111ll1ll1ll_l1_ = l111ll11ll11_l1_(yccc,l1l111_l1_ (u"ࠬ࠭峯"),l111ll11lll1_l1_)
	if level==l1l111_l1_ (u"࠭࠱ࠨ峰") and l111lll1l111_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭峱") not in url:
			for zz in range(len(yddd)):
				l111ll1l1l1l_l1_ = str(zz)
				l111ll11lll1_l1_ = []
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ峲")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ峳"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ峴")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࠨ࡟ࠥ峵"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ島")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠨ࡝ࠣ峷"))
				succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yddd,l1l111_l1_ (u"ࠧࠨ峸"),l111ll11lll1_l1_)
				if succeeded: l111ll1lll1l_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠴࠽࠾ࠬ峹")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ峺")])
			l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠࠦ峻"))
			succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yccc,l1l111_l1_ (u"ࠫࠬ峼"),l111ll11lll1_l1_)
			if succeeded and l111ll1lll1l_l1_ and l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ峽") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ峾")
				l111ll1lll1l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࠲࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ峿")])
	return yddd,l111lll1l111_l1_,l111ll1lll1l_l1_,l111ll1ll1ll_l1_
def l111ll11l11l_l1_(yccc,yddd,url,index):
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ崀"))
	l111ll11lll1_l1_,l111ll1llll1_l1_ = [],[]
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ崁"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ崂")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ崃"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠵ࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ崄"))
	if l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ崅") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ崆"))
	elif l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ崇") in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崈"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ崉")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崊"))
	if l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭崋") in url or (l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ崌") in url and l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ崍") not in url):
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ崎")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ崏"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ崐")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ崑"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ崒")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ崓"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ崔")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ崕"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ崖")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠥࡡࠧ崗"))
	l111lll11ll1_l1_,yeee,l111ll1ll1l1_l1_ = l111ll11ll11_l1_(yddd,l1l111_l1_ (u"ࠫࠬ崘"),l111ll11lll1_l1_)
	if level==l1l111_l1_ (u"ࠬ࠸ࠧ崙") and l111lll11ll1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l111ll11lll1_l1_ = []
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崚")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ崛"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崜")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ崝"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崞")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ崟"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崠")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ崡"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崢")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ崣"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崤")+index2+l1l111_l1_ (u"ࠥࡡࠧ崥"))
				succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yeee,l1l111_l1_ (u"ࠫࠬ崦"),l111ll11lll1_l1_)
				if succeeded: l111ll1llll1_l1_.append([item,url,l1l111_l1_ (u"ࠬ࠹࠺࠻ࠩ崧")+l111ll1l1l1l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ崨")+index2+l1l111_l1_ (u"ࠧ࠻࠼࠳ࠫ崩")])
			l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠲࡟ࠥ崪"))
			l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠲࡟ࠥ崫"))
			succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yddd,l1l111_l1_ (u"ࠪࠫ崬"),l111ll11lll1_l1_)
			if succeeded and l111ll1llll1_l1_ and l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ崭") in list(item.keys()):
				l111ll1llll1_l1_.append([item,url,l1l111_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ崮")])
	return yeee,l111lll11ll1_l1_,l111ll1llll1_l1_,l111ll1ll1l1_l1_
def l111ll1l111l_l1_(yccc,yeee,url,index):
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ崯"))
	l111ll11lll1_l1_,l111ll1l11ll_l1_ = [],[]
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崰")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡻ࡫ࡲࡵ࡫ࡦࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崱"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崲")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崳"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崴")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崵"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崶")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崷"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崸")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崹"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崺")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崻"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崼")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ崽"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崾")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崿"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嵀"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嵁"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嵂"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ嵃")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡪࡲࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嵄"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嵅")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嵆"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫ࠢ嵇"))
	l111lll1l1l1_l1_,yfff,l111llll1l11_l1_ = l111ll11ll11_l1_(yeee,l1l111_l1_ (u"ࠪࠫ嵈"),l111ll11lll1_l1_)
	if level==l1l111_l1_ (u"ࠫ࠸࠭嵉") and l111lll1l1l1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l111ll1l1lll_l1_ = str(zz)
				l111ll11lll1_l1_ = []
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡦࡧࡨ࡞ࠦ嵊")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ嵋"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡨࡩࡪࡠࠨ嵌")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡬ࡧ࡭ࡦࡅࡤࡶࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡫ࡦࡳࡥࠨ࡟ࠥ嵍"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡪ࡫࡬࡛ࠣ嵎")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ嵏"))
				l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡬ࡦࡧ࡝ࠥ嵐")+l111ll1l1lll_l1_+l1l111_l1_ (u"ࠧࡣࠢ嵑"))
				succeeded,item,l1111ll1_l1_ = l111ll11ll11_l1_(yfff,l1l111_l1_ (u"࠭ࠧ嵒"),l111ll11lll1_l1_)
				if succeeded: l111ll1l11ll_l1_.append([item,url,l1l111_l1_ (u"ࠧ࠵࠼࠽ࠫ嵓")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵔")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵕")+l111ll1l1lll_l1_])
	return yfff,l111lll1l1l1_l1_,l111ll1l11ll_l1_,l111llll1l11_l1_
def l111ll11ll11_l1_(l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l111ll1l1l11_l1_):
	yccc,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	yddd,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	yeee,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	yfff,l1l1l1ll111l_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	item,yrender = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	count = len(l111ll1l1l11_l1_)
	for l1l11l111l_l1_ in range(count):
		try:
			out = eval(l111ll1l1l11_l1_[l1l11l111l_l1_])
			return True,out,l1l11l111l_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠪࠫ嵖"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠫࠬ嵗"),data=l1l111_l1_ (u"ࠬ࠭嵘")):
	l111ll1lll1l_l1_,l111ll1llll1_l1_,l111ll1l11ll_l1_ = [],[],[]
	if l1l111_l1_ (u"࠭࠺࠻ࠩ嵙") not in index: index = l1l111_l1_ (u"ࠧ࠲࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ嵚")
	level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵛"))
	if level==l1l111_l1_ (u"ࠩ࠷ࠫ嵜"): level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠪ࠵ࠬ嵝"),l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_
	data = data.replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ嵞"),l1l111_l1_ (u"ࠬ࠭嵟"))
	html,yccc,l1l11llll_l1_ = l111ll1lllll_l1_(url,data)
	index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ嵠")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵡")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵢")+l111ll1l1lll_l1_
	if level in [l1l111_l1_ (u"ࠩ࠴ࠫ嵣"),l1l111_l1_ (u"ࠪ࠶ࠬ嵤"),l1l111_l1_ (u"ࠫ࠸࠭嵥")]:
		yddd,l111lll1l111_l1_,l111ll1lll1l_l1_,l111ll1ll1ll_l1_ = l111ll1lll11_l1_(yccc,url,index)
		if not l111lll1l111_l1_: return
		l1lllll111_l1_ = len(l111ll1lll1l_l1_)
		if l1lllll111_l1_<2:
			if level==l1l111_l1_ (u"ࠬ࠷ࠧ嵦"): level = l1l111_l1_ (u"࠭࠲ࠨ嵧")
			l111ll1lll1l_l1_ = []
	index = level+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵨")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵩")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵪")+l111ll1l1lll_l1_
	if level in [l1l111_l1_ (u"ࠪ࠶ࠬ嵫"),l1l111_l1_ (u"ࠫ࠸࠭嵬")]:
		yeee,l111lll11ll1_l1_,l111ll1llll1_l1_,l111ll1ll1l1_l1_ = l111ll11l11l_l1_(yccc,yddd,url,index)
		if not l111lll11ll1_l1_: return
		l1ll1l1l11_l1_ = len(l111ll1llll1_l1_)
		if l1ll1l1l11_l1_<2:
			if level==l1l111_l1_ (u"ࠬ࠸ࠧ嵭"): level = l1l111_l1_ (u"࠭࠳ࠨ嵮")
			l111ll1llll1_l1_ = []
	index = level+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵯")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵰")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵱")+l111ll1l1lll_l1_
	if level in [l1l111_l1_ (u"ࠪ࠷ࠬ嵲")]:
		yfff,l111lll1l1l1_l1_,l111ll1l11ll_l1_,l111llll1l11_l1_ = l111ll1l111l_l1_(yccc,yeee,url,index)
		if not l111lll1l1l1_l1_: return
		l1ll1l1l1l_l1_ = len(l111ll1l11ll_l1_)
	for item,url,index in l111ll1lll1l_l1_+l111ll1llll1_l1_+l111ll1l11ll_l1_:
		l1ll11l1ll1l_l1_ = l111ll11llll_l1_(item,url,index)
	return
def l111ll11llll_l1_(item,url=l1l111_l1_ (u"ࠫࠬ嵳"),index=l1l111_l1_ (u"ࠬ࠭嵴")):
	if l1l111_l1_ (u"࠭࠺࠻ࠩ嵵") in index: level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵶"))
	else: level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠨ࠳ࠪ嵷"),l1l111_l1_ (u"ࠩ࠳ࠫ嵸"),l1l111_l1_ (u"ࠪ࠴ࠬ嵹"),l1l111_l1_ (u"ࠫ࠵࠭嵺")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,l111llll111l_l1_ = l111llll1ll1_l1_(item)
	l1llll11ll11_l1_ = l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸࡅࠧ嵻") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡴࡶࡵࡩࡦࡳࡳࡀࠩ嵼") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ嵽") in l1ll1ll_l1_
	l1llll11l1l1_l1_ = l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ嵾") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࡂࠫ嵿") in l1ll1ll_l1_
	if l1llll11ll11_l1_ or l1llll11l1l1_l1_: l1ll1ll_l1_ = url
	l1llll11ll11_l1_ = l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ嶀") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭嶁") not in l1ll1ll_l1_
	l1llll11l1l1_l1_ = l1l111_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭嶂") not in l1ll1ll_l1_  and l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡹࡴࡰࡴࡨࡪࡷࡵ࡮ࡵࠩ嶃") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀࠧ嶄") and l1llll11ll11_l1_ and l1llll11l1l1_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ嶅") in url or l1l111_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ嶆") in l1ll1ll_l1_:
		level,l111ll1l1l1l_l1_,index2,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠪ࠵ࠬ嶇"),l1l111_l1_ (u"ࠫ࠵࠭嶈"),l1l111_l1_ (u"ࠬ࠶ࠧ嶉"),l1l111_l1_ (u"࠭࠰ࠨ嶊")
		index = l1l111_l1_ (u"ࠧࠨ嶋")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠨࠩ嶌")
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ嶍") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ嶎") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ嶏") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ嶐"))
		if data.count(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ嶑"))==4:
			l111lll1l11l_l1_,key,l111lll11l11_l1_,l111lll1111l_l1_,token = data.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ嶒"))
			l1l11llll_l1_ = l111lll1l11l_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ嶓")+key+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭嶔")+l111lll11l11_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ嶕")+l111lll1111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ嶖")+l111llll111l_l1_
			if l1l111_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ嶗") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ嶘")+key
	if not title:
		global l111ll1l11l1_l1_
		l111ll1l11l1_l1_ += 1
		title = l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࠪ嶙")+str(l111ll1l11l1_l1_)
		index = l1l111_l1_ (u"ࠨ࠵ࠪ嶚")+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶛")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭嶜")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶝")+l111ll1l1lll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ嶞") in str(item): return False
	elif l1l111_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭嶟") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ嶠") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ嶡") in list(item.keys()) or l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ嶢") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭嶣")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶤")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶥")+l111ll1l1lll_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶦"),l1lllll_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ嶧")+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ嶨"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ嶩") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ嶪")+title
		index = l1l111_l1_ (u"ࠫ࠸࠭嶫")+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶬")+l111ll1l1l1l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ嶭")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶮")+l111ll1l1lll_l1_
		url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ嶯"),l1l111_l1_ (u"ࠩࠪ嶰"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶱"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠫࠬ嶲"),index,l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ嶳"))
	elif l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ嶴") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠧ࠴ࠩ嶵")+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶶")+l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶷")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嶸")+l111ll1l1lll_l1_
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ嶹")+title
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嶺"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫ࠧ嶻") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ嶼")+title
		index = l1l111_l1_ (u"ࠨ࠴࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ嶽")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶾"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ嶿") in str(item):
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ巀")+title
		index = l1l111_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ巁")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭巂"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ巃") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭巄"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ巅"),9999)
	elif l111lll1l1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ巆"),l1lllll_l1_+l111lll1l1ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭巇") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巈"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ巉")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ巊")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ巋") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ巌"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ巍"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll1ll_l1_)
	elif l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ巎") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ巏") in l1ll1ll_l1_ and count:
			l111lll11lll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭巐"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ巑")+l111lll11lll_l1_
			index = l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ巒")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巓"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ巔")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ巕")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ巖"),1)[0]
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ巗"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll1ll_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ巘") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡦ࠳ࠬ巙") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠩ࠲ࡄࠬ巚") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠪ࠳ࠬ巛"))==3):
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巜"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡉࡈࡏࡎࠪ川")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ州")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ巟") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巠"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡘࡗࡊࡘࠧ巡")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ巢")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ巣")+title
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巤"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l111llll1ll1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,token = False,l1l111_l1_ (u"࠭ࠧ工"),l1l111_l1_ (u"ࠧࠨ左"),l1l111_l1_ (u"ࠨࠩ巧"),l1l111_l1_ (u"ࠩࠪ巨"),l1l111_l1_ (u"ࠪࠫ巩"),l1l111_l1_ (u"ࠫࠬ巪"),l1l111_l1_ (u"ࠬ࠭巫"),l1l111_l1_ (u"࠭ࠧ巬")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,token
	for l111lll111l1_l1_ in list(item.keys()):
		yrender = item[l111lll111l1_l1_]
		if isinstance(yrender,dict): break
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ巭"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡐ࡮ࡹࡴࡉࡧࡤࡨࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ差"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥ࡮࡬ࡲࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ巯"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡻ࡮ࡱ࡮ࡤࡽࡦࡨ࡬ࡦࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ巰"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡦࡰࡴࡰࡥࡹࡺࡥࡥࡖ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ己"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ已"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ巳"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ巴"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ巵"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ巶"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ巷"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡺ࡮ࡪࡥࡰࡋࡧࠫࡢࠨ巸"))
	succeeded,title,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巹"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ巺"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ巻"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ巼"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ巽"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巾"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ巿"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ帀"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ币"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ市"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࠧ࡞ࠤ布"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࡕࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ帄"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡆࡴࡺࡴࡰ࡯ࡓࡥࡳ࡫࡬ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ帅"))
	succeeded,count,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ帆"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ帇"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨ࡮ࡨࡲ࡬ࡺࡨࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ师"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࠭࡝࡜ࠩ࡬ࡧࡴࡴࡔࡺࡲࡨࠫࡢࠨ帉"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡶࡸࡾࡲࡥࠨ࡟ࠥ帊"))
	succeeded,l1l1lll1ll_l1_,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ帋"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ希"))
	succeeded,token,l1111ll1_l1_ = l111ll11ll11_l1_(item,yrender,l111ll11lll1_l1_)
	if l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ帍") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭帎"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ帏")
	if l1l111_l1_ (u"ࠧๆสสุึ࠭帐") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ帑"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ帒")
	if l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ帓") in list(yrender.keys()):
		l111lll1llll_l1_ = str(yrender[l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ帔")])
		if l1l111_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ帕") in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ帖")
		if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ帗") in l111lll1llll_l1_: l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ帘")
		if l1l111_l1_ (u"ࠩࡅࡹࡾ࠭帙") in l111lll1llll_l1_ or l1l111_l1_ (u"ࠪࡖࡪࡴࡴࠨ帚") in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ帛")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡺ࠭ๅษษืีࠬ帜")) in l111lll1llll_l1_: l111lll1l1ll_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ帝")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡵࠨึิหฦ࠭帞")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ帟")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡷࠪหุะฦอษิࠫ帠")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ帡")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡹࠬหูๅษ้หฯ࠭帢")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠡࠢࠪ帣")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ帤") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠧࡀࠩ帥"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭带") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ帧")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111lll11111_l1_: title = l111lll11111_l1_+title
	l1l1lll1ll_l1_ = l1l1lll1ll_l1_.replace(l1l111_l1_ (u"ࠪ࠰ࠬ帨"),l1l111_l1_ (u"ࠫࠬ帩"))
	count = count.replace(l1l111_l1_ (u"ࠬ࠲ࠧ帪"),l1l111_l1_ (u"࠭ࠧ師"))
	count = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࠫ帬"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠨࠩ席")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_,token
def l111ll1lllll_l1_(url,data=l1l111_l1_ (u"ࠩࠪ帮"),request=l1l111_l1_ (u"ࠪࠫ帯")):
	if request==l1l111_l1_ (u"ࠫࠬ帰"): request = l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ帱")
	l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ帲"):l11ll1l1l1_l1_,l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ帳"):l1l111_l1_ (u"ࠨࡒࡕࡉࡋࡃࡨ࡭࠿ࡤࡶࠬ帴")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ帵"))
	if data.count(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ帶"))==4: l111lll1l11l_l1_,key,l111lll11l11_l1_,l111lll1111l_l1_,token = data.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ帷"))
	else: l111lll1l11l_l1_,key,l111lll11l11_l1_,l111lll1111l_l1_,token = l1l111_l1_ (u"ࠬ࠭常"),l1l111_l1_ (u"࠭ࠧ帹"),l1l111_l1_ (u"ࠧࠨ帺"),l1l111_l1_ (u"ࠨࠩ帻"),l1l111_l1_ (u"ࠩࠪ帼")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠥࡧࡴࡴࡴࡦࡺࡷࠦ帽"):{l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ帾"):{l1l111_l1_ (u"ࠧ࡮࡬ࠣ帿"):l1l111_l1_ (u"ࠨࡡࡳࠤ幀"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ幁"):l1l111_l1_ (u"࡙ࠣࡈࡆࠧ幂"),l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ幃"):l111lll11l11_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ幄") or l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ幅") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡷ࡫ࡥ࡭࠱ࡵࡩࡪࡲ࡟ࡸࡣࡷࡧ࡭ࡥࡳࡦࡳࡸࡩࡳࡩࡥࠨ幆")+l1l111_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ幇")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦࡒࡤࡶࡦࡳࡳࠨ幈")] = l111lll1l11l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭幉"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ幊"))
	elif l1l111_l1_ (u"ࠪ࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ幋") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ幌")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ幍"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ幎"))
	elif l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ幏") in url and l111lll1l11l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ幐")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ幑")][l1l111_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࠪ幒")][l1l111_l1_ (u"ࠫࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠩ幓")] = l111lll1l11l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ幔"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠵ࡶ࡫ࠫ幕"))
	elif l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ幖") in url and l111lll1111l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ幗"):l1l111_l1_ (u"ࠩ࠴ࠫ幘"),l1l111_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ幙"):l111lll11l11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ幚"):l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ幛")+l111lll1111l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ幜"),url,l1l111_l1_ (u"ࠧࠨ幝"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ幞"),l1l111_l1_ (u"ࠩࠪ幟"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠺ࡺࡨࠨ幠"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ幡"),url,l1l111_l1_ (u"ࠬ࠭幢"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ幣"),l1l111_l1_ (u"ࠧࠨ幤"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠹ࡸ࡭࠭幥"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ幦"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ幧"),html,re.DOTALL|re.I)
	if tmp: l111lll11l11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ幨"),html,re.DOTALL|re.I)
	if tmp: l111lll1l11l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ幩") in list(cookies.keys()): l111lll1111l_l1_ = cookies[l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ幪")]
	l1l1l1111_l1_ = l111lll1l11l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ幫")+key+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ幬")+l111lll11l11_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭幭")+l111lll1111l_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ幮")+token
	if request==l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ幯") and l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ幰") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ幱"),html,re.DOTALL)
		if not l11ll11l1l_l1_: l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ干"),html,re.DOTALL)
		l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ平"),l11ll11l1l_l1_[0])
	elif request==l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ年") and l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ幵") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ并"),html,re.DOTALL)
		l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ幷"),l11ll11l1l_l1_[0])
	elif l1l111_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ幸") not in html: l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ幹"),html)
	else: l111lll1lll1_l1_ = l1l111_l1_ (u"ࠨࠩ幺")
	if 0:
		yccc = str(l111lll1lll1_l1_)
		if kodi_version>18.99: yccc = yccc.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ幻"))
		open(l1l111_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰ࡧࡥࡹ࠭幼"),l1l111_l1_ (u"ࠫࡼࡨࠧ幽")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ幾"),l1l1l1111_l1_)
	return html,l111lll1lll1_l1_,l1l1l1111_l1_
def l111llll11l1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ广"),l1l111_l1_ (u"ࠧࠬࠩ庀"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ庁")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ庂"),l1l111_l1_ (u"ࠪ࠯ࠬ広"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ࠭庄")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨ庅") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡓࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭庆")
		elif l1l111_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭庇") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ庈")
		elif l1l111_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ庉") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆ࡭ࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ床")
		else: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠫࠬ庋")
		l1llllll_l1_ = l1lllll1_l1_+l111ll1ll11l_l1_
	else:
		l111ll1ll111_l1_,l111ll11l1ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠬ࠭庌")
		l111ll11ll1l_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ庍"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭庎"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ序"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ庐"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ庑")]
		l111lll1ll1l_l1_ = [l1l111_l1_ (u"ࠫࠬ庒"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ库"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ应"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭底"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ庖")]
		l111llll1111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ店"),l111ll11ll1l_l1_)
		if l111llll1111_l1_ == -1: return
		l111ll1l1ll1_l1_ = l111lll1ll1l_l1_[l111llll1111_l1_]
		html,c,data = l111ll1lllll_l1_(l1lllll1_l1_+l111ll1l1ll1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ庘")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ庙")][l1l111_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ庚")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ庛")][l1l111_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ府")][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ庝")][l1l111_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ庞")]
				for l111ll11l1l1_l1_ in range(len(d)):
					group = d[l111ll11l1l1_l1_][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ废")][l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ庠")]
					for l111llll11ll_l1_ in range(len(group)):
						yrender = group[l111llll11ll_l1_][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ庡")]
						if l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ庢") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ庣")][l1l111_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ庤")][l1l111_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ庥")][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ度")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ座"),l1l111_l1_ (u"ࠬࠬࠧ庨"))
							title = yrender[l1l111_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ庩")]
							title = title.replace(l1l111_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ庪"),l1l111_l1_ (u"ࠨࠩ庫"))
							if l1l111_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ庬") in title: continue
							if l1l111_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ庭") in title:
								title = l1l111_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ庮")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠬะัห์หࠤาูศࠨ庯") in title: continue
							title = title.replace(l1l111_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ庰"),l1l111_l1_ (u"ࠧࠨ庱"))
							if l1l111_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ庲") in title: continue
							if l1l111_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ庳") in title:
								title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ庴")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ庵") in title: continue
							l111ll1ll111_l1_.append(escapeUNICODE(title))
							l111ll11l1ll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l111lll1ll11_l1_ = l1l111_l1_ (u"ࠬ࠭庶")
		else:
			l111ll1ll111_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ康"),l1lllllll_l1_]+l111ll1ll111_l1_
			l111ll11l1ll_l1_ = [l1l111_l1_ (u"ࠧࠨ庸"),l111lllll_l1_]+l111ll11l1ll_l1_
			l111llll1l1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭庹"),l111ll1ll111_l1_)
			if l111llll1l1l_l1_ == -1: return
			l111lll1ll11_l1_ = l111ll11l1ll_l1_[l111llll1l1l_l1_]
		if l111lll1ll11_l1_: l1llllll_l1_ = l111l1_l1_+l111lll1ll11_l1_
		elif l111ll1l1ll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1l1ll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
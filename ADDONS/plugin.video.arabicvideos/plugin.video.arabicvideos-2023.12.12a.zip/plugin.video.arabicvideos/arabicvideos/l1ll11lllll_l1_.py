# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ⾈")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩ⾉")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⾊"):l1l111_l1_ (u"ࠬ࠭⾋")}
def l11l1ll_l1_(mode,url,text):
	if   mode==320: l1lll_l1_ = l1l1l11_l1_()
	elif mode==321: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==322: l1lll_l1_ = PLAY(url)
	elif mode==329: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾌"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⾍"),l1l111_l1_ (u"ࠨࠩ⾎"),329,l1l111_l1_ (u"ࠩࠪ⾏"),l1l111_l1_ (u"ࠪࠫ⾐"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⾑"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⾒"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⾓"),l1l111_l1_ (u"ࠧࠨ⾔"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⾕"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠰ࡳ࡬ࡵ࠭⾖"),l1l111_l1_ (u"ࠪࠫ⾗"),headers,l1l111_l1_ (u"ࠫࠬ⾘"),l1l111_l1_ (u"ࠬ࠭⾙"),l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⾚"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡥࡲࡲࡴ࠳ࡰ࡭ࡷࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⾛"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⾜"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title==l1l111_l1_ (u"ࠩส่๊้สษหࠣห้๋ัว์ฬࠫ⾝"): continue
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⾞"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⾟")+l1lllll_l1_+title,l1ll1ll_l1_,321)
	return html
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⾠"),url,l1l111_l1_ (u"࠭ࠧ⾡"),headers,l1l111_l1_ (u"ࠧࠨ⾢"),l1l111_l1_ (u"ࠨࠩ⾣"),l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⾤"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ⾥"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡰࡥ࠷ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⾦"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⾧"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,count,title in items:
		count = count.replace(l1l111_l1_ (u"ู࠭ะัࠣࠫ⾨"),l1l111_l1_ (u"ࠧࠨ⾩")).replace(l1l111_l1_ (u"ࠨࠢࠪ⾪"),l1l111_l1_ (u"ࠩࠪ⾫"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࠬ⾬"),l1l111_l1_ (u"ࠫࠬ⾭"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠧ࠭ࠢ⾮"),l1l111_l1_ (u"࠭ࠧ⾯"))
		if l1l111_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬ⾰") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ⾱")+l1ll1ll_l1_
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ⾲")+l1ll1ll_l1_
		l1ll1l_l1_ = l111l1_l1_+l1ll1l_l1_
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⾳"))
		title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ⾴")+count+l1l111_l1_ (u"ࠬ࠯ࠧ⾵")
		if l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⾶") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⾷"),l1lllll_l1_+title,l1ll1ll_l1_,321,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ⾸") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⾹"),l1lllll_l1_+title,l1ll1ll_l1_,322,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ⾺"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⾻"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⾼")+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾽"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭⾾")+title,l1ll1ll_l1_,321)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⾿"),url,l1l111_l1_ (u"ࠩࠪ⿀"),headers,l1l111_l1_ (u"ࠪࠫ⿁"),l1l111_l1_ (u"ࠫࠬ⿂"),l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⿃"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⿄"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⿅"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ⿆"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ⿇"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ⿈"),l1l111_l1_ (u"ࠫ࠰࠭⿉"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭⿊")+search
	l1lll11_l1_(url)
	return
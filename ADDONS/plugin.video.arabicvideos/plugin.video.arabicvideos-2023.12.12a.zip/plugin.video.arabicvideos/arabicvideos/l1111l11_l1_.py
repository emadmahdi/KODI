# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧஃ")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ஄"):l1l111_l1_ (u"ࠩࠪஅ")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡐࡒࡁࡠࠩஆ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==10: l1lll_l1_ = l1l1l11_l1_()
	elif mode==11: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==12: l1lll_l1_ = PLAY(url)
	elif mode==13: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==14: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==15: l1lll_l1_ = l111111l_l1_()
	elif mode==16: l1lll_l1_ = l11111l1_l1_()
	elif mode==19: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫஇ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬஈ"),l1l111_l1_ (u"࠭ࠧஉ"),19,l1l111_l1_ (u"ࠧࠨஊ"),l1l111_l1_ (u"ࠨࠩ஋"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭஌"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ஍"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫஎ"),l1l111_l1_ (u"ࠬ࠭ஏ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ஐ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ஑")+l1lllll_l1_+l1l111_l1_ (u"ࠨฤัีࠥอไฦุสๅฬะࠧஒ"),l1l111_l1_ (u"ࠩࠪஓ"),14)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪஔ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭க")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠬ஖"),l1l111_l1_ (u"࠭ࠧ஗"),15)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ஘"),headers,l1l111_l1_ (u"ࠨࠩங"),l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫச"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡯ࡣࡹ࠱ࡸࡲࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ஛"),html,re.DOTALL)
	l1111lll_l1_ = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ஜ"),l1111lll_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ஝"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ஞ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩட")+l1lllll_l1_+title,l1ll1ll_l1_,11)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭஠"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ஡"),l1l111_l1_ (u"ࠪࠫ஢"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡰࡤࡺࡧࡧࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ண"),html,re.DOTALL)
	l1l1l1l_l1_ = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧத"),l1l1l1l_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭஥"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ஦")+l1lllll_l1_+title,l1ll1ll_l1_,11)
	return html
def l111111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஧"),l1lllll_l1_+l1l111_l1_ (u"ࠩฯ้๏฿ࠠศๆ่ืู้ไศฬࠣห้฿ัษ์ฬࠫந"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡥࡸ࠯࠻࠳ู๊ไิๆสฮ࠲฿ัษ์ฬࠫன"),11)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫப"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦวๅี้อࠥอไฤะํีฮ࠭஫"),l1l111_l1_ (u"࠭ࠧ஬"),16)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஭"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡษ็วำ๐ัสࠢ࠴ࠫம"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮࡫ࡷ࠮࠺࠲ุ้๊ำๅษอ࠱ึ๋ึศ่࠰࠶࠵࠸࠲ࠨய"),11)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪர"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤฬ๊รฯ์ิอࠥ࠸ࠧற"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠱࠽࠵ๅิๆึ่ฬะ࠭า็ูห๋࠳࠲࠱࠴࠶ࠫல"),11)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ள"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠵࠷ࠬழ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠷࠹࠯ๆืิ๎ฮ࠭வ"),11)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩஶ"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠸࠲ࠨஷ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠳࠴࠲ฺ้ื๊สࠩஸ"),11)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬஹ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠴࠴ࠫ஺"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠶࠶࠵ๅึำํอࠬ஻"),11)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஼"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠷࠶ࠧ஽"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠲࠱࠱ู่ึ๐ษࠨா"),11)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫி"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠲࠻ࠪீ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠴࠽࠴๋ีา์ฬࠫு"),11)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧூ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠵࠽࠭௃"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠷࠸࠰็ุี๏ฯࠧ௄"),11)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ௅"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠱࠸ࠩெ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠳࠺࠳๊฻ั๋หࠪே"),11)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ை"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠴࠺ࠬ௉"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠶࠼࠯ๆืิ๎ฮ࠭ொ"),11)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪோ"),headers,True,l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡐࡆ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧௌ"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫ࡭࡫ࡡࡥ࡫ࡱ࡫࠲ࡺ࡯ࡱࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿்ࠪ"),html,re.DOTALL)
	block = l11llll_l1_[0]+l11llll_l1_[1]
	items=re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ௎"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭௏") in url: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧௐ"),l1lllll_l1_+title,url,11,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ௑"),l1lllll_l1_+title,url,12,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭௒"),url,l1l111_l1_ (u"ࠪࠫ௓"),headers,True,True,l1l111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ௔"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠮࠮ࠫࡁࠬࡶ࡮࡭ࡨࡵࡡࡦࡳࡳࡺࡥ࡯ࡶࠪ௕"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	found = False
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠲ࡨ࡯ࡹ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ௖"),block,re.DOTALL)
	l1l1_l1_,l11111ll_l1_ = [],[]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if title==l1l111_l1_ (u"ࠧࠨௗ"): title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ௘"))[-1].replace(l1l111_l1_ (u"ࠩ࠰ࠫ௙"),l1l111_l1_ (u"ࠪࠤࠬ௚"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡢࡤࠬࠫࠪ௛"),title,re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = int(l1111ll1_l1_[0])
		else: l1111ll1_l1_ = 0
		l11111ll_l1_.append([l1ll1l_l1_,l1ll1ll_l1_,title,l1111ll1_l1_])
	l11111ll_l1_ = sorted(l11111ll_l1_, reverse=True, key=lambda key: key[3])
	for l1ll1l_l1_,l1ll1ll_l1_,title,l1111ll1_l1_ in l11111ll_l1_:
		l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
		title = title.replace(l1l111_l1_ (u"๋ࠬิศ้าอ๋ࠥำๅี็ࠫ௜"),l1l111_l1_ (u"࠭ๅิๆึ่ࠬ௝"))
		title = title.replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ืู้ไࠨ௞"),l1l111_l1_ (u"ࠨษ็ุ้๊ำๅࠩ௟"))
		title = title.replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢไ๎้๋ࠧ௠"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ௡"))
		title = title.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊แ๋ๆ่ࠫ௢"),l1l111_l1_ (u"ࠬอไโ์็้ࠬ௣"))
		title = title.replace(l1l111_l1_ (u"࠭ๅษษืีฮࠦใ้ษ็๎ฯ๐ࠧ௤"),l1l111_l1_ (u"ࠧࠨ௥"))
		title = title.replace(l1l111_l1_ (u"ࠨ฻ส่๏ฯฺࠠๆ์ࠤฬู๊าสࠪ௦"),l1l111_l1_ (u"ࠩࠪ௧"))
		title = title.replace(l1l111_l1_ (u"ู้ࠪอ็ะห้ࠣออิาหࠪ௨"),l1l111_l1_ (u"ࠫࠬ௩"))
		title = title.replace(l1l111_l1_ (u"ࠬอ่็ࠢ็ห๏์ࠧ௪"),l1l111_l1_ (u"࠭ࠧ௫"))
		title = title.replace(l1l111_l1_ (u"ࠧศ๊้่ฬ๐ๆࠨ௬"),l1l111_l1_ (u"ࠨࠩ௭"))
		title = title.replace(l1l111_l1_ (u"ࠩหะํีษࠡ฻ส่๏ฯࠧ௮"),l1l111_l1_ (u"ࠪࠫ௯"))
		title = title.replace(l1l111_l1_ (u"ࠫั๎ฯสࠢ฼ห้๐ษࠨ௰"),l1l111_l1_ (u"ࠬ࠭௱"))
		title = title.replace(l1l111_l1_ (u"࠭ศะ๊้ࠤฯำๅ๋ๆࠪ௲"),l1l111_l1_ (u"ࠧࠨ௳"))
		title = title.replace(l1l111_l1_ (u"ࠨ฻็ํࠥอไฺำหࠫ௴"),l1l111_l1_ (u"ࠩࠪ௵"))
		title = title.replace(l1l111_l1_ (u"้ࠪออิาหࠪ௶"),l1l111_l1_ (u"ࠫࠬ௷"))
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ௸")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ௹"),l1l111_l1_ (u"ࠧࠡࠩ௺")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ௻"),l1l111_l1_ (u"ࠩࠣࠫ௼"))
		title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ௽")+title
		l1lllllll_l1_ = title
		if l1l111_l1_ (u"ࠫ࠴ࡷ࠯ࠨ௾") in url and (l1l111_l1_ (u"ࠬอไฮๆๅอࠬ௿") in title or l1l111_l1_ (u"࠭วๅฯ็ๆ์࠭ఀ") in title):
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪఁ"),title,re.DOTALL)
			if l1l1lll_l1_: l1lllllll_l1_ = l1l1lll_l1_[0]
		if l1lllllll_l1_ not in l1l1_l1_:
			l1l1_l1_.append(l1lllllll_l1_)
			if l1l111_l1_ (u"ࠨ࠱ࡴ࠳ࠬం") in url and (l1l111_l1_ (u"ࠩส่า๊โสࠩః") in title or l1l111_l1_ (u"ࠪห้ำไใ้ࠪఄ") in title):
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫఅ"),l1lllll_l1_+l1lllllll_l1_,l1ll1ll_l1_,13,l1ll1l_l1_)
				found = True
			elif l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬఆ") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ఇ"),l1lllll_l1_+title,l1ll1ll_l1_,11,l1ll1l_l1_)
				found = True
			else:
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ఈ"),l1lllll_l1_+title,l1ll1ll_l1_,12,l1ll1l_l1_)
				found = True
	if found:
		items = re.findall(l1l111_l1_ (u"ࠨࡶࡶࡧࡤ࠹ࡤࡠࡤࡸࡸࡹࡵ࡮ࠡࡴࡨࡨ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ఉ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1llllll1_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩఊ"),l1lllll_l1_+l1llllll1_l1_,url,11)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫఋ"),headers,True,l1l111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪఌ"))
	l1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡳࡦࡴ࡬ࡩࡸ࠴ࠪࡀࠫࠥࠫ఍"),html,re.DOTALL)
	l1lllll1_l1_ = l111l1_l1_+l1111l1l_l1_[0]
	l1lll_l1_ = l1lll11_l1_(l1lllll1_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧఎ"),headers,True,l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩఏ"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡷࡵ࠳ࡩࡧࡴࡤࡱࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬఐ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡡࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠥࠩ఑"),l1lllll1_l1_,re.DOTALL)
		if l1ll_l1_:
			first = l1ll_l1_[0][0]
			second,l111l111_l1_ = l1ll_l1_[0][1].rsplit(l1l111_l1_ (u"ࠪ࠳ࠬఒ"),1)
			l1llllll_l1_ = second+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬఓ")
			l1llll_l1_.append(l1llllll_l1_)
			l1111111_l1_ = first+l111l111_l1_
		else:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ఔ"),headers,False,l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨక"))
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡵࡧࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨఖ"),l11l1ll1_l1_,re.DOTALL)
			if l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_[0]+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱ࠸ࡻ࠸ࠨగ")
				l1llll_l1_.append(l1lllll1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡄࡲࡼ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪఘ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩఙ"),block,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬచ")
			l1llll_l1_.append(l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫఛ"),url)
	return
def l11111l1_l1_():
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧజ"),headers,True,l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡓࡃࡐࡅࡉࡇࡎ࠮࠳ࡶࡸࠬఝ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࡥࡳࡦࡥࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡲࡥࡧࡶࡢࡧࡴࡴࡴࡦࡰࡷࠦࠬఞ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫట"),block,re.DOTALL)
	year = re.findall(l1l111_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠵ࠧఠ"),str(items),re.DOTALL)
	year = year[0]
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭డ"))+l1l111_l1_ (u"ࠬࠦࠧఢ")+year
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ణ"),l1lllll_l1_+title,url,11)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨత"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩథ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫద"),l1l111_l1_ (u"ࠪ࠯ࠬధ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠦ࠴ࡷ࠯ࠣన") + l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
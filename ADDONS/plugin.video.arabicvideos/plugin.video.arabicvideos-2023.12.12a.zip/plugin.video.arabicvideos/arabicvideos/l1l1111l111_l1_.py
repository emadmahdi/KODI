# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㱵")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧ㱶")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ㱷"),l1l111_l1_ (u"ࠪหุะแิษิฮ่๋้ࠠࠢส่฼๊ศศฬࠪ㱸")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㱹"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭㱺"),l1l111_l1_ (u"࠭ࠧ㱻"),l1l111_l1_ (u"ࠧࠨ㱼"),l1l111_l1_ (u"ࠨࠩ㱽"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㱾"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㱿"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲀"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ㲁"),l1l111_l1_ (u"࠭ࠧ㲂"),459,l1l111_l1_ (u"ࠧࠨ㲃"),l1l111_l1_ (u"ࠨࠩ㲄"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㲅"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲆"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㲇")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬหษฬสฮ๊่ࠥะ์๊ࠣฯ࠭㲈"),l1l11ll_l1_,451,l1l111_l1_ (u"࠭ࠧ㲉"),l1l111_l1_ (u"ࠧࠨ㲊"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ㲋"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲌"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㲍")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ㲎"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠬ࠭㲏"),l1l111_l1_ (u"࠭ࠧ㲐"),l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ㲑"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㲒"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㲓"),l1l111_l1_ (u"ࠪࠫ㲔"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡓࡡࡪࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠫ㲕"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㲖"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨ㲗"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㲘"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㲙")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪ㲚")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㲛"),url,l1l111_l1_ (u"ࠫࠬ㲜"),l1l111_l1_ (u"ࠬ࠭㲝"),l1l111_l1_ (u"࠭ࠧ㲞"),l1l111_l1_ (u"ࠧࠨ㲟"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭㲠"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㲡"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡸࡣࡹࡩࡸࠨࠧ㲢"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㲣"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡒࡦࡥࡨࡲࡹࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ㲤"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ㲥") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㲦"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࠧࡇࡣࡵࡱࡵࡒࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㲧"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"ࠩ࠳ࠫ㲨"),l1l111_l1_ (u"ࠪ࠵ࠬ㲩"),l1l111_l1_ (u"ࠫ࠷࠭㲪")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩ㲫"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭㲬"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ㲭"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ㲮"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ㲯"),l1l111_l1_ (u"ࠪห฿์๊สࠩ㲰"),l1l111_l1_ (u"ࠫศเๆ๋หࠪ㲱"),l1l111_l1_ (u"้ࠬไ๋สࠪ㲲"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ㲳"),l1l111_l1_ (u"่ࠧัสๅࠬ㲴"),l1l111_l1_ (u"ࠨ็หหึอษࠨ㲵"),l1l111_l1_ (u"ࠩ฼ี฻࠭㲶"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ㲷"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ㲸")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠫ㲹") in html and l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠫ㲺") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㲻"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪ㲼"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ㲽"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭㲾"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ู๊ࠫไิๆࠪ㲿") not in title:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㳀"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ㳁") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㳂") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㳃"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳄"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠪࠫ㳅"),l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㳆")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㳇"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㳈"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳉"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ㳊")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㳋"),url,l1l111_l1_ (u"ࠪࠫ㳌"),l1l111_l1_ (u"ࠫࠬ㳍"),l1l111_l1_ (u"ࠬ࠭㳎"),l1l111_l1_ (u"࠭ࠧ㳏"),l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡕࡈࡅࡘࡕࡎࡔ࠯࠴ࡷࡹ࠭㳐"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡆࡥࡹ࡫ࡧࡰࡴࡼࡗࡺࡨࡌࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㳑"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠨ㳒") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠯ࠪ㳓"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"ࠫࠥ࠭㳔"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㳕"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㳖"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳗"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㳘"),url,l1l111_l1_ (u"ࠩࠪ㳙"),l1l111_l1_ (u"ࠪࠫ㳚"),l1l111_l1_ (u"ࠫࠬ㳛"),l1l111_l1_ (u"ࠬ࠭㳜"),l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㳝"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㳞"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ㳟"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㳠"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㳡"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㳢"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㳣"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ㳤")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ㳥"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ㳦"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭㳧"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭㳨"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㳩"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭㳪"),l1l111_l1_ (u"࠭ࠧ㳫"),l1l111_l1_ (u"ࠧࠨ㳬"),l1l111_l1_ (u"ࠨࠩ㳭"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㳮"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㳯"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡘ࡮ࡺ࡬ࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡷ࡮ࡪࡥ࠿ࠩ㳰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ㳱"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㳲")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ㳳")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡐ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩࠣࡵࡨࡰࡦࡸࡹࠣࠩ㳴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ㳵"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ㳶"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ㳷")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"ࠬ࠭㳸")
			else: l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ㳹")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㳺")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㳻")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㳼"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ㳽"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ㳾"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ㳿"),l1l111_l1_ (u"࠭ࠫࠨ㴀"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ㴁")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ䍣")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ䍤")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอๆ้ษ฼ࠤฬ็ไศ็ࠪ䍥"),l1l111_l1_ (u"࠭ฬ้ัสฮࠥอแๅษ่ࠫ䍦")]
def l11l1ll_l1_(mode,url,text):
	if   mode==380: l1lll_l1_ = l1l1l11_l1_()
	elif mode==381: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==382: l1lll_l1_ = PLAY(url)
	elif mode==383: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==389: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䍧"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䍨"),l1l111_l1_ (u"ࠩࠪ䍩"),389,l1l111_l1_ (u"ࠪࠫ䍪"),l1l111_l1_ (u"ࠫࠬ䍫"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䍬"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䍭"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䍮"),l1l111_l1_ (u"ࠨࠩ䍯"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䍰"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䍱")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䍲"),l111l1_l1_,381,l1l111_l1_ (u"ࠬ࠭䍳"),l1l111_l1_ (u"࠭ࠧ䍴"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䍵"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍶"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䍷")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้าว็สํอࠬ䍸"),l111l1_l1_,381,l1l111_l1_ (u"ࠫࠬ䍹"),l1l111_l1_ (u"ࠬ࠭䍺"),l1l111_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ䍻"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䍼"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ䍽"),l1l111_l1_ (u"ࠩࠪ䍾"),l1l111_l1_ (u"ࠪࠫ䍿"),l1l111_l1_ (u"ࠫࠬ䎀"),l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䎁"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎂"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎃"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䎄")+l1lllll_l1_+title,l111l1_l1_,381,l1l111_l1_ (u"ࠩࠪ䎅"),l1l111_l1_ (u"ࠪࠫ䎆"),l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䎇")+str(seq))
	block = l1l111_l1_ (u"ࠬ࠭䎈")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳ࡫ࡤࡰࡴࠥࠫ䎉"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠩ࠰࠭ࡃ࠮ࡧࡳࡪࡦࡨࠫ䎊"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎋"),block,re.DOTALL)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䎌"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䎍"),l1l111_l1_ (u"ࠫࠬ䎎"),9999)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠬอไฤ฻็ํ๋ࠥิศ้าอࠬ䎏"):
			if first:
				title = l1l111_l1_ (u"࠭วๅษไ่ฬ๋ࠠࠨ䎐")+title
				first = False
			else: title = l1l111_l1_ (u"ࠧศๆ่ืู้ไศฬࠣࠫ䎑")+title
		if title not in l11lll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎒"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䎓")+l1lllll_l1_+title,l1ll1ll_l1_,381)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䎔"),url,l1l111_l1_ (u"ࠫࠬ䎕"),l1l111_l1_ (u"ࠬ࠭䎖"),l1l111_l1_ (u"࠭ࠧ䎗"),l1l111_l1_ (u"ࠧࠨ䎘"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ䎙"))
	html = response.content
	if type==l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ䎚"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡧࡲࡤࡪ࠰ࡴࡦ࡭ࡥࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ䎛"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎜"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬࡹࡩࡥࡧࡵࠫ䎝"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠪ䎞"),html,re.DOTALL)
		block = l11llll_l1_[0]
		z = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䎟"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*z)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䎠"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡳ࡭࡫ࡧࡩࡷ࠳࡭ࡰࡸ࡬ࡩࡸ࠳ࡴࡷࡵ࡫ࡳࡼࡹࠢࠩ࠰࠭ࡃ࠮ࡂࡨࡦࡣࡧࡩࡷࡄࠧ䎡"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䎢"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䎣") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄࠧ䎤"),l1l111_l1_ (u"࠭࠼ࡦࡰࡧࡂࡁࡹࡴࡢࡴࡷࡂࠬ䎥"))
		html = html.replace(l1l111_l1_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭䎦"),l1l111_l1_ (u"ࠨ࠾ࡨࡲࡩࡄ࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ䎧"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡹࡧࡲࡵࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡱࡨࡃ࠭䎨"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==2: items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎩"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࠬࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡽࡵ࡬ࡨࡪࡨࡡࡳࠫࠪ䎪"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫ䎫") in url:
				items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䎬"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠧ࠰ࡳࡸࡥࡱ࡯ࡴࡺ࠱ࠪ䎭") in url:
				items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎮"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䎯"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࠩ䎰") in title:
			title = re.findall(l1l111_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡧࡵ࡭ࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎱"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䎲")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂࠧ䎳"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ䎴") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎵"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭䎶") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎷"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧ䎸") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎹"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ䎺") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎻"),l1lllll_l1_+title,l1ll1ll_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䎼"),l1lllll_l1_+title,l1ll1ll_l1_,382,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡓࡥ࡬࡫ࠠࠩ࠰࠭ࡃ࠮ࠦ࡯ࡧࠢࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䎽"),html,re.DOTALL)
	if l11llll_l1_:
		current = l11llll_l1_[0][0]
		last = l11llll_l1_[0][1]
		block = l11llll_l1_[0][2]
		items = re.findall(l1l111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧ䎾"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠫࠬ䎿") or title==last: continue
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䏀"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ䏁")+title,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠧࠨ䏂"),l1l111_l1_ (u"ࠨࠩ䏃"),type)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ䏄")+title+l1l111_l1_ (u"ࠪ࠳ࠬ䏅"),l1l111_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䏆")+last+l1l111_l1_ (u"ࠬ࠵ࠧ䏇"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䏈"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะิࠤฺ็อสࠢࠪ䏉")+last,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠨࠩ䏊"),l1l111_l1_ (u"ࠩࠪ䏋"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䏌"),url,l1l111_l1_ (u"ࠫࠬ䏍"),l1l111_l1_ (u"ࠬ࠭䏎"),l1l111_l1_ (u"࠭ࠧ䏏"),l1l111_l1_ (u"ࠧࠨ䏐"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䏑"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䏒"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,False):
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䏓"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่๊ࠥไไสสีࠥ๎วๅ็หี๊าࠠๆ่฼๋ࠬ䏔"),l1l111_l1_ (u"ࠬ࠭䏕"),9999)
		return
	if l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䏖") in url or l1l111_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ䏗") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠩࠪࡧࡱࡧࡳࡴ࠿ࠪ࡭ࡹ࡫࡭ࠨࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭䏘"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[1]
			l1ll1l11_l1_(l1lllll1_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡨࡲࡡࡴࡵࡀࠫࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠧࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡥࡸࡺࠢࠨࠩࠪ䏙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠬࡴࡵ࡮ࡧࡵࡥࡳࡪ࡯ࠨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠫࠬ䏚"),block,re.DOTALL)
		for l1ll1l_l1_,l1l1lll_l1_,l1ll1ll_l1_,name in items:
			title = l1l1lll_l1_+l1l111_l1_ (u"ࠫࠥࡀࠠࠨ䏛")+name+l1l111_l1_ (u"ࠬࠦวๅฯ็ๆฮ࠭䏜")
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䏝"),l1lllll_l1_+title,l1ll1ll_l1_,382)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䏞"),url,l1l111_l1_ (u"ࠨࠩ䏟"),l1l111_l1_ (u"ࠩࠪ䏠"),l1l111_l1_ (u"ࠪࠫ䏡"),l1l111_l1_ (u"ࠫࠬ䏢"),l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䏣"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䏤"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠨࠩ࡬ࡨࡂ࠭ࡰ࡭ࡣࡼࡩࡷ࠳࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠨࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂ࠮ࠢࡴࡪࡨࡥࡩ࡫ࡲࠣࡾࠪࡴࡦ࡭࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩࠬࠫࠬ࠭䏥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠣࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂ࠭ࡳࡦࡴࡹࡩࡷ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ䏦"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䏧")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䏨")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷ࡫࡭ࡰࡦࡤࡰࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡳ࡯ࡥࡣ࡯࠱ࡨࡲ࡯ࡴࡧࠥࠫ䏩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡥ࡟ࡠࡦ࡯ࡣ࡬ࡪࡲࡪࡸࡨ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䏪"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䏫")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䏬")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䏭"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ䏮"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ䏯"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭䏰"),l1l111_l1_ (u"ࠬ࠱ࠧ䏱"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡵࡀࠫ䏲")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ䏳"))
	return
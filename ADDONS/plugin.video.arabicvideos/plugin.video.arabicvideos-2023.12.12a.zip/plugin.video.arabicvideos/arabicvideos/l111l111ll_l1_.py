# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ␟")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡈࡋࡉࡥࠧ␠")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ู่ࠩฬืูสࠩ␡"),l1l111_l1_ (u"ࠪหาีหࠡษ็ฬึอๅอࠩ␢"),l1l111_l1_ (u"ࠫฬำฯฬࠢส่ฬู๊ศสࠪ␣"),l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ␤"),l1l111_l1_ (u"࠭วฮัฮࠤฬ๊ว฻ษ้ํࠬ␥")]
def l11l1ll_l1_(mode,url,text):
	if   mode==440: l1lll_l1_ = l1l1l11_l1_()
	elif mode==441: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==442: l1lll_l1_ = PLAY(url)
	elif mode==443: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==449: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ␦"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ␧"),l1l111_l1_ (u"ࠩࠪ␨"),l1l111_l1_ (u"ࠪࠫ␩"),l1l111_l1_ (u"ࠫࠬ␪"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ␫"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ␬"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␭"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ␮"),l1l111_l1_ (u"ࠩࠪ␯"),449,l1l111_l1_ (u"ࠪࠫ␰"),l1l111_l1_ (u"ࠫࠬ␱"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ␲"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␳"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ␴")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ␵"),l111l1_l1_,441)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ␶"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ␷"),l1l111_l1_ (u"ࠫࠬ␸"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡣࡲ࡫࡮ࡶࡡࡵ࡭࡬࡮ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭␹"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ␺"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ␻"): continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␼"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ␽")+l1lllll_l1_+title,l1ll1ll_l1_,441)
	return
def l1lll11_l1_(url,l1111ll1_l1_=l1l111_l1_ (u"ࠪࠫ␾")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ␿"),url,l1l111_l1_ (u"ࠬ࠭⑀"),l1l111_l1_ (u"࠭ࠧ⑁"),l1l111_l1_ (u"ࠧࠨ⑂"),l1l111_l1_ (u"ࠨࠩ⑃"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⑄"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⑅"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⑆"),block,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		if l1l111_l1_ (u"ࠬ࠵ࡵࡳ࡮࠲ࠫ⑇") in l1ll1ll_l1_: continue
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ⑈") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑉"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ⑊") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⑋"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⑌"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⑍"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⑎"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⑏"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭⑐")+title,l1ll1ll_l1_,441)
	return
def l1ll1l11_l1_(url):
	data = {l1l111_l1_ (u"ࠨࡘ࡬ࡩࡼ࠭⑑"):1}
	headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⑒"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⑓")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ⑔"),url,data,headers,l1l111_l1_ (u"ࠬ࠭⑕"),l1l111_l1_ (u"࠭ࠧ⑖"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⑗"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡦࡹ࡯࡯ࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭⑘"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨ⑙"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⑚"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⑛"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡯ࡨ࠼࡬ࡱࡦ࡭ࡥࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⑜"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⑝"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ⑞"),l1l111_l1_ (u"ࠨࠩ⑟")).strip(l1l111_l1_ (u"ࠩࠣࠫ①"))
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ②"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	return
def PLAY(url):
	data = {l1l111_l1_ (u"࡛ࠫ࡯ࡥࡸࠩ③"):1}
	headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ④"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ⑤")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ⑥"),url,data,headers,l1l111_l1_ (u"ࠨࠩ⑦"),l1l111_l1_ (u"ࠩࠪ⑧"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⑨"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡽࡡࡵࡥ࡫ࡅࡷ࡫ࡡࡎࡣࡶࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⑩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪ⑪"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ⑫"),l1l111_l1_ (u"ࠧࠨ⑬")).strip(l1l111_l1_ (u"ࠨࠢࠪ⑭"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⑮")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⑯")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯࡯ࡹ࡯ࡳࡦࡪ࠭ࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⑰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴ࠰ࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⑱"),block,re.DOTALL)
		for title,l111l1ll_l1_,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ⑲"),l1l111_l1_ (u"ࠧࠨ⑳"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⑴")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⑵")+l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ⑶")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⑷"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭⑸"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ⑹"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ⑺"),l1l111_l1_ (u"ࠨ࠭ࠪ⑻"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⑼")+search
	l1lll11_l1_(url)
	return
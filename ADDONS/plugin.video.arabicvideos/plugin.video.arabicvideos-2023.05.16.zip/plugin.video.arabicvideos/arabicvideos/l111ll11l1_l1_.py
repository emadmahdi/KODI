# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧᵁ")
menu_name = l1l11l_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭ᵂ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨ็ุหึ฿ษࠨᵃ"),l1l11l_l1_ (u"ࠩสัิัࠠศๆหีฬ๋ฬࠨᵄ"),l1l11l_l1_ (u"ࠪหาีหࠡษ็ห้฿วษࠩᵅ"),l1l11l_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᵆ"),l1l11l_l1_ (u"ࠬออะอࠣห้อฺศ่์ࠫᵇ")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l111l1_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l111ll_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᵈ"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨᵉ"),l1l11l_l1_ (u"ࠨࠩᵊ"),l1l11l_l1_ (u"ࠩࠪᵋ"),l1l11l_l1_ (u"ࠪࠫᵌ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᵍ"))
	html = response.content
	l111l11l1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩᵎ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᵏ"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᵐ"),l1l11l_l1_ (u"ࠨࠩᵑ"),449,l1l11l_l1_ (u"ࠩࠪᵒ"),l1l11l_l1_ (u"ࠪࠫᵓ"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵔ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵕ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᵖ")+menu_name+l1l11l_l1_ (u"ࠧศๆิส๏ู๊สࠩᵗ"),l11lll_l1_,441)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᵘ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᵙ"),l1l11l_l1_ (u"ࠪࠫᵚ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡢࡱࡪࡴࡵࡠࡴ࡬࡫࡭ࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᵛ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᵜ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1111l_l1_==l1l11l_l1_ (u"࠭ࠣࠨᵝ"): continue
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᵞ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᵟ")+menu_name+title,l1111l_l1_,441)
	return
def l111l1_l1_(url,l1l111ll_l1_=l1l11l_l1_ (u"ࠩࠪᵠ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᵡ"),url,l1l11l_l1_ (u"ࠫࠬᵢ"),l1l11l_l1_ (u"ࠬ࠭ᵣ"),l1l11l_l1_ (u"࠭ࠧᵤ"),l1l11l_l1_ (u"ࠧࠨᵥ"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᵦ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫᵧ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠴ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᵨ"),block,re.DOTALL)
	for l1111l_l1_,title,img in items:
		if l1l11l_l1_ (u"ࠫ࠴ࡻࡲ࡭࠱ࠪᵩ") in l1111l_l1_: continue
		elif l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧᵪ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᵫ"),menu_name+title,l1111l_l1_,443,img)
		elif l1l11l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪᵬ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵭ"),menu_name+title,l1111l_l1_,443,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᵮ"),menu_name+title,l1111l_l1_,442,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᵯ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᵰ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵱ"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬᵲ")+title,l1111l_l1_,441)
	return
l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࡦࡲ࡬ࡕ࡫ࡷࡰࡪࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡶࡪࡦࡨࡳࡑࡏࡓࡕࠢࡀࠤࡠ࠭ๅีษ๊ำฮ࠭ࠬࠨใํ่๊࠭ࠬࠨษ฽๊๏ฯࠧ࠭ࠩๆ่๏ฮࠧ࠭ࠩส฽้อๆࠨ࠮๋ࠪิอแࠨ࠮้ࠪออัศหࠪ࠰ࠬ฿ัืࠩ࠯๊ࠫํัอษ้ࠫ࠱࠭วๅส๋้ࠬࡣࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦ࠮࡬ࡱ࡬ࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡻ࡮ࡦࡵࡦࡥࡵ࡫ࡈࡕࡏࡏࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨ࡭࡫ࡱ࡯࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭࠯ࠨࠫࠍࠍࠎ࡫ࡰࡪࡵࡲࡨࡪࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ࠯ࡸ࡮ࡺ࡬ࡦ࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡦࡴࡹࠩࡸࡤࡰࡺ࡫ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦࠢࡩࡳࡷࠦࡶࡢ࡮ࡸࡩࠥ࡯࡮ࠡࡸ࡬ࡨࡪࡵࡌࡊࡕࡗ࠭࠿ࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡸ࡬ࡨࡪࡵࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠶࠱࡯࡭ࡨࠫࠍࠍࠎ࡫࡬ࡪࡨࠣࡩࡵ࡯ࡳࡰࡦࡨࠤࡦࡴࡤࠡࠩส่า๊โสࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫࡤࡓࡏࡅࡡࠪࠤ࠰ࠦࡥࡱ࡫ࡶࡳࡩ࡫࡛࠱࡟ࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࠡࡰࡲࡸࠥ࡯࡮ࠡࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶ࠾ࠏࠏࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠸࠲ࡩ࡮ࡩࠬࠎࠎࠏࠉࠊࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࠬ࠵ࡡࡴࡵࡨࡱࡧࡲࡹ࠰ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠶࠲ࡩ࡮ࡩࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠵࠶࠶࠰࡮ࡳࡧࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠹ࠬࡪ࡯ࡪ࠭ࠏࠏࡩࡧࠢࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࡂ࠭ࠧ࠻ࠌࠌࡶࡪࡺࡵࡳࡰࠍࠦࠧࠨᵳ")
def l111ll_l1_(url):
	data = {l1l11l_l1_ (u"ࠨࡘ࡬ࡩࡼ࠭ᵴ"):1}
	headers = {l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᵵ"):l1l11l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩᵶ")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩᵷ"),url,data,headers,l1l11l_l1_ (u"ࠬ࠭ᵸ"),l1l11l_l1_ (u"࠭ࠧᵹ"),l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᵺ"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡶࡩࡦࡹ࡯࡯ࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ᵻ"),html,re.DOTALL)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨᵼ"),html,re.DOTALL)
	# l111l111l_l1_
	if l11111l1l_l1_:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᵽ"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵾ"),menu_name+title,l1111l_l1_,443,img)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠬࠨ࡯ࡨ࠼࡬ࡱࡦ࡭ࡥࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᵿ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᶀ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪᶁ"),l1l11l_l1_ (u"ࠨࠩᶂ")).strip(l1l11l_l1_ (u"ࠩࠣࠫᶃ"))
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᶄ"),menu_name+title,l1111l_l1_,442,img)
	return
def PLAY(url):
	data = {l1l11l_l1_ (u"࡛ࠫ࡯ࡥࡸࠩᶅ"):1}
	headers = {l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᶆ"):l1l11l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᶇ")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬᶈ"),url,data,headers,l1l11l_l1_ (u"ࠨࠩᶉ"),l1l11l_l1_ (u"ࠩࠪᶊ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᶋ"))
	html = response.content
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡽࡡࡵࡥ࡫ࡅࡷ࡫ࡡࡎࡣࡶࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᶌ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪᶍ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩᶎ"),l1l11l_l1_ (u"ࠧࠨᶏ")).strip(l1l11l_l1_ (u"ࠨࠢࠪᶐ"))
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᶑ")+title+l1l11l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᶒ")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡪ࡯࡯ࡹ࡯ࡳࡦࡪ࠭ࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᶓ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࠨࡳࡦࡴ࠰ࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᶔ"),block,re.DOTALL)
		for title,l1l1l111_l1_,l1111l_l1_ in items:
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩᶕ"),l1l11l_l1_ (u"ࠧࠨᶖ"))
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᶗ")+title+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᶘ")+l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨᶙ")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᶚ"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᶛ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧᶜ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨᶝ"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪᶞ"),l1l11l_l1_ (u"ࠩ࠮ࠫᶟ"))
	#search = unescapeHTML(search)
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨᶠ")+search
	l111l1_l1_(url)
	return
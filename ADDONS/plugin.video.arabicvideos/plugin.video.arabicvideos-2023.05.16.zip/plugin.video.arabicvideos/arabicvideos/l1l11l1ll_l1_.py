# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ๒")
headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ๓"):l1l11l_l1_ (u"ࠧࠨ๔")}
menu_name = l1l11l_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧ๕")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ๖"),l1l11l_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪ๗"),l1l11l_l1_ (u"๊ࠫ฻วา฻๊ࠫ๘"),l1l11l_l1_ (u"ࠬอูๅ่้ࠣ฾์วࠡ⠕ࠣࡊࡴࡸࠠࡢࡦࡶࠫ๙"),l1l11l_l1_ (u"࠭ๅ้สส๎้อสࠨ๚"),l1l11l_l1_ (u"ࠧษำส้ัࠦใๆสํ์ฯืࠧ๛"),l1l11l_l1_ (u"ࠨษ็฽ฬฮࠠไ็ห๎ํะัࠨ๜"),l1l11l_l1_ (u"ࠩสื้อๅ๋ษอࠫ๝"),l1l11l_l1_ (u"ࠪหำื้ࠨ๞"),l1l11l_l1_ (u"ࠫฬ่ำศ็ࠣหำื๊ࠨ๟"),l1l11l_l1_ (u"ࠬอิหำส็ฬะࠧ๠")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l111l1_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l111ll_l1_(url)
	elif mode==254: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭๡")+text)
	elif mode==255: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ๢")+text)
	elif mode==256: results = l1l1l1ll1_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
headers = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ๣"):l1ll1111l_l1_()}
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭๤"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩ๥"),l1l11l_l1_ (u"ࠫࠬ๦"),headers,l1l11l_l1_ (u"ࠬ࠭๧"),l1l11l_l1_ (u"࠭ࠧ๨"),l1l11l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ๩"))
	html = response.content
	#l1l1ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ๪"),html,re.DOTALL)
	#if l1l1ll11_l1_: l1l1ll11_l1_ = SERVER(l1l1ll11_l1_[0],l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭๫"))
	#else: l1l1ll11_l1_ = l11lll_l1_
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๬"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ๭"),l1l11l_l1_ (u"ࠬ࠭๮"),259,l1l11l_l1_ (u"࠭ࠧ๯"),l1l11l_l1_ (u"ࠧࠨ๰"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ๱"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ๲"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭๳"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬ๴"),254)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ๵"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ๶"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨ๷"),255)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭๸"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ๹"),l1l11l_l1_ (u"ࠪࠫ๺"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ๻"),menu_name+l1l11l_l1_ (u"ࠬอไๆ็ํึฮ࠭๼"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ๽"),251,l1l11l_l1_ (u"ࠧࠨ๾"),l1l11l_l1_ (u"ࠨࠩ๿"),l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩ຀"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪກ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ຂ")+menu_name+l1l11l_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ຃"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬຄ"),251,l1l11l_l1_ (u"ࠧࠨ຅"),l1l11l_l1_ (u"ࠨࠩຆ"),l1l11l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ງ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪຈ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ຉ")+menu_name+l1l11l_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫຊ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ຋"),251,l1l11l_l1_ (u"ࠧࠨຌ"),l1l11l_l1_ (u"ࠨࠩຍ"),l1l11l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨຎ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪຏ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ຐ")+menu_name+l1l11l_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬຑ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡭ࡣࡷࡩࡸࡺࠧຒ"),251,l1l11l_l1_ (u"ࠧࠨຓ"),l1l11l_l1_ (u"ࠨࠩດ"),l1l11l_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪຕ"))
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡪࡴࡵࡉࡧࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬຖ"),html,re.DOTALL)
	l1l11l1l_l1_ = l1ll1l1ll_l1_[0]
	l1l111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ທ"),l1l11l1l_l1_,re.DOTALL)
	for l1111l_l1_,title in l1l111l1l_l1_:
		title = unescapeHTML(title)
		if title not in l1llll1_l1_ and title!=l1l11l_l1_ (u"ࠬ࠭ຘ"):
			if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫນ") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠧ࠰ࠩບ")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬປ")),l11lll_l1_)
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩຜ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬຝ")+menu_name+title,l1111l_l1_,256)
	return html
def l1l1l1ll1_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬພ"),l1l11l_l1_ (u"ࠬ࠭ຟ"),l1l11l_l1_ (u"࠭ࡓࡖࡄࡐࡉࡓ࡛ࠠࠡࠢࠣࠤࠬຠ")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫມ"),url,l1l11l_l1_ (u"ࠨࠩຢ"),headers,l1l11l_l1_ (u"ࠩࠪຣ"),l1l11l_l1_ (u"ࠪࠫ຤"),l1l11l_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫລ"))
	html = response.content
	if l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠧ຦") in html: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ວ"),menu_name+l1l11l_l1_ (u"ࠧศๆฦ็ะืࠠๆึส๋ิฯࠧຨ"),url,251,l1l11l_l1_ (u"ࠨࠩຩ"),l1l11l_l1_ (u"ࠩࠪສ"),l1l11l_l1_ (u"ࠪࡱࡴࡹࡴࠨຫ"))
	if l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒࡧࡩ࡯ࡕ࡯࡭ࡩ࡫ࡳࠨຬ") in html: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬອ"),menu_name+l1l11l_l1_ (u"࠭วๅ็่๎ืฯࠧຮ"),url,251,l1l11l_l1_ (u"ࠧࠨຯ"),l1l11l_l1_ (u"ࠨࠩະ"),l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫັ"))
	if l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠭າ") in html:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪຳ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			if len(l1ll111_l1_)>1 and type==l1l11l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫິ"): block = l1ll111_l1_[1]
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧີ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title2 = re.findall(l1l11l_l1_ (u"ࠧ࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨຶ"),title,re.DOTALL)
				try: tt1 = title2[0][0]
				except: tt1 = l1l11l_l1_ (u"ࠨࠩື")
				try: tt2 = title2[0][1]
				except: tt2 = l1l11l_l1_ (u"ຸࠩࠪ")
				title2 = tt1+tt2
				title2 = title2.replace(l1l11l_l1_ (u"ࠪࡠࡳູ࠭"),l1l11l_l1_ (u"຺ࠫࠬ"))
				#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭ົ"),str(title2))
				if l1l11l_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠨຼ") in title:
					title2 = re.findall(l1l11l_l1_ (u"ࠧ࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫຽ"),title,re.DOTALL)
					title2 = title2[0]
				if not title2:
					title2 = re.findall(l1l11l_l1_ (u"ࠨࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭຾"),title,re.DOTALL)
					title2 = title2[0]
				else:
					if l1l11l_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ຿") in l1111l_l1_: type = l1111l_l1_.split(l1l11l_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨເ"))[1]
					else: type = l1l11l_l1_ (u"ࠫࡳ࡫ࡷࡦࡵࡷࠫແ")
					#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠬ࠵ࠧໂ")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪໃ")),l11lll_l1_)
					title2 = title2.strip(l1l11l_l1_ (u"ࠧࠡࠩໄ"))
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໅"),menu_name+title2,l1111l_l1_,251,l1l11l_l1_ (u"ࠩࠪໆ"),l1l11l_l1_ (u"ࠪࠫ໇"),type)
	return
def l111l1_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"່ࠫࠬ"),l1l11l_l1_ (u"້ࠬ࠭"),l1l11l_l1_ (u"࠭ࡔࡊࡖࡏࡉࡘ໊ࠦࠠࠡࠢࠣࠫ")+type,url)
	method,data,items = l1l11l_l1_ (u"ࠧࡈࡇࡗ໋ࠫ"),l1l11l_l1_ (u"ࠨࠩ໌"),[]
	if type==l1l11l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪໍ"):
		if l1l11l_l1_ (u"ࠪࡃࠬ໎") in url:
			method2,data2 = l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ໏"),{}
			url2,l1l1l1lll_l1_ = url.split(l1l11l_l1_ (u"ࠬࡅࠧ໐"))
			lines = l1l1l1lll_l1_.split(l1l11l_l1_ (u"࠭ࠦࠨ໑"))
			for line in lines:
				key,value = line.split(l1l11l_l1_ (u"ࠧ࠾ࠩ໒"))
				data2[key] = value
			if lines: method,url,data = method2,url2,data2
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l1l11l_l1_ (u"ࠨࠩ໓"),l1l11l_l1_ (u"ࠩࠪ໔"),l1l11l_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ໕"))
	html = response.content
	#html = html[99000:]
	if type==l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ໖"): l1ll111_l1_ = [html]
	elif l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ໗") in type: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡢ࡫ࡱࡗࡱ࡯ࡤࡦࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪ໘"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ໙"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨฮา๎ิࠦวๅษไ่ฬ๋࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ໚"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ໛"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วห࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵࡍࡳ࡙ࡥࡤࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪໜ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠫࡲࡵࡳࡵࠩໝ"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠧໞ"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡂ࡭ࡱࡦ࡯ࡸ࠳ࡕࡍࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡂࡤࡲࡉࡱ࡙ࡥࡦࡦࠥࠫໟ"),html,re.DOTALL)
	if l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ໠") in type:
		block = l1ll111_l1_[0]
		zz = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭࡭ࡣࡽࡽ࠳࠰࠿ࠡࠪࡶࡶࡨࢂࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࠬࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ໡"),block,re.DOTALL)
		if zz:
			l1ll1l1l_l1_,l1l1lll_l1_,l1l1ll1ll_l1_,l1ll11l11_l1_ = zip(*zz)
			items = zip(l1ll1l1l_l1_,l1ll11l11_l1_,l1l1lll_l1_)
	else:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࡄࡶࡪࡧ࠮ࠫࡁࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡠࡼࢁ࠳࠭࠷ࢀࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭໢"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for l1111l_l1_,img,title in items:
		if l1l11l_l1_ (u"࡛ࠪ࡜ࡋࠧ໣") in title: continue
		#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠫ࠴࠭໤")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ໥")),l11lll_l1_)
		#img = img.rstrip(l1l11l_l1_ (u"࠭࠯ࠨ໦")).replace(SERVER(img,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ໧")),l11lll_l1_)
		title = unescapeHTML(title)
		if l1l11l_l1_ (u"ࠨษ็ั้่ษࠨ໨") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ໩"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ໪") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					l1l1l11_l1_.append(title)
					addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ໫"),menu_name+title,l1111l_l1_,253,img)
			else: addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ໬"),menu_name+title,l1111l_l1_,252,img)
		elif l1l11l_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ໭") in l1111l_l1_ or l1l11l_l1_ (u"ࠧๆี็ื้࠭໮") in title:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໯"),menu_name+title,l1111l_l1_,253,img)
		else:
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ໰"),menu_name+title,l1111l_l1_,252,img)
	if type in [l1l11l_l1_ (u"ࠪࡲࡪࡽࡥࡴࡶࠪ໱"),l1l11l_l1_ (u"ࠫࡧ࡫ࡳࡵࠩ໲"),l1l11l_l1_ (u"ࠬࡳ࡯ࡴࡶࠪ໳")]:
		items = re.findall(l1l11l_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡳࡻ࡭ࡣࡧࡵࡷࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ໴"),html,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໵"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧ໶")+title,l1111l_l1_,251,l1l11l_l1_ (u"ࠩࠪ໷"),l1l11l_l1_ (u"ࠪࠫ໸"),type)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ໹"),url,l1l11l_l1_ (u"ࠬ࠭໺"),headers,l1l11l_l1_ (u"࠭ࠧ໻"),l1l11l_l1_ (u"ࠧࠨ໼"),l1l11l_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ໽"))
	html = response.content
	#items = re.findall(l1l11l_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡕ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ໾"),html,re.DOTALL)
	# the first 10000 character of the html file is l1l1l11ll_l1_ l1l1lll11_l1_ in l1l1llll1_l1_ .. it l1l1ll1l1_l1_ l1l1l111l_l1_
	html = html[10000:]
	items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭໿"),html,re.DOTALL)
	if not items: return
	img,name = items[0]
	if l1l11l_l1_ (u"ࠫฬ๊อๅไฬࠫༀ") in name: name = name.split(l1l11l_l1_ (u"ࠬอไฮๆๅอࠬ༁"))[0].strip(l1l11l_l1_ (u"࠭ࠠࠨ༂"))
	elif l1l11l_l1_ (u"ࠧฮๆๅอࠬ༃") in name: name = name.split(l1l11l_l1_ (u"ࠨฯ็ๆฮ࠭༄"))[0].strip(l1l11l_l1_ (u"ࠩࠣࠫ༅"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷࡋࡰࡪࡵࡲࡨࡪࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ༆"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭༇"),block,re.DOTALL)
		for l1111l_l1_,l1ll1ll_l1_ in items:
			title = name+l1l11l_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡำๅ้ࠥ࠭༈")+l1ll1ll_l1_
			#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"࠭࠯ࠨ༉")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ༊")),l11lll_l1_)
			#img = img.rstrip(l1l11l_l1_ (u"ࠨ࠱ࠪ་")).replace(SERVER(img,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭༌")),l11lll_l1_)
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ།"),menu_name+title,l1111l_l1_,252,img)
	else: addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ༎"),menu_name+l1l11l_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ༏"),url,252,img)
	return
def l1l11l111_l1_(title,l1111l_l1_):
	title2 = re.findall(l1l11l_l1_ (u"࡛࠭ࡢ࠯ࡽࡅ࠲ࡠ࠭࡞࠭ࠪ༐"),title,re.DOTALL)
	if title2: title = title2[0]
	else: title = title+l1l11l_l1_ (u"ࠧࠡࠩ༑")+SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠨࡰࡤࡱࡪ࠭༒"))
	title = title.replace(l1l11l_l1_ (u"ࠩ฼ีอࠦำ๋ัࠪ༓"),l1l11l_l1_ (u"ࠪࠫ༔")).replace(l1l11l_l1_ (u"๊ࠫฮวีำࠪ༕"),l1l11l_l1_ (u"ࠬ࠭༖")).replace(l1l11l_l1_ (u"࠭ๅีษ๊ำฮ࠭༗"),l1l11l_l1_ (u"ࠧࠨ༘"))
	title = title.replace(l1l11l_l1_ (u"ࠨ๏༙ࠪ"),l1l11l_l1_ (u"ࠩࠪ༚"))
	title = title.replace(l1l11l_l1_ (u"ࠪࠤࠥ࠭༛"),l1l11l_l1_ (u"ࠫࠥ࠭༜")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ༝"),l1l11l_l1_ (u"࠭ࠠࠨ༞"))
	return title
def PLAY(url):
	# l11l11l_l1_://l1l11l1l1_l1_.l1l1l1l1l_l1_/فيلم-l1l11llll_l1_-for-l1l111lll_l1_-l1l1111ll_l1_-2022-مترجم/
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ༟"),url,l1l11l_l1_ (u"ࠨࠩ༠"),headers,l1l11l_l1_ (u"ࠩࠪ༡"),l1l11l_l1_ (u"ࠪࠫ༢"),l1l11l_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ༣"))
	html = response.content
	l1l111ll1_l1_,l1l1ll11l_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠬ࠭༤"),l1l11l_l1_ (u"࠭ࠧ༥"),[]
	# l1l1l1111_l1_ & download l1l1l1ll_l1_
	l1ll111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡺࡥࡹࡩࡨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱࠮ࡄ࠯ࠢࠨ༦"),html,re.DOTALL)
	if l1ll111ll_l1_: l1l111ll1_l1_,type1,l1l1ll11l_l1_,l1l1ll111_l1_ = l1ll111ll_l1_[0]
	else:
		l1ll111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡂࡶࡶࡷࡳࡳࡹࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ༧"),html,re.DOTALL)
		if l1ll111ll_l1_:
			l1111l_l1_,type1 = l1ll111ll_l1_[0]
			if l1l11l_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ༨") in type1: l1l111ll1_l1_ = l1111l_l1_
			else: l1l1ll11l_l1_ = l1111l_l1_
	server = SERVER(url,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ༩"))
	#headers = {l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ༪"):server,l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ༫"):l1ll1111l_l1_()}
	headers[l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ༬")] = server
	if l1l111ll1_l1_:
		# l1l1l1111_l1_ l1l1lll1_l1_
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ༭"),l1l111ll1_l1_,l1l11l_l1_ (u"ࠨࠩ༮"),headers,l1l11l_l1_ (u"ࠩࠪ༯"),l1l11l_l1_ (u"ࠪࠫ༰"),l1l11l_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ༱"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡩࡷࡇࡲࡦࡣࠥࠬ࠳࠰࠿࠽࠱ࡸࡰࡃ࠯ࠧ༲"),html,re.DOTALL)
		if l1ll111_l1_:
			l1l111111_l1_ = l1ll111_l1_[0]
			l1l111111_l1_ = l1l111111_l1_.replace(l1l11l_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ༳"),l1l11l_l1_ (u"ࠧ࠽ࡪ࠶ࡂࠬ༴"))
			l1l111111_l1_ = l1l111111_l1_.replace(l1l11l_l1_ (u"ࠨ࠾࡫࠷ࡃ༵࠭"),l1l11l_l1_ (u"ࠩ࠿࡬࠸ࡄ࠼ࡩ࠵ࡁࠫ༶"))
			l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀ࡭࠹࠾࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼ࡩ࠵ࡁ༷ࠫ"),l1l111111_l1_,re.DOTALL)
			for l1l1l111_l1_,block in l1l1l1_l1_:
				items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ༸"),block,re.DOTALL)
				for l1111l_l1_,name in items:
					#name = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠬ࡮࡯ࡴࡶ༹ࠪ"))
					l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ༺")+name+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࡠࡡࡢࡣࠬ༻")+l1l1l111_l1_
					l1ll1l1l_l1_.append(l1111l_l1_)
		# l1l11111l_l1_ l1111l_l1_
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ༼"),html,re.DOTALL)
		if not l1l1lll1_l1_: l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࡎ࡬ࡲࡢ࡯ࡨࠦ࠳࠰࠿ࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡋࡉࡎࡍࡈࡕ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ༽"),html,re.DOTALL)
		if l1l1lll1_l1_:
			l1111l_l1_,l1l1l111_l1_ = l1l1lll1_l1_[0]
			name = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠪࡲࡦࡳࡥࠨ༾"))
			if l1l11l_l1_ (u"ࠫࠪ࠭༿") in l1l1l111_l1_: l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ཀ")+name+l1l11l_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩཁ")
			else: l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨག")+name+l1l11l_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࡡࡢࡣࡤ࠭གྷ")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	if l1l1ll11l_l1_:
		# download l1l1lll1_l1_
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ང"),l1l1ll11l_l1_,l1l11l_l1_ (u"ࠪࠫཅ"),headers,l1l11l_l1_ (u"ࠫࠬཆ"),l1l11l_l1_ (u"ࠬ࠭ཇ"),l1l11l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ཈"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡅࡱࡺࡲࡱࡵࡡࡥࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭ཉ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨཊ"),block,re.DOTALL)
			for l1111l_l1_,title,l1l1l111_l1_ in items:
				if not l1111l_l1_: continue
				# l1l1l1l11_l1_ l1l1111l1_l1_ by l1l11l11l_l1_ .. it l1l1lll1l_l1_ a l1l11ll1l_l1_ from l1l11l11l_l1_ l1ll11l1l_l1_
				if l1l11l_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩཋ") in l1111l_l1_: continue
				l1111l_l1_ = UNQUOTE(l1111l_l1_)
				#title = l1l11l111_l1_(title,l1111l_l1_)
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫཌ")+title+l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬཌྷ")+l1l1l111_l1_
				l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪཎ"), l1ll1l1l_l1_)
	l1l11ll11_l1_ = str(l1ll1l1l_l1_)
	l1lll1_l1_ = [l1l11l_l1_ (u"࠭࠮ࡻ࡫ࡳࡃࠬཏ"),l1l11l_l1_ (u"ࠧ࠯ࡴࡤࡶࡄ࠭ཐ"),l1l11l_l1_ (u"ࠨ࠰ࡷࡼࡹࡅࠧད"),l1l11l_l1_ (u"ࠩ࠱ࡴࡩ࡬࠿ࠨདྷ"),l1l11l_l1_ (u"ࠪ࠲ࡹࡧࡲࡀࠩན"),l1l11l_l1_ (u"ࠫ࠳࡯ࡳࡰࡁࠪཔ"),l1l11l_l1_ (u"ࠬ࠴ࡺࡪࡲ࠱ࠫཕ"),l1l11l_l1_ (u"࠭࠮ࡳࡣࡵ࠲ࠬབ"),l1l11l_l1_ (u"ࠧ࠯ࡶࡻࡸ࠳࠭བྷ"),l1l11l_l1_ (u"ࠨ࠰ࡳࡨ࡫࠴ࠧམ"),l1l11l_l1_ (u"ࠩ࠱ࡸࡦࡸ࠮ࠨཙ"),l1l11l_l1_ (u"ࠪ࠲࡮ࡹ࡯࠯ࠩཚ")]
	if any(value in l1l11ll11_l1_ for value in l1lll1_l1_):
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬཛ"),l1l11l_l1_ (u"ࠬ࠭ཛྷ"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩཝ"),l1l11l_l1_ (u"ࠧอำหࠤึอศุ่ࠢาฯ๊แࠡๆฦ๊ࠥํะศࠢส่ึอศุࠢ็๎ุࠦๅ็้ࠢ์฾ࠦวๅำ๋หอ฽ࠠศๆอ๎ࠥ็๊่ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡ࠰࠱ࠤ้ษๆ้ࠡำหࠥอไๆ๊ๅ฽ࠥ็๊่ࠢัำ๊อสࠡลัี๎ฺ๋ࠦำ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪཞ"))
		return
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧཟ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠩࠣࠫའ"),l1l11l_l1_ (u"ࠪ࠯ࠬཡ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡬ࡩ࡯ࡦ࠲ࡃ࡫࡯࡮ࡥ࠿ࠪར")+search
	l111l1_l1_(url,l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬལ"))
	return
def l1l1l1l_l1_(url,filter):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧཤ"),l1l11l_l1_ (u"ࠧࠨཥ"),filter,url)
	#headers2 = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩས"):url,l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ཧ"):l1l11l_l1_ (u"ࠪࠫཨ")}
	#headers2 = l1l11l_l1_ (u"ࠫࠬཀྵ")
	#filter = filter.replace(l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧཪ"),l1l11l_l1_ (u"࠭ࠧཫ"))
	if l1l11l_l1_ (u"ࠧࡀࡁࠪཬ") in url: url = url.split(l1l11l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ཭"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭཮"),1)
	if filter==l1l11l_l1_ (u"ࠪࠫ཯"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠫࠬ཰"),l1l11l_l1_ (u"ཱࠬ࠭")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"࠭࡟ࡠࡡིࠪ"))
	if type==l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖཱིࠫ"):
		if l1ll11ll1_l1_[0]+l1l11l_l1_ (u"ࠨ࠿ࡀུࠫ") not in l1lllll1_l1_: category = l1ll11ll1_l1_[0]
		for i in range(len(l1ll11ll1_l1_[0:-1])):
			if l1ll11ll1_l1_[i]+l1l11l_l1_ (u"ࠩࡀࡁཱུࠬ") in l1lllll1_l1_: category = l1ll11ll1_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭ྲྀ")+category+l1l11l_l1_ (u"ࠫࡂࡃ࠰ࠨཷ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨླྀ")+category+l1l11l_l1_ (u"࠭࠽࠾࠲ࠪཹ")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠨེࠪ"))+l1l11l_l1_ (u"ࠨࡡࡢࡣཻࠬ")+l11l111_l1_.strip(l1l11l_l1_ (u"ོࠩࠩࠪࠬ"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸཽ࠭"))
		url2 = url+l1l11l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪཾ")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ཿ"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨྀ"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠧࠨཱྀ"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫྂ"))
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠩࠪྃ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀ྄ࠩ")+l1llll1l_l1_
		l11l1ll1_l1_ = l1l1l11l1_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ྅"),menu_name+l1l11l_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ྆"),l11l1ll1_l1_,251,l1l11l_l1_ (u"࠭ࠧ྇"),l1l11l_l1_ (u"ࠧࠨྈ"),l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩྉ"))
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩྊ"),menu_name+l1l11l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪྋ")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪྌ"),l11l1ll1_l1_,251,l1l11l_l1_ (u"ࠬ࠭ྍ"),l1l11l_l1_ (u"࠭ࠧྎ"),l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨྏ"))
		addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ྐ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩྑ"),l1l11l_l1_ (u"ࠪࠫྒ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩྒྷ"),url,l1l11l_l1_ (u"ࠬ࠭ྔ"),headers,l1l11l_l1_ (u"࠭ࠧྕ"),l1l11l_l1_ (u"ࠧࠨྖ"),l1l11l_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ྗ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡕࡧࡵࡱࡇ࡚ࡎࡴࠤࠪ྘"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	l1ll11111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡘࡦࡾࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࡌࡸࡪࡳࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬྙ"),block,re.DOTALL)
	l1l1lllll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡗࡧࡴࡪࡰࡪࡊ࡮ࡲࡴࡦࡴࠥ࠲࠯ࡅ࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄ࠮ࠫࡁࠫࡀࡺࡲ࠾ࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬྚ"),block,re.DOTALL)
	l1l1ll1_l1_ = l1ll11111_l1_+l1l1lllll_l1_
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		#if l1l11l_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧྛ") in l1l111l_l1_: continue
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧྜ"),block,re.DOTALL)
		if name==l1l11l_l1_ (u"ࠧศะิํࠬྜྷ"): name = l1l11l_l1_ (u"ࠨษ็ห็ูวๆࠩྞ")
		if not items:
			l1l111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡳࡣࡷࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩྟ"),block,re.DOTALL)
			items = []
			for option,value in l1l111l1l_l1_: items.append([option,l1l11l_l1_ (u"ࠪࠫྠ"),value])
			l1l111l_l1_ = l1l11l_l1_ (u"ࠫࡷࡧࡴࡦࠩྡ")
			name = l1l11l_l1_ (u"ࠬอไหไํ๎๊࠭ྡྷ")
		else: l1l111l_l1_ = items[0][1]
		if l1l11l_l1_ (u"࠭࠽࠾ࠩྣ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫྤ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l1ll11ll1_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨྥ")+l1111l1_l1_)
				return
			else:
				l11l1ll1_l1_ = l1l1l11l1_l1_(url2)
				if l1l111l_l1_==l1ll11ll1_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩྦ"),menu_name+l1l11l_l1_ (u"ࠪห้าๅ๋฻ࠣࠫྦྷ"),l11l1ll1_l1_,251,l1l11l_l1_ (u"ࠫࠬྨ"),l1l11l_l1_ (u"ࠬ࠭ྩ"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧྪ"))
				else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧྫ"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩྫྷ"),url2,254,l1l11l_l1_ (u"ࠩࠪྭ"),l1l11l_l1_ (u"ࠪࠫྮ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬྯ"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨྰ")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽࠾࠲ࠪྱ")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪྲ")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿ࡀ࠴ࠬླ")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ྴ")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྵ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ྶ")+name,url2,255,l1l11l_l1_ (u"ࠬ࠭ྷ"),l1l11l_l1_ (u"࠭ࠧྸ"),l1111l1_l1_)		# +l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩྐྵ"))
		dict[l1l111l_l1_] = {}
		for option,dummy,value in items:
			if option in l1llll1_l1_: continue
			if l1l11l_l1_ (u"ࠨษ็็้࠭ྺ") in option: continue
			option = unescapeHTML(option)
			#if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧྻ") in option: continue
			#if l1l11l_l1_ (u"ࠪࡲ࠲ࡧࠧྼ") in value: continue
			l1l11lll1_l1_,title2 = option,option
			title2 = name+l1l11l_l1_ (u"ࠫ࠿ࠦࠧ྽")+l1l11lll1_l1_
			dict[l1l111l_l1_][value] = title2
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨ྾")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽࠾ࠩ྿")+l1l11lll1_l1_
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪ࿀")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿ࡀࠫ࿁")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭࿂")+l11l111_l1_
			if type==l1l11l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ࿃"):
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿄"),menu_name+title2,url,255,l1l11l_l1_ (u"ࠬ࠭࿅"),l1l11l_l1_ (u"࿆࠭ࠧ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ࿇"))
			elif type==l1l11l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ࿈") and l1ll11ll1_l1_[-2]+l1l11l_l1_ (u"ࠩࡀࡁࠬ࿉") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭࿊"))
				#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ࿋"),l1l11l_l1_ (u"ࠬ࠭࿌"),l1lll1l1_l1_,l11l111_l1_)
				url3 = url+l1l11l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ࿍")+l1lll1l1_l1_
				l11l1ll1_l1_ = l1l1l11l1_l1_(url3)
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿎"),menu_name+title2,l11l1ll1_l1_,251,l1l11l_l1_ (u"ࠨࠩ࿏"),l1l11l_l1_ (u"ࠩࠪ࿐"),l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ࿑"))
			else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿒"),menu_name+title2,url,254,l1l11l_l1_ (u"ࠬ࠭࿓"),l1l11l_l1_ (u"࠭ࠧ࿔"),l1l1111_l1_)
	return
l1ll11ll1_l1_ = [l1l11l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ࿕"),l1l11l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ࿖"),l1l11l_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ࿗")]
l1ll111l1_l1_ = [l1l11l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ࿘"),l1l11l_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ࿙"),l1l11l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ࿚"),l1l11l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ࿛"),l1l11l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ࿜"),l1l11l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ࿝"),l1l11l_l1_ (u"ࠩࡵࡥࡹ࡫ࠧ࿞")]
def l1l1l11l1_l1_(url):
	l1l111l11_l1_ = l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠵࠴࠷࠷࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡉࡱࡰࡩ࠳ࡶࡨࡱࠩ࿟")
	url = url.replace(l1l11l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࠨ࿠"),l1l111l11_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭࿡"),l1l11l_l1_ (u"࠭ࠧ࿢"))
	if l1l111l11_l1_ not in url: url = url+l1l111l11_l1_
	url = url.replace(l1l11l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭࿣"),l1l11l_l1_ (u"ࠨࡻࡨࡥࡷ࠭࿤"))
	url = url.replace(l1l11l_l1_ (u"ࠩࡂࡃࠬ࿥"),l1l11l_l1_ (u"ࠪࡃࠬ࿦"))
	url = url.replace(l1l11l_l1_ (u"ࠫࠫࠬࠧ࿧"),l1l11l_l1_ (u"ࠬࠬࠧ࿨"))
	url = url.replace(l1l11l_l1_ (u"࠭࠽࠾ࠩ࿩"),l1l11l_l1_ (u"ࠧ࠾ࠩ࿪"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ࿫"),l1l11l_l1_ (u"ࠩࠪ࿬"),l1l11l_l1_ (u"ࠪࠫ࿭"),l1l11l_l1_ (u"ࠫࡕࡘࡅࡑࡃࡕࡉࡤࡌࡉࡍࡖࡈࡖࡤࡌࡉࡏࡃࡏࡣ࡚ࡘࡌࠨ࿮"))
	return url
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭࿯"),l1l11l_l1_ (u"࠭ࠧ࿰"),filters,l1l11l_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧ࿱")+mode)
	# mode==l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ࿲")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ࿳")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠪࡥࡱࡲࠧ࿴")					all filters (l1lll111_l1_ l111l1l_l1_ filter)
	filters = filters.strip(l1l11l_l1_ (u"ࠫࠫࠬࠧ࿵"))
	l1llllll_l1_,l11llll_l1_ = {},l1l11l_l1_ (u"ࠬ࠭࿶")
	if l1l11l_l1_ (u"࠭࠽࠾ࠩ࿷") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠧࠧࠨࠪ࿸"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠨ࠿ࡀࠫ࿹"))
			l1llllll_l1_[var] = value
	for key in l1ll111l1_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠩ࠳ࠫ࿺")
		if l1l11l_l1_ (u"ࠪࠩࠬ࿻") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭࿼") and value!=l1l11l_l1_ (u"ࠬ࠶ࠧ࿽"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠠࠬࠢࠪ࿾")+value
		elif mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ࿿") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪက"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬခ")+key+l1l11l_l1_ (u"ࠪࡁࡂ࠭ဂ")+value
		elif mode==l1l11l_l1_ (u"ࠫࡦࡲ࡬ࠨဃ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨင")+key+l1l11l_l1_ (u"࠭࠽࠾ࠩစ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠡ࠭ࠣࠫဆ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠩࠫဇ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪဈ"),l1l11l_l1_ (u"ࠪࠫဉ"),l11llll_l1_,l1l11l_l1_ (u"ࠫࡔ࡛ࡔࠨည"))
	return l11llll_l1_
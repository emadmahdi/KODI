# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪ㲼")
def MAIN(mode,text=l1l11l_l1_ (u"ࠩࠪ㲽")):
	if   mode==  0: l1ll11l1lll1_l1_(text)
	elif mode==  2: l1ll1l1llll1_l1_(text)
	elif mode==  3: l1ll1ll11ll1_l1_()
	elif mode==  4: l1ll1lllll1l_l1_(text)
	elif mode==  5: l1ll11l1l111_l1_()
	elif mode==  6: l1ll1lll1lll_l1_()
	elif mode==  7: l1ll1l11llll_l1_()
	elif mode==  8: l1ll11l11111_l1_()
	elif mode==  9: l1ll11l111l1_l1_()
	elif mode==150: l1ll1ll1lll1_l1_()
	elif mode==151: l1l1ll11llll_l1_()
	elif mode==152: l1ll1l11l11l_l1_()
	elif mode==153: l1lll1l1l1l1_l1_()
	elif mode==154: l1lll1111ll1_l1_()
	elif mode==155: l1ll11ll1l11_l1_()
	elif mode==156: l1l1ll11ll11_l1_()
	elif mode==157: l1ll1llll111_l1_()
	elif mode==158: l1ll1l11l1ll_l1_()
	elif mode==159: l1ll1ll1111l_l1_(True)
	elif mode==170: l1ll1111ll1l_l1_()
	elif mode==171: l1ll1l1ll1l1_l1_()
	elif mode==172: l1lll1l11111_l1_()
	elif mode==173: l1ll1l1l1lll_l1_(l1l11l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ㲾"),True)
	elif mode==174: l1ll1l1l1lll_l1_(l1l11l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ㲿"),True)
	elif mode==175: l1ll11llll1l_l1_()
	elif mode==176: l1ll11111111_l1_()
	elif mode==177: l1lll1111111_l1_(l1l11l_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ㳀"))
	elif mode==178: l1lll1111111_l1_(l1l11l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㳁"))
	elif mode==179: l1lll1111111_l1_(l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧ㳂"))
	elif mode==190: l1ll11l1ll11_l1_()
	elif mode==191: l1l1lll1lll1_l1_()
	elif mode==192: l1ll1111111l_l1_()
	elif mode==193: l1ll1l1lll11_l1_()
	elif mode==194: l1l1lllll1l1_l1_()
	elif mode==195: l1ll111l11ll_l1_()
	elif mode==196: l1ll11l11lll_l1_()
	elif mode==197: l1ll111ll11l_l1_()
	elif mode==198: l1ll1l1ll111_l1_()
	elif mode==199: l1l1lll1l1l1_l1_()
	elif mode==340: l1l1lll11ll1_l1_(text)
	elif mode==341: l1lll11111l1_l1_()
	elif mode==342: l1ll11lll111_l1_()
	elif mode==343: l1ll111ll1l1_l1_()
	elif mode==344: l1lll1111l11_l1_()
	elif mode==345: l1ll1l1l1111_l1_()
	elif mode==346: l1ll1l111l11_l1_()
	elif mode==347: l1ll1lll111l_l1_(True)
	elif mode==348: l1ll1l1ll1ll_l1_()
	elif mode==349: l1ll1ll1llll_l1_(l1ll1l11l11_l1_)
	elif mode==500: l1l1llll111l_l1_()
	elif mode==501: l1l1ll1lll11_l1_()
	elif mode==502: l1ll1l1l1ll1_l1_(l1l11l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ㳃"),True)
	elif mode==503: l1ll1ll1llll_l1_(l1ll111111l_l1_)
	elif mode==504: l1ll1ll1llll_l1_(favoritesfile)
	elif mode==505: l1ll11lll1ll_l1_()
	elif mode==506: FIX_OR_CREATE_ALL_DATABASES(True)
	elif mode==507: l1ll1lllllll_l1_(text,l1l11l_l1_ (u"ࠩࠪ㳄"),True)
	elif mode==508: l1ll1l1ll11l_l1_()
	return
def l1ll1lllllll_l1_(addon_id,function,showDialogs):
	conn = sqlite3.connect(l1ll1ll1ll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1ll11111l11_l1_ = l1l11l_l1_ (u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭㳅")
	else: l1ll11111l11_l1_ = l1l11l_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪ㳆")
	cc.execute(l1l11l_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭㳇")+l1ll11111l11_l1_+l1l11l_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ㳈")+addon_id+l1l11l_l1_ (u"ࠧࠣࠢ࠾ࠫ㳉"))
	rows = cc.fetchall()
	if rows and function in [l1l11l_l1_ (u"ࠨࠩ㳊"),l1l11l_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ㳋")]:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ㳌"),l1l11l_l1_ (u"ࠫࠬ㳍"),l1l11l_l1_ (u"ࠬ࠭㳎"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㳏"),l1l11l_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ㳐")+addon_id+l1l11l_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ㳑"))
		if yes!=1: return
		cc.execute(l1l11l_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨ㳒")+l1ll11111l11_l1_+l1l11l_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ㳓")+addon_id+l1l11l_l1_ (u"ࠫࠧࠦ࠻ࠨ㳔"))
	elif function in [l1l11l_l1_ (u"ࠬ࠭㳕"),l1l11l_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࠧ㳖")]:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࠨ㳗"),l1l11l_l1_ (u"ࠨࠩ㳘"),l1l11l_l1_ (u"ࠩࠪ㳙"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㳚"),l1l11l_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ㳛")+addon_id+l1l11l_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ㳜"))
		if yes!=1: return
		if kodi_version<19: cc.execute(l1l11l_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭㳝")+addon_id+l1l11l_l1_ (u"ࠧࠣࠫࠣ࠿ࠬ㳞"))
		else: cc.execute(l1l11l_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨ㳟")+addon_id+l1l11l_l1_ (u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩ㳠"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l1l11l_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ㳡"))
	time.sleep(1)
	if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㳢"),l1l11l_l1_ (u"ࠬ࠭㳣"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㳤"),l1l11l_l1_ (u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫ㳥"))
	if function in [l1l11l_l1_ (u"ࠨࠩ㳦"),l1l11l_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ㳧")]: l1ll1ll1111l_l1_(showDialogs)
	return
def l1ll11lll1ll_l1_():
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㳨"),l1l11l_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㳩"))
	l1ll1lll11ll_l1_ = l1lll111111l_l1_()
	l1ll11l11l1_l1_ = l1l11l_l1_ (u"ࠬࡢ࡮ࠨ㳪")
	l1lll1l1ll11_l1_ = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㳫")
	l1lll1l1l1ll_l1_ = l1l11l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ㳬")
	for id,l1ll1l11l1l1_l1_,l1ll11ll1l1l_l1_,answer,l1l1ll1ll11l_l1_,reason in reversed(l1ll1lll11ll_l1_):
		if id==l1l11l_l1_ (u"ࠨ࠲ࠪ㳭"):
			l1ll111lllll_l1_,l1lll11l1111_l1_ = answer.split(l1l11l_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㳮"))
			continue
		if l1ll11l11l1_l1_!=l1l11l_l1_ (u"ࠪࡠࡳ࠭㳯"): l1ll11l11l1_l1_ += l1lll1l1l1ll_l1_
		l1llll1llll_l1_ = l1l11l_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㳰")+id+l1l11l_l1_ (u"ࠬࠦ࠺ࠡࠩ㳱")+l1l11l_l1_ (u"࠭วๅีวห้ࠦ࠺ࠡࠩ㳲")+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㳳")+l1ll11ll1l1l_l1_
		l1lllll1111_l1_ = l1l11l_l1_ (u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้า่ศสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㳴")+answer
		l11l11ll1ll_l1_ = l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽รࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㳵")+l1l1ll1ll11l_l1_
		l11l11lll11_l1_ = l1l11l_l1_ (u"ࠪࡠࡳࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิสหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㳶")+reason
		l1ll11l11l1_l1_ += l1llll1llll_l1_+l1lllll1111_l1_+l1l11l_l1_ (u"ࠫࡡࡴࠧ㳷")+l1lll1l1ll11_l1_+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ㳸")+l11l11ll1ll_l1_+l11l11lll11_l1_+l1l11l_l1_ (u"࠭࡜࡯ࠩ㳹")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㳺"),l1lll11l1111_l1_,l1ll11l11l1_l1_,l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㳻"))
	return
def l1ll1ll1llll_l1_(file):
	if file==favoritesfile: l1ll1l11111l_l1_ = l1l11l_l1_ (u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ㳼")
	elif file==l1ll1l11l11_l1_: l1ll1l11111l_l1_ = l1l11l_l1_ (u"ࠪห้ืำศศ็ࠫ㳽")
	elif file==l1ll111111l_l1_: l1ll1l11111l_l1_ = l1l11l_l1_ (u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ㳾")
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬ࠭㳿"),l1l11l_l1_ (u"࠭ࠧ㴀"),l1l11l_l1_ (u"ࠧࠨ㴁"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㴂"),l1l11l_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ศๆࠡวุ่ฬำࠠࠨ㴃")+l1ll1l11111l_l1_+l1l11l_l1_ (u"ࠪࠤฤࠧࠧ㴄"))
	if yes==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㴅"),l1l11l_l1_ (u"ࠬ࠭㴆"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㴇"),l1l11l_l1_ (u"ࠧห็ࠣษฺ๊วฮ่่ࠢๆࠦࠧ㴈")+l1ll1l11111l_l1_)
	return
def l1l1ll1lll11_l1_():
	if kodi_version<18:
		message = l1l11l_l1_ (u"ࠨๆ็วุ็ࠠฤ่อࠤฯูสฯั่ࠤส฻ฯศำࠣ็ํี๊ࠡไา๎๊ࠦัใ็ࠣࠫ㴉")+str(kodi_version)+l1l11l_l1_ (u"ࠩࠣ์้ํะศࠢส่็๎วว็ࠣห้๋ี้ำฬࠤ้อࠠห฻่่ࠥ฿ๆะๅࠣ࠲ࠥํะ่ࠢส่๊๐าสࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲๊ࠥลึๆสัࠥอไๆึๆ่ฮࠦโๆࠢหฮาี๊ฬࠢหี๋อๅอࠢๆ์ิ๐ࠠฦๆ์ࠤส๐ࠠฦืาหึࠦัใ็๊ࠤศ฿ไ๊่๊ࠢࠥ࠷࠸࠯࠲ࠪ㴊")
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㴋"),l1l11l_l1_ (u"ࠫࠬ㴌"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㴍"),message)
		return
	l1l1lll11l1l_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ㴎"))
	l1llll1l1l11_l1_ = l1ll11lll11l_l1_([l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭㴏")])
	l1ll111l111_l1_,l1ll1ll1l1l1_l1_,l1l1ll1l1lll_l1_,l1ll1ll1l1ll_l1_,l1ll1ll11lll_l1_,l1l1lll11l11_l1_,l1ll1ll1l11l_l1_ = l1llll1l1l11_l1_[l1l11l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ㴐")]
	if l1ll111l111_l1_ or l1l11l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ㴑") not in str(l1l1lll11l1l_l1_):
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㴒"),l1l11l_l1_ (u"ࠫࠬ㴓"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㴔"),l1l11l_l1_ (u"࠭วๅไ๋หห๋ࠠศๆู่ํืษࠡฬ฼้้ࠦแใู้ࠣ฾ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥํะ่ࠢส่็๎วว็ࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠫ㴕"))
		succeeded = l1ll1l1l1ll1_l1_(l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭㴖"),True)
		if not succeeded: return
	l1ll1ll11l11_l1_(True)
	return
	l1l11l_l1_ (u"ࠣࠤࠥࠎࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠩࠬࠎࠎ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠶࠷ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้้สศสฬࠫࠏࠏࡥ࡭࡫ࡩࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄ࠾࠿ࠪ࠹࠺࠻ࠧ࠻ࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠤࡂࠦࠧใ๊สส๊ࠦวๅื๋ีࠬࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็้ࠣัํ่ๅหࠪࠎࠎ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠳࠾ࠎࠏࠣࠡࡣࡱࡽࠥࡵࡴࡩࡧࡵࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࠊࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨࠩࠍࠍࠎࠩࡩ࡮ࡲࡲࡶࡹࠦࡳࡲ࡮࡬ࡸࡪ࠹ࠊࠊࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡻ࡯ࡥࡸࡵࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠵࠾࠽࠱࠲࠹ࠣ࠿ࠬ࠯ࠊࠊࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࡶࡪࡧࡺࠦࠥ࡝ࡈࡆࡔࡈࠤࡻ࡯ࡥࡸࡏࡲࡨࡪࠦ࠽ࠡ࠸࠹࠴࠽࠶ࠠ࠼ࠩࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠲࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠹࠺ࠧࠊࠥࠣࠦࡑ࡯ࡳࡵࠢࡈࡱࡦࡪࠢࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࡪࡲࡩࡧࠢࡦ࡬ࡴ࡯ࡣࡦ࠿ࡀ࠶࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥ࠭࠵࠶࠷ࠪࠍࠨࠦࠢࡈࡣ࡯ࡰࡪࡸࡹࡠࡇࡰࡥࡩࠨࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠨ࠮ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠯ࠊࠊࠤࠥࠦ㴗")
def l1ll1ll11l11_l1_(showDialogs=True):
	l1l1lll11l1l_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ㴘"))
	if l1l11l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ㴙") not in str(l1l1lll11l1l_l1_):
		if showDialogs:
			DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㴚"),l1l11l_l1_ (u"ࠬ࠭㴛"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㴜"),l1l11l_l1_ (u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ㴝"))
		return
	l1ll1lll1l1l_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ㴞"),l1l11l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ㴟"),l1l11l_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㴠"),l1l11l_l1_ (u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬ㴡"))
	if not os.path.exists(l1ll1lll1l1l_l1_): return
	oldFILE = open(l1ll1lll1l1l_l1_,l1l11l_l1_ (u"ࠬࡸࡢࠨ㴢")).read()
	if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㴣"))
	l1l1ll1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ㴤"),oldFILE,re.DOTALL)
	l1l1lll1l111_l1_,l1lll1l1l111_l1_ = l1l1ll1l1ll1_l1_[0]
	l1lll111l1l1_l1_ = l1l11l_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ㴥")+l1l1lll1l111_l1_+l1l11l_l1_ (u"ࠩ࠯ࠫ㴦")+l1lll1l1l111_l1_+l1l11l_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ㴧")
	if showDialogs:
		l1lll111lll1_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩ㴨"))
		if l1lll111lll1_l1_==l1l11l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ㴩"): l1lll1111lll_l1_ = l1l11l_l1_ (u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭㴪")
		elif l1lll111lll1_l1_==l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭㴫"): l1lll1111lll_l1_ = l1l11l_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭㴬")
		else: l1lll1111lll_l1_ = l1l11l_l1_ (u"ࠩๅ์ฬฬๅࠡลัี๎࠭㴭")
		choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㴮"),l1l11l_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ㴯"),l1l11l_l1_ (u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ㴰"),l1l11l_l1_ (u"࠭โ้ษษ้ࠥอไึ๊ิࠫ㴱"),l1l11l_l1_ (u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫ㴲")+l1lll1111lll_l1_,l1l11l_l1_ (u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㴳"))
		if choice==1: l1ll11llllll_l1_ = l1l11l_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ㴴")
		elif choice==2: l1ll11llllll_l1_ = l1l11l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ㴵")
		else: l1ll11llllll_l1_ = l1l11l_l1_ (u"ࠫࠬ㴶")
	else:
		l1lll111lll1_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ㴷"))
		if   l1lll111lll1_l1_==l1l11l_l1_ (u"࠭ࠧ㴸"): choice = 0
		elif l1lll111lll1_l1_==l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ㴹"): choice = 1
		elif l1lll111lll1_l1_==l1l11l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ㴺"): choice = 2
		l1ll11llllll_l1_ = l1lll111lll1_l1_
	if   choice==0: l1ll11l1l1l1_l1_ = l1l11l_l1_ (u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭㴻")
	elif choice==1: l1ll11l1l1l1_l1_ = l1l11l_l1_ (u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧ㴼")
	elif choice==2: l1ll11l1l1l1_l1_ = l1l11l_l1_ (u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨ㴽")
	else: return
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ㴾"),l1ll11llllll_l1_)
	l1l1llll1lll_l1_ = l1l11l_l1_ (u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ㴿")+l1ll11l1l1l1_l1_+l1l11l_l1_ (u"ࠧ࠭ࠩ㵀")+l1lll1l1l111_l1_+l1l11l_l1_ (u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ㵁")
	newFILE = oldFILE.replace(l1lll111l1l1_l1_,l1l1llll1lll_l1_)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㵂"))
	open(l1ll1lll1l1l_l1_,l1l11l_l1_ (u"ࠪࡻࡧ࠭㵃")).write(newFILE)
	LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㵄"),l1l11l_l1_ (u"ࠬ࠴ࠠࠡࠢࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫ㵅")+l1ll11l1l1l1_l1_+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ㵆"))
	#time.sleep(2)
	if showDialogs: xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭㵇"))
	return
def l1l1llll111l_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࠩ㵈"),l1l11l_l1_ (u"ࠩๆ่ฬ࠭㵉"),l1l11l_l1_ (u"๊ࠪ฾๋ࠧ㵊"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㵋"),l1l11l_l1_ (u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪ㵌"))
	if yes==1: l1ll1l11llll_l1_()
	return
def l1ll11l11111_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㵍"),l1l11l_l1_ (u"ࠧࠨ㵎"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㵏"),l1l11l_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬ㵐"))
	return
def l1ll1l1ll1ll_l1_():
	l1llll1llll_l1_ = l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㵑")
	l1llll1llll_l1_ += l1l11l_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪ㵒")
	l1llll1llll_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡸ࡮ࡩࡢࡥࡲࡹࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ㵓")
	l1lllll1111_l1_ = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞สิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㵔")
	l1lllll1111_l1_ += l1l11l_l1_ (u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫ㵕")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡮ࡷࡶࡰ࡮ࡳࡲࡶ࡮ࡨࡶࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㵖")
	message = l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ㵗")+l1llll1llll_l1_+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨ㵘")+l1lllll1111_l1_
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㵙"),l1l11l_l1_ (u"ࠬ࠭㵚"),message)
	return
def l1ll1l111l11_l1_():
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㵛"),l1l11l_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㵜"))
	l1ll1lll11ll_l1_ = l1lll111111l_l1_()
	if not l1ll1lll11ll_l1_: return
	id,l1ll1l11l1l1_l1_,l1ll11ll1l1l_l1_,answer,l1l1ll1ll11l_l1_,reason = l1ll1lll11ll_l1_[0]
	l1ll111lllll_l1_,l1lll11l1111_l1_ = answer.split(l1l11l_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㵝"))
	l1lllll1111_l1_,l11l11ll1ll_l1_,l11l11lll11_l1_ = l1l1ll1ll11l_l1_.split(l1l11l_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㵞"))
	l1lll11l1lll_l1_ = l1l1ll1ll1l1_l1_
	stay = True
	while stay:
		l1ll11l111ll_l1_ = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠪࠫ㵟"),l1l11l_l1_ (u"้๊ࠫวฺฬิห฻࠭㵠"),l1l11l_l1_ (u"๊ࠬไฤูไห้࠭㵡"),l1l11l_l1_ (u"࠭ฮา๊ฯࠫ㵢"),l1l11l_l1_ (u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣๆ๊ࠦศๆีะࠤอืๆศ็ฯࠤ฾๋วะ่๊ࠢࠥา็ศิๆࠫ㵣"),l1lllll1111_l1_)
		if l1ll11l111ll_l1_==0:
			yes = DIALOG_OK(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㵤"),l1l11l_l1_ (u"ࠩ฼์ิฯࠧ㵥"),l1l11l_l1_ (u"ࠪห้อูหำสฺࠥ฿ไ๊่ࠢฬิษࠠศๆศ฽้อๆศฬࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬ㵦"),l11l11ll1ll_l1_)
			#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㵧"),l1l11l_l1_ (u"ࠬ฿่ะหࠪ㵨"),l1l11l_l1_ (u"࠭สุ้ํัࠬ㵩"),l1l11l_l1_ (u"ࠧศๆส฽ฯืวืࠢ฼่๎ࠦๅษัฦࠤฬ๊ลฺๆส๊ฬะࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩ㵪"),l11l11ll1ll_l1_)
			#if yes: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㵫"),l1l11l_l1_ (u"ࠩ฼์ิฯࠧ㵬"),l1l11l_l1_ (u"้้ࠪออูษอࠫ㵭"),l11l11lll11_l1_)
		if l1ll11l111ll_l1_==1: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㵮"),l1lll11l1lll_l1_,l1lll11l1lll_l1_,l1l11l_l1_ (u"ࠬอำหะา้ࠥํะศࠢส่ืืࠠๅๆัีําࠠๆ่ࠣหู้ฤศๆࠣฬิ๎ๆࠡวฯหอฯࠠศๆึศฬ๊࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠวํࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ษึฮำีๅ่ࠢ็็๏ࠦสฺำไࠤฬ๊ฬ้ษหࠤฬ๊ีฮ์ะࡠࡳࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㵯")+l1lll11l1lll_l1_+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㵰"))
		if l1ll11l111ll_l1_==2: stay = False
	return
def l1lll1111l11_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㵱"),l1l11l_l1_ (u"ࠨࠩ㵲"),l1l11l_l1_ (u"ࠩࠪ㵳"),l1l11l_l1_ (u"ࠪืษอไࠨ㵴"),l1l11l_l1_ (u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬ㵵"))
	if yes==1:
		succeeded = True
		if os.path.exists(l1l1llll1l11_l1_):
			try: os.remove(l1l1llll1l11_l1_)
			except: succeeded = False
		if succeeded: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㵶"),l1l11l_l1_ (u"࠭ࠧ㵷"),l1l11l_l1_ (u"ࠧࠨ㵸"),l1l11l_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ㵹"))
		else: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㵺"),l1l11l_l1_ (u"ࠪࠫ㵻"),l1l11l_l1_ (u"ࠫࠬ㵼"),l1l11l_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬ㵽"))
	return
def l1ll1l1l1111_l1_():
	l1ll11l1ll11_l1_()
	l1lll11ll1l1_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㵾"))
	message = {}
	message[l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ㵿")] = l1l11l_l1_ (u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧ㶀")
	message[l1l11l_l1_ (u"ࠩࡖࡘࡔࡖࠧ㶁")] = l1l11l_l1_ (u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ㶂")
	message[l1l11l_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㶃")] = l1l11l_l1_ (u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭㶄")+str(LIMITED_CACHE/60)+l1l11l_l1_ (u"࠭ࠠะไํๆฮࠦแใูࠪ㶅")
	l1ll1111ll11_l1_ = message[l1lll11ll1l1_l1_]
	choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠧࠨ㶆"),l1l11l_l1_ (u"ࠨๅสุࠥ࠭㶇")+str(LIMITED_CACHE/60)+l1l11l_l1_ (u"ࠩࠣำ็๐โสࠩ㶈"),l1l11l_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ㶉"),l1l11l_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ㶊"),l1ll1111ll11_l1_,l1l11l_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨ㶋"))
	if choice==0: l1ll1111l11l_l1_ = l1l11l_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ㶌")
	elif choice==1: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ㶍")
	elif choice==2: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠨࡕࡗࡓࡕ࠭㶎")
	else: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠩࠪ㶏")
	if l1ll1111l11l_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㶐"),l1ll1111l11l_l1_)
		l1l1llllll11_l1_ = message[l1ll1111l11l_l1_]
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㶑"),l1l11l_l1_ (u"ࠬ࠭㶒"),l1l11l_l1_ (u"࠭ࠧ㶓"),l1l1llllll11_l1_)
	return
def l1ll111ll1l1_l1_():
	message = {}
	message[l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ㶔")] = l1l11l_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭㶕")
	message[l1l11l_l1_ (u"ࠩࡄࡗࡐ࠭㶖")] = l1l11l_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧ㶗")
	message[l1l11l_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㶘")] = l1l11l_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ㶙")
	l1ll1llll1l1_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭㶚"))
	l1lll11ll1l1_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㶛"))
	l1ll1111ll11_l1_ = message[l1lll11ll1l1_l1_]+l1ll1llll1l1_l1_
	choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠨࠩ㶜"),l1l11l_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ㶝"),l1l11l_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ㶞"),l1l11l_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ㶟"),l1ll1111ll11_l1_,l1l11l_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩ㶠"))
	if choice==0: l1ll1111l11l_l1_ = l1l11l_l1_ (u"࠭ࡁࡔࡍࠪ㶡")
	elif choice==1: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ㶢")
	elif choice==2: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠨࡕࡗࡓࡕ࠭㶣")
	if choice in [0,1]:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㶤"),l1l11l_l1_ (u"ࠪื๏ืแา࠼ࠣࠫ㶥")+l1l1ll11l1l1_l1_[1],l1l11l_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ㶦")+l1l1ll11l1l1_l1_[0],l1l11l_l1_ (u"ࠬ࠭㶧"),l1l11l_l1_ (u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ㶨"))
		if yes==1: l1ll1ll1l111_l1_ = l1l1ll11l1l1_l1_[0]
		else: l1ll1ll1l111_l1_ = l1l1ll11l1l1_l1_[1]
	elif choice==2: l1ll1ll1l111_l1_ = l1l11l_l1_ (u"ࠧࠨ㶩")
	else: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠨࠩ㶪")
	if l1ll1111l11l_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㶫"),l1ll1111l11l_l1_)
		settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ㶬"),l1ll1ll1l111_l1_)
		l1l1llllll11_l1_ = message[l1ll1111l11l_l1_]+l1ll1ll1l111_l1_
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㶭"),l1l11l_l1_ (u"ࠬ࠭㶮"),l1l11l_l1_ (u"࠭ࠧ㶯"),l1l1llllll11_l1_)
	return
def l1ll11lll111_l1_():
	l1lll11ll1l1_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㶰"))
	message = {}
	message[l1l11l_l1_ (u"ࠨࡃࡘࡘࡔ࠭㶱")] = l1l11l_l1_ (u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪ㶲")
	message[l1l11l_l1_ (u"ࠪࡅࡘࡑࠧ㶳")] = l1l11l_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ㶴")
	message[l1l11l_l1_ (u"࡙ࠬࡔࡐࡒࠪ㶵")] = l1l11l_l1_ (u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ㶶")
	l1ll1111ll11_l1_ = message[l1lll11ll1l1_l1_]
	choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠧࠨ㶷"),l1l11l_l1_ (u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭㶸"),l1l11l_l1_ (u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ㶹"),l1l11l_l1_ (u"ࠪษ๏่วโࠢๆห๊๊ࠧ㶺"),l1ll1111ll11_l1_,l1l11l_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧ㶻"))
	if choice==0: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠬࡇࡓࡌࠩ㶼")
	elif choice==1: l1ll1111l11l_l1_ = l1l11l_l1_ (u"࠭ࡁࡖࡖࡒࠫ㶽")
	elif choice==2: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠧࡔࡖࡒࡔࠬ㶾")
	else: l1ll1111l11l_l1_ = l1l11l_l1_ (u"ࠨࠩ㶿")
	if l1ll1111l11l_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ㷀"),l1ll1111l11l_l1_)
		l1l1llllll11_l1_ = message[l1ll1111l11l_l1_]
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㷁"),l1l11l_l1_ (u"ࠫࠬ㷂"),l1l11l_l1_ (u"ࠬ࠭㷃"),l1l1llllll11_l1_)
	return
def l1ll1l1ll11l_l1_():
	l1l1llll11ll_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㷄"))
	if l1l1llll11ll_l1_==l1l11l_l1_ (u"ࠧࡔࡖࡒࡔࠬ㷅"): header = l1l11l_l1_ (u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧ㷆")
	else: header = l1l11l_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧ㷇")
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ㷈"),l1l11l_l1_ (u"ࠫส๐โศใࠪ㷉"),l1l11l_l1_ (u"ࠬะแฺ์็ࠫ㷊"),header,l1l11l_l1_ (u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱ๋้ࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩ㷋"))
	if yes==-1: return
	elif yes:
		settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㷌"),l1l11l_l1_ (u"ࠨࠩ㷍"))
		DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㷎"),l1l11l_l1_ (u"ࠪࠫ㷏"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㷐"),l1l11l_l1_ (u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ㷑"))
	else:
		settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㷒"),l1l11l_l1_ (u"ࠧࡔࡖࡒࡔࠬ㷓"))
		DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㷔"),l1l11l_l1_ (u"ࠩࠪ㷕"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㷖"),l1l11l_l1_ (u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭㷗"))
	return
def l1ll11l1lll1_l1_(text):
	if text!=l1l11l_l1_ (u"ࠬ࠭㷘"):
		text = l1ll1ll11ll_l1_(text)
		text = text.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㷙")).encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㷚"))
		l1ll1ll1ll1_l1_ = 10103
		l1ll1ll1l11_l1_ = xbmcgui.l1ll1l1ll11_l1_(l1ll1ll1ll1_l1_)
		l1ll1ll1l11_l1_.getControl(311).l1ll1lll11l_l1_(text)
		#l1ll11lllll1_l1_ = xbmcgui.WindowXMLDialog(l1l11l_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡌࡧࡼࡦࡴࡧࡲࡥ࠴࠵࠲ࡽࡳ࡬ࠨ㷛"), xbmcaddon.Addon().getAddonInfo(l1l11l_l1_ (u"ࠩࡳࡥࡹ࡮ࠧ㷜")).decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㷝")),l1l11l_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ㷞"),l1l11l_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ㷟"))
		#l1ll11lllll1_l1_.show()
		#l1ll11lllll1_l1_.getControl(99991).setPosition(0,0)
		#l1ll11lllll1_l1_.getControl(311).l1ll1lll11l_l1_(text)
		#l1ll11lllll1_l1_.getControl(5).l1l1ll1l111l_l1_(l1ll1lll1ll1_l1_)
		#width = xbmcgui.l1ll11111ll1_l1_()
		#height = xbmcgui.l1ll1l11l111_l1_()
		#resolution = (0.0+width)/height
		#l1ll11lllll1_l1_.getControl(5).l1ll1ll11111_l1_(width-180)
		#l1ll11lllll1_l1_.getControl(5).setHeight(height-180)
		#l1ll11lllll1_l1_.doModal()
		#del l1ll11lllll1_l1_
	return
l1l1lll1ll11_l1_ = [
			 l1l11l_l1_ (u"ࠨࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢࠪࠫࠥ࡯ࡳࠡࡰࡲࡸࠥࡩࡵࡳࡴࡨࡲࡹࡲࡹࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠦ㷠")
			,l1l11l_l1_ (u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡍࡢ࡮࡬ࡧ࡮ࡵࡵࡴࠢࡶࡧࡷ࡯ࡰࡵࡵࠪ㷡")
			,l1l11l_l1_ (u"ࠨࡒ࡙ࡖࠥࡏࡐࡕࡘࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡇࡱ࡯ࡥ࡯ࡶࠪ㷢")
			,l1l11l_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰ࡚ࠣ࡮ࡪࡥࡰࠢࡌࡲ࡫ࡵࠠࡌࡧࡼࠫ㷣")
			,l1l11l_l1_ (u"ࠪࡸ࡭࡯ࡳࠡࡪࡤࡷ࡭ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡧࡸ࡯࡬ࡧࡱࠫ㷤")
			,l1l11l_l1_ (u"ࠫࡺࡹࡥࡴࠢࡳࡰࡦ࡯࡮ࠡࡊࡗࡘࡕࠦࡦࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠭㷥")
			,l1l11l_l1_ (u"ࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡶࡵࡤ࡫ࡪ࠴ࡨࡵ࡯࡯ࠧࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪ㷦")
			,l1l11l_l1_ (u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩ㷧")
			,l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫࠽࠱ࠨࡷࡩࡽࡺ࠽ࠨ㷨")
			,l1l11l_l1_ (u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩ㷩")
			,l1l11l_l1_ (u"ࠩࡡࡢࡣࡤ࡞ࠨ㷪")
			]
def l1ll111llll1_l1_(line):
	if l1l11l_l1_ (u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ㷫") in line and l1l11l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㷬") in line: return True
	for text in l1l1lll1ll11_l1_:
		if text in line: return True
	return False
def l1l1ll1l11ll_l1_(data):
	data = data.replace(l1l11l_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㷭")+l1l11l_l1_ (u"࠭ࠠࠨ㷮")*51+l1l11l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㷯"),l1l11l_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㷰"))
	data = data.replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㷱")+l1l11l_l1_ (u"ࠪࠤࠬ㷲")*51+l1l11l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㷳"),l1l11l_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㷴"))
	data = data.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩ㷵")+l1l11l_l1_ (u"ࠧࠡࠩ㷶")*51+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㷷"),l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㷸"))
	data = data.replace(l1l11l_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢ࠰ࡵࡷࡳࡷࡧࡧࡦ࠱ࡨࡱࡺࡲࡡࡵࡧࡧ࠳࠵࠵ࡁ࡯ࡦࡵࡳ࡮ࡪ࠯ࡥࡣࡷࡥ࠴ࡵࡲࡨ࠰ࡻࡦࡲࡩ࠮࡬ࡱࡧ࡭࠴࡬ࡩ࡭ࡧࡶ࠳࠳ࡱ࡯ࡥ࡫࠲ࡥࡩࡪ࡯࡯ࡵ࠲ࠫ㷹"),l1l11l_l1_ (u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠩ㷺"))
	data = data.replace(l1l11l_l1_ (u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫ㷻"),l1l11l_l1_ (u"࠭࠺ࠡࠩ㷼"))
	return data
def l1l1lll11ll1_l1_(l1ll1l111111_l1_):
	if l1l11l_l1_ (u"ࠧࡐࡎࡇࠫ㷽") in l1ll1l111111_l1_:
		l1ll1llll1ll_l1_ = l1l1ll1lllll_l1_
		header = l1l11l_l1_ (u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨ㷾")
	else:
		l1ll1llll1ll_l1_ = l1lll11111ll_l1_
		header = l1l11l_l1_ (u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩ㷿")
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ㸀"),l1l11l_l1_ (u"ࠫࠬ㸁"),l1l11l_l1_ (u"ࠬ࠭㸂"),header,l1l11l_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ㸃"))
	if yes!=1: return
	l1l1ll1ll111_l1_,counts = [],0
	size = os.path.getsize(l1ll1llll1ll_l1_)
	file = open(l1ll1llll1ll_l1_,l1l11l_l1_ (u"ࠧࡳࡤࠪ㸄"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭㸅"))
	data = l1l1ll1l11ll_l1_(data)
	lines = data.split(l1l11l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㸆"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㸇"))
		#if line.strip(l1l11l_l1_ (u"ࠫࠥ࠭㸈"))==l1l11l_l1_ (u"ࠬ࠭㸉"): continue
		ignore = l1ll111llll1_l1_(line)
		if ignore: continue
		line = line.replace(l1l11l_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡤ࠭㸊"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ㸋"))
		line = line.replace(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠨ㸌"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࡊࡘࡒࡐࡔ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㸍"))
		l1l1lll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠬࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ㸎"),line,re.DOTALL)
		l1ll1l1111ll_l1_ = l1l11l_l1_ (u"ࠫࠬ㸏")
		if l1l1lll1l1ll_l1_:
			line = line.replace(l1l1lll1l1ll_l1_[0][0],l1l11l_l1_ (u"ࠬ࠭㸐")).replace(l1l1lll1l1ll_l1_[0][2],l1l11l_l1_ (u"࠭ࠧ㸑"))
			l1ll1l1111ll_l1_ = l1l1lll1l1ll_l1_[0][1]
		else:
			l1l1lll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ㸒"),line,re.DOTALL)
			if l1l1lll1l1ll_l1_:
				line = line.replace(l1l1lll1l1ll_l1_[0][1],l1l11l_l1_ (u"ࠨࠩ㸓"))
				l1ll1l1111ll_l1_ = l1l1lll1l1ll_l1_[0][0]
		if l1ll1l1111ll_l1_: line = line.replace(l1ll1l1111ll_l1_,l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㸔")+l1ll1l1111ll_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㸕"))
		l1l1ll1ll111_l1_.append(line)
		if len(str(l1l1ll1ll111_l1_))>50100: break
	l1l1ll1ll111_l1_ = reversed(l1l1ll1ll111_l1_)
	l1ll1lll1ll1_l1_ = l1l11l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㸖").join(l1l1ll1ll111_l1_)
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠬࡲࡥࡧࡶࠪ㸗"),l1l11l_l1_ (u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪ㸘"),l1ll1lll1ll1_l1_,l1l11l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ㸙"))
	return
def l1l1lll1l1l1_l1_():
	l1ll1lllll11_l1_ = open(l1ll1l111l1l_l1_,l1l11l_l1_ (u"ࠨࡴࡥࠫ㸚")).read()
	if kodi_version>18.99: l1ll1lllll11_l1_ = l1ll1lllll11_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㸛"))
	l1ll1lllll11_l1_ = l1ll1lllll11_l1_.replace(l1l11l_l1_ (u"ࠪࡠࡹ࠭㸜"),l1l11l_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥ࠭㸝"))
	l1llll1l1l11_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮ࡶ࡝ࡦ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭㸞"),l1ll1lllll11_l1_,re.DOTALL)
	for line in l1llll1l1l11_l1_:
		l1ll1lllll11_l1_ = l1ll1lllll11_l1_.replace(line,l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㸟")+line+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㸠"))
	DIALOG_TEXTVIEWER(l1l11l_l1_ (u"ࠨษ็ฮ฿๐๊าษอࠤฬ๊รฯ์ิอࠥ็๊ࠡษ็ฬึอๅอࠩ㸡"),l1ll1lllll11_l1_)
	return
def l1ll1l1ll111_l1_():
	l1llll1llll_l1_ = l1l11l_l1_ (u"ࠩห฽฻ࠦวๅลีีฬืฺࠠๆ์ࠤฬ๊ั๋็๋ฮ้่ࠥ็ฬิ์้ࠦส้ใิࠤส๋ใศ่ํอࠥะโะ์่ࠤํะรฯ์ิࠤฬ๊แ๋ัํ์ࠥ๎็ั้ࠣห้ษาาษิࠤ์๐ࠠศๆฦื์๋้ࠠษ็วึ่วๆ่ࠢ฽ࠥฮูื๋ࠢ็ฬ๊สศๆํࠫ㸢")
	l1lllll1111_l1_ = l1l11l_l1_ (u"่ࠪฯ่ฯ๋็ࠣห้็๊ะ์๋ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ๅ๋่ࠣ์้ะรฯ์ิ๋ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ิษิࠤ࠳ࠦรๆษࠣ฽ิฯࠠศี๊้๋ࠥสหษ็๎ฮࠦแ่า๊ࠤฯ่่ๆࠢหฮาื๊ไࠢส่ๆ๐ฯ๋๊ࠣฬํ่สࠡษๆฬึࠦๅ็๋ࠢๆฯࠦวๅี๊้ࠥอไ้ษะำࠥ࠴ࠠฤ็สࠤฬ๊ำ่็ࠣห้ษูๅ๋ࠣ์ฬ๊ริใ็ࠤๆํ่ࠡ์ะี่ࠦวๅใํำ๏๎ࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤํ๊ใ็ࠢหๆๆุษࠡๅห๎ึฯࠧ㸣")
	l11l11ll1ll_l1_ = l1l11l_l1_ (u"ࠫศ๋วࠡษ็วึ่วๆࠢไ๋๏ࠦสิฬัำ๊ࠦไๅฬๅำ๏๋้ࠠษ็ฮศิ๊า๋่่ࠢ์ࠠษ็ๅำฬืฺࠠัาࠤฬ๊ห้ษ้๎ࠥ๎วๅัๅหห่ࠠ࠯่ࠢฯ้อࠠาไ่ࠤ࠺࠺࠴ࠡฬ฼๊๏ࠦ࠵ࠡัๅหห่้ࠠࠢ࠷࠸ࠥัว็์ฬࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอมࠡสะือࠦวิฬัำฬ๋ใࠡๆ็ื์๋ࠠศๆํ้๏์ࠠฤ๊ࠣื์๋ࠠศๆํืฬืࠧ㸤")
	message = l1llll1llll_l1_+l1l11l_l1_ (u"ࠬࡀࠠࠨ㸥")+l1lllll1111_l1_+l1l11l_l1_ (u"࠭ࠠ࠯ࠢࠪ㸦")+l11l11ll1ll_l1_
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㸧"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㸨"),message,l1l11l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㸩"))
	return
def l11ll1llll1_l1_(l111l11l1ll_l1_,message,showDialogs=True,url=l1l11l_l1_ (u"ࠪࠫ㸪"),source=l1l11l_l1_ (u"ࠫࠬ㸫"),text=l1l11l_l1_ (u"ࠬ࠭㸬"),l11ll11lll1_l1_=l1l11l_l1_ (u"࠭ࠧ㸭")):
	if l1l11l_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ㸮") in text: l1llll11lll1_l1_ = True
	else: l1llll11lll1_l1_ = False
	l1l1ll11ll1l_l1_ = True
	if not l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ㸯")):
		if showDialogs:
			#if message.count(l1l11l_l1_ (u"ࠩ࡟ࡠࡳ࠭㸰"))>1: l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㸱")
			#else: l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㸲")
			l1l1llll1l1l_l1_ = (l1l11l_l1_ (u"ࠬอไิูิ࠾ࠬ㸳") in message and l1l11l_l1_ (u"࠭วๅ็ๆห๋ࡀࠧ㸴") in message and l1l11l_l1_ (u"ࠧศๆ่่ๆࡀࠧ㸵") in message and l1l11l_l1_ (u"ࠨษ็า฼ษࠧ㸶") in message and l1l11l_l1_ (u"ࠩส่๊฻ฯา࠼ࠪ㸷") in message)
			if not l1l1llll1l1l_l1_: l1l1ll11ll1l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㸸"),l1l11l_l1_ (u"ࠫࠬ㸹"),l1l11l_l1_ (u"ࠬ࠭㸺"),l1l11l_l1_ (u"࠭็ๅࠢอีุ๊่ࠠา๊ࠤฬ๊ัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ㸻"),message.replace(l1l11l_l1_ (u"ࠧ࡝࡞ࡱࠫ㸼"),l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㸽")))
	elif showDialogs:
		message = l1l11l_l1_ (u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩ㸾")
		l1lll11lll1l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㸿"),l1l11l_l1_ (u"ࠫࠬ㹀"),l1l11l_l1_ (u"ࠬ࠭㹁"),l1l11l_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭㹂")+l1l11l_l1_ (u"ࠧࠡࠢ࠴࠳࠺࠭㹃"),l1l11l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭㹄"))
		l1lll11lll11_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㹅"),l1l11l_l1_ (u"ࠪࠫ㹆"),l1l11l_l1_ (u"ࠫࠬ㹇"),l1l11l_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ㹈")+l1l11l_l1_ (u"࠭ࠠࠡ࠴࠲࠹ࠬ㹉"),l1l11l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ㹊"))
		l1lll11ll1ll_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㹋"),l1l11l_l1_ (u"ࠩࠪ㹌"),l1l11l_l1_ (u"ࠪࠫ㹍"),l1l11l_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ㹎")+l1l11l_l1_ (u"ࠬࠦࠠ࠴࠱࠸ࠫ㹏"),l1l11l_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ㹐"))
		l1lll1l1111l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㹑"),l1l11l_l1_ (u"ࠨࠩ㹒"),l1l11l_l1_ (u"ࠩࠪ㹓"),l1l11l_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ㹔")+l1l11l_l1_ (u"ࠫࠥࠦ࠴࠰࠷ࠪ㹕"),l1l11l_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ㹖"))
		l1l1ll11ll1l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㹗"),l1l11l_l1_ (u"ࠧࠨ㹘"),l1l11l_l1_ (u"ࠨࠩ㹙"),l1l11l_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ㹚")+l1l11l_l1_ (u"ࠪࠤࠥ࠻࠯࠶ࠩ㹛"),l1l11l_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ㹜"))
	if l1l1ll11ll1l_l1_!=1:
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㹝"),l1l11l_l1_ (u"࠭ࠧ㹞"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㹟"),l1l11l_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫ㹠"))
		return False
	l1lll1l111l1_l1_ = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠣ㹡") )
	message += l1l11l_l1_ (u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ㹢")+addon_version+l1l11l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ㹣")
	message += l1l11l_l1_ (u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭㹤")+l1ll1l1l11l_l1_(32)+l1l11l_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬ㹥")+l1ll1l1111l1_l1_+l1l11l_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࠭㹦")
	message += l1l11l_l1_ (u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭㹧")+l1lll1l111l1_l1_
	#l1lll11l1l11_l1_ = l1l1llll1ll1_l1_(l1l11l_l1_ (u"ࠩ࠺࠺࠳࠼࠵࠯࠳࠶࠼࠳࠸࠳࠱ࠩ㹨"))
	l1lll11l1l11_l1_ = l1l1llll1ll1_l1_()
	l1lll11l1l11_l1_ = QUOTE(l1lll11l1l11_l1_)
	if l1lll11l1l11_l1_: message += l1l11l_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬ㹩")+l1lll11l1l11_l1_
	if url: message += l1l11l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨ㹪")+url
	if source: message += l1l11l_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬ㹫")+source
	message += l1l11l_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ㹬")
	if showDialogs: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧอษิ๎ࠥอไฦำึห้࠭㹭"),l1l11l_l1_ (u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪ㹮"))
	if l11ll11lll1_l1_:
		l1ll1lll1ll1_l1_ = l11ll11lll1_l1_
		if kodi_version>18.99: l1ll1lll1ll1_l1_ = l1ll1lll1ll1_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㹯"))
		l1ll1lll1ll1_l1_ = base64.b64encode(l1ll1lll1ll1_l1_)
	elif l1llll11lll1_l1_:
		if l1l11l_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ㹰") in text: l1lll11ll11l_l1_ = l1l1ll1lllll_l1_
		else: l1lll11ll11l_l1_ = l1lll11111ll_l1_
		if not os.path.exists(l1lll11ll11l_l1_):
			DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㹱"),l1l11l_l1_ (u"ࠬ࠭㹲"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㹳"),l1l11l_l1_ (u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬ㹴"))
			return False
		l1l1ll1ll111_l1_,counts = [],0
		size = os.path.getsize(l1lll11ll11l_l1_)
		file = open(l1lll11ll11l_l1_,l1l11l_l1_ (u"ࠨࡴࡥࠫ㹵"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㹶"))
		data = l1l1ll1l11ll_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㹷"))
			ignore = l1ll111llll1_l1_(line)
			if ignore: continue
			l1l1lll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰࠭࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ㹸"),line,re.DOTALL)
			if l1l1lll1l1ll_l1_:
				line = line.replace(l1l1lll1l1ll_l1_[0][0],l1l11l_l1_ (u"ࠬ࠭㹹")).replace(l1l1lll1l1ll_l1_[0][2],l1l11l_l1_ (u"࠭ࠧ㹺"))
			else:
				l1l1lll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ㹻"),line,re.DOTALL)
				if l1l1lll1l1ll_l1_: line = line.replace(l1l1lll1l1ll_l1_[0][1],l1l11l_l1_ (u"ࠨࠩ㹼"))
			l1l1ll1ll111_l1_.append(line)
			if len(str(l1l1ll1ll111_l1_))>121000: break
		l1l1ll1ll111_l1_ = reversed(l1l1ll1ll111_l1_)
		l1ll1lll1ll1_l1_ = l1l11l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㹽").join(l1l1ll1ll111_l1_)
		l1ll1lll1ll1_l1_ = l1ll1lll1ll1_l1_.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㹾"))
		l1ll1lll1ll1_l1_ = base64.b64encode(l1ll1lll1ll1_l1_)
	else: l1ll1lll1ll1_l1_ = l1l11l_l1_ (u"ࠫࠬ㹿")
	url = WEBSITES[l1l11l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㺀")][2]
	payload = {l1l11l_l1_ (u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ㺁"):l111l11l1ll_l1_,l1l11l_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ㺂"):message,l1l11l_l1_ (u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ㺃"):l1ll1lll1ll1_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㺄"),url,payload,l1l11l_l1_ (u"ࠪࠫ㺅"),l1l11l_l1_ (u"ࠫࠬ㺆"),l1l11l_l1_ (u"ࠬ࠭㺇"),l1l11l_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵࠩ㺈"))
	#succeeded = response.succeeded
	html = response.content
	if l1l11l_l1_ (u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩ㺉") in html: succeeded = True
	else: succeeded = False
	if showDialogs:
		if succeeded:
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠬ㺊"),l1l11l_l1_ (u"ࠩห๊ัออࠨ㺋"))
			DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㺌"),l1l11l_l1_ (u"ࠫࠬ㺍"),l1l11l_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫ㺎"),l1l11l_l1_ (u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨ㺏"))
		else:
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧๅๆฦืๆ࠭㺐"),l1l11l_l1_ (u"ࠨใื่ࠥ็๊ࠡษ็ษึูวๅࠩ㺑"))
			DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㺒"),l1l11l_l1_ (u"ࠪࠫ㺓"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㺔"),l1l11l_l1_ (u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ㺕"))
	return succeeded
def l1l1ll11llll_l1_():
	l1llll1llll_l1_ = l1l11l_l1_ (u"࠭࠱࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡࡶࡨࡼࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ㺖")
	l1lllll1111_l1_ = l1l11l_l1_ (u"ࠧ࠲࠰ࠣࠤࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢส่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ㺗")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㺘"),l1l11l_l1_ (u"ࠩࠪ㺙"),l1l11l_l1_ (u"ࠪࡅࡷࡧࡢࡪࡥࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ㺚"),l1llll1llll_l1_+l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㺛")+l1lllll1111_l1_)
	l1llll1llll_l1_ = l1l11l_l1_ (u"ࠬ࠸࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡢࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠫ㺜")
	l1lllll1111_l1_ = l1l11l_l1_ (u"࠭࠲࠯ࠢࠣࠤสึวࠡๆ่ࠤฯาฯࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠโไ่ࠤอะฺ๋์ิࠤฬ๊ฬๅัࠣฯ๊ࠦโๆࠢหฮ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡษ็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭㺝")
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㺞"),l1l11l_l1_ (u"ࠨࠩ㺟"),l1l11l_l1_ (u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ㺠"),l1llll1llll_l1_+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㺡")+l1lllll1111_l1_)
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㺢"),l1l11l_l1_ (u"ࠬ࠭㺣"),l1l11l_l1_ (u"࠭ࠧ㺤"),l1l11l_l1_ (u"ࠧࡇࡱࡱࡸࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧ㺥"),l1l11l_l1_ (u"ࠨࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦ࡮ࡰࡹࠣࡃࠬ㺦")+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㺧")+l1l11l_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ะ่ษหࠤส๊้ࠡๆ๋ัฮࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤศ๊ย็มࠪ㺨"))
	if yes==1: l1ll1lll1lll_l1_()
	return
def l1lll1l1l1l1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㺩"),l1l11l_l1_ (u"ࠬ࠭㺪"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㺫"),l1l11l_l1_ (u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭㺬"))
	return
def l1lll1111ll1_l1_():
	message = l1l11l_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨ㺭")
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㺮"),l1l11l_l1_ (u"ࠪࠫ㺯"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㺰"),message)
	return
def l1ll11ll1l11_l1_():
	message = l1l11l_l1_ (u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ㺱")
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㺲"),l1l11l_l1_ (u"ࠧࠨ㺳"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㺴"),message)
	return
def l1l1ll11ll11_l1_():
	message = l1l11l_l1_ (u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭㺵")
	DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㺶"),l1l11l_l1_ (u"ࠫࠬ㺷"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㺸"),l1l11l_l1_ (u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨ㺹"),message)
	return
def l1ll1llll111_l1_():
	message = l1l11l_l1_ (u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬ㺺")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㺻"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㺼"),message,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭㺽"))
	return
def l1ll1l11l1ll_l1_():
	l1llll1llll_l1_ = l1l11l_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬ㺾")
	l1lllll1111_l1_ = l1l11l_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧ㺿")
	l11l11ll1ll_l1_ = l1l11l_l1_ (u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㻀")
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㻁"),l1l11l_l1_ (u"ࠨࠩ㻂"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㻃"),l1llll1llll_l1_,l1lllll1111_l1_,l11l11ll1ll_l1_)
	return
def l1ll11l1ll11_l1_():
	l1lllll1111_l1_ = l1l11l_l1_ (u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫ㻄")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㻅") + l1l11l_l1_ (u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ㻆") + str(PERMANENT_CACHE/60/60/24/30) + l1l11l_l1_ (u"࠭ࠠี้ิࠫ㻇")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㻈") + l1l11l_l1_ (u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ㻉") + str(l1llll11l11_l1_/60/60/24) + l1l11l_l1_ (u"ࠩࠣ๎ํ๋ࠧ㻊")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠪࡠࡳ࠭㻋") + l1l11l_l1_ (u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ㻌") + str(l1llll_l1_/60/60/24) + l1l11l_l1_ (u"๊้ࠬࠦ็ࠪ㻍")
	l1lllll1111_l1_ += l1l11l_l1_ (u"࠭࡜࡯ࠩ㻎") + l1l11l_l1_ (u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ㻏") + str(REGULAR_CACHE/60/60) + l1l11l_l1_ (u"ࠨࠢึห฾ฯࠧ㻐")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㻑") + l1l11l_l1_ (u"ࠪ࠹࠳ࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡัสส๊อ้ࠠ็าฮ์ࠦࠧ㻒") + str(l1111lll_l1_/60/60) + l1l11l_l1_ (u"ูࠫࠥวฺหࠪ㻓")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮ࠨ㻔") + l1l11l_l1_ (u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧ㻕") + str(l1l11ll11ll_l1_/60) + l1l11l_l1_ (u"ࠧࠡัๅ๎็ฯࠧ㻖")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㻗") + l1l11l_l1_ (u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫ㻘") + str(NO_CACHE) + l1l11l_l1_ (u"ࠪࠤิ่๊ใหࠪ㻙")
	l1lllll1111_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㻚") + l1l11l_l1_ (u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩ㻛") + str(REGULAR_CACHE/60/60) + l1l11l_l1_ (u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧ㻜") + str(l1llll_l1_/60/60/24) + l1l11l_l1_ (u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭㻝") + str(l1111lll_l1_/60/60) + l1l11l_l1_ (u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬ㻞") + str(l1l11ll11ll_l1_/60) + l1l11l_l1_ (u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫ㻟") + str(NO_CACHE) + l1l11l_l1_ (u"ࠪࠤิ่๊ใหࠪ㻠")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㻡"),l1l11l_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ㻢"),l1lllll1111_l1_,l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㻣"))
	return
def l1l1lll1lll1_l1_():
	message = l1l11l_l1_ (u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ㻤")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㻥"),l1l11l_l1_ (u"ࠩࠪ㻦"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㻧"),message)
	return
def l1ll1111111l_l1_():
	message = l1l11l_l1_ (u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ㻨")
	DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㻩"),l1l11l_l1_ (u"࠭ࠧ㻪"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㻫"),message)
	return
def l1ll1l1lll11_l1_():
	message = l1l11l_l1_ (u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬ㻬")
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㻭"),l1l11l_l1_ (u"ࠪࠫ㻮"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㻯"),message)
	return
def l1l1lllll1l1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㻰"),l1l11l_l1_ (u"࠭ࠧ㻱"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㻲"),l1l11l_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㻳"))
	l1ll1l1l1lll_l1_(l1l11l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㻴"),True)
	return
def l1ll111l11ll_l1_():
	message  = l1l11l_l1_ (u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ㻵")
	#message += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞๊๊ิฬࠦวๅ฻สส็ࠦ็้ࠢࡵࡩࡈࡇࡐࡕࡅࡋࡅࠥอไฯษุࠤอฺัไหࠣะําไ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ㻶")
	#message += l1l11l_l1_ (u"ࠬ๎วๅาํࠤฺ์ูหุ้ࠣึ้ษࠡฮ๋ะ้ࠦฮึ์ุห๊ࠥๅ็฻ࠣฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ๊์ࠠหืไัࠥอไฦ่อี๋ะࠧ㻷")
	message += l1l11l_l1_ (u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭㻸")
	message += l1l11l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิั࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ㻹")
	message += l1l11l_l1_ (u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨ㻺")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㻻"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㻼"),message,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ㻽"))
	message = l1l11l_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ㻾")
	message += l1l11l_l1_ (u"࠭࡜࡯ࠩ㻿")+l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㼀")
	message += l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㼁")+l1l11l_l1_ (u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ㼂")
	message += l1l11l_l1_ (u"ࠪࡠࡳ࠭㼃")+l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㼄")
	message += l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㼅")+l1l11l_l1_ (u"࠭วๅ็หี๊า้ࠠฮาࠤ฼ื๊ให่ࠣฯาว้ิࠣห้฿ววไࠣ์้้ๆ่ษࠣฮาะวอࠢฯ๋ิࠦใษ์ิࠤํอไๆสิ้ัู๊่ࠦࠣห้๋ิไๆฬࠤฺเ๊าหࠣ์้อࠠหีอั็ࠦวๅฬ฼ฬࠥ็ลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠษษ็ำำ๎ไࠡๆห฽฻ࠦวๅ็๋ห็฿้ࠠลํฺฬࠦไไ์ࠣ๎ฯ฼อࠡฯฯ้ࠥอไๆึๆ่ฮࠦࠧ㼆")
	message += l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟สีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้ส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㼇")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㼈"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㼉"),message,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭㼊"))
	#l1ll1l1llll1_l1_(l1l11l_l1_ (u"ࠫࡎࡹࡐࡳࡱࡥࡰࡪࡳ࠽ࡇࡣ࡯ࡷࡪ࠭㼋"))
	#message = l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㼌")+l1l11l_l1_ (u"่࠭ๅไาࠤ้ออู่สࠤฬ๐ึศࠢฦ๊ࠥอไๆ๊สๆ฾ࠦวๅ็฼ห็ฯࠠหะอ่ๆࠦศศะอ่ฬ็ࠠศๆห่ิ่ࠦหะอ่ๆࠦศศะอ่ฬ็ࠠีำๆอࠥอไศ่อี๋๐สࠡใํࠤี๊ใࠡษ็ฬ้ี้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์็ࠡฯอํ๊่ࠥࠡฬ่ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥࡖࡲࡰࡺࡼࠤศ๎ࠠฤ์ࠣ์ุ๐ไสࠢสาึ๏ࠠโษ้ࠤฬ๊ๅ้ษๅ฽ࠥอไๆ฻สๆฮࠦำ้ใࠣฮำะไโ๋่่ࠢ์็ศࠢ็๊ࠥะูๆๆࠣะ๊๐ู่ษࠪ㼍")
	#message += l1l11l_l1_ (u"ࠧๅฯ็ࠤฬ๊ๅีๅ็อ่ࠥๅࠡส฼้้๐ๆ࠻ࠢࠣࠤࠥอไฤ๊็࠾ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า๊ࠩࠡส็ฯฮࠠๆ฻๊ࠤฬูๅࠡส็ำ่่ࠦศี่ࠤูืใสࠢส่ส์สา่ํฮࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠห฻่่ࠥ฿ๆะๅࠪ㼎")
	#message += l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㼏")+l1l11l_l1_ (u"๋ࠩห้ัว็์࠽ࠤัืศࠡษึฮำีวๆ࡙ࠢࡔࡓฺ่่ࠦาࠤฬ๊ศฺุࠣๆิࠦสฮฬสะࠥ็โุࠢอ฾๏๐ัࠡࡆࡑࡗࠥ๎วๅละื๋ࠦร็ࠢํ็ํ์ࠠโ์ࠣฬ้ีࠠศะิࠤ฾๊ๅศࠢส๊ࠥอำหะาห๊ࠦࡐࡳࡱࡻࡽ่ࠥฯࠡ์ะ่๋ࠥิไๆฬࠤอ฿ึࠡษ็้ํอโฺ๋่่ࠢ์ࠠๅ์ึࠤๆ๐ࠠอ็ํ฽ࠥอไะ๊็ࠫ㼐")
	#DIALOG_TEXTVIEWER(l1l11l_l1_ (u"ู้้ࠪไสࠢ฼๊ิࠦศฺุࠣห้์วิࠩ㼑"),message)
	#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㼒"),l1l11l_l1_ (u"ࠬ็อึࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠨ㼓"),l1l11l_l1_ (u"࠭็ัษࠣห้็อึ๊ࠢ์๊ࠥๅฺำไอࠥํไࠡษ็ู้้ไส่๊ࠢࠥ฿ๆะๅࠣห๊ࠦๅ็ࠢส่อืๆศ็ฯ࠲ู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ็อึ่ࠢ์ฬู่่่ࠢีฯ๐ๆࠡษ็วํ๊้ࠡสฺ๋฾้ࠠศๆฺฬ๏฿๊๊ࠡส่ะอๆ๋หࠣฬฬูสฯัส้ࠥฮั้ๅึ๎๋ࠥฬศ่ํࠤฬ์สࠡฬัฮฬื็ࠡ็้ࠤฬ๊โศศ่อࠥอไห์ࠣืฯ฾็าࠢ็หา่ว࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึลࠧ㼔"),l1l11l_l1_ (u"ࠧࠨ㼕"),l1l11l_l1_ (u"ࠨࠩ㼖"),l1l11l_l1_ (u"ࠩๆ่ฬ࠭㼗"),l1l11l_l1_ (u"๊ࠪ฾๋ࠧ㼘"))
	#if yes==1:
	#l1ll11llll1l_l1_()
	return
def l1ll11l11lll_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㼙"),l1l11l_l1_ (u"ࠬ࠭㼚"),l1l11l_l1_ (u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭㼛"),l1l11l_l1_ (u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡะา้ฬะ่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥษัิๆࠣีุอไสࠢไ๎ุฮ่ไࠢส่๎ࠦࠢศๆะหัูࠦๆษาࠦࠥษ่ࠡษ็ํࠥࡢ࡮ࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࠰ࡰࡥ࡭ࡪࡩ࠲ࠢ࡟ࡲࡡࡴร้ࠢสๅฯำࠠ็ไสุࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ัศสฺࠤࡡࡴࠠࡩࡶࡷࡴ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴࡯ࡳࡴࡷࡨࡷࠬ㼜"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㼝"),l1l11l_l1_ (u"ࠩࠪ㼞"),l1l11l_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ㼟"),l1l11l_l1_ (u"ࠫ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹࡜࡯࡞ࡱ࠸࠹࠺࠴࠵ࠢ࠸࠹࠺࠻࠵ࠡ࠸࠹࠺࠻࠼࡟࠸࠹࠺࠻࠼ࠦ࠸࠹࠺࠻࠼ࠥ࠿࠹࠺࠻࠼ࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࡣࡏࡐࡊࡋࡌ࠴ࡣࡐࡑࡋࡌࡍ࠴ࡣࡑࡒࡌࡍࡎ࠴ࡣࡒࡓࡍࡎࡏ࠴ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦࡁࡂࡃࡄࡅ࠷ࡥࡂࡃࡄࡅࡆ࠷ࡥࡃࡄࡅࡆࡇ࠷ࡥࡄࡅࡆࡇࡈ࠷ࡥࡅࡆࡇࡈࡉ࠷ࡥࡆࡇࡈࡉࡊ࠷ࡥࡇࡈࡉࡊࡋ࠷ࡥࡈࡉࡊࡋࡌ࠷ࡥࡉࡊࡋࡌࡍ࠷ࡥࡊࡋࡌࡍࡎ࠷ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࠦ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂࠢࡅࡆࡇࡈࡂࠨ㼠"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㼡"),l1l11l_l1_ (u"࠭ࠧ㼢"),l1l11l_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ㼣"),l1l11l_l1_ (u"ࠨ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠳ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡ࠻ࠣࡅࡆࡇࡁࡂ࠳ࡢࡆࡇࡈࡂࡃ࠳ࡢࡇࡈࡉࡃࡄ࠳ࡢࡈࡉࡊࡄࡅ࠳ࡢࡉࡊࡋࡅࡆ࠳ࡢࡊࡋࡌࡆࡇ࠳ࡢࡋࡌࡍࡇࡈ࠳ࡢࡌࡍࡎࡈࡉ࠳ࡢࡍࡎࡏࡉࡊ࠳ࡢࡎࡏࡐࡊࡋ࠳ࡢࡏࡐࡑࡋࡌ࠳ࡢࡐࡑࡒࡌࡍ࠳ࡢࡑࡒࡓࡍࡎ࠳ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥࡇࡁࡂࡃࡄ࠶ࡤࡈࡂࡃࡄࡅ࠶ࡤࡉࡃࡄࡅࡆ࠶ࡤࡊࡄࡅࡆࡇ࠶ࡤࡋࡅࡆࡇࡈ࠶ࡤࡌࡆࡇࡈࡉ࠶ࡤࡍࡇࡈࡉࡊ࠶ࡤࡎࡈࡉࡊࡋ࠶ࡤࡏࡉࡊࡋࡌ࠶ࡤࡐࡊࡋࡌࡍ࠶ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࠥ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁࠡࡄࡅࡆࡇࡈࠧ㼤"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㼥"),l1l11l_l1_ (u"ࠪࠫ㼦"),l1l11l_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ㼧"),l1l11l_l1_ (u"ࠬ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠫ㼨"))
	#text = l1l11l_l1_ (u"࠭ࠨࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࠡࠫࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠩ㼩")
	#l1l1llllllll_l1_(l1l11l_l1_ (u"ࠧࠨ㼪"),l1l11l_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ㼫"),l1l11l_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ㼬"),l1l11l_l1_ (u"ࠪ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿࠰࠲࠴࠶࠸ࠬ㼭"),l1l11l_l1_ (u"ࠫ࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸࠲࠳࠴࠵࠶ࠬ㼮"),text,1)
	#l1l1llllllll_l1_(l1l11l_l1_ (u"ࠬ࠭㼯"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭㼰"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ㼱"),l1l11l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ㼲"),l1l11l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭㼳"),l1l11l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ㼴"))
	#l1l1llllllll_l1_(l1l11l_l1_ (u"ࠫࠬ㼵"),l1l11l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ㼶"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭㼷"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ㼸"),l1l11l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ㼹"),l1l11l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ㼺"))
	#l1l1llllllll_l1_(l1l11l_l1_ (u"ࠪࠫ㼻"),l1l11l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ㼼"),l1l11l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ㼽"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭㼾"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ㼿"),l1l11l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ㽀"))
	#l1l1llllllll_l1_(l1l11l_l1_ (u"ࠩࠪ㽁"),l1l11l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ㽂"),l1l11l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ㽃"),l1l11l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ㽄"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉ࡞ࡱࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭㽅"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ㽆"))
	return
def l1ll11l111l1_l1_():
	l1ll11l1ll11_l1_()
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㽇"),l1l11l_l1_ (u"ࠩࠪ㽈"),l1l11l_l1_ (u"ࠪࠫ㽉"),l1l11l_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠศๆๆหูࠦฟࠨ㽊"),l1l11l_l1_ (u"ࠬอไไษืࠤ๏ูัฺࠢ฼้้ࠦวๅสิ๊ฬ๋ฬ๊่ࠡืาํ๋ࠠ฻ํำูࠥอษࠢสฺ่็อศฬ้๋ࠣࠦวๅว้ฮึ์สࠡ฻้ำࠥอไฮษฯอࠥหไ๋้สࠤํอไๆีะࠤ๏ะๅࠡฬ็ๆฬฬ๊ศࠢ฼๊ิࠦว็ฬ๊หฦูࠦๆำࠣห้฻แฮษอࠤํอไๆีะࠤ้อุ๋ࠠิࠤํ๋ๅไ่ࠣ๎า๊ࠠษ฻ูࠤฬ๊ๅีษๆ่ࠬ㽋"))
	if yes==1:
		l1ll11l1ll1l_l1_([iptv1_dbfile,iptv2_dbfile])
		DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㽌"),l1l11l_l1_ (u"ࠧࠨ㽍"),l1l11l_l1_ (u"ࠨฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠษษ็็ฬ๋ไࠨ㽎"),l1l11l_l1_ (u"ࠩศิฬࠦใศ่อࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬำฯࠡษ็้ํอโฺࠢไะึฮࠠศๆ่์็฿ࠠศๆล๊ࠥ࠴࠮࠯๋ࠢวีอࠠศๆุ่่๊ษࠡ็ึฮ๊ืษࠡใศิ๋ࠦวาี็ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ㽏"))
	return yes
def l1ll1lllll1l_l1_(showDialogs=True):
	if not showDialogs: showDialogs = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㽐"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡸࡢ࡯ࡳࡰࡪ࠴ࡣࡰ࡯ࠪ㽑"),l1l11l_l1_ (u"ࠬ࠭㽒"),l1l11l_l1_ (u"࠭ࠧ㽓"),False,l1l11l_l1_ (u"ࠧࠨ㽔"),l1l11l_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ㽕"))
	#html = response.content
	if not response.succeeded:
		l1ll1111llll_l1_ = False
		l1l1lll1l1_l1_ = l1l1ll1l1l_l1_()
		LOG_THIS(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㽖"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨ㽗")+l1l1lll1l1_l1_+l1l11l_l1_ (u"ࠫࡢ࠭㽘"))
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㽙"),l1l11l_l1_ (u"࠭ࠧ㽚"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㽛"),l1l11l_l1_ (u"ࠨใะูࠥอไศฬุห้ࠦวๅ็ืๅึࠦ࠮࠯࠰ู้้ࠣไสࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡๆสࠤ๏฿ๅๅࠢ฼๊ิฺ้ࠠๆ์ࠤ่๎ฯ๋ࠢ࠱࠲࠳ฺ่่ࠦา็้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬ㽜"))
	else:
		l1ll1111llll_l1_ = True
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㽝"),l1l11l_l1_ (u"ࠪࠫ㽞"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㽟"),l1l11l_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ㽠"))
	if not l1ll1111llll_l1_ and showDialogs: l1ll1l11l11l_l1_()
	return l1ll1111llll_l1_
def l1ll1l11l11l_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㽡"),l1l11l_l1_ (u"ࠧࠨ㽢"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㽣"),l1l11l_l1_ (u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨ㽤"))
	#l1lllll1111_l1_ = l1l11l_l1_ (u"ุࠪ์อฯสࠢส่ฯฺแ๋ำ๋ࠣ๏ࠦๅๅใࠣ๎าะ่๋ࠢ฼่๎ࠦิโำฬࠤำอีสࠢฦ์ࠥะ่ศไํ฽ࠥิวึหู่ࠣืใศฬ้ࠣ฾ื่โหࠣ์้ํࠠหษิ๎ำࠦีๅษะ๎ฮ่ࠦ็ใสิࠥ๎วๅ฼ิฺ๋ࠥๆ่๊ࠢ์ࠥะศศั็ࠤฬ๊ๅฺๆ๋้ฬะࠠษูิ๎็ฯࠠๆึไีฮ๊ࠦึ฻หࠤฬิสาษๅ๋ฬ่ࠦโ้่๋ฬ࠭㽥")
	l1ll1l1lll1l_l1_()
	return
def l1ll1l1llll1_l1_(text=l1l11l_l1_ (u"ࠫࠬ㽦")):
	l1llll11lll1_l1_ = True
	if l1l11l_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ㽧") not in text:
		l1llll11lll1_l1_ = False
		yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㽨"),l1l11l_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠬ㽩"),l1l11l_l1_ (u"ࠨวิืฬ๊ࠠๆึๆ่ฮ࠭㽪"),l1l11l_l1_ (u"ࠩࠪ㽫"),l1l11l_l1_ (u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อࠥลࠧ㽬"))
		if yes==1:
			l1llll11lll1_l1_ = True
			text = l1l11l_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ㽭")
	if l1llll11lll1_l1_:
		#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㽮"),l1l11l_l1_ (u"࠭ࠧ㽯"),l1l11l_l1_ (u"ࠧࠨ㽰"),l1l11l_l1_ (u"ࠨวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ㽱"),l1l11l_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦิฬฺ๎฾ࠦวๅ็หี๊าࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠวุ่ฬำ็ศࠩ㽲"))
		#if not yes:
		#	DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㽳"),l1l11l_l1_ (u"ࠫࠬ㽴"),l1l11l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ㽵"),l1l11l_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ㽶"))
		#	return
		l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡯ࡳ࡬ࡹ࠽ࡺࡧࡶࠫࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸ๊่ࠧ࠭ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ࠮ࠪๆอ๊ࠠศำึห้ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัูࠦๅ์ๆࠤฬ์ࠠหไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦว้ࠢส่ึอศุࠢส่ี๐๋ࠠ฻ฺ๎่ࠦวๅ็ื็้ฯࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊࠴่ࠠๆࠣฮึ๐ฯࠡษ็หึูวๅࠢส่ฬ์ࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠶࠺ࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆ฽หฦࠦวๅษิืฬ๊ࠧࠪࠌࠌࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࠮ࠪหีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไห้ืฬศรࠣๆึอมสࠢๅื๊ࠦวๅ็ืห่๊้ࠠษ็หุฬไส๋ࠢหีอࠠๅ็ࠣฮัีࠠศๆะ่ࠥํๆศๅࠣๅาอ่ๅࠢๆฮฬฮษࠡฮ่๎฾ࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠯ࠊࠊࠋࠥࠦࠧ㽷")
		if l1l11l_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ㽸") not in text:
			yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㽹"),l1l11l_l1_ (u"ࠪࠫ㽺"),l1l11l_l1_ (u"ࠫࠬ㽻"),l1l11l_l1_ (u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ㽼"),l1l11l_l1_ (u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭㽽"))
			if yes!=1:
				DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㽾"),l1l11l_l1_ (u"ࠨࠩ㽿"),l1l11l_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ㾀"),l1l11l_l1_ (u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭㾁"))
				return
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㾂"),l1l11l_l1_ (u"ࠬ࠭㾃"),l1l11l_l1_ (u"࠭ใหษหอࠥ๎ิาฯࠣห้๋่ื๊฼ࠤ้๊ๅษำ่ะࠬ㾄"),l1l11l_l1_ (u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไศ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ㾅"))
	search = OPEN_KEYBOARD(l1l11l_l1_ (u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩ㾆"))
	if not search: return
	message = search
	if l1llll11lll1_l1_: type = l1l11l_l1_ (u"ࠩ࠰ࡔࡷࡵࡢ࡭ࡧࡰࠫ㾇")
	else: type = l1l11l_l1_ (u"ࠪ࠱ࡒ࡫ࡳࡴࡣࡪࡩࠬ㾈")
	l111l11l1ll_l1_ = l1l11l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ㾉")+l1ll1l1l11l_l1_(32)+type
	succeeded = l11ll1llll1_l1_(l111l11l1ll_l1_,message,True,l1l11l_l1_ (u"ࠬ࠭㾊"),l1l11l_l1_ (u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩ㾋"),text)
	#	url = l1l11l_l1_ (u"ࠧ࡮ࡻࠣࡅࡕࡏࠠࡢࡰࡧ࠳ࡴࡸࠠࡔࡏࡗࡔࠥࡹࡥࡳࡸࡨࡶࠬ㾌")
	#	payload = l1l11l_l1_ (u"ࠨࡽࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ࠿ࠨࡍ࡚ࠢࡄࡔࡎࠦࡋࡆ࡛ࠥ࠰ࠧࡺ࡯ࠣ࠼࡞ࠦࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠥࡡ࠱ࠨࡳࡦࡰࡧࡩࡷࠨ࠺ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࠭ࠤࡶࡹࡧࡰࡥࡤࡶࠥ࠾ࠧࡌࡲࡰ࡯ࠣࡅࡷࡧࡢࡪࡥ࡚ࠣ࡮ࡪࡥࡰࡵࠥ࠰ࠧࡺࡥࡹࡶࡢࡦࡴࡪࡹࠣ࠼ࠥࠫ㾍")+message+l1l11l_l1_ (u"ࠩࠥࢁࠬ㾎")
	#	#auth=(l1l11l_l1_ (u"ࠥࡥࡵ࡯ࠢ㾏"), l1l11l_l1_ (u"ࠦࡲࡿࠠࡱࡧࡵࡷࡴࡴࡡ࡭ࠢࡤࡴ࡮ࠦ࡫ࡦࡻࠥ㾐")),
	#	import requests
	#	response = requests.request(l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ㾑"),url, data=payload, headers=l1l11l_l1_ (u"࠭ࠧ㾒"), auth=l1l11l_l1_ (u"ࠧࠨ㾓"))
	#	response = requests.l111l1llll_l1_(url, data=payload, headers=l1l11l_l1_ (u"ࠨࠩ㾔"), auth=l1l11l_l1_ (u"ࠩࠪ㾕"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㾖"),l1l11l_l1_ (u"ࠫࠬ㾗"),l1l11l_l1_ (u"ࠬ࠭㾘"),l1l11l_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ㾙"))
	#	else:
	#		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㾚"),l1l11l_l1_ (u"ࠨࠩ㾛"),l1l11l_l1_ (u"ࠩั฻ศࠦแ๋ࠢส่สืำศๆࠪ㾜"),l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡾࢁ࠿ࠦࡻࠢࡴࢀࠫ㾝").format(response.status_code, response.content))
	#	l1ll1111l1l1_l1_ = l1l11l_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ㾞")
	#	l1ll11l11l1l_l1_ = l1l11l_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ㾟")
	#	header = l1l11l_l1_ (u"࠭ࠧ㾠")
	#	#header += l1l11l_l1_ (u"ࠧࡇࡴࡲࡱ࠿ࠦࠧ㾡") + l1ll1111l1l1_l1_
	#	#header += l1l11l_l1_ (u"ࠨ࡞ࡱࡘࡴࡀࠠࠨ㾢") + l1l1ll11l1ll_l1_
	#	#header += l1l11l_l1_ (u"ࠩ࡟ࡲࡈࡩ࠺ࠡࠩ㾣") + l1l1ll11l1ll_l1_
	#	header += l1l11l_l1_ (u"ࠪࡠࡳ࡙ࡵࡣ࡬ࡨࡧࡹࡀࠠๆ่ࠣ็ํี๊ࠡษ็ๅ๏ี๊้ࠢส่฾ืศ๋ࠩ㾤")
	#	server = l1lll11l11l1_l1_.l1ll111l1l11_l1_(l1l11l_l1_ (u"ࠫࡸࡳࡴࡱ࠯ࡶࡩࡷࡼࡥࡳࠩ㾥"),25)
	#	#server.l1ll11ll1ll1_l1_()
	#	server.l1ll11llll11_l1_(l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ㾦"),l1l11l_l1_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ㾧"))
	#	response = server.l1ll1l1l11l1_l1_(l1ll1111l1l1_l1_,l1ll11l11l1l_l1_, header + l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㾨") + message)
	#	server.quit()
	return
def l1ll1ll11ll1_l1_():
	text = l1l11l_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ㾩")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㾪"),l1l11l_l1_ (u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪ㾫"),text,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ㾬"))
	text = l1l11l_l1_ (u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨ㾭")
	l1ll111l11_l1_(l1l11l_l1_ (u"࠭࡬ࡦࡨࡷࠫ㾮"),l1l11l_l1_ (u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬ㾯"),text,l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ㾰"))
	return
def l1ll11lll1l1_l1_(addon_id):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㾱"),l1l11l_l1_ (u"ࠪࠫ㾲"),l1l11l_l1_ (u"ࠫࠬ㾳"),addon_id)
	result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ㾴")+addon_id+l1l11l_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬ㾵"))
	refresh = True
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡸ࡮ࡵࡵ࡫࡯ࠎࠎࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡺࡥࡱࡨ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡡࡥࡦࡲࡲࡸ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍ࡮࡬ࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯ࡧࡻ࡭ࡸࡺࡳࠩࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠬ࠾ࠏࠏࠉࡴࡪࡸࡸ࡮ࡲ࠮ࡳ࡯ࡷࡶࡪ࡫ࠨࡹࡤࡰࡧ࡫࡯࡬ࡦࠫࠍࠍࠎࡸࡥࡧࡴࡨࡷ࡭ࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࡶࡵࡨࡶ࡫࡯࡬ࡦࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡹࡸ࡫ࡲࡧࡱ࡯ࡨࡪࡸࠬࠨࡣࡧࡨࡴࡴࡳࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠏࠏࡩࡧࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱ࡩࡽ࡯ࡳࡵࡵࠫࡹࡸ࡫ࡲࡧ࡫࡯ࡩ࠮ࡀࠊࠊࠋࡶ࡬ࡺࡺࡩ࡭࠰ࡵࡱࡹࡸࡥࡦࠪࡸࡷࡪࡸࡦࡪ࡮ࡨ࠭ࠏࠏࠉࡳࡧࡩࡶࡪࡹࡨࠡ࠿ࠣࡘࡷࡻࡥࠋࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࡩ࡯࡯ࡰࠣࡁࠥࡹࡱ࡭࡫ࡷࡩ࠸࠴ࡣࡰࡰࡱࡩࡨࡺࠨࡢࡦࡧࡳࡳࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࡦࡳࡳࡴ࠮ࡵࡧࡻࡸࡤ࡬ࡡࡤࡶࡲࡶࡾࠦ࠽ࠡࡵࡷࡶࠏࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡣࡧࡨࡴࡴࡳ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࠦࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡲࡦࡲࡲࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠣࠤࠥ㾶")
	if refresh:
		time.sleep(1)
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ㾷"))
		time.sleep(1)
	return
def l1l1ll1l1l1l_l1_(l1lll1l1lll1_l1_):
	import os
	for root,dirs,files in os.walk(l1lll1l1lll1_l1_,topdown=False):
		for name in files:
			try: os.remove(os.path.join(root,name))
			except: pass
	for name in dirs: os.rmdir(os.path.join(root,name))
	return
def l1ll1l1ll1l1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㾸"),l1l11l_l1_ (u"ࠪࠫ㾹"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㾺"),l1l11l_l1_ (u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪ㾻"))
	l1ll1l1lll11_l1_()
	return
def l1ll1l1lll1l_l1_():
	#	l11l11l_l1_://l11lll1111l_l1_.tv/download/849
	#   l11l11l_l1_://play.l1lll1l11lll_l1_.l11111ll_l1_/l1ll111lll11_l1_/l1ll11l11l11_l1_/l1llll111111_l1_?id=l111lll11l_l1_.xbmc.l11lll1111l_l1_
	#	http://mirror.l1ll1l1l1l1l_l1_.l1lll11l1l1l_l1_.l1lll1l11l1l_l1_/l1ll1l11lll1_l1_/xbmc/l1ll111ll111_l1_/l1l1ll1l11l1_l1_/l1ll1l1l111l_l1_
	#	http://l1l1lllll1ll_l1_.l1l1lll111l1_l1_.l1lll1l11l1l_l1_/l11lll1111l_l1_/l1ll111ll111_l1_/l1l1ll1l11l1_l1_/l1ll1l1l111l_l1_
	url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫ㾼")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㾽"),url,l1l11l_l1_ (u"ࠨࠩ㾾"),l1l11l_l1_ (u"ࠩࠪ㾿"),l1l11l_l1_ (u"ࠪࠫ㿀"),l1l11l_l1_ (u"ࠫࠬ㿁"),l1l11l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨ㿂"))
	html = response.content
	l1l1ll1llll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬ㿃"),html,re.DOTALL)
	l1l1ll1llll1_l1_ = l1l1ll1llll1_l1_[0].split(l1l11l_l1_ (u"ࠧ࠮ࠩ㿄"))[0]
	l1lll11lllll_l1_ = str(kodi_version)
	#l11l11lll11_l1_ = l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㿅")+l1l11l_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠ฻ู่่๋ࠥࠡๅ๋ำ๏ࠦลึัสีࠥ࠷࠹๊่ࠡหࠥฮูะ้ࠪ㿆")+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㿇")
	l11l11lll11_l1_ = l1l11l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭㿈")+l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㿉")+l1l1ll1llll1_l1_+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㿊")
	l11l11lll11_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㿋")+l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ㿌")+l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㿍")+l1lll11lllll_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㿎")
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㿏"),l1l11l_l1_ (u"ࠬ࠭㿐"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㿑"),l11l11lll11_l1_)
	return
def l1ll11111111_l1_():
	# l11l11l_l1_://l1lll1l11ll1_l1_-l1ll11111lll_l1_-l1ll11l1l1ll_l1_.l1ll1l1lllll_l1_.l11111ll_l1_/request-l1ll11l1llll_l1_
	# l11l11l_l1_://l1lll1l11ll1_l1_-l1ll11111lll_l1_-l1ll11l1l1ll_l1_.l1ll1l1lllll_l1_.l11111ll_l1_/query-l1l1lll11111_l1_
	l1llll1llll_l1_,l1lllll1111_l1_,l11l11ll1ll_l1_,l11l11lll11_l1_,l1ll1ll111l1_l1_,l1l1lll1l11l_l1_,l1ll111l1l1l_l1_ = l1l11l_l1_ (u"ࠧࠨ㿒"),l1l11l_l1_ (u"ࠨࠩ㿓"),l1l11l_l1_ (u"ࠩࠪ㿔"),l1l11l_l1_ (u"ࠪࠫ㿕"),l1l11l_l1_ (u"ࠫࠬ㿖"),l1l11l_l1_ (u"ࠬ࠭㿗"),l1l11l_l1_ (u"࠭ࠧ㿘")
	payload,l1l1lll1111l_l1_,l1ll1l11ll1l_l1_,l1l1ll1l1l11_l1_ = {l1l11l_l1_ (u"ࠧࡢࠩ㿙"):l1l11l_l1_ (u"ࠨࡣࠪ㿚")},{},[],{}
	url = WEBSITES[l1l11l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㿛")][1]
	response = OPENURL_REQUESTS_CACHED(l1l11ll11ll_l1_,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㿜"),url,payload,l1l11l_l1_ (u"ࠫࠬ㿝"),l1l11l_l1_ (u"ࠬ࠭㿞"),l1l11l_l1_ (u"࠭ࠧ㿟"),l1l11l_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ㿠"))
	html = response.content
	html = html.replace(l1l11l_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨ㿡"),l1l11l_l1_ (u"ࠩࡘࡗࡆ࠭㿢"))
	html = html.replace(l1l11l_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ㿣"),l1l11l_l1_ (u"࡚ࠫࡑࠧ㿤"))
	html = html.replace(l1l11l_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬ㿥"),l1l11l_l1_ (u"࠭ࡕࡂࡇࠪ㿦"))
	html = html.replace(l1l11l_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭㿧"),l1l11l_l1_ (u"ࠨࡍࡖࡅࠬ㿨"))
	html = html.replace(l1l11l_l1_ (u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ㿩"),l1l11l_l1_ (u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ㿪"))
	html = html.replace(l1l11l_l1_ (u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ㿫"),l1l11l_l1_ (u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ㿬"))
	html = html.replace(l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ㿭"),l1l11l_l1_ (u"ࠧࠡࠢࠪ㿮"))
	try: l1ll1l11ll11_l1_ = EVAL(l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㿯"),html)
	except:
		DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㿰"),l1l11l_l1_ (u"ࠪࠫ㿱"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㿲"),l1l11l_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ㿳"))
		return
	l1lll11l111l_l1_,l1lll1l11l11_l1_,l1ll11l1l11l_l1_ = l1ll1l11ll11_l1_
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ㿴"),str(l1lll11l111l_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ㿵"),str(l1lll1l11l11_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ㿶"),str(l1ll11l1l11l_l1_))
	l1l1ll1l1l11_l1_ = {}
	for site,l1lll11l11ll_l1_,l1ll1llllll1_l1_ in l1lll1l11l11_l1_:
		l1ll1llllll1_l1_ = escapeUNICODE(l1ll1llllll1_l1_)
		l1ll1llllll1_l1_ = l1ll1llllll1_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫ㿷")).strip(l1l11l_l1_ (u"ࠪࠤ࠳࠭㿸"))
		l11l11lll11_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㿹")+site+l1l11l_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㿺")+l1ll1llllll1_l1_+l1l11l_l1_ (u"࠭࡜࡯ࠩ㿻")
		if l1lll11l11ll_l1_.isdigit():
			l1l1ll1l1l11_l1_[site] = int(l1lll11l11ll_l1_)
			if int(l1lll11l11ll_l1_)>100: l1lll11l11ll_l1_ = l1l11l_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ㿼")
			else: l1lll11l11ll_l1_ = l1l11l_l1_ (u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ㿽")
		if site not in [l1l11l_l1_ (u"ࠩࡄࡐࡑ࠭㿾"),l1l11l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㿿"),l1l11l_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ䀀"),l1l11l_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ䀁"),l1l11l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ䀂")]:
			if   l1lll11l11ll_l1_==l1l11l_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ䀃"): l1llll1llll_l1_ += l1l11l_l1_ (u"ࠨࠢࠣࠫ䀄")+site
			elif l1lll11l11ll_l1_==l1l11l_l1_ (u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫ䀅"): l1lllll1111_l1_ += l1l11l_l1_ (u"ࠪࠤࠥ࠭䀆")+site
	l1lll11l1ll1_l1_,l1ll111l1111_l1_,l1ll111l1ll1_l1_ = list(zip(*l1lll1l11l11_l1_))
	for site in sorted(l1l1l1lll11_l1_):
		if site not in l1lll11l1ll1_l1_:
			l11l11lll11_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䀇")+site+l1l11l_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䀈")+l1l11l_l1_ (u"࠭ไศࠢํ์ัีࠧ䀉")+l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䀊")
			if site not in [l1l11l_l1_ (u"ࠨࡃࡏࡐࠬ䀋"),l1l11l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ䀌"),l1l11l_l1_ (u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ䀍"),l1l11l_l1_ (u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ䀎"),l1l11l_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ䀏")]: l11l11ll1ll_l1_ += l1l11l_l1_ (u"࠭ࠠࠡࠩ䀐")+site
	for l1ll1llllll1_l1_,counts in l1lll11l111l_l1_:
		l1ll1llllll1_l1_ = escapeUNICODE(l1ll1llllll1_l1_)
		l1ll1ll111l1_l1_ += l1ll1llllll1_l1_+l1l11l_l1_ (u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䀑")+str(counts)+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭䀒")
	l1llll1llll_l1_ = l1llll1llll_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫ䀓"))
	l1lllll1111_l1_ = l1lllll1111_l1_.strip(l1l11l_l1_ (u"ࠪࠤࠬ䀔"))
	l11l11ll1ll_l1_ = l11l11ll1ll_l1_.strip(l1l11l_l1_ (u"ࠫࠥ࠭䀕"))
	l11l11llll1_l1_ = l1llll1llll_l1_+l1l11l_l1_ (u"ࠬࠦࠠࠨ䀖")+l1lllll1111_l1_
	#l11111l1ll1_l1_  = l1l11l_l1_ (u"࠭࡜࡯ࡊ࡬࡫࡭࡛ࡳࡢࡩࡨ࠾ࠥࡡࠠࠨ䀗")+l1llll1llll_l1_+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ䀘")
	#l11111l1ll1_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱࡐࡴࡽࡕࡴࡣࡪࡩࠥࡀࠠ࡜ࠢࠪ䀙")+l1lllll1111_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠬ䀚")
	#l11111l1ll1_l1_ += l1l11l_l1_ (u"ࠪࡠࡳࡔ࡯ࡖࡵࡤ࡫ࡪࠦࠠ࠻ࠢ࡞ࠤࠬ䀛")+l11l11ll1ll_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠧ䀜")
	l11l11lll1l_l1_  = l1l11l_l1_ (u"๋่ࠬศไ฼ࠤูเไࠡ็้๋ฬࠦวๅสิ๊ฬ๋ฬࠡ์๋้ࠥอไษษิัฮࠦแ๋ัํ์์อสࠡสา์๋ࠦๅีษๆ่ࠬ䀝")+l1l11l_l1_ (u"࠭࡜࡯ࠩ䀞")+l1l11l_l1_ (u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠬ䀟")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䀠")
	l11l11lll1l_l1_ += l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䀡")+l11l11llll1_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ䀢")
	l11l11lll1l_l1_ += l1l11l_l1_ (u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤ๏๎ๅࠡษ็ฬฬือสࠢฦ๎ࠥ็๊ะ์๋๋ฬะࠧ䀣")+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䀤")+l1l11l_l1_ (u"่่࠭าสࠤ๊฿ๆศ้ࠣหาะๅศๆࠣ็อ๐ั๊ࠡฯ์ิࠦๅีๅ็อࠥ็๊ࠡษ็ฬึ์วๆฮࠪ䀥")+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䀦")
	l11l11lll1l_l1_ += l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䀧")+l11l11ll1ll_l1_+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀨")
	l1lll111ll11_l1_,l1ll111111l1_l1_,l1ll1l1l1l11_l1_,l1l1lllll11l_l1_ = 0,0,0,0
	all = l1l1ll1l1l11_l1_[l1l11l_l1_ (u"ࠪࡅࡑࡒࠧ䀩")]
	if l1l11l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䀪") in list(l1l1ll1l1l11_l1_.keys()): l1lll111ll11_l1_ = l1l1ll1l1l11_l1_[l1l11l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ䀫")]
	if l1l11l_l1_ (u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ䀬") in list(l1l1ll1l1l11_l1_.keys()): l1ll111111l1_l1_ = l1l1ll1l1l11_l1_[l1l11l_l1_ (u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ䀭")]
	if l1l11l_l1_ (u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ䀮") in list(l1l1ll1l1l11_l1_.keys()): l1ll1l1l1l11_l1_ = l1l1ll1l1l11_l1_[l1l11l_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭䀯")]
	if l1l11l_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ䀰") in list(l1l1ll1l1l11_l1_.keys()): l1l1lllll11l_l1_ = l1l1ll1l1l11_l1_[l1l11l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ䀱")]
	videos_count = all-l1lll111ll11_l1_-l1ll111111l1_l1_-l1ll1l1l1l11_l1_-l1l1lllll11l_l1_
	dummy,l1ll1l111lll_l1_ = l1ll11l1l11l_l1_[0]
	dummy,l1l1lll1ll1l_l1_ = l1ll11l1l11l_l1_[1]
	l1ll11l11ll1_l1_ = l1ll1l111lll_l1_-l1l1lll1ll1l_l1_
	l1ll111l1l1l_l1_ += l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䀲")+str(l1l1lll1ll1l_l1_)+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䀳")+l1l11l_l1_ (u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫ䀴")
	l1ll111l1l1l_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䀵")+str(l1ll11l11ll1_l1_)+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀶")+l1l11l_l1_ (u"ࠪฬฬูสฯัส้ࠥࡶࡲࡰࡺࡼࠤศ๎ࠠࡷࡲࡱࠤ࠿ࠦࠧ䀷")
	l1ll111l1l1l_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䀸")+str(l1ll1l111lll_l1_)+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䀹")+l1l11l_l1_ (u"࠭วๅ฻าำࠥอไไๆํࠤ้าๅ๋฻ࠣห้ษฬ่ิฬࠤ࠿ࠦࠧ䀺")
	l1ll111l1l1l_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䀻")+str(len(l1ll11l1l11l_l1_[2:]))+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䀼")+l1l11l_l1_ (u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧ䀽")
	for country,l1ll1l11l1l1_l1_ in l1ll11l1l11l_l1_[2:]:
		country = escapeUNICODE(country)
		country = country.strip(l1l11l_l1_ (u"ࠪࠤࠬ䀾")).strip(l1l11l_l1_ (u"ࠫࠥ࠴ࠧ䀿"))
		l1ll111l1l1l_l1_ += country+l1l11l_l1_ (u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䁀")+str(l1ll1l11l1l1_l1_)+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫ䁁")
	#l1ll111l1l1l_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰ࠱ࠫ䁂")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䁃")+str(videos_count)+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䁄")+l1l11l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥอิห฼็ฮࠥࡀࠠࠨ䁅")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䁆")+str(l1lll111ll11_l1_)+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䁇")+l1l11l_l1_ (u"࠭ืๅสสฮู๊ࠥาใิࠤออ๊ฬ๊้ࠤ࠿ࠦࠧ䁈")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䁉")+str(l1l1lllll11l_l1_)+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䁊")+l1l11l_l1_ (u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่าฬุๆࠡ࠼ࠣࠫ䁋")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䁌")+str(l1ll111111l1_l1_)+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䁍")+l1l11l_l1_ (u"ࠬะหษ์อࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิࠦ࠺ࠡࠩ䁎")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䁏")+str(l1ll1l1l1l11_l1_)+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䁐")+l1l11l_l1_ (u"ࠨฬฮฬ๏ะࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠿ࠦࠧ䁑")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䁒")+str(len(l1lll11l111l_l1_))+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䁓")+l1l11l_l1_ (u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫ䁔")
	#l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䁕")+l1l11l_l1_ (u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦวๅ฻ส่๊๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ䁖")+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䁗")
	l1l1lll1l11l_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䁘")+l1ll1ll111l1_l1_
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䁙"),l1l11l_l1_ (u"ࠪ฽ิีࠠศๆฦะ์ุษࠡษ็ฮ๏ࠦวิฬัำ๊ะ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢส่฾อไๆࠢํ์๊ࠦรๆีࠣࠬฬ๊ศศำะอ࠮࠭䁚"),l1ll111l1l1l_l1_,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ䁛"))
	#l1ll111l11_l1_(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䁜"),l1l11l_l1_ (u"࠭ฬๆ์฼ࠤ์ึ็ࠡษ็วึ่วๆࠢอาฺࠦริฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦࠠโไฺࠤ๏๎ๅࠡล่ืࠥ࠮วๅสสีาฯࠩࠨ䁝"),l1l1lll1l11l_l1_,l1l11l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ䁞"))
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䁟"),l1l11l_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢส่฾อไๆࠢํ์๊ࠦรๆีࠣࠬฬ๊ศศำะอ࠮࠭䁠"),l1l1lll1l11l_l1_,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭䁡"))
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䁢"),l1l11l_l1_ (u"๋่ࠬศไ฼ࠤฬฺส฻ๆอࠤ๏๎ๅࠡษ็ฬฬือสࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠧ䁣"),l11l11lll1l_l1_,l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ䁤"))
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ䁥"),l1l11l_l1_ (u"ࠨล฼่๎ࠦวๅั๋่ࠥอไห์ࠣ๎ํ๋ࠠศๆหหึำษࠡษึฮำีๅหࠢส่อืๆศ็ฯࠫ䁦"),l11l11lll11_l1_,l1l11l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ䁧"))
	return
def l1ll111ll11l_l1_():
	message = l1l11l_l1_ (u"๋ࠪีอࠠศๆหี๋อๅอࠢํ฽๊๊ࠠศใู่ࠥฮวิฬัำฬ๋ࠠอๆาࠤ่๎ฯ๋ࠢࠫࡏࡴࡪࡩࠡࡕ࡮࡭ࡳ࠯ࠠศๆำ๎ࠥอำๆ้࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥ๎ๅๆๅ้ࠤฯัศ๋ฬ๊ࠤออำหะาห๊ࠦๅฯิ้ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ่ࠠา๊ࠤฬ๊ัิษ็อࠥ๎ฺ๋ำ๊ห้ࠥห๋ำ้ࠣํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั่ࠦศๆ่ึ๏ีࠠฤ์ูห๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦรอ๊หอࠥอไษำ้ห๊าࠧ䁨")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䁩"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䁪"),message,l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ䁫"))
	return
def l1lll11111l1_l1_():
	message = l1l11l_l1_ (u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅฯิ้ࠤ฾๋วะ๋ࠢๅ๏ํࠠฤ์ูหࠥาๅ๋฻ࠣห฾ีวะฬࠣ็ํี๊ࠡษ็้฼๊่ษห่ࠣ฾๋ไࠡสิ๊ฬ๋ฬࠡ฻่หิ่ࠦไๆ๊หࠥะสๆࠢส์ฯ๎ๅศฬํ็๏อ้ࠠๆสࠤฯำสศฮࠣว๏ࠦๆ้฻้๋ࠣࠦวๅะหีฮࠦแ๋ࠢๆ์ิ๐ࠠฤ๊ࠣห้ิศาหࠣๅ๏ࠦสฬสํฮࠥษึศใสฮ้่ࠥะ์ࠪ䁬")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䁭")+l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䁮")+WEBSITES[l1l11l_l1_ (u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ䁯")][0]+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䁰")+WEBSITES[l1l11l_l1_ (u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ䁱")][1]+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䁲")
	message += l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼๐ๆࠡลา๊ฬํ่ࠠ็สࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䁳")+WEBSITES[l1l11l_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ䁴")][0]+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䁵")+WEBSITES[l1l11l_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ䁶")][1]+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䁷")
	message += l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ䁸")+l1l11l_l1_ (u"࠭࡜࡯ࠩ䁹")+l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䁺")+WEBSITES[l1l11l_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ䁻")][0]+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䁼")
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䁽"),l1l11l_l1_ (u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ䁾"),message,l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ䁿"))
	return
def l1lll1111111_l1_(l1lll1111l1l_l1_):
	xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬ䂀")+l1lll1111l1l_l1_+l1l11l_l1_ (u"ࠧࠪࠩ䂁"), True)
	return
def l1ll1lll1lll_l1_():
	l1llll1l1_l1_(l1l11l_l1_ (u"ࠨࡵࡷࡳࡵ࠭䂂"))
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣ䂃"))
	return
def l1ll11l1l111_l1_():
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩ䂄"), True)
	return
def l1ll1ll1111l_l1_(showDialogs=True):
	if not showDialogs: yes = True
	else: yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䂅"),l1l11l_l1_ (u"ࠬ࠭䂆"),l1l11l_l1_ (u"࠭ࠧ䂇"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䂈"),l1l11l_l1_ (u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡษ็ฦ๋ࠦฟࠨ䂉"))
	if yes==1:
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬ䂊"))
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䂋"),l1l11l_l1_ (u"ࠫࠬ䂌"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䂍"),l1l11l_l1_ (u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆะี๊ࠥ฿ๅศัࠣ࠲ࠥ๐ัอ๋ࠣษ฾฽วยࠢๆ์ิ๐ࠠ࠶ࠢาๆฬฬโࠡล๋ࠤศ้หาࠢ็็๏๊ࠦ็้ํࠤ฾๋ไ๋หࠣห้ะอะ์ฮࠫ䂎"))
		settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ䂏"),l1l11l_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ䂐"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭䂑"))
	l1ll111l111_l1_ = (not yes)
	return l1ll111l111_l1_
def l1ll1111ll1l_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䂒"),l1l11l_l1_ (u"ࠫࠬ䂓"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䂔"),l1l11l_l1_ (u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣ์ศ๋วࠡสสืฯิฯศ็ࠣࠦฬ๊ใ๋ส๋ีิࠨࠠโษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠨ䂕"))
	return
def l1ll1ll1lll1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䂖"),l1l11l_l1_ (u"ࠨࠩ䂗"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䂘"),l1l11l_l1_ (u"่้ࠪะูศ็็ࠤ๊฿ࠠศๆ่ๅ฻๊ษࠡ࠰ࠣหีํศࠡว็ํࠥอไาษห฻ࠥอไั์ࠣฮึ๐ฯࠡวูหๆะ็ࠡล๋ࠤู๊อ่่๊ࠢࠥࠦโศศ่อࠥอไๆใู่ฮ่ࠦๅๅ้ࠤ้อࠠหุ฽฻ࠥ฿ไ๋้ࠣ์้อࠠหึ฽่์ࠦ࠮๊ࠡหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํษๅศࠢหหุะฮะษ่ࠤࠧอไไ์ห์ึีࠢࠡใสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํ์แิࠢส่่๊วๆ๋ࠢห้฽ั๋ไฬࠤ฾์ฯࠡษ็ฮ฾อๅๅ่ࠢ฽๋ࠥอห๊ํหฯࠦโ้ษษ้ࠥอไๆใู่ฮ࠭䂙"))
	return
#l1lll111l111_l1_ 	  required	and l1lll111l111_l1_     installed	and		not l1ll111l111_l1_		ignore
#l1lll111l111_l1_ not required	and	l1lll111l111_l1_ not installed 	and 	    l1ll111l111_l1_		ignore
#l1lll111l111_l1_ not required	and	l1lll111l111_l1_ not installed 	and 	not l1ll111l111_l1_		ignore
#l1lll111l111_l1_ not required	and	l1lll111l111_l1_     installed 	and 	not l1ll111l111_l1_		ignore
#l1lll111l111_l1_     required	and	l1lll111l111_l1_ not installed 	and 	    l1ll111l111_l1_		l11ll11l11_l1_ l1ll111111l1_l1_	l1ll1ll111ll_l1_
#l1lll111l111_l1_     required	and	l1lll111l111_l1_ not installed 	and 	not l1ll111l111_l1_		l11ll11l11_l1_ l1ll111111l1_l1_	l1ll1ll111ll_l1_
#l1lll111l111_l1_     required 	and l1lll111l111_l1_     installed 	and 	    l1ll111l111_l1_		l11ll11l11_l1_ l1lll11llll1_l1_	l1ll1ll111ll_l1_
#l1lll111l111_l1_ not required	and	l1lll111l111_l1_     installed 	and 	    l1ll111l111_l1_		l11ll11l11_l1_ l1lll11llll1_l1_	l1ll1ll111ll_l1_
#cond1: required and not installed: l11ll11l11_l1_ l1ll111111l1_l1_
#cond2: installed and l11ll11l11_l1_ update: l11ll11l11_l1_ l1lll11llll1_l1_
def l1ll1lll111l_l1_(showDialogs=True):
	l1llll1l1l11_l1_ = l1ll11lll11l_l1_([l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭䂚")])
	l1ll1l1l11ll_l1_ = []
	for addon_id in [l1l11l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ䂛")]:
		if addon_id not in list(l1llll1l1l11_l1_.keys()): continue
		l1ll111l111_l1_,l1ll1111111_l1_,l1l1ll1l1lll_l1_,l1ll1ll1l1ll_l1_,l1ll1ll11lll_l1_,l1l1lll11l11_l1_,l1ll1ll1l11l_l1_ = l1llll1l1l11_l1_[addon_id]
		if not l1ll1111111_l1_ or (l1ll1111111_l1_ and l1ll111l111_l1_): l1ll1l1l11ll_l1_.append(addon_id)
	l1l1ll11lll1_l1_ = len(l1ll1l1l11ll_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1ll1ll1ll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1ll1lll11l1_l1_ = []
	for addon_id in l1lll1l1ll1l_l1_:
		cc.execute(l1l11l_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤࠧ࠷ࠢࠡࡣࡱࡨࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ䂜")+addon_id+l1l11l_l1_ (u"ࠧࠣࠢ࠾ࠫ䂝"))
		rows = cc.fetchall()
		if rows: l1ll1lll11l1_l1_.append(addon_id)
	l1ll11l1111l_l1_ = len(l1ll1lll11l1_l1_)>0
	for addon_id in l1ll1ll1ll11_l1_:
		cc.execute(l1l11l_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡱࡵ࡭࡬࡯࡮ࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭䂞")+addon_id+l1l11l_l1_ (u"ࠩࠥࠤࡀ࠭䂟"))
		l1lll1l1llll_l1_ = cc.fetchall()
		if l1lll1l1llll_l1_ and l1l11l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ䂠") not in str(l1lll1l1llll_l1_): l1ll1l1l11ll_l1_.append(addon_id)
	l1ll11111l1l_l1_ = len(l1ll1l1l11ll_l1_)>0
	l1ll1l1l11ll_l1_ = list(set(l1ll1l1l11ll_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ䂡"),l1l11l_l1_ (u"ࠬࡴࡥࡦࡦࡢࡪ࡮ࡾࡩ࡯ࡩࡢࡶࡪࡶ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰ࠽ࠤࠥ࠭䂢")+str(l1l1ll11lll1_l1_))
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ䂣"),l1l11l_l1_ (u"ࠧ࡯ࡧࡨࡨࡤࡪࡥ࡭ࡧࡷ࡭ࡳ࡭࡟ࡰ࡮ࡧࡣࡦࡪࡤࡰࡰࡶ࠾ࠥࠦࠧ䂤")+str(l1ll11l1111l_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ䂥"),l1l11l_l1_ (u"ࠩࡱࡩࡪࡪ࡟ࡧ࡫ࡻ࡭ࡳ࡭࡟ࡰࡴ࡬࡫࡮ࡴ࠺ࠡࠢࠪ䂦")+str(l1ll11111l1l_l1_))
	l1ll111l111_l1_ = False
	if l1ll11l1111l_l1_ or l1ll11111l1l_l1_:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䂧"),l1l11l_l1_ (u"ࠫࠬ䂨"),l1l11l_l1_ (u"ࠬ࠭䂩"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䂪"),l1l11l_l1_ (u"ࠧศๆหี๋อๅอ๋ࠢะิࠦๅีๅ็อࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰࠱࠲่ࠥฯࠡ์ๆ์๋ࠦๅฺู็ࠤศ๎ࠠๅษࠣ๎฾๋ไࠡสุ์ึฯࠠึฯํัฮࠦ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢส่ว์ࠠภ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䂫"))
		if yes==1:
			l1lll11ll111_l1_ = True
			if l1l1ll11lll1_l1_:
				l1lll11ll111_l1_ = l1lll1l11111_l1_(False)
			l1l1llll11l1_l1_ = True
			if l1ll11l1111l_l1_:
				for addon_id in l1ll1lll11l1_l1_: l1ll11lll1l1_l1_(addon_id)
				l1l1llll11l1_l1_ = True
			l1ll11ll11l1_l1_ = True
			if l1ll11111l1l_l1_:
				conn = sqlite3.connect(l1ll1ll1ll1l_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1ll1l1l11ll_l1_:
					if l1l11l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫ䂬") in addon_id: l1lll1l1llll_l1_ = addon_id
					else: l1lll1l1llll_l1_ = l1l11l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ䂭")
					try: cc.execute(l1l11l_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧ䂮")+l1lll1l1llll_l1_+l1l11l_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ䂯")+addon_id+l1l11l_l1_ (u"ࠬࠨࠠ࠼ࠩ䂰"))
					except: l1ll11ll11l1_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ䂱"))
			time.sleep(1)
			if l1lll11ll111_l1_ or l1l1llll11l1_l1_ or l1ll11ll11l1_l1_:
				l1ll111l111_l1_ = False
				DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䂲"),l1l11l_l1_ (u"ࠨࠩ䂳"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䂴"),l1l11l_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥะแฺ์็ࠤํหีๅษะࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅฮ่๎฾ࠦลืษไหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ䂵"))
			else:
				l1ll111l111_l1_ = True
				DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䂶"),l1l11l_l1_ (u"ࠬ࠭䂷"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䂸"),l1l11l_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫ䂹"))
	elif showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䂺"),l1l11l_l1_ (u"ࠩࠪ䂻"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䂼"),l1l11l_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅีๅ็อࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ䂽"))
	return l1ll111l111_l1_
def l1ll111111ll_l1_():
	l1ll111lll1l_l1_,l1lll111ll1l_l1_,l1l1ll1lll1l_l1_ = False,l1l11l_l1_ (u"ࠬ࠭䂾"),l1l11l_l1_ (u"࠭ࠧ䂿")
	l1lll111l11l_l1_,l1ll11ll11ll_l1_,l1ll1l111ll1_l1_ = False,l1l11l_l1_ (u"ࠧࠨ䃀"),l1l11l_l1_ (u"ࠨࠩ䃁")
	l1llll1l1l11_l1_ = l1ll11lll11l_l1_([l1l11l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ䃂"),l1l11l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ䃃"),l1l11l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ䃄")])
	for addon_id in [l1l11l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ䃅"),l1l11l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ䃆"),l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭䃇")]:
		if addon_id not in list(l1llll1l1l11_l1_.keys()): continue
		l1ll111l111_l1_,l1ll1111111_l1_,l1ll111l1ll_l1_,l1ll11lll1l_l1_,l1ll11llll1_l1_,l1lll1l111ll_l1_,l1ll1l1111l_l1_ = l1llll1l1l11_l1_[addon_id]
		if addon_id==l1l11l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭䃈"):
			l1lll111l11l_l1_ = l1ll111l111_l1_
			l1ll11ll11ll_l1_ = l1l11l_l1_ (u"ࠩࠫࠫ䃉")+l1ll1111111_l1_+l1l11l_l1_ (u"ࠪࠤࠬ䃊")+TRANSLATE(l1lll1l111ll_l1_)+l1l11l_l1_ (u"ࠫ࠮࠭䃋")
			l1ll1l111ll1_l1_ = l1ll11lll1l_l1_
		elif addon_id==l1l11l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ䃌"):
			l1ll111lll1l_l1_ = l1ll111lll1l_l1_ or l1ll111l111_l1_
			l1lll111ll1l_l1_ += l1l11l_l1_ (u"࠭ࠠࠡ࠮ࠣࠤ࠭࠭䃍")+l1ll1111111_l1_+l1l11l_l1_ (u"ࠧࠡࠩ䃎")+TRANSLATE(l1lll1l111ll_l1_)+l1l11l_l1_ (u"ࠨࠫࠪ䃏")
			l1l1ll1lll1l_l1_ += l1l11l_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ䃐")+l1ll11lll1l_l1_
		elif addon_id==l1l11l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ䃑"):
			l1ll111ll1ll_l1_ = l1ll111l111_l1_
			l1ll111l11l1_l1_ = l1l11l_l1_ (u"ࠫ࠭࠭䃒")+l1ll1111111_l1_+l1l11l_l1_ (u"ࠬࠦࠧ䃓")+TRANSLATE(l1lll1l111ll_l1_)+l1l11l_l1_ (u"࠭ࠩࠨ䃔")
			l1l1ll1l1111_l1_ = l1ll11lll1l_l1_
	l1lll111ll1l_l1_ = l1lll111ll1l_l1_.strip(l1l11l_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭䃕"))
	l1l1ll1lll1l_l1_ = l1l1ll1lll1l_l1_.strip(l1l11l_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ䃖"))
	text1  = l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䃗")+l1ll1l111ll1_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䃘")
	text1 += l1l11l_l1_ (u"ࠫࡡࡴࠧ䃙")+l1l11l_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䃚")+l1ll11ll11ll_l1_+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䃛")
	text1 += l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䃜")+l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅ็ัึู๋ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䃝")+l1l1ll1lll1l_l1_+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䃞")
	text1 += l1l11l_l1_ (u"ࠪࡠࡳ࠭䃟")+l1l11l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไๆะี๊ࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䃠")+l1lll111ll1l_l1_+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䃡")
	text1 += l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࠫ䃢")+l1l11l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䃣")+l1l1ll1l1111_l1_+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䃤")
	text1 += l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䃥")+l1l11l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䃦")+l1ll111l11l1_l1_+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䃧")
	l1ll111l111_l1_ = (l1lll111l11l_l1_ or l1ll111lll1l_l1_)
	if l1ll111l111_l1_:
		header = l1l11l_l1_ (u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧ䃨")
		text2 = l1l11l_l1_ (u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢาื์ฺࠠ็สำࠬ䃩")
	else:
		header = l1l11l_l1_ (u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤ๊้ࠣำุๆࠡ฻่หิ࠭䃪")
		text2 = l1l11l_l1_ (u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪ䃫")
	text3 = l1l11l_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱ้ำุๆࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨ䃬")
	l1ll111l111l_l1_ = text1+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䃭")+text2+l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䃮")+text3
	l1ll111l11_l1_(l1l11l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䃯"),header,l1ll111l111l_l1_,l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ䃰"))
	return
def l1ll1l11llll_l1_(showDialogs=True,l1ll1111l111_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ䃱"),l1l11l_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ䃲"))
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ䃳"),l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ䃴"))
	if showDialogs:
		l1ll111111ll_l1_()
		l1ll1l1lll1l_l1_()
	if l1ll1111l111_l1_:
		l1l1llll1111_l1_ = l1ll1lll111l_l1_(False)
		l1l1lll1llll_l1_ = l1ll1ll1111l_l1_(showDialogs)
		if not (l1l1llll1111_l1_ or l1l1lll1llll_l1_):
			settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ䃵"),l1l11l_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ䃶"))
			xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䃷"))
	return
def l1lll1l11111_l1_(showDialogs=True):
	l1llll1l1l11_l1_ = l1ll11lll11l_l1_([l1l11l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ䃸")])
	yes,l1lll111l1ll_l1_,l1lll1l1l11l_l1_ = True,True,True
	for addon_id in [l1l11l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ䃹")]:
		l1ll111l111_l1_,l1ll1111111_l1_,l1ll111l1ll_l1_,l1ll11lll1l_l1_,l1ll11llll1_l1_,l1lll1l111ll_l1_,l1ll1l1111l_l1_ = l1llll1l1l11_l1_[addon_id]
		if l1ll111l111_l1_:
			l1lll111l1ll_l1_ = False
			break
	if l1lll111l1ll_l1_:
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䃺"),l1l11l_l1_ (u"ࠪࠫ䃻"),l1l11l_l1_ (u"ࠫๆำีࠡ็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭䃼"),l1l11l_l1_ (u"๋ࠬฮำ่ࠣ฽๊อฯࠡ็๋ะํีฺ่ࠠา็ࠥ๎ๅโ฻็ࠤําว่ิ่้ࠣอำหะาห๊࠭䃽"))
		return
	if showDialogs:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䃾"),l1l11l_l1_ (u"ࠧࠨ䃿"),l1l11l_l1_ (u"ࠨࠩ䄀"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䄁"),l1l11l_l1_ (u"้ࠪำุๆࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࡝ࡰࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่ห่ࠥฯ๋็ࠣวํࠦๅโไ๋ำࠥษ่ࠡ็อ์็็ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤฬ๊ๅีๅ็อࠥอไร่ࠣรࠬ䄂"))
		if yes!=1: return
	if yes==1:
		for addon_id in [l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭䄃")]:
			if addon_id not in list(l1llll1l1l11_l1_.keys()): continue
			l1ll111l111_l1_,l1ll1111111_l1_,l1ll111l1ll_l1_,l1ll11lll1l_l1_,l1ll11llll1_l1_,l1lll1l111ll_l1_,l1ll1l1111l_l1_ = l1llll1l1l11_l1_[addon_id]
			succeeded = l1ll1111lll1_l1_(addon_id,l1ll1l1111l_l1_,showDialogs)
			l1lll1l1l11l_l1_ = l1lll1l1l11l_l1_ and succeeded
	if showDialogs:
		if l1lll1l1l11l_l1_: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䄄"),l1l11l_l1_ (u"࠭ࠧ䄅"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䄆"),l1l11l_l1_ (u"ࠨฬ่ࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣࡠࡳࠦๅฯิ้ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫ䄇"))
		else: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䄈"),l1l11l_l1_ (u"ࠪࠫ䄉"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䄊"),l1l11l_l1_ (u"๊ࠬไฤีไࠤ้๋๋ࠠฬ่็๋ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤส฻ไศฯู้้ࠣไส࡞ࡱࠤ๊ิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩ䄋"))
	return l1lll1l1l11l_l1_
	#settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ䄌"),l1l11l_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ䄍"))
	#xbmc.executebuiltin(l1l11l_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ䄎")+sys.argv[0]+l1l11l_l1_ (u"ࠩࡂࡱࡴࡪࡥ࠾࠴࠹࠴ࠬ䄏")+l1l11l_l1_ (u"ࠥ࠭ࠧ䄐"))
	#xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䄑"))
def l1ll1111lll1_l1_(addon_id,l1ll1l1111l_l1_,showDialogs=True):
	succeeded = False
	if showDialogs:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬ࠭䄒"),l1l11l_l1_ (u"࠭ࠧ䄓"),l1l11l_l1_ (u"ࠧࠨ䄔"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䄕"),l1l11l_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬ䄖"))
		if yes!=1: return False
	l1l1ll1ll1ll_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1ll1l1111l_l1_)
	if l1l1ll1ll1ll_l1_:
		import zipfile,io
		l1ll11ll1111_l1_ = io.BytesIO(l1l1ll1ll1ll_l1_)
		zf = zipfile.ZipFile(l1ll11ll1111_l1_)
		zf.extractall(l1l1lllllll1_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l1l11l_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ䄗"))
		time.sleep(1)
		result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ䄘")+addon_id+l1l11l_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ䄙"))
		if l1l11l_l1_ (u"࠭ࡏࡌࠩ䄚") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ䄛"),l1l11l_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ䄜"))
	if showDialogs:
		if succeeded: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䄝"),l1l11l_l1_ (u"ࠪࠫ䄞"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䄟"),l1l11l_l1_ (u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ䄠"))
		else: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䄡"),l1l11l_l1_ (u"ࠧࠨ䄢"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䄣"),l1l11l_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ䄤"))
	return succeeded
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࠤ࡫ࡰࡴࡴࡸࡴࠡࡵࡴࡰ࡮ࡺࡥ࠴ࠌࠌࡧࡴࡴ࡮ࠡ࠿ࠣࡷࡶࡲࡩࡵࡧ࠶࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࡧࡤࡥࡱࡱࡷࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡺࡥࡹࡶࡢࡪࡦࡩࡴࡰࡴࡼࠤࡂࠦࡳࡵࡴࠍࠍࡨࡩࠠ࠾ࠢࡦࡳࡳࡴ࠮ࡤࡷࡵࡷࡴࡸࠨࠪࠌࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡗࡓࡈࡆ࡚ࡅࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡘࡋࡔࠡࡱࡵ࡭࡬࡯࡮ࠡ࠿ࠣࠦࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠤࠪ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠣࠤࠥ䄥")
def l1ll1l1l1lll_l1_(addon_id,showDialogs=True):
	if showDialogs==l1l11l_l1_ (u"ࠫࠬ䄦"): showDialogs = True
	#l1lll111llll_l1_ = xbmc.getCondVisibility(l1l11l_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ䄧")+addon_id+l1l11l_l1_ (u"࠭ࠩࠨ䄨"))
	l1ll1lll1l11_l1_ = l1l1llllll1l_l1_([addon_id])
	l1ll1lll1111_l1_,l1lll111llll_l1_ = l1ll1lll1l11_l1_[addon_id]
	if l1lll111llll_l1_:
		succeeded = True
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䄩"),l1l11l_l1_ (u"ࠨࠩ䄪"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䄫"),l1l11l_l1_ (u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬ䄬")+addon_id+l1l11l_l1_ (u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧ䄭"))
	else:
		succeeded = False
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䄮"),l1l11l_l1_ (u"࠭ࠧ䄯"),l1l11l_l1_ (u"ࠧࠨ䄰"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䄱"),l1l11l_l1_ (u"ࠩࠪ䄲")+addon_id+l1l11l_l1_ (u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦ࠮ࠡ์ฯฬࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡๆๆ๎ࠥ๐ูๆๆࠣห้ฮั็ษ่ะࠥ฿ๆะๅࠣฬฺ๎ัสุࠢั๏ำษࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨ䄳"))
		if yes==1:
			xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫ䄴")+addon_id+l1l11l_l1_ (u"ࠬ࠯ࠧ䄵"))
			time.sleep(1)
			xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭䄶"))
			time.sleep(1)
			while xbmc.getCondVisibility(l1l11l_l1_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ䄷")): time.sleep(1)
			result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ䄸")+addon_id+l1l11l_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ䄹"))
			if l1l11l_l1_ (u"ࠪࡓࡐ࠭䄺") in result:
				succeeded = True
				if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䄻"),l1l11l_l1_ (u"ࠬ࠭䄼"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䄽"),l1l11l_l1_ (u"ࠧห็ࠣๅา฻ࠠฤ๊ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศส๋๋ࠢ๏ࠦวๅฤ้ࠤัอ็ำห่้ࠣอำหะาห๊࠭䄾"))
			elif showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䄿"),l1l11l_l1_ (u"ࠩࠪ䅀"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䅁"),l1l11l_l1_ (u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭䅂"))
	return succeeded
def l1ll11ll111l_l1_(addon_id,showDialogs=True):
	l1llll1l1l11_l1_ = l1ll11lll11l_l1_([addon_id])
	if addon_id not in list(l1llll1l1l11_l1_.keys()): return False
	l1ll111l111_l1_,l1ll1111111_l1_,l1ll111l1ll_l1_,l1ll11lll1l_l1_,l1ll11llll1_l1_,l1lll1l111ll_l1_,l1ll1l1111l_l1_ = l1llll1l1l11_l1_[addon_id]
	succeeded,l1ll1ll11l1l_l1_ = False,l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ䅃")
	if l1lll1l111ll_l1_==l1l11l_l1_ (u"࠭ࡧࡰࡱࡧࠫ䅄"):
		succeeded = True
		l1ll1ll11l1l_l1_ = l1l11l_l1_ (u"ࠧࡨࡱࡲࡨࠬ䅅")
	elif l1lll1l111ll_l1_==l1l11l_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ䅆"):
		succeeded = False
		result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ䅇")+addon_id+l1l11l_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ䅈"))
		if l1l11l_l1_ (u"ࠫࡔࡑࠧ䅉") in result: succeeded = True
		if succeeded: l1ll1ll11l1l_l1_ = l1l11l_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭䅊")
	elif l1lll1l111ll_l1_==l1l11l_l1_ (u"࠭࡯࡭ࡦࠪ䅋"):
		succeeded = l1ll1111lll1_l1_(addon_id,l1ll1l1111l_l1_,showDialogs)
		if succeeded: l1ll1ll11l1l_l1_ = l1l11l_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ䅌")
	elif l1lll1l111ll_l1_==l1l11l_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ䅍"):
		l1ll11ll1lll_l1_ = l1lll1l11111_l1_(showDialogs)
		if l1ll11ll1lll_l1_:
			succeeded = l1ll1l1l1lll_l1_(addon_id,showDialogs)
			if succeeded: l1ll1ll11l1l_l1_ = l1l11l_l1_ (u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬ䅎")
	l1l1lll11lll_l1_ = l1ll11lll1l_l1_
	return succeeded,l1ll1ll11l1l_l1_,l1l1lll11lll_l1_
def l1ll1l1l1ll1_l1_(l1ll1llll11l_l1_=l1l11l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ䅏"),showDialogs=True):
	l1l1lll11l1l_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ䅐"))
	import json
	data = json.loads(l1l1lll11l1l_l1_)
	l1l1lll111ll_l1_ = data[l1l11l_l1_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ䅑")][l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ䅒")]
	if kodi_version<19: l1l1lll111ll_l1_ = l1l1lll111ll_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䅓"))
	if showDialogs:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࠩ䅔"),l1l11l_l1_ (u"ࠩࠪ䅕"),l1l11l_l1_ (u"ࠪࠫ䅖"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䅗"),l1l11l_l1_ (u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪ䅘")+l1l1lll111ll_l1_+l1l11l_l1_ (u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨ䅙")+l1ll1llll11l_l1_+l1l11l_l1_ (u"ࠧࠡมࠤࠫ䅚"))
		if yes!=1: return False
	succeeded,l1ll1ll11l1l_l1_,l1l1lll11lll_l1_ = l1ll11ll111l_l1_(l1ll1llll11l_l1_,False)
	if succeeded:
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䅛"),l1l11l_l1_ (u"ࠩࠪ䅜"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䅝"),l1l11l_l1_ (u"ࠫฯ๋สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅฮ็ำࠥอไอัํำࠥ๎็้ࠢฯห์ุࠠๅๆสืฯิฯศ็ࠣ࠲ู่ࠥโࠢํฮ๊ࠦวๅฤ้ࠤฯเ๊๋ำࠣษ฾ีวะษอࠤ่๎ฯ๋ࠢ็็๏๊ࠦิฬ฼้้ࠦวๅฮ็ำࠥอไอัํำࠥฮฯๅษ้๋ࠣࠦวๅไา๎๊࠭䅞"))
		result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠣࠩ䅟")+l1ll1llll11l_l1_+l1l11l_l1_ (u"࠭ࠢࡾࡿࠪ䅠"))
		if l1l11l_l1_ (u"ࠧࡐࡍࠪ䅡") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ䅢"))
	elif showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䅣"),l1l11l_l1_ (u"ࠪࠫ䅤"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䅥"),l1l11l_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧ䅦"))
	return succeeded
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᛦ")
menu_name = l1l11l_l1_ (u"ࠫࡤࡉࡍࡏࡡࠪᛧ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"่ࠬวว็อ๎ࠬᛨ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l1l1ll1_l1_(url)
	elif mode==302: results = l111l1_l1_(url)
	elif mode==303: results = l1111l1l1_l1_(url)
	elif mode==304: results = l111ll_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛩ"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᛪ"),l1l11l_l1_ (u"ࠨࠩ᛫"),309,l1l11l_l1_ (u"ࠩࠪ᛬"),l1l11l_l1_ (u"ࠪࠫ᛭"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᛮ"))
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᛯ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᛰ"),l1l11l_l1_ (u"ࠧࠨᛱ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᛲ"),l11lll_l1_,l1l11l_l1_ (u"ࠩࠪᛳ"),l1l11l_l1_ (u"ࠪࠫᛴ"),l1l11l_l1_ (u"ࠫࠬᛵ"),l1l11l_l1_ (u"ࠬ࠭ᛶ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᛷ"))
	html = response.content
	html = l1llll11ll_l1_(html)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡷ࡯ࡂ࠭࠴ࠪࡀࠫ࠿ࡷࡵࡧ࡮࠿ࠩᛸ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᛹"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ᛺"))
		if title==l1l11l_l1_ (u"ࠪี๊฼ว็ࠩ᛻"): l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯า็ูห๋࠵ࠧ᛼")
		if not any(value in title for value in l1llll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᛽"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᛾")+menu_name+title,l1111l_l1_,301)
	l1l1l1ll1_l1_(l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭᛿"))
	return html
def l1l1l1ll1_l1_(url):
	seq = 0
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᜀ"),url,l1l11l_l1_ (u"ࠩࠪᜁ"),l1l11l_l1_ (u"ࠪࠫᜂ"),l1l11l_l1_ (u"ࠫࠬᜃ"),l1l11l_l1_ (u"ࠬ࠭ᜄ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᜅ"))
	html = response.content
	html = l1llll11ll_l1_(html)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠾ࡶࡩࡨࡺࡩࡰࡰࡁ࠲࠯ࡅ࠼࠰ࡵࡨࡧࡹ࡯࡯࡯ࡀࠬࠫᜆ"),html,re.DOTALL)
	if l1ll111_l1_:
		for block in l1ll111_l1_:
			seq += 1
			items = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡶࡩࡨࡺࡩࡰࡰࡁ࠲ࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᜇ"),block,re.DOTALL)
			for title,test,l1111l_l1_ in items:
				title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫᜈ"))
				if title==l1l11l_l1_ (u"ࠪࠫᜉ"): title = l1l11l_l1_ (u"ࠫอ๎่้๊๋ࠫᜊ")
				if l1l11l_l1_ (u"ࠬ࡫࡭࠿࠾ࡤࠫᜋ") not in test:
					if block.count(l1l11l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪᜌ"))>0:
						l1llll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᜍ"),block,re.DOTALL)
						for l1111l_l1_ in l1llll1111_l1_:
							title = l1111l_l1_.split(l1l11l_l1_ (u"ࠨ࠱ࠪᜎ"))[-2]
							addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜏ"),menu_name+title,l1111l_l1_,301)
						continue
					else: l1111l_l1_ = url+l1l11l_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᜐ")+str(seq)
				#l11ll111l_l1_ = [l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥ࠭ᜑ"),l1l11l_l1_ (u"ࠬอแๅษ่ࠤࠬᜒ"),l1l11l_l1_ (u"࠭ศาษ่ะࠬᜓ"),l1l11l_l1_ (u"ฺࠧำฺ᜔๋ࠬ"),l1l11l_l1_ (u"ࠨๅ็๎ออสࠨ᜕"),l1l11l_l1_ (u"ࠩส฾ฬ์้ࠨ᜖")]
				#if any(value in title for value in l11ll111l_l1_):
				if not any(value in title for value in l1llll1_l1_):
					addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᜗"),menu_name+title,l1111l_l1_,302)
	else: l111l1_l1_(url,html)
	return
def l111l1_l1_(url,html=l1l11l_l1_ (u"ࠫࠬ᜘")):
	if html==l1l11l_l1_ (u"ࠬ࠭᜙"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ᜚"),url,l1l11l_l1_ (u"ࠧࠨ᜛"),l1l11l_l1_ (u"ࠨࠩ᜜"),l1l11l_l1_ (u"ࠩࠪ᜝"),l1l11l_l1_ (u"ࠪࠫ᜞"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᜟ"))
		html = response.content
		html = l1llll11ll_l1_(html)
	if l1l11l_l1_ (u"ࠬࡅࡳࡦࡳࡸࡩࡳࡩࡥ࠾ࠩᜠ") in url:
		url,seq = url.split(l1l11l_l1_ (u"࠭࠿ࡴࡧࡴࡹࡪࡴࡣࡦ࠿ࠪᜡ"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠾ࡶࡩࡨࡺࡩࡰࡰࡁ࠲࠯ࡅ࠼࠰ࡵࡨࡧࡹ࡯࡯࡯ࡀࠬࠫᜢ"),html,re.DOTALL)
		block = l1ll111_l1_[int(seq)-1]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡳࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡲࡨࡾࡄࠧᜣ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡥ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᜤ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for l1111l_l1_,data,img in items:
		title = re.findall(l1l11l_l1_ (u"ࠪࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠮ࠫࡁ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡮ࡀࠪᜥ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l11l_l1_ (u"ࠫࡡࡴࠧᜦ"),l1l11l_l1_ (u"ࠬ࠭ᜧ")).strip(l1l11l_l1_ (u"࠭ࠠࠨᜨ"))
		if not title or title==l1l11l_l1_ (u"ࠧࠨᜩ"):
			title = re.findall(l1l11l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠿࠰࠭ࡃࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᜪ"),data,re.DOTALL)
			if title: title = title[0].replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬᜫ"),l1l11l_l1_ (u"ࠪࠫᜬ")).strip(l1l11l_l1_ (u"ࠫࠥ࠭ᜭ"))
			if not title or title==l1l11l_l1_ (u"ࠬ࠭ᜮ"):
				title = re.findall(l1l11l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᜯ"),data,re.DOTALL)
				title = title[0].replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪᜰ"),l1l11l_l1_ (u"ࠨࠩᜱ")).strip(l1l11l_l1_ (u"ࠩࠣࠫᜲ"))
		title = unescapeHTML(title)
		#if title==l1l11l_l1_ (u"ࠪࠫᜳ"): continue
		if title not in l1l1l11_l1_:
			l1l1l11_l1_.append(title)
			l1l11l1l_l1_ = l1111l_l1_+data+img
			if l1l11l_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴᜴࠭") in l1l11l1l_l1_ or l1l11l_l1_ (u"๋ࠬำๅี็ࠫ᜵") in l1l11l1l_l1_ or l1l11l_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࠣࠩ᜶") in l1l11l1l_l1_:
				if l1l11l_l1_ (u"ࠧษำส้ั࠭᜷") in data: title = l1l11l_l1_ (u"ࠨสิ๊ฬ๋ฬࠡࠩ᜸")+title
				elif l1l11l_l1_ (u"่ࠩืู้ไࠨ᜹") in data or l1l11l_l1_ (u"้ࠪํูๅࠨ᜺") in data: title = l1l11l_l1_ (u"ู๊ࠫไิๆࠣࠫ᜻")+title
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᜼"),menu_name+title,l1111l_l1_,303,img)
			else: addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᜽"),menu_name+title,l1111l_l1_,305,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ᜾"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᜿"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᝀ"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡࠩᝁ")+title,l1111l_l1_,302)
	return
def l1111l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᝂ"),url,l1l11l_l1_ (u"ࠬ࠭ᝃ"),l1l11l_l1_ (u"࠭ࠧᝄ"),l1l11l_l1_ (u"ࠧࠨᝅ"),l1l11l_l1_ (u"ࠨࠩᝆ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨᝇ"))
	html = response.content
	html = l1llll11ll_l1_(html)
	name = re.findall(l1l11l_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸ࡮ࡺ࡬ࡦࡀࠪᝈ"),html,re.DOTALL)
	name = name[0].replace(l1l11l_l1_ (u"ࠫࢁࠦำ๋็สࠤ๋อ่ࠨᝉ"),l1l11l_l1_ (u"ࠬ࠭ᝊ")).replace(l1l11l_l1_ (u"࠭ࡃࡪ࡯ࡤࠤࡓࡵࡷࠨᝋ"),l1l11l_l1_ (u"ࠧࠨᝌ")).strip(l1l11l_l1_ (u"ࠨࠢࠪᝍ")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬᝎ"),l1l11l_l1_ (u"ࠪࠤࠬᝏ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡥࡢࡵࡲࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨᝐ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᝑ"),block,re.DOTALL)
		if len(items)>1:
			for l1111l_l1_,title in items:
				#title = name+l1l11l_l1_ (u"࠭ࠠࠨᝒ")+title.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪᝓ"),l1l11l_l1_ (u"ࠨࠩ᝔")).strip(l1l11l_l1_ (u"ࠩࠣࠫ᝕"))
				title = title.replace(l1l11l_l1_ (u"ࠪࡠࡳ࠭᝖"),l1l11l_l1_ (u"ࠫࠬ᝗")).strip(l1l11l_l1_ (u"ࠬࠦࠧ᝘"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᝙"),menu_name+title,l1111l_l1_,304)
		else: l111ll_l1_(url)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ᝚"),url,l1l11l_l1_ (u"ࠨࠩ᝛"),l1l11l_l1_ (u"ࠩࠪ᝜"),l1l11l_l1_ (u"ࠪࠫ᝝"),l1l11l_l1_ (u"ࠫࠬ᝞"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ᝟"))
	html = response.content
	html = l1llll11ll_l1_(html)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡥࡧࡷࡥ࡮ࡲࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠩᝠ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᝡ"),block,re.DOTALL)
	for l1111l_l1_,img,title in items:
		title = title.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫᝢ"),l1l11l_l1_ (u"ࠩࠪᝣ")).strip(l1l11l_l1_ (u"ࠪࠤࠬᝤ"))
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᝥ"),menu_name+title,l1111l_l1_,305,img)
	return
def PLAY(url):
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫ࡬ࡹࡳ࡬ࠪࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡭࡯࡮ࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱ࠯ࠊࠊࡥࡲࡳࡰ࡯ࡥࡴࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡱ࡮࡭ࡪࡹ࠮ࡨࡧࡷࡣࡩ࡯ࡣࡵࠪࠬࠎࠎࡖࡈࡑࡕࡈࡗࡘࡏࡄࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡖࡈࡑࡕࡈࡗࡘࡏࡄࠨ࡟ࠍࠍࡻ࡫ࡲࡪࡨࡼࡣࡱ࡯࡮࡬ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠤ࡫ࡶࡪ࡬ࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠰ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠧࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀࠫ࠰ࡖࡈࡑࡕࡈࡗࡘࡏࡄࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ࠯ࠊࠊࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡼࡥࡳ࡫ࡩࡽࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬ࠪࠌࠌࠧࡦࡪ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡤࡨࠧࠦࡴࡢࡴࡪࡩࡹࡃࠢࡠࡤ࡯ࡥࡳࡱࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡣࡧࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠣࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡦࡪ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧࠪࠌࠌࠧࡦࡪ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡡࡥࡡ࡫ࡸࡲࡲࠩࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡥࡸࡳࠨࠠࡴࡶࡼࡰࡪࡃࠢࡥ࡫ࡶࡴࡱࡧࡹ࠻ࠢࡱࡳࡳ࡫࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࡞࠴ࡢ࠱ࠧ࠰ࠩࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡤ࠱ࡧ࡮ࡳࡡࡷ࡫ࡧࡷ࠳ࡲࡩࡷࡧ࠲ࠫࢂࠐࠉࠣࠤࠥᝦ")
	url2 = url+l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬࡮ࡴࡧ࠰ࠩᝧ")
	#server = SERVER(url2,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫᝨ"))
	#headers2 = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᝩ"):None,l1l11l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᝪ"):server}
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᝫ"),url2,l1l11l_l1_ (u"ࠫࠬᝬ"),l1l11l_l1_ (u"ࠬ࠭᝭"),l1l11l_l1_ (u"࠭ࠧᝮ"),l1l11l_l1_ (u"ࠧࠨᝯ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫᝰ"))
	html = response.content
	html = l1llll11ll_l1_(html)
	#url2 = l1llll1l11_l1_(url2,l1l11l_l1_ (u"ࠩ࡯ࡳࡼ࡫ࡲࠨ᝱"))
	#html = l1llll111l_l1_(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᝲ"),url2,l1l11l_l1_ (u"ࠫࠬᝳ"),l1l11l_l1_ (u"ࠬ࠭᝴"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩ᝵"))
	#if html and kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ᝶"))
	#html = l1llll11ll_l1_(html)
	l1ll1l1l_l1_ = []
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᝷"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᝸"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠪࡠࡳ࠭᝹"),l1l11l_l1_ (u"ࠫࠬ᝺")).strip(l1l11l_l1_ (u"ࠬࠦࠧ᝻"))
			l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ᝼"),title,re.DOTALL)
			if l1l1l111_l1_:
				l1l1l111_l1_ = l1l11l_l1_ (u"ࠧࡠࡡࡢࡣࠬ᝽")+l1l1l111_l1_[0]
				#title = l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ᝾")
				title = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ᝿"))
			else: l1l1l111_l1_ = l1l11l_l1_ (u"ࠪࠫក")
			l111l1ll1_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬខ")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩគ")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l111l1ll1_l1_)
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡸࡣࡷࡧ࡭ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪឃ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		# l1l11111l_l1_ l1l1l1111_l1_ l1l1lll1_l1_
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠱࠲࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭ង"),block,re.DOTALL)
		for l1111l_l1_ in l1l1lll1_l1_:
			l1111l_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧច")+l1111l_l1_
			title = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧឆ"))
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫជ")+title+l1l11l_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬឈ")
			l1ll1l1l_l1_.append(l1111l_l1_)
		# l1llll11l1_l1_ l1l1l1111_l1_ l1l1lll1_l1_
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡧࡪࡢࡺ࡟ࠬࢀࡻࡲ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫញ"),html,re.DOTALL)
		if l1l1lll1_l1_:
			items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡴࡤࡦࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨដ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪឋ"),l1l11l_l1_ (u"ࠨࠩឌ")).strip(l1l11l_l1_ (u"ࠩࠣࠫឍ"))
				title = title.replace(l1l11l_l1_ (u"ࠪࡇ࡮ࡳࡡࠡࡐࡲࡻࠬណ"),l1l11l_l1_ (u"ࠫࡈ࡯࡭ࡢࡐࡲࡻࠬត"))
				l1111l_l1_ = l1l1lll1_l1_[0]+l1l11l_l1_ (u"ࠬࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡸ࡫ࡷࡧ࡭ࠬࡩ࡯ࡦࡨࡼࡂ࠭ថ")+index+l1l11l_l1_ (u"࠭ࠦࡪࡦࡀࠫទ")+id+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨធ")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩន")
				l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧប"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩផ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬព"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭ភ"): return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨម"),l1l11l_l1_ (u"ࠧࠬࠩយ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭រ")+search
	l111l1_l1_(url)
	return
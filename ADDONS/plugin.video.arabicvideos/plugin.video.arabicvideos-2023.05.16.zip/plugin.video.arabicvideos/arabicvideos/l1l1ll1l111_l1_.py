# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬタ")
headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪダ"):l1l11l_l1_ (u"ࠧࠨチ")}
script_name = l1l11l_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧヂ")
menu_name = l1l11l_l1_ (u"ࠩࡢࡔࡓ࡚࡟ࠨッ")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l1l11l_l1_ (u"ࠪ࠷ࠬツ"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l1l11l_l1_ (u"ࠫ࠶࠭ヅ"))
	elif mode==36: results = CATEGORIES(url,l1l11l_l1_ (u"ࠬ࠸ࠧテ"))
	elif mode==37: results = CATEGORIES(url,l1l11l_l1_ (u"࠭࠴ࠨデ"))
	elif mode==38: results = l1lll1ll1_l1_()
	elif mode==39: results = SEARCH(text,page)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧト"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨド"),l1l11l_l1_ (u"ࠩࠪナ"),39,l1l11l_l1_ (u"ࠪࠫニ"),l1l11l_l1_ (u"ࠫࠬヌ"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩネ"))
	#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫノ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧハ"),l1l11l_l1_ (u"ࠨࠩバ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧパ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬヒ")+menu_name+l1l11l_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭ビ"),l1l11l_l1_ (u"ࠬ࠭ピ"),38)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭フ"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩブ")+menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วห๋ࠢฬึอๅอࠩプ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧヘ"),31)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪベ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ペ")+menu_name+l1l11l_l1_ (u"ࠬอไๆี็ื้อสࠡษ็ห่ััࠡ็ืห์ีษࠨホ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫボ"),37)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧポ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪマ")+menu_name+l1l11l_l1_ (u"ࠩสๅ้อๅࠡฯึฬࠥอไ็๊฼ࠫミ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫム"),35)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫメ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧモ")+menu_name+l1l11l_l1_ (u"࠭วโๆส้ࠥำำษࠢส่๊๋หๅࠩャ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨヤ"),36)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨュ"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫユ")+menu_name+l1l11l_l1_ (u"ࠪหาีหࠡษ็หๆ๊วๆࠩョ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬヨ"),32)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬラ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨリ")+menu_name+l1l11l_l1_ (u"ࠧๆีิั๏อสࠨル"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡪࡩࡳࡸࡥ࠰࠶࠲࠵ࠬレ"),32)
	return l1l11l_l1_ (u"ࠩࠪロ")
def CATEGORIES(url,select=l1l11l_l1_ (u"ࠪࠫヮ")):
	type = url.split(l1l11l_l1_ (u"ࠫ࠴࠭ワ"))[3]
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ヰ"),l1l11l_l1_ (u"࠭ࠧヱ"),type, url)
	if type==l1l11l_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫヲ"):
		html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠨࠩン"),headers,l1l11l_l1_ (u"ࠩࠪヴ"),l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪヵ"))
		if select==l1l11l_l1_ (u"ࠫ࠸࠭ヶ"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡷࡪࡸࡩࡦࡵࡉࡳࡷࡳࠧヷ"),html,re.DOTALL)
			block= l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬヸ"),block,re.DOTALL)
			for l1111l_l1_,name in items:
				if l1l11l_l1_ (u"ࠧไๆํฬฬะࠠๆุะ็ฮ࠭ヹ") in name: continue
				url = l11lll_l1_ + l1111l_l1_
				name = name.strip(l1l11l_l1_ (u"ࠨࠢࠪヺ"))
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ・"),menu_name+name,url,32)
		if select==l1l11l_l1_ (u"ࠪ࠸ࠬー"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡨࡪࡺࡡࡪ࡮ࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡷࡀ࠿࠳ࡦࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ヽ"),html,re.DOTALL)
			block= l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧヾ"),block,re.DOTALL)
			for l1111l_l1_,img,title in items:
				url = l11lll_l1_ + l1111l_l1_
				title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨヿ"))
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㄀"),menu_name+title,url,32,img)
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㄁"),l1l11l_l1_ (u"ࠩࠪ㄂"),url,l1l11l_l1_ (u"ࠪࠫ㄃"))
	if type==l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ㄄"):
		html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠬ࠭ㄅ"),headers,l1l11l_l1_ (u"࠭ࠧㄆ"),l1l11l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠶ࡳࡪࠧㄇ"))
		if select==l1l11l_l1_ (u"ࠨ࠳ࠪㄈ"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡉࡨࡲࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡥ࡭ࡧࡦࡸࠬㄉ"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫㄊ"),block,re.DOTALL)
			for value,name in items:
				url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳ࠬㄋ") + value
				name = name.strip(l1l11l_l1_ (u"ࠬࠦࠧㄌ"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㄍ"),menu_name+name,url,32)
		elif select==l1l11l_l1_ (u"ࠧ࠳ࠩㄎ"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡂࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪㄏ"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪㄐ"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l11l_l1_ (u"ࠪࠤࠬㄑ"))
				url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴ࡧࡣࡵࡱࡵ࠳ࠬㄒ") + value
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄓ"),menu_name+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧㄔ"),l1l11l_l1_ (u"ࠧࠨㄕ"),url,l1l11l_l1_ (u"ࠨࠩㄖ"))
	type = url.split(l1l11l_l1_ (u"ࠩ࠲ࠫㄗ"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫㄘ"),headers,l1l11l_l1_ (u"ࠫࠬㄙ"),l1l11l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧㄚ"))
	if l1l11l_l1_ (u"࠭ࡨࡰ࡯ࡨࠫㄛ") in url: type=l1l11l_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩㄜ")
	if type==l1l11l_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬㄝ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷ࠭࠴ࠪࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬㄞ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫㄟ"),block,re.DOTALL)
			for l1111l_l1_,img,name in items:
				url = l11lll_l1_ + l1111l_l1_
				name = name.strip(l1l11l_l1_ (u"ࠫࠥ࠭ㄠ"))
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄡ"),menu_name+name,url,32,img)
	if type==l1l11l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ㄢ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫㄣ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠬࡁࠬࠦࠬㄤ"),block,re.DOTALL)
		for l1111l_l1_,img,name in items:
			name = name.strip(l1l11l_l1_ (u"ࠩࠣࠫㄥ"))
			url = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄦ"),menu_name+name,url,33,img)
	if type==l1l11l_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭ㄧ"):
		page = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧㄨ"))[-1]
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧㄩ"),l1l11l_l1_ (u"ࠧࠨㄪ"),url,l1l11l_l1_ (u"ࠨࠩㄫ"))
		if page==l1l11l_l1_ (u"ࠩ࠴ࠫㄬ"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠨㄭ"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࠬㄮ"),block,re.DOTALL)
			count = 0
			for l1111l_l1_,img,l1ll1ll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l11l_l1_ (u"ࠬࠦ࠭ࠡࠩㄯ") + l1ll1ll_l1_
				url = l11lll_l1_ + l1111l_l1_
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㄰"),menu_name+name,url,33,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶ࠲࠯ࡅࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪㄱ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࠩㄲ"),block,re.DOTALL)
		for l1111l_l1_,img,title,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫㄳ"))
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬㄴ"))
			name = title + l1l11l_l1_ (u"ࠫࠥ࠳ࠠࠨㄵ") + l1ll1ll_l1_
			url = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㄶ"),menu_name+name,url,33,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡧ࡭ࡻࡳ࡬࡮ࡩ࡯࡯࠯ࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡶ࡮࡭ࡨࡵࠪ࠱࠯ࡄ࠯ࡤࡢࡶࡤ࠱ࡷ࡫ࡶࡪࡸࡨ࠱ࡿࡵ࡮ࡦ࡫ࡧࡁࠧ࠺ࠢࠨㄷ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ㄸ"),block,re.DOTALL)
	for l1111l_l1_,page in items:
		url = l11lll_l1_ + l1111l_l1_
		name = l1l11l_l1_ (u"ࠨืไัฮࠦࠧㄹ") + page
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄺ"),menu_name+name,url,32)
	return
def PLAY(url):
	if l1l11l_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧㄻ") in url:
		url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࡹ࠵࠴ࡹࡥࡳ࡫ࡨࡷࡑ࡯࡮࡬࠱ࠪㄼ") + url.split(l1l11l_l1_ (u"ࠬ࠵ࠧㄽ"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪㄾ"),url,l1l11l_l1_ (u"ࠧࠨㄿ"),headers,l1l11l_l1_ (u"ࠨࠩㅀ"),l1l11l_l1_ (u"ࠩࠪㅁ"),l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫㅂ"))
		html = response.content
		items = re.findall(l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪㅃ"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l11l_l1_ (u"ࠬࡢ࠯ࠨㅄ"),l1l11l_l1_ (u"࠭࠯ࠨㅅ"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫㅆ"),url,l1l11l_l1_ (u"ࠨࠩㅇ"),headers,l1l11l_l1_ (u"ࠩࠪㅈ"),l1l11l_l1_ (u"ࠪࠫㅉ"),l1l11l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬㅊ"))
		html = response.content
		items = re.findall(l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡛ࡒࡍࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬㅋ"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬㅌ"))
	return
def SEARCH(search,page=l1l11l_l1_ (u"ࠧࠨㅍ")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠨࠢࠪㅎ"),l1l11l_l1_ (u"ࠩࠨ࠶࠵࠭ㅏ"))
	l1llll11l_l1_ = [l1l11l_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪㅐ"),l1l11l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫㅑ")]
	if not page: page = l1l11l_l1_ (u"ࠬ࠷ࠧㅒ")
	else: page,type = page.split(l1l11l_l1_ (u"࠭࠯ࠨㅓ"))
	if showdialogs:
		l1lll1l11ll_l1_ = [ l1l11l_l1_ (u"ࠧษฯฮࠤ฾์ࠠศใ็ห๊࠭ㅔ") , l1l11l_l1_ (u"ࠨสะฯࠥ฿ๆࠡ็ึุ่๊วหࠩㅕ")]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦ࠭ࠡษัฮึࠦวๅสะฯࠬㅖ"), l1lll1l11ll_l1_)
		if selection == -1 : return
		type = l1llll11l_l1_[selection]
	else:
		if l1l11l_l1_ (u"ࠪࡣࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࡢࠫㅗ") in options: type = l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫㅘ")
		elif l1l11l_l1_ (u"ࠬࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭ㅙ") in options: type = l1l11l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ㅚ")
		else: return
	headers[l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ㅛ")] = l1l11l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨㅜ")
	data = {l1l11l_l1_ (u"ࠩࡴࡹࡪࡸࡹࠨㅝ"):l1l1ll_l1_ , l1l11l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡇࡳࡲࡧࡩ࡯ࠩㅞ"):type}
	if page!=l1l11l_l1_ (u"ࠫ࠶࠭ㅟ"): data[l1l11l_l1_ (u"ࠬ࡬ࡲࡰ࡯ࠪㅠ")] = page
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫㅡ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨㅢ"),data,headers,l1l11l_l1_ (u"ࠨࠩㅣ"),l1l11l_l1_ (u"ࠩࠪㅤ"),l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ㅥ"))
	html = response.content
	items=re.findall(l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧㅦ"),html,re.DOTALL)
	if items:
		for title,l1111l_l1_ in items:
			url = l11lll_l1_ + l1111l_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࠯ࠨㅧ"),l1l11l_l1_ (u"࠭࠯ࠨㅨ"))
			if l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩㅩ") in url: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㅪ"),menu_name+l1l11l_l1_ (u"ࠩไ๎้๋ࠠࠨㅫ")+title,url,33)
			elif l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬㅬ") in url:
				url = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭ㅭ"),l1l11l_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࠫㅮ"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅯ"),menu_name+l1l11l_l1_ (u"ࠧๆี็ื้ࠦࠧㅰ")+title,url+l1l11l_l1_ (u"ࠨ࠱࠴ࠫㅱ"),32)
	count=re.findall(l1l11l_l1_ (u"ࠩࠥࡸࡴࡺࡡ࡭ࠤ࠽ࠬ࠳࠰࠿ࠪࡿࠪㅲ"),html,re.DOTALL)
	if count:
		pages = int(  (int(count[0])+9)   /10 )+1
		for l1llll1ll_l1_ in range(1,pages):
			l1llll1ll_l1_ = str(l1llll1ll_l1_)
			if l1llll1ll_l1_!=page:
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅳ"),l1l11l_l1_ (u"ฺࠫ็อสࠢࠪㅴ")+l1llll1ll_l1_,l1l11l_l1_ (u"ࠬ࠭ㅵ"),39,l1l11l_l1_ (u"࠭ࠧㅶ"),l1llll1ll_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩㅷ")+type,search)
	return
def l1lll1ll1_l1_():
	l1111l_l1_ = l1l11l_l1_ (u"ࠨࡣࡋࡖ࠵ࡩࡄࡰࡸࡏ࠶ࡩࢀࡤࡉࡌ࡯࡝࡜࠶࠰ࡍࡰࡅ࡬ࡧࡳࡖ࠱ࡎࡰࡒࡻࡒ࡭࡭ࡵࡏ࠶࡛ࡱ࡚࠳ࡘࡩ࡝࡜ࡐࡹࡍ࠴࡫࡬ࡧࡍࡆࡖࡘ࡬࠽ࡼࡨࡇࡇ࠷ࡥࡋࡱࢀࡤࡄ࠷ࡷࡑ࠸࡛࠴ࠨㅸ")
	l1111l_l1_ = base64.b64decode(l1111l_l1_)
	l1111l_l1_ = l1111l_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㅹ"))
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨㅺ"))
	return
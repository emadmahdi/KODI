# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᘐ")
menu_name = l1l11l_l1_ (u"ࠧࡠࡅࡐࡐࡤ࠭ᘑ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨไ้์ฬะࠠโุสส๏ฯࠧᘒ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l111l1_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l111ll_l1_(url,text)
	elif mode==474: results = l1l1l1ll1_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᘓ"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫᘔ"),l1l11l_l1_ (u"ࠫࠬᘕ"),l1l11l_l1_ (u"ࠬ࠭ᘖ"),l1l11l_l1_ (u"࠭ࠧᘗ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᘘ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩᘙ"),html,re.DOTALL)
	l111l11l1_l1_ = l111l11l1_l1_[0].strip(l1l11l_l1_ (u"ࠩ࠲ࠫᘚ"))
	l111l11l1_l1_ = SERVER(l111l11l1_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧᘛ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘜ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᘝ"),l1l11l_l1_ (u"࠭ࠧᘞ"),479,l1l11l_l1_ (u"ࠧࠨᘟ"),l1l11l_l1_ (u"ࠨࠩᘠ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᘡ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᘢ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᘣ"),l1l11l_l1_ (u"ࠬ࠭ᘤ"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘥ"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᘦ")+menu_name+l1l11l_l1_ (u"ࠨลไ่ฬ๋ࠠๆ็ํึฮ࠭ᘧ"),l111l11l1_l1_,471,l1l11l_l1_ (u"ࠩࠪᘨ"),l1l11l_l1_ (u"ࠪࠫᘩ"),l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᘪ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘫ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᘬ")+menu_name+l1l11l_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧᘭ"),l111l11l1_l1_,471,l1l11l_l1_ (u"ࠨࠩᘮ"),l1l11l_l1_ (u"ࠩࠪᘯ"),l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᘰ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᘱ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᘲ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨᘳ"))
		#if title in l1llll1_l1_: continue
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠧࡤࡣࡷࡁࡴࡴ࡬ࡪࡰࡨ࠱ࡲࡵࡶࡪࡧࡶ࠵ࠬᘴ"),l1l11l_l1_ (u"ࠨࡥࡤࡸࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᘵ"))
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᘶ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᘷ")+menu_name+title,l1111l_l1_,474)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᘸ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᘹ"),l1l11l_l1_ (u"࠭ࠧᘺ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫᘻ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨᘼ"),html,re.DOTALL)
	for l1l11l1l_l1_ in l1ll111_l1_:
		block = block.replace(l1l11l1l_l1_,l1l11l_l1_ (u"ࠩࠪᘽ"))
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᘾ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		#l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࠨᘿ")+category+l1l11l_l1_ (u"ࠬࡃࠧᙀ")+value
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙁ"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᙂ")+menu_name+title,l1111l_l1_,474)
	return
def l1l1l1ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᙃ"),url,l1l11l_l1_ (u"ࠩࠪᙄ"),l1l11l_l1_ (u"ࠪࠫᙅ"),l1l11l_l1_ (u"ࠫࠬᙆ"),l1l11l_l1_ (u"ࠬ࠭ᙇ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᙈ"))
	html = response.content
	if l1l11l_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶࠧᙉ") in url: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦࠬᙊ"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙋ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᙌ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1l11l_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫᙍ") in l1111l_l1_:
				if l1l11l_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡦࡰࡪࡰ࡮ࡹࡨ࠮࡯ࡲࡺ࡮࡫ࡳࠨᙎ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳ࠲ࠩᙏ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡰ࡭ࡸࡩࠧᙐ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡸࡻ࠳ࡣࡩࡣࡱࡲࡪࡲࠧᙑ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"่๊ࠩีࠦวๅสาห๏ฯࠧᙒ") in title and l1l11l_l1_ (u"ࠪࡨࡴࡃࡲࡢࡶ࡬ࡲ࡬࠭ᙓ") not in l1111l_l1_: continue
			else: title = l1l11l_l1_ (u"ࠫฯืส๋สࠣฬฬูสฯัส้࠿ࠦࠠࠨᙔ")+title
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙕ"),menu_name+title,l1111l_l1_,471)
	else: l111l1_l1_(url)
	return
def l111l1_l1_(url,request=l1l11l_l1_ (u"࠭ࠧᙖ")):
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫᙗ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᙘ"),url,l1l11l_l1_ (u"ࠩࠪᙙ"),l1l11l_l1_ (u"ࠪࠫᙚ"),l1l11l_l1_ (u"ࠫࠬᙛ"),l1l11l_l1_ (u"ࠬ࠭ᙜ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᙝ"))
	html = response.content
	items = []
	if request==l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩᙞ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲࡬࡬ࡶ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᙟ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮࠭ᙠ"),block,re.DOTALL)
		l1l1lll1_l1_,titles,l1llll1lll_l1_ = zip(*items)
		items = zip(l1llll1lll_l1_,l1l1lll1_l1_,titles)
	elif request==l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᙡ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭ᙢ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪᙣ"),block,re.DOTALL)
		l1l1lll1_l1_,titles,l1llll1lll_l1_ = zip(*items)
		items = zip(l1llll1lll_l1_,l1l1lll1_l1_,titles)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᙤ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧᙥ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᙦ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᙧ"),html,re.DOTALL)
		if not l1ll111_l1_: return
		block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᙨ"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᙩ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"๋ࠬิศ้าอࠬᙪ"),l1l11l_l1_ (u"࠭แ๋ๆ่ࠫᙫ"),l1l11l_l1_ (u"ࠧศ฼้๎ฮ࠭ᙬ"),l1l11l_l1_ (u"ࠨๅ็๎อ࠭᙭"),l1l11l_l1_ (u"ࠩส฽้อๆࠨ᙮"),l1l11l_l1_ (u"๋ࠪิอแࠨᙯ"),l1l11l_l1_ (u"๊ࠫฮวาษฬࠫᙰ"),l1l11l_l1_ (u"ࠬ฿ัืࠩᙱ"),l1l11l_l1_ (u"࠭ๅ่ำฯห๋࠭ᙲ"),l1l11l_l1_ (u"ࠧศๆห์๊࠭ᙳ"),l1l11l_l1_ (u"ࠨ็ึีา๐ษࠨᙴ")]
	for img,l1111l_l1_,title in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠩ࠲ࠫᙵ"))
		if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᙶ") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴࠭ᙷ")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠬ࠵ࠧᙸ"))
		if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫᙹ") not in img: img = l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩᙺ")+img.strip(l1l11l_l1_ (u"ࠨ࠱ࠪᙻ"))
		#l1111l_l1_ = unescapeHTML(l1111l_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫᙼ"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᙽ"),title,re.DOTALL)
		if any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᙾ"),menu_name+title,l1111l_l1_,472,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠬอไฮๆๅอࠬᙿ") in title:
			title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚁ"),menu_name+title,l1111l_l1_,473,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ᚂ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᚃ"),menu_name+title,l1111l_l1_,471,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᚄ"),menu_name+title,l1111l_l1_,473,img)
	if request not in [l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᚅ"),l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧᚆ")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᚇ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᚈ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1111l_l1_==l1l11l_l1_ (u"ࠨࠥࠪᚉ"): continue
				l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫᚊ")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠪ࠳ࠬᚋ"))
				title = unescapeHTML(title)
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᚌ"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫᚍ")+title,l1111l_l1_,471)
		l111lll11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᚎ"),html,re.DOTALL)
		if l111lll11_l1_:
			l1111l_l1_ = l111lll11_l1_[0]
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚏ"),menu_name+l1l11l_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨᚐ"),l1111l_l1_,471)
	return
def l111ll_l1_(url,l1lllll11l_l1_):
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪᚑ"),l1l11l_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪᚒ")+url)
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨᚓ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᚔ"),url,l1l11l_l1_ (u"࠭ࠧᚕ"),l1l11l_l1_ (u"ࠧࠨᚖ"),l1l11l_l1_ (u"ࠨࠩᚗ"),l1l11l_l1_ (u"ࠩࠪᚘ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᚙ"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᚚ"),html,re.DOTALL)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ᚛")+l1lllll11l_l1_+l1l11l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᚜"),html,re.DOTALL)
	items = []
	# l111l111l_l1_
	if l11111l1l_l1_ and not l1lllll11l_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᚝"),html,re.DOTALL)
		img = img[0]
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࡟࠰ࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ᚞"),block,re.DOTALL)
		for l1lllll11l_l1_,title in items: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᚟"),menu_name+title,url,473,img,l1l11l_l1_ (u"ࠪࠫᚠ"),l1lllll11l_l1_)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		#img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬᚡ"))
		img = re.findall(l1l11l_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚢ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡴࡪࡶ࡯ࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠦࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࠧᚣ"),block,re.DOTALL)
		if items:
			for title,l1111l_l1_ in items:
				l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩᚤ")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠨ࠱ࠪᚥ"))
				addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᚦ"),menu_name+title,l1111l_l1_,472,img)
		else:
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᚧ"),block,re.DOTALL)
			for l1111l_l1_,title,img in items:
				if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᚨ") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠬ࠵ࠧᚩ")+l1111l_l1_.strip(l1l11l_l1_ (u"࠭࠯ࠨᚪ"))
				addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᚫ"),menu_name+title,l1111l_l1_,472,img)
	if l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠪᚬ") in html:
		if items: addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᚭ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᚮ"),l1l11l_l1_ (u"ࠫࠬᚯ"),9999)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᚰ"),menu_name+l1l11l_l1_ (u"࠭ๅ้ษู๎฾ࠦะศฬู้ࠣฯࠧᚱ"),url,471)
	#else: l111l1_l1_(url)
	return
def PLAY(url):
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫᚲ"))
	l1ll1l1l_l1_ = []
	# l1lllll111_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᚳ"),url,l1l11l_l1_ (u"ࠩࠪᚴ"),l1l11l_l1_ (u"ࠪࠫᚵ"),l1l11l_l1_ (u"ࠫࠬᚶ"),l1l11l_l1_ (u"ࠬ࠭ᚷ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᚸ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡯ࡂࠬᚹ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᚺ"),block,re.DOTALL)
		if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_,True): return
	# default l1l1l1111_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᚻ"),html,re.DOTALL)
	if l1111l_l1_:
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫᚼ")
		if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᚽ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᚾ")+l1111l_l1_
		l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l11111l_l1_ l1l1l1111_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩ࡛ࡒࡍࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᚿ"),html,re.DOTALL)
	if l1111l_l1_:
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨᛀ")
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᛁ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᛂ")+l1111l_l1_
		l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l1l1111_l1_ l1l1lll1_l1_
	url2 = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᛃ"),l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧᛄ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᛅ"),url2,l1l11l_l1_ (u"࠭ࠧᛆ"),l1l11l_l1_ (u"ࠧࠨᛇ"),l1l11l_l1_ (u"ࠨࠩᛈ"),l1l11l_l1_ (u"ࠩࠪᛉ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨᛊ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᛋ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫᛌ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᛍ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᛎ")
			if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᛏ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᛐ")+l1111l_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	url2 = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᛑ"),l1l11l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡪࡳࠫᛒ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᛓ"),url2,l1l11l_l1_ (u"࠭ࠧᛔ"),l1l11l_l1_ (u"ࠧࠨᛕ"),l1l11l_l1_ (u"ࠨࠩᛖ"),l1l11l_l1_ (u"ࠩࠪᛗ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨᛘ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᛙ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧᛚ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᛛ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᛜ")
			if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᛝ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᛞ")+l1111l_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᛟ"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᛠ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭ᛡ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧᛢ"): return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩᛣ"),l1l11l_l1_ (u"ࠨ࠭ࠪᛤ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪᛥ")+search
	l111l1_l1_(url)
	return
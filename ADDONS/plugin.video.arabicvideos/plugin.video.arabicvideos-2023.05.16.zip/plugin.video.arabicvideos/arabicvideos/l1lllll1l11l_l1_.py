# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ䖜")
#headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䖝"):l1l11l_l1_ (u"ࠧࠨ䖞")}
menu_name = l1l11l_l1_ (u"ࠨࡡࡖࡌࡕࡥࠧ䖟")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ู่ࠩฬืูสࠩ䖠"),l1l11l_l1_ (u"ࠪฬะࠦๅษษืีࠬ䖡")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l111l1_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l111ll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䖢"),l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭䖣"),l1l11l_l1_ (u"࠭ࠧ䖤"),l1l11l_l1_ (u"ࠧࠨ䖥"),l1l11l_l1_ (u"ࠨࠩ䖦"),l1l11l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䖧"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䖨"),html,re.DOTALL)
	l111l11l1_l1_ = l111l11l1_l1_[0].strip(l1l11l_l1_ (u"ࠫ࠴࠭䖩"))
	l111l11l1_l1_ = SERVER(l111l11l1_l1_,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ䖪"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䖫"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䖬"),l111l11l1_l1_,489,l1l11l_l1_ (u"ࠨࠩ䖭"),l1l11l_l1_ (u"ࠩࠪ䖮"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䖯"))
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䖰"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䖱"),l1l11l_l1_ (u"࠭ࠧ䖲"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䖳"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䖴")+menu_name+l1l11l_l1_ (u"ࠩฦัิัࠠศๆ่์ฬ฼ฺ๊ࠩ䖵"),l111l11l1_l1_,481)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯ࠢ࡮ࡻࡄࡧࡨࡵࡵ࡯ࡶࠥࠫ䖶"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ䖷"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠬࠩࠧ䖸"): continue
		if title in l1llll1_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䖹"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䖺")+menu_name+title,l1111l_l1_,481)
	return html
def l111l1_l1_(url,l1l1l1l1l1l1_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䖻"),url,l1l11l_l1_ (u"ࠩࠪ䖼"),l1l11l_l1_ (u"ࠪࠫ䖽"),l1l11l_l1_ (u"ࠫࠬ䖾"),l1l11l_l1_ (u"ࠬ࠭䖿"),l1l11l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ䗀"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡲࡷࡹ࠮࠮ࠫࡁࠬࠦ࡫ࡵ࡯ࡵࡧࡵࠦࠬ䗁"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ䗂"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"ุ่ࠩฬํฯสࠩ䗃"),l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨ䗄"),l1l11l_l1_ (u"ࠫฬเๆ๋หࠪ䗅"),l1l11l_l1_ (u"ࠬษฺ็์ฬࠫ䗆"),l1l11l_l1_ (u"࠭ใๅ์หࠫ䗇"),l1l11l_l1_ (u"ࠧศ฻็ห๋࠭䗈"),l1l11l_l1_ (u"ࠨ้าหๆ࠭䗉"),l1l11l_l1_ (u"่ࠩฬฬืวสࠩ䗊"),l1l11l_l1_ (u"ࠪ฽ึ฼ࠧ䗋"),l1l11l_l1_ (u"๊ࠫํัอษ้ࠫ䗌"),l1l11l_l1_ (u"ࠬอไษ๊่ࠫ䗍"),l1l11l_l1_ (u"࠭ๅิำะ๎ฮ࠭䗎")]
	l1l1l1l1l1ll_l1_ = l1l11l_l1_ (u"ࠧ࠰ࠩ䗏").join(l1l1l1l1l1l1_l1_.strip(l1l11l_l1_ (u"ࠨ࠱ࠪ䗐")).split(l1l11l_l1_ (u"ࠩ࠲ࠫ䗑"))[4:]).split(l1l11l_l1_ (u"ࠪ࠱ࠬ䗒"))
	for l1111l_l1_,title,img in items:
		title = unescapeHTML(title)
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ䗓"),title,re.DOTALL)
		if l1l1l1l1l1l1_l1_:
			l111l1ll1_l1_ = l1l11l_l1_ (u"ࠬ࠵ࠧ䗔").join(l1111l_l1_.strip(l1l11l_l1_ (u"࠭࠯ࠨ䗕")).split(l1l11l_l1_ (u"ࠧ࠰ࠩ䗖"))[4:]).split(l1l11l_l1_ (u"ࠨ࠯ࠪ䗗"))
			l1l1l1l1ll11_l1_ = len([x for x in l1l1l1l1l1ll_l1_ if x in l111l1ll1_l1_])
			if l1l1l1l1ll11_l1_>2 and l1l11l_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭䗘") in l1111l_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䗙"),menu_name+title,l1111l_l1_,482,img)
		else:
			if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ䗚"),title,re.DOTALL)
			#if any(value in title for value in l11111ll1_l1_):
			if set(title.split()) & set(l11111ll1_l1_) and l1l11l_l1_ (u"๋ࠬำๅี็ࠫ䗛") not in title:
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䗜"),menu_name+title,l1111l_l1_,482,img)
			elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠧฮๆๅอࠬ䗝") in title:
				title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䗞") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗟"),menu_name+title,l1111l_l1_,483,img,l1l11l_l1_ (u"ࠪࠫ䗠"),url)
					l1l1l11_l1_.append(title)
			else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗡"),menu_name+title,l1111l_l1_,483,img,l1l11l_l1_ (u"ࠬ࠭䗢"),url)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠤ䗣"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧ䗤"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠨษ็ูๆำษࠡࠩ䗥"),l1l11l_l1_ (u"ࠩࠪ䗦"))
			if title!=l1l11l_l1_ (u"ࠪࠫ䗧"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗨"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ䗩")+title,l1111l_l1_,481,l1l11l_l1_ (u"࠭ࠧ䗪"),l1l11l_l1_ (u"ࠧࠨ䗫"),l1l1l1l1l1l1_l1_)
	return
def l111ll_l1_(url,url2):
	headers = {l1l11l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䗬"):l1l11l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䗭")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䗮"),url,l1l11l_l1_ (u"ࠫࠬ䗯"),headers,l1l11l_l1_ (u"ࠬ࠭䗰"),l1l11l_l1_ (u"࠭ࠧ䗱"),l1l11l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䗲"))
	html = response.content
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ䗳"))
	img = re.findall(l1l11l_l1_ (u"ࠩࠥ࡭ࡲ࡭࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䗴"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫ䗵"))
	l1l1l1l1l11l_l1_ = True
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡲࡩࡴࡶࡖࡩࡦࡹ࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭䗶"),html,re.DOTALL)
	# l111l111l_l1_
	if l11111l1l_l1_ and l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬ䗷") not in url:
		block = l11111l1l_l1_[0]
		count = block.count(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠪ䗸"))
		if count==0: count = block.count(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂ࠭䗹"))
		if count>1:
			l1l1l1l1l11l_l1_ = False
			if l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠧ࠭䗺") in block:
				items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ䗻"),block,re.DOTALL)
				for id,title in items:
					l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠷࠴ࡰࡩࡲࡂࡷࡱࡻࡧ࠾ࠩ䗼")+id
					addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗽"),menu_name+title,l1111l_l1_,483,img)
			else:
				items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ䗾"),block,re.DOTALL)
				for id,title in items:
					l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳ࠯ࡲ࡫ࡴࡄࡹࡥࡳ࡫ࡨࡷࡎࡊ࠽ࠨ䗿")+id
					addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘀"),menu_name+title,l1111l_l1_,483,img)
	# l1l11l1_l1_
	if l1l1l1l1l11l_l1_:
		block = l1l11l_l1_ (u"ࠨࠩ䘁")
		if l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴࠩ䘂") in url: block = html
		else:
			l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡪࡶ࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䘃"),html,re.DOTALL)
			if l1ll1l1ll_l1_: block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䘄"),block,re.DOTALL)
		if items:
			for l1111l_l1_,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䘅"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䘆"),menu_name+title,l1111l_l1_,482,img)
	if not menuItemsLIST: l111l1_l1_(url2,url)
	return
def PLAY(url):
	url2 = url.strip(l1l11l_l1_ (u"ࠧ࠰ࠩ䘇"))+l1l11l_l1_ (u"ࠨ࠱ࡂࡨࡴࡃࡷࡢࡶࡦ࡬ࠬ䘈")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䘉"),url2,l1l11l_l1_ (u"ࠪࠫ䘊"),l1l11l_l1_ (u"ࠫࠬ䘋"),l1l11l_l1_ (u"ࠬ࠭䘌"),l1l11l_l1_ (u"࠭ࠧ䘍"),l1l11l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䘎"))
	html = response.content
	l1ll1l1l_l1_ = []
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ䘏"))
	l1llllllll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡹࡳࡤࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䘐"),html,re.DOTALL)
	if not l1llllllll_l1_: l1llllllll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡠ࠭ࡺࡨࡪࡵ࡟࠲࡮ࡪ࡜࠭࠲࡟࠰࠭࠴ࠪࡀࠫ࡟࠭ࠬ䘑"),html,re.DOTALL)
	l1llllllll_l1_ = l1llllllll_l1_[0]
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䘒"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ䘓"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨ䘔"))
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡼ࡯࠳࠲࠵࠵࠴ࡺࡥ࡮ࡲ࠲ࡥ࡯ࡧࡸ࠰࡫ࡩࡶࡦࡳࡥ࠳࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪ䘕")+l1llllllll_l1_+l1l11l_l1_ (u"ࠨࠨࡹ࡭ࡩ࡫࡯࠾ࠩ䘖")+l111111ll_l1_[2:]+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䘗")+title+l1l11l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䘘")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l11111l_l1_ l1l1l1111_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧ࡭ࡥࡵࡇࡰࡦࡪࡪࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䘙"),html,re.DOTALL)
	if l1111l_l1_:
		title = SERVER(l1111l_l1_[0],l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ䘚"))
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䘛")+title+l1l11l_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ䘜")
		l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	url2 = url.strip(l1l11l_l1_ (u"ࠨ࠱ࠪ䘝"))+l1l11l_l1_ (u"ࠩ࠲ࡃࡩࡵ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䘞")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䘟"),url2,l1l11l_l1_ (u"ࠫࠬ䘠"),l1l11l_l1_ (u"ࠬ࠭䘡"),l1l11l_l1_ (u"࠭ࠧ䘢"),l1l11l_l1_ (u"ࠧࠨ䘣"),l1l11l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䘤"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡸࡦࡨ࡬ࡦ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭䘥"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䘦"),block,re.DOTALL)
		for title,l1111l_l1_ in items:
			title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭䘧"))
			if l1l11l_l1_ (u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭䘨") in l1111l_l1_: title2 = l1l11l_l1_ (u"࠭࡟ࡠะสูࠬ䘩")
			else: title2 = l1l11l_l1_ (u"ࠧࠨ䘪")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䘫")+title+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䘬")+title2
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䘭"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䘮"),url)
	return
def SEARCH(search,l111l11l1_l1_=l1l11l_l1_ (u"ࠬ࠭䘯")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ䘰"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨ䘱"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ䘲"),l1l11l_l1_ (u"ࠩ࠮ࠫ䘳"))
	if l111l11l1_l1_==l1l11l_l1_ (u"ࠪࠫ䘴"): l111l11l1_l1_ = l11lll_l1_
	url = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭䘵")+search+l1l11l_l1_ (u"ࠬ࠵ࠧ䘶")
	l111l1_l1_(url,l1l11l_l1_ (u"࠭ࠧ䘷"))
	return
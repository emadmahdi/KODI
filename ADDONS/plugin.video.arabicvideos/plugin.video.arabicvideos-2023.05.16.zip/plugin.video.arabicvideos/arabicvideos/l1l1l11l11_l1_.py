# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ᦿ")
def MAIN(mode,url):
	if   mode==330: results = l1ll111111_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l1l1l1lll1_l1_()
	elif mode==333: results = l1l11lll1l_l1_()
	elif mode==334: results = l1l1l1ll11_l1_(url)
	else: results = False
	return results
def l1l1l1ll11_l1_(l1l1l111ll_l1_):
	try: os.remove(l1l1l111ll_l1_.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᧀ")))
	except: os.remove(l1l1l111ll_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᧁ"))
	return
def l1l11lll1l_l1_():
	message = l1l11l_l1_ (u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭ᧂ")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩᧃ"),l1l11l_l1_ (u"ࠩࠪᧄ"),l1l11l_l1_ (u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡษ็้้็วหࠩᧅ"),message)
	return
def l1ll111111_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᧆ"),l1l11l_l1_ (u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪᧇ"),l1l11l_l1_ (u"࠭ࠧᧈ"),333)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᧉ"),l1l11l_l1_ (u"ࠨฬ฽๎๏ืࠠๆๅส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨ᧊"),l1l11l_l1_ (u"ࠩࠪ᧋"),332)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᧌"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᧍"),l1l11l_l1_ (u"ࠬ࠭᧎"),9999)
	l1l1ll1lll_l1_ = l1l1l1l1ll_l1_()
	mtime = os.stat(l1l1ll1lll_l1_).st_mtime
	files = []
	if kodi_version>18.99: l1l1ll1ll1_l1_ = os.listdir(l1l1ll1lll_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ᧏")))
	else: l1l1ll1ll1_l1_ = os.listdir(l1l1ll1lll_l1_.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ᧐")))
	for filename in l1l1ll1ll1_l1_:
		if kodi_version>18.99: filename = filename.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭᧑"))
		if not filename.startswith(l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ᧒")): continue
		filepath = os.path.join(l1l1ll1lll_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l1l1llll1l_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ᧓"))
			except: pass
			filename = filename.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ᧔"))
		filepath = os.path.join(l1l1ll1lll_l1_,filename)
		addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᧕"),filename,filepath,331)
	return
def l1l1l1l1ll_l1_():
	l1l1ll1lll_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩ᧖"))
	if l1l1ll1lll_l1_: return l1l1ll1lll_l1_
	settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ᧗"),addoncachefolder)
	return addoncachefolder
def l1l1l1lll1_l1_():
	l1l1ll1lll_l1_ = l1l1l1l1ll_l1_()
	l1l1ll11ll_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ᧘"),l1l11l_l1_ (u"ࠩࠪ᧙"),l1l11l_l1_ (u"ࠪࠫ᧚"),l1l1ll1lll_l1_,l1l11l_l1_ (u"ࠫ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨ᧛"))
	if l1l1ll11ll_l1_==1:
		newpath = l1l1ll1111_l1_(3,l1l11l_l1_ (u"๋ࠬใศ่ࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ᧜"),l1l11l_l1_ (u"࠭࡬ࡰࡥࡤࡰࠬ᧝"),l1l11l_l1_ (u"ࠧࠨ᧞"),False,True,l1l1ll1lll_l1_)
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ᧟"),l1l11l_l1_ (u"ࠩࠪ᧠"),l1l11l_l1_ (u"ࠪࠫ᧡"),newpath,l1l11l_l1_ (u"ࠫ์ึว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ฬะ์าࠤ้ะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ࠥฮฯๅษ้๋ࠣࠦวๅ็ๆห๋ࠦวๅไา๎๊ࠦฟࠨ᧢"))
		if yes==1:
			settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨ᧣"),newpath)
			DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ᧤"),l1l11l_l1_ (u"ࠧࠨ᧥"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᧦"),l1l11l_l1_ (u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪ᧧"))
	#if not l1l1ll11ll_l1_ or not yes: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ᧨"),l1l11l_l1_ (u"ࠫࠬ᧩"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᧪"),l1l11l_l1_ (u"࠭สๆࠢส่฿อมࠡษ็฽๊๊๊สࠩ᧫"))
	return
def l1l1l1llll_l1_(filename):
	l1l1llllll_l1_ = l1l11l_l1_ (u"ࠧࠨ᧬").join(ii for ii in filename if ii not in l1l11l_l1_ (u"ࠨ࡞࠲ࠦ࠿࠰࠿࠽ࡀࡿࠫ᧭")+half_triangular_colon)
	return l1l1llllll_l1_
def l1l1l1l1l1_l1_(url,videofiletype=l1l11l_l1_ (u"ࠩࠪ᧮"),website=l1l11l_l1_ (u"ࠪࠫ᧯")):
	#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫ᧰"),l1l11l_l1_ (u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬ᧱"))
	LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭᧲"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ᧳")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ᧴"))
	if not videofiletype: videofiletype = GET_VIDEOFILETYPE(url,website)
	#if not videofiletype:
	#	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ᧵"),l1l11l_l1_ (u"ࠪࠫ᧶"),l1l11l_l1_ (u"ࠫฯ์า๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ᧷"),l1l11l_l1_ (u"ࠬอไๆๆไࠤ๊์ࠠ็๊฼ࠤࠬ᧸")+videofiletype+l1l11l_l1_ (u"้࠭ࠠษ็ฬึ์วๆฮࠣัฬ๊๊ศࠢ฽๎ึࠦฬศ้ีࠤ้ะอๆ์็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้๋ไโษอࠫ᧹"))
	#	LOG_THIS(l1l11l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ᧺"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡸࡾࡶࡥ࠰ࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ᧻")+url+l1l11l_l1_ (u"ࠩࠣࡡࠬ᧼"))
	#	return False
	l1l1ll1lll_l1_ = l1l1l1l1ll_l1_()
	l1l1lll1l1_l1_ = l1l1ll1l1l_l1_()
	filename = l1l1lll1l1_l1_.replace(l1l11l_l1_ (u"ࠪࠤࠬ᧽"),l1l11l_l1_ (u"ࠫࡤ࠭᧾"))
	filename = l1l1l1llll_l1_(filename)
	#videofiletype = videofiletype.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ᧿"))
	filename = l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬᨀ")+str(int(now))[-4:]+l1l11l_l1_ (u"ࠧࡠࠩᨁ")+filename+videofiletype
	l1l11llll1_l1_ = os.path.join(l1l1ll1lll_l1_,filename)
	headers = {}
	headers[l1l11l_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪᨂ")] = l1l11l_l1_ (u"ࠩࠪᨃ")
	headers[l1l11l_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶࠪᨄ")] = l1l11l_l1_ (u"ࠫ࠯࠵ࠪࠨᨅ")
	url = url.replace(l1l11l_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨᨆ"),l1l11l_l1_ (u"࠭ࠧᨇ"))
	if l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬᨈ") in url:
		url2,useragent = url.rsplit(l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᨉ"),1)
		useragent = useragent.replace(l1l11l_l1_ (u"ࠩࡿࠫᨊ"),l1l11l_l1_ (u"ࠪࠫᨋ")).replace(l1l11l_l1_ (u"ࠫࠫ࠭ᨌ"),l1l11l_l1_ (u"ࠬ࠭ᨍ"))
	else: url2,useragent = url,None
	if not useragent: useragent = l1ll1111l_l1_()
	if useragent: headers[l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᨎ")] = useragent
	if l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᨏ") in url2: url2,l1l1l11ll1_l1_ = url2.rsplit(l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᨐ"),1)
	else: url2,l1l1l11ll1_l1_ = url2,l1l11l_l1_ (u"ࠩࠪᨑ")
	url2 = url2.strip(l1l11l_l1_ (u"ࠪࢀࠬᨒ")).strip(l1l11l_l1_ (u"ࠫࠫ࠭ᨓ")).strip(l1l11l_l1_ (u"ࠬࢂࠧᨔ")).strip(l1l11l_l1_ (u"࠭ࠦࠨᨕ"))
	l1l1l11ll1_l1_ = l1l1l11ll1_l1_.replace(l1l11l_l1_ (u"ࠧࡽࠩᨖ"),l1l11l_l1_ (u"ࠨࠩᨗ")).replace(l1l11l_l1_ (u"ᨘࠩࠩࠫ"),l1l11l_l1_ (u"ࠪࠫᨙ"))
	if l1l1l11ll1_l1_:	headers[l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬᨚ")] = l1l1l11ll1_l1_
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᨛ"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ᨜")+url2+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪ᨝")+str(headers)+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ᨞")+l1l11llll1_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠬ᨟"))
	MegaByte = 1024*1024
	l1l1lll11l_l1_ = 0
	try:
		l1l1lll111_l1_ =	xbmc.getInfoLabel(l1l11l_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡫ࡥࡔࡲࡤࡧࡪ࠭ᨠ"))
		l1l1lll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪࠫࠨᨡ"),l1l1lll111_l1_)
		l1l1lll11l_l1_ = int(l1l1lll111_l1_[0])
	except: pass
	if l1l1lll11l_l1_==0:
		try:
			st = os.l1l11ll1ll_l1_(l1l1ll1lll_l1_)
			l1l1lll11l_l1_ = st.f_frsize*st.f_bavail//MegaByte
		except: pass
	if l1l1lll11l_l1_==0:
		try:
			st = os.l1l1lllll1_l1_(l1l1ll1lll_l1_)
			l1l1lll11l_l1_ = st.f_frsize*st.f_bavail//MegaByte
		except: pass
	if l1l1lll11l_l1_==0:
		try:
			import shutil
			total,l1l1l1ll1l_l1_,l1l1l1l11l_l1_ = shutil.l1ll1111ll_l1_(l1l1ll1lll_l1_)
			l1l1lll11l_l1_ = l1l1l1l11l_l1_//MegaByte
		except: pass
	if l1l1lll11l_l1_==0:
		l1ll111l11_l1_(l1l11l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫᨢ"),l1l11l_l1_ (u"࠭ๅิษะอࠥอไหะี๎๋ࠦๅอ้๋่ฮ࠭ᨣ"),l1l11l_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣว๋๊ࠦฮัาࠤ๊่ฯศำุ้ࠣออสࠢส่ฯิา๋่ࠣห้็วา฼ฬࠤๆ๐ࠠอ้สึฺ่่ࠦๆํ๋ࠥ็ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ๊ࠥๆࠡ์฼ู้้ࠦ็ัๆࠤส๊้ࠡล้ࠤ๏่่ๆ่ࠢฬึ๋ฬ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠษฯ็ࠤ์ึ็ࠡษ็ู้้ไสࠢ็ห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢๅำࠥ๐ำษสࠣห๊ะไศรࠣะ์อาไࠢหห้๋ไโษอࠤํํะศࠢไ๎์ࠦฮุ๊ิอࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ์้ํะศࠢสุ่ฮศࠡไส้ࠥอไๆสิ้ัࠦๅลไอหࠥฮๅ็฻ࠣห้ฮั็ษ่ะ๋ࠥๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫᨤ"),l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᨥ"))
		LOG_THIS(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᨦ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡧࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥࡺࡨࡦࠢࡧ࡭ࡸࡱࠠࡧࡴࡨࡩࠥࡹࡰࡢࡥࡨࠫᨧ"))
		return False
	import requests
	if videofiletype==l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪᨨ"):
		l1l1lll_l1_,l1ll1l1l_l1_ = l1ll11111l_l1_(url2,headers)
		#DIALOG_SELECT(l1l11l_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪᨩ"), l1l1lll_l1_)
		#DIALOG_SELECT(l1l11l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᨪ"), l1ll1l1l_l1_)
		if len(l1l1lll_l1_)==0:
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫᨫ"),l1l11l_l1_ (u"ࠨࠩᨬ"))
			return False
		elif len(l1l1lll_l1_)==1: selection = 0
		elif len(l1l1lll_l1_)>1:
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧᨭ"), l1l1lll_l1_)
			if selection == -1 :
				DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭ᨮ"),l1l11l_l1_ (u"ࠫࠬᨯ"))
				return False
		url2 = l1ll1l1l_l1_[selection]
	filesize = 0
	if videofiletype==l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫᨰ"):
		l1l11llll1_l1_ = l1l11llll1_l1_.rsplit(l1l11l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬᨱ"))[0]+l1l11l_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬᨲ")
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᨳ"),url2,l1l11l_l1_ (u"ࠩࠪᨴ"),headers,l1l11l_l1_ (u"ࠪࠫᨵ"),l1l11l_l1_ (u"ࠫࠬᨶ"),l1l11l_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊ࠭ࡅࡑ࡚ࡒࡑࡕࡁࡅࡡ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬᨷ"))
		l11l1111_l1_ = response.content
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"࠭࡜ࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨᨸ"),l11l1111_l1_+l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡶࠬᨹ"),re.DOTALL)
		if not l1l1lll1_l1_:
			LOG_THIS(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᨺ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᨻ")+url2+l1l11l_l1_ (u"ࠪࠤࡢ࠭ᨼ"))
			return False
		l1111l_l1_ = l1l1lll1_l1_[0]
		if not l1111l_l1_.startswith(l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᨽ")):
			if l1111l_l1_.startswith(l1l11l_l1_ (u"ࠬ࠵࠯ࠨᨾ")): l1111l_l1_ = url2.split(l1l11l_l1_ (u"࠭࠺ࠨᨿ"),1)[0]+l1l11l_l1_ (u"ࠧ࠻ࠩᩀ")+l1111l_l1_
			elif l1111l_l1_.startswith(l1l11l_l1_ (u"ࠨ࠱ࠪᩁ")): l1111l_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭ᩂ"))+l1111l_l1_
			else: l1111l_l1_ = url2.rsplit(l1l11l_l1_ (u"ࠪ࠳ࠬᩃ"),1)[0]+l1l11l_l1_ (u"ࠫ࠴࠭ᩄ")+l1111l_l1_
		response = requests.request(l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᩅ"),l1111l_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l1l1l1l111_l1_ = len(l1l1lll1_l1_)
		filesize = chunksize*l1l1l1l111_l1_
	else:
		chunksize = 1*MegaByte
		response = requests.request(l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᩆ"),url2,headers=headers,verify=False,stream=True)
		if l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᩇ") in response.headers: filesize = int(response.headers[l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᩈ")])
		l1l1l1l111_l1_ = int(filesize//chunksize)
	#l1l1lll1ll_l1_ = l1l1l1l111_l1_+1
	l1l1lll1ll_l1_ = int(filesize//MegaByte)+1
	if filesize<21000:
		LOG_THIS(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᩉ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡴࡰࡱࠣࡷࡲࡧ࡬࡭ࠢࡲࡶࠥ࡯ࡴࠡ࡫ࡶࠤࡲ࠹ࡵ࠹ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᩊ")+url2+l1l11l_l1_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᩋ")+str(l1l1lll1ll_l1_)+l1l11l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᩌ")+str(l1l1lll11l_l1_)+l1l11l_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᩍ")+l1l11llll1_l1_+l1l11l_l1_ (u"ࠧࠡ࡟ࠪᩎ"))
		DIALOG_OK(l1l11l_l1_ (u"ࠨࠩᩏ"),l1l11l_l1_ (u"ࠩࠪᩐ"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᩑ"),l1l11l_l1_ (u"ࠫๆฺไࠡใํࠤ๊฿ัโหࠣัั๋ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็้้็ࠠึ฼ํีࠥาฯศ๋่ࠢ์ึวࠡๆสࠤ๏๋ใ็ࠢ็่อืๆศ็ฯࠤฯำๅ๋ๆ๋ࠣีอࠠศๆ่่ๆ࠭ᩒ"))
		return False
	l1l1l11l1l_l1_ = 400
	l1l1l11111_l1_ = l1l1lll11l_l1_-l1l1lll1ll_l1_
	if l1l1l11111_l1_<l1l1l11l1l_l1_:
		LOG_THIS(l1l11l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᩓ"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡑࡳࡹࠦࡥ࡯ࡱࡸ࡫࡭ࠦࡤࡪࡵ࡮ࠤࡸࡶࡡࡤࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᩔ")+url2+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᩕ")+str(l1l1lll1ll_l1_)+l1l11l_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧᩖ")+str(l1l1lll11l_l1_)+l1l11l_l1_ (u"ࠩࠣࡑࡇࠦ࠭ࠡࠩᩗ")+str(l1l1l11l1l_l1_)+l1l11l_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᩘ")+l1l11llll1_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠧᩙ"))
		DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ᩚ"),l1l11l_l1_ (u"࠭ࠧᩛ"),l1l11l_l1_ (u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏๊ࠧᩜ"),l1l11l_l1_ (u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ࠦࠧᩝ")+str(l1l1lll1ll_l1_)+l1l11l_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨᩞ")+str(l1l1lll11l_l1_)+l1l11l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪ᩟")+str(l1l1l11l1l_l1_)+l1l11l_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ᩠࠭"))
		return False
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᩡ"),l1l11l_l1_ (u"࠭ࠧᩢ"),l1l11l_l1_ (u"ࠧࠨᩣ"),l1l11l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠภࠩᩤ"),l1l11l_l1_ (u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢะะ๊ํࠠหไิ๎ออࠠࠨᩥ")+str(l1l1lll1ll_l1_)+l1l11l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡฬๅี๏ฮวࠡࠩᩦ")+str(l1l1lll11l_l1_)+l1l11l_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้้ࠠำหࠥอไๆๆไࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ็่ฯำๅ๋ๆ้๋ࠣࠦวๅว้ฮึ์สࠡว็ํࠥา็ศิๆࠤ࠳ࠦ็ๅࠢส๊ฯࠦๅหลๆำࠥ๎สา์าࠤฬ๊วิฬ่ีฬืࠠษฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥลࠧᩧ"))
	if yes!=1:
		DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ᩨ"),l1l11l_l1_ (u"࠭ࠧᩩ"),l1l11l_l1_ (u"ࠧࠨᩪ"),l1l11l_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ᩫ"))
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᩬ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡷ࡫ࡦࡶࡵࡨࡨࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᩭ")+url2+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫᩮ")+l1l11llll1_l1_+l1l11l_l1_ (u"ࠬࠦ࡝ࠨᩯ"))
		return False
	LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᩰ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬᩱ"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l11llll1_l1_,l1l11l_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᩲ"))
	l1l1l11lll_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l1l11llll1_l1_,l1l11l_l1_ (u"ࠩࡺࡦࠬᩳ"))
	else: file = open(l1l11llll1_l1_.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᩴ")),l1l11l_l1_ (u"ࠫࡼࡨࠧ᩵"))
	if videofiletype==l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ᩶"): # l1l1l1ll1l_l1_ for l11l1111_l1_ and l1l1l1111l_l1_ chunks l1l1llll11_l1_ files such as .l1l1ll1l11_l1_
		for ii in range(1,l1l1l1l111_l1_+1):
			l1111l_l1_ = l1l1lll1_l1_[ii-1]
			if not l1111l_l1_.startswith(l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ᩷")):
				if l1111l_l1_.startswith(l1l11l_l1_ (u"ࠧ࠰࠱ࠪ᩸")): l1111l_l1_ = url2.split(l1l11l_l1_ (u"ࠨ࠼ࠪ᩹"),1)[0]+l1l11l_l1_ (u"ࠩ࠽ࠫ᩺")+l1111l_l1_
				elif l1111l_l1_.startswith(l1l11l_l1_ (u"ࠪ࠳ࠬ᩻")): l1111l_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ᩼"))+l1111l_l1_
				else: l1111l_l1_ = url2.rsplit(l1l11l_l1_ (u"ࠬ࠵ࠧ᩽"),1)[0]+l1l11l_l1_ (u"࠭࠯ࠨ᩾")+l1111l_l1_
			response = requests.request(l1l11l_l1_ (u"ࠧࡈࡇࡗ᩿ࠫ"),l1111l_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			t2 = time.time()
			l1l11lll11_l1_ = t2-t1
			l1l11lllll_l1_ = l1l11lll11_l1_//ii
			l1l1ll111l_l1_ = l1l11lllll_l1_*(l1l1l1l111_l1_+1)
			l1l1l111l1_l1_ = l1l1ll111l_l1_-l1l11lll11_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii//(l1l1l1l111_l1_+1)),l1l11l_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ᪀"),l1l11l_l1_ (u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ᪁"),str(ii*chunksize//MegaByte)+l1l11l_l1_ (u"ࠪ࠳ࠬ᪂")+str(l1l1lll1ll_l1_)+l1l11l_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ᪃")+time.strftime(l1l11l_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ᪄"),time.gmtime(l1l1l111l1_l1_))+l1l11l_l1_ (u"࠭ࠠแࠩ᪅"))
			if pDialog.iscanceled():
				l1l1l11lll_l1_ = False
				break
	else: # l11lll1l_l1_ and other l1l1ll11l1_l1_ file l1ll1111l1_l1_
		ii = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			ii = ii+1
			t2 = time.time()
			l1l11lll11_l1_ = t2-t1
			l1l11lllll_l1_ = l1l11lll11_l1_/ii
			l1l1ll111l_l1_ = l1l11lllll_l1_*(l1l1l1l111_l1_+1)
			l1l1l111l1_l1_ = l1l1ll111l_l1_-l1l11lll11_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii/(l1l1l1l111_l1_+1)),l1l11l_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ᪆"),l1l11l_l1_ (u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨ᪇"),str(ii*chunksize//MegaByte)+l1l11l_l1_ (u"ࠩ࠲ࠫ᪈")+str(l1l1lll1ll_l1_)+l1l11l_l1_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ᪉")+time.strftime(l1l11l_l1_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ᪊"),time.gmtime(l1l1l111l1_l1_))+l1l11l_l1_ (u"ࠬࠦเࠨ᪋"))
			if pDialog.iscanceled():
				l1l1l11lll_l1_ = False
				break
		response.close()
	file.close()
	pDialog.close()
	if not l1l1l11lll_l1_:
		LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭᪌"),LOGGING(script_name)+l1l11l_l1_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠲࡭ࡳࡺࡥࡳࡴࡸࡴࡹ࡫ࡤࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡱࡴࡲࡧࡪࡹࡳ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ᪍")+url2+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ᪎")+l1l11llll1_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠬ᪏"))
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ᪐"),l1l11l_l1_ (u"ࠫࠬ᪑"),l1l11l_l1_ (u"ࠬ࠭᪒"),l1l11l_l1_ (u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫ᪓"))
		return True
	LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ᪔"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ᪕")+url2+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ᪖")+l1l11llll1_l1_+l1l11l_l1_ (u"ࠪࠤࡢ࠭᪗"))
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ᪘"),l1l11l_l1_ (u"ࠬ࠭᪙"),l1l11l_l1_ (u"࠭ࠧ᪚"),l1l11l_l1_ (u"ࠧห็ࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠษ่ฯหา࠭᪛"))
	return True
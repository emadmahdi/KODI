# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧᇸ")
menu_name = l1l11l_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨᇹ")
l11lll_l1_ = WEBSITES[script_name][0]
headers = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᇺ"):l1l11l_l1_ (u"ࠫࠬᇻ")}
l1llll1_l1_ = [l1l11l_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠫᇼ"),l1l11l_l1_ (u"࠭ศไำสࠤ࡙࡜ࠧᇽ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l111l1_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==373: results = l1l1l1ll1_l1_(url)
	elif mode==374: results = l11l11lll_l1_(url)
	elif mode==375: results = l11l111ll_l1_(url)
	elif mode==376: results = l11l11l11_l1_(0,url)
	elif mode==377: results = l11l11l11_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᇾ"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩᇿ"),l1l11l_l1_ (u"ࠩࠪሀ"),l1l11l_l1_ (u"ࠪࠫሁ"),l1l11l_l1_ (u"ࠫࠬሂ"),l1l11l_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ሃ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ሄ"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧህ"),l1l11l_l1_ (u"ࠨࠩሆ"),379,l1l11l_l1_ (u"ࠩࠪሇ"),l1l11l_l1_ (u"ࠪࠫለ"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨሉ"))
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪሊ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ላ"),l1l11l_l1_ (u"ࠧࠨሌ"),9999)
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺ࠭ࡴ࡫ࡧࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨል"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨሎ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if not any(value in title for value in l1llll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪሏ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ሐ")+menu_name+title,l1111l_l1_,371)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬሑ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨሒ")+menu_name+l1l11l_l1_ (u"ࠧศๆ่้๏ุษࠨሓ"),l11lll_l1_,375)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨሔ"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫሕ")+menu_name+l1l11l_l1_ (u"ࠪห้ษอะอࠪሖ"),l11lll_l1_,376)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሗ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧመ")+menu_name+l1l11l_l1_ (u"๊࠭ีษ๊ำࠥอไร่ࠪሙ"),l11lll_l1_,377)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧሚ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪማ")+menu_name+l1l11l_l1_ (u"ࠩๅหห๋ษࠡษ็้ํู่ࠨሜ"),l11lll_l1_,373)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪም"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ሞ")+menu_name+l1l11l_l1_ (u"่ࠬวว็ฬࠤฬ๊ๅๆอ็๎๋࠭ሟ"),l11lll_l1_,374)
	return
def l1l1l1ll1_l1_(website=l1l11l_l1_ (u"࠭ࠧሠ")):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫሡ"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩሢ"),l1l11l_l1_ (u"ࠩࠪሣ"),l1l11l_l1_ (u"ࠪࠫሤ"),l1l11l_l1_ (u"ࠫࠬሥ"),l1l11l_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩሦ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡵࡱࡳ࠱ࡲ࡫࡮ࡶࠩሧ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ረ"),block,re.DOTALL)
		for l1111l_l1_,title in items[7:]:
			title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪሩ"))
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if not any(value in title for value in l1llll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩሪ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬራ")+menu_name+title,l1111l_l1_,371)
		for l1111l_l1_,title in items[0:7]:
			title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭ሬ"))
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if not any(value in title for value in l1llll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬር"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨሮ")+menu_name+title,l1111l_l1_,371)
	return html
def l11l11lll_l1_(website=l1l11l_l1_ (u"ࠧࠨሯ")):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬሰ"),l11lll_l1_,l1l11l_l1_ (u"ࠩࠪሱ"),l1l11l_l1_ (u"ࠪࠫሲ"),l1l11l_l1_ (u"ࠫࠬሳ"),l1l11l_l1_ (u"ࠬ࠭ሴ"),l1l11l_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡇࡃࡕࡑࡕࡗࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ስ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠤࡨࡧࡴࠡࡖࡤ࡫ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫሶ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሷ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧሸ") in l1111l_l1_: continue
			else: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if not any(value in title for value in l1llll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪሹ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ሺ")+menu_name+title,l1111l_l1_,371)
	return
def l11l111ll_l1_(website=l1l11l_l1_ (u"ࠬ࠭ሻ")):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪሼ"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨሽ"),l1l11l_l1_ (u"ࠨࠩሾ"),l1l11l_l1_ (u"ࠩࠪሿ"),l1l11l_l1_ (u"ࠪࠫቀ"),l1l11l_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡊࡊࡇࡔࡖࡔࡈࡈ࠲࠷ࡳࡵࠩቁ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠧቂ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫቃ"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if not any(value in title for value in l1llll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ቄ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪቅ")+menu_name+title,l1111l_l1_,372,img)
	return
def l11l11l11_l1_(id,website=l1l11l_l1_ (u"ࠩࠪቆ")):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧቇ"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬቈ"),l1l11l_l1_ (u"ࠬ࠭቉"),l1l11l_l1_ (u"࠭ࠧቊ"),l1l11l_l1_ (u"ࠧࠨቋ"),l1l11l_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡘࡃࡗࡇࡍࡏࡎࡈࡐࡒ࡛࠲࠷ࡳࡵࠩቌ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨቍ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[id]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭቎"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if not any(value in title for value in l1llll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ቏"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧቐ")+menu_name+title,l1111l_l1_,372,img)
	return
def l111l1_l1_(url,type1=l1l11l_l1_ (u"࠭ࠧቑ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨቒ"),l1l11l_l1_ (u"ࠨࠩቓ"),type1,url)
	#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩቔ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧቕ"),url,l1l11l_l1_ (u"ࠫࠬቖ"),l1l11l_l1_ (u"ࠬ࠭቗"),l1l11l_l1_ (u"࠭ࠧቘ"),l1l11l_l1_ (u"ࠧࠨ቙"),l1l11l_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫቚ"))
	html = response.content
	if l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡶࡡࡨࡧࡢࠫቛ") in url:
		l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡆࡲࡢࡶ࡯࠰࠲࠯ࡅࠩࠣࠩቜ"),html,re.DOTALL)
		if l1111l_l1_:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_[0]
			l111l1_l1_(l1111l_l1_)
			return
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࠥࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡯ࡧ࠱࠸࠭ቝ"),html,re.DOTALL)
	if type1==l1l11l_l1_ (u"ࠬ࠭቞") and l1ll111_l1_ and l1ll111_l1_[0].count(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࠫ቟"))>1:
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧበ"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ูࠨቡ"),url,371,l1l11l_l1_ (u"ࠩࠪቢ"),l1l11l_l1_ (u"ࠪࠫባ"),l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡶࠫቤ"))
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫብ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࠨቦ")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩቧ"))
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨቨ"),menu_name+title,l1111l_l1_,371)
	else:
		l1l1l11_l1_ = []
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡭ࡥ࠯࠶ࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡾࡳ࠮࠳࠵ࠫቩ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠼ࠧ࠮࠮ࠫࡁࠬࡧࡴࡲ࠭ࡹࡵ࠰࠵࠷࠭ቪ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ቫ"),block,re.DOTALL)
			l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵ࠤࡂ࡛ࠦ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸࡷࡿ࠺ࠡࡥࡲࡹࡳࡺࠠ࠾ࠢ࡬ࡲࡹ࠮ࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫฬ๊อๅไฬࠤ࠰࠮࡜ࡥ࠭ࠬࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠ࠭ࠏࠏࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡧࡴࡻ࡮ࡵࠢࡀࠤ࠲࠷ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵࠲ࡦࡶࡰࡦࡰࡧࠬ࠭ࡲࡩ࡯࡭࠯࡭ࡲ࡭ࠬࡵ࡫ࡷࡰࡪ࠲ࡣࡰࡷࡱࡸ࠮࠯ࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡮ࡺࡥ࡮ࡵ࠵࠰ࠥࡸࡥࡷࡧࡵࡷࡪࡃࡆࡢ࡮ࡶࡩ࠱ࠦ࡫ࡦࡻࡀࡰࡦࡳࡢࡥࡣࠣ࡯ࡪࡿ࠺ࠡ࡭ࡨࡽࡠ࠹࡝ࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡧࡴࡻ࡮ࡵࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠤࠥࠦቬ")
			for l1111l_l1_,img,title in items:
				#img = l11lll_l1_+img
				l1111l_l1_ = l11lll_l1_+l1111l_l1_
				title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨቭ"))
				if l1l11l_l1_ (u"ࠧ࠰ࡣ࡯ࡣࠬቮ") in l1111l_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨቯ"),menu_name+title,l1111l_l1_,371,img)
				elif l1l11l_l1_ (u"ࠩส่า๊โสࠩተ") in title and (l1l11l_l1_ (u"ࠪ࠳ࡈࡧࡴ࠮ࠩቱ") in url or l1l11l_l1_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬࠴࠭ቲ") in url):
					l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠲ࠦࠫศๆะ่็ฯࠠࠬ࡞ࡧ࠯ࠬታ"),title,re.DOTALL)
					if l1ll1ll_l1_: title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣู๊ไิๆࠣࠫቴ")+l1ll1ll_l1_[0]
					if title not in l1l1l11_l1_:
						l1l1l11_l1_.append(title)
						addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧት"),menu_name+title,l1111l_l1_,371,img)
				else: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧቶ"),menu_name+title,l1111l_l1_,372,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪቷ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ቸ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				l1111l_l1_ = l11lll_l1_+l1111l_l1_
				title = l1l11l_l1_ (u"ฺࠫ็อสࠢࠪቹ")+unescapeHTML(title)
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬቺ"),menu_name+title,l1111l_l1_,371,l1l11l_l1_ (u"࠭ࠧቻ"),l1l11l_l1_ (u"ࠧࠨቼ"),l1l11l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࡳࠨች"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ቾ"),url,l1l11l_l1_ (u"ࠪࠫቿ"),l1l11l_l1_ (u"ࠫࠬኀ"),l1l11l_l1_ (u"ࠬ࠭ኁ"),l1l11l_l1_ (u"࠭ࠧኂ"),l1l11l_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨኃ"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡮ࡤࡦࡪࡲ࠭ࡴࡷࡦࡧࡪࡹࡳࠡ࡯ࡵ࡫࠲ࡨࡴ࡮࠯࠸ࠤࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ኄ"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	url3 = l1l11l_l1_ (u"ࠩࠪኅ")
	url2 = re.findall(l1l11l_l1_ (u"ࠪࡺࡦࡸࠠࡶࡴ࡯ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧኆ"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡼࡩࡥࡲࡤ࡫ࡪࡥࠧኇ"),l1l11l_l1_ (u"ࠬ࠵ࡐ࡭ࡣࡼ࠳ࠬኈ"))
	if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ኉") not in url2: url2 = l11lll_l1_+url2
	url2 = url2.strip(l1l11l_l1_ (u"ࠧ࠮ࠩኊ"))
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬኋ"),url2,l1l11l_l1_ (u"ࠩࠪኌ"),l1l11l_l1_ (u"ࠪࠫኍ"),l1l11l_l1_ (u"ࠫࠬ኎"),l1l11l_l1_ (u"ࠬ࠭኏"),l1l11l_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧነ"))
	l1ll1ll1_l1_ = response.content
	url3 = re.findall(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬኑ"),l1ll1ll1_l1_,re.DOTALL)
	if url3:
		url3 = url3[-1]
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ኒ") not in url3: url3 = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨና")+url3
		if l1l11l_l1_ (u"ࠪ࠳ࡕࡒࡁ࡚࠱ࠪኔ") not in url2:
			if l1l11l_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠱ࡱ࡮ࡴ࠮࡫ࡵࠪን") in url3:
				l11l11l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡴࡺࡨ࡬ࡪࡵ࡫ࡩࡷ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫኖ"),l1ll1ll1_l1_,re.DOTALL)
				if l11l11l1l_l1_:
					l11l111l1_l1_, l11l11ll1_l1_ = l11l11l1l_l1_[0]
					url3 = SERVER(url3,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪኗ"))+l1l11l_l1_ (u"ࠧ࠰ࡸ࠵࠳ࠬኘ")+l11l111l1_l1_+l1l11l_l1_ (u"ࠨ࠱ࡦࡳࡳ࡬ࡩࡨ࠱ࠪኙ")+l11l11ll1_l1_+l1l11l_l1_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨኚ")
		import ll_l1_
		ll_l1_.l1l_l1_([url3],script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩኛ"))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬኜ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭ኝ"): return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨኞ"),l1l11l_l1_ (u"ࠧࠬࠩኟ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡖࡩࡦࡸࡣࡩ࠱ࠪአ")+search
	l111l1_l1_(url)
	return
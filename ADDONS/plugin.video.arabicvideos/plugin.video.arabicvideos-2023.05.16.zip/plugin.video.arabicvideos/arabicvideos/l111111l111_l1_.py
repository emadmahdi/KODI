# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ䛄")
headers = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䛅"):l1l11l_l1_ (u"ࠩࠪ䛆")}
menu_name = l1l11l_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ䛇")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ䛈"),l1l11l_l1_ (u"ࠬࡽࡷࡦࠩ䛉")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l111l1_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l111ll_l1_(url,text)
	elif mode==564: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭䛊")+text)
	elif mode==565: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ䛋")+text)
	elif mode==566: results = l1l1l1ll1_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䛌"),l11lll_l1_,l1l11l_l1_ (u"ࠩࠪ䛍"),l1l11l_l1_ (u"ࠪࠫ䛎"),False,l1l11l_l1_ (u"ࠫࠬ䛏"),l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䛐"))
	#hostname = response.headers[l1l11l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䛑")]
	#hostname = hostname.strip(l1l11l_l1_ (u"ࠧ࠰ࠩ䛒"))
	#l111l11l1_l1_ = l11lll_l1_
	#url = l111l11l1_l1_+l1l11l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䛓")
	#url = l111l11l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䛔"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ䛕"),l1l11l_l1_ (u"ࠫࠬ䛖"),l1l11l_l1_ (u"ࠬ࠭䛗"),l1l11l_l1_ (u"࠭ࠧ䛘"),l1l11l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䛙"))
	#addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䛚"),menu_name+l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䛛"),l1l11l_l1_ (u"ࠪࠫ䛜"),8)
	#addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䛝"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䛞"),l1l11l_l1_ (u"࠭ࠧ䛟"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䛠"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䛡"),l11lll_l1_,569,l1l11l_l1_ (u"ࠩࠪ䛢"),l1l11l_l1_ (u"ࠪࠫ䛣"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛤"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䛥"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ䛦"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䛧"),564)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䛨"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ䛩"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䛪"),565)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䛫"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䛬"),l1l11l_l1_ (u"࠭ࠧ䛭"),9999)
	#headers2 = {l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䛮"):hostname,l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䛯"):l1l11l_l1_ (u"ࠩࠪ䛰")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l11l_l1_ (u"ࠪࡠ࠴࠭䛱"),l1l11l_l1_ (u"ࠫ࠴࠭䛲"))
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡸࡩࡨࡪࡷࡦࡦࡸࠨ࠯ࠬࡂ࠭࡫࡯࡬ࡵࡧࡵࠫ䛳"),html,re.DOTALL)
	#if l1ll111_l1_:
	#	block = l1ll111_l1_[0]
	#	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ䛴"),block,re.DOTALL)
	#	for l1111l_l1_,title in items:
	#		if l1l11l_l1_ (u"ࠧࠦࡦ࠼ࠩ࠽࠻ࠥࡥ࠺ࠨࡦ࠺ࠫࡤ࠹ࠧࡤ࠻ࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡣ࠻ࠨࡨ࠽ࠫࡡ࠺࠯ࠨࡨ࠽ࠫࡡࡥࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡦ࠿ࠧ䛵") in l1111l_l1_: continue
	#		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䛶"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䛷")+menu_name+title,l1111l_l1_,566)
	#	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䛸"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䛹"),l1l11l_l1_ (u"ࠬ࠭䛺"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䛻"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ䛼"),l1l11l_l1_ (u"ࠨࠩ䛽"),l1l11l_l1_ (u"ࠩࠪ䛾"),l1l11l_l1_ (u"ࠪࠫ䛿"),l1l11l_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䜀"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭䜁"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䜂"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ䜃") not in l1111l_l1_:
			#	server = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ䜄"))
			#	l1111l_l1_ = l1111l_l1_.replace(server,l111l11l1_l1_)
			if title==l1l11l_l1_ (u"ࠩࠪ䜅"): continue
			if any(value in title.lower() for value in l1llll1_l1_): continue
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䜆"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䜇")+menu_name+title,l1111l_l1_,566)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䜈"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䜉"),l1l11l_l1_ (u"ࠧࠨ䜊"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ䜋"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䜌"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䜍"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䜎")+menu_name+title,l1111l_l1_,566,img)
	return html
def l1l1l1ll1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䜏"),l1l11l_l1_ (u"࠭ࠧ䜐"),url,l1l11l_l1_ (u"ࠧࠨ䜑"))
	#headers2 = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䜒"):url,l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䜓"):l1l11l_l1_ (u"ࠪࠫ䜔")}
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䜕"),url,l1l11l_l1_ (u"ࠬ࠭䜖"),l1l11l_l1_ (u"࠭ࠧ䜗"),l1l11l_l1_ (u"ࠧࠨ䜘"),l1l11l_l1_ (u"ࠨࠩ䜙"),l1l11l_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䜚"))
	html = response.content
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䜛"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䜜"),url,564)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䜝"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䜞"),url,565)
	if l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ䜟") in html:
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䜠"),menu_name+l1l11l_l1_ (u"ࠩส่๊๋๊ำหࠪ䜡"),url,561,l1l11l_l1_ (u"ࠪࠫ䜢"),l1l11l_l1_ (u"ࠫࠬ䜣"),l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䜤"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ䜥"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䜦"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䜧"),menu_name+title,l1111l_l1_,561)
	return
def l111l1_l1_(l1l1ll1l1l1_l1_,type=l1l11l_l1_ (u"ࠩࠪ䜨")):
	if l1l11l_l1_ (u"ࠪ࠾࠿࠭䜩") in l1l1ll1l1l1_l1_:
		url3,url = l1l1ll1l1l1_l1_.split(l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䜪"))
		server = SERVER(url3,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ䜫"))
		url = server+url
	else: url,url3 = l1l1ll1l1l1_l1_,l1l1ll1l1l1_l1_
	#headers2 = {l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䜬"):url3,l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䜭"):l1l11l_l1_ (u"ࠨࠩ䜮")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䜯"),url,l1l11l_l1_ (u"ࠪࠫ䜰"),l1l11l_l1_ (u"ࠫࠬ䜱"),l1l11l_l1_ (u"ࠬ࠭䜲"),l1l11l_l1_ (u"࠭ࠧ䜳"),l1l11l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䜴"))
	html = response.content
	if type==l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䜵"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭䜶"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䜷"):
		l1ll111_l1_ = [html.replace(l1l11l_l1_ (u"ࠫࡡࡢ࠯ࠨ䜸"),l1l11l_l1_ (u"ࠬ࠵ࠧ䜹")).replace(l1l11l_l1_ (u"࠭࡜࡝ࠤࠪ䜺"),l1l11l_l1_ (u"ࠧࠣࠩ䜻"))]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡉࡵ࡭ࡩ࠳࠭ࡘࡧࡦ࡭ࡲࡧࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䜼"),html,re.DOTALL)
	l1l1l11_l1_ = []
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࡊࡶ࡮ࡪࡉࡵࡧࡰࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ䜽"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			if any(value in title.lower() for value in l1llll1_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l11l_l1_ (u"ู้ࠪอ็ะหࠣࠫ䜾"),l1l11l_l1_ (u"ࠫࠬ䜿"))
			if l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䝀") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝁"),menu_name+title,l1111l_l1_,563,img)
			elif l1l11l_l1_ (u"ࠧฮๆๅอࠬ䝂") in title:
				l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ䝃"),title,re.DOTALL)
				if l1ll1ll_l1_: title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䝄") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					l1l1l11_l1_.append(title)
					addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝅"),menu_name+title,l1111l_l1_,563,img)
			else:
				addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䝆"),menu_name+title,l1111l_l1_,562,img)
		if type==l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䝇"):
			l1lllllll1l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ䝈"),block,re.DOTALL)
			if l1lllllll1l_l1_:
				count = l1lllllll1l_l1_[0]
				l1111l_l1_ = url+l1l11l_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ䝉")+count
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝊"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ䝋"),l1111l_l1_,561,l1l11l_l1_ (u"ࠪࠫ䝌"),l1l11l_l1_ (u"ࠫࠬ䝍"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䝎"))
		elif type==l1l11l_l1_ (u"࠭ࠧ䝏"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䝐"),html,re.DOTALL)
			if l1ll111_l1_:
				block = l1ll111_l1_[0]
				items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䝑"),block,re.DOTALL)
				for l1111l_l1_,title in items:
					title = l1l11l_l1_ (u"ุࠩๅาฯࠠࠨ䝒")+unescapeHTML(title)
					addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝓"),menu_name+title,l1111l_l1_,561)
	return
def l111ll_l1_(url,type=l1l11l_l1_ (u"ࠫࠬ䝔")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䝕"),l1l11l_l1_ (u"࠭ࠧ䝖"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䝗"),url,l1l11l_l1_ (u"ࠨࠩ䝘"),l1l11l_l1_ (u"ࠩࠪ䝙"),l1l11l_l1_ (u"ࠪࠫ䝚"),l1l11l_l1_ (u"ࠫࠬ䝛"),l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䝜"))
	html = response.content
	html = UNQUOTE(html)
	l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࡞࠱࠶ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠰ࠫ࠱࠭ࠠࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪ࠳ࠬ࠯ࠊࠊ࡫ࡩࠤ๋่ࠬิ็ࠪࠤ࡮ࡴࠠ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡴࡺࡲࡨ࠾ࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡹࡰ࡭࡫ࡷ๋่ࠬࠬิ็ࠪ࠭ࡠ࠶࡝ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡴࡨࡴࡱࡧࡣࡦู้ࠪࠪอ็ะหࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬำไใหࠪࠤ࡮ࡴࠠ࡯ࡣࡰࡩ࠿ࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭อๅไฬࠫ࠮ࡡ࠰࡞ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧฺ๊ࠫࠫว่ัฬࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠣࠤࠥ䝝")
	# l111l111l_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䝞"),html,re.DOTALL)
	if not type and l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ䝟"),block,re.DOTALL)
		if len(items)>1:
			for l1111l_l1_,title in items:
				#title = name+l1l11l_l1_ (u"ࠩࠣ࠱ࠥ࠭䝠")+title
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝡"),menu_name+title,l1111l_l1_,563,l1l11l_l1_ (u"ࠫࠬ䝢"),l1l11l_l1_ (u"ࠬ࠭䝣"),l1l11l_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ䝤"))
			return
	# l1l11l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳࡹ࠾ࠨ䝥"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ䝦"),block)
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠪ䝧"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ䝨"),str(items))
		for l1111l_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭䝩"))
			#title = name+l1l11l_l1_ (u"ࠬࠦ࠭ࠡࠩ䝪")+title
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䝫"),menu_name+title,l1111l_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䝬"),html,re.DOTALL)
		if title: title = title[0].replace(l1l11l_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭䝭"),l1l11l_l1_ (u"ࠩࠪ䝮")).replace(l1l11l_l1_ (u"ู้ࠪอ็ะหࠣࠫ䝯"),l1l11l_l1_ (u"ࠫࠬ䝰"))
		else: title = l1l11l_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ䝱")
		addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䝲"),menu_name+title,url,562)
	return
def PLAY(url):
	l1ll1l1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䝳"),url,l1l11l_l1_ (u"ࠨࠩ䝴"),l1l11l_l1_ (u"ࠩࠪ䝵"),l1l11l_l1_ (u"ࠪࠫ䝶"),l1l11l_l1_ (u"ࠫࠬ䝷"),l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䝸"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䝹"),html,re.DOTALL)
	if l1l1l_l1_:
		l1l1l_l1_ = [l1l1l_l1_[0][0],l1l1l_l1_[0][1]]
		if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭䝺"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䝻"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䝼") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if name==l1l11l_l1_ (u"ࠪื๏ืแา๋ࠢ๎ู๊ࠥๆษࠪ䝽"): name = l1l11l_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ䝾")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䝿")+name+l1l11l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䞀")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䞁"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䞂"),block,re.DOTALL)
		for l1111l_l1_,l1l1l111_l1_ in items:
			if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䞃") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ䞄"),l1l1l111_l1_,re.DOTALL)
			if l1l1l111_l1_: l1l1l111_l1_ = l1l11l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ䞅")+l1l1l111_l1_[0]
			else: l1l1l111_l1_ = l1l11l_l1_ (u"ࠬ࠭䞆")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡷࡦࡥ࡬ࡱࡦ࠭䞇")+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䞈")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䞉"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䞊"),url)
	return
def SEARCH(search,hostname=l1l11l_l1_ (u"ࠪࠫ䞋")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬ䞌"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭䞍"): return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ䞎"),l1l11l_l1_ (u"ࠧࠬࠩ䞏"))
	l1ll1l1l_l1_ = [l1l11l_l1_ (u"ࠨ࠱ࠪ䞐"),l1l11l_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡵࡨࡶ࡮࡫ࡳࠨ䞑"),l1l11l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡤࡲ࡮ࡳࡥࠨ䞒"),l1l11l_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡸࡻ࠭䞓"),l1l11l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ䞔")]
	l1lll1l11ll_l1_ = [l1l11l_l1_ (u"࠭วๅลไ่ฬ๋ࠧ䞕"),l1l11l_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ䞖"),l1l11l_l1_ (u"ࠨษ็ห๋๐ๅ๋๋ࠢࠤฬ๊ใาฬ๋๊ࠬ䞗"),l1l11l_l1_ (u"ࠩส่อืวๆฮࠣฮ้๐แำ์๋๊๏ฯࠧ䞘"),l1l11l_l1_ (u"ࠪ฾๏ืࠠๆฯาำࠬ䞙")]
	if showdialogs:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ䞚"), l1lll1l11ll_l1_)
		if selection==-1: return
	else: selection = 4
	if not hostname:
		hostname = l11lll_l1_
		#response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䞛"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ䞜"),l1l11l_l1_ (u"ࠧࠨ䞝"),False,l1l11l_l1_ (u"ࠨࠩ䞞"),l1l11l_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭䞟"))
		#hostname = response.headers[l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䞠")]
		#hostname = response.url
		#hostname = hostname.strip(l1l11l_l1_ (u"ࠫ࠴࠭䞡"))
	url2 = hostname+l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ䞢")+search+l1ll1l1l_l1_[selection]
	l111l1_l1_(url2)
	return
def l1l1l1l_l1_(l1l1ll1l1l1_l1_,filter):
	if l1l11l_l1_ (u"࠭࠿ࡀࠩ䞣") in l1l1ll1l1l1_l1_: url = l1l1ll1l1l1_l1_.split(l1l11l_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䞤"))[0]
	else: url = l1l1ll1l1l1_l1_
	#headers2 = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䞥"):l1l1ll1l1l1_l1_,l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䞦"):l1l11l_l1_ (u"ࠪࠫ䞧")}
	filter = filter.replace(l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䞨"),l1l11l_l1_ (u"ࠬ࠭䞩"))
	type,filter = filter.split(l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ䞪"),1)
	if filter==l1l11l_l1_ (u"ࠧࠨ䞫"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠨࠩ䞬"),l1l11l_l1_ (u"ࠩࠪ䞭")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䞮"))
	if type==l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䞯"):
		if l1ll11ll1_l1_[0]+l1l11l_l1_ (u"ࠬࡃ࠽ࠨ䞰") not in l1lllll1_l1_: category = l1ll11ll1_l1_[0]
		for i in range(len(l1ll11ll1_l1_[0:-1])):
			if l1ll11ll1_l1_[i]+l1l11l_l1_ (u"࠭࠽࠾ࠩ䞱") in l1lllll1_l1_: category = l1ll11ll1_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪ䞲")+category+l1l11l_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䞳")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬ䞴")+category+l1l11l_l1_ (u"ࠪࡁࡂ࠶ࠧ䞵")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠫࠫࠬࠧ䞶"))+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䞷")+l11l111_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠧࠩ䞸"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䞹"))
		url2 = url+l1l11l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䞺")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ䞻"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ䞼"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠫࠬ䞽"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䞾"))
		if l1llll1l_l1_==l1l11l_l1_ (u"࠭ࠧ䞿"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䟀")+l1llll1l_l1_
		l11l1ll1_l1_ = l1l1l11l1_l1_(url2,l1l1ll1l1l1_l1_)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䟁"),menu_name+l1l11l_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ䟂"),l11l1ll1_l1_,561,l1l11l_l1_ (u"ࠪࠫ䟃"),l1l11l_l1_ (u"ࠫࠬ䟄"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䟅"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䟆"),menu_name+l1l11l_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ䟇")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ䟈"),l11l1ll1_l1_,561,l1l11l_l1_ (u"ࠩࠪ䟉"),l1l11l_l1_ (u"ࠪࠫ䟊"),l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䟋"))
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䟌"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䟍"),l1l11l_l1_ (u"ࠧࠨ䟎"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䟏"),url,l1l11l_l1_ (u"ࠩࠪ䟐"),l1l11l_l1_ (u"ࠪࠫ䟑"),l1l11l_l1_ (u"ࠫࠬ䟒"),l1l11l_l1_ (u"ࠬ࠭䟓"),l1l11l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䟔"))
	html = response.content
	html = html.replace(l1l11l_l1_ (u"ࠧ࡝࡞ࠥࠫ䟕"),l1l11l_l1_ (u"ࠨࠤࠪ䟖")).replace(l1l11l_l1_ (u"ࠩ࡟ࡠ࠴࠭䟗"),l1l11l_l1_ (u"ࠪ࠳ࠬ䟘"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ䟙"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ䟚"),block+l1l11l_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ䟛"),re.DOTALL)
	dict = {}
	for l1l111l_l1_,name,block in l1l1ll1_l1_:
		name = escapeUNICODE(name)
		if l1l11l_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ䟜") in l1l111l_l1_: continue
		items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ䟝"),block,re.DOTALL)
		if l1l11l_l1_ (u"ࠩࡀࡁࠬ䟞") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䟟"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l1ll11ll1_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ䟠")+l1111l1_l1_)
				return
			else:
				l11l1ll1_l1_ = l1l1l11l1_l1_(url2,l1l1ll1l1l1_l1_)
				if l1l111l_l1_==l1ll11ll1_l1_[-1]:
					addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䟡"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾࠭䟢"),l11l1ll1_l1_,561,l1l11l_l1_ (u"ࠧࠨ䟣"),l1l11l_l1_ (u"ࠨࠩ䟤"),l1l11l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䟥"))
				else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䟦"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ䟧"),url2,564,l1l11l_l1_ (u"ࠬ࠭䟨"),l1l11l_l1_ (u"࠭ࠧ䟩"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䟪"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫ䟫")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࡁ࠵࠭䟬")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭䟭")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂࡃ࠰ࠨ䟮")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䟯")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䟰"),menu_name+name+l1l11l_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ䟱"),url2,565,l1l11l_l1_ (u"ࠨࠩ䟲"),l1l11l_l1_ (u"ࠩࠪ䟳"),l1111l1_l1_+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟴"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l11l_l1_ (u"ࠫࡷ࠭䟵") or value==l1l11l_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ䟶"): continue
			if any(value in option.lower() for value in l1llll1_l1_): continue
			if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䟷") in option: continue
			if l1l11l_l1_ (u"ࠧศๆๆ่ࠬ䟸") in option: continue
			if l1l11l_l1_ (u"ࠨࡰ࠰ࡥࠬ䟹") in value: continue
			#if value in [l1l11l_l1_ (u"ࠩࡵࠫ䟺"),l1l11l_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ䟻"),l1l11l_l1_ (u"ࠫࡹࡼ࠭࡮ࡣࠪ䟼")]: continue
			#if l1l111l_l1_==l1l11l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䟽"): option = value
			if option==l1l11l_l1_ (u"࠭ࠧ䟾"): option = value
			l1l11lll1_l1_ = option
			name1 = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡰࡤࡱࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢ࡯ࡨࡂࠬ䟿"),option,re.DOTALL)
			if name1: l1l11lll1_l1_ = name1[0]
			title2 = name+l1l11l_l1_ (u"ࠨ࠼ࠣࠫ䠀")+l1l11lll1_l1_
			dict[l1l111l_l1_][value] = title2
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬ䠁")+l1l111l_l1_+l1l11l_l1_ (u"ࠪࡁࡂ࠭䠂")+l1l11lll1_l1_
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠫࠫࠬࠧ䠃")+l1l111l_l1_+l1l11l_l1_ (u"ࠬࡃ࠽ࠨ䠄")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ䠅")+l11l111_l1_
			if type==l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䠆"):
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠇"),menu_name+title2,url,565,l1l11l_l1_ (u"ࠩࠪ䠈"),l1l11l_l1_ (u"ࠪࠫ䠉"),l1l1111_l1_+l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䠊"))
			elif type==l1l11l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ䠋") and l1ll11ll1_l1_[-2]+l1l11l_l1_ (u"࠭࠽࠾ࠩ䠌") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䠍"))
				#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䠎"),l1l11l_l1_ (u"ࠩࠪ䠏"),l1lll1l1_l1_,l11l111_l1_)
				url3 = url+l1l11l_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䠐")+l1lll1l1_l1_
				l11l1ll1_l1_ = l1l1l11l1_l1_(url3,l1l1ll1l1l1_l1_)
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䠑"),menu_name+title2,l11l1ll1_l1_,561,l1l11l_l1_ (u"ࠬ࠭䠒"),l1l11l_l1_ (u"࠭ࠧ䠓"),l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䠔"))
			else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠕"),menu_name+title2,url,564,l1l11l_l1_ (u"ࠩࠪ䠖"),l1l11l_l1_ (u"ࠪࠫ䠗"),l1l1111_l1_)
	return
l1ll11ll1_l1_ = [l1l11l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䠘"),l1l11l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䠙"),l1l11l_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭䠚")]
l1ll111l1_l1_ = [l1l11l_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ䠛"),l1l11l_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ䠜"),l1l11l_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ䠝"),l1l11l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ䠞"),l1l11l_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ䠟"),l1l11l_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ䠠"),l1l11l_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭䠡"),l1l11l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ䠢")]
def l1l1l11l1_l1_(url2,url3):
	if l1l11l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䠣") in url2: url2 = url2.replace(l1l11l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䠤"),l1l11l_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ䠥"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䠦"),l1l11l_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ䠧"))
	url2 = url2.replace(l1l11l_l1_ (u"࠭࠽࠾ࠩ䠨"),l1l11l_l1_ (u"ࠧ࠰ࠩ䠩"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠨࠨࠩࠫ䠪"),l1l11l_l1_ (u"ࠩ࠲ࠫ䠫"))
	return url2
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䠬"),l1l11l_l1_ (u"ࠫࠬ䠭"),filters,l1l11l_l1_ (u"ࠬࡏࡎࠡࠢࠣࠤࠬ䠮")+mode)
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䠯")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䠰")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠨࡣ࡯ࡰࠬ䠱")					all filters (l1lll111_l1_ l111l1l_l1_ filter)
	filters = filters.strip(l1l11l_l1_ (u"ࠩࠩࠪࠬ䠲"))
	l1llllll_l1_,l11llll_l1_ = {},l1l11l_l1_ (u"ࠪࠫ䠳")
	if l1l11l_l1_ (u"ࠫࡂࡃࠧ䠴") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠬࠬࠦࠨ䠵"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"࠭࠽࠾ࠩ䠶"))
			l1llllll_l1_[var] = value
	for key in l1ll111l1_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠧ࠱ࠩ䠷")
		if l1l11l_l1_ (u"ࠨࠧࠪ䠸") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䠹") and value!=l1l11l_l1_ (u"ࠪ࠴ࠬ䠺"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠥ࠱ࠠࠨ䠻")+value
		elif mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䠼") and value!=l1l11l_l1_ (u"࠭࠰ࠨ䠽"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪ䠾")+key+l1l11l_l1_ (u"ࠨ࠿ࡀࠫ䠿")+value
		elif mode==l1l11l_l1_ (u"ࠩࡤࡰࡱ࠭䡀"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭䡁")+key+l1l11l_l1_ (u"ࠫࡂࡃࠧ䡂")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠬࠦࠫࠡࠩ䡃"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠧࠩ䡄"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䡅"),l1l11l_l1_ (u"ࠨࠩ䡆"),l11llll_l1_,l1l11l_l1_ (u"ࠩࡒ࡙࡙࠭䡇"))
	return l11llll_l1_
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗࠬㅻ")
menu_name = l1l11l_l1_ (u"ࠬࡥࡌࡔࡖࡢࠫㅼ")
l1l1l1ll11l_l1_ = 5
l1l1l11lll1_l1_ = 10
def MAIN(mode,url,text,page):
	if   mode==160: results = MENU()
	elif mode==161: results = l1l1ll11lll_l1_(text)
	elif mode==162: results = l1l1l111111_l1_(text,162)
	elif mode==163: results = l1l1l111111_l1_(text,163)
	elif mode==164: results = l1l1ll11l1l_l1_(text)
	elif mode==165: results = l1l1l1ll111_l1_(text,page)
	elif mode==166: results = l1l1l1llll1_l1_(url,text)
	elif mode==167: results = l1l11ll1l1l_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅽ"),l1l11l_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์ฺࠠึ๋หห๐ษࠨㅾ"),l1l11l_l1_ (u"ࠨࠩㅿ"),161,l1l11l_l1_ (u"ࠩࠪㆀ"),l1l11l_l1_ (u"ࠪࠫㆁ"),l1l11l_l1_ (u"ࠫࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪㆂ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㆃ"),l1l11l_l1_ (u"࠭โิ็ࠣ฽ู๎วว์ࠪㆄ"),l1l11l_l1_ (u"ࠧࠨㆅ"),162,l1l11l_l1_ (u"ࠨࠩㆆ"),l1l11l_l1_ (u"ࠩࠪㆇ"),l1l11l_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧㆈ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆉ"),l1l11l_l1_ (u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠨㆊ"),l1l11l_l1_ (u"࠭ࠧㆋ"),163,l1l11l_l1_ (u"ࠧࠨㆌ"),l1l11l_l1_ (u"ࠨࠩㆍ"),l1l11l_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧㆎ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㆏"),l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์ࠪ㆐"),l1l11l_l1_ (u"ࠬ࠭㆑"),164,l1l11l_l1_ (u"࠭ࠧ㆒"),l1l11l_l1_ (u"ࠧࠨ㆓"),l1l11l_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㆔"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㆕"),l1l11l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭㆖"),l1l11l_l1_ (u"ࠫࠬ㆗"),165,l1l11l_l1_ (u"ࠬ࠭㆘"),l1l11l_l1_ (u"࠭ࠧ㆙"),l1l11l_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩ㆚"))
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㆛"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㆜"),l1l11l_l1_ (u"ࠪࠫ㆝"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㆞"),l1l11l_l1_ (u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ㆟"),l1l11l_l1_ (u"࠭ࠧㆠ"),163,l1l11l_l1_ (u"ࠧࠨㆡ"),l1l11l_l1_ (u"ࠨࠩㆢ"),l1l11l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬㆣ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㆤ"),l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬㆥ"),l1l11l_l1_ (u"ࠬ࠭ㆦ"),163,l1l11l_l1_ (u"࠭ࠧㆧ"),l1l11l_l1_ (u"ࠧࠨㆨ"),l1l11l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪㆩ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆪ"),l1l11l_l1_ (u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫㆫ"),l1l11l_l1_ (u"ࠫࠬㆬ"),162,l1l11l_l1_ (u"ࠬ࠭ㆭ"),l1l11l_l1_ (u"࠭ࠧㆮ"),l1l11l_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩㆯ"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㆰ"),l1l11l_l1_ (u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪㆱ"),l1l11l_l1_ (u"ࠪࠫㆲ"),162,l1l11l_l1_ (u"ࠫࠬㆳ"),l1l11l_l1_ (u"ࠬ࠭ㆴ"),l1l11l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧㆵ"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆶ"),l1l11l_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡสะฯࠥ฿ิ้ษษ๎ࠬㆷ"),l1l11l_l1_ (u"ࠩࠪㆸ"),164,l1l11l_l1_ (u"ࠪࠫㆹ"),l1l11l_l1_ (u"ࠫࠬㆺ"),l1l11l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩㆻ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㆼ"),l1l11l_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨㆽ"),l1l11l_l1_ (u"ࠨࠩㆾ"),165,l1l11l_l1_ (u"ࠩࠪㆿ"),l1l11l_l1_ (u"ࠪࠫ㇀"),l1l11l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㇁"))
	return
def l1l1ll11lll_l1_(options):
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㇂"),l1l11l_l1_ (u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩ㇃"),l1l11l_l1_ (u"ࠧࠨ㇄"),161,l1l11l_l1_ (u"ࠨࠩ㇅"),l1l11l_l1_ (u"ࠩࠪ㇆"),l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ㇇"))
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㇈"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㇉"),l1l11l_l1_ (u"࠭ࠧ㇊"),9999)
	l1l1l11l1l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㇋"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ࡞࡛ࡔࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㇌")+l1l11l_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ㇍"),l1l11l_l1_ (u"ࠪࠫ㇎"),147)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㇏"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㇐")+l1l11l_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ㇑"),l1l11l_l1_ (u"ࠧࠨ㇒"),148)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㇓"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡏࡆࡍࠢࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㇔")+l1l11l_l1_ (u"ࠪๆ๋อษࠡฤํࠤๆ๐ไๆ่๊๋่ࠢࠥใ฻๊้ࠬ㇕"),l1l11l_l1_ (u"ࠫࠬ㇖"),28)
	#addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ㇗"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡐࡖࡋࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㇘")+l1l11l_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ㇙"),l1l11l_l1_ (u"ࠨࠩ㇚"),41)
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㇛"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡋࡘࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㇜")+l1l11l_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ㇝"),l1l11l_l1_ (u"ࠬ࠭㇞"),135)
	import l1ll1l1l111_l1_
	l1ll1l1l111_l1_.ITEMS(l1l11l_l1_ (u"࠭࠰ࠨ㇟"),False)
	l1ll1l1l111_l1_.ITEMS(l1l11l_l1_ (u"ࠧ࠲ࠩ㇠"),False)
	l1ll1l1l111_l1_.ITEMS(l1l11l_l1_ (u"ࠨ࠴ࠪ㇡"),False)
	#l1ll1l1l111_l1_.ITEMS(l1l11l_l1_ (u"ࠩ࠶ࠫ㇢"),False)
	if l1l11l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ㇣") in options:
		menuItemsLIST[:] = l1l1l1111ll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1l1ll11l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l1ll11l_l1_)
	menuItemsLIST[:] = l1l1l11l1l1_l1_+menuItemsLIST
	return
def l1l1ll11l1l_l1_(options):
	options = options.replace(l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㇤"),l1l11l_l1_ (u"ࠬ࠭㇥")).replace(l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㇦"),l1l11l_l1_ (u"ࠧࠨ㇧"))
	headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㇨") : l1l11l_l1_ (u"ࠩࠪ㇩") }
	url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩ㇪")
	payload = { l1l11l_l1_ (u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭㇫") : l1l11l_l1_ (u"ࠬ࠻࠰ࠨ㇬") }
	data = l111111l_l1_(payload)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㇭"),l1l11l_l1_ (u"ࠧࠨ㇮"),l1l11l_l1_ (u"ࠨࠩ㇯"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1l11ll11ll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ㇰ"),url,data,headers,l1l11l_l1_ (u"ࠪࠫㇱ"),l1l11l_l1_ (u"ࠫࠬㇲ"),l1l11l_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺࠧㇳ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨㇴ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬㇵ"),block,re.DOTALL)
	l1l11l1l111_l1_,l1l11ll1l11_l1_ = list(zip(*items))
	l1l11lll1ll_l1_ = []
	l1l1ll11l11_l1_ = [l1l11l_l1_ (u"ࠨࠢࠪㇶ"),l1l11l_l1_ (u"ࠩࠥࠫㇷ"),l1l11l_l1_ (u"ࠪࡤࠬㇸ"),l1l11l_l1_ (u"ࠫ࠱࠭ㇹ"),l1l11l_l1_ (u"ࠬ࠴ࠧㇺ"),l1l11l_l1_ (u"࠭࠺ࠨㇻ"),l1l11l_l1_ (u"ࠧ࠼ࠩㇼ"),l1l11l_l1_ (u"ࠣࠩࠥㇽ"),l1l11l_l1_ (u"ࠩ࠰ࠫㇾ")]
	l1l1l1l1ll1_l1_ = l1l11ll1l11_l1_+l1l11l1l111_l1_
	for word in l1l1l1l1ll1_l1_:
		if word in l1l11ll1l11_l1_: l1l1l1l1111_l1_ = 2
		if word in l1l11l1l111_l1_: l1l1l1l1111_l1_ = 4
		l1l1ll1111l_l1_ = [i in word for i in l1l1ll11l11_l1_]
		if any(l1l1ll1111l_l1_):
			index = l1l1ll1111l_l1_.index(True)
			splitter = l1l1ll11l11_l1_[index]
			l1l1l1ll1ll_l1_ = l1l11l_l1_ (u"ࠪࠫㇿ")
			if word.count(splitter)>1: l1l1l1lll1l_l1_,l1l1l1ll1l1_l1_,l1l1l1ll1ll_l1_ = word.split(splitter,2)
			else: l1l1l1lll1l_l1_,l1l1l1ll1l1_l1_ = word.split(splitter,1)
			if len(l1l1l1lll1l_l1_)>l1l1l1l1111_l1_: l1l11lll1ll_l1_.append(l1l1l1lll1l_l1_.lower())
			if len(l1l1l1ll1l1_l1_)>l1l1l1l1111_l1_: l1l11lll1ll_l1_.append(l1l1l1ll1l1_l1_.lower())
			if len(l1l1l1ll1ll_l1_)>l1l1l1l1111_l1_: l1l11lll1ll_l1_.append(l1l1l1ll1ll_l1_.lower())
		elif len(word)>l1l1l1l1111_l1_: l1l11lll1ll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l11lll1ll_l1_)
	#selection = DIALOG_SELECT(str(len(l1l11lll1ll_l1_)),l1l11lll1ll_l1_)
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊ࡮࡬ࡷࡹࠦ࠽ࠡ࡝ࠪ็้๋วหࠢ฼ุํอฦ๋หࠣ฽ึฮ๊สࠩ࠯่๊ࠫๅศฬࠣ฽ู๎วว์ฬࠤส์ใๅ์ี๎ฮ࠭࡝ࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠵࠭ࠏࠏ࡬ࡪࡵࡷ࠵ࠥࡃࠠ࡜࡟ࠍࠍࡨࡵࡵ࡯ࡶࡶࠤࡂࠦ࡬ࡦࡰࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡩ࡯ࡶࡰࡷࡷ࠯࠻ࠩ࠻ࠢࡵࡥࡳࡪ࡯࡮࠰ࡶ࡬ࡺ࡬ࡦ࡭ࡧࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࡩࡷ࡬࠮ࡀࠠ࡭࡫ࡶࡸ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧไๆ่อࠥ฿ิ้ษษ๎ฮࠦัใ็ࠣࠫ࠰ࡹࡴࡳࠪ࡬࠭࠮ࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠏࠏࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไๅ฼ฬ࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࠧࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡂࡃ࠰࠻ࠢ࡯࡭ࡸࡺ࠲ࠡ࠿ࠣࡥࡷࡨࡌࡊࡕࡗࠎࠎࠏࠣࡦ࡮ࡶࡩ࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡦࡰࡪࡐࡎ࡙ࡔࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠴࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠡ࠾ࠢ࠰࠵࠿ࠦࡢࡳࡧࡤ࡯ࠏࠏࠉࡦ࡮࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࡶࡩࡦࡸࡣࡩࠢࡀࠤࡱ࡯ࡳࡵ࠴࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠤࠥࠦ㈀")
	if l1l11l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭㈁") in options:
		l1l1l11l111_l1_ = l1l1l1lll11_l1_
	elif l1l11l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭㈂") in options:
		l1l1l11l111_l1_ = [l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㈃")]
		import IPTV
		if not IPTV.isIPTVFiles(True): return
	count,l1l11l1l11l_l1_ = 0,0
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈄"),l1l11l_l1_ (u"ࠩส่อำหࠡ฻้ࠤ࠿࡛ࠦࠡࠢࡠࠫ㈅"),l1l11l_l1_ (u"ࠪࠫ㈆"),164,l1l11l_l1_ (u"ࠫࠬ㈇"),l1l11l_l1_ (u"ࠬ࠭㈈"),l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㈉")+options)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈊"),l1l11l_l1_ (u"ࠨว฼หิฯࠠศๆหัะࠦวๅ฻ื์ฬฬ๊ࠨ㈋"),l1l11l_l1_ (u"ࠩࠪ㈌"),164,l1l11l_l1_ (u"ࠪࠫ㈍"),l1l11l_l1_ (u"ࠫࠬ㈎"),l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㈏")+options)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㈐"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㈑"),l1l11l_l1_ (u"ࠨࠩ㈒"),9999)
	l1l11l11lll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1ll111ll_l1_ = []
	for word in l1l11lll1ll_l1_:
		l1l1l1ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡞ࠤࡡ࠲࡜࠼࡞࠽ࡠ࠲ࡢࠫ࡝࠿࡟ࠦࡡ࠭࡜࡜࡞ࡠࡠ࠭ࡢࠩ࡝ࡽ࡟ࢁࡡࠧ࡜ࡁ࡞ࠦࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧ㈓"),word,re.DOTALL)
		if l1l1l1ll1l1_l1_: word = word.split(l1l1l1ll1l1_l1_[0],1)[0]
		l1l1l1l1l1l_l1_ = word.replace(l1l11l_l1_ (u"ࠪ๕ࠬ㈔"),l1l11l_l1_ (u"ࠫࠬ㈕")).replace(l1l11l_l1_ (u"ࠬ๔ࠧ㈖"),l1l11l_l1_ (u"࠭ࠧ㈗")).replace(l1l11l_l1_ (u"ࠧ์ࠩ㈘"),l1l11l_l1_ (u"ࠨࠩ㈙")).replace(l1l11l_l1_ (u"ࠩ๒ࠫ㈚"),l1l11l_l1_ (u"ࠪࠫ㈛")).replace(l1l11l_l1_ (u"ࠫ๑࠭㈜"),l1l11l_l1_ (u"ࠬ࠭㈝"))
		l1l1l1l1l1l_l1_ = l1l1l1l1l1l_l1_.replace(l1l11l_l1_ (u"࠭๐ࠨ㈞"),l1l11l_l1_ (u"ࠧࠨ㈟")).replace(l1l11l_l1_ (u"ࠨ๏ࠪ㈠"),l1l11l_l1_ (u"ࠩࠪ㈡")).replace(l1l11l_l1_ (u"ࠪ๖ࠬ㈢"),l1l11l_l1_ (u"ࠫࠬ㈣")).replace(l1l11l_l1_ (u"ࠬฒࠧ㈤"),l1l11l_l1_ (u"࠭ࠧ㈥")).replace(l1l11l_l1_ (u"ࠧแࠩ㈦"),l1l11l_l1_ (u"ࠨࠩ㈧"))
		l1l1ll111ll_l1_.append(l1l1l1l1l1l_l1_)
	for i in range(0,20):
		text = random.sample(l1l1ll111ll_l1_,1)[0]
		site = random.sample(l1l1l11l111_l1_,1)[0]
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㈨"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡖࡪࡦࡨࡳ࡙ࠥࡥࡢࡴࡦ࡬ࠥࠦࠠࡴ࡫ࡷࡩ࠿࠭㈩")+str(site)+l1l11l_l1_ (u"ࠫࠥࠦࡴࡦࡺࡷ࠾ࠬ㈪")+text)
		#results = l1l11llllll_l1_(l1l11l_l1_ (u"ࠬ࠭㈫"),l1l11l_l1_ (u"࠭ࠧ㈬"),l1l11l_l1_ (u"ࠧࠨ㈭"),site,l1l11l_l1_ (u"ࠨࠩ㈮"),l1l11l_l1_ (u"ࠩࠪ㈯"),text+l1l11l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ㈰"),l1l11l_l1_ (u"ࠫࠬ㈱"),l1l11l_l1_ (u"ࠬ࠭㈲"))
		l1lll1lll1l_l1_,l1llll111ll_l1_,l1llllll11l_l1_ = l1lll1ll11l_l1_(site)
		l1llll111ll_l1_(text+l1l11l_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ㈳"))
		if len(menuItemsLIST)>0: break
	text = text.replace(l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㈴"),l1l11l_l1_ (u"ࠨࠩ㈵"))
	l1l11l11lll_l1_[0][1] = l1l11l_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㈶")+text+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไษฯฮࠤ฾์ࠠ࠻ࠢ࡞ࠤࠬ㈷")
	menuItemsLIST[:] = l1l1l1111ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1l1ll11l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l1ll11l_l1_)
	menuItemsLIST[:] = l1l11l11lll_l1_+menuItemsLIST
	#import l111l111l1_l1_
	#l111l111l1_l1_.SEARCH(search)
	return
def l1l1ll111l1_l1_(site):
	l1lll1lll1l_l1_,l1llll111ll_l1_,l1llllll11l_l1_ = l1lll1ll11l_l1_(site)
	try:
		if l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㈸") in site: l1lll1lll1l_l1_(site)
		else: l1lll1lll1l_l1_()
		l1l1l1l11l1_l1_ = False
	except: l1l1l1l11l1_l1_ = True
	if l1l1l1l11l1_l1_: DIALOG_NOTIFICATION(site,l1l11l_l1_ (u"ࠬ็ิๅࠢห๋ีอࠠศๆ่์็฿ࠧ㈹"),time=2000)
	else: DIALOG_NOTIFICATION(site,l1l11l_l1_ (u"࠭สๆࠢฯ่อࠦวๅลๅืฬ๋ࠧ㈺"),time=2000)
	return l1l1l1l11l1_l1_
def l1l11l1ll1l_l1_(l1l1l11llll_l1_=True):
	if not l1l1l11llll_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㈻"),l1l11l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㈼"),l1l11l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㈽"))
		if results:
			contentsDICT = results
			return
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㈾"),l1l11l_l1_ (u"ࠫࠬ㈿"),l1l11l_l1_ (u"ࠬ࠭㉀"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㉁"),l1l11l_l1_ (u"ࠧๅๅํࠤฯ๋ไว๊ࠢิ์ࠦวๅไสส๊ฯࠠ࠯ࠢส่อืๆศ็ฯࠤ๏ำสศฮࠣว๋๊ࠦโฯุࠤัฺ๋๊่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠโ์ࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํืฯิัอ่๊ࠢ์อࠠโไฺࠤฬ๊รใีส้ࠥอไาศํื๏ฯࠠ࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴ฺࠠ็็๎ฮࠦๅๅศࠣะ๊๐ูࠡษ็ว็ูวๆࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࠯๊่ࠢࠥะั๋ัࠣว๋ࠦสอ็฼ࠤ็อฦๆหࠣห้ษโิษ่ࠤฬ๊ย็ࠢยࠫ㉂"))
	if yes!=1: return
	l1l11ll1111_l1_ = menuItemsLIST[:]
	l1l1l111ll1_l1_,l1l1l111l11_l1_ = 0,l1l11l_l1_ (u"ࠨࠩ㉃")
	for site in l1l1ll11111_l1_:
		l1l1l1l11l1_l1_ = l1l1ll111l1_l1_(site)
		if l1l1l1l11l1_l1_:
			l1l1l111ll1_l1_ += 1
			l1l1l111l11_l1_ += l1l11l_l1_ (u"ࠩࠣࠫ㉄")+site
			if l1l1l111ll1_l1_>=l1l1l11lll1_l1_: break
	menuItemsLIST[:] = l1l11ll1111_l1_
	if l1l1l111ll1_l1_>=l1l1l11lll1_l1_: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㉅"),l1l11l_l1_ (u"ࠫࠬ㉆"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㉇"),l1l11l_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧ㉈")+str(l1l1l111ll1_l1_)+l1l11l_l1_ (u"ࠧࠡ็๋ห็฿ࠠๆ่้ࠣํอโฺࠢส่อืๆศ็ฯࠤ࠳࠴࠮๊ࠡึฬอํวࠡไาࠤ๏้่็ࠢ฼ำ๊่ࠦอ๊าࠤส์สา่ํฮࠥ็๊ࠡฮ๊หื้้้ࠠํ࠾ࠬ㉉")+l1l1l111l11_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㉊"),l1l11l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㉋"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㉌"),l1l11l_l1_ (u"ࠫࠬ㉍"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㉎"),l1l11l_l1_ (u"࠭สๆࠢฯ่อࠦฬๆ์฼ࠤฬ๊รใีส้ࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้ฮั็ษ่ะࠬ㉏"))
	return
def l1l11llll1l_l1_(options):
	if l1l11l_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ㉐") not in options:
		results = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㉑"),l1l11l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㉒"),l1l11l_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ㉓"))
		if results: menuItemsLIST[:] = results ; return
	message = l1l11l_l1_ (u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ㉔")
	import IPTV
	if IPTV.isIPTVFiles(True):
		if l1l11l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㉕") in options and l1l11l_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭㉖") not in options:
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭㉗"),l1l11l_l1_ (u"ࠨࠩ㉘"),l1l11l_l1_ (u"ࠩࠪ㉙"),options+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㉚"))
			except: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㉛"),l1l11l_l1_ (u"ࠬ࠭㉜"),l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ㉝"),message)
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㉞"),l1l11l_l1_ (u"ࠨࠩ㉟"),l1l11l_l1_ (u"ࠩࠪ㉠"),options+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㉡"))
			except: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㉢"),l1l11l_l1_ (u"ࠬ࠭㉣"),l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ㉤"),message)
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㉥"),l1l11l_l1_ (u"ࠨࠩ㉦"),l1l11l_l1_ (u"ࠩࠪ㉧"),options+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㉨"))
			except: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㉩"),l1l11l_l1_ (u"ࠬ࠭㉪"),l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ㉫"),message)
		if l1l11l_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ㉬") in options and l1l11l_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ㉭") not in options:
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㉮"),l1l11l_l1_ (u"ࠪࠫ㉯"),l1l11l_l1_ (u"ࠫࠬ㉰"),options+l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㉱"))
			except: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㉲"),l1l11l_l1_ (u"ࠧࠨ㉳"),l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭㉴"),message)
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㉵"),l1l11l_l1_ (u"ࠪࠫ㉶"),l1l11l_l1_ (u"ࠫࠬ㉷"),options+l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㉸"))
			except: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㉹"),l1l11l_l1_ (u"ࠧࠨ㉺"),l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭㉻"),message)
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㉼"),l1l11l_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ㉽"),menuItemsLIST,PERMANENT_CACHE)
	return
def l1l1l1ll111_l1_(options,l1l1l11l11l_l1_):
	if l1l11l_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ㉾") in options:
		if l1l11l_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ㉿") in options and l1l1l11l11l_l1_==l1l11l_l1_ (u"࠭ࠧ㊀"): l1l11l1ll1l_l1_(True)
		elif l1l1l11l11l_l1_: l1l11l1ll1l_l1_(False)
		#if contentsDICT=={}: return
	l1l1l11ll11_l1_ = options.replace(l1l11l_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ㊁"),l1l11l_l1_ (u"ࠨࠩ㊂")).replace(l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㊃"),l1l11l_l1_ (u"ࠪࠫ㊄")).replace(l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㊅"),l1l11l_l1_ (u"ࠬ࠭㊆"))
	if not l1l1l11l11l_l1_:
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㊇"),l1l11l_l1_ (u"ࠧหฯา๎ะࠦ็ั้ࠣห้่วว็ฬࠫ㊈"),l1l11l_l1_ (u"ࠨࠩ㊉"),165,l1l11l_l1_ (u"ࠩࠪ㊊"),l1l11l_l1_ (u"ࠪࠫ㊋"),l1l11l_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ㊌")+l1l1l11ll11_l1_)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㊍"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㊎"),l1l11l_l1_ (u"ࠧࠨ㊏"),9999)
	if l1l11l_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ㊐") in options:
		l1llll1111_l1_ = [l1l11l_l1_ (u"ࠩฦๅ้อๅࠨ㊑"),l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠫ㊒"),l1l11l_l1_ (u"ู๊ࠫัฮ์สฮࠬ㊓"),l1l11l_l1_ (u"ࠬฮัศ็ฯࠫ㊔"),l1l11l_l1_ (u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬ㊕"),l1l11l_l1_ (u"ࠧา็ูห๋࠭㊖"),l1l11l_l1_ (u"ࠨละำะ࠳รฯำࠪ㊗"),l1l11l_l1_ (u"ࠩึ่ฬูไࠨ㊘"),l1l11l_l1_ (u"้ࠪํู๊ใ๋ࠪ㊙"),l1l11l_l1_ (u"ࠫศฺ็า࠯ฦ็ะืࠧ㊚"),l1l11l_l1_ (u"ࠬอไร่ࠪ㊛"),l1l11l_l1_ (u"࠭ึฮๅࠪ㊜"),l1l11l_l1_ (u"ࠧา์สฺฮ࠭㊝"),l1l11l_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ㊞"),l1l11l_l1_ (u"่้ࠩะ๊๊็ࠩ㊟"),l1l11l_l1_ (u"ࠪฬะࠦอ๋ࠩ㊠"),l1l11l_l1_ (u"ࠫิ๐ๆ๋หࠪ㊡"),l1l11l_l1_ (u"ูࠬๆ้ษอࠫ㊢"),l1l11l_l1_ (u"࠭รฯำ์ࠫ㊣")]
		l1l11ll111l_l1_ = [l1l11l_l1_ (u"ࠧศใ็ห๊࠭㊤"),l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㊥"),l1l11l_l1_ (u"ࠩไ๎้๋ࠧ㊦"),l1l11l_l1_ (u"ࠪๅ้๋ࠧ㊧")]
		l1l11lll11l_l1_ = [l1l11l_l1_ (u"ู๊ࠫไิๆࠪ㊨"),l1l11l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ㊩")]
		l1l1ll11ll1_l1_ = [l1l11l_l1_ (u"࠭ๅิษิัࠬ㊪"),l1l11l_l1_ (u"ࠧๆีิั๏อสࠨ㊫")]
		l1l11lll111_l1_ = [l1l11l_l1_ (u"ࠨสิห๊าࠧ㊬"),l1l11l_l1_ (u"ࠩࡶ࡬ࡴࡽࠧ㊭"),l1l11l_l1_ (u"ࠪฮ้็า๋๊้ࠫ㊮"),l1l11l_l1_ (u"ࠫฯ๊๊โิํ์๋࠭㊯")]
		l1l1l1l1l11_l1_ = [l1l11l_l1_ (u"ࠬอๆๆ์ࠪ㊰"),l1l11l_l1_ (u"࠭ใาฬ๋๊ࠬ㊱"),l1l11l_l1_ (u"ࠧไษิฮํ์ࠧ㊲"),l1l11l_l1_ (u"ࠨ࡭࡬ࡨࡸ࠭㊳"),l1l11l_l1_ (u"ฺࠩๅ้࠭㊴"),l1l11l_l1_ (u"ࠪห฼็วๅࠩ㊵")]
		l11llll1_l1_ = [l1l11l_l1_ (u"ࠫึ๋ึศ่ࠪ㊶")]
		l11l11ll_l1_ = [l1l11l_l1_ (u"ࠬออะอࠪ㊷"),l1l11l_l1_ (u"࠭วฯำࠪ㊸"),l1l11l_l1_ (u"ࠧๆ๊ัีࠬ㊹"),l1l11l_l1_ (u"ࠨฮา๎ิ࠭㊺"),l1l11l_l1_ (u"ฺ่ࠩฬ็ࠧ㊻"),l1l11l_l1_ (u"ࠪัิ๐หࠨ㊼")]
		l1l11lllll1_l1_ = [l1l11l_l1_ (u"ุ๊ࠫวิๆࠪ㊽"),l1l11l_l1_ (u"ูࠬไิๆ๊ࠫ㊾")]
		l1l11l1l1l1_l1_ = [l1l11l_l1_ (u"࠭ว฻ษ้๎ࠬ㊿"),l1l11l_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ㋀"),l1l11l_l1_ (u"ࠨๅ็๎อ࠭㋁"),l1l11l_l1_ (u"ࠩะๅ้࠭㋂"),l1l11l_l1_ (u"ࠪࡱࡺࡹࡩࡤࠩ㋃")]
		l11l111ll_l1_ = [l1l11l_l1_ (u"ࠫฬ้หาࠩ㋄"),l1l11l_l1_ (u"ࠬอิ่ำࠪ㋅"),l1l11l_l1_ (u"࠭ๅๆ์ี๋ࠬ㋆"),l1l11l_l1_ (u"ࠧศ฻็ํࠬ㋇"),l1l11l_l1_ (u"ࠨ็ัฮฬื็ࠨ㋈"),l1l11l_l1_ (u"่ࠩาฯอัศฬࠪ㋉"),l1l11l_l1_ (u"ࠪห็๎้ࠨ㋊")]
		l1l11ll1lll_l1_ = [l1l11l_l1_ (u"ࠫฬ๊ว็ࠩ㋋"),l1l11l_l1_ (u"ࠬำวๅ์ࠪ㋌"),l1l11l_l1_ (u"࠭ๅฬสอࠫ㋍"),l1l11l_l1_ (u"ࠧาษษะࠬ㋎")]
		l1l11l1ll11_l1_ = [l1l11l_l1_ (u"ࠨุะ็ࠬ㋏"),l1l11l_l1_ (u"ࠩๆ์๊๐ฯ๋ࠩ㋐")]
		l1l11ll11l1_l1_ = [l1l11l_l1_ (u"ࠪี๏อึ่ࠩ㋑"),l1l11l_l1_ (u"่ࠫ๎ั่ࠩ㋒"),l1l11l_l1_ (u"๋ࠬีศำ฼๋ࠬ㋓"),l1l11l_l1_ (u"࠭ิ้ฬࠪ㋔"),l1l11l_l1_ (u"ࠧา์สฺฮ࠭㋕")]
		l1l1l1l111l_l1_ = [l1l11l_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ㋖"),l1l11l_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ㋗"),l1l11l_l1_ (u"๊ࠪ๏ะแๅ์ๆืࠬ㋘")]
		l1l11l1lll1_l1_ = [l1l11l_l1_ (u"๊๋ࠫหๅ์้ࠫ㋙"),l1l11l_l1_ (u"ࠬอิฯษุࠫ㋚"),l1l11l_l1_ (u"࠭ๆอ๊่ࠫ㋛")]
		l1lll1ll1_l1_ = [l1l11l_l1_ (u"ࠧษอࠣั๏࠭㋜"),l1l11l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㋝"),l1l11l_l1_ (u"ࠩๅ๊ฬํࠧ㋞"),l1l11l_l1_ (u"ࠪๆ๋๎วหࠩ㋟")]
		l1l1l11ll1l_l1_ = [l1l11l_l1_ (u"ࠫิ๐ๆࠨ㋠"),l1l11l_l1_ (u"ࠬอฯฺ์๊ࠫ㋡"),l1l11l_l1_ (u"࠭า๋ษิหฯ࠭㋢"),l1l11l_l1_ (u"ࠧๅู่๎ฬะࠧ㋣"),l1l11l_l1_ (u"ࠨั฼หฦ࠭㋤"),l1l11l_l1_ (u"ࠩๅีฬ์ࠧ㋥"),l1l11l_l1_ (u"ࠪๆฺอฦะࠩ㋦"),l1l11l_l1_ (u"ࠫึัวยࠩ㋧"),l1l11l_l1_ (u"๋ࠬัอ฻ํ๋ࠬ㋨"),l1l11l_l1_ (u"࠭วัษ้ࠫ㋩"),l1l11l_l1_ (u"ࠧศี็ห๊࠭㋪"),l1l11l_l1_ (u"ࠨฬ๋หู๐อࠨ㋫"),l1l11l_l1_ (u"ࠩั฻อ࠭㋬"),l1l11l_l1_ (u"ࠪัํุ่๋ࠩ㋭"),l1l11l_l1_ (u"ࠫ฾ะศศฬࠪ㋮"),l1l11l_l1_ (u"๋่ࠬศๆํำࠬ㋯"),l1l11l_l1_ (u"࠭ๆ้ษ฼๎ࠬ㋰"),l1l11l_l1_ (u"ฺࠧไสสิ࠭㋱"),l1l11l_l1_ (u"ࠨษ้หู๐ฯࠨ㋲")]
		l1l1l1l1lll_l1_ = [l1l11l_l1_ (u"ࠩ࠴࠽ࠬ㋳"),l1l11l_l1_ (u"ࠪ࠶࠵࠭㋴"),l1l11l_l1_ (u"ࠫ࠷࠷ࠧ㋵"),l1l11l_l1_ (u"ࠬ࠸࠲ࠨ㋶"),l1l11l_l1_ (u"࠭࠲࠴ࠩ㋷"),l1l11l_l1_ (u"ࠧ࠳࠶ࠪ㋸")]
		if not l1l1l11l11l_l1_:
			l1l1l11l11l_l1_ = 0
			for l1l1l111lll_l1_ in l1llll1111_l1_:
				l1l1l11l11l_l1_ += 1
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㋹"),menu_name+l1l1l111lll_l1_,l1l11l_l1_ (u"ࠩࠪ㋺"),165,l1l11l_l1_ (u"ࠪࠫ㋻"),str(l1l1l11l11l_l1_),l1l1l11ll11_l1_)
		else:
			for name in sorted(list(contentsDICT.keys())):
				name2 = name.lower()
				category = []
				if any(value in name2 for value in l1l11ll111l_l1_): category.append(1)
				if any(value in name2 for value in l1l11lll11l_l1_): category.append(2)
				if any(value in name2 for value in l1l1ll11ll1_l1_): category.append(3)
				if any(value in name2 for value in l1l11lll111_l1_): category.append(4)
				if any(value in name2 for value in l1l1l1l1l11_l1_): category.append(5)
				if any(value in name2 for value in l11llll1_l1_): category.append(6)
				if any(value in name2 for value in l11l11ll_l1_) and name2 not in [l1l11l_l1_ (u"ࠫฬิั๊ࠩ㋼")]: category.append(7)
				if any(value in name2 for value in l1l11lllll1_l1_): category.append(8)
				if any(value in name2 for value in l1l11l1l1l1_l1_): category.append(9)
				if any(value in name2 for value in l11l111ll_l1_): category.append(10)
				if any(value in name2 for value in l1l11ll1lll_l1_): category.append(11)
				if any(value in name2 for value in l1l11l1ll11_l1_): category.append(12)
				if any(value in name2 for value in l1l11ll11l1_l1_): category.append(13)
				if any(value in name2 for value in l1l1l1l111l_l1_): category.append(14)
				if any(value in name2 for value in l1l11l1lll1_l1_): category.append(15)
				if any(value in name2 for value in l1lll1ll1_l1_): category.append(16)
				if any(value in name2 for value in l1l1l11ll1l_l1_): category.append(17)
				if any(value in name2 for value in l1l1l1l1lll_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l1l1l11l11l_l1_:
						addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋽"),menu_name+name,name,166,l1l11l_l1_ (u"࠭ࠧ㋾"),l1l11l_l1_ (u"ࠧࠨ㋿"),l1l1l11ll11_l1_+l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㌀"))
	elif l1l11l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ㌁") in options:
		if l1l11l_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ㌂") in options:
			import IPTV
			if not IPTV.isIPTVFiles(False): IPTV.CREATE_STREAMS()
		l1l11llll1l_l1_(options)
	return
def l1l1l1llll1_l1_(nameonly,options):
	nameonly = nameonly(l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㌃"),l1l11l_l1_ (u"ࠬ࠭㌄"))
	options = options.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㌅"),l1l11l_l1_ (u"ࠧࠨ㌆")).replace(l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㌇"),l1l11l_l1_ (u"ࠩࠪ㌈"))
	l1l11l1ll1l_l1_(False)
	if contentsDICT=={}: return
	if l1l11l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ㌉") in options:
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌊"),l1l11l_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㌋")+nameonly+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ㌌"),nameonly,166,l1l11l_l1_ (u"ࠧࠨ㌍"),l1l11l_l1_ (u"ࠨࠩ㌎"),l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㌏")+options)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㌐"),l1l11l_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ㌑"),nameonly,166,l1l11l_l1_ (u"ࠬ࠭㌒"),l1l11l_l1_ (u"࠭ࠧ㌓"),l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㌔")+options)
		addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㌕"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㌖"),l1l11l_l1_ (u"ࠪࠫ㌗"),9999)
	for website in sorted(list(contentsDICT[nameonly].keys())):
		type,name,url,l1l1l1l11ll_l1_,image,page,text,favorite,infodict = contentsDICT[nameonly][website]
		if l1l11l_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭㌘") in options or len(contentsDICT[nameonly])==1:
			l1l11llllll_l1_(type,l1l11l_l1_ (u"ࠬ࠭㌙"),url,l1l1l1l11ll_l1_,l1l11l_l1_ (u"࠭ࠧ㌚"),page,text,l1l11l_l1_ (u"ࠧࠨ㌛"),l1l11l_l1_ (u"ࠨࠩ㌜"))
			menuItemsLIST[:] = l1l1l1111ll_l1_(menuItemsLIST)
			l1l11l1l1ll_l1_,newLIST = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(newLIST)
			if l1l11l_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ㌝") in options: menuItemsLIST[:] = l1l11l1l1ll_l1_+newLIST[:l1l1l1ll11l_l1_]
			else: menuItemsLIST[:] = l1l11l1l1ll_l1_+newLIST
		elif l1l11l_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ㌞") in options: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌟"),website,url,l1l1l1l11ll_l1_,image,page,text,favorite,infodict)
	return
def l1l1l111111_l1_(options,mode):
	options = options.replace(l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ㌠"),l1l11l_l1_ (u"࠭ࠧ㌡")).replace(l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㌢"),l1l11l_l1_ (u"ࠨࠩ㌣"))
	name,l1l11llll11_l1_ = l1l11l_l1_ (u"ࠩࠪ㌤"),[]
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㌥"),l1l11l_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㌦")+name+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ㌧"),l1l11l_l1_ (u"࠭ࠧ㌨"),mode,l1l11l_l1_ (u"ࠧࠨ㌩"),l1l11l_l1_ (u"ࠨࠩ㌪"),l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㌫")+options)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㌬"),l1l11l_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫ㌭"),l1l11l_l1_ (u"ࠬ࠭㌮"),mode,l1l11l_l1_ (u"࠭ࠧ㌯"),l1l11l_l1_ (u"ࠧࠨ㌰"),l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㌱")+options)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㌲"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㌳"),l1l11l_l1_ (u"ࠫࠬ㌴"),9999)
	l1l11l1l1ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l1l11l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭㌵") in options:
		l1l11l1ll1l_l1_(False)
		if contentsDICT=={}: return
		l1l1l1111l1_l1_ = list(contentsDICT.keys())
		nameonly = random.sample(l1l1l1111l1_l1_,1)[0]
		l1l11lll1ll_l1_ = list(contentsDICT[nameonly].keys())
		website = random.sample(l1l11lll1ll_l1_,1)[0]
		type,name,url,l1l1l1l11ll_l1_,image,page,text,favorite,infodict = contentsDICT[nameonly][website]
		LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌶"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪ㌷")+website+l1l11l_l1_ (u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ㌸")+name+l1l11l_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ㌹")+url+l1l11l_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭㌺")+str(l1l1l1l11ll_l1_))
	elif l1l11l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ㌻") in options:
		l1l11llll1l_l1_(options)
		if not menuItemsLIST: return
		type,name,url,l1l1l1l11ll_l1_,image,page,text,favorite,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㌼"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭㌽")+name+l1l11l_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ㌾")+url+l1l11l_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ㌿")+str(l1l1l1l11ll_l1_))
	l1l11lll1l1_l1_ = name
	l1l1l111l1l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㍀"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ㍁")+name+l1l11l_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭㍂")+url+l1l11l_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ㍃")+str(l1l1l1l11ll_l1_))
		menuItemsLIST[:] = []
		if l1l1l1l11ll_l1_==234 and l1l11l_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ㍄") in text: l1l1l1l11ll_l1_ = 233
		if l1l1l1l11ll_l1_==144: l1l1l1l11ll_l1_ = 291
		html = l1l11llllll_l1_(type,name,url,l1l1l1l11ll_l1_,image,page,text,favorite,infodict)
		#if l1l11l_l1_ (u"ࠧࡠࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࡣࠬ㍅") in html: l1l1l111111_l1_(options,mode)
		if l1l11l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ㍆") in options and l1l1l1l11ll_l1_==167: del menuItemsLIST[:3]
		l1l11llll11_l1_[:] = l1l1l1111ll_l1_(menuItemsLIST)
		if l1l1l111l1l_l1_ and l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡷࠪั้่ษࠨ㍇")) in str(l1l11llll11_l1_) or l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡸࠫา๊โ่ࠩ㍈")) in str(l1l11llll11_l1_):
			name = l1l11lll1l1_l1_
			l1l11llll11_l1_[:] = l1l1l111l1l_l1_
			break
		l1l11lll1l1_l1_ = name
		l1l1l111l1l_l1_ = l1l11llll11_l1_[:]
		if str(l1l11llll11_l1_).count(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㍉"))>0: break
		if str(l1l11llll11_l1_).count(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ㍊"))>0: break
		if l1l1l1l11ll_l1_==233: break	# l11ll1l1l1_l1_ l1l111l1_l1_ names l1l1l11l1ll_l1_ of l1l11l1_l1_ name
		if l1l1l1l11ll_l1_==291: break	# l1111ll1_l1_ l1l1l1lllll_l1_ names l1l1l11l1ll_l1_ of l1111ll1_l1_ l1l1l1lllll_l1_ contents
		if l1l11llll11_l1_: type,name,url,l1l1l1l11ll_l1_,image,page,text,favorite,infodict = random.sample(l1l11llll11_l1_,1)[0]
	if name==l1l11l_l1_ (u"࠭ࠧ㍋"): name = l1l11l_l1_ (u"ࠧ࠯࠰࠱࠲ࠬ㍌")
	elif name.count(l1l11l_l1_ (u"ࠨࡡࠪ㍍"))>1: name = name.split(l1l11l_l1_ (u"ࠩࡢࠫ㍎"),2)[2]
	name = name.replace(l1l11l_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭㍏"),l1l11l_l1_ (u"ࠫࠬ㍐"))#.replace(l1l11l_l1_ (u"ࠬ࠲ࡍࡐࡘࡌࡉࡘࡀࠠࠨ㍑"),l1l11l_l1_ (u"࠭ࠧ㍒")).replace(l1l11l_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ㍓"),l1l11l_l1_ (u"ࠨࠩ㍔")).replace(l1l11l_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ㍕"),l1l11l_l1_ (u"ࠪࠫ㍖"))
	name = name.replace(l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㍗"),l1l11l_l1_ (u"ࠬ࠭㍘"))
	l1l11l1l1ll_l1_[0][1] = l1l11l_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㍙")+name+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭㍚")
	for i in range(9): random.shuffle(l1l11llll11_l1_)
	if l1l11l_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ㍛") in options: menuItemsLIST[:] = l1l11l1l1ll_l1_+l1l11llll11_l1_[:l1l1l1ll11l_l1_]
	else: menuItemsLIST[:] = l1l11l1l1ll_l1_+l1l11llll11_l1_
	return
def l1l11ll1l1l_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㍜"),l1l11l_l1_ (u"ࠪࠫ㍝")).replace(l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㍞"),l1l11l_l1_ (u"ࠬ࠭㍟"))
	l1l1l11111l_l1_ = GROUP
	if l1l11l_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ㍠") in GROUP:
		l1l1l11111l_l1_ = GROUP.split(l1l11l_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ㍡"))[0]
		type = l1l11l_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ㍢")
	elif l1l11l_l1_ (u"࡙ࠩࡓࡉ࠭㍣") in TYPE: type = l1l11l_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭㍤")
	elif l1l11l_l1_ (u"ࠫࡑࡏࡖࡆࠩ㍥") in TYPE: type = l1l11l_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭㍦")
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㍧"),l1l11l_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㍨")+type+l1l1l11111l_l1_+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ㍩"),TYPE,167,l1l11l_l1_ (u"ࠩࠪ㍪"),l1l11l_l1_ (u"ࠪࠫ㍫"),l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㍬")+GROUP)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㍭"),l1l11l_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ㍮"),TYPE,167,l1l11l_l1_ (u"ࠧࠨ㍯"),l1l11l_l1_ (u"ࠨࠩ㍰"),l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㍱")+GROUP)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㍲"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㍳"),l1l11l_l1_ (u"ࠬ࠭㍴"),9999)
	import IPTV
	if l1l11l_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ㍵") in GROUP: IPTV.GROUPS(TYPE,GROUP,l1l11l_l1_ (u"ࠧࠨ㍶"))
	else: IPTV.ITEMS(TYPE,GROUP,l1l11l_l1_ (u"ࠨࠩ㍷"))
	menuItemsLIST[:] = l1l1l1111ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l1ll11l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l1ll11l_l1_)
	return
def l1l1l1111ll_l1_(menuItemsLIST):
	l1l11llll11_l1_ = []
	for type,name,url,mode,image,page,text,favorite,infodict in menuItemsLIST:
		if l1l11l_l1_ (u"ุࠩๅาฯࠧ㍸") in name or l1l11l_l1_ (u"ูࠪๆำ็ࠨ㍹") in name or l1l11l_l1_ (u"ࠫࡵࡧࡧࡦࠩ㍺") in name.lower(): continue
		l1l11llll11_l1_.append([type,name,url,mode,image,page,text,favorite,infodict])
	return l1l11llll11_l1_
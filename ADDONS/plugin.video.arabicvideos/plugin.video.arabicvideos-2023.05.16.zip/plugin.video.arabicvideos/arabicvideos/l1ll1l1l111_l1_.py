# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠭⤭")
l11lll_l1_ = WEBSITES[l1l11l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ⤮")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l1l11l_l1_ (u"ࠨ࠲ࠪ⤯"),True)
	elif mode==102: results = ITEMS(l1l11l_l1_ (u"ࠩ࠴ࠫ⤰"),True)
	elif mode==103: results = ITEMS(l1l11l_l1_ (u"ࠪ࠶ࠬ⤱"),True)
	elif mode==104: results = ITEMS(l1l11l_l1_ (u"ࠫ࠸࠭⤲"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l1l11l_l1_ (u"ࠬ࠺ࠧ⤳"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤴"),l1l11l_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭⤵")+l1l11l_l1_ (u"ࠨๆ็ู้ะัไ์้ࠤอิฯๆหࠣࡍࡕ࡚ࡖࠨ⤶"),l1l11l_l1_ (u"ࠩࠪ⤷"),230)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⤸"),l1l11l_l1_ (u"ࠫࡤ࡚ࡖ࠱ࡡࠪ⤹")+l1l11l_l1_ (u"่ࠬๆ้ษอࠤ๊์ࠠๆ๊สๆ฾ํวࠡษ็วฺ๊๊สࠩ⤺"),l1l11l_l1_ (u"࠭ࠧ⤻"),101)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤼"),l1l11l_l1_ (u"ࠨࡡࡗ࡚࠹ࡥࠧ⤽")+l1l11l_l1_ (u"ࠩๅ๊ํอสࠡ็ัฮฬืษࠡ็้ࠤ๏๎ส๋๊หࠫ⤾"),l1l11l_l1_ (u"ࠪࠫ⤿"),106)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⥀"),l1l11l_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ⥁")+l1l11l_l1_ (u"࠭โ็๊สฮࠥ฿ัษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ⥂"),l1l11l_l1_ (u"ࠧࠨ⥃"),147)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⥄"),l1l11l_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ⥅")+l1l11l_l1_ (u"ࠪๆ๋๎วหࠢฦะ๋ฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ⥆"),l1l11l_l1_ (u"ࠫࠬ⥇"),148)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⥈"),l1l11l_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬ⥉")+l1l11l_l1_ (u"ࠧࠡࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ็้ࠤ๊๎โฺ้่ࠤࠥ࠭⥊"),l1l11l_l1_ (u"ࠨࠩ⥋"),28)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⥌"),l1l11l_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩ⥍")+l1l11l_l1_ (u"ࠫ็์วสࠢส่๊฿วาใ้๋ࠣࠦๅ้ไ฼๋๊࠭⥎"),l1l11l_l1_ (u"ࠬ࠭⥏"),41)
	#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫ⥐"),l1l11l_l1_ (u"ࠧࡠࡍ࡚ࡘࡤ࠭⥑")+l1l11l_l1_ (u"ࠨไ้หฮࠦวๅๅ๋ฯึࠦๅ็่ࠢ์็฿็ๆࠩ⥒"),l1l11l_l1_ (u"ࠩࠪ⥓"),135)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⥔"),l1l11l_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪ⥕")+l1l11l_l1_ (u"่ࠬๆศห๋้ࠣอࠠๆ่้ࠣํู่ࠡสส๊๏ะࠧ⥖"),l1l11l_l1_ (u"࠭ࠧ⥗"),38)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⥘"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⥙"),l1l11l_l1_ (u"ࠩࠪ⥚"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⥛"),l1l11l_l1_ (u"ࠫࡤ࡚ࡖ࠲ࡡࠪ⥜")+l1l11l_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯฺࠠษ่อࠬ⥝"),l1l11l_l1_ (u"࠭ࠧ⥞"),102)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⥟"),l1l11l_l1_ (u"ࠨࡡࡗ࡚࠷ࡥࠧ⥠")+l1l11l_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤำอีสࠩ⥡"),l1l11l_l1_ (u"ࠪࠫ⥢"),103)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⥣"),l1l11l_l1_ (u"ࠬࡥࡔࡗ࠵ࡢࠫ⥤")+l1l11l_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡๆ็ๅา฻ࠧ⥥"),l1l11l_l1_ (u"ࠧࠨ⥦"),104)
	return
def ITEMS(l1lllll1ll_l1_,showDialogs=True):
	menu_name = l1l11l_l1_ (u"ࠨࡡࡗ࡚ࠬ⥧")+l1lllll1ll_l1_+l1l11l_l1_ (u"ࠩࡢࠫ⥨")
	client = l1ll1l1l11l_l1_(32)
	payload = { l1l11l_l1_ (u"ࠪ࡭ࡩ࠭⥩") : l1l11l_l1_ (u"ࠫࠬ⥪") , l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࠪ⥫") : client , l1l11l_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ⥬") : l1l11l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⥭") , l1l11l_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭⥮") : l1lllll1ll_l1_ }
	#data = l111111l_l1_(payload)
	#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⥯"),str(payload))
	#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⥰"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ⥱"), l11lll_l1_, payload, l1l11l_l1_ (u"ࠬ࠭⥲"), True,l1l11l_l1_ (u"࠭ࠧ⥳"),l1l11l_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ⥴"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭⥵"),l11lll_l1_,payload,l1l11l_l1_ (u"ࠩࠪ⥶"),l1l11l_l1_ (u"ࠪࠫ⥷"),l1l11l_l1_ (u"ࠫࠬ⥸"),l1l11l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ⥹"))
	html = response.content
	#html = html.replace(l1l11l_l1_ (u"࠭࡜ࡳࠩ⥺"),l1l11l_l1_ (u"ࠧࠨ⥻"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⥼"),l1l11l_l1_ (u"ࠩࠪ⥽"),html,html)
	#file = open(l1l11l_l1_ (u"ࠪࡷ࠿࠵ࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ⥾"), l1l11l_l1_ (u"ࠫࡼ࠭⥿"))
	#file.write(html)
	#file.close()
	items = re.findall(l1l11l_l1_ (u"ࠬ࠮࡛࡟࠽࡟ࡶࡡࡴ࡝ࠬࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠭⦀"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l11l_l1_ (u"࠭ࡡ࡭ࠩ⦁"),l1l11l_l1_ (u"ࠧࡂ࡮ࠪ⦂"))
			start = start.replace(l1l11l_l1_ (u"ࠨࡇ࡯ࠫ⦃"),l1l11l_l1_ (u"ࠩࡄࡰࠬ⦄"))
			start = start.replace(l1l11l_l1_ (u"ࠪࡅࡑ࠭⦅"),l1l11l_l1_ (u"ࠫࡆࡲࠧ⦆"))
			start = start.replace(l1l11l_l1_ (u"ࠬࡋࡌࠨ⦇"),l1l11l_l1_ (u"࠭ࡁ࡭ࠩ⦈"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l11l_l1_ (u"ࠧࡂ࡮࠰ࠫ⦉"),l1l11l_l1_ (u"ࠨࡃ࡯ࠫ⦊"))
			start = start.replace(l1l11l_l1_ (u"ࠩࡄࡰࠥ࠭⦋"),l1l11l_l1_ (u"ࠪࡅࡱ࠭⦌"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1ll1l1111_l1_,name,img in items:
			if l1l11l_l1_ (u"ࠫࠨ࠭⦍") in source: continue
			#if source in [l1l11l_l1_ (u"ࠬࡔࡔࠨ⦎"),l1l11l_l1_ (u"࡙࠭ࡖࠩ⦏"),l1l11l_l1_ (u"ࠧࡘࡕ࠳ࠫ⦐"),l1l11l_l1_ (u"ࠨࡔࡏ࠵ࠬ⦑"),l1l11l_l1_ (u"ࠩࡕࡐ࠷࠭⦒")]: continue
			if source!=l1l11l_l1_ (u"࡙ࠪࡗࡒࠧ⦓"): name = name+l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࠡࠢࠪ⦔")+source+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⦕")
			url = source+l1l11l_l1_ (u"࠭࠻࠼ࠩ⦖")+server+l1l11l_l1_ (u"ࠧ࠼࠽ࠪ⦗")+l1ll1l1111_l1_+l1l11l_l1_ (u"ࠨ࠽࠾ࠫ⦘")+l1lllll1ll_l1_
			addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⦙"),menu_name+l1l11l_l1_ (u"ࠪࠫ⦚")+name,url,105,img)
	else:
		if showDialogs: addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⦛"),menu_name+l1l11l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭⦜"),l1l11l_l1_ (u"࠭ࠧ⦝"),9999)
		#if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ⦞"),l1l11l_l1_ (u"ࠨࠩ⦟"),l1l11l_l1_ (u"ࠩࠪ⦠"),l1l11l_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ⦡"))
		#addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⦢"),menu_name+l1l11l_l1_ (u"๊ࠬไฤีไࠤ้อࠠห๊ฯำ่ࠥๆ้ษอࠤฯ๊แำ๊้๎ฮࠦไไࠩ⦣"),l1l11l_l1_ (u"࠭ࠧ⦤"),9999)
		#addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⦥"),menu_name+l1l11l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊วใำหหฦ่ࠦศๆสูิ่วยࠢไๆ฼࠭⦦"),l1l11l_l1_ (u"ࠩࠪ⦧"),9999)
		#addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⦨"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⦩"),l1l11l_l1_ (u"ࠬ࠭⦪"),9999)
		#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⦫"),menu_name+l1l11l_l1_ (u"ࠧࡖࡰࡩࡳࡷࡺࡵ࡯ࡣࡷࡩࡱࡿࠬࠡࡰࡲࠤ࡙࡜ࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠢࡩࡳࡷࠦࡹࡰࡷࠪ⦬"),l1l11l_l1_ (u"ࠨࠩ⦭"),9999)
		#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⦮"),menu_name+l1l11l_l1_ (u"ࠪࡍࡹࠦࡩࡴࠢࡩࡳࡷࠦࡲࡦ࡮ࡤࡸ࡮ࡼࡥࡴࠢࠩࠤ࡫ࡸࡩࡦࡰࡧࡷࠥࡵ࡮࡭ࡻࠪ⦯"),l1l11l_l1_ (u"ࠫࠬ⦰"),9999)
	return
def PLAY(id):
	source,server,l1ll1l1111_l1_,l1lllll1ll_l1_ = id.split(l1l11l_l1_ (u"ࠬࡁ࠻ࠨ⦱"))
	url = l1l11l_l1_ (u"࠭ࠧ⦲")
	if source==l1l11l_l1_ (u"ࠧࡖࡔࡏࠫ⦳"): url = l1ll1l1111_l1_
	elif source==l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ⦴"):
		url = WEBSITES[l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ⦵")][0]+l1l11l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭⦶")+l1ll1l1111_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],script_name,l1l11l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⦷"),url)
		return
	elif source==l1l11l_l1_ (u"ࠬࡍࡁࠨ⦸"):
		payload = { l1l11l_l1_ (u"࠭ࡩࡥࠩ⦹") : l1l11l_l1_ (u"ࠧࠨ⦺"), l1l11l_l1_ (u"ࠨࡷࡶࡩࡷ࠭⦻") : l1ll1l1l11l_l1_(32) , l1l11l_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ⦼") : l1l11l_l1_ (u"ࠪࡴࡱࡧࡹࡈࡃ࠴ࠫ⦽") , l1l11l_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ⦾") : l1l11l_l1_ (u"ࠬ࠭⦿") }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ⧀"),l11lll_l1_,payload,l1l11l_l1_ (u"ࠧࠨ⧁"),False,l1l11l_l1_ (u"ࠨࠩ⧂"),l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⧃"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⧄"),l1l11l_l1_ (u"ࠫࠬ⧅"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⧆"),l1l11l_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ⧇"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1ll1l11lll_l1_ = cookies[l1l11l_l1_ (u"ࠧࡂࡕࡓ࠲ࡓࡋࡔࡠࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࠫ⧈")]
		url = response.headers[l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ⧉")]
		payload = { l1l11l_l1_ (u"ࠩ࡬ࡨࠬ⧊") : l1ll1l1111_l1_ , l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ⧋") : l1ll1l1l11l_l1_(32) , l1l11l_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭⧌") : l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠷࠭⧍") , l1l11l_l1_ (u"࠭࡭ࡦࡰࡸࠫ⧎") : l1l11l_l1_ (u"ࠧࠨ⧏") }
		headers = { l1l11l_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ⧐") : l1l11l_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩࡃࠧ⧑")+l1ll1l11lll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⧒"),l11lll_l1_,payload,headers,l1l11l_l1_ (u"ࠫࠬ⧓"),l1l11l_l1_ (u"ࠬ࠭⧔"),l1l11l_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ⧕"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ⧖"),l1l11l_l1_ (u"ࠨࠩ⧗"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⧘"),l1l11l_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ⧙"))
			return
		html = response.content
		url = re.findall(l1l11l_l1_ (u"ࠫࡷ࡫ࡳࡱࠤ࠽ࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄࡳ࠳ࡶ࠺ࠬࠬ࠳࠰࠿ࠪࠤࠪ⧚"),html,re.DOTALL)
		l1111l_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭⧛"),l1l11l_l1_ (u"࠭ࠫࠬ࠭࠮࠯࠰ࠦࠧ⧜")+l1111l_l1_)
		#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ⧝"),l1l11l_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠡࠩ⧞")+params)
		l1ll1l11ll1_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠼࠳࠭⧟")+server+l1l11l_l1_ (u"ࠪ࠻࠼࠽࠯ࠨ⧠")+l1ll1l1111_l1_+l1l11l_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭⧡")+params
		l1ll1l1l1ll_l1_ = l1ll1l11ll1_l1_.replace(l1l11l_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ⧢"),l1l11l_l1_ (u"࠭࠴࠱࠼࠺ࠫ⧣")).replace(l1l11l_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ⧤"),l1l11l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ⧥"))
		l1ll1l1l1l1_l1_ = l1ll1l11ll1_l1_.replace(l1l11l_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ⧦"),l1l11l_l1_ (u"ࠪ࠸࠷ࡀ࠷ࠨ⧧")).replace(l1l11l_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭⧨"),l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ⧩"))
		l1l1lll_l1_ = [l1l11l_l1_ (u"࠭ࡈࡅࠩ⧪"),l1l11l_l1_ (u"ࠧࡔࡆ࠴ࠫ⧫"),l1l11l_l1_ (u"ࠨࡕࡇ࠶ࠬ⧬")]
		l1ll1l1l_l1_ = [l1ll1l11ll1_l1_,l1ll1l1l1ll_l1_,l1ll1l1l1l1_l1_]
		selection = 0
		#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ⧭"), l1l1lll_l1_)
		if selection == -1: return
		else: url = l1ll1l1l_l1_[selection]
	elif source==l1l11l_l1_ (u"ࠪࡒ࡙࠭⧮"):
		headers = { l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ⧯") : l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ⧰") }
		payload = { l1l11l_l1_ (u"࠭ࡩࡥࠩ⧱") : l1ll1l1111_l1_ , l1l11l_l1_ (u"ࠧࡶࡵࡨࡶࠬ⧲") : l1ll1l1l11l_l1_(32) , l1l11l_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ⧳") : l1l11l_l1_ (u"ࠩࡳࡰࡦࡿࡎࡕࠩ⧴") , l1l11l_l1_ (u"ࠪࡱࡪࡴࡵࠨ⧵") : l1lllll1ll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ⧶"), l11lll_l1_, payload, headers, False,l1l11l_l1_ (u"ࠬ࠭⧷"),l1l11l_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ⧸"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ⧹"),l1l11l_l1_ (u"ࠨࠩ⧺"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⧻"),l1l11l_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ⧼"))
			return
		html = response.content
		url = response.headers[l1l11l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭⧽")]
		url = url.replace(l1l11l_l1_ (u"ࠬࠫ࠲࠱ࠩ⧾"),l1l11l_l1_ (u"࠭ࠠࠨ⧿"))
		url = url.replace(l1l11l_l1_ (u"ࠧࠦ࠵ࡇࠫ⨀"),l1l11l_l1_ (u"ࠨ࠿ࠪ⨁"))
		if l1l11l_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࠨ⨂") in l1ll1l1111_l1_:
			url = url.replace(l1l11l_l1_ (u"ࠪࡒ࡙ࡔࡎࡪ࡮ࡨࠫ⨃"),l1l11l_l1_ (u"ࠫࠬ⨄"))
			url = url.replace(l1l11l_l1_ (u"ࠬࡲࡥࡢࡴࡱ࡭ࡳ࡭࠱ࠨ⨅"),l1l11l_l1_ (u"࠭ࡌࡦࡣࡵࡲ࡮ࡴࡧࠨ⨆"))
	elif source==l1l11l_l1_ (u"ࠧࡑࡎࠪ⨇"):
		#headers = { l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⨈") : l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ⨉") }
		payload = { l1l11l_l1_ (u"ࠪ࡭ࡩ࠭⨊") : l1ll1l1111_l1_ , l1l11l_l1_ (u"ࠫࡺࡹࡥࡳࠩ⨋") : l1ll1l1l11l_l1_(32) , l1l11l_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ⨌") : l1l11l_l1_ (u"࠭ࡰ࡭ࡣࡼࡔࡑ࠭⨍") , l1l11l_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ⨎") : l1lllll1ll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭⨏"), l11lll_l1_, payload, l1l11l_l1_ (u"ࠩࠪ⨐"),False,l1l11l_l1_ (u"ࠪࠫ⨑"),l1l11l_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭⨒"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⨓"),l1l11l_l1_ (u"࠭ࠧ⨔"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⨕"),l1l11l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ⨖"))
			return
		html = response.content
		url = response.headers[l1l11l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ⨗")]
		headers = {l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ⨘"):response.headers[l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ⨙")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ⨚"),url, l1l11l_l1_ (u"࠭ࠧ⨛"),headers , l1l11l_l1_ (u"ࠧࠨ⨜"),l1l11l_l1_ (u"ࠨࠩ⨝"),l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫ⨞"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⨟"),l1l11l_l1_ (u"ࠫࠬ⨠"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⨡"),l1l11l_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ⨢"))
			return
		html = response.content
		items = re.findall(l1l11l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⨣"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l11l_l1_ (u"ࠨࡖࡄࠫ⨤"),l1l11l_l1_ (u"ࠩࡉࡑࠬ⨥"),l1l11l_l1_ (u"ࠪ࡝࡚࠭⨦"),l1l11l_l1_ (u"ࠫ࡜࡙࠱ࠨ⨧"),l1l11l_l1_ (u"ࠬ࡝ࡓ࠳ࠩ⨨"),l1l11l_l1_ (u"࠭ࡒࡍ࠳ࠪ⨩"),l1l11l_l1_ (u"ࠧࡓࡎ࠵ࠫ⨪")]:
		if source==l1l11l_l1_ (u"ࠨࡖࡄࠫ⨫"): l1ll1l1111_l1_ = id
		headers = { l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⨬") : l1l11l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⨭") }
		payload = { l1l11l_l1_ (u"ࠫ࡮ࡪࠧ⨮") : l1ll1l1111_l1_ , l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࠪ⨯") : l1ll1l1l11l_l1_(32) , l1l11l_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ⨰") : l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽࠬ⨱")+source , l1l11l_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭⨲") : l1lllll1ll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⨳"),l11lll_l1_,payload,headers,l1l11l_l1_ (u"ࠪࠫ⨴"),l1l11l_l1_ (u"ࠫࠬ⨵"),l1l11l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ⨶"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⨷"),l1l11l_l1_ (u"ࠧࠨ⨸"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⨹"),l1l11l_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ⨺"))
			return
		html = response.content
		url = response.headers[l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ⨻")]
		if source==l1l11l_l1_ (u"ࠫࡋࡓࠧ⨼"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⨽"), url, l1l11l_l1_ (u"࠭ࠧ⨾"), l1l11l_l1_ (u"ࠧࠨ⨿"), False,l1l11l_l1_ (u"ࠨࠩ⩀"),l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠸ࡶ࡫ࠫ⩁"))
			url = response.headers[l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ⩂")]
			url = url.replace(l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ⩃"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⩄"))
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫ⩅"))
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫᶡ")
menu_name = l1l11l_l1_ (u"ࠬࡥࡅࡈࡐࡢࠫᶢ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫᶣ"),l1l11l_l1_ (u"ࠧศๆๆ่ࠬᶤ"),l1l11l_l1_ (u"ࠨࡰ࠲ࡅࠬᶥ"),l1l11l_l1_ (u"ࠩสุ่๊๊ะࠩᶦ"),l1l11l_l1_ (u"ࠪๆฺฯฺࠠึๅࠫᶧ")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l111l1_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l111ll_l1_(url)
	elif mode==434: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᶨ")+text)
	elif mode==435: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᶩ")+text)
	elif mode==436: results = l1l1l1ll1_l1_(url)
	elif mode==437: results = l111ll1l1_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᶪ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧᶫ"),l1l11l_l1_ (u"ࠨࠩᶬ"),l1l11l_l1_ (u"ࠩࠪᶭ"),l1l11l_l1_ (u"ࠪࠫᶮ"),l1l11l_l1_ (u"ࠫࠬᶯ"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᶰ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡣࡱࡳࡳ࡯ࡣࡢ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᶱ"),html,re.DOTALL)
	l111l11l1_l1_ = l111l11l1_l1_[0].strip(l1l11l_l1_ (u"ࠧ࠰ࠩᶲ"))
	l111l11l1_l1_ = SERVER(l111l11l1_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᶳ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᶴ"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᶵ"),l1l11l_l1_ (u"ࠫࠬᶶ"),439,l1l11l_l1_ (u"ࠬ࠭ᶷ"),l1l11l_l1_ (u"࠭ࠧᶸ"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶹ"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᶺ"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬᶻ"),l111l11l1_l1_,435)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧᶽ"),l111l11l1_l1_,434)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᶾ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᶿ"),l1l11l_l1_ (u"ࠧࠨ᷀"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᷁"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢ᷂ࠫ")+menu_name+l1l11l_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ᷃"),l111l11l1_l1_,431)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᷄"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᷅")+menu_name+l1l11l_l1_ (u"࠭วโๆส้ࠥอ่็ࠢ็ห๏์ࠧ᷆"),l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹ࠱ࠨ᷇"),436)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᷈"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᷉")+menu_name+l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤฬ๎ๆࠡๆส๎๋᷊࠭"),l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲ࡧ࡬࡭࠳ࠪ᷋"),436)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᷌"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᷍")+menu_name+l1l11l_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯ᷎ࠧ"),l111l11l1_l1_,437)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ᷏࠭"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞᷐ࠩ"),l1l11l_l1_ (u"ࠪࠫ᷑"),9999)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᷒"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᷓ")+menu_name+l1l11l_l1_ (u"࠭วๅ็่๎ืฯࠧᷔ"),l111l11l1_l1_,431,l1l11l_l1_ (u"ࠧࠨᷕ"),l1l11l_l1_ (u"ࠨࠩᷖ"),l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᷗ"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᷘ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᷙ")+menu_name+l1l11l_l1_ (u"ࠬษแๅษ่ࠫᷚ"),l111l11l1_l1_+l1l11l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠵ࠧᷛ"),436)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᷜ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᷝ")+menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬࠪᷞ"),l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠱࠶࠵ࠧᷟ"),436)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࡙ࠫࠧࡩࡵࡧࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬ࠧ࠭ᷠ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᷡ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		#if title==l1l11l_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᷢ"): title = l1l11l_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭ᷣ")
		if title in l1llll1_l1_: continue
		if title==l1l11l_l1_ (u"ࠨษ็ีห๐ำ๋หࠪᷤ"): continue
		if l1l11l_l1_ (u"ࠩส์๋ࠦไศ์้ࠫᷥ") in title: continue
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᷦ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᷧ")+menu_name+title,l1111l_l1_,431)
	return
def l111ll1l1_l1_(website=l1l11l_l1_ (u"ࠬ࠭ᷨ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᷩ"),website+l1l11l_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧᷪ"),l1l11l_l1_ (u"ࠨࠩᷫ"),l1l11l_l1_ (u"ࠩࠪᷬ"),l1l11l_l1_ (u"ࠪࠫᷭ"),l1l11l_l1_ (u"ࠫࠬᷮ"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᷯ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡣࡱࡳࡳ࡯ࡣࡢ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᷰ"),html,re.DOTALL)
	l111l11l1_l1_ = l111l11l1_l1_[0].strip(l1l11l_l1_ (u"ࠧ࠰ࠩᷱ"))
	l111l11l1_l1_ = SERVER(l111l11l1_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᷲ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡐ࡮ࡹࡴࡅࡴࡲࡴࡪࡪࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡵࡧ࡭࡯࡮ࡨࡏࡤࡷࡹ࡫ࡲࠣࠩᷳ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᷴ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1llll1_l1_: continue
		l1111l_l1_ = website+l1l11l_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࠨ᷵")+category+l1l11l_l1_ (u"ࠬࡃࠧ᷶")+value
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ᷷࠭"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠ᷸ࠩ")+menu_name+title,l1111l_l1_,431)
	return
def	l1l1l1ll1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨ᷹ࠩ"),l1l11l_l1_ (u"᷺ࠩࠪ"),l1l11l_l1_ (u"ࠪࡗ࡚ࡈࡍࡆࡐࡘࠫ᷻"),url)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ᷼"),l1111l_l1_)
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠬࡻࡲ࡭᷽ࠩ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ᷾"),url,l1l11l_l1_ (u"ࠧࠨ᷿"),l1l11l_l1_ (u"ࠨࠩḀ"),l1l11l_l1_ (u"ࠩࠪḁ"),l1l11l_l1_ (u"ࠪࠫḂ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩḃ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḄ"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾࠭ḅ"),url,431)
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧḆ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡫ࡦࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧḇ"),block,re.DOTALL)
	for l11l11111_l1_,title in items:
		if title in l1llll1_l1_: continue
		url2 = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡐࡳࡻ࡯ࡥࡴ࠱ࡎࡩࡾࡹ࠮ࡱࡪࡳࡃࡰ࡫ࡹ࠾ࠩḈ")+l11l11111_l1_
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪḉ"),menu_name+title,url2,431)
	#addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩḊ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḋ"),l1l11l_l1_ (u"࠭ࠧḌ"),9999)
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡋࡱࡲࡪࡸࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠧḍ"),html,re.DOTALL)
	#block = l1ll111_l1_[0]
	#items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨḎ"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1llll1_l1_: continue
	#	if l1l11l_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴ࠱ࠪḏ") in url: url2 = l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡑࡴࡼࡩࡦࡵ࠲ࡘࡪࡸ࡭ࡴ࠰ࡳ࡬ࡵࡅࠧḐ")+category+l1l11l_l1_ (u"ࠫࡂ࠭ḑ")+value
	#	elif l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠳ࠧḒ") in url: url2 = l111l11l1_l1_+l1l11l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡓࡦࡴ࡬ࡩࡸ࠵ࡇࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨḓ")+category+l1l11l_l1_ (u"ࠧ࠾ࠩḔ")+value
	#	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨḕ"),menu_name+title,url2,431)
	return
def l111l1_l1_(url,request=l1l11l_l1_ (u"ࠩࠪḖ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫḗ"),l1l11l_l1_ (u"ࠫࠬḘ"),request,url)
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩḙ"))
	items = []
	if l1l11l_l1_ (u"࠭࠯ࡕࡧࡵࡱࡸ࠴ࡰࡩࡲࠪḚ") in url or l1l11l_l1_ (u"ࠧ࠰ࡉࡨࡸ࠳ࡶࡨࡱࠩḛ") in url or l1l11l_l1_ (u"ࠨ࠱ࡎࡩࡾࡹ࠮ࡱࡪࡳࠫḜ") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬḝ"):l1l11l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫḞ"),l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪḟ"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬḠ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫḡ"),url2,data2,headers2,l1l11l_l1_ (u"ࠧࠨḢ"),l1l11l_l1_ (u"ࠨࠩḣ"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭Ḥ"))
		html = response.content
		block = html
	elif request==l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬḥ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨḦ"),url,l1l11l_l1_ (u"ࠬ࠭ḧ"),l1l11l_l1_ (u"࠭ࠧḨ"),l1l11l_l1_ (u"ࠧࠨḩ"),l1l11l_l1_ (u"ࠨࠩḪ"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ḫ"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡒࡧࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡎࡣࡷࡧ࡭࡫ࡳࡕࡣࡥࡰࡪࠨࠧḬ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧḭ"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩḮ"),url,l1l11l_l1_ (u"࠭ࠧḯ"),l1l11l_l1_ (u"ࠧࠨḰ"),l1l11l_l1_ (u"ࠨࠩḱ"),l1l11l_l1_ (u"ࠩࠪḲ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧḳ"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡒࡤ࡫࡮ࡴࡡࡵࡧࠥࠫḴ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬḵ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨḶ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"ࠧๆึส๋ิฯࠧḷ"),l1l11l_l1_ (u"ࠨใํ่๊࠭Ḹ"),l1l11l_l1_ (u"ࠩส฾๋๐ษࠨḹ"),l1l11l_l1_ (u"ࠪ็้๐ศࠨḺ"),l1l11l_l1_ (u"ࠫฬ฿ไศ่ࠪḻ"),l1l11l_l1_ (u"ࠬํฯศใࠪḼ"),l1l11l_l1_ (u"࠭ๅษษิหฮ࠭ḽ"),l1l11l_l1_ (u"ฺࠧำูࠫḾ"),l1l11l_l1_ (u"ࠨ็๊ีัอๆࠨḿ"),l1l11l_l1_ (u"ࠩส่อ๎ๅࠨṀ")]
	for l1111l_l1_,title,img in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠪ࠳ࠬṁ"))
		#l1111l_l1_ = unescapeHTML(l1111l_l1_)
		title = unescapeHTML(title)
		#title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭Ṃ"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨṃ"),title,re.DOTALL)
		if any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬṄ"),menu_name+title,l1111l_l1_,432,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠧศๆะ่็ฯࠧṅ") in title:
			title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧṆ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩṇ"),menu_name+title,l1111l_l1_,433,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨṈ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṉ"),menu_name+title,l1111l_l1_,431,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṊ"),menu_name+title,l1111l_l1_,433,img)
	if request!=l1l11l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨṋ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡒࡤ࡫࡮ࡴࡡࡵࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧṌ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧṍ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧṎ") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1111l_l1_
				l1111l_l1_ = unescapeHTML(l1111l_l1_)
				title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"ࠪࠫṏ"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṐ"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫṑ")+title,l1111l_l1_,431)
		l111lll11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṒ"),html,re.DOTALL)
		if l111lll11_l1_:
			l1111l_l1_ = l111lll11_l1_[0]
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṓ"),menu_name+l1l11l_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨṔ"),l1111l_l1_,431)
	return
def l111ll_l1_(url):
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪṕ"),l1l11l_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪṖ")+url)
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨṗ"))
	l11111l1l_l1_,l1ll1l1ll_l1_ = [],[]
	if l1l11l_l1_ (u"ࠬࡋࡰࡪࡵࡲࡨࡪࡹ࠮ࡱࡪࡳࠫṘ") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩṙ"):l1l11l_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨṚ"),l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧṛ"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩṜ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨṝ"),url2,data2,headers2,l1l11l_l1_ (u"ࠫࠬṞ"),l1l11l_l1_ (u"ࠬ࠭ṟ"),l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬṠ"))
		html = response.content
		l1ll1l1ll_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫṡ"),url,l1l11l_l1_ (u"ࠨࠩṢ"),l1l11l_l1_ (u"ࠩࠪṣ"),l1l11l_l1_ (u"ࠪࠫṤ"),l1l11l_l1_ (u"ࠫࠬṥ"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫṦ"))
		html = response.content
		l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩṧ"),html,re.DOTALL)
		l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡇࡳ࡭ࡸࡵࡤࡦࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫṨ"),html,re.DOTALL)
	# l111l111l_l1_
	if l11111l1l_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠨࠤࡲ࡫࠿࡯࡭ࡢࡩࡨࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧṩ"),html,re.DOTALL)
		img = img[0]
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬṪ"),block,re.DOTALL)
		for l111l1llll_l1_,l111l1lll1_l1_,title in items:
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡉࡵ࡯ࡳࡰࡦࡨࡷ࠳ࡶࡨࡱࡁࠪṫ")+l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡁࠬṬ")+l111l1lll1_l1_+l1l11l_l1_ (u"ࠬࠬࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨṭ")+l111l1llll_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ṯ"),menu_name+title,l1111l_l1_,433,img)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨṯ"))
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬṰ"),block,re.DOTALL)
		for l1111l_l1_,title,l1ll1ll_l1_ in items:
			title = title+l1l11l_l1_ (u"ࠩࠣࠫṱ")+l1ll1ll_l1_
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩṲ"),menu_name+title,l1111l_l1_,432,img)
	return
def PLAY(url):
	url2 = url+l1l11l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬṳ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩṴ"),url2,l1l11l_l1_ (u"࠭ࠧṵ"),l1l11l_l1_ (u"ࠧࠨṶ"),l1l11l_l1_ (u"ࠨࠩṷ"),l1l11l_l1_ (u"ࠩࠪṸ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬṹ"))
	html = response.content
	l1ll1l1l_l1_ = []
	l111l11l1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨṺ"))
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠯ࡶࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧṻ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1llllllll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṼ"),block,re.DOTALL)
		if l1llllllll_l1_:
			l1llllllll_l1_ = l1llllllll_l1_[0]
			#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨṽ"),l1l11l_l1_ (u"ࠨࠩṾ"),l1l11l_l1_ (u"ࠩࠪṿ"),l1llllllll_l1_)
			items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩẀ"),block,re.DOTALL)
			for server,title in items:
				l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩẁ")+server+l1l11l_l1_ (u"ࠬࠬࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨẂ")+l1llllllll_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧẃ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨẄ")
				l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l11111l_l1_ l1111l_l1_
	l1l11111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲࡯ࡦࡳࡣࡰࡩࠧࡄ࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬẅ"),html,re.DOTALL)
	if l1l11111l_l1_:
		l1l11111l_l1_ = l1l11111l_l1_[0].replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬẆ"),l1l11l_l1_ (u"ࠪࠫẇ"))
		title = SERVER(l1l11111l_l1_,l1l11l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩẈ"))
		l1111l_l1_ = l1l11111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ẉ")+title+l1l11l_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧẊ")
		l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪẋ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬẌ"),block,re.DOTALL)
		for l1111l_l1_,title,l1l1l111_l1_ in items:
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬẍ"),l1l11l_l1_ (u"ࠪࠫẎ"))
			if l1l1l111_l1_!=l1l11l_l1_ (u"ࠫࠬẏ"): l1l1l111_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪẐ")+l1l1l111_l1_
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧẑ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫẒ")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ẓ"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨẔ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠪࠫẕ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠫࠬẖ"): return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧẗ"),l1l11l_l1_ (u"࠭ࠥ࠳࠲ࠪẘ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡁࡶࡁࠬẙ")+search
	l111l1_l1_(url)
	return
# ===========================================
#     l111lllll_l1_ l111l1111_l1_ l1111ll1l_l1_
# ===========================================
def l111llll1_l1_(url):
	url = url.split(l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬẚ"))[0]
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭ẛ"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧẜ"),l111l11l1_l1_,l1l11l_l1_ (u"ࠫࠬẝ"),l1l11l_l1_ (u"ࠬ࠭ẞ"),l1l11l_l1_ (u"࠭ࠧẟ"),l1l11l_l1_ (u"ࠧࠨẠ"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪạ"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡢࡶࡶࡷࡳࡳࠨ࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫࡭ࡳ࡭ࡍࡢࡵࡷࡩࡷࠨࠧẢ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + options block + category
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡢࡶࡶࡷࡳࡳࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭ࠬả"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111l11ll_l1_(block):
	# value + name
	items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࡟ࡨ࠰࠯ࠢࠡࡦࡤࡸࡦ࠳࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬẤ"),block,re.DOTALL)
	return items
def l111ll1ll_l1_(url):
	#url = url.replace(l1l11l_l1_ (u"ࠬࡩࡡࡵ࠿ࠪấ"),l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩẦ"))
	l111l1l1l_l1_ = url.split(l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫầ"))[0]
	l111l1l11_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬẨ"))
	url = url.replace(l111l1l1l_l1_,l111l1l11_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ẩ"),l1l11l_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧẪ"))
	return url
def l111ll1111_l1_(l11l111_l1_,url):
	l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧẫ")) # l11l1l11ll_l1_ be l11l1ll111_l1_
	url3 = url+l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩẬ")+l1lll1l1_l1_
	url3 = l111ll1ll_l1_(url3)
	return url3
l111111_l1_ = [l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨậ"),l1l11l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨẮ"),l1l11l_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧắ"),l1l11l_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨẰ")]
l11ll1l_l1_ = [l1l11l_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫằ"),l1l11l_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪẲ"),l1l11l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫẳ"),l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨẴ"),l1l11l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩẵ"),l1l11l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩẶ")]
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫặ"),l1l11l_l1_ (u"ࠪࠫẸ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬẹ"),l1l11l_l1_ (u"ࠬ࠭Ẻ"),filter,url)
	if l1l11l_l1_ (u"࠭࠿ࠨẻ") in url: url = url.split(l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫẼ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠨࡡࡢࡣࠬẽ"),1)
	if filter==l1l11l_l1_ (u"ࠩࠪẾ"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠪࠫế"),l1l11l_l1_ (u"ࠫࠬỀ")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩề"))
	if type==l1l11l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩỂ"):
		if l111111_l1_[0]+l1l11l_l1_ (u"ࠧ࠾ࠩể") not in l1lllll1_l1_: category = l111111_l1_[0]
		for i in range(len(l111111_l1_[0:-1])):
			if l111111_l1_[i]+l1l11l_l1_ (u"ࠨ࠿ࠪỄ") in l1lllll1_l1_: category = l111111_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠩࠩࠫễ")+category+l1l11l_l1_ (u"ࠪࡁ࠵࠭Ệ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠫࠫ࠭ệ")+category+l1l11l_l1_ (u"ࠬࡃ࠰ࠨỈ")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠨỉ"))+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫỊ")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠪị"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬỌ")) # l11l11llll_l1_ l11lll11l1_l1_ not l1l1ll11ll_l1_
		url2 = url+l1l11l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧọ")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧỎ"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧỏ")) # l11l11llll_l1_ l11lll11l1_l1_ not l1l1ll11ll_l1_
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"࠭ࠧỐ"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪố")) # l11l11llll_l1_ l11lll11l1_l1_ not l1l1ll11ll_l1_
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠨࠩỒ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ồ")+l1llll1l_l1_
		url2 = l111ll1ll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪỔ"),menu_name+l1l11l_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧổ"),url2,431)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỖ"),menu_name+l1l11l_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ỗ")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭Ộ"),url2,431)
		addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ộ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩỚ"),l1l11l_l1_ (u"ࠪࠫớ"),9999)
	l1l1ll1_l1_ = l111llll1_l1_(url)
	dict = {}
	for name,block,l1l111l_l1_ in l1l1ll1_l1_:
		name = name.replace(l1l11l_l1_ (u"ࠫ࠲࠳ࠧỜ"),l1l11l_l1_ (u"ࠬ࠭ờ"))
		items = l111l11ll_l1_(block)
		if l1l11l_l1_ (u"࠭࠽ࠨỞ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪở"):
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l111111_l1_[-1]:
					url = l111ll1ll_l1_(url)
					l111l1_l1_(url)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧỠ")+l1111l1_l1_)
				return
			else:
				url2 = l111ll1ll_l1_(url2)
				if l1l111l_l1_==l111111_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩỡ"),menu_name+l1l11l_l1_ (u"ࠪห้าๅ๋฻ࠣࠫỢ"),url2,431)
				else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫợ"),menu_name+l1l11l_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭Ụ"),url2,435,l1l11l_l1_ (u"࠭ࠧụ"),l1l11l_l1_ (u"ࠧࠨỦ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫủ"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠩࠩࠫỨ")+l1l111l_l1_+l1l11l_l1_ (u"ࠪࡁ࠵࠭ứ")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠫࠫ࠭Ừ")+l1l111l_l1_+l1l11l_l1_ (u"ࠬࡃ࠰ࠨừ")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪỬ")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧử"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪỮ")+name,url2,434,l1l11l_l1_ (u"ࠩࠪữ"),l1l11l_l1_ (u"ࠪࠫỰ"),l1111l1_l1_)		# +l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ự"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if value==l1l11l_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬỲ"): option = l1l11l_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭ỳ")
			elif value==l1l11l_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧỴ"): option = l1l11l_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪỵ")
			if option in l1llll1_l1_: continue
			#if l1l11l_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨỶ") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫỷ"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠫࠫ࠭Ỹ")+l1l111l_l1_+l1l11l_l1_ (u"ࠬࡃࠧỹ")+option
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"࠭ࠦࠨỺ")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾ࠩỻ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬỼ")+l11l111_l1_
			title = option+l1l11l_l1_ (u"ࠩࠣ࠾ࠬỽ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠪ࠴ࠬỾ")]
			title = option+l1l11l_l1_ (u"ࠫࠥࡀࠧỿ")+name
			if type==l1l11l_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨἀ"): addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ἁ"),menu_name+title,url,434,l1l11l_l1_ (u"ࠧࠨἂ"),l1l11l_l1_ (u"ࠨࠩἃ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἄ"))
			elif type==l1l11l_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ἅ") and l111111_l1_[-2]+l1l11l_l1_ (u"ࠫࡂ࠭ἆ") in l1lllll1_l1_:
				url3 = l111ll1111_l1_(l11l111_l1_,url)
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἇ"),menu_name+title,url3,431)
			else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ἀ"),menu_name+title,url,435,l1l11l_l1_ (u"ࠧࠨἉ"),l1l11l_l1_ (u"ࠨࠩἊ"),l1l1111_l1_)
	return
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪἋ"),l1l11l_l1_ (u"ࠪࠫἌ"),filters,l1l11l_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬἍ"))
	# mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧἎ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩἏ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬἐ")			all l111l1l_l1_ & l111lll1l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠨ࠿ࠩࠫἑ"),l1l11l_l1_ (u"ࠩࡀ࠴ࠫ࠭ἒ"))
	filters = filters.strip(l1l11l_l1_ (u"ࠪࠪࠬἓ"))
	l1llllll_l1_ = {}
	if l1l11l_l1_ (u"ࠫࡂ࠭ἔ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠬࠬࠧἕ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"࠭࠽ࠨ἖"))
			l1llllll_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠧࠨ἗")
	for key in l11ll1l_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠨ࠲ࠪἘ")
		if l1l11l_l1_ (u"ࠩࠨࠫἙ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬἚ") and value!=l1l11l_l1_ (u"ࠫ࠵࠭Ἓ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠦࠫࠡࠩἜ")+value
		elif mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩἝ") and value!=l1l11l_l1_ (u"ࠧ࠱ࠩ἞"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠨࠨࠪ἟")+key+l1l11l_l1_ (u"ࠩࡀࠫἠ")+value
		elif mode==l1l11l_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨἡ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠫ࠭ἢ")+key+l1l11l_l1_ (u"ࠬࡃࠧἣ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"࠭ࠠࠬࠢࠪἤ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠩἥ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠨ࠿࠳ࠫἦ"),l1l11l_l1_ (u"ࠩࡀࠫἧ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫἨ"),l1l11l_l1_ (u"ࠫࠬἩ"),filters,l1l11l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭Ἢ"))
	return l11llll_l1_
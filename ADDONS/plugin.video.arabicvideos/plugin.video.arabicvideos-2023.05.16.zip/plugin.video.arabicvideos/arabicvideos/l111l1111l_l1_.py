# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
import bs4
script_name = l1l11l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨἫ")
menu_name = l1l11l_l1_ (u"ࠧࡠࡇࡏࡇࡤ࠭Ἤ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l11111l1ll_l1_(url)
	elif mode==512: results = l111l1ll11_l1_(url)
	elif mode==513: results = l111l1l1ll_l1_(url)
	elif mode==514: results = l11111ll11_l1_(url,l1l11l_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧἭ")+text)
	elif mode==515: results = l11111ll11_l1_(url,l1l11l_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨἮ")+text)
	elif mode==516: results = l1111ll1ll_l1_(text)
	elif mode==517: results = l111l11l11_l1_(url)
	elif mode==518: results = l111l11l1l_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1111llll1_l1_(url)
	elif mode==521: results = l11111l1l1_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l11111llll_l1_(text)
	elif mode==524: results = l1111l111l_l1_()
	elif mode==525: results = l111l1l1l1_l1_()
	elif mode==526: results = l1111lll1l_l1_()
	elif mode==527: results = l1111l11l1_l1_()
	else: results = False
	return results
def MENU(website=l1l11l_l1_ (u"ࠪࠫἯ")):
	if not website:
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἰ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬἱ"),l1l11l_l1_ (u"࠭ࠧἲ"),519)
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬἳ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠲࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪἴ"),l1l11l_l1_ (u"ࠩࠪἵ"),9999)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪἶ"),menu_name+l1l11l_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊รฺ็ส่ࠬἷ"),l1l11l_l1_ (u"ࠬ࠭Ἰ"),525)
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ἱ"),menu_name+l1l11l_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆฦุำอีࠨἺ"),l1l11l_l1_ (u"ࠨࠩἻ"),526)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩἼ"),menu_name+l1l11l_l1_ (u"้ࠪํฺู่หࠣห้๋ี็ใสฮࠬἽ"),l1l11l_l1_ (u"ࠫࠬἾ"),527)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἿ"),menu_name+l1l11l_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅ็้์฾อสࠨὀ"),l1l11l_l1_ (u"ࠧࠨὁ"),524)
	return
def l1111l111l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨὂ"),menu_name+l1l11l_l1_ (u"ࠩࠣๅ๏ี๊้้สฮࠥ࠳ࠠฯษุอࠬὃ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࠪὄ"),520)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫὅ"),menu_name+l1l11l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦัิัࠧ὆"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵࡬ࡢࡶࡨࡷࡹ࠭὇"),521)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧὈ"),menu_name+l1l11l_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษโะ็ࠪὉ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࡲࡰࡩ࡫ࡳࡵࠩὊ"),521)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪὋ"),menu_name+l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡลๆฯึࠦๅีษ๊ำฮ࠭Ὄ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡼࡩࡦࡹࡶࠫὍ"),521)
	return
def l111l1l1l1_l1_():
	l1l11l_l1_ (u"ࠨࠢࠣࠏࠍࠍࡹࡿࡰࡦࠢࡀࠤ࠶ࠦࠣࠡࡣࡦࡸࡴࡸࡳࠎࠌࠌࡸࡾࡶࡥࠡ࠿ࠣ࠶ࠥࠩࠠࡷ࡫ࡧࡩࡴࡹࠍࠋࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦ࠱ࠡࠥࠣࡱࡴࡼࡩࡦࡵࠐࠎࠎࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢ࠶ࠤࠨࠦࡳࡦࡴ࡬ࡩࡸࠓࠊࠊࡨࡲࡶࡪ࡯ࡧ࡯ࠢࡀࠤ࡫ࡧ࡬ࡴࡧࠣࠧࠥࡧࡲࡢࡤ࡬ࡧࠒࠐࠉࡧࡱࡵࡩ࡮࡭࡮ࠡ࠿ࠣࡸࡷࡻࡥࠡࠥࠣࡩࡳ࡭࡬ࡪࡵ࡫ࠑࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮๊๋ࠫหๅ์้ࠤศ็ไศ็ࠣ฽ึฮ๊ࠨ࠮࡯࡭ࡳࡱ࠲࠭࠷࠴࠵࠮ࠓࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅๆอ็๎๋ࠦๅิๆึ่ฬะฺࠠำห๎ࠬ࠲࡬ࡪࡰ࡮࠷࠱࠻࠱࠲ࠫࠐࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ้๊࠭ࠪัไ๋่ࠣวๆ๊วๆࠢสะ๋ฮ๊ࠨ࠮࡯࡭ࡳࡱ࠴࠭࠷࠴࠵࠮ࠓࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅๆอ็๎๋ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏࠭ࠬ࡭࡫ࡱ࡯࠺࠲࠵࠲࠳ࠬࠑࠏࠏ࡬ࡪࡰ࡮࠵ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠷ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠸ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠹ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠹ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩࠐࠎࠎࠨࠢࠣ὎")
	l1111l1l1l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠩ὏")
	l1111l1lll_l1_ = l1111l1l1l_l1_+l1l11l_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫὐ")
	l111l1l11l_l1_ = l1111l1l1l_l1_+l1l11l_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬὑ")
	l1111l11ll_l1_ = l1111l1l1l_l1_+l1l11l_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬὒ")
	l1111l1l11_l1_ = l1111l1l1l_l1_+l1l11l_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭ὓ")
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὔ"),menu_name+l1l11l_l1_ (u"࠭ๅึ่ไหฯࠦรโๆส้ࠥ฿ัษ์ࠪὕ"),l1111l1lll_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧὖ"),menu_name+l1l11l_l1_ (u"ࠨ็ุ๊ๆอสࠡ็ึุ่๊วหࠢ฼ีอ๐ࠧὗ"),l111l1l11l_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ὘"),menu_name+l1l11l_l1_ (u"ฺ้ࠪ์แศฬࠣวๆ๊วๆࠢสะ๋ฮ๊ࠨὙ"),l1111l11ll_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ὚"),menu_name+l1l11l_l1_ (u"๋ࠬี็ใสฮ๋ࠥำๅี็หฯࠦวอ่ห๎ࠬὛ"),l1111l1l11_l1_,511)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ὜"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠱࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩὝ"),l1l11l_l1_ (u"ࠨࠩ὞"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩὟ"),menu_name+l1l11l_l1_ (u"ࠪๅ์ืำࠡล฼้ฬ๊ࠠฤสฯำ๏࠭ὠ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡤࡰࡵ࡮ࡡࡣࡧࡷࠫὡ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὢ"),menu_name+l1l11l_l1_ (u"࠭แ่ำึࠤࠥฮไะࠢส่ส์สศฮࠪὣ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡩ࡯ࡶࡰࡷࡶࡾ࠭ὤ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨὥ"),menu_name+l1l11l_l1_ (u"ࠩไ๋ึูࠠศๆ็฾ฮ࠭ὦ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪὧ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫὨ"),menu_name+l1l11l_l1_ (u"ࠬ็็าีฺ้ࠣ์แศฬࠣห้฿ๅๅࠩὩ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳࡬࡫࡮ࡳࡧࠪὪ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧὫ"),menu_name+l1l11l_l1_ (u"ࠨใ๊ีุࠦำ็หࠣห้หีะษิࠫὬ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡳࡧ࡯ࡩࡦࡹࡥࡠࡻࡨࡥࡷ࠭Ὥ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨὮ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠲ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠶ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ὧ"),l1l11l_l1_ (u"ࠬ࠭ὰ"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ά"),menu_name+l1l11l_l1_ (u"ࠧๆ๊สื๊ࠦ࠭ࠡใ็ฮึࠦๅฮัาࠫὲ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬέ"),515)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩὴ"),menu_name+l1l11l_l1_ (u"้ࠪํอำๆࠢ࠰ࠤๆ๊สาࠢๆห๊๊ࠧή"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨὶ"),514)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪί"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠵ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠹࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨὸ"),l1l11l_l1_ (u"ࠧࠨό"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨὺ"),menu_name+l1l11l_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สา่ࠢัิีࠧύ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫὼ"),515)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫώ"),menu_name+l1l11l_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ὾"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ὿"),514)
	return
def l1111l11l1_l1_():
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᾀ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩᾁ"),l1l11l_l1_ (u"ࠩࠪᾂ"),l1l11l_l1_ (u"ࠪࠫᾃ"),l1l11l_l1_ (u"ࠫࠬᾄ"),l1l11l_l1_ (u"ࠬ࠭ᾅ"),l1l11l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᾆ"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬᾇ"),multi_valued_attributes=None)
	block = l11111l11l_l1_.find(l1l11l_l1_ (u"ࠨࡵࡨࡰࡪࡩࡴࠨᾈ"),attrs={l1l11l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧᾉ"):l1l11l_l1_ (u"ࠪࡸࡦ࡭ࠧᾊ")})	# <select name=l1l11l_l1_ (u"ࠫࡹࡧࡧࠨᾋ")>
	options = block.find_all(l1l11l_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠬᾌ"))
	for option in options:
		value = option.get(l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬᾍ"))		# or option[l1l11l_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭ᾎ")] l11ll1l1ll_l1_ it will fail if not l1ll1ll11_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᾏ"))
			value = value.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᾐ"))
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠫࡺࡹࡱࡧࡀࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࠨࡷࡥ࡬ࡃࠧᾑ")+value
		title = title.replace(l1l11l_l1_ (u"ࠫ็อฦๆหࠣࠫᾒ"),l1l11l_l1_ (u"ࠬ࠭ᾓ"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾔ"),menu_name+title,l1111l_l1_,511)
	return
def l1111lll1l_l1_():
	l1111l1l1l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠩᾕ")
	l1111l1ll1_l1_ = l1111l1l1l_l1_+l1l11l_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࠦࡵࡣࡪࡁࠬᾖ")
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᾗ"),menu_name+l1l11l_l1_ (u"ฺ้ࠪ์แศฬࠣวูิวึࠩᾘ"),l1111l1ll1_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᾙ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᾚ"),l1l11l_l1_ (u"࠭ࠧᾛ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᾜ"),menu_name+l1l11l_l1_ (u"ࠨใ๊ีุࠦรีะสูࠥษศอัํࠫᾝ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡤࡰࡵ࡮ࡡࡣࡧࡷࠫᾞ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᾟ"),menu_name+l1l11l_l1_ (u"ࠫๆํัิ่ࠢ์฼์ࠧᾠ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡴࡡࡵ࡫ࡲࡲࡦࡲࡩࡵࡻࠪᾡ"),517)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾢ"),menu_name+l1l11l_l1_ (u"ࠧโ้ิืࠥࠦสศำําࠥอไๆ์็หิ࠭ᾣ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡤ࡬ࡶࡹ࡮࡟ࡺࡧࡤࡶࠬᾤ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᾥ"),menu_name+l1l11l_l1_ (u"ࠪๅ์ืำࠡࠢอหึ๐ฮࠡษ็์ๆอษࠨᾦ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡩ࡫ࡡࡵࡪࡢࡽࡪࡧࡲࠨᾧ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᾨ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠸࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᾩ"),l1l11l_l1_ (u"ࠧࠨᾪ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᾫ"),menu_name+l1l11l_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สา่ࠢัิีࠧᾬ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫᾭ"),515)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᾮ"),menu_name+l1l11l_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี้ࠥวๆๆࠪᾯ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧᾰ"),514)
	return
def l11111l1ll_l1_(url):
	if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫᾱ") in url: index = 0
	elif l1l11l_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩᾲ") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᾳ"),url,l1l11l_l1_ (u"ࠪࠫᾴ"),l1l11l_l1_ (u"ࠫࠬ᾵"),l1l11l_l1_ (u"ࠬ࠭ᾶ"),l1l11l_l1_ (u"࠭ࠧᾷ"),l1l11l_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡏࡍࡘ࡚ࡓ࠮࠳ࡶࡸࠬᾸ"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭Ᾱ"),multi_valued_attributes=None)
	l1l1l1_l1_ = l11111l11l_l1_.find_all(class_=l1l11l_l1_ (u"ࠩ࡭ࡹࡲࡨ࡯࠮ࡶ࡫ࡩࡦࡺࡥࡳࠢࡦࡰࡪࡧࡲࡧ࡫ࡻࠫᾺ"))
	for block in l1l1l1_l1_:
		title = block.find_all(l1l11l_l1_ (u"ࠪࡥࠬΆ"))[index].text
		l1111l_l1_ = l11lll_l1_+block.find_all(l1l11l_l1_ (u"ࠫࡦ࠭ᾼ"))[index].get(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ᾽"))
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫι"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ᾿"))
		if not l1l1l1_l1_:
			l111l1ll11_l1_(l1111l_l1_)
			return
		else:
			title = title.replace(l1l11l_l1_ (u"ࠨไสส๊ฯࠠࠨ῀"),l1l11l_l1_ (u"ࠩࠪ῁"))
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῂ"),menu_name+title,l1111l_l1_,512)
	l11111lll1_l1_(l11111l11l_l1_,511)
	return
def l11111lll1_l1_(l11111l11l_l1_,mode):
	block = l11111l11l_l1_.find(class_=l1l11l_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨῃ"))
	if block:
		pages = block.find_all(l1l11l_l1_ (u"ࠬࡧࠧῄ"))
		l11111l111_l1_ = block.find_all(l1l11l_l1_ (u"࠭࡬ࡪࠩ῅"))
		l1111lll11_l1_ = list(zip(pages,l11111l111_l1_))
		ii = -1
		length = len(l1111lll11_l1_)
		for l1llll1ll_l1_,l11111ll1l_l1_ in l1111lll11_l1_:
			ii += 1
			l11111ll1l_l1_ = l11111ll1l_l1_[l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭ῆ")]
			if l1l11l_l1_ (u"ࠨࡷࡱࡥࡻࡧࡩ࡭ࡣࡥࡰࡪ࠭ῇ") in l11111ll1l_l1_ or l1l11l_l1_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࠪῈ") in l11111ll1l_l1_: continue
			name2 = l1llll1ll_l1_.text
			l111l1ll1_l1_ = l11lll_l1_+l1llll1ll_l1_.get(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨΈ"))
			if kodi_version<19:
				name2 = name2.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩῊ"))
				l111l1ll1_l1_ = l111l1ll1_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪΉ"))
			if   ii==0: name2 = l1l11l_l1_ (u"࠭ร้ๆ์ࠫῌ")
			elif ii==1: name2 = l1l11l_l1_ (u"ࠧิษหๆฮ࠭῍")
			elif ii==length-2: name2 = l1l11l_l1_ (u"ࠨๆสั็ฯࠧ῎")
			elif ii==length-1: name2 = l1l11l_l1_ (u"ࠩฦา๏ืษࠨ῏")
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῐ"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪῑ")+name2,l111l1ll1_l1_,mode)
	return
def l111l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩῒ"),url,l1l11l_l1_ (u"࠭ࠧΐ"),l1l11l_l1_ (u"ࠧࠨ῔"),l1l11l_l1_ (u"ࠨࠩ῕"),l1l11l_l1_ (u"ࠩࠪῖ"),l1l11l_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠶࠳࠱ࡴࡶࠪῗ"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩῘ"),multi_valued_attributes=None)
	l1l1l1_l1_ = l11111l11l_l1_.find_all(class_=l1l11l_l1_ (u"ࠬࡸ࡯ࡸࠩῙ"))
	items,first = [],True
	for block in l1l1l1_l1_:
		if not block.find(class_=l1l11l_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯ࡺࡶࡦࡶࡰࡦࡴࠪῚ")): continue
		if first: first = False ; continue
		l111l111ll_l1_ = []
		l111111lll_l1_ = block.find_all(class_=[l1l11l_l1_ (u"ࠧࡤࡧࡱࡷࡴࡸࡳࡩ࡫ࡳࠤࡷ࡫ࡤࠨΊ"),l1l11l_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡶࡵࡳࡲ࡯ࡩࠬ῜")])
		for l1111l1111_l1_ in l111111lll_l1_:
			l1lllll111_l1_ = l1111l1111_l1_.find_all(l1l11l_l1_ (u"ࠩ࡯࡭ࠬ῝"))[1].text
			if kodi_version<19:
				l1lllll111_l1_ = l1lllll111_l1_.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ῞"))
			l111l111ll_l1_.append(l1lllll111_l1_)
		if not l1l11_l1_(script_name,l1l11l_l1_ (u"ࠫࠬ῟"),l111l111ll_l1_,False):
			image = block.find(l1l11l_l1_ (u"ࠬ࡯࡭ࡨࠩῠ")).get(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨῡ"))
			title = block.find(l1l11l_l1_ (u"ࠧࡩ࠵ࠪῢ"))
			name = title.find(l1l11l_l1_ (u"ࠨࡣࠪΰ")).text
			l1111l_l1_ = l11lll_l1_+title.find(l1l11l_l1_ (u"ࠩࡤࠫῤ")).get(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨῥ"))
			plot = block.find(class_=l1l11l_l1_ (u"ࠫࡳࡵ࠭࡮ࡣࡵ࡫࡮ࡴࠧῦ"))
			stars = block.find(class_=l1l11l_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬῧ"))
			if plot: plot = plot.text
			if stars: stars = stars.text
			if kodi_version<19:
				image = image.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫῨ"))
				name = name.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬῩ"))
				l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ὺ"))
				if plot: plot = plot.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧΎ"))
			infodict = {}
			if stars: infodict[l1l11l_l1_ (u"ࠪࡷࡹࡧࡲࡴࠩῬ")] = stars
			if plot:
				plot = plot.replace(l1l11l_l1_ (u"ࠫࡡࡴࠧ῭"),l1l11l_l1_ (u"ࠬࠦ࠮࠯ࠢࠪ΅"))
				infodict[l1l11l_l1_ (u"࠭ࡰ࡭ࡱࡷࠫ`")] = plot.replace(l1l11l_l1_ (u"ࠧ࠯࠰࠱ห็ืรࠡษ็้ื๐ฯࠨ῰"),l1l11l_l1_ (u"ࠨࠩ῱"))
			if l1l11l_l1_ (u"ࠩ࠲ࡻࡴࡸ࡫࠰ࠩῲ") in l1111l_l1_:
				#name = l1l11l_l1_ (u"ࠪฬาัฺ่ࠠࠣࠫῳ")+name
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫῴ"),menu_name+name,l1111l_l1_,516,image,l1l11l_l1_ (u"ࠬ࠭῵"),name,l1l11l_l1_ (u"࠭ࠧῶ"),infodict)
			elif l1l11l_l1_ (u"ࠧ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩῷ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨῸ"),menu_name+name,l1111l_l1_,513,image,l1l11l_l1_ (u"ࠩࠪΌ"),name,l1l11l_l1_ (u"ࠪࠫῺ"),infodict)
	l11111lll1_l1_(l11111l11l_l1_,512)
	return
def l111l1l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨΏ"),url,l1l11l_l1_ (u"ࠬ࠭ῼ"),l1l11l_l1_ (u"࠭ࠧ´"),l1l11l_l1_ (u"ࠧࠨ῾"),l1l11l_l1_ (u"ࠨࠩ῿"),l1l11l_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠶࠲࠷ࡳࡵࠩ "))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ "),multi_valued_attributes=None)
	l1l1l1_l1_ = l11111l11l_l1_.find_all(l1l11l_l1_ (u"ࠫࡱ࡯ࠧ "))
	names,items = [],[]
	for block in l1l1l1_l1_:
		if not block.find(class_=l1l11l_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠮ࡹࡵࡥࡵࡶࡥࡳࠩ ")): continue
		if not block.find(class_=[l1l11l_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠨ "),l1l11l_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠢࡷࡩࡽࡺ࠭ࡤࡧࡱࡸࡪࡸࠧ ")]): continue
		if block.find(class_=l1l11l_l1_ (u"ࠨࡪ࡬ࡨࡪ࠭ ")): continue
		title = block.find(class_=[l1l11l_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠫ "),l1l11l_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠥࡺࡥࡹࡶ࠰ࡧࡪࡴࡴࡦࡴࠪ ")])
		name = title.find(l1l11l_l1_ (u"ࠫࡦ࠭ ")).text
		if name in names: continue
		names.append(name)
		l1111l_l1_ = l11lll_l1_+title.find(l1l11l_l1_ (u"ࠬࡧࠧ ")).get(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࠫ​"))
		if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ‌") in url: image = block.find(l1l11l_l1_ (u"ࠨ࡫ࡰ࡫ࠬ‍")).get(l1l11l_l1_ (u"ࠩࡶࡶࡨ࠭‎"))
		elif l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ‏") in url: image = block.find(l1l11l_l1_ (u"ࠫ࡮ࡳࡧࠨ‐")).get(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ‑"))
		elif l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ‒") in url: image = block.find(l1l11l_l1_ (u"ࠧࡪ࡯ࡪࠫ–")).get(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ—"))
		else: image = block.find(l1l11l_l1_ (u"ࠩ࡬ࡱ࡬࠭―")).get(l1l11l_l1_ (u"ࠪࡷࡷࡩࠧ‖"))
		if kodi_version<19:
			name = name.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ‗"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ‘"))
			image = image.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ’"))
		name = name.strip(l1l11l_l1_ (u"ࠧࠡࠩ‚"))
		items.append((name,l1111l_l1_,image))
	if l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ‛") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1111l_l1_,image in items:
		if l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ“") in url: addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ”"),menu_name+name,l1111l_l1_,522,image)
		elif l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭„") in url: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ‟"),menu_name+name,l1111l_l1_,513,image,l1l11l_l1_ (u"࠭ࠧ†"),name)
		else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ‡"),menu_name+name,l1111l_l1_,516,image,l1l11l_l1_ (u"ࠨࠩ•"),name)
	return
def l1111ll1ll_l1_(text):
	text = text.replace(l1l11l_l1_ (u"ࠩส่ส฿ไศ่ࠪ‣"),l1l11l_l1_ (u"ࠪࠫ․")).replace(l1l11l_l1_ (u"้ࠫ็๊ๅ็ࠪ‥"),l1l11l_l1_ (u"ࠬ࠭…")).replace(l1l11l_l1_ (u"࠭วๅำึ้๏࠭‧"),l1l11l_l1_ (u"ࠧࠨ "))
	text = text.replace(l1l11l_l1_ (u"ࠨว฼่ฬ์ࠧ "),l1l11l_l1_ (u"ࠩࠪ‪")).replace(l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨ‫"),l1l11l_l1_ (u"ࠫࠬ‬")).replace(l1l11l_l1_ (u"ࠬอไษำ๋้ํ࠭‭"),l1l11l_l1_ (u"࠭ࠧ‮"))
	text = text.replace(l1l11l_l1_ (u"ࠧศๆอุํ๐โ๋ࠩ "),l1l11l_l1_ (u"ࠨࠩ‰")).replace(l1l11l_l1_ (u"ࠩ็ุ้๊ำๅࠩ‱"),l1l11l_l1_ (u"ࠪࠫ′")).replace(l1l11l_l1_ (u"ู๊ࠫไิๆࠪ″"),l1l11l_l1_ (u"ࠬ࠭‴"))
	text = text.replace(l1l11l_l1_ (u"࠭࠺ࠨ‵"),l1l11l_l1_ (u"ࠧࠨ‶")).replace(l1l11l_l1_ (u"ࠨࠫࠪ‷"),l1l11l_l1_ (u"ࠩࠪ‸")).replace(l1l11l_l1_ (u"ࠪࠬࠬ‹"),l1l11l_l1_ (u"ࠫࠬ›")).replace(l1l11l_l1_ (u"ࠬ࠲ࠧ※"),l1l11l_l1_ (u"࠭ࠧ‼"))
	text = text.replace(l1l11l_l1_ (u"ࠧࡠࠩ‽"),l1l11l_l1_ (u"ࠨࠩ‾")).replace(l1l11l_l1_ (u"ࠩ࠾ࠫ‿"),l1l11l_l1_ (u"ࠪࠫ⁀")).replace(l1l11l_l1_ (u"ࠫ࠲࠭⁁"),l1l11l_l1_ (u"ࠬ࠭⁂")).replace(l1l11l_l1_ (u"࠭࠮ࠨ⁃"),l1l11l_l1_ (u"ࠧࠨ⁄"))
	text = text.replace(l1l11l_l1_ (u"ࠨ࡞ࠪࠫ⁅"),l1l11l_l1_ (u"ࠩࠪ⁆")).replace(l1l11l_l1_ (u"ࠪࡠࠧ࠭⁇"),l1l11l_l1_ (u"ࠫࠬ⁈"))
	text = text.replace(l1l11l_l1_ (u"ࠬࠦࠠࠡࠢࠪ⁉"),l1l11l_l1_ (u"࠭ࠠࠨ⁊")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ⁋"),l1l11l_l1_ (u"ࠨࠢࠪ⁌")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬ⁍"),l1l11l_l1_ (u"ࠪࠤࠬ⁎"))
	text = text.strip(l1l11l_l1_ (u"ࠫࠥ࠭⁏"))
	l111l11ll1_l1_ = text.count(l1l11l_l1_ (u"ࠬࠦࠧ⁐"))+1
	if l111l11ll1_l1_==1:
		l11111llll_l1_(text)
		return
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⁑"),menu_name+l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃࠠไๆ่หฯࠦไๅสะฯࠥࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⁒"),l1l11l_l1_ (u"ࠨࠩ⁓"),9999)
	l1111ll11l_l1_ = text.split(l1l11l_l1_ (u"ࠩࠣࠫ⁔"))
	l111l1l111_l1_ = pow(2,l111l11ll1_l1_)
	l111l11111_l1_ = []
	def l1111ll111_l1_(a,b):
		if a==l1l11l_l1_ (u"ࠪ࠵ࠬ⁕"): return b
		return l1l11l_l1_ (u"ࠫࠬ⁖")
	for ii in range(l111l1l111_l1_,0,-1):
		l1111lllll_l1_ = list(l111l11ll1_l1_*l1l11l_l1_ (u"ࠬ࠶ࠧ⁗")+bin(ii)[2:])[-l111l11ll1_l1_:]
		l1111lllll_l1_ = reversed(l1111lllll_l1_)
		result = map(l1111ll111_l1_,l1111lllll_l1_,l1111ll11l_l1_)
		title = l1l11l_l1_ (u"࠭ࠠࠨ⁘").join(filter(None,result))
		if kodi_version<19: title2 = title.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⁙"))
		else: title2 = title
		if len(title2)>2 and title not in l111l11111_l1_:
			l111l11111_l1_.append(title)
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⁚"),menu_name+title,l1l11l_l1_ (u"ࠩࠪ⁛"),523,l1l11l_l1_ (u"ࠪࠫ⁜"),l1l11l_l1_ (u"ࠫࠬ⁝"),title)
	return
def l11111llll_l1_(l111l11lll_l1_):
	if kodi_version<19:
		l111l11lll_l1_ = l111l11lll_l1_.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⁞"))
		import arabic_reshaper
		l111l11lll_l1_ = arabic_reshaper.ArabicReshaper().reshape(l111l11lll_l1_)
		l111l11lll_l1_ = bidi.algorithm.get_display(l111l11lll_l1_)
	import l111l111l1_l1_
	l111l11lll_l1_ = OPEN_KEYBOARD(default=l111l11lll_l1_)
	l111l111l1_l1_.SEARCH(l111l11lll_l1_)
	return
def l111l11l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ "),url,l1l11l_l1_ (u"ࠧࠨ⁠"),l1l11l_l1_ (u"ࠨࠩ⁡"),l1l11l_l1_ (u"ࠩࠪ⁢"),l1l11l_l1_ (u"ࠪࠫ⁣"),l1l11l_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡍࡋࡖࡘࡘ࠳࠱ࡴࡶࠪ⁤"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⁥"),multi_valued_attributes=None)
	block = l11111l11l_l1_.find(class_=l1l11l_l1_ (u"࠭࡬ࡪࡵࡷ࠱ࡸ࡫ࡰࡢࡴࡤࡸࡴࡸࠠ࡭࡫ࡶࡸ࠲ࡺࡩࡵ࡮ࡨࠫ⁦"))
	titles = block.find_all(l1l11l_l1_ (u"ࠧࡢࠩ⁧"))
	items = []
	for title in titles:
		name = title.text
		l1111l_l1_ = l11lll_l1_+title.get(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫࠭⁨"))
		if kodi_version<19:
			name = name.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⁩"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⁪"))
		if l1l11l_l1_ (u"ࠫࠨ࠭⁫") not in l1111l_l1_: items.append((name,l1111l_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1111l_l1_ = item
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⁬"),menu_name+name,l1111l_l1_,518)
	return
def l111l11l1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ⁭"),url,l1l11l_l1_ (u"ࠧࠨ⁮"),l1l11l_l1_ (u"ࠨࠩ⁯"),l1l11l_l1_ (u"ࠩࠪ⁰"),l1l11l_l1_ (u"ࠪࠫⁱ"),l1l11l_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⁲"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⁳"),multi_valued_attributes=None)
	l1l1l1_l1_ = l11111l11l_l1_.find(class_=l1l11l_l1_ (u"࠭ࡥࡹࡲࡤࡲࡩ࠭⁴")).find_all(l1l11l_l1_ (u"ࠧࡵࡴࠪ⁵"))
	for block in l1l1l1_l1_:
		l1111ll1l1_l1_ = block.find_all(l1l11l_l1_ (u"ࠨࡣࠪ⁶"))
		if not l1111ll1l1_l1_: continue
		image = block.find(l1l11l_l1_ (u"ࠩ࡬ࡱ࡬࠭⁷")).get(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ⁸"))
		name = l1111ll1l1_l1_[1].text
		l1111l_l1_ = l11lll_l1_+l1111ll1l1_l1_[1].get(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⁹"))
		stars = block.find(class_=l1l11l_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬ⁺"))
		if stars: stars = stars.text
		if kodi_version<19:
			name = name.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⁻"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⁼"))
			image = image.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⁽"))
		infodict = {}
		if stars: infodict[l1l11l_l1_ (u"ࠩࡶࡸࡦࡸࡳࠨ⁾")] = stars
		if l1l11l_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪⁿ") in l1111l_l1_:
			#name = l1l11l_l1_ (u"ࠫอำหࠡ฻้ࠤࠬ₀")+name
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ₁"),menu_name+name,l1111l_l1_,516,image,l1l11l_l1_ (u"࠭ࠧ₂"),name,l1l11l_l1_ (u"ࠧࠨ₃"),infodict)
		elif l1l11l_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ₄") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ₅"),menu_name+name,l1111l_l1_,513,image,l1l11l_l1_ (u"ࠪࠫ₆"),name,l1l11l_l1_ (u"ࠫࠬ₇"),infodict)
	l11111lll1_l1_(l11111l11l_l1_,518)
	return
def l1111llll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ₈"),url,l1l11l_l1_ (u"࠭ࠧ₉"),l1l11l_l1_ (u"ࠧࠨ₊"),l1l11l_l1_ (u"ࠨࠩ₋"),l1l11l_l1_ (u"ࠩࠪ₌"),l1l11l_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡜ࡉࡅࡇࡒࡗࡤࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨ₍"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ₎"),multi_valued_attributes=None)
	titles = l11111l11l_l1_.find_all(class_=l1l11l_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡴࡪࡶ࡯ࡩࠥ࡯࡮࡭࡫ࡱࡩࠬ₏"))
	l1l1lll1_l1_ = l11111l11l_l1_.find_all(class_=l1l11l_l1_ (u"࠭ࡢࡶࡶࡷࡳࡳࠦࡧࡳࡧࡨࡲࠥࡹ࡭ࡢ࡮࡯ࠤࡷ࡯ࡧࡩࡶࠪₐ"))
	items = zip(titles,l1l1lll1_l1_)
	for title,l1111l_l1_ in items:
		title = title.text
		l1111l_l1_ = l11lll_l1_+l1111l_l1_.get(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࠬₑ"))
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ₒ"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧₓ"))
		title = title.replace(l1l11l_l1_ (u"ࠪࠤࠥࠦࠠࠨₔ"),l1l11l_l1_ (u"ࠫࠥ࠭ₕ")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠡࠩₖ"),l1l11l_l1_ (u"࠭ࠠࠨₗ")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪₘ"),l1l11l_l1_ (u"ࠨࠢࠪₙ"))
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩₚ"),menu_name+title,l1111l_l1_,521)
	return
def l11111l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧₛ"),url,l1l11l_l1_ (u"ࠫࠬₜ"),l1l11l_l1_ (u"ࠬ࠭₝"),l1l11l_l1_ (u"࠭ࠧ₞"),l1l11l_l1_ (u"ࠧࠨ₟"),l1l11l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰࡚ࡎࡊࡅࡐࡕࡢࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ₠"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ₡"),multi_valued_attributes=None)
	l111l1ll1l_l1_ = l11111l11l_l1_.find(class_=l1l11l_l1_ (u"ࠪࡰࡦࡸࡧࡦ࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡ࡯ࡨࡨ࡮ࡻ࡭࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠺ࠠࡴ࡯ࡤࡰࡱ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠶ࠬ₢"))
	l1l1l1_l1_ = l111l1ll1l_l1_.find_all(l1l11l_l1_ (u"ࠫࡱ࡯ࠧ₣"))
	for block in l1l1l1_l1_:
		title = block.find(class_=l1l11l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ₤")).text
		l1111l_l1_ = l11lll_l1_+block.find(l1l11l_l1_ (u"࠭ࡡࠨ₥")).get(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࠬ₦"))
		image = block.find(l1l11l_l1_ (u"ࠨ࡫ࡰ࡫ࠬ₧")).get(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ₨"))
		duration = block.find(class_=l1l11l_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ₩")).text
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ₪"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ₫"))
			image = image.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ€"))
			duration = duration.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ₭"))
		duration = duration.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫ₮"),l1l11l_l1_ (u"ࠩࠪ₯")).strip(l1l11l_l1_ (u"ࠪࠤࠬ₰"))
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ₱"),menu_name+title,l1111l_l1_,522,image,duration)
	l11111lll1_l1_(l11111l11l_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ₲"),url,l1l11l_l1_ (u"࠭ࠧ₳"),l1l11l_l1_ (u"ࠧࠨ₴"),l1l11l_l1_ (u"ࠨࠩ₵"),l1l11l_l1_ (u"ࠩࠪ₶"),l1l11l_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ₷"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ₸"),multi_valued_attributes=None)
	l1111l_l1_ = l11111l11l_l1_.find(class_=l1l11l_l1_ (u"ࠬ࡬࡬ࡦࡺ࠰ࡺ࡮ࡪࡥࡰࠩ₹")).find(l1l11l_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪ࠭₺")).get(l1l11l_l1_ (u"ࠧࡴࡴࡦࠫ₻"))
	if kodi_version<19: l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭₼"))
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ₽"))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠪࠫ₾"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠫࠬ₿"): return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧ⃀"),l1l11l_l1_ (u"࠭ࠥ࠳࠲ࠪ⃁"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡁࡴࡁࠬ⃂")+search
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⃃"),url,l1l11l_l1_ (u"ࠩࠪ⃄"),l1l11l_l1_ (u"ࠪࠫ⃅"),l1l11l_l1_ (u"ࠫࠬ⃆"),l1l11l_l1_ (u"ࠬ࠭⃇"),l1l11l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ⃈"))
	html = response.content
	l11111l11l_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ⃉"),multi_valued_attributes=None)
	l1l1l1_l1_ = l11111l11l_l1_.find_all(class_=l1l11l_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯࠯ࡷ࡭ࡹࡲࡥࠡ࡮ࡨࡪࡹ࠭⃊"))
	for block in l1l1l1_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⃋"))
		title = title.split(l1l11l_l1_ (u"ࠪࠬࠬ⃌"),1)[0].strip(l1l11l_l1_ (u"ࠫࠥ࠭⃍"))
		if   l1l11l_l1_ (u"ࠬษูๆษ็ࠫ⃎") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⃏"),l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ⃐"))
		elif l1l11l_l1_ (u"ࠨลืาฬ฻ࠧ⃑") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲⃒ࠫ"),l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳⃓ࠬ"))
		#elif l1l11l_l1_ (u"ࠫศำฯศอࠪ⃔") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⃕"),l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡦࡸࡨࡲࡹ࠵ࠧ⃖"))
		#elif l1l11l_l1_ (u"ࠧๆ้ิะฬ์วหࠩ⃗") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱⃘ࠪ"),l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡪࡪࡹࡴࡪࡸࡤࡰ࠴⃙࠭"))
		elif l1l11l_l1_ (u"ࠪๅ๏ี๊้้สฮ⃚ࠬ") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⃛"),l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭⃜"))
		#elif l1l11l_l1_ (u"࠭รฯสสีࠬ⃝") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⃞"),l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡷࡳࡵ࡯ࡣ࠰ࠩ⃟"))
		else: continue
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⃠"),menu_name+title,l1111l_l1_,513)
	return
# ===========================================
#     l111lllll_l1_ l111l1111_l1_ l1111ll1l_l1_
# ===========================================
def l11111ll11_l1_(url,text):
	global l111111_l1_,l11ll1l_l1_
	if l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ⃡") in url:
		l111111_l1_ = [l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⃢"),l1l11l_l1_ (u"ࠬࡿࡥࡢࡴࠪ⃣"),l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⃤")]
		l11ll1l_l1_ = [l1l11l_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭⃥ࠩ"),l1l11l_l1_ (u"ࠨࡻࡨࡥࡷ⃦࠭"),l1l11l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⃧")]
	elif l1l11l_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳ⃨ࠫ") in url:
		l111111_l1_ = [l1l11l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⃩"),l1l11l_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ⃪࠭"),l1l11l_l1_ (u"࠭ࡴࡺࡲࡨ⃫ࠫ")]
		l11ll1l_l1_ = [l1l11l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ⃬ࠩ"),l1l11l_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯⃭ࠩ"),l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫⃮ࠧ")]
	l1l1l1l_l1_(url,text)
	return
def l111llll1_l1_(url):
	url = url.split(l1l11l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅ⃯ࠧ"))[0]
	#l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ⃰"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⃱"),url,l1l11l_l1_ (u"࠭ࠧ⃲"),l1l11l_l1_ (u"ࠧࠨ⃳"),l1l11l_l1_ (u"ࠨࠩ⃴"),l1l11l_l1_ (u"ࠩࠪ⃵"),l1l11l_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ⃶"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡫ࡵࡲ࡮ࠢࡤࡧࡹ࡯࡯࡯࠿ࠥ࠳࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ⃷"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + category + options block
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹࠦ࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⃸"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111l11ll_l1_(block):
	# value + name
	items = re.findall(l1l11l_l1_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⃹"),block,re.DOTALL)
	return items
def l111ll1ll_l1_(url):
	#url = url.replace(l1l11l_l1_ (u"ࠧࡤࡣࡷࡁࠬ⃺"),l1l11l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ⃻"))
	l111l1l1l_l1_ = url.split(l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⃼"))[0]
	l111l1l11_l1_ = SERVER(url,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ⃽"))
	#url = url.replace(l111l1l1l_l1_,l111l1l11_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⃾"),l1l11l_l1_ (u"ࠬ࠵࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠧࠩ⃿"))
	return url
def l11ll1ll11_l1_(l11l111_l1_,url):
	l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ℀")) # l11l1l11ll_l1_ be l11l1ll111_l1_
	url3 = url+l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ℁")+l1lll1l1_l1_
	url3 = l111ll1ll_l1_(url3)
	return url3
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪℂ"),l1l11l_l1_ (u"ࠩࠪ℃"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ℄"),l1l11l_l1_ (u"ࠫࠬ℅"),filter,url)
	if l1l11l_l1_ (u"ࠬࡅࠧ℆") in url: url = url.split(l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪℇ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ℈"),1)
	if filter==l1l11l_l1_ (u"ࠨࠩ℉"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠩࠪℊ"),l1l11l_l1_ (u"ࠪࠫℋ")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨℌ"))
	if type==l1l11l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨℍ"):
		if l111111_l1_[0]+l1l11l_l1_ (u"࠭࠽ࠨℎ") not in l1lllll1_l1_: category = l111111_l1_[0]
		for i in range(len(l111111_l1_[0:-1])):
			if l111111_l1_[i]+l1l11l_l1_ (u"ࠧ࠾ࠩℏ") in l1lllll1_l1_: category = l111111_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠨࠨࠪℐ")+category+l1l11l_l1_ (u"ࠩࡀ࠴ࠬℑ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠪࠪࠬℒ")+category+l1l11l_l1_ (u"ࠫࡂ࠶ࠧℓ")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧ℔"))+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪℕ")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠩ№"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ℗")) # l11l11llll_l1_ l11lll11l1_l1_ not l1l1ll11ll_l1_
		url2 = url+l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭℘")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ℙ"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ℚ")) # l11l11llll_l1_ l11lll11l1_l1_ not l1l1ll11ll_l1_
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠬ࠭ℛ"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩℜ")) # l11l11llll_l1_ l11lll11l1_l1_ not l1l1ll11ll_l1_
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠧࠨℝ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ℞")+l1llll1l_l1_
		url2 = l111ll1ll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ℟"),menu_name+l1l11l_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭℠"),url2,511)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ℡"),menu_name+l1l11l_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ™")+l1ll1l11_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ℣"),url2,511)
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬℤ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ℥"),l1l11l_l1_ (u"ࠩࠪΩ"),9999)
	l1l1ll1_l1_ = l111llll1_l1_(url)
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		name = name.replace(l1l11l_l1_ (u"ࠪ࠱࠲࠭℧"),l1l11l_l1_ (u"ࠫࠬℨ"))
		items = l111l11ll_l1_(block)
		if l1l11l_l1_ (u"ࠬࡃࠧ℩") not in url2: url2 = url
		if type==l1l11l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩK"):
			if l1l111l_l1_ not in l111111_l1_: continue
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l111111_l1_[-1]:
					url = l111ll1ll_l1_(url)
					l111l1ll11_l1_(url)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Å")+l1111l1_l1_)
				return
			else:
				url2 = l111ll1ll_l1_(url2)
				if l1l111l_l1_==l111111_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨℬ"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠩℭ"),url2,511)
				else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ℮"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫℯ"),url2,515,l1l11l_l1_ (u"ࠬ࠭ℰ"),l1l11l_l1_ (u"࠭ࠧℱ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪℲ"):
			if l1l111l_l1_ not in l11ll1l_l1_: continue
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠨࠨࠪℳ")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀ࠴ࠬℴ")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠪࠪࠬℵ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠶ࠧℶ")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩℷ")+l11l111_l1_
			if   name==l1l11l_l1_ (u"࠭ࡴࡺࡲࡨࠫℸ"): name = l1l11l_l1_ (u"ࠧศๆ้์฾࠭ℹ")
			elif name==l1l11l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ℺"): name = l1l11l_l1_ (u"ࠩส่฾๋ไࠨ℻")
			elif name==l1l11l_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫℼ"): name = l1l11l_l1_ (u"ࠫฬ๊ไ฻หࠪℽ")
			elif name==l1l11l_l1_ (u"ࠬࡿࡥࡢࡴࠪℾ"): name = l1l11l_l1_ (u"࠭วๅี้อࠬℿ")
			elif name==l1l11l_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ⅀"): name = l1l11l_l1_ (u"ࠨษ็้ํูๅࠨ⅁")
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⅂"),menu_name+l1l11l_l1_ (u"ࠪห้าๅ๋฻࠽ࠤࠬ⅃")+name,url2,514,l1l11l_l1_ (u"ࠫࠬ⅄"),l1l11l_l1_ (u"ࠬ࠭ⅅ"),l1111l1_l1_)		# +l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨⅆ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if option in l1llll1_l1_: continue
			if l1l11l_l1_ (u"ࠧๆื้ๅฬะࠠฤะิํࠬⅇ") in option: continue
			if l1l11l_l1_ (u"ࠨษ็็้࠭ⅈ") in option: continue
			if l1l11l_l1_ (u"ࠩส่้เษࠨⅉ") in option: continue
			option = option.replace(l1l11l_l1_ (u"ࠪๆฬฬๅสࠢࠪ⅊"),l1l11l_l1_ (u"ࠫࠬ⅋"))
			if   name==l1l11l_l1_ (u"ࠬࡺࡹࡱࡧࠪ⅌"): name = l1l11l_l1_ (u"࠭วๅ่๋฽ࠬ⅍")
			elif name==l1l11l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩⅎ"): name = l1l11l_l1_ (u"ࠨษ็฽๊๊ࠧ⅏")
			elif name==l1l11l_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ⅐"): name = l1l11l_l1_ (u"ࠪหฺ้๊สࠩ⅑")
			elif name==l1l11l_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ⅒"): name = l1l11l_l1_ (u"ࠬอไิ่ฬࠫ⅓")
			elif name==l1l11l_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ⅔"): name = l1l11l_l1_ (u"ࠧศๆ่์ุ๋ࠧ⅕")
			#if l1l11l_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ⅖") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ⅗"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠪࠪࠬ⅘")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠭⅙")+option
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠬࠬࠧ⅚")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽ࠨ⅛")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ⅜")+l11l111_l1_
			if name: title = option+l1l11l_l1_ (u"ࠨࠢ࠽ࠫ⅝")+name
			else: title = option   #+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠩ࠳ࠫ⅞")]
			if type==l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⅟"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅠ"),menu_name+title,url,514,l1l11l_l1_ (u"ࠬ࠭Ⅱ"),l1l11l_l1_ (u"࠭ࠧⅢ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩⅣ"))
			elif type==l1l11l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫⅤ") and l111111_l1_[-2]+l1l11l_l1_ (u"ࠩࡀࠫⅥ") in l1lllll1_l1_:
				url3 = l11ll1ll11_l1_(l11l111_l1_,url)
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⅦ"),menu_name+title,url3,511)
			else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅧ"),menu_name+title,url,515,l1l11l_l1_ (u"ࠬ࠭Ⅸ"),l1l11l_l1_ (u"࠭ࠧⅩ"),l1l1111_l1_)
	return
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨⅪ"),l1l11l_l1_ (u"ࠨࠩⅫ"),filters,l1l11l_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪⅬ"))
	# mode==l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬⅭ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧⅮ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪⅯ")			all l111l1l_l1_ & l111lll1l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"࠭࠽ࠧࠩⅰ"),l1l11l_l1_ (u"ࠧ࠾࠲ࠩࠫⅱ"))
	filters = filters.strip(l1l11l_l1_ (u"ࠨࠨࠪⅲ"))
	l1llllll_l1_ = {}
	if l1l11l_l1_ (u"ࠩࡀࠫⅳ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠪࠪࠬⅴ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠫࡂ࠭ⅵ"))
			l1llllll_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠬ࠭ⅶ")
	for key in l11ll1l_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"࠭࠰ࠨⅷ")
		if l1l11l_l1_ (u"ࠧࠦࠩⅸ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪⅹ") and value!=l1l11l_l1_ (u"ࠩ࠳ࠫⅺ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠪࠤ࠰ࠦࠧⅻ")+value
		elif mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧⅼ") and value!=l1l11l_l1_ (u"ࠬ࠶ࠧⅽ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠦࠨⅾ")+key+l1l11l_l1_ (u"ࠧ࠾ࠩⅿ")+value
		elif mode==l1l11l_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ↀ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠩࠫↁ")+key+l1l11l_l1_ (u"ࠪࡁࠬↂ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠫࠥ࠱ࠠࠨↃ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧↄ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"࠭࠽࠱ࠩↅ"),l1l11l_l1_ (u"ࠧ࠾ࠩↆ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩↇ"),l1l11l_l1_ (u"ࠩࠪↈ"),filters,l1l11l_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫ↉"))
	return l11llll_l1_
l111111_l1_ = []
l11ll1l_l1_ = []
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᐧ")
menu_name = l1l11l_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧᐨ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᐩ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l111l1_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l111ll_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᐪ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᐫ"),l1l11l_l1_ (u"ࠬ࠭ᐬ"),l1l11l_l1_ (u"࠭ࠧᐭ"),l1l11l_l1_ (u"ࠧࠨᐮ"),l1l11l_l1_ (u"ࠨࠩᐯ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᐰ"))
	html = response.content
	l111l11l1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧᐱ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐲ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᐳ"),l1l11l_l1_ (u"࠭ࠧᐴ"),559,l1l11l_l1_ (u"ࠧࠨᐵ"),l1l11l_l1_ (u"ࠨࠩᐶ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᐷ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐸ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐹ"),l1l11l_l1_ (u"ࠬ࠭ᐺ"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐻ"),menu_name+l1l11l_l1_ (u"ࠧศะอี๋อࠠๅๅࠪᐼ"),l111l11l1_l1_+l1l11l_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᐽ"),551,l1l11l_l1_ (u"ࠩࠪᐾ"),l1l11l_l1_ (u"ࠪࠫᐿ"),l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᑀ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᑁ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᑂ"),block,re.DOTALL)
	for l11l11111_l1_,title in items:
		l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭ᑃ")+l11l11111_l1_+l1l11l_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩᑄ")
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᑅ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᑆ")+menu_name+title,l1111l_l1_,551)
	#addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᑇ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᑈ"),l1l11l_l1_ (u"࠭ࠧᑉ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨᑊ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᑋ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠩࠦࠫᑌ"): continue
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ุ้๊ࠪำๅࠢࠪᑍ") in title: continue
		if l1l11l_l1_ (u"ࠫศำฯฬࠩᑎ") in title: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᑏ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᑐ")+menu_name+title,l1111l_l1_,551)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᑑ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᑒ"),l1l11l_l1_ (u"ࠩࠪᑓ"),9999)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠪࠧࠬᑔ"): continue
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ู๊ࠫไิๆࠣࠫᑕ") in title: continue
		if l1l11l_l1_ (u"ࠬษอะอࠪᑖ") not in title: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᑗ"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᑘ")+menu_name+title,l1111l_l1_,551)
	return
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"ࠨࠩᑙ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᑚ"),l1l11l_l1_ (u"ࠪࠫᑛ"),url)
	items = []
	# l11111lll_l1_ l1111l111_l1_
	if l1l11l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫᑜ") in url or l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ᑝ") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᑞ"):l1l11l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᑟ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᑠ"),url2,data2,headers2,l1l11l_l1_ (u"ࠩࠪᑡ"),l1l11l_l1_ (u"ࠪࠫᑢ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᑣ"))
		html = response.content
		l1ll111_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᑤ"),url,l1l11l_l1_ (u"࠭ࠧᑥ"),l1l11l_l1_ (u"ࠧࠨᑦ"),l1l11l_l1_ (u"ࠨࠩᑧ"),l1l11l_l1_ (u"ࠩࠪᑨ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩᑩ"))
		html = response.content
		# l11l11111_l1_ items
		if l11l11111_l1_==l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᑪ"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬᑫ"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᑬ"),block,re.DOTALL)
			#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᑭ"),l1l11l_l1_ (u"ࠨࠩᑮ"),l1l11l_l1_ (u"ࠩࠪᑯ"))
		# l1111ll11_l1_ l1l111l1_l1_
		elif l1l11l_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠪᑰ") in html:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ᑱ"),html,re.DOTALL)
		else:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪᑲ"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	if not items:
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᑳ"),block,re.DOTALL)
		if not items: items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᑴ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"ࠨ็ืห์ีษࠨᑵ"),l1l11l_l1_ (u"ࠩไ๎้๋ࠧᑶ"),l1l11l_l1_ (u"ࠪห฿์๊สࠩᑷ"),l1l11l_l1_ (u"่๊๊ࠫษࠩᑸ"),l1l11l_l1_ (u"ࠬอูๅษ้ࠫᑹ"),l1l11l_l1_ (u"࠭็ะษไࠫᑺ"),l1l11l_l1_ (u"ࠧๆสสีฬฯࠧᑻ"),l1l11l_l1_ (u"ࠨ฻ิฺࠬᑼ"),l1l11l_l1_ (u"่๋ࠩึาว็ࠩᑽ"),l1l11l_l1_ (u"ࠪห้ฮ่ๆࠩᑾ")]
	for l1111l_l1_,title,img in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠫ࠴࠭ᑿ"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨᒀ"),title,re.DOTALL)
		if l1l11l_l1_ (u"࠭ำๅษึ่ࠬᒁ") not in url and any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᒂ"),menu_name+title,l1111l_l1_,552,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠨษ็ั้่ษࠨᒃ") in title:
			title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᒄ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒅ"),menu_name+title,l1111l_l1_,553,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭ᒆ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒇ"),menu_name+title,l1111l_l1_,551,img)
		else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒈ"),menu_name+title,l1111l_l1_,553,img)
	if l11l11111_l1_==l1l11l_l1_ (u"ࠧࠨᒉ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࠬᒊ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᒋ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1111l_l1_==l1l11l_l1_ (u"ࠥࠦᒌ"): continue
				#title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"ࠫࠬᒍ"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒎ"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬᒏ")+title,l1111l_l1_,551)
	if l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧᒐ") in url or l1l11l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩᒑ") in url:
		if l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩᒒ") in url:
			url = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪᒓ"),l1l11l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᒔ"))+l1l11l_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃ࠲࠱ࠩᒕ")
		elif l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧᒖ") in url:
			url,offset = url.split(l1l11l_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩᒗ"))
			offset = int(offset)+20
			url = url+l1l11l_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪᒘ")+str(offset)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᒙ"),menu_name+l1l11l_l1_ (u"๋๋ࠪอใࠡษ็้ื๐ฯࠨᒚ"),url,551)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᒛ"),url,l1l11l_l1_ (u"ࠬ࠭ᒜ"),l1l11l_l1_ (u"࠭ࠧᒝ"),l1l11l_l1_ (u"ࠧࠨᒞ"),l1l11l_l1_ (u"ࠨࠩᒟ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᒠ"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࡃࡻࡖࡩࡷ࡯ࡥࡴࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᒡ"),html,re.DOTALL)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡲࡩࡴࡶ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨᒢ"),html,re.DOTALL)
	# l111l111l_l1_
	if l11111l1l_l1_ and l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧᒣ") not in url:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᒤ"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᒥ"),menu_name+title,l1111l_l1_,553,img)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠨࠤ࡬ࡱࡦ࡭ࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒦ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᒧ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#title = title.replace(l1l11l_l1_ (u"ࠪࡠࡳ࠭ᒨ"),l1l11l_l1_ (u"ࠫࠬᒩ")).strip(l1l11l_l1_ (u"ࠬࠦࠧᒪ"))
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᒫ"),menu_name+title,l1111l_l1_,552,img)
	return
def PLAY(url):
	url2 = url.replace(l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᒬ"),l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᒭ"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ᒮ"),l1l11l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ᒯ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᒰ"),url2,l1l11l_l1_ (u"ࠬ࠭ᒱ"),l1l11l_l1_ (u"࠭ࠧᒲ"),l1l11l_l1_ (u"ࠧࠨᒳ"),l1l11l_l1_ (u"ࠨࠩᒴ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᒵ"))
	html = response.content
	l111l11l1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧᒶ"))
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᒷ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1ll1lll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᒸ"),html,re.DOTALL)
		l1ll1lll_l1_ = l1ll1lll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨᒹ"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪᒺ"),l1l11l_l1_ (u"ࠨࠩᒻ")).strip(l1l11l_l1_ (u"ࠩࠣࠫᒼ"))
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭ᒽ")+server+l1l11l_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭ᒾ")+l1ll1lll_l1_+l1l11l_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭ᒿ")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᓀ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᓁ")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡧࡳࡼࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᓂ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᓃ"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᓄ")+name+l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᓅ")
			if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᓆ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᓇ")+l1111l_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬᓈ"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᓉ"),url)
	return
l1l11l_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡓࡐࡆ࡟࡟ࡐࡎࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࡩࡧࡴࡢࠢࡀࠤࢀ࠭ࡖࡪࡧࡺࠫ࠿࠷ࡽࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭࠺ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡕࡕࡓࡕࠩ࠯ࡹࡷࡲࠬࡥࡣࡷࡥ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟ࠍࠍࠨࠦࡷࡢࡶࡦ࡬ࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡼࡧࡴࡤࡪࡄࡶࡪࡧࡍࡢࡵࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡲࡩ࡯࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡩࡵ࡮ࡸ࡮ࡲࡥࡩ࠳ࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥ࠭ࡳࡸࡥࡱ࡯ࡴࡺ࠮࡯࡭ࡳࡱࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ࠭ࠪࡣࡤࡥ࡟ࠨ࠭ࡴࡹࡦࡲࡩࡵࡻࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠍࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯࠽࠾࠲࠽ࠤࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬอไาษห฻๊๊ࠥิࠢไ๎์ࠦแ๋ัํ์ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࠉࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡔࡑࡇ࡙ࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࠬࡼࡩࡥࡧࡲࠫ࠱ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢᓊ")
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠪࠫᓋ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠫࠬᓌ"): return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧᓍ"),l1l11l_l1_ (u"࠭࠭ࠨᓎ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩᓏ")+search+l1l11l_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧᓐ")
	l111l1_l1_(url)
	return
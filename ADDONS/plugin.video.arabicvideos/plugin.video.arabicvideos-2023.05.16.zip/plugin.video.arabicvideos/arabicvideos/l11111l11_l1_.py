# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫᓑ")
menu_name = l1l11l_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩᓒ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"๊ࠫ๎โฺ้ࠢฮๆ๊๊ไีࠪᓓ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l111l1_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l111ll_l1_(url)
	elif mode==494: results = l1l1l1ll1_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᓔ"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧᓕ"),l1l11l_l1_ (u"ࠧࠨᓖ"),l1l11l_l1_ (u"ࠨࠩᓗ"),l1l11l_l1_ (u"ࠩࠪᓘ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᓙ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᓚ"),html,re.DOTALL)
	l111l11l1_l1_ = l111l11l1_l1_[0].strip(l1l11l_l1_ (u"ࠬ࠵ࠧᓛ"))
	l111l11l1_l1_ = SERVER(l111l11l1_l1_,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪᓜ"))
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓝ"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᓞ"),l111l11l1_l1_,499,l1l11l_l1_ (u"ࠩࠪᓟ"),l1l11l_l1_ (u"ࠪࠫᓠ"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᓡ"))
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓢ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᓣ")+menu_name+l1l11l_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭ᓤ"),l111l11l1_l1_,491,l1l11l_l1_ (u"ࠨࠩᓥ"),l1l11l_l1_ (u"ࠩࠪᓦ"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᓧ"))
	#addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᓨ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓩ"),l1l11l_l1_ (u"࠭ࠧᓪ"),9999)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠡࡃ࡭ࡥࡽ࡯ࡦࡺࡈ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᓫ"),html,re.DOTALL)
	if l1ll1l1ll_l1_:
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡦࡪ࡮ࡷࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᓬ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title in l1llll1_l1_: continue
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡰ࡮ࡧ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬᓭ")+l1111l_l1_+l1l11l_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨᓮ")
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓯ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᓰ")+menu_name+title,l1111l_l1_,491)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᓱ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᓲ"),l1l11l_l1_ (u"ࠨࠩᓳ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓴ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᓵ")+menu_name+l1l11l_l1_ (u"ࠫศ็ไศ็ࠪᓶ"),l111l11l1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษไ่ฬ๋࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡧ࡫࡯ࡱࡪ࠵ࡦࡰࡴࡨ࡭࡬ࡴ࠭ࡩࡦ࠰หๆ๊วๆ࠯สะ๋ฮ้࠮࠴ࠪᓷ"),494,l1l11l_l1_ (u"࠭ࠧᓸ"),l1l11l_l1_ (u"ࠧࠨᓹ"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᓺ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓻ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᓼ")+menu_name+l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠬᓽ"),l111l11l1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰็ึุ่๊วห࠱่ืู้ไศฬ࠰หั์ศ๊ࠩᓾ"),494,l1l11l_l1_ (u"࠭ࠧᓿ"),l1l11l_l1_ (u"ࠧࠨᔀ"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᔁ"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᔂ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔃ"),l1l11l_l1_ (u"ࠫࠬᔄ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔅ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᔆ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠧ࠰ࠩᔇ"): continue
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᔈ") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1111l_l1_
		if title in l1llll1_l1_: continue
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔉ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᔊ")+menu_name+title,l1111l_l1_,491)
	return html
def l1l1l1ll1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬᔋ"),l1l11l_l1_ (u"ࠬ࠭ᔌ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᔍ"),url,l1l11l_l1_ (u"ࠧࠨᔎ"),l1l11l_l1_ (u"ࠨࠩᔏ"),l1l11l_l1_ (u"ࠩࠪᔐ"),l1l11l_l1_ (u"ࠪࠫᔑ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᔒ"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡦࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᔓ"),html,re.DOTALL)
	if l11111l1l_l1_:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᔔ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title in l1llll1_l1_: continue
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᔕ"),menu_name+title,l1111l_l1_,491)
	return
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"ࠨࠩᔖ")):
	items = []
	#l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭ᔗ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᔘ"),url,l1l11l_l1_ (u"ࠫࠬᔙ"),l1l11l_l1_ (u"ࠬ࠭ᔚ"),l1l11l_l1_ (u"࠭ࠧᔛ"),l1l11l_l1_ (u"ࠧࠨᔜ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᔝ"))
	html = response.content
	block = l1l11l_l1_ (u"ࠩࠪᔞ")
	if l1l11l_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨᔟ") in url: block = html
	elif l1l11l_l1_ (u"ࠫࡄࡹ࠽ࠨᔠ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡢ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࠦࡲࡧ࡮ࡪࡨࡨࡷࡹࠨࠧᔡ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᔢ"),block,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࠨ࡭ࡢࡰ࡬ࡪࡪࡹࡴࠣࠩᔣ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
	if not block: return
	#if not items: items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࡝࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡧࡵࡸࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᔤ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"ุ่ࠩฬํฯสࠩᔥ"),l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨᔦ"),l1l11l_l1_ (u"ࠫฬเๆ๋หࠪᔧ"),l1l11l_l1_ (u"ࠬษฺ็์ฬࠫᔨ"),l1l11l_l1_ (u"࠭ใๅ์หࠫᔩ"),l1l11l_l1_ (u"ࠧศ฻็ห๋࠭ᔪ"),l1l11l_l1_ (u"ࠨ้าหๆ࠭ᔫ"),l1l11l_l1_ (u"่ࠩฬฬืวสࠩᔬ"),l1l11l_l1_ (u"ࠪ฽ึ฼ࠧᔭ"),l1l11l_l1_ (u"๊ࠫํัอษ้ࠫᔮ"),l1l11l_l1_ (u"ࠬอไษ๊่ࠫᔯ"),l1l11l_l1_ (u"࠭ๅิำะ๎ฮ࠭ᔰ")]
	for l1111l_l1_,img,title in items:
		title = unescapeHTML(title)
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨᔱ"),title,re.DOTALL)
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫᔲ"),title,re.DOTALL)
		if not l1ll1ll_l1_ or any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᔳ"),menu_name+title,l1111l_l1_,492,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠪั้่ษࠨᔴ") in title:
			title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᔵ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔶ"),menu_name+title,l1111l_l1_,493,img)
				l1l1l11_l1_.append(title)
		else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔷ"),menu_name+title,l1111l_l1_,493,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᔸ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᔹ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠩสฺ่็อสࠢࠪᔺ"),l1l11l_l1_ (u"ࠪࠫᔻ"))
			if title!=l1l11l_l1_ (u"ࠫࠬᔼ"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔽ"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬᔾ")+title,l1111l_l1_,491)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᔿ"),url,l1l11l_l1_ (u"ࠨࠩᕀ"),l1l11l_l1_ (u"ࠩࠪᕁ"),l1l11l_l1_ (u"ࠪࠫᕂ"),l1l11l_l1_ (u"ࠫࠬᕃ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᕄ"))
	html = response.content
	url2 = re.findall(l1l11l_l1_ (u"࠭ࠢࡃࡷࡷࡸࡴࡴࡳࡃࡣࡵࡇࡴࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕅ"),html,re.DOTALL)
	if url2:
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᕆ"),url2,l1l11l_l1_ (u"ࠨࠩᕇ"),l1l11l_l1_ (u"ࠩࠪᕈ"),l1l11l_l1_ (u"ࠪࠫᕉ"),l1l11l_l1_ (u"ࠫࠬᕊ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ᕋ"))
		html = response.content
	img = re.findall(l1l11l_l1_ (u"࠭ࠢࡪ࡯ࡪ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᕌ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨᕍ"))
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᕎ"),html,re.DOTALL)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬᕏ"),html,re.DOTALL)
	# l111l111l_l1_
	if l11111l1l_l1_ and l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᕐ") not in url:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᕑ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕒ"),menu_name+title,l1111l_l1_,493,img)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡢ࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࠤࡥࡳࡽࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᕓ"),block,re.DOTALL)
		if items:
			for l1111l_l1_,img,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩᕔ"))
				addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᕕ"),menu_name+title,l1111l_l1_,492,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᕖ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᕗ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l11l_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬᕘ"),l1l11l_l1_ (u"ࠬ࠭ᕙ"))
				if title!=l1l11l_l1_ (u"࠭ࠧᕚ"): addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕛ"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧᕜ")+title,l1111l_l1_,491)
	return
def PLAY(url):
	url2 = url.strip(l1l11l_l1_ (u"ࠩ࠲ࠫᕝ"))+l1l11l_l1_ (u"ࠪ࠳ࡄࡼࡩࡦࡹࡀ࠵ࠬᕞ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᕟ"),url2,l1l11l_l1_ (u"ࠬ࠭ᕠ"),l1l11l_l1_ (u"࠭ࠧᕡ"),l1l11l_l1_ (u"ࠧࠨᕢ"),l1l11l_l1_ (u"ࠨࠩᕣ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᕤ"))
	html = response.content
	l1ll1l1l_l1_ = []
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧᕥ"))
	l1llllllll_l1_ = re.findall(l1l11l_l1_ (u"ࠦࡩࡧࡴࡢ࠼ࠣࠫࡶࡃࠨ࠯ࠬࡂ࠭ࠫࠨᕦ"),html,re.DOTALL)
	#if not l1llllllll_l1_: l1llllllll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࠨࡵࡪ࡬ࡷࡡ࠴ࡩࡥ࡞࠯࠴ࡡ࠲ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧᕧ"),html,re.DOTALL)
	l1llllllll_l1_ = l1llllllll_l1_[0]
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕨ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪᕩ"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪᕪ"))
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡰ࡮ࡧ࠳ࡸ࡫ࡲࡷࡧࡵࡷ࠴ࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࡁࡴࡁࠬᕫ")+l1llllllll_l1_+l1l11l_l1_ (u"ࠪࠪ࡮ࡃࠧᕬ")+l111111ll_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᕭ")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᕮ")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l11111l_l1_ l1l1l1111_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩ࡙ࡥࡳࡸࡨࡶࠧ࠴ࠪࡀࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᕯ"),html,re.DOTALL)
	if l1111l_l1_:
		title = l1l11l_l1_ (u"ࠧๆใู่ࠬᕰ")
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࡡࡢࠫᕱ")+title
		l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	#url2 = url.strip(l1l11l_l1_ (u"ࠩ࠲ࠫᕲ"))+l1l11l_l1_ (u"ࠪ࠳ࡄࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠽࠲ࠩᕳ")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᕴ"),url2,l1l11l_l1_ (u"ࠬ࠭ᕵ"),l1l11l_l1_ (u"࠭ࠧᕶ"),l1l11l_l1_ (u"ࠧࠨᕷ"),l1l11l_l1_ (u"ࠨࠩᕸ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ᕹ"))
	#html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᕺ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᕻ"),block,re.DOTALL)
		for title,l1111l_l1_ in items:
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧᕼ"))
			if l1l11l_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧᕽ") in l1111l_l1_: title2 = l1l11l_l1_ (u"ࠧࡠࡡัหฺ࠭ᕾ")
			else: title2 = l1l11l_l1_ (u"ࠨࠩᕿ")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᖀ")+title+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᖁ")+title2
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᖂ"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖃ"),url)
	return
def SEARCH(search,l111l11l1_l1_=l1l11l_l1_ (u"࠭ࠧᖄ")):
	if not l111l11l1_l1_: l111l11l1_l1_ = l11lll_l1_
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩᖅ"),l1l11l_l1_ (u"ࠨ࠭ࠪᖆ"))
	url = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵࡅࡳ࠾ࠩᖇ")+search
	l111l1_l1_(url)
	return
#   search is l1l1l11ll_l1_ l1l1lll11_l1_ in l111l1_l1_()
#   l11l11l_l1_://l11111111_l1_.l1111111l_l1_-l111111l1_l1_.l111111l1_l1_/?s=the+l1llllll1l_l1_
#   l11l11l_l1_://l11111111_l1_.l1111111l_l1_-l111111l1_l1_.l111111l1_l1_/search/the+l1llllll1l_l1_/
#   l11l11l_l1_://l11111111_l1_.l1111111l_l1_-l111111l1_l1_.l111111l1_l1_/index.l1lllllll1_l1_?s=the+l1llllll1l_l1_
#	l11l11l_l1_://l1111111l_l1_-l111111l1_l1_.io/index.l1lllllll1_l1_?s=the+l1llllll1l_l1_
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ⼬")
headers = {l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⼭"):l1l11l_l1_ (u"ࠪࠫ⼮")}
menu_name = l1l11l_l1_ (u"ࠫࡤࡓࡃࡎࡡࠪ⼯")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ⼰"),l1l11l_l1_ (u"࠭ࡷࡸࡧࠪ⼱")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l111l1_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l111ll_l1_(url,text)
	elif mode==364: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ⼲")+text)
	elif mode==365: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ⼳")+text)
	elif mode==366: results = l1l1l1ll1_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⼴"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ⼵"),l1l11l_l1_ (u"ࠫࠬ⼶"),False,l1l11l_l1_ (u"ࠬ࠭⼷"),l1l11l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⼸"))
	#hostname = response.headers[l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ⼹")]
	#hostname = hostname.strip(l1l11l_l1_ (u"ࠨ࠱ࠪ⼺"))
	#l111l11l1_l1_ = l11lll_l1_
	#url = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ⼻")
	#url = l111l11l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⼼"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ⼽"),l1l11l_l1_ (u"ࠬ࠭⼾"),l1l11l_l1_ (u"࠭ࠧ⼿"),l1l11l_l1_ (u"ࠧࠨ⽀"),l1l11l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⽁"))
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⽂"),menu_name+l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⽃"),l1l11l_l1_ (u"ࠫࠬ⽄"),8)
	#addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⽅"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⽆"),l1l11l_l1_ (u"ࠧࠨ⽇"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⽈"),menu_name+l1l11l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⽉"),l11lll_l1_,369,l1l11l_l1_ (u"ࠪࠫ⽊"),l1l11l_l1_ (u"ࠫࠬ⽋"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⽌"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⽍"),menu_name+l1l11l_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ⽎"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ⽏"),364)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽐"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭⽑"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ⽒"),365)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⽓"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⽔"),l1l11l_l1_ (u"ࠧࠨ⽕"),9999)
	#headers2 = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ⽖"):hostname,l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⽗"):l1l11l_l1_ (u"ࠪࠫ⽘")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l11l_l1_ (u"ࠫࡡ࠵ࠧ⽙"),l1l11l_l1_ (u"ࠬ࠵ࠧ⽚"))
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࡧࡧࡲࠩ࠰࠭ࡃ࠮࡬ࡩ࡭ࡶࡨࡶࠬ⽛"),html,re.DOTALL)
	#if l1ll111_l1_:
	#	block = l1ll111_l1_[0]
	#	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⽜"),block,re.DOTALL)
	#	for l1111l_l1_,title in items:
	#		if l1l11l_l1_ (u"ࠨࠧࡧ࠽ࠪ࠾࠵ࠦࡦ࠻ࠩࡧ࠻ࠥࡥ࠺ࠨࡥ࠼ࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡤ࠼ࠩࡩ࠾ࠥࡢ࠻࠰ࠩࡩ࠾ࠥࡢࡦࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡧ࠹ࠨ⽝") in l1111l_l1_: continue
	#		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽞"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⽟")+menu_name+title,l1111l_l1_,366)
	#	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⽠"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⽡"),l1l11l_l1_ (u"࠭ࠧ⽢"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ⽣"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ⽤"),l1l11l_l1_ (u"ࠩࠪ⽥"),l1l11l_l1_ (u"ࠪࠫ⽦"),l1l11l_l1_ (u"ࠫࠬ⽧"),l1l11l_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ⽨"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡵࡏ࡭ࡸࡺࡂࡶࡶࡷࡳࡳࠨࠧ⽩"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠲࡯ࡴࡦ࡯࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⽪"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭⽫") not in l1111l_l1_:
			#	server = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭⽬"))
			#	l1111l_l1_ = l1111l_l1_.replace(server,l111l11l1_l1_)
			if title==l1l11l_l1_ (u"ࠪࠫ⽭"): continue
			if any(value in title.lower() for value in l1llll1_l1_): continue
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⽮"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⽯")+menu_name+title,l1111l_l1_,366)
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⽰"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⽱"),l1l11l_l1_ (u"ࠨࠩ⽲"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠫ⽳"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⽴"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⽵"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⽶")+menu_name+title,l1111l_l1_,366,img)
	return html
def l1l1l1ll1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⽷"),l1l11l_l1_ (u"ࠧࠨ⽸"),url,l1l11l_l1_ (u"ࠨࠩ⽹"))
	#headers2 = {l1l11l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ⽺"):url,l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⽻"):l1l11l_l1_ (u"ࠫࠬ⽼")}
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⽽"),url,l1l11l_l1_ (u"࠭ࠧ⽾"),l1l11l_l1_ (u"ࠧࠨ⽿"),l1l11l_l1_ (u"ࠨࠩ⾀"),l1l11l_l1_ (u"ࠩࠪ⾁"),l1l11l_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⾂"))
	html = response.content
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾃"),menu_name+l1l11l_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ⾄"),url,364)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾅"),menu_name+l1l11l_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ⾆"),url,365)
	if l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ⾇") in html:
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⾈"),menu_name+l1l11l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ⾉"),url,361,l1l11l_l1_ (u"ࠫࠬ⾊"),l1l11l_l1_ (u"ࠬ࠭⾋"),l1l11l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⾌"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ⾍"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⾎"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⾏"),menu_name+title,l1111l_l1_,361)
	return
def l111l1_l1_(l1l1ll1l1l1_l1_,type=l1l11l_l1_ (u"ࠪࠫ⾐")):
	if l1l11l_l1_ (u"ࠫ࠿ࡀࠧ⾑") in l1l1ll1l1l1_l1_:
		url3,url = l1l1ll1l1l1_l1_.split(l1l11l_l1_ (u"ࠬࡀ࠺ࠨ⾒"))
		server = SERVER(url3,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ⾓"))
		url = server+url
	else: url,url3 = l1l1ll1l1l1_l1_,l1l1ll1l1l1_l1_
	#headers2 = {l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ⾔"):url3,l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ⾕"):l1l11l_l1_ (u"ࠩࠪ⾖")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⾗"),url,l1l11l_l1_ (u"ࠫࠬ⾘"),l1l11l_l1_ (u"ࠬ࠭⾙"),l1l11l_l1_ (u"࠭ࠧ⾚"),l1l11l_l1_ (u"ࠧࠨ⾛"),l1l11l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⾜"))
	html = response.content
	if type==l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ⾝"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ⾞"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⾟"):
		l1ll111_l1_ = [html.replace(l1l11l_l1_ (u"ࠬࡢ࡜࠰ࠩ⾠"),l1l11l_l1_ (u"࠭࠯ࠨ⾡")).replace(l1l11l_l1_ (u"ࠧ࡝࡞ࠥࠫ⾢"),l1l11l_l1_ (u"ࠨࠤࠪ⾣"))]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡊࡶ࡮ࡪ࠭࠮ࡏࡼࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭⾤"),html,re.DOTALL)
	l1l1l11_l1_ = []
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡋࡷ࡯ࡤࡊࡶࡨࡱࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ⾥"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			if any(value in title.lower() for value in l1llll1_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l11l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ⾦"),l1l11l_l1_ (u"ࠬ࠭⾧"))
			if l1l11l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⾨") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⾩"),menu_name+title,l1111l_l1_,363,img)
			elif l1l11l_l1_ (u"ࠨฯ็ๆฮ࠭⾪") in title:
				l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ⾫"),title,re.DOTALL)
				if l1ll1ll_l1_: title = l1l11l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⾬") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					l1l1l11_l1_.append(title)
					addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾭"),menu_name+title,l1111l_l1_,363,img)
			else:
				addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⾮"),menu_name+title,l1111l_l1_,362,img)
		if type==l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⾯"):
			l1lllllll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ⾰"),block,re.DOTALL)
			if l1lllllll1l_l1_:
				count = l1lllllll1l_l1_[0]
				l1111l_l1_ = url+l1l11l_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ⾱")+count
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⾲"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡลัี๎࠭⾳"),l1111l_l1_,361,l1l11l_l1_ (u"ࠫࠬ⾴"),l1l11l_l1_ (u"ࠬ࠭⾵"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⾶"))
		elif type==l1l11l_l1_ (u"ࠧࠨ⾷"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⾸"),html,re.DOTALL)
			if l1ll111_l1_:
				block = l1ll111_l1_[0]
				items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⾹"),block,re.DOTALL)
				for l1111l_l1_,title in items:
					title = l1l11l_l1_ (u"ูࠪๆำษࠡࠩ⾺")+unescapeHTML(title)
					addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾻"),menu_name+title,l1111l_l1_,361)
	return
def l111ll_l1_(url,type=l1l11l_l1_ (u"ࠬ࠭⾼")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ⾽"),url,l1l11l_l1_ (u"ࠧࠨ⾾"),l1l11l_l1_ (u"ࠨࠩ⾿"),l1l11l_l1_ (u"ࠩࠪ⿀"),l1l11l_l1_ (u"ࠪࠫ⿁"),l1l11l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⿂"))
	html = response.content
	html = UNQUOTE(html)
	name = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣ࡫ࡷࡩࡲࠨࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࡁ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠬ࠳࠰࠿ࠪࠤࠪ⿃"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l11l_l1_ (u"࠭࠭ࠨ⿄"),l1l11l_l1_ (u"ࠧࠡࠩ⿅")).strip(l1l11l_l1_ (u"ࠨ࠱ࠪ⿆"))
	if l1l11l_l1_ (u"่ࠩ์ุ๋ࠧ⿇") in name and type==l1l11l_l1_ (u"ࠪࠫ⿈"):
		name = name.split(l1l11l_l1_ (u"๊ࠫ๎ำๆࠩ⿉"))[0]
		name = name.replace(l1l11l_l1_ (u"๋ࠬิศ้าอࠬ⿊"),l1l11l_l1_ (u"࠭ࠧ⿋")).strip(l1l11l_l1_ (u"ࠧࠡࠩ⿌"))
	elif l1l11l_l1_ (u"ࠨฯ็ๆฮ࠭⿍") in name:
		name = name.split(l1l11l_l1_ (u"ࠩะ่็ฯࠧ⿎"))[0]
		name = name.replace(l1l11l_l1_ (u"ู้ࠪอ็ะหࠪ⿏"),l1l11l_l1_ (u"ࠫࠬ⿐")).strip(l1l11l_l1_ (u"ࠬࠦࠧ⿑"))
	else: name = name
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷ࡮ࡴࡧ࡭ࡧࡶࡩࡨࡺࡩࡰࡰࠪ⿒"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		if type==l1l11l_l1_ (u"ࠧࠨ⿓"):
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⿔"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳࠨ⿕") in title: continue
				if l1l11l_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࠫ⿖") in title: continue
				title = name+l1l11l_l1_ (u"ࠫࠥ࠳ࠠࠨ⿗")+title
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿘"),menu_name+title,l1111l_l1_,363,l1l11l_l1_ (u"࠭ࠧ⿙"),l1l11l_l1_ (u"ࠧࠨ⿚"),l1l11l_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⿛"))
		if len(menuItemsLIST)==0:
			l1l11l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠱࠲࡙ࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩࠧࠨࠪ⿜"),block+l1l11l_l1_ (u"ࠪࠪࠫ࠭⿝"),re.DOTALL)
			if l1l11l1l_l1_: block = l1l11l1l_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ⿞"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ⿟"))
				title = name+l1l11l_l1_ (u"࠭ࠠ࠮ࠢࠪ⿠")+title
				addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⿡"),menu_name+title,l1111l_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⿢"),html,re.DOTALL)
		if title: title = title[0].replace(l1l11l_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ⿣"),l1l11l_l1_ (u"ࠪࠫ⿤")).replace(l1l11l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ⿥"),l1l11l_l1_ (u"ࠬ࠭⿦"))
		else: title = l1l11l_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ⿧")
		addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⿨"),menu_name+title,url,362)
	return
def PLAY(url):
	l1ll1l1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⿩"),url,l1l11l_l1_ (u"ࠩࠪ⿪"),l1l11l_l1_ (u"ࠪࠫ⿫"),l1l11l_l1_ (u"ࠫࠬ⿬"),l1l11l_l1_ (u"ࠬ࠭⿭"),l1l11l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⿮"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⿯"),html,re.DOTALL)
	if l1l1l_l1_:
		l1l1l_l1_ = [l1l1l_l1_[0][0],l1l1l_l1_[0][1]]
		if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ⿰"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⿱"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⿲") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if name==l1l11l_l1_ (u"ุࠫ๐ัโำ้ࠣฬ๐ࠠิ์่หࠬ⿳"): name = l1l11l_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ⿴")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⿵")+name+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⿶")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⿷"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⿸"),block,re.DOTALL)
		for l1111l_l1_,l1l1l111_l1_ in items:
			if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⿹") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ⿺"),l1l1l111_l1_,re.DOTALL)
			if l1l1l111_l1_: l1l1l111_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ⿻")+l1l1l111_l1_[0]
			else: l1l1l111_l1_ = l1l11l_l1_ (u"࠭ࠧ⿼")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽࡮ࡻࡦ࡭ࡲࡧࠧ⿽")+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⿾")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⿿"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ　"),url)
	return
def SEARCH(search,hostname=l1l11l_l1_ (u"ࠫࠬ、")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭。"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧ〃"): return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩ〄"),l1l11l_l1_ (u"ࠨ࠭ࠪ々"))
	l1ll1l1l_l1_ = [l1l11l_l1_ (u"ࠩ࠲ࠫ〆"),l1l11l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ〇"),l1l11l_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ〈"),l1l11l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ〉"),l1l11l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ《")]
	l1lll1l11ll_l1_ = [l1l11l_l1_ (u"ࠧศๆฦๅ้อๅࠨ》"),l1l11l_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ「"),l1l11l_l1_ (u"ࠩส่ฬ์๊ๆ์ࠣ์ࠥอไไำอ์๋࠭」"),l1l11l_l1_ (u"ࠪห้ฮัศ็ฯࠤฯ๊๊โิํ์๋๐ษࠨ『"),l1l11l_l1_ (u"ࠫ฿๐ัࠡ็ะำิ࠭』")]
	if showdialogs:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ【"), l1lll1l11ll_l1_)
		if selection==-1: return
	else: selection = 4
	if hostname==l1l11l_l1_ (u"࠭ࠧ】"):
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ〒"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ〓"),l1l11l_l1_ (u"ࠩࠪ〔"),False,l1l11l_l1_ (u"ࠪࠫ〕"),l1l11l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ〖"))
		hostname = response.headers[l1l11l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ〗")]
		hostname = hostname.strip(l1l11l_l1_ (u"࠭࠯ࠨ〘"))
	url2 = hostname+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ〙")+search+l1ll1l1l_l1_[selection]
	l111l1_l1_(url2)
	return
def l1l1l1l_l1_(l1l1ll1l1l1_l1_,filter):
	if l1l11l_l1_ (u"ࠨࡁࡂࠫ〚") in l1l1ll1l1l1_l1_: url = l1l1ll1l1l1_l1_.split(l1l11l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ〛"))[0]
	else: url = l1l1ll1l1l1_l1_
	#headers2 = {l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ〜"):l1l1ll1l1l1_l1_,l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ〝"):l1l11l_l1_ (u"ࠬ࠭〞")}
	filter = filter.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ〟"),l1l11l_l1_ (u"ࠧࠨ〠"))
	type,filter = filter.split(l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ〡"),1)
	if filter==l1l11l_l1_ (u"ࠩࠪ〢"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠪࠫ〣"),l1l11l_l1_ (u"ࠫࠬ〤")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ〥"))
	if type==l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ〦"):
		if l1ll11ll1_l1_[0]+l1l11l_l1_ (u"ࠧ࠾࠿ࠪ〧") not in l1lllll1_l1_: category = l1ll11ll1_l1_[0]
		for i in range(len(l1ll11ll1_l1_[0:-1])):
			if l1ll11ll1_l1_[i]+l1l11l_l1_ (u"ࠨ࠿ࡀࠫ〨") in l1lllll1_l1_: category = l1ll11ll1_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬ〩")+category+l1l11l_l1_ (u"ࠪࡁࡂ࠶〪ࠧ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"〫ࠫࠫࠬࠧ")+category+l1l11l_l1_ (u"ࠬࡃ࠽࠱ࠩ〬")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"〭࠭ࠦࠧࠩ"))+l1l11l_l1_ (u"ࠧࡠࡡࡢ〮ࠫ")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠨࠨ〯ࠩࠫ"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ〰"))
		url2 = url+l1l11l_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ〱")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ〲"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ〳"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"࠭ࠧ〴"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ〵"))
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠨࠩ〶"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ〷")+l1llll1l_l1_
		l11l1ll1_l1_ = l1l1l11l1_l1_(url2,l1l1ll1l1l1_l1_)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ〸"),menu_name+l1l11l_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ〹"),l11l1ll1_l1_,361,l1l11l_l1_ (u"ࠬ࠭〺"),l1l11l_l1_ (u"࠭ࠧ〻"),l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ〼"))
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ〽"),menu_name+l1l11l_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ〾")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ〿"),l11l1ll1_l1_,361,l1l11l_l1_ (u"ࠫࠬ぀"),l1l11l_l1_ (u"ࠬ࠭ぁ"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧあ"))
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬぃ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨい"),l1l11l_l1_ (u"ࠩࠪぅ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧう"),url,l1l11l_l1_ (u"ࠫࠬぇ"),l1l11l_l1_ (u"ࠬ࠭え"),l1l11l_l1_ (u"࠭ࠧぉ"),l1l11l_l1_ (u"ࠧࠨお"),l1l11l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫか"))
	html = response.content
	html = html.replace(l1l11l_l1_ (u"ࠩ࡟ࡠࠧ࠭が"),l1l11l_l1_ (u"ࠪࠦࠬき")).replace(l1l11l_l1_ (u"ࠫࡡࡢ࠯ࠨぎ"),l1l11l_l1_ (u"ࠬ࠵ࠧく"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼࡮ࡻࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯࡮ࡻࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩぐ"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬけ"),block+l1l11l_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬげ"),re.DOTALL)
	dict = {}
	for l1l111l_l1_,name,block in l1l1ll1_l1_:
		name = escapeUNICODE(name)
		if l1l11l_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫこ") in l1l111l_l1_: continue
		items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬご"),block,re.DOTALL)
		if l1l11l_l1_ (u"ࠫࡂࡃࠧさ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩざ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l1ll11ll1_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭し")+l1111l1_l1_)
				return
			else:
				l11l1ll1_l1_ = l1l1l11l1_l1_(url2,l1l1ll1l1l1_l1_)
				if l1l111l_l1_==l1ll11ll1_l1_[-1]:
					addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧじ"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ูࠨす"),l11l1ll1_l1_,361,l1l11l_l1_ (u"ࠩࠪず"),l1l11l_l1_ (u"ࠪࠫせ"),l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬぜ"))
				else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬそ"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾࠭ぞ"),url2,364,l1l11l_l1_ (u"ࠧࠨた"),l1l11l_l1_ (u"ࠨࠩだ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪち"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭ぢ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂࡃ࠰ࠨっ")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨつ")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽࠾࠲ࠪづ")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫて")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨで"),menu_name+name+l1l11l_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫと"),url2,365,l1l11l_l1_ (u"ࠪࠫど"),l1l11l_l1_ (u"ࠫࠬな"),l1111l1_l1_+l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧに"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l11l_l1_ (u"࠭ࡲࠨぬ") or value==l1l11l_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭ね"): continue
			if any(value in option.lower() for value in l1llll1_l1_): continue
			if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭の") in option: continue
			if l1l11l_l1_ (u"ࠩส่่๊ࠧは") in option: continue
			if l1l11l_l1_ (u"ࠪࡲ࠲ࡧࠧば") in value: continue
			#if value in [l1l11l_l1_ (u"ࠫࡷ࠭ぱ"),l1l11l_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫひ"),l1l11l_l1_ (u"࠭ࡴࡷ࠯ࡰࡥࠬび")]: continue
			#if l1l111l_l1_==l1l11l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ぴ"): option = value
			if option==l1l11l_l1_ (u"ࠨࠩふ"): option = value
			l1l11lll1_l1_ = option
			name1 = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧぶ"),option,re.DOTALL)
			if name1: l1l11lll1_l1_ = name1[0]
			title2 = name+l1l11l_l1_ (u"ࠪ࠾ࠥ࠭ぷ")+l1l11lll1_l1_
			dict[l1l111l_l1_][value] = title2
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠫࠫࠬࠧへ")+l1l111l_l1_+l1l11l_l1_ (u"ࠬࡃ࠽ࠨべ")+l1l11lll1_l1_
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"࠭ࠦࠧࠩぺ")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾࠿ࠪほ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬぼ")+l11l111_l1_
			if type==l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪぽ"):
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪま"),menu_name+title2,url,365,l1l11l_l1_ (u"ࠫࠬみ"),l1l11l_l1_ (u"ࠬ࠭む"),l1l1111_l1_+l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨめ"))
			elif type==l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫも") and l1ll11ll1_l1_[-2]+l1l11l_l1_ (u"ࠨ࠿ࡀࠫゃ") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬや"))
				#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫゅ"),l1l11l_l1_ (u"ࠫࠬゆ"),l1lll1l1_l1_,l11l111_l1_)
				url3 = url+l1l11l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫょ")+l1lll1l1_l1_
				l11l1ll1_l1_ = l1l1l11l1_l1_(url3,l1l1ll1l1l1_l1_)
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭よ"),menu_name+title2,l11l1ll1_l1_,361,l1l11l_l1_ (u"ࠧࠨら"),l1l11l_l1_ (u"ࠨࠩり"),l1l11l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪる"))
			else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪれ"),menu_name+title2,url,364,l1l11l_l1_ (u"ࠫࠬろ"),l1l11l_l1_ (u"ࠬ࠭ゎ"),l1l1111_l1_)
	return
l1ll11ll1_l1_ = [l1l11l_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬわ"),l1l11l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ゐ"),l1l11l_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨゑ")]
l1ll111l1_l1_ = [l1l11l_l1_ (u"ࠩࡰࡴࡦࡧࠧを"),l1l11l_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩん"),l1l11l_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪゔ"),l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧゕ"),l1l11l_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧゖ"),l1l11l_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ゗"),l1l11l_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ゘"),l1l11l_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨ゙ࠫ")]
def l1l1l11l1_l1_(url2,url3):
	if l1l11l_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴ゚ࠪ") in url2: url2 = url2.replace(l1l11l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ゛"),l1l11l_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠭゜"))
	url2 = url2.replace(l1l11l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬゝ"),l1l11l_l1_ (u"ࠧ࠻࠼࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩ࠲ࠫゞ"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠨ࠿ࡀࠫゟ"),l1l11l_l1_ (u"ࠩ࠲ࠫ゠"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠪࠪࠫ࠭ァ"),l1l11l_l1_ (u"ࠫ࠴࠭ア"))
	return url2
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ィ"),l1l11l_l1_ (u"࠭ࠧイ"),filters,l1l11l_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧゥ")+mode)
	# mode==l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪウ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬェ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠪࡥࡱࡲࠧエ")					all filters (l1lll111_l1_ l111l1l_l1_ filter)
	filters = filters.strip(l1l11l_l1_ (u"ࠫࠫࠬࠧォ"))
	l1llllll_l1_,l11llll_l1_ = {},l1l11l_l1_ (u"ࠬ࠭オ")
	if l1l11l_l1_ (u"࠭࠽࠾ࠩカ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠧࠧࠨࠪガ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠨ࠿ࡀࠫキ"))
			l1llllll_l1_[var] = value
	for key in l1ll111l1_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠩ࠳ࠫギ")
		if l1l11l_l1_ (u"ࠪࠩࠬク") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭グ") and value!=l1l11l_l1_ (u"ࠬ࠶ࠧケ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠠࠬࠢࠪゲ")+value
		elif mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪコ") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪゴ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬサ")+key+l1l11l_l1_ (u"ࠪࡁࡂ࠭ザ")+value
		elif mode==l1l11l_l1_ (u"ࠫࡦࡲ࡬ࠨシ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨジ")+key+l1l11l_l1_ (u"࠭࠽࠾ࠩス")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠡ࠭ࠣࠫズ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠩࠫセ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪゼ"),l1l11l_l1_ (u"ࠪࠫソ"),l11llll_l1_,l1l11l_l1_ (u"ࠫࡔ࡛ࡔࠨゾ"))
	return l11llll_l1_
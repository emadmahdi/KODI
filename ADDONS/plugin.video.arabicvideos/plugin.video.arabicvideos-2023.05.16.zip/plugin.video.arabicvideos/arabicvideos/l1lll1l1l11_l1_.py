# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ♀")
menu_name = l1l11l_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭♁")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨ็ุหึ฿ษࠨ♂"),l1l11l_l1_ (u"ࠩสัิัࠠศๆหีฬ๋ฬࠨ♃"),l1l11l_l1_ (u"ࠪหาีหࠡษ็ห้฿วษࠩ♄"),l1l11l_l1_ (u"ࠫฬำฯฬࠢส่ฬเว็๋ࠪ♅")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l111l1_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l111ll_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ♆"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ♇"),l1l11l_l1_ (u"ࠧࠨ♈"),l1l11l_l1_ (u"ࠨࠩ♉"),l1l11l_l1_ (u"ࠩࠪ♊"),l1l11l_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ♋"))
	html = response.content
	l111l11l1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ♌"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♍"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭♎"),l1l11l_l1_ (u"ࠧࠨ♏"),89,l1l11l_l1_ (u"ࠨࠩ♐"),l1l11l_l1_ (u"ࠩࠪ♑"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ♒"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♓"),menu_name+l1l11l_l1_ (u"ࠬอฮหำ้ห๊ࠥใࠨ♔"),l111l11l1_l1_,81,l1l11l_l1_ (u"࠭ࠧ♕"),l1l11l_l1_ (u"ࠧࠨ♖"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ♗"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ♘"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭♙"),block,re.DOTALL)
	for l11l11111_l1_,title in items:
		l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࡃ࡮ࡺࡥ࡮࠿ࠪ♚")+l11l11111_l1_+l1l11l_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭♛")
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♜"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ♝")+menu_name+title,l1111l_l1_,81)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭♞"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ♟"),l1l11l_l1_ (u"ࠪࠫ♠"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡴࡡࡷ࠯ࡰࡥ࡮ࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡹࡂࠬ♡"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ♢"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"࠭ࠣࠨ♣"): continue
		if title in l1llll1_l1_: continue
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ♤"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ♥")+menu_name+title,l1111l_l1_,81)
	return
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"ࠩࠪ♦")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ♧"),l1l11l_l1_ (u"ࠫࠬ♨"),url)
	items = []
	# l11111lll_l1_ l1111l111_l1_
	if l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬ♩") in url or l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧ♪") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭♫"):l1l11l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ♬")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ♭"),url2,data2,headers2,l1l11l_l1_ (u"ࠪࠫ♮"),l1l11l_l1_ (u"ࠫࠬ♯"),l1l11l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ♰"))
		html = response.content
		l1ll111_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ♱"),url,l1l11l_l1_ (u"ࠧࠨ♲"),l1l11l_l1_ (u"ࠨࠩ♳"),l1l11l_l1_ (u"ࠩࠪ♴"),l1l11l_l1_ (u"ࠪࠫ♵"),l1l11l_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ♶"))
		html = response.content
		# l11l11111_l1_ items
		if l11l11111_l1_==l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ♷"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭♸"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭♹"),block,re.DOTALL)
			#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ♺"),l1l11l_l1_ (u"ࠩࠪ♻"),l1l11l_l1_ (u"ࠪࠫ♼"))
		# l1111ll11_l1_ l1l111l1_l1_
		elif l1l11l_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠫ♽") in html:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡱࡱࡶࡸࠥࡳࡢ࠮࠳࠳ࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ♾"),html,re.DOTALL)
		else:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ♿"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	if not items:
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳࡯ࡳ࡫ࡪ࡭ࡳࡧ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⚀"),block,re.DOTALL)
		if not items: items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⚁"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"ุ่ࠩฬํฯสࠩ⚂"),l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨ⚃"),l1l11l_l1_ (u"ࠫฬเๆ๋หࠪ⚄"),l1l11l_l1_ (u"้ࠬไ๋สࠪ⚅"),l1l11l_l1_ (u"࠭วฺๆส๊ࠬ⚆"),l1l11l_l1_ (u"่ࠧัสๅࠬ⚇"),l1l11l_l1_ (u"ࠨ็หหึอษࠨ⚈"),l1l11l_l1_ (u"ࠩ฼ี฻࠭⚉"),l1l11l_l1_ (u"้ࠪ์ืฬศ่ࠪ⚊"),l1l11l_l1_ (u"ࠫฬ๊ศ้็ࠪ⚋")]
	for l1111l_l1_,title,img in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠬ࠵ࠧ⚌"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ⚍"),title,re.DOTALL)
		if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⚎") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚏"),menu_name+title,l1111l_l1_,83,img)
		elif l1l11l_l1_ (u"ࠩึ่ฬูไࠨ⚐") not in url and any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⚑"),menu_name+title,l1111l_l1_,82,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠫฬ๊อๅไฬࠫ⚒") in title:
			title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⚓") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⚔"),menu_name+title,l1111l_l1_,83,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ⚕") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚖"),menu_name+title,l1111l_l1_,81,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⚗"),menu_name+title,l1111l_l1_,83,img)
	if l11l11111_l1_==l1l11l_l1_ (u"ࠪࠫ⚘"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲࠨ⚙"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⚚"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1111l_l1_==l1l11l_l1_ (u"ࠨࠢ⚛"): continue
				#title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"ࠧࠨ⚜"): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚝"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨ⚞")+title,l1111l_l1_,81)
	if l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪ⚟") in url or l1l11l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬ⚠") in url:
		if l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬ⚡") in url:
			url = url.replace(l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭⚢"),l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ⚣"))+l1l11l_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿࠵࠴ࠬ⚤")
		elif l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪ⚥") in url:
			url,offset = url.split(l1l11l_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬ⚦"))
			offset = int(offset)+20
			url = url+l1l11l_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠭⚧")+str(offset)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚨"),menu_name+l1l11l_l1_ (u"࠭็็ษๆࠤฬ๊ๅำ์าࠫ⚩"),url,81)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ⚪"),url,l1l11l_l1_ (u"ࠨࠩ⚫"),l1l11l_l1_ (u"ࠩࠪ⚬"),l1l11l_l1_ (u"ࠪࠫ⚭"),l1l11l_l1_ (u"ࠫࠬ⚮"),l1l11l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⚯"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࡆࡾ࡙ࡥࡳ࡫ࡨࡷ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⚰"),html,re.DOTALL)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⚱"),html,re.DOTALL)
	# l111l111l_l1_
	if l11111l1l_l1_ and l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⚲") not in url:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⚳"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚴"),menu_name+title,l1111l_l1_,83,img)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠫࠧ࡯࡭ࡢࡩࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⚵"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⚶"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#title = title.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩ⚷"),l1l11l_l1_ (u"ࠧࠨ⚸")).strip(l1l11l_l1_ (u"ࠨࠢࠪ⚹"))
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⚺"),menu_name+title,l1111l_l1_,82,img)
	return
def PLAY(url):
	url2 = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ⚻"),l1l11l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡲࡵࡶࡪࡧࡶ࠳ࠬ⚼"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⚽"),l1l11l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⚾"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ⚿"),url2,l1l11l_l1_ (u"ࠨࠩ⛀"),l1l11l_l1_ (u"ࠩࠪ⛁"),l1l11l_l1_ (u"ࠪࠫ⛂"),l1l11l_l1_ (u"ࠫࠬ⛃"),l1l11l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⛄"))
	html = response.content
	l111l11l1_l1_ = SERVER(url2,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ⛅"))
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⛆"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1ll1lll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ⛇"),html,re.DOTALL)
		l1ll1lll_l1_ = l1ll1lll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠤࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ⛈"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠪࡠࡳ࠭⛉"),l1l11l_l1_ (u"ࠫࠬ⛊")).strip(l1l11l_l1_ (u"ࠬࠦࠧ⛋"))
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩ⛌")+server+l1l11l_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩ⛍")+l1ll1lll_l1_+l1l11l_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ⛎")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⛏")+title+l1l11l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⛐")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⛑"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⛒"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⛓")+name+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⛔")
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭⛕"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⛖"),url)
	return
l1l11l_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡔࡑࡇ࡙ࡠࡑࡏࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࡪࡡࡵࡣࠣࡁࠥࢁࠧࡗ࡫ࡨࡻࠬࡀ࠱ࡾࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ࠻ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨࡿࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡖࡏࡔࡖࠪ࠰ࡺࡸ࡬࠭ࡦࡤࡸࡦ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠࠎࠎࠩࠠࡸࡣࡷࡧ࡭ࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡽࡡࡵࡥ࡫ࡅࡷ࡫ࡡࡎࡣࡶࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡼࡧࡴࡤࡪࠪࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠦࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡪ࡯࡯ࡹ࡯ࡳࡦࡪ࠭ࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡵࡨࡶ࠲ࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡸ࡮ࡺ࡬ࡦ࠮ࡴࡹࡦࡲࡩࡵࡻ࠯ࡰ࡮ࡴ࡫ࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ࠮ࠫࡤࡥ࡟ࡠࠩ࠮ࡵࡺࡧ࡬ࡪࡶࡼࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠬࠎࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩ࠾࠿࠳࠾ࠥࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࠱࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ํࠠโ์า๎ํ࠭ࠩࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࠊࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠱࠭ࡶࡪࡦࡨࡳࠬ࠲ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠨࠢࠣ⛗")
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬ⛘"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭⛙"): return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ⛚"),l1l11l_l1_ (u"ࠧ࠮ࠩ⛛"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⛜")+search+l1l11l_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ⛝")
	l111l1_l1_(url)
	return
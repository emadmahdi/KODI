# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㍻")
#l11l111ll1l_l1_ = [ l1l11l_l1_ (u"࠭࡭ࡺࡵࡷࡶࡪࡧ࡭ࠨ㍼"),l1l11l_l1_ (u"ࠧࡷ࡫ࡰࡴࡱ࡫ࠧ㍽"),l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡧࡵ࡭ࠨ㍾"),l1l11l_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ㍿") ]
l11l111ll1l_l1_ = []
headers = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㎀"):l1l11l_l1_ (u"ࠫࠬ㎁")}
def l1l_l1_(l1lllll_l1_,source,type,url):
	#DIALOG_SELECT(l1l11l_l1_ (u"ࠬษฮหำࠣห้ืวษูࠣห้๋ๆศีหࠫ㎂"),l1lllll_l1_)
	if not l1lllll_l1_:
		LOG_THIS(l1l11l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㎃"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ㎄")+source+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩ㎅")+type+l1l11l_l1_ (u"ࠩࠣࡡࠬ㎆"))
		l11ll11ll11_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㎇"),l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㎈"),l1l11l_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ㎉"))
		datetime = time.strftime(l1l11l_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧ㎊"),time.gmtime(now))
		line = datetime,url
		key = source+l1l11l_l1_ (u"ࠧࠡࠢࠣࠤࠬ㎋")+addon_version+l1l11l_l1_ (u"ࠨࠢࠣࠤࠥ࠭㎌")+str(kodi_version)
		if key not in list(l11ll11ll11_l1_.keys()): l11ll11ll11_l1_[key] = [line]
		else: l11ll11ll11_l1_[key].append(line)
		total = 0
		for key in list(l11ll11ll11_l1_.keys()):
			l11ll11ll11_l1_[key] = list(set(l11ll11ll11_l1_[key]))
			total += len(l11ll11ll11_l1_[key])
		DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㎍"),l1l11l_l1_ (u"ࠪࠫ㎎"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㎏"),l1l11l_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํࠦ࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠹ࠣๅ๏ี๊้้สฮࠬ㎐")+l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࠫ㎑")+l1l11l_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪ㎒")+str(total))
		if total>=7:
			yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࠩ㎓"),l1l11l_l1_ (u"ࠩࠪ㎔"),l1l11l_l1_ (u"ࠪࠫ㎕"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㎖"),l1l11l_l1_ (u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠹ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭㎗"))
			if yes==1:
				l11ll11lll1_l1_ = l1l11l_l1_ (u"࠭ࠧ㎘")
				for key in list(l11ll11ll11_l1_.keys()):
					l11ll11lll1_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㎙")+key
					l1llllll1lll_l1_ = sorted(l11ll11ll11_l1_[key],reverse=False,key=lambda l111ll1ll1l_l1_: l111ll1ll1l_l1_[0])
					for datetime,url in l1llllll1lll_l1_:
						l11ll11lll1_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㎚")+datetime+l1l11l_l1_ (u"ࠩࠣࠤࠥࠦࠧ㎛")+UNQUOTE(url)
					l11ll11lll1_l1_ += l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㎜")
				import l1llll1lllll_l1_
				l111l11l1ll_l1_ = l1l11l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ㎝")+l1ll1l1l11l_l1_(32)+l1l11l_l1_ (u"ࠬ࠳ࡖࡪࡦࡨࡳࡸ࠭㎞")
				succeeded = l1llll1lllll_l1_.l11ll1llll1_l1_(l111l11l1ll_l1_,l1l11l_l1_ (u"࠭ࠧ㎟"),False,l1l11l_l1_ (u"ࠧࠨ㎠"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㎡"),l1l11l_l1_ (u"ࠩࠪ㎢"),l11ll11lll1_l1_)
				if succeeded: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㎣"),l1l11l_l1_ (u"ࠫࠬ㎤"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㎥"),l1l11l_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ㎦"))
				else: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㎧"),l1l11l_l1_ (u"ࠨࠩ㎨"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㎩"),l1l11l_l1_ (u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨ㎪"))
			if yes!=-1:
				l11ll11ll11_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㎫"),l1l11l_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ㎬"))
		if l11ll11ll11_l1_: WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㎭"),l1l11l_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭㎮"),l11ll11ll11_l1_,PERMANENT_CACHE)
		return
	l1lllll_l1_ = list(set(l1lllll_l1_))
	l1l1lll_l1_,l1ll1l1l_l1_ = l111111lll1_l1_(l1lllll_l1_,source)
	l1llllll1l1l_l1_ = str(l1ll1l1l_l1_).count(l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㎯"))
	l11111l111l_l1_ = str(l1ll1l1l_l1_).count(l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㎰"))
	l1lllllll11l_l1_ = len(l1ll1l1l_l1_)-l1llllll1l1l_l1_-l11111l111l_l1_
	l11111ll1l1_l1_ = l1l11l_l1_ (u"ู้ࠪอ็ะห࠽ࠫ㎱")+str(l1llllll1l1l_l1_)+l1l11l_l1_ (u"ࠫࠥࠦࠠࠡฬะ้๏๊࠺ࠨ㎲")+str(l11111l111l_l1_)+l1l11l_l1_ (u"ࠬࠦࠠࠡࠢฦาึ๏࠺ࠨ㎳")+str(l1lllllll11l_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㎴"),l1l11l_l1_ (u"ࠧࠨ㎵"),str(l1llllll1l1l_l1_),str(l11111l111l_l1_))
	#selection = DIALOG_SELECT(l11111ll1l1_l1_, l1ll1l1l_l1_)
	if not l1ll1l1l_l1_:
		result = l1l11l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㎶")
		l1l111l11l1_l1_ = l1l11l_l1_ (u"ࠩࠪ㎷")
	else:
		while True:
			l1l111l11l1_l1_ = l1l11l_l1_ (u"ࠪࠫ㎸")
			if len(l1ll1l1l_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l11111ll1l1_l1_,l1l1lll_l1_)
			if selection==-1: result = l1l11l_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ㎹")
			else:
				title = l1l1lll_l1_[selection]
				l1111l_l1_ = l1ll1l1l_l1_[selection]
				#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㎺"),l1l11l_l1_ (u"࠭ࠧ㎻"),title,l1111l_l1_)
				if l1l11l_l1_ (u"ࠧิ์ิๅึ࠭㎼") in title and l1l11l_l1_ (u"ࠨ࠴่ะ์๎ไ࠳ࠩ㎽") in title:
					LOG_THIS(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㎾"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ㎿")+title+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ㏀")+l1111l_l1_+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ㏁"))
					import l1llll1lllll_l1_
					l1llll1lllll_l1_.MAIN(156)
					result = l1l11l_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㏂")
				else:
					LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㏃"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭㏄")+title+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ㏅")+l1111l_l1_+l1l11l_l1_ (u"ࠪࠤࡢ࠭㏆"))
					result,l1l111l11l1_l1_,l1l1lll1l1l_l1_ = l1111l11ll1_l1_(l1111l_l1_,source,type)
					#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㏇"),l1l11l_l1_ (u"ࠬ࠭㏈"),result,l1l111l11l1_l1_)
			if l1l11l_l1_ (u"࠭࡜࡯ࠩ㏉") not in l1l111l11l1_l1_: l11lllll11l_l1_,l11lllll111_l1_ = l1l111l11l1_l1_,l1l11l_l1_ (u"ࠧࠨ㏊")
			else: l11lllll11l_l1_,l11lllll111_l1_ = l1l111l11l1_l1_.split(l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㏋"),1)
			if result in [l1l11l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ㏌"),l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㏍"),l1l11l_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㏎"),l1l11l_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ㏏")] or len(l1ll1l1l_l1_)==1: break
			elif result in [l1l11l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㏐"),l1l11l_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ㏑"),l1l11l_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ㏒")]: break
			elif result not in [l1l11l_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭㏓"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㏔")]: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㏕"),l1l11l_l1_ (u"ࠬ࠭㏖"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㏗"),l1l11l_l1_ (u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪ㏘")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㏙")+l11lllll11l_l1_+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㏚")+l11lllll111_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㏛"),l1l11l_l1_ (u"ࠫࠬ㏜"),l1l11l_l1_ (u"ࠬ࠭㏝"),str(l1l1lll1l1l_l1_))
	if result==l1l11l_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㏞") and len(l1l1lll_l1_)>0: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㏟"),l1l11l_l1_ (u"ࠨࠩ㏠"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㏡"),l1l11l_l1_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ㏢")+l1l11l_l1_ (u"ࠫࡡࡴࠧ㏣")+l1l111l11l1_l1_)
	elif result in [l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㏤"),l1l11l_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㏥")] and l1l111l11l1_l1_!=l1l11l_l1_ (u"ࠧࠨ㏦"): DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㏧"),l1l11l_l1_ (u"ࠩࠪ㏨"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㏩"),l1l111l11l1_l1_)
	#elif l1l111l11l1_l1_==l1l11l_l1_ (u"ࠫࡗࡋࡔࡖࡔࡑࡣ࡙ࡕ࡟࡚ࡑࡘࡘ࡚ࡈࡅࠨ㏪"): result = l1l1lll1l1l_l1_
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰ࡮࡬ࠠࡳࡧࡶࡹࡱࡺࠠࡪࡰࠣ࡟ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ࠯ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ࡟࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡖࡨࡷࡹࡀࠠࠡࠢࠪ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠰࡞࠭ࡶࡽࡸ࠴ࡡࡳࡩࡹ࡟࠷ࡣࠩࠋࠋࠌࡼࡧࡳࡣࡱ࡮ࡸ࡫࡮ࡴ࠮ࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࡣࡧࡨࡴࡴ࡟ࡩࡣࡱࡨࡱ࡫ࠬࠡࡈࡤࡰࡸ࡫ࠬࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬ࠮࠯ࠊࠊࠋࡳࡰࡦࡿ࡟ࡪࡶࡨࡱࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡎ࡬ࡷࡹࡏࡴࡦ࡯ࠫࡴࡦࡺࡨ࠾ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠱ࡂࡱࡴࡪࡥ࠾࠳࠷࠷ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࠩ࠸ࡌࡶࠦ࠵ࡇ࡫ࡼࡨ࠱ࡱࡺ࡙ࡸࡼ࠿ࡑࠨࠫࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡶ࡬ࡢࡻࠫࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࡬ࡷ࠳࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳ࠯ࡪࡲ࡫ࡳࡳ࡫࠯࠲࠴࠶࠸࠹࠽࠮࡮ࡲ࠷ࠫ࠱ࡶ࡬ࡢࡻࡢ࡭ࡹ࡫࡭ࠪࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨฬ่ࠤฬ๊วๅ฼สลࠬ࠲ࠧࠨࠫࠍࠍࠧࠨࠢ㏫")
	return result
	#if source==l1l11l_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㏬"): menu_name = l1l11l_l1_ (u"ࠧࡉࡎࡄࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㏭")
	#elif source==l1l11l_l1_ (u"ࠨ࠶ࡋࡉࡑࡇࡌࠨ㏮"): menu_name = l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡍࡋࡌࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㏯")
	#elif source==l1l11l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㏰"): menu_name = l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡁࡌࡏࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㏱")
	#elif source==l1l11l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㏲"): menu_name = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡕࡋ࠸ࠥ࠭㏳")
	#size = len(l1lllll1l1_l1_)
	#for i in range(0,size):
	#	title = l1l1111llll_l1_[i]
	#	l1111l_l1_ = l1lllll1l1_l1_[i]
	#	addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㏴"),menu_name+title,l1111l_l1_,160,l1l11l_l1_ (u"ࠨࠩ㏵"),l1l11l_l1_ (u"ࠩࠪ㏶"),source)
def l1111l11ll1_l1_(url,source,type=l1l11l_l1_ (u"ࠪࠫ㏷")):
	url = url.strip(l1l11l_l1_ (u"ࠫࠥ࠭㏸")).strip(l1l11l_l1_ (u"ࠬࠬࠧ㏹")).strip(l1l11l_l1_ (u"࠭࠿ࠨ㏺")).strip(l1l11l_l1_ (u"ࠧ࠰ࠩ㏻"))
	l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lllll11lll_l1_(url,source)
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㏼"),l1l11l_l1_ (u"ࠩࠪ㏽"),url,l1l111l11l1_l1_)
	if l1l111l11l1_l1_==l1l11l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ㏾"): return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	elif l1ll1l1l_l1_:
		while True:
			if len(l1ll1l1l_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ㏿"), l1l1lll_l1_)
			if selection==-1: result = l1l11l_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ㐀")
			else:
				l111ll11l11_l1_ = l1ll1l1l_l1_[selection]
				title = l1l1lll_l1_[selection]
				LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㐁"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸ࡫࡬ࡦࡥࡷࡩࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭㐂")+title+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㐃")+str(l111ll11l11_l1_)+l1l11l_l1_ (u"ࠩࠣࡡࠬ㐄"))
				if l1l11l_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭㐅") in l111ll11l11_l1_ and l1l11l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ㐆") in l111ll11l11_l1_:
					l11l11111l1_l1_,l1l1ll1ll1l_l1_,l1l1lll1l1l_l1_ = l11ll1ll11l_l1_(l111ll11l11_l1_)
					if l1l1lll1l1l_l1_: l111ll11l11_l1_ = l1l1lll1l1l_l1_[0]
					else: l111ll11l11_l1_ = l1l11l_l1_ (u"ࠬ࠭㐇")
				if not l111ll11l11_l1_: result = l1l11l_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㐈")
				else: result = PLAY_VIDEO(l111ll11l11_l1_,source,type)
			if result in [l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㐉"),l1l11l_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ㐊")] or len(l1ll1l1l_l1_)==1: break
			elif result in [l1l11l_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㐋"),l1l11l_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㐌"),l1l11l_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㐍")]: break
			else: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㐎"),l1l11l_l1_ (u"࠭ࠧ㐏"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㐐"),l1l11l_l1_ (u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧ㐑"))
	else:
		result = l1l11l_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭㐒")
		videofiletype = GET_VIDEOFILETYPE(url)
		if videofiletype: result = PLAY_VIDEO(url,source,type)
	return result,l1l111l11l1_l1_,l1ll1l1l_l1_
	#title = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ㐓") )
	#if l1l11l_l1_ (u"ุࠫ๐ัโำࠣ฽ฬ๋ࠠๆฮ๊์้࠭㐔") in title:
	#	import l1llll1lllll_l1_
	#	l1llll1lllll_l1_.MAIN(156)
	#	return l1l11l_l1_ (u"ࠬ࠭㐕")
def l1llll1l1ll1_l1_(url,source):
	# url = url+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㐖")+name+l1l11l_l1_ (u"ࠧࡠࡡࠪ㐗")+type+l1l11l_l1_ (u"ࠨࡡࡢࠫ㐘")+l11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࠬ㐙")+l1l1l111_l1_
	# url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹࡅ࡮ࡢ࡯ࡨࡨࡂࡧ࡫ࡸࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳࡰ࠵ࡡࡢ࠻࠷࠶ࠧ㐚")
	url2,l11lll11lll_l1_,server,l111ll1lll1_l1_,name,type,l11_l1_,l1l1l111_l1_ = url,l1l11l_l1_ (u"ࠫࠬ㐛"),l1l11l_l1_ (u"ࠬ࠭㐜"),l1l11l_l1_ (u"࠭ࠧ㐝"),l1l11l_l1_ (u"ࠧࠨ㐞"),l1l11l_l1_ (u"ࠨࠩ㐟"),l1l11l_l1_ (u"ࠩࠪ㐠"),l1l11l_l1_ (u"ࠪࠫ㐡")
	#source = source.lower()
	if l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㐢") in url:
		url2,l11lll11lll_l1_ = url.split(l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㐣"),1)
		l11lll11lll_l1_ = l11lll11lll_l1_+l1l11l_l1_ (u"࠭࡟ࡠࠩ㐤")+l1l11l_l1_ (u"ࠧࡠࡡࠪ㐥")+l1l11l_l1_ (u"ࠨࡡࡢࠫ㐦")+l1l11l_l1_ (u"ࠩࡢࡣࠬ㐧")
		l11lll11lll_l1_ = l11lll11lll_l1_.lower()
		name,type,l11_l1_,l1l1l111_l1_,source2 = l11lll11lll_l1_.split(l1l11l_l1_ (u"ࠪࡣࡤ࠭㐨"))[:5]
	if l1l1l111_l1_==l1l11l_l1_ (u"ࠫࠬ㐩"): l1l1l111_l1_ = l1l11l_l1_ (u"ࠬ࠶ࠧ㐪")
	else: l1l1l111_l1_ = l1l1l111_l1_.replace(l1l11l_l1_ (u"࠭ࡰࠨ㐫"),l1l11l_l1_ (u"ࠧࠨ㐬")).replace(l1l11l_l1_ (u"ࠨࠢࠪ㐭"),l1l11l_l1_ (u"ࠩࠪ㐮"))
	url2 = url2.strip(l1l11l_l1_ (u"ࠪࡃࠬ㐯")).strip(l1l11l_l1_ (u"ࠫ࠴࠭㐰")).strip(l1l11l_l1_ (u"ࠬࠬࠧ㐱"))
	server = SERVER(url2,l1l11l_l1_ (u"࠭ࡨࡰࡵࡷࠫ㐲"))
	if name: l111ll1lll1_l1_ = name
	#elif source: l111ll1lll1_l1_ = source
	else: l111ll1lll1_l1_ = server
	l111ll1lll1_l1_ = SERVER(l111ll1lll1_l1_,l1l11l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㐳"))
	name = name.replace(l1l11l_l1_ (u"ࠨ็หหูืࠧ㐴"),l1l11l_l1_ (u"ࠩࠪ㐵")).replace(l1l11l_l1_ (u"ࠪื๏ืแาࠩ㐶"),l1l11l_l1_ (u"ࠫࠬ㐷")).replace(l1l11l_l1_ (u"ࠬอไࠡࠩ㐸"),l1l11l_l1_ (u"࠭ࠠࠨ㐹")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ㐺"),l1l11l_l1_ (u"ࠨࠢࠪ㐻"))
	l11lll11lll_l1_ = l11lll11lll_l1_.replace(l1l11l_l1_ (u"่ࠩฬฬฺัࠨ㐼"),l1l11l_l1_ (u"ࠪࠫ㐽")).replace(l1l11l_l1_ (u"ุࠫ๐ัโำࠪ㐾"),l1l11l_l1_ (u"ࠬ࠭㐿")).replace(l1l11l_l1_ (u"࠭วๅࠢࠪ㑀"),l1l11l_l1_ (u"ࠧࠡࠩ㑁")).replace(l1l11l_l1_ (u"ࠨࠢࠣࠫ㑂"),l1l11l_l1_ (u"ࠩࠣࠫ㑃"))
	l111ll1lll1_l1_ = l111ll1lll1_l1_.replace(l1l11l_l1_ (u"้ࠪออิาࠩ㑄"),l1l11l_l1_ (u"ࠫࠬ㑅")).replace(l1l11l_l1_ (u"ู๊ࠬาใิࠫ㑆"),l1l11l_l1_ (u"࠭ࠧ㑇")).replace(l1l11l_l1_ (u"ࠧศๆࠣࠫ㑈"),l1l11l_l1_ (u"ࠨࠢࠪ㑉")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬ㑊"),l1l11l_l1_ (u"ࠪࠤࠬ㑋"))
	return url2,l11lll11lll_l1_,server,l111ll1lll1_l1_,name,type,l11_l1_,l1l1l111_l1_
def l1l1111l111_l1_(url,source):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㑌"),l1l11l_l1_ (u"ࠬ࠭㑍"),url,l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇࠪ㑎"))
	# l111ll1l_l1_	: سيرفر خاص
	# l11llll11l1_l1_		: سيرفر محدد
	# l11lll11l1l_l1_		: سيرفر عام معروف
	# l11111l1_l1_	: سيرفر عام خارجي
	# l1llllllll11_l1_	: سيرفر عام خارجي
	l111l1ll1ll_l1_,name,l111ll1l_l1_,l11lll11l1l_l1_,l11111l1_l1_,l11llll11l1_l1_,l1llllllll11_l1_ = l1l11l_l1_ (u"ࠧࠨ㑏"),l1l11l_l1_ (u"ࠨࠩ㑐"),None,None,None,None,None
	url2,l11lll11lll_l1_,server,l111ll1lll1_l1_,name,type,l11_l1_,l1l1l111_l1_ = l1llll1l1ll1_l1_(url,source)
	if l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㑑") in url:
		if   type==l1l11l_l1_ (u"ࠪࡩࡲࡨࡥࡥࠩ㑒"): type = l1l11l_l1_ (u"ࠫࠥ࠭㑓")+l1l11l_l1_ (u"๋ࠬแืๆࠪ㑔")
		elif type==l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ㑕"): type = l1l11l_l1_ (u"ࠧࠡࠩ㑖")+l1l11l_l1_ (u"ࠨุ่ࠧฬํฯสࠩ㑗")
		elif type==l1l11l_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ㑘"): type = l1l11l_l1_ (u"ࠪࠤࠬ㑙")+l1l11l_l1_ (u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭㑚")
		elif type==l1l11l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㑛"): type = l1l11l_l1_ (u"࠭ࠠࠨ㑜")+l1l11l_l1_ (u"ࠧࠦࠧࠨฮา๋๊ๅࠩ㑝")
		elif type==l1l11l_l1_ (u"ࠨࠩ㑞"): type = l1l11l_l1_ (u"ࠩࠣࠫ㑟")+l1l11l_l1_ (u"ࠪࠩࠪࠫࠥࠨ㑠")
		if l11_l1_!=l1l11l_l1_ (u"ࠫࠬ㑡"):
			if l1l11l_l1_ (u"ࠬࡳࡰ࠵ࠩ㑢") not in l11_l1_: l11_l1_ = l1l11l_l1_ (u"࠭ࠥࠨ㑣")+l11_l1_
			l11_l1_ = l1l11l_l1_ (u"ࠧࠡࠩ㑤")+l11_l1_
		if l1l1l111_l1_!=l1l11l_l1_ (u"ࠨࠩ㑥"):
			l1l1l111_l1_ = l1l11l_l1_ (u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬ㑦")+l1l1l111_l1_
			l1l1l111_l1_ = l1l11l_l1_ (u"ࠪࠤࠬ㑧")+l1l1l111_l1_[-9:]
	#if any(value in server for value in l11l111ll1l_l1_): return l1l11l_l1_ (u"ࠫࠬ㑨")
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㑩"),l1l11l_l1_ (u"࠭ࠧ㑪"),name,l111ll1lll1_l1_)
	if   l1l11l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㑫")		in source: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㑬")		in source: l111ll1l_l1_	= l1l11l_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㑭")
	elif l1l11l_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ㑮")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ㑯")		in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ㑰")
	#elif l1l11l_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡹࡴࡢࡶ࡬ࡳࡳ࠭㑱") in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠧࡢ࡮ࡤࡶࡦࡨࠧ㑲")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠨࡵࡨࡩࡪ࡫ࡤࠨ㑳")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	#elif l1l11l_l1_ (u"ࠩࡳࡧࡷ࡫ࡶࡪࡧࡺࠫ㑴")	in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫ㑵")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫ㑶")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ㑷")		in name:   l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ㑸")		in name:   l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭㑹")		in name:   l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ㑺")	in name:   l111ll1l_l1_	= l1l11l_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡳࠫ㑻")
	elif l1l11l_l1_ (u"ࠪๅัืࠧ㑼")			in name:   l111ll1l_l1_	= l1l11l_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ㑽")
	elif l1l11l_l1_ (u"ࠬ็ไิูํ๊ࠬ㑾")		in name:   l111ll1l_l1_	= l1l11l_l1_ (u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ㑿")
	elif l1l11l_l1_ (u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧ㒀")		in url2:   l111ll1l_l1_	= l1l11l_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㒁")
	elif l1l11l_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ㒂")		in name:   l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㒃")		in name:   l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ㒄")		in name:   l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㒅")	in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ㒆")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭㒇")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ㒈")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪ㒉")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ㒊")		in server: l111ll1l_l1_	= l111ll1lll1_l1_
	#elif l1l11l_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻ࠳ࡴࡥࡵࠩ㒋")	in url2:   l111ll1l_l1_	= l1l11l_l1_ (u"ࠬࠦࠧ㒌")
	elif l1l11l_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ㒍")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ㒎")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨ㒏")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ㒐")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬ㒑")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭㒒")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࠫ㒓")	 	in server: l111ll1l_l1_	= l1l11l_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ㒔")
	elif l1l11l_l1_ (u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧ㒕")	 	in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ㒖")
	elif l1l11l_l1_ (u"ࠩࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪࠧ㒗")	in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠧ㒘")
	elif l1l11l_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ㒙")		in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭㒚")
	elif l1l11l_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ㒛")		in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ㒜")
	elif l1l11l_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ㒝")	in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ㒞")
	elif l1l11l_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭㒟")	in server: l111ll1l_l1_	= l1l11l_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ㒠")
	elif l1l11l_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭㒡")		in server: l111ll1l_l1_	= l1l11l_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ㒢")
	elif l1l11l_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ㒣")	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ㒤")
	elif l1l11l_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ㒥")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ㒦")
	elif l1l11l_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭㒧")	 	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠬࡩࡡࡵࡥ࡫ࠫ㒨")
	elif l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ㒩")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ㒪")
	elif l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ㒫")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ㒬")
	elif l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ㒭")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪ㒮")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ㒯")		in server: l11llll11l1_l1_	= l111ll1lll1_l1_
	elif l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ㒰")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ㒱")
	elif l1l11l_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ㒲")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ㒳")
	elif l1l11l_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ㒴") 	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭㒵")
	elif l1l11l_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ㒶")	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ㒷")
	elif l1l11l_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ㒸")	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭㒹")
	elif l1l11l_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭㒺") 	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ㒻")
	elif l1l11l_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ㒼")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭㒽")
	elif l1l11l_l1_ (u"࠭ࡵࡱࡲࠪ㒾") 			in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭㒿")
	elif l1l11l_l1_ (u"ࠨࡷࡳࡦࠬ㓀") 			in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ㓁")
	elif l1l11l_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ㓂") 		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ㓃")
	elif l1l11l_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ㓄") 	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ㓅")
	elif l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ㓆")		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ㓇")
	elif l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ㓈") 		in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ㓉")
	elif l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ㓊") 	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ㓋")
	elif l1l11l_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ㓌")	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ㓍")
	elif l1l11l_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ㓎")	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭㓏")
	#elif l1l11l_l1_ (u"ࠪࡹࡵࡺ࡯ࡣࡱࡻࠫ㓐") 	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ㓑")
	#elif l1l11l_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ㓒")	in server: l11lll11l1l_l1_	= l1l11l_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ㓓")
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࡹࡷࡲࠫࠨ࠿ࡀࡁࠬ࠱ࡵࡳ࡮࠵࠭ࠏࠏࠉࡵࡴࡼ࠾ࠏࠏࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭࠰ࡋࡳࡸࡺࡥࡥࡏࡨࡨ࡮ࡧࡆࡪ࡮ࡨࠬࡺࡸ࡬࠳ࠫ࠱ࡺࡦࡲࡩࡥࡡࡸࡶࡱ࠮ࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࠍ࡮࡬ࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠊࠊࠋࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠴࠵࠶࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ࠩࠋࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡈࡤࡰࡸ࡫ࠊࠊࠋࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥ࡮࠱ࡳࡷ࡭ࠊࠊࠋࠌࡰ࡮ࡹࡴࡠࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡸࡩࡲ࠭ࡰࡴࡪ࠲࡬࡯ࡴࡩࡷࡥ࠲࡮ࡵ࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦ࡯࠳ࡸࡻࡰࡱࡱࡵࡸࡪࡪࡳࡪࡶࡨࡷ࠳࡮ࡴ࡮࡮ࠪࠎࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱ࡲࡩࡴࡶࡢࡹࡷࡲࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇ࠰࠵ࡸࡺࠧࠪࠌࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀࡺࡲ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌ࡭࡫ࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࡛࠱࡟࠱ࡰࡴࡽࡥࡳࠪࠬࠎࠎࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࡯࡭ࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼ࡣࡀࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࠯࡭࡫ࡁࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁ࠵ࡢ࠿ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠶࠷࠸࠲ࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧࠪࠌࠌࠍࠎࠏࡰࡢࡴࡷࡷࠥࡃࠠࡴࡧࡵࡺࡪࡸ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠯ࠩࠬࠎࠎࠏࠉࠊࡨࡲࡶࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡰࡢࡴࡷࡷ࠿ࠐࠉࠊࠋࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡵࡧࡲࡵࠫ࠿࠸࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࠏࡥ࡭࡫ࡩࠤࡵࡧࡲࡵࠢ࡬ࡲࠥ࡮ࡴ࡮࡮࠽ࠎࠎࠏࠉࠊࠋࠌࡶࡪࡹ࡯࡭ࡸࡨࡶࠥࡃࠠࡕࡴࡸࡩࠏࠏࠉࠊࠋࠌࠍࡧࡸࡥࡢ࡭ࠍࠍࠧࠨࠢ㓔")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㓕"),l1l11l_l1_ (u"ࠩࠪ㓖"),url,url2)
	if   l111ll1l_l1_:	l111l1ll1ll_l1_,name = l1l11l_l1_ (u"ࠪาฬ฻ࠧ㓗"),l111ll1l_l1_
	elif l11llll11l1_l1_:		l111l1ll1ll_l1_,name = l1l11l_l1_ (u"๋ࠫࠪอะัࠪ㓘"),l11llll11l1_l1_
	elif l11lll11l1l_l1_:		l111l1ll1ll_l1_,name = l1l11l_l1_ (u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪ㓙"),l11lll11l1l_l1_
	elif l11111l1_l1_:	l111l1ll1ll_l1_,name = l1l11l_l1_ (u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ㓚"),l11111l1_l1_
	elif l1llllllll11_l1_:	l111l1ll1ll_l1_,name = l1l11l_l1_ (u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧ㓛"),l111ll1lll1_l1_
	else:			l111l1ll1ll_l1_,name = l1l11l_l1_ (u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩ㓜"),l111ll1lll1_l1_
	return l111l1ll1ll_l1_,name,type,l11_l1_,l1l1l111_l1_
	l1l11l_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭࡫ࡩࠤࠬࡶ࡬ࡢࡻࡵ࠲࠹࡮ࡥ࡭ࡣ࡯ࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌࡴࡷ࡯ࡶࡢࡶࡨࠤࡂࠦࠧࡩࡧ࡯ࡥࡱ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸࡨࡺ࠳࡯࡯ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡫ࡶࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡨ࡯࡮ࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡪࡧࠫࠥࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡷ࡭ࡧࡲࡦࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠊࠊࠤࠥࠦ㓝")
def l1111ll11ll_l1_(url,source):
	url2,l11lll11lll_l1_,server,l111ll1lll1_l1_,name,type,l11_l1_,l1l1l111_l1_ = l1llll1l1ll1_l1_(url,source)
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㓞"),l1l11l_l1_ (u"ࠫࠬ㓟"),l11llll11l1_l1_,server)
	#if l1l11l_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ㓠")	in server: url2 = url2.replace(l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㓡"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㓢"))
	#if any(value in server for value in l11l111ll1l_l1_): l1l1lll_l1_,l1ll1l1l_l1_ = [l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ㓣")],[]
	if   l1l11l_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㓤")		in source: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l1_l1_(url2,name)
	elif l1l11l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㓥")		in source: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll1_l1_(url2,type,l1l1l111_l1_)
	elif l1l11l_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㓦")		in source: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111111ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㓧")		in source: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l1111l_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮ࠩ㓨")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡢ࡮ࡤࡶࡦࡨࠧ㓩")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11llllllll_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ㓪")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111111111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ㓫")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111111111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮ࡥ࡯ࡹࡧ࠭㓬")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11111l11_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ㓭")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111ll111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ㓮")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111llll1ll_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡴࡷ࡭ࡶࡥࠬ㓯")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111llll1ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ㓰")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lll1l1l11_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ㓱")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111l11l_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ㓲")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lllll1l11l_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ㓳")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llllll1111_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡻࡹ࠴ࡶࠩ㓴")			in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l1ll1l1ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ㓵")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111111l1l_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ㓶")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1l1l_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡤ࡫ࡰࡥ࠲ࡲࡩࡨࡪࡷࠫ㓷")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll1_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ㓸")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll1_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ㓹")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l1ll1l11l_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㓺")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111111l111_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ㓻")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l1l111_l1_(url2)
	elif l1l11l_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㓼")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1ll1l111l_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㓽")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l1ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ㓾")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l1ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡵࡧࡦ࡬ࠬ㓿")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l1ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫ㔀")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11llll11_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨ㔁")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠫࠬ㔂"),[l1l11l_l1_ (u"ࠬ࠭㔃")],[url2]
	elif l1l11l_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ㔄")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll1l11l_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠭㔅")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l1llllll_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡷࡳࡦࡦࡳࠧ㔆") 		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠩࠪ㔇"),[l1l11l_l1_ (u"ࠪࠫ㔈")],[url2]
	else: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㔉"),[l1l11l_l1_ (u"ࠬ࠭㔊")],[url2]
	return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
def l11lll111ll_l1_(url,source):
	server = SERVER(url,l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㔋"))
	#if l1l11l_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ㔌")	in server: url2 = url2.replace(l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ㔍"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㔎"))
	#if any(value in server for value in l11l111ll1l_l1_): l1l1lll_l1_,l1ll1l1l_l1_ = [l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡊ࡙ࡏࡍࡘࡈࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࠠࡵࡪ࡬ࡷࠥࡹࡥࡳࡸࡨࡶࠬ㔏")],[]
	l1111ll11l1_l1_ = False
	if   l1l11l_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ㔐")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l1111l1l1_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ㔑")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l1111l1l1_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㔒")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l1ll_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㔓")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1ll1l111l_l1_(url)
	elif l1l11l_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ㔔")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll1ll11l_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪ㔕")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111111ll_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭㔖")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111l11l111_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ㔗")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lll1llllll_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭㔘")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111l1ll111_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭㔙")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll11111l_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭㔚")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll111l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ㔛")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll111l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ㔜")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ㔝")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ㔞")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡼࡩࡥࡪࡧࠫ㔟")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ㔠")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	elif l1l11l_l1_ (u"ࠧ࡭࡫࡬࡭ࡻ࡯ࡤࡦࡱࠪ㔡")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	elif l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡴࡨࡡࠨ㔢")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1l11ll_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡹࡰࡦࡧࡧࠫ㔣")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1l11ll_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡹࡵࡨࡡ࡮ࠩ㔤") 		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠫࠬ㔥"),[l1l11l_l1_ (u"ࠬ࠭㔦")],[url]
	#elif l1l11l_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ㔧")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lll1lllll1_l1_(url)
	elif l1l11l_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ㔨") 	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l111l11l_l1_(url)
	elif l1l11l_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ㔩")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l1l11l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࡨࡰࠩ㔪")in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111ll1l11l_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ㔫") 	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11ll1l111l_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ㔬")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111l1llll_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡻࡰࡣࠩ㔭") 			in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lll1ll1l11_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡵࡱࡲࠪ㔮") 			in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lll1ll1l11_l1_(url)
	#elif l1l11l_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ㔯") 	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111l1l11ll_l1_(url)
	#elif l1l11l_l1_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ㔰")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111l1l11ll_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ㔱") 		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111111ll1l_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ㔲") 	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l1111l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ㔳")		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111lll1ll_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ㔴") 		in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111l1111l_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ㔵") 	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11l11lllll_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ㔶")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11111l1111_l1_(url)
	elif l1l11l_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ㔷")	in server: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l111l1l1lll_l1_(url)
	else: l1111ll11l1_l1_ = True
	if l1111ll11l1_l1_ or l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠫ㔸") in l1l111l11l1_l1_:
		l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠢࡉࡥ࡮ࡲࡥࡥࠩ㔹"),[],[]
	return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡉࡘ࡚ࡒࡆࡃࡐࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡈࡑࡘࡒࡑࡏࡍࡊࡖࡈࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡋࡑࡘࡔ࡛ࡐࡍࡑࡄࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡔࡉࡇ࡙ࡍࡉࡋࡏࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡦࡸ࠱࡭ࡴ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡈ࡚ࡎࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡶ࡬ࡢࡻࡵ࠲࠹࡮ࡥ࡭ࡣ࡯ࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡍࡋࡌࡂࡎࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾࡙ࠢࡍࡉࡈࡏࡎࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠠࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡍࡊࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡘࡎࡁࡓࡇࠫࡹࡷࡲࠩࠋࠋࠥࠦࠧ㔺")
def	l111llllll1_l1_(l1l1llllll1_l1_):
	if l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࠪ㔻") in str(type(l1l1llllll1_l1_)):
		l1l1lll1_l1_ = []
		for l1111l_l1_ in l1l1llllll1_l1_:
			if l1l11l_l1_ (u"࠭ࡳࡵࡴࠪ㔼") in str(type(l1111l_l1_)):
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠧ࡝ࡴࠪ㔽"),l1l11l_l1_ (u"ࠨࠩ㔾")).replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㔿"),l1l11l_l1_ (u"ࠪࠫ㕀")).strip(l1l11l_l1_ (u"ࠫࠥ࠭㕁"))
			l1l1lll1_l1_.append(l1111l_l1_)
	else: l1l1lll1_l1_ = l1l1llllll1_l1_.replace(l1l11l_l1_ (u"ࠬࡢࡲࠨ㕂"),l1l11l_l1_ (u"࠭ࠧ㕃")).replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㕄"),l1l11l_l1_ (u"ࠨࠩ㕅")).strip(l1l11l_l1_ (u"ࠩࠣࠫ㕆"))
	return l1l1lll1_l1_
def l1lllll11lll_l1_(url,source):
	LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㕇"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ㕈")+url+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ㕉"))
	l1llllllll11_l1_,l1111l_l1_,l111lllllll_l1_ = l1l11l_l1_ (u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ㕊"),l1l11l_l1_ (u"ࠧࠨ㕋"),l1l11l_l1_ (u"ࠨࠩ㕌")
	l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1111ll11ll_l1_(url,source)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㕍"),l1l11l_l1_ (u"ࠪࠫ㕎"),l1l11l_l1_ (u"ࠫࠬ㕏"),l1l111l11l1_l1_)
	l1ll1l1l_l1_ = l111llllll1_l1_(l1ll1l1l_l1_)
	if l1l111l11l1_l1_==l1l11l_l1_ (u"ࠬࡋࡘࡊࡖࠪ㕐"): return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	elif l1ll1l1l_l1_: l1111l_l1_ = l1ll1l1l_l1_[0]
	if l1l111l11l1_l1_==l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㕑"):
		#l1l111l11l1_l1_ = l1l111l11l1_l1_.replace(l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㕒"),l1l11l_l1_ (u"ࠨࠩ㕓"))
		l1llllllll11_l1_ = l1l11l_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ㕔")
		l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11lll111ll_l1_(l1111l_l1_,source)
		l1ll1l1l_l1_ = l111llllll1_l1_(l1ll1l1l_l1_)
		if l1l111l11l1_l1_==l1l11l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ㕕"): return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
		elif l1l11l_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠳ࠪ㕖") in l1l111l11l1_l1_:
			l111lllllll_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥ࠭㕗")+l1l111l11l1_l1_
			l1llllllll11_l1_ = l1l11l_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ㕘")
			l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l11lll111l1_l1_(l1111l_l1_,source)
			l1ll1l1l_l1_ = l111llllll1_l1_(l1ll1l1l_l1_)
			if l1l111l11l1_l1_==l1l11l_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ㕙"): return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
			elif l1l11l_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧ㕚") in l1l111l11l1_l1_:
				l111lllllll_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠪ㕛")+l1l111l11l1_l1_
				l1llllllll11_l1_ = l1l11l_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ㕜")
				l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l111l111l_l1_(l1111l_l1_,source)
				l1ll1l1l_l1_ = l111llllll1_l1_(l1ll1l1l_l1_)
				if l1l111l11l1_l1_==l1l11l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ㕝"): return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
				elif l1l11l_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠫ㕞") in l1l111l11l1_l1_:
					l111lllllll_l1_ += l1l11l_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠷࠿ࠦࠧ㕟")+l1l111l11l1_l1_
					#LOG_THIS(l1l11l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㕠"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡆࡲ࡬ࠡࡇࡻࡸࡪࡸ࡮ࡢ࡮ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࡸࠦࡆࡢ࡫࡯ࡩࡩࠦࠠࠡࡏࡨࡷࡸࡧࡧࡦࡵ࠽ࠤࡠࠦࠧ㕡")+l111lllllll_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭㕢")+url+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ㕣")+l1111l_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠧ㕤"))
	elif l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ㕥") in l1l111l11l1_l1_: l111lllllll_l1_ = l1l11l_l1_ (u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠲࠽ࠤࠬ㕦")+l1l111l11l1_l1_
	l111lllllll_l1_ = l111lllllll_l1_.strip(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㕧"))
	if l1ll1l1l_l1_: LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㕨"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ㕩")+l1llllllll11_l1_+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ㕪")+l1111l_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡸࡻ࡬ࡵ࠼ࠣ࡟ࠥ࠭㕫")+str(l1ll1l1l_l1_)+l1l11l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ㕬")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ㕭"))
	else: LOG_THIS(l1l11l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㕮"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ㕯")+l1111l_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡧࡶࡷࡦ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭㕰")+l111lllllll_l1_+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ㕱")+url+l1l11l_l1_ (u"ࠫࠥࡣࠧ㕲"))
	#l111lllllll_l1_ = l111lllllll_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ㕳"),l1l11l_l1_ (u"࠭ࠠ࠯࠰࠱ࠤࠬ㕴"))
	#if l1l11l_l1_ (u"ࠧࡦࡴࡵࡳࡷࡀࠠࠨ㕵") not in l1l111l11l1_l1_.lower(): return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	l111lllllll_l1_ = UNQUOTE(l111lllllll_l1_)
	return l111lllllll_l1_,l1l1lll_l1_,l1ll1l1l_l1_
def l111111lll1_l1_(l1l1lll1l1l_l1_,source):
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭㕶"),l1l1lll1l1l_l1_)
	expiry = l1llll_l1_
	data = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㕷"),l1l11l_l1_ (u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ㕸"),l1l1lll1l1l_l1_)
	if data:
		l1l1lll_l1_,l1ll1l1l_l1_ = list(zip(*data))
		return l1l1lll_l1_,l1ll1l1l_l1_
	l1l1lll_l1_,l1ll1l1l_l1_,l1l1111llll_l1_ = [],[],[]
	for l1111l_l1_ in l1l1lll1l1l_l1_:
		if l1l11l_l1_ (u"ࠫ࠴࠵ࠧ㕹") not in l1111l_l1_: continue
		l111l1ll1ll_l1_,name,type,l11_l1_,l1l1l111_l1_ = l1l1111l111_l1_(l1111l_l1_,source)
		l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࡤࠬࠩ㕺"),l1l1l111_l1_,re.DOTALL)
		if l1l1l111_l1_: l1l1l111_l1_ = int(l1l1l111_l1_[0])
		else: l1l1l111_l1_ = 0
		#if l1l1l111_l1_:
		#	l11ll1l1lll_l1_ = sorted(l1l1l111_l1_,reverse=True,key=lambda key: int(key))
		#	l1l1l111_l1_ = int(l11ll1l1lll_l1_[0])
		#else: l1l1l111_l1_ = 0
		server = SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㕻"))
		l1l1111llll_l1_.append([l111l1ll1ll_l1_,name,type,l11_l1_,l1l1l111_l1_,l1111l_l1_,server])
	if l1l1111llll_l1_:
		#l111l1ll1ll_l1_,name,type,l11_l1_,l1l1l111_l1_,l1111l_l1_ = zip(*l1l1111llll_l1_)
		#name = reversed(name)
		#l1l1111llll_l1_ = zip(l111l1ll1ll_l1_,name,type,l11_l1_,l1l1l111_l1_,l1111l_l1_)
		l11l1111111_l1_ = sorted(l1l1111llll_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111llll111_l1_ = []
		for line in l11l1111111_l1_:
			if line not in l111llll111_l1_:
				l111llll111_l1_.append(line)
				#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ㕼"),str(line))
		for l111l1ll1ll_l1_,name,type,l11_l1_,l1l1l111_l1_,l1111l_l1_,server in l111llll111_l1_:
			if l1l1l111_l1_: l1l1l111_l1_ = str(l1l1l111_l1_)
			else: l1l1l111_l1_ = l1l11l_l1_ (u"ࠨࠩ㕽")
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㕾"),l1l11l_l1_ (u"ࠪࠫ㕿"),name,l1111l_l1_)
			title = l1l11l_l1_ (u"ุࠫ๐ัโำࠪ㖀")+l1l11l_l1_ (u"ࠬࠦࠧ㖁")+type+l1l11l_l1_ (u"࠭ࠠࠨ㖂")+l111l1ll1ll_l1_+l1l11l_l1_ (u"ࠧࠡࠩ㖃")+l1l1l111_l1_+l1l11l_l1_ (u"ࠨࠢࠪ㖄")+l11_l1_+l1l11l_l1_ (u"ࠩࠣࠫ㖅")+name
			if server not in title: title = title+l1l11l_l1_ (u"ࠪࠤࠬ㖆")+server
			title = title.replace(l1l11l_l1_ (u"ࠫࠪ࠭㖇"),l1l11l_l1_ (u"ࠬ࠭㖈")).strip(l1l11l_l1_ (u"࠭ࠠࠨ㖉")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ㖊"),l1l11l_l1_ (u"ࠨࠢࠪ㖋")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬ㖌"),l1l11l_l1_ (u"ࠪࠤࠬ㖍")).replace(l1l11l_l1_ (u"ࠫࠥࠦࠧ㖎"),l1l11l_l1_ (u"ࠬࠦࠧ㖏"))
			if l1111l_l1_ not in l1ll1l1l_l1_:
				l1l1lll_l1_.append(title)
				l1ll1l1l_l1_.append(l1111l_l1_)
		if l1ll1l1l_l1_:
			#selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ㖐"),l1ll1l1l_l1_)
			data = list(zip(l1l1lll_l1_,l1ll1l1l_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ㖑"),l1l1lll1l1l_l1_,data,expiry)
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ㖒"),l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠺࠳࠼ࠣࠤࠥ࠭㖓")+str(data))
	return l1l1lll_l1_,l1ll1l1l_l1_
l1l11l_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡗࡊࡘࡖࡆࡔࡖࡣࡈࡇࡃࡉࡇࡇࡣࡔࡒࡄࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡴࡻࡲࡤࡧࡀࠫࠬ࠯࠺ࠋࠋࠦࡸ࠶ࠦ࠽ࠡࡶ࡬ࡱࡪ࠴ࡴࡪ࡯ࡨࠬ࠮ࠐࠉࡤࡣࡦ࡬ࡪࡶࡥࡳ࡫ࡲࡨࠥࡃࠠࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈࠎࠎࡩ࡯࡯ࡰࠣࡁࠥࡹࡱ࡭࡫ࡷࡩ࠸࠴ࡣࡰࡰࡱࡩࡨࡺࠨ࡮ࡣ࡬ࡲࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡸࡪࡾࡴࡠࡨࡤࡧࡹࡵࡲࡺࠢࡀࠤࡸࡺࡲࠋࠋࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡓࡆࡎࡈࡇ࡙ࠦࡳࡦࡴࡹࡩࡷࡹࡌࡊࡕࡗ࠰ࡺࡸ࡬ࡍࡋࡖࡘࠥࡌࡒࡐࡏࠣࡷࡪࡸࡶࡦࡴࡶࡧࡦࡩࡨࡦ࡚ࠢࡌࡊࡘࡅࠡ࡮࡬ࡲࡰࡒࡉࡔࡖࡀࠦࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮࠱ࠧࠣࠩࠬࠎࠎࡸ࡯ࡸࡵࠣࡁࠥࡩ࠮ࡧࡧࡷࡧ࡭ࡧ࡬࡭ࠪࠬࠎࠎ࡯ࡦࠡࡴࡲࡻࡸࡀࠊࠊࠋࠦࡱࡪࡹࡳࡢࡩࡨࠤࡂࠦࠧࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࡦࡥࡨ࡮ࡥࠨࠌࠌࠍࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕ࠮ࡸࡶࡱࡒࡉࡔࡖࠣࡁࠥࡋࡖࡂࡎࠫࠫࡸࡺࡲࠨ࠮ࡵࡳࡼࡹ࡛࠱࡟࡞࠴ࡢ࠯ࠬࡆࡘࡄࡐ࠭࠭ࡳࡵࡴࠪ࠰ࡷࡵࡷࡴ࡝࠳ࡡࡠ࠷࡝ࠪࠌࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠨࡳࡥࡴࡵࡤ࡫ࡪࠦ࠽ࠡࠩࡱࡳࡹࠦࡦࡰࡷࡱࡨࠥ࡯࡮ࠡࡥࡤࡧ࡭࡫ࠧࠋࠋࠌࡷࡪࡸࡶࡦࡴࡶࡐࡎ࡙ࡔ࠭ࡷࡵࡰࡑࡏࡓࡕࠢࡀࠤࡘࡋࡒࡗࡇࡕࡗ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩࠋࠋࠌࡸࠥࡃࠠࠩࡰࡲࡻ࠰ࡩࡡࡤࡪࡨࡴࡪࡸࡩࡰࡦ࠯ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫ࠯ࡷࡹࡸࠨࡴࡧࡵࡺࡪࡸࡳࡍࡋࡖࡘ࠮࠲ࡳࡵࡴࠫࡹࡷࡲࡌࡊࡕࡗ࠭࠮ࠐࠉࠊࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠧࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡷࡪࡸࡶࡦࡴࡶࡧࡦࡩࡨࡦ࡙ࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀ࠮ࡂ࠭ࠧ࠲ࡴࠪࠌࠌࠍࡨࡵ࡮࡯࠰ࡦࡳࡲࡳࡩࡵࠪࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎࠩࡴ࠳ࠢࡀࠤࡹ࡯࡭ࡦ࠰ࡷ࡭ࡲ࡫ࠨࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡓࡕࡔࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠫࡱࡪࡹࡳࡢࡩࡨ࠰ࡸࡺࡲࠩ࡫ࡱࡸ࠭ࡺ࠲࠮ࡶ࠴࠭࠮࠱ࠧࠡ࡯ࡶࠫ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠠࡴࡧࡵࡺࡪࡸࡳࡍࡋࡖࡘ࠱ࡻࡲ࡭ࡎࡌࡗ࡙ࠐࠊࡥࡧࡩࠤࡘࡋࡒࡗࡇࡕࡗࡤࡕࡌࡅࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠰ࡸࡵࡵࡳࡥࡨࡁࠬ࠭ࠩ࠻ࠌࠌࡷࡪࡸࡶࡦࡴࡶࡐࡎ࡙ࡔ࠭ࡷࡵࡰࡑࡏࡓࡕ࠮ࡸࡲࡰࡴ࡯ࡸࡰࡏࡍࡘ࡚ࠬࡴࡧࡵࡺࡪࡸࡳࡅࡋࡆࡘࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࠣ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡱ࡯ࡳࡵࠪࡶࡩࡹ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪࠫࠍࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪࠌࠌࠧ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲ࠢ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࠬ࠭ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭ࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠻ࠌࠌࠍ࡮࡬ࠠ࡭࡫ࡱ࡯ࡂࡃࠧࠨ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࡴࡧࡵࡺࡪࡸࡎࡂࡏࡈࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇࠫࡰ࡮ࡴ࡫࠭ࡵࡲࡹࡷࡩࡥࠪࠌࠌࠍࡸ࡫ࡲࡷࡧࡵࡷࡉࡏࡃࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠣ࡟ࡸ࡫ࡲࡷࡧࡵࡒࡆࡓࡅ࠭࡮࡬ࡲࡰࡣࠠࠪࠌࠌࡷࡴࡸࡴࡦࡦࡇࡍࡈ࡚ࠠ࠾ࠢࡶࡳࡷࡺࡥࡥࠪࡶࡩࡷࡼࡥࡳࡵࡇࡍࡈ࡚ࠬࠡࡴࡨࡺࡪࡸࡳࡦ࠿ࡗࡶࡺ࡫ࠬࠡ࡭ࡨࡽࡂࡲࡡ࡮ࡤࡧࡥࠥࡱࡥࡺ࠼ࠣ࡯ࡪࡿ࡛࠱࡟ࠬࠎࠎ࡬࡯ࡳࠢࡶࡩࡷࡼࡥࡳ࠮࡯࡭ࡳࡱࠠࡪࡰࠣࡷࡴࡸࡴࡦࡦࡇࡍࡈ࡚࠺ࠋࠋࠌࡷࡪࡸࡶࡦࡴࠣࡁࠥࡹࡥࡳࡸࡨࡶ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠦࠩ࠯ࠫࠬ࠯ࠊࠊࠋࡶࡩࡷࡼࡥࡳࡵࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡴࡧࡵࡺࡪࡸࠩࠋࠋࠌࡹࡷࡲࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠨࡲࡩ࡯ࡧࡶࠤࡂࠦ࡬ࡦࡰࠫࡹࡳࡱ࡮ࡰࡹࡱࡐࡎ࡙ࡔࠪࠌࠌࠧ࡮࡬ࠠ࡭࡫ࡱࡩࡸࡄ࠰࠻ࠌࠌࠧࠎࡳࡥࡴࡵࡤ࡫ࡪࠦ࠽ࠡࠩ࡟ࡠࡳ࠭ࠊࠊࠥࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯ࠥ࡯࡮ࠡࡷࡱ࡯ࡳࡵࡷ࡯ࡎࡌࡗ࡙ࡀࠊࠊࠥࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࠥ࠱࠽ࠡ࡮࡬ࡲࡰࠦࠫࠡࠩ࡟ࡠࡳ࠭ࠊࠊࠥࠌࡷࡺࡨࡪࡦࡥࡷࠤࡂࠦࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࡶࠤࡂࠦࠧࠡ࠭ࠣࡷࡹࡸࠨ࡭࡫ࡱࡩࡸ࠯ࠊࠊࠥࠌࡶࡪࡹࡵ࡭ࡶࠣࡁ࡙ࠥࡅࡏࡆࡢࡉࡒࡇࡉࡍࠪࡶࡹࡧࡰࡥࡤࡶ࠯ࡱࡪࡹࡳࡢࡩࡨ࠰ࡋࡧ࡬ࡴࡧ࠯ࠫࠬ࠲ࠧࡇࡔࡒࡑ࠲ࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩ࠮ࡷࡴࡻࡲࡤࡧࠬࠎࠎࡸࡥࡵࡷࡵࡲࠥࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖ࠯ࡹࡷࡲࡌࡊࡕࡗࠎࠧࠨࠢ㖔")
def	l11lll111l1_l1_(url,source):
	#url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡃࡣ࡚ࡣ࡯࡫࡮ࡰࡼࡎࡧࠬ㖕")
	errortrace = l1l11l_l1_ (u"ࠬ࠭㖖")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11llll11ll_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: errortrace = str(error)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㖗"),l1l11l_l1_ (u"ࠧࠨ㖘"),l1l11l_l1_ (u"ࠨࠩ㖙"),str(results))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㖚"),l1l11l_l1_ (u"ࠪࠫ㖛"),l1l11l_l1_ (u"ࠫࠬ㖜"),str(errortrace))
	# resolveurl l11lll1ll1_l1_ fail l1lllllll111_l1_ with l1llll11ll1l_l1_ error or l11l1111l11_l1_ value False
	if not results:
		if errortrace==l1l11l_l1_ (u"ࠬ࠭㖝"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㖞"),l1l11l_l1_ (u"ࠧࠨ㖟"),l1l11l_l1_ (u"ࠨࠩ㖠"),str(errortrace))
		l1l111l11l1_l1_ = l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㖡")
		l1l111l11l1_l1_ += l1l11l_l1_ (u"ࠪࠤࠬ㖢")+errortrace.splitlines()[-1]
		return l1l111l11l1_l1_,[],[]
	return l1l11l_l1_ (u"ࠫࠬ㖣"),[l1l11l_l1_ (u"ࠬ࠭㖤")],[results]
def	l1l111l111l_l1_(url,source):
	#url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡅࡥ࡜ࡥࡪࡦࡰࡲࡾࡐࡩࠧ㖥")
	#url = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳ࠯ࡷ࡫ࡧࡩࡴ࠵ࡸ࠸ࡻࡼ࠸࠶ࡹࠧ㖦")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㖧"),l1l11l_l1_ (u"ࠩࠪ㖨"),url,l1l11l_l1_ (u"ࠪࠫ㖩"))
	#return l1l11l_l1_ (u"ࠫࠬ㖪"),[],[]
	errortrace = l1l11l_l1_ (u"ࠬ࠭㖫")
	results = False
	try:
		import youtube_dl
		l1l1111111l_l1_ = youtube_dl.YoutubeDL({l1l11l_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ㖬"): True})
		results = l1l1111111l_l1_.extract_info(url,download=False)
	except Exception as error: errortrace = str(error)
	# youtube_dl l11lll1ll1_l1_ fail l1lllllll111_l1_ with l1llll11ll1l_l1_ error or l11l1111l11_l1_ value False
	if not results or l1l11l_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ㖭") not in list(results.keys()):
		if errortrace==l1l11l_l1_ (u"ࠨࠩ㖮"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㖯"),l1l11l_l1_ (u"ࠪࠫ㖰"),l1l11l_l1_ (u"ࠫࠬ㖱"),errortrace)
		l1l111l11l1_l1_ = l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠤࡋࡧࡩ࡭ࡧࡧࠫ㖲")
		l1l111l11l1_l1_ += l1l11l_l1_ (u"࠭ࠠࠨ㖳")+errortrace.splitlines()[-1]
		return l1l111l11l1_l1_,[],[]
	else:
		l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
		for l1111l_l1_ in results[l1l11l_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ㖴")]:
			l1l1lll_l1_.append(l1111l_l1_[l1l11l_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࠨ㖵")])
			l1ll1l1l_l1_.append(l1111l_l1_[l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㖶")])
		return l1l11l_l1_ (u"ࠪࠫ㖷"),l1l1lll_l1_,l1ll1l1l_l1_
def l11llllllll_l1_(url):
	if l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㖸") in url:
		l1l1lll_l1_,l1ll1l1l_l1_ = l1ll11111l_l1_(url)
		if l1ll1l1l_l1_: return l1l11l_l1_ (u"ࠬ࠭㖹"),l1l1lll_l1_,l1ll1l1l_l1_
		return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡅࡗࡇࡂࠨ㖺"),[],[]
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㖻"),[l1l11l_l1_ (u"ࠨࠩ㖼")],[url]
def l1111111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㖽"),l1l11l_l1_ (u"ࠪࠫ㖾"),l1l11l_l1_ (u"ࠫࠬ㖿"),url)
	#url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡴࡴࡥ࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡪ࡫ࡨ࠷࠱࠺ࡦ࠵࠾࠸ࡣ࠳࠺ࡧ࠵࠶࠸࠰࠳ࡣࡧ࠵࠽ࡪࡤ࠲࠴ࡦ࠺࠽࠶࠶ࠨ㗀")
	#url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡶࡩࡱ࡮ࡤ࠮ࡧࡰࡦࡪࡪ࠮ࡴࡥࡧࡲ࠳ࡺ࡯࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡦ࠵࠷࠵࠺࠲࠷ࡥ࠽ࡧࡣࡧ࠹࠼࠹࠻ࡪ࠱ࡦ࠹࠹࠷࠵ࡨࡥ࠲࠹࠹࠹࠽࠽࠳ࠨ㗁")
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㗂"),url,l1l11l_l1_ (u"ࠨࠩ㗃"),l1l11l_l1_ (u"ࠩࠪ㗄"),l1l11l_l1_ (u"ࠪࠫ㗅"),l1l11l_l1_ (u"ࠫࠬ㗆"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ㗇"))
	html = response.content
	html = l1llll11ll_l1_(html)
	#WRITE_THIS(l1l11l_l1_ (u"࠭ࠧ㗈"),html)
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㗉"),html,re.DOTALL)
	if l1111l_l1_: return l1l11l_l1_ (u"ࠨࠩ㗊"),[l1l11l_l1_ (u"ࠩࠪ㗋")],[l1111l_l1_[0]]
	return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㗌"),[],[]
def l11l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㗍"),url,l1l11l_l1_ (u"ࠬ࠭㗎"),l1l11l_l1_ (u"࠭ࠧ㗏"),l1l11l_l1_ (u"ࠧࠨ㗐"),l1l11l_l1_ (u"ࠨࠩ㗑"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩ㗒"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㗓"),html,re.DOTALL)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭㗔"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㗕"),[l1l11l_l1_ (u"࠭ࠧ㗖")],[l1111l_l1_]
def l111ll111l_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ㗗"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ㗘"),l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㗙"):l1l11l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ㗚")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㗛"),url2,data2,headers2,l1l11l_l1_ (u"ࠬ࠭㗜"),l1l11l_l1_ (u"࠭ࠧ㗝"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡎࡐ࡙࠰࠵ࡸࡺࠧ㗞"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㗟"),html,re.DOTALL)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡏࡑ࡚ࠫ㗠"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㗡"),[l1l11l_l1_ (u"ࠫࠬ㗢")],[l1111l_l1_]
def l1lllll1l11l_l1_(url):
	headers = {l1l11l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ㗣"):l1l11l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ㗤")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㗥"),url,l1l11l_l1_ (u"ࠨࠩ㗦"),headers,l1l11l_l1_ (u"ࠩࠪ㗧"),l1l11l_l1_ (u"ࠪࠫ㗨"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭㗩"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㗪"),html,re.DOTALL|re.IGNORECASE)
	if not l1111l_l1_: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪ㗫"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㗬"),[l1l11l_l1_ (u"ࠨࠩ㗭")],[l1111l_l1_]
def l1lll1l1l11_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㗮"):l1l11l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ㗯")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㗰"),url2,data2,headers2,l1l11l_l1_ (u"ࠬ࠭㗱"),l1l11l_l1_ (u"࠭ࠧ㗲"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡌࡆࡒࡁࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ㗳"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ㗴"),html,re.DOTALL|re.IGNORECASE)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡍࡇࡌࡂࡅࡌࡑࡆ࠭㗵"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㗶") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ㗷")+l1111l_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㗸"),l1l11l_l1_ (u"࠭ࠧ㗹"),l1l11l_l1_ (u"ࠧࠨ㗺"),l1111l_l1_)
	return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㗻"),[l1l11l_l1_ (u"ࠩࠪ㗼")],[l1111l_l1_]
def l1111l11l_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㗽"):l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ㗾")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ㗿"),url2,data2,headers2,l1l11l_l1_ (u"࠭ࠧ㘀"),l1l11l_l1_ (u"ࠧࠨ㘁"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡃࡅࡈࡔ࠳࠱ࡴࡶࠪ㘂"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ㘃"),html,re.DOTALL|re.IGNORECASE)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡄࡆࡉࡕࠧ㘄"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㘅"),[l1l11l_l1_ (u"ࠬ࠭㘆")],[l1111l_l1_]
def l111llll1ll_l1_(url):
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ㘇"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㘈"),url,l1l11l_l1_ (u"ࠨࠩ㘉"),l1l11l_l1_ (u"ࠩࠪ㘊"),l1l11l_l1_ (u"ࠪࠫ㘋"),l1l11l_l1_ (u"ࠫࠬ㘌"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡖ࡙ࡊ࡚ࡔ࠭࠲ࡵࡷࠫ㘍"))
	html = response.content
	l1lll1lll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡶࡢࡴࠣࡪࡸ࡫ࡲࡷࠢࡀ࠲࠯ࡅࠧࠩ࠰࠭ࡃ࠮࠭ࠢ㘎"),html,re.DOTALL|re.IGNORECASE)
	if l1lll1lll11l_l1_:
		l1lll1lll11l_l1_ = l1lll1lll11l_l1_[0][2:]
		#l1lll1lll11l_l1_ = l1lll1lll11l_l1_.decode(l1l11l_l1_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ㘏"))
		l1lll1lll11l_l1_ = base64.b64decode(l1lll1lll11l_l1_)
		if kodi_version>18.99: l1lll1lll11l_l1_ = l1lll1lll11l_l1_.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭㘐"))
		l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㘑"),l1lll1lll11l_l1_,re.DOTALL)
	else: l1111l_l1_ = l1l11l_l1_ (u"ࠪࠫ㘒")
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡔࡗࡈࡘࡒࠬ㘓"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㘔") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ㘕")+l1111l_l1_
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㘖"),[l1l11l_l1_ (u"ࠨࠩ㘗")],[l1111l_l1_]
def l1llllll1111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㘘"),url,l1l11l_l1_ (u"ࠪࠫ㘙"),l1l11l_l1_ (u"ࠫࠬ㘚"),l1l11l_l1_ (u"ࠬ࠭㘛"),l1l11l_l1_ (u"࠭ࠧ㘜"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡋࡇ࡚ࡘࡌࡔ࠲࠷ࡳࡵࠩ㘝"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠳࠵ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㘞"),html,re.DOTALL)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠭㘟"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㘠"),[l1l11l_l1_ (u"ࠫࠬ㘡")],[l1111l_l1_]
def l1ll1l111l_l1_(url):
	id = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㘢"))[-1]
	if l1l11l_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭㘣") in url: url = url.replace(l1l11l_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ㘤"),l1l11l_l1_ (u"ࠨࠩ㘥"))
	url = url.replace(l1l11l_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࠨ㘦"),l1l11l_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡯ࡨࡸࡦࡪࡡࡵࡣ࠲ࠫ㘧"))
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㘨"),url,l1l11l_l1_ (u"ࠬ࠭㘩"),l1l11l_l1_ (u"࠭ࠧ㘪"),l1l11l_l1_ (u"ࠧࠨ㘫"),l1l11l_l1_ (u"ࠨࠩ㘬"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㘭"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ㘮"),url)
	l1l111l11l1_l1_ = l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ㘯")
	error = re.findall(l1l11l_l1_ (u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㘰"),html,re.DOTALL)
	if error: l1l111l11l1_l1_ = error[0]
	url = re.findall(l1l11l_l1_ (u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㘱"),html,re.DOTALL)
	if not url and l1l111l11l1_l1_:
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㘲"),l1l11l_l1_ (u"ࠨࠩ㘳"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠫ㘴"),l1l111l11l1_l1_)
		return l1l111l11l1_l1_,[],[]
	l1111l_l1_ = url[0].replace(l1l11l_l1_ (u"ࠪࡠࡡ࠭㘵"),l1l11l_l1_ (u"ࠫࠬ㘶"))
	l1l1ll1ll1l_l1_,l1l1lll1l1l_l1_ = l1ll11111l_l1_(l1111l_l1_)
	owner = re.findall(l1l11l_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࠧࡀࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㘷"),html,re.DOTALL)
	if owner: l111l111l11_l1_,l1l11111111_l1_,l11l1ll1l11_l1_ = owner[0]
	else: l111l111l11_l1_,l1l11111111_l1_,l11l1ll1l11_l1_ = l1l11l_l1_ (u"࠭ࠧ㘸"),l1l11l_l1_ (u"ࠧࠨ㘹"),l1l11l_l1_ (u"ࠨࠩ㘺")
	l11l1ll1l11_l1_ = l11l1ll1l11_l1_.replace(l1l11l_l1_ (u"ࠩ࡟࠳ࠬ㘻"),l1l11l_l1_ (u"ࠪ࠳ࠬ㘼"))
	l1l11111111_l1_ = escapeUNICODE(l1l11111111_l1_)
	l1l1lll_l1_ = [l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ㘽")+l1l11111111_l1_+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㘾")]+l1l1ll1ll1l_l1_
	l1ll1l1l_l1_ = [l11l1ll1l11_l1_]+l1l1lll1l1l_l1_
	selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ㘿")+str(len(l1ll1l1l_l1_)-1)+l1l11l_l1_ (u"ࠧࠡ็็ๅ࠮࠭㙀"),l1l1lll_l1_)
	if selection==-1: return l1l11l_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭㙁"),[],[]
	elif selection==0:
		new_path = sys.argv[0]+l1l11l_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨ㙂")+l11l1ll1l11_l1_+l1l11l_l1_ (u"ࠪࠪࡹ࡫ࡸࡵ࠿ࠪ㙃")+l1l11111111_l1_
		settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㙄"),l1l11l_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ㙅"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ㙆")+new_path+l1l11l_l1_ (u"ࠢࠪࠤ㙇"))
		return l1l11l_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭㙈"),[],[]
	l1111l_l1_ =  l1ll1l1l_l1_[selection]
	return l1l11l_l1_ (u"ࠩࠪ㙉"),[l1l11l_l1_ (u"ࠪࠫ㙊")],[l1111l_l1_]
def l11l1l111_l1_(l1111l_l1_):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㙋"),l1111l_l1_,l1l11l_l1_ (u"ࠬ࠭㙌"),l1l11l_l1_ (u"࠭ࠧ㙍"),l1l11l_l1_ (u"ࠧࠨ㙎"),l1l11l_l1_ (u"ࠨࠩ㙏"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨ㙐"))
	html = response.content
	if l1l11l_l1_ (u"ࠪ࠲࡯ࡹ࡯࡯ࠩ㙑") in l1111l_l1_: url = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㙒"),html,re.DOTALL)
	else: url = re.findall(l1l11l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㙓"),html,re.DOTALL)
	if not url: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧ㙔"),[],[]
	url = url[0]
	if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ㙕") not in url: url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ㙖")+url
	return l1l11l_l1_ (u"ࠩࠪ㙗"),[l1l11l_l1_ (u"ࠪࠫ㙘")],[url]
def l11ll1ll11l_l1_(url):
	# http://l1111ll1l1l_l1_.l111lll11ll_l1_/l1l11111lll_l1_.html?l11llll11l1_l1_=l111lll1ll1_l1_
	# http://l1111ll1l1l_l1_.l111lll11ll_l1_/l111l1llll1_l1_?op=l1llll11l11l_l1_&id=l1l11111lll_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㙙") : l1l11l_l1_ (u"ࠬ࠭㙚") }
	if l1l11l_l1_ (u"࠭࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩ㙛") in url:
		html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠧࠨ㙜"),headers,l1l11l_l1_ (u"ࠨࠩ㙝"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫ㙞"))
		#xbmc.log(html)
		#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㙟"),l1l11l_l1_ (u"ࠫࠬ㙠"),url,html)
		items = re.findall(l1l11l_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㙡"),html,re.DOTALL)
		if items: return l1l11l_l1_ (u"࠭ࠧ㙢"),[l1l11l_l1_ (u"ࠧࠨ㙣")],[items[0]]
		else:
			message = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㙤"),html,re.DOTALL)
			if message:
				DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㙥"),l1l11l_l1_ (u"ࠪࠫ㙦"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭㙧"),message[0])
				return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭㙨")+message[0],[],[]
	else:
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㙩"),l1l11l_l1_ (u"ࠧࠨ㙪"),l1111l_l1_,l1l11l_l1_ (u"ࠨࠩ㙫"))
		#url,name2 = url.split(l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㙬"))
		#name2 = name2.lower()
		name2 = l1l11l_l1_ (u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭㙭")
		# l1l1l1111_l1_ l1l1lll1_l1_
		html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠫࠬ㙮"),headers,l1l11l_l1_ (u"ࠬ࠭㙯"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠷ࡴࡤࠨ㙰"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡇࡱࡵࡱࠥࡳࡥࡵࡪࡲࡨࡂࠨࡐࡐࡕࡗࠦࠥࡧࡣࡵ࡫ࡲࡲࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ㙱"),html,re.DOTALL)
		if not l1ll111_l1_: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ㙲"),[],[]
		l111l1ll1_l1_ = l1ll111_l1_[0][0]
		block = l1ll111_l1_[0][1]
		if l1l11l_l1_ (u"ࠩ࠱ࡶࡦࡸࠧ㙳") in block or l1l11l_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ㙴") in block: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡒࡕࡓࡉࡃࡋࡈࡆࠦࡎࡰࡶࠣࡥࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩ㙵"),[],[]
		items = re.findall(l1l11l_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㙶"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l111111l_l1_(payload)
		html = OPENURL_CACHED(l1111lll_l1_,l111l1ll1_l1_,data,headers,l1l11l_l1_ (u"࠭ࠧ㙷"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩ㙸"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿࠭㙹"),html,re.DOTALL)
		if not l1ll111_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭㙺"),[],[]
		download = l1ll111_l1_[0][0]
		block = l1ll111_l1_[0][1]
		items = re.findall(l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪ㙻"),block,re.DOTALL)
		l11ll111l11_l1_,l1l1lll_l1_,l11lll1l111_l1_,l1ll1l1l_l1_,l1111l11l11_l1_ = [],[],[],[],[]
		for l1111l_l1_,title in items:
			if l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㙼") in l1111l_l1_:
				l11ll111l11_l1_,l11lll1l111_l1_ = l1ll11111l_l1_(l1111l_l1_)
				l1ll1l1l_l1_ = l1ll1l1l_l1_ + l11lll1l111_l1_
				if l11ll111l11_l1_[0]==l1l11l_l1_ (u"ࠬ࠳࠱ࠨ㙽"): l1l1lll_l1_.append(l1l11l_l1_ (u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫ㙾")+l1l11l_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥ࠭㙿")+name2)
				else:
					for title in l11ll111l11_l1_:
						l1l1lll_l1_.append(l1l11l_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭㚀")+l1l11l_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ㚁")+name2+l1l11l_l1_ (u"ࠪࠤࠬ㚂")+title)
			else:
				title = title.replace(l1l11l_l1_ (u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭㚃"),l1l11l_l1_ (u"ࠬ࠭㚄"))
				title = title.strip(l1l11l_l1_ (u"࠭ࠢࠨ㚅"))
				#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㚆"),l1l11l_l1_ (u"ࠨࠩ㚇"),title,str(l1111l11l11_l1_))
				title = l1l11l_l1_ (u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨ㚈")+l1l11l_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ㚉")+name2+l1l11l_l1_ (u"ࠫࠥ࠭㚊")+title
				l1l1lll_l1_.append(title)
				l1ll1l1l_l1_.append(l1111l_l1_)
		# download l1l1lll1_l1_
		l1111l_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ㚋") + download
		html = OPENURL_CACHED(l1111lll_l1_,l1111l_l1_,l1l11l_l1_ (u"࠭ࠧ㚌"),headers,l1l11l_l1_ (u"ࠧࠨ㚍"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪ㚎"))
		items = re.findall(l1l11l_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨ㚏"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l11l_l1_ (u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧ㚐")+l1l11l_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ㚑")+name2+l1l11l_l1_ (u"ࠬࠦࠧ㚒")+resolution.split(l1l11l_l1_ (u"࠭ࡸࠨ㚓"))[1]
			l1111l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ㚔")+id+l1l11l_l1_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ㚕")+mode+l1l11l_l1_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ㚖")+hash
			l1111l11l11_l1_.append(resolution)
			l1l1lll_l1_.append(title)
			l1ll1l1l_l1_.append(l1111l_l1_)
		l1111l11l11_l1_ = set(l1111l11l11_l1_)
		l1111lll11l_l1_,l11l1lll111_l1_ = [],[]
		for title in l1l1lll_l1_:
			#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㚗"),l1l11l_l1_ (u"ࠫࠬ㚘"),title,l1l11l_l1_ (u"ࠬ࠭㚙"))
			res = re.findall(l1l11l_l1_ (u"ࠨࠠࠩ࡞ࡧ࠮ࡽࢂ࡜ࡥࠬࠬࠪࠫࠨ㚚"),title+l1l11l_l1_ (u"ࠧࠧࠨࠪ㚛"),re.DOTALL)
			for resolution in l1111l11l11_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l11l_l1_ (u"ࠨࡺࠪ㚜"))[1])
			l1111lll11l_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1ll1l1l_l1_)):
			items = re.findall(l1l11l_l1_ (u"ࠤࠩࠪ࠭࠴ࠪࡀࠫࠫࡠࡩ࠰ࠩࠧࠨࠥ㚝"),l1l11l_l1_ (u"ࠪࠪࠫ࠭㚞")+l1111lll11l_l1_[i]+l1l11l_l1_ (u"ࠫࠫࠬࠧ㚟"),re.DOTALL)
			l11l1lll111_l1_.append( [l1111lll11l_l1_[i],l1ll1l1l_l1_[i],items[0][0],items[0][1]] )
		l11l1lll111_l1_ = sorted(l11l1lll111_l1_, key=lambda x: x[3], reverse=True)
		l11l1lll111_l1_ = sorted(l11l1lll111_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
		for i in range(len(l11l1lll111_l1_)):
			l1l1lll_l1_.append(l11l1lll111_l1_[i][0])
			l1ll1l1l_l1_.append(l11l1lll111_l1_[i][1])
	if len(l1ll1l1l_l1_)==0: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ㚠"),[],[]
	return l1l11l_l1_ (u"࠭ࠧ㚡"),l1l1lll_l1_,l1ll1l1l_l1_
def l11ll11111l_l1_(url):
	# http://l1llll11l111_l1_.l11111ll_l1_/717254
	parts = url.split(l1l11l_l1_ (u"ࠧࡀࠩ㚢"))
	url2 = parts[0]
	headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㚣") : l1l11l_l1_ (u"ࠩࠪ㚤") }
	html = OPENURL_CACHED(l1111lll_l1_,url2,l1l11l_l1_ (u"ࠪࠫ㚥"),headers,l1l11l_l1_ (u"ࠫࠬ㚦"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࠸ࡘࡘࡇࡒ࠮࠳ࡶࡸࠬ㚧"))
	items = re.findall(l1l11l_l1_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡷࡢ࡫ࡷ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ㚨"),html,re.DOTALL)
	url = items[0]
	#l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lllll1lll1_l1_(url)
	#return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㚩"),[l1l11l_l1_ (u"ࠨࠩ㚪")],[url]
def l111l1ll111_l1_(url):
	# l11l11l_l1_://l11l111l1l_l1_.l111lll11l_l1_/l11l11l111_l1_
	# l11l11l_l1_://l111lll1l1_l1_.cc/l11l11l111_l1_
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	headers = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㚫") : l1l11l_l1_ (u"ࠪࠫ㚬") }
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠫࠬ㚭"),headers,l1l11l_l1_ (u"ࠬ࠭㚮"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ㚯"))
	url2 = re.findall(l1l11l_l1_ (u"ࠧࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡࡸࡶࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㚰"),html,re.DOTALL)
	if url2: return l1l11l_l1_ (u"ࠨࠩ㚱"),[l1l11l_l1_ (u"ࠩࠪ㚲")],[url2[0]]
	else: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡕ࡛࡜࡙ࡖࡑ࠭㚳"),[],[]
def l11ll111l1l_l1_(url):
	# l11l11l_l1_://l11l111l1l_l1_.l111lll11l_l1_/l11l11l111_l1_
	# l11l11l_l1_://l111lll1l1_l1_.cc/l11l11l111_l1_
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㚴") : l1l11l_l1_ (u"ࠬ࠭㚵") }
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"࠭ࠧ㚶"),headers,l1l11l_l1_ (u"ࠧࠨ㚷"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ㚸"))
	url2 = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࡬ࡹࡺ࠮ࠫࡁࠬࠦࠬ㚹"),html,re.DOTALL)
	if url2: return l1l11l_l1_ (u"ࠪࠫ㚺"),[l1l11l_l1_ (u"ࠫࠬ㚻")],[url2[0]]
	else: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠭㚼"),[],[]
def l111111l1l_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㚽"),l1l11l_l1_ (u"ࠧࠨ㚾"),l1l11l_l1_ (u"ࠨࠩ㚿"),url)
	# l1l1l1111_l1_    l11l11l_l1_://show.l111l11l11l_l1_.l11111ll_l1_/l1111lllll1_l1_-l1111lll1l1_l1_/l1111lll1l1_l1_-l11l11l1l1l_l1_.l1lllllll1_l1_?action=l1111l11l1l_l1_&l111l1llll_l1_=32513&l111111ll1_l1_=1&type=l11l111ll1_l1_
	# download l11l11l_l1_://show.l111l11l11l_l1_.l11111ll_l1_/l1l1lll1_l1_/l1lllll1l1ll_l1_
	l1l1lll_l1_,l1ll1l1l_l1_,errno = [],[],l1l11l_l1_ (u"ࠩࠪ㛀")
	# l1l1l1111_l1_
	if l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ㛁") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㛂"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ㛃")}
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㛄"),url2,data2,headers2,l1l11l_l1_ (u"ࠧࠨ㛅"),l1l11l_l1_ (u"ࠨࠩ㛆"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬ㛇"))
		l1ll1ll1_l1_ = response.content
		url2 = re.findall(l1l11l_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫ㛈"),l1ll1ll1_l1_,re.DOTALL)
		url2 = url2[0]
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㛉"),l1l11l_l1_ (u"ࠬ࠭㛊"),l1l11l_l1_ (u"࠭ࠧ㛋"),url2)
		#return
	# download
	elif l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡲࡰࡹ࠯ࠨ㛌") in url:
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ㛍"),url,l1l11l_l1_ (u"ࠩࠪ㛎"),l1l11l_l1_ (u"ࠪࠫ㛏"),True,l1l11l_l1_ (u"ࠫࠬ㛐"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨ㛑"))
		l1ll1ll1_l1_ = response.content
		if l1l11l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㛒") in list(response.headers.keys()): url2 = response.headers[l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㛓")]
		else: url2 = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㛔"),l1ll1ll1_l1_,re.DOTALL)[0]
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㛕"),l1l11l_l1_ (u"ࠪࠫ㛖"),url2,str(2222))
	if l1l11l_l1_ (u"ࠫ࠴ࡼ࠯ࠨ㛗") in url2 or l1l11l_l1_ (u"ࠬ࠵ࡦ࠰ࠩ㛘") in url2:
		url2 = url2.replace(l1l11l_l1_ (u"࠭࠯ࡧ࠱ࠪ㛙"),l1l11l_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭㛚"))
		url2 = url2.replace(l1l11l_l1_ (u"ࠨ࠱ࡹ࠳ࠬ㛛"),l1l11l_l1_ (u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ㛜"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㛝"),l1l11l_l1_ (u"ࠫࠬ㛞"),url2,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ㛟"),url2,l1l11l_l1_ (u"࠭ࠧ㛠"),l1l11l_l1_ (u"ࠧࠨ㛡"),l1l11l_l1_ (u"ࠨࠩ㛢"),l1l11l_l1_ (u"ࠩࠪ㛣"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭㛤"))
		l1ll1ll1_l1_ = response.content
		items = re.findall(l1l11l_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㛥"),l1ll1ll1_l1_,re.DOTALL)
		if items:
			for l1111l_l1_,title in items:
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࡜ࠨ㛦"),l1l11l_l1_ (u"࠭ࠧ㛧"))
				l1l1lll_l1_.append(title)
				l1ll1l1l_l1_.append(l1111l_l1_)
		else:
			items = re.findall(l1l11l_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㛨"),l1ll1ll1_l1_,re.DOTALL)
			if items:
				l1111l_l1_ = items[0]
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠨ࡞࡟ࠫ㛩"),l1l11l_l1_ (u"ࠩࠪ㛪"))
				l1l1lll_l1_.append(l1l11l_l1_ (u"ࠪࠫ㛫"))
				l1ll1l1l_l1_.append(l1111l_l1_)
	else: return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㛬"),[l1l11l_l1_ (u"ࠬ࠭㛭")],[url2]
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㛮"),l1l11l_l1_ (u"ࠧࠨ㛯"),str(data2),url2)
	if len(l1ll1l1l_l1_)==0: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㛰"),[],[]
	return l1l11l_l1_ (u"ࠩࠪ㛱"),l1l1lll_l1_,l1ll1l1l_l1_
def l1l1ll1l1ll_l1_(url):
	# l1l1l1111_l1_ l11lll1l_l1_  l11l11l_l1_://l1l11111l11_l1_.l111l111l1l_l1_.l111lll11l_l1_/l11111ll1ll_l1_/l1lll1ll1l1l_l1_.l1lllllll1_l1_?s=07&id=l1lllll1l1l1_l1_,&img=2wh9shmvcTypozADtS8EpvgrwWS.l11111lll11_l1_&l11l1l1lll1_l1_=l1llll1l1l1l_l1_&l111l1l11l1_l1_=l1llll11111l_l1_
	# l1l1l1111_l1_ l11l1111_l1_ l11l11l_l1_://l11lll1l11l_l1_.l111l111l1l_l1_.l111lll11l_l1_/l11111ll1ll_l1_/l1llll1llll1_l1_.l1lllllll1_l1_?l11ll11ll1l_l1_=l1111ll1ll1_l1_&l11l111111l_l1_=8a26a6cc61a884e89076504130c71626&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l11111lll11_l1_&l11l1l1lll1_l1_=l1llll1l1l1l_l1_&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l11111lll11_l1_&l11l1l1lll1_l1_=l1llll1l1l1l_l1_&l111l1l11l1_l1_=l1111111ll1_l1_
	# download l11l11l_l1_://l1llllll1ll1_l1_.l11ll1ll111_l1_.l1111llllll_l1_/l11l1ll1l1l_l1_?server=l1llll1lll11_l1_&id=l11l11l1111_l1_,,
	# l1l11111l_l1_ l11l11l_l1_://l11ll1ll111_l1_.l111111l1_l1_/l1l11111l_l1_/l11l1l11lll_l1_
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㛲"),url,l1l11l_l1_ (u"ࠫࠬ㛳"),l1l11l_l1_ (u"ࠬ࠭㛴"),l1l11l_l1_ (u"࠭ࠧ㛵"),l1l11l_l1_ (u"ࠧࠨ㛶"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠶ࡹࡴࠨ㛷"))
	html = response.content
	l1l1lll_l1_,l1ll1l1l_l1_,errno = [],[],l1l11l_l1_ (u"ࠩࠪ㛸")
	if l1l11l_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭㛹") in url or l1l11l_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ㛺") in url:
		if l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ㛻") in url:
			url2 = re.findall(l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㛼"),html,re.DOTALL)
			url2 = url2[0]
		else: url2 = url
		if l1l11l_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ㛽") not in url2: return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㛾"),[l1l11l_l1_ (u"ࠩࠪ㛿")],[url2]
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㜀"),url2,l1l11l_l1_ (u"ࠫࠬ㜁"),l1l11l_l1_ (u"ࠬ࠭㜂"),l1l11l_l1_ (u"࠭ࠧ㜃"),l1l11l_l1_ (u"ࠧࠨ㜄"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠷ࡴࡤࠨ㜅"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࡭ࡷࠬ㜆"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㜇"),block,re.DOTALL)
		if items:
			for l1111l_l1_,l111l111lll_l1_ in items:
				l1l1lll_l1_.append(l111l111lll_l1_)
				l1ll1l1l_l1_.append(l1111l_l1_)
	elif l1l11l_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵ࠭㜈") in url:
		url2 = re.findall(l1l11l_l1_ (u"ࠬࡻࡲ࡭࠿ࠫ࠲࠯ࡅࠩࠣࠩ㜉"),html,re.DOTALL)
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㜊"),url2,l1l11l_l1_ (u"ࠧࠨ㜋"),l1l11l_l1_ (u"ࠨࠩ㜌"),l1l11l_l1_ (u"ࠩࠪ㜍"),l1l11l_l1_ (u"ࠪࠫ㜎"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ㜏"))
		html = response.content
		url3 = re.findall(l1l11l_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㜐"),html,re.DOTALL)
		url3 = url3[0]
		l1l1lll_l1_.append(l1l11l_l1_ (u"࠭ࠧ㜑"))
		l1ll1l1l_l1_.append(url3)
	elif l1l11l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧ㜒") in url:
		url2 = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㜓"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			return l1l11l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㜔"),[l1l11l_l1_ (u"ࠪࠫ㜕")],[url2]
	if len(l1ll1l1l_l1_)==0: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡘࡖ࠸࡚࠭㜖"),[],[]
	return l1l11l_l1_ (u"ࠬ࠭㜗"),l1l1lll_l1_,l1ll1l1l_l1_
def l11ll1l11l_l1_(url):
	# l11l11l_l1_://l11ll111lll_l1_.l111l11ll11_l1_/l11lll1ll1l_l1_?call=l11l1l1l1l1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11llll11l1_l1_=l111lll11l1_l1_
	# l11l11l_l1_://l11ll111lll_l1_.l111l11ll11_l1_/l11lll1ll1l_l1_?call=l11l1l1l1l1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11llll11l1_l1_=l1111llll1l_l1_
	url2 = url.split(l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㜘"),1)[0].strip(l1l11l_l1_ (u"ࠧࡀࠩ㜙")).strip(l1l11l_l1_ (u"ࠨ࠱ࠪ㜚")).strip(l1l11l_l1_ (u"ࠩࠩࠫ㜛"))
	l1l1lll_l1_,l1ll1l1l_l1_,items,url3 = [],[],[],l1l11l_l1_ (u"ࠪࠫ㜜")
	headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㜝"):l1l11l_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬ㜞") }
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㜟"),url2,l1l11l_l1_ (u"ࠧࠨ㜠"),headers,True,l1l11l_l1_ (u"ࠨࠩ㜡"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪ㜢"))
	if l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㜣") in list(response.headers.keys()): url3 = response.headers[l1l11l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㜤")]
	#response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㜥"),url3,l1l11l_l1_ (u"࠭ࠧ㜦"),headers,False,l1l11l_l1_ (u"ࠧࠨ㜧"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠸࡮ࡥࠩ㜨"))
	#if l1l11l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㜩") in response.headers: url3 = response.headers[l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㜪")]
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㜫"),l1l11l_l1_ (u"ࠬ࠭㜬"),url3,response.content)
	if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ㜭") in url3:
		# l11l11l_l1_://l11lll1111_l1_.top/f/l11l11ll1l1_l1_/?l1l11l11ll_l1_=l1l11l11111_l1_
		# l11l11l_l1_://l11lll1111_l1_.top/v/l11l11ll1l1_l1_/?l1l11l11ll_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ㜮") in url: url3 = url3.replace(l1l11l_l1_ (u"ࠨ࠱ࡩ࠳ࠬ㜯"),l1l11l_l1_ (u"ࠩ࠲ࡺ࠴࠭㜰"))
		l11llll1lll_l1_ = url2.split(l1l11l_l1_ (u"ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬ㜱"))[1]
		headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㜲"):headers[l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㜳")] , l1l11l_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭㜴"):l1l11l_l1_ (u"ࠧࡑࡊࡓࡗࡎࡊ࠽ࠨ㜵")+l11llll1lll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ㜶"),url3,l1l11l_l1_ (u"ࠩࠪ㜷"),headers,False,l1l11l_l1_ (u"ࠪࠫ㜸"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㜹"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1111lll_l1_,url3,l1l11l_l1_ (u"ࠬ࠭㜺"),headers,l1l11l_l1_ (u"࠭ࠧ㜻"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠸ࡸࡤࠨ㜼"))
		if l1l11l_l1_ (u"ࠨ࠱ࡩ࠳ࠬ㜽") in url3: items = re.findall(l1l11l_l1_ (u"ࠩ࠿࡬࠷ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㜾"),html,re.DOTALL)
		elif l1l11l_l1_ (u"ࠪ࠳ࡻ࠵ࠧ㜿") in url3: items = re.findall(l1l11l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㝀"),html,re.DOTALL)
		if items: return [],[l1l11l_l1_ (u"ࠬ࠭㝁")],[ items[0] ]
		elif l1l11l_l1_ (u"࠭࠼ࡩ࠳ࡁ࠸࠵࠺࠼࠰ࡪ࠴ࡂࠬ㝂") in html:
			return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠิ์ิๅึࠦวๅใํำ๏๎ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯฺ๋๋้ࠢีั่่๊ࠢࠥอไฦ่อี๋ะࠠศๆัหฺฯࠠษๅࠪ㝃"),[],[]
	else: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗࠫ㝄"),[],[]
	#xbmc.log(html)
def l11l1llllll_l1_(l1111l_l1_):
	# l11l11l_l1_://l1l11l111ll_l1_.l111ll1_l1_/?l1ll1lll_l1_=147043&l1lll11l_l1_=5
	parts = re.findall(l1l11l_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ㝅"),l1111l_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭㝆"),re.DOTALL|re.IGNORECASE)
	l1ll1lll_l1_,l1lll11l_l1_ = parts[0]
	url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ㝇")+l1ll1lll_l1_+l1l11l_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ㝈")+l1lll11l_l1_
	headers = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㝉"):l1l11l_l1_ (u"ࠧࠨ㝊") , l1l11l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ㝋"):l1l11l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ㝌") }
	url2 = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠪࠫ㝍"),headers,l1l11l_l1_ (u"ࠫࠬ㝎"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭࠲ࡵࡷࠫ㝏"))
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㝐"),l1l11l_l1_ (u"ࠧࠨ㝑"),url,url2)
	#l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lllll1lll1_l1_(url2)
	#return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㝒"),[l1l11l_l1_ (u"ࠩࠪ㝓")],[url2]
def l1l1ll1l11l_l1_(url):
	# l11l11l_l1_://l1llll111l1l_l1_.l1l1llll11_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l11l11ll11l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l1lllll1_l1_=1608181746
	server = SERVER(url,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ㝔"))
	headers2 = {l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㝕"):server,l1l11l_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ㝖"):l1l11l_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭㝗")}
	response = OPENURL_REQUESTS_CACHED(l1l11ll11ll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㝘"),url,l1l11l_l1_ (u"ࠨࠩ㝙"),headers2,l1l11l_l1_ (u"ࠩࠪ㝚"),l1l11l_l1_ (u"ࠪࠫ㝛"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ㝜"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭㝝"),html,re.DOTALL)
	url2 = l1l11l_l1_ (u"࠭ࠧ㝞")
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㝟"),block,re.DOTALL)
		l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
		for title,l1111l_l1_ in items:
			l1l1lll_l1_.append(title)
			l1ll1l1l_l1_.append(l1111l_l1_)
		if len(l1ll1l1l_l1_)==1: url2 = l1ll1l1l_l1_[0]
		elif len(l1ll1l1l_l1_)>1:
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭㝠"), l1l1lll_l1_)
			if selection==-1: return l1l11l_l1_ (u"ࠩࠪ㝡"),[],[]
			url2 = l1ll1l1l_l1_[selection]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㝢"),html,re.DOTALL)
		if l1ll111_l1_: url2 = l1ll111_l1_[0]
	if not url2: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡅࡌࡑࡆ࠭㝣"),[],[]
	return l1l11l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㝤"),[l1l11l_l1_ (u"࠭ࠧ㝥")],[url2]
def l111111l111_l1_(url):
	# l11l11l_l1_://l1l11l11l11_l1_.l1lllll1llll_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l11l11ll11l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l1lllll1_l1_=1608181746
	# l11l11l_l1_://l1l11l11l11_l1_.l111l11ll11_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l11l11ll11l_l1_=l1l1111l1ll_l1_&l11l1lllll1_l1_=1684182121
	server = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㝦"))
	headers2 = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㝧"):server,l1l11l_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ㝨"):l1l11l_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ㝩")}
	response = OPENURL_REQUESTS_CACHED(l1l11ll11ll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㝪"),url,l1l11l_l1_ (u"ࠬ࠭㝫"),headers2,l1l11l_l1_ (u"࠭ࠧ㝬"),l1l11l_l1_ (u"ࠧࠨ㝭"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ㝮"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ㝯"),html,re.DOTALL)
	url2 = l1l11l_l1_ (u"ࠪࠫ㝰")
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ㝱"),block,re.DOTALL)
		l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
		for title,l1111l_l1_ in items:
			l1l1lll_l1_.append(title)
			l1ll1l1l_l1_.append(l1111l_l1_)
		if len(l1ll1l1l_l1_)==1: url2 = l1ll1l1l_l1_[0]
		elif len(l1ll1l1l_l1_)>1:
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ㝲"), l1l1lll_l1_)
			if selection==-1: return l1l11l_l1_ (u"࠭ࠧ㝳"),[],[]
			url2 = l1ll1l1l_l1_[selection]
	if not url2:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㝴"),html,re.DOTALL)
		if l1ll111_l1_: url2 = l1ll111_l1_[0]
	if not url2: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪ㝵"),[],[]
	return l1l11l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㝶"),[l1l11l_l1_ (u"ࠪࠫ㝷")],[url2]
def l11111l_l1_(l1111l_l1_):
	# l11l11l_l1_://w.l1111l1lll1_l1_.l11ll1lll1l_l1_/l1111lllll1_l1_-content/l1l111l1l11_l1_/l1111l1l11l_l1_/l11ll1ll1ll_l1_/l1111l1l111_l1_/l111ll1ll11_l1_/l1111llll11_l1_.l1lllllll1_l1_?l1ll1lll_l1_=42869&l1lll11l_l1_=4
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㝸"),l1l11l_l1_ (u"ࠬ࠭㝹"),l1111l_l1_,html)
	parts = re.findall(l1l11l_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ㝺"),l1111l_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪ㝻"),re.DOTALL)
	url,l1ll1lll_l1_,l1lll11l_l1_ = parts[0]
	data = {l1l11l_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩ㝼"):l1ll1lll_l1_,l1l11l_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ㝽"):l1lll11l_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㝾"),url,data,l1l11l_l1_ (u"ࠫࠬ㝿"),l1l11l_l1_ (u"ࠬ࠭㞀"),l1l11l_l1_ (u"࠭ࠧ㞁"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵࠩ㞂"))
	html = response.content
	url2 = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㞃"),html,re.DOTALL)[0]
	return l1l11l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㞄"),[l1l11l_l1_ (u"ࠪࠫ㞅")],[url2]
def l1llll1ll1_l1_(url):
	# l11l11l_l1_://l11l1lll1l1_l1_.l1111111l_l1_-l11ll111ll1_l1_.l11111ll_l1_/l1l11111l_l1_.l1lllllll1_l1_?l1111111lll_l1_=l111l1l1l11_l1_
	# l11l11l_l1_://l.l111l1111l1_l1_.l1111llllll_l1_/l1l11111l_l1_.l1lllllll1_l1_?l1111111lll_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㞆"),url,l1l11l_l1_ (u"ࠬ࠭㞇"),l1l11l_l1_ (u"࠭ࠧ㞈"),l1l11l_l1_ (u"ࠧࠨ㞉"),l1l11l_l1_ (u"ࠨࠩ㞊"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮࠳ࡶࡸࠬ㞋"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㞌"),html,re.DOTALL)
	if l1111l_l1_:
		l1111l_l1_ = l1111l_l1_[0]
		if l1111l_l1_: return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㞍"),[l1l11l_l1_ (u"ࠬ࠭㞎")],[l1111l_l1_]
	return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㞏"),[],[]
def l11111l11_l1_(url):
	# l11l11l_l1_://l11111111_l1_.l1111111l_l1_-l111111l1_l1_.l111111l1_l1_/l1111lllll1_l1_-content/l1l111l1l11_l1_/old/l1lllll11111_l1_/server.l1lllllll1_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㞐"),url,l1l11l_l1_ (u"ࠨࠩ㞑"),l1l11l_l1_ (u"ࠩࠪ㞒"),l1l11l_l1_ (u"ࠪࠫ㞓"),l1l11l_l1_ (u"ࠫࠬ㞔"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡒ࠰࠵ࡸࡺࠧ㞕"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡊࡈࡕࡅࡒࡋࠠࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㞖"),html,re.DOTALL)[0]
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㞗"),[l1l11l_l1_ (u"ࠨࠩ㞘")],[l1111l_l1_]
def l1llll1l1l_l1_(url):
	# l11l11l_l1_://l11l1l11l11_l1_.l1llll1ll1l1_l1_.cc/l1111lllll1_l1_-content/l1l111l1l11_l1_/l1llllllllll_l1_%20Now%20New/l1lllll1l111_l1_.l1lllllll1_l1_?action=l11ll1111l1_l1_&index=00&id=58504
	# l11l11l_l1_://l11l11ll111_l1_.l1llll1ll1l1_l1_.l111ll1_l1_/l11l1l11ll1_l1_/2021/04/05/_111l1l1ll1_l1_-l1l111llll1_l1_.l1lll1ll1lll_l1_ 200.l1lllll111l1_l1_.2020.l1llllll11ll_l1_/[l1llllllllll_l1_-l1l111llll1_l1_.l111111llll_l1_] 200.l1lllll111l1_l1_.2020.l1llllll11ll_l1_-360p.l11lll1l_l1_
	l111l1l1l_l1_ = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㞙"))
	if l1l11l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ㞚") in url:
		headers = {l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㞛"):l111l1l1l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㞜"),url,l1l11l_l1_ (u"࠭ࠧ㞝"),headers,l1l11l_l1_ (u"ࠧࠨ㞞"),l1l11l_l1_ (u"ࠨࠩ㞟"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ㞠"))
		html = response.content
		url2 = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㞡"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			if l1l11l_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ㞢") in url2:
				url2 = url2.replace(l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ㞣"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ㞤"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㞥"),url2,l1l11l_l1_ (u"ࠨࠩ㞦"),headers,l1l11l_l1_ (u"ࠩࠪ㞧"),l1l11l_l1_ (u"ࠪࠫ㞨"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ㞩"))
				l1ll1ll1_l1_ = response.content
				items = re.findall(l1l11l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㞪"),l1ll1ll1_l1_,re.DOTALL)
				l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
				l111l1l11_l1_ = SERVER(url2,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㞫"))
				for l1111l_l1_,l1l1l111_l1_ in reversed(items):
					l1111l_l1_ = l111l1l11_l1_+l1111l_l1_+l1l11l_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ㞬")+l111l1l11_l1_
					l1l1lll_l1_.append(l1l1l111_l1_)
					l1ll1l1l_l1_.append(l1111l_l1_)
				return l1l11l_l1_ (u"ࠨࠩ㞭"),l1l1lll_l1_,l1ll1l1l_l1_
			else: return l1l11l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㞮"),[l1l11l_l1_ (u"ࠪࠫ㞯")],[url2]
	url2 = url+l1l11l_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ㞰")+l111l1l1l_l1_
	return l1l11l_l1_ (u"ࠬ࠭㞱"),[l1l11l_l1_ (u"࠭ࠧ㞲")],[url2]
def l111lllll1l_l1_(l1111l_l1_):
	# l11l11l_l1_://l1llll1ll1l1_l1_.l11ll1lll1l_l1_/l1111lllll1_l1_-content/l1l111l1l11_l1_/l11ll111111_l1_/l1lllll1ll11_l1_/server.l1lllllll1_l1_?l1ll1lll_l1_=42869&l1lll11l_l1_=4
	# l11l11l_l1_://l11lll1l1ll_l1_.l1llll1ll1l1_l1_.l111ll1_l1_/l11l1l11ll1_l1_/2020/08/14/_111l1l1ll1_l1_-l1l111llll1_l1_.l1lll1ll1lll_l1_ l1llllllll1l_l1_.l111lll1l1l_l1_.2020.l111l1lllll_l1_-l111llll1l1_l1_/[l1llllllllll_l1_-l1l111llll1_l1_.l111111llll_l1_] l1llllllll1l_l1_.l111lll1l1l_l1_.2020.l111l1lllll_l1_-l111llll1l1_l1_-1080p.l11lll1l_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㞳"),l1l11l_l1_ (u"ࠨࠩ㞴"),url,html)
	l111l1l1l_l1_ = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㞵"))
	if l1l11l_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࠪ㞶") in l1111l_l1_:
		parts = re.findall(l1l11l_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ㞷"),l1111l_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨ㞸"),re.DOTALL)
		url,l1ll1lll_l1_,l1lll11l_l1_ = parts[0]
		data = {l1l11l_l1_ (u"࠭ࡩࡥࠩ㞹"):l1ll1lll_l1_,l1l11l_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ㞺"):l1lll11l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭㞻"),url,data,l1l11l_l1_ (u"ࠩࠪ㞼"),l1l11l_l1_ (u"ࠪࠫ㞽"),l1l11l_l1_ (u"ࠫࠬ㞾"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭㞿"))
		html = response.content
		url2 = re.findall(l1l11l_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㟀"),html,re.DOTALL)[0]
		if l1l11l_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ㟁") in url2:
			headers = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㟂"):l111l1l1l_l1_,l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㟃"):l1l11l_l1_ (u"ࠪࠫ㟄")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㟅"),url2,l1l11l_l1_ (u"ࠬ࠭㟆"),headers,l1l11l_l1_ (u"࠭ࠧ㟇"),l1l11l_l1_ (u"ࠧࠨ㟈"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ㟉"))
			l1ll1ll1_l1_ = response.content
			items = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㟊"),l1ll1ll1_l1_,re.DOTALL)
			l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
			l111l1l11_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ㟋"))
			for l1111l_l1_,l1l1l111_l1_ in reversed(items):
				l1111l_l1_ = l111l1l11_l1_+l1111l_l1_+l1l11l_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ㟌")+l111l1l11_l1_
				l1l1lll_l1_.append(l1l1l111_l1_)
				l1ll1l1l_l1_.append(l1111l_l1_)
			return l1l11l_l1_ (u"ࠬ࠭㟍"),l1l1lll_l1_,l1ll1l1l_l1_
		else: return l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㟎"),[l1l11l_l1_ (u"ࠧࠨ㟏")],[url2]
	else:
		l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ㟐")+l111l1l1l_l1_
		return l1l11l_l1_ (u"ࠩࠪ㟑"),[l1l11l_l1_ (u"ࠪࠫ㟒")],[l1111l_l1_]
def l11llll11_l1_(l1111l_l1_):
	# http://l1l11111ll1_l1_.tv/?l1ll1lll_l1_=159485&l1lll11l_l1_=0
	if l1l11l_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ㟓") in l1111l_l1_:
		parts = re.findall(l1l11l_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ㟔"),l1111l_l1_+l1l11l_l1_ (u"࠭ࠦࠧࠩ㟕"),re.DOTALL|re.IGNORECASE)
		l1ll1lll_l1_,l1lll11l_l1_ = parts[0]
		host = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㟖"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㟗"),l1l11l_l1_ (u"ࠩࠪ㟘"),l1111l_l1_,host)
		url = host+l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ㟙")+l1ll1lll_l1_+l1l11l_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ㟚")+l1lll11l_l1_
		headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㟛"):l1l11l_l1_ (u"࠭ࠧ㟜") , l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ㟝"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ㟞") }
		url2 = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠩࠪ㟟"),headers,l1l11l_l1_ (u"ࠪࠫ㟠"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠴ࡷࡹ࠭㟡"))
		url2 = url2.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ㟢"),l1l11l_l1_ (u"࠭ࠧ㟣")).replace(l1l11l_l1_ (u"ࠧ࡝ࡴࠪ㟤"),l1l11l_l1_ (u"ࠨࠩ㟥"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㟦"),l1l11l_l1_ (u"ࠪࠫ㟧"),url,url2)
		#l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1lllll1lll1_l1_(url2)
		#return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
		return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㟨"),[l1l11l_l1_ (u"ࠬ࠭㟩")],[url2]
	elif l1l11l_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ㟪") in l1111l_l1_:
		counts = 0
		while l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ㟫") in l1111l_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ㟬"),l1111l_l1_,l1l11l_l1_ (u"ࠩࠪ㟭"),l1l11l_l1_ (u"ࠪࠫ㟮"),l1l11l_l1_ (u"ࠫࠬ㟯"),l1l11l_l1_ (u"ࠬ࠭㟰"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠷ࡴࡤࠨ㟱"))
			if l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㟲") in list(response.headers.keys()): l1111l_l1_ = response.headers[l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㟳")]
			counts += 1
		return l1l11l_l1_ (u"ࠩࠪ㟴"),[l1l11l_l1_ (u"ࠪࠫ㟵")],[l1111l_l1_]
	else: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㟶"),[],[]
def l1l11l1ll_l1_(url):
	# l11l11l_l1_://l111l11ll1l_l1_.l111111ll11_l1_.me/l/l1l1111lll1_l1_=
	server = SERVER(url,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㟷"))
	headers = {l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㟸"):server,l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㟹"):l1ll1111l_l1_()}
	if l1l11l_l1_ (u"ࠨ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭㟺") in url:
		headers2 = {l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㟻"):l1l11l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㟼")}
		url2,data2 = URLDECODE(url)
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㟽"),url2,data2,headers2,True,l1l11l_l1_ (u"ࠬ࠭㟾"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠶ࡹࡴࠨ㟿"))
		html = response.content
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㠀"),html,re.DOTALL|re.IGNORECASE)
		if l1l1lll1_l1_: return l1l11l_l1_ (u"ࠨࠩ㠁"),[l1l11l_l1_ (u"ࠩࠪ㠂")],[l1l1lll1_l1_[0]]
	elif l1l11l_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ㠃") in url:
		html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠫࠬ㠄"),headers,l1l11l_l1_ (u"ࠬ࠭㠅"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨ㠆"))
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㠇"),html,re.DOTALL)
		if l1l1lll1_l1_: return l1l11l_l1_ (u"ࠨࠩ㠈"),[l1l11l_l1_ (u"ࠩࠪ㠉")],[l1l1lll1_l1_[0]]
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㠊"),url,l1l11l_l1_ (u"ࠫࠬ㠋"),headers,l1l11l_l1_ (u"ࠬ࠭㠌"),l1l11l_l1_ (u"࠭ࠧ㠍"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ㠎"))
		if l1l11l_l1_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ㠏") in list(response.headers.keys()):
			cookies = response.headers[l1l11l_l1_ (u"ࠩࡶࡩࡹ࠳ࡣࡰࡱ࡮࡭ࡪ࠭㠐")]
			l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡣࡱࡴ࡫ࡠ࠰࠭ࡃࡂ࠮࠮ࠫࡁࠬ࠿ࠬ㠑"),cookies,re.DOTALL)
			if l1l1lll1_l1_:
				l1111l_l1_ = UNQUOTE(l1l1lll1_l1_[0])
				return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㠒"),[l1l11l_l1_ (u"ࠬ࠭㠓")],[l1111l_l1_]
	return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㠔"),[],[]
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠩࠠ࡯ࡱࡷࠤࡼࡵࡲ࡬࡫ࡱ࡫ࠏࠏࠉࠤࠢ࡬ࡸࠥࡴࡥࡦࡦࡶࠤࡨࡵ࡯࡬࡫ࡨࠤ࡫ࡸ࡯࡮ࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠐࠉࠊࠥࠣࡇࡴࡵ࡫ࡪࡧ࠽ࠤࡨ࡬࡟ࡤ࡮ࡨࡥࡷࡧ࡮ࡤࡧࡀࡇࡒ࡫࠮ࡉࡍࡊࡕࡰࡳࡷ࡯ࡕ࡙ࡹࡳࢀࡖࡊࡲࡴࡳࡼࡷࡓࡂ࡜ࡦࡴࡳࡌ࠷࡫ࡄࡓ࡙ࡔࡗࡢ࡚ࡄࡉ࠴࠲࠷࠶࠷࠵࠴࠵࠷࠶࠰࠷࠯࠳࠱࠷࠻࠰ࠋࠋࠌࡷࡪࡸࡶࡦࡴࠣࡁ࡙ࠥࡅࡓࡘࡈࡖ࠭ࡻࡲ࡭࠮ࠪࡹࡷࡲࠧࠪࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࠺ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖࠫ࠭࠱࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࠻ࡵࡨࡶࡻ࡫ࡲࡾࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪ࠭ࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠎࡲࡩ࡯࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡱ࡯࡮࡬࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐࢁࡸࡥ࠯ࡋࡊࡒࡔࡘࡅࡄࡃࡖࡉ࠮ࠐࠉࠊ࡫ࡩࠤࡱ࡯࡮࡬ࡵ࠽ࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡨࡱࡧ࡫ࡤ࠮ࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࠪࠫ࠱ࡡࠧࠨ࡟࠯࡟ࡱ࡯࡮࡬࡟ࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠰࡭ࡺ࡭࡭ࠫࠍࠍࠎࠩ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࡟࠵ࡣࠊࠊࠋࠦ࡭࡫ࠦࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠌࠌࠍࠨࠏࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠧࠎࡸࡥࡵࡷࡵࡲࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠏࠏࠉࠤࡧ࡯ࡷࡪࡀࠠࡶࡴ࡯ࠤࡂࠦ࡬ࡪࡰ࡮ࠎࠎࠨࠢࠣ㠕")
	#if l1l11l_l1_ (u"ࠨ࠰ࡰࡴ࠹࠴ࡨࡵ࡯࡯ࠫ㠖") in url:
	#	l1111l111l1_l1_ = url.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㠗"))
	#	url = l1l11l_l1_ (u"ࠪ࠳ࠬ㠘").join(l1111l111l1_l1_[:4])
	#	tmp = re.findall(l1l11l_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠵࠯࠯ࠬࡂ࠳࠮࠮࠮ࠫࡁࠬࠨࠬ㠙"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l1l11l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ㠚")+tmp[0][1]+l1l11l_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ㠛")
	#	#return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㠜"),[l1l11l_l1_ (u"ࠨࠩ㠝")],[url]
	#	#l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1llll1ll111_l1_(url)
	#	#return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
	# l1l11111l_l1_ l1111l_l1_
	#return l1l11l_l1_ (u"ࠩࠪ㠞"),[l1l11l_l1_ (u"ࠪࠫ㠟")],[l1111l_l1_]
def l111111111l_l1_(l1111l_l1_):
	# l11l11l_l1_://l1llllll1l11_l1_.l111ll1_l1_/?l1ll1lll_l1_=142302&l1lll11l_l1_=4
	parts = re.findall(l1l11l_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ㠠"),l1111l_l1_,re.DOTALL|re.IGNORECASE)
	l1ll1lll_l1_,l1lll11l_l1_ = parts[0]
	server = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㠡"))
	#url = server+l1l11l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡘ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ㠢")
	url = server+l1l11l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ㠣")
	#url = server+l1l11l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭㠤")+l1ll1lll_l1_+l1l11l_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭㠥")+l1lll11l_l1_
	#data = {l1l11l_l1_ (u"ࠪ࡭ࡩ࠭㠦"):l1ll1lll_l1_,l1l11l_l1_ (u"ࠫ࡮࠭㠧"):l1lll11l_l1_,l1l11l_l1_ (u"ࠬࡳࡥࡵࡣࠪ㠨"):l1l11l_l1_ (u"࠭࡯࡭ࡦࡢࡷࡪࡸࡶࡦࡴࡶࠫ㠩"),l1l11l_l1_ (u"ࠧࡵࡻࡳࡩࠬ㠪"):l1l11l_l1_ (u"ࠨࡱ࡯ࡨࠬ㠫")}
	data = {l1l11l_l1_ (u"ࠩ࡬ࡨࠬ㠬"):l1ll1lll_l1_,l1l11l_l1_ (u"ࠪ࡭ࠬ㠭"):l1lll11l_l1_}
	headers = {l1l11l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ㠮"):l1l11l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭㠯"),l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㠰"):l1111l_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㠱"),url,data,headers,l1l11l_l1_ (u"ࠨࠩ㠲"),l1l11l_l1_ (u"ࠩࠪ㠳"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬ㠴"))
	l1ll1ll1_l1_ = response.content
	url2 = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㠵"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
	if url2:
		url2 = url2[0]
		return l1l11l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㠶"),[l1l11l_l1_ (u"࠭ࠧ㠷")],[url2]
	return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㠸"),[],[]
def l11ll1_l1_(url,type,l1l1l111_l1_):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㠹"),l1l11l_l1_ (u"ࠩࠪ㠺"),url2,type)
	# http://l111ll11ll1_l1_.l11llll1ll1_l1_.io/l1111l_l1_/136530
	l1lllll_l1_,l111ll111l1_l1_ = [],[]
	l1ll1ll1_l1_ = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠪࠫ㠻"),l1l11l_l1_ (u"ࠫࠬ㠼"),True,l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠲ࡵࡷࠫ㠽"))
	l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࡁ࠵ࡡ࠿ࠩ㠾"),l1ll1ll1_l1_,re.DOTALL)
	for block in l1l1l1_l1_:
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ㠿"),block,re.DOTALL)
		for l1111l_l1_,title in l1l1lll1_l1_:
			if l1111l_l1_ not in l1lllll_l1_ and (l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ㡀") in l1111l_l1_ or l1l11l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭㡁") in l1111l_l1_):
				title = title.replace(l1l11l_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫ㡂"),l1l11l_l1_ (u"ࠫࠬ㡃")).replace(l1l11l_l1_ (u"ࠬࠦ࠭ࠡࠩ㡄"),l1l11l_l1_ (u"࠭ࠧ㡅")).strip(l1l11l_l1_ (u"ࠧࠡࠩ㡆")).replace(l1l11l_l1_ (u"ࠨࠢࠣࠫ㡇"),l1l11l_l1_ (u"ࠩࠣࠫ㡈"))
				l1lllll_l1_.append(l1111l_l1_)
				l111ll111l1_l1_.append(title)
	if not l1lllll_l1_: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ㡉"),[],[]
	if len(l1lllll_l1_)>1:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษࠩ㡊"),l111ll111l1_l1_)
		if selection==-1: selection = 0
	else: selection = 0
	url3 = l1lllll_l1_[selection]
	l1ll1l1l_l1_,l1l1lll_l1_ = [],[]
	if type==l1l11l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㡋"):
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㡌"),url3,l1l11l_l1_ (u"ࠧࠨ㡍"),l1l11l_l1_ (u"ࠨࠩ㡎"),l1l11l_l1_ (u"ࠩࠪ㡏"),True,l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠸࡮ࡥࠩ㡐"))
		l1lll1l1l_l1_ = response.content
		l11l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡧࡺ࡮࠮࡮ࡲࡥࡩ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㡑"),l1lll1l1l_l1_,re.DOTALL)
		if l11l1ll1_l1_:
			l1111l_l1_ = UNQUOTE(l11l1ll1_l1_[0])
			l1ll1l1l_l1_.append(l1111l_l1_)
			l1l1lll_l1_.append(l1l1l111_l1_)
			#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㡒"),l1l11l_l1_ (u"࠭ࠧ㡓"),l1l11l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㡔"),l1111l_l1_)
	elif type==l1l11l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ㡕"):
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㡖"),url3,l1l11l_l1_ (u"ࠪࠫ㡗"),l1l11l_l1_ (u"ࠫࠬ㡘"),l1l11l_l1_ (u"ࠬ࠭㡙"),True,l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍ࠮࠵ࡵࡨࠬ㡚"))
		l1lll1l1l_l1_ = response.content
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㡛"),l1lll1l1l_l1_,re.DOTALL)
		for l1111l_l1_,size in l1l1lll1_l1_:
			if l1l1l111_l1_ in size:
				l1l1lll_l1_.append(size)
				l1ll1l1l_l1_.append(l1111l_l1_)
				#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㡜"),l1l11l_l1_ (u"ࠩࠪ㡝"),l1l11l_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ㡞"),l1111l_l1_)
				break
		if not l1ll1l1l_l1_:
			for l1111l_l1_,size in l1l1lll1_l1_:
				l1l1lll_l1_.append(size)
				l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"࡙ࠫࡋࡓࡕࠩ㡟"),l1ll1l1l_l1_)
	if not l1ll1l1l_l1_: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭㡠"),[],[]
	return l1l11l_l1_ (u"࠭ࠧ㡡"),l1l1lll_l1_,l1ll1l1l_l1_
def l11l1_l1_(url,name):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㡢"),l1l11l_l1_ (u"ࠨࠩ㡣"),url,l11llll11l1_l1_)
	# http://l1l11l11l1l_l1_.l1111l1lll1_l1_.l111ll1_l1_/5cf68c23e6e79			?l11llll11l1_l1_=			__1l111ll1ll_l1_
	# http://w.l1ll11l1_l1_.l111lll11l_l1_/5e14fd0a2806e			?l11llll11l1_l1_=			ok.l111l1l111l_l1_
	#l11llll11l1_l1_ = l11llll11l1_l1_.replace(l1l11l_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭ࡠࡡࠪ㡤"),l1l11l_l1_ (u"ࠪࠫ㡥")).split(l1l11l_l1_ (u"ࠫࡤࡥࠧ㡦"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㡧"),url,l1l11l_l1_ (u"࠭ࠧ㡨"),l1l11l_l1_ (u"ࠧࠨ㡩"),True,l1l11l_l1_ (u"ࠨࠩ㡪"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠶ࡹࡴࠨ㡫"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l1l11l_l1_ (u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪ㡬") in list(cookies.keys()):
		l1l11ll1l_l1_ = cookies[l1l11l_l1_ (u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫ㡭")]
		l1l11ll1l_l1_ = UNQUOTE(escapeUNICODE(l1l11ll1l_l1_))
		items = re.findall(l1l11l_l1_ (u"ࠬࡸ࡯ࡶࡶࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㡮"),l1l11ll1l_l1_,re.DOTALL)
		url2 = items[0].replace(l1l11l_l1_ (u"࠭࡜࠰ࠩ㡯"),l1l11l_l1_ (u"ࠧ࠰ࠩ㡰"))
		url2 = escapeUNICODE(url2)
	else: url2 = url
	if l1l11l_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ㡱") in url2:
		id = url2.split(l1l11l_l1_ (u"ࠩࠨ࠶ࡋ࠭㡲"))[-1]
		url2 = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡦࡺࡣࡩ࠰࡬ࡷ࠴࠭㡳")+id
		return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㡴"),[l1l11l_l1_ (u"ࠬ࠭㡵")],[url2]
	else:
		website = WEBSITES[l1l11l_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㡶")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㡷"),website,l1l11l_l1_ (u"ࠨࠩ㡸"),l1l11l_l1_ (u"ࠩࠪ㡹"),True,l1l11l_l1_ (u"ࠪࠫ㡺"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠲࡯ࡦࠪ㡻"))
		l11llll1111_l1_ = response.url
		#l11llll1111_l1_ = response.headers[l1l11l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㡼")]
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㡽"),l1l11l_l1_ (u"ࠧࠨ㡾"),response.url,website)
		l111ll11111_l1_ = url2.split(l1l11l_l1_ (u"ࠨ࠱ࠪ㡿"))[2]#.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㢀"))
		l1l11l11ll1_l1_ = l11llll1111_l1_.split(l1l11l_l1_ (u"ࠪ࠳ࠬ㢁"))[2]#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㢂"))
		url3 = url2.replace(l111ll11111_l1_,l1l11l11ll1_l1_)
		headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㢃"):l1l11l_l1_ (u"࠭ࠧ㢄") , l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ㢅"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ㢆") , l1l11l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㢇"):url3 }
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㢈"), url3, l1l11l_l1_ (u"ࠫࠬ㢉"), headers, False,l1l11l_l1_ (u"ࠬ࠭㢊"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬ㢋"))
		html = response.content
		#xbmc.log(str(url3), level=xbmc.LOGERROR)
		items = re.findall(l1l11l_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㢌"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l11l_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㢍"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㢎"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㢏"),l1l11l_l1_ (u"ࠫࠬ㢐"),str(items),html)
		if items:
			l1111l_l1_ = items[0].replace(l1l11l_l1_ (u"ࠬࡢ࠯ࠨ㢑"),l1l11l_l1_ (u"࠭࠯ࠨ㢒"))
			l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠧ࠰ࠩ㢓"))
			if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭㢔") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㢕") + l1111l_l1_
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ㢖"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭㢗"))
			if name==l1l11l_l1_ (u"ࠬ࠭㢘"): l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"࠭ࠧ㢙"),[l1l11l_l1_ (u"ࠧࠨ㢚")],[l1111l_l1_]
			else: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㢛"),[l1l11l_l1_ (u"ࠩࠪ㢜")],[l1111l_l1_]
		else: l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡐࡃࡐࠫ㢝"),[],[]
		return l1l111l11l1_l1_,l1l1lll_l1_,l1ll1l1l_l1_
def l11ll1l111l_l1_(url):
	# l11l11l_l1_://l1llllll1ll1_l1_.l11lll11111_l1_.l11111ll_l1_/e/l1lllllll1l1_l1_
	headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㢞") : l1l11l_l1_ (u"ࠬ࠭㢟") }
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"࠭ࠧ㢠"),headers,l1l11l_l1_ (u"ࠧࠨ㢡"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ㢢"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㢣"),l1l11l_l1_ (u"ࠪࠫ㢤"),url,html)
	items = re.findall(l1l11l_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㢥"),html,re.DOTALL)
	l1l1lll_l1_,l1ll1l1l_l1_,errno = [],[],l1l11l_l1_ (u"ࠬ࠭㢦")
	if items:
		for l1111l_l1_,l111l111lll_l1_ in items:
			l1l1lll_l1_.append(l111l111lll_l1_)
			l1ll1l1l_l1_.append(l1111l_l1_)
	if len(l1ll1l1l_l1_)==0: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓࠬ㢧"),[],[]
	return l1l11l_l1_ (u"ࠧࠨ㢨"),l1l1lll_l1_,l1ll1l1l_l1_
def l111111ll1l_l1_(url):
	# l11l11l_l1_://l1111lll111_l1_.l11111ll_l1_/l1l11111l_l1_-l11l1l1ll11_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ㢩"),l1l11l_l1_ (u"ࠩࠪ㢪"))
	headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㢫") : l1l11l_l1_ (u"ࠫࠬ㢬") }
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠬ࠭㢭"),headers,l1l11l_l1_ (u"࠭ࠧ㢮"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡙ࡖࡒࡏࡂࡆ࠰࠵ࡸࡺࠧ㢯"))
	items = re.findall(l1l11l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㢰"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㢱"),l1l11l_l1_ (u"ࠪࠫ㢲"),url,items[0])
	if items:
		url = items[0]+l1l11l_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ㢳")+url
		return l1l11l_l1_ (u"ࠬ࠭㢴"),[l1l11l_l1_ (u"࠭ࠧ㢵")],[url]
	else: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡕࡑࡕࡁࡅࠩ㢶"),[],[]
def l11l1111l1l_l1_(url):
	# l11l11l_l1_://l1lll1ll11ll_l1_.to/l1l11111l_l1_/5c83f14297d62
	url = url.strip(l1l11l_l1_ (u"ࠨ࠱ࠪ㢷"))
	if l1l11l_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ㢸") in url: id = url.split(l1l11l_l1_ (u"ࠪ࠳ࠬ㢹"))[4]
	else: id = url.split(l1l11l_l1_ (u"ࠫ࠴࠭㢺"))[-1]
	url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩ㢻") + id
	headers = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㢼") : l1l11l_l1_ (u"ࠧࠨ㢽") }
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠨࠩ㢾"),headers,l1l11l_l1_ (u"ࠩࠪ㢿"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡄࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬ㣀"))
	html = html.replace(l1l11l_l1_ (u"ࠫࡡࡢࠧ㣁"),l1l11l_l1_ (u"ࠬ࠭㣂"))
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㣃"),l1l11l_l1_ (u"ࠧࠨ㣄"),url,html)
	items = re.findall(l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㣅"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"ࠩࠪ㣆"),[l1l11l_l1_ (u"ࠪࠫ㣇")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡄࡕࡗࡖࡊࡇࡍࠨ㣈"),[],[]
def l1111l1111l_l1_(url):
	# l11l11l_l1_://l1l111111ll_l1_.l111ll1_l1_/l1l11111l_l1_-l11l1llll1l_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ㣉"),l1l11l_l1_ (u"࠭ࠧ㣊"))
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠧࠨ㣋"),l1l11l_l1_ (u"ࠨࠩ㣌"),l1l11l_l1_ (u"ࠩࠪ㣍"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪ㣎"))
	items = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㣏"),html,re.DOTALL)
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	for l1111l_l1_,l111l111lll_l1_,res in items:
		l1l1lll_l1_.append(l111l111lll_l1_+l1l11l_l1_ (u"ࠬࠦࠧ㣐")+res)
		l1ll1l1l_l1_.append(l1111l_l1_)
	if len(l1ll1l1l_l1_)==0: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡔࡠࡁࠨ㣑"),[],[]
	return l1l11l_l1_ (u"ࠧࠨ㣒"),l1l1lll_l1_,l1ll1l1l_l1_
def l11l11lllll_l1_(url):
	# l11l11l_l1_://l1l111l11ll_l1_.l111ll1l11_l1_/l1l11111l_l1_-l1111l1ll11_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ㣓"),l1l11l_l1_ (u"ࠩࠪ㣔"))
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠪࠫ㣕"),l1l11l_l1_ (u"ࠫࠬ㣖"),l1l11l_l1_ (u"ࠬ࠭㣗"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ㣘"))
	items = re.findall(l1l11l_l1_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧ㣙"),html,re.DOTALL)
	items = set(items)
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	for id,mode,hash,l111l111lll_l1_,res in items:
		url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ㣚")+id+l1l11l_l1_ (u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ㣛")+mode+l1l11l_l1_ (u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ㣜")+hash
		html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠫࠬ㣝"),l1l11l_l1_ (u"ࠬ࠭㣞"),l1l11l_l1_ (u"࠭ࠧ㣟"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠳ࡰࡧࠫ㣠"))
		items = re.findall(l1l11l_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㣡"),html,re.DOTALL)
		for l1111l_l1_ in items:
			l1l1lll_l1_.append(l111l111lll_l1_+l1l11l_l1_ (u"ࠩࠣࠫ㣢")+res)
			l1ll1l1l_l1_.append(l1111l_l1_)
	if len(l1ll1l1l_l1_)==0: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐࠩ㣣"),[],[]
	return l1l11l_l1_ (u"ࠫࠬ㣤"),l1l1lll_l1_,l1ll1l1l_l1_
def l1lll1ll1l11_l1_(url):
	# l11l11l_l1_://l1llll11llll_l1_.l11111ll_l1_:2053/l1llll1l11l1_l1_/l1111l11lll_l1_.l11l1l1l11l_l1_.l1l11l1111l_l1_.1080p.l1l111ll11l_l1_.l11llll111l_l1_.l1llll111l11_l1_.l11lll1l_l1_.html?l11l11ll11l_l1_=2jpqzvpT8BbNUifWZO4QLQ&l11l1lllll1_l1_=1624070560
	# http://l1lllll11ll1_l1_.l11lll1l1l1_l1_/l11l1l111l1_l1_/l11l1l1ll1l_l1_.l111ll1llll_l1_.l11l1lll11l_l1_.2018.1080p.l111l1lllll_l1_-l111llll1l1_l1_.l1lllll11l11_l1_.l11lll1l_l1_.html
	l1111l_l1_ = l1l11l_l1_ (u"ࠬ࠭㣥")
	if 1 or l1l11l_l1_ (u"࠭ࡋࡦࡻࡀࠫ㣦") not in url:
		url2 = url.replace(l1l11l_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠴࡬ࡪࡸࡨࠫ㣧"),l1l11l_l1_ (u"ࠨࡷࡳࡴࡴࡳ࠮࡭࡫ࡹࡩࠬ㣨"))
		url2 = url2.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㣩"))
		id = url2[3]
		url2 = l1l11l_l1_ (u"ࠪ࠳ࠬ㣪").join(url2[0:4])
		#headers = {l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㣫"):l1ll1111l_l1_(),l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㣬"):l1l11l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ㣭")}
		payload = {l1l11l_l1_ (u"ࠧࡪࡦࠪ㣮"):id,l1l11l_l1_ (u"ࠨࡱࡳࠫ㣯"):l1l11l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬ㣰"),l1l11l_l1_ (u"ࠪࡱࡪࡺࡨࡰࡦࡢࡪࡷ࡫ࡥࠨ㣱"):l1l11l_l1_ (u"ࠫࡋࡸࡥࡦ࠭ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠯ࠪ࠹ࡅࠦ࠵ࡈࠫ㣲")}
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ㣳"),url2,payload,l1l11l_l1_ (u"࠭ࠧ㣴"),l1l11l_l1_ (u"ࠧࠨ㣵"),l1l11l_l1_ (u"ࠨࠩ㣶"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠶ࡹࡴࠨ㣷"))
		if l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㣸") in list(response.headers.keys()): l1111l_l1_ = response.headers[l1l11l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㣹")]
		if not l1111l_l1_ and response.succeeded:
			html = response.content
			l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㣺"),html,re.DOTALL)
			if l1111l_l1_: l1111l_l1_ = l1111l_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㣻"),url,l1l11l_l1_ (u"ࠧࠨ㣼"),l1l11l_l1_ (u"ࠨࠩ㣽"),l1l11l_l1_ (u"ࠩࠪ㣾"),l1l11l_l1_ (u"ࠪࠫ㣿"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠲࡯ࡦࠪ㤀"))
		if l1l11l_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㤁") in list(response.headers.keys()): l1111l_l1_ = response.headers[l1l11l_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㤂")]
	if l1111l_l1_: return l1l11l_l1_ (u"ࠧࠨ㤃"),[l1l11l_l1_ (u"ࠨࠩ㤄")],[l1111l_l1_]
	return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡚ࡖࡂࡐࡏࠪ㤅"),[],[]
def l11l111l11l_l1_(url):
	# l11l11l_l1_://l1llllll1ll1_l1_.l111ll1l111_l1_.l11111ll_l1_/012ocyw9li6g.html
	headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㤆") : l1l11l_l1_ (u"ࠫࠬ㤇") }
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠬ࠭㤈"),headers,l1l11l_l1_ (u"࠭ࠧ㤉"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ㤊"))
	items = re.findall(l1l11l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㤋"),html,re.DOTALL)
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	if items:
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠩࡰࡴ࠹࠭㤌"))
		l1ll1l1l_l1_.append(items[0][1])
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ㤍"))
		l1ll1l1l_l1_.append(items[0][0])
		return l1l11l_l1_ (u"ࠫࠬ㤎"),l1l1lll_l1_,l1ll1l1l_l1_
	else: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡍࡋࡌ࡚ࡎࡊࡅࡐࠩ㤏"),[],[]
def l1l1111l1l1_l1_(url):
	# l1llll111ll1_l1_ l11ll1lll11_l1_			url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡝࠼࡝࠴࠲ࡘࡐࡼࡾࡗࡅࠨ㤐")
	# l1llll1ll11l_l1_ .l1l111lll11_l1_ l11ll1lll11_l1_		url = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡝ࡼ࡭ࡔࡐࡄࡽࡪࡿࡆࡊࠩ㤑")
	# l11l1l111ll_l1_ l1l1ll1l11_l1_ .l11l1111_l1_ l11ll1lll11_l1_		url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡍࡦ࠳࠯ࡑࡗࡹ࡙ࡳࡏࡹࠪ㤒")
	# l11l111llll_l1_ l11ll1lll11_l1_			url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡥࡠࡕ࠼࡚ࡻࡐࡍ࠲ࡒࡌࠫ㤓")
	# l1l111l11l_l1_ files have l11l1111ll1_l1_ l1llll11lll1_l1_		url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽࠲ࡹࡇࡖ࡚࡜ࡣࡔࡻࡢࡕࠬ㤔")
	# url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡿ࡯ࡶࡶࡸ࠲ࡧ࡫࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ㤕")
	# url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࠲ࡶ࠰ࡥࡩ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ㤖")
	# url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡨࡱࡧ࡫ࡤ࠰ࡧࡇࡰ࡟࠻ࡶࡂࡐࡔ࡙࡬࠭㤗")
	# url = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩ㤘")
	# url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡶࡆࡆ࡮࡮࡭ࡤࡐ࠱࡚࡭ࠩࡥࡧࡥࡣࡩࡣࡱࡲࡪࡲ࠽ࡈࡱ࡯ࡨࡪࡴࡌࡪࡰࡨࡪࡴࡸࡔࡗࡒࡵࡳࡩࡻࡣࡵ࡫ࡲࡲࡦࡴࡤࡅ࡫ࡶࡸࡷ࡯ࡢࡶࡶ࡬ࡳࡳࡅࡳࡺࡰࡧ࡭ࡨࡧࡴࡪࡱࡱࡁ࠷࠽࠷࠶࠹࠸ࠫ㤙")
	# l1111ll1_l1_ l111111l11l_l1_ l1llll111111_l1_   l11l11l_l1_://l1111l1l1ll_l1_.me/l1llll11ll11_l1_/l1lll1llll11_l1_-l1llll11l1ll_l1_-l1111111l1l_l1_
	id = url.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㤚"))[-1]
	id = id.split(l1l11l_l1_ (u"ࠪࠪࠬ㤛"))[0]
	id = id.replace(l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭㤜"),l1l11l_l1_ (u"ࠬ࠭㤝"))
	#id = l1l11l_l1_ (u"࠭ࡥࡠࡕ࠼࡚ࡻࡐࡍ࠲ࡒࡌࠫ㤞")
	#url = l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦ࠱ࡳࡰࡦࡿ࠯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫ㤟")+id
	#return l1l11l_l1_ (u"ࠨࠩ㤠"),[l1l11l_l1_ (u"ࠩࠪ㤡")],[url]
	url2 = WEBSITES[l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㤢")][0]+l1l11l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ㤣")+id
	l1lll1ll1ll1_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࡯ࡶࡶࡸ࠲ࡧ࡫࠯ࠨ㤤")+id
	l111lll111l_l1_,l1llll1l111l_l1_,l1l11l111l1_l1_,l1llll1lll1l_l1_ = l1l11l_l1_ (u"࠭ࠧ㤥"),l1l11l_l1_ (u"ࠧࠨ㤦"),l1l11l_l1_ (u"ࠨࠩ㤧"),l1l11l_l1_ (u"ࠩࠪ㤨")
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠪࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡠࠬ࠲ࠧࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠮࠮ࠫࡁࠬࡨࡪ࡬ࡡࡶ࡮ࡷࡅࡺࡪࡩࡰࡖࡵࡥࡨࡱࡉ࡯ࡦࡨࡼࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫࠬࠧࠪࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡿࠧࡲࡡ࡯ࡩࡸࡥ࡬࡫ࡃࡰࡦࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡡࠧษั๋๊ࠥะัอ็ฬࠤ๏๎ส๋๊หࠫࡢ࠲࡛ࠨࠩࡠࠎࠎࠏࠉࡧࡱࡵࠤࡱࡧ࡮ࡨ࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰࡦࡴࡧࠪࠌࠌࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ฯืฬๆหࠣห้๋ๆศีหอ࠿࠭ࠬࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠭ࠏࠏࠉࠊ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡜࠲࠯࠱࠶ࡣ࠺ࠋࠋࠌࠍࠎࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡦࡦࡹࡥࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࠉࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࡠ࠶࡝ࠬࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠪࡹࡿࡰࡦ࠿ࡷࡶࡦࡩ࡫ࠧࡶ࡯ࡥࡳ࡭࠽ࠨ࠭࡯࡭ࡳࡱࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝ࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࠩ࠲ࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࠵ࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠿ࠦࡤࡢࡵ࡫࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡩࡧࡳࡩࡗࡕࡐࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡸ࠵ࠧ࠭ࠩ࠲ࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࠵ࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡮࡬ࡴࡗࡕࡐࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠧ࡭ࡺ࡭࡭࠴ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰࡭ࡲࡳࡖࡔࡏ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨࠫࠍࠍࠎࠩࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡞࠭ࡎࡇࡇࡍࡆࡀࡕࡓࡋࡀࠦ࠭࠴ࠪࡀࠫࠥ࠰࡙࡟ࡐࡆ࠿ࡖ࡙ࡇ࡚ࡉࡕࡎࡈࡗ࠱ࡍࡒࡐࡗࡓ࠱ࡎࡊ࠽ࠣࡸࡷࡸࠬ࠲ࡨࡵ࡯࡯࠶࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡ࡫ࡷࡩࡲࡹ࠺ࠡࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࠦ࠽ࠡ࡫ࡷࡩࡲࡹ࡛࠱࡟ࠦ࠯ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠦࡵࡻࡳࡩࡂࡺࡲࡢࡥ࡮ࠪࡹࡲࡡ࡯ࡩࡀࠫࠏࠏࡢ࡭ࡱࡦ࡯ࡸ࠲ࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶࠲ࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬࡼࡿࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡸࡶࡱࡥࡥ࡯ࡥࡲࡨࡪࡪ࡟ࡧ࡯ࡷࡣࡸࡺࡲࡦࡣࡰࡣࡲࡧࡰࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡤ࡬࡭ࡵࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡪࡨࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡫ࡳࡴࡠ࡮࡬ࡷࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠࡢࡰࡧࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠣࡀ࡟ࠬ࠭࡝࠻ࠌࠌࠍࠎ࡬࡭ࡵࡡ࡯࡭ࡸࡺࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠏࡦ࡮ࡶࡢ࡭ࡹࡧࡧࡴࠢࡀࠤ࡫ࡳࡴࡠ࡮࡬ࡷࡹ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠬࠨࠫࠍࠍࠎࠏࡦࡰࡴࠣ࡭ࡹ࡫࡭ࠡ࡫ࡱࠤ࡫ࡳࡴࡠ࡫ࡷࡥ࡬ࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡴࡢࡩ࠯ࡷ࡮ࢀࡥࠡ࠿ࠣ࡭ࡹ࡫࡭࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠱ࠪ࠭ࠏࠏࠉࠊࠋࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵ࡝࡬ࡸࡦ࡭࡝ࠡ࠿ࠣࡷ࡮ࢀࡥࠋࠋࡩࡳࡷࠦࡢ࡭ࡱࡦ࡯ࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡮࡬ࠠ࡯ࡱࡷࠤࡧࡲ࡯ࡤ࡭࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊ࡮࡬ࡲࡪࡹࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠮ࠪ࠭ࠏࠏࠉࡧࡱࡵࠤࡱ࡯࡮ࡦࠢ࡬ࡲࠥࡲࡩ࡯ࡧࡶ࠾ࠏࠏࠉࠊࠥࡻࡦࡲࡩ࠮࡭ࡱࡪࠬࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧ࠭࡮ࡨࡺࡪࡲ࠽ࡹࡤࡰࡧ࠳ࡒࡏࡈࡐࡒࡘࡎࡉࡅࠪࠌࠌࠍࠎࠩࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩ࡮࡬ࡲࡪ࠲࡬ࡦࡸࡨࡰࡂࡾࡢ࡮ࡥ࠱ࡐࡔࡍࡎࡐࡖࡌࡇࡊ࠯ࠊࠊࠋࠌࡰ࡮ࡴࡥࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡱ࡯࡮ࡦࠫࠍࠍࠎࠏࡤࡪࡥࡷࠤࡂࠦࡻࡾࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦ࡬ࡪࡰࡨ࠲ࡸࡶ࡬ࡪࡶࠫࠫࠫࠬࠧࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉ࡬ࡧࡼ࠰ࡻࡧ࡬ࡶࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪࡁࠬ࠲࠱ࠪࠌࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࡰ࡫ࡹ࡞ࠢࡀࠤࡻࡧ࡬ࡶࡧࠍࠍࠎࠏࡩࡧࠢࠪࡷ࡮ࢀࡥࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࠦࡡ࡯ࡦࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞ࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠏࠏࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨࡵ࡬ࡾࡪ࠭࡝ࠡ࠿ࠣࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶ࡞ࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞࡟ࠍࠍࠎࠏࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࡤࡪࡥࡷ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࡸ࠲ࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡧࡱࡵࡱࡦࡺࡳࠣ࠼࡟࡟࠭࠴ࠪࡀࠫ࡟ࡡࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠣ࠼࡟࡟࠭࠴ࠪࡀࠫ࡟ࡡࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡧࡱࡵࠤࡧࡲ࡯ࡤ࡭ࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠫࠬࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡁࠧ࠭ࠬࠨ࠿ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠣࠤࠪ࠰ࠬࠨࠧࠪࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠺ࡵࡴࡸࡩࠬ࠲ࠧ࠻ࡖࡵࡹࡪ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠾࡫ࡧ࡬ࡴࡧࠪ࠰ࠬࡀࡆࡢ࡮ࡶࡩࠬ࠯ࠊࠊࠋ࡬ࡪ࡛ࠥ࠭ࠨࠢࡱࡳࡹࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫࠻ࠢࡥࡰࡴࡩ࡫ࠡ࠿ࠣࠫࡠ࠭ࠫࡣ࡮ࡲࡧࡰ࠱ࠧ࡞ࠩࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡅࡗࡃࡏࠬࠬࡲࡩࡴࡶࠪ࠰ࡧࡲ࡯ࡤ࡭ࠬࠎࠎࠏࡦࡰࡴࠣࡨ࡮ࡩࡴࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭࠽ࠎࠎࠏࠉࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠ࠭ࠏࠏࠉࠊࡦ࡬ࡧࡹࡡࠧࡵࡻࡳࡩࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠾ࠩ࠯ࠫࡂࠨࠧࠪ࠭ࠪࠦࠬࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡦࡱࡵࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫ࡫ࡶࡳࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡨࡳࡷࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫࡼ࡯ࡤࡵࡪࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡸ࡯ࡺࡦࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡺ࡭ࡩࡺࡨࠨ࡟ࠬ࠯ࠬࡾࠧࠬࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫ࡭࡫ࡩࡨࡪࡷࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡩࡵࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡸࡺࡡࡳࡶࠪࡡ࠰࠭࠭ࠨ࠭ࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡦࡰࡧࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡤࡦࡺࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡳࡵࡣࡵࡸࠬࡣࠫࠨ࠯ࠪ࠯ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡩࡳࡪࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࠦࡡ࡯ࡦࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࡃ࠷࠱࠲࠴࠵࠶࠸࠹࠳࠻ࠢࡧࡩࡱࠦࡤࡪࡥࡷ࡟ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠏࠏࠉࠊࠋࡦ࡭ࡵ࡮ࡥࡳࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬࡣ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠧࠩࠬࠎࠎࠏࠉࠊࡨࡲࡶࠥ࡯ࡴࡦ࡯ࠣ࡭ࡳࠦࡣࡪࡲ࡫ࡩࡷࡀࠊࠊࠋࠌࠍࠎࡱࡥࡺ࠮ࡹࡥࡱࡻࡥࠡ࠿ࠣ࡭ࡹ࡫࡭࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠿ࠪ࠰࠶࠯ࠊࠊࠋࠌࠍࠎࡪࡩࡤࡶ࡞࡯ࡪࡿ࡝ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡻࡧ࡬ࡶࡧࠬࠎࠎࠏࠉࠤ࡫ࡩࠤࠬࡻࡲ࡭ࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡹࡷࡲࠧ࡞ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࡞ࠫࡺࡸ࡬ࠨ࡟ࠬࠎࠎࠏࠉࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸࠮ࡢࡲࡳࡩࡳࡪࠨࡥ࡫ࡦࡸ࠮ࠐࠉࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠮ࡶࡸࡷ࡫ࡡ࡮ࡵ࠳࠰ࡸࡺࡲࡦࡣࡰࡷ࠶࠲ࡳࡵࡴࡨࡥࡲࡹ࠲ࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮࡞ࡡ࠱ࡡ࡝ࠋࠋ࡬ࡪࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵ࠥࡧ࡮ࡥࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠼ࠍࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺ࠱ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠾ࠏࠏࠉࠊࡷࡵࡰ࠶ࠦ࠽ࠡࡦ࡬ࡧࡹ࠷࡛ࠨࡷࡵࡰࠬࡣ࡛࠻࠵࠳࠴ࡢࠐࠉࠊࠋࠦࡹࡷࡲ࠱ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈ࡚ࠬࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࠴࡟ࠬࡻࡲ࡭ࠩࡠ࠭࠮ࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࡨࡲࡶࠥࡪࡩࡤࡶ࠵ࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸࠺ࠋࠋࠌࠍࠎࡻࡲ࡭࠴ࠣࡁࠥࡪࡩࡤࡶ࠵࡟ࠬࡻࡲ࡭ࠩࡠ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠉࠤࡷࡵࡰ࠷ࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡘࡒࡖ࡛ࡏࡕࡇࠫࡨ࡮ࡩࡴ࠳࡝ࠪࡹࡷࡲࠧ࡞ࠫࠬ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠉࡪࡨࠣࡹࡷࡲ࠱࠾࠿ࡸࡶࡱ࠸ࠠࡢࡰࡧࠤࡺࡸ࡬࠲ࠢࡱࡳࡹࠦࡩ࡯ࠢࡸࡶࡱࡥ࡬ࡪࡵࡷ࠾ࠏࠏࠉࠊࠋࠌࡹࡷࡲ࡟࡭࡫ࡶࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡻࡲ࡭࠳ࠬࠎࠎࠏࠉࠊࠋࡧ࡭ࡨࡺ࠱࠯ࡷࡳࡨࡦࡺࡥࠩࡦ࡬ࡧࡹ࠸ࠩࠋࠋࠌࠍࠎࠏࡳࡵࡴࡨࡥࡲࡹ࠰࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠷ࠩࠋࠋࡨࡰࡸ࡫࠺ࠡࡵࡷࡶࡪࡧ࡭ࡴ࠲ࠣࡁࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠰ࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶ࠏࠏࠢࠣࠤ㤩")
	# l1lllll111ll_l1_ json data
	# l1l11111l_l1_ url l11ll1lll11_l1_:    l11l11l_l1_://l1llllll1ll1_l1_.l1111ll1_l1_.l11111ll_l1_/l1l11111l_l1_/l11l1ll1lll_l1_
	# list of l11ll1lllll_l1_ & l1llll1l1l11_l1_
	# l11l11l_l1_://l11l1lll1l_l1_.l11111ll_l1_/l1111111l11_l1_-l111l111ll1_l1_/l1111111l11_l1_-l111l111ll1_l1_/l11lll11ll_l1_/l11lllll11_l1_/l11ll1l11l1_l1_/l111ll1l1l1_l1_/l1111ll1_l1_.py
	# all the l11ll11111_l1_ l11111lll1l_l1_ l111lllll11_l1_ l11l111l111_l1_ l1lllllll1ll_l1_:	l11l11l_l1_://l1llllll1ll1_l1_.l1111ll1_l1_.l11111ll_l1_/l11lllll1l1_l1_/l11111l1l11_l1_/l11111ll1ll_l1_?l1lll1lll1ll_l1_=l1llll1l1l1l_l1_	&	l11ll11l11l_l1_ = l11l1ll1lll_l1_
	# 3 streams:	13KB:	l1l11l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ㤪"): l1l11l_l1_ (u"ࠬࡏࡏࡔࡡࡆࡖࡊࡇࡔࡐࡔࠪ㤫"),l1l11l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭㤬"): l1l11l_l1_ (u"ࠧ࠳࠴࠱࠷࠸࠴࠱࠱࠳ࠪ㤭")
	# 7 streams		44KB:	l1l11l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ㤮"): l1l11l_l1_ (u"ࠩࡌࡓࡘࡥࡍࡆࡕࡖࡅࡌࡋࡓࡠࡇ࡛ࡘࡊࡔࡓࡊࡑࡑࠫ㤯"),l1l11l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ㤰"): l1l11l_l1_ (u"ࠫ࠶࠽࠮࠴࠵࠱࠶ࠬ㤱")
	# 7 streams		58KB:	l1l11l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ㤲"): l1l11l_l1_ (u"࠭ࡉࡐࡕࠪ㤳"),l1l11l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ㤴"): l1l11l_l1_ (u"ࠨ࠳࠺࠲࠸࠹࠮࠳ࠩ㤵")
	# 9 streams		24KB:	l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭㤶"): l1l11l_l1_ (u"ࠪࡅࡓࡊࡒࡐࡋࡇࡣࡈࡘࡅࡂࡖࡒࡖࠬ㤷"),l1l11l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ㤸"): l1l11l_l1_ (u"ࠬ࠸࠲࠯࠵࠳࠲࠶࠶࠰ࠨ㤹")
	# no json file:		21 streams	95KB:	l1l11l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ㤺"): l1l11l_l1_ (u"ࠧࡘࡇࡅࡣࡈࡘࡅࡂࡖࡒࡖࠬ㤻"),l1l11l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ㤼"): l1l11l_l1_ (u"ࠩ࠴࠲࠷࠶࠲࠳࠲࠺࠶࠻࠴࠰࠱࠰࠳࠴ࠬ㤽")
	# no json file:		21 streams	121KB:	l1l11l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ㤾"): l1l11l_l1_ (u"ࠫ࡜ࡋࡂࠨ㤿"),l1l11l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ㥀"): l1l11l_l1_ (u"࠭࠲࠯࠴࠳࠶࠷࠶࠸࠱࠳࠱࠴࠵࠴࠰࠱ࠩ㥁")
	# no json file: 	26 streams	115KB:	l1l11l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ㥂"): l1l11l_l1_ (u"ࠨࡏ࡚ࡉࡇ࠭㥃"),l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ㥄"): l1l11l_l1_ (u"ࠪ࠶࠳࠸࠰࠳࠴࠳࠼࠵࠷࠮࠱࠲࠱࠴࠵࠭㥅")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ㥆"): l1l11l_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉ࠭㥇"),l1l11l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭㥈"): l1l11l_l1_ (u"ࠧ࠲࠹࠱࠷࠶࠴࠳࠶ࠩ㥉")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ㥊"): l1l11l_l1_ (u"࡚ࠩࡉࡇࡥࡒࡆࡏࡌ࡜ࠬ㥋"),l1l11l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ㥌"): l1l11l_l1_ (u"ࠫ࠶࠴࠲࠱࠴࠵࠴࠼࠸࠷࠯࠲࠴࠲࠵࠶ࠧ㥍")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ㥎"): l1l11l_l1_ (u"࠭ࡗࡆࡄࡢࡉࡒࡈࡅࡅࡆࡈࡈࡤࡖࡌࡂ࡛ࡈࡖࠬ㥏"),l1l11l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ㥐"): l1l11l_l1_ (u"ࠨ࠳࠱࠶࠵࠸࠲࠱࠹࠶࠵࠳࠶࠰࠯࠲࠳ࠫ㥑")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭㥒"): l1l11l_l1_ (u"ࠪࡅࡓࡊࡒࡐࡋࡇࡣࡊࡓࡂࡆࡆࡇࡉࡉࡥࡐࡍࡃ࡜ࡉࡗ࠭㥓"),l1l11l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ㥔"): l1l11l_l1_ (u"ࠬ࠷࠷࠯࠵࠴࠲࠸࠻ࠧ㥕")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ㥖"): l1l11l_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡏࡘࡗࡎࡉࠧ㥗"),l1l11l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ㥘"): l1l11l_l1_ (u"ࠩ࠸࠲࠶࠼࠮࠶࠳ࠪ㥙")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ㥚"): l1l11l_l1_ (u"࡙ࠫ࡜ࡈࡕࡏࡏ࠹ࡤ࡙ࡉࡎࡒࡏ࡝ࡤࡋࡍࡃࡇࡇࡈࡊࡊ࡟ࡑࡎࡄ࡝ࡊࡘࠧ㥛"),l1l11l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ㥜"): l1l11l_l1_ (u"࠭࠲࠯࠲ࠪ㥝")
	# l1l1l1l11l1_l1_:	l1l11l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ㥞"): l1l11l_l1_ (u"ࠨࡋࡒࡗࡤࡓࡕࡔࡋࡆࠫ㥟"),l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ㥠"): l1l11l_l1_ (u"ࠪ࠹࠳࠸࠱ࠨ㥡")
	# url2 = WEBSITES[l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㥢")][0]+l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡵࡲࡡࡺࡧࡵࡃࡵࡸࡥࡵࡶࡼࡔࡷ࡯࡮ࡵ࠿ࡷࡶࡺ࡫ࠧ㥣")  # l1llll1l1l1l_l1_ l111l1lll11_l1_ l1lll1lll111_l1_ and l111111l1ll_l1_ l111l11l1l1_l1_ l11ll1l1ll_l1_ l1111111111_l1_ file size
	#data2 = l1l11l_l1_ (u"࠭ࡻࠨ㥤")l1lll1lll1l1_l1_ (u"ࠧ࠻࡫ࡧ࠰ࠬ㥥")l111ll1111l_l1_ (u"ࠨ࠼ࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࢁࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ࠿ࠨࡁࡏࡆࡕࡓࡎࡊࠢ࠭ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠦ࠶࠽࠮࠴࠳࠱࠷࠺ࠨࡽࡾࡿࠪ㥦")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㥧"),url2,data2,l1l11l_l1_ (u"ࠪࠫ㥨"),l1l11l_l1_ (u"ࠫࠬ㥩"),l1l11l_l1_ (u"ࠬ࠭㥪"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ㥫"))
	#html = response.content
	for ii in range(5):
		#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧศๆ่ัฬ๎ไสࠢิๆ๊ࡀࠠࠡࠩ㥬")+str(ii+1),l1l11l_l1_ (u"ࠨࠩ㥭"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㥮"),url2,l1l11l_l1_ (u"ࠪࠫ㥯"),l1l11l_l1_ (u"ࠫࠬ㥰"),l1l11l_l1_ (u"ࠬ࠭㥱"),l1l11l_l1_ (u"࠭ࠧ㥲"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨ㥳"))
		html = response.content
		if l1l11l_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭㥴") in html: break
		time.sleep(2)
	#WRITE_THIS(l1l11l_l1_ (u"ࠩࠪ㥵"),html)
	l1ll11lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡓࡰࡦࡿࡥࡳࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ㥶"),html,re.DOTALL)
	if l1ll11lll1_l1_: l1ll11lll1_l1_ = l1ll11lll1_l1_[0]
	else: l1ll11lll1_l1_ = html
	l1ll11lll1_l1_ = l1ll11lll1_l1_.replace(l1l11l_l1_ (u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬ㥷"),l1l11l_l1_ (u"ࠬࠬࠧ㥸"))
	l11l1l1l111_l1_ = EVAL(l1l11l_l1_ (u"࠭ࡤࡪࡥࡷࠫ㥹"),l1ll11lll1_l1_)
	#WRITE_THIS(l1l11l_l1_ (u"ࠧࠨ㥺"),str(l11l1l1l111_l1_))
	# l1lllll111ll_l1_ l11l1llll11_l1_ & l1l111l1lll_l1_
	# l1111ll1_l1_ l1llll111ll1_l1_ l1111l_l1_ l1l1lll1l_l1_ l1l11l_l1_ (u"ࠨࠨࡩࡱࡹࡃࡶࡵࡶࠪ㥻") to l1l111ll11_l1_ on l11lll1111l_l1_
	l1l1lll_l1_,l1ll1l1l_l1_ = [l1l11l_l1_ (u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭㥼")],[l1l11l_l1_ (u"ࠪࠫ㥽")]
	try:
		l11l1llll11_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭㥾")][l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ㥿")][l1l11l_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭㦀")]
		for l11l11l111l_l1_ in l11l1llll11_l1_:
			l1111l_l1_ = l11l11l111l_l1_[l1l11l_l1_ (u"ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠨ㦁")]
			try: title = l11l11l111l_l1_[l1l11l_l1_ (u"ࠨࡰࡤࡱࡪ࠭㦂")][l1l11l_l1_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭㦃")]
			except: title = l11l11l111l_l1_[l1l11l_l1_ (u"ࠪࡲࡦࡳࡥࠨ㦄")][l1l11l_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ㦅")][0][l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࠪ㦆")]
			l1ll1l1l_l1_.append(l1111l_l1_)
			l1l1lll_l1_.append(title)
	except: pass
	if len(l1l1lll_l1_)>1:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭วฯฬิࠤฬ๊สาฮ่อࠥอไๆ่สือฯ࠺ࠨ㦇"), l1l1lll_l1_)
		if selection==-1: return l1l11l_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ㦈"),[],[]
		elif selection!=0:
			l1111l_l1_ = l1ll1l1l_l1_[selection]+l1l11l_l1_ (u"ࠨࠨࠪ㦉")
			l1111ll1l11_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠩࠬ࡫ࡳࡴ࠾࠰࠭ࡃ࠮ࠬࠧ㦊"),l1111l_l1_)
			if l1111ll1l11_l1_: l1111l_l1_ = l1111l_l1_.replace(l1111ll1l11_l1_[0],l1l11l_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ㦋"))
			else: l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ㦌")
			l111lll111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧ㦍"))
	formats,l1l111l1l1l_l1_,l11ll1l1l11_l1_,l11ll1l1l1l_l1_,l11ll1l11ll_l1_ = [],[],[],[],[]
	# l1lllll111ll_l1_ l111lll1lll_l1_ streams
	try: l1llll1l111l_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭㦎")][l1l11l_l1_ (u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ㦏")]
	except: pass
	# l1lllll111ll_l1_ l11l1l111ll_l1_ stream
	try: l1l11l111l1_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ㦐")][l1l11l_l1_ (u"ࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ㦑")]
	except: pass
	# l1lllll111ll_l1_ l1llll11l1_l1_ l11lll1l_l1_ streams
	try: formats = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ㦒")][l1l11l_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ㦓")]
	except: pass
	# l1lllll111ll_l1_ l1llll11l1_l1_ l1l111lll11_l1_ streams
	try: l1l111l1l1l_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ㦔")][l1l11l_l1_ (u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨ㦕")]
	except: pass
	l11l1l1111l_l1_ = formats+l1l111l1l1l_l1_
	for dict in l11l1l1111l_l1_:
		#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ㦖"),str(dict))
		if l1l11l_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭㦗") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ㦘")] = str(dict[l1l11l_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ㦙")])
		if l1l11l_l1_ (u"ࠫ࡫ࡶࡳࠨ㦚") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠬ࡬ࡰࡴࠩ㦛")] = str(dict[l1l11l_l1_ (u"࠭ࡦࡱࡵࠪ㦜")])
		if l1l11l_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ㦝") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠨࡶࡼࡴࡪ࠭㦞")] = dict[l1l11l_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ㦟")]		#.replace(l1l11l_l1_ (u"ࠪࡁࠬ㦠"),l1l11l_l1_ (u"ࠫࡂ࠭㦡"))+l1l11l_l1_ (u"ࠬࠨࠧ㦢")
		if l1l11l_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ㦣") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫ㦤")] = str(dict[l1l11l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ㦥")])
		if l1l11l_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ㦦") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㦧")] = str(dict[l1l11l_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㦨")])
		if l1l11l_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ㦩") in list(dict.keys()): dict[l1l11l_l1_ (u"࠭ࡳࡪࡼࡨࠫ㦪")] = str(dict[l1l11l_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭㦫")])+l1l11l_l1_ (u"ࠨࡺࠪ㦬")+str(dict[l1l11l_l1_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩ㦭")])
		if l1l11l_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭㦮") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ㦯")] = dict[l1l11l_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ㦰")][l1l11l_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㦱")]+l1l11l_l1_ (u"ࠧ࠮ࠩ㦲")+dict[l1l11l_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ㦳")][l1l11l_l1_ (u"ࠩࡨࡲࡩ࠭㦴")]
		if l1l11l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ㦵") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ㦶")] = dict[l1l11l_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ㦷")][l1l11l_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㦸")]+l1l11l_l1_ (u"ࠧ࠮ࠩ㦹")+dict[l1l11l_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ㦺")][l1l11l_l1_ (u"ࠩࡨࡲࡩ࠭㦻")]
		if l1l11l_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫ㦼") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㦽")] = dict[l1l11l_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭㦾")]
		if l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㦿") in list(dict.keys()) and int(dict[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㧀")])>111222333: del dict[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㧁")]
		if l1l11l_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫ㧂") in list(dict.keys()):
			cipher = dict[l1l11l_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬ㧃")].split(l1l11l_l1_ (u"ࠫࠫ࠭㧄"))
			for item in cipher:
				key,value = item.split(l1l11l_l1_ (u"ࠬࡃࠧ㧅"),1)
				dict[key] = UNQUOTE(value)
		if l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㧆") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㧇")] = UNQUOTE(dict[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㧈")])
		#if l1l11l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴ࠿ࠪ㧉") in dict[l1l11l_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ㧊")]: dict[l1l11l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ㧋")] = dict[l1l11l_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ㧌")].split(l1l11l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸࡃ࡜ࠣࠩ㧍"))[1].strip(l1l11l_l1_ (u"ࠧ࡝ࠤࠪ㧎"))
		#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ㧏"),dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ㧐")]+l1l11l_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣࠫ㧑")+dict[l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࠩ㧒")])
		l11ll1l1l11_l1_.append(dict)
	l1l1l111l_l1_ = l1l11l_l1_ (u"ࠬ࠭㧓")
	if l1l11l_l1_ (u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭㧔") in l1ll11lll1_l1_:
		#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡺࡶࡶ࠳࡯ࡹࡢࡪࡰ࠲ࡴࡱࡧࡹࡦࡴࡢ࠲࠯ࡅࠩࠣࠩ㧕"),html,re.DOTALL)
		# l11ll1lll11_l1_:	/s/l11111ll1ll_l1_/6dde7fb4/l1llllll11l1_l1_.l111l1ll1l1_l1_/l111l11lll1_l1_/base.l111l11111l_l1_
		#l11lll1ll11_l1_ = [l1l11l_l1_ (u"ࠨ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡩ࠾࠷ࡥ࠷࠻࠵࡫࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥࡕࡔ࠱ࡥࡥࡸ࡫࠮࡫ࡵࠪ㧖")]
		l11lll1ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡡࡽࠪࡀ࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡ࠱࠲࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠯ࠢࠨ㧗"),html,re.DOTALL)
		if l11lll1ll11_l1_:
			l11lll1ll11_l1_ = WEBSITES[l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㧘")][0]+l11lll1ll11_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㧙"),l11lll1ll11_l1_,l1l11l_l1_ (u"ࠬ࠭㧚"),l1l11l_l1_ (u"࠭ࠧ㧛"),l1l11l_l1_ (u"ࠧࠨ㧜"),l1l11l_l1_ (u"ࠨࠩ㧝"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ㧞"))
			l1l1l111l_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l111lll1111_l1_ = cipher._load_javascript(l1l1l111l_l1_)
			l1llll1l1111_l1_ = EVAL(l1l11l_l1_ (u"ࠪࡷࡹࡸࠧ㧟"),str(l111lll1111_l1_))
			l11111l1lll_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1llll1l1111_l1_)
	for dict in l11ll1l1l11_l1_:
		url = dict[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㧠")]
		if l1l11l_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠾ࠩ㧡") in url or url.count(l1l11l_l1_ (u"࠭ࡳࡪࡩࡀࠫ㧢"))>1:
			l11ll1l1l1l_l1_.append(dict)
		elif l1l1l111l_l1_ and l1l11l_l1_ (u"ࠧࡴࠩ㧣") in list(dict.keys()) and l1l11l_l1_ (u"ࠨࡵࡳࠫ㧤") in list(dict.keys()):
			l11l111llll_l1_ = l11111l1lll_l1_.execute(dict[l1l11l_l1_ (u"ࠩࡶࠫ㧥")])
			if l11l111llll_l1_!=dict[l1l11l_l1_ (u"ࠪࡷࠬ㧦")]:
				dict[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㧧")] = url+l1l11l_l1_ (u"ࠬࠬࠧ㧨")+dict[l1l11l_l1_ (u"࠭ࡳࡱࠩ㧩")]+l1l11l_l1_ (u"ࠧ࠾ࠩ㧪")+l11l111llll_l1_
				l11ll1l1l1l_l1_.append(dict)
	for dict in l11ll1l1l1l_l1_:
		l11_l1_,l11111111l1_l1_,l1111ll1lll_l1_,l1l1ll111_l1_,codecs,l11llllll11_l1_ = l1l11l_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ㧫"),l1l11l_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ㧬"),l1l11l_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ㧭"),l1l11l_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ㧮"),l1l11l_l1_ (u"ࠬ࠭㧯"),l1l11l_l1_ (u"࠭࠰ࠨ㧰")
		try:
			l11ll1l1ll1_l1_ = dict[l1l11l_l1_ (u"ࠧࡵࡻࡳࡩࠬ㧱")]
			l11ll1l1ll1_l1_ = l11ll1l1ll1_l1_.replace(l1l11l_l1_ (u"ࠨ࠭ࠪ㧲"),l1l11l_l1_ (u"ࠩࠪ㧳"))
			items = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ㧴"),l11ll1l1ll1_l1_,re.DOTALL)
			l1l1ll111_l1_,l11_l1_,codecs = items[0]
			l1l1111ll11_l1_ = codecs.split(l1l11l_l1_ (u"ࠫ࠱࠭㧵"))
			l11111111l1_l1_ = l1l11l_l1_ (u"ࠬ࠭㧶")
			for item in l1l1111ll11_l1_: l11111111l1_l1_ += item.split(l1l11l_l1_ (u"࠭࠮ࠨ㧷"))[0]+l1l11l_l1_ (u"ࠧ࠭ࠩ㧸")
			l11111111l1_l1_ = l11111111l1_l1_.strip(l1l11l_l1_ (u"ࠨ࠮ࠪ㧹"))
			if l1l11l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㧺") in list(dict.keys()): l11llllll11_l1_ = str(float(dict[l1l11l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㧻")]*10)//1024/10)+l1l11l_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㧼")
			else: l11llllll11_l1_ = l1l11l_l1_ (u"ࠬ࠭㧽")
			if l1l1ll111_l1_==l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࠫ㧾"): continue
			elif l1l11l_l1_ (u"ࠧ࠭ࠩ㧿") in l11ll1l1ll1_l1_:
				l1l1ll111_l1_ = l1l11l_l1_ (u"ࠨࡃ࠮࡚ࠬ㨀")
				l1111ll1lll_l1_ = l11_l1_+l1l11l_l1_ (u"ࠩࠣࠤࠬ㨁")+l11llllll11_l1_+dict[l1l11l_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ㨂")].split(l1l11l_l1_ (u"ࠫࡽ࠭㨃"))[1]
			elif l1l1ll111_l1_==l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㨄"):
				l1l1ll111_l1_ = l1l11l_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ㨅")
				l1111ll1lll_l1_ = l11llllll11_l1_+dict[l1l11l_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ㨆")].split(l1l11l_l1_ (u"ࠨࡺࠪ㨇"))[1]+l1l11l_l1_ (u"ࠩࠣࠤࠬ㨈")+dict[l1l11l_l1_ (u"ࠪࡪࡵࡹࠧ㨉")]+l1l11l_l1_ (u"ࠫ࡫ࡶࡳࠨ㨊")+l1l11l_l1_ (u"ࠬࠦࠠࠨ㨋")+l11_l1_
			elif l1l1ll111_l1_==l1l11l_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ㨌"):
				l1l1ll111_l1_ = l1l11l_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭㨍")
				l1111ll1lll_l1_ = l11llllll11_l1_+str(int(dict[l1l11l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬ㨎")])/1000)+l1l11l_l1_ (u"ࠩ࡮࡬ࡿࠦࠠࠨ㨏")+dict[l1l11l_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㨐")]+l1l11l_l1_ (u"ࠫࡨ࡮ࠧ㨑")+l1l11l_l1_ (u"ࠬࠦࠠࠨ㨒")+l11_l1_
		except:
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		if l1l11l_l1_ (u"࠭ࡤࡶࡴࡀࠫ㨓") in dict[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㨔")]: duration = round(0.5+float(dict[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㨕")].split(l1l11l_l1_ (u"ࠩࡧࡹࡷࡃࠧ㨖"),1)[1].split(l1l11l_l1_ (u"ࠪࠪࠬ㨗"),1)[0]))
		elif l1l11l_l1_ (u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧ㨘") in list(dict.keys()): duration = round(0.5+float(dict[l1l11l_l1_ (u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨ㨙")])/1000)
		else: duration = l1l11l_l1_ (u"࠭࠰ࠨ㨚")
		if l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㨛") not in list(dict.keys()): l11llllll11_l1_ = dict[l1l11l_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭㨜")].split(l1l11l_l1_ (u"ࠩࡻࠫ㨝"))[1]
		else: l11llllll11_l1_ = dict[l1l11l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㨞")]
		if l1l11l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ㨟") not in list(dict.keys()): dict[l1l11l_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ㨠")] = l1l11l_l1_ (u"࠭࠰࠮࠲ࠪ㨡")
		dict[l1l11l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㨢")] = l1l1ll111_l1_+l1l11l_l1_ (u"ࠨ࠼ࠣࠤࠬ㨣")+l1111ll1lll_l1_+l1l11l_l1_ (u"ࠩࠣࠤ࠭࠭㨤")+l11111111l1_l1_+l1l11l_l1_ (u"ࠪ࠰ࠬ㨥")+dict[l1l11l_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ㨦")]+l1l11l_l1_ (u"ࠬ࠯ࠧ㨧")
		dict[l1l11l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ㨨")] = l1111ll1lll_l1_.split(l1l11l_l1_ (u"ࠧࠡࠢࠪ㨩"))[0].split(l1l11l_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭㨪"))[0]
		dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㨫")] = l1l1ll111_l1_
		dict[l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ㨬")] = l11_l1_
		dict[l1l11l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ㨭")] = codecs
		dict[l1l11l_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ㨮")] = duration
		dict[l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㨯")] = l11llllll11_l1_
		l11ll1l11ll_l1_.append(dict)
	l11l1l11111_l1_,l11lll1lll1_l1_,l1l111lll1l_l1_,l111ll111ll_l1_,l11ll1111ll_l1_ = [],[],[],[],[]
	l111l1l1111_l1_,l11ll1ll1l1_l1_,l1111l1ll1l_l1_,l1l1111l11l_l1_,l1l111ll111_l1_ = [],[],[],[],[]
	if l1llll1l111l_l1_:
		dict = {}
		dict[l1l11l_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭㨰")] = l1l11l_l1_ (u"ࠨࡃ࠮࡚ࠬ㨱")
		dict[l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ㨲")] = l1l11l_l1_ (u"ࠪࡱࡵࡪࠧ㨳")
		dict[l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㨴")] = dict[l1l11l_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ㨵")]+l1l11l_l1_ (u"࠭࠺ࠡࠢࠪ㨶")+dict[l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㨷")]+l1l11l_l1_ (u"ࠨࠢࠣࠫ㨸")+l1l11l_l1_ (u"ࠩฯ์ิฯࠠัๅํอࠬ㨹")
		dict[l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ㨺")] = l1llll1l111l_l1_
		dict[l1l11l_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ㨻")] = l1l11l_l1_ (u"ࠬ࠶ࠧ㨼") # for l1l1ll11l1_l1_ l1llll1l111l_l1_ any l11l111l1ll_l1_ will l11ll11l111_l1_ l11111ll11l_l1_ sort l1ll1lll1ll_l1_
		dict[l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㨽")] = l1l11l_l1_ (u"ࠧ࠺࠺࠺࠺࠺࠺࠳࠳࠳࠳ࠫ㨾") # 20
		l11ll1l11ll_l1_.append(dict)
	if l1l11l111l1_l1_:
		l11ll111l11_l1_,l11lll1l111_l1_ = l1ll11111l_l1_(l1l11l111l1_l1_)
		l11lllll1ll_l1_ = list(zip(l11ll111l11_l1_,l11lll1l111_l1_))
		for title,l1111l_l1_ in l11lllll1ll_l1_:
			dict = {}
			dict[l1l11l_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ㨿")] = l1l11l_l1_ (u"ࠩࡄ࠯࡛࠭㩀")
			dict[l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ㩁")] = l1l11l_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ㩂")
			dict[l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㩃")] = l1111l_l1_
			#if l1l11l_l1_ (u"࠭ࡂࡘ࠼ࠣࠫ㩄") in title: dict[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㩅")] = title.split(l1l11l_l1_ (u"ࠨࠢࠣࠫ㩆"))[1].split(l1l11l_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ㩇"))[0]
			#if l1l11l_l1_ (u"ࠪࡖࡪࡹ࠺ࠡࠩ㩈") in title: dict[l1l11l_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ㩉")] = title.split(l1l11l_l1_ (u"ࠬࡘࡥࡴ࠼ࠣࠫ㩊"))[1]
			# title = l1l11l_l1_ (u"ࠨ࠴࠳࠸࠺࡯ࡧࡶࡳࠡࠢ࠺࠶࠵ࠦࠠ࠯࡯࠶ࡹ࠽ࠨ㩋")
			if l1l11l_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ㩌") in title: dict[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㩍")] = title.split(l1l11l_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ㩎"))[0].rsplit(l1l11l_l1_ (u"ࠪࠤࠥ࠭㩏"))[-1]
			else: dict[l1l11l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㩐")] = l1l11l_l1_ (u"ࠬ࠷࠰ࠨ㩑")
			if title.count(l1l11l_l1_ (u"࠭ࠠࠡࠩ㩒"))>1:
				l1l1l111_l1_ = title.rsplit(l1l11l_l1_ (u"ࠧࠡࠢࠪ㩓"))[-3]
				if l1l1l111_l1_.isdigit(): dict[l1l11l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ㩔")] = l1l1l111_l1_
				else: dict[l1l11l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ㩕")] = l1l11l_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ㩖")
			#dict[l1l11l_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ㩗")] = title
			if title==l1l11l_l1_ (u"ࠬ࠳࠱ࠨ㩘"): dict[l1l11l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㩙")] = dict[l1l11l_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭㩚")]+l1l11l_l1_ (u"ࠨ࠼ࠣࠤࠬ㩛")+dict[l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ㩜")]+l1l11l_l1_ (u"ࠪࠤࠥ࠭㩝")+l1l11l_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ㩞")
			else: dict[l1l11l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㩟")] = dict[l1l11l_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ㩠")]+l1l11l_l1_ (u"ࠧ࠻ࠢࠣࠫ㩡")+dict[l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ㩢")]+l1l11l_l1_ (u"ࠩࠣࠤࠬ㩣")+dict[l1l11l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㩤")]+l1l11l_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㩥")+dict[l1l11l_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭㩦")]
			l11ll1l11ll_l1_.append(dict)
	l11ll1l11ll_l1_ = sorted(l11ll1l11ll_l1_,reverse=True,key=lambda key: float(key[l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㩧")]))
	if not l11ll1l11ll_l1_:
		l1llll1llll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㩨"),html,re.DOTALL)
		l1lllll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㩩"),html,re.DOTALL)
		l11l11ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㩪"),html,re.DOTALL)
		l11l11lll11_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㩫"),html,re.DOTALL)
		try: l11l11lll1l_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ㩬")][l1l11l_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ㩭")][l1l11l_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ㩮")][l1l11l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㩯")][l1l11l_l1_ (u"ࠨࡴࡸࡲࡸ࠭㩰")][0][l1l11l_l1_ (u"ࠩࡷࡩࡽࡺࠧ㩱")]
		except: l11l11lll1l_l1_ = l1l11l_l1_ (u"ࠪࠫ㩲")
		try: l11l11llll1_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ㩳")][l1l11l_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ㩴")][l1l11l_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ㩵")][l1l11l_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨ㩶")][0][l1l11l_l1_ (u"ࠨࡴࡸࡲࡸ࠭㩷")][0][l1l11l_l1_ (u"ࠩࡷࡩࡽࡺࠧ㩸")]
		except: l11l11llll1_l1_ = l1l11l_l1_ (u"ࠪࠫ㩹")
		try: l11111l1ll1_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ㩺")][l1l11l_l1_ (u"ࠬࡸࡥࡢࡵࡲࡲࠬ㩻")]
		except: l11111l1ll1_l1_ = l1l11l_l1_ (u"࠭ࠧ㩼")
		if l1llll1llll_l1_ or l1lllll1111_l1_ or l11l11ll1ll_l1_ or l11l11lll11_l1_ or l11l11lll1l_l1_ or l11l11llll1_l1_ or l11111l1ll1_l1_:
			if   l1llll1llll_l1_: message = l1llll1llll_l1_[0]
			elif l1lllll1111_l1_: message = l1lllll1111_l1_[0]
			elif l11l11ll1ll_l1_: message = l11l11ll1ll_l1_[0]
			elif l11l11lll11_l1_: message = l11l11lll11_l1_[0]
			elif l11l11lll1l_l1_: message = l11l11lll1l_l1_
			elif l11l11llll1_l1_: message = l11l11llll1_l1_
			elif l11111l1ll1_l1_: message = l11111l1ll1_l1_
			l1111ll1111_l1_ = message.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㩽"),l1l11l_l1_ (u"ࠨࠩ㩾")).strip(l1l11l_l1_ (u"ࠩࠣࠫ㩿"))
			l11l1ll1ll1_l1_ = l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ่ࠦใัࠣ๎่๎ๆࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㪀")
			DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㪁"),l1l11l_l1_ (u"ࠬ࠭㪂"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่๊ࠡส่๊ฮัๆฮࠪ㪃"),l11l1ll1ll1_l1_+l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㪄")+l1111ll1111_l1_)
			return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠪ㪅")+l1111ll1111_l1_,[],[]
		else: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ㪆"),[],[]
	l11111ll111_l1_,l1llll1111l1_l1_,l11l111ll11_l1_ = [],[],[]
	for dict in l11ll1l11ll_l1_:
		if dict[l1l11l_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ㪇")]==l1l11l_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ㪈"):
			l11l1l11111_l1_.append(dict[l1l11l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㪉")])
			l111l1l1111_l1_.append(dict)
		elif dict[l1l11l_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ㪊")]==l1l11l_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭㪋"):
			l11lll1lll1_l1_.append(dict[l1l11l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ㪌")])
			l11ll1ll1l1_l1_.append(dict)
		elif dict[l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ㪍")]==l1l11l_l1_ (u"ࠪࡱࡵࡪࠧ㪎"):
			title = dict[l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㪏")].replace(l1l11l_l1_ (u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ㪐"),l1l11l_l1_ (u"࠭ࠧ㪑"))
			if l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㪒") not in list(dict.keys()): l11llllll11_l1_ = l1l11l_l1_ (u"ࠨ࠲ࠪ㪓")
			else: l11llllll11_l1_ = dict[l1l11l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㪔")]
			l11111ll111_l1_.append([dict,{},title,l11llllll11_l1_])
		else:
			title = dict[l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㪕")].replace(l1l11l_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ㪖"),l1l11l_l1_ (u"ࠬ࠭㪗"))
			if l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㪘") not in list(dict.keys()): l11llllll11_l1_ = l1l11l_l1_ (u"ࠧ࠱ࠩ㪙")
			else: l11llllll11_l1_ = dict[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㪚")]
			l11111ll111_l1_.append([dict,{},title,l11llllll11_l1_])
			l1l111lll1l_l1_.append(title)
			l1111l1ll1l_l1_.append(dict)
		l11lllllll1_l1_ = True
		if l1l11l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ㪛") in list(dict.keys()):
			if l1l11l_l1_ (u"ࠪࡥࡻ࠶ࠧ㪜") in dict[l1l11l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ㪝")]: l11lllllll1_l1_ = False
			elif kodi_version<18:
				if l1l11l_l1_ (u"ࠬࡧࡶࡤࠩ㪞") not in dict[l1l11l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭㪟")] and l1l11l_l1_ (u"ࠧ࡮ࡲ࠷ࡥࠬ㪠") not in dict[l1l11l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ㪡")]: l11lllllll1_l1_ = False
		if dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㪢")]==l1l11l_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ㪣") and dict[l1l11l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ㪤")]!=l1l11l_l1_ (u"ࠬ࠶࠭࠱ࠩ㪥") and l11lllllll1_l1_==True:
			l11ll1111ll_l1_.append(dict[l1l11l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㪦")])
			l1l111ll111_l1_.append(dict)
		elif dict[l1l11l_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭㪧")]==l1l11l_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ㪨") and dict[l1l11l_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ㪩")]!=l1l11l_l1_ (u"ࠪ࠴࠲࠶ࠧ㪪") and l11lllllll1_l1_==True:
			l111ll111ll_l1_.append(dict[l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㪫")])
			l1l1111l11l_l1_.append(dict)
		#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭㪬"),l1l11l_l1_ (u"࠭ࠫࠬ࠭࠮࠯࠰࠱ࠠࠡࠢࠪ㪭")+dict[l1l11l_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ㪮")])
	for l11llll1l1l_l1_ in l1l1111l11l_l1_:
		l111ll11l1l_l1_ = l11llll1l1l_l1_[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㪯")]
		for l11l11l1ll1_l1_ in l1l111ll111_l1_:
			l111111l1l1_l1_ = l11l11l1ll1_l1_[l1l11l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㪰")]
			l11llllll11_l1_ = l111111l1l1_l1_+l111ll11l1l_l1_
			title = l11l11l1ll1_l1_[l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㪱")].replace(l1l11l_l1_ (u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠥ࠭㪲"),l1l11l_l1_ (u"ࠬࡳࡰࡥࠢࠣࠫ㪳"))
			title = title.replace(l11l11l1ll1_l1_[l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ㪴")]+l1l11l_l1_ (u"ࠧࠡࠢࠪ㪵"),l1l11l_l1_ (u"ࠨࠩ㪶"))
			title = title.replace(str((float(l111111l1l1_l1_*10)//1024/10))+l1l11l_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ㪷"),str((float(l11llllll11_l1_*10)//1024/10))+l1l11l_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ㪸"))
			title = title+l1l11l_l1_ (u"ࠫ࠭࠭㪹")+l11llll1l1l_l1_[l1l11l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㪺")].split(l1l11l_l1_ (u"࠭ࠨࠨ㪻"),1)[1]
			l11111ll111_l1_.append([l11l11l1ll1_l1_,l11llll1l1l_l1_,title,l11llllll11_l1_])
	l11111ll111_l1_ = sorted(l11111ll111_l1_, reverse=True, key=lambda key: float(key[3]))
	for l11l11l1ll1_l1_,l11llll1l1l_l1_,title,l11llllll11_l1_ in l11111ll111_l1_:
		l11ll1l1111_l1_ = l11l11l1ll1_l1_[l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㪼")]
		if l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ㪽") in list(l11llll1l1l_l1_.keys()):
			l11ll1l1111_l1_ = l1l11l_l1_ (u"ࠩࡰࡴࡩ࠭㪾")
			#l11ll1l1111_l1_ = l11ll1l1111_l1_+l11llll1l1l_l1_[l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ㪿")]
		if l11ll1l1111_l1_ not in l11l111ll11_l1_:
			l11l111ll11_l1_.append(l11ll1l1111_l1_)
			l1llll1111l1_l1_.append([l11l11l1ll1_l1_,l11llll1l1l_l1_,title,l11llllll11_l1_])
			#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ㫀"),str(l11llllll11_l1_)+l1l11l_l1_ (u"ࠬࠦࠠࠡࠩ㫁")+title)
	#l1llll1111l1_l1_ = sorted(l1llll1111l1_l1_, reverse=True, key=lambda key: int(key[3]))
	l11111l1l1l_l1_,l111l1ll11l_l1_,shift = [],[],0
	l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࡳࡼࡴࡥࡳࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡳࡼࡴࡥࡳࠤ࠽࠲࠯ࡅࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡲࡻࡳ࡫ࡲ࠻ࠌࠌࠍࡸ࡮ࡩࡧࡶࠣ࠯ࡂࠦ࠱ࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ࠮ࡳࡼࡴࡥࡳ࡝࠳ࡡࡠ࠶࡝ࠬࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠴ࡡࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡍࡦࡰࡸ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡣࡩࡱ࡬ࡧࡪࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ㫂")
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࡴࡽ࡮ࡦࡴࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡩࡨࡢࡰࡱࡩࡱࡏࡤࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮ࡢ࡮ࡸࡵ࡮࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏ࡯ࡸࡰࡨࡶࡤࡴࡡ࡮ࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡦࡻࡴࡩࡱࡵࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱࡥࡪࡴࡱࡱ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥࡵࡷ࡯ࡧࡵࡣࡳࡧ࡭ࡦ࠼ࠍࠍࠎ࡯࡭ࡢࡩࡨࡷࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠥࠬ࠳࠰࠿ࠪࠤࡤࡰࡱࡵࡷࡓࡣࡷ࡭ࡳ࡭ࡳࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣ࡭ࡲࡧࡧࡦࡵࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࠉࡪ࡯ࡤ࡫ࡪࡹ࡟ࡶࡴ࡯ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡻࡲ࡭ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡩ࡮ࡣࡪࡩࡸࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࡯࡭ࡢࡩࡨࡷࡤࡻࡲ࡭࠼ࠣ࡭ࡲࡧࡧࡦࠢࡀࠤ࡮ࡳࡡࡨࡧࡶࡣࡺࡸ࡬࡜࠯࠴ࡡࠏࠏࠉࡰࡹࡱࡩࡷࠦ࠽ࠡࡱࡺࡲࡪࡸ࡟࡯ࡣࡰࡩࡠ࠶࡝ࠋࠋࠌࡷ࡭࡯ࡦࡵࠢ࠮ࡁࠥ࠷ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ࠭ࡲࡻࡳ࡫ࡲࠬࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡘࡇࡅࡗࡎ࡚ࡅࡔ࡝ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫࡢࡡ࠰࡞࠭ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠫࡰࡹࡱࡩࡷࡥࡣࡩࡣࡱࡲࡪࡲ࡛࠱࡟ࠍࠍࠎࡹࡥ࡭ࡧࡦࡸࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡨ࡮࡯ࡪࡥࡨࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠤࠥࠦ㫃")
	l1l11111111_l1_,l11ll11l1l1_l1_ = l1l11l_l1_ (u"ࠨࠩ㫄"),l1l11l_l1_ (u"ࠩࠪ㫅")
	try: l1l11111111_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ㫆")][l1l11l_l1_ (u"ࠫࡦࡻࡴࡩࡱࡵࠫ㫇")]
	except: l1l11111111_l1_ = l1l11l_l1_ (u"ࠬ࠭㫈")
	try: l1111ll111l_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ㫉")][l1l11l_l1_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠪ㫊")]
	except: l1111ll111l_l1_ = l1l11l_l1_ (u"ࠨࠩ㫋")
	if l1l11111111_l1_ and l1111ll111l_l1_:
		shift += 1
		title = l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭㫌")+l1l11111111_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㫍")
		l1111l_l1_ = WEBSITES[l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㫎")][0]+l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ㫏")+l1111ll111l_l1_
		l11111l1l1l_l1_.append(title)
		l111l1ll11l_l1_.append(l1111l_l1_)
		try: l11ll11l1l1_l1_ = l11l1l1l111_l1_[l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ㫐")][l1l11l_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪ㫑")][l1l11l_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬ㫒")][-1][l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㫓")]
		except: pass
	#if l1llll1l111l_l1_:
	#	shift += 1
	#	l11111l1l1l_l1_.append(l1l11l_l1_ (u"ࠪࡱࡵࡪࠠอ๊าอࠥึใ๋หࠪ㫔")) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"ࠫࡩࡧࡳࡩࠩ㫕"))
	for l11l11l1ll1_l1_,l11llll1l1l_l1_,title,l11llllll11_l1_ in l1llll1111l1_l1_:
		l11111l1l1l_l1_.append(title) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭㫖"))
	if l1l111lll1l_l1_: l11111l1l1l_l1_.append(l1l11l_l1_ (u"࠭ี้ำฬࠤํ฻่ห่ࠢัิีษࠨ㫗")) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭㫘"))
	if l11111ll111_l1_: l11111l1l1l_l1_.append(l1l11l_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤฬ๊ๅห๊ไีࠬ㫙")) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"ࠩࡤࡰࡱ࠭㫚"))
	if l11ll1111ll_l1_: l11111l1l1l_l1_.append(l1l11l_l1_ (u"ࠪࡱࡵࡪࠠศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬ㫛")) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"ࠫࡲࡶࡤࠨ㫜"))
	if l11l1l11111_l1_: l11111l1l1l_l1_.append(l1l11l_l1_ (u"ࠬ฻่าหࠣฬิ๎ๆࠡื๋ฮࠬ㫝")) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㫞"))
	if l11lll1lll1_l1_: l11111l1l1l_l1_.append(l1l11l_l1_ (u"ࠧึ๊อࠤอี่็ุࠢ์ึฯࠧ㫟")) ; l111l1ll11l_l1_.append(l1l11l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ㫠"))
	l1l111lllll_l1_ = False
	while True:
		selection = DIALOG_SELECT(l1lll1ll1ll1_l1_, l11111l1l1l_l1_)
		if selection==-1: return l1l11l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ㫡"),[],[]
		elif selection==0 and l1l11111111_l1_:
			l1111l_l1_ = l111l1ll11l_l1_[selection]
			new_path = sys.argv[0]+l1l11l_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠲࠶࠴ࠪࡳࡧ࡭ࡦ࠿ࠪ㫢")+QUOTE(l1l11111111_l1_)+l1l11l_l1_ (u"ࠫࠫࡻࡲ࡭࠿ࠪ㫣")+l1111l_l1_
			if l11ll11l1l1_l1_: new_path = new_path+l1l11l_l1_ (u"ࠬࠬࡩ࡮ࡣࡪࡩࡂ࠭㫤")+QUOTE(l11ll11l1l1_l1_)
			settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㫥"),l1l11l_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㫦"))
			xbmc.executebuiltin(l1l11l_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ㫧")+new_path+l1l11l_l1_ (u"ࠤࠬࠦ㫨"))
			return l1l11l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ㫩"),[],[]
		choice = l111l1ll11l_l1_[selection]
		l1llllll111l_l1_ = l11111l1l1l_l1_[selection]
		if choice==l1l11l_l1_ (u"ࠫࡩࡧࡳࡩࠩ㫪"):
			l1llll1lll1l_l1_ = l1llll1l111l_l1_
			break
		elif choice in [l1l11l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ㫫"),l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㫬"),l1l11l_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭㫭")]:
			if choice==l1l11l_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ㫮"): l1l1lll_l1_,l111l111111_l1_ = l1l111lll1l_l1_,l1111l1ll1l_l1_
			elif choice==l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㫯"): l1l1lll_l1_,l111l111111_l1_ = l11l1l11111_l1_,l111l1l1111_l1_
			elif choice==l1l11l_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ㫰"): l1l1lll_l1_,l111l111111_l1_ = l11lll1lll1_l1_,l11ll1ll1l1_l1_
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ㫱"), l1l1lll_l1_)
			if selection!=-1:
				l1llll1lll1l_l1_ = l111l111111_l1_[selection][l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㫲")]
				l1llllll111l_l1_ = l1l1lll_l1_[selection]
				break
		elif choice==l1l11l_l1_ (u"࠭࡭ࡱࡦࠪ㫳"):
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่าห࠽ࠫ㫴"), l11ll1111ll_l1_)
			if selection!=-1:
				l1llllll111l_l1_ = l11ll1111ll_l1_[selection]
				l11ll11l1ll_l1_ = l1l111ll111_l1_[selection]
				selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ฬ࠽ࠫ㫵"), l111ll111ll_l1_)
				if selection!=-1:
					l1llllll111l_l1_ += l1l11l_l1_ (u"ࠩࠣ࠯ࠥ࠭㫶")+l111ll111ll_l1_[selection]
					l11l11l1l11_l1_ = l1l1111l11l_l1_[selection]
					l1l111lllll_l1_ = True
					break
		elif choice==l1l11l_l1_ (u"ࠪࡥࡱࡲࠧ㫷"):
			l11lll11l11_l1_,l111ll1l1ll_l1_,l1llll111lll_l1_,l11l1ll11l1_l1_ = list(zip(*l11111ll111_l1_))
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ㫸"), l1llll111lll_l1_)
			if selection!=-1:
				l1llllll111l_l1_ = l1llll111lll_l1_[selection]
				l11ll11l1ll_l1_ = l11lll11l11_l1_[selection]
				if l1l11l_l1_ (u"ࠬࡳࡰࡥࠩ㫹") in l1llll111lll_l1_[selection] and l11ll11l1ll_l1_[l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㫺")]!=l1llll1l111l_l1_:
					l11l11l1l11_l1_ = l111ll1l1ll_l1_[selection]
					l1l111lllll_l1_ = True
				else: l1llll1lll1l_l1_ = l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㫻")]
				break
		elif choice==l1l11l_l1_ (u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ㫼"):
			#shift += 1
			l11lll11l11_l1_,l111ll1l1ll_l1_,l1llll111lll_l1_,l11l1ll11l1_l1_ = list(zip(*l1llll1111l1_l1_))
			l11ll11l1ll_l1_ = l11lll11l11_l1_[selection-shift]
			if l1l11l_l1_ (u"ࠩࡰࡴࡩ࠭㫽") in l1llll111lll_l1_[selection-shift] and l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ㫾")]!=l1llll1l111l_l1_:
				l11l11l1l11_l1_ = l111ll1l1ll_l1_[selection-shift]
				l1l111lllll_l1_ = True
			else: l1llll1lll1l_l1_ = l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㫿")]
			l1llllll111l_l1_ = l1llll111lll_l1_[selection-shift]
			break
	if not l1l111lllll_l1_: l1llll1ll1ll_l1_ = l1llll1lll1l_l1_
	else: l1llll1ll1ll_l1_ = l1l11l_l1_ (u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥ࠭㬀")+l11ll11l1ll_l1_[l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㬁")]+l1l11l_l1_ (u"ࠧࠡ࠭ࠣࡅࡺࡪࡩࡰ࠼ࠣࠫ㬂")+l11l11l1l11_l1_[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㬃")]
	if l1l111lllll_l1_:
		#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ㬄"),l1l11l_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ㬅")+str(l11ll11l1ll_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ㬆"),l1l11l_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ㬇")+str(l11l11l1l11_l1_))
		#if l1l111l1ll1_l1_>l11l1111lll_l1_: duration = str(l1l111l1ll1_l1_)
		#else: duration = str(l11l1111lll_l1_)
		#duration = str(l1l111l1ll1_l1_) if l1l111l1ll1_l1_>l11l1111lll_l1_ else str(l11l1111lll_l1_)
		l1l111l1ll1_l1_ = int(l11ll11l1ll_l1_[l1l11l_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ㬈")])
		l11l1111lll_l1_ = int(l11l11l1l11_l1_[l1l11l_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ㬉")])
		duration = str(max(l1l111l1ll1_l1_,l11l1111lll_l1_))
		l111llll11l_l1_ = l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㬊")].replace(l1l11l_l1_ (u"ࠩࠩࠫ㬋"),l1l11l_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ㬌"))		# +l1l11l_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ㬍")
		l11lll1llll_l1_ = l11l11l1l11_l1_[l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㬎")].replace(l1l11l_l1_ (u"࠭ࠦࠨ㬏"),l1l11l_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭㬐"))		# +l1l11l_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ㬑")
		l1l111lll11_l1_ = l1l11l_l1_ (u"ࠩ࠿ࡃࡽࡳ࡬ࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥ࠵࠳࠶ࠢࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࡀ࡚࡚ࠦࡆ࠮࠺ࠥࡃࡃࡢ࡮ࠨ㬒")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠪࡀࡒࡖࡄࠡࡺࡰࡰࡳࡹ࠺ࡹࡵ࡬ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠵࠴࠵࠷࠯࡙ࡏࡏࡗࡨ࡮ࡥ࡮ࡣ࠰࡭ࡳࡹࡴࡢࡰࡦࡩࠧࠦࡸ࡮࡮ࡱࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠣࠢࡻࡱࡱࡴࡳ࠻ࡺ࡯࡭ࡳࡱ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠷࠹࠺࠻࠲ࡼࡱ࡯࡮࡬ࠤࠣࡼࡸ࡯࠺ࡴࡥ࡫ࡩࡲࡧࡌࡰࡥࡤࡸ࡮ࡵ࡮࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡ࡯ࡦࡤࡶࡩࡹ࠮ࡪࡵࡲ࠲ࡴࡸࡧ࠰࡫ࡷࡸ࡫࠵ࡐࡶࡤ࡯࡭ࡨࡲࡹࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡖࡸࡦࡴࡤࡢࡴࡧࡷ࠴ࡓࡐࡆࡉ࠰ࡈࡆ࡙ࡈࡠࡵࡦ࡬ࡪࡳࡡࡠࡨ࡬ࡰࡪࡹ࠯ࡅࡃࡖࡌ࠲ࡓࡐࡅ࠰ࡻࡷࡩࠨࠠ࡮࡫ࡱࡆࡺ࡬ࡦࡦࡴࡗ࡭ࡲ࡫࠽ࠣࡒࡗ࠵࠳࠻ࡓࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫ㬓")+duration+l1l11l_l1_ (u"ࠫࡘࠨࠠࡵࡻࡳࡩࡂࠨࡳࡵࡣࡷ࡭ࡨࠨࠠࡱࡴࡲࡪ࡮ࡲࡥࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡴࡷࡵࡦࡪ࡮ࡨ࠾࡮ࡹ࡯ࡧࡨ࠰ࡱࡦ࡯࡮࠻࠴࠳࠵࠶ࠨ࠾࡝ࡰࠪ㬔")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠬࡂࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ㬕")
		l1l111lll11_l1_ += l1l11l_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠵ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡺ࡮ࡪࡥࡰ࠱ࠪ㬖")+l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㬗")]+l1l11l_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ㬘")		# l11l111lll1_l1_=l1l11l_l1_ (u"ࠤ࠴ࠦ㬙") l1l111ll1l1_l1_=l1l11l_l1_ (u"ࠥࡸࡷࡻࡥࠣ㬚") default=l1l11l_l1_ (u"ࠦࡹࡸࡵࡦࠤ㬛")>\n
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ㬜")
		l1l111lll11_l1_ += l1l11l_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭㬝")+l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ㬞")]+l1l11l_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ㬟")+l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ㬠")]+l1l11l_l1_ (u"ࠪࠦࠥࡹࡴࡢࡴࡷ࡛࡮ࡺࡨࡔࡃࡓࡁࠧ࠷ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠭㬡")+str(l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㬢")])+l1l11l_l1_ (u"ࠬࠨࠠࡸ࡫ࡧࡸ࡭ࡃࠢࠨ㬣")+str(l11ll11l1ll_l1_[l1l11l_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ㬤")])+l1l11l_l1_ (u"ࠧࠣࠢ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠫ㬥")+str(l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ㬦")])+l1l11l_l1_ (u"ࠩࠥࠤ࡫ࡸࡡ࡮ࡧࡕࡥࡹ࡫࠽ࠣࠩ㬧")+l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠪࡪࡵࡹࠧ㬨")]+l1l11l_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ㬩")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ㬪")+l111llll11l_l1_+l1l11l_l1_ (u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ㬫")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ㬬")+l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ㬭")]+l1l11l_l1_ (u"ࠩࠥࡂࡡࡴࠧ㬮")	# l1llll1111ll_l1_=l1l11l_l1_ (u"ࠥࡸࡷࡻࡥࠣ㬯")>\n
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧ㬰")+l11ll11l1ll_l1_[l1l11l_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ㬱")]+l1l11l_l1_ (u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭㬲")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ㬳")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ㬴")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ㬵")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠳ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧ㬶")+l11l11l1l11_l1_[l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㬷")]+l1l11l_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ㬸")		# l11l111lll1_l1_=l1l11l_l1_ (u"ࠨ࠱ࠣ㬹") l1l111ll1l1_l1_=l1l11l_l1_ (u"ࠢࡵࡴࡸࡩࠧ㬺") default=l1l11l_l1_ (u"ࠣࡶࡵࡹࡪࠨ㬻")>\n
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ㬼")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ㬽")+l11l11l1l11_l1_[l1l11l_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ㬾")]+l1l11l_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ㬿")+l11l11l1l11_l1_[l1l11l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭㭀")]+l1l11l_l1_ (u"ࠧࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࠱࠴࠲࠷࠻࠺ࠨ࠾࡝ࡰࠪ㭁")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠨ࠾ࡄࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠧ㭂")+l11l11l1l11_l1_[l1l11l_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ㭃")]+l1l11l_l1_ (u"ࠪࠦ࠴ࡄ࡜࡯ࠩ㭄")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ㭅")+l11lll1llll_l1_+l1l11l_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ㭆")
		l1l111lll11_l1_ += l1l11l_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ㭇")+l11l11l1l11_l1_[l1l11l_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭㭈")]+l1l11l_l1_ (u"ࠨࠤࡁࡠࡳ࠭㭉")	# l1llll1111ll_l1_=l1l11l_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ㭊")>\n
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭㭋")+l11l11l1l11_l1_[l1l11l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ㭌")]+l1l11l_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ㭍")
		l1l111lll11_l1_ += l1l11l_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ㭎")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭㭏")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭㭐")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠩ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ㭑")
		l1l111lll11_l1_ += l1l11l_l1_ (u"ࠪࡀ࠴ࡓࡐࡅࡀ࡟ࡲࠬ㭒")
		#open(l1l11l_l1_ (u"ࠫࡸࡀ࡜࡝ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭㭓"),l1l11l_l1_ (u"ࠬࡽࡢࠨ㭔")).write(l1l111lll11_l1_)
		#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ㭕"),l1l111lll11_l1_)
		#l1l111lll11_l1_ = OPENURL_CACHED(NO_CACHE,l1llll1l111l_l1_,l1l11l_l1_ (u"ࠧࠨ㭖"),l1l11l_l1_ (u"ࠨࠩ㭗"),l1l11l_l1_ (u"ࠩࠪ㭘"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠺ࡶ࡫ࠫ㭙"))
		if kodi_version>18.99:
			import http.server as l11lll11ll1_l1_
			import http.client as l11111l11ll_l1_
		else:
			import BaseHTTPServer as l11lll11ll1_l1_
			import httplib as l11111l11ll_l1_
		class l1lllll1ll1l_l1_(l11lll11ll1_l1_.HTTPServer):
			#l1l111lll11_l1_ = l1l11l_l1_ (u"ࠫࡁࡄࠧ㭚")
			def __init__(self,l11111llll1_l1_=l1l11l_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ㭛"),port=55055,l1l111lll11_l1_=l1l11l_l1_ (u"࠭࠼࠿ࠩ㭜")):
				self.l11111llll1_l1_ = l11111llll1_l1_
				self.port = port
				self.l1l111lll11_l1_ = l1l111lll11_l1_
				l11lll11ll1_l1_.HTTPServer.__init__(self,(self.l11111llll1_l1_,self.port),l111l1lll1l_l1_)
				self.l1lllll11l1l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ㭝")+l11111llll1_l1_+l1l11l_l1_ (u"ࠨ࠼ࠪ㭞")+str(port)+l1l11l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ㭟")
				#print(l1l11l_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡵࡱࠢࡱࡳࡼࠦ࡬ࡪࡵࡷࡩࡳ࡯࡮ࡨࠢࡲࡲࠥࡶ࡯ࡳࡶ࠽ࠤࠬ㭠")+str(port))
			def start(self):
				self.threads = l11ll11llll_l1_(False)
				self.threads.start_new_thread(1,self.l11l11111ll_l1_)
			def l11l11111ll_l1_(self):
				#print(l1l11l_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡤࡶࡹ࡫ࡤࠨ㭡"))
				self.l1lll1llll1l_l1_ = True
				#l1ll1llll1l_l1_ = 0
				while self.l1lll1llll1l_l1_:
					#l1ll1llll1l_l1_ += 1
					#print(l1l11l_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡪࡤࡲࡩࡲࡥࡠࡴࡨࡵࡺ࡫ࡳࡵࠪࠬࠤࡳࡵࡷ࠻ࠢࠪ㭢")+str(l1ll1llll1l_l1_)+l1l11l_l1_ (u"࠭ࠧ㭣"))
					#settimeout l11lllll1l_l1_ not l1l111ll11_l1_ l1111l1l1l1_l1_ to error message if it l1lllllllll1_l1_ l1llll11ll1l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l11l11111ll_l1_ l11l111l1l1_l1_ request l1lllll1111l_l1_ 60 seconds)
					self.handle_request()
				#print(l1l11l_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡵࡰࡱࡧࡧࡠࡳ࠭㭤"))
			def stop(self):
				self.l1lll1llll1l_l1_ = False
				self.l11l11l1lll_l1_()	# needed to l1l1111ll1l_l1_ self.handle_request() to l11l11111ll_l1_ l11l1lll1ll_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l1l11l_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠢࡱࡳࡼࡢ࡮ࠨ㭥"))
			def load(self,l1l111lll11_l1_):
				self.l1l111lll11_l1_ = l1l111lll11_l1_
			def l11l11l1lll_l1_(self):
				conn = l11111l11ll_l1_.HTTPConnection(self.l11111llll1_l1_+l1l11l_l1_ (u"ࠩ࠽ࠫ㭦")+str(self.port))
				conn.request(l1l11l_l1_ (u"ࠥࡌࡊࡇࡄࠣ㭧"), l1l11l_l1_ (u"ࠦ࠴ࠨ㭨"))
		class l111l1lll1l_l1_(l11lll11ll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l1l11l_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡌࡋࡔࠡࠢࠪ㭩")+self.path)
				self.send_response(200)
				self.send_header(l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ㭪"),l1l11l_l1_ (u"ࠧࡵࡧࡻࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ㭫"))
				self.end_headers()
				#self.wfile.write(self.path+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㭬"))
				self.wfile.write(self.server.l1l111lll11_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㭭")))
				time.sleep(1)
				if self.path==l1l11l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㭮"): self.server.shutdown()
				if self.path==l1l11l_l1_ (u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ㭯"): self.server.shutdown()
			def do_HEAD(self):
				#print(l1l11l_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡍࡋࡁࡅࠢࠣࠫ㭰")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1lllll1ll1l_l1_(l1l11l_l1_ (u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩ㭱"),55055,l1l111lll11_l1_)
		#httpd.load(l1l111lll11_l1_)
		l1llll1lll1l_l1_ = httpd.l1lllll11l1l_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1llll1lll1l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮࡬ࡺࡪࡹࡩ࡮࠰ࡧࡥࡸ࡮ࡩࡧ࠰ࡲࡶ࡬࠵࡬ࡪࡸࡨࡷ࡮ࡳ࠯ࡤࡪࡸࡲࡰࡪࡵࡳࡡ࠴࠳ࡦࡺ࡯ࡠ࠹࠲ࡸࡪࡹࡴࡱ࡫ࡦ࠸ࡤ࠾ࡳ࠰ࡏࡤࡲ࡮࡬ࡥࡴࡶ࠱ࡱࡵࡪࠧ㭲")
		#l1llll1lll1l_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡥࡸ࡮࠮ࡢ࡭ࡤࡱࡦ࡯ࡺࡦࡦ࠱ࡲࡪࡺ࠯ࡥࡣࡶ࡬࠷࠼࠴࠰ࡖࡨࡷࡹࡉࡡࡴࡧࡶ࠳࠷ࡩ࠯ࡲࡷࡤࡰࡨࡵ࡭࡮࠱࠴࠳ࡒࡻ࡬ࡵ࡫ࡕࡩࡸࡓࡐࡆࡉ࠵࠲ࡲࡶࡤࠨ㭳")
		#l1llll1lll1l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡹࡹࡩ࠯ࡶࡨࡰࡪࡩ࡯࡮࠯ࡳࡥࡷ࡯ࡳࡵࡧࡦ࡬࠳࡬ࡲ࠰ࡩࡳࡥࡨ࠵ࡄࡂࡕࡋࡣࡈࡕࡎࡇࡑࡕࡑࡆࡔࡃࡆ࠱ࡗࡩࡱ࡫ࡣࡰ࡯ࡓࡥࡷ࡯ࡳࡕࡧࡦ࡬࠴ࡳࡰ࠵࠯࡯࡭ࡻ࡫࠯࡮ࡲ࠷࠱ࡱ࡯ࡶࡦ࠯ࡰࡴࡩ࠳ࡁࡗ࠯ࡅࡗ࠳ࡳࡰࡥࠩ㭴")
		#l1llll1lll1l_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡶࡩࡳࡥࡥ࡫ࡤ࠲ࡧࡨࡣ࠯ࡥࡲ࠲ࡺࡱ࠯ࡥࡣࡶ࡬࠴ࡵ࡮ࡥࡧࡰࡥࡳࡪ࠯ࡵࡧࡶࡸࡨࡧࡲࡥ࠱࠴࠳ࡨࡲࡩࡦࡰࡷࡣࡲࡧ࡮ࡪࡨࡨࡷࡹ࠳ࡥࡷࡧࡱࡸࡸ࠳࡭ࡶ࡮ࡷ࡭ࡱࡧ࡮ࡨ࠰ࡰࡴࡩ࠭㭵")
		#l1llll1lll1l_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ㭶")
	else: httpd = l1l11l_l1_ (u"ࠬ࠭㭷")
	if not l1llll1lll1l_l1_: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭㭸"),[],[]
	return l1l11l_l1_ (u"ࠧࠨ㭹"),[l1l11l_l1_ (u"ࠨࠩ㭺")],[[l1llll1lll1l_l1_,l111lll111l_l1_,httpd]]
def l1111lll1ll_l1_(url):
	# l11l11l_l1_://l1l11111l1l_l1_.l11111ll_l1_/l111l11llll_l1_
	headers = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㭻") : l1l11l_l1_ (u"ࠪࠫ㭼") }
	#url = url.replace(l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ㭽"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ㭾"))
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"࠭ࠧ㭿"),headers,l1l11l_l1_ (u"ࠧࠨ㮀"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨ㮁"))
	items = re.findall(l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭㮂"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l11ll111l11_l1_,l1l1lll_l1_,l11lll1l111_l1_,l1ll1l1l_l1_ = [],[],[],[]
	if items:
		for l1111l_l1_,dummy,l111l111lll_l1_ in items:
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ㮃"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ㮄"))
			if l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㮅") in l1111l_l1_:
				l11ll111l11_l1_,l11lll1l111_l1_ = l1ll11111l_l1_(l1111l_l1_)
				#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㮆"),l1l11l_l1_ (u"ࠧࠨ㮇"),str(l1ll1l1l_l1_),str(l11lll1l111_l1_))
				l1ll1l1l_l1_ = l1ll1l1l_l1_ + l11lll1l111_l1_
				if l11ll111l11_l1_[0]==l1l11l_l1_ (u"ࠨ࠯࠴ࠫ㮈"): l1l1lll_l1_.append(l1l11l_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ㮉")+l1l11l_l1_ (u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ㮊"))
				else:
					for title in l11ll111l11_l1_:
						l1l1lll_l1_.append(l1l11l_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ㮋")+l1l11l_l1_ (u"ࠬࠦࠠࠡࠩ㮌")+title)
			else:
				title = l1l11l_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ㮍")+l1l11l_l1_ (u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪ㮎")+l111l111lll_l1_
				l1ll1l1l_l1_.append(l1111l_l1_)
				l1l1lll_l1_.append(title)
		return l1l11l_l1_ (u"ࠨࠩ㮏"),l1l1lll_l1_,l1ll1l1l_l1_
	else: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ㮐"),[],[]
def	l1llll1l11ll_l1_(url):
	# l11l11l_l1_://l1l111l1111_l1_.cc/l1l11111l_l1_-1qrpoobdg7bu.html
	# l11l11l_l1_://l11l11l11ll_l1_.cc//l1l11111l_l1_-l11l1ll11ll_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㮑"),url,l1l11l_l1_ (u"ࠫࠬ㮒"),l1l11l_l1_ (u"ࠬ࠭㮓"),l1l11l_l1_ (u"࠭ࠧ㮔"),l1l11l_l1_ (u"ࠧࠨ㮕"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡜ࡉࡅࡇࡒࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ㮖"))
	html = response.content
	l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㮗"),html,re.DOTALL)
	if l1l1lll1_l1_:
		l1111l_l1_ = l1l1lll1_l1_[0]
		return l1l11l_l1_ (u"ࠪࠫ㮘"),[l1l11l_l1_ (u"ࠫࠬ㮙")],[l1111l_l1_]
	return l1l11l_l1_ (u"ࠬ࠭㮚"),[],[]
def	l1llll1ll111_l1_(url):
	# l11l11l_l1_://l1llll1l1lll_l1_.in/l11111111ll_l1_
	# l11l11l_l1_://l1llll1l1lll_l1_.in/l1l11111l_l1_-l11111111ll_l1_.html
	# l11l11l_l1_://l11l1l1l1ll_l1_.l1111l11111_l1_/l11llllll1l_l1_
	# l11l11l_l1_://l11l1l1l1ll_l1_.l1111l11111_l1_/l1l11111l_l1_-l11llllll1l_l1_.html
	# l11l11l_l1_://l1llllll1ll1_l1_.l1l111111l1_l1_.l11111ll_l1_/l1l11111l_l1_-l111ll11lll_l1_.html
	url = url.replace(l1l11l_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭㮛"),l1l11l_l1_ (u"ࠧࠨ㮜")).replace(l1l11l_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ㮝"),l1l11l_l1_ (u"ࠩࠪ㮞"))
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㮟"),url,l1l11l_l1_ (u"ࠫࠬ㮠"),l1l11l_l1_ (u"ࠬ࠭㮡"),l1l11l_l1_ (u"࠭ࠧ㮢"),l1l11l_l1_ (u"ࠧࠨ㮣"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ㮤"))
	html = response.content
	l111lll1l11_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭ࡡ࠯ࠩࠨ㮥"),html,re.DOTALL)
	if l111lll1l11_l1_:
		l111lll1l11_l1_ = l111lll1l11_l1_[0]
		l11111l11l1_l1_ = l11111lllll_l1_(l111lll1l11_l1_)
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㮦"),l11111l11l1_l1_,re.DOTALL)
		if not l1l1lll1_l1_: l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠭ࢂ࠭㮧"),l11111l11l1_l1_,re.DOTALL)
		l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
		for l1111l_l1_,title in l1l1lll1_l1_:
			if not title: title = l1111l_l1_.rsplit(l1l11l_l1_ (u"ࠬ࠴ࠧ㮨"),1)[1]
			l1l1lll_l1_.append(title)
			l1ll1l1l_l1_.append(l1111l_l1_)
		return l1l11l_l1_ (u"࠭ࠧ㮩"),l1l1lll_l1_,l1ll1l1l_l1_
	id = url.split(l1l11l_l1_ (u"ࠧ࠰ࠩ㮪"))[3]
	headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㮫"):l1l11l_l1_ (u"ࠩࠪ㮬") , l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㮭"):l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㮮") }
	payload = { l1l11l_l1_ (u"ࠬ࡯ࡤࠨ㮯"):id , l1l11l_l1_ (u"࠭࡯ࡱࠩ㮰"):l1l11l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ㮱") }
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭㮲"),url,payload,headers,l1l11l_l1_ (u"ࠩࠪ㮳"),l1l11l_l1_ (u"ࠪࠫ㮴"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ㮵"))
	html = response.content
	items = re.findall(l1l11l_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㮶"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"࠭ࠧ㮷"),[l1l11l_l1_ (u"ࠧࠨ㮸")],[ items[0] ]
	return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈࠩ㮹"),[],[]
l1l11l_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡊࡓ࡛ࡏࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࠥࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵࡶࡪࡦ࠱ࡧࡴ࠵ࡶࡪࡦࡨࡳ࠴ࡶ࡬ࡢࡻ࠲ࡅࡆ࡜ࡅࡏࡦࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࠡ࠼ࠣࠫࠬࠦࡽࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡖࡊࡆ࠰࠵ࡸࡺࠧࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡪࠥ࠭࠮࡮࠵ࡸ࠼ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾ࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࡵࡧࡰࡴࡠ࠶࡝࠾࠿ࠪ࠱࠶࠭࠺ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧู๊ࠬࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠾ࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧิ์ิๅึࠦฮศืࠪ࠯ࠬࠦࠠࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱࡵ࠺ࠧࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔ࡜ࡉࡅࠩ࠯࡟ࡢ࠲࡛࡞ࠌࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠲࡯࠱࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡹࡴࡳࡧࡤࡱ࠴࠸࠲࠺࠰ࡰ࠷ࡺ࠾ࠊࠣࠤࠥ㮺")
#####################################################
#    l11llll1l11_l1_ l111l1l1l1l_l1_ l1111l111ll_l1_
#    16-06-2019
#####################################################
def l111l11l111_l1_(url):
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠪࠫ㮻"),l1l11l_l1_ (u"ࠫࠬ㮼"),l1l11l_l1_ (u"ࠬ࠭㮽"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡌࡐࡃࡇࡗ࠲࠷ࡳࡵࠩ㮾"))
	items = re.findall(l1l11l_l1_ (u"ࠧࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㮿"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"ࠨࠩ㯀"),[l1l11l_l1_ (u"ࠩࠪ㯁")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨ㯂"),[],[]
def l1111l1llll_l1_(url):
	return l1l11l_l1_ (u"ࠫࠬ㯃"),[l1l11l_l1_ (u"ࠬ࠭㯄")],[ url ]
def l111l1l1lll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㯅"),l1l11l_l1_ (u"ࠧࠨ㯆"),url,l1l11l_l1_ (u"ࠨࠩ㯇"))
	server = url.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㯈"))
	basename = l1l11l_l1_ (u"ࠪ࠳ࠬ㯉").join(server[0:3])
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠫࠬ㯊"),l1l11l_l1_ (u"ࠬ࠭㯋"),l1l11l_l1_ (u"࠭ࠧ㯌"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ㯍"))
	items = re.findall(l1l11l_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ㯎"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㯏"),l1l11l_l1_ (u"ࠪࠫ㯐"),url,str(var))
	if items:
		l1l1ll1llll_l1_,l1l1lllll11_l1_,l1l1lllll1l_l1_,l11l1ll1111_l1_,l11l1ll111l_l1_,l11l1l1llll_l1_ = items[0]
		var = int(l1l1lllll11_l1_) % int(l1l1lllll1l_l1_) + int(l11l1ll1111_l1_) % int(l11l1ll111l_l1_)
		url = basename + l1l1ll1llll_l1_ + str(var) + l11l1l1llll_l1_
		return l1l11l_l1_ (u"ࠫࠬ㯑"),[l1l11l_l1_ (u"ࠬ࠭㯒")],[url]
	else: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ㯓"),[],[]
def l11l1l11l1l_l1_(url):
	url = url.replace(l1l11l_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ㯔"),l1l11l_l1_ (u"ࠨࠩ㯕"))
	url = url.replace(l1l11l_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ㯖"),l1l11l_l1_ (u"ࠪࠫ㯗"))
	id = url.split(l1l11l_l1_ (u"ࠫ࠴࠭㯘"))[-1]
	headers = { l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㯙") : l1l11l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ㯚") }
	payload = { l1l11l_l1_ (u"ࠢࡪࡦࠥ㯛"):id , l1l11l_l1_ (u"ࠣࡱࡳࠦ㯜"):l1l11l_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ㯝") }
	request = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㯞"), url, payload, headers, l1l11l_l1_ (u"ࠫࠬ㯟"),l1l11l_l1_ (u"ࠬ࠭㯠"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ㯡"))
	if l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㯢") in list(request.headers.keys()): l1111l_l1_ = request.headers[l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㯣")]
	else: l1111l_l1_ = url
	if l1111l_l1_: return l1l11l_l1_ (u"ࠩࠪ㯤"),[l1l11l_l1_ (u"ࠪࠫ㯥")],[l1111l_l1_]
	else: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ㯦"),[],[]
def l11111l1111_l1_(url):
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠬ࠭㯧"),l1l11l_l1_ (u"࠭ࠧ㯨"),l1l11l_l1_ (u"ࠧࠨ㯩"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ㯪"))
	items = re.findall(l1l11l_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ㯫"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"ࠪࠫ㯬"),[l1l11l_l1_ (u"ࠫࠬ㯭")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ㯮"),[],[]
def l1lll1llllll_l1_(url):
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"࠭ࠧ㯯"),l1l11l_l1_ (u"ࠧࠨ㯰"),l1l11l_l1_ (u"ࠨࠩ㯱"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ㯲"))
	items = re.findall(l1l11l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㯳"),html,re.DOTALL)
	#l11l11l11l1_l1_.l1llll11l1l1_l1_(l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ㯴") + items[0])
	if items:
		url = url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ㯵") + items[0]
		return l1l11l_l1_ (u"࠭ࠧ㯶"),[l1l11l_l1_ (u"ࠧࠨ㯷")],[ url ]
	else: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ㯸"),[],[]
def l111ll1l11l_l1_(url):
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠩࠪ㯹"),l1l11l_l1_ (u"ࠪࠫ㯺"),l1l11l_l1_ (u"ࠫࠬ㯻"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖ࠰࠵ࡸࡺࠧ㯼"))
	items = re.findall(l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㯽"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㯾"),l1l11l_l1_ (u"ࠨࠩ㯿"),str(items),html)
	if items: return l1l11l_l1_ (u"ࠩࠪ㰀"),[l1l11l_l1_ (u"ࠪࠫ㰁")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡖࡄࡏࡍࡈ࡜ࡉࡅࡇࡒࡌࡔ࡙ࡔࠨ㰂"),[],[]
def l111l1111ll_l1_(url):
	#url = url.replace(l1l11l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ㰃"),l1l11l_l1_ (u"࠭ࠧ㰄"))
	html = OPENURL_CACHED(l1111lll_l1_,url,l1l11l_l1_ (u"ࠧࠨ㰅"),l1l11l_l1_ (u"ࠨࠩ㰆"),l1l11l_l1_ (u"ࠩࠪ㰇"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ㰈"))
	items = re.findall(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㰉"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㰊"),l1l11l_l1_ (u"࠭ࠧ㰋"),items[0],items[0])
	if items: return l1l11l_l1_ (u"ࠧࠨ㰌"),[l1l11l_l1_ (u"ࠨࠩ㰍")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ㰎"),[],[]
l1l11l_l1_ (u"ࠥࠦࠧࠐࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠎࠨࠦࠠࠡࠢࡑࡓ࡙ࠦࡗࡐࡔࡎࡍࡓࡍࠠࡂࡐ࡜ࡑࡔࡘࡅࠋࠥࠣࠤࠥࠦ࠰࠳࠯ࡉࡉࡇ࠳࠲࠱࠴࠴ࠎࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠌࠍࠎࠏࠐࠢࠣࠤ㰏")
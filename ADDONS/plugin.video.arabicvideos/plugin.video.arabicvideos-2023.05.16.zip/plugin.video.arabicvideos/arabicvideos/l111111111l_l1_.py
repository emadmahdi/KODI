# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ䅧")
headers = { l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䅨") : l1l11l_l1_ (u"ࠨࠩ䅩") }
menu_name = l1l11l_l1_ (u"ࠩࡢࡗࡍ࠺࡟ࠨ䅪")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ䅫"),l1l11l_l1_ (u"ࠫฬ๊ใๅࠩ䅬"),l1l11l_l1_ (u"ࠬอแๅษ่ࠫ䅭"),l1l11l_l1_ (u"࠭ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪ䅮"),l1l11l_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ䅯")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l111l1_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l111ll_l1_(url)
	elif mode==114: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ䅰")+text)
	elif mode==115: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭䅱")+text)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䅲"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ䅳"),headers,l1l11l_l1_ (u"ࠬ࠭䅴"),l1l11l_l1_ (u"࠭ࠧ䅵"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䅶"))
	html = response.content
	l1l1ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䅷"),html,re.DOTALL)
	l1l1ll11_l1_ = l1l1ll11_l1_[0].strip(l1l11l_l1_ (u"ࠩ࠲ࠫ䅸"))
	l111l11l1_l1_ = SERVER(l1l1ll11_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ䅹"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䅺"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䅻"),l1l11l_l1_ (u"࠭ࠧ䅼"),119,l1l11l_l1_ (u"ࠧࠨ䅽"),l1l11l_l1_ (u"ࠨࠩ䅾"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䅿"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䆀"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䆁"),l1l1ll11_l1_,115)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䆂"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䆃"),l1l1ll11_l1_,114)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䆄"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䆅"),l1l11l_l1_ (u"ࠩࠪ䆆"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䆇"),l1l1ll11_l1_,l1l11l_l1_ (u"ࠫࠬ䆈"),headers,l1l11l_l1_ (u"ࠬ࠭䆉"),l1l11l_l1_ (u"࠭ࠧ䆊"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ䆋"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡺࡡࡣࡵࠫ࠲࠯ࡅࠩࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡶࡩࡦࡸࡣࡩࠩ䆌"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䆍"),block,re.DOTALL)
	for filter,title in items:
		#url = l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡌࡴࡳࡥ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡌࡴࡳࡥ࠯ࡲ࡫ࡴࠬ䆎")
		url = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡷ࡬ࡪࡳࡥ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡊࡲࡱࡪ࠴ࡰࡩࡲࠪ䆏")
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䆐"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䆑")+menu_name+title,url,111,l1l11l_l1_ (u"ࠧࠨ䆒"),l1l11l_l1_ (u"ࠨࠩ䆓"),filter)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䆔"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆕"),l1l11l_l1_ (u"ࠫࠬ䆖"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䆗"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䆘"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ䆙") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ䆚"))
		if l1l11l_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ䆛") in l1111l_l1_: title = l1l11l_l1_ (u"๊ࠪ๏ะแๅๅึࠫ䆜")
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆝"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䆞")+menu_name+title,l1111l_l1_,111)
	return html
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"࠭ࠧ䆟")):
	if l1l11l_l1_ (u"ࠧ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡗ࡭ࡵࡷࡴ࠰ࡳ࡬ࡵࡅࠧ䆠") in url:
		url,data = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䆡"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ䆢"),l1l11l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䆣"):l1l11l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䆤")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䆥"),url,data,headers2,l1l11l_l1_ (u"࠭ࠧ䆦"),l1l11l_l1_ (u"ࠧࠨ䆧"),l1l11l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䆨"))
		html = response.content
		block = html
	elif l1l11l_l1_ (u"ࠩࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡍࡵ࡭ࡦ࠰ࡳ࡬ࡵ࠭䆩") in url:
		data = {l1l11l_l1_ (u"ࠪࡥࡨࡺࡩࡰࡰࠪ䆪"):l1l11l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡨ࡬ࡰࡥ࡮ࠫ䆫"),l1l11l_l1_ (u"ࠬࡱࡥࡺࠩ䆬"):l11l11111_l1_}
		headers2 = {l1l11l_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䆭"):l1l11l_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䆮")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭䆯"),url,data,headers2,l1l11l_l1_ (u"ࠩࠪ䆰"),l1l11l_l1_ (u"ࠪࠫ䆱"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ䆲"))
		html = response.content
		block = html
	else:
		headers2 = {l1l11l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䆳"):l1l11l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䆴")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䆵"),url,l1l11l_l1_ (u"ࠨࠩ䆶"),headers2,l1l11l_l1_ (u"ࠩࠪ䆷"),l1l11l_l1_ (u"ࠪࠫ䆸"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠳ࡳࡦࠪ䆹"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡶࡡࡨࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪࡶࡤ࡫ࡸ࠳ࡣ࡭ࡱࡸࡨࠬ䆺"),html,re.DOTALL)
		if not l1ll111_l1_: return
		block = l1ll111_l1_[0]
	#items = re.findall(l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡣࡱࡻ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭䆻"),block,re.DOTALL)
	items = re.findall(l1l11l_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ䆼"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"ࠨ็ืห์ีษࠨ䆽"),l1l11l_l1_ (u"ࠩไ๎้๋ࠧ䆾"),l1l11l_l1_ (u"ࠪห฿์๊สࠩ䆿"),l1l11l_l1_ (u"่๊๊ࠫษࠩ䇀"),l1l11l_l1_ (u"ࠬอูๅษ้ࠫ䇁"),l1l11l_l1_ (u"࠭็ะษไࠫ䇂"),l1l11l_l1_ (u"ࠧๆสสีฬฯࠧ䇃"),l1l11l_l1_ (u"ࠨ฻ิฺࠬ䇄"),l1l11l_l1_ (u"่๋ࠩึาว็ࠩ䇅"),l1l11l_l1_ (u"ࠪห้ฮ่ๆࠩ䇆")]
	for l1111l_l1_,img,title in items:
		if l1l11l_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ䇇") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䇈") in l1111l_l1_: continue
		#l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭ࠦࠤ࠲࠶࠼ࡀ࠭䇉"),l1l11l_l1_ (u"ࠧࠧࠩ䇊"))
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠨ࠱ࠪ䇋"))
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䇌"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭䇍"),title,re.DOTALL)
		if l1l11l_l1_ (u"ࠫๆ๐ไๆࠩ䇎") in l1111l_l1_ or any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䇏"),menu_name+title,l1111l_l1_,112,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"࠭วๅฯ็ๆฮ࠭䇐") in title and l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭䇑") not in url:
			title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䇒") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇓"),menu_name+title,l1111l_l1_,113,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴ࠲ࠫ䇔") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇕"),menu_name+title,l1111l_l1_,111,img)
		elif l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䇖") in l1111l_l1_ and l1l11l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ䇗") not in url:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭䇘")
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇙"),menu_name+title,l1111l_l1_,111,img)
		elif l1l11l_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ䇚") in url and l1l11l_l1_ (u"ࠪั้่ษࠨ䇛") in title:
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䇜"),menu_name+title,l1111l_l1_,112,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇝"),menu_name+title,l1111l_l1_,113,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ䇞"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䇟"),block,re.DOTALL)
		if not items: items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䇠"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠩสฺ่็อสࠢࠪ䇡"),l1l11l_l1_ (u"ࠪࠫ䇢"))
			if title!=l1l11l_l1_ (u"ࠫࠬ䇣"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇤"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬ䇥")+title,l1111l_l1_,111)
	l111lll11_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䇦"),html,re.DOTALL)
	if l111lll11_l1_:
		l1111l_l1_ = l111lll11_l1_[0]
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇧"),menu_name+l1l11l_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะࠩ䇨"),l1111l_l1_,111)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䇩"),url,l1l11l_l1_ (u"ࠫࠬ䇪"),headers,l1l11l_l1_ (u"ࠬ࠭䇫"),l1l11l_l1_ (u"࠭ࠧ䇬"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䇭"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࠣ࡭ࡩࡃࠢࡴࡧࡤࡷࡴࡴࡳࠣࠪ࠱࠮ࡄ࠯ࡴࡢࡩࡶ࠱ࡨࡲ࡯ࡶࡦࠪ䇮"),html,re.DOTALL)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ䇯"),html,re.DOTALL)
	items = []
	# l111l111l_l1_
	if l11111l1l_l1_ and l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䇰") not in url:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䇱"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䇲"))
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䇳"),menu_name+title,l1111l_l1_,113,img)
	# l1l11l1_l1_
	elif l1ll1l1ll_l1_:
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳࡛ࡢ࠯ࡽࡡ࠰ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䇴"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ䇵"))
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䇶"),menu_name+title,l1111l_l1_,112,img)
	# l1l11l1_l1_ l1l1ll1l_l1_
	if not items and l1l11l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䇷") in html:
		l1ll1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡸࡥࡢࡦࡦࡶࡺࡳࡢࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䇸"),html,re.DOTALL)
		if l1ll1l1l1_l1_:
			block = l1ll1l1l1_l1_[0]
			l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䇹"),block,re.DOTALL)
			if len(l1l1lll1_l1_)>2:
				l1111l_l1_ = l1l1lll1_l1_[2]+l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫ䇺")
				l111l1_l1_(l1111l_l1_)
	return
def PLAY(url):
	l1ll1l1l_l1_ = []
	l11l1ll1_l1_ = url.strip(l1l11l_l1_ (u"ࠧ࠰ࠩ䇻"))
	hostname = SERVER(l11l1ll1_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ䇼"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䇽"),l11l1ll1_l1_,l1l11l_l1_ (u"ࠪࠫ䇾"),headers,l1l11l_l1_ (u"ࠫࠬ䇿"),l1l11l_l1_ (u"ࠬ࠭䈀"),l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䈁"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䈂"))
	id = re.findall(l1l11l_l1_ (u"ࠨࡲࡲࡷࡹࡏࡤ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䈃"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠤࠪ䈄"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠪࡴࡴࡹࡴ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䈅"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l1l11l_l1_ (u"ࠫࠬ䈆")
	#else: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䈇"),l1l11l_l1_ (u"࠭ࠧ䈈"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䈉"),l1l11l_l1_ (u"ࠨ์ิะ๎ࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ䈊"))
	if l1l11l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠥࠫ䈋") in html:
		#parts = url.split(l1l11l_l1_ (u"ࠪ࠳ࠬ䈌"))
		#url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ䈍"))
		url2 = l11l1ll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࠬ䈎")
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䈏"),url2,l1l11l_l1_ (u"ࠧࠨ䈐"),headers,l1l11l_l1_ (u"ࠨࠩ䈑"),l1l11l_l1_ (u"ࠩࠪ䈒"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ䈓"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䈔"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䈕"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1ll111_l1_: l1l11l1l_l1_ = l1ll111_l1_[0]
		else: l1l11l1l_l1_ = l1ll1ll1_l1_
		if not id:
			id = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡃࠢ࠱ࠤࠣࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䈖"),l1l11l1l_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l1l11l_l1_ (u"ࠧࠨ䈗")
		l11l1ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䈘"),l1ll1ll1_l1_,re.DOTALL)
		l1l111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ䈙"),l1ll1ll1_l1_,re.DOTALL)
		l11l1ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䈚"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ䈛"),l1ll1ll1_l1_)
		l11l1l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䈜"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1lll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䈝"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l1l1ll111ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䈞"),l1l11l1l_l1_,re.DOTALL|re.IGNORECASE)
		l1l1ll11l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ䈟"),l1l11l1l_l1_,re.DOTALL|re.IGNORECASE)
		items = l11l1ll11_l1_+l1l111l1l_l1_+l11l1ll1l_l1_+l11l1l1l1_l1_+l11l1l11l_l1_+l11ll1lll_l1_+l1l1ll111ll1_l1_+l1l1ll11l11l_l1_
		if not items:
			items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䈠"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠪࡠࡹ࠭䈡"),l1l11l_l1_ (u"ࠫࠬ䈢")).replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䈣"),l1l11l_l1_ (u"࠭ࠧ䈤")).strip(l1l11l_l1_ (u"ࠧࠡࠩ䈥"))
			#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ䈦"),title)
			if l1l11l_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧ䈧") in server: continue
			if l1l11l_l1_ (u"ࠪ࠲࡯ࡶࡧࠨ䈨") in server: continue
			if l1l11l_l1_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ䈩") in server: continue
			l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭䈪"),title,re.DOTALL)
			if l1l1l111_l1_:
				l1l1l111_l1_ = l1l1l111_l1_[0]
				if l1l1l111_l1_ in title: title = title.replace(l1l1l111_l1_+l1l11l_l1_ (u"࠭ࡰࠨ䈫"),l1l11l_l1_ (u"ࠧࠨ䈬")).replace(l1l1l111_l1_,l1l11l_l1_ (u"ࠨࠩ䈭")).strip(l1l11l_l1_ (u"ࠩࠣࠫ䈮"))
				l1l1l111_l1_ = l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䈯")+l1l1l111_l1_
			else: l1l1l111_l1_ = l1l11l_l1_ (u"ࠫࠬ䈰")
			if server.isdigit(): l1111l_l1_ = hostname+l1l11l_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ䈱")+id+l1l11l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䈲")+server+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䈳")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䈴")+l1l1l111_l1_
			else:
				if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䈵") not in server: server = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䈶")+server
				l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䈷"),title,re.DOTALL)
				if l1l1l111_l1_: l1l1l111_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䈸")+l1l1l111_l1_[0]
				else: l1l1l111_l1_ = l1l11l_l1_ (u"࠭ࠧ䈹")
				l1111l_l1_ = server+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨ䈺")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䈻"),l1ll1l1l_l1_)
	#l1ll1l1l_l1_ = []
	if l1l11l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴ࠨࠧ䈼") in html:
		#parts = url.split(l1l11l_l1_ (u"ࠪ࠳ࠬ䈽"))
		#url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䈾"))
		url2 = l11l1ll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䈿")
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䉀"),url2,l1l11l_l1_ (u"ࠧࠨ䉁"),headers,l1l11l_l1_ (u"ࠨࠩ䉂"),l1l11l_l1_ (u"ࠩࠪ䉃"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ䉄"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䉅"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡳࡥࡥ࡫ࡤ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠫ࠱ࡀ࠴ࡪࡩࡷࡀࠪ䉆"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1ll111_l1_: l1l11l1l_l1_ = l1ll111_l1_[0]
		else: l1l11l1l_l1_ = l1ll1ll1_l1_
		l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䉇"),l1l11l1l_l1_,re.DOTALL)
		for title,block in l1l1l1_l1_:
			title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩ䉈"))
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䉉"),block,re.DOTALL)
			for l1111l_l1_,name,l1l1l111_l1_ in items:
				l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡟ࡨ࠰࠭䉊"),l1l1l111_l1_,re.DOTALL)
				if l1l1l111_l1_: l1l1l111_l1_ = l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䉋")+l1l1l111_l1_[0]
				else:
					l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪࠫࠨ䉌"),title,re.DOTALL)
					if l1l1l111_l1_: l1l1l111_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䉍")+l1l1l111_l1_[0]
					else: l1l1l111_l1_ = l1l11l_l1_ (u"࠭ࠧ䉎")
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䉏")+name+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䉐")+l1l1l111_l1_
				l1ll1l1l_l1_.append(l1111l_l1_)
		if not l1l1l1_l1_:
			#url2 = hostname +l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡔࡪࡤ࡬࡮ࡪ࠴ࡶ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵ࡮ࡰࠨ䉑")
			url2 = hostname +l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡅࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵ࠭䉒")
			headers2 = {l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䉓"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䉔")}
			data2 = {l1l11l_l1_ (u"࠭ࡩࡥࠩ䉕"):id}
			response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䉖"),url2,data2,headers2,l1l11l_l1_ (u"ࠨࠩ䉗"),l1l11l_l1_ (u"ࠩࠪ䉘"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ䉙"))
			l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䉚"))
			items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䉛"),l1ll1ll1_l1_,re.DOTALL)
			for l1111l_l1_,name,l1l1l111_l1_ in items:
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䉜")+name+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䉝")+l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭䉞")+l1l1l111_l1_
				l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ䉟"),l1ll1l1l_l1_)
	elif l1l11l_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡓࡵࡷࠨ䉠") in html:
		headers2 = { l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䉡"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䉢") }
		url2 = l11l1ll1_l1_.replace(parts[3],l1l11l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䉣"))
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䉤"),url2,l1l11l_l1_ (u"ࠨࠩ䉥"),headers2,l1l11l_l1_ (u"ࠩࠪ䉦"),l1l11l_l1_ (u"ࠪࠫ䉧"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ䉨"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䉩"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䉪"),l1ll1ll1_l1_,re.DOTALL)
		for block in l1ll111_l1_:
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䉫"),block,re.DOTALL)
			for l1111l_l1_,name,l1l1l111_l1_ in items:
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䉬")+name+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䉭")+l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䉮")+l1l1l111_l1_
				l1ll1l1l_l1_.append(l1111l_l1_)
	elif l1l11l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ䉯") in html:
		headers2 = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䉰"):l1l11l_l1_ (u"࠭ࠧ䉱") , l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䉲"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䉳") }
		url2 = hostname + l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬ䉴")+id
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䉵"),url2,l1l11l_l1_ (u"ࠫࠬ䉶"),headers2,l1l11l_l1_ (u"ࠬ࠭䉷"),l1l11l_l1_ (u"࠭ࠧ䉸"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫ䉹"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䉺"))
		if l1l11l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱ࡧࡺ࡮ࡴࠩ䉻") in l1ll1ll1_l1_:
			l11l1ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䉼"),l1ll1ll1_l1_,re.DOTALL)
			for url3 in l11l1ll1l_l1_:
				if l1l11l_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䉽") not in url3 and l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䉾") in url3:
					url3 = url3+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䉿")
					l1ll1l1l_l1_.append(url3)
				elif l1l11l_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ䊀") in url3:
					l1l1l111_l1_ = l1l11l_l1_ (u"ࠨࠩ䊁")
					response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䊂"),url3,l1l11l_l1_ (u"ࠪࠫ䊃"),headers,l1l11l_l1_ (u"ࠫࠬ䊄"),l1l11l_l1_ (u"ࠬ࠭䊅"),l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠶ࡵࡪࠪ䊆"))
					l11ll11l1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䊇"))
					l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࠩ࠮࠯࠰࠱࠲࠭䊈"),l11ll11l1_l1_,re.DOTALL)
					for l11llllll_l1_ in l1l1l1_l1_:
						l11ll1l11_l1_ = l1l11l_l1_ (u"ࠩࠪ䊉")
						l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬ䊊"),l11llllll_l1_,re.DOTALL)
						for l11lll11l_l1_ in l11l1l1l1_l1_:
							item = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䊋"),l11lll11l_l1_,re.DOTALL)
							if item:
								l1l1l111_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䊌")+item[0]
								break
						for l11lll11l_l1_ in reversed(l11l1l1l1_l1_):
							item = re.findall(l1l11l_l1_ (u"࠭࡜ࡸ࡞ࡺ࠯ࠬ䊍"),l11lll11l_l1_,re.DOTALL)
							if item:
								l11ll1l11_l1_ = item[0]
								break
						l11l1l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䊎"),l11llllll_l1_,re.DOTALL)
						for l11ll1ll1_l1_ in l11l1l11l_l1_:
							l11ll1ll1_l1_ = l11ll1ll1_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䊏")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䊐")+l1l1l111_l1_
							l1ll1l1l_l1_.append(l11ll1ll1_l1_)
		elif l1l11l_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠨ䊑") in l1ll1ll1_l1_:
			l1ll1ll1_l1_ = l1ll1ll1_l1_.replace(l1l11l_l1_ (u"ࠫࡁ࡮࠶ࠡࠩ䊒"),l1l11l_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂࠦ࠽࠾ࡕࡗࡅࡗ࡚࠽࠾ࠩ䊓"))+l1l11l_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠧ䊔")
			l1ll1ll1_l1_ = l1ll1ll1_l1_.replace(l1l11l_l1_ (u"ࠧ࠽ࡪ࠶ࠤࠬ䊕"),l1l11l_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬ䊖"))+l1l11l_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪ䊗")
			l11l1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠮࠮ࠫࡁࠬࡁࡂࡋࡎࡅ࠿ࡀࠫ䊘"),l1ll1ll1_l1_,re.DOTALL)
			if l11l1l1ll_l1_:
				for l11llllll_l1_ in l11l1l1ll_l1_:
					if l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ䊙") not in l11llllll_l1_: continue
					l11lll1l1_l1_ = l1l11l_l1_ (u"ࠬ࠭䊚")
					l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䊛"),l11llllll_l1_,re.DOTALL)
					for l11lll11l_l1_ in l11l1l1l1_l1_:
						item = re.findall(l1l11l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ䊜"),l11lll11l_l1_,re.DOTALL)
						if item:
							l11lll1l1_l1_ = l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭䊝")+item[0]
							break
					l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ䊞"),l11llllll_l1_,re.DOTALL)
					if l11l1l1l1_l1_:
						for l11ll1l11_l1_,l11ll1l1l_l1_ in l11l1l1l1_l1_:
							l11ll1l1l_l1_ = l11ll1l1l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䊟")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䊠")+l11lll1l1_l1_
							l1ll1l1l_l1_.append(l11ll1l1l_l1_)
					else:
						l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䊡"),l11llllll_l1_,re.DOTALL)
						for l11ll1l1l_l1_,l11ll1l11_l1_ in l11l1l1l1_l1_:
							l11ll1l1l_l1_ = l11ll1l1l_l1_.strip(l1l11l_l1_ (u"࠭ࠠࠨ䊢"))+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䊣")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䊤")+l11lll1l1_l1_
							l1ll1l1l_l1_.append(l11ll1l1l_l1_)
			else:
				l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭ࡢࡷࠬࠫ࠿ࠫ䊥"),l1ll1ll1_l1_,re.DOTALL)
				for l11ll1l1l_l1_,l11ll1l11_l1_ in l11l1l1l1_l1_:
					l11ll1l1l_l1_ = l11ll1l1l_l1_.strip(l1l11l_l1_ (u"ࠪࠤࠬ䊦"))+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䊧")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䊨")
					l1ll1l1l_l1_.append(l11ll1l1l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䊩"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䊪"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ䊫"),l1l11l_l1_ (u"ࠩ࠮ࠫ䊬"))
	if showdialogs:
		l11ll11ll_l1_ = [l1l11l_l1_ (u"ࠪหๆ๊วๆࠩ䊭"),l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠬ䊮"),l1l11l_l1_ (u"๋ࠬๅฬๆํ๊ࠬ䊯"),l1l11l_l1_ (u"࠭วๅๅ็ࠫ䊰")]
		l1llll11l_l1_ = [l1l11l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭䊱"),l1l11l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䊲"),l1l11l_l1_ (u"ࠩࡤࡧࡹࡵࡲࠨ䊳"),l1l11l_l1_ (u"ࠪࠫ䊴")]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํࠦ࠭ࠡษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮࠧ䊵"), l11ll11ll_l1_)
		if selection == -1 : return
		type = l1llll11l_l1_[selection]
	else: type = l1l11l_l1_ (u"ࠬ࠭䊶")
	l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭ࠪ࠳࡭ࡵ࡭ࡦࠩ࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡳࡧ࡭ࡦ࠿ࠥࡸࡾࡶࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡰࡪࡩࡴ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡶࡸࡷ࠮ࡳࡩࡱࡺࡨ࡮ࡧ࡬ࡰࡩࡶ࠭࠱ࡹࡴࡳࠪ࡯ࡩࡳ࠮ࡨࡵ࡯࡯࠭࠮࠯ࠊࠊ࡫ࡩࠤࡸ࡮࡯ࡸࡦ࡬ࡥࡱࡵࡧࡴࠢࡤࡲࡩࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠭ࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࠊࡨࡲࡶࠥࡩࡡࡵࡧࡪࡳࡷࡿࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎ࡯ࡦࠡࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡟ࠬ฿ัฺุ้้ࠣอัฺหࠪࡡ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡧࡦࡺࡥࡨࡱࡵࡽ࠮ࠐࠉࠊࠋࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไโๆอีࠥอไๆ่สือࡀࠧ࠭ࠢࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙࠯ࠊࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷ࠠ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡࠩࠪࠎࠎࠩࡵࡳ࡮ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ࠭ࡶࡩࡦࡸࡣࡩ࠭ࠪࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠧࠬࡥࡤࡸࡪ࡭࡯ࡳࡻࠍࠍࠧࠨࠢ䊷")
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ䊸")+search+l1l11l_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࠨ䊹")+type
	l111l1_l1_(url)
	return
# ===========================================
#     l111lllll_l1_ l111l1111_l1_ l1111ll1l_l1_
# ===========================================
def l111llll1_l1_(url):
	url = url.split(l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭䊺"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䊻"),url,l1l11l_l1_ (u"ࠫࠬ䊼"),headers,l1l11l_l1_ (u"ࠬ࠭䊽"),l1l11l_l1_ (u"࠭ࠧ䊾"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ䊿"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠦ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ䋀"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + category + options block
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡳࡻ࠮ࠫࡁࡵࡳࡺࡴࡤࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡩ࡯ࡲࡸࡸࠥࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䋁"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111l11ll_l1_(block):
	# id + title
	items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡥࡤࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡫ࡩࡨࡱ࡭ࡢࡴ࡮࠱ࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䋂"),block,re.DOTALL)
	return items
def l1l1ll111lll_l1_(url):
	url = url.replace(l1l11l_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ䋃"),l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ䋄"))
	if l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ䋅") not in url: url = url+l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ䋆")
	l111l1l1l_l1_ = url.split(l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ䋇"))[0]
	l111l1l11_l1_ = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭䋈"))
	url = url.replace(l111l1l1l_l1_,l111l1l11_l1_)
	#url = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ䋉"),l1l11l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡖ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡍࡵ࡭ࡦ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡘ࡮࡯ࡸࡵ࠱ࡴ࡭ࡶ࠿ࠨ䋊"))
	url = url.replace(l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ䋋"),l1l11l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡹ࡮ࡥ࡮ࡧ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡌࡴࡳࡥ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡗ࡭ࡵࡷࡴ࠰ࡳ࡬ࡵࡅࠧ䋌"))
	return url
l1l1ll111l1l_l1_ = [l1l11l_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ䋍"),l1l11l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䋎"),l1l11l_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ䋏"),l1l11l_l1_ (u"ࠪࡧࡦࡺࠧ䋐")]
l1l1ll11l111_l1_ = [l1l11l_l1_ (u"ࠫࡨࡧࡴࠨ䋑"),l1l11l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ䋒"),l1l11l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ䋓")]
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䋔"),l1l11l_l1_ (u"ࠨࠩ䋕"))
	url = url.split(l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭䋖"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䋗"),1)
	if filter==l1l11l_l1_ (u"ࠫࠬ䋘"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠬ࠭䋙"),l1l11l_l1_ (u"࠭ࠧ䋚")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䋛"))
	if type==l1l11l_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ䋜"):
		if l1l1ll11l111_l1_[0]+l1l11l_l1_ (u"ࠩࡀࠫ䋝") not in l1lllll1_l1_: category = l1l1ll11l111_l1_[0]
		for i in range(len(l1l1ll11l111_l1_[0:-1])):
			if l1l1ll11l111_l1_[i]+l1l11l_l1_ (u"ࠪࡁࠬ䋞") in l1lllll1_l1_: category = l1l1ll11l111_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠫࠫ࠭䋟")+category+l1l11l_l1_ (u"ࠬࡃ࠰ࠨ䋠")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"࠭ࠦࠨ䋡")+category+l1l11l_l1_ (u"ࠧ࠾࠲ࠪ䋢")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠪ䋣"))+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䋤")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠬ䋥"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ䋦"))
		url2 = url+l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ䋧")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ䋨"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䋩"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠨࠩ䋪"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䋫"))
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠪࠫ䋬"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ䋭")+l1llll1l_l1_
		url3 = l1l1ll111lll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䋮"),menu_name+l1l11l_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ䋯"),url3,111)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䋰"),menu_name+l1l11l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ䋱")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ䋲"),url3,111)
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䋳"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䋴"),l1l11l_l1_ (u"ࠬ࠭䋵"),9999)
	l1l1ll1_l1_ = l111llll1_l1_(url)
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		name = name.replace(l1l11l_l1_ (u"࠭࠭࠮ࠩ䋶"),l1l11l_l1_ (u"ࠧࠨ䋷"))
		items = l111l11ll_l1_(block)
		if l1l11l_l1_ (u"ࠨ࠿ࠪ䋸") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ䋹"):
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l1l1ll11l111_l1_[-1]:
					url3 = l1l1ll111lll_l1_(url2)
					l111l1_l1_(url3)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ䋺")+l1111l1_l1_)
				return
			else:
				if l1l111l_l1_==l1l1ll11l111_l1_[-1]:
					url3 = l1l1ll111lll_l1_(url2)
					addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋻"),menu_name+l1l11l_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭䋼"),url3,111)
				else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋽"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ䋾"),url2,115,l1l11l_l1_ (u"ࠨࠩ䋿"),l1l11l_l1_ (u"ࠩࠪ䌀"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ䌁"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠫࠫ࠭䌂")+l1l111l_l1_+l1l11l_l1_ (u"ࠬࡃ࠰ࠨ䌃")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"࠭ࠦࠨ䌄")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾࠲ࠪ䌅")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ䌆")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䌇"),menu_name+l1l11l_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ䌈")+name,url2,114,l1l11l_l1_ (u"ࠫࠬ䌉"),l1l11l_l1_ (u"ࠬ࠭䌊"),l1111l1_l1_)		# +l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䌋"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if value==l1l11l_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧ䌌"): option = l1l11l_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ䌍")
			elif value==l1l11l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ䌎"): option = l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ䌏")
			if option in l1llll1_l1_: continue
			#if l1l11l_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ䌐") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䌑"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"࠭ࠦࠨ䌒")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾ࠩ䌓")+option
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠨࠨࠪ䌔")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࠫ䌕")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䌖")+l11l111_l1_
			title = option+l1l11l_l1_ (u"ࠫࠥࡀࠧ䌗")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠬ࠶ࠧ䌘")]
			title = option+l1l11l_l1_ (u"࠭ࠠ࠻ࠩ䌙")+name
			if type==l1l11l_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ䌚"): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䌛"),menu_name+title,url,114,l1l11l_l1_ (u"ࠩࠪ䌜"),l1l11l_l1_ (u"ࠪࠫ䌝"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䌞"))
			elif type==l1l11l_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭䌟") and l1l1ll11l111_l1_[-2]+l1l11l_l1_ (u"࠭࠽ࠨ䌠") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䌡"))
				url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ䌢")+l1lll1l1_l1_
				url3 = l1l1ll111lll_l1_(url2)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䌣"),menu_name+title,url3,111)
			else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䌤"),menu_name+title,url,115,l1l11l_l1_ (u"ࠫࠬ䌥"),l1l11l_l1_ (u"ࠬ࠭䌦"),l1l1111_l1_)
	return
def l1lll1ll_l1_(filters,mode):
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䌧")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䌨")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠨࡣ࡯ࡰࠬ䌩")					all l111l1l_l1_ & l111lll1l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠩࡀࠪࠬ䌪"),l1l11l_l1_ (u"ࠪࡁ࠵ࠬࠧ䌫"))
	filters = filters.strip(l1l11l_l1_ (u"ࠫࠫ࠭䌬"))
	l1llllll_l1_ = {}
	if l1l11l_l1_ (u"ࠬࡃࠧ䌭") in filters:
		items = filters.split(l1l11l_l1_ (u"࠭ࠦࠨ䌮"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠧ࠾ࠩ䌯"))
			l1llllll_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠨࠩ䌰")
	for key in l1l1ll111l1l_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠩ࠳ࠫ䌱")
		if l1l11l_l1_ (u"ࠪࠩࠬ䌲") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䌳") and value!=l1l11l_l1_ (u"ࠬ࠶ࠧ䌴"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠠࠬࠢࠪ䌵")+value
		elif mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䌶") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪ䌷"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠩࠫ䌸")+key+l1l11l_l1_ (u"ࠪࡁࠬ䌹")+value
		elif mode==l1l11l_l1_ (u"ࠫࡦࡲ࡬ࠨ䌺"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠧ䌻")+key+l1l11l_l1_ (u"࠭࠽ࠨ䌼")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠡ࠭ࠣࠫ䌽"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠪ䌾"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠩࡀ࠴ࠬ䌿"),l1l11l_l1_ (u"ࠪࡁࠬ䍀"))
	return l11llll_l1_
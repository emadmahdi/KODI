# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ䡈")
menu_name = l1l11l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ䡉")
l11lll_l1_ = WEBSITES[script_name][0]
#headers = l1l11l_l1_ (u"ࠬ࠭䡊")
#headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䡋"):l1l11l_l1_ (u"ࠧࠨ䡌")}
l1l11lll11ll_l1_ = 0
def MAIN(mode,url,text,type,page,name,image):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1l11lll111l_l1_(url,name,image)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l111l1_l1_(url,page,text)
	elif mode==145: results = l1l1l11lllll_l1_(url,page)
	elif mode==147: results = l1l1l111l111_l1_()
	elif mode==148: results = l1l1l111l1l1_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䡍"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䡎")+menu_name+l1l11l_l1_ (u"ࠪๆฬฬๅสࠩ䡏"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌࡂ࡬࠸ࡋࡸ࠾ࡆࡉ࠺࡝ࡲ࡚ࡨࡆ࠱ࡔ࡙࠱࠼ࡍ࠳ࡃࡱࡴࡍࡾࡠࡁ࠵ࡷࡖࡅࠬ䡐"),144)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䡑"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䡒")+menu_name+l1l11l_l1_ (u"ࠧีะุࠫ䡓"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࡕࡅࡑࡳ࡫࡬ࡩࡤ࡫ࡤࡰࠬ䡔"),144)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䡕"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䡖")+menu_name+l1l11l_l1_ (u"๊ࠫ๎โฺࠩ䡗"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡖࡅࡴ࠹࠾ࡧࡇࡏࡵࡴ࠽ࡧࡨࡨࡸࡘࡗࡵ࠶࡛ࡴࡷࡩࡺࠫ䡘"),144)
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡙"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䡚")+menu_name+l1l11l_l1_ (u"ࠨฯึหอ࠭䡛"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡄ࡙࡮ࡥࡔࡱࡦ࡭ࡦࡲࡃࡕࡘࠪ䡜"),144)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䡝"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䡞")+menu_name+l1l11l_l1_ (u"ࠬอไฺษหࠫ䡟"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ䡠"),144)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䡡"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䡢")+menu_name+l1l11l_l1_ (u"ࠩสๅ้อๅࠨ䡣"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭䡤"),144)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䡥"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䡦")+menu_name+l1l11l_l1_ (u"࠭ๅฯฬสีฬะࠧ䡧"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭䡨"),144)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䡩"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䡪")+menu_name+l1l11l_l1_ (u"ࠪๆฺ๐ัสࠩ䡫"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ䡬"),144,l1l11l_l1_ (u"ࠬ࠭䡭"),l1l11l_l1_ (u"࠭ࠧ䡮"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䡯"))
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䡰"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䡱")+menu_name+l1l11l_l1_ (u"ࠪฮฺ็อࠨ䡲"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ䡳"),144)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䡴"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䡵")+menu_name+l1l11l_l1_ (u"ࠧาศํื๏ฯࠧ䡶"),l11lll_l1_+l1l11l_l1_ (u"ࠨࠩ䡷"),144)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䡸"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䡹")+menu_name+l1l11l_l1_ (u"ࠫึอฦอࠩ䡺"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡅࡢࡱ࠿ࠪ䡻"),144)
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䡼"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䡽"),l1l11l_l1_ (u"ࠨࠩ䡾"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䡿"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䢀"),l1l11l_l1_ (u"ࠫࠬ䢁"),149,l1l11l_l1_ (u"ࠬ࠭䢂"),l1l11l_l1_ (u"࠭ࠧ䢃"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䢄"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䢅"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䢆")+menu_name+l1l11l_l1_ (u"ࠪห้ืฦ๋ีํอࠬ䢇"),l11lll_l1_+l1l11l_l1_ (u"ࠫࠬ䢈"),144)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䢉"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䢊")+menu_name+l1l11l_l1_ (u"ࠧศๆิหหาษࠨ䢋"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ䢌"),144)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢍"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䢎")+menu_name+l1l11l_l1_ (u"ࠫฬ๊สึใะࠫ䢏"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ䢐"),144)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䢑"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䢒")+menu_name+l1l11l_l1_ (u"ࠨษ็ๆฺ๐ัสࠩ䢓"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ䢔"),144,l1l11l_l1_ (u"ࠪࠫ䢕"),l1l11l_l1_ (u"ࠫࠬ䢖"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䢗"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䢘"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䢙")+menu_name+l1l11l_l1_ (u"ࠨ็ัฮฬืวหࠢํ์ฯ๐่ษࠩ䢚"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ䢛"),144)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䢜"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䢝")+l1l11l_l1_ (u"ࠬࡥ࡙ࡕࡅࡢࠫ䢞")+l1l11l_l1_ (u"࠭ๅฯฬสีฬะࠠศๆหี๋อๅอࠩ䢟"),l1l11l_l1_ (u"ࠧࠨ䢠"),290)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䢡"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䢢"),l1l11l_l1_ (u"ࠪࠫ䢣"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䢤"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䢥")+menu_name+l1l11l_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ䢦"),l1l11l_l1_ (u"ࠧࠨ䢧"),147)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䢨"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䢩")+menu_name+l1l11l_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ䢪"),l1l11l_l1_ (u"ࠫࠬ䢫"),148)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䢬"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䢭")+menu_name+l1l11l_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ䢮"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ䢯"),144)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢰"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䢱")+menu_name+l1l11l_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ䢲"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ䢳"),144)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䢴"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䢵")+menu_name+l1l11l_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭䢶"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ䢷"),144)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䢸"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䢹")+menu_name+l1l11l_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ䢺"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ䢻"),144)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䢼"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䢽")+menu_name+l1l11l_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ䢾"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ䢿"),144)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䣀"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䣁")+menu_name+l1l11l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ䣂"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭䣃"),144)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䣄"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䣅")+menu_name+l1l11l_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ䣆"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ䣇"),144)
	return
def l1l11lll111l_l1_(url,name,image):
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䣈"),menu_name+l1l11l_l1_ (u"࠭ࡃࡉࡐࡏ࠾ࠥࠦࠧ䣉")+name,url,144,image)
	return
def l1l1l111l111_l1_():
	l111l1_l1_(l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ศฬࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ䣊"))
	return
def l1l1l111l1l1_l1_():
	l111l1_l1_(l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡷࡺࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ䣋"))
	return
def PLAY(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䣌"),l1l11l_l1_ (u"ࠪࠫ䣍"),l1l11l_l1_ (u"ࠫࠬ䣎"),url)
	#url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧ䣏")
	#items = re.findall(l1l11l_l1_ (u"࠭ࡶ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䣐"),url,re.DOTALL)
	#id = items[0]
	#l1111l_l1_ = l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦ࠱ࡳࡰࡦࡿ࠯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫ䣑")+id
	#PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䣒"))
	#return
	l1l11l_l1_ (u"ࠤࠥࠦࠏࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࡹࡷࡲࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬࠐࠉࡦࡴࡵࡳࡷࡹࠬࡵ࡫ࡷࡰࡪࡹࠬ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠫࡹࡷࡲࠩࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠭ࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠱ࡺࡹࡱࡧࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤ䣓")
	url = url.split(l1l11l_l1_ (u"ࠪࠪࠬ䣔"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l1l1l1111111_l1_(cc,url,index):
	level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = index.split(l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䣕"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䣖"),l1l11l_l1_ (u"࠭ࠧ䣗"),index,l1l11l_l1_ (u"ࠧࡇࡋࡕࡗ࡙࠭䣘")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䣙")+url)
	l1l11ll1lll1_l1_,l1l11lll1111_l1_ = [],[]
	# l11lll1ll1l_l1_ l1l1l11l1l11_l1_    should be the first item in the l1l11ll1lll1_l1_ list
	if l1l11l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ䣚") in url: l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣࠢ䣛"))
	# l11lll1ll1l_l1_ search l1l1l111lll1_l1_      should be the first item in the l1l11ll1lll1_l1_ list
	if l1l11l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ䣜") in url: l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟ࠥ䣝"))
	# main page
	if level==l1l11l_l1_ (u"࠭࠱ࠨ䣞"): l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䣟"))
	# search results
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ䣠"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟ࠥ䣡"))
	# l1l1l111ll11_l1_ l1l1l1111lll_l1_ & main page l1l1l1111lll_l1_ l1l1l111lll1_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡧࡨࡡࠧࡦࡰࡷࡶ࡮࡫ࡳࠨ࡟ࠥ䣢"))
	# l1l1l111111l_l1_ l1lllll1ll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡨࡩ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞࡝࠶ࡡࡠ࠭ࡧࡶ࡫ࡧࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ䣣"))
	l1l1l111llll_l1_,dd,l1l11ll1l111_l1_ = l1l11ll1ll11_l1_(cc,l1l11l_l1_ (u"ࠬ࠭䣤"),l1l11ll1lll1_l1_)
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ䣥"),str(dd))
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䣦"),l1l11l_l1_ (u"ࠨࠩ䣧"),l1l11l_l1_ (u"ࠩࠪ䣨"),str(len(dd)))
	if level==l1l11l_l1_ (u"ࠪ࠵ࠬ䣩") and l1l1l111llll_l1_:
		if len(dd)>1 and l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ䣪") not in url:
			for zz in range(len(dd)):
				l1l11llll11l_l1_ = str(zz)
				l1l11ll1lll1_l1_ = []
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡪࡤ࡜ࠤ䣫")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡱࡵࡡࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ䣬"))
				# l1l1l111ll11_l1_ l1l1l1111lll_l1_
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡥࡦ࡞ࠦ䣭")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠣ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࠬࡣࠢ䣮"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡧࡨࡠࠨ䣯")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠥࡡࠧ䣰"))
				succeeded,item,l1l111ll_l1_ = l1l11ll1ll11_l1_(dd,l1l11l_l1_ (u"ࠫࠬ䣱"),l1l11ll1lll1_l1_)
				if succeeded: l1l11lll1111_l1_.append([item,url,l1l11l_l1_ (u"ࠬ࠸࠺࠻ࠩ䣲")+l1l11llll11l_l1_+l1l11l_l1_ (u"࠭࠺࠻࠲࠽࠾࠵࠭䣳")])
				#success = l1l1l11ll111_l1_(item,url,l1l11l_l1_ (u"ࠧ࠳࠼࠽ࠫ䣴")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠨ࠼࠽࠴࠿ࡀ࠰ࠨ䣵"))
				#if success: l1l11lllll11_l1_ += 1
				#succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,token = l1l1l1l111ll_l1_(item)
				#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䣶"),menu_name+title,l1111l_l1_,144,l1l11l_l1_ (u"ࠪࠫ䣷"),l1l11l_l1_ (u"ࠫ࠷ࡀ࠺ࠨ䣸")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ䣹"))
				#l1l11lllll11_l1_ += 1
			# main page l1l1l1111lll_l1_ l1l1l111lll1_l1_
			l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࠧ䣺"))
			succeeded,item,l1l111ll_l1_ = l1l11ll1ll11_l1_(cc,l1l11l_l1_ (u"ࠧࠨ䣻"),l1l11ll1lll1_l1_)
			#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ䣼"),str(cc))
			if succeeded and l1l11lll1111_l1_ and l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ䣽") in list(item.keys()):
				l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ䣾")
				l1l11lll1111_l1_.append([item,l1111l_l1_,l1l11l_l1_ (u"ࠫ࠶ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ䣿")])
	return dd,l1l1l111llll_l1_,l1l11lll1111_l1_,l1l11ll1l111_l1_
def l1l11ll1l11l_l1_(cc,dd,url,index):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䤀"),l1l11l_l1_ (u"࠭ࠧ䤁"),index,l1l11l_l1_ (u"ࠧࡔࡇࡆࡓࡓࡊࠧ䤂")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䤃")+url)
	level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = index.split(l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䤄"))
	l1l11ll1lll1_l1_,l1l1l11111l1_l1_ = [],[]
	# search results
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡨࡩࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ䤅"))
	# main page
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡩࡪ࡛ࠣ䤆")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ䤇"))
	# l1l1l1lllll_l1_ l1l1l1111lll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡤࡥ࡝࠴ࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ䤈"))
	# l11lll1ll1l_l1_ search & l1l1l11l1l11_l1_ & l1l1l111lll1_l1_
	if l1l11l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪ࠭䤉") in url: l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ䤊"))
	elif l1l11l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ䤋") in url: l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䤌"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡩࡪ࡛ࠣ䤍")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ䤎"))
	# l1l1l1lllll_l1_ l1ll1111l1_l1_ & l1l1l1111lll_l1_ filters
	if l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䤏") in url or (l1l11l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ䤐") in url and l1l11l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ䤑") not in url):
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡧࡨࡠࠨ䤒")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠥࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ䤓"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡩࡪ࡛ࠣ䤔")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ䤕"))
	# l1l1l111ll11_l1_ search
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡤࡥ࡝ࠥ䤖")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠢ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡤࡦࡱ࡫ࡔࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䤗"))
	# main page
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡦࡧ࡟ࠧ䤘")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ䤙"))
	# l11lll1ll1l_l1_ l1l1l11l1l11_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡨࡩࡡࠢ䤚")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠦࡢࠨ䤛"))
	l1l1l111l1ll_l1_,ee,l1l11llllll1_l1_ = l1l11ll1ll11_l1_(dd,l1l11l_l1_ (u"ࠬ࠭䤜"),l1l11ll1lll1_l1_)
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ䤝"),str(ee))
	#DIALOG_OK()
	if level==l1l11l_l1_ (u"ࠧ࠳ࠩ䤞") and l1l1l111l1ll_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1l11ll1lll1_l1_ = []
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡧࡨ࡟ࠧ䤟")+index2+l1l11l_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ䤠"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡩࡪࡡࠢ䤡")+index2+l1l11l_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ䤢"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ䤣")+index2+l1l11l_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ䤤"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧ࡞ࠦ䤥")+index2+l1l11l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ䤦"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡨࡩࡠࠨ䤧")+index2+l1l11l_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ䤨"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡪ࡫࡛ࠣ䤩")+index2+l1l11l_l1_ (u"ࠧࡣࠢ䤪"))
				succeeded,item,l1l111ll_l1_ = l1l11ll1ll11_l1_(ee,l1l11l_l1_ (u"࠭ࠧ䤫"),l1l11ll1lll1_l1_)
				if succeeded: l1l1l11111l1_l1_.append([item,url,l1l11l_l1_ (u"ࠧ࠴࠼࠽ࠫ䤬")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䤭")+index2+l1l11l_l1_ (u"ࠩ࠽࠾࠵࠭䤮")])
				#success = l1l1l11ll111_l1_(item,url,l1l11l_l1_ (u"ࠪ࠷࠿ࡀࠧ䤯")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䤰")+index2+l1l11l_l1_ (u"ࠬࡀ࠺࠱ࠩ䤱"))
				#if success: l1l1l111ll1l_l1_ += 1
				#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ䤲"),str(l1l111ll_l1_)+l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ䤳")+str(item))
				#l1l1l111ll1l_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,token = l1l1l1l111ll_l1_(item)
				#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䤴"),menu_name+title,l1111l_l1_,144,img,l1l11l_l1_ (u"ࠩ࠶࠾࠿࠭䤵")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠪ࠾࠿࠭䤶")+index2+l1l11l_l1_ (u"ࠫ࠿ࡀ࠰ࠨ䤷"))
			# search l1l1l111lll1_l1_
			l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠴ࡡࠧ䤸"))
			# search l1l1l111lll1_l1_
			l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡤࡥ࡝࠴ࡡࠧ䤹"))
			succeeded,item,l1l111ll_l1_ = l1l11ll1ll11_l1_(dd,l1l11l_l1_ (u"ࠧࠨ䤺"),l1l11ll1lll1_l1_)
			if succeeded and l1l1l11111l1_l1_ and l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ䤻") in list(item.keys()):
				l1l1l11111l1_l1_.append([item,url,l1l11l_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭䤼")])
			#success = l1l1l11ll111_l1_(item,url,l1l11l_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ䤽"))
			#if success: l1l1l111ll1l_l1_ += 1
			#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ䤾"),str(item))
			#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䤿"),l1111l_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ䥀")+token)
	return ee,l1l1l111l1ll_l1_,l1l1l11111l1_l1_,l1l11llllll1_l1_
def l1l11lll11l1_l1_(cc,ee,url,index):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䥁"),l1l11l_l1_ (u"ࠨࠩ䥂"),index,l1l11l_l1_ (u"ࠩࡗࡌࡎࡘࡄࠨ䥃")+l1l11l_l1_ (u"ࠪࡠࡳ࠭䥄")+url)
	level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = index.split(l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䥅"))
	l1l11ll1lll1_l1_,l1l11lll1l1l_l1_ = [],[]
	# search results
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ䥆")+index2+l1l11l_l1_ (u"ࠨ࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡹࡩࡷࡺࡩࡤࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ䥇"))
	# l11lll1ll1l_l1_ l1l1l11l1l11_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧ࡞ࠦ䥈")+index2+l1l11l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䥉"))
	# l1l1l11l1lll_l1_ l1lllll1ll_l1_ l1l1l1111lll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡨࡩࡠࠨ䥊")+index2+l1l11l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡵࡩࡪࡲࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ䥋"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡪ࡫࡛ࠣ䥌")+index2+l1l11l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ䥍"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡥࡦ࡝ࠥ䥎")+index2+l1l11l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䥏"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡧࡨ࡟ࠧ䥐")+index2+l1l11l_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ䥑"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡩࡪࡡࠢ䥒")+index2+l1l11l_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ䥓"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ䥔")+index2+l1l11l_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ䥕"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ䥖"))
	# l1l1l111ll11_l1_ l1l1l1l11l11_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ䥗"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䥘"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡩࡪࡡࠢ䥙")+index2+l1l11l_l1_ (u"ࠦࡢࡡࠧࡳࡧࡨࡰࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ䥚"))
	# main page
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ䥛")+index2+l1l11l_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ䥜"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧࠥ䥝"))
	l1l1l11l111l_l1_,ff,l1l1l1l1111l_l1_ = l1l11ll1ll11_l1_(ee,l1l11l_l1_ (u"ࠨࠩ䥞"),l1l11ll1lll1_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ䥟"),str(ff))
	if level==l1l11l_l1_ (u"ࠪ࠷ࠬ䥠") and l1l1l11l111l_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1l1l1111ll1_l1_ = str(zz)
				#DIALOG_OK()
				l1l11ll1lll1_l1_ = []
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦ࡫࡬࡛ࠣ䥡")+l1l1l1111ll1_l1_+l1l11l_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ䥢"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡦࡧ࡝ࠥ䥣")+l1l1l1111ll1_l1_+l1l11l_l1_ (u"ࠢ࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ䥤"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠧ䥥")+l1l1l1111ll1_l1_+l1l11l_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ䥦"))
				l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࡡࠢ䥧")+l1l1l1111ll1_l1_+l1l11l_l1_ (u"ࠦࡢࠨ䥨"))
				succeeded,item,l1l111ll_l1_ = l1l11ll1ll11_l1_(ff,l1l11l_l1_ (u"ࠬ࠭䥩"),l1l11ll1lll1_l1_)
				#succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,token = l1l1l1l111ll_l1_(item)
				#addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䥪"),menu_name+l1111l_l1_,l1111l_l1_,143,img)
				if succeeded: l1l11lll1l1l_l1_.append([item,url,l1l11l_l1_ (u"ࠧ࠵࠼࠽ࠫ䥫")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䥬")+index2+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䥭")+l1l1l1111ll1_l1_])
				#success = l1l1l11ll111_l1_(item,url,l1l11l_l1_ (u"ࠪ࠸࠿ࡀࠧ䥮")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䥯")+index2+l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䥰")+l1l1l1111ll1_l1_)
				#if success: l1l11llll1l1_l1_ += 1
	return ff,l1l1l11l111l_l1_,l1l11lll1l1l_l1_,l1l1l1l1111l_l1_
def l1l11ll1ll11_l1_(l1l1ll1llll_l1_,l1l1lllll11_l1_,l1l11llll111_l1_):
	cc,l1l1lllll11_l1_ = l1l1ll1llll_l1_,l1l1lllll11_l1_
	dd,l1l1lllll11_l1_ = l1l1ll1llll_l1_,l1l1lllll11_l1_
	ee,l1l1lllll11_l1_ = l1l1ll1llll_l1_,l1l1lllll11_l1_
	ff,l1l1lllll11_l1_ = l1l1ll1llll_l1_,l1l1lllll11_l1_
	item,render = l1l1ll1llll_l1_,l1l1lllll11_l1_
	count = len(l1l11llll111_l1_)
	for ii in range(count):
		try:
			out = eval(l1l11llll111_l1_[ii])
			#if isinstance(out,dict): out = l1l11l_l1_ (u"࠭ࠧ䥱")
			return True,out,ii+1
		except: pass
	return False,l1l11l_l1_ (u"ࠧࠨ䥲"),0
def l111l1_l1_(url,index=l1l11l_l1_ (u"ࠨࠩ䥳"),data=l1l11l_l1_ (u"ࠩࠪ䥴")):
	l1l11lll1111_l1_,l1l1l11111l1_l1_,l1l11lll1l1l_l1_ = [],[],[]
	if l1l11l_l1_ (u"ࠪ࠾࠿࠭䥵") not in index: index = l1l11l_l1_ (u"ࠫ࠶ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ䥶")
	level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = index.split(l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䥷"))
	if level==l1l11l_l1_ (u"࠭࠴ࠨ䥸"): level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = l1l11l_l1_ (u"ࠧ࠲ࠩ䥹"),l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䥺"),l1l11l_l1_ (u"ࠩࠪ䥻"),index,url)
	data = data.replace(l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䥼"),l1l11l_l1_ (u"ࠫࠬ䥽"))
	html,cc,data2 = l1l1l11111ll_l1_(url,data)
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡪࠥ࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡳࡷࠦࠧ࠰ࡷࡶࡩࡷ࠵ࠧࠡ࡫ࡱࠤࡺࡸ࡬࠻ࠌࠌࠍࠨࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡵࡷ࡯ࡧࡵࡒࡦࡳࡥࠣ࠰࠭ࡃࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠤ࡫ࡩࠤࡳࡵࡴࠡࡱࡺࡲࡪࡸ࠺ࠡࠌࠌࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡨ࡮ࡡ࡯ࡰࡨࡰࡒ࡫ࡴࡢࡦࡤࡸࡦࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡱࡺࡲࡪࡸࡕࡳ࡮ࡶࠦ࠿ࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣࡲࡴࡺࠠࡰࡹࡱࡩࡷࡀࠠࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴ࠽ࠎࠎࠏࠉࡰࡹࡱࡩࡷࡔࡁࡎࡇࠣࡁࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠱࡟ࠬࠎࠎࠏࠉࡰࡹࡱࡩࡷࡔࡁࡎࡇࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ࠮ࡳࡼࡴࡥࡳࡐࡄࡑࡊ࠱ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠳ࡠࠎࠎࠏࠉࡪࡨࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰ࡲࡩ࡯࡭ࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡲࡻࡳ࡫ࡲࡏࡃࡐࡉ࠱ࡲࡩ࡯࡭࠯࠵࠹࠺ࠩࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡰ࡮ࡴ࡫ࠨ࠮ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠰ࠬ࠭ࠬ࠺࠻࠼࠽࠮ࠐࠉࠣࠤࠥ䥾")
	index = level+l1l11l_l1_ (u"࠭࠺࠻ࠩ䥿")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䦀")+index2+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䦁")+l1l1l1111ll1_l1_
	if level in [l1l11l_l1_ (u"ࠩ࠴ࠫ䦂"),l1l11l_l1_ (u"ࠪ࠶ࠬ䦃"),l1l11l_l1_ (u"ࠫ࠸࠭䦄")]:
		dd,l1l1l111llll_l1_,l1l11lll1111_l1_,l1l11ll1l111_l1_ = l1l1l1111111_l1_(cc,url,index)
		if not l1l1l111llll_l1_: return
		l1l11lllll11_l1_ = len(l1l11lll1111_l1_)
		if l1l11lllll11_l1_<2:
			if level==l1l11l_l1_ (u"ࠬ࠷ࠧ䦅"): level = l1l11l_l1_ (u"࠭࠲ࠨ䦆")
			l1l11lll1111_l1_ = []
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䦇"),l1l11l_l1_ (u"ࠨࠩ䦈"),index,l1l11l_l1_ (u"ࠩ࡯ࡩࡻ࡫࡬࠻ࠢ࠴ࡠࡳ࠭䦉")+l1l11l_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩ࠿ࠦࠧ䦊")+str(l1l11ll1l111_l1_)+l1l11l_l1_ (u"ࠫࡡࡴࠧ䦋")+l1l11l_l1_ (u"ࠬࡲࡥ࡯ࡩࡷ࡬࠿ࠦࠧ䦌")+str(len(dd))+l1l11l_l1_ (u"࠭࡜࡯ࠩ䦍")+l1l11l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡀࠠࠨ䦎")+str(l1l11lllll11_l1_)+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䦏")+url)
	index = level+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䦐")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠪ࠾࠿࠭䦑")+index2+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䦒")+l1l1l1111ll1_l1_
	if level in [l1l11l_l1_ (u"ࠬ࠸ࠧ䦓"),l1l11l_l1_ (u"࠭࠳ࠨ䦔")]:
		ee,l1l1l111l1ll_l1_,l1l1l11111l1_l1_,l1l11llllll1_l1_ = l1l11ll1l11l_l1_(cc,dd,url,index)
		if not l1l1l111l1ll_l1_: return
		l1l1l111ll1l_l1_ = len(l1l1l11111l1_l1_)
		if l1l1l111ll1l_l1_<2:
			if level==l1l11l_l1_ (u"ࠧ࠳ࠩ䦕"): level = l1l11l_l1_ (u"ࠨ࠵ࠪ䦖")
			l1l1l11111l1_l1_ = []
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䦗"),l1l11l_l1_ (u"ࠪࠫ䦘"),index,l1l11l_l1_ (u"ࠫࡱ࡫ࡶࡦ࡮࠽ࠤ࠷ࡢ࡮ࠨ䦙")+l1l11l_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫࠺ࠡࠩ䦚")+str(l1l11llllll1_l1_)+l1l11l_l1_ (u"࠭࡜࡯ࠩ䦛")+l1l11l_l1_ (u"ࠧ࡭ࡧࡱ࡫ࡹ࡮࠺ࠡࠩ䦜")+str(len(ee))+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䦝")+l1l11l_l1_ (u"ࠩࡦࡳࡺࡴࡴ࠻ࠢࠪ䦞")+str(l1l1l111ll1l_l1_)+l1l11l_l1_ (u"ࠪࡠࡳ࠭䦟")+url)
	index = level+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䦠")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䦡")+index2+l1l11l_l1_ (u"࠭࠺࠻ࠩ䦢")+l1l1l1111ll1_l1_
	if level in [l1l11l_l1_ (u"ࠧ࠴ࠩ䦣")]:
		ff,l1l1l11l111l_l1_,l1l11lll1l1l_l1_,l1l1l1l1111l_l1_ = l1l11lll11l1_l1_(cc,ee,url,index)
		if not l1l1l11l111l_l1_: return
		l1l11llll1l1_l1_ = len(l1l11lll1l1l_l1_)
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䦤"),l1l11l_l1_ (u"ࠩࠪ䦥"),index,l1l11l_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠷ࡡࡴࠧ䦦")+l1l11l_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ䦧")+str(l1l1l1l1111l_l1_)+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䦨")+l1l11l_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ䦩")+str(len(ff))+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䦪")+l1l11l_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ䦫")+str(l1l11llll1l1_l1_)+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䦬")+url)
	for item,url,index in l1l11lll1111_l1_+l1l1l11111l1_l1_+l1l11lll1l1l_l1_:
		success = l1l1l11ll111_l1_(item,url,index)
	return
def l1l1l11ll111_l1_(item,url=l1l11l_l1_ (u"ࠪࠫ䦭"),index=l1l11l_l1_ (u"ࠫࠬ䦮")):
	if l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䦯") in index: level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = index.split(l1l11l_l1_ (u"࠭࠺࠻ࠩ䦰"))
	else: level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = l1l11l_l1_ (u"ࠧ࠲ࠩ䦱"),l1l11l_l1_ (u"ࠨ࠲ࠪ䦲"),l1l11l_l1_ (u"ࠩ࠳ࠫ䦳"),l1l11l_l1_ (u"ࠪ࠴ࠬ䦴")
	succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,l1l1l11lll11_l1_ = l1l1l1l111ll_l1_(item)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ䦵"),url)
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䦶"),l1111l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ䦷"),l1111l_l1_+l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ䦸")+title)
	# needed for l1l1l111ll11_l1_ l1l1l1l11l11_l1_ next page
	# and needed for l1l1l111ll11_l1_ l1l1l1l11l11_l1_ sub-l1lllll1ll_l1_
	#if (l1l11l_l1_ (u"ࠨࡸ࡬ࡩࡼࡃ࠵࠱ࠩ䦹") in l1111l_l1_ or l1l11l_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽࠵࠻ࠪ䦺") in l1111l_l1_) and (l1l11l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹ࠿ࠨ䦻") in l1111l_l1_ or l1l11l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹ࠿ࠨ䦼") in l1111l_l1_): l1111l_l1_ = url
	cond1 = l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸࡅࠧ䦽") in l1111l_l1_ or l1l11l_l1_ (u"࠭࠯ࡴࡶࡵࡩࡦࡳࡳࡀࠩ䦾") in l1111l_l1_ or l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ䦿") in l1111l_l1_
	cond2 = l1l11l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ䧀") in l1111l_l1_ or l1l11l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࡂࠫ䧁") in l1111l_l1_
	if cond1 or cond2: l1111l_l1_ = url
	cond1 = l1l11l_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ䧂") not in l1111l_l1_ and l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭䧃") not in l1111l_l1_
	cond2 = l1l11l_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭䧄") not in l1111l_l1_  and l1l11l_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡹࡴࡰࡴࡨࡪࡷࡵ࡮ࡵࠩ䧅") not in l1111l_l1_
	if index[0:5]==l1l11l_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀࠧ䧆") and cond1 and cond2: l1111l_l1_ = url
	if l1l11l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ䧇") in url or l1l11l_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ䧈") in l1111l_l1_:
		level,l1l11llll11l_l1_,index2,l1l1l1111ll1_l1_ = l1l11l_l1_ (u"ࠪ࠵ࠬ䧉"),l1l11l_l1_ (u"ࠫ࠵࠭䧊"),l1l11l_l1_ (u"ࠬ࠶ࠧ䧋"),l1l11l_l1_ (u"࠭࠰ࠨ䧌")
		index = l1l11l_l1_ (u"ࠧࠨ䧍")
	data2 = l1l11l_l1_ (u"ࠨࠩ䧎")
	if l1l11l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ䧏") in l1111l_l1_ or l1l11l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ䧐") in l1111l_l1_ or l1l11l_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ䧑") in url:
		data = settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ䧒"))
		if data.count(l1l11l_l1_ (u"࠭࠺࠻࠼ࠪ䧓"))==4:
			l1l1l11l1111_l1_,key,l1l1l111l11l_l1_,l1l11llll1ll_l1_,token = data.split(l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ䧔"))
			data2 = l1l1l11l1111_l1_+l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ䧕")+key+l1l11l_l1_ (u"ࠩ࠽࠾࠿࠭䧖")+l1l1l111l11l_l1_+l1l11l_l1_ (u"ࠪ࠾࠿ࡀࠧ䧗")+l1l11llll1ll_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ䧘")+l1l1l11lll11_l1_
			if l1l11l_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ䧙") in url and not l1111l_l1_: l1111l_l1_ = url
			else: l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ䧚")+key
	if not title:
		global l1l11lll11ll_l1_
		l1l11lll11ll_l1_ += 1
		title = l1l11l_l1_ (u"ࠧโ์า๎ํํวหࠢࠪ䧛")+str(l1l11lll11ll_l1_)
		index = l1l11l_l1_ (u"ࠨ࠵ࠪ䧜")+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䧝")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠪ࠾࠿࠭䧞")+index2+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䧟")+l1l1l1111ll1_l1_
	#if l1l11l_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫ䧠") in url: l1111l_l1_ = url
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䧡"),l1l11l_l1_ (u"ࠧࠨ䧢"),title,index+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䧣")+l1111l_l1_)
	#if not l1111l_l1_: l1111l_l1_ = url
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䧤"),l1l11l_l1_ (u"ࠪࠫ䧥"),str(succeeded),title+l1l11l_l1_ (u"ࠫࠥࡀ࠺࠻ࠢࠪ䧦")+l1111l_l1_)
	#if l1l11l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ䧧") in url and index==l1l11l_l1_ (u"࠭࠰ࠨ䧨"):
	#	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䧩"),menu_name+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡑࡻࡹࡖࡪࡴࡤࡦࡴࡨࡶࠬ䧪") in str(item): return False			# l1l1l11l1ll1_l1_ not items
	elif l1l11l_l1_ (u"ࠩ࠲ࡥࡧࡵࡵࡵࠩ䧫") in l1111l_l1_: return False
	elif l1l11l_l1_ (u"ࠪ࠳ࡨࡵ࡭࡮ࡷࡱ࡭ࡹࡿࠧ䧬") in l1111l_l1_: return False
	elif l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䧭") in list(item.keys()) or l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ䧮") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l11l_l1_ (u"࠭࠺࠻ࠩ䧯")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䧰")+index2+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䧱")+l1l1l1111ll1_l1_
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䧲"),menu_name+l1l11l_l1_ (u"ࠪ࠾࠿ࠦࠧ䧳")+l1l11l_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ䧴"),l1111l_l1_,144,img,index,data2)
	elif l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭䧵") in l1111l_l1_:
		title = l1l11l_l1_ (u"࠭࠺࠻ࠢࠪ䧶")+title
		index = l1l11l_l1_ (u"ࠧ࠴ࠩ䧷")+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䧸")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䧹")+index2+l1l11l_l1_ (u"ࠪ࠾࠿࠭䧺")+l1l1l1111ll1_l1_
		url = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ䧻"),l1l11l_l1_ (u"ࠬ࠭䧼"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䧽"),menu_name+title,url,145,l1l11l_l1_ (u"ࠧࠨ䧾"),index,l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䧿"))
	elif l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ䨀") in url and not l1111l_l1_:
		index = l1l11l_l1_ (u"ࠪ࠷ࠬ䨁")+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䨂")+l1l11llll11l_l1_+l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䨃")+index2+l1l11l_l1_ (u"࠭࠺࠻ࠩ䨄")+l1l1l1111ll1_l1_
		title = l1l11l_l1_ (u"ࠧ࠻࠼ࠣࠫ䨅")+title
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䨆"),menu_name+title,url,144,img,index,data2)
	#elif l1l11l_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࡁࠬ䨇") in l1111l_l1_: return False
	elif l1l11l_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࠫ䨈") in l1111l_l1_ and url==l11lll_l1_:
		title = l1l11l_l1_ (u"ࠫ࠿ࡀࠠࠨ䨉")+title
		index = l1l11l_l1_ (u"ࠬ࠸࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ䨊")
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䨋"),menu_name+title,l1111l_l1_,144,img,index,data2)
	elif not l1111l_l1_ and l1l11l_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䨌") in str(item):
		title = l1l11l_l1_ (u"ࠨ࠼࠽ࠤࠬ䨍")+title
		index = l1l11l_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭䨎")
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䨏"),menu_name+title,url,144,img,index)
	elif l1l11l_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䨐") in str(item):
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䨑"),menu_name+title,l1l11l_l1_ (u"࠭ࠧ䨒"),9999)
	#elif l1l11l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ䨓") in l1111l_l1_ and l1l11l_l1_ (u"ࠨࡤࡳࡁࠬ䨔") not in l1111l_l1_:
	#	title = l1l11l_l1_ (u"ࠩ࠽࠾ࠥ࠭䨕")+title
	#	index = l1l11l_l1_ (u"ࠪ࠶࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ䨖")
	#	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䨗"),menu_name+title,l1111l_l1_,144,img,index)
	elif l11lll1l1l1_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ䨘"),menu_name+l11lll1l1l1_l1_+title,l1111l_l1_,143,img)
	elif l1l11l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ䨙") in l1111l_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䨚"),menu_name+l1l11l_l1_ (u"ࠨࡎࡌࡗ࡙࠭䨛")+count+l1l11l_l1_ (u"ࠩ࠽ࠤࠥ࠭䨜")+title,l1111l_l1_,144,img,index)
	#elif l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ䨝") in l1111l_l1_ and l1l11l_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ䨞") not in l1111l_l1_ and l1l11l_l1_ (u"ࠬࡺ࠽࠱ࠩ䨟") not in l1111l_l1_:
	#	l1l1l1111l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ䨠"),l1111l_l1_,re.DOTALL)
	#	l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ䨡")+l1l1l1111l1l_l1_[0]
	#	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䨢"),menu_name+l1l11l_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ䨣")+count+l1l11l_l1_ (u"ࠪ࠾ࠥࠦࠧ䨤")+title,l1111l_l1_,144,img,index)
	elif l1l11l_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭䨥") in l1111l_l1_:
		l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ䨦"),1)[0]
		addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䨧"),menu_name+title,l1111l_l1_,143,img,duration)
	elif l1l11l_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ䨨") in l1111l_l1_:
		if l1l11l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ䨩") in l1111l_l1_ and count:
			l1l1l1111l1l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ䨪"),1)[1]
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ䨫")+l1l1l1111l1l_l1_
			index = l1l11l_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ䨬")
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䨭"),menu_name+l1l11l_l1_ (u"࠭ࡌࡊࡕࡗࠫ䨮")+count+l1l11l_l1_ (u"ࠧ࠻ࠢࠣࠫ䨯")+title,l1111l_l1_,144,img,index)
		else:
			l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ䨰"),1)[0]
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䨱"),menu_name+title,l1111l_l1_,143,img,duration)
	elif l1l11l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭䨲") in l1111l_l1_ or l1l11l_l1_ (u"ࠫ࠴ࡩ࠯ࠨ䨳") in l1111l_l1_ or (l1l11l_l1_ (u"ࠬ࠵ࡀࠨ䨴") in l1111l_l1_ and l1111l_l1_.count(l1l11l_l1_ (u"࠭࠯ࠨ䨵"))==3):
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䨶"),menu_name+l1l11l_l1_ (u"ࠨࡅࡋࡒࡑ࠭䨷")+count+l1l11l_l1_ (u"ࠩ࠽ࠤࠥ࠭䨸")+title,l1111l_l1_,144,img,index)
	elif l1l11l_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ䨹") in l1111l_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䨺"),menu_name+l1l11l_l1_ (u"࡛ࠬࡓࡆࡔࠪ䨻")+count+l1l11l_l1_ (u"࠭࠺ࠡࠢࠪ䨼")+title,l1111l_l1_,144,img,index)
	else:
		if not l1111l_l1_: l1111l_l1_ = url
		title = l1l11l_l1_ (u"ࠧ࠻࠼ࠣࠫ䨽")+title
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䨾"),menu_name+title,l1111l_l1_,144,img,index,data2)
	return True
def l1l1l1l111ll_l1_(item):
	succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,token = False,l1l11l_l1_ (u"ࠩࠪ䨿"),l1l11l_l1_ (u"ࠪࠫ䩀"),l1l11l_l1_ (u"ࠫࠬ䩁"),l1l11l_l1_ (u"ࠬ࠭䩂"),l1l11l_l1_ (u"࠭ࠧ䩃"),l1l11l_l1_ (u"ࠧࠨ䩄"),l1l11l_l1_ (u"ࠨࠩ䩅"),l1l11l_l1_ (u"ࠩࠪ䩆")
	#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ䩇"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,token
	for l1l1l11llll1_l1_ in list(item.keys()):
		render = item[l1l1l11llll1_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l1l11l_l1_ (u"ࠫࠬ䩈"),str(render))
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䩉"),str(render))
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ䩊"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ䩋"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪ࡬ࡪࡰࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䩌"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡹࡳࡶ࡬ࡢࡻࡤࡦࡱ࡫ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䩍"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࡔࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ䩎"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䩏"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ䩐"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ䩑"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ䩒"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ䩓"))
	# required for l1l1l1lllll_l1_ l1l11lllllll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ䩔"))
	# l1l1l111ll11_l1_ l1l1l1111lll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡹ࡭ࡩ࡫࡯ࡊࡦࠪࡡࠧ䩕"))
	succeeded,title,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䩖"),l1l11l_l1_ (u"ࠬ࠭䩗"),l1l11l_l1_ (u"࠭ࠧ䩘"),str(l1l111ll_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ䩙"),str(l1l111ll_l1_)+l1l11l_l1_ (u"ࠨࠢࠣࠤࠬ䩚")+str(title))
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ䩛"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ䩜"))
	# l1l1l111lll1_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ䩝"))
	# header feed
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ䩞"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ䩟"))
	# required for l1l1l1lllll_l1_ l1l11lll1ll1_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䩠"))
	# l1l1l111ll11_l1_ l1l1l1111lll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ䩡"))
	succeeded,l1111l_l1_,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ䩢"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䩣"))
	# l1l1l111ll11_l1_ l1l1l1111lll_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ䩤"))
	succeeded,img,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䩥"),str(l1l111ll_l1_)+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ䩦")+img)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸࠬࡣࠢ䩧"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ䩨"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡄࡲࡸࡹࡵ࡭ࡑࡣࡱࡩࡱࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ䩩"))
	succeeded,count,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ䩪"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ䩫"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ䩬"))
	# l1l1l11l11ll_l1_ l1l1l111ll11_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡤࡱࡱࠫࡢࡡࠧࡪࡥࡲࡲ࡙ࡿࡰࡦࠩࡠࠦ䩭"))
	# l1l1l11l11ll_l1_ l1l1l111ll11_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡴࡶࡼࡰࡪ࠭࡝ࠣ䩮"))
	succeeded,duration,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	#l1l11ll1lll1_l1_ = []
	# l1l1l111lll1_l1_
	#l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡬ࡪࡥ࡮ࡘࡷࡧࡣ࡬࡫ࡱ࡫ࡕࡧࡲࡢ࡯ࡶࠫࡢࠨ䩯"))
	# l11lll1ll1l_l1_ l1l1l11l1l11_l1_
	#l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡹࡸࡡࡤ࡭࡬ࡲ࡬ࡖࡡࡳࡣࡰࡷࠬࡣࠢ䩰"))
	#succeeded,l1l11lll1l11_l1_,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	l1l11ll1lll1_l1_ = []
	# l11lll1ll1l_l1_ l1l1l11l1l11_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ䩱"))
	# l1l1l111lll1_l1_
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ䩲"))
	succeeded,token,l1l111ll_l1_ = l1l11ll1ll11_l1_(item,render,l1l11ll1lll1_l1_)
	if l1l11l_l1_ (u"ࠬࡒࡉࡗࡇࠪ䩳") in duration: duration,l11lll1l1l1_l1_ = l1l11l_l1_ (u"࠭ࠧ䩴"),l1l11l_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ䩵")
	if l1l11l_l1_ (u"ࠨ็หหูืࠧ䩶") in duration: duration,l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠩࠪ䩷"),l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ䩸")
	if l1l11l_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ䩹") in list(render.keys()):
		l1l1l11ll11l_l1_ = str(render[l1l11l_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ䩺")])
		if l1l11l_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭䩻") in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠧࠥ࠼ࠣࠤࠬ䩼")
		if l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䩽") in l1l1l11ll11l_l1_: l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ䩾")
		if l1l11l_l1_ (u"ࠪࡆࡺࡿࠧ䩿") in l1l1l11ll11l_l1_ or l1l11l_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ䪀") in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ䪁")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡻࠧๆสสุึ࠭䪂")) in l1l1l11ll11l_l1_: l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ䪃")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡶࠩืีฬวࠧ䪄")) in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ䪅")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡸࠫฬูสวฮสีࠬ䪆")) in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ䪇")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ䪈")) in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ䪉")
	l1111l_l1_ = escapeUNICODE(l1111l_l1_)
	if l1111l_l1_ and l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ䪊") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
	img = img.split(l1l11l_l1_ (u"ࠨࡁࠪ䪋"))[0]
	if  img and l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䪌") not in img: img = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ䪍")+img
	title = escapeUNICODE(title)
	if l1l1l1111l11_l1_: title = l1l1l1111l11_l1_+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l11l_l1_ (u"ࠫ࠱࠭䪎"),l1l11l_l1_ (u"ࠬ࠭䪏"))
	count = count.replace(l1l11l_l1_ (u"࠭ࠬࠨ䪐"),l1l11l_l1_ (u"ࠧࠨ䪑"))
	count = re.findall(l1l11l_l1_ (u"ࠨ࡞ࡧ࠯ࠬ䪒"),count)
	if count: count = count[0]
	else: count = l1l11l_l1_ (u"ࠩࠪ䪓")
	return True,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_,token
def l1l1l11111ll_l1_(url,data=l1l11l_l1_ (u"ࠪࠫ䪔"),request=l1l11l_l1_ (u"ࠫࠬ䪕")):
	if request==l1l11l_l1_ (u"ࠬ࠭䪖"): request = l1l11l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭䪗")
	#if l1l11l_l1_ (u"ࠧࡠࡡࠪ䪘") in l1l1l1l111l1_l1_: l1l1l1l111l1_l1_ = l1l11l_l1_ (u"ࠨࠩ䪙")
	#if l1l11l_l1_ (u"ࠩࡶࡷࡂ࠭䪚") in url: url = url.split(l1l11l_l1_ (u"ࠪࡷࡸࡃࠧ䪛"))[0]
	useragent = l1ll1111l_l1_()
	#useragent = l1l11l_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠳࠳࠽࠳࠶࠮࠱࠰࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠤࡊࡪࡧ࠰࠳࠳࠽࠳࠶࠮࠲࠷࠴࠼࠳࠽࠰ࠨ䪜")
	headers2 = {l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䪝"):useragent,l1l11l_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭䪞"):l1l11l_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ䪟")}
	#headers2 = headers.copy()
	global settings
	if not data: data = settings.getSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ䪠"))
	if data.count(l1l11l_l1_ (u"ࠩ࠽࠾࠿࠭䪡"))==4: l1l1l11l1111_l1_,key,l1l1l111l11l_l1_,l1l11llll1ll_l1_,token = data.split(l1l11l_l1_ (u"ࠪ࠾࠿ࡀࠧ䪢"))
	else: l1l1l11l1111_l1_,key,l1l1l111l11l_l1_,l1l11llll1ll_l1_,token = l1l11l_l1_ (u"ࠫࠬ䪣"),l1l11l_l1_ (u"ࠬ࠭䪤"),l1l11l_l1_ (u"࠭ࠧ䪥"),l1l11l_l1_ (u"ࠧࠨ䪦"),l1l11l_l1_ (u"ࠨࠩ䪧")
	data2 = {l1l11l_l1_ (u"ࠤࡦࡳࡳࡺࡥࡹࡶࠥ䪨"):{l1l11l_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ䪩"):{l1l11l_l1_ (u"ࠦ࡭ࡲࠢ䪪"):l1l11l_l1_ (u"ࠧࡧࡲࠣ䪫"),l1l11l_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ䪬"):l1l11l_l1_ (u"ࠢࡘࡇࡅࠦ䪭"),l1l11l_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ䪮"):l1l1l111l11l_l1_}}}
	if url==l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ䪯") or l1l11l_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ䪰") in url:
		url = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡶࡪ࡫࡬࠰ࡴࡨࡩࡱࡥࡷࡢࡶࡦ࡬ࡤࡹࡥࡲࡷࡨࡲࡨ࡫ࠧ䪱")+l1l11l_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ䪲")+key
		data2[l1l11l_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࡑࡣࡵࡥࡲࡹࠧ䪳")] = l1l1l11l1111_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䪴"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠴ࡷࡹ࠭䪵"))
	elif l1l11l_l1_ (u"ࠩ࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ䪶") in url:
		url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭䪷")+key
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䪸"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠳ࡳࡦࠪ䪹"))
	elif l1l11l_l1_ (u"࠭࡫ࡦࡻࡀࠫ䪺") in url and l1l1l11l1111_l1_:
		data2[l1l11l_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭䪻")] = token
		data2[l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ䪼")][l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࠩ䪽")][l1l11l_l1_ (u"ࠪࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠨ䪾")] = l1l1l11l1111_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䪿"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ䫀"))
	elif l1l11l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ䫁") in url and l1l11llll1ll_l1_:
		headers2.update({l1l11l_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ䫂"):l1l11l_l1_ (u"ࠨ࠳ࠪ䫃"),l1l11l_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭䫄"):l1l1l111l11l_l1_})
		headers2.update({l1l11l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䫅"):l1l11l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ䫆")+l1l11llll1ll_l1_})
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䫇"),url,l1l11l_l1_ (u"࠭ࠧ䫈"),headers2,l1l11l_l1_ (u"ࠧࠨ䫉"),l1l11l_l1_ (u"ࠨࠩ䫊"),l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠹ࡹ࡮ࠧ䫋"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䫌"),url,l1l11l_l1_ (u"ࠫࠬ䫍"),headers2,l1l11l_l1_ (u"ࠬ࠭䫎"),l1l11l_l1_ (u"࠭ࠧ䫏"),l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠸ࡷ࡬ࠬ䫐"))
	html = response.content
	tmp = re.findall(l1l11l_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫑"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫒"),html,re.DOTALL|re.I)
	if tmp: l1l1l111l11l_l1_ = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠪࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫓"),html,re.DOTALL|re.I)
	if tmp: l1l1l11l1111_l1_ = tmp[0]
	#tmp = re.findall(l1l11l_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫔"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䫕"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩࠨ࠺ࡼࠤࡷࡳࡰ࡫࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䫖"),html,re.DOTALL|re.I)
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䫗"),l1l11l_l1_ (u"ࠨࠩ䫘"),l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ䫙"),str(len(tmp)))
	#if tmp: l1l1l111lll1_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l11l_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ䫚") in list(cookies.keys()): l1l11llll1ll_l1_ = cookies[l1l11l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ䫛")]
	l1l1l1lll_l1_ = l1l1l11l1111_l1_+l1l11l_l1_ (u"ࠬࡀ࠺࠻ࠩ䫜")+key+l1l11l_l1_ (u"࠭࠺࠻࠼ࠪ䫝")+l1l1l111l11l_l1_+l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ䫞")+l1l11llll1ll_l1_+l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ䫟")+token
	if request==l1l11l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ䫠") and l1l11l_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ䫡") in html:
		l1l11ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡠࡠࠨࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠨ࡜࡞ࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭䫢"),html,re.DOTALL)
		if not l1l11ll1l1_l1_: l1l11ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭䫣"),html,re.DOTALL)
		l1l11ll1llll_l1_ = EVAL(l1l11l_l1_ (u"࠭ࡳࡵࡴࠪ䫤"),l1l11ll1l1_l1_[0])
	elif request==l1l11l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ䫥") and l1l11l_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭䫦") in html:
		l1l11ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ䫧"),html,re.DOTALL)
		l1l11ll1llll_l1_ = EVAL(l1l11l_l1_ (u"ࠪࡷࡹࡸࠧ䫨"),l1l11ll1l1_l1_[0])
	elif l1l11l_l1_ (u"ࠫࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ䫩") not in html: l1l11ll1llll_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡹࡴࡳࠩ䫪"),html)
	else: l1l11ll1llll_l1_ = l1l11l_l1_ (u"࠭ࠧ䫫")
	if 0:
		cc = str(l1l11ll1llll_l1_)
		if kodi_version>18.99: cc = cc.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䫬"))
		open(l1l11l_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮ࡥࡣࡷࠫ䫭"),l1l11l_l1_ (u"ࠩࡺࡦࠬ䫮")).write(cc)
		#open(l1l11l_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ䫯"),l1l11l_l1_ (u"ࠫࡼ࠭䫰")).write(html)
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ䫱"),l1l1l1lll_l1_)
	return html,l1l11ll1llll_l1_,l1l1l1lll_l1_
def l1l1l11lllll_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ䫲"),l1l11l_l1_ (u"ࠧࠬࠩ䫳"))
	url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ䫴")+search
	l111l1_l1_(url2,index)
	return
def SEARCH(search):
	#search = l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䫵")+l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࠨ䫶")+l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ䫷")+l1l11l_l1_ (u"ࠬࡥࠧ䫸")+search
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䫹"),l1l11l_l1_ (u"ࠧࠨ䫺"),l1l11l_l1_ (u"ࠨࠩ䫻"),search)
	search,options,showdialogs = SEARCH_OPTIONS(search)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䫼"),l1l11l_l1_ (u"ࠪࠫ䫽"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭䫾"),l1l11l_l1_ (u"ࠬ࠱ࠧ䫿"))
	url2 = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࠨ䬀")+search
	if not showdialogs:
		if l1l11l_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࡡࠪ䬁") in options: l1l11lllll1l_l1_ = l1l11l_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡕࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ䬂")
		elif l1l11l_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨ䬃") in options: l1l11lllll1l_l1_ = l1l11l_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ䬄")
		elif l1l11l_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࠩ䬅") in options: l1l11lllll1l_l1_ = l1l11l_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡨࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ䬆")
		else: l1l11lllll1l_l1_ = l1l11l_l1_ (u"࠭ࠧ䬇")
		url3 = url2+l1l11lllll1l_l1_
	else:
		l1l11lll1lll_l1_,l1l11ll1l1ll_l1_,title2 = [],[],l1l11l_l1_ (u"ࠧࠨ䬈")
		l1l11ll1ll1l_l1_ = [l1l11l_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ䬉"),l1l11l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ䬊"),l1l11l_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭䬋"),l1l11l_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ䬌"),l1l11l_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ䬍")]
		l1l1l11l1l1l_l1_ = [l1l11l_l1_ (u"࠭ࠧ䬎"),l1l11l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭䬏"),l1l11l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ䬐"),l1l11l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ䬑"),l1l11l_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ䬒")]
		l1l1l11ll1ll_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ䬓"),l1l11ll1ll1l_l1_)
		if l1l1l11ll1ll_l1_ == -1: return
		l1l1l11ll1l1_l1_ = l1l1l11l1l1l_l1_[l1l1l11ll1ll_l1_]
		html,c,data = l1l1l11111ll_l1_(url2+l1l1l11ll1l1_l1_)
		if c:
			try:
				d = c[l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ䬔")][l1l11l_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ䬕")][l1l11l_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ䬖")][l1l11l_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䬗")][l1l11l_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ䬘")][l1l11l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ䬙")][l1l11l_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ䬚")]
				for l1l11ll1l1l1_l1_ in range(len(d)):
					group = d[l1l11ll1l1l1_l1_][l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䬛")][l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䬜")]
					for l1l1l1l11111_l1_ in range(len(group)):
						render = group[l1l1l1l11111_l1_][l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䬝")]
						if l1l11l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭䬞") in list(render.keys()):
							l1111l_l1_ = render[l1l11l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ䬟")][l1l11l_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ䬠")][l1l11l_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ䬡")][l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ䬢")]
							l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭䬣"),l1l11l_l1_ (u"ࠧࠧࠩ䬤"))
							title = render[l1l11l_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ䬥")]
							title = title.replace(l1l11l_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ䬦"),l1l11l_l1_ (u"ࠪࠫ䬧"))
							if l1l11l_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ䬨") in title: continue
							if l1l11l_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ䬩") in title:
								title = l1l11l_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ䬪")+title
								title2 = title
								l111l1ll1_l1_ = l1111l_l1_
							if l1l11l_l1_ (u"ࠧหำอ๎อࠦอิสࠪ䬫") in title: continue
							title = title.replace(l1l11l_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭䬬"),l1l11l_l1_ (u"ࠩࠪ䬭"))
							if l1l11l_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ䬮") in title: continue
							if l1l11l_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭䬯") in title:
								title = l1l11l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭䬰")+title
								title2 = title
								l111l1ll1_l1_ = l1111l_l1_
							if l1l11l_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ䬱") in title: continue
							l1l11lll1lll_l1_.append(escapeUNICODE(title))
							l1l11ll1l1ll_l1_.append(l1111l_l1_)
			except: pass
		if not title2: l1l1l11l11l1_l1_ = l1l11l_l1_ (u"ࠧࠨ䬲")
		else:
			l1l11lll1lll_l1_ = [l1l11l_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ䬳"),title2]+l1l11lll1lll_l1_
			l1l11ll1l1ll_l1_ = [l1l11l_l1_ (u"ࠩࠪ䬴"),l111l1ll1_l1_]+l1l11ll1l1ll_l1_
			l1l1l11lll1l_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ䬵"),l1l11lll1lll_l1_)
			if l1l1l11lll1l_l1_ == -1: return
			l1l1l11l11l1_l1_ = l1l11ll1l1ll_l1_[l1l1l11lll1l_l1_]
		if l1l1l11l11l1_l1_: url3 = l11lll_l1_+l1l1l11l11l1_l1_
		elif l1l1l11ll1l1_l1_: url3 = url2+l1l1l11ll1l1_l1_
		else: url3 = url2
		l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩ࡭ࡱࡺࡥࡳ࠯ࡧࡶࡴࡶࡤࡰࡹࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡳࡦࡥࡷ࡭ࡴࡴࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡕࡩࡲࡵࡶࡦࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠫ࠱࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡱࡵࡸࠥࡨࡹࠨ࠮ࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ࠱ࡴࡪࡶ࡯ࡩࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠨࠢࠣ䬶")
	#DIALOG_OK()
	l111l1_l1_(url3)
	return
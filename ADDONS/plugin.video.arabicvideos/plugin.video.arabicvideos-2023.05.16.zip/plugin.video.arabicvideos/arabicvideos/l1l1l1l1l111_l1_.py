# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧࡕࡇࡖࡘࠬ䘸"),l1l11l_l1_ (u"ࠨࡖࡈࡗ࡙࠭䘹"))
#url = l1l11l_l1_ (u"ࠩࡆ࠾ࡡࡢࡐࡰࡴࡷࡥࡧࡲࡥࠡࡒࡵࡳ࡬ࡸࡡ࡮ࡵ࡟ࡠࡐࡕࡄࡊࡡࡹ࠵࠽ࡥ࠶࠵ࡤ࡬ࡸࡡࡢࡋࡰࡦ࡬ࡠࡡࡶ࡯ࡳࡶࡤࡦࡱ࡫࡟ࡥࡣࡷࡥࡡࡢࡣࡢࡥ࡫ࡩࡡࡢࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࡠࡡ࡬ࡩ࡭ࡧࡢ࠴࠽࠿࠶ࡠࡕࡋ࡚ࡤุ๊ศำฬࡣฬ๊ัิ๊็ࡣฬ๊รฺฺ่ࡣ࠭฻ࠩࡠࠪฦฬฬึัࡠษ็ั้๎วอ์ࠬ࠲ࡲࡶ࠳ࠨ䘺")
#url = l1l11l_l1_ (u"ࠪࡧ࠿ࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ䘻")
#url = l1l11l_l1_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ䘼")
#url = l1l11l_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ䘽")
url = l1l11l_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ใะู࠳ࡳࡰ࠴ࠩ䘾")
url = l1l11l_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ࡩ࡭ࡱ࡫࡟࠵࠺࠶࠸ࡤ࡙ࡈࡗࡡี๎ฬืษࡠษ็ีุ๎ไࡠษ็ว฾฾ๅࡠุࠪ࠭ࡤ࠮รษษำีࡤอไฮๆ๋หั๐ࠩ࠯࡯ࡳ࠷ࠬ䘿")
#url = url.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䙀"))
xbmc.Player().play(url)
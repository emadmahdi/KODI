# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䬷")
menu_name = l1l11l_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ䬸")
l11lll_l1_ = WEBSITES[script_name][0]
#headers = l1l11l_l1_ (u"ࠧࠨ䬹")
#headers = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䬺"):l1l11l_l1_ (u"ࠩࠪ䬻")}
def MAIN(mode,url,text,type,page):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1ll1lllll_l1_(url)
	#elif mode==142: results = l1l11ll11l11_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,page)
	elif mode==145: results = l1l1l11lllll_l1_(url)
	elif mode==146: results = l1l11ll1111l_l1_(url)
	elif mode==147: results = l1l1l111l111_l1_()
	elif mode==148: results = l1l1l111l1l1_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࡐࡍࡆ࠶࡜ࡨ࡞ࡋࡃࡗࡶࡾࡱࡈࡴࡎࡕࡺࡊ࡫ࡠ࡚ࡗࡖࡏࡔࡐࢀࡺࡱࡴࡻࡓࡘ࠭䬼")
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䬽"),menu_name+l1l11l_l1_ (u"࡚ࠬࡅࡔࡖࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠫ䬾"),url,144)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䬿"),menu_name+l1l11l_l1_ (u"ࠧࡰ࡮ࡧࡩࡷࠦࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠡࡰࡲࡸࠥࡲࡩࡴࡶ࡬ࡲ࡬ࠦ࡮ࡦࡹࡨࡶࠥࡶ࡬ࡺࡣ࡯࡭ࡸࡺࠧ䭀"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡞ࡆࡱࡳࡨ࡝ࡿ࡞࡚ࡧ࡭ࠩࡰ࡮ࡹࡴ࠾ࡔࡇࡕࡒ࠼࠳ࡷࡊ࡭ࡔ࠵࡮ࡥࡕࡵࠪ䭁"),144)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䭂"),menu_name+l1l11l_l1_ (u"้ࠪํู่ࠡใสี฿࠭䭃"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࡕࡄࡶࡒࡺࡴࡴࡪ࠵ࡉࡼࡳࡵࡓࡔࡎࡄࡤ࠶࠸ࡷࡕࡤࡹࠪ䭄"),144)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭅"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䭆"),l1l11l_l1_ (u"ࠧࠨ䭇"),149,l1l11l_l1_ (u"ࠨࠩ䭈"),l1l11l_l1_ (u"ࠩࠪ䭉"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䭊"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭋"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䭌")+l1l11l_l1_ (u"࠭࡟࡚ࡖࡆࡣࠬ䭍")+l1l11l_l1_ (u"ࠧๆ๊สๆ฾ࠦวฯฬสี์อࠠศๆ่ฬึ๋ฬࠨ䭎"),l1l11l_l1_ (u"ࠨࠩ䭏"),290)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䭐"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䭑")+menu_name+l1l11l_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤ๏๎ส๋๊หࠫ䭒"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ䭓"),144)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭔"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䭕")+menu_name+l1l11l_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ䭖"),l11lll_l1_,144,l1l11l_l1_ (u"ࠩࠪ䭗"),l1l11l_l1_ (u"ࠪࠫ䭘"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䭙"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭚"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䭛")+menu_name+l1l11l_l1_ (u"ࠧศๆ่ัฯ๎้ࠡษ็ีฬฬฬࠨ䭜"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ䭝"),146)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䭞"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䭟"),l1l11l_l1_ (u"ࠫࠬ䭠"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭡"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䭢")+menu_name+l1l11l_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤ฾ืศ๋หࠪ䭣"),l1l11l_l1_ (u"ࠨࠩ䭤"),147)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䭥"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䭦")+menu_name+l1l11l_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ䭧"),l1l11l_l1_ (u"ࠬ࠭䭨"),148)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭩"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䭪")+menu_name+l1l11l_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥ฿ัษ์ฬࠫ䭫"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๅ๏๊ๅࠨ䭬"),144)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䭭"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䭮")+menu_name+l1l11l_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢสะ๋ฮ๊สࠩ䭯"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽࡮ࡱࡹ࡭ࡪ࠭䭰"),144)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䭱"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䭲")+menu_name+l1l11l_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ䭳"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ䭴"),144)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭵"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䭶")+menu_name+l1l11l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥ฿ัษ์ฬࠫ䭷"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึุ่๊ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ䭸"),144)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䭹"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䭺")+menu_name+l1l11l_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢสะ๋ฮ๊สࠩ䭻"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡹࡥࡳ࡫ࡨࡷࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ䭼"),144)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭽"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䭾")+menu_name+l1l11l_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦใศำอ์๋࠭䭿"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๆหึะ่็ࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ䮀"),144)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䮁"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䮂")+menu_name+l1l11l_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ䮃"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ䮄"),144)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䮅"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䮆")+menu_name+l1l11l_l1_ (u"ࠨษ็฽ึอโࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ䮇"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑ࠺ࡪࡖࡳ࠹ࡴࡳࡍ࠳࠷ࡓ࡭ࡹ࡝ࡊࡨࡏࡰࡌࡰࡷ࡯ࡵࡻࡴࡲࡘࡋࡺ࡭ࡧࡴࠪ䮈"),144)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䮉"),menu_name+l1l11l_l1_ (u"ࠫฬ฿ฯศัสฮࠥอึศใฬࠤ๏๎ส๋๊หࠫ䮊"),l1l11l_l1_ (u"ࠬ࠭䮋"),144)
	#yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䮌"),l1l11l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭䮍"),l1l11l_l1_ (u"ࠨ้ำหࠥอไศะอ๎ฬืࠠิ๊ไࠤ๏ิัอๅ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨ䮎"),l1l11l_l1_ (u"ࠩ็ว๋ํࠠิ๊ไࠤ๏่่ๆࠢหฮูเ๊ๅࠢหี๋อๅอࠢํ์ฯ๐่ษࠩ䮏"))
	#if yes==1:
	#	url = l1l11l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ䮐")
	#	xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠩࠨ䮑"))
	#	xbmc.executebuiltin(l1l11l_l1_ (u"ࠬࡘࡥࡱ࡮ࡤࡧࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡼࡩࡥࡧࡲࡷ࠱࠭䮒")+url+l1l11l_l1_ (u"࠭ࠩࠨ䮓"))
	#	#xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡓࡷࡱࡅࡩࡪ࡯࡯ࠪࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠫࠪ䮔"))
	return
l1l11l_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡏࡄࡍࡓࡖࡁࡈࡇࠫࡹࡷࡲࠩ࠻ࠌࠌ࡬ࡹࡳ࡬࠭ࡥࡦ࠰ࡩࡧࡴࡢࠢࡀࠤࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄࠬࡺࡸ࡬ࠪࠌࠌ࡭࡫ࠦࠧࡓࡧࡩࡥࡦࡺࠠࡂ࡮࠰ࡋࡦࡳ࡭ࡢ࡮ࠪࠤ࡮ࡴࠠࡩࡶࡰࡰ࠿ࠦࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡷࡵࡰ࠱࠭ࡹࡦࡵࠪ࠭ࠏࠏࡤࡥࠢࡀࠤࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡳࡧࡧࡦࠪ࡯ࡩࡳ࠮ࡤࡥࠫࠬ࠾ࠏࠏࠉࡪࡶࡨࡱࠥࡃࠠࡥࡦ࡞࡭ࡢࠐࠉࠊࡋࡑࡗࡊࡘࡔࡠࡋࡗࡉࡒࡥࡔࡐࡡࡐࡉࡓ࡛ࠨࡪࡶࡨࡱ࠮ࠐࠉࡊࡖࡈࡑࡘ࠮ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠨࠢࠣ䮕")
def l1l1l111l111_l1_():
	ITEMS(l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬสฮࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ䮖"))
	return
def l1l1l111l1l1_l1_():
	ITEMS(l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡹࡼࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ䮗"))
	return
def PLAY(url,type):
	#url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭䮘")
	#items = re.findall(l1l11l_l1_ (u"ࠬࡼ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ䮙"),url,re.DOTALL)
	#id = items[0]
	#l1111l_l1_ = l1l11l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ䮚")+id
	#PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䮛"))
	#return
	l1l11l_l1_ (u"ࠣࠤࠥࠎࠎ࡯࡭ࡱࡱࡵࡸࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡨࡶࡷࡵࡲࡴ࠮ࡷ࡭ࡹࡲࡥࡴ࠮࡯࡭ࡳࡱࡳࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠴ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷࠭ࡻࡲ࡭ࠫࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ䮜")
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l1l11ll1111l_l1_(url):
	html,cc,data = l1l1l11111ll_l1_(url)
	dd = cc[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ䮝")][l1l11l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䮞")][l1l11l_l1_ (u"ࠫࡹࡧࡢࡴࠩ䮟")]
	for ii in range(len(dd)):
		item = dd[ii]
		l1l1l11ll111_l1_(item,url,str(ii))
	ee = dd[0][l1l11l_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䮠")][l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䮡")][l1l11l_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䮢")][l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ䮣")]
	s = 0
	for ii in range(len(ee)):
		item = ee[ii][l1l11l_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䮤")][l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䮥")][0]
		if list(item[l1l11l_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫ䮦")][l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭䮧")].keys())[0]==l1l11l_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䮨"): continue
		succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_ = l1l1l1l111ll_l1_(item)
		if not title:
			s += 1
			title = l1l11l_l1_ (u"ࠧโ์า๎ํํวหࠢิหหาษࠡࠩ䮩")+str(s)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䮪"),menu_name+title,url,144,l1l11l_l1_ (u"ࠩࠪ䮫"),str(ii))
	key = re.findall(l1l11l_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䮬"),html,re.DOTALL)
	url2 = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ䮭")+key[0]
	html,cc,data2 = l1l1l11111ll_l1_(url2)
	for jj in range(3,4):
		dd = cc[l1l11l_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ䮮")][jj][l1l11l_l1_ (u"࠭ࡧࡶ࡫ࡧࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䮯")][l1l11l_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭䮰")]
		for ii in range(len(dd)):
			item = dd[ii]
			if l1l11l_l1_ (u"ࠨ࡛ࡲࡹ࡙ࡻࡢࡦࠢࡓࡶࡪࡳࡩࡶ࡯ࠪ䮱") in str(item): continue
			l1l1l11ll111_l1_(item)
	return
def ITEMS(url,data=l1l11l_l1_ (u"ࠩࠪ䮲"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ䮳"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䮴"),l1l11l_l1_ (u"ࠬ࠭䮵"))
	html,cc,data2 = l1l1l11111ll_l1_(url,data)
	l1ll1lll11_l1_,ff = l1l11l_l1_ (u"࠭ࠧ䮶"),l1l11l_l1_ (u"ࠧࠨ䮷")
	#if l1l11l_l1_ (u"ࠨࡱࡺࡲࡪࡸࠧ䮸") in html.lower(): DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䮹"),l1l11l_l1_ (u"ࠪࠫ䮺"),l1l11l_l1_ (u"ࠫࡴࡽ࡮ࡦࡴࠣࡩࡽ࡯ࡳࡵࠩ䮻"),l1l11l_l1_ (u"ࠬ࡯࡮ࠡࡪࡷࡱࡱ࠭䮼"))
	owner = re.findall(l1l11l_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࡔࡡ࡮ࡧࠥ࠲࠯ࡅࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䮽"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l11l_l1_ (u"ࠧࠣࡸ࡬ࡨࡪࡵࡏࡸࡰࡨࡶࠧ࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䮾"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l11l_l1_ (u"ࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡐࡩࡹࡧࡤࡢࡶࡤࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࡯ࡸࡰࡨࡶ࡚ࡸ࡬ࡴࠤ࠽ࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䮿"),html,re.DOTALL)
	if owner:
		l1ll1lll11_l1_ = l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䯀")+owner[0][0]+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䯁")
		l1111l_l1_ = owner[0][1]
		if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䯂") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
		#if l1l11l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ䯃") in url and l1l11l_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ䯄") not in url and l1l11l_l1_ (u"ࠧ࠰ࡥ࠲ࠫ䯅") not in url and l1l11l_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࠨ䯆") not in url:
		if l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ䯇") in url: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䯈"),menu_name+l1ll1lll11_l1_,l1111l_l1_,144)
	#if cc==l1l11l_l1_ (u"ࠫࠬ䯉"): l1l11l1l1lll_l1_(url,html) ; return
	l1l11l1l1l1l_l1_ = [l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭䯊"),l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䯋"),l1l11l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䯌"),l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ䯍"),l1l11l_l1_ (u"ࠩ࠲ࡪࡪࡧࡴࡶࡴࡨࡨࠬ䯎"),l1l11l_l1_ (u"ࠪࡷࡸࡃࠧ䯏"),l1l11l_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ䯐"),l1l11l_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ䯑"),l1l11l_l1_ (u"࠭ࡢࡱ࠿ࠪ䯒"),l1l11l_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ䯓")]
	l1l11l1lllll_l1_ = not any(value in url for value in l1l11l1l1l1l_l1_)
	if l1l11l1lllll_l1_ and l1ll1lll11_l1_:
		l1l11lll1_l1_ = l1l11l_l1_ (u"ࠨษ็ฬาัࠧ䯔")
		title2 = l1l11l_l1_ (u"ࠩๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ䯕")
		l1l11l1lll1l_l1_ = l1l11l_l1_ (u"ࠪห้็๊ะ์๋๋ฬะࠧ䯖")
		l1l11l1lll11_l1_ = l1l11l_l1_ (u"ࠫฬ๊โ็๊สฮࠬ䯗")
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䯘"),menu_name+l1ll1lll11_l1_,url,9999)
		if l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣสะฯࠧ࠭䯙") in html: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䯚"),menu_name+l1l11lll1_l1_,url,145,l1l11l_l1_ (u"ࠨࠩ䯛"),l1l11l_l1_ (u"ࠩࠪ䯜"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䯝"))
		if l1l11l_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ䯞") in html: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䯟"),menu_name+title2,url+l1l11l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ䯠"),144)
		if l1l11l_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่ๆ๐ฯ๋๊๊หฯࠨࠧ䯡") in html: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯢"),menu_name+l1l11l1lll1l_l1_,url+l1l11l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ䯣"),144)
		if l1l11l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ䯤") in html: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䯥"),menu_name+l1l11l1lll11_l1_,url+l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ䯦"),144)
		if l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡕࡨࡥࡷࡩࡨࠣࠩ䯧") in html: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䯨"),menu_name+l1l11lll1_l1_,url,145,l1l11l_l1_ (u"ࠨࠩ䯩"),l1l11l_l1_ (u"ࠩࠪ䯪"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䯫"))
		if l1l11l_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠤࠪ䯬") in html: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䯭"),menu_name+title2,url+l1l11l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ䯮"),144)
		if l1l11l_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ䯯") in html: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䯰"),menu_name+l1l11l1lll1l_l1_,url+l1l11l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ䯱"),144)
		if l1l11l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡉࡨࡢࡰࡱࡩࡱࡹࠢࠨ䯲") in html: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䯳"),menu_name+l1l11l1lll11_l1_,url+l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ䯴"),144)
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䯵"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䯶"),l1l11l_l1_ (u"ࠨࠩ䯷"),9999)
	if l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ䯸") in url:
		dd = cc[l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䯹")][l1l11l_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䯺")][l1l11l_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ䯻")][l1l11l_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ䯼")][l1l11l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ䯽")]
		l1l11ll11111_l1_ = 0
		for i in range(len(dd)):
			if l1l11l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䯾") in list(dd[i].keys()):
				l1l11ll11ll1_l1_ = dd[i][l1l11l_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䯿")]
				length = len(str(l1l11ll11ll1_l1_))
				if length>l1l11ll11111_l1_:
					l1l11ll11111_l1_ = length
					ff = l1l11ll11ll1_l1_
		if l1l11ll11111_l1_==0: return
	elif l1l11l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ䰀") in url or l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ䰁") in url or l1l11l_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡅ࡫ࡦࡻࡀࠫ䰂") in url or l1l11l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ䰃") in url or l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ䰄") in url or url==l11lll_l1_:
		l1l11ll1lll1_l1_ = []
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡆࡳࡲࡳࡡ࡯ࡦࡶࠫࡢࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ䰅"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ䰆"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ䰇"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䰈"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ䰉"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠮࠳ࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡦࡨ࡬ࡦࡖࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ䰊"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ䰋"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡝ࡡࡵࡥ࡫ࡒࡪࡾࡴࡓࡧࡶࡹࡱࡺࡳࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࠫࡢࠨ䰌"))
		l1l11ll111l1_l1_,ff = l1l11l1ll111_l1_(cc,l1l11l_l1_ (u"ࠩࠪ䰍"),l1l11ll1lll1_l1_)
	if not ff:
		try:
			dd = cc[l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䰎")][l1l11l_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䰏")][l1l11l_l1_ (u"ࠬࡺࡡࡣࡵࠪ䰐")]
			cond1 = l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䰑") in url or l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ䰒") in url or l1l11l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ䰓") in url
			l1l11l1ll1l1_l1_ = l1l11l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠣࠩ䰔") in html or l1l11l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭䰕") in html or l1l11l_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ䰖") in html
			l1l11l1ll11l_l1_ = l1l11l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡗ࡫ࡧࡩࡴࡹࠢࠨ䰗") in html or l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶࡶࠦࠬ䰘") in html or l1l11l_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ䰙") in html
			if cond1 and (l1l11l1ll1l1_l1_ or l1l11l1ll11l_l1_):
				for ii in range(len(dd)):
					if l1l11l_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䰚") not in list(dd[ii].keys()): continue
					ee = dd[ii][l1l11l_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䰛")]
					try: gg = ee[l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ䰜")][l1l11l_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䰝")][l1l11l_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭䰞")][l1l11l_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䰟")][l1l11l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡕࡻࡳࡩࡘࡻࡢࡎࡧࡱࡹࡎࡺࡥ࡮ࡵࠪ䰠")][ii]
					except: gg = ee
					try: l1111l_l1_ = gg[l1l11l_l1_ (u"ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪ䰡")][l1l11l_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ䰢")][l1l11l_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ䰣")][l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ䰤")]
					except: continue
					if   l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭䰥")		in l1111l_l1_	and l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䰦")		in url: ee = dd[ii] ; break
					elif l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ䰧")	in l1111l_l1_	and l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ䰨")	in url: ee = dd[ii] ; break
					elif l1l11l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ䰩")	in l1111l_l1_	and l1l11l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䰪")		in url: ee = dd[ii] ; break
					else: ee = dd[0]
			elif l1l11l_l1_ (u"ࠫࡧࡶ࠽ࠨ䰫") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l1l11l_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䰬")][l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䰭")]
		except: pass
	if not ff: return
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䰮"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ䰯"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ䰰"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䰱"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ䰲"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ䰳"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ䰴"))
	if l1l11l_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭䰵") not in url: l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡴࡷࡥࡑࡪࡴࡵࠨ࡟࡞ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡗࡽࡵ࡫ࡓࡶࡤࡐࡩࡳࡻࡉࡵࡧࡰࡷࠬࡣࠢ䰶"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䰷"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ䰸"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ䰹"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䰺"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ䰻"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ䰼"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ䰽"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䰾"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࠨ䰿"))
	l1l11ll111ll_l1_ = l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡹ้ࠬไࠡไ๋หห๋ࠠศๆอุ฿๐ไࠨ䱀"))
	l1l11l1l11l1_l1_ = l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡺ࠭ใๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭䱁"))
	l1l11l1l1l11_l1_ = l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡻࠧไๆࠣห้่ๆ้ษอࠫ䱂"))
	l1l1l1111l1_l1_ = [l1l11ll111ll_l1_,l1l11l1l11l1_l1_,l1l11l1l1l11_l1_,l1l11l_l1_ (u"ࠧࡂ࡮࡯ࠤࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ䱃"),l1l11l_l1_ (u"ࠨࡃ࡯ࡰࠥࡼࡩࡥࡧࡲࡷࠬ䱄"),l1l11l_l1_ (u"ࠩࡄࡰࡱࠦࡣࡩࡣࡱࡲࡪࡲࡳࠨ䱅")]
	l1l11l1l1ll1_l1_,gg = l1l11l1ll111_l1_(ff,index,l1l11ll1lll1_l1_)
	if l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䱆") in str(type(gg)) and any(value in str(gg[0]) for value in l1l1l1111l1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1l11ll1lll1_l1_ = []
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ䱇"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ䱈"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ䱉"))
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ䱊"))		#4
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ䱋"))		#7
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ䱌"))		#6
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡩࡤࡱࡪࡉࡡࡳࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡨࡣࡰࡩࠬࡣࠢ䱍"))		#5
		l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝ࠣ䱎"))
		l1l11ll111l1_l1_,item = l1l11l1ll111_l1_(gg,index2,l1l11ll1lll1_l1_)
		#if l1l11ll111l1_l1_ not in [l1l11l_l1_ (u"ࠬ࠸ࠧ䱏"),l1l11l_l1_ (u"࠭࠴ࠨ䱐"),l1l11l_l1_ (u"ࠧ࠶ࠩ䱑")]: l1l1l11ll111_l1_(item)		# 2,4,7
		#else: l1l1l11ll111_l1_(item,url,str(index2))
		l1l1l11ll111_l1_(item,url,str(index2))
		if l1l11ll111l1_l1_==l1l11l_l1_ (u"ࠨ࠶ࠪ䱒"):
			try:
				hh = item[l1l11l_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩ䱓")][l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ䱔")][l1l11l_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䱕")][l1l11l_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ䱖")]
				for l1l1l1111ll1_l1_ in range(len(hh)):
					l1l11ll11l1l_l1_ = hh[l1l1l1111ll1_l1_]
					l1l1l11ll111_l1_(l1l11ll11l1l_l1_)
			except: pass
	l1l11lll1ll1_l1_ = False
	if l1l11l_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ䱗") not in url and l1l11l1l1ll1_l1_==l1l11l_l1_ (u"ࠧ࠹ࠩ䱘"): l1l11lll1ll1_l1_ = True
	if l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ䱙") in data2: l1l1l11l1111_l1_,key,l1l1l111lll1_l1_,l1l1l111l11l_l1_,token,l1l11llll1ll_l1_ = data2.split(l1l11l_l1_ (u"ࠩ࠽࠾࠿࠭䱚"))
	else: l1l1l11l1111_l1_,key,l1l1l111lll1_l1_,l1l1l111l11l_l1_,token,l1l11llll1ll_l1_ = l1l11l_l1_ (u"ࠪࠫ䱛"),l1l11l_l1_ (u"ࠫࠬ䱜"),l1l11l_l1_ (u"ࠬ࠭䱝"),l1l11l_l1_ (u"࠭ࠧ䱞"),l1l11l_l1_ (u"ࠧࠨ䱟"),l1l11l_l1_ (u"ࠨࠩ䱠")
	url2,l1lllllll1l_l1_ = l1l11l_l1_ (u"ࠩࠪ䱡"),l1l11l_l1_ (u"ࠪࠫ䱢")
	if menuItemsLIST:
		l1l11ll11lll_l1_ = str(menuItemsLIST[-1][1])
		if   menu_name+l1l11l_l1_ (u"ࠫࡈࡎࡎࡍࠩ䱣") in l1l11ll11lll_l1_: l1lllllll1l_l1_ = l1l11l_l1_ (u"ࠬࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ䱤")
		elif menu_name+l1l11l_l1_ (u"࠭ࡕࡔࡇࡕࠫ䱥") in l1l11ll11lll_l1_: l1lllllll1l_l1_ = l1l11l_l1_ (u"ࠧࡄࡊࡄࡒࡓࡋࡌࡔࠩ䱦")
		elif menu_name+l1l11l_l1_ (u"ࠨࡎࡌࡗ࡙࠭䱧") in l1l11ll11lll_l1_: l1lllllll1l_l1_ = l1l11l_l1_ (u"ࠩࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ䱨")
	if l1l11l_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡶࠦࠬ䱩") in html and l1l11l_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ䱪") not in url and not l1l11lll1ll1_l1_ and l1l11l_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪࠧ䱫") not in url:	# and (index!=l1l11l_l1_ (u"࠭ࠧ䱬") or l1l11l_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ䱭") in url or l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ䱮") in url or l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ䱯") in url or l1l11l_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ䱰") in url):
		url2 = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡤࡧࡪࡢࡺࡂࡧࡹࡵ࡫ࡦࡰࡀࠫ䱱")+l1l1l111lll1_l1_
	elif l1l11l_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠭䱲") in html and l1l11l_l1_ (u"࠭ࡢࡱ࠿ࠪ䱳") not in url and l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭䱴") in url or l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭䱵") in url:
		url2 = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭䱶")+key
	elif l1l11l_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥࠫ䱷") in html and l1l11l_l1_ (u"ࠫࡧࡶ࠽ࠨ䱸") not in url:
		url2 = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࡃࡰ࡫ࡹ࠾ࠩ䱹")+key
	if url2: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱺"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ䱻"),url2,144,l1lllllll1l_l1_,l1l11l_l1_ (u"ࠨࠩ䱼"),data2)
	return
def l1l11l1ll111_l1_(l1l1ll1llll_l1_,l1l1lllll11_l1_,l1l11llll111_l1_):
	cc = l1l1ll1llll_l1_
	ff,index = l1l1ll1llll_l1_,l1l1lllll11_l1_
	gg,index2 = l1l1ll1llll_l1_,l1l1lllll11_l1_
	item,render = l1l1ll1llll_l1_,l1l1lllll11_l1_
	count = len(l1l11llll111_l1_)
	for ii in range(count):
		try:
			out = eval(l1l11llll111_l1_[ii])
			#if isinstance(out,dict): out = l1l11l_l1_ (u"ࠩࠪ䱽")
			return str(ii+1),out
		except: pass
	return l1l11l_l1_ (u"ࠪࠫ䱾"),l1l11l_l1_ (u"ࠫࠬ䱿")
def l1l1l1l111ll_l1_(item):
	try: l1l1l11llll1_l1_ = list(item.keys())[0]
	except: return False,l1l11l_l1_ (u"ࠬ࠭䲀"),l1l11l_l1_ (u"࠭ࠧ䲁"),l1l11l_l1_ (u"ࠧࠨ䲂"),l1l11l_l1_ (u"ࠨࠩ䲃"),l1l11l_l1_ (u"ࠩࠪ䲄"),l1l11l_l1_ (u"ࠪࠫ䲅"),l1l11l_l1_ (u"ࠫࠬ䲆")
	succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_ = False,l1l11l_l1_ (u"ࠬ࠭䲇"),l1l11l_l1_ (u"࠭ࠧ䲈"),l1l11l_l1_ (u"ࠧࠨ䲉"),l1l11l_l1_ (u"ࠨࠩ䲊"),l1l11l_l1_ (u"ࠩࠪ䲋"),l1l11l_l1_ (u"ࠪࠫ䲌"),l1l11l_l1_ (u"ࠫࠬ䲍")
	#WRITE_THIS(l1l11l_l1_ (u"ࠬ࠭䲎"),str(item))
	render = item[l1l1l11llll1_l1_]
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ䲏"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ䲐"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ䲑"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ䲒"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ䲓"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ䲔"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ䲕"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ䲖"))
	l1l11ll111l1_l1_,title = l1l11l1ll111_l1_(item,render,l1l11ll1lll1_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䲗"),l1l11l_l1_ (u"ࠨࠩ䲘"),l1l11l_l1_ (u"ࠩࠪ䲙"),title)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䲚"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ䲛"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䲜"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ䲝")) # required for l1l1l1lllll_l1_ l1l11lll1ll1_l1_
	l1l11ll111l1_l1_,l1111l_l1_ = l1l11l1ll111_l1_(item,render,l1l11ll1lll1_l1_)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䲞"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ䲟"))
	l1l11ll111l1_l1_,img = l1l11l1ll111_l1_(item,render,l1l11ll1lll1_l1_)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࠧ࡞ࠤ䲠"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࡕࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ䲡"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡆࡴࡺࡴࡰ࡯ࡓࡥࡳ࡫࡬ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ䲢"))
	l1l11ll111l1_l1_,count = l1l11l1ll111_l1_(item,render,l1l11ll1lll1_l1_)
	l1l11ll1lll1_l1_ = []
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ䲣"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䲤"))
	l1l11ll1lll1_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ䲥"))
	l1l11ll111l1_l1_,duration = l1l11l1ll111_l1_(item,render,l1l11ll1lll1_l1_)
	if l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䲦") in duration: duration,l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠩࠪ䲧"),l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ䲨")
	if l1l11l_l1_ (u"๊ࠫฮวีำࠪ䲩") in duration: duration,l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠬ࠭䲪"),l1l11l_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ䲫")
	if l1l11l_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ䲬") in list(render.keys()):
		l1l1l11ll11l_l1_ = str(render[l1l11l_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ䲭")])
		if l1l11l_l1_ (u"ࠩࡉࡶࡪ࡫ࠠࡸ࡫ࡷ࡬ࠥࡇࡤࡴࠩ䲮") in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠪࠨ࠿࠭䲯")
		if l1l11l_l1_ (u"ࠫࡑࡏࡖࡆࠢࡑࡓ࡜࠭䲰") in l1l1l11ll11l_l1_: l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭䲱")
		if l1l11l_l1_ (u"࠭ࡂࡶࡻࠪ䲲") in l1l1l11ll11l_l1_ or l1l11l_l1_ (u"ࠧࡓࡧࡱࡸࠬ䲳") in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠨࠦࠧ࠾ࠬ䲴")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡷ้ࠪออิาࠩ䲵")) in l1l1l11ll11l_l1_: l11lll1l1l1_l1_ = l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ䲶")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡹฺࠬัศรࠪ䲷")) in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠬࠪࠤ࠻ࠩ䲸")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡻࠧศีอสัอัࠨ䲹")) in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠧࠥࠦ࠽ࠫ䲺")
		if l1l11ll1ll1_l1_(l1l11l_l1_ (u"ࡶࠩศ฽้อๆศฬࠪ䲻")) in l1l1l11ll11l_l1_: l1l1l1111l11_l1_ = l1l11l_l1_ (u"ࠩࠧ࠾ࠬ䲼")
	l1111l_l1_ = escapeUNICODE(l1111l_l1_)
	if l1111l_l1_ and l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䲽") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
	img = img.split(l1l11l_l1_ (u"ࠫࡄ࠭䲾"))[0]
	if  img and l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䲿") not in img: img = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭䳀")+img
	title = escapeUNICODE(title)
	if l1l1l1111l11_l1_: title = l1l1l1111l11_l1_+l1l11l_l1_ (u"ࠧࠡࠢࠪ䳁")+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l11l_l1_ (u"ࠨ࠮ࠪ䳂"),l1l11l_l1_ (u"ࠩࠪ䳃"))
	count = count.replace(l1l11l_l1_ (u"ࠪ࠰ࠬ䳄"),l1l11l_l1_ (u"ࠫࠬ䳅"))
	count = re.findall(l1l11l_l1_ (u"ࠬࡢࡤࠬࠩ䳆"),count)
	if count: count = count[0]
	else: count = l1l11l_l1_ (u"࠭ࠧ䳇")
	return True,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_
def l1l1l11ll111_l1_(item,url=l1l11l_l1_ (u"ࠧࠨ䳈"),index=l1l11l_l1_ (u"ࠨࠩ䳉")):
	succeeded,title,l1111l_l1_,img,count,duration,l11lll1l1l1_l1_,l1l1l1111l11_l1_ = l1l1l1l111ll_l1_(item)
	#if l1l11l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ䳊") in url and index==l1l11l_l1_ (u"ࠪ࠴ࠬ䳋"):
	#	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳌"),menu_name+title,url,144)
	#	return
	if not succeeded: return
	elif l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ䳍") in str(item): return	# l1l1l111lll1_l1_ not items
	elif l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡖࡹࡷࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䳎") in str(item): return			# l1l1l11l1ll1_l1_ not items
	elif not l1111l_l1_ and l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭䳏") in url: return			# l1111l1ll_l1_ l1l11l1ll1ll_l1_ list not items
	elif title and not l1111l_l1_ and (l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ䳐") in url or l1l11l_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ䳑") in str(item) or url==l11lll_l1_):
		title = l1l11l_l1_ (u"ࠪࡁࡂࡃࠠࠨ䳒")+title+l1l11l_l1_ (u"ࠫࠥࡃ࠽࠾ࠩ䳓")
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䳔"),menu_name+title,l1l11l_l1_ (u"࠭ࠧ䳕"),9999)
	elif title and l1l11l_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ䳖") in str(item):
		addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䳗"),menu_name+title,l1l11l_l1_ (u"ࠩࠪ䳘"),9999)
	elif l1l11l_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ䳙") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳚"),menu_name+title,l1111l_l1_,144,img,index)
	elif not title: return
	elif l11lll1l1l1_l1_: addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ䳛"),menu_name+l11lll1l1l1_l1_+title,l1111l_l1_,143,img)
	#elif l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ䳜") in l1111l_l1_ and l1l11l_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ䳝") not in l1111l_l1_ and l1l11l_l1_ (u"ࠨࡶࡀ࠴ࠬ䳞") not in l1111l_l1_:
	#	l1l1l1111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ䳟"),l1111l_l1_,re.DOTALL)
	#	l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ䳠")+l1l1l1111l1l_l1_[0]
	#	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳡"),menu_name+l1l11l_l1_ (u"ࠬࡒࡉࡔࡖࠪ䳢")+count+l1l11l_l1_ (u"࠭࠺ࠡࠢࠪ䳣")+title,l1111l_l1_,144,img)
	elif l1l11l_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ䳤") in l1111l_l1_ or l1l11l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ䳥") in l1111l_l1_:
		if l1l11l_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ䳦") in l1111l_l1_ and l1l11l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ䳧") not in l1111l_l1_:
			l1l1l1111l1l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ䳨"),1)[1]
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ䳩")+l1l1l1111l1l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䳪"),menu_name+l1l11l_l1_ (u"ࠧࡍࡋࡖࡘࠬ䳫")+count+l1l11l_l1_ (u"ࠨ࠼ࠣࠤࠬ䳬")+title,l1111l_l1_,144,img)
		else:
			l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ䳭"),1)[0]
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䳮"),menu_name+title,l1111l_l1_,143,img,duration)
	else:
		type = l1l11l_l1_ (u"ࠫࠬ䳯")
		if not l1111l_l1_: l1111l_l1_ = url
		#if l1l11l_l1_ (u"ࠬࡹࡳ࠾ࠩ䳰") in l1111l_l1_: l1111l_l1_ = url
		#elif l1l11l_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ䳱") in l1111l_l1_: l1111l_l1_ = url		# not needed it will stop l1l11l1llll1_l1_ l1l1l1lllll_l1_ l1l11lll1ll1_l1_
		elif not any(value in l1111l_l1_ for value in [l1l11l_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ䳲"),l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ䳳"),l1l11l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ䳴"),l1l11l_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䳵"),l1l11l_l1_ (u"ࠫࡸࡹ࠽ࠨ䳶"),l1l11l_l1_ (u"ࠬࡨࡰ࠾ࠩ䳷")]):
			if l1l11l_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ䳸")	in l1111l_l1_ or l1l11l_l1_ (u"ࠧ࠰ࡥ࠲ࠫ䳹") in l1111l_l1_: type = l1l11l_l1_ (u"ࠨࡅࡋࡒࡑ࠭䳺")+count+l1l11l_l1_ (u"ࠩ࠽ࠤࠥ࠭䳻")
			if l1l11l_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ䳼") in l1111l_l1_: type = l1l11l_l1_ (u"࡚࡙ࠫࡅࡓࠩ䳽")+count+l1l11l_l1_ (u"ࠬࡀࠠࠡࠩ䳾")
			index,l1l1l1l111l1_l1_ = l1l11l_l1_ (u"࠭ࠧ䳿"),l1l11l_l1_ (u"ࠧࠨ䴀")
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䴁"),menu_name+type+title,l1111l_l1_,144,img,index)
	return
def l1l1l11111ll_l1_(url,data=l1l11l_l1_ (u"ࠩࠪ䴂"),request=l1l11l_l1_ (u"ࠪࠫ䴃")):
	global settings
	if not data: data = settings.getSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭䴄"))
	#if l1l11l_l1_ (u"ࠬࡥ࡟ࠨ䴅") in l1l1l1l111l1_l1_: l1l1l1l111l1_l1_ = l1l11l_l1_ (u"࠭ࠧ䴆")
	#if l1l11l_l1_ (u"ࠧࡴࡵࡀࠫ䴇") in url: url = url.split(l1l11l_l1_ (u"ࠨࡵࡶࡁࠬ䴈"))[0]
	if request==l1l11l_l1_ (u"ࠩࠪ䴉"): request = l1l11l_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ䴊")
	useragent = l1ll1111l_l1_()
	headers2 = {l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䴋"):useragent,l1l11l_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䴌"):l1l11l_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ䴍")}
	#headers2 = headers.copy()
	if l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ䴎") in data: l1l1l11l1111_l1_,key,l1l1l111lll1_l1_,l1l1l111l11l_l1_,token,l1l11llll1ll_l1_ = data.split(l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ䴏"))
	else: l1l1l11l1111_l1_,key,l1l1l111lll1_l1_,l1l1l111l11l_l1_,token,l1l11llll1ll_l1_ = l1l11l_l1_ (u"ࠩࠪ䴐"),l1l11l_l1_ (u"ࠪࠫ䴑"),l1l11l_l1_ (u"ࠫࠬ䴒"),l1l11l_l1_ (u"ࠬ࠭䴓"),l1l11l_l1_ (u"࠭ࠧ䴔"),l1l11l_l1_ (u"ࠧࠨ䴕")
	if l1l11l_l1_ (u"ࠨࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ䴖") in url:
		data2 = {}
		data2[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ䴗")] = {l1l11l_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ䴘"):{l1l11l_l1_ (u"ࠦ࡭ࡲࠢ䴙"):l1l11l_l1_ (u"ࠧࡧࡲࠣ䴚"),l1l11l_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ䴛"):l1l11l_l1_ (u"ࠢࡘࡇࡅࠦ䴜"),l1l11l_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ䴝"):l1l1l111l11l_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䴞"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ䴟"))
	elif l1l11l_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ䴠") in url and l1l1l11l1111_l1_:
		data2 = {l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ䴡"):token}
		data2[l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ䴢")] = {l1l11l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ䴣"):{l1l11l_l1_ (u"ࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ䴤"):l1l1l11l1111_l1_,l1l11l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ䴥"):l1l11l_l1_ (u"࡛ࠥࡊࡈࠢ䴦"),l1l11l_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ䴧"):l1l1l111l11l_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䴨"),url,data2,headers2,True,True,l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠳ࡰࡧࠫ䴩"))
	elif l1l11l_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ䴪") in url and l1l11llll1ll_l1_:
		headers2.update({l1l11l_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ䴫"):l1l11l_l1_ (u"ࠩ࠴ࠫ䴬"),l1l11l_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ䴭"):l1l1l111l11l_l1_})
		headers2.update({l1l11l_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䴮"):l1l11l_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ䴯")+l1l11llll1ll_l1_})
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䴰"),url,l1l11l_l1_ (u"ࠧࠨ䴱"),headers2,l1l11l_l1_ (u"ࠨࠩ䴲"),l1l11l_l1_ (u"ࠩࠪ䴳"),l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠸ࡸࡤࠨ䴴"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䴵"),url,l1l11l_l1_ (u"ࠬ࠭䴶"),headers2,l1l11l_l1_ (u"࠭ࠧ䴷"),l1l11l_l1_ (u"ࠧࠨ䴸"),l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠷ࡸ࡭࠭䴹"))
	html = response.content
	tmp = re.findall(l1l11l_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䴺"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䴻"),html,re.DOTALL|re.I)
	if tmp: l1l1l111l11l_l1_ = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴼"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠬࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴽"),html,re.DOTALL|re.I)
	if tmp: l1l1l11l1111_l1_ = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ䴾"),html,re.DOTALL|re.I)
	if tmp: l1l1l111lll1_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l11l_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ䴿") in list(cookies.keys()): l1l11llll1ll_l1_ = cookies[l1l11l_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭䵀")]
	data = l1l1l11l1111_l1_+l1l11l_l1_ (u"ࠩ࠽࠾࠿࠭䵁")+key+l1l11l_l1_ (u"ࠪ࠾࠿ࡀࠧ䵂")+l1l1l111lll1_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ䵃")+l1l1l111l11l_l1_+l1l11l_l1_ (u"ࠬࡀ࠺࠻ࠩ䵄")+token+l1l11l_l1_ (u"࠭࠺࠻࠼ࠪ䵅")+l1l11llll1ll_l1_
	if request==l1l11l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ䵆") and l1l11l_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ䵇") in html:
		l1l11ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ䵈"),html,re.DOTALL)
		if not l1l11ll1l1_l1_: l1l11ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ䵉"),html,re.DOTALL)
		l1l11ll1llll_l1_ = EVAL(l1l11l_l1_ (u"ࠫࡸࡺࡲࠨ䵊"),l1l11ll1l1_l1_[0])
	elif request==l1l11l_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ䵋") and l1l11l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ䵌") in html:
		l1l11ll1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭䵍"),html,re.DOTALL)
		l1l11ll1llll_l1_ = EVAL(l1l11l_l1_ (u"ࠨࡵࡷࡶࠬ䵎"),l1l11ll1l1_l1_[0])
	elif l1l11l_l1_ (u"ࠩ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ䵏") not in html: l1l11ll1llll_l1_ = EVAL(l1l11l_l1_ (u"ࠪࡷࡹࡸࠧ䵐"),html)
	else: l1l11ll1llll_l1_ = l1l11l_l1_ (u"ࠫࠬ䵑")
	#open(l1l11l_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲࡯ࡹ࡯࡯ࠩ䵒"),l1l11l_l1_ (u"࠭ࡷࠨ䵓")).write(str(l1l11ll1llll_l1_))
	#open(l1l11l_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ䵔"),l1l11l_l1_ (u"ࠨࡹࠪ䵕")).write(html)
	settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ䵖"),data)
	return html,l1l11ll1llll_l1_,data
def l1l1l11lllll_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠪࠤࠬ䵗"),l1l11l_l1_ (u"ࠫ࠰࠭䵘"))
	url2 = url+l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭䵙")+search
	ITEMS(url2)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ䵚"),l1l11l_l1_ (u"ࠧࠬࠩ䵛"))
	url2 = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࠪ䵜")+search
	if not showdialogs:
		if l1l11l_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࡣࠬ䵝") in options: l1l11lllll1l_l1_ = l1l11l_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡗࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ䵞")
		elif l1l11l_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪ䵟") in options: l1l11lllll1l_l1_ = l1l11l_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ䵠")
		elif l1l11l_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫ䵡") in options: l1l11lllll1l_l1_ = l1l11l_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡪࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ䵢")
		url3 = url2+l1l11lllll1l_l1_
	else:
		l1l11lll1lll_l1_,l1l11ll1l1ll_l1_,title2 = [],[],l1l11l_l1_ (u"ࠨࠩ䵣")
		l1l11ll1ll1l_l1_ = [l1l11l_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭䵤"),l1l11l_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ䵥"),l1l11l_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ䵦"),l1l11l_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ䵧"),l1l11l_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ䵨")]
		l1l1l11l1l1l_l1_ = [l1l11l_l1_ (u"ࠧࠨ䵩"),l1l11l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ䵪"),l1l11l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ䵫"),l1l11l_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ䵬"),l1l11l_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ䵭")]
		l1l1l11ll1ll_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ䵮"),l1l11ll1ll1l_l1_)
		if l1l1l11ll1ll_l1_ == -1: return
		l1l1l11ll1l1_l1_ = l1l1l11l1l1l_l1_[l1l1l11ll1ll_l1_]
		html,c,data = l1l1l11111ll_l1_(url2+l1l1l11ll1l1_l1_)
		if c:
			d = c[l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ䵯")][l1l11l_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䵰")][l1l11l_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ䵱")][l1l11l_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䵲")][l1l11l_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ䵳")][l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ䵴")][l1l11l_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ䵵")]
			for l1l11ll1l1l1_l1_ in range(len(d)):
				group = d[l1l11ll1l1l1_l1_][l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ䵶")][l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䵷")]
				for l1l1l1l11111_l1_ in range(len(group)):
					render = group[l1l1l1l11111_l1_][l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䵸")]
					if l1l11l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ䵹") in list(render.keys()):
						l1111l_l1_ = render[l1l11l_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ䵺")][l1l11l_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭䵻")][l1l11l_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ䵼")][l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䵽")]
						l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ䵾"),l1l11l_l1_ (u"ࠨࠨࠪ䵿"))
						title = render[l1l11l_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ䶀")]
						title = title.replace(l1l11l_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭䶁"),l1l11l_l1_ (u"ࠫࠬ䶂"))
						if l1l11l_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ䶃") in title: continue
						if l1l11l_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ䶄") in title:
							title = l1l11l_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ䶅")+title
							title2 = title
							l111l1ll1_l1_ = l1111l_l1_
						if l1l11l_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ䶆") in title: continue
						title = title.replace(l1l11l_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ䶇"),l1l11l_l1_ (u"ࠪࠫ䶈"))
						if l1l11l_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ䶉") in title: continue
						if l1l11l_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ䶊") in title:
							title = l1l11l_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ䶋")+title
							title2 = title
							l111l1ll1_l1_ = l1111l_l1_
						if l1l11l_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ䶌") in title: continue
						l1l11lll1lll_l1_.append(escapeUNICODE(title))
						l1l11ll1l1ll_l1_.append(l1111l_l1_)
		if not title2: l1l1l11l11l1_l1_ = l1l11l_l1_ (u"ࠨࠩ䶍")
		else:
			l1l11lll1lll_l1_ = [l1l11l_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ䶎"),title2]+l1l11lll1lll_l1_
			l1l11ll1l1ll_l1_ = [l1l11l_l1_ (u"ࠪࠫ䶏"),l111l1ll1_l1_]+l1l11ll1l1ll_l1_
			l1l1l11lll1l_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ䶐"),l1l11lll1lll_l1_)
			if l1l1l11lll1l_l1_ == -1: return
			l1l1l11l11l1_l1_ = l1l11ll1l1ll_l1_[l1l1l11lll1l_l1_]
		if l1l1l11l11l1_l1_: url3 = l11lll_l1_+l1l1l11l11l1_l1_
		elif l1l1l11ll1l1_l1_: url3 = url2+l1l1l11ll1l1_l1_
		else: url3 = url2
		l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡪ࡮ࡲࡴࡦࡴ࠰ࡨࡷࡵࡰࡥࡱࡺࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡸࡪࡳ࠭ࡴࡧࡦࡸ࡮ࡵ࡮ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡩࡧࠢࠪࡖࡪࡳ࡯ࡷࡧࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠬ࠲ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡲࡶࡹࠦࡢࡺࠩ࠯ࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭ࠫࡵ࡫ࡷࡰࡪࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡩࡷࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠢࠣࠤ䶑")
	ITEMS(url3)
	return
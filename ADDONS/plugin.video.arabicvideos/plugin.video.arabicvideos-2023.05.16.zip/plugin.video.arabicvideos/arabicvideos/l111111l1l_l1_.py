# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ↊")
menu_name = l1l11l_l1_ (u"ࠬࡥࡆࡋࡕࡢࠫ↋")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"࠭วๅฬุ๊๏็วหࠩ↌"),l1l11l_l1_ (u"ࠧศ่ืหฦࠦอิษหࠫ↍"),l1l11l_l1_ (u"ࠨู็ฬฬะࠠศๆี์๖อัࠨ↎")]
#headers = {l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭↏"):l1l11l_l1_ (u"ࠪࠫ←")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l111l1_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l111ll_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ↑"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ→"),l1l11l_l1_ (u"࠭ࠧ↓"),399,l1l11l_l1_ (u"ࠧࠨ↔"),l1l11l_l1_ (u"ࠨࠩ↕"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭↖"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ↗"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ↘"),l1l11l_l1_ (u"ࠬ࠭↙"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ↚"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ↛"),l1l11l_l1_ (u"ࠨࠩ↜"),l1l11l_l1_ (u"ࠩࠪ↝"),l1l11l_l1_ (u"ࠪࠫ↞"),l1l11l_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ↟"))
	html = response.content
	items = re.findall(l1l11l_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭↠"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭↡"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ↢")+menu_name+title,l11lll_l1_,391,l1l11l_l1_ (u"ࠨࠩ↣"),l1l11l_l1_ (u"ࠩࠪ↤"),l1l11l_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ↥")+str(seq))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ↦"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ↧")+menu_name+l1l11l_l1_ (u"࠭ๅฯฬสีฬะฺࠠึ๋หห๐ษࠨ↨"),l11lll_l1_,391,l1l11l_l1_ (u"ࠧࠨ↩"),l1l11l_l1_ (u"ࠨࠩ↪"),l1l11l_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪ↫"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ↬"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭↭")+menu_name+l1l11l_l1_ (u"ࠬษูๅ๋ࠣห้ษแๅษ่ࠤฯ่๊๋็ส๏ࠬ↮"),l11lll_l1_,391,l1l11l_l1_ (u"࠭ࠧ↯"),l1l11l_l1_ (u"ࠧࠨ↰"),l1l11l_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡱࡴࡼࡩࡦࡵࠪ↱"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ↲"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ↳")+menu_name+l1l11l_l1_ (u"ࠫศ฿ไ๊ࠢสู่๊ไิๆสฮࠥะโ๋์่ห๐࠭↴"),l11lll_l1_,391,l1l11l_l1_ (u"ࠬ࠭↵"),l1l11l_l1_ (u"࠭ࠧ↶"),l1l11l_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡶࡩࡷ࡯ࡥࡴࠩ↷"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↸"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ↹")+menu_name+l1l11l_l1_ (u"ࠪวๆ๊วๆ่้ࠢ๏ุษࠨ↺"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ↻"),391,l1l11l_l1_ (u"ࠬ࠭↼"),l1l11l_l1_ (u"࠭ࠧ↽"),l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ↾"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↿"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⇀")+menu_name+l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪ⇁"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠭⇂"),391,l1l11l_l1_ (u"ࠬ࠭⇃"),l1l11l_l1_ (u"࠭ࠧ⇄"),l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⇅"))
	block = l1l11l_l1_ (u"ࠨࠩ⇆")
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧ⇇"),html,re.DOTALL)
	if l1ll111_l1_: block += l1ll111_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⇈"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⇉"),l1l11l_l1_ (u"ࠬ࠭⇊"),l1l11l_l1_ (u"࠭ࠧ⇋"),l1l11l_l1_ (u"ࠧࠨ⇌"),l1l11l_l1_ (u"ࠨࠩ⇍"),l1l11l_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ⇎"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡲࡥࡢࡵࡨࡷࠧ࠮࠮ࠫࡁࠬࡥࡸ࡯ࡤࡦࠩ⇏"),html,re.DOTALL)
	if l1ll111_l1_: block += l1ll111_l1_[0]
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⇐"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⇑"),l1l11l_l1_ (u"࠭ࠧ⇒"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⇓"),block,re.DOTALL)
	first = True
	for l1111l_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l11l_l1_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ⇔"):
			if first:
				title = l1l11l_l1_ (u"ࠩส่ฬ็ไศ็ࠣࠫ⇕")+title
				first = False
			else: title = l1l11l_l1_ (u"ࠪห้๋ำๅี็หฯࠦࠧ⇖")+title
		if title not in l1llll1_l1_:
			if title==l1l11l_l1_ (u"ࠫศ็ไศ็ࠪ⇗"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇘"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⇙")+menu_name+title,l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ⇚"),391,l1l11l_l1_ (u"ࠨࠩ⇛"),l1l11l_l1_ (u"ࠩࠪ⇜"),l1l11l_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⇝"))
			elif title==l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠬ⇞"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇟"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⇠")+menu_name+title,l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩ⇡"),391,l1l11l_l1_ (u"ࠨࠩ⇢"),l1l11l_l1_ (u"ࠩࠪ⇣"),l1l11l_l1_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⇤"))
			else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇥"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⇦")+menu_name+title,l1111l_l1_,391)
	return html
def l111l1_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⇧"),l1l11l_l1_ (u"ࠧࠨ⇨"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⇩"),url,l1l11l_l1_ (u"ࠩࠪ⇪"),l1l11l_l1_ (u"ࠪࠫ⇫"),l1l11l_l1_ (u"ࠫࠬ⇬"),l1l11l_l1_ (u"ࠬ࠭⇭"),l1l11l_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⇮"))
	html = response.content
	if type in [l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ⇯"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⇰")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ⇱"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⇲"),l1l11l_l1_ (u"ࠫࠬ⇳"),url,block)
	elif type==l1l11l_l1_ (u"ࠬࡧ࡬࡭ࡡࡰࡳࡻ࡯ࡥࡴࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⇴"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࡥࡷࡩࡨࡪࡸࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ⇵"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
	elif type==l1l11l_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡰࡳࡻ࡯ࡥࡴࠩ⇶"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶ࡯ࡩ࡫ࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠫࡹࡵࡰ࠮࡫ࡰࡨࡧ࠳࡬ࡪࡵࡷࠤࡹࡸࡩࡨࡪࡷࠦ⇷"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ⇸"),l1l11l_l1_ (u"ࠪࠫ⇹"),str(len(block)),type)
			items = re.findall(l1l11l_l1_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⇺"),block,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟ࡴࡧࡵ࡭ࡪࡹࠧ⇻"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡴࡰࡲ࠰࡭ࡲࡪࡢ࠮࡮࡬ࡷࡹࠦࡴࡳ࡫ࡪ࡬ࡹ࠮࠮ࠫࡁࠬࡪࡴࡵࡴࡦࡴࠥ⇼"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ⇽"),l1l11l_l1_ (u"ࠨࠩ⇾"),str(len(block)),type)
			items = re.findall(l1l11l_l1_ (u"ࠤ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ⇿"),block,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ∀"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ∁"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ∂"),block,re.DOTALL)
	elif type==l1l11l_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ∃"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ∄"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		zzz = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ∅"),block,re.DOTALL)
		l1ll1l1l_l1_,l1ll11l11_l1_,l1l1lll_l1_ = zip(*zzz)
		items = zip(l1ll11l11_l1_,l1ll1l1l_l1_,l1l1lll_l1_)
	elif type==l1l11l_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪ∆"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ∇"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ∈"),block,re.DOTALL)
	elif l1l11l_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ∉") in type:
		seq = int(type[-1:])
		html = html.replace(l1l11l_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ∊"),l1l11l_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭∋"))
		html = html.replace(l1l11l_l1_ (u"ࠨ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭∌"),l1l11l_l1_ (u"ࠩ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡦࡰࡧࡂࠬ∍"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ∎"),html,re.DOTALL)
		block = l1ll111_l1_[seq]
		if seq==6:
			zzz = re.findall(l1l11l_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ∏"),block,re.DOTALL)
			l1ll11l11_l1_,l1l1lll_l1_,l1ll1l1l_l1_ = zip(*zzz)
			items = zip(l1ll11l11_l1_,l1ll1l1l_l1_,l1l1lll_l1_)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ∐"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0][0]
			if l1l11l_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ∑") in url:
				items = re.findall(l1l11l_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ−"),block,re.DOTALL)
			elif l1l11l_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ∓") in url:
				items = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ∔"),block,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ∕"),l1l11l_l1_ (u"ࠫࠬ∖"),str(len(items)),type)
	if not items and block:
		items = re.findall(l1l11l_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ∗"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠫ∘") in title: continue
		if l1l11l_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭∙") in title:
			title = re.findall(l1l11l_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ√"),title,re.DOTALL)
			title = title[0][1]#+l1l11l_l1_ (u"ࠩࠣ࠱ࠥ࠭∛")+title[0][0]
			if title in l1l1l11_l1_: continue
			l1l1l11_l1_.append(title)
			title = l1l11l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ∜")+title
		title2 = re.findall(l1l11l_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬ∝"),title,re.DOTALL)
		if title2: title = title2[0]
		title = unescapeHTML(title)
		if l1l11l_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ∞") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭∟"),menu_name+title,l1111l_l1_,393,img)
		elif l1l11l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ∠") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ∡"),menu_name+title,l1111l_l1_,393,img)
		elif l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ∢") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ∣"),menu_name+title,l1111l_l1_,393,img)
		elif l1l11l_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ∤") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ∥"),menu_name+title,l1111l_l1_,391,img)
		else: addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ∦"),menu_name+title,l1111l_l1_,392,img)
	if type not in [l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ∧"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ∨")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ∩"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ∪"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ∫"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ∬")+title,l1111l_l1_,391,l1l11l_l1_ (u"࠭ࠧ∭"),l1l11l_l1_ (u"ࠧࠨ∮"),type)
	return
def l111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ∯"),l1l11l_l1_ (u"ࠩࠪ∰"),l1l11l_l1_ (u"ࠪࠫ∱"),url)
	server = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ∲"))
	url = url.replace(server,l11lll_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ∳"),url,l1l11l_l1_ (u"࠭ࠧ∴"),l1l11l_l1_ (u"ࠧࠨ∵"),l1l11l_l1_ (u"ࠨࠩ∶"),l1l11l_l1_ (u"ࠩࠪ∷"),l1l11l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ∸"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ∹"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ∺"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ∻"),block,re.DOTALL)
		for img,l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭∼"),menu_name+title,l1111l_l1_,392,img)
	return
def PLAY(url):
	html = l1llll111l_l1_(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ∽"),url,l1l11l_l1_ (u"ࠩࠪ∾"),l1l11l_l1_ (u"ࠪࠫ∿"),l1l11l_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ≀"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ≁"),url,l1l11l_l1_ (u"࠭ࠧ≂"),l1l11l_l1_ (u"ࠧࠨ≃"),l1l11l_l1_ (u"ࠨࠩ≄"),l1l11l_l1_ (u"ࠩࠪ≅"),l1l11l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ≆"))
	#html = response.content
	if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ≇"))
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ≈"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴ࠰ࡳࡵࡺࡩࡰࡰ࠰࠵ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡞ࠦࢁࡢࠧ࡞ࠪࡶ࡬ࡪࡧࡤࡦࡴࡿࡴࡦ࡭࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠫ࡞ࠦࢁࡢࠧ࡞ࠩ≉"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0][0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡹࡱࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡳࡳࡸࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳࡮ࡶ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡷ࡫ࡧࡣࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ≊"),block,re.DOTALL)
		for type,l111l1llll_l1_,l111111ll1_l1_,title in items:
			#l1111l_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡽ࠮ࡢ࡮ࡩࡥ࡯࡫ࡲࡵࡸ࠱ࡧࡴࡳ࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࡤࡨࡲ࡯࡮࠮ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࠪ≋")
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵࡅࡡࡤࡶ࡬ࡳࡳࡃࡤࡰࡱࡢࡴࡱࡧࡹࡦࡴࡢࡥ࡯ࡧࡸࠧࡲࡲࡷࡹࡃࠧ≌")+l111l1llll_l1_+l1l11l_l1_ (u"ࠪࠪࡳࡻ࡭ࡦ࠿ࠪ≍")+l111111ll1_l1_+l1l11l_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࠫ≎")+type
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭≏")+title+l1l11l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ≐")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	#WRITE_THIS(html)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠢࡪࡦࡀࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ࠠࡤ࡮ࡤࡷࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡞ࡠࠧࢂࠧ࡞ࡵࡥࡳࡽࡡ࡜ࠣࡾࠪࡡࠧ≑"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠣ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࠧࡲࡷࡤࡰ࡮ࡺࡹࠨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ≒"),block,re.DOTALL)
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ≓"),l1l11l_l1_ (u"ࠪࠫ≔"),str(items),str(block))
		for img,l1111l_l1_,l1l1l111_l1_,lang in items:
			if l1l11l_l1_ (u"ࠫࡂ࠭≕") in img:
				host = img.split(l1l11l_l1_ (u"ࠬࡃࠧ≖"))[1]
				title = SERVER(host,l1l11l_l1_ (u"࠭ࡨࡰࡵࡷࠫ≗"))
			else: title = l1l11l_l1_ (u"ࠧࠨ≘")
			title = lang+l1l11l_l1_ (u"ࠨࠢࠪ≙")+title
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ≚")+title+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ≛")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ≜"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ≝"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ≞"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨ≟"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ≠"),l1l11l_l1_ (u"ࠩ࠮ࠫ≡"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ≢")+search
	l111l1_l1_(url,l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ≣"))
	return
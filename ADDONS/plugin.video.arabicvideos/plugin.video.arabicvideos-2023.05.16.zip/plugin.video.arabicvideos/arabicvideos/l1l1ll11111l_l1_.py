# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ䍁")
menu_name = l1l11l_l1_ (u"ࠬࡥࡓࡉࡐࡢࠫ䍂")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"࠭โ็๊สฮࠥ็ึศศํอࠬ䍃"),l1l11l_l1_ (u"ࠧโษิื่๎ࠧ䍄"),l1l11l_l1_ (u"ࠨࡕ࡫ࡳࡼࠦ࡭ࡰࡴࡨࠫ䍅")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l111l1_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l111ll_l1_(url,text)
	elif mode==584: results = l1l1l1ll1_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䍆"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ䍇"),l1l11l_l1_ (u"ࠫࠬ䍈"),l1l11l_l1_ (u"ࠬ࠭䍉"),l1l11l_l1_ (u"࠭ࠧ䍊"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䍋"))
	html = response.content
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍌"),menu_name+l1l11l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䍍"),l1l11l_l1_ (u"ࠪࠫ䍎"),589,l1l11l_l1_ (u"ࠫࠬ䍏"),l1l11l_l1_ (u"ࠬ࠭䍐"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䍑"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䍒"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䍓"),l1l11l_l1_ (u"ࠩࠪ䍔"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ䍕"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ䍖"),html,re.DOTALL)
	for l1l11l1l_l1_ in l1ll111_l1_: block = block.replace(l1l11l1l_l1_,l1l11l_l1_ (u"ࠬ࠭䍗"))
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䍘"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䍙"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䍚")+menu_name+title,l1111l_l1_,584)
	return
def l1l1l1ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䍛"),url,l1l11l_l1_ (u"ࠪࠫ䍜"),l1l11l_l1_ (u"ࠫࠬ䍝"),l1l11l_l1_ (u"ࠬ࠭䍞"),l1l11l_l1_ (u"࠭ࠧ䍟"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䍠"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ䍡"),html,re.DOTALL)
	if l11111l1l_l1_:
		block = l11111l1l_l1_[0]
		block = block.replace(l1l11l_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪ䍢"),l1l11l_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩ䍣"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䍤"),block,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = [(l1l11l_l1_ (u"ࠬ࠭䍥"),block)]
		for l1l1ll1111l1_l1_,block in l1ll111_l1_:
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䍦"),block,re.DOTALL)
			if l1l1ll1111l1_l1_: l1l1ll1111l1_l1_ = l1l11l_l1_ (u"ࠧࠡࠩ䍧")+l1l1ll1111l1_l1_
			for l1111l_l1_,title in items:
				title = l1l11l_l1_ (u"ࠨฬึุ่๊ࠧ䍨")+l1l1ll1111l1_l1_+l1l11l_l1_ (u"ࠩ࠽ࠤࠬ䍩")+title
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䍪"),menu_name+title,l1111l_l1_,581)
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䍫"),html,re.DOTALL)
	if l1ll1l1ll_l1_:
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ䍬"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䍭"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䍮"),l1l11l_l1_ (u"ࠨࠩ䍯"),9999)
			for l1111l_l1_,title in items:
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䍰"),menu_name+title,l1111l_l1_,581)
	if not l11111l1l_l1_ and not l1ll1l1ll_l1_: l111l1_l1_(url)
	return
def l111l1_l1_(url,request=l1l11l_l1_ (u"ࠪࠫ䍱")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䍲"),l1l11l_l1_ (u"ࠬ࠭䍳"),request,url)
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䍴"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䍵"),url,l1l11l_l1_ (u"ࠨࠩ䍶"),l1l11l_l1_ (u"ࠩࠪ䍷"),l1l11l_l1_ (u"ࠪࠫ䍸"),l1l11l_l1_ (u"ࠫࠬ䍹"),l1l11l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䍺"))
	html = response.content
	items = []
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䍻"),html,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧ䍼"),html,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ䍽"),html,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䍾"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䍿"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎀"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"๋ࠬิศ้าอࠬ䎁"),l1l11l_l1_ (u"࠭แ๋ๆ่ࠫ䎂"),l1l11l_l1_ (u"ࠧศ฼้๎ฮ࠭䎃"),l1l11l_l1_ (u"ࠨๅ็๎อ࠭䎄"),l1l11l_l1_ (u"ࠩส฽้อๆࠨ䎅"),l1l11l_l1_ (u"๋ࠪิอแࠨ䎆"),l1l11l_l1_ (u"๊ࠫฮวาษฬࠫ䎇"),l1l11l_l1_ (u"ࠬ฿ัืࠩ䎈"),l1l11l_l1_ (u"࠭ๅ่ำฯห๋࠭䎉"),l1l11l_l1_ (u"ࠧศๆห์๊࠭䎊"),l1l11l_l1_ (u"ࠨ็ึีา๐ษࠨ䎋")]
	for img,l1111l_l1_,title in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠩ࠲ࠫ䎌"))
		if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䎍") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠫ࠴࠭䎎")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠬ࠵ࠧ䎏"))
		if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䎐") not in img: img = l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩ䎑")+img.strip(l1l11l_l1_ (u"ࠨ࠱ࠪ䎒"))
		#l1111l_l1_ = unescapeHTML(l1111l_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䎓"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭䎔"),title,re.DOTALL)
		if any(value in title for value in l11111ll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䎕"),menu_name+title,l1111l_l1_,582,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠬอไฮๆๅอࠬ䎖") in title:
			title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䎗") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎘"),menu_name+title,l1111l_l1_,583,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭䎙") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎚"),menu_name+title,l1111l_l1_,581,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎛"),menu_name+title,l1111l_l1_,583,img)
	if request not in [l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭䎜"),l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ䎝")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䎞"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ䎟"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1111l_l1_==l1l11l_l1_ (u"ࠨࠥࠪ䎠"): continue
				l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ䎡")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠪ࠳ࠬ䎢"))
				title = unescapeHTML(title)
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎣"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ䎤")+title,l1111l_l1_,581)
		l111lll11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䎥"),html,re.DOTALL)
		if l111lll11_l1_:
			l1111l_l1_ = l111lll11_l1_[0]
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎦"),menu_name+l1l11l_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ䎧"),l1111l_l1_,581)
	return
def l111ll_l1_(url,l1lllll11l_l1_):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䎨"),l1l11l_l1_ (u"ࠪࠫ䎩"),l1lllll11l_l1_,url)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ䎪"),l1l11l_l1_ (u"ࠬ࠷࠱࠲࠳ࠣࠤࠬ䎫")+url)
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䎬"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䎭"),url,l1l11l_l1_ (u"ࠨࠩ䎮"),l1l11l_l1_ (u"ࠩࠪ䎯"),l1l11l_l1_ (u"ࠪࠫ䎰"),l1l11l_l1_ (u"ࠫࠬ䎱"),l1l11l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ䎲"))
	html = response.content
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭࡮ࡢࡸ࠰ࡷࡪࡧࡳࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䎳"),html,re.DOTALL)
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ䎴"),str(l1lllll11l_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ䎵"),str(l1ll1l1ll_l1_))
	items = []
	# l111l111l_l1_
	l1l1ll1111ll_l1_ = False
	if l11111l1l_l1_ and not l1lllll11l_l1_:
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䎶"),block,re.DOTALL)
		for l1lllll11l_l1_,title in items:
			l1lllll11l_l1_ = l1lllll11l_l1_.strip(l1l11l_l1_ (u"ࠪࠧࠬ䎷"))
			if len(items)>1: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎸"),menu_name+title,url,583,l1l11l_l1_ (u"ࠬ࠭䎹"),l1l11l_l1_ (u"࠭ࠧ䎺"),l1lllll11l_l1_)
			else: l1l1ll1111ll_l1_ = True
	else: l1l1ll1111ll_l1_ = True
	# l1l11l1_l1_
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࠬ䎻")+l1lllll11l_l1_+l1l11l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䎼"),html,re.DOTALL)
	if l1ll1l1ll_l1_ and l1l1ll1111ll_l1_:
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ䎽"),block,re.DOTALL)
		if items:
			for l1111l_l1_,title in items:
				l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࠬ䎾")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠫ࠴࠭䎿"))
				addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䏀"),menu_name+title,l1111l_l1_,582)
		else:
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ䏁"),block,re.DOTALL)
			for l1111l_l1_,title,img in items:
				if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ䏂") not in l1111l_l1_: l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"ࠨ࠱ࠪ䏃")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠩ࠲ࠫ䏄"))
				addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䏅"),menu_name+title,l1111l_l1_,582)
	return
def PLAY(url):
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ䏆"))
	l1ll1l1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䏇"),url,l1l11l_l1_ (u"࠭ࠧ䏈"),l1l11l_l1_ (u"ࠧࠨ䏉"),l1l11l_l1_ (u"ࠨࠩ䏊"),l1l11l_l1_ (u"ࠩࠪ䏋"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䏌"))
	html = response.content
	# l1lllll11111_l1_ page
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䏍"),html,re.DOTALL)
	if l1111l_l1_ and l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䏎") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䏏")+l1111l_l1_[0]
	#//l1llllll1ll1_l1_.l1l1l1llllll_l1_.l1l1l1llll1l_l1_/l1l1ll111111_l1_/?l1l1ll111l11_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l1111l_l1_.split(l1l11l_l1_ (u"ࠧࡩࡣࡶ࡬ࡂ࠭䏐"))[1]
	parts = hash.split(l1l11l_l1_ (u"ࠨࡡࡢࠫ䏑"))
	l1l1l1lllll1_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l11l_l1_ (u"ࠩࡀࠫ䏒"))
			if kodi_version>18.99: part = part.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䏓"))
			l1l1l1lllll1_l1_.append(part)
		except: pass
	l1l1lll1_l1_ = l1l11l_l1_ (u"ࠫࡃ࠭䏔").join(l1l1l1lllll1_l1_)
	l1l1lll1_l1_ = l1l1lll1_l1_.splitlines()
	for l1111l_l1_ in l1l1lll1_l1_:
		title,l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠬࠦ࠽࠿ࠢࠪ䏕"))
		l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䏖")+title+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ䏗")
		l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䏘"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䏙"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠪࠫ䏚"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠫࠬ䏛"): return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧ䏜"),l1l11l_l1_ (u"࠭ࠫࠨ䏝"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ䏞")+search
	l111l1_l1_(url)
	return
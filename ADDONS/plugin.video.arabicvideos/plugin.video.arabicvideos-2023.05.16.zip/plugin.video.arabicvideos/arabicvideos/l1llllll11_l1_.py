# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡪ࠮࠵ࡪࡨࡰࡦࡲ࠮ࡵࡸࠪᖈ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠺ࡨࡦ࡮ࡤࡰ࠳ࡺࡶࠨᖉ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࠸࡭࡫࡬ࡢ࡮࠱ࡸࡻ࠭ᖊ")
script_name = l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨᖋ")
headers = { l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᖌ") : l1l11l_l1_ (u"ࠨࠩᖍ") }
menu_name = l1l11l_l1_ (u"ࠩࡢࡇࡒࡌ࡟ࠨᖎ")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l11l11ll_l1_()
	elif mode==95: results = l111ll_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖏ"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᖐ"),l1l11l_l1_ (u"ࠬ࠭ᖑ"),99,l1l11l_l1_ (u"࠭ࠧᖒ"),l1l11l_l1_ (u"ࠧࠨᖓ"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᖔ"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᖕ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖖ"),l1l11l_l1_ (u"ࠫࠬᖗ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖘ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᖙ")+menu_name+l1l11l_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭ᖚ"),l1l11l_l1_ (u"ࠨࠩᖛ"),94)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖜ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᖝ")+menu_name+l1l11l_l1_ (u"ࠫฬ๊รฮัฮࠫᖞ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡡࡵࡧࡶࡸࠬᖟ"),91)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖠ"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᖡ")+menu_name+l1l11l_l1_ (u"ࠨษ็ว฾๊้ࠡฬๅ๎๊อ๋ࠨᖢ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡬ࡱࡩࡨࠧᖣ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖤ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᖥ")+menu_name+l1l11l_l1_ (u"ࠬอไฤๅฮี๋ࠥิศ้าอࠬᖦ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࡶࡪࡧࡺࠫᖧ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᖨ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᖩ")+menu_name+l1l11l_l1_ (u"ࠩส่๊ัศหࠩᖪ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡴ࡮ࡴࠧᖫ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖬ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᖭ")+menu_name+l1l11l_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬᖮ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡯ࡧࡺࡑࡴࡼࡩࡦࡵࠪᖯ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖰ"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᖱ")+menu_name+l1l11l_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩᖲ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡳ࡫ࡷࡆࡲ࡬ࡷࡴࡪࡥࡴࠩᖳ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᖴ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᖵ"),l1l11l_l1_ (u"ࠧࠨᖶ"),9999)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖷ"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᖸ")+menu_name+l1l11l_l1_ (u"ࠪะิ๐ฯࠡษ็้ํู่ࠨᖹ"),l11lll_l1_,91)
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠫࠬᖺ"),headers,l1l11l_l1_ (u"ࠬ࠭ᖻ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᖼ"))
	#upper l1lllll1ll_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࡮ࡢࡸࠪᖽ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᖾ"),block,re.DOTALL)
	l1llll1_l1_ = [l1l11l_l1_ (u"ࠩสๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠬᖿ")]
	for l1111l_l1_,title in items:
		title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬᗀ"))
		if not any(value in title for value in l1llll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗁ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᗂ")+menu_name+title,l1111l_l1_,91)
	return html
def ITEMS(url):
	if l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࠫᗃ") in url:
		url,search = url.split(l1l11l_l1_ (u"ࠧࡀࡶࡀࠫᗄ"))
		headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᗅ") : l1l11l_l1_ (u"ࠩࠪᗆ") , l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᗇ") : l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪᗈ") }
		data = { l1l11l_l1_ (u"ࠬࡺࠧᗉ") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫᗊ"),url,data,headers,l1l11l_l1_ (u"ࠧࠨᗋ"),l1l11l_l1_ (u"ࠨࠩᗌ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧᗍ"))
		html = response.content
	else:
		headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᗎ") : l1l11l_l1_ (u"ࠫࠬᗏ") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠬ࠭ᗐ"),headers,l1l11l_l1_ (u"࠭ࠧᗑ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠴ࡱࡨࠬᗒ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࡬࡯ࡰࡶࠥࠫᗓ"),html,re.DOTALL)
	if l1ll111_l1_: block = l1ll111_l1_[0]
	else: block = l1l11l_l1_ (u"ࠩࠪᗔ")
	items = re.findall(l1l11l_l1_ (u"ࠪࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡯ࡲࡺ࡮࡫࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗕ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠫฬ๊อๅไฬࠫᗖ") in title and l1l11l_l1_ (u"ࠬ࠵ࡣ࠰ࠩᗗ") not in url and l1l11l_l1_ (u"࠭࠯ࡤࡣࡷ࠳ࠬᗘ") not in url:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮ࡛ࠦ࠱࠯࠼ࡡ࠰࠭ᗙ"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᗚ")+l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗛ"),menu_name+title,l1111l_l1_,95,img)
					l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࠫᗜ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗝ"),menu_name+title,l1111l_l1_,92,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗞ"),menu_name+title,l1111l_l1_,91,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫᗟ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᗠ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠨษ็ูๆำษࠡࠩᗡ"),l1l11l_l1_ (u"ࠩࠪᗢ"))
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗣ"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪᗤ")+title,l1111l_l1_,91)
	return
def l111ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠬ࠭ᗥ"),headers,l1l11l_l1_ (u"࠭ࠧᗦ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᗧ"))
	img = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᗨ"),html,re.DOTALL)
	img = img[0]
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡨࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨᗩ"),html,re.DOTALL)
	if l1ll111_l1_:
		name = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᗪ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬᗫ"))
			if l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗬ") in name: name = name.split(l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᗭ"),1)[1]
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗮ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᗯ"),menu_name+name+l1l11l_l1_ (u"ࠩࠣ࠱ࠥ࠭ᗰ")+title,l1111l_l1_,92,img)
	else:
		tmp = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡴࡼࡩࡦࡶ࡬ࡸࡱ࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᗱ"),html,re.DOTALL)
		if tmp: l1111l_l1_,title = tmp[0]
		else: l1111l_l1_,title = url,name
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗲ"),menu_name+title,l1111l_l1_,92,img)
	return
def PLAY(url):
	l1ll1l1l_l1_,l1lllll1l1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠬ࠭ᗳ"),headers,l1l11l_l1_ (u"࠭ࠧᗴ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᗵ"))
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡶࡨࡼࡹ࠳ࡳࡩࡣࡧࡳࡼࡀࠠ࡯ࡱࡱࡩࡀࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗶ"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᗷ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᗸ"),block,re.DOTALL)
		for l1111l_l1_ in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᗹ")
			l1ll1l1l_l1_.append(l1111l_l1_)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡴࡡࡷ࠯ࡷࡥࡧࡹࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࠱ࡵࡧ࡮ࡦ࡮࠰ࡱࡴࡸࡥࠨᗺ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		# l1l1l1111_l1_ l1l1lll1_l1_
		items = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡫࡭ࡣࡧࡧࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᗻ"),block,re.DOTALL)
		for id,l1111l_l1_ in items:
			title = l1l11l_l1_ (u"ࠧิ์ิๅึࠦࠧᗼ")+id
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᗽ")+title+l1l11l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᗾ")
			l1ll1l1l_l1_.append(l1111l_l1_)
		# other l1l1lll1_l1_
		items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗿ"),block,re.DOTALL)
		for l1111l_l1_ in items:
			if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᘀ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᘁ")+l1111l_l1_
			l1111l_l1_ = UNQUOTE(l1111l_l1_)
			l1ll1l1l_l1_.append(l1111l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᘂ"),url)
	return
def l11l11ll_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11lll_l1_,l1l11l_l1_ (u"ࠧࠨᘃ"),headers,l1l11l_l1_ (u"ࠨࠩᘄ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨᘅ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢࡪࡰࡧࡩࡽ࠳࡬ࡢࡵࡷ࠱ࡲࡵࡶࡪࡧࠫ࠲࠯ࡅࠩࡪࡦࡀࠦ࡮ࡴࡤࡦࡺ࠰ࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࠩᘆ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᘇ"),block,re.DOTALL)
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴࠭ᘈ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᘉ"),menu_name+title,l1111l_l1_,92,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘊ"),menu_name+title,l1111l_l1_,91,img)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠨࠩᘋ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠩࠪᘌ"): return
	search = search.replace(l1l11l_l1_ (u"ࠪࠤࠬᘍ"),l1l11l_l1_ (u"ࠫ࠰࠭ᘎ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡸࡂ࠭ᘏ")+search
	ITEMS(url)
	return
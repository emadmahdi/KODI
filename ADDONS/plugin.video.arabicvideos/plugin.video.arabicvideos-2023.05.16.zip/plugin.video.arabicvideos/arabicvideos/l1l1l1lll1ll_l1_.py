# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ䏟")
menu_name = l1l11l_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨ䏠")
l11lll_l1_ = WEBSITES[script_name][0]
headers = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䏡"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l111l1_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1l1l1lll1l1_l1_(url)
	elif mode==314: results = l11l11ll_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䏢"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䏣"),l1l11l_l1_ (u"࠭ࠧ䏤"),319,l1l11l_l1_ (u"ࠧࠨ䏥"),l1l11l_l1_ (u"ࠨࠩ䏦"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䏧"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䏨"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สาࠩ䏩"),l1l11l_l1_ (u"ࠬ࠭䏪"),114,l11lll_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䏫"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ䏬"),l1l11l_l1_ (u"ࠨࠩ䏭"),l1l11l_l1_ (u"ࠩࠪ䏮"),l1l11l_l1_ (u"ࠪࠫ䏯"),l1l11l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䏰"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻ࡬ࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䏱"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䏲"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䏳"),l1l11l_l1_ (u"ࠨࠩ䏴"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠩ࠿࡬࠺ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠶ࡀࠪ䏵"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l11l_l1_ (u"ࠪࠤࠬ䏶"))
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䏷"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䏸")+menu_name+title,l11lll_l1_,314,l1l11l_l1_ (u"࠭ࠧ䏹"),l1l11l_l1_ (u"ࠧࠨ䏺"),str(seq+1))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䏻"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䏼")+menu_name+l1l11l_l1_ (u"้ࠪ็อืฺࠢื๋ึ࠭䏽"),l11lll_l1_,314,l1l11l_l1_ (u"ࠫࠬ䏾"),l1l11l_l1_ (u"ࠬ࠭䏿"),l1l11l_l1_ (u"࠭࠰ࠨ䐀"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䐁"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䐂"),l1l11l_l1_ (u"ࠩࠪ䐃"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡈ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡃࡀࠪ䐄"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࠭䐅")+l1111l_l1_
		#title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䐆"))
		#url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡈ࡯࡭ࡢࡐࡲࡻ࠴ࡏ࡮ࡵࡧࡵࡪࡦࡩࡥ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠯ࡲ࡫ࡴࠬ䐇")
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐈"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䐉")+menu_name+title,l1111l_l1_,311)
	return html
def l11l11ll_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䐊"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ䐋"),l1l11l_l1_ (u"ࠫࠬ䐌"),l1l11l_l1_ (u"ࠬ࠭䐍"),l1l11l_l1_ (u"࠭ࠧ䐎"),l1l11l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡐࡆ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ䐏"))
	html = response.content
	if seq==l1l11l_l1_ (u"ࠨ࠲ࠪ䐐"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷࡥࡧ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ䐑"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐒"),block,re.DOTALL)
		for l1111l_l1_,name,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࠭䐓")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䐔"))
			name = name.strip(l1l11l_l1_ (u"࠭ࠠࠨ䐕"))
			title = title+l1l11l_l1_ (u"ࠧࠡࠪࠪ䐖")+name+l1l11l_l1_ (u"ࠨࠫࠪ䐗")
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䐘"),menu_name+title,l1111l_l1_,312)
	elif seq in [l1l11l_l1_ (u"ࠪ࠵ࠬ䐙"),l1l11l_l1_ (u"ࠫ࠷࠭䐚"),l1l11l_l1_ (u"ࠬ࠹ࠧ䐛")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠽ࡪ࠸ࡂ࠳࠰࠿ࠪ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡰ࡬࠭䐜"),html,re.DOTALL)
		l1l1l1lll11l_l1_ = int(seq)-1
		block = l1ll111_l1_[l1l1l1lll11l_l1_]
		if seq==l1l11l_l1_ (u"ࠧ࠲ࠩ䐝"): items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐞"),block,re.DOTALL)
		else: items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐟"),block,re.DOTALL)
		for l1111l_l1_,img,title,name in items:
			img = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࠬ䐠")+img
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࠭䐡")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䐢"))
			name = name.strip(l1l11l_l1_ (u"࠭ࠠࠨ䐣"))
			title = title+l1l11l_l1_ (u"ࠧࠡࠪࠪ䐤")+name+l1l11l_l1_ (u"ࠨࠫࠪ䐥")
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䐦"),menu_name+title,l1111l_l1_,311,img)
	elif seq in [l1l11l_l1_ (u"ࠪ࠸ࠬ䐧"),l1l11l_l1_ (u"ࠫ࠺࠭䐨"),l1l11l_l1_ (u"ࠬ࠼ࠧ䐩")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠽ࡪ࠸ࡂ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ䐪"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1ll111_l1_[seq]
		items = re.findall(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂ࠱ࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐫"),block,re.DOTALL)
		for img,l1111l_l1_,name1,title,name2 in items:
			img = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࠪ䐬")+img
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ䐭")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䐮"))
			name1 = name1.strip(l1l11l_l1_ (u"ࠫࠥ࠭䐯"))
			name2 = name2.strip(l1l11l_l1_ (u"ࠬࠦࠧ䐰"))
			if name1: name = name1
			else: name = name2
			title = title+l1l11l_l1_ (u"࠭ࠠࠩࠩ䐱")+name+l1l11l_l1_ (u"ࠧࠪࠩ䐲")
			addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䐳"),menu_name+title,l1111l_l1_,312,img)
	return
def l111l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䐴"),url,l1l11l_l1_ (u"ࠪࠫ䐵"),l1l11l_l1_ (u"ࠫࠬ䐶"),l1l11l_l1_ (u"ࠬ࠭䐷"),l1l11l_l1_ (u"࠭ࠧ䐸"),l1l11l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䐹"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡥࡳࡽ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡬ࡰࡣࡷ࠱ࡷ࡯ࡧࡩࡶࠪ䐺"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	if l1l11l_l1_ (u"ࠩࡦࡥࡹࡹࡵ࡮࠯ࡰࡳࡧ࡯࡬ࡦࠩ䐻") in block:
		items = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐼"),block,re.DOTALL)
		if items:
			for img,l1111l_l1_,title,count in items:
				img = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࠭䐽")+img
				l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࠧ䐾")+l1111l_l1_
				count = count.replace(l1l11l_l1_ (u"࠭ࠠศๆุ์ฯ๐ษ࠻ࠢࠪ䐿"),l1l11l_l1_ (u"ࠧ࠻ࠩ䑀"))
				title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ䑁"))
				title = title+l1l11l_l1_ (u"ࠩࠣࠬࠬ䑂")+count+l1l11l_l1_ (u"ࠪ࠭ࠬ䑃")
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑄"),menu_name+title,l1111l_l1_,311,img)
	else:
		items = re.findall(l1l11l_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䑅"),block,re.DOTALL)
		for l1111l_l1_,title,l1l1l1llll11_l1_,duration in items:
			if title==l1l11l_l1_ (u"࠭ࠧ䑆") or l1l1l1llll11_l1_==l1l11l_l1_ (u"ࠧࠨ䑇"): continue
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࠪ䑈")+l1111l_l1_
			title = title+l1l11l_l1_ (u"ࠩࠣࠬࠬ䑉")+duration+l1l11l_l1_ (u"ࠪ࠭ࠬ䑊")
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䑋"),menu_name+title,l1111l_l1_,312)
	if not items: l111ll_l1_(html)
	return
def l111ll_l1_(html):
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䑌"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䑍"),block,re.DOTALL)
	for l1111l_l1_,title,name,count,duration in items:
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩ䑎")+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ䑏"))
		name = name.strip(l1l11l_l1_ (u"ࠩࠣࠫ䑐"))
		title = title+l1l11l_l1_ (u"ࠪࠤ࠭࠭䑑")+name+l1l11l_l1_ (u"ࠫ࠮࠭䑒")
		addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䑓"),menu_name+title,l1111l_l1_,312,l1l11l_l1_ (u"࠭ࠧ䑔"),duration)
	return
def l1l1l1lll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䑕"),url,l1l11l_l1_ (u"ࠨࠩ䑖"),l1l11l_l1_ (u"ࠩࠪ䑗"),l1l11l_l1_ (u"ࠪࠫ䑘"),l1l11l_l1_ (u"ࠫࠬ䑙"),l1l11l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈࡠࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䑚"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠥࡶ࠭࠲ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠧ䑛"),html,re.DOTALL)
	if not l1ll111_l1_:
		l111l1_l1_(url)
		return
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䑜"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࠪ䑝")+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䑞"))
		if l1l11l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠯ࠪ䑟") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䑠"),menu_name+title,l1111l_l1_,312)
		else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑡"),menu_name+title,l1111l_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䑢"),url,l1l11l_l1_ (u"ࠧࠨ䑣"),l1l11l_l1_ (u"ࠨࠩ䑤"),l1l11l_l1_ (u"ࠩࠪ䑥"),l1l11l_l1_ (u"ࠪࠫ䑦"),l1l11l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䑧"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡡࡶࡦ࡬ࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䑨"),html,re.DOTALL)
	if not l1111l_l1_: l1111l_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䑩"),html,re.DOTALL)
	l1111l_l1_ = l11lll_l1_+l1111l_l1_[0]
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䑪"))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠨࠩ䑫"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠩࠪ䑬"): return
	search = search.replace(l1l11l_l1_ (u"ࠪࠤࠬ䑭"),l1l11l_l1_ (u"ࠫ࠰࠭䑮"))
	typeList = [l1l11l_l1_ (u"ࠬࠬࡴ࠾ࡣࠪ䑯"),l1l11l_l1_ (u"࠭ࠦࡵ࠿ࡦࠫ䑰"),l1l11l_l1_ (u"ࠧࠧࡶࡀࡷࠬ䑱")]
	if showdialogs:
		searchTitle = [l1l11l_l1_ (u"ࠨไสีห࠭䑲"),l1l11l_l1_ (u"ࠩศูิอัࠡ࠱้ࠣั๊ฯࠨ䑳"),l1l11l_l1_ (u"้ࠪ็฽ูࠡษ็ูํะ๊ࠨ䑴")]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦ࠭ࠡลัฮึࠦวๅสะฯࠬ䑵"), searchTitle)
		if selection == -1: return
	elif l1l11l_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࡢࠫ䑶") in options: selection = 0
	elif l1l11l_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࡢࠫ䑷") in options: selection = 1
	elif l1l11l_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࡣࠬ䑸") in options: selection = 2
	else: return
	type = typeList[selection]
	url = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࡱ࠾ࠩ䑹")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䑺"),url,l1l11l_l1_ (u"ࠪࠫ䑻"),l1l11l_l1_ (u"ࠫࠬ䑼"),l1l11l_l1_ (u"ࠬ࠭䑽"),l1l11l_l1_ (u"࠭ࠧ䑾"),l1l11l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䑿"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ䒀"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		if selection in [0,1]:
			items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䒁"),block,re.DOTALL)
			for l1111l_l1_,img,title,name in items:
				title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䒂"))
				name = name.strip(l1l11l_l1_ (u"ࠫࠥ࠭䒃"))
				title = title+l1l11l_l1_ (u"ࠬࠦࠨࠨ䒄")+name+l1l11l_l1_ (u"࠭ࠩࠨ䒅")
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䒆"),menu_name+title,l1111l_l1_,313,img)
		elif selection==2:
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯ࡵࡦࡁࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䒇"),block,re.DOTALL)
			for l1111l_l1_,title,name in items:
				title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䒈"))
				name = name.strip(l1l11l_l1_ (u"ࠪࠤࠬ䒉"))
				title = title+l1l11l_l1_ (u"ࠫࠥ࠮ࠧ䒊")+name+l1l11l_l1_ (u"ࠬ࠯ࠧ䒋")
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䒌"),menu_name+title,l1111l_l1_,312)
	return
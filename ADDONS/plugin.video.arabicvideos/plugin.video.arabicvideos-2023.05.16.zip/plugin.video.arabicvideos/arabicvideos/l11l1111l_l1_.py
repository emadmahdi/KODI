# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩኡ")
headers = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧኢ"):l1l11l_l1_ (u"ࠫࠬኣ")}
menu_name = l1l11l_l1_ (u"ࠬࡥࡃ࠵ࡗࡢࠫኤ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪእ"),l1l11l_l1_ (u"ࠧศะิ๎ࠬኦ"),l1l11l_l1_ (u"ࠨษัี๎࠭ኧ"),l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫከ"),l1l11l_l1_ (u"ࠪฬิ๎ๆࠡวัฮ๏อัࠨኩ"),l1l11l_l1_ (u"ࠫฬ็ไศ็ࠪኪ"),l1l11l_l1_ (u"๋ࠬำๅี็หฯ࠭ካ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l111l1_l1_(url,text)
	elif mode==422: results = l1111l1l1_l1_(url)
	elif mode==423: results = l111ll_l1_(url)
	elif mode==424: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬኬ")+text)
	elif mode==425: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ክ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l111ll1l1_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1111lll1_l1_(l1l11l_l1_ (u"ࠨࡉࡈࡘࠬኮ"),l11lll_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪኯ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧኰ"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ኱"),l1l11l_l1_ (u"ࠬ࠭ኲ"),l1l11l_l1_ (u"࠭ࠧኳ"),l1l11l_l1_ (u"ࠧࠨኴ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪኵ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ኶"),html,re.DOTALL)
	l111l11l1_l1_ = l111l11l1_l1_[0].strip(l1l11l_l1_ (u"ࠪ࠳ࠬ኷"))
	l111l11l1_l1_ = SERVER(l111l11l1_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨኸ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኹ"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ኺ"),l1l11l_l1_ (u"ࠧࠨኻ"),429,l1l11l_l1_ (u"ࠨࠩኼ"),l1l11l_l1_ (u"ࠩࠪኽ"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧኾ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ኿"),menu_name+l1l11l_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨዀ"),l111l11l1_l1_,425)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭዁"),menu_name+l1l11l_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪዂ"),l111l11l1_l1_,424)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ዃ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩዄ"),l1l11l_l1_ (u"ࠪࠫዅ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ዆"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ዇")+menu_name+l1l11l_l1_ (u"࠭วๅำษ๎ุ๐ษࠨወ"),l111l11l1_l1_,421)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዉ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪዊ")+menu_name+l1l11l_l1_ (u"ࠩฦๅ้อๅࠡษ็๊ั๎ๅࠨዋ"),l111l11l1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶ࠳ࠬዌ"),421)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫው"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧዎ")+menu_name+l1l11l_l1_ (u"࠭ๆ๋ฬไู่่ࠧዏ"),l111l11l1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡰࡨࡸ࡫ࡲࡩࡹ࠱ࠪዐ"),421)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ዑ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬࡁࠬ࠳࠰࠿ࠪ࠾ࠪዒ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶࠫዓ") in l1111l_l1_: title = l1l11l_l1_ (u"ࠫศ็ไศ็ࠣห้์ฬ้็ࠪዔ")
		elif l1l11l_l1_ (u"ࠬ࠵࡮ࡦࡶࡩࡰ࡮ࡾࠧዕ") in l1111l_l1_: title = l1l11l_l1_ (u"࠭รโๆส้ࠥ๎ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨዖ")
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ዗"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪዘ")+menu_name+title,l1111l_l1_,421)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዙ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬዚ")+menu_name+l1l11l_l1_ (u"ࠫ็อฦๆหࠣฮๆ฻๊ๅ์ฬࠫዛ"),l111l11l1_l1_,427)
	return
def l111ll1l1_l1_(website=l1l11l_l1_ (u"ࠬ࠭ዜ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪዝ"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨዞ"),l1l11l_l1_ (u"ࠨࠩዟ"),l1l11l_l1_ (u"ࠩࠪዠ"),l1l11l_l1_ (u"ࠪࠫዡ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ዢ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡕ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ዣ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪࠤ࠭ࠤࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠭ࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿ࠫዤ"),block,re.DOTALL)
	for category,id,l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸ࠮࡯ࡲࡺ࡮࡫ࡳࠨዥ") in l1111l_l1_: title = l1l11l_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨዦ")
		elif l1l11l_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴ࠯ࡱࡩࡹ࡬࡬ࡪࡺࠪዧ") in l1111l_l1_: title = l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬየ")
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዩ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧዪ")+menu_name+title,l1111l_l1_,421,l1l11l_l1_ (u"࠭ࠧያ"),l1l11l_l1_ (u"ࠧࠨዬ"),category+l1l11l_l1_ (u"ࠨࡾࠪይ")+id)
	return
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"ࠩࠪዮ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫዯ"),l1l11l_l1_ (u"ࠫࠬደ"),l11l11111_l1_,url)
	if l1l11l_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨዱ") in url: url = url.strip(l1l11l_l1_ (u"࠭࠯ࠨዲ"))+l1l11l_l1_ (u"ࠧ࠰࡯ࡳࡥࡦ࠵ࡦࡢ࡯࡬ࡰࡾ࠵ࠧዳ")
	items = []
	l111l11l1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬዴ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ድ"),url,l1l11l_l1_ (u"ࠪࠫዶ"),headers,l1l11l_l1_ (u"ࠫࠬዷ"),l1l11l_l1_ (u"ࠬ࠭ዸ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪዹ"))
	html = response.content
	if not l11l11111_l1_ or l1l11l_l1_ (u"ࠧࡽࠩዺ") in l11l11111_l1_:
		#if l1l11l_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠭ዻ") in html:
		#	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዼ"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ዽ"),url,425)
		#	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዾ"),menu_name+l1l11l_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨዿ"),url,424)
		#	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫጀ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧጁ"),l1l11l_l1_ (u"ࠨࠩጂ"),9999)
		if l1l11l_l1_ (u"ࠩࡿࠫጃ") not in l11l11111_l1_: l111ll11l_l1_ = l1l11l_l1_ (u"ࠪࠫጄ")
		else: l111ll11l_l1_ = l1l11l_l1_ (u"ࠫ࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠵ࠧጅ")+l11l11111_l1_
		l1111l1ll_l1_ = False
		if l1l11l_l1_ (u"ࠬࡖࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠨጆ") in html:
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ጇ"),menu_name+l1l11l_l1_ (u"ࠧศๆ่้๏ุษࠨገ"),url,421,l1l11l_l1_ (u"ࠨࠩጉ"),l1l11l_l1_ (u"ࠩࠪጊ"),l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬጋ"))
			l1111l1ll_l1_ = True
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠩጌ"),html,re.DOTALL)
		if l1ll111_l1_:
			l1l11l1l_l1_ = l1ll111_l1_[0]
			l1l111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡨ࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫግ"),l1l11l1l_l1_,re.DOTALL)
			for l111l1lll_l1_,title2 in l1l111l1l_l1_:
				l111l1ll1_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡨ࡫࡮ࡵࡧࡵ࠳ࡦࡩࡴࡪࡱࡱ࠳ࡍࡵ࡭ࡦࡲࡤ࡫ࡪࡒ࡯ࡢࡦࡨࡶ࠴ࡺࡡࡣ࠱ࠪጎ")+l111l1lll_l1_+l111ll11l_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩጏ")
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጐ"),menu_name+title2,l111l1ll1_l1_,421)
				l1111l1ll_l1_ = True
		if l1111l1ll_l1_: addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ጑"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪጒ"),l1l11l_l1_ (u"ࠫࠬጓ"),9999)
	if l11l11111_l1_==l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧጔ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡍࡶ࡮ࡷ࡭ࡋ࡯࡬ࡵࡧࡵࠫጕ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡑ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪ጖"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		else: block = l1l11l_l1_ (u"ࠨࠩ጗")
	elif l1l11l_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬጘ") in url or l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡧࡪࡴࡴࡦࡴ࠲ࠫጙ") in url:
		block = html
	elif l1l11l_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭ጚ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡖࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠫࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠰ࠧጛ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	elif l1l11l_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷࡹࠧጜ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࠭ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠫࠩጝ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠯࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫጞ"),block,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡆ࡭ࡲࡧ࠴ࡶࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩጟ"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		else: block = l1l11l_l1_ (u"ࠪࠫጠ")
	if not items: items = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࠯ࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠭࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠲࠯ࡅࡂࡰࡺࡗ࡭ࡹࡲࡥࡊࡰࡩࡳ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀࠬጡ"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫጢ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for l1111l_l1_,img,title in items:
		if not title: continue
		if l1l11l_l1_ (u"࠭࠿࡯ࡧࡺࡷࡂ࠭ጣ") in l1111l_l1_: continue
		title = title.replace(l1l11l_l1_ (u"ࠧๆึส๋ิฯࠠࠨጤ"),l1l11l_l1_ (u"ࠨࠩጥ"))
		title = unescapeHTML(title)
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪጦ"),title,re.DOTALL)
		if l1ll1ll_l1_ and l1l11l_l1_ (u"ࠪั้่ษࠨጧ") in title:
			title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪጨ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬጩ"),menu_name+title,l1111l_l1_,422,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠵ࠧጪ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧጫ"),menu_name+title,l1111l_l1_,421,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጬ"),menu_name+title,l1111l_l1_,422,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩጭ"),html,re.DOTALL)
	if l1ll111_l1_ and l11l11111_l1_!=l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬጮ"):
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࡠࠬࡢࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩ࡟ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ጯ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠬอไึใะอࠥ࠭ጰ"),l1l11l_l1_ (u"࠭ࠧጱ"))
			if title!=l1l11l_l1_ (u"ࠧࠨጲ"): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጳ"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨጴ")+title,l1111l_l1_,421)
	l111lll11_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀ࠴ࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ጵ"),html,re.DOTALL)
	if l111lll11_l1_:
		l1111l_l1_,title = l111lll11_l1_[0]
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጶ"),menu_name+title,l1111l_l1_,421)
	return
def l1111l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩጷ"),url,l1l11l_l1_ (u"࠭ࠧጸ"),l1l11l_l1_ (u"ࠧࠨጹ"),l1l11l_l1_ (u"ࠨࠩጺ"),l1l11l_l1_ (u"ࠩࠪጻ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨጼ"))
	html = response.content
	# l1l1l1111_l1_/download main l1l1ll1l_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡑࡳࡼࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨጽ"),html,re.DOTALL)
	if l1ll111_l1_:
		url = l1ll111_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩጾ"),url,l1l11l_l1_ (u"࠭ࠧጿ"),l1l11l_l1_ (u"ࠧࠨፀ"),l1l11l_l1_ (u"ࠨࠩፁ"),l1l11l_l1_ (u"ࠩࠪፂ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠷ࡴࡤࠨፃ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩፄ"),l1l11l_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬፅ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡓࡦࡣࡶࡳࡳࡹࡓࡦࡥࡷ࡭ࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪፆ"),html,re.DOTALL)
	# l1111ll11_l1_ l111ll111_l1_
	if l1l11l_l1_ (u"ࠧ࠰ࡶࡤ࡫࠴࠭ፇ") in url or l1l11l_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࠨፈ") in url:
		l111l1_l1_(url)
	# l111l111l_l1_
	elif l1ll111_l1_:
		img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪፉ"))
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤፊ"),block,re.DOTALL)
		l1111llll_l1_ = [l1l11l_l1_ (u"ู๊ࠫไิๆࠪፋ"),l1l11l_l1_ (u"๋่ࠬิ็ࠪፌ"),l1l11l_l1_ (u"࠭ศา่ส้ั࠭ፍ"),l1l11l_l1_ (u"ࠧฮๆๅอࠬፎ")]
		for l1111l_l1_,title in items:
			if any(value in title for value in l1111llll_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨፏ"),menu_name+title,l1111l_l1_,423,img)
			else: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨፐ"),menu_name+title,l1111l_l1_,426,img)
	else: l111ll_l1_(url)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧፑ"),url,l1l11l_l1_ (u"ࠫࠬፒ"),l1l11l_l1_ (u"ࠬ࠭ፓ"),l1l11l_l1_ (u"࠭ࠧፔ"),l1l11l_l1_ (u"ࠧࠨፕ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧፖ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧፗ"),l1l11l_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪፘ"))
	img = re.findall(l1l11l_l1_ (u"ࠫࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧፙ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = l1l11l_l1_ (u"ࠬ࠭ፚ")
	# l1l11l1_l1_
	l1ll1l1l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡔࡧࡦࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ፛"),html,re.DOTALL)
	if l1ll1l1l1_l1_:
		block = l1ll1l1l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ፜"),block,re.DOTALL)
		for l1111l_l1_,title,l1ll1ll_l1_ in items:
			title = title+l1l11l_l1_ (u"ࠨࠢࠪ፝")+l1ll1ll_l1_
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ፞"),menu_name+title,l1111l_l1_,426,img)
	else: addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ፟"),menu_name+l1l11l_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪ፠"),url,426,img)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ፡"),url,l1l11l_l1_ (u"࠭ࠧ።"),headers,l1l11l_l1_ (u"ࠧࠨ፣"),l1l11l_l1_ (u"ࠨࠩ፤"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ፥"))
	html = response.content
	#newurl = re.findall(l1l11l_l1_ (u"ࠪࠦࡸࡺࡹ࡭ࡧࡶ࡬ࡪ࡫ࡴࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ፦"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ፧"))
	l111l11l1_l1_ = SERVER(newurl,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ፨"))
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	#if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ፩"),l1l11l_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ፪"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡙ࡤࡸࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ፫"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠢࠡ࠱ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ፬"),block,re.DOTALL)
		for l1lll11l_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ፭"))
			if l1l11l_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪ፮") in title.lower(): title = l1l11l_l1_ (u"ࠬิวึࠢࠪ፯")+title
			l1111l_l1_ = l111l11l1_l1_+l1l11l_l1_ (u"࠭࠯ࡴࡶࡵࡹࡨࡺࡵࡳࡧ࠲ࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ፰")+l1lll11l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ፱")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ፲")
			#l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡢ࠶ࡸ࠲࡮ࡩࡵࠨ፳"),l1l11l_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷ࠱ࡱࡽ࠭፴"))
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ፵"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦࠧࠦ࠯࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ፶"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨ፷"))
			if l1l11l_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭፸") in title.lower(): title2 = l1l11l_l1_ (u"ࠨࡡࡢาฬ฻ࠧ፹")
			else: title2 = l1l11l_l1_ (u"ࠩࠪ፺")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ፻")+title+l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ፼")+title2
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ፽"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ፾"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠧࠨ፿"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠨࠩᎀ"): return
	search = search.replace(l1l11l_l1_ (u"ࠩࠣࠫᎁ"),l1l11l_l1_ (u"ࠪ࠯ࠬᎂ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭ᎃ")+search+l1l11l_l1_ (u"ࠬ࠵ࠧᎄ")
	l111l1_l1_(url,l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᎅ"))
	return
# ===========================================
#     l111lllll_l1_ l111l1111_l1_ l1111ll1l_l1_
# ===========================================
def l111llll1_l1_(url):
	if l1l11l_l1_ (u"ࠧࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩᎆ") not in url: url = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᎇ"))
	else: url = url.split(l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᎈ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᎉ"),url,l1l11l_l1_ (u"ࠫࠬᎊ"),l1l11l_l1_ (u"ࠬ࠭ᎋ"),l1l11l_l1_ (u"࠭ࠧᎌ"),l1l11l_l1_ (u"ࠧࠨᎍ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪᎎ"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᎏ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + options block + category
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡌࡴࡼࡥࡳࡣࡥࡰࡪ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࠤࡤࡰࡱࠨ࠮ࠫࡁࠫࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᎐"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111l11ll_l1_(block):
	# id + title
	items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᎑"),block,re.DOTALL)
	return items
def l111ll1ll_l1_(url):
	l111l1l1l_l1_ = url.split(l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ᎒"))[0]
	l111l1l11_l1_ = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ᎓"))
	url = url.replace(l111l1l1l_l1_,l111l1l11_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ᎔"),l1l11l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨ᎕"))
	url = url.replace(l1l11l_l1_ (u"ࠩࡀࠫ᎖"),l1l11l_l1_ (u"ࠪ࠳ࠬ᎗")).replace(l1l11l_l1_ (u"ࠫࠫ࠭᎘"),l1l11l_l1_ (u"ࠬ࠵ࠧ᎙"))
	url = url+l1l11l_l1_ (u"࠭࠯ࠨ᎚")
	return url
l111111_l1_ = [l1l11l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ᎛"),l1l11l_l1_ (u"ࠨࡶࡼࡴࡪࡹࠧ᎜"),l1l11l_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ᎝")]
l11ll1l_l1_ = [l1l11l_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫ᎞"),l1l11l_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ᎟"),l1l11l_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᎠ"),l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᎡ")]
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᎢ"),l1l11l_l1_ (u"ࠨࠩᎣ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᎤ"),l1l11l_l1_ (u"ࠪࠫᎥ"),filter,url)
	if l1l11l_l1_ (u"ࠫࡄ࠭Ꭶ") in url: url = url.split(l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᎧ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"࠭࡟ࡠࡡࠪᎨ"),1)
	if filter==l1l11l_l1_ (u"ࠧࠨᎩ"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠨࠩᎪ"),l1l11l_l1_ (u"ࠩࠪᎫ")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᎬ"))
	if type==l1l11l_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᎭ"):
		if l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᎮ") in url:
			global l111111_l1_
			l111111_l1_ = l111111_l1_[1:]
		if l111111_l1_[0]+l1l11l_l1_ (u"࠭࠽ࠨᎯ") not in l1lllll1_l1_: category = l111111_l1_[0]
		for i in range(len(l111111_l1_[0:-1])):
			if l111111_l1_[i]+l1l11l_l1_ (u"ࠧ࠾ࠩᎰ") in l1lllll1_l1_: category = l111111_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠨࠨࠪᎱ")+category+l1l11l_l1_ (u"ࠩࡀ࠴ࠬᎲ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠪࠪࠬᎳ")+category+l1l11l_l1_ (u"ࠫࡂ࠶ࠧᎴ")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧᎵ"))+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪᎶ")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠩᎷ"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᎸ"))
		url2 = url+l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ꮉ")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭Ꮊ"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭Ꮋ"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠬ࠭Ꮌ"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᎽ"))
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠧࠨᎾ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᎿ")+l1llll1l_l1_
		url2 = l111ll1ll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏀ"),menu_name+l1l11l_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭Ꮑ"),url2,421,l1l11l_l1_ (u"ࠫࠬᏂ"),l1l11l_l1_ (u"ࠬ࠭Ꮓ"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭Ꮔ"))
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏅ"),menu_name+l1l11l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨᏆ")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨᏇ"),url2,421,l1l11l_l1_ (u"ࠪࠫᏈ"),l1l11l_l1_ (u"ࠫࠬᏉ"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᏊ"))
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᏋ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᏌ"),l1l11l_l1_ (u"ࠨࠩᏍ"),9999)
	l1l1ll1_l1_ = l111llll1_l1_(url)
	dict = {}
	for name,block,l1l111l_l1_ in l1l1ll1_l1_:
		if l1l11l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭Ꮞ") in url and l1l111l_l1_==l1l11l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᏏ"): continue
		name = name.replace(l1l11l_l1_ (u"ࠫ࠲࠳ࠧᏐ"),l1l11l_l1_ (u"ࠬ࠭Ꮡ"))
		items = l111l11ll_l1_(block)
		if l1l11l_l1_ (u"࠭࠽ࠨᏒ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᏓ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l111111_l1_[-1]:
					url = l111ll1ll_l1_(url)
					l111l1_l1_(url)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧᏔ")+l1111l1_l1_)
				return
			else:
				url2 = l111ll1ll_l1_(url2)
				if l1l111l_l1_==l111111_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏕ"),menu_name+l1l11l_l1_ (u"ࠪห้าๅ๋฻ࠪᏖ"),url2,421,l1l11l_l1_ (u"ࠫࠬᏗ"),l1l11l_l1_ (u"ࠬ࠭Ꮨ"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭Ꮩ"))
				else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏚ"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ูࠨᏛ"),url2,425,l1l11l_l1_ (u"ࠩࠪᏜ"),l1l11l_l1_ (u"ࠪࠫᏝ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧᏞ"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠬࠬࠧᏟ")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽࠱ࠩᏠ")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠧࠧࠩᏡ")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿࠳ࠫᏢ")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭Ꮳ")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏤ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭Ꮵ")+name,url2,424,l1l11l_l1_ (u"ࠬ࠭Ꮶ"),l1l11l_l1_ (u"࠭ࠧᏧ"),l1111l1_l1_)		# +l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᏨ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if value==l1l11l_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨᏩ"): option = l1l11l_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩᏪ")
			elif value==l1l11l_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪᏫ"): option = l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭Ꮼ")
			if option in l1llll1_l1_: continue
			#if l1l11l_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᏭ") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧᏮ"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠧࠧࠩᏯ")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿ࠪᏰ")+option
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠩࠩࠫᏱ")+l1l111l_l1_+l1l11l_l1_ (u"ࠪࡁࠬᏲ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᏳ")+l11l111_l1_
			title = option+l1l11l_l1_ (u"ࠬࠦ࠺ࠨᏴ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"࠭࠰ࠨᏵ")]
			title = option+l1l11l_l1_ (u"ࠧࠡ࠼ࠪ᏶")+name
			if type==l1l11l_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ᏷"): addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏸ"),menu_name+title,url,424,l1l11l_l1_ (u"ࠪࠫᏹ"),l1l11l_l1_ (u"ࠫࠬᏺ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᏻ"))
			elif type==l1l11l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᏼ") and l111111_l1_[-2]+l1l11l_l1_ (u"ࠧ࠾ࠩᏽ") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ᏾"))
				url3 = url+l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭᏿")+l1lll1l1_l1_
				url3 = l111ll1ll_l1_(url3)
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᐀"),menu_name+title,url3,421,l1l11l_l1_ (u"ࠫࠬᐁ"),l1l11l_l1_ (u"ࠬ࠭ᐂ"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᐃ"))
			else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐄ"),menu_name+title,url,425,l1l11l_l1_ (u"ࠨࠩᐅ"),l1l11l_l1_ (u"ࠩࠪᐆ"),l1l1111_l1_)
	return
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᐇ"),l1l11l_l1_ (u"ࠫࠬᐈ"),filters,l1l11l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭ᐉ"))
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᐊ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᐋ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠨࡣ࡯ࡰࠬᐌ")					all l111l1l_l1_ & l111lll1l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠩࡀࠪࠬᐍ"),l1l11l_l1_ (u"ࠪࡁ࠵ࠬࠧᐎ"))
	filters = filters.strip(l1l11l_l1_ (u"ࠫࠫ࠭ᐏ"))
	l1llllll_l1_ = {}
	if l1l11l_l1_ (u"ࠬࡃࠧᐐ") in filters:
		items = filters.split(l1l11l_l1_ (u"࠭ࠦࠨᐑ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠧ࠾ࠩᐒ"))
			l1llllll_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠨࠩᐓ")
	for key in l11ll1l_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠩ࠳ࠫᐔ")
		if l1l11l_l1_ (u"ࠪࠩࠬᐕ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᐖ") and value!=l1l11l_l1_ (u"ࠬ࠶ࠧᐗ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠠࠬࠢࠪᐘ")+value
		elif mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᐙ") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪᐚ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠩࠫᐛ")+key+l1l11l_l1_ (u"ࠪࡁࠬᐜ")+value
		elif mode==l1l11l_l1_ (u"ࠫࡦࡲ࡬ࠨᐝ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠧᐞ")+key+l1l11l_l1_ (u"࠭࠽ࠨᐟ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠡ࠭ࠣࠫᐠ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠪᐡ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠩࡀ࠴ࠬᐢ"),l1l11l_l1_ (u"ࠪࡁࠬᐣ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬᐤ"),l1l11l_l1_ (u"ࠬ࠭ᐥ"),filters,l1l11l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᐦ"))
	return l11llll_l1_
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ⡣")
menu_name = l1l11l_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧ⡤")
l11lll_l1_ = WEBSITES[script_name][0]
headers = {l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⡥"):l1l11l_l1_ (u"ࠪࠫ⡦")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l111l1_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⡧"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⡨"),l1l11l_l1_ (u"࠭ࠧ⡩"),329,l1l11l_l1_ (u"ࠧࠨ⡪"),l1l11l_l1_ (u"ࠨࠩ⡫"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⡬"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⡭"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⡮"),l1l11l_l1_ (u"ࠬ࠭⡯"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ⡰"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ⡱"),l1l11l_l1_ (u"ࠨࠩ⡲"),headers,l1l11l_l1_ (u"ࠩࠪ⡳"),l1l11l_l1_ (u"ࠪࠫ⡴"),l1l11l_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⡵"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰࡲ࠱ࡵࡲࡵࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⡶"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⡷"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title==l1l11l_l1_ (u"ࠧศๆ่็ฯฮษࠡษ็้ึฬ๊สࠩ⡸"): continue
		l1111l_l1_ = l11lll_l1_+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡹"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⡺")+menu_name+title,l1111l_l1_,321)
	return html
def l111l1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⡻"),l1l11l_l1_ (u"ࠫࠬ⡼"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⡽"),url,l1l11l_l1_ (u"࠭ࠧ⡾"),headers,l1l11l_l1_ (u"ࠧࠨ⡿"),l1l11l_l1_ (u"ࠨࠩ⢀"),l1l11l_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⢁"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ⢂"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡰࡥ࠷ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢃"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⢄"),block,re.DOTALL)
	for l1111l_l1_,img,count,title in items:
		count = count.replace(l1l11l_l1_ (u"ู࠭ะัࠣࠫ⢅"),l1l11l_l1_ (u"ࠧࠨ⢆")).replace(l1l11l_l1_ (u"ࠨࠢࠪ⢇"),l1l11l_l1_ (u"ࠩࠪ⢈"))
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠪ࠳ࠬ⢉"),l1l11l_l1_ (u"ࠫࠬ⢊"))
		img = img.replace(l1l11l_l1_ (u"ࠧ࠭ࠢ⢋"),l1l11l_l1_ (u"࠭ࠧ⢌"))
		if l1l11l_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬ⢍") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ⢎")+l1111l_l1_
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ⢏")+l1111l_l1_
		img = l11lll_l1_+img
		title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ⢐"))
		title = title+l1l11l_l1_ (u"ࠫࠥ࠮ࠧ⢑")+count+l1l11l_l1_ (u"ࠬ࠯ࠧ⢒")
		if l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⢓") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢔"),menu_name+title,l1111l_l1_,321,img)
		elif l1l11l_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ⢕") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⢖"),menu_name+title,l1111l_l1_,322,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ⢗"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⢘"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⢙")+l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢚"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥ࠭⢛")+title,l1111l_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⢜"),url,l1l11l_l1_ (u"ࠩࠪ⢝"),headers,l1l11l_l1_ (u"ࠪࠫ⢞"),l1l11l_l1_ (u"ࠫࠬ⢟"),l1l11l_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⢠"))
	html = response.content
	#l1111l_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⢡"),html,re.DOTALL)
	#if not l1111l_l1_:
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⢢"),html,re.DOTALL)
	l1111l_l1_ = l11lll_l1_+l1111l_l1_[0]#+l1l11l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ⢣")+l1ll1111l_l1_()+l1l11l_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡵࡴࡸࡩࠬ⢤")
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⢥"))
	return
def SEARCH(search):
	#search = l1l11l_l1_ (u"๊ࠫิสศำࠪ⢦")
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭⢧"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧ⢨"): return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩ⢩"),l1l11l_l1_ (u"ࠨ࠭ࠪ⢪"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ⢫")+search
	l111l1_l1_(url)
	return
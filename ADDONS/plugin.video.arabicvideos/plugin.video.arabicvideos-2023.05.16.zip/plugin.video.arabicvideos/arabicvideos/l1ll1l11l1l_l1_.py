# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ⩆")
menu_name = l1l11l_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧ⩇")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ⩈"),l1l11l_l1_ (u"ࠪหุะแิษิฮ่๋้ࠠࠢส่฼๊ศศฬࠪ⩉")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l111l1_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1111l1l1_l1_(url)
	elif mode==454: results = l111ll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ⩊"),l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭⩋"),l1l11l_l1_ (u"࠭ࠧ⩌"),l1l11l_l1_ (u"ࠧࠨ⩍"),l1l11l_l1_ (u"ࠨࠩ⩎"),l1l11l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⩏"))
	html = response.content
	l111l11l1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ⩐"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩑"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⩒"),l1l11l_l1_ (u"࠭ࠧ⩓"),459,l1l11l_l1_ (u"ࠧࠨ⩔"),l1l11l_l1_ (u"ࠨࠩ⩕"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⩖"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⩗"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⩘")+menu_name+l1l11l_l1_ (u"๋ࠬหษฬสฮ๊่ࠥะ์๊ࠣฯ࠭⩙"),l111l11l1_l1_,451,l1l11l_l1_ (u"࠭ࠧ⩚"),l1l11l_l1_ (u"ࠧࠨ⩛"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⩜"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩝"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⩞")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ⩟"),l111l11l1_l1_,451,l1l11l_l1_ (u"ࠬ࠭⩠"),l1l11l_l1_ (u"࠭ࠧ⩡"),l1l11l_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⩢"))
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩣"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⩤")+menu_name+l1l11l_l1_ (u"้๊ࠪัไ๋่ࠪ⩥"),l111l11l1_l1_,451,l1l11l_l1_ (u"ࠫࠬ⩦"),l1l11l_l1_ (u"ࠬ࠭⩧"),l1l11l_l1_ (u"࠭ࡡࡤࡶࡲࡶࡸ࠭⩨"))
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⩩"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⩪")+menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬ๋๋ࠣี๊สࠩ⩫"),l111l11l1_l1_,451,l1l11l_l1_ (u"ࠪࠫ⩬"),l1l11l_l1_ (u"ࠫࠬ⩭"),l1l11l_l1_ (u"ࠬ࠶ࠧ⩮"))
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⩯"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⩰")+menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วห๊๊ࠢิ๐ษࠡ็าฬ้าษࠨ⩱"),l111l11l1_l1_,451,l1l11l_l1_ (u"ࠩࠪ⩲"),l1l11l_l1_ (u"ࠪࠫ⩳"),l1l11l_l1_ (u"ࠫ࠶࠭⩴"))
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⩵"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⩶")+menu_name+l1l11l_l1_ (u"ࠧศใ็ห๊ࠦ็็ัํอࠬ⩷"),l111l11l1_l1_,451,l1l11l_l1_ (u"ࠨࠩ⩸"),l1l11l_l1_ (u"ࠩࠪ⩹"),l1l11l_l1_ (u"ࠪ࠶ࠬ⩺"))
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⩻"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⩼"),l1l11l_l1_ (u"࠭ࠧ⩽"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡏࡤ࡭ࡳࡓࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࠤࡖ࡭ࡹ࡫ࡓ࡭࡫ࡧࡩࡷࠨࠧ⩾"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⩿"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1111l_l1_==l1l11l_l1_ (u"ࠩࠦࠫ⪀"): continue
			if title in l1llll1_l1_: continue
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪁"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⪂")+menu_name+title,l1111l_l1_,451)
	return
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"ࠬ࠭⪃")):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⪄"),l1l11l_l1_ (u"ࠧࠨ⪅"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⪆"),url,l1l11l_l1_ (u"ࠩࠪ⪇"),l1l11l_l1_ (u"ࠪࠫ⪈"),l1l11l_l1_ (u"ࠫࠬ⪉"),l1l11l_l1_ (u"ࠬ࠭⪊"),l1l11l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⪋"))
	html = response.content
	if l11l11111_l1_==l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⪌"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡖ࡭ࡹ࡫ࡓ࡭࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡽࡡࡷࡧࡶࠦࠬ⪍"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	elif l11l11111_l1_==l1l11l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ⪎"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡗ࡫ࡣࡦࡰࡷࡔࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭⪏"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	elif l1l11l_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠪ⪐") in html:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷࡩࡽࡺ࠯࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠦࠬ⪑"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࠥࡅࡨࡺ࡯ࡳࡐࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⪒"),block,re.DOTALL)
	elif l11l11111_l1_ in [l1l11l_l1_ (u"ࠧ࠱ࠩ⪓"),l1l11l_l1_ (u"ࠨ࠳ࠪ⪔"),l1l11l_l1_ (u"ࠩ࠵ࠫ⪕")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡘ࡫ࡣࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄࠧ⪖"),html,re.DOTALL)
		block = l1ll111_l1_[int(l11l11111_l1_)]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ⪗"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ⪘"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11111ll1_l1_ = [l1l11l_l1_ (u"࠭ๅีษ๊ำฮ࠭⪙"),l1l11l_l1_ (u"ࠧโ์็้ࠬ⪚"),l1l11l_l1_ (u"ࠨษ฽๊๏ฯࠧ⪛"),l1l11l_l1_ (u"ࠩฦ฾๋๐ษࠨ⪜"),l1l11l_l1_ (u"ࠪ็้๐ศࠨ⪝"),l1l11l_l1_ (u"ࠫฬ฿ไศ่ࠪ⪞"),l1l11l_l1_ (u"ࠬํฯศใࠪ⪟"),l1l11l_l1_ (u"࠭ๅษษิหฮ࠭⪠"),l1l11l_l1_ (u"ฺࠧำูࠫ⪡"),l1l11l_l1_ (u"ࠨ็๊ีัอๆࠨ⪢"),l1l11l_l1_ (u"ࠩส่อ๎ๅࠨ⪣")]
	for l1111l_l1_,img,title in items:
		if l1l11l_l1_ (u"ࠪࠦࡆࡩࡴࡰࡴࡶࡐ࡮ࡹࡴࠣࠩ⪤") in html and l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠩ⪥") in img:
			img = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⪦"),img,re.DOTALL)
			img = img[0]
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"࠭࠯ࠨ⪧"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ⪨"),title,re.DOTALL)
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ⪩"),title,re.DOTALL)
		#if any(value in title for value in l11111ll1_l1_):
		if set(title.split()) & set(l11111ll1_l1_) and l1l11l_l1_ (u"่ࠩืู้ไࠨ⪪") not in title:
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⪫"),menu_name+title,l1111l_l1_,452,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠫา๊โสࠩ⪬") in title:
			title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⪭") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⪮"),menu_name+title,l1111l_l1_,453,img)
				l1l1l11_l1_.append(title)
		else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⪯"),menu_name+title,l1111l_l1_,453,img)
	if l11l11111_l1_ in [l1l11l_l1_ (u"ࠨࠩ⪰"),l1l11l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ⪱")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⪲"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⪳"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				#if l1111l_l1_==l1l11l_l1_ (u"ࠧࠨ⪴"): continue
				title = unescapeHTML(title)
				#if title!=l1l11l_l1_ (u"࠭ࠧ⪵"):
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⪶"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧ⪷")+title,l1111l_l1_,451)
	return
def l1111l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⪸"),url,l1l11l_l1_ (u"ࠪࠫ⪹"),l1l11l_l1_ (u"ࠫࠬ⪺"),l1l11l_l1_ (u"ࠬ࠭⪻"),l1l11l_l1_ (u"࠭ࠧ⪼"),l1l11l_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⪽"))
	html = response.content
	# l111l111l_l1_
	l11111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡆࡥࡹ࡫ࡧࡰࡴࡼࡗࡺࡨࡌࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⪾"),html,re.DOTALL)
	if l11111l1l_l1_ and l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠨ⪿") in str(l11111l1l_l1_):
		title = re.findall(l1l11l_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠯ࠪ⫀"),html,re.DOTALL)
		title = title[0].strip(l1l11l_l1_ (u"ࠫࠥ࠭⫁"))
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⫂"),menu_name+title,url,454)
		block = l11111l1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⫃"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⫄"),menu_name+title,l1111l_l1_,454)
	else: l111ll_l1_(url)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⫅"),url,l1l11l_l1_ (u"ࠩࠪ⫆"),l1l11l_l1_ (u"ࠪࠫ⫇"),l1l11l_l1_ (u"ࠫࠬ⫈"),l1l11l_l1_ (u"ࠬ࠭⫉"),l1l11l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⫊"))
	html = response.content
	# l1l11l1_l1_
	l1ll1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ⫋"),html,re.DOTALL)
	if l1ll1l1ll_l1_:
		block = l1ll1l1ll_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ⫌"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⫍"),menu_name+title,l1111l_l1_,452,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⫎"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⫏"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				#if l1111l_l1_==l1l11l_l1_ (u"ࠧࠨ⫐"): continue
				title = unescapeHTML(title)
				#if title!=l1l11l_l1_ (u"࠭ࠧ⫑"):
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⫒"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧ⫓")+title,l1111l_l1_,454)
	return
def PLAY(url):
	url2 = url.replace(l1l11l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ⫔"),l1l11l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫ⫕"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⫖"),l1l11l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⫗"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ⫘"),url2,l1l11l_l1_ (u"ࠧࠨ⫙"),l1l11l_l1_ (u"ࠨࠩ⫚"),l1l11l_l1_ (u"ࠩࠪ⫛"),l1l11l_l1_ (u"ࠪࠫ⫝̸"),l1l11l_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⫝"))
	html = response.content
	l111l11l1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ⫞"))
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡚ࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡹࡩࡥࡧࡁࠫ⫟"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ⫠"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⫡")+title+l1l11l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⫢")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫࠥࡷࡪࡲࡡࡳࡻࠥࠫ⫣"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ⫤"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			name = unescapeHTML(name)
			l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭⫥"),name,re.DOTALL)
			if l1l1l111_l1_:
				l1l1l111_l1_ = l1l11l_l1_ (u"࠭࡟ࡠࡡࡢࠫ⫦")+l1l1l111_l1_[0]
				name = l1l11l_l1_ (u"ࠧࠨ⫧")
			else: l1l1l111_l1_ = l1l11l_l1_ (u"ࠨࠩ⫨")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⫩")+name+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⫪")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ⫫"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⫬"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ⫭"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨ⫮"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ⫯"),l1l11l_l1_ (u"ࠩ࠮ࠫ⫰"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⫱")+search
	l111l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭⺗")
menu_name = l1l11l_l1_ (u"ࠧࡠࡏ࠷࡙ࡤ࠭⺘")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨษ้์ฬ฿ࠠศใ็ห๊࠭⺙"),l1l11l_l1_ (u"ࠩฯ์ิอสࠡษไ่ฬ๋ࠧ⺚")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l111l1_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l111ll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺛"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⺜"),l1l11l_l1_ (u"ࠬ࠭⺝"),389,l1l11l_l1_ (u"࠭ࠧ⺞"),l1l11l_l1_ (u"ࠧࠨ⺟"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⺠"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⺡"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⺢"),l1l11l_l1_ (u"ࠫࠬ⺣"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺤"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⺥")+menu_name+l1l11l_l1_ (u"ࠧศๆ่้๏ุษࠨ⺦"),l11lll_l1_,381,l1l11l_l1_ (u"ࠨࠩ⺧"),l1l11l_l1_ (u"ࠩࠪ⺨"),l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ⺩"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺪"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⺫")+menu_name+l1l11l_l1_ (u"࠭วๅฮส๊อ๐ษࠨ⺬"),l11lll_l1_,381,l1l11l_l1_ (u"ࠧࠨ⺭"),l1l11l_l1_ (u"ࠨࠩ⺮"),l1l11l_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ⺯"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⺰"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ⺱"),l1l11l_l1_ (u"ࠬ࠭⺲"),l1l11l_l1_ (u"࠭ࠧ⺳"),l1l11l_l1_ (u"ࠧࠨ⺴"),l1l11l_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⺵"))
	html = response.content
	items = re.findall(l1l11l_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⺶"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺷"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⺸")+menu_name+title,l11lll_l1_,381,l1l11l_l1_ (u"ࠬ࠭⺹"),l1l11l_l1_ (u"࠭ࠧ⺺"),l1l11l_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⺻")+str(seq))
	block = l1l11l_l1_ (u"ࠨࠩ⺼")
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧ⺽"),html,re.DOTALL)
	if l1ll111_l1_: block += l1ll111_l1_[0]
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠬ࠳࠰࠿ࠪࡣࡶ࡭ࡩ࡫ࠧ⺾"),html,re.DOTALL)
	if l1ll111_l1_: block += l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⺿"),block,re.DOTALL)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⻀"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⻁"),l1l11l_l1_ (u"ࠧࠨ⻂"),9999)
	first = True
	for l1111l_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l11l_l1_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ⻃"):
			if first:
				title = l1l11l_l1_ (u"ࠩส่ฬ็ไศ็ࠣࠫ⻄")+title
				first = False
			else: title = l1l11l_l1_ (u"ࠪห้๋ำๅี็หฯࠦࠧ⻅")+title
		if title not in l1llll1_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻆"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⻇")+menu_name+title,l1111l_l1_,381)
	return html
def l111l1_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⻈"),l1l11l_l1_ (u"ࠧࠨ⻉"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⻊"),url,l1l11l_l1_ (u"ࠩࠪ⻋"),l1l11l_l1_ (u"ࠪࠫ⻌"),l1l11l_l1_ (u"ࠫࠬ⻍"),l1l11l_l1_ (u"ࠬ࠭⻎"),l1l11l_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⻏"))
	html = response.content
	if type==l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⻐"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡥࡷࡩࡨ࠮ࡲࡤ࡫ࡪࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ⻑"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⻒"),block,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ⻓"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠨ⻔"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		z = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⻕"),block,re.DOTALL)
		l1ll1l1l_l1_,l1ll11l11_l1_,l1l1lll_l1_ = zip(*z)
		items = zip(l1ll11l11_l1_,l1ll1l1l_l1_,l1l1lll_l1_)
	elif type==l1l11l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⻖"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࡶ࠱ࡹࡼࡳࡩࡱࡺࡷࠧ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⻗"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⻘"),block,re.DOTALL)
	elif l1l11l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ⻙") in type:
		seq = int(type[-1:])
		html = html.replace(l1l11l_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⻚"),l1l11l_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡷࡹࡧࡲࡵࡀࠪ⻛"))
		html = html.replace(l1l11l_l1_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ⻜"),l1l11l_l1_ (u"࠭࠼ࡦࡰࡧࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ⻝"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡷࡥࡷࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡯ࡦࡁࠫ⻞"),html,re.DOTALL)
		block = l1ll111_l1_[seq]
		if seq==2: items = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⻟"),block,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࢂࡳࡪࡦࡨࡦࡦࡸࠩࠨ⻠"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0][0]
			if l1l11l_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ⻡") in url:
				items = re.findall(l1l11l_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⻢"),block,re.DOTALL)
			elif l1l11l_l1_ (u"ࠬ࠵ࡱࡶࡣ࡯࡭ࡹࡿ࠯ࠨ⻣") in url:
				items = re.findall(l1l11l_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⻤"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l11l_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⻥"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࠧ⻦") in title:
			title = re.findall(l1l11l_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡥࡳ࡫ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⻧"),title,re.DOTALL)
			title = title[0][1]#+l1l11l_l1_ (u"ࠪࠤ࠲ࠦࠧ⻨")+title[0][0]
			if title in l1l1l11_l1_: continue
			l1l1l11_l1_.append(title)
			title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ⻩")+title
		title2 = re.findall(l1l11l_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠭⻪"),title,re.DOTALL)
		if title2: title = title2[0]
		title = unescapeHTML(title)
		if l1l11l_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ⻫") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻬"),menu_name+title,l1111l_l1_,383,img)
		elif l1l11l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ⻭") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⻮"),menu_name+title,l1111l_l1_,383,img)
		elif l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠴࠭⻯") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻰"),menu_name+title,l1111l_l1_,383,img)
		elif l1l11l_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫ⻱") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻲"),menu_name+title,l1111l_l1_,381,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⻳"),menu_name+title,l1111l_l1_,382,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡒࡤ࡫ࡪࠦࠨ࠯ࠬࡂ࠭ࠥࡵࡦࠡࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⻴"),html,re.DOTALL)
	if l1ll111_l1_:
		current = l1ll111_l1_[0][0]
		last = l1ll111_l1_[0][1]
		block = l1ll111_l1_[0][2]
		items = re.findall(l1l11l_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦ⻵"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title==l1l11l_l1_ (u"ࠪࠫ⻶") or title==last: continue
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻷"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ⻸")+title,l1111l_l1_,381,l1l11l_l1_ (u"࠭ࠧ⻹"),l1l11l_l1_ (u"ࠧࠨ⻺"),type)
		#if title==last:
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ⻻")+title+l1l11l_l1_ (u"ࠩ࠲ࠫ⻼"),l1l11l_l1_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠪ⻽")+last+l1l11l_l1_ (u"ࠫ࠴࠭⻾"))
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻿"),menu_name+l1l11l_l1_ (u"࠭วฯำูࠣๆำษࠡࠩ⼀")+last,l1111l_l1_,381,l1l11l_l1_ (u"ࠧࠨ⼁"),l1l11l_l1_ (u"ࠨࠩ⼂"),type)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⼃"),url,l1l11l_l1_ (u"ࠪࠫ⼄"),l1l11l_l1_ (u"ࠫࠬ⼅"),l1l11l_l1_ (u"ࠬ࠭⼆"),l1l11l_l1_ (u"࠭ࠧ⼇"),l1l11l_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⼈"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⼉"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_,False):
		addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⼊"),menu_name+l1l11l_l1_ (u"ࠪห้๋ำๅี็ࠤ้๊ใษษิࠤํอไๆสิ้ัࠦๅ็฻๊ࠫ⼋"),l1l11l_l1_ (u"ࠫࠬ⼌"),9999)
		return
	if l1l11l_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⼍") in url or l1l11l_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ⼎") in url:
		url2 = re.findall(l1l11l_l1_ (u"ࠧࠨࠩࡦࡰࡦࡹࡳ࠾ࠩ࡬ࡸࡪࡳࠧ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬ⼏"),html,re.DOTALL)
		if url2:
			url2 = url2[1]
			l111ll_l1_(url2)
			return
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠩࠪࡧࡱࡧࡳࡴ࠿ࠪࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸ࠭ࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡤࡷࡹࠨࠧࠨࠩ⼐"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࠪࠫࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠫࡳࡻ࡭ࡦࡴࡤࡲࡩࡵࠧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫ⼑"),block,re.DOTALL)
		for img,l1ll1ll_l1_,l1111l_l1_,name in items:
			title = l1ll1ll_l1_+l1l11l_l1_ (u"ࠪࠤ࠿ࠦࠧ⼒")+name+l1l11l_l1_ (u"ࠫࠥอไฮๆๅอࠬ⼓")
			addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⼔"),menu_name+title,l1111l_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ⼕"),url,l1l11l_l1_ (u"ࠧࠨ⼖"),l1l11l_l1_ (u"ࠨࠩ⼗"),l1l11l_l1_ (u"ࠩࠪ⼘"),l1l11l_l1_ (u"ࠪࠫ⼙"),l1l11l_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⼚"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⼛"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	l1ll1l1l_l1_ = []
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠢࠣ࡫ࡧࡁࠬࡶ࡬ࡢࡻࡨࡶ࠲ࡵࡰࡵ࡫ࡲࡲ࠲࠷ࠧࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁ࠭ࠨࡳࡩࡧࡤࡨࡪࡸࠢࡽࠩࡳࡥ࡬ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࠫࠥࠦࠧ⼜"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0][0]
		items = re.findall(l1l11l_l1_ (u"ࠢࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠬࡹࡥࡳࡸࡨࡶࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨ⼝"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⼞")+title+l1l11l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⼟")
			l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡳ࡯ࡥࡣ࡯ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡲࡵࡤࡢ࡮࠰ࡧࡱࡵࡳࡦࠤࠪ⼠"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡤࡥ࡟ࡥ࡮ࡢ࡫ࡩࡸࡩࡷࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⼡"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⼢")+title+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⼣")
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⼤"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⼥"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠩࠪ⼦"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠪࠫ⼧"): return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭⼨"),l1l11l_l1_ (u"ࠬ࠱ࠧ⼩"))
	url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡀࡵࡀࠫ⼪")+search
	l111l1_l1_(url,l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⼫"))
	return
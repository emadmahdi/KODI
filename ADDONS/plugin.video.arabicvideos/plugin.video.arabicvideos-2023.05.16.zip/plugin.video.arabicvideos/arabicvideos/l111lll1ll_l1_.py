# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭ᱳ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺ࠳࠱ࡦࡪࡹࡴࠨᱴ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠱࠯ࡥࡲࡱࠬᱵ")
#l11lll_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬᱶ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠹ࡨࡥࡴࡶ࠱ࡧࡴࡳࠧᱷ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠰ࡺ࡮ࡶ࠮ࡴࡪࡲࡪࡩࡧ࠮ࡤࡱࡰࠫᱸ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡴࡳࡥ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡱࡰࠬᱹ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬᱺ")
script_name = l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨᱻ")
menu_name = l1l11l_l1_ (u"ࠬࡥࡅࡈࡘࡢࠫᱼ")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l111l1_l1_(url,page)
	elif mode==222: results = l1l1l1ll1_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1l1l1l_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱽ"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ᱾"),l1l11l_l1_ (u"ࠨࠩ᱿"),229,l1l11l_l1_ (u"ࠩࠪᲀ"),l1l11l_l1_ (u"ࠪࠫᲁ"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲂ"))
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲃ"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩᲄ"),l11lll_l1_,226,l1l11l_l1_ (u"ࠧࠨᲅ"),l1l11l_l1_ (u"ࠨࠩᲆ"),l1l11l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩᲇ"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᲈ"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧᲉ"),l11lll_l1_,226,l1l11l_l1_ (u"ࠬ࠭ᲊ"),l1l11l_l1_ (u"࠭ࠧ᲋"),l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ᲌"))
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᲍"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᲎"),l1l11l_l1_ (u"ࠪࠫ᲏"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᲐ"),l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭Ბ"),l1l11l_l1_ (u"࠭ࠧᲒ"),l1l11l_l1_ (u"ࠧࠨᲓ"),l1l11l_l1_ (u"ࠨࠩᲔ"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᲕ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࠥ࡯࠭ࡩࡱࡰࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᲖ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᲗ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠬࡂ࠯ࡪࡀࠪᲘ") in title: title = title.split(l1l11l_l1_ (u"࠭࠼࠰࡫ࡁࠫᲙ"))[1]
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲚ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᲛ")+menu_name+title,l1111l_l1_,222)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᲜ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᲝ"),l1l11l_l1_ (u"ࠫࠬᲞ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࠩ࠰࠭ࡃ࠮ࡂࡳࡤࡴ࡬ࡴࡹ࠭Ჟ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡰࡥࡣࠣࡦࡩࡨࠢ࠿࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᲠ"),html,re.DOTALL)
	for title,l1111l_l1_ in items:
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲡ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᲢ")+menu_name+title,l1111l_l1_,221)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᲣ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᲤ"),l1l11l_l1_ (u"ࠫࠬᲥ"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᲦ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"࠭ࡨࡵ࡯࡯ࠫᲧ") not in l1111l_l1_: continue
		if not l1111l_l1_.endswith(l1l11l_l1_ (u"ࠧ࠰ࠩᲨ")): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲩ"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᲪ")+menu_name+title,l1111l_l1_,221)
	return html
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอึ฻ู๋๋ࠣอࠠๅษูหๆฯࠠศี่ࠤิิ่ๅ๋ࠢ็้๋ษࠡษ็ืึ࠭ࠬࠨࠩ࠯࠶࠷࠻ࠩࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧหฯำ๎ึ࠭ࠬࠨࠩ࠯࠶࠷࠼ࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠢ࡫ࡸࡲࡲࠩࠋࠋࠦ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱࡐࡴࡧࡤࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠦ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࡞ࡱࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡪࡴࡸࠠࡶࡴ࡯࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠤࠋ࡬ࡪࠥࡻࡲ࡭ࠣࡀࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮ࡸࡶࡱ࠲࠲࠳࠶ࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ࠯ࠫࠬ࠲࠲࠳࠻࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩส่ศ้หาุ่ࠢฬํฯสࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ࠰࠷࠸࠱ࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩส่ฬ็ไศ็ࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ࠯࠶࠷࠺ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࠯ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็ุ้๊ำๅษอࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࠩ࠲ࡸࡻ࠭ࠬ࠳࠴࠷࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬࡲࡩ࡯࡭ࠪ࠰ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠲ࠧࠨ࠮࠼࠽࠾࠿ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠠ࡮ࡩࡥࠬ࠳࠰࠿ࠪࡀࡈ࡫ࡾࡈࡥࡴࡶ࠿࠳ࡦࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤ࡭ࡺ࡭࡭ࠌࠌࠧࠥ࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠥ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡠ࠷࠯࡞࡝࡬ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࠩࡷࡳࡷࡸࡥ࡯ࡶࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠶࠷࠷ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫࡹࡵࡲࡳࡧࡱࡸࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࠧࠨࠢᲫ")
def l1l1l1ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᲬ"),url,l1l11l_l1_ (u"ࠬ࠭Ჭ"),l1l11l_l1_ (u"࠭ࠧᲮ"),l1l11l_l1_ (u"ࠧࠨᲯ"),l1l11l_l1_ (u"ࠨࠩᲰ"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᲱ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡸࡥࡳࡤࡴࡲࡰࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᲲ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᲳ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲴ"),menu_name+title,l1111l_l1_,224)
	return
def l1l1l1l_l1_(url):
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ჵ"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠧᲶ"),url,221)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠨࠩᲷ"),l1l11l_l1_ (u"ࠩࠪᲸ"),l1l11l_l1_ (u"ࠪࠫᲹ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᲺ"))
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡰࡥ࡮ࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠶࠷࠷ࠩࠋࠋࠥࠦࠧ᲻")
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡶࡤࡢࡲࡦࡼࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳࠨ᲼"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᲽ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1111l_l1_==l1l11l_l1_ (u"ࠨࠥࠪᲾ"): name = title
			else:
				title = title + l1l11l_l1_ (u"ࠩࠣࠤ࠿ࠦࠠࠨᲿ") + l1l11l_l1_ (u"ࠪๅ้ะัࠡࠩ᳀") + name
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳁"),menu_name+title,l1111l_l1_,221)
	else: l111l1_l1_(url)
	return
def l111l1_l1_(url,page=l1l11l_l1_ (u"ࠬ࠷ࠧ᳂")):
	if page==l1l11l_l1_ (u"࠭ࠧ᳃"): page = l1l11l_l1_ (u"ࠧ࠲ࠩ᳄")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ᳅"),l1l11l_l1_ (u"ࠩࠪ᳆"),str(url), str(page))
	if l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ᳇") in url or l1l11l_l1_ (u"ࠫࡄ࠭᳈") in url: url2 = url + l1l11l_l1_ (u"ࠬࠬࠧ᳉")
	else: url2 = url + l1l11l_l1_ (u"࠭࠿ࠨ᳊")
	#url2 = url2 + l1l11l_l1_ (u"ࠧࡰࡷࡷࡴࡺࡺ࡟ࡧࡱࡵࡱࡦࡺ࠽࡫ࡵࡲࡲࠫࡵࡵࡵࡲࡸࡸࡤࡳ࡯ࡥࡧࡀࡱࡴࡼࡩࡦࡵࡢࡰ࡮ࡹࡴࠧࡲࡤ࡫ࡪࡃࠧ᳋")+page
	url2 = url2 + l1l11l_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧ᳌") + page
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠩࠪ᳍"),l1l11l_l1_ (u"ࠪࠫ᳎"),l1l11l_l1_ (u"ࠫࠬ᳏"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭᳐"))
	#name = l1l11l_l1_ (u"࠭ࠧ᳑")
	#if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨ᳒") in url:
	#	name = re.findall(l1l11l_l1_ (u"ࠨ࠾࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀࠬ᳓"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l1l11l_l1_ (u"᳔ࠩࠣࠫ")) + l1l11l_l1_ (u"ࠪࠤ࠲᳕ࠦࠧ")
	#	else: name = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰ᳖ࠧ") ) + l1l11l_l1_ (u"᳗ࠬࠦ࠭ࠡࠩ")
	if l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ᳘ࠧ") in url:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡦࡤࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ᳙࠭"),html,re.DOTALL)
		block = l1ll111_l1_[-1]
	# l111ll1ll1_l1_ l111l111l_l1_
	elif l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ᳚") in url:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡲࡻࡱ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠡࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ᳛"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	else:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ᳜ࠫ"),html,re.DOTALL)
		block = l1ll111_l1_[-1]
	items = re.findall(l1l11l_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᳝"),block,re.DOTALL)
	for l1111l_l1_,img,title in items:
		l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࠌ࡭࡫ࠦࠧ࠰ࡵࡨࡶ࡮࡫ࡳࠨࠢ࡬ࡲࠥࡻࡲ࡭ࠢࡤࡲࡩࠦࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎ࡯ࡦࠡࠩ࠲ࡷࡪࡧࡳࡰࡰࠪࠤ࡮ࡴࠠࡶࡴ࡯ࠤࡦࡴࡤࠡࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࠤࡸࡺࡲࠩ࡮࡬ࡲࡰ࠯ࠩࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡳࡧ࡭ࡦࠢ࠮ࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠦࠧࠨ᳞")
		title = unescapeHTML(title)
		l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟࠳ࠬ࠲ࠧ࠰ࠩࠬࠎࠎࠏࡩ࡮ࡩࠣࡁࠥ࡯࡭ࡨ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࠊ࡫ࡩࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤ࡮ࡳࡧ࠻ࠢ࡬ࡱ࡬ࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺ࠨࠢ࠮ࠤ࡮ࡳࡧࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡓࡕࡔࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠫ࡭ࡲ࡭ࠬࠨࠩࠬࠎࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࡱ࡯࡮࡬ࠌࠌࠍࠧࠨ᳟ࠢ")
		if l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯ࠨ᳠") in l1111l_l1_ or l1l11l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࠪ᳡") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᳢"),menu_name+title,l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠪ࠳᳣ࠬ")),223,img)
		else:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳤ࠫ"),menu_name+title,l1111l_l1_,221,img)
	if len(items)>=16:
		l11llll1l1_l1_ = [l1l11l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ᳥࠭"),l1l11l_l1_ (u"࠭࠯ࡵࡸ᳦ࠪ"),l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ᳧"),l1l11l_l1_ (u"ࠨ࠱ࡷࡶࡪࡴࡤࡪࡰࡪ᳨ࠫ")]
		page = int(page)
		if any(value in url for value in l11llll1l1_l1_):
			for n in range(0,1000,100):
				if int(page/100)*100==n:
					for i in range(n,n+100,10):
						if int(page/10)*10==i:
							for j in range(i,i+10,1):
								if not page==j and j!=0:
									addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᳩ"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡࠩᳪ")+str(j),url,221,l1l11l_l1_ (u"ࠫࠬᳫ"),str(j))
						elif i!=0: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳬ"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤ᳭ࠬ")+str(i),url,221,l1l11l_l1_ (u"ࠧࠨᳮ"),str(i))
						else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᳯ"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨᳰ")+str(1),url,221,l1l11l_l1_ (u"ࠪࠫᳱ"),str(1))
				elif n!=0: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᳲ"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫᳳ")+str(n),url,221,l1l11l_l1_ (u"࠭ࠧ᳴"),str(n))
				else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳵ"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧᳶ")+str(1),url,221)
	return
def PLAY(url):
	#global l1l11l_l1_ (u"ࠩࠪ᳷")
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ᳸"),l1l11l_l1_ (u"ࠫࠬ᳹"),url, url[-45:])
	# l11l11l_l1_://l11l11111l_l1_.l11111ll_l1_/l11l111ll1_l1_/فيلم-the-l11l11l1l1_l1_-l111ll1lll_l1_-2019-مترجم
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠬ࠭ᳺ"),l1l11l_l1_ (u"࠭ࠧ᳻"),l1l11l_l1_ (u"ࠧࠨ᳼"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ᳽"))
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡸࡩࡄวๅฬุ๊๏็࠼࠰ࡶࡧࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᳾"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# l11l11l_l1_://l1l111l1l1_l1_.l111ll1l1l_l1_/l11l111ll1_l1_/فيلم-the-l11l11l1l1_l1_-l111ll1lll_l1_-2019-مترجم
	l1l111ll1_l1_,l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠪࠫ᳿"),l1l11l_l1_ (u"ࠫࠬᴀ")
	l11l11l1ll_l1_,l111lllll1_l1_ = html,html
	l11l1111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡨࡰࡹࡢࡨࡱࠦࡡࡱ࡫ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴁ"),html,re.DOTALL)
	if l11l1111ll_l1_:
		for l1111l_l1_ in l11l1111ll_l1_:
			if l1l11l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧᴂ") in l1111l_l1_: l1l111ll1_l1_ = l1111l_l1_
			elif l1l11l_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫᴃ") in l1111l_l1_: l1l1ll11l_l1_ = l1111l_l1_
		if l1l111ll1_l1_!=l1l11l_l1_ (u"ࠨࠩᴄ"): l11l11l1ll_l1_ = OPENURL_CACHED(l1llll_l1_,l1l111ll1_l1_,l1l11l_l1_ (u"ࠩࠪᴅ"),l1l11l_l1_ (u"ࠪࠫᴆ"),l1l11l_l1_ (u"ࠫࠬᴇ"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫᴈ"))
		if l1l1ll11l_l1_!=l1l11l_l1_ (u"࠭ࠧᴉ"): l111lllll1_l1_ = OPENURL_CACHED(l1llll_l1_,l1l1ll11l_l1_,l1l11l_l1_ (u"ࠧࠨᴊ"),l1l11l_l1_ (u"ࠨࠩᴋ"),l1l11l_l1_ (u"ࠩࠪᴌ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩᴍ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬᴎ"),l1l11l_l1_ (u"ࠬ࠭ᴏ"),l1l1ll11l_l1_,l1l111ll1_l1_)
	# l11l11l_l1_://l111llll1l_l1_.l1l111l1l1_l1_.download/?id=__11l11l11l_l1_
	l11l111l11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᴐ"),l11l11l1ll_l1_,re.DOTALL)
	if l11l111l11_l1_:
		url2 = l11l111l11_l1_[0]#+l1l11l_l1_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࡨࡵࡶࡳ࠾࠴࠵࠷࠺࠰࠴࠺࠺࠴࠲࠵࠴࠱࠼࠹ࡀ࠴࠲࠶࠸ࠫᴑ")
		if url2!=l1l11l_l1_ (u"ࠨࠩᴒ") and l1l11l_l1_ (u"ࠩࡸࡴࡱࡵࡡࡥࡧࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᴓ") in url2 and l1l11l_l1_ (u"ࠪ࠳ࡄ࡯ࡤ࠾ࡡࠪᴔ") not in url2:
			l1ll1ll1_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠫࠬᴕ"),l1l11l_l1_ (u"ࠬ࠭ᴖ"),l1l11l_l1_ (u"࠭ࠧᴗ"),l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭ᴘ"))
			l111ll11ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴙ"),l1ll1ll1_l1_,re.DOTALL)
			if l111ll11ll_l1_:
				for l1111l_l1_,l1l1l111_l1_ in l111ll11ll_l1_:
					l1ll1l1l_l1_.append(l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡨࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࡰࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱࡵ࠺࡟ࡠࠩᴚ")+l1l1l111_l1_)
			else:
				server = url2.split(l1l11l_l1_ (u"ࠪ࠳ࠬᴛ"))[2]
				l1ll1l1l_l1_.append(url2+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᴜ")+server+l1l11l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᴝ"))
		elif url2!=l1l11l_l1_ (u"࠭ࠧᴞ"):
			#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᴟ"),l1l11l_l1_ (u"ࠨࠩᴠ"),url2,str(l11l111l11_l1_))
			server = url2.split(l1l11l_l1_ (u"ࠩ࠲ࠫᴡ"))[2]
			l1ll1l1l_l1_.append(url2+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᴢ")+server+l1l11l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᴣ"))
	# l11l11l_l1_://l111lll1l1_l1_.cc/l11l11l111_l1_
	# l11l11l_l1_://l11l111l1l_l1_.l111lll11l_l1_/l11l11l111_l1_
	l111llll11_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡴࡢࡤ࡯ࡩࠥࡩ࡬ࡢࡵࡶࡁࠧࡪ࡬ࡴࡡࡷࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧᴤ"),l111lllll1_l1_,re.DOTALL)
	if l111llll11_l1_:
		l111llll11_l1_ = l111llll11_l1_[0]
		l11l1111l1_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡵࡦࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᴥ"),l111llll11_l1_,re.DOTALL)
		if l11l1111l1_l1_:
			for l1l1l111_l1_,l1111l_l1_ in l11l1111l1_l1_:
				if l1l11l_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩᴦ") not in l1111l_l1_: continue
				if l1111l_l1_.count(l1l11l_l1_ (u"ࠨ࠱ࠪᴧ"))>=2:
					server = l1111l_l1_.split(l1l11l_l1_ (u"ࠩ࠲ࠫᴨ"))[2]
					l1ll1l1l_l1_.append(l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᴩ")+server+l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡰࡴ࠹ࡥ࡟ࠨᴪ")+l1l1l111_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭ᴫ"), l1ll1l1l_l1_)
	#if selection == -1 : return
	newLIST = []
	for l1111l_l1_ in l1ll1l1l_l1_:
		# l111lll111_l1_	l11l11l_l1_://l1111ll11_l1_.l1l111l1l1_l1_.l111ll1l1l_l1_/l11l111ll1_l1_/l1l1l1111_l1_/فيلم-the-l11l111lll_l1_-l11l111111_l1_-l111ll1l11_l1_-2017-مترجم/l111llllll_l1_
		#if l1l11l_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧᴬ") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࡄࡴࡡ࡮ࡧࠪᴭ") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭ᴮ") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫᴯ") not in l1111l_l1_: continue
		newLIST.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᴰ"), newLIST)
	import ll_l1_
	ll_l1_.l1l_l1_(newLIST,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᴱ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭ᴲ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧᴳ"): return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠧࠡࠩᴴ"),l1l11l_l1_ (u"ࠨ࠭ࠪᴵ"))
	html = OPENURL_CACHED(l1111lll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠩࠪᴶ"),l1l11l_l1_ (u"ࠪࠫᴷ"),l1l11l_l1_ (u"ࠫࠬᴸ"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ᴹ"))
	token = re.findall(l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡥࡴࡰ࡭ࡨࡲࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴺ"),html,re.DOTALL)
	if token:
		url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡡࡷࡳࡰ࡫࡮࠾ࠩᴻ")+token[0]+l1l11l_l1_ (u"ࠨࠨࡴࡁࠬᴼ")+l1l1ll_l1_
		l111l1_l1_(url)
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᴽ"),l1l11l_l1_ (u"ࠪࠫᴾ"),l1l11l_l1_ (u"ࠫࠬᴿ"), l1l11l_l1_ (u"ࠬ࠭ᵀ"))
	return
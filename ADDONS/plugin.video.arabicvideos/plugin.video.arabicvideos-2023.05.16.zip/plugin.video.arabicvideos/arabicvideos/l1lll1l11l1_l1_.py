# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ⛞")
menu_name = l1l11l_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ⛟")
l11lll_l1_ = WEBSITES[script_name][0]
l1ll1ll11l_l1_ = WEBSITES[script_name][1]
l1lll111ll1_l1_ = WEBSITES[script_name][2]
l1lll11l111_l1_ = WEBSITES[script_name][3]
#l1lll11lll1_l1_  = WEBSITES[script_name][4]
#l1lll11lll1_l1_  = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==20: results = l1lll11l11l_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l111l1_l1_(url,page)
	elif mode==23: results = l111ll_l1_(url,page)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1ll1lllll1_l1_(url)
	elif mode==27: results = l1lll1ll1_l1_(url)
	elif mode==28: results = l1lll11ll11_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1lll11l11l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛠"),menu_name+l1l11l_l1_ (u"ู࠭าสํࠫ⛡"),l11lll_l1_,21,l1l11l_l1_ (u"ࠧࠨ⛢"),l1l11l_l1_ (u"ࠨ࠳࠳࠵ࠬ⛣"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⛤"),menu_name+l1l11l_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⛥"),l1ll1ll11l_l1_,21,l1l11l_l1_ (u"ࠫࠬ⛦"),l1l11l_l1_ (u"ࠬ࠷࠰࠲ࠩ⛧"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛨"),menu_name+l1l11l_l1_ (u"ࠧโษิื๎࠭⛩"),l1lll111ll1_l1_,21,l1l11l_l1_ (u"ࠨࠩ⛪"),l1l11l_l1_ (u"ࠩ࠴࠴࠶࠭⛫"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛬"),menu_name+l1l11l_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ⛭"),l1lll11l111_l1_,21,l1l11l_l1_ (u"ࠬ࠭⛮"),l1l11l_l1_ (u"࠭࠱࠱࠳ࠪ⛯"))
	return
def l1lll11ll11_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⛰"),menu_name+l1l11l_l1_ (u"ࠨ฻ิฬ๏࠭⛱"),l11lll_l1_,27)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⛲"),menu_name+l1l11l_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⛳"),l1ll1ll11l_l1_,27)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⛴"),menu_name+l1l11l_l1_ (u"ࠬ็วาี์ࠫ⛵"),l1lll111ll1_l1_,27)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫ⛶"),menu_name+l1l11l_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ⛷"),l1lll11l111_l1_,27)
	return
def MENU(l1lll11ll1l_l1_):
	script_name = l1lll11ll1l_l1_
	if l1lll11ll1l_l1_==l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ⛸"): l1lll11ll1l_l1_ = l11lll_l1_
	elif l1lll11ll1l_l1_==l1l11l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⛹"): l1lll11ll1l_l1_ = l1ll1ll11l_l1_
	else: script_name = l1l11l_l1_ (u"ࠪࠫ⛺")
	lang = l1lll11llll_l1_(l1lll11ll1l_l1_)
	if lang==l1l11l_l1_ (u"ࠫࡦࡸࠧ⛻") or script_name==l1l11l_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⛼"):
		l1ll1llllll_l1_ = l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⛽")
		name1 = l1l11l_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣัฬ๊๊สࠩ⛾")
		name2 = l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤศำฯฬࠩ⛿")
		l1lll111111_l1_ = l1l11l_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥษศอัํࠫ✀")
		l1lll1111l1_l1_ = l1l11l_l1_ (u"ࠪฬะࠦอ๋ࠢล๎ࠥ็๊ๅ็ࠪ✁")
		l1lll11111l_l1_ = l1l11l_l1_ (u"ࠫศ็ไศ็ࠪ✂")
		l1lll111l11_l1_ = l1l11l_l1_ (u"๋่ࠬิ์ๅํࠬ✃")
		l1lll1111ll_l1_ = l1l11l_l1_ (u"࠭ศาษ่ะࠬ✄")
	elif lang==l1l11l_l1_ (u"ࠧࡦࡰࠪ✅") or script_name==l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ✆"):
		l1ll1llllll_l1_ = l1l11l_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢ࡬ࡲࠥࡹࡩࡵࡧࠪ✇")
		name1 = l1l11l_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡉࡵࡳࡴࡨࡲࡹ࠭✈")
		name2 = l1l11l_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡌࡢࡶࡨࡷࡹ࠭✉")
		l1lll111111_l1_ = l1l11l_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡂ࡮ࡳ࡬ࡦࡨࡥࡵࠩ✊")
		l1lll1111l1_l1_ = l1l11l_l1_ (u"࠭ࡌࡪࡸࡨࠤ࡮ࡌࡩ࡭࡯ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠫ✋")
		l1lll11111l_l1_ = l1l11l_l1_ (u"ࠧࡎࡱࡹ࡭ࡪࡹࠧ✌")
		l1lll111l11_l1_ = l1l11l_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ✍")
		l1lll1111ll_l1_ = l1l11l_l1_ (u"ࠩࡖ࡬ࡴࡽࡳࠨ✎")
	elif lang in [l1l11l_l1_ (u"ࠪࡪࡦ࠭✏"),l1l11l_l1_ (u"ࠫ࡫ࡧ࠲ࠨ✐")]:
		l1ll1llllll_l1_ = l1l11l_l1_ (u"ࠬาำหฮ๋ࠤิืࠠิษ໏ฮࠬ✑")
		name1 = l1l11l_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠอษิ໐ࠬ✒")
		name2 = l1l11l_l1_ (u"ࠧิำํห้ࠦ࠭ࠡฤัี໑์ࠧ✓")
		l1lll111111_l1_ = l1l11l_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢส่ๆฮวࠨ✔")
		l1lll1111l1_l1_ = l1l11l_l1_ (u"ࠩກาูࠦา็ั๊ࠤฬ๐ࠠโ์็้ࠬ✕")
		l1lll11111l_l1_ = l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨ✖")
		l1lll111l11_l1_ = l1l11l_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ✗")
		l1lll1111ll_l1_ = l1l11l_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠨ✘")
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✙"),menu_name+l1ll1llllll_l1_,l1lll11ll1l_l1_,29,l1l11l_l1_ (u"ࠧࠨ✚"),l1l11l_l1_ (u"ࠨࠩ✛"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭✜"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ✝"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭✞")+menu_name+l1lll1111l1_l1_,l1lll11ll1l_l1_,27)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ✟"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ✠"),l1l11l_l1_ (u"ࠧࠨ✡"),9999)
	l1lllll1ll_l1_ = [l1l11l_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ✢"),l1l11l_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ✣"),l1l11l_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ✤")]
	html = OPENURL_CACHED(l1llll_l1_,l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ✥"),l1l11l_l1_ (u"ࠬ࠭✦"),l1l11l_l1_ (u"࠭ࠧ✧"),l1l11l_l1_ (u"ࠧࠨ✨"),l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ✩"))
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠩࡥࡹࡹࡺ࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭࠴ࡉ࡯࡯ࡶࡤࡧࡹ࠭✪"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ✫"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if any(value in l1111l_l1_ for value in l1lllll1ll_l1_):
				url = l1lll11ll1l_l1_+l1111l_l1_
				if l1l11l_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ✬") in l1111l_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✭"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ✮")+menu_name+name1,url,22,l1l11l_l1_ (u"ࠧࠨ✯"),l1l11l_l1_ (u"ࠨ࠳࠳࠴ࠬ✰"))
					addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ✱"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ✲")+menu_name+name2,url,22,l1l11l_l1_ (u"ࠫࠬ✳"),l1l11l_l1_ (u"ࠬ࠷࠰࠲ࠩ✴"))
					addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✵"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ✶")+menu_name+l1lll111111_l1_,url,22,l1l11l_l1_ (u"ࠨࠩ✷"),l1l11l_l1_ (u"ࠩ࠵࠴࠶࠭✸"))
				elif l1l11l_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ✹") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✺"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ✻")+menu_name+l1lll11111l_l1_,url,22,l1l11l_l1_ (u"࠭ࠧ✼"),l1l11l_l1_ (u"ࠧ࠲࠲࠳ࠫ✽"))
				elif l1l11l_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ✾") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ✿"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ❀")+menu_name+l1lll111l11_l1_,url,25,l1l11l_l1_ (u"ࠫࠬ❁"),l1l11l_l1_ (u"ࠬ࠷࠰࠲ࠩ❂"))
				elif l1l11l_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ❃") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❄"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ❅")+menu_name+l1lll1111ll_l1_,url,22,l1l11l_l1_ (u"ࠩࠪ❆"),l1l11l_l1_ (u"ࠪ࠵࠵࠷ࠧ❇"))
	return html
def l1ll1lllll1_l1_(url):
	l1lll11ll1l_l1_ = l1lll111l1l_l1_(url)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠫࠬ❈"),l1l11l_l1_ (u"ࠬ࠭❉"),l1l11l_l1_ (u"࠭ࠧ❊"),l1l11l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡍࡖࡕࡌࡇࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ❋"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡏࡸࡷ࡮ࡩ࠭ࡵࡱࡲࡰࡸ࠳ࡨࡦࡣࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡹࡩࡤ࠯ࡥࡳࡩࡿࠧ❌"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	title = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ❍"),block,re.DOTALL)[0]
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❎"),menu_name+title,url,22,l1l11l_l1_ (u"ࠫࠬ❏"),l1l11l_l1_ (u"ࠬ࠷࠰࠲ࠩ❐"))
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ❑"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l1lll11ll1l_l1_ + l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❒"),menu_name+title,l1111l_l1_,23,l1l11l_l1_ (u"ࠨࠩ❓"),l1l11l_l1_ (u"ࠩ࠴࠴࠶࠭❔"))
	return
def l111l1_l1_(url,page):
	l1lll11ll1l_l1_ = l1lll111l1l_l1_(url)
	lang = l1lll11llll_l1_(url)
	type = url.split(l1l11l_l1_ (u"ࠪ࠳ࠬ❕"))[-1]
	l1ll1lll1ll_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ❖"),l1l11l_l1_ (u"ࠬ࠭❗"),url, type)
	if type==l1l11l_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭❘") and page==l1l11l_l1_ (u"ࠧ࠱ࠩ❙"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠨࠩ❚"),l1l11l_l1_ (u"ࠩࠪ❛"),l1l11l_l1_ (u"ࠪࠫ❜"),l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ❝"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡥࡳ࡫ࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠫ❞"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁ࠭࠴ࠪࡀࠫࡁ࠲࠯ࡅࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ❟"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1111l_l1_ = l1lll11ll1l_l1_ + l1111l_l1_
			img = l1lll11ll1l_l1_ + QUOTE(img)
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❠"),menu_name+title,l1111l_l1_,23,img,l1ll1lll1ll_l1_+l1l11l_l1_ (u"ࠨ࠲࠴ࠫ❡"))
	l1ll1llll11_l1_=0
	if type==l1l11l_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ❢"): category=l1l11l_l1_ (u"ࠪ࠷ࠬ❣")
	if type==l1l11l_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ❤"): category=l1l11l_l1_ (u"ࠬ࠻ࠧ❥")
	if type==l1l11l_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ❦"): category=l1l11l_l1_ (u"ࠧ࠸ࠩ❧")
	if type in [l1l11l_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ❨"),l1l11l_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ❩"),l1l11l_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ❪")] and page!=l1l11l_l1_ (u"ࠫ࠵࠭❫"):
		url2 = l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡕࡧࡧࡦ࡫ࡱ࡫ࡎࡺࡥ࡮ࡁࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ❬")+category+l1l11l_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭❭")+page+l1l11l_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡲࡶࡩ࡫ࡲࡣࡻࡀࠫ❮")+l1ll1lll1ll_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠨࠩ❯"),l1l11l_l1_ (u"ࠩࠪ❰"),l1l11l_l1_ (u"ࠪࠫ❱"),l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ❲"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭❳"),l1l11l_l1_ (u"࠭ࠧ❴"),url2, html)
		items = re.findall(l1l11l_l1_ (u"ࠧࠣࡋࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠱࠿ࠣࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ❵"),html,re.DOTALL)
		for id,title,img in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l11l_l1_ (u"ࠨ࡞࡟ࠫ❶"),l1l11l_l1_ (u"ࠩࠪ❷"))
			title = title.replace(l1l11l_l1_ (u"ࠪࠦࠬ❸"),l1l11l_l1_ (u"ࠫࠬ❹"))
			l1ll1llll11_l1_ += 1
			l1111l_l1_ = l1lll11ll1l_l1_ + l1l11l_l1_ (u"ࠬ࠵ࠧ❺") + type + l1l11l_l1_ (u"࠭࠯ࡄࡱࡱࡸࡪࡴࡴ࠰ࠩ❻") + id
			img = l1lll11ll1l_l1_ + QUOTE(img)
			if type==l1l11l_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ❼"): addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ❽"),menu_name+title,l1111l_l1_,24,img,l1ll1lll1ll_l1_+l1l11l_l1_ (u"ࠩ࠳࠵ࠬ❾"))
			else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❿"),menu_name+title,l1111l_l1_,23,img,l1ll1lll1ll_l1_+l1l11l_l1_ (u"ࠫ࠵࠷ࠧ➀"))
	if type==l1l11l_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ➁"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1lll11ll1l_l1_+l1l11l_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡉ࡯ࡦࡨࡼࡄࡶࡡࡨࡧࡀࠫ➂")+page,l1l11l_l1_ (u"ࠧࠨ➃"),l1l11l_l1_ (u"ࠨࠩ➄"),l1l11l_l1_ (u"ࠩࠪ➅"),l1l11l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭➆"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࠮ࡦࡨࡱࡴ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࠭ࡥࡧࡰࡳࠬ➇"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ➈"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			l1ll1llll11_l1_ += 1
			img = l1lll11ll1l_l1_ + img
			l1111l_l1_ = l1lll11ll1l_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➉"),menu_name+title,l1111l_l1_,23,img,l1l11l_l1_ (u"ࠧ࠲࠲࠴ࠫ➊"))
	if l1ll1llll11_l1_>20:
		title=l1l11l_l1_ (u"ࠨืไัฮࠦࠧ➋")
		if lang==l1l11l_l1_ (u"ࠩࡨࡲࠬ➌"): title = l1l11l_l1_ (u"ࠪࡔࡦ࡭ࡥࠡࠩ➍")
		if lang==l1l11l_l1_ (u"ࠫ࡫ࡧࠧ➎"): title = l1l11l_l1_ (u"ࠬ฻แฮ้ࠣࠫ➏")
		if lang==l1l11l_l1_ (u"࠭ࡦࡢ࠴ࠪ➐"): title = l1l11l_l1_ (u"ࠧึใะ๋ࠥ࠭➑")
		for l1lll111lll_l1_ in range(1,11) :
			if not page==str(l1lll111lll_l1_):
				l1ll1llll1l_l1_ = l1l11l_l1_ (u"ࠨ࠲ࠪ➒")+str(l1lll111lll_l1_)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➓"),menu_name+title+str(l1lll111lll_l1_),url,22,l1l11l_l1_ (u"ࠪࠫ➔"),l1ll1lll1ll_l1_+l1ll1llll1l_l1_[-2:])
	return
def l111ll_l1_(url,page):
	if not page: page = 0
	l1lll11ll1l_l1_ = l1lll111l1l_l1_(url)
	l1lll11lll1_l1_ = l1lll111l1l_l1_(url)
	lang = l1lll11llll_l1_(url)
	parts = url.split(l1l11l_l1_ (u"ࠫ࠴࠭➕"))
	id,type = parts[-1],parts[3]
	l1ll1lll1ll_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	l1ll1llll11_l1_ = 0
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭➖"),l1l11l_l1_ (u"࠭ࠧ➗"),url, type)
	if type==l1l11l_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ➘"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠨࠩ➙"),l1l11l_l1_ (u"ࠩࠪ➚"),l1l11l_l1_ (u"ࠪࠫ➛"),l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ➜"))
		items = re.findall(l1l11l_l1_ (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡥࡰࡢࡰࡨࡰࡤࡏࡴࡦ࡯࠱࠮ࡄࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࡩ࠯࠭ࡂࡺࡦࡸࠠࡪࡰࡷࡩࡷࡥࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨࠩ➝"),html,re.DOTALL)
		title = l1l11l_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ➞")
		if lang==l1l11l_l1_ (u"ࠧࡦࡰࠪ➟"): title = l1l11l_l1_ (u"ࠨࠢ࠰ࠤࡊࡶࡩࡴࡱࡧࡩࠥ࠭➠")
		if lang==l1l11l_l1_ (u"ࠩࡩࡥࠬ➡"): title = l1l11l_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ➢")
		if lang==l1l11l_l1_ (u"ࠫ࡫ࡧ࠲ࠨ➣"): title = l1l11l_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ➤")
		if lang==l1l11l_l1_ (u"࠭ࡦࡢࠩ➥"): l1lll11l1l1_l1_ = l1l11l_l1_ (u"ࠧࠨ➦")
		else: l1lll11l1l1_l1_ = lang
		l1lll1l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ➧"),html,re.DOTALL)
		for name,count,img,l1111l_l1_ in items:
			for l1ll1ll_l1_ in range(int(count),0,-1):
				l1ll1l111_l1_ = img + l1lll11l1l1_l1_ + id + l1l11l_l1_ (u"ࠩ࠲ࠫ➨") + str(l1ll1ll_l1_) + l1l11l_l1_ (u"ࠪ࠲ࡵࡴࡧࠨ➩")
				#l1111l1ll1_l1_ = l1lll1l1111_l1_[0][0]+lang+id+l1l11l_l1_ (u"ࠫ࠴࠲ࠧ➪")+str(l1ll1ll_l1_)+l1l11l_l1_ (u"ࠬ࠲ࠧ➫")+str(l1ll1ll_l1_)+l1l11l_l1_ (u"࠭࡟ࠨ➬")+l1lll1l1111_l1_[0][2]
				name1 = name + title + str(l1ll1ll_l1_)
				name1 = unescapeHTML(name1)
				addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭➭"),menu_name+name1,url,24,l1ll1l111_l1_,l1l11l_l1_ (u"ࠨࠩ➮"),str(l1ll1ll_l1_))
	elif type==l1l11l_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ➯"):
		url2 = l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡄࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡏࡴࡦ࡯ࡂ࡭ࡩࡃࠧ➰")+str(id)+l1l11l_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ➱")+page+l1l11l_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾࠳ࠪ➲")
		html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"࠭ࠧ➳"),l1l11l_l1_ (u"ࠧࠨ➴"),l1l11l_l1_ (u"ࠨࠩ➵"),l1l11l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ➶"))
		items = re.findall(l1l11l_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡆ࡬ࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭➷"),html,re.DOTALL)
		title = l1l11l_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ➸")
		if lang==l1l11l_l1_ (u"ࠬ࡫࡮ࠨ➹"): title = l1l11l_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ➺")
		if lang==l1l11l_l1_ (u"ࠧࡧࡣࠪ➻"): title = l1l11l_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ➼")
		if lang==l1l11l_l1_ (u"ࠩࡩࡥ࠷࠭➽"): title = l1l11l_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ➾")
		for l1ll1ll_l1_,img,l1111l_l1_,desc,name in items:
			l1ll1llll11_l1_ += 1
			l1ll1l111_l1_ = l1lll11lll1_l1_ + QUOTE(img)
			#l1111l1ll1_l1_ = l1lll11lll1_l1_ + QUOTE(l1111l_l1_)
			name = escapeUNICODE(name)
			name1 = name + title + str(l1ll1ll_l1_)
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ➿"),menu_name+name1,url2,24,l1ll1l111_l1_,l1l11l_l1_ (u"ࠬ࠭⟀"),str(l1ll1llll11_l1_))
	elif type==l1l11l_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⟁"):
		if l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴࠨ⟂") in url and l1l11l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⟃") not in url:
			url2 = l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀࠫ⟄")+str(id)+l1l11l_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⟅")+page+l1l11l_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠵࠭⟆")
			html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠬ࠭⟇"),l1l11l_l1_ (u"࠭ࠧ⟈"),l1l11l_l1_ (u"ࠧࠨ⟉"),l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠶ࡶࡩ࠭⟊"))
			items = re.findall(l1l11l_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⟋"),html,re.DOTALL)
			for img,l1111l_l1_,name,title in items:
				l1ll1llll11_l1_ += 1
				l1ll1l111_l1_ = l1lll11lll1_l1_ + QUOTE(img)
				#l1111l1ll1_l1_ = l1lll11lll1_l1_ + QUOTE(l1111l_l1_)
				name1 = name + l1l11l_l1_ (u"ࠪࠤ࠲ࠦࠧ⟌") + title
				name1 = name1.strip(l1l11l_l1_ (u"ࠫࠥ࠭⟍"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⟎"),menu_name+name1,url2,24,l1ll1l111_l1_,l1l11l_l1_ (u"࠭ࠧ⟏"),str(l1ll1llll11_l1_))
		elif l1l11l_l1_ (u"ࠧࡄ࡮࡬ࡴࡸ࠭⟐") in url:
			url2 = l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿࠳ࠪࡵࡧࡧࡦ࠿ࠪ⟑")+page+l1l11l_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠴࠹ࠬ⟒")
			html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠪࠫ⟓"),l1l11l_l1_ (u"ࠫࠬ⟔"),l1l11l_l1_ (u"ࠬ࠭⟕"),l1l11l_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠵ࡶ࡫ࠫ⟖"))
			items = re.findall(l1l11l_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⟗"),html,re.DOTALL)
			for img,title,l1111l_l1_ in items:
				l1ll1llll11_l1_ += 1
				l1ll1l111_l1_ = l1lll11lll1_l1_ + QUOTE(img)
				#l1111l1ll1_l1_ = l1lll11lll1_l1_ + QUOTE(l1111l_l1_)
				name1 = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ⟘"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⟙"),menu_name+name1,url2,24,l1ll1l111_l1_,l1l11l_l1_ (u"ࠪࠫ⟚"),str(l1ll1llll11_l1_))
		elif l1l11l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⟛") in url:
			if l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠷ࠩ⟜") in url:
				url2 = l1lll11ll1l_l1_+l1l11l_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⟝")+page+l1l11l_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠷ࠩ⟞")
				html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠨࠩ⟟"),l1l11l_l1_ (u"ࠩࠪ⟠"),l1l11l_l1_ (u"ࠪࠫ⟡"),l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠻ࡴࡩࠩ⟢"))
			elif l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠵ࠩ⟣") in url:
				url2 = l1lll11ll1l_l1_+l1l11l_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⟤")+page+l1l11l_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠵ࠩ⟥")
				html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠨࠩ⟦"),l1l11l_l1_ (u"ࠩࠪ⟧"),l1l11l_l1_ (u"ࠪࠫ⟨"),l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠼ࡴࡩࠩ⟩"))
			items = re.findall(l1l11l_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⟪"),html,re.DOTALL)
			for img,l1111l_l1_,name,title in items:
				l1ll1llll11_l1_ += 1
				l1ll1l111_l1_ = l1lll11lll1_l1_ + QUOTE(img)
				#l1111l1ll1_l1_ = l1lll11lll1_l1_ + QUOTE(l1111l_l1_)
				name1 = name + l1l11l_l1_ (u"࠭ࠠ࠮ࠢࠪ⟫") + title
				name1 = name1.strip(l1l11l_l1_ (u"ࠧࠡࠩ⟬"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⟭"),menu_name+name1,url2,24,l1ll1l111_l1_,l1l11l_l1_ (u"ࠩࠪ⟮"),str(l1ll1llll11_l1_))
	if type==l1l11l_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⟯") or type==l1l11l_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⟰"):
		if l1ll1llll11_l1_>25:
			title=l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ⟱")
			if lang==l1l11l_l1_ (u"࠭ࡥ࡯ࠩ⟲"): title = l1l11l_l1_ (u"ࠧࠡࡒࡤ࡫ࡪࠦࠧ⟳")
			if lang==l1l11l_l1_ (u"ࠨࡨࡤࠫ⟴"): title = l1l11l_l1_ (u"ูࠩࠣๆำ็ࠡࠩ⟵")
			if lang==l1l11l_l1_ (u"ࠪࡪࡦ࠸ࠧ⟶"): title = l1l11l_l1_ (u"ࠫࠥ฻แฮ้ࠣࠫ⟷")
			for l1lll111lll_l1_ in range(1,11):
				if not page==str(l1lll111lll_l1_):
					l1ll1llll1l_l1_ = l1l11l_l1_ (u"ࠬ࠶ࠧ⟸")+str(l1lll111lll_l1_)
					addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟹"),menu_name+title+str(l1lll111lll_l1_),url,23,l1l11l_l1_ (u"ࠧࠨ⟺"),l1ll1lll1ll_l1_+l1ll1llll1l_l1_[-2:])
	return
def PLAY(url,l1ll1ll_l1_):
	l1lll11lll1_l1_ = l1lll111l1l_l1_(url)
	l1l1lll_l1_,l1ll1l1l_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠨࠩ⟻"),l1l11l_l1_ (u"ࠩࠪ⟼"),l1l11l_l1_ (u"ࠪࠫ⟽"),l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⟾"))
	# l1l11l1_l1_ l11l1111_l1_ l1l1lll1_l1_
	items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࡢ࠭࠭࠴ࠪࡀࠫࠥࡂࠬ⟿"),html,re.DOTALL)
	if items:
		lang = l1lll11llll_l1_(url)
		parts = url.split(l1l11l_l1_ (u"࠭࠯ࠨ⠀"))
		id,type = parts[-1],parts[3]
		l1111l_l1_ = items[0][0]+lang+id+l1l11l_l1_ (u"ࠧ࠰࠮ࠪ⠁")+l1ll1ll_l1_+l1l11l_l1_ (u"ࠨ࠮ࠪ⠂")+l1ll1ll_l1_+l1l11l_l1_ (u"ࠩࡢࠫ⠃")+items[0][2]
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ⠄"))
		l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l11l1_l1_ l11lll1l_l1_ url
	items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪ࠭࠭ࡢ࠮࠯ࠬࡂ࠭ࠧ࠭⠅"),html,re.DOTALL)
	if items:
		lang = l1lll11llll_l1_(url)
		parts = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧ⠆"))
		id,type = parts[-1],parts[3]
		l1111l_l1_ = items[0][0]+lang+id+l1l11l_l1_ (u"࠭࠯ࠨ⠇")+l1ll1ll_l1_+items[0][2]
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡺࡸ࡬ࠨ⠈"))
		l1ll1l1l_l1_.append(l1111l_l1_)
	# l1l11l1_l1_ l11lll1l_l1_ src
	items = re.findall(l1l11l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⠉"),html,re.DOTALL)
	for l1111l_l1_ in items:
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠩ࠲࠳ࠬ⠊"),l1l11l_l1_ (u"ࠪ࠳ࠬ⠋"))
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠫࡲࡶ࠴ࠡࡵࡵࡧࠬ⠌"))
		l1ll1l1l_l1_.append(l1111l_l1_)
	# l1lll11l1ll_l1_ l11lll1l_l1_ l1l1lll1_l1_
	items = re.findall(l1l11l_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⠍"),html,re.DOTALL)
	if items:
		l1111l_l1_ = items[int(l1ll1ll_l1_)-1]
		l1111l_l1_ = l1lll11lll1_l1_+QUOTE(l1111l_l1_)
		l1l1lll_l1_.append(l1l11l_l1_ (u"࠭࡭ࡱ࠶ࠣࡥࡩࡪࡲࡦࡵࡶࠫ⠎"))
		l1ll1l1l_l1_.append(l1111l_l1_)
	# l1lll11l1ll_l1_ l1lll1l111l_l1_ l1l1lll1_l1_
	items = re.findall(l1l11l_l1_ (u"ࠧࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⠏"),html,re.DOTALL)
	if items:
		l1111l_l1_ = items[int(l1ll1ll_l1_)-1]
		l1111l_l1_ = l1lll11lll1_l1_+QUOTE(l1111l_l1_)
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠨ࡯ࡳ࠷ࠥࡧࡤࡥࡴࡨࡷࡸ࠭⠐"))
		l1ll1l1l_l1_.append(l1111l_l1_)
	# selection
	if len(l1ll1l1l_l1_)==1: l1111l_l1_ = l1ll1l1l_l1_[0]
	else:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ⠑"), l1l1lll_l1_)
		if selection == -1 : return
		l1111l_l1_ = l1ll1l1l_l1_[selection]
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⠒"))
	return
def l1lll111l1l_l1_(url):
	if l11lll_l1_ in url: site = l11lll_l1_
	elif l1ll1ll11l_l1_ in url: site = l1ll1ll11l_l1_
	elif l1lll111ll1_l1_ in url: site = l1lll111ll1_l1_
	elif l1lll11l111_l1_ in url: site = l1lll11l111_l1_
	else: site = l1l11l_l1_ (u"ࠫࠬ⠓")
	return site
def l1lll11llll_l1_(url):
	if   l11lll_l1_ in url: lang = l1l11l_l1_ (u"ࠬࡧࡲࠨ⠔")
	elif l1ll1ll11l_l1_ in url: lang = l1l11l_l1_ (u"࠭ࡥ࡯ࠩ⠕")
	elif l1lll111ll1_l1_ in url: lang = l1l11l_l1_ (u"ࠧࡧࡣࠪ⠖")
	elif l1lll11l111_l1_ in url: lang = l1l11l_l1_ (u"ࠨࡨࡤ࠶ࠬ⠗")
	else: lang = l1l11l_l1_ (u"ࠩࠪ⠘")
	return lang
def l1lll1ll1_l1_(url):
	lang = l1lll11llll_l1_(url)
	url2 = url + l1l11l_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡏ࡭ࡻ࡫ࠧ⠙")
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ⠚"),url2,l1l11l_l1_ (u"ࠬ࠭⠛"),l1l11l_l1_ (u"࠭ࠧ⠜"),l1l11l_l1_ (u"ࠧࠨ⠝"),l1l11l_l1_ (u"ࠨࠩ⠞"),l1l11l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ⠟"))
	html = response.content
	items = re.findall(l1l11l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⠠"),html,re.DOTALL)
	url3 = items[0]
	PLAY_VIDEO(url3,script_name,l1l11l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⠡"))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠬࠦࠧ⠢"),l1l11l_l1_ (u"࠭ࠫࠨ⠣"))
	if showdialogs:
		l1lllll1l1_l1_ = [ l11lll_l1_ , l1ll1ll11l_l1_ , l1lll111ll1_l1_ , l1lll11l111_l1_ ]
		l1lll1l11ll_l1_ = [ l1l11l_l1_ (u"ฺࠧำห๎ࠬ⠤") , l1l11l_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ⠥") , l1l11l_l1_ (u"ࠩไหึู้ࠨ⠦") , l1l11l_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ⠧") ]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่้เษࠡษ็้๋อำษห࠽ࠫ⠨"), l1lll1l11ll_l1_)
		if selection == -1 : return
		website = l1lllll1l1_l1_[selection]
	else:
		if l1l11l_l1_ (u"ࠬࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭⠩") in options: website = l11lll_l1_
		elif l1l11l_l1_ (u"࠭࡟ࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎ࡟ࠨ⠪") in options: website = l1ll1ll11l_l1_
		else: website = l1l11l_l1_ (u"ࠧࠨ⠫")
	if not website: return
	lang = l1lll11llll_l1_(website)
	url2 = website + l1l11l_l1_ (u"ࠣ࠱ࡋࡳࡲ࡫࠯ࡔࡧࡤࡶࡨ࡮࠿ࡴࡧࡤࡶࡨ࡮ࡳࡵࡴ࡬ࡲ࡬ࡃࠢ⠬") + l1l1ll_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ⠭"),l1l11l_l1_ (u"ࠪࠫ⠮"),lang,url2)
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠫࠬ⠯"),l1l11l_l1_ (u"ࠬ࠭⠰"),l1l11l_l1_ (u"࠭ࠧ⠱"),l1l11l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ⠲"))
	items = re.findall(l1l11l_l1_ (u"ࠨࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠬ⠳"),html,re.DOTALL)
	if items:
		for img,category,id,title in items:
			#if category in [l1l11l_l1_ (u"ࠩ࠶ࠫ⠴"),l1l11l_l1_ (u"ࠪ࠹ࠬ⠵"),l1l11l_l1_ (u"ࠫ࠼࠭⠶")]:
			if category in [l1l11l_l1_ (u"ࠬ࠹ࠧ⠷"),l1l11l_l1_ (u"࠭࠷ࠨ⠸")]:
				title = title.replace(l1l11l_l1_ (u"ࠧ࡝࡞ࠪ⠹"),l1l11l_l1_ (u"ࠨࠩ⠺"))
				title = title.replace(l1l11l_l1_ (u"ࠩࠥࠫ⠻"),l1l11l_l1_ (u"ࠪࠫ⠼"))
				if category==l1l11l_l1_ (u"ࠫ࠸࠭⠽"):
					type = l1l11l_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⠾")
					if lang==l1l11l_l1_ (u"࠭ࡡࡳࠩ⠿"): name = l1l11l_l1_ (u"ࠧๆี็ื้ࠦ࠺ࠡࠩ⡀")
					elif lang==l1l11l_l1_ (u"ࠨࡧࡱࠫ⡁"): name = l1l11l_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠽ࠤࠬ⡂")
					elif lang==l1l11l_l1_ (u"ࠪࡪࡦ࠭⡃"): name = l1l11l_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ⡄")
					elif lang==l1l11l_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⡅"): name = l1l11l_l1_ (u"࠭ำา์ส่ࠥํวࠡ࠼ࠣࠫ⡆")
				elif category==l1l11l_l1_ (u"ࠧ࠶ࠩ⡇"):
					type = l1l11l_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⡈")
					if lang==l1l11l_l1_ (u"ࠩࡤࡶࠬ⡉"): name = l1l11l_l1_ (u"ࠪๅ๏๊ๅࠡ࠼ࠣࠫ⡊")
					elif lang==l1l11l_l1_ (u"ࠫࡪࡴࠧ⡋"): name = l1l11l_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࠤ࠿ࠦࠧ⡌")
					elif lang==l1l11l_l1_ (u"࠭ࡦࡢࠩ⡍"): name = l1l11l_l1_ (u"ࠧโ์็้ࠥࡀࠠࠨ⡎")
					elif lang==l1l11l_l1_ (u"ࠨࡨࡤ࠶ࠬ⡏"): name = l1l11l_l1_ (u"ࠩไ่๊ࠦ็ศࠢ࠽ࠤࠬ⡐")
				elif category==l1l11l_l1_ (u"ࠪ࠻ࠬ⡑"):
					type = l1l11l_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⡒")
					if lang==l1l11l_l1_ (u"ࠬࡧࡲࠨ⡓"): name = l1l11l_l1_ (u"࠭ศา่ส้ัࠦ࠺ࠡࠩ⡔")
					elif lang==l1l11l_l1_ (u"ࠧࡦࡰࠪ⡕"): name = l1l11l_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠢ࠽ࠤࠬ⡖")
					elif lang==l1l11l_l1_ (u"ࠩࡩࡥࠬ⡗"): name = l1l11l_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ⡘")
					elif lang==l1l11l_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⡙"): name = l1l11l_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠡ࠼ࠣࠫ⡚")
				title = name + title
				l1111l_l1_ = website + l1l11l_l1_ (u"࠭࠯ࠨ⡛") + type + l1l11l_l1_ (u"ࠧ࠰ࡅࡲࡲࡹ࡫࡮ࡵ࠱ࠪ⡜") + id
				img = QUOTE(img)
				img = website+img
				#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ⡝"),img)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⡞"),menu_name+title,l1111l_l1_,23,img,l1l11l_l1_ (u"ࠪ࠵࠵࠷ࠧ⡟"))
	#else: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⡠"),l1l11l_l1_ (u"ࠬ࠭⡡"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⡢"),,لا توجد نتائج للبحث')
	return
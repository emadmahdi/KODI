# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙ࠨ傸")
contentsDICT = {}
menuItemsLIST = []
l1ll1l1111l1_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢ傹"))
kodi_version = re.findall(l1l11l_l1_ (u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭傺"),l1ll1l1111l1_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11ll1ll11ll_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ傻"))
	l1ll1111l1ll_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ傼"))
	l1l11111llll_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ傽"))
	l11l1l1ll111_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ傾"))
	loglevel = xbmc.LOGINFO
	l1ll1ll1ll1l_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ傿"),l1l11l_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ僀"),l1l11l_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ僁"))
	ltr,rtl = l1l11l_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ僂"),l1l11l_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ僃")
	half_triangular_colon = l1l11l_l1_ (u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭僄")
else:
	l11ll1ll11ll_l1_ = xbmc.translatePath(l1l11l_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ僅"))
	l1ll1111l1ll_l1_ = xbmc.translatePath(l1l11l_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ僆"))
	l1l11111llll_l1_ = xbmc.translatePath(l1l11l_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬ僇"))
	l11l1l1ll111_l1_ = xbmc.translatePath(l1l11l_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ僈"))
	loglevel = xbmc.LOGNOTICE
	l1ll1ll1ll1l_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ僉"),l1l11l_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭僊"),l1l11l_l1_ (u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪ僋"))
	ltr,rtl = l1l11l_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ僌").encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ働")),l1l11l_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩ僎").encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ像"))
	half_triangular_colon = l1l11l_l1_ (u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫ僐").encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ僑"))
addon_handle = int(sys.argv[1])
addon_id = sys.argv[0].split(l1l11l_l1_ (u"ࠬ࠵ࠧ僒"))[2]	# l11l1ll1ll_l1_.l1l1llll11_l1_.l11ll1l111ll_l1_
addon_name = addon_id.split(l1l11l_l1_ (u"࠭࠮ࠨ僓"))[2]		# l11ll1l111ll_l1_
addon_path = sys.argv[2]				# ?mode=12&url=http://test.l11111ll_l1_
#l1l111ll1l1l_l1_ = sys.argv[0]+addon_path		# l11l1ll1ll_l1_://l11l1ll1ll_l1_.l1l1llll11_l1_.l11ll1l111ll_l1_/?mode=12&url=http://test.l11111ll_l1_
#addon_path = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡉࡳࡱࡪࡥࡳࡒࡤࡸ࡭࠭僔"))
addon_version = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡖࡦࡴࡶ࡭ࡴࡴࠨࠨ僕")+addon_id+l1l11l_l1_ (u"ࠩࠬࠫ僖"))
l1lll11111ll_l1_ = os.path.join(l1l11111llll_l1_,l1l11l_l1_ (u"ࠪ࡯ࡴࡪࡩ࠯࡮ࡲ࡫ࠬ僗"))
l1l1ll1lllll_l1_ = os.path.join(l1l11111llll_l1_,l1l11l_l1_ (u"ࠫࡰࡵࡤࡪ࠰ࡲࡰࡩ࠴࡬ࡰࡩࠪ僘"))
l1lll1l1ll1l_l1_ = [l1l11l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧ僙"),l1l11l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧ僚"),l1l11l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪ僛"),l1l11l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪ僜"),l1l11l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪ僝"),l1l11l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧ僞")]
l1ll1ll1ll11_l1_ = l1lll1l1ll1l_l1_+[l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭僟"),l1l11l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ僠"),l1l11l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ僡"),l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡶࡨࡦࡰࡲࡱࡪࡴࡡ࡭ࡇࡐࡅࡉ࠭僢")]		# ,l1l11l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡩ࡯ࡵࡷࡥࡱࡲࡅࡎࡃࡇࠫ僣")
addoncachefolder = os.path.join(l11l1l1ll111_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬ僤")+addon_version+l1l11l_l1_ (u"ࠪ࠲ࡩࡨࠧ僥"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࠨ僦")+addon_version+l1l11l_l1_ (u"ࠬ࠴ࡤࡣࠩ僧"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l11l_l1_ (u"࠭ࡩࡱࡶࡹ࠶ࡩࡧࡴࡢࡡࠪ僨")+addon_version+l1l11l_l1_ (u"ࠧ࠯ࡦࡥࠫ僩"))
l1ll111111l_l1_ = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩ僪"))
#l11ll11ll1l1_l1_ = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠩ࡯ࡥࡸࡺ࡭ࡦࡰࡸ࠲ࡩࡧࡴࠨ僫"))
favoritesfile = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠪࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࠮ࡥࡣࡷࠫ僬"))
dummyiptvfile = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠫࡩࡻ࡭࡮ࡻ࡬ࡴࡹࡼ࠮ࡥࡣࡷࠫ僭"))
fulliptvfile = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠬ࡬ࡵ࡭࡮࡬ࡴࡹࡼ࠮ࡥࡣࡷࠫ僮"))
l1ll1l11l11_l1_ = os.path.join(addoncachefolder,l1l11l_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡦࡤࡸࠬ僯"))
dialogimagefile = os.path.join(addoncachefolder,l1l11l_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭࡟࠱࠲࠳࠴ࡤ࠴ࡰ࡯ࡩࠪ僰"))
addonfolder = xbmcaddon.Addon().getAddonInfo(l1l11l_l1_ (u"ࠨࡲࡤࡸ࡭࠭僱"))
defaulticon = os.path.join(addonfolder,l1l11l_l1_ (u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ僲"))
defaultthumb = os.path.join(addonfolder,l1l11l_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣ࠰ࡳࡲ࡬࠭僳"))
defaultfanart = os.path.join(addonfolder,l1l11l_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲࡯ࡶࡧࠨ僴"))
l1ll1l111l1l_l1_ = os.path.join(addonfolder,l1l11l_l1_ (u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬ僵"))
l11ll111l1l1_l1_ = os.path.join(addonfolder,l1l11l_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ僶"),l1l11l_l1_ (u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨ僷"))
l1l1lllllll1_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ僸"))
l1l1llll1l11_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ價"),l1l11l_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ僺"),addon_id,l1l11l_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ僻"))
l1l111l11l1l_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ僼"),l1l11l_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ僽"),l1l11l_l1_ (u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ僾"))
fontfile = os.path.join(l11ll1ll11ll_l1_,l1l11l_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧ僿"),l1l11l_l1_ (u"ࠩࡉࡳࡳࡺࡳࠨ儀"),l1l11l_l1_ (u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭儁"))
l1l1ll1ll1l1_l1_ = l1l11l_l1_ (u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬ儂")
settings = xbmcaddon.Addon(id=addon_id)
now = int(time.time())
l1l111llll11_l1_ = 60
HOUR = 60*l1l111llll11_l1_
l111lll1l111_l1_ = 24*HOUR
l11llll111l1_l1_ = 30*l111lll1l111_l1_
NO_CACHE = 0
l1l11ll11ll_l1_ = 30*l1l111llll11_l1_
l1111lll_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
l1llll_l1_ = 3*l111lll1l111_l1_
l1llll11l11_l1_ = 30*l111lll1l111_l1_
PERMANENT_CACHE = 12*l11llll111l1_l1_
LIMITED_CACHE = 1*HOUR
l11l111lll11_l1_ = [l1l11l_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ儃"),l1l11l_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ億")]
l11ll11lll1l_l1_ = [l1l11l_l1_ (u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭儅")]
l11ll1ll11l1_l1_ = [l1l11l_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ儆"),l1l11l_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬ儇"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧ儈"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ儉"),l1l11l_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ儊"),l1l11l_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭儋"),l1l11l_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ儌")]
l11ll1ll11l1_l1_ += [l1l11l_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ儍"),l1l11l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ儎"),l1l11l_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ儏"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ儐"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ儑"),l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭儒"),l1l11l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ儓")]
l111lll1lll1_l1_ = [l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠭儔"),l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ儕"),l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ儖"),l1l11l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ儗")]
l111lll1lll1_l1_ += [l1l11l_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ儘"),l1l11l_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ儙"),l1l11l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ儚")]
l111lll1lll1_l1_ += [l1l11l_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ儛"),l1l11l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ儜"),l1l11l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ儝"),l1l11l_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭儞")]		# l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭償")
l111lll1lll1_l1_ += [l1l11l_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ儠"),l1l11l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ儡"),l1l11l_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ儢"),l1l11l_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ儣"),l1l11l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ儤")]
#l111lll1lll1_l1_ += [l1l11l_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ儥"),l1l11l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ儦"),l1l11l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ儧"),l1l11l_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ儨")]
#l111lll1lll1_l1_ += [l1l11l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ儩"),l1l11l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࠬ優"),l1l11l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ儫"),l1l11l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ儬")]
l1lll1l1ll1_l1_ = [l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭儭"),l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ儮"),l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ儯"),l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ儰")]
l1lll1l1ll1_l1_ += [l1l11l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ儱"),l1l11l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ儲"),l1l11l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ儳"),l1l11l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ儴"),l1l11l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ儵")]
l1lll1lllll_l1_ = [l1l11l_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ儶"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ儷"),l1l11l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ儸"),l1l11l_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ儹"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ儺")]
l1lll1lllll_l1_ += [l1l11l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ儻"),l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ儼"),l1l11l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭儽"),l1l11l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ儾")]
#l1lll1lllll_l1_ += [l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭儿"),l1l11l_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ兀")]
l1lllll1ll1_l1_ = [l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭允"),l1l11l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ兂"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ元"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ兄"),l1l11l_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ充")]	# ,l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ兆")
#l1lllll1ll1_l1_ += [l1l11l_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ兇"),l1l11l_l1_ (u"ࠫࡍࡋࡌࡂࡎࠪ先"),l1l11l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ光"),l1l11l_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ兊"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ克"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ兌"),l1l11l_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ免")]
l11l1l11l11l_l1_  = [l1l11l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ兎"),l1l11l_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ兏"),l1l11l_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ児"),l1l11l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ兑"),l1l11l_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭兒"),l1l11l_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ兓"),l1l11l_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ兔"),l1l11l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ兕")]
l11l1l11l11l_l1_ += [l1l11l_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ兖"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ兗"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ兘"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ兙"),l1l11l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ党"),l1l11l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭兛")]
l11l1l11l11l_l1_ += [l1l11l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭兜"),l1l11l_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭兝"),l1l11l_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ兞")]		# l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ兟"),l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ兠"),l1l11l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ兡")
l11l1l11l11l_l1_ += [l1l11l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ兢"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ兣"),l1l11l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭兤"),l1l11l_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ入"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ兦")]
l11l111l11l1_l1_  = [l1l11l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ內"),l1l11l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ全"),l1l11l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ兩"),l1l11l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ兪")]
l11l111l11l1_l1_ += [l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ八"),l1l11l_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ公")]
l11l111l11l1_l1_ += [l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ六"),l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ兮"),l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ兯")]
l11l111l11l1_l1_ += [l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ兰"),l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ共"),l1l11l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ兲")]
#l11l111l11l1_l1_ += [l1l11l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ关"),l1l11l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ兴")]
#l11l111l11l1_l1_ += [l1l11l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࠫ兵"),l1l11l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࠫ其"),l1l11l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࠬ具")]
l11l11l11l1l_l1_ = [l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ典"),l1l11l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ兹"),l1l11l_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ兺"),l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ养")]		# l1l11l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭兼"),l1l11l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ兽")
l1llll1l111_l1_ = l11l1l11l11l_l1_+l11l111l11l1_l1_
l1l1l1lll11_l1_ = l11l1l11l11l_l1_+l11l11l11l1l_l1_
l1l1ll11111_l1_ = l11l1l11l11l_l1_+l11l11l11l1l_l1_+l11l111lll11_l1_
l1llll11lll_l1_ = l111lll1lll1_l1_+l1lll1lllll_l1_+l1lllll1ll1_l1_+l1lll1l1ll1_l1_
NO_EXIT_LIST = [ l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ兾")
				,l1l11l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ兿")
				,l1l11l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ冀")
				,l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨ冁")
				,l1l11l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩ冂")
				,l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪ冃")
				,l1l11l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪ冄")
				,l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫ内")
				,l1l11l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬ円")
				,l1l11l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ冇")
				,l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ冈")
				,l1l11l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ冉")
				,l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨ冊")
				,l1l11l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ冋")
				,l1l11l_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ册")
				,l1l11l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠴ࡷࡹ࠭再")
				,l1l11l_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠶ࡳࡪࠧ冎")
				,l1l11l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪ冏")
				,l1l11l_l1_ (u"࠭ࡍࡆࡐࡘࡗ࠲࡙ࡈࡐ࡙ࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ冐")
				,l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡄࡒࡉࡕࡍࡠࡗࡖࡉࡗࡇࡇࡆࡐࡗ࠱࠶ࡹࡴࠨ冑")
				,l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡃࡉࡇࡆࡏࡤࡇࡃࡄࡑࡘࡒ࡙࠳࠱ࡴࡶࠪ冒")
				,l1l11l_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭冓")
				,l1l11l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ冔")
				#,l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ冕")
				#,l1l11l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ冖")
				#,l1l11l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ冗")
				#,l1l11l_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ冘")
				#,l1l11l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ写")
				#,l1l11l_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡌࡋࡔࡠࡎࡄࡘࡊ࡙ࡔࡠࡘࡈࡖࡘࡏࡏࡏࡡࡑ࡙ࡒࡈࡅࡓࡕ࠰࠵ࡸࡺࠧ冚")
				#,l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ军")
				#,l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ农")
				#,l1l11l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ冝")
				]
# l11ll1l111l1_l1_ will not show l11lll1l1l1l_l1_ errors
UNIMPORTANT_REQUESTS = [
						l1l11l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ冞")
						,l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ冟")
						]
l1l1ll11l1l1_l1_ = [l1l11l_l1_ (u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ冠"),l1l11l_l1_ (u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ冡"),l1l11l_l1_ (u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫ冢"),l1l11l_l1_ (u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬ冣"),l1l11l_l1_ (u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭冤"),l1l11l_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧ冥")]
WEBSITES = {
			#,l1l11l_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ冦")	:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬ冧")]
			#,l1l11l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ冨")	:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴࡮ࡦࡶࠪ冩")]
			#,l1l11l_l1_ (u"ࠫࡊࡍ࡙࠵ࡄࡈࡗ࡙࠭冪")	:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ冫")]
			#,l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ冬")	:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭冭")]
			#,l1l11l_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ冮")		:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠸࡭࡫࡬ࡢ࡮࠱ࡱࡪ࠭冯")]
			#,l1l11l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭冰")	:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥࠨ冱"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨࠫ冲")]
			#,l1l11l_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭决")		:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡳ࡯ࡷࡵ࠷ࡹ࠳ࡽࡳࠨ冴")]
			#,l1l11l_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ况"):[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠭冶")]
			#,l1l11l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭冷")	:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠯ࡥࡲࡱࠬ冸")]
			 l1l11l_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ冹")		:[l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡲࡥࡲ࠴࡮ࡦࡶࠪ冺")]
			,l1l11l_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭冻")		:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸࠬ冼")]
			,l1l11l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ冽")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡵࡤ࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬ冾")]
			,l1l11l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭冿")		:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬ࡧࡣࡷ࡭ࡲ࡯࠮ࡵࡸࠪ净")]
			,l1l11l_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ凁")	:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡬࡬ࡣࡺࡸ࡭ࡧࡲࡵࡸ࠱࡭ࡷ࠭凂")]
			,l1l11l_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ凃")		:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡱࡳࡡࡢࡴࡨࡪ࠳ࡩࡨࠨ凄")]
			,l1l11l_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ凅")		:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫ准")]
			,l1l11l_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ凇")		:[l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡩࡱࡲࡪࡻࡵࡤ࠯ࡥࡲࡱࠬ凈")]
			,l1l11l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ凉")		:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠴ࡧ࡮ࡳࡡ࠵ࡷ࠱ࡧࡴࡳࠧ凊")]
			,l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ凋")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡣࡥࡨࡴ࠴ࡣࡰ࡯ࠪ凌")]
			,l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭凍")		:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣ࠰࡬ࡳࠬ凎")]
			,l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ减")		:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫ凐")]
			,l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ凑")	:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠴ࡣࡰ࡯ࠪ凒")]
			,l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ凓")	:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪ࠷ࡹ࠳ࡴࡥࡸࡵࠪ凔")]
			,l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭凕")		:[l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠲ࡴ࡯ࡸ࠰ࡦࡳࡲ࠭凖")]
			,l1l11l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ凗")	:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ凘"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ凙")]
			#,l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ凚")		:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡴࡥࡵࠩ凛")]
			,l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭凜")		:[l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡨࡪࡧࡤ࠯࡮࡬ࡺࡪ࠭凝")]
			#,l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ凞")		:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡥࡨࡻࡱࡳࡼ࠴࡬ࡪࡸࡨࠫ凟")]
			,l1l11l_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ几")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪ凡")]
			,l1l11l_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ凢")	:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࡬ࡨࡶ࠳ࡹࡨࡰࡹࠪ凣")]
			,l1l11l_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ凤")		:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡲࡦࡦࠪ凥")]
			,l1l11l_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ処")		:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬ凧")]
			,l1l11l_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ凨")		:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮ࡶࡵࠪ凩")]
			,l1l11l_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ凪")		:[l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ凫"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ凬"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ凭"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ凮"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ凯")]
			,l1l11l_l1_ (u"ࠫࡎࡖࡔࡗࠩ凰")			:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡮ࡰࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰࠫ凱")]
			,l1l11l_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ凲")	:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡤࡶࡧࡧ࡬ࡢ࠯ࡷࡺ࠳࡯ࡱࠨ凳")]
			,l1l11l_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ凴")	:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭凵"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧ࡯ࡴ࠯࡮ࡼ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭凶")]
			,l1l11l_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ凷")		:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮ࡤࡣࡰࠫ凸")]
			#,l1l11l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭凹")		:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡲࠫ出")]
			,l1l11l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ击")		:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪࡩࡩ࡮ࡣ࠱ࡸࡺࡨࡥࠨ凼")]
			,l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ函")		:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭凾")]
			#,l1l11l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ凿")		:[l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ刀"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭刁"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ刂"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ刃"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ刄"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ刅"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ分")]
			#,l1l11l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭切")		:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ刈"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ刉"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ刊"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ刋"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ刌"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ刍"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ刎")]
			#,l1l11l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ刏")		:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ刐"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ刑"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ划"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ刓"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ刔"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭刕"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ刖")]
			#,l1l11l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ列")		:[l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ刘"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ则"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ刚"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ创"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ刜"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ初"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ刞")]
			#,l1l11l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ刟")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭删"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ刡"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ刢"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ刣"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ判"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ別"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ刦")]
			,l1l11l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ刧")		:[l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ刨"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ利"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ刪"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭别"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭刬"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ刭"),l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ刮")]
			#,l1l11l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ刯")		:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠭到"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭刱"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ刲"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ刳")]
			,l1l11l_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ刴")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲࠫ刵"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ制"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ刷"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ券")]
			,l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ刹")		:[l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮࠵࠳࡯ࡳࡩࡣ࡫ࡩࡩ࠺ࡵ࠯ࡵ࡬ࡸࡪ࠭刺")]
			,l1l11l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ刻")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ刼"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ刽"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ刾")]
			#,l1l11l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ刿")	:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࠱ࡷ࡭ࡵ࡯ࡧࡲࡵࡳ࠳ࡵ࡮࡭࡫ࡱࡩࠬ剀")]    #	l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡱࡴࡲ࠲ࡨࡵ࡭ࠨ剁")
			,l1l11l_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ剂")		:[l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡦࡶࡰ࠱ࡱࡪ࠭剃")]
			,l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ剄")		:[l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ剅")]
			,l1l11l_l1_ (u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ剆")		:[l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡮ࡳࡩ࡯ࠧ則"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡸࡻࡲࡨࡧ࠱ࡷ࡭࠵࡫ࡰࡦ࡬ࠫ剈")]
			}
class dummy_object(): pass
class l11l11l11lll_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l1l11l111l1l_l1_ = -1
	def onClick(self,l11lll111111_l1_):
		if l11lll111111_l1_>=9010: self.l1l11l111l1l_l1_ = l11lll111111_l1_-9010
		self.delete()
	def l1l11111l111_l1_(self,*args):
		#self.getControl(9001).l1ll1lll11l_l1_(header)
		#self.getControl(9009).l1l1ll1l111l_l1_(text)
		#self.getControl(9010).l1ll1lll11l_l1_(button0)
		#self.getControl(9011).l1ll1lll11l_l1_(button1)
		#self.getControl(9012).l1ll1lll11l_l1_(button2)
		self.button0,self.button1,self.button2 = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1l1lllll111_l1_ = args[5],args[6]
		self.image_width,self.l111lll11lll_l1_,self.l11l1111l1ll_l1_ = args[7],args[8],args[9]
		if self.l111lll11lll_l1_>0 or self.l11l1111l1ll_l1_>0: self.enable_progressbar = True
		else: self.enable_progressbar = False
		self.image_filename,self.image_height = CREATE_IMAGE(self.button0,self.button1,self.button2,self.header,self.text,self.profile,self.l1l1lllll111_l1_,self.image_width,self.enable_progressbar)
		self.show()
		self.getControl(9050).setImage(self.image_filename)
		self.getControl(9050).setHeight(self.image_height)
		if not self.button1 and self.button0 and self.button2: self.getControl(9012).setPosition(-220,0)
		return self.image_filename,self.image_height
	def l1l11l11111l_l1_(self):
		if self.l111lll11lll_l1_:
			import threading
			self.l11l11lll1ll_l1_ = threading.Thread(target=self.l11l1ll111l1_l1_,args=())
			self.l11l11lll1ll_l1_.start()
			#self.l11l11lll1ll_l1_.join()
		else: self.enableButtons()
	def l11l1ll111l1_l1_(self):
		self.getControl(9020).setEnabled(True)
		for ii in range(1,self.l111lll11lll_l1_+1):
			time.sleep(1)
			l111lll1l1ll_l1_ = int(100*ii/self.l111lll11lll_l1_)
			self.l11ll111l111_l1_(l111lll1l1ll_l1_)
			if self.l1l11l111l1l_l1_>0: break
		self.enableButtons()
	def l1l111ll1l11_l1_(self):
		if self.l11l1111l1ll_l1_:
			import threading
			self.l11l11llll11_l1_ = threading.Thread(target=self.l11ll1l11lll_l1_,args=())
			self.l11l11llll11_l1_.start()
			#self.l11l11llll11_l1_.join()
		else: self.enableButtons()
	def l11ll1l11lll_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l111lll11lll_l1_)
		for ii in range(self.l11l1111l1ll_l1_-1,-1,-1):
			time.sleep(1)
			l111lll1l1ll_l1_ = int(100*ii/self.l11l1111l1ll_l1_)
			self.l11ll111l111_l1_(l111lll1l1ll_l1_)
			if self.l1l11l111l1l_l1_>0: break
		if self.l11l1111l1ll_l1_>0: self.l1l11l111l1l_l1_ = 10
		self.delete()
	def l11ll111l111_l1_(self,l111lll1l1ll_l1_):
		self.l11ll1l11111_l1_ = l111lll1l1ll_l1_
		self.getControl(9020).setPercent(self.l11ll1l11111_l1_)
	def enableButtons(self):
		if self.button0!=l1l11l_l1_ (u"ࠩࠪ剉"): self.getControl(9010).setEnabled(True)
		if self.button1!=l1l11l_l1_ (u"ࠪࠫ削"): self.getControl(9011).setEnabled(True)
		if self.button2!=l1l11l_l1_ (u"ࠫࠬ剋"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.image_filename)
		except: pass
		#del self
	l1l11l_l1_ (u"ࠧࠨࠢࠎࠌࠌࡨࡪ࡬ࠠࡶࡲࡧࡥࡹ࡫ࠨࡴࡧ࡯ࡪ࠱ࡶࡥࡳࡥࡨࡲࡹ࠲ࠪࡢࡴࡪࡷ࠮ࡀࠍࠋࠋࠌࡸࡪࡾࡴࠡ࠿ࠣࡥࡷ࡭ࡳ࡜࠲ࡠࠑࠏࠏࠉࡪࡨࠣࡰࡪࡴࠨࡢࡴࡪࡷ࠮ࡄ࠱࠻ࠢࡷࡩࡽࡺࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࡣࡵ࡫ࡸࡡ࠱࡞ࠏࠍࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡧࡲࡨࡵࠬࡂ࠷ࡀࠠࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࡡࡳࡩࡶ࡟࠷ࡣࠍࠋࠋࠌࡷࡪࡲࡦ࠯ࡲࡨࡶࡨ࡫࡮ࡵ࠮ࡶࡩࡱ࡬࠮ࡵࡧࡻࡸࠥࡃࠠࡱࡧࡵࡧࡪࡴࡴ࠭ࡶࡨࡼࡹࠓࠊࠊࠋࡶࡩࡱ࡬࠮ࡪ࡯ࡤ࡫ࡪࡥࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡮ࡥࡪࡩ࡫ࡸࠥࡃࠠࡴࡧ࡯ࡪ࠳ࡩࡲࡦࡣࡷࡩࡘ࡮࡯ࡸࡋࡰࡥ࡬࡫ࠨࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲ࠵࠲ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱ࠵࠱ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠵࠰ࡸ࡫࡬ࡧ࠰࡫ࡩࡦࡪࡥࡳ࠮ࡶࡩࡱ࡬࠮ࡵࡧࡻࡸ࠱ࡹࡥ࡭ࡨ࠱ࡴࡷࡵࡦࡪ࡮ࡨ࠰ࡸ࡫࡬ࡧ࠰ࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲ࠱ࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡࡺ࡭ࡩࡺࡨ࠭ࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳࡹࡴࡪ࡯ࡨࡳࡺࡺࠬࡴࡧ࡯ࡪ࠳ࡩ࡬ࡰࡵࡨࡸ࡮ࡳࡥࡰࡷࡷ࠭ࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡵࡱࡦࡤࡸࡪࡖࡲࡰࡩࡵࡩࡸࡹࡂࡢࡴࠫࡴࡪࡸࡣࡦࡰࡷ࠭ࠒࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠬࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡭࡫ࡩࡨࡪࡷࠑࠏࠏࠢࠣࠤ剌")
class l11ll1llll11_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l1l11l_l1_ (u"࠭ࠧ前")
	def onPlayBackStopped(self):
		self.status=l1l11l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ剎")
	def onPlayBackStarted(self):
		if l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ剏")):
			self.stop()
			self.status=l1l11l_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ剐")
		else: self.status=l1l11l_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ剑")
		time.sleep(1)
	def onPlayBackError(self):
		self.status=l1l11l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ剒")
	def onPlayBackEnded(self):
		self.status=l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ剓")
class l11ll11llll_l1_():
	def __init__(self,showDialogs=False,l11l1l111ll1_l1_=True):
		self.showDialogs = showDialogs
		self.l11l1l111ll1_l1_ = l11l1l111ll1_l1_
		self.l1l1111l1111_l1_,self.l1l11l11llll_l1_ = [],[]
		self.l11lll11111l_l1_,self.l11ll1lll11l_l1_ = {},{}
		self.l11llll1l11l_l1_ = []
		self.l111llllll1l_l1_,self.l11ll11lll11_l1_,self.l1l111llll1l_l1_ = {},{},{}
	def l11llllllll1_l1_(self,id,func,*args):
		id = str(id)
		self.l11lll11111l_l1_[id] = l1l11l_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ剔")
		if self.showDialogs: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧࠨ剕"),id)
		# l1lll111ll11_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1lll111ll11_l1_ 2 & 3
		import threading
		l1l11l11l111_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l11llll1l11l_l1_.append(l1l11l11l111_l1_)
		#l1l11l11l111_l1_.start()
		return l1l11l11l111_l1_
	def start_new_thread(self,id,func,*args):
		l1l11l11l111_l1_ = self.l11llllllll1_l1_(id,func,*args)
		l1l11l11l111_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l111llllll1l_l1_[id] = time.time()
		#LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ剖"),l1l11l_l1_ (u"ࠩࡷ࡬ࡷ࡫ࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣ࡭ࡩࡀࠠࠨ剗")+id)
		try:
			#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ剘"),l1l11l_l1_ (u"ࠫࡊࡓࡁࡅ࠼࠽ࠤࠬ剙")+str(func))
			self.l11ll1lll11l_l1_[id] = func(*args)
			if l1l11l_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭剚") in str(func) and not self.l11ll1lll11l_l1_[id].succeeded:
				FORCED_EXIT(l1l11l_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬ剛"))
			self.l1l1111l1111_l1_.append(id)
			self.l11lll11111l_l1_[id] = l1l11l_l1_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ剜")
			#LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ剝"),l1l11l_l1_ (u"ࠩࡷ࡬ࡷ࡫ࡡࡥࠢࡩ࡭ࡳ࡯ࡳࡩࡧࡧࠤ࡮ࡪ࠺ࠡࠩ剞")+id)
		except Exception as err:
			#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ剟"),l1l11l_l1_ (u"ࠫࡹ࡮ࡲࡦࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤ࡮ࡪ࠺ࠡࠩ剠")+id)
			if self.l11l1l111ll1_l1_:
				errortrace = traceback.format_exc()
				sys.stderr.write(errortrace)
				#traceback.print_exc(file=sys.stderr)
			self.l1l11l11llll_l1_.append(id)
			self.l11lll11111l_l1_[id] = l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ剡")
		self.l11ll11lll11_l1_[id] = time.time()
		self.l1l111llll1l_l1_[id] = self.l11ll11lll11_l1_[id] - self.l111llllll1l_l1_[id]
	def l11l1l111l1l_l1_(self):
		for proc in self.l11llll1l11l_l1_:
			proc.start()
	def l111llll1111_l1_(self):
		while l1l11l_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ剢") in list(self.l11lll11111l_l1_.values()): time.sleep(1.000)
def l11l1l11ll11_l1_():
	l11l11ll111l_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ剣"))
	if l11l11ll111l_l1_==addon_version:
		status = l1l11l_l1_ (u"ࠨࡐࡒࡣ࡚ࡖࡄࡂࡖࡈࠫ剤")
	elif not os.path.exists(addoncachefolder):
		status = l1l11l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ剥")
		os.makedirs(addoncachefolder)
	elif os.path.exists(main_dbfile) and os.path.exists(iptv1_dbfile) and os.path.exists(iptv2_dbfile):
		status = l1l11l_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ剦")
	else:
		status = l1l11l_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ剧")
		l11l1ll11ll1_l1_,l11l1ll1l11l_l1_,l11l1l1ll11l_l1_ = False,False,False
		l1l111l111ll_l1_ = [l1l11l_l1_ (u"ࠬ࠾࠮࠶࠰࠳ࠫ剨"),l1l11l_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ剩"),l1l11l_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬ剪"),l1l11l_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬ剫"),l1l11l_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭剬"),l1l11l_l1_ (u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧ剭"),l1l11l_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨ剮"),l1l11l_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩ副")]
		l11ll111l11l_l1_ = l1l111l111ll_l1_[-1]
		l11lll1ll111_l1_ = l111lll1l1l1_l1_(l11ll111l11l_l1_)
		l11l1lll1lll_l1_ = l111lll1l1l1_l1_(addon_version)
		if l11l1lll1lll_l1_>l11lll1ll111_l1_:
			files = os.listdir(addoncachefolder)
			files = sorted(files,reverse=True)
			for filename in files:
				if l1l11l_l1_ (u"࠭ࡤࡢࡶࡤࡣࠬ剰") in filename and l1l11l_l1_ (u"ࠧ࠯ࡦࡥࠫ剱") in filename:
					l11ll11l1lll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦࡥࠨ࠯ࠬࡂ࠭ࡡ࠴ࡤࡣࠩ割"),filename,re.DOTALL)
					l11ll11l1lll_l1_ = l11ll11l1lll_l1_[0]
					l1l11111ll11_l1_ = l111lll1l1l1_l1_(l11ll11l1lll_l1_)
					if l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬ剳") in filename:
						if l1l11111ll11_l1_>=l11lll1ll111_l1_:
							l1l111l1lll1_l1_ = os.path.join(addoncachefolder,filename)
							try:
								if l1l111l1lll1_l1_!=main_dbfile: os.rename(l1l111l1lll1_l1_,main_dbfile)
								l11l1ll11ll1_l1_ = True
							except: pass
					elif l1l11l_l1_ (u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥࠧ剴") in filename:
						if l1l11111ll11_l1_>=l11lll1ll111_l1_:
							l1l111l1lll1_l1_ = os.path.join(addoncachefolder,filename)
							try:
								if l1l111l1lll1_l1_!=iptv1_dbfile: os.rename(l1l111l1lll1_l1_,iptv1_dbfile)
								l11l1ll1l11l_l1_ = True
							except: pass
					elif l1l11l_l1_ (u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࠨ創") in filename:
						if l1l11111ll11_l1_>=l11lll1ll111_l1_:
							l1l111l1lll1_l1_ = os.path.join(addoncachefolder,filename)
							try:
								if l1l111l1lll1_l1_!=iptv2_dbfile: os.rename(l1l111l1lll1_l1_,iptv2_dbfile)
								l11l1l1ll11l_l1_ = True
							except: pass
					if l11l1ll11ll1_l1_ and l11l1ll1l11l_l1_ and l11l1l1ll11l_l1_:
						status = l1l11l_l1_ (u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬ剶")
						break
	return status
def l11ll1l1lll1_l1_():
	script_name = l1l11l_l1_ (u"࠭ࡍࡂࡋࡑࡑࡊࡔࡕࠨ剷")
	succeeded,updateListing,cacheToDisc = True,False,False
	menuItem = EXTRACT_KODI_PATH(addon_path)
	type,l1l1111ll11l_l1_,l11l1ll11lll_l1_,mode,l11l1111llll_l1_,l11ll11l1ll1_l1_,text,context,infodict = menuItem
	l11l11111ll1_l1_ = type,l1l1111ll11l_l1_,l11l1ll11lll_l1_,mode,l11l1111llll_l1_,l1l11l_l1_ (u"ࠧࠨ剸"),text,l1l11l_l1_ (u"ࠨࠩ剹"),l1l11l_l1_ (u"ࠩࠪ剺")
	l11l1l111111_l1_ = int(mode)
	l11llllll111_l1_ = int(l11l1l111111_l1_%10)
	l1l1l1l11ll_l1_ = int(l11l1l111111_l1_/10)
	#l1l1lll1l1_l1_ = l1l1ll1l1l_l1_()
	l111l111lll_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ剻"))
	l111l111lll_l1_ = l111l111lll_l1_.replace(ltr,l1l11l_l1_ (u"ࠫࠬ剼")).replace(rtl,l1l11l_l1_ (u"ࠬ࠭剽"))
	if l11l1l111111_l1_==260: message = l1l11l_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ剾")+addon_version+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ剿")+l1ll1l1111l1_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫ劀")
	else:
		l1l111lll1l1_l1_ = UNQUOTE(addon_path).replace(l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ劁"),l1l11l_l1_ (u"ࠪࠫ劂")).replace(l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ劃"),l1l11l_l1_ (u"ࠬ࠭劄"))
		l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ劅"),l1l11l_l1_ (u"ࠧࠨ劆")).strip(l1l11l_l1_ (u"ࠨࠢࠪ劇"))
		l1l111lll1l1_l1_ = l1l111lll1l1_l1_.replace(l1l11l_l1_ (u"ࠩࠣࠤࠥࠦࠧ劈"),l1l11l_l1_ (u"ࠪࠤࠬ劉")).replace(l1l11l_l1_ (u"ࠫࠥࠦࠠࠨ劊"),l1l11l_l1_ (u"ࠬࠦࠧ劋")).replace(l1l11l_l1_ (u"࠭ࠠࠡࠩ劌"),l1l11l_l1_ (u"ࠧࠡࠩ劍"))
		message = l1l11l_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ劎")+l111l111lll_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ劏")+mode+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ劐")+l1l111lll1l1_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠧ劑")
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ劒"),LOGGING(script_name)+message)
	#text = text.replace(l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ劓"),l1l11l_l1_ (u"ࠧࠨ劔"))
	refresh = settings.getSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ劕"))
	l1l1llll11ll_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ劖"))
	l1l1lll1l1_l1_ = RESTORE_PATH_NAME(l111l111lll_l1_)
	l1l1111ll11l_l1_ = RESTORE_PATH_NAME(l1l1111ll11l_l1_)
	l11ll1lllll1_l1_ = [0,15,17,19,26,34,50,53]
	l11l1l1l11l1_l1_ = [0,15,17,19,26,34,50,53]
	l1l111llllll_l1_ = l1l1l1l11ll_l1_ not in l11l1l1l11l1_l1_
	IPTV = l1l1l1l11ll_l1_ in [23,28] and text
	l11l1ll1llll_l1_ = l11l1l111111_l1_ in [265,270]
	l11ll11l111l_l1_ = (l1l111llllll_l1_ or IPTV) and not l11l1ll1llll_l1_
	l1l11l11l11l_l1_ = refresh!=l1l11l_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭劗") and (refresh!=l1l11l_l1_ (u"ࠫࠬ劘") or context==l1l11l_l1_ (u"ࠬ࠭劙"))
	l11llll1l1ll_l1_ = l1l11l_l1_ (u"࠭ࡴࡺࡲࡨࡁࠬ劚") in refresh
	l1l11l1llll_l1_ = l11l1l111111_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l11llllll111_l1_==9 or l11l1l111111_l1_ in [145,516,523]
	l1l111ll1ll1_l1_ = not l1l11l1llll_l1_
	l1l11111ll1l_l1_ = not SEARCH
	l11l1lll1l11_l1_ = l1l1lll1l1_l1_ in [l1l11l_l1_ (u"ࠧࠨ力"),l1l11l_l1_ (u"ࠨ࠰࠱ࠫ劜")]
	l11lll1l1l11_l1_ = l11l1lll1l11_l1_ or l1l111ll1ll1_l1_
	l11ll1ll111l_l1_ = l11l1lll1l11_l1_ or l1l11111ll1l_l1_ or l11llll1l1ll_l1_
	l11l1111l11l_l1_ = l11l1l111111_l1_ not in [260,265,270,330,540]
	if l1l1llll11ll_l1_: l11lll1l111l_l1_ = SEARCH or l1l11l1llll_l1_
	else: l11lll1l111l_l1_ = True
	l11ll11ll11l_l1_ = l11l1111l11l_l1_ and l11lll1l1l11_l1_ and l11ll1ll111l_l1_ and l11lll1l111l_l1_
	l11l1l1l11ll_l1_ = l11l1111l11l_l1_ and l11lll1l111l_l1_
	if 1 and l1l11l11l11l_l1_ and l11ll11ll11l_l1_:
		DirectoryItems_List = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ劝"),l1l11l_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ办"),[l11l11111ll1_l1_])
		if DirectoryItems_List:
			#xbmcgui.Dialog().l11l111l1111_l1_(l1l11l_l1_ (u"ࠫࠬ功"),l1l11l_l1_ (u"ࠬࡸࡥࡢࡦ࡬ࡲ࡬ࠦࡣࡢࡥ࡫ࡩࠬ加"),l1l11l_l1_ (u"࠭ࠧ务"),100,False)
			#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ劢"),refresh)
			if 1 and l11llll1l1ll_l1_:
				#xbmcgui.Dialog().l11l111l1111_l1_(l1l11l_l1_ (u"ࠨࠩ劣"),l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡺ࡫ࡱ࡫ࠥ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ劤"),l1l11l_l1_ (u"ࠪࠫ劥"),100,False)
				l1l111ll11l1_l1_ = []
				import l1ll11l111l_l1_,FAVORITES
				MENUS__LAST_VIDEOS_MENU = l1ll11l111l_l1_.l1ll11l1l11_l1_
				FAVORITES_FILE_DICT = FAVORITES.GET_ALL_FAVORITES()
				l11lll1111l1_l1_ = refresh
				l1l11111l1l1_l1_,l1l1111l111l_l1_,l1l1ll1l1l1_l1_,l11l11lll1l1_l1_,l1l111l1l11l_l1_,l11ll1l1ll11_l1_,l1l1111l11l1_l1_,l11l1l1l1lll_l1_,l11ll1l1l111_l1_ = EXTRACT_KODI_PATH(l11lll1111l1_l1_)
				l11l1lll11ll_l1_ = l1l11111l1l1_l1_,l1l1111l111l_l1_,l1l1ll1l1l1_l1_,l11l11lll1l1_l1_,l1l111l1l11l_l1_,l1l11l_l1_ (u"ࠫࠬ劦"),l1l1111l11l1_l1_,l1l11l_l1_ (u"ࠬ࠭劧"),l1l11l_l1_ (u"࠭ࠧ动")
				#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ助"),str(l11l1lll11ll_l1_))
				for list_item in DirectoryItems_List:
					l11l11l1l11l_l1_ = list_item[l1l11l_l1_ (u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ努")]
					#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ劫"),str(l11l11l1l11l_l1_))
					if l11l11l1l11l_l1_==l11l1lll11ll_l1_ or list_item[l1l11l_l1_ (u"ࠪࡱࡴࡪࡥࠨ劬")] in [265,270]:
						list_item = GET_LIST_ITEM(l11l11l1l11l_l1_,MENUS__LAST_VIDEOS_MENU,FAVORITES_FILE_DICT)
						if list_item[l1l11l_l1_ (u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ劭")]:
							#xbmcgui.Dialog().l11l111l1111_l1_(l1l11l_l1_ (u"ࠬ࠭劮"),l1l11l_l1_ (u"࠭ࡵࡱࡦࡤࡸ࡮ࡴࡧࠡࡥࡲࡲࡹ࡫ࡸࡵࠩ劯"),l1l11l_l1_ (u"ࠧࠨ劰"),100,False)
							l11l11ll11l1_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(FAVORITES_FILE_DICT,l11l11l1l11l_l1_,list_item[l1l11l_l1_ (u"ࠨࡰࡨࡻࡵࡧࡴࡩࠩ励")])
							#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ劲"),str(l11l11ll11l1_l1_))
							#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ劳"),str(list_item[l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪ労")]))
							list_item[l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ劵")] = l11l11ll11l1_l1_+list_item[l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ劶")]
					l1l111ll11l1_l1_.append(list_item)
				settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ劷"),l1l11l_l1_ (u"ࠨࠩ劸"))
				if type==l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ効"): WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ劺"),[l11l11111ll1_l1_],l1l111ll11l1_l1_,REGULAR_CACHE)
			else: l1l111ll11l1_l1_ = DirectoryItems_List
			if type==l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ劻") and l1l1lll1l1_l1_!=l1l11l_l1_ (u"ࠬ࠴࠮ࠨ劼") and l11ll11l111l_l1_: l11lll11lll1_l1_()
			addItems_succeeded = CREATE_KODI_MENU(l1l111ll11l1_l1_,succeeded,updateListing,cacheToDisc)
			#xbmcgui.Dialog().l11l111l1111_l1_(l1l11l_l1_ (u"࠭ࠧ劽"),l1l11l_l1_ (u"ࠧࡤࡴࡨࡥࡹ࡯࡮ࡨࠢࡰࡩࡳࡻࠧ劾"),l1l11l_l1_ (u"ࠨࠩ势"),100,False)
			return
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ勀"),addon_path)
	#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ勁"),refresh)
	elif type==l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ勂") and refresh==l1l11l_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ勃") and l11l1l1l11ll_l1_:
		DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࠫ勄"),[l11l11111ll1_l1_])
	#context = l1l11l_l1_ (u"ࠧࠨ勅")
	if l1l11l_l1_ (u"ࠨࡡࠪ勆") in context: l11l1111l1l1_l1_,context2 = context.split(l1l11l_l1_ (u"ࠩࡢࠫ勇"),1)
	else: l11l1111l1l1_l1_,context2 = context,l1l11l_l1_ (u"ࠪࠫ勈")
	if l11l1111l1l1_l1_ in [l1l11l_l1_ (u"ࠫ࠶࠭勉"),l1l11l_l1_ (u"ࠬ࠸ࠧ勊"),l1l11l_l1_ (u"࠭࠳ࠨ勋"),l1l11l_l1_ (u"ࠧ࠵ࠩ勌"),l1l11l_l1_ (u"ࠨ࠷ࠪ勍")] and context2:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭勎") l1l1l1ll1l_l1_ l11l111l1ll1_l1_ l11l1111111l_l1_ is no addon_handle l11l111l1ll_l1_ to l1l111l11111_l1_ for l11ll11l11l1_l1_ directory
		#l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠭勏") l1l1l1ll1l_l1_ to open a l1lllll1ll_l1_ list l1lllllll1ll_l1_ l11l111ll1ll_l1_ addon_path
		#xbmc.executebuiltin(l1l11l_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ勐")+sys.argv[0]+addon_path.split(l1l11l_l1_ (u"ࠬࠬࡣࡰࡰࡷࡩࡽࡺ࠽ࠨ勑"))[0]+l1l11l_l1_ (u"࠭ࠦࡤࡱࡱࡸࡪࡾࡴ࠾࠲ࠪ勒")+l1l11l_l1_ (u"ࠢࠪࠤ勓"))
		#xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ勔")+addon_id+l1l11l_l1_ (u"ࠩ࠲ࡃࡹ࡫ࡸࡵ࠿ࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢ࠭ࠬ動"))
		settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ勖"),addon_path)
		#settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ勗"),l1l11l_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ勘"))
		xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ務"))
		return
	elif l11l1111l1l1_l1_==l1l11l_l1_ (u"ࠧ࠷ࠩ勚"):
		if context2==l1l11l_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ勛"): DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ勜"),l1l11l_l1_ (u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ勝"))
		elif context2==l1l11l_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠫ勞"): mode = 334
		results = l1l11llllll_l1_(type,l1l1111ll11l_l1_,l11l1ll11lll_l1_,mode,l11l1111llll_l1_,l11ll11l1ll1_l1_,text,context,infodict)
		settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ募"),l1l11l_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ勠"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ勡"))
		return
	elif context==l1l11l_l1_ (u"ࠨ࠹ࠪ勢"):
		import l111l111l1_l1_
		l111l111l1_l1_.l1llll11111_l1_()
		settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭勣"),l1l11l_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭勤"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ勥"))
		return
	elif context==l1l11l_l1_ (u"ࠬ࠾ࠧ勦"):
		settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ勧"),l1l11l_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ勨"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ勩")+addon_id+l1l11l_l1_ (u"ࠩࡂࡱࡴࡪࡥ࠾ࠩ勪")+str(mode)+l1l11l_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠫࠪ勫"))
		return
	elif context==l1l11l_l1_ (u"ࠫ࠾࠭勬"):
		# l11l1l11l1l1_l1_ update the l111llll1lll_l1_ l1lllll1ll_l1_
		#results = l1l11llllll_l1_(type,l1l1111ll11l_l1_,l11l1ll11lll_l1_,mode,l11l1111llll_l1_,l11ll11l1ll1_l1_,text,context,infodict)
		# l11l1l11l1l1_l1_ update the l11l1lll111l_l1_ l1lllll1ll_l1_
		settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ勭"),l1l11l_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ勮"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ勯"))
		return
	if settings.getSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ勰")) not in [l1l11l_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ勱"),l1l11l_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ勲"),l1l11l_l1_ (u"ࠫࡆ࡙ࡋࠨ勳")]: settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ勴"),l1l11l_l1_ (u"࠭ࡁࡔࡍࠪ勵"))
	if settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ勶")) not in [l1l11l_l1_ (u"ࠨࡃࡘࡘࡔ࠭勷"),l1l11l_l1_ (u"ࠩࡖࡘࡔࡖࠧ勸"),l1l11l_l1_ (u"ࠪࡅࡘࡑࠧ勹")]: settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭勺"),l1l11l_l1_ (u"ࠬࡇࡓࡌࠩ勻"))
	if settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ勼")) not in [l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ勽"),l1l11l_l1_ (u"ࠨࡕࡗࡓࡕ࠭勾"),l1l11l_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ勿")]: settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ匀"),l1l11l_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ匁"))
	if not settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ匂")): settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭匃"),l1l1ll11l1l1_l1_[0])
	l11lllllllll_l1_ = l11l1l11ll11_l1_()
	l11lll11llll_l1_ = l11lllllllll_l1_!=l1l11l_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ匄")
	if l11lll11llll_l1_:
		DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ包"),l1l11l_l1_ (u"ࠩࠪ匆"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭匇"),l1l11l_l1_ (u"ࠫฯ๋ࠠหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬ匈")+addon_version)
		#l1ll11l1ll1l_l1_([main_dbfile])
		if l11lllllllll_l1_==l1l11l_l1_ (u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬ匉"):
			LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭匊"),l1l11l_l1_ (u"ࠧ࠯ࠢࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ匋")+addon_path+l1l11l_l1_ (u"ࠨࠢࡠࠫ匌"))
			DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ匍"),l1l11l_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ匎"))
			DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ匏"),l1l11l_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ匐"))
		else:
			LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭匑"),l1l11l_l1_ (u"ࠧ࠯ࠢࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ匒")+addon_path+l1l11l_l1_ (u"ࠨࠢࡠࠫ匓"))
			DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ匔"),l1l11l_l1_ (u"ࠪࠫ匕"),l1l11l_l1_ (u"ࠫอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ化"),l1l11l_l1_ (u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢฦ์ࠥะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ࠳ࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪ北"))
			l1ll11l1ll1l_l1_()
			FIX_OR_CREATE_ALL_DATABASES(False)
			l1l111111l11_l1_ = l1ll1l1l11l_l1_(32)
			import l1llll1lllll_l1_
			l1llll1lllll_l1_.l1ll1l111l11_l1_()
			l1llll1lllll_l1_.l1lll11111l1_l1_()
			l1llll1lllll_l1_.l1ll1l1l1lll_l1_(l1l11l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭匘"),False)
			l1llll1lllll_l1_.l1ll1l1l1lll_l1_(l1l11l_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ匙"),False)
			l1llll1lllll_l1_.l1ll1lllll1l_l1_(False)
			l1llll1lllll_l1_.l1ll1lll111l_l1_(False)
			l1llll1lllll_l1_.l1ll1lllllll_l1_(l1l11l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭匚"),l1l11l_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ匛"),False)
			l1l11l_l1_ (u"ࠥࠦࠧࠓࠊࠊࠋࠌࡸࡷࡿ࠺ࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳࡧ࡫࡯ࡩ࠷ࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ࠭ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࠬࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ࠮ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࠉࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠶ࠥࡃࠠࡹࡤࡰࡧࡦࡪࡤࡰࡰ࠱ࡅࡩࡪ࡯࡯ࠪ࡬ࡨࡂ࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠩࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠳࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧ࡬ࡱࡧ࡭ࡴࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡱࡶࡣ࡯࡭ࡹࡿ࠮ࡢࡵ࡮ࠫ࠱࠭ࡴࡳࡷࡨࠫ࠮ࠓࠊࠊࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠏࠍࠍࠎࠏࠢࠣࠤ匜")
			try:
				l1l1111ll1ll_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭匝"),l1l11l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ匞"),l1l11l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ匟"),l1l11l_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭匠"))
				l11ll1llll1l_l1_ = xbmcaddon.Addon(id=l1l11l_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ匡"))
				l11ll1llll1l_l1_.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ匢"),l1l11l_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ匣"))
			except: pass
			try:
				l1l1111ll1ll_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭匤"),l1l11l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ匥"),l1l11l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ匦"),l1l11l_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭匧"))
				l11ll1llll1l_l1_ = xbmcaddon.Addon(id=l1l11l_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ匨"))
				l11ll1llll1l_l1_.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ匩"),l1l11l_l1_ (u"ࠪ࠷ࠬ匪"))
			except: pass
			try:
				l1l1111ll1ll_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭匫"),l1l11l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ匬"),l1l11l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭匭"),l1l11l_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭匮"))
				l11ll1llll1l_l1_ = xbmcaddon.Addon(id=l1l11l_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ匯"))
				l11ll1llll1l_l1_.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ匰"),l1l11l_l1_ (u"ࠪ࠶ࠬ匱"))
			except: pass
			if os.path.exists(dummyiptvfile):
				#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ匲"),l1l11l_l1_ (u"ࠬ࠭匳"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ匴"),l1l11l_l1_ (u"ࠧฦาสࠤ่์สࠡฬึฮำีๅࠡะา้ฮࠦเࡊࡒࡗ࡚ࠥอไๆ๊ฯ์ิฯࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢไืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥะไใษษ๎ฬࠦศอๆหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠢฯำ๏ีษࠨ匵"))
				import IPTV
				IPTV.CREATE_STREAMS()
		settings.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠴ࡨࡰࡵࡷࠫ匶"),l1l11l_l1_ (u"ࠩࠪ匷"))
		settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡦࡢࡵࡨࡰࡸࡪ࠲࠯ࡪࡲࡷࡹ࠭匸"),l1l11l_l1_ (u"ࠫࠬ匹"))
		data = FIX_AND_GET_FILE_CONTENTS(l1ll111111l_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll1l11l11_l1_)
		settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ区"),addon_version)
		return
	l11ll11llll1_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ医"))
	if l11ll11llll1_l1_==l1l11l_l1_ (u"ࠧࠨ匼") or now-int(l11ll11llll1_l1_)>REGULAR_CACHE:
		#l1ll11l1ll1l_l1_([main_dbfile,iptv1_dbfile,iptv2_dbfile])
		settings.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭匽"),l1l11l_l1_ (u"ࠩࠪ匾"))
	l11l1l1lll1l_l1_ = 0
	l11llllll1ll_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ匿"))
	if len(l11llllll1ll_l1_)==15:
		first,second,l111l111_l1_ = l11llllll1ll_l1_[0:4],l11llllll1ll_l1_[4:9],l11llllll1ll_l1_[9:]
		first = int(first)^l1111lll_l1_
		second = int(second)^REGULAR_CACHE
		l111l111_l1_ = int(l111l111_l1_)^l1llll_l1_
		if first==second==l111l111_l1_:
			l11l1l1lll1l_l1_ = first*60
			if l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪ區")): l11l1l1lll1l_l1_ = l11l1l1lll1l_l1_*2
	l1l11111lll1_l1_ = l1l11l_l1_ (u"ࠬ࠷࠶ࠨ十")+settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ卂"))
	if l1l11111lll1_l1_: l1l11111lll1_l1_ = int(l1l11111lll1_l1_)^l1llll11l11_l1_
	if (not l1l11111lll1_l1_ or not l11l1l1lll1l_l1_ or now-int(l1l11111lll1_l1_)<=0 or now-int(l1l11111lll1_l1_)>l11l1l1lll1l_l1_):
		if not l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ千")):
			# l11l11l_l1_://l1llllll1ll1_l1_.l11l1llll1ll_l1_.l11111ll_l1_/l11l111llll1_l1_/l11lllll1l1l_l1_
			# unescapeHTML(l1l11l_l1_ (u"ࠨࠢࠩࠧࡽ࠸࠶࠴ࡄ࠾ࠤࠫࠩࡸ࠳࠹࠴ࡈࡀࠦࠦࠤࡺ࠵࠺࠷ࡇ࠻ࠡࠨࠦࡼ࠷࠼࠳ࡃ࠽ࠪ卄"))
			#l11l1lll1l1l_l1_ = l1l11l_l1_ (u"ࠩ⸾ࠤ⼢ࠦࠠ⾋ࠢࠣ⸮ࠥ⹁ࠧ卅")
			#l11ll1l11l11_l1_ = l1l11l_l1_ (u"ࠪ⸿ࠥ⼣ࠠࠡ⾍ࠣࠤⸯࠦ⸻ࠨ卆")
			l1ll1lll11ll_l1_ = l1lll111111l_l1_()
			if l1ll1lll11ll_l1_:
				LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ升"),l1l11l_l1_ (u"ࠬ࠴ࠠࠡࠢࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ午")+addon_path+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ卉"))
				id,l1ll1l11l1l1_l1_,l1ll11ll1l1l_l1_,answer,l1l1ll1ll11l_l1_,reason = l1ll1lll11ll_l1_[0]
				l1ll111lllll_l1_,l1lll11l1111_l1_ = answer.split(l1l11l_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ半"))
				del l1ll1lll11ll_l1_[0]
				l11l1l11111l_l1_ = random.sample(l1ll1lll11ll_l1_,1)
				id,l1ll1l11l1l1_l1_,l1ll11ll1l1l_l1_,answer,l1l1ll1ll11l_l1_,reason = l11l1l11111l_l1_[0]
				l1ll11ll1l1l_l1_ = l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ卋")+id+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ卌")+l1ll11ll1l1l_l1_
				button0,button1,l11lll1ll1l1_l1_ = answer,l1l1ll1ll11l_l1_,reason
				l1l1l1ll_l1_ = [button0,button1,l1l1ll1ll1l1_l1_]
				choice = -9
				while choice<0:
					l1l1111l1l1l_l1_ = random.sample(l1l1l1ll_l1_,3)
					choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠪࠫ卍"),l1l1111l1l1l_l1_[0],l1l1111l1l1l_l1_[1],l1l1111l1l1l_l1_[2],l1ll111lllll_l1_,l1ll11ll1l1l_l1_,5,60)
					if choice==10: break
					if choice>=0 and l1l1111l1l1l_l1_[choice]==l1l1l1ll_l1_[1]:
						choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠫࠬ华"),l1l11l_l1_ (u"ࠬ࠭协"),l1l11l_l1_ (u"ู้࠭ัฬࠫ卐"),l1l11l_l1_ (u"ࠧࠨ卑"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ卒"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ卓")+l11lll1ll1l1_l1_,10)
						if choice>=0: choice = -9
					elif choice>=0 and l1l1111l1l1l_l1_[choice]==l1l1l1ll_l1_[2]:
						choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠪࠫ協"),l1l11l_l1_ (u"ࠫࠬ单"),l1l1ll1ll1l1_l1_,l1l11l_l1_ (u"ࠬ࠭卖"),l1ll111lllll_l1_,l1ll11ll1l1l_l1_+l1l11l_l1_ (u"࠭࡜࡯࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭南")+l1l1l1ll_l1_[0]+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ単"),30)
					if choice==-1: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ卙"),l1l11l_l1_ (u"ࠩࠪ博"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭卛"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่้ิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ卜"))
				settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ卝"),str(now^l1llll11l11_l1_)[2:])
				WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ卞"),l1l11l_l1_ (u"ࠧࡂࡗࡗࡌࠬ卟"),1,PERMANENT_CACHE)
			else: WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ占"),l1l11l_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ卡"),0,PERMANENT_CACHE)
		else:
			settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ卢"),str(now^l1llll11l11_l1_)[2:])
			WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ卣"),l1l11l_l1_ (u"ࠬࡇࡕࡕࡊࠪ卤"),1,PERMANENT_CACHE)
	if l11lll11llll_l1_: l1llll1lllll_l1_.l1ll1ll11l11_l1_(False)
	# l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ卥")	l1l111l11111_l1_ file to read/write the l1l1l11l1l1_l1_ l1lllll1ll_l1_ list
	# l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ卦")		no l1l11l11l1l_l1_ l11l111l1l11_l1_ to the l1l1l11l1l1_l1_ l1lllll1ll_l1_ list
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡓࡊࡖࡈࡗࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠤࡂࠦࡓࡊࡖࡈࡗࡤࡓࡏࡅࡇࡖࠤࡦࡴࡤࠡ࡯ࡲࡨࡪ࠷࠽࠾࠻ࠐࠎࠎࡕࡔࡉࡇࡕࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡁࠥࡳ࡯ࡥࡧ࠳ࠤ࡮ࡴࠠ࡜࠳࠷࠹࠱࠻࠱࠷࠮࠸࠶࠸ࡣࠍࠋࠋࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡗࡎ࡚ࡅࡔࡡࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡࡱࡵࠤࡔ࡚ࡈࡆࡔࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠏࠍࠍࡗࡇࡎࡅࡑࡐࡣࡒࡕࡄࡆࡕࠣࡁࠥࡳ࡯ࡥࡧ࠵ࡁࡂ࠷࠶ࠡࡣࡱࡨࠥࡳ࡯ࡥࡧ࠳ࠥࡂ࠷࠶࠱ࠏࠍࠍ࡞ࡕࡕࡕࡗࡅࡉࡤࡓࡅࡏࡗࡖࠤࡂࠦ࡭ࡰࡦࡨ࠴ࠥ࡯࡮ࠡ࡝࠴࠸࠹ࡣࠍࠋࠋࠦࡲࡦࡳࡥࡠࠢࡀࠤࡈࡒࡅࡂࡐࡢࡑࡊࡔࡕࡠࡎࡄࡆࡊࡒࠨ࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࡱࡥࡲ࡫࡟ࠡ࠿ࠣࡖࡊ࡙ࡔࡐࡔࡈࡣࡕࡇࡔࡉࡡࡑࡅࡒࡋࠨ࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࡕࡉࡒࡋࡍࡃࡇࡕࡣࡗࡋࡓࡖࡎࡗࡗࡤࡓࡏࡅࡇࡖࠤࡂࠦࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡵࡲࠡࡔࡄࡒࡉࡕࡍࡠࡏࡒࡈࡊ࡙ࠠࡰࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࡣࡒࡋࡎࡖࡕࠐࠎࠎ࡯ࡦࠡࡔࡈࡑࡊࡓࡂࡆࡔࡢࡖࡊ࡙ࡕࡍࡖࡖࡣࡒࡕࡄࡆࡕ࠽ࠑࠏࠏࠉࠤ࡫ࡩࠤࡗࡇࡎࡅࡑࡐࡣࡒࡕࡄࡆࡕ࠽ࠤࡨࡵ࡮ࡥ࠳ࠣࡁࠥ࠮࡭ࡦࡰࡸࡣࡱࡧࡢࡦ࡮ࠣ࡭ࡳ࡛ࠦࠨ࠰࠱ࠫ࠱࠭ࡍࡢ࡫ࡱࠤࡒ࡫࡮ࡶࠩࡠ࠭ࠒࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࡀࠠࡤࡱࡱࡨ࠶ࠦ࠽ࠡࠪࡰࡩࡳࡻ࡟࡭ࡣࡥࡩࡱࠧ࠽࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࠌ࡭࡫ࠦࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫࠥ࡯࡮ࠡࡶࡨࡼࡹࠦࡡ࡯ࡦࠣࡱࡪࡴࡵࡠ࡮ࡤࡦࡪࡲࠡ࠾ࡰࡤࡱࡪࡥࠠࡢࡰࡧࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳࡫ࡸࡪࡵࡷࡷ࠭ࡲࡡࡴࡶࡰࡩࡳࡻࡦࡪ࡮ࡨ࠭࠿ࠓࠊࠊࠋࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࠨ࠰ࠣࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡵ࡫࡮ࠩ࡮ࡤࡷࡹࡳࡥ࡯ࡷࡩ࡭ࡱ࡫ࠬࠨࡴࡥࠫ࠮࠴ࡲࡦࡣࡧࠬ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡵ࡬ࡥࡈࡌࡐࡊࠦ࠽ࠡࡱ࡯ࡨࡋࡏࡌࡆ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠐࠎࠎࠏࠉ࡮ࡧࡱࡹࡎࡺࡥ࡮ࡵࡏࡍࡘ࡚࡛࠻࡟ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡳࡱࡪࡆࡊࡎࡈ࠭ࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥࠦࡗࡳ࡫ࡷ࡭ࡳ࡭ࠠ࡭ࡣࡶࡸࠥࡳࡥ࡯ࡷࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧࠬࡣࡧࡨࡴࡴ࡟ࡱࡣࡷ࡬࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࠊࡴࡨࡷࡺࡲࡴࡴࠢࡀࠤࡒࡇࡉࡏࡡࡇࡍࡘࡖࡁࡕࡅࡋࡉࡗ࠮ࡴࡺࡲࡨ࠰ࡳࡧ࡭ࡦࡡ࠯ࡹࡷࡲ࡟࠭࡯ࡲࡨࡪ࠲ࡩ࡮ࡣࡪࡩࡤ࠲ࡰࡢࡩࡨࡣ࠱ࡺࡥࡹࡶ࠯ࡧࡴࡴࡴࡦࡺࡷ࠰࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠯ࠍࠋࠋࠌࠍࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠࡴࡶࡵࠬࡲ࡫࡮ࡶࡋࡷࡩࡲࡹࡌࡊࡕࡗ࠭ࠒࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠ࡯ࡧࡺࡊࡎࡒࡅ࠯ࡧࡱࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠏࠍࠍࠎࠏ࡯ࡱࡧࡱࠬࡱࡧࡳࡵ࡯ࡨࡲࡺ࡬ࡩ࡭ࡧ࠯ࠫࡼࡨࠧࠪ࠰ࡺࡶ࡮ࡺࡥࠩࡰࡨࡻࡋࡏࡌࡆࠫࠐࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡃࠠࡎࡃࡌࡒࡤࡊࡉࡔࡒࡄࡘࡈࡎࡅࡓࠪࡷࡽࡵ࡫ࠬ࡯ࡣࡰࡩࡤ࠲ࡵࡳ࡮ࡢ࠰ࡲࡵࡤࡦ࠮࡬ࡱࡦ࡭ࡥࡠ࠮ࡳࡥ࡬࡫࡟࠭ࡶࡨࡼࡹ࠲ࡣࡰࡰࡷࡩࡽࡺࠬࡪࡰࡩࡳࡩ࡯ࡣࡵࠫࠐࠎࠎࠨࠢࠣ卧")
	results = l1l11llllll_l1_(type,l1l1111ll11l_l1_,l11l1ll11lll_l1_,mode,l11l1111llll_l1_,l11ll11l1ll1_l1_,text,context,infodict)
	# l11lll1111l_l1_ l1l111lll111_l1_: succeeded,updateListing,cacheToDisc = True,False,True
	# updateListing = True => l111l1lll11_l1_ this list is l11l11ll1lll_l1_ and will exit to main l1lllll1ll_l1_
	# updateListing = False => l111l1lll11_l1_ this list is l11llll1ll1l_l1_ and will exit to l1l1l11l1l1_l1_ l1lllll1ll_l1_
	# cacheToDisc = True => will cause the l111lll1llll_l1_ status to l111llll11ll_l1_ l11l1l1111l1_l1_
	# cacheToDisc = False => will l11l11llll1l_l1_ the l111lll1llll_l1_ status to l11llll11l1l_l1_ l11lll1l1ll1_l1_
	#succeeded,updateListing,cacheToDisc = True,False,True
	#if not l1l111lll1ll_l1_: cacheToDisc = False
	if l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ卨") in text: updateListing = True
	if type==l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ卩"):
		if l1l1lll1l1_l1_!=l1l11l_l1_ (u"ࠫ࠳࠴ࠧ卪") and l11ll11l111l_l1_: l11lll11lll1_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬ࡯࡮ࡵࠩ卫"),l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ卬"),l1l11l_l1_ (u"ࠧࡂࡗࡗࡌࠬ卭")) or l11l1l111111_l1_ not in l11ll1lllll1_l1_) and not l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ卮")):
				import l1ll11l111l_l1_
				DirectoryItems_List = GET_ALL_LIST_ITEMS(l1ll11l111l_l1_.l1ll11l1l11_l1_)
				addItems_succeeded = CREATE_KODI_MENU(DirectoryItems_List,succeeded,updateListing,cacheToDisc)
				if 1 and l11l1l1l11ll_l1_ and DirectoryItems_List:
					WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋࠧ卯"),[l11l11111ll1_l1_],DirectoryItems_List,REGULAR_CACHE)
				#elif 1 and not DirectoryItems_List:
				#	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ印"),[l11l11111ll1_l1_])
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l11l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ危")+addon_id+l1l11l_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ卲"),xbmcgui.ListItem(l1l11l_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ即")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ却")+addon_id+l1l11l_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ卵"),xbmcgui.ListItem(l1l11l_l1_ (u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ卶")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,updateListing,cacheToDisc)
	return
def l1l11llllll_l1_(type,name,url,mode,image,page,text,context,infodict):
	l11l1l111111_l1_ = int(mode)
	l1l1l1l11ll_l1_ = int(l11l1l111111_l1_//10)
	if   l1l1l1l11ll_l1_==0:  import l1llll1lllll_l1_ 	; results = l1llll1lllll_l1_.MAIN(l11l1l111111_l1_,text)
	elif l1l1l1l11ll_l1_==1:  import l1l11111_l1_ 		; results = l1l11111_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==2:  import l1lll1l11l1_l1_ 		; results = l1lll1l11l1_l1_.MAIN(l11l1l111111_l1_,url,page,text)
	elif l1l1l1l11ll_l1_==3:  import l1l1ll1l111_l1_ 		; results = l1l1ll1l111_l1_.MAIN(l11l1l111111_l1_,url,page,text)
	elif l1l1l1l11ll_l1_==4:  import l1lll111l_l1_ 	; results = l1lll111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==5:  import l1l1l1l1lll1_l1_ 	; results = l1l1l1l1lll1_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==6:  import l1lllll11_l1_ 	; results = l1lllll11_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==7:  import l11l1_l1_ 		; results = l11l1_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==8:  import l1lll1l1l11_l1_ 	; results = l1lll1l1l11_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==9:  import l1llllll11_l1_		; results = l1llllll11_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==10: import l1ll1l1l111_l1_ 		; results = l1ll1l1l111_l1_.MAIN(l11l1l111111_l1_,url)
	elif l1l1l1l11ll_l1_==11: import l111111111l_l1_ 	; results = l111111111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==12: import l11ll1l11l_l1_ 		; results = l11ll1l11l_l1_.MAIN(l11l1l111111_l1_,url,page,text)
	elif l1l1l1l11ll_l1_==13: import l1lll11l1_l1_	; results = l1lll11l1_l1_.MAIN(l11l1l111111_l1_,url,page,text)
	elif l1l1l1l11ll_l1_==14: import l1l1111l1l1_l1_ 		; results = l1l1111l1l1_l1_.MAIN(l11l1l111111_l1_,url,text,type,page,name,image)
	elif l1l1l1l11ll_l1_==15: import l1llll1lllll_l1_ 	; results = l1llll1lllll_l1_.MAIN(l11l1l111111_l1_,text)
	elif l1l1l1l11ll_l1_==16: import l1l11l1llll_l1_	 	; results = l1l11l1llll_l1_.MAIN(l11l1l111111_l1_,url,text,page)
	elif l1l1l1l11ll_l1_==17: import l1llll1lllll_l1_ 	; results = l1llll1lllll_l1_.MAIN(l11l1l111111_l1_,text)
	elif l1l1l1l11ll_l1_==18: import l1l1lll1lll_l1_	; results = l1l1lll1lll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==19: import l1llll1lllll_l1_ 	; results = l1llll1lllll_l1_.MAIN(l11l1l111111_l1_,text)
	elif l1l1l1l11ll_l1_==20: import l11llll11_l1_		; results = l11llll11_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==21: import l11l1llllll_l1_ ; results = l11l1llllll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==22: import l111lll1ll_l1_ 	; results = l111lll1ll_l1_.MAIN(l11l1l111111_l1_,url,page,text)
	elif l1l1l1l11ll_l1_==23: import IPTV 		; results = IPTV.MAIN(l11l1l111111_l1_,url,text,type,page)
	elif l1l1l1l11ll_l1_==24: import l11ll1_l1_ 		; results = l11ll1_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==25: import l1l11l1ll_l1_ 	; results = l1l11l1ll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==26: import l1ll11l111l_l1_ 		; results = l1ll11l111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l11l1l111111_l1_,context)
	elif l1l1l1l11ll_l1_==28: import IPTV 		; results = IPTV.MAIN(l11l1l111111_l1_,url,text,type,page)
	elif l1l1l1l11ll_l1_==29: import l1l11l1l1111_l1_	; results = l1l11l1l1111_l1_.MAIN(l11l1l111111_l1_,url,page,text)
	elif l1l1l1l11ll_l1_==30: import l1llll1l1l_l1_		; results = l1llll1l1l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==31: import l1l1l1lll1ll_l1_	; results = l1l1l1lll1ll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==32: import l1ll1lll1l1_l1_	; results = l1ll1lll1l1_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==33: import l1l1l11l11_l1_		; results = l1l1l11l11_l1_.MAIN(l11l1l111111_l1_,url)
	elif l1l1l1l11ll_l1_==34: import l1llll1lllll_l1_ 	; results = l1llll1lllll_l1_.MAIN(l11l1l111111_l1_,text)
	elif l1l1l1l11ll_l1_==35: import l11111l_l1_		; results = l11111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==36: import l1l1ll1l11l_l1_		; results = l1l1ll1l11l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==37: import l11l1l111_l1_		; results = l11l1l111_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==38: import l1l1ll1l1ll_l1_ 		; results = l1l1ll1l1ll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==39: import l111111l1l_l1_	; results = l111111l1l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==40: import l1ll1l111l_l1_	; results = l1ll1l111l_l1_.MAIN(l11l1l111111_l1_,url,text,type,page)
	elif l1l1l1l11ll_l1_==41: import l1ll1l111l_l1_	; results = l1ll1l111l_l1_.MAIN(l11l1l111111_l1_,url,text,type,page)
	elif l1l1l1l11ll_l1_==42: import l11l1111l_l1_		; results = l11l1111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==43: import l111ll111l_l1_		; results = l111ll111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==44: import l111ll11l1_l1_		; results = l111ll11l1_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==45: import l1ll1l11l1l_l1_		; results = l1ll1l11l1l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==46: import l111llll1ll_l1_		; results = l111llll1ll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==47: import l1llll1ll1_l1_	; results = l1llll1ll1_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==48: import l1lllll1l11l_l1_		; results = l1lllll1l11l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==49: import l11111l11_l1_		; results = l11111l11_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==50: import l1llll1lllll_l1_ 	; results = l1llll1lllll_l1_.MAIN(l11l1l111111_l1_,text)
	elif l1l1l1l11ll_l1_==51: import l111l1111l_l1_ 	; results = l111l1111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==52: import l111l1111l_l1_ 	; results = l111l1111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==53: import l1ll11l111l_l1_ 		; results = l1ll11l111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==54: import l111l111l1_l1_	; results = l111l111l1_l1_.MAIN(l11l1l111111_l1_,url,text,page)
	elif l1l1l1l11ll_l1_==55: import l1111l11l_l1_ 	; results = l1111l11l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==56: import l111111l111_l1_		; results = l111111l111_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==57: import l1111111ll_l1_		; results = l1111111ll_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==58: import l1l1ll11111l_l1_	; results = l1l1ll11111l_l1_.MAIN(l11l1l111111_l1_,url,text)
	elif l1l1l1l11ll_l1_==59: import l1lllllll11_l1_		; results = l1lllllll11_l1_.MAIN(l11l1l111111_l1_,url,text)
	else: results = None
	return results
def l1l1ll1l1l_l1_(name=l1l11l_l1_ (u"ࠪࠫ卷")):
	if not name: name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ卸"))
	name = name.replace(l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ卹"),l1l11l_l1_ (u"࠭ࠧ卺"))
	name = name.replace(l1l11l_l1_ (u"ࠧࠡࠢࠣࠤࠬ卻"),l1l11l_l1_ (u"ࠨࠢࠪ卼")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠥ࠭卽"),l1l11l_l1_ (u"ࠪࠤࠬ卾")).replace(l1l11l_l1_ (u"ࠫࠥࠦࠧ卿"),l1l11l_l1_ (u"ࠬࠦࠧ厀")).strip(l1l11l_l1_ (u"࠭ࠠࠨ厁"))
	name = name.replace(l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ厂"),l1l11l_l1_ (u"ࠨࠩ厃")).replace(l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ厄"),l1l11l_l1_ (u"ࠪࠫ厅"))
	tmp = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠࠨ历"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l11l_l1_ (u"ࠬࡓࡡࡪࡰࠣࡑࡪࡴࡵࠨ厇")
	return name
def SHOW_NETWORK_ERRORS(code,reason,source,showDialogs):
	if l1l11l_l1_ (u"࠭࠭ࠨ厈") in source: site = source.split(l1l11l_l1_ (u"ࠧ࠮ࠩ厉"),1)[0]
	else: site = source
	l1l1111ll1l1_l1_ = (code in [7,11001,11002,10054])
	l111llll11l1_l1_ = reason.lower()
	l11ll11111ll_l1_ = (code in [0,104,10061,111])
	l11ll11111l1_l1_ = (l1l11l_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ厊") in l111llll11l1_l1_)
	l11ll111111l_l1_ = (l1l11l_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ压") in l111llll11l1_l1_)
	l11ll1111111_l1_ = (l1l11l_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡨࡱࡲ࡫ࡱ࡫ࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ厌") in l111llll11l1_l1_)
	l11l1lllllll_l1_ = (l1l11l_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭厍") in l111llll11l1_l1_)
	proxy_status = settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ厎"))
	dns_status = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭厏"))
	l11ll1ll1lll_l1_ = l1l11l_l1_ (u"ࠧโึ็ࠤอูอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ厐")
	l11ll1l1ll1l_l1_ = l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠨ厑")+str(code)+l1l11l_l1_ (u"ࠩ࠽ࠤࠬ厒")+reason
	if l11ll11111ll_l1_ or l11ll11111l1_l1_ or l11ll111111l_l1_ or l11ll1111111_l1_ or l11l1lllllll_l1_:
		l11ll1ll1lll_l1_ += l1l11l_l1_ (u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ厓")
	if l1l1111ll1l1_l1_: l11ll1ll1lll_l1_ += l1l11l_l1_ (u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ厔")
	l11ll1l1ll1l_l1_ = l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ厕")+l11ll1l1ll1l_l1_+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ厖")
	if proxy_status==l1l11l_l1_ (u"ࠧࡂࡕࡎࠫ厗") or dns_status==l1l11l_l1_ (u"ࠨࡃࡖࡏࠬ厘"):
		l11ll1ll1lll_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤศีๆศ้ࠣรࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭厙")
	trytofix = False
	if showDialogs:
		if proxy_status==l1l11l_l1_ (u"ࠪࡅࡘࡑࠧ厚") or dns_status==l1l11l_l1_ (u"ࠫࡆ࡙ࡋࠨ厛"):
			#if kodi_version<19: l11ll1l1ll1l_l1_ = l11ll1l1ll1l_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ厜"))
			trytofix = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭厝"),l1l11l_l1_ (u"ࠧࠨ厞"),l1l11l_l1_ (u"ࠨࠩ原"),site+l1l11l_l1_ (u"ࠩࠣࠤࠥ࠭厠")+TRANSLATE(site),l11ll1ll1lll_l1_,l11ll1l1ll1l_l1_)
		else: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ厡"),l1l11l_l1_ (u"ࠫࠬ厢"),site+l1l11l_l1_ (u"ࠬࠦࠠࠡࠩ厣")+TRANSLATE(site),l11ll1ll1lll_l1_,l11ll1l1ll1l_l1_)
	if reason.endswith(l1l11l_l1_ (u"࠭ࠠࠪࠩ厤")): reason = reason.rsplit(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ厥"))[0]
	#if trytofix: LOG_THIS(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭厦"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ厧")+str(code)+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ厨")+reason+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭厩")+source+l1l11l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡅࡗࡇࡂࡊࡅ࠽ࠤࡠࠦࠧ厪")+l11ll1ll1lll_l1_+l1l11l_l1_ (u"࠭ࠠ࡞࡟ࠣࠤࠥࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ厫")+l11ll1l1ll1l_l1_+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ厬"))
	return trytofix
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢࡧࡲࡸࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠴ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠳ࠢࡲࡶࠥࡨ࡬ࡰࡥ࡮ࡩࡩ࠹࠺ࠎࠌࠌࠍࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨ่๋฽๋ࠥๆࠡษ็ััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆ࠲ࠬࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥ࠱࠽๋้ࠡࠩࠣࠦสา์าࠤฯ็วึ์็ࠤฬ้หาࠢยࠫࠒࠐࠉࠊ࡫ࡩࠤࡩࡴࡳ࠻ࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽ࠡࠩ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄࠢ࠮ࡁ้ࠥ࠭ࠠษ็ือฮࠠใัࠣ๎่๎ๆࠡࠩ࠮ࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽๊ࠡࠩิฬࠦวๅ็๋ๆ฾ࠦแ๋้ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡰࡷࡵࡧࡪ࠱ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧࠬࡵࡷࡶ࠭ࡩ࡯ࡥࡧࠬ࠯ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧࠬࡴࡨࡥࡸࡵ࡮ࠬࠩࠣࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ࠰ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠰࠭ࠠ࡞࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ࠯ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠏࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲ࡳࡪࡶࡨ࠯ࠬࠦࠠࠡࠩ࠮ࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠮ࡳࡪࡶࡨ࠭࠱ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠱ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡࡻࡨࡷࡂࡃ࠱࠻ࠢ࡬ࡱࡵࡵࡲࡵࠢࡖࡉࡗ࡜ࡉࡄࡇࡖࠤࡀࠦࡓࡆࡔ࡙ࡍࡈࡋࡓ࠯ࡏࡄࡍࡓ࠮࠱࠺࠷ࠬࠑࠏࠏࡥ࡭࡫ࡩࠤࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠼ࠐࠎࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠠ࠾ࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠭ࠪࠤ࠳ࠦ็ๅࠢอี๏ีࠠๆ฻ิๅฮࠦวๅลึฬฬฮ้ࠠษ็ั้๎ไࠡมࠪࠑࠏࠏࠉࡺࡧࡶࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥ࡙ࡆࡕࡑࡓ࠭࠭ࡣࡦࡰࡷࡩࡷ࠭ࠬࡴ࡫ࡷࡩ࠰࠭ࠠࠡࠢࠪ࠯࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋࠨࡴ࡫ࡷࡩ࠮࠲࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠲࠼ࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠿ࠣࠫ็ี๋ࠠๅ๋๊ࠥํๆศๅ๊ࠣํ฿ࠠๆ่ࠣห้ำฬษࠢ฼๊ิ้ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัๆࠤ๊็ี้ๆฬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠๅษࠣ๎฾๋ไࠡ฻้ำ่࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡ฼ํีࠥํะ่ࠢสฺ่็อส๋ࠢห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࡠࡳ࠭ࠫࠨฮิฬ๋ࠥำฮࠢส่่อิ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠำๅࠤึ็ูࠡษ็ััฮࠠࠩ็ฮ่ฬࠦࡖࡑࡐࠣ࠰ࠥࡖࡲࡰࡺࡼࠤ࠱ࠦࡄࡏࡕࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡฮิฬࠥ฽ไษ๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศฯๅหࠬࠓࠊࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡘࡊ࡞ࡔࡗࡋࡈ࡛ࡊࡘࠨࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗ࠮ࠓࠊࠊࠤࠥࠦ厭")
def l1ll11l1ll1l_l1_(l111lll11111_l1_=[]):
	l111lll1111l_l1_ = [l1ll111111l_l1_,favoritesfile,dummyiptvfile,fulliptvfile,l1ll1l11l11_l1_]
	l11ll1lll1ll_l1_ = l111lll11111_l1_+l111lll1111l_l1_
	for filename in os.listdir(addoncachefolder):
		if filename.startswith(l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ厮")): continue
		l11ll111llll_l1_ = os.path.join(addoncachefolder,filename)
		if l11ll111llll_l1_ not in l11ll1lll1ll_l1_:
			try: os.remove(l11ll111llll_l1_)
			except: pass
	time.sleep(1)
	return
def EXTRACT_KODI_PATH(kodipath=addon_path):
	l11lllll1111_l1_ = {l1l11l_l1_ (u"ࠪࡸࡾࡶࡥࠨ厯"):l1l11l_l1_ (u"ࠫࠬ厰"),l1l11l_l1_ (u"ࠬࡳ࡯ࡥࡧࠪ厱"):l1l11l_l1_ (u"࠭ࠧ厲"),l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ厳"):l1l11l_l1_ (u"ࠨࠩ厴"),l1l11l_l1_ (u"ࠩࡷࡩࡽࡺࠧ厵"):l1l11l_l1_ (u"ࠪࠫ厶"),l1l11l_l1_ (u"ࠫࡵࡧࡧࡦࠩ厷"):l1l11l_l1_ (u"ࠬ࠭厸"),l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ厹"):l1l11l_l1_ (u"ࠧࠨ厺"),l1l11l_l1_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧ去"):l1l11l_l1_ (u"ࠩࠪ厼"),l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ厽"):l1l11l_l1_ (u"ࠫࠬ厾"),l1l11l_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ县"):l1l11l_l1_ (u"࠭ࠧ叀")}
	if l1l11l_l1_ (u"ࠧࡀࠩ叁") in kodipath: kodipath = kodipath.split(l1l11l_l1_ (u"ࠨࡁࠪ参"),1)[1]
	url2,l11llll1llll_l1_ = URLDECODE(kodipath)
	args = dict(list(l11lllll1111_l1_.items())+list(l11llll1llll_l1_.items()))
	l11l11ll1ll1_l1_ = args[l1l11l_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ參")]
	l11l1ll11lll_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ叄")])
	l1l1111ll111_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ叅")])
	l11ll11l1ll1_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠬࡶࡡࡨࡧࠪ叆")])
	type_ = UNQUOTE(args[l1l11l_l1_ (u"࠭ࡴࡺࡲࡨࠫ叇")])
	l1l1111ll11l_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ又")])
	l11l1111llll_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧ叉")])
	l11l1l1l1111_l1_ = args[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ及")]
	l11l1ll1111l_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬ友")])
	#name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ双"))
	#image = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬ反"))
	if not l11l11ll1ll1_l1_: type_ = l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭収") ; l11l11ll1ll1_l1_ = l1l11l_l1_ (u"ࠧ࠳࠸࠳ࠫ叏")
	return type_,l1l1111ll11l_l1_,l11l1ll11lll_l1_,l11l11ll1ll1_l1_,l11l1111llll_l1_,l11ll11l1ll1_l1_,l1l1111ll111_l1_,l11l1l1l1111_l1_,l11l1ll1111l_l1_
def l11l1ll1l1l1_l1_(proxy,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix=True,allow_proxy_fix=True):
	l11l11l11l11_l1_,l11l1ll1ll11_l1_ = proxy.split(l1l11l_l1_ (u"ࠨ࠼ࠪ叐"))
	#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ุ่่๊ࠩษࠡว้ฮึ์๊หࠢ࠱ࠤุษอศ๊็ࠤส฻ไศฯ๊หࠬ发"),l1l11l_l1_ (u"ࠪืศาัษࠢࠪ叒")+name,time=2000)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ叓"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧࠡࠩ叔")+name+l1l11l_l1_ (u"࠭ࠠࡴࡧࡵࡺࡪࡸࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ叕")+proxy+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭取")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ受"))
	url = url+l1l11l_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ变")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix,allow_proxy_fix)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ叙"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࠨ叚")+name+l1l11l_l1_ (u"ࠬࠦࡳࡦࡴࡹࡩࡷࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ叛")+proxy+l1l11l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ叜")+url+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ叝"))
		FORCED_EXIT(l1l11l_l1_ (u"ࠨࡊࡗࡘࡕࠦࡒࡦࡳࡸࡩࡸࡺࠠࡇࡣ࡬ࡰࡺࡸࡥࠨ叞"))
	#else: LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ叟"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ叠")+proxy+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ叡")+url+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ叢"))
	return response
def l11l1111lll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ口"),url,l1l11l_l1_ (u"ࠧࠨ古"),l1l11l_l1_ (u"ࠨࠩ句"),True,False,l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ另"),True,False)
	l1l11l11lll1_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l11l1111ll11_l1_
		l11l1l11l111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭叧"),html)
		#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ叨"),str(l11l1l11l111_l1_))
		if l11l1l11l111_l1_: html = l1l11l_l1_ (u"ࠬࡢ࡮ࠨ叩").join(l11l1l11l111_l1_)
		proxies = html.replace(l1l11l_l1_ (u"࠭࡜ࡳࠩ只"),l1l11l_l1_ (u"ࠧࠨ叫")).strip(l1l11l_l1_ (u"ࠨ࡞ࡱࠫ召")).split(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ叭"))
		l1l11l11lll1_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l11l_l1_ (u"ࠪ࠲ࠬ叮"))==3: l1l11l11lll1_l1_.append(proxy)
	return l1l11l11lll1_l1_
def OPENURL_REQUESTS_PROXIES(*args):
	#l11l1l1l111l_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠹࠻࠮࠴࠵࠱࠵࠼࠴࠱࠳࠹࠲ࡥࡵ࡯࠯ࡱࡴࡲࡼࡾࡅࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡶࡴࡪ࡫ࡤ࠾࠳࠳ࠪࡱࡧࡳࡵࡡࡦ࡬ࡪࡩ࡫࠾࠳࠳ࠪ࡭ࡺࡴࡱࡵࡀࡸࡷࡻࡥࠧࡲࡲࡷࡹࡃࡴࡳࡷࡨࠪ࡫ࡵࡲ࡮ࡣࡷࡁࡹࡾࡴࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ可")
	l1l111lllll1_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡴࡷࡵࡸࡺࡵࡦࡶࡦࡶࡥ࠯ࡥࡲࡱ࠴ࡼ࠲࠰ࡁࡵࡩࡶࡻࡥࡴࡶࡀࡨ࡮ࡹࡰ࡭ࡣࡼࡴࡷࡵࡸࡪࡧࡶࠪࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱࠲࠳࠴ࠫࡹࡳ࡭࠿ࡼࡩࡸࠬ࡬ࡪ࡯࡬ࡸࡂ࠷࠰ࠧࡥࡲࡹࡳࡺࡲࡺ࠿ࡑࡐ࠱ࡈࡅ࠭ࡆࡈ࠰ࡋࡘࠬࡈࡄ࠯ࡘࡗ࠭台")
	l11ll1111ll1_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸ࡯ࡰࡵࡷࡩࡷࡱࡩࡥ࠱ࡲࡴࡪࡴࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡰࡥ࡮ࡴ࠯ࡉࡖࡗࡔࡘ࠴ࡴࡹࡶࠪ叱")
	#l11lll1l11ll_l1_ = l11l1111lll1_l1_(l11l1l1l111l_l1_)
	l11lll1l11ll_l1_ = l11l1111lll1_l1_(l11ll1111ll1_l1_)
	l1l11l11lll1_l1_ = l11l1111lll1_l1_(l1l111lllll1_l1_)
	l1l11l11l1l1_l1_ = l11lll1l11ll_l1_+l1l11l11lll1_l1_
	LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭史"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧ右")+str(len(l11lll1l11ll_l1_))+l1l11l_l1_ (u"ࠩ࠮ࠫ叴")+str(len(l1l11l11lll1_l1_))+l1l11l_l1_ (u"ࠪࠤࡢ࠭叵"))
	proxy = settings.getSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ叶"))
	response = dummy_object()
	response.succeeded = False
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ号"),l1l11l_l1_ (u"࠭ࠧ司"))
	if proxy or l1l11l11l1l1_l1_:
		id,timeout = 0,10
		l11l111ll11l_l1_ = len(l1l11l11l1l1_l1_)
		l11lllll11ll_l1_ = timeout
		if l11l111ll11l_l1_>l11lllll11ll_l1_: counts = l11lllll11ll_l1_
		else: counts = l11l111ll11l_l1_
		l1l1111l1l11_l1_ = random.sample(l1l11l11l1l1_l1_,counts)
		if proxy: l1l1111l1l11_l1_ = [proxy]+l1l1111l1l11_l1_
		#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ叹"),str(l1l1111l1l11_l1_))
		threads = l11ll11llll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l1l1111l1111_l1_:
			if id<counts:
				proxy = l1l1111l1l11_l1_[id]
				threads.start_new_thread(id,l11l1ll1l1l1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ叺"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ叻")+proxy+l1l11l_l1_ (u"ࠪࠤࡢ࠭叼"))
		l1l1111l1111_l1_ = threads.l1l1111l1111_l1_
		if l1l1111l1111_l1_:
			l11ll1lll11l_l1_ = threads.l11ll1lll11l_l1_
			l11ll1l1l1ll_l1_ = l1l1111l1111_l1_[0]
			response = l11ll1lll11l_l1_[l11ll1l1l1ll_l1_]
			proxy = l1l1111l1l11_l1_[int(l11ll1l1l1ll_l1_)]
			settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ叽"),proxy)
			if l11ll1l1l1ll_l1_!=0: LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ叾"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ叿")+proxy+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ吀"))
			else: LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ吁"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ吂")+proxy+l1l11l_l1_ (u"ࠪࠤࡢ࠭吃"))
		#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ各"),l1l11l_l1_ (u"ࠬࡶࡲࡰࡺ࡬ࡩࡸࡒࡉࡔࡖ࠵ࠤ࠿ࡀࠠࠨ吅")+str(l1l1111l1l11_l1_))
		#LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭吆"),l1l11l_l1_ (u"ࠧࡱࡴࡲࡼ࡮࡫ࡳࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ吇")+str(l1l11l11l1l1_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ合"),l1l11l_l1_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ吉")+str(threads.l1l1111l1111_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ吊"),l1l11l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ吋")+str(threads.l1l11l11llll_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ同"),l1l11l_l1_ (u"࠭ࡲࡦࡵࡸࡰࡹࡹࡄࡊࡅࡗࠤ࠿ࡀࠠࠨ名")+str(threads.l11ll1lll11l_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ后"),l1l11l_l1_ (u"ࠨࡧ࡯ࡴࡦࡹࡥࡥࡶ࡬ࡱࡪࡊࡉࡄࡖࠣ࠾࠿ࠦࠧ吏")+str(threads.l1l111llll1l_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ吐"),l1l11l_l1_ (u"ࠪࡷࡴࡸࡴࡦࡦࡏࡍࡘ࡚ࠠ࠻࠼ࠣࠫ向")+str(l11l1111111_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ吒"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࠩ吓")+l11l111l111l_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ吔")+str(l11l1111111_l1_))
	return response
def USE_DNS_SERVER(connection,dns_server):
	original_create_connection = connection.create_connection
	def l11l11l1l1ll_l1_(address,*args,**kwargs):
		host,port = address
		l11111llll1_l1_ = DNS_RESOLVER(host,dns_server)
		if l11111llll1_l1_: host = l11111llll1_l1_[0]
		else:
			if dns_server in l1l1ll11l1l1_l1_: l1l1ll11l1l1_l1_.remove(dns_server)
			if l1l1ll11l1l1_l1_:
				l11l1l1111ll_l1_ = l1l1ll11l1l1_l1_[0]
				#LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ吕"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࡛ࠡࠢࠣ࡮ࡲ࡬ࠡࡶࡵࡽࠥࡺࡨࡦࠢࡲࡸ࡭࡫ࡲࠡࡆࡑࡗ࠿ࡡࠠࠨ吖")+l11l1l1111ll_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡱࡶࡸ࠿ࡡࠠࠨ吗")+str(host)+l1l11l_l1_ (u"ࠪࠤࡢ࠭吘"))
				l11111llll1_l1_ = DNS_RESOLVER(host,l11l1l1111ll_l1_)
				if l11111llll1_l1_: host = l11111llll1_l1_[0]
		address = (host,port)
		return original_create_connection(address,*args,**kwargs)
	connection.create_connection = l11l11l1l1ll_l1_
	return original_create_connection
def l1llll111l_l1_(expiry,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡸࡺࡲࠨ吙"),l1l11l_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭吚"),[method,url,data,headers,source])
	if html:
		LOG_OPENURL(True,url,data,headers,source,l1l11l_l1_ (u"࠭ࠧ君"))
		return html
	html = l1111lll1_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ吜"),[method,url,data,headers,source],html,expiry)
	return html
def l1111lll1_l1_(method,url,data=l1l11l_l1_ (u"ࠨࠩ吝"),headers=l1l11l_l1_ (u"ࠩࠪ吞"),source=l1l11l_l1_ (u"ࠪࠫ吟")):
	LOG_OPENURL(False,url,data,headers,source,l1l11l_l1_ (u"ࠫࠬ吠"))
	if kodi_version>18.99: import urllib.request as l11l111ll1l1_l1_
	else: import urllib2 as l11l111ll1l1_l1_
	if not headers: headers = {l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ吡"):l1l11l_l1_ (u"࠭ࠧ吢")}
	if not data: data = {}
	if method==l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ吣"):
		url = url+l1l11l_l1_ (u"ࠨࡁࠪ吤")+l111111l_l1_(data)
		data = None
	try:
		req = l11l111ll1l1_l1_.Request(url,headers=headers,data=data)
		http_response = l11l111ll1l1_l1_.urlopen(req)
		html = http_response.read()
	except: html = l1l11l_l1_ (u"ࠩࠪ吥")
	#try:
	#	req = l11l111ll1l1_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l11l111ll1l1_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l1l11l_l1_ (u"ࠪࠫ否")
	return html
def l111llll1l1l_l1_(url):
	l1l111l1111l_l1_,l11lll11ll11_l1_ = url.split(l1l11l_l1_ (u"ࠫ࠴࠭吧"))[2],80
	if l1l11l_l1_ (u"ࠬࡀࠧ吨") in l1l111l1111l_l1_: l1l111l1111l_l1_,l11lll11ll11_l1_ = l1l111l1111l_l1_.split(l1l11l_l1_ (u"࠭࠺ࠨ吩"))
	l11l111l1lll_l1_ = l1l11l_l1_ (u"ࠧ࠰ࠩ吪")+l1l11l_l1_ (u"ࠨ࠱ࠪ含").join(url.split(l1l11l_l1_ (u"ࠩ࠲ࠫ听"))[3:])
	request = l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠠࠨ吭")+l11l111l1lll_l1_+l1l11l_l1_ (u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫ吮")
	#request += l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠼ࠣࡠࡷࡢ࡮ࠨ启")
	request += l1l11l_l1_ (u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭吰")+l1l111l1111l_l1_+l1l11l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ吱")
	request += l1l11l_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭吲")
	import socket
	try:
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect((l1l111l1111l_l1_,l11lll11ll11_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l11l_l1_ (u"ࠩࠪ吳")
	return html
def SERVER(l1111l_l1_,type):
	# url:	http://l1llllll1ll1_l1_.l11lll1ll1ll_l1_.l11111ll_l1_
	# host:	l1llllll1ll1_l1_.l11lll1ll1ll_l1_.l11111ll_l1_
	# name:	l11lll1ll1ll_l1_
	#server = l1l11l_l1_ (u"ࠪ࠳ࠬ吴").join(l1111l_l1_.split(l1l11l_l1_ (u"ࠫ࠴࠭吵"))[:3])
	if l1l11l_l1_ (u"ࠬ࠴ࠧ吶") not in l1111l_l1_: return l1111l_l1_
	l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠯ࠨ吷")
	part1,part2 = l1111l_l1_.split(l1l11l_l1_ (u"ࠧ࠯ࠩ吸"),1)
	l11l11l1lll1_l1_,l11l11l1ll1l_l1_ = part2.split(l1l11l_l1_ (u"ࠨ࠱ࠪ吹"),1)
	server = part1+l1l11l_l1_ (u"ࠩ࠱ࠫ吺")+l11l11l1lll1_l1_
	if type in [l1l11l_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ吻"),l1l11l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ吼")] and l1l11l_l1_ (u"ࠬ࠵ࠧ吽") in server: server = server.rsplit(l1l11l_l1_ (u"࠭࠯ࠨ吾"),1)[1]
	if type==l1l11l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ吿") and l1l11l_l1_ (u"ࠨ࠰ࠪ呀") in server:
		l11l11l111ll_l1_ = server.split(l1l11l_l1_ (u"ࠩ࠱ࠫ呁"))
		length = len(l11l11l111ll_l1_)
		if length<=2 or l1l11l_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ呂") in server: l11l11l111ll_l1_ = l11l11l111ll_l1_[0]
		elif length>=3: l11l11l111ll_l1_ = l11l11l111ll_l1_[1]
		if len(l11l11l111ll_l1_)>1: server = l11l11l111ll_l1_
	return server
	l1l11l_l1_ (u"ࠦࠧࠨࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࠪ࠳ࠬ࠱ࡵࡳ࡮࠵࠯ࠬ࠵ࠧࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡳ࡫ࡴ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡨࡵ࡭࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡴࡸࡧ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡶࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡺࡶ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡼࡹ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡸࡴ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡰࡩ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡳࡷ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣࡢ࡯࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡯࡯࡮࡬ࡲࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰࡯࡭ࡻ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡱࡻࡢ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡦࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡳࡸ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲࡮ࡴ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡻࡼࡽ࠮ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡱ࠳࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡧࡰࡦࡪࡪ࠮ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࠥࠦࠧ呃")
def l1l11ll1ll1_l1_(l1l11ll111ll_l1_):
	l1l11l1l11l1_l1_ = repr(l1l11ll111ll_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ呄"))).replace(l1l11l_l1_ (u"ࠨࠧࠣ呅"),l1l11l_l1_ (u"ࠧࠨ呆"))
	return l1l11l1l11l1_l1_
def l1ll1ll11ll_l1_(string):
	#if l1l11l_l1_ (u"ࠨ࡞ࡸࠫ呇") in string:
	#	string = string.decode(l1l11l_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ呈"))
	#	l11ll11l1l1l_l1_=re.findall(l1l11l_l1_ (u"ࡵࠫࡡࡻ࡛࠱࠯࠼ࡅ࠲ࡌ࡝ࠨ呉"),string)
	#	for unicode in l11ll11l1l1l_l1_
	#		char = l111lll11l11_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ告"))
	l11l11111l11_l1_ = l1l11l_l1_ (u"ࠬ࠭呋")
	if kodi_version<19: string = string.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ呌"))
	import unicodedata
	for l1ll1ll111l_l1_ in string:
		if   l1ll1ll111l_l1_==l1l11l_l1_ (u"ࡵࠨฤࠪ呍"): l11llllll11l_l1_ = l1l11l_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠳ࠩ呎")
		elif l1ll1ll111l_l1_==l1l11l_l1_ (u"ࡷࠪวࠬ呏"): l11llllll11l_l1_ = l1l11l_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠶ࠫ呐")
		elif l1ll1ll111l_l1_==l1l11l_l1_ (u"ࡹࠬสࠧ呑"): l11llllll11l_l1_ = l1l11l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠹࠭呒")
		elif l1ll1ll111l_l1_==l1l11l_l1_ (u"ࡻࠧฦࠩ呓"): l11llllll11l_l1_ = l1l11l_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠵ࠨ呔")
		elif l1ll1ll111l_l1_==l1l11l_l1_ (u"ࡶࠩษࠫ呕"): l11llllll11l_l1_ = l1l11l_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠸ࠪ呖")
		else:
			l111ll1llll1_l1_ = unicodedata.decomposition(l1ll1ll111l_l1_)
			if l1l11l_l1_ (u"ࠪࠤࠬ呗") in l111ll1llll1_l1_: l11llllll11l_l1_ = l1l11l_l1_ (u"ࠫࡡࡢࡵࠨ员")+l111ll1llll1_l1_.split(l1l11l_l1_ (u"ࠬࠦࠧ呙"),1)[1]
			else:
				l11llllll11l_l1_ = l1l11l_l1_ (u"࠭࠰࠱࠲࠳ࠫ呚")+hex(ord(l1ll1ll111l_l1_)).replace(l1l11l_l1_ (u"ࠧ࠱ࡺࠪ呛"),l1l11l_l1_ (u"ࠨࠩ呜"))
				l11llllll11l_l1_ = l1l11l_l1_ (u"ࠩ࡟ࡠࡺ࠭呝")+l11llllll11l_l1_[-4:]
			#if ord(l1ll1ll111l_l1_)<256: l11llllll11l_l1_ = l1l11l_l1_ (u"ࠪࡠࡡࡻ࠰࠱ࠩ呞")+l11l11l11111_l1_
			#elif ord(l1ll1ll111l_l1_)<4096: l11llllll11l_l1_ = l1l11l_l1_ (u"ࠫࡡࡢࡵ࠱ࠩ呟")+l11l11l11111_l1_
			#elif l1l11l_l1_ (u"ࠬࠦࠧ呠") in l111ll1llll1_l1_: l11llllll11l_l1_ = l1l11l_l1_ (u"࠭࡜࡝ࡷࠪ呡")+l111ll1llll1_l1_.split(l1l11l_l1_ (u"ࠧࠡࠩ呢"),1)[1]
			#else: l11llllll11l_l1_ = l1l11l_l1_ (u"ࠨ࡞࡟ࡹࠬ呣")+l11l11l11111_l1_
		l11l11111l11_l1_ += l11llllll11l_l1_
	l11l11111l11_l1_ = l11l11111l11_l1_.replace(l1l11l_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪ呤"),l1l11l_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫ呥"))
	if kodi_version<19: l11l11111l11_l1_ = l11l11111l11_l1_.decode(l1l11l_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ呦")).encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ呧"))
	else: l11l11111l11_l1_ = l11l11111l11_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ周")).decode(l1l11l_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ呩"))
	return l11l11111l11_l1_
def OPEN_KEYBOARD(header=l1l11l_l1_ (u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨ呪"),default=l1l11l_l1_ (u"ࠩࠪ呫"),l11lllll111l_l1_=False):
	text = l11l1l111lll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l11l_l1_ (u"ࠪࠤࠥ࠭呬"),l1l11l_l1_ (u"ࠫࠥ࠭呭")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ呮"),l1l11l_l1_ (u"࠭ࠠࠨ呯")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ呰"),l1l11l_l1_ (u"ࠨࠢࠪ呱"))
	if not text and not l11lllll111l_l1_:
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ呲"),l1l11l_l1_ (u"ࠪ࠲ࠥࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨ味")+text+l1l11l_l1_ (u"ࠫࠧ࠭呴"))
		DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭呵"),l1l11l_l1_ (u"࠭ࠧ呶"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ呷"),l1l11l_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หฯฯษ็ࠫ呸"))
		return l1l11l_l1_ (u"ࠩࠪ呹")
	if text not in [l1l11l_l1_ (u"ࠪࠫ呺"),l1l11l_l1_ (u"ࠫࠥ࠭呻")]:
		text = text.strip(l1l11l_l1_ (u"ࠬࠦࠧ呼"))
		text = l1ll1ll11ll_l1_(text)
	if l1l11_l1_(l1l11l_l1_ (u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨ命"),l1l11l_l1_ (u"ࠧࠨ呾"),[text],False):
		LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ呿"),l1l11l_l1_ (u"ࠩ࠱ࠤࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠻ࠢࠣࠤࠧ࠭咀")+text+l1l11l_l1_ (u"ࠪࠦࠬ咁"))
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ咂"),l1l11l_l1_ (u"ࠬ࠭咃"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ咄"),l1l11l_l1_ (u"ࠧษฯฮࠤ฿๐ัࠡ็ึ้ํำࠠษ้ࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠬ咅"))
		return l1l11l_l1_ (u"ࠨࠩ咆")
	LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ咇"),l1l11l_l1_ (u"ࠪ࠲ࠥࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡣ࡯ࡰࡴࡽࡥࡥ࠼ࠣࠤࠥࠨࠧ咈")+text+l1l11l_l1_ (u"ࠫࠧ࠭咉"))
	return text
def l11lll11lll1_l1_():
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l11l_l1_ (u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡ࡞࡞࠳ࡈࡕࡌࡐࡔ࡟ࡡࠬ咊"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l11l_l1_ (u"࠭࡟ࠦ࡯࠱ࠩࡩࡥࠥࡉ࠼ࠨࡑࡤ࠭咋"),time.localtime(now))
	name = name+datetime
	menuItem = (type,name,url,mode,image,page,text,context,l1l11l_l1_ (u"ࠧࠨ和"))
	if os.path.exists(l1ll111111l_l1_):
		oldFILE = open(l1ll111111l_l1_,l1l11l_l1_ (u"ࠨࡴࡥࠫ咍")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ咎"))
		oldFILE = EVAL(l1l11l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ咏"),oldFILE)
	else: oldFILE = {}
	newFILE = {}
	for l11l111lll1l_l1_ in list(oldFILE.keys()):
		if l11l111lll1l_l1_!=type: newFILE[l11l111lll1l_l1_] = oldFILE[l11l111lll1l_l1_]
		else:
			if name and name!=l1l11l_l1_ (u"ࠫ࠳࠴ࠧ咐"):
				oldLIST = oldFILE[l11l111lll1l_l1_]
				if menuItem in oldLIST:
					index = oldLIST.index(menuItem)
					del oldLIST[index]
				newLIST = [menuItem]+oldLIST
				newLIST = newLIST[:50]
				newFILE[l11l111lll1l_l1_] = newLIST
			else: newFILE[l11l111lll1l_l1_] = oldFILE[l11l111lll1l_l1_]
	if type not in list(newFILE.keys()): newFILE[type] = [menuItem]
	newFILE = str(newFILE)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ咑"))
	open(l1ll111111l_l1_,l1l11l_l1_ (u"࠭ࡷࡣࠩ咒")).write(newFILE)
	return
def l1ll11111l_l1_(url2,headers={}):
	#if headers[l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ咓")]==l1l11l_l1_ (u"ࠨࠩ咔"): headers[l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭咕")] = l1l11l_l1_ (u"ࠪࠤࠬ咖")
	#l11ll11ll1ll_l1_ = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ咗") : l1l11l_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠺࠹࠳࠶࠮࠴࠹࠺࠴࠳࠷࠴࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ咘") }
	#url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡦ࠻࠸࠳ࡳࡹࡤࡦࡱ࠲ࡲ࡫࠯ࡷ࡫ࡧࡩࡴ࠴࡭࠴ࡷ࠻ࠫ咙")
	#open(l1l11l_l1_ (u"ࠧࡔ࠼࡟ࡠࡹ࡫ࡳࡵ࠴࠱ࡱ࠸ࡻ࠸ࠨ咚"), l1l11l_l1_ (u"ࠨࡴࠪ咛")).read()
	url,params = url2,l1l11l_l1_ (u"ࠩࠪ咜")
	if l1l11l_l1_ (u"ࠪࢀࠬ咝") in url2:
		url,params = url2.split(l1l11l_l1_ (u"ࠫࢁ࠭咞"),1)
		if l1l11l_l1_ (u"ࠬࡃࠧ咟") not in params: url,params = url2,l1l11l_l1_ (u"࠭ࠧ咠")
	response = OPENURL_REQUESTS_CACHED(l1l11ll11ll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ咡"),url,l1l11l_l1_ (u"ࠨࠩ咢"),headers,l1l11l_l1_ (u"ࠩࠪ咣"),True,l1l11l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ咤"),False,False)
	html = response.content
	if l1l11l_l1_ (u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨ咥") not in html: return [l1l11l_l1_ (u"ࠬ࠳࠱ࠨ咦")],[url2]
	#	if l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ咧") in list(headers.keys()): del headers[l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ咨")]
	#	else: headers[l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ咩")] = l1l11l_l1_ (u"ࠩࠪ咪")
	#	response = OPENURL_REQUESTS_CACHED(l1l11ll11ll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ咫"),url,l1l11l_l1_ (u"ࠫࠬ咬"),headers,l1l11l_l1_ (u"ࠬ࠭咭"),False,l1l11l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠲࡯ࡦࠪ咮"),False,False)
	#	html = response.content
	if l1l11l_l1_ (u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫ咯") in html: return [l1l11l_l1_ (u"ࠨ࠯࠴ࠫ咰")],[url2]
	if l1l11l_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭咱") in html: return [l1l11l_l1_ (u"ࠪ࠱࠶࠭咲")],[url2]
	#if l1l11l_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿ࡖ࡙ࡇ࡚ࡉࡕࡎࡈࡗࠬ咳") in html: return [l1l11l_l1_ (u"ࠬ࠳࠱ࠨ咴")],[url2]
	l1l1lll_l1_,l1ll1l1l_l1_,l11lll1llll1_l1_,l1l11l11l1ll_l1_ = [],[],[],[]
	lines = re.findall(l1l11l_l1_ (u"࠭࡜ࠤࡇ࡛ࡘ࠲࡞࠭ࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉ࠾࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭咵"),html+l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡶࠬ咶"),re.DOTALL)
	if not lines: return [l1l11l_l1_ (u"ࠨ࠯࠴ࠫ咷")],[url2]
	for line,l1111l_l1_ in lines:
		l111lllllll1_l1_,l11llllll11_l1_,l1l1l111_l1_ = {},-1,-1
		title = l1l11l_l1_ (u"ࠩࠪ咸")
		#hostname = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠪࡲࡦࡳࡥࠨ咹"))
		#title = title+l1l11l_l1_ (u"ࠫࠥࠦࠧ咺")+hostname+l1l11l_l1_ (u"ࠬࠦࠠࠨ咻")
		#line = line.lower()
		items = line.split(l1l11l_l1_ (u"࠭ࠬࠨ咼"))
		for item in items:
			#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ咽"),l1l11l_l1_ (u"ࠨࠩ咾"),item,l1l11l_l1_ (u"ࠩࠪ咿"))
			#if l1l11l_l1_ (u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ哀") in item: l111lllllll1_l1_[key] = value
			if l1l11l_l1_ (u"ࠫࡂ࠭品") in item:
				key,value = item.split(l1l11l_l1_ (u"ࠬࡃࠧ哂"),1)
				l111lllllll1_l1_[key.lower()] = value
		if l1l11l_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ哃") in line.lower():
			l11llllll11_l1_ = int(l111lllllll1_l1_[l1l11l_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ哄")])//1024
			#title += l1l11l_l1_ (u"ࠨࡃࡹ࡫ࡇ࡝࠺ࠡࠩ哅")+str(l11llllll11_l1_)+l1l11l_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ哆")
			title += str(l11llllll11_l1_)+l1l11l_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ哇")
		elif l1l11l_l1_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ哈") in line.lower():
			l11llllll11_l1_ = int(l111lllllll1_l1_[l1l11l_l1_ (u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ哉")])//1024
			#title += l1l11l_l1_ (u"࠭ࡂࡘ࠼ࠣࠫ哊")+str(l11llllll11_l1_)+l1l11l_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ哋")
			title += str(l11llllll11_l1_)+l1l11l_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ哌")
		if l1l11l_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭响") in line.lower():
			l1l1l111_l1_ = int(l111lllllll1_l1_[l1l11l_l1_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ哎")].split(l1l11l_l1_ (u"ࠫࡽ࠭哏"))[1])
			#title += l1l11l_l1_ (u"ࠬࡘࡥࡴ࠼ࠣࠫ哐")+str(l1l1l111_l1_)+l1l11l_l1_ (u"࠭ࠠࠡࠩ哑")
			title += str(l1l1l111_l1_)+l1l11l_l1_ (u"ࠧࠡࠢࠪ哒")
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠣࠫ哓"))
		if not title: title = l1l11l_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ哔")
		if not l1111l_l1_.startswith(l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ哕")):
			if l1111l_l1_.startswith(l1l11l_l1_ (u"ࠫ࠴࠵ࠧ哖")): l1111l_l1_ = url.split(l1l11l_l1_ (u"ࠬࡀࠧ哗"),1)[0]+l1l11l_l1_ (u"࠭࠺ࠨ哘")+l1111l_l1_
			elif l1111l_l1_.startswith(l1l11l_l1_ (u"ࠧ࠰ࠩ哙")): l1111l_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ哚"))+l1111l_l1_
			else: l1111l_l1_ = url.rsplit(l1l11l_l1_ (u"ࠩ࠲ࠫ哛"),1)[0]+l1l11l_l1_ (u"ࠪ࠳ࠬ哜")+l1111l_l1_
		if params!=l1l11l_l1_ (u"ࠫࠬ哝"): l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࢂࠧ哞")+params
		if l1l11l_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ哟") in list(l111lllllll1_l1_.keys()):
			l111l1ll1_l1_ = l111lllllll1_l1_[l1l11l_l1_ (u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ哠")]
			l111l1ll1_l1_ = l111l1ll1_l1_.replace(l1l11l_l1_ (u"ࠨࠤࠪ員"),l1l11l_l1_ (u"ࠩࠪ哢")).replace(l1l11l_l1_ (u"ࠥࠫࠧ哣"),l1l11l_l1_ (u"ࠫࠬ哤")).split(l1l11l_l1_ (u"ࠬࠩࠧ哥"),1)[0]
			videofiletype = GET_VIDEOFILETYPE(l111l1ll1_l1_)
			if videofiletype: title2 = title+l1l11l_l1_ (u"࠭ࠠࠡࠩ哦")+videofiletype
			else: title2 = title
			title2 = title2+l1l11l_l1_ (u"ࠧࠡࠢࡓࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫ࠧ哧")
			title2 = title2+l1l11l_l1_ (u"ࠨࠢࠣࠫ哨")+SERVER(l111l1ll1_l1_,l1l11l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ哩"))
			l1l1lll_l1_.append(title2)
			l1ll1l1l_l1_.append(l111l1ll1_l1_)
			l11lll1llll1_l1_.append(l1l1l111_l1_)
			l1l11l11l1ll_l1_.append(l11llllll11_l1_)
		l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠪࠧࠬ哪"),1)[0]
		videofiletype = GET_VIDEOFILETYPE(l1111l_l1_)
		if videofiletype: title = title+l1l11l_l1_ (u"ࠫࠥࠦࠧ哫")+videofiletype
		title = title+l1l11l_l1_ (u"ࠬࠦࠠࠨ哬")+SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ哭"))
		l1l1lll_l1_.append(title)
		l1ll1l1l_l1_.append(l1111l_l1_)
		l11lll1llll1_l1_.append(l1l1l111_l1_)
		l1l11l11l1ll_l1_.append(l11llllll11_l1_)
	zz = list(zip(l1l1lll_l1_,l1ll1l1l_l1_,l11lll1llll1_l1_,l1l11l11l1ll_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll_l1_,l1ll1l1l_l1_,l11lll1llll1_l1_,l1l11l11l1ll_l1_ = list(zip(*zz))
	l1l1lll_l1_,l1ll1l1l_l1_ = list(l1l1lll_l1_),list(l1ll1l1l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧࠨ哮"), l1l1lll_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨࠩ哯"), l1ll1l1l_l1_)
	return l1l1lll_l1_,l1ll1l1l_l1_
mac = l1l11l_l1_ (u"ࠩࠪ哰")
def l11lll111ll1_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1ll1l1l11l_l1_(length=32):
	l1ll1l1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡷࡹࡸࠧ哱"),l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ哲"),l1l11l_l1_ (u"ࠬࡉࡌࡊࡇࡑࡘࡎࡊࠧ哳"))
	if l1ll1l1l1l_l1_: return l1ll1l1l1l_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l11l11lll1ll_l1_ = threading.Thread(target=l11lll111ll1_l1_,args=())
	l11l11lll1ll_l1_.start()
	for ii in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l1l11l_l1_ (u"࠭࠰࠱࠳࠴࠶࠷࠹࠳࠵࠶࠸࠹࠻࠼࠷࠸ࠩ哴")
	else:
		mac = mac.replace(l1l11l_l1_ (u"ࠧ࠻ࠩ哵"),l1l11l_l1_ (u"ࠨࠩ哶"))
		node = str(int(mac,16))
	node = re.findall(l1l11l_l1_ (u"ࠩ࡞࠴࠲࠿࡝ࠬࠩ哷"),node,re.DOTALL)
	node = length*l1l11l_l1_ (u"ࠪ࠴ࠬ哸")+node[0]
	node = node[-length:]
	mm,ss = l1l11l_l1_ (u"ࠫࠬ哹"),l1l11l_l1_ (u"ࠬ࠭哺")
	l11l1l1l1l11_l1_ = str(int(l1l11l_l1_ (u"࠭࠹ࠨ哻")*(length+1))-int(node))[-length:]
	for ii in list(range(0,length,4)):
		l111lll1ll1l_l1_ = l11l1l1l1l11_l1_[ii:ii+4]
		mm += l111lll1ll1l_l1_+l1l11l_l1_ (u"ࠧ࠮ࠩ哼")
		ss += str(sum(map(int,node[ii:ii+4]))%10)
	l1ll1l1l1l_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ哽"),l1l11l_l1_ (u"ࠩࡆࡐࡎࡋࡎࡕࡋࡇࠫ哾"),l1ll1l1l1l_l1_,PERMANENT_CACHE)
	return l1ll1l1l1l_l1_
def DNS_RESOLVER(host,dns_server=l1l1ll11l1l1_l1_[0]):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ哿"),l1l11l_l1_ (u"ࠫࠬ唀"),str(dns_server),str(host))
	if host.replace(l1l11l_l1_ (u"ࠬ࠴ࠧ唁"),l1l11l_l1_ (u"࠭ࠧ唂")).isdigit(): return [host]
	import struct,socket
	try:
		l11ll1lll1l1_l1_ = struct.pack(l1l11l_l1_ (u"ࠢ࠿ࡊࠥ唃"), 12049)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠣࡀࡋࠦ唄"), 256)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠤࡁࡌࠧ唅"), 1)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠥࡂࡍࠨ唆"), 0)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠦࡃࡎࠢ唇"), 0)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠧࡄࡈࠣ唈"), 0)
		if kodi_version>18.99: l11ll111l1ll_l1_ = host.split(l1l11l_l1_ (u"࠭࠮ࠨ唉"))
		else: l11ll111l1ll_l1_ = host.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ唊")).split(l1l11l_l1_ (u"ࠨ࠰ࠪ唋"))
		for part in l11ll111l1ll_l1_:
			parts = part.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ唌"))
			l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠥࡆࠧ唍"), len(part))
			for l11lll11l1l1_l1_ in part:
				l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠦࡨࠨ唎"), l11lll11l1l1_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ唏")))
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠨࡂࠣ唐"), 0)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠢ࠿ࡊࠥ唑"), 1)
		l11ll1lll1l1_l1_ += struct.pack(l1l11l_l1_ (u"ࠣࡀࡋࠦ唒"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l11ll1lll1l1_l1_), (dns_server, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l1l1111l1lll_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ唓"), data, 0)
		l11llll11lll_l1_ = l1l1111l1lll_l1_[3]
		offset = len(host)+18
		answer = []
		for _ in range(l11llll11lll_l1_):
			l11lll1lll11_l1_ = offset
			l11l1lll1111_l1_ = 1
			l11ll1ll1ll1_l1_ = False
			while True:
				l11lll11l1l1_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠥࡂࡇࠨ唔"), data, l11lll1lll11_l1_)[0]
				if l11lll11l1l1_l1_ == 0:
					l11lll1lll11_l1_ += 1
					break
				# l11l11l1ll11_l1_ the field l11l11l111l1_l1_ the first l1l1111lll1l_l1_ bits l11l1ll111ll_l1_ to 1, l11l1lll1ll_l1_ a pointer
				if l11lll11l1l1_l1_ >= 192:
					l11lll111lll_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠦࡃࡈࠢ唕"), data, l11lll1lll11_l1_ + 1)[0]
					# l111lllll1l1_l1_ the pointer
					l11lll1lll11_l1_ = ((l11lll11l1l1_l1_ << 8) + l11lll111lll_l1_ - 0xc000) - 1
					l11ll1ll1ll1_l1_ = True
				l11lll1lll11_l1_ += 1
				if l11ll1ll1ll1_l1_ == False: l11l1lll1111_l1_ += 1
			if l11ll1ll1ll1_l1_ == True: l11l1lll1111_l1_ += 1
			offset = offset + l11l1lll1111_l1_
			l1l11l111ll1_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠧࡄࡈࡉࡋࡋࠦ唖"), data, offset)
			offset = offset + 10
			l1l1111llll1_l1_ = l1l11l111ll1_l1_[0]
			l11ll1lll111_l1_ = l1l11l111ll1_l1_[3]
			if l1l1111llll1_l1_ == 1: # l1l1111111ll_l1_ type
				l11lll11l1ll_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠨ࠾ࠣ唗")+l1l11l_l1_ (u"ࠢࡃࠤ唘")*l11ll1lll111_l1_, data, offset)
				l11111llll1_l1_ = l1l11l_l1_ (u"ࠨࠩ唙")
				for l11lll11l1l1_l1_ in l11lll11l1ll_l1_: l11111llll1_l1_ += str(l11lll11l1l1_l1_) + l1l11l_l1_ (u"ࠩ࠱ࠫ唚")
				l11111llll1_l1_ = l11111llll1_l1_[0:-1]
				answer.append(l11111llll1_l1_)
			if l1l1111llll1_l1_ in [1,2,5,6,15,28]: offset = offset + l11ll1lll111_l1_
	except: answer = []
	if not answer: LOG_THIS(l1l11l_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ唛"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ唜")+host+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ唝"))
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ唞"),l1l11l_l1_ (u"ࠧࠨ唟"),str(host),str(answer))
	return answer
def l1l11_l1_(script_name,url,l1l1l_l1_,showDialog=True):
	if l1l1l_l1_:
		l1l1111l1ll1_l1_ = [l1l11l_l1_ (u"ࠨๅหหึ࠭唠"),l1l11l_l1_ (u"ࠩหห้เࠧ唡"),l1l11l_l1_ (u"ࠪࡥࡩࡻ࡬ࡵࠩ唢"),l1l11l_l1_ (u"ࠫࡽࡾࠧ唣"),l1l11l_l1_ (u"ࠬࡹࡥࡹࠩ唤")]
		if script_name!=l1l11l_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ唥"):
			l1l1111l1ll1_l1_ += [l1l11l_l1_ (u"ࠧࡳ࠼ࠪ唦"),l1l11l_l1_ (u"ࠨࡴ࠰ࠫ唧"),l1l11l_l1_ (u"ࠩ࠰ࡱࡦ࠭唨")]
			l1l1111l1ll1_l1_ += [l1l11l_l1_ (u"ࠪ࠾ࡷ࠭唩"),l1l11l_l1_ (u"ࠫ࠲ࡸࠧ唪"),l1l11l_l1_ (u"ࠬࡳࡡ࠮ࠩ唫")]
		for l1lllll111_l1_ in l1l1l_l1_:
			if l1l11l_l1_ (u"࠭ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨ唬") in l1lllll111_l1_: continue
			if l1l11l_l1_ (u"ࠧฮๆๅอࠬ唭") in l1lllll111_l1_: continue
			l1lllll111_l1_ = l1lllll111_l1_.lower()
			if kodi_version<19: l1lllll111_l1_ = l1lllll111_l1_.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭售")).encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ唯"))
			#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ唰"),l1l11l_l1_ (u"ࠫࠬ唱"),l1l11l_l1_ (u"ࠬ࠭唲"),str(l1lllll111_l1_))
			#l11llll11l11_l1_ = re.findall(l1l11l_l1_ (u"࠭࡞ࠩ࠳࡞࠺࠲࠿࡝ࡽ࠴࡞࠴࠲࠿࡝ࠪࠦࠪ唳"),l1lllll111_l1_,re.DOTALL)
			#l11llll11ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࡟࡞࠮ࠬ࠶ࡡ࠶࠮࠻ࡠࢀ࠷ࡡ࠰࠮࠻ࡠ࠭ࠩ࠭唴"),l1lllll111_l1_,re.DOTALL)
			#l111lllll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡠࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࡠ࠰ࠪࠧ唵"),l1lllll111_l1_,re.DOTALL)
			#l11lll11l111_l1_ = any(l11llll11l11_l1_,l11llll11ll1_l1_,l111lllll111_l1_,l11llll111ll_l1_)
			l1lllll111_l1_ = l1lllll111_l1_.replace(l1l11l_l1_ (u"ࠩ࠽ࠫ唶"),l1l11l_l1_ (u"ࠪࠫ唷"))
			l11lll11l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ唸"),l1lllll111_l1_,re.DOTALL)
			l11ll1l1llll_l1_ = False
			for digits in l11lll11l111_l1_:
				if len(digits)==2:
					l11ll1l1llll_l1_ = True
					break
			if l1l11l_l1_ (u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨ唹") in l1lllll111_l1_: continue
			elif l1l11l_l1_ (u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧ唺") in l1lllll111_l1_: continue
			elif l1l11l_l1_ (u"ࠧ฻์ิࠤ๊฻ๆโࠩ唻") in l1lllll111_l1_: continue
			elif l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡮࡙ࡈ࡛ࡋࡖࡆ࡚ࠪ唼")): continue
			elif l1lllll111_l1_ in [l1l11l_l1_ (u"ࠩࡵࠫ唽")] or l11ll1l1llll_l1_ or any(value in l1lllll111_l1_ for value in l1l1111l1ll1_l1_):
				LOG_THIS(l1l11l_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ唾"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡣࡧࡹࡱࡺࡳࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ唿")+url+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ啀"))
				if showDialog: DIALOG_NOTIFICATION(l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ啁"),l1l11l_l1_ (u"ࠧศๆไ๎ิ๐่ࠡๆ็็ออัࠡใๅ฻ࠥ๎ร็ษ้๋ࠣ฿ส่ࠩ啂"))
				return True
	return False
def l111111l_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l11l111lll_l1_
	else: import urllib as l1l11l111lll_l1_
	l11lllll1l11_l1_ = l1l11l111lll_l1_.urlencode(data)
	return l11lllll1l11_l1_
def URLDECODE(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ啃"),l1l11l_l1_ (u"ࠩࠪ啄"),url,l1l11l_l1_ (u"࡙ࠪࡗࡒࡄࡆࡅࡒࡈࡊ࠭啅"))
	if l1l11l_l1_ (u"ࠫࡂ࠭商") in url:
		if l1l11l_l1_ (u"ࠬࡅࠧ啇") in url: url2,filters = url.split(l1l11l_l1_ (u"࠭࠿ࠨ啈"))
		else: url2,filters = l1l11l_l1_ (u"ࠧࠨ啉"),url
		filters = filters.split(l1l11l_l1_ (u"ࠨࠨࠪ啊"))
		data2 = {}
		for filter in filters:
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ啋"),l1l11l_l1_ (u"ࠪࠫ啌"),filter,str(filters))
			key,value = filter.split(l1l11l_l1_ (u"ࠫࡂ࠭啍"))
			data2[key] = value
	else: url2,data2 = url,{}
	return url2,data2
def PLAY_VIDEO(url3,website=l1l11l_l1_ (u"ࠬ࠭啎"),type_=l1l11l_l1_ (u"࠭ࠧ問")):
	if not type_: type_ = l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭啐")
	result,l1l1111lll11_l1_,httpd = l1l11l_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ啑"),l1l11l_l1_ (u"ࠩࠪ啒"),l1l11l_l1_ (u"ࠪࠫ啓")
	if len(url3)==3:
		url,l11l1ll11111_l1_,httpd = url3
		if l11l1ll11111_l1_!=l1l11l_l1_ (u"ࠫࠬ啔"): l1l1111lll11_l1_ = l1l11l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ啕")+l11l1ll11111_l1_+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ啖")
	else: url,l11l1ll11111_l1_,httpd = url3,l1l11l_l1_ (u"ࠧࠨ啗"),l1l11l_l1_ (u"ࠨࠩ啘")
	#url = UNQUOTE(url)		# cause l111lll11ll1_l1_ for l1111ll1_l1_ l11l1111_l1_ l11lll1l1l1_l1_ streams
	url = url.replace(l1l11l_l1_ (u"ࠩࠨ࠶࠵࠭啙"),l1l11l_l1_ (u"ࠪࠤࠬ啚"))	# needed for l1llll1ll1l1_l1_
	videofiletype = GET_VIDEOFILETYPE(url,website)
	if website not in [l1l11l_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭啛"),l1l11l_l1_ (u"ࠬࡏࡐࡕࡘࠪ啜")]:
		if website!=l1l11l_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ啝"): url = url.replace(l1l11l_l1_ (u"ࠧࠡࠩ啞"),l1l11l_l1_ (u"ࠨࠧ࠵࠴ࠬ啟"))
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ啠"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ啡")+url+l1l11l_l1_ (u"ࠫࠥࡣࠧ啢")+l1l1111lll11_l1_)
		if videofiletype==l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ啣") and website not in [l1l11l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ啤"),l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ啥")]:
			headers = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ啦"):l1l11l_l1_ (u"ࠩࠪ啧")}
			l1l1lll_l1_,l1ll1l1l_l1_ = l1ll11111l_l1_(url,headers)
			count = len(l1ll1l1l_l1_)
			if count>1:
				selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ啨")+str(count)+l1l11l_l1_ (u"๋ࠫࠥไโࠫࠪ啩"), l1l1lll_l1_)
				if selection == -1:
					DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอุ฿๐ไࠨ啪"),l1l11l_l1_ (u"࠭ࠧ啫"))
					return result
			else: selection = 0
			url = l1ll1l1l_l1_[selection]
			if l1l1lll_l1_[0]!=l1l11l_l1_ (u"ࠧ࠮࠳ࠪ啬"):
				LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ啭"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ啮")+l1l1lll_l1_[selection]+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ啯")+url+l1l11l_l1_ (u"ࠫࠥࡣࠧ啰"))
		#url = url+l1l11l_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠳࠻࠺࠵࠶࠰࠱ࠩ啱")
		#url = url+l1l11l_l1_ (u"࠭ࡼࡅࡐࡗࡁ࠶ࠬࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥ࠾ࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠶ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࡁ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠪࡆࡩࡣࡦࡲࡷࡁ࠯࠵ࠪࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬࡑ࡯࡮ࡶࡺ࠾ࠤࡆࡴࡤࡳࡱ࡬ࡨࠥ࠽࠮࠱࠽ࠣࡗࡒ࠳ࡇ࠹࠻࠵ࡅࠥࡈࡵࡪ࡮ࡧ࠳ࡓࡘࡄ࠺࠲ࡐ࠿ࠥࡽࡶࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠯࠵࠰࠳ࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠽࠮࠱࠰࠶࠷࠾࠼࠮࠹࠹ࠣࡑࡴࡨࡩ࡭ࡧࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ啲")
		if l1l11l_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ啳") in url: url = url+l1l11l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ啴")
		elif l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ啵") in url.lower() and l1l11l_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ啶") not in url and l1l11l_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ啷") not in url:
			if l1l11l_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ啸") not in url and l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ啹") in url.lower():
				if l1l11l_l1_ (u"ࠧࡽࠩ啺") not in url: url = url+l1l11l_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ啻")
				else: url = url+l1l11l_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭啼")
			if l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ啽") not in url.lower() and website not in [l1l11l_l1_ (u"ࠫࡎࡖࡔࡗࠩ啾")]:
				if l1l11l_l1_ (u"ࠬࢂࠧ啿") not in url: url = url+l1l11l_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭喀")
				else: url = url+l1l11l_l1_ (u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ喁")
		#url = url.replace(l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ喂"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ喃"))
	LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ善"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ喅")+url+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ喆"))
	l11l11111l1l_l1_ = xbmcgui.ListItem()
	#l11l11111l1l_l1_ = xbmcgui.ListItem(l1l11l_l1_ (u"࠭ࡴࡦࡵࡷࠫ喇"))
	type_,l1l1111ll11l_l1_,l11l1ll11lll_l1_,l11l11ll1ll1_l1_,l11l1111llll_l1_,l11ll11l1ll1_l1_,l1l1111ll111_l1_,l11l1l1l1111_l1_,l11l1ll1111l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if website not in [l1l11l_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ喈"),l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠭喉")]:
		if kodi_version<19: l111lll11l1l_l1_ = l1l11l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࡡࡥࡦࡲࡲࠬ喊")
		else: l111lll11l1l_l1_ = l1l11l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠨ喋")
		#l11l11111l1l_l1_ = xbmcgui.ListItem(path=url)
		l11l11111l1l_l1_.setProperty(l111lll11l1l_l1_, l1l11l_l1_ (u"ࠫࠬ喌"))
		l11l11111l1l_l1_.setMimeType(l1l11l_l1_ (u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪ喍"))
		l11l11111l1l_l1_.setInfo(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ喎"),{l1l11l_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ喏"):l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ喐")})
		#img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡮ࡩ࡯࡯ࠩ喑"))
		#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ喒"),l1l11l_l1_ (u"ࠫࡊࡓࡁࡅ࠼࠽࠾࠿ࡀࠠࠨ喓")+image)
		#l11l11111l1l_l1_.setArt({l1l11l_l1_ (u"ࠬ࡯ࡣࡰࡰࠪ喔"):image,l1l11l_l1_ (u"࠭ࡴࡩࡷࡰࡦࠬ喕"):image,l1l11l_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ喖"):image})
		l11l11111l1l_l1_.setArt({l1l11l_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ喗"):l11l1111llll_l1_,l1l11l_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩ喘"):l11l1111llll_l1_,l1l11l_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪ喙"):l11l1111llll_l1_,l1l11l_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ喚"):l11l1111llll_l1_,l1l11l_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧ喛"):l11l1111llll_l1_,l1l11l_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩ喜"):l11l1111llll_l1_,l1l11l_l1_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ喝"):l11l1111llll_l1_,l1l11l_l1_ (u"ࠨ࡫ࡦࡳࡳ࠭喞"):l11l1111llll_l1_})
		#l11l11111l1l_l1_.setInfo(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ喟"),{l1l11l_l1_ (u"ࠪࡘ࡮ࡺ࡬ࡦࠩ喠"):name})
		#name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ喡"))
		#name = name.strip(l1l11l_l1_ (u"ࠬࠦࠧ喢"))
		# when set to l1l11l_l1_ (u"ࠨࡆࡢ࡮ࡶࡩࠧ喣") it l1l111l1l111_l1_ l11l11llllll_l1_ l111l11l1l1_l1_ and l11l11llll1l_l1_ l11llllll1l1_l1_ l111llllll11_l1_ l111llllllll_l1_
		if videofiletype in [l1l11l_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ喤"),l1l11l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ喥")]: l11l11111l1l_l1_.setContentLookup(True)
		else: l11l11111l1l_l1_.setContentLookup(False)
		#if videofiletype in [l1l11l_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ喦")]: l11l11111l1l_l1_.setContentLookup(False)
		if l1l11l_l1_ (u"ࠪࡶࡹࡳࡰࠨ喧") in url:
			import l1llll1lllll_l1_
			l1llll1lllll_l1_.l1ll1l1l1lll_l1_(l1l11l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ喨"),False)
		elif videofiletype==l1l11l_l1_ (u"ࠬ࠴࡭ࡱࡦࠪ喩") or l1l11l_l1_ (u"࠭࠯ࡥࡣࡶ࡬࠴࠭喪") in url:
			import l1llll1lllll_l1_
			l1llll1lllll_l1_.l1ll1l1l1lll_l1_(l1l11l_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ喫"),False)
			l11l11111l1l_l1_.setProperty(l111lll11l1l_l1_,l1l11l_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ喬"))
			l11l11111l1l_l1_.setProperty(l1l11l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦ࠰ࡰࡥࡳ࡯ࡦࡦࡵࡷࡣࡹࡿࡰࡦࠩ喭"),l1l11l_l1_ (u"ࠪࡱࡵࡪࠧ單"))
			#l11l11111l1l_l1_.setMimeType(l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡧࡥࡸ࡮ࠫࡹ࡯࡯ࠫ喯"))
			#l11l11111l1l_l1_.setContentLookup(False)
		if l11l1ll11111_l1_:
			l11l11111l1l_l1_.setSubtitles([l11l1ll11111_l1_])
			#xbmc.log(LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࡆࡪࡤࡦࡦࠣࡷࡺࡨࡴࡪࡶ࡯ࡩࠥࡺ࡯ࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡖࡹࡧࡺࡩࡵ࡮ࡨ࠾ࡠ࠭喰")+l11l1ll11111_l1_+l1l11l_l1_ (u"࠭࡝ࠨ喱"), level=xbmc.LOGNOTICE)
	if type_==l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭喲") and website==l1l11l_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ喳"):
		result = l1l11l_l1_ (u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ喴")
		website = l1l11l_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡆࡏࡣࡋࡏࡌࡆࡕࠪ喵")
	elif type_==l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ営") and l11l1l1l1111_l1_.startswith(l1l11l_l1_ (u"ࠬ࠼ࠧ喷")):
		result = l1l11l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ喸")
		website = website+l1l11l_l1_ (u"ࠧࡠࡆࡏࠫ喹")
	# l11ll1l1111l_l1_ l11ll111lll1_l1_
	#	l11l1l1l1l1l_l1_ = l11ll1llll11_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l1l1l1ll1l_l1_ with xbmc.sleep(step*1000)
	if result!=l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ喺"): l11lll11lll1_l1_()
	l11l1l1l1l1l_l1_ = l11ll1llll11_l1_()
	if type_==l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ喻") and not l11l1l1l1111_l1_.startswith(l1l11l_l1_ (u"ࠪ࠺ࠬ喼")):
		#title = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡪࡶ࡯ࡩࠬ喽"))
		#l11l11111l1l_l1_.setInfo(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ喾"),{l1l11l_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ喿"): 3600})
		#xbmcplugin.setContent(addon_handle,l1l11l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ嗀"))
		#l11l11111l1l_l1_.setInfo(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嗁"),{l1l11l_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ嗂"):l1l11l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ嗃")})
		#l11l11111l1l_l1_.setProperty(l1l11l_l1_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨ嗄"),l1l11l_l1_ (u"ࠬࡺࡲࡶࡧࠪ嗅"))
		#l11l11111l1l_l1_.setInfo(type=l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嗆"),l11l11111lll_l1_={l1l11l_l1_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ嗇"):l1l11l_l1_ (u"ࠨࡪࡨࡰࡱࡵࠠࡸࡱࡵࡰࡩ࠭嗈")})
		l11l11111l1l_l1_.setPath(url)
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ嗉"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ嗊")+url+l1l11l_l1_ (u"ࠫࠥࡣࠧ嗋"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11l11111l1l_l1_)
	elif type_==l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ嗌"):
		LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭嗍"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ嗎")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ嗏"))
		l11l1l1l1l1l_l1_.play(url,l11l11111l1l_l1_)
		#xbmc.Player().play(url,l11l11111l1l_l1_)
	if result!=l1l11l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ嗐"):
		timeout,result = 60,l1l11l_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ嗑")
		#l1llll1l1_l1_(l1l11l_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ嗒"))
		for ii in range(timeout*2):
			# l11ll1l1111l_l1_ l11ll111lll1_l1_
			#	if l1lllllll1ll_l1_ time.sleep() l1l1l11l1ll_l1_ of xbmc.sleep() l11llll1ll11_l1_ the l11111ll1ll_l1_ status
			#	l1l11l_l1_ (u"ࠧࡳࡹࡱ࡮ࡤࡽࡪࡸ࠮ࡴࡶࡤࡸࡺࡹࠢ嗓") will stop l1l1111lllll_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(500)
			result = l11l1l1l1l1l_l1_.status
			if result==l1l11l_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ嗔"):
				DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧศๆไ๎ิ๐่ࠡ์฼้้࠭嗕"),l1l11l_l1_ (u"ࠨࠩ嗖"),time=500)
				LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ嗗"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࡸ࡬ࡨࡪࡵࠠࡪࡵࠣࡴࡱࡧࡹࡪࡰࡪࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ嗘")+url+l1l11l_l1_ (u"ࠫࠥࡣࠧ嗙")+l1l1111lll11_l1_)
				break
			elif result==l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ嗚"):
				LOG_THIS(l1l11l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ嗛"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭嗜")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ嗝")+l1l1111lll11_l1_)
				DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠩส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠫ嗞"),l1l11l_l1_ (u"ࠪࠫ嗟"),time=500)
				break
			#if l1l11l_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ嗠") in url: break
			if ii%2==0: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠬาวา์ࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪ嗡"),l1l11l_l1_ (u"࠭ศศไํࠤࠬ嗢")+str(timeout-ii//2)+l1l11l_l1_ (u"ࠧࠡอส๊๏ฯࠧ嗣"))
		else:
			result = l1l11l_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ嗤")
			l11l1l1l1l1l_l1_.stop()
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠩส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠫ嗥"),l1l11l_l1_ (u"ࠪࠫ嗦"),time=500)
			LOG_THIS(l1l11l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ嗧"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡖ࡬ࡱࡪࡵࡵࡵࠢࡸࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ嗨")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ嗩")+l1l1111lll11_l1_)
		#l1llll1l1_l1_(l1l11l_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭嗪"))
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢ࡫ࡸࡹࡶࡤ࠻ࠏࠍࠍࠎࠩࠠࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡧࡱ࡯ࡣ࡬ࠢࡲ࡯ࠥࡺ࡯ࠡࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠣࡸ࡭࡫ࠠࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠬ࠯ࠍࠋࠋࠌࠧ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ࠲ࠧࠨ࠮ࠪࠫ࠱ࡌࡡ࡭ࡵࡨ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠸ࡸ࡭࠭ࠩࠎࠌࠌࠍࡹ࡯࡭ࡦ࠰ࡶࡰࡪ࡫ࡰࠩ࠳ࠬࠑࠏࠏࠉࡩࡶࡷࡴࡩ࠴ࡳࡩࡷࡷࡨࡴࡽ࡮ࠩࠫࠐࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠩ࠯ࠫࠬ࠯ࠍࠋࠋࠥࠦࠧ嗫")
	if result==l1l11l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ嗬") and not l1ll111l1lll_l1_(l1l11l_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ嗭")):
		import l1l1l11l11_l1_
		succeeded = l1l1l11l11_l1_.l1l1l1l1l1_l1_(url,videofiletype,website)
		if succeeded: l11lll11lll1_l1_()
	else: succeeded = False
	if result in [l1l11l_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ嗮"),l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ嗯")] or succeeded:
		#addon_version = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠨࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭ࠨ嗰")+addon_id+l1l11l_l1_ (u"ࠢࠪࠤ嗱") )
		response = SEND_ANALYTICS_EVENT(website)
		#html = response.content
	#if result in [l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ嗲"),l1l11l_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ嗳"),l1l11l_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ嗴"),l1l11l_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ嗵"),l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭嗶")]: l1l111l111l1_l1_(l1l11l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ嗷"),False)
	#l1l111l111l1_l1_(l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠲࠹ࡲࡥࠩ嗸"))
	#if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ嗹") in url and result in [l1l11l_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ嗺"),l1l11l_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ嗻")]:
	#	l1l1111lllll_l1_ = HTTPS(False)
	#	if not l1l1111lllll_l1_:
	#		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ嗼"),l1l11l_l1_ (u"ࠬ࠭嗽"),l1l11l_l1_ (u"࠭วๅษอูฬ๊ࠠๆึไีࠬ嗾"),l1l11l_l1_ (u"ࠧๆึๆ่ฮࠦ࠮࠯࠰๋ࠣีอࠠศๆไ๎ิ๐่ࠡ์ะฮฬาࠠศๆ์ࠤฬะีศๆู้ࠣ็ัࠡࠪิฬ฼ࠦๅีใิ࠭ࠥ๎ไไ่่้ࠣษำโࠢส่ฬะีศๆࠣห้๋ิโำ่ࠣฬฺ๊ࠦ็็ࠤ฾๊้ࠡฮ๊หื้ࠧ嗿"))
	#		return l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ嘀")
	#sys.exit()
	return result
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l1lllll111_l1_ = args[0]
		l1l1ll1l_l1_ = args[1]
		if not l1l1lllll111_l1_: l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ嘁")
		if not l1l1ll1l_l1_: l1l1ll1l_l1_ = l1l11l_l1_ (u"ࠪหุะๅาษิࠫ嘂")
		header = args[2]
		text = l1l11l_l1_ (u"ࠫࡡࡴࠧ嘃").join(args[3:])
	else: l1l1lllll111_l1_,l1l1ll1l_l1_,header,text = l1l11l_l1_ (u"ࠬ࠭嘄"),l1l11l_l1_ (u"࠭ࡏࡌࠩ嘅"),l1l11l_l1_ (u"ࠧࠨ嘆"),l1l11l_l1_ (u"ࠨࠩ嘇")
	l1l1llllllll_l1_(l1l1lllll111_l1_,l1l11l_l1_ (u"ࠩࠪ嘈"),l1l1ll1l_l1_,l1l11l_l1_ (u"ࠪࠫ嘉"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l1lllll111_l1_ = args[0]
	l11l1lllll11_l1_ = args[1]
	l11l1ll1ll1l_l1_ = args[2]
	if l11l1ll1ll1l_l1_ or l11l1lllll11_l1_: l11l1llll111_l1_ = True
	else: l11l1llll111_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l1lllll111_l1_: l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ嘊")
	if not l11l1lllll11_l1_: l11l1lllll11_l1_ = l1l11l_l1_ (u"้ࠬไศࠩ嘋")
	if not l11l1ll1ll1l_l1_: l11l1ll1ll1l_l1_ = l1l11l_l1_ (u"࠭ๆฺ็ࠪ嘌")
	if len(args)>=6: text += l1l11l_l1_ (u"ࠧ࡝ࡰࠪ嘍")+args[5]
	if len(args)>=7: text += l1l11l_l1_ (u"ࠨ࡞ࡱࠫ嘎")+args[6]
	choice = l1l1llllllll_l1_(l1l1lllll111_l1_,l11l1lllll11_l1_,l1l11l_l1_ (u"ࠩࠪ嘏"),l11l1ll1ll1l_l1_,header,text)
	if choice==-1 and l11l1llll111_l1_: choice = -1
	elif choice==-1 and not l11l1llll111_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l11ll1ll1111_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l11l_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ嘐") in list(kwargs.keys()): l11lll1l11l1_l1_ = kwargs[l1l11l_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ嘑")]
	else: l11lll1l11l1_l1_ = 1000
	if len(args)>2 and l1l11l_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ嘒") not in args[2]: profile = args[2]
	else: profile = l1l11l_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬ嘓")
	l1ll11lllll1_l1_ = xbmcgui.WindowXMLDialog(l1l11l_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧ嘔"),addonfolder,l1l11l_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ嘕"),l1l11l_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ嘖"))
	image_filename,image_height = CREATE_IMAGE(l1l11l_l1_ (u"ࠪࠫ嘗"),l1l11l_l1_ (u"ࠫࠬ嘘"),l1l11l_l1_ (u"ࠬ࠭嘙"),header,text,profile,l1l11l_l1_ (u"࠭࡬ࡦࡨࡷࠫ嘚"),720,False)
	#time.sleep(0.200)
	l1ll11lllll1_l1_.show()
	if profile==l1l11l_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ嘛"):
		l1ll11lllll1_l1_.getControl(9040).setHeight(215)
		l1ll11lllll1_l1_.getControl(9040).setPosition(55,-80)
		l1ll11lllll1_l1_.getControl(9050).setPosition(120,-60)
		l1ll11lllll1_l1_.getControl(400).setPosition(90,-35)
	l1ll11lllll1_l1_.getControl(401).setVisible(False)
	l1ll11lllll1_l1_.getControl(402).setVisible(False)
	l1ll11lllll1_l1_.getControl(9050).setImage(image_filename)
	l1ll11lllll1_l1_.getControl(9050).setHeight(image_height)
	import threading
	l1l11l11l111_l1_ = threading.Thread(target=l111lll111l1_l1_,args=(l1ll11lllll1_l1_,image_filename,l11lll1l11l1_l1_))
	l1l11l11l111_l1_.start()
	#l1l11l11l111_l1_.join()
	return
	#return xbmcgui.Dialog().l11l111l1111_l1_(l11ll1l11ll1_l1_=False,*args,**kwargs)
def l111lll111l1_l1_(l1ll11lllll1_l1_,image_filename,l11lll1l11l1_l1_):
	time.sleep(l11lll1l11l1_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(image_filename):
		try: os.remove(image_filename)
		except: pass
	#del l1ll11lllll1_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠨࠩ嘜"),l1l11l_l1_ (u"ࠩࠪ嘝"),l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ嘞"),l1l11l_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ嘟")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1l1lllll111_l1_ = args[3]
	return l1ll111l11_l1_(l1l1lllll111_l1_,header,text,profile)
	#return xbmcgui.Dialog().l11ll1111l11_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l11l11ll1111_l1_(*args,**kwargs)
def l1l1ll1111_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l11l1l111lll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#button0,button1,button2,header,text,profile,l1l1lllll111_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1ll11lllll1_l1_ = l11l11l11lll_l1_(l1l11l_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ嘠"),addonfolder,l1l11l_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ嘡"),l1l11l_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ嘢"))
	#l1ll11lllll1_l1_.l1l11111l111_l1_(button0,button1,button2,header,text,profile,l1l1lllll111_l1_,855)
	#return l1ll11lllll1_l1_
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢࡷ࡭ࡲ࡫࡯ࡶࡶࡁ࠴࠿ࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡳࡵࡣࡵࡸࡇࡻࡴࡵࡱࡱࡷ࡙࡯࡭ࡦࡱࡸࡸ࠭ࡺࡩ࡮ࡧࡲࡹࡹ࠯ࠍࠋࠋࡨࡰࡸ࡫࠺ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡧࡱࡥࡧࡲࡥࡃࡷࡷࡸࡴࡴࡳࠩࠫࠐࠎࠎࠩࡤࡪࡣ࡯ࡳ࡬࠴ࡵࡱࡦࡤࡸࡪࡖࡲࡰࡩࡵࡩࡸࡹࡂࡢࡴࠫ࠻࠵࠯ࠉࠤࠢ࠺࠴ࠪࠓࠊࠊࡦ࡬ࡥࡱࡵࡧ࠯ࡦࡲࡑࡴࡪࡡ࡭ࠪࠬࠑࠏࠏࡣࡩࡱ࡬ࡧࡪࠦ࠽ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡥ࡫ࡳ࡮ࡩࡥࡊࡆࠐࠎࠎࡺࡲࡺ࠼ࠣࡳࡸ࠴ࡲࡦ࡯ࡲࡺࡪ࠮ࡤࡪࡣ࡯ࡳ࡬࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠩࠎࠌࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠏࠍࠍࠨࡪࡥ࡭ࠢࡧ࡭ࡦࡲ࡯ࡨࠏࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡨ࡮࡯ࡪࡥࡨࠑࠏࠏࠢࠣࠤ嘣")
def l1llll1l1_l1_(l11l1ll1l1ll_l1_):
	if kodi_version>17.99: l1ll11lllll1_l1_ = l1l11l_l1_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧ嘤")
	else: l1ll11lllll1_l1_ = l1l11l_l1_ (u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧ嘥")
	l11l1ll1l1ll_l1_ = l11l1ll1l1ll_l1_.lower()
	if l11l1ll1l1ll_l1_==l1l11l_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ嘦"): xbmc.executebuiltin(l1l11l_l1_ (u"ࠬࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࠧ嘧")+l1ll11lllll1_l1_+l1l11l_l1_ (u"࠭ࠩࠨ嘨"))
	elif l11l1ll1l1ll_l1_==l1l11l_l1_ (u"ࠧࡴࡶࡲࡴࠬ嘩"): xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࠨ嘪")+l1ll11lllll1_l1_+l1l11l_l1_ (u"ࠩࠬࠫ嘫"))
	return
def l1l1llllllll_l1_(l1l1lllll111_l1_,button0=l1l11l_l1_ (u"ࠪࠫ嘬"),button1=l1l11l_l1_ (u"ࠫࠬ嘭"),button2=l1l11l_l1_ (u"ࠬ࠭嘮"),header=l1l11l_l1_ (u"࠭ࠧ嘯"),text=l1l11l_l1_ (u"ࠧࠨ嘰"),l11l1lll1ll1_l1_=0,l11l11lllll1_l1_=0,profile=l1l11l_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ嘱")):
	if not l1l1lllll111_l1_: l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ嘲")
	l1ll11lllll1_l1_ = l11l11l11lll_l1_(l1l11l_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ嘳"),addonfolder,l1l11l_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ嘴"),l1l11l_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ嘵"))
	l1ll11lllll1_l1_.l1l11111l111_l1_(button0,button1,button2,header,text,profile,l1l1lllll111_l1_,900,l11l1lll1ll1_l1_,l11l11lllll1_l1_)
	if l11l1lll1ll1_l1_>0: l1ll11lllll1_l1_.l1l11l11111l_l1_()
	if l11l11lllll1_l1_>0: l1ll11lllll1_l1_.l1l111ll1l11_l1_()
	if l11l1lll1ll1_l1_==0 and l11l11lllll1_l1_==0: l1ll11lllll1_l1_.enableButtons()
	l1ll11lllll1_l1_.doModal()
	choice = l1ll11lllll1_l1_.l1l11l111l1l_l1_
	return choice
def l1ll111l11_l1_(l1l1lllll111_l1_,header,text,profile=l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ嘶")):
	if not l1l1lllll111_l1_: l1l1lllll111_l1_ = l1l11l_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ嘷")
	#text = l1l11l_l1_ (u"ࠨ࡞ࡱࠫ嘸").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l1l11l_l1_ (u"ࠩࠪ嘹")
	l1ll11lllll1_l1_ = xbmcgui.WindowXMLDialog(l1l11l_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭嘺"),addonfolder,l1l11l_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ嘻"),l1l11l_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ嘼"))
	image_filename,image_height = CREATE_IMAGE(l1l11l_l1_ (u"࠭ࠧ嘽"),l1l11l_l1_ (u"ࠧࠨ嘾"),l1l11l_l1_ (u"ࠨࠩ嘿"),header,text,profile,l1l1lllll111_l1_,1270,False)
	l1ll11lllll1_l1_.show()
	#time.sleep(1)
	#l1ll11lllll1_l1_.getControl(9050).l1ll1ll11111_l1_(1270-60)
	l1ll11lllll1_l1_.getControl(9050).setHeight(image_height)
	l1ll11lllll1_l1_.getControl(9050).setImage(image_filename)
	result = l1ll11lllll1_l1_.doModal()
	#del l1ll11lllll1_l1_
	try: os.remove(image_filename)
	except: pass
	return result
def l1ll1111l_l1_(l11l11ll1l11_l1_=True):
	if l11l11ll1l11_l1_:
		useragent = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡶࡸࡷ࠭噀"),l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭噁"),l1l11l_l1_ (u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧ噂"))
		if useragent: return useragent
	#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ噃"),l1l11l_l1_ (u"࠭ࡅࡎࡃࡇࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࡵࡴࡧࡵࡥ࡬࡫࡮ࡵ࠼ࠣࠫ噄")+results)
	# l1l11l111l11_l1_ and l11ll1l111_l1_ common user l11l1l1ll1l1_l1_ (l11llll11l1l_l1_ l1l11l1111l1_l1_)
	text = l1l11l_l1_ (u"ࠧࠨ噅")
	url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡩࡨ࡮ࡢ࡭ࡱࡪ࠲ࡼ࡯࡬࡭ࡵ࡫ࡳࡺࡹࡥ࠯ࡥࡲࡱ࠴࠸࠰࠲࠴࠲࠴࠶࠵࠰࠴࠱ࡰࡳࡸࡺ࠭ࡤࡱࡰࡱࡴࡴ࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࡷ࠴࠭噆")
	headers = {l1l11l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ噇"):url}
	response = OPENURL_REQUESTS_CACHED(l1llll11l11_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ噈"),url,l1l11l_l1_ (u"ࠫࠬ噉"),headers,l1l11l_l1_ (u"ࠬ࠭噊"),False,l1l11l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧ噋"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l11l_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨ噌"))
		if count>80:
			text = re.findall(l1l11l_l1_ (u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ噍"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ噎"),l1l11l_l1_ (u"ࠪࠫ噏"),l1l11l_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠧ噐"),l1l11l_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࡙ࠣࡘࡋࡒ࠮ࡃࡊࡉࡓ࡚ࡓࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠬ噑"))
	if not text:
		text = open(l11ll111l1l1_l1_,l1l11l_l1_ (u"࠭ࡲࡣࠩ噒")).read()
		if kodi_version>18.99: text = text.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ噓"))
		text = text.replace(l1l11l_l1_ (u"ࠨ࡞ࡵࠫ噔"),l1l11l_l1_ (u"ࠩࠪ噕"))
	l11ll11ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫ噖"),text,re.DOTALL)
	l1l111l1llll_l1_ = []
	for line in l11ll11ll111_l1_:
		l11l1ll1l111_l1_ = line.lower()
		if l1l11l_l1_ (u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬ噗") in l11l1ll1l111_l1_: continue
		if l1l11l_l1_ (u"ࠬࡻࡢࡶࡰࡷࡹࠬ噘") in l11l1ll1l111_l1_: continue
		#if l1l11l_l1_ (u"࠭ࡨࡵ࡯࡯ࠫ噙") in l11l1ll1l111_l1_: continue
		l1l111l1llll_l1_.append(line)
	useragent = random.sample(l1l111l1llll_l1_,1)
	useragent = useragent[0]
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ噚"),l1l11l_l1_ (u"ࠨࠩ噛"),str(len(l11ll11ll111_l1_)),useragent)
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ噜"),l1l11l_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭噝"),useragent,l1111lll_l1_)
	return useragent
def l1l11l1111ll_l1_(errortrace):
	#if l1l11l_l1_ (u"ࠫ࡫ࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠩ噞") in str(error).lower(): return
	#errortrace = traceback.format_exc()
	sys.stderr.write(errortrace)
	lines = errortrace.splitlines()
	error = lines[-1]
	l11lll1lll1l_l1_ = open(l1lll11111ll_l1_,l1l11l_l1_ (u"ࠬࡸࡢࠨ噟")).read()
	if kodi_version>18.99: l11lll1lll1l_l1_ = l11lll1lll1l_l1_.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ噠"))
	l11lll1lll1l_l1_ = l11lll1lll1l_l1_[-8000:]
	sep = l1l11l_l1_ (u"ࠧ࠾ࠩ噡")*100
	if sep in l11lll1lll1l_l1_: l11lll1lll1l_l1_ = l11lll1lll1l_l1_.rsplit(sep,1)[1]
	if error in l11lll1lll1l_l1_: l11lll1lll1l_l1_ = l11lll1lll1l_l1_.rsplit(error,1)[0]
	#l1ll111l11_l1_(l1l11l_l1_ (u"ࠨࠩ噢"),error,l11lll1lll1l_l1_)
	#loglines = l11lll1lll1l_l1_.splitlines()
	#for line in reversed(loglines):
	#	if l1l11l_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠬ噣") in line: continue
	#	if l1l11l_l1_ (u"ࠪࡑࡴࡪࡥ࠻ࠢ࡞ࠫ噤") not in line: continue
	l11l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪ噥"),l11lll1lll1l_l1_,re.DOTALL)
	for typ,source in reversed(l11l11l1l1l1_l1_):
		#if l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࠧ噦") in source: continue
		#if l1l11l_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࠩ噧") in source: continue
		if source: break
	else: source = l1l11l_l1_ (u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧ器")
	#l1ll111l11_l1_(l1l11l_l1_ (u"ࠨࠩ噩"),source,str(l11l11l1l1l1_l1_))
	file,line,func = l1l11l_l1_ (u"ࠩࠪ噪"),l1l11l_l1_ (u"ࠪࠫ噫"),l1l11l_l1_ (u"ࠫࠬ噬")
	l11lllll111_l1_ = l1l11l_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ噭")+error
	source2 = l1l11l_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ุำึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ噮")+source
	for l11l1llll11l_l1_ in reversed(lines):
		if l1l11l_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠧ噯") in l11l1llll11l_l1_ and l1l11l_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ噰") in l11l1llll11l_l1_: break
	l11l1llll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬ噱"),l11l1llll11l_l1_,re.DOTALL)
	if l11l1llll11l_l1_:
		file,line,func = l11l1llll11l_l1_[0]
		if l1l11l_l1_ (u"ࠪ࠳ࠬ噲") in file: file = file.rsplit(l1l11l_l1_ (u"ࠫ࠴࠭噳"),1)[1]
		else: file = file.rsplit(l1l11l_l1_ (u"ࠬࡢ࡜ࠨ噴"),1)[1]
		l11l1111l111_l1_ = l1l11l_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็็ๅ࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ噵")+file
		line2 = l1l11l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึ฻ึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ噶")+line
		l1l11111l1ll_l1_ = l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็้่อๆ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ噷")+func
		l11lll1lllll_l1_ = l11l1111l111_l1_+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ噸")+line2+l1l11l_l1_ (u"ࠪࡠࡳ࠭噹")+l1l11111l1ll_l1_+l1l11l_l1_ (u"ࠫࡡࡴࠧ噺")+source2+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ噻")+l11lllll111_l1_
		l11l1l1lll11_l1_ = line2+l1l11l_l1_ (u"࠭࡜࡯ࠩ噼")+source2+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ噽")+l11lllll111_l1_+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ噾")+l11l1111l111_l1_+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ噿")+l1l11111l1ll_l1_
		l1l111ll111l_l1_ = line2+l1l11l_l1_ (u"ࠪࡠࡳ࠭嚀")+l11lllll111_l1_+l1l11l_l1_ (u"ࠫࡡࡴࠧ嚁")+l11l1111l111_l1_+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ嚂")+l1l11111l1ll_l1_
	else:
		l11l1111l111_l1_,line2,l1l11111l1ll_l1_ = l1l11l_l1_ (u"࠭ࠧ嚃"),l1l11l_l1_ (u"ࠧࠨ嚄"),l1l11l_l1_ (u"ࠨࠩ嚅")
		l11lll1lllll_l1_ = source2+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ嚆")+l11lllll111_l1_
		l11l1l1lll11_l1_ = source2+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ嚇")+l11lllll111_l1_
		l1l111ll111l_l1_ = l11lllll111_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l1l11l_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ嚈"),time=2000)
	l1l11111l11l_l1_ = l1l11l_l1_ (u"ࠬำฯฬࠢั฻ศฺ๋ࠦำ้ࠣ็฻่ะࠩ嚉")+l1l11l_l1_ (u"࠭࡜࡯ࠩ嚊")
	l11ll1111l_l1_ = l1ll11lllll_l1_()
	l11ll1111l1l_l1_ = []
	results = l11ll1111l_l1_[l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ嚋")]
	l11l1lll1lll_l1_ = l111lll1l1l1_l1_(addon_version)
	if l1l11l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭嚌") in list(l11ll1111l_l1_.keys()):
		for l11l11ll111l_l1_,l11lll111l1l_l1_,l1l111l1l1ll_l1_ in results: l11ll1111l1l_l1_ = max(l11ll1111l1l_l1_,l11lll111l1l_l1_)
		if l11l1lll1lll_l1_<l11ll1111l1l_l1_:
			header = l1l11l_l1_ (u"ࠩๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨ嚍")
			choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ嚎"),l1l11l_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ嚏"),l1l11l_l1_ (u"ࠬะอะ์ฮࠫ嚐"),l1l11l_l1_ (u"࠭ฮา๊ฯࠫ嚑"),l1l11111l11l_l1_+header,l11lll1lllll_l1_)
			if choice==0:
				yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ嚒"),l1l11l_l1_ (u"ࠨะิ์ั࠭嚓"),l1l11l_l1_ (u"ࠩอัิ๐หࠨ嚔"),l1l11l_l1_ (u"ࠪࠫ嚕"),header)
				if yes==1: choice = 1
			if choice==1:
				import l1llll1lllll_l1_
				l1llll1lllll_l1_.l1ll1l11llll_l1_()
			return
	l111ll1lllll_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ嚖"),l1l11l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ嚗"),l1l11l_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ嚘"))
	if not l111ll1lllll_l1_: l111ll1lllll_l1_ = []
	l11l1l1lll11_l1_ = l11l1l1lll11_l1_.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ嚙"),l1l11l_l1_ (u"ࠨ࡞࡟ࡲࠬ嚚")).replace(l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ嚛"),l1l11l_l1_ (u"ࠪࠫ嚜")).replace(l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ嚝"),l1l11l_l1_ (u"ࠬ࠭嚞")).replace(l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ嚟"),l1l11l_l1_ (u"ࠧࠨ嚠"))
	l1l111ll111l_l1_ = l1l111ll111l_l1_.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫ嚡"),l1l11l_l1_ (u"ࠩ࡟ࡠࡳ࠭嚢")).replace(l1l11l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ嚣"),l1l11l_l1_ (u"ࠫࠬ嚤")).replace(l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ嚥"),l1l11l_l1_ (u"࠭ࠧ嚦")).replace(l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嚧"),l1l11l_l1_ (u"ࠨࠩ嚨"))
	l111llll111l_l1_ = addon_version+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ嚩")+l1l111ll111l_l1_
	if l111llll111l_l1_ in l111ll1lllll_l1_:
		header = l1l11l_l1_ (u"่ࠪ็ีࠠใ็อࠤฬ์สࠡีสฬ็อࠠษวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ嚪")
		#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ嚫"),l1l11l_l1_ (u"ࠬิั้ฮࠪ嚬"),l1l11l_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ嚭"),l1l11111l11l_l1_+header,l11lll1lllll_l1_)
		#if yes==1: DIALOG_OK(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ嚮"),l1l11l_l1_ (u"ࠨะิ์ั࠭嚯"),l1l11l_l1_ (u"ࠩࠪ嚰"),header)
		DIALOG_OK(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ嚱"),l1l11l_l1_ (u"ࠫࠬ嚲"),l1l11111l11l_l1_+header,l11lll1lllll_l1_)
		return
	l111lllll11l_l1_ = str(kodi_version).split(l1l11l_l1_ (u"ࠬ࠴ࠧ嚳"))[0]
	#l1l111ll11ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫ嚴"),l1l11l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ嚵"),l1l11l_l1_ (u"ࠨࡃࡏࡐࡤࡑࡎࡐ࡙ࡑࡣࡊࡘࡒࡐࡔࡖࠫ嚶"))
	url = WEBSITES[l1l11l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ嚷")][6]
	response = OPENURL_REQUESTS_CACHED(l1111lll_l1_,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ嚸"),url,l1l11l_l1_ (u"ࠫࠬ嚹"),l1l11l_l1_ (u"ࠬ࠭嚺"),l1l11l_l1_ (u"࠭ࠧ嚻"),l1l11l_l1_ (u"ࠧࠨ嚼"),l1l11l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫ嚽"),False,False)
	html = response.content
	l1l111ll11ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ嚾"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭嚿"),l1l11l_l1_ (u"ࠫࡆࡒࡌࡠࡍࡑࡓ࡜ࡔ࡟ࡆࡔࡕࡓࡗ࡙ࠧ囀"),l1l111ll11ll_l1_,REGULAR_CACHE)
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭囁"),line+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ囂")+error+l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ囃")+addon_version+l1l11l_l1_ (u"ࠨࠢࠣࠤࠬ囄")+l111lllll11l_l1_)
	for l1l111111ll1_l1_,l1l111l1l1l1_l1_,l11ll1l1l11l_l1_,l11l1l1ll1ll_l1_ in l1l111ll11ll_l1_:
		l1l111111ll1_l1_ = l1l111111ll1_l1_.split(l1l11l_l1_ (u"ࠩ࠮ࠫ囅"))
		l11ll1l1l11l_l1_ = l11ll1l1l11l_l1_.split(l1l11l_l1_ (u"ࠪ࠯ࠬ囆"))
		l11l1l1ll1ll_l1_ = l11l1l1ll1ll_l1_.split(l1l11l_l1_ (u"ࠫ࠰࠭囇"))
		#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭囈"),str(l1l111111ll1_l1_)+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ囉")+l1l111l1l1l1_l1_+l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ囊")+str(l11ll1l1l11l_l1_)+l1l11l_l1_ (u"ࠨࠢࠣࠤࠬ囋")+str(l11l1l1ll1ll_l1_))
		if line in l1l111111ll1_l1_ and error==l1l111l1l1l1_l1_ and addon_version in l11ll1l1l11l_l1_ and l111lllll11l_l1_ in l11l1l1ll1ll_l1_:
			header = l1l11l_l1_ (u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧ囌")
			yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ囍"),l1l11l_l1_ (u"ࠫำื่อࠩ囎"),l1l11l_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ囏"),l1l11111l11l_l1_+header,l11lll1lllll_l1_)
			if yes==1: DIALOG_OK(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭囐"),l1l11l_l1_ (u"ࠧࠨ囑"),l1l11l_l1_ (u"ࠨࠩ囒"),header)
			return
	header = l1l11l_l1_ (u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ囓")
	DIALOG_OK(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ囔"),l1l11l_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ囕"),l1l11111l11l_l1_+header,l11lll1lllll_l1_)
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ囖"),l1l11l_l1_ (u"࠭ใๅษࠪ囗"),l1l11l_l1_ (u"ࠧ็฻่ࠫ囘"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ囙"),l1l11l_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪ囚"))
	if yes==1: l1llll11lll1_l1_ = l1l11l_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭四")
	else:
		DIALOG_OK(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ囜"),l1l11l_l1_ (u"ࠬ࠭囝"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ回"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬ囟"))
		return
	message = l11l1l1lll11_l1_
	l111l11l1ll_l1_ = l1l11l_l1_ (u"ࠨࡃ࡙࠾ࠥ࠭因")+l1ll1l1l11l_l1_(32)+l1l11l_l1_ (u"ࠩ࠰ࡉࡷࡸ࡯ࡳࡵࠪ囡")
	import l1llll1lllll_l1_
	succeeded = l1llll1lllll_l1_.l11ll1llll1_l1_(l111l11l1ll_l1_,message,True,l1l11l_l1_ (u"ࠪࠫ团"),l1l11l_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭団"),l1llll11lll1_l1_)
	if succeeded and l1llll11lll1_l1_:
		l111ll1lllll_l1_.append(l111llll111l_l1_)
		WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ囤"),l1l11l_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ囥"),l111ll1lllll_l1_,PERMANENT_CACHE)
	return
def l1ll111l1lll_l1_(l11ll11l1111_l1_):
	l1ll111l11l_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ囦"))
	#l11ll11l1111_l1_ = l11ll11l1111_l1_.encode(l1l11l_l1_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ囧")).replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ囨"),l1l11l_l1_ (u"ࠪࠫ囩"))
	user = l1ll1l1l11l_l1_(32)
	import hashlib
	md5 = hashlib.md5((l1l11l_l1_ (u"ࠫ࡝࠷࠹ࠨ囪")+l11ll11l1111_l1_+l1l11l_l1_ (u"ࠬ࠷࠸࠾ࠩ囫")+user).encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ囬"))).hexdigest()[0:32]
	if md5 in l1ll111l11l_l1_: return True
	return False
def WRITE_THIS(l1l1l1111l_l1_,data):
	if kodi_version>18.99: data = data.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ园"))
	if l1l1l1111l_l1_==l1l11l_l1_ (u"ࠨࠩ囮"): filename = l1l11l_l1_ (u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡦࡤࡸࠬ囯")
	else: filename = l1l11l_l1_ (u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪ困")+str(now)+l1l11l_l1_ (u"ࠫ࠳ࡪࡡࡵࠩ囱")
	open(filename,l1l11l_l1_ (u"ࠬࡽࡢࠨ囲")).write(data)
	return
def l1lll111111l_l1_():
	l11llllll1ll_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ図"))
	if l11llllll1ll_l1_:
		l1ll1lll11ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ围"),l1l11l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ囵"),l1l11l_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ囶"))
		if l1ll1lll11ll_l1_: return l1ll1lll11ll_l1_
	l1ll11l1ll1_l1_ = l1ll1l1l11l_l1_(32)
	payload = {l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ囷"):l1ll11l1ll1_l1_}
	url = WEBSITES[l1l11l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ囸")][5]
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ囹"),url,payload,l1l11l_l1_ (u"࠭ࠧ固"),l1l11l_l1_ (u"ࠧࠨ囻"),l1l11l_l1_ (u"ࠨࠩ囼"),l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ国"))
	if not response.succeeded: return []
	l1l11l11ll11_l1_ = response.content
	l1l11l11ll11_l1_ = l1l11l11ll11_l1_.replace(l1l11l_l1_ (u"ࠪࡠࡡࡸࠧ图"),l1l11l_l1_ (u"ࠫࡡࡴࠧ囿")).replace(l1l11l_l1_ (u"ࠬࡢ࡜࡯ࠩ圀"),l1l11l_l1_ (u"࠭࡜࡯ࠩ圁")).replace(l1l11l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ圂"),l1l11l_l1_ (u"ࠨ࡞ࡱࠫ圃")).replace(l1l11l_l1_ (u"ࠩ࡟ࡶࠬ圄"),l1l11l_l1_ (u"ࠪࡠࡳ࠭圅")).replace(l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ圆"),l1l11l_l1_ (u"ࠬࡢ࡮ࠨ圇"))
	l1l11l11ll11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ圈"),l1l11l11ll11_l1_,re.DOTALL)
	if not l1l11l11ll11_l1_: return []
	l1l11l11ll11_l1_ = sorted(l1l11l11ll11_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1ll1l11l1l1_l1_,l1ll11ll1l1l_l1_,answer,l1l1ll1ll11l_l1_,reason = l1l11l11ll11_l1_[0]
	if l1l11l_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ圉") not in reason: l11l1l11ll1l_l1_,l11l1l11lll1_l1_,l11l1l11llll_l1_ = reason,reason,reason
	else: l11l1l11ll1l_l1_,l11l1l11lll1_l1_,l11l1l11llll_l1_ = reason.split(l1l11l_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭圊"),2)
	settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ國"),l1ll11ll1l1l_l1_)
	#settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨ࠳ࡲ࡯࡯ࡩࠪ圌"),l11l1l11ll1l_l1_)
	settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠴࡬ࡰࡰࡪࠫ圍"),l1l11l_l1_ (u"ࠬ࠭圎"))
	settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ圏"),l1l11l_l1_ (u"ࠧࠨ圐"))
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ圑"),l1l11l_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ園"),l1l11l11ll11_l1_,REGULAR_CACHE)
	return l1l11l11ll11_l1_
def SPLIT_BIGLIST(l1l111l11l11_l1_,splits_count):
	length = len(l1l111l11l11_l1_)
	l1l111ll1lll_l1_ = []
	for ii in range(1,splits_count+1):
		if ii!=splits_count:
			l1l11111111l_l1_ = l1l111l11l11_l1_[0:int(length/splits_count)]
			del l1l111l11l11_l1_[0:int(length/splits_count)]
		else:
			l1l11111111l_l1_ = l1l111l11l11_l1_
			del l1l111l11l11_l1_
		l1l111ll1lll_l1_.append(l1l11111111l_l1_)
		del l1l11111111l_l1_
	return l1l111ll1lll_l1_
def l11llll1lll1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l1l11l_l1_ (u"ࠪࡨࡺࡳ࡭ࡺࡰࡤࡱࡪ࠭圓"),data)
	#text = pickle.dumps(dummy)
	if 1 or l1l11l_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ圔") not in filename: text = str(data)
	else:
		l1111l111l1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l11l_l1_ (u"ࠬ࠭圕")
		for split in l1111l111l1_l1_:
			text += str(split)+l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ圖")
		text = text.strip(l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭圗"))
	compressed = zlib.compress(text)
	open(filepath,l1l11l_l1_ (u"ࠨࡹࡥࠫ團")).write(compressed)
	return
def l1l111l1ll11_l1_(results_type,filename):
	if results_type==l1l11l_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ圙"): data = {}
	elif results_type==l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ圚"): data = []
	elif results_type==l1l11l_l1_ (u"ࠫࡸࡺࡲࠨ圛"): data = l1l11l_l1_ (u"ࠬ࠭圜")
	elif results_type==l1l11l_l1_ (u"࠭ࡩ࡯ࡶࠪ圝"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	compressed = open(filepath,l1l11l_l1_ (u"ࠧࡳࡤࠪ圞")).read()
	text = zlib.decompress(compressed)
	#open(l1l11l_l1_ (u"ࠨࡵ࠽ࡠࡡࡏࡐࡕࡘ࠴࠲ࡹࡾࡴࠨ土"),l1l11l_l1_ (u"ࠩࡺࡦࠬ圠")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l1l11l_l1_ (u"ࠪࡨࡺࡳ࡭ࡺࡰࡤࡱࡪ࠭圡"))
	#if l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ圢") not in text: data = EVAL(l1l11l_l1_ (u"ࠬࡹࡴࡳࠩ圣"),text)
	if l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ圤") not in text: data = eval(text)
	else:
		l1111l111l1_l1_ = text.split(l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭圥"))
		del text
		data = []
		l1l1111l11ll_l1_ = l11ll11llll_l1_()
		id = 0
		for split in l1111l111l1_l1_:
			#data += EVAL(l1l11l_l1_ (u"ࠨࡵࡷࡶࠬ圦"),split)
			l1l1111l11ll_l1_.l11llllllll1_l1_(str(id),eval,split)
			id += 1
		del l1111l111l1_l1_
		l1l1111l11ll_l1_.l11l1l111l1l_l1_()
		l1l1111l11ll_l1_.l111llll1111_l1_()
		l11l11111111_l1_ = list(l1l1111l11ll_l1_.l11ll1lll11l_l1_.keys())
		l11l111l11ll_l1_ = sorted(l11l11111111_l1_,reverse=False,key=lambda key: int(key))
		for id in l11l111l11ll_l1_:
			data += l1l1111l11ll_l1_.l11ll1lll11l_l1_[id]
	return data
def l1ll11lll11_l1_(addon_id):
	l1l111l11lll_l1_ = os.path.join(l1ll1111l1ll_l1_,l1l11l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ圧"),addon_id,l1l11l_l1_ (u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭在"))
	try: l11ll11l1l11_l1_ = open(l1l111l11lll_l1_,l1l11l_l1_ (u"ࠫࡷࡨࠧ圩")).read()
	except:
		l11l1ll11l1l_l1_ = os.path.join(l11ll1ll11ll_l1_,l1l11l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ圪"),addon_id,l1l11l_l1_ (u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩ圫"))
		try: l11ll11l1l11_l1_ = open(l11l1ll11l1l_l1_,l1l11l_l1_ (u"ࠧࡳࡤࠪ圬")).read()
		except: return l1l11l_l1_ (u"ࠨࠩ圭"),[]
	if kodi_version>18.99: l11ll11l1l11_l1_ = l11ll11l1l11_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ圮"))
	version = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧ圯"),l11ll11l1l11_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l11l_l1_ (u"ࠫࠬ地"),[]
	l1l11l11ll1l_l1_,l11lll1111ll_l1_ = version[0],l111lll1l1l1_l1_(version[0])
	return l1l11l11ll1l_l1_,l11lll1111ll_l1_
def l1ll11lllll_l1_():
	l1ll11l1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ圱"),l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ圲"),l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ圳"))
	if l1ll11l1l1l_l1_: return l1ll11l1l1l_l1_
	l11ll1111l_l1_,l1ll11l1l1l_l1_ = {},{}
	l11l11l1l1l1_l1_ = [WEBSITES[l1l11l_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ圴")][1]]
	if kodi_version>17.99: l11l11l1l1l1_l1_.append(WEBSITES[l1l11l_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ圵")][2])
	if kodi_version>18.99: l11l11l1l1l1_l1_.append(WEBSITES[l1l11l_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ圶")][3])
	for l11l111lllll_l1_ in l11l11l1l1l1_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ圷"),l11l111lllll_l1_,l1l11l_l1_ (u"ࠬ࠭圸"),l1l11l_l1_ (u"࠭ࠧ圹"),l1l11l_l1_ (u"ࠧࠨ场"),False,l1l11l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ圻"))
		if response.succeeded:
			html = response.content
			l111llll1ll1_l1_ = l11l111lllll_l1_.rsplit(l1l11l_l1_ (u"ࠩ࠲ࠫ圼"),1)[0]
			l11lll1l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ圽"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l11llll1l1l1_l1_ in l11lll1l1111_l1_:
				l11lllllll11_l1_ = l111llll1ll1_l1_+l1l11l_l1_ (u"ࠫ࠴࠭圾")+addon_id+l1l11l_l1_ (u"ࠬ࠵ࠧ圿")+addon_id+l1l11l_l1_ (u"࠭࠭ࠨ址")+l11llll1l1l1_l1_+l1l11l_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ坁")
				if addon_id not in list(l11ll1111l_l1_.keys()):
					l11ll1111l_l1_[addon_id] = []
					l1ll11l1l1l_l1_[addon_id] = []
				l11l11l1111l_l1_ = l111lll1l1l1_l1_(l11llll1l1l1_l1_)
				l11ll1111l_l1_[addon_id].append((l11llll1l1l1_l1_,l11l11l1111l_l1_,l11lllllll11_l1_))
	for addon_id in list(l11ll1111l_l1_.keys()):
		#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ坂"),str(addon_id)+l1l11l_l1_ (u"ࠩࠣࠤ࠳ࠦࠠࠨ坃")+str(l11ll1111l_l1_[addon_id]))
		l1ll11l1l1l_l1_[addon_id] = sorted(l11ll1111l_l1_[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭坄"),l1l11l_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ坅"),l1ll11l1l1l_l1_,REGULAR_CACHE)
	return l1ll11l1l1l_l1_
	l1l11l_l1_ (u"ࠧࠨࠢࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡴࡪࡥࡣࡧࡵ࡫࠳ࡵࡲࡨ࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯ࡣࡴࡤࡲࡨ࡮࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡫ࡡ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡦࡷࡧ࡮ࡤࡪ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡵࡴࡩࡧࡵࡷࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡧࡨ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠴࠲ࡶࡦࡽ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࠥࠦࠧ坆")
def l111lll1l1l1_l1_(l11llll1l1l1_l1_):
	l11l11l1111l_l1_ = []
	l1lllllllll_l1_ = l11llll1l1l1_l1_.split(l1l11l_l1_ (u"࠭࠮ࠨ均"))
	for l1lll111l1_l1_ in l1lllllllll_l1_:
		parts = re.findall(l1l11l_l1_ (u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫ坈"),l1lll111l1_l1_,re.DOTALL)
		l1l1l1lllll1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l1l1lllll1_l1_.append(part)
		l11l11l1111l_l1_.append(l1l1l1lllll1_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ坉"),str(l11llll1l1l1_l1_)+l1l11l_l1_ (u"ࠩࠣࠤ࠳ࠦࠠࠨ坊")+str(l11l11l1111l_l1_))
	return l11l11l1111l_l1_
def l11l1l1l1ll1_l1_(l11l11l1111l_l1_):
	l11llll1l1l1_l1_ = l1l11l_l1_ (u"ࠪࠫ坋")
	for l1lll111l1_l1_ in l11l11l1111l_l1_:
		for part in l1lll111l1_l1_: l11llll1l1l1_l1_ += str(part)
		l11llll1l1l1_l1_ += l1l11l_l1_ (u"ࠫ࠳࠭坌")
	l11llll1l1l1_l1_ = l11llll1l1l1_l1_.strip(l1l11l_l1_ (u"ࠬ࠴ࠧ坍"))
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ坎"),str(l11l11l1111l_l1_)+l1l11l_l1_ (u"ࠧࠡࠢ࠱ࠤࠥ࠭坏")+str(l11llll1l1l1_l1_))
	return l11llll1l1l1_l1_
def l1ll11lll11l_l1_(l1ll111lll1_l1_=l1ll1ll1ll11_l1_):
	# l11l11l11ll1_l1_ not l1l111l11111_l1_ l11l1l111l11_l1_ l11l111l1ll1_l1_ l11ll1111l_l1_ status l11l1l11ll_l1_ l1l1ll11ll_l1_ l1l11l1111_l1_ l11lllll1lll_l1_
	#l1llll1l1l11_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭坐"),l1l11l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ坑"),l1l11l_l1_ (u"ࠪࡉࡒࡇࡄࡠࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ坒"))
	#if l1llll1l1l11_l1_: return l1llll1l1l11_l1_
	l1llll1l1l11_l1_ = {}
	l11ll1111l_l1_ = l1ll11lllll_l1_()
	l1ll1lll1l11_l1_ = l1l1llllll1l_l1_(l1ll111lll1_l1_)
	for addon_id in l1ll111lll1_l1_:
		if addon_id not in list(l11ll1111l_l1_.keys()): continue
		#if not l11ll1111l_l1_[addon_id]: continue
		l1ll11l1l1l_l1_ = l11ll1111l_l1_[addon_id]
		l1ll11lll1l_l1_,l1ll11llll1_l1_,l1ll1l1111l_l1_ = l1ll11l1l1l_l1_[0]
		#l1ll1111111_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫ坓")+addon_id+l1l11l_l1_ (u"ࠬ࠯ࠧ坔"))
		l1ll1111111_l1_,l1ll111l1ll_l1_ = l1ll11lll11_l1_(addon_id)
		l1ll1lll1111_l1_,l1lll111llll_l1_ = l1ll1lll1l11_l1_[addon_id]
		l1ll111ll1l_l1_ = l1ll11llll1_l1_>l1ll111l1ll_l1_ and l1ll1lll1111_l1_
		l1ll111l111_l1_ = True
		if not l1ll1lll1111_l1_: l1lll1l111ll_l1_ = l1l11l_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ坕")
		elif not l1lll111llll_l1_: l1lll1l111ll_l1_ = l1l11l_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ坖")
		elif l1ll111ll1l_l1_: l1lll1l111ll_l1_ = l1l11l_l1_ (u"ࠨࡱ࡯ࡨࠬ块")
		else:
			l1lll1l111ll_l1_ = l1l11l_l1_ (u"ࠩࡪࡳࡴࡪࠧ坘")
			l1ll111l111_l1_ = False
		l1llll1l1l11_l1_[addon_id] = (l1ll111l111_l1_,l1ll1111111_l1_,l1ll111l1ll_l1_,l1ll11lll1l_l1_,l1ll11llll1_l1_,l1lll1l111ll_l1_,l1ll1l1111l_l1_)
	#WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭坙"),l1l11l_l1_ (u"ࠫࡊࡓࡁࡅࡡࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ坚"),l1llll1l1l11_l1_,REGULAR_CACHE)
	return l1llll1l1l11_l1_
	l1l11l_l1_ (u"ࠧࠨࠢࠎࠌࠌࠧ࡮࡬ࠠࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳ࠮࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠰࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࠥࡼࡥࡳࡵ࡬ࡳࡳ࠲ࡔࡳࡷࡨ࠰࡙ࡸࡵࡦࠏࠍࠍࠨ࡫࡬ࡴࡧ࠽ࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵ࠰࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠲ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡃࠠࠨࠩ࠯ࡊࡦࡲࡳࡦ࠮ࡉࡥࡱࡹࡥࠎࠌࠌࠧ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹࠦ࠽ࠡࠪࡻࡦࡲࡩ࠮ࡨࡧࡷࡇࡴࡴࡤࡗ࡫ࡶ࡭ࡧ࡯࡬ࡪࡶࡼ࡙ࠬࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬ࠯ࠧࠪ࠿ࡀ࠵࠮ࠓࠊࠊࠥ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡁࠫࠬࠓࠊࠊࠥ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࠬࡽࡨ࡭ࡤ࠰ࡪࡩࡹࡉ࡯࡯ࡦ࡙࡭ࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠮ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳࡏࡳࡆࡰࡤࡦࡱ࡫ࡤࠩࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠩࠨࠫࡀࡁ࠶࠯ࠍࠋࠋࠦࡩࡱࡹࡥ࠻ࠢ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࡰࡲࡸࠥ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡩࡴࡡࡨࡼ࡮ࡹࡴࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡨࡪࡩ࡫ࡩࡸࡺ࡟ࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠊࠋࠪ࠯ࡸࡺࡲࠩࡪ࡬࡫࡭࡫ࡳࡵࡡࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷࡥࡣࡰ࡯ࡳࡥࡷ࡫ࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠋࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡲࡰࡩࠏࠧࠬࡵࡷࡶ࠭࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡴࡲࡤࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫࡳ࡫ࡥࡥࡡࡸࡴࡩࡧࡴࡦࠋࠌࠫ࠰ࡹࡴࡳࠪࡱࡩࡪࡪ࡟ࡶࡲࡧࡥࡹ࡫ࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡳࡵࡣࡷࡹࡸࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡶࡸࡦࡺࡵࡴࠫࠬࠑࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡶࡦࡴࡶ࡭ࡴࡴࡳ࠻ࠢࠣࠫ࠰ࡹࡴࡳࠪࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭࠰࠭ࠠࠡࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥࡹ࡫ࡶࡸ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨ࠮࠯ࠍࠋࠋࠥࠦࠧ坛")
def PROGRESS_UPDATE(pDialog,l11ll1llllll_l1_,l1l111111l1l_l1_=l1l11l_l1_ (u"࠭ࠧ坜"),line2=l1l11l_l1_ (u"ࠧࠨ坝"),l1l111111ll1_l1_=l1l11l_l1_ (u"ࠨࠩ坞")):
	if kodi_version<19: pDialog.update(l11ll1llllll_l1_,l1l111111l1l_l1_,line2,l1l111111ll1_l1_)
	else: pDialog.update(l11ll1llllll_l1_,l1l111111l1l_l1_+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ坟")+line2+l1l11l_l1_ (u"ࠪࡠࡳ࠭坠")+l1l111111ll1_l1_)
	return
def l11111lllll_l1_(l111lll1l11_l1_):
	# l1l111l11111_l1_ it for this:  function(p,a,c,k,e,d)
	def l11ll11l11ll_l1_(num,b,l11l11lll111_l1_=l1l11l_l1_ (u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࠨ坡")):
		return ((num == 0) and l11l11lll111_l1_[0]) or (l11ll11l11ll_l1_(num // b, b, l11l11lll111_l1_).lstrip(l11l11lll111_l1_[0]) + l11l11lll111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l11l_l1_ (u"ࠧࡢ࡜ࡣࠤ坢") + l11ll11l11ll_l1_(c, a) + l1l11l_l1_ (u"ࠨ࡜࡝ࡤࠥ坣"),  k[c], p)
		return p
	l111lll1l11_l1_ = l111lll1l11_l1_.split(l1l11l_l1_ (u"ࠧࡾࠪࠪ坤"))[1][:-1]
	l11111l11l1_l1_ = eval(l1l11l_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩ坥")+l111lll1l11_l1_,{l1l11l_l1_ (u"ࠩࡥࡥࡸ࡫ࡎࠨ坦"):l11ll11l11ll_l1_,l1l11l_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠪ坧"):unpack})   #,locals())
	return l11111l11l1_l1_
def l1llll1l11_l1_(url,l11l1l11l1ll_l1_=l1l11l_l1_ (u"ࠫࠬ坨")):
	if l11l1l11l1ll_l1_==l1l11l_l1_ (u"ࠬࡲ࡯ࡸࡧࡵࠫ坩"): url = re.sub(l1l11l_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭坪"),lambda l1l11l111111_l1_: l1l11l111111_l1_.group(0).lower(),url)
	elif l11l1l11l1ll_l1_==l1l11l_l1_ (u"ࠧࡶࡲࡳࡩࡷ࠭坫"): url = re.sub(l1l11l_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨ坬"),lambda l1l11l111111_l1_: l1l11l111111_l1_.group(0).upper(),url)
	return url
def l1l1llllll1l_l1_(l1ll111lll1_l1_):
	installed,l11ll1ll1l11_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1ll1ll1ll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l1ll111lll1_l1_)==1: l11ll1111lll_l1_ = l1l11l_l1_ (u"ࠩࠫࠦࠬ坭")+l1ll111lll1_l1_[0]+l1l11l_l1_ (u"ࠪࠦ࠮࠭坮")
	else: l11ll1111lll_l1_ = str(tuple(l1ll111lll1_l1_))
	cc.execute(l1l11l_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫ坯")+l11ll1111lll_l1_+l1l11l_l1_ (u"ࠬࠦ࠻ࠨ坰"))
	rows = cc.fetchall()
	l1ll1lll1l11_l1_ = {}
	for addon_id in l1ll111lll1_l1_: l1ll1lll1l11_l1_[addon_id] = (False,False)
	for addon_id,l11ll1ll1l11_l1_ in rows:
		installed = True
		l11ll1ll1l11_l1_ = l11ll1ll1l11_l1_==1
		l1ll1lll1l11_l1_[addon_id] = (installed,l11ll1ll1l11_l1_)
	conn.close()
	return l1ll1lll1l11_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	if file==l1ll1l11l11_l1_: results = []
	else: results = {}
	if os.path.exists(file):
		oldFILE = open(file,l1l11l_l1_ (u"࠭ࡲࡣࠩ坱")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ坲"))
		if file==l1ll1l11l11_l1_: results = EVAL(l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭坳"),oldFILE)
		else:
			l11lll11l11l_l1_ = EVAL(l1l11l_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ坴"),oldFILE)
			if l11lll11l11l_l1_:
				for key in l11lll11l11l_l1_.keys():
					results[key] = []
					for l11ll11lllll_l1_ in l11lll11l11l_l1_[key]:
						type,name,url,mode,image,page,text,context,infodict = l1l11l_l1_ (u"ࠪࠫ坵"),l1l11l_l1_ (u"ࠫࠬ坶"),l1l11l_l1_ (u"ࠬ࠭坷"),l1l11l_l1_ (u"࠭ࠧ坸"),l1l11l_l1_ (u"ࠧࠨ坹"),l1l11l_l1_ (u"ࠨࠩ坺"),l1l11l_l1_ (u"ࠩࠪ坻"),l1l11l_l1_ (u"ࠪࠫ坼"),l1l11l_l1_ (u"ࠫࠬ坽")
						type = l11ll11lllll_l1_[0]
						name = l11ll11lllll_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l11ll11lllll_l1_[2]
						mode = l11ll11lllll_l1_[3]
						image = l11ll11lllll_l1_[4]
						page = l11ll11lllll_l1_[5]
						if len(l11ll11lllll_l1_)>6: text = l11ll11lllll_l1_[6]
						if len(l11ll11lllll_l1_)>7: context = l11ll11lllll_l1_[7]
						if len(l11ll11lllll_l1_)>8: infodict = l11ll11lllll_l1_[8]
						if file==favoritesfile: l111lllll1ll_l1_ = type,name,url,mode,image,l1l11l_l1_ (u"ࠬ࠭坾"),text,l1l11l_l1_ (u"࠭ࠧ坿"),l1l11l_l1_ (u"ࠧࠨ垀")
						else: l111lllll1ll_l1_ = type,name,url,mode,image,page,text,context,infodict
						results[key].append(l111lllll1ll_l1_)
		newFILE = str(results)
		if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭垁"))
		open(file,l1l11l_l1_ (u"ࠩࡺࡦࠬ垂")).write(newFILE)
	return results
def l1lll1ll11l_l1_(site):
	l1lll1llll1_l1_ = site.split(l1l11l_l1_ (u"ࠪ࠱ࠬ垃"),1)[0]
	l1lll1lll1l_l1_,l1llll111ll_l1_,l1llllll11l_l1_ = l1l11l_l1_ (u"ࠫࠬ垄"),l1l11l_l1_ (u"ࠬ࠭垅"),l1l11l_l1_ (u"࠭ࠧ垆")
	if   l1lll1llll1_l1_==l1l11l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭垇")		:	from l11l1_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ垈")	:	from l11111l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ垉")		:	from l11ll1_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ垊")	:	from l1l11111_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭型")	:	from l1lllll11_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ垌")	: 	from l1lll11l1_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ垍")	:	from l1lll111l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ垎")	:	from l1l11l1ll_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ垏")		:	from l11l1l111_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ垐")	:	from l11l1111l_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ垑")	:	from l11111l11_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭垒")	:	from l1llllll11_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ垓")	:	from l1llll1ll1_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ垔"):	from l1l1ll11111l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ垕")	:	from l1llll1l1l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭垖"):	from l1ll1l111l_l1_	import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ垗")	:	from l11ll1l11l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ垘")	:	from l111ll11l1_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ垙")	:	from l111ll111l_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ垚")	:	from l111111l1l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ垛")	:	from l1lll1l1l11_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ垜")	:	from l1111l11l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ垝")		:	from l1lll1l11l1_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ垞")		:	from IPTV			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭垟")	:	from l1ll1lll1l1_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ垠")	:	from l1ll1l11l1l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ垡")	:	from l1l1ll1l1ll_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭垢")	:	from l1l1ll1l11l_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ垣")	:	from l111111l111_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ垤")	:	from l1111111ll_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ垥")	:	from l1lllllll11_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ垦")		:	from l1l1ll1l111_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭垧")	:	from l111111111l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ垨")	:	from l1l1l1lll1ll_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ垩")	:	from l1l1l1l1lll1_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ垪")	:	from l1lllll1l11l_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ垫")		:	from l111llll1ll_l1_			import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ垬")	:	from l1l1111l1l1_l1_		import MENU as l1lll1lll1l_l1_,SEARCH as l1llll111ll_l1_,menu_name as l1llllll11l_l1_
	elif l1lll1llll1_l1_==l1l11l_l1_ (u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩ垭"):	from l1l11l1l1111_l1_	import MENU as l1lll1lll1l_l1_
	return l1lll1lll1l_l1_,l1llll111ll_l1_,l1llllll11l_l1_
def DOWNLOAD_USING_PROGRESSBAR(l111ll1lll1l_l1_,headers={}):
	#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࠬ垮"),l1l11l_l1_ (u"ࠬ࠭垯"),l1l11l_l1_ (u"࠭ࠧ垰"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ垱"),l1l11l_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤ๊์ࠠศๆศ๊ฯืๆห๋ࠢๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠣࠪ垲"))
	#if yes!=1: return
	LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ垳"),l1l11l_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩ垴")+l111ll1lll1l_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ垵")+str(headers)+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ垶"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ垷"),l1l11l_l1_ (u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩ垸"))
	MegaByte = 1024*1024
	l11l1111ll1l_l1_ = bytes()
	chunk_size = 1*MegaByte
	import requests
	headers2 = headers
	headers2[l1l11l_l1_ (u"ࠨࡔࡤࡲ࡬࡫ࠧ垹")] = l1l11l_l1_ (u"ࠩࡥࡽࡹ࡫ࡳ࠾࠲࠰ࠫ垺")
	response = requests.get(l111ll1lll1l_l1_,stream=True,headers=headers2,timeout=120)
	if l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫ垻") not in list(response.headers.keys()):
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ垼"),l1l11l_l1_ (u"ࠬ࠭垽"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ垾"),l1l11l_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪ垿"))
		return
	filesize = int(response.headers[l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ埀")])
	l1l1lll1ll_l1_ = str(int(1000*filesize/MegaByte)/1000.0)
	l1l1l1l111_l1_ = int(filesize/chunk_size)+1
	if l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩ埁") in list(response.headers.keys()) and filesize>MegaByte:
		l11l1llllll1_l1_ = True
		l1lllllllll_l1_ = []
		l1llllll1ll_l1_ = 10
		l1lllllllll_l1_.append(str(0*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠪ࠱ࠬ埂")+str(1*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(1*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠫ࠲࠭埃")+str(2*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(2*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠬ࠳ࠧ埄")+str(3*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(3*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"࠭࠭ࠨ埅")+str(4*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(4*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠧ࠮ࠩ埆")+str(5*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(5*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠨ࠯ࠪ埇")+str(6*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(6*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠩ࠰ࠫ埈")+str(7*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(7*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠪ࠱ࠬ埉")+str(8*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(8*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠫ࠲࠭埊")+str(9*filesize//l1llllll1ll_l1_-1))
		l1lllllllll_l1_.append(str(9*filesize//l1llllll1ll_l1_)+l1l11l_l1_ (u"ࠬ࠳ࠧ埋"))
		l1l111ll1111_l1_ = float(l1l1l1l111_l1_)/l1llllll1ll_l1_
		l11ll1l1l1l1_l1_ = l1l111ll1111_l1_/int(1+l1l111ll1111_l1_)
	else:
		l11l1llllll1_l1_ = False
		l1llllll1ll_l1_ = 1
		l11ll1l1l1l1_l1_ = 1
	response.close()
	LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭埌"),l1l11l_l1_ (u"ࠧ࠯ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡤࡶ࡬ࡳࡳࡹ࠺ࠡ࡝ࠣࠫ埍")+str(l11l1llllll1_l1_)+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ城")+str(filesize)+l1l11l_l1_ (u"ࠩࠣࡡࠬ埏"))
	ii = 0
	#t1 = time.time()-30
	for jj in range(l1llllll1ll_l1_):
		headers2 = headers
		if l11l1llllll1_l1_: headers2[l1l11l_l1_ (u"ࠪࡖࡦࡴࡧࡦࠩ埐")] = l1l11l_l1_ (u"ࠫࡧࡿࡴࡦࡵࡀࠫ埑")+l1lllllllll_l1_[jj]
		response = requests.get(l111ll1lll1l_l1_,stream=True,headers=headers2,timeout=120)
		for chunk in response.iter_content(chunk_size=chunk_size):
			if pDialog.iscanceled():
				response.close()
				LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ埒"),l1l11l_l1_ (u"࠭࠮ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧ埓"))
				break
			ii += l11ll1l1l1l1_l1_
			PROGRESS_UPDATE(pDialog,0+int(100*ii/l1l1l1l111_l1_),l1l11l_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠥอไอิฤࠤึ่ๅࠨ埔"),str(int(ii*chunk_size//MegaByte))+l1l11l_l1_ (u"ࠨࠢ࠲ࠤࠬ埕")+l1l1lll1ll_l1_+l1l11l_l1_ (u"ࠩࠣࡑࡇ࠭埖"))
			l11l1111ll1l_l1_ += chunk
			#PROGRESS_UPDATE(pDialog,0+int(35*ii/l1l1l1l111_l1_),l1l11l_l1_ (u"ࠪะ้ฮࠠศๆ่่ๆࠦวๅำษ๎ุ๐࠺࠮ࠢส่ัุมࠡำๅ้ࠬ埗")+l1l11l_l1_ (u"ࠫࡡࡴࠧ埘")+str(ii*chunksize/MegaByte)+l1l11l_l1_ (u"ࠬࠦ࠯ࠡࠩ埙")+l1l1lll1ll_l1_+l1l11l_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ埚")+time.strftime(l1l11l_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ埛")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ埜")+time.gmtime(l1l1l111l1_l1_))+l1l11l_l1_ (u"ࠩࠣไࠬ埝"))
			#t2 = time.time()
			#l1l11lll11_l1_ = t2-t1
			#l1l11lllll_l1_ = l1l11lll11_l1_/ii
			#l1l1ll111l_l1_ = l1l11lllll_l1_*(l1l1l1l111_l1_+1)
			#l1l1l111l1_l1_ = l1l1ll111l_l1_-l1l11lll11_l1_
		response.close()
	pDialog.close()
	if len(l11l1111ll1l_l1_)<filesize:
		LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ埞"),l1l11l_l1_ (u"ࠫ࠳ࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡳࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡣࡷ࠾ࠥࡡࠠࠨ域")+str(len(l11l1111ll1l_l1_)//MegaByte)+l1l11l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪ埠")+l1l1lll1ll_l1_+l1l11l_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ埡"))
		choice = l1l1llllllll_l1_(l1l11l_l1_ (u"ࠧࠨ埢"),l1l11l_l1_ (u"ࠨว็฾ฬว้ࠠะิ์ั࠭埣"),l1l11l_l1_ (u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩ埤"),l1l11l_l1_ (u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬ埥"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ埦"),l1l11l_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩ埧")+str(len(l11l1111ll1l_l1_)//MegaByte)+l1l11l_l1_ (u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬ埨")+l1l1lll1ll_l1_+l1l11l_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩ埩"))
		if choice==2: l11l1111ll1l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l111ll1lll1l_l1_,headers)
		elif choice==1: LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ埪"),l1l11l_l1_ (u"ࠩ࠱ࠤࠥࠦࡎࡰࡶࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࡩࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡦࡩࡣࡦࡲࡷࡩࡩࠦࡡ࡯ࡦࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡥࠩ埫"))
		else: return
		if not l11l1111ll1l_l1_: return
	else: LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ埬"),l1l11l_l1_ (u"ࠫ࠳ࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩ࠴ࠠࠡࠢࡉ࡭ࡱ࡫ࠠࡔ࡫ࡽࡩ࠿࡛ࠦࠡࠩ埭")+l1l1lll1ll_l1_+l1l11l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ埮"))
	return l11l1111ll1l_l1_
def SEND_ANALYTICS_EVENT(script_name,allow_dns_fix=True,allow_proxy_fix=True):
	# old l11ll1ll1l1l_l1_ l11l1lll11l1_l1_ l11111l1l11_l1_
	#l111llll1l11_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡣࡰ࡯࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠱ࠧࡶ࡬ࡨࡂ࡛ࡁ࠮࠳࠵࠻࠵࠺࠵࠲࠲࠷࠱࠺ࠬࡣࡪࡦࡀࠫ埯")+l1ll1l1l11l_l1_(32)+l1l11l_l1_ (u"ࠧࠧࡶࡀࡩࡻ࡫࡮ࡵࠨࡶࡧࡂ࡫࡮ࡥࠨࡨࡧࡂ࠭埰")+addon_version+l1l11l_l1_ (u"ࠨࠨࡤࡺࡂ࠭埱")+addon_version+l1l11l_l1_ (u"ࠩࠩࡥࡳࡃࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࡥࡎࡆ࡙ࡆࡐࡎࡋࡎࡕࡋࡇࠪࡪࡧ࠽ࠨ埲")+script_name+l1l11l_l1_ (u"ࠪࠪࡪࡲ࠽ࠨ埳")+str(kodi_version)+l1l11l_l1_ (u"ࠫࠫࢀ࠽ࠨ埴")+l111llll1l11_l1_
	#response = OPENURL_REQUESTS(l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ埵"),url,l1l11l_l1_ (u"࠭ࠧ埶"),l1l11l_l1_ (u"ࠧࠨ執"),l1l11l_l1_ (u"ࠨࠩ埸"),False,l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ培"))
	# l11l11lll11l_l1_ test:    l11l11l_l1_://l1lll1l11ll1_l1_-l1ll11111lll_l1_-l1ll11l1l1ll_l1_.l1lll1l11lll_l1_/l11l1l1llll1_l1_/l11lll1l1lll_l1_-l11l11l1llll_l1_
	# l11l11lll11l_l1_ json method:    l11l11l_l1_://l111lll1l11l_l1_.l1lll1l11lll_l1_.l11111ll_l1_/l11l1llll1l1_l1_/l11ll111ll1l_l1_/l1l111111111_l1_/protocol/l11l1l1llll1_l1_/l11l1lllll1l_l1_/l11l11lll11l_l1_
	# l11l11lll11l_l1_ json method:    l11l11l_l1_://l111lll1l11l_l1_.l1lll1l11lll_l1_.l11111ll_l1_/l11l1llll1l1_l1_/l11ll111ll1l_l1_/l1l111111111_l1_/protocol/l11l1l1llll1_l1_/l11l1lllll1l_l1_?l11llll1111l_l1_=l11l111111ll_l1_
	# l11l11lll11l_l1_ hit method:   l11l11l_l1_://l1llllll1ll1_l1_.l11lll11ll1l_l1_.l11111ll_l1_/l11l1l1llll1_l1_-l11lll1ll11l_l1_-protocol-l11ll1l11l1l_l1_
	# l11l11lll11l_l1_ hit method:   l11l11l_l1_://l1llllll1ll1_l1_.l11lll11ll1l_l1_.l11111ll_l1_/l1l111l11ll1_l1_-l11l1ll1lll1_l1_-l1lll1l11lll_l1_-l11l1llll1l1_l1_-l11lll1ll11l_l1_-protocol-version-2
	# l11l11ll1l1l_l1_ json method
	#url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰࡯ࡳ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡧࡰࡪࡡࡶࡩࡨࡸࡥࡵ࠿࠳࠱ࡻ࠷࠵ࡂࡦࡦࡖࡌࡧࡐࡨࡳࡵࡳ࡬ࡲ࠵࠺ࡍࡄࠪࡲ࡫ࡡࡴࡷࡵࡩࡲ࡫࡮ࡵࡡ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠫ基")
	#headers = {l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ埻"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ埼")}
	#params = {l1l11l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨࠫ埽"):script_name,l1l11l_l1_ (u"ࠧࡢࡸࡢࡺࡪࡸࡳࡪࡱࡱࠫ埾"):addon_version,l1l11l_l1_ (u"ࠨ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ埿"):kodi_version}
	#data = {l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡡ࡬ࡨࠬ堀"):l1ll1l1l11l_l1_(32),l1l11l_l1_ (u"ࠪࡩࡻ࡫࡮ࡵࡵࠪ堁"):[{l1l11l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ堂"):l1l11l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࡤࡍࡁ࠵ࠩ堃"),l1l11l_l1_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭堄"):params}]}
	#response = OPENURL_REQUESTS(l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ堅"),url,str(data),headers,l1l11l_l1_ (u"ࠨࠩ堆"),False,l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ堇"))
	# l11l11ll1l1l_l1_ hit method
	url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰ࡩ࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠲ࠧࡶ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠪࡨ࡯ࡤ࠾ࠩ堈")+l1ll1l1l11l_l1_(32)+l1l11l_l1_ (u"ࠫࠫࡥࡳ࠾࠳ࠩࡩࡳࡃࠧ堉")+script_name+l1l11l_l1_ (u"ࠬࠬࡵࡱ࠰ࡤࡺࡤࡼࡥࡳ࠿ࠪ堊")+addon_version+l1l11l_l1_ (u"࠭ࠦࡶࡲ࠱࡯ࡴࡪࡩࡠࡸࡨࡶࡂ࠭堋")+str(kodi_version)
	response = OPENURL_REQUESTS(l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ堌"),url,l1l11l_l1_ (u"ࠨࠩ堍"),l1l11l_l1_ (u"ࠩࠪ堎"),l1l11l_l1_ (u"ࠪࠫ堏"),False,l1l11l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ堐"))
	return response
def l1l1llll1ll1_l1_(l11111llll1_l1_=l1l11l_l1_ (u"ࠬ࠭堑")):
	l1lll11l1l11_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡳࡵࡴࠪ堒"),l1l11l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ堓"),l1l11l_l1_ (u"ࠨࡋࡓࡐࡔࡉࡁࡕࡋࡒࡒࠬ堔"))
	if l1lll11l1l11_l1_: return l1lll11l1l11_l1_
	# url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡵࡲ࡯ࡤࡣࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ堕")
	# l11111l1l11_l1_   url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡶࡷࡩࡱ࡬ࡷ࠳ࡧࡰࡱ࠱࡭ࡷࡴࡴ࠯ࠨ堖")+l11111llll1_l1_
	# l11l11ll11ll_l1_   url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡷࡩࡱ࠱࡭ࡸ࠵࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ堗")
	url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ堘")+l11111llll1_l1_+l1l11l_l1_ (u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ堙")
	response = OPENURL_REQUESTS(l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ堚"),url,l1l11l_l1_ (u"ࠨࠩ堛"),l1l11l_l1_ (u"ࠩࠪ堜"),l1l11l_l1_ (u"ࠪࠫ堝"),False,l1l11l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ堞"))
	html = response.content
	l1l1111111l1_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ堟"),html)
	l11l11l1l111_l1_,country,l11l1ll11l11_l1_,l11lll111l11_l1_,timezone = l1l11l_l1_ (u"࠭ࠧ堠"),l1l11l_l1_ (u"ࠧࠨ堡"),l1l11l_l1_ (u"ࠨࠩ堢"),l1l11l_l1_ (u"ࠩࠪ堣"),l1l11l_l1_ (u"ࠪࠫ堤")
	if l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧ堥") in list(l1l1111111l1_l1_.keys()): l11l11l1l111_l1_ = l1l1111111l1_l1_[l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨ堦")]
	if l1l11l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ堧") in list(l1l1111111l1_l1_.keys()): country = l1l1111111l1_l1_[l1l11l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ堨")]
	if l1l11l_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ堩") in list(l1l1111111l1_l1_.keys()): l11l1ll11l11_l1_ = l1l1111111l1_l1_[l1l11l_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ堪")]
	if l1l11l_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ堫") in list(l1l1111111l1_l1_.keys()): l11lll111l11_l1_ = l1l1111111l1_l1_[l1l11l_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ堬")]
	if l1l11l_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ堭") in list(l1l1111111l1_l1_.keys()):
		timezone = l1l1111111l1_l1_[l1l11l_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ堮")][l1l11l_l1_ (u"ࠧࡶࡶࡦࠫ堯")]
		if timezone[0] not in [l1l11l_l1_ (u"ࠨ࠯ࠪ堰"),l1l11l_l1_ (u"ࠩ࠮ࠫ報")]: timezone = l1l11l_l1_ (u"ࠪ࠯ࠬ堲")+timezone
	l1lll11l1l11_l1_ = l11l11l1l111_l1_+l1l11l_l1_ (u"ࠫ࠱࠭堳")+country+l1l11l_l1_ (u"ࠬ࠲ࠧ場")+l11l1ll11l11_l1_+l1l11l_l1_ (u"࠭ࠬࠨ堵")+l11lll111l11_l1_+l1l11l_l1_ (u"ࠧ࠭ࠩ堶")+timezone
	if kodi_version>18.99: l1lll11l1l11_l1_ = l1lll11l1l11_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭堷")).decode(l1l11l_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ堸"))
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭堹"),l1l11l_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ堺"),l1lll11l1l11_l1_,l1111lll_l1_)
	return l1lll11l1l11_l1_
#=================================================================================
# the l11ll11111_l1_ function l111lllll11_l1_ added from:
# l11l11l_l1_://l1l111l111_l1_.l11111ll_l1_/l11l1l1l1l_l1_/l11ll1l1l1_l1_-host-l11l1ll1l1_l1_/-/l11lll11ll_l1_/l11lllll11_l1_/l11l1l1111_l1_/l11l1l1ll1_l1_/l111lll111ll_l1_.py
# l11l11l_l1_://l11l1lll1l_l1_.l11111ll_l1_/l11l1l11l1_l1_/l11ll11lll_l1_-l11ll1111l_l1_/l11lll11ll_l1_/l11lllll11_l1_/l11l1ll1ll_l1_.l1l1llll11_l1_.l1l1111lll_l1_/l11lll1l11_l1_/l11l111111l1_l1_/l111lll111_l1_.py
# l11llll11111_l1_ to the l11l1l1lllll_l1_ l1l11l_l1_ (u"ࠧࡘࡧࡺࡵࡲࡪࡹࠨ堻")
#=================================================================================
def l1llll11ll_l1_(data):
	page = data
	if l1l11l_l1_ (u"࠭ࡡࡥ࡫࡯ࡦࡴࡥࡈࡕࡏࡏࡣࡪࡴࡣࡰࡦࡨࡶࠬ堼") in data:
		l1l111111lll_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡦࡶ࡮ࡶࡴ࠯ࠬࡂ࠿࠳࠰࠿࡝ࠩࠫ࠲࠯ࡅࠩ࠼ࠩ堽"), data, re.S)
		l11llll1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࠱ࡪ࠲࠳࠴࠮࠯ࠪ࠱࠮ࡄ࠯࡜ࠪࠩ堾"), data, re.S)
		if l1l111111lll_l1_ and l11llll1l111_l1_:
			l11lllllll_l1_ = l1l111111lll_l1_[0].replace(l1l11l_l1_ (u"ࠤࠪࠦ堿"),l1l11l_l1_ (u"ࠪࠫ塀"))
			l11lllllll_l1_ = l11lllllll_l1_.replace(l1l11l_l1_ (u"ࠦ࠰ࠨ塁"),l1l11l_l1_ (u"ࠬ࠭塂"))
			l11lllllll_l1_ = l11lllllll_l1_.replace(l1l11l_l1_ (u"ࠨ࡜࡯ࠤ塃"),l1l11l_l1_ (u"ࠧࠨ塄"))
			l11lllll1ll1_l1_ = l11lllllll_l1_.split(l1l11l_l1_ (u"ࠨ࠰ࠪ塅"))
			page = l1l11l_l1_ (u"ࠩࠪ塆")
			for l11ll1ll1l_l1_ in l11lllll1ll1_l1_:
				l11ll111ll11_l1_ = base64.b64decode(l11ll1ll1l_l1_+l1l11l_l1_ (u"ࠪࡁࡂ࠭塇")).decode(l1l11l_l1_ (u"ࠦࡺࡺࡦ࠮࠺ࠥ塈"))
				l11lllll11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࡤࠬࠩ塉"), l11ll111ll11_l1_, re.S)
				if l11lllll11l1_l1_:
					l111lll1ll11_l1_ = int(l11lllll11l1_l1_[0])+int(l11llll1l111_l1_[0])
					page = page + chr(l111lll1ll11_l1_)
	return page
if __name__==l1l11l_l1_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨ塊"):
	# l11l111ll111_l1_ l11l1l1_l1_ when l111ll1lll11_l1_
	LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ塋"),l1l11l_l1_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࠭塌"))
	if 0:
		url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡱࡱࡩ࠴ࡼࡩࡥࡧࡲࡣࡵࡲࡡࡺࡧࡵࡃࡺ࡯ࡤ࠾࠲ࠩࡺ࡮ࡪ࠽ࡧࡨࡥ࠻࠵࠾ࡣ࠲࠻࠵ࡧ࠷࠾ࡤ࠲࠳࠵࠴࠷ࡧࡤ࠲࠺ࡧࡨ࠶࠸ࡣ࠷࠺࠳࠺ࠬ塍")
		import ll_l1_
		a,b,c = ll_l1_.l1111111ll_l1_(url)
		#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ塎"),l1l11l_l1_ (u"ࠫࠬ塏"),l1l11l_l1_ (u"ࠬ࠭塐"),str(c))
		l1111111lll_l1_ = c[0][0]
		#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ塑"),l1111111lll_l1_)
		l1111111lll_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴ࠵࠷࠲࠳ࡢ࡬ࡻࡦࡪࡨࡲࡪ࠯ࡥ࠱ࡷࡨࡪ࡮࠯ࡶࡲ࠳ࡸࡺࡲࡦࡣࡰ࠳ࡻ࠷࠯ࡩ࡮ࡶ࠳࠸ࡪࡕࡕࡈ࠺࡝࠼ࡋࡂࡈ࡮ࡘࡶ࡛ࡐࡊࡵ࠴ࡎ࡛࡬࠵࠱࠷࠺࠶࠺࠾࠿࠲࠺࠶࠲ࡥࡱࡲ࠯ࡢ࡮࡯࠳࠶࠶࠷࠯࠳࠸࠽࠳࠷࠴࠯࠶࠶࠳ࡾ࡫ࡳ࠰ࡅࡄ࠳࠵࠵࠰࠷࠯࠳࠶࠴࠸࠯ࡧࡨࡥ࠻࠵࠾ࡣ࠲࠻࠵ࡧ࠷࠾ࡤ࠲࠳࠵࠴࠷ࡧࡤ࠲࠺ࡧࡨ࠶࠸ࡣ࠷࠺࠳࠺࠴࠷࠵࠶ࡡ࡫ࡨ࠼࠸࠰ࡣࡡࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵ࠹ࠩ塒")
		#PLAY_VIDEO(l1111111lll_l1_)
		l11l11111l1l_l1_ = xbmcgui.ListItem()
		#l11l11111l1l_l1_.setPath(l1111111lll_l1_)
		#xbmcplugin.setResolvedUrl(addon_handle,True,l11l11111l1l_l1_)
		xbmc.Player().play(l1111111lll_l1_,l11l11111l1l_l1_)
	else:
		errortrace = l1l11l_l1_ (u"ࠨࠩ塓")
		l1llll1l1_l1_(l1l11l_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ塔"))
		try: l11ll1l1lll1_l1_()
		except Exception as error: errortrace = traceback.format_exc()
		l1llll1l1_l1_(l1l11l_l1_ (u"ࠪࡷࡹࡵࡰࠨ塕"))
		if errortrace:
			#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ塖"),l1l11l_l1_ (u"ࠬࡋࡅࡎࡏࡄࡅࡉࡊ࠺ࠡࠢࠪ塗")+errortrace)
			if l1l11l_l1_ (u"࠭࡟ࡠࡈࡒࡖࡈࡋࡄࡠࡇ࡛ࡍ࡙ࡥ࡟ࠨ塘") not in errortrace: l1l11l1111ll_l1_(errortrace)
			else:
				l11l111l1l1l_l1_ = errortrace.splitlines()
				for line in reversed(l11l111l1l1l_l1_):
					if l1l11l_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ塙") in line:
						line = line.split(l1l11l_l1_ (u"ࠨࡡࡢࡊࡔࡘࡃࡆࡆࡢࡉ࡝ࡏࡔࡠࡡࠪ塚"))[1]
						sys.stderr.write(l1l11l_l1_ (u"ࠩ࡟ࡲࡋࡕࡒࡄࡇࡇࠤࡊ࡞ࡉࡕ࠼࡟ࡲࠬ塛")+line)
						sys.stderr.write(l1l11l_l1_ (u"ࠪࡠࡳࡥࠧ塜"))
						break
		refresh = settings.getSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ塝"))
		if refresh==l1l11l_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ塞"): settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ塟"),l1l11l_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ塠"))
		elif refresh==l1l11l_l1_ (u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ塡"): settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭塢"),l1l11l_l1_ (u"ࠪࠫ塣"))
		l1lll1111lll_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ塤"))
		l1l1lll11l1l_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ塥"))
		if l1l11l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ塦") in str(l1l1lll11l1l_l1_) and l1lll1111lll_l1_ in [l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ塧"),l1l11l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ塨")]:
			#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠩࠪ塩"),l1lll1111lll_l1_)
			time.sleep(0.100)
			xbmc.executebuiltin(l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧ塪"))
		#l1l111l1ll1l_l1_ = sys.version_info[0]
		#l11lllllll1l_l1_ = sys.version_info[1]
		#if l1l111l1ll1l_l1_==2: python_version = l1l11l_l1_ (u"ࠫ࠷࠽ࠧ填")
		#else: python_version = str(l1l111l1ll1l_l1_)+str(l11lllllll1l_l1_)
		#l1l111lll11l_l1_ = os.path.join(addonfolder,l1l11l_l1_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ塬")+python_version)
		if 0 and addon_handle>-1:
			#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ塭"),l1l11l_l1_ (u"ࠧࠨ塮"),l1l11l_l1_ (u"ࠨࠩ塯"),str(addon_handle))
			xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
			succeeded,updateListing,cacheToDisc = False,False,False
			xbmcplugin.endOfDirectory(addon_handle,succeeded,updateListing,cacheToDisc)
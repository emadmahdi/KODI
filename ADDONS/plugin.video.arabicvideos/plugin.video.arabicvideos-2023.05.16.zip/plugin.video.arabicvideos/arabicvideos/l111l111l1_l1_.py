# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎࠧ⏨")
menu_name = l1l11l_l1_ (u"ࠩࡢࡋࡑ࡙࡟ࠨ⏩")
def MAIN(mode,url,text,page):
	if   mode==540: results = MENU()
	elif mode==541: results = l1llll1lll1_l1_(text)
	elif mode==542: results = l1llll111l1_l1_(text,url,page)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏪"),l1l11l_l1_ (u"ࠫอำหࠡฮา๎ิ࠭⏫"),l1l11l_l1_ (u"ࠬ࠭⏬"),549)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⏭"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃࠠไๆ่หฯࠦๅฯิ้อࠥࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⏮"),l1l11l_l1_ (u"ࠨࠩ⏯"),9999)
	l1llll1l11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ⏰"),l1l11l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⏱"))
	if l1llll1l11l_l1_:
		l1llll1l11l_l1_ = l1llll1l11l_l1_[l1l11l_l1_ (u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬ⏲")]
		for search in reversed(l1llll1l11l_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏳"),search,l1l11l_l1_ (u"࠭ࠧ⏴"),549,l1l11l_l1_ (u"ࠧࠨ⏵"),l1l11l_l1_ (u"ࠨࠩ⏶"),search)
	return
def SEARCH(search):
	#search,options,showdialogs = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l111l11lll_l1_ = search.replace(menu_name,l1l11l_l1_ (u"ࠩࠪ⏷"))
	l1lll1lll11_l1_(l111l11lll_l1_)
	#l1lll1l1lll_l1_ = search+options+l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⏸")
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⏹"),l1l11l_l1_ (u"ࠬ฿ๅๅࠢหัะࠦฬๆษ฼๎ࠥ࠳ࠠࠨ⏺")+l111l11lll_l1_,l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬ⏻"),542,l1l11l_l1_ (u"ࠧࠨ⏼"),l1l11l_l1_ (u"ࠨࠩ⏽"),l111l11lll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⏾"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⏿"),l1l11l_l1_ (u"ࠫࠬ␀"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ␁"),l1l11l_l1_ (u"࠭ๆหษษะࠥอไษฯฮࠤ๊็ีๅหࠣ࠱ࠥ࠭␂")+l111l11lll_l1_,l1l11l_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭␃"),542,l1l11l_l1_ (u"ࠨࠩ␄"),l1l11l_l1_ (u"ࠩࠪ␅"),l111l11lll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␆"),l1l11l_l1_ (u"๋ࠫะววฮࠣห้ฮอฬ่ࠢๆุ๋ษࠡ࠯ࠣࠫ␇")+l111l11lll_l1_,l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫ␈"),542,l1l11l_l1_ (u"࠭ࠧ␉"),l1l11l_l1_ (u"ࠧࠨ␊"),l111l11lll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␋"),l1l11l_l1_ (u"ࠩหัะࠦๅ็ใิำࠥ࠳ࠠࠨ␌")+l111l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ␍"),541,l1l11l_l1_ (u"ࠫࠬ␎"),l1l11l_l1_ (u"ࠬ࠭␏"),l111l11lll_l1_)
	return
def l1lll1lll11_l1_(l1lllll11ll_l1_):
	l1lllll1l1l_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫ␐"),l1l11l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ␑"),l1lllll11ll_l1_)
	l1lllll1l11_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭␒"),l1l11l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ␓"),menu_name+l1lllll11ll_l1_)
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ␔"),l1lllll11ll_l1_)
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ␕"),menu_name+l1lllll11ll_l1_)
	old_value = l1lllll1l1l_l1_+l1lllll1l11_l1_
	if old_value: l1lllll11ll_l1_ = menu_name+l1lllll11ll_l1_
	WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ␖"),l1lllll11ll_l1_,old_value,l1llll11l11_l1_)
	return
def l1llll11111_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࠧ␗"),l1l11l_l1_ (u"ࠧࠨ␘"),l1l11l_l1_ (u"ࠨࠩ␙"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ␚"),l1l11l_l1_ (u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦใๅ็สฮࠥอไษฯฮࠤฬ๊ๅฯิ้อࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠦࠧࠧ␛"))
	if yes!=1: return
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ␜"))
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫ␝"))
	DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡉࡌࡐࡕࡈࡈࠬ␞"))
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ␟"),l1l11l_l1_ (u"ࠨࠩ␠"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ␡"),l1l11l_l1_ (u"ࠪฮ๊ࠦศ็ฮสั๋ࠥำฮࠢฯ้๏฿ࠠไๆ่หฯࠦวๅสะฯࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ␢"))
	return
def l1llll111l1_l1_(search_org,action,site=l1l11l_l1_ (u"ࠫࠬ␣")):
	l1llll11l1l_l1_,l1llll11ll1_l1_,l1llll1l1ll_l1_,l1lll1l1l1l_l1_,l1lll1ll111_l1_,l1llll1l1l1_l1_,threads = [],[],[],{},{},{},{}
	if action==l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫ␤"): l1llll1l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫ␥"),l1l11l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ␦"),menu_name+search_org)
	elif action==l1l11l_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ␧"): l1llll1l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ␨"),l1l11l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩ␩"),search_org)
	elif action==l1l11l_l1_ (u"ࠫࡨࡲ࡯ࡴࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ␪"): l1llll1l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࠪ␫"),l1l11l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡉࡌࡐࡕࡈࡈࠬ␬"),[site,search_org])
	if not l1llll1l1ll_l1_:
		l1llll1llll_l1_ = l1l11l_l1_ (u"่ࠧาสࠤฬ๊ศฮอࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࡢ࡮ࠨ␭")
		l1lllll1111_l1_ = l1l11l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ว์ࠠศๆหัะࠦแ๋ࠢฯ้๏฿ࠠศๆ่์ฬู่ࠡ฻้ࠤࡡࡴࠠࠣ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤࠬ␮")+search_org+l1l11l_l1_ (u"ࠩࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠧࠦ࡜࡯ࠢ฼่๊อࠠฤ่๋ࠣีอࠠศๆหัะࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠫ␯")
		if action==l1l11l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡷ࡮ࡺࡥࡴࠩ␰"): message = l1lllll1111_l1_
		else: message = l1llll1llll_l1_+l1lllll1111_l1_
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࠬ␱"),l1l11l_l1_ (u"ࠬ࠭␲"),l1l11l_l1_ (u"࠭ࠧ␳"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ␴"),message)
		if yes!=1: return
		LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ␵"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡙ࠥࡥࡢࡴࡦ࡬ࠥࡌ࡯ࡳ࠼ࠣ࡟ࠥ࠭␶")+search_org+l1l11l_l1_ (u"ࠪࠤࡢ࠭␷"))
		#global menuItemsLIST
		import threading
		#l1llll1l111_l1_ = [l1l11l_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ␸"),l1l11l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ␹"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ␺")]
		l1llllll1l1_l1_ = 1
		for site in l1llll1l111_l1_:
			l1lll1l1l1l_l1_[site] = []
			options = l1l11l_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ␻")
			if l1l11l_l1_ (u"ࠨ࠯ࠪ␼") in site: options = options+l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࠧ␽")+site+l1l11l_l1_ (u"ࠪࡣࠬ␾")
			l1lll1lll1l_l1_,l1llll111ll_l1_,l1llllll11l_l1_ = l1lll1ll11l_l1_(site)
			if l1llllll1l1_l1_:
				threads[site] = threading.Thread(target=l1llll111ll_l1_,args=(search_org+options,))
				threads[site].start()
			else: l1llll111ll_l1_(search_org+options)
			DIALOG_NOTIFICATION(TRANSLATE(site),l1l11l_l1_ (u"ࠫࠬ␿"),time=1000)
		if l1llllll1l1_l1_:
			for site in l1llll1l111_l1_:
				threads[site].join(10)
		#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⑀"),l1l11l_l1_ (u"࠭ࠧ⑁"),l1l11l_l1_ (u"ࠧࡪࡶࡨࡱࡸࠦࡦࡰࡷࡱࡨࡪࡪ࠺ࠨ⑂"),str(len(menuItemsLIST)))
		for site in l1llll1l111_l1_:
			l1lll1lll1l_l1_,l1llll111ll_l1_,l1llllll11l_l1_ = l1lll1ll11l_l1_(site)
			for menuItem in menuItemsLIST:
				type,name,url,mode,image,page,text,context,infodict = menuItem
				if l1llllll11l_l1_ in name:
					if l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࠧ⑃") in site and 239>=mode>=230:
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ⑄")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⑅")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ⑆")]: continue
						if l1l11l_l1_ (u"ࠬ฻แฮหࠪ⑇") not in name:
							if   type==l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫ⑈"): site = l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ⑉")
							elif type==l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⑊"): site = l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⑋")
							elif type==l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⑌"): site = l1l11l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ⑍")
						else:
							if   l1l11l_l1_ (u"ࠬࡒࡉࡗࡇࠪ⑎") in url: site = l1l11l_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⑏")
							elif l1l11l_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧ⑐") in url: site = l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⑑")
							elif l1l11l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ⑒") in url: site = l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⑓")
					elif l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࠭⑔") in site and 149>=mode>=140:
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⑕")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⑖")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⑗")]: continue
						if l1l11l_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ⑘") in name or l1l11l_l1_ (u"ࠩ࠽࠾ࠥ࠭⑙") in name:
							continue
							#if   image==l1l11l_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ⑚"): site = l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⑛")
							#elif image==l1l11l_l1_ (u"ࠬࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⑜"): site = l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⑝")
							#else: site = l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⑞")
						else:
							if   mode==144 and l1l11l_l1_ (u"ࠨࡗࡖࡉࡗ࠭⑟") in name: site = l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ①")
							elif mode==144 and l1l11l_l1_ (u"ࠪࡇࡍࡔࡌࠨ②") in name: site = l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ③")
							elif mode==144 and l1l11l_l1_ (u"ࠬࡒࡉࡔࡖࠪ④") in name: site = l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⑤")
							elif mode==143: site = l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⑥")
							else: continue
					elif l1l11l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࠧ⑦") in site and 419>=mode>=400:
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⑧")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⑨")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ⑩")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ⑪")]: continue
						if   mode in [401,405]: site = l1l11l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ⑫")
						elif mode in [402,406]: site = l1l11l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⑬")
						elif mode in [403,404]: site = l1l11l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭⑭")
						elif mode in [412,413]: site = l1l11l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ⑮")
					elif l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࠪ⑯") in site and 39>=mode>=30:
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ⑰")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ⑱")]: continue
						if   mode in [32,39]: site = l1l11l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ⑲")
						elif mode in [33,39]: site = l1l11l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘ࠭⑳")
					elif l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࠨ⑴") in site and 29>=mode>=20:
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ⑵")]: continue
						if menuItem in l1lll1l1l1l_l1_[l1l11l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ⑶")]: continue
						if   l1l11l_l1_ (u"ࠫ࠴ࡧࡲ࠯ࠩ⑷") in url: site = l1l11l_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⑸")
						elif l1l11l_l1_ (u"࠭࠯ࡦࡰ࠱ࠫ⑹") in url: site = l1l11l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ⑺")
					#elif l1l11l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࠬ⑻") in site and 319>=mode>=310:
					#	if menuItem in l1lll1l1l1l_l1_[site]: continue
					#	if mode==312: site = l1lll1llll1_l1_+l1l11l_l1_ (u"ࠩ࠰ࡅ࡚ࡊࡉࡐࡕࠪ⑼")
					#	elif l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴ࠮ࠩ⑽") in url: site = l1lll1llll1_l1_+l1l11l_l1_ (u"ࠫ࠲ࡇࡌࡃࡗࡐࡗࠬ⑾")
					#	else: site = l1lll1llll1_l1_+l1l11l_l1_ (u"ࠬ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ⑿")
					l1lll1l1l1l_l1_[site].append(menuItem)
		menuItemsLIST[:] = []
		for site in list(l1lll1l1l1l_l1_.keys()):
			l1lll1ll111_l1_[site] = []
			l1llll1l1l1_l1_[site] = []
			for type,name,url,mode,image,page,text,context,infodict in l1lll1l1l1l_l1_[site]:
				menuItem = (type,name,url,mode,image,page,text,context,infodict)
				if l1l11l_l1_ (u"࠭ีโฯฬࠫ⒀") in name and type==l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒁"): l1llll1l1l1_l1_[site].append(menuItem)
				else: l1lll1ll111_l1_[site].append(menuItem)
		l1llll1ll1l_l1_ = [(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⒂"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⒃"),l1l11l_l1_ (u"ࠪࠫ⒄"),157,l1l11l_l1_ (u"ࠫࠬ⒅"),l1l11l_l1_ (u"ࠬ࠭⒆"),l1l11l_l1_ (u"࠭ࠧ⒇"),l1l11l_l1_ (u"ࠧࠨ⒈"),l1l11l_l1_ (u"ࠨࠩ⒉"))]
		for site in l1llll11lll_l1_:
			if site==l1lll1lllll_l1_[0]: l1llll1ll1l_l1_ = [(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⒊"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⒋"),l1l11l_l1_ (u"ࠫࠬ⒌"),157,l1l11l_l1_ (u"ࠬ࠭⒍"),l1l11l_l1_ (u"࠭ࠧ⒎"),l1l11l_l1_ (u"ࠧࠨ⒏"),l1l11l_l1_ (u"ࠨࠩ⒐"),l1l11l_l1_ (u"ࠩࠪ⒑"))]
			elif site==l1lllll1ll1_l1_[0]: l1llll1ll1l_l1_ = [(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⒒"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯูࠦศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⒓"),l1l11l_l1_ (u"ࠬ࠭⒔"),157,l1l11l_l1_ (u"࠭ࠧ⒕"),l1l11l_l1_ (u"ࠧࠨ⒖"),l1l11l_l1_ (u"ࠨࠩ⒗"),l1l11l_l1_ (u"ࠩࠪ⒘"),l1l11l_l1_ (u"ࠪࠫ⒙"))]
			elif site==l1lll1l1ll1_l1_[0]: l1llll1ll1l_l1_ = [(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⒚"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⒛"),l1l11l_l1_ (u"࠭ࠧ⒜"),157,l1l11l_l1_ (u"ࠧࠨ⒝"),l1l11l_l1_ (u"ࠨࠩ⒞"),l1l11l_l1_ (u"ࠩࠪ⒟"),l1l11l_l1_ (u"ࠪࠫ⒠"),l1l11l_l1_ (u"ࠫࠬ⒡"))]
			if site not in l1lll1ll111_l1_.keys(): continue
			if l1lll1ll111_l1_[site]:
				l1lll1ll1ll_l1_ = TRANSLATE(site)
				l1llll1111l_l1_ = [(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⒢"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃࠠࠨ⒣")+l1lll1ll1ll_l1_+l1l11l_l1_ (u"ࠧࠡ࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⒤"),l1l11l_l1_ (u"ࠨࠩ⒥"),9999,l1l11l_l1_ (u"ࠩࠪ⒦"),l1l11l_l1_ (u"ࠪࠫ⒧"),l1l11l_l1_ (u"ࠫࠬ⒨"),l1l11l_l1_ (u"ࠬ࠭⒩"),l1l11l_l1_ (u"࠭ࠧ⒪"))]
				if 0:
					l1lllll1lll_l1_ = search_org+l1l11l_l1_ (u"ࠧࠡ࠯ࠣࠫ⒫")+l1l11l_l1_ (u"ࠨสะฯࠬ⒬")+l1l11l_l1_ (u"ࠩࠣࠫ⒭")+l1lll1ll1ll_l1_
				else:
					l1lllll1lll_l1_ = l1l11l_l1_ (u"ࠪฬาัࠧ⒮")+l1l11l_l1_ (u"ࠫࠥ࠭⒯")+l1lll1ll1ll_l1_+l1l11l_l1_ (u"ࠬࠦ࠭ࠡࠩ⒰")+search_org
				if len(l1lll1ll111_l1_[site])<8: l1llll1ll11_l1_ = []
				else:
					l1llllll111_l1_ = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ⒱")+l1lllll1lll_l1_+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⒲")
					l1llll1ll11_l1_ = [(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒳"),menu_name+l1llllll111_l1_,l1l11l_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⒴"),542,l1l11l_l1_ (u"ࠪࠫ⒵"),site,search_org,l1l11l_l1_ (u"ࠫࠬⒶ"),l1l11l_l1_ (u"ࠬ࠭Ⓑ"))]
				l1lllll111l_l1_ = l1lll1ll111_l1_[site]+l1llll1l1l1_l1_[site]
				l1llll11ll1_l1_ += l1llll1ll1l_l1_+l1llll1111l_l1_+l1lllll111l_l1_[:7]+l1llll1ll11_l1_
				l1lll1ll1l1_l1_ = [(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓒ"),menu_name+l1lllll1lll_l1_,l1l11l_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ⓓ"),542,l1l11l_l1_ (u"ࠨࠩⒺ"),site,search_org,l1l11l_l1_ (u"ࠩࠪⒻ"),l1l11l_l1_ (u"ࠪࠫⒼ"))]
				l1llll11l1l_l1_ += l1llll1ll1l_l1_+l1lll1ll1l1_l1_
				l1llll1ll1l_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪⒽ"),[site,search_org],l1lllll111l_l1_,l1llll11l11_l1_)
		WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫⒾ"),search_org,l1llll11ll1_l1_,l1llll11l11_l1_)
		DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⒿ"),search_org)
		WRITE_TO_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬⓀ"),menu_name+search_org,l1llll11l1l_l1_,l1llll11l11_l1_)
		DIALOG_OK(l1l11l_l1_ (u"ࠨࠩⓁ"),l1l11l_l1_ (u"ࠩࠪⓂ"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ⓝ"),l1l11l_l1_ (u"ࠫฬ๊ศฮอࠣห้าๅศ฻ํࠤฬ์ส่๋ࠣฬ๋าวฮࠢ࡟ࡲࡡࡴࠠห็ࠣฮำุ๊็ࠢส่๋ะววฮࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะ๊ࠥๅะหࠣฯ้อห๋่ࠣ๎ํ๋ࠠๅๅํࠤฯูสุ์฼ࠤฬู๊้ัฬࠤส๊๊่ษࠣฬิ๎ๆࠡ฻่่ࠥฮอฬࠢฯำ๏ีࠧⓄ"))
		if action==l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⓅ") and l1llll11l1l_l1_: l1llll1l1ll_l1_ = l1llll11l1l_l1_
		else: l1llll1l1ll_l1_ = l1llll11ll1_l1_
	if action!=l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬⓆ"):
		for type,name,url,mode,image,page,text,context,infodict in l1llll1l1ll_l1_:
			if action in [l1l11l_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ⓡ"),l1l11l_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⓈ")] and l1l11l_l1_ (u"ุࠩๅาฯࠧⓉ") in name and type==l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓊ"): continue
			addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return
def l1llll1lll1_l1_(search_org=l1l11l_l1_ (u"ࠫࠬⓋ")):
	search,options,showdialogs = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬⓌ"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪⓍ")+search+l1l11l_l1_ (u"ࠧࠡ࡟ࠪⓎ"))
	l1l1ll_l1_ = search+options
	if 0:
		l1lllll11l1_l1_,l111l11lll_l1_ = search+l1l11l_l1_ (u"ࠨࠢ࠰ࠤࠬⓏ"),l1l11l_l1_ (u"ࠩࠪⓐ")
	else:
		l1lllll11l1_l1_,l111l11lll_l1_ = l1l11l_l1_ (u"ࠪࠫⓑ"),l1l11l_l1_ (u"ࠫࠥ࠳ࠠࠨⓒ")+search
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⓓ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⓔ"),l1l11l_l1_ (u"ࠧࠨⓕ"),157)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓖ"),l1l11l_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨⓗ")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠࡊࡒࡗ࡚ࠬⓘ")+l111l11lll_l1_,l1l11l_l1_ (u"ࠫࠬⓙ"),239,l1l11l_l1_ (u"ࠬ࠭ⓚ"),l1l11l_l1_ (u"࠭ࠧⓛ"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⓜ"),l1l11l_l1_ (u"ࠨࡡࡅࡏࡗࡥࠧⓝ")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤอ้ัศࠩⓞ")+l111l11lll_l1_,l1l11l_l1_ (u"ࠪࠫⓟ"),379,l1l11l_l1_ (u"ࠫࠬⓠ"),l1l11l_l1_ (u"ࠬ࠭ⓡ"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⓢ"),l1l11l_l1_ (u"ࠧࡠࡍࡏࡅࡤ࠭ⓣ")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ็้ࠦวๅ฻ิฬࠬⓤ")+l111l11lll_l1_,l1l11l_l1_ (u"ࠩࠪⓥ"),19,l1l11l_l1_ (u"ࠪࠫⓦ"),l1l11l_l1_ (u"ࠫࠬⓧ"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⓨ"),l1l11l_l1_ (u"࠭࡟ࡌࡔࡅࡣࠬⓩ")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ⓪")+l111l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ⓫"),329,l1l11l_l1_ (u"ࠩࠪ⓬"),l1l11l_l1_ (u"ࠪࠫ⓭"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⓮"),l1l11l_l1_ (u"ࠬࡥࡆࡉ࠳ࡢࠫ⓯")+l1lllll11l1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใสู้ࠦวๅล๋่ࠬ⓰")+l111l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ⓱"),579,l1l11l_l1_ (u"ࠨࠩ⓲"),l1l11l_l1_ (u"ࠩࠪ⓳"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⓴"),l1l11l_l1_ (u"ࠫࡤࡋࡇࡃࡡࠪ⓵")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠪ⓶")+l111l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ⓷"),129,l1l11l_l1_ (u"ࠧࠨ⓸"),l1l11l_l1_ (u"ࠨࠩ⓹"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⓺"),l1l11l_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ⓻")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠫࠥࠦศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧ⓼")+l111l11lll_l1_+l1l11l_l1_ (u"ࠬࠦࠠࠨ⓽"),l1l11l_l1_ (u"࠭ࠧ⓾"),29,l1l11l_l1_ (u"ࠧࠨ⓿"),l1l11l_l1_ (u"ࠨࠩ─"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ━"),l1l11l_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩ│")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬ┃")+l111l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭┄"),249,l1l11l_l1_ (u"࠭ࠧ┅"),l1l11l_l1_ (u"ࠧࠨ┆"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┇"),l1l11l_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ┈")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧ┉")+l111l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ┊"),59,l1l11l_l1_ (u"ࠬ࠭┋"),l1l11l_l1_ (u"࠭ࠧ┌"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┍"),l1l11l_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧ┎")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬ┏")+l111l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ┐"),69,l1l11l_l1_ (u"ࠫࠬ┑"),l1l11l_l1_ (u"ࠬ࠭┒"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┓"),l1l11l_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭└")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬฬ์๊หࠩ┕")+l111l11lll_l1_,l1l11l_l1_ (u"ࠩࠪ┖"),39,l1l11l_l1_ (u"ࠪࠫ┗"),l1l11l_l1_ (u"ࠫࠬ┘"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┙"),l1l11l_l1_ (u"࠭࡟ࡌ࡙ࡗࡣࠬ┚")+l111l11lll_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ┛"),l1l11l_l1_ (u"ࠨࠩ├"),139,l1l11l_l1_ (u"ࠩࠪ┝"),l1l11l_l1_ (u"ࠪࠫ┞"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┟"),l1l11l_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ┠")+l111l11lll_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡื๋ฮࠥอไี์฼อࠬ┡"),l1l11l_l1_ (u"ࠧࠨ┢"),319,l1l11l_l1_ (u"ࠨࠩ┣"),l1l11l_l1_ (u"ࠩࠪ┤"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┥"),l1l11l_l1_ (u"ࠫࡤࡓࡒࡇࠩ┦")+l111l11lll_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠใ่สอࠥอไๆ฻สีๆ࠭┧"),l1l11l_l1_ (u"࠭ࠧ┨"),49,l1l11l_l1_ (u"ࠧࠨ┩"),l1l11l_l1_ (u"ࠨࠩ┪"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┫"),l1l11l_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ┬")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫ┭"),l1l11l_l1_ (u"ࠬ࠭┮"),39,l1l11l_l1_ (u"࠭ࠧ┯"),l1l11l_l1_ (u"ࠧࠨ┰"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࡤ࠭┱"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┲"),l1l11l_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ┳")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭┴"),l1l11l_l1_ (u"ࠬ࠭┵"),39,l1l11l_l1_ (u"࠭ࠧ┶"),l1l11l_l1_ (u"ࠧࠨ┷"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭┸"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┹"),l1l11l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ┺")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ┻"),l1l11l_l1_ (u"ࠬ࠭┼"),149,l1l11l_l1_ (u"࠭ࠧ┽"),l1l11l_l1_ (u"ࠧࠨ┾"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨ┿"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╀"),l1l11l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ╁")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬ╂"),l1l11l_l1_ (u"ࠬ࠭╃"),149,l1l11l_l1_ (u"࠭ࠧ╄"),l1l11l_l1_ (u"ࠧࠨ╅"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫ╆"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╇"),l1l11l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ╈")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ╉"),l1l11l_l1_ (u"ࠬ࠭╊"),149,l1l11l_l1_ (u"࠭ࠧ╋"),l1l11l_l1_ (u"ࠧࠨ╌"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ╍"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╎"),l1l11l_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ╏")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪ═"),l1l11l_l1_ (u"ࠬ࠭║"),29,l1l11l_l1_ (u"࠭ࠧ╒"),l1l11l_l1_ (u"ࠧࠨ╓"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭╔"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╕"),l1l11l_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ╖")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭╗"),l1l11l_l1_ (u"ࠬ࠭╘"),29,l1l11l_l1_ (u"࠭ࠧ╙"),l1l11l_l1_ (u"ࠧࠨ╚"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍࡥࠧ╛"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╜"),l1l11l_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ╝")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫ╞"),l1l11l_l1_ (u"ࠬ࠭╟"),409,l1l11l_l1_ (u"࠭ࠧ╠"),l1l11l_l1_ (u"ࠧࠨ╡"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࡣࠬ╢"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╣"),l1l11l_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ╤")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨ╥"),l1l11l_l1_ (u"ࠬ࠭╦"),409,l1l11l_l1_ (u"࠭ࠧ╧"),l1l11l_l1_ (u"ࠧࠨ╨"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨ╩"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╪"),l1l11l_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ╫")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ๊ํอสࠨ╬"),l1l11l_l1_ (u"ࠬ࠭╭"),409,l1l11l_l1_ (u"࠭ࠧ╮"),l1l11l_l1_ (u"ࠧࠨ╯"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ╰"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╱"),l1l11l_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ╲")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨ╳"),l1l11l_l1_ (u"ࠬ࠭╴"),319,l1l11l_l1_ (u"࠭ࠧ╵"),l1l11l_l1_ (u"ࠧࠨ╶"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࡢࠫ╷"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╸"),l1l11l_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ╹")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊ห้ࠣั๊ฯࠨ╺"),l1l11l_l1_ (u"ࠬ࠭╻"),319,l1l11l_l1_ (u"࠭ࠧ╼"),l1l11l_l1_ (u"ࠧࠨ╽"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ╾"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╿"),l1l11l_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ▀")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪ▁"),l1l11l_l1_ (u"ࠬ࠭▂"),319,l1l11l_l1_ (u"࠭ࠧ▃"),l1l11l_l1_ (u"ࠧࠨ▄"),l1l1ll_l1_+l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ▅"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ▆"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ▇"),l1l11l_l1_ (u"ࠫࠬ█"),157)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▉"),l1l11l_l1_ (u"࠭࡟ࡇࡌࡖࡣࠬ▊")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠧࠡสะฯ๋่ࠥใ฻ࠣๅัืࠠี๊ࠪ▋")+l111l11lll_l1_+l1l11l_l1_ (u"ࠨࠢࠪ▌"),l1l11l_l1_ (u"ࠩࠪ▍"),399,l1l11l_l1_ (u"ࠪࠫ▎"),l1l11l_l1_ (u"ࠫࠬ▏"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▐"),l1l11l_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ░")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫ▒")+l111l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ▓"),469,l1l11l_l1_ (u"ࠩࠪ▔"),l1l11l_l1_ (u"ࠪࠫ▕"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▖"),l1l11l_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫ▗")+l1lllll11l1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๆ๋ำ๏ࠦๆหࠩ▘")+l111l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ▙"),459,l1l11l_l1_ (u"ࠨࠩ▚"),l1l11l_l1_ (u"ࠩࠪ▛"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▜"),l1l11l_l1_ (u"ࠫࡤࡉࡍࡏࡡࠪ▝")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ์ว้ࠩ▞")+l111l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ▟"),309,l1l11l_l1_ (u"ࠧࠨ■"),l1l11l_l1_ (u"ࠨࠩ□"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▢"),l1l11l_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ▣")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾่๋ࠦࠢึ๎๊อࠧ▤")+l111l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭▥"),569,l1l11l_l1_ (u"࠭ࠧ▦"),l1l11l_l1_ (u"ࠧࠨ▧"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▨"),l1l11l_l1_ (u"ࠩࡢࡗࡍࡔ࡟ࠨ▩")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨ▪")+l111l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ▫"),589,l1l11l_l1_ (u"ࠬ࠭▬"),l1l11l_l1_ (u"࠭ࠧ▭"),l1l1ll_l1_+l1l11l_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ▮"))
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▯"),l1l11l_l1_ (u"ࠩࡢࡑࡈࡓ࡟ࠨ▰")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧ▱")+l111l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ▲"),369,l1l11l_l1_ (u"ࠬ࠭△"),l1l11l_l1_ (u"࠭ࠧ▴"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▵"),l1l11l_l1_ (u"ࠨࡡࡖࡌࡕࡥࠧ▶")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แࠡสิ์ࠬ▷")+l111l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ▸"),489,l1l11l_l1_ (u"ࠫࠬ▹"),l1l11l_l1_ (u"ࠬ࠭►"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭▻"),l1l11l_l1_ (u"ࠧࡠࡃࡕࡗࡤ࠭▼")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ฽ึฮࠠิ์ํำࠬ▽")+l111l11lll_l1_,l1l11l_l1_ (u"ࠩࠪ▾"),259,l1l11l_l1_ (u"ࠪࠫ▿"),l1l11l_l1_ (u"ࠫࠬ◀"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◁"),l1l11l_l1_ (u"࠭࡟ࡄ࠶ࡘࡣࠬ◂")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭◃")+l111l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ◄"),429,l1l11l_l1_ (u"ࠩࠪ◅"),l1l11l_l1_ (u"ࠪࠫ◆"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◇"),l1l11l_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫ◈")+l1lllll11l1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦแ้ำํ์ࠬ◉")+l111l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ◊"),119,l1l11l_l1_ (u"ࠨࠩ○"),l1l11l_l1_ (u"ࠩࠪ◌"),l1l1ll_l1_+l1l11l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ◍"))
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◎"),l1l11l_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫ●")+l1lllll11l1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ◐")+l111l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ◑"),79,l1l11l_l1_ (u"ࠨࠩ◒"),l1l11l_l1_ (u"ࠩࠪ◓"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◔"),l1l11l_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ◕")+l111l11lll_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ◖"),l1l11l_l1_ (u"࠭ࠧ◗"),389,l1l11l_l1_ (u"ࠧࠨ◘"),l1l11l_l1_ (u"ࠨࠩ◙"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◚"),l1l11l_l1_ (u"ࠪࡣࡊࡍࡖࡠࠩ◛")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦล๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭◜"),l1l11l_l1_ (u"ࠬ࠭◝"),229,l1l11l_l1_ (u"࠭ࠧ◞"),l1l11l_l1_ (u"ࠧࠨ◟"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭◠"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ◡"),l1l11l_l1_ (u"ࠪࠫ◢"),157)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◣"),l1l11l_l1_ (u"ࠬࡥࡈࡍࡅࡢࠫ◤")+l1lllll11l1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่้ࠡ็หู๊ࠥๆษࠪ◥")+l111l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ◦"),89,l1l11l_l1_ (u"ࠨࠩ◧"),l1l11l_l1_ (u"ࠩࠪ◨"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◩"),l1l11l_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ◪")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩ◫")+l111l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ◬"),439,l1l11l_l1_ (u"ࠧࠨ◭"),l1l11l_l1_ (u"ࠨࠩ◮"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◯"),l1l11l_l1_ (u"ࠪࡣࡈࡓࡆࡠࠩ◰")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ◱")+l111l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭◲"),99,l1l11l_l1_ (u"࠭ࠧ◳"),l1l11l_l1_ (u"ࠧࠨ◴"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◵"),l1l11l_l1_ (u"ࠩࡢࡇࡒࡒ࡟ࠨ◶")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨ◷")+l111l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ◸"),479,l1l11l_l1_ (u"ࠬ࠭◹"),l1l11l_l1_ (u"࠭ࠧ◺"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◻"),l1l11l_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧ◼")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧ◽")+l111l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ◾"),559,l1l11l_l1_ (u"ࠫࠬ◿"),l1l11l_l1_ (u"ࠬ࠭☀"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☁"),l1l11l_l1_ (u"ࠧࡠࡈࡋ࠶ࡤ࠭☂")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨ☃")+l111l11lll_l1_,l1l11l_l1_ (u"ࠩࠪ☄"),599,l1l11l_l1_ (u"ࠪࠫ★"),l1l11l_l1_ (u"ࠫࠬ☆"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☇"),l1l11l_l1_ (u"࠭࡟ࡆࡉࡇࡣࠬ☈")+l111l11lll_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢศ๎ั๐ࠠะ์าࠫ☉"),l1l11l_l1_ (u"ࠨࠩ☊"),449,l1l11l_l1_ (u"ࠩࠪ☋"),l1l11l_l1_ (u"ࠪࠫ☌"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☍"),l1l11l_l1_ (u"ࠬࡥࡁࡌࡅࡢࠫ☎")+l111l11lll_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษๆ์ฬ๋ࠠไษ่ࠫ☏"),l1l11l_l1_ (u"ࠧࠨ☐"),359,l1l11l_l1_ (u"ࠨࠩ☑"),l1l11l_l1_ (u"ࠩࠪ☒"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☓"),l1l11l_l1_ (u"ࠫࡤࡉࡍࡄࡡࠪ☔")+l111l11lll_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠪ☕"),l1l11l_l1_ (u"࠭ࠧ☖"),499,l1l11l_l1_ (u"ࠧࠨ☗"),l1l11l_l1_ (u"ࠨࠩ☘"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☙"),l1l11l_l1_ (u"ࠪࡣࡆࡘࡌࡠࠩ☚")+l111l11lll_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ☛"),l1l11l_l1_ (u"ࠬ࠭☜"),209,l1l11l_l1_ (u"࠭ࠧ☝"),l1l11l_l1_ (u"ࠧࠨ☞"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☟"),l1l11l_l1_ (u"ࠩࡢࡌࡊࡒ࡟ࠨ☠")+l111l11lll_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ☡"),l1l11l_l1_ (u"ࠫࠬ☢"),99,l1l11l_l1_ (u"ࠬ࠭☣"),l1l11l_l1_ (u"࠭ࠧ☤"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☥"),l1l11l_l1_ (u"ࠨࡡࡖࡊ࡜ࡥࠧ☦")+search+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ั๋ีࠣๅํื้ࠠฬืࠫ☧"),l1l11l_l1_ (u"ࠪࠫ☨"),218,l1l11l_l1_ (u"ࠫࠬ☩"),l1l11l_l1_ (u"ࠬ࠭☪"),search) # 219
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☫"),l1l11l_l1_ (u"ࠧࡠࡏ࡙࡞ࡤ࠭☬")+search+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻้ࠣํ็๊ำࠢ็ห๋ีࠧ☭"),l1l11l_l1_ (u"ࠩࠪ☮"),188,l1l11l_l1_ (u"ࠪࠫ☯"),l1l11l_l1_ (u"ࠫࠬ☰"),search)# 189
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ☱"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ☲"),l1l11l_l1_ (u"ࠧࠨ☳"),157)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☴"),l1l11l_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ☵")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬ☶")+l111l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ☷"),149,l1l11l_l1_ (u"ࠬ࠭☸"),l1l11l_l1_ (u"࠭ࠧ☹"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☺"),l1l11l_l1_ (u"ࠨࡡࡇࡐࡒࡥࠧ☻")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧ☼")+l111l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ☽"),409,l1l11l_l1_ (u"ࠫࠬ☾"),l1l11l_l1_ (u"ࠬ࠭☿"),l1l1ll_l1_)
	return
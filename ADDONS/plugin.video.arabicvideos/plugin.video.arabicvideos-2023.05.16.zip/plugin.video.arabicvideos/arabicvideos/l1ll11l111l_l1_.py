# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡒࡋࡎࡖࡕࠪ⫲")
def MAIN(mode,url,text):
	if   mode==260: results = MENU()
	elif mode==261: results = l1ll111l1l1_l1_()
	elif mode==263: results = l1ll11ll11l_l1_()
	elif mode==264: results = l1ll11ll1ll_l1_()
	elif mode==265: results = l1ll11l1l11_l1_(text)
	elif mode==266: results = l1ll11ll1l1_l1_(text)
	elif mode==267: results = l1ll11111ll_l1_(True,True)
	elif mode==268: results = l1ll11111ll_l1_(True,False)
	elif mode==531: results = l1ll1l11111_l1_()
	else: results = False
	return results
def MENU():
	if kodi_version<18: addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⫳"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ๆะ่ࠥอไๆึส็้ࠦหษฬࠣ็ํี๊ࠡฯา๎ะࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⫴"),l1l11l_l1_ (u"ࠧࠨ⫵"),341)
	l1ll11111l1_l1_,l1ll11l1111_l1_ = False,False
	l1ll1111l11_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭⫶"))
	if l1ll1111l11_l1_==l1l11l_l1_ (u"ࠩࠪ⫷"): l1ll1111l11_l1_ = l1ll11111ll_l1_(False,True)
	if l1ll1111l11_l1_==l1l11l_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ⫸"): l1ll11111l1_l1_ = True
	elif l1ll1111l11_l1_==l1l11l_l1_ (u"ࠫࡓࡋࡗࠨ⫹"): l1ll11l1111_l1_ = True
	elif l1ll1111l11_l1_==l1l11l_l1_ (u"ࠬࡕࡌࡅࠩ⫺"): l1ll11l1111_l1_ = False
	else: return
	l1ll111l111_l1_ = l1ll11l1lll_l1_([l1l11l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ⫻"),l1l11l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ⫼")])
	#l1ll11111l1_l1_ = True
	if l1ll11111l1_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⫽"),l1l11l_l1_ (u"ࠩ࠴࠲ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⫾"),l1l11l_l1_ (u"ࠪࠫ⫿"),531)
		addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⬀"),l1l11l_l1_ (u"ࠬ࠸࠮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⬁"),l1l11l_l1_ (u"࠭ࠧ⬂"),531)
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⬃"),l1l11l_l1_ (u"ࠨ࠵࠱ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣศา่ส้ัูࠦๆษาࠤๆ๐็ࠡ็ื็้ฯ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⬄"),l1l11l_l1_ (u"ࠩࠪ⬅"),531)
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⬆"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠰ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠴ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⬇"),l1l11l_l1_ (u"ࠬ࠭⬈"),9990)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⬉"),l1l11l_l1_ (u"ࠧࠨ⬊"),str(l1ll11111l1_l1_),str(l1ll11l1111_l1_))
	if l1ll11111l1_l1_ or l1ll11l1111_l1_: addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⬋"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ้ี๊ไࠢิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⬌"),l1l11l_l1_ (u"ࠪࠫ⬍"),267)
	if l1ll11111l1_l1_ or l1ll111l111_l1_: addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⬎"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ๅัํ็ࠥะอะ์ฮࠤ๊์ࠠศๆ่ฬึ๋ฬ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⬏"),l1l11l_l1_ (u"࠭ࠧ⬐"),159)
	if l1ll11111l1_l1_ or l1ll111l111_l1_ or l1ll11l1111_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⬑"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠴ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠱࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⬒"),l1l11l_l1_ (u"ࠩࠪ⬓"),9990)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⬔"),l1l11l_l1_ (u"ࠫࡓࡵࠠࡂࡴࡤࡦ࡮ࡩࠧ⬕"),l1l11l_l1_ (u"ࠬ࠭⬖"),151)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⬗"),l1l11l_l1_ (u"ฺ่ࠧࠣห้หูๅษ้หฯ࠭⬘"),l1l11l_l1_ (u"ࠨࠩ⬙"),346)
	if not l1ll11111l1_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⬚"),l1l11l_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ⬛"),l1l11l_l1_ (u"ࠫࠬ⬜"),501)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⬝"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⬞"),l1l11l_l1_ (u"ࠧࠨ⬟"),9990)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⬠"),l1l11l_l1_ (u"่ࠩ์ุ๎ูสࠢสุ่๐ๆๆษࠪ⬡"),l1l11l_l1_ (u"ࠪࠫ⬢"),510)
		addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⬣"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⬤"),l1l11l_l1_ (u"࠭ࠧ⬥"),9990)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⬦"),l1l11l_l1_ (u"ࠨษ็ๅ๏ี๊้้สฮࠬ⬧"),l1l11l_l1_ (u"ࠩࠪ⬨"),165,l1l11l_l1_ (u"ࠪࠫ⬩"),l1l11l_l1_ (u"ࠫࠬ⬪"),l1l11l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭⬫"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⬬"),l1l11l_l1_ (u"ࠧๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧ⬭"),l1l11l_l1_ (u"ࠨࠩ⬮"),261)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⬯"),l1l11l_l1_ (u"ࠪๆฬฬๅสࠢส่็์่ศฬࠪ⬰"),l1l11l_l1_ (u"ࠫࠬ⬱"),100)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬲"),l1l11l_l1_ (u"࠭โศศ่อࠥอไฺึ๋หห๐ษࠨ⬳"),l1l11l_l1_ (u"ࠧࠨ⬴"),160)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⬵"),l1l11l_l1_ (u"ࠩหัะࠦศไๆࠣห้๋่ศไ฼ࠫ⬶"),l1l11l_l1_ (u"ࠪࠫ⬷"),540)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⬸"),l1l11l_l1_ (u"ࠬอไโ์า๎ํํวหࠢส่๊ำๅๅหࠪ⬹"),l1l11l_l1_ (u"࠭ࠧ⬺"),330)
		#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⬻"),l1l11l_l1_ (u"ࠨสะฯࠥ฿วะ์ࠣฬ่๊ࠠศๆ่์ฬู่ࠨ⬼"),l1l11l_l1_ (u"ࠩࠪ⬽"),262)
		#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⬾"),l1l11l_l1_ (u"ࠫอำหࠡฬ็ๆฬฬ๊ࠡสๆ่ࠥอไๆ๊สๆ฾࠭⬿"),l1l11l_l1_ (u"ࠬ࠭⭀"),268)
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⭁"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠶ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠳࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭂"),l1l11l_l1_ (u"ࠨࠩ⭃"),9990)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭄"),l1l11l_l1_ (u"ࠪๆฬฬๅสࠢสุฯืวไࠢࡌࡔ࡙࡜ࠧ⭅"),l1l11l_l1_ (u"ࠫࠬ⭆"),230)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭇"),l1l11l_l1_ (u"࠭โศศ่อࠥษโิษ่ࠤࡎࡖࡔࡗࠩ⭈"),l1l11l_l1_ (u"ࠧࠨ⭉"),165,l1l11l_l1_ (u"ࠨࠩ⭊"),l1l11l_l1_ (u"ࠩࠪ⭋"),l1l11l_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ⭌"))
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭍"),l1l11l_l1_ (u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠤ๊์๋๊ࠠอ๎ํฮࠧ⭎"),l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ⭏"),144)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⭐"),l1l11l_l1_ (u"ࠨ็๋ห็฿๋๊ࠠอ๎ํฮࠠๆ่ࠣห้ฮั็ษ่ะࠬ⭑"),l1l11l_l1_ (u"ࠩࠪ⭒"),290)
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⭓"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠴ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠸ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⭔"),l1l11l_l1_ (u"ࠬ࠭⭕"),9990)
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭖"),l1l11l_l1_ (u"ࠧใษษ้ฮࠦวๅ็ไฺ้ฯࠠ࠲ࠩ⭗"),l1l11l_l1_ (u"ࠨࠩ⭘"),270,l1l11l_l1_ (u"ࠩࠪ⭙"),l1l11l_l1_ (u"ࠪࠫ⭚"),l1l11l_l1_ (u"ࠫࠬ⭛"),l1l11l_l1_ (u"ࠬ࠷ࠧ⭜"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭝"),l1l11l_l1_ (u"ࠧใษษ้ฮࠦวๅ็ไฺ้ฯࠠ࠳ࠩ⭞"),l1l11l_l1_ (u"ࠨࠩ⭟"),270,l1l11l_l1_ (u"ࠩࠪ⭠"),l1l11l_l1_ (u"ࠪࠫ⭡"),l1l11l_l1_ (u"ࠫࠬ⭢"),l1l11l_l1_ (u"ࠬ࠸ࠧ⭣"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭤"),l1l11l_l1_ (u"ࠧใษษ้ฮࠦวๅ็ไฺ้ฯࠠ࠴ࠩ⭥"),l1l11l_l1_ (u"ࠨࠩ⭦"),270,l1l11l_l1_ (u"ࠩࠪ⭧"),l1l11l_l1_ (u"ࠪࠫ⭨"),l1l11l_l1_ (u"ࠫࠬ⭩"),l1l11l_l1_ (u"ࠬ࠹ࠧ⭪"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭫"),l1l11l_l1_ (u"ࠧใษษ้ฮࠦวๅ็ไฺ้ฯࠠ࠵ࠩ⭬"),l1l11l_l1_ (u"ࠨࠩ⭭"),270,l1l11l_l1_ (u"ࠩࠪ⭮"),l1l11l_l1_ (u"ࠪࠫ⭯"),l1l11l_l1_ (u"ࠫࠬ⭰"),l1l11l_l1_ (u"ࠬ࠺ࠧ⭱"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭲"),l1l11l_l1_ (u"ࠧใษษ้ฮࠦวๅ็ไฺ้ฯࠠ࠶ࠩ⭳"),l1l11l_l1_ (u"ࠨࠩ⭴"),270,l1l11l_l1_ (u"ࠩࠪ⭵"),l1l11l_l1_ (u"ࠪࠫ⭶"),l1l11l_l1_ (u"ࠫࠬ⭷"),l1l11l_l1_ (u"ࠬ࠻ࠧ⭸"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⭹"),l1l11l_l1_ (u"ࠧใษษ้ฮࠦยฯำࠣ࠹࠵ࠦแ๋ัํ์ࠬ⭺"),l1l11l_l1_ (u"ࠨࠩ⭻"),265,l1l11l_l1_ (u"ࠩࠪ⭼"),l1l11l_l1_ (u"ࠪࠫ⭽"),l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⭾"))
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭿"),l1l11l_l1_ (u"࠭โศศ่อࠥศฮาࠢ࠸࠴่ࠥๆศหࠪ⮀"),l1l11l_l1_ (u"ࠧࠨ⮁"),265,l1l11l_l1_ (u"ࠨࠩ⮂"),l1l11l_l1_ (u"ࠩࠪ⮃"),l1l11l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⮄"))
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⮅"),l1l11l_l1_ (u"่ࠬวว็ฬࠤวิัࠡ࠷࠳ࠤ๊าไะࠩ⮆"),l1l11l_l1_ (u"࠭ࠧ⮇"),265,l1l11l_l1_ (u"ࠧࠨ⮈"),l1l11l_l1_ (u"ࠨࠩ⮉"),l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮊"))
		#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮋"),l1l11l_l1_ (u"ࠫࡤࡋࡍࡅࡡࠪ⮌")+l1l11l_l1_ (u"่ࠬวว็ฬࠤๆำีࠡࡋࡓࡘ࡛ๆࠧ⮍"),l1l11l_l1_ (u"࠭ࠧ⮎"),9999,l1l11l_l1_ (u"ࠧࠨ⮏"),l1l11l_l1_ (u"ࠨࠩ⮐"),l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮑"))
		#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮒"),l1l11l_l1_ (u"ࠫࡤࡋࡍࡅࡡࠪ⮓")+l1l11l_l1_ (u"่ࠬวว็ฬࠤๆำีࠨ⮔"),l1l11l_l1_ (u"࠭ࠧ⮕"),9999,l1l11l_l1_ (u"ࠧࠨ⮖"),l1l11l_l1_ (u"ࠨࠩ⮗"),l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮘"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⮙"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠵ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠹ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⮚"),l1l11l_l1_ (u"ࠬ࠭⮛"),9990)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⮜"),l1l11l_l1_ (u"ࠧฦ฻็ห๋อสࠡอๅหๆ๐ษࠡวึ่ฬ๋๊สࠩ⮝"),l1l11l_l1_ (u"ࠨࠩ⮞"),505)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⮟"),l1l11l_l1_ (u"ࠪฮ็ื๊าࠢสืฯิฯศ็ࠣห้ฮั็ษ่ะࠬ⮠"),l1l11l_l1_ (u"ࠫࠬ⮡"),176)
	if l1ll11l1111_l1_: addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⮢"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ำึหห๊้ࠠลัฬฬืࠠๆ่ࠣห้๋ศา็ฯ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⮣"),l1l11l_l1_ (u"ࠧࠨ⮤"),267)
	else: addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⮥"),l1l11l_l1_ (u"ࠩิืฬฬไ๊ࠡฦาออัࠡ็้ࠤฬ๊ๅษำ่ะࠬ⮦"),l1l11l_l1_ (u"ࠪࠫ⮧"),268)
	if l1ll111l111_l1_: addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⮨"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆศูิอัࠡำๅ้ࠥ࠮ࠠࠨ⮩")+addon_version+l1l11l_l1_ (u"࠭ࠠࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⮪"),l1l11l_l1_ (u"ࠧࠨ⮫"),7)
	else: addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⮬"),l1l11l_l1_ (u"ࠩส่ส฻ฯศำࠣี็๋ࠠࠩࠢࠪ⮭")+addon_version+l1l11l_l1_ (u"ࠪࠤ࠮࠭⮮"),l1l11l_l1_ (u"ࠫࠬ⮯"),7)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⮰"),l1l11l_l1_ (u"࠭สใำํีࠥ฿ๆࠡฤัีࠥอไห฼ํ๎ึอสࠨ⮱"),l1l11l_l1_ (u"ࠧࠨ⮲"),199)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⮳"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠻ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠸࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⮴"),l1l11l_l1_ (u"ࠪࠫ⮵"),9990)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⮶"),l1l11l_l1_ (u"่ࠬวว็ฬࠤฬ๊รอ๊หอࠬ⮷"),l1l11l_l1_ (u"࠭ࠧ⮸"),263)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮹"),l1l11l_l1_ (u"ࠨไสส๊ฯࠠศๆัำ๊อสࠨ⮺"),l1l11l_l1_ (u"ࠩࠪ⮻"),264)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⮼"),l1l11l_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠫ⮽"),l1l11l_l1_ (u"ࠬ࠭⮾"),341)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⮿"),l1l11l_l1_ (u"ࠧศๆศ๊ัอาศฬࠣห้ษฮา๋ࠪ⯀"),l1l11l_l1_ (u"ࠨࠩ⯁"),348)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⯂"),l1l11l_l1_ (u"ࠪฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭⯃"),l1l11l_l1_ (u"ࠫࠬ⯄"),196)
	return
def l1ll111l1l1_l1_():
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯅"),l1l11l_l1_ (u"࠭ࠠࠡ࠳࠱ࠤࠥࡥࡔࡗ࠲ࡢࠫ⯆")+l1l11l_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠩ⯇"),l1l11l_l1_ (u"ࠨࠩ⯈"),100)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯉"),l1l11l_l1_ (u"ࠪࠤࠥ࠸࠮ࠡࠢࡢࡍࡕ࡚࡟ࠨ⯊")+l1l11l_l1_ (u"ࠫฬฺสาษๆࠤࡎࡖࡔࡗ่ࠢำๆ๎ูࠨ⯋"),l1l11l_l1_ (u"ࠬ࠭⯌"),230)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⯍"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ุ่ࠢฬ้ไࠡไ็๎้ฯ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⯎"),l1l11l_l1_ (u"ࠨࠩ⯏"),157)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯐"),l1l11l_l1_ (u"ࠪࡣࡇࡑࡒࡠࠩ⯑")+l1l11l_l1_ (u"๊ࠫ๎โฺࠢห็ึอࠧ⯒"),l1l11l_l1_ (u"ࠬ࠭⯓"),370)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯔"),l1l11l_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭⯕")+l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠬ⯖"),l1l11l_l1_ (u"ࠩࠪ⯗"),30)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯘"),l1l11l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ⯙")+l1l11l_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠪ⯚"),l1l11l_l1_ (u"࠭ࠧ⯛"),140)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯜"),l1l11l_l1_ (u"ࠨࡡࡎࡐࡆࡥࠧ⯝")+l1l11l_l1_ (u"่ࠩ์็฿ࠠไๆࠣห้฿ัษࠩ⯞"),l1l11l_l1_ (u"ࠪࠫ⯟"),10)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯠"),l1l11l_l1_ (u"ࠬࡥࡋࡓࡄࡢࠫ⯡")+l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩ⯢"),l1l11l_l1_ (u"ࠧࠨ⯣"),320)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯤"),l1l11l_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨ⯥")+l1l11l_l1_ (u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠬ⯦"),l1l11l_l1_ (u"ࠫࠬ⯧"),570)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯨"),l1l11l_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬ⯩")+l1l11l_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠨ⯪"),l1l11l_l1_ (u"ࠨࠩ⯫"),120) # 128
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯬"),l1l11l_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ⯭")+l1l11l_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠬ⯮"),l1l11l_l1_ (u"ࠬ࠭⯯"),400)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯰"),l1l11l_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭⯱")+l1l11l_l1_ (u"ࠨ้ࠢࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧ⯲"),l1l11l_l1_ (u"ࠩࠪ⯳"),20)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯴"),l1l11l_l1_ (u"ࠫࡤࡇࡋࡐࡡࠪ⯵")+l1l11l_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩ⯶"),l1l11l_l1_ (u"࠭ࠧ⯷"),70)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯸"),l1l11l_l1_ (u"ࠨࡡࡄࡏ࡜ࡥࠧ⯹") +l1l11l_l1_ (u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭⯺"),l1l11l_l1_ (u"ࠪࠫ⯻"),240)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯼"),l1l11l_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫ⯽")+l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ⯾"),l1l11l_l1_ (u"ࠧࠨ⯿"),40)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰀ"),l1l11l_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨⰁ")+l1l11l_l1_ (u"้ࠪํู่ࠡึ๋ๅ๋ࠥวไีࠪⰂ"),l1l11l_l1_ (u"ࠫࠬⰃ"),50)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰄ"),l1l11l_l1_ (u"࠭࡟ࡇࡖࡐࡣࠬⰅ")+l1l11l_l1_ (u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭Ⰶ"),l1l11l_l1_ (u"ࠨࠩⰇ"),60)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰈ"),l1l11l_l1_ (u"ࠪࡣࡐ࡝ࡔࡠࠩⰉ")+l1l11l_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧⰊ"),l1l11l_l1_ (u"ࠬ࠭Ⰻ"),130)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⰼ"),l1l11l_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭Ⰽ")+l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪⰎ"),l1l11l_l1_ (u"ࠩࠪⰏ"),310)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰐ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤํ฿วๆหࠣ࠱๋ࠥิศๅ็ࠤ่ั๊าห࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰑ"),l1l11l_l1_ (u"ࠬ࠭Ⱂ"),157)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱃ"),l1l11l_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭Ⱄ")+l1l11l_l1_ (u"ࠨ้ࠢࠣํู่ࠡใฯีฺ่ࠥࠨⰕ"),l1l11l_l1_ (u"ࠩࠪⰖ"),390)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰗ"),l1l11l_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪⰘ")+l1l11l_l1_ (u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬⰙ"),l1l11l_l1_ (u"࠭ࠧⰚ"),460)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⰛ"),l1l11l_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧⰜ")+l1l11l_l1_ (u"่ࠩ์็฿ࠠๅ๊า๎ࠥ์สࠨⰝ"),l1l11l_l1_ (u"ࠪࠫⰞ"),450)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰟ"),l1l11l_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫⰠ")+l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭Ⱑ"),l1l11l_l1_ (u"ࠧࠨⰢ"),300)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰣ"),l1l11l_l1_ (u"ࠩࡢ࡛ࡈࡓ࡟ࠨⰤ")+l1l11l_l1_ (u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠩⰥ"),l1l11l_l1_ (u"ࠫࠬⰦ"),560)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰧ"),l1l11l_l1_ (u"࠭࡟ࡔࡊࡑࡣࠬⰨ")+l1l11l_l1_ (u"ࠧๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨⰩ"),l1l11l_l1_ (u"ࠨࠩⰪ"),580)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰫ"),l1l11l_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩⰬ")+l1l11l_l1_ (u"๊ࠫ๎โฺ่ࠢห๏ࠦำ๋็สࠫⰭ"),l1l11l_l1_ (u"ࠬ࠭Ⱞ"),360)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱟ"),l1l11l_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭ⰰ")+l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧⰱ"),l1l11l_l1_ (u"ࠩࠪⰲ"),480)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰳ"),l1l11l_l1_ (u"ࠫࡤࡇࡒࡔࡡࠪⰴ")+l1l11l_l1_ (u"๋่ࠬใ฻ࠣ฽ึฮࠠิ์ํำࠬⰵ"),l1l11l_l1_ (u"࠭ࠧⰶ"),250)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⰷ"),l1l11l_l1_ (u"ࠨࡡࡆ࠸࡚ࡥࠧⰸ")+l1l11l_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็่า์๋ࠫⰹ"),l1l11l_l1_ (u"ࠪࠫⰺ"),420)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰻ"),l1l11l_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫⰼ")+l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨⰽ"),l1l11l_l1_ (u"ࠧࠨⰾ"),110)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰿ"),l1l11l_l1_ (u"ࠩࡢࡑ࠹࡛࡟ࠨⱀ")+l1l11l_l1_ (u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬⱁ"),l1l11l_l1_ (u"ࠫࠬⱂ"),380)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱃ"),l1l11l_l1_ (u"࠭࡟ࡆࡉ࡙ࡣࠬⱄ")+l1l11l_l1_ (u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬⱅ"),l1l11l_l1_ (u"ࠨࠩⱆ"),220)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⱇ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱๋ࠥิศๅ็ࠤ่ั๊าหࠣะิอ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⱈ"),l1l11l_l1_ (u"ࠫࠬⱉ"),157)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱊ"),l1l11l_l1_ (u"࠭࡟ࡉࡎࡆࡣࠬⱋ")+l1l11l_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧⱌ"),l1l11l_l1_ (u"ࠨࠩⱍ"),80)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱎ"),l1l11l_l1_ (u"ࠪࡣࡊࡍࡎࡠࠩⱏ")+l1l11l_l1_ (u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫⱐ"),l1l11l_l1_ (u"ࠬ࠭ⱑ"),430)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱒ"),l1l11l_l1_ (u"ࠧࡠࡅࡐࡊࡤ࠭ⱓ")+l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩⱔ"),l1l11l_l1_ (u"ࠩࠪⱕ"),90)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱖ"),l1l11l_l1_ (u"ࠫࡤࡉࡍࡍࡡࠪⱗ")+l1l11l_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ⱘ"),l1l11l_l1_ (u"࠭ࠧⱙ"),470)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱚ"),l1l11l_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧⱛ")+l1l11l_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪⱜ"),l1l11l_l1_ (u"ࠪࠫⱝ"),550)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱞ"),l1l11l_l1_ (u"ࠬࡥࡆࡉ࠴ࡢࠫⱟ")+l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩⱠ"),l1l11l_l1_ (u"ࠧࠨⱡ"),590)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱢ"),l1l11l_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨⱣ")+l1l11l_l1_ (u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪⱤ"),l1l11l_l1_ (u"ࠫࠬⱥ"),440)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱦ"),l1l11l_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬⱧ")+l1l11l_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨⱨ"),l1l11l_l1_ (u"ࠨࠩⱩ"),350)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱪ"),l1l11l_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩⱫ")+l1l11l_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬⱬ"),l1l11l_l1_ (u"ࠬ࠭Ɑ"),490)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ɱ"),l1l11l_l1_ (u"ࠧࡠࡃࡕࡐࡤ࠭Ɐ")+l1l11l_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩⱰ"),l1l11l_l1_ (u"ࠩࠪⱱ"),200)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱲ"),l1l11l_l1_ (u"ࠫࡤࡎࡅࡍࡡࠪⱳ")+l1l11l_l1_ (u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨⱴ"),l1l11l_l1_ (u"࠭ࠧⱵ"),90)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱶ"),l1l11l_l1_ (u"ࠨࡡࡖࡊ࡜ࡥࠧⱷ")+l1l11l_l1_ (u"่ࠩ์็฿ࠠิ์ิ๎ุࠦแ้ำࠣ์ฯฺࠧⱸ"),l1l11l_l1_ (u"ࠪࠫⱹ"),218)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱺ"),l1l11l_l1_ (u"ࠬࡥࡍࡗ࡜ࡢࠫⱻ")+l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤ๊๎แ๋ิ็ห๋ีࠠศ๊้่ฬ๐ๆࠨⱼ"),l1l11l_l1_ (u"ࠧࠨⱽ"),188) # 180
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱾ"),l1l11l_l1_ (u"ࠩࡢࡉࡌࡈ࡟ࠨⱿ")+l1l11l_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫⲀ"),l1l11l_l1_ (u"ࠫࠬⲁ"),120) # 128
	return
def l1ll11ll1ll_l1_():
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲂ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞โࠣࡔࡷࡵࡢ࡭ࡧࡰࡷࠥࠬࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࡵࠣࠤ็อฦๆหู้ࠣอใๅ๋ࠢวุฬไสࠢࠣ࠲࠶࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨⲃ"),l1l11l_l1_ (u"ࠧࠨⲄ"),264)
	#addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⲅ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࠦ࠲࠯ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⲆ")+l1l11l_l1_ (u"ࠪๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ั࠭ⲇ"),l1l11l_l1_ (u"ࠫࠬⲈ"),175)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⲉ"),l1l11l_l1_ (u"࠭ࡎࡰࠢࡄࡶࡦࡨࡩࡤࠢࡏࡩࡹࡺࡥࡳࡵࠣࠬࡴࡸࠠࡕࡧࡻࡸ࠮࠭Ⲋ"),l1l11l_l1_ (u"ࠧࠨⲋ"),151)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⲍ"),l1l11l_l1_ (u"ࠩศฬ้อฺࠡ฻้ࠤฺ๊ใๅหࠪⲍ"),l1l11l_l1_ (u"ࠪࠫⲎ"),2,l1l11l_l1_ (u"ࠫࠬⲏ"),l1l11l_l1_ (u"ࠬ࠭Ⲑ"),l1l11l_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩⲑ"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⲒ"),l1l11l_l1_ (u"ࠨำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬⲓ"),l1l11l_l1_ (u"ࠩࠪⲔ"),2,l1l11l_l1_ (u"ࠪࠫⲕ"),l1l11l_l1_ (u"ࠫࠬⲖ"),l1l11l_l1_ (u"ࠬ࠭ⲗ"))
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⲘ"),l1l11l_l1_ (u"ࠧฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤฬ๊อศๆํࠫⲙ"),l1l11l_l1_ (u"ࠨࠩⲚ"),2,l1l11l_l1_ (u"ࠩࠪⲛ"),l1l11l_l1_ (u"ࠪࠫⲜ"),l1l11l_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧⲝ"))
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⲞ"),l1l11l_l1_ (u"࠭ลาีสู่ࠥฬๅࠢส่สิืศรࠣห้่ฯ๋็ࠪⲟ"),l1l11l_l1_ (u"ࠧࠨⲠ"),2,l1l11l_l1_ (u"ࠨࠩⲡ"),l1l11l_l1_ (u"ࠩࠪⲢ"),l1l11l_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪⲣ"))
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⲤ"),l1l11l_l1_ (u"่ࠬัศรฬࠤุาไࠡษ็วำ฽วยࠢส่าอไ๋ࠩⲥ"),l1l11l_l1_ (u"࠭ࠧⲦ"),340,l1l11l_l1_ (u"ࠧࠨⲧ"),l1l11l_l1_ (u"ࠨࠩⲨ"),l1l11l_l1_ (u"ࠩࡢࡐࡔࡍࡆࡊࡎࡈࡣࠬⲩ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⲪ"),l1l11l_l1_ (u"ࠫ็ืวยหࠣืั๊ࠠศๆฦา฼อมࠡษ็ๆิ๐ๅࠨⲫ"),l1l11l_l1_ (u"ࠬ࠭Ⲭ"),340,l1l11l_l1_ (u"࠭ࠧⲭ"),l1l11l_l1_ (u"ࠧࠨⲮ"),l1l11l_l1_ (u"ࠨࡡࡏࡓࡌࡌࡉࡍࡇࡢࡓࡑࡊ࡟ࠨⲯ"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⲰ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⲱ"),l1l11l_l1_ (u"ࠫࠬⲲ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⲳ"),l1l11l_l1_ (u"࠭ล๋ไสๅࠥ๎สี฼ํ่ࠥอไไษืࠫⲴ"),l1l11l_l1_ (u"ࠧࠨⲵ"),345)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⲷ"),l1l11l_l1_ (u"ࠩส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥไษำ้ห๊าࠧⲷ"),l1l11l_l1_ (u"ࠪࠫⲸ"),507,l1l11l_l1_ (u"ࠫࠬⲹ"),l1l11l_l1_ (u"ࠬ࠭Ⲻ"),l1l11l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫⲻ"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⲼ"),l1l11l_l1_ (u"ࠨฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠪⲽ"),l1l11l_l1_ (u"ࠩࠪⲾ"),159)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⲿ"),l1l11l_l1_ (u"ࠫส๐โศใࠣ์ฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭Ⳁ"),l1l11l_l1_ (u"ࠬ࠭ⳁ"),343)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⳂ"),l1l11l_l1_ (u"ࠧฦ์ๅหๆ่ࠦหึ฽๎้ࠦสฯิํ๊ࠥอไใ๊สส๊࠭ⳃ"),l1l11l_l1_ (u"ࠨࠩⳄ"),508)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⳅ"),l1l11l_l1_ (u"ࠪๅา฻้ࠠวุ่ฬำࠠระิࠤฬ๊สฮัํฯฬะࠧⳆ"),l1l11l_l1_ (u"ࠫࠬⳇ"),7)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⳈ"),l1l11l_l1_ (u"࠭ส฻์ํี๋ࠥใศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭ⳉ"),l1l11l_l1_ (u"ࠧࠨⳊ"),332)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⳋ"),l1l11l_l1_ (u"ࠩศ๎็อแ๊ࠡอุ฿๐ไࠡีํีๆืวหࠢส่อื่ไีํࠫⳌ"),l1l11l_l1_ (u"ࠪࠫⳍ"),342)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⳎ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⳏ"),l1l11l_l1_ (u"࠭ࠧⳐ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⳑ"),l1l11l_l1_ (u"ࠨวุ่ฬำࠠๆะี๊ࠥ฿ๅศัࠪⳒ"),l1l11l_l1_ (u"ࠩࠪⳓ"),172)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⳔ"),l1l11l_l1_ (u"ࠫส฻ไศฯ้้ࠣ็ࠠศๆิืฬฬไࠨⳕ"),l1l11l_l1_ (u"ࠬ࠭Ⳗ"),349)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⳗ"),l1l11l_l1_ (u"ࠧฦื็หาࠦโ้ษษ้ࠥอไๆใู่ฮ࠭Ⳙ"),l1l11l_l1_ (u"ࠨࠩⳙ"),504)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⳚ"),l1l11l_l1_ (u"ࠪษฺ๊วฮࠢไ๎ิ๐่่ษอࠤࡲࡶࡤࠨⳛ"),l1l11l_l1_ (u"ࠫࠬⳜ"),173)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⳝ"),l1l11l_l1_ (u"࠭ลึๆสัࠥ็๊ะ์๋๋ฬะࠠࡳࡶࡰࡴࠬⳞ"),l1l11l_l1_ (u"ࠧࠨⳟ"),174)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⳡ"),l1l11l_l1_ (u"ࠩศู้ออࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠬⳡ"),l1l11l_l1_ (u"ࠪࠫⳢ"),502)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⳣ"),l1l11l_l1_ (u"ࠬหีๅษะࠤ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫⳤ"),l1l11l_l1_ (u"࠭ࠧ⳥"),503)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⳦"),l1l11l_l1_ (u"ࠨวุ่ฬำࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠨ⳧"),l1l11l_l1_ (u"ࠩࠪ⳨"),506)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⳩"),l1l11l_l1_ (u"ࠫๆำีࠡษอูฬ๊ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ⳪"),l1l11l_l1_ (u"ࠬ࠭Ⳬ"),4)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⳬ"),l1l11l_l1_ (u"ࠧฦื็หาࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็็ํี๊ࠨⳭ"),l1l11l_l1_ (u"ࠨࠩⳮ"),347)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⳯"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⳰"),l1l11l_l1_ (u"ࠫࠬ⳱"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⳲ"),l1l11l_l1_ (u"࠭ๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠩⳳ"),l1l11l_l1_ (u"ࠧࠨ⳴"),9)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⳵"),l1l11l_l1_ (u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ⳶"),l1l11l_l1_ (u"ࠪࠫ⳷"),344)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⳸"),l1l11l_l1_ (u"ࠬหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠪ⳹"),l1l11l_l1_ (u"࠭ࠧ⳺"),6)
	#addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⳻"),l1l11l_l1_ (u"ࠨว฼ำฬีวหࠢ࡜ࡳࡺࡺࡵࡣࡧࠪ⳼"),l1l11l_l1_ (u"ࠩࠪ⳽"),179)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⳾"),l1l11l_l1_ (u"ࠫส฿ฯศัสฮࠥ࡟࡯ࡶࡶࡸࡦࡪ࠳ࡄࡍࠩ⳿"),l1l11l_l1_ (u"ࠬ࠭ⴀ"),178)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⴁ"),l1l11l_l1_ (u"ࠧฦ฻าหิอสࠡࡔࡨࡷࡴࡲࡶࡦࡗࡕࡐࠬⴂ"),l1l11l_l1_ (u"ࠨࠩⴃ"),177)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⴄ"),l1l11l_l1_ (u"ࠪษ฾ีวะษอࠤࡎࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠢࡄࡨࡦࡶࡴࡪࡸࡨࠫⴅ"),l1l11l_l1_ (u"ࠫࠬⴆ"),5)
	return
def l1ll11ll11l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⴇ"),l1l11l_l1_ (u"࠭ࡎࡰࠢࡄࡶࡦࡨࡩࡤࠢࡏࡩࡹࡺࡥࡳࡵࠣࠬࡴࡸࠠࡕࡧࡻࡸ࠮࠭ⴈ"),l1l11l_l1_ (u"ࠧࠨⴉ"),151)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴊ"),l1l11l_l1_ (u"่ࠩหࠥํ่ࠡษไฺ้ࠦฬๅั่้ࠣฮั็ษ่ะࠬⴋ"),l1l11l_l1_ (u"ࠪࠫⴌ"),197)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⴍ"),l1l11l_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ั࠭ⴎ"),l1l11l_l1_ (u"࠭ࠧⴏ"),341)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⴐ"),l1l11l_l1_ (u"ࠨ็สࠤ์๎ࠠระิࠤส฻ฯศำ่่ࠣ๎ฯ๋๋่้ࠢฮั็ษ่ะࠬⴑ"),l1l11l_l1_ (u"ࠩࠪⴒ"),7)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⴓ"),l1l11l_l1_ (u"่ࠫ๐แ๋หࠣหุะฮะษ่ࠤฬ๊ๅโุ็อࠬⴔ"),l1l11l_l1_ (u"ࠬ࠭ⴕ"),150)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⴖ"),l1l11l_l1_ (u"ࠧไ์ไ๎ฮࠦๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠪⴗ"),l1l11l_l1_ (u"ࠨࠩⴘ"),170)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⴙ"),l1l11l_l1_ (u"ࠪ็๏็ࠠหฬุ่ࠥ๎สห๊สู้ࠦๅฺࠢส่๊ฮัๆฮࠪⴚ"),l1l11l_l1_ (u"ࠫࠬⴛ"),196)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⴜ"),l1l11l_l1_ (u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤํ้ๅࠡ฻่ี์ࠦศศๆหี๋อๅอࠩⴝ"),l1l11l_l1_ (u"ࠧࠨⴞ"),190)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴟ"),l1l11l_l1_ (u"ࠩ็้ฬึวࠡส฼ฺࠥอไา๊สฬ฼ࠦศุ์ษอࠬⴠ"),l1l11l_l1_ (u"ࠪࠫⴡ"),155)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⴢ"),l1l11l_l1_ (u"๊ࠬๅศาสࠤอ฿ึࠡษ็ีํอศุࠢ็หࠥะูๆๆࠪⴣ"),l1l11l_l1_ (u"࠭ࠧⴤ"),153)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⴥ"),l1l11l_l1_ (u"ࠨๆ่หีอࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠢ็หࠥะูๆๆࠪ⴦"),l1l11l_l1_ (u"ࠩࠪⴧ"),152)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⴨"),l1l11l_l1_ (u"้๋ࠫวัษࠣฬ฾฼ࠠศๆ่์ฬู่ࠡๆสࠤฯ฿ๅๅࠩ⴩"),l1l11l_l1_ (u"ࠬ࠭⴪"),195)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⴫"),l1l11l_l1_ (u"ࠧหฯำ๎ึ๊ࠦฯืุࠣ์อฯสࠢส่ฯฺแ๋ำࠪ⴬"),l1l11l_l1_ (u"ࠨࠩⴭ"),171)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⴮"),l1l11l_l1_ (u"่๊ࠪอะศࠢํ์ัีࠠิ์ิๅึอสࠡ็ฯ๋ํ๊ษࠨ⴯"),l1l11l_l1_ (u"ࠫࠬⴰ"),156)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⴱ"),l1l11l_l1_ (u"࠭วๅใํำ๏๎็ศฬ๊ࠣํ฿ࠠ࡮ࡲࡧࠤ้อࠠห฻่่ࠬⴲ"),l1l11l_l1_ (u"ࠧࠨⴳ"),194)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴴ"),l1l11l_l1_ (u"ࠩ็้ฬึวࠡๆสࠤ๋็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠩⴵ"),l1l11l_l1_ (u"ࠪࠫⴶ"),193)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⴷ"),l1l11l_l1_ (u"ࠬฮูืࠢส่ๆ๐ฯ๋๊๊หฯࠦศุ์ษอࠥ๎สใู฼ࠫⴸ"),l1l11l_l1_ (u"࠭ࠧⴹ"),158)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⴺ"),l1l11l_l1_ (u"ࠨๅํๅࠥะอๅࠢห๊ๆูใࠡ็ื็้ฯࠠๆฦๅฮ์࠭ⴻ"),l1l11l_l1_ (u"ࠩࠪⴼ"),192)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⴽ"),l1l11l_l1_ (u"่ࠫ๐แࠡฬึฮำีๅࠡษ็ี๏๋่ห่ࠢ฽้่ࠥะ์ࠪⴾ"),l1l11l_l1_ (u"ࠬ࠭ⴿ"),198)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⵀ"),l1l11l_l1_ (u"ࠧๆษ๋ࠣ๏ࠦวๅีํีๆืวหࠢส่฾อๅส๋ࠢห้ิวึหࠪⵁ"),l1l11l_l1_ (u"ࠨࠩⵂ"),157)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⵃ"),l1l11l_l1_ (u"้ࠪฬࠦๅฺ่์ࠤ์ึ็ࠡษ็฽้อๅศฬࠣฬฬ๊ศา่ส้ัࠦࠬࠨⵄ")+half_triangular_colon+l1l11l_l1_ (u"ࠫࡀ࠭ⵅ"),l1l11l_l1_ (u"ࠬ࠭ⵆ"),191)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⵇ"),l1l11l_l1_ (u"ࠧไ์ไࠤฯำไࠡ็ื็้ฯࠠฮฮหࠤอ฿ึࠡษ็้ํอโฺࠩⵈ"),l1l11l_l1_ (u"ࠨࠩⵉ"),195)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⵊ"),l1l11l_l1_ (u"ࠪว๏์ࠠๆ๊สๆ฾ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤฬ๊รอ่ห๎ฮ࠭ⵋ"),l1l11l_l1_ (u"ࠫࠬⵌ"),154)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⵍ"),l1l11l_l1_ (u"࠭โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠡࡆࡐࡇࡆ࠭ⵎ"),l1l11l_l1_ (u"ࠧࠨⵏ"),3)
	return
def l1ll11l1l11_l1_(type_,l1ll1111ll1_l1_=False):
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵐ"),l1l11l_l1_ (u"่ࠩืาࠦ็ั้ࠣห้่วว็ฬࠫⵑ"),l1l11l_l1_ (u"ࠪࠫⵒ"),266,l1l11l_l1_ (u"ࠫࠬⵓ"),l1l11l_l1_ (u"ࠬ࠭ⵔ"),type_)
	#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⵕ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⵖ"),l1l11l_l1_ (u"ࠨࠩⵗ"),9999)
	l11111ll1_l1_ = []
	if os.path.exists(l1ll111111l_l1_):
		l1ll11ll111_l1_ = open(l1ll111111l_l1_,l1l11l_l1_ (u"ࠩࡵࡦࠬⵘ")).read()
		if kodi_version>18.99: l1ll11ll111_l1_ = l1ll11ll111_l1_.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨⵙ"))
		l1ll111ll11_l1_ = EVAL(l1l11l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩⵚ"),l1ll11ll111_l1_)
		if type_ in list(l1ll111ll11_l1_.keys()):
			l11111ll1_l1_ = l1ll111ll11_l1_[type_]
			if not l1ll1111ll1_l1_:
				try:
					for type,name,url,mode,image,page,text,context,infodict in l11111ll1_l1_:
						addMenuItem(type,name,url,mode,image,page,text,context,infodict)
				except:
					#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ⵛ"),l1l11l_l1_ (u"࠭ࠧⵜ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪⵝ"),l1l11l_l1_ (u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡ็็ๅࠥศฮาࠢส่ๆ๐ฯ๋๊๊หฯ࠭ⵞ"),l1l11l_l1_ (u"ࠩ็็๏ࠦสหะ็ู๋ࠥๆࠡษ็ู้้ไสࠢสฺ฿฽ฺࠠๆ์ࠫⵟ"),l1l11l_l1_ (u"ู๊ࠪࠦอ้ࠡำ๋ࠥอไใษษ้ฮࠨࠧⵠ"))
					l1ll111ll11_l1_ = FIX_AND_GET_FILE_CONTENTS(l1ll111111l_l1_)
					l11111ll1_l1_ = l1ll111ll11_l1_[type_]
					for type,name,url,mode,image,page,text,context,infodict in l11111ll1_l1_:
						addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return len(l11111ll1_l1_)
def l1ll11ll1l1_l1_(type_):
	answer = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫⵡ"),l1l11l_l1_ (u"ࠬ࠭ⵢ"),l1l11l_l1_ (u"࠭ࠧⵣ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪⵤ"),l1l11l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤัฺ๋๊่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢลาึࠦ࠵࠱ࠢࠪⵥ")+TRANSLATE(type)+l1l11l_l1_ (u"ࠩࠣรࠦ࠭ⵦ"))
	if answer==1:
		if os.path.exists(l1ll111111l_l1_):
			l1ll11ll111_l1_ = open(l1ll111111l_l1_,l1l11l_l1_ (u"ࠪࡶࡧ࠭ⵧ")).read()
			if kodi_version>18.99: l1ll11ll111_l1_ = l1ll11ll111_l1_.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⵨"))
			l1ll11ll111_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ⵩"),l1ll11ll111_l1_)
			if type_ in list(l1ll11ll111_l1_.keys()):
				del l1ll11ll111_l1_[type_]
				l1ll11ll111_l1_ = str(l1ll11ll111_l1_)
				if kodi_version>18.99: l1ll11ll111_l1_ = l1ll11ll111_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⵪"))
				open(l1ll111111l_l1_,l1l11l_l1_ (u"ࠧࡸࡤࠪ⵫")).write(l1ll11ll111_l1_)
				DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⵬"),l1l11l_l1_ (u"ࠩࠪ⵭"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⵮"),l1l11l_l1_ (u"ࠫฯ๋ࠠๆีะࠤัฺ๋๊่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢลาึࠦ࠵࠱ࠢࠪⵯ")+TRANSLATE(type))
	l1ll11l1l11_l1_(type_)
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ⵰"),l1l11l_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ⵱"))
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ⵲"))
	return
def l1ll11111ll_l1_(showDialogs,l1ll1l111ll_l1_):
	l1ll111l11l_l1_,l1ll1111l1l_l1_,l1ll11l11ll_l1_ = l1l11l_l1_ (u"ࠨࠩ⵳"),l1l11l_l1_ (u"ࠩࠪ⵴"),l1l11l_l1_ (u"ࠪࠫ⵵")
	url = WEBSITES[l1l11l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ⵶")][3]
	l1ll11l1ll1_l1_ = l1ll1l1l11l_l1_(32)
	payload = {l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࠪ⵷"):l1ll11l1ll1_l1_,l1l11l_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ⵸"):addon_version}
	if not l1ll1l111ll_l1_: DELETE_FROM_SQL3(main_dbfile,l1l11l_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ⵹"),[l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭⵺"),url,payload,l1l11l_l1_ (u"ࠩࠪ⵻"),l1l11l_l1_ (u"ࠪࠫ⵼"),l1l11l_l1_ (u"ࠫࠬ⵽"),l1l11l_l1_ (u"ࠬࡓࡅࡏࡗࡖ࠱ࡘࡎࡏࡘࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨ⵾")])
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗ⵿ࠫ"),url,payload,l1l11l_l1_ (u"ࠧࠨⶀ"),l1l11l_l1_ (u"ࠨࠩⶁ"),l1l11l_l1_ (u"ࠩࠪⶂ"),l1l11l_l1_ (u"ࠪࡑࡊࡔࡕࡔ࠯ࡖࡌࡔ࡝࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭ⶃ"),True,True)
	if not response.succeeded: l1ll1111l11_l1_ = l1l11l_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪⶄ")
	else:
		newfile = response.content
		if not newfile: newfile = l1l11l_l1_ (u"ࠬࠨࠢࠨⶅ")
		l1ll1111lll_l1_ = EVAL(l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫⶆ"),newfile)
		for l1ll111llll_l1_,l1ll1l111l1_l1_,message in l1ll1111lll_l1_:
			if kodi_version>18.99: message = message.encode(l1l11l_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬⶇ")).decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ⶈ"))
			if l1ll111llll_l1_==l1l11l_l1_ (u"ࠩ࠳ࠫⶉ"):
				l1ll111l11l_l1_ += message+l1l11l_l1_ (u"ࠪ࠾࠿࠭ⶊ")
				l1ll1111l1l_l1_ += l1l11l_l1_ (u"ࠫࡡࡸ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡶࡡࡴࠧⶋ")
			else: l1ll1111l1l_l1_ += message
		l1ll111l11l_l1_ = l1ll111l11l_l1_.strip(l1l11l_l1_ (u"ࠬࡀ࠺ࠨⶌ"))
		settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡸࡷࡪࡸ࠮ࡱࡴ࡬ࡺࡸ࠭ⶍ"),l1ll111l11l_l1_)
		settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨⶎ"),str(now))
		if os.path.exists(l1ll1l11l11_l1_): l1ll11l11ll_l1_ = open(l1ll1l11l11_l1_,l1l11l_l1_ (u"ࠨࡴࡥࠫⶏ")).read()
		l1ll1111l1l_l1_ = str(l1ll1111l1l_l1_.splitlines())
		if kodi_version>18.99: l1ll1111l1l_l1_ = l1ll1111l1l_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧⶐ"))
		if l1ll1111l1l_l1_==l1ll11l11ll_l1_: l1ll1111l11_l1_ = l1l11l_l1_ (u"ࠪࡓࡑࡊࠧⶑ")
		else:
			l1ll1111l11_l1_ = l1l11l_l1_ (u"ࠫࡓࡋࡗࠨⶒ")
			open(l1ll1l11l11_l1_,l1l11l_l1_ (u"ࠬࡽࡢࠨⶓ")).write(l1ll1111l1l_l1_)
		if showDialogs:
			l1ll1111l11_l1_ = l1l11l_l1_ (u"࠭ࡏࡍࡆࠪⶔ")
			l1ll1111lll_l1_ = sorted(l1ll1111lll_l1_,reverse=True,key=lambda key: int(key[0]))
			l1ll11l11l1_l1_ = l1l11l_l1_ (u"ࠧࠨⶕ")
			for l1ll111llll_l1_,l1ll1l111l1_l1_,message in l1ll1111lll_l1_:
				if kodi_version>18.99: message = message.encode(l1l11l_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ⶖ")).decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⶗"))
				if l1ll11l11l1_l1_: l1ll11l11l1_l1_ += l1l11l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ⶘")
				if l1ll111llll_l1_==l1l11l_l1_ (u"ࠫ࠵࠭⶙"): continue
				date = message.split(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ⶚"))[0]
				l111ll1l_l1_ = l1l11l_l1_ (u"࠭ࠧ⶛")
				if l1ll1l111l1_l1_:
					l111ll1l_l1_ = l1l11l_l1_ (u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫ⶜")
					if kodi_version>18.99: l111ll1l_l1_ = l111ll1l_l1_.encode(l1l11l_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭⶝")).decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⶞"))
				l1ll11l11l1_l1_ += message.replace(date,l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭⶟")+date+l111ll1l_l1_+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⶠ"))+l1l11l_l1_ (u"ࠬࡢ࡮ࠨⶡ")
			l1ll11l11l1_l1_ = escapeUNICODE(l1ll11l11l1_l1_)
			l1ll111l11_l1_(l1l11l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬⶢ"),l1l11l_l1_ (u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪⶣ"),l1ll11l11l1_l1_,l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩⶤ"))
			settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ⶥ"),l1l11l_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭ⶦ"))
			xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ⶧"))
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪⶨ"),l1ll1111l11_l1_)
	return l1ll1111l11_l1_
def l1ll11l1lll_l1_(l1ll111lll1_l1_):
	l11ll1111l_l1_ = l1ll11lllll_l1_()
	l1ll111l111_l1_ = False
	for addon_id in l1ll111lll1_l1_:
		if l1ll111l111_l1_: continue
		if addon_id not in list(l11ll1111l_l1_.keys()): continue
		l1ll11l1l1l_l1_ = l11ll1111l_l1_[addon_id]
		l1ll11lll1l_l1_,l1ll11llll1_l1_,l1ll1l1111l_l1_ = l1ll11l1l1l_l1_[0]
		l1ll1111111_l1_,l1ll111l1ll_l1_ = l1ll11lll11_l1_(addon_id)
		if not l1ll1111111_l1_: l1ll111l111_l1_ = True
		else:
			l1ll111ll1l_l1_ = l1ll11llll1_l1_>l1ll111l1ll_l1_
			if l1ll111ll1l_l1_: l1ll111l111_l1_ = True
	return l1ll111l111_l1_
def l1ll1l11111_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧⶩ"),l1l11l_l1_ (u"ࠧࠨⶪ"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⶫ"),l1l11l_l1_ (u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤ฾์ฯไุ่่๊ࠢษࠡๅห๎ึฯࠠ࠯࠰ࠣวอีรࠡสไัฺࠦวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠฮษ๋่ࠥะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอไๆึๆ่ฮูࠦ็ัๆࠤส๋วࠡสึฬอࠦวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠษีหฬࠥษๆࠡษ็ฬึ์วๆฮࠣ฽๋ีใࠡไา๎๊ࠦ࠮࠯ࠢฦ์ࠥฮำษสࠣว๋ࠦวๅ็หี๊าࠠใษ่ࠤอห๊ใษไࠤฬ๊ศา่ส้ัูࠦๅ๋ࠣะ์อาไࠢ࠱࠲ࠥษ่ࠡสึฬอࠦว็ๅ่ࠣฬࠦสิฬัำ๊ࠦศา่ส้ัูࠦๆษาࠤฬ๊รึๆํࠤ࠳࠴ࠠๅ็฼ีๆฯࠠศๆุ่่๊ษࠡสส่฻ฮืࠡษ้ฮࠥฮอศฮฬࠤส๊้ࠡวิืฬ๊ࠠาไ่ࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ำศ฻า็ࠥ็๊ࠡฯ็ࠤฺ๊ใๅหࠣะ์อาไ๊ࠢิฬ࠭ⶬ"))
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
headers = { l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫੈ") : l1l11l_l1_ (u"ࠨࠩ੉") }
script_name = l1l11l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ੊")
menu_name = l1l11l_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩੋ")
l11lll_l1_ = WEBSITES[script_name][0]
#l1lll_l1_ = [l1l11l_l1_ (u"ࠫๆ๐ไๆࠩੌ"),l1l11l_l1_ (u"้ࠬไ๋ส੍ࠪ"),l1l11l_l1_ (u"࠭วๅ฻ิฺࠥอไศีห์฾๐ࠧ੎"),l1l11l_l1_ (u"ࠧๆีิั๏ฯࠧ੏"),l1l11l_l1_ (u"ࠨ็ึีา๐็ࠨ੐"),l1l11l_l1_ (u"ࠩส฾๋๐ษࠨੑ"),l1l11l_l1_ (u"ࠪห฾๊ว็ࠩ੒"),l1l11l_l1_ (u"้่ࠫวยࠩ੓")]
#proxy = l1l11l_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷࠵࠺࠰࠵࠴࠸࠴࠸࠸࠰࠴࠷࠵ࡀ࠳࠲࠴࠻ࠫ੔")
#proxy = l1l11l_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭੕")+l1ll111l_l1_[6][1]
proxy = l1l11l_l1_ (u"ࠧࠨ੖")
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨล็฽ฬฮࠧ੗"),l1l11l_l1_ (u"ࠩส่๊฻วา฻ฬࠤฬ๊อาหࠪ੘"),l1l11l_l1_ (u"ࠪห้่ัศ่ࠣห้้ั๋็ࠪਖ਼"),l1l11l_l1_ (u"ࠫฬ๊ใหสࠣ์ࠥอไศสะหะ࠭ਗ਼"),l1l11l_l1_ (u"ࠬอไึ๊ิࠤํࠦวๅะ็ๅ๏อสࠨਜ਼"),l1l11l_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่ฬึวฺ์ฬࠫੜ")]
def MAIN(mode,url,text):
	if   mode==240: results = MENU()
	elif mode==241: results = l111l1_l1_(url,text)
	elif mode==242: results = l111ll_l1_(url)
	elif mode==243: results = PLAY(url)
	elif mode==244: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ੝")+text)
	elif mode==245: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨਫ਼")+text)
	elif mode==246: results = l11l1ll_l1_(url)
	elif mode==247: results = l1ll1111_l1_(url)
	elif mode==248: results = l1l1l1l1_l1_()
	elif mode==249: results = SEARCH(text)
	else: results = False
	return results
def l1l1l1l1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ੟"),l1l11l_l1_ (u"ࠪࠫ੠"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ੡"),l1l11l_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢࠥว่๎วๆࠢส่ัี๊ะࠤࠣๅ๏ࠦศฺุࠣห้ษอ๋ษ้ࠤๆ๐็่๋ࠡ฽๋ࠥๆࠡษ็ััฮࠠืัࠣห้ฮัศ็ฯࠤ࠳่่ࠦาสࠤ๏ูศษุ่่๊ࠢษࠡใํࠤฯฺฺ๋ๆࠣห้็๊ะ์๋๋ฬะࠠ࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠิสห๋ฬࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋๋๋ࠢ๏ࠦสู้ิࠤํะฮหใํࠤอ฻่าหࠣ฽ู๎วว์ฬࠫ੢"))
	return
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ੣"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ੤"),headers,l1l11l_l1_ (u"ࠨࠩ੥"),l1l11l_l1_ (u"ࠩࠪ੦"),l1l11l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ੧"))
	html = response.content
	l1l1ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡵ࡭ࡦ࠯ࡶ࡭ࡹ࡫࠭ࡣࡶࡱ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੨"),html,re.DOTALL)
	if l1l1ll11_l1_: l1l1ll11_l1_ = l1l1ll11_l1_[0]
	else: l1l1ll11_l1_ = l11lll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ੩"),l1l1ll11_l1_,l1l11l_l1_ (u"࠭ࠧ੪"),headers,l1l11l_l1_ (u"ࠧࠨ੫"),l1l11l_l1_ (u"ࠨࠩ੬"),l1l11l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ੭"))
	html = response.content
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ੮"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ੯"),l1l11l_l1_ (u"ࠬ࠭ੰ"),249,l1l11l_l1_ (u"࠭ࠧੱ"),l1l11l_l1_ (u"ࠧࠨੲ"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬੳ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩੴ"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ੵ"),l11lll_l1_,246)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ੶"),menu_name+l1l11l_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ੷"),l11lll_l1_,247)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ੸"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ੹"),l1l11l_l1_ (u"ࠨࠩ੺"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੻"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ੼")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ੽"),l1l1ll11_l1_,241,l1l11l_l1_ (u"ࠬ࠭੾"),l1l11l_l1_ (u"࠭ࠧ੿"),l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ઀"))
	l1l11lll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡴࡨࡧࡪࡴࡴ࡭ࡻ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧઁ"),html,re.DOTALL)
	l1111l_l1_ = l1l11lll_l1_[0]
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩં"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬઃ")+menu_name+l1l11l_l1_ (u"ࠫศ฼๊โࠢะำ๏ัวࠨ઄"),l1111l_l1_,241)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪઅ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭આ"),l1l11l_l1_ (u"ࠧࠨઇ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡯ࡥ࠱࠹ࠦࡤ࠮ࡨ࡯ࡩࡽࠦࡡ࡭࡫ࡪࡲ࠲࡯ࡴࡦ࡯ࡶ࠱ࡨ࡫࡮ࡵࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨࡪࡸ࠭࡭࡫ࡱ࡯ࠥࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨઈ"),html,re.DOTALL)
	for l1111l_l1_,name,block in l1ll111_l1_:
		if name in l1llll1_l1_: continue
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩઉ"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬઊ")+menu_name+name,l1111l_l1_,241)
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪઋ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title in l1llll1_l1_: continue
			title = name+l1l11l_l1_ (u"ࠬࠦࠧઌ")+title
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઍ"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ઎")+menu_name+title,l1111l_l1_,241)
	return
def l11l1ll_l1_(website=l1l11l_l1_ (u"ࠨࠩએ")):
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠩࠪઐ"),headers,l1l11l_l1_ (u"ࠪࠫઑ"),l1l11l_l1_ (u"ࠫࡆࡑࡗࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ઒"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽ࡰࡤࡺࠬઓ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ઔ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title not in l1llll1_l1_:
				title = title+l1l11l_l1_ (u"ࠧࠡ็ุ๊ๆฯࠧક")
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨખ"),menu_name+title,l1111l_l1_,245)
		if website==l1l11l_l1_ (u"ࠩࠪગ"): addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨઘ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫઙ"),l1l11l_l1_ (u"ࠬ࠭ચ"),9999)
	return html
def l1ll1111_l1_(website=l1l11l_l1_ (u"࠭ࠧછ")):
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠧࠨજ"),headers,l1l11l_l1_ (u"ࠨࠩઝ"),l1l11l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪઞ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࡮ࡢࡸࠪટ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫઠ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title not in l1llll1_l1_:
				title = title+l1l11l_l1_ (u"ࠬࠦๅโๆอีฮ࠭ડ")
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઢ"),menu_name+title,l1111l_l1_,244)
		if website==l1l11l_l1_ (u"ࠧࠨણ"): addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ત"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩથ"),l1l11l_l1_ (u"ࠪࠫદ"),9999)
	return html
def l111l1_l1_(url,type=l1l11l_l1_ (u"ࠫࠬધ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ન"),l1l11l_l1_ (u"࠭ࠧ઩"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨપ"),headers,True,l1l11l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫફ"))
	if type==l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫબ"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡼ࡯ࡰࡦࡴ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡷࡼ࡯ࡰࡦࡴ࠰ࡦࡺࡺࡴࡰࡰ࠰ࡴࡷ࡫ࡶࠨભ"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡧࡱࡲࡸࡪࡸࠧમ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩય"),block,re.DOTALL)
		if not items:
			items = re.findall(l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬર"),block,re.DOTALL)
		for img,l1111l_l1_,title in items:
			#if l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ઱") in img: img = img.split(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦࠬલ"))[1]
			if l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫળ") in l1111l_l1_ or l1l11l_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡸࡵ࠲ࠫ઴") in l1111l_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫવ"),menu_name+title,l1111l_l1_,242,img)
			elif l1l11l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧશ") in l1111l_l1_:
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬષ"),menu_name+title,l1111l_l1_,243,img)
			elif l1l11l_l1_ (u"ࠧ࠰ࡩࡤࡱࡪࡹ࠯ࠨસ") not in l1111l_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧહ"),menu_name+title,l1111l_l1_,243,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ઺"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ઻"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title==l1l11l_l1_ (u"ࠫࠫࡲࡳࡢࡳࡸࡳࡀ઼࠭"): title = l1l11l_l1_ (u"ูࠬวษไฬࠫઽ")
			if title==l1l11l_l1_ (u"࠭ࠦࡳࡵࡤࡵࡺࡵ࠻ࠨા"): title = l1l11l_l1_ (u"ࠧๅษะๆฮ࠭િ")
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨી"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨુ")+title,l1111l_l1_,241)
	return
def SEARCH(search):
	# l11l11l_l1_://l1ll11l1_l1_.l111ll1_l1_/search?q=%l1ll11ll_l1_%l111lll_l1_%l1ll11ll_l1_%l11lll1_l1_%l1ll11ll_l1_%l1111ll_l1_
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠪࠫૂ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠫࠬૃ"): return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠬࠦࠧૄ"),l1l11l_l1_ (u"࠭ࠥ࠳࠲ࠪૅ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ૆")+l1l1ll_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩે"),l1l11l_l1_ (u"ࠩࠪૈ"),url,l1l11l_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࡢࡅࡐࡕࡁࡎࠩૉ"))
	results = l111l1_l1_(url)
	return
def l111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ૊"),l1l11l_l1_ (u"ࠬ࠭ો"),url,l1l11l_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࡠࡃࡎ࡛ࡆࡓࠧૌ"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨ્"),headers,True,l1l11l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭૎"))
	if l1l11l_l1_ (u"ࠩ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡄࠧ૏") not in html:
		img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡏࡣࡰࡰࠪૐ"))
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ૑"),menu_name+l1l11l_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫ૒"),url,243,img)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࡁࠬ࠳࠰࠿ࠪ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠳࠴ࠨ૓"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		l1l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૔"),block,re.DOTALL)
		for l1111l_l1_,title,img in l1l11l1_l1_:
			#if l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ૕") in l1111l_l1_: continue
			if l1l11l_l1_ (u"ࠩส่า๊โศฬࠪ૖") in title or l1l11l_l1_ (u"้ࠪํอำๆࠢสาึ๏ࠧ૗") in title: continue
			if l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭૘") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ૙"),menu_name+title,l1111l_l1_,242,img)
			else: addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ૚"),menu_name+title,l1111l_l1_,243,img)
	return
def PLAY(url):
	#l1l1l1l1_l1_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#open(l1l11l_l1_ (u"ࠧࡔ࠼࡟ࡠࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ૛"), l1l11l_l1_ (u"ࠨࡹࠪ૜")).write(html)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠩࠪ૝"),headers,True,l1l11l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ૞"))
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡧࡧࡤࡨࡧ࠰ࡨࡦࡴࡧࡦࡴ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭૟"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	l1l1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧૠ"),html,re.DOTALL)
	#l1l1l1ll_l1_ = ([l1l11l_l1_ (u"࠭ࠧૡ"),l1l11l_l1_ (u"ࠧࠨૢ")],[l1l11l_l1_ (u"ࠨࠩૣ"),l1l11l_l1_ (u"ࠩࠪ૤")])
	l1ll1l1l_l1_,l1l1lll_l1_,l1l1l1_l1_,l1l1llll_l1_ = [],[],[],[]
	if l1l1l1ll_l1_:
		l11_l1_ = l1l11l_l1_ (u"ࠪࡱࡵ࠺ࠧ૥")
		for l1l1ll1l_l1_,l1l1l111_l1_ in l1l1l1ll_l1_:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠢࡴࡹࡦࡲࡩࡵࡻࠥࠤ࡮ࡪ࠽ࠣࠩ૦")+l1l1ll1l_l1_+l1l11l_l1_ (u"ࠬࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿࠰࡟ࡷ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ૧"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			l1l1l1_l1_.append(block)
			l1l1llll_l1_.append(l1l1l111_l1_)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡱࡶࡣ࡯࡭ࡹ࡯ࡥࡴࠪ࠱࠮ࡄ࠯࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭૨"),html,re.DOTALL)
		if not l1ll111_l1_:
			DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ૩"),l1l11l_l1_ (u"ࠨࠩ૪"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૫"),l1l11l_l1_ (u"่ࠪฬ๊้ࠦฮาࠤ๊๊แࠡใํำ๏๎ࠠโ์๋ࠣีอࠠศๆิหอ฽ࠧ૬"))
			return
		else:
			block,filename = l1ll111_l1_[0]
			l1lll1_l1_ = [l1l11l_l1_ (u"ࠫࡿ࡯ࡰࠨ૭"),l1l11l_l1_ (u"ࠬࡸࡡࡳࠩ૮"),l1l11l_l1_ (u"࠭ࡴࡹࡶࠪ૯"),l1l11l_l1_ (u"ࠧࡱࡦࡩࠫ૰"),l1l11l_l1_ (u"ࠨࡪࡷࡱࠬ૱"),l1l11l_l1_ (u"ࠩࡷࡥࡷ࠭૲"),l1l11l_l1_ (u"ࠪ࡭ࡸࡵࠧ૳"),l1l11l_l1_ (u"ࠫ࡭ࡺ࡭࡭ࠩ૴")]
			l11_l1_ = filename.rsplit(l1l11l_l1_ (u"ࠬ࠴ࠧ૵"),1)[1].strip(l1l11l_l1_ (u"࠭ࠠࠨ૶"))
			if l11_l1_ in l1lll1_l1_:
				DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ૷"),l1l11l_l1_ (u"ࠨࠩ૸"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬૹ"),l1l11l_l1_ (u"ࠪห้๋ไโࠢ็๎ุࠦแ๋ัํ์ࠥ๎ไศุࠢ์ฯ࠭ૺ"))
				return
		l1l1l1_l1_.append(block)
		l1l1llll_l1_.append(l1l11l_l1_ (u"ࠫࠬૻ"))
	for i in range(len(l1l1l1_l1_)):
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩࡤࡱࡱ࠱࠭࠴ࠪࡀࠫࠥࠫૼ"),l1l1l1_l1_[i],re.DOTALL)
		for l1111l_l1_,l1l1l11l_l1_ in l1l1lll1_l1_:
			if l1l11l_l1_ (u"࠭ࡴࡰࡴࡵࡩࡳࡺࠧ૽") in l1l1l11l_l1_: continue
			#elif l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽࠬ૾") in l1l1l11l_l1_: continue
			elif l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ૿") in l1l1l11l_l1_: type = l1l11l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ଀")
			elif l1l11l_l1_ (u"ࠪࡴࡱࡧࡹࠨଁ") in l1l1l11l_l1_: type = l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪଂ")
			else: type = l1l11l_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ଃ")
			#title = l1l1llll_l1_[i]+l1l11l_l1_ (u"࠭ࠠๆๆไࠤࠬ଄")+type
			#l1l1lll_l1_.append(title)
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࠪଅ")+type+l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭ଆ")+l1l1llll_l1_[i]+l1l11l_l1_ (u"ࠩࡢࡣࡦࡱࡷࡢ࡯ࠪଇ")
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪࡘࡊ࡙ࡔࠨଈ"),l1l1lll_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"࡙ࠫࡋࡓࡕࠩଉ"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫଊ"),url)
	return
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨଋ"),l1l11l_l1_ (u"ࠧࠨଌ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ଍"),l1l11l_l1_ (u"ࠩࠪ଎"),filter,url)
	l111111_l1_ = [l1l11l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࠫଏ"),l1l11l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ଐ"),l1l11l_l1_ (u"ࠬࡿࡥࡢࡴࠪ଑"),l1l11l_l1_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭଒")]
	if l1l11l_l1_ (u"ࠧࡀࠩଓ") in url: url = url.split(l1l11l_l1_ (u"ࠨࡁࠪଔ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭କ"),1)
	if filter==l1l11l_l1_ (u"ࠪࠫଖ"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠫࠬଗ"),l1l11l_l1_ (u"ࠬ࠭ଘ")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"࠭࡟ࡠࡡࠪଙ"))
	if type==l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫଚ"):
		if l111111_l1_[0]+l1l11l_l1_ (u"ࠨ࠿ࠪଛ") not in l1lllll1_l1_: category = l111111_l1_[0]
		for i in range(len(l111111_l1_[0:-1])):
			if l111111_l1_[i]+l1l11l_l1_ (u"ࠩࡀࠫଜ") in l1lllll1_l1_: category = l111111_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠪࠪࠬଝ")+category+l1l11l_l1_ (u"ࠫࡂ࠶ࠧଞ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠬࠬࠧଟ")+category+l1l11l_l1_ (u"࠭࠽࠱ࠩଠ")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠩଡ"))+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬଢ")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠩࠩࠫଣ"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠪࡥࡱࡲࠧତ"))
		url2 = url+l1l11l_l1_ (u"ࠫࡄ࠭ଥ")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ଦ"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨଧ"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠧࠨନ"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠨࡣ࡯ࡰࠬ଩"))
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠩࠪପ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠪࡃࠬଫ")+l1llll1l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫବ"),menu_name+l1l11l_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠧଭ"),url2,241,l1l11l_l1_ (u"࠭ࠧମ"),l1l11l_l1_ (u"ࠧ࠲ࠩଯ"))
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨର"),menu_name+l1l11l_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ଱")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩଲ"),url2,241,l1l11l_l1_ (u"ࠫࠬଳ"),l1l11l_l1_ (u"ࠬ࠷ࠧ଴"))
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫଵ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଶ"),l1l11l_l1_ (u"ࠨࠩଷ"),9999)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠩࠪସ"),headers,True,l1l11l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬହ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁ࡬࡯ࡳ࡯ࠣ࡭ࡩ࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫ଺"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠴ࠪࡀࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡲࡥࡤࡶࡁࠫ଻"),block,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"଼࠭ࠧ"),l1l11l_l1_ (u"ࠧࠨଽ"),l1l11l_l1_ (u"ࠨࠩା"),str(l1l1ll1_l1_))
	dict = {}
	for l1l111l_l1_,name,block in l1l1ll1_l1_:
		#name = name.replace(l1l11l_l1_ (u"ࠩ࠰࠱ࠬି"),l1l11l_l1_ (u"ࠪࠫୀ"))
		items = re.findall(l1l11l_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡁࠬ࠳࠰࠿ࠪ࠾ࠪୁ"),block,re.DOTALL)
		if l1l11l_l1_ (u"ࠬࡃࠧୂ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪୃ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l111111_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧୄ")+l1111l1_l1_)
				return
			else:
				if l1l111l_l1_==l111111_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୅"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠩ୆"),url2,241,l1l11l_l1_ (u"ࠪࠫେ"),l1l11l_l1_ (u"ࠫ࠶࠭ୈ"))
				else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୉"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾࠭୊"),url2,245,l1l11l_l1_ (u"ࠧࠨୋ"),l1l11l_l1_ (u"ࠨࠩୌ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕ୍ࠪ"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠪࠪࠬ୎")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠶ࠧ୏")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠬࠬࠧ୐")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽࠱ࠩ୑")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ୒")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୓"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠤࠬ୔")+name,url2,244,l1l11l_l1_ (u"ࠪࠫ୕"),l1l11l_l1_ (u"ࠫࠬୖ"),l1111l1_l1_)		# +l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧୗ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if option in l1llll1_l1_: continue
			if l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ୘") not in value: value = option
			else: value = re.findall(l1l11l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୙"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠨࠨࠪ୚")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࠫ୛")+option
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠪࠪࠬଡ଼")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠭ଢ଼")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ୞")+l11l111_l1_
			title = option+l1l11l_l1_ (u"࠭ࠠ࠻ࠢࠪୟ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠧ࠱ࠩୠ")]
			title = option+l1l11l_l1_ (u"ࠨࠢ࠽ࠤࠬୡ")+name
			if type==l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪୢ"): addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪୣ"),menu_name+title,url,244,l1l11l_l1_ (u"ࠫࠬ୤"),l1l11l_l1_ (u"ࠬ࠭୥"),l1l1111_l1_)		# +l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ୦"))
			elif type==l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ୧") and l111111_l1_[-2]+l1l11l_l1_ (u"ࠨ࠿ࠪ୨") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠩࡤࡰࡱ࠭୩"))
				url3 = url+l1l11l_l1_ (u"ࠪࡃࠬ୪")+l1lll1l1_l1_
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ୫"),menu_name+title,url3,241,l1l11l_l1_ (u"ࠬ࠭୬"),l1l11l_l1_ (u"࠭࠱ࠨ୭"))
			else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ୮"),menu_name+title,url,245,l1l11l_l1_ (u"ࠨࠩ୯"),l1l11l_l1_ (u"ࠩࠪ୰"),l1l1111_l1_)
	return
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫୱ"),l1l11l_l1_ (u"ࠫࠬ୲"),filters,l1l11l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭୳"))
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ୴")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ୵")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠨࡣ࡯ࡰࠬ୶")					all filters (l1lll111_l1_ l111l1l_l1_ filter)
	#filters = filters.replace(l1l11l_l1_ (u"ࠩࡀࠪࠬ୷"),l1l11l_l1_ (u"ࠪࡁ࠵ࠬࠧ୸"))
	filters = filters.strip(l1l11l_l1_ (u"ࠫࠫ࠭୹"))
	l1llllll_l1_ = {}
	if l1l11l_l1_ (u"ࠬࡃࠧ୺") in filters:
		items = filters.split(l1l11l_l1_ (u"࠭ࠦࠨ୻"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠧ࠾ࠩ୼"))
			l1llllll_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠨࠩ୽")
	l11ll1l_l1_ = [l1l11l_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࠪ୾"),l1l11l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ୿"),l1l11l_l1_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ஀"),l1l11l_l1_ (u"ࠬࡿࡥࡢࡴࠪ஁"),l1l11l_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨஂ"),l1l11l_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨஃ"),l1l11l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ஄")]
	for key in l11ll1l_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠩ࠳ࠫஅ")
		#if l1l11l_l1_ (u"ࠪࠩࠬஆ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭இ") and value!=l1l11l_l1_ (u"ࠬ࠶ࠧஈ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠠࠬࠢࠪஉ")+value
		elif mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪஊ") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪ஋"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠩࠫ஌")+key+l1l11l_l1_ (u"ࠪࡁࠬ஍")+value
		elif mode==l1l11l_l1_ (u"ࠫࡦࡲ࡬ࠨஎ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠧஏ")+key+l1l11l_l1_ (u"࠭࠽ࠨஐ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠡ࠭ࠣࠫ஑"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠪஒ"))
	#l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠩࡀ࠴ࠬஓ"),l1l11l_l1_ (u"ࠪࡁࠬஔ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬக"),l1l11l_l1_ (u"ࠬ࠭஖"),filters,l1l11l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧ஗"))
	return l11llll_l1_
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ䙁")
menu_name = l1l11l_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩ䙂")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠫอัࠠๆสสุึ࠭䙃")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l111l1_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l111ll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䙄"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ䙅"),l1l11l_l1_ (u"ࠧࠨ䙆"),l1l11l_l1_ (u"ࠨࠩ䙇"),l1l11l_l1_ (u"ࠩࠪ䙈"),l1l11l_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䙉"))
	html = response.content
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙊"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䙋"),l1l11l_l1_ (u"࠭ࠧ䙌"),469,l1l11l_l1_ (u"ࠧࠨ䙍"),l1l11l_l1_ (u"ࠨࠩ䙎"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䙏"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙐"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䙑")+menu_name+l1l11l_l1_ (u"ࠬษฮาࠢส่า๊โศฬࠪ䙒"),l11lll_l1_,461,l1l11l_l1_ (u"࠭ࠧ䙓"),l1l11l_l1_ (u"ࠧࠨ䙔"),l1l11l_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䙕"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䙖"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䙗"),l1l11l_l1_ (u"ࠫࠬ䙘"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨ࡭ࡦࡰࡸ࠱ࡧࡺ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ䙙"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ䙚"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#if l1111l_l1_==l1l11l_l1_ (u"ࠧࠤࠩ䙛"): continue
			if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䙜") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if title==l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ䙝"): title = l1l11l_l1_ (u"ࠪะิ๐ฯࠡฯ็ๆฬะࠠห์ไ๎ࠥ็ว็ࠩ䙞")
			if title in l1llll1_l1_: continue
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙟"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䙠")+menu_name+title,l1111l_l1_,461)
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡇࡱࡲࡸࡪࡸࡃࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䙡"),html,re.DOTALL)
	#if l1ll111_l1_:
	#	block = l1ll111_l1_[0]
	#	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭䙢"),block,re.DOTALL)
	#	for l1111l_l1_,title in items:
	#		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙣"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䙤")+menu_name+title,l1111l_l1_,461)
	return
def l111l1_l1_(url,l11l11111_l1_=l1l11l_l1_ (u"ࠪࠫ䙥")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䙦"),l1l11l_l1_ (u"ࠬ࠭䙧"),l11l11111_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䙨"),url,l1l11l_l1_ (u"ࠧࠨ䙩"),l1l11l_l1_ (u"ࠨࠩ䙪"),l1l11l_l1_ (u"ࠩࠪ䙫"),l1l11l_l1_ (u"ࠪࠫ䙬"),l1l11l_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䙭"))
	html = response.content
	if l11l11111_l1_!=l1l11l_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䙮"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠨ䙯"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧฤะิࠤฬ๊อๅไสฮ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ䙰"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䙱"),block,re.DOTALL)
		l1l1l11_l1_ = []
		l11111ll1_l1_ = [l1l11l_l1_ (u"ุ่ࠩฬํฯสࠩ䙲"),l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨ䙳"),l1l11l_l1_ (u"ࠫฬเๆ๋หࠪ䙴"),l1l11l_l1_ (u"้ࠬไ๋สࠪ䙵"),l1l11l_l1_ (u"࠭วฺๆส๊ࠬ䙶"),l1l11l_l1_ (u"่ࠧัสๅࠬ䙷"),l1l11l_l1_ (u"ࠨ็หหึอษࠨ䙸"),l1l11l_l1_ (u"ࠩ฼ี฻࠭䙹"),l1l11l_l1_ (u"้ࠪ์ืฬศ่ࠪ䙺"),l1l11l_l1_ (u"ࠫฬ๊ศ้็ࠪ䙻")]
		for l1111l_l1_,title,img in items:
			if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䙼") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = UNQUOTE(l1111l_l1_)	#.strip(l1l11l_l1_ (u"࠭࠯ࠨ䙽"))
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ䙾"),title,re.DOTALL)
			if any(value in title for value in l11111ll1_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䙿"),menu_name+title,l1111l_l1_,462,img)
			elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠩส่า๊โสࠩ䚀") in title:
				title = l1l11l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䚁") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䚂"),menu_name+title,l1111l_l1_,463,img)
					l1l1l11_l1_.append(title)
			else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䚃"),menu_name+title,l1111l_l1_,463,img)
	if l11l11111_l1_!=l1l11l_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䚄"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䚅"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䚆"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫ䚇"))
				if l1111l_l1_==l1l11l_l1_ (u"ࠥࠦ䚈"): continue
				if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䚉") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
				#title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"ࠬ࠭䚊"): addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䚋"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥ࠭䚌")+title,l1111l_l1_,461)
	return
def l111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䚍"),l1l11l_l1_ (u"ࠩࠪ䚎"),l1l11l_l1_ (u"ࠪࡉࡕࡏࡓࡐࡆࡈࡗࠬ䚏"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䚐"),url,l1l11l_l1_ (u"ࠬ࠭䚑"),l1l11l_l1_ (u"࠭ࠧ䚒"),l1l11l_l1_ (u"ࠧࠨ䚓"),l1l11l_l1_ (u"ࠨࠩ䚔"),l1l11l_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䚕"))
	html = response.content
	# l1l11l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦࠬ䚖"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䚗"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䚘") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䚙"),menu_name+title,l1111l_l1_,462,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䚚"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䚛"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫ䚜"))
			if l1111l_l1_==l1l11l_l1_ (u"ࠥࠦ䚝"): continue
			if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䚞") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			#title = unescapeHTML(title)
			if title!=l1l11l_l1_ (u"ࠬ࠭䚟"): addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䚠"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥ࠭䚡")+title,l1111l_l1_,463)
	return
def PLAY(url):
	l1ll1l1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䚢"),url,l1l11l_l1_ (u"ࠩࠪ䚣"),l1l11l_l1_ (u"ࠪࠫ䚤"),l1l11l_l1_ (u"ࠫࠬ䚥"),l1l11l_l1_ (u"ࠬ࠭䚦"),l1l11l_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䚧"))
	html = response.content
	# l1l11111l_l1_ l1111l_l1_
	l11lll111l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡕࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䚨"),html,re.DOTALL)
	if l11lll111l_l1_:
		l11lll111l_l1_ = l11lll111l_l1_[0]
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䚩") not in l11lll111l_l1_:
			if l1l11l_l1_ (u"ࠩ࠲࠳ࠬ䚪") in l11lll111l_l1_: l11lll111l_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䚫")+l11lll111l_l1_
			else: l11lll111l_l1_ = l11lll_l1_+l11lll111l_l1_
		l11lll111l_l1_ = l11lll111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ䚬")
		l1ll1l1l_l1_.append(l11lll111l_l1_)
	# l1l1l1111_l1_ l1l1lll1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡨ࠱࠶࠼ࡥࡩ࡫ࡵࡲࡦࠪ࠱࠮ࡄ࠯ࡳ࡮ࡣ࡯ࡰ࠳࠰࠿ࠣࡘ࡬ࡨࡪࡵࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡐ࡭ࡣࡼࠦࠬ䚭"),html,re.DOTALL)
	if l1ll111_l1_:
		l1l1l1l11ll1_l1_,l1l1l1l11lll_l1_ = l1ll111_l1_[0]
		names = re.findall(l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䚮"),l1l1l1l11ll1_l1_,re.DOTALL)
		l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠢࡴࡧࡷ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ䚯"),l1l1l1l11lll_l1_,re.DOTALL)
		l1l1l1l11l1l_l1_ = zip(names,l1l1lll1_l1_)
		for name,l1lll1lll11l_l1_ in l1l1l1l11l1l_l1_:
			l1lll1lll11l_l1_ = l1lll1lll11l_l1_[2:]
			if kodi_version<19: l1lll1lll11l_l1_ = l1lll1lll11l_l1_.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䚰"))
			l1lll1lll11l_l1_ = base64.b64decode(l1lll1lll11l_l1_)
			if kodi_version>18.99: l1lll1lll11l_l1_ = l1lll1lll11l_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䚱"))
			l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䚲"),l1lll1lll11l_l1_,re.DOTALL)
			l1111l_l1_ = l1111l_l1_[0]
		if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䚳") not in l1111l_l1_:
			if l1l11l_l1_ (u"ࠬ࠵࠯ࠨ䚴") in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䚵")+l1111l_l1_
			else: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䚶")+name+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䚷")
			l1ll1l1l_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ䚸"),l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䚹"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l1l11l_l1_ (u"ࠫࠥ࠭䚺") in search:
		if showdialogs: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䚻"),l1l11l_l1_ (u"࠭ࠧ䚼"),l1l11l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓࠦๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭䚽"),l1l11l_l1_ (u"ࠨๆ็วุ็ࠠศๆหัะࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศࠢํ฽ฺ๊๊่ࠠาࠤ฼๊ศࠡลๆฯึࠦๅ็ࠢๆ่๊ฯ้ࠠษะำฮࠦ࠮࠯࠰ࠣ๎ึา้ࠡษ็ฬาัฺ่ࠠࠣ็้๋ษ๊ࠡสัิฯࠠโไฺࠫ䚾"))
		return
	#search = search.replace(l1l11l_l1_ (u"ࠩࠣࠫ䚿"),l1l11l_l1_ (u"ࠪ࠱ࠬ䛀"))
	#url = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ䛁")+search
	url = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡱ࠰ࠩ䛂")+search+l1l11l_l1_ (u"࠭࠯ࠨ䛃")
	l111l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ㰐")
headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㰑") : l1l11l_l1_ (u"࠭ࠧ㰒") }
menu_name = l1l11l_l1_ (u"ࠧࡠࡕࡉ࡛ࡤ࠭㰓")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l111l1_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l111ll_l1_(url)
	elif mode==214: results = l1lll1ll1111_l1_(url)
	elif mode==215: results = l1lll1ll111l_l1_(url)
	elif mode==218: results = l1l1llll1ll_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l1l1llll1ll_l1_():
	message = l1l11l_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭㰔")
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㰕"),l1l11l_l1_ (u"ࠪࠫ㰖"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㰗"),l1l11l_l1_ (u"ࠬอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠫ㰘"),message)
	return
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㰙"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㰚"),l1l11l_l1_ (u"ࠨࠩ㰛"),219,l1l11l_l1_ (u"ࠩࠪ㰜"),l1l11l_l1_ (u"ࠪࠫ㰝"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㰞"))
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㰟"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠫ㰠"),l1l11l_l1_ (u"ࠧࠨ㰡"),114,l11lll_l1_)
	url = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡔ࡮ࡴ࠿ࡵࡻࡳࡩࡂࡵ࡮ࡦࠨࡧࡥࡹࡧ࠽ࡱ࡫ࡱࠪࡱ࡯࡭ࡪࡶࡀ࠶࠺࠭㰢")
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㰣"),script_name+l1l11l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㰤")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ㰥"),url,211)
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭㰦"),headers,l1l11l_l1_ (u"࠭ࠧ㰧"),l1l11l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㰨"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡴࡄࡸࡸࡹࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㰩"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㰪"),block,re.DOTALL)
	for l1111l_l1_,title in items:#[1:-1]:
		url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࠧ㰫")+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㰬"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㰭")+menu_name+title,url,211)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㰮"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㰯"),block,re.DOTALL)
	l1llll1_l1_ = [l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠢส๊๊๐ࠧ㰰"),l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ㰱")]
	#l11ll111l_l1_ = [l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤࠬ㰲"),l1l11l_l1_ (u"ࠫฬ็ไศ็ࠣࠫ㰳"),l1l11l_l1_ (u"ࠬฮัศ็ฯࠫ㰴"),l1l11l_l1_ (u"ู࠭าู๊ࠫ㰵"),l1l11l_l1_ (u"ࠧไๆํฬฬะࠧ㰶"),l1l11l_l1_ (u"ࠨษ฽ห๋๏ࠧ㰷")]
	for l1111l_l1_,title in items:
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ㰸"))
		if not any(value in title for value in l1llll1_l1_):
		#	if any(value in title for value in l11ll111l_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㰹"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㰺")+menu_name+title,l1111l_l1_,211)
	return html
def l111l1_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠬ࠭㰻"),headers,l1l11l_l1_ (u"࠭ࠧ㰼"),l1l11l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ㰽"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㰾"),l1l11l_l1_ (u"ࠩࠪ㰿"),url,html)
	if l1l11l_l1_ (u"ࠪ࡫ࡪࡺࡰࡰࡵࡷࡷࠬ㱀") in url or l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ㱁") in url: block = html
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡓࡥࡥ࡫ࡤࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ㱂"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		else: return
	items = re.findall(l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㱃"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l11llll1l_l1_ = [l1l11l_l1_ (u"ࠧๆึส๋ิฯࠧ㱄"),l1l11l_l1_ (u"ࠨใํ่๊࠭㱅"),l1l11l_l1_ (u"ࠩส฾๋๐ษࠨ㱆"),l1l11l_l1_ (u"ࠪ็้๐ศࠨ㱇"),l1l11l_l1_ (u"ࠫฬ฿ไศ่ࠪ㱈"),l1l11l_l1_ (u"ࠬํฯศใࠪ㱉"),l1l11l_l1_ (u"࠭ๅษษิหฮ࠭㱊"),l1l11l_l1_ (u"ฺࠧำูࠫ㱋"),l1l11l_l1_ (u"ࠨ็๊ีัอๆࠨ㱌"),l1l11l_l1_ (u"ࠩส่อ๎ๅࠨ㱍")]
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㱎") in l1111l_l1_: continue
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠫ࠴࠭㱏"))
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ㱐"))
		if l1l11l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭㱑") in l1111l_l1_ or any(value in title for value in l11llll1l_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㱒"),menu_name+title,l1111l_l1_,212,img)
		elif l1l11l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ㱓") in l1111l_l1_ and l1l11l_l1_ (u"ࠩส่า๊โสࠩ㱔") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭㱕"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㱖") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㱗"),menu_name+title,l1111l_l1_,213,img)
					l1l1l11_l1_.append(title)
		else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㱘"),menu_name+title,l1111l_l1_,213,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㱙"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㱚"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠩสฺ่็อสࠢࠪ㱛"),l1l11l_l1_ (u"ࠪࠫ㱜"))
			if title!=l1l11l_l1_ (u"ࠫࠬ㱝"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㱞"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬ㱟")+title,l1111l_l1_,211)
	return
def l111ll_l1_(url):
	episodesCount,items,l11lllll_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨ㱠"),headers,l1l11l_l1_ (u"ࠨࠩ㱡"),l1l11l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㱢"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㱣"),html,re.DOTALL)
	if l1ll111_l1_:
		l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࠬ㱤").join(l1ll111_l1_)
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㱥"),l1l1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l11l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ㱦"))
	for l1111l_l1_ in items:
		l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠧ࠰ࠩ㱧"))
		title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㱨") + l1111l_l1_.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㱩"))[-1].replace(l1l11l_l1_ (u"ࠪ࠱ࠬ㱪"),l1l11l_l1_ (u"ࠫࠥ࠭㱫"))
		l1l111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫ㱬"),l1111l_l1_.split(l1l11l_l1_ (u"࠭࠯ࠨ㱭"))[-1],re.DOTALL)
		if l1l111ll_l1_: l1l111ll_l1_ = l1l111ll_l1_[0]
		else: l1l111ll_l1_ = l1l11l_l1_ (u"ࠧ࠱ࠩ㱮")
		l11lllll_l1_.append([l1111l_l1_,title,l1l111ll_l1_])
	items = sorted(l11lllll_l1_, reverse=False, key=lambda key: int(key[2]))
	l11lllll1_l1_ = str(items).count(l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ㱯"))
	episodesCount = str(items).count(l1l11l_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ㱰"))
	if l11lllll1_l1_>1 and episodesCount>0 and l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ㱱") not in url:
		for l1111l_l1_,title,l1l111ll_l1_ in items:
			if l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭㱲") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㱳"),menu_name+title,l1111l_l1_,213)
	else:
		for l1111l_l1_,title,l1l111ll_l1_ in items:
			if l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ㱴") not in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㱵"),menu_name+title,l1111l_l1_,212)
	return
def PLAY(url):
	l1ll1l1l_l1_ = []
	parts = url.split(l1l11l_l1_ (u"ࠨ࠱ࠪ㱶"))
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠩࠪ㱷"),headers,l1l11l_l1_ (u"ࠪࠫ㱸"),l1l11l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㱹"))
	# l1l1l1111_l1_ l1l1lll1_l1_
	if l1l11l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭㱺") in html:
		url2 = url.replace(parts[3],l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ㱻"))
		l1ll1ll1_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠧࠨ㱼"),headers,l1l11l_l1_ (u"ࠨࠩ㱽"),l1l11l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㱾"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㱿"),l1ll1ll1_l1_,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ㲀"),block,re.DOTALL)
			if items:
				id = re.findall(l1l11l_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭㲁"),l1ll1ll1_l1_,re.DOTALL)
				if id:
					l1ll1l1111_l1_ = id[0]
					for l1111l_l1_,title in items:
						l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠩ㲂")+l1ll1l1111_l1_+l1l11l_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ㲃")+l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㲄")+title+l1l11l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ㲅")
						l1ll1l1l_l1_.append(l1111l_l1_)
			else:
				# l11l11l_l1_://l1lll1ll11l1_l1_.tv/l1l1l1111_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࠤࡿࠪࡶࡻ࡯ࡵ࠽ࠬࠫ㲆"),block,re.DOTALL)
				for l1111l_l1_,dummy in items:
					l1ll1l1l_l1_.append(l1111l_l1_)
	# download l1l1lll1_l1_
	if l1l11l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ㲇") in html:
		url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㲈"))
		l1ll1ll1_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"࠭ࠧ㲉"),headers,l1l11l_l1_ (u"ࠧࠨ㲊"),l1l11l_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ㲋"))
		id = re.findall(l1l11l_l1_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㲌"),l1ll1ll1_l1_,re.DOTALL)
		if id:
			l1ll1l1111_l1_ = id[0]
			headers2 = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㲍"):l1l11l_l1_ (u"ࠫࠬ㲎") , l1l11l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ㲏"):l1l11l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ㲐") }
			url2 = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡴ࡫ࡴࠨࡳࡳࡸࡺࡉࡥ࠿ࠪ㲑")+l1ll1l1111_l1_
			l1ll1ll1_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠨࠩ㲒"),headers2,l1l11l_l1_ (u"ࠩࠪ㲓"),l1l11l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ㲔"))
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁ࡮࠳࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㲕"),l1ll1ll1_l1_,re.DOTALL)
			if l1ll111_l1_:
				for resolution,block in l1ll111_l1_:
					items = re.findall(l1l11l_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㲖"),block,re.DOTALL)
					for name,l1111l_l1_ in items:
						l1ll1l1l_l1_.append(l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㲗")+name+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㲘")+l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭㲙")+resolution)
			else:
				l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿࡬࠻࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ㲚"),l1ll1ll1_l1_,re.DOTALL)
				if not l1ll111_l1_: l1ll111_l1_ = [l1ll1ll1_l1_]
				for block in l1ll111_l1_:
					l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࠊࠋࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡩࡷࡼࡥࡳࡵࡗ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࠎࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠋࠋࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩࡠ࠳࠱࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫฬ๊ฯใหࠣࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋࠌࠍ࡮࡬ࠠ࡯ࡣࡰࡩࠦࡃࠧࠨ࠼ࠣࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥࠡ࠭ࠣࠫࠥๆࠠࠨࠌࠌࠍࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦࠧࠨࠌࠌࠍࠎࠏࠉࠣࠤࠥ㲛")
					name = l1l11l_l1_ (u"ࠫࠬ㲜")
					items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ㲝"),block,re.DOTALL)
					for l1111l_l1_ in items:
						server = l1l11l_l1_ (u"࠭ࠦࠧࠩ㲞") + l1111l_l1_.split(l1l11l_l1_ (u"ࠧ࠰ࠩ㲟"))[2].lower() + l1l11l_l1_ (u"ࠨࠨࠩࠫ㲠")
						server = server.replace(l1l11l_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ㲡"),l1l11l_l1_ (u"ࠪࠫ㲢")).replace(l1l11l_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ㲣"),l1l11l_l1_ (u"ࠬ࠭㲤"))
						server = server.replace(l1l11l_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭㲥"),l1l11l_l1_ (u"ࠧࠨ㲦")).replace(l1l11l_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ㲧"),l1l11l_l1_ (u"ࠩࠪ㲨"))
						server = server.replace(l1l11l_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ㲩"),l1l11l_l1_ (u"ࠫࠬ㲪")).replace(l1l11l_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ㲫"),l1l11l_l1_ (u"࠭ࠧ㲬"))
						server = server.replace(l1l11l_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭㲭"),l1l11l_l1_ (u"ࠨࠩ㲮")).replace(l1l11l_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ㲯"),l1l11l_l1_ (u"ࠪࠫ㲰"))
						server = server.replace(l1l11l_l1_ (u"ࠫࠫࠬࠧ㲱"),l1l11l_l1_ (u"ࠬ࠭㲲"))
						l1111l_l1_ = l1111l_l1_ + l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㲳") + name + server + l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㲴")
						l1ll1l1l_l1_.append(l1111l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㲵"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠩࠪ㲶"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠪࠫ㲷"): return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭㲸"),l1l11l_l1_ (u"ࠬ࠱ࠧ㲹"))
	url = l11lll_l1_ + l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ㲺")+search
	l111l1_l1_(url)
	return
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠡࡵࡨࡧࡴࡴࡤࡢࡴࡼࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣ࠰ࡧࡦࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧ࡭࡫ࡣ࡬࡯ࡤࡶࡰ࠳ࡢࡰ࡮ࡧࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࠮ࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࠋࡩࡳࡷࠦࡣࡢࡶࡨ࡫ࡴࡸࡹ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡩࡡࡵࡧࡪࡳࡷࡿࠩࠋࠋࠌࠍ࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩ࠯ࠤ࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔࠪࠌࠌࠍ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲ࠢ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ࠯ࡸ࡫ࡡࡳࡥ࡫࠯ࠬࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ࠮ࡧࡦࡺࡥࡨࡱࡵࡽࠏࠏࠉࡕࡋࡗࡐࡊ࡙ࠨࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ㲻")
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧဋ")
headers = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪဌ") : l1l11l_l1_ (u"ࠧࠨဍ") }
menu_name = l1l11l_l1_ (u"ࠨࡡࡄࡖࡑࡥࠧဎ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩဏ"),l1l11l_l1_ (u"ࠪห้้ไࠨတ"),l1l11l_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ထ"),l1l11l_l1_ (u"ࠬอไฺษหࠫဒ"),l1l11l_l1_ (u"࠭ศาษ่ะ้ࠥๅษ์๋ฮึ࠭ဓ"),l1l11l_l1_ (u"ࠧๆ๊หห๏๊้ࠠࠢฯ์ฬ๊ࠧန"),l1l11l_l1_ (u"ࠨษ็ๆุ๋ࠠศๆสื้อๅ๋ࠩပ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l111l1_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l111ll_l1_(url)
	elif mode==204: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭ဖ")+text)
	elif mode==205: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪဗ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫဘ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬမ"),l1l11l_l1_ (u"࠭ࠧယ"),209,l1l11l_l1_ (u"ࠧࠨရ"),l1l11l_l1_ (u"ࠨࠩလ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ဝ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪသ"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧဟ"),l11lll_l1_,205)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဠ"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩအ"),l11lll_l1_,204)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬဢ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨဣ"),l1l11l_l1_ (u"ࠩࠪဤ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪဥ"),script_name+l1l11l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ဦ")+menu_name+l1l11l_l1_ (u"๋ࠬๅ๋ิฬࠫဧ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࠪဨ"),201)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧဩ"),script_name+l1l11l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪဪ")+menu_name+l1l11l_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧါ"),l11lll_l1_+l1l11l_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧာ"),201)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫိ"),script_name+l1l11l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧီ")+menu_name+l1l11l_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ု"),l11lll_l1_+l1l11l_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡸ࡫ࡲࡪࡧࡶࠫူ"),201)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨေ"),script_name+l1l11l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫဲ")+menu_name+l1l11l_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬဳ"),l11lll_l1_+l1l11l_l1_ (u"ࠫࡄࡅ࡭ࡢ࡫ࡱࡴࡦ࡭ࡥࠨဴ"),201)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩဵ"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧံ"),headers,True,l1l11l_l1_ (u"ࠧࠨ့"),l1l11l_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬး"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳ࡴࡢࡤࡶࠬ࠳࠰࠿ࠪࡏࡤ࡭ࡳࡘ࡯ࡸ္ࠩ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀ်ࠬ"),block,re.DOTALL)
		for filter,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡬ࡴࡳࡥ࠰࡯ࡲࡶࡪࡅࡦࡪ࡮ࡷࡩࡷࡃࠧျ")+filter
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬြ"),script_name+l1l11l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨွ")+menu_name+title,l1111l_l1_,201)
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬှ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨဿ"),l1l11l_l1_ (u"ࠩࠪ၀"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ၁"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭၂"),block,re.DOTALL)
	#l11ll111l_l1_ = [l1l11l_l1_ (u"๋ࠬำๅี็หฯࠦࠧ၃"),l1l11l_l1_ (u"࠭วโๆส้ࠥ࠭၄"),l1l11l_l1_ (u"ࠧษำส้ั࠭၅"),l1l11l_l1_ (u"ࠨ฻ิ์฻࠭၆"),l1l11l_l1_ (u"ࠩๆ่๏ฮวหࠩ၇"),l1l11l_l1_ (u"ࠪห฿อๆ๊ࠩ၈")]
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ၉") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ၊"))
		if not any(value in title for value in l1llll1_l1_):
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭။"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ၌")+menu_name+title,l1111l_l1_,201)
	return html
def l111l1_l1_(url):
	l1l11l_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡧࡱࡵࠤࡕࡕࡓࡕࠢࡩ࡭ࡱࡺࡥࡳ࠼ࠍࠍ࡮࡬ࠠࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬࠦࡩ࡯ࠢࡸࡶࡱࡀࠊࠊࠋࡸࡶࡱ࠸ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠳ࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨࡁࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࠪ࠰ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠫ࠮ࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠳࠮ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠭ࠏࠏࠉࡥࡣࡷࡥ࠷ࠦ࠽ࠡࡽࠪࡪࡴࡸ࡭ࠨ࠼ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠰ࠬࡌࡩ࡭ࡶࡨࡶ࡜ࡵࡲࡥ࠿ࠪ࠾ࠬ࠭ࡽࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡣࠠ࠾ࠢࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬࡣࠠ࠾ࠢࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪ࡜࠲ࡉࡓࡓࡈ࠰ࡘࡔࡑࡅࡏࠩࡠࠤࡂࠦࠧࡈ࡜࠷ࡓࡩ࠶࡮࡫ࡖࡆࡥࡌࡽࡣࡈࡳ࠷ࡍࡿࡍࡱࡉࡇࡵ࡝࠵ࡻ࡚ࡰࡣࡘ࡜࡟ࡉ࠶ࡉࡧ࡛ࡼࡽ࠭ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡣࠠ࠾ࠢࠪࡻࡦࡸࡢ࡭࡫ࡲࡲࡿࡺࡶࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࡨࡽࡏࡶࡤࡪࡋ࠹ࡍࡲࡘ࠰ࡎ࡚ࡑࡎ࡞ࡲࡒࡍࡓ࡭ࡨࡦࡔࡄ࡬ࡺ࡙ࡲࡩࡍ࡚࠲ࡄ࠵࡝ࡱࡋ࠹ࡑࡕࡌࡷࡎࡴ࡚ࡩࡤࡋ࡚ࡱࡏࡪࡰ࡫ࡔࡘࡗࡘࡖ࡙ࡏ࠴࡙࡯ࡲࡇࡣࡈࡉࡶࡦ࡛ࡆ࡬ࡑࡈࡼࡊࡕࡕࡗࡓ࡜࡙࠹࠷ࡤ࠲ࡐ࡚ࡩࡍࡩࡷࡦࡰࡐࡽ࡛࡝ࡒࡇࡓࡰࡰ࠷࡛ࡘࡊ࠲ࡧ࡯ࡽࡲ࡚࠲ࡄࡱࡥ࠸ࡶࡘࡔ࠳ࡅ࡛ࡧ࡚ࡁ࠴ࡕࡰࡒ࡯ࡪࡆࡥ࠵࡚ࡇࡎࡹࡉ࡮࠳࡫࡝ࡾࡏ࠶ࡊ࡬ࡘࡼ࡟࡚ࡧࡺࡐࡰࡑࡾࡕࡇࡆࡻࡐ࡮ࡎ࠶ࡎࡅࡐ࡯࡞࡯࡮࡬ࡏ࠴ࡑ࡯࡟࡚ࡂ࡮ࡐ࡭ࡨࡲ࡟ࡺࡂ࠲ࡑ࡮ࡆࡽࡍࡕࡌ࡮ࡑࡿࡠࡪࡐࡆࡌࡾࡓ࡚࡙ࡺࡏࡽ࡯࠵ࡔࡄࡤ࠷ࡐࡘࡇࡰࡎࡘࡋࡼࡓ࡙ࡲࡪࡏ࡬ࡪ࡭࡫ࡗ࠽࠾ࠩࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠴࠯ࡨࡦࡺࡡ࠳࠮࡫ࡩࡦࡪࡥࡳࡵ࠵࠰࡙ࡸࡵࡦ࠮ࠪࠫ࠱࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠨ࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠤࠥࠦ၍")
	if l1l11l_l1_ (u"ࠩࡂࡃࠬ၎") in url: url,type = url.split(l1l11l_l1_ (u"ࠪࡃࡄ࠭၏"))
	else: type = l1l11l_l1_ (u"ࠫࠬၐ")
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ၑ"),l1l11l_l1_ (u"࠭ࠧၒ"),url,type)
	#if url==l11lll_l1_: url = url+l1l11l_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬၓ")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩၔ"),l1l11l_l1_ (u"ࠩࠪၕ"),url,l1l11l_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪၖ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨၗ"),url,l1l11l_l1_ (u"ࠬ࠭ၘ"),headers,True,l1l11l_l1_ (u"࠭ࠧၙ"),l1l11l_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ၚ"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ၛ"))
	#WRITE_THIS(html)
	if l1l11l_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫၜ") in url: l1ll111_l1_ = [html]
	elif type==l1l11l_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬၝ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡒࡧࡳࡵࡧࡵࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ၞ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧၟ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠱ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬၠ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩၡ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠴ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧၢ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠩ࠴࠵࠶ࡳࡡࡪࡰࡳࡥ࡬࡫ࠧၣ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨࡳࠣࠩၤ"),html,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲ࠲࡬࡯ࡰࡶࡨࡶࠬၥ"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ၦ"),l1l11l_l1_ (u"࠭ࠧၧ"),l1l11l_l1_ (u"ࠧࠨၨ"),str(l1ll111_l1_))
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	#items = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬၩ"),block,re.DOTALL)
	l11llll1l_l1_ = [l1l11l_l1_ (u"ุ่ࠩฬํฯสࠩၪ"),l1l11l_l1_ (u"ࠪๅ๏๊ๅࠨၫ"),l1l11l_l1_ (u"ࠫฬเๆ๋หࠪၬ"),l1l11l_l1_ (u"้ࠬไ๋สࠪၭ"),l1l11l_l1_ (u"࠭วฺๆส๊ࠬၮ"),l1l11l_l1_ (u"่ࠧัสๅࠬၯ"),l1l11l_l1_ (u"ࠨ็หหึอษࠨၰ"),l1l11l_l1_ (u"ࠩ฼ี฻࠭ၱ"),l1l11l_l1_ (u"้ࠪ์ืฬศ่ࠪၲ"),l1l11l_l1_ (u"ࠫฬ๊ศ้็ࠪၳ")]
	#addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪၴ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၵ"),l1l11l_l1_ (u"ࠧࠨၶ"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧၷ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l11l_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨၸ"),block,re.DOTALL)
		l1l1lll1_l1_,l11ll1111_l1_,titles = zip(*items)
		items = zip(l11ll1111_l1_,l1l1lll1_l1_,titles)
	l1l1l11_l1_ = []
	for img,l1111l_l1_,title in items:
		#l1111l_l1_ = escapeUNICODE(l1111l_l1_)
		#l1111l_l1_ = QUOTE(l1111l_l1_)
		if l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬၹ") in l1111l_l1_: continue
		l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠫ࠴࠭ၺ"))
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧၻ"))
		if l1l11l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭ၼ") in l1111l_l1_ or any(value in title for value in l11llll1l_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ၽ"),menu_name+title,l1111l_l1_,202,img)
		elif l1l11l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫၾ") in l1111l_l1_ and l1l11l_l1_ (u"ࠩส่า๊โสࠩၿ") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ႀ"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪႁ") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬႂ"),menu_name+title,l1111l_l1_,203,img)
					l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"࠭࠯ࡱࡣࡦ࡯࠴࠭ႃ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧႄ"),menu_name+title,l1111l_l1_+l1l11l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨႅ"),201,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩႆ"),menu_name+title,l1111l_l1_,203,img)
	if type in [l1l11l_l1_ (u"ࠪࠫႇ"),l1l11l_l1_ (u"ࠫࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ႈ")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ႉ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ႊ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				l1111l_l1_ = unescapeHTML(l1111l_l1_)
				title = unescapeHTML(title)
				title = title.replace(l1l11l_l1_ (u"ࠧศๆุๅาฯࠠࠨႋ"),l1l11l_l1_ (u"ࠨࠩႌ"))
				if l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡶࡁႍࠬ") in url:
					l11l1lll1_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩႎ"))[1]
					l11lll111_l1_ = url.split(l1l11l_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪႏ"))[1]
					l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫ႐")+l11lll111_l1_,l1l11l_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬ႑")+l11l1lll1_l1_)
				if title!=l1l11l_l1_ (u"ࠧࠨ႒"): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ႓"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨ႔")+title,l1111l_l1_,201)
	return
def l111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ႕"),l1l11l_l1_ (u"ࠫࠬ႖"),url,l1l11l_l1_ (u"ࠬ࠭႗"))
	episodesCount,items,l11lllll_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ႘"),url,l1l11l_l1_ (u"ࠧࠨ႙"),headers,True,l1l11l_l1_ (u"ࠨࠩႚ"),l1l11l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪႛ"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨႜ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫႝ"),html,re.DOTALL)
	if l1ll111_l1_:
		l11lllll_l1_ = []
		l1l1l1_l1_ = l1l11l_l1_ (u"ࠬ࠭႞").join(l1ll111_l1_)
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ႟"),l1l1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨႠ"))
	for l1111l_l1_ in items:
		l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠨ࠱ࠪႡ"))
		title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨႢ") + l1111l_l1_.split(l1l11l_l1_ (u"ࠪ࠳ࠬႣ"))[-1].replace(l1l11l_l1_ (u"ࠫ࠲࠭Ⴄ"),l1l11l_l1_ (u"ࠬࠦࠧႥ"))
		l1l111ll_l1_ = re.findall(l1l11l_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬႦ"),l1111l_l1_.split(l1l11l_l1_ (u"ࠧ࠰ࠩႧ"))[-1],re.DOTALL)
		if l1l111ll_l1_: l1l111ll_l1_ = l1l111ll_l1_[0]
		else: l1l111ll_l1_ = l1l11l_l1_ (u"ࠨ࠲ࠪႨ")
		l11lllll_l1_.append([l1111l_l1_,title,l1l111ll_l1_])
	items = sorted(l11lllll_l1_, reverse=False, key=lambda key: int(key[2]))
	l11lllll1_l1_ = str(items).count(l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫႩ"))
	episodesCount = str(items).count(l1l11l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭Ⴊ"))
	if l11lllll1_l1_>1 and episodesCount>0 and l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭Ⴋ") not in url:
		for l1111l_l1_,title,l1l111ll_l1_ in items:
			if l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧႬ") in l1111l_l1_:
				#l1111l_l1_ = QUOTE(l1111l_l1_)
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⴍ"),menu_name+title,l1111l_l1_,203)
	else:
		for l1111l_l1_,title,l1l111ll_l1_ in items:
			if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩႮ") not in l1111l_l1_:
				#if l1l11l_l1_ (u"ࠨࠧࠪႯ") not in l1111l_l1_: l1111l_l1_ = QUOTE(l1111l_l1_)
				#else: l1111l_l1_ = QUOTE(UNQUOTE(l1111l_l1_))
				#l1111l_l1_ = UNQUOTE(l1111l_l1_)
				title = UNQUOTE(title)
				addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨႰ"),menu_name+title,l1111l_l1_,202)
	return
def PLAY(url):
	#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪႱ"),l1l11l_l1_ (u"ࠫࡊࡓࡁࡅࠢ࠴࠵࠶࠭Ⴒ"))
	l1ll1l1l_l1_ = []
	parts = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧႳ"))
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧႴ"),l1l11l_l1_ (u"ࠧࠨႵ"),url,l1l11l_l1_ (u"ࠨࡒࡏࡅ࡞࠳࠱ࡴࡶࠪႶ"))
	#url = UNQUOTE(QUOTE(url))
	hostname = l11lll_l1_
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭Ⴗ"),url,l1l11l_l1_ (u"ࠪࠫႸ"),headers,True,True,l1l11l_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨႹ"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪႺ"))
	id = re.findall(l1l11l_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧႻ"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨႼ"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠨࡲࡲࡷࡹ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႽ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪႾ"),l1l11l_l1_ (u"ࠪࠫႿ"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჀ"),l1l11l_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩჁ"))
	#LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ⴢ"),l1l11l_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠶࠷࠱ࠨჃ"))
	if l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩჄ") in html:
		#parts = url.split(l1l11l_l1_ (u"ࠩ࠲ࠫჅ"))
		url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ჆"))
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨჇ"),url2,l1l11l_l1_ (u"ࠬ࠭჈"),headers,True,True,l1l11l_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ჉"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ჊"))
		l11l1ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ჋"),l1ll1ll1_l1_,re.DOTALL)
		l1l111l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ჌"),l1ll1ll1_l1_,re.DOTALL)
		l11l1ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧჍ"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ჎"),l1ll1ll1_l1_)
		l11l1l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭჏"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1lll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨა"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
		items = l11l1ll11_l1_+l1l111l1l_l1_+l11l1ll1l_l1_+l11l1l1l1_l1_+l11l1l11l_l1_+l11ll1lll_l1_
		#LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧბ"),l1l11l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡓࡕࡃࡕࡘ࡚ࠥࡉࡎࡋࡑࡋࠥ࠺࠴࠵ࠩგ"))
		if not items:
			items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧდ"),l1ll1ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l11l_l1_ (u"ࠪ࠲ࡵࡴࡧࠨე") in server: continue
			if l1l11l_l1_ (u"ࠫ࠳ࡰࡰࡨࠩვ") in server: continue
			if l1l11l_l1_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬზ") in server: continue
			l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧთ"),title,re.DOTALL)
			if l1l1l111_l1_:
				l1l1l111_l1_ = l1l1l111_l1_[0]
				if l1l1l111_l1_ in title: title = title.replace(l1l1l111_l1_+l1l11l_l1_ (u"ࠧࡱࠩი"),l1l11l_l1_ (u"ࠨࠩკ")).replace(l1l1l111_l1_,l1l11l_l1_ (u"ࠩࠪლ")).strip(l1l11l_l1_ (u"ࠪࠤࠬმ"))
				l1l1l111_l1_ = l1l11l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩნ")+l1l1l111_l1_
			else: l1l1l111_l1_ = l1l11l_l1_ (u"ࠬ࠭ო")
			#LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭პ"),l1l11l_l1_ (u"ࠧ࡜ࠩჟ")+str(id)+l1l11l_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭რ")+str(hostname)+l1l11l_l1_ (u"ࠩࡠࠤࠥࡡࠧს")+str(title)+l1l11l_l1_ (u"ࠪࡡ࡛ࠥࠦࠨტ")+str(l1l1l111_l1_)+l1l11l_l1_ (u"ࠫࡢ࠭უ"))
			if server.isdigit():
				l1111l_l1_ = hostname+l1l11l_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨფ")+id+l1l11l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪქ")+server+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨღ")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩყ")+l1l1l111_l1_
			else:
				if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧშ") not in server: server = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩჩ")+server
				l1l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬც"),title,re.DOTALL)
				if l1l1l111_l1_: l1l1l111_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪძ")+l1l1l111_l1_[0]
				else: l1l1l111_l1_ = l1l11l_l1_ (u"࠭ࠧწ")
				l1111l_l1_ = server+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨჭ")+l1l1l111_l1_
			l1ll1l1l_l1_.append(l1111l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨხ"),l1l11l_l1_ (u"ࠩ࡞ࠫჯ")+l1l1l111_l1_+l1l11l_l1_ (u"ࠪࡡࠥࠦࠠࠡ࡝ࠪჰ")+title+l1l11l_l1_ (u"ࠫࡢ࠭ჱ"))
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪჲ"), l1ll1l1l_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧჳ"),l1l11l_l1_ (u"ࠧࠨჴ"),l1l11l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠠ࠲ࠩჵ"),	str(len(items)))
	if l1l11l_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡒࡴࡽࠧჶ") in html:
		headers2 = { l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩჷ"):l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫჸ") }
		url2 = url+l1l11l_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨჹ")
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪჺ"),url2,l1l11l_l1_ (u"ࠧࠨ჻"),headers2,True,l1l11l_l1_ (u"ࠨࠩჼ"),l1l11l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ჽ"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨჾ"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬჿ"),l1l11l_l1_ (u"ࠬ࠭ᄀ"),url2,l1ll1ll1_l1_)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᄁ"),l1ll1ll1_l1_,re.DOTALL)
		for block in l1ll111_l1_:
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩᄂ"),block,re.DOTALL)
			for l1111l_l1_,name,l1l1l111_l1_ in items:
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᄃ")+name+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᄄ")+l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨᄅ")+l1l1l111_l1_
				l1ll1l1l_l1_.append(l1111l_l1_)
	elif l1l11l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨᄆ") in html:
		headers2 = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᄇ"):l1l11l_l1_ (u"࠭ࠧᄈ") , l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪᄉ"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩᄊ") }
		url2 = hostname + l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬᄋ")+id
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᄌ"),url2,l1l11l_l1_ (u"ࠫࠬᄍ"),headers2,True,True,l1l11l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩᄎ"))
		l1ll1ll1_l1_ = response.content#.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᄏ"))
		if l1l11l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡸࡳࡹࠧᄐ") in l1ll1ll1_l1_:
			l11l1ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᄑ"),l1ll1ll1_l1_,re.DOTALL)
			for url3 in l11l1ll1l_l1_:
				if l1l11l_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩᄒ") not in url3 and l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᄓ") in url3:
					url3 = url3+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᄔ")
					l1ll1l1l_l1_.append(url3)
				elif l1l11l_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬᄕ") in url3:
					l1l1l111_l1_ = l1l11l_l1_ (u"࠭ࠧᄖ")
					response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᄗ"),url3,l1l11l_l1_ (u"ࠨࠩᄘ"),headers,True,True,l1l11l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭ᄙ"))
					l11ll11l1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᄚ"))
					l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭ࡂࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࠬ࠱࠲࠳࠭࠮ࠩᄛ"),l11ll11l1_l1_,re.DOTALL)
					for l11llllll_l1_ in l1l1l1_l1_:
						l11ll1l11_l1_ = l1l11l_l1_ (u"ࠬ࠭ᄜ")
						l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨᄝ"),l11llllll_l1_,re.DOTALL)
						for l11lll11l_l1_ in l11l1l1l1_l1_:
							item = re.findall(l1l11l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨᄞ"),l11lll11l_l1_,re.DOTALL)
							if item:
								l1l1l111_l1_ = l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭ᄟ")+item[0]
								break
						for l11lll11l_l1_ in reversed(l11l1l1l1_l1_):
							item = re.findall(l1l11l_l1_ (u"ࠩ࡟ࡻࡡࡽࠫࠨᄠ"),l11lll11l_l1_,re.DOTALL)
							if item:
								l11ll1l11_l1_ = item[0]
								break
						l11l1l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᄡ"),l11llllll_l1_,re.DOTALL)
						for l11ll1ll1_l1_ in l11l1l11l_l1_:
							l11ll1ll1_l1_ = l11ll1ll1_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᄢ")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᄣ")+l1l1l111_l1_
							l1ll1l1l_l1_.append(l11ll1ll1_l1_)
			#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧᄤ"),l1l11l_l1_ (u"ࠧࠨᄥ"),l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵ࠬᄦ"),	str(len(l1ll1l1l_l1_))	)
		elif l1l11l_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧᄧ") in l1ll1ll1_l1_:
			l1ll1ll1_l1_ = l1ll1ll1_l1_.replace(l1l11l_l1_ (u"ࠪࡀ࡭࠼ࠠࠨᄨ"),l1l11l_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨᄩ"))+l1l11l_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ᄪ")
			l1ll1ll1_l1_ = l1ll1ll1_l1_.replace(l1l11l_l1_ (u"࠭࠼ࡩ࠵ࠣࠫᄫ"),l1l11l_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫᄬ"))+l1l11l_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩᄭ")
			#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᄮ"),l1ll1ll1_l1_)
			#open(l1l11l_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪᄯ"),l1l11l_l1_ (u"ࠫࡼ࠭ᄰ")).write(l1ll1ll1_l1_)
			l11l1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ᄱ"),l1ll1ll1_l1_,re.DOTALL)
			if l11l1l1ll_l1_:
				for l11llllll_l1_ in l11l1l1ll_l1_:
					if l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬᄲ") not in l11llllll_l1_: continue
					#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᄳ"),l1l11l_l1_ (u"ࠨࠩᄴ"),l1l11l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࠶࠷࠱ࠨᄵ"),	l11llllll_l1_	)
					l11lll1l1_l1_ = l1l11l_l1_ (u"ࠪࠫᄶ")
					l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡸࡲ࡯ࡸ࠯ࡰࡳࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᄷ"),l11llllll_l1_,re.DOTALL)
					for l11lll11l_l1_ in l11l1l1l1_l1_:
						item = re.findall(l1l11l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ᄸ"),l11lll11l_l1_,re.DOTALL)
						if item:
							l11lll1l1_l1_ = l1l11l_l1_ (u"࠭࡟ࡠࡡࡢࠫᄹ")+item[0]
							break
					l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ᄺ"),l11llllll_l1_,re.DOTALL)
					if l11l1l1l1_l1_:
						for l11ll1l11_l1_,l11ll1l1l_l1_ in l11l1l1l1_l1_:
							l11ll1l1l_l1_ = l11ll1l1l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᄻ")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᄼ")+l11lll1l1_l1_
							l1ll1l1l_l1_.append(l11ll1l1l_l1_)
					else:
						l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᄽ"),l11llllll_l1_,re.DOTALL)
						for l11ll1l1l_l1_,l11ll1l11_l1_ in l11l1l1l1_l1_:
							l11ll1l1l_l1_ = l11ll1l1l_l1_.strip(l1l11l_l1_ (u"ࠫࠥ࠭ᄾ"))+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᄿ")+l11ll1l11_l1_+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᅀ")+l11lll1l1_l1_
							l1ll1l1l_l1_.append(l11ll1l1l_l1_)
			else:
				l11l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫࡠࡼ࠱ࠩ࠽ࠩᅁ"),l1ll1ll1_l1_,re.DOTALL)
				for l11ll1l1l_l1_,l11ll1l11_l1_ in l11l1l1l1_l1_:
					l11ll1l1l_l1_ = l11ll1l1l_l1_.strip(l1l11l_l1_ (u"ࠨࠢࠪᅂ"))+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᅃ")+l11ll1l11_l1_+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᅄ")
					l1ll1l1l_l1_.append(l11ll1l1l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᅅ"), l1ll1l1l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1l1l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᅆ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧᅇ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨᅈ"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪᅉ"),l1l11l_l1_ (u"ࠩ࠮ࠫᅊ"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᅋ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩᅌ"),l1l11l_l1_ (u"ࠬ࠭ᅍ"),headers,True,l1l11l_l1_ (u"࠭ࠧᅎ"),l1l11l_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ᅏ"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᅐ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᅑ"),html,re.DOTALL)
	if showdialogs and l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᅒ"),block,re.DOTALL)
		l11lll1ll_l1_,l11ll11ll_l1_ = [],[]
		for category,title in items:
			#if title in [l1l11l_l1_ (u"ࠫึ๐วืหࠣ์๋ࠥีศำ฼๋ࠬᅓ")]: continue
			l11lll1ll_l1_.append(category)
			l11ll11ll_l1_.append(title)
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬᅔ"), l11ll11ll_l1_)
		if selection == -1 : return
		category = l11lll1ll_l1_[selection]
	else: category = l1l11l_l1_ (u"࠭ࠧᅕ")
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫᅖ")+search+l1l11l_l1_ (u"ࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬᅗ")+category+l1l11l_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾࠳ࠪᅘ")
	l111l1_l1_(url)
	return
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᅙ"),l1l11l_l1_ (u"ࠫࠬᅚ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ᅛ"),l1l11l_l1_ (u"࠭ࠧᅜ"),filter,url)
	# for l11l1llll_l1_ filter:		l111111_l1_ = [l1l11l_l1_ (u"ࠧࡄࡣࡷࡩ࡬ࡵࡲࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪᅝ"),l1l11l_l1_ (u"ࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧᅞ"),l1l11l_l1_ (u"ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩᅟ"),l1l11l_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬᅠ")]
	l111111_l1_ = [l1l11l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᅡ"),l1l11l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫᅢ"),l1l11l_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬᅣ"),l1l11l_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨᅤ")]
	if l1l11l_l1_ (u"ࠨࡁࠪᅥ") in url: url = url.split(l1l11l_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᅦ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᅧ"),1)
	if filter==l1l11l_l1_ (u"ࠫࠬᅨ"): l1lllll1_l1_,l1llll1l_l1_ = l1l11l_l1_ (u"ࠬ࠭ᅩ"),l1l11l_l1_ (u"࠭ࠧᅪ")
	else: l1lllll1_l1_,l1llll1l_l1_ = filter.split(l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᅫ"))
	if type==l1l11l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬᅬ"):
		if l111111_l1_[0]+l1l11l_l1_ (u"ࠩࡀࠫᅭ") not in l1lllll1_l1_: category = l111111_l1_[0]
		for i in range(len(l111111_l1_[0:-1])):
			if l111111_l1_[i]+l1l11l_l1_ (u"ࠪࡁࠬᅮ") in l1lllll1_l1_: category = l111111_l1_[i+1]
		l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠫࠫ࠭ᅯ")+category+l1l11l_l1_ (u"ࠬࡃ࠰ࠨᅰ")
		l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"࠭ࠦࠨᅱ")+category+l1l11l_l1_ (u"ࠧ࠾࠲ࠪᅲ")
		l1111l1_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠨࠨࠪᅳ"))+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ᅴ")+l11l111_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠬᅵ"))
		l1lll1l1_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᅶ"))
		url2 = url+l1l11l_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩᅷ")+l1lll1l1_l1_
	elif type==l1l11l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧᅸ"):
		l1ll1l11_l1_ = l1lll1ll_l1_(l1lllll1_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᅹ"))
		l1ll1l11_l1_ = UNQUOTE(l1ll1l11_l1_)
		if l1llll1l_l1_!=l1l11l_l1_ (u"ࠨࠩᅺ"): l1llll1l_l1_ = l1lll1ll_l1_(l1llll1l_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᅻ"))
		if l1llll1l_l1_==l1l11l_l1_ (u"ࠪࠫᅼ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨᅽ")+l1llll1l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅾ"),menu_name+l1l11l_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩᅿ"),url2,201)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆀ"),menu_name+l1l11l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨᆁ")+l1ll1l11_l1_+l1l11l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨᆂ"),url2,201)
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᆃ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᆄ"),l1l11l_l1_ (u"ࠬ࠭ᆅ"),9999)
	html = OPENURL_CACHED(l1llll_l1_,url+l1l11l_l1_ (u"࠭࠯ࡢ࡮ࡽࠫᆆ"),l1l11l_l1_ (u"ࠧࠨᆇ"),headers,l1l11l_l1_ (u"ࠨࠩᆈ"),l1l11l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᆉ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠨ࠯ࠬࡂ࠭ࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤࠨᆊ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# for l11l1llll_l1_ filter:		l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪᆋ"),block,re.DOTALL)
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡩࡧࡴࡢ࠯ࡩࡳࡷ࡚ࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽ࡪ࠵ࠫᆌ"),block,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧᆍ"),l1l11l_l1_ (u"ࠧࠨᆎ"),l1l11l_l1_ (u"ࠨࠩᆏ"),str(l1l1ll1_l1_))
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		#name = name.replace(l1l11l_l1_ (u"ࠩ࠰࠱ࠬᆐ"),l1l11l_l1_ (u"ࠪࠫᆑ"))
		name = name.replace(l1l11l_l1_ (u"ࠫฬิส๋ษิࠤࠬᆒ"),l1l11l_l1_ (u"ࠬ࠭ᆓ"))
		name = name.replace(l1l11l_l1_ (u"࠭ำ็หࠣห้หๆหษฯࠫᆔ"),l1l11l_l1_ (u"ࠧศๆึ๊ฮ࠭ᆕ"))
		items = re.findall(l1l11l_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩᆖ"),block,re.DOTALL)
		if l1l11l_l1_ (u"ࠩࡀࠫᆗ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧᆘ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l111111_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫᆙ")+l1111l1_l1_)
				return
			else:
				if l1l111l_l1_==l111111_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆚ"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾ࠦࠧᆛ"),url2,201)
				else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆜ"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩᆝ"),url2,205,l1l11l_l1_ (u"ࠩࠪᆞ"),l1l11l_l1_ (u"ࠪࠫᆟ"),l1111l1_l1_)
		elif type==l1l11l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬᆠ"):
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠬࠬࠧᆡ")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽࠱ࠩᆢ")
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠧࠧࠩᆣ")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿࠳ࠫᆤ")
			l1111l1_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ᆥ")+l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆦ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ᆧ")+name,url2,204,l1l11l_l1_ (u"ࠬ࠭ᆨ"),l1l11l_l1_ (u"࠭ࠧᆩ"),l1111l1_l1_)		# +l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᆪ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			option = option.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫᆫ"),l1l11l_l1_ (u"ࠩࠪᆬ"))
			if option in l1llll1_l1_: continue
			#if option==l1l11l_l1_ (u"ࠪห้้ไࠨᆭ"): continue
			#option = l1l11l_l1_ (u"ࠫࡠ࠭ᆮ")+option+l1l11l_l1_ (u"ࠬࡣࠧᆯ")
			#if l1l11l_l1_ (u"࠭วๅๅ็ࠫᆰ") in option: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᆱ"),l1l11l_l1_ (u"ࠨࠩᆲ"),l1l11l_l1_ (u"ࠩࠪᆳ"),l1l11l_l1_ (u"ࠪ࡟ࠬᆴ")+str(option)+l1l11l_l1_ (u"ࠫࡢ࠭ᆵ"))
			#if l1l11l_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᆶ") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧᆷ"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l1lllll1_l1_+l1l11l_l1_ (u"ࠧࠧࠩᆸ")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿ࠪᆹ")+option
			l11l111_l1_ = l1llll1l_l1_+l1l11l_l1_ (u"ࠩࠩࠫᆺ")+l1l111l_l1_+l1l11l_l1_ (u"ࠪࡁࠬᆻ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᆼ")+l11l111_l1_
			title = option+l1l11l_l1_ (u"ࠬࠦ࠺ࠨᆽ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"࠭࠰ࠨᆾ")]
			title = option+l1l11l_l1_ (u"ࠧࠡ࠼ࠪᆿ")+name
			if type==l1l11l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩᇀ"): addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇁ"),menu_name+title,url,204,l1l11l_l1_ (u"ࠪࠫᇂ"),l1l11l_l1_ (u"ࠫࠬᇃ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᇄ"))
			elif type==l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪᇅ") and l111111_l1_[-2]+l1l11l_l1_ (u"ࠧ࠾ࠩᇆ") in l1lllll1_l1_:
				l1lll1l1_l1_ = l1lll1ll_l1_(l11l111_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᇇ"))
				url3 = url+l1l11l_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᇈ")+l1lll1l1_l1_
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᇉ"),menu_name+title,url3,201)
			else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᇊ"),menu_name+title,url,205,l1l11l_l1_ (u"ࠬ࠭ᇋ"),l1l11l_l1_ (u"࠭ࠧᇌ"),l1l1111_l1_)
	return
def l1lll1ll_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᇍ"),l1l11l_l1_ (u"ࠨࠩᇎ"),filters,l1l11l_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪᇏ"))
	# mode==l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᇐ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ values
	# mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᇑ")		l11l1l1_l1_ l111l11_l1_ l111l1l_l1_ filters
	# mode==l1l11l_l1_ (u"ࠬࡧ࡬࡭ࠩᇒ")					all filters (l1lll111_l1_ l111l1l_l1_ filter)
	filters = filters.replace(l1l11l_l1_ (u"࠭࠽ࠧࠩᇓ"),l1l11l_l1_ (u"ࠧ࠾࠲ࠩࠫᇔ"))
	filters = filters.strip(l1l11l_l1_ (u"ࠨࠨࠪᇕ"))
	l1llllll_l1_ = {}
	if l1l11l_l1_ (u"ࠩࡀࠫᇖ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠪࠪࠬᇗ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠫࡂ࠭ᇘ"))
			l1llllll_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠬ࠭ᇙ")
	# for l11l1llll_l1_ filter:		l11ll1l_l1_ = [l1l11l_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩᇚ"),l1l11l_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ᇛ"),l1l11l_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨᇜ"),l1l11l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫᇝ")]
	l11ll1l_l1_ = [l1l11l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᇞ"),l1l11l_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᇟ"),l1l11l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫᇠ"),l1l11l_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧᇡ")]
	for key in l11ll1l_l1_:
		if key in list(l1llllll_l1_.keys()): value = l1llllll_l1_[key]
		else: value = l1l11l_l1_ (u"ࠧ࠱ࠩᇢ")
		if l1l11l_l1_ (u"ࠨࠧࠪᇣ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫᇤ") and value!=l1l11l_l1_ (u"ࠪ࠴ࠬᇥ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠥ࠱ࠠࠨᇦ")+value
		elif mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᇧ") and value!=l1l11l_l1_ (u"࠭࠰ࠨᇨ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠧࠧࠩᇩ")+key+l1l11l_l1_ (u"ࠨ࠿ࠪᇪ")+value
		elif mode==l1l11l_l1_ (u"ࠩࡤࡰࡱ࠭ᇫ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠪࠪࠬᇬ")+key+l1l11l_l1_ (u"ࠫࡂ࠭ᇭ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠬࠦࠫࠡࠩᇮ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠨᇯ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠧ࠾࠲ࠪᇰ"),l1l11l_l1_ (u"ࠨ࠿ࠪᇱ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᇲ"),l1l11l_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫᇳ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬᇴ"),l1l11l_l1_ (u"ࠬ࠭ᇵ"),filters,l1l11l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᇶ"))
	return l11llll_l1_
l1l11l_l1_ (u"ࠢࠣࠤࠍࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠎ࠷ࡳࡵࠢࡰࡩࡹ࡮࡯ࡥࠋࠌࠬࡺࡹࡥࡥࠢࡱࡳࡼࠦࡩ࡯ࠢࡺࡩࡧࡹࡩࡵࡧࠬࠎࡦࡪࡤࡪࡰࡪࠤ࡫࡯࡬ࡵࡧࡵࠤࡹࡵࠠࡴࡧࡤࡶࡨ࡮ࠊࡑࡑࡖࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠎࠎࡪࡡࡵࡣ࠽ࠍࡠ࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪ࠰ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡀࠉࡄࡱࡲ࡯࡮࡫࡛ࠠࠬࠢࡖࡊࡌ࠭ࡕࡑࡎࡉࡓࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠶ࡳࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠍࠎ࠮ࡵࡴࡧࡧࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡲࡷࡤࡰ࡮ࡺࡹ࠾࡙ࡈࡆ࠲ࡊࡌࠧࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠽࠳࠲࠵࠴ࠏࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠷ࡷࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲ࠰࠴࠳࠵࠾ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠺ࡋࠦ࠴࠳ࡆࡱࡻࡒࡢࡻࠍࠦࠧࠨᇷ")
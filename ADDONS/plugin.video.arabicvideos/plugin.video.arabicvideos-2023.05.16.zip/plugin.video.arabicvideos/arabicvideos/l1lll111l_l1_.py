﻿# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
script_name = l1l11l_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫෟ")
headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ෠") : l1l11l_l1_ (u"ࠫࠬ෡") }
menu_name = l1l11l_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫ෢")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==40: results = MENU()
	elif mode==41: results = l1lll1ll1_l1_()
	elif mode==42: results = l111ll_l1_(url)
	elif mode==43: results = PLAY(url)
	elif mode==44: results = CATEGORIES(url,text)
	elif mode==45: results = l111l1_l1_(url,text)
	elif mode==46: results = l1lll1111_l1_()
	elif mode==47: results = l1ll11lll_l1_(url)
	elif mode==49: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫ෣"),script_name+l1l11l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ෤")+menu_name+l1l11l_l1_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣหู้๋ศำไࠫ෥"),l1l11l_l1_ (u"ࠩࠪ෦"),41)
	return
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ࠱࠭ࠧ࠭࠶࠼࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้ฮัศ็ฯࠤฬ๊อศๆํอࠬ࠲ࠧࠨ࠮࠷࠺࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾࡫࠶ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳࡭࠸࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬ࡯ࡣࡰࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡰࡤࡱࡪ࠲࡬ࡪࡰ࡮࠰࠹࠻ࠬࠨࠩ࠯ࠫࠬ࠲ࠧ࠴ࠩࠬࠎࠎࡴࡡ࡮ࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡶࡪࡩࡥ࡯ࡶ࠰ࡨࡪ࡬ࡡࡶ࡮ࡷ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠯ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡳࡧ࡭ࡦ࡝࠳ࡡ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭࠶࠸࠰ࠬ࠭ࠬࠨࠩ࠯ࠫ࠷࠭ࠩࠋࠋࡱࡥࡲ࡫ࠠ࠾ࠢ࡞ࠫฬืิ๋ใࠣห้ฮัศ็ฯࠫࡢࠐࠉࠤࡰࡤࡱࡪࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠥࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵ࠯ࡷࡳࡵࠨ࠾࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡰࡤࡱࡪࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠰࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡴࡡ࡮ࡧ࡞࠴ࡢ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮࠷࠸࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠶ࠧࠪࠌࠌࡶࡪࡺࡵࡳࡰࠣ࡬ࡹࡳ࡬ࠋࠋࠥࠦࠧ෧")
def l111l1_l1_(url,select):
	l1lll1_l1_ = [l1l11l_l1_ (u"ࠫฯ฽ศ๋ไสฮࠥอไศฮ๊ึฮࠦวๅาๆ๎ฮ࠭෨"),l1l11l_l1_ (u"ࠬาฯ้ๆࠣห้ฮัศ็ฯࠫ෩"),l1l11l_l1_ (u"࠭ว้ไสฮࠥฮัศ็ฯ๊ฬ࠭෪")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨ෫"),headers,l1l11l_l1_ (u"ࠨࠩ෬"),l1l11l_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ෭"))
	if select==l1l11l_l1_ (u"ࠪ࠶ࠬ෮"):
		l1ll1l1ll_l1_=re.findall(l1l11l_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷ࠱ࡩ࡫ࡦࡢࡷ࡯ࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࠣࠩ෯"),html,re.DOTALL)
		if l1ll1l1ll_l1_:
			block = l1ll1l1ll_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡷ࡫࡬࠾ࠤࡥࡳࡴࡱ࡭ࡢࡴ࡮ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ෰"),block,re.DOTALL)
			for img,url,title in items:
				if not any(value in title for value in l1lll1_l1_):
					title = unescapeHTML(title)
					addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෱"),menu_name+title,url,42,img)
	elif select==l1l11l_l1_ (u"ࠧ࠴ࠩෲ"):
		l1ll1l1l1_l1_=re.findall(l1l11l_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦ࠯ࡥࡳࡽ࠮࠮ࠫࡁࠬࡷࡨࡸࡩࡱࡶࠪෳ"),html,re.DOTALL)
		if l1ll1l1l1_l1_:
			block = l1ll1l1l1_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠩ࡫࠶࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭෴"),block,re.DOTALL)
			for url,title,img in items:
				if not any(value in title for value in l1lll1_l1_):
					title = unescapeHTML(title)
					addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෵"),menu_name+title,url,42,img)
	l1ll1lll1_l1_=re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡩࠩ෶"),html,re.DOTALL)
	if l1ll1lll1_l1_:
		block = l1ll1lll1_l1_[0]
		items=re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭෷"),block,re.DOTALL)
		for url,title in items:
			title = unescapeHTML(title)
			title = l1l11l_l1_ (u"࠭ีโฯฬࠤࠬ෸") + title
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ෹"),menu_name+title,url,45,l1l11l_l1_ (u"ࠨࠩ෺"),l1l11l_l1_ (u"ࠩࠪ෻"),select)
	return
def l111ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫ෼"),headers,l1l11l_l1_ (u"ࠫࠬ෽"),l1l11l_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭෾"))
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"࠭ࡥ࡯ࡶࡵࡽ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡳࡱࡣࡱࠤ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢ࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭෿"),html,re.DOTALL)
	if l1ll111_l1_:
		name = l1ll111_l1_[0]
		name = unescapeHTML(name)
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠧࡸࡲ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠲ࡹࡣࡳ࡫ࡳࡸ࠭࠴ࠪࡀࠫ࠱ࡩࡳࡺࡲࡺࠩ฀"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡳࡥࡵࡣࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࡩ࡮ࡣࡪࡩࠧࡀࡻࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡬ࡺࡳࡢࠣ࠼ࡾࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪก"),block,re.DOTALL)
			for l1111l_l1_,title,l1ll1ll1l_l1_,l1ll1l111_l1_,l1ll1l11l_l1_ in items:
				l1ll1l111_l1_ = l1ll1l111_l1_.replace(l1l11l_l1_ (u"ࠩ࡟࠳ࠬข"),l1l11l_l1_ (u"ࠪ࠳ࠬฃ"))
				l1ll1l11l_l1_ = l1ll1l11l_l1_.replace(l1l11l_l1_ (u"ࠫࡡ࠵ࠧค"),l1l11l_l1_ (u"ࠬ࠵ࠧฅ"))
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭࡜࠰ࠩฆ"),l1l11l_l1_ (u"ࠧ࠰ࠩง"))
				title = escapeUNICODE(title)
				l1111l_l1_ = escapeUNICODE(l1111l_l1_)
				title = title.split(l1l11l_l1_ (u"ࠨࠢࠪจ"))[-1]
				title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨฉ") + name + l1l11l_l1_ (u"ࠪࠤ࠲ࠦࠧช") + title
				duration = re.findall(l1l11l_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫ࡣ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩซ"),l1ll1ll1l_l1_,re.DOTALL)
				if duration: duration = duration[0]
				else:  duration = l1l11l_l1_ (u"ࠬ࠭ฌ")
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬญ"),menu_name+title,l1111l_l1_,43,l1ll1l11l_l1_,duration)
		else:
			items=re.findall(l1l11l_l1_ (u"ࠧࡪࡶࡨࡱࡵࡸ࡯ࡱ࠿ࠥࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡸ࡬ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠳࠰࠿ࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ฎ"),html,re.DOTALL)
			for title,l1111l_l1_,img in items:
				img = img.replace(l1l11l_l1_ (u"ࠨ࡞࠲ࠫฏ"),l1l11l_l1_ (u"ࠩ࠲ࠫฐ"))
				title = escapeUNICODE(title)
				l1111l_l1_ = escapeUNICODE(l1111l_l1_)
				addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩฑ"),menu_name+title,l1111l_l1_,43,img)
			#l1ll1llll_l1_(url)
	else:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵ࠮ࡵࡨࡶ࡮࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬฒ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ณ"),l1l11l_l1_ (u"࠭ࠧด"),url, block)
			items=re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ต"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧถ"),menu_name+title,l1111l_l1_,47)
	return
def PLAY(url):
	url = url.replace(l1l11l_l1_ (u"ࠩࠣࠫท"),l1l11l_l1_ (u"ࠪࠩ࠷࠶ࠧธ"))
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪน"))
	return
def l1ll11lll_l1_(url):
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠬ࠭บ"),headers,l1l11l_l1_ (u"࠭ࠧป"),l1l11l_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡓࡐࡆ࡟࡟ࡏࡇ࡚࡛ࡊࡈࡓࡊࡖࡈ࠱࠶ࡹࡴࠨผ"))
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡘࡌࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫฝ"),html,re.DOTALL)
	PLAY(l1111l_l1_[0])
	return
def CATEGORIES(url,category):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪพ"),l1l11l_l1_ (u"ࠪࠫฟ"),type, url)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠫࠬภ"),headers,l1l11l_l1_ (u"ࠬ࠭ม"),l1l11l_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩย"))
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠧࡤࡣࡷ࠵࠳ࡧ࡜ࠩ࠲࠯ࠬ࠳࠰࠿ࠪࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦࠩร"),html,re.DOTALL)
	block= l1ll111_l1_[0]
	items=re.findall(l1l11l_l1_ (u"ࠨࡥࡤࡸ࠶࠴ࡡ࡝ࠪࠫ࠲࠯ࡅࠩ࠭ࠪ࠱࠮ࡄ࠯ࠬ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠯ࡠࠬࡢࠧ࠭࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫฤ"),block,re.DOTALL)
	l1ll1ll11_l1_=False
	l1lll1_l1_ = [l1l11l_l1_ (u"ࠩ࠰࠷࠾࠿ࠧล"),l1l11l_l1_ (u"ࠪ࠹࠻࠺࠳ࠨฦ"),l1l11l_l1_ (u"ࠫ࠷࠹࠰࠷ࠩว"),l1l11l_l1_ (u"ࠬ࠻࠶࠶࠶ࠪศ"),l1l11l_l1_ (u"࠭࠱࠱࠹࠴࠺ࠬษ"),l1l11l_l1_ (u"ࠧ࠲࠲࠵࠻࠼࠭ส"),l1l11l_l1_ (u"ࠨ࠹࠼࠸࠻࠭ห")]
	for cat,parent,title,l1111l_l1_ in items:
		if parent == category and cat not in l1lll1_l1_:
			title = unescapeHTML(title)
			if l1l11l_l1_ (u"๋ࠩๆฬะࠠษำส้ั࠭ฬ") in title: continue
			if l1l11l_l1_ (u"ࠪࠬࠬอ") in title:
				title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪฮ") + title.replace(re.findall(l1l11l_l1_ (u"ࠬࠦ࡜ࠩ࠰࠭ࡃࡡ࠯ࠧฯ"),title)[0],l1l11l_l1_ (u"࠭ࠧะ"))
			url = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࠩั") + l1111l_l1_
			if cat == l1l11l_l1_ (u"ࠨ࠯࠴࠺࠺࠭า"): title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨำ") + l1l11l_l1_ (u"ࠪหู้๊ะุࠢฬฬำࠠีสิࠤ࠭࠼࠰ࠪࠩิ")
			if l1l11l_l1_ (u"ࠫ࠲࠭ี") in cat: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬึ"),menu_name+title,url,44,l1l11l_l1_ (u"࠭ࠧื"),l1l11l_l1_ (u"ࠧࠨุ"),cat)
			else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨู"),menu_name+title,url,42)
			l1ll1ll11_l1_=True
	if not l1ll1ll11_l1_: l111l1_l1_(url,l1l11l_l1_ (u"ࠩ࠶ฺࠫ"))
	return
def l1lll1111_l1_():
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ฻"),l1l11l_l1_ (u"ࠫࠬ฼"),type, url)
	html = OPENURL_CACHED(REGULAR_CACHE,l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭฽"),headers,l1l11l_l1_ (u"࠭ࠧ฾"),l1l11l_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡓࡖࡔࡍࡒࡂࡏࡖ࠱࠶ࡹࡴࠨ฿"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡯ࡨ࡫ࡦ࠳࡭ࡦࡰࡸ࠱ࡧࡲ࡯ࡤ࡭ࠫ࠲࠯ࡅࠩ࡮ࡧࡪࡥ࠲ࡳࡥ࡯ࡷࠪเ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨแ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪโ"),menu_name+title,l1111l_l1_,44)
	return
def l1lll1ll1_l1_():
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡲࡩࡷࡧࠪใ"),l1l11l_l1_ (u"ࠬ࠭ไ"),l1l11l_l1_ (u"࠭ࠧๅ"),l1l11l_l1_ (u"ࠧࠨๆ"),l1l11l_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬ็"))
	items = re.findall(l1l11l_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ่ࠧ"),html,re.DOTALL)
	url = UNQUOTE(items[0])
	#DIALOG_OK(l1l11l_l1_ (u"้ࠪࠫ"),l1l11l_l1_ (u"๊ࠫࠬ"),url,str(html))
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠬࡲࡩࡷࡧ๋ࠪ"))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ์"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨํ"): return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ๎"),l1l11l_l1_ (u"ࠩࠨ࠶࠵࠭๏"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ๐") +l1l1ll_l1_
	l111l1_l1_(url,l1l11l_l1_ (u"ࠫ࠸࠭๑"))
	return
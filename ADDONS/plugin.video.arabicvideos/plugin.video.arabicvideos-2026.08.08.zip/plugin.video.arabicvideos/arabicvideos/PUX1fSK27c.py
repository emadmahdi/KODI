# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from fRuUz1KSZi import *
class Cnhys3vcJ7dDSrOMH(nGgFqXhvLiaQdOx1plMPSecb0kKVm):
	def __init__(njQd6prxHB1y9AfhTDt5lkON2JSU,*aargs,**kkwargs):
		njQd6prxHB1y9AfhTDt5lkON2JSU.choiceID = -igM4DhpPzoX95Ysnar6Auj
	def onClick(njQd6prxHB1y9AfhTDt5lkON2JSU,qwRf3nTJD7bMB51WKhLVjcZaGx84Fd):
		if qwRf3nTJD7bMB51WKhLVjcZaGx84Fd>=CMUXq6mPQV5rLsSBdWZJvA(u"࠹࠱࠳࠳౱"): njQd6prxHB1y9AfhTDt5lkON2JSU.choiceID = qwRf3nTJD7bMB51WKhLVjcZaGx84Fd-CMUXq6mPQV5rLsSBdWZJvA(u"࠹࠱࠳࠳౱")
		njQd6prxHB1y9AfhTDt5lkON2JSU.V4N1lDopv9Amc0SXJ()
	def zfn8Ghd56uAkHN1OExRLbQ(njQd6prxHB1y9AfhTDt5lkON2JSU,*aargs):
		njQd6prxHB1y9AfhTDt5lkON2JSU.button0,njQd6prxHB1y9AfhTDt5lkON2JSU.button1,njQd6prxHB1y9AfhTDt5lkON2JSU.button2 = aargs[nxUveizbLEAT2FBNy3],aargs[igM4DhpPzoX95Ysnar6Auj],aargs[s0sB2Xyp9uYU5N3fxzKoLW8]
		njQd6prxHB1y9AfhTDt5lkON2JSU.header,njQd6prxHB1y9AfhTDt5lkON2JSU.text = aargs[Q5yM0D6SaP9teHXufTGjUBc],aargs[HHQhABuNKV7cd]
		njQd6prxHB1y9AfhTDt5lkON2JSU.profile,njQd6prxHB1y9AfhTDt5lkON2JSU.direction = aargs[ssYkHaML9z37bJ0StuEBXIqgiV(u"࠶౲")],aargs[MBS1GrwQoUlsiIRfVDOHdA(u"࠸౳")]
		njQd6prxHB1y9AfhTDt5lkON2JSU.buttonstimeout,njQd6prxHB1y9AfhTDt5lkON2JSU.closetimeout = aargs[SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠻౵")],aargs[NZiEOAWrSX1u2gU05DR6TB8tm(u"࠻౴")]
		if njQd6prxHB1y9AfhTDt5lkON2JSU.buttonstimeout>nxUveizbLEAT2FBNy3 or njQd6prxHB1y9AfhTDt5lkON2JSU.closetimeout>Urj6egiVyHA75ZK(u"࠵౶"): njQd6prxHB1y9AfhTDt5lkON2JSU.enable_progressbar = dbo4vrnTM56I
		else: njQd6prxHB1y9AfhTDt5lkON2JSU.enable_progressbar = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename = KIyJ8Q1qLwhsDt90eHX.replace(MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ௟"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡢࠫ௠")+str(pVesmhFG6wgubAODHSKvN1Wx.time())+HHthiRYs8T6IO3qUyX(u"ࠪࡣࠬ௡"))
		njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename = njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename.replace(dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡡࡢࠧ௢"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡢ࡜࡝࡞ࠪ௣")).replace(bruAOCB4ZoHVF7,taD1d3bpqyfM4VNhK0P29GSZ(u"࠭࠯࠰࠱࠲ࠫ௤"))
		njQd6prxHB1y9AfhTDt5lkON2JSU.image_height = rNMO5BvD6dICWcRw2FT(njQd6prxHB1y9AfhTDt5lkON2JSU.button0,njQd6prxHB1y9AfhTDt5lkON2JSU.button1,njQd6prxHB1y9AfhTDt5lkON2JSU.button2,njQd6prxHB1y9AfhTDt5lkON2JSU.header,njQd6prxHB1y9AfhTDt5lkON2JSU.text,njQd6prxHB1y9AfhTDt5lkON2JSU.profile,njQd6prxHB1y9AfhTDt5lkON2JSU.direction,njQd6prxHB1y9AfhTDt5lkON2JSU.enable_progressbar,njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename)
		njQd6prxHB1y9AfhTDt5lkON2JSU.show()
		njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(NZiEOAWrSX1u2gU05DR6TB8tm(u"࠿࠰࠶࠲౷")).setImage(njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename)
		njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(J6G8X3gO1MiKh027D(u"࠹࠱࠷࠳౸")).setHeight(njQd6prxHB1y9AfhTDt5lkON2JSU.image_height)
		if not njQd6prxHB1y9AfhTDt5lkON2JSU.button1 and njQd6prxHB1y9AfhTDt5lkON2JSU.button0 and njQd6prxHB1y9AfhTDt5lkON2JSU.button2: njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(ZeV4vau9CjN(u"࠻࠳࠵࠷౺")).setPosition(-SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠵࠶࠵౻"),u8iSx05wLfVyMNp1X3l(u"࠱౹"))
		return njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename,njQd6prxHB1y9AfhTDt5lkON2JSU.image_height
	def qWc2exwG1KAIr0b(njQd6prxHB1y9AfhTDt5lkON2JSU):
		if njQd6prxHB1y9AfhTDt5lkON2JSU.buttonstimeout:
			njQd6prxHB1y9AfhTDt5lkON2JSU.th1 = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=njQd6prxHB1y9AfhTDt5lkON2JSU.yHFXbwNV3Y8vLnt1qA5ocfZxrRlU)
			njQd6prxHB1y9AfhTDt5lkON2JSU.th1.start()
		else: njQd6prxHB1y9AfhTDt5lkON2JSU.YYOAcIRZC98mG1dfD6s()
	def yHFXbwNV3Y8vLnt1qA5ocfZxrRlU(njQd6prxHB1y9AfhTDt5lkON2JSU):
		njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(WlU7AtONpyj3(u"࠽࠵࠸࠰౼")).setEnabled(dbo4vrnTM56I)
		for aaHueZUKGJDOvqjAy6CTinMIY in range(igM4DhpPzoX95Ysnar6Auj,njQd6prxHB1y9AfhTDt5lkON2JSU.buttonstimeout+igM4DhpPzoX95Ysnar6Auj):
			pVesmhFG6wgubAODHSKvN1Wx.sleep(igM4DhpPzoX95Ysnar6Auj)
			hDPoNu1ami5KbXLV2FCdSr = int(YoMw2J1Ljp(u"࠶࠶࠰౽")*aaHueZUKGJDOvqjAy6CTinMIY/njQd6prxHB1y9AfhTDt5lkON2JSU.buttonstimeout)
			njQd6prxHB1y9AfhTDt5lkON2JSU.GZRW8ElLqp16CsodJTny(hDPoNu1ami5KbXLV2FCdSr)
			if njQd6prxHB1y9AfhTDt5lkON2JSU.choiceID>x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠶౾"): break
		njQd6prxHB1y9AfhTDt5lkON2JSU.YYOAcIRZC98mG1dfD6s()
	def mmOxRozcQ0XnDPe8EuG(njQd6prxHB1y9AfhTDt5lkON2JSU):
		if njQd6prxHB1y9AfhTDt5lkON2JSU.closetimeout:
			njQd6prxHB1y9AfhTDt5lkON2JSU.th2 = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=njQd6prxHB1y9AfhTDt5lkON2JSU.YC16qcL9oKJlzk4i)
			njQd6prxHB1y9AfhTDt5lkON2JSU.th2.start()
		else: njQd6prxHB1y9AfhTDt5lkON2JSU.YYOAcIRZC98mG1dfD6s()
	def YC16qcL9oKJlzk4i(njQd6prxHB1y9AfhTDt5lkON2JSU):
		njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(G6GUCto502jZTLubYNnqMx8ywBah(u"࠹࠱࠴࠳౿")).setEnabled(dbo4vrnTM56I)
		pVesmhFG6wgubAODHSKvN1Wx.sleep(njQd6prxHB1y9AfhTDt5lkON2JSU.buttonstimeout)
		for aaHueZUKGJDOvqjAy6CTinMIY in range(njQd6prxHB1y9AfhTDt5lkON2JSU.closetimeout-igM4DhpPzoX95Ysnar6Auj,-igM4DhpPzoX95Ysnar6Auj,-igM4DhpPzoX95Ysnar6Auj):
			pVesmhFG6wgubAODHSKvN1Wx.sleep(igM4DhpPzoX95Ysnar6Auj)
			hDPoNu1ami5KbXLV2FCdSr = int(wnVICNyfE3XZ0htUaDFAOgLo(u"࠲࠲࠳ಀ")*aaHueZUKGJDOvqjAy6CTinMIY/njQd6prxHB1y9AfhTDt5lkON2JSU.closetimeout)
			njQd6prxHB1y9AfhTDt5lkON2JSU.GZRW8ElLqp16CsodJTny(hDPoNu1ami5KbXLV2FCdSr)
			if njQd6prxHB1y9AfhTDt5lkON2JSU.choiceID>nxUveizbLEAT2FBNy3: break
		if njQd6prxHB1y9AfhTDt5lkON2JSU.closetimeout>nxUveizbLEAT2FBNy3: njQd6prxHB1y9AfhTDt5lkON2JSU.choiceID = gNPRXprEAQJ(u"࠳࠳ಁ")
		njQd6prxHB1y9AfhTDt5lkON2JSU.V4N1lDopv9Amc0SXJ()
	def GZRW8ElLqp16CsodJTny(njQd6prxHB1y9AfhTDt5lkON2JSU,hDPoNu1ami5KbXLV2FCdSr):
		njQd6prxHB1y9AfhTDt5lkON2JSU.precent = hDPoNu1ami5KbXLV2FCdSr
		njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(CMUXq6mPQV5rLsSBdWZJvA(u"࠼࠴࠷࠶ಂ")).setPercent(njQd6prxHB1y9AfhTDt5lkON2JSU.precent)
	def YYOAcIRZC98mG1dfD6s(njQd6prxHB1y9AfhTDt5lkON2JSU):
		if njQd6prxHB1y9AfhTDt5lkON2JSU.button0: njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(sdRqnego9PclrL4m2J(u"࠽࠵࠷࠰ಃ")).setEnabled(dbo4vrnTM56I)
		if njQd6prxHB1y9AfhTDt5lkON2JSU.button1: njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(FkqI4Gm8wMvUVbgo(u"࠾࠶࠱࠲಄")).setEnabled(dbo4vrnTM56I)
		if njQd6prxHB1y9AfhTDt5lkON2JSU.button2: njQd6prxHB1y9AfhTDt5lkON2JSU.getControl(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠿࠰࠲࠴ಅ")).setEnabled(dbo4vrnTM56I)
	def V4N1lDopv9Amc0SXJ(njQd6prxHB1y9AfhTDt5lkON2JSU):
		njQd6prxHB1y9AfhTDt5lkON2JSU.close()
		try: YdDkIjFhgzuboBKca70ERt.remove(njQd6prxHB1y9AfhTDt5lkON2JSU.image_filename)
		except: pass
def o1OgjEBsS0aKNl6T7LyAXWfmQ(*aargs,**kkwargs):
	if aargs:
		direction = aargs[nxUveizbLEAT2FBNy3]
		cmt3w1CPlkTzjAKieugL6vWFb = aargs[igM4DhpPzoX95Ysnar6Auj]
		if not direction: direction = wb1nC3e8AjRVU4ovsuPa(u"ࠧࡤࡧࡱࡸࡪࡸࠧ௥")
		if not cmt3w1CPlkTzjAKieugL6vWFb: cmt3w1CPlkTzjAKieugL6vWFb = dQvxmFkyLOteNMWBJ2bDHV(u"ࠨษึฮ๊ืวาࠩ௦")
		k9r2PUz8LYxjBs6QA = aargs[s0sB2Xyp9uYU5N3fxzKoLW8]
		lMBt2kFfevrWmz5GIsgS4NnAcH = URBvawyLXfQiS2NI34HDk.join(aargs[z8wTfYPiRQL(u"࠳ಆ"):])
	else: direction,cmt3w1CPlkTzjAKieugL6vWFb,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH = kh850jKbzmBwY,WlU7AtONpyj3(u"ࠩࡒࡏࠬ௧"),kh850jKbzmBwY,kh850jKbzmBwY
	NJZUGpSmQLPBxuv3Mn(direction,kh850jKbzmBwY,cmt3w1CPlkTzjAKieugL6vWFb,kh850jKbzmBwY,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,**kkwargs)
	return
def aa48i0SKpcGbWFBYLtCre(*aargs,**kkwargs):
	direction = aargs[nxUveizbLEAT2FBNy3]
	dSzThtDPM4V1kFgKQ0JcqECyorL = aargs[igM4DhpPzoX95Ysnar6Auj]
	DX95FrLWv37jlKT2ItasiqPxc = aargs[s0sB2Xyp9uYU5N3fxzKoLW8]
	if DX95FrLWv37jlKT2ItasiqPxc or dSzThtDPM4V1kFgKQ0JcqECyorL: mmn6kY3GIcHDSywbEJRAgjvsxet = dbo4vrnTM56I
	else: mmn6kY3GIcHDSywbEJRAgjvsxet = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	k9r2PUz8LYxjBs6QA = aargs[Q5yM0D6SaP9teHXufTGjUBc]
	lMBt2kFfevrWmz5GIsgS4NnAcH = aargs[HHQhABuNKV7cd]
	if not direction: direction = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡧࡪࡴࡴࡦࡴࠪ௨")
	if not dSzThtDPM4V1kFgKQ0JcqECyorL: dSzThtDPM4V1kFgKQ0JcqECyorL = FkqI4Gm8wMvUVbgo(u"่๊ࠫวࠡࠢࡑࡳࠬ௩")
	if not DX95FrLWv37jlKT2ItasiqPxc: DX95FrLWv37jlKT2ItasiqPxc = aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ௪")
	if len(aargs)>=HHthiRYs8T6IO3qUyX(u"࠸ಈ"): lMBt2kFfevrWmz5GIsgS4NnAcH += URBvawyLXfQiS2NI34HDk+aargs[z8wTfYPiRQL(u"࠶ಇ")]
	if len(aargs)>=XasF0WO7rDUHnEt8hAl9kLN(u"࠺ಉ"): lMBt2kFfevrWmz5GIsgS4NnAcH += URBvawyLXfQiS2NI34HDk+aargs[SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠺ಊ")]
	OGIekTnvLMdDym = NJZUGpSmQLPBxuv3Mn(direction,dSzThtDPM4V1kFgKQ0JcqECyorL,kh850jKbzmBwY,DX95FrLWv37jlKT2ItasiqPxc,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,**kkwargs)
	if OGIekTnvLMdDym==-HHthiRYs8T6IO3qUyX(u"࠶ಋ") and mmn6kY3GIcHDSywbEJRAgjvsxet: OGIekTnvLMdDym = -igM4DhpPzoX95Ysnar6Auj
	elif OGIekTnvLMdDym==-igM4DhpPzoX95Ysnar6Auj and not mmn6kY3GIcHDSywbEJRAgjvsxet: OGIekTnvLMdDym = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	elif OGIekTnvLMdDym==nxUveizbLEAT2FBNy3: OGIekTnvLMdDym = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	elif OGIekTnvLMdDym==s0sB2Xyp9uYU5N3fxzKoLW8: OGIekTnvLMdDym = dbo4vrnTM56I
	return OGIekTnvLMdDym
def W6EMASlVYF0gvGmzo(*aargs,**kkwargs):
	return SSDm5G4FUAzu26LbKqpvV79d.Dialog().select(*aargs,**kkwargs)
def o4n5ehzyjHTWdL8(*args,**kwargs):
	k9r2PUz8LYxjBs6QA = args[nxUveizbLEAT2FBNy3]
	lMBt2kFfevrWmz5GIsgS4NnAcH = args[igM4DhpPzoX95Ysnar6Auj]
	if len(args) > s0sB2Xyp9uYU5N3fxzKoLW8 and J6G8X3gO1MiKh027D(u"࠭ࡴࡪ࡯ࡨࠫ௫") not in str(args[qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠸ಌ")]):
		WZU4iLQ1dF8nHusCTvA = args[s0sB2Xyp9uYU5N3fxzKoLW8]
		HIjfZDsYEz81W9tFASgcybPOo = kwargs.get(ZeV4vau9CjN(u"ࠧࡵ࡫ࡰࡩࠬ௬"), qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠱࠱࠲࠳಍"))
	else:
		WZU4iLQ1dF8nHusCTvA = Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨ௭")
		HIjfZDsYEz81W9tFASgcybPOo = args[s0sB2Xyp9uYU5N3fxzKoLW8] if len(args) > s0sB2Xyp9uYU5N3fxzKoLW8 else kwargs.get(J6G8X3gO1MiKh027D(u"ࠩࡷ࡭ࡲ࡫ࠧ௮"), YoMw2J1Ljp(u"࠲࠲࠳࠴ಎ"))
	QApCLZzTSmUnwJyg = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=SoDPhwFiYM12BZufXgvT7qNH6Izp,args=(k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,WZU4iLQ1dF8nHusCTvA,HIjfZDsYEz81W9tFASgcybPOo))
	QApCLZzTSmUnwJyg.start()
	return
def SoDPhwFiYM12BZufXgvT7qNH6Izp(k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,WZU4iLQ1dF8nHusCTvA,HIjfZDsYEz81W9tFASgcybPOo):
	uunI6S1vaKxepftFMBA = WZU4iLQ1dF8nHusCTvA.replace(taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪ௯"),kh850jKbzmBwY)
	import NNeGzpnkuF
	name = NNeGzpnkuF.QwbOcSlDzkaXm07x2ioyNYJWqfsCE1(dbo4vrnTM56I,uunI6S1vaKxepftFMBA+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫࠥ࠳ࠠࠨ௰")+k9r2PUz8LYxjBs6QA+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࠦ࠭ࠡࠩ௱")+lMBt2kFfevrWmz5GIsgS4NnAcH)
	name = NNeGzpnkuF.MMNV8Ogb9iJ4TD1EQq(name)
	image_filename = YdDkIjFhgzuboBKca70ERt.path.join(KK3fcUvjoZ8GnSkxiOFpIBgsa,name+Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭࠮ࡱࡰࡪࠫ௲"))
	if YdDkIjFhgzuboBKca70ERt.path.exists(image_filename):
		if WZU4iLQ1dF8nHusCTvA==MBS1GrwQoUlsiIRfVDOHdA(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ௳"): image_height = gNPRXprEAQJ(u"࠳࠴࠻ಏ")
		elif WZU4iLQ1dF8nHusCTvA==HHthiRYs8T6IO3qUyX(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬ௴"): image_height = HHthiRYs8T6IO3qUyX(u"࠵࠵࠵ಐ")
	else: image_height = rNMO5BvD6dICWcRw2FT(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,WZU4iLQ1dF8nHusCTvA,u8iSx05wLfVyMNp1X3l(u"ࠩ࡯ࡩ࡫ࡺࠧ௵"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,image_filename)
	pB783WdQotakUPxMKymOE1lnR = nGgFqXhvLiaQdOx1plMPSecb0kKVm(BBOY8rvinVbFh(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪ௶"),LgbODRkm2KcsCZpN9JwEHhovdt71,z8wTfYPiRQL(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ௷"),gNPRXprEAQJ(u"ࠬ࠽࠲࠱ࡲࠪ௸"))
	pB783WdQotakUPxMKymOE1lnR.show()
	if WZU4iLQ1dF8nHusCTvA==HHthiRYs8T6IO3qUyX(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪ௹"):
		pB783WdQotakUPxMKymOE1lnR.getControl(XasF0WO7rDUHnEt8hAl9kLN(u"࠾࠶࠴࠱ಒ")).setHeight(MBS1GrwQoUlsiIRfVDOHdA(u"࠶࠶࠻಑"))
		pB783WdQotakUPxMKymOE1lnR.getControl(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠺࠲࠷࠴ಕ")).setPosition(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠻࠵ಓ"),-HfuZG0aphlYnVLOyAk93rj(u"࠸࠱ಔ"))
		pB783WdQotakUPxMKymOE1lnR.getControl(wnVICNyfE3XZ0htUaDFAOgLo(u"࠻࠳࠹࠵ಖ")).setPosition(YoMw2J1Ljp(u"࠴࠶࠵ಗ"),-ZeV4vau9CjN(u"࠺࠵ಘ"))
		pB783WdQotakUPxMKymOE1lnR.getControl(wnVICNyfE3XZ0htUaDFAOgLo(u"࠴࠱࠲ಛ")).setPosition(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠾࠶ಙ"),-J6G8X3gO1MiKh027D(u"࠹࠵ಚ"))
	pB783WdQotakUPxMKymOE1lnR.getControl(wb1nC3e8AjRVU4ovsuPa(u"࠵࠲࠴ಜ")).setVisible(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	pB783WdQotakUPxMKymOE1lnR.getControl(u8iSx05wLfVyMNp1X3l(u"࠶࠳࠶ಝ")).setVisible(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	pB783WdQotakUPxMKymOE1lnR.getControl(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠼࠴࠺࠶ಞ")).setImage(image_filename)
	pB783WdQotakUPxMKymOE1lnR.getControl(BBOY8rvinVbFh(u"࠽࠵࠻࠰ಟ")).setHeight(image_height)
	pVesmhFG6wgubAODHSKvN1Wx.sleep(HIjfZDsYEz81W9tFASgcybPOo/Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠶࠶࠰࠱࠰࠳ಠ"))
	return
def Z7XaWzvgUpr4YhSjTyfPk(*aargs,**kkwargs):
	k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,profile,direction = kh850jKbzmBwY,kh850jKbzmBwY,WlU7AtONpyj3(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ௺"),WlU7AtONpyj3(u"ࠨ࡮ࡨࡪࡹ࠭௻")
	if len(aargs)>=igM4DhpPzoX95Ysnar6Auj: k9r2PUz8LYxjBs6QA = aargs[nxUveizbLEAT2FBNy3]
	if len(aargs)>=s0sB2Xyp9uYU5N3fxzKoLW8: lMBt2kFfevrWmz5GIsgS4NnAcH = aargs[igM4DhpPzoX95Ysnar6Auj]
	if len(aargs)>=Q5yM0D6SaP9teHXufTGjUBc: profile = aargs[s0sB2Xyp9uYU5N3fxzKoLW8]
	if len(aargs)>=HHQhABuNKV7cd: direction = aargs[Q5yM0D6SaP9teHXufTGjUBc]
	return KKHpNde5TOmYqjIygtlwhf7W2sr(direction,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,profile)
def gPYeVMwT5u1EQkpl2BGNZHXd(*aargs,**kkwargs):
	return SSDm5G4FUAzu26LbKqpvV79d.Dialog().contextmenu(*aargs,**kkwargs)
def Digl6HdJyQ15s2rZamnfxc3SRI(*aargs,**kkwargs):
	return SSDm5G4FUAzu26LbKqpvV79d.Dialog().browseSingle(*aargs,**kkwargs)
def s0KgwLzXHxrdWYRfPhjlN2(*aargs,**kkwargs):
	return SSDm5G4FUAzu26LbKqpvV79d.Dialog().input(*aargs,**kkwargs)
def aaXbN7lmtKqzc2C9JVDi(*aargs,**kkwargs):
	return SSDm5G4FUAzu26LbKqpvV79d.DialogProgress(*aargs,**kkwargs)
def NJZUGpSmQLPBxuv3Mn(direction,button0=kh850jKbzmBwY,button1=kh850jKbzmBwY,button2=kh850jKbzmBwY,k9r2PUz8LYxjBs6QA=kh850jKbzmBwY,lMBt2kFfevrWmz5GIsgS4NnAcH=kh850jKbzmBwY,profile=SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ௼"),dvJXm5Liw1YMOoVQrg=nxUveizbLEAT2FBNy3,AaQBOe2Ld1umjKsNM4iPyEYth5w=nxUveizbLEAT2FBNy3):
	if not direction: direction = FkqI4Gm8wMvUVbgo(u"ࠪࡧࡪࡴࡴࡦࡴࠪ௽")
	pB783WdQotakUPxMKymOE1lnR = Cnhys3vcJ7dDSrOMH(HfuZG0aphlYnVLOyAk93rj(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭௾"),LgbODRkm2KcsCZpN9JwEHhovdt71,WlU7AtONpyj3(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭௿"),YoMw2J1Ljp(u"࠭࠷࠳࠲ࡳࠫఀ"))
	pB783WdQotakUPxMKymOE1lnR.zfn8Ghd56uAkHN1OExRLbQ(button0,button1,button2,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,profile,direction,dvJXm5Liw1YMOoVQrg,AaQBOe2Ld1umjKsNM4iPyEYth5w)
	if dvJXm5Liw1YMOoVQrg>nxUveizbLEAT2FBNy3: pB783WdQotakUPxMKymOE1lnR.qWc2exwG1KAIr0b()
	if AaQBOe2Ld1umjKsNM4iPyEYth5w>nxUveizbLEAT2FBNy3: pB783WdQotakUPxMKymOE1lnR.mmOxRozcQ0XnDPe8EuG()
	if dvJXm5Liw1YMOoVQrg==nxUveizbLEAT2FBNy3 and AaQBOe2Ld1umjKsNM4iPyEYth5w==nxUveizbLEAT2FBNy3: pB783WdQotakUPxMKymOE1lnR.YYOAcIRZC98mG1dfD6s()
	pB783WdQotakUPxMKymOE1lnR.doModal()
	OGIekTnvLMdDym = pB783WdQotakUPxMKymOE1lnR.choiceID
	return OGIekTnvLMdDym
def KKHpNde5TOmYqjIygtlwhf7W2sr(direction,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,profile=XasF0WO7rDUHnEt8hAl9kLN(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨఁ")):
	if not direction: direction = G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨ࡮ࡨࡪࡹ࠭ం")
	pB783WdQotakUPxMKymOE1lnR = nGgFqXhvLiaQdOx1plMPSecb0kKVm(HfuZG0aphlYnVLOyAk93rj(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬః"),LgbODRkm2KcsCZpN9JwEHhovdt71,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫఄ"),BBOY8rvinVbFh(u"ࠫ࠼࠸࠰ࡱࠩఅ"))
	image_filename = KIyJ8Q1qLwhsDt90eHX.replace(J6G8X3gO1MiKh027D(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬఆ"),wb1nC3e8AjRVU4ovsuPa(u"࠭࡟ࠨఇ")+str(pVesmhFG6wgubAODHSKvN1Wx.time())+XasF0WO7rDUHnEt8hAl9kLN(u"ࠧࡠࠩఈ"))
	image_filename = image_filename.replace(BBOY8rvinVbFh(u"ࠨ࡞࡟ࠫఉ"),HfuZG0aphlYnVLOyAk93rj(u"ࠩ࡟ࡠࡡࡢࠧఊ")).replace(bruAOCB4ZoHVF7,FkqI4Gm8wMvUVbgo(u"ࠪ࠳࠴࠵࠯ࠨఋ"))
	image_height = rNMO5BvD6dICWcRw2FT(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,k9r2PUz8LYxjBs6QA,lMBt2kFfevrWmz5GIsgS4NnAcH,profile,direction,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,image_filename)
	pB783WdQotakUPxMKymOE1lnR.show()
	pB783WdQotakUPxMKymOE1lnR.getControl(tzEjvOaZWU1A(u"࠿࠰࠶࠲ಡ")).setHeight(image_height)
	pB783WdQotakUPxMKymOE1lnR.getControl(tzEjvOaZWU1A(u"࠹࠱࠷࠳ಢ")).setImage(image_filename)
	f2fhC36kNaiB9KYQSpwgdsru7 = pB783WdQotakUPxMKymOE1lnR.doModal()
	try: YdDkIjFhgzuboBKca70ERt.remove(image_filename)
	except: pass
	return f2fhC36kNaiB9KYQSpwgdsru7
def rNMO5BvD6dICWcRw2FT(chVO2pfUCoj6SksDTlaq,PdT7YZUKWahEnHfcyClkG5sJbrFR,GHLdcMJ5aCoptRe9DBbIPrs,piDNqYaCZ3wPFhSk7UJTtdx,fRJYhnSKHsZ7MqFwmiVz,vvIgUDnbOPV3zA9laZFtJi5YHLmd,FF4sQC1Bbm9jlgtYniqRp6kIdWJuLO,vHpedmuDWao4wXN8gIh7M,a2i6rMkgwBuyoEAFtPLlqjpRVOGI):
	f0jvTrH4D8 = YdDkIjFhgzuboBKca70ERt.path.dirname(a2i6rMkgwBuyoEAFtPLlqjpRVOGI)
	if not YdDkIjFhgzuboBKca70ERt.path.exists(f0jvTrH4D8):
		try: YdDkIjFhgzuboBKca70ERt.makedirs(f0jvTrH4D8)
		except: pass
	JJA5CEWvHfQryca6SdXMbzq = rhxvFSocgMqPei9f1IJ(vvIgUDnbOPV3zA9laZFtJi5YHLmd)
	jWr1dXlGMySKZbAsP93OqeFpk = OjpKsIQ7ZbrJDqoc8gfdmiMS2B(JJA5CEWvHfQryca6SdXMbzq,chVO2pfUCoj6SksDTlaq,PdT7YZUKWahEnHfcyClkG5sJbrFR,GHLdcMJ5aCoptRe9DBbIPrs,piDNqYaCZ3wPFhSk7UJTtdx,fRJYhnSKHsZ7MqFwmiVz,vvIgUDnbOPV3zA9laZFtJi5YHLmd,FF4sQC1Bbm9jlgtYniqRp6kIdWJuLO,vHpedmuDWao4wXN8gIh7M,a2i6rMkgwBuyoEAFtPLlqjpRVOGI)
	return jWr1dXlGMySKZbAsP93OqeFpk
def rhxvFSocgMqPei9f1IJ(vvIgUDnbOPV3zA9laZFtJi5YHLmd):
	j3Gce65kIvlyCRZ7tzKYaVq = XONpB38LESgyRmt
	U0G37bKqOItaAkpzhM6wQfuyDZ = u8iSx05wLfVyMNp1X3l(u"࠳࠲ಣ")
	tpxbz06qEDXn = wb1nC3e8AjRVU4ovsuPa(u"࠴࠳ತ")
	scxqV32JKGABlyaX = nxUveizbLEAT2FBNy3
	bbHQVrYi2l1mc = Urj6egiVyHA75ZK(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫఌ")
	vg6Ru2ptKHWVF = nxUveizbLEAT2FBNy3
	ewBu2LTZYPyHG = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠴࠽ಥ")
	IgVNsbm3rk02UwyhTu = YoMw2J1Ljp(u"࠷࠵ದ")
	PC42aRBAuMHU3E5OewstxZ8pofD = wnVICNyfE3XZ0htUaDFAOgLo(u"࠽ಧ")
	dabW9cQorezk = dbo4vrnTM56I
	XoDk9s5YClI = FkqI4Gm8wMvUVbgo(u"࠹࠷࠶ನ")
	heL7gwbiytDZ4vJzoBIdGKEFxV5f = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠴࠲࠲಩")
	qq84MJV2rOAzhcN10wdt = gNPRXprEAQJ(u"࠶࠲ಪ")
	p0Mj2ozcCKQF4nV9Eg7dwYUb = taD1d3bpqyfM4VNhK0P29GSZ(u"࠴࠻࠴ಫ")
	wq0UC3N1IuDnFYZT5X7Mdj6fgVt = wnVICNyfE3XZ0htUaDFAOgLo(u"࠵࠼ಬ")
	QEi4oZvYcGw2MKH = XONpB38LESgyRmt
	kgfpHqDaCP0Z3VKoN9TjIS5 = nxUveizbLEAT2FBNy3
	gLCmuaJMbljfHUTOtdrD3Qp8yPI = u8iSx05wLfVyMNp1X3l(u"࠷࠶ಭ")
	JaP78r0DShfgl6t4QpK2V9 = [x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠳࠷ರ"),Urj6egiVyHA75ZK(u"࠸࠸ಮ"),BBOY8rvinVbFh(u"࠸࠸ಯ")]
	from PIL import ImageDraw as Tk3fFn6NlOQUr4KhL2vJSPi71jG8,ImageFont as EE3yNOsZ4SzuWpg16inm9LDatbj5rw,Image as QTUZ8trfRMkVD7zCoOL5
	if HfuZG0aphlYnVLOyAk93rj(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ఍") in vvIgUDnbOPV3zA9laZFtJi5YHLmd:
		if vvIgUDnbOPV3zA9laZFtJi5YHLmd==u8iSx05wLfVyMNp1X3l(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡸࡥࡨࡷ࡯ࡥࡷ࠭ఎ"):
			KlQJmCqvkD = Urj6egiVyHA75ZK(u"࠲࠳࠺ಱ")
			bbHQVrYi2l1mc = G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧ࡭ࡧࡩࡸࠬఏ")
			dabW9cQorezk = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==XasF0WO7rDUHnEt8hAl9kLN(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬఐ"):
			KlQJmCqvkD = sdRqnego9PclrL4m2J(u"ࠩࡘࡔࡕࡋࡒࠨ఑")
			bbHQVrYi2l1mc = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪࡶ࡮࡭ࡨࡵࠩఒ")
			scxqV32JKGABlyaX = dQvxmFkyLOteNMWBJ2bDHV(u"࠳࠳ಲ")
		Fsp2z0ctjY = tzEjvOaZWU1A(u"࠺࠶࠵ಳ")
		JaP78r0DShfgl6t4QpK2V9 = [tzEjvOaZWU1A(u"࠷࠸಴"),tzEjvOaZWU1A(u"࠷࠸಴"),tzEjvOaZWU1A(u"࠷࠸಴")]
		tpxbz06qEDXn = YoMw2J1Ljp(u"࠷࠶ವ")
		U0G37bKqOItaAkpzhM6wQfuyDZ = nxUveizbLEAT2FBNy3
		IgVNsbm3rk02UwyhTu = Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠸࠰ಶ")
		ewBu2LTZYPyHG = J6G8X3gO1MiKh027D(u"࠳࠶ಷ")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==YoMw2J1Ljp(u"ࠫࡲ࡫࡮ࡶࡡ࡬ࡸࡪࡳࠧఓ"):
		JaP78r0DShfgl6t4QpK2V9,Fsp2z0ctjY,KlQJmCqvkD = [u8iSx05wLfVyMNp1X3l(u"࠵࠼಺"),u8iSx05wLfVyMNp1X3l(u"࠵࠼಺"),u8iSx05wLfVyMNp1X3l(u"࠵࠼಺")],Urj6egiVyHA75ZK(u"࠳࠲࠳ಸ"),dQvxmFkyLOteNMWBJ2bDHV(u"࠴࠸࠴ಹ")
		vg6Ru2ptKHWVF,IgVNsbm3rk02UwyhTu,ewBu2LTZYPyHG, = nxUveizbLEAT2FBNy3,-qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠵࠷಻"),-ssYkHaML9z37bJ0StuEBXIqgiV(u"࠸࠶಼")
		U0G37bKqOItaAkpzhM6wQfuyDZ = nxUveizbLEAT2FBNy3
		uuLOEMCUAhsJ0w7521oKyj = QTUZ8trfRMkVD7zCoOL5.open(fJOjp8Gxr7Rh9dnZL056Bzag1uve)
		zkD5Qsh6dZgFXSbV9tOY = QTUZ8trfRMkVD7zCoOL5.new(J6G8X3gO1MiKh027D(u"ࠬࡘࡇࡃࡃࠪఔ"),(Fsp2z0ctjY,KlQJmCqvkD),(gNPRXprEAQJ(u"࠸࠵࠶ಽ"),nxUveizbLEAT2FBNy3,nxUveizbLEAT2FBNy3,gNPRXprEAQJ(u"࠸࠵࠶ಽ")))
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==J6G8X3gO1MiKh027D(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪక"): JaP78r0DShfgl6t4QpK2V9,KlQJmCqvkD,Fsp2z0ctjY = [qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠵࠼ು"),XasF0WO7rDUHnEt8hAl9kLN(u"࠲࠵ಾ"),WlU7AtONpyj3(u"࠳࠲ಿ")],YoMw2J1Ljp(u"࠹࠵࠶ೂ"),gNPRXprEAQJ(u"࠻࠳࠴ೀ")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==FkqI4Gm8wMvUVbgo(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬఖ"): JaP78r0DShfgl6t4QpK2V9,KlQJmCqvkD,Fsp2z0ctjY = [x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠹࠲ೄ"),YoMw2J1Ljp(u"࠳࠺ೆ"),G6GUCto502jZTLubYNnqMx8ywBah(u"࠷࠺ೃ")],x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠷࠳࠴ೇ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠹࠱࠲೅")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==HHthiRYs8T6IO3qUyX(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪగ"): JaP78r0DShfgl6t4QpK2V9,KlQJmCqvkD,Fsp2z0ctjY = [wnVICNyfE3XZ0htUaDFAOgLo(u"࠹࠶ೋ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠶࠶ೈ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠷࠾ೊ")],taD1d3bpqyfM4VNhK0P29GSZ(u"࠵࠱࠲ೌ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠽࠵࠶೉")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬఘ"): KlQJmCqvkD,Fsp2z0ctjY = wb1nC3e8AjRVU4ovsuPa(u"࠸࠶࠳್"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠳࠵࠻࠵೎")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==HfuZG0aphlYnVLOyAk93rj(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫఙ"): KlQJmCqvkD,Fsp2z0ctjY = J6G8X3gO1MiKh027D(u"࡚ࠫࡖࡐࡆࡔࠪచ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠴࠶࠼࠶೏")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪఛ"): JaP78r0DShfgl6t4QpK2V9,KlQJmCqvkD,Fsp2z0ctjY = [WlU7AtONpyj3(u"࠲࠹೓"),XasF0WO7rDUHnEt8hAl9kLN(u"࠳࠵೔"),taD1d3bpqyfM4VNhK0P29GSZ(u"࠶࠾೑")],wnVICNyfE3XZ0htUaDFAOgLo(u"࠻࠹࠶೐"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠷࠲࠸࠲೒")
	elif vvIgUDnbOPV3zA9laZFtJi5YHLmd==sdRqnego9PclrL4m2J(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩజ"): JaP78r0DShfgl6t4QpK2V9,KlQJmCqvkD,Fsp2z0ctjY = [aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠶࠽೗"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠷࠹೘"),sdRqnego9PclrL4m2J(u"࠴࠼ೖ")],SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡖࡒࡓࡉࡗ࠭ఝ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠳࠵࠻࠵ೕ")
	ecuF02YlIBmi5S9xUP3AwQrHnW8oj,Z8pmhJ2B0EWOux3tgbTFcG5A,YYoiKcHwleq3C0GvRLMsr8 = JaP78r0DShfgl6t4QpK2V9
	ttWRgmnLxN = EE3yNOsZ4SzuWpg16inm9LDatbj5rw.truetype(FNPV23kDeG8BbUiT05x19,size=ecuF02YlIBmi5S9xUP3AwQrHnW8oj)
	diJk9C0r4XuUg7cywFNS = EE3yNOsZ4SzuWpg16inm9LDatbj5rw.truetype(FNPV23kDeG8BbUiT05x19,size=Z8pmhJ2B0EWOux3tgbTFcG5A)
	SejWn3Q2pxLfz1MRUNmDZ69w = EE3yNOsZ4SzuWpg16inm9LDatbj5rw.truetype(FNPV23kDeG8BbUiT05x19,size=YYoiKcHwleq3C0GvRLMsr8)
	b2zuDlgZC175h = Fsp2z0ctjY-IgVNsbm3rk02UwyhTu*s0sB2Xyp9uYU5N3fxzKoLW8
	eN0iQsFtgIpXnYMZkGq3cPyd1D257 = QTUZ8trfRMkVD7zCoOL5.new(tzEjvOaZWU1A(u"ࠨࡔࡊࡆࡆ࠭ఞ"),(b2zuDlgZC175h,WlU7AtONpyj3(u"࠷࠰࠱೙")),(HHthiRYs8T6IO3qUyX(u"࠲࠶࠷೚"),HHthiRYs8T6IO3qUyX(u"࠲࠶࠷೚"),HHthiRYs8T6IO3qUyX(u"࠲࠶࠷೚"),nxUveizbLEAT2FBNy3))
	kqxUp0FZABac97MrtKLH6go = Tk3fFn6NlOQUr4KhL2vJSPi71jG8.Draw(eN0iQsFtgIpXnYMZkGq3cPyd1D257)
	GtL4WxCIcKFovMdOihrTyBJ02np5q,C3culjpK7Px2nswEa6LhdyR = kqxUp0FZABac97MrtKLH6go.textsize(wb1nC3e8AjRVU4ovsuPa(u"ࠩࡋࡌࡍࠦࡂࡃࡄࠣ࠼࠽࠾ࠠ࠱࠲࠳ࠫట"),font=ttWRgmnLxN)
	LyOatzMPNJ4q,Mkt582EnxeAHP3DsTGz9JOob7S = kqxUp0FZABac97MrtKLH6go.textsize(sdRqnego9PclrL4m2J(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬఠ"),font=diJk9C0r4XuUg7cywFNS)
	I5hTkiCKW7eU1pGmx = {Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡩ࡫࡬ࡦࡶࡨࡣ࡭ࡧࡲࡢ࡭ࡤࡸࠬడ"):wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,gNPRXprEAQJ(u"ࠬࡹࡵࡱࡲࡲࡶࡹࡥ࡬ࡪࡩࡤࡸࡺࡸࡥࡴࠩఢ"):dbo4vrnTM56I,J6G8X3gO1MiKh027D(u"࠭ࡁࡓࡃࡅࡍࡈࠦࡌࡊࡉࡄࡘ࡚ࡘࡅࠡࡃࡏࡐࡆࡎࠧణ"):wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1}
	from arabic_reshaper import ArabicReshaper as KZ8W9hDl6OIGkQqMn1A4HmL
	wvVWkGcifSp2amt3Pg09NXURhA1dx = KZ8W9hDl6OIGkQqMn1A4HmL(configuration=I5hTkiCKW7eU1pGmx)
	JJA5CEWvHfQryca6SdXMbzq = {}
	apNivqECZj = locals()
	for fOX1xaTVkPrbmWg0l in apNivqECZj: JJA5CEWvHfQryca6SdXMbzq[fOX1xaTVkPrbmWg0l] = apNivqECZj[fOX1xaTVkPrbmWg0l]
	return JJA5CEWvHfQryca6SdXMbzq
def OjpKsIQ7ZbrJDqoc8gfdmiMS2B(JJA5CEWvHfQryca6SdXMbzq,chVO2pfUCoj6SksDTlaq,PdT7YZUKWahEnHfcyClkG5sJbrFR,GHLdcMJ5aCoptRe9DBbIPrs,piDNqYaCZ3wPFhSk7UJTtdx,fRJYhnSKHsZ7MqFwmiVz,vvIgUDnbOPV3zA9laZFtJi5YHLmd,FF4sQC1Bbm9jlgtYniqRp6kIdWJuLO,vHpedmuDWao4wXN8gIh7M,a2i6rMkgwBuyoEAFtPLlqjpRVOGI):
	for fOX1xaTVkPrbmWg0l in JJA5CEWvHfQryca6SdXMbzq: globals()[fOX1xaTVkPrbmWg0l] = JJA5CEWvHfQryca6SdXMbzq[fOX1xaTVkPrbmWg0l]
	global wq0UC3N1IuDnFYZT5X7Mdj6fgVt,QEi4oZvYcGw2MKH
	if vvIgUDnbOPV3zA9laZFtJi5YHLmd!=CMUXq6mPQV5rLsSBdWZJvA(u"ࠧ࡮ࡧࡱࡹࡤ࡯ࡴࡦ࡯ࠪత"):
		bMo1SgZLa8 = l7tuXCf0oKV9FPOy6Hb.getSetting(BBOY8rvinVbFh(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩథ"))
		if bMo1SgZLa8:
			if chVO2pfUCoj6SksDTlaq==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫద"): chVO2pfUCoj6SksDTlaq = wb1nC3e8AjRVU4ovsuPa(u"ࠪ࡝ࡪࡹࠧధ")
			elif chVO2pfUCoj6SksDTlaq==ZeV4vau9CjN(u"่๊ࠫวࠡࠢࡑࡳࠬన"): chVO2pfUCoj6SksDTlaq = CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡔ࡯ࠨ఩")
			if PdT7YZUKWahEnHfcyClkG5sJbrFR==J6G8X3gO1MiKh027D(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨప"): PdT7YZUKWahEnHfcyClkG5sJbrFR = u8iSx05wLfVyMNp1X3l(u"࡚ࠧࡧࡶࠫఫ")
			elif PdT7YZUKWahEnHfcyClkG5sJbrFR==A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨๅ็หࠥࠦࡎࡰࠩబ"): PdT7YZUKWahEnHfcyClkG5sJbrFR = gNPRXprEAQJ(u"ࠩࡑࡳࠬభ")
			if GHLdcMJ5aCoptRe9DBbIPrs==gNPRXprEAQJ(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬమ"): GHLdcMJ5aCoptRe9DBbIPrs = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫ࡞࡫ࡳࠨయ")
			elif GHLdcMJ5aCoptRe9DBbIPrs==NZiEOAWrSX1u2gU05DR6TB8tm(u"้ࠬไศࠢࠣࡒࡴ࠭ర"): GHLdcMJ5aCoptRe9DBbIPrs = Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭ࡎࡰࠩఱ")
			import NNeGzpnkuF
			X0mhvdbn9g61HlGZs = NNeGzpnkuF.SBAXFxdtK8EbMzceVu([chVO2pfUCoj6SksDTlaq,PdT7YZUKWahEnHfcyClkG5sJbrFR,GHLdcMJ5aCoptRe9DBbIPrs,piDNqYaCZ3wPFhSk7UJTtdx,fRJYhnSKHsZ7MqFwmiVz])
			if X0mhvdbn9g61HlGZs: chVO2pfUCoj6SksDTlaq,PdT7YZUKWahEnHfcyClkG5sJbrFR,GHLdcMJ5aCoptRe9DBbIPrs,piDNqYaCZ3wPFhSk7UJTtdx,fRJYhnSKHsZ7MqFwmiVz = X0mhvdbn9g61HlGZs
	if BBJYzRKgHkOqx:
		fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.decode(NVbhZ0DTpOkCA)
		piDNqYaCZ3wPFhSk7UJTtdx = piDNqYaCZ3wPFhSk7UJTtdx.decode(NVbhZ0DTpOkCA)
		chVO2pfUCoj6SksDTlaq = chVO2pfUCoj6SksDTlaq.decode(NVbhZ0DTpOkCA)
		PdT7YZUKWahEnHfcyClkG5sJbrFR = PdT7YZUKWahEnHfcyClkG5sJbrFR.decode(NVbhZ0DTpOkCA)
		GHLdcMJ5aCoptRe9DBbIPrs = GHLdcMJ5aCoptRe9DBbIPrs.decode(NVbhZ0DTpOkCA)
	V27PaAJXG4bmz6q5wCMTcx = piDNqYaCZ3wPFhSk7UJTtdx.count(URBvawyLXfQiS2NI34HDk)+igM4DhpPzoX95Ysnar6Auj
	IItSgCvfYWZreOBV6s4k5PQ0z3cKd = U0G37bKqOItaAkpzhM6wQfuyDZ+V27PaAJXG4bmz6q5wCMTcx*(C3culjpK7Px2nswEa6LhdyR+scxqV32JKGABlyaX)-scxqV32JKGABlyaX
	if fRJYhnSKHsZ7MqFwmiVz:
		mRAQn4h9ptrOH107vYBzJqTcoC6xN = Mkt582EnxeAHP3DsTGz9JOob7S+PC42aRBAuMHU3E5OewstxZ8pofD
		jpSr1u6whKyMFC7blReAJBYmoPTGz = wvVWkGcifSp2amt3Pg09NXURhA1dx.reshape(fRJYhnSKHsZ7MqFwmiVz)
		if dabW9cQorezk:
			x0x6ogGKdQ4eDXE = cRfVCEXNPHb6n(kqxUp0FZABac97MrtKLH6go,diJk9C0r4XuUg7cywFNS,jpSr1u6whKyMFC7blReAJBYmoPTGz,Z8pmhJ2B0EWOux3tgbTFcG5A,b2zuDlgZC175h,mRAQn4h9ptrOH107vYBzJqTcoC6xN)
			sHap3q68tuCE = LJr1W4bXNvnkPxy89KqO3MA(x0x6ogGKdQ4eDXE)
			II24VynlQDbvjZq1Y8WFmAzSa = sHap3q68tuCE.count(URBvawyLXfQiS2NI34HDk)+igM4DhpPzoX95Ysnar6Auj
			hxcsUbMigYmozAIqtN95OnWJCvQZ = ewBu2LTZYPyHG+II24VynlQDbvjZq1Y8WFmAzSa*mRAQn4h9ptrOH107vYBzJqTcoC6xN-PC42aRBAuMHU3E5OewstxZ8pofD
		else:
			hxcsUbMigYmozAIqtN95OnWJCvQZ = ewBu2LTZYPyHG+Mkt582EnxeAHP3DsTGz9JOob7S
			sHap3q68tuCE = jpSr1u6whKyMFC7blReAJBYmoPTGz.split(URBvawyLXfQiS2NI34HDk)[nxUveizbLEAT2FBNy3]
			x0x6ogGKdQ4eDXE = jpSr1u6whKyMFC7blReAJBYmoPTGz.split(URBvawyLXfQiS2NI34HDk)[nxUveizbLEAT2FBNy3]
	else: hxcsUbMigYmozAIqtN95OnWJCvQZ = ewBu2LTZYPyHG
	RQXD8txJju = kgfpHqDaCP0Z3VKoN9TjIS5+gLCmuaJMbljfHUTOtdrD3Qp8yPI
	if vHpedmuDWao4wXN8gIh7M:
		ZkPGA3nfv64V5UMHdW02o = heL7gwbiytDZ4vJzoBIdGKEFxV5f-XoDk9s5YClI
		RQXD8txJju += ZkPGA3nfv64V5UMHdW02o
	else: ZkPGA3nfv64V5UMHdW02o = nxUveizbLEAT2FBNy3
	if chVO2pfUCoj6SksDTlaq or PdT7YZUKWahEnHfcyClkG5sJbrFR or GHLdcMJ5aCoptRe9DBbIPrs: RQXD8txJju += qq84MJV2rOAzhcN10wdt
	jWr1dXlGMySKZbAsP93OqeFpk = KlQJmCqvkD if KlQJmCqvkD!=z8wTfYPiRQL(u"ࠧࡖࡒࡓࡉࡗ࠭ల") else IItSgCvfYWZreOBV6s4k5PQ0z3cKd+hxcsUbMigYmozAIqtN95OnWJCvQZ+RQXD8txJju
	eN0iQsFtgIpXnYMZkGq3cPyd1D257 = QTUZ8trfRMkVD7zCoOL5.new(YoMw2J1Ljp(u"ࠨࡔࡊࡆࡆ࠭ళ"),(Fsp2z0ctjY,jWr1dXlGMySKZbAsP93OqeFpk),(ssYkHaML9z37bJ0StuEBXIqgiV(u"࠳࠷࠸೛"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࠳࠷࠸೛"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࠳࠷࠸೛"),nxUveizbLEAT2FBNy3))
	NGdrJeKZnXcgi19sRkpOLICMj7 = Tk3fFn6NlOQUr4KhL2vJSPi71jG8.Draw(eN0iQsFtgIpXnYMZkGq3cPyd1D257)
	EDCtjFxXkUVAze92Md = jWr1dXlGMySKZbAsP93OqeFpk-IItSgCvfYWZreOBV6s4k5PQ0z3cKd-RQXD8txJju-ewBu2LTZYPyHG
	if not PdT7YZUKWahEnHfcyClkG5sJbrFR and chVO2pfUCoj6SksDTlaq and GHLdcMJ5aCoptRe9DBbIPrs:
		wq0UC3N1IuDnFYZT5X7Mdj6fgVt += qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠳࠳࠹೜")
		QEi4oZvYcGw2MKH -= ZeV4vau9CjN(u"࠴࠵࠵ೝ")
	import bidi.algorithm as meriXMfz3Qo9EWROxgdUS4lBpLYN
	if piDNqYaCZ3wPFhSk7UJTtdx:
		ZK9Ca7lwIpNs03FS1 = U0G37bKqOItaAkpzhM6wQfuyDZ
		piDNqYaCZ3wPFhSk7UJTtdx = meriXMfz3Qo9EWROxgdUS4lBpLYN.get_display(wvVWkGcifSp2amt3Pg09NXURhA1dx.reshape(piDNqYaCZ3wPFhSk7UJTtdx))
		XXluaiyqGjfzJnxVtm458bTYRI = piDNqYaCZ3wPFhSk7UJTtdx.splitlines()
		for KXVpQi6eGUdNCO1LumZkRDS3vqWYh in XXluaiyqGjfzJnxVtm458bTYRI:
			if KXVpQi6eGUdNCO1LumZkRDS3vqWYh:
				IEfZt6ri5OKRLPYbVHDqhJuw1g4s,Kd1zo7YiuvNQ4 = NGdrJeKZnXcgi19sRkpOLICMj7.textsize(KXVpQi6eGUdNCO1LumZkRDS3vqWYh,font=ttWRgmnLxN)
				if bbHQVrYi2l1mc==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩࡦࡩࡳࡺࡥࡳࠩఴ"): ypjNBzgJZFtw84sWDQMP = j3Gce65kIvlyCRZ7tzKYaVq+(Fsp2z0ctjY-IEfZt6ri5OKRLPYbVHDqhJuw1g4s)/s0sB2Xyp9uYU5N3fxzKoLW8
				elif bbHQVrYi2l1mc==wb1nC3e8AjRVU4ovsuPa(u"ࠪࡶ࡮࡭ࡨࡵࠩవ"): ypjNBzgJZFtw84sWDQMP = j3Gce65kIvlyCRZ7tzKYaVq+Fsp2z0ctjY-IEfZt6ri5OKRLPYbVHDqhJuw1g4s-tpxbz06qEDXn
				elif bbHQVrYi2l1mc==aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࡱ࡫ࡦࡵࠩశ"): ypjNBzgJZFtw84sWDQMP = j3Gce65kIvlyCRZ7tzKYaVq+tpxbz06qEDXn
				NGdrJeKZnXcgi19sRkpOLICMj7.text((ypjNBzgJZFtw84sWDQMP,ZK9Ca7lwIpNs03FS1),KXVpQi6eGUdNCO1LumZkRDS3vqWYh,font=ttWRgmnLxN,fill=u8iSx05wLfVyMNp1X3l(u"ࠬࡿࡥ࡭࡮ࡲࡻࠬష"))
			ZK9Ca7lwIpNs03FS1 += ecuF02YlIBmi5S9xUP3AwQrHnW8oj+scxqV32JKGABlyaX
	if chVO2pfUCoj6SksDTlaq or PdT7YZUKWahEnHfcyClkG5sJbrFR or GHLdcMJ5aCoptRe9DBbIPrs:
		CuwH65D8BTNlPpY = IItSgCvfYWZreOBV6s4k5PQ0z3cKd+EDCtjFxXkUVAze92Md+ewBu2LTZYPyHG+ZkPGA3nfv64V5UMHdW02o+kgfpHqDaCP0Z3VKoN9TjIS5
		if chVO2pfUCoj6SksDTlaq:
			chVO2pfUCoj6SksDTlaq = meriXMfz3Qo9EWROxgdUS4lBpLYN.get_display(wvVWkGcifSp2amt3Pg09NXURhA1dx.reshape(chVO2pfUCoj6SksDTlaq))
			fRN32PrY90vcInQD,GhXUS4ovFt = NGdrJeKZnXcgi19sRkpOLICMj7.textsize(chVO2pfUCoj6SksDTlaq,font=SejWn3Q2pxLfz1MRUNmDZ69w)
			JJ5xyQODHtdijB = wq0UC3N1IuDnFYZT5X7Mdj6fgVt+nxUveizbLEAT2FBNy3*(QEi4oZvYcGw2MKH+p0Mj2ozcCKQF4nV9Eg7dwYUb)+(p0Mj2ozcCKQF4nV9Eg7dwYUb-fRN32PrY90vcInQD)/s0sB2Xyp9uYU5N3fxzKoLW8
			NGdrJeKZnXcgi19sRkpOLICMj7.text((JJ5xyQODHtdijB,CuwH65D8BTNlPpY),chVO2pfUCoj6SksDTlaq,font=SejWn3Q2pxLfz1MRUNmDZ69w,fill=Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭స"))
		if PdT7YZUKWahEnHfcyClkG5sJbrFR:
			PdT7YZUKWahEnHfcyClkG5sJbrFR = meriXMfz3Qo9EWROxgdUS4lBpLYN.get_display(wvVWkGcifSp2amt3Pg09NXURhA1dx.reshape(PdT7YZUKWahEnHfcyClkG5sJbrFR))
			JHK7cIB5wLAOPVWzMYXC,DwPxciysVFH7MhEGqWzrAlpm = NGdrJeKZnXcgi19sRkpOLICMj7.textsize(PdT7YZUKWahEnHfcyClkG5sJbrFR,font=SejWn3Q2pxLfz1MRUNmDZ69w)
			RuaiUjvn2sIN = wq0UC3N1IuDnFYZT5X7Mdj6fgVt+igM4DhpPzoX95Ysnar6Auj*(QEi4oZvYcGw2MKH+p0Mj2ozcCKQF4nV9Eg7dwYUb)+(p0Mj2ozcCKQF4nV9Eg7dwYUb-JHK7cIB5wLAOPVWzMYXC)/s0sB2Xyp9uYU5N3fxzKoLW8
			NGdrJeKZnXcgi19sRkpOLICMj7.text((RuaiUjvn2sIN,CuwH65D8BTNlPpY),PdT7YZUKWahEnHfcyClkG5sJbrFR,font=SejWn3Q2pxLfz1MRUNmDZ69w,fill=tzEjvOaZWU1A(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧహ"))
		if GHLdcMJ5aCoptRe9DBbIPrs:
			GHLdcMJ5aCoptRe9DBbIPrs = meriXMfz3Qo9EWROxgdUS4lBpLYN.get_display(wvVWkGcifSp2amt3Pg09NXURhA1dx.reshape(GHLdcMJ5aCoptRe9DBbIPrs))
			W2eOEZjPRs6xQJkY0XLSp,AvjdY2imaEZpCqrD = NGdrJeKZnXcgi19sRkpOLICMj7.textsize(GHLdcMJ5aCoptRe9DBbIPrs,font=SejWn3Q2pxLfz1MRUNmDZ69w)
			v8BmG1KdrsARpk2DEJ6QtUiaq = wq0UC3N1IuDnFYZT5X7Mdj6fgVt+s0sB2Xyp9uYU5N3fxzKoLW8*(QEi4oZvYcGw2MKH+p0Mj2ozcCKQF4nV9Eg7dwYUb)+(p0Mj2ozcCKQF4nV9Eg7dwYUb-W2eOEZjPRs6xQJkY0XLSp)/s0sB2Xyp9uYU5N3fxzKoLW8
			NGdrJeKZnXcgi19sRkpOLICMj7.text((v8BmG1KdrsARpk2DEJ6QtUiaq,CuwH65D8BTNlPpY),GHLdcMJ5aCoptRe9DBbIPrs,font=SejWn3Q2pxLfz1MRUNmDZ69w,fill=XasF0WO7rDUHnEt8hAl9kLN(u"ࠨࡻࡨࡰࡱࡵࡷࠨ఺"))
	if fRJYhnSKHsZ7MqFwmiVz:
		gJsMnxaU42eoHRFNBjd56w1,s6bqOQ7NvH3V2DLgwZJ5mTP941Eo8 = [],[]
		x0x6ogGKdQ4eDXE = CXk8icqSR3vBK5IE(x0x6ogGKdQ4eDXE)
		KZFSryT4lhPc6VMjO8CEYvI = x0x6ogGKdQ4eDXE.split(wb1nC3e8AjRVU4ovsuPa(u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ఻"))
		for mCFZPVExc1sJtdOUgeDABa in KZFSryT4lhPc6VMjO8CEYvI:
			RdBxrVUwcheYtST9WDQGHP1A = FF4sQC1Bbm9jlgtYniqRp6kIdWJuLO
			if   NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣ఼ࠬ") in mCFZPVExc1sJtdOUgeDABa: RdBxrVUwcheYtST9WDQGHP1A = ZeV4vau9CjN(u"ࠫࡱ࡫ࡦࡵࠩఽ")
			elif WlU7AtONpyj3(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨా") in mCFZPVExc1sJtdOUgeDABa: RdBxrVUwcheYtST9WDQGHP1A = HHthiRYs8T6IO3qUyX(u"࠭ࡲࡪࡩ࡫ࡸࠬి")
			elif ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫీ") in mCFZPVExc1sJtdOUgeDABa: RdBxrVUwcheYtST9WDQGHP1A = YoMw2J1Ljp(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨు")
			rwDO2zE59WBlNAKGjFbfo1 = mCFZPVExc1sJtdOUgeDABa
			TTQ0CK4drp = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡢࡷࡸࡹ࡟ࡠ࠰࠭ࡃࡤ࠭ూ"),mCFZPVExc1sJtdOUgeDABa,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for CzBXLW9jgRwHZK6eV1vT in TTQ0CK4drp: rwDO2zE59WBlNAKGjFbfo1 = rwDO2zE59WBlNAKGjFbfo1.replace(CzBXLW9jgRwHZK6eV1vT,kh850jKbzmBwY)
			if rwDO2zE59WBlNAKGjFbfo1==kh850jKbzmBwY: IEfZt6ri5OKRLPYbVHDqhJuw1g4s,Kd1zo7YiuvNQ4 = nxUveizbLEAT2FBNy3,mRAQn4h9ptrOH107vYBzJqTcoC6xN
			else: IEfZt6ri5OKRLPYbVHDqhJuw1g4s,Kd1zo7YiuvNQ4 = NGdrJeKZnXcgi19sRkpOLICMj7.textsize(rwDO2zE59WBlNAKGjFbfo1,font=diJk9C0r4XuUg7cywFNS)
			if   RdBxrVUwcheYtST9WDQGHP1A==Urj6egiVyHA75ZK(u"ࠪࡰࡪ࡬ࡴࠨృ"): o70vcuqRnAQD1UVH = vg6Ru2ptKHWVF+IgVNsbm3rk02UwyhTu
			elif RdBxrVUwcheYtST9WDQGHP1A==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࡷ࡯ࡧࡩࡶࠪౄ"): o70vcuqRnAQD1UVH = vg6Ru2ptKHWVF+IgVNsbm3rk02UwyhTu+b2zuDlgZC175h-IEfZt6ri5OKRLPYbVHDqhJuw1g4s
			elif RdBxrVUwcheYtST9WDQGHP1A==Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ౅"): o70vcuqRnAQD1UVH = vg6Ru2ptKHWVF+IgVNsbm3rk02UwyhTu+(b2zuDlgZC175h-IEfZt6ri5OKRLPYbVHDqhJuw1g4s)/s0sB2Xyp9uYU5N3fxzKoLW8
			if o70vcuqRnAQD1UVH<IgVNsbm3rk02UwyhTu: o70vcuqRnAQD1UVH = vg6Ru2ptKHWVF+IgVNsbm3rk02UwyhTu
			gJsMnxaU42eoHRFNBjd56w1.append(o70vcuqRnAQD1UVH)
			s6bqOQ7NvH3V2DLgwZJ5mTP941Eo8.append(IEfZt6ri5OKRLPYbVHDqhJuw1g4s)
		o70vcuqRnAQD1UVH = gJsMnxaU42eoHRFNBjd56w1[nxUveizbLEAT2FBNy3]
		k9U0Re3hXo = x0x6ogGKdQ4eDXE.split(sdRqnego9PclrL4m2J(u"࠭࡟ࡴࡵࡶࡣࠬె"))
		PPDQBEVkjl = (NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠺࠻ೞ"),NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠺࠻ೞ"),NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠺࠻ೞ"),NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠺࠻ೞ"))
		ekz57wj2JN3oGXvsZ = PPDQBEVkjl
		TuPAgKCDrMRpH5bhkZfycU31ozI,bAnQJaKkNOsz6Vf93 = nxUveizbLEAT2FBNy3,nxUveizbLEAT2FBNy3
		UlFz35QiJyAx9dPhreq2swbBOpW7 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		OgAniGm2zRp10TWe4JVMbHUo3y = nxUveizbLEAT2FBNy3
		KKUFWpIT5rB296aqGtoSezYn = IItSgCvfYWZreOBV6s4k5PQ0z3cKd+ewBu2LTZYPyHG/s0sB2Xyp9uYU5N3fxzKoLW8
		if hxcsUbMigYmozAIqtN95OnWJCvQZ<(EDCtjFxXkUVAze92Md+ewBu2LTZYPyHG):
			N38K4hm1FXMI = (EDCtjFxXkUVAze92Md+ewBu2LTZYPyHG-hxcsUbMigYmozAIqtN95OnWJCvQZ)/s0sB2Xyp9uYU5N3fxzKoLW8
			KKUFWpIT5rB296aqGtoSezYn = IItSgCvfYWZreOBV6s4k5PQ0z3cKd+ewBu2LTZYPyHG+N38K4hm1FXMI-Mkt582EnxeAHP3DsTGz9JOob7S/s0sB2Xyp9uYU5N3fxzKoLW8
		for KXVpQi6eGUdNCO1LumZkRDS3vqWYh in k9U0Re3hXo:
			if not KXVpQi6eGUdNCO1LumZkRDS3vqWYh or (KXVpQi6eGUdNCO1LumZkRDS3vqWYh and ord(KXVpQi6eGUdNCO1LumZkRDS3vqWYh[nxUveizbLEAT2FBNy3])==XasF0WO7rDUHnEt8hAl9kLN(u"࠻࠻࠲࠸࠻೟")): continue
			IZBiRnOdKLfgXYPjy7eUJ1rs45z0 = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪే"),igM4DhpPzoX95Ysnar6Auj)
			KxbNsjJZwO = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(tzEjvOaZWU1A(u"ࠨࡡࡱࡩࡼࡩ࡯࡭ࡱࡵࠫై"),igM4DhpPzoX95Ysnar6Auj)
			E3wTIWDKekyX8jFuZdiQaBzpmgAx6 = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(WlU7AtONpyj3(u"ࠩࡢࡩࡳࡪࡣࡰ࡮ࡲࡶࡤ࠭౉"),igM4DhpPzoX95Ysnar6Auj)
			r9reYMI34DvcHfwFj = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(gNPRXprEAQJ(u"ࠪࡣࡱ࡯࡮ࡦࡴࡷࡰࡤ࠭ొ"),igM4DhpPzoX95Ysnar6Auj)
			LCHtEXz802rnkPeVZpY7oOiuJb9a = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(Urj6egiVyHA75ZK(u"ࠫࡤࡲࡩ࡯ࡧ࡯ࡩ࡫ࡺ࡟ࠨో"),igM4DhpPzoX95Ysnar6Auj)
			WDinqUO4fAQMHKvwdbJ = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪౌ"),igM4DhpPzoX95Ysnar6Auj)
			u1qLPorXnyjaQkc32BMmUlsF = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.split(ZeV4vau9CjN(u"࠭࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣ్ࠬ"),igM4DhpPzoX95Ysnar6Auj)
			if len(IZBiRnOdKLfgXYPjy7eUJ1rs45z0)>igM4DhpPzoX95Ysnar6Auj:
				OgAniGm2zRp10TWe4JVMbHUo3y += igM4DhpPzoX95Ysnar6Auj
				KXVpQi6eGUdNCO1LumZkRDS3vqWYh = IZBiRnOdKLfgXYPjy7eUJ1rs45z0[igM4DhpPzoX95Ysnar6Auj]
				TuPAgKCDrMRpH5bhkZfycU31ozI = nxUveizbLEAT2FBNy3
				o70vcuqRnAQD1UVH = gJsMnxaU42eoHRFNBjd56w1[OgAniGm2zRp10TWe4JVMbHUo3y]
				bAnQJaKkNOsz6Vf93 += mRAQn4h9ptrOH107vYBzJqTcoC6xN
				UlFz35QiJyAx9dPhreq2swbBOpW7 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
			elif len(KxbNsjJZwO)>igM4DhpPzoX95Ysnar6Auj:
				KXVpQi6eGUdNCO1LumZkRDS3vqWYh = KxbNsjJZwO[igM4DhpPzoX95Ysnar6Auj]
				ekz57wj2JN3oGXvsZ = KXVpQi6eGUdNCO1LumZkRDS3vqWYh[nxUveizbLEAT2FBNy3:dQvxmFkyLOteNMWBJ2bDHV(u"࠾ೠ")]
				ekz57wj2JN3oGXvsZ = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࠤࠩ౎")+ekz57wj2JN3oGXvsZ[s0sB2Xyp9uYU5N3fxzKoLW8:]
				KXVpQi6eGUdNCO1LumZkRDS3vqWYh = KXVpQi6eGUdNCO1LumZkRDS3vqWYh[wnVICNyfE3XZ0htUaDFAOgLo(u"࠹ೡ"):]
			elif len(E3wTIWDKekyX8jFuZdiQaBzpmgAx6)>igM4DhpPzoX95Ysnar6Auj:
				KXVpQi6eGUdNCO1LumZkRDS3vqWYh = E3wTIWDKekyX8jFuZdiQaBzpmgAx6[igM4DhpPzoX95Ysnar6Auj]
				ekz57wj2JN3oGXvsZ = PPDQBEVkjl
			elif len(r9reYMI34DvcHfwFj)>igM4DhpPzoX95Ysnar6Auj:
				KXVpQi6eGUdNCO1LumZkRDS3vqWYh = r9reYMI34DvcHfwFj[igM4DhpPzoX95Ysnar6Auj]
				UlFz35QiJyAx9dPhreq2swbBOpW7 = dbo4vrnTM56I
				TuPAgKCDrMRpH5bhkZfycU31ozI = s6bqOQ7NvH3V2DLgwZJ5mTP941Eo8[OgAniGm2zRp10TWe4JVMbHUo3y]
			elif len(LCHtEXz802rnkPeVZpY7oOiuJb9a)>Urj6egiVyHA75ZK(u"࠲ೢ"): KXVpQi6eGUdNCO1LumZkRDS3vqWYh = LCHtEXz802rnkPeVZpY7oOiuJb9a[igM4DhpPzoX95Ysnar6Auj]
			elif len(WDinqUO4fAQMHKvwdbJ)>kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠳ೣ"): KXVpQi6eGUdNCO1LumZkRDS3vqWYh = WDinqUO4fAQMHKvwdbJ[igM4DhpPzoX95Ysnar6Auj]
			elif len(u1qLPorXnyjaQkc32BMmUlsF)>FkqI4Gm8wMvUVbgo(u"࠴೤"): KXVpQi6eGUdNCO1LumZkRDS3vqWYh = u1qLPorXnyjaQkc32BMmUlsF[igM4DhpPzoX95Ysnar6Auj]
			if KXVpQi6eGUdNCO1LumZkRDS3vqWYh:
				zyJ6d4GR5sYA7qZ802vEMgabh = KKUFWpIT5rB296aqGtoSezYn+bAnQJaKkNOsz6Vf93
				KXVpQi6eGUdNCO1LumZkRDS3vqWYh = meriXMfz3Qo9EWROxgdUS4lBpLYN.get_display(KXVpQi6eGUdNCO1LumZkRDS3vqWYh)
				IEfZt6ri5OKRLPYbVHDqhJuw1g4s,Kd1zo7YiuvNQ4 = NGdrJeKZnXcgi19sRkpOLICMj7.textsize(KXVpQi6eGUdNCO1LumZkRDS3vqWYh,font=diJk9C0r4XuUg7cywFNS)
				if UlFz35QiJyAx9dPhreq2swbBOpW7: TuPAgKCDrMRpH5bhkZfycU31ozI -= IEfZt6ri5OKRLPYbVHDqhJuw1g4s
				li3ktYcPUmXpyD9f = o70vcuqRnAQD1UVH+TuPAgKCDrMRpH5bhkZfycU31ozI
				NGdrJeKZnXcgi19sRkpOLICMj7.text((li3ktYcPUmXpyD9f,zyJ6d4GR5sYA7qZ802vEMgabh),KXVpQi6eGUdNCO1LumZkRDS3vqWYh,font=diJk9C0r4XuUg7cywFNS,fill=ekz57wj2JN3oGXvsZ)
				if vvIgUDnbOPV3zA9laZFtJi5YHLmd==sdRqnego9PclrL4m2J(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫ౏"): NGdrJeKZnXcgi19sRkpOLICMj7.text((li3ktYcPUmXpyD9f+igM4DhpPzoX95Ysnar6Auj,zyJ6d4GR5sYA7qZ802vEMgabh+igM4DhpPzoX95Ysnar6Auj),KXVpQi6eGUdNCO1LumZkRDS3vqWYh,font=diJk9C0r4XuUg7cywFNS,fill=ekz57wj2JN3oGXvsZ)
				if not UlFz35QiJyAx9dPhreq2swbBOpW7: TuPAgKCDrMRpH5bhkZfycU31ozI += IEfZt6ri5OKRLPYbVHDqhJuw1g4s
				if zyJ6d4GR5sYA7qZ802vEMgabh>EDCtjFxXkUVAze92Md+mRAQn4h9ptrOH107vYBzJqTcoC6xN: break
	if vvIgUDnbOPV3zA9laZFtJi5YHLmd==FkqI4Gm8wMvUVbgo(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬ౐"):
		vvEAkyXHYJNjmwa6oZ7Qb = uuLOEMCUAhsJ0w7521oKyj.copy()
		pVesmhFG6wgubAODHSKvN1Wx.sleep(Urj6egiVyHA75ZK(u"࠴࠳࠶࠵೥"))
		vvEAkyXHYJNjmwa6oZ7Qb.paste(zkD5Qsh6dZgFXSbV9tOY,(nxUveizbLEAT2FBNy3,nxUveizbLEAT2FBNy3),mask=eN0iQsFtgIpXnYMZkGq3cPyd1D257)
	else: vvEAkyXHYJNjmwa6oZ7Qb = eN0iQsFtgIpXnYMZkGq3cPyd1D257
	if BBJYzRKgHkOqx: a2i6rMkgwBuyoEAFtPLlqjpRVOGI = a2i6rMkgwBuyoEAFtPLlqjpRVOGI.decode(NVbhZ0DTpOkCA)
	try: vvEAkyXHYJNjmwa6oZ7Qb.save(a2i6rMkgwBuyoEAFtPLlqjpRVOGI)
	except UnicodeError:
		if BBJYzRKgHkOqx:
			a2i6rMkgwBuyoEAFtPLlqjpRVOGI = a2i6rMkgwBuyoEAFtPLlqjpRVOGI.encode(NVbhZ0DTpOkCA)
			vvEAkyXHYJNjmwa6oZ7Qb.save(a2i6rMkgwBuyoEAFtPLlqjpRVOGI)
	return jWr1dXlGMySKZbAsP93OqeFpk
def cRfVCEXNPHb6n(kqxUp0FZABac97MrtKLH6go,diJk9C0r4XuUg7cywFNS,pjHl5SgGK4ih7kTmEROZwrXCezatn,sOFa8WN5jQ,b2zuDlgZC175h,hkuAd4IpDbiRVq):
	gd4ARDt81brXBFUy,BDLIvJicmagtAQ9xspY,Xp9tgk8aO5Ur = kh850jKbzmBwY,nxUveizbLEAT2FBNy3,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠶࠻࠰࠱࠲೦")
	pjHl5SgGK4ih7kTmEROZwrXCezatn = pjHl5SgGK4ih7kTmEROZwrXCezatn.replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ౑"),z8wTfYPiRQL(u"ࠫࡠࡉࡏࡍࡑࡕ࠾࠿ࡀࠧ౒"))
	lb07ZQsigJD = b2zuDlgZC175h-sOFa8WN5jQ*s0sB2Xyp9uYU5N3fxzKoLW8
	for fcIUp40hvG8OtDRWMlT97C in pjHl5SgGK4ih7kTmEROZwrXCezatn.splitlines():
		BDLIvJicmagtAQ9xspY += hkuAd4IpDbiRVq
		QalTkuULFHcROn3YpbEZIN7D,hkCizlu6ysSYTPbWjFJ5 = nxUveizbLEAT2FBNy3,kh850jKbzmBwY
		for xJLdHMIZXptVs in fcIUp40hvG8OtDRWMlT97C.split(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF):
			OmFBWHoPDTVYds83L = LJr1W4bXNvnkPxy89KqO3MA(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+xJLdHMIZXptVs)
			sGO2dvcHeR7lIAVuanph,m9PSTAReh0jNtoJw = kqxUp0FZABac97MrtKLH6go.textsize(OmFBWHoPDTVYds83L,font=diJk9C0r4XuUg7cywFNS)
			if QalTkuULFHcROn3YpbEZIN7D+sGO2dvcHeR7lIAVuanph<lb07ZQsigJD:
				if not hkCizlu6ysSYTPbWjFJ5: hkCizlu6ysSYTPbWjFJ5 += xJLdHMIZXptVs
				else: hkCizlu6ysSYTPbWjFJ5 += EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+xJLdHMIZXptVs
				QalTkuULFHcROn3YpbEZIN7D += sGO2dvcHeR7lIAVuanph
			else:
				if sGO2dvcHeR7lIAVuanph<lb07ZQsigJD:
					hkCizlu6ysSYTPbWjFJ5 += wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࡢ࡮ࠡࠩ౓")+xJLdHMIZXptVs
					BDLIvJicmagtAQ9xspY += hkuAd4IpDbiRVq
					QalTkuULFHcROn3YpbEZIN7D = sGO2dvcHeR7lIAVuanph
				else:
					while sGO2dvcHeR7lIAVuanph>lb07ZQsigJD:
						for GO7MHm4uakCRsJ8AlcdLr in range(igM4DhpPzoX95Ysnar6Auj,len(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+xJLdHMIZXptVs),igM4DhpPzoX95Ysnar6Auj):
							fAuGmHpqFlJ = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+xJLdHMIZXptVs[:GO7MHm4uakCRsJ8AlcdLr]
							Y5UQGB2pEr9zqmSHA1hOj = xJLdHMIZXptVs[GO7MHm4uakCRsJ8AlcdLr:]
							WhcbC7tf3Tv = LJr1W4bXNvnkPxy89KqO3MA(fAuGmHpqFlJ)
							zVspADRdloOrfeI,NN70oBWVDcSzKh2LPU8 = kqxUp0FZABac97MrtKLH6go.textsize(WhcbC7tf3Tv,font=diJk9C0r4XuUg7cywFNS)
							if QalTkuULFHcROn3YpbEZIN7D+zVspADRdloOrfeI>lb07ZQsigJD:
								ZG4rHUE9xvLFaoI = sGO2dvcHeR7lIAVuanph-zVspADRdloOrfeI
								hkCizlu6ysSYTPbWjFJ5 += fAuGmHpqFlJ+URBvawyLXfQiS2NI34HDk
								BDLIvJicmagtAQ9xspY += hkuAd4IpDbiRVq
								sGO2dvcHeR7lIAVuanph = ZG4rHUE9xvLFaoI
								if ZG4rHUE9xvLFaoI>lb07ZQsigJD:
									QalTkuULFHcROn3YpbEZIN7D = nxUveizbLEAT2FBNy3
									xJLdHMIZXptVs = Y5UQGB2pEr9zqmSHA1hOj
								else:
									QalTkuULFHcROn3YpbEZIN7D = ZG4rHUE9xvLFaoI
									hkCizlu6ysSYTPbWjFJ5 += Y5UQGB2pEr9zqmSHA1hOj
								break
				if BDLIvJicmagtAQ9xspY>Xp9tgk8aO5Ur: break
		gd4ARDt81brXBFUy += URBvawyLXfQiS2NI34HDk+hkCizlu6ysSYTPbWjFJ5
		if BDLIvJicmagtAQ9xspY>Xp9tgk8aO5Ur: break
	gd4ARDt81brXBFUy = gd4ARDt81brXBFUy[igM4DhpPzoX95Ysnar6Auj:]
	gd4ARDt81brXBFUy = gd4ARDt81brXBFUy.replace(gNPRXprEAQJ(u"࡛࠭ࡄࡑࡏࡓࡗࡀ࠺࠻ࠩ౔"),gNPRXprEAQJ(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨౕ"))
	return gd4ARDt81brXBFUy
def LJr1W4bXNvnkPxy89KqO3MA(xJLdHMIZXptVs):
	if aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࡝ౖࠪ") in xJLdHMIZXptVs and sdRqnego9PclrL4m2J(u"ࠩࡠࠫ౗") in xJLdHMIZXptVs:
		TTQ0CK4drp = [wVvqN8LZCJW5ryAb1EHRPFkQ0,YoMw2J1Ljp(u"ࠪ࡟࠴ࡘࡔࡍ࡟ࠪౘ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡠ࠵ࡌࡆࡈࡗࡡࠬౙ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬࡡ࠯ࡓࡋࡊࡌ࡙ࡣࠧౚ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࡛࠭࠰ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ౛"),z8wTfYPiRQL(u"ࠧ࡜ࡔࡗࡐࡢ࠭౜"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠨౝ"),sdRqnego9PclrL4m2J(u"ࠩ࡞ࡖࡎࡍࡈࡕ࡟ࠪ౞"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ౟")]
		PhctfSwyden82lbAY4QBrio = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠴ࠪࡀ࡞ࡠࠫౠ"),xJLdHMIZXptVs,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		de9TSNow1QFmOKLlkbDcPs = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࡀ࠺࠻࠰࠭ࡃࡡࡣࠧౡ"),xJLdHMIZXptVs,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		iiqebuHvcdIpw5X = TTQ0CK4drp+PhctfSwyden82lbAY4QBrio+de9TSNow1QFmOKLlkbDcPs
		for CzBXLW9jgRwHZK6eV1vT in iiqebuHvcdIpw5X: xJLdHMIZXptVs = xJLdHMIZXptVs.replace(CzBXLW9jgRwHZK6eV1vT,kh850jKbzmBwY)
	return xJLdHMIZXptVs
def CXk8icqSR3vBK5IE(fRJYhnSKHsZ7MqFwmiVz):
	fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(URBvawyLXfQiS2NI34HDk,u8iSx05wLfVyMNp1X3l(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧౢ"))
	fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(HfuZG0aphlYnVLOyAk93rj(u"ࠧ࡜ࡔࡗࡐࡢ࠭ౣ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ౤"))
	fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ౥"),WlU7AtONpyj3(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ౦"))
	fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(HfuZG0aphlYnVLOyAk93rj(u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ౧"),gNPRXprEAQJ(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ౨"))
	fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(YoMw2J1Ljp(u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ౩"),Urj6egiVyHA75ZK(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ౪"))
	fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(wVvqN8LZCJW5ryAb1EHRPFkQ0,ZeV4vau9CjN(u"ࠨࡡࡶࡷࡸࡥ࡟ࡦࡰࡧࡧࡴࡲ࡯ࡳࡡࠪ౫"))
	AP5TI0WkhgtZd7G8CjfOB6R = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(tzEjvOaZWU1A(u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠣࠬ࠳࠰࠿ࠪ࡞ࡠࠫ౬"),fRJYhnSKHsZ7MqFwmiVz,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for HyB86JVDaeEsOzGlImW93UQiST in AP5TI0WkhgtZd7G8CjfOB6R: fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.replace(u8iSx05wLfVyMNp1X3l(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ౭")+HyB86JVDaeEsOzGlImW93UQiST+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࡢ࠭౮"),Urj6egiVyHA75ZK(u"ࠬࡥࡳࡴࡵࡢࡣࡳ࡫ࡷࡤࡱ࡯ࡳࡷ࠭౯")+HyB86JVDaeEsOzGlImW93UQiST+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭࡟ࠨ౰"))
	return fRJYhnSKHsZ7MqFwmiVz
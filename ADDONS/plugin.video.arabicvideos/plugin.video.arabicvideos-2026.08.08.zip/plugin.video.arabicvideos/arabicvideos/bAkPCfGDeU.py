# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'CIMAFANS'
headers = { 'User-Agent' : kh850jKbzmBwY }
GalrcVUMy8bzORWX5E0exhYivBwgk = '_CMF_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==90: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==91: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==92: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==94: PP3FsDicLyWuTR7GV5Ia = Em1lqDXHLbM6x0cv8Jiag()
	elif mode==95: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==99: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,99,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المضاف حديثا',kh850jKbzmBwY,94)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الأحدث',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?type=latest',91)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الأعلى تقيماً',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?type=imdb',91)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الأكثر مشاهدة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?type=view',91)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المثبت',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?type=pin',91)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'جديد الأفلام',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?type=newMovies',91)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'جديد الحلقات',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?type=newEpisodes',91)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'CIMAFANS-MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="mainmenu(.*?)nav',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li><a href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['افلام للكبار فقط']
	for Ga8xfYU6ht7cHjzn,title in items:
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,91)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="f-cats"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li><a href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,91)
	return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url):
	if '/search.php' in url:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMAFANS-TITLES-1st')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	else:
		headers = { 'User-Agent' : kh850jKbzmBwY }
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'CIMAFANS-TITLES-2nd')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"movies-items"(.*?)"clear"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	else: ZZDUdXR52CMs9K73Ex = kh850jKbzmBwY
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"movie-item".*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Sp6qOyDB0nt5Qo4KwbPfcWYe,mHjNds76Q1BvDh8e3,LtaDBqr1oOpP0Yz3g4ci8 = zip(*items)
		items = zip(mHjNds76Q1BvDh8e3,Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8)
	SHTvIuhX52dxQRsWA = []
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		if 'حلقة' in title and '/c/' not in url and '/cat/' not in url:
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة [0-9]+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if WULSmfNH09tPIv58snzpCkR:
				title = '_MOD_'+WULSmfNH09tPIv58snzpCkR[0]
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,95,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
		elif '/video/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,92,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,91,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			title = title.replace('الصفحة ',kh850jKbzmBwY)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,91)
	return
def do7Es2fUtFlM8ScLx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'CIMAFANS-EPISODES-1st')
	NWqAr40jTLlMBemn3o79y = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y[0]
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="episodes-panel(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		name = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('itemprop="title">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if name: name = name[1]
		else:
			name = ppNwDFByU1dZn5ca.getInfoLabel('ListItem.Label')
			if wVvqN8LZCJW5ryAb1EHRPFkQ0 in name: name = name.split(wVvqN8LZCJW5ryAb1EHRPFkQ0,1)[1]
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?name">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+name+' - '+title,Ga8xfYU6ht7cHjzn,92,NWqAr40jTLlMBemn3o79y)
	else:
		VBzUkECjaup0d9QSc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="movietitle"><a href="(.*?)">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if VBzUkECjaup0d9QSc: Ga8xfYU6ht7cHjzn,title = VBzUkECjaup0d9QSc[0]
		else: Ga8xfYU6ht7cHjzn,title = url,name
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,92,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX,VoxkPgz5FyJ0C3BKUDtw,NHjSru5bCKEXl7sQPpW9RieM = [],'',''
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'CIMAFANS-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('text-shadow: none;">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"play-vid"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
		VoxkPgz5FyJ0C3BKUDtw = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]+watch.php[^"]+)"',ZZDUdXR52CMs9K73Ex)
		NHjSru5bCKEXl7sQPpW9RieM  = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]+download.php[^"]+)"',ZZDUdXR52CMs9K73Ex)
	if VoxkPgz5FyJ0C3BKUDtw:
		VoxkPgz5FyJ0C3BKUDtw = VoxkPgz5FyJ0C3BKUDtw[nxUveizbLEAT2FBNy3]
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',VoxkPgz5FyJ0C3BKUDtw,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'CIMAFANS-PLAY-3rd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"server-tabs"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]+)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('url=')[1]
				Ga8xfYU6ht7cHjzn = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(Ga8xfYU6ht7cHjzn)
				if eOQJrvLAZC: Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.decode(NVbhZ0DTpOkCA)
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
				owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	if NHjSru5bCKEXl7sQPpW9RieM:
		NHjSru5bCKEXl7sQPpW9RieM = NHjSru5bCKEXl7sQPpW9RieM[nxUveizbLEAT2FBNy3]
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',NHjSru5bCKEXl7sQPpW9RieM,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'CIMAFANS-PLAY-4th')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"download-list"(.*?)</a>\s+</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]+)".*?"name".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn not in owMxje0p9Ya3CkhJDX:
					Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__download'
					owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def Em1lqDXHLbM6x0cv8Jiag():
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'CIMAFANS-LATEST-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="index-last-movie(.*?)id="index-slider-movie',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		if '/video/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,92,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,91,NWqAr40jTLlMBemn3o79y)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search.php?t='+search
	bsZhnoqjD3U(url)
	return
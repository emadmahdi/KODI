# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ೧")
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn,QmRL0swTcY9dXyIgrp82Aa1ekD):
	if   eYN1APt8aZflKmByj0ioGzn==NZiEOAWrSX1u2gU05DR6TB8tm(u"࠸࠹࠰൫"): PP3FsDicLyWuTR7GV5Ia = bbs4ESy0Gz1Ugafr2()
	elif eYN1APt8aZflKmByj0ioGzn==wb1nC3e8AjRVU4ovsuPa(u"࠹࠳࠲൬"): PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(QmRL0swTcY9dXyIgrp82Aa1ekD)
	elif eYN1APt8aZflKmByj0ioGzn==BBOY8rvinVbFh(u"࠳࠴࠴൭"): PP3FsDicLyWuTR7GV5Ia = PhKMqxUfRs9rupiV()
	elif eYN1APt8aZflKmByj0ioGzn==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠴࠵࠶൮"): PP3FsDicLyWuTR7GV5Ia = Q9YhsvJ3SHZ1fyCl0()
	else: PP3FsDicLyWuTR7GV5Ia = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	return PP3FsDicLyWuTR7GV5Ia
def yv8LezRQifhw1Kx(QmRL0swTcY9dXyIgrp82Aa1ekD):
	NRlCaq1ndM(QmRL0swTcY9dXyIgrp82Aa1ekD,vkNGie5mhCqoTFRzPKaML0x6,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡷ࡫ࡧࡩࡴ࠭೨"))
	return
def Q9YhsvJ3SHZ1fyCl0():
	gfe2BNJ3kTF0Xx = XasF0WO7rDUHnEt8hAl9kLN(u"ࠨลำ๋อࠦลๅ๋ࠣีฬฮืࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไึ๊อࠤๆ๐ࠠศๆ่์็฿ࠠศๆ่฻้๎ศࠡอ่ࠤศ฼ฺุࠢ฼่๎ࠦาาࠢส่็อฦๆหࠣห้๐ๅ๋่ࠣฯ๊ࠦรฯฬสีࠥࠨสฮ็ํ่๋ࠥไโษอࠤๆ๐ฯ๋๊ࠥࠤะ๋ࠠศะอหึࠦฯใหࠣห้฻่าหࠣ์ฬิสศำ๊ࠣํ฿ࠠๆๆไࠤฬ๊ี้ำฬࠤํฮูะ้สࠤุ๎แࠡ์หำศࠦวๅฬะ้๏๊ࠧ೩")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠศๆ่่ๆอสࠨ೪"),gfe2BNJ3kTF0Xx)
	return
def bbs4ESy0Gz1Ugafr2():
	EE6ysIeB8jKNgCfOkv(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠪࡰ࡮ࡴ࡫ࠨ೫"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ೬"),kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠵࠶࠷൯"))
	EE6ysIeB8jKNgCfOkv(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡲࡩ࡯࡭ࠪ೭"),J6G8X3gO1MiKh027D(u"࠭ส฻์ํี๋ࠥใศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭೮"),kh850jKbzmBwY,wb1nC3e8AjRVU4ovsuPa(u"࠶࠷࠷൰"))
	EE6ysIeB8jKNgCfOkv(WlU7AtONpyj3(u"ࠧ࡭࡫ࡱ࡯ࠬ೯"),HHFAVK8SwRUqBLuTfdeJ9nbD+z8wTfYPiRQL(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ೰")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠽࠾࠿࠹൱"))
	MkU5OwSJsViLedBc4Yo6A92DIPZNzx = nGsXz4Co9W8()
	SzO7QCthDn4KFjpxqX = YdDkIjFhgzuboBKca70ERt.stat(MkU5OwSJsViLedBc4Yo6A92DIPZNzx).st_mtime
	ddXFhKwSID7ZUc3 = []
	if eOQJrvLAZC: iDGRCO5AhxKJ0wjlvZ1c8BpnWz = YdDkIjFhgzuboBKca70ERt.listdir(MkU5OwSJsViLedBc4Yo6A92DIPZNzx.encode(NVbhZ0DTpOkCA))
	else: iDGRCO5AhxKJ0wjlvZ1c8BpnWz = YdDkIjFhgzuboBKca70ERt.listdir(MkU5OwSJsViLedBc4Yo6A92DIPZNzx.decode(NVbhZ0DTpOkCA))
	for FlyIgmU0k5t4vhKD1qOpzeSwo6XJ in iDGRCO5AhxKJ0wjlvZ1c8BpnWz:
		if eOQJrvLAZC: FlyIgmU0k5t4vhKD1qOpzeSwo6XJ = FlyIgmU0k5t4vhKD1qOpzeSwo6XJ.decode(NVbhZ0DTpOkCA)
		if not FlyIgmU0k5t4vhKD1qOpzeSwo6XJ.startswith(Urj6egiVyHA75ZK(u"ࠩࡩ࡭ࡱ࡫࡟ࠨೱ")): continue
		pHE2kiY6FeQbv3ATawx5 = YdDkIjFhgzuboBKca70ERt.path.join(MkU5OwSJsViLedBc4Yo6A92DIPZNzx,FlyIgmU0k5t4vhKD1qOpzeSwo6XJ)
		SzO7QCthDn4KFjpxqX = YdDkIjFhgzuboBKca70ERt.path.getmtime(pHE2kiY6FeQbv3ATawx5)
		ddXFhKwSID7ZUc3.append([FlyIgmU0k5t4vhKD1qOpzeSwo6XJ,SzO7QCthDn4KFjpxqX])
	ddXFhKwSID7ZUc3 = sorted(ddXFhKwSID7ZUc3,reverse=dbo4vrnTM56I,key=lambda key: key[igM4DhpPzoX95Ysnar6Auj])
	for FlyIgmU0k5t4vhKD1qOpzeSwo6XJ,SzO7QCthDn4KFjpxqX in ddXFhKwSID7ZUc3:
		if BBJYzRKgHkOqx:
			try: FlyIgmU0k5t4vhKD1qOpzeSwo6XJ = FlyIgmU0k5t4vhKD1qOpzeSwo6XJ.decode(NVbhZ0DTpOkCA)
			except: pass
			FlyIgmU0k5t4vhKD1qOpzeSwo6XJ = FlyIgmU0k5t4vhKD1qOpzeSwo6XJ.encode(NVbhZ0DTpOkCA)
		pHE2kiY6FeQbv3ATawx5 = YdDkIjFhgzuboBKca70ERt.path.join(MkU5OwSJsViLedBc4Yo6A92DIPZNzx,FlyIgmU0k5t4vhKD1qOpzeSwo6XJ)
		EE6ysIeB8jKNgCfOkv(ZeV4vau9CjN(u"ࠪࡺ࡮ࡪࡥࡰࠩೲ"),FlyIgmU0k5t4vhKD1qOpzeSwo6XJ,pHE2kiY6FeQbv3ATawx5,BBOY8rvinVbFh(u"࠸࠹࠱൲"))
	return
def nGsXz4Co9W8():
	MkU5OwSJsViLedBc4Yo6A92DIPZNzx = l7tuXCf0oKV9FPOy6Hb.getSetting(sdRqnego9PclrL4m2J(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧೳ"))
	if MkU5OwSJsViLedBc4Yo6A92DIPZNzx: return MkU5OwSJsViLedBc4Yo6A92DIPZNzx
	l7tuXCf0oKV9FPOy6Hb.setSetting(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨ೴"),qJWGLeXlsvHDr)
	return qJWGLeXlsvHDr
def PhKMqxUfRs9rupiV():
	MkU5OwSJsViLedBc4Yo6A92DIPZNzx = nGsXz4Co9W8()
	XWHJsOo2yUTvkDdj1RK05hgFwf = aa48i0SKpcGbWFBYLtCre(tzEjvOaZWU1A(u"࠭ࡣࡦࡰࡷࡩࡷ࠭೵"),kh850jKbzmBwY,kh850jKbzmBwY,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠫ೶"),RlMpu0hP8YmzZovkVXOs1G+MkU5OwSJsViLedBc4Yo6A92DIPZNzx+wVvqN8LZCJW5ryAb1EHRPFkQ0+G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨ࡞ࡱࡠࡳํะศ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠศๆ่็ฬ์ࠠภࠩ೷"))
	if XWHJsOo2yUTvkDdj1RK05hgFwf==WlU7AtONpyj3(u"࠷൳"):
		MTDkUAibd0zhBrvQGL7aqX4 = Digl6HdJyQ15s2rZamnfxc3SRI(YoMw2J1Ljp(u"࠳൴"),HfuZG0aphlYnVLOyAk93rj(u"่ࠩ็ฬ์ࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭೸"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡰࡴࡩࡡ࡭ࠩ೹"),kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I,MkU5OwSJsViLedBc4Yo6A92DIPZNzx)
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ೺"),kh850jKbzmBwY,kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩ೻"),RlMpu0hP8YmzZovkVXOs1G+MkU5OwSJsViLedBc4Yo6A92DIPZNzx+wVvqN8LZCJW5ryAb1EHRPFkQ0+tzEjvOaZWU1A(u"࠭࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧ೼"))
		if II7ErX2ocuU==FkqI4Gm8wMvUVbgo(u"࠲൵"):
			l7tuXCf0oKV9FPOy6Hb.setSetting(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ೽"),MTDkUAibd0zhBrvQGL7aqX4)
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,XasF0WO7rDUHnEt8hAl9kLN(u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩ೾"))
	return
def jBe37Si5TW02qLlwa(QmRL0swTcY9dXyIgrp82Aa1ekD,EqRs5OPLAuS=kh850jKbzmBwY,website=kh850jKbzmBwY):
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ೿")+QmRL0swTcY9dXyIgrp82Aa1ekD+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࠤࡢ࠭ഀ"))
	if not EqRs5OPLAuS: EqRs5OPLAuS = LYSRpzfhE3cGlXW08VK(QmRL0swTcY9dXyIgrp82Aa1ekD)
	MkU5OwSJsViLedBc4Yo6A92DIPZNzx = nGsXz4Co9W8()
	BPmnCIRKgJyuMrSDHj1VaAqNkYFGoU = QwbOcSlDzkaXm07x2ioyNYJWqfsCE1(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	FlyIgmU0k5t4vhKD1qOpzeSwo6XJ = BPmnCIRKgJyuMrSDHj1VaAqNkYFGoU.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,CMUXq6mPQV5rLsSBdWZJvA(u"ࠫࡤ࠭ഁ"))
	FlyIgmU0k5t4vhKD1qOpzeSwo6XJ = MMNV8Ogb9iJ4TD1EQq(FlyIgmU0k5t4vhKD1qOpzeSwo6XJ)
	FlyIgmU0k5t4vhKD1qOpzeSwo6XJ = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬ࡬ࡩ࡭ࡧࡢࠫം")+str(int(sC2g4oDQNAU7x))[-Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠶൶"):]+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭࡟ࠨഃ")+FlyIgmU0k5t4vhKD1qOpzeSwo6XJ+EqRs5OPLAuS
	el62cKSsRpGCfM4uLhoajTb5UWwHmn = YdDkIjFhgzuboBKca70ERt.path.join(MkU5OwSJsViLedBc4Yo6A92DIPZNzx,FlyIgmU0k5t4vhKD1qOpzeSwo6XJ)
	ZZTivR1uy8jFJ7qUa5QNYCtd4 = {}
	ZZTivR1uy8jFJ7qUa5QNYCtd4[dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩഄ")] = kh850jKbzmBwY
	ZZTivR1uy8jFJ7qUa5QNYCtd4[aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨࡃࡦࡧࡪࡶࡴࠨഅ")] = WlU7AtONpyj3(u"ࠩ࠭࠳࠯࠭ആ")
	QmRL0swTcY9dXyIgrp82Aa1ekD = QmRL0swTcY9dXyIgrp82Aa1ekD.replace(taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ഇ"),kh850jKbzmBwY)
	if wb1nC3e8AjRVU4ovsuPa(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩഈ") in QmRL0swTcY9dXyIgrp82Aa1ekD:
		O9wzaDlICnq,GYOXsa4p1l = QmRL0swTcY9dXyIgrp82Aa1ekD.rsplit(wnVICNyfE3XZ0htUaDFAOgLo(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪഉ"),MBS1GrwQoUlsiIRfVDOHdA(u"࠴൷"))
		GYOXsa4p1l = GYOXsa4p1l.replace(gNPRXprEAQJ(u"࠭ࡼࠨഊ"),kh850jKbzmBwY).replace(wb1nC3e8AjRVU4ovsuPa(u"ࠧࠧࠩഋ"),kh850jKbzmBwY)
	else: O9wzaDlICnq,GYOXsa4p1l = QmRL0swTcY9dXyIgrp82Aa1ekD,None
	if not GYOXsa4p1l: GYOXsa4p1l = e9SaDhW4XdLY2HfyPU7JI()
	if GYOXsa4p1l: ZZTivR1uy8jFJ7qUa5QNYCtd4[dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬഌ")] = GYOXsa4p1l
	if tzEjvOaZWU1A(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ഍") in O9wzaDlICnq: O9wzaDlICnq,guEWp2n0C6kOlZ = O9wzaDlICnq.rsplit(J6G8X3gO1MiKh027D(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬഎ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠵൸"))
	else: O9wzaDlICnq,guEWp2n0C6kOlZ = O9wzaDlICnq,kh850jKbzmBwY
	O9wzaDlICnq = O9wzaDlICnq.strip(Urj6egiVyHA75ZK(u"ࠫࢁ࠭ഏ")).strip(HfuZG0aphlYnVLOyAk93rj(u"ࠬࠬࠧഐ")).strip(qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ࡼࠨ഑")).strip(FkqI4Gm8wMvUVbgo(u"ࠧࠧࠩഒ"))
	guEWp2n0C6kOlZ = guEWp2n0C6kOlZ.replace(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡾࠪഓ"),kh850jKbzmBwY).replace(FkqI4Gm8wMvUVbgo(u"ࠩࠩࠫഔ"),kh850jKbzmBwY)
	if guEWp2n0C6kOlZ:	ZZTivR1uy8jFJ7qUa5QNYCtd4[Urj6egiVyHA75ZK(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫക")] = guEWp2n0C6kOlZ
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬഖ")+O9wzaDlICnq+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨഗ")+str(ZZTivR1uy8jFJ7qUa5QNYCtd4)+wb1nC3e8AjRVU4ovsuPa(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ഘ")+el62cKSsRpGCfM4uLhoajTb5UWwHmn+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࠡ࡟ࠪങ"))
	FFUbpd3xE58zLNGsinlCvgrB2f = Urj6egiVyHA75ZK(u"࠶࠶࠲࠵൹")*Urj6egiVyHA75ZK(u"࠶࠶࠲࠵൹")
	IbwoFENtqAYvHBQaRfUKJVZ98urL = qMfFUXi9201WIyB4bAvtkgCdl3J7()//FFUbpd3xE58zLNGsinlCvgrB2f
	if not IbwoFENtqAYvHBQaRfUKJVZ98urL:
		KKHpNde5TOmYqjIygtlwhf7W2sr(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨࡴ࡬࡫࡭ࡺࠧച"),BBOY8rvinVbFh(u"่ࠩืฬำษࠡษ็ฮำุ๊็่ࠢะ์๎ไสࠩഛ"),HHthiRYs8T6IO3qUyX(u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ฿๐ัࠡไสำึࠦร็ࠢํัิีࠠๆไาหึࠦๅิษะอࠥอไหะี๎๋ࠦวๅใสี฿ฯࠠโ์ࠣะ์อาไ๋ࠢ฽้๐็ࠡใส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡๆ้ࠤ๏฿ๅๅࠢ฼๊ิ้ࠠฦๆ์ࠤศ์๋ࠠไ๋้๋ࠥศา็ฯ๎ࠥฮั็ษ่ะ้่ࠥะ์ࠣฬา๊่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ่ࠥฯࠡ์ึฬอࠦวๆฬ็หฦࠦฬ่ษี็ࠥฮวๅ็็ๅฬะ้้ࠠำหࠥ็๊่ࠢั฻ํืษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสุ์ึฯࠠึฯํัฮ่ࠦๅ้ำหࠥอไิสหࠤ็อๅࠡษ็้อืๅอ่ࠢศ็ะวࠡส่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧജ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧഝ"))
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+HfuZG0aphlYnVLOyAk93rj(u"ࠬࠦࠠࠡࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࠠࡵࡪࡨࠤࡩ࡯ࡳ࡬ࠢࡩࡶࡪ࡫ࠠࡴࡲࡤࡧࡪ࠭ഞ"))
		return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if EqRs5OPLAuS==u8iSx05wLfVyMNp1X3l(u"࠭࠮࡮࠵ࡸ࠼ࠬട"):
		x2xi0tpFnQgNmaJ4LR,lnYtOIQ4Rkh386Bca7 = U3K1zSPsqampcGTIEufWi4(vkNGie5mhCqoTFRzPKaML0x6,O9wzaDlICnq,ZZTivR1uy8jFJ7qUa5QNYCtd4)
		if len(x2xi0tpFnQgNmaJ4LR)==J6G8X3gO1MiKh027D(u"࠶ൺ"):
			o4n5ehzyjHTWdL8(wb1nC3e8AjRVU4ovsuPa(u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫഠ"),kh850jKbzmBwY)
			return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		elif len(x2xi0tpFnQgNmaJ4LR)==CMUXq6mPQV5rLsSBdWZJvA(u"࠱ൻ"): TTn7mZzPRjq5GBESh8aKy = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠱ർ")
		elif len(x2xi0tpFnQgNmaJ4LR)>J6G8X3gO1MiKh027D(u"࠳ൽ"):
			TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ഡ"), x2xi0tpFnQgNmaJ4LR)
			if TTn7mZzPRjq5GBESh8aKy == -kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠴ൾ") :
				o4n5ehzyjHTWdL8(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊สฮ็ํ่ࠬഢ"),kh850jKbzmBwY)
				return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		O9wzaDlICnq = lnYtOIQ4Rkh386Bca7[TTn7mZzPRjq5GBESh8aKy]
	kuwzNQBgO2rl = BBOY8rvinVbFh(u"࠴ൿ")
	import requests as Cfr9RlkW32GtYT7ijNbFEJDqy
	if EqRs5OPLAuS==G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩണ"):
		el62cKSsRpGCfM4uLhoajTb5UWwHmn = el62cKSsRpGCfM4uLhoajTb5UWwHmn.rsplit(FkqI4Gm8wMvUVbgo(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪത"))[nxUveizbLEAT2FBNy3]+Urj6egiVyHA75ZK(u"ࠬ࠴࡭ࡱ࠶ࠪഥ")
		qnE2chelYX3w9RAMSb = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,WlU7AtONpyj3(u"࠭ࡇࡆࡖࠪദ"),O9wzaDlICnq,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,kh850jKbzmBwY,kh850jKbzmBwY,z8wTfYPiRQL(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧധ"))
		jqQgxivVJFC1wIEOLt4Z = qnE2chelYX3w9RAMSb.content
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(ZeV4vau9CjN(u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩന"),jqQgxivVJFC1wIEOLt4Z+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩ࡟ࡲࡡࡸࠧഩ"),sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not Sp6qOyDB0nt5Qo4KwbPfcWYe:
			IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+z8wTfYPiRQL(u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭പ")+O9wzaDlICnq+YoMw2J1Ljp(u"ࠫࠥࡣࠧഫ"))
			return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		Ga8xfYU6ht7cHjzn = Sp6qOyDB0nt5Qo4KwbPfcWYe[nxUveizbLEAT2FBNy3]
		if not Ga8xfYU6ht7cHjzn.startswith(YoMw2J1Ljp(u"ࠬ࡮ࡴࡵࡲࠪബ")):
			if Ga8xfYU6ht7cHjzn.startswith(bruAOCB4ZoHVF7): Ga8xfYU6ht7cHjzn = O9wzaDlICnq.split(HHthiRYs8T6IO3qUyX(u"࠭࠺ࠨഭ"),YoMw2J1Ljp(u"࠶඀"))[nxUveizbLEAT2FBNy3]+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧ࠻ࠩമ")+Ga8xfYU6ht7cHjzn
			elif Ga8xfYU6ht7cHjzn.startswith(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M): Ga8xfYU6ht7cHjzn = hBRWs4K6t1nderkNEQo7bIvCFuZfS(O9wzaDlICnq,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨࡷࡵࡰࠬയ"))+Ga8xfYU6ht7cHjzn
			else: Ga8xfYU6ht7cHjzn = O9wzaDlICnq.rsplit(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠷ඁ"))[nxUveizbLEAT2FBNy3]+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
		qnE2chelYX3w9RAMSb = Cfr9RlkW32GtYT7ijNbFEJDqy.request(CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࡊࡉ࡙࠭ര"),Ga8xfYU6ht7cHjzn,headers=ZZTivR1uy8jFJ7qUa5QNYCtd4,verify=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		itIUGmTQJKYwq793FNg = qnE2chelYX3w9RAMSb.content
		zO3AUVIRFf8YcXa = len(itIUGmTQJKYwq793FNg)
		xJ3PsEvbTm1QB8IqzDl = len(Sp6qOyDB0nt5Qo4KwbPfcWYe)
		kuwzNQBgO2rl = zO3AUVIRFf8YcXa*xJ3PsEvbTm1QB8IqzDl
	else:
		zO3AUVIRFf8YcXa = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠱ං")*FFUbpd3xE58zLNGsinlCvgrB2f
		qnE2chelYX3w9RAMSb = Cfr9RlkW32GtYT7ijNbFEJDqy.request(HHthiRYs8T6IO3qUyX(u"ࠪࡋࡊ࡚ࠧറ"),O9wzaDlICnq,headers=ZZTivR1uy8jFJ7qUa5QNYCtd4,verify=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,stream=dbo4vrnTM56I)
		if gNPRXprEAQJ(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬല") in qnE2chelYX3w9RAMSb.headers: kuwzNQBgO2rl = int(qnE2chelYX3w9RAMSb.headers[ZeV4vau9CjN(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ള")])
		xJ3PsEvbTm1QB8IqzDl = int(kuwzNQBgO2rl//zO3AUVIRFf8YcXa)
	m243m086aQdTDwuyR5vEcBox7KNkl = int(kuwzNQBgO2rl//FFUbpd3xE58zLNGsinlCvgrB2f)+sdRqnego9PclrL4m2J(u"࠲ඃ")
	if kuwzNQBgO2rl<u8iSx05wLfVyMNp1X3l(u"࠴࠴࠴࠵࠶඄"):
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+z8wTfYPiRQL(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨഴ")+O9wzaDlICnq+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫവ")+str(m243m086aQdTDwuyR5vEcBox7KNkl)+WlU7AtONpyj3(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧശ")+str(IbwoFENtqAYvHBQaRfUKJVZ98urL)+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬഷ")+el62cKSsRpGCfM4uLhoajTb5UWwHmn+FkqI4Gm8wMvUVbgo(u"ࠪࠤࡢ࠭സ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,sdRqnego9PclrL4m2J(u"ࠫๆฺไࠡใํࠤ๊฿ัโหࠣัั๋ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็้้็ࠠึ฼ํีࠥาฯศ๋่ࠢ์ึวࠡๆสࠤ๏๋ใ็ࠢ็่อืๆศ็ฯࠤฯำๅ๋ๆ๋ࠣีอࠠศๆ่่ๆ࠭ഹ"))
		return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	VvNPe9aKLIs3cdMb = z8wTfYPiRQL(u"࠷࠴࠵අ")
	kUJ5Cr08m6iNG1tFn = IbwoFENtqAYvHBQaRfUKJVZ98urL-m243m086aQdTDwuyR5vEcBox7KNkl
	if kUJ5Cr08m6iNG1tFn<VvNPe9aKLIs3cdMb:
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬࠦࠠࠡࡐࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡩࡴ࡭ࠣࡷࡵࡧࡣࡦࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫഺ")+O9wzaDlICnq+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜഻ࠢࠪ")+str(m243m086aQdTDwuyR5vEcBox7KNkl)+wb1nC3e8AjRVU4ovsuPa(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟഼ࠥ࠭")+str(IbwoFENtqAYvHBQaRfUKJVZ98urL)+WlU7AtONpyj3(u"ࠨࠢࡐࡆࠥ࠳ࠠࠨഽ")+str(VvNPe9aKLIs3cdMb)+J6G8X3gO1MiKh027D(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬാ")+el62cKSsRpGCfM4uLhoajTb5UWwHmn+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࠤࡢ࠭ി"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,Urj6egiVyHA75ZK(u"้ࠫอ๋๊ࠠฯำ๋ࠥำศฯฬࠤ่อแ๋ห่้ࠣะอๆ์็ࠫീ"),FkqI4Gm8wMvUVbgo(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥำฬๆ้ࠣࠫു")+str(m243m086aQdTDwuyR5vEcBox7KNkl)+gNPRXprEAQJ(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤࠬൂ")+str(IbwoFENtqAYvHBQaRfUKJVZ98urL)+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์้๊ๅฮษไ฼ฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศะ๊้ࠤฺ๊วไๆࠣ๎ัฮࠠฦสๅหฦࠦࠧൃ")+str(VvNPe9aKLIs3cdMb)+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨ่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦร็ࠢฯ๋ฬุใࠡๆสࠤฯ๎ฬะࠢไ๎์ࠦๅิษะอ้ࠥวโ์ฬࠤ้ะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้สࠪൄ"))
		return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(tzEjvOaZWU1A(u"ࠩࡦࡩࡳࡺࡥࡳࠩ൅"),kh850jKbzmBwY,kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"๋้ࠪࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢยࠫെ"),u8iSx05wLfVyMNp1X3l(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤาาๅ่ࠢอๆึ๐ศศࠢࠪേ")+str(m243m086aQdTDwuyR5vEcBox7KNkl)+FkqI4Gm8wMvUVbgo(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣฮ็ื๊ษษࠣࠫൈ")+str(IbwoFENtqAYvHBQaRfUKJVZ98urL)+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭ࠠๆ์฽หออ๊ห๋๋ࠢีอࠠศๆ่่ๆࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ้๊สฮ็ํ่๋ࠥๆࠡษ็ษ๋ะั็ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩ൉"))
	if II7ErX2ocuU!=BBOY8rvinVbFh(u"࠵ආ"):
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,u8iSx05wLfVyMNp1X3l(u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬൊ"))
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡳ࡫ࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪോ")+O9wzaDlICnq+J6G8X3gO1MiKh027D(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩൌ")+el62cKSsRpGCfM4uLhoajTb5UWwHmn+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࠤࡢ്࠭"))
		return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠩൎ"))
	dvKayN8PuxMGoHhbX3qmR46n0 = aaXbN7lmtKqzc2C9JVDi()
	dvKayN8PuxMGoHhbX3qmR46n0.create(el62cKSsRpGCfM4uLhoajTb5UWwHmn,dQvxmFkyLOteNMWBJ2bDHV(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭൏"))
	USXEcZAyrV = dbo4vrnTM56I
	UeqO0bVyYcknh2B = pVesmhFG6wgubAODHSKvN1Wx.time()
	if not Y3Ny5eLHdp.PJ4koZBprVaY3C8:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧ൐"))
		return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if eOQJrvLAZC: NNHQyis9khj3TprB = open(el62cKSsRpGCfM4uLhoajTb5UWwHmn,HHthiRYs8T6IO3qUyX(u"ࠧࡸࡤࠪ൑"))
	else: NNHQyis9khj3TprB = open(el62cKSsRpGCfM4uLhoajTb5UWwHmn.decode(NVbhZ0DTpOkCA),dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡹࡥࠫ൒"))
	if EqRs5OPLAuS==z8wTfYPiRQL(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ൓"):
		for aaHueZUKGJDOvqjAy6CTinMIY in range(BBOY8rvinVbFh(u"࠶ඇ"),xJ3PsEvbTm1QB8IqzDl+BBOY8rvinVbFh(u"࠶ඇ")):
			Ga8xfYU6ht7cHjzn = Sp6qOyDB0nt5Qo4KwbPfcWYe[aaHueZUKGJDOvqjAy6CTinMIY-SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠷ඈ")]
			if not Ga8xfYU6ht7cHjzn.startswith(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪ࡬ࡹࡺࡰࠨൔ")):
				if Ga8xfYU6ht7cHjzn.startswith(bruAOCB4ZoHVF7): Ga8xfYU6ht7cHjzn = O9wzaDlICnq.split(YoMw2J1Ljp(u"ࠫ࠿࠭ൕ"),WlU7AtONpyj3(u"࠱ඉ"))[nxUveizbLEAT2FBNy3]+Urj6egiVyHA75ZK(u"ࠬࡀࠧൖ")+Ga8xfYU6ht7cHjzn
				elif Ga8xfYU6ht7cHjzn.startswith(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M): Ga8xfYU6ht7cHjzn = hBRWs4K6t1nderkNEQo7bIvCFuZfS(O9wzaDlICnq,wb1nC3e8AjRVU4ovsuPa(u"࠭ࡵࡳ࡮ࠪൗ"))+Ga8xfYU6ht7cHjzn
				else: Ga8xfYU6ht7cHjzn = O9wzaDlICnq.rsplit(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,J6G8X3gO1MiKh027D(u"࠲ඊ"))[nxUveizbLEAT2FBNy3]+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
			qnE2chelYX3w9RAMSb = Cfr9RlkW32GtYT7ijNbFEJDqy.request(Urj6egiVyHA75ZK(u"ࠧࡈࡇࡗࠫ൘"),Ga8xfYU6ht7cHjzn,headers=ZZTivR1uy8jFJ7qUa5QNYCtd4,verify=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			itIUGmTQJKYwq793FNg = qnE2chelYX3w9RAMSb.content
			qnE2chelYX3w9RAMSb.close()
			NNHQyis9khj3TprB.write(itIUGmTQJKYwq793FNg)
			WUY1T9OFCRKiV0AQtn47zfp = pVesmhFG6wgubAODHSKvN1Wx.time()
			CtIwVh23U4SHscbnE80g6 = WUY1T9OFCRKiV0AQtn47zfp-UeqO0bVyYcknh2B
			zYoukVlxLWqBMr = CtIwVh23U4SHscbnE80g6//aaHueZUKGJDOvqjAy6CTinMIY
			XzUjp4a2vrCQ = zYoukVlxLWqBMr*(xJ3PsEvbTm1QB8IqzDl+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠳උ"))
			qNHlgOh5tZ6zijLIF = XzUjp4a2vrCQ-CtIwVh23U4SHscbnE80g6
			TTXCigp03UrWMSxNql(dvKayN8PuxMGoHhbX3qmR46n0,int(HfuZG0aphlYnVLOyAk93rj(u"࠵࠵࠶ඍ")*aaHueZUKGJDOvqjAy6CTinMIY//(xJ3PsEvbTm1QB8IqzDl+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠴ඌ"))),BBOY8rvinVbFh(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ൙"),ZeV4vau9CjN(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ൚"),str(aaHueZUKGJDOvqjAy6CTinMIY*zO3AUVIRFf8YcXa//FFUbpd3xE58zLNGsinlCvgrB2f)+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+str(m243m086aQdTDwuyR5vEcBox7KNkl)+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ൛")+pVesmhFG6wgubAODHSKvN1Wx.strftime(tzEjvOaZWU1A(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ൜"),pVesmhFG6wgubAODHSKvN1Wx.gmtime(qNHlgOh5tZ6zijLIF))+gNPRXprEAQJ(u"ࠬࠦเࠨ൝"))
			if dvKayN8PuxMGoHhbX3qmR46n0.iscanceled():
				USXEcZAyrV = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
				break
	else:
		aaHueZUKGJDOvqjAy6CTinMIY = YoMw2J1Ljp(u"࠵ඎ")
		for itIUGmTQJKYwq793FNg in qnE2chelYX3w9RAMSb.iter_content(chunk_size=zO3AUVIRFf8YcXa):
			NNHQyis9khj3TprB.write(itIUGmTQJKYwq793FNg)
			aaHueZUKGJDOvqjAy6CTinMIY = aaHueZUKGJDOvqjAy6CTinMIY+tzEjvOaZWU1A(u"࠷ඏ")
			WUY1T9OFCRKiV0AQtn47zfp = pVesmhFG6wgubAODHSKvN1Wx.time()
			CtIwVh23U4SHscbnE80g6 = WUY1T9OFCRKiV0AQtn47zfp-UeqO0bVyYcknh2B
			zYoukVlxLWqBMr = CtIwVh23U4SHscbnE80g6/aaHueZUKGJDOvqjAy6CTinMIY
			XzUjp4a2vrCQ = zYoukVlxLWqBMr*(xJ3PsEvbTm1QB8IqzDl+sdRqnego9PclrL4m2J(u"࠱ඐ"))
			qNHlgOh5tZ6zijLIF = XzUjp4a2vrCQ-CtIwVh23U4SHscbnE80g6
			TTXCigp03UrWMSxNql(dvKayN8PuxMGoHhbX3qmR46n0,int(FkqI4Gm8wMvUVbgo(u"࠳࠳࠴ඒ")*aaHueZUKGJDOvqjAy6CTinMIY/(xJ3PsEvbTm1QB8IqzDl+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠲එ"))),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧ൞"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧൟ"),str(aaHueZUKGJDOvqjAy6CTinMIY*zO3AUVIRFf8YcXa//FFUbpd3xE58zLNGsinlCvgrB2f)+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+str(m243m086aQdTDwuyR5vEcBox7KNkl)+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ൠ")+pVesmhFG6wgubAODHSKvN1Wx.strftime(HfuZG0aphlYnVLOyAk93rj(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦൡ"),pVesmhFG6wgubAODHSKvN1Wx.gmtime(qNHlgOh5tZ6zijLIF))+YoMw2J1Ljp(u"ࠪࠤๅ࠭ൢ"))
			if dvKayN8PuxMGoHhbX3qmR46n0.iscanceled():
				USXEcZAyrV = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
				break
		qnE2chelYX3w9RAMSb.close()
	NNHQyis9khj3TprB.close()
	dvKayN8PuxMGoHhbX3qmR46n0.close()
	if not USXEcZAyrV:
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨൣ")+O9wzaDlICnq+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ൤")+el62cKSsRpGCfM4uLhoajTb5UWwHmn+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࠠ࡞ࠩ൥"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Urj6egiVyHA75ZK(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ൦"))
		return dbo4vrnTM56I
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+FkqI4Gm8wMvUVbgo(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ൧")+O9wzaDlICnq+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ൨")+el62cKSsRpGCfM4uLhoajTb5UWwHmn+XasF0WO7rDUHnEt8hAl9kLN(u"ࠪࠤࡢ࠭൩"))
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,tzEjvOaZWU1A(u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪ൪"))
	return dbo4vrnTM56I
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'YOUTUBE'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_YUT_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
sew1FPnz05lIrc9f8DQBZtE7 = 0
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text,type,QPZDaMKgtTUyNjB7EqvOLwph,name,vvufbqFnUclCD5MxOz):
	if	 mode==140: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==141: PP3FsDicLyWuTR7GV5Ia = X9D5tljKCfU3ZdrM2OPiWezGk(url,name,vvufbqFnUclCD5MxOz)
	elif mode==143: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url,type)
	elif mode==144: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,QPZDaMKgtTUyNjB7EqvOLwph,text)
	elif mode==145: PP3FsDicLyWuTR7GV5Ia = bqedPTRD0YhxuVNw1UM(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==147: PP3FsDicLyWuTR7GV5Ia = HHwX4lcCW5evhFRDdz()
	elif mode==148: PP3FsDicLyWuTR7GV5Ia = VVqA1WGz2IhYwnCkXsF()
	elif mode==149: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	if 0:
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'قائمة 1',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'قائمة 2',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'شخص',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/user/TCNofficial',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'موقع',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'حساب',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/@TheSocialCTV',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'العاب',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/gaming',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'افلام',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/feed/storefront',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مختارات',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/feed/guide_builder',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'قصيرة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/shorts',144,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'تصفح',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/youtubei/v1/guide?key=',144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'رئيسية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+kh850jKbzmBwY,144)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'رائج',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/feed/trending?bp=',144)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,149,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الرائجة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/feed/trending',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'التصفح',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/youtubei/v1/guide?key=',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'القصيرة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/shorts',144,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مختارات يوتيوب',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/feed/guide_builder',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مختارات البرنامج',kh850jKbzmBwY,290)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: قنوات عربية',kh850jKbzmBwY,147)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: قنوات أجنبية',kh850jKbzmBwY,148)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: افلام عربية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=فيلم',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: افلام اجنبية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=movie',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: مسرحيات عربية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=مسرحية',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: مسلسلات عربية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: مسلسلات اجنبية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=series&sp=EgIQAw==',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: مسلسلات كارتون',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=كارتون&sp=EgIQAw==',144)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث: خطبة المرجعية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def X9D5tljKCfU3ZdrM2OPiWezGk(url,name,vvufbqFnUclCD5MxOz):
	name = jkFVp3s1NGQ0(name)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'CHNL:  '+name,url,144,vvufbqFnUclCD5MxOz)
	return
def HHwX4lcCW5evhFRDdz():
	bsZhnoqjD3U(WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def VVqA1WGz2IhYwnCkXsF():
	bsZhnoqjD3U(WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query=tv&sp=EgJAAQ==')
	return
def yv8LezRQifhw1Kx(url,type):
	url = url.split('&',1)[0]
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo([url],vkNGie5mhCqoTFRzPKaML0x6,type,url)
	return
def OJrgIXbSm8QFY92HcB7o(qsV5hGHbYfnW8exI2OmN0RZi9EU,url,CCb3sqcILQHYeMzR):
	level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = CCb3sqcILQHYeMzR.split('::')
	p4nlo6ONCVjFiuk,DzL6ecdrWyqR21xgn = [],[]
	if '/youtubei/v1/browse' in url: p4nlo6ONCVjFiuk.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: p4nlo6ONCVjFiuk.append("yccc['onResponseReceivedCommands']")
	p4nlo6ONCVjFiuk.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': p4nlo6ONCVjFiuk.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	p4nlo6ONCVjFiuk.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	p4nlo6ONCVjFiuk.append("yccc['entries']")
	p4nlo6ONCVjFiuk.append("yccc['items'][3]['guideSectionRenderer']['items']")
	naRfBT3xMzWqDKJVYo2v,t9qGvc8yJE1T5Sfw,KgisMv38jGPEqp5BnmuzA = w3WtRAYg1cC(qsV5hGHbYfnW8exI2OmN0RZi9EU,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
	if level=='1' and naRfBT3xMzWqDKJVYo2v:
		if len(t9qGvc8yJE1T5Sfw)>1 and 'search_query' not in url:
			for ukcyNFCBIWoZtMH7f2 in range(len(t9qGvc8yJE1T5Sfw)):
				wQvkxJV20cXbjptnE54o = str(ukcyNFCBIWoZtMH7f2)
				p4nlo6ONCVjFiuk = []
				p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['reloadContinuationItemsCommand']['continuationItems']")
				p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['command']")
				p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]")
				jVhaOJ9utFmLGZpHceKNMlE,JJNIsO8Vcbx0,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(t9qGvc8yJE1T5Sfw,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
				if jVhaOJ9utFmLGZpHceKNMlE: DzL6ecdrWyqR21xgn.append([JJNIsO8Vcbx0,url,'2::'+wQvkxJV20cXbjptnE54o+'::0::0'])
			p4nlo6ONCVjFiuk.append("yccc['continuationEndpoint']")
			jVhaOJ9utFmLGZpHceKNMlE,JJNIsO8Vcbx0,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(qsV5hGHbYfnW8exI2OmN0RZi9EU,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
			if jVhaOJ9utFmLGZpHceKNMlE and DzL6ecdrWyqR21xgn and 'continuationCommand' in list(JJNIsO8Vcbx0.keys()):
				Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/my_main_page_shorts_link'
				DzL6ecdrWyqR21xgn.append([JJNIsO8Vcbx0,Ga8xfYU6ht7cHjzn,'1::0::0::0'])
	return t9qGvc8yJE1T5Sfw,naRfBT3xMzWqDKJVYo2v,DzL6ecdrWyqR21xgn,KgisMv38jGPEqp5BnmuzA
def nmsKlkhocy6FX2C9JNu03BA1W(qsV5hGHbYfnW8exI2OmN0RZi9EU,t9qGvc8yJE1T5Sfw,url,CCb3sqcILQHYeMzR):
	level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = CCb3sqcILQHYeMzR.split('::')
	p4nlo6ONCVjFiuk,UgbL39B8IJphnZjRmDrousqadWGyx = [],[]
	p4nlo6ONCVjFiuk.append("yddd[0]['itemSectionRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['reloadContinuationItemsCommand']['continuationItems']")
	p4nlo6ONCVjFiuk.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: p4nlo6ONCVjFiuk.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: p4nlo6ONCVjFiuk.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yddd["+wQvkxJV20cXbjptnE54o+"]")
	gg30t5XPqdIcWKD1z6Yia,NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,UBu9xVswfvpYioAZOh3mjQ = w3WtRAYg1cC(t9qGvc8yJE1T5Sfw,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
	if level=='2' and gg30t5XPqdIcWKD1z6Yia:
		if len(NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O)>1:
			for ukcyNFCBIWoZtMH7f2 in range(len(NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O)):
				jBHt2TPim1LlfnRdMJbN = str(ukcyNFCBIWoZtMH7f2)
				p4nlo6ONCVjFiuk = []
				p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['richSectionRenderer']['content']")
				p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]")
				p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['richItemRenderer']['content']")
				p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]")
				jVhaOJ9utFmLGZpHceKNMlE,JJNIsO8Vcbx0,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
				if jVhaOJ9utFmLGZpHceKNMlE: UgbL39B8IJphnZjRmDrousqadWGyx.append([JJNIsO8Vcbx0,url,'3::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::0'])
			p4nlo6ONCVjFiuk.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			p4nlo6ONCVjFiuk.append("yddd[1]")
			jVhaOJ9utFmLGZpHceKNMlE,JJNIsO8Vcbx0,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(t9qGvc8yJE1T5Sfw,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
			if jVhaOJ9utFmLGZpHceKNMlE and UgbL39B8IJphnZjRmDrousqadWGyx and 'continuationItemRenderer' in list(JJNIsO8Vcbx0.keys()):
				UgbL39B8IJphnZjRmDrousqadWGyx.append([JJNIsO8Vcbx0,url,'3::0::0::0'])
	return NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,gg30t5XPqdIcWKD1z6Yia,UgbL39B8IJphnZjRmDrousqadWGyx,UBu9xVswfvpYioAZOh3mjQ
def f7fv8gmH1Dbw5tp3XakBMNzV6(qsV5hGHbYfnW8exI2OmN0RZi9EU,NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,url,CCb3sqcILQHYeMzR):
	level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = CCb3sqcILQHYeMzR.split('::')
	p4nlo6ONCVjFiuk,YfAxhtuOsW38BScbV9IilEX = [],[]
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['reelShelfRenderer']['items']")
	p4nlo6ONCVjFiuk.append("yeee["+jBHt2TPim1LlfnRdMJbN+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	p4nlo6ONCVjFiuk.append("yeee")
	gDKFQEUVBkY,L1FstYoVPlzQmGHi8RWNnMkD,mDN79SrApohx0Vt364cLETla = w3WtRAYg1cC(NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
	if level=='3' and gDKFQEUVBkY:
		if len(L1FstYoVPlzQmGHi8RWNnMkD)>0:
			for ukcyNFCBIWoZtMH7f2 in range(len(L1FstYoVPlzQmGHi8RWNnMkD)):
				UyQMsIctXYrd42enS7vwDOJ = str(ukcyNFCBIWoZtMH7f2)
				p4nlo6ONCVjFiuk = []
				p4nlo6ONCVjFiuk.append("yfff["+UyQMsIctXYrd42enS7vwDOJ+"]['richItemRenderer']['content']")
				p4nlo6ONCVjFiuk.append("yfff["+UyQMsIctXYrd42enS7vwDOJ+"]['gameCardRenderer']['game']")
				p4nlo6ONCVjFiuk.append("yfff["+UyQMsIctXYrd42enS7vwDOJ+"]['itemSectionRenderer']['contents'][0]")
				p4nlo6ONCVjFiuk.append("yfff["+UyQMsIctXYrd42enS7vwDOJ+"]")
				p4nlo6ONCVjFiuk.append("yfff")
				jVhaOJ9utFmLGZpHceKNMlE,JJNIsO8Vcbx0,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(L1FstYoVPlzQmGHi8RWNnMkD,kh850jKbzmBwY,p4nlo6ONCVjFiuk)
				if jVhaOJ9utFmLGZpHceKNMlE: YfAxhtuOsW38BScbV9IilEX.append([JJNIsO8Vcbx0,url,'4::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ])
	return L1FstYoVPlzQmGHi8RWNnMkD,gDKFQEUVBkY,YfAxhtuOsW38BScbV9IilEX,mDN79SrApohx0Vt364cLETla
def w3WtRAYg1cC(SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1,Ajeuh9WfIX2zwTC):
	qsV5hGHbYfnW8exI2OmN0RZi9EU,JE4RrP2aZqWOLV1 = SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1
	t9qGvc8yJE1T5Sfw,JE4RrP2aZqWOLV1 = SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1
	NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,JE4RrP2aZqWOLV1 = SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1
	L1FstYoVPlzQmGHi8RWNnMkD,JE4RrP2aZqWOLV1 = SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1
	JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg = SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1
	count = len(Ajeuh9WfIX2zwTC)
	for aaHueZUKGJDOvqjAy6CTinMIY in range(count):
		try:
			WlGw8ukCyBFvPz = eval(Ajeuh9WfIX2zwTC[aaHueZUKGJDOvqjAy6CTinMIY])
			return True,WlGw8ukCyBFvPz,aaHueZUKGJDOvqjAy6CTinMIY+1
		except: pass
	return False,kh850jKbzmBwY,0
def bsZhnoqjD3U(url,CCb3sqcILQHYeMzR=kh850jKbzmBwY,data=kh850jKbzmBwY):
	DzL6ecdrWyqR21xgn,UgbL39B8IJphnZjRmDrousqadWGyx,YfAxhtuOsW38BScbV9IilEX = [],[],[]
	if '::' not in CCb3sqcILQHYeMzR: CCb3sqcILQHYeMzR = '1::0::0::0'
	level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = CCb3sqcILQHYeMzR.split('::')
	if level=='4': level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = '1',wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ
	data = data.replace('_REMEMBERRESULTS_',kh850jKbzmBwY)
	uP1m46pAK5a3UgdqvBz9rnL,qsV5hGHbYfnW8exI2OmN0RZi9EU,hhUDZA3piIJyMsxfbgGdWO = eT5kf76ME9mpVnauDZYK1(url,data)
	CCb3sqcILQHYeMzR = level+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
	if level in ['1','2','3']:
		t9qGvc8yJE1T5Sfw,naRfBT3xMzWqDKJVYo2v,DzL6ecdrWyqR21xgn,KgisMv38jGPEqp5BnmuzA = OJrgIXbSm8QFY92HcB7o(qsV5hGHbYfnW8exI2OmN0RZi9EU,url,CCb3sqcILQHYeMzR)
		if not naRfBT3xMzWqDKJVYo2v: return
		XaquxBLdi0gt = len(DzL6ecdrWyqR21xgn)
		if XaquxBLdi0gt<2:
			if level=='1': level = '2'
			DzL6ecdrWyqR21xgn = []
	CCb3sqcILQHYeMzR = level+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
	if level in ['2','3']:
		NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,gg30t5XPqdIcWKD1z6Yia,UgbL39B8IJphnZjRmDrousqadWGyx,UBu9xVswfvpYioAZOh3mjQ = nmsKlkhocy6FX2C9JNu03BA1W(qsV5hGHbYfnW8exI2OmN0RZi9EU,t9qGvc8yJE1T5Sfw,url,CCb3sqcILQHYeMzR)
		if not gg30t5XPqdIcWKD1z6Yia: return
		xxKCysiJOE = len(UgbL39B8IJphnZjRmDrousqadWGyx)
		if xxKCysiJOE<2:
			if level=='2': level = '3'
			UgbL39B8IJphnZjRmDrousqadWGyx = []
	CCb3sqcILQHYeMzR = level+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
	if level in ['3']:
		L1FstYoVPlzQmGHi8RWNnMkD,gDKFQEUVBkY,YfAxhtuOsW38BScbV9IilEX,mDN79SrApohx0Vt364cLETla = f7fv8gmH1Dbw5tp3XakBMNzV6(qsV5hGHbYfnW8exI2OmN0RZi9EU,NujSXaGZ86Tk2eoJQYhvqtCHfDmd9O,url,CCb3sqcILQHYeMzR)
		if not gDKFQEUVBkY: return
		lj9DQcNP3Auif = len(YfAxhtuOsW38BScbV9IilEX)
	for JJNIsO8Vcbx0,url,CCb3sqcILQHYeMzR in DzL6ecdrWyqR21xgn+UgbL39B8IJphnZjRmDrousqadWGyx+YfAxhtuOsW38BScbV9IilEX:
		kJuXd2DV1ot6 = gecrvyol2MukPXGOE(JJNIsO8Vcbx0,url,CCb3sqcILQHYeMzR)
	return
def gecrvyol2MukPXGOE(JJNIsO8Vcbx0,url=kh850jKbzmBwY,CCb3sqcILQHYeMzR=kh850jKbzmBwY):
	if '::' in CCb3sqcILQHYeMzR: level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = CCb3sqcILQHYeMzR.split('::')
	else: level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = '1','0','0','0'
	jVhaOJ9utFmLGZpHceKNMlE,title,Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,count,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,xTZun9hpjbKqmiJUvWVzySsGk8tE,xIUnT2XsMH93CWw0E4ozrtJ8,KXNZAOHtp5VhMQL1u = DKNXAdMYPe60kjQW(JJNIsO8Vcbx0)
	VpkuSHoBa1REQ5xPO923rX4W = '/videos?' in Ga8xfYU6ht7cHjzn or '/streams?' in Ga8xfYU6ht7cHjzn or '/playlists?' in Ga8xfYU6ht7cHjzn
	HkFhwRE6A9qsMGL8KiUrmguBV7nv = '/channels?' in Ga8xfYU6ht7cHjzn or '/shorts?' in Ga8xfYU6ht7cHjzn
	if VpkuSHoBa1REQ5xPO923rX4W or HkFhwRE6A9qsMGL8KiUrmguBV7nv: Ga8xfYU6ht7cHjzn = url
	VpkuSHoBa1REQ5xPO923rX4W = 'watch?v=' not in Ga8xfYU6ht7cHjzn and '/playlist?list=' not in Ga8xfYU6ht7cHjzn
	HkFhwRE6A9qsMGL8KiUrmguBV7nv = '/gaming' not in Ga8xfYU6ht7cHjzn  and '/feed/storefront' not in Ga8xfYU6ht7cHjzn
	if CCb3sqcILQHYeMzR[0:5]=='3::0::' and VpkuSHoBa1REQ5xPO923rX4W and HkFhwRE6A9qsMGL8KiUrmguBV7nv: Ga8xfYU6ht7cHjzn = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in Ga8xfYU6ht7cHjzn:
		level,wQvkxJV20cXbjptnE54o,jBHt2TPim1LlfnRdMJbN,UyQMsIctXYrd42enS7vwDOJ = '1','0','0','0'
		CCb3sqcILQHYeMzR = kh850jKbzmBwY
	hhUDZA3piIJyMsxfbgGdWO = kh850jKbzmBwY
	if '/youtubei/v1/browse' in Ga8xfYU6ht7cHjzn or '/youtubei/v1/search' in Ga8xfYU6ht7cHjzn or '/my_main_page_shorts_link' in url:
		data = l7tuXCf0oKV9FPOy6Hb.getSetting('av.youtube.data')
		if data.count(':::')==4:
			uUahjqdL8PEG0c3mReioFwxAS7O,key,lB8D9p3Ij6Eq4FJuTbocPgNYtXU,tquLUCHYBA,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = data.split(':::')
			hhUDZA3piIJyMsxfbgGdWO = uUahjqdL8PEG0c3mReioFwxAS7O+':::'+key+':::'+lB8D9p3Ij6Eq4FJuTbocPgNYtXU+':::'+tquLUCHYBA+':::'+KXNZAOHtp5VhMQL1u
			if '/my_main_page_shorts_link' in url and not Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = url
			else: Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?key='+key
	if not title:
		global sew1FPnz05lIrc9f8DQBZtE7
		sew1FPnz05lIrc9f8DQBZtE7 += 1
		title = 'فيديوهات '+str(sew1FPnz05lIrc9f8DQBZtE7)
		CCb3sqcILQHYeMzR = '3'+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
	if not jVhaOJ9utFmLGZpHceKNMlE: return False
	elif 'searchPyvRenderer' in str(JJNIsO8Vcbx0): return False
	elif '/about' in Ga8xfYU6ht7cHjzn: return False
	elif '/community' in Ga8xfYU6ht7cHjzn: return False
	elif 'continuationItemRenderer' in list(JJNIsO8Vcbx0.keys()) or 'continuationCommand' in list(JJNIsO8Vcbx0.keys()):
		if int(level)>1: level = str(int(level)-1)
		CCb3sqcILQHYeMzR = level+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: '+'صفحة أخرى',Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR,hhUDZA3piIJyMsxfbgGdWO)
	elif '/search' in Ga8xfYU6ht7cHjzn:
		title = ':: '+title
		CCb3sqcILQHYeMzR = '3'+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
		url = url.replace('/search',kh850jKbzmBwY)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,145,kh850jKbzmBwY,CCb3sqcILQHYeMzR,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not Ga8xfYU6ht7cHjzn:
		CCb3sqcILQHYeMzR = '3'+'::'+wQvkxJV20cXbjptnE54o+'::'+jBHt2TPim1LlfnRdMJbN+'::'+UyQMsIctXYrd42enS7vwDOJ
		title = ':: '+title
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR,hhUDZA3piIJyMsxfbgGdWO)
	elif '/browse' in Ga8xfYU6ht7cHjzn and url==WLjaXVNk2dnAJzPpy6OlMv4qoi9:
		title = ':: '+title
		CCb3sqcILQHYeMzR = '2::0::0::0'
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR,hhUDZA3piIJyMsxfbgGdWO)
	elif not Ga8xfYU6ht7cHjzn and 'horizontalMovieListRenderer' in str(JJNIsO8Vcbx0):
		title = ':: '+title
		CCb3sqcILQHYeMzR = '3::0::0::0'
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR)
	elif 'messageRenderer' in str(JJNIsO8Vcbx0):
		EE6ysIeB8jKNgCfOkv('link',GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,9999)
	elif xTZun9hpjbKqmiJUvWVzySsGk8tE:
		EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+xTZun9hpjbKqmiJUvWVzySsGk8tE+title,Ga8xfYU6ht7cHjzn,143,NWqAr40jTLlMBemn3o79y)
	elif '/playlist?list=' in Ga8xfYU6ht7cHjzn:
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('&playnext=1',kh850jKbzmBwY)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'LIST'+count+':  '+title,Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR)
	elif '/shorts/' in Ga8xfYU6ht7cHjzn:
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('&list=',1)[0]
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,143,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	elif '/watch?v=' in Ga8xfYU6ht7cHjzn:
		if '&list=' in Ga8xfYU6ht7cHjzn and count:
			hs94nomAjJGIpbua3DQSBtv8eHq = Ga8xfYU6ht7cHjzn.split('&list=',1)[1]
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/playlist?list='+hs94nomAjJGIpbua3DQSBtv8eHq
			CCb3sqcILQHYeMzR = '1::0::0::0'
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'LIST'+count+':  '+title,Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR)
		else:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('&list=',1)[0]
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,143,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	elif '/channel/' in Ga8xfYU6ht7cHjzn or '/c/' in Ga8xfYU6ht7cHjzn or ('/@' in Ga8xfYU6ht7cHjzn and Ga8xfYU6ht7cHjzn.count(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)==3):
		if BBJYzRKgHkOqx:
			title = title.decode(NVbhZ0DTpOkCA).encode('raw_unicode_escape')
			title = Z4CP1xs5w7fi(title)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'CHNL'+count+':  '+title,Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR)
	elif '/user/' in Ga8xfYU6ht7cHjzn:
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'USER'+count+':  '+title,Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR)
	else:
		if not Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = url
		title = ':: '+title
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,144,NWqAr40jTLlMBemn3o79y,CCb3sqcILQHYeMzR,hhUDZA3piIJyMsxfbgGdWO)
	return True
def DKNXAdMYPe60kjQW(JJNIsO8Vcbx0):
	jVhaOJ9utFmLGZpHceKNMlE,title,Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,count,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,xTZun9hpjbKqmiJUvWVzySsGk8tE,xIUnT2XsMH93CWw0E4ozrtJ8,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = False,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY
	if not isinstance(JJNIsO8Vcbx0,dict): return jVhaOJ9utFmLGZpHceKNMlE,title,Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,count,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,xTZun9hpjbKqmiJUvWVzySsGk8tE,xIUnT2XsMH93CWw0E4ozrtJ8,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk
	for ZmfINyWY93 in list(JJNIsO8Vcbx0.keys()):
		dDEb4fVZNB5HQv7wlU0JFRpIg = JJNIsO8Vcbx0[ZmfINyWY93]
		if isinstance(dDEb4fVZNB5HQv7wlU0JFRpIg,dict): break
	p4nlo6ONCVjFiuk = []
	p4nlo6ONCVjFiuk.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['header']['richListHeaderRenderer']['title']")
	p4nlo6ONCVjFiuk.append("yrender['headline']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['unplayableText']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['formattedTitle']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['title']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['title']['runs'][0]['text']")
	p4nlo6ONCVjFiuk.append("yrender['text']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['text']['runs'][0]['text']")
	p4nlo6ONCVjFiuk.append("yrender['title']['content']")
	p4nlo6ONCVjFiuk.append("yrender['title']")
	p4nlo6ONCVjFiuk.append("item['title']")
	p4nlo6ONCVjFiuk.append("item['reelWatchEndpoint']['videoId']")
	jVhaOJ9utFmLGZpHceKNMlE,title,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg,p4nlo6ONCVjFiuk)
	p4nlo6ONCVjFiuk = []
	p4nlo6ONCVjFiuk.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	p4nlo6ONCVjFiuk.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	p4nlo6ONCVjFiuk.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	p4nlo6ONCVjFiuk.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	p4nlo6ONCVjFiuk.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	p4nlo6ONCVjFiuk.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	p4nlo6ONCVjFiuk.append("item['commandMetadata']['webCommandMetadata']['url']")
	jVhaOJ9utFmLGZpHceKNMlE,Ga8xfYU6ht7cHjzn,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg,p4nlo6ONCVjFiuk)
	p4nlo6ONCVjFiuk = []
	p4nlo6ONCVjFiuk.append("yrender['thumbnail']['thumbnails'][0]['url']")
	p4nlo6ONCVjFiuk.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	p4nlo6ONCVjFiuk.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	jVhaOJ9utFmLGZpHceKNMlE,NWqAr40jTLlMBemn3o79y,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg,p4nlo6ONCVjFiuk)
	p4nlo6ONCVjFiuk = []
	p4nlo6ONCVjFiuk.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	p4nlo6ONCVjFiuk.append("yrender['videoCountShortText']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['videoCountText']['runs'][0]['text']")
	p4nlo6ONCVjFiuk.append("yrender['videoCount']")
	jVhaOJ9utFmLGZpHceKNMlE,count,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg,p4nlo6ONCVjFiuk)
	p4nlo6ONCVjFiuk = []
	p4nlo6ONCVjFiuk.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	p4nlo6ONCVjFiuk.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['lengthText']['simpleText']")
	p4nlo6ONCVjFiuk.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	p4nlo6ONCVjFiuk.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	jVhaOJ9utFmLGZpHceKNMlE,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg,p4nlo6ONCVjFiuk)
	p4nlo6ONCVjFiuk = []
	p4nlo6ONCVjFiuk.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	p4nlo6ONCVjFiuk.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	jVhaOJ9utFmLGZpHceKNMlE,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk,hUfv2IrbNmXRzGPMdt = w3WtRAYg1cC(JJNIsO8Vcbx0,dDEb4fVZNB5HQv7wlU0JFRpIg,p4nlo6ONCVjFiuk)
	if 'LIVE' in qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ: qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,xTZun9hpjbKqmiJUvWVzySsGk8tE = kh850jKbzmBwY,'LIVE:  '
	if 'مباشر' in qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ: qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,xTZun9hpjbKqmiJUvWVzySsGk8tE = kh850jKbzmBwY,'LIVE:  '
	if 'badges' in list(dDEb4fVZNB5HQv7wlU0JFRpIg.keys()):
		g1DMntwFB6E2ChHpuN0j = str(dDEb4fVZNB5HQv7wlU0JFRpIg['badges'])
		if 'Free with Ads' in g1DMntwFB6E2ChHpuN0j: xIUnT2XsMH93CWw0E4ozrtJ8 = '$:  '
		if 'LIVE' in g1DMntwFB6E2ChHpuN0j: xTZun9hpjbKqmiJUvWVzySsGk8tE = 'LIVE:  '
		if 'Buy' in g1DMntwFB6E2ChHpuN0j or 'Rent' in g1DMntwFB6E2ChHpuN0j: xIUnT2XsMH93CWw0E4ozrtJ8 = '$$:  '
		if iBnaOtjD0XE63YSrbP4NHye(u'مباشر') in g1DMntwFB6E2ChHpuN0j: xTZun9hpjbKqmiJUvWVzySsGk8tE = 'LIVE:  '
		if iBnaOtjD0XE63YSrbP4NHye(u'شراء') in g1DMntwFB6E2ChHpuN0j: xIUnT2XsMH93CWw0E4ozrtJ8 = '$$:  '
		if iBnaOtjD0XE63YSrbP4NHye(u'استئجار') in g1DMntwFB6E2ChHpuN0j: xIUnT2XsMH93CWw0E4ozrtJ8 = '$$:  '
		if iBnaOtjD0XE63YSrbP4NHye(u'إعلانات') in g1DMntwFB6E2ChHpuN0j: xIUnT2XsMH93CWw0E4ozrtJ8 = '$:  '
	Ga8xfYU6ht7cHjzn = Z4CP1xs5w7fi(Ga8xfYU6ht7cHjzn)
	if Ga8xfYU6ht7cHjzn and 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
	NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.split('?')[0]
	if  NWqAr40jTLlMBemn3o79y and 'http' not in NWqAr40jTLlMBemn3o79y: NWqAr40jTLlMBemn3o79y = 'https:'+NWqAr40jTLlMBemn3o79y
	title = Z4CP1xs5w7fi(title)
	if xIUnT2XsMH93CWw0E4ozrtJ8: title = xIUnT2XsMH93CWw0E4ozrtJ8+title
	qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ.replace(',',kh850jKbzmBwY)
	count = count.replace(',',kh850jKbzmBwY)
	count = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('\d+',count)
	if count: count = count[0]
	else: count = kh850jKbzmBwY
	return True,title,Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,count,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,xTZun9hpjbKqmiJUvWVzySsGk8tE,xIUnT2XsMH93CWw0E4ozrtJ8,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk
def eT5kf76ME9mpVnauDZYK1(url,data=kh850jKbzmBwY,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG==kh850jKbzmBwY: jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = 'ytInitialData'
	GYOXsa4p1l = e9SaDhW4XdLY2HfyPU7JI()
	tqQkcdHYyM3L7h = {'User-Agent':GYOXsa4p1l,'Cookie':'PREF=hl=ar'}
	global l7tuXCf0oKV9FPOy6Hb
	if not data: data = l7tuXCf0oKV9FPOy6Hb.getSetting('av.youtube.data')
	if data.count(':::')==4: uUahjqdL8PEG0c3mReioFwxAS7O,key,lB8D9p3Ij6Eq4FJuTbocPgNYtXU,tquLUCHYBA,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = data.split(':::')
	else: uUahjqdL8PEG0c3mReioFwxAS7O,key,lB8D9p3Ij6Eq4FJuTbocPgNYtXU,tquLUCHYBA,ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY
	hhUDZA3piIJyMsxfbgGdWO = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":lB8D9p3Ij6Eq4FJuTbocPgNYtXU}}}
	if url==WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/shorts' or '/my_main_page_shorts_link' in url:
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		hhUDZA3piIJyMsxfbgGdWO['sequenceParams'] = uUahjqdL8PEG0c3mReioFwxAS7O
		hhUDZA3piIJyMsxfbgGdWO = str(hhUDZA3piIJyMsxfbgGdWO)
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',url,hhUDZA3piIJyMsxfbgGdWO,tqQkcdHYyM3L7h,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/youtubei/v1/guide?key='+key
		hhUDZA3piIJyMsxfbgGdWO = str(hhUDZA3piIJyMsxfbgGdWO)
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',url,hhUDZA3piIJyMsxfbgGdWO,tqQkcdHYyM3L7h,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and uUahjqdL8PEG0c3mReioFwxAS7O:
		hhUDZA3piIJyMsxfbgGdWO['continuation'] = ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk
		hhUDZA3piIJyMsxfbgGdWO['context']['client']['visitorData'] = uUahjqdL8PEG0c3mReioFwxAS7O
		hhUDZA3piIJyMsxfbgGdWO = str(hhUDZA3piIJyMsxfbgGdWO)
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',url,hhUDZA3piIJyMsxfbgGdWO,tqQkcdHYyM3L7h,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and tquLUCHYBA:
		tqQkcdHYyM3L7h.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':lB8D9p3Ij6Eq4FJuTbocPgNYtXU})
		tqQkcdHYyM3L7h.update({'Cookie':'VISITOR_INFO1_LIVE='+tquLUCHYBA})
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,tqQkcdHYyM3L7h,kh850jKbzmBwY,kh850jKbzmBwY,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,tqQkcdHYyM3L7h,kh850jKbzmBwY,kh850jKbzmBwY,'YOUTUBE-GET_PAGE_DATA-6th')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	VBzUkECjaup0d9QSc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"innertubeApiKey".*?"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL|sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.I)
	if VBzUkECjaup0d9QSc: key = VBzUkECjaup0d9QSc[0]
	VBzUkECjaup0d9QSc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"cver".*?"value".*?"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL|sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.I)
	if VBzUkECjaup0d9QSc: lB8D9p3Ij6Eq4FJuTbocPgNYtXU = VBzUkECjaup0d9QSc[0]
	VBzUkECjaup0d9QSc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"visitorData".*?"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL|sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.I)
	if VBzUkECjaup0d9QSc: uUahjqdL8PEG0c3mReioFwxAS7O = VBzUkECjaup0d9QSc[0]
	cookies = OIjmsWqwACpDMT7l3GaYbxtvh0L.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): tquLUCHYBA = cookies['VISITOR_INFO1_LIVE']
	lSZx6VCD5KrTOpcRjH7ok2Ed = uUahjqdL8PEG0c3mReioFwxAS7O+':::'+key+':::'+lB8D9p3Ij6Eq4FJuTbocPgNYtXU+':::'+tquLUCHYBA+':::'+ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ytInitialData' and 'ytInitialData' in uP1m46pAK5a3UgdqvBz9rnL:
		oabPvej8ESnIgh41iqQ0zDxB6C = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('window\["ytInitialData"\] = ({.*?});',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not oabPvej8ESnIgh41iqQ0zDxB6C: oabPvej8ESnIgh41iqQ0zDxB6C = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('var ytInitialData = ({.*?});',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		S58SkwXHrginhjV4LIZzE1Y2 = tmYCsS329HanzjLFbJP('str',oabPvej8ESnIgh41iqQ0zDxB6C[0])
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ytInitialGuideData' and 'ytInitialGuideData' in uP1m46pAK5a3UgdqvBz9rnL:
		oabPvej8ESnIgh41iqQ0zDxB6C = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('var ytInitialGuideData = ({.*?});',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		S58SkwXHrginhjV4LIZzE1Y2 = tmYCsS329HanzjLFbJP('str',oabPvej8ESnIgh41iqQ0zDxB6C[0])
	elif '</script>' not in uP1m46pAK5a3UgdqvBz9rnL: S58SkwXHrginhjV4LIZzE1Y2 = tmYCsS329HanzjLFbJP('str',uP1m46pAK5a3UgdqvBz9rnL)
	else: S58SkwXHrginhjV4LIZzE1Y2 = kh850jKbzmBwY
	if 0:
		qsV5hGHbYfnW8exI2OmN0RZi9EU = str(S58SkwXHrginhjV4LIZzE1Y2)
		if eOQJrvLAZC: qsV5hGHbYfnW8exI2OmN0RZi9EU = qsV5hGHbYfnW8exI2OmN0RZi9EU.encode(NVbhZ0DTpOkCA)
		open('S:\\0000emad.dat','wb').write(qsV5hGHbYfnW8exI2OmN0RZi9EU)
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.youtube.data',lSZx6VCD5KrTOpcRjH7ok2Ed)
	return uP1m46pAK5a3UgdqvBz9rnL,S58SkwXHrginhjV4LIZzE1Y2,lSZx6VCD5KrTOpcRjH7ok2Ed
def bqedPTRD0YhxuVNw1UM(url,CCb3sqcILQHYeMzR):
	search = GG5Fs0hvURxyBV8gz()
	if not search: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	O9wzaDlICnq = url+'/search?query='+search
	bsZhnoqjD3U(O9wzaDlICnq,CCb3sqcILQHYeMzR)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if not search:
		search = GG5Fs0hvURxyBV8gz()
		if not search: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in kFdoZmlxSf8shU: V4VwRJNbtv = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in kFdoZmlxSf8shU: V4VwRJNbtv = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in kFdoZmlxSf8shU: V4VwRJNbtv = '&sp=EgIQAg%253D%253D'
		else: V4VwRJNbtv = kh850jKbzmBwY
		QQJdiByEeNqLYGs = O9wzaDlICnq+V4VwRJNbtv
	else:
		tfKYoGSHPFORcdIAE,cvqI083LrQbKFwo5lmZHVY,EVfKyFrmX1Mpb62tLuHS5w3W = [],[],kh850jKbzmBwY
		mtzegkoZuS7nMXPdNDUKLJ = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		VDTwEtoki5XFBR2JYbZ4cqA = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		H2jMEu1WNJGs3hnob69p = W6EMASlVYF0gvGmzo('اختر البحث المناسب',mtzegkoZuS7nMXPdNDUKLJ)
		if H2jMEu1WNJGs3hnob69p == -1: return
		db0KJC5qhtoQGwUY = VDTwEtoki5XFBR2JYbZ4cqA[H2jMEu1WNJGs3hnob69p]
		uP1m46pAK5a3UgdqvBz9rnL,AYJGshEQbHj0Zfy8qX,data = eT5kf76ME9mpVnauDZYK1(O9wzaDlICnq+db0KJC5qhtoQGwUY)
		if AYJGshEQbHj0Zfy8qX:
			try:
				gTramv6KjWXnMN7O5RUBID0yAz = AYJGshEQbHj0Zfy8qX['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for XM5TohpKmCtJnq10O9VPIfws in range(len(gTramv6KjWXnMN7O5RUBID0yAz)):
					group = gTramv6KjWXnMN7O5RUBID0yAz[XM5TohpKmCtJnq10O9VPIfws]['searchFilterGroupRenderer']['filters']
					for jMTdgy20ZhrX5 in range(len(group)):
						dDEb4fVZNB5HQv7wlU0JFRpIg = group[jMTdgy20ZhrX5]['searchFilterRenderer']
						if 'navigationEndpoint' in list(dDEb4fVZNB5HQv7wlU0JFRpIg.keys()):
							Ga8xfYU6ht7cHjzn = dDEb4fVZNB5HQv7wlU0JFRpIg['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('\u0026','&')
							title = dDEb4fVZNB5HQv7wlU0JFRpIg['tooltip']
							title = title.replace('البحث عن ',kh850jKbzmBwY)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								EVfKyFrmX1Mpb62tLuHS5w3W = title
								jQOlvATLDcdquxVXaJib3Yo5 = Ga8xfYU6ht7cHjzn
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',kh850jKbzmBwY)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								EVfKyFrmX1Mpb62tLuHS5w3W = title
								jQOlvATLDcdquxVXaJib3Yo5 = Ga8xfYU6ht7cHjzn
							if 'Sort by' in title: continue
							tfKYoGSHPFORcdIAE.append(Z4CP1xs5w7fi(title))
							cvqI083LrQbKFwo5lmZHVY.append(Ga8xfYU6ht7cHjzn)
			except: pass
		if not EVfKyFrmX1Mpb62tLuHS5w3W: Wq45BJAIHQiRyKtuX836 = kh850jKbzmBwY
		else:
			tfKYoGSHPFORcdIAE = ['بدون فلتر',EVfKyFrmX1Mpb62tLuHS5w3W]+tfKYoGSHPFORcdIAE
			cvqI083LrQbKFwo5lmZHVY = [kh850jKbzmBwY,jQOlvATLDcdquxVXaJib3Yo5]+cvqI083LrQbKFwo5lmZHVY
			e0vH7okCzg8Z1TAWX3nYBdQ9 = W6EMASlVYF0gvGmzo('موقع يوتيوب - اختر الفلتر',tfKYoGSHPFORcdIAE)
			if e0vH7okCzg8Z1TAWX3nYBdQ9 == -1: return
			Wq45BJAIHQiRyKtuX836 = cvqI083LrQbKFwo5lmZHVY[e0vH7okCzg8Z1TAWX3nYBdQ9]
		if Wq45BJAIHQiRyKtuX836: QQJdiByEeNqLYGs = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Wq45BJAIHQiRyKtuX836
		elif db0KJC5qhtoQGwUY: QQJdiByEeNqLYGs = O9wzaDlICnq+db0KJC5qhtoQGwUY
		else: QQJdiByEeNqLYGs = O9wzaDlICnq
	bsZhnoqjD3U(QQJdiByEeNqLYGs)
	return
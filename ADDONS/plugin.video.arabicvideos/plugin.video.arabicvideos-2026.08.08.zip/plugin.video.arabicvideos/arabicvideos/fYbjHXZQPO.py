# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SHOFHA'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SHT_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==640: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==641: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==642: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==644: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==645: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==649: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,649,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',WLjaXVNk2dnAJzPpy6OlMv4qoi9,641,kh850jKbzmBwY,kh850jKbzmBwY,'featured')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"navslide-divider"(.*?)"navslide-divider"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,644)
	return
def CC6NMTjSO2g(url):
	qwPT5Yf7y2J1d8eX = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-SUBMENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if NSUBGjzyZh5xaKL9AJF:
		ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"presentation"','</ul>')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = [(kh850jKbzmBwY,ZZDUdXR52CMs9K73Ex)]
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' فرز أو فلتر أو ترتيب '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		for JLngAu1qYhtXm0BNr,ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
			qwPT5Yf7y2J1d8eX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if JLngAu1qYhtXm0BNr: JLngAu1qYhtXm0BNr = JLngAu1qYhtXm0BNr+': '
			for Ga8xfYU6ht7cHjzn,title in qwPT5Yf7y2J1d8eX:
				title = JLngAu1qYhtXm0BNr+title
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,641)
	oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-category-subcats"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if oQuiJvtTzwPZbXd7sf4HcG9:
		ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(h729UnyEIjoYSNKcLOvqfV4)<30:
			if qwPT5Yf7y2J1d8eX: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
			for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,641)
	if not NSUBGjzyZh5xaKL9AJF and not oQuiJvtTzwPZbXd7sf4HcG9: bsZhnoqjD3U(url)
	return
def bsZhnoqjD3U(url,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'POST',url,data,headers,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-TITLES-1st')
	else:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-TITLES-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZZDUdXR52CMs9K73Ex,items = kh850jKbzmBwY,[]
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ajax-search':
		ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4: items.append((kh850jKbzmBwY,Ga8xfYU6ht7cHjzn,title))
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"mastcontent-wrap"(.*?)"content"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8,mHjNds76Q1BvDh8e3 = zip(*items)
			items = zip(mHjNds76Q1BvDh8e3,Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8)
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_episodes':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_movies':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(liroJ6qCK9k)>1: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[1]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured_series':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4: items.append((kh850jKbzmBwY,Ga8xfYU6ht7cHjzn,title))
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(data-echo=".*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if ZZDUdXR52CMs9K73Ex and not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items: return
	SHTvIuhX52dxQRsWA = []
	fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,642,NWqAr40jTLlMBemn3o79y)
		elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_episodes':
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,642,NWqAr40jTLlMBemn3o79y)
		elif WULSmfNH09tPIv58snzpCkR:
			title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,645,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,645,NWqAr40jTLlMBemn3o79y)
	if 1:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn=='#': continue
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,641)
	return
def do7Es2fUtFlM8ScLx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	vvufbqFnUclCD5MxOz = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"image" content="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	NWqAr40jTLlMBemn3o79y = vvufbqFnUclCD5MxOz[0] if vvufbqFnUclCD5MxOz else kh850jKbzmBwY
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"AiredEPS"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)</em>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = title.replace('</span><em>',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if BBJYzRKgHkOqx: Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.decode(NVbhZ0DTpOkCA)
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,642,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	lnYtOIQ4Rkh386Bca7,u6X0ermz2hnb4FPM7oSyGIA1V,owMxje0p9Ya3CkhJDX = [],[],[]
	O9wzaDlICnq = url.replace('/watch.php','/play.php')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if 'embedded-video' in uP1m46pAK5a3UgdqvBz9rnL:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"embed_server"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if Sp6qOyDB0nt5Qo4KwbPfcWYe:
				Ga8xfYU6ht7cHjzn = Sp6qOyDB0nt5Qo4KwbPfcWYe[0]
				if Ga8xfYU6ht7cHjzn not in lnYtOIQ4Rkh386Bca7:
					u6X0ermz2hnb4FPM7oSyGIA1V.append('?named=__embed')
					lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('var servers =(.*?);',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = vDVykQSI8dwipbZuJmG31RO7l6h.loads(ZZDUdXR52CMs9K73Ex)
		for JJNIsO8Vcbx0 in items:
			Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)"',JJNIsO8Vcbx0,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if Ga8xfYU6ht7cHjzn:
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
				if Ga8xfYU6ht7cHjzn not in lnYtOIQ4Rkh386Bca7:
					u6X0ermz2hnb4FPM7oSyGIA1V.append('?named=__watch')
					lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	O9wzaDlICnq = url.replace('/watch.php','/download.php')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOFHA-PLAY-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"player"(.*?)"DownloadServer"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</div>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
		for Ga8xfYU6ht7cHjzn,title in Sp6qOyDB0nt5Qo4KwbPfcWYe:
			title = title.replace('<div class="desc">','').replace('</div>','')
			title = title.strip()
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+Ga8xfYU6ht7cHjzn
			if Ga8xfYU6ht7cHjzn not in lnYtOIQ4Rkh386Bca7:
				u6X0ermz2hnb4FPM7oSyGIA1V.append('?named='+title+'__download')
				lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	cbEeOrp1di2TL7GXnguA6f = zip(lnYtOIQ4Rkh386Bca7,u6X0ermz2hnb4FPM7oSyGIA1V)
	for Ga8xfYU6ht7cHjzn,name in cbEeOrp1di2TL7GXnguA6f: owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+name)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search.php?keywords='+search
	bsZhnoqjD3U(url,'search')
	return
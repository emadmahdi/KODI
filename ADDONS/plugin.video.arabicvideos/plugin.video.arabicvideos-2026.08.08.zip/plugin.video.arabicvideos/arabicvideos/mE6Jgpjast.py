# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'FARESKO'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_FSK_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الرئيسية','يلا شوت']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==990: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==991: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==992: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==993: PP3FsDicLyWuTR7GV5Ia = sGaLKXvqkC(url)
	elif mode==999: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FARESKO-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,999,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"primary-links"(.*?)</u',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,991)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"list-categories"(.*?)</u',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.lstrip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,991)
	return
def bsZhnoqjD3U(url,type=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FARESKO-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-content"(.*?)"footer"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"overlay"','"duration"><')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		SHTvIuhX52dxQRsWA = []
		for NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,Ga8xfYU6ht7cHjzn,title in items:
			title = title.strip(' ')
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if 'episodes' not in type and WULSmfNH09tPIv58snzpCkR:
				title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
				title = title.replace('اون لاين',kh850jKbzmBwY)
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,993,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,992,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''["']pagination["'](.*?)["']footer["']''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,991,kh850jKbzmBwY,kh850jKbzmBwY,type)
	else:
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('load-next-button" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة جديدة',Ga8xfYU6ht7cHjzn[0],991,kh850jKbzmBwY,kh850jKbzmBwY,type)
	return
def sGaLKXvqkC(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FARESKO-SERIES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="eplist"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		hNDb2sI34dvRnlXZHMz6YfkuOSV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in hNDb2sI34dvRnlXZHMz6YfkuOSV:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,992)
	else:
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"category".*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if Ga8xfYU6ht7cHjzn:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
			bsZhnoqjD3U(Ga8xfYU6ht7cHjzn,'episodes')
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX,OEVmWsLiSNvybAxc2e9Id8C1jkRXp = [],[]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FARESKO-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if 'hash=' in uP1m46pAK5a3UgdqvBz9rnL:
		rFk4DCWv7EXd = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('hash=(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		rFk4DCWv7EXd = list(set(rFk4DCWv7EXd))
		for LsgQIK6E08od3r5 in rFk4DCWv7EXd:
			qaKTAyYWX8dJ6w1rlphxSPu7MCLj = []
			VQfK9Lr0j75zHwg1xOGY = LsgQIK6E08od3r5.split('__')
			for omfXkuRP6QsITcL9WAbFS25pw in VQfK9Lr0j75zHwg1xOGY:
				try:
					omfXkuRP6QsITcL9WAbFS25pw = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(omfXkuRP6QsITcL9WAbFS25pw+'=')
					if eOQJrvLAZC: omfXkuRP6QsITcL9WAbFS25pw = omfXkuRP6QsITcL9WAbFS25pw.decode(NVbhZ0DTpOkCA)
					qaKTAyYWX8dJ6w1rlphxSPu7MCLj.append(omfXkuRP6QsITcL9WAbFS25pw)
				except: pass
			Sp6qOyDB0nt5Qo4KwbPfcWYe = '>'.join(qaKTAyYWX8dJ6w1rlphxSPu7MCLj)
			Sp6qOyDB0nt5Qo4KwbPfcWYe = Sp6qOyDB0nt5Qo4KwbPfcWYe.splitlines()
			for Ga8xfYU6ht7cHjzn in Sp6qOyDB0nt5Qo4KwbPfcWYe:
				if ' => ' in Ga8xfYU6ht7cHjzn:
					title,Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split(' => ')
					owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+title+'__watch')
	elif 'post_id' in uP1m46pAK5a3UgdqvBz9rnL:
		bYXVGSPi1DC6kIh9BE7j3esN0mfQg = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("post_id = '(.*?)'",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if bYXVGSPi1DC6kIh9BE7j3esN0mfQg:
			bYXVGSPi1DC6kIh9BE7j3esN0mfQg = bYXVGSPi1DC6kIh9BE7j3esN0mfQg[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			guEWp2n0C6kOlZ = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"video-play-button" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if guEWp2n0C6kOlZ: headers.update({'Referer':guEWp2n0C6kOlZ[0]})
			E180i9gBdNyFG4vx2wOpnZ = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/wp-admin/admin-ajax.php?action=video_info&post_id='+bYXVGSPi1DC6kIh9BE7j3esN0mfQg
			OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',E180i9gBdNyFG4vx2wOpnZ,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'FARESKO-PLAY-2nd')
			CkH3dlE8y6fXBQwRrM = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
			FH5oNSjkRw0c4OnP = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"name":"(.*?)","src":"(.*?)"',CkH3dlE8y6fXBQwRrM,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if not FH5oNSjkRw0c4OnP:
				FH5oNSjkRw0c4OnP = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"src":"(.*?)"',CkH3dlE8y6fXBQwRrM,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if FH5oNSjkRw0c4OnP:
					D8LIQm7CWcYfyh2XvVl5 = ['']*len(FH5oNSjkRw0c4OnP)
					FH5oNSjkRw0c4OnP = list(zip(D8LIQm7CWcYfyh2XvVl5,FH5oNSjkRw0c4OnP))
			for name,Ga8xfYU6ht7cHjzn in FH5oNSjkRw0c4OnP:
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				Ga8xfYU6ht7cHjzn = ioZ083zxYk(Ga8xfYU6ht7cHjzn)
				if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
				else: OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
				owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+name+'__watch')
			jQOlvATLDcdquxVXaJib3Yo5 = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+bYXVGSPi1DC6kIh9BE7j3esN0mfQg+'&video_id=null&video_url=null&video_source=custom'
			OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',jQOlvATLDcdquxVXaJib3Yo5,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'FARESKO-PLAY-3rd')
			kKwr9zX358QO47tbu1UC2 = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
			XckOiLbjTKVUW1FyIv3 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if XckOiLbjTKVUW1FyIv3:
				HKZECBpyDf,uufKtMjTNiR02gpm36OWrnl = zip(*XckOiLbjTKVUW1FyIv3)
				XckOiLbjTKVUW1FyIv3 = list(zip(uufKtMjTNiR02gpm36OWrnl,HKZECBpyDf))
			for name,Ga8xfYU6ht7cHjzn in XckOiLbjTKVUW1FyIv3:
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				Ga8xfYU6ht7cHjzn = ioZ083zxYk(Ga8xfYU6ht7cHjzn)
				if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
				else: OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
				owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+name+'__download')
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?s='+search
	bsZhnoqjD3U(url,'search')
	return
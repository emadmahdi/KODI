# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'MOVIZLAND'
headers = { 'User-Agent' : kh850jKbzmBwY }
GalrcVUMy8bzORWX5E0exhYivBwgk = '_MVZ_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
d0hVTC6pXnNEwLqm4zbt3x = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][1]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==180: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==181: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==182: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==183: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==188: PP3FsDicLyWuTR7GV5Ia = qW0zupKTfGon5BMSkxy3LEOvP()
	elif mode==189: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def qW0zupKTfGon5BMSkxy3LEOvP():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,message)
	return
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,189,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'بوكس اوفيس موفيز لاند',WLjaXVNk2dnAJzPpy6OlMv4qoi9,181,kh850jKbzmBwY,kh850jKbzmBwY,'box-office')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'أحدث الافلام',WLjaXVNk2dnAJzPpy6OlMv4qoi9,181,kh850jKbzmBwY,kh850jKbzmBwY,'latest-movies')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'تليفزيون موفيز لاند',WLjaXVNk2dnAJzPpy6OlMv4qoi9,181,kh850jKbzmBwY,kh850jKbzmBwY,'tv')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الاكثر مشاهدة',WLjaXVNk2dnAJzPpy6OlMv4qoi9,181,kh850jKbzmBwY,kh850jKbzmBwY,'top-views')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'أقوى الافلام الحالية',WLjaXVNk2dnAJzPpy6OlMv4qoi9,181,kh850jKbzmBwY,kh850jKbzmBwY,'top-movies')
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-MENU-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<h2><a href="(.*?)".*?">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,181)
	return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url,type=kh850jKbzmBwY):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': ZZDUdXR52CMs9K73Ex = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	elif type=='box-office': ZZDUdXR52CMs9K73Ex = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	elif type=='top-movies': ZZDUdXR52CMs9K73Ex = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('btn-2-overlay(.*?)<style>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	elif type=='top-views': ZZDUdXR52CMs9K73Ex = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	elif type=='tv': ZZDUdXR52CMs9K73Ex = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	else: ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
	if type in ['top-views','top-movies']:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	FfMaBDcVKlON = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for NWqAr40jTLlMBemn3o79y,SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1,OU7qz1PTwdQu8GFfcpbIkNErinoSD in items:
		if type in ['top-views','top-movies']:
			NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,jQOlvATLDcdquxVXaJib3Yo5,title = NWqAr40jTLlMBemn3o79y,SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1,OU7qz1PTwdQu8GFfcpbIkNErinoSD
		else: NWqAr40jTLlMBemn3o79y,title,Ga8xfYU6ht7cHjzn,jQOlvATLDcdquxVXaJib3Yo5 = NWqAr40jTLlMBemn3o79y,SVgRjzYbPBieLyTDrX,JE4RrP2aZqWOLV1,OU7qz1PTwdQu8GFfcpbIkNErinoSD
		Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn)
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('?view=true',kh850jKbzmBwY)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',kh850jKbzmBwY).replace('بجوده ',kh850jKbzmBwY)
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'الحلقة' in title or 'الحلقه' in title:
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|الحلقه) \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if WULSmfNH09tPIv58snzpCkR:
				title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,183,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
		elif any(value in title for value in FfMaBDcVKlON):
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?servers=' + jQOlvATLDcdquxVXaJib3Yo5
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,182,NWqAr40jTLlMBemn3o79y)
		else:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?servers=' + jQOlvATLDcdquxVXaJib3Yo5
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,183,NWqAr40jTLlMBemn3o79y)
	if type==kh850jKbzmBwY:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('\n<li><a href="(.*?)".*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			title = title.replace('الصفحة ',kh850jKbzmBwY)
			if title!=kh850jKbzmBwY:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,181)
	return
def do7Es2fUtFlM8ScLx(url):
	O9wzaDlICnq = url.split('?servers=')[0]
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-EPISODES-1st')
	ZZDUdXR52CMs9K73Ex = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	title,W7BTt4f3CkhKJIY,NWqAr40jTLlMBemn3o79y = ZZDUdXR52CMs9K73Ex[0]
	name = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="episodesNumbers"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn in items:
			Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn)
			title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(الحلقة|الحلقه)-([0-9]+)',Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-2],sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if not title: title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('()-([0-9]+)',Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-2],sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if title: title = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF + title[0][1]
			else: title = kh850jKbzmBwY
			title = name + ' - ' + 'الحلقة' + title
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,182,NWqAr40jTLlMBemn3o79y)
	if not items:
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',kh850jKbzmBwY).replace('بجوده ',kh850jKbzmBwY)
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,182,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	dw41pjPtHs = url.split('?servers=')
	O9wzaDlICnq = dw41pjPtHs[0]
	del dw41pjPtHs[0]
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-PLAY-1st')
	Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('font-size: 25px;" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	if Ga8xfYU6ht7cHjzn not in dw41pjPtHs: dw41pjPtHs.append(Ga8xfYU6ht7cHjzn)
	lnYtOIQ4Rkh386Bca7 = []
	for Ga8xfYU6ht7cHjzn in dw41pjPtHs:
		if '://moshahda.' in Ga8xfYU6ht7cHjzn:
			QUyjSvbDIdhRYsV6MmL3wFXezH = Ga8xfYU6ht7cHjzn
			lnYtOIQ4Rkh386Bca7.append(QUyjSvbDIdhRYsV6MmL3wFXezH+'?named=Main')
	for Ga8xfYU6ht7cHjzn in dw41pjPtHs:
		if '://vb.movizland.' in Ga8xfYU6ht7cHjzn:
			uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,Ga8xfYU6ht7cHjzn,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-PLAY-2nd')
			uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.decode(Vl3xtR0PmB).encode(NVbhZ0DTpOkCA)
			uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if liroJ6qCK9k:
				juk5im1JNf4y2WMaFPUXwVzE3,xHtTaDugOdMC0w9IW5Psi = [],[]
				if len(liroJ6qCK9k)==1:
					title = kh850jKbzmBwY
					ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
				else:
					for ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
						c0jtBCYDEkL5HJfVX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
						if c0jtBCYDEkL5HJfVX: ZZDUdXR52CMs9K73Ex = 'src="/uploads/13721411411.png"  \n  ' + c0jtBCYDEkL5HJfVX[0][1]
						c0jtBCYDEkL5HJfVX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
						if c0jtBCYDEkL5HJfVX: ZZDUdXR52CMs9K73Ex = 'src="/uploads/13721411411.png"  \n  ' + c0jtBCYDEkL5HJfVX[0]
						c0jtBCYDEkL5HJfVX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
						if c0jtBCYDEkL5HJfVX: ZZDUdXR52CMs9K73Ex = c0jtBCYDEkL5HJfVX[0] + '  \n  src="/uploads/13721411411.png"'
						Ol5nqQcjBvFNKXd9JA7kVx3H = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<(.*?)http://up.movizland.(online|com)/uploads/',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
						title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('> *([^<>]+) *<',Ol5nqQcjBvFNKXd9JA7kVx3H[0][0],sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
						title = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF.join(title)
						title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
						title = title.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
						juk5im1JNf4y2WMaFPUXwVzE3.append(title)
					TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('أختر الفيديو المطلوب:', juk5im1JNf4y2WMaFPUXwVzE3)
					if TTn7mZzPRjq5GBESh8aKy == -1 : return
					title = juk5im1JNf4y2WMaFPUXwVzE3[TTn7mZzPRjq5GBESh8aKy]
					ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[TTn7mZzPRjq5GBESh8aKy]
				Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(http://moshahda\..*?/\w+.html)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				KUx6WM4p7wslLoJirz = Ga8xfYU6ht7cHjzn[0]
				lnYtOIQ4Rkh386Bca7.append(KUx6WM4p7wslLoJirz+'?named=Forum')
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('ـ',kh850jKbzmBwY)
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				Wk0maH8CX6zSreUd7PAyKo1Bwi9Mbf = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				for ZSQw3LKergx0vWDfz8h in Wk0maH8CX6zSreUd7PAyKo1Bwi9Mbf:
					type = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(' typetype="(.*?)" ',ZSQw3LKergx0vWDfz8h)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = kh850jKbzmBwY
					items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',ZSQw3LKergx0vWDfz8h,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
					for Bv1yu3jHLc8,Ga8xfYU6ht7cHjzn in items:
						title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(\w+[ \w]*)<',Bv1yu3jHLc8)
						title = title[-1]
						Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + type
						lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	QQJdiByEeNqLYGs = O9wzaDlICnq.replace(WLjaXVNk2dnAJzPpy6OlMv4qoi9,d0hVTC6pXnNEwLqm4zbt3x)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,QQJdiByEeNqLYGs,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-PLAY-3rd')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		hB7dEkguQPf4nvrDm = items[-1]
		lnYtOIQ4Rkh386Bca7.append(hB7dEkguQPf4nvrDm+'?named=Mobile')
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'MOVIZLAND-SEARCH-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<option value="(.*?)">(.*?)</option>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	a2Q4EjInRSVmWvM = [ kh850jKbzmBwY ]
	BXR6lLynDIueAJC = [ 'الكل وبدون فلتر' ]
	for XvPwmy3axVdD6NIKGb4Ak,title in items:
		a2Q4EjInRSVmWvM.append(XvPwmy3axVdD6NIKGb4Ak)
		BXR6lLynDIueAJC.append(title)
	if XvPwmy3axVdD6NIKGb4Ak:
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('اختر الفلتر المناسب:', BXR6lLynDIueAJC)
		if TTn7mZzPRjq5GBESh8aKy == -1 : return
		XvPwmy3axVdD6NIKGb4Ak = a2Q4EjInRSVmWvM[TTn7mZzPRjq5GBESh8aKy]
	else: XvPwmy3axVdD6NIKGb4Ak = kh850jKbzmBwY
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/?s='+search+'&mcat='+XvPwmy3axVdD6NIKGb4Ak
	bsZhnoqjD3U(url)
	return
# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = HfuZG0aphlYnVLOyAk93rj(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
GalrcVUMy8bzORWX5E0exhYivBwgk = MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
hx6weAziyfkPORvdlrmoj = YdDkIjFhgzuboBKca70ERt.path.join(UVJ84eNx6jG1Owy7rI,gNPRXprEAQJ(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
bh0epoS2z8KM = YdDkIjFhgzuboBKca70ERt.path.join(UVJ84eNx6jG1Owy7rI,HHthiRYs8T6IO3qUyX(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
olbz7NBga546OMHp1FDT9nm2dhV = YdDkIjFhgzuboBKca70ERt.path.join(Vx3dLGn9Sc7jkBM,CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
HHZEavV3qlry1SL = tzEjvOaZWU1A(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
ucOlm43PBjGxqo = Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
oopxd4sSH5EI0YGV9Jaq8zOceibt = YoMw2J1Ljp(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
JpsNYMK9IiFH7LeBucPTvk4XZtRxGf = XasF0WO7rDUHnEt8hAl9kLN(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
amvKzfsdEbHnZpVeB2k0jLJ3NGyMgl = XasF0WO7rDUHnEt8hAl9kLN(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
Vwm7Bnpjk60XyNGgtDHxO2 = XasF0WO7rDUHnEt8hAl9kLN(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
KKp9LX3C0WYhz1ROk = N3sFYzhgMTQ
mKYzaZQv38b6P9N2hDdXL5M = qJWGLeXlsvHDr
y3jZYI5VhvRn4K = hLUyzBCXDm90cO8xrkuEZK5RdMgWGn
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn):
	if   eYN1APt8aZflKmByj0ioGzn==wnVICNyfE3XZ0htUaDFAOgLo(u"࠸࠶࠳ࣈ"): PP3FsDicLyWuTR7GV5Ia = AAJfCI3SgY1TKlHEvVOh()
	elif eYN1APt8aZflKmByj0ioGzn==MBS1GrwQoUlsiIRfVDOHdA(u"࠹࠷࠵ࣉ"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(hx6weAziyfkPORvdlrmoj,dbo4vrnTM56I,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==ZeV4vau9CjN(u"࠺࠸࠷࣊"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(bh0epoS2z8KM,dbo4vrnTM56I,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠻࠹࠹࣋"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(olbz7NBga546OMHp1FDT9nm2dhV,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠼࠺࠴࣌"): PP3FsDicLyWuTR7GV5Ia = OEJNR0ts1D(dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠽࠴࠶࣍"): PP3FsDicLyWuTR7GV5Ia = tbyPuehQrKczBwGNVD963TLgilJsqR(dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==tzEjvOaZWU1A(u"࠷࠵࠸࣎"): PP3FsDicLyWuTR7GV5Ia = r0n8tI7hBSmH2biMv6fxo(dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==taD1d3bpqyfM4VNhK0P29GSZ(u"࠸࠷࠳࣏"): PP3FsDicLyWuTR7GV5Ia = EE5aCShrVsktel()
	elif eYN1APt8aZflKmByj0ioGzn==sdRqnego9PclrL4m2J(u"࠹࠸࠵࣐"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(HHZEavV3qlry1SL,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==dQvxmFkyLOteNMWBJ2bDHV(u"࠺࠹࠷࣑"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(ucOlm43PBjGxqo,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠻࠺࠹࣒"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(oopxd4sSH5EI0YGV9Jaq8zOceibt,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==HHthiRYs8T6IO3qUyX(u"࠼࠻࠴࣓"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(JpsNYMK9IiFH7LeBucPTvk4XZtRxGf,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==wb1nC3e8AjRVU4ovsuPa(u"࠽࠵࠶ࣔ"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(amvKzfsdEbHnZpVeB2k0jLJ3NGyMgl,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==J6G8X3gO1MiKh027D(u"࠷࠶࠸ࣕ"): PP3FsDicLyWuTR7GV5Ia = LAqRc0J9jSY(Vwm7Bnpjk60XyNGgtDHxO2,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==Urj6egiVyHA75ZK(u"࠸࠷࠺ࣖ"): PP3FsDicLyWuTR7GV5Ia = j1bdRPLNFAkfIiaX(dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠹࠸࠼ࣗ"): PP3FsDicLyWuTR7GV5Ia = mvRspdr9xQIzCiUGa58FLOK6yHVl();BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==z8wTfYPiRQL(u"࠴࠴࠽࠶ࣘ"): PP3FsDicLyWuTR7GV5Ia = fyKqDX9dv2Mb4JFrmACo5P()
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠵࠵࠾࠱ࣙ"): PP3FsDicLyWuTR7GV5Ia = TQu5N04VzBM9eF1iU(dbo4vrnTM56I);BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==wb1nC3e8AjRVU4ovsuPa(u"࠶࠶࠸࠳ࣚ"): PP3FsDicLyWuTR7GV5Ia = VX2Boj37wpe50CTJLDZ6cSkHuiN();BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==WlU7AtONpyj3(u"࠷࠰࠹࠵ࣛ"): PP3FsDicLyWuTR7GV5Ia = zzZCYcAFy0ODa();BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠱࠱࠺࠷ࣜ"): PP3FsDicLyWuTR7GV5Ia = jAyTprgbIk0SRh();BtAopqyRg4(PP3FsDicLyWuTR7GV5Ia)
	elif eYN1APt8aZflKmByj0ioGzn==aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠲࠲࠻࠹ࣝ"): PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif eYN1APt8aZflKmByj0ioGzn==aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠳࠳࠼࠻ࣞ"): PP3FsDicLyWuTR7GV5Ia = Vpfsi34uMYhIEgDewmTBL()
	else: PP3FsDicLyWuTR7GV5Ia = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	return PP3FsDicLyWuTR7GV5Ia
def Vpfsi34uMYhIEgDewmTBL():
	FFUbpd3xE58zLNGsinlCvgrB2f = MBS1GrwQoUlsiIRfVDOHdA(u"࠴࠴࠷࠺ࣟ")*MBS1GrwQoUlsiIRfVDOHdA(u"࠴࠴࠷࠺ࣟ")
	IbwoFENtqAYvHBQaRfUKJVZ98urL = qMfFUXi9201WIyB4bAvtkgCdl3J7()//FFUbpd3xE58zLNGsinlCvgrB2f
	R4Cae1sGhMKTJuObQf8tEWIqLjkv70 = IbwoFENtqAYvHBQaRfUKJVZ98urL<Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠹࠵࣠")
	size = HHFAVK8SwRUqBLuTfdeJ9nbD+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(IbwoFENtqAYvHBQaRfUKJVZ98urL)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	if R4Cae1sGhMKTJuObQf8tEWIqLjkv70:
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,u8iSx05wLfVyMNp1X3l(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(IbwoFENtqAYvHBQaRfUKJVZ98urL)+gNPRXprEAQJ(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,z8wTfYPiRQL(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return R4Cae1sGhMKTJuObQf8tEWIqLjkv70
def BtAopqyRg4(kJuXd2DV1ot6):
	if kJuXd2DV1ot6: EoGNACuMnrFUzPyi(dbo4vrnTM56I)
	return
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),kh850jKbzmBwY,ZeV4vau9CjN(u"࠶࠶࠸࠷࣡"))
	EE6ysIeB8jKNgCfOkv(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),tzEjvOaZWU1A(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),kh850jKbzmBwY,XasF0WO7rDUHnEt8hAl9kLN(u"࠽࠵࠱࣢"))
	EE6ysIeB8jKNgCfOkv(HfuZG0aphlYnVLOyAk93rj(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),HHthiRYs8T6IO3qUyX(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠷࠵࠲ࣣ"))
	EE6ysIeB8jKNgCfOkv(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),u8iSx05wLfVyMNp1X3l(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),kh850jKbzmBwY,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠲࠲࠻࠴ࣤ"))
	return
def fyKqDX9dv2Mb4JFrmACo5P():
	zNbsVqvXDcf,XaquxBLdi0gt = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(KKp9LX3C0WYhz1ROk)
	x6G9yYP1IQe0UTENd4WwqLvzu,xxKCysiJOE = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(mKYzaZQv38b6P9N2hDdXL5M)
	BrC5SqzJWePjlD2FXRocfU4K7hAgT9,lj9DQcNP3Auif = jURErmLv8M4PZ9Ky6FH(y3jZYI5VhvRn4K)
	NQgfMyivuL3ESP9r6hmAGs,uyXNawGvOV7DFK9lme48id = zNbsVqvXDcf+x6G9yYP1IQe0UTENd4WwqLvzu+BrC5SqzJWePjlD2FXRocfU4K7hAgT9,XaquxBLdi0gt+xxKCysiJOE+lj9DQcNP3Auif
	LR7saxGkNb6VYzyI4 = dQvxmFkyLOteNMWBJ2bDHV(u"ࠩࠣࠬࠬࠚ")+tYl0rEQ93unIM(zNbsVqvXDcf)+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪࠤ࠲ࠦࠧࠛ")+str(XaquxBLdi0gt)+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	lXWDJRvQFImZh = MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࠦࠨࠨࠝ")+tYl0rEQ93unIM(x6G9yYP1IQe0UTENd4WwqLvzu)+wb1nC3e8AjRVU4ovsuPa(u"࠭ࠠ࠮ࠢࠪࠞ")+str(xxKCysiJOE)+Urj6egiVyHA75ZK(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	wXGMtCzZqK87Ru9vFybls = HHthiRYs8T6IO3qUyX(u"ࠨࠢࠫࠫࠠ")+tYl0rEQ93unIM(BrC5SqzJWePjlD2FXRocfU4K7hAgT9)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(lj9DQcNP3Auif)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	ii2qPHKtfmDzS4XjrCyQah67cMI = u8iSx05wLfVyMNp1X3l(u"ࠫࠥ࠮ࠧࠣ")+tYl0rEQ93unIM(NQgfMyivuL3ESP9r6hmAGs)+Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬࠦ࠭ࠡࠩࠤ")+str(uyXNawGvOV7DFK9lme48id)+ZeV4vau9CjN(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	EE6ysIeB8jKNgCfOkv(Urj6egiVyHA75ZK(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),GalrcVUMy8bzORWX5E0exhYivBwgk+FkqI4Gm8wMvUVbgo(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+ii2qPHKtfmDzS4XjrCyQah67cMI,kh850jKbzmBwY,Urj6egiVyHA75ZK(u"࠳࠳࠼࠹ࣥ"))
	EE6ysIeB8jKNgCfOkv(MBS1GrwQoUlsiIRfVDOHdA(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),HHFAVK8SwRUqBLuTfdeJ9nbD+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,wb1nC3e8AjRVU4ovsuPa(u"࠼࠽࠾࠿ࣦ"))
	EE6ysIeB8jKNgCfOkv(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),GalrcVUMy8bzORWX5E0exhYivBwgk+wb1nC3e8AjRVU4ovsuPa(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+LR7saxGkNb6VYzyI4,kh850jKbzmBwY,taD1d3bpqyfM4VNhK0P29GSZ(u"࠵࠵࠾࠱ࣧ"))
	EE6ysIeB8jKNgCfOkv(HHthiRYs8T6IO3qUyX(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),GalrcVUMy8bzORWX5E0exhYivBwgk+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+lXWDJRvQFImZh,kh850jKbzmBwY,HHthiRYs8T6IO3qUyX(u"࠶࠶࠸࠳ࣨ"))
	EE6ysIeB8jKNgCfOkv(z8wTfYPiRQL(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),GalrcVUMy8bzORWX5E0exhYivBwgk+FkqI4Gm8wMvUVbgo(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+wXGMtCzZqK87Ru9vFybls,kh850jKbzmBwY,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠷࠰࠹࠵ࣩ"))
	EE6ysIeB8jKNgCfOkv(Urj6egiVyHA75ZK(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),GalrcVUMy8bzORWX5E0exhYivBwgk+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+ii2qPHKtfmDzS4XjrCyQah67cMI,kh850jKbzmBwY,FkqI4Gm8wMvUVbgo(u"࠱࠱࠺࠷࣪"))
	return
def jAyTprgbIk0SRh():
	kJuXd2DV1ot6 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,sdRqnego9PclrL4m2J(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if II7ErX2ocuU:
		QJS9lPxgfHLbqkNEVKGr3 = zzZCYcAFy0ODa()
		WhxRc6vagoTACt = LAqRc0J9jSY(qJWGLeXlsvHDr,dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		kJuXd2DV1ot6 = QJS9lPxgfHLbqkNEVKGr3 and WhxRc6vagoTACt
		if kJuXd2DV1ot6: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,WlU7AtONpyj3(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return kJuXd2DV1ot6
def VX2Boj37wpe50CTJLDZ6cSkHuiN():
	import KYQy2zFjca
	KYQy2zFjca.DimCxMk2fNH4q19()
	jVhaOJ9utFmLGZpHceKNMlE = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(FkqI4Gm8wMvUVbgo(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),kh850jKbzmBwY,kh850jKbzmBwY,Urj6egiVyHA75ZK(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),tzEjvOaZWU1A(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if II7ErX2ocuU==igM4DhpPzoX95Ysnar6Auj:
		jVhaOJ9utFmLGZpHceKNMlE = LAqRc0J9jSY(qJWGLeXlsvHDr,dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		if jVhaOJ9utFmLGZpHceKNMlE: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,J6G8X3gO1MiKh027D(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return jVhaOJ9utFmLGZpHceKNMlE
def zzZCYcAFy0ODa():
	jVhaOJ9utFmLGZpHceKNMlE = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(YoMw2J1Ljp(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),kh850jKbzmBwY,kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠧิฦส่ࠬ࠻"),HHthiRYs8T6IO3qUyX(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if II7ErX2ocuU==igM4DhpPzoX95Ysnar6Auj:
		try:
			YdDkIjFhgzuboBKca70ERt.remove(hLUyzBCXDm90cO8xrkuEZK5RdMgWGn)
			jVhaOJ9utFmLGZpHceKNMlE = dbo4vrnTM56I
		except: pass
		if jVhaOJ9utFmLGZpHceKNMlE: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,Urj6egiVyHA75ZK(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return jVhaOJ9utFmLGZpHceKNMlE
def fyKqDX9dv2Mb4JFrmACo5P():
	zNbsVqvXDcf,XaquxBLdi0gt = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(KKp9LX3C0WYhz1ROk)
	x6G9yYP1IQe0UTENd4WwqLvzu,xxKCysiJOE = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(mKYzaZQv38b6P9N2hDdXL5M)
	BrC5SqzJWePjlD2FXRocfU4K7hAgT9,lj9DQcNP3Auif = jURErmLv8M4PZ9Ky6FH(y3jZYI5VhvRn4K)
	NQgfMyivuL3ESP9r6hmAGs,uyXNawGvOV7DFK9lme48id = zNbsVqvXDcf+x6G9yYP1IQe0UTENd4WwqLvzu+BrC5SqzJWePjlD2FXRocfU4K7hAgT9,XaquxBLdi0gt+xxKCysiJOE+lj9DQcNP3Auif
	LR7saxGkNb6VYzyI4 = Urj6egiVyHA75ZK(u"ࠫࠥ࠮ࠧ࠿")+tYl0rEQ93unIM(zNbsVqvXDcf)+gNPRXprEAQJ(u"ࠬࠦ࠭ࠡࠩࡀ")+str(XaquxBLdi0gt)+wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	lXWDJRvQFImZh = ZeV4vau9CjN(u"ࠧࠡࠪࠪࡂ")+tYl0rEQ93unIM(x6G9yYP1IQe0UTENd4WwqLvzu)+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨࠢ࠰ࠤࠬࡃ")+str(xxKCysiJOE)+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	wXGMtCzZqK87Ru9vFybls = MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࠤ࠭࠭ࡅ")+tYl0rEQ93unIM(BrC5SqzJWePjlD2FXRocfU4K7hAgT9)+FkqI4Gm8wMvUVbgo(u"ࠫࠥ࠳ࠠࠨࡆ")+str(lj9DQcNP3Auif)+u8iSx05wLfVyMNp1X3l(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	ii2qPHKtfmDzS4XjrCyQah67cMI = tzEjvOaZWU1A(u"࠭ࠠࠩࠩࡈ")+tYl0rEQ93unIM(NQgfMyivuL3ESP9r6hmAGs)+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧࠡ࠯ࠣࠫࡉ")+str(uyXNawGvOV7DFK9lme48id)+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	EE6ysIeB8jKNgCfOkv(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),GalrcVUMy8bzORWX5E0exhYivBwgk+dQvxmFkyLOteNMWBJ2bDHV(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+ii2qPHKtfmDzS4XjrCyQah67cMI,kh850jKbzmBwY,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠲࠲࠻࠸࣫"))
	EE6ysIeB8jKNgCfOkv(NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),HHFAVK8SwRUqBLuTfdeJ9nbD+YoMw2J1Ljp(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠻࠼࠽࠾࣬"))
	EE6ysIeB8jKNgCfOkv(FkqI4Gm8wMvUVbgo(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),GalrcVUMy8bzORWX5E0exhYivBwgk+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+LR7saxGkNb6VYzyI4,kh850jKbzmBwY,BBOY8rvinVbFh(u"࠴࠴࠽࠷࣭"))
	EE6ysIeB8jKNgCfOkv(u8iSx05wLfVyMNp1X3l(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),GalrcVUMy8bzORWX5E0exhYivBwgk+J6G8X3gO1MiKh027D(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+lXWDJRvQFImZh,kh850jKbzmBwY,CMUXq6mPQV5rLsSBdWZJvA(u"࠵࠵࠾࠲࣮"))
	EE6ysIeB8jKNgCfOkv(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),GalrcVUMy8bzORWX5E0exhYivBwgk+NZiEOAWrSX1u2gU05DR6TB8tm(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+wXGMtCzZqK87Ru9vFybls,kh850jKbzmBwY,u8iSx05wLfVyMNp1X3l(u"࠶࠶࠸࠴࣯"))
	EE6ysIeB8jKNgCfOkv(tzEjvOaZWU1A(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),GalrcVUMy8bzORWX5E0exhYivBwgk+XasF0WO7rDUHnEt8hAl9kLN(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+ii2qPHKtfmDzS4XjrCyQah67cMI,kh850jKbzmBwY,HfuZG0aphlYnVLOyAk93rj(u"࠷࠰࠹࠶ࣰ"))
	return
def AAJfCI3SgY1TKlHEvVOh():
	zNbsVqvXDcf,XaquxBLdi0gt = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(hx6weAziyfkPORvdlrmoj)
	x6G9yYP1IQe0UTENd4WwqLvzu,xxKCysiJOE = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(bh0epoS2z8KM)
	BrC5SqzJWePjlD2FXRocfU4K7hAgT9,lj9DQcNP3Auif = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(olbz7NBga546OMHp1FDT9nm2dhV)
	NQgfMyivuL3ESP9r6hmAGs,uyXNawGvOV7DFK9lme48id = jURErmLv8M4PZ9Ky6FH(ddtjWBhYgr56)
	NQgfMyivuL3ESP9r6hmAGs -= HfuZG0aphlYnVLOyAk93rj(u"࠳࠷࠺࠹࠸ࣱ")
	uyXNawGvOV7DFK9lme48id -= igM4DhpPzoX95Ysnar6Auj
	ddXFhKwSID7ZUc3 = str(YdDkIjFhgzuboBKca70ERt.listdir(CgazVoB1dTFkxXqbSn))
	eetdmz7jEGPh = ddXFhKwSID7ZUc3.count(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+ddXFhKwSID7ZUc3.count(ZeV4vau9CjN(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	LR7saxGkNb6VYzyI4 = z8wTfYPiRQL(u"࡙ࠩࠣࠬࠬ")+tYl0rEQ93unIM(zNbsVqvXDcf)+HfuZG0aphlYnVLOyAk93rj(u"ࠪࠤ࠲࡚ࠦࠧ")+str(XaquxBLdi0gt)+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	lXWDJRvQFImZh = dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࠦࠨࠨ࡜")+tYl0rEQ93unIM(x6G9yYP1IQe0UTENd4WwqLvzu)+CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࠠ࠮ࠢࠪ࡝")+str(xxKCysiJOE)+u8iSx05wLfVyMNp1X3l(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	wXGMtCzZqK87Ru9vFybls = oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨࠢࠫࠫ࡟")+tYl0rEQ93unIM(BrC5SqzJWePjlD2FXRocfU4K7hAgT9)+FkqI4Gm8wMvUVbgo(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(lj9DQcNP3Auif)+WlU7AtONpyj3(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	ii2qPHKtfmDzS4XjrCyQah67cMI = ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࠥ࠮ࠧࡢ")+tYl0rEQ93unIM(NQgfMyivuL3ESP9r6hmAGs)+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬ࠯ࠧࡣ")
	YiymI45GqkK2e = HHthiRYs8T6IO3qUyX(u"࠭ࠠࠩࠩࡤ")+str(eetdmz7jEGPh)+sdRqnego9PclrL4m2J(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	p7URwvtrP0BNLMkZy = zNbsVqvXDcf+x6G9yYP1IQe0UTENd4WwqLvzu+BrC5SqzJWePjlD2FXRocfU4K7hAgT9+NQgfMyivuL3ESP9r6hmAGs
	ENrzhWRykvKitAY = XaquxBLdi0gt+xxKCysiJOE+lj9DQcNP3Auif+uyXNawGvOV7DFK9lme48id+eetdmz7jEGPh
	fRJYhnSKHsZ7MqFwmiVz = u8iSx05wLfVyMNp1X3l(u"ࠨࠢࠫࠫࡦ")+tYl0rEQ93unIM(p7URwvtrP0BNLMkZy)+HHthiRYs8T6IO3qUyX(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(ENrzhWRykvKitAY)+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	EE6ysIeB8jKNgCfOkv(MBS1GrwQoUlsiIRfVDOHdA(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),GalrcVUMy8bzORWX5E0exhYivBwgk+FkqI4Gm8wMvUVbgo(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,CMUXq6mPQV5rLsSBdWZJvA(u"࠸࠶࠸ࣲ"))
	EE6ysIeB8jKNgCfOkv(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),HHFAVK8SwRUqBLuTfdeJ9nbD+XasF0WO7rDUHnEt8hAl9kLN(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠻࠼࠽࠾ࣳ"))
	EE6ysIeB8jKNgCfOkv(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),GalrcVUMy8bzORWX5E0exhYivBwgk+WlU7AtONpyj3(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+LR7saxGkNb6VYzyI4,kh850jKbzmBwY,wnVICNyfE3XZ0htUaDFAOgLo(u"࠺࠸࠶ࣴ"))
	EE6ysIeB8jKNgCfOkv(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),GalrcVUMy8bzORWX5E0exhYivBwgk+NZiEOAWrSX1u2gU05DR6TB8tm(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+lXWDJRvQFImZh,kh850jKbzmBwY,qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠻࠹࠸ࣵ"))
	EE6ysIeB8jKNgCfOkv(z8wTfYPiRQL(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),GalrcVUMy8bzORWX5E0exhYivBwgk+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+wXGMtCzZqK87Ru9vFybls,kh850jKbzmBwY,BBOY8rvinVbFh(u"࠼࠺࠳ࣶ"))
	EE6ysIeB8jKNgCfOkv(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),GalrcVUMy8bzORWX5E0exhYivBwgk+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+ii2qPHKtfmDzS4XjrCyQah67cMI,kh850jKbzmBwY,BBOY8rvinVbFh(u"࠽࠴࠵ࣷ"))
	EE6ysIeB8jKNgCfOkv(dQvxmFkyLOteNMWBJ2bDHV(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),GalrcVUMy8bzORWX5E0exhYivBwgk+sdRqnego9PclrL4m2J(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+YiymI45GqkK2e,kh850jKbzmBwY,CMUXq6mPQV5rLsSBdWZJvA(u"࠷࠵࠸ࣸ"))
	return
def EE5aCShrVsktel():
	x8a79DJzKwoN = dbo4vrnTM56I if i2xvIPUGcdqsV5FnDfwBklhjCNXo7M in Vx3dLGn9Sc7jkBM else wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if not x8a79DJzKwoN:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHthiRYs8T6IO3qUyX(u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮ࠡ็ฮ่ࠥษฬ่ิฬࠤศฮไ๊ࠡฦ๊ิื่๋ัࠣ์้๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์่ࠠาสࠤฬ๊ๆ้฻ࠪࡷ"))
		return
	kJ5Z6fzjH7 = l7tuXCf0oKV9FPOy6Hb.getSetting(gNPRXprEAQJ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩࡸ"))
	if not kJ5Z6fzjH7: mvRspdr9xQIzCiUGa58FLOK6yHVl()
	zNbsVqvXDcf,XaquxBLdi0gt = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(HHZEavV3qlry1SL)
	x6G9yYP1IQe0UTENd4WwqLvzu,xxKCysiJOE = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(ucOlm43PBjGxqo)
	BrC5SqzJWePjlD2FXRocfU4K7hAgT9,lj9DQcNP3Auif = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(oopxd4sSH5EI0YGV9Jaq8zOceibt)
	NQgfMyivuL3ESP9r6hmAGs,uyXNawGvOV7DFK9lme48id = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(JpsNYMK9IiFH7LeBucPTvk4XZtRxGf)
	b3KoDgqwGnCOY7xP,eetdmz7jEGPh = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(amvKzfsdEbHnZpVeB2k0jLJ3NGyMgl)
	CC8XTwpKsA7GuImjEoLyZJ20avbf5,SkMwhNXIj3iY1r8 = TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(Vwm7Bnpjk60XyNGgtDHxO2)
	LR7saxGkNb6VYzyI4 = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ࠠࠩࠩࡹ")+tYl0rEQ93unIM(zNbsVqvXDcf)+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧࠡ࠯ࠣࠫࡺ")+str(XaquxBLdi0gt)+HfuZG0aphlYnVLOyAk93rj(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡻ")
	lXWDJRvQFImZh = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࠣࠬࠬࡼ")+tYl0rEQ93unIM(x6G9yYP1IQe0UTENd4WwqLvzu)+J6G8X3gO1MiKh027D(u"ࠪࠤ࠲ࠦࠧࡽ")+str(xxKCysiJOE)+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࡾ")
	wXGMtCzZqK87Ru9vFybls = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࠦࠨࠨࡿ")+tYl0rEQ93unIM(BrC5SqzJWePjlD2FXRocfU4K7hAgT9)+tzEjvOaZWU1A(u"࠭ࠠ࠮ࠢࠪࢀ")+str(lj9DQcNP3Auif)+J6G8X3gO1MiKh027D(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࢁ")
	ii2qPHKtfmDzS4XjrCyQah67cMI = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࠢࠫࠫࢂ")+tYl0rEQ93unIM(NQgfMyivuL3ESP9r6hmAGs)+YoMw2J1Ljp(u"ࠩࠣ࠱ࠥ࠭ࢃ")+str(uyXNawGvOV7DFK9lme48id)+BBOY8rvinVbFh(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢄ")
	YiymI45GqkK2e = NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࠥ࠮ࠧࢅ")+tYl0rEQ93unIM(b3KoDgqwGnCOY7xP)+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬࠦ࠭ࠡࠩࢆ")+str(eetdmz7jEGPh)+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢇ")
	CIpiAyx7O5DsXSKoLMY3Z1BHvjdcF = dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࠡࠪࠪ࢈")+tYl0rEQ93unIM(CC8XTwpKsA7GuImjEoLyZJ20avbf5)+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠨࠢ࠰ࠤࠬࢉ")+str(SkMwhNXIj3iY1r8)+XasF0WO7rDUHnEt8hAl9kLN(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࢊ")
	p7URwvtrP0BNLMkZy = zNbsVqvXDcf+x6G9yYP1IQe0UTENd4WwqLvzu+BrC5SqzJWePjlD2FXRocfU4K7hAgT9+NQgfMyivuL3ESP9r6hmAGs+b3KoDgqwGnCOY7xP+CC8XTwpKsA7GuImjEoLyZJ20avbf5
	ENrzhWRykvKitAY = XaquxBLdi0gt+xxKCysiJOE+lj9DQcNP3Auif+uyXNawGvOV7DFK9lme48id+eetdmz7jEGPh+SkMwhNXIj3iY1r8
	fRJYhnSKHsZ7MqFwmiVz = ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࠤ࠭࠭ࢋ")+tYl0rEQ93unIM(p7URwvtrP0BNLMkZy)+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫࠥ࠳ࠠࠨࢌ")+str(ENrzhWRykvKitAY)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࢍ")
	EE6ysIeB8jKNgCfOkv(gNPRXprEAQJ(u"࠭࡬ࡪࡰ࡮ࠫࢎ"),GalrcVUMy8bzORWX5E0exhYivBwgk+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪ࢏"),kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠸࠷࠻ࣹ"))
	EE6ysIeB8jKNgCfOkv(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨ࡮࡬ࡲࡰ࠭࢐"),GalrcVUMy8bzORWX5E0exhYivBwgk+z8wTfYPiRQL(u"่ࠩืาࠦวๅฮ่๎฾࠭࢑")+fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠹࠸࠻ࣺ"))
	EE6ysIeB8jKNgCfOkv(ZeV4vau9CjN(u"ࠪࡰ࡮ࡴ࡫ࠨ࢒"),HHFAVK8SwRUqBLuTfdeJ9nbD+FkqI4Gm8wMvUVbgo(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ࢓")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠼࠽࠾࠿ࣻ"))
	EE6ysIeB8jKNgCfOkv(J6G8X3gO1MiKh027D(u"ࠬࡲࡩ࡯࡭ࠪ࢔"),GalrcVUMy8bzORWX5E0exhYivBwgk+dQvxmFkyLOteNMWBJ2bDHV(u"࠭ๅิฯ้้ࠣ็วหࠢࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭࢕")+LR7saxGkNb6VYzyI4,kh850jKbzmBwY,XasF0WO7rDUHnEt8hAl9kLN(u"࠻࠺࠷ࣼ"))
	EE6ysIeB8jKNgCfOkv(u8iSx05wLfVyMNp1X3l(u"ࠧ࡭࡫ࡱ࡯ࠬ࢖"),GalrcVUMy8bzORWX5E0exhYivBwgk+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬࢗ")+lXWDJRvQFImZh,kh850jKbzmBwY,Urj6egiVyHA75ZK(u"࠼࠻࠲ࣽ"))
	EE6ysIeB8jKNgCfOkv(NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩ࡯࡭ࡳࡱࠧ࢘"),GalrcVUMy8bzORWX5E0exhYivBwgk+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵ࢙ࠪ")+wXGMtCzZqK87Ru9vFybls,kh850jKbzmBwY,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠽࠵࠴ࣾ"))
	EE6ysIeB8jKNgCfOkv(MBS1GrwQoUlsiIRfVDOHdA(u"ࠫࡱ࡯࡮࡬࢚ࠩ"),GalrcVUMy8bzORWX5E0exhYivBwgk+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࢛")+ii2qPHKtfmDzS4XjrCyQah67cMI,kh850jKbzmBwY,ZeV4vau9CjN(u"࠷࠶࠶ࣿ"))
	EE6ysIeB8jKNgCfOkv(NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭࡬ࡪࡰ࡮ࠫ࢜"),GalrcVUMy8bzORWX5E0exhYivBwgk+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧ࢝")+YiymI45GqkK2e,kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠸࠷࠸ऀ"))
	EE6ysIeB8jKNgCfOkv(WlU7AtONpyj3(u"ࠨ࡮࡬ࡲࡰ࠭࢞"),GalrcVUMy8bzORWX5E0exhYivBwgk+tzEjvOaZWU1A(u"่ࠩืาࠦๅๅใสฮࠥࡧ࡮ࡳࠩ࢟")+CIpiAyx7O5DsXSKoLMY3Z1BHvjdcF,kh850jKbzmBwY,ssYkHaML9z37bJ0StuEBXIqgiV(u"࠹࠸࠺ँ"))
	return
def TQu5N04VzBM9eF1iU(showDialogs):
	if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,wb1nC3e8AjRVU4ovsuPa(u"้ࠪั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠥ࠴࠮้ࠡำหࠥอไๆฮ็ำࠥ็๊่ࠢห฽฻ࠦโ้ษษ้ࠥอไษำ้ห๊าࠠๆะี๊ฮࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲࠳ูࠦ็ัุ้ࠣำࠠศๆ่ะ้ีࠠิ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสั่็ࠦๅอๆาࠤัี๊ะ๋ࠢ๎อีรࠡ็ิอࠥษฮา๋ࠣฬ๊๊ฦ่ࠢหห้฻่าࠢ฼๊ิࠦแหฯࠣห้่่ศศ่ࠫࢠ"))
	MMNQq4CJio18VDfGeX5an93ur,cV9y7DuUJHRFmekz2pElgjY0Zao = [],nxUveizbLEAT2FBNy3
	for hguvb8PDEAkiLJsO9ZMwzqUVCK,DZensRkI7ofbWd2xPSB46uvrJyF,mdLq2RsyMjw7Ye6o in YdDkIjFhgzuboBKca70ERt.walk(N3sFYzhgMTQ,topdown=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1):
		F0hjYVvHBPXWD3I7RS6O = len(mdLq2RsyMjw7Ye6o)
		if F0hjYVvHBPXWD3I7RS6O>aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠸࠴࠵ं"): MMNQq4CJio18VDfGeX5an93ur.append(DZensRkI7ofbWd2xPSB46uvrJyF)
		cV9y7DuUJHRFmekz2pElgjY0Zao += F0hjYVvHBPXWD3I7RS6O
	pmwru3FzA76skPiQXx = cV9y7DuUJHRFmekz2pElgjY0Zao>J6G8X3gO1MiKh027D(u"࠹࠵࠶࠰ः")
	if showDialogs:
		count = HHFAVK8SwRUqBLuTfdeJ9nbD+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"้ࠫี๊ไࠢࠣࠫࢡ")+str(cV9y7DuUJHRFmekz2pElgjY0Zao)+z8wTfYPiRQL(u"ࠬࠦࠠึ๊ิอࠬࢢ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
		if not MMNQq4CJio18VDfGeX5an93ur and not pmwru3FzA76skPiQXx: II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠭ไศࠢํ์ัีฺ่ࠠา็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥะอหษฯࠤศ์ࠠห็ึัࠥ฻่าࠢส่่ะวษหࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฺ๎ัࠡษ็็ฯอศสࠢส่ว์ࠠภࠣࠣࡠࡳࡢ࡮ࠨࢣ")+count)
		else: II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧๅัํ็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์์ึวࠡไาࠤ๏ูศษุ่ࠢฬ้ไࠡใํࠤฯฺฺ๋ๆࠣห้า็ศิࠣ์ฯฺฺ๋ๆࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤศ์สࠡสะหัฯࠠฦๆ์ࠤู๊อ้ࠡำ๋ࠥอไึ๊ิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
	else: II7ErX2ocuU = igM4DhpPzoX95Ysnar6Auj
	if II7ErX2ocuU==igM4DhpPzoX95Ysnar6Auj:
		if pmwru3FzA76skPiQXx: LAqRc0J9jSY(hguvb8PDEAkiLJsO9ZMwzqUVCK,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		elif MMNQq4CJio18VDfGeX5an93ur:
			for DZensRkI7ofbWd2xPSB46uvrJyF in MMNQq4CJio18VDfGeX5an93ur: LAqRc0J9jSY(DZensRkI7ofbWd2xPSB46uvrJyF,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def mvRspdr9xQIzCiUGa58FLOK6yHVl():
	kJuXd2DV1ot6 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Urj6egiVyHA75ZK(u"ࠨๆๆ๎ࠥ๐ูๆๆࠣห้ะๆู์ไࠤ฾์ฯไࠢ࠱࠲ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬาอฬสࠢศ่๎ࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦไๅ็็ๅฬะ้ࠠษ็้ั๊ฯศฬࠣห้ะ๊ࠡี๋ๅࠥ๐ๅิฯ๊หࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤส฿ืศร๋ࠣีํࠠศๆิาฺฯࠠศๆล๊ࠥลࠡࠨࢥ"))
	if II7ErX2ocuU==-ssYkHaML9z37bJ0StuEBXIqgiV(u"࠶ऄ"): return
	if II7ErX2ocuU:
		import subprocess as zHNCyQDk5EaUfWOuRcAYv28sq
		try:
			zHNCyQDk5EaUfWOuRcAYv28sq.Popen(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡶࡹࠬࢦ"))
			kJuXd2DV1ot6 = dbo4vrnTM56I
		except: pass
		if kJuXd2DV1ot6:
			CNYoqsgdly = HHZEavV3qlry1SL+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+ucOlm43PBjGxqo+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+oopxd4sSH5EI0YGV9Jaq8zOceibt+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+JpsNYMK9IiFH7LeBucPTvk4XZtRxGf+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+amvKzfsdEbHnZpVeB2k0jLJ3NGyMgl+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+Vwm7Bnpjk60XyNGgtDHxO2
			BV2GHYfC7UiOkjSEn69bl8 = zHNCyQDk5EaUfWOuRcAYv28sq.Popen(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡷࡺࠦ࠭ࡤࠢࠥࡧ࡭ࡳ࡯ࡥࠢ࠰ࡖࠥ࠶࠷࠸࠹ࠣࠫࢧ")+CNYoqsgdly+ZeV4vau9CjN(u"ࠫࠧ࠭ࢨ"),shell=dbo4vrnTM56I,stdin=zHNCyQDk5EaUfWOuRcAYv28sq.PIPE,stdout=zHNCyQDk5EaUfWOuRcAYv28sq.PIPE,stderr=zHNCyQDk5EaUfWOuRcAYv28sq.PIPE)
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,wb1nC3e8AjRVU4ovsuPa(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨࢩ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ssYkHaML9z37bJ0StuEBXIqgiV(u"ู࠭ๆๆํอࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอࠥะอหษฯࠤอืๆศ็ฯࠤࠥࡸ࡯ࡰࡶࠣࠤศ๎ࠠࠡࡵࡸࡴࡪࡸࡵࡴࡧࡵࠤࠥษ่ࠡࠢࡶࡹ่ࠥࠦอ้สึ่ࠦไศࠢํ์ัีࠠโ์๊ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦร้ࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ั࠭ࢪ"))
	return kJuXd2DV1ot6
def tYl0rEQ93unIM(p7URwvtrP0BNLMkZy):
	for C6OlKRZbXfukEA2 in [CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࡃࠩࢫ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨࡍࡅࠫࢬ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩࡐࡆࠬࢭ"),tzEjvOaZWU1A(u"ࠪࡋࡇ࠭ࢮ"),dQvxmFkyLOteNMWBJ2bDHV(u"࡙ࠫࡈࠧࢯ")]:
		if p7URwvtrP0BNLMkZy<A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠷࠰࠳࠶अ"): break
		else: p7URwvtrP0BNLMkZy /= CMUXq6mPQV5rLsSBdWZJvA(u"࠱࠱࠴࠷࠲࠵आ")
	fRJYhnSKHsZ7MqFwmiVz = G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧࠫ࠳࠯࠳ࡩࠤࠪࡹࠢࢰ")%(p7URwvtrP0BNLMkZy,C6OlKRZbXfukEA2)
	return fRJYhnSKHsZ7MqFwmiVz
def TwZJqU8HdSVr4WA3cCfPv6EY1pKF9j(ll4ZM9KuIv7=G6GUCto502jZTLubYNnqMx8ywBah(u"࠭࠮ࠨࢱ")):
	global M4manTB1GWg,ffatFTgkWS8r
	M4manTB1GWg,ffatFTgkWS8r = nxUveizbLEAT2FBNy3,nxUveizbLEAT2FBNy3
	def HPdyxGFE7QfTNIsJ319OCBMhU(ll4ZM9KuIv7):
		global M4manTB1GWg,ffatFTgkWS8r
		if YdDkIjFhgzuboBKca70ERt.path.exists(ll4ZM9KuIv7):
			if nxUveizbLEAT2FBNy3 and WlU7AtONpyj3(u"ࠧࡴࡥࡤࡲࡩ࡯ࡲࠨࢲ") in dir(YdDkIjFhgzuboBKca70ERt):
				for zFIpk5JQtqDViLrg in YdDkIjFhgzuboBKca70ERt.scandir(ll4ZM9KuIv7):
					if zFIpk5JQtqDViLrg.is_dir(follow_symlinks=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1):
						HPdyxGFE7QfTNIsJ319OCBMhU(zFIpk5JQtqDViLrg.path)
					elif zFIpk5JQtqDViLrg.is_file(follow_symlinks=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1):
						M4manTB1GWg += zFIpk5JQtqDViLrg.stat().st_size
						ffatFTgkWS8r += igM4DhpPzoX95Ysnar6Auj
			else:
				for zFIpk5JQtqDViLrg in YdDkIjFhgzuboBKca70ERt.listdir(ll4ZM9KuIv7):
					llSACGdVZ10WriKLznIk3THcjh5UB = YdDkIjFhgzuboBKca70ERt.path.abspath(YdDkIjFhgzuboBKca70ERt.path.join(ll4ZM9KuIv7,zFIpk5JQtqDViLrg))
					if YdDkIjFhgzuboBKca70ERt.path.isdir(llSACGdVZ10WriKLznIk3THcjh5UB):
						HPdyxGFE7QfTNIsJ319OCBMhU(llSACGdVZ10WriKLznIk3THcjh5UB)
					elif YdDkIjFhgzuboBKca70ERt.path.isfile(llSACGdVZ10WriKLznIk3THcjh5UB):
						p7URwvtrP0BNLMkZy,ENrzhWRykvKitAY = jURErmLv8M4PZ9Ky6FH(llSACGdVZ10WriKLznIk3THcjh5UB)
						M4manTB1GWg += p7URwvtrP0BNLMkZy
						ffatFTgkWS8r += ENrzhWRykvKitAY
		return
	try: HPdyxGFE7QfTNIsJ319OCBMhU(ll4ZM9KuIv7)
	except: pass
	return M4manTB1GWg,ffatFTgkWS8r
def tbyPuehQrKczBwGNVD963TLgilJsqR(showDialogs):
	if showDialogs:
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHFAVK8SwRUqBLuTfdeJ9nbD+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ้็ࠤฯื๊ะ่ࠢืา࠭ࢳ")+URBvawyLXfQiS2NI34HDk+z8wTfYPiRQL(u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠡ࠰࠱ࠤํ๋ไโษอࠤฬ๊ใาษืࠫࢴ")+URBvawyLXfQiS2NI34HDk+ZeV4vau9CjN(u"ࠪรࠦࠧࠧࢵ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		if II7ErX2ocuU!=igM4DhpPzoX95Ysnar6Auj: return
	naRfBT3xMzWqDKJVYo2v = LAqRc0J9jSY(hx6weAziyfkPORvdlrmoj,dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	gg30t5XPqdIcWKD1z6Yia = LAqRc0J9jSY(bh0epoS2z8KM,dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	gDKFQEUVBkY = LAqRc0J9jSY(olbz7NBga546OMHp1FDT9nm2dhV,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	vdyEUG2ROcilSzYr1xFjWJ8nPMHDaB = OEJNR0ts1D(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	ZrG6QMwFYJk7qU9Kyh05 = r0n8tI7hBSmH2biMv6fxo(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	succeeded = all([naRfBT3xMzWqDKJVYo2v,gg30t5XPqdIcWKD1z6Yia,gDKFQEUVBkY,vdyEUG2ROcilSzYr1xFjWJ8nPMHDaB,ZrG6QMwFYJk7qU9Kyh05])
	if showDialogs:
		if succeeded: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࢶ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡษ็ุ้ำࠧࢷ"))
	return succeeded
def j1bdRPLNFAkfIiaX(showDialogs):
	if showDialogs:
		CNYoqsgdly = HHZEavV3qlry1SL+URBvawyLXfQiS2NI34HDk+ucOlm43PBjGxqo+URBvawyLXfQiS2NI34HDk+oopxd4sSH5EI0YGV9Jaq8zOceibt+URBvawyLXfQiS2NI34HDk+JpsNYMK9IiFH7LeBucPTvk4XZtRxGf+URBvawyLXfQiS2NI34HDk+amvKzfsdEbHnZpVeB2k0jLJ3NGyMgl+URBvawyLXfQiS2NI34HDk+Vwm7Bnpjk60XyNGgtDHxO2
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHFAVK8SwRUqBLuTfdeJ9nbD+WlU7AtONpyj3(u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦวๅฬํࠤๆ๐่ࠠา๊ࠤฬ๊ๅอๆาหฯࡢ࡮࡝ࡰࠪࢸ")+CNYoqsgdly+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		if II7ErX2ocuU!=igM4DhpPzoX95Ysnar6Auj: return
	naRfBT3xMzWqDKJVYo2v = LAqRc0J9jSY(HHZEavV3qlry1SL,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	gg30t5XPqdIcWKD1z6Yia = LAqRc0J9jSY(ucOlm43PBjGxqo,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	gDKFQEUVBkY = LAqRc0J9jSY(oopxd4sSH5EI0YGV9Jaq8zOceibt,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	vdyEUG2ROcilSzYr1xFjWJ8nPMHDaB = LAqRc0J9jSY(JpsNYMK9IiFH7LeBucPTvk4XZtRxGf,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	ZrG6QMwFYJk7qU9Kyh05 = LAqRc0J9jSY(amvKzfsdEbHnZpVeB2k0jLJ3NGyMgl,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	qT2jNUAJLMtS = LAqRc0J9jSY(Vwm7Bnpjk60XyNGgtDHxO2,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	succeeded = all([naRfBT3xMzWqDKJVYo2v,gg30t5XPqdIcWKD1z6Yia,gDKFQEUVBkY,vdyEUG2ROcilSzYr1xFjWJ8nPMHDaB,ZrG6QMwFYJk7qU9Kyh05,qT2jNUAJLMtS])
	if showDialogs:
		if succeeded: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,XasF0WO7rDUHnEt8hAl9kLN(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࢹ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,XasF0WO7rDUHnEt8hAl9kLN(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࢺ"))
	return succeeded
def OEJNR0ts1D(showDialogs):
	if showDialogs:
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHFAVK8SwRUqBLuTfdeJ9nbD+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠๆฯอ์๏อสࠡ็็ๅࠥ฻่าࠢส่ั๊ฯࠡมࠤࠥࠬࢻ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		if II7ErX2ocuU!=SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠲इ"): return u8iSx05wLfVyMNp1X3l(u"ࡈࡤࡰࡸ࡫ई")
	try:
		succeeded = tzEjvOaZWU1A(u"ࡗࡶࡺ࡫उ")
		CwjE64qdfunV90pZJlNc2OyDQgHoi = JFCUilw8a9NdZSGtm.connect(ddtjWBhYgr56)
		CwjE64qdfunV90pZJlNc2OyDQgHoi.text_factory = str
		YZI1eGP3xaRoBul = CwjE64qdfunV90pZJlNc2OyDQgHoi.cursor()
		YZI1eGP3xaRoBul.execute(tzEjvOaZWU1A(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡲࡤࡸ࡭ࡁࠧࢼ"))
		YZI1eGP3xaRoBul.execute(gNPRXprEAQJ(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡶ࡭ࡿ࡫ࡳ࠼ࠩࢽ"))
		YZI1eGP3xaRoBul.execute(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡸࡪࡾࡴࡶࡴࡨ࠿ࠬࢾ"))
		CwjE64qdfunV90pZJlNc2OyDQgHoi.commit()
		YZI1eGP3xaRoBul.execute(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧࢿ"))
		CwjE64qdfunV90pZJlNc2OyDQgHoi.close()
	except: succeeded = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࡊࡦࡲࡳࡦऊ")
	if showDialogs:
		if succeeded: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,u8iSx05wLfVyMNp1X3l(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣀ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,sdRqnego9PclrL4m2J(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣁ"))
	return succeeded
def r0n8tI7hBSmH2biMv6fxo(showDialogs):
	if showDialogs:
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"่่ࠩๆอสࠡษ็็ึอิ้ࠡํࠤ๊๊แศฬࠣ๎ฺ์ู่ษࠣ็ํี๊ࠡ฻้ำ๊อ๋ࠠ฼็ๆࠥ์แิ้ࠣฬฺ๎ัส่ࠢๅฬารสࠢ࠱࠲ࠥํะ่ࠢส่๊๊แศฬࠣ๎าะวอ้สࠤ๊ฮัๆฮํࠤ่๎ฯ๋ࠢะฮ๎ฺ๊ࠦำไ์๋ࠦๅ็้สࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯࠧࣂ")+URBvawyLXfQiS2NI34HDk+URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"๋้ࠪࠦสา์าࠤู๊อࠡ็็ๅฬะࠠศๆๆีฬฺࠠศๆ่ศ็ะษࠡมࠤࠥࠬࣃ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		if II7ErX2ocuU!=igM4DhpPzoX95Ysnar6Auj: return x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࡋࡧ࡬ࡴࡧऋ")
	succeeded = ZeV4vau9CjN(u"࡚ࡲࡶࡧऌ")
	for file in YdDkIjFhgzuboBKca70ERt.listdir(CgazVoB1dTFkxXqbSn):
		if G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡰࡵࡤࡪࡡࡶࡸࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ࣄ") not in file and u8iSx05wLfVyMNp1X3l(u"ࠬࡱ࡯ࡥ࡫ࡢࡧࡷࡧࡳࡩ࡮ࡲ࡫ࠬࣅ") not in file: continue
		Xjrvpb09sE = YdDkIjFhgzuboBKca70ERt.path.join(CgazVoB1dTFkxXqbSn,file)
		try: YdDkIjFhgzuboBKca70ERt.remove(Xjrvpb09sE)
		except Exception as GVK7LkZ6Cr8MfpSE2:
			succeeded = sdRqnego9PclrL4m2J(u"ࡆࡢ࡮ࡶࡩऍ")
			if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,str(GVK7LkZ6Cr8MfpSE2))
	if showDialogs:
		if succeeded: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,YoMw2J1Ljp(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࣆ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,wb1nC3e8AjRVU4ovsuPa(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩࣇ"))
	return succeeded
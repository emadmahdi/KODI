# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'BOKRA'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_BKR_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
headers = {'User-Agent':kh850jKbzmBwY}
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['افلام للكبار','بكرا TV']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==370: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==371: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==372: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==374: PP3FsDicLyWuTR7GV5Ia = E0ENQdTlPHzxX3GUaBWJS9DKe(url)
	elif mode==375: PP3FsDicLyWuTR7GV5Ia = llAve4QkUWp0hnPb17No(url)
	elif mode==376: PP3FsDicLyWuTR7GV5Ia = DmZ63igH9dsxXRzAb0MT(0,url)
	elif mode==377: PP3FsDicLyWuTR7GV5Ia = DmZ63igH9dsxXRzAb0MT(1,url)
	elif mode==379: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-MENU-1st')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,379,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('right-side(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',WLjaXVNk2dnAJzPpy6OlMv4qoi9,375)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الأحدث',WLjaXVNk2dnAJzPpy6OlMv4qoi9,376)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'قائمة الممثلين',WLjaXVNk2dnAJzPpy6OlMv4qoi9,374)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="container"(.*?)top-menu',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items[7:]:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371)
		for Ga8xfYU6ht7cHjzn,title in items[0:7]:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371)
	return
def E0ENQdTlPHzxX3GUaBWJS9DKe(website=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-ACTORSMENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="row cat Tags"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if 'http' in Ga8xfYU6ht7cHjzn: continue
			else: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371)
	return
def llAve4QkUWp0hnPb17No(website=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-FEATURED-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"MainContent"(.*?)main-title2',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('://',':///').replace(bruAOCB4ZoHVF7,i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
				EE6ysIeB8jKNgCfOkv('video',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,372,NWqAr40jTLlMBemn3o79y)
	return
def DmZ63igH9dsxXRzAb0MT(id,website=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-WATCHINGNOW-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('main-title2(.*?)class="row',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[id]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('://',':///').replace(bruAOCB4ZoHVF7,i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
				EE6ysIeB8jKNgCfOkv('video',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,372,NWqAr40jTLlMBemn3o79y)
	return
def bsZhnoqjD3U(url,yGHav67gnAxtQo4FzrXROCuSJ9mMqI=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if 'vidpage_' in url:
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(/Album-.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if Ga8xfYU6ht7cHjzn:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn[0]
			bsZhnoqjD3U(Ga8xfYU6ht7cHjzn)
			return
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class=" subcats"(.*?)class="col-md-3',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if yGHav67gnAxtQo4FzrXROCuSJ9mMqI==kh850jKbzmBwY and liroJ6qCK9k and liroJ6qCK9k[0].count('href')>1:
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',url,371,kh850jKbzmBwY,kh850jKbzmBwY,'titles')
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371)
	else:
		SHTvIuhX52dxQRsWA = []
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="col-md-3(.*?)col-xs-12',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="col-sm-8"(.*?)col-xs-12',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
				Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('://',':///').replace(bruAOCB4ZoHVF7,i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
				if '/al_' in Ga8xfYU6ht7cHjzn:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371,NWqAr40jTLlMBemn3o79y)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) - +الحلقة +\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
					if WULSmfNH09tPIv58snzpCkR: title = '_MOD_مسلسل '+WULSmfNH09tPIv58snzpCkR[0]
					if title not in SHTvIuhX52dxQRsWA:
						SHTvIuhX52dxQRsWA.append(title)
						EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371,NWqAr40jTLlMBemn3o79y)
				else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,372,NWqAr40jTLlMBemn3o79y)
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="".*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
				title = 'صفحة '+E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,371,kh850jKbzmBwY,kh850jKbzmBwY,'titles')
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('label-success mrg-btm-5 ">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	QQJdiByEeNqLYGs = kh850jKbzmBwY
	O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('var url = "(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if O9wzaDlICnq: O9wzaDlICnq = O9wzaDlICnq[0]
	else: O9wzaDlICnq = url.replace('/vidpage_','/Play/')
	if 'http' not in O9wzaDlICnq: O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9+O9wzaDlICnq
	O9wzaDlICnq = O9wzaDlICnq.strip('-')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(i8a54nkd09BCbvuZxQFMAqDR2tlK,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'BOKRA-PLAY-2nd')
	kKwr9zX358QO47tbu1UC2 = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	QQJdiByEeNqLYGs = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if QQJdiByEeNqLYGs:
		QQJdiByEeNqLYGs = QQJdiByEeNqLYGs[-1]
		if 'http' not in QQJdiByEeNqLYGs: QQJdiByEeNqLYGs = 'http:'+QQJdiByEeNqLYGs
		if '/PLAY/' not in O9wzaDlICnq:
			if 'embed.min.js' in QQJdiByEeNqLYGs:
				ca8GhR5uYv0SbFC36NO = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if ca8GhR5uYv0SbFC36NO:
					eAZpSTaRtUrfMIs7J, rxUW96Rw3ianAv = ca8GhR5uYv0SbFC36NO[0]
					QQJdiByEeNqLYGs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(QQJdiByEeNqLYGs,'url')+'/v2/'+eAZpSTaRtUrfMIs7J+'/config/'+rxUW96Rw3ianAv+'.json'
		import OO3KYXPMuI
		OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo([QQJdiByEeNqLYGs],vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/Search/'+search
	bsZhnoqjD3U(url)
	return
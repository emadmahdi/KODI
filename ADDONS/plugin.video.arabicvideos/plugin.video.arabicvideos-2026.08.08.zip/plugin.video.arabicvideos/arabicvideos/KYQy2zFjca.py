# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = FkqI4Gm8wMvUVbgo(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ႏ")
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn,fRJYhnSKHsZ7MqFwmiVz=kh850jKbzmBwY):
	if   eYN1APt8aZflKmByj0ioGzn==WlU7AtONpyj3(u"࠳ᎂ"): RzuUtV3OZ6P(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠵ᎃ"): pass
	elif eYN1APt8aZflKmByj0ioGzn==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠷ᎄ"): pujLsDSbUtky8dzM2qGgAwflxen0(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠹ᎅ"): hDuiaoe7Fk()
	elif eYN1APt8aZflKmByj0ioGzn==sdRqnego9PclrL4m2J(u"࠴ᎆ"): kI2ryinlYotcSfE4q8UT(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==dQvxmFkyLOteNMWBJ2bDHV(u"࠶ᎇ"): o9pnaCxFIXwSrMVP8()
	elif eYN1APt8aZflKmByj0ioGzn==z8wTfYPiRQL(u"࠸ᎈ"): cHKCb25gadn6ki4SQJ7Pvw()
	elif eYN1APt8aZflKmByj0ioGzn==wb1nC3e8AjRVU4ovsuPa(u"࠺ᎉ"): bcJCAsovQl0dkSKR()
	elif eYN1APt8aZflKmByj0ioGzn==dQvxmFkyLOteNMWBJ2bDHV(u"࠼ᎊ"): yQHIV0XYfTuLrntPicw8hNKo()
	elif eYN1APt8aZflKmByj0ioGzn==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠶࠻࠰ᎋ"): dnGvtJ5sha()
	elif eYN1APt8aZflKmByj0ioGzn==A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠷࠵࠲ᎌ"): L3rIYOnpQJX2ymF4DPaHcMk()
	elif eYN1APt8aZflKmByj0ioGzn==J6G8X3gO1MiKh027D(u"࠱࠶࠴ᎍ"): JLkcOX2m9hVn()
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠲࠷࠶ᎎ"): xb5VI9fRrS6()
	elif eYN1APt8aZflKmByj0ioGzn==gNPRXprEAQJ(u"࠳࠸࠸ᎏ"): XVI3fuBiZwo1HSJadKNbn()
	elif eYN1APt8aZflKmByj0ioGzn==BBOY8rvinVbFh(u"࠴࠹࠺᎐"): VVCOEsewUNDZonLkz()
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠵࠺࠼᎑"): JJU2jI94nNtE()
	elif eYN1APt8aZflKmByj0ioGzn==ZeV4vau9CjN(u"࠶࠻࠷᎒"): VyJ1SqDs5jvprBoH7()
	elif eYN1APt8aZflKmByj0ioGzn==tzEjvOaZWU1A(u"࠷࠵࠹᎓"): jd7yhq6490Z5EpUCMi()
	elif eYN1APt8aZflKmByj0ioGzn==x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠱࠶࠻᎔"): Q7ec2iEWwNhKSUB3zX(dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠲࠹࠳᎕"): Go3cg10vtpxVDuhljUOQ()
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠳࠺࠵᎖"): nqa35JujQkNi1Zl4xz()
	elif eYN1APt8aZflKmByj0ioGzn==ZeV4vau9CjN(u"࠴࠻࠷᎗"): JzWXiMVkU8cp41nPHC7ZyDQAf([fRJYhnSKHsZ7MqFwmiVz],dbo4vrnTM56I,dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	elif eYN1APt8aZflKmByj0ioGzn==CMUXq6mPQV5rLsSBdWZJvA(u"࠵࠼࠹᎘"): BfnJNmF3wajrI5hqTQuzpVOds(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ႐"),dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠶࠽࠴᎙"): BfnJNmF3wajrI5hqTQuzpVOds(wb1nC3e8AjRVU4ovsuPa(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ႑"),dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==J6G8X3gO1MiKh027D(u"࠷࠷࠶᎚"): ZcMxSdYbDyRmUkvX5zoB4w()
	elif eYN1APt8aZflKmByj0ioGzn==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠱࠸࠸᎛"): kjchvyfurWUbIX5wnPNY0TqRLmlA()
	elif eYN1APt8aZflKmByj0ioGzn==ZeV4vau9CjN(u"࠲࠹࠺᎜"): T3E2DU9Oc7s6uadSYIHrWjknigZ(dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ႒"))
	elif eYN1APt8aZflKmByj0ioGzn==BBOY8rvinVbFh(u"࠳࠺࠽᎝"): T3E2DU9Oc7s6uadSYIHrWjknigZ(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ႓"))
	elif eYN1APt8aZflKmByj0ioGzn==x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠴࠽࠵᎞"): DimCxMk2fNH4q19()
	elif eYN1APt8aZflKmByj0ioGzn==XasF0WO7rDUHnEt8hAl9kLN(u"࠵࠾࠷᎟"): cEd1NuvM4aLe23xIGJZoqmt7P()
	elif eYN1APt8aZflKmByj0ioGzn==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠶࠿࠲Ꭰ"): KmpXWbVesjcwQG8tnOIJ()
	elif eYN1APt8aZflKmByj0ioGzn==G6GUCto502jZTLubYNnqMx8ywBah(u"࠷࠹࠴Ꭱ"): KoJB3XCRDiyUj5()
	elif eYN1APt8aZflKmByj0ioGzn==MBS1GrwQoUlsiIRfVDOHdA(u"࠱࠺࠶Ꭲ"): XEZQznufPd()
	elif eYN1APt8aZflKmByj0ioGzn==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠲࠻࠸Ꭳ"): yyONMGbBUKnHhrS6C9VLfgmap4J()
	elif eYN1APt8aZflKmByj0ioGzn==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠳࠼࠺Ꭴ"): UCRl657NaEu4bZOfhmgIcF9Vs1z8TA()
	elif eYN1APt8aZflKmByj0ioGzn==wnVICNyfE3XZ0htUaDFAOgLo(u"࠴࠽࠼Ꭵ"): lvkBQoAjptycmJa()
	elif eYN1APt8aZflKmByj0ioGzn==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠵࠾࠾Ꭶ"): S6SjfXlrsvqp()
	elif eYN1APt8aZflKmByj0ioGzn==x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠶࠿࠹Ꭷ"): p42CbDl1FRycsnL8NzPaXU()
	elif eYN1APt8aZflKmByj0ioGzn==YoMw2J1Ljp(u"࠹࠴࠱Ꭸ"): sN2iR3DaeMXhJjAZSQIw0FgyUfuc(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==G6GUCto502jZTLubYNnqMx8ywBah(u"࠳࠵࠳Ꭹ"): NIentSVcyBiY54WkwLXq7z8uTad()
	elif eYN1APt8aZflKmByj0ioGzn==XasF0WO7rDUHnEt8hAl9kLN(u"࠴࠶࠵Ꭺ"): YP7UH3pGoR46mI1afESzgOMD()
	elif eYN1APt8aZflKmByj0ioGzn==MBS1GrwQoUlsiIRfVDOHdA(u"࠵࠷࠷Ꭻ"): U9AT4fPHVdyDtqloC3JL5()
	elif eYN1APt8aZflKmByj0ioGzn==YoMw2J1Ljp(u"࠶࠸࠺Ꭼ"): llwNKXmUsB5cpItOCzRMu0()
	elif eYN1APt8aZflKmByj0ioGzn==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠷࠹࠼Ꭽ"): E6mCleYhtfDXpjvc2ugaQTK(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	elif eYN1APt8aZflKmByj0ioGzn==BBOY8rvinVbFh(u"࠸࠺࠷Ꭾ"): iQdx2LevkbrEK7OAT(dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==gNPRXprEAQJ(u"࠹࠴࠹Ꭿ"): ojXLQdesxltUYF6WMfBVIpP0()
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠳࠵࠻Ꮀ"): oDNVl1FR4raneiWhYC6tE58(J6G8X3gO1MiKh027D(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ႔"),dbo4vrnTM56I,dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==dQvxmFkyLOteNMWBJ2bDHV(u"࠶࠲࠳Ꮁ"): wzV6X7aBiLAM4WTEx()
	elif eYN1APt8aZflKmByj0ioGzn==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠷࠳࠵Ꮂ"): Z3qJalC9vAg()
	elif eYN1APt8aZflKmByj0ioGzn==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠸࠴࠷Ꮃ"): lBtE7m0AprDdhuZw1()
	elif eYN1APt8aZflKmByj0ioGzn==J6G8X3gO1MiKh027D(u"࠹࠵࠹Ꮄ"): EESKxloOs8(nhtQiTLMbx4kcymAPUF0GIXq)
	elif eYN1APt8aZflKmByj0ioGzn==sdRqnego9PclrL4m2J(u"࠺࠶࠴Ꮅ"): EESKxloOs8(Ls8nETvYeDouVpxIStMZy6mBw)
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠻࠰࠶Ꮆ"): fURNFwnLEtubOkWdA6s9jz5Y8XC()
	elif eYN1APt8aZflKmByj0ioGzn==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠵࠱࠸Ꮇ"): bYyrpulUGfHo(dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠶࠲࠺Ꮈ"): zzFOx6vDoS5ufGpsTBd0XJ()
	elif eYN1APt8aZflKmByj0ioGzn==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠷࠳࠼Ꮉ"): vgCaByuwmiIA3RqD4Mz2kYxG0()
	elif eYN1APt8aZflKmByj0ioGzn==z8wTfYPiRQL(u"࠴࠴࠷࠶Ꮊ"): KKZIXCDadtw4L1JM9ir3ozpH()
	elif eYN1APt8aZflKmByj0ioGzn==FkqI4Gm8wMvUVbgo(u"࠵࠵࠸࠱Ꮋ"): Yh3Sb8ABLNfivn6qCRlTxPzH()
	elif eYN1APt8aZflKmByj0ioGzn==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠶࠶࠲࠳Ꮌ"): T3E2DU9Oc7s6uadSYIHrWjknigZ(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ႕"))
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠷࠰࠳࠵Ꮍ"): XepEjD976JyPRldkKmW()
	elif eYN1APt8aZflKmByj0ioGzn==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠱࠱࠴࠷Ꮎ"): DV07FxNEvU2AZuYg3Wjmt9wISJkRih(dbo4vrnTM56I)
	elif eYN1APt8aZflKmByj0ioGzn==wnVICNyfE3XZ0htUaDFAOgLo(u"࠲࠲࠵࠹Ꮏ"): vqubNPTH3cKWC4mJME2SZ1gIXs()
	elif eYN1APt8aZflKmByj0ioGzn==taD1d3bpqyfM4VNhK0P29GSZ(u"࠳࠳࠶࠻Ꮐ"): SLhogQxDVJM2kBIwHaOyR4P()
	return
def DV07FxNEvU2AZuYg3Wjmt9wISJkRih(showDialogs=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1):
	vOaYw9z4tl = ppNwDFByU1dZn5ca.executeJSONRPC(tzEjvOaZWU1A(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡧࡦࡲࡥ࠯࡭ࡨࡽࡧࡵࡡࡳࡦ࡯ࡥࡾࡵࡵࡵࡵࠥࢁࢂ࠭႖"))
	vOaYw9z4tl = vDVykQSI8dwipbZuJmG31RO7l6h.loads(vOaYw9z4tl)[A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ႗")][taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡶࡢ࡮ࡸࡩࠬ႘")]
	choice,GcSgHZAMnVfNbyCzKRk = s0sB2Xyp9uYU5N3fxzKoLW8,vOaYw9z4tl[:]
	if showDialogs:
		PPyjgblOKdvBnu9fRWeC7aSUYTHJr = tzEjvOaZWU1A(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡ็ไ฽้ฯ้ࠠฬ฼้้࠭႙") if FkqI4Gm8wMvUVbgo(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨႚ") in vOaYw9z4tl else sdRqnego9PclrL4m2J(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห้ࠣฯ๎โโหࠪႛ")
		choice = NJZUGpSmQLPBxuv3Mn(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡧࡪࡴࡴࡦࡴࠪႜ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫำื่อࠩႝ"),HfuZG0aphlYnVLOyAk93rj(u"ࠬห๊ใษไࠫ႞"),taD1d3bpqyfM4VNhK0P29GSZ(u"࠭สี฼ํ่ࠬ႟"),fWM6PeOrvciG0RQpIKzltojDqaYs,HHFAVK8SwRUqBLuTfdeJ9nbD+PPyjgblOKdvBnu9fRWeC7aSUYTHJr+wVvqN8LZCJW5ryAb1EHRPFkQ0+URBvawyLXfQiS2NI34HDk+URBvawyLXfQiS2NI34HDk+HHthiRYs8T6IO3qUyX(u"่ࠧา๊ࠤฬู๊่์ไอࠥะำๆฯࠣฬฬูสฯัส้๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦวๅ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊ฯࠦสิฬฺ๎฾ࠦร็ࠢอ฽๊๊ࠠษฯฮࠤๆ๐ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ࠲࠳ࠦร้ࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะใหสࠣีุอไสࠢ็่๊ฮัๆฮࠣฬฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧႠ"))
	if choice==s0sB2Xyp9uYU5N3fxzKoLW8 and ZeV4vau9CjN(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨႡ") not in vOaYw9z4tl: GcSgHZAMnVfNbyCzKRk = [A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩႢ")]+vOaYw9z4tl
	elif choice==igM4DhpPzoX95Ysnar6Auj and oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪႣ") in vOaYw9z4tl:
		GcSgHZAMnVfNbyCzKRk = vOaYw9z4tl[:]
		GcSgHZAMnVfNbyCzKRk.remove(dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫႤ"))
	if GcSgHZAMnVfNbyCzKRk!=vOaYw9z4tl:
		GcSgHZAMnVfNbyCzKRk = str(GcSgHZAMnVfNbyCzKRk).replace(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧ࠭ࠢႥ"),HHthiRYs8T6IO3qUyX(u"࠭ࠢࠨႦ"))
		PP3FsDicLyWuTR7GV5Ia = ppNwDFByU1dZn5ca.executeJSONRPC(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠩႧ")+GcSgHZAMnVfNbyCzKRk+YoMw2J1Ljp(u"ࠨࡿࢀࠫႨ"))
		if showDialogs:
			if J6G8X3gO1MiKh027D(u"ࠩࡷࡶࡺ࡫ࠧႩ") in str(PP3FsDicLyWuTR7GV5Ia): o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧႪ"))
			else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHthiRYs8T6IO3qUyX(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩႫ"))
	return
def XepEjD976JyPRldkKmW():
	MG645iOBIVYXStw79kfNz0enRKFrC = l7tuXCf0oKV9FPOy6Hb.getSetting(gNPRXprEAQJ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩႬ"))
	message = Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭วๅำๅ้ࠥอไๆฯาำࠥำวๅ์สࠤ์๎ࠠ࠻ࠢࠣࠤࠬႭ")+str(MG645iOBIVYXStw79kfNz0enRKFrC)+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࠡ࡭ࡥࡴࡸ࠭Ⴎ") if MG645iOBIVYXStw79kfNz0enRKFrC else Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡ็อ์็็ษࠡฯส่๏อࠧႯ")
	message = HHFAVK8SwRUqBLuTfdeJ9nbD+message+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩ࡟ࡲ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅࠢฦ์ࠥะฺ๋์ิࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠨႰ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠪࡧࡪࡴࡴࡦࡴࠪႱ"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠫำื่อࠩႲ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬห๊ใษไࠫႳ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭สี฼ํ่ࠬႴ"),fWM6PeOrvciG0RQpIKzltojDqaYs,message+dQvxmFkyLOteNMWBJ2bDHV(u"ࠧ࡝ࡰ࡟ࡲฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤ์๐ฺࠠ็็๎ฮ๊ࠦใ๊่ࠤอํวࠡษ็ฬึ์วๆฮࠣฬฬิส๋ษิࠤศ฿ไ๊ࠢฯ์ิฯࠠๆฬ๋ๅึฯࠠๅำๅ้ࠥอไอ๊าอࠥอไั์ࠣห๋ะࠠหฯาำ์ࠦแ๋๊ࠢิ์ࠦวๅึสุฮࠦ࠮࠯๋๋ࠢีอࠠๆ฻้ห์ูࠦ็ั่หࠥะโ้็ࠣห๋ะࠠษฬื฾๏๊ࠠโ์า๎ํࠦแศ่ࠣห้ฮั็ษ่ะ๊ࠥๆࠡ์ึวฺ้้่ࠠࠣห้า่ะหࠣห้ะ๊ࠡฬิ๎ิํวࠡๆฦ๊ࠥอไษำ้ห๊าࠠิ๊ไࠤ๏ิสศำࠣห้า่ะหࠣวํะ่ๆษอ๎่๐วࠡ࠰࠱ࠤ฾๊ๅศࠢส๊์๊ࠦอสࠣหำะ๊ศำࠣี็๋ࠠอ๊าอࠥ฻ฺ๋ำࠣษีอࠠไษ้ฮࠥอไฦ่อี๋ะฺ่ࠠา็ࠥฮื๋ศฬࠤศ๎ࠠใๆํ่ฮ࠭Ⴕ"))
	if gNiJnH3cvG1Dd9t in [-WlU7AtONpyj3(u"࠴Ꮑ"),HfuZG0aphlYnVLOyAk93rj(u"࠴Ꮒ")]: return
	if gNiJnH3cvG1Dd9t==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠶Ꮓ"):
		MG645iOBIVYXStw79kfNz0enRKFrC = kh850jKbzmBwY
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,BBOY8rvinVbFh(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊ใษไࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫႶ"))
	else:
		items = [FkqI4Gm8wMvUVbgo(u"ࠩ࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫႷ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠪ࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬႸ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫ࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭Ⴙ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠬ࠷࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႺ"),J6G8X3gO1MiKh027D(u"࠭࠱࠳࠷࠳ࠤࡰࡨࡰࡴࠩႻ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠧ࠲࠷࠳࠴ࠥࡱࡢࡱࡵࠪႼ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࠳࠺࠹࠵ࠦ࡫ࡣࡲࡶࠫႽ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩ࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬႾ"),YoMw2J1Ljp(u"ࠪ࠶࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭Ⴟ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫ࠸࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧჀ"),BBOY8rvinVbFh(u"ࠬ࠹࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨჁ"),FkqI4Gm8wMvUVbgo(u"࠭࠴࠱࠲࠳ࠤࡰࡨࡰࡴࠩჂ"),gNPRXprEAQJ(u"ࠧ࠵࠷࠳࠴ࠥࡱࡢࡱࡵࠪჃ"),ZeV4vau9CjN(u"ࠨ࠷࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫჄ"),YoMw2J1Ljp(u"ࠩ࠹࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬჅ"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠪ࠻࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭჆"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠫ࠽࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧჇ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬ࠿࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ჈"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭࠱࠱࠲࠳࠴ࠥࡱࡢࡱࡵࠪ჉"),HfuZG0aphlYnVLOyAk93rj(u"ࠧ࠲࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ჊"),sdRqnego9PclrL4m2J(u"ࠨ࠳࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬ჋"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩ࠼࠽࠾࠿࠹ࠡ࡭ࡥࡴࡸ࠭჌")]
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo(XasF0WO7rDUHnEt8hAl9kLN(u"ࠪหำะัࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡษ็้๋อำษหࠪჍ"),items)
		if TTn7mZzPRjq5GBESh8aKy==-SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠷Ꮔ"): return
		MG645iOBIVYXStw79kfNz0enRKFrC = str(items[TTn7mZzPRjq5GBESh8aKy][:-kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠵Ꮕ")])
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,dQvxmFkyLOteNMWBJ2bDHV(u"๋ࠫาอหࠢ฼้้๐ษࠡฬื฾๏๊้ࠠฬะำ๏ีࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࡠࡳࡢ࡮ࠨ჎")+HHFAVK8SwRUqBLuTfdeJ9nbD+MG645iOBIVYXStw79kfNz0enRKFrC+G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬࠦ࡫ࡣࡲࡶࠫ჏")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
	l7tuXCf0oKV9FPOy6Hb.setSetting(CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪა"),MG645iOBIVYXStw79kfNz0enRKFrC)
	return
def Yh3Sb8ABLNfivn6qCRlTxPzH(WLX7eo3a86Q=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1):
	rfHTFW3wbSMAR6eGxgJn0kcCLoN = n7nyEOZgJMld1IbGH5Dexz6ciUamp8()
	PPyjgblOKdvBnu9fRWeC7aSUYTHJr = ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ์฼้้࠭ბ") if rfHTFW3wbSMAR6eGxgJn0kcCLoN else ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใ่ࠢฮํ่แࠨგ")
	gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡦࡩࡳࡺࡥࡳࠩდ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪาึ๎ฬࠨე"),z8wTfYPiRQL(u"ࠫส๐โศใࠪვ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬะิ฻์็ࠫზ"),fWM6PeOrvciG0RQpIKzltojDqaYs,HHFAVK8SwRUqBLuTfdeJ9nbD+PPyjgblOKdvBnu9fRWeC7aSUYTHJr+wVvqN8LZCJW5ryAb1EHRPFkQ0+URBvawyLXfQiS2NI34HDk+gNPRXprEAQJ(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯาูๅࠢๆ์ิ๐ࠠฤ๊อ์๊อส๋ๅํหࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๊ไศฯๅࠤ࠳࠴ࠠฦ็สࠤอ฿ฯࠡษ้ฮ์อมࠡษ็ๅ๏ี๊้ࠢส่าอไ๋ࠢหว่๋ไ่ࠢ࠱࠲ࠥษ่ࠡส฼ำࠥอไ็ไิࠤ฾๊้ࠡิิࠤࠧะฬศ๊ีࠤส๊้ࠡษ็่ฬำโࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢศ่฿อมࠡษ็ฮูเ๊ๅࠢส่้ออใࠢหห้์โาࠢ฼่๎ࠦาาࠢࠥษ๏่วโࠢส่ๆ๐ฯ๋๊ࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤฬ๊วิฬไหิฯࠠๆ่ࠣฮ฿๐๊าࠢอีฯ๐ศࠡ็ะฮํ๐วหࠢส่็๎วว็ࠣ࠲࠳่ࠦฯษุอࠥะัห์หࠤา๊โศฬࠣห้๋ำๅี็หฯࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊่ࠠา๊ࠤฬู๊่์ไอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭თ"))
	if gNiJnH3cvG1Dd9t==igM4DhpPzoX95Ysnar6Auj: rOtv5I87Hb9KB4FX3we = ppNwDFByU1dZn5ca.executeJSONRPC(BBOY8rvinVbFh(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࡟ࢀࢁࠬი"))
	elif gNiJnH3cvG1Dd9t==s0sB2Xyp9uYU5N3fxzKoLW8: rOtv5I87Hb9KB4FX3we = ppNwDFByU1dZn5ca.executeJSONRPC(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝࠴ࡡࢂࢃࠧკ"))
	if gNiJnH3cvG1Dd9t in [igM4DhpPzoX95Ysnar6Auj,s0sB2Xyp9uYU5N3fxzKoLW8]:
		if aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩࡷࡶࡺ࡫ࠧლ") in str(rOtv5I87Hb9KB4FX3we): o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHthiRYs8T6IO3qUyX(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧმ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gNPRXprEAQJ(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩნ"))
	return
def KKZIXCDadtw4L1JM9ir3ozpH():
	url = Y3Ny5eLHdp.SITESURLS[J6G8X3gO1MiKh027D(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧო")][wb1nC3e8AjRVU4ovsuPa(u"࠱Ꮖ")]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,FkqI4Gm8wMvUVbgo(u"࠭ࡇࡆࡖࠪპ"),url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬჟ"))
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ddXFhKwSID7ZUc3 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨრ"),uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ddXFhKwSID7ZUc3 = sorted(ddXFhKwSID7ZUc3,reverse=dbo4vrnTM56I)
	TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo(CMUXq6mPQV5rLsSBdWZJvA(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫს"),ddXFhKwSID7ZUc3)
	if TTn7mZzPRjq5GBESh8aKy>=gNPRXprEAQJ(u"࠲Ꮗ"):
		ZTKX9j5Bepfz3kE0cIlwCAdUr = url.rsplit(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,WlU7AtONpyj3(u"࠴Ꮘ"))[u8iSx05wLfVyMNp1X3l(u"࠴Ꮙ")]+u8iSx05wLfVyMNp1X3l(u"ࠪ࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࠫტ")+ddXFhKwSID7ZUc3[TTn7mZzPRjq5GBESh8aKy]+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫ࠳ࢀࡩࡱࠩუ")
		succeeded = wwQH0OrJK467EjF5(dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪფ"),ZTKX9j5Bepfz3kE0cIlwCAdUr,dbo4vrnTM56I)
		if succeeded:
			l7tuXCf0oKV9FPOy6Hb.setSetting(J6G8X3gO1MiKh027D(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪქ"),kh850jKbzmBwY)
			II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧห็ࠣฮะฮ๊หࠢศูิอัࠡไา๎๊ࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ้้ๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤศ๎ส้็สฮ๏้๊ศࠢหฮาี๊ฬࠢฯ้๏฿ࠠศๆหีฬ๋ฬࠡสสืฯิฯศ็ࠣฦำืࠠฦืาหึࠦๅห๊ไีࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠฦ์ๅหๆࠦวๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไ่าสࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪღ"))
			if II7ErX2ocuU: oDNVl1FR4raneiWhYC6tE58(J6G8X3gO1MiKh027D(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ყ"),dbo4vrnTM56I,dbo4vrnTM56I)
	return
def zzFOx6vDoS5ufGpsTBd0XJ():
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,BBOY8rvinVbFh(u"๊่ࠩࠥะั๋ัࠣๅ฾๊วࠡ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡษ็าฬ฻ษࠡส๋ๆฯࠦฬๅสࠣห้ะอะ์ฮหฯࠦ࠮࠯๊ࠢิฬࠦวๅ็ึัู่ࠥโࠢํือฮࠠหฯา๎ะࠦแ้ำํࠤ้าๅ๋฻ࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํ๋ࠥั้ำࠣ์็ะࠠๆ฻ํ๊ࠬშ"))
	if II7ErX2ocuU:
		l7tuXCf0oKV9FPOy6Hb.setSetting(YoMw2J1Ljp(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡶ࡬ࡴࡸࡴࠨჩ"),kh850jKbzmBwY)
		l7tuXCf0oKV9FPOy6Hb.setSetting(u8iSx05wLfVyMNp1X3l(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫც"),kh850jKbzmBwY)
		l7tuXCf0oKV9FPOy6Hb.setSetting(J6G8X3gO1MiKh027D(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩძ"),kh850jKbzmBwY)
		l7tuXCf0oKV9FPOy6Hb.setSetting(NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧწ"),kh850jKbzmBwY)
		l7tuXCf0oKV9FPOy6Hb.setSetting(NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩჭ"),kh850jKbzmBwY)
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨฬ่ࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥ๎ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสอัิ๐ห้ࠡำ๋ࠥอไฦ฻าหิอสࠡ࠰࠱ࠤํษ๊ืษࠣฮาี๊ฬ๋ࠢ฼ฬฬแࠡษ็ฬึ์วๆฮࠣห้ะ๊ࠡฬ฼ฮ๊ีฺࠠๆ์ࠤฬ๊่ใฬࠪხ"))
		EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def fURNFwnLEtubOkWdA6s9jz5Y8XC():
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧჯ"),BBOY8rvinVbFh(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ჰ"))
	OOSTfYwR1Q45yq0F2Meoi6bxALa = YzCfP9jWUqo28NQH5k4lDFJduSic(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	J9culz3S7AQw5PGvfjDrg = URBvawyLXfQiS2NI34HDk
	yxFTmaSUO5bLuEjodNeM0r8B = RlMpu0hP8YmzZovkVXOs1G+BBOY8rvinVbFh(u"ࠫࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠࠨჱ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	eHZrzUEx7K5s1Ca = URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩჲ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+dQvxmFkyLOteNMWBJ2bDHV(u"࠭࡜࡯࡞ࡱࠫჳ")
	for id,VwPKg4qUmChSbR2Bj,CP40jZaurIbXOYi,r0DZkyVeJ4WL7hp,p2jM0PyqsJfe8FHzC5kTu,reason in reversed(OOSTfYwR1Q45yq0F2Meoi6bxALa):
		if id==MBS1GrwQoUlsiIRfVDOHdA(u"ࠧ࠱ࠩჴ"):
			bnzKgiyqL9N35rOeDjdopvm6F,TxsV19OXq2Fohc7ljKJamY = r0DZkyVeJ4WL7hp.split(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨ࡞ࡱ࠿ࡀ࠭ჵ"))
			continue
		if J9culz3S7AQw5PGvfjDrg!=URBvawyLXfQiS2NI34HDk: J9culz3S7AQw5PGvfjDrg += eHZrzUEx7K5s1Ca
		i2xKJuM5eANb = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨჶ")+RlMpu0hP8YmzZovkVXOs1G+id+MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࠤ࠿ࠦࠧჷ")+WlU7AtONpyj3(u"ࠫฬ๊ำลษ็ࠤ࠿ࠦࠧჸ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+CP40jZaurIbXOYi
		ccYfzwbEjm2qxCdhlSRWt = taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬࡢ࡮࡜ࡔࡗࡐࡢ࠭ჹ")+RlMpu0hP8YmzZovkVXOs1G+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠭วๅฮ๋หอࠦ࠺ࠡࠩჺ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+r0DZkyVeJ4WL7hp
		TTQHx1fWsXizAbwYFO6dEP9vclK = HHthiRYs8T6IO3qUyX(u"ࠧ࡜ࡔࡗࡐࡢ࠭჻")+RlMpu0hP8YmzZovkVXOs1G+tzEjvOaZWU1A(u"ࠨษ็า฼ษࠠ࠻ࠢࠪჼ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+p2jM0PyqsJfe8FHzC5kTu
		iUzhMjqu1OQ7 = wb1nC3e8AjRVU4ovsuPa(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟ࠪჽ")+RlMpu0hP8YmzZovkVXOs1G+dQvxmFkyLOteNMWBJ2bDHV(u"ࠪหู้ศษࠢ࠽ࠤࠬჾ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+reason
		J9culz3S7AQw5PGvfjDrg += i2xKJuM5eANb+ccYfzwbEjm2qxCdhlSRWt+URBvawyLXfQiS2NI34HDk+yxFTmaSUO5bLuEjodNeM0r8B+URBvawyLXfQiS2NI34HDk+TTQHx1fWsXizAbwYFO6dEP9vclK+iUzhMjqu1OQ7+URBvawyLXfQiS2NI34HDk
	KKHpNde5TOmYqjIygtlwhf7W2sr(Urj6egiVyHA75ZK(u"ࠫࡷ࡯ࡧࡩࡶࠪჿ"),TxsV19OXq2Fohc7ljKJamY,J9culz3S7AQw5PGvfjDrg,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ᄀ"))
	return
def EESKxloOs8(file):
	if file==Ls8nETvYeDouVpxIStMZy6mBw: kRmS7GetnWNpr = HfuZG0aphlYnVLOyAk93rj(u"࠭โ้ษษ้ࠥอไๆใู่ฮ࠭ᄁ")
	elif file==nhtQiTLMbx4kcymAPUF0GIXq: kRmS7GetnWNpr = gNPRXprEAQJ(u"ࠧใ๊สส๊ࠦยฯำࠣห้็๊ะ์๋๋ฬะࠧᄂ")
	gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᄃ"),taD1d3bpqyfM4VNhK0P29GSZ(u"่ࠩืา࠭ᄄ"),z8wTfYPiRQL(u"ࠪษฺ๊วฮࠩᄅ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫำื่อࠩᄆ"),fWM6PeOrvciG0RQpIKzltojDqaYs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬํไࠡฬิ๎ิࠦลึๆสั๋ࠥไโࠢࠪᄇ")+kRmS7GetnWNpr+WlU7AtONpyj3(u"࠭ࠠฤ็ࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไࠤฤ࠭ᄈ"))
	if gNiJnH3cvG1Dd9t==taD1d3bpqyfM4VNhK0P29GSZ(u"࠵Ꮚ"):
		if YdDkIjFhgzuboBKca70ERt.path.exists(file):
			try: YdDkIjFhgzuboBKca70ERt.remove(file)
			except: pass
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧห็ุ้ࠣำࠠๆๆไࠤࠬᄉ")+kRmS7GetnWNpr)
	elif gNiJnH3cvG1Dd9t==XasF0WO7rDUHnEt8hAl9kLN(u"࠷Ꮛ"):
		data = cKMH9xQ3YwjEsZeVBbXa(file)
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨᄊ")+kRmS7GetnWNpr)
	return
def Z3qJalC9vAg():
	if xkio8CndBTR19MPztUvSqVLG5rcW<A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠱࠹Ꮜ"):
		gfe2BNJ3kTF0Xx = CMUXq6mPQV5rLsSBdWZJvA(u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬᄋ")+str(xkio8CndBTR19MPztUvSqVLG5rcW)+YoMw2J1Ljp(u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫᄌ")
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
		return
	Vew6ko57lWDvgiSaYBjrZHXhc = ppNwDFByU1dZn5ca.executeJSONRPC(ZeV4vau9CjN(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᄍ"))
	p9XQ5ELjTtvSUyCZMzuPfq = toPT5OnwVCDE7Rci1x3vZ0aB2Ymzrj([J6G8X3gO1MiKh027D(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᄎ")])
	e5z2d6xF1A8t,cwZz4lxQWH3tKOpP,AIPMnOeZ6dh2TF5atbm8kWyxpY94R,mmxYiVp9sz2NF6On1,PCEfM9VNLUzgI3sYW1J47Zc5oGD,nJuZIQCMLGz,s7cL8GMbQPwmfAJD1O6z3 = p9XQ5ELjTtvSUyCZMzuPfq[Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᄏ")]
	if e5z2d6xF1A8t or ZeV4vau9CjN(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᄐ") not in str(Vew6ko57lWDvgiSaYBjrZHXhc):
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,WlU7AtONpyj3(u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭ᄑ"))
		jVhaOJ9utFmLGZpHceKNMlE = lBtE7m0AprDdhuZw1()
		if not jVhaOJ9utFmLGZpHceKNMlE: return
	Fn2bCjwJos7liIu4aGKVWYN(dbo4vrnTM56I)
	return
def Fn2bCjwJos7liIu4aGKVWYN(showDialogs=dbo4vrnTM56I):
	Vew6ko57lWDvgiSaYBjrZHXhc = ppNwDFByU1dZn5ca.executeJSONRPC(HHthiRYs8T6IO3qUyX(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬᄒ"))
	if BBOY8rvinVbFh(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᄓ") not in str(Vew6ko57lWDvgiSaYBjrZHXhc):
		if showDialogs:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HfuZG0aphlYnVLOyAk93rj(u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩᄔ"))
		return
	piA2l9JHj1nqLBPboVRcZtvwmaIs = YdDkIjFhgzuboBKca70ERt.path.join(Vx3dLGn9Sc7jkBM,YoMw2J1Ljp(u"ࠬࡧࡤࡥࡱࡱࡷࠬᄕ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᄖ"),wb1nC3e8AjRVU4ovsuPa(u"ࠧ࠸࠴࠳ࡴࠬᄗ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭ࠩᄘ"))
	if not YdDkIjFhgzuboBKca70ERt.path.exists(piA2l9JHj1nqLBPboVRcZtvwmaIs): return
	UCZFVWoE9Thtd04DcyYug7rQO1XBP = open(piA2l9JHj1nqLBPboVRcZtvwmaIs,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡵࡦࠬᄙ")).read()
	if eOQJrvLAZC: UCZFVWoE9Thtd04DcyYug7rQO1XBP = UCZFVWoE9Thtd04DcyYug7rQO1XBP.decode(NVbhZ0DTpOkCA)
	g4UDtw0xdEFY8lcZi2vHCV5RyjX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(XasF0WO7rDUHnEt8hAl9kLN(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠬࡡࡪࠫ࠭࡞ࡧ࠯࠱ࡢࡤࠬࠫ࠯ࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪᄚ"),UCZFVWoE9Thtd04DcyYug7rQO1XBP,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	hrLB5RoQcJNK,llWhoxv3fVOYX5ie47 = g4UDtw0xdEFY8lcZi2vHCV5RyjX[nxUveizbLEAT2FBNy3]
	bJkvH5hKQptTGMmr7ygZqOA = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬᄛ")+hrLB5RoQcJNK+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬ࠲ࠧᄜ")+llWhoxv3fVOYX5ie47+wnVICNyfE3XZ0htUaDFAOgLo(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨᄝ")
	if showDialogs:
		vvfas8d90xetCAmuPID = ppNwDFByU1dZn5ca.getInfoLabel(MBS1GrwQoUlsiIRfVDOHdA(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡚࡮࡫ࡷ࡮ࡱࡧࡩࠬᄞ"))
		if vvfas8d90xetCAmuPID==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫᄟ"): Qf927eWJCDnF1KO = dQvxmFkyLOteNMWBJ2bDHV(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩᄠ")
		elif vvfas8d90xetCAmuPID==aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩᄡ"): Qf927eWJCDnF1KO = MBS1GrwQoUlsiIRfVDOHdA(u"ࠫ็๎วว็ࠣห้฻่าࠩᄢ")
		else: Qf927eWJCDnF1KO = MBS1GrwQoUlsiIRfVDOHdA(u"่่ࠬศศ่ࠤศิั๊ࠩᄣ")
		gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᄤ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧใ๊สส๊ࠦรฯำ์ࠫᄥ"),sdRqnego9PclrL4m2J(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨᄦ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧᄧ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪห๋ะࠠฮษ็๎ฬࠦสิฬัำ๊ࠦࠧᄨ")+Qf927eWJCDnF1KO,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫฬ์สࠡษ็ฦ๋ࠦสิฬัำ๊ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์ใࠡฬึฮ฼๐ูࠡษึฮำีวๆࠢส่็๎วว็ࠣห้๋ี้ำฬࠤอีไศ่๊่่ࠢࠥศศ่ࠤฬ๊ใหษหอࠥ࠴้ࠠลํฺฬࠦสิฬฺ๎฾ࠦล๋ไสๅ์อࠠโ์ࠣว๏่ࠦใฬࠣฮูอมࠡ࡞ࡱࡠࡳࠦࠧᄩ")+RlMpu0hP8YmzZovkVXOs1G+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢࠩᄪ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		if gNiJnH3cvG1Dd9t==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠲Ꮝ"): AUko8sxiFfmWN1273DSRcMlT45gI = WlU7AtONpyj3(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩᄫ")
		elif gNiJnH3cvG1Dd9t==XasF0WO7rDUHnEt8hAl9kLN(u"࠴Ꮞ"): AUko8sxiFfmWN1273DSRcMlT45gI = z8wTfYPiRQL(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ᄬ")
		else: AUko8sxiFfmWN1273DSRcMlT45gI = kh850jKbzmBwY
	else:
		vvfas8d90xetCAmuPID = l7tuXCf0oKV9FPOy6Hb.getSetting(FkqI4Gm8wMvUVbgo(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭ᄭ"))
		if   vvfas8d90xetCAmuPID==kh850jKbzmBwY: gNiJnH3cvG1Dd9t = NZiEOAWrSX1u2gU05DR6TB8tm(u"࠳Ꮟ")
		elif vvfas8d90xetCAmuPID==BBOY8rvinVbFh(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬᄮ"): gNiJnH3cvG1Dd9t = aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠵Ꮠ")
		elif vvfas8d90xetCAmuPID==aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩᄯ"): gNiJnH3cvG1Dd9t = ZeV4vau9CjN(u"࠷Ꮡ")
		AUko8sxiFfmWN1273DSRcMlT45gI = vvfas8d90xetCAmuPID
	if   gNiJnH3cvG1Dd9t==ssYkHaML9z37bJ0StuEBXIqgiV(u"࠶Ꮢ"): TTnRBvdbw1mqS4ouOilhPtyjszcNU = gNPRXprEAQJ(u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨᄰ")
	elif gNiJnH3cvG1Dd9t==FkqI4Gm8wMvUVbgo(u"࠱Ꮣ"): TTnRBvdbw1mqS4ouOilhPtyjszcNU = YoMw2J1Ljp(u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩᄱ")
	elif gNiJnH3cvG1Dd9t==FkqI4Gm8wMvUVbgo(u"࠳Ꮤ"): TTnRBvdbw1mqS4ouOilhPtyjszcNU = XasF0WO7rDUHnEt8hAl9kLN(u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪᄲ")
	else: return
	l7tuXCf0oKV9FPOy6Hb.setSetting(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬᄳ"),AUko8sxiFfmWN1273DSRcMlT45gI)
	xqtyX89BovTRgPi0jA4wHuQULKmI = Urj6egiVyHA75ZK(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩᄴ")+TTnRBvdbw1mqS4ouOilhPtyjszcNU+gNPRXprEAQJ(u"ࠩ࠯ࠫᄵ")+llWhoxv3fVOYX5ie47+WlU7AtONpyj3(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬᄶ")
	cGMhOotCmlI7XsjDfTgK9xZNE = UCZFVWoE9Thtd04DcyYug7rQO1XBP.replace(bJkvH5hKQptTGMmr7ygZqOA,xqtyX89BovTRgPi0jA4wHuQULKmI)
	if eOQJrvLAZC: cGMhOotCmlI7XsjDfTgK9xZNE = cGMhOotCmlI7XsjDfTgK9xZNE.encode(NVbhZ0DTpOkCA)
	open(piA2l9JHj1nqLBPboVRcZtvwmaIs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡼࡨࠧᄷ")).write(cGMhOotCmlI7XsjDfTgK9xZNE)
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬ࠴࡜ࡵࡕ࡮࡭ࡳࠦࡄࡦࡨࡤࡹࡱࡺࠠࡗ࡫ࡨࡻࡸࡀࠠ࡜ࠢࠪᄸ")+TTnRBvdbw1mqS4ouOilhPtyjszcNU+gNPRXprEAQJ(u"࠭ࠠ࡞ࠩᄹ"))
	if showDialogs: ppNwDFByU1dZn5ca.executebuiltin(gNPRXprEAQJ(u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭ᄺ"))
	return
def wzV6X7aBiLAM4WTEx():
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨสิ๊ฬ๋ฬࠡ฻่หิࠦแู๋้้้ࠣไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤส๋วࠡล็ษฺีวาࠢๅำ๏๋ࠠ࠯࠰࠱ࠤศ๎ࠠศ่อࠤ๊๋ๆ้฻้๋ࠣࠦวิฬัำฬ๋ࠠศๆหี๋อๅอࠢ࠱࠲࠳ࠦร้ࠢ็ำ๏้ࠠๆึๆ่ฮࠦรฯำ์ࠤฯิีࠡฮ๊หื้ࠠฤ่อࠤํ๊วࠡฬัูࠥฮโ๋หࠣา้่ࠠศๆ็๋ࠥࡢ࡮࡝ࡰࠣัฬ๎ไࠡฬะำ๏ัࠠศๆหี๋อๅอࠢฦ์ࠥอสึๆࠣฬฬ๊ๅษำ่ะ๊ࠥๅฺำไอูࠥศษࠢสฺ่๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦแฮืࠣห้ะอะ์ฮหฯࠦวๅฤ้ࠤฤ࠭ᄻ"))
	if II7ErX2ocuU==u8iSx05wLfVyMNp1X3l(u"࠳Ꮥ"): bcJCAsovQl0dkSKR()
	return
def yQHIV0XYfTuLrntPicw8hNKo():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,BBOY8rvinVbFh(u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬᄼ"))
	return
def ojXLQdesxltUYF6WMfBVIpP0():
	i2xKJuM5eANb = RlMpu0hP8YmzZovkVXOs1G+HHthiRYs8T6IO3qUyX(u"ࠪฮ฾ีวะࠢื๎฾ฯࠠรๆ้ࠣา๋ฯࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤ࠿ࠦࠧᄽ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	i2xKJuM5eANb += wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪᄾ")
	i2xKJuM5eANb += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯ࡴࡪ࡬ࡥࡨࡵࡵ࡯ࡶࠪᄿ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	ccYfzwbEjm2qxCdhlSRWt = RlMpu0hP8YmzZovkVXOs1G+Urj6egiVyHA75ZK(u"࠭ศา่ส้ัࠦิา์ฺࠤฬ๊ๅิๆ่ࠤ࠿ࠦࠧᅀ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	ccYfzwbEjm2qxCdhlSRWt += YoMw2J1Ljp(u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫᅁ")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+WlU7AtONpyj3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡱࡺࡹ࡬ࡪ࡯ࡵࡹࡱ࡫ࡲࠨᅂ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	gfe2BNJ3kTF0Xx = FkqI4Gm8wMvUVbgo(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨᅃ")+i2xKJuM5eANb+WlU7AtONpyj3(u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨᅄ")+ccYfzwbEjm2qxCdhlSRWt
	KKHpNde5TOmYqjIygtlwhf7W2sr(XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡷ࡯ࡧࡩࡶࠪᅅ"),kh850jKbzmBwY,gfe2BNJ3kTF0Xx)
	return
def E6mCleYhtfDXpjvc2ugaQTK(j74j26QlgA8):
	cW0nAyRfCOhPkLVpbN(uQIXMypK534GsVWetdl6Px9fTjUn)
	OOSTfYwR1Q45yq0F2Meoi6bxALa = YzCfP9jWUqo28NQH5k4lDFJduSic(j74j26QlgA8)
	for sFiM7TgPWRekGDAvbq29Vy83 in [z8wTfYPiRQL(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᅆ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩᅇ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᅈ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࡣ࡙࡙ࠧᅉ")]:
		if sFiM7TgPWRekGDAvbq29Vy83 in Y3Ny5eLHdp.SEND_THESE_EVENTS: Y3Ny5eLHdp.SEND_THESE_EVENTS.remove(sFiM7TgPWRekGDAvbq29Vy83)
	Ss8qMFRLjJQm6TNutnVXkcevg1(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗࠬᅊ"))
	id,VwPKg4qUmChSbR2Bj,CP40jZaurIbXOYi,r0DZkyVeJ4WL7hp,p2jM0PyqsJfe8FHzC5kTu,reason = OOSTfYwR1Q45yq0F2Meoi6bxALa[nxUveizbLEAT2FBNy3]
	bnzKgiyqL9N35rOeDjdopvm6F,TxsV19OXq2Fohc7ljKJamY = r0DZkyVeJ4WL7hp.split(J6G8X3gO1MiKh027D(u"ࠪࡠࡳࡁ࠻ࠨᅋ"))
	ccYfzwbEjm2qxCdhlSRWt,TTQHx1fWsXizAbwYFO6dEP9vclK,iUzhMjqu1OQ7 = p2jM0PyqsJfe8FHzC5kTu.split(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫࡡࡴ࠻࠼ࠩᅌ"))
	FRYfjTieQ6VsPadXp51EIJDwM29Z = dbo4vrnTM56I
	while FRYfjTieQ6VsPadXp51EIJDwM29Z:
		YR8cByH30A1Fk5hUMo = NJZUGpSmQLPBxuv3Mn(kh850jKbzmBwY,z8wTfYPiRQL(u"ࠬิั้ฮࠪᅍ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬᅎ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧใษษ้ฮࠦวๅฬหี฾อสࠨᅏ"),sdRqnego9PclrL4m2J(u"ࠨๆศ๎็อแࠡษ็ษ฾๊ว็ษอࠤ࠿ࠦࠠหสิ฽ࠥษ่ࠡษ่ืาࠦวๅสิ๊ฬ๋ฬࠨᅐ"),ccYfzwbEjm2qxCdhlSRWt)
		if YR8cByH30A1Fk5hUMo==Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠵Ꮦ"): HUjhFzcs3YmSoPABw9dJ2aL075rCD4 = NJZUGpSmQLPBxuv3Mn(kh850jKbzmBwY,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩ฼์ิฯࠧᅑ"),kh850jKbzmBwY,sdRqnego9PclrL4m2J(u"้ࠪอีรࠡษ็ฮอืูࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪᅒ"),TTQHx1fWsXizAbwYFO6dEP9vclK,z8wTfYPiRQL(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࠨᅓ"))
		elif YR8cByH30A1Fk5hUMo==ssYkHaML9z37bJ0StuEBXIqgiV(u"࠵Ꮧ"): pujLsDSbUtky8dzM2qGgAwflxen0()
		else: FRYfjTieQ6VsPadXp51EIJDwM29Z = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if j74j26QlgA8: EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def llwNKXmUsB5cpItOCzRMu0():
	DimCxMk2fNH4q19()
	vpX46m0rcGqw = l7tuXCf0oKV9FPOy6Hb.getSetting(u8iSx05wLfVyMNp1X3l(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡥࡤࡧ࡭࡫ࠧᅔ"))
	gfe2BNJ3kTF0Xx = {}
	gfe2BNJ3kTF0Xx[MBS1GrwQoUlsiIRfVDOHdA(u"࠭ࡁࡖࡖࡒࠫᅕ")] = taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧศๆๆหูࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้࠭ᅖ")
	gfe2BNJ3kTF0Xx[NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠨࡕࡗࡓࡕ࠭ᅗ")] = u8iSx05wLfVyMNp1X3l(u"ࠩส่่อิࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨᅘ")
	gfe2BNJ3kTF0Xx[z8wTfYPiRQL(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫᅙ")] = HfuZG0aphlYnVLOyAk93rj(u"่ࠫอิࠡฮาห่ࠥี๋ำࠣห้๋ฯ๊ࠢ࠱ࠤࠬᅚ")+str(JUH64BgvjCIG5DRcZTSd782fVqo/Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠻࠶Ꮨ"))+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬࠦฯใ์ๅอࠥ็โุࠩᅛ")
	Y53DxX6S179gEnhwcMPsrR = gfe2BNJ3kTF0Xx[vpX46m0rcGqw]
	gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(kh850jKbzmBwY,u8iSx05wLfVyMNp1X3l(u"࠭ใศึࠣࠫᅜ")+str(JUH64BgvjCIG5DRcZTSd782fVqo/XasF0WO7rDUHnEt8hAl9kLN(u"࠼࠰Ꮩ"))+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࠡัๅ๎็ฯࠧᅝ"),WlU7AtONpyj3(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧᅞ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩศ๎็อแࠡๅส้้࠭ᅟ"),Y53DxX6S179gEnhwcMPsrR,taD1d3bpqyfM4VNhK0P29GSZ(u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥอไไษืࠤฬ๊ะไ์ࠣห้ะไใษษ๎ࠥษๅࠡฬิ๎ิࠦล๋ไสๅࠥอไไษืࠤออไไษ่่ࠥษๅࠡฬิ๎ิࠦใศึࠣ฽๊ื็ࠡไุ๎ึࠦฬะษࠣรࠦ࠭ᅠ"))
	if gNiJnH3cvG1Dd9t==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠰Ꮪ"): CdqoSB7FAjwTfpQ = G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬᅡ")
	elif gNiJnH3cvG1Dd9t==G6GUCto502jZTLubYNnqMx8ywBah(u"࠲Ꮫ"): CdqoSB7FAjwTfpQ = BBOY8rvinVbFh(u"ࠬࡇࡕࡕࡑࠪᅢ")
	elif gNiJnH3cvG1Dd9t==A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠴Ꮬ"): CdqoSB7FAjwTfpQ = aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࡓࡕࡑࡓࠫᅣ")
	else: CdqoSB7FAjwTfpQ = kh850jKbzmBwY
	if CdqoSB7FAjwTfpQ:
		l7tuXCf0oKV9FPOy6Hb.setSetting(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡧࡦࡩࡨࡦࠩᅤ"),CdqoSB7FAjwTfpQ)
		oAbwc0VtBrdHzqR4SkjuWZ = gfe2BNJ3kTF0Xx[CdqoSB7FAjwTfpQ]
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,oAbwc0VtBrdHzqR4SkjuWZ)
	return
def U9AT4fPHVdyDtqloC3JL5():
	gfe2BNJ3kTF0Xx = {}
	gfe2BNJ3kTF0Xx[YoMw2J1Ljp(u"ࠨࡃࡘࡘࡔ࠭ᅥ")] = ZeV4vau9CjN(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥอไหๆๅหห๐๋ࠠ฻่่࠿ࠦࠧᅦ")
	gfe2BNJ3kTF0Xx[ZeV4vau9CjN(u"ࠪࡅࡘࡑࠧᅧ")] = wnVICNyfE3XZ0htUaDFAOgLo(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์ࡀࠠࠨᅨ")
	gfe2BNJ3kTF0Xx[wb1nC3e8AjRVU4ovsuPa(u"࡙ࠬࡔࡐࡒࠪᅩ")] = G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ำ๋ำไีࠥࡊࡎࡔ่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩᅪ")
	en6yOYxCIAFLb = l7tuXCf0oKV9FPOy6Hb.getSetting(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧᅫ"))
	vpX46m0rcGqw = l7tuXCf0oKV9FPOy6Hb.getSetting(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᅬ"))
	Y53DxX6S179gEnhwcMPsrR = gfe2BNJ3kTF0Xx[vpX46m0rcGqw]+en6yOYxCIAFLb
	gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(kh850jKbzmBwY,wb1nC3e8AjRVU4ovsuPa(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧᅭ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩᅮ"),YoMw2J1Ljp(u"ࠫส๐โศใࠣ็ฬ๋ไࠨᅯ"),Y53DxX6S179gEnhwcMPsrR,wb1nC3e8AjRVU4ovsuPa(u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩᅰ"))
	if gNiJnH3cvG1Dd9t==FkqI4Gm8wMvUVbgo(u"࠳Ꮭ"): CdqoSB7FAjwTfpQ = ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡁࡔࡍࠪᅱ")
	elif gNiJnH3cvG1Dd9t==YoMw2J1Ljp(u"࠵Ꮮ"): CdqoSB7FAjwTfpQ = ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡂࡗࡗࡓࠬᅲ")
	elif gNiJnH3cvG1Dd9t==qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠷Ꮯ"): CdqoSB7FAjwTfpQ = XasF0WO7rDUHnEt8hAl9kLN(u"ࠨࡕࡗࡓࡕ࠭ᅳ")
	if gNiJnH3cvG1Dd9t in [qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠰Ꮱ"),dQvxmFkyLOteNMWBJ2bDHV(u"࠷Ꮰ")]:
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(u8iSx05wLfVyMNp1X3l(u"ࠩࡦࡩࡳࡺࡥࡳࠩᅴ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪื๏ืแา࠼ࠣࠫᅵ")+Y3Ny5eLHdp.DNS_SERVERS[igM4DhpPzoX95Ysnar6Auj],Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ุࠫ๐ัโำ࠽ࠤࠬᅶ")+Y3Ny5eLHdp.DNS_SERVERS[nxUveizbLEAT2FBNy3],kh850jKbzmBwY,Urj6egiVyHA75ZK(u"ࠬษฮหษิࠤุ๐ัโำࠣࡈࡓ࡙ࠠศๆ่๊ฬูศࠡๆๆࠫᅷ"))
		if II7ErX2ocuU==wnVICNyfE3XZ0htUaDFAOgLo(u"࠲Ꮲ"): dHJIB9o4Nuh = Y3Ny5eLHdp.DNS_SERVERS[nxUveizbLEAT2FBNy3]
		else: dHJIB9o4Nuh = Y3Ny5eLHdp.DNS_SERVERS[igM4DhpPzoX95Ysnar6Auj]
	elif gNiJnH3cvG1Dd9t==HfuZG0aphlYnVLOyAk93rj(u"࠴Ꮳ"): dHJIB9o4Nuh = kh850jKbzmBwY
	else: CdqoSB7FAjwTfpQ = kh850jKbzmBwY
	if CdqoSB7FAjwTfpQ:
		l7tuXCf0oKV9FPOy6Hb.setSetting(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᅸ"),CdqoSB7FAjwTfpQ)
		l7tuXCf0oKV9FPOy6Hb.setSetting(ZeV4vau9CjN(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧᅹ"),dHJIB9o4Nuh)
		oAbwc0VtBrdHzqR4SkjuWZ = gfe2BNJ3kTF0Xx[CdqoSB7FAjwTfpQ]+dHJIB9o4Nuh
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,oAbwc0VtBrdHzqR4SkjuWZ)
	return
def YP7UH3pGoR46mI1afESzgOMD():
	vpX46m0rcGqw = l7tuXCf0oKV9FPOy6Hb.getSetting(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᅺ"))
	gfe2BNJ3kTF0Xx = {}
	gfe2BNJ3kTF0Xx[MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡄ࡙࡙ࡕࠧᅻ")] = sdRqnego9PclrL4m2J(u"ࠪห้ฮั้ๅึ๎ࠥอไหๆๅหห๐ࠠอษ๊ึ๊ࠥไฺ็็ࠫᅼ")
	gfe2BNJ3kTF0Xx[FkqI4Gm8wMvUVbgo(u"ࠫࡆ࡙ࡋࠨᅽ")] = YoMw2J1Ljp(u"ࠬอไษำ๋็ุ๐ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์࠭ᅾ")
	gfe2BNJ3kTF0Xx[ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡓࡕࡑࡓࠫᅿ")] = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧศๆหีํ้ำ๋่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩᆀ")
	Y53DxX6S179gEnhwcMPsrR = gfe2BNJ3kTF0Xx[vpX46m0rcGqw]
	gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(kh850jKbzmBwY,ZeV4vau9CjN(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭ᆁ"),FkqI4Gm8wMvUVbgo(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨᆂ"),z8wTfYPiRQL(u"ࠪษ๏่วโࠢๆห๊๊ࠧᆃ"),Y53DxX6S179gEnhwcMPsrR,HHthiRYs8T6IO3qUyX(u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧᆄ"))
	if gNiJnH3cvG1Dd9t==G6GUCto502jZTLubYNnqMx8ywBah(u"࠳Ꮴ"): CdqoSB7FAjwTfpQ = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡇࡓࡌࠩᆅ")
	elif gNiJnH3cvG1Dd9t==CMUXq6mPQV5rLsSBdWZJvA(u"࠵Ꮵ"): CdqoSB7FAjwTfpQ = wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ࡁࡖࡖࡒࠫᆆ")
	elif gNiJnH3cvG1Dd9t==wb1nC3e8AjRVU4ovsuPa(u"࠷Ꮶ"): CdqoSB7FAjwTfpQ = BBOY8rvinVbFh(u"ࠧࡔࡖࡒࡔࠬᆇ")
	else: CdqoSB7FAjwTfpQ = kh850jKbzmBwY
	if CdqoSB7FAjwTfpQ:
		l7tuXCf0oKV9FPOy6Hb.setSetting(ZeV4vau9CjN(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᆈ"),CdqoSB7FAjwTfpQ)
		oAbwc0VtBrdHzqR4SkjuWZ = gfe2BNJ3kTF0Xx[CdqoSB7FAjwTfpQ]
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,oAbwc0VtBrdHzqR4SkjuWZ)
	return
def SLhogQxDVJM2kBIwHaOyR4P():
	y01yMnXal5N4tYDAkhLwmKcQxe = l7tuXCf0oKV9FPOy6Hb.getSetting(Urj6egiVyHA75ZK(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡧࡵࡵࡱࡶࡧࡷࡧࡰࡦࡴࡶࠫᆉ"))
	if y01yMnXal5N4tYDAkhLwmKcQxe==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪࡗ࡙ࡕࡐࠨᆊ"): header = sdRqnego9PclrL4m2J(u"ࠫฯาว้ิࠣห้ำฬษࠢส่ศ๎ส้็สฮ๏้๊ࠡ็อ์็็ࠧᆋ")
	else: header = MBS1GrwQoUlsiIRfVDOHdA(u"ࠬะฬศ๊ีࠤฬ๊ออสࠣห้ษ่ห๊่หฯ๐ใ๋่ࠢๅ฾๊ࠧᆌ")
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,J6G8X3gO1MiKh027D(u"࠭ล๋ไสๅࠬᆍ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧหใ฼๎้࠭ᆎ"),header,YoMw2J1Ljp(u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฺษ้๎๋ࠥๆࠡ็ื็้ฯࠠศๆะะอࠦ࠮࠯๊ࠢิฬࠦวๅฯฯฬࠥ๐ๅ็฻ࠣห้ฮั็ษ่ะ๋ࠥๆࠡใอัࠥอไึใะหฯ่ࠦใำสลฯํวࠡ࠰࠱ࠤ์์วࠡฬึฮ฼๐ูࠡล้ࠤฯูๅฮࠢ็่อืๆศ็ฯࠤศ์๋ࠠไ๋้ࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ๊ำว้ๆฬࠤฯาว้ิ๋ࠣีอࠠศๆะะอࠦ࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสอษ๋ึࠥอไฮฮหࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ࠣรࠦࠧࠧᆏ"))
	if II7ErX2ocuU==-tzEjvOaZWU1A(u"࠷Ꮷ"): return
	elif II7ErX2ocuU:
		l7tuXCf0oKV9FPOy6Hb.setSetting(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡧࡵࡵࡱࡶࡧࡷࡧࡰࡦࡴࡶࠫᆐ"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡅ࡚࡚ࡏࠨᆑ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫฯ๋ࠠหใ฼๎้ࠦสอษ๋ึࠥอไฮฮหࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ࠪᆒ"))
	else:
		l7tuXCf0oKV9FPOy6Hb.setSetting(gNPRXprEAQJ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡣࡸࡸࡴࡹࡣࡳࡣࡳࡩࡷࡹࠧᆓ"),HfuZG0aphlYnVLOyAk93rj(u"࠭ࡓࡕࡑࡓࠫᆔ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,dQvxmFkyLOteNMWBJ2bDHV(u"ࠧห็ࠣษ๏่วโࠢอะฬ๎าࠡษ็ััฮࠠศๆฦ์ฯ๎ๅศฬํ็๏࠭ᆕ"))
	return
def vgCaByuwmiIA3RqD4Mz2kYxG0():
	y01yMnXal5N4tYDAkhLwmKcQxe = l7tuXCf0oKV9FPOy6Hb.getSetting(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨᆖ"))
	if y01yMnXal5N4tYDAkhLwmKcQxe==XasF0WO7rDUHnEt8hAl9kLN(u"ࠩࡖࡘࡔࡖࠧᆗ"): header = Urj6egiVyHA75ZK(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣฯ๎โโࠩᆘ")
	else: header = Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊็ูๅࠩᆙ")
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬห๊ใษไࠫᆚ"),ZeV4vau9CjN(u"࠭สโ฻ํ่ࠬᆛ"),header,gNPRXprEAQJ(u"ࠧใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ์อ้ࠥะอะ์ฮ๋ฬࠦร้ฬ๋้ฬะ๊ไ์สࠤอ฿ฯࠡ࠳࠹ࠤุอูส่๊ࠢࠥษ่ๅࠢฦืฯิฯศ็ࠣ࠲࠳่ࠦฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊๊ࠦลัํࠤส๊้ࠡฬะำ๏ั็ศࠢไ๎้ࠥไࠡ็ิอࠥ๐สๆࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤ࠳࠴้้ࠠำหࠥ๐ำษสࠣฬ฼ฬࠠโ์ࠣๅฯำࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠠภࠣࠤࠫᆜ"))
	if II7ErX2ocuU==-NZiEOAWrSX1u2gU05DR6TB8tm(u"࠱Ꮸ"): return
	elif II7ErX2ocuU:
		l7tuXCf0oKV9FPOy6Hb.setSetting(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨᆝ"),z8wTfYPiRQL(u"ࠩࡄ࡙࡙ࡕࠧᆞ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,CMUXq6mPQV5rLsSBdWZJvA(u"ࠪฮ๊ࠦสโ฻ํ่ࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬᆟ"))
	else:
		l7tuXCf0oKV9FPOy6Hb.setSetting(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᆠ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࡙ࠬࡔࡐࡒࠪᆡ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,YoMw2J1Ljp(u"࠭สๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨᆢ"))
	return
def vqubNPTH3cKWC4mJME2SZ1gIXs():
	Mus0aGQ3jH5ZLWkRKN = l7tuXCf0oKV9FPOy6Hb.getSetting(dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡹࡨࡦࡨࡧࡣࡩࡧࠪᆣ"))
	if Mus0aGQ3jH5ZLWkRKN==BBOY8rvinVbFh(u"ࠨࡕࡗࡓࡕ࠭ᆤ"): header = Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩฯ่อࠦวๅไ๋หห๋ࠠๆ่ࠣห้หๆหำ้ฮ๋ࠥส้ไไࠫᆥ")
	else: header = z8wTfYPiRQL(u"ࠪะ้ฮࠠศๆๅ์ฬฬๅࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦๅโ฻็ࠫᆦ")
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,ZeV4vau9CjN(u"ࠫส๐โศใࠪᆧ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬะแฺ์็ࠫᆨ"),header,sdRqnego9PclrL4m2J(u"࠭โ้ษษ้ࠥฮูืࠢส่๊๎วใ฻ࠣ์ำอีสࠢส่๊ำฬ้สฬࠤ๊๋ใ็ࠢอาื๐ๆ่ษࠣๅ๏ࠦวๅว้ฮึ์สࠡใํࠤุ๐ัโำสฮ๊ࠥวࠡ์๋ะิࠦแ๋้สࠤฺ๊ใๅหࠣััฮࠠ࠯࠰๋ࠣีํࠠศๆฺี๏่ษࠡฬึห฾ีࠠโ์ࠣๆึอมส๋ࠢหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆฯฯ์อฯࠠๅๅ้ࠤ๊์ࠠๆ๊ๅ฽ࠥฮฯ๋ๆ้ࠣฯ๎แา๋ࠢ฾๏ืࠠๆฯฯ์อࠦ࡜࡯࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠหใ฼๎้ࠦรๆࠢศ๎็อแࠡฮ็ฬࠥอไใ๊สส๊ࠦๅ็ࠢส่ส์สา่อࠤฤࠧࠡࠨᆩ"))
	if II7ErX2ocuU==-YoMw2J1Ljp(u"࠲Ꮹ"): return
	elif II7ErX2ocuU:
		l7tuXCf0oKV9FPOy6Hb.setSetting(YoMw2J1Ljp(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡹࡨࡦࡨࡧࡣࡩࡧࠪᆪ"),sdRqnego9PclrL4m2J(u"ࠨࡃࡘࡘࡔ࠭ᆫ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,WlU7AtONpyj3(u"ࠩอ้ࠥะแฺ์็ࠤั๊ศࠡษ็ๆํอฦๆ่๊ࠢࠥอไ้์หࠫᆬ"))
	else:
		l7tuXCf0oKV9FPOy6Hb.setSetting(XasF0WO7rDUHnEt8hAl9kLN(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᆭ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡘ࡚ࡏࡑࠩᆮ"))
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,z8wTfYPiRQL(u"ࠬะๅࠡวํๆฬ็ࠠอๆหࠤฬ๊โ้ษษ้๋ࠥๆࠡษ็์๏ฮࠧᆯ"))
	return
def RzuUtV3OZ6P(fRJYhnSKHsZ7MqFwmiVz):
	if fRJYhnSKHsZ7MqFwmiVz!=kh850jKbzmBwY:
		fRJYhnSKHsZ7MqFwmiVz = q59OjVhmPrB4a8bLFokl0xEAJnZX1s(fRJYhnSKHsZ7MqFwmiVz)
		fRJYhnSKHsZ7MqFwmiVz = fRJYhnSKHsZ7MqFwmiVz.decode(NVbhZ0DTpOkCA).encode(NVbhZ0DTpOkCA)
		sUDiK1AvMuwP6aY = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠳࠳࠵࠵࠹Ꮺ")
		lK8uaL1snZ7cXFwGe = SSDm5G4FUAzu26LbKqpvV79d.Window(sUDiK1AvMuwP6aY)
		lK8uaL1snZ7cXFwGe.getControl(NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠵࠶Ꮻ")).setLabel(fRJYhnSKHsZ7MqFwmiVz)
	return
rXWiUAx4k8aBDt = [
			 J6G8X3gO1MiKh027D(u"ࠨࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴ࠥ࡯ࡳࠡࡰࡲࡸࠥࡩࡵࡳࡴࡨࡲࡹࡲࡹࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠦᆰ")
			,u8iSx05wLfVyMNp1X3l(u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡍࡢ࡮࡬ࡧ࡮ࡵࡵࡴࠢࡶࡧࡷ࡯ࡰࡵࡵࠪᆱ")
			,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡒ࡙ࡖࠥࡏࡐࡕࡘࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡇࡱ࡯ࡥ࡯ࡶࠪᆲ")
			,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰ࡚ࠣ࡮ࡪࡥࡰࠢࡌࡲ࡫ࡵࠠࡌࡧࡼࠫᆳ")
			,YoMw2J1Ljp(u"ࠪࡸ࡭࡯ࡳࠡࡪࡤࡷ࡭ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡧࡸ࡯࡬ࡧࡱࠫᆴ")
			,ZeV4vau9CjN(u"ࠫࡺࡹࡥࡴࠢࡳࡰࡦ࡯࡮ࠡࡊࡗࡘࡕࠦࡦࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠭ᆵ")
			,wb1nC3e8AjRVU4ovsuPa(u"ࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡶࡵࡤ࡫ࡪ࠴ࡨࡵ࡯࡯ࠫᆶ")+wb1nC3e8AjRVU4ovsuPa(u"࠭ࠣࠨᆷ")+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡴࡵ࡯࠱ࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠭ᆸ")
			,HfuZG0aphlYnVLOyAk93rj(u"ࠨࡋࡱࡷࡪࡩࡵࡳࡧࡕࡩࡶࡻࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩ࠯ࠫᆹ")
			,HfuZG0aphlYnVLOyAk93rj(u"ࠩࡈࡶࡷࡵࡲࠡࡩࡨࡸࡹ࡯࡮ࡨࠢࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆ࠲ࡃࡲࡵࡤࡦࡧࡀ࠴ࠫࡺࡥࡹࡶࡷࡁࠬᆺ")
			,dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡻࡦࡸ࡮ࡪࡰࡪࡷ࠳ࡽࡡࡳࡰࠫࠫᆻ")
			,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࡣࡤ࡞࡟ࡠࠪᆼ")
			,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪᆽ")
			,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭࡬ࡢࡴࡪࡩࠥࡧࡵࡥ࡫ࡲࠤࡸࡿ࡮ࡤࠢࡨࡶࡷࡵࡲ࠻ࠩᆾ")
			,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡪࡰࡩࡳ࠿ࠦࡍࡦࡦ࡬ࡥࡨࡵࡤࡦࡥࠣࡨࡪࡩ࡯ࡥࡧࡵ࠾ࠬᆿ")
			]
def vboW0jYxKGhpz(LpUBDvCibaX6hrA9I):
	if XasF0WO7rDUHnEt8hAl9kLN(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ᇀ") in LpUBDvCibaX6hrA9I and SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᇁ") in LpUBDvCibaX6hrA9I: return dbo4vrnTM56I
	for fRJYhnSKHsZ7MqFwmiVz in rXWiUAx4k8aBDt:
		if fRJYhnSKHsZ7MqFwmiVz in LpUBDvCibaX6hrA9I: return dbo4vrnTM56I
	return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
def Ld8EYJIFzMgj5oWm2ha1f973(data):
	HmUvOTqLwbQKfsuZlJ = ssYkHaML9z37bJ0StuEBXIqgiV(u"࠼Ꮽ") if eOQJrvLAZC else qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠵࠺Ꮼ")
	data = data.replace(XasF0WO7rDUHnEt8hAl9kLN(u"࠹࠰Ꮾ")*EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,HmUvOTqLwbQKfsuZlJ*EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	data = data.replace(WlU7AtONpyj3(u"ࠪࠤࡁ࡭ࡥ࡯ࡧࡵࡥࡱࡄ࠺ࠡࠩᇂ"),z8wTfYPiRQL(u"ࠫ࠿ࠦࠧᇃ"))
	hhUDZA3piIJyMsxfbgGdWO = kh850jKbzmBwY
	for LpUBDvCibaX6hrA9I in data.splitlines():
		V4N1lDopv9Amc0SXJ = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠲࠮ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᇄ"),LpUBDvCibaX6hrA9I,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if V4N1lDopv9Amc0SXJ: LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(V4N1lDopv9Amc0SXJ[nxUveizbLEAT2FBNy3],kh850jKbzmBwY)
		hhUDZA3piIJyMsxfbgGdWO += URBvawyLXfQiS2NI34HDk+LpUBDvCibaX6hrA9I
	return hhUDZA3piIJyMsxfbgGdWO
def sN2iR3DaeMXhJjAZSQIw0FgyUfuc(WNqmPu1A90ai3tpFGZTM):
	if aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࡏࡍࡆࠪᇅ") in WNqmPu1A90ai3tpFGZTM:
		RHocNPKy5QSM8VwD = odLPpDhSRbMNTFQH340IJO5UBueK
		header = u8iSx05wLfVyMNp1X3l(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไใัํ้ࠥลࠧᇆ")
	else:
		RHocNPKy5QSM8VwD = GrvDPu4WyAdmnf9cNRtzV3h7K
		header = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅฯส่๏ࠦฟࠨᇇ")
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,header,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩึะ้ࠦวๅลั฻ฬว๋ࠠฯอ์๏ࠦรุ๋สࠤ฾๊้ࠡีฯ่ࠥอไศีอาิอๅࠡ࠰ࠣ์ฬ๊วฬ่ํ๊ࠥ฼ั้ำํอ๊ࠥๅฺำไอ้๊ࠥโࠢะำะะࠠศๆุ่่๊ษ๊่ࠡหࠥํ่ࠡษ็้่อๆࠡษ็ิ๏ࠦำษสࠣัิ๎หࠡษ็ู้้ไสࠢ࠱ࠤ่๎ฯ๋ࠢํัฯ็ุࠡสึะ้๐ๆࠡ࠰ࠣห้ษ่ๅ๊ࠢ์ࠥอไิฮ็ࠤฬ๊อศๆํࠤํ็๊่่ࠢ฽้๎ๅศฬࠣฮอีรࠡ็้ิࠥฮฯศ์ฬࠤฬ๊สี฼ํ่ࠥอไฮษ็๎๊ࠥศา่ส้ัࠦใ้ัํࠤํอไ๊ࠢส่ว์ࠠ࠯ࠢฦ้ฬࠦวๅีฯ่ࠥอไใัํ้ࠥ็็้ࠢสุ่าไࠡษ็ืฬฮโࠡษ็ิ๏ࠦสๆࠢฯ้฾ํࠠๆ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡไห่ࠥศฮาࠢศ฻ๆอมࠡๆ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬᇈ"))
	if II7ErX2ocuU!=x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠱Ꮿ"): return
	DIOXK6gYEhS4M2inmQCjl87WRBf3,ZqUKbox5pPuJ79ng32cX6IkvL = [],qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠱Ᏸ")
	size,count = jURErmLv8M4PZ9Ky6FH(RHocNPKy5QSM8VwD)
	file = open(RHocNPKy5QSM8VwD,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠪࡶࡧ࠭ᇉ"))
	if size>HHthiRYs8T6IO3qUyX(u"࠴࠴࠵࠸࠰࠱Ᏺ"): file.seek(-tzEjvOaZWU1A(u"࠳࠳࠴࠶࠶࠰Ᏹ"),YdDkIjFhgzuboBKca70ERt.SEEK_END)
	data = file.read()
	file.close()
	if eOQJrvLAZC: data = data.decode(NVbhZ0DTpOkCA)
	data = Ld8EYJIFzMgj5oWm2ha1f973(data)
	ZCgD0e7dMi5kRwnFujf8xHEaKO = data.split(URBvawyLXfQiS2NI34HDk)
	for LpUBDvCibaX6hrA9I in reversed(ZCgD0e7dMi5kRwnFujf8xHEaKO):
		a8o6z1ekiL0fq = vboW0jYxKGhpz(LpUBDvCibaX6hrA9I)
		if a8o6z1ekiL0fq: continue
		LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡤ࠭ᇊ"),RlMpu0hP8YmzZovkVXOs1G+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᇋ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(z8wTfYPiRQL(u"࠭ࡅࡓࡔࡒࡖ࠿࠭ᇌ"),BBOY8rvinVbFh(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ࠪᇍ")+MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡇࡕࡖࡔࡘ࠺ࠨᇎ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		h8hdAPQIekx2 = kh850jKbzmBwY
		d2NrpsYyekujChFR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩᇏ"),LpUBDvCibaX6hrA9I,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if d2NrpsYyekujChFR:
			LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][nxUveizbLEAT2FBNy3],d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj]).replace(d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][s0sB2Xyp9uYU5N3fxzKoLW8],kh850jKbzmBwY)
			h8hdAPQIekx2 = d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj]
		else:
			d2NrpsYyekujChFR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪᇐ"),LpUBDvCibaX6hrA9I,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if d2NrpsYyekujChFR:
				LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj],kh850jKbzmBwY)
				h8hdAPQIekx2 = d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][nxUveizbLEAT2FBNy3]
		if h8hdAPQIekx2: LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(h8hdAPQIekx2,HHFAVK8SwRUqBLuTfdeJ9nbD+h8hdAPQIekx2+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		DIOXK6gYEhS4M2inmQCjl87WRBf3.append(LpUBDvCibaX6hrA9I)
		if len(str(DIOXK6gYEhS4M2inmQCjl87WRBf3))>SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠹࠵࠷࠰࠱Ᏻ"): break
	DIOXK6gYEhS4M2inmQCjl87WRBf3 = reversed(DIOXK6gYEhS4M2inmQCjl87WRBf3)
	wwObSFLeXMDPR4 = URBvawyLXfQiS2NI34HDk.join(DIOXK6gYEhS4M2inmQCjl87WRBf3)
	KKHpNde5TOmYqjIygtlwhf7W2sr(dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡱ࡫ࡦࡵࠩᇑ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩᇒ"),wwObSFLeXMDPR4,tzEjvOaZWU1A(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩᇓ"))
	return
def p42CbDl1FRycsnL8NzPaXU():
	O2lxL4gNW3pZcKiewdQPu = open(tTxQDmGMWN7Lf9vRuwjbKOS,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡳࡤࠪᇔ")).read()
	if eOQJrvLAZC: O2lxL4gNW3pZcKiewdQPu = O2lxL4gNW3pZcKiewdQPu.decode(NVbhZ0DTpOkCA)
	O2lxL4gNW3pZcKiewdQPu = O2lxL4gNW3pZcKiewdQPu.replace(MBS1GrwQoUlsiIRfVDOHdA(u"ࠨ࡞ࡷࠫᇕ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࠣࠤࠥࠦࠠࠡࠢࠣࠫᇖ"))
	p9XQ5ELjTtvSUyCZMzuPfq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(XasF0WO7rDUHnEt8hAl9kLN(u"ࠪࠬࡻࡢࡤ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠࠫᇗ"),O2lxL4gNW3pZcKiewdQPu,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for LpUBDvCibaX6hrA9I in p9XQ5ELjTtvSUyCZMzuPfq:
		O2lxL4gNW3pZcKiewdQPu = O2lxL4gNW3pZcKiewdQPu.replace(LpUBDvCibaX6hrA9I,RlMpu0hP8YmzZovkVXOs1G+LpUBDvCibaX6hrA9I+wVvqN8LZCJW5ryAb1EHRPFkQ0)
	Z7XaWzvgUpr4YhSjTyfPk(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫฬ๊ส฻์ํีฬะࠠศๆฦา๏ืษࠡใํࠤฬ๊ศาษ่ะࠬᇘ"),O2lxL4gNW3pZcKiewdQPu)
	return
def S6SjfXlrsvqp():
	i2xKJuM5eANb = HfuZG0aphlYnVLOyAk93rj(u"ࠬฮูืࠢส่ศุัศำࠣ฽้๏ࠠศๆิ๎๊๎สࠡๅ๋๊ฯื่ๅࠢอ์ๆืࠠฦ็ๆห๋๐ษࠡฬๅำ๏๋้ࠠฬฦา๏ืࠠศๆไ๎ิ๐่๊๊ࠡิ์ࠦวๅลีีฬื่ࠠ์ࠣห้ษำ่็ࠣ์ฬ๊ราไสู้๋ࠥࠡส฼ฺࠥ๎ใศๆอห้๐ࠧᇙ")
	ccYfzwbEjm2qxCdhlSRWt = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ไหไา๎๊ࠦวๅใํำ๏๎ࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์่๎๋่ࠦๅฬฦา๏ื็ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํืฬืࠠ࠯ࠢฦ้ฬูࠦะหࠣหุํๅࠡ็อฮฬ๊๊สࠢไ๋ีํࠠหไ๋้ࠥฮสฮำํ็ࠥอไโ์า๎ํࠦศ้ไอࠤฬ้ศา่๊ࠢࠥ๎โหࠢสุ่ํๅࠡษ็์ฬำฯࠡ࠰ࠣว๊อࠠศๆึ๋๊ࠦวๅล฼่๎่ࠦศๆฦืๆ๊ࠠโ้๋ࠤ๏ำัไࠢส่ๆ๐ฯ๋๊ࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬว้ࠠๆๆ๊ࠥฮโโิฬࠤ่ฮ๊าหࠪᇚ")
	TTQHx1fWsXizAbwYFO6dEP9vclK = MBS1GrwQoUlsiIRfVDOHdA(u"ࠧฤ็สࠤฬ๊ราไส้ࠥ็็๋ࠢอืฯิฯๆࠢ็่ฯ่ฯ๋็ࠣ์ฬ๊สฤะํีࠥ๎ไไ่ࠣฬ๊่ฯศำࠣ฽ิีࠠศๆฮ์ฬ์๊๊ࠡส่ิ่ววไࠣ࠲๋ࠥหๅษࠣี็๋ࠠ࠶࠶࠷ࠤฯ฿ๆ๋ࠢ࠸ࠤิ่ววไࠣ์ࠥ࠺࠴ࠡอส๊๏ฯࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤอำำษࠢสืฯิฯศ็ๆࠤ้๊ำ่็ࠣห้๐ๅ๋่ࠣวํࠦำ่็ࠣห้๐ำศำࠪᇛ")
	gfe2BNJ3kTF0Xx = i2xKJuM5eANb+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨ࠼ࠣࠫᇜ")+ccYfzwbEjm2qxCdhlSRWt+YoMw2J1Ljp(u"ࠩࠣ࠲ࠥ࠭ᇝ")+TTQHx1fWsXizAbwYFO6dEP9vclK
	KKHpNde5TOmYqjIygtlwhf7W2sr(ZeV4vau9CjN(u"ࠪࡧࡪࡴࡴࡦࡴࠪᇞ"),fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx,u8iSx05wLfVyMNp1X3l(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᇟ"))
	return
def pPI9ojeNDixmAdQcVz(type,gfe2BNJ3kTF0Xx,showDialogs=dbo4vrnTM56I,url=kh850jKbzmBwY,iEKg4FWeD9vR21wMJZYyP0dp5mojcI=kh850jKbzmBwY,fRJYhnSKHsZ7MqFwmiVz=kh850jKbzmBwY,SMs8JiXrwPnYt6=kh850jKbzmBwY):
	N9VcgHoAZUe4l3xYW0rS7vsEtXK = dbo4vrnTM56I
	if not Y3Ny5eLHdp.OdwIhsZak4uy3p6N1r8UMngT:
		if showDialogs:
			k2Mo8O6Ljigz5qGC = (ZeV4vau9CjN(u"ࠬอไิูิ࠾ࠬᇠ") in gfe2BNJ3kTF0Xx and sdRqnego9PclrL4m2J(u"࠭วๅ็ๆห๋ࡀࠧᇡ") in gfe2BNJ3kTF0Xx and BBOY8rvinVbFh(u"ࠧศๆ่่ๆࡀࠧᇢ") in gfe2BNJ3kTF0Xx and XasF0WO7rDUHnEt8hAl9kLN(u"ࠨษ็า฼ษࠧᇣ") in gfe2BNJ3kTF0Xx and MBS1GrwQoUlsiIRfVDOHdA(u"ࠩส่๊฻ฯา࠼ࠪᇤ") in gfe2BNJ3kTF0Xx)
			if not k2Mo8O6Ljigz5qGC: N9VcgHoAZUe4l3xYW0rS7vsEtXK = aa48i0SKpcGbWFBYLtCre(ZeV4vau9CjN(u"ࠪࡧࡪࡴࡴࡦࡴࠪᇥ"),kh850jKbzmBwY,kh850jKbzmBwY,HHthiRYs8T6IO3qUyX(u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨᇦ"),gfe2BNJ3kTF0Xx.replace(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡢ࡜࡯ࠩᇧ"),URBvawyLXfQiS2NI34HDk))
	elif showDialogs:
		gfe2BNJ3kTF0Xx = z8wTfYPiRQL(u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭ᇨ")
		VYOlQ7r32UaiNPTkwLK = aa48i0SKpcGbWFBYLtCre(CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࡤࡧࡱࡸࡪࡸࠧᇩ"),kh850jKbzmBwY,kh850jKbzmBwY,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨᇪ")+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩࠣࠤ࠶࠵࠵ࠨᇫ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨᇬ"))
		zXwR2JpdZmEiBst9HhU61xDKl = aa48i0SKpcGbWFBYLtCre(Urj6egiVyHA75ZK(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇭ"),kh850jKbzmBwY,kh850jKbzmBwY,tzEjvOaZWU1A(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬᇮ")+WlU7AtONpyj3(u"࠭ࠠࠡ࠴࠲࠹ࠬᇯ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬᇰ"))
		BG7wRiEtSfY = aa48i0SKpcGbWFBYLtCre(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇱ"),kh850jKbzmBwY,kh850jKbzmBwY,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩᇲ")+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪࠤࠥ࠹࠯࠶ࠩᇳ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩᇴ"))
		Do5iyV2hKcO3B = aa48i0SKpcGbWFBYLtCre(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᇵ"),kh850jKbzmBwY,kh850jKbzmBwY,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ᇶ")+tzEjvOaZWU1A(u"ࠧࠡࠢ࠷࠳࠺࠭ᇷ"),J6G8X3gO1MiKh027D(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ᇸ"))
		N9VcgHoAZUe4l3xYW0rS7vsEtXK = aa48i0SKpcGbWFBYLtCre(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡦࡩࡳࡺࡥࡳࠩᇹ"),kh850jKbzmBwY,kh850jKbzmBwY,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪᇺ")+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࠥࠦ࠵࠰࠷ࠪᇻ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪᇼ"))
	VwPKg4qUmChSbR2Bj = t5tNrlFIL7Skg(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	ZIQjOMRJPCo5nd = HHthiRYs8T6IO3qUyX(u"࠭ࡁࡗ࠼ࠣࠫᇽ")+VwPKg4qUmChSbR2Bj+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧ࠮ࠩᇾ")+type
	gTf1RiSwUj8b923IVo5hBLxqdMEck = dbo4vrnTM56I if BBOY8rvinVbFh(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫᇿ") in fRJYhnSKHsZ7MqFwmiVz else wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if not N9VcgHoAZUe4l3xYW0rS7vsEtXK:
		if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠥฮๆศรࠣ฽้๏ุࠠๆห็ࠬሀ"))
		return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	z0IVWYwOfMkZs2lUPoDgLXdtbJ4hQx = ppNwDFByU1dZn5ca.getInfoLabel(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩሁ"))
	gfe2BNJ3kTF0Xx += oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࠥࡢ࡜࡯࡞࡟ࡲࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡢ࡜࡯ࡃࡧࡨࡴࡴࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪሂ")+YYTi6EgrdkyOUSbW+MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࠦ࠺࡝࡞ࡱࠫሃ")
	gfe2BNJ3kTF0Xx += tzEjvOaZWU1A(u"࠭ࡅ࡮ࡣ࡬ࡰ࡙ࠥࡥ࡯ࡦࡨࡶ࠿ࠦࠧሄ")+VwPKg4qUmChSbR2Bj+sdRqnego9PclrL4m2J(u"ࠧࠡ࠼࡟ࡠࡳࡑ࡯ࡥ࡫࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭ህ")+Sv0hKklQYynRBda+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࠢ࠽ࡠࡡࡴࠧሆ")
	gfe2BNJ3kTF0Xx += J6G8X3gO1MiKh027D(u"ࠩࡎࡳࡩ࡯ࠠࡏࡣࡰࡩ࠿ࠦࠧሇ")+z0IVWYwOfMkZs2lUPoDgLXdtbJ4hQx
	m5H0Akr6BTjSKOeDYfpZN4XlgIh = kCqLgAuyJnZKc5MHDvtXz3UEQs()
	m5H0Akr6BTjSKOeDYfpZN4XlgIh = m5H0Akr6BTjSKOeDYfpZN4XlgIh.replace(u8iSx05wLfVyMNp1X3l(u"ࠪ࠰࠱࠭ለ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫ࠱࠭ሉ"))
	m5H0Akr6BTjSKOeDYfpZN4XlgIh = ioZ083zxYk(m5H0Akr6BTjSKOeDYfpZN4XlgIh)
	if m5H0Akr6BTjSKOeDYfpZN4XlgIh: gfe2BNJ3kTF0Xx += wb1nC3e8AjRVU4ovsuPa(u"ࠬࠦ࠺࡝࡞ࡱࡐࡴࡩࡡࡵ࡫ࡲࡲ࠿ࠦࠧሊ")+m5H0Akr6BTjSKOeDYfpZN4XlgIh
	if url: gfe2BNJ3kTF0Xx += tzEjvOaZWU1A(u"࠭ࠠ࠻࡞࡟ࡲ࡚ࡘࡌ࠻ࠢࠪላ")+url
	if iEKg4FWeD9vR21wMJZYyP0dp5mojcI: gfe2BNJ3kTF0Xx += gNPRXprEAQJ(u"ࠧࠡ࠼࡟ࡠࡳ࡙࡯ࡶࡴࡦࡩ࠿ࠦࠧሌ")+iEKg4FWeD9vR21wMJZYyP0dp5mojcI
	gfe2BNJ3kTF0Xx += J6G8X3gO1MiKh027D(u"ࠨࠢ࠽ࡠࡡࡴࠧል")
	if showDialogs: o4n5ehzyjHTWdL8(J6G8X3gO1MiKh027D(u"ࠩฯหึ๐ࠠศๆศีุอไࠨሎ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪห้ืฬศรࠣห้อๆหฺสีࠬሏ"))
	if gTf1RiSwUj8b923IVo5hBLxqdMEck:
		if aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫሐ") in fRJYhnSKHsZ7MqFwmiVz: uOCiDBUpSn = odLPpDhSRbMNTFQH340IJO5UBueK
		else: uOCiDBUpSn = GrvDPu4WyAdmnf9cNRtzV3h7K
		if not YdDkIjFhgzuboBKca70ERt.path.exists(uOCiDBUpSn):
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,MBS1GrwQoUlsiIRfVDOHdA(u"ูࠬฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ฻์ิࠤ๊๎ฬ้ัࠪሑ"))
			return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭࠮࡝ࡶࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡵࡨࡲࡩࠦࡴࡩࡧࠣࡰࡴ࡭ࡦࡪ࡮ࡨࠫሒ"))
		DIOXK6gYEhS4M2inmQCjl87WRBf3,ZqUKbox5pPuJ79ng32cX6IkvL = [],tzEjvOaZWU1A(u"࠵Ᏼ")
		file = open(uOCiDBUpSn,sdRqnego9PclrL4m2J(u"ࠧࡳࡤࠪሓ"))
		size,count = jURErmLv8M4PZ9Ky6FH(uOCiDBUpSn)
		if size>qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠹࠰࠲࠲࠳࠴Ᏽ"): file.seek(-qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠹࠰࠲࠲࠳࠴Ᏽ"),YdDkIjFhgzuboBKca70ERt.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(NVbhZ0DTpOkCA)
		data = Ld8EYJIFzMgj5oWm2ha1f973(data)
		ZCgD0e7dMi5kRwnFujf8xHEaKO = data.splitlines()
		for LpUBDvCibaX6hrA9I in reversed(ZCgD0e7dMi5kRwnFujf8xHEaKO):
			a8o6z1ekiL0fq = vboW0jYxKGhpz(LpUBDvCibaX6hrA9I)
			if a8o6z1ekiL0fq: continue
			d2NrpsYyekujChFR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨሔ"),LpUBDvCibaX6hrA9I,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if d2NrpsYyekujChFR:
				LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][nxUveizbLEAT2FBNy3],d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj]).replace(d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][s0sB2Xyp9uYU5N3fxzKoLW8],kh850jKbzmBwY)
			else:
				d2NrpsYyekujChFR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩሕ"),LpUBDvCibaX6hrA9I,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if d2NrpsYyekujChFR: LpUBDvCibaX6hrA9I = LpUBDvCibaX6hrA9I.replace(d2NrpsYyekujChFR[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj],kh850jKbzmBwY)
			DIOXK6gYEhS4M2inmQCjl87WRBf3.append(LpUBDvCibaX6hrA9I)
			if len(str(DIOXK6gYEhS4M2inmQCjl87WRBf3))>FkqI4Gm8wMvUVbgo(u"࠲࠶࠳࠳࠴࠵᏶"): break
		DIOXK6gYEhS4M2inmQCjl87WRBf3 = reversed(DIOXK6gYEhS4M2inmQCjl87WRBf3)
		wwObSFLeXMDPR4 = HfuZG0aphlYnVLOyAk93rj(u"ࠪࡠࡷࡢ࡮ࠨሖ").join(DIOXK6gYEhS4M2inmQCjl87WRBf3)
	elif SMs8JiXrwPnYt6: wwObSFLeXMDPR4 = SMs8JiXrwPnYt6
	else: wwObSFLeXMDPR4 = kh850jKbzmBwY
	url = Y3Ny5eLHdp.SITESURLS[ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫሗ")][s0sB2Xyp9uYU5N3fxzKoLW8]
	K83xkHbNteiq7RnvgFSL0foXO92EmW = {A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭መ"):ZIQjOMRJPCo5nd,gNPRXprEAQJ(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧሙ"):gfe2BNJ3kTF0Xx,u8iSx05wLfVyMNp1X3l(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨሚ"):wwObSFLeXMDPR4}
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨࡒࡒࡗ࡙࠭ማ"),url,K83xkHbNteiq7RnvgFSL0foXO92EmW,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡋࡎࡅࡡࡈࡑࡆࡏࡌ࠮࠳ࡶࡸࠬሜ"))
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡷࡪࡴࡤࡠࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠫም") in uP1m46pAK5a3UgdqvBz9rnL: jVhaOJ9utFmLGZpHceKNMlE = dbo4vrnTM56I
	else: jVhaOJ9utFmLGZpHceKNMlE = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if showDialogs:
		if jVhaOJ9utFmLGZpHceKNMlE:
			o4n5ehzyjHTWdL8(tzEjvOaZWU1A(u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧሞ"),z8wTfYPiRQL(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ሟ"))
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠬሠ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧห็ࠣษึูวๅࠢส่ึูวๅหࠣฬ๋าวฮࠩሡ"))
		else:
			o4n5ehzyjHTWdL8(Urj6egiVyHA75ZK(u"ࠨๆ็วุ็ࠠโึ็ࠤฬ๊ลาีส่ࠬሢ"),FkqI4Gm8wMvUVbgo(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪሣ"))
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨሤ"))
	return jVhaOJ9utFmLGZpHceKNMlE
def L3rIYOnpQJX2ymF4DPaHcMk():
	i2xKJuM5eANb = tzEjvOaZWU1A(u"ࠫࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡺࡲࡢࡰࡶࡰࡦࡺࡥࠡ࡯ࡨࡲࡺࠦࡩࡵࡧࡰࡷࠥࡺ࡯ࠡࡣࠣࡰࡦࡴࡧࡶࡣࡪࡩࠥࡵࡴࡩࡧࡵࠤࡹ࡮ࡡ࡯ࠢࡄࡶࡦࡨࡩࡤࠢ࠱࠲ࠥࡕࡲࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡳࡩࡱࡺࠤࡆࡸࡡࡣ࡫ࡦࠤࡱ࡫ࡴࡵࡧࡵࡷࠥࡧ࡮ࡥࠢࡷࡩࡽࡺࠠࡀࠣࠪሥ")
	ccYfzwbEjm2qxCdhlSRWt = z8wTfYPiRQL(u"ࠬํไࠡฬิ๎ิࠦสาฮ่อ่่ࠥศศ่ࠤฬ๊ศา่ส้ัࠦลๅ๋่ࠣ฿ฯࠠฤะิํࠥเ๊าࠢส่฾ืศ๋หࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦฺ๊หึࠦวๅละีๆ่ࠦศๆๆฮฬฮษࠡษ็฽ึฮ๊สࠢยࠥࠬሦ")
	choice = NJZUGpSmQLPBxuv3Mn(YoMw2J1Ljp(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ሧ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧฯำ๋ะࠥࡋࡸࡪࡶࠪረ"),HfuZG0aphlYnVLOyAk93rj(u"ࠨࡖࡵࡥࡳࡹ࡬ࡢࡶࡨࠤฯืฬๆหࠪሩ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩ฼ีอ๐ࠠࡂࡴࡤࡦ࡮ࡩࠧሪ"),fWM6PeOrvciG0RQpIKzltojDqaYs,i2xKJuM5eANb+HHthiRYs8T6IO3qUyX(u"ࠪࡠࡳࡢ࡮ࠨራ")+ccYfzwbEjm2qxCdhlSRWt)
	if choice in [-wnVICNyfE3XZ0htUaDFAOgLo(u"࠲᏷"),NZiEOAWrSX1u2gU05DR6TB8tm(u"࠲ᏸ")]: return
	elif choice==z8wTfYPiRQL(u"࠴ᏹ"):
		import UlEOghLYat
		UlEOghLYat.JJbTHaEOlBhLGsXI9Rwd0ickQ8tzj()
		return
	E8S5nYtIQZeKVv6lLoF79BJHhk = dbo4vrnTM56I
	while E8S5nYtIQZeKVv6lLoF79BJHhk:
		E8S5nYtIQZeKVv6lLoF79BJHhk = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		message = WlU7AtONpyj3(u"ࠫสึวࠡ฻้ำ่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡว็ํࠥࠨลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠦࠥัๅࠡ฼ํีࠥอไฯูࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࠰࠱ࠤสึวࠡๆ่ࠤฯาฯࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠโ฼ํีࠥอไอๆาࠤส๊้ࠡลํࠤั๊ฯࠡอส๊๏ࠦแ๋้ࠣห้ิืࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥัๅࠡส฼ำ์อࠠ฻์ิࠤฬ๊ฮุࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࡝ࡰࠣษีอࠠๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡๆสࠤฯ฾็าࠢ็็ࠥ࠴࠮ࠡษำ๋อࠦลๅ๋ࠣࠦส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠤࠣ࠲࠳ࠦหๆࠢ฽๎ึࠦลฺัสำฬะࠠศๆ่์็฿ࠠศๆฯ฾ึอแ๋ࠢ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦแหฯࠣࠦส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠤࠣรࠦ࠭ሬ")
		choice = NJZUGpSmQLPBxuv3Mn(ZeV4vau9CjN(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬር"),XasF0WO7rDUHnEt8hAl9kLN(u"࠭ࡅࡹ࡫ࡷࠤำื่อࠩሮ"),tzEjvOaZWU1A(u"࡚ࠧࡧࡶࠤ๋฿ๅࠨሯ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠢศ๊ั๊๊ำ์ࠪሰ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩ฼ำุ๊่๊ࠦิࠤฬ๊รฮำไࠤํอไไฬสฬฮࠦวๅ฻ิฬ๏ฯࠧሱ"),message,profile=HfuZG0aphlYnVLOyAk93rj(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨሲ"))
		if choice==dQvxmFkyLOteNMWBJ2bDHV(u"࠶ᏺ"):
			message = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡ࡮ࡨࡸࡹ࡫ࡲࡴࠢࡷ࡬ࡪࡴࠠࡰࡲࡨࡲࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠢࡷࡳࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࠮࠯ࠢࡌࡪࠥࡿ࡯ࡶࠢࡦࡥࡳࡢࠧࡵࠢࡩ࡭ࡳࡪࠠࠣࡃࡵ࡭ࡦࡲࠢࠡࡨࡲࡲࡹࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡵ࡮࡭ࡳࠦࡴࡰࠢࡤࡲࡾࠦ࡯ࡵࡪࡨࡶࠥࡹ࡫ࡪࡰࠣࡸ࡭ࡧࡴࠡࡪࡤࡺࡪࠦ࡜ࠣࡃࡵ࡭ࡦࡲ࡜ࠣࠢࡩࡳࡳࡺࠠ࠯࠰ࠣࡅࡳࡪࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠤࡡࡴࠠࡊࡨࠣࡅࡷࡧࡢࡪࡥࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡯ࡳࠡࡰࡲࡸࠥࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࠡ࠰࠱ࠤ࡙࡮ࡥ࡯ࠢࡲࡴࡪࡴࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡲࡦࡩ࡬ࡳࡳࡧ࡬ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡠࡳࡢ࡮ࠡࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦ࡮ࡰࡹࠣࡸࡴࠦ࡯ࡱࡧࡱࠤࡹ࡮ࡥࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦ࠿ࠢࠩሳ")
			choice = NJZUGpSmQLPBxuv3Mn(HHthiRYs8T6IO3qUyX(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬሴ"),MBS1GrwQoUlsiIRfVDOHdA(u"࠭ࡅࡹ࡫ࡷࠤำื่อࠩስ"),J6G8X3gO1MiKh027D(u"࡚ࠧࡧࡶࠤ๋฿ๅࠨሶ"),gNPRXprEAQJ(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡ฻ิฬ๏࠭ሷ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࡐ࡭ࡸࡹࡩ࡯ࡩࠣࡅࡷࡧࡢࡪࡥࠣࡊࡴࡴࡴࠡࠨࠣࡘࡪࡾࡴࠨሸ"),message,profile=NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨሹ"))
			if choice==qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠷ᏻ"): E8S5nYtIQZeKVv6lLoF79BJHhk = dbo4vrnTM56I
		if choice==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠷ᏼ"): cHKCb25gadn6ki4SQJ7Pvw()
	return
def xb5VI9fRrS6():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,sdRqnego9PclrL4m2J(u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪሺ"))
	return
def XVI3fuBiZwo1HSJadKNbn():
	gfe2BNJ3kTF0Xx = dQvxmFkyLOteNMWBJ2bDHV(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬሻ")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
	return
def VVCOEsewUNDZonLkz():
	gfe2BNJ3kTF0Xx = qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭วๅำ๋หอ฽ࠠศๆห฻๏ฬษࠡๆสࠤ฾๊วให่ࠣ์อࠠษษ็ฬึ์วๆฮࠣ์฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠪሼ")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
	return
def JJU2jI94nNtE():
	gfe2BNJ3kTF0Xx = HfuZG0aphlYnVLOyAk93rj(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫሽ")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,WlU7AtONpyj3(u"ࠨีํีๆืวหࠢึ๎หฯࠠฤ๊้ࠣัํ่ๅหࠪሾ"),gfe2BNJ3kTF0Xx)
	return
def VyJ1SqDs5jvprBoH7():
	gfe2BNJ3kTF0Xx = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩสุ่๐ัโำสฮࠥอไฺษ่อࠥํ๊ࠡีํีๆืวหࠢัหึา๊ส๋ࠢ฾๏ืࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦอ็ํ฽ࠥอไๆ๊สๆ฾ࠦสิฬัำ๊ํว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฬศ่ํอࠥ๎ๅีษๆ่์อࠠไอํีฮࠦไศ่ࠣห้็๊ะ์๋๋ฬะࠠโ์๊หࠥหๅศࠢห฻๏ฬษࠡล๋ࠤ๊๋ๆ้฻ฬࠤศ๎ࠠๆฯำ์ๆฯࠠฤ๊ࠣๅ๏ํวࠡ็ื็้ฯࠠฮไ๋ๆࠥอไๆๆๆ๎ฮࡢ࡮࡝ࡰ࡟ࡲฬ๊ำ๋ำไีฬะࠠศๆัหฺฯ่ࠠ์ࠣื๏ืแาษอࠤฯอศฺห่้๋่ࠣใ฻ࠣห้ษีๅ์ࠣ์ู๊สฯั่อࠥ็๊ࠡ็๋ห็฿ࠠใๆํ่ฮࠦฬะษࠣ์฾อฯสࠢอ็ํ์ࠠๆัไ์฾ฯࠠศๆฦะึࠦร้ࠢํ้้้็ศࠢส่๊๎โฺࠢส่ศ฻ไ๋๋่ࠢ์ึวࠡใ๊๎ࠥา๊ะหุ๊ࠣฮ๊ศ๋ࠢืึ๐ูสู๋้ࠢอใๅ้สࠤ็๊๊ๅหࠣะิอࠧሿ")
	KKHpNde5TOmYqjIygtlwhf7W2sr(z8wTfYPiRQL(u"ࠪࡧࡪࡴࡴࡦࡴࠪቀ"),fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧቁ"))
	return
def jd7yhq6490Z5EpUCMi():
	i2xKJuM5eANb = ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅัๅอࠥอไฺษ็๎ฮ࠭ቂ")
	ccYfzwbEjm2qxCdhlSRWt = WlU7AtONpyj3(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠฤๆࠣࡱ࠸ࡻ࠸ࠨቃ")
	TTQHx1fWsXizAbwYFO6dEP9vclK = Urj6egiVyHA75ZK(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ฮา๋๊ๅ๋ࠢห้ีว้่็์ิࠦࡤࡰࡹࡱࡰࡴࡧࡤࠨቄ")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,i2xKJuM5eANb,ccYfzwbEjm2qxCdhlSRWt,TTQHx1fWsXizAbwYFO6dEP9vclK)
	return
def DimCxMk2fNH4q19():
	ccYfzwbEjm2qxCdhlSRWt = qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩቅ")
	ccYfzwbEjm2qxCdhlSRWt += SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩ࡟ࡲࡡࡴࠧቆ") + Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩቇ") + str(ggbKIPj8XAQhBVyeu1oDO47FNz/qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠶࠱ᏽ")/qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠶࠱ᏽ")/oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠳࠶᏾")/ZeV4vau9CjN(u"࠵࠳᏿")) + gNPRXprEAQJ(u"ฺࠫࠥ็าࠩቈ")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk + MBS1GrwQoUlsiIRfVDOHdA(u"ࠬ࠸࠮ࠡฮาหࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้๋แาู๊ࠤศ์็ศࠢ็หࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ቉") + str(xCNH20myQLKTeJUVA1p7/CMUXq6mPQV5rLsSBdWZJvA(u"࠹࠴᐀")/CMUXq6mPQV5rLsSBdWZJvA(u"࠹࠴᐀")/YoMw2J1Ljp(u"࠶࠹ᐁ")) + qvCARpoujaDHbnOgYF8274NkWzeG39(u"๋๊่࠭ࠠࠫቊ")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk + WlU7AtONpyj3(u"ࠧ࠴࠰ࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๆศัิหࠥะส฻์ิࠤํ๋ฯห้ࠣࠫቋ") + str(mXiE2RJGvS1DK4ZQuzl0sBFV/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠻࠶ᐂ")/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠻࠶ᐂ")/YoMw2J1Ljp(u"࠸࠴ᐃ")) + Urj6egiVyHA75ZK(u"ࠨࠢํ์๊࠭ቌ")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk + HfuZG0aphlYnVLOyAk93rj(u"ࠩ࠷࠲๋ࠥส้ีฺࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢๅำࠥะส฻์ิࠤํ๋ฯห้ࠣࠫቍ") + str(SSZixT0lqg4BaUOtf79JjFIurn/z8wTfYPiRQL(u"࠶࠱ᐄ")/z8wTfYPiRQL(u"࠶࠱ᐄ")) + wb1nC3e8AjRVU4ovsuPa(u"ࠪࠤุอูสࠩ቎")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk + dQvxmFkyLOteNMWBJ2bDHV(u"ࠫ࠺࠴ࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢาหห๋ว๊่ࠡำฯํࠠࠨ቏") + str(qogplQ5vHLYt8Ci1fknObwMThe/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠷࠲ᐅ")/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠷࠲ᐅ")) + MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࠦำศ฻ฬࠫቐ")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk + Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧቑ") + str(i8a54nkd09BCbvuZxQFMAqDR2tlK/Urj6egiVyHA75ZK(u"࠸࠳ᐆ")) + wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࠡัๅ๎็ฯࠧቒ")
	ccYfzwbEjm2qxCdhlSRWt += URBvawyLXfQiS2NI34HDk + HfuZG0aphlYnVLOyAk93rj(u"ࠨ࠹࠱ࠤอี่็ࠢๆหูࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤอูัฺหࠣ์๊ีส่ࠢࠪቓ") + str(uQIXMypK534GsVWetdl6Px9fTjUn) + MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࠣำ็๐โสࠩቔ")
	ccYfzwbEjm2qxCdhlSRWt += CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡠࡳࡢ࡮ࠨቕ") + wnVICNyfE3XZ0htUaDFAOgLo(u"๊ࠫัไศ࠼ูࠣๆำวหࠢๅ์ฬฬๅࠡษ็วๆ๊วๆ๋ࠢห้๋ำๅี็หฯ่ࠦศๆะ่็อสࠡ฻่ี์อࠠࠨቖ") + str(SSZixT0lqg4BaUOtf79JjFIurn/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")) + qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࠦำศ฻ฬࠤ࠳ࠦรๆษࠣๆํอฦๆࠢฦ๊ํอูࠡษ็ๅ๏ี๊้้สฮࠥ็ูๆำ๊หࠥ࠭቗") + str(mXiE2RJGvS1DK4ZQuzl0sBFV/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")/wnVICNyfE3XZ0htUaDFAOgLo(u"࠶࠹ᐈ")) + Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭ࠠฤ์ส้ࠥ࠴ࠠฤ็สࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤๆ฿ๅา้สࠤࠬቘ") + str(qogplQ5vHLYt8Ci1fknObwMThe/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")) + CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࠡีส฽ฮࠦแใูࠣ࠲ࠥษๅศࠢไัฺࠦัใ็ࠣห้หีะษิࠤๆ฿ๅา้ࠣࠫ቙") + str(i8a54nkd09BCbvuZxQFMAqDR2tlK/NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴ᐇ")) + Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࠢาๆ๏่ษࠡ࠰ࠣว๊อࠠโฯุࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠣๅ฾๋ั่ࠢࠪቚ") + str(uQIXMypK534GsVWetdl6Px9fTjUn) + x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩࠣำ็๐โสࠩቛ")
	KKHpNde5TOmYqjIygtlwhf7W2sr(z8wTfYPiRQL(u"ࠪࡶ࡮࡭ࡨࡵࠩቜ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"๊ࠫอ่๊ࠠࠣห้้วีࠢสู่๊สฯั่ࠤๆ๐ࠠศๆหี๋อๅอࠩቝ"),ccYfzwbEjm2qxCdhlSRWt,ZeV4vau9CjN(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ቞"))
	return
def cEd1NuvM4aLe23xIGJZoqmt7P():
	gfe2BNJ3kTF0Xx = gNPRXprEAQJ(u"࠭วๅใสู้ฯࠠห฻้๎๋ࠥฬๅัࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏่ࠦศๆ้ๆ฼ฯࠠห฻้๎ࠥษๆࠡษ็หุ๋ࠠศๆฦู้๐ࠠห็ࠣฮ฾ี๊ๅ้ࠣ์ๆอีๅหࠣ์๋่ืสࠢอ฽๋๏ࠠๆฮ็ำࠥ๎สๆࠢอ฽ิ๐ไࠡษึ้์่ࠦษั๋๊ࠥ฿ไศ็ฬࠤฯ฿ๆ๋่่ࠢๆࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋ࠩ቟")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
	return
def KmpXWbVesjcwQG8tnOIJ():
	gfe2BNJ3kTF0Xx = sdRqnego9PclrL4m2J(u"ࠧฦาสࠤํอฬ่ฬๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅึห็ฮ่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥษ่ࠡษ้็ࠥะุ็ࠢฦ๊ࠥอไๆ๊ๅ฽ࠥอไฤื็๎้ࠥว็ࠢไ๎์ࠦๅีๅ็อ๋ࠥฤใฬ๊ࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣๅสึๆࠡฮิฬ๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮืๅสࠣห้฻แฮหࠣห้฻อ๋ฯฬࠤํะฮำ์้๋ฬࠦศะๆสࠤ๊์ࠠศๆุๅาฯࠠศๆๅำ๏๋ษࠨበ")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
	return
def KoJB3XCRDiyUj5():
	gfe2BNJ3kTF0Xx = G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬቡ")
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
	return
def XEZQznufPd():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧቢ"))
	BfnJNmF3wajrI5hqTQuzpVOds(ZeV4vau9CjN(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪባ"),dbo4vrnTM56I)
	return
def yyONMGbBUKnHhrS6C9VLfgmap4J():
	gfe2BNJ3kTF0Xx  = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭ቤ")
	gfe2BNJ3kTF0Xx += Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬብ")
	gfe2BNJ3kTF0Xx += URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+G6GUCto502jZTLubYNnqMx8ywBah(u"࠭เ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำࠪቦ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+URBvawyLXfQiS2NI34HDk
	gfe2BNJ3kTF0Xx += Urj6egiVyHA75ZK(u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧቧ")
	KKHpNde5TOmYqjIygtlwhf7W2sr(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࡴ࡬࡫࡭ࡺࠧቨ"),fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx,wb1nC3e8AjRVU4ovsuPa(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬቩ"))
	gfe2BNJ3kTF0Xx = qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ቪ")
	gfe2BNJ3kTF0Xx += URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࡦࡱ࡯ࡢ࡯ࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࠥࠦࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠣࠤࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠠࠡࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠠࠡࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪቫ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	gfe2BNJ3kTF0Xx += BBOY8rvinVbFh(u"ࠬࡢ࡮࡝ࡰࠪቬ")+J6G8X3gO1MiKh027D(u"࠭วๅั๋่ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧቭ")
	gfe2BNJ3kTF0Xx += URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧๆืิࠤࠥอไไ๊ํฮࠥࠦรๆ์ิ็ฬࠦࠠไ่าหࠥࠦแา่ึหࠥࠦวๅ์๋๊ฬ์ࠠࠡสิ๎฼อๆ๋ษࠣห้หๅศำสฮࠥษไๆษ้๎ฬࠦั้ีํหࠥอไ๋ษหห๋ࠦวๅี฼์ิ๐ษࠡำ๋้ฬ์๊ศ๊ࠢ์้์ฯศࠩቮ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	gfe2BNJ3kTF0Xx += MBS1GrwQoUlsiIRfVDOHdA(u"ࠨ࡞ࡱࡠࡳ࠭ቯ")+FkqI4Gm8wMvUVbgo(u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪተ")
	gfe2BNJ3kTF0Xx += HHFAVK8SwRUqBLuTfdeJ9nbD+G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪหึูไࠡำึห้ฯࠠๆฦาฬฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอใหสࠣๅ๏ํวࠡษึ้ࠥฮไะๅࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะำหูํ฽ࠥีฮ้ๆ๊หࠬቱ")+wVvqN8LZCJW5ryAb1EHRPFkQ0
	KKHpNde5TOmYqjIygtlwhf7W2sr(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫࡷ࡯ࡧࡩࡶࠪቲ"),fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨታ"))
	return
def UCRl657NaEu4bZOfhmgIcF9Vs1z8TA():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,wb1nC3e8AjRVU4ovsuPa(u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭ቴ"),BBOY8rvinVbFh(u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡำึหห๊่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥฮวิฬัำฬ๋ࠠศๆไ๎ุฮ่ไࠢฦำ๋อ็࡝ࡰࠪት")+HHFAVK8SwRUqBLuTfdeJ9nbD+HHthiRYs8T6IO3qUyX(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡨࡤࡧࡪࡨ࡯ࡰ࡭࠱ࡧࡴࡳ࠯ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࠪቶ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+HfuZG0aphlYnVLOyAk93rj(u"ࠩ࡟ࡲࡡࡴร้ࠢหหึูวๅࠢส๎๊๐ไࠡษ็ํࠥษฯ็ษ๊ࠤࠥࡢ࡮ࠡࠩቷ")+HHFAVK8SwRUqBLuTfdeJ9nbD+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡆࡧ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠩቸ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
	return
def kI2ryinlYotcSfE4q8UT(showDialogs=dbo4vrnTM56I):
	if not showDialogs: showDialogs = dbo4vrnTM56I
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,Urj6egiVyHA75ZK(u"ࠫࡌࡋࡔࠨቹ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡹࡣࡰࡴࡱ࡫࠮ࡤࡱࡰࠫቺ"),kh850jKbzmBwY,kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩቻ"))
	if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
		cXfqYuEtxPUmd8wWMNT37y1Ah = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		BPmnCIRKgJyuMrSDHj1VaAqNkYFGoU = QwbOcSlDzkaXm07x2ioyNYJWqfsCE1(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+WlU7AtONpyj3(u"ࠧࠡࠢࠣࡌ࡙࡚ࡐࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡑࡧࡢࡦ࡮࠽࡟ࠬቼ")+BPmnCIRKgJyuMrSDHj1VaAqNkYFGoU+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࡟ࠪች"))
		if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩไัฺࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠ࠯࠰࠱ࠤฺ๊ใๅหࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠡ฻็ํ้่ࠥะ์ࠣ࠲࠳࠴้ࠠ฻้ำ่ࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭ቾ"))
	else:
		cXfqYuEtxPUmd8wWMNT37y1Ah = dbo4vrnTM56I
		if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ZeV4vau9CjN(u"ࠪะ๏ีࠠอัสࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แาࠫࠣ๎฾๋ไࠡ฻้ำ่่ࠦศๆหี๋อๅอࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧቿ"))
	if not cXfqYuEtxPUmd8wWMNT37y1Ah and showDialogs: JLkcOX2m9hVn()
	return cXfqYuEtxPUmd8wWMNT37y1Ah
def JLkcOX2m9hVn():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫอ฿ึࠡษ็้ํอโฺࠢอัฯอฬࠡำห฻๋ࠥิโำࠣ์็ี๋ࠠๅ๋๊ࠥา็ศิๆࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣห้ืศุࠢสฺ่๊แาࠢฦ์ࠥํๆศๅู้้ࠣไสࠢไ๎ฺࠥ็ศัฬࠤฬ๊สีใํีࠥอไฯษุอࠥฮใ้ัํࠤ฾์ฯไࠢ฼่๊อࠠศ่๊ࠤฯ๋ࠠโฯุࠤฬ๊ศา่ส้ัูࠦๅ๋ࠣ็ํี๊ࠡษ็ษฺีวาษอࠤࡡࡴࠠ࠲࠹࠱࠺ࠥࠦࠦࠡࠢ࠴࠼࠳ࡡ࠰࠮࠻ࡠࠤࠥࠬࠠࠡ࠳࠼࠲ࡠ࠶࠭࠴࡟ࠪኀ"))
	OBkhYLsyTmRjfAdP()
	return
def pujLsDSbUtky8dzM2qGgAwflxen0(fRJYhnSKHsZ7MqFwmiVz=kh850jKbzmBwY):
	gTf1RiSwUj8b923IVo5hBLxqdMEck = dbo4vrnTM56I
	if CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨኁ") not in fRJYhnSKHsZ7MqFwmiVz:
		gTf1RiSwUj8b923IVo5hBLxqdMEck = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		gNiJnH3cvG1Dd9t = NJZUGpSmQLPBxuv3Mn(BBOY8rvinVbFh(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ኂ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧฯำ๋ะࠬኃ"),WlU7AtONpyj3(u"ࠨวิืฬ๊ࠠๆึๆ่ฮ࠭ኄ"),tzEjvOaZWU1A(u"ࠩศีุอไࠡำึห้ฯࠧኅ"),fWM6PeOrvciG0RQpIKzltojDqaYs,wb1nC3e8AjRVU4ovsuPa(u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠๆึๆ่ฮࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤ࠭ኆ"))
		if gNiJnH3cvG1Dd9t in [-dQvxmFkyLOteNMWBJ2bDHV(u"࠶ᐉ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠶ᐊ")]: return
		elif gNiJnH3cvG1Dd9t==HHthiRYs8T6IO3qUyX(u"࠱ᐋ"):
			gTf1RiSwUj8b923IVo5hBLxqdMEck = dbo4vrnTM56I
			fRJYhnSKHsZ7MqFwmiVz = z8wTfYPiRQL(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧኇ")
	if gTf1RiSwUj8b923IVo5hBLxqdMEck:
		if YoMw2J1Ljp(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬኈ") not in fRJYhnSKHsZ7MqFwmiVz:
			II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ࡣࡦࡰࡷࡩࡷ࠭኉"),kh850jKbzmBwY,kh850jKbzmBwY,XasF0WO7rDUHnEt8hAl9kLN(u"ุ้ࠧ฼ࠤฬ๊ๅีๅ็อࠥ็๊ࠡษ็ืั๊ࠧኊ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨไห่ࠥหัิษ็ࠤฬ๊ำอๆࠣ฽้๐ใࠡล้ࠤฯ้ัา๊ࠢࠣๆูࠠศๆไ฽้ࠦวๅาํࠤศ฿ืศๅࠣห้๋ิไๆฬࠤ࠳ࠦไไ์ࠣ๎ฯ๋ࠠหีฯ๎้ࠦ็ั้ࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ࠱ࠤํฮฯ้่๋ࠣีอࠠศๆอืั๐ไࠡี๋ๅࠥะัิๆ้้ࠣ็ࠠๅษࠣๅฬฬฯส่๊ࠢ์ࠦไฦ่๊ࠤ้อ๋ࠠฯอ์๏ูࠦๅ๋ࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอี๏ีࠠศ่อࠤฬ๊ลษๆส฾ࠥ฿ๆ่ษࠣ࠲ࠥํไࠡไ่ฮࠥฮสไำสีࠥอไๆึๆ่ฮࠦฟࠨኋ"))
			if II7ErX2ocuU!=Urj6egiVyHA75ZK(u"࠲ᐌ"):
				o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,HHthiRYs8T6IO3qUyX(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬኌ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ኍ"))
				return
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫๆ๐ࠠศๆืหูฯࠠศๆๅหิ๋ษࠡฯส์้ࠦร็ࠢอ็ฯฮࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอิาฯࠣๅ๏ํวࠡษ็ู้้ไสࠢฦ์ࠥอไๆู๊์฾่ࠦฦาสࠤศืฯหࠢฯ์ฬฮࠠๆ่ࠣห้๋ศา็ฯࠤๆหะ็ࠢฦ็ฯฮฺ่๋ࠠห๋ࠦศา์า็ࠥษไฦๆๆฮึ๎ๆ๋ࠢส่ส๐ๅ๋ๆࠣ์ฯึใา๋่ࠢฬࠦส็ี์ࠤศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ኎"))
	gfe2BNJ3kTF0Xx = GG5Fs0hvURxyBV8gz(header=oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬ࡝ࡲࡪࡶࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭኏"),source=vkNGie5mhCqoTFRzPKaML0x6)
	if not gfe2BNJ3kTF0Xx: return
	if gTf1RiSwUj8b923IVo5hBLxqdMEck: type = wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ࡐࡳࡱࡥࡰࡪࡳࠧነ")
	else: type = Urj6egiVyHA75ZK(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠨኑ")
	jVhaOJ9utFmLGZpHceKNMlE = pPI9ojeNDixmAdQcVz(type,gfe2BNJ3kTF0Xx,dbo4vrnTM56I,kh850jKbzmBwY,HHthiRYs8T6IO3qUyX(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡛ࡓࡆࡔࡖࠫኒ"),fRJYhnSKHsZ7MqFwmiVz)
	return
def hDuiaoe7Fk():
	fRJYhnSKHsZ7MqFwmiVz = z8wTfYPiRQL(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭ና")
	KKHpNde5TOmYqjIygtlwhf7W2sr(wb1nC3e8AjRVU4ovsuPa(u"ࠪࡶ࡮࡭ࡨࡵࠩኔ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫን"),fRJYhnSKHsZ7MqFwmiVz,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨኖ"))
	fRJYhnSKHsZ7MqFwmiVz = tzEjvOaZWU1A(u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩኗ")
	KKHpNde5TOmYqjIygtlwhf7W2sr(sdRqnego9PclrL4m2J(u"ࠧ࡭ࡧࡩࡸࠬኘ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭ኙ"),fRJYhnSKHsZ7MqFwmiVz,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬኚ"))
	return
def nqa35JujQkNi1Zl4xz():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨኛ"))
	KoJB3XCRDiyUj5()
	return
def kjchvyfurWUbIX5wnPNY0TqRLmlA():
	X0wn4s2R3P1BMoAcUJhDCg = {}
	DNl9I268hQBV,F8kp0XHuzchNS2MqUYv7,h76EJgywpT2Q = u4RBP7F3kvd1TlCtMKArQ(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	i2xKJuM5eANb,ccYfzwbEjm2qxCdhlSRWt,TTQHx1fWsXizAbwYFO6dEP9vclK,iUzhMjqu1OQ7,BJWmzH4rM9jPyd2K,ydw8CLncXSheZrY4IqaW3M9puo2j,MrOnbeXQpVxcflsW94g1BLiA = kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY
	i2xKJuM5eANb = cyR2rJzGpVSXNuHsEQjk60fvFetYDx.join(F8kp0XHuzchNS2MqUYv7)
	ccYfzwbEjm2qxCdhlSRWt = cyR2rJzGpVSXNuHsEQjk60fvFetYDx.join(h76EJgywpT2Q)
	yNwe2UXhar,rDyCH2NfpKkS,QQZAc8k3qU7wt1yg0hzCof = DNl9I268hQBV
	for CYil97XWVj4Z3SRKMUf8DGQeLa,UFDNphQl5BVWYvAfaOGIuHk6qKbPMy,KGr8wnCQuchLkS9 in rDyCH2NfpKkS:
		KGr8wnCQuchLkS9 = Z4CP1xs5w7fi(KGr8wnCQuchLkS9)
		KGr8wnCQuchLkS9 = KGr8wnCQuchLkS9.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).strip(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࠥ࠴ࠧኜ"))
		NLySCdI9gxpJAa0BK4fz = CYil97XWVj4Z3SRKMUf8DGQeLa.replace(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬኝ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡁࡑࡋࠪኞ"))
		iUzhMjqu1OQ7 += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+NLySCdI9gxpJAa0BK4fz+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧ࠻ࠢࠪኟ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+KGr8wnCQuchLkS9+URBvawyLXfQiS2NI34HDk
		if UFDNphQl5BVWYvAfaOGIuHk6qKbPMy.isdigit(): X0wn4s2R3P1BMoAcUJhDCg[CYil97XWVj4Z3SRKMUf8DGQeLa] = int(UFDNphQl5BVWYvAfaOGIuHk6qKbPMy)
	eyS7slmE9cGJQDM,JChpNRcUfP1gnEjZbo9tABWHKw6,bbS5yCz9xdLPJmcsKaBhGIno = list(zip(*rDyCH2NfpKkS))
	for CYil97XWVj4Z3SRKMUf8DGQeLa in sorted(zDi7eytcamrCE):
		if CYil97XWVj4Z3SRKMUf8DGQeLa not in eyS7slmE9cGJQDM:
			iUzhMjqu1OQ7 += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+CYil97XWVj4Z3SRKMUf8DGQeLa+YoMw2J1Ljp(u"ࠨ࠼ࠣࠫአ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+XasF0WO7rDUHnEt8hAl9kLN(u"ࠩ็หࠥ๐่อัࠪኡ")+URBvawyLXfQiS2NI34HDk
			if CYil97XWVj4Z3SRKMUf8DGQeLa not in Y3Ny5eLHdp.non_videos_actions: TTQHx1fWsXizAbwYFO6dEP9vclK += cyR2rJzGpVSXNuHsEQjk60fvFetYDx+CYil97XWVj4Z3SRKMUf8DGQeLa
	for KGr8wnCQuchLkS9,ZqUKbox5pPuJ79ng32cX6IkvL in yNwe2UXhar:
		KGr8wnCQuchLkS9 = Z4CP1xs5w7fi(KGr8wnCQuchLkS9)
		BJWmzH4rM9jPyd2K += KGr8wnCQuchLkS9+HfuZG0aphlYnVLOyAk93rj(u"ࠪ࠾ࠥ࠭ኢ")+HHFAVK8SwRUqBLuTfdeJ9nbD+str(ZqUKbox5pPuJ79ng32cX6IkvL)+wVvqN8LZCJW5ryAb1EHRPFkQ0+ityRsSDe1ZNqhQ3PLjp74dfEV
	i2xKJuM5eANb = i2xKJuM5eANb.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	ccYfzwbEjm2qxCdhlSRWt = ccYfzwbEjm2qxCdhlSRWt.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	TTQHx1fWsXizAbwYFO6dEP9vclK = TTQHx1fWsXizAbwYFO6dEP9vclK.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	PUArdjZ46F = i2xKJuM5eANb+YoMw2J1Ljp(u"ࠫࠥࠦ࠮࠯ࠢࠣࠫኣ")+ccYfzwbEjm2qxCdhlSRWt
	qGpQryMfUOei0IboYvKd5CEX3xJg  = HHthiRYs8T6IO3qUyX(u"๋่ࠬศไ฼ࠤั๐ฯสࠢื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦแ๋ัํ์์อสࠡใํࠤศิัࠡ࠹࠵ࠤุอูสࠢࠫ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬ࠭ࠥ࠮ๅ็ࠢส่ศ้หาࠢศ่๎ࠦวๅลๅ่࠮࠭ኤ")+URBvawyLXfQiS2NI34HDk+CMUXq6mPQV5rLsSBdWZJvA(u"่่࠭าสࠤ๊฿ๆศ้ࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐็ๆࠢไ๋๏ࠦๅ็ࠢ฼๊ิ้้ࠠๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠤํ๊วࠡ็้ࠤฬ๊ๅ้ไ฼ࠫእ")+URBvawyLXfQiS2NI34HDk
	qGpQryMfUOei0IboYvKd5CEX3xJg += HHFAVK8SwRUqBLuTfdeJ9nbD+PUArdjZ46F+wVvqN8LZCJW5ryAb1EHRPFkQ0+FkqI4Gm8wMvUVbgo(u"ࠧ࡝ࡰ࡟ࡲࠬኦ")
	qGpQryMfUOei0IboYvKd5CEX3xJg += HHthiRYs8T6IO3qUyX(u"ࠨ็๋ห็฿ࠠๅ็ࠣ๎ูเไࠡ็้๋ฬࠦวๅสิ๊ฬ๋ฬࠡใํำ๏๎็ศฬࠣๅ๏ࠦรฯำࠣ࠻࠷ࠦำศ฻ฬࠤ࠭࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠯ࠠࠩ็ิฮอฯࠠฤสฯำ๏࠯ࠧኧ")+URBvawyLXfQiS2NI34HDk+Urj6egiVyHA75ZK(u"๋๋ࠩีอࠠๆ฻้ห์ࠦวฮฬ่ห้่ࠦอ๊าࠤฺ๊ใๅหࠣ฽๋ีใࠡล๋ࠤๆ๐ࠠศๆ่์็฿ࠠฤ๊ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨከ")+URBvawyLXfQiS2NI34HDk
	TTQHx1fWsXizAbwYFO6dEP9vclK = cyR2rJzGpVSXNuHsEQjk60fvFetYDx.join(sorted(TTQHx1fWsXizAbwYFO6dEP9vclK.split(cyR2rJzGpVSXNuHsEQjk60fvFetYDx)))
	qGpQryMfUOei0IboYvKd5CEX3xJg += HHFAVK8SwRUqBLuTfdeJ9nbD+TTQHx1fWsXizAbwYFO6dEP9vclK+wVvqN8LZCJW5ryAb1EHRPFkQ0
	uuatX1Rfl7ABPC3bLgNw5HGdYq,DDB7qcLwW2z6,oPKHsx5vp6IVG,UVx2IE30noLGscSYD1mk4qXu = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠲ᐍ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠲ᐍ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠲ᐍ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠲ᐍ")
	all = X0wn4s2R3P1BMoAcUJhDCg[aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡅࡑࡒࠧኩ")]
	if x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫኪ") in list(X0wn4s2R3P1BMoAcUJhDCg.keys()): uuatX1Rfl7ABPC3bLgNw5HGdYq = X0wn4s2R3P1BMoAcUJhDCg[BBOY8rvinVbFh(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬካ")]
	if SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧኬ") in list(X0wn4s2R3P1BMoAcUJhDCg.keys()): DDB7qcLwW2z6 = X0wn4s2R3P1BMoAcUJhDCg[J6G8X3gO1MiKh027D(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨክ")]
	if NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬኮ") in list(X0wn4s2R3P1BMoAcUJhDCg.keys()): oPKHsx5vp6IVG = X0wn4s2R3P1BMoAcUJhDCg[FkqI4Gm8wMvUVbgo(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ኯ")]
	if z8wTfYPiRQL(u"ࠪࡖࡊࡖࡏࡔࠩኰ") in list(X0wn4s2R3P1BMoAcUJhDCg.keys()): UVx2IE30noLGscSYD1mk4qXu = X0wn4s2R3P1BMoAcUJhDCg[NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࡗࡋࡐࡐࡕࠪ኱")]
	y0yQhBj7Te = all-uuatX1Rfl7ABPC3bLgNw5HGdYq-DDB7qcLwW2z6-oPKHsx5vp6IVG-UVx2IE30noLGscSYD1mk4qXu
	W7BTt4f3CkhKJIY,GKg7vI8ysmaCpTVok0 = QQZAc8k3qU7wt1yg0hzCof[nxUveizbLEAT2FBNy3]
	W7BTt4f3CkhKJIY,m60mXC9awLxbQ3sfB8IiJleK = QQZAc8k3qU7wt1yg0hzCof[igM4DhpPzoX95Ysnar6Auj]
	iiedvYLbuJ9SXRyVwNkGsFmDfTUBCI = GKg7vI8ysmaCpTVok0-m60mXC9awLxbQ3sfB8IiJleK
	MrOnbeXQpVxcflsW94g1BLiA += RlMpu0hP8YmzZovkVXOs1G+str(m60mXC9awLxbQ3sfB8IiJleK)+wVvqN8LZCJW5ryAb1EHRPFkQ0+ZeV4vau9CjN(u"ࠬอไฺัาࠤฬ๊อใ์ๅ๎๊ࠥไฤฮ๊ึฮࠦ࠺ࠡࠩኲ")
	MrOnbeXQpVxcflsW94g1BLiA += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(iiedvYLbuJ9SXRyVwNkGsFmDfTUBCI)+wVvqN8LZCJW5ryAb1EHRPFkQ0+YoMw2J1Ljp(u"࠭ศศีอาิอๅࠡࡲࡵࡳࡽࡿࠠฤ๊ࠣࡺࡵࡴࠠ࠻ࠢࠪኳ")
	MrOnbeXQpVxcflsW94g1BLiA += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(GKg7vI8ysmaCpTVok0)+wVvqN8LZCJW5ryAb1EHRPFkQ0+MBS1GrwQoUlsiIRfVDOHdA(u"ࠧศๆ฼ำิࠦวๅๅ็๎๊ࠥฬๆ์฼ࠤฬ๊รอ้ีอࠥࡀࠠࠨኴ")
	MrOnbeXQpVxcflsW94g1BLiA += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(len(QQZAc8k3qU7wt1yg0hzCof[ssYkHaML9z37bJ0StuEBXIqgiV(u"࠵ᐎ"):]))+wVvqN8LZCJW5ryAb1EHRPFkQ0+dQvxmFkyLOteNMWBJ2bDHV(u"ࠨ฻าำࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎์อࠠฤฮ๊ึฮࠦ࠺ࠡ࡞ࡱࡠࡳ࠭ኵ")
	for dDw34S56lb,VwPKg4qUmChSbR2Bj in QQZAc8k3qU7wt1yg0hzCof[ssYkHaML9z37bJ0StuEBXIqgiV(u"࠶ᐏ"):]:
		dDw34S56lb = Z4CP1xs5w7fi(dDw34S56lb)
		dDw34S56lb = dDw34S56lb.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).strip(gNPRXprEAQJ(u"ࠩࠣ࠲ࠬ኶"))
		MrOnbeXQpVxcflsW94g1BLiA += dDw34S56lb+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪ࠾ࠥ࠭኷")+HHFAVK8SwRUqBLuTfdeJ9nbD+str(VwPKg4qUmChSbR2Bj)+wVvqN8LZCJW5ryAb1EHRPFkQ0+wb1nC3e8AjRVU4ovsuPa(u"ࠫࠥࠦࠠࠨኸ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += RlMpu0hP8YmzZovkVXOs1G+str(y0yQhBj7Te)+wVvqN8LZCJW5ryAb1EHRPFkQ0+XasF0WO7rDUHnEt8hAl9kLN(u"ࠬ็๊ะ์๋๋ฬะࠠศึอ฾้ะࠠ࠻ࠢࠪኹ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(uuatX1Rfl7ABPC3bLgNw5HGdYq)+wVvqN8LZCJW5ryAb1EHRPFkQ0+HHthiRYs8T6IO3qUyX(u"࠭ืๅสสฮู๊ࠥาใิࠤࡆࡖࡉࠡ࠼ࠣࠫኺ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(UVx2IE30noLGscSYD1mk4qXu)+wVvqN8LZCJW5ryAb1EHRPFkQ0+MBS1GrwQoUlsiIRfVDOHdA(u"ุࠧๆหหฯࠦำ๋ำไีࠥอไๆีอ์ิ฿ࠠ࠻ࠢࠪኻ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(DDB7qcLwW2z6)+wVvqN8LZCJW5ryAb1EHRPFkQ0+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨฬฮฬ๏ะࠠหูห๎็ࠦใ้ัํࠤ฾๋วะࠢ࠽ࠤࠬኼ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(oPKHsx5vp6IVG)+wVvqN8LZCJW5ryAb1EHRPFkQ0+Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩอฯอ๐สࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥࡀࠠࠨኽ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+str(len(yNwe2UXhar))+wVvqN8LZCJW5ryAb1EHRPFkQ0+tzEjvOaZWU1A(u"ࠪำํ๊ࠠี฼็ฮࠥ็๊ะ์๋๋ฬะࠠ࠻ࠢࠪኾ")
	ydw8CLncXSheZrY4IqaW3M9puo2j += aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࡡࡴ࡜࡯ࠩ኿")+BJWmzH4rM9jPyd2K
	KKHpNde5TOmYqjIygtlwhf7W2sr(Urj6egiVyHA75ZK(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬዀ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦรฯำࠣ࠻࠷ࠦำศ฻ฬࠤ࠭࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠯ࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ዁"),ydw8CLncXSheZrY4IqaW3M9puo2j,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪዂ"))
	KKHpNde5TOmYqjIygtlwhf7W2sr(WlU7AtONpyj3(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨዃ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"่ࠩ์ฬู่ࠡษืฮ฿๊สࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬዄ"),qGpQryMfUOei0IboYvKd5CEX3xJg,u8iSx05wLfVyMNp1X3l(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ዅ"))
	KKHpNde5TOmYqjIygtlwhf7W2sr(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡱ࡫ࡦࡵࠩ዆"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬษูๅ๋ࠣห้ี่ๅࠢส่ฯ๐ࠠศีอาิ๋สࠡษ็ฬึ์วๆฮࠣๅ๏ࠦรฯำࠣ࠻࠷ࠦำศ฻ฬࠤ࠭࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠯ࠧ዇"),iUzhMjqu1OQ7,WlU7AtONpyj3(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧወ"))
	EoGNACuMnrFUzPyi(dbo4vrnTM56I)
	return
def lvkBQoAjptycmJa():
	gfe2BNJ3kTF0Xx = wb1nC3e8AjRVU4ovsuPa(u"่ࠧาสࠤฬ๊ศา่ส้ัฺ๊ࠦ็็ࠤฬ็ึๅࠢหหุะฮะษ่ࠤั๊ฯࠡๅ๋ำ๏ࠦࠨࡌࡱࡧ࡭࡙ࠥ࡫ࡪࡰࠬࠤฬ๊ะ๋ࠢสื๊ํ࡜࡯ࠩዉ")+RlMpu0hP8YmzZovkVXOs1G+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧዊ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩ࡟ࡲࡡࡴ࡜࡯๋้๊้ࠢๆࠡฬฮฬ๏ะ็ࠡสสืฯิฯศ็ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣวํࠦสฮ็ํ่์ࠦๅ็࡞ࡱࠫዋ")+RlMpu0hP8YmzZovkVXOs1G+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲࠫዌ")+wVvqN8LZCJW5ryAb1EHRPFkQ0+J6G8X3gO1MiKh027D(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสุࠢ๎ฬ์ษࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆห้ࠣ฾๊่ๆษอࠤฬ๊ศา่ส้ั࠭ው")
	KKHpNde5TOmYqjIygtlwhf7W2sr(tzEjvOaZWU1A(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬዎ"),fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx,gNPRXprEAQJ(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩዏ"))
	return
def NIentSVcyBiY54WkwLXq7z8uTad():
	gfe2BNJ3kTF0Xx = HfuZG0aphlYnVLOyAk93rj(u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅิฬ๋ำ฾ูࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬዐ")+URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+Y3Ny5eLHdp.SITESURLS[HfuZG0aphlYnVLOyAk93rj(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧዑ")][nxUveizbLEAT2FBNy3]+wVvqN8LZCJW5ryAb1EHRPFkQ0+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࠣࠤࠥࠦร้ࠢࠣࠤࠥ࠭ዒ")+HHFAVK8SwRUqBLuTfdeJ9nbD+Y3Ny5eLHdp.SITESURLS[G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩዓ")][igM4DhpPzoX95Ysnar6Auj]+wVvqN8LZCJW5ryAb1EHRPFkQ0
	gfe2BNJ3kTF0Xx += BBOY8rvinVbFh(u"ࠫࡡࡴ࡜࡯࡞ࡱห้ืวษูࠣวิ์ว่๊ࠢ์ࠥอไิ๊ิืࠥอไั์ࠣ๎าะวอ้้ࠣิ๐ัࠡ็็ๅฬะࠠไ๊า๎๊ࠥสฬสํฮࠥฮั็ษ่ะࠥ฿ๅศัࠣฬฬ๊ืา์ๅอࠥอไหไ็๎ิ๐ษࠡษ็ๆิ๐ๅส࡞ࡱࠫዔ")+HHFAVK8SwRUqBLuTfdeJ9nbD+Y3Ny5eLHdp.SITESURLS[J6G8X3gO1MiKh027D(u"ࠬࡑࡏࡅࡋࡢࡗࡔ࡛ࡒࡄࡇࡖࠫዕ")][nxUveizbLEAT2FBNy3]+wVvqN8LZCJW5ryAb1EHRPFkQ0+qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ࠠࠡࠢࠣวํࠦࠠࠡࠢࠪዖ")+HHFAVK8SwRUqBLuTfdeJ9nbD+Y3Ny5eLHdp.SITESURLS[gNPRXprEAQJ(u"ࠧࡌࡑࡇࡍࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭዗")][igM4DhpPzoX95Ysnar6Auj]+wVvqN8LZCJW5ryAb1EHRPFkQ0
	gfe2BNJ3kTF0Xx += aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࡞ࡱࡠࡳࡢ࡮อ็ํ฽๋ࠥไโษอࠤ฾๋วะ่ࠢ์ั๎ฯสࠢไ๎ࠥอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠫዘ")+URBvawyLXfQiS2NI34HDk+HHFAVK8SwRUqBLuTfdeJ9nbD+Y3Ny5eLHdp.SITESURLS[ZeV4vau9CjN(u"ࠩࡉࡍࡑࡋࡓࡠࡕࡒ࡙ࡗࡉࡅࡔࠩዙ")][nxUveizbLEAT2FBNy3]+wVvqN8LZCJW5ryAb1EHRPFkQ0
	KKHpNde5TOmYqjIygtlwhf7W2sr(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡧࡪࡴࡴࡦࡴࠪዚ"),u8iSx05wLfVyMNp1X3l(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪዛ"),gfe2BNJ3kTF0Xx,HfuZG0aphlYnVLOyAk93rj(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨዜ"))
	return
def T3E2DU9Oc7s6uadSYIHrWjknigZ(efMBAbzi8Vx):
	ppNwDFByU1dZn5ca.executebuiltin(YoMw2J1Ljp(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬዝ")+efMBAbzi8Vx+tzEjvOaZWU1A(u"ࠧࠪࠩዞ"), dbo4vrnTM56I)
	return
def cHKCb25gadn6ki4SQJ7Pvw():
	oojYOMHFhlx5(CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࡵࡷࡳࡵ࠭ዟ"))
	ppNwDFByU1dZn5ca.executebuiltin(WlU7AtONpyj3(u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣዠ"))
	return
def o9pnaCxFIXwSrMVP8():
	ppNwDFByU1dZn5ca.executebuiltin(HHthiRYs8T6IO3qUyX(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩዡ"), dbo4vrnTM56I)
	return
def Go3cg10vtpxVDuhljUOQ():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ZeV4vau9CjN(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫዢ"))
	return
def dnGvtJ5sha():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨዣ"))
	return
def lBtE7m0AprDdhuZw1(PuGgtWdR0j78z5EQabwTHFY=taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬዤ"),showDialogs=dbo4vrnTM56I):
	Vew6ko57lWDvgiSaYBjrZHXhc = ppNwDFByU1dZn5ca.executeJSONRPC(gNPRXprEAQJ(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪዥ"))
	data = vDVykQSI8dwipbZuJmG31RO7l6h.loads(Vew6ko57lWDvgiSaYBjrZHXhc)
	r81nAMWIuf4piFTDGoNbk = data[G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨࡴࡨࡷࡺࡲࡴࠨዦ")][aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩࡹࡥࡱࡻࡥࠨዧ")]
	if BBJYzRKgHkOqx: r81nAMWIuf4piFTDGoNbk = r81nAMWIuf4piFTDGoNbk.encode(NVbhZ0DTpOkCA)
	if showDialogs:
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,wnVICNyfE3XZ0htUaDFAOgLo(u"๋้ࠪࠦสา์าࠤฯเ๊๋ำࠣะ้ีࠠࠨየ")+r81nAMWIuf4piFTDGoNbk+Urj6egiVyHA75ZK(u"ࠫࠥอไั์ุ้ࠣะฮะ็ࠣห้ศๆࠡใํࠤ่๎ฯ๋ࠢศ่๎ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำࠥ࠭ዩ")+PuGgtWdR0j78z5EQabwTHFY+FkqI4Gm8wMvUVbgo(u"ࠬࠦฟࠢࠩዪ"))
		if II7ErX2ocuU!=MBS1GrwQoUlsiIRfVDOHdA(u"࠶ᐐ"): return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	jVhaOJ9utFmLGZpHceKNMlE,ZITdOLbAx7QE6azk342C,mQ6gNrCMxtip5uBSLVZb3vfYc = nbIzqZLsiEkfX1Op(PuGgtWdR0j78z5EQabwTHFY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	if jVhaOJ9utFmLGZpHceKNMlE:
		if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭สๆฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ะ้ีࠠศๆฯำ๏ี้้๋ࠠࠤัอ็ำࠢ็่ฬูสฯัส้ࠥ࠴ࠠิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦส฻์ํีࠥหูะษาหฯࠦใ้ัํࠤ้้๊ࠡ์ึฮ฾๋ไࠡษ็ะ้ีࠠศๆฯำ๏ีࠠษั็ห๋ࠥๆࠡษ็ๆิ๐ๅࠨያ"))
		pYMAch3kEg = ppNwDFByU1dZn5ca.executeJSONRPC(wb1nC3e8AjRVU4ovsuPa(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠥࠫዬ")+PuGgtWdR0j78z5EQabwTHFY+HHthiRYs8T6IO3qUyX(u"ࠨࠤࢀࢁࠬይ"))
		jVhaOJ9utFmLGZpHceKNMlE = dbo4vrnTM56I if ZeV4vau9CjN(u"ࠩࡒࡏࠬዮ") in pYMAch3kEg else wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		pVesmhFG6wgubAODHSKvN1Wx.sleep(ZeV4vau9CjN(u"࠷ᐑ"))
		ppNwDFByU1dZn5ca.executebuiltin(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪዯ"))
	elif showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ZeV4vau9CjN(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯ่ࠦหใ฼๎้ࠦวๅฮ็ำࠥอไๆู็์อ࠭ደ"))
	return jVhaOJ9utFmLGZpHceKNMlE
def OBkhYLsyTmRjfAdP():
	url = XasF0WO7rDUHnEt8hAl9kLN(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳࡩࡳࡴࡲࡶࡸ࠴࡫ࡰࡦ࡬࠲ࡹࡼ࠯ࡳࡧ࡯ࡩࡦࡹࡥࡴ࠱ࡺ࡭ࡳࡪ࡯ࡸࡵ࠲ࡻ࡮ࡴ࠶࠵࠱ࠪዱ")
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ࡇࡆࡖࠪዲ"),url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,BBOY8rvinVbFh(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡖࡌࡔ࡝࡟ࡍࡃࡗࡉࡘ࡚࡟ࡌࡑࡇࡍࡤ࡜ࡅࡓࡕࡌࡓࡓ࠳࠱ࡴࡶࠪዳ"))
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	HLbP6JfAj8m = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣ࡭ࡲࡨ࡮࠳ࠨ࡝ࡦ࠮ࡠ࠳ࡢࡤࠬ࠯࡞ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯࠮࠳ࠧዴ"),uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	HLbP6JfAj8m = HLbP6JfAj8m[nxUveizbLEAT2FBNy3].split(HfuZG0aphlYnVLOyAk93rj(u"ࠩ࠰ࠫድ"))[nxUveizbLEAT2FBNy3]
	OdvgyKiEIYzJDx1MhmXjtLGe = str(xkio8CndBTR19MPztUvSqVLG5rcW)
	iUzhMjqu1OQ7 = XasF0WO7rDUHnEt8hAl9kLN(u"ࠪ࡟ࡗ࡚ࡌ࡞วุำฬืࠠไ๊า๎ࠥอไฤะํีࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬዶ")+RlMpu0hP8YmzZovkVXOs1G+HLbP6JfAj8m+wVvqN8LZCJW5ryAb1EHRPFkQ0
	iUzhMjqu1OQ7 += Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡡࡴ࡜࡯ࠩዷ")+dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้๋ࠣํࠦ࠺ࠡࠢࠣࠫዸ")+RlMpu0hP8YmzZovkVXOs1G+OdvgyKiEIYzJDx1MhmXjtLGe+wVvqN8LZCJW5ryAb1EHRPFkQ0
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,iUzhMjqu1OQ7)
	return
def admShRbHg1IVFefqZL9XUjGrP0():
	o7PS8y2BhurTg9b,gfVQyGTx6tPw,qQ96bYdXstPHcAvkZGNVo = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,kh850jKbzmBwY,kh850jKbzmBwY
	jfy0DQ6bCdtpLP8oFa9XAexkh5zv7,cT58HNQXtVKOPo1yluB7nsRU0I2D,VAYJ2KbCU6pdWuQhcTa = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,kh850jKbzmBwY,kh850jKbzmBwY
	scnXa48BzVCG7U0 = [HfuZG0aphlYnVLOyAk93rj(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫዹ"),BBOY8rvinVbFh(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩዺ"),Urj6egiVyHA75ZK(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧዻ")]
	p9XQ5ELjTtvSUyCZMzuPfq = toPT5OnwVCDE7Rci1x3vZ0aB2Ymzrj(scnXa48BzVCG7U0)
	for AF8yoQXOqHLfvhGC4 in scnXa48BzVCG7U0:
		if AF8yoQXOqHLfvhGC4 not in list(p9XQ5ELjTtvSUyCZMzuPfq.keys()): continue
		e5z2d6xF1A8t,kB7S62uJHgG4,bclGNvZLa54idPETOJuWI9mz,ntJOsPgNfpuqDCT4rLMcU,D96pLZ0Q3Rqm7rd5ksUGTAXMPNji,wu4vJRqY8jt,SuRoO6KYB4QXgDajVI9k5sJC = p9XQ5ELjTtvSUyCZMzuPfq[AF8yoQXOqHLfvhGC4]
		if AF8yoQXOqHLfvhGC4==NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧዼ"):
			jfy0DQ6bCdtpLP8oFa9XAexkh5zv7 = e5z2d6xF1A8t
			cT58HNQXtVKOPo1yluB7nsRU0I2D = kB7S62uJHgG4+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࠤࠥࠦࠠࠩࠢࠪዽ")+Hczgh3TNkKXoq4AZ1wJiC(wu4vJRqY8jt)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠫࠥ࠯ࠧዾ")
			VAYJ2KbCU6pdWuQhcTa = ntJOsPgNfpuqDCT4rLMcU
		elif AF8yoQXOqHLfvhGC4==CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧዿ"):
			o7PS8y2BhurTg9b = o7PS8y2BhurTg9b or e5z2d6xF1A8t
			gfVQyGTx6tPw += YoMw2J1Ljp(u"࠭ࠠࠡ࠮ࠣࠤࠬጀ")+kB7S62uJHgG4+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧጁ")+Hczgh3TNkKXoq4AZ1wJiC(wu4vJRqY8jt)+gNPRXprEAQJ(u"ࠨࠢࠬࠫጂ")
			qQ96bYdXstPHcAvkZGNVo += x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩࠣࠤ࠱ࠦࠠࠨጃ")+ntJOsPgNfpuqDCT4rLMcU
		elif AF8yoQXOqHLfvhGC4==aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩጄ"):
			s2WmiGfEjUkgNzbon4qVvJpxYSAIO = e5z2d6xF1A8t
			RRaUsHXrZOL = kB7S62uJHgG4+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࠥࠦࠠࠡࠪࠣࠫጅ")+Hczgh3TNkKXoq4AZ1wJiC(wu4vJRqY8jt)+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࠦࠩࠨጆ")
			duT8z5w1D64kpU2QXFbPMoSVsrOxig = ntJOsPgNfpuqDCT4rLMcU
	gfVQyGTx6tPw = gfVQyGTx6tPw.strip(ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࠠࠡ࠮ࠣࠤࠬጇ"))
	qQ96bYdXstPHcAvkZGNVo = qQ96bYdXstPHcAvkZGNVo.strip(HHthiRYs8T6IO3qUyX(u"ࠧࠡࠢ࠯ࠤࠥ࠭ገ"))
	LR7saxGkNb6VYzyI4  = u8iSx05wLfVyMNp1X3l(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ጉ")+RlMpu0hP8YmzZovkVXOs1G+VAYJ2KbCU6pdWuQhcTa+wVvqN8LZCJW5ryAb1EHRPFkQ0
	LR7saxGkNb6VYzyI4 += URBvawyLXfQiS2NI34HDk+BBOY8rvinVbFh(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫጊ")+RlMpu0hP8YmzZovkVXOs1G+cT58HNQXtVKOPo1yluB7nsRU0I2D+wVvqN8LZCJW5ryAb1EHRPFkQ0
	LR7saxGkNb6VYzyI4 += aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡠࡳࡢ࡮ࠨጋ")+u8iSx05wLfVyMNp1X3l(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำู่๊ࠣส้ั฼ࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩጌ")+RlMpu0hP8YmzZovkVXOs1G+qQ96bYdXstPHcAvkZGNVo+wVvqN8LZCJW5ryAb1EHRPFkQ0
	LR7saxGkNb6VYzyI4 += URBvawyLXfQiS2NI34HDk+J6G8X3gO1MiKh027D(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅ็ึฮํีูࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧግ")+RlMpu0hP8YmzZovkVXOs1G+gfVQyGTx6tPw+wVvqN8LZCJW5ryAb1EHRPFkQ0
	LR7saxGkNb6VYzyI4 += gNPRXprEAQJ(u"࠭࡜࡯࡞ࡱࠫጎ")+dQvxmFkyLOteNMWBJ2bDHV(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫጏ")+RlMpu0hP8YmzZovkVXOs1G+duT8z5w1D64kpU2QXFbPMoSVsrOxig+wVvqN8LZCJW5ryAb1EHRPFkQ0
	LR7saxGkNb6VYzyI4 += URBvawyLXfQiS2NI34HDk+tzEjvOaZWU1A(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩጐ")+RlMpu0hP8YmzZovkVXOs1G+RRaUsHXrZOL+wVvqN8LZCJW5ryAb1EHRPFkQ0
	e5z2d6xF1A8t = jfy0DQ6bCdtpLP8oFa9XAexkh5zv7 or o7PS8y2BhurTg9b
	if e5z2d6xF1A8t:
		header = WlU7AtONpyj3(u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫ጑")
		lXWDJRvQFImZh = tzEjvOaZWU1A(u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫጒ")
	else:
		header = CMUXq6mPQV5rLsSBdWZJvA(u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬጓ")
		lXWDJRvQFImZh = Urj6egiVyHA75ZK(u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧጔ")
	wXGMtCzZqK87Ru9vFybls = taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧጕ")
	ii2qPHKtfmDzS4XjrCyQah67cMI = LR7saxGkNb6VYzyI4+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠧ࡝ࡰ࡟ࡲࠬ጖")+lXWDJRvQFImZh+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࡞ࡱࡠࡳ࠭጗")+wXGMtCzZqK87Ru9vFybls
	KKHpNde5TOmYqjIygtlwhf7W2sr(u8iSx05wLfVyMNp1X3l(u"ࠩࡵ࡭࡬࡮ࡴࠨጘ"),header,ii2qPHKtfmDzS4XjrCyQah67cMI,HHthiRYs8T6IO3qUyX(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ጙ"))
	return e5z2d6xF1A8t
def wwQH0OrJK467EjF5(AF8yoQXOqHLfvhGC4,SuRoO6KYB4QXgDajVI9k5sJC,showDialogs):
	jVhaOJ9utFmLGZpHceKNMlE = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if showDialogs:
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,HHthiRYs8T6IO3qUyX(u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧጚ"))
		if II7ErX2ocuU!=igM4DhpPzoX95Ysnar6Auj: return wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	Igjt50Suy2N6leUfsiq = RQgkpZOda5yorDl(SuRoO6KYB4QXgDajVI9k5sJC,{},showDialogs)
	if Igjt50Suy2N6leUfsiq:
		TTqRaQpEFYzWPlAognwU = YdDkIjFhgzuboBKca70ERt.path.join(UVJ84eNx6jG1Owy7rI,AF8yoQXOqHLfvhGC4)
		LAqRc0J9jSY(TTqRaQpEFYzWPlAognwU,dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		import zipfile as hht0dqDJ8bBWM,io as LmtZjJnQV9vWpK8dqcfehXDSA
		zt4uhXg3droNWxfFlG1VO8TymjY0 = LmtZjJnQV9vWpK8dqcfehXDSA.BytesIO(Igjt50Suy2N6leUfsiq)
		try:
			Oi3BalK5cXAgp21efvukV7F = hht0dqDJ8bBWM.ZipFile(zt4uhXg3droNWxfFlG1VO8TymjY0)
			Oi3BalK5cXAgp21efvukV7F.extractall(UVJ84eNx6jG1Owy7rI)
			pVesmhFG6wgubAODHSKvN1Wx.sleep(igM4DhpPzoX95Ysnar6Auj)
			ppNwDFByU1dZn5ca.executebuiltin(tzEjvOaZWU1A(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩጛ"))
			pVesmhFG6wgubAODHSKvN1Wx.sleep(igM4DhpPzoX95Ysnar6Auj)
			jVhaOJ9utFmLGZpHceKNMlE = nGC9NLBoEHgje(AF8yoQXOqHLfvhGC4)
		except: jVhaOJ9utFmLGZpHceKNMlE = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if showDialogs:
		if jVhaOJ9utFmLGZpHceKNMlE: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,dQvxmFkyLOteNMWBJ2bDHV(u"࠭สๆࠢห๊ัออࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪጜ"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,YoMw2J1Ljp(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬጝ"))
	return jVhaOJ9utFmLGZpHceKNMlE
def BfnJNmF3wajrI5hqTQuzpVOds(AF8yoQXOqHLfvhGC4,showDialogs=dbo4vrnTM56I):
	if showDialogs==kh850jKbzmBwY: showDialogs = dbo4vrnTM56I
	zXA3Mx0NnmP95Gf8glyqJkcLeE = RxMv42cqGKBNhSas6Q0([AF8yoQXOqHLfvhGC4])
	aRG3W12LS9ekXwxAcBY5Td4zZMQO,ddiJ3rZtx2veLCU7RmyFk = zXA3Mx0NnmP95Gf8glyqJkcLeE[AF8yoQXOqHLfvhGC4]
	if ddiJ3rZtx2veLCU7RmyFk:
		jVhaOJ9utFmLGZpHceKNMlE = dbo4vrnTM56I
		if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,CMUXq6mPQV5rLsSBdWZJvA(u"ࠨใะูࠥอไฦุสๅฮࠦ࡜࡯ࠢࠪጞ")+AF8yoQXOqHLfvhGC4+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไ่ࠢ์ั๎ฯส๋้ࠢๆ฿ไส๋ࠢะฬําสࠢ็่ฬูสฯัส้ࠬጟ"))
	else:
		jVhaOJ9utFmLGZpHceKNMlE = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(J6G8X3gO1MiKh027D(u"ࠪࡧࡪࡴࡴࡦࡴࠪጠ"),kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,kh850jKbzmBwY+AF8yoQXOqHLfvhGC4+WlU7AtONpyj3(u"ࠫࠥࡢ࡮࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯส๋ࠢห้ฮั็ษ่ะࠥฮอศฮฬࠤ้ํวࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨጡ"))
		if II7ErX2ocuU==Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠱ᐒ"):
			ppNwDFByU1dZn5ca.executebuiltin(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࡏ࡮ࡴࡶࡤࡰࡱࡇࡤࡥࡱࡱࠬࠬጢ")+AF8yoQXOqHLfvhGC4+wb1nC3e8AjRVU4ovsuPa(u"࠭ࠩࠨጣ"))
			pVesmhFG6wgubAODHSKvN1Wx.sleep(tzEjvOaZWU1A(u"࠲ᐓ"))
			ppNwDFByU1dZn5ca.executebuiltin(u8iSx05wLfVyMNp1X3l(u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯ࠧጤ"))
			pVesmhFG6wgubAODHSKvN1Wx.sleep(FkqI4Gm8wMvUVbgo(u"࠳ᐔ"))
			while ppNwDFByU1dZn5ca.getCondVisibility(YoMw2J1Ljp(u"ࠨ࡙࡬ࡲࡩࡵࡷ࠯ࡋࡶࡅࡨࡺࡩࡷࡧࠫࡴࡷࡵࡧࡳࡧࡶࡷࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬጥ")): pVesmhFG6wgubAODHSKvN1Wx.sleep(dQvxmFkyLOteNMWBJ2bDHV(u"࠴ᐕ"))
			jVhaOJ9utFmLGZpHceKNMlE = nGC9NLBoEHgje(AF8yoQXOqHLfvhGC4)
			if showDialogs and jVhaOJ9utFmLGZpHceKNMlE: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,BBOY8rvinVbFh(u"ࠩอ้ࠥ็อึࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ๎็๋ࠢส่ว์ࠠอษ๊ึฮࠦไๅษึฮำีวๆࠩጦ"))
			elif showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬጧ"))
	return jVhaOJ9utFmLGZpHceKNMlE
def Q7ec2iEWwNhKSUB3zX(showDialogs):
	if not showDialogs: II7ErX2ocuU = dbo4vrnTM56I
	else: II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫጨ"),kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ZeV4vau9CjN(u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡล้ࠤฯ฽ไษ่๊้่ࠢࠥะ์ࠣๅา฻้ࠠฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠภࠩጩ"))
	if II7ErX2ocuU==WlU7AtONpyj3(u"࠵ᐖ"):
		ppNwDFByU1dZn5ca.executebuiltin(gNPRXprEAQJ(u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩጪ"))
		if showDialogs:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,dQvxmFkyLOteNMWBJ2bDHV(u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ึฮํีูࠡ฻่หิࠦ࠮ࠡ์ิะ๎ࠦลฺูสล้่ࠥะ์ࠣ࠹ࠥีโศศๅࠤศ๎ࠠฤๅฮี๊ࠥใ๋ࠢํ๊์๐ฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠧጫ"))
	return
def bcJCAsovQl0dkSKR():
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭ጬ"),Urj6egiVyHA75ZK(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪጭ"))
	OBkhYLsyTmRjfAdP()
	e5z2d6xF1A8t = admShRbHg1IVFefqZL9XUjGrP0()
	if e5z2d6xF1A8t:
		iQdx2LevkbrEK7OAT(dbo4vrnTM56I)
		Q7ec2iEWwNhKSUB3zX(dbo4vrnTM56I)
		EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def nGC9NLBoEHgje(AF8yoQXOqHLfvhGC4):
	PP3FsDicLyWuTR7GV5Ia = ppNwDFByU1dZn5ca.executeJSONRPC(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ጮ")+AF8yoQXOqHLfvhGC4+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩጯ"))
	succeeded = dbo4vrnTM56I if taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬࡕࡋࠨጰ") in PP3FsDicLyWuTR7GV5Ia else wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	return succeeded
def s08sXdjR15laN9eoEkMi(AF8yoQXOqHLfvhGC4):
	PP3FsDicLyWuTR7GV5Ia = ppNwDFByU1dZn5ca.executeJSONRPC(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩጱ")+AF8yoQXOqHLfvhGC4+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭ጲ"))
	succeeded = dbo4vrnTM56I if ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨࡑࡎࠫጳ") in PP3FsDicLyWuTR7GV5Ia else wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	return succeeded
def nbIzqZLsiEkfX1Op(AF8yoQXOqHLfvhGC4,showDialogs,Bqo0QwKYRahy,p9XQ5ELjTtvSUyCZMzuPfq=None):
	II7ErX2ocuU,succeeded,ZITdOLbAx7QE6azk342C,kB7S62uJHgG4 = dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,tzEjvOaZWU1A(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩጴ"),kh850jKbzmBwY
	if not p9XQ5ELjTtvSUyCZMzuPfq: p9XQ5ELjTtvSUyCZMzuPfq = toPT5OnwVCDE7Rci1x3vZ0aB2Ymzrj([AF8yoQXOqHLfvhGC4])
	if AF8yoQXOqHLfvhGC4 in list(p9XQ5ELjTtvSUyCZMzuPfq.keys()):
		e5z2d6xF1A8t,kB7S62uJHgG4,bclGNvZLa54idPETOJuWI9mz,ntJOsPgNfpuqDCT4rLMcU,D96pLZ0Q3Rqm7rd5ksUGTAXMPNji,wu4vJRqY8jt,SuRoO6KYB4QXgDajVI9k5sJC = p9XQ5ELjTtvSUyCZMzuPfq[AF8yoQXOqHLfvhGC4]
		if wu4vJRqY8jt==A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪ࡫ࡴࡵࡤࠨጵ"):
			succeeded,ZITdOLbAx7QE6azk342C = dbo4vrnTM56I,u8iSx05wLfVyMNp1X3l(u"ࠫࡳࡵࡴࡩ࡫ࡱ࡫ࠬጶ")
			if Bqo0QwKYRahy and showDialogs:
				II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,dQvxmFkyLOteNMWBJ2bDHV(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬጷ")+AF8yoQXOqHLfvhGC4+wb1nC3e8AjRVU4ovsuPa(u"࠭࡜࡯࡞ࡱ๋้ࠦสา์าࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠๆำฬࠤศิั๊ࠩጸ"))
				if II7ErX2ocuU:
					succeeded = wwQH0OrJK467EjF5(AF8yoQXOqHLfvhGC4,SuRoO6KYB4QXgDajVI9k5sJC,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
					if succeeded:
						ZITdOLbAx7QE6azk342C = ZeV4vau9CjN(u"ࠧࡳࡧ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬጹ")
						if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ๊๎ฬ้ัฬࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษว฼หิฯࠠหอห๎ฯํว࡝ࡰ࡟ࡲࠬጺ")+AF8yoQXOqHLfvhGC4)
					else:
						ZITdOLbAx7QE6azk342C = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩጻ")
						o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,z8wTfYPiRQL(u"่้ࠪษำโࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ฾อฯสࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪጼ")+AF8yoQXOqHLfvhGC4)
		else:
			if showDialogs:
				if wu4vJRqY8jt==G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ጽ"): gfe2BNJ3kTF0Xx = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"๋ࠬส้ไไอࠬጾ")
				elif wu4vJRqY8jt==NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭࡯࡭ࡦࠪጿ"): gfe2BNJ3kTF0Xx = aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧใัํ้ฮ࠭ፀ")
				elif wu4vJRqY8jt==MBS1GrwQoUlsiIRfVDOHdA(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩፁ"): gfe2BNJ3kTF0Xx = Urj6egiVyHA75ZK(u"ࠩ฽๎ึࠦๅฬสออࠬፂ")
				II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"๋ࠪีํࠠศๆศฺฬ็ษࠡࠩፃ")+gfe2BNJ3kTF0Xx+aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦฟࠢ࡞ࡱࡠࡳ࠭ፄ")+AF8yoQXOqHLfvhGC4)
			if not II7ErX2ocuU: ZITdOLbAx7QE6azk342C = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧፅ")
			else:
				if wu4vJRqY8jt==oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨፆ"):
					succeeded = nGC9NLBoEHgje(AF8yoQXOqHLfvhGC4)
					if succeeded:
						ZITdOLbAx7QE6azk342C = dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨፇ")
						if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,dQvxmFkyLOteNMWBJ2bDHV(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭ፈ")+AF8yoQXOqHLfvhGC4)
					elif showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ลืษไอ๋ࠥส้ไไอࠥ࠴࠮๊ࠡ็้ࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠหึ฽๎้ํว࡝ࡰ࡟ࡲࠬፉ")+AF8yoQXOqHLfvhGC4)
				elif wu4vJRqY8jt in [aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡳࡱࡪࠧፊ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬፋ")]:
					succeeded = wwQH0OrJK467EjF5(AF8yoQXOqHLfvhGC4,SuRoO6KYB4QXgDajVI9k5sJC,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
					if succeeded:
						if wu4vJRqY8jt==J6G8X3gO1MiKh027D(u"ࠬࡵ࡬ࡥࠩፌ"): ZITdOLbAx7QE6azk342C = YoMw2J1Ljp(u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧፍ")
						elif wu4vJRqY8jt==gNPRXprEAQJ(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨፎ"): ZITdOLbAx7QE6azk342C = oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫፏ")
						kB7S62uJHgG4 = ntJOsPgNfpuqDCT4rLMcU
						if showDialogs:
							if ZITdOLbAx7QE6azk342C==qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪፐ"): o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,z8wTfYPiRQL(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦโะ์่อࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอัิ๐ห่ษ࡟ࡲࡡࡴࠧፑ")+AF8yoQXOqHLfvhGC4)
							elif ZITdOLbAx7QE6azk342C==z8wTfYPiRQL(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧፒ"): o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,XasF0WO7rDUHnEt8hAl9kLN(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ፓ")+AF8yoQXOqHLfvhGC4)
					elif showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦสฮัํฯࠥษ่ࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩፔ")+AF8yoQXOqHLfvhGC4)
	elif showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,BBOY8rvinVbFh(u"ࠧๅๆฦืๆࠦ࠮࠯๊ࠢิ์ࠦวๅวูหๆฯࠠ฻์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴࠮๊ࠡ็๋ีอࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥษๆࠡ์ๅ์๊ࠦศหอห๎ฯࠦ็ั้ࠣห้หึศใฬࠤศ๎ࠠหฯา๎ะํว࡝ࡰ࡟ࡲࠬፕ")+AF8yoQXOqHLfvhGC4)
	return succeeded,ZITdOLbAx7QE6azk342C,kB7S62uJHgG4
def oDNVl1FR4raneiWhYC6tE58(AF8yoQXOqHLfvhGC4,showDialogs,RRCXac4h8JQed):
	M3MgquCJ4R2ULBeln = JFCUilw8a9NdZSGtm.connect(C69OKz3wk0dSb)
	M3MgquCJ4R2ULBeln.text_factory = str
	YZI1eGP3xaRoBul = M3MgquCJ4R2ULBeln.cursor()
	succeeded,VK5U0JjdRoFna1tAOePyz = dbo4vrnTM56I,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	try:
		u6tV4I1mOAEUcTj = taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪፖ")
		YZI1eGP3xaRoBul.execute(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧፗ")+AF8yoQXOqHLfvhGC4+HHthiRYs8T6IO3qUyX(u"ࠪࠦࠥࡁࠧፘ"))
		wfZ3SeHKbUEq7XAhg9iODnLQ6l = YZI1eGP3xaRoBul.fetchall()
		if wfZ3SeHKbUEq7XAhg9iODnLQ6l and u6tV4I1mOAEUcTj not in str(wfZ3SeHKbUEq7XAhg9iODnLQ6l): YZI1eGP3xaRoBul.execute(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨፙ")+u6tV4I1mOAEUcTj+Urj6egiVyHA75ZK(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫፚ")+AF8yoQXOqHLfvhGC4+tzEjvOaZWU1A(u"࠭ࠢࠡ࠽ࠪ፛"))
		LLnw8QjauHEVOmvi = NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪ፜") if BBJYzRKgHkOqx else G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧ፝")
		YZI1eGP3xaRoBul.execute(taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠪ፞")+LLnw8QjauHEVOmvi+Urj6egiVyHA75ZK(u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ፟")+AF8yoQXOqHLfvhGC4+YoMw2J1Ljp(u"ࠫࠧࠦ࠻ࠨ፠"))
		wfZ3SeHKbUEq7XAhg9iODnLQ6l = YZI1eGP3xaRoBul.fetchall()
		if wfZ3SeHKbUEq7XAhg9iODnLQ6l:
			if showDialogs: II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩ፡")+AF8yoQXOqHLfvhGC4+z8wTfYPiRQL(u"࠭ࠠ࡝ࡰ࡟ࡲࠥ࠭።")+HHFAVK8SwRUqBLuTfdeJ9nbD+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࠡ็อ์็็้ࠠๆสࠤ๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสโ฻ํ่์ࠦวๅฤ้ࠤฤࠧࠡࠡࠩ፣")+wVvqN8LZCJW5ryAb1EHRPFkQ0+HfuZG0aphlYnVLOyAk93rj(u"ࠨࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠฦ์ๅหๆํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสุࠢ๎ฬ์ษࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭፤"))
			else: II7ErX2ocuU = igM4DhpPzoX95Ysnar6Auj
			if II7ErX2ocuU==igM4DhpPzoX95Ysnar6Auj:
				VK5U0JjdRoFna1tAOePyz = dbo4vrnTM56I
				YZI1eGP3xaRoBul.execute(FkqI4Gm8wMvUVbgo(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨ፥")+LLnw8QjauHEVOmvi+kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ፦")+AF8yoQXOqHLfvhGC4+XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࠧࠦ࠻ࠨ፧"))
		elif RRCXac4h8JQed:
			if showDialogs: II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,WlU7AtONpyj3(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩ፨")+AF8yoQXOqHLfvhGC4+taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࠠ࡝ࡰ࡟ࡲࠥ࠭፩")+HHFAVK8SwRUqBLuTfdeJ9nbD+A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠧࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࠬ፪")+wVvqN8LZCJW5ryAb1EHRPFkQ0+MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสุࠢ๎ฬ์ษࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭፫"))
			else: II7ErX2ocuU = igM4DhpPzoX95Ysnar6Auj
			if II7ErX2ocuU==igM4DhpPzoX95Ysnar6Auj:
				VK5U0JjdRoFna1tAOePyz = dbo4vrnTM56I
				if BBJYzRKgHkOqx: YZI1eGP3xaRoBul.execute(BBOY8rvinVbFh(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠨ፬")+LLnw8QjauHEVOmvi+z8wTfYPiRQL(u"ࠪࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪ፭")+AF8yoQXOqHLfvhGC4+dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࠧ࠯ࠠ࠼ࠩ፮"))
				else: YZI1eGP3xaRoBul.execute(wb1nC3e8AjRVU4ovsuPa(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫ፯")+LLnw8QjauHEVOmvi+ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࠮ࡸࡴࡩࡧࡴࡦࡔࡸࡰࡪ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪ፰")+AF8yoQXOqHLfvhGC4+BBOY8rvinVbFh(u"ࠧࠣ࠮࠴࠭ࠥࡁࠧ፱"))
	except: succeeded = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	M3MgquCJ4R2ULBeln.commit()
	M3MgquCJ4R2ULBeln.close()
	if VK5U0JjdRoFna1tAOePyz:
		pVesmhFG6wgubAODHSKvN1Wx.sleep(BBOY8rvinVbFh(u"࠶ᐗ"))
		ppNwDFByU1dZn5ca.executebuiltin(gNPRXprEAQJ(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ፲"))
		pVesmhFG6wgubAODHSKvN1Wx.sleep(Urj6egiVyHA75ZK(u"࠷ᐘ"))
		if showDialogs:
			if succeeded: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,taD1d3bpqyfM4VNhK0P29GSZ(u"้ࠩะาะฺࠠ็็๎ฮࠦลึๆสัࠥะอะ์ฮࠤฬ๊ลืษไอࠥࡢ࡮࡝ࡰࠪ፳")+AF8yoQXOqHLfvhGC4)
			else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,WlU7AtONpyj3(u"ࠪๅู๊สࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫ፴")+AF8yoQXOqHLfvhGC4)
	return VK5U0JjdRoFna1tAOePyz
def JzWXiMVkU8cp41nPHC7ZyDQAf(scnXa48BzVCG7U0,showDialogs,Bqo0QwKYRahy,RRCXac4h8JQed):
	p9XQ5ELjTtvSUyCZMzuPfq = toPT5OnwVCDE7Rci1x3vZ0aB2Ymzrj(scnXa48BzVCG7U0)
	KKzL1IoAhV47mUERMler9csdG = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	for AF8yoQXOqHLfvhGC4 in scnXa48BzVCG7U0:
		succeeded,ZITdOLbAx7QE6azk342C,kB7S62uJHgG4 = nbIzqZLsiEkfX1Op(AF8yoQXOqHLfvhGC4,showDialogs,Bqo0QwKYRahy,p9XQ5ELjTtvSUyCZMzuPfq)
		VK5U0JjdRoFna1tAOePyz = oDNVl1FR4raneiWhYC6tE58(AF8yoQXOqHLfvhGC4,showDialogs,RRCXac4h8JQed)
		if VK5U0JjdRoFna1tAOePyz: KKzL1IoAhV47mUERMler9csdG = dbo4vrnTM56I
	if KKzL1IoAhV47mUERMler9csdG:
		pVesmhFG6wgubAODHSKvN1Wx.sleep(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠱ᐙ"))
		ppNwDFByU1dZn5ca.executebuiltin(tzEjvOaZWU1A(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ፵"))
		pVesmhFG6wgubAODHSKvN1Wx.sleep(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠲ᐚ"))
	if showDialogs:
		if len(scnXa48BzVCG7U0)>x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠳ᐛ"): o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬะๅࠡส้ะฬำࠠโฯุࠤัฺ๋๊ࠢส่ส฼วโษอࠫ፶"))
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭สๆࠢห๊ัออࠡใะูࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ፷")+scnXa48BzVCG7U0[G6GUCto502jZTLubYNnqMx8ywBah(u"࠳ᐜ")])
	return
def iQdx2LevkbrEK7OAT(showDialogs):
	REFswck3mJ7xzAI = [HfuZG0aphlYnVLOyAk93rj(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ፸"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ፹"),tzEjvOaZWU1A(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭፺"),Urj6egiVyHA75ZK(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪ፻")]
	tWk7YSVMBZN1le3rDTo = [z8wTfYPiRQL(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴࡯ࡵࡪࡨࡶࡸ࠭፼"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡪ࠭፽"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦࠩ፾"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩ፿"),wb1nC3e8AjRVU4ovsuPa(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩᎀ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡨࡵࡤࡦࡤࡨࡶ࡬࠭ᎁ")]
	for AF8yoQXOqHLfvhGC4 in tWk7YSVMBZN1le3rDTo: s08sXdjR15laN9eoEkMi(AF8yoQXOqHLfvhGC4)
	JzWXiMVkU8cp41nPHC7ZyDQAf(REFswck3mJ7xzAI,showDialogs,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
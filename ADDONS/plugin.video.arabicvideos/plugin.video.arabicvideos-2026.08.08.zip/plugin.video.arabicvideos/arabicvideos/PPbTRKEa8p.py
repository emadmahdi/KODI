# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SHOOFNET'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SNT_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الرئيسية','يلا شوت','دكتنا','فيديو نسائم']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==840: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==841: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==842: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==843: PP3FsDicLyWuTR7GV5Ia = sGaLKXvqkC(url)
	elif mode==849: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFNET-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,849,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"primary-links"(.*?)</u',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,841)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"list-categories"(.*?)</u',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,841)
	return
def bsZhnoqjD3U(url,x9XP1ec8DolGwABgkiIJyq=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFNET-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-content"(.*?)"footer"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"overlay"','"duration"><')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		SHTvIuhX52dxQRsWA = []
		for NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,Ga8xfYU6ht7cHjzn,title in items:
			title = title.strip(' ')
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if 'episodes' not in x9XP1ec8DolGwABgkiIJyq and WULSmfNH09tPIv58snzpCkR:
				title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
				title = title.replace('اون لاين',kh850jKbzmBwY)
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,843,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,842,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''["']pagination["'](.*?)["']footer["']''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		x9XP1ec8DolGwABgkiIJyq = 'episodes_pages' if 'episodes' in x9XP1ec8DolGwABgkiIJyq else 'pages'
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,841,kh850jKbzmBwY,kh850jKbzmBwY,x9XP1ec8DolGwABgkiIJyq)
	return
def sGaLKXvqkC(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFNET-SERIES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"category".*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if Ga8xfYU6ht7cHjzn: bsZhnoqjD3U(Ga8xfYU6ht7cHjzn[0],'episodes')
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFNET-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	bYXVGSPi1DC6kIh9BE7j3esN0mfQg = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("var post_id	= '(.*?)'",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if bYXVGSPi1DC6kIh9BE7j3esN0mfQg:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/wp-admin/admin-ajax.php?action=video_info&post_id='+bYXVGSPi1DC6kIh9BE7j3esN0mfQg[0]
		headers = {'Referer':url}
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',Ga8xfYU6ht7cHjzn,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFNET-PLAY-2nd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"name":"(.*?)","src":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for title,Ga8xfYU6ht7cHjzn in items:
			title = Z4CP1xs5w7fi(title)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?s='+search
	bsZhnoqjD3U(url,'search')
	return
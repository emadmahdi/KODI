# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SERIES4WATCH'
headers = { 'User-Agent' : kh850jKbzmBwY }
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SFW_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==210: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==211: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==212: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==213: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==214: PP3FsDicLyWuTR7GV5Ia = QNyI9sWA8UOtpfc1vj3PBgbT(url)
	elif mode==215: PP3FsDicLyWuTR7GV5Ia = t1zMejAolV3Hp9JYLqKChafR85yuX(url)
	elif mode==218: PP3FsDicLyWuTR7GV5Ia = qW0zupKTfGon5BMSkxy3LEOvP()
	elif mode==219: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def qW0zupKTfGon5BMSkxy3LEOvP():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'الموقع تغير بالكامل',message)
	return
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,219,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/getpostsPin?type=one&data=pin&limit=25'
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',url,211)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'SERIES4WATCH-MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('FiltersButtons(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-get="(.*?)".*?</i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/getposts?type=one&data='+Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,211)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('navigation-menu(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(http.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['مسلسلات انمي','الرئيسية']
	for Ga8xfYU6ht7cHjzn,title in items:
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,211)
	return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('MediaGrid"(.*?)class="pagination"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		else: return
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	FfMaBDcVKlON = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		if '/series/' in Ga8xfYU6ht7cHjzn: continue
		Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn).strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if '/film/' in Ga8xfYU6ht7cHjzn or any(value in title for value in FfMaBDcVKlON):
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,212,NWqAr40jTLlMBemn3o79y)
		elif '/episode/' in Ga8xfYU6ht7cHjzn and 'الحلقة' in title:
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if WULSmfNH09tPIv58snzpCkR:
				title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,213,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,213,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(Ga8xfYU6ht7cHjzn)
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			title = title.replace('الصفحة ',kh850jKbzmBwY)
			if title!=kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,211)
	return
def do7Es2fUtFlM8ScLx(url):
	QQkebwGuqUcmrYO6tNhK1xF2jAPfL,items,t9T0AqyFcxHVzpnMWlad1CLk4ZhE = -1,[],[]
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'SERIES4WATCH-EPISODES-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('ti-list-numbered(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		tKoDYsOPeyxM = kh850jKbzmBwY.join(liroJ6qCK9k)
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"',tKoDYsOPeyxM,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	items.append(url)
	items = set(items)
	for Ga8xfYU6ht7cHjzn in items:
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		title = '_MOD_' + Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1].replace('-',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		hUfv2IrbNmXRzGPMdt = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('الحلقة-(\d+)',Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1],sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if hUfv2IrbNmXRzGPMdt: hUfv2IrbNmXRzGPMdt = hUfv2IrbNmXRzGPMdt[0]
		else: hUfv2IrbNmXRzGPMdt = '0'
		t9T0AqyFcxHVzpnMWlad1CLk4ZhE.append([Ga8xfYU6ht7cHjzn,title,hUfv2IrbNmXRzGPMdt])
	items = sorted(t9T0AqyFcxHVzpnMWlad1CLk4ZhE, reverse=False, key=lambda key: int(key[2]))
	b3OxNkBMcG2 = str(items).count('/season/')
	QQkebwGuqUcmrYO6tNhK1xF2jAPfL = str(items).count('/episode/')
	if b3OxNkBMcG2>1 and QQkebwGuqUcmrYO6tNhK1xF2jAPfL>0 and '/season/' not in url:
		for Ga8xfYU6ht7cHjzn,title,hUfv2IrbNmXRzGPMdt in items:
			if '/season/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,213)
	else:
		for Ga8xfYU6ht7cHjzn,title,hUfv2IrbNmXRzGPMdt in items:
			if '/season/' not in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,212)
	return
def yv8LezRQifhw1Kx(url):
	lnYtOIQ4Rkh386Bca7 = []
	VQfK9Lr0j75zHwg1xOGY = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in uP1m46pAK5a3UgdqvBz9rnL:
		O9wzaDlICnq = url.replace(VQfK9Lr0j75zHwg1xOGY[3],'watch')
		kKwr9zX358QO47tbu1UC2 = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,'SERIES4WATCH-PLAY-2nd')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="servers-list(.*?)</div>',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if items:
				id = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('post_id=(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if id:
					zzRGXieSsdC89MgBJDWL1IwPUFoak = id[0]
					for Ga8xfYU6ht7cHjzn,title in items:
						Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?postid='+zzRGXieSsdC89MgBJDWL1IwPUFoak+'&serverid='+Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
						lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
			else:
				items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-embedd=".*?(http.*?)("|&quot;)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				for Ga8xfYU6ht7cHjzn,W7BTt4f3CkhKJIY in items:
					lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	if '/download/' in uP1m46pAK5a3UgdqvBz9rnL:
		O9wzaDlICnq = url.replace(VQfK9Lr0j75zHwg1xOGY[3],'download')
		kKwr9zX358QO47tbu1UC2 = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,'SERIES4WATCH-PLAY-3rd')
		id = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('postId:"(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if id:
			zzRGXieSsdC89MgBJDWL1IwPUFoak = id[0]
			tqQkcdHYyM3L7h = { 'User-Agent':kh850jKbzmBwY , 'X-Requested-With':'XMLHttpRequest' }
			O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/ajaxCenter?_action=getdownloadlinks&postId='+zzRGXieSsdC89MgBJDWL1IwPUFoak
			kKwr9zX358QO47tbu1UC2 = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,tqQkcdHYyM3L7h,kh850jKbzmBwY,'SERIES4WATCH-PLAY-4th')
			liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<h3.*?(\d+)(.*?)</div>',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if liroJ6qCK9k:
				for zVGvBU4MkeqfxyNprhZSgmjai6,ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
					items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<td>(.*?)<.*?href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
					for name,Ga8xfYU6ht7cHjzn in items:
						lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn+'?named='+name+'__download'+'____'+zVGvBU4MkeqfxyNprhZSgmjai6)
			else:
				liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<h6(.*?)</table>',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if not liroJ6qCK9k: liroJ6qCK9k = [kKwr9zX358QO47tbu1UC2]
				for ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
					name = kh850jKbzmBwY
					items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(http.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
					for Ga8xfYU6ht7cHjzn in items:
						fDKF4iZ5rz7McduTexbA2RpPs = '&&' + Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[2].lower() + '&&'
						fDKF4iZ5rz7McduTexbA2RpPs = fDKF4iZ5rz7McduTexbA2RpPs.replace('.com&&',kh850jKbzmBwY).replace('.co&&',kh850jKbzmBwY)
						fDKF4iZ5rz7McduTexbA2RpPs = fDKF4iZ5rz7McduTexbA2RpPs.replace('.net&&',kh850jKbzmBwY).replace('.org&&',kh850jKbzmBwY)
						fDKF4iZ5rz7McduTexbA2RpPs = fDKF4iZ5rz7McduTexbA2RpPs.replace('.live&&',kh850jKbzmBwY).replace('.online&&',kh850jKbzmBwY)
						fDKF4iZ5rz7McduTexbA2RpPs = fDKF4iZ5rz7McduTexbA2RpPs.replace('&&hd.',kh850jKbzmBwY).replace('&&www.',kh850jKbzmBwY)
						fDKF4iZ5rz7McduTexbA2RpPs = fDKF4iZ5rz7McduTexbA2RpPs.replace('&&',kh850jKbzmBwY)
						Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + name + fDKF4iZ5rz7McduTexbA2RpPs + '__download'
						lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search?s='+search
	bsZhnoqjD3U(url)
	return
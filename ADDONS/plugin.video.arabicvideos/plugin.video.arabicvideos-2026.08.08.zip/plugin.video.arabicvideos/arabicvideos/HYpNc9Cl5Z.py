# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SERIESTIME'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SRT_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الرئيسية','يلا شوت']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==890: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==891: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==892: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==893: PP3FsDicLyWuTR7GV5Ia = sGaLKXvqkC(url)
	elif mode==899: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SERIESTIME-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,899,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"list-categories"(.*?)</u',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.lstrip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,891)
	return
def bsZhnoqjD3U(url,type=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SERIESTIME-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-content"(.*?)"footer"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"overlay"','"duration"><')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		SHTvIuhX52dxQRsWA = []
		for NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = ioZ083zxYk(Ga8xfYU6ht7cHjzn)
			title = title.strip(' ')
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if 'episodes' not in type and WULSmfNH09tPIv58snzpCkR:
				title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
				title = title.replace('اون لاين',kh850jKbzmBwY)
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,893,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,892,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''["']pagination["'](.*?)["']footer["']''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,891,kh850jKbzmBwY,kh850jKbzmBwY,type)
	else:
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('load-next-button" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة جديدة',Ga8xfYU6ht7cHjzn[0],891,kh850jKbzmBwY,kh850jKbzmBwY,type)
	return
def sGaLKXvqkC(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SERIESTIME-SERIES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="eplist"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		hNDb2sI34dvRnlXZHMz6YfkuOSV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in hNDb2sI34dvRnlXZHMz6YfkuOSV:
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,892)
	else:
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"category".*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if Ga8xfYU6ht7cHjzn:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
			bsZhnoqjD3U(Ga8xfYU6ht7cHjzn,'episodes')
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX,OEVmWsLiSNvybAxc2e9Id8C1jkRXp = [],[]
	r4rIFWpixAJ7oL0Rljg1quwQym = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	O9wzaDlICnq = url.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)+'/see'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SERIESTIME-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if 'hash=' in uP1m46pAK5a3UgdqvBz9rnL:
		rFk4DCWv7EXd = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('hash=(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		rFk4DCWv7EXd = list(set(rFk4DCWv7EXd))
		for LsgQIK6E08od3r5 in rFk4DCWv7EXd:
			qaKTAyYWX8dJ6w1rlphxSPu7MCLj = []
			VQfK9Lr0j75zHwg1xOGY = LsgQIK6E08od3r5.split('__')
			for omfXkuRP6QsITcL9WAbFS25pw in VQfK9Lr0j75zHwg1xOGY:
				try:
					omfXkuRP6QsITcL9WAbFS25pw = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(omfXkuRP6QsITcL9WAbFS25pw+'=')
					if eOQJrvLAZC: omfXkuRP6QsITcL9WAbFS25pw = omfXkuRP6QsITcL9WAbFS25pw.decode(NVbhZ0DTpOkCA)
					qaKTAyYWX8dJ6w1rlphxSPu7MCLj.append(omfXkuRP6QsITcL9WAbFS25pw)
				except: pass
			Sp6qOyDB0nt5Qo4KwbPfcWYe = '>'.join(qaKTAyYWX8dJ6w1rlphxSPu7MCLj)
			Sp6qOyDB0nt5Qo4KwbPfcWYe = Sp6qOyDB0nt5Qo4KwbPfcWYe.splitlines()
			for Ga8xfYU6ht7cHjzn in Sp6qOyDB0nt5Qo4KwbPfcWYe:
				if ' => ' in Ga8xfYU6ht7cHjzn:
					title,Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split(' => ')
					Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
					owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	elif 'post_id = ' in uP1m46pAK5a3UgdqvBz9rnL:
		bYXVGSPi1DC6kIh9BE7j3esN0mfQg = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("post_id = '(.*?)'",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if bYXVGSPi1DC6kIh9BE7j3esN0mfQg:
			bYXVGSPi1DC6kIh9BE7j3esN0mfQg = bYXVGSPi1DC6kIh9BE7j3esN0mfQg[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
			headers['Referer'] = fDKF4iZ5rz7McduTexbA2RpPs
			E180i9gBdNyFG4vx2wOpnZ = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/wp-admin/admin-ajax.php?action=video_info&post_id='+bYXVGSPi1DC6kIh9BE7j3esN0mfQg
			try: OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',E180i9gBdNyFG4vx2wOpnZ,kh850jKbzmBwY,headers,kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,'SERIESTIME-PLAY-2nd')
			except: r4rIFWpixAJ7oL0Rljg1quwQym = dbo4vrnTM56I
			if not r4rIFWpixAJ7oL0Rljg1quwQym:
				CkH3dlE8y6fXBQwRrM = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
				FH5oNSjkRw0c4OnP = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"name":"(.*?)","src":"(.*?)"',CkH3dlE8y6fXBQwRrM,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if not FH5oNSjkRw0c4OnP:
					FH5oNSjkRw0c4OnP = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"src":"(.*?)"',CkH3dlE8y6fXBQwRrM,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
					if FH5oNSjkRw0c4OnP:
						D8LIQm7CWcYfyh2XvVl5 = ['']*len(FH5oNSjkRw0c4OnP)
						FH5oNSjkRw0c4OnP = list(zip(D8LIQm7CWcYfyh2XvVl5,FH5oNSjkRw0c4OnP))
				for name,Ga8xfYU6ht7cHjzn in FH5oNSjkRw0c4OnP:
					Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
					Ga8xfYU6ht7cHjzn = ioZ083zxYk(Ga8xfYU6ht7cHjzn)
					owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+name+'__watch')
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?s='+search
	bsZhnoqjD3U(url,'search')
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'EGYBESTVIP'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_EGV_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,QPZDaMKgtTUyNjB7EqvOLwph,text):
	if   mode==220: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==221: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==222: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==223: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==224: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url)
	elif mode==229: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,229,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBEST-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="i i-home"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,222)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="ba(.*?)<script',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for title,Ga8xfYU6ht7cHjzn in items:
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,221)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if 'html' not in Ga8xfYU6ht7cHjzn: continue
			if not Ga8xfYU6ht7cHjzn.endswith(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M): EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,221)
	return uP1m46pAK5a3UgdqvBz9rnL
def CC6NMTjSO2g(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-SUBMENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="rs_scroll"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</i>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,224)
	return
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(url):
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',url,221)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-FILTERS_MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="sub_nav(.*?)id="movies',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".+?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if Ga8xfYU6ht7cHjzn=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,221)
	else: bsZhnoqjD3U(url)
	return
def bsZhnoqjD3U(url,QPZDaMKgtTUyNjB7EqvOLwph='1'):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	if '/search' in url or '?' in url: O9wzaDlICnq = url + '&'
	else: O9wzaDlICnq = url + '?'
	O9wzaDlICnq = O9wzaDlICnq + 'page=' + QPZDaMKgtTUyNjB7EqvOLwph
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pda"(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[-1]
	elif '/series/' in url:
		liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="owl-carousel owl-carousel(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	else:
		liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="movies(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[-1]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		if '/movie/' in Ga8xfYU6ht7cHjzn or '/episode' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn.rstrip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M),223,NWqAr40jTLlMBemn3o79y)
		else:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,221,NWqAr40jTLlMBemn3o79y)
	if len(items)>=16:
		oi20K9MklU8qYQ6GSVd = ['/movies','/tv','/search','/trending']
		QPZDaMKgtTUyNjB7EqvOLwph = int(QPZDaMKgtTUyNjB7EqvOLwph)
		if any(value in url for value in oi20K9MklU8qYQ6GSVd):
			for Jt4DLkC7OjKUiTwlcFNfzy in range(0,1000,100):
				if int(QPZDaMKgtTUyNjB7EqvOLwph/100)*100==Jt4DLkC7OjKUiTwlcFNfzy:
					for asKYTS478qkW in range(Jt4DLkC7OjKUiTwlcFNfzy,Jt4DLkC7OjKUiTwlcFNfzy+100,10):
						if int(QPZDaMKgtTUyNjB7EqvOLwph/10)*10==asKYTS478qkW:
							for DdCH2hG6Lw in range(asKYTS478qkW,asKYTS478qkW+10,1):
								if not QPZDaMKgtTUyNjB7EqvOLwph==DdCH2hG6Lw and DdCH2hG6Lw!=0:
									EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+str(DdCH2hG6Lw),url,221,kh850jKbzmBwY,str(DdCH2hG6Lw))
						elif asKYTS478qkW!=0: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+str(asKYTS478qkW),url,221,kh850jKbzmBwY,str(asKYTS478qkW))
						else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+str(1),url,221,kh850jKbzmBwY,str(1))
				elif Jt4DLkC7OjKUiTwlcFNfzy!=0: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+str(Jt4DLkC7OjKUiTwlcFNfzy),url,221,kh850jKbzmBwY,str(Jt4DLkC7OjKUiTwlcFNfzy))
				else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+str(1),url,221)
	return
def yv8LezRQifhw1Kx(url):
	x2xi0tpFnQgNmaJ4LR,lnYtOIQ4Rkh386Bca7 = [],[]
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-PLAY-1st')
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<td>التصنيف</td>.*?">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	BfgcCYXqdpb6hsr5o3FAWk9meR0E,MNp6XJI1qnult4ToG = kh850jKbzmBwY,kh850jKbzmBwY
	xJbLqQAy37YhPwCvVZi0XD1oak,h3n6pXrT9USeDIaOP5EJoflLH = uP1m46pAK5a3UgdqvBz9rnL,uP1m46pAK5a3UgdqvBz9rnL
	qdIHfjMD7AG2689 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('show_dl api" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if qdIHfjMD7AG2689:
		for Ga8xfYU6ht7cHjzn in qdIHfjMD7AG2689:
			if '/watch/' in Ga8xfYU6ht7cHjzn: BfgcCYXqdpb6hsr5o3FAWk9meR0E = Ga8xfYU6ht7cHjzn
			elif '/download/' in Ga8xfYU6ht7cHjzn: MNp6XJI1qnult4ToG = Ga8xfYU6ht7cHjzn
		if BfgcCYXqdpb6hsr5o3FAWk9meR0E!=kh850jKbzmBwY: xJbLqQAy37YhPwCvVZi0XD1oak = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,BfgcCYXqdpb6hsr5o3FAWk9meR0E,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-PLAY-2nd')
		if MNp6XJI1qnult4ToG!=kh850jKbzmBwY: h3n6pXrT9USeDIaOP5EJoflLH = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,MNp6XJI1qnult4ToG,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-PLAY-3rd')
	pFX5vbIJDe4hlO6 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="video".*?data-src="(.*?)"',xJbLqQAy37YhPwCvVZi0XD1oak,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if pFX5vbIJDe4hlO6:
		O9wzaDlICnq = pFX5vbIJDe4hlO6[0]
		if O9wzaDlICnq!=kh850jKbzmBwY and 'uploaded.egybest.download' in O9wzaDlICnq and '/?id=_' not in O9wzaDlICnq:
			kKwr9zX358QO47tbu1UC2 = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-PLAY-4th')
			p0fGnA8iYC7NgQPRtForOdMWTh = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('source src="(.*?)" title="(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if p0fGnA8iYC7NgQPRtForOdMWTh:
				for Ga8xfYU6ht7cHjzn,sYm5r9QKRfjoytO in p0fGnA8iYC7NgQPRtForOdMWTh:
					lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn+'?named=ed.egybest.do__watch__mp4__'+sYm5r9QKRfjoytO)
			else:
				fDKF4iZ5rz7McduTexbA2RpPs = O9wzaDlICnq.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[2]
				lnYtOIQ4Rkh386Bca7.append(O9wzaDlICnq+'?named='+fDKF4iZ5rz7McduTexbA2RpPs+'__watch')
		elif O9wzaDlICnq!=kh850jKbzmBwY:
			fDKF4iZ5rz7McduTexbA2RpPs = O9wzaDlICnq.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[2]
			lnYtOIQ4Rkh386Bca7.append(O9wzaDlICnq+'?named='+fDKF4iZ5rz7McduTexbA2RpPs+'__watch')
	y5W4zKHkjP0oQXBVr8DU = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<table class="dls_table(.*?)</table>',h3n6pXrT9USeDIaOP5EJoflLH,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if y5W4zKHkjP0oQXBVr8DU:
		y5W4zKHkjP0oQXBVr8DU = y5W4zKHkjP0oQXBVr8DU[0]
		UKx3hIpiyaf50NjwSEo2knZLt = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',y5W4zKHkjP0oQXBVr8DU,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if UKx3hIpiyaf50NjwSEo2knZLt:
			for sYm5r9QKRfjoytO,Ga8xfYU6ht7cHjzn in UKx3hIpiyaf50NjwSEo2knZLt:
				if 'myegyvip' not in Ga8xfYU6ht7cHjzn: continue
				if Ga8xfYU6ht7cHjzn.count(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)>=2:
					fDKF4iZ5rz7McduTexbA2RpPs = Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[2]
					lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn+'?named='+fDKF4iZ5rz7McduTexbA2RpPs+'__download__mp4__'+sYm5r9QKRfjoytO)
	FTeYZftg5dr4X = []
	for Ga8xfYU6ht7cHjzn in lnYtOIQ4Rkh386Bca7:
		FTeYZftg5dr4X.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(FTeYZftg5dr4X,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(qogplQ5vHLYt8Ci1fknObwMThe,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYBESTVIP-SEARCH-1st')
	ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('name="_token" value="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk:
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search?_token='+ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk[0]+'&q='+BkpEeTDInR6LQFG2m1Ns
		bsZhnoqjD3U(url)
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'TVFUN'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_TVF_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['بث مباشر']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==460: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==461: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==462: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==463: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==469: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'TVFUN-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,469,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"menu-btn"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)</span>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,461)
	return
def bsZhnoqjD3U(url,JjH8Zr42QL5AnsweEIRxltWcp=kh850jKbzmBwY):
	items = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'TVFUN-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="head-title"(.*?)id="footer"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		SHTvIuhX52dxQRsWA = []
		fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			title = '_MOD_'+title.replace('<br>',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn)
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,462,NWqAr40jTLlMBemn3o79y)
			elif WULSmfNH09tPIv58snzpCkR and 'الحلقة' in title:
				title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
				if title not in SHTvIuhX52dxQRsWA:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,463,NWqAr40jTLlMBemn3o79y)
					SHTvIuhX52dxQRsWA.append(title)
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,463,NWqAr40jTLlMBemn3o79y)
	if JjH8Zr42QL5AnsweEIRxltWcp!='latest':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				if Ga8xfYU6ht7cHjzn=="": continue
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
				if title!=kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,461)
	return
def do7Es2fUtFlM8ScLx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'TVFUN-EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="head-title"(.*?)id="footer"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if items:
			for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
				title = '_MOD_'+title.replace('<br>',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,462,NWqAr40jTLlMBemn3o79y)
		else:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="episode.*?href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,462)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if Ga8xfYU6ht7cHjzn=="": continue
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if title!=kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,463)
	return
def yv8LezRQifhw1Kx(url):
	lnYtOIQ4Rkh386Bca7 = []
	O9wzaDlICnq = url.replace('/video/','/watch/')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'TVFUN-PLAY-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('VideoServers"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for dc2JyM8957lDnHVvW0tLKNupj,name in Sp6qOyDB0nt5Qo4KwbPfcWYe:
			dc2JyM8957lDnHVvW0tLKNupj = dc2JyM8957lDnHVvW0tLKNupj[2:]
			if BBJYzRKgHkOqx: dc2JyM8957lDnHVvW0tLKNupj = dc2JyM8957lDnHVvW0tLKNupj.decode(NVbhZ0DTpOkCA)
			dc2JyM8957lDnHVvW0tLKNupj = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(dc2JyM8957lDnHVvW0tLKNupj)
			if eOQJrvLAZC: dc2JyM8957lDnHVvW0tLKNupj = dc2JyM8957lDnHVvW0tLKNupj.decode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)"',dc2JyM8957lDnHVvW0tLKNupj,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
			if 'http' not in Ga8xfYU6ht7cHjzn:
				if bruAOCB4ZoHVF7 in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
				else: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if Ga8xfYU6ht7cHjzn not in lnYtOIQ4Rkh386Bca7:
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+name+'__watch'
				lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if not search:
		search = GG5Fs0hvURxyBV8gz()
		if not search: return
	if EE3iZM15sTQ2t9cOhuCWwDjGSUzryF in search:
		if showDialogs: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/q/'+search+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M
	bsZhnoqjD3U(url)
	return
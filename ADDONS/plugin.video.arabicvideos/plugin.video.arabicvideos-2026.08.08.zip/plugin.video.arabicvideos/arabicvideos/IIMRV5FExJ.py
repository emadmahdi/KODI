# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'GLOBALSEARCH'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_GLS_'
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz,QPZDaMKgtTUyNjB7EqvOLwph):
	if   eYN1APt8aZflKmByj0ioGzn==540: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif eYN1APt8aZflKmByj0ioGzn==541: PP3FsDicLyWuTR7GV5Ia = F5FkXTBobdiwZ(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==542: PP3FsDicLyWuTR7GV5Ia = sUWKYyqP426FlOHxuhXotzS(fRJYhnSKHsZ7MqFwmiVz,QmRL0swTcY9dXyIgrp82Aa1ekD,QPZDaMKgtTUyNjB7EqvOLwph)
	elif eYN1APt8aZflKmByj0ioGzn==543: PP3FsDicLyWuTR7GV5Ia = Jcl08PwWxmRBkTZrfiyLh7KjY1FXd()
	elif eYN1APt8aZflKmByj0ioGzn==548: PP3FsDicLyWuTR7GV5Ia = ooCKemPauS(QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==549: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(fRJYhnSKHsZ7MqFwmiVz)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder','بحث جديد لجميع المواقع',kh850jKbzmBwY,549)
	EE6ysIeB8jKNgCfOkv('link','كيف يعمل بحث جميع المواقع','',543)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'==== كلمات البحث المخزنة ===='+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	iov3SWN1Q9ZKUxCygGlsnTkb07 = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if iov3SWN1Q9ZKUxCygGlsnTkb07:
		iov3SWN1Q9ZKUxCygGlsnTkb07 = iov3SWN1Q9ZKUxCygGlsnTkb07['__SEQUENCED_COLUMNS__']
		for othRNaJrlCsOAymp4iQL6HPEVn9gb in reversed(iov3SWN1Q9ZKUxCygGlsnTkb07):
			EE6ysIeB8jKNgCfOkv('folder',othRNaJrlCsOAymp4iQL6HPEVn9gb,kh850jKbzmBwY,549,kh850jKbzmBwY,kh850jKbzmBwY,othRNaJrlCsOAymp4iQL6HPEVn9gb)
	return
def dStQzEeyknDaOs7q(othRNaJrlCsOAymp4iQL6HPEVn9gb):
	if not othRNaJrlCsOAymp4iQL6HPEVn9gb:
		othRNaJrlCsOAymp4iQL6HPEVn9gb = GG5Fs0hvURxyBV8gz()
		if not othRNaJrlCsOAymp4iQL6HPEVn9gb: return
		othRNaJrlCsOAymp4iQL6HPEVn9gb = othRNaJrlCsOAymp4iQL6HPEVn9gb.lower()
	D2vGheawHt3pBn9CbZs = othRNaJrlCsOAymp4iQL6HPEVn9gb.replace(GalrcVUMy8bzORWX5E0exhYivBwgk,kh850jKbzmBwY)
	ccetYpEjky8Q5n(D2vGheawHt3pBn9CbZs,'_ALL',True)
	EE6ysIeB8jKNgCfOkv('link','بحث جماعي للمواقع - '+D2vGheawHt3pBn9CbZs,'search_sites_all',542,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('folder','بحث منفرد للمواقع - '+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,541,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder','نتائج البحث مفصلة - '+D2vGheawHt3pBn9CbZs,'opened_sites_all',542,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('folder','نتائج البحث مقسمة - '+D2vGheawHt3pBn9CbZs,'listed_sites_all',542,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	return
def ccetYpEjky8Q5n(H5LWnUBxFXso2Og9rmCd,FkjOA5lS1yHL6g7KPM09Eh,P9Oh4pVJb0yzen61x):
	if FkjOA5lS1yHL6g7KPM09Eh=='_ALL': Q5oAfVI1RDpbZ6g02 = '_GLS_'
	elif FkjOA5lS1yHL6g7KPM09Eh=='_GOOGLE': Q5oAfVI1RDpbZ6g02 = '_GOS_'
	FFv8PQlcZgM3Be7Tphb1s = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,H5LWnUBxFXso2Og9rmCd)
	EzTag3CJR91 = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,Q5oAfVI1RDpbZ6g02+H5LWnUBxFXso2Og9rmCd)
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,H5LWnUBxFXso2Og9rmCd)
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,Q5oAfVI1RDpbZ6g02+H5LWnUBxFXso2Og9rmCd)
	qqFEfistUzgAHW90O = FFv8PQlcZgM3Be7Tphb1s+EzTag3CJR91
	if qqFEfistUzgAHW90O and P9Oh4pVJb0yzen61x: H5LWnUBxFXso2Og9rmCd = Q5oAfVI1RDpbZ6g02+H5LWnUBxFXso2Og9rmCd
	l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,'GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,H5LWnUBxFXso2Og9rmCd,qqFEfistUzgAHW90O,xCNH20myQLKTeJUVA1p7)
	return
def UGg4RckBn7ySxV15laImCqpbYPr(FkjOA5lS1yHL6g7KPM09Eh):
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if II7ErX2ocuU!=1: return
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh)
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_DETAILED'+FkjOA5lS1yHL6g7KPM09Eh)
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_DIVIDED'+FkjOA5lS1yHL6g7KPM09Eh)
	if FkjOA5lS1yHL6g7KPM09Eh=='_GOOGLE': pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GOOGLESEARCH_RESULTS')
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def sUWKYyqP426FlOHxuhXotzS(YuIdpwo928UlA,X8rOZojJgNKix,G86oSVnyHAIxh3WOgZLUb=kh850jKbzmBwY,Gp4e8s57qMFRCwc39Pxv0=WTyswk70P6az,oik5dXGYL3HPmxOy={}):
	XMt4ecQTuR1jvJ,o8KMkyEtsYb7hABzSJlGaX13vFNI,HHjbGpuvyItgxS,G2EkdFTzhLBbu4UmfOjNCoYqS,WWRJCdvZh7V8H5 = [],{},{},{},{}
	if '_all' in X8rOZojJgNKix: FkjOA5lS1yHL6g7KPM09Eh,MN6Qdl47bwDo9hqxpmc2t3Xf,Q5oAfVI1RDpbZ6g02 = '_ALL','_all','_GLS_'
	elif '_google' in X8rOZojJgNKix: FkjOA5lS1yHL6g7KPM09Eh,MN6Qdl47bwDo9hqxpmc2t3Xf,Q5oAfVI1RDpbZ6g02 = '_GOOGLE','_google','_GOS_'
	if X8rOZojJgNKix in ['listed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,'opened_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,'closed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf]:
		if X8rOZojJgNKix=='listed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf: XMt4ecQTuR1jvJ = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,Q5oAfVI1RDpbZ6g02+YuIdpwo928UlA)
		elif X8rOZojJgNKix=='opened_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf: XMt4ecQTuR1jvJ = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GLOBALSEARCH_DETAILED'+FkjOA5lS1yHL6g7KPM09Eh,YuIdpwo928UlA)
		elif X8rOZojJgNKix=='closed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf: XMt4ecQTuR1jvJ = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GLOBALSEARCH_DIVIDED'+FkjOA5lS1yHL6g7KPM09Eh,(G86oSVnyHAIxh3WOgZLUb,YuIdpwo928UlA))
	if not XMt4ecQTuR1jvJ:
		i2xKJuM5eANb = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		ccYfzwbEjm2qxCdhlSRWt = 'هل تريد الآن البحث في جميع المواقع عن \n "'+RlMpu0hP8YmzZovkVXOs1G+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+YuIdpwo928UlA+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+wVvqN8LZCJW5ryAb1EHRPFkQ0+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if X8rOZojJgNKix=='search_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf: gfe2BNJ3kTF0Xx = ccYfzwbEjm2qxCdhlSRWt
		else: gfe2BNJ3kTF0Xx = i2xKJuM5eANb+ccYfzwbEjm2qxCdhlSRWt
		II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
		if II7ErX2ocuU!=1: return
		JabU23pYu7zWD8(SmThPgBVzt8,SmThPgBVzt8,SmThPgBVzt8)
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+'   Search For: [ '+YuIdpwo928UlA+' ]')
		thfZVYUrsQH10kxm = 1
		for CYil97XWVj4Z3SRKMUf8DGQeLa in Gp4e8s57qMFRCwc39Pxv0:
			hIV4sw1flm7xqF0APJ5TNkn = oik5dXGYL3HPmxOy[CYil97XWVj4Z3SRKMUf8DGQeLa] if oik5dXGYL3HPmxOy else YuIdpwo928UlA
			try: p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
			except: continue
			o8KMkyEtsYb7hABzSJlGaX13vFNI[CYil97XWVj4Z3SRKMUf8DGQeLa] = []
			uT9JyZBUCVavzKLOgw = '_NODIALOGS_'
			if '-' in CYil97XWVj4Z3SRKMUf8DGQeLa: uT9JyZBUCVavzKLOgw = uT9JyZBUCVavzKLOgw+'_REMEMBERRESULTS__'+CYil97XWVj4Z3SRKMUf8DGQeLa+'_'
			if thfZVYUrsQH10kxm:
				pVesmhFG6wgubAODHSKvN1Wx.sleep(0.75)
				WWRJCdvZh7V8H5[CYil97XWVj4Z3SRKMUf8DGQeLa] = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=VNevGUwBskhaFpPEr5oMyACH2q8,args=(hIV4sw1flm7xqF0APJ5TNkn+uT9JyZBUCVavzKLOgw,))
				WWRJCdvZh7V8H5[CYil97XWVj4Z3SRKMUf8DGQeLa].start()
			else: VNevGUwBskhaFpPEr5oMyACH2q8(hIV4sw1flm7xqF0APJ5TNkn+uT9JyZBUCVavzKLOgw)
			o4n5ehzyjHTWdL8(Hczgh3TNkKXoq4AZ1wJiC(CYil97XWVj4Z3SRKMUf8DGQeLa),kh850jKbzmBwY,pVesmhFG6wgubAODHSKvN1Wx=1000)
		if thfZVYUrsQH10kxm:
			pVesmhFG6wgubAODHSKvN1Wx.sleep(2)
			for CYil97XWVj4Z3SRKMUf8DGQeLa in Gp4e8s57qMFRCwc39Pxv0: WWRJCdvZh7V8H5[CYil97XWVj4Z3SRKMUf8DGQeLa].join(10)
			pVesmhFG6wgubAODHSKvN1Wx.sleep(2)
		for CYil97XWVj4Z3SRKMUf8DGQeLa in Gp4e8s57qMFRCwc39Pxv0:
			try: p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
			except: continue
			for ysV8ChmKR0EgYMaAqlH6jonIQJx9 in Y3Ny5eLHdp.menuItemsLIST:
				uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = ysV8ChmKR0EgYMaAqlH6jonIQJx9
				if THiQ1ScLBrWuwmaj in ppweOR6rMg:
					if 'IPTV-' in CYil97XWVj4Z3SRKMUf8DGQeLa and (239>=eYN1APt8aZflKmByj0ioGzn>=230 or 289>=eYN1APt8aZflKmByj0ioGzn>=280):
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['IPTV-LIVE']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['IPTV-MOVIES']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['IPTV-SERIES']: continue
						if 'صفحة' not in ppweOR6rMg:
							if   uDJvEcha9x4OtnN5e18yKqA3zgmW=='live': CYil97XWVj4Z3SRKMUf8DGQeLa = 'IPTV-LIVE'
							elif uDJvEcha9x4OtnN5e18yKqA3zgmW=='video': CYil97XWVj4Z3SRKMUf8DGQeLa = 'IPTV-MOVIES'
							elif uDJvEcha9x4OtnN5e18yKqA3zgmW=='folder': CYil97XWVj4Z3SRKMUf8DGQeLa = 'IPTV-SERIES'
						else:
							if   'LIVE' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'IPTV-LIVE'
							elif 'MOVIES' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'IPTV-MOVIES'
							elif 'SERIES' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'IPTV-SERIES'
					elif 'M3U-' in CYil97XWVj4Z3SRKMUf8DGQeLa and 729>=eYN1APt8aZflKmByj0ioGzn>=710:
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['M3U-LIVE']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['M3U-MOVIES']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['M3U-SERIES']: continue
						if 'صفحة' not in ppweOR6rMg:
							if   uDJvEcha9x4OtnN5e18yKqA3zgmW=='live': CYil97XWVj4Z3SRKMUf8DGQeLa = 'M3U-LIVE'
							elif uDJvEcha9x4OtnN5e18yKqA3zgmW=='video': CYil97XWVj4Z3SRKMUf8DGQeLa = 'M3U-MOVIES'
							elif uDJvEcha9x4OtnN5e18yKqA3zgmW=='folder': CYil97XWVj4Z3SRKMUf8DGQeLa = 'M3U-SERIES'
						else:
							if   'LIVE' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'M3U-LIVE'
							elif 'MOVIES' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'M3U-MOVIES'
							elif 'SERIES' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'M3U-SERIES'
					elif 'YOUTUBE-' in CYil97XWVj4Z3SRKMUf8DGQeLa and 149>=eYN1APt8aZflKmByj0ioGzn>=140:
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['YOUTUBE-CHANNELS']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['YOUTUBE-PLAYLISTS']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in ppweOR6rMg or ':: ' in ppweOR6rMg:
							continue
						else:
							if   eYN1APt8aZflKmByj0ioGzn==144 and 'USER' in ppweOR6rMg: CYil97XWVj4Z3SRKMUf8DGQeLa = 'YOUTUBE-CHANNELS'
							elif eYN1APt8aZflKmByj0ioGzn==144 and 'CHNL' in ppweOR6rMg: CYil97XWVj4Z3SRKMUf8DGQeLa = 'YOUTUBE-CHANNELS'
							elif eYN1APt8aZflKmByj0ioGzn==144 and 'LIST' in ppweOR6rMg: CYil97XWVj4Z3SRKMUf8DGQeLa = 'YOUTUBE-PLAYLISTS'
							elif eYN1APt8aZflKmByj0ioGzn==143: CYil97XWVj4Z3SRKMUf8DGQeLa = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in CYil97XWVj4Z3SRKMUf8DGQeLa and 419>=eYN1APt8aZflKmByj0ioGzn>=400:
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['DAILYMOTION-PLAYLISTS']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['DAILYMOTION-CHANNELS']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['DAILYMOTION-VIDEOS']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['DAILYMOTION-LIVES']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['DAILYMOTION-HASHTAGS']: continue
						if   eYN1APt8aZflKmByj0ioGzn in [401,405]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'DAILYMOTION-PLAYLISTS'
						elif eYN1APt8aZflKmByj0ioGzn in [402,406]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'DAILYMOTION-CHANNELS'
						elif eYN1APt8aZflKmByj0ioGzn in [404]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'DAILYMOTION-VIDEOS'
						elif eYN1APt8aZflKmByj0ioGzn in [415]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'DAILYMOTION-LIVES'
						elif eYN1APt8aZflKmByj0ioGzn in [416]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in CYil97XWVj4Z3SRKMUf8DGQeLa and 39>=eYN1APt8aZflKmByj0ioGzn>=30:
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['PANET-SERIES']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['PANET-MOVIES']: continue
						if   eYN1APt8aZflKmByj0ioGzn in [32,39]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'PANET-SERIES'
						elif eYN1APt8aZflKmByj0ioGzn in [33,39]: CYil97XWVj4Z3SRKMUf8DGQeLa = 'PANET-MOVIES'
					elif 'IFILM-' in CYil97XWVj4Z3SRKMUf8DGQeLa and 29>=eYN1APt8aZflKmByj0ioGzn>=20:
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['IFILM-ARABIC']: continue
						if ysV8ChmKR0EgYMaAqlH6jonIQJx9 in o8KMkyEtsYb7hABzSJlGaX13vFNI['IFILM-ENGLISH']: continue
						if   '/ar.' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'IFILM-ARABIC'
						elif '/en.' in QmRL0swTcY9dXyIgrp82Aa1ekD: CYil97XWVj4Z3SRKMUf8DGQeLa = 'IFILM-ENGLISH'
					o8KMkyEtsYb7hABzSJlGaX13vFNI[CYil97XWVj4Z3SRKMUf8DGQeLa].append(ysV8ChmKR0EgYMaAqlH6jonIQJx9)
		for CYil97XWVj4Z3SRKMUf8DGQeLa in list(o8KMkyEtsYb7hABzSJlGaX13vFNI.keys()):
			HHjbGpuvyItgxS[CYil97XWVj4Z3SRKMUf8DGQeLa] = []
			G2EkdFTzhLBbu4UmfOjNCoYqS[CYil97XWVj4Z3SRKMUf8DGQeLa] = []
			for uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in o8KMkyEtsYb7hABzSJlGaX13vFNI[CYil97XWVj4Z3SRKMUf8DGQeLa]:
				ysV8ChmKR0EgYMaAqlH6jonIQJx9 = (uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA)
				if 'صفحة' in ppweOR6rMg and uDJvEcha9x4OtnN5e18yKqA3zgmW=='folder': G2EkdFTzhLBbu4UmfOjNCoYqS[CYil97XWVj4Z3SRKMUf8DGQeLa].append(ysV8ChmKR0EgYMaAqlH6jonIQJx9)
				else: HHjbGpuvyItgxS[CYil97XWVj4Z3SRKMUf8DGQeLa].append(ysV8ChmKR0EgYMaAqlH6jonIQJx9)
		NR9Fan5lcb07qZQY1ejkrgiX,X74YVrsugUjM3FnJeBA2azb = [],[]
		RkwHM25AJNxyZLdrei4hsB = list(HHjbGpuvyItgxS.keys())
		RRVhnK0JNDQ9vkZY = S4xl5ZswLy3pGDuOqIFgvUCk8cB1i6(RkwHM25AJNxyZLdrei4hsB)
		PhHu9BEwGKIf1Ltipd8Wq6mFX2xjaT = []
		for CYil97XWVj4Z3SRKMUf8DGQeLa in RRVhnK0JNDQ9vkZY:
			if isinstance(CYil97XWVj4Z3SRKMUf8DGQeLa,tuple):
				PhHu9BEwGKIf1Ltipd8Wq6mFX2xjaT = [CYil97XWVj4Z3SRKMUf8DGQeLa]
				continue
			if CYil97XWVj4Z3SRKMUf8DGQeLa not in Gp4e8s57qMFRCwc39Pxv0: continue
			if HHjbGpuvyItgxS[CYil97XWVj4Z3SRKMUf8DGQeLa]:
				FzAIcdMgV9qs6oy3SbZ27O8f4aWwRe = Hczgh3TNkKXoq4AZ1wJiC(CYil97XWVj4Z3SRKMUf8DGQeLa)
				zIPOoXKCHxRF3Lyeuf2SqGdmb4a = [('link',RlMpu0hP8YmzZovkVXOs1G+'===== '+FzAIcdMgV9qs6oy3SbZ27O8f4aWwRe+' ====='+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY)]
				if 0: Ubec28JOqQAtRk7lYDfsZamvG = YuIdpwo928UlA+' - '+'بحث'+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+FzAIcdMgV9qs6oy3SbZ27O8f4aWwRe
				else: Ubec28JOqQAtRk7lYDfsZamvG = 'بحث'+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+FzAIcdMgV9qs6oy3SbZ27O8f4aWwRe+' - '+YuIdpwo928UlA
				if len(HHjbGpuvyItgxS[CYil97XWVj4Z3SRKMUf8DGQeLa])<8: ggByOY4RHEmfbvK = []
				else:
					jGA4E0yLmqaoJYRHxtMziX6rD = HHFAVK8SwRUqBLuTfdeJ9nbD+Ubec28JOqQAtRk7lYDfsZamvG+wVvqN8LZCJW5ryAb1EHRPFkQ0
					ggByOY4RHEmfbvK = [('folder',Q5oAfVI1RDpbZ6g02+jGA4E0yLmqaoJYRHxtMziX6rD,'closed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,542,kh850jKbzmBwY,CYil97XWVj4Z3SRKMUf8DGQeLa,YuIdpwo928UlA,kh850jKbzmBwY,kh850jKbzmBwY)]
				pDKFncIb4jX = HHjbGpuvyItgxS[CYil97XWVj4Z3SRKMUf8DGQeLa]+G2EkdFTzhLBbu4UmfOjNCoYqS[CYil97XWVj4Z3SRKMUf8DGQeLa]
				nEx0YGtD1kI4smB2Wi = PhHu9BEwGKIf1Ltipd8Wq6mFX2xjaT+zIPOoXKCHxRF3Lyeuf2SqGdmb4a+pDKFncIb4jX[:7]+ggByOY4RHEmfbvK
				NR9Fan5lcb07qZQY1ejkrgiX += nEx0YGtD1kI4smB2Wi
				JbklGofNqwrWZ73th = [('folder',Q5oAfVI1RDpbZ6g02+Ubec28JOqQAtRk7lYDfsZamvG,'closed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,542,kh850jKbzmBwY,CYil97XWVj4Z3SRKMUf8DGQeLa,YuIdpwo928UlA,kh850jKbzmBwY,kh850jKbzmBwY)]
				xJjSv1ch59DydU06FLqNVmoZE = PhHu9BEwGKIf1Ltipd8Wq6mFX2xjaT+JbklGofNqwrWZ73th
				X74YVrsugUjM3FnJeBA2azb += xJjSv1ch59DydU06FLqNVmoZE
				l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,'GLOBALSEARCH_DIVIDED'+FkjOA5lS1yHL6g7KPM09Eh,(CYil97XWVj4Z3SRKMUf8DGQeLa,YuIdpwo928UlA),pDKFncIb4jX,xCNH20myQLKTeJUVA1p7)
				PhHu9BEwGKIf1Ltipd8Wq6mFX2xjaT = []
		l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,'GLOBALSEARCH_DETAILED'+FkjOA5lS1yHL6g7KPM09Eh,YuIdpwo928UlA,NR9Fan5lcb07qZQY1ejkrgiX,xCNH20myQLKTeJUVA1p7)
		pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,YuIdpwo928UlA)
		l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,'GLOBALSEARCH_SPLITTED'+FkjOA5lS1yHL6g7KPM09Eh,Q5oAfVI1RDpbZ6g02+YuIdpwo928UlA,X74YVrsugUjM3FnJeBA2azb,xCNH20myQLKTeJUVA1p7)
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		XMt4ecQTuR1jvJ = X74YVrsugUjM3FnJeBA2azb if X8rOZojJgNKix=='listed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf and X74YVrsugUjM3FnJeBA2azb else NR9Fan5lcb07qZQY1ejkrgiX
	if X8rOZojJgNKix in ['listed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,'opened_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,'closed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf]:
		for uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in XMt4ecQTuR1jvJ:
			if X8rOZojJgNKix in ['listed_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf,'opened_sites'+MN6Qdl47bwDo9hqxpmc2t3Xf] and 'صفحة' in ppweOR6rMg and uDJvEcha9x4OtnN5e18yKqA3zgmW=='folder': continue
			EE6ysIeB8jKNgCfOkv(uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA)
	JabU23pYu7zWD8(yBOdNtTJF1m,yBOdNtTJF1m,yBOdNtTJF1m)
	return
def F5FkXTBobdiwZ(search):
	RRVhnK0JNDQ9vkZY = S4xl5ZswLy3pGDuOqIFgvUCk8cB1i6(Ege1mcK0zWQ)
	for CYil97XWVj4Z3SRKMUf8DGQeLa in RRVhnK0JNDQ9vkZY:
		if '-' in CYil97XWVj4Z3SRKMUf8DGQeLa: continue
		if isinstance(CYil97XWVj4Z3SRKMUf8DGQeLa,tuple):
			Y3Ny5eLHdp.menuItemsLIST.append(CYil97XWVj4Z3SRKMUf8DGQeLa)
			continue
		p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
		name = Hczgh3TNkKXoq4AZ1wJiC(CYil97XWVj4Z3SRKMUf8DGQeLa)+' - '+search
		EE6ysIeB8jKNgCfOkv('folder',THiQ1ScLBrWuwmaj+name,CYil97XWVj4Z3SRKMUf8DGQeLa,548,'','',search)
	return
def ooCKemPauS(CYil97XWVj4Z3SRKMUf8DGQeLa,search):
	p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
	VNevGUwBskhaFpPEr5oMyACH2q8(search)
	return
def Jcl08PwWxmRBkTZrfiyLh7KjY1FXd():
	o1OgjEBsS0aKNl6T7LyAXWfmQ('','',fWM6PeOrvciG0RQpIKzltojDqaYs,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def LJAMqH6tTP8p(YuIdpwo928UlA=kh850jKbzmBwY):
	othRNaJrlCsOAymp4iQL6HPEVn9gb,uT9JyZBUCVavzKLOgw,showDialogs = gCI13c7MdXA8(YuIdpwo928UlA)
	if not othRNaJrlCsOAymp4iQL6HPEVn9gb:
		othRNaJrlCsOAymp4iQL6HPEVn9gb = GG5Fs0hvURxyBV8gz()
		if not othRNaJrlCsOAymp4iQL6HPEVn9gb: return
		othRNaJrlCsOAymp4iQL6HPEVn9gb = othRNaJrlCsOAymp4iQL6HPEVn9gb.lower()
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+'   Search For: [ '+othRNaJrlCsOAymp4iQL6HPEVn9gb+' ]')
	BkpEeTDInR6LQFG2m1Ns = othRNaJrlCsOAymp4iQL6HPEVn9gb+uT9JyZBUCVavzKLOgw
	if 0: p4tN9ZkbucLj18,D2vGheawHt3pBn9CbZs = othRNaJrlCsOAymp4iQL6HPEVn9gb+' - ',kh850jKbzmBwY
	else: p4tN9ZkbucLj18,D2vGheawHt3pBn9CbZs = kh850jKbzmBwY,' - '+othRNaJrlCsOAymp4iQL6HPEVn9gb
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'مواقع سيرفرات خاصة - قليلة المشاكل'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,157)
	EE6ysIeB8jKNgCfOkv('folder','_M3U_'+p4tN9ZkbucLj18+'بحث M3U'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,719,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_IPT_'+p4tN9ZkbucLj18+'بحث IPTV'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,239,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_BKR_'+p4tN9ZkbucLj18+'بحث موقع بكرا'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,379,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_ART_'+p4tN9ZkbucLj18+'بحث موقع تونز عربية'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,739,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_KRB_'+p4tN9ZkbucLj18+'بحث موقع قناة كربلاء'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,329,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FH2_'+p4tN9ZkbucLj18+'بحث موقع فاصل الثاني'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,599,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_KTV_'+p4tN9ZkbucLj18+'بحث موقع كتكوت تيفي'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,819,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_EB1_'+p4tN9ZkbucLj18+'بحث موقع ايجي بيست 1'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,779,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_EB2_'+p4tN9ZkbucLj18+'بحث موقع ايجي بيست 2'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,789,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_IFL_'+p4tN9ZkbucLj18+'  بحث موقع قناة آي فيلم'+D2vGheawHt3pBn9CbZs+cyR2rJzGpVSXNuHsEQjk60fvFetYDx,kh850jKbzmBwY,29,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_AKO_'+p4tN9ZkbucLj18+'بحث موقع أكوام القديم'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,79,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_AKW_'+p4tN9ZkbucLj18+'بحث موقع أكوام الجديد'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,249,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_MRF_'+p4tN9ZkbucLj18+'بحث موقع قناة المعارف'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,49,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_SHM_'+p4tN9ZkbucLj18+'بحث موقع شوف ماكس'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,59,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,157)
	EE6ysIeB8jKNgCfOkv('folder','_LRZ_'+p4tN9ZkbucLj18+'بحث موقع لاروزا'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,709,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FJS_'+p4tN9ZkbucLj18+' بحث موقع فجر شو'+D2vGheawHt3pBn9CbZs+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,kh850jKbzmBwY,399,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_TVF_'+p4tN9ZkbucLj18+'بحث موقع تيفي فان'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,469,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_LDN_'+p4tN9ZkbucLj18+'بحث موقع لودي نت'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,459,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_CMN_'+p4tN9ZkbucLj18+'بحث موقع سيما ناو'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,309,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_SHN_'+p4tN9ZkbucLj18+'بحث موقع شاهد نيوز'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,589,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns+'_NODIALOGS_')
	EE6ysIeB8jKNgCfOkv('folder','_ARS_'+p4tN9ZkbucLj18+'بحث موقع عرب سييد'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,259,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_CCB_'+p4tN9ZkbucLj18+'بحث موقع سيما كلوب'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,829,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_SH4_'+p4tN9ZkbucLj18+'بحث موقع شاهد فوريو'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,119,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns+'_NODIALOGS_')
	EE6ysIeB8jKNgCfOkv('folder','_SHT_'+p4tN9ZkbucLj18+'بحث موقع شوفها تيفي'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,649,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_WC1_'+p4tN9ZkbucLj18+'بحث موقع وي سيما 1'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,569,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_WC2_'+p4tN9ZkbucLj18+'بحث موقع وي سيما 2'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,1009,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'مواقع سيرفرات عامة - كثيرة المشاكل'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,157)
	EE6ysIeB8jKNgCfOkv('folder','_TKT_'+p4tN9ZkbucLj18+'بحث موقع تكات'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,949,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FST_'+p4tN9ZkbucLj18+'بحث موقع فوستا'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,609,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FBK_'+p4tN9ZkbucLj18+'بحث موقع فبركة'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,629,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_YQT_'+p4tN9ZkbucLj18+'بحث موقع ياقوت'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,669,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_SHB_'+p4tN9ZkbucLj18+'بحث موقع شبكتي'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,969,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_VRB_'+p4tN9ZkbucLj18+'بحث موقع فاربون'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,879,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_BRS_'+p4tN9ZkbucLj18+'بحث موقع برستيج'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,659,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_KRM_'+p4tN9ZkbucLj18+'بحث موقع كرمالك'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,929,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_ANZ_'+p4tN9ZkbucLj18+'بحث موقع انمي زد'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,979,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FSK_'+p4tN9ZkbucLj18+'بحث موقع فارسكو'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,999,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_HLC_'+p4tN9ZkbucLj18+'بحث موقع هلا سيما'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,89,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_MST_'+p4tN9ZkbucLj18+'بحث موقع المصطبة'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,869,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_SNT_'+p4tN9ZkbucLj18+'بحث موقع شوف نت'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,849,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_DR7_'+p4tN9ZkbucLj18+'بحث موقع دراما صح'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,689,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_CFR_'+p4tN9ZkbucLj18+'بحث موقع سيما فري'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,839,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_CMF_'+p4tN9ZkbucLj18+'بحث موقع سيما فانز'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,99,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_CML_'+p4tN9ZkbucLj18+'بحث موقع سيما لايت'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,479,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_C4H_'+p4tN9ZkbucLj18+'بحث موقع سيما 400'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,699,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_ABD_'+p4tN9ZkbucLj18+'بحث موقع سيما عبدو'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,559,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_AKT_'+p4tN9ZkbucLj18+'بحث موقع اكوام تيوب'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,859,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_DCF_'+p4tN9ZkbucLj18+'بحث موقع دراما كافيه'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,939,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FTV_'+p4tN9ZkbucLj18+'بحث موقع فوشار تيفي'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,919,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_CWB_'+p4tN9ZkbucLj18+'بحث موقع سيما وبس'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,989,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_AHK_'+p4tN9ZkbucLj18+'بحث موقع أهواك تيفي'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,619,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_SRT_'+p4tN9ZkbucLj18+'بحث موقع سيريس تايم'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,899,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_FVD_'+p4tN9ZkbucLj18+'بحث موقع فوشار فيديو'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,909,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_C4P_'+p4tN9ZkbucLj18+'بحث موقع سيما فور بي'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,889,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_EB4_'+p4tN9ZkbucLj18+'بحث موقع ايجي بيست 4'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,809,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'مواقع سيرفرات خاصة - قليلة المشاكل'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,157)
	EE6ysIeB8jKNgCfOkv('folder','_YUT_'+p4tN9ZkbucLj18+'بحث موقع يوتيوب'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,149,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	EE6ysIeB8jKNgCfOkv('folder','_DLM_'+p4tN9ZkbucLj18+'بحث موقع دايلي موشن'+D2vGheawHt3pBn9CbZs,kh850jKbzmBwY,409,kh850jKbzmBwY,kh850jKbzmBwY,BkpEeTDInR6LQFG2m1Ns)
	return
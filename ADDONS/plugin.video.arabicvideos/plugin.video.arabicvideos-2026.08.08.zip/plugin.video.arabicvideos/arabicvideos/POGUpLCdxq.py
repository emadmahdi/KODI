# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
KXWUabAT1GONjQ6ml2Z3cow7kPz5 = 'IPTV'
sglu80vyjMGhdWNi6E4Z5eVAKb = '_IPT_'
rLyahNuKk71Y5UWQeXl8mBFqx = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def cVwdXQBSYLaqJ9FeU(eYN1APt8aZflKmByj0ioGzn,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz,uDJvEcha9x4OtnN5e18yKqA3zgmW,AIZOsmw6lin0WxLe4zjp,ZtgNzIpQ4wOo3SjYyH0):
	global sglu80vyjMGhdWNi6E4Z5eVAKb
	try:
		MVuQxgTUyK = str(ZtgNzIpQ4wOo3SjYyH0['folder'])
		sglu80vyjMGhdWNi6E4Z5eVAKb = '_IP'+MVuQxgTUyK+'_'
	except: MVuQxgTUyK = kh850jKbzmBwY
	if   eYN1APt8aZflKmByj0ioGzn==230: X0mhvdbn9g61HlGZs = oIBeO19wsgzt5d2A8xn()
	elif eYN1APt8aZflKmByj0ioGzn==231: X0mhvdbn9g61HlGZs = UVWvGfLoC7jzlOt(MVuQxgTUyK)
	elif eYN1APt8aZflKmByj0ioGzn==232: X0mhvdbn9g61HlGZs = LdkfZTsaI6(MVuQxgTUyK)
	elif eYN1APt8aZflKmByj0ioGzn==233: X0mhvdbn9g61HlGZs = ELGOqyNZQRxIBo9g(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz,AIZOsmw6lin0WxLe4zjp)
	elif eYN1APt8aZflKmByj0ioGzn==234: X0mhvdbn9g61HlGZs = yIGljH8dub0q4zoD(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz,AIZOsmw6lin0WxLe4zjp)
	elif eYN1APt8aZflKmByj0ioGzn==235: X0mhvdbn9g61HlGZs = yv8LezRQifhw1Kx(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,uDJvEcha9x4OtnN5e18yKqA3zgmW)
	elif eYN1APt8aZflKmByj0ioGzn==236: X0mhvdbn9g61HlGZs = BpzXfU2PtDj5(MVuQxgTUyK,True)
	elif eYN1APt8aZflKmByj0ioGzn==237: X0mhvdbn9g61HlGZs = uf80nP6wIkzMNEHsLS2WO(MVuQxgTUyK,True)
	elif eYN1APt8aZflKmByj0ioGzn==238: X0mhvdbn9g61HlGZs = J1JEVlucdsaXCIwbTSGtRk5xe(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==239: X0mhvdbn9g61HlGZs = pDmCduxfSOb9yKGcP(fRJYhnSKHsZ7MqFwmiVz,MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,AIZOsmw6lin0WxLe4zjp)
	elif eYN1APt8aZflKmByj0ioGzn==280: X0mhvdbn9g61HlGZs = G3Y9xIhbPUgKRuLkE0NaJrWnF5T(MVuQxgTUyK,True)
	elif eYN1APt8aZflKmByj0ioGzn==281: X0mhvdbn9g61HlGZs = LI1NqPWEQDAFxchiKYreZf5stB(MVuQxgTUyK)
	elif eYN1APt8aZflKmByj0ioGzn==282: X0mhvdbn9g61HlGZs = mUYHjhxNVBOi1bl(MVuQxgTUyK)
	elif eYN1APt8aZflKmByj0ioGzn==283: X0mhvdbn9g61HlGZs = D8I4yOlxktgEPTruVZSnB9(MVuQxgTUyK)
	elif eYN1APt8aZflKmByj0ioGzn==285: X0mhvdbn9g61HlGZs = yzWgaGAiFK3sC9qQDIeT6Suw1k(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==286: X0mhvdbn9g61HlGZs = SrixBOX1jIJ2pT9EP8wn(MVuQxgTUyK)
	elif eYN1APt8aZflKmByj0ioGzn==289: X0mhvdbn9g61HlGZs = Yzhfkmxe1FO3(fRJYhnSKHsZ7MqFwmiVz,MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,AIZOsmw6lin0WxLe4zjp)
	else: X0mhvdbn9g61HlGZs = False
	return X0mhvdbn9g61HlGZs
def oIBeO19wsgzt5d2A8xn():
	for MVuQxgTUyK in range(1,xXUqn2W1CElKt0+1):
		sglu80vyjMGhdWNi6E4Z5eVAKb = '_IP'+str(MVuQxgTUyK)+'_'
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قائمة مجلد '+XCli7cMH0maTR[MVuQxgTUyK],kh850jKbzmBwY,280,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	return
def G3Y9xIhbPUgKRuLkE0NaJrWnF5T(MVuQxgTUyK=kh850jKbzmBwY,nITwbOW29VtLR7BUqYNX=kh850jKbzmBwY):
	if MVuQxgTUyK:
		MyKEdLiXUe1fvsoSu = {'folder':MVuQxgTUyK}
		wwmDeBsdxp = kh850jKbzmBwY
	else:
		MyKEdLiXUe1fvsoSu = kh850jKbzmBwY
		wwmDeBsdxp = kh850jKbzmBwY
	tZv7jeVHUk = I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX)
	if not tZv7jeVHUk:
		EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+RlMpu0hP8YmzZovkVXOs1G+' إضافة أو تغيير اشتراك'+wwmDeBsdxp+' '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,231,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+RlMpu0hP8YmzZovkVXOs1G+' جلب ملفات'+wwmDeBsdxp+' '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,232,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	else:
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'بحث في الملفات'+wwmDeBsdxp,kh850jKbzmBwY,289,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_',kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات مصنفة مرتبة'+wwmDeBsdxp,'LIVE_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات مصنفة من القسم'+wwmDeBsdxp,'LIVE_FROM_GROUP_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات مصنفة من الاسم'+wwmDeBsdxp,'LIVE_FROM_NAME_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات مصنفة بلا ترتيب'+wwmDeBsdxp,'LIVE_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات بلا ترتيب'+wwmDeBsdxp,'LIVE_ORIGINAL_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات مجهولة مرتبة'+wwmDeBsdxp,'LIVE_UNKNOWN_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'قنوات مجهولة بلا ترتيب'+wwmDeBsdxp,'LIVE_UNKNOWN_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'أفلام مصنفة بلا ترتيب'+wwmDeBsdxp,'VOD_MOVIES_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'أفلام مصنفة مرتبة'+wwmDeBsdxp,'VOD_MOVIES_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'مسلسلات مصنفة بلا ترتيب'+wwmDeBsdxp,'VOD_SERIES_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'مسلسلات مصنفة مرتبة'+wwmDeBsdxp,'VOD_SERIES_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'فيديوهات بلا ترتيب'+wwmDeBsdxp,'VOD_ORIGINAL_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'فيديوهات مصنفة من القسم'+wwmDeBsdxp,'VOD_FROM_GROUP_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'فيديوهات مصنفة من الاسم'+wwmDeBsdxp,'VOD_FROM_NAME_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'فيديوهات مجهولة بلا ترتيب'+wwmDeBsdxp,'VOD_UNKNOWN_GROUPED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'فيديوهات مجهولة مرتبة'+wwmDeBsdxp,'VOD_UNKNOWN_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'برامج القنوات (جدول فقط)'+wwmDeBsdxp,'LIVE_EPG_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'أرشيف القنوات للأيام الماضية'+wwmDeBsdxp,'LIVE_TIMESHIFT_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'أرشيف برامج القنوات للأيام الماضية'+wwmDeBsdxp,'LIVE_ARCHIVED_GROUPED_SORTED',233,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'إضافة أو تغيير اشتراك'+wwmDeBsdxp,kh850jKbzmBwY,231,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'جلب ملفات'+wwmDeBsdxp,kh850jKbzmBwY,232,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'مسح ملفات'+wwmDeBsdxp,kh850jKbzmBwY,237,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'فحص اشتراك'+wwmDeBsdxp,kh850jKbzmBwY,236,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'عدد فيديوهات'+wwmDeBsdxp,kh850jKbzmBwY,281,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'Referer تغيير'+wwmDeBsdxp,kh850jKbzmBwY,286,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'User-Agent تغيير'+wwmDeBsdxp,kh850jKbzmBwY,283,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+'استخدم السيرفر الأسرع'+wwmDeBsdxp,kh850jKbzmBwY,282,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,MyKEdLiXUe1fvsoSu)
	return
def BpzXfU2PtDj5(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX=True):
	KKwHAVRqbPfg,wb9nhQ6DW2vYoacPUJML7emC53dR = False,kh850jKbzmBwY
	ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr = kh850jKbzmBwY,kh850jKbzmBwY
	X8XrE9dRtVmNLy2BaOgJKwx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,zFRisTInHVNM,PdXj83zlyLfWGowmYTJ7art15,EXd8bTinsxYZG = WgP5ZytDrHKmjhIl6kVGwSz(MVuQxgTUyK)
	if PdXj83zlyLfWGowmYTJ7art15==kh850jKbzmBwY: return False,kh850jKbzmBwY,kh850jKbzmBwY
	ZZTivR1uy8jFJ7qUa5QNYCtd4 = C2S0UNM3PlzBIWtgnXHJcyhA5wLvq(MVuQxgTUyK)
	if X8XrE9dRtVmNLy2BaOgJKwx:
		qnE2chelYX3w9RAMSb = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'GET',X8XrE9dRtVmNLy2BaOgJKwx,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,False,kh850jKbzmBwY,'IPTV-CHECK_ACCOUNT-1st')
		wGAgfE7BYlCXex = qnE2chelYX3w9RAMSb.content
		if qnE2chelYX3w9RAMSb.succeeded:
			u7tmUBSLK135k,bfHGux4EI5MkhcCeXm,eEf42bncNukg3POByM9w5jJADzHQo,u8UczmgI7CO4eF,GX1aAKOxPdWwhe = 0,0,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY
			try:
				mudcb6l54eVhj920CDTxS = tmYCsS329HanzjLFbJP('dict',wGAgfE7BYlCXex)
				wb9nhQ6DW2vYoacPUJML7emC53dR = mudcb6l54eVhj920CDTxS['user_info']['status']
				KKwHAVRqbPfg = True
				eEf42bncNukg3POByM9w5jJADzHQo = mudcb6l54eVhj920CDTxS['server_info']['time_now']
			except: pass
			if eEf42bncNukg3POByM9w5jJADzHQo:
				try:
					Sqd49vcJWTHi7NF6EsgxR1MytzIp = pVesmhFG6wgubAODHSKvN1Wx.strptime(eEf42bncNukg3POByM9w5jJADzHQo,'%Y.%m.%d %H:%M:%S')
					u7tmUBSLK135k = int(pVesmhFG6wgubAODHSKvN1Wx.mktime(Sqd49vcJWTHi7NF6EsgxR1MytzIp))
					bfHGux4EI5MkhcCeXm = int(sC2g4oDQNAU7x-u7tmUBSLK135k)
					bfHGux4EI5MkhcCeXm = int((bfHGux4EI5MkhcCeXm+900)/1800)*1800
				except: pass
				try:
					Sqd49vcJWTHi7NF6EsgxR1MytzIp = pVesmhFG6wgubAODHSKvN1Wx.localtime(int(mudcb6l54eVhj920CDTxS['user_info']['created_at']))
					u8UczmgI7CO4eF = pVesmhFG6wgubAODHSKvN1Wx.strftime('%Y.%m.%d %H:%M:%S',Sqd49vcJWTHi7NF6EsgxR1MytzIp)
				except: pass
				try:
					Sqd49vcJWTHi7NF6EsgxR1MytzIp = pVesmhFG6wgubAODHSKvN1Wx.localtime(int(mudcb6l54eVhj920CDTxS['user_info']['exp_date']))
					GX1aAKOxPdWwhe = pVesmhFG6wgubAODHSKvN1Wx.strftime('%Y.%m.%d %H:%M:%S',Sqd49vcJWTHi7NF6EsgxR1MytzIp)
				except: pass
			l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.timestamp_'+MVuQxgTUyK,str(sC2g4oDQNAU7x))
			l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.timediff_'+MVuQxgTUyK,str(bfHGux4EI5MkhcCeXm))
			try:
				xxSnKN4g5d2JjuZefYmaUqX3WL = '"server_info":'+wGAgfE7BYlCXex.split('"server_info":')[1]
				xxSnKN4g5d2JjuZefYmaUqX3WL = xxSnKN4g5d2JjuZefYmaUqX3WL.replace(':',': ').replace(',',', ').replace('}}','}')
				Dlp4C3JzV7URk8biSaqXcsdm1YF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"url": "(.*?)", "port": "(.*?)"',xxSnKN4g5d2JjuZefYmaUqX3WL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr = Dlp4C3JzV7URk8biSaqXcsdm1YF[0]
			except: KKwHAVRqbPfg = False
			if KKwHAVRqbPfg and nITwbOW29VtLR7BUqYNX:
				max = mudcb6l54eVhj920CDTxS['user_info']['max_connections']
				uuORp2rlQzyN9tM = mudcb6l54eVhj920CDTxS['user_info']['active_cons']
				TdMyQLvc6VCFjABE9w8 = mudcb6l54eVhj920CDTxS['user_info']['is_trial']
				romB2OCMiqVK6yDSveXNtGulL4cPkg = X8XrE9dRtVmNLy2BaOgJKwx.split('?',1)
				gfe2BNJ3kTF0Xx = 'URL:  '+HHFAVK8SwRUqBLuTfdeJ9nbD+X8XrE9dRtVmNLy2BaOgJKwx+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\n\nStatus:  '+HHFAVK8SwRUqBLuTfdeJ9nbD+wb9nhQ6DW2vYoacPUJML7emC53dR+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\nTrial:    '+HHFAVK8SwRUqBLuTfdeJ9nbD+str(TdMyQLvc6VCFjABE9w8=='1')+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\nCreated  At:  '+HHFAVK8SwRUqBLuTfdeJ9nbD+u8UczmgI7CO4eF+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\nExpiry Date:  '+HHFAVK8SwRUqBLuTfdeJ9nbD+GX1aAKOxPdWwhe+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\nConnections   ( Active / Maximum ) :  '+HHFAVK8SwRUqBLuTfdeJ9nbD+uuORp2rlQzyN9tM+' / '+max+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\nAllowed Outputs:   '+HHFAVK8SwRUqBLuTfdeJ9nbD+" , ".join(mudcb6l54eVhj920CDTxS['user_info']['allowed_output_formats'])+wVvqN8LZCJW5ryAb1EHRPFkQ0
				gfe2BNJ3kTF0Xx += '\n\n'+xxSnKN4g5d2JjuZefYmaUqX3WL
				if wb9nhQ6DW2vYoacPUJML7emC53dR=='Active': Z7XaWzvgUpr4YhSjTyfPk('الاشتراك يعمل بدون مشاكل',gfe2BNJ3kTF0Xx)
				else: Z7XaWzvgUpr4YhSjTyfPk('يبدو أن هناك مشكلة في الاشتراك',gfe2BNJ3kTF0Xx)
	if X8XrE9dRtVmNLy2BaOgJKwx and KKwHAVRqbPfg and wb9nhQ6DW2vYoacPUJML7emC53dR=='Active':
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+X8XrE9dRtVmNLy2BaOgJKwx+' ]')
		p0tnXBb1Td2WGVE3A7yZcv = True
	else:
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,'Checking IPTV URL   [ Does not work ]   [ '+X8XrE9dRtVmNLy2BaOgJKwx+' ]')
		if nITwbOW29VtLR7BUqYNX: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		p0tnXBb1Td2WGVE3A7yZcv = False
	return p0tnXBb1Td2WGVE3A7yZcv,ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr
def yIGljH8dub0q4zoD(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy,fE0KldMIwQP1UeyT,I6DiqTSAsagUXbfnG,nITwbOW29VtLR7BUqYNX=True):
	if not I6DiqTSAsagUXbfnG: I6DiqTSAsagUXbfnG = '1'
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX): return
	SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy)
	PhTJmsMVHGt = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'list',Tn91jD2Ues7RYOdBfwy,fE0KldMIwQP1UeyT)
	W0PtGKJgnVwEBouzkydZaR6C = int(I6DiqTSAsagUXbfnG)*100
	MG8Na3YPdr4Xx = W0PtGKJgnVwEBouzkydZaR6C-100
	for LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1 in PhTJmsMVHGt[MG8Na3YPdr4Xx:W0PtGKJgnVwEBouzkydZaR6C]:
		Lost4xdenIgVEX = ('GROUPED' in Tn91jD2Ues7RYOdBfwy or Tn91jD2Ues7RYOdBfwy=='ALL')
		ssnNu2FKaW = ('GROUPED' not in Tn91jD2Ues7RYOdBfwy and Tn91jD2Ues7RYOdBfwy!='ALL')
		if Lost4xdenIgVEX or ssnNu2FKaW:
			if   'ARCHIVED'  in Tn91jD2Ues7RYOdBfwy: Y3Ny5eLHdp.menuItemsLIST.append(['folder',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,238,JeoM5hbREjnXOD1,kh850jKbzmBwY,'ARCHIVED',kh850jKbzmBwY,{'folder':MVuQxgTUyK}])
			elif 'EPG' 		 in Tn91jD2Ues7RYOdBfwy: Y3Ny5eLHdp.menuItemsLIST.append(['folder',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,238,JeoM5hbREjnXOD1,kh850jKbzmBwY,'FULL_EPG',kh850jKbzmBwY,{'folder':MVuQxgTUyK}])
			elif 'TIMESHIFT' in Tn91jD2Ues7RYOdBfwy: Y3Ny5eLHdp.menuItemsLIST.append(['folder',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,238,JeoM5hbREjnXOD1,kh850jKbzmBwY,'TIMESHIFT',kh850jKbzmBwY,{'folder':MVuQxgTUyK}])
			elif 'LIVE' 	 in Tn91jD2Ues7RYOdBfwy: Y3Ny5eLHdp.menuItemsLIST.append(['live',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,235,JeoM5hbREjnXOD1,kh850jKbzmBwY,kh850jKbzmBwY,LLjJSPRyT85B9Cq3,{'folder':MVuQxgTUyK}])
			else: Y3Ny5eLHdp.menuItemsLIST.append(['video',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,235,JeoM5hbREjnXOD1,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK}])
	YBzevm68pHSuQy = len(PhTJmsMVHGt)
	P4gGaQM7VLjzsixrcmuHBb35A1(MVuQxgTUyK,I6DiqTSAsagUXbfnG,Tn91jD2Ues7RYOdBfwy,234,YBzevm68pHSuQy,fE0KldMIwQP1UeyT)
	return
def ooSVIHFdGTBKlu7Uz56c9aq(f7fVh0kFwCW1SjedPsv2yrN):
	EE6ysIeB8jKNgCfOkv('link',f7fVh0kFwCW1SjedPsv2yrN+'هذه القائمة إما فارغة أو غير موجودة',kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('link',f7fVh0kFwCW1SjedPsv2yrN+'أو الخدمة غير موجودة في اشتراكك',kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('link',f7fVh0kFwCW1SjedPsv2yrN+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',kh850jKbzmBwY,9999)
	return
def ELGOqyNZQRxIBo9g(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy,fE0KldMIwQP1UeyT,I6DiqTSAsagUXbfnG,DfpTxH8yzJAMi6NlcbERU0WS=kh850jKbzmBwY,nITwbOW29VtLR7BUqYNX=True):
	if not I6DiqTSAsagUXbfnG: I6DiqTSAsagUXbfnG = '1'
	f7fVh0kFwCW1SjedPsv2yrN = sglu80vyjMGhdWNi6E4Z5eVAKb
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX): return False
	if '__SERIES__' in fE0KldMIwQP1UeyT: IsTMDzkhRLXKftgo8jPn,zzkfLQw16Ki9hMrSTEb = fE0KldMIwQP1UeyT.split('__SERIES__')
	else: IsTMDzkhRLXKftgo8jPn,zzkfLQw16Ki9hMrSTEb = fE0KldMIwQP1UeyT,kh850jKbzmBwY
	SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy)
	Gfkrb25eL3XDFQumSiV1ph = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'list',Tn91jD2Ues7RYOdBfwy,'__GROUPS__')
	if not Gfkrb25eL3XDFQumSiV1ph: return False
	toYwe1p5Enx = []
	for aaYES459ZRJ7m3,JeoM5hbREjnXOD1 in Gfkrb25eL3XDFQumSiV1ph:
		if DfpTxH8yzJAMi6NlcbERU0WS:
			if '__SERIES__' in aaYES459ZRJ7m3: f7fVh0kFwCW1SjedPsv2yrN = 'SERIES'
			elif '!!__UNKNOWN__!!' in aaYES459ZRJ7m3: f7fVh0kFwCW1SjedPsv2yrN = 'UNKNOWN'
			elif 'LIVE' in Tn91jD2Ues7RYOdBfwy: f7fVh0kFwCW1SjedPsv2yrN = 'LIVE'
			else: f7fVh0kFwCW1SjedPsv2yrN = 'VIDEOS'
			f7fVh0kFwCW1SjedPsv2yrN = ','+HHFAVK8SwRUqBLuTfdeJ9nbD+f7fVh0kFwCW1SjedPsv2yrN+': '+wVvqN8LZCJW5ryAb1EHRPFkQ0
		if '__SERIES__' in aaYES459ZRJ7m3: XMd3tHBNviDr,MdVOUist9wg = aaYES459ZRJ7m3.split('__SERIES__')
		else: XMd3tHBNviDr,MdVOUist9wg = aaYES459ZRJ7m3,kh850jKbzmBwY
		if not fE0KldMIwQP1UeyT:
			if XMd3tHBNviDr in toYwe1p5Enx: continue
			toYwe1p5Enx.append(XMd3tHBNviDr)
			if 'RANDOM' in DfpTxH8yzJAMi6NlcbERU0WS: EE6ysIeB8jKNgCfOkv('folder',f7fVh0kFwCW1SjedPsv2yrN+XMd3tHBNviDr,Tn91jD2Ues7RYOdBfwy,167,kh850jKbzmBwY,'1',aaYES459ZRJ7m3,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
			elif '__SERIES__' in aaYES459ZRJ7m3: EE6ysIeB8jKNgCfOkv('folder',f7fVh0kFwCW1SjedPsv2yrN+XMd3tHBNviDr,Tn91jD2Ues7RYOdBfwy,233,kh850jKbzmBwY,'1',aaYES459ZRJ7m3,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
			else: EE6ysIeB8jKNgCfOkv('folder',f7fVh0kFwCW1SjedPsv2yrN+XMd3tHBNviDr,Tn91jD2Ues7RYOdBfwy,234,kh850jKbzmBwY,'1',aaYES459ZRJ7m3,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
		elif '__SERIES__' in aaYES459ZRJ7m3 and XMd3tHBNviDr==IsTMDzkhRLXKftgo8jPn:
			if MdVOUist9wg in toYwe1p5Enx: continue
			toYwe1p5Enx.append(MdVOUist9wg)
			if 'RANDOM' in DfpTxH8yzJAMi6NlcbERU0WS: EE6ysIeB8jKNgCfOkv('folder',f7fVh0kFwCW1SjedPsv2yrN+MdVOUist9wg,Tn91jD2Ues7RYOdBfwy,167,kh850jKbzmBwY,'1',aaYES459ZRJ7m3,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
			else: EE6ysIeB8jKNgCfOkv('folder',f7fVh0kFwCW1SjedPsv2yrN+MdVOUist9wg,Tn91jD2Ues7RYOdBfwy,234,JeoM5hbREjnXOD1,'1',aaYES459ZRJ7m3,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	Y3Ny5eLHdp.menuItemsLIST[:] = sorted(Y3Ny5eLHdp.menuItemsLIST,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l[1].lower())
	if not DfpTxH8yzJAMi6NlcbERU0WS:
		W0PtGKJgnVwEBouzkydZaR6C = int(I6DiqTSAsagUXbfnG)*100
		MG8Na3YPdr4Xx = W0PtGKJgnVwEBouzkydZaR6C-100
		YBzevm68pHSuQy = len(Y3Ny5eLHdp.menuItemsLIST)
		Y3Ny5eLHdp.menuItemsLIST[:] = Y3Ny5eLHdp.menuItemsLIST[MG8Na3YPdr4Xx:W0PtGKJgnVwEBouzkydZaR6C]
		P4gGaQM7VLjzsixrcmuHBb35A1(MVuQxgTUyK,I6DiqTSAsagUXbfnG,Tn91jD2Ues7RYOdBfwy,233,YBzevm68pHSuQy,fE0KldMIwQP1UeyT)
	return True
def J1JEVlucdsaXCIwbTSGtRk5xe(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,FhSy4bc087wOLinxzqCekrtf2):
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,True): return
	ZZTivR1uy8jFJ7qUa5QNYCtd4 = C2S0UNM3PlzBIWtgnXHJcyhA5wLvq(MVuQxgTUyK)
	u7tmUBSLK135k = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.timestamp_'+MVuQxgTUyK)
	if not u7tmUBSLK135k or sC2g4oDQNAU7x-int(u7tmUBSLK135k)>24*bbQgZCcL8Ya3UdP4zKAryn:
		p0tnXBb1Td2WGVE3A7yZcv,ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr = BpzXfU2PtDj5(MVuQxgTUyK,False)
		if not p0tnXBb1Td2WGVE3A7yZcv: return
	bfHGux4EI5MkhcCeXm = int(l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.timediff_'+MVuQxgTUyK))
	zFRisTInHVNM = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.server_'+MVuQxgTUyK)
	PdXj83zlyLfWGowmYTJ7art15 = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.username_'+MVuQxgTUyK)
	EXd8bTinsxYZG = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.password_'+MVuQxgTUyK)
	VMUJnKtcqh = QmRL0swTcY9dXyIgrp82Aa1ekD.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	ZZaiOv3Ko0IQ2syHJEW1puGU9B = VMUJnKtcqh[-1].replace('.ts',kh850jKbzmBwY).replace('.m3u8',kh850jKbzmBwY)
	if FhSy4bc087wOLinxzqCekrtf2=='SHORT_EPG': biuIT0jXkzwGBoW8YdUmaZ9M6 = 'get_short_epg'
	else: biuIT0jXkzwGBoW8YdUmaZ9M6 = 'get_simple_data_table'
	X8XrE9dRtVmNLy2BaOgJKwx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,zFRisTInHVNM,PdXj83zlyLfWGowmYTJ7art15,EXd8bTinsxYZG = WgP5ZytDrHKmjhIl6kVGwSz(MVuQxgTUyK)
	if not PdXj83zlyLfWGowmYTJ7art15: return
	HzIvgNJE2uO = X8XrE9dRtVmNLy2BaOgJKwx+'&action='+biuIT0jXkzwGBoW8YdUmaZ9M6+'&stream_id='+ZZaiOv3Ko0IQ2syHJEW1puGU9B
	wGAgfE7BYlCXex = hEMa2SNAX1dDZ9u58JKcebtfUCwyY(uQIXMypK534GsVWetdl6Px9fTjUn,HzIvgNJE2uO,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,kh850jKbzmBwY,'IPTV-EPG_ITEMS-2nd')
	bHWlwdjLp4TnAXi8mZ = tmYCsS329HanzjLFbJP('dict',wGAgfE7BYlCXex)
	L8Co41jYEfFru7IK9zd3AXvZQHwb2g = bHWlwdjLp4TnAXi8mZ['epg_listings']
	nngRM3XyOljDu = []
	if FhSy4bc087wOLinxzqCekrtf2 in ['ARCHIVED','TIMESHIFT']:
		for mudcb6l54eVhj920CDTxS in L8Co41jYEfFru7IK9zd3AXvZQHwb2g:
			if mudcb6l54eVhj920CDTxS['has_archive']==1:
				nngRM3XyOljDu.append(mudcb6l54eVhj920CDTxS)
				if FhSy4bc087wOLinxzqCekrtf2 in ['TIMESHIFT']: break
		if not nngRM3XyOljDu: return
		EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+HHFAVK8SwRUqBLuTfdeJ9nbD+'الملفات الأولي بهذه القائمة قد لا تعمل'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		if FhSy4bc087wOLinxzqCekrtf2 in ['TIMESHIFT']:
			cdeObBIFzNCGMhAU93nKLQVsi4Ru = 2
			aM02fL7zNnSFbYXe6JARlqsw5iUKEg = cdeObBIFzNCGMhAU93nKLQVsi4Ru*bbQgZCcL8Ya3UdP4zKAryn
			nngRM3XyOljDu = []
			ttOjmzPC56Uk = int(int(mudcb6l54eVhj920CDTxS['start_timestamp'])/aM02fL7zNnSFbYXe6JARlqsw5iUKEg)*aM02fL7zNnSFbYXe6JARlqsw5iUKEg
			nvYphX6oES = sC2g4oDQNAU7x+aM02fL7zNnSFbYXe6JARlqsw5iUKEg
			j8kf7sWlwLmXJ5zHQy = int((nvYphX6oES-ttOjmzPC56Uk)/bbQgZCcL8Ya3UdP4zKAryn)
			for ENrzhWRykvKitAY in range(j8kf7sWlwLmXJ5zHQy):
				if ENrzhWRykvKitAY>=6:
					if ENrzhWRykvKitAY%cdeObBIFzNCGMhAU93nKLQVsi4Ru!=0: continue
					bWwkVQg90T4UanAjt6dux3BCs2FXl = aM02fL7zNnSFbYXe6JARlqsw5iUKEg
				else: bWwkVQg90T4UanAjt6dux3BCs2FXl = aM02fL7zNnSFbYXe6JARlqsw5iUKEg//2
				fsuoJlbTXPkgnQSLz5ORYc = ttOjmzPC56Uk+ENrzhWRykvKitAY*bbQgZCcL8Ya3UdP4zKAryn
				mudcb6l54eVhj920CDTxS = {}
				mudcb6l54eVhj920CDTxS['title'] = kh850jKbzmBwY
				Sqd49vcJWTHi7NF6EsgxR1MytzIp = pVesmhFG6wgubAODHSKvN1Wx.localtime(fsuoJlbTXPkgnQSLz5ORYc-bfHGux4EI5MkhcCeXm-bbQgZCcL8Ya3UdP4zKAryn)
				mudcb6l54eVhj920CDTxS['start'] = pVesmhFG6wgubAODHSKvN1Wx.strftime('%Y.%m.%d %H:%M:%S',Sqd49vcJWTHi7NF6EsgxR1MytzIp)
				mudcb6l54eVhj920CDTxS['start_timestamp'] = str(fsuoJlbTXPkgnQSLz5ORYc)
				mudcb6l54eVhj920CDTxS['stop_timestamp'] = str(fsuoJlbTXPkgnQSLz5ORYc+bWwkVQg90T4UanAjt6dux3BCs2FXl)
				nngRM3XyOljDu.append(mudcb6l54eVhj920CDTxS)
	elif FhSy4bc087wOLinxzqCekrtf2 in ['SHORT_EPG','FULL_EPG']: nngRM3XyOljDu = L8Co41jYEfFru7IK9zd3AXvZQHwb2g
	if FhSy4bc087wOLinxzqCekrtf2=='FULL_EPG' and len(nngRM3XyOljDu)>0:
		EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+HHFAVK8SwRUqBLuTfdeJ9nbD+'هذه قائمة برامج القنوات (جدول فقط)ـ'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	wHD6OLQ3fVYpEhoteaUsC502j = []
	JeoM5hbREjnXOD1 = ppNwDFByU1dZn5ca.getInfoLabel('ListItem.Icon')
	for mudcb6l54eVhj920CDTxS in nngRM3XyOljDu:
		ZuIGmbiCfy6xvAgMTo7aS0kpznQ = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(mudcb6l54eVhj920CDTxS['title'])
		if eOQJrvLAZC: ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.decode(NVbhZ0DTpOkCA)
		fsuoJlbTXPkgnQSLz5ORYc = int(mudcb6l54eVhj920CDTxS['start_timestamp'])
		AA5ksOf8xdB317UzilCyJjEqhISc = int(mudcb6l54eVhj920CDTxS['stop_timestamp'])
		Zs8uqeTojhl9gmvb1y46riNDMwX = str(int((AA5ksOf8xdB317UzilCyJjEqhISc-fsuoJlbTXPkgnQSLz5ORYc+59)/60))
		XI8EUtzcwFv1294pGHd = mudcb6l54eVhj920CDTxS['start'].replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,':')
		Sqd49vcJWTHi7NF6EsgxR1MytzIp = pVesmhFG6wgubAODHSKvN1Wx.localtime(fsuoJlbTXPkgnQSLz5ORYc-bbQgZCcL8Ya3UdP4zKAryn)
		xwIyM2PT04dogKpkiU71ftqzY = pVesmhFG6wgubAODHSKvN1Wx.strftime('%H:%M',Sqd49vcJWTHi7NF6EsgxR1MytzIp)
		S9kBArCoL1KNgFbMvQd67It5OlEJ = pVesmhFG6wgubAODHSKvN1Wx.strftime('%a',Sqd49vcJWTHi7NF6EsgxR1MytzIp)
		if FhSy4bc087wOLinxzqCekrtf2=='SHORT_EPG': ZuIGmbiCfy6xvAgMTo7aS0kpznQ = RlMpu0hP8YmzZovkVXOs1G+xwIyM2PT04dogKpkiU71ftqzY+' ـ '+ZuIGmbiCfy6xvAgMTo7aS0kpznQ+wVvqN8LZCJW5ryAb1EHRPFkQ0
		elif FhSy4bc087wOLinxzqCekrtf2=='TIMESHIFT': ZuIGmbiCfy6xvAgMTo7aS0kpznQ = S9kBArCoL1KNgFbMvQd67It5OlEJ+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+xwIyM2PT04dogKpkiU71ftqzY+' ('+Zs8uqeTojhl9gmvb1y46riNDMwX+'min)'
		else: ZuIGmbiCfy6xvAgMTo7aS0kpznQ = S9kBArCoL1KNgFbMvQd67It5OlEJ+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+xwIyM2PT04dogKpkiU71ftqzY+' ('+Zs8uqeTojhl9gmvb1y46riNDMwX+'min)   '+ZuIGmbiCfy6xvAgMTo7aS0kpznQ+' ـ'
		if FhSy4bc087wOLinxzqCekrtf2 in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			T7TY0klWnZvD2mJG6raMCuI = zFRisTInHVNM+'/timeshift/'+PdXj83zlyLfWGowmYTJ7art15+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+EXd8bTinsxYZG+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Zs8uqeTojhl9gmvb1y46riNDMwX+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+XI8EUtzcwFv1294pGHd+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+ZZaiOv3Ko0IQ2syHJEW1puGU9B+'.m3u8'
			if FhSy4bc087wOLinxzqCekrtf2=='FULL_EPG': EE6ysIeB8jKNgCfOkv('link',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,T7TY0klWnZvD2mJG6raMCuI,9999,JeoM5hbREjnXOD1,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
			else: EE6ysIeB8jKNgCfOkv('video',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,T7TY0klWnZvD2mJG6raMCuI,235,JeoM5hbREjnXOD1,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
		wHD6OLQ3fVYpEhoteaUsC502j.append(ZuIGmbiCfy6xvAgMTo7aS0kpznQ)
	if FhSy4bc087wOLinxzqCekrtf2=='SHORT_EPG' and wHD6OLQ3fVYpEhoteaUsC502j: dvNc5OmlsFqKJyVGE3QDbhZ0kS = gPYeVMwT5u1EQkpl2BGNZHXd(wHD6OLQ3fVYpEhoteaUsC502j)
	return wHD6OLQ3fVYpEhoteaUsC502j
def mUYHjhxNVBOi1bl(MVuQxgTUyK):
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,True): return
	zFRisTInHVNM,ytPQSXZE714U0u3,spyaugSf7NTBKmC8wJHFtIbPWAXLRj = kh850jKbzmBwY,0,0
	p0tnXBb1Td2WGVE3A7yZcv,ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr = BpzXfU2PtDj5(MVuQxgTUyK,False)
	if p0tnXBb1Td2WGVE3A7yZcv:
		tjMFwNCP4nAlG = kYs9RtXTaMFL4lQnyKV3NPj(ffvYVrA80Q7wXmxuTsz2RMOnCh)
		ytPQSXZE714U0u3 = EVdbBHraG7gFeChjkTPfoOwS(tjMFwNCP4nAlG[0],int(gAu3X4VHJ6DohW09ijBlyYQ7fNtSr))
		SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,'LIVE_GROUPED')
		Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'list','LIVE_GROUPED')
		PhTJmsMVHGt = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'list','LIVE_GROUPED',Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y[1])
		QmRL0swTcY9dXyIgrp82Aa1ekD = PhTJmsMVHGt[0][2]
		UUjSp0L75b9OMBrzCPsa1EFT = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('://(.*?)/',QmRL0swTcY9dXyIgrp82Aa1ekD,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		UUjSp0L75b9OMBrzCPsa1EFT = UUjSp0L75b9OMBrzCPsa1EFT[0]
		if ':' in UUjSp0L75b9OMBrzCPsa1EFT: WtHJpasNZx983Gd,cikvpV1AWgC768SyMdQ = UUjSp0L75b9OMBrzCPsa1EFT.split(':')
		else: WtHJpasNZx983Gd,cikvpV1AWgC768SyMdQ = UUjSp0L75b9OMBrzCPsa1EFT,'80'
		lKRhF8bGocqyd4TZ2Pm0EtkugQ = kYs9RtXTaMFL4lQnyKV3NPj(WtHJpasNZx983Gd)
		spyaugSf7NTBKmC8wJHFtIbPWAXLRj = EVdbBHraG7gFeChjkTPfoOwS(lKRhF8bGocqyd4TZ2Pm0EtkugQ[0],int(cikvpV1AWgC768SyMdQ))
	if ytPQSXZE714U0u3 and spyaugSf7NTBKmC8wJHFtIbPWAXLRj:
		gfe2BNJ3kTF0Xx = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		gfe2BNJ3kTF0Xx += '\n\n'+'وقت ضائع في السيرفر الأصلي'+URBvawyLXfQiS2NI34HDk+str(int(spyaugSf7NTBKmC8wJHFtIbPWAXLRj*1000))+' ملي ثانية'
		gfe2BNJ3kTF0Xx += '\n\n'+'وقت ضائع في السيرفر البديل'+URBvawyLXfQiS2NI34HDk+str(int(ytPQSXZE714U0u3*1000))+' ملي ثانية'
		oPseX03Q2D4gjy7TMHbz = aa48i0SKpcGbWFBYLtCre('center','السيرفر الأصلي','السيرفر الأسرع',fWM6PeOrvciG0RQpIKzltojDqaYs,gfe2BNJ3kTF0Xx)
		if oPseX03Q2D4gjy7TMHbz==1 and ytPQSXZE714U0u3<spyaugSf7NTBKmC8wJHFtIbPWAXLRj: zFRisTInHVNM = ffvYVrA80Q7wXmxuTsz2RMOnCh+':'+gAu3X4VHJ6DohW09ijBlyYQ7fNtSr
	else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'البرنامج لم يجد السيرفر البديل')
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.server_'+MVuQxgTUyK,zFRisTInHVNM)
	return
def yv8LezRQifhw1Kx(MVuQxgTUyK,QmRL0swTcY9dXyIgrp82Aa1ekD,uDJvEcha9x4OtnN5e18yKqA3zgmW):
	HLlO2nw9C4ugGiFr = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.useragent_'+MVuQxgTUyK)
	limf2hZrL6tCWQbBM = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.referer_'+MVuQxgTUyK)
	if HLlO2nw9C4ugGiFr or limf2hZrL6tCWQbBM:
		QmRL0swTcY9dXyIgrp82Aa1ekD += '|'
		if HLlO2nw9C4ugGiFr: QmRL0swTcY9dXyIgrp82Aa1ekD += '&User-Agent='+HLlO2nw9C4ugGiFr
		if limf2hZrL6tCWQbBM: QmRL0swTcY9dXyIgrp82Aa1ekD += '&Referer='+limf2hZrL6tCWQbBM
		QmRL0swTcY9dXyIgrp82Aa1ekD = QmRL0swTcY9dXyIgrp82Aa1ekD.replace('|&','|')
	iOkuK7CHrfhwsjv = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.server_'+MVuQxgTUyK)
	if iOkuK7CHrfhwsjv:
		Qwdb9fPZxOUKa3AFqI8ESYW = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('://(.*?)/',QmRL0swTcY9dXyIgrp82Aa1ekD,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		QmRL0swTcY9dXyIgrp82Aa1ekD = QmRL0swTcY9dXyIgrp82Aa1ekD.replace(Qwdb9fPZxOUKa3AFqI8ESYW[0],iOkuK7CHrfhwsjv)
	NRlCaq1ndM(QmRL0swTcY9dXyIgrp82Aa1ekD,KXWUabAT1GONjQ6ml2Z3cow7kPz5,uDJvEcha9x4OtnN5e18yKqA3zgmW)
	return
def D8I4yOlxktgEPTruVZSnB9(MVuQxgTUyK):
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	HLlO2nw9C4ugGiFr = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.useragent_'+MVuQxgTUyK)
	eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('center','استخدام الأصلي','تعديل القديم',HLlO2nw9C4ugGiFr,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if eu1tKi9gm0==1: HLlO2nw9C4ugGiFr = GG5Fs0hvURxyBV8gz('أكتب ـIPTV User-Agent جديد',HLlO2nw9C4ugGiFr,True)
	else: HLlO2nw9C4ugGiFr = 'Unknown'
	if HLlO2nw9C4ugGiFr==EE3iZM15sTQ2t9cOhuCWwDjGSUzryF:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,HLlO2nw9C4ugGiFr,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if eu1tKi9gm0!=1:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم الإلغاء')
		return
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.useragent_'+MVuQxgTUyK,HLlO2nw9C4ugGiFr)
	Qt2cnJzb9PM4AfjWyZLEIroV7F(MVuQxgTUyK)
	return
def SrixBOX1jIJ2pT9EP8wn(MVuQxgTUyK):
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	limf2hZrL6tCWQbBM = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.referer_'+MVuQxgTUyK)
	eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('center','استخدام الأصلي','تعديل القديم',limf2hZrL6tCWQbBM,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if eu1tKi9gm0==1: limf2hZrL6tCWQbBM = GG5Fs0hvURxyBV8gz('أكتب ـIPTV Referer جديد',limf2hZrL6tCWQbBM,True)
	else: limf2hZrL6tCWQbBM = kh850jKbzmBwY
	if limf2hZrL6tCWQbBM==EE3iZM15sTQ2t9cOhuCWwDjGSUzryF:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,limf2hZrL6tCWQbBM,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if eu1tKi9gm0!=1:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم الإلغاء')
		return
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.referer_'+MVuQxgTUyK,limf2hZrL6tCWQbBM)
	Qt2cnJzb9PM4AfjWyZLEIroV7F(MVuQxgTUyK)
	return
def WgP5ZytDrHKmjhIl6kVGwSz(MVuQxgTUyK,SELAwNZB4s=kh850jKbzmBwY):
	if not SELAwNZB4s: SELAwNZB4s = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.url_'+MVuQxgTUyK)
	zFRisTInHVNM = hBRWs4K6t1nderkNEQo7bIvCFuZfS(SELAwNZB4s,'url')
	PdXj83zlyLfWGowmYTJ7art15 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('username=(.*?)&',SELAwNZB4s+'&',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	EXd8bTinsxYZG = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('password=(.*?)&',SELAwNZB4s+'&',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not PdXj83zlyLfWGowmYTJ7art15 or not EXd8bTinsxYZG:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY
	PdXj83zlyLfWGowmYTJ7art15 = PdXj83zlyLfWGowmYTJ7art15[0]
	EXd8bTinsxYZG = EXd8bTinsxYZG[0]
	X8XrE9dRtVmNLy2BaOgJKwx = zFRisTInHVNM+'/player_api.php?username='+PdXj83zlyLfWGowmYTJ7art15+'&password='+EXd8bTinsxYZG
	Se5znCoQLf1J0g2UIA3jixVpBqT9Wd = zFRisTInHVNM+'/get.php?username='+PdXj83zlyLfWGowmYTJ7art15+'&password='+EXd8bTinsxYZG+'&type=m3u_plus'
	return X8XrE9dRtVmNLy2BaOgJKwx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,zFRisTInHVNM,PdXj83zlyLfWGowmYTJ7art15,EXd8bTinsxYZG
def LpFTwflVW8sa19vA(MVuQxgTUyK,mzOP482s3e=kh850jKbzmBwY):
	Dy7z9Yj5gH68LhZ = mzOP482s3e.replace(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,'_').replace(':','_').replace('.','_')
	Dy7z9Yj5gH68LhZ = Dy7z9Yj5gH68LhZ.replace('?','_').replace('=','_').replace('&','_')
	Dy7z9Yj5gH68LhZ = YdDkIjFhgzuboBKca70ERt.path.join(qJWGLeXlsvHDr,Dy7z9Yj5gH68LhZ).strip('.m3u')+'.m3u'
	return Dy7z9Yj5gH68LhZ
def UVWvGfLoC7jzlOt(MVuQxgTUyK):
	m4mILh8Xe1R = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.url_'+MVuQxgTUyK)
	m5fNGtKCZUF = True
	if m4mILh8Xe1R:
		eu1tKi9gm0 = NJZUGpSmQLPBxuv3Mn('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',HHFAVK8SwRUqBLuTfdeJ9nbD+m4mILh8Xe1R+wVvqN8LZCJW5ryAb1EHRPFkQ0+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if eu1tKi9gm0==-1: return
		elif eu1tKi9gm0==0: m4mILh8Xe1R = kh850jKbzmBwY
		elif eu1tKi9gm0==2:
			eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if eu1tKi9gm0 in [-1,0]: return
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم مسح الرابط')
			m5fNGtKCZUF = False
			pNCf9XBKjbVPSu = kh850jKbzmBwY
	if m5fNGtKCZUF:
		pNCf9XBKjbVPSu = GG5Fs0hvURxyBV8gz('اكتب رابط ـIPTV كاملا',m4mILh8Xe1R)
		pNCf9XBKjbVPSu = pNCf9XBKjbVPSu.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if not pNCf9XBKjbVPSu:
			eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if eu1tKi9gm0 in [-1,0]: return
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم مسح الرابط')
	else:
		X8XrE9dRtVmNLy2BaOgJKwx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,zFRisTInHVNM,PdXj83zlyLfWGowmYTJ7art15,EXd8bTinsxYZG = WgP5ZytDrHKmjhIl6kVGwSz(MVuQxgTUyK,pNCf9XBKjbVPSu)
		if not PdXj83zlyLfWGowmYTJ7art15: return
		gfe2BNJ3kTF0Xx = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		gfe2BNJ3kTF0Xx += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+zFRisTInHVNM+wVvqN8LZCJW5ryAb1EHRPFkQ0+'عنوان السيرفر: '
		gfe2BNJ3kTF0Xx += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+PdXj83zlyLfWGowmYTJ7art15+wVvqN8LZCJW5ryAb1EHRPFkQ0+'اسم المستخدم: '
		gfe2BNJ3kTF0Xx += URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+iSkaBp8qJyeQzwCD++'كلمة السر: '
		eu1tKi9gm0 = aa48i0SKpcGbWFBYLtCre('right',kh850jKbzmBwY,kh850jKbzmBwY,'الرابط الجديد هو:',HHFAVK8SwRUqBLuTfdeJ9nbD+pNCf9XBKjbVPSu+wVvqN8LZCJW5ryAb1EHRPFkQ0+'\n\n'+gfe2BNJ3kTF0Xx)
		if eu1tKi9gm0!=1:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم الإلغاء')
			return
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.url_'+MVuQxgTUyK,pNCf9XBKjbVPSu)
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.timestamp_'+MVuQxgTUyK,kh850jKbzmBwY)
	l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.timediff_'+MVuQxgTUyK,kh850jKbzmBwY)
	HLlO2nw9C4ugGiFr = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.useragent_'+MVuQxgTUyK)
	if not HLlO2nw9C4ugGiFr: l7tuXCf0oKV9FPOy6Hb.setSetting('av.iptv.useragent_'+MVuQxgTUyK,'Unknown')
	bml5ckdXs2r3UWC0YeaSiA = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,pNCf9XBKjbVPSu+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if bml5ckdXs2r3UWC0YeaSiA==1: p0tnXBb1Td2WGVE3A7yZcv,ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr = BpzXfU2PtDj5(MVuQxgTUyK,True)
	Qt2cnJzb9PM4AfjWyZLEIroV7F(MVuQxgTUyK)
	return
def KbkZgyvXALwuDH7zq1phaS(XXluaiyqGjfzJnxVtm458bTYRI,X3XGLA4Zkp,lXVt8ErH5J92coBah1WR3iO4yKwed,LLMuqs42Yn9owv713xRODSVzCiyA5m,J4XmNeTxEGfkB9CqjZr3,juLSnF2ey4Vfx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd):
	PhTJmsMVHGt,A2CHQFM8sgZiSEx = [],[]
	p45dEV7wqSrnMJKDky = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for KXVpQi6eGUdNCO1LumZkRDS3vqWYh in XXluaiyqGjfzJnxVtm458bTYRI:
		if juLSnF2ey4Vfx%473==0:
			TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,40+int(10*juLSnF2ey4Vfx/J4XmNeTxEGfkB9CqjZr3),'قراءة الفيديوهات','الفيديو رقم:-',str(juLSnF2ey4Vfx)+' / '+str(J4XmNeTxEGfkB9CqjZr3))
			if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
				LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
				return None,None,None
		QmRL0swTcY9dXyIgrp82Aa1ekD = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^(.*?)\n+((http|https|rtmp).*?)$',KXVpQi6eGUdNCO1LumZkRDS3vqWYh,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if QmRL0swTcY9dXyIgrp82Aa1ekD:
			KXVpQi6eGUdNCO1LumZkRDS3vqWYh,QmRL0swTcY9dXyIgrp82Aa1ekD,UDcrMhq2jdQwL4P9BoESJVkOIRK1uT = QmRL0swTcY9dXyIgrp82Aa1ekD[0]
			QmRL0swTcY9dXyIgrp82Aa1ekD = QmRL0swTcY9dXyIgrp82Aa1ekD.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY)
			KXVpQi6eGUdNCO1LumZkRDS3vqWYh = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY)
		else:
			A2CHQFM8sgZiSEx.append({'line':KXVpQi6eGUdNCO1LumZkRDS3vqWYh})
			continue
		ppJnf1qD3j5yBErlGIZeRCU,LLjJSPRyT85B9Cq3,aaYES459ZRJ7m3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,uDJvEcha9x4OtnN5e18yKqA3zgmW,MmEBwALfF7bvgCZGWYlcz3hsJy9e = {},kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,False
		try:
			KXVpQi6eGUdNCO1LumZkRDS3vqWYh,ZuIGmbiCfy6xvAgMTo7aS0kpznQ = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.rsplit('",',1)
			KXVpQi6eGUdNCO1LumZkRDS3vqWYh = KXVpQi6eGUdNCO1LumZkRDS3vqWYh+'"'
		except:
			try: KXVpQi6eGUdNCO1LumZkRDS3vqWYh,ZuIGmbiCfy6xvAgMTo7aS0kpznQ = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.rsplit('1,',1)
			except: ZuIGmbiCfy6xvAgMTo7aS0kpznQ = kh850jKbzmBwY
		ppJnf1qD3j5yBErlGIZeRCU['url'] = QmRL0swTcY9dXyIgrp82Aa1ekD
		riIzK7uaSeA58k0O = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(' (.*?)="(.*?)"',KXVpQi6eGUdNCO1LumZkRDS3vqWYh,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for fOX1xaTVkPrbmWg0l,IiYrTdMHyaRXEAsz5Q7 in riIzK7uaSeA58k0O:
			fOX1xaTVkPrbmWg0l = fOX1xaTVkPrbmWg0l.replace('"',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			ppJnf1qD3j5yBErlGIZeRCU[fOX1xaTVkPrbmWg0l] = IiYrTdMHyaRXEAsz5Q7.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		yDnk05wu2PI4 = list(ppJnf1qD3j5yBErlGIZeRCU.keys())
		if not ZuIGmbiCfy6xvAgMTo7aS0kpznQ:
			if 'name' in yDnk05wu2PI4 and ppJnf1qD3j5yBErlGIZeRCU['name']: ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ppJnf1qD3j5yBErlGIZeRCU['name']
		ppJnf1qD3j5yBErlGIZeRCU['title'] = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'logo' in yDnk05wu2PI4:
			ppJnf1qD3j5yBErlGIZeRCU['img'] = ppJnf1qD3j5yBErlGIZeRCU['logo']
			del ppJnf1qD3j5yBErlGIZeRCU['logo']
		else: ppJnf1qD3j5yBErlGIZeRCU['img'] = kh850jKbzmBwY
		if 'group' in yDnk05wu2PI4 and ppJnf1qD3j5yBErlGIZeRCU['group']: aaYES459ZRJ7m3 = ppJnf1qD3j5yBErlGIZeRCU['group']
		if any(value in QmRL0swTcY9dXyIgrp82Aa1ekD.lower() for value in p45dEV7wqSrnMJKDky):
			MmEBwALfF7bvgCZGWYlcz3hsJy9e = True if 'm3u' not in QmRL0swTcY9dXyIgrp82Aa1ekD else False
		if MmEBwALfF7bvgCZGWYlcz3hsJy9e or '__SERIES__' in aaYES459ZRJ7m3 or '__MOVIES__' in aaYES459ZRJ7m3:
			uDJvEcha9x4OtnN5e18yKqA3zgmW = 'VOD'
			if '__SERIES__' in aaYES459ZRJ7m3: uDJvEcha9x4OtnN5e18yKqA3zgmW = uDJvEcha9x4OtnN5e18yKqA3zgmW+'_SERIES'
			elif '__MOVIES__' in aaYES459ZRJ7m3: uDJvEcha9x4OtnN5e18yKqA3zgmW = uDJvEcha9x4OtnN5e18yKqA3zgmW+'_MOVIES'
			else: uDJvEcha9x4OtnN5e18yKqA3zgmW = uDJvEcha9x4OtnN5e18yKqA3zgmW+'_UNKNOWN'
			aaYES459ZRJ7m3 = aaYES459ZRJ7m3.replace('__SERIES__',kh850jKbzmBwY).replace('__MOVIES__',kh850jKbzmBwY)
		else:
			uDJvEcha9x4OtnN5e18yKqA3zgmW = 'LIVE'
			if ZuIGmbiCfy6xvAgMTo7aS0kpznQ in X3XGLA4Zkp: LLjJSPRyT85B9Cq3 = LLjJSPRyT85B9Cq3+'_EPG'
			if ZuIGmbiCfy6xvAgMTo7aS0kpznQ in lXVt8ErH5J92coBah1WR3iO4yKwed: LLjJSPRyT85B9Cq3 = LLjJSPRyT85B9Cq3+'_ARCHIVED'
			if not aaYES459ZRJ7m3: uDJvEcha9x4OtnN5e18yKqA3zgmW = uDJvEcha9x4OtnN5e18yKqA3zgmW+'_UNKNOWN'
			else: uDJvEcha9x4OtnN5e18yKqA3zgmW = uDJvEcha9x4OtnN5e18yKqA3zgmW+LLjJSPRyT85B9Cq3
		aaYES459ZRJ7m3 = aaYES459ZRJ7m3.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'LIVE_UNKNOWN' in uDJvEcha9x4OtnN5e18yKqA3zgmW: aaYES459ZRJ7m3 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in uDJvEcha9x4OtnN5e18yKqA3zgmW: aaYES459ZRJ7m3 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in uDJvEcha9x4OtnN5e18yKqA3zgmW:
			Tt91pdaGc857WOU3Ah2D = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) [Ss]\d+ +[Ee]\d+',ppJnf1qD3j5yBErlGIZeRCU['title'],sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if Tt91pdaGc857WOU3Ah2D: Tt91pdaGc857WOU3Ah2D = Tt91pdaGc857WOU3Ah2D[0]
			else: Tt91pdaGc857WOU3Ah2D = '!!__UNKNOWN_SERIES__!!'
			aaYES459ZRJ7m3 = aaYES459ZRJ7m3+'__SERIES__'+Tt91pdaGc857WOU3Ah2D
		if 'id' in yDnk05wu2PI4: del ppJnf1qD3j5yBErlGIZeRCU['id']
		if 'ID' in yDnk05wu2PI4: del ppJnf1qD3j5yBErlGIZeRCU['ID']
		if 'name' in yDnk05wu2PI4: del ppJnf1qD3j5yBErlGIZeRCU['name']
		ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ppJnf1qD3j5yBErlGIZeRCU['title']
		ZuIGmbiCfy6xvAgMTo7aS0kpznQ = Z4CP1xs5w7fi(ZuIGmbiCfy6xvAgMTo7aS0kpznQ)
		ZuIGmbiCfy6xvAgMTo7aS0kpznQ = kcethajG49mLgU2vOHwPo8(ZuIGmbiCfy6xvAgMTo7aS0kpznQ)
		ys6Eb5QnDX,aaYES459ZRJ7m3 = eecvkLUuf17gMb5w6yaoAsnC(aaYES459ZRJ7m3)
		ZZwEmi19M4OF72xznkUcX,ZuIGmbiCfy6xvAgMTo7aS0kpznQ = eecvkLUuf17gMb5w6yaoAsnC(ZuIGmbiCfy6xvAgMTo7aS0kpznQ)
		ppJnf1qD3j5yBErlGIZeRCU['type'] = uDJvEcha9x4OtnN5e18yKqA3zgmW
		ppJnf1qD3j5yBErlGIZeRCU['context'] = LLjJSPRyT85B9Cq3
		ppJnf1qD3j5yBErlGIZeRCU['group'] = aaYES459ZRJ7m3.upper()
		ppJnf1qD3j5yBErlGIZeRCU['title'] = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.upper()
		ppJnf1qD3j5yBErlGIZeRCU['country'] = ZZwEmi19M4OF72xznkUcX.upper()
		ppJnf1qD3j5yBErlGIZeRCU['language'] = ys6Eb5QnDX.upper()
		PhTJmsMVHGt.append(ppJnf1qD3j5yBErlGIZeRCU)
		juLSnF2ey4Vfx += 1
	return PhTJmsMVHGt,juLSnF2ey4Vfx,A2CHQFM8sgZiSEx
def kcethajG49mLgU2vOHwPo8(ZuIGmbiCfy6xvAgMTo7aS0kpznQ):
	ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.replace('||','|').replace('___',':').replace('--','-')
	ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.replace('[[','[').replace(']]',']')
	ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.replace('((','(').replace('))',')')
	ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.replace('<<','<').replace('>>','>')
	ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	return ZuIGmbiCfy6xvAgMTo7aS0kpznQ
def y1n6QjvUCR(mVL6H0iS7b1v,LLMuqs42Yn9owv713xRODSVzCiyA5m):
	BiAjedXIm6NECtGDqRrkS = {}
	for HHlh0Bi9fG8SnT42KZYRm6gcMj in rLyahNuKk71Y5UWQeXl8mBFqx: BiAjedXIm6NECtGDqRrkS[HHlh0Bi9fG8SnT42KZYRm6gcMj] = []
	J4XmNeTxEGfkB9CqjZr3 = len(mVL6H0iS7b1v)
	WfQlI7gBSJDtnjk9dA = str(J4XmNeTxEGfkB9CqjZr3)
	juLSnF2ey4Vfx = 0
	A2CHQFM8sgZiSEx = []
	for ppJnf1qD3j5yBErlGIZeRCU in mVL6H0iS7b1v:
		if juLSnF2ey4Vfx%873==0:
			TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,50+int(5*juLSnF2ey4Vfx/J4XmNeTxEGfkB9CqjZr3),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(juLSnF2ey4Vfx)+' / '+WfQlI7gBSJDtnjk9dA)
			if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
				LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
				return None,None
		aaYES459ZRJ7m3,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1 = ppJnf1qD3j5yBErlGIZeRCU['group'],ppJnf1qD3j5yBErlGIZeRCU['context'],ppJnf1qD3j5yBErlGIZeRCU['title'],ppJnf1qD3j5yBErlGIZeRCU['url'],ppJnf1qD3j5yBErlGIZeRCU['img']
		ZZwEmi19M4OF72xznkUcX,ys6Eb5QnDX,HHlh0Bi9fG8SnT42KZYRm6gcMj = ppJnf1qD3j5yBErlGIZeRCU['country'],ppJnf1qD3j5yBErlGIZeRCU['language'],ppJnf1qD3j5yBErlGIZeRCU['type']
		IkBXCuOzmHLjFnhiR6PNA270Edy = (aaYES459ZRJ7m3,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1)
		ulEt69DcWgQCUzjkIHTnKZNa52r = False
		if 'LIVE' in HHlh0Bi9fG8SnT42KZYRm6gcMj:
			if 'UNKNOWN' in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['LIVE_UNKNOWN_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			elif 'LIVE' in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['LIVE_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			else: ulEt69DcWgQCUzjkIHTnKZNa52r = True
			BiAjedXIm6NECtGDqRrkS['LIVE_ORIGINAL_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
		elif 'VOD' in HHlh0Bi9fG8SnT42KZYRm6gcMj:
			if 'UNKNOWN' in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['VOD_UNKNOWN_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			elif 'MOVIES' in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['VOD_MOVIES_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			elif 'SERIES' in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['VOD_SERIES_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			else: ulEt69DcWgQCUzjkIHTnKZNa52r = True
			BiAjedXIm6NECtGDqRrkS['VOD_ORIGINAL_GROUPED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
		else: ulEt69DcWgQCUzjkIHTnKZNa52r = True
		if ulEt69DcWgQCUzjkIHTnKZNa52r: A2CHQFM8sgZiSEx.append(ppJnf1qD3j5yBErlGIZeRCU)
		juLSnF2ey4Vfx += 1
	rQ9FwsGupV = sorted(mVL6H0iS7b1v,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l['title'].lower())
	del mVL6H0iS7b1v
	WfQlI7gBSJDtnjk9dA = str(J4XmNeTxEGfkB9CqjZr3)
	juLSnF2ey4Vfx = 0
	for ppJnf1qD3j5yBErlGIZeRCU in rQ9FwsGupV:
		juLSnF2ey4Vfx += 1
		if juLSnF2ey4Vfx%873==0:
			TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,55+int(5*juLSnF2ey4Vfx/J4XmNeTxEGfkB9CqjZr3),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(juLSnF2ey4Vfx)+' / '+WfQlI7gBSJDtnjk9dA)
			if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
				LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
				return None,None
		HHlh0Bi9fG8SnT42KZYRm6gcMj = ppJnf1qD3j5yBErlGIZeRCU['type']
		aaYES459ZRJ7m3,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1 = ppJnf1qD3j5yBErlGIZeRCU['group'],ppJnf1qD3j5yBErlGIZeRCU['context'],ppJnf1qD3j5yBErlGIZeRCU['title'],ppJnf1qD3j5yBErlGIZeRCU['url'],ppJnf1qD3j5yBErlGIZeRCU['img']
		ZZwEmi19M4OF72xznkUcX,ys6Eb5QnDX = ppJnf1qD3j5yBErlGIZeRCU['country'],ppJnf1qD3j5yBErlGIZeRCU['language']
		ywCtamJIvQnAbH0P4kpMYZ2rj5Vg = (aaYES459ZRJ7m3,LLjJSPRyT85B9Cq3+'_TIMESHIFT',ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1)
		IkBXCuOzmHLjFnhiR6PNA270Edy = (aaYES459ZRJ7m3,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1)
		g13TNK0WCeA5ykV2ImMx4zJabwQ6BX = (ZZwEmi19M4OF72xznkUcX,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1)
		ooZezMtb83KAOHuTE0Cm2fdpBxGgsn = (ys6Eb5QnDX,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1)
		if 'LIVE' in HHlh0Bi9fG8SnT42KZYRm6gcMj:
			if 'UNKNOWN' in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['LIVE_UNKNOWN_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			else: BiAjedXIm6NECtGDqRrkS['LIVE_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			if 'EPG'		in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['LIVE_EPG_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			if 'ARCHIVED'	in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['LIVE_ARCHIVED_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			if 'ARCHIVED'	in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['LIVE_TIMESHIFT_GROUPED_SORTED'].append(ywCtamJIvQnAbH0P4kpMYZ2rj5Vg)
			BiAjedXIm6NECtGDqRrkS['LIVE_FROM_NAME_SORTED'].append(g13TNK0WCeA5ykV2ImMx4zJabwQ6BX)
			BiAjedXIm6NECtGDqRrkS['LIVE_FROM_GROUP_SORTED'].append(ooZezMtb83KAOHuTE0Cm2fdpBxGgsn)
		elif 'VOD' in HHlh0Bi9fG8SnT42KZYRm6gcMj:
			if   'UNKNOWN'	in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['VOD_UNKNOWN_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			elif 'MOVIES'	in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['VOD_MOVIES_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			elif 'SERIES'	in HHlh0Bi9fG8SnT42KZYRm6gcMj: BiAjedXIm6NECtGDqRrkS['VOD_SERIES_GROUPED_SORTED'].append(IkBXCuOzmHLjFnhiR6PNA270Edy)
			BiAjedXIm6NECtGDqRrkS['VOD_FROM_NAME_SORTED'].append(g13TNK0WCeA5ykV2ImMx4zJabwQ6BX)
			BiAjedXIm6NECtGDqRrkS['VOD_FROM_GROUP_SORTED'].append(ooZezMtb83KAOHuTE0Cm2fdpBxGgsn)
	return BiAjedXIm6NECtGDqRrkS,A2CHQFM8sgZiSEx
def eecvkLUuf17gMb5w6yaoAsnC(ZuIGmbiCfy6xvAgMTo7aS0kpznQ):
	if len(ZuIGmbiCfy6xvAgMTo7aS0kpznQ)<3: return ZuIGmbiCfy6xvAgMTo7aS0kpznQ,ZuIGmbiCfy6xvAgMTo7aS0kpznQ
	iY2bzBIUQeNgWS9hLdXoKFH7fruR,e2BMKl5Qqp1OsJcRgrF = kh850jKbzmBwY,kh850jKbzmBwY
	L27MDCOqsATfdkxEZNXj96i = ZuIGmbiCfy6xvAgMTo7aS0kpznQ
	aVAZG8tKoi2pjD = ZuIGmbiCfy6xvAgMTo7aS0kpznQ[:1]
	yYpUjOEieIqrxc8tTRkBnaHgWzC = ZuIGmbiCfy6xvAgMTo7aS0kpznQ[1:]
	if   aVAZG8tKoi2pjD=='(': e2BMKl5Qqp1OsJcRgrF = ')'
	elif aVAZG8tKoi2pjD=='[': e2BMKl5Qqp1OsJcRgrF = ']'
	elif aVAZG8tKoi2pjD=='<': e2BMKl5Qqp1OsJcRgrF = '>'
	elif aVAZG8tKoi2pjD=='|': e2BMKl5Qqp1OsJcRgrF = '|'
	if e2BMKl5Qqp1OsJcRgrF and (e2BMKl5Qqp1OsJcRgrF in yYpUjOEieIqrxc8tTRkBnaHgWzC):
		o8qTvbGstWri0,HHeEpOr5m1WbJl6VQYcs4fTiPnS3t = yYpUjOEieIqrxc8tTRkBnaHgWzC.split(e2BMKl5Qqp1OsJcRgrF,1)
		iY2bzBIUQeNgWS9hLdXoKFH7fruR = o8qTvbGstWri0
		L27MDCOqsATfdkxEZNXj96i = aVAZG8tKoi2pjD+o8qTvbGstWri0+e2BMKl5Qqp1OsJcRgrF+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+HHeEpOr5m1WbJl6VQYcs4fTiPnS3t
	elif ZuIGmbiCfy6xvAgMTo7aS0kpznQ.count('|')>=2:
		o8qTvbGstWri0,HHeEpOr5m1WbJl6VQYcs4fTiPnS3t = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.split('|',1)
		iY2bzBIUQeNgWS9hLdXoKFH7fruR = o8qTvbGstWri0
		L27MDCOqsATfdkxEZNXj96i = o8qTvbGstWri0+' |'+HHeEpOr5m1WbJl6VQYcs4fTiPnS3t
	else:
		e2BMKl5Qqp1OsJcRgrF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ZuIGmbiCfy6xvAgMTo7aS0kpznQ,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not e2BMKl5Qqp1OsJcRgrF: e2BMKl5Qqp1OsJcRgrF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ZuIGmbiCfy6xvAgMTo7aS0kpznQ,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not e2BMKl5Qqp1OsJcRgrF: e2BMKl5Qqp1OsJcRgrF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',ZuIGmbiCfy6xvAgMTo7aS0kpznQ,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if e2BMKl5Qqp1OsJcRgrF:
			o8qTvbGstWri0,HHeEpOr5m1WbJl6VQYcs4fTiPnS3t = ZuIGmbiCfy6xvAgMTo7aS0kpznQ.split(e2BMKl5Qqp1OsJcRgrF[0],1)
			iY2bzBIUQeNgWS9hLdXoKFH7fruR = o8qTvbGstWri0
			L27MDCOqsATfdkxEZNXj96i = o8qTvbGstWri0+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+e2BMKl5Qqp1OsJcRgrF[0]+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+HHeEpOr5m1WbJl6VQYcs4fTiPnS3t
	L27MDCOqsATfdkxEZNXj96i = L27MDCOqsATfdkxEZNXj96i.replace(ityRsSDe1ZNqhQ3PLjp74dfEV,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	iY2bzBIUQeNgWS9hLdXoKFH7fruR = iY2bzBIUQeNgWS9hLdXoKFH7fruR.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	if not iY2bzBIUQeNgWS9hLdXoKFH7fruR: iY2bzBIUQeNgWS9hLdXoKFH7fruR = '!!__UNKNOWN__!!'
	iY2bzBIUQeNgWS9hLdXoKFH7fruR = iY2bzBIUQeNgWS9hLdXoKFH7fruR.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	L27MDCOqsATfdkxEZNXj96i = L27MDCOqsATfdkxEZNXj96i.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	return iY2bzBIUQeNgWS9hLdXoKFH7fruR,L27MDCOqsATfdkxEZNXj96i
def C2S0UNM3PlzBIWtgnXHJcyhA5wLvq(MVuQxgTUyK):
	ZZTivR1uy8jFJ7qUa5QNYCtd4 = {}
	HLlO2nw9C4ugGiFr = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.useragent_'+MVuQxgTUyK)
	if HLlO2nw9C4ugGiFr: ZZTivR1uy8jFJ7qUa5QNYCtd4['User-Agent'] = HLlO2nw9C4ugGiFr
	limf2hZrL6tCWQbBM = l7tuXCf0oKV9FPOy6Hb.getSetting('av.iptv.referer_'+MVuQxgTUyK)
	if limf2hZrL6tCWQbBM: ZZTivR1uy8jFJ7qUa5QNYCtd4['Referer'] = limf2hZrL6tCWQbBM
	return ZZTivR1uy8jFJ7qUa5QNYCtd4
def LdkfZTsaI6(MVuQxgTUyK):
	global LLMuqs42Yn9owv713xRODSVzCiyA5m,BiAjedXIm6NECtGDqRrkS,T0suBmKv9GR,jk6u72mHbWUIX1RzKsgZSVAF,ZSQRJ145avLoDGzY,Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y,ynZuIL8MQzD0KavGSc95lx3dOethTV,Jbmlg4OMXBTfUu8sLHoVWt,sAOHPnCbxcJRqkG9M7zyUIDN84et
	X8XrE9dRtVmNLy2BaOgJKwx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,zFRisTInHVNM,PdXj83zlyLfWGowmYTJ7art15,EXd8bTinsxYZG = WgP5ZytDrHKmjhIl6kVGwSz(MVuQxgTUyK)
	if not PdXj83zlyLfWGowmYTJ7art15: return
	ZZTivR1uy8jFJ7qUa5QNYCtd4 = C2S0UNM3PlzBIWtgnXHJcyhA5wLvq(MVuQxgTUyK)
	oPseX03Q2D4gjy7TMHbz = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if oPseX03Q2D4gjy7TMHbz!=1: return
	Dy7z9Yj5gH68LhZ = kjJsP2yEaNpefm5nB4MDA.replace('___','_'+MVuQxgTUyK)
	if 1:
		p0tnXBb1Td2WGVE3A7yZcv,ffvYVrA80Q7wXmxuTsz2RMOnCh,gAu3X4VHJ6DohW09ijBlyYQ7fNtSr = BpzXfU2PtDj5(MVuQxgTUyK,False)
		if not p0tnXBb1Td2WGVE3A7yZcv:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not Se5znCoQLf1J0g2UIA3jixVpBqT9Wd: IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(KXWUabAT1GONjQ6ml2Z3cow7kPz5)+'   No IPTV URL found to download IPTV files')
			else: IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(KXWUabAT1GONjQ6ml2Z3cow7kPz5)+'   Failed to download IPTV files')
			return
		iUL2C1GAdkSgz9Vtursh6ebZ = RQgkpZOda5yorDl(Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,ZZTivR1uy8jFJ7qUa5QNYCtd4,True)
		if not iUL2C1GAdkSgz9Vtursh6ebZ: return
		open(Dy7z9Yj5gH68LhZ,'wb').write(iUL2C1GAdkSgz9Vtursh6ebZ)
	else: iUL2C1GAdkSgz9Vtursh6ebZ = open(Dy7z9Yj5gH68LhZ,'rb').read()
	if eOQJrvLAZC and iUL2C1GAdkSgz9Vtursh6ebZ: iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.decode(NVbhZ0DTpOkCA)
	LLMuqs42Yn9owv713xRODSVzCiyA5m = aaXbN7lmtKqzc2C9JVDi()
	LLMuqs42Yn9owv713xRODSVzCiyA5m.create('جلب ملفات ـIPTV جديدة',kh850jKbzmBwY)
	TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,15,'تنظيف الملف الرئيسي',kh850jKbzmBwY)
	iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace('"tvg-','" tvg-')
	iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace('َ',kh850jKbzmBwY).replace('ً',kh850jKbzmBwY).replace('ُ',kh850jKbzmBwY).replace('ٌ',kh850jKbzmBwY)
	iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace('ّ',kh850jKbzmBwY).replace('ِ',kh850jKbzmBwY).replace('ٍ',kh850jKbzmBwY).replace('ْ',kh850jKbzmBwY)
	iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace('group-title=','group=').replace('tvg-',kh850jKbzmBwY)
	lXVt8ErH5J92coBah1WR3iO4yKwed,X3XGLA4Zkp = [],[]
	TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
		LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
		return
	QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_series_categories'
	qnE2chelYX3w9RAMSb = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',QmRL0swTcY9dXyIgrp82Aa1ekD,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,kh850jKbzmBwY,kh850jKbzmBwY,'IPTV-CREATE_STREAMS-1st')
	wGAgfE7BYlCXex = qnE2chelYX3w9RAMSb.content
	wGAgfE7BYlCXex = Z4CP1xs5w7fi(wGAgfE7BYlCXex)
	rRnAG9YHfeihk8B5EIxJNOl1q = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('category_name":"(.*?)"',wGAgfE7BYlCXex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	del wGAgfE7BYlCXex
	for aaYES459ZRJ7m3 in rRnAG9YHfeihk8B5EIxJNOl1q:
		aaYES459ZRJ7m3 = aaYES459ZRJ7m3.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		if BBJYzRKgHkOqx: aaYES459ZRJ7m3 = aaYES459ZRJ7m3.decode(NVbhZ0DTpOkCA).encode(NVbhZ0DTpOkCA)
		iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace('group="'+aaYES459ZRJ7m3+'"','group="__SERIES__'+aaYES459ZRJ7m3+'"')
	del rRnAG9YHfeihk8B5EIxJNOl1q
	TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
		LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
		return
	QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_vod_categories'
	qnE2chelYX3w9RAMSb = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',QmRL0swTcY9dXyIgrp82Aa1ekD,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,kh850jKbzmBwY,kh850jKbzmBwY,'IPTV-CREATE_STREAMS-2nd')
	wGAgfE7BYlCXex = qnE2chelYX3w9RAMSb.content
	wGAgfE7BYlCXex = Z4CP1xs5w7fi(wGAgfE7BYlCXex)
	x3DcAP7H5aK = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('category_name":"(.*?)"',wGAgfE7BYlCXex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	del wGAgfE7BYlCXex
	for aaYES459ZRJ7m3 in x3DcAP7H5aK:
		aaYES459ZRJ7m3 = aaYES459ZRJ7m3.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		if BBJYzRKgHkOqx: aaYES459ZRJ7m3 = aaYES459ZRJ7m3.decode(NVbhZ0DTpOkCA).encode(NVbhZ0DTpOkCA)
		iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace('group="'+aaYES459ZRJ7m3+'"','group="__MOVIES__'+aaYES459ZRJ7m3+'"')
	del x3DcAP7H5aK
	TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
		LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
		return
	QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_live_streams'
	qnE2chelYX3w9RAMSb = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',QmRL0swTcY9dXyIgrp82Aa1ekD,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,kh850jKbzmBwY,kh850jKbzmBwY,'IPTV-CREATE_STREAMS-3rd')
	wGAgfE7BYlCXex = qnE2chelYX3w9RAMSb.content
	wGAgfE7BYlCXex = Z4CP1xs5w7fi(wGAgfE7BYlCXex)
	Wbx8BE7gaQJrySz = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"name":"(.*?)".*?"tv_archive":(.*?),',wGAgfE7BYlCXex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for ppweOR6rMg,o4lTSIKFhMmXiC10axOGNc3D in Wbx8BE7gaQJrySz:
		if o4lTSIKFhMmXiC10axOGNc3D=='1': lXVt8ErH5J92coBah1WR3iO4yKwed.append(ppweOR6rMg)
	del Wbx8BE7gaQJrySz
	ktm2IQR9dAhM5 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',wGAgfE7BYlCXex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	del wGAgfE7BYlCXex
	for ppweOR6rMg,Y5MQiXGWxgBASZFNnj2fcPvCRhI in ktm2IQR9dAhM5:
		if Y5MQiXGWxgBASZFNnj2fcPvCRhI!='null': X3XGLA4Zkp.append(ppweOR6rMg)
	del ktm2IQR9dAhM5
	iUL2C1GAdkSgz9Vtursh6ebZ = iUL2C1GAdkSgz9Vtursh6ebZ.replace(lpaqU2W5YZ4v6MuVyecsDIEO,URBvawyLXfQiS2NI34HDk)
	XXluaiyqGjfzJnxVtm458bTYRI = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('NF:(.+?)'+'#'+'EXTI',iUL2C1GAdkSgz9Vtursh6ebZ+'\n+'+'#'+'EXTINF:',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not XXluaiyqGjfzJnxVtm458bTYRI:
		IvJhkcEqiMVHr1sAeo(ss12Lxn9zHmkefgR6GDE,KdYh8IpH9bmSxQNDZ1efLGtrkiv(KXWUabAT1GONjQ6ml2Z3cow7kPz5)+'   Folder:'+MVuQxgTUyK+'   No video links found in IPTV file')
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+URBvawyLXfQiS2NI34HDk+RlMpu0hP8YmzZovkVXOs1G+'مجلد رقم '+MVuQxgTUyK)
		LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
		return
	hdNnWePuJ4i2IHfFmtXqKaScvZwOBG = []
	for KXVpQi6eGUdNCO1LumZkRDS3vqWYh in XXluaiyqGjfzJnxVtm458bTYRI:
		pMDe2q1FyxWmdOQNngE6BJcAu5YZ = KXVpQi6eGUdNCO1LumZkRDS3vqWYh.lower()
		if 'adult' in pMDe2q1FyxWmdOQNngE6BJcAu5YZ: continue
		if 'xxx' in pMDe2q1FyxWmdOQNngE6BJcAu5YZ: continue
		hdNnWePuJ4i2IHfFmtXqKaScvZwOBG.append(KXVpQi6eGUdNCO1LumZkRDS3vqWYh)
	XXluaiyqGjfzJnxVtm458bTYRI = hdNnWePuJ4i2IHfFmtXqKaScvZwOBG
	del hdNnWePuJ4i2IHfFmtXqKaScvZwOBG
	XOsco3kdKujLQ8tNgJx = 1024*1024
	Sd73X5ANBECcFJgT = 1+len(iUL2C1GAdkSgz9Vtursh6ebZ)//XOsco3kdKujLQ8tNgJx//10
	del iUL2C1GAdkSgz9Vtursh6ebZ
	bbMIfxq1kU5e = len(XXluaiyqGjfzJnxVtm458bTYRI)
	HMZXCf28pGPgjVeELAFun9 = HuIsVEn7UMJDg(XXluaiyqGjfzJnxVtm458bTYRI,Sd73X5ANBECcFJgT)
	del XXluaiyqGjfzJnxVtm458bTYRI
	for GO7MHm4uakCRsJ8AlcdLr in range(Sd73X5ANBECcFJgT):
		TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,35+int(5*GO7MHm4uakCRsJ8AlcdLr/Sd73X5ANBECcFJgT),'تقطيع الملف الرئيسي','الجزء رقم:-',str(GO7MHm4uakCRsJ8AlcdLr+1)+' / '+str(Sd73X5ANBECcFJgT))
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
			LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
			return
		QQgRqjAiC4EzHfrOyGb2B = str(HMZXCf28pGPgjVeELAFun9[GO7MHm4uakCRsJ8AlcdLr])
		if eOQJrvLAZC: QQgRqjAiC4EzHfrOyGb2B = QQgRqjAiC4EzHfrOyGb2B.encode(NVbhZ0DTpOkCA)
		open(Dy7z9Yj5gH68LhZ+'.00'+str(GO7MHm4uakCRsJ8AlcdLr),'wb').write(QQgRqjAiC4EzHfrOyGb2B)
	del HMZXCf28pGPgjVeELAFun9,QQgRqjAiC4EzHfrOyGb2B
	xI1HWEZ2L9Q4rMCyNeRKSFDhT,mVL6H0iS7b1v,juLSnF2ey4Vfx = [],[],0
	for GO7MHm4uakCRsJ8AlcdLr in range(Sd73X5ANBECcFJgT):
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
			LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
			return
		QQgRqjAiC4EzHfrOyGb2B = open(Dy7z9Yj5gH68LhZ+'.00'+str(GO7MHm4uakCRsJ8AlcdLr),'rb').read()
		pVesmhFG6wgubAODHSKvN1Wx.sleep(1)
		try: YdDkIjFhgzuboBKca70ERt.remove(Dy7z9Yj5gH68LhZ+'.00'+str(GO7MHm4uakCRsJ8AlcdLr))
		except: pass
		if eOQJrvLAZC: QQgRqjAiC4EzHfrOyGb2B = QQgRqjAiC4EzHfrOyGb2B.decode(NVbhZ0DTpOkCA)
		UiYnmorWeKdQNCx0AyXVO = tmYCsS329HanzjLFbJP('list',QQgRqjAiC4EzHfrOyGb2B)
		del QQgRqjAiC4EzHfrOyGb2B
		PhTJmsMVHGt,juLSnF2ey4Vfx,A2CHQFM8sgZiSEx = KbkZgyvXALwuDH7zq1phaS(UiYnmorWeKdQNCx0AyXVO,X3XGLA4Zkp,lXVt8ErH5J92coBah1WR3iO4yKwed,LLMuqs42Yn9owv713xRODSVzCiyA5m,bbMIfxq1kU5e,juLSnF2ey4Vfx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd)
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
			LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
			return
		if not PhTJmsMVHGt:
			LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
			return
		mVL6H0iS7b1v += PhTJmsMVHGt
		xI1HWEZ2L9Q4rMCyNeRKSFDhT += A2CHQFM8sgZiSEx
	del UiYnmorWeKdQNCx0AyXVO,PhTJmsMVHGt
	BiAjedXIm6NECtGDqRrkS,A2CHQFM8sgZiSEx = y1n6QjvUCR(mVL6H0iS7b1v,LLMuqs42Yn9owv713xRODSVzCiyA5m)
	if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
		LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
		return
	xI1HWEZ2L9Q4rMCyNeRKSFDhT += A2CHQFM8sgZiSEx
	del mVL6H0iS7b1v,A2CHQFM8sgZiSEx
	jk6u72mHbWUIX1RzKsgZSVAF,ZSQRJ145avLoDGzY,Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y,ynZuIL8MQzD0KavGSc95lx3dOethTV,Jbmlg4OMXBTfUu8sLHoVWt = {},{},{},0,0
	LLz4yxkoJhqlKVwFruvnaNU8D = list(BiAjedXIm6NECtGDqRrkS.keys())
	sAOHPnCbxcJRqkG9M7zyUIDN84et = len(LLz4yxkoJhqlKVwFruvnaNU8D)*3
	if 1:
		WWRJCdvZh7V8H5 = {}
		for Tn91jD2Ues7RYOdBfwy in LLz4yxkoJhqlKVwFruvnaNU8D:
			WWRJCdvZh7V8H5[Tn91jD2Ues7RYOdBfwy] = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=lCoq8ygnDwPhOMLjHGa4r3,args=(Tn91jD2Ues7RYOdBfwy,))
			WWRJCdvZh7V8H5[Tn91jD2Ues7RYOdBfwy].start()
		for Tn91jD2Ues7RYOdBfwy in LLz4yxkoJhqlKVwFruvnaNU8D:
			WWRJCdvZh7V8H5[Tn91jD2Ues7RYOdBfwy].join()
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
			LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
			return
	else:
		for Tn91jD2Ues7RYOdBfwy in LLz4yxkoJhqlKVwFruvnaNU8D:
			lCoq8ygnDwPhOMLjHGa4r3(Tn91jD2Ues7RYOdBfwy)
			if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
				LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
				return
	uf80nP6wIkzMNEHsLS2WO(MVuQxgTUyK,False)
	LLz4yxkoJhqlKVwFruvnaNU8D = list(jk6u72mHbWUIX1RzKsgZSVAF.keys())
	T0suBmKv9GR = 0
	if 1:
		WWRJCdvZh7V8H5 = {}
		for Tn91jD2Ues7RYOdBfwy in LLz4yxkoJhqlKVwFruvnaNU8D:
			WWRJCdvZh7V8H5[Tn91jD2Ues7RYOdBfwy] = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=zRADOZCYnmatVQo4jq2e8G7TMFs3,args=(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy))
			WWRJCdvZh7V8H5[Tn91jD2Ues7RYOdBfwy].start()
		for Tn91jD2Ues7RYOdBfwy in LLz4yxkoJhqlKVwFruvnaNU8D:
			WWRJCdvZh7V8H5[Tn91jD2Ues7RYOdBfwy].join()
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
			LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
			return
	else:
		for Tn91jD2Ues7RYOdBfwy in LLz4yxkoJhqlKVwFruvnaNU8D:
			zRADOZCYnmatVQo4jq2e8G7TMFs3(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy)
			if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
				LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
				return
	GO7MHm4uakCRsJ8AlcdLr = 0
	WL610dZng9eExQTh = len(xI1HWEZ2L9Q4rMCyNeRKSFDhT)
	SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,'IGNORED')
	for qoaHc25fFPBLtxJN in xI1HWEZ2L9Q4rMCyNeRKSFDhT:
		if GO7MHm4uakCRsJ8AlcdLr%27==0:
			TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,95+int(5*GO7MHm4uakCRsJ8AlcdLr//WL610dZng9eExQTh),'تخزين المهملة','الفيديو رقم:-',str(GO7MHm4uakCRsJ8AlcdLr)+' / '+str(WL610dZng9eExQTh))
			if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled():
				LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
				return
		l0S5ZkdnJ8OaNh6GVoK7m(SX63uY5zewEndZ9frvUV0,'IGNORED',str(qoaHc25fFPBLtxJN),kh850jKbzmBwY,ggbKIPj8XAQhBVyeu1oDO47FNz)
		GO7MHm4uakCRsJ8AlcdLr += 1
	l0S5ZkdnJ8OaNh6GVoK7m(SX63uY5zewEndZ9frvUV0,'IGNORED','__COUNT__',str(WL610dZng9eExQTh),ggbKIPj8XAQhBVyeu1oDO47FNz)
	l0S5ZkdnJ8OaNh6GVoK7m(SX63uY5zewEndZ9frvUV0,'DUMMY','__DUMMY__','1',ggbKIPj8XAQhBVyeu1oDO47FNz)
	LLMuqs42Yn9owv713xRODSVzCiyA5m.close()
	pVesmhFG6wgubAODHSKvN1Wx.sleep(1)
	QvUBKfPtwMIDRa4W5xH = LI1NqPWEQDAFxchiKYreZf5stB(MVuQxgTUyK,False)
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,RlMpu0hP8YmzZovkVXOs1G+'تم جلب ملفات ـIPTV جديدة'+wVvqN8LZCJW5ryAb1EHRPFkQ0+'\n\n'+QvUBKfPtwMIDRa4W5xH)
	Qt2cnJzb9PM4AfjWyZLEIroV7F(MVuQxgTUyK)
	bYyrpulUGfHo(False)
	EoGNACuMnrFUzPyi(False)
	return
def lCoq8ygnDwPhOMLjHGa4r3(Tn91jD2Ues7RYOdBfwy):
	global LLMuqs42Yn9owv713xRODSVzCiyA5m,BiAjedXIm6NECtGDqRrkS,T0suBmKv9GR,jk6u72mHbWUIX1RzKsgZSVAF,ZSQRJ145avLoDGzY,Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y,ynZuIL8MQzD0KavGSc95lx3dOethTV,Jbmlg4OMXBTfUu8sLHoVWt,sAOHPnCbxcJRqkG9M7zyUIDN84et
	jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy] = {}
	n78nc54TpdrbCGSq6AxkFNYWZQ,pplOaJ0P3CzbSNrX = {},[]
	ofjKG2i6a7DrvBLXextskMnzlwuZQ8 = len(BiAjedXIm6NECtGDqRrkS[Tn91jD2Ues7RYOdBfwy])
	jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy]['__COUNT__'] = ofjKG2i6a7DrvBLXextskMnzlwuZQ8
	if ofjKG2i6a7DrvBLXextskMnzlwuZQ8>0:
		GmPCytrL7lYNejgHVca2zOqxbJ,fID3hy0awt5lW7xozCpRFmP,HHQswK8SLexVI5JfZ2WkpEiCN4cg3T,lNbKit6HUM0nRCzmwjdar2PSGXI,rfIkxhnJBi3KsL = zip(*BiAjedXIm6NECtGDqRrkS[Tn91jD2Ues7RYOdBfwy])
		del fID3hy0awt5lW7xozCpRFmP,HHQswK8SLexVI5JfZ2WkpEiCN4cg3T,lNbKit6HUM0nRCzmwjdar2PSGXI
		BkS6TeQqpNVRGKH3Jvm2hU = list(set(GmPCytrL7lYNejgHVca2zOqxbJ))
		for aaYES459ZRJ7m3 in BkS6TeQqpNVRGKH3Jvm2hU:
			n78nc54TpdrbCGSq6AxkFNYWZQ[aaYES459ZRJ7m3] = kh850jKbzmBwY
			jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy][aaYES459ZRJ7m3] = []
		TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,60+int(15*Jbmlg4OMXBTfUu8sLHoVWt//sAOHPnCbxcJRqkG9M7zyUIDN84et),'تصنيع القوائم','الجزء رقم:-',str(Jbmlg4OMXBTfUu8sLHoVWt)+' / '+str(sAOHPnCbxcJRqkG9M7zyUIDN84et))
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled(): return
		Jbmlg4OMXBTfUu8sLHoVWt += 1
		s9s4d6nq2jDoZYfyCB38IROtu = len(BkS6TeQqpNVRGKH3Jvm2hU)
		del BkS6TeQqpNVRGKH3Jvm2hU
		pplOaJ0P3CzbSNrX = list(set(zip(GmPCytrL7lYNejgHVca2zOqxbJ,rfIkxhnJBi3KsL)))
		del GmPCytrL7lYNejgHVca2zOqxbJ,rfIkxhnJBi3KsL
		for aaYES459ZRJ7m3,NZj0IMlhLqu8xPJFsmAdVe in pplOaJ0P3CzbSNrX:
			if not n78nc54TpdrbCGSq6AxkFNYWZQ[aaYES459ZRJ7m3] and NZj0IMlhLqu8xPJFsmAdVe: n78nc54TpdrbCGSq6AxkFNYWZQ[aaYES459ZRJ7m3] = NZj0IMlhLqu8xPJFsmAdVe
		TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,60+int(15*Jbmlg4OMXBTfUu8sLHoVWt//sAOHPnCbxcJRqkG9M7zyUIDN84et),'تصنيع القوائم','الجزء رقم:-',str(Jbmlg4OMXBTfUu8sLHoVWt)+' / '+str(sAOHPnCbxcJRqkG9M7zyUIDN84et))
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled(): return
		Jbmlg4OMXBTfUu8sLHoVWt += 1
		fCzO9gHBPyt0nJLXxmGRbW7dkvlhSD = list(n78nc54TpdrbCGSq6AxkFNYWZQ.keys())
		VViW2nMrglNC04bqtvXDO = list(n78nc54TpdrbCGSq6AxkFNYWZQ.values())
		del n78nc54TpdrbCGSq6AxkFNYWZQ
		pplOaJ0P3CzbSNrX = list(zip(fCzO9gHBPyt0nJLXxmGRbW7dkvlhSD,VViW2nMrglNC04bqtvXDO))
		del fCzO9gHBPyt0nJLXxmGRbW7dkvlhSD,VViW2nMrglNC04bqtvXDO
		pplOaJ0P3CzbSNrX = sorted(pplOaJ0P3CzbSNrX)
	else: Jbmlg4OMXBTfUu8sLHoVWt += 2
	jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy]['__GROUPS__'] = pplOaJ0P3CzbSNrX
	del pplOaJ0P3CzbSNrX
	for aaYES459ZRJ7m3,LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1 in BiAjedXIm6NECtGDqRrkS[Tn91jD2Ues7RYOdBfwy]:
		jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy][aaYES459ZRJ7m3].append((LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1))
	TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,60+int(15*Jbmlg4OMXBTfUu8sLHoVWt//sAOHPnCbxcJRqkG9M7zyUIDN84et),'تصنيع القوائم','الجزء رقم:-',str(Jbmlg4OMXBTfUu8sLHoVWt)+' / '+str(sAOHPnCbxcJRqkG9M7zyUIDN84et))
	if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled(): return
	Jbmlg4OMXBTfUu8sLHoVWt += 1
	del BiAjedXIm6NECtGDqRrkS[Tn91jD2Ues7RYOdBfwy]
	Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y[Tn91jD2Ues7RYOdBfwy] = list(jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy].keys())
	ZSQRJ145avLoDGzY[Tn91jD2Ues7RYOdBfwy] = len(Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y[Tn91jD2Ues7RYOdBfwy])
	ynZuIL8MQzD0KavGSc95lx3dOethTV += ZSQRJ145avLoDGzY[Tn91jD2Ues7RYOdBfwy]
	return
def zRADOZCYnmatVQo4jq2e8G7TMFs3(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy):
	global LLMuqs42Yn9owv713xRODSVzCiyA5m,BiAjedXIm6NECtGDqRrkS,T0suBmKv9GR,jk6u72mHbWUIX1RzKsgZSVAF,ZSQRJ145avLoDGzY,Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y,ynZuIL8MQzD0KavGSc95lx3dOethTV,Jbmlg4OMXBTfUu8sLHoVWt,sAOHPnCbxcJRqkG9M7zyUIDN84et
	SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy)
	for juLSnF2ey4Vfx in range(1+ZSQRJ145avLoDGzY[Tn91jD2Ues7RYOdBfwy]//273):
		whEcYfdUtBuMJmKG0PQNbsjVkx = []
		O3XutarFy9fTdJQWD1V7Pj4 = Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y[Tn91jD2Ues7RYOdBfwy][0:273]
		for aaYES459ZRJ7m3 in O3XutarFy9fTdJQWD1V7Pj4:
			whEcYfdUtBuMJmKG0PQNbsjVkx.append(jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy][aaYES459ZRJ7m3])
		l0S5ZkdnJ8OaNh6GVoK7m(SX63uY5zewEndZ9frvUV0,Tn91jD2Ues7RYOdBfwy,O3XutarFy9fTdJQWD1V7Pj4,whEcYfdUtBuMJmKG0PQNbsjVkx,ggbKIPj8XAQhBVyeu1oDO47FNz,True)
		T0suBmKv9GR += len(O3XutarFy9fTdJQWD1V7Pj4)
		TTXCigp03UrWMSxNql(LLMuqs42Yn9owv713xRODSVzCiyA5m,75+int(20*T0suBmKv9GR//ynZuIL8MQzD0KavGSc95lx3dOethTV),'تخزين القوائم','القائمة رقم:-',str(T0suBmKv9GR)+' / '+str(ynZuIL8MQzD0KavGSc95lx3dOethTV))
		if LLMuqs42Yn9owv713xRODSVzCiyA5m.iscanceled(): return
		del Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y[Tn91jD2Ues7RYOdBfwy][0:273]
	del jk6u72mHbWUIX1RzKsgZSVAF[Tn91jD2Ues7RYOdBfwy],Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y[Tn91jD2Ues7RYOdBfwy],ZSQRJ145avLoDGzY[Tn91jD2Ues7RYOdBfwy]
	return
def LI1NqPWEQDAFxchiKYreZf5stB(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX=True):
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX): return
	EWXFzrkvJwh41jKdYZaNqb9nT8L6 = fWM6PeOrvciG0RQpIKzltojDqaYs
	FGqNIAPlpfc7 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,'LIVE_ORIGINAL_GROUPED')
	QQdxguW9HS60yGJ = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,'VOD_ORIGINAL_GROUPED')
	WL610dZng9eExQTh = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(FGqNIAPlpfc7,'int','IGNORED','__COUNT__')
	wRdyWYF2065eo9vm8C3BNnufS = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(FGqNIAPlpfc7,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	SnqxZ5er8Wf0upv2skUVD = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(QQdxguW9HS60yGJ,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	QfgrdPEkqeRA = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(FGqNIAPlpfc7,'int','LIVE_GROUPED','__COUNT__')
	c9cCEsAZ8MmrOULv5YuH = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(FGqNIAPlpfc7,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	ZMS7DuGR5YKpPXcHzNml = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(FGqNIAPlpfc7,'int','VOD_MOVIES_GROUPED','__COUNT__')
	klZg8qYAG0 = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(QQdxguW9HS60yGJ,'int','VOD_SERIES_GROUPED','__COUNT__')
	G2GcfzRuBS0bdqotEZ6QjNxO = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(FGqNIAPlpfc7,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(QQdxguW9HS60yGJ,'list','VOD_SERIES_GROUPED','__GROUPS__')
	KyTOLZWUBNujdH = []
	for aaYES459ZRJ7m3,JeoM5hbREjnXOD1 in Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y:
		WAQefjDolPpY3NO14yRm7iLvZ2 = aaYES459ZRJ7m3.split('__SERIES__')[1]
		KyTOLZWUBNujdH.append(WAQefjDolPpY3NO14yRm7iLvZ2)
	rJv96pVEZsAI2Lu0GkiWOlSBqMY = len(KyTOLZWUBNujdH)
	YBzevm68pHSuQy = int(ZMS7DuGR5YKpPXcHzNml)+int(klZg8qYAG0)+int(G2GcfzRuBS0bdqotEZ6QjNxO)+int(c9cCEsAZ8MmrOULv5YuH)+int(QfgrdPEkqeRA)
	QvUBKfPtwMIDRa4W5xH = kh850jKbzmBwY
	QvUBKfPtwMIDRa4W5xH += 'قنوات: '+str(QfgrdPEkqeRA)
	QvUBKfPtwMIDRa4W5xH += '   .   أفلام: '+str(ZMS7DuGR5YKpPXcHzNml)
	QvUBKfPtwMIDRa4W5xH += '\nمسلسلات: '+str(rJv96pVEZsAI2Lu0GkiWOlSBqMY)
	QvUBKfPtwMIDRa4W5xH += '   .   حلقات: '+str(klZg8qYAG0)
	QvUBKfPtwMIDRa4W5xH += '\nقنوات مجهولة: '+str(c9cCEsAZ8MmrOULv5YuH)
	QvUBKfPtwMIDRa4W5xH += '   .   فيدوهات مجهولة: '+str(G2GcfzRuBS0bdqotEZ6QjNxO)
	QvUBKfPtwMIDRa4W5xH += '\nمجموع القنوات: '+str(wRdyWYF2065eo9vm8C3BNnufS)
	QvUBKfPtwMIDRa4W5xH += '   .   مجموع الفيديوهات: '+str(SnqxZ5er8Wf0upv2skUVD)
	QvUBKfPtwMIDRa4W5xH += '\n\nمجموع المضافة: '+str(YBzevm68pHSuQy)
	QvUBKfPtwMIDRa4W5xH += '   .   مجموع المهملة: '+str(WL610dZng9eExQTh)
	if nITwbOW29VtLR7BUqYNX: o1OgjEBsS0aKNl6T7LyAXWfmQ('center',kh850jKbzmBwY,EWXFzrkvJwh41jKdYZaNqb9nT8L6,QvUBKfPtwMIDRa4W5xH)
	rrNBwSQ1afgjldIUnvEXRkiPzh0c = QvUBKfPtwMIDRa4W5xH.replace('\n\n',URBvawyLXfQiS2NI34HDk)
	IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,'.\tCounts of IPTV videos   Folder: '+MVuQxgTUyK+URBvawyLXfQiS2NI34HDk+rrNBwSQ1afgjldIUnvEXRkiPzh0c)
	return QvUBKfPtwMIDRa4W5xH
def uf80nP6wIkzMNEHsLS2WO(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX=True):
	if nITwbOW29VtLR7BUqYNX:
		oPseX03Q2D4gjy7TMHbz = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if oPseX03Q2D4gjy7TMHbz!=1: return
		NNHQyis9khj3TprB = kjJsP2yEaNpefm5nB4MDA.replace('___','_'+MVuQxgTUyK)
		try: YdDkIjFhgzuboBKca70ERt.remove(NNHQyis9khj3TprB)
		except: pass
	NNHQyis9khj3TprB = jWdxMcgPk7w4QVpUobD3r.replace('___','_'+MVuQxgTUyK)
	try: YdDkIjFhgzuboBKca70ERt.remove(NNHQyis9khj3TprB)
	except: pass
	NNHQyis9khj3TprB = t98YoUCELeSGOQduDsKcpZy2.replace('___','_'+MVuQxgTUyK)
	try: YdDkIjFhgzuboBKca70ERt.remove(NNHQyis9khj3TprB)
	except: pass
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'SECTIONS_IPTV','SECTIONS_IPTV_'+MVuQxgTUyK)
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	bYyrpulUGfHo(False)
	Qt2cnJzb9PM4AfjWyZLEIroV7F(MVuQxgTUyK)
	if nITwbOW29VtLR7BUqYNX:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم مسح جميع ملفات ـIPTV')
		EoGNACuMnrFUzPyi(False)
	return
def I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK=kh850jKbzmBwY,nITwbOW29VtLR7BUqYNX=True):
	if MVuQxgTUyK:
		SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(str(MVuQxgTUyK),'DUMMY')
		UDcrMhq2jdQwL4P9BoESJVkOIRK1uT = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'str','DUMMY','__DUMMY__')
		if UDcrMhq2jdQwL4P9BoESJVkOIRK1uT: return True
	else:
		MVuQxgTUyK = '1'
		for wwmDeBsdxp in range(1,xXUqn2W1CElKt0+1):
			SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(str(wwmDeBsdxp),'DUMMY')
			UDcrMhq2jdQwL4P9BoESJVkOIRK1uT = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'str','DUMMY','__DUMMY__')
			if UDcrMhq2jdQwL4P9BoESJVkOIRK1uT: return True
	if nITwbOW29VtLR7BUqYNX:
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+HHFAVK8SwRUqBLuTfdeJ9nbD+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+wVvqN8LZCJW5ryAb1EHRPFkQ0)
		EWXFzrkvJwh41jKdYZaNqb9nT8L6 = 'إضافة وتغيير رابط '+XCli7cMH0maTR[1]+' (مجلد '+XCli7cMH0maTR[int(MVuQxgTUyK)]+')'
		oPseX03Q2D4gjy7TMHbz = aa48i0SKpcGbWFBYLtCre(kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,EWXFzrkvJwh41jKdYZaNqb9nT8L6,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if oPseX03Q2D4gjy7TMHbz==1: UVWvGfLoC7jzlOt(MVuQxgTUyK)
	return False
def pDmCduxfSOb9yKGcP(KDXf8TyFk5mUp3WwPEIjnNrvx6gtcB,MVuQxgTUyK=kh850jKbzmBwY,Tn91jD2Ues7RYOdBfwy=kh850jKbzmBwY,I6DiqTSAsagUXbfnG=kh850jKbzmBwY):
	if not I6DiqTSAsagUXbfnG: I6DiqTSAsagUXbfnG = '1'
	othRNaJrlCsOAymp4iQL6HPEVn9gb,uT9JyZBUCVavzKLOgw,nITwbOW29VtLR7BUqYNX = gCI13c7MdXA8(KDXf8TyFk5mUp3WwPEIjnNrvx6gtcB)
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX): return
	if not othRNaJrlCsOAymp4iQL6HPEVn9gb:
		othRNaJrlCsOAymp4iQL6HPEVn9gb = GG5Fs0hvURxyBV8gz()
		if not othRNaJrlCsOAymp4iQL6HPEVn9gb: return
	QQ09DJPvps5HLGFjKd4xCEcABtS = [kh850jKbzmBwY,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Tn91jD2Ues7RYOdBfwy:
		if not nITwbOW29VtLR7BUqYNX:
			if   '_IPTV-LIVE_' in uT9JyZBUCVavzKLOgw: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[1]
			elif '_IPTV-MOVIES' in uT9JyZBUCVavzKLOgw: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[2]
			elif '_IPTV-SERIES' in uT9JyZBUCVavzKLOgw: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[3]
			else: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[0]
		else:
			hzdq1kfcLeTyam = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			gNiJnH3cvG1Dd9t = W6EMASlVYF0gvGmzo('أختر البحث المناسب', hzdq1kfcLeTyam)
			if gNiJnH3cvG1Dd9t==-1: return
			Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[gNiJnH3cvG1Dd9t]
	othRNaJrlCsOAymp4iQL6HPEVn9gb = othRNaJrlCsOAymp4iQL6HPEVn9gb+'_NODIALOGS_'
	if MVuQxgTUyK: Yzhfkmxe1FO3(othRNaJrlCsOAymp4iQL6HPEVn9gb,MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy,I6DiqTSAsagUXbfnG)
	else:
		for MVuQxgTUyK in range(1,xXUqn2W1CElKt0+1):
			Yzhfkmxe1FO3(othRNaJrlCsOAymp4iQL6HPEVn9gb,str(MVuQxgTUyK),Tn91jD2Ues7RYOdBfwy,I6DiqTSAsagUXbfnG)
		Y3Ny5eLHdp.menuItemsLIST[:] = sorted(Y3Ny5eLHdp.menuItemsLIST,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l[1].lower())
	return
def Yzhfkmxe1FO3(KDXf8TyFk5mUp3WwPEIjnNrvx6gtcB,MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy=kh850jKbzmBwY,I6DiqTSAsagUXbfnG=kh850jKbzmBwY):
	if not I6DiqTSAsagUXbfnG: I6DiqTSAsagUXbfnG = '1'
	othRNaJrlCsOAymp4iQL6HPEVn9gb,uT9JyZBUCVavzKLOgw,nITwbOW29VtLR7BUqYNX = gCI13c7MdXA8(KDXf8TyFk5mUp3WwPEIjnNrvx6gtcB)
	if not MVuQxgTUyK: return
	if not I7J9YEW8wxy6uOh35PVQf2G0v(MVuQxgTUyK,nITwbOW29VtLR7BUqYNX): return
	if not othRNaJrlCsOAymp4iQL6HPEVn9gb:
		othRNaJrlCsOAymp4iQL6HPEVn9gb = GG5Fs0hvURxyBV8gz()
		if not othRNaJrlCsOAymp4iQL6HPEVn9gb: return
	QQ09DJPvps5HLGFjKd4xCEcABtS = [kh850jKbzmBwY,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Tn91jD2Ues7RYOdBfwy:
		if not nITwbOW29VtLR7BUqYNX:
			if   '_IPTV-LIVE_' in uT9JyZBUCVavzKLOgw: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[1]
			elif '_IPTV-MOVIES' in uT9JyZBUCVavzKLOgw: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[2]
			elif '_IPTV-SERIES' in uT9JyZBUCVavzKLOgw: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[3]
			else: Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[0]
		else:
			hzdq1kfcLeTyam = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			gNiJnH3cvG1Dd9t = W6EMASlVYF0gvGmzo('أختر البحث المناسب', hzdq1kfcLeTyam)
			if gNiJnH3cvG1Dd9t==-1: return
			Tn91jD2Ues7RYOdBfwy = QQ09DJPvps5HLGFjKd4xCEcABtS[gNiJnH3cvG1Dd9t]
	EXOcK1Ma08wnpVokYW5Sh = othRNaJrlCsOAymp4iQL6HPEVn9gb.lower()
	SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,'SEARCH')
	X0mhvdbn9g61HlGZs = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'list','SEARCH',(Tn91jD2Ues7RYOdBfwy,EXOcK1Ma08wnpVokYW5Sh))
	if not X0mhvdbn9g61HlGZs:
		mOnMFaTfzG5U7QVgJIueqL9Xt,sITB0Fjt3oHCNLa = [],[]
		if not Tn91jD2Ues7RYOdBfwy: SUjKicDhZsGM8X = [1,2,3,4,5]
		else: SUjKicDhZsGM8X = [QQ09DJPvps5HLGFjKd4xCEcABtS.index(Tn91jD2Ues7RYOdBfwy)]
		for GO7MHm4uakCRsJ8AlcdLr in SUjKicDhZsGM8X:
			SX63uY5zewEndZ9frvUV0 = EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,QQ09DJPvps5HLGFjKd4xCEcABtS[GO7MHm4uakCRsJ8AlcdLr])
			if GO7MHm4uakCRsJ8AlcdLr!=3:
				PhTJmsMVHGt = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'dict',QQ09DJPvps5HLGFjKd4xCEcABtS[GO7MHm4uakCRsJ8AlcdLr])
				del PhTJmsMVHGt['__COUNT__']
				del PhTJmsMVHGt['__GROUPS__']
				del PhTJmsMVHGt['__SEQUENCED_COLUMNS__']
				Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y = list(PhTJmsMVHGt.keys())
				for aaYES459ZRJ7m3 in Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y:
					for LLjJSPRyT85B9Cq3,ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1 in PhTJmsMVHGt[aaYES459ZRJ7m3]:
						if EXOcK1Ma08wnpVokYW5Sh in ZuIGmbiCfy6xvAgMTo7aS0kpznQ.lower(): sITB0Fjt3oHCNLa.append((ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1))
					del PhTJmsMVHGt[aaYES459ZRJ7m3]
				del PhTJmsMVHGt
			else: Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(SX63uY5zewEndZ9frvUV0,'list',QQ09DJPvps5HLGFjKd4xCEcABtS[GO7MHm4uakCRsJ8AlcdLr],'__GROUPS__')
			for aaYES459ZRJ7m3 in Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y:
				try: aaYES459ZRJ7m3,JeoM5hbREjnXOD1 = aaYES459ZRJ7m3
				except: JeoM5hbREjnXOD1 = kh850jKbzmBwY
				if EXOcK1Ma08wnpVokYW5Sh in aaYES459ZRJ7m3.lower():
					if GO7MHm4uakCRsJ8AlcdLr!=3: LbcdRQwyJN4YeX78A0jgWvmHo2EB6 = aaYES459ZRJ7m3
					else:
						XMd3tHBNviDr,MdVOUist9wg = aaYES459ZRJ7m3.split('__SERIES__')
						if EXOcK1Ma08wnpVokYW5Sh in XMd3tHBNviDr.lower(): LbcdRQwyJN4YeX78A0jgWvmHo2EB6 = XMd3tHBNviDr
						else: LbcdRQwyJN4YeX78A0jgWvmHo2EB6 = MdVOUist9wg
					mOnMFaTfzG5U7QVgJIueqL9Xt.append((aaYES459ZRJ7m3,LbcdRQwyJN4YeX78A0jgWvmHo2EB6,QQ09DJPvps5HLGFjKd4xCEcABtS[GO7MHm4uakCRsJ8AlcdLr],JeoM5hbREjnXOD1))
			del Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y
		mOnMFaTfzG5U7QVgJIueqL9Xt = set(mOnMFaTfzG5U7QVgJIueqL9Xt)
		sITB0Fjt3oHCNLa = set(sITB0Fjt3oHCNLa)
		mOnMFaTfzG5U7QVgJIueqL9Xt = sorted(mOnMFaTfzG5U7QVgJIueqL9Xt,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l[1])
		sITB0Fjt3oHCNLa = sorted(sITB0Fjt3oHCNLa,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l[0])
		l0S5ZkdnJ8OaNh6GVoK7m(SX63uY5zewEndZ9frvUV0,'SEARCH',(Tn91jD2Ues7RYOdBfwy,EXOcK1Ma08wnpVokYW5Sh),(mOnMFaTfzG5U7QVgJIueqL9Xt,sITB0Fjt3oHCNLa),ggbKIPj8XAQhBVyeu1oDO47FNz)
	else: mOnMFaTfzG5U7QVgJIueqL9Xt,sITB0Fjt3oHCNLa = X0mhvdbn9g61HlGZs
	Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y = len(mOnMFaTfzG5U7QVgJIueqL9Xt)
	CATtmyHxcj8OLiR3fUdgulEzkn = len(sITB0Fjt3oHCNLa)
	AIZOsmw6lin0WxLe4zjp = int(I6DiqTSAsagUXbfnG)
	dCPLkMKRTmh = max(0,(AIZOsmw6lin0WxLe4zjp-1)*100)
	yyBkmbVTjAJO1PdDo = max(0,AIZOsmw6lin0WxLe4zjp*100)
	VCzPvNXlQj = max(0,dCPLkMKRTmh-Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y)
	tpiI9cRD18oeX3MFUWvNSH0CBj = max(0,yyBkmbVTjAJO1PdDo-Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y)
	for aaYES459ZRJ7m3,LbcdRQwyJN4YeX78A0jgWvmHo2EB6,p1GCBvL2o0UkrXl,JeoM5hbREjnXOD1 in mOnMFaTfzG5U7QVgJIueqL9Xt[dCPLkMKRTmh:yyBkmbVTjAJO1PdDo]:
		EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+LbcdRQwyJN4YeX78A0jgWvmHo2EB6,p1GCBvL2o0UkrXl,234,JeoM5hbREjnXOD1,'1',aaYES459ZRJ7m3,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	del mOnMFaTfzG5U7QVgJIueqL9Xt
	for ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,JeoM5hbREjnXOD1 in sITB0Fjt3oHCNLa[VCzPvNXlQj:tpiI9cRD18oeX3MFUWvNSH0CBj]:
		iFPDMd7EGmplIYs0Srok2T = LYSRpzfhE3cGlXW08VK(QmRL0swTcY9dXyIgrp82Aa1ekD)
		uDJvEcha9x4OtnN5e18yKqA3zgmW = 'live'
		if '.mkv' in iFPDMd7EGmplIYs0Srok2T or 'VOD' in Tn91jD2Ues7RYOdBfwy: uDJvEcha9x4OtnN5e18yKqA3zgmW = 'video'
		EE6ysIeB8jKNgCfOkv(uDJvEcha9x4OtnN5e18yKqA3zgmW,sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,235,JeoM5hbREjnXOD1,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	del sITB0Fjt3oHCNLa
	P4gGaQM7VLjzsixrcmuHBb35A1(MVuQxgTUyK,I6DiqTSAsagUXbfnG,Tn91jD2Ues7RYOdBfwy,239,Lmp2huKk5jQzXVxMqgDJ18GriTfR9Y+CATtmyHxcj8OLiR3fUdgulEzkn,othRNaJrlCsOAymp4iQL6HPEVn9gb+'_NODIALOGS_')
	return
def P4gGaQM7VLjzsixrcmuHBb35A1(MVuQxgTUyK,I6DiqTSAsagUXbfnG,Tn91jD2Ues7RYOdBfwy,eYN1APt8aZflKmByj0ioGzn,YBzevm68pHSuQy,fRJYhnSKHsZ7MqFwmiVz):
	if I6DiqTSAsagUXbfnG!='1': EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'صفحة '+str(1),Tn91jD2Ues7RYOdBfwy,eYN1APt8aZflKmByj0ioGzn,kh850jKbzmBwY,str(1),fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	if not YBzevm68pHSuQy: YBzevm68pHSuQy = 0
	yyrA89T6kZf = int(YBzevm68pHSuQy/100)+1
	for AIZOsmw6lin0WxLe4zjp in range(2,yyrA89T6kZf):
		Lost4xdenIgVEX = (AIZOsmw6lin0WxLe4zjp%10==0 or int(I6DiqTSAsagUXbfnG)-4<AIZOsmw6lin0WxLe4zjp<int(I6DiqTSAsagUXbfnG)+4)
		ssnNu2FKaW = (Lost4xdenIgVEX and int(I6DiqTSAsagUXbfnG)-40<AIZOsmw6lin0WxLe4zjp<int(I6DiqTSAsagUXbfnG)+40)
		if str(AIZOsmw6lin0WxLe4zjp)!=I6DiqTSAsagUXbfnG and (AIZOsmw6lin0WxLe4zjp%100==0 or ssnNu2FKaW):
			EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'صفحة '+str(AIZOsmw6lin0WxLe4zjp),Tn91jD2Ues7RYOdBfwy,eYN1APt8aZflKmByj0ioGzn,kh850jKbzmBwY,str(AIZOsmw6lin0WxLe4zjp),fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	if str(yyrA89T6kZf)!=I6DiqTSAsagUXbfnG: EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+'أخر صفحة '+str(yyrA89T6kZf),Tn91jD2Ues7RYOdBfwy,eYN1APt8aZflKmByj0ioGzn,kh850jKbzmBwY,str(yyrA89T6kZf),fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	return
def EH3Ar81B0lh4jzCbdgvxZemcif(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy):
	if 'SERIES' in Tn91jD2Ues7RYOdBfwy or 'VOD_ORIGINAL' in Tn91jD2Ues7RYOdBfwy: SX63uY5zewEndZ9frvUV0 = t98YoUCELeSGOQduDsKcpZy2
	else: SX63uY5zewEndZ9frvUV0 = jWdxMcgPk7w4QVpUobD3r
	SX63uY5zewEndZ9frvUV0 = SX63uY5zewEndZ9frvUV0.replace('___','_'+MVuQxgTUyK)
	return SX63uY5zewEndZ9frvUV0
def yzWgaGAiFK3sC9qQDIeT6Suw1k(MVuQxgTUyK,Tn91jD2Ues7RYOdBfwy,fE0KldMIwQP1UeyT):
	X8XrE9dRtVmNLy2BaOgJKwx,Se5znCoQLf1J0g2UIA3jixVpBqT9Wd,zFRisTInHVNM,PdXj83zlyLfWGowmYTJ7art15,EXd8bTinsxYZG = WgP5ZytDrHKmjhIl6kVGwSz(MVuQxgTUyK)
	if not PdXj83zlyLfWGowmYTJ7art15: return
	ZZTivR1uy8jFJ7qUa5QNYCtd4 = C2S0UNM3PlzBIWtgnXHJcyhA5wLvq(MVuQxgTUyK)
	if   Tn91jD2Ues7RYOdBfwy=='XTREAM_LIVE_GROUPS': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_live_categories'
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_VOD_GROUPS': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_vod_categories'
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_SERIES_GROUPS': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_series_categories'
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_LIVE_ITEMS': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_live_streams&category_id='+fE0KldMIwQP1UeyT
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_VOD_ITEMS': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_vod_streams&category_id='+fE0KldMIwQP1UeyT
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_SERIES_ITEMS': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_series&category_id='+fE0KldMIwQP1UeyT
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_EPISODES': QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx+'&action=get_series_info&series_id='+fE0KldMIwQP1UeyT
	else: return
	qnE2chelYX3w9RAMSb = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',QmRL0swTcY9dXyIgrp82Aa1ekD,kh850jKbzmBwY,ZZTivR1uy8jFJ7qUa5QNYCtd4,kh850jKbzmBwY,kh850jKbzmBwY,'IPTV-XTREAM_MENUS-1st')
	wGAgfE7BYlCXex = qnE2chelYX3w9RAMSb.content
	if BBJYzRKgHkOqx: wGAgfE7BYlCXex = wGAgfE7BYlCXex.decode(NVbhZ0DTpOkCA).encode(NVbhZ0DTpOkCA)
	tzlULc3eGg = tmYCsS329HanzjLFbJP('list',wGAgfE7BYlCXex)
	if 'GROUPS' in Tn91jD2Ues7RYOdBfwy:
		Tn91jD2Ues7RYOdBfwy = Tn91jD2Ues7RYOdBfwy.replace('_GROUPS','_ITEMS')
		tzlULc3eGg = sorted(tzlULc3eGg,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l['category_name'].lower())
		for aaYES459ZRJ7m3 in tzlULc3eGg:
			OesjM2wRTp = aaYES459ZRJ7m3['category_id']
			ZuIGmbiCfy6xvAgMTo7aS0kpznQ = aaYES459ZRJ7m3['category_name']
			EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,Tn91jD2Ues7RYOdBfwy,285,kh850jKbzmBwY,kh850jKbzmBwY,str(OesjM2wRTp),kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_SERIES_ITEMS':
		tzlULc3eGg = sorted(tzlULc3eGg,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l['name'].lower())
		for xeUAJkiPB6aHmWojX7tSQc in tzlULc3eGg:
			ZuIGmbiCfy6xvAgMTo7aS0kpznQ = xeUAJkiPB6aHmWojX7tSQc['name']
			NZj0IMlhLqu8xPJFsmAdVe = xeUAJkiPB6aHmWojX7tSQc['cover']
			OesjM2wRTp = xeUAJkiPB6aHmWojX7tSQc['series_id']
			EE6ysIeB8jKNgCfOkv('folder',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,'XTREAM_EPISODES',285,NZj0IMlhLqu8xPJFsmAdVe,kh850jKbzmBwY,str(OesjM2wRTp),kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	elif Tn91jD2Ues7RYOdBfwy=='XTREAM_EPISODES':
		NZj0IMlhLqu8xPJFsmAdVe = tzlULc3eGg['info']['cover']
		ppweOR6rMg = tzlULc3eGg['info']['name']
		RR65OuFjk21PAMKmLhocC0Ns = tzlULc3eGg['episodes']
		for IvRtTycKu3VxpbZW2ns1jG04BN in RR65OuFjk21PAMKmLhocC0Ns:
			Ek94UvjSKZH6hdL2w301NfOM = RR65OuFjk21PAMKmLhocC0Ns[IvRtTycKu3VxpbZW2ns1jG04BN]
			for v3OojMmb7niIrtEZh9 in Ek94UvjSKZH6hdL2w301NfOM:
				ZuIGmbiCfy6xvAgMTo7aS0kpznQ = v3OojMmb7niIrtEZh9['title']
				JrsAb1XmgGk3BqWOVpI5l = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('\d+.(S\d+E\d+)',ZuIGmbiCfy6xvAgMTo7aS0kpznQ,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if JrsAb1XmgGk3BqWOVpI5l: ZuIGmbiCfy6xvAgMTo7aS0kpznQ = ppweOR6rMg+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+JrsAb1XmgGk3BqWOVpI5l[0]
				OesjM2wRTp = v3OojMmb7niIrtEZh9['id']
				Aqd2rwola9euDkVYz3ptfH = v3OojMmb7niIrtEZh9['container_extension']
				QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx.split('/player_api.php')[0]+'/series/'+PdXj83zlyLfWGowmYTJ7art15+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+EXd8bTinsxYZG+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+str(OesjM2wRTp)+'.'+Aqd2rwola9euDkVYz3ptfH
				EE6ysIeB8jKNgCfOkv('video',sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,235,NZj0IMlhLqu8xPJFsmAdVe,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	elif 'ITEMS' in Tn91jD2Ues7RYOdBfwy:
		uDJvEcha9x4OtnN5e18yKqA3zgmW = 'live' if 'LIVE' in Tn91jD2Ues7RYOdBfwy else 'video'
		tzlULc3eGg = sorted(tzlULc3eGg,reverse=False,key=lambda fOX1xaTVkPrbmWg0l: fOX1xaTVkPrbmWg0l['name'].lower())
		for gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr in tzlULc3eGg:
			ZuIGmbiCfy6xvAgMTo7aS0kpznQ = gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr['name']
			NZj0IMlhLqu8xPJFsmAdVe = gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr['stream_icon']
			OesjM2wRTp = gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr['stream_id']
			try:
				Aqd2rwola9euDkVYz3ptfH = gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr['container_extension']
				if Aqd2rwola9euDkVYz3ptfH: Aqd2rwola9euDkVYz3ptfH = '.'+Aqd2rwola9euDkVYz3ptfH
			except: Aqd2rwola9euDkVYz3ptfH = kh850jKbzmBwY
			if gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr['stream_type']=='live': HHlh0Bi9fG8SnT42KZYRm6gcMj,gPaoibhYX4VLDwClypOK = kh850jKbzmBwY,'live'
			elif gjOE7ARZYdDP3pKhlIqNJ1GsznHXkr['stream_type']=='movie': HHlh0Bi9fG8SnT42KZYRm6gcMj,gPaoibhYX4VLDwClypOK = 'movie/','video'
			QmRL0swTcY9dXyIgrp82Aa1ekD = X8XrE9dRtVmNLy2BaOgJKwx.split('/player_api.php')[0]+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+HHlh0Bi9fG8SnT42KZYRm6gcMj+PdXj83zlyLfWGowmYTJ7art15+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+EXd8bTinsxYZG+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+str(OesjM2wRTp)+Aqd2rwola9euDkVYz3ptfH
			EE6ysIeB8jKNgCfOkv(uDJvEcha9x4OtnN5e18yKqA3zgmW,sglu80vyjMGhdWNi6E4Z5eVAKb+ZuIGmbiCfy6xvAgMTo7aS0kpznQ,QmRL0swTcY9dXyIgrp82Aa1ekD,235,NZj0IMlhLqu8xPJFsmAdVe,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{'folder':MVuQxgTUyK})
	return
def Qt2cnJzb9PM4AfjWyZLEIroV7F(MVuQxgTUyK):
	j5NBXkaslm4tAQ3DOJnpcC = l7tuXCf0oKV9FPOy6Hb.getSetting('av.language.provider')
	Nt2Vd6GWgKmZujfE = l7tuXCf0oKV9FPOy6Hb.getSetting('av.language.code')
	pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'MENUS_CACHE_'+j5NBXkaslm4tAQ3DOJnpcC+'_'+Nt2Vd6GWgKmZujfE,'%_IP'+MVuQxgTUyK+'_%')
	return
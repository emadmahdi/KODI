# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'ALKAWTHAR'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_KWT_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,QPZDaMKgtTUyNjB7EqvOLwph,text):
	if   mode==130: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==131: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==132: PP3FsDicLyWuTR7GV5Ia = Iu8MASzegtVLihCDn76kr3WKx(url)
	elif mode==133: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==134: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==135: PP3FsDicLyWuTR7GV5Ia = r1GaLwhMA3()
	elif mode==139: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text,url)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,139,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-MENU-1st')
	liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('dropdown-menu(.*?)dropdown-toggle',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[1]
	items=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if '/conductor' in Ga8xfYU6ht7cHjzn: continue
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
		if '/category/' in url: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,132)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,131)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المسلسلات',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/543',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الأفلام',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/628',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'برامج الصغار والشباب',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/517',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'ابرز البرامج',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/1763',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المحاضرات',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/943',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'عاشوراء',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/1353',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'البرامج الاجتماعية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/501',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'البرامج الدينية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/509',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'البرامج الوثائقية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/553',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'البرامج السياسية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/545',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'كتب',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/291',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'تعلم الفارسية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/88',132,kh850jKbzmBwY,'1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'أرشيف البرامج',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/category/1279',132,kh850jKbzmBwY,'1')
	return
def bsZhnoqjD3U(url):
	zGvqM86RaCOX0IbsSmpFn = ['/religious','/social','/political','/films','/series']
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-TITLES-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('titlebar(.*?)titlebar',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if any(value in url for value in zGvqM86RaCOX0IbsSmpFn):
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,133,NWqAr40jTLlMBemn3o79y,'1')
	elif '/docs' in url:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for NWqAr40jTLlMBemn3o79y,title,Ga8xfYU6ht7cHjzn in items:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,133,NWqAr40jTLlMBemn3o79y,'1')
	return
def Iu8MASzegtVLihCDn76kr3WKx(url):
	XvPwmy3axVdD6NIKGb4Ak = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-CATEGORIES-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('parentcat(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not liroJ6qCK9k:
		do7Es2fUtFlM8ScLx(url,'1')
		return
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("href='(.*?)'.*?>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,132,kh850jKbzmBwY,'1')
	return
def do7Es2fUtFlM8ScLx(url,QPZDaMKgtTUyNjB7EqvOLwph):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-EPISODES-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('totalpagecount=[\'"](.*?)[\'"]',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items:
		url = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="news-detail-body".*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,134)
		else: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	XIegO2lMxWS8Pp79bYDEAKF = int(items[0])
	name = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('main-title.*?</a> >(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if name: name = name[0].strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	else: name = ppNwDFByU1dZn5ca.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		XvPwmy3axVdD6NIKGb4Ak = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
		if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: O9wzaDlICnq = url
		else: O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/category/' + XvPwmy3axVdD6NIKGb4Ak + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + QPZDaMKgtTUyNjB7EqvOLwph
		kKwr9zX358QO47tbu1UC2 = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-EPISODES-2nd')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('currentpagenumber(.*?)pagination',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for NWqAr40jTLlMBemn3o79y,type,Ga8xfYU6ht7cHjzn,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',kh850jKbzmBwY)
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
			if XvPwmy3axVdD6NIKGb4Ak=='628': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,133,NWqAr40jTLlMBemn3o79y,'1')
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,134,NWqAr40jTLlMBemn3o79y)
	elif '/episode/' in url:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('playlist(.*?)col-md-12',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,134,NWqAr40jTLlMBemn3o79y)
		elif '/category/628' in uP1m46pAK5a3UgdqvBz9rnL:
				title = '_MOD_' + 'ملف التشغيل'
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,134)
		else:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="Categories.*?href=\'(.*?)\'',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			XvPwmy3axVdD6NIKGb4Ak = items[0].split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
			url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/category/' + XvPwmy3axVdD6NIKGb4Ak
			Iu8MASzegtVLihCDn76kr3WKx(url)
			return
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		yz0JuMrlWdISxFaqQ29pZ63iR8om = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in yz0JuMrlWdISxFaqQ29pZ63iR8om:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('&amp;','&')
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,133)
	return
def yv8LezRQifhw1Kx(url):
	if '/news/' in url or '/episode/' in url:
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-PLAY-1st')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("mobilevideopath.*?value='(.*?)'",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if items: url = items[0]
	NRlCaq1ndM(url,vkNGie5mhCqoTFRzPKaML0x6,'video')
	return
def r1GaLwhMA3():
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/live'
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALKAWTHAR-LIVE-1st')
	O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('live-container.*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	O9wzaDlICnq = O9wzaDlICnq[0]
	tqQkcdHYyM3L7h = {'Referer':WLjaXVNk2dnAJzPpy6OlMv4qoi9}
	ItlLDowfSeYWhBAN = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'GET',O9wzaDlICnq,kh850jKbzmBwY,tqQkcdHYyM3L7h,kh850jKbzmBwY,True,'ALKAWTHAR-LIVE-2nd')
	kKwr9zX358QO47tbu1UC2 = ItlLDowfSeYWhBAN.content
	ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('csrf-token" content="(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk = ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk[0]
	KCUDINmFkyb2Ysa4ZPGMzW = hBRWs4K6t1nderkNEQo7bIvCFuZfS(O9wzaDlICnq,'url')
	QQJdiByEeNqLYGs = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("playUrl = '(.*?)'",kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	QQJdiByEeNqLYGs = KCUDINmFkyb2Ysa4ZPGMzW+QQJdiByEeNqLYGs[0]
	fdTMwbGtQo8F2mNJ7rphziseO = {'X-CSRF-TOKEN':ss5QCTmid9V7PhA2Y1Mtr4yKnelIjk}
	EEgPj05Fwz6YU = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'POST',QQJdiByEeNqLYGs,kh850jKbzmBwY,fdTMwbGtQo8F2mNJ7rphziseO,False,True,'ALKAWTHAR-LIVE-3rd')
	OwH6r0uPtRkI5QaJjZf2XpFgBoE = EEgPj05Fwz6YU.content
	DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"(.*?)"',OwH6r0uPtRkI5QaJjZf2XpFgBoE,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9 = DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9[0].replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	NRlCaq1ndM(DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9,vkNGie5mhCqoTFRzPKaML0x6,'live')
	return
def dStQzEeyknDaOs7q(search,url=kh850jKbzmBwY):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if url==kh850jKbzmBwY:
		if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
		if search==kh850jKbzmBwY: return
		search = ioZ083zxYk(search)
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search?q='+search
		do7Es2fUtFlM8ScLx(url,kh850jKbzmBwY)
		return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'ANIMEZID'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_ANZ_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الرئيسية', 'Sign in', 'تسجيل الدخول', 'اشترك الآن', 'عرض الكل']
def Z6V4AKYFUSWMmqBNXJ72p(mode, url, text):
    if mode == 970: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
    elif mode == 971: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url, text)
    elif mode == 972: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
    elif mode == 973: PP3FsDicLyWuTR7GV5Ia = CYnmhWAZaoUXGcVJD67(url)
    elif mode == 974: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
    elif mode == 979: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
    else: PP3FsDicLyWuTR7GV5Ia = False
    return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', WLjaXVNk2dnAJzPpy6OlMv4qoi9, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-MENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'بحث في الموقع', kh850jKbzmBwY, 979, kh850jKbzmBwY, kh850jKbzmBwY, '_REMEMBERRESULTS_')
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    OEVmWsLiSNvybAxc2e9Id8C1jkRXp = []
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"azMainNav"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if '<span>' in title: title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<span>(.*?)</span>', title, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
            if '"' in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^(.*?)"', Ga8xfYU6ht7cHjzn, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
            if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
            if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
            OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
            EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 971)
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pda bdb"><strong>(.*?)<.*?href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    for title, Ga8xfYU6ht7cHjzn in items:
        if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
        if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
        OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
        EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 971)
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('("ba mgb table full".*?)"container-footer"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
            if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
            OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
            if 'vid=' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 972)
            else: EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 971)
    return
def CC6NMTjSO2g(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-SUBMENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if NSUBGjzyZh5xaKL9AJF:
        ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
        ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"presentation"', '</ul>')
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"dropdown-header">(.*?)</li>(.*?)</ul>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if not liroJ6qCK9k: liroJ6qCK9k = [(kh850jKbzmBwY, ZZDUdXR52CMs9K73Ex)]
        EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' فرز أو فلتر أو ترتيب ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
        for JLngAu1qYhtXm0BNr, ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            if JLngAu1qYhtXm0BNr: JLngAu1qYhtXm0BNr = JLngAu1qYhtXm0BNr + ': '
            for Ga8xfYU6ht7cHjzn, title in items:
                title = JLngAu1qYhtXm0BNr + title
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 971)
    oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-category-subcats"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if oQuiJvtTzwPZbXd7sf4HcG9:
        ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if len(items) < 30:
            EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
            for Ga8xfYU6ht7cHjzn, title in items:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 971)
    if not NSUBGjzyZh5xaKL9AJF and not oQuiJvtTzwPZbXd7sf4HcG9: bsZhnoqjD3U(url)
    return
def bsZhnoqjD3U(url, jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
    if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'ajax-search':
        url, search = url.split('?', 1)
        data = 'queryString=' + search
        headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'POST', url, data, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-TITLES-1st')
    else:
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-TITLES-2nd')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    ZZDUdXR52CMs9K73Ex, items = kh850jKbzmBwY, []
    giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url, 'url')
    if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'ajax-search':
        ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
        h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in h729UnyEIjoYSNKcLOvqfV4:
            items.append((kh850jKbzmBwY, Ga8xfYU6ht7cHjzn, title))
    elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'featured':
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-carousel_featured"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'new_episodes':
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'new_movies':
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if len(liroJ6qCK9k) > 1: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[1]
    elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'featured_series':
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    else:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="az-card(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    if ZZDUdXR52CMs9K73Ex and not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="az-card.*?href="(.*?)" aria-label="(.*?)".*?src="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not items: return
    for Ga8xfYU6ht7cHjzn, title, NWqAr40jTLlMBemn3o79y in items:
        if 'vid=' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 972, NWqAr40jTLlMBemn3o79y)
        elif '/series/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 973, NWqAr40jTLlMBemn3o79y)
        else: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 971, NWqAr40jTLlMBemn3o79y)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if Ga8xfYU6ht7cHjzn == '#': continue
            if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
            Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('&amp;', '&')
            title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 971)
    return
def CYnmhWAZaoUXGcVJD67(url):
    o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, url)
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-EPISODES-2nd')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    if '/season/' not in url:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"az-series-seasons(.*?)</section>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"az-card.*?href="(.*?)" aria-label="(.*?)".*?src="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title, vvufbqFnUclCD5MxOz in items:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 973, vvufbqFnUclCD5MxOz)
    else:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"az-series-episodes(.*?)</section>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"az-card.*?href="(.*?)" aria-label="(.*?)".*?src="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title, vvufbqFnUclCD5MxOz in items:
                EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 972, vvufbqFnUclCD5MxOz)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if Ga8xfYU6ht7cHjzn == '#': continue
            if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
            Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('&amp;', '&')
            title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 973)
    return
def yv8LezRQifhw1Kx(url):
    owMxje0p9Ya3CkhJDX, OEVmWsLiSNvybAxc2e9Id8C1jkRXp = [], []
    O9wzaDlICnq = url.replace('watch.php', 'play.php')
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', O9wzaDlICnq, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"Playerholder".*?src="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if Ga8xfYU6ht7cHjzn:
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
        if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
            OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
            fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn, 'name')
            Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + fDKF4iZ5rz7McduTexbA2RpPs + '__embed'
            owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"az-server-list"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-server-url="(.*?)".*?<strong>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
                OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
                fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn, 'name')
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + fDKF4iZ5rz7McduTexbA2RpPs + '__watch'
                owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"az-download-group".*?</i>(.*?)<(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    for sYm5r9QKRfjoytO, ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<strong>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
                OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__download__' + sYm5r9QKRfjoytO
                owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def r13z4tYS5p2fOqAHlVR9PBvFwd(url):
    owMxje0p9Ya3CkhJDX, OEVmWsLiSNvybAxc2e9Id8C1jkRXp = [], []
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    if 'post=' in uP1m46pAK5a3UgdqvBz9rnL:
        Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"video-bibplayer".*?href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
        LsgQIK6E08od3r5 = Ga8xfYU6ht7cHjzn.split('post=')[1]
        LsgQIK6E08od3r5 = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(LsgQIK6E08od3r5)
        if eOQJrvLAZC: LsgQIK6E08od3r5 = LsgQIK6E08od3r5.decode(NVbhZ0DTpOkCA)
        LsgQIK6E08od3r5 = tmYCsS329HanzjLFbJP('dict', LsgQIK6E08od3r5)
        if 'servers' in list(LsgQIK6E08od3r5.keys()):
            Sp6qOyDB0nt5Qo4KwbPfcWYe = LsgQIK6E08od3r5['servers']
            LtaDBqr1oOpP0Yz3g4ci8 = list(Sp6qOyDB0nt5Qo4KwbPfcWYe.keys())
            Sp6qOyDB0nt5Qo4KwbPfcWYe = list(Sp6qOyDB0nt5Qo4KwbPfcWYe.values())
            cbEeOrp1di2TL7GXnguA6f = zip(LtaDBqr1oOpP0Yz3g4ci8, Sp6qOyDB0nt5Qo4KwbPfcWYe)
            for title, Ga8xfYU6ht7cHjzn in cbEeOrp1di2TL7GXnguA6f:
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.strip(' ')
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__watch'
                owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
        if 'download' in str(LsgQIK6E08od3r5.keys()):
            FUC9OmHZqPky0WGAJoX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('download(\d*)', str(LsgQIK6E08od3r5.keys()), sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for sYm5r9QKRfjoytO in FUC9OmHZqPky0WGAJoX:
                TTeSzx4qFC12cK7aLDnrWIPjBs = LsgQIK6E08od3r5['download' + sYm5r9QKRfjoytO]
                if TTeSzx4qFC12cK7aLDnrWIPjBs:
                    LtaDBqr1oOpP0Yz3g4ci8 = list(TTeSzx4qFC12cK7aLDnrWIPjBs.keys())
                    Sp6qOyDB0nt5Qo4KwbPfcWYe = list(TTeSzx4qFC12cK7aLDnrWIPjBs.values())
                    cbEeOrp1di2TL7GXnguA6f = zip(LtaDBqr1oOpP0Yz3g4ci8, Sp6qOyDB0nt5Qo4KwbPfcWYe)
                    for title, Ga8xfYU6ht7cHjzn in cbEeOrp1di2TL7GXnguA6f:
                        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.strip(' ')
                        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__download__' + sYm5r9QKRfjoytO
                        owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    else:
        O9wzaDlICnq = url.replace('watch.php', 'play.php')
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', O9wzaDlICnq, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ANIMEZID-PLAY-2nd')
        uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
        Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"embedURL" href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if 0 and Ga8xfYU6ht7cHjzn:
            Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
            if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
                OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
                fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn, 'name')
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + fDKF4iZ5rz7McduTexbA2RpPs + '__embed'
                owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-servers"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('embed-url="(.*?)".*?<strong>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title in items:
                if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
                    OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
                    fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn, 'name')
                    Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + fDKF4iZ5rz7McduTexbA2RpPs + '__watch'
                    owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
        if 'pm-download' not in uP1m46pAK5a3UgdqvBz9rnL:
            O9wzaDlICnq = url.replace('watch.php', 'downloads.php')
            OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', O9wzaDlICnq, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, False, 'ANIMEZID-PLAY-3rd')
            uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pm-download(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<strong>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title in items:
                if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
                    OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
                    fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn, 'name')
                    Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + fDKF4iZ5rz7McduTexbA2RpPs + '__download'
                    owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def dStQzEeyknDaOs7q(search):
    search, kFdoZmlxSf8shU, showDialogs = gCI13c7MdXA8(search)
    if search == kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
    if search == kh850jKbzmBwY: return
    search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF, '+')
    url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search.php?keywords=' + search
    bsZhnoqjD3U(url, 'search')
    return
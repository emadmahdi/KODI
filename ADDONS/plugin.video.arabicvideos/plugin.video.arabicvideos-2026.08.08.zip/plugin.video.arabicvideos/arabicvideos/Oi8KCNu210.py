# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'ALFATIMI'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_FTM_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
oOlIzQHhvr7MY4tKs8bJDBGEgdkmN = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
qKHiF8yovI9kcNl5es3tWm = ['3030','628']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==60: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==61: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==62: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==63: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==64: PP3FsDicLyWuTR7GV5Ia = XHG6xVUdWgaf3lKc7YMBLbO5(text)
	elif mode==69: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,69,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'ما يتم مشاهدته الان',WLjaXVNk2dnAJzPpy6OlMv4qoi9,64,kh850jKbzmBwY,kh850jKbzmBwY,'recent_viewed_vids')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الاكثر مشاهدة',WLjaXVNk2dnAJzPpy6OlMv4qoi9,64,kh850jKbzmBwY,kh850jKbzmBwY,'most_viewed_vids')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'اضيفت مؤخرا',WLjaXVNk2dnAJzPpy6OlMv4qoi9,64,kh850jKbzmBwY,kh850jKbzmBwY,'recently_added_vids')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'فيديو عشوائي',WLjaXVNk2dnAJzPpy6OlMv4qoi9,64,kh850jKbzmBwY,kh850jKbzmBwY,'random_vids')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'افلام ومسلسلات',WLjaXVNk2dnAJzPpy6OlMv4qoi9,61,kh850jKbzmBwY,kh850jKbzmBwY,'-1')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'البرامج الدينية',WLjaXVNk2dnAJzPpy6OlMv4qoi9,61,kh850jKbzmBwY,kh850jKbzmBwY,'-2')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'English Videos',WLjaXVNk2dnAJzPpy6OlMv4qoi9,61,kh850jKbzmBwY,kh850jKbzmBwY,'-3')
	return kh850jKbzmBwY
def bsZhnoqjD3U(url,XvPwmy3axVdD6NIKGb4Ak):
	s9s4liu1z63XFfGJ8v2YU7 = kh850jKbzmBwY
	if XvPwmy3axVdD6NIKGb4Ak not in ['-1','-2','-3']: s9s4liu1z63XFfGJ8v2YU7 = '?cat='+XvPwmy3axVdD6NIKGb4Ak
	O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/menu_level.php'+s9s4liu1z63XFfGJ8v2YU7
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'ALFATIMI-TITLES-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	F4Pr3bi2yWL7JGA,TCJsHMedRrK8G = False,False
	for Ga8xfYU6ht7cHjzn,title,count in items:
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
		s9s4liu1z63XFfGJ8v2YU7 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('cat=(.*?)&',Ga8xfYU6ht7cHjzn,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
		if XvPwmy3axVdD6NIKGb4Ak==s9s4liu1z63XFfGJ8v2YU7: F4Pr3bi2yWL7JGA = True
		elif F4Pr3bi2yWL7JGA 	or (XvPwmy3axVdD6NIKGb4Ak=='-1' and s9s4liu1z63XFfGJ8v2YU7 in oOlIzQHhvr7MY4tKs8bJDBGEgdkmN)  						or (XvPwmy3axVdD6NIKGb4Ak=='-2' and s9s4liu1z63XFfGJ8v2YU7 not in qKHiF8yovI9kcNl5es3tWm and s9s4liu1z63XFfGJ8v2YU7 not in oOlIzQHhvr7MY4tKs8bJDBGEgdkmN)  						or (XvPwmy3axVdD6NIKGb4Ak=='-3' and s9s4liu1z63XFfGJ8v2YU7 in qKHiF8yovI9kcNl5es3tWm):
							if count=='1': EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,63)
							else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,61,kh850jKbzmBwY,kh850jKbzmBwY,s9s4liu1z63XFfGJ8v2YU7)
							TCJsHMedRrK8G = True
	if not TCJsHMedRrK8G: do7Es2fUtFlM8ScLx(url)
	return
def do7Es2fUtFlM8ScLx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALFATIMI-EPISODES-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination(.*?)id="footer',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	Ga8xfYU6ht7cHjzn = kh850jKbzmBwY
	for NWqAr40jTLlMBemn3o79y,title,Ga8xfYU6ht7cHjzn in items:
		title = title.replace('Add',kh850jKbzmBwY).replace('to Quicklist',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,63,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?)div',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex=liroJ6qCK9k[0]
	ZZDUdXR52CMs9K73Ex=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	items=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	O9wzaDlICnq = url.split('?')[0]
	for Ga8xfYU6ht7cHjzn,r3Q0E1RMsJHBXt6hjYuLoaI in items:
		Ga8xfYU6ht7cHjzn = O9wzaDlICnq + Ga8xfYU6ht7cHjzn
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(r3Q0E1RMsJHBXt6hjYuLoaI)
		title = 'صفحة ' + title
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,62)
	return Ga8xfYU6ht7cHjzn
def yv8LezRQifhw1Kx(url):
	if 'videos.php' in url: url = do7Es2fUtFlM8ScLx(url)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,True,'ALFATIMI-PLAY-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('playlistfile:"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	NRlCaq1ndM(url,vkNGie5mhCqoTFRzPKaML0x6,'video')
	return
def XHG6xVUdWgaf3lKc7YMBLbO5(XvPwmy3axVdD6NIKGb4Ak):
	K83xkHbNteiq7RnvgFSL0foXO92EmW = { 'mode' : XvPwmy3axVdD6NIKGb4Ak }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = KQUd6anP3Rr95(K83xkHbNteiq7RnvgFSL0foXO92EmW)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(qogplQ5vHLYt8Ci1fknObwMThe,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in items:
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,63,NWqAr40jTLlMBemn3o79y)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search_result.php?query=' + BkpEeTDInR6LQFG2m1Ns
	do7Es2fUtFlM8ScLx(url)
	return
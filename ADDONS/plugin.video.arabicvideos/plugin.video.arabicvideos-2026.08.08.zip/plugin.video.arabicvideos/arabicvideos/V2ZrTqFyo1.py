# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠬࡘࡁࡏࡆࡒࡑࡘ᳗࠭")
GalrcVUMy8bzORWX5E0exhYivBwgk = HfuZG0aphlYnVLOyAk93rj(u"࠭࡟ࡍࡕࡗࡣ᳘ࠬ")
GwgEhH98FjfJks = HHQhABuNKV7cd
XclTGI5K8bzvgyEtHhPQY6DwRaN = dQvxmFkyLOteNMWBJ2bDHV(u"࠳࠳ὃ")
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn,url,fRJYhnSKHsZ7MqFwmiVz,QPZDaMKgtTUyNjB7EqvOLwph,SMT9JWapBjDXNCFLlixwo7b36g8uA):
	try: Sun57X6YaOzP8NTpcBvUH3k = str(SMT9JWapBjDXNCFLlixwo7b36g8uA[CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࡧࡱ࡯ࡨࡪࡸ᳙ࠧ")])
	except: Sun57X6YaOzP8NTpcBvUH3k = kh850jKbzmBwY
	if   eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠴࠺࠵ὄ"): PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif eYN1APt8aZflKmByj0ioGzn==ZeV4vau9CjN(u"࠵࠻࠷ὅ"): PP3FsDicLyWuTR7GV5Ia = u0e95cZOkv4CYRN1snL37JpEPTj(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠼࠲὆"): PP3FsDicLyWuTR7GV5Ia = vmY7GIyLVJ6(fRJYhnSKHsZ7MqFwmiVz,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠶࠼࠲὆"))
	elif eYN1APt8aZflKmByj0ioGzn==Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠷࠶࠴὇"): PP3FsDicLyWuTR7GV5Ia = vmY7GIyLVJ6(fRJYhnSKHsZ7MqFwmiVz,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠷࠶࠴὇"))
	elif eYN1APt8aZflKmByj0ioGzn==Urj6egiVyHA75ZK(u"࠱࠷࠶Ὀ"): PP3FsDicLyWuTR7GV5Ia = d3GSvVOrUP4(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==YoMw2J1Ljp(u"࠲࠸࠸Ὁ"): PP3FsDicLyWuTR7GV5Ia = fgEQhqvlWG9sV7(url,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==u8iSx05wLfVyMNp1X3l(u"࠳࠹࠺Ὂ"): PP3FsDicLyWuTR7GV5Ia = j4JHxalrRMOfh(url,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==dQvxmFkyLOteNMWBJ2bDHV(u"࠴࠺࠼Ὃ"): PP3FsDicLyWuTR7GV5Ia = RRxjByl3UDQte4w0FXcaKG(url,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==YoMw2J1Ljp(u"࠵࠻࠾Ὄ"): PP3FsDicLyWuTR7GV5Ia = SSgh9L8GZjdNbRVaIFJQP(url,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==wb1nC3e8AjRVU4ovsuPa(u"࠼࠼࠱Ὅ"): PP3FsDicLyWuTR7GV5Ia = x7QMKZhrv1TELY()
	elif eYN1APt8aZflKmByj0ioGzn==G6GUCto502jZTLubYNnqMx8ywBah(u"࠽࠶࠳὎"): PP3FsDicLyWuTR7GV5Ia = TAXl03FSVK()
	elif eYN1APt8aZflKmByj0ioGzn==FkqI4Gm8wMvUVbgo(u"࠷࠷࠵὏"): PP3FsDicLyWuTR7GV5Ia = WMq4L5EvahslDK20fNAb6B(Sun57X6YaOzP8NTpcBvUH3k,fRJYhnSKHsZ7MqFwmiVz,QPZDaMKgtTUyNjB7EqvOLwph)
	elif eYN1APt8aZflKmByj0ioGzn==G6GUCto502jZTLubYNnqMx8ywBah(u"࠸࠸࠷ὐ"): PP3FsDicLyWuTR7GV5Ia = Wx8EH4gNsVSklQPIuLfYnRb73dyo(Sun57X6YaOzP8NTpcBvUH3k,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==HfuZG0aphlYnVLOyAk93rj(u"࠹࠹࠹ὑ"): PP3FsDicLyWuTR7GV5Ia = Lb5V1Yi93hIcqZPFgQaKpe6kfm(Sun57X6YaOzP8NTpcBvUH3k,fRJYhnSKHsZ7MqFwmiVz)
	else: PP3FsDicLyWuTR7GV5Ia = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv(wb1nC3e8AjRVU4ovsuPa(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳚"),FkqI4Gm8wMvUVbgo(u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪ᳛"),kh850jKbzmBwY,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠴࠺࠶ὒ"),kh850jKbzmBwY,kh850jKbzmBwY,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠ᳜ࠩ"))
	EE6ysIeB8jKNgCfOkv(Urj6egiVyHA75ZK(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),J6G8X3gO1MiKh027D(u"่ࠬำๆࠢ฼ุํอฦ๋᳞ࠩ"),kh850jKbzmBwY,J6G8X3gO1MiKh027D(u"࠵࠻࠸ὓ"),kh850jKbzmBwY,kh850jKbzmBwY,wb1nC3e8AjRVU4ovsuPa(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳟ࠪ"))
	EE6ysIeB8jKNgCfOkv(FkqI4Gm8wMvUVbgo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳠"),J6G8X3gO1MiKh027D(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ᳡"),kh850jKbzmBwY,J6G8X3gO1MiKh027D(u"࠶࠼࠳ὔ"),kh850jKbzmBwY,kh850jKbzmBwY,FkqI4Gm8wMvUVbgo(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳢ࠧ"))
	EE6ysIeB8jKNgCfOkv(BBOY8rvinVbFh(u"ࠪࡪࡴࡲࡤࡦࡴ᳣ࠪ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์᳤ࠪ"),kh850jKbzmBwY,u8iSx05wLfVyMNp1X3l(u"࠷࠶࠵ὕ"),kh850jKbzmBwY,kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳥ࠪ"))
	EE6ysIeB8jKNgCfOkv(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ࡦࡰ࡮ࡧࡩࡷ᳦࠭"),WlU7AtONpyj3(u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็᳧ࠪ"),kh850jKbzmBwY,J6G8X3gO1MiKh027D(u"࠷࠷࠵ὖ"),kh850jKbzmBwY,kh850jKbzmBwY,sdRqnego9PclrL4m2J(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡ᳨ࠪ"))
	EE6ysIeB8jKNgCfOkv(FkqI4Gm8wMvUVbgo(u"ࠩ࡯࡭ࡳࡱࠧᳩ"),HHFAVK8SwRUqBLuTfdeJ9nbD+Urj6egiVyHA75ZK(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᳪ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠺࠻࠼࠽ὗ"))
	EE6ysIeB8jKNgCfOkv(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᳫ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"่ࠬๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩᳬ"),kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠳࠹࠷὘"),kh850jKbzmBwY,kh850jKbzmBwY,HfuZG0aphlYnVLOyAk93rj(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳭"))
	EE6ysIeB8jKNgCfOkv(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳮ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨᳯ"),kh850jKbzmBwY,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠴࠺࠸Ὑ"),kh850jKbzmBwY,kh850jKbzmBwY,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᳰ"))
	EE6ysIeB8jKNgCfOkv(u8iSx05wLfVyMNp1X3l(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),sdRqnego9PclrL4m2J(u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫᳲ"),kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠵࠻࠸὚"),kh850jKbzmBwY,kh850jKbzmBwY,XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᳳ"))
	EE6ysIeB8jKNgCfOkv(taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳴"),tzEjvOaZWU1A(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧᳵ"),kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠶࠼࠲Ὓ"),kh850jKbzmBwY,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᳶ"))
	EE6ysIeB8jKNgCfOkv(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳷"),Urj6egiVyHA75ZK(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭᳸"),kh850jKbzmBwY,YoMw2J1Ljp(u"࠷࠶࠵὜"),kh850jKbzmBwY,kh850jKbzmBwY,ZeV4vau9CjN(u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳹"))
	EE6ysIeB8jKNgCfOkv(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳺ"),J6G8X3gO1MiKh027D(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᳻"),kh850jKbzmBwY,dQvxmFkyLOteNMWBJ2bDHV(u"࠷࠷࠷Ὕ"),kh850jKbzmBwY,kh850jKbzmBwY,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳼"))
	EE6ysIeB8jKNgCfOkv(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࡮࡬ࡲࡰ࠭᳽"),HHFAVK8SwRUqBLuTfdeJ9nbD+WlU7AtONpyj3(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨ᳾")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,YoMw2J1Ljp(u"࠺࠻࠼࠽὞"))
	EE6ysIeB8jKNgCfOkv(YoMw2J1Ljp(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳿"),wb1nC3e8AjRVU4ovsuPa(u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩᴀ"),kh850jKbzmBwY,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠳࠹࠷Ὗ"),kh850jKbzmBwY,kh850jKbzmBwY,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴁ"))
	EE6ysIeB8jKNgCfOkv(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᴂ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨᴃ"),kh850jKbzmBwY,gNPRXprEAQJ(u"࠴࠺࠸ὠ"),kh850jKbzmBwY,kh850jKbzmBwY,BBOY8rvinVbFh(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴄ"))
	EE6ysIeB8jKNgCfOkv(gNPRXprEAQJ(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴅ"),BBOY8rvinVbFh(u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫᴆ"),kh850jKbzmBwY,HfuZG0aphlYnVLOyAk93rj(u"࠵࠻࠸ὡ"),kh850jKbzmBwY,kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᴇ"))
	EE6ysIeB8jKNgCfOkv(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴈ"),CMUXq6mPQV5rLsSBdWZJvA(u"࠭โิ็ࠣๅ๏ี๊้ࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧᴉ"),kh850jKbzmBwY,Urj6egiVyHA75ZK(u"࠶࠼࠲ὢ"),kh850jKbzmBwY,kh850jKbzmBwY,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴊ"))
	EE6ysIeB8jKNgCfOkv(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴋ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢหัะูࠦี๊สส๏࠭ᴌ"),kh850jKbzmBwY,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠷࠶࠵ὣ"),kh850jKbzmBwY,kh850jKbzmBwY,YoMw2J1Ljp(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴍ"))
	EE6ysIeB8jKNgCfOkv(gNPRXprEAQJ(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴎ"),ZeV4vau9CjN(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭ᴏ"),kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠷࠷࠶ὤ"),kh850jKbzmBwY,kh850jKbzmBwY,wb1nC3e8AjRVU4ovsuPa(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴐ"))
	return
def x7QMKZhrv1TELY():
	EE6ysIeB8jKNgCfOkv(BBOY8rvinVbFh(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴑ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡡࡌࡔ࡙ࡥࠧᴒ")+MBS1GrwQoUlsiIRfVDOHdA(u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜ࠧᴓ"),kh850jKbzmBwY,u8iSx05wLfVyMNp1X3l(u"࠸࠸࠷ὥ"))
	EE6ysIeB8jKNgCfOkv(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪࡰ࡮ࡴ࡫ࠨᴔ"),HHFAVK8SwRUqBLuTfdeJ9nbD+z8wTfYPiRQL(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᴕ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,gNPRXprEAQJ(u"࠻࠼࠽࠾ὦ"))
	for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
		GalrcVUMy8bzORWX5E0exhYivBwgk = sdRqnego9PclrL4m2J(u"ࠬࡥࡉࡑࠩᴖ")+str(Sun57X6YaOzP8NTpcBvUH3k)+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭࡟ࠨᴗ")
		EE6ysIeB8jKNgCfOkv(HfuZG0aphlYnVLOyAk93rj(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴘ"),GalrcVUMy8bzORWX5E0exhYivBwgk+wb1nC3e8AjRVU4ovsuPa(u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪᴙ")+XCli7cMH0maTR[Sun57X6YaOzP8NTpcBvUH3k],kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠺࠺࠹ὧ"),kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{sdRqnego9PclrL4m2J(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴚ"):Sun57X6YaOzP8NTpcBvUH3k})
	return
def TAXl03FSVK():
	EE6ysIeB8jKNgCfOkv(dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴛ"),gNPRXprEAQJ(u"ࠫࡤࡓ࠳ࡖࡡࠪᴜ")+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖࠩᴝ"),kh850jKbzmBwY,gNPRXprEAQJ(u"࠻࠻࠻Ὠ"))
	EE6ysIeB8jKNgCfOkv(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠭࡬ࡪࡰ࡮ࠫᴞ"),HHFAVK8SwRUqBLuTfdeJ9nbD+gNPRXprEAQJ(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᴟ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,dQvxmFkyLOteNMWBJ2bDHV(u"࠾࠿࠹࠺Ὡ"))
	for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
		GalrcVUMy8bzORWX5E0exhYivBwgk = sdRqnego9PclrL4m2J(u"ࠨࡡࡐ࡙ࠬᴠ")+str(Sun57X6YaOzP8NTpcBvUH3k)+CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࡢࠫᴡ")
		EE6ysIeB8jKNgCfOkv(Urj6egiVyHA75ZK(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴢ"),GalrcVUMy8bzORWX5E0exhYivBwgk+HHthiRYs8T6IO3qUyX(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭ᴣ")+XCli7cMH0maTR[Sun57X6YaOzP8NTpcBvUH3k],kh850jKbzmBwY,z8wTfYPiRQL(u"࠽࠶࠶Ὢ"),kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,{Urj6egiVyHA75ZK(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴤ"):Sun57X6YaOzP8NTpcBvUH3k})
	return
def qIY0bf9ELZi(CYil97XWVj4Z3SRKMUf8DGQeLa):
	global VdZ2GnPEoRkJzqp6ceS,RTYOBpNxgrD
	p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
	try:
		if HHthiRYs8T6IO3qUyX(u"࠭ࡉࡇࡋࡏࡑࠬᴥ") in CYil97XWVj4Z3SRKMUf8DGQeLa: p0gCAJBwG1(CYil97XWVj4Z3SRKMUf8DGQeLa)
		else: p0gCAJBwG1()
		r4rIFWpixAJ7oL0Rljg1quwQym = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	except:
		aaQOmgxv8XZT3C6zk()
		r4rIFWpixAJ7oL0Rljg1quwQym = dbo4vrnTM56I
	CYil97XWVj4Z3SRKMUf8DGQeLa = Hczgh3TNkKXoq4AZ1wJiC(CYil97XWVj4Z3SRKMUf8DGQeLa)
	if r4rIFWpixAJ7oL0Rljg1quwQym:
		o4n5ehzyjHTWdL8(CYil97XWVj4Z3SRKMUf8DGQeLa,ZeV4vau9CjN(u"ࠧโึ็ࠤ้๊ริใࠪᴦ"),pVesmhFG6wgubAODHSKvN1Wx=ZeV4vau9CjN(u"࠲࠱࠲࠳Ὣ"))
		VdZ2GnPEoRkJzqp6ceS += igM4DhpPzoX95Ysnar6Auj
		RTYOBpNxgrD += CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࠢ࠱ࠤࠬᴧ")+CYil97XWVj4Z3SRKMUf8DGQeLa
	else: o4n5ehzyjHTWdL8(CYil97XWVj4Z3SRKMUf8DGQeLa,kh850jKbzmBwY,pVesmhFG6wgubAODHSKvN1Wx=x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠲࠲࠳࠴Ὤ"))
	return
mBRihGyOYN5AT2XgZU6a3M7 = {}
def oFc6e7H5ywPQqxEDjA1zGR(KCcPWJO8FiSMwjoB7k=dbo4vrnTM56I):
	global VdZ2GnPEoRkJzqp6ceS,RTYOBpNxgrD,mBRihGyOYN5AT2XgZU6a3M7
	if not KCcPWJO8FiSMwjoB7k:
		mBRihGyOYN5AT2XgZU6a3M7 = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,ZeV4vau9CjN(u"ࠩࡧ࡭ࡨࡺࠧᴨ"),YoMw2J1Ljp(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫᴩ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩᴪ"))
		if mBRihGyOYN5AT2XgZU6a3M7: return
	II7ErX2ocuU = aa48i0SKpcGbWFBYLtCre(BBOY8rvinVbFh(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᴫ"),kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭อห๋ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮࠯ࠢึ๎ๆำีࠡษ็ฬึ์วๆฮࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤาะ้ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴࠮้ࠡำ๋ࠥอไฺ็็๎ฮࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤࡡࡴ࡜࡯ࠩᴬ")+HHFAVK8SwRUqBLuTfdeJ9nbD+wnVICNyfE3XZ0htUaDFAOgLo(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯาๅฺࠢๅหห๋ษࠡษ็ว็ูวๆࠢส่ว์ࠠภࠩᴭ")+wVvqN8LZCJW5ryAb1EHRPFkQ0)
	if II7ErX2ocuU!=igM4DhpPzoX95Ysnar6Auj: return
	JabU23pYu7zWD8(SmThPgBVzt8,SmThPgBVzt8,SmThPgBVzt8)
	O5Utev2cB1EjPboHNKY4MAhlx0RnJ = Y3Ny5eLHdp.menuItemsLIST
	VdZ2GnPEoRkJzqp6ceS,RTYOBpNxgrD,VVSkpRvEu4sdIQq5oXhZYHT = nxUveizbLEAT2FBNy3,kh850jKbzmBwY,{}
	for CYil97XWVj4Z3SRKMUf8DGQeLa in dpTy2xekflusq8gFLE3CU:
		pVesmhFG6wgubAODHSKvN1Wx.sleep(igM4DhpPzoX95Ysnar6Auj)
		VVSkpRvEu4sdIQq5oXhZYHT[CYil97XWVj4Z3SRKMUf8DGQeLa] = mvKTPeMQOyDJ(daemon=dbo4vrnTM56I,target=qIY0bf9ELZi,args=(CYil97XWVj4Z3SRKMUf8DGQeLa,))
		VVSkpRvEu4sdIQq5oXhZYHT[CYil97XWVj4Z3SRKMUf8DGQeLa].start()
	else:
		for CYil97XWVj4Z3SRKMUf8DGQeLa in list(VVSkpRvEu4sdIQq5oXhZYHT.keys()): VVSkpRvEu4sdIQq5oXhZYHT[CYil97XWVj4Z3SRKMUf8DGQeLa].join()
	Y3Ny5eLHdp.menuItemsLIST[:] = O5Utev2cB1EjPboHNKY4MAhlx0RnJ
	mBRihGyOYN5AT2XgZU6a3M7 = {}
	for CYil97XWVj4Z3SRKMUf8DGQeLa in list(VVSkpRvEu4sdIQq5oXhZYHT.keys()):
		try: TPwRDQjZfpy24M6BY5GxWq9JU7ot8h = Y3Ny5eLHdp.menuItemsDICT[CYil97XWVj4Z3SRKMUf8DGQeLa]
		except: continue
		CYil97XWVj4Z3SRKMUf8DGQeLa = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡡࡏࡗ࡙ࡥࠧᴮ")+Hczgh3TNkKXoq4AZ1wJiC(CYil97XWVj4Z3SRKMUf8DGQeLa)
		for uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 in TPwRDQjZfpy24M6BY5GxWq9JU7ot8h:
			if not ppweOR6rMg: ppweOR6rMg = HfuZG0aphlYnVLOyAk93rj(u"ࠩ࠱࠲࠳࠴ࠧᴯ")
			else:
				if ppweOR6rMg.count(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࡣࠬᴰ"))>igM4DhpPzoX95Ysnar6Auj: ppweOR6rMg = ppweOR6rMg.split(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫࡤ࠭ᴱ"),s0sB2Xyp9uYU5N3fxzKoLW8)[s0sB2Xyp9uYU5N3fxzKoLW8]
				ppweOR6rMg = ppweOR6rMg.replace(sdRqnego9PclrL4m2J(u"ࠬࢦࠧᴲ"),kh850jKbzmBwY).replace(dQvxmFkyLOteNMWBJ2bDHV(u"࠭ࠠࡉࡆࠪᴳ"),kh850jKbzmBwY).replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡉࡆࠣࠫᴴ"),kh850jKbzmBwY)
				ppweOR6rMg = ppweOR6rMg.replace(sdRqnego9PclrL4m2J(u"ࠨโࠪᴵ"),kh850jKbzmBwY).replace(gNPRXprEAQJ(u"ࠩฬࠫᴶ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"๋ࠪࠬᴷ")).replace(z8wTfYPiRQL(u"ࠫษ࠭ᴸ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠬ๎ࠧᴹ"))
				ppweOR6rMg = ppweOR6rMg.replace(u8iSx05wLfVyMNp1X3l(u"࠭รࠨᴺ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧศࠩᴻ")).replace(dQvxmFkyLOteNMWBJ2bDHV(u"ࠨวࠪᴼ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩสࠫᴽ")).replace(HHthiRYs8T6IO3qUyX(u"ࠪฦࠬᴾ"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠫฬ࠭ᴿ"))
				ppweOR6rMg = ppweOR6rMg.replace(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"๊ࠬรࠨᵀ"),dQvxmFkyLOteNMWBJ2bDHV(u"࠭ไศࠩᵁ")).replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧๅวࠪᵂ"),sdRqnego9PclrL4m2J(u"ࠨๆสࠫᵃ")).replace(ZeV4vau9CjN(u"ࠩ็ฦࠬᵄ"),sdRqnego9PclrL4m2J(u"่ࠪฬ࠭ᵅ"))
				ppweOR6rMg = ppweOR6rMg.replace(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫ๓࠭ᵆ"),kh850jKbzmBwY).replace(MBS1GrwQoUlsiIRfVDOHdA(u"ࠬ๑ࠧᵇ"),kh850jKbzmBwY).replace(FkqI4Gm8wMvUVbgo(u"࠭๏ࠨᵈ"),kh850jKbzmBwY).replace(tzEjvOaZWU1A(u"ࠧํࠩᵉ"),kh850jKbzmBwY)
				ppweOR6rMg = ppweOR6rMg.replace(CMUXq6mPQV5rLsSBdWZJvA(u"ࠨ๒ࠪᵊ"),kh850jKbzmBwY).replace(dQvxmFkyLOteNMWBJ2bDHV(u"ࠩ๐ࠫᵋ"),kh850jKbzmBwY).replace(J6G8X3gO1MiKh027D(u"ࠪ๖ࠬᵌ"),kh850jKbzmBwY).replace(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫ๖࠭ᵍ"),kh850jKbzmBwY)
				ppweOR6rMg = ppweOR6rMg.replace(J6G8X3gO1MiKh027D(u"ࠬࢂࠧᵎ"),kh850jKbzmBwY).replace(BBOY8rvinVbFh(u"࠭ࡾࠨᵏ"),kh850jKbzmBwY)
				ppweOR6rMg = ppweOR6rMg.replace(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧศ๊้ࠤ้อ๊็ࠩᵐ"),kh850jKbzmBwY).replace(tzEjvOaZWU1A(u"ࠨีํ้ฬࠦไศ์อࠫᵑ"),kh850jKbzmBwY)
				v8PwO54WsIJpUgTF6Kb90DERk1Yl = [wb1nC3e8AjRVU4ovsuPa(u"ࠩส่฾อศࠨᵒ"),ZeV4vau9CjN(u"ࠪา๏อไࠨᵓ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫฬ๊ศ้็ࠪᵔ"),YoMw2J1Ljp(u"ࠬอไศ่ࠪᵕ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭วุใส่ࠬᵖ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧฮษ็๎์࠭ᵗ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨษ็฾ฬุࠧᵘ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ุࠩห้ำࠧᵙ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪห้ี๊็ࠩᵚ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"๊ࠫ๎วๅ์าࠫᵛ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬอไฺษ็้ࠬᵜ"),u8iSx05wLfVyMNp1X3l(u"࠭วฺ็ส่ࠬᵝ")]
				if not any(IiYrTdMHyaRXEAsz5Q7 in ppweOR6rMg for IiYrTdMHyaRXEAsz5Q7 in v8PwO54WsIJpUgTF6Kb90DERk1Yl): ppweOR6rMg = ppweOR6rMg.replace(HfuZG0aphlYnVLOyAk93rj(u"ࠧศๆࠪᵞ"),kh850jKbzmBwY)
				ppweOR6rMg = ppweOR6rMg.replace(HfuZG0aphlYnVLOyAk93rj(u"ࠨษัี๏࠭ᵟ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩสาึ๏ࠧᵠ")).replace(dQvxmFkyLOteNMWBJ2bDHV(u"ࠪหั์ศ๊ࠩᵡ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫฬาๆษ์ࠪᵢ")).replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬ฿ววๆํ๋ࠬᵣ"),CMUXq6mPQV5rLsSBdWZJvA(u"ู࠭ศศ็๎ࠬᵤ"))
				ppweOR6rMg = ppweOR6rMg.replace(sdRqnego9PclrL4m2J(u"ࠧศฮ้ฬ๏ํࠧᵥ"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠨษฯ๊อ๐ࠧᵦ")).replace(WlU7AtONpyj3(u"ࠩ฼ีอ๐็ࠨᵧ"),J6G8X3gO1MiKh027D(u"ࠪ฽ึฮ๊ࠨᵨ")).replace(taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫึ๎ๅศ่ึ๎์࠭ᵩ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠬื่ๆษ้ื๏࠭ᵪ"))
				ppweOR6rMg = ppweOR6rMg.replace(MBS1GrwQoUlsiIRfVDOHdA(u"ฺ࠭าสํ๋ࠬᵫ"),tzEjvOaZWU1A(u"ࠧ฻ำห๎ࠬᵬ")).replace(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨุ๊้๊ࠣำๅษอࠫᵭ"),HfuZG0aphlYnVLOyAk93rj(u"่ࠩืู้ไศฬࠪᵮ")).replace(sdRqnego9PclrL4m2J(u"ࠪห฿อๆ๊ࠩᵯ"),HHthiRYs8T6IO3qUyX(u"ࠫฬเว็์ࠪᵰ"))
				ppweOR6rMg = ppweOR6rMg.replace(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬะวา์ั๎ࠬᵱ"),BBOY8rvinVbFh(u"࠭สศำําࠬᵲ")).replace(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧฯ์ส่ࠥ฿ไๆ์ࠪᵳ"),wb1nC3e8AjRVU4ovsuPa(u"ࠨะํห้࠭ᵴ")).replace(ZeV4vau9CjN(u"่ࠩ์ุ๐โ๋้ࠪᵵ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"้ࠪํู๊ใ๋ࠪᵶ"))
				ppweOR6rMg = ppweOR6rMg.replace(J6G8X3gO1MiKh027D(u"ࠫ์์ฯ๊ࠩᵷ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠬํๆะ์ࠪᵸ")).replace(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭็็ัํ๋ࠬᵹ"),z8wTfYPiRQL(u"่่ࠧา๎ࠬᵺ")).replace(FkqI4Gm8wMvUVbgo(u"ࠨ๊ฮหห่๊่ࠩᵻ"),HfuZG0aphlYnVLOyAk93rj(u"๋ࠩฯฬฬโ๋ࠩᵼ"))
				ppweOR6rMg = ppweOR6rMg.replace(WlU7AtONpyj3(u"ࠪฮ้๐แำ์๋๊๏ํࠧᵽ"),BBOY8rvinVbFh(u"ࠫฯ๊แำ์๋๊ࠬᵾ")).replace(tzEjvOaZWU1A(u"ࠬะไโิํ์๋๐็ࠨᵿ"),ZeV4vau9CjN(u"࠭สๅใี๎ํ์ࠧᶀ")).replace(taD1d3bpqyfM4VNhK0P29GSZ(u"้ࠧࠢๆีฯ๎ๆࠨᶁ"),WlU7AtONpyj3(u"ࠨ๊ๆีฯ๎ๆࠨᶂ"))
				ppweOR6rMg = ppweOR6rMg.replace(u8iSx05wLfVyMNp1X3l(u"ࠩส่าอไ๋้ࠪᶃ"),z8wTfYPiRQL(u"ࠪัฬ๊๊่ࠩᶄ")).replace(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"๊ࠫ๎ำໍไํࠫᶅ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"๋่ࠬิ์ๅํࠬᶆ")).replace(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭วๅษ้้๏࠭ᶇ"),HfuZG0aphlYnVLOyAk93rj(u"ࠧศ่่๎ࠬᶈ"))
				ppweOR6rMg = ppweOR6rMg.replace(HfuZG0aphlYnVLOyAk93rj(u"ࠨษ็ุ้๊ำๅษอࠫᶉ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"่ࠩืู้ไศฬࠪᶊ")).replace(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠪห้ฮัศ็ฯࠫᶋ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫอืวๆฮࠪᶌ")).replace(qvCARpoujaDHbnOgYF8274NkWzeG39(u"้ࠬวาฬ๋๊ࠬᶍ"),G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ใาฬ๋๊ࠬᶎ"))
				ppweOR6rMg = ppweOR6rMg.replace(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧฮำ๋ฬࠬᶏ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨฯิฬࠬᶐ")).replace(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩส่ฬ์วี์าࠫᶑ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪห๋อิ๋ัࠪᶒ")).replace(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫฬู๊้์๊ࠫᶓ"),ZeV4vau9CjN(u"ࠬอำ๋๊ํࠫᶔ"))
				ppweOR6rMg = ppweOR6rMg.replace(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ู࠭าส์ࠫᶕ"),MBS1GrwQoUlsiIRfVDOHdA(u"ฺࠧำห๎ࠬᶖ")).replace(XasF0WO7rDUHnEt8hAl9kLN(u"ࠨฬิ็๎࠭ᶗ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩอี่๐ࠧᶘ")).replace(YoMw2J1Ljp(u"ࠪฮึ้๊่ࠩᶙ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫฯืใ๋ࠩᶚ")).replace(Urj6egiVyHA75ZK(u"ࠬอไๆุสๅࠬᶛ"),HfuZG0aphlYnVLOyAk93rj(u"࠭ๅืษไࠫᶜ"))
				ppweOR6rMg = ppweOR6rMg.replace(sdRqnego9PclrL4m2J(u"ࠧา์สฺ๏࠭ᶝ"),sdRqnego9PclrL4m2J(u"ࠨำํห฻ฯࠧᶞ")).replace(u8iSx05wLfVyMNp1X3l(u"ࠩิ๎ฬ฼็ࠨᶟ"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠪี๏อึสࠩᶠ")).replace(MBS1GrwQoUlsiIRfVDOHdA(u"ࠫฬู๊้์๊ࠫᶡ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬอำ๋๊ํࠫᶢ"))
				ppweOR6rMg = ppweOR6rMg.replace(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ใ้็ํำ๎࠭ᶣ"),ZeV4vau9CjN(u"ࠧไ๊่๎ิ๐ࠧᶤ")).replace(ZeV4vau9CjN(u"ࠨๅ๋้๏ี๊่ࠩᶥ"),NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩๆ์๊๐ฯ๋ࠩᶦ")).replace(XasF0WO7rDUHnEt8hAl9kLN(u"ࠪห๋๐ๅ๋ࠩᶧ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫฬ์ๅ๋ࠩᶨ"))
				ppweOR6rMg = ppweOR6rMg.replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬอๆ๋็ํุ๋࠭ᶩ"),ZeV4vau9CjN(u"࠭ว็็ํุ๋࠭ᶪ")).replace(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧศ่่ํࠬᶫ"),z8wTfYPiRQL(u"ࠨษ้้๏ฺๆࠨᶬ")).replace(sdRqnego9PclrL4m2J(u"ࠩส๊๊๐ࠧᶭ"),z8wTfYPiRQL(u"ࠪห๋๋๊ี่ࠪᶮ"))
				ppweOR6rMg = ppweOR6rMg.replace(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫฬ์ๅ๋ึุ้๋࠭ᶯ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬอๆๆ์ื๊ࠬᶰ")).replace(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠭วๅษ้้๏ฺๆࠨᶱ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠧศ่่๎ู์ࠧᶲ")).replace(YoMw2J1Ljp(u"ࠨษไ่ฬ๋ࠠๆี็ื้อสࠨᶳ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪᶴ"))
				ppweOR6rMg = ppweOR6rMg.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).strip(HfuZG0aphlYnVLOyAk93rj(u"ࠪ࠱ࠬᶵ")).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if ppweOR6rMg not in list(mBRihGyOYN5AT2XgZU6a3M7.keys()): mBRihGyOYN5AT2XgZU6a3M7[ppweOR6rMg] = {}
			mBRihGyOYN5AT2XgZU6a3M7[ppweOR6rMg][CYil97XWVj4Z3SRKMUf8DGQeLa] = [uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0]
	l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,YoMw2J1Ljp(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᶶ"),ZeV4vau9CjN(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᶷ"),mBRihGyOYN5AT2XgZU6a3M7,ggbKIPj8XAQhBVyeu1oDO47FNz)
	if VdZ2GnPEoRkJzqp6ceS>=XclTGI5K8bzvgyEtHhPQY6DwRaN: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,sdRqnego9PclrL4m2J(u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧᶸ")+str(VdZ2GnPEoRkJzqp6ceS)+WlU7AtONpyj3(u"ࠧࠡ็๋ๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้้ࠠๆิฬࠦๅีๅ็อูࠥศษ้สࠤ฾อฯส่๊ࠢࠥอไฦ่อี๋๐สࠡ฻้ำ่่ࠦศๆ่์ฬู่้ࠡํ࠾ࠬᶹ")+RTYOBpNxgrD)
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧᶺ"))
	JabU23pYu7zWD8(yBOdNtTJF1m,yBOdNtTJF1m,yBOdNtTJF1m)
	PFdBcmhgrHfqQKG6yORvt()
	return
def j2UYx38S4BXWsZEAehrD9(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw):
	j74j26QlgA8 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	oCGwtNUbhvk2yQ4JTYM5KH91dg = Y3Ny5eLHdp.menuItemsLIST
	Y3Ny5eLHdp.menuItemsLIST[:] = []
	if j74j26QlgA8 and wb1nC3e8AjRVU4ovsuPa(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᶻ") not in uT9JyZBUCVavzKLOgw:
		PP3FsDicLyWuTR7GV5Ia = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪࡰ࡮ࡹࡴࠨᶼ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫᶽ"),Urj6egiVyHA75ZK(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭ᶾ")+Sun57X6YaOzP8NTpcBvUH3k)
	elif MBS1GrwQoUlsiIRfVDOHdA(u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭ᶿ") not in uT9JyZBUCVavzKLOgw or wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡠࡘࡒࡈࡤ࠭᷀") not in uT9JyZBUCVavzKLOgw:
		import POGUpLCdxq
		gfe2BNJ3kTF0Xx = wb1nC3e8AjRVU4ovsuPa(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥืำศศ็ࠤฬ๊ศา่ส้ั࠭᷁")
		if Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࡢࡐࡎ࡜ࡅࡠ᷂ࠩ") not in uT9JyZBUCVavzKLOgw:
			try: POGUpLCdxq.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,J6G8X3gO1MiKh027D(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ᷃"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+J6G8X3gO1MiKh027D(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᷄"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,taD1d3bpqyfM4VNhK0P29GSZ(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭᷅"),gfe2BNJ3kTF0Xx)
			try: POGUpLCdxq.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ᷆"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+J6G8X3gO1MiKh027D(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᷇"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,XasF0WO7rDUHnEt8hAl9kLN(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ᷈"),gfe2BNJ3kTF0Xx)
			try: POGUpLCdxq.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,sdRqnego9PclrL4m2J(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᷉"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᷊"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ᷋"),gfe2BNJ3kTF0Xx)
		if u8iSx05wLfVyMNp1X3l(u"ࠬࡥࡖࡐࡆࡢࠫ᷌") not in uT9JyZBUCVavzKLOgw:
			try: POGUpLCdxq.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,XasF0WO7rDUHnEt8hAl9kLN(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᷍"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+HfuZG0aphlYnVLOyAk93rj(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣ᷎ࠬ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ᷏࠭"),gfe2BNJ3kTF0Xx)
			try: POGUpLCdxq.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,HHthiRYs8T6IO3qUyX(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᷐"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᷑"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ᷒"),gfe2BNJ3kTF0Xx)
		PP3FsDicLyWuTR7GV5Ia = Y3Ny5eLHdp.menuItemsLIST
		if j74j26QlgA8: l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,MBS1GrwQoUlsiIRfVDOHdA(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᷓ"),taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧᷔ")+Sun57X6YaOzP8NTpcBvUH3k,PP3FsDicLyWuTR7GV5Ia,ggbKIPj8XAQhBVyeu1oDO47FNz)
	Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg
	return PP3FsDicLyWuTR7GV5Ia
def W51X3LngAQZluTKOdk(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw):
	j74j26QlgA8 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	oCGwtNUbhvk2yQ4JTYM5KH91dg = Y3Ny5eLHdp.menuItemsLIST
	Y3Ny5eLHdp.menuItemsLIST[:] = []
	if j74j26QlgA8 and oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᷕ") not in uT9JyZBUCVavzKLOgw:
		PP3FsDicLyWuTR7GV5Ia = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,dQvxmFkyLOteNMWBJ2bDHV(u"ࠨ࡮࡬ࡷࡹ࠭ᷖ"),Urj6egiVyHA75ZK(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨᷗ"),gNPRXprEAQJ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪᷘ")+Sun57X6YaOzP8NTpcBvUH3k)
	elif BBOY8rvinVbFh(u"ࠫࡤࡒࡉࡗࡇࡢࠫᷙ") not in uT9JyZBUCVavzKLOgw or CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡥࡖࡐࡆࡢࠫᷚ") not in uT9JyZBUCVavzKLOgw:
		import FWP6uTtizv
		gfe2BNJ3kTF0Xx = HfuZG0aphlYnVLOyAk93rj(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣีุอฦๅࠢส่อืๆศ็ฯࠫᷛ")
		if ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᷜ") not in uT9JyZBUCVavzKLOgw:
			try: FWP6uTtizv.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᷝ"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᷞ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,tzEjvOaZWU1A(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᷟ"),gfe2BNJ3kTF0Xx)
			try: FWP6uTtizv.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,BBOY8rvinVbFh(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᷠ"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷡ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᷢ"),gfe2BNJ3kTF0Xx)
			try: FWP6uTtizv.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,HHthiRYs8T6IO3qUyX(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᷣ"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷤ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,FkqI4Gm8wMvUVbgo(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᷥ"),gfe2BNJ3kTF0Xx)
		if kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡣ࡛ࡕࡄࡠࠩᷦ") not in uT9JyZBUCVavzKLOgw:
			try: FWP6uTtizv.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,z8wTfYPiRQL(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᷧ"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷨ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪᷩ"),gfe2BNJ3kTF0Xx)
			try: FWP6uTtizv.ELGOqyNZQRxIBo9g(Sun57X6YaOzP8NTpcBvUH3k,YoMw2J1Ljp(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᷪ"),kh850jKbzmBwY,kh850jKbzmBwY,uT9JyZBUCVavzKLOgw+gNPRXprEAQJ(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷫ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
			except: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,dQvxmFkyLOteNMWBJ2bDHV(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭ᷬ"),gfe2BNJ3kTF0Xx)
		PP3FsDicLyWuTR7GV5Ia = Y3Ny5eLHdp.menuItemsLIST
		if j74j26QlgA8: l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩᷭ"),NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫᷮ")+Sun57X6YaOzP8NTpcBvUH3k,PP3FsDicLyWuTR7GV5Ia,ggbKIPj8XAQhBVyeu1oDO47FNz)
	Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg
	return PP3FsDicLyWuTR7GV5Ia
def WMq4L5EvahslDK20fNAb6B(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw,yKWIbm2s6UYGv7LA91fj5iFz):
	JabU23pYu7zWD8(CZcUWsSLm46e37YphagTvVld,CZcUWsSLm46e37YphagTvVld,SmThPgBVzt8)
	if yKWIbm2s6UYGv7LA91fj5iFz: oFc6e7H5ywPQqxEDjA1zGR(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	elif A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᷯ") in uT9JyZBUCVavzKLOgw and not yKWIbm2s6UYGv7LA91fj5iFz: oFc6e7H5ywPQqxEDjA1zGR(dbo4vrnTM56I)
	OVPdJMvQn7oikXx9u = uT9JyZBUCVavzKLOgw.replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᷰ"),kh850jKbzmBwY).replace(J6G8X3gO1MiKh027D(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᷱ"),kh850jKbzmBwY).replace(ZeV4vau9CjN(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᷲ"),kh850jKbzmBwY)
	if not yKWIbm2s6UYGv7LA91fj5iFz:
		EE6ysIeB8jKNgCfOkv(MBS1GrwQoUlsiIRfVDOHdA(u"ࠩ࡯࡭ࡳࡱࠧᷳ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡษ็ว็ูวๆࠩᷴ"),kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"࠹࠹࠷Ὥ"),kh850jKbzmBwY,kh850jKbzmBwY,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ᷵")+OVPdJMvQn7oikXx9u,kh850jKbzmBwY,{dQvxmFkyLOteNMWBJ2bDHV(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᷶"):Sun57X6YaOzP8NTpcBvUH3k})
		EE6ysIeB8jKNgCfOkv(MBS1GrwQoUlsiIRfVDOHdA(u"࠭࡬ࡪࡰ࡮᷷ࠫ"),HHFAVK8SwRUqBLuTfdeJ9nbD+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤ᷸ࠬ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠼࠽࠾࠿Ὦ"))
		KATelV46pvn = [HfuZG0aphlYnVLOyAk93rj(u"ࠨลไ่ฬ๋᷹ࠧ"),G6GUCto502jZTLubYNnqMx8ywBah(u"่ࠩืู้ไศฬ᷺ࠪ"),MBS1GrwQoUlsiIRfVDOHdA(u"ุ้ࠪือ๋ษอࠫ᷻"),YoMw2J1Ljp(u"ࠫอืวๆฮࠪ᷼"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬษืโษ็ࠤํ้ัห๊้᷽ࠫ"),XasF0WO7rDUHnEt8hAl9kLN(u"࠭ัๆุส๊ࠬ᷾"),J6G8X3gO1MiKh027D(u"ࠧฤฯาฯ࠲ษฮา᷿ࠩ"),YoMw2J1Ljp(u"ࠨี็หุ๊ࠧḀ"),u8iSx05wLfVyMNp1X3l(u"่ࠩ์ุ๐โ๊ࠩḁ"),J6G8X3gO1MiKh027D(u"ࠪวูํั࠮ลๆฯึ࠭Ḃ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫฬ๊ย็ࠩḃ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬ฼อไࠩḄ"),ZeV4vau9CjN(u"࠭ั๋ษูอࠬḅ"),tzEjvOaZWU1A(u"ࠧ็์อๅ้้ำࠨḆ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨ็่ฯ้๐ๆࠨḇ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩหฯࠥำ๊ࠨḈ"),BBOY8rvinVbFh(u"ࠪำ๏์๊สࠩḉ"),J6G8X3gO1MiKh027D(u"ุࠫ์่ศฬࠪḊ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬษฮา๋ࠪḋ")]
		yKWIbm2s6UYGv7LA91fj5iFz = nxUveizbLEAT2FBNy3
		for d84tph1L9lkAWZ6IFMQCOmrGgq in KATelV46pvn:
			yKWIbm2s6UYGv7LA91fj5iFz += igM4DhpPzoX95Ysnar6Auj
			EE6ysIeB8jKNgCfOkv(WlU7AtONpyj3(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ḍ"),GalrcVUMy8bzORWX5E0exhYivBwgk+d84tph1L9lkAWZ6IFMQCOmrGgq,kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠻࠻࠹Ὧ"),kh850jKbzmBwY,str(yKWIbm2s6UYGv7LA91fj5iFz),OVPdJMvQn7oikXx9u,kh850jKbzmBwY,{kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḍ"):Sun57X6YaOzP8NTpcBvUH3k})
	else:
		gcXVUQpWYv0rxZKzl4onkuh2RAs = [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨษไ่ฬ๋ࠧḎ"),BBOY8rvinVbFh(u"ࠩࡰࡳࡻ࡯ࡥࠨḏ"),HHthiRYs8T6IO3qUyX(u"ࠪๅ๏๊ๅࠨḐ"),NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫๆ๊ๅࠨḑ")]
		sGaLKXvqkC = [dQvxmFkyLOteNMWBJ2bDHV(u"๋ࠬำๅี็ࠫḒ"),dQvxmFkyLOteNMWBJ2bDHV(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ḓ")]
		l3OcixJfoLrqge9MmQPtXw8syA = [HfuZG0aphlYnVLOyAk93rj(u"ࠧๆีสีา࠭Ḕ"),wb1nC3e8AjRVU4ovsuPa(u"ࠨ็ึีา๐วหࠩḕ")]
		jblOSZ5nd2YGxVAWzD3uUk = [Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩหีฬ๋ฬࠨḖ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪࡷ࡭ࡵࡷࠨḗ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠫฯ๊แำ์๋๊ࠬḘ"),HHthiRYs8T6IO3qUyX(u"ࠬะไ๋ใี๎ํ์ࠧḙ")]
		S7ETjqC5zL36wAKUbGxeBVPd2lv = [qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ว็็ํࠫḚ"),gNPRXprEAQJ(u"ࠧไำอ์๋࠭ḛ"),WlU7AtONpyj3(u"ࠨๅสีฯ๎ๆࠨḜ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩ࡮࡭ࡩࡹࠧḝ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪ฻ๆ๊ࠧḞ"),HHthiRYs8T6IO3qUyX(u"ࠫฬ฽แศๆࠪḟ")]
		pGim6EBLcDRZyarFJKMn9Hq = [A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬืๅืษ้ࠫḠ")]
		Em1lqDXHLbM6x0cv8Jiag = [BBOY8rvinVbFh(u"࠭วฮัฮࠫḡ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧศะิࠫḢ"),J6G8X3gO1MiKh027D(u"ࠨ็๋าึ࠭ḣ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩฯำ๏ีࠧḤ"),sdRqnego9PclrL4m2J(u"้ࠪ฻อแࠨḥ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠫาี๊ฬࠩḦ")]
		MKFfs9524DkNogJbxhZ1mz70VSH3iT = [ssYkHaML9z37bJ0StuEBXIqgiV(u"ูࠬไศี็ࠫḧ"),sdRqnego9PclrL4m2J(u"࠭ำๅี็๋ࠬḨ")]
		eeHRwB62fiMxmQ = [XasF0WO7rDUHnEt8hAl9kLN(u"ࠧศ฼ส๊๏࠭ḩ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨ็๋ื๏่้ࠨḪ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩๆ่๏ฮࠧḫ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪัๆ๊ࠧḬ"),sdRqnego9PclrL4m2J(u"ࠫࡲࡻࡳࡪࡥࠪḭ")]
		llAve4QkUWp0hnPb17No = [qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬอใฬำࠪḮ"),Urj6egiVyHA75ZK(u"࠭วี้ิࠫḯ"),WlU7AtONpyj3(u"ࠧๆ็ํึ์࠭Ḱ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨษ฼่๎࠭ḱ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"่ࠩาฯอั่ࠩḲ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"้ࠪำะวาษอࠫḳ"),HfuZG0aphlYnVLOyAk93rj(u"ࠫฬ่่๊ࠩḴ")]
		sa7Ok8vNHTAIVnhtFJ42SwXGY = [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬอไศ่ࠪḵ"),HfuZG0aphlYnVLOyAk93rj(u"࠭อศๆํࠫḶ"),gNPRXprEAQJ(u"ࠧๆอหฮࠬḷ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨำสสั࠭Ḹ")]
		JcjYNAGzgwivCSBZVlWMD2koEud69 = [HHthiRYs8T6IO3qUyX(u"ูࠩั่࠭ḹ"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠪ็ํ๋๊ะ์ࠪḺ")]
		MsSwaVtuoRTq2DYOdpBN3U5 = [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫึ๐วื้ࠪḻ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"้่ࠬา้ࠪḼ"),WlU7AtONpyj3(u"࠭ๅึษิ฽์࠭ḽ"),ZeV4vau9CjN(u"ࠧี๊อࠫḾ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨำํห฻ฯࠧḿ")]
		mMfOrtAEv3HjgcC = [gNPRXprEAQJ(u"้ࠩ๎ฯ็ไไีࠪṀ"),sdRqnego9PclrL4m2J(u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫṁ"),gNPRXprEAQJ(u"๋ࠫ๐สโๆํ็ุ࠭Ṃ")]
		yymTsc2fGjFHISNLZQvEaO3xeW = [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"๋ࠬๅฬๆํ๊ࠬṃ"),YoMw2J1Ljp(u"࠭วีะสูࠬṄ"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠧ็ฮ๋้ࠬṅ")]
		r1GaLwhMA3 = [qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨสฮࠤา๐ࠧṆ"),tzEjvOaZWU1A(u"ࠩ࡯࡭ࡻ࡫ࠧṇ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠪๆ๋อ็ࠨṈ"),sdRqnego9PclrL4m2J(u"ࠫ็์่ศฬࠪṉ")]
		bNZsa9It57THBEO0YK6zGVfLj = [MBS1GrwQoUlsiIRfVDOHdA(u"ࠬี๊็ࠩṊ"),z8wTfYPiRQL(u"࠭วะ฻ํ๋ࠬṋ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧำ์สีฬะࠧṌ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨๆฺ้๏อสࠨṍ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩา฽ฬวࠧṎ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠪๆึอๆࠨṏ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫ็฻ววัࠪṐ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬืหศรࠪṑ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠭ๅาฮ฼๎์࠭Ṓ"),Urj6egiVyHA75ZK(u"ࠧศาส๊ࠬṓ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨษึ่ฬ๋ࠧṔ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩอ์ฬฺ๊ฮࠩṕ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪา฼ฮࠧṖ"),HfuZG0aphlYnVLOyAk93rj(u"ࠫา๎า้์ࠪṗ"),wb1nC3e8AjRVU4ovsuPa(u"ࠬ฿สษษอࠫṘ"),sdRqnego9PclrL4m2J(u"࠭ๅ้ษ็๎ิ࠭ṙ"),ZeV4vau9CjN(u"ࠧ็๊ส฽๏࠭Ṛ"),tzEjvOaZWU1A(u"ࠨ฻ๅหหีࠧṛ"),tzEjvOaZWU1A(u"ࠩส๊ฬฺ๊ะࠩṜ")]
		mm0HivAWD2JO6TZo = [NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠪ࠶࠵࠷࠰ࠨṝ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫ࠷࠶࠱࠲ࠩṞ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬ࠸࠰࠲࠴ࠪṟ"),wnVICNyfE3XZ0htUaDFAOgLo(u"࠭࠲࠱࠳࠶ࠫṠ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧ࠳࠲࠴࠸ࠬṡ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠨ࠴࠳࠵࠺࠭Ṣ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩ࠵࠴࠶࠼ࠧṣ"),BBOY8rvinVbFh(u"ࠪ࠶࠵࠷࠷ࠨṤ"),z8wTfYPiRQL(u"ࠫ࠷࠶࠱࠹ࠩṥ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬ࠸࠰࠲࠻ࠪṦ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭࠲࠱࠴࠳ࠫṧ"),WlU7AtONpyj3(u"ࠧ࠳࠲࠵࠵ࠬṨ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨ࠴࠳࠶࠷࠭ṩ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩ࠵࠴࠷࠹ࠧṪ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪ࠶࠵࠸࠴ࠨṫ"),HfuZG0aphlYnVLOyAk93rj(u"ࠫ࠷࠶࠲࠶ࠩṬ"),Urj6egiVyHA75ZK(u"ࠬ࠸࠰࠳࠸ࠪṭ"),wnVICNyfE3XZ0htUaDFAOgLo(u"࠭࠲࠱࠴࠺ࠫṮ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠧ࠳࠲࠵࠼ࠬṯ")]
		for ppweOR6rMg in sorted(list(mBRihGyOYN5AT2XgZU6a3M7.keys())):
			tVNeLEOXQU1osj = ppweOR6rMg.lower()
			XvPwmy3axVdD6NIKGb4Ak = []
			if any(value in tVNeLEOXQU1osj for value in gcXVUQpWYv0rxZKzl4onkuh2RAs): XvPwmy3axVdD6NIKGb4Ak.append(igM4DhpPzoX95Ysnar6Auj)
			if any(value in tVNeLEOXQU1osj for value in sGaLKXvqkC): XvPwmy3axVdD6NIKGb4Ak.append(s0sB2Xyp9uYU5N3fxzKoLW8)
			if any(value in tVNeLEOXQU1osj for value in l3OcixJfoLrqge9MmQPtXw8syA): XvPwmy3axVdD6NIKGb4Ak.append(Q5yM0D6SaP9teHXufTGjUBc)
			if any(value in tVNeLEOXQU1osj for value in jblOSZ5nd2YGxVAWzD3uUk): XvPwmy3axVdD6NIKGb4Ak.append(HHQhABuNKV7cd)
			if any(value in tVNeLEOXQU1osj for value in S7ETjqC5zL36wAKUbGxeBVPd2lv): XvPwmy3axVdD6NIKGb4Ak.append(XONpB38LESgyRmt)
			if any(value in tVNeLEOXQU1osj for value in pGim6EBLcDRZyarFJKMn9Hq): XvPwmy3axVdD6NIKGb4Ak.append(wb1nC3e8AjRVU4ovsuPa(u"࠻ὰ"))
			if any(value in tVNeLEOXQU1osj for value in Em1lqDXHLbM6x0cv8Jiag) and tVNeLEOXQU1osj not in [taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨษัี๎࠭Ṱ")]: XvPwmy3axVdD6NIKGb4Ak.append(sdRqnego9PclrL4m2J(u"࠽ά"))
			if any(value in tVNeLEOXQU1osj for value in MKFfs9524DkNogJbxhZ1mz70VSH3iT): XvPwmy3axVdD6NIKGb4Ak.append(wnVICNyfE3XZ0htUaDFAOgLo(u"࠸ὲ"))
			if any(value in tVNeLEOXQU1osj for value in eeHRwB62fiMxmQ): XvPwmy3axVdD6NIKGb4Ak.append(ZeV4vau9CjN(u"࠺έ"))
			if any(value in tVNeLEOXQU1osj for value in llAve4QkUWp0hnPb17No): XvPwmy3axVdD6NIKGb4Ak.append(ssYkHaML9z37bJ0StuEBXIqgiV(u"࠳࠳ὴ"))
			if any(value in tVNeLEOXQU1osj for value in sa7Ok8vNHTAIVnhtFJ42SwXGY): XvPwmy3axVdD6NIKGb4Ak.append(FkqI4Gm8wMvUVbgo(u"࠴࠵ή"))
			if any(value in tVNeLEOXQU1osj for value in JcjYNAGzgwivCSBZVlWMD2koEud69): XvPwmy3axVdD6NIKGb4Ak.append(wb1nC3e8AjRVU4ovsuPa(u"࠵࠷ὶ"))
			if any(value in tVNeLEOXQU1osj for value in MsSwaVtuoRTq2DYOdpBN3U5): XvPwmy3axVdD6NIKGb4Ak.append(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠶࠹ί"))
			if any(value in tVNeLEOXQU1osj for value in mMfOrtAEv3HjgcC): XvPwmy3axVdD6NIKGb4Ak.append(wb1nC3e8AjRVU4ovsuPa(u"࠷࠴ὸ"))
			if any(value in tVNeLEOXQU1osj for value in yymTsc2fGjFHISNLZQvEaO3xeW): XvPwmy3axVdD6NIKGb4Ak.append(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠱࠶ό"))
			if any(value in tVNeLEOXQU1osj for value in r1GaLwhMA3): XvPwmy3axVdD6NIKGb4Ak.append(ZeV4vau9CjN(u"࠲࠸ὺ"))
			if any(value in tVNeLEOXQU1osj for value in bNZsa9It57THBEO0YK6zGVfLj): XvPwmy3axVdD6NIKGb4Ak.append(z8wTfYPiRQL(u"࠳࠺ύ"))
			if any(value in tVNeLEOXQU1osj for value in mm0HivAWD2JO6TZo): XvPwmy3axVdD6NIKGb4Ak.append(YoMw2J1Ljp(u"࠴࠼ὼ"))
			if not XvPwmy3axVdD6NIKGb4Ak: XvPwmy3axVdD6NIKGb4Ak = [CMUXq6mPQV5rLsSBdWZJvA(u"࠵࠾ώ")]
			for s9s4liu1z63XFfGJ8v2YU7 in XvPwmy3axVdD6NIKGb4Ak:
				if str(s9s4liu1z63XFfGJ8v2YU7)==yKWIbm2s6UYGv7LA91fj5iFz:
					EE6ysIeB8jKNgCfOkv(dQvxmFkyLOteNMWBJ2bDHV(u"ࠩࡩࡳࡱࡪࡥࡳࠩṱ"),GalrcVUMy8bzORWX5E0exhYivBwgk+ppweOR6rMg,ppweOR6rMg,YoMw2J1Ljp(u"࠶࠼࠶὾"),kh850jKbzmBwY,kh850jKbzmBwY,OVPdJMvQn7oikXx9u+HfuZG0aphlYnVLOyAk93rj(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṲ"))
	JabU23pYu7zWD8(CZcUWsSLm46e37YphagTvVld,CZcUWsSLm46e37YphagTvVld,yBOdNtTJF1m)
	return
def Wx8EH4gNsVSklQPIuLfYnRb73dyo(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw):
	j74j26QlgA8 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if j74j26QlgA8:
		EE6ysIeB8jKNgCfOkv(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡱ࡯࡮࡬ࠩṳ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡌࡔ࡙࡜ࠧṴ"),kh850jKbzmBwY,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠽࠶࠵὿"),kh850jKbzmBwY,kh850jKbzmBwY,tzEjvOaZWU1A(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫṵ"),kh850jKbzmBwY,{aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṶ"):Sun57X6YaOzP8NTpcBvUH3k})
		EE6ysIeB8jKNgCfOkv(kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨ࡮࡬ࡲࡰ࠭ṷ"),HHFAVK8SwRUqBLuTfdeJ9nbD+u8iSx05wLfVyMNp1X3l(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧṸ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,HHthiRYs8T6IO3qUyX(u"࠹࠺࠻࠼ᾀ"))
	oCGwtNUbhvk2yQ4JTYM5KH91dg = Y3Ny5eLHdp.menuItemsLIST[:]
	import POGUpLCdxq
	if Sun57X6YaOzP8NTpcBvUH3k:
		if not POGUpLCdxq.I7J9YEW8wxy6uOh35PVQf2G0v(Sun57X6YaOzP8NTpcBvUH3k,dbo4vrnTM56I): return
		ZpiXY6lfWEBHDsz7U42atL0g = j2UYx38S4BXWsZEAehrD9(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw)
		FTeYZftg5dr4X = sorted(ZpiXY6lfWEBHDsz7U42atL0g,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[igM4DhpPzoX95Ysnar6Auj].lower())
	else:
		if not POGUpLCdxq.I7J9YEW8wxy6uOh35PVQf2G0v(kh850jKbzmBwY,dbo4vrnTM56I): return
		if j74j26QlgA8 and BBOY8rvinVbFh(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨṹ") not in uT9JyZBUCVavzKLOgw:
			FTeYZftg5dr4X = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫࡱ࡯ࡳࡵࠩṺ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬṻ"),taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪṼ"))
		else:
			YYB0Qx7CgLKSZpuDjHU9w8Mv3JhGf,FTeYZftg5dr4X,ZpiXY6lfWEBHDsz7U42atL0g = [],[],[]
			for ffJ5nlzKxcTHt3Op in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
				FTeYZftg5dr4X += j2UYx38S4BXWsZEAehrD9(str(ffJ5nlzKxcTHt3Op),uT9JyZBUCVavzKLOgw)
			for type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in FTeYZftg5dr4X:
				if fRJYhnSKHsZ7MqFwmiVz not in YYB0Qx7CgLKSZpuDjHU9w8Mv3JhGf:
					YYB0Qx7CgLKSZpuDjHU9w8Mv3JhGf.append(fRJYhnSKHsZ7MqFwmiVz)
					feGcOun7EbDJQYsT0I1 = type,ppweOR6rMg,fRJYhnSKHsZ7MqFwmiVz,BBOY8rvinVbFh(u"࠲࠸࠸ᾁ"),vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,uT9JyZBUCVavzKLOgw,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA
					ZpiXY6lfWEBHDsz7U42atL0g.append(feGcOun7EbDJQYsT0I1)
			FTeYZftg5dr4X = sorted(ZpiXY6lfWEBHDsz7U42atL0g,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[igM4DhpPzoX95Ysnar6Auj].lower())
			if j74j26QlgA8: l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧṽ"),FkqI4Gm8wMvUVbgo(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬṾ"),FTeYZftg5dr4X,ggbKIPj8XAQhBVyeu1oDO47FNz)
	Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg+FTeYZftg5dr4X
	EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def Lb5V1Yi93hIcqZPFgQaKpe6kfm(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw):
	j74j26QlgA8 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	if j74j26QlgA8:
		EE6ysIeB8jKNgCfOkv(WlU7AtONpyj3(u"ࠩ࡯࡭ࡳࡱࠧṿ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡎ࠵ࡘࠫẀ"),kh850jKbzmBwY,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠹࠹࠹ᾂ"),kh850jKbzmBwY,kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩẁ"),kh850jKbzmBwY,{YoMw2J1Ljp(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẂ"):Sun57X6YaOzP8NTpcBvUH3k})
		EE6ysIeB8jKNgCfOkv(wb1nC3e8AjRVU4ovsuPa(u"࠭࡬ࡪࡰ࡮ࠫẃ"),HHFAVK8SwRUqBLuTfdeJ9nbD+Urj6egiVyHA75ZK(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬẄ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,CMUXq6mPQV5rLsSBdWZJvA(u"࠼࠽࠾࠿ᾃ"))
	oCGwtNUbhvk2yQ4JTYM5KH91dg = Y3Ny5eLHdp.menuItemsLIST[:]
	import FWP6uTtizv
	if Sun57X6YaOzP8NTpcBvUH3k:
		if not FWP6uTtizv.I7J9YEW8wxy6uOh35PVQf2G0v(Sun57X6YaOzP8NTpcBvUH3k,dbo4vrnTM56I): return
		ZpiXY6lfWEBHDsz7U42atL0g = W51X3LngAQZluTKOdk(Sun57X6YaOzP8NTpcBvUH3k,uT9JyZBUCVavzKLOgw)
		FTeYZftg5dr4X = sorted(ZpiXY6lfWEBHDsz7U42atL0g,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[igM4DhpPzoX95Ysnar6Auj].lower())
	else:
		if not FWP6uTtizv.I7J9YEW8wxy6uOh35PVQf2G0v(kh850jKbzmBwY,dbo4vrnTM56I): return
		if j74j26QlgA8 and sdRqnego9PclrL4m2J(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ẅ") not in uT9JyZBUCVavzKLOgw:
			FTeYZftg5dr4X = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩ࡯࡭ࡸࡺࠧẆ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩẇ"),wb1nC3e8AjRVU4ovsuPa(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧẈ"))
		else:
			YYB0Qx7CgLKSZpuDjHU9w8Mv3JhGf,FTeYZftg5dr4X,ZpiXY6lfWEBHDsz7U42atL0g = [],[],[]
			for ffJ5nlzKxcTHt3Op in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
				FTeYZftg5dr4X += W51X3LngAQZluTKOdk(str(ffJ5nlzKxcTHt3Op),uT9JyZBUCVavzKLOgw)
			for type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in FTeYZftg5dr4X:
				if fRJYhnSKHsZ7MqFwmiVz not in YYB0Qx7CgLKSZpuDjHU9w8Mv3JhGf:
					YYB0Qx7CgLKSZpuDjHU9w8Mv3JhGf.append(fRJYhnSKHsZ7MqFwmiVz)
					feGcOun7EbDJQYsT0I1 = type,ppweOR6rMg,fRJYhnSKHsZ7MqFwmiVz,qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠵࠻࠻ᾄ"),vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,uT9JyZBUCVavzKLOgw,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA
					ZpiXY6lfWEBHDsz7U42atL0g.append(feGcOun7EbDJQYsT0I1)
			FTeYZftg5dr4X = sorted(ZpiXY6lfWEBHDsz7U42atL0g,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[igM4DhpPzoX95Ysnar6Auj].lower())
			if j74j26QlgA8: l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,BBOY8rvinVbFh(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫẉ"),G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩẊ"),FTeYZftg5dr4X,ggbKIPj8XAQhBVyeu1oDO47FNz)
	Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg+FTeYZftg5dr4X
	EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def fgEQhqvlWG9sV7(group,uT9JyZBUCVavzKLOgw):
	j74j26QlgA8 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	PP3FsDicLyWuTR7GV5Ia = []
	KmhvgytAYriRb1WOxoQ = CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧẋ") if HfuZG0aphlYnVLOyAk93rj(u"ࠨࡋࡓࡘ࡛࠭Ẍ") in uT9JyZBUCVavzKLOgw else wb1nC3e8AjRVU4ovsuPa(u"ࠩࡢࡑ࠸࡛࡟ࠨẍ")
	if j74j26QlgA8: PP3FsDicLyWuTR7GV5Ia = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡰ࡮ࡹࡴࠨẎ"),u8iSx05wLfVyMNp1X3l(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭ẏ")+KmhvgytAYriRb1WOxoQ[:-igM4DhpPzoX95Ysnar6Auj],group)
	if not PP3FsDicLyWuTR7GV5Ia:
		for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
			if j74j26QlgA8: PP3FsDicLyWuTR7GV5Ia += uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡲࡩࡴࡶࠪẐ"),YoMw2J1Ljp(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨẑ")+KmhvgytAYriRb1WOxoQ[:-igM4DhpPzoX95Ysnar6Auj],aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩẒ")+KmhvgytAYriRb1WOxoQ+str(Sun57X6YaOzP8NTpcBvUH3k))
			elif KmhvgytAYriRb1WOxoQ==HfuZG0aphlYnVLOyAk93rj(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨẓ"): PP3FsDicLyWuTR7GV5Ia += j2UYx38S4BXWsZEAehrD9(str(Sun57X6YaOzP8NTpcBvUH3k),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧẔ"))
			elif KmhvgytAYriRb1WOxoQ==HHthiRYs8T6IO3qUyX(u"ࠪࡣࡒ࠹ࡕࡠࠩẕ"): PP3FsDicLyWuTR7GV5Ia += W51X3LngAQZluTKOdk(str(Sun57X6YaOzP8NTpcBvUH3k),YoMw2J1Ljp(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩẖ"))
		for type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in PP3FsDicLyWuTR7GV5Ia:
			if fRJYhnSKHsZ7MqFwmiVz==group: fz6oQdSusZKCOcM7IDLaFi(type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA)
		items,h729UnyEIjoYSNKcLOvqfV4 = [],[]
		for type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in Y3Ny5eLHdp.menuItemsLIST:
			iD4HKrQRlI6BOVjqWzTpa9bE = type,ppweOR6rMg[HHQhABuNKV7cd:],url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,kh850jKbzmBwY
			if iD4HKrQRlI6BOVjqWzTpa9bE not in h729UnyEIjoYSNKcLOvqfV4:
				h729UnyEIjoYSNKcLOvqfV4.append(iD4HKrQRlI6BOVjqWzTpa9bE)
				JJNIsO8Vcbx0 = type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA
				items.append(JJNIsO8Vcbx0)
		PP3FsDicLyWuTR7GV5Ia = sorted(items,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[igM4DhpPzoX95Ysnar6Auj].lower()[wnVICNyfE3XZ0htUaDFAOgLo(u"࠺ᾅ"):])
		if j74j26QlgA8: l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,G6GUCto502jZTLubYNnqMx8ywBah(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧẗ")+KmhvgytAYriRb1WOxoQ[:-igM4DhpPzoX95Ysnar6Auj],group,PP3FsDicLyWuTR7GV5Ia,ggbKIPj8XAQhBVyeu1oDO47FNz)
	if XasF0WO7rDUHnEt8hAl9kLN(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨẘ") in uT9JyZBUCVavzKLOgw and len(PP3FsDicLyWuTR7GV5Ia)>GwgEhH98FjfJks:
		Y3Ny5eLHdp.menuItemsLIST[:] = []
		EE6ysIeB8jKNgCfOkv(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẙ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠨ࡝ࠪẚ")+HHFAVK8SwRUqBLuTfdeJ9nbD+group+wVvqN8LZCJW5ryAb1EHRPFkQ0+HHthiRYs8T6IO3qUyX(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫẛ"),group,ZeV4vau9CjN(u"࠷࠶࠶ᾆ"),kh850jKbzmBwY,kh850jKbzmBwY,KmhvgytAYriRb1WOxoQ+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẜ"))
		EE6ysIeB8jKNgCfOkv(wb1nC3e8AjRVU4ovsuPa(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẝ"),FkqI4Gm8wMvUVbgo(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫẞ"),group,J6G8X3gO1MiKh027D(u"࠱࠷࠷ᾇ"),kh850jKbzmBwY,kh850jKbzmBwY,KmhvgytAYriRb1WOxoQ+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬẟ"))
		EE6ysIeB8jKNgCfOkv(J6G8X3gO1MiKh027D(u"ࠧ࡭࡫ࡱ࡯ࠬẠ"),HHFAVK8SwRUqBLuTfdeJ9nbD+sdRqnego9PclrL4m2J(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ạ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,CMUXq6mPQV5rLsSBdWZJvA(u"࠺࠻࠼࠽ᾈ"))
		PP3FsDicLyWuTR7GV5Ia = Y3Ny5eLHdp.menuItemsLIST+TvsJhn6Sa1zbp8W3NVFy.sample(PP3FsDicLyWuTR7GV5Ia,GwgEhH98FjfJks)
	Y3Ny5eLHdp.menuItemsLIST[:] = PP3FsDicLyWuTR7GV5Ia
	EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def u0e95cZOkv4CYRN1snL37JpEPTj(uT9JyZBUCVavzKLOgw):
	EE6ysIeB8jKNgCfOkv(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩࡩࡳࡱࡪࡥࡳࠩẢ"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭ả"),kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠳࠹࠵ᾉ"),kh850jKbzmBwY,kh850jKbzmBwY,ZeV4vau9CjN(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫẤ"))
	EE6ysIeB8jKNgCfOkv(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬࡲࡩ࡯࡭ࠪấ"),HHFAVK8SwRUqBLuTfdeJ9nbD+HHthiRYs8T6IO3qUyX(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẦ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,u8iSx05wLfVyMNp1X3l(u"࠼࠽࠾࠿ᾊ"))
	mrjbsKyLA9NfnT = Y3Ny5eLHdp.menuItemsLIST[:]
	Y3Ny5eLHdp.menuItemsLIST[:] = []
	import GE5WAD6LR8
	GE5WAD6LR8.yIGljH8dub0q4zoD(wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧ࠱ࠩầ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	GE5WAD6LR8.yIGljH8dub0q4zoD(tzEjvOaZWU1A(u"ࠨ࠳ࠪẨ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	GE5WAD6LR8.yIGljH8dub0q4zoD(XasF0WO7rDUHnEt8hAl9kLN(u"ࠩ࠵ࠫẩ"),wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	if FkqI4Gm8wMvUVbgo(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬẪ") in uT9JyZBUCVavzKLOgw:
		Y3Ny5eLHdp.menuItemsLIST[:] = eZPpNcREw3(Y3Ny5eLHdp.menuItemsLIST)
		if len(Y3Ny5eLHdp.menuItemsLIST)>GwgEhH98FjfJks: Y3Ny5eLHdp.menuItemsLIST[:] = TvsJhn6Sa1zbp8W3NVFy.sample(Y3Ny5eLHdp.menuItemsLIST,GwgEhH98FjfJks)
	Y3Ny5eLHdp.menuItemsLIST[:] = mrjbsKyLA9NfnT+Y3Ny5eLHdp.menuItemsLIST
	return
def d3GSvVOrUP4(uT9JyZBUCVavzKLOgw):
	uT9JyZBUCVavzKLOgw = uT9JyZBUCVavzKLOgw.replace(J6G8X3gO1MiKh027D(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẫ"),kh850jKbzmBwY).replace(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẬ"),kh850jKbzmBwY)
	headers = { J6G8X3gO1MiKh027D(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪậ") : kh850jKbzmBwY }
	url = qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭Ắ")
	data = {Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪắ"):HfuZG0aphlYnVLOyAk93rj(u"ࠩ࠸࠴ࠬẰ")}
	data = KQUd6anP3Rr95(data)
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(i8a54nkd09BCbvuZxQFMAqDR2tlK,Urj6egiVyHA75ZK(u"ࠪࡋࡊ࡚ࠧằ"),url,data,headers,kh850jKbzmBwY,kh850jKbzmBwY,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭Ẳ"))
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧẳ"),uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(tzEjvOaZWU1A(u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫẴ"),ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	jFPDKnIecQaEd10oOTRbHC,R95WdH4eIVKB0Xsto1MycG = list(zip(*items))
	vmhEpfaXCjwlgRiJxZ5D = []
	oTpnSkE3tJ4 = [EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,YoMw2J1Ljp(u"ࠧࠣࠩẵ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨࡢࠪẶ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠩ࠯ࠫặ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪ࠲ࠬẸ"),BBOY8rvinVbFh(u"ࠫ࠿࠭ẹ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬࡁࠧẺ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨࠧࠣẻ"),Urj6egiVyHA75ZK(u"ࠧ࠮ࠩẼ")]
	e0o2pvyIfYq6ErDclijhTHXRO3LP = R95WdH4eIVKB0Xsto1MycG+jFPDKnIecQaEd10oOTRbHC
	for WW2AkuUHShqLGE5M0soCl in e0o2pvyIfYq6ErDclijhTHXRO3LP:
		if WW2AkuUHShqLGE5M0soCl in R95WdH4eIVKB0Xsto1MycG: ggCwmAnsjOdlHBtf8DbSyR7QZW = s0sB2Xyp9uYU5N3fxzKoLW8
		if WW2AkuUHShqLGE5M0soCl in jFPDKnIecQaEd10oOTRbHC: ggCwmAnsjOdlHBtf8DbSyR7QZW = HHQhABuNKV7cd
		wu82GQl7DKiAV6Sv = [asKYTS478qkW in WW2AkuUHShqLGE5M0soCl for asKYTS478qkW in oTpnSkE3tJ4]
		if any(wu82GQl7DKiAV6Sv):
			CCb3sqcILQHYeMzR = wu82GQl7DKiAV6Sv.index(dbo4vrnTM56I)
			Zy3osrg6IFYlt1L = oTpnSkE3tJ4[CCb3sqcILQHYeMzR]
			ExDvpNMBWayqz6UFGkJ0c8Zh = kh850jKbzmBwY
			if WW2AkuUHShqLGE5M0soCl.count(Zy3osrg6IFYlt1L)>igM4DhpPzoX95Ysnar6Auj: HJ1apOwvNL8UzS,dcuGer5yqHa,ExDvpNMBWayqz6UFGkJ0c8Zh = WW2AkuUHShqLGE5M0soCl.split(Zy3osrg6IFYlt1L,s0sB2Xyp9uYU5N3fxzKoLW8)
			else: HJ1apOwvNL8UzS,dcuGer5yqHa = WW2AkuUHShqLGE5M0soCl.split(Zy3osrg6IFYlt1L,igM4DhpPzoX95Ysnar6Auj)
			if len(HJ1apOwvNL8UzS)>ggCwmAnsjOdlHBtf8DbSyR7QZW: vmhEpfaXCjwlgRiJxZ5D.append(HJ1apOwvNL8UzS.lower())
			if len(dcuGer5yqHa)>ggCwmAnsjOdlHBtf8DbSyR7QZW: vmhEpfaXCjwlgRiJxZ5D.append(dcuGer5yqHa.lower())
			if len(ExDvpNMBWayqz6UFGkJ0c8Zh)>ggCwmAnsjOdlHBtf8DbSyR7QZW: vmhEpfaXCjwlgRiJxZ5D.append(ExDvpNMBWayqz6UFGkJ0c8Zh.lower())
		elif len(WW2AkuUHShqLGE5M0soCl)>ggCwmAnsjOdlHBtf8DbSyR7QZW: vmhEpfaXCjwlgRiJxZ5D.append(WW2AkuUHShqLGE5M0soCl.lower())
	for asKYTS478qkW in range(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠽ᾋ")): TvsJhn6Sa1zbp8W3NVFy.shuffle(vmhEpfaXCjwlgRiJxZ5D)
	if G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩẽ") in uT9JyZBUCVavzKLOgw:
		QapdADRH3jNBfIzxYLnvbGEW = Ege1mcK0zWQ
	elif sdRqnego9PclrL4m2J(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩẾ") in uT9JyZBUCVavzKLOgw:
		QapdADRH3jNBfIzxYLnvbGEW = [wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪࡍࡕ࡚ࡖࠨế")]
		import POGUpLCdxq
		if not POGUpLCdxq.I7J9YEW8wxy6uOh35PVQf2G0v(kh850jKbzmBwY,dbo4vrnTM56I): return
	elif BBOY8rvinVbFh(u"ࠫࡤࡓ࠳ࡖࡡࠪỀ") in uT9JyZBUCVavzKLOgw:
		QapdADRH3jNBfIzxYLnvbGEW = [gNPRXprEAQJ(u"ࠬࡓ࠳ࡖࠩề")]
		import FWP6uTtizv
		if not FWP6uTtizv.I7J9YEW8wxy6uOh35PVQf2G0v(kh850jKbzmBwY,dbo4vrnTM56I): return
	count,U9fOcsBvwXPnmjR = nxUveizbLEAT2FBNy3,nxUveizbLEAT2FBNy3
	EE6ysIeB8jKNgCfOkv(z8wTfYPiRQL(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ể"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧ࡜ࠢࠣࡡࠥࡀวๅสะฯࠥ฿ๆࠨể"),kh850jKbzmBwY,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠶࠼࠴ᾌ"),kh850jKbzmBwY,kh850jKbzmBwY,tzEjvOaZWU1A(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ễ")+uT9JyZBUCVavzKLOgw)
	EE6ysIeB8jKNgCfOkv(dQvxmFkyLOteNMWBJ2bDHV(u"ࠩࡩࡳࡱࡪࡥࡳࠩễ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪỆ"),kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠷࠶࠵ᾍ"),kh850jKbzmBwY,kh850jKbzmBwY,z8wTfYPiRQL(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩệ")+uT9JyZBUCVavzKLOgw)
	EE6ysIeB8jKNgCfOkv(taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬࡲࡩ࡯࡭ࠪỈ"),HHFAVK8SwRUqBLuTfdeJ9nbD+XasF0WO7rDUHnEt8hAl9kLN(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫỉ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠹࠺࠻࠼ᾎ"))
	R47aAWs9Flv = Y3Ny5eLHdp.menuItemsLIST[:]
	Y3Ny5eLHdp.menuItemsLIST[:] = []
	SkIaHvdN3jg = []
	for WW2AkuUHShqLGE5M0soCl in vmhEpfaXCjwlgRiJxZ5D:
		dcuGer5yqHa = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(XasF0WO7rDUHnEt8hAl9kLN(u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆࠧỊ")+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࠥࠪị")+u8iSx05wLfVyMNp1X3l(u"ࠩ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭Ọ"),WW2AkuUHShqLGE5M0soCl,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if dcuGer5yqHa: WW2AkuUHShqLGE5M0soCl = WW2AkuUHShqLGE5M0soCl.split(dcuGer5yqHa[nxUveizbLEAT2FBNy3],igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		MI72vlN5pyfBCnagiWZGt4 = WW2AkuUHShqLGE5M0soCl.replace(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪ๕ࠬọ"),kh850jKbzmBwY).replace(J6G8X3gO1MiKh027D(u"ࠫ๓࠭Ỏ"),kh850jKbzmBwY).replace(HHthiRYs8T6IO3qUyX(u"ࠬ๑ࠧỏ"),kh850jKbzmBwY).replace(FkqI4Gm8wMvUVbgo(u"࠭๏ࠨỐ"),kh850jKbzmBwY).replace(ZeV4vau9CjN(u"ࠧํࠩố"),kh850jKbzmBwY)
		MI72vlN5pyfBCnagiWZGt4 = MI72vlN5pyfBCnagiWZGt4.replace(wb1nC3e8AjRVU4ovsuPa(u"ࠨ๒ࠪỒ"),kh850jKbzmBwY).replace(z8wTfYPiRQL(u"ࠩ๐ࠫồ"),kh850jKbzmBwY).replace(tzEjvOaZWU1A(u"ࠪ๖ࠬỔ"),kh850jKbzmBwY).replace(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫฑ࠭ổ"),kh850jKbzmBwY).replace(HfuZG0aphlYnVLOyAk93rj(u"ࠬๆࠧỖ"),kh850jKbzmBwY)
		if MI72vlN5pyfBCnagiWZGt4: SkIaHvdN3jg.append(MI72vlN5pyfBCnagiWZGt4)
	aIkprum6c2jgG7OLMTd1Atyf9EVUz = []
	for aaHueZUKGJDOvqjAy6CTinMIY in range(nxUveizbLEAT2FBNy3,ZeV4vau9CjN(u"࠳࠲ᾏ")):
		search = TvsJhn6Sa1zbp8W3NVFy.sample(SkIaHvdN3jg,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		if search in aIkprum6c2jgG7OLMTd1Atyf9EVUz: continue
		aIkprum6c2jgG7OLMTd1Atyf9EVUz.append(search)
		CYil97XWVj4Z3SRKMUf8DGQeLa = TvsJhn6Sa1zbp8W3NVFy.sample(QapdADRH3jNBfIzxYLnvbGEW,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+FkqI4Gm8wMvUVbgo(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩỗ")+str(CYil97XWVj4Z3SRKMUf8DGQeLa)+ZeV4vau9CjN(u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪỘ")+search)
		p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
		VNevGUwBskhaFpPEr5oMyACH2q8(search+BBOY8rvinVbFh(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ộ"))
		if len(Y3Ny5eLHdp.menuItemsLIST)>nxUveizbLEAT2FBNy3: break
	search = search.replace(z8wTfYPiRQL(u"ࠩࡢࡑࡔࡊ࡟ࠨỚ"),kh850jKbzmBwY)
	R47aAWs9Flv[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj] = YoMw2J1Ljp(u"ࠪ࡟ࠬớ")+HHFAVK8SwRUqBLuTfdeJ9nbD+search+wVvqN8LZCJW5ryAb1EHRPFkQ0+taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࠥࡀศฮอࠣ฽๋ࡣࠧỜ")
	Y3Ny5eLHdp.menuItemsLIST[:] = eZPpNcREw3(Y3Ny5eLHdp.menuItemsLIST)
	if len(Y3Ny5eLHdp.menuItemsLIST)>GwgEhH98FjfJks: Y3Ny5eLHdp.menuItemsLIST[:] = TvsJhn6Sa1zbp8W3NVFy.sample(Y3Ny5eLHdp.menuItemsLIST,GwgEhH98FjfJks)
	Y3Ny5eLHdp.menuItemsLIST[:] = R47aAWs9Flv+Y3Ny5eLHdp.menuItemsLIST
	return
def j4JHxalrRMOfh(baGthHun86,uT9JyZBUCVavzKLOgw):
	baGthHun86 = baGthHun86.replace(Urj6egiVyHA75ZK(u"ࠬࡥࡍࡐࡆࡢࠫờ"),kh850jKbzmBwY)
	uT9JyZBUCVavzKLOgw = uT9JyZBUCVavzKLOgw.replace(wb1nC3e8AjRVU4ovsuPa(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨỞ"),kh850jKbzmBwY).replace(aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫở"),kh850jKbzmBwY)
	oFc6e7H5ywPQqxEDjA1zGR(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	if not mBRihGyOYN5AT2XgZU6a3M7: return
	if ZeV4vau9CjN(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪỠ") in uT9JyZBUCVavzKLOgw:
		EE6ysIeB8jKNgCfOkv(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠩࡩࡳࡱࡪࡥࡳࠩỡ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪ࡟ࠬỢ")+HHFAVK8SwRUqBLuTfdeJ9nbD+baGthHun86+wVvqN8LZCJW5ryAb1EHRPFkQ0+WlU7AtONpyj3(u"ࠫࠥࡀวๅไึ้ࡢ࠭ợ"),baGthHun86,wb1nC3e8AjRVU4ovsuPa(u"࠳࠹࠺ᾐ"),kh850jKbzmBwY,kh850jKbzmBwY,FkqI4Gm8wMvUVbgo(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪỤ")+uT9JyZBUCVavzKLOgw)
		EE6ysIeB8jKNgCfOkv(WlU7AtONpyj3(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ụ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭Ủ"),baGthHun86,taD1d3bpqyfM4VNhK0P29GSZ(u"࠴࠺࠻ᾑ"),kh850jKbzmBwY,kh850jKbzmBwY,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ủ")+uT9JyZBUCVavzKLOgw)
		EE6ysIeB8jKNgCfOkv(BBOY8rvinVbFh(u"ࠩ࡯࡭ࡳࡱࠧỨ"),HHFAVK8SwRUqBLuTfdeJ9nbD+MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨứ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,G6GUCto502jZTLubYNnqMx8ywBah(u"࠽࠾࠿࠹ᾒ"))
	for website in sorted(list(mBRihGyOYN5AT2XgZU6a3M7[baGthHun86].keys())):
		uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = mBRihGyOYN5AT2XgZU6a3M7[baGthHun86][website]
		if sdRqnego9PclrL4m2J(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ừ") in uT9JyZBUCVavzKLOgw or len(mBRihGyOYN5AT2XgZU6a3M7[baGthHun86])==igM4DhpPzoX95Ysnar6Auj:
			fz6oQdSusZKCOcM7IDLaFi(uDJvEcha9x4OtnN5e18yKqA3zgmW,kh850jKbzmBwY,url,b1EixfJBaNcTQW,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,kh850jKbzmBwY)
			Y3Ny5eLHdp.menuItemsLIST[:] = eZPpNcREw3(Y3Ny5eLHdp.menuItemsLIST)
			oCGwtNUbhvk2yQ4JTYM5KH91dg,FTeYZftg5dr4X = Y3Ny5eLHdp.menuItemsLIST[:Q5yM0D6SaP9teHXufTGjUBc],Y3Ny5eLHdp.menuItemsLIST[Q5yM0D6SaP9teHXufTGjUBc:]
			if ZeV4vau9CjN(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧừ") in uT9JyZBUCVavzKLOgw:
				for asKYTS478qkW in range(SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠾ᾓ")): TvsJhn6Sa1zbp8W3NVFy.shuffle(FTeYZftg5dr4X)
				Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg+FTeYZftg5dr4X[:GwgEhH98FjfJks]
			else: Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg+FTeYZftg5dr4X
		elif HfuZG0aphlYnVLOyAk93rj(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧỬ") in uT9JyZBUCVavzKLOgw: EE6ysIeB8jKNgCfOkv(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧử"),website,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA)
	return
def vmY7GIyLVJ6(uT9JyZBUCVavzKLOgw,eYN1APt8aZflKmByj0ioGzn):
	uT9JyZBUCVavzKLOgw = uT9JyZBUCVavzKLOgw.replace(tzEjvOaZWU1A(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪỮ"),kh850jKbzmBwY).replace(u8iSx05wLfVyMNp1X3l(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ữ"),kh850jKbzmBwY)
	ppweOR6rMg,FTeYZftg5dr4X = kh850jKbzmBwY,[]
	EE6ysIeB8jKNgCfOkv(wb1nC3e8AjRVU4ovsuPa(u"ࠪࡪࡴࡲࡤࡦࡴࠪỰ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫࡠ࠭ự")+HHFAVK8SwRUqBLuTfdeJ9nbD+ppweOR6rMg+wVvqN8LZCJW5ryAb1EHRPFkQ0+CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧỲ"),kh850jKbzmBwY,eYN1APt8aZflKmByj0ioGzn,kh850jKbzmBwY,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỳ")+uT9JyZBUCVavzKLOgw)
	EE6ysIeB8jKNgCfOkv(u8iSx05wLfVyMNp1X3l(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỴ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨỵ"),kh850jKbzmBwY,eYN1APt8aZflKmByj0ioGzn,kh850jKbzmBwY,kh850jKbzmBwY,ZeV4vau9CjN(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧỶ")+uT9JyZBUCVavzKLOgw)
	EE6ysIeB8jKNgCfOkv(FkqI4Gm8wMvUVbgo(u"ࠪࡰ࡮ࡴ࡫ࠨỷ"),HHFAVK8SwRUqBLuTfdeJ9nbD+ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩỸ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠿࠹࠺࠻ᾔ"))
	oCGwtNUbhvk2yQ4JTYM5KH91dg = Y3Ny5eLHdp.menuItemsLIST[:]
	Y3Ny5eLHdp.menuItemsLIST[:] = []
	PP3FsDicLyWuTR7GV5Ia = []
	if oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭ỹ") in uT9JyZBUCVavzKLOgw:
		oFc6e7H5ywPQqxEDjA1zGR(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		if not mBRihGyOYN5AT2XgZU6a3M7: return
		ZnbVHraDcfhNypLPUo8Q9tRESF0Blv = list(mBRihGyOYN5AT2XgZU6a3M7.keys())
		baGthHun86 = TvsJhn6Sa1zbp8W3NVFy.sample(ZnbVHraDcfhNypLPUo8Q9tRESF0Blv,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		vmhEpfaXCjwlgRiJxZ5D = list(mBRihGyOYN5AT2XgZU6a3M7[baGthHun86].keys())
		website = TvsJhn6Sa1zbp8W3NVFy.sample(vmhEpfaXCjwlgRiJxZ5D,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = mBRihGyOYN5AT2XgZU6a3M7[baGthHun86][website]
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+z8wTfYPiRQL(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩỺ")+website+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪỻ")+ppweOR6rMg+dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪỼ")+url+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬỽ")+str(b1EixfJBaNcTQW))
	elif taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡣࡎࡖࡔࡗࡡࠪỾ") in uT9JyZBUCVavzKLOgw:
		import POGUpLCdxq
		if not POGUpLCdxq.I7J9YEW8wxy6uOh35PVQf2G0v(kh850jKbzmBwY,dbo4vrnTM56I): return
		for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
			PP3FsDicLyWuTR7GV5Ia += j2UYx38S4BXWsZEAehrD9(str(Sun57X6YaOzP8NTpcBvUH3k),uT9JyZBUCVavzKLOgw)
		if not PP3FsDicLyWuTR7GV5Ia: return
		uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = TvsJhn6Sa1zbp8W3NVFy.sample(PP3FsDicLyWuTR7GV5Ia,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫỿ")+ppweOR6rMg+YoMw2J1Ljp(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧἀ")+url+MBS1GrwQoUlsiIRfVDOHdA(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩἁ")+str(b1EixfJBaNcTQW))
	elif SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡠࡏ࠶࡙ࡤ࠭ἂ") in uT9JyZBUCVavzKLOgw:
		import FWP6uTtizv
		if not FWP6uTtizv.I7J9YEW8wxy6uOh35PVQf2G0v(kh850jKbzmBwY,dbo4vrnTM56I): return
		for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
			PP3FsDicLyWuTR7GV5Ia += W51X3LngAQZluTKOdk(str(Sun57X6YaOzP8NTpcBvUH3k),uT9JyZBUCVavzKLOgw)
		if not PP3FsDicLyWuTR7GV5Ia: return
		uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = TvsJhn6Sa1zbp8W3NVFy.sample(PP3FsDicLyWuTR7GV5Ia,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
		IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨἃ")+ppweOR6rMg+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫἄ")+url+HHthiRYs8T6IO3qUyX(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭ἅ")+str(b1EixfJBaNcTQW))
	vZbc19g2BWe = ppweOR6rMg
	p9qJOfmsl0Cvca31jEDibI5kNdu = []
	for asKYTS478qkW in range(nxUveizbLEAT2FBNy3,FkqI4Gm8wMvUVbgo(u"࠱࠱ᾕ")):
		if asKYTS478qkW>nxUveizbLEAT2FBNy3: IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+FkqI4Gm8wMvUVbgo(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫἆ")+ppweOR6rMg+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧἇ")+url+dQvxmFkyLOteNMWBJ2bDHV(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩἈ")+str(b1EixfJBaNcTQW))
		Y3Ny5eLHdp.menuItemsLIST[:] = []
		if b1EixfJBaNcTQW==wnVICNyfE3XZ0htUaDFAOgLo(u"࠳࠵࠷ᾖ") and YoMw2J1Ljp(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨἉ") in fRJYhnSKHsZ7MqFwmiVz: b1EixfJBaNcTQW = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠴࠶࠷ᾗ")
		if b1EixfJBaNcTQW==XasF0WO7rDUHnEt8hAl9kLN(u"࠺࠵࠹ᾘ") and aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨἊ") in fRJYhnSKHsZ7MqFwmiVz: b1EixfJBaNcTQW = gNPRXprEAQJ(u"࠻࠶࠹ᾙ")
		if b1EixfJBaNcTQW==MBS1GrwQoUlsiIRfVDOHdA(u"࠶࠺࠴ᾚ"): b1EixfJBaNcTQW = wnVICNyfE3XZ0htUaDFAOgLo(u"࠸࠹࠲ᾛ")
		W7BTt4f3CkhKJIY = fz6oQdSusZKCOcM7IDLaFi(uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA)
		if A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩἋ") in uT9JyZBUCVavzKLOgw and b1EixfJBaNcTQW==wnVICNyfE3XZ0htUaDFAOgLo(u"࠱࠷࠹ᾜ"): del Y3Ny5eLHdp.menuItemsLIST[:Q5yM0D6SaP9teHXufTGjUBc]
		if ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡣࡒ࠹ࡕࡠࠩἌ") in uT9JyZBUCVavzKLOgw and b1EixfJBaNcTQW==kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠲࠸࠻ᾝ"): del Y3Ny5eLHdp.menuItemsLIST[:Q5yM0D6SaP9teHXufTGjUBc]
		FTeYZftg5dr4X[:] = eZPpNcREw3(Y3Ny5eLHdp.menuItemsLIST)
		if p9qJOfmsl0Cvca31jEDibI5kNdu and iBnaOtjD0XE63YSrbP4NHye(HHthiRYs8T6IO3qUyX(u"ࡹࠬำไใหࠪἍ")) in str(FTeYZftg5dr4X) or iBnaOtjD0XE63YSrbP4NHye(A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࡺ࠭อๅไ๊ࠫἎ")) in str(FTeYZftg5dr4X):
			ppweOR6rMg = vZbc19g2BWe
			FTeYZftg5dr4X[:] = p9qJOfmsl0Cvca31jEDibI5kNdu
			break
		vZbc19g2BWe = ppweOR6rMg
		p9qJOfmsl0Cvca31jEDibI5kNdu = FTeYZftg5dr4X
		if str(FTeYZftg5dr4X).count(HfuZG0aphlYnVLOyAk93rj(u"࠭ࡶࡪࡦࡨࡳࠬἏ"))>nxUveizbLEAT2FBNy3: break
		if str(FTeYZftg5dr4X).count(z8wTfYPiRQL(u"ࠧ࡭࡫ࡹࡩࠬἐ"))>nxUveizbLEAT2FBNy3: break
		if b1EixfJBaNcTQW==z8wTfYPiRQL(u"࠴࠶࠷ᾞ"): break
		if b1EixfJBaNcTQW==XasF0WO7rDUHnEt8hAl9kLN(u"࠺࠵࠸ᾟ"): break
		if b1EixfJBaNcTQW==SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠶࠾࠷ᾠ"): break
		if CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪἑ") in uT9JyZBUCVavzKLOgw and FTeYZftg5dr4X: uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,url,b1EixfJBaNcTQW,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = TvsJhn6Sa1zbp8W3NVFy.sample(FTeYZftg5dr4X,igM4DhpPzoX95Ysnar6Auj)[nxUveizbLEAT2FBNy3]
	if not ppweOR6rMg: ppweOR6rMg = u8iSx05wLfVyMNp1X3l(u"ࠩ࠱࠲࠳࠴ࠧἒ")
	elif ppweOR6rMg.count(tzEjvOaZWU1A(u"ࠪࡣࠬἓ"))>igM4DhpPzoX95Ysnar6Auj: ppweOR6rMg = ppweOR6rMg.split(HfuZG0aphlYnVLOyAk93rj(u"ࠫࡤ࠭ἔ"),s0sB2Xyp9uYU5N3fxzKoLW8)[s0sB2Xyp9uYU5N3fxzKoLW8]
	ppweOR6rMg = ppweOR6rMg.replace(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨἕ"),kh850jKbzmBwY)
	ppweOR6rMg = ppweOR6rMg.replace(wnVICNyfE3XZ0htUaDFAOgLo(u"࠭࡟ࡎࡑࡇࡣࠬ἖"),kh850jKbzmBwY)
	oCGwtNUbhvk2yQ4JTYM5KH91dg[nxUveizbLEAT2FBNy3][igM4DhpPzoX95Ysnar6Auj] = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧ࡜ࠩ἗")+HHFAVK8SwRUqBLuTfdeJ9nbD+ppweOR6rMg+wVvqN8LZCJW5ryAb1EHRPFkQ0+wb1nC3e8AjRVU4ovsuPa(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪἘ")
	if FkqI4Gm8wMvUVbgo(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫἙ") in uT9JyZBUCVavzKLOgw:
		for asKYTS478qkW in range(ssYkHaML9z37bJ0StuEBXIqgiV(u"࠾ᾡ")): TvsJhn6Sa1zbp8W3NVFy.shuffle(FTeYZftg5dr4X)
		Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg+FTeYZftg5dr4X[:GwgEhH98FjfJks]
	else: Y3Ny5eLHdp.menuItemsLIST[:] = oCGwtNUbhvk2yQ4JTYM5KH91dg+FTeYZftg5dr4X
	return
def RRxjByl3UDQte4w0FXcaKG(vQb0qrFDG6,xPnJbzmsK3A):
	xPnJbzmsK3A = xPnJbzmsK3A.replace(MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬἚ"),kh850jKbzmBwY).replace(BBOY8rvinVbFh(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨἛ"),kh850jKbzmBwY)
	If6AGv5Q7KyYgFC0xpukhTPL1q = xPnJbzmsK3A
	if WlU7AtONpyj3(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ἔ") in xPnJbzmsK3A:
		If6AGv5Q7KyYgFC0xpukhTPL1q = xPnJbzmsK3A.split(J6G8X3gO1MiKh027D(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧἝ"))[nxUveizbLEAT2FBNy3]
		type = XasF0WO7rDUHnEt8hAl9kLN(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ἞")
	elif MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡘࡒࡈࠬ἟") in vQb0qrFDG6: type = WlU7AtONpyj3(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬἠ")
	elif wb1nC3e8AjRVU4ovsuPa(u"ࠪࡐࡎ࡜ࡅࠨἡ") in vQb0qrFDG6: type = u8iSx05wLfVyMNp1X3l(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬἢ")
	EE6ysIeB8jKNgCfOkv(BBOY8rvinVbFh(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἣ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࡛࠭ࠨἤ")+HHFAVK8SwRUqBLuTfdeJ9nbD+type+If6AGv5Q7KyYgFC0xpukhTPL1q+wVvqN8LZCJW5ryAb1EHRPFkQ0+gNPRXprEAQJ(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩἥ"),vQb0qrFDG6,Urj6egiVyHA75ZK(u"࠷࠶࠸ᾢ"),kh850jKbzmBwY,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ἦ")+xPnJbzmsK3A)
	EE6ysIeB8jKNgCfOkv(G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡩࡳࡱࡪࡥࡳࠩἧ"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩἨ"),vQb0qrFDG6,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠱࠷࠹ᾣ"),kh850jKbzmBwY,kh850jKbzmBwY,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩἩ")+xPnJbzmsK3A)
	EE6ysIeB8jKNgCfOkv(qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࡲࡩ࡯࡭ࠪἪ"),HHFAVK8SwRUqBLuTfdeJ9nbD+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫἫ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠺࠻࠼࠽ᾤ"))
	import POGUpLCdxq
	for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
		if MBS1GrwQoUlsiIRfVDOHdA(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨἬ") in xPnJbzmsK3A: POGUpLCdxq.ELGOqyNZQRxIBo9g(str(Sun57X6YaOzP8NTpcBvUH3k),vQb0qrFDG6,xPnJbzmsK3A,kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		else: POGUpLCdxq.yIGljH8dub0q4zoD(str(Sun57X6YaOzP8NTpcBvUH3k),vQb0qrFDG6,xPnJbzmsK3A,kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	Y3Ny5eLHdp.menuItemsLIST[:] = eZPpNcREw3(Y3Ny5eLHdp.menuItemsLIST)
	if len(Y3Ny5eLHdp.menuItemsLIST)>(GwgEhH98FjfJks+Q5yM0D6SaP9teHXufTGjUBc): Y3Ny5eLHdp.menuItemsLIST[:] = Y3Ny5eLHdp.menuItemsLIST[:Q5yM0D6SaP9teHXufTGjUBc]+TvsJhn6Sa1zbp8W3NVFy.sample(Y3Ny5eLHdp.menuItemsLIST[Q5yM0D6SaP9teHXufTGjUBc:],GwgEhH98FjfJks)
	return
def SSgh9L8GZjdNbRVaIFJQP(vQb0qrFDG6,xPnJbzmsK3A):
	xPnJbzmsK3A = xPnJbzmsK3A.replace(x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪἭ"),kh850jKbzmBwY).replace(ZeV4vau9CjN(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ἦ"),kh850jKbzmBwY)
	If6AGv5Q7KyYgFC0xpukhTPL1q = xPnJbzmsK3A
	if ZeV4vau9CjN(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪἯ") in xPnJbzmsK3A:
		If6AGv5Q7KyYgFC0xpukhTPL1q = xPnJbzmsK3A.split(dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫἰ"))[nxUveizbLEAT2FBNy3]
		type = z8wTfYPiRQL(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨἱ")
	elif MBS1GrwQoUlsiIRfVDOHdA(u"࠭ࡖࡐࡆࠪἲ") in vQb0qrFDG6: type = CMUXq6mPQV5rLsSBdWZJvA(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪἳ")
	elif SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡎࡌ࡚ࡊ࠭ἴ") in vQb0qrFDG6: type = gNPRXprEAQJ(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪἵ")
	EE6ysIeB8jKNgCfOkv(ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡪࡴࡲࡤࡦࡴࠪἶ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡠ࠭ἷ")+HHFAVK8SwRUqBLuTfdeJ9nbD+type+If6AGv5Q7KyYgFC0xpukhTPL1q+wVvqN8LZCJW5ryAb1EHRPFkQ0+dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧἸ"),vQb0qrFDG6,gNPRXprEAQJ(u"࠳࠹࠼ᾥ"),kh850jKbzmBwY,kh850jKbzmBwY,wnVICNyfE3XZ0htUaDFAOgLo(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἹ")+xPnJbzmsK3A)
	EE6ysIeB8jKNgCfOkv(Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἺ"),u8iSx05wLfVyMNp1X3l(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧἻ"),vQb0qrFDG6,wb1nC3e8AjRVU4ovsuPa(u"࠴࠺࠽ᾦ"),kh850jKbzmBwY,kh850jKbzmBwY,dQvxmFkyLOteNMWBJ2bDHV(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἼ")+xPnJbzmsK3A)
	EE6ysIeB8jKNgCfOkv(dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡰ࡮ࡴ࡫ࠨἽ"),HHFAVK8SwRUqBLuTfdeJ9nbD+qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩἾ")+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,MBS1GrwQoUlsiIRfVDOHdA(u"࠽࠾࠿࠹ᾧ"))
	import FWP6uTtizv
	for Sun57X6YaOzP8NTpcBvUH3k in range(igM4DhpPzoX95Ysnar6Auj,xXUqn2W1CElKt0+igM4DhpPzoX95Ysnar6Auj):
		if SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬἿ") in xPnJbzmsK3A: FWP6uTtizv.ELGOqyNZQRxIBo9g(str(Sun57X6YaOzP8NTpcBvUH3k),vQb0qrFDG6,xPnJbzmsK3A,kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
		else: FWP6uTtizv.yIGljH8dub0q4zoD(str(Sun57X6YaOzP8NTpcBvUH3k),vQb0qrFDG6,xPnJbzmsK3A,kh850jKbzmBwY,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	Y3Ny5eLHdp.menuItemsLIST[:] = eZPpNcREw3(Y3Ny5eLHdp.menuItemsLIST)
	if len(Y3Ny5eLHdp.menuItemsLIST)>(GwgEhH98FjfJks+Q5yM0D6SaP9teHXufTGjUBc): Y3Ny5eLHdp.menuItemsLIST[:] = Y3Ny5eLHdp.menuItemsLIST[:Q5yM0D6SaP9teHXufTGjUBc]+TvsJhn6Sa1zbp8W3NVFy.sample(Y3Ny5eLHdp.menuItemsLIST[Q5yM0D6SaP9teHXufTGjUBc:],GwgEhH98FjfJks)
	return
def eZPpNcREw3(NqXisd9IcjvQ1g5DG):
	rnAlWvF0CbwP2dHoED3RTxf6G = []
	for type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA in NqXisd9IcjvQ1g5DG:
		if HfuZG0aphlYnVLOyAk93rj(u"࠭ีโฯฬࠫὀ") in ppweOR6rMg or CMUXq6mPQV5rLsSBdWZJvA(u"ࠧึใะ๋ࠬὁ") in ppweOR6rMg or gNPRXprEAQJ(u"ࠨࡲࡤ࡫ࡪ࠭ὂ") in ppweOR6rMg.lower(): continue
		rnAlWvF0CbwP2dHoED3RTxf6G.append([type,ppweOR6rMg,url,eYN1APt8aZflKmByj0ioGzn,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,fRJYhnSKHsZ7MqFwmiVz,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA])
	return rnAlWvF0CbwP2dHoED3RTxf6G
# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from FF2tjaMxBU import *
SITESURLS = {
     z8wTfYPiRQL(u"ࠪࡅࡍ࡝ࡁࡌࠩඓ")        : [BBOY8rvinVbFh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭ඔ")]
    ,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࡇࡋࡐࡃࡐࠫඕ")        : [CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪඖ")]
    ,FkqI4Gm8wMvUVbgo(u"ࠧࡂࡍ࡚ࡅࡒ࠭඗")        : [MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨ඘")]
    ,FkqI4Gm8wMvUVbgo(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬ඙")    : [dQvxmFkyLOteNMWBJ2bDHV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢ࡭ࡺࡥࡲ࠴ࡴࡶࡤࡨࠫක")]
    ,CMUXq6mPQV5rLsSBdWZJvA(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ඛ")     : [qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫග")]
    ,HfuZG0aphlYnVLOyAk93rj(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧඝ")      : [ZeV4vau9CjN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩඞ")]
    ,YoMw2J1Ljp(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪඟ")     : [MBS1GrwQoUlsiIRfVDOHdA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡩࡡ࡮ࠩච")]
    ,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨඡ")  : [u8iSx05wLfVyMNp1X3l(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫජ")]
    ,Urj6egiVyHA75ZK(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧඣ")     : [sdRqnego9PclrL4m2J(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡷࡩ࠴࡯࡯࡮ࠪඤ")]
    ,HHthiRYs8T6IO3qUyX(u"ࠧࡂ࡛ࡏࡓࡑ࠭ඥ")        : [A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨඦ")]
    ,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡅࡓࡐࡘࡁࠨට")        : [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧࡰ࡮ࡼࡥ࠯ࡥࡲࠫඨ")]
    ,tzEjvOaZWU1A(u"ࠫࡇࡘࡓࡕࡇࡍࠫඩ")       : [wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷ࡭࡯࠴ࡣࡢ࡯ࠪඪ")]
    ,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧණ")      : [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭ඬ")]
    ,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨත")       : [BBOY8rvinVbFh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠳ࡩࡩ࡮ࡣ࠷ࡴ࠳ࡩ࡯࡮ࠩථ")]
    ,FkqI4Gm8wMvUVbgo(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪද")       : [u8iSx05wLfVyMNp1X3l(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪධ")]
    ,HfuZG0aphlYnVLOyAk93rj(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫන") : [x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵࡸࡹ࠲ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡳࡩࡱࡳࠫ඲")]
    ,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩඳ")     : [Urj6egiVyHA75ZK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡪ࡯ࡤࡪࡦࡴࡳ࠯ࡥࡲࠫප")]
    ,ZeV4vau9CjN(u"ࠩࡆࡍࡒࡇࡆࡓࡇࡈࠫඵ")     : [u8iSx05wLfVyMNp1X3l(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡨࡵࡩ࠳ࡺ࡯ࡥࡣࡼࠫබ")]
    ,WlU7AtONpyj3(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧභ")    : [G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷࠫම")]
    ,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧඹ")      : [tzEjvOaZWU1A(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡦࡧࠬය")]
    ,HfuZG0aphlYnVLOyAk93rj(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪර")     : [HfuZG0aphlYnVLOyAk93rj(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡾࡩࡩ࡮ࡣ࠱ࡧࡨ࠭඼")]
    ,WlU7AtONpyj3(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨල")  : [u8iSx05wLfVyMNp1X3l(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ඾"), G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡳࡣࡳ࡬ࡶࡲ࠮ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭඿"), G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡤࡶࡨ࡮࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩව")]
    ,FkqI4Gm8wMvUVbgo(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪශ")    : [Urj6egiVyHA75ZK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠺࠴ࡤࡳࡣࡰࡥࡨࡧࡦࡦ࠯ࡷࡺ࠳ࡩ࡯࡮ࠩෂ")]
    ,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫස")     : [CMUXq6mPQV5rLsSBdWZJvA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳࡬ࡵ࡯ࠩහ")]
    ,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ළ")     : [BBOY8rvinVbFh(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡬ࡨࠬෆ")]
    ,HfuZG0aphlYnVLOyAk93rj(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ෇")     : [wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧ෈")]
    ,gNPRXprEAQJ(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ෉")      : [sdRqnego9PclrL4m2J(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦ්ࠩ")]
    ,u8iSx05wLfVyMNp1X3l(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬ෋")     : [oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡬ࡤ࡫ࡱࡩࡲࡧ࠮ࡤࡱࡰࠫ෌")]
    ,wb1nC3e8AjRVU4ovsuPa(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ෍")    : [oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠮ࡦ࡮࡬ࡪ࠳ࡴࡥࡸࡵࠪ෎")]
    ,YoMw2J1Ljp(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨා")      : [ZeV4vau9CjN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭ැ")]
    ,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬෑ")    : [kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨි")]
    ,YoMw2J1Ljp(u"ࠫࡋࡕࡓࡕࡃࠪී")        : [A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡹࡨࡦࡸ࡯ࡴࡦࠩු")]
    ,wb1nC3e8AjRVU4ovsuPa(u"࠭ࡆࡖࡐࡒࡒ࡙࡜ࠧ෕")      : [A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࠱ࡥࡱࡳࡥࡴࡪ࡮ࡥ࡭࠴࡮ࡦࡶࠪූ")]
    ,tzEjvOaZWU1A(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪ෗")     : [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦ࠳࡬ࡵࡴࡪࡤࡶ࠲ࡺࡶ࠯ࡥࡲࡱࠬෘ")]
    ,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨෙ")  : [YoMw2J1Ljp(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡧࡷࡶ࡬ࡦࡸ࠮ࡷ࡫ࡧࡩࡴ࠭ේ")]
    ,u8iSx05wLfVyMNp1X3l(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧෛ")     : [MBS1GrwQoUlsiIRfVDOHdA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡩࡣ࡯ࡥࡨ࡯࡭ࡢ࠰ࡰࡩࡩ࡯ࡡࠨො")]
    ,BBOY8rvinVbFh(u"ࠧࡊࡈࡌࡐࡒ࠭ෝ")        : [z8wTfYPiRQL(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩෞ"), CMUXq6mPQV5rLsSBdWZJvA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡳ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪෟ"), MBS1GrwQoUlsiIRfVDOHdA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ෠"), qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠳࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭෡"), dQvxmFkyLOteNMWBJ2bDHV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠿࠳࠯࠳࠼࠴࠳࠸࠴࠯࠳࠵࠶ࠬ෢")]
    ,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ෣")    : [BBOY8rvinVbFh(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡤࡶࡧࡧ࡬ࡢ࠯ࡷࡺ࠳࡯ࡱࠨ෤")]
    ,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ෥")     : [CMUXq6mPQV5rLsSBdWZJvA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯࡮ࡺ࡫ࡰࡶ࠱ࡦࡺࢀࡺࠨ෦")]
    ,WlU7AtONpyj3(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫ෧")      : [Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡩࡳ࡯ࡤࡰࡰ࠴࡯ࡳࡩࠪ෨")]
    ,CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ෩")       : [XasF0WO7rDUHnEt8hAl9kLN(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡣࡵࡳࡿࡧ࠮ࡪࡰ࡮ࠫ෪")]
    ,wb1nC3e8AjRVU4ovsuPa(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ෫")      : [HfuZG0aphlYnVLOyAk93rj(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡸࡴࡶࠧ෬")]
    ,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬ෭")    : [BBOY8rvinVbFh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮࡮ࡣࡶࡥ࠳ࡴࡥࡸࡵࠪ෮")]
    ,u8iSx05wLfVyMNp1X3l(u"ࠫࡕࡇࡎࡆࡖࠪ෯")        : [sdRqnego9PclrL4m2J(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧ෰")]
    ,wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨ෱")     : [SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫࠲ࡩࡲࡧࡤࡠࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠯ࡰ࡮ࡧ࠳࡮ࡴࡤࡦࡺ࠱࡬ࡹࡳ࡬ࠨෲ")]
    ,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬෳ")   : [YoMw2J1Ljp(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡦ࠴ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧ࠱ࡧࡦࡳࠧ෴")]
    ,HHthiRYs8T6IO3qUyX(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭෵")    : [taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠮ࡧࡱࡵࡹࡲ࠭෶")]
    ,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ෷")   : [sdRqnego9PclrL4m2J(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡦ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭෸")]
    ,sdRqnego9PclrL4m2J(u"ࠧࡔࡊࡒࡊࡍࡇࠧ෹")       : [HfuZG0aphlYnVLOyAk93rj(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬ෺")]
    ,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ෻")     : [HfuZG0aphlYnVLOyAk93rj(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ෼"), wb1nC3e8AjRVU4ovsuPa(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ෽"), WlU7AtONpyj3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ෾")]
    ,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨ෿")     : [ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡸ࡮࡯ࡰࡨࡱࡩࡹ࠴࡯࡯࡮࡬ࡲࡪ࠭฀")]
    ,ZeV4vau9CjN(u"ࠨࡖࡌࡏࡆࡇࡔࠨก")       : [YoMw2J1Ljp(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡱࡡࡢࡶ࠱ࡲࡪࡺࠧข")]
    ,u8iSx05wLfVyMNp1X3l(u"ࠪࡘ࡛ࡌࡕࡏࠩฃ")        : [dQvxmFkyLOteNMWBJ2bDHV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩค")]
    ,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬฅ")       : [aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ฆ")]
    ,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫง")   : [Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫจ")]
    ,MBS1GrwQoUlsiIRfVDOHdA(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪฉ")      : [Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡩ࡯ࡲࡦࡥࡷࠫช")]
    ,J6G8X3gO1MiKh027D(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬซ")      : [WlU7AtONpyj3(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡡࡤࠩฌ")]
    ,gNPRXprEAQJ(u"࡙࠭ࡂࡓࡒࡘࠬญ")        : [wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬฎ")]
    ,sdRqnego9PclrL4m2J(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩฏ")      : [HfuZG0aphlYnVLOyAk93rj(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬฐ")]
    ,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩฑ") : [aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧฒ")]
    ,tzEjvOaZWU1A(u"ࠬࡏࡐࡕࡘࠪณ")         : [kh850jKbzmBwY]
    ,wb1nC3e8AjRVU4ovsuPa(u"࠭ࡍ࠴ࡗࠪด")          : [kh850jKbzmBwY]
    ,tzEjvOaZWU1A(u"ࠧࡓࡇࡓࡓࡘ࠭ต")        : [kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨถ"), XasF0WO7rDUHnEt8hAl9kLN(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ท"), z8wTfYPiRQL(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧธ")]
    ,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠱ࠨน")   : [dQvxmFkyLOteNMWBJ2bDHV(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩบ"), G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧป"), MBS1GrwQoUlsiIRfVDOHdA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨผ")]
    ,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓ࠶ࠬฝ")   : [dQvxmFkyLOteNMWBJ2bDHV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧพ"), WlU7AtONpyj3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬฟ"), qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ภ")]
    ,MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠴ࠩม")   : [tzEjvOaZWU1A(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧย"), taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬร"), MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ฤ")]
    ,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠩࡎࡓࡉࡏ࡟ࡔࡑࡘࡖࡈࡋࡓࠨล") : [ZeV4vau9CjN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮࠯࡬ࡱࡧ࡭ࠬฦ"), kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡯ࡴࡪࡩࠨว"), G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫศ")]
    ,ZeV4vau9CjN(u"࠭ࡆࡊࡎࡈࡗࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭ษ"): [ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶࠧส")]
    ,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧห") : [J6G8X3gO1MiKh027D(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬฬ"), YoMw2J1Ljp(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩอ")]
}
PRIVATE_VPS_SERVER_URLS = [dQvxmFkyLOteNMWBJ2bDHV(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠶࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬ࡀ࠱࠹࠳࠸࠳࡫࡫ࡴࡤࡪࠪฮ"), tzEjvOaZWU1A(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠷࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠺࠳࠺࠵࠹࠴ࡸࡥࡴࡱ࡯ࡺࡪ࠭ฯ")]
if igM4DhpPzoX95Ysnar6Auj:
    SITESURLS[taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ะ")] = [
        x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩั"), dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭า"), Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬำ"),
        aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨิ"), A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨี"), tzEjvOaZWU1A(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫึ"),
        SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧื"), wb1nC3e8AjRVU4ovsuPa(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨุ"), SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨูࠩ"),
        qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ฺࠧ"), YoMw2J1Ljp(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭฻"), WlU7AtONpyj3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭฼")
    ]
    SITESURLS[oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠳ࠪ฽")] = [
        CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ฾"), BBOY8rvinVbFh(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ฿"),
        BBOY8rvinVbFh(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭เ"), dQvxmFkyLOteNMWBJ2bDHV(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩแ"),
        ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩโ"), kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬใ"),
        BBOY8rvinVbFh(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨไ"), HfuZG0aphlYnVLOyAk93rj(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩๅ"),
        taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪๆ"), YoMw2J1Ljp(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ็"),
        z8wTfYPiRQL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹ่ࠧ"), x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡽࡥࡣࡥࡤࡧ࡭࡫้ࠧ")
    ]
    SITESURLS[YoMw2J1Ljp(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳๊ࠩ")] = [
        CMUXq6mPQV5rLsSBdWZJvA(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯࡭࡫ࡶࡸࡵࡲࡡࡺ๋ࠩ"), gNPRXprEAQJ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭์"),
        qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬํ"), z8wTfYPiRQL(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ๎"),
        FkqI4Gm8wMvUVbgo(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ๏"), taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ๐"),
        Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ๑"), aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ๒"),
        J6G8X3gO1MiKh027D(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ๓"), sdRqnego9PclrL4m2J(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ๔"),
        dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭๕"), SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭๖")
    ]
    SITESURLS[MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠳ࠨ๗")] = [
        HHthiRYs8T6IO3qUyX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ๘"), gNPRXprEAQJ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ๙"), J6G8X3gO1MiKh027D(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ๚"), x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭๛"),
        wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭๜"), aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ๝"), WlU7AtONpyj3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ๞"),
        HfuZG0aphlYnVLOyAk93rj(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭๟"), Urj6egiVyHA75ZK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ๠"), ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ๡"),
        qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ๢"), sdRqnego9PclrL4m2J(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡺࡩࡧࡩࡡࡤࡪࡨࠫ๣")
    ]
else:
    SITESURLS[A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ๤")] = [
        gNPRXprEAQJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭๥"), sdRqnego9PclrL4m2J(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ๦"), Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ๧"), FkqI4Gm8wMvUVbgo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ๨"),
        FkqI4Gm8wMvUVbgo(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ๩"), qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ๪"), oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ๫"),
        SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ๬"), WlU7AtONpyj3(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭๭"), J6G8X3gO1MiKh027D(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ๮"),
        HHthiRYs8T6IO3qUyX(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪ๯"), WlU7AtONpyj3(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪ๰")
    ]
    SITESURLS[Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠶࠭๱")] = [
        tzEjvOaZWU1A(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ๲"), aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ๳"), WlU7AtONpyj3(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ๴"), wb1nC3e8AjRVU4ovsuPa(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ๵"),
        z8wTfYPiRQL(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ๶"), Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ๷"), wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ๸"),
        ZeV4vau9CjN(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ๹"), x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ๺"), XasF0WO7rDUHnEt8hAl9kLN(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ๻"),
        BBOY8rvinVbFh(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩ๼"), WlU7AtONpyj3(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡸࡧࡥࡧࡦࡩࡨࡦࠩ๽")
    ]
    SITESURLS[gNPRXprEAQJ(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬ๾")] = [
        ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ๿"), ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ຀"), qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧກ"), taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪຂ"),
        G6GUCto502jZTLubYNnqMx8ywBah(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ຃"), CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ຄ"), oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ຅"),
        J6G8X3gO1MiKh027D(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪຆ"), A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫງ"), taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩຈ"),
        A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨຉ"), taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥࠨຊ")
    ]
    SITESURLS[G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫ຋")] = [
        SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪຌ"), Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧຍ"), z8wTfYPiRQL(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ຎ"), ZeV4vau9CjN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩຏ"),
        CMUXq6mPQV5rLsSBdWZJvA(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩຐ"), WlU7AtONpyj3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬຑ"), FkqI4Gm8wMvUVbgo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨຒ"),
        SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩຓ"), BBOY8rvinVbFh(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪດ"), taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨຕ"),
        FkqI4Gm8wMvUVbgo(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧຖ"), aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧທ")
    ]
api_python_actions = [kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧຘ"), YoMw2J1Ljp(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧນ"), ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧບ"), gNPRXprEAQJ(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪປ"), J6G8X3gO1MiKh027D(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫຜ"), kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ຝ"), YoMw2J1Ljp(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩພ"), A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭ຟ"), dQvxmFkyLOteNMWBJ2bDHV(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧຠ"), u8iSx05wLfVyMNp1X3l(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩມ"), Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡇ࡛ࡉࡈ࡛ࡔࡆࡌࡖࠫຢ"),XasF0WO7rDUHnEt8hAl9kLN(u"࡚ࠩࡉࡇࡉࡁࡄࡊࡈࠫຣ")]
api_repos_actions = [ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡅࡉࡊࡏࡏࡕࠪ຤"), ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭ລ"), HfuZG0aphlYnVLOyAk93rj(u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ຦")]
non_videos_actions = [taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡁࡍࡎࠪວ"), dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧຨ"), CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩຩ"), Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ສ"), YoMw2J1Ljp(u"ࠪࡖࡊࡖࡏࡔࠩຫ"), kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧຬ"), BBOY8rvinVbFh(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨອ"), x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬຮ"), Urj6egiVyHA75ZK(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡈࡇࡗࡍࡉ࠭ຯ"), sdRqnego9PclrL4m2J(u"ࠨࡕࡌࡘࡊ࡙ࡕࡓࡎࡖࠫະ")] + api_python_actions + api_repos_actions
CF9584m6rqWJQd2 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
YOx3mT62jDIFtVG = dbo4vrnTM56I
OdwIhsZak4uy3p6N1r8UMngT = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
PJ4koZBprVaY3C8 = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
avprivsnorestrict = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
avprivslongperiod = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
resolveonly = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
ktRv3MH6Ju1qSrXAyaV7BGf = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
ALLOW_DNS_FIX = Yv0mlf7x2VyTOQrw3GLHhE9M8pnzs
ALLOW_PROXY_FIX = Yv0mlf7x2VyTOQrw3GLHhE9M8pnzs
ALLOW_SHOWDIALOGS_FIX = Yv0mlf7x2VyTOQrw3GLHhE9M8pnzs
menuItemsLIST = []
SEND_THESE_EVENTS = []
SAVED_FORWARDS = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [Urj6egiVyHA75ZK(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫັ"), CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭າ"), u8iSx05wLfVyMNp1X3l(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬຳ"), J6G8X3gO1MiKh027D(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧິ"), qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ີ"), YoMw2J1Ljp(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩຶ"), YoMw2J1Ljp(u"ࠨ࡛ࡄࡕࡔ࡚ࠧື"), tzEjvOaZWU1A(u"࡙ࠩࡅࡗࡈࡏࡏຸࠩ"), aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅູࠬ"), ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࡕࡇࡎࡆࡖ຺ࠪ"), J6G8X3gO1MiKh027D(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨົ")]
BADWEBSITES += [HfuZG0aphlYnVLOyAk93rj(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧຼ"), HfuZG0aphlYnVLOyAk93rj(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪຽ"), sdRqnego9PclrL4m2J(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ຾"), wnVICNyfE3XZ0htUaDFAOgLo(u"ࠩࡗ࡚ࡋ࡛ࡎࠨ຿"), Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫເ"), Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ແ"), oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ໂ"), tzEjvOaZWU1A(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨໃ"), u8iSx05wLfVyMNp1X3l(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩໄ"), ZeV4vau9CjN(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩ໅"), XasF0WO7rDUHnEt8hAl9kLN(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫໆ")]
BADWEBSITES += [G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ໇")]
BADCOMMONIDS = [XasF0WO7rDUHnEt8hAl9kLN(u"ࠫ࠾࠿࠹࠺࠯࠼࠽࠾࠿࠭࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠴࠵࠶࠰ࠨ່"), MBS1GrwQoUlsiIRfVDOHdA(u"ࠬ࠿࠹࠹࠺࠰࠻࠼࠼࠶࠮࠷࠸࠸࠹࠳࠳࠴࠴࠵࠱࠷࠶࠸࠷້ࠩ")]
GEOLOCATION_DATA = kh850jKbzmBwY
AV_CLIENT_IDS = kh850jKbzmBwY
DNS_SERVERS = [MBS1GrwQoUlsiIRfVDOHdA(u"࠭࠱࠯࠳࠱࠵࠳࠷໊ࠧ"), NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠧ࠹࠰࠻࠲࠽࠴࠸ࠨ໋"), Urj6egiVyHA75ZK(u"ࠨ࠳࠱࠴࠳࠶࠮࠲ࠩ໌"), Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩ࠻࠲࠽࠴࠴࠯࠶ࠪໍ"), NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠸࠮࠳࠴࠵ࠫ໎"), J6G8X3gO1MiKh027D(u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠰࠯࠴࠵࠴ࠬ໏")]
busydialog_active = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
dns_succeeded_urls = []
scrapers_succeeded = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
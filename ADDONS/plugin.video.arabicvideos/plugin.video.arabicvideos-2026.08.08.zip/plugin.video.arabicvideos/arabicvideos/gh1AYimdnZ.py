# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'CIMANOW'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_CMN_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['قائمتي']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==300: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==301: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==302: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==303: PP3FsDicLyWuTR7GV5Ia = xyLG18ZqBpNfXtUM04lH(url)
	elif mode==304: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==305: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==306: PP3FsDicLyWuTR7GV5Ia = z5082rwu71V9aNOmJ()
	elif mode==309: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,309,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/home',kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<header(.*?)</header>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li><a href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,301)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	CC6NMTjSO2g(WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/home',uP1m46pAK5a3UgdqvBz9rnL)
	return uP1m46pAK5a3UgdqvBz9rnL
def z5082rwu71V9aNOmJ():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def CC6NMTjSO2g(url,uP1m46pAK5a3UgdqvBz9rnL=kh850jKbzmBwY):
	if not uP1m46pAK5a3UgdqvBz9rnL:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-SUBMENU-1st')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	dUh1Xs4tY3yE = 0
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<section>.*?</section>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
		dUh1Xs4tY3yE += 1
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for title,Zx4dc3oRLTtf0imyHjGPgDSVY5,Ga8xfYU6ht7cHjzn in items:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if title==kh850jKbzmBwY: title = 'بووووو'
			if 'em><a' not in Zx4dc3oRLTtf0imyHjGPgDSVY5:
				if ZZDUdXR52CMs9K73Ex.count('/category/')>0:
					KATelV46pvn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
					for Ga8xfYU6ht7cHjzn in KATelV46pvn:
						title = Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-2]
						EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,301)
					continue
				else: Ga8xfYU6ht7cHjzn = url+'?sequence='+str(dUh1Xs4tY3yE)
			if not any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk):
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,302)
	if not liroJ6qCK9k: bsZhnoqjD3U(url,uP1m46pAK5a3UgdqvBz9rnL)
	return
def bsZhnoqjD3U(url,uP1m46pAK5a3UgdqvBz9rnL=kh850jKbzmBwY):
	if uP1m46pAK5a3UgdqvBz9rnL==kh850jKbzmBwY:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-TITLES-1st')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if '?sequence=' in url:
		url,dUh1Xs4tY3yE = url.split('?sequence=')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(<section>.*?</section>)',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[int(dUh1Xs4tY3yE)-1]
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"posts"(.*?)</body>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	for Ga8xfYU6ht7cHjzn,data,NWqAr40jTLlMBemn3o79y in items:
		title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if title: title = title[0][2].replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if not title or title==kh850jKbzmBwY:
			title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('title">.*?</em>(.*?)<',data,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if title: title = title[0].replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if not title or title==kh850jKbzmBwY:
				title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('title">(.*?)<',data,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				title = title[0].replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		title = title.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if title not in SHTvIuhX52dxQRsWA:
			SHTvIuhX52dxQRsWA.append(title)
			c0jtBCYDEkL5HJfVX = Ga8xfYU6ht7cHjzn+data+NWqAr40jTLlMBemn3o79y
			if '/selary/' in c0jtBCYDEkL5HJfVX or 'مسلسل' in c0jtBCYDEkL5HJfVX or '"episode"' in c0jtBCYDEkL5HJfVX:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,303,NWqAr40jTLlMBemn3o79y)
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,305,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li><a href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,302)
	return
def xyLG18ZqBpNfXtUM04lH(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-SEASONS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	name = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<title>(.*?)</title>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',kh850jKbzmBwY).replace('Cima Now',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		name = name.split('الحلقة')[0].strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)+' - '
	else: name = kh850jKbzmBwY
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<section(.*?)</section>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(items)>1:
			for Ga8xfYU6ht7cHjzn,title in items:
				title = name+title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,304)
		elif len(items)==1:
			Ga8xfYU6ht7cHjzn,title = items[0]
			do7Es2fUtFlM8ScLx(Ga8xfYU6ht7cHjzn)
		else: do7Es2fUtFlM8ScLx(url)
	return
def do7Es2fUtFlM8ScLx(url):
	if '/selary/' not in url: url = url.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)+'/watching'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if '/selary/' not in url:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"episodes"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			title = 'الحلقة '+title
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,305)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"details"(.*?)"related"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,305,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	jj7q4FIVKmbMslTYenwyuGr1gL = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="shine" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if jj7q4FIVKmbMslTYenwyuGr1gL:
		fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(jj7q4FIVKmbMslTYenwyuGr1gL[0],'url')
		headers = {'Referer':fDKF4iZ5rz7McduTexbA2RpPs}
	else: headers = kh850jKbzmBwY
	O9wzaDlICnq = url+'watching/'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'CIMANOW-PLAY-5th')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	lnYtOIQ4Rkh386Bca7 = []
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"download"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</i>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			sYm5r9QKRfjoytO = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('\d\d\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if sYm5r9QKRfjoytO:
				sYm5r9QKRfjoytO = '____'+sYm5r9QKRfjoytO[0]
				title = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
			else: sYm5r9QKRfjoytO = kh850jKbzmBwY
			jQOlvATLDcdquxVXaJib3Yo5 = Ga8xfYU6ht7cHjzn+'?named='+title+'__download'+sYm5r9QKRfjoytO
			lnYtOIQ4Rkh386Bca7.append(jQOlvATLDcdquxVXaJib3Yo5)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"watch"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"embed".*?src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn in Sp6qOyDB0nt5Qo4KwbPfcWYe:
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
			title = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__embed'
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
		Sp6qOyDB0nt5Qo4KwbPfcWYe = [WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/wp-content/themes/Cima%20Now%20New/core.php']
		if Sp6qOyDB0nt5Qo4KwbPfcWYe:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for CCb3sqcILQHYeMzR,id,title in items:
				title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				Ga8xfYU6ht7cHjzn = Sp6qOyDB0nt5Qo4KwbPfcWYe[0]+'?action=switch&index='+CCb3sqcILQHYeMzR+'&id='+id+'?named='+title+'__watch'
				lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/?s='+search
	bsZhnoqjD3U(url)
	return
﻿# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'ALMAAREF'
headers = {'User-Agent':kh850jKbzmBwY}
GalrcVUMy8bzORWX5E0exhYivBwgk = '_MRF_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text,QPZDaMKgtTUyNjB7EqvOLwph):
	if   mode==40: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==41: PP3FsDicLyWuTR7GV5Ia = r1GaLwhMA3()
	elif mode==42: PP3FsDicLyWuTR7GV5Ia = mSAiZd8bTwtBGysLj(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==43: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==44: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==49: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,49)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+'البث الحي لقناة المعارف',kh850jKbzmBwY,41)
	mSAiZd8bTwtBGysLj(kh850jKbzmBwY,'1')
	return
def R8jvhiNcVEguQ3(kFdoZmlxSf8shU,fHDpST1WvjX48AdVGkJOeP2tlENbq3):
	search,sort,RRzFJb0tuU,XvPwmy3axVdD6NIKGb4Ak,shrl07KS5ULfwvaNbXWo = kh850jKbzmBwY,[],[],[],[]
	W7BTt4f3CkhKJIY,AAoiZlrmTc = kIX1R7uhneTmEWoL(kFdoZmlxSf8shU)
	for OSvbC40RHt2AWY in list(AAoiZlrmTc.keys()):
		value = AAoiZlrmTc[OSvbC40RHt2AWY]
		if not value: continue
		if   OSvbC40RHt2AWY=='sort': sort = [value]
		elif OSvbC40RHt2AWY=='series': RRzFJb0tuU = [value]
		elif OSvbC40RHt2AWY=='search': search = value
		elif OSvbC40RHt2AWY=='category': XvPwmy3axVdD6NIKGb4Ak = [value]
		elif OSvbC40RHt2AWY=='specialist': shrl07KS5ULfwvaNbXWo = [value]
	K83xkHbNteiq7RnvgFSL0foXO92EmW = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":XvPwmy3axVdD6NIKGb4Ak,"specialist":shrl07KS5ULfwvaNbXWo,"series":RRzFJb0tuU,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(fHDpST1WvjX48AdVGkJOeP2tlENbq3)}}
	K83xkHbNteiq7RnvgFSL0foXO92EmW = vDVykQSI8dwipbZuJmG31RO7l6h.dumps(K83xkHbNteiq7RnvgFSL0foXO92EmW)
	Ga8xfYU6ht7cHjzn = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'POST',Ga8xfYU6ht7cHjzn,K83xkHbNteiq7RnvgFSL0foXO92EmW,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	data = tmYCsS329HanzjLFbJP('dict',uP1m46pAK5a3UgdqvBz9rnL)
	return data
def mSAiZd8bTwtBGysLj(kFdoZmlxSf8shU,level):
	tKoDYsOPeyxM = R8jvhiNcVEguQ3(kFdoZmlxSf8shU,'1')
	ZZDUdXR52CMs9K73Ex = tKoDYsOPeyxM['facets']
	if level=='1':
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex['video_categories']
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<div(.*?)/div>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for JJNIsO8Vcbx0 in items:
			VBzUkECjaup0d9QSc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',JJNIsO8Vcbx0+'<',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if not VBzUkECjaup0d9QSc: VBzUkECjaup0d9QSc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-value=\\"(.*?)\\">(.*?)<',JJNIsO8Vcbx0+'<',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			XvPwmy3axVdD6NIKGb4Ak,title = VBzUkECjaup0d9QSc[0]
			if BBJYzRKgHkOqx: title = Z4CP1xs5w7fi(title)
			if not kFdoZmlxSf8shU: EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,42,kh850jKbzmBwY,'2','?category='+XvPwmy3axVdD6NIKGb4Ak)
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,42,kh850jKbzmBwY,'2',kFdoZmlxSf8shU+'&category='+XvPwmy3axVdD6NIKGb4Ak)
	if level=='2':
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex['specialist']
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('value="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for shrl07KS5ULfwvaNbXWo,title in items:
			if BBJYzRKgHkOqx: title = Z4CP1xs5w7fi(title)
			if not shrl07KS5ULfwvaNbXWo: title = title = 'الجميع'
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,42,kh850jKbzmBwY,'3',kFdoZmlxSf8shU+'&specialist='+shrl07KS5ULfwvaNbXWo)
	elif level=='3':
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex['series']
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('value="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for RRzFJb0tuU,title in items:
			if BBJYzRKgHkOqx: title = Z4CP1xs5w7fi(title)
			if not RRzFJb0tuU: title = title = 'الجميع'
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,42,kh850jKbzmBwY,'4',kFdoZmlxSf8shU+'&series='+RRzFJb0tuU)
	elif level=='4':
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex['sort_video']
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('value="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for sort,title in items:
			if not sort: continue
			if BBJYzRKgHkOqx: title = Z4CP1xs5w7fi(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,44,kh850jKbzmBwY,'1',kFdoZmlxSf8shU+'&sort='+sort)
	return
def bsZhnoqjD3U(kFdoZmlxSf8shU,fHDpST1WvjX48AdVGkJOeP2tlENbq3):
	tKoDYsOPeyxM = R8jvhiNcVEguQ3(kFdoZmlxSf8shU,fHDpST1WvjX48AdVGkJOeP2tlENbq3)
	ZZDUdXR52CMs9K73Ex = tKoDYsOPeyxM['template']
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		if BBJYzRKgHkOqx: title = Z4CP1xs5w7fi(title)
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,43,NWqAr40jTLlMBemn3o79y)
	ZZDUdXR52CMs9K73Ex = tKoDYsOPeyxM['facets']['pagination']
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-page="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for QPZDaMKgtTUyNjB7EqvOLwph,title in items:
		if fHDpST1WvjX48AdVGkJOeP2tlENbq3==QPZDaMKgtTUyNjB7EqvOLwph: continue
		if BBJYzRKgHkOqx: title = Z4CP1xs5w7fi(title)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,kh850jKbzmBwY,44,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,kFdoZmlxSf8shU)
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'ALMAAREF-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<video src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('youtube_url.*?(http.*?)&',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	owMxje0p9Ya3CkhJDX = []
	if Ga8xfYU6ht7cHjzn:
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0].replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def r1GaLwhMA3():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/البث-المباشر-6',kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'ALMAAREF-LIVE-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	url = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-item=.*?(http.*?)&',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	url = url[0].replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	NRlCaq1ndM(url,vkNGie5mhCqoTFRzPKaML0x6,'live')
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	bbr6FME1N5fGueC = False
	if search==kh850jKbzmBwY:
		search = GG5Fs0hvURxyBV8gz()
		bbr6FME1N5fGueC = True
	if search==kh850jKbzmBwY: return
	if not bbr6FME1N5fGueC: bsZhnoqjD3U('?search='+search,'1')
	else: mSAiZd8bTwtBGysLj('?search='+search,'1')
	return
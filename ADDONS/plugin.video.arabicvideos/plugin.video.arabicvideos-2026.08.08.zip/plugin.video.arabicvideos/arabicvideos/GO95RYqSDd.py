# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SHAHIDNEWS'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SHN_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['قنوات فضائية', 'فارسكو', 'Show more', 'موقع عرب سيد', 'قصة عشق']
def Z6V4AKYFUSWMmqBNXJ72p(mode, url, text):
    if mode == 580: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
    elif mode == 581: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url, text)
    elif mode == 582: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
    elif mode == 583: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url, text)
    elif mode == 584: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
    elif mode == 589: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
    else: PP3FsDicLyWuTR7GV5Ia = False
    return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', WLjaXVNk2dnAJzPpy6OlMv4qoi9, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHIDNEWS-MENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'بحث في الموقع', kh850jKbzmBwY, 589, kh850jKbzmBwY, kh850jKbzmBwY, '_REMEMBERRESULTS_')
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"navslide-divider"(.*?)"navslide-divider"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("'dropdown-menu'(.*?)</ul>", uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    for c0jtBCYDEkL5HJfVX in liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace(c0jtBCYDEkL5HJfVX, kh850jKbzmBwY)
    items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    for Ga8xfYU6ht7cHjzn, title in items:
        if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
        EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 584)
    return
def CC6NMTjSO2g(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHIDNEWS-SUBMENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if NSUBGjzyZh5xaKL9AJF:
        ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
        ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"presentation"', '</ul>')
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"dropdown-header">(.*?)</li>(.*?)</ul>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if not liroJ6qCK9k: liroJ6qCK9k = [(kh850jKbzmBwY, ZZDUdXR52CMs9K73Ex)]
        EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' فرز أو فلتر أو ترتيب ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
        for JLngAu1qYhtXm0BNr, ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            if JLngAu1qYhtXm0BNr: JLngAu1qYhtXm0BNr = JLngAu1qYhtXm0BNr + ': '
            for Ga8xfYU6ht7cHjzn, title in items:
                title = JLngAu1qYhtXm0BNr + title
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 581)
    oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-category-subcats"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if oQuiJvtTzwPZbXd7sf4HcG9:
        ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if len(items) < 30:
            EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
            for Ga8xfYU6ht7cHjzn, title in items:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 581)
    if not NSUBGjzyZh5xaKL9AJF and not oQuiJvtTzwPZbXd7sf4HcG9: bsZhnoqjD3U(url)
    return
def bsZhnoqjD3U(url, jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
    giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url, 'url')
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHIDNEWS-TITLES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    items = []
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(data-echo=".*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"BlocksList"(.*?)"titleSectionCon"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="pm-grid"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="pm-related"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k: return
    ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    SHTvIuhX52dxQRsWA = []
    fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة', 'فيلم', 'اغنية', 'كليب', 'اعلان', 'هداف', 'مباراة', 'عرض', 'مهرجان', 'البوم', 'مسرحية']
    for NWqAr40jTLlMBemn3o79y, Ga8xfYU6ht7cHjzn, title in items:
        Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn).strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
        if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
        if 'http' not in NWqAr40jTLlMBemn3o79y: NWqAr40jTLlMBemn3o79y = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + NWqAr40jTLlMBemn3o79y.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
        WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة \d+', title, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
            EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 582, NWqAr40jTLlMBemn3o79y)
        elif WULSmfNH09tPIv58snzpCkR and 'الحلقة' in title:
            title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
            if title not in SHTvIuhX52dxQRsWA:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 583, NWqAr40jTLlMBemn3o79y)
                SHTvIuhX52dxQRsWA.append(title)
        elif '/movseries/' in Ga8xfYU6ht7cHjzn:
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 581, NWqAr40jTLlMBemn3o79y)
        else:
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 583, NWqAr40jTLlMBemn3o79y)
    if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG not in ['featured_movies', 'featured_series']:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title in items:
                if Ga8xfYU6ht7cHjzn == '#': continue
                Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
                title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 581)
        QWK6fmVB8eAjab = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('showmore" href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if QWK6fmVB8eAjab:
            Ga8xfYU6ht7cHjzn = QWK6fmVB8eAjab[0]
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'مشاهدة المزيد', Ga8xfYU6ht7cHjzn, 581)
    return
def do7Es2fUtFlM8ScLx(url, GGy6r8KUN0WjnqoTR):
    giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url, 'url')
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHIDNEWS-EPISODES-2nd')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('nav-seasons"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    items = []
    gFthaolRMw = False
    if NSUBGjzyZh5xaKL9AJF and not GGy6r8KUN0WjnqoTR:
        ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for GGy6r8KUN0WjnqoTR, title in items:
            GGy6r8KUN0WjnqoTR = GGy6r8KUN0WjnqoTR.strip('#')
            if len(items) > 1: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, url, 583, kh850jKbzmBwY, kh850jKbzmBwY, GGy6r8KUN0WjnqoTR)
            else: gFthaolRMw = True
    else: gFthaolRMw = True
    oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="' + GGy6r8KUN0WjnqoTR + '"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if oQuiJvtTzwPZbXd7sf4HcG9 and gFthaolRMw:
        ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if items:
            for Ga8xfYU6ht7cHjzn, title in items:
                Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
                EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 582)
        else:
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title, NWqAr40jTLlMBemn3o79y in items:
                if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
                EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 582)
    return
def yv8LezRQifhw1Kx(url):
    giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url, 'url')
    lnYtOIQ4Rkh386Bca7 = []
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHIDNEWS-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"Playerholder".*?href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
    if Ga8xfYU6ht7cHjzn and 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:' + Ga8xfYU6ht7cHjzn
    g5gTIZNUBP7Mpjf4cm9LCl = Ga8xfYU6ht7cHjzn.split('hash=')[1]
    VQfK9Lr0j75zHwg1xOGY = g5gTIZNUBP7Mpjf4cm9LCl.split('__')
    EGumWYO5Fjl4sAtHchPev68KDk, Sp6qOyDB0nt5Qo4KwbPfcWYe, title = kh850jKbzmBwY, [], kh850jKbzmBwY
    for omfXkuRP6QsITcL9WAbFS25pw in VQfK9Lr0j75zHwg1xOGY:
        n5slqKkOy7f0eW48YLizBm = ((4 - len(omfXkuRP6QsITcL9WAbFS25pw) % 4) % 4) * '='
        try:
            omfXkuRP6QsITcL9WAbFS25pw = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(omfXkuRP6QsITcL9WAbFS25pw + n5slqKkOy7f0eW48YLizBm)
            if eOQJrvLAZC: omfXkuRP6QsITcL9WAbFS25pw = omfXkuRP6QsITcL9WAbFS25pw.decode(NVbhZ0DTpOkCA, 'ignore')
        except:
            pass
        EGumWYO5Fjl4sAtHchPev68KDk += omfXkuRP6QsITcL9WAbFS25pw
    EGumWYO5Fjl4sAtHchPev68KDk = EGumWYO5Fjl4sAtHchPev68KDk.replace(' = ', ' => ')
    xxhwvPqM2RtBYcNom7QWAsSfjI = EGumWYO5Fjl4sAtHchPev68KDk.splitlines()
    for Ga8xfYU6ht7cHjzn in xxhwvPqM2RtBYcNom7QWAsSfjI:
        if '://' in Ga8xfYU6ht7cHjzn: Sp6qOyDB0nt5Qo4KwbPfcWYe.append(Ga8xfYU6ht7cHjzn)
    for Ga8xfYU6ht7cHjzn in Sp6qOyDB0nt5Qo4KwbPfcWYe:
        if ' => ' in Ga8xfYU6ht7cHjzn: title, Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split(' => ')
        elif 'http' in Ga8xfYU6ht7cHjzn:
            title, Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('http')
            Ga8xfYU6ht7cHjzn = 'http' + Ga8xfYU6ht7cHjzn
        else:
            continue
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.strip(' ')
        if not title: title = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn, 'name')
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__watch'
        lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def dStQzEeyknDaOs7q(search):
    search, kFdoZmlxSf8shU, showDialogs = gCI13c7MdXA8(search)
    if search == kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
    if search == kh850jKbzmBwY: return
    search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF, '+')
    url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search.php?keywords=' + search
    bsZhnoqjD3U(url)
    return
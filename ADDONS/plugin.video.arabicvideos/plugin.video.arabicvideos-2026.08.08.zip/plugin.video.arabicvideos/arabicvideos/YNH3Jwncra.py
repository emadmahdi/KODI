# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'EGYNOW'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_EGN_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==430: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==431: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==432: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==433: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==434: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==437: PP3FsDicLyWuTR7GV5Ia = Qd6OnrkNEhTtq3AeVLJZPU1XWMw(url)
	elif mode==439: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/films',kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	giRfrJxZdQ16bw2oe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"canonical" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	giRfrJxZdQ16bw2oe = giRfrJxZdQ16bw2oe[0].strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(giRfrJxZdQ16bw2oe,'url')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,439,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر محدد',giRfrJxZdQ16bw2oe,435)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر كامل',giRfrJxZdQ16bw2oe,434)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المضاف حديثا',giRfrJxZdQ16bw2oe,431)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'افلام اون لاين',giRfrJxZdQ16bw2oe+'/films1',436)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات اون لاين',giRfrJxZdQ16bw2oe+'/series-all1',436)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'قائمة تفصيلية',giRfrJxZdQ16bw2oe,437)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"SiteNavigation"(.*?)"Search"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,431)
	return
def Qd6OnrkNEhTtq3AeVLJZPU1XWMw(website=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',website+'/films',kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	giRfrJxZdQ16bw2oe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"canonical" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	giRfrJxZdQ16bw2oe = giRfrJxZdQ16bw2oe[0].strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(giRfrJxZdQ16bw2oe,'url')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"ListDroped"(.*?)"SearchingMaster"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for XvPwmy3axVdD6NIKGb4Ak,value,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		Ga8xfYU6ht7cHjzn = website+'/explore/?'+XvPwmy3axVdD6NIKGb4Ak+'='+value
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,431)
	return
def CC6NMTjSO2g(url):
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-SUBMENU-1st')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',url,431)
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"titleSectionCon"(.*?)</div></div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-key="(.*?)".*?<em>(.*?)</em>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for JjH8Zr42QL5AnsweEIRxltWcp,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		O9wzaDlICnq = giRfrJxZdQ16bw2oe+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+JjH8Zr42QL5AnsweEIRxltWcp
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,O9wzaDlICnq,431)
	return
def bsZhnoqjD3U(url,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		O9wzaDlICnq,hhUDZA3piIJyMsxfbgGdWO = kIX1R7uhneTmEWoL(url)
		tqQkcdHYyM3L7h = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'POST',O9wzaDlICnq,hhUDZA3piIJyMsxfbgGdWO,tqQkcdHYyM3L7h,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-TITLES-1st')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured':
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-TITLES-2nd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"MainSlider"(.*?)"MatchesTable"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a href="([^"]*)" title="([^"]*)".*?image: url\((.*?)\)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-TITLES-2nd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"BlocksList"(.*?)"Paginate"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"BlocksList"(.*?)"titleSectionCon"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<a href="([^"]*)" title="([^"]*)".*?data-image="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in items:
		Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn).strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,432,NWqAr40jTLlMBemn3o79y)
		elif WULSmfNH09tPIv58snzpCkR and 'الحلقة' in title:
			title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,433,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		elif '/movseries/' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,431,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,433,NWqAr40jTLlMBemn3o79y)
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG!='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"Paginate"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+Ga8xfYU6ht7cHjzn
				Ga8xfYU6ht7cHjzn = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(Ga8xfYU6ht7cHjzn)
				title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				if title!=kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,431)
		QWK6fmVB8eAjab = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('showmore" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if QWK6fmVB8eAjab:
			Ga8xfYU6ht7cHjzn = QWK6fmVB8eAjab[0]
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مشاهدة المزيد',Ga8xfYU6ht7cHjzn,431)
	return
def do7Es2fUtFlM8ScLx(url):
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	NSUBGjzyZh5xaKL9AJF,oQuiJvtTzwPZbXd7sf4HcG9 = [],[]
	if 'Episodes.php' in url:
		O9wzaDlICnq,hhUDZA3piIJyMsxfbgGdWO = kIX1R7uhneTmEWoL(url)
		tqQkcdHYyM3L7h = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'POST',O9wzaDlICnq,hhUDZA3piIJyMsxfbgGdWO,tqQkcdHYyM3L7h,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-EPISODES-1st')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		oQuiJvtTzwPZbXd7sf4HcG9 = [uP1m46pAK5a3UgdqvBz9rnL]
	else:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-EPISODES-2nd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"SeasonsList"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"EpisodesList"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if NSUBGjzyZh5xaKL9AJF:
		NWqAr40jTLlMBemn3o79y = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"og:image" content="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y[0]
		ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for LsgQIK6E08od3r5,U7g3QDyz0Fmvil4xG6XThqS,title in items:
			Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+U7g3QDyz0Fmvil4xG6XThqS+'&post_id='+LsgQIK6E08od3r5
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,433,NWqAr40jTLlMBemn3o79y)
	elif oQuiJvtTzwPZbXd7sf4HcG9:
		NWqAr40jTLlMBemn3o79y = ppNwDFByU1dZn5ca.getInfoLabel('ListItem.Thumb')
		ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,WULSmfNH09tPIv58snzpCkR in items:
			title = title+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+WULSmfNH09tPIv58snzpCkR
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,432,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	O9wzaDlICnq = url+'/watch/'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	lnYtOIQ4Rkh386Bca7 = []
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(O9wzaDlICnq,'url')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"container-servers"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		N96VzWobDawRQEik5t3B = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-id="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if N96VzWobDawRQEik5t3B:
			N96VzWobDawRQEik5t3B = N96VzWobDawRQEik5t3B[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-server="(.*?)".*?<span>(.*?)</span>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for fDKF4iZ5rz7McduTexbA2RpPs,title in items:
				Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+fDKF4iZ5rz7McduTexbA2RpPs+'&post_id='+N96VzWobDawRQEik5t3B+'?named='+title+'__watch'
				lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	g96suaJPE4Kq8N = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"container-iframe"><iframe src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if g96suaJPE4Kq8N:
		g96suaJPE4Kq8N = g96suaJPE4Kq8N[0].replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY)
		title = hBRWs4K6t1nderkNEQo7bIvCFuZfS(g96suaJPE4Kq8N,'name')
		Ga8xfYU6ht7cHjzn = g96suaJPE4Kq8N+'?named='+title+'__embed'
		lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"container-download"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,sYm5r9QKRfjoytO in items:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY)
			if sYm5r9QKRfjoytO!=kh850jKbzmBwY: sYm5r9QKRfjoytO = '____'+sYm5r9QKRfjoytO
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__download'+sYm5r9QKRfjoytO
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?s='+search
	bsZhnoqjD3U(url)
	return
def vgP862NBF4UG(url):
	url = url.split('/smartemadfilter?')[0]
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',giRfrJxZdQ16bw2oe,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('("dropdown-button".*?)"SearchingMaster"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	deib7XxUZCQw8HA1n = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	return deib7XxUZCQw8HA1n
def OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex):
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-term="(\d+)" data-name="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	return items
def bF2piHrjYeOC7uxPz(url):
	gdGWEPpk3frFTQa8wcYhqMyV4 = url.split('/smartemadfilter?')[0]
	jjEqDAJkvVXK5WdC0xSGR2m = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	url = url.replace(gdGWEPpk3frFTQa8wcYhqMyV4,jjEqDAJkvVXK5WdC0xSGR2m)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def CWvUl98PQhyqeDOptjsz3(oufZ8U7XLDFy4b,url):
	PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(oufZ8U7XLDFy4b,'modified_filters')
	QQJdiByEeNqLYGs = url+'/smartemadfilter?'+PhFd0yvXWULQIfu9N2pSYDRCx
	QQJdiByEeNqLYGs = bF2piHrjYeOC7uxPz(QQJdiByEeNqLYGs)
	return QQJdiByEeNqLYGs
XXSxywJDNdUneWclbfI7 = ['category','country','genre','release-year']
vKwTaOAiBIbCjhdJktHeuMyWz8 = ['quality','release-year','genre','category','language','country']
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==kh850jKbzmBwY: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = kh850jKbzmBwY,kh850jKbzmBwY
	else: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if XXSxywJDNdUneWclbfI7[0]+'=' not in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[0]
		for asKYTS478qkW in range(len(XXSxywJDNdUneWclbfI7[0:-1])):
			if XXSxywJDNdUneWclbfI7[asKYTS478qkW]+'=' in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[asKYTS478qkW+1]
		oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ.strip('&')+'___'+oufZ8U7XLDFy4b.strip('&')
		PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		O9wzaDlICnq = url+'/smartemadfilter?'+PhFd0yvXWULQIfu9N2pSYDRCx
	elif type=='ALL_ITEMS_FILTER':
		FCyjlpcBn5OG2Nowxvf6WQS74 = Md2htF3Gi186nWlYkJq(WQEFAlL7oCZ3XBt,'modified_values')
		FCyjlpcBn5OG2Nowxvf6WQS74 = KsuzxGjOHChbIXrwWm(FCyjlpcBn5OG2Nowxvf6WQS74)
		if CW52XnyslubD60Y4LNHp3hzZ9VP8!=kh850jKbzmBwY: CW52XnyslubD60Y4LNHp3hzZ9VP8 = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		if CW52XnyslubD60Y4LNHp3hzZ9VP8==kh850jKbzmBwY: O9wzaDlICnq = url
		else: O9wzaDlICnq = url+'/smartemadfilter?'+CW52XnyslubD60Y4LNHp3hzZ9VP8
		O9wzaDlICnq = bF2piHrjYeOC7uxPz(O9wzaDlICnq)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أظهار قائمة الفيديو التي تم اختيارها ',O9wzaDlICnq,431)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+' [[   '+FCyjlpcBn5OG2Nowxvf6WQS74+'   ]]',O9wzaDlICnq,431)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	deib7XxUZCQw8HA1n = vgP862NBF4UG(url)
	dict = {}
	for name,ZZDUdXR52CMs9K73Ex,uHwkOpvAPM3bqC72KZstX in deib7XxUZCQw8HA1n:
		name = name.replace('--',kh850jKbzmBwY)
		items = OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex)
		if '=' not in O9wzaDlICnq: O9wzaDlICnq = url
		if type=='SPECIFIED_FILTER':
			if XvPwmy3axVdD6NIKGb4Ak!=uHwkOpvAPM3bqC72KZstX: continue
			elif len(items)<2:
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]:
					url = bF2piHrjYeOC7uxPz(url)
					bsZhnoqjD3U(url)
				else: cf9bnl3ZAhJLt24qxIFwGzuNsMi(O9wzaDlICnq,'SPECIFIED_FILTER___'+mDAEOKl2SQpv71acI4PJj5Hs9XzT)
				return
			else:
				O9wzaDlICnq = bF2piHrjYeOC7uxPz(O9wzaDlICnq)
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع ',O9wzaDlICnq,431)
				else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع ',O9wzaDlICnq,435,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		elif type=='ALL_ITEMS_FILTER':
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع :'+name,O9wzaDlICnq,434,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		dict[uHwkOpvAPM3bqC72KZstX] = {}
		for value,OSvbC40RHt2AWY in items:
			if value=='196533': OSvbC40RHt2AWY = 'أفلام نيتفلكس'
			elif value=='196531': OSvbC40RHt2AWY = 'مسلسلات نيتفلكس'
			if OSvbC40RHt2AWY in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			dict[uHwkOpvAPM3bqC72KZstX][value] = OSvbC40RHt2AWY
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'='+OSvbC40RHt2AWY
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'='+value
			qCdAhU0NW12mBS9neTQgwi = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			title = OSvbC40RHt2AWY+' :'#+dict[uHwkOpvAPM3bqC72KZstX]['0']
			title = OSvbC40RHt2AWY+' :'+name
			if type=='ALL_ITEMS_FILTER': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,434,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
			elif type=='SPECIFIED_FILTER' and XXSxywJDNdUneWclbfI7[-2]+'=' in WQEFAlL7oCZ3XBt:
				QQJdiByEeNqLYGs = CWvUl98PQhyqeDOptjsz3(oufZ8U7XLDFy4b,url)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,QQJdiByEeNqLYGs,431)
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,435,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
	return
def Md2htF3Gi186nWlYkJq(T3IPgzYmNnC9tkupohdRj2Qf,mode):
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.replace('=&','=0&')
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.strip('&')
	yXeoduEjYKJLf0OinrlVzN3 = {}
	if '=' in T3IPgzYmNnC9tkupohdRj2Qf:
		items = T3IPgzYmNnC9tkupohdRj2Qf.split('&')
		for JJNIsO8Vcbx0 in items:
			moT0kOcKq7JPVSt3L,value = JJNIsO8Vcbx0.split('=')
			yXeoduEjYKJLf0OinrlVzN3[moT0kOcKq7JPVSt3L] = value
	jjSBkesYpFQc6A1q8RfVJgW = kh850jKbzmBwY
	for key in vKwTaOAiBIbCjhdJktHeuMyWz8:
		if key in list(yXeoduEjYKJLf0OinrlVzN3.keys()): value = yXeoduEjYKJLf0OinrlVzN3[key]
		else: value = '0'
		if '%' not in value: value = ioZ083zxYk(value)
		if mode=='modified_values' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+' + '+value
		elif mode=='modified_filters' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
		elif mode=='all_filters': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip(' + ')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip('&')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.replace('=0','=')
	return jjSBkesYpFQc6A1q8RfVJgW
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'IFILM'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_IFL_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
d0hVTC6pXnNEwLqm4zbt3x = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][1]
dwmfrA3kVjbRU7KMaqCEBXYx9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][2]
gsqoO8eRhFYryKW = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][3]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,QPZDaMKgtTUyNjB7EqvOLwph,text):
	if   mode==20: PP3FsDicLyWuTR7GV5Ia = bbTlg7fPxE6QkBwydoAGeXi2WqHSs()
	elif mode==21: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc(url)
	elif mode==22: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==23: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==24: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url,text)
	elif mode==25: PP3FsDicLyWuTR7GV5Ia = geCYu9DK40y6UXhfSPHaqp5b73z(url)
	elif mode==27: PP3FsDicLyWuTR7GV5Ia = r1GaLwhMA3(url)
	elif mode==28: PP3FsDicLyWuTR7GV5Ia = gvH7r1jsWhy0()
	elif mode==29: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def bbTlg7fPxE6QkBwydoAGeXi2WqHSs():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'عربي',WLjaXVNk2dnAJzPpy6OlMv4qoi9,21,kh850jKbzmBwY,'101')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'English',d0hVTC6pXnNEwLqm4zbt3x,21,kh850jKbzmBwY,'101')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فارسى',dwmfrA3kVjbRU7KMaqCEBXYx9,21,kh850jKbzmBwY,'101')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فارسى 2',gsqoO8eRhFYryKW,21,kh850jKbzmBwY,'101')
	return
def gvH7r1jsWhy0():
	EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+'عربي',WLjaXVNk2dnAJzPpy6OlMv4qoi9,27)
	EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+'English',d0hVTC6pXnNEwLqm4zbt3x,27)
	EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+'فارسى',dwmfrA3kVjbRU7KMaqCEBXYx9,27)
	EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+'فارسى 2',gsqoO8eRhFYryKW,27)
	return
def ohG2UpvdmfAxONbuc(maOcdN9C2IqDWbGZwhKMn):
	vkNGie5mhCqoTFRzPKaML0x6 = maOcdN9C2IqDWbGZwhKMn
	if maOcdN9C2IqDWbGZwhKMn=='IFILM-ARABIC': maOcdN9C2IqDWbGZwhKMn = WLjaXVNk2dnAJzPpy6OlMv4qoi9
	elif maOcdN9C2IqDWbGZwhKMn=='IFILM-ENGLISH': maOcdN9C2IqDWbGZwhKMn = d0hVTC6pXnNEwLqm4zbt3x
	else: vkNGie5mhCqoTFRzPKaML0x6 = kh850jKbzmBwY
	i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(maOcdN9C2IqDWbGZwhKMn)
	if i5HfSMmVOeAJPvI=='ar' or vkNGie5mhCqoTFRzPKaML0x6=='IFILM-ARABIC':
		dz9WceRH3Y = 'بحث في الموقع'
		FEGJjiSZXB5pNV = 'مسلسلات - حالية'
		tVNeLEOXQU1osj = 'مسلسلات - أحدث'
		bg5txl14r2nR8padu = 'مسلسلات - أبجدي'
		nDI9Wbr7oBcjOfSwuGhRktvFCmea = 'بث حي آي فيلم'
		EmPXAn1wRMxFpds7yojc0aelGKqZ8 = 'أفلام'
		eBfpvXVSFJEs0wrmjDiPC = 'موسيقى'
		Un5St1MBCAJ6 = 'برامج'
	elif i5HfSMmVOeAJPvI=='en' or vkNGie5mhCqoTFRzPKaML0x6=='IFILM-ENGLISH':
		dz9WceRH3Y = 'Search in site'
		FEGJjiSZXB5pNV = 'Series - Current'
		tVNeLEOXQU1osj = 'Series - Latest'
		bg5txl14r2nR8padu = 'Series - Alphabet'
		nDI9Wbr7oBcjOfSwuGhRktvFCmea = 'Live iFilm channel'
		EmPXAn1wRMxFpds7yojc0aelGKqZ8 = 'Movies'
		eBfpvXVSFJEs0wrmjDiPC = 'Music'
		Un5St1MBCAJ6 = 'Shows'
	elif i5HfSMmVOeAJPvI in ['fa','fa2']:
		dz9WceRH3Y = 'جستجو در سایت'
		FEGJjiSZXB5pNV = 'سريال - جاری'
		tVNeLEOXQU1osj = 'سريال - آخرین'
		bg5txl14r2nR8padu = 'سريال - الفبا'
		nDI9Wbr7oBcjOfSwuGhRktvFCmea = 'پخش زنده اي فيلم'
		EmPXAn1wRMxFpds7yojc0aelGKqZ8 = 'فيلم'
		eBfpvXVSFJEs0wrmjDiPC = 'موسيقى'
		Un5St1MBCAJ6 = 'برنامه ها'
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+dz9WceRH3Y,maOcdN9C2IqDWbGZwhKMn,29,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('live',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+nDI9Wbr7oBcjOfSwuGhRktvFCmea,maOcdN9C2IqDWbGZwhKMn,27)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	MBq6IdsKJ9z21Z = ['Series','Program','Music']
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,maOcdN9C2IqDWbGZwhKMn+'/home',kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-MENU-1st')
	liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('button-menu(.*?)/Contact',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if any(value in Ga8xfYU6ht7cHjzn for value in MBq6IdsKJ9z21Z):
				url = maOcdN9C2IqDWbGZwhKMn+Ga8xfYU6ht7cHjzn
				if 'Series' in Ga8xfYU6ht7cHjzn:
					EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+FEGJjiSZXB5pNV,url,22,kh850jKbzmBwY,'100')
					EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+tVNeLEOXQU1osj,url,22,kh850jKbzmBwY,'101')
					EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+bg5txl14r2nR8padu,url,22,kh850jKbzmBwY,'201')
				elif 'Film' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+EmPXAn1wRMxFpds7yojc0aelGKqZ8,url,22,kh850jKbzmBwY,'100')
				elif 'Music' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+eBfpvXVSFJEs0wrmjDiPC,url,25,kh850jKbzmBwY,'101')
				elif 'Program' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+Un5St1MBCAJ6,url,22,kh850jKbzmBwY,'101')
	return uP1m46pAK5a3UgdqvBz9rnL
def geCYu9DK40y6UXhfSPHaqp5b73z(url):
	maOcdN9C2IqDWbGZwhKMn = ZHUbeK76dXMx(url)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-MUSIC_MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('Music-tools-header(.*?)Music-body',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<p>(.*?)</p>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,22,kh850jKbzmBwY,'101')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		Ga8xfYU6ht7cHjzn = maOcdN9C2IqDWbGZwhKMn + Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,23,kh850jKbzmBwY,'101')
	return
def bsZhnoqjD3U(url,QPZDaMKgtTUyNjB7EqvOLwph):
	maOcdN9C2IqDWbGZwhKMn = ZHUbeK76dXMx(url)
	i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(url)
	type = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
	dZHSEUJukoILPpQqOK0l = str(int(QPZDaMKgtTUyNjB7EqvOLwph)//100)
	QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)%100)
	if type=='Series' and QPZDaMKgtTUyNjB7EqvOLwph=='0':
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-TITLES-1st')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('serial-body(.*?)class="row',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			title = Z4CP1xs5w7fi(title)
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			Ga8xfYU6ht7cHjzn = maOcdN9C2IqDWbGZwhKMn + Ga8xfYU6ht7cHjzn
			NWqAr40jTLlMBemn3o79y = maOcdN9C2IqDWbGZwhKMn + ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,23,NWqAr40jTLlMBemn3o79y,dZHSEUJukoILPpQqOK0l+'01')
	uuyBj5CPAf1XDZ=0
	if type=='Series': XvPwmy3axVdD6NIKGb4Ak='3'
	if type=='Film': XvPwmy3axVdD6NIKGb4Ak='5'
	if type=='Program': XvPwmy3axVdD6NIKGb4Ak='7'
	if type in ['Series','Program','Film'] and QPZDaMKgtTUyNjB7EqvOLwph!='0':
		O9wzaDlICnq = maOcdN9C2IqDWbGZwhKMn+'/Home/PageingItem?category='+XvPwmy3axVdD6NIKGb4Ak+'&page='+QPZDaMKgtTUyNjB7EqvOLwph+'&size=30&orderby='+dZHSEUJukoILPpQqOK0l
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-TITLES-2nd')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for id,title,NWqAr40jTLlMBemn3o79y in items:
			title = Z4CP1xs5w7fi(title)
			title = title.replace('\\',kh850jKbzmBwY)
			title = title.replace('"',kh850jKbzmBwY)
			uuyBj5CPAf1XDZ += 1
			Ga8xfYU6ht7cHjzn = maOcdN9C2IqDWbGZwhKMn + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + type + '/Content/' + id
			NWqAr40jTLlMBemn3o79y = maOcdN9C2IqDWbGZwhKMn + ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
			if type=='Film': EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,24,NWqAr40jTLlMBemn3o79y,dZHSEUJukoILPpQqOK0l+'01')
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,23,NWqAr40jTLlMBemn3o79y,dZHSEUJukoILPpQqOK0l+'01')
	if type=='Music':
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,maOcdN9C2IqDWbGZwhKMn+'/Music/Index?page='+QPZDaMKgtTUyNjB7EqvOLwph,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-TITLES-3rd')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination-demo(.*?)pagination-demo',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			uuyBj5CPAf1XDZ += 1
			NWqAr40jTLlMBemn3o79y = maOcdN9C2IqDWbGZwhKMn + NWqAr40jTLlMBemn3o79y
			Ga8xfYU6ht7cHjzn = maOcdN9C2IqDWbGZwhKMn + Ga8xfYU6ht7cHjzn
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,23,NWqAr40jTLlMBemn3o79y,'101')
	if uuyBj5CPAf1XDZ>20:
		title='صفحة '
		if i5HfSMmVOeAJPvI=='en': title = 'Page '
		if i5HfSMmVOeAJPvI=='fa': title = 'صفحه '
		if i5HfSMmVOeAJPvI=='fa2': title = 'صفحه '
		for YApb91W3ysqLQ5c0SeO2l4UH in range(1,11) :
			if not QPZDaMKgtTUyNjB7EqvOLwph==str(YApb91W3ysqLQ5c0SeO2l4UH):
				AvFq58TiYoxhaE06XlO = '0'+str(YApb91W3ysqLQ5c0SeO2l4UH)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title+str(YApb91W3ysqLQ5c0SeO2l4UH),url,22,kh850jKbzmBwY,dZHSEUJukoILPpQqOK0l+AvFq58TiYoxhaE06XlO[-2:])
	return
def do7Es2fUtFlM8ScLx(url,QPZDaMKgtTUyNjB7EqvOLwph):
	if not QPZDaMKgtTUyNjB7EqvOLwph: QPZDaMKgtTUyNjB7EqvOLwph = 0
	maOcdN9C2IqDWbGZwhKMn = ZHUbeK76dXMx(url)
	ZXbWJI1NfoiCt6uGRnkxKlqUSF = ZHUbeK76dXMx(url)
	i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(url)
	VQfK9Lr0j75zHwg1xOGY = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	id,type = VQfK9Lr0j75zHwg1xOGY[-1],VQfK9Lr0j75zHwg1xOGY[3]
	dZHSEUJukoILPpQqOK0l = str(int(QPZDaMKgtTUyNjB7EqvOLwph)//100)
	QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)%100)
	uuyBj5CPAf1XDZ = 0
	if type=='Series':
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-EPISODES-1st')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		title = ' - الحلقة '
		if i5HfSMmVOeAJPvI=='en': title = ' - Episode '
		if i5HfSMmVOeAJPvI=='fa': title = ' - قسمت '
		if i5HfSMmVOeAJPvI=='fa2': title = ' - قسمت '
		if i5HfSMmVOeAJPvI=='fa': NR1sIAw9a0ilufZpLoUYmHMBXCTd = kh850jKbzmBwY
		else: NR1sIAw9a0ilufZpLoUYmHMBXCTd = i5HfSMmVOeAJPvI
		hUGPOaSyCKi1XdF4wqgs2jtT = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for name,count,NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn in items:
			for WULSmfNH09tPIv58snzpCkR in range(int(count),0,-1):
				ZzHgWVf5ncmbERSvBiopl8qrJCQk9a = NWqAr40jTLlMBemn3o79y + NR1sIAw9a0ilufZpLoUYmHMBXCTd + id + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + str(WULSmfNH09tPIv58snzpCkR) + '.png'
				FEGJjiSZXB5pNV = name + title + str(WULSmfNH09tPIv58snzpCkR)
				FEGJjiSZXB5pNV = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(FEGJjiSZXB5pNV)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+FEGJjiSZXB5pNV,url,24,ZzHgWVf5ncmbERSvBiopl8qrJCQk9a,kh850jKbzmBwY,str(WULSmfNH09tPIv58snzpCkR))
	elif type=='Program':
		O9wzaDlICnq = maOcdN9C2IqDWbGZwhKMn+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+QPZDaMKgtTUyNjB7EqvOLwph+'&size=30&orderby=1'
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-EPISODES-2nd')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		title = ' - الحلقة '
		if i5HfSMmVOeAJPvI=='en': title = ' - Episode '
		if i5HfSMmVOeAJPvI=='fa': title = ' - قسمت '
		if i5HfSMmVOeAJPvI=='fa2': title = ' - قسمت '
		for WULSmfNH09tPIv58snzpCkR,NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,HGpMRnSw5ayLuEq6XCicxFNrsvB,name in items:
			uuyBj5CPAf1XDZ += 1
			ZzHgWVf5ncmbERSvBiopl8qrJCQk9a = ZXbWJI1NfoiCt6uGRnkxKlqUSF + ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
			name = Z4CP1xs5w7fi(name)
			FEGJjiSZXB5pNV = name + title + str(WULSmfNH09tPIv58snzpCkR)
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+FEGJjiSZXB5pNV,O9wzaDlICnq,24,ZzHgWVf5ncmbERSvBiopl8qrJCQk9a,kh850jKbzmBwY,str(uuyBj5CPAf1XDZ))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			O9wzaDlICnq = maOcdN9C2IqDWbGZwhKMn+'/Music/GetTracksBy?id='+str(id)+'&page='+QPZDaMKgtTUyNjB7EqvOLwph+'&size=30&type=0'
			uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-EPISODES-3rd')
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,name,title in items:
				uuyBj5CPAf1XDZ += 1
				ZzHgWVf5ncmbERSvBiopl8qrJCQk9a = ZXbWJI1NfoiCt6uGRnkxKlqUSF + ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
				FEGJjiSZXB5pNV = name + ' - ' + title
				FEGJjiSZXB5pNV = FEGJjiSZXB5pNV.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				FEGJjiSZXB5pNV = Z4CP1xs5w7fi(FEGJjiSZXB5pNV)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+FEGJjiSZXB5pNV,O9wzaDlICnq,24,ZzHgWVf5ncmbERSvBiopl8qrJCQk9a,kh850jKbzmBwY,str(uuyBj5CPAf1XDZ))
		elif 'Clips' in url:
			O9wzaDlICnq = maOcdN9C2IqDWbGZwhKMn+'/Music/GetTracksBy?id=0&page='+QPZDaMKgtTUyNjB7EqvOLwph+'&size=30&type=15'
			uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-EPISODES-4th')
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for NWqAr40jTLlMBemn3o79y,title,Ga8xfYU6ht7cHjzn in items:
				uuyBj5CPAf1XDZ += 1
				ZzHgWVf5ncmbERSvBiopl8qrJCQk9a = ZXbWJI1NfoiCt6uGRnkxKlqUSF + ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
				FEGJjiSZXB5pNV = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				FEGJjiSZXB5pNV = Z4CP1xs5w7fi(FEGJjiSZXB5pNV)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+FEGJjiSZXB5pNV,O9wzaDlICnq,24,ZzHgWVf5ncmbERSvBiopl8qrJCQk9a,kh850jKbzmBwY,str(uuyBj5CPAf1XDZ))
		elif 'category' in url:
			if 'category=6' in url:
				O9wzaDlICnq = maOcdN9C2IqDWbGZwhKMn+'/Music/GetTracksBy?id=0&page='+QPZDaMKgtTUyNjB7EqvOLwph+'&size=30&type=6'
				uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				O9wzaDlICnq = maOcdN9C2IqDWbGZwhKMn+'/Music/GetTracksBy?id=0&page='+QPZDaMKgtTUyNjB7EqvOLwph+'&size=30&type=4'
				uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-EPISODES-6th')
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,name,title in items:
				uuyBj5CPAf1XDZ += 1
				ZzHgWVf5ncmbERSvBiopl8qrJCQk9a = ZXbWJI1NfoiCt6uGRnkxKlqUSF + ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
				FEGJjiSZXB5pNV = name + ' - ' + title
				FEGJjiSZXB5pNV = FEGJjiSZXB5pNV.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				FEGJjiSZXB5pNV = Z4CP1xs5w7fi(FEGJjiSZXB5pNV)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+FEGJjiSZXB5pNV,O9wzaDlICnq,24,ZzHgWVf5ncmbERSvBiopl8qrJCQk9a,kh850jKbzmBwY,str(uuyBj5CPAf1XDZ))
	if type=='Music' or type=='Program':
		if uuyBj5CPAf1XDZ>25:
			title='صفحة '
			if i5HfSMmVOeAJPvI=='en': title = ' Page '
			if i5HfSMmVOeAJPvI=='fa': title = ' صفحه '
			if i5HfSMmVOeAJPvI=='fa2': title = ' صفحه '
			for YApb91W3ysqLQ5c0SeO2l4UH in range(1,11):
				if not QPZDaMKgtTUyNjB7EqvOLwph==str(YApb91W3ysqLQ5c0SeO2l4UH):
					AvFq58TiYoxhaE06XlO = '0'+str(YApb91W3ysqLQ5c0SeO2l4UH)
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title+str(YApb91W3ysqLQ5c0SeO2l4UH),url,23,kh850jKbzmBwY,dZHSEUJukoILPpQqOK0l+AvFq58TiYoxhaE06XlO[-2:])
	return
def yv8LezRQifhw1Kx(url,WULSmfNH09tPIv58snzpCkR):
	ZXbWJI1NfoiCt6uGRnkxKlqUSF = ZHUbeK76dXMx(url)
	x2xi0tpFnQgNmaJ4LR,lnYtOIQ4Rkh386Bca7 = [],[]
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-PLAY-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(url)
		VQfK9Lr0j75zHwg1xOGY = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		id,type = VQfK9Lr0j75zHwg1xOGY[-1],VQfK9Lr0j75zHwg1xOGY[3]
		Ga8xfYU6ht7cHjzn = items[0][0]+i5HfSMmVOeAJPvI+id+'/,'+WULSmfNH09tPIv58snzpCkR+','+WULSmfNH09tPIv58snzpCkR+'_'+items[0][2]
		x2xi0tpFnQgNmaJ4LR.append('m3u8')
		lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(url)
		VQfK9Lr0j75zHwg1xOGY = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		id,type = VQfK9Lr0j75zHwg1xOGY[-1],VQfK9Lr0j75zHwg1xOGY[3]
		Ga8xfYU6ht7cHjzn = items[0][0]+i5HfSMmVOeAJPvI+id+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+WULSmfNH09tPIv58snzpCkR+items[0][2]
		x2xi0tpFnQgNmaJ4LR.append('mp4 url')
		lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('source src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn in items:
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace(bruAOCB4ZoHVF7,i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		x2xi0tpFnQgNmaJ4LR.append('mp4 src')
		lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('VideoAddress":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		Ga8xfYU6ht7cHjzn = items[int(WULSmfNH09tPIv58snzpCkR)-1]
		Ga8xfYU6ht7cHjzn = ZXbWJI1NfoiCt6uGRnkxKlqUSF+ioZ083zxYk(Ga8xfYU6ht7cHjzn)
		x2xi0tpFnQgNmaJ4LR.append('mp4 address')
		lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('VoiceAddress":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		Ga8xfYU6ht7cHjzn = items[int(WULSmfNH09tPIv58snzpCkR)-1]
		Ga8xfYU6ht7cHjzn = ZXbWJI1NfoiCt6uGRnkxKlqUSF+ioZ083zxYk(Ga8xfYU6ht7cHjzn)
		x2xi0tpFnQgNmaJ4LR.append('mp3 address')
		lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	if len(lnYtOIQ4Rkh386Bca7)==1: Ga8xfYU6ht7cHjzn = lnYtOIQ4Rkh386Bca7[0]
	else:
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('اختر الفيديو المناسب:', x2xi0tpFnQgNmaJ4LR)
		if TTn7mZzPRjq5GBESh8aKy == -1 : return
		Ga8xfYU6ht7cHjzn = lnYtOIQ4Rkh386Bca7[TTn7mZzPRjq5GBESh8aKy]
	NRlCaq1ndM(Ga8xfYU6ht7cHjzn,vkNGie5mhCqoTFRzPKaML0x6,'video')
	return
def ZHUbeK76dXMx(url):
	if WLjaXVNk2dnAJzPpy6OlMv4qoi9 in url: CYil97XWVj4Z3SRKMUf8DGQeLa = WLjaXVNk2dnAJzPpy6OlMv4qoi9
	elif d0hVTC6pXnNEwLqm4zbt3x in url: CYil97XWVj4Z3SRKMUf8DGQeLa = d0hVTC6pXnNEwLqm4zbt3x
	elif dwmfrA3kVjbRU7KMaqCEBXYx9 in url: CYil97XWVj4Z3SRKMUf8DGQeLa = dwmfrA3kVjbRU7KMaqCEBXYx9
	elif gsqoO8eRhFYryKW in url: CYil97XWVj4Z3SRKMUf8DGQeLa = gsqoO8eRhFYryKW
	else: CYil97XWVj4Z3SRKMUf8DGQeLa = kh850jKbzmBwY
	return CYil97XWVj4Z3SRKMUf8DGQeLa
def LzfVpPYHhjsAcgiuaxJySRKI(url):
	if   WLjaXVNk2dnAJzPpy6OlMv4qoi9 in url: i5HfSMmVOeAJPvI = 'ar'
	elif d0hVTC6pXnNEwLqm4zbt3x in url: i5HfSMmVOeAJPvI = 'en'
	elif dwmfrA3kVjbRU7KMaqCEBXYx9 in url: i5HfSMmVOeAJPvI = 'fa'
	elif gsqoO8eRhFYryKW in url: i5HfSMmVOeAJPvI = 'fa2'
	else: i5HfSMmVOeAJPvI = kh850jKbzmBwY
	return i5HfSMmVOeAJPvI
def r1GaLwhMA3(url):
	i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(url)
	O9wzaDlICnq = url + '/Home/Live'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-LIVE-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('source src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	QQJdiByEeNqLYGs = items[0]
	NRlCaq1ndM(QQJdiByEeNqLYGs,vkNGie5mhCqoTFRzPKaML0x6,'live')
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if not search:
		search = GG5Fs0hvURxyBV8gz()
		if not search: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	if showDialogs:
		WWTPobsOlZBRVk4nLx2mUcrIY7zf = [ WLjaXVNk2dnAJzPpy6OlMv4qoi9 , d0hVTC6pXnNEwLqm4zbt3x , dwmfrA3kVjbRU7KMaqCEBXYx9 , gsqoO8eRhFYryKW ]
		u6X0ermz2hnb4FPM7oSyGIA1V = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('اختر اللغة المناسبة:', u6X0ermz2hnb4FPM7oSyGIA1V)
		if TTn7mZzPRjq5GBESh8aKy == -1 : return
		website = WWTPobsOlZBRVk4nLx2mUcrIY7zf[TTn7mZzPRjq5GBESh8aKy]
	else:
		if '_IFILM-ARABIC_' in kFdoZmlxSf8shU: website = WLjaXVNk2dnAJzPpy6OlMv4qoi9
		elif '_IFILM-ENGLISH_' in kFdoZmlxSf8shU: website = d0hVTC6pXnNEwLqm4zbt3x
		else: website = kh850jKbzmBwY
	if not website: return
	i5HfSMmVOeAJPvI = LzfVpPYHhjsAcgiuaxJySRKI(website)
	O9wzaDlICnq = website + "/Home/Search?searchstring=" + BkpEeTDInR6LQFG2m1Ns
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'IFILM-SEARCH-1st')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		for NWqAr40jTLlMBemn3o79y,XvPwmy3axVdD6NIKGb4Ak,id,title in items:
			if XvPwmy3axVdD6NIKGb4Ak in ['3','7']:
				title = title.replace('\\',kh850jKbzmBwY)
				title = title.replace('"',kh850jKbzmBwY)
				if XvPwmy3axVdD6NIKGb4Ak=='3':
					type = 'Series'
					if i5HfSMmVOeAJPvI=='ar': name = 'مسلسل : '
					elif i5HfSMmVOeAJPvI=='en': name = 'Series : '
					elif i5HfSMmVOeAJPvI=='fa': name = 'سريال ها : '
					elif i5HfSMmVOeAJPvI=='fa2': name = 'سريال ها : '
				elif XvPwmy3axVdD6NIKGb4Ak=='5':
					type = 'Film'
					if i5HfSMmVOeAJPvI=='ar': name = 'فيلم : '
					elif i5HfSMmVOeAJPvI=='en': name = 'Movie : '
					elif i5HfSMmVOeAJPvI=='fa': name = 'فيلم : '
					elif i5HfSMmVOeAJPvI=='fa2': name = 'فلم ها : '
				elif XvPwmy3axVdD6NIKGb4Ak=='7':
					type = 'Program'
					if i5HfSMmVOeAJPvI=='ar': name = 'برنامج : '
					elif i5HfSMmVOeAJPvI=='en': name = 'Program : '
					elif i5HfSMmVOeAJPvI=='fa': name = 'برنامه ها : '
					elif i5HfSMmVOeAJPvI=='fa2': name = 'برنامه ها : '
				title = name + title
				Ga8xfYU6ht7cHjzn = website + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + type + '/Content/' + id
				NWqAr40jTLlMBemn3o79y = ioZ083zxYk(NWqAr40jTLlMBemn3o79y)
				NWqAr40jTLlMBemn3o79y = website+NWqAr40jTLlMBemn3o79y
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,23,NWqAr40jTLlMBemn3o79y,'101')
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
headers = { 'User-Agent' : kh850jKbzmBwY }
vkNGie5mhCqoTFRzPKaML0x6 = 'AKOAM'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_AKO_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
wbZOzcGeCymDUPFR = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==70: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==71: PP3FsDicLyWuTR7GV5Ia = Iu8MASzegtVLihCDn76kr3WKx(url)
	elif mode==72: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==73: PP3FsDicLyWuTR7GV5Ia = EOjKTRioJ03rF(url)
	elif mode==74: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==79: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,79,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'سلسلة افلام',kh850jKbzmBwY,79,kh850jKbzmBwY,kh850jKbzmBwY,'سلسلة افلام')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'سلاسل منوعة',kh850jKbzmBwY,79,kh850jKbzmBwY,kh850jKbzmBwY,'سلسلة')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'AKOAM-MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="partions"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title not in QQeT5Ntzv2ysxVmLHj1adM40iYpk:
				EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,71)
	return uP1m46pAK5a3UgdqvBz9rnL
def Iu8MASzegtVLihCDn76kr3WKx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,headers,kh850jKbzmBwY,'AKOAM-CATEGORIES-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('sect_parts(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,72)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'جميع الفروع',url,72)
	else: bsZhnoqjD3U(url,kh850jKbzmBwY)
	return
def bsZhnoqjD3U(url,type):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('section_title featured_title(.*?)subjects-crousel',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif type=='search':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('akoam_result(.*?)<script',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif type=='more':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('section_title more_title(.*?)footer_bottom_services',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('navigation(.*?)<script',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items and liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		if any(value in title for value in wbZOzcGeCymDUPFR): EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,73,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,73,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("</li><li >.*?href='(.*?)'>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,72,kh850jKbzmBwY,kh850jKbzmBwY,type)
	return
def nY2PgwzKmVUcBqfyr(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,headers,True,'AKOAM-SECTIONS-2nd')
	O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"href","(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	O9wzaDlICnq = O9wzaDlICnq[1]
	return O9wzaDlICnq
def EOjKTRioJ03rF(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,True,'AKOAM-SECTIONS-1st')
	tilce4SIE7GfHq5kR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"(https*://akwam.net/\w+.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	UL9yuBZ08VrjeT7CnmoSwGa = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"(https*://underurl.com/\w+.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if tilce4SIE7GfHq5kR or UL9yuBZ08VrjeT7CnmoSwGa:
		if tilce4SIE7GfHq5kR: QQJdiByEeNqLYGs = tilce4SIE7GfHq5kR[0]
		elif UL9yuBZ08VrjeT7CnmoSwGa: QQJdiByEeNqLYGs = nY2PgwzKmVUcBqfyr(UL9yuBZ08VrjeT7CnmoSwGa[0])
		QQJdiByEeNqLYGs = KsuzxGjOHChbIXrwWm(QQJdiByEeNqLYGs)
		import JfSMWI6aRA
		if '/series/' in QQJdiByEeNqLYGs or '/shows/' in QQJdiByEeNqLYGs: JfSMWI6aRA.do7Es2fUtFlM8ScLx(QQJdiByEeNqLYGs)
		else: JfSMWI6aRA.yv8LezRQifhw1Kx(QQJdiByEeNqLYGs)
		return
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,73)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not liroJ6qCK9k:
		o4n5ehzyjHTWdL8('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,NWqAr40jTLlMBemn3o79y,ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	if 'sub_epsiode_title' in ZZDUdXR52CMs9K73Ex:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else:
		J2JlUokZBPMjxzWwTQ = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('sub_file_title\'>(.*?) - <i>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		items = []
		for filename in J2JlUokZBPMjxzWwTQ:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',kh850jKbzmBwY) ]
	count = 0
	x2xi0tpFnQgNmaJ4LR,aqU9rOI0ifjgQcB4d3hLtWl6e7NRF = [],[]
	size = len(items)
	for title,filename in items:
		uayM539UAPSgpYjhs = kh850jKbzmBwY
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: uayM539UAPSgpYjhs = filename.split('.')[-1]
		title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		x2xi0tpFnQgNmaJ4LR.append(title)
		aqU9rOI0ifjgQcB4d3hLtWl6e7NRF.append(count)
		count += 1
	if size>0:
		if any(value in name for value in wbZOzcGeCymDUPFR):
			if size==1:
				TTn7mZzPRjq5GBESh8aKy = 0
			else:
				TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('اختر الفيديو المناسب:', x2xi0tpFnQgNmaJ4LR)
				if TTn7mZzPRjq5GBESh8aKy == -1: return
			yv8LezRQifhw1Kx(url+'?section='+str(1+aqU9rOI0ifjgQcB4d3hLtWl6e7NRF[size-TTn7mZzPRjq5GBESh8aKy-1]))
		else:
			for asKYTS478qkW in reversed(range(size)):
				title = name + ' - ' + x2xi0tpFnQgNmaJ4LR[asKYTS478qkW]
				title = title.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				Ga8xfYU6ht7cHjzn = url + '?section='+str(size-asKYTS478qkW)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,74,NWqAr40jTLlMBemn3o79y)
	else:
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+'الرابط ليس فيديو',kh850jKbzmBwY,9999,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	O9wzaDlICnq,WULSmfNH09tPIv58snzpCkR = url.split('?section=')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,headers,True,kh850jKbzmBwY,'AKOAM-PLAY_AKOAM-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	AGrpcD8qoNkadhX2fMw96VtPKI = liroJ6qCK9k[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	AGrpcD8qoNkadhX2fMw96VtPKI = AGrpcD8qoNkadhX2fMw96VtPKI + 'direct_link_box'
	tKoDYsOPeyxM = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('epsoide_box(.*?)direct_link_box',AGrpcD8qoNkadhX2fMw96VtPKI,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	WULSmfNH09tPIv58snzpCkR = len(tKoDYsOPeyxM)-int(WULSmfNH09tPIv58snzpCkR)
	ZZDUdXR52CMs9K73Ex = tKoDYsOPeyxM[WULSmfNH09tPIv58snzpCkR]
	owMxje0p9Ya3CkhJDX = []
	PPwXLu7nlg = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("class='download_btn.*?href='(.*?)'",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn in items:
		owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named=________akoam')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for ff7T1vWhJZtw3mszanrCpue2VgI,Ga8xfYU6ht7cHjzn in items:
		ff7T1vWhJZtw3mszanrCpue2VgI = ff7T1vWhJZtw3mszanrCpue2VgI.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
		ff7T1vWhJZtw3mszanrCpue2VgI = ff7T1vWhJZtw3mszanrCpue2VgI.split('.')[0]
		if ff7T1vWhJZtw3mszanrCpue2VgI in PPwXLu7nlg:
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+PPwXLu7nlg[ff7T1vWhJZtw3mszanrCpue2VgI]+'________akoam')
		else: owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+ff7T1vWhJZtw3mszanrCpue2VgI+'________akoam')
	if not owMxje0p9Ya3CkhJDX:
		message = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('sub-no-file.*?\n(.*?)\n',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if message: o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,'رسالة من الموقع الاصلي',message[0])
	else:
		import OO3KYXPMuI
		OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search/'+BkpEeTDInR6LQFG2m1Ns
	PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,'search')
	return
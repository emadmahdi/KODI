# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'FASELHD2'
headers = {'User-Agent': kh850jKbzmBwY}
GalrcVUMy8bzORWX5E0exhYivBwgk = '_FH2_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][nxUveizbLEAT2FBNy3]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['FaselHD']
def Z6V4AKYFUSWMmqBNXJ72p(mode, url, text):
    if mode == 590: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
    elif mode == 591: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url, text)
    elif mode == 592: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
    elif mode == 593:
        PP3FsDicLyWuTR7GV5Ia = oAYk7vWHsLNC0VJqQ8FjnX(url, text)
    elif mode == 599:
        PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
    else:
        PP3FsDicLyWuTR7GV5Ia = False
    return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
    giRfrJxZdQ16bw2oe = WLjaXVNk2dnAJzPpy6OlMv4qoi9
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', giRfrJxZdQ16bw2oe, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'FASELHD2-MENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'بحث في الموقع', giRfrJxZdQ16bw2oe, 599, kh850jKbzmBwY, kh850jKbzmBwY, '_REMEMBERRESULTS_')
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<h3>(.*?)<.*?href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    dUh1Xs4tY3yE = nxUveizbLEAT2FBNy3
    for title, Ga8xfYU6ht7cHjzn in items:
        Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9
        title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
        if any(value in title for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
        EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 591, kh850jKbzmBwY, kh850jKbzmBwY, 'featured' + str(dUh1Xs4tY3yE))
        dUh1Xs4tY3yE += igM4DhpPzoX95Ysnar6Auj
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"main-menu"(.*?)</nav>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
        LiKEzOQSwmt7MeUqaGp1AJkvonPfTh = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li (.*?)</li>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for MBq6IdsKJ9z21Z in LiKEzOQSwmt7MeUqaGp1AJkvonPfTh:
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<', MBq6IdsKJ9z21Z, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title in items:
                if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe + Ga8xfYU6ht7cHjzn
                EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 591)
    return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url, eRVKBkL2rNi=kh850jKbzmBwY):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'FASELHD2-TITLES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    items = []
    if 'featured' in eRVKBkL2rNi:
        dUh1Xs4tY3yE = eRVKBkL2rNi[-igM4DhpPzoX95Ysnar6Auj]
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"boxes--holder"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[int(dUh1Xs4tY3yE)]
    elif eRVKBkL2rNi == 'filters':
        liroJ6qCK9k = [uP1m46pAK5a3UgdqvBz9rnL.replace('\\/', i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace('\\"', '"')]
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
    else:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"boxes--holder"(.*?)"pagination"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
    if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة', 'فيلم', 'اغنية', 'كليب', 'اعلان', 'هداف', 'مباراة', 'عرض', 'مهرجان', 'البوم', 'مسرحية', 'حلقة']
    SHTvIuhX52dxQRsWA = []
    for Ga8xfYU6ht7cHjzn, NWqAr40jTLlMBemn3o79y, title in items:
        title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
        try:
            title = title.encode(BPnjKce5wR).decode(NVbhZ0DTpOkCA)
        except:
            pass
        title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
        if any(value in title.lower() for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
        WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+', title, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if '/movseries/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 591, NWqAr40jTLlMBemn3o79y)
        elif WULSmfNH09tPIv58snzpCkR:
            title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
            if title not in SHTvIuhX52dxQRsWA:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 593, NWqAr40jTLlMBemn3o79y)
                SHTvIuhX52dxQRsWA.append(title)
        elif any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
            EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 592, NWqAr40jTLlMBemn3o79y)
        else:
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 593, NWqAr40jTLlMBemn3o79y)
    if eRVKBkL2rNi == 'filters':
        BeaPvLOV5WQEgZpRbh = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"more_button_page":(.*?),', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if BeaPvLOV5WQEgZpRbh:
            count = BeaPvLOV5WQEgZpRbh[0]
            Ga8xfYU6ht7cHjzn = url + '/offset/' + count
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة أخرى', Ga8xfYU6ht7cHjzn, 591, kh850jKbzmBwY, kh850jKbzmBwY, 'filters')
    elif 'featured' not in eRVKBkL2rNi:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title in items:
                title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
                Ga8xfYU6ht7cHjzn = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(Ga8xfYU6ht7cHjzn)
                if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 591, kh850jKbzmBwY, kh850jKbzmBwY, 'details4')
    return
def oAYk7vWHsLNC0VJqQ8FjnX(url, data=kh850jKbzmBwY):
    if '/Episodes.php' in url:
        headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'POST', url, data, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'FASELHD2-SEASONS_EPISODES-1st')
        uP1m46pAK5a3UgdqvBz9rnL = '"EpisodesList"' + OIjmsWqwACpDMT7l3GaYbxtvh0L.content + '</div>'
    else:
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'FASELHD2-SEASONS_EPISODES-2nd')
        uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    vvufbqFnUclCD5MxOz = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"inner--image"><img src="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    NWqAr40jTLlMBemn3o79y = vvufbqFnUclCD5MxOz[nxUveizbLEAT2FBNy3] if vvufbqFnUclCD5MxOz else kh850jKbzmBwY
    items = []
    if not data:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"SeasonsList"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            if len(items) > 1:
                for N96VzWobDawRQEik5t3B, GGy6r8KUN0WjnqoTR, title in items:
                    Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
                    hhUDZA3piIJyMsxfbgGdWO = 'season=' + GGy6r8KUN0WjnqoTR + '&post_id=' + N96VzWobDawRQEik5t3B
                    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 593, NWqAr40jTLlMBemn3o79y, kh850jKbzmBwY, hhUDZA3piIJyMsxfbgGdWO)
        data = dbo4vrnTM56I
    if data and len(items) < s0sB2Xyp9uYU5N3fxzKoLW8:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"EpisodesList"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[nxUveizbLEAT2FBNy3]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<em>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, q2qOZJQiy7ugcjprh64RLdW, EVfKyFrmX1Mpb62tLuHS5w3W in items:
                title = q2qOZJQiy7ugcjprh64RLdW + EE3iZM15sTQ2t9cOhuCWwDjGSUzryF + EVfKyFrmX1Mpb62tLuHS5w3W
                title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
                EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 592, NWqAr40jTLlMBemn3o79y)
    return
def yv8LezRQifhw1Kx(url):
    url = url.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M) + '/watch/'
    owMxje0p9Ya3CkhJDX, Fr2nREYhQJela3szX, vAJGwmQjgI96P7pRWEDe = [], [], []
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'FASELHD2-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    RsbCagWf3x2Nn4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('العمر :.*?<strong">(.*?)</strong>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if RsbCagWf3x2Nn4 and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6, url, RsbCagWf3x2Nn4): return
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<iframe src="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if Ga8xfYU6ht7cHjzn:
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
        owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=__embed')
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"main--contents"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for jj4z8ypcK7, N96VzWobDawRQEik5t3B, title in items:
            title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
            Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id=' + N96VzWobDawRQEik5t3B + '&i=' + jj4z8ypcK7
            owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=' + title + '__watch')
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"downloads"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, name in items:
            owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=' + name + '__download')
    for t42R8EyFVQzrwjX in owMxje0p9Ya3CkhJDX:
        Ga8xfYU6ht7cHjzn, name = t42R8EyFVQzrwjX.split('?named')
        if Ga8xfYU6ht7cHjzn not in Fr2nREYhQJela3szX:
            Fr2nREYhQJela3szX.append(Ga8xfYU6ht7cHjzn)
            vAJGwmQjgI96P7pRWEDe.append(t42R8EyFVQzrwjX)
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(vAJGwmQjgI96P7pRWEDe, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def dStQzEeyknDaOs7q(search):
    search, kFdoZmlxSf8shU, showDialogs = gCI13c7MdXA8(search)
    if search == kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
    if search == kh850jKbzmBwY: return
    search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF, '+')
    giRfrJxZdQ16bw2oe = WLjaXVNk2dnAJzPpy6OlMv4qoi9
    url = giRfrJxZdQ16bw2oe + '/?s=' + search
    bsZhnoqjD3U(url, 'details5')
    return
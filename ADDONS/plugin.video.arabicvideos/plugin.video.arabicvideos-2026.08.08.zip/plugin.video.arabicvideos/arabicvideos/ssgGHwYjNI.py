# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'MOVS4U'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_M4U_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['انواع افلام','جودات افلام']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==380: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==381: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==382: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==383: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==389: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,389,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',WLjaXVNk2dnAJzPpy6OlMv4qoi9,381,kh850jKbzmBwY,kh850jKbzmBwY,'featured')
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الجانبية',WLjaXVNk2dnAJzPpy6OlMv4qoi9,381,kh850jKbzmBwY,kh850jKbzmBwY,'sider')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MOVS4U-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<header>.*?<h2>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for dUh1Xs4tY3yE in range(len(items)):
		title = items[dUh1Xs4tY3yE]
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,WLjaXVNk2dnAJzPpy6OlMv4qoi9,381,kh850jKbzmBwY,kh850jKbzmBwY,'latest'+str(dUh1Xs4tY3yE))
	ZZDUdXR52CMs9K73Ex = kh850jKbzmBwY
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="menu"(.*?)id="contenedor"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex += liroJ6qCK9k[0]
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="sidebar(.*?)aside',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex += liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	uWLHzodcJeGxVFP2Eqr0fZUwKb5 = True
	for Ga8xfYU6ht7cHjzn,title in items:
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		if title=='الأعلى مشاهدة':
			if uWLHzodcJeGxVFP2Eqr0fZUwKb5:
				title = 'الافلام '+title
				uWLHzodcJeGxVFP2Eqr0fZUwKb5 = False
			else: title = 'المسلسلات '+title
		if title not in QQeT5Ntzv2ysxVmLHj1adM40iYpk:
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,381)
	return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url,type):
	ZZDUdXR52CMs9K73Ex,items = [],[]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MOVS4U-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if type=='search':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="search-page"(.*?)class="sidebar',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif type=='sider':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="widget(.*?)class="widget',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		O98VHvgphf4qdWAjJi12b = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		lnYtOIQ4Rkh386Bca7,Xbqki1lOcYQuH5wBo8,x2xi0tpFnQgNmaJ4LR = zip(*O98VHvgphf4qdWAjJi12b)
		items = zip(Xbqki1lOcYQuH5wBo8,lnYtOIQ4Rkh386Bca7,x2xi0tpFnQgNmaJ4LR)
	elif type=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="slider-movies-tvshows"(.*?)<header>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif 'latest' in type:
		dUh1Xs4tY3yE = int(type[-1:])
		uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('<header>','<end><start>')
		uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('<div class="sidebar','<end><div class="sidebar')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<start>(.*?)<end>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[dUh1Xs4tY3yE]
		if dUh1Xs4tY3yE==2: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="content"(.*?)class="(pagination|sidebar)',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0][0]
			if '/collection/' in url:
				items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			elif '/quality/' in url:
				items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items and ZZDUdXR52CMs9K73Ex:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		if 'serie' in title:
			title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^(.*?)<.*?serie">(.*?)<',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			title = title[0][1]
			if title in SHTvIuhX52dxQRsWA: continue
			SHTvIuhX52dxQRsWA.append(title)
			title = '_MOD_'+title
		EVfKyFrmX1Mpb62tLuHS5w3W = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^(.*?)<',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if EVfKyFrmX1Mpb62tLuHS5w3W: title = EVfKyFrmX1Mpb62tLuHS5w3W[0]
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		if '/tvshows/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,383,NWqAr40jTLlMBemn3o79y)
		elif '/episodes/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,383,NWqAr40jTLlMBemn3o79y)
		elif '/seasons/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,383,NWqAr40jTLlMBemn3o79y)
		elif '/collection/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,381,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,382,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		nMISPVqm5f1uX2z = liroJ6qCK9k[0][0]
		HENY5rjyqJOX49WZdnth0lAgsUzak1 = liroJ6qCK9k[0][1]
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0][2]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("href='(.*?)'.*?>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title==kh850jKbzmBwY or title==HENY5rjyqJOX49WZdnth0lAgsUzak1: continue
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,381,kh850jKbzmBwY,kh850jKbzmBwY,type)
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('/page/'+title+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,'/page/'+HENY5rjyqJOX49WZdnth0lAgsUzak1+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'اخر صفحة '+HENY5rjyqJOX49WZdnth0lAgsUzak1,Ga8xfYU6ht7cHjzn,381,kh850jKbzmBwY,kh850jKbzmBwY,type)
	return
def do7Es2fUtFlM8ScLx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MOVS4U-EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="C rated".*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV,False):
		EE6ysIeB8jKNgCfOkv('link',GalrcVUMy8bzORWX5E0exhYivBwgk+'المسلسل للكبار والمبرمج منعه',kh850jKbzmBwY,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''class='item'><a href="(.*?)"''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if O9wzaDlICnq:
			O9wzaDlICnq = O9wzaDlICnq[1]
			do7Es2fUtFlM8ScLx(O9wzaDlICnq)
			return
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''class='episodios'(.*?)id="cast"''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for NWqAr40jTLlMBemn3o79y,WULSmfNH09tPIv58snzpCkR,Ga8xfYU6ht7cHjzn,name in items:
			title = WULSmfNH09tPIv58snzpCkR+' : '+name+' الحلقة'
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,382)
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MOVS4U-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="C rated".*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	lnYtOIQ4Rkh386Bca7 = []
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0][0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("data-url='(.*?)'.*?class='server'>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="remodal"(.*?)class="remodal-close"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__download'
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?s='+search
	bsZhnoqjD3U(url,'search')
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SHAHID4U'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SH4_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
headers = {'User-Agent': e9SaDhW4XdLY2HfyPU7JI(True)}
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['عروض مصارعة', 'الكل', 'افلام', 'javascript', 'مصارعة حرة']
def Z6V4AKYFUSWMmqBNXJ72p(mode, url, text):
    if mode == 110: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
    elif mode == 111: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url, text)
    elif mode == 112: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
    elif mode == 113: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url, True)
    elif mode == 114: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url, 'FULL_FILTER___' + text)
    elif mode == 115: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url, 'DEFINED_FILTER___' + text)
    elif mode == 116: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url, False)
    elif mode == 119: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
    else: PP3FsDicLyWuTR7GV5Ia = False
    return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'بحث في الموقع', kh850jKbzmBwY, 119, kh850jKbzmBwY, kh850jKbzmBwY, '_REMEMBERRESULTS_')
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'فلتر محدد', WLjaXVNk2dnAJzPpy6OlMv4qoi9, 115)
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'فلتر كامل', WLjaXVNk2dnAJzPpy6OlMv4qoi9, 114)
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'المميزة', WLjaXVNk2dnAJzPpy6OlMv4qoi9, 111, kh850jKbzmBwY, kh850jKbzmBwY, 'featured')
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', WLjaXVNk2dnAJzPpy6OlMv4qoi9, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-MENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('simple-filter(.*?)adv-filter', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k:
        o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY, kh850jKbzmBwY, 'موقع شاهد فوريو', 'البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
        return
    else:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for filter, NWqAr40jTLlMBemn3o79y, title in items:
            url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + filter
            EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, url, 111, NWqAr40jTLlMBemn3o79y, kh850jKbzmBwY, filter)
        EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="dropdown"(.*?)<script>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            title = title.replace(URBvawyLXfQiS2NI34HDk, kh850jKbzmBwY).replace(lpaqU2W5YZ4v6MuVyecsDIEO, kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
            if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
            if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
            if 'netflix' in Ga8xfYU6ht7cHjzn: title = 'نيتفلكس'
            EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 111)
    return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url, JjH8Zr42QL5AnsweEIRxltWcp=kh850jKbzmBwY, OIjmsWqwACpDMT7l3GaYbxtvh0L=kh850jKbzmBwY):
    if not OIjmsWqwACpDMT7l3GaYbxtvh0L: OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-TITLES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k, items, SHTvIuhX52dxQRsWA = [], [], []
    if JjH8Zr42QL5AnsweEIRxltWcp == 'featured':
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('glide__slides(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    else:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('shows-container(.*?)pagination', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k: return
    ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة', 'فيلم', 'اغنية', 'كليب', 'اعلان', 'هداف', 'مباراة', 'عرض', 'مهرجان', 'البوم']
    for Ga8xfYU6ht7cHjzn, NWqAr40jTLlMBemn3o79y, title in items:
        if 'WWE' in title: continue
        if 'javascript' in Ga8xfYU6ht7cHjzn: continue
        Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn).strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
        title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
        title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
        WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة \d+', title, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if '/film/' in Ga8xfYU6ht7cHjzn or 'فيلم' in Ga8xfYU6ht7cHjzn or any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
            EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 112, NWqAr40jTLlMBemn3o79y)
        elif WULSmfNH09tPIv58snzpCkR and 'الحلقة' in title and '/list' not in url:
            title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
            if title not in SHTvIuhX52dxQRsWA:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 113, NWqAr40jTLlMBemn3o79y)
                SHTvIuhX52dxQRsWA.append(title)
        elif '/actor/' in Ga8xfYU6ht7cHjzn:
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 111, NWqAr40jTLlMBemn3o79y)
        elif '/series/' in Ga8xfYU6ht7cHjzn and '/list' not in url:
            Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '/list'
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 111, NWqAr40jTLlMBemn3o79y)
        elif '/list' in url and 'حلقة' in title:
            EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 112, NWqAr40jTLlMBemn3o79y)
        else:
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 113, NWqAr40jTLlMBemn3o79y)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k and JjH8Zr42QL5AnsweEIRxltWcp != 'featured':
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        if JjH8Zr42QL5AnsweEIRxltWcp != 'search': items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(updateQuery).*?>(.+?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        else: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li>.*?href="(.*?)">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if 'page=' in url: url = url.split('page=', 1)[0][:-1]
        for Ga8xfYU6ht7cHjzn, title in items:
            title = title.replace(URBvawyLXfQiS2NI34HDk, kh850jKbzmBwY).replace(lpaqU2W5YZ4v6MuVyecsDIEO, kh850jKbzmBwY)
            title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
            if JjH8Zr42QL5AnsweEIRxltWcp != 'search':
                Ga8xfYU6ht7cHjzn = url + '&page=' + title if '?' in url else url + '?page=' + title
            title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
            if title: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 111, kh850jKbzmBwY, kh850jKbzmBwY, JjH8Zr42QL5AnsweEIRxltWcp)
    return
def do7Es2fUtFlM8ScLx(url, jGXJfhRy27dQDKVPYzr3WZImO4):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-EPISODES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('items d-flex(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if len(liroJ6qCK9k) > 1:
        if '/season/' in liroJ6qCK9k[0]: djk9EyCzTearMK3vWINi2L, hNDb2sI34dvRnlXZHMz6YfkuOSV = liroJ6qCK9k[0], liroJ6qCK9k[1]
        else: djk9EyCzTearMK3vWINi2L, hNDb2sI34dvRnlXZHMz6YfkuOSV = liroJ6qCK9k[1], liroJ6qCK9k[0]
    else: djk9EyCzTearMK3vWINi2L, hNDb2sI34dvRnlXZHMz6YfkuOSV = liroJ6qCK9k[0], liroJ6qCK9k[0]
    for aaHueZUKGJDOvqjAy6CTinMIY in range(2):
        if jGXJfhRy27dQDKVPYzr3WZImO4: mode, type, ZZDUdXR52CMs9K73Ex = 116, 'folder', djk9EyCzTearMK3vWINi2L
        else: mode, type, ZZDUdXR52CMs9K73Ex = 112, 'video', hNDb2sI34dvRnlXZHMz6YfkuOSV
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if jGXJfhRy27dQDKVPYzr3WZImO4 and len(items) < 2:
            jGXJfhRy27dQDKVPYzr3WZImO4 = False
            continue
        for Ga8xfYU6ht7cHjzn, q2qOZJQiy7ugcjprh64RLdW, EVfKyFrmX1Mpb62tLuHS5w3W in items:
            title = q2qOZJQiy7ugcjprh64RLdW + EE3iZM15sTQ2t9cOhuCWwDjGSUzryF + EVfKyFrmX1Mpb62tLuHS5w3W
            EE6ysIeB8jKNgCfOkv(type, GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, mode)
        break
    if not items and '/episodes' in uP1m46pAK5a3UgdqvBz9rnL:
        YKBAXf6roDUj0vI4ta2 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="breadcrumb"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if YKBAXf6roDUj0vI4ta2:
            ZZDUdXR52CMs9K73Ex = YKBAXf6roDUj0vI4ta2[0]
            Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            if len(Sp6qOyDB0nt5Qo4KwbPfcWYe) > 2:
                Ga8xfYU6ht7cHjzn = Sp6qOyDB0nt5Qo4KwbPfcWYe[2] + 'list'
                bsZhnoqjD3U(Ga8xfYU6ht7cHjzn)
    return
def yv8LezRQifhw1Kx(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV, 'GET', url, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="actions(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not liroJ6qCK9k: return
    ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    MbB35afShGzrNxsVYRPKdv = '/watch/' in ZZDUdXR52CMs9K73Ex
    download = '/download/' in ZZDUdXR52CMs9K73Ex
    if MbB35afShGzrNxsVYRPKdv and not download: VoxkPgz5FyJ0C3BKUDtw, NHjSru5bCKEXl7sQPpW9RieM = Sp6qOyDB0nt5Qo4KwbPfcWYe[0], kh850jKbzmBwY
    elif not MbB35afShGzrNxsVYRPKdv and download: VoxkPgz5FyJ0C3BKUDtw, NHjSru5bCKEXl7sQPpW9RieM = kh850jKbzmBwY, Sp6qOyDB0nt5Qo4KwbPfcWYe[0]
    elif MbB35afShGzrNxsVYRPKdv and download: VoxkPgz5FyJ0C3BKUDtw, NHjSru5bCKEXl7sQPpW9RieM = Sp6qOyDB0nt5Qo4KwbPfcWYe[0], Sp6qOyDB0nt5Qo4KwbPfcWYe[1]
    else: VoxkPgz5FyJ0C3BKUDtw, NHjSru5bCKEXl7sQPpW9RieM = kh850jKbzmBwY, kh850jKbzmBwY
    lnYtOIQ4Rkh386Bca7 = []
    if MbB35afShGzrNxsVYRPKdv:
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV, 'GET', VoxkPgz5FyJ0C3BKUDtw, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-PLAY-2nd')
        kKwr9zX358QO47tbu1UC2 = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
        oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('let servers(.*?)player', kKwr9zX358QO47tbu1UC2, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL | sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.IGNORECASE)
        if oQuiJvtTzwPZbXd7sf4HcG9:
            c0jtBCYDEkL5HJfVX = oQuiJvtTzwPZbXd7sf4HcG9[0]
            h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"name":"(.*?)".*?"url":"(.*?)"', c0jtBCYDEkL5HJfVX, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for title, Ga8xfYU6ht7cHjzn in h729UnyEIjoYSNKcLOvqfV4:
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('\\/', i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__watch'
                lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
    if download:
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV, 'GET', NHjSru5bCKEXl7sQPpW9RieM, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-PLAY-3rd')
        kKwr9zX358QO47tbu1UC2 = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
        oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"servers"(.*?)info-container', kKwr9zX358QO47tbu1UC2, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if oQuiJvtTzwPZbXd7sf4HcG9:
            c0jtBCYDEkL5HJfVX = oQuiJvtTzwPZbXd7sf4HcG9[0]
            h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<', c0jtBCYDEkL5HJfVX, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            for Ga8xfYU6ht7cHjzn, title, sYm5r9QKRfjoytO in h729UnyEIjoYSNKcLOvqfV4:
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__download' + '____' + sYm5r9QKRfjoytO
                lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def dStQzEeyknDaOs7q(search):
    search, kFdoZmlxSf8shU, showDialogs = gCI13c7MdXA8(search)
    if not search:
        search = GG5Fs0hvURxyBV8gz()
        if not search: return
    search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF, '+')
    url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search?s=' + search
    bsZhnoqjD3U(url, 'search')
    return
def vgP862NBF4UG(url):
    url = url.split('/smartemadfilter?')[0]
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV, 'GET', url, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'SHAHID4U-GET_FILTERS_BLOCKS-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    deib7XxUZCQw8HA1n = []
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('adv-filter(.*?)shows-container', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        deib7XxUZCQw8HA1n = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        V3ODGPc1X9hTi, PP2Kjhwm47VFtgoquiCGcTDOJB16v, tKoDYsOPeyxM = zip(*deib7XxUZCQw8HA1n)
        deib7XxUZCQw8HA1n = zip(PP2Kjhwm47VFtgoquiCGcTDOJB16v, V3ODGPc1X9hTi, tKoDYsOPeyxM)
    return deib7XxUZCQw8HA1n
def OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex):
    items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('value="(.*?)".*?>\s*(.*?)\s*<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    return items
def SHR2zf15lUiajMCvE3T(url):
    if '/smartemadfilter?' not in url: url = url + '/smartemadfilter?'
    gdGWEPpk3frFTQa8wcYhqMyV4 = url.split('/smartemadfilter?')[0]
    jjEqDAJkvVXK5WdC0xSGR2m = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url, 'url')
    url = url.replace(gdGWEPpk3frFTQa8wcYhqMyV4, jjEqDAJkvVXK5WdC0xSGR2m)
    url = url.replace('/smartemadfilter?', '/?')
    return url
oiOLQdnBxYbPJ5czsNr7GejXg = ['quality', 'year', 'genre', 'category']
icLElfdQ3HBwDTs4uogx = ['category', 'genre', 'year']
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(url, filter):
    url = url.split('/smartemadfilter?')[0]
    type, filter = filter.split('___', 1)
    if filter == kh850jKbzmBwY: WQEFAlL7oCZ3XBt, CW52XnyslubD60Y4LNHp3hzZ9VP8 = kh850jKbzmBwY, kh850jKbzmBwY
    else: WQEFAlL7oCZ3XBt, CW52XnyslubD60Y4LNHp3hzZ9VP8 = filter.split('___')
    if type == 'DEFINED_FILTER':
        if icLElfdQ3HBwDTs4uogx[0] + '=' not in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = icLElfdQ3HBwDTs4uogx[0]
        for asKYTS478qkW in range(len(icLElfdQ3HBwDTs4uogx[0:-1])):
            if icLElfdQ3HBwDTs4uogx[asKYTS478qkW] + '=' in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = icLElfdQ3HBwDTs4uogx[asKYTS478qkW + 1]
        oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt + '&' + XvPwmy3axVdD6NIKGb4Ak + '=0'
        oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8 + '&' + XvPwmy3axVdD6NIKGb4Ak + '=0'
        mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ.strip('&') + '___' + oufZ8U7XLDFy4b.strip('&')
        PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8, 'modified_filters')
        O9wzaDlICnq = url + '/smartemadfilter?' + PhFd0yvXWULQIfu9N2pSYDRCx
    elif type == 'FULL_FILTER':
        FCyjlpcBn5OG2Nowxvf6WQS74 = Md2htF3Gi186nWlYkJq(WQEFAlL7oCZ3XBt, 'modified_values')
        FCyjlpcBn5OG2Nowxvf6WQS74 = KsuzxGjOHChbIXrwWm(FCyjlpcBn5OG2Nowxvf6WQS74)
        if CW52XnyslubD60Y4LNHp3hzZ9VP8 != kh850jKbzmBwY: CW52XnyslubD60Y4LNHp3hzZ9VP8 = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8, 'modified_filters')
        if CW52XnyslubD60Y4LNHp3hzZ9VP8 == kh850jKbzmBwY: O9wzaDlICnq = url
        else: O9wzaDlICnq = url + '/smartemadfilter?' + CW52XnyslubD60Y4LNHp3hzZ9VP8
        QQJdiByEeNqLYGs = SHR2zf15lUiajMCvE3T(O9wzaDlICnq)
        EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'أظهار قائمة الفيديو التي تم اختيارها ', QQJdiByEeNqLYGs, 111)
        EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + ' [[   ' + FCyjlpcBn5OG2Nowxvf6WQS74 + '   ]]', QQJdiByEeNqLYGs, 111)
        EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    deib7XxUZCQw8HA1n = vgP862NBF4UG(url)
    dict = {}
    for name, uHwkOpvAPM3bqC72KZstX, ZZDUdXR52CMs9K73Ex in deib7XxUZCQw8HA1n:
        name = name.replace('كل ', kh850jKbzmBwY)
        items = OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex)
        if '=' not in O9wzaDlICnq: O9wzaDlICnq = url
        if type == 'DEFINED_FILTER':
            if XvPwmy3axVdD6NIKGb4Ak != uHwkOpvAPM3bqC72KZstX: continue
            elif len(items) < 2:
                if uHwkOpvAPM3bqC72KZstX == icLElfdQ3HBwDTs4uogx[-1]:
                    QQJdiByEeNqLYGs = SHR2zf15lUiajMCvE3T(O9wzaDlICnq)
                    bsZhnoqjD3U(QQJdiByEeNqLYGs)
                else:
                    cf9bnl3ZAhJLt24qxIFwGzuNsMi(O9wzaDlICnq, 'DEFINED_FILTER___' + mDAEOKl2SQpv71acI4PJj5Hs9XzT)
                return
            else:
                if uHwkOpvAPM3bqC72KZstX == icLElfdQ3HBwDTs4uogx[-1]:
                    QQJdiByEeNqLYGs = SHR2zf15lUiajMCvE3T(O9wzaDlICnq)
                    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'الجميع', QQJdiByEeNqLYGs, 111)
                else:
                    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'الجميع', O9wzaDlICnq, 115, kh850jKbzmBwY, kh850jKbzmBwY, mDAEOKl2SQpv71acI4PJj5Hs9XzT)
        elif type == 'FULL_FILTER':
            oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt + '&' + uHwkOpvAPM3bqC72KZstX + '=0'
            oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8 + '&' + uHwkOpvAPM3bqC72KZstX + '=0'
            mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ + '___' + oufZ8U7XLDFy4b
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'الجميع :' + name, O9wzaDlICnq, 114, kh850jKbzmBwY, kh850jKbzmBwY, mDAEOKl2SQpv71acI4PJj5Hs9XzT)
        dict[uHwkOpvAPM3bqC72KZstX] = {}
        for value, OSvbC40RHt2AWY in items:
            if value == '196533': OSvbC40RHt2AWY = 'أفلام نيتفلكس'
            elif value == '196531': OSvbC40RHt2AWY = 'مسلسلات نيتفلكس'
            if OSvbC40RHt2AWY in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
            dict[uHwkOpvAPM3bqC72KZstX][value] = OSvbC40RHt2AWY
            oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt + '&' + uHwkOpvAPM3bqC72KZstX + '=' + OSvbC40RHt2AWY
            oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8 + '&' + uHwkOpvAPM3bqC72KZstX + '=' + value
            qCdAhU0NW12mBS9neTQgwi = oXj3aANJy9KfGnze0xY2Lu41OZQ + '___' + oufZ8U7XLDFy4b
            title = OSvbC40RHt2AWY + ' :'
            title = OSvbC40RHt2AWY + ' :' + name
            if type == 'FULL_FILTER': EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, url, 114, kh850jKbzmBwY, kh850jKbzmBwY, qCdAhU0NW12mBS9neTQgwi)
            elif type == 'DEFINED_FILTER' and icLElfdQ3HBwDTs4uogx[-2] + '=' in WQEFAlL7oCZ3XBt:
                PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(oufZ8U7XLDFy4b, 'modified_filters')
                O9wzaDlICnq = url + '/smartemadfilter?' + PhFd0yvXWULQIfu9N2pSYDRCx
                QQJdiByEeNqLYGs = SHR2zf15lUiajMCvE3T(O9wzaDlICnq)
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, QQJdiByEeNqLYGs, 111)
            else:
                EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, url, 115, kh850jKbzmBwY, kh850jKbzmBwY, qCdAhU0NW12mBS9neTQgwi)
    return
def Md2htF3Gi186nWlYkJq(T3IPgzYmNnC9tkupohdRj2Qf, mode):
    T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.replace('=&', '=0&')
    T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.strip('&')
    yXeoduEjYKJLf0OinrlVzN3 = {}
    if '=' in T3IPgzYmNnC9tkupohdRj2Qf:
        items = T3IPgzYmNnC9tkupohdRj2Qf.split('&')
        for JJNIsO8Vcbx0 in items:
            moT0kOcKq7JPVSt3L, value = JJNIsO8Vcbx0.split('=')
            yXeoduEjYKJLf0OinrlVzN3[moT0kOcKq7JPVSt3L] = value
    jjSBkesYpFQc6A1q8RfVJgW = kh850jKbzmBwY
    for key in oiOLQdnBxYbPJ5czsNr7GejXg:
        if key in list(yXeoduEjYKJLf0OinrlVzN3.keys()): value = yXeoduEjYKJLf0OinrlVzN3[key]
        else: value = '0'
        if '%' not in value: value = ioZ083zxYk(value)
        if mode == 'modified_values' and value != '0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW + ' + ' + value
        elif mode == 'modified_filters' and value != '0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW + '&' + key + '=' + value
        elif mode == 'all': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW + '&' + key + '=' + value
    jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip(' + ')
    jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip('&')
    jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.replace('=0', '=')
    return jjSBkesYpFQc6A1q8RfVJgW
﻿# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn,oGZp6d5h91cxY):
	if oGZp6d5h91cxY==kh850jKbzmBwY: return
	if eYN1APt8aZflKmByj0ioGzn==1:
		sUDiK1AvMuwP6aY = SSDm5G4FUAzu26LbKqpvV79d.getCurrentWindowDialogId()
		lK8uaL1snZ7cXFwGe = SSDm5G4FUAzu26LbKqpvV79d.Window(sUDiK1AvMuwP6aY)
		oGZp6d5h91cxY = q59OjVhmPrB4a8bLFokl0xEAJnZX1s(oGZp6d5h91cxY)
		lK8uaL1snZ7cXFwGe.getControl(311).setLabel(oGZp6d5h91cxY)
	if eYN1APt8aZflKmByj0ioGzn==0:
		x9XP1ec8DolGwABgkiIJyq='X'
		if eOQJrvLAZC: dESp7yxOwgtLu9mrMbXiN0qR = isinstance(oGZp6d5h91cxY,str)
		else: dESp7yxOwgtLu9mrMbXiN0qR = isinstance(oGZp6d5h91cxY,unicode)
		if dESp7yxOwgtLu9mrMbXiN0qR==True: x9XP1ec8DolGwABgkiIJyq='U'
		nnrfVhcQFzRCbLWDEKi=str(type(oGZp6d5h91cxY))+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+oGZp6d5h91cxY+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+x9XP1ec8DolGwABgkiIJyq+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF
		for asKYTS478qkW in range(0,len(oGZp6d5h91cxY),1):
			nnrfVhcQFzRCbLWDEKi += hex(ord(oGZp6d5h91cxY[asKYTS478qkW])).replace('0x',kh850jKbzmBwY)+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF
		oGZp6d5h91cxY = q59OjVhmPrB4a8bLFokl0xEAJnZX1s(oGZp6d5h91cxY)
		x9XP1ec8DolGwABgkiIJyq='X'
		if eOQJrvLAZC: dESp7yxOwgtLu9mrMbXiN0qR = isinstance(oGZp6d5h91cxY, str)
		else: dESp7yxOwgtLu9mrMbXiN0qR = isinstance(oGZp6d5h91cxY, unicode)
		if dESp7yxOwgtLu9mrMbXiN0qR==True: x9XP1ec8DolGwABgkiIJyq='U'
		byYnQt9VlBDhf=str(type(oGZp6d5h91cxY))+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+oGZp6d5h91cxY+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+x9XP1ec8DolGwABgkiIJyq+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF
		for asKYTS478qkW in range(0,len(oGZp6d5h91cxY),1):
			byYnQt9VlBDhf += hex(ord(oGZp6d5h91cxY[asKYTS478qkW])).replace('0x',kh850jKbzmBwY)+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'MYCIMA'
headers = {'User-Agent':kh850jKbzmBwY}
GalrcVUMy8bzORWX5E0exhYivBwgk = '_MCM_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['مصارعة حرة','wwe']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==360: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==361: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==362: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==363: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url,text)
	elif mode==364: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'CATEGORIES___'+text)
	elif mode==365: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'FILTERS___'+text)
	elif mode==366: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==369: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text,url)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',WLjaXVNk2dnAJzPpy6OlMv4qoi9,369,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر محدد',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/AjaxCenter/RightBar',364)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر كامل',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/AjaxCenter/RightBar',365)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MYCIMA-MENU-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="menu-item.*?href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title==kh850jKbzmBwY: continue
			if any(value in title.lower() for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,366)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('hoverable activable(.*?)hoverable activable',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,366,NWqAr40jTLlMBemn3o79y)
	return uP1m46pAK5a3UgdqvBz9rnL
def CC6NMTjSO2g(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MYCIMA-SUBMENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if 'class="Slider--Grid"' in uP1m46pAK5a3UgdqvBz9rnL:
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',url,361,kh850jKbzmBwY,kh850jKbzmBwY,'featured')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="list--Tabsui"(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,361)
	return
def bsZhnoqjD3U(bjRnSzJeaUo5QqwEgk17vC3r9POlh,type=kh850jKbzmBwY):
	if '::' in bjRnSzJeaUo5QqwEgk17vC3r9POlh:
		QQJdiByEeNqLYGs,url = bjRnSzJeaUo5QqwEgk17vC3r9POlh.split('::')
		fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(QQJdiByEeNqLYGs,'url')
		url = fDKF4iZ5rz7McduTexbA2RpPs+url
	else: url,QQJdiByEeNqLYGs = bjRnSzJeaUo5QqwEgk17vC3r9POlh,bjRnSzJeaUo5QqwEgk17vC3r9POlh
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MYCIMA-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if type=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif type=='filters':
		liroJ6qCK9k = [uP1m46pAK5a3UgdqvBz9rnL.replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace('\\"','"')]
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('GridItem"><a href="([^"]*)" title="([^"]*)".*?url\((.*?)\)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in items:
			if any(value in title.lower() for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
			NWqAr40jTLlMBemn3o79y = Z4CP1xs5w7fi(NWqAr40jTLlMBemn3o79y)
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			title = Z4CP1xs5w7fi(title)
			title = title.replace('مشاهدة ',kh850jKbzmBwY)
			if '/series/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,363,NWqAr40jTLlMBemn3o79y)
			elif 'حلقة' in title:
				WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) +حلقة +\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				if WULSmfNH09tPIv58snzpCkR: title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
				if title not in SHTvIuhX52dxQRsWA:
					SHTvIuhX52dxQRsWA.append(title)
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,363,NWqAr40jTLlMBemn3o79y)
			else:
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,362,NWqAr40jTLlMBemn3o79y)
		if type=='filters':
			BeaPvLOV5WQEgZpRbh = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"more_button_page":(.*?),',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if BeaPvLOV5WQEgZpRbh:
				count = BeaPvLOV5WQEgZpRbh[0]
				Ga8xfYU6ht7cHjzn = url+'/offset/'+count
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة أخرى',Ga8xfYU6ht7cHjzn,361,kh850jKbzmBwY,kh850jKbzmBwY,'filters')
		elif type==kh850jKbzmBwY:
			liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="pagination(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if liroJ6qCK9k:
				ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
				items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
				for Ga8xfYU6ht7cHjzn,title in items:
					title = 'صفحة '+E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,361)
	return
def do7Es2fUtFlM8ScLx(url,type=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MYCIMA-EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	uP1m46pAK5a3UgdqvBz9rnL = KsuzxGjOHChbIXrwWm(uP1m46pAK5a3UgdqvBz9rnL)
	name = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('itemprop="item" href=".*?/series/(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if name: name = name[-1].replace('-',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	if 'موسم' in name and type==kh850jKbzmBwY:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	else: name = name
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="Seasons--Episodes"(.*?)</singlesection',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		if type==kh850jKbzmBwY:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,363,kh850jKbzmBwY,kh850jKbzmBwY,'episodes')
		if len(Y3Ny5eLHdp.menuItemsLIST)==0:
			c0jtBCYDEkL5HJfVX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="Episodes--Seasons--Episodes"(.*?)&&',ZZDUdXR52CMs9K73Ex+'&&',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if c0jtBCYDEkL5HJfVX: ZZDUdXR52CMs9K73Ex = c0jtBCYDEkL5HJfVX[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<episodeTitle>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				title = name+' - '+title
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,362)
	if len(Y3Ny5eLHdp.menuItemsLIST)==0:
		title = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<title>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',kh850jKbzmBwY).replace('مشاهدة ',kh850jKbzmBwY)
		else: title = 'ملف التشغيل'
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,362)
	return
def yv8LezRQifhw1Kx(url):
	lnYtOIQ4Rkh386Bca7 = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MYCIMA-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV:
		ZspMxOvY50RNBKew1JqzD26tLV = [ZspMxOvY50RNBKew1JqzD26tLV[0][0],ZspMxOvY50RNBKew1JqzD26tLV[0][1]]
		if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-url="(.*?)".*?strong>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,name in items:
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			if name=='سيرفر ماي سيما': name = 'mycima'
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+name+'__watch'
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="List--Download(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,sYm5r9QKRfjoytO in items:
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
			sYm5r9QKRfjoytO = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('\d\d\d+',sYm5r9QKRfjoytO,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if sYm5r9QKRfjoytO: sYm5r9QKRfjoytO = '____'+sYm5r9QKRfjoytO[0]
			else: sYm5r9QKRfjoytO = kh850jKbzmBwY
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named=mycima'+'__download'+sYm5r9QKRfjoytO
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search,X9jKbFyEoWRqr0wHsapA87=kh850jKbzmBwY):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	lnYtOIQ4Rkh386Bca7 = ['/list',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,'/list/series','/list/anime','/list/tv']
	u6X0ermz2hnb4FPM7oSyGIA1V = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('اختر النوع المطلوب:', u6X0ermz2hnb4FPM7oSyGIA1V)
		if TTn7mZzPRjq5GBESh8aKy==-1: return
	else: TTn7mZzPRjq5GBESh8aKy = 0
	if X9jKbFyEoWRqr0wHsapA87==kh850jKbzmBwY:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,False,kh850jKbzmBwY,'MYCIMA-SEARCH-1st')
		X9jKbFyEoWRqr0wHsapA87 = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Location']
		X9jKbFyEoWRqr0wHsapA87 = X9jKbFyEoWRqr0wHsapA87.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	O9wzaDlICnq = X9jKbFyEoWRqr0wHsapA87+'/search/'+search+lnYtOIQ4Rkh386Bca7[TTn7mZzPRjq5GBESh8aKy]
	bsZhnoqjD3U(O9wzaDlICnq)
	return
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(bjRnSzJeaUo5QqwEgk17vC3r9POlh,filter):
	if '??' in bjRnSzJeaUo5QqwEgk17vC3r9POlh: url = bjRnSzJeaUo5QqwEgk17vC3r9POlh.split('//getposts??')[0]
	else: url = bjRnSzJeaUo5QqwEgk17vC3r9POlh
	filter = filter.replace('_FORGETRESULTS_',kh850jKbzmBwY)
	type,filter = filter.split('___',1)
	if filter==kh850jKbzmBwY: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = kh850jKbzmBwY,kh850jKbzmBwY
	else: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = filter.split('___')
	if type=='CATEGORIES':
		if aDueNVf7CBtO[0]+'==' not in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = aDueNVf7CBtO[0]
		for asKYTS478qkW in range(len(aDueNVf7CBtO[0:-1])):
			if aDueNVf7CBtO[asKYTS478qkW]+'==' in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = aDueNVf7CBtO[asKYTS478qkW+1]
		oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&&'+XvPwmy3axVdD6NIKGb4Ak+'==0'
		oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&&'+XvPwmy3axVdD6NIKGb4Ak+'==0'
		mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ.strip('&&')+'___'+oufZ8U7XLDFy4b.strip('&&')
		PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		O9wzaDlICnq = url+'//getposts??'+PhFd0yvXWULQIfu9N2pSYDRCx
	elif type=='FILTERS':
		FCyjlpcBn5OG2Nowxvf6WQS74 = Md2htF3Gi186nWlYkJq(WQEFAlL7oCZ3XBt,'modified_values')
		FCyjlpcBn5OG2Nowxvf6WQS74 = KsuzxGjOHChbIXrwWm(FCyjlpcBn5OG2Nowxvf6WQS74)
		if CW52XnyslubD60Y4LNHp3hzZ9VP8!=kh850jKbzmBwY: CW52XnyslubD60Y4LNHp3hzZ9VP8 = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		if CW52XnyslubD60Y4LNHp3hzZ9VP8==kh850jKbzmBwY: O9wzaDlICnq = url
		else: O9wzaDlICnq = url+'//getposts??'+CW52XnyslubD60Y4LNHp3hzZ9VP8
		DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9 = GD0TY9iUgdM3(O9wzaDlICnq,bjRnSzJeaUo5QqwEgk17vC3r9POlh)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أظهار قائمة الفيديو التي تم اختيارها ',DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9,361,kh850jKbzmBwY,kh850jKbzmBwY,'filters')
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+' [[   '+FCyjlpcBn5OG2Nowxvf6WQS74+'   ]]',DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9,361,kh850jKbzmBwY,kh850jKbzmBwY,'filters')
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'MYCIMA-FILTERS_MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	uP1m46pAK5a3UgdqvBz9rnL = uP1m46pAK5a3UgdqvBz9rnL.replace('\\"','"').replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<mycima--filter(.*?)</mycima--filter>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not liroJ6qCK9k: return
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	deib7XxUZCQw8HA1n = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',ZZDUdXR52CMs9K73Ex+'<filterbox',sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	dict = {}
	for uHwkOpvAPM3bqC72KZstX,name,ZZDUdXR52CMs9K73Ex in deib7XxUZCQw8HA1n:
		name = Z4CP1xs5w7fi(name)
		if 'interest' in uHwkOpvAPM3bqC72KZstX: continue
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if '==' not in O9wzaDlICnq: O9wzaDlICnq = url
		if type=='CATEGORIES':
			if XvPwmy3axVdD6NIKGb4Ak!=uHwkOpvAPM3bqC72KZstX: continue
			elif len(items)<=1:
				if uHwkOpvAPM3bqC72KZstX==aDueNVf7CBtO[-1]: bsZhnoqjD3U(O9wzaDlICnq)
				else: cf9bnl3ZAhJLt24qxIFwGzuNsMi(O9wzaDlICnq,'CATEGORIES___'+mDAEOKl2SQpv71acI4PJj5Hs9XzT)
				return
			else:
				DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9 = GD0TY9iUgdM3(O9wzaDlICnq,bjRnSzJeaUo5QqwEgk17vC3r9POlh)
				if uHwkOpvAPM3bqC72KZstX==aDueNVf7CBtO[-1]:
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9,361,kh850jKbzmBwY,kh850jKbzmBwY,'filters')
				else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,364,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		elif type=='FILTERS':
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&&'+uHwkOpvAPM3bqC72KZstX+'==0'
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&&'+uHwkOpvAPM3bqC72KZstX+'==0'
			mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name+': الجميع',O9wzaDlICnq,365,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT+'_FORGETRESULTS_')
		dict[uHwkOpvAPM3bqC72KZstX] = {}
		for value,OSvbC40RHt2AWY in items:
			name = Z4CP1xs5w7fi(name)
			OSvbC40RHt2AWY = Z4CP1xs5w7fi(OSvbC40RHt2AWY)
			if value=='r' or value=='nc-17': continue
			if any(value in OSvbC40RHt2AWY.lower() for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
			if 'http' in OSvbC40RHt2AWY: continue
			if 'الكل' in OSvbC40RHt2AWY: continue
			if 'n-a' in value: continue
			if OSvbC40RHt2AWY==kh850jKbzmBwY: OSvbC40RHt2AWY = value
			q2qOZJQiy7ugcjprh64RLdW = OSvbC40RHt2AWY
			FEGJjiSZXB5pNV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<name>(.*?)</name>',OSvbC40RHt2AWY,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if FEGJjiSZXB5pNV: q2qOZJQiy7ugcjprh64RLdW = FEGJjiSZXB5pNV[0]
			EVfKyFrmX1Mpb62tLuHS5w3W = name+': '+q2qOZJQiy7ugcjprh64RLdW
			dict[uHwkOpvAPM3bqC72KZstX][value] = EVfKyFrmX1Mpb62tLuHS5w3W
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&&'+uHwkOpvAPM3bqC72KZstX+'=='+q2qOZJQiy7ugcjprh64RLdW
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&&'+uHwkOpvAPM3bqC72KZstX+'=='+value
			qCdAhU0NW12mBS9neTQgwi = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			if type=='FILTERS':
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+EVfKyFrmX1Mpb62tLuHS5w3W,url,365,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and aDueNVf7CBtO[-2]+'==' in WQEFAlL7oCZ3XBt:
				PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(oufZ8U7XLDFy4b,'modified_filters')
				QQJdiByEeNqLYGs = url+'//getposts??'+PhFd0yvXWULQIfu9N2pSYDRCx
				DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9 = GD0TY9iUgdM3(QQJdiByEeNqLYGs,bjRnSzJeaUo5QqwEgk17vC3r9POlh)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+EVfKyFrmX1Mpb62tLuHS5w3W,DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9,361,kh850jKbzmBwY,kh850jKbzmBwY,'filters')
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+EVfKyFrmX1Mpb62tLuHS5w3W,url,364,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
	return
aDueNVf7CBtO = ['genre','release-year','nation']
ddOVBszlewvyPqKUExIgT = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def GD0TY9iUgdM3(O9wzaDlICnq,QQJdiByEeNqLYGs):
	if '/AjaxCenter/RightBar' in O9wzaDlICnq: O9wzaDlICnq = O9wzaDlICnq.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	O9wzaDlICnq = O9wzaDlICnq.replace('//getposts??','::/AjaxCenter/Filtering/')
	O9wzaDlICnq = O9wzaDlICnq.replace('==',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	O9wzaDlICnq = O9wzaDlICnq.replace('&&',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	return O9wzaDlICnq
def Md2htF3Gi186nWlYkJq(T3IPgzYmNnC9tkupohdRj2Qf,mode):
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.strip('&&')
	yXeoduEjYKJLf0OinrlVzN3,jjSBkesYpFQc6A1q8RfVJgW = {},kh850jKbzmBwY
	if '==' in T3IPgzYmNnC9tkupohdRj2Qf:
		items = T3IPgzYmNnC9tkupohdRj2Qf.split('&&')
		for JJNIsO8Vcbx0 in items:
			moT0kOcKq7JPVSt3L,value = JJNIsO8Vcbx0.split('==')
			yXeoduEjYKJLf0OinrlVzN3[moT0kOcKq7JPVSt3L] = value
	for key in ddOVBszlewvyPqKUExIgT:
		if key in list(yXeoduEjYKJLf0OinrlVzN3.keys()): value = yXeoduEjYKJLf0OinrlVzN3[key]
		else: value = '0'
		if '%' not in value: value = ioZ083zxYk(value)
		if mode=='modified_values' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+' + '+value
		elif mode=='modified_filters' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&&'+key+'=='+value
		elif mode=='all': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&&'+key+'=='+value
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip(' + ')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip('&&')
	return jjSBkesYpFQc6A1q8RfVJgW
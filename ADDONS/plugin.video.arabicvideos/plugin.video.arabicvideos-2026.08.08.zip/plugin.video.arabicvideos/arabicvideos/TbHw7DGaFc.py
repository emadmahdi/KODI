# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'KATKOTTV'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_KTV_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = []
def Z6V4AKYFUSWMmqBNXJ72p(mode, url, text):
    if mode == 810: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
    elif mode == 811: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url, text)
    elif mode == 812: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
    elif mode == 813: PP3FsDicLyWuTR7GV5Ia = sGaLKXvqkC(url)
    elif mode == 819: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
    else: PP3FsDicLyWuTR7GV5Ia = False
    return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', WLjaXVNk2dnAJzPpy6OlMv4qoi9, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'KATKOTTV-MENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'بحث في الموقع', kh850jKbzmBwY, 819, kh850jKbzmBwY, kh850jKbzmBwY, '_REMEMBERRESULTS_')
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"primary-links"(.*?)"most-viewed"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
    items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    for Ga8xfYU6ht7cHjzn, title in items:
        if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
        EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 811)
    return
def bsZhnoqjD3U(url, type=kh850jKbzmBwY):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'KATKOTTV-TITLES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-content"(.*?)"footer"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        SHTvIuhX52dxQRsWA = []
        for NWqAr40jTLlMBemn3o79y, Ga8xfYU6ht7cHjzn, title in items:
            title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
            WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+', title, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
            if 'episodes' not in type and WULSmfNH09tPIv58snzpCkR:
                title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
                title = title.replace('اون لاين', kh850jKbzmBwY)
                if title not in SHTvIuhX52dxQRsWA:
                    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 813, NWqAr40jTLlMBemn3o79y)
                    SHTvIuhX52dxQRsWA.append(title)
            else:
                EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 812, NWqAr40jTLlMBemn3o79y)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("'pagination'(.*?)footer", uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        type = 'episodes_pages' if 'episodes' in type else 'pages'
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 811, kh850jKbzmBwY, kh850jKbzmBwY, type)
    return
def sGaLKXvqkC(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'KATKOTTV-SERIES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"category".*?href="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if Ga8xfYU6ht7cHjzn: bsZhnoqjD3U(Ga8xfYU6ht7cHjzn[0], 'episodes')
    return
def yv8LezRQifhw1Kx(url):
    owMxje0p9Ya3CkhJDX = []
    O9wzaDlICnq = url + '?do=watch'
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', O9wzaDlICnq, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'KATKOTTV-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('embed-source" src="(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if Ga8xfYU6ht7cHjzn:
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
        owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    else:
        OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'KATKOTTV-PLAY-2nd')
        uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
        LsgQIK6E08od3r5 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('post=(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if LsgQIK6E08od3r5:
            LsgQIK6E08od3r5 = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(LsgQIK6E08od3r5[0])
            if eOQJrvLAZC: LsgQIK6E08od3r5 = LsgQIK6E08od3r5.decode(NVbhZ0DTpOkCA)
            LsgQIK6E08od3r5 = tmYCsS329HanzjLFbJP('dict', LsgQIK6E08od3r5)
            Sp6qOyDB0nt5Qo4KwbPfcWYe = LsgQIK6E08od3r5['servers']
            LtaDBqr1oOpP0Yz3g4ci8 = list(Sp6qOyDB0nt5Qo4KwbPfcWYe.keys())
            Sp6qOyDB0nt5Qo4KwbPfcWYe = list(Sp6qOyDB0nt5Qo4KwbPfcWYe.values())
            cbEeOrp1di2TL7GXnguA6f = zip(LtaDBqr1oOpP0Yz3g4ci8, Sp6qOyDB0nt5Qo4KwbPfcWYe)
            for title, Ga8xfYU6ht7cHjzn in cbEeOrp1di2TL7GXnguA6f:
                Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '?named=' + title + '__watch'
                owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def dStQzEeyknDaOs7q(search):
    search, kFdoZmlxSf8shU, showDialogs = gCI13c7MdXA8(search)
    if search == kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
    if search == kh850jKbzmBwY: return
    search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF, '+')
    url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/?s=' + search
    bsZhnoqjD3U(url, 'search')
    return
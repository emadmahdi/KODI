# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'ALARAB'
headers = {'User-Agent':kh850jKbzmBwY}
GalrcVUMy8bzORWX5E0exhYivBwgk = '_KLA_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==10: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==11: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==12: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==13: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==14: PP3FsDicLyWuTR7GV5Ia = Em1lqDXHLbM6x0cv8Jiag()
	elif mode==15: PP3FsDicLyWuTR7GV5Ia = ff0rAZ39u4FV()
	elif mode==16: PP3FsDicLyWuTR7GV5Ia = pGim6EBLcDRZyarFJKMn9Hq()
	elif mode==19: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,19,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'آخر الإضافات',kh850jKbzmBwY,14)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان',kh850jKbzmBwY,15)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'ALARAB-MENU-1st')
	liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="nav-slider"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	k5MEtJ0q3ABUKgLWf8jHuNlI6 = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',k5MEtJ0q3ABUKgLWf8jHuNlI6,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,11)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="navbar"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	c0jtBCYDEkL5HJfVX = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',c0jtBCYDEkL5HJfVX,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,11)
	return uP1m46pAK5a3UgdqvBz9rnL
def ff0rAZ39u4FV():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'جميع المسلسلات العربية',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/view-8/مسلسلات-عربية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات السنة الأخيرة',kh850jKbzmBwY,16)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان الأخيرة 1',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/view-8/مسلسلات-رمضان-2022',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان الأخيرة 2',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/view-8/مسلسلات-رمضان-2023',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2023',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2023/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2022',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2022/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2021',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2021/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2020',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2020/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2019',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2019/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2018',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2018/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2017',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2017/مصرية',11)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات رمضان 2016',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/ramadan2016/مصرية',11)
	return
def Em1lqDXHLbM6x0cv8Jiag():
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,True,'ALARAB-LATEST-1st')
	liroJ6qCK9k=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('heading-top(.*?)div class=',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]+liroJ6qCK9k[1]
	items=sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
		if 'series' in url: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,11,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,12,NWqAr40jTLlMBemn3o79y)
	return
def bsZhnoqjD3U(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,True,True,'ALARAB-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('video-category(.*?)right_content',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not liroJ6qCK9k: return
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	TCJsHMedRrK8G = False
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA,t9T0AqyFcxHVzpnMWlad1CLk4ZhE = [],[]
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		if title==kh850jKbzmBwY: title = Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1].replace('-',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		hUfv2IrbNmXRzGPMdt = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(\d+)',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if hUfv2IrbNmXRzGPMdt: hUfv2IrbNmXRzGPMdt = int(hUfv2IrbNmXRzGPMdt[0])
		else: hUfv2IrbNmXRzGPMdt = 0
		t9T0AqyFcxHVzpnMWlad1CLk4ZhE.append([NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title,hUfv2IrbNmXRzGPMdt])
	t9T0AqyFcxHVzpnMWlad1CLk4ZhE = sorted(t9T0AqyFcxHVzpnMWlad1CLk4ZhE, reverse=True, key=lambda key: key[3])
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title,hUfv2IrbNmXRzGPMdt in t9T0AqyFcxHVzpnMWlad1CLk4ZhE:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',kh850jKbzmBwY)
		title = title.replace('عالية على العرب',kh850jKbzmBwY)
		title = title.replace('مشاهدة مباشرة',kh850jKbzmBwY)
		title = title.replace('اون لاين',kh850jKbzmBwY)
		title = title.replace('اونلاين',kh850jKbzmBwY)
		title = title.replace('بجودة عالية',kh850jKbzmBwY)
		title = title.replace('جودة عالية',kh850jKbzmBwY)
		title = title.replace('بدون تحميل',kh850jKbzmBwY)
		title = title.replace('على العرب',kh850jKbzmBwY)
		title = title.replace('مباشرة',kh850jKbzmBwY)
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		title = '_MOD_'+title
		EVfKyFrmX1Mpb62tLuHS5w3W = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) الحلقة \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if WULSmfNH09tPIv58snzpCkR: EVfKyFrmX1Mpb62tLuHS5w3W = WULSmfNH09tPIv58snzpCkR[0]
		if EVfKyFrmX1Mpb62tLuHS5w3W not in SHTvIuhX52dxQRsWA:
			SHTvIuhX52dxQRsWA.append(EVfKyFrmX1Mpb62tLuHS5w3W)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+EVfKyFrmX1Mpb62tLuHS5w3W,Ga8xfYU6ht7cHjzn,13,NWqAr40jTLlMBemn3o79y)
				TCJsHMedRrK8G = True
			elif 'series' in Ga8xfYU6ht7cHjzn:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,11,NWqAr40jTLlMBemn3o79y)
				TCJsHMedRrK8G = True
			else:
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,12,NWqAr40jTLlMBemn3o79y)
				TCJsHMedRrK8G = True
	if TCJsHMedRrK8G:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('tsc_3d_button red.*?href="([^"]*)" title="([^"]*)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,QPZDaMKgtTUyNjB7EqvOLwph in items:
			url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+QPZDaMKgtTUyNjB7EqvOLwph,url,11)
	return
def do7Es2fUtFlM8ScLx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,True,'ALARAB-EPISODES-1st')
	RRzFJb0tuU = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(/series.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9+RRzFJb0tuU[0]
	PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(O9wzaDlICnq)
	return
def yv8LezRQifhw1Kx(url):
	lnYtOIQ4Rkh386Bca7 = []
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(qogplQ5vHLYt8Ci1fknObwMThe,url,kh850jKbzmBwY,headers,True,'ALARAB-PLAY-1st')
	O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="resp-iframe" src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if O9wzaDlICnq:
		O9wzaDlICnq = O9wzaDlICnq[0]
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('^(http.*?)(http.*?)$',O9wzaDlICnq,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if Sp6qOyDB0nt5Qo4KwbPfcWYe:
			uWLHzodcJeGxVFP2Eqr0fZUwKb5 = Sp6qOyDB0nt5Qo4KwbPfcWYe[0][0]
			OuUfvj3DpWPi58Vw,QlhMfC5pcrI = Sp6qOyDB0nt5Qo4KwbPfcWYe[0][1].rsplit(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,1)
			QQJdiByEeNqLYGs = OuUfvj3DpWPi58Vw+'?named=__watch'
			lnYtOIQ4Rkh386Bca7.append(QQJdiByEeNqLYGs)
			DLxe0nHGOjr7tZgIY6Bw32oaCXuVE9 = uWLHzodcJeGxVFP2Eqr0fZUwKb5+QlhMfC5pcrI
		else:
			kKwr9zX358QO47tbu1UC2 = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,headers,False,'ALARAB-PLAY-2nd')
			O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"src": "(.*?)"',kKwr9zX358QO47tbu1UC2,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if O9wzaDlICnq:
				O9wzaDlICnq = O9wzaDlICnq[0]+'?named=__watch__m3u8'
				lnYtOIQ4Rkh386Bca7.append(O9wzaDlICnq)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('searchBox(.*?)<style>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		O9wzaDlICnq = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if O9wzaDlICnq:
			O9wzaDlICnq = O9wzaDlICnq[0]+'?named=__watch'
			lnYtOIQ4Rkh386Bca7.append(O9wzaDlICnq)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def pGim6EBLcDRZyarFJKMn9Hq():
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,True,'ALARAB-RAMADAN-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="content_sec"(.*?)id="left_content"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	qWyu1D0dHZFL3jTOIm = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('/ramadan([0-9]+)/',str(items),sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	qWyu1D0dHZFL3jTOIm = qWyu1D0dHZFL3jTOIm[0]
	for Ga8xfYU6ht7cHjzn,title in items:
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+qWyu1D0dHZFL3jTOIm
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,11)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + "/q/" + BkpEeTDInR6LQFG2m1Ns
	PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
headers = { 'User-Agent' : kh850jKbzmBwY }
vkNGie5mhCqoTFRzPKaML0x6 = 'AKWAM'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_AKW_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QyT7R9hstr1mg = kh850jKbzmBwY
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==240: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==241: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==242: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==243: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==244: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'FILTERS___'+text)
	elif mode==245: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'CATEGORIES___'+text)
	elif mode==246: PP3FsDicLyWuTR7GV5Ia = UMBji0qxQ5fuaG3PtCZX9ye7Igw8(url)
	elif mode==247: PP3FsDicLyWuTR7GV5Ia = oHvFkzli0nWS2Bpu3RONAJ(url)
	elif mode==248: PP3FsDicLyWuTR7GV5Ia = i4tEhHbBDVoyT1sYU30pZx()
	elif mode==249: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def i4tEhHbBDVoyT1sYU30pZx():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'AKWAM-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	fhBg9C7W0PE14GZSukwzXTA3KJQY = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('home-site-btn-container.*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if fhBg9C7W0PE14GZSukwzXTA3KJQY: fhBg9C7W0PE14GZSukwzXTA3KJQY = fhBg9C7W0PE14GZSukwzXTA3KJQY[0]
	else: fhBg9C7W0PE14GZSukwzXTA3KJQY = WLjaXVNk2dnAJzPpy6OlMv4qoi9
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',fhBg9C7W0PE14GZSukwzXTA3KJQY,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'AKWAM-MENU-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,249,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر محدد',WLjaXVNk2dnAJzPpy6OlMv4qoi9,246)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر كامل',WLjaXVNk2dnAJzPpy6OlMv4qoi9,247)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',fhBg9C7W0PE14GZSukwzXTA3KJQY,241,kh850jKbzmBwY,kh850jKbzmBwY,'featured')
	JZT62Iozr8Ba = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('recently-container.*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	Ga8xfYU6ht7cHjzn = JZT62Iozr8Ba[0]
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'أضيف حديثا',Ga8xfYU6ht7cHjzn,241)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,name,ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
		if name in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,241)
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			title = name+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+title
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,241)
	return
def UMBji0qxQ5fuaG3PtCZX9ye7Igw8(website=kh850jKbzmBwY):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'AKWAM-MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="menu(.*?)<nav',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?text">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title not in QQeT5Ntzv2ysxVmLHj1adM40iYpk:
				title = title+' مصنفة'
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,245)
		if website==kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	return uP1m46pAK5a3UgdqvBz9rnL
def oHvFkzli0nWS2Bpu3RONAJ(website=kh850jKbzmBwY):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,'AKWAM-MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="menu(.*?)<nav',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?text">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title not in QQeT5Ntzv2ysxVmLHj1adM40iYpk:
				title = title+' مفلترة'
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,244)
		if website==kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	return uP1m46pAK5a3UgdqvBz9rnL
def bsZhnoqjD3U(url,type=kh850jKbzmBwY):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('swiper-container(.*?)swiper-button-prev',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="widget"(.*?)main-footer',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not items:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
			if '/series/' in Ga8xfYU6ht7cHjzn or '/shows/' in Ga8xfYU6ht7cHjzn:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,242,NWqAr40jTLlMBemn3o79y)
			elif '/movies/' in Ga8xfYU6ht7cHjzn:
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,243,NWqAr40jTLlMBemn3o79y)
			elif '/games/' not in Ga8xfYU6ht7cHjzn:
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,243,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			Ga8xfYU6ht7cHjzn = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(Ga8xfYU6ht7cHjzn)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,241)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search?q='+BkpEeTDInR6LQFG2m1Ns
	PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	return
def do7Es2fUtFlM8ScLx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in uP1m46pAK5a3UgdqvBz9rnL:
		NWqAr40jTLlMBemn3o79y = ppNwDFByU1dZn5ca.getInfoLabel('ListItem.Icon')
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+'رابط التشغيل',url,243,NWqAr40jTLlMBemn3o79y)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('-episodes">(.*?)<div class="widget-4',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		hNDb2sI34dvRnlXZHMz6YfkuOSV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in hNDb2sI34dvRnlXZHMz6YfkuOSV:
			title = title.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,242,NWqAr40jTLlMBemn3o79y)
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,243,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,headers,True,'AKWAM-PLAY-1st')
	ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('badge-danger.*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	rgDROZTUtwb8Q0fhYx9WEXL = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('li><a href="#(.*?)".*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	lnYtOIQ4Rkh386Bca7,x2xi0tpFnQgNmaJ4LR,tKoDYsOPeyxM,FUC9OmHZqPky0WGAJoX = [],[],[],[]
	if rgDROZTUtwb8Q0fhYx9WEXL:
		uayM539UAPSgpYjhs = 'mp4'
		for cmt3w1CPlkTzjAKieugL6vWFb,sYm5r9QKRfjoytO in rgDROZTUtwb8Q0fhYx9WEXL:
			liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('tab-content quality" id="'+cmt3w1CPlkTzjAKieugL6vWFb+'".*?</div>.\s*</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			tKoDYsOPeyxM.append(ZZDUdXR52CMs9K73Ex)
			FUC9OmHZqPky0WGAJoX.append(sYm5r9QKRfjoytO)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="qualities(.*?)<h3.*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			ZZDUdXR52CMs9K73Ex,filename = liroJ6qCK9k[0]
			OgN2S0jPCEi8JqXtaLoucbsDZTUB = ['zip','rar','txt','pdf','htm','tar','iso','html']
			uayM539UAPSgpYjhs = filename.rsplit('.',1)[1].strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if uayM539UAPSgpYjhs in OgN2S0jPCEi8JqXtaLoucbsDZTUB:
				o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'الملف ليس فيديو ولا صوت')
				return
		tKoDYsOPeyxM.append(ZZDUdXR52CMs9K73Ex)
		FUC9OmHZqPky0WGAJoX.append(kh850jKbzmBwY)
	for asKYTS478qkW in range(len(tKoDYsOPeyxM)):
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?icon-(.*?)"',tKoDYsOPeyxM[asKYTS478qkW],sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,e0ZujWEV23Qyld8prF7ANxCsahfg in Sp6qOyDB0nt5Qo4KwbPfcWYe:
			if 'torrent' in e0ZujWEV23Qyld8prF7ANxCsahfg: continue
			elif 'download' in e0ZujWEV23Qyld8prF7ANxCsahfg: type = 'download'
			elif 'play' in e0ZujWEV23Qyld8prF7ANxCsahfg: type = 'watch'
			else: type = 'unknown'
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named=__'+type+'____'+FUC9OmHZqPky0WGAJoX[asKYTS478qkW]+'__akwam'
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,filter):
	XXSxywJDNdUneWclbfI7 = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==kh850jKbzmBwY: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = kh850jKbzmBwY,kh850jKbzmBwY
	else: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = filter.split('___')
	if type=='CATEGORIES':
		if XXSxywJDNdUneWclbfI7[0]+'=' not in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[0]
		for asKYTS478qkW in range(len(XXSxywJDNdUneWclbfI7[0:-1])):
			if XXSxywJDNdUneWclbfI7[asKYTS478qkW]+'=' in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[asKYTS478qkW+1]
		oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ.strip('&')+'___'+oufZ8U7XLDFy4b.strip('&')
		PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'all')
		O9wzaDlICnq = url+'?'+PhFd0yvXWULQIfu9N2pSYDRCx
	elif type=='FILTERS':
		FCyjlpcBn5OG2Nowxvf6WQS74 = Md2htF3Gi186nWlYkJq(WQEFAlL7oCZ3XBt,'modified_values')
		FCyjlpcBn5OG2Nowxvf6WQS74 = KsuzxGjOHChbIXrwWm(FCyjlpcBn5OG2Nowxvf6WQS74)
		if CW52XnyslubD60Y4LNHp3hzZ9VP8!=kh850jKbzmBwY: CW52XnyslubD60Y4LNHp3hzZ9VP8 = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'all')
		if CW52XnyslubD60Y4LNHp3hzZ9VP8==kh850jKbzmBwY: O9wzaDlICnq = url
		else: O9wzaDlICnq = url+'?'+CW52XnyslubD60Y4LNHp3hzZ9VP8
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أظهار قائمة الفيديو التي تم اختيارها',O9wzaDlICnq,241,kh850jKbzmBwY,'1')
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+' [[   '+FCyjlpcBn5OG2Nowxvf6WQS74+'   ]]',O9wzaDlICnq,241,kh850jKbzmBwY,'1')
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,headers,True,'AKWAM-FILTERS_MENU-1st')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<form id(.*?)</form>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	deib7XxUZCQw8HA1n = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	dict = {}
	for uHwkOpvAPM3bqC72KZstX,name,ZZDUdXR52CMs9K73Ex in deib7XxUZCQw8HA1n:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<option(.*?)>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if '=' not in O9wzaDlICnq: O9wzaDlICnq = url
		if type=='CATEGORIES':
			if XvPwmy3axVdD6NIKGb4Ak!=uHwkOpvAPM3bqC72KZstX: continue
			elif len(items)<=1:
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]: bsZhnoqjD3U(O9wzaDlICnq)
				else: cf9bnl3ZAhJLt24qxIFwGzuNsMi(O9wzaDlICnq,'CATEGORIES___'+mDAEOKl2SQpv71acI4PJj5Hs9XzT)
				return
			else:
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,241,kh850jKbzmBwY,'1')
				else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,245,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		elif type=='FILTERS':
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع : '+name,O9wzaDlICnq,244,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		dict[uHwkOpvAPM3bqC72KZstX] = {}
		for value,OSvbC40RHt2AWY in items:
			if OSvbC40RHt2AWY in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			if 'value' not in value: value = OSvbC40RHt2AWY
			else: value = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"(.*?)"',value,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
			dict[uHwkOpvAPM3bqC72KZstX][value] = OSvbC40RHt2AWY
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'='+OSvbC40RHt2AWY
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'='+value
			qCdAhU0NW12mBS9neTQgwi = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			title = OSvbC40RHt2AWY+' : '#+dict[uHwkOpvAPM3bqC72KZstX]['0']
			title = OSvbC40RHt2AWY+' : '+name
			if type=='FILTERS': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,244,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
			elif type=='CATEGORIES' and XXSxywJDNdUneWclbfI7[-2]+'=' in WQEFAlL7oCZ3XBt:
				PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(oufZ8U7XLDFy4b,'all')
				QQJdiByEeNqLYGs = url+'?'+PhFd0yvXWULQIfu9N2pSYDRCx
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,QQJdiByEeNqLYGs,241,kh850jKbzmBwY,'1')
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,245,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
	return
def Md2htF3Gi186nWlYkJq(T3IPgzYmNnC9tkupohdRj2Qf,mode):
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.strip('&')
	yXeoduEjYKJLf0OinrlVzN3 = {}
	if '=' in T3IPgzYmNnC9tkupohdRj2Qf:
		items = T3IPgzYmNnC9tkupohdRj2Qf.split('&')
		for JJNIsO8Vcbx0 in items:
			moT0kOcKq7JPVSt3L,value = JJNIsO8Vcbx0.split('=')
			yXeoduEjYKJLf0OinrlVzN3[moT0kOcKq7JPVSt3L] = value
	jjSBkesYpFQc6A1q8RfVJgW = kh850jKbzmBwY
	vKwTaOAiBIbCjhdJktHeuMyWz8 = ['section','category','rating','year','language','formats','quality']
	for key in vKwTaOAiBIbCjhdJktHeuMyWz8:
		if key in list(yXeoduEjYKJLf0OinrlVzN3.keys()): value = yXeoduEjYKJLf0OinrlVzN3[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+' + '+value
		elif mode=='modified_filters' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
		elif mode=='all': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip(' + ')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip('&')
	return jjSBkesYpFQc6A1q8RfVJgW
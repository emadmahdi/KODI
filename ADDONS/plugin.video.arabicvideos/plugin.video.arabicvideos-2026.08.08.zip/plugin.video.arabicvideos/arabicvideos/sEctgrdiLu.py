# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SHOOFMAX'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SHM_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
d0hVTC6pXnNEwLqm4zbt3x = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][1]
dwmfrA3kVjbRU7KMaqCEBXYx9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][2]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==50: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==51: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==52: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==53: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==55: PP3FsDicLyWuTR7GV5Ia = U8Un7WrtMdT()
	elif mode==56: PP3FsDicLyWuTR7GV5Ia = XgTxtqmyaAB()
	elif mode==57: PP3FsDicLyWuTR7GV5Ia = vsIGpBwy4Dl1JjPHNcEnubSW2zTQO(url,1)
	elif mode==58: PP3FsDicLyWuTR7GV5Ia = vsIGpBwy4Dl1JjPHNcEnubSW2zTQO(url,2)
	elif mode==59: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,59,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'المسلسلات',kh850jKbzmBwY,56)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الافلام',kh850jKbzmBwY,55)
	return kh850jKbzmBwY
def U8Un7WrtMdT():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أفلام مرتبة بسنة الإنتاج',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/movie/1/yop',57)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أفلام مرتبة بالأفضل تقييم',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/movie/1/review',57)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أفلام مرتبة بالأكثر مشاهدة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/movie/1/views',57)
	return
def XgTxtqmyaAB():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات مرتبة بسنة الإنتاج',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/series/1/yop',57)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات مرتبة بالأفضل تقييم',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/series/1/review',57)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسلات مرتبة بالأكثر مشاهدة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/series/1/views',57)
	return
def bsZhnoqjD3U(url):
	if '?' in url:
		VQfK9Lr0j75zHwg1xOGY = url.split('?')
		url = VQfK9Lr0j75zHwg1xOGY[0]
		filter = '?' + ioZ083zxYk(VQfK9Lr0j75zHwg1xOGY[1],'=&:/%')
	else: filter = kh850jKbzmBwY
	type,QPZDaMKgtTUyNjB7EqvOLwph,sort = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': yGHav67gnAxtQo4FzrXROCuSJ9mMqI='فيلم'
		elif type=='series': yGHav67gnAxtQo4FzrXROCuSJ9mMqI='مسلسل'
		url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/genre/filter/' + ioZ083zxYk(yGHav67gnAxtQo4FzrXROCuSJ9mMqI) + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + QPZDaMKgtTUyNjB7EqvOLwph + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + sort + filter
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFMAX-TITLES-1st')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		uuyBj5CPAf1XDZ=0
		for id,title,nYbosSfiPT,NWqAr40jTLlMBemn3o79y in items:
			uuyBj5CPAf1XDZ += 1
			NWqAr40jTLlMBemn3o79y = dwmfrA3kVjbRU7KMaqCEBXYx9 + '/v2/img/program/main/' + NWqAr40jTLlMBemn3o79y + '-2.jpg'
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/program/' + id
			if type=='movie': EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,53,NWqAr40jTLlMBemn3o79y)
			if type=='series': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسل '+title,Ga8xfYU6ht7cHjzn+'?ep='+nYbosSfiPT+'='+title+'='+NWqAr40jTLlMBemn3o79y,52,NWqAr40jTLlMBemn3o79y)
	else:
		if type=='movie': yGHav67gnAxtQo4FzrXROCuSJ9mMqI='movies'
		elif type=='series': yGHav67gnAxtQo4FzrXROCuSJ9mMqI='series'
		url = d0hVTC6pXnNEwLqm4zbt3x + '/json/selected/' + sort + '-' + yGHav67gnAxtQo4FzrXROCuSJ9mMqI + '-WW.json'
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFMAX-TITLES-2nd')
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		uuyBj5CPAf1XDZ=0
		for id,nYbosSfiPT,NWqAr40jTLlMBemn3o79y,title in items:
			uuyBj5CPAf1XDZ += 1
			NWqAr40jTLlMBemn3o79y = d0hVTC6pXnNEwLqm4zbt3x + '/img/program/' + NWqAr40jTLlMBemn3o79y + '-2.jpg'
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/program/' + id
			if type=='movie': EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,53,NWqAr40jTLlMBemn3o79y)
			elif type=='series': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مسلسل '+title,Ga8xfYU6ht7cHjzn+'?ep='+nYbosSfiPT+'='+title+'='+NWqAr40jTLlMBemn3o79y,52,NWqAr40jTLlMBemn3o79y)
	title='صفحة '
	if uuyBj5CPAf1XDZ==16:
		for YApb91W3ysqLQ5c0SeO2l4UH in range(1,13) :
			if not QPZDaMKgtTUyNjB7EqvOLwph==str(YApb91W3ysqLQ5c0SeO2l4UH):
				url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/genre/filter/'+type+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+str(YApb91W3ysqLQ5c0SeO2l4UH)+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+sort+filter
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title+str(YApb91W3ysqLQ5c0SeO2l4UH),url,51)
	return
def do7Es2fUtFlM8ScLx(url):
	VQfK9Lr0j75zHwg1xOGY = url.split('=')
	nYbosSfiPT = int(VQfK9Lr0j75zHwg1xOGY[1])
	name = KsuzxGjOHChbIXrwWm(VQfK9Lr0j75zHwg1xOGY[2])
	name = name.replace('_MOD_مسلسل ',kh850jKbzmBwY)
	NWqAr40jTLlMBemn3o79y = VQfK9Lr0j75zHwg1xOGY[3]
	url = url.split('?')[0]
	if nYbosSfiPT==0:
		uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(SSZixT0lqg4BaUOtf79JjFIurn,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFMAX-EPISODES-1st')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<select(.*?)</select>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('option value="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		nYbosSfiPT = int(items[-1])
	for WULSmfNH09tPIv58snzpCkR in range(nYbosSfiPT,0,-1):
		Ga8xfYU6ht7cHjzn = url + '?ep=' + str(WULSmfNH09tPIv58snzpCkR)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(WULSmfNH09tPIv58snzpCkR)
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,53,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFMAX-PLAY-1st')
	vMdnkmq5ReusVaI6 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if vMdnkmq5ReusVaI6:
		pVesmhFG6wgubAODHSKvN1Wx = vMdnkmq5ReusVaI6[1].replace('T',eexO1A6EKJIVruD87qmaiGhbw)
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+URBvawyLXfQiS2NI34HDk+pVesmhFG6wgubAODHSKvN1Wx)
		return
	B7s2aXtDrwyqMRe,yE1u5jGaoQSInWg = [],[]
	HwZUAnf4IOmKQkFbgJoDYpj3ehqBdc = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('var origin_link = "(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	kfl5F9Sp427KRXZoQev = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('var backup_origin_link = "(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)[0]
	Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('hls: (.*?)_link\+"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for fDKF4iZ5rz7McduTexbA2RpPs,Ga8xfYU6ht7cHjzn in Sp6qOyDB0nt5Qo4KwbPfcWYe:
		if 'backup' in fDKF4iZ5rz7McduTexbA2RpPs:
			fDKF4iZ5rz7McduTexbA2RpPs = 'backup server'
			url = kfl5F9Sp427KRXZoQev + Ga8xfYU6ht7cHjzn
		else:
			fDKF4iZ5rz7McduTexbA2RpPs = 'main server'
			url = HwZUAnf4IOmKQkFbgJoDYpj3ehqBdc + Ga8xfYU6ht7cHjzn
		if '.m3u8' in url:
			B7s2aXtDrwyqMRe.append(url)
			yE1u5jGaoQSInWg.append('m3u8  '+fDKF4iZ5rz7McduTexbA2RpPs)
	Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	Sp6qOyDB0nt5Qo4KwbPfcWYe += sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for fDKF4iZ5rz7McduTexbA2RpPs,Ga8xfYU6ht7cHjzn in Sp6qOyDB0nt5Qo4KwbPfcWYe:
		filename = Ga8xfYU6ht7cHjzn.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
		filename = filename.replace('fallback',kh850jKbzmBwY)
		filename = filename.replace('.mp4',kh850jKbzmBwY)
		filename = filename.replace('-',kh850jKbzmBwY)
		if 'backup' in fDKF4iZ5rz7McduTexbA2RpPs:
			fDKF4iZ5rz7McduTexbA2RpPs = 'backup server'
			url = kfl5F9Sp427KRXZoQev + Ga8xfYU6ht7cHjzn
		else:
			fDKF4iZ5rz7McduTexbA2RpPs = 'main server'
			url = HwZUAnf4IOmKQkFbgJoDYpj3ehqBdc + Ga8xfYU6ht7cHjzn
		B7s2aXtDrwyqMRe.append(url)
		yE1u5jGaoQSInWg.append('mp4  '+fDKF4iZ5rz7McduTexbA2RpPs+cyR2rJzGpVSXNuHsEQjk60fvFetYDx+filename)
	TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('Select Video Quality:', yE1u5jGaoQSInWg)
	if TTn7mZzPRjq5GBESh8aKy == -1 : return
	url = B7s2aXtDrwyqMRe[TTn7mZzPRjq5GBESh8aKy]
	NRlCaq1ndM(url,vkNGie5mhCqoTFRzPKaML0x6,'video')
	return
def vsIGpBwy4Dl1JjPHNcEnubSW2zTQO(url,type):
	if 'series' in url: O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/genre/مسلسل'
	else: O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/genre/فيلم'
	O9wzaDlICnq = ioZ083zxYk(O9wzaDlICnq)
	uP1m46pAK5a3UgdqvBz9rnL = OrmXPzD0El(mXiE2RJGvS1DK4ZQuzl0sBFV,O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHOOFMAX-FILTERS-1st')
	if type==1: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('subgenre(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif type==2: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('country(.*?)div',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('option value="(.*?)">(.*?)</option',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if type==1:
		for XE2dV3Q0uqH1Dom7kRcU,title in items:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url+'?subgenre='+XE2dV3Q0uqH1Dom7kRcU,58)
	elif type==2:
		url,XE2dV3Q0uqH1Dom7kRcU = url.split('?')
		for dDw34S56lb,title in items:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url+'?country='+dDw34S56lb+'&'+XE2dV3Q0uqH1Dom7kRcU,51)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if not search: search = GG5Fs0hvURxyBV8gz()
	if not search: return
	BkpEeTDInR6LQFG2m1Ns = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search?q='+BkpEeTDInR6LQFG2m1Ns
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,True,kh850jKbzmBwY,'SHOOFMAX-SEARCH-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('general-body(.*?)search-bottom-padding',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
			url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + Ga8xfYU6ht7cHjzn
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+ioZ083zxYk(title)+'='+NWqAr40jTLlMBemn3o79y
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,52,NWqAr40jTLlMBemn3o79y)
				else:
					title = '_MOD_فيلم '+title
					EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,53,NWqAr40jTLlMBemn3o79y)
	return
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'KATKOUTE'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_KTK_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الصفحة الرئيسية','Sign in','الأقسام']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==670: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==671: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==672: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==673: PP3FsDicLyWuTR7GV5Ia = CYnmhWAZaoUXGcVJD67(url,text)
	elif mode==674: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==679: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,679,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"navslide-divider"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,mode)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	items = Iu8MASzegtVLihCDn76kr3WKx(WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/watch/browse.html')
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,674,NWqAr40jTLlMBemn3o79y)
	return
def Iu8MASzegtVLihCDn76kr3WKx(url):
	KATelV46pvn = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','KATKOUTE','CATEGORIES')
	if KATelV46pvn: return KATelV46pvn
	KATelV46pvn = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-CATEGORIES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"category-header"(.*?)<footer>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		KATelV46pvn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if KATelV46pvn: l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,'KATKOUTE','CATEGORIES',KATelV46pvn,mXiE2RJGvS1DK4ZQuzl0sBFV)
	return KATelV46pvn
def CC6NMTjSO2g(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-SUBMENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if NSUBGjzyZh5xaKL9AJF:
		ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"presentation"','</ul>')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = [(kh850jKbzmBwY,ZZDUdXR52CMs9K73Ex)]
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' فرز أو فلتر أو ترتيب '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		for JLngAu1qYhtXm0BNr,ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if JLngAu1qYhtXm0BNr: JLngAu1qYhtXm0BNr = JLngAu1qYhtXm0BNr+': '
			for Ga8xfYU6ht7cHjzn,title in items:
				title = JLngAu1qYhtXm0BNr+title
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,671)
	oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-category-subcats"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if oQuiJvtTzwPZbXd7sf4HcG9:
		ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(items)<30:
			EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
			for Ga8xfYU6ht7cHjzn,title in items:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,671)
	if not NSUBGjzyZh5xaKL9AJF and not oQuiJvtTzwPZbXd7sf4HcG9: bsZhnoqjD3U(url)
	return
def bsZhnoqjD3U(url,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'POST',url,data,headers,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-TITLES-1st')
	else:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-TITLES-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZZDUdXR52CMs9K73Ex,items = kh850jKbzmBwY,[]
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ajax-search':
		ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4: items.append((kh850jKbzmBwY,Ga8xfYU6ht7cHjzn,title))
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-video-watch-featured"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_episodes':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_movies':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(liroJ6qCK9k)>1: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[1]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured_series':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4: items.append((kh850jKbzmBwY,Ga8xfYU6ht7cHjzn,title))
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(data-echo=".*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if ZZDUdXR52CMs9K73Ex and not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items: return
	SHTvIuhX52dxQRsWA = []
	fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,672,NWqAr40jTLlMBemn3o79y)
		elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_episodes':
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,672,NWqAr40jTLlMBemn3o79y)
		elif WULSmfNH09tPIv58snzpCkR:
			title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,673,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		elif '/movseries/' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,671,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,673,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if Ga8xfYU6ht7cHjzn=='#': continue
			if 'http' not in Ga8xfYU6ht7cHjzn:
				O9wzaDlICnq = url.rsplit(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,1)[0]
				Ga8xfYU6ht7cHjzn = O9wzaDlICnq+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,671,kh850jKbzmBwY,kh850jKbzmBwY,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	return
def CYnmhWAZaoUXGcVJD67(url,GGy6r8KUN0WjnqoTR):
	EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+'تشغيل الفيديو',url,672)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	KATelV46pvn = Iu8MASzegtVLihCDn76kr3WKx(WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/watch/browse.html')
	qtvMNmdeyhiRPFVgASjW7ncsr,bYenwFZ1oWr3vA6uimBSaNsD,g67zJkNUXAaLn95iYEo = zip(*KATelV46pvn)
	VJZUqOEjWatnD8HorNseXi4F972 = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-EPISODES-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-video-heading"(.*?)id="player"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in Sp6qOyDB0nt5Qo4KwbPfcWYe:
			if Ga8xfYU6ht7cHjzn not in qtvMNmdeyhiRPFVgASjW7ncsr:
				JJNIsO8Vcbx0 = (Ga8xfYU6ht7cHjzn,title)
				VJZUqOEjWatnD8HorNseXi4F972.append(JJNIsO8Vcbx0)
		if len(VJZUqOEjWatnD8HorNseXi4F972)==1:
			Ga8xfYU6ht7cHjzn,title = VJZUqOEjWatnD8HorNseXi4F972[0]
			bsZhnoqjD3U(Ga8xfYU6ht7cHjzn,'new_episodes')
			return
		else:
			for Ga8xfYU6ht7cHjzn,title in VJZUqOEjWatnD8HorNseXi4F972:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,671,kh850jKbzmBwY,kh850jKbzmBwY,'new_episodes')
	if not VJZUqOEjWatnD8HorNseXi4F972: bsZhnoqjD3U(url,'new_episodes')
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'KATKOUTE-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('sources:(.*?)flashplayer',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('file: "(.*?)".*?label: "(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,sYm5r9QKRfjoytO in Sp6qOyDB0nt5Qo4KwbPfcWYe:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named=__watch__'+sYm5r9QKRfjoytO
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"embedded-video".*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not Sp6qOyDB0nt5Qo4KwbPfcWYe: Sp6qOyDB0nt5Qo4KwbPfcWYe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("file: '(.*?)'",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if Sp6qOyDB0nt5Qo4KwbPfcWYe:
		Ga8xfYU6ht7cHjzn = Sp6qOyDB0nt5Qo4KwbPfcWYe[0]
		if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
		owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named=__embed')
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/watch/search.php?keywords='+search
	bsZhnoqjD3U(url,'search')
	return
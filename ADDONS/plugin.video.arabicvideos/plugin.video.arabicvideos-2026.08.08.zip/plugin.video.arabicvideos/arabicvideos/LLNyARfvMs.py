# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'FASELHD1'
headers = {'User-Agent':kh850jKbzmBwY}
GalrcVUMy8bzORWX5E0exhYivBwgk = '_FH1_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['جوائز الأوسكار','المراجعات','wwe']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==570: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==571: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==572: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==573: PP3FsDicLyWuTR7GV5Ia = oAYk7vWHsLNC0VJqQ8FjnX(url,text)
	elif mode==576: PP3FsDicLyWuTR7GV5Ia = z5082rwu71V9aNOmJ()
	elif mode==579: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('link',GalrcVUMy8bzORWX5E0exhYivBwgk+'لماذا الموقع بطيء',kh850jKbzmBwY,576)
	giRfrJxZdQ16bw2oe,url = WLjaXVNk2dnAJzPpy6OlMv4qoi9,WLjaXVNk2dnAJzPpy6OlMv4qoi9
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FASELHD1-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',giRfrJxZdQ16bw2oe,579,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',giRfrJxZdQ16bw2oe,571,kh850jKbzmBwY,kh850jKbzmBwY,'featured1')
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="h3">(.*?)<.*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for title,Ga8xfYU6ht7cHjzn in items:
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,571,kh850jKbzmBwY,kh850jKbzmBwY,'details1')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"menu-primary"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		LiKEzOQSwmt7MeUqaGp1AJkvonPfTh = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<li (.*?)</li>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Um2YXZgNFopaqVnMWC0RrBxwDkd7P = [kh850jKbzmBwY,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		aaHueZUKGJDOvqjAy6CTinMIY = 0
		for MBq6IdsKJ9z21Z in LiKEzOQSwmt7MeUqaGp1AJkvonPfTh:
			if aaHueZUKGJDOvqjAy6CTinMIY>0: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',MBq6IdsKJ9z21Z,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn=='#': continue
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+Ga8xfYU6ht7cHjzn
				if title==kh850jKbzmBwY: continue
				if any(value in title.lower() for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
				title = Um2YXZgNFopaqVnMWC0RrBxwDkd7P[aaHueZUKGJDOvqjAy6CTinMIY]+title
				EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,571,kh850jKbzmBwY,kh850jKbzmBwY,'details2')
			aaHueZUKGJDOvqjAy6CTinMIY += 1
	return
def z5082rwu71V9aNOmJ():
	o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def bsZhnoqjD3U(url,type=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FASELHD1-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="h4">(.*?)</div>(.*?)"container"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not oQuiJvtTzwPZbXd7sf4HcG9: return
	if type=='filters':
		liroJ6qCK9k = [uP1m46pAK5a3UgdqvBz9rnL.replace('\\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace('\\"','"')]
	elif type=='featured1':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"homeSlide"(.*?)"container"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		mHjNds76Q1BvDh8e3,Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8 = zip(*items)
		items = zip(Sp6qOyDB0nt5Qo4KwbPfcWYe,mHjNds76Q1BvDh8e3,LtaDBqr1oOpP0Yz3g4ci8)
	elif type=='featured2':
		title,ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	elif type=='details2' and len(oQuiJvtTzwPZbXd7sf4HcG9)>1:
		title = oQuiJvtTzwPZbXd7sf4HcG9[0][0]
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,571,kh850jKbzmBwY,kh850jKbzmBwY,'featured2')
		title = oQuiJvtTzwPZbXd7sf4HcG9[1][0]
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,571,kh850jKbzmBwY,kh850jKbzmBwY,'details3')
		return
	else:
		title,ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[-1]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		if any(value in title.lower() for value in QQeT5Ntzv2ysxVmLHj1adM40iYpk): continue
		NWqAr40jTLlMBemn3o79y = Z4CP1xs5w7fi(NWqAr40jTLlMBemn3o79y)
		NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.split('?resize=')[0]
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if '/collections/' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,571,NWqAr40jTLlMBemn3o79y)
		elif WULSmfNH09tPIv58snzpCkR and type==kh850jKbzmBwY:
			title = '_MOD_'+WULSmfNH09tPIv58snzpCkR[0][0]
			title = title.strip(' –')
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,573,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		elif 'episodes/' in Ga8xfYU6ht7cHjzn or 'movies/' in Ga8xfYU6ht7cHjzn or 'hindi/' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,572,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,573,NWqAr40jTLlMBemn3o79y)
	if type=='filters':
		BeaPvLOV5WQEgZpRbh = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"more_button_page":(.*?),',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if BeaPvLOV5WQEgZpRbh:
			count = BeaPvLOV5WQEgZpRbh[0]
			Ga8xfYU6ht7cHjzn = url+'/offset/'+count
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة أخرى',Ga8xfYU6ht7cHjzn,571,kh850jKbzmBwY,kh850jKbzmBwY,'filters')
	elif 'details' in type:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("class='pagination(.*?)</div>",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("href='(.*?)'.*?>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				title = 'صفحة '+E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,571,kh850jKbzmBwY,kh850jKbzmBwY,'details4')
	return
def oAYk7vWHsLNC0VJqQ8FjnX(url,type=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FASELHD1-SEASONS_EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	djk9EyCzTearMK3vWINi2L = False
	if not type:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"seasonList"(.*?)"container"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if len(items)>1:
				giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
				djk9EyCzTearMK3vWINi2L = True
				for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,name,title in items:
					name = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(name)
					if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+Ga8xfYU6ht7cHjzn
					title = name+' - '+title
					EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,573,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,'episodes')
	if type=='episodes' or not djk9EyCzTearMK3vWINi2L:
		vvufbqFnUclCD5MxOz = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"posterImg".*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if vvufbqFnUclCD5MxOz: NWqAr40jTLlMBemn3o79y = vvufbqFnUclCD5MxOz[0]
		else: NWqAr40jTLlMBemn3o79y = kh850jKbzmBwY
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"epAll"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,572,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX,Fr2nREYhQJela3szX,vAJGwmQjgI96P7pRWEDe = [],[],[]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'FASELHD1-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	RsbCagWf3x2Nn4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('مستوى المشاهدة.*?">(.*?)</span>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if RsbCagWf3x2Nn4:
		ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"tag">(.*?)</a>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV): return
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"videoRow"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn in items:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('&img=')[0]
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named=__embed')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="streamHeader(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("href = '(.*?)'.*?</i>(.*?)</a>",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,name in items:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('&img=')[0]
			name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+name+'__watch')
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="downloadLinks(.*?)blackwindow',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</span>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,name in items:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.split('&img=')[0]
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn+'?named='+name+'__download')
	for t42R8EyFVQzrwjX in owMxje0p9Ya3CkhJDX:
		Ga8xfYU6ht7cHjzn,name = t42R8EyFVQzrwjX.split('?named')
		if Ga8xfYU6ht7cHjzn not in Fr2nREYhQJela3szX:
			Fr2nREYhQJela3szX.append(Ga8xfYU6ht7cHjzn)
			vAJGwmQjgI96P7pRWEDe.append(t42R8EyFVQzrwjX)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(vAJGwmQjgI96P7pRWEDe,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	O9wzaDlICnq = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/?s='+search
	bsZhnoqjD3U(O9wzaDlICnq,'details5')
	return
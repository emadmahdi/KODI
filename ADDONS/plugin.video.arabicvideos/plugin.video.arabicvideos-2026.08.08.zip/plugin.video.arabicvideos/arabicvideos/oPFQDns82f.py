# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
import bs4 as gdLPDXtb0UNY5j6m
vkNGie5mhCqoTFRzPKaML0x6 = 'ELCINEMA'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_ELC_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
headers = {'Referer':WLjaXVNk2dnAJzPpy6OlMv4qoi9}
QQeT5Ntzv2ysxVmLHj1adM40iYpk = []
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==510: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==511: PP3FsDicLyWuTR7GV5Ia = Kq02BrbzHtpOANRycGSsohUfaQY8(url)
	elif mode==512: PP3FsDicLyWuTR7GV5Ia = D0ruFmsVEfWRZnX1e(url)
	elif mode==513: PP3FsDicLyWuTR7GV5Ia = WW21SQ4VxMFXaAtGTY0el(url)
	elif mode==514: PP3FsDicLyWuTR7GV5Ia = JgkIGmZCBb(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: PP3FsDicLyWuTR7GV5Ia = JgkIGmZCBb(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: PP3FsDicLyWuTR7GV5Ia = spIFR5hiOELUfe(text)
	elif mode==517: PP3FsDicLyWuTR7GV5Ia = NEmoRGra8i9eQK(url)
	elif mode==518: PP3FsDicLyWuTR7GV5Ia = z3Y9qRiX7gaZ1jN(url)
	elif mode==519: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	elif mode==520: PP3FsDicLyWuTR7GV5Ia = ZoVeraUDBShtQ(url)
	elif mode==521: PP3FsDicLyWuTR7GV5Ia = lgnHFSKrD2(url)
	elif mode==522: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==523: PP3FsDicLyWuTR7GV5Ia = vrCoyMx8mFHdOQuzInEhw3RPTfDWAS(text)
	elif mode==524: PP3FsDicLyWuTR7GV5Ia = To5fOvkwEqnWRLyU9IuclKCYJ()
	elif mode==525: PP3FsDicLyWuTR7GV5Ia = siRecaDobM6nju8zZgIq()
	elif mode==526: PP3FsDicLyWuTR7GV5Ia = yZG60bUFa1ikpmMQYEdXoWq()
	elif mode==527: PP3FsDicLyWuTR7GV5Ia = PVl4L0CTRmtBubiHed()
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث بموسوعة السينما',kh850jKbzmBwY,519)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'موسوعة الأعمال',kh850jKbzmBwY,525)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'موسوعة الأشخاص',kh850jKbzmBwY,526)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'موسوعة المصنفات',kh850jKbzmBwY,527)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'موسوعة المنوعات',kh850jKbzmBwY,524)
	return
def To5fOvkwEqnWRLyU9IuclKCYJ():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+' فيديوهات - خاصة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video',520)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فيديوهات - أحدث',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/latest',521)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فيديوهات - أقدم',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/oldest',521)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فيديوهات - أكثر مشاهدة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/views',521)
	return
def siRecaDobM6nju8zZgIq():
	vd7B31EYcWj9nHFR8AC05m4 = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup?utf8=%E2%9C%93'
	ogNS4DYV5CR = vd7B31EYcWj9nHFR8AC05m4+'&type=2&category=1&foreign=false&tag='
	wtRq8g9lnI2vMj6BWuD0XPpV = vd7B31EYcWj9nHFR8AC05m4+'&type=2&category=3&foreign=false&tag='
	Jnf6VmsHGSx4p2eLyiwK = vd7B31EYcWj9nHFR8AC05m4+'&type=2&category=1&foreign=true&tag='
	O0We4j1dviKBZTgHr8UfS3RpP7kX = vd7B31EYcWj9nHFR8AC05m4+'&type=2&category=3&foreign=true&tag='
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات أفلام عربي',ogNS4DYV5CR,511)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات مسلسلات عربي',wtRq8g9lnI2vMj6BWuD0XPpV,511)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات أفلام اجنبي',Jnf6VmsHGSx4p2eLyiwK,511)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات مسلسلات اجنبي',O0We4j1dviKBZTgHr8UfS3RpP7kX,511)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس أعمال أبجدي',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/work/alphabet',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس  بلد الإنتاج',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/work/country',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس اللغة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/work/language',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس مصنفات العمل',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/work/genre',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس سنة الإصدار',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/work/release_year',517)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مواسم - فلتر محدد',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/seasonals',515)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مواسم - فلتر كامل',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/seasonals',514)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات - فلتر محدد',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup',515)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات - فلتر كامل',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup',514)
	return
def PVl4L0CTRmtBubiHed():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup',kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	ZZDUdXR52CMs9K73Ex = iMaTUn8worFpj7v1ef4XR.find('select',attrs={'name':'tag'})
	kFdoZmlxSf8shU = ZZDUdXR52CMs9K73Ex.find_all('option')
	for OSvbC40RHt2AWY in kFdoZmlxSf8shU:
		value = OSvbC40RHt2AWY.get('value')
		if not value: continue
		title = OSvbC40RHt2AWY.text
		if BBJYzRKgHkOqx:
			title = title.encode(NVbhZ0DTpOkCA)
			value = value.encode(NVbhZ0DTpOkCA)
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',kh850jKbzmBwY)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,511)
	return
def yZG60bUFa1ikpmMQYEdXoWq():
	vd7B31EYcWj9nHFR8AC05m4 = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup?utf8=%E2%9C%93'
	E180i9gBdNyFG4vx2wOpnZ = vd7B31EYcWj9nHFR8AC05m4+'&type=1&category=&foreign=&tag='
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات أشخاص',E180i9gBdNyFG4vx2wOpnZ,511)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس أشخاص أبجدي',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/person/alphabet',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس موطن',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/person/nationality',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس  تاريخ الميلاد',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/person/birth_year',517)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فهرس  تاريخ الوفاة',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/index/person/death_year',517)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات - فلتر محدد',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup',515)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مصنفات - فلتر كامل',WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/lineup',514)
	return
def Kq02BrbzHtpOANRycGSsohUfaQY8(url):
	if '/seasonals' in url: CCb3sqcILQHYeMzR = 0
	elif '/lineup' in url: CCb3sqcILQHYeMzR = 1
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-LISTS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	tKoDYsOPeyxM = iMaTUn8worFpj7v1ef4XR.find_all(class_='jumbo-theater clearfix')
	for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
		title = ZZDUdXR52CMs9K73Ex.find_all('a')[CCb3sqcILQHYeMzR].text
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+ZZDUdXR52CMs9K73Ex.find_all('a')[CCb3sqcILQHYeMzR].get('href')
		if BBJYzRKgHkOqx:
			title = title.encode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
		if not tKoDYsOPeyxM:
			D0ruFmsVEfWRZnX1e(Ga8xfYU6ht7cHjzn)
			return
		else:
			title = title.replace('قائمة ',kh850jKbzmBwY)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,512)
	P4gGaQM7VLjzsixrcmuHBb35A1(iMaTUn8worFpj7v1ef4XR,511)
	return
def P4gGaQM7VLjzsixrcmuHBb35A1(iMaTUn8worFpj7v1ef4XR,mode):
	ZZDUdXR52CMs9K73Ex = iMaTUn8worFpj7v1ef4XR.find(class_='pagination')
	if ZZDUdXR52CMs9K73Ex:
		yz0JuMrlWdISxFaqQ29pZ63iR8om = ZZDUdXR52CMs9K73Ex.find_all('a')
		fTGcSwroyWYUAt8IxjJ6 = ZZDUdXR52CMs9K73Ex.find_all('li')
		I5MPTGnq4a9KO = list(zip(yz0JuMrlWdISxFaqQ29pZ63iR8om,fTGcSwroyWYUAt8IxjJ6))
		aaHueZUKGJDOvqjAy6CTinMIY = -1
		MFd2oJXiwjImEgYzCy1TS = len(I5MPTGnq4a9KO)
		for r3Q0E1RMsJHBXt6hjYuLoaI,sX7SboZPh9Kqrxp4l in I5MPTGnq4a9KO:
			aaHueZUKGJDOvqjAy6CTinMIY += 1
			sX7SboZPh9Kqrxp4l = sX7SboZPh9Kqrxp4l['class']
			if 'unavailable' in sX7SboZPh9Kqrxp4l or 'current' in sX7SboZPh9Kqrxp4l: continue
			tVNeLEOXQU1osj = r3Q0E1RMsJHBXt6hjYuLoaI.text
			jQOlvATLDcdquxVXaJib3Yo5 = WLjaXVNk2dnAJzPpy6OlMv4qoi9+r3Q0E1RMsJHBXt6hjYuLoaI.get('href')
			if BBJYzRKgHkOqx:
				tVNeLEOXQU1osj = tVNeLEOXQU1osj.encode(NVbhZ0DTpOkCA)
				jQOlvATLDcdquxVXaJib3Yo5 = jQOlvATLDcdquxVXaJib3Yo5.encode(NVbhZ0DTpOkCA)
			if   aaHueZUKGJDOvqjAy6CTinMIY==0: tVNeLEOXQU1osj = 'أولى'
			elif aaHueZUKGJDOvqjAy6CTinMIY==1: tVNeLEOXQU1osj = 'سابقة'
			elif aaHueZUKGJDOvqjAy6CTinMIY==MFd2oJXiwjImEgYzCy1TS-2: tVNeLEOXQU1osj = 'لاحقة'
			elif aaHueZUKGJDOvqjAy6CTinMIY==MFd2oJXiwjImEgYzCy1TS-1: tVNeLEOXQU1osj = 'أخيرة'
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+tVNeLEOXQU1osj,jQOlvATLDcdquxVXaJib3Yo5,mode)
	return
def D0ruFmsVEfWRZnX1e(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-TITLES1-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	tKoDYsOPeyxM = iMaTUn8worFpj7v1ef4XR.find_all(class_='row')
	items,uWLHzodcJeGxVFP2Eqr0fZUwKb5 = [],True
	for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
		if not ZZDUdXR52CMs9K73Ex.find(class_='thumbnail-wrapper'): continue
		if uWLHzodcJeGxVFP2Eqr0fZUwKb5: uWLHzodcJeGxVFP2Eqr0fZUwKb5 = False ; continue
		yAZotX0l9cIapOEMT8 = []
		Itn9DoNZFOXWxG47sUlzfvg6p3B0 = ZZDUdXR52CMs9K73Ex.find_all(class_=['censorship red','censorship purple'])
		for nbPfMsAzkdEaKt8Hix in Itn9DoNZFOXWxG47sUlzfvg6p3B0:
			xsM9rN1JOyDLpw7nzUZAl = nbPfMsAzkdEaKt8Hix.find_all('li')[1].text
			if BBJYzRKgHkOqx:
				xsM9rN1JOyDLpw7nzUZAl = xsM9rN1JOyDLpw7nzUZAl.encode(NVbhZ0DTpOkCA)
			yAZotX0l9cIapOEMT8.append(xsM9rN1JOyDLpw7nzUZAl)
		if not EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,kh850jKbzmBwY,yAZotX0l9cIapOEMT8,False):
			vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('data-src')
			title = ZZDUdXR52CMs9K73Ex.find('h3')
			name = title.find('a').text
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+title.find('a').get('href')
			GeO7YLwloKybxMDrZXH03W9Tk2V6gd = ZZDUdXR52CMs9K73Ex.find(class_='no-margin')
			vvp0LCfZIQgeP2ykl = ZZDUdXR52CMs9K73Ex.find(class_='legend')
			if GeO7YLwloKybxMDrZXH03W9Tk2V6gd: GeO7YLwloKybxMDrZXH03W9Tk2V6gd = GeO7YLwloKybxMDrZXH03W9Tk2V6gd.text
			if vvp0LCfZIQgeP2ykl: vvp0LCfZIQgeP2ykl = vvp0LCfZIQgeP2ykl.text
			if BBJYzRKgHkOqx:
				vvufbqFnUclCD5MxOz = vvufbqFnUclCD5MxOz.encode(NVbhZ0DTpOkCA)
				name = name.encode(NVbhZ0DTpOkCA)
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
				if GeO7YLwloKybxMDrZXH03W9Tk2V6gd: GeO7YLwloKybxMDrZXH03W9Tk2V6gd = GeO7YLwloKybxMDrZXH03W9Tk2V6gd.encode(NVbhZ0DTpOkCA)
			SMT9JWapBjDXNCFLlixwo7b36g8uA = {}
			if vvp0LCfZIQgeP2ykl: SMT9JWapBjDXNCFLlixwo7b36g8uA['stars'] = vvp0LCfZIQgeP2ykl
			if GeO7YLwloKybxMDrZXH03W9Tk2V6gd:
				GeO7YLwloKybxMDrZXH03W9Tk2V6gd = GeO7YLwloKybxMDrZXH03W9Tk2V6gd.replace(URBvawyLXfQiS2NI34HDk,' .. ')
				SMT9JWapBjDXNCFLlixwo7b36g8uA['plot'] = GeO7YLwloKybxMDrZXH03W9Tk2V6gd.replace('...اقرأ المزيد',kh850jKbzmBwY)
			if '/work/' in Ga8xfYU6ht7cHjzn:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,516,vvufbqFnUclCD5MxOz,kh850jKbzmBwY,name,kh850jKbzmBwY,SMT9JWapBjDXNCFLlixwo7b36g8uA)
			elif '/person/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,513,vvufbqFnUclCD5MxOz,kh850jKbzmBwY,name,kh850jKbzmBwY,SMT9JWapBjDXNCFLlixwo7b36g8uA)
	P4gGaQM7VLjzsixrcmuHBb35A1(iMaTUn8worFpj7v1ef4XR,512)
	return
def WW21SQ4VxMFXaAtGTY0el(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-TITLES2-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	tKoDYsOPeyxM = iMaTUn8worFpj7v1ef4XR.find_all('li')
	PP2Kjhwm47VFtgoquiCGcTDOJB16v,items = [],[]
	for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
		if not ZZDUdXR52CMs9K73Ex.find(class_='thumbnail-wrapper'): continue
		if not ZZDUdXR52CMs9K73Ex.find(class_=['unstyled','unstyled text-center']): continue
		if ZZDUdXR52CMs9K73Ex.find(class_='hide'): continue
		title = ZZDUdXR52CMs9K73Ex.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in PP2Kjhwm47VFtgoquiCGcTDOJB16v: continue
		PP2Kjhwm47VFtgoquiCGcTDOJB16v.append(name)
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+title.find('a').get('href')
		if '/search/work/' in url: vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('src')
		elif '/search/person/' in url: vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('data-src')
		elif '/search/video/' in url: vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('data-src')
		else: vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('src')
		if BBJYzRKgHkOqx:
			name = name.encode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
			vvufbqFnUclCD5MxOz = vvufbqFnUclCD5MxOz.encode(NVbhZ0DTpOkCA)
		name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		items.append((name,Ga8xfYU6ht7cHjzn,vvufbqFnUclCD5MxOz))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,Ga8xfYU6ht7cHjzn,vvufbqFnUclCD5MxOz in items:
		if '/search/video/' in url: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,522,vvufbqFnUclCD5MxOz)
		elif '/search/person/' in url: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,513,vvufbqFnUclCD5MxOz,kh850jKbzmBwY,name)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,516,vvufbqFnUclCD5MxOz,kh850jKbzmBwY,name)
	return
def spIFR5hiOELUfe(text):
	text = text.replace('الإعلان',kh850jKbzmBwY).replace('لفيلم',kh850jKbzmBwY).replace('الرسمي',kh850jKbzmBwY)
	text = text.replace('إعلان',kh850jKbzmBwY).replace('فيلم',kh850jKbzmBwY).replace('البرومو',kh850jKbzmBwY)
	text = text.replace('التشويقي',kh850jKbzmBwY).replace('لمسلسل',kh850jKbzmBwY).replace('مسلسل',kh850jKbzmBwY)
	text = text.replace(':',kh850jKbzmBwY).replace(')',kh850jKbzmBwY).replace('(',kh850jKbzmBwY).replace(',',kh850jKbzmBwY)
	text = text.replace('_',kh850jKbzmBwY).replace(';',kh850jKbzmBwY).replace('-',kh850jKbzmBwY).replace('.',kh850jKbzmBwY)
	text = text.replace('\'',kh850jKbzmBwY).replace('\"',kh850jKbzmBwY)
	text = text.replace(eexO1A6EKJIVruD87qmaiGhbw,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(ityRsSDe1ZNqhQ3PLjp74dfEV,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	text = text.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	cngYmDGKS9bA = text.count(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)+1
	if cngYmDGKS9bA==1:
		vrCoyMx8mFHdOQuzInEhw3RPTfDWAS(text)
		return
	EE6ysIeB8jKNgCfOkv('link',GalrcVUMy8bzORWX5E0exhYivBwgk+HHFAVK8SwRUqBLuTfdeJ9nbD+'==== كلمات للبحث ===='+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	uHvC6Udc7X1TbEzAt0Kep4 = text.split(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	KP8Sbx4wstrld5H = pow(2,cngYmDGKS9bA)
	FrgNL8JmkAZTlXspSvdUBjca26 = []
	def vxdNGTa4yBFob(XB9lcYOxaR4tPzJr30,eZydFYvmt56IBnlUwr):
		if XB9lcYOxaR4tPzJr30=='1': return eZydFYvmt56IBnlUwr
		return kh850jKbzmBwY
	for aaHueZUKGJDOvqjAy6CTinMIY in range(KP8Sbx4wstrld5H,0,-1):
		nmCGao1pOgK = list(cngYmDGKS9bA*'0'+bin(aaHueZUKGJDOvqjAy6CTinMIY)[2:])[-cngYmDGKS9bA:]
		nmCGao1pOgK = reversed(nmCGao1pOgK)
		pYMAch3kEg = map(vxdNGTa4yBFob,nmCGao1pOgK,uHvC6Udc7X1TbEzAt0Kep4)
		title = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF.join(filter(None,pYMAch3kEg))
		if BBJYzRKgHkOqx: EVfKyFrmX1Mpb62tLuHS5w3W = title.decode(NVbhZ0DTpOkCA)
		else: EVfKyFrmX1Mpb62tLuHS5w3W = title
		if len(EVfKyFrmX1Mpb62tLuHS5w3W)>2 and title not in FrgNL8JmkAZTlXspSvdUBjca26:
			FrgNL8JmkAZTlXspSvdUBjca26.append(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,kh850jKbzmBwY,523,kh850jKbzmBwY,kh850jKbzmBwY,title)
	return
def vrCoyMx8mFHdOQuzInEhw3RPTfDWAS(D2vGheawHt3pBn9CbZs):
	if BBJYzRKgHkOqx:
		D2vGheawHt3pBn9CbZs = D2vGheawHt3pBn9CbZs.decode(NVbhZ0DTpOkCA)
		import arabic_reshaper as llr4qQxLn9BKGMp,bidi.algorithm as meriXMfz3Qo9EWROxgdUS4lBpLYN
		D2vGheawHt3pBn9CbZs = llr4qQxLn9BKGMp.ArabicReshaper().reshape(D2vGheawHt3pBn9CbZs)
		D2vGheawHt3pBn9CbZs = meriXMfz3Qo9EWROxgdUS4lBpLYN.get_display(D2vGheawHt3pBn9CbZs)
	import IIMRV5FExJ
	D2vGheawHt3pBn9CbZs = GG5Fs0hvURxyBV8gz(bbsYnuFMRzrZAUSgCIWvm4hKVOl=D2vGheawHt3pBn9CbZs)
	IIMRV5FExJ.dStQzEeyknDaOs7q(D2vGheawHt3pBn9CbZs)
	return
def NEmoRGra8i9eQK(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-INDEXES_LISTS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	ZZDUdXR52CMs9K73Ex = iMaTUn8worFpj7v1ef4XR.find(class_='list-separator list-title')
	LtaDBqr1oOpP0Yz3g4ci8 = ZZDUdXR52CMs9K73Ex.find_all('a')
	items = []
	for title in LtaDBqr1oOpP0Yz3g4ci8:
		name = title.text
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+title.get('href')
		if BBJYzRKgHkOqx:
			name = name.encode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
		if '#' not in Ga8xfYU6ht7cHjzn: items.append((name,Ga8xfYU6ht7cHjzn))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for JJNIsO8Vcbx0 in items:
		name,Ga8xfYU6ht7cHjzn = JJNIsO8Vcbx0
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,518)
	return
def z3Y9qRiX7gaZ1jN(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-INDEXES_TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	tKoDYsOPeyxM = iMaTUn8worFpj7v1ef4XR.find(class_='expand').find_all('tr')
	for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
		zwpGir8QoIjlFHNYvafU0 = ZZDUdXR52CMs9K73Ex.find_all('a')
		if not zwpGir8QoIjlFHNYvafU0: continue
		vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('data-src')
		name = zwpGir8QoIjlFHNYvafU0[1].text
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+zwpGir8QoIjlFHNYvafU0[1].get('href')
		vvp0LCfZIQgeP2ykl = ZZDUdXR52CMs9K73Ex.find(class_='legend')
		if vvp0LCfZIQgeP2ykl: vvp0LCfZIQgeP2ykl = vvp0LCfZIQgeP2ykl.text
		if BBJYzRKgHkOqx:
			name = name.encode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
			vvufbqFnUclCD5MxOz = vvufbqFnUclCD5MxOz.encode(NVbhZ0DTpOkCA)
		SMT9JWapBjDXNCFLlixwo7b36g8uA = {}
		if vvp0LCfZIQgeP2ykl: SMT9JWapBjDXNCFLlixwo7b36g8uA['stars'] = vvp0LCfZIQgeP2ykl
		if '/work/' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,516,vvufbqFnUclCD5MxOz,kh850jKbzmBwY,name,kh850jKbzmBwY,SMT9JWapBjDXNCFLlixwo7b36g8uA)
		elif '/person/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+name,Ga8xfYU6ht7cHjzn,513,vvufbqFnUclCD5MxOz,kh850jKbzmBwY,name,kh850jKbzmBwY,SMT9JWapBjDXNCFLlixwo7b36g8uA)
	P4gGaQM7VLjzsixrcmuHBb35A1(iMaTUn8worFpj7v1ef4XR,518)
	return
def ZoVeraUDBShtQ(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-VIDEOS_LISTS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	LtaDBqr1oOpP0Yz3g4ci8 = iMaTUn8worFpj7v1ef4XR.find_all(class_='section-title inline')
	Sp6qOyDB0nt5Qo4KwbPfcWYe = iMaTUn8worFpj7v1ef4XR.find_all(class_='button green small right')
	items = zip(LtaDBqr1oOpP0Yz3g4ci8,Sp6qOyDB0nt5Qo4KwbPfcWYe)
	for title,Ga8xfYU6ht7cHjzn in items:
		title = title.text
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn.get('href')
		if BBJYzRKgHkOqx:
			title = title.encode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
		title = title.replace(eexO1A6EKJIVruD87qmaiGhbw,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(ityRsSDe1ZNqhQ3PLjp74dfEV,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,521)
	return
def lgnHFSKrD2(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-VIDEOS_TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	IPeLXmBF4jpVlD7QOJCrYfuh8c1x5 = iMaTUn8worFpj7v1ef4XR.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	tKoDYsOPeyxM = IPeLXmBF4jpVlD7QOJCrYfuh8c1x5.find_all('li')
	for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
		title = ZZDUdXR52CMs9K73Ex.find(class_='title').text
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+ZZDUdXR52CMs9K73Ex.find('a').get('href')
		vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex.find('img').get('data-src')
		qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = ZZDUdXR52CMs9K73Ex.find(class_='duration').text
		if BBJYzRKgHkOqx:
			title = title.encode(NVbhZ0DTpOkCA)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
			vvufbqFnUclCD5MxOz = vvufbqFnUclCD5MxOz.encode(NVbhZ0DTpOkCA)
			qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ.encode(NVbhZ0DTpOkCA)
		qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ.replace(URBvawyLXfQiS2NI34HDk,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,522,vvufbqFnUclCD5MxOz,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	P4gGaQM7VLjzsixrcmuHBb35A1(iMaTUn8worFpj7v1ef4XR,521)
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	Ga8xfYU6ht7cHjzn = iMaTUn8worFpj7v1ef4XR.find(class_='flex-video').find('iframe').get('src')
	if BBJYzRKgHkOqx: Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.encode(NVbhZ0DTpOkCA)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo([Ga8xfYU6ht7cHjzn],vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'%20')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/?q='+search
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-SEARCH-1st')
	if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
		E180i9gBdNyFG4vx2wOpnZ = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search_entity/?q='+search+'&entity=work'
		jQOlvATLDcdquxVXaJib3Yo5 = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search_entity/?q='+search+'&entity=person'
		ZlKX7fiWVkAywdTUmMesrcR = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search_entity/?q='+search+'&entity=video'
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن أعمال',E180i9gBdNyFG4vx2wOpnZ,513,kh850jKbzmBwY,search)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن أشخاص',jQOlvATLDcdquxVXaJib3Yo5,513,kh850jKbzmBwY,search)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن فيديوهات',ZlKX7fiWVkAywdTUmMesrcR,513,kh850jKbzmBwY,search)
		return
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	iMaTUn8worFpj7v1ef4XR = gdLPDXtb0UNY5j6m.BeautifulSoup(uP1m46pAK5a3UgdqvBz9rnL,'html.parser',multi_valued_attributes=None)
	tKoDYsOPeyxM = iMaTUn8worFpj7v1ef4XR.find_all(class_='section-title left')
	for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
		title = ZZDUdXR52CMs9K73Ex.text
		if BBJYzRKgHkOqx:
			title = title.encode(NVbhZ0DTpOkCA)
		title = title.split('(',1)[0].strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if   'أعمال' in title: Ga8xfYU6ht7cHjzn = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: Ga8xfYU6ht7cHjzn = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: Ga8xfYU6ht7cHjzn = url.replace('/search/','/search/video/')
		else: continue
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,513)
	return
def JgkIGmZCBb(url,text):
	global XXSxywJDNdUneWclbfI7,vKwTaOAiBIbCjhdJktHeuMyWz8
	if '/seasonals' in url:
		XXSxywJDNdUneWclbfI7 = ['seasonal','year','category']
		vKwTaOAiBIbCjhdJktHeuMyWz8 = ['seasonal','year','category']
	elif '/lineup' in url:
		XXSxywJDNdUneWclbfI7 = ['category','foreign','type']
		vKwTaOAiBIbCjhdJktHeuMyWz8 = ['category','foreign','type']
	cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,text)
	return
def vgP862NBF4UG(url):
	url = url.split('/smartemadfilter?')[0]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('form action="/(.*?)</form>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	deib7XxUZCQw8HA1n = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	return deib7XxUZCQw8HA1n
def OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex):
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<option value="(.*?)">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	return items
def bF2piHrjYeOC7uxPz(url):
	gdGWEPpk3frFTQa8wcYhqMyV4 = url.split('/smartemadfilter?')[0]
	jjEqDAJkvVXK5WdC0xSGR2m = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def jDA8RCXuHE0kQ41lKwbPc7M(oufZ8U7XLDFy4b,url):
	PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(oufZ8U7XLDFy4b,'all_filters')
	QQJdiByEeNqLYGs = url+'/smartemadfilter?'+PhFd0yvXWULQIfu9N2pSYDRCx
	QQJdiByEeNqLYGs = bF2piHrjYeOC7uxPz(QQJdiByEeNqLYGs)
	return QQJdiByEeNqLYGs
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==kh850jKbzmBwY: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = kh850jKbzmBwY,kh850jKbzmBwY
	else: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if XXSxywJDNdUneWclbfI7[0]+'=' not in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[0]
		for asKYTS478qkW in range(len(XXSxywJDNdUneWclbfI7[0:-1])):
			if XXSxywJDNdUneWclbfI7[asKYTS478qkW]+'=' in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[asKYTS478qkW+1]
		oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ.strip('&')+'___'+oufZ8U7XLDFy4b.strip('&')
		PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		O9wzaDlICnq = url+'/smartemadfilter?'+PhFd0yvXWULQIfu9N2pSYDRCx
	elif type=='ALL_ITEMS_FILTER':
		FCyjlpcBn5OG2Nowxvf6WQS74 = Md2htF3Gi186nWlYkJq(WQEFAlL7oCZ3XBt,'modified_values')
		FCyjlpcBn5OG2Nowxvf6WQS74 = KsuzxGjOHChbIXrwWm(FCyjlpcBn5OG2Nowxvf6WQS74)
		if CW52XnyslubD60Y4LNHp3hzZ9VP8!=kh850jKbzmBwY: CW52XnyslubD60Y4LNHp3hzZ9VP8 = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		if CW52XnyslubD60Y4LNHp3hzZ9VP8==kh850jKbzmBwY: O9wzaDlICnq = url
		else: O9wzaDlICnq = url+'/smartemadfilter?'+CW52XnyslubD60Y4LNHp3hzZ9VP8
		O9wzaDlICnq = bF2piHrjYeOC7uxPz(O9wzaDlICnq)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أظهار قائمة الفيديو التي تم اختيارها ',O9wzaDlICnq,511)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+' [[   '+FCyjlpcBn5OG2Nowxvf6WQS74+'   ]]',O9wzaDlICnq,511)
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	deib7XxUZCQw8HA1n = vgP862NBF4UG(url)
	dict = {}
	for name,uHwkOpvAPM3bqC72KZstX,ZZDUdXR52CMs9K73Ex in deib7XxUZCQw8HA1n:
		name = name.replace('--',kh850jKbzmBwY)
		items = OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex)
		if '=' not in O9wzaDlICnq: O9wzaDlICnq = url
		if type=='SPECIFIED_FILTER':
			if uHwkOpvAPM3bqC72KZstX not in XXSxywJDNdUneWclbfI7: continue
			if XvPwmy3axVdD6NIKGb4Ak!=uHwkOpvAPM3bqC72KZstX: continue
			elif len(items)<2:
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]:
					url = bF2piHrjYeOC7uxPz(url)
					D0ruFmsVEfWRZnX1e(url)
				else: cf9bnl3ZAhJLt24qxIFwGzuNsMi(O9wzaDlICnq,'SPECIFIED_FILTER___'+mDAEOKl2SQpv71acI4PJj5Hs9XzT)
				return
			else:
				O9wzaDlICnq = bF2piHrjYeOC7uxPz(O9wzaDlICnq)
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,511)
				else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,515,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		elif type=='ALL_ITEMS_FILTER':
			if uHwkOpvAPM3bqC72KZstX not in vKwTaOAiBIbCjhdJktHeuMyWz8: continue
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع: '+name,O9wzaDlICnq,514,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		dict[uHwkOpvAPM3bqC72KZstX] = {}
		for value,OSvbC40RHt2AWY in items:
			if OSvbC40RHt2AWY in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			if 'مصنفات أخرى' in OSvbC40RHt2AWY: continue
			if 'الكل' in OSvbC40RHt2AWY: continue
			if 'اللغة' in OSvbC40RHt2AWY: continue
			OSvbC40RHt2AWY = OSvbC40RHt2AWY.replace('قائمة ',kh850jKbzmBwY)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[uHwkOpvAPM3bqC72KZstX][value] = OSvbC40RHt2AWY
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'='+OSvbC40RHt2AWY
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'='+value
			qCdAhU0NW12mBS9neTQgwi = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			if name: title = OSvbC40RHt2AWY+' :'+name
			else: title = OSvbC40RHt2AWY
			if type=='ALL_ITEMS_FILTER': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,514,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
			elif type=='SPECIFIED_FILTER' and XXSxywJDNdUneWclbfI7[-2]+'=' in WQEFAlL7oCZ3XBt:
				QQJdiByEeNqLYGs = jDA8RCXuHE0kQ41lKwbPc7M(oufZ8U7XLDFy4b,url)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,QQJdiByEeNqLYGs,511)
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,515,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
	return
def Md2htF3Gi186nWlYkJq(T3IPgzYmNnC9tkupohdRj2Qf,mode):
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.replace('=&','=0&')
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.strip('&')
	yXeoduEjYKJLf0OinrlVzN3 = {}
	if '=' in T3IPgzYmNnC9tkupohdRj2Qf:
		items = T3IPgzYmNnC9tkupohdRj2Qf.split('&')
		for JJNIsO8Vcbx0 in items:
			moT0kOcKq7JPVSt3L,value = JJNIsO8Vcbx0.split('=')
			yXeoduEjYKJLf0OinrlVzN3[moT0kOcKq7JPVSt3L] = value
	jjSBkesYpFQc6A1q8RfVJgW = kh850jKbzmBwY
	for key in vKwTaOAiBIbCjhdJktHeuMyWz8:
		if key in list(yXeoduEjYKJLf0OinrlVzN3.keys()): value = yXeoduEjYKJLf0OinrlVzN3[key]
		else: value = '0'
		if '%' not in value: value = ioZ083zxYk(value)
		if mode=='modified_values' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+' + '+value
		elif mode=='modified_filters' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
		elif mode=='all_filters': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip(' + ')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip('&')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.replace('=0','=')
	return jjSBkesYpFQc6A1q8RfVJgW
XXSxywJDNdUneWclbfI7 = []
vKwTaOAiBIbCjhdJktHeuMyWz8 = []
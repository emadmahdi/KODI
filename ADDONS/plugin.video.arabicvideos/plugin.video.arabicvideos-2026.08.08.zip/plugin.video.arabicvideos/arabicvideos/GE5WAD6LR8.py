# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'LIVETV'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS['PYTHON'][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url):
	if   mode==100: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==101: PP3FsDicLyWuTR7GV5Ia = yIGljH8dub0q4zoD('0',True)
	elif mode==102: PP3FsDicLyWuTR7GV5Ia = yIGljH8dub0q4zoD('1',True)
	elif mode==103: PP3FsDicLyWuTR7GV5Ia = yIGljH8dub0q4zoD('2',True)
	elif mode==104: PP3FsDicLyWuTR7GV5Ia = yIGljH8dub0q4zoD('3',True)
	elif mode==105: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==106: PP3FsDicLyWuTR7GV5Ia = yIGljH8dub0q4zoD('4',True)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder','_M3U_'+'قوائم فيديوهات M3U',kh850jKbzmBwY,762)
	EE6ysIeB8jKNgCfOkv('folder','_IPT_'+'قوائم فيديوهات IPTV',kh850jKbzmBwY,761)
	EE6ysIeB8jKNgCfOkv('folder','_TV0_'+'قنوات من مواقعها الأصلية',kh850jKbzmBwY,101)
	EE6ysIeB8jKNgCfOkv('folder','_TV4_'+'قنوات مختارة من يوتيوب',kh850jKbzmBwY,106)
	EE6ysIeB8jKNgCfOkv('folder','_YUT_'+'قنوات عربية من يوتيوب',kh850jKbzmBwY,147)
	EE6ysIeB8jKNgCfOkv('folder','_YUT_'+'قنوات أجنبية من يوتيوب',kh850jKbzmBwY,148)
	EE6ysIeB8jKNgCfOkv('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',kh850jKbzmBwY,28)
	EE6ysIeB8jKNgCfOkv('live','_MRF_'+'قناة المعارف من موقعهم',kh850jKbzmBwY,41)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder','_TV1_'+'قنوات تلفزيونية عامة',kh850jKbzmBwY,102)
	EE6ysIeB8jKNgCfOkv('folder','_TV2_'+'قنوات تلفزيونية خاصة',kh850jKbzmBwY,103)
	EE6ysIeB8jKNgCfOkv('folder','_TV3_'+'قنوات تلفزيونية للفحص',kh850jKbzmBwY,104)
	return
def yIGljH8dub0q4zoD(MBq6IdsKJ9z21Z,showDialogs=True):
	GalrcVUMy8bzORWX5E0exhYivBwgk = '_TV'+MBq6IdsKJ9z21Z+'_'
	K83xkHbNteiq7RnvgFSL0foXO92EmW = {'id':kh850jKbzmBwY,'user':Y3Ny5eLHdp.AV_CLIENT_IDS,'function':'list','menu':MBq6IdsKJ9z21Z}
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',WLjaXVNk2dnAJzPpy6OlMv4qoi9,K83xkHbNteiq7RnvgFSL0foXO92EmW,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'LIVETV-ITEMS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if items:
		for asKYTS478qkW in range(len(items)):
			name = items[asKYTS478qkW][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[asKYTS478qkW] = items[asKYTS478qkW][0],items[asKYTS478qkW][1],items[asKYTS478qkW][2],name,items[asKYTS478qkW][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for iEKg4FWeD9vR21wMJZYyP0dp5mojcI,fDKF4iZ5rz7McduTexbA2RpPs,zzRGXieSsdC89MgBJDWL1IwPUFoak,name,NWqAr40jTLlMBemn3o79y in items:
			if '#' in iEKg4FWeD9vR21wMJZYyP0dp5mojcI: continue
			if iEKg4FWeD9vR21wMJZYyP0dp5mojcI!='URL': name = name+HHFAVK8SwRUqBLuTfdeJ9nbD+ityRsSDe1ZNqhQ3PLjp74dfEV+iEKg4FWeD9vR21wMJZYyP0dp5mojcI+wVvqN8LZCJW5ryAb1EHRPFkQ0
			url = iEKg4FWeD9vR21wMJZYyP0dp5mojcI+';;'+fDKF4iZ5rz7McduTexbA2RpPs+';;'+zzRGXieSsdC89MgBJDWL1IwPUFoak+';;'+MBq6IdsKJ9z21Z
			EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+kh850jKbzmBwY+name,url,105,NWqAr40jTLlMBemn3o79y)
	else:
		if showDialogs: EE6ysIeB8jKNgCfOkv('link',GalrcVUMy8bzORWX5E0exhYivBwgk+'هذه الخدمة مخصصة للمبرمج فقط',kh850jKbzmBwY,9999)
	return
def yv8LezRQifhw1Kx(id):
	iEKg4FWeD9vR21wMJZYyP0dp5mojcI,fDKF4iZ5rz7McduTexbA2RpPs,zzRGXieSsdC89MgBJDWL1IwPUFoak,MBq6IdsKJ9z21Z = id.split(';;')
	url = kh850jKbzmBwY
	if iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='URL': url = zzRGXieSsdC89MgBJDWL1IwPUFoak
	elif iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='YOUTUBE':
		url = Y3Ny5eLHdp.SITESURLS['YOUTUBE'][0]+'/watch?v='+zzRGXieSsdC89MgBJDWL1IwPUFoak
		import OO3KYXPMuI
		OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo([url],vkNGie5mhCqoTFRzPKaML0x6,'live',url)
		return
	elif iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='GA':
		K83xkHbNteiq7RnvgFSL0foXO92EmW = { 'id' : kh850jKbzmBwY, 'user' : Y3Ny5eLHdp.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : kh850jKbzmBwY }
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,K83xkHbNteiq7RnvgFSL0foXO92EmW,kh850jKbzmBwY,False,kh850jKbzmBwY,'LIVETV-PLAY-1st')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		cookies = OIjmsWqwACpDMT7l3GaYbxtvh0L.cookies
		X05D3aYJrZn = cookies['ASP.NET_SessionId']
		url = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Location']
		K83xkHbNteiq7RnvgFSL0foXO92EmW = { 'id' : zzRGXieSsdC89MgBJDWL1IwPUFoak , 'user' : Y3Ny5eLHdp.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : kh850jKbzmBwY }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+X05D3aYJrZn }
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,K83xkHbNteiq7RnvgFSL0foXO92EmW,headers,kh850jKbzmBwY,kh850jKbzmBwY,'LIVETV-PLAY-2nd')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		url = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('resp":"(http.*?m3u8)(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Ga8xfYU6ht7cHjzn = url[0][0]
		fOhXn6wI7QKHMYrujAkPb2S3De = url[0][1]
		kodsg56qPXM = 'http://38.'+fDKF4iZ5rz7McduTexbA2RpPs+'777/'+zzRGXieSsdC89MgBJDWL1IwPUFoak+'_HD.m3u8'+fOhXn6wI7QKHMYrujAkPb2S3De
		xPRUvDgImp0j6w9dOZNqVQab4S = kodsg56qPXM.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		rOR8nFZNheiutKzfaTb63qV = kodsg56qPXM.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		x2xi0tpFnQgNmaJ4LR = ['HD','SD1','SD2']
		lnYtOIQ4Rkh386Bca7 = [kodsg56qPXM,xPRUvDgImp0j6w9dOZNqVQab4S,rOR8nFZNheiutKzfaTb63qV]
		TTn7mZzPRjq5GBESh8aKy = 0
		if TTn7mZzPRjq5GBESh8aKy == -1: return
		else: url = lnYtOIQ4Rkh386Bca7[TTn7mZzPRjq5GBESh8aKy]
	elif iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		K83xkHbNteiq7RnvgFSL0foXO92EmW = { 'id' : zzRGXieSsdC89MgBJDWL1IwPUFoak , 'user' : Y3Ny5eLHdp.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : MBq6IdsKJ9z21Z }
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST', WLjaXVNk2dnAJzPpy6OlMv4qoi9, K83xkHbNteiq7RnvgFSL0foXO92EmW, headers, False,kh850jKbzmBwY,'LIVETV-PLAY-3rd')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		url = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Location']
		url = url.replace('%20',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		url = url.replace('%3D','=')
		if 'Learn' in zzRGXieSsdC89MgBJDWL1IwPUFoak:
			url = url.replace('NTNNile',kh850jKbzmBwY)
			url = url.replace('learning1','Learning')
	elif iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='PL':
		K83xkHbNteiq7RnvgFSL0foXO92EmW = { 'id' : zzRGXieSsdC89MgBJDWL1IwPUFoak , 'user' : Y3Ny5eLHdp.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : MBq6IdsKJ9z21Z }
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST', WLjaXVNk2dnAJzPpy6OlMv4qoi9, K83xkHbNteiq7RnvgFSL0foXO92EmW, kh850jKbzmBwY,False,kh850jKbzmBwY,'LIVETV-PLAY-4th')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		url = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Location']
		headers = {'Referer':OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Referer']}
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'POST',url, kh850jKbzmBwY,headers , kh850jKbzmBwY,kh850jKbzmBwY,'LIVETV-PLAY-5th')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('source src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		url = items[0]
	elif iEKg4FWeD9vR21wMJZYyP0dp5mojcI in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='TA': zzRGXieSsdC89MgBJDWL1IwPUFoak = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		K83xkHbNteiq7RnvgFSL0foXO92EmW = { 'id' : zzRGXieSsdC89MgBJDWL1IwPUFoak , 'user' : Y3Ny5eLHdp.AV_CLIENT_IDS , 'function' : 'play'+iEKg4FWeD9vR21wMJZYyP0dp5mojcI , 'menu' : MBq6IdsKJ9z21Z }
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',WLjaXVNk2dnAJzPpy6OlMv4qoi9,K83xkHbNteiq7RnvgFSL0foXO92EmW,headers,kh850jKbzmBwY,kh850jKbzmBwY,'LIVETV-PLAY-6th')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded:
			o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		url = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Location']
		if iEKg4FWeD9vR21wMJZYyP0dp5mojcI=='FM':
			OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, False,kh850jKbzmBwY,'LIVETV-PLAY-7th')
			url = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers['Location']
			url = url.replace('https','http')
	NRlCaq1ndM(url,vkNGie5mhCqoTFRzPKaML0x6,'live')
	return
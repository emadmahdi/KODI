# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'CIMA4U'
headers = {'User-Agent':kh850jKbzmBwY}
GalrcVUMy8bzORWX5E0exhYivBwgk = '_C4U_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==420: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==421: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==422: PP3FsDicLyWuTR7GV5Ia = xyLG18ZqBpNfXtUM04lH(url)
	elif mode==423: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
	elif mode==424: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: PP3FsDicLyWuTR7GV5Ia = cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==427: PP3FsDicLyWuTR7GV5Ia = Qd6OnrkNEhTtq3AeVLJZPU1XWMw(url)
	elif mode==429: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	giRfrJxZdQ16bw2oe = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	giRfrJxZdQ16bw2oe = giRfrJxZdQ16bw2oe[0].strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(giRfrJxZdQ16bw2oe,'url')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,429,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر محدد',giRfrJxZdQ16bw2oe,425)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'فلتر كامل',giRfrJxZdQ16bw2oe,424)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'الرئيسية',giRfrJxZdQ16bw2oe,421)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('NavigationMenu(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="*(.*?)"*>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		if '/actors' in Ga8xfYU6ht7cHjzn: title = 'أفلام النجوم'
		elif '/netflix' in Ga8xfYU6ht7cHjzn: title = 'أفلام ومسلسلات نيتفلكس'
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,421)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'قائمة تفصيلية',giRfrJxZdQ16bw2oe,427)
	return
def Qd6OnrkNEhTtq3AeVLJZPU1XWMw(website=kh850jKbzmBwY):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('FilteringTitle(.*?)PageTitle',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for XvPwmy3axVdD6NIKGb4Ak,id,Ga8xfYU6ht7cHjzn,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		if 'netflix-movies' in Ga8xfYU6ht7cHjzn: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in Ga8xfYU6ht7cHjzn: title = 'مسلسلات نيتفلكس'
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,421,kh850jKbzmBwY,kh850jKbzmBwY,XvPwmy3axVdD6NIKGb4Ak+'|'+id)
	return
def bsZhnoqjD3U(url,JjH8Zr42QL5AnsweEIRxltWcp=kh850jKbzmBwY):
	if '/HomepageLoader/' in url: url = url.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)+'/mpaa/family/'
	items = []
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if not JjH8Zr42QL5AnsweEIRxltWcp or '|' in JjH8Zr42QL5AnsweEIRxltWcp:
		if '|' not in JjH8Zr42QL5AnsweEIRxltWcp: lqm3uMF67XW = kh850jKbzmBwY
		else: lqm3uMF67XW = '/archive/'+JjH8Zr42QL5AnsweEIRxltWcp
		UvRfFQ3xmypVPL4GOHXcloekW1rCi7 = False
		if 'PinSlider' in uP1m46pAK5a3UgdqvBz9rnL:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'المميزة',url,421,kh850jKbzmBwY,kh850jKbzmBwY,'featured')
			UvRfFQ3xmypVPL4GOHXcloekW1rCi7 = True
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('PageTitle(.*?)PageContent',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			c0jtBCYDEkL5HJfVX = liroJ6qCK9k[0]
			h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-tab="(.*?)".*?<span>(.*?)<',c0jtBCYDEkL5HJfVX,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for mwzAPgxfYF2dyTH,EVfKyFrmX1Mpb62tLuHS5w3W in h729UnyEIjoYSNKcLOvqfV4:
				jQOlvATLDcdquxVXaJib3Yo5 = giRfrJxZdQ16bw2oe+'/ajaxcenter/action/HomepageLoader/tab/'+mwzAPgxfYF2dyTH+lqm3uMF67XW+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+EVfKyFrmX1Mpb62tLuHS5w3W,jQOlvATLDcdquxVXaJib3Yo5,421)
				UvRfFQ3xmypVPL4GOHXcloekW1rCi7 = True
		if UvRfFQ3xmypVPL4GOHXcloekW1rCi7: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	if JjH8Zr42QL5AnsweEIRxltWcp=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('PinSlider(.*?)MultiFilter',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('PinSlider(.*?)PageTitle',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		else: ZZDUdXR52CMs9K73Ex = kh850jKbzmBwY
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
	elif '/filter/' in url:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('PageContent(.*?)class="*pagination"*',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	elif '/actors' in url:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('PageContent(.*?)class="*pagination"*',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('Cima4uBlocks(.*?)</li></ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		else: ZZDUdXR52CMs9K73Ex = kh850jKbzmBwY
	if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title in items:
		if not title: continue
		if '?news=' in Ga8xfYU6ht7cHjzn: continue
		title = title.replace('مشاهدة ',kh850jKbzmBwY)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) حلقة \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if WULSmfNH09tPIv58snzpCkR and 'حلقة' in title:
			title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0]
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,422,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		elif '/actor/' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,421,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,422,NWqAr40jTLlMBemn3o79y)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k and JjH8Zr42QL5AnsweEIRxltWcp!='featured':
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
			title = title.replace('الصفحة ',kh850jKbzmBwY)
			if title!=kh850jKbzmBwY: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,421)
	QWK6fmVB8eAjab = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('</li><a href="(.*?)".*?>(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if QWK6fmVB8eAjab:
		Ga8xfYU6ht7cHjzn,title = QWK6fmVB8eAjab[0]
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,421)
	return
def xyLG18ZqBpNfXtUM04lH(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-SEASONS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="WatchNow".*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		url = liroJ6qCK9k[0]
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-SEASONS-2nd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('SeasonsSections(.*?)</div></div></div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if '/tag/' in url or '/actor' in url:
		bsZhnoqjD3U(url)
	elif liroJ6qCK9k:
		NWqAr40jTLlMBemn3o79y = ppNwDFByU1dZn5ca.getInfoLabel('ListItem.Thumb')
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("href='(.*?)'>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		HsUlZgC4mrjRcJBz = ['مسلسل','موسم','برنامج','حلقة']
		for Ga8xfYU6ht7cHjzn,title in items:
			if any(value in title for value in HsUlZgC4mrjRcJBz):
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,423,NWqAr40jTLlMBemn3o79y)
			else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,426,NWqAr40jTLlMBemn3o79y)
	else: do7Es2fUtFlM8ScLx(url)
	return
def do7Es2fUtFlM8ScLx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-EPISODES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	NWqAr40jTLlMBemn3o79y = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"background-image:url\((.*?)\)',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if NWqAr40jTLlMBemn3o79y: NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y[0]
	else: NWqAr40jTLlMBemn3o79y = kh850jKbzmBwY
	YKBAXf6roDUj0vI4ta2 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('EpisodesSection(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if YKBAXf6roDUj0vI4ta2:
		ZZDUdXR52CMs9K73Ex = YKBAXf6roDUj0vI4ta2[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,WULSmfNH09tPIv58snzpCkR in items:
			title = title+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+WULSmfNH09tPIv58snzpCkR
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,426,NWqAr40jTLlMBemn3o79y)
	else: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+'رابط التشغيل',url,426,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	gwTxGW5o3mcX4QzlfIuSHU = OIjmsWqwACpDMT7l3GaYbxtvh0L.url
	if BBJYzRKgHkOqx: gwTxGW5o3mcX4QzlfIuSHU = gwTxGW5o3mcX4QzlfIuSHU.encode(NVbhZ0DTpOkCA)
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(gwTxGW5o3mcX4QzlfIuSHU,'url')
	lnYtOIQ4Rkh386Bca7 = []
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('WatchSection(.*?)</div></div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-link="(.*?)".*? />(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for b95XrOmEyKwYDUPzV,title in items:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if 'myvid' in title.lower(): title = 'خاص '+title
			Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+'/structure/server.php?id='+b95XrOmEyKwYDUPzV+'?named='+title+'__watch'
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace(lpaqU2W5YZ4v6MuVyecsDIEO,kh850jKbzmBwY)
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('DownloadServers(.*?)</div></div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*? />(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if 'myvid' in title.lower(): EVfKyFrmX1Mpb62tLuHS5w3W = '__خاص'
			else: EVfKyFrmX1Mpb62tLuHS5w3W = kh850jKbzmBwY
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__download'+EVfKyFrmX1Mpb62tLuHS5w3W
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace(lpaqU2W5YZ4v6MuVyecsDIEO,kh850jKbzmBwY)
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/Search?q='+search
	bsZhnoqjD3U(url,'search')
	return
def vgP862NBF4UG(url):
	if 'smartemadfilter' not in url: url = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('MultiFilter(.*?)PageTitle',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	deib7XxUZCQw8HA1n = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	return deib7XxUZCQw8HA1n
def OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex):
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-id="(.*?)".*?</div>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	return items
def bF2piHrjYeOC7uxPz(url):
	gdGWEPpk3frFTQa8wcYhqMyV4 = url.split('/smartemadfilter?')[0]
	jjEqDAJkvVXK5WdC0xSGR2m = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	url = url.replace(gdGWEPpk3frFTQa8wcYhqMyV4,jjEqDAJkvVXK5WdC0xSGR2m)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M).replace('&',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
	url = url+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M
	return url
XXSxywJDNdUneWclbfI7 = ['category','types','release-year']
vKwTaOAiBIbCjhdJktHeuMyWz8 = ['Quality','release-year','types','category']
def cf9bnl3ZAhJLt24qxIFwGzuNsMi(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==kh850jKbzmBwY: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = kh850jKbzmBwY,kh850jKbzmBwY
	else: WQEFAlL7oCZ3XBt,CW52XnyslubD60Y4LNHp3hzZ9VP8 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global XXSxywJDNdUneWclbfI7
			XXSxywJDNdUneWclbfI7 = XXSxywJDNdUneWclbfI7[1:]
		if XXSxywJDNdUneWclbfI7[0]+'=' not in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[0]
		for asKYTS478qkW in range(len(XXSxywJDNdUneWclbfI7[0:-1])):
			if XXSxywJDNdUneWclbfI7[asKYTS478qkW]+'=' in WQEFAlL7oCZ3XBt: XvPwmy3axVdD6NIKGb4Ak = XXSxywJDNdUneWclbfI7[asKYTS478qkW+1]
		oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+XvPwmy3axVdD6NIKGb4Ak+'=0'
		mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ.strip('&')+'___'+oufZ8U7XLDFy4b.strip('&')
		PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		O9wzaDlICnq = url+'/smartemadfilter?'+PhFd0yvXWULQIfu9N2pSYDRCx
	elif type=='ALL_ITEMS_FILTER':
		FCyjlpcBn5OG2Nowxvf6WQS74 = Md2htF3Gi186nWlYkJq(WQEFAlL7oCZ3XBt,'modified_values')
		FCyjlpcBn5OG2Nowxvf6WQS74 = KsuzxGjOHChbIXrwWm(FCyjlpcBn5OG2Nowxvf6WQS74)
		if CW52XnyslubD60Y4LNHp3hzZ9VP8!=kh850jKbzmBwY: CW52XnyslubD60Y4LNHp3hzZ9VP8 = Md2htF3Gi186nWlYkJq(CW52XnyslubD60Y4LNHp3hzZ9VP8,'modified_filters')
		if CW52XnyslubD60Y4LNHp3hzZ9VP8==kh850jKbzmBwY: O9wzaDlICnq = url
		else: O9wzaDlICnq = url+'/smartemadfilter?'+CW52XnyslubD60Y4LNHp3hzZ9VP8
		O9wzaDlICnq = bF2piHrjYeOC7uxPz(O9wzaDlICnq)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'أظهار قائمة الفيديو التي تم اختيارها ',O9wzaDlICnq,421,kh850jKbzmBwY,kh850jKbzmBwY,'filter')
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+' [[   '+FCyjlpcBn5OG2Nowxvf6WQS74+'   ]]',O9wzaDlICnq,421,kh850jKbzmBwY,kh850jKbzmBwY,'filter')
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	deib7XxUZCQw8HA1n = vgP862NBF4UG(url)
	dict = {}
	for name,ZZDUdXR52CMs9K73Ex,uHwkOpvAPM3bqC72KZstX in deib7XxUZCQw8HA1n:
		if '/category/' in url and uHwkOpvAPM3bqC72KZstX=='category': continue
		name = name.replace('--',kh850jKbzmBwY)
		items = OtqmR0wXGsoZjia1hK(ZZDUdXR52CMs9K73Ex)
		if '=' not in O9wzaDlICnq: O9wzaDlICnq = url
		if type=='SPECIFIED_FILTER':
			if XvPwmy3axVdD6NIKGb4Ak!=uHwkOpvAPM3bqC72KZstX: continue
			elif len(items)<2:
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]:
					url = bF2piHrjYeOC7uxPz(url)
					bsZhnoqjD3U(url)
				else: cf9bnl3ZAhJLt24qxIFwGzuNsMi(O9wzaDlICnq,'SPECIFIED_FILTER___'+mDAEOKl2SQpv71acI4PJj5Hs9XzT)
				return
			else:
				O9wzaDlICnq = bF2piHrjYeOC7uxPz(O9wzaDlICnq)
				if uHwkOpvAPM3bqC72KZstX==XXSxywJDNdUneWclbfI7[-1]: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,421,kh850jKbzmBwY,kh850jKbzmBwY,'filter')
				else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع',O9wzaDlICnq,425,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		elif type=='ALL_ITEMS_FILTER':
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'=0'
			mDAEOKl2SQpv71acI4PJj5Hs9XzT = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الجميع :'+name,O9wzaDlICnq,424,kh850jKbzmBwY,kh850jKbzmBwY,mDAEOKl2SQpv71acI4PJj5Hs9XzT)
		dict[uHwkOpvAPM3bqC72KZstX] = {}
		for value,OSvbC40RHt2AWY in items:
			if value=='196533': OSvbC40RHt2AWY = 'أفلام نيتفلكس'
			elif value=='196531': OSvbC40RHt2AWY = 'مسلسلات نيتفلكس'
			if OSvbC40RHt2AWY in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			dict[uHwkOpvAPM3bqC72KZstX][value] = OSvbC40RHt2AWY
			oXj3aANJy9KfGnze0xY2Lu41OZQ = WQEFAlL7oCZ3XBt+'&'+uHwkOpvAPM3bqC72KZstX+'='+OSvbC40RHt2AWY
			oufZ8U7XLDFy4b = CW52XnyslubD60Y4LNHp3hzZ9VP8+'&'+uHwkOpvAPM3bqC72KZstX+'='+value
			qCdAhU0NW12mBS9neTQgwi = oXj3aANJy9KfGnze0xY2Lu41OZQ+'___'+oufZ8U7XLDFy4b
			title = OSvbC40RHt2AWY+' :'#+dict[uHwkOpvAPM3bqC72KZstX]['0']
			title = OSvbC40RHt2AWY+' :'+name
			if type=='ALL_ITEMS_FILTER': EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,424,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
			elif type=='SPECIFIED_FILTER' and XXSxywJDNdUneWclbfI7[-2]+'=' in WQEFAlL7oCZ3XBt:
				PhFd0yvXWULQIfu9N2pSYDRCx = Md2htF3Gi186nWlYkJq(oufZ8U7XLDFy4b,'modified_filters')
				QQJdiByEeNqLYGs = url+'/smartemadfilter?'+PhFd0yvXWULQIfu9N2pSYDRCx
				QQJdiByEeNqLYGs = bF2piHrjYeOC7uxPz(QQJdiByEeNqLYGs)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,QQJdiByEeNqLYGs,421,kh850jKbzmBwY,kh850jKbzmBwY,'filter')
			else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,425,kh850jKbzmBwY,kh850jKbzmBwY,qCdAhU0NW12mBS9neTQgwi)
	return
def Md2htF3Gi186nWlYkJq(T3IPgzYmNnC9tkupohdRj2Qf,mode):
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.replace('=&','=0&')
	T3IPgzYmNnC9tkupohdRj2Qf = T3IPgzYmNnC9tkupohdRj2Qf.strip('&')
	yXeoduEjYKJLf0OinrlVzN3 = {}
	if '=' in T3IPgzYmNnC9tkupohdRj2Qf:
		items = T3IPgzYmNnC9tkupohdRj2Qf.split('&')
		for JJNIsO8Vcbx0 in items:
			moT0kOcKq7JPVSt3L,value = JJNIsO8Vcbx0.split('=')
			yXeoduEjYKJLf0OinrlVzN3[moT0kOcKq7JPVSt3L] = value
	jjSBkesYpFQc6A1q8RfVJgW = kh850jKbzmBwY
	for key in vKwTaOAiBIbCjhdJktHeuMyWz8:
		if key in list(yXeoduEjYKJLf0OinrlVzN3.keys()): value = yXeoduEjYKJLf0OinrlVzN3[key]
		else: value = '0'
		if '%' not in value: value = ioZ083zxYk(value)
		if mode=='modified_values' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+' + '+value
		elif mode=='modified_filters' and value!='0': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
		elif mode=='all': jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW+'&'+key+'='+value
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip(' + ')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.strip('&')
	jjSBkesYpFQc6A1q8RfVJgW = jjSBkesYpFQc6A1q8RfVJgW.replace('=0','=')
	return jjSBkesYpFQc6A1q8RfVJgW
# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'MASAVIDEO'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_MSV_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = ''
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==1040: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==1041: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==1042: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==1043: PP3FsDicLyWuTR7GV5Ia = CYnmhWAZaoUXGcVJD67(url,text)
	elif mode==1044: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==1049: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'MASAVIDEO-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,1049,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''["']navslide-wrap["'](.*?)</ul>''',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
			EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1044)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('/category.php">(.*?)"navslide-divider"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''["']dropdown-menu["'](.*?)</ul>''',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for c0jtBCYDEkL5HJfVX in liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace(c0jtBCYDEkL5HJfVX,kh850jKbzmBwY)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if not title: continue
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1044)
	return
def CC6NMTjSO2g(url):
	qwPT5Yf7y2J1d8eX,h729UnyEIjoYSNKcLOvqfV4 = [],[]
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'MASAVIDEO-SUBMENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if NSUBGjzyZh5xaKL9AJF and '.php' in str(NSUBGjzyZh5xaKL9AJF):
		ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
		ZZDUdXR52CMs9K73Ex = ZZDUdXR52CMs9K73Ex.replace('"presentation"','</ul>')
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = [(kh850jKbzmBwY,ZZDUdXR52CMs9K73Ex)]
		EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' فرز أو فلتر أو ترتيب '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		for JLngAu1qYhtXm0BNr,ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
			qwPT5Yf7y2J1d8eX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if JLngAu1qYhtXm0BNr: JLngAu1qYhtXm0BNr = JLngAu1qYhtXm0BNr+': '
			for Ga8xfYU6ht7cHjzn,title in qwPT5Yf7y2J1d8eX:
				title = JLngAu1qYhtXm0BNr+title
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1041)
	oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-category-subcats"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if oQuiJvtTzwPZbXd7sf4HcG9:
		ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if 1 or len(h729UnyEIjoYSNKcLOvqfV4)<30:
			if qwPT5Yf7y2J1d8eX: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
			for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4:
				if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1041)
	if not NSUBGjzyZh5xaKL9AJF and not oQuiJvtTzwPZbXd7sf4HcG9: bsZhnoqjD3U(url)
	return
def bsZhnoqjD3U(url,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		tqQkcdHYyM3L7h = headers.copy()
		tqQkcdHYyM3L7h['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'POST',url,data,tqQkcdHYyM3L7h,kh850jKbzmBwY,kh850jKbzmBwY,'MASAVIDEO-TITLES-1st')
	else:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'MASAVIDEO-TITLES-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	ZZDUdXR52CMs9K73Ex,items = kh850jKbzmBwY,[]
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='ajax-search':
		ZZDUdXR52CMs9K73Ex = uP1m46pAK5a3UgdqvBz9rnL
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in h729UnyEIjoYSNKcLOvqfV4: items.append((kh850jKbzmBwY,Ga8xfYU6ht7cHjzn,title))
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-carousel_featured"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_episodes':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_movies':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"row pm-ul-browse-videos(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(liroJ6qCK9k)>1: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[1]
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured_series':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-grid"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if ZZDUdXR52CMs9K73Ex and not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"thumbnail".*?<a href="([^"]*)" title="([^"]*)".*?src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items: return
	SHTvIuhX52dxQRsWA = []
	fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in items:
		NWqAr40jTLlMBemn3o79y += '|Referer='+WLjaXVNk2dnAJzPpy6OlMv4qoi9
		if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة).\d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1042,NWqAr40jTLlMBemn3o79y)
		elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='new_episodes':
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1042,NWqAr40jTLlMBemn3o79y)
		elif WULSmfNH09tPIv58snzpCkR:
			title = '_MOD_' + WULSmfNH09tPIv58snzpCkR[0][0]
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1043,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1043,NWqAr40jTLlMBemn3o79y)
	if 1:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn=='#': continue
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,1041)
	return
def CYnmhWAZaoUXGcVJD67(url,GGy6r8KUN0WjnqoTR):
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'MASAVIDEO-EPISODES-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	vvufbqFnUclCD5MxOz = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pm-poster-img.*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	NWqAr40jTLlMBemn3o79y = vvufbqFnUclCD5MxOz[0] if vvufbqFnUclCD5MxOz else kh850jKbzmBwY
	NWqAr40jTLlMBemn3o79y += '|Referer='+WLjaXVNk2dnAJzPpy6OlMv4qoi9
	items = []
	gFthaolRMw = False
	if NSUBGjzyZh5xaKL9AJF and not GGy6r8KUN0WjnqoTR:
		ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for GGy6r8KUN0WjnqoTR,title in items:
			GGy6r8KUN0WjnqoTR = GGy6r8KUN0WjnqoTR.strip('#')
			if len(items)>1: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,1043,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,GGy6r8KUN0WjnqoTR)
			else: gFthaolRMw = True
	else: gFthaolRMw = True
	oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="'+GGy6r8KUN0WjnqoTR+'"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not oQuiJvtTzwPZbXd7sf4HcG9:
		oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"AiredEPS"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if oQuiJvtTzwPZbXd7sf4HcG9:
			ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				title = title.replace('</em><span>',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1042,NWqAr40jTLlMBemn3o79y)
	elif oQuiJvtTzwPZbXd7sf4HcG9 and gFthaolRMw:
		ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		h729UnyEIjoYSNKcLOvqfV4 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if h729UnyEIjoYSNKcLOvqfV4:
			PhR5sWKu8z2AedF,ZMcSrpiq5w = zip(*h729UnyEIjoYSNKcLOvqfV4)
			E1MINJpxseDo = [NWqAr40jTLlMBemn3o79y]*len(h729UnyEIjoYSNKcLOvqfV4)
			items = zip(ZMcSrpiq5w,PhR5sWKu8z2AedF,E1MINJpxseDo)
		if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"thumbnail".*?href="([^"]*)" title="([^"]*)".*?src="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in items:
			NWqAr40jTLlMBemn3o79y += '|Referer='+WLjaXVNk2dnAJzPpy6OlMv4qoi9
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			title = title.replace('</em><span>',EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,1042,NWqAr40jTLlMBemn3o79y)
	return
def yv8LezRQifhw1Kx(url):
	owMxje0p9Ya3CkhJDX,OEVmWsLiSNvybAxc2e9Id8C1jkRXp = [],[]
	uP1m46pAK5a3UgdqvBz9rnL = ''
	if 'post=' in uP1m46pAK5a3UgdqvBz9rnL:
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="player".*?href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
		LsgQIK6E08od3r5 = Ga8xfYU6ht7cHjzn.split('post=')[1]
		LsgQIK6E08od3r5 = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(LsgQIK6E08od3r5)
		if eOQJrvLAZC: LsgQIK6E08od3r5 = LsgQIK6E08od3r5.decode(NVbhZ0DTpOkCA)
		LsgQIK6E08od3r5 = tmYCsS329HanzjLFbJP('dict',LsgQIK6E08od3r5)
		Sp6qOyDB0nt5Qo4KwbPfcWYe = LsgQIK6E08od3r5['servers']
		LtaDBqr1oOpP0Yz3g4ci8 = list(Sp6qOyDB0nt5Qo4KwbPfcWYe.keys())
		Sp6qOyDB0nt5Qo4KwbPfcWYe = list(Sp6qOyDB0nt5Qo4KwbPfcWYe.values())
		cbEeOrp1di2TL7GXnguA6f = zip(LtaDBqr1oOpP0Yz3g4ci8,Sp6qOyDB0nt5Qo4KwbPfcWYe)
		for title,Ga8xfYU6ht7cHjzn in cbEeOrp1di2TL7GXnguA6f:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
			owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	else:
		O9wzaDlICnq = url.replace('watch.php','play.php')
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'MASAVIDEO-PLAY2-1st')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"embedURL" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if 0 and Ga8xfYU6ht7cHjzn:
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
			if Ga8xfYU6ht7cHjzn not in OEVmWsLiSNvybAxc2e9Id8C1jkRXp:
				OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
				fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+fDKF4iZ5rz7McduTexbA2RpPs+'__embed'
				owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('list_server(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("<iframe src='(.*?)'.*?<strong>(.*?)<",ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
				OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
				fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+fDKF4iZ5rz7McduTexbA2RpPs+'__watch'
				owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
		O9wzaDlICnq = url.replace('watch.php','downloads.php')
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,False,'MASAVIDEO-PLAY-2nd')
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pm-download"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for ZZDUdXR52CMs9K73Ex in liroJ6qCK9k:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<strong>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<span>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn in OEVmWsLiSNvybAxc2e9Id8C1jkRXp: continue
				OEVmWsLiSNvybAxc2e9Id8C1jkRXp.append(Ga8xfYU6ht7cHjzn)
				fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+fDKF4iZ5rz7McduTexbA2RpPs+'__download'
				owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search.php?keywords='+search
	bsZhnoqjD3U(url,'search')
	return
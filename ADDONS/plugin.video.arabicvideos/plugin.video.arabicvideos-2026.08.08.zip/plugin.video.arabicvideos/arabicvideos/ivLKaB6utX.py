# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'CIMALIGHT'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_CML_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
QQeT5Ntzv2ysxVmLHj1adM40iYpk = ['قنوات فضائية']
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==470: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==471: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url,text)
	elif mode==472: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==473: PP3FsDicLyWuTR7GV5Ia = CYnmhWAZaoUXGcVJD67(url,text)
	elif mode==474: PP3FsDicLyWuTR7GV5Ia = CC6NMTjSO2g(url)
	elif mode==479: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,479,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"content"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?</i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		title = title.replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn.replace('cat=online-movies1','cat=online-movies')
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,474)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('/category.php">(.*?)"navslide-divider"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("'dropdown-menu'(.*?)</ul>",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if title in QQeT5Ntzv2ysxVmLHj1adM40iYpk: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,474)
	return
def CC6NMTjSO2g(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if 'topvideos.php' in url: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)id="pm-grid"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	else: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"caret"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if 'topvideos.php' in Ga8xfYU6ht7cHjzn:
				if 'topvideos.php?c=english-movies' in Ga8xfYU6ht7cHjzn: continue
				if 'topvideos.php?c=online-movies1' in Ga8xfYU6ht7cHjzn: continue
				if 'topvideos.php?c=misc' in Ga8xfYU6ht7cHjzn: continue
				if 'topvideos.php?c=tv-channel' in Ga8xfYU6ht7cHjzn: continue
				if 'منذ البداية' in title and 'do=rating' not in Ga8xfYU6ht7cHjzn: continue
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,471)
	else: bsZhnoqjD3U(url)
	return
def bsZhnoqjD3U(url,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=kh850jKbzmBwY):
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	items = []
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured_movies':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"container-fluid"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8,wMyL0gj6chJTnR3ut9iHaWO = zip(*items)
		items = zip(wMyL0gj6chJTnR3ut9iHaWO,Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8)
	elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG=='featured_series':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('المسلسلات المميزة(.*?)<style>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8,wMyL0gj6chJTnR3ut9iHaWO = zip(*items)
		items = zip(wMyL0gj6chJTnR3ut9iHaWO,Sp6qOyDB0nt5Qo4KwbPfcWYe,LtaDBqr1oOpP0Yz3g4ci8)
	else:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(data-echo=".*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"BlocksList"(.*?)"titleSectionCon"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="pm-grid"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="pm-related"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pm-ul-browse-videos(.*?)clearfix',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not liroJ6qCK9k: return
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not items: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	SHTvIuhX52dxQRsWA = []
	fWEJvk6xoYzOmT2B1ld374 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title in items:
		Ga8xfYU6ht7cHjzn = KsuzxGjOHChbIXrwWm(Ga8xfYU6ht7cHjzn).strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		title = title.replace('ماي سيما',kh850jKbzmBwY).replace('مشاهدة',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		if 'http' not in NWqAr40jTLlMBemn3o79y: NWqAr40jTLlMBemn3o79y = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+NWqAr40jTLlMBemn3o79y.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة) \d+',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if any(value in title for value in fWEJvk6xoYzOmT2B1ld374):
			title = '_MOD_'+title
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,472,NWqAr40jTLlMBemn3o79y)
		elif WULSmfNH09tPIv58snzpCkR and 'حلقة' in title:
			title = '_MOD_'+WULSmfNH09tPIv58snzpCkR[0][0]
			if title not in SHTvIuhX52dxQRsWA:
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,473,NWqAr40jTLlMBemn3o79y)
				SHTvIuhX52dxQRsWA.append(title)
		elif '/movseries/' in Ga8xfYU6ht7cHjzn:
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,471,NWqAr40jTLlMBemn3o79y)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,473,NWqAr40jTLlMBemn3o79y)
	if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG not in ['featured_movies','featured_series']:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"pagination(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if liroJ6qCK9k:
			ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)</a>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title in items:
				if Ga8xfYU6ht7cHjzn=='#': continue
				Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+title,Ga8xfYU6ht7cHjzn,471)
		QWK6fmVB8eAjab = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('showmore" href="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if QWK6fmVB8eAjab:
			Ga8xfYU6ht7cHjzn = QWK6fmVB8eAjab[0]
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مشاهدة المزيد',Ga8xfYU6ht7cHjzn,471)
	return
def CYnmhWAZaoUXGcVJD67(url,GGy6r8KUN0WjnqoTR):
	giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url,'url')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-EPISODES-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	NSUBGjzyZh5xaKL9AJF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"SeasonsBox"(.*?)</div>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	items = []
	if NSUBGjzyZh5xaKL9AJF and not GGy6r8KUN0WjnqoTR:
		NWqAr40jTLlMBemn3o79y = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"series-header".*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y[0] if NWqAr40jTLlMBemn3o79y else kh850jKbzmBwY
		ZZDUdXR52CMs9K73Ex = NSUBGjzyZh5xaKL9AJF[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if len(items)==1: GGy6r8KUN0WjnqoTR = items[0][0]
		elif len(items)>1:
			for GGy6r8KUN0WjnqoTR,title in items: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,url,473,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,GGy6r8KUN0WjnqoTR)
	oQuiJvtTzwPZbXd7sf4HcG9 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="'+GGy6r8KUN0WjnqoTR+'"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if oQuiJvtTzwPZbXd7sf4HcG9 and len(items)<2:
		NWqAr40jTLlMBemn3o79y = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"series-header".*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y[0] if NWqAr40jTLlMBemn3o79y else kh850jKbzmBwY
		ZZDUdXR52CMs9K73Ex = oQuiJvtTzwPZbXd7sf4HcG9[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)"',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if items:
			for Ga8xfYU6ht7cHjzn,title in items:
				title = title.replace('ماي سيما',kh850jKbzmBwY).replace('مسلسل',kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,472,NWqAr40jTLlMBemn3o79y)
		else:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title,NWqAr40jTLlMBemn3o79y in items:
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = giRfrJxZdQ16bw2oe+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn.strip(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,472,NWqAr40jTLlMBemn3o79y)
	if 'id="pm-related"' in uP1m46pAK5a3UgdqvBz9rnL:
		if items: EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'مواضيع ذات صلة',url,471)
	return
def yv8LezRQifhw1Kx(url):
	lnYtOIQ4Rkh386Bca7 = []
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<div itemprop="description">(.*?)href=',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		ZspMxOvY50RNBKew1JqzD26tLV = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<p>(.*?)</p>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if ZspMxOvY50RNBKew1JqzD26tLV and EEvng7MJTeOpm8GbzX(vkNGie5mhCqoTFRzPKaML0x6,url,ZspMxOvY50RNBKew1JqzD26tLV,True): return
	O9wzaDlICnq = url.replace('/watch.php','/play.php')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-PLAY-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	Wusgc79FEHCbt4alpP5AnUBeJvdORQ = []
	Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"embedded".*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if Ga8xfYU6ht7cHjzn:
		Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
		if Ga8xfYU6ht7cHjzn and Ga8xfYU6ht7cHjzn not in Wusgc79FEHCbt4alpP5AnUBeJvdORQ:
			Wusgc79FEHCbt4alpP5AnUBeJvdORQ.append(Ga8xfYU6ht7cHjzn)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named=__embed'
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall("iframe src='(.*?)'.*?<strong>(.*?)</strong>",uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		if Ga8xfYU6ht7cHjzn not in Wusgc79FEHCbt4alpP5AnUBeJvdORQ:
			Wusgc79FEHCbt4alpP5AnUBeJvdORQ.append(Ga8xfYU6ht7cHjzn)
			Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__watch'
			if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
			lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	O9wzaDlICnq = url.replace('/watch.php','/downloads.php')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',O9wzaDlICnq,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'CIMALIGHT-PLAY-3rd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"downloadlist"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<strong>(.*?)</strong>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title in items:
			if Ga8xfYU6ht7cHjzn not in Wusgc79FEHCbt4alpP5AnUBeJvdORQ:
				Wusgc79FEHCbt4alpP5AnUBeJvdORQ.append(Ga8xfYU6ht7cHjzn)
				Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn+'?named='+title+'__download'
				if 'http' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = 'http:'+Ga8xfYU6ht7cHjzn
				lnYtOIQ4Rkh386Bca7.append(Ga8xfYU6ht7cHjzn)
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(lnYtOIQ4Rkh386Bca7,vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	fDKF4iZ5rz7McduTexbA2RpPs = hBRWs4K6t1nderkNEQo7bIvCFuZfS(WLjaXVNk2dnAJzPpy6OlMv4qoi9,'url')
	url = fDKF4iZ5rz7McduTexbA2RpPs+'/search.php?keywords='+search
	bsZhnoqjD3U(url,'search')
	return
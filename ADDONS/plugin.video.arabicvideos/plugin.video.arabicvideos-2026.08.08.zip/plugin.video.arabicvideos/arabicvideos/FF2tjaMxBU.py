# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
nxUveizbLEAT2FBNy3 = sdRqnego9PclrL4m2J(u"࠱ୌ")
igM4DhpPzoX95Ysnar6Auj = CMUXq6mPQV5rLsSBdWZJvA(u"࠳୍")
s0sB2Xyp9uYU5N3fxzKoLW8 = igM4DhpPzoX95Ysnar6Auj+igM4DhpPzoX95Ysnar6Auj
Q5yM0D6SaP9teHXufTGjUBc = s0sB2Xyp9uYU5N3fxzKoLW8+igM4DhpPzoX95Ysnar6Auj
HHQhABuNKV7cd = Q5yM0D6SaP9teHXufTGjUBc+igM4DhpPzoX95Ysnar6Auj
XONpB38LESgyRmt = HHQhABuNKV7cd+igM4DhpPzoX95Ysnar6Auj
kh850jKbzmBwY = sdRqnego9PclrL4m2J(u"ࠨࠩऎ")
EE3iZM15sTQ2t9cOhuCWwDjGSUzryF = taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࠣࠫए")
cyR2rJzGpVSXNuHsEQjk60fvFetYDx = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF*s0sB2Xyp9uYU5N3fxzKoLW8
ityRsSDe1ZNqhQ3PLjp74dfEV = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF*Q5yM0D6SaP9teHXufTGjUBc
eexO1A6EKJIVruD87qmaiGhbw = EE3iZM15sTQ2t9cOhuCWwDjGSUzryF*HHQhABuNKV7cd
i2xvIPUGcdqsV5FnDfwBklhjCNXo7M = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪ࠳ࠬऐ")
bruAOCB4ZoHVF7 = tzEjvOaZWU1A(u"ࠫ࠴࠵ࠧऑ")
Yv0mlf7x2VyTOQrw3GLHhE9M8pnzs = None
dbo4vrnTM56I = oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࡚ࡲࡶࡧ௝")
wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1 = taD1d3bpqyfM4VNhK0P29GSZ(u"ࡆࡢ࡮ࡶࡩ௞")
Cs4q8pHiOvZM6LAdeEtRPf = ZeV4vau9CjN(u"ࠬࡺࡲࡶࡧࠪऒ")
SmThPgBVzt8 = u8iSx05wLfVyMNp1X3l(u"࠭ࡦࡢ࡮ࡶࡩࠬओ")
CZcUWsSLm46e37YphagTvVld = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧऔ")
yBOdNtTJF1m = tzEjvOaZWU1A(u"ࠨࡦࡨࡪࡦࡻ࡬ࡵࠩक")
HHFAVK8SwRUqBLuTfdeJ9nbD = YoMw2J1Ljp(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡂ࠶࠴ࡉࡡࠬख")
RlMpu0hP8YmzZovkVXOs1G = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ग")
WLMh7bYQKiTC0n2lwmFgPxac8 = tzEjvOaZWU1A(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠳࠴ࡇ࠷࠷࠸ࡣࠧघ")
Ws6T43Ff1i8xHzR = tzEjvOaZWU1A(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠲ࡈ࠸࠵ࡋࡌ࡝ࠨङ")
cnh21VvwsA67eNtIB9DumazSCQr = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋࡌࡆ࡞ࠩच")
wVvqN8LZCJW5ryAb1EHRPFkQ0 = BBOY8rvinVbFh(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩछ")
NVbhZ0DTpOkCA = tzEjvOaZWU1A(u"ࠨࡷࡷࡪ࠽࠭ज")
BPnjKce5wR = dQvxmFkyLOteNMWBJ2bDHV(u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪझ")
Vl3xtR0PmB = taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩञ")
Ll16ekoIZjzN9E = sdRqnego9PclrL4m2J(u"ࠫࡓࡕࡔࡊࡅࡈࠫट")
Z75FAEJHyizqQG1DSwnK9fLrvjUWkI = SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡋࡒࡓࡑࡕࠫठ")
TqywXFbirSu = BBOY8rvinVbFh(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬड")
ss12Lxn9zHmkefgR6GDE = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬढ")
URBvawyLXfQiS2NI34HDk = aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨ࡞ࡱࠫण")
lpaqU2W5YZ4v6MuVyecsDIEO = HHthiRYs8T6IO3qUyX(u"ࠩ࡟ࡶࠬत")
fWM6PeOrvciG0RQpIKzltojDqaYs = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭थ")
XXnoFIhTbGMUlJNjBtdxqP8 = HfuZG0aphlYnVLOyAk93rj(u"࠴୎")
GOfwy72YRjtQC9vx31I4S6AuFEo = BBOY8rvinVbFh(u"࠴࠳࠻୏")
PAeR5o1FpS2InVUhr = WlU7AtONpyj3(u"࠶࠻୐")
VQG7LjY23A5kyRcWbvOiUn = tzEjvOaZWU1A(u"࠹࠰୑")
naOy2dX06M = tzEjvOaZWU1A(u"࠱࠱୒")
DpFaXUr0xoH4MfLuAbc = wnVICNyfE3XZ0htUaDFAOgLo(u"࠲࠴࠳୓")
Mp3z8xKw9uPg2GNcbtnvVHljXiIZB = taD1d3bpqyfM4VNhK0P29GSZ(u"࠶࠸୔")
xXUqn2W1CElKt0 = XONpB38LESgyRmt
h02CUxE1dg3YWoSVmp9BPKOI7 = NZiEOAWrSX1u2gU05DR6TB8tm(u"࠹࠴୕")
bbQgZCcL8Ya3UdP4zKAryn = dQvxmFkyLOteNMWBJ2bDHV(u"࠺࠵ୖ")*h02CUxE1dg3YWoSVmp9BPKOI7
XitAeIKomQrflzU = Urj6egiVyHA75ZK(u"࠷࠺ୗ")*bbQgZCcL8Ya3UdP4zKAryn
gkWVLcijaRZnzwMNF4Y5dQqbTBJeAu = Urj6egiVyHA75ZK(u"࠹࠰୘")*XitAeIKomQrflzU
uQIXMypK534GsVWetdl6Px9fTjUn = nxUveizbLEAT2FBNy3
i8a54nkd09BCbvuZxQFMAqDR2tlK = x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠳࠱୙")*h02CUxE1dg3YWoSVmp9BPKOI7
qogplQ5vHLYt8Ci1fknObwMThe = s0sB2Xyp9uYU5N3fxzKoLW8*bbQgZCcL8Ya3UdP4zKAryn
SSZixT0lqg4BaUOtf79JjFIurn = wb1nC3e8AjRVU4ovsuPa(u"࠲࠸୚")*bbQgZCcL8Ya3UdP4zKAryn
mXiE2RJGvS1DK4ZQuzl0sBFV = Q5yM0D6SaP9teHXufTGjUBc*XitAeIKomQrflzU
xCNH20myQLKTeJUVA1p7 = A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠵࠳୛")*XitAeIKomQrflzU
ggbKIPj8XAQhBVyeu1oDO47FNz = HfuZG0aphlYnVLOyAk93rj(u"࠴࠶ଡ଼")*gkWVLcijaRZnzwMNF4Y5dQqbTBJeAu
JUH64BgvjCIG5DRcZTSd782fVqo = bbQgZCcL8Ya3UdP4zKAryn
XCli7cMH0maTR = [A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ฺࠫ็ัࠨद"),wb1nC3e8AjRVU4ovsuPa(u"ࠬษ่ๅࠩध"),gNPRXprEAQJ(u"࠭หศ่ํࠫन"),J6G8X3gO1MiKh027D(u"ࠧฬษ็ฯࠬऩ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨำสฬ฾࠭प"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠩัหู๊ࠧफ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪืฬีำࠨब"),BBOY8rvinVbFh(u"ุࠫอศฺࠩभ"),gNPRXprEAQJ(u"ࠬัวๆ่ࠪम"),taD1d3bpqyfM4VNhK0P29GSZ(u"࠭สศี฼ࠫय"),tzEjvOaZWU1A(u"ฺࠧษืีࠬर")]
es94V0ZkbA8z2YR5NoHvEJyG6hmI = [
						 HfuZG0aphlYnVLOyAk93rj(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧऱ")
						,WlU7AtONpyj3(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭ल")
						,sdRqnego9PclrL4m2J(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫळ")
						,HHthiRYs8T6IO3qUyX(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬऴ")
						,J6G8X3gO1MiKh027D(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧव")
						,XasF0WO7rDUHnEt8hAl9kLN(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩश")
						,MBS1GrwQoUlsiIRfVDOHdA(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫष")
						,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬस")
						,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ह")
						,CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧऺ")
						,Urj6egiVyHA75ZK(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫऻ")
						,XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬़ࠬ")
						,J6G8X3gO1MiKh027D(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬऽ")
						,dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩा")
						,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪि")
						]
XGQAhBKYCS = es94V0ZkbA8z2YR5NoHvEJyG6hmI+[
				 taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫी")
				,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨु")
				,HfuZG0aphlYnVLOyAk93rj(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧू")
				,BBOY8rvinVbFh(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨृ")
				,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩॄ")
				,HfuZG0aphlYnVLOyAk93rj(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪॅ")
				,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪॆ")
				,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫे")
				,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬै")
				,BBOY8rvinVbFh(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨॉ")
				,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨॊ")
				,sdRqnego9PclrL4m2J(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩो")
				,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪौ")
				,tzEjvOaZWU1A(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ्࠭")
				,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪॎ")
				,Urj6egiVyHA75ZK(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬॏ")
				]
vvSEGw9KPtkc5NLBxjRnQZMg = [
						 dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ॐ")
						,dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ॑")
						,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺ॒ࠧ")
						]
GbqdKcX9QL3M = [HHthiRYs8T6IO3qUyX(u"ࠧࡃࡑࡎࡖࡆ࠭॓"),HfuZG0aphlYnVLOyAk93rj(u"ࠨࡒࡄࡒࡊ࡚ࠧ॔"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧॕ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ॖ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡎࡌࡉࡍࡏࠪॗ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫक़"),wb1nC3e8AjRVU4ovsuPa(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ख़")]
GbqdKcX9QL3M += [BBOY8rvinVbFh(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ग़"),HfuZG0aphlYnVLOyAk93rj(u"ࠨࡃࡎࡓࡆࡓࠧज़"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡄࡏ࡜ࡇࡍࠨड़"),sdRqnego9PclrL4m2J(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬढ़"),J6G8X3gO1MiKh027D(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭फ़")]
yUR49VWlq7OrLZB6GN = [ZeV4vau9CjN(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬय़"),WlU7AtONpyj3(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩॠ"),z8wTfYPiRQL(u"ࠧࡕࡘࡉ࡙ࡓ࠭ॡ"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩॢ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪॣ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ।"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭॥")]
yUR49VWlq7OrLZB6GN += [qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ०"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ१"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡔࡊࡒࡊࡍࡇࠧ२"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩ३"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪ४")]
RfJOSot3x5wU16BM2srbNmejAila = [taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡘࡎࡑࡁࡂࡖࠪ५"),FkqI4Gm8wMvUVbgo(u"ࠫࡆ࡟ࡌࡐࡎࠪ६"),gNPRXprEAQJ(u"ࠬࡌࡏࡔࡖࡄࠫ७"),FkqI4Gm8wMvUVbgo(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ८"),MBS1GrwQoUlsiIRfVDOHdA(u"࡚ࠧࡃࡔࡓ࡙࠭९"),u8iSx05wLfVyMNp1X3l(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ॰"),FkqI4Gm8wMvUVbgo(u"࡙ࠩࡅࡗࡈࡏࡏࠩॱ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪॲ")]
RfJOSot3x5wU16BM2srbNmejAila += [CMUXq6mPQV5rLsSBdWZJvA(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬॳ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧॴ"),wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧॵ"),wb1nC3e8AjRVU4ovsuPa(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩॶ"),ZeV4vau9CjN(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩॷ"),HHthiRYs8T6IO3qUyX(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫॸ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫॹ")]
RfJOSot3x5wU16BM2srbNmejAila += [FkqI4Gm8wMvUVbgo(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ॺ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧॻ"),CMUXq6mPQV5rLsSBdWZJvA(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩॼ"),HfuZG0aphlYnVLOyAk93rj(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨॽ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫॾ"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪॿ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬঀ")]
RfJOSot3x5wU16BM2srbNmejAila += [BBOY8rvinVbFh(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧঁ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨং"),FkqI4Gm8wMvUVbgo(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩঃ"),BBOY8rvinVbFh(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ঄"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪঅ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡄࡌ࡜ࡇࡋࠨআ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬই"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨঈ")]
RfJOSot3x5wU16BM2srbNmejAila += [wb1nC3e8AjRVU4ovsuPa(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧউ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪঊ"),wb1nC3e8AjRVU4ovsuPa(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬঋ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨঌ"),tzEjvOaZWU1A(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ঍"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭঎"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭এ"),sdRqnego9PclrL4m2J(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧঐ")]
l3M7OyGix208jcuTP = [FkqI4Gm8wMvUVbgo(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ঑"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ঒"),YoMw2J1Ljp(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬও"),Urj6egiVyHA75ZK(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬঔ")]
l3M7OyGix208jcuTP += [sdRqnego9PclrL4m2J(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨক"),ZeV4vau9CjN(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩখ"),tzEjvOaZWU1A(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭গ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ঘ"),ZeV4vau9CjN(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫঙ"),z8wTfYPiRQL(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨচ")]
iZWXTKRotAsDxqPd2p = [NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪছ")]+GbqdKcX9QL3M+[ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡑࡎ࡞ࡅࡅࠩজ")]+yUR49VWlq7OrLZB6GN+[aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࡕ࡛ࡂࡍࡋࡆࠫঝ")]+RfJOSot3x5wU16BM2srbNmejAila+[NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ঞ")]+l3M7OyGix208jcuTP
tcli6aJQCRpkgGUbmO75NEYS3V = [tzEjvOaZWU1A(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬট")]
vmXznORTZ2165Vl = [WlU7AtONpyj3(u"ࠧࡑࡔࡌ࡚ࡆ࡚ࡅࠨঠ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡏࡌ࡜ࡊࡊࠧড"),HHthiRYs8T6IO3qUyX(u"ࠩࡓ࡙ࡇࡒࡉࡄࠩঢ")]
JDYjluLKngtaozQv3BiG = [ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡑ࠸࡛ࠧণ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࡎࡖࡔࡗࠩত"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪথ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡉࡇࡋࡏࡑࠬদ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨধ")]
wWguRoGajeOv0  = [HHthiRYs8T6IO3qUyX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭ন"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ঩"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪপ"),YoMw2J1Ljp(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨফ"),gNPRXprEAQJ(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡌࡆ࡙ࡈࡕࡃࡊࡗࠬব")]
wWguRoGajeOv0 += [BBOY8rvinVbFh(u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬভ"),Urj6egiVyHA75ZK(u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧম")]
wWguRoGajeOv0 += [x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩয"),ZeV4vau9CjN(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭র"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭঱")]
wWguRoGajeOv0 += [dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧল"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ঳"),WlU7AtONpyj3(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ঴")]
wWguRoGajeOv0 += [kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ঵"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬশ"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ষ")]
tP3vOXqZnG6aJjkhDgpfe75lIL = list(filter(lambda C6OlKRZbXfukEA2: C6OlKRZbXfukEA2 not in wWguRoGajeOv0+tcli6aJQCRpkgGUbmO75NEYS3V+vmXznORTZ2165Vl+JDYjluLKngtaozQv3BiG,iZWXTKRotAsDxqPd2p))
Ege1mcK0zWQ = tP3vOXqZnG6aJjkhDgpfe75lIL+JDYjluLKngtaozQv3BiG
WTyswk70P6az = tP3vOXqZnG6aJjkhDgpfe75lIL+wWguRoGajeOv0
dpTy2xekflusq8gFLE3CU = WTyswk70P6az+tcli6aJQCRpkgGUbmO75NEYS3V
zDi7eytcamrCE = Ege1mcK0zWQ+tcli6aJQCRpkgGUbmO75NEYS3V
ssKUBCaX2fTbtIZm4L8HDun = [tzEjvOaZWU1A(u"ࠪࡅࡐࡕࡁࡎࠩস"),J6G8X3gO1MiKh027D(u"ࠫࡆࡑࡗࡂࡏࠪহ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠬࡏࡆࡊࡎࡐࠫ঺"),ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ঻"),WlU7AtONpyj3(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ়ࠩ"),wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪঽ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬা"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫি"),WlU7AtONpyj3(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩী"),HHthiRYs8T6IO3qUyX(u"ࠬࡓ࠳ࡖࠩু"),z8wTfYPiRQL(u"࠭ࡉࡑࡖ࡙ࠫূ"),A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠧࡃࡑࡎࡖࡆ࠭ৃ"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪৄ"),FkqI4Gm8wMvUVbgo(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ৅")]
NOT_TO_TEST_ALL_SERVERS = [tzEjvOaZWU1A(u"ࠪࡣࡆࡑࡏࡠࠩ৆"),u8iSx05wLfVyMNp1X3l(u"ࠫࡤࡇࡋࡘࡡࠪে"),WlU7AtONpyj3(u"ࠬࡥࡉࡇࡎࡢࠫৈ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭࡟ࡌࡔࡅࡣࠬ৉"),wb1nC3e8AjRVU4ovsuPa(u"ࠧࡠࡏࡕࡊࡤ࠭৊"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨࡡࡖࡌࡒࡥࠧো"),sdRqnego9PclrL4m2J(u"ࠩࡢࡗࡍ࡜࡟ࠨৌ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࡣ࡞࡛ࡔࡠ্ࠩ"),gNPRXprEAQJ(u"ࠫࡤࡊࡌࡎࡡࠪৎ"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࡥࡍࡖࠩ৏"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭࡟ࡊࡒࠪ৐"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡠࡄࡎࡖࡤ࠭৑"),ZeV4vau9CjN(u"ࠨࡡࡈࡐࡈࡥࠧ৒"),FkqI4Gm8wMvUVbgo(u"ࠩࡢࡅࡗ࡚࡟ࠨ৓")]
rbTo6gq2XRScGUuvkw = [oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡔࡊࡘࡍࠨ৔"),YoMw2J1Ljp(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣࡕࡋࡒࡎࠩ৕"),dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉࡥࡐࡆࡔࡐࠫ৖"),ZeV4vau9CjN(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡒࡈࡖࡒ࠭ৗ"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),ZeV4vau9CjN(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭৙"),CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡘࡊࡓࡐࠨ৚"),qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤ࡚ࡅࡎࡒࠪ৛")]
jP9LGqufXONnTFpz21mRU6CdwEy = [nxUveizbLEAT2FBNy3,sdRqnego9PclrL4m2J(u"࠵࠺࠶ଢ଼"),HHthiRYs8T6IO3qUyX(u"࠶࠼࠰୬"),G6GUCto502jZTLubYNnqMx8ywBah(u"࠲࠹࠳୯"),XasF0WO7rDUHnEt8hAl9kLN(u"࠵࠾࠶୤"),oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠲࠷࠲୧"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠶࠽࠶୫"),Urj6egiVyHA75ZK(u"࠸࠹࠰୥"),WlU7AtONpyj3(u"࠴࠶࠳୨"),aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠹࠷࠰୞"),FkqI4Gm8wMvUVbgo(u"࠵࠱࠲୮"),u8iSx05wLfVyMNp1X3l(u"࠸࠶࠵ୣ"),Urj6egiVyHA75ZK(u"࠸࠷࠵୪"),SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠻࠴࠱୦"),wb1nC3e8AjRVU4ovsuPa(u"࠽࠶࠱୭"),FkqI4Gm8wMvUVbgo(u"࠳࠳࠵࠵ୢ"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠺࠻࠼࠴ୡ"),XasF0WO7rDUHnEt8hAl9kLN(u"࠷࠰࠳࠲ୟ"),kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠱࠱࠺࠳ୠ"),tzEjvOaZWU1A(u"࠳࠴࠴࠵୩")]
ZfHpAKRnVgOhvzwM08Xqkyi6 = [WlU7AtONpyj3(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩড়"),ZeV4vau9CjN(u"ࠬ࠷࠵࠱ࡦ࠵࠶࡫࠷࠭ࡤ࠷࠻ࡥ࠲࠺࠰࠳࠳࠰ࡥࡦ࠾࠴࠮ࡧ࠼࠶࠸ࡩࡡࡧ࠺࠸࠼࠸࠺ࠧঢ়"),dQvxmFkyLOteNMWBJ2bDHV(u"࠭࠳࠺࠻࠴ࡩ࠾ࡩ࠵࠮࠹ࡨࡩ࠸࠳࠴ࡦࡧ࠵࠱࠽࠺ࡣ࠱࠯ࡩࡨ࠼࠿࠲ࡣࡣࡧࡨ࠸ࡪ࠵ࠨ৞"),YoMw2J1Ljp(u"ࠧ࠸࠸ࡥ࠸࡫ࡩ࠳࠵ࡨࡦࡨ࠶࠿ࡤ࠺ࡥ࠸࠹ࡦ࠷࠵ࡧ࠵࠹࠴࠹ࡩࡤ࠺࠳࠷ࡧࠬয়"),WlU7AtONpyj3(u"ࠨ࠳࡙ࡒࡸࡓࡴࡍ࠳ࡲࡆࡗ࡞࡫ࡔࡐࡆࡦࡈࡓࡊ࠲ࡍ࡛࡝ࡏࡰࡪ࠱ࡦ࡭࡞ࡼ࠭ৠ"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠫৡ"),tzEjvOaZWU1A(u"ࠪ࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࠨৢ"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸࠭ৣ"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠬ࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿ࠧ৤"),z8wTfYPiRQL(u"࠭࠴࠵ࡨ࠷࠴࠽ࡪ࠴ࡢ࠴ࡰࡷ࡭࠷ࡢ࠴ࡤࡧ࠸࠾ࡧ࠶࠵࠺࠴࠻࡫࠻ࡰ࠲࠲࠴࠴࠸࡬ࡪࡴࡰ࠷ࡥ࠹࠷࠷ࡧࡥ࠸࠷࠵࠺࠲ࠨ৥"),XasF0WO7rDUHnEt8hAl9kLN(u"ࠧࡣࡤ࠸࠷࠽࠷࠸࠱࠯࠸ࡨ࠶ࡧ࠭࠵ࡥ࠵࠺࠲ࡧࡢ࠷ࡤ࠰࠵࠻ࡨࡢ࠳࠶ࡥ࠺࠾ࡩ࠸ࡢ࠯࠳࠴࠲࠷ࡶ࠶࠻ࡤ࡬࠷࠻ࡱ࠲ࡣ࠹࠴ࠬ০"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠨࡨ࠼ࡪ࠽࠷࠷࠸࠶࠰ࡥࡧ࠿࠸࠮࠶࠴ࡨ࠷࠳࠸࠸࠲ࡧ࠱࠻࠸࠵ࡣ࠺࠷࠺࠺࠸࠵࠴࠳࠰࠴࠵࠳࠱࡮࡫ࡦ࠸ࡩ࡫࡬࡭ࡩࡦࡦࡷ࠭১")]
mDiRgOkPEX5z6vsZCHxcLy2 = [YoMw2J1Ljp(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬ২"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯ࠧ৩"),x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩ৪"),Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬ৫"),HfuZG0aphlYnVLOyAk93rj(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨ৬"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱࠪ৭"),Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠨࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳࠧ৮"),MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡵࡩࡵࡲࡩࡵ࠰ࡧࡩࡻ࠭৯"),ZeV4vau9CjN(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭ৰ"),ZeV4vau9CjN(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠶࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧৱ")]
c2Ip3dJ75GjlkfxtDveToKX1 = {
	 gNPRXprEAQJ(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠱ࠩ৲")	: nxUveizbLEAT2FBNy3
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ࡁࡍࡃࡕࡅࡇ࠭৳")		: NZiEOAWrSX1u2gU05DR6TB8tm(u"࠳࠳୰")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠧࡊࡈࡌࡐࡒ࠭৴")		: Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠵࠴ୱ")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠨࡒࡄࡒࡊ࡚ࠧ৵")		: wb1nC3e8AjRVU4ovsuPa(u"࠷࠵୲")
	,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ৶")		: MBS1GrwQoUlsiIRfVDOHdA(u"࠹࠶୳")
	,gNPRXprEAQJ(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ৷")		: HfuZG0aphlYnVLOyAk93rj(u"࠻࠰୴")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭৸")		: Urj6egiVyHA75ZK(u"࠶࠱୵")
	,HHthiRYs8T6IO3qUyX(u"ࠬࡇࡋࡐࡃࡐࠫ৹")		: u8iSx05wLfVyMNp1X3l(u"࠸࠲୶")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ৺")		: z8wTfYPiRQL(u"࠺࠳୷")
	,J6G8X3gO1MiKh027D(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ৻")		: dQvxmFkyLOteNMWBJ2bDHV(u"࠼࠴୸")
	,z8wTfYPiRQL(u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨৼ")		: G6GUCto502jZTLubYNnqMx8ywBah(u"࠵࠵࠶୹")
	,BBOY8rvinVbFh(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ৽")		: HfuZG0aphlYnVLOyAk93rj(u"࠶࠷࠰୺")
	,YoMw2J1Ljp(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ৾")		: wnVICNyfE3XZ0htUaDFAOgLo(u"࠷࠲࠱୻")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ৿")	: FkqI4Gm8wMvUVbgo(u"࠱࠴࠲୼")
	,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭਀")		: BBOY8rvinVbFh(u"࠲࠶࠳୽")
	,gNPRXprEAQJ(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠳ࠪਁ")	: SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠳࠸࠴୾")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠧࡓࡃࡑࡈࡔࡓࡓࡠ࠲ࠪਂ")	: HfuZG0aphlYnVLOyAk93rj(u"࠴࠺࠵୿")
	,WlU7AtONpyj3(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠶ࠬਃ")	: sdRqnego9PclrL4m2J(u"࠵࠼࠶஀")
	,tzEjvOaZWU1A(u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ਄")	: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠶࠾࠰஁")
	,J6G8X3gO1MiKh027D(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࡤ࠹ࠧਅ")	: J6G8X3gO1MiKh027D(u"࠷࠹࠱ஂ")
	,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ਆ")		: wb1nC3e8AjRVU4ovsuPa(u"࠲࠱࠲ஃ")
	,HHthiRYs8T6IO3qUyX(u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫਇ")	: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠳࠳࠳஄")
	,BBOY8rvinVbFh(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪਈ")	: BBOY8rvinVbFh(u"࠴࠵࠴அ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡊࡒࡗ࡚ࡤ࠶ࠧਉ")		: HfuZG0aphlYnVLOyAk93rj(u"࠵࠷࠵ஆ")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡃࡎ࡛ࡆࡓࠧਊ")		: J6G8X3gO1MiKh027D(u"࠶࠹࠶இ")
	,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ਋")		: tzEjvOaZWU1A(u"࠷࠻࠰ஈ")
	,tzEjvOaZWU1A(u"ࠪࡑࡊࡔࡕࡔࡡ࠳ࠫ਌")		: u8iSx05wLfVyMNp1X3l(u"࠸࠶࠱உ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠫࡋࡇࡖࡐࡔࡌࡘࡊ࡙ࠧ਍")	: wb1nC3e8AjRVU4ovsuPa(u"࠲࠸࠲ஊ")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠬࡏࡐࡕࡘࡢ࠵ࠬ਎")		: ssYkHaML9z37bJ0StuEBXIqgiV(u"࠳࠺࠳஋")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬਏ")	: A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠴࠼࠴஌")
	,u8iSx05wLfVyMNp1X3l(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨਐ")		: MBS1GrwQoUlsiIRfVDOHdA(u"࠶࠴࠵஍")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ਑")	: dQvxmFkyLOteNMWBJ2bDHV(u"࠷࠶࠶எ")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ਒")	: ssYkHaML9z37bJ0StuEBXIqgiV(u"࠸࠸࠰ஏ")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬਓ")		: u8iSx05wLfVyMNp1X3l(u"࠹࠳࠱ஐ")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠴ࠨਔ")	: A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠳࠵࠲஑")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧਕ")		: u8iSx05wLfVyMNp1X3l(u"࠴࠷࠳ஒ")
	,gNPRXprEAQJ(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ਖ")		: SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠵࠹࠴ஓ")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡃࡑࡎࡖࡆ࠭ਗ")		: wnVICNyfE3XZ0htUaDFAOgLo(u"࠶࠻࠵ஔ")
	,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨਘ")		: Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠷࠽࠶க")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬਙ")	: CMUXq6mPQV5rLsSBdWZJvA(u"࠸࠿࠰஖")
	,z8wTfYPiRQL(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࡠ࠲ࠪਚ"): taD1d3bpqyfM4VNhK0P29GSZ(u"࠺࠰࠱஗")
	,YoMw2J1Ljp(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࡡ࠴ࠫਛ"): Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠴࠲࠲஘")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬਜ")		: BBOY8rvinVbFh(u"࠵࠴࠳ங")
	,Urj6egiVyHA75ZK(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ਝ")		: gNPRXprEAQJ(u"࠶࠶࠴ச")
	,ZeV4vau9CjN(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨਞ")		: Urj6egiVyHA75ZK(u"࠷࠸࠵஛")
	,HfuZG0aphlYnVLOyAk93rj(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩਟ")		: CMUXq6mPQV5rLsSBdWZJvA(u"࠸࠺࠶ஜ")
	,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩࡗ࡚ࡋ࡛ࡎࠨਠ")		: HfuZG0aphlYnVLOyAk93rj(u"࠹࠼࠰஝")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ਡ")	: tzEjvOaZWU1A(u"࠺࠷࠱ஞ")
	,u8iSx05wLfVyMNp1X3l(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ਢ")		: taD1d3bpqyfM4VNhK0P29GSZ(u"࠴࠹࠲ட")
	,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧਣ")		: wb1nC3e8AjRVU4ovsuPa(u"࠵࠻࠳஠")
	,XasF0WO7rDUHnEt8hAl9kLN(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠷ࠪਤ")	: MBS1GrwQoUlsiIRfVDOHdA(u"࠷࠳࠴஡")
	,u8iSx05wLfVyMNp1X3l(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࡡ࠳ࠫਥ")	: FkqI4Gm8wMvUVbgo(u"࠸࠵࠵஢")
	,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࡢ࠵ࠬਦ")	: CMUXq6mPQV5rLsSBdWZJvA(u"࠹࠷࠶ண")
	,tzEjvOaZWU1A(u"ࠩࡐࡉࡓ࡛ࡓࡠ࠳ࠪਧ")		: Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠺࠹࠰த")
	,FkqI4Gm8wMvUVbgo(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩਨ")	: SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠻࠴࠱஥")
	,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭਩")		: Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠵࠶࠲஦")
	,tzEjvOaZWU1A(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ਪ")		: G6GUCto502jZTLubYNnqMx8ywBah(u"࠶࠸࠳஧")
	,WlU7AtONpyj3(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨਫ")		: A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"࠷࠺࠴ந")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫਬ")	: SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠸࠼࠵ன")
	,HHthiRYs8T6IO3qUyX(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪਭ")		: FkqI4Gm8wMvUVbgo(u"࠹࠾࠶ப")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠩࡉࡓࡘ࡚ࡁࠨਮ")		: J6G8X3gO1MiKh027D(u"࠻࠶࠰஫")
	,HHthiRYs8T6IO3qUyX(u"ࠪࡅࡍ࡝ࡁࡌࠩਯ")		: BBOY8rvinVbFh(u"࠼࠱࠱஬")
	,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬਰ")		: sdRqnego9PclrL4m2J(u"࠶࠳࠲஭")
	,tzEjvOaZWU1A(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ਱")	: qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠷࠵࠳ம")
	,gNPRXprEAQJ(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ਲ")		: kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠸࠷࠴ய")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡃࡔࡖࡘࡊࡐࠧਲ਼")		: kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠹࠹࠵ர")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ਴")		: SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠺࠻࠶ற")
	,HHthiRYs8T6IO3qUyX(u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫਵ")		: Urj6egiVyHA75ZK(u"࠻࠽࠰ல")
	,HfuZG0aphlYnVLOyAk93rj(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫਸ਼")		: J6G8X3gO1MiKh027D(u"࠼࠸࠱ள")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ਷")		: YoMw2J1Ljp(u"࠶࠺࠲ழ")
	,WlU7AtONpyj3(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬਸ")		: z8wTfYPiRQL(u"࠸࠲࠳வ")
	,YoMw2J1Ljp(u"࠭ࡍ࠴ࡗࡢ࠴ࠬਹ")		: taD1d3bpqyfM4VNhK0P29GSZ(u"࠹࠴࠴ஶ")
	,u8iSx05wLfVyMNp1X3l(u"ࠧࡎ࠵ࡘࡣ࠶࠭਺")		: qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠺࠶࠵ஷ")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭਻")	: sdRqnego9PclrL4m2J(u"࠻࠸࠶ஸ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࡆࡐࡊࡇࡎࡆࡔࡢ࠴਼ࠬ")	: kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠼࠺࠰ஹ")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠪࡇࡑࡋࡁࡏࡇࡕࡣ࠶࠭਽")	: YoMw2J1Ljp(u"࠽࠵࠱஺")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠫࡗࡇࡎࡅࡑࡐࡗࡤ࠷ࠧਾ")	: sdRqnego9PclrL4m2J(u"࠷࠷࠲஻")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧਿ")		: YoMw2J1Ljp(u"࠸࠹࠳஼")
	,z8wTfYPiRQL(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨੀ")		: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠹࠻࠴஽")
	,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩੁ")		: NZiEOAWrSX1u2gU05DR6TB8tm(u"࠺࠽࠵ா")
	,J6G8X3gO1MiKh027D(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪੂ")		: taD1d3bpqyfM4VNhK0P29GSZ(u"࠼࠵࠶ி")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ੃")		: kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠽࠷࠰ீ")
	,BBOY8rvinVbFh(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ੄")		: BBOY8rvinVbFh(u"࠾࠲࠱ு")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭੅")		: BBOY8rvinVbFh(u"࠸࠴࠲ூ")
	,WlU7AtONpyj3(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧ੆")		: G6GUCto502jZTLubYNnqMx8ywBah(u"࠹࠶࠳௃")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩੇ")	: dQvxmFkyLOteNMWBJ2bDHV(u"࠺࠸࠴௄")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨੈ")		: sdRqnego9PclrL4m2J(u"࠻࠺࠵௅")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡘࡄࡖࡇࡕࡎࠨ੉")		: x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"࠼࠼࠶ெ")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩ੊")		: XasF0WO7rDUHnEt8hAl9kLN(u"࠽࠾࠰ே")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧੋ")	: Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠾࠹࠱ை")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩੌ")	: u8iSx05wLfVyMNp1X3l(u"࠹࠱࠲௉")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜੍ࠧ")		: gNPRXprEAQJ(u"࠺࠳࠳ொ")
	,ssYkHaML9z37bJ0StuEBXIqgiV(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ੎")		: SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠻࠵࠴ோ")
	,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪ੏")	: kkD16Il5AZ9BLfOcwGjToFX3bvC(u"࠼࠷࠵ௌ")
	,YoMw2J1Ljp(u"ࠨࡖࡌࡏࡆࡇࡔࠨ੐")		: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠽࠹࠶்")
	,BBOY8rvinVbFh(u"ࠩࡔࡊࡎࡒࡍࠨੑ")		: BBOY8rvinVbFh(u"࠾࠻࠰௎")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭੒")	: taD1d3bpqyfM4VNhK0P29GSZ(u"࠿࠶࠱௏")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭੓")		: HfuZG0aphlYnVLOyAk93rj(u"࠹࠸࠲ௐ")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ੔")		: u8iSx05wLfVyMNp1X3l(u"࠺࠺࠳௑")
	,z8wTfYPiRQL(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ੕")		: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠻࠼࠴௒")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨ੖")		: WlU7AtONpyj3(u"࠴࠴࠵࠶௓")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡉࡒࡓࡌࡒࡅࡔࡇࡄࡖࡈࡎࠧ੗")	: FkqI4Gm8wMvUVbgo(u"࠵࠵࠷࠰௔")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠻࠭੘")	: sdRqnego9PclrL4m2J(u"࠶࠶࠲࠱௕")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧਖ਼")	: Urj6egiVyHA75ZK(u"࠷࠰࠴࠲௖")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧਗ਼")	: tzEjvOaZWU1A(u"࠱࠱࠶࠳ௗ")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬࡇ࡙ࡍࡑࡏࠫਜ਼")		: WlU7AtONpyj3(u"࠲࠲࠸࠴௘")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩੜ")	: wb1nC3e8AjRVU4ovsuPa(u"࠳࠳࠺࠵௙")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨ੝")		: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠴࠴࠼࠶௚")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠨࡅࡏࡉࡆࡔࡅࡓࡡ࠵ࠫਫ਼")	: WlU7AtONpyj3(u"࠵࠵࠾࠰௛")
	,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ੟")	: oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠶࠶࠹࠱௜")
}
gVurG84mzZcMsKSEHkye7jBWnvfd = {
	MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡥ࡭ࡽࡡ࡬ࠩ੠")				:WlU7AtONpyj3(u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭੡")
	,HHthiRYs8T6IO3qUyX(u"ࠬࡧ࡫ࡰࡣࡰࠫ੢")				:oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ੣")
	,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠧࡢ࡭ࡲࡥࡲࡩࡡ࡮ࠩ੤")				:HfuZG0aphlYnVLOyAk93rj(u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩ੥")
	,HHthiRYs8T6IO3qUyX(u"ࠩࡤ࡯ࡼࡧ࡭ࠨ੦")				:taD1d3bpqyfM4VNhK0P29GSZ(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ੧")
	,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫࡦࡱࡷࡢ࡯ࡷࡹࡧ࡫ࠧ੨")			:sdRqnego9PclrL4m2J(u"๋่ࠬใ฻ࠣห่๎วๆࠢอ๎ํฮࠧ੩")
	,u8iSx05wLfVyMNp1X3l(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭੪")				:z8wTfYPiRQL(u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ੫")
	,Urj6egiVyHA75ZK(u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ੬")				:J6G8X3gO1MiKh027D(u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ੭")
	,wb1nC3e8AjRVU4ovsuPa(u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭੮")			:gNPRXprEAQJ(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ੯")
	,tzEjvOaZWU1A(u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧੰ")				:qvCARpoujaDHbnOgYF8274NkWzeG39(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪੱ")
	,HfuZG0aphlYnVLOyAk93rj(u"ࠧࡢ࡮ࡰࡷࡹࡨࡡࠨੲ")				:oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨ็๋ๆ฾ࠦวๅ็ุ฻อฯࠧੳ")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠩࡤࡲ࡮ࡳࡥࡻ࡫ࡧࠫੴ")				:dQvxmFkyLOteNMWBJ2bDHV(u"้ࠪํู่ࠡษ้้๏ࠦาะࠩੵ")
	,HfuZG0aphlYnVLOyAk93rj(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩ੶")			:Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"๋่ࠬใ฻ࠣวึอศ๋ๅࠣฮํ์าࠨ੷")
	,gNPRXprEAQJ(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ੸")				:taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧ੹")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪ੺")				:taD1d3bpqyfM4VNhK0P29GSZ(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪ੻")
	,WlU7AtONpyj3(u"ࠪࡥࡾࡲ࡯࡭ࠩ੼")				:CMUXq6mPQV5rLsSBdWZJvA(u"๊ࠫ๎โฺࠢฦ๎้๎ไࠨ੽")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠬࡨ࡯࡬ࡴࡤࠫ੾")				:SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ๅ้ไ฼ࠤอ้ัศࠩ੿")
	,Urj6egiVyHA75ZK(u"ࠧࡣࡴࡶࡸࡪࡰࠧ઀")				:J6G8X3gO1MiKh027D(u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭ઁ")
	,BBOY8rvinVbFh(u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪં")				:WlU7AtONpyj3(u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪઃ")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡨ࡯࡭ࡢ࠶ࡳࠫ઄")				:Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ีࠥฮ๊ࠨઅ")
	,wb1nC3e8AjRVU4ovsuPa(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭આ")				:kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩઇ")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪઈ")				:XasF0WO7rDUHnEt8hAl9kLN(u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪઉ")
	,BBOY8rvinVbFh(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬઊ")				:CMUXq6mPQV5rLsSBdWZJvA(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬઋ")
	,z8wTfYPiRQL(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࡷࡰࡴ࡮ࠫઌ")			:SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮฺࠠ็็ࠫઍ")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩ઎")				:HHthiRYs8T6IO3qUyX(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩએ")
	,BBOY8rvinVbFh(u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫઐ")				:dQvxmFkyLOteNMWBJ2bDHV(u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫઑ")
	,tzEjvOaZWU1A(u"ࠫࡨ࡯࡭ࡢࡨࡵࡩࡪ࠭઒")				:qvCARpoujaDHbnOgYF8274NkWzeG39(u"๋่ࠬใ฻ࠣื๏๋วࠡใิ๎ࠬઓ")
	,HHthiRYs8T6IO3qUyX(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩઔ")			:dQvxmFkyLOteNMWBJ2bDHV(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨક")
	,MBS1GrwQoUlsiIRfVDOHdA(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩખ")				:G6GUCto502jZTLubYNnqMx8ywBah(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩગ")
	,BBOY8rvinVbFh(u"ࠪࡧ࡮ࡳࡡࡸࡤࡤࡷࠬઘ")				:Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"๊ࠫ๎โฺࠢึ๎๊อ้ࠠสึࠫઙ")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪચ")			:wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠨછ")
	,HHthiRYs8T6IO3qUyX(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧજ")	:XasF0WO7rDUHnEt8hAl9kLN(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥีุ่้ࠣะฮะ็ํ๊ࠬઝ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡩࡣࡶ࡬ࡹࡧࡧࡴࠩઞ")	:NZiEOAWrSX1u2gU05DR6TB8tm(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥํวีฬส็ࠬટ")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯࡯࡭ࡻ࡫ࡳࠨઠ")	:tzEjvOaZWU1A(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆสสุึ࠭ડ")
	,BBOY8rvinVbFh(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧઢ"):taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨણ")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭ત")	:J6G8X3gO1MiKh027D(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫથ")
	,CMUXq6mPQV5rLsSBdWZJvA(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡸ࡬ࡨࡪࡵࡳࠨદ")	:oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨધ")
	,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧન")				:BBOY8rvinVbFh(u"࠭ๅห๊ๅๅࠬ઩")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠧࡥࡴࡤࡱࡦࡩࡡࡧࡧࠪપ")			:YoMw2J1Ljp(u"ࠨ็๋ๆ฾ࠦฯาษ่ห้ࠥวโ์๊ࠫફ")
	,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪબ")				:Urj6egiVyHA75ZK(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪભ")
	,Urj6egiVyHA75ZK(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬમ")				:G6GUCto502jZTLubYNnqMx8ywBah(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭ય")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨર")				:YoMw2J1Ljp(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪ઱")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪલ")				:CMUXq6mPQV5rLsSBdWZJvA(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬળ")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ઴")				:taD1d3bpqyfM4VNhK0P29GSZ(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧવ")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧશ")				:aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩષ")
	,u8iSx05wLfVyMNp1X3l(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫસ")			:SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭હ")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪ઺")				:HHthiRYs8T6IO3qUyX(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪ઻")
	,dQvxmFkyLOteNMWBJ2bDHV(u"ࠫࡪ࡭ࡹ࡯ࡱࡺ઼ࠫ")				:Urj6egiVyHA75ZK(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬઽ")
	,wb1nC3e8AjRVU4ovsuPa(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨા")				:ZeV4vau9CjN(u"ࠧๆ๊ๅ฽๋่ࠥิ๊฼อࠥอไิ์้้ฬ࠭િ")
	,wb1nC3e8AjRVU4ovsuPa(u"ࠨࡧ࡯࡭࡫ࡼࡩࡥࡧࡲࠫી")			:NZiEOAWrSX1u2gU05DR6TB8tm(u"่ࠩ์็฿ࠠฤๆํๅࠥ็๊ะ์๋ࠫુ")
	,gNPRXprEAQJ(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫૂ")				:x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"๊ࠫ๎โฺࠢไฬึ้ษࠨૃ")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬૄ")				:gNPRXprEAQJ(u"࠭แีๆࠪૅ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪ૆")			:ZeV4vau9CjN(u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭ે")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡩࡥࡷ࡫ࡳ࡬ࡱࠪૈ")				:u8iSx05wLfVyMNp1X3l(u"้ࠪํู่ࠡใสีุ้่ࠨૉ")
	,wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭૊")				:HHthiRYs8T6IO3qUyX(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧો")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨૌ")				:gNPRXprEAQJ(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์્ࠪ")
	,z8wTfYPiRQL(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ૎")				:tzEjvOaZWU1A(u"่ࠩะ้ีࠧ૏")
	,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠪࡪࡴࡹࡴࡢࠩૐ")				:SGw8cNUHojkJriW7zL45F1mdTeVbX(u"๊ࠫ๎โฺࠢไ์ุะวࠨ૑")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠬ࡬ࡵ࡯ࡱࡱࡸࡻ࠭૒")				:ZeV4vau9CjN(u"࠭ๅ้ไ฼ࠤๆ์่็ࠢอ๎ๆ๐ࠧ૓")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠧࡧࡷࡶ࡬ࡦࡸࡴࡷࠩ૔")				:A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥะ๊โ์ࠪ૕")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩࡩࡹࡸ࡮ࡡࡳࡸ࡬ࡨࡪࡵࠧ૖")			:Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"้ࠪํู่ࠡใุ๋ฬืࠠโ์า๎ํ࠭૗")
	,J6G8X3gO1MiKh027D(u"ࠫ࡬ࡵ࡯ࡥࠩ૘")					:HHthiRYs8T6IO3qUyX(u"ࠬา๊ะࠩ૙")
	,HHthiRYs8T6IO3qUyX(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ૚")				:XasF0WO7rDUHnEt8hAl9kLN(u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧ૛")
	,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠨࡪࡨࡰࡦࡲࠧ૜")				:BBOY8rvinVbFh(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ૝")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪ࡭࡫࡯࡬࡮ࠩ૞")				:u8iSx05wLfVyMNp1X3l(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ૟")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫૠ")			:FkqI4Gm8wMvUVbgo(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨૡ")
	,sdRqnego9PclrL4m2J(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧૢ")		:CMUXq6mPQV5rLsSBdWZJvA(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ૣ")
	,MBS1GrwQoUlsiIRfVDOHdA(u"ࠩ࡬ࡴࡹࡼࠧ૤")					:BBOY8rvinVbFh(u"ࠪࡍࡕ࡚ࡖࠨ૥")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧ૦")			:tzEjvOaZWU1A(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩ૧")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫ૨")			:gNPRXprEAQJ(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫ૩")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭૪")			:sdRqnego9PclrL4m2J(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨ૫")
	,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭૬")			:WlU7AtONpyj3(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ૭")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧ૮")				:wnVICNyfE3XZ0htUaDFAOgLo(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨ૯")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ૰")				:sdRqnego9PclrL4m2J(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬ૱")
	,u8iSx05wLfVyMNp1X3l(u"ࠩ࡮࡭ࡷࡳࡡ࡭࡭ࠪ૲")				:tzEjvOaZWU1A(u"้ࠪํู่ࠡๅิ้ฬ๊ใࠨ૳")
	,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠫࡱࡧࡲࡰࡼࡤࠫ૴")				:kkD16Il5AZ9BLfOcwGjToFX3bvC(u"๋่ࠬใ฻่ࠣฬื่ำษࠪ૵")
	,Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧ૶")				:FkqI4Gm8wMvUVbgo(u"ࠧๆๆไࠫ૷")
	,J6G8X3gO1MiKh027D(u"ࠨ࡮࡬ࡺࡪ࠭૸")					:NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩๅ๊ฬฯࠧૹ")
	,FkqI4Gm8wMvUVbgo(u"ࠪࡰ࡮ࡼࡥࡵࡸࠪૺ")				:G6GUCto502jZTLubYNnqMx8ywBah(u"๊๊ࠫแࠨૻ")
	,Urj6egiVyHA75ZK(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭ૼ")				:taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬ૽")
	,wb1nC3e8AjRVU4ovsuPa(u"ࠧ࡮࠵ࡸࠫ૾")					:z8wTfYPiRQL(u"ࠨࡏ࠶࡙ࠬ૿")
	,z8wTfYPiRQL(u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫ଀")				:z8wTfYPiRQL(u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭ଁ")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨଂ")			:MBS1GrwQoUlsiIRfVDOHdA(u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨଃ")
	,Urj6egiVyHA75ZK(u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪ଄")			:u8iSx05wLfVyMNp1X3l(u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬଅ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"ࠨ࡯ࡤࡷࡦࡼࡩࡥࡧࡲࠫଆ")			:gNPRXprEAQJ(u"่ࠩ์็฿ࠠๆษึหࠥ็๊ะ์๋ࠫଇ")
	,tzEjvOaZWU1A(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫଈ")				:FkqI4Gm8wMvUVbgo(u"๊ࠫ็โ้ัࠪଉ")
	,kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬଊ")				:taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨଋ")
	,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧଌ")				:ZeV4vau9CjN(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨ଍")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩࡲࡰࡩ࠭଎")					:G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪๆิ๐ๅࠨଏ")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠫࡵࡧ࡮ࡦࡶࠪଐ")				:u8iSx05wLfVyMNp1X3l(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩ଑")
	,MBS1GrwQoUlsiIRfVDOHdA(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ଒")			:Urj6egiVyHA75ZK(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪଓ")
	,FkqI4Gm8wMvUVbgo(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧଔ")			:SGw8cNUHojkJriW7zL45F1mdTeVbX(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧକ")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠪࡵ࡫࡯࡬࡮ࠩଖ")				:qvCARpoujaDHbnOgYF8274NkWzeG39(u"๊ࠫ๎โฺࠢๆ๎ํࠦแ๋ๆ่ࠫଗ")
	,J6G8X3gO1MiKh027D(u"ࠬࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦࠩଘ")			:tzEjvOaZWU1A(u"࠭ๅ้ไ฼ࠤุ๐ั๋ีࠣฮฬ๐ๅࠨଙ")
	,qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠧࡴࡪࡤࡦࡦࡱࡡࡵࡻࠪଚ")			:ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨ็๋ๆ฾ࠦิษๅอ๎ࠬଛ")
	,ZeV4vau9CjN(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫଜ")				:tzEjvOaZWU1A(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬଝ")
	,G6GUCto502jZTLubYNnqMx8ywBah(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠸ࠧଞ")			:WlU7AtONpyj3(u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠠ࠳ࠩଟ")
	,taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡳࡩࡣ࡫࡭ࡩࡴࡥࡸࡵࠪଠ")			:MBS1GrwQoUlsiIRfVDOHdA(u"ࠧๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨଡ")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫଢ")			:u8iSx05wLfVyMNp1X3l(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫଣ")
	,MBS1GrwQoUlsiIRfVDOHdA(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭ତ")		:A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬଥ")
	,Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨଦ")		:MBS1GrwQoUlsiIRfVDOHdA(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨଧ")
	,x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫନ")	:ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨ଩")
	,gNPRXprEAQJ(u"ࠩࡶ࡬ࡴ࡬ࡨࡢࠩପ")				:NZiEOAWrSX1u2gU05DR6TB8tm(u"้ࠪํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬଫ")
	,MBS1GrwQoUlsiIRfVDOHdA(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭ବ")				:z8wTfYPiRQL(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬଭ")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"࠭ࡳࡩࡱࡲࡪࡳ࡫ࡴࠨମ")				:x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้ࠢฮࠬଯ")
	,SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪର")				:Urj6egiVyHA75ZK(u"่ࠩ์็฿ࠠี๊ไࠤอื่ࠨ଱")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠪࡸ࡮ࡱࡡࡢࡶࠪଲ")				:dQvxmFkyLOteNMWBJ2bDHV(u"๊ࠫ๎โฺࠢอ็ฬะࠧଳ")
	,NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠬࡺࡶࡧࡷࡱࠫ଴")				:Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭ଵ")
	,oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࡷࡣࡵࡦࡴࡴࠧଶ")				:ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠨ็๋ๆ฾ࠦแศำห์๋࠭ଷ")
	,A9LwIR4bemxpVDfjKEUi0GcT2Zt(u"ࠩࡹ࡭ࡩ࡫࡯ࠨସ")				:FkqI4Gm8wMvUVbgo(u"ࠪๅ๏ี๊้ࠩହ")
	,tzEjvOaZWU1A(u"ࠫࡻ࡯ࡤࡦࡱࡱࡷࡦ࡫࡭ࠨ଺")			:tzEjvOaZWU1A(u"๋่ࠬใ฻ࠣๅ๏ี๊้้ࠢืฬฬๅࠨ଻")
	,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠷଼ࠧ")				:oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬࠦ࠱ࠨଽ")
	,HHthiRYs8T6IO3qUyX(u"ࠨࡹࡨࡧ࡮ࡳࡡ࠳ࠩା")				:oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠡ࠴ࠪି")
	,ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪࡽࡦࡷ࡯ࡵࠩୀ")				:qvCARpoujaDHbnOgYF8274NkWzeG39(u"๊ࠫ๎โฺࠢํห็๎สࠨୁ")
	,sdRqnego9PclrL4m2J(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ୂ")				:wb1nC3e8AjRVU4ovsuPa(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫୃ")
	,z8wTfYPiRQL(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪୄ")		:kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ୅")
	,XasF0WO7rDUHnEt8hAl9kLN(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭୆")	:CMUXq6mPQV5rLsSBdWZJvA(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧେ")
	,tzEjvOaZWU1A(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬୈ")		:aLfSo9Q6FTKis4qklHpuj7cdOvgCUD(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬ୉")
	,FkqI4Gm8wMvUVbgo(u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ୊")			:oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧๆ๊สๆ฾ࠦๅ็ࠢํ์ฯ๐่ษࠩୋ")
}
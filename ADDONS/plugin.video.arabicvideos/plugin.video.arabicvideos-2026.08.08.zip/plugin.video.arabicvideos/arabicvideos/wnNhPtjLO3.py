# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
KXWUabAT1GONjQ6ml2Z3cow7kPz5 = 'FAVORITES'
def cVwdXQBSYLaqJ9FeU(eYN1APt8aZflKmByj0ioGzn,jjFPaglXRuTsnvhfd74YS5mVZ):
	if   eYN1APt8aZflKmByj0ioGzn==270: X0mhvdbn9g61HlGZs = G3Y9xIhbPUgKRuLkE0NaJrWnF5T(jjFPaglXRuTsnvhfd74YS5mVZ)
	else: X0mhvdbn9g61HlGZs = False
	return X0mhvdbn9g61HlGZs
def vBAYPCM8ciEGwrmFypH6WKTnxUl(LLjJSPRyT85B9Cq3,jjFPaglXRuTsnvhfd74YS5mVZ,OVmon1HMT3ShEtdGp0UafRxvXLQkeA):
	if not LLjJSPRyT85B9Cq3: return
	if   OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='UP1'	: f1hsw0Fu3plAJNUie(jjFPaglXRuTsnvhfd74YS5mVZ,True,igM4DhpPzoX95Ysnar6Auj)
	elif OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='DOWN1'	: f1hsw0Fu3plAJNUie(jjFPaglXRuTsnvhfd74YS5mVZ,False,igM4DhpPzoX95Ysnar6Auj)
	elif OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='UP4'	: f1hsw0Fu3plAJNUie(jjFPaglXRuTsnvhfd74YS5mVZ,True,HHQhABuNKV7cd)
	elif OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='DOWN4'	: f1hsw0Fu3plAJNUie(jjFPaglXRuTsnvhfd74YS5mVZ,False,HHQhABuNKV7cd)
	elif OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='ADD1'	: lDVwabcoypLntMzjST17RYK(jjFPaglXRuTsnvhfd74YS5mVZ)
	elif OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='REMOVE1': Ufv5RsIkmtZ7YVo8M(jjFPaglXRuTsnvhfd74YS5mVZ)
	elif OVmon1HMT3ShEtdGp0UafRxvXLQkeA=='DELETELIST': oOzIhwUYeBlDG(jjFPaglXRuTsnvhfd74YS5mVZ)
	return
def G3Y9xIhbPUgKRuLkE0NaJrWnF5T(jjFPaglXRuTsnvhfd74YS5mVZ):
	DCzVs5fTpJab2ZcAd = ubDoWUSC0rtABRZ7Kfe3sdwk4()
	if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()):
		try:
			oozkupHUcSNmqYtV1 = DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]
			if nxUveizbLEAT2FBNy3 and jjFPaglXRuTsnvhfd74YS5mVZ in ['5','11','12','13']:
				for uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 in oozkupHUcSNmqYtV1:
					if uDJvEcha9x4OtnN5e18yKqA3zgmW=='video':
						EE6ysIeB8jKNgCfOkv('video',HHFAVK8SwRUqBLuTfdeJ9nbD+'تشغيل من الأعلى إلى الأسفل'+wVvqN8LZCJW5ryAb1EHRPFkQ0,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3)
						EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
						break
			for uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 in oozkupHUcSNmqYtV1:
				EE6ysIeB8jKNgCfOkv(uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0)
		except:
			DCzVs5fTpJab2ZcAd = cKMH9xQ3YwjEsZeVBbXa(Ls8nETvYeDouVpxIStMZy6mBw)
			oozkupHUcSNmqYtV1 = DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]
			for uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 in oozkupHUcSNmqYtV1:
				EE6ysIeB8jKNgCfOkv(uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0)
	return
def lDVwabcoypLntMzjST17RYK(jjFPaglXRuTsnvhfd74YS5mVZ):
	uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 = EEwuUCX43k8ldHzSQOWqiTJrax(gsLJM8uq1Xv6EC)
	if jjFPaglXRuTsnvhfd74YS5mVZ in ['5','11','12','13'] and uDJvEcha9x4OtnN5e18yKqA3zgmW!='video':
		o1OgjEBsS0aKNl6T7LyAXWfmQ('','',fWM6PeOrvciG0RQpIKzltojDqaYs,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	S3rDIapLiAgkbZ0Olyx = uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,ZtgNzIpQ4wOo3SjYyH0
	DCzVs5fTpJab2ZcAd = ubDoWUSC0rtABRZ7Kfe3sdwk4()
	MMhCBtRNgqfHrGYK0zE = {}
	for H46z2PUCsnTR0AxFjiQ1DJ in list(DCzVs5fTpJab2ZcAd.keys()):
		if H46z2PUCsnTR0AxFjiQ1DJ!=jjFPaglXRuTsnvhfd74YS5mVZ: MMhCBtRNgqfHrGYK0zE[H46z2PUCsnTR0AxFjiQ1DJ] = DCzVs5fTpJab2ZcAd[H46z2PUCsnTR0AxFjiQ1DJ]
		else:
			if ppweOR6rMg and ppweOR6rMg!='..':
				OXxAMps6TIji5WSN71G = DCzVs5fTpJab2ZcAd[H46z2PUCsnTR0AxFjiQ1DJ]
				if S3rDIapLiAgkbZ0Olyx in OXxAMps6TIji5WSN71G:
					bi9Ugtjme3Oyr7 = OXxAMps6TIji5WSN71G.index(S3rDIapLiAgkbZ0Olyx)
					del OXxAMps6TIji5WSN71G[bi9Ugtjme3Oyr7]
				FRyZIUnQi5DuCdbVkqPMfhcj6 = OXxAMps6TIji5WSN71G+[S3rDIapLiAgkbZ0Olyx]
				MMhCBtRNgqfHrGYK0zE[H46z2PUCsnTR0AxFjiQ1DJ] = FRyZIUnQi5DuCdbVkqPMfhcj6
			else: MMhCBtRNgqfHrGYK0zE[H46z2PUCsnTR0AxFjiQ1DJ] = DCzVs5fTpJab2ZcAd[H46z2PUCsnTR0AxFjiQ1DJ]
	if jjFPaglXRuTsnvhfd74YS5mVZ not in list(MMhCBtRNgqfHrGYK0zE.keys()): MMhCBtRNgqfHrGYK0zE[jjFPaglXRuTsnvhfd74YS5mVZ] = [S3rDIapLiAgkbZ0Olyx]
	fXRS4WHdOmC6nBhTeJP = str(MMhCBtRNgqfHrGYK0zE)
	if eOQJrvLAZC: fXRS4WHdOmC6nBhTeJP = fXRS4WHdOmC6nBhTeJP.encode(NVbhZ0DTpOkCA)
	open(Ls8nETvYeDouVpxIStMZy6mBw,'wb').write(fXRS4WHdOmC6nBhTeJP)
	return
def Ufv5RsIkmtZ7YVo8M(jjFPaglXRuTsnvhfd74YS5mVZ):
	uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 = EEwuUCX43k8ldHzSQOWqiTJrax(gsLJM8uq1Xv6EC)
	S3rDIapLiAgkbZ0Olyx = uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,ZtgNzIpQ4wOo3SjYyH0
	DCzVs5fTpJab2ZcAd = ubDoWUSC0rtABRZ7Kfe3sdwk4()
	if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()) and S3rDIapLiAgkbZ0Olyx in DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]:
		DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ].remove(S3rDIapLiAgkbZ0Olyx)
		if len(DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ])==nxUveizbLEAT2FBNy3: del DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]
		fXRS4WHdOmC6nBhTeJP = str(DCzVs5fTpJab2ZcAd)
		if eOQJrvLAZC: fXRS4WHdOmC6nBhTeJP = fXRS4WHdOmC6nBhTeJP.encode(NVbhZ0DTpOkCA)
		open(Ls8nETvYeDouVpxIStMZy6mBw,'wb').write(fXRS4WHdOmC6nBhTeJP)
	return
def f1hsw0Fu3plAJNUie(jjFPaglXRuTsnvhfd74YS5mVZ,nOmexqWlEkyQHzwcU,SSUxY6nhpw4VK):
	uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 = EEwuUCX43k8ldHzSQOWqiTJrax(gsLJM8uq1Xv6EC)
	S3rDIapLiAgkbZ0Olyx = uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,kh850jKbzmBwY,ZtgNzIpQ4wOo3SjYyH0
	DCzVs5fTpJab2ZcAd = ubDoWUSC0rtABRZ7Kfe3sdwk4()
	if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()):
		OXxAMps6TIji5WSN71G = DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]
		if S3rDIapLiAgkbZ0Olyx not in OXxAMps6TIji5WSN71G: return
		p7URwvtrP0BNLMkZy = len(OXxAMps6TIji5WSN71G)
		for GO7MHm4uakCRsJ8AlcdLr in range(nxUveizbLEAT2FBNy3,SSUxY6nhpw4VK):
			zdQjr2JgFxmHZfPbkCvURyt = OXxAMps6TIji5WSN71G.index(S3rDIapLiAgkbZ0Olyx)
			if nOmexqWlEkyQHzwcU: DHFuS7JEjfd5AnGw = zdQjr2JgFxmHZfPbkCvURyt-igM4DhpPzoX95Ysnar6Auj
			else: DHFuS7JEjfd5AnGw = zdQjr2JgFxmHZfPbkCvURyt+igM4DhpPzoX95Ysnar6Auj
			if DHFuS7JEjfd5AnGw>=p7URwvtrP0BNLMkZy: DHFuS7JEjfd5AnGw = DHFuS7JEjfd5AnGw-p7URwvtrP0BNLMkZy
			if DHFuS7JEjfd5AnGw<nxUveizbLEAT2FBNy3: DHFuS7JEjfd5AnGw = DHFuS7JEjfd5AnGw+p7URwvtrP0BNLMkZy
			OXxAMps6TIji5WSN71G.insert(DHFuS7JEjfd5AnGw, OXxAMps6TIji5WSN71G.pop(zdQjr2JgFxmHZfPbkCvURyt))
		DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ] = OXxAMps6TIji5WSN71G
		fXRS4WHdOmC6nBhTeJP = str(DCzVs5fTpJab2ZcAd)
		if eOQJrvLAZC: fXRS4WHdOmC6nBhTeJP = fXRS4WHdOmC6nBhTeJP.encode(NVbhZ0DTpOkCA)
		open(Ls8nETvYeDouVpxIStMZy6mBw,'wb').write(fXRS4WHdOmC6nBhTeJP)
	return
def KSwDYiTd0t1RJ3Urf76q(jjFPaglXRuTsnvhfd74YS5mVZ):
	if jjFPaglXRuTsnvhfd74YS5mVZ in ['1','2','3','4']: OoxPFJuiswH0ecVYm4,mQ30UeLDuzEGKkqRsi8lf4NA9n = 'مفضلة',jjFPaglXRuTsnvhfd74YS5mVZ
	elif jjFPaglXRuTsnvhfd74YS5mVZ in ['5']: OoxPFJuiswH0ecVYm4,mQ30UeLDuzEGKkqRsi8lf4NA9n = 'تشغيل','1'
	elif jjFPaglXRuTsnvhfd74YS5mVZ in ['11']: OoxPFJuiswH0ecVYm4,mQ30UeLDuzEGKkqRsi8lf4NA9n = 'تشغيل','2'
	else: OoxPFJuiswH0ecVYm4,mQ30UeLDuzEGKkqRsi8lf4NA9n = kh850jKbzmBwY,kh850jKbzmBwY
	y1UNkKJWlGD5MH7ohex68TRPtQ = OoxPFJuiswH0ecVYm4+EE3iZM15sTQ2t9cOhuCWwDjGSUzryF+mQ30UeLDuzEGKkqRsi8lf4NA9n
	return y1UNkKJWlGD5MH7ohex68TRPtQ
def oOzIhwUYeBlDG(jjFPaglXRuTsnvhfd74YS5mVZ):
	y1UNkKJWlGD5MH7ohex68TRPtQ = KSwDYiTd0t1RJ3Urf76q(jjFPaglXRuTsnvhfd74YS5mVZ)
	oPseX03Q2D4gjy7TMHbz = aa48i0SKpcGbWFBYLtCre('center',kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'هل تريد فعلا مسح جميع محتويات قائمة '+y1UNkKJWlGD5MH7ohex68TRPtQ+' ؟!')
	if oPseX03Q2D4gjy7TMHbz!=1: return
	DCzVs5fTpJab2ZcAd = ubDoWUSC0rtABRZ7Kfe3sdwk4()
	if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()):
		del DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]
		fXRS4WHdOmC6nBhTeJP = str(DCzVs5fTpJab2ZcAd)
		if eOQJrvLAZC: fXRS4WHdOmC6nBhTeJP = fXRS4WHdOmC6nBhTeJP.encode(NVbhZ0DTpOkCA)
		open(Ls8nETvYeDouVpxIStMZy6mBw,'wb').write(fXRS4WHdOmC6nBhTeJP)
		o1OgjEBsS0aKNl6T7LyAXWfmQ(kh850jKbzmBwY,kh850jKbzmBwY,fWM6PeOrvciG0RQpIKzltojDqaYs,'تم مسح جميع محتويات قائمة '+y1UNkKJWlGD5MH7ohex68TRPtQ)
	return
def ubDoWUSC0rtABRZ7Kfe3sdwk4():
	DCzVs5fTpJab2ZcAd = {}
	if YdDkIjFhgzuboBKca70ERt.path.exists(Ls8nETvYeDouVpxIStMZy6mBw):
		hhRDtAjc8MUkPbz = open(Ls8nETvYeDouVpxIStMZy6mBw,'rb').read()
		if eOQJrvLAZC: hhRDtAjc8MUkPbz = hhRDtAjc8MUkPbz.decode(NVbhZ0DTpOkCA)
		DCzVs5fTpJab2ZcAd = tmYCsS329HanzjLFbJP('dict',hhRDtAjc8MUkPbz)
	return DCzVs5fTpJab2ZcAd
def JwPmx250ZfYL7rpcd3WTqy(DCzVs5fTpJab2ZcAd,S3rDIapLiAgkbZ0Olyx,Qg8zyi9VbZG):
	uDJvEcha9x4OtnN5e18yKqA3zgmW,ppweOR6rMg,QmRL0swTcY9dXyIgrp82Aa1ekD,eYN1APt8aZflKmByj0ioGzn,NZj0IMlhLqu8xPJFsmAdVe,AIZOsmw6lin0WxLe4zjp,fRJYhnSKHsZ7MqFwmiVz,LLjJSPRyT85B9Cq3,ZtgNzIpQ4wOo3SjYyH0 = S3rDIapLiAgkbZ0Olyx
	if not eYN1APt8aZflKmByj0ioGzn: uDJvEcha9x4OtnN5e18yKqA3zgmW,eYN1APt8aZflKmByj0ioGzn = 'folder','260'
	RRIdrH4mWe0xvuOzBjn3cfLACT1l,jjFPaglXRuTsnvhfd74YS5mVZ = [],kh850jKbzmBwY
	if 'context=' in gsLJM8uq1Xv6EC:
		JrsAb1XmgGk3BqWOVpI5l = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('context=(\d+)',gsLJM8uq1Xv6EC,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if JrsAb1XmgGk3BqWOVpI5l: jjFPaglXRuTsnvhfd74YS5mVZ = str(JrsAb1XmgGk3BqWOVpI5l[nxUveizbLEAT2FBNy3])
	if eYN1APt8aZflKmByj0ioGzn=='270':
		jjFPaglXRuTsnvhfd74YS5mVZ = LLjJSPRyT85B9Cq3
		if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()):
			y1UNkKJWlGD5MH7ohex68TRPtQ = KSwDYiTd0t1RJ3Urf76q(jjFPaglXRuTsnvhfd74YS5mVZ)
			RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('مسح قائمة '+y1UNkKJWlGD5MH7ohex68TRPtQ,'RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_DELETELIST'+')'))
	else:
		if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()):
			count = len(DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ])
			if count>igM4DhpPzoX95Ysnar6Auj: RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('تحريك 1 للأعلى','RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_UP1)'))
			if count>HHQhABuNKV7cd: RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('تحريك 4 للأعلى','RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_UP4)'))
			if count>igM4DhpPzoX95Ysnar6Auj: RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('تحريك 1 للأسفل','RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_DOWN1)'))
			if count>HHQhABuNKV7cd: RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('تحريك 4 للأسفل','RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_DOWN4)'))
		for jjFPaglXRuTsnvhfd74YS5mVZ in ['1','2','3','4','5','11']:
			y1UNkKJWlGD5MH7ohex68TRPtQ = KSwDYiTd0t1RJ3Urf76q(jjFPaglXRuTsnvhfd74YS5mVZ)
			if jjFPaglXRuTsnvhfd74YS5mVZ in list(DCzVs5fTpJab2ZcAd.keys()) and S3rDIapLiAgkbZ0Olyx in DCzVs5fTpJab2ZcAd[jjFPaglXRuTsnvhfd74YS5mVZ]:
				RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('مسح من '+y1UNkKJWlGD5MH7ohex68TRPtQ,'RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_REMOVE1)'))
			else: RRIdrH4mWe0xvuOzBjn3cfLACT1l.append(('إضافة ل'+y1UNkKJWlGD5MH7ohex68TRPtQ,'RunPlugin('+Qg8zyi9VbZG+'&context='+jjFPaglXRuTsnvhfd74YS5mVZ+'_ADD1)'))
	JrlC7X9Bd5US4RfqYMtpvOegiDN = []
	for fV54CqY0yiadoIGKgZ,vN8MglYLc5qCf in RRIdrH4mWe0xvuOzBjn3cfLACT1l:
		fV54CqY0yiadoIGKgZ = RlMpu0hP8YmzZovkVXOs1G+fV54CqY0yiadoIGKgZ+wVvqN8LZCJW5ryAb1EHRPFkQ0
		JrlC7X9Bd5US4RfqYMtpvOegiDN.append((fV54CqY0yiadoIGKgZ,vN8MglYLc5qCf,))
	return JrlC7X9Bd5US4RfqYMtpvOegiDN
# -*- coding: utf-8 -*-
import sys as oo6Jpzna1cwVWskQLPT
JJbiP8dkzHMfCqnFO92xyV = oo6Jpzna1cwVWskQLPT.version_info [0] == 2
ioL3ISXaGKz8Hhx = 2048
M90jbQZvoSN7tEe8Iz26PH1 = 7
def iixFD6jwTfXQUpags28CMSHb1 (w9pXoySj87J41VvOkdhGDFAZsR):
	global UC8V2F1NOod7mpLAKM
	LDuJ6r5XWEwbaSm8oQzhqKAZ4 = ord (w9pXoySj87J41VvOkdhGDFAZsR [-1])
	nyBvT5lqKM9E = w9pXoySj87J41VvOkdhGDFAZsR [:-1]
	pixIV0791WOldvD = LDuJ6r5XWEwbaSm8oQzhqKAZ4 % len (nyBvT5lqKM9E)
	oNFYubyXD7CvAEI = nyBvT5lqKM9E [:pixIV0791WOldvD] + nyBvT5lqKM9E [pixIV0791WOldvD:]
	if JJbiP8dkzHMfCqnFO92xyV:
		jOKsgkJ2NzbGQtw0ePfx = unicode () .join ([unichr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	else:
		jOKsgkJ2NzbGQtw0ePfx = str () .join ([chr (ord (LoTmEXgPsyFWkzuewC1) - ioL3ISXaGKz8Hhx - (fbVyGXLDTRo35Mk6xSJdvn + LDuJ6r5XWEwbaSm8oQzhqKAZ4) % M90jbQZvoSN7tEe8Iz26PH1) for fbVyGXLDTRo35Mk6xSJdvn, LoTmEXgPsyFWkzuewC1 in enumerate (oNFYubyXD7CvAEI)])
	return eval (jOKsgkJ2NzbGQtw0ePfx)
XasF0WO7rDUHnEt8hAl9kLN,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,MBS1GrwQoUlsiIRfVDOHdA=iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1,iixFD6jwTfXQUpags28CMSHb1
A9LwIR4bemxpVDfjKEUi0GcT2Zt,SGw8cNUHojkJriW7zL45F1mdTeVbX,z8wTfYPiRQL=MBS1GrwQoUlsiIRfVDOHdA,x2L9VpHor78mtGUaMFjEeZK5Nkyvu,XasF0WO7rDUHnEt8hAl9kLN
ssYkHaML9z37bJ0StuEBXIqgiV,ZeV4vau9CjN,HfuZG0aphlYnVLOyAk93rj=z8wTfYPiRQL,SGw8cNUHojkJriW7zL45F1mdTeVbX,A9LwIR4bemxpVDfjKEUi0GcT2Zt
sdRqnego9PclrL4m2J,dQvxmFkyLOteNMWBJ2bDHV,Y7SorgUzMbHFGtWpAl2OnVmdCuD=HfuZG0aphlYnVLOyAk93rj,ZeV4vau9CjN,ssYkHaML9z37bJ0StuEBXIqgiV
HHthiRYs8T6IO3qUyX,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,wb1nC3e8AjRVU4ovsuPa=Y7SorgUzMbHFGtWpAl2OnVmdCuD,dQvxmFkyLOteNMWBJ2bDHV,sdRqnego9PclrL4m2J
kkD16Il5AZ9BLfOcwGjToFX3bvC,wnVICNyfE3XZ0htUaDFAOgLo,taD1d3bpqyfM4VNhK0P29GSZ=wb1nC3e8AjRVU4ovsuPa,aLfSo9Q6FTKis4qklHpuj7cdOvgCUD,HHthiRYs8T6IO3qUyX
J6G8X3gO1MiKh027D,YoMw2J1Ljp,u8iSx05wLfVyMNp1X3l=taD1d3bpqyfM4VNhK0P29GSZ,wnVICNyfE3XZ0htUaDFAOgLo,kkD16Il5AZ9BLfOcwGjToFX3bvC
BBOY8rvinVbFh,qvCARpoujaDHbnOgYF8274NkWzeG39,oo9GZln3sOt7YFXehI5Mm2AruLbN8p=u8iSx05wLfVyMNp1X3l,YoMw2J1Ljp,J6G8X3gO1MiKh027D
NZiEOAWrSX1u2gU05DR6TB8tm,WlU7AtONpyj3,Q0QcDKulBRrjGVsinUqMtk1yOh4TE=oo9GZln3sOt7YFXehI5Mm2AruLbN8p,qvCARpoujaDHbnOgYF8274NkWzeG39,BBOY8rvinVbFh
CMUXq6mPQV5rLsSBdWZJvA,G6GUCto502jZTLubYNnqMx8ywBah,tzEjvOaZWU1A=Q0QcDKulBRrjGVsinUqMtk1yOh4TE,WlU7AtONpyj3,NZiEOAWrSX1u2gU05DR6TB8tm
FkqI4Gm8wMvUVbgo,gNPRXprEAQJ,Urj6egiVyHA75ZK=tzEjvOaZWU1A,G6GUCto502jZTLubYNnqMx8ywBah,CMUXq6mPQV5rLsSBdWZJvA
from fRuUz1KSZi import *
vkNGie5mhCqoTFRzPKaML0x6 = HfuZG0aphlYnVLOyAk93rj(u"ࠪࡍࡓࡏࡔࠨᐣ")
x9XP1ec8DolGwABgkiIJyq,KYOoVyM4h78dmQDaTGzxZCFq,Nh5VL36XOvMt,pAL3Y0dZuIXc,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,lMBt2kFfevrWmz5GIsgS4NnAcH,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA = EEwuUCX43k8ldHzSQOWqiTJrax(gsLJM8uq1Xv6EC)
zb2EY0tPqjxn587AivOmdBSCpl = int(pAL3Y0dZuIXc)
WqbtdIEBif2sj4co8v = ppNwDFByU1dZn5ca.getInfoLabel(gNPRXprEAQJ(u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬᐤ"))
WqbtdIEBif2sj4co8v = WqbtdIEBif2sj4co8v.replace(OqMVuNDcB3,kh850jKbzmBwY).replace(lwOeWC9qnD863ifFhIa,kh850jKbzmBwY)
if zb2EY0tPqjxn587AivOmdBSCpl==ssYkHaML9z37bJ0StuEBXIqgiV(u"࠶࠻࠶ᑎ"): tWQskYGi1hCZcXglmEL67Do = wb1nC3e8AjRVU4ovsuPa(u"ࠬࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ᐥ")+YYTi6EgrdkyOUSbW+SGw8cNUHojkJriW7zL45F1mdTeVbX(u"࠭ࠠ࡞ࠢࠣࠤࡐࡵࡤࡪ࠼ࠣ࡟ࠥ࠭ᐦ")+Sv0hKklQYynRBda+dQvxmFkyLOteNMWBJ2bDHV(u"ࠧࠡ࡟ࠪᐧ")
else:
	spJ0dem2ly8z4cDNxS = KsuzxGjOHChbIXrwWm(gsLJM8uq1Xv6EC).replace(HHFAVK8SwRUqBLuTfdeJ9nbD,kh850jKbzmBwY).replace(RlMpu0hP8YmzZovkVXOs1G,kh850jKbzmBwY)
	spJ0dem2ly8z4cDNxS = spJ0dem2ly8z4cDNxS.replace(wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY).strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	spJ0dem2ly8z4cDNxS = spJ0dem2ly8z4cDNxS.replace(eexO1A6EKJIVruD87qmaiGhbw,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(ityRsSDe1ZNqhQ3PLjp74dfEV,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace(cyR2rJzGpVSXNuHsEQjk60fvFetYDx,EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
	if sdRqnego9PclrL4m2J(u"ࠨࠨࡸࡶࡱࡃࠧᐨ") in spJ0dem2ly8z4cDNxS:
		spJ0dem2ly8z4cDNxS,Zm7Q0uevONFxjtHUX65lpkAySbGM = spJ0dem2ly8z4cDNxS.rsplit(Y7SorgUzMbHFGtWpAl2OnVmdCuD(u"ࠩࠩࡹࡷࡲ࠽ࠨᐩ"),dQvxmFkyLOteNMWBJ2bDHV(u"࠶ᑏ"))
		spJ0dem2ly8z4cDNxS += u8iSx05wLfVyMNp1X3l(u"ࠪࠪࡺࡸ࡬࠾ࠩᐪ")+e6ul0cbvpi8NC4qaSMKh3B5TWFUwEj(Zm7Q0uevONFxjtHUX65lpkAySbGM,vkNGie5mhCqoTFRzPKaML0x6)
	tWQskYGi1hCZcXglmEL67Do = kkD16Il5AZ9BLfOcwGjToFX3bvC(u"ࠫࠥࠦࠠࡍࡣࡥࡩࡱࡀࠠ࡜ࠢࠪᐫ")+WqbtdIEBif2sj4co8v+BBOY8rvinVbFh(u"ࠬࠦ࡝ࠡࠢࠣࡑࡴࡪࡥ࠻ࠢ࡞ࠤࠬᐬ")+pAL3Y0dZuIXc+BBOY8rvinVbFh(u"࠭ࠠ࡞ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ᐭ")+spJ0dem2ly8z4cDNxS+oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠧࠡ࡟ࠪᐮ")
llxd9F07BIPtRZNMckOewDH6AYagn = FkqI4Gm8wMvUVbgo(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨᐯ")
IvJhkcEqiMVHr1sAeo(Ll16ekoIZjzN9E,llxd9F07BIPtRZNMckOewDH6AYagn+URBvawyLXfQiS2NI34HDk+KdYh8IpH9bmSxQNDZ1efLGtrkiv(vkNGie5mhCqoTFRzPKaML0x6)+tWQskYGi1hCZcXglmEL67Do)
if FkqI4Gm8wMvUVbgo(u"ࠩࡢࠫᐰ") in A7qWbt6Vp5IwEnjkD0RP: EEBXPbyUTcxlSa6qR,mACaDbEMcLFhdPtnsBigSeH3RZV0 = A7qWbt6Vp5IwEnjkD0RP.split(oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠪࡣࠬᐱ"),igM4DhpPzoX95Ysnar6Auj)
else: EEBXPbyUTcxlSa6qR,mACaDbEMcLFhdPtnsBigSeH3RZV0 = A7qWbt6Vp5IwEnjkD0RP,kh850jKbzmBwY
VURLhyzScTfv05 = kh850jKbzmBwY
if EEBXPbyUTcxlSa6qR in [x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠫ࠶࠭ᐲ"),WlU7AtONpyj3(u"ࠬ࠸ࠧᐳ"),ZeV4vau9CjN(u"࠭࠳ࠨᐴ"),taD1d3bpqyfM4VNhK0P29GSZ(u"ࠧ࠵ࠩᐵ"),HfuZG0aphlYnVLOyAk93rj(u"ࠨ࠷ࠪᐶ"),G6GUCto502jZTLubYNnqMx8ywBah(u"ࠩ࠴࠵ࠬᐷ"),ssYkHaML9z37bJ0StuEBXIqgiV(u"ࠪ࠵࠷࠭ᐸ"),HHthiRYs8T6IO3qUyX(u"ࠫ࠶࠹ࠧᐹ")] and (qvCARpoujaDHbnOgYF8274NkWzeG39(u"ࠬࡇࡄࡅࠩᐺ") in mACaDbEMcLFhdPtnsBigSeH3RZV0 or dQvxmFkyLOteNMWBJ2bDHV(u"࠭ࡒࡆࡏࡒ࡚ࡊ࠭ᐻ") in mACaDbEMcLFhdPtnsBigSeH3RZV0 or G6GUCto502jZTLubYNnqMx8ywBah(u"ࠧࡖࡒࠪᐼ") in mACaDbEMcLFhdPtnsBigSeH3RZV0 or wb1nC3e8AjRVU4ovsuPa(u"ࠨࡆࡒ࡛ࡓ࠭ᐽ") in mACaDbEMcLFhdPtnsBigSeH3RZV0):
	Y3Ny5eLHdp.ktRv3MH6Ju1qSrXAyaV7BGf = dbo4vrnTM56I
	Y3Ny5eLHdp.resolveonly = dbo4vrnTM56I
	LLRFxsa2dwEGNA5th8kTibQ = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	from wnNhPtjLO3 import vBAYPCM8ciEGwrmFypH6WKTnxUl
	vBAYPCM8ciEGwrmFypH6WKTnxUl(A7qWbt6Vp5IwEnjkD0RP,EEBXPbyUTcxlSa6qR,mACaDbEMcLFhdPtnsBigSeH3RZV0)
	l7tuXCf0oKV9FPOy6Hb.setSetting(ZeV4vau9CjN(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ᐾ"),gsLJM8uq1Xv6EC)
elif not EEBXPbyUTcxlSa6qR and not CbHFYhIEAlBaG9WnModu7xq1K and zb2EY0tPqjxn587AivOmdBSCpl in [gNPRXprEAQJ(u"࠸࠳࠶ᑐ"),z8wTfYPiRQL(u"࠷࠲࠷ᑑ")]:
	Y3Ny5eLHdp.ktRv3MH6Ju1qSrXAyaV7BGf = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	Y3Ny5eLHdp.resolveonly = dbo4vrnTM56I
	LLRFxsa2dwEGNA5th8kTibQ = dbo4vrnTM56I
	Sun57X6YaOzP8NTpcBvUH3k = str(SMT9JWapBjDXNCFLlixwo7b36g8uA[wb1nC3e8AjRVU4ovsuPa(u"ࠪࡪࡴࡲࡤࡦࡴࠪᐿ")])
	vkNGie5mhCqoTFRzPKaML0x6 = wnVICNyfE3XZ0htUaDFAOgLo(u"ࠫࡎࡖࡔࡗࠩᑀ") if zb2EY0tPqjxn587AivOmdBSCpl==HHthiRYs8T6IO3qUyX(u"࠳࠵࠸ᑒ") else oo9GZln3sOt7YFXehI5Mm2AruLbN8p(u"ࠬࡓ࠳ࡖࠩᑁ")
	m4ESihWpUD5Oj2cXRB = vkNGie5mhCqoTFRzPKaML0x6.lower()
	GYOXsa4p1l = l7tuXCf0oKV9FPOy6Hb.getSetting(taD1d3bpqyfM4VNhK0P29GSZ(u"࠭ࡡࡷ࠰ࠪᑂ")+m4ESihWpUD5Oj2cXRB+x2L9VpHor78mtGUaMFjEeZK5Nkyvu(u"ࠧ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬᑃ")+Sun57X6YaOzP8NTpcBvUH3k)
	guEWp2n0C6kOlZ = l7tuXCf0oKV9FPOy6Hb.getSetting(BBOY8rvinVbFh(u"ࠨࡣࡹ࠲ࠬᑄ")+m4ESihWpUD5Oj2cXRB+Q0QcDKulBRrjGVsinUqMtk1yOh4TE(u"ࠩ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬᑅ")+Sun57X6YaOzP8NTpcBvUH3k)
	if GYOXsa4p1l or guEWp2n0C6kOlZ:
		Nh5VL36XOvMt += SGw8cNUHojkJriW7zL45F1mdTeVbX(u"ࠪࢀࠬᑆ")
		if GYOXsa4p1l: Nh5VL36XOvMt += FkqI4Gm8wMvUVbgo(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᑇ")+GYOXsa4p1l
		if guEWp2n0C6kOlZ: Nh5VL36XOvMt += BBOY8rvinVbFh(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᑈ")+guEWp2n0C6kOlZ
		Nh5VL36XOvMt = Nh5VL36XOvMt.replace(YoMw2J1Ljp(u"࠭ࡼࠧࠩᑉ"),HfuZG0aphlYnVLOyAk93rj(u"ࠧࡽࠩᑊ"))
	gyoMwzDXJ6aF = l7tuXCf0oKV9FPOy6Hb.getSetting(gNPRXprEAQJ(u"ࠨࡣࡹ࠲ࠬᑋ")+m4ESihWpUD5Oj2cXRB+NZiEOAWrSX1u2gU05DR6TB8tm(u"ࠩ࠱ࡷࡪࡸࡶࡦࡴࡢࠫᑌ")+Sun57X6YaOzP8NTpcBvUH3k)
	if gyoMwzDXJ6aF:
		ZcM6xuUz0EfvNHanTgS5i = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(dQvxmFkyLOteNMWBJ2bDHV(u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭ᑍ"),Nh5VL36XOvMt,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		Nh5VL36XOvMt = Nh5VL36XOvMt.replace(ZcM6xuUz0EfvNHanTgS5i[nxUveizbLEAT2FBNy3],gyoMwzDXJ6aF)
	NRlCaq1ndM(Nh5VL36XOvMt,vkNGie5mhCqoTFRzPKaML0x6,x9XP1ec8DolGwABgkiIJyq)
else:
	Y3Ny5eLHdp.ktRv3MH6Ju1qSrXAyaV7BGf = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	Y3Ny5eLHdp.resolveonly = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	LLRFxsa2dwEGNA5th8kTibQ = wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1
	import EX1SxIMYj7
	try: EX1SxIMYj7.sGMtbCw4ZKX76YmJ0OFNkhgSUiu(x9XP1ec8DolGwABgkiIJyq,KYOoVyM4h78dmQDaTGzxZCFq,Nh5VL36XOvMt,pAL3Y0dZuIXc,vvufbqFnUclCD5MxOz,QPZDaMKgtTUyNjB7EqvOLwph,lMBt2kFfevrWmz5GIsgS4NnAcH,A7qWbt6Vp5IwEnjkD0RP,SMT9JWapBjDXNCFLlixwo7b36g8uA,zb2EY0tPqjxn587AivOmdBSCpl,EEBXPbyUTcxlSa6qR,mACaDbEMcLFhdPtnsBigSeH3RZV0,WqbtdIEBif2sj4co8v)
	except Exception as E4h2XtMqQgBco: VURLhyzScTfv05 = CU1t3OXbgRciK8V.format_exc()
QrZXnLMCy1WfTISU(Y3Ny5eLHdp.ktRv3MH6Ju1qSrXAyaV7BGf,VURLhyzScTfv05,LLRFxsa2dwEGNA5th8kTibQ)
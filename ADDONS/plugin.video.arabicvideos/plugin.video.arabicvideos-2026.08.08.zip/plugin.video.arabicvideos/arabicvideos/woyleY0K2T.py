# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'ARABICTOONS'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_ART_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
def Z6V4AKYFUSWMmqBNXJ72p(mode, url, text):
    if mode == 730: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
    elif mode == 731: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url, text)
    elif mode == 732: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
    elif mode == 733: PP3FsDicLyWuTR7GV5Ia = do7Es2fUtFlM8ScLx(url)
    elif mode == 734: PP3FsDicLyWuTR7GV5Ia = RNug20bnJXYVf(url)
    elif mode == 735: PP3FsDicLyWuTR7GV5Ia = IIhux69CsNq(url)
    elif mode == 739: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
    else: PP3FsDicLyWuTR7GV5Ia = False
    return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
    EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'بحث في الموقع', kh850jKbzmBwY, 739, kh850jKbzmBwY, kh850jKbzmBwY, '_REMEMBERRESULTS_')
    EE6ysIeB8jKNgCfOkv('link', HHFAVK8SwRUqBLuTfdeJ9nbD + ' ===== ===== ===== ' + wVvqN8LZCJW5ryAb1EHRPFkQ0, kh850jKbzmBwY, 9999)
    EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + 'افلام', WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/movies.php', 731)
    EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + 'مسلسلات', WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/cartoon.php', 734)
    EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + 'الحلقات الجديدة', WLjaXVNk2dnAJzPpy6OlMv4qoi9, 731, '', '', 'latest_episodes')
    EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + 'مسلسلات جديدة', WLjaXVNk2dnAJzPpy6OlMv4qoi9, 731, '', '', 'latest_series')
    EE6ysIeB8jKNgCfOkv('folder', vkNGie5mhCqoTFRzPKaML0x6 + '_SCRIPT_' + GalrcVUMy8bzORWX5E0exhYivBwgk + 'أفلام جديدة', WLjaXVNk2dnAJzPpy6OlMv4qoi9, 731, '', '', 'latest_movies')
    return
def RNug20bnJXYVf(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ARABICTOONS-SERIES_SUBMENU-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"series-fullpage"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?>(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn
            title = 'الكل' if 'الكل' in title else 'حرف ' + title
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 731)
    return
def IIhux69CsNq(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ARABICTOONS-SERIES_FEATURED-2nd')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="slider"(.*?)</ul>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for title, Ga8xfYU6ht7cHjzn, NWqAr40jTLlMBemn3o79y in items:
            Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn
            NWqAr40jTLlMBemn3o79y = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + NWqAr40jTLlMBemn3o79y
            title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 733, NWqAr40jTLlMBemn3o79y)
    return
def bsZhnoqjD3U(url, jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ARABICTOONS-TITLES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    items = []
    if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'search':
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"section-header">(.*?)pagination', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if liroJ6qCK9k:
            ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
            items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)".*?title">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    elif 'latest' in jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"section-header">(.*?)"swiper-pagination"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        if jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'latest_movies': ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[2]
        elif jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'latest_series': ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[1]
        else: ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    else:
        liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"series-grid-swiper"(.*?)pagination', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        Sp6qOyDB0nt5Qo4KwbPfcWYe, LtaDBqr1oOpP0Yz3g4ci8, mHjNds76Q1BvDh8e3 = zip(*items)
        items = zip(Sp6qOyDB0nt5Qo4KwbPfcWYe, mHjNds76Q1BvDh8e3, LtaDBqr1oOpP0Yz3g4ci8)
    for Ga8xfYU6ht7cHjzn, NWqAr40jTLlMBemn3o79y, title in items:
        if 'books' in Ga8xfYU6ht7cHjzn: continue
        Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn
        if 'http' not in NWqAr40jTLlMBemn3o79y: NWqAr40jTLlMBemn3o79y = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + NWqAr40jTLlMBemn3o79y
        title = title.strip()
        if 'movies.php' in url or jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG == 'latest_movies': EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 732, NWqAr40jTLlMBemn3o79y)
        else: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 733, NWqAr40jTLlMBemn3o79y)
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('pagination(.*?)"series-grid-swiper"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?"page-number">(.*?)</a>', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title in items:
            if '>' in title: continue
            Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn if '.php' in Ga8xfYU6ht7cHjzn else url + Ga8xfYU6ht7cHjzn
            title = title.strip()
            title = E1XdT7HqUwC4m5pLKR6sua2MzFyNi(title)
            EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + 'صفحة ' + title, Ga8xfYU6ht7cHjzn, 731)
    return
def do7Es2fUtFlM8ScLx(url):
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ARABICTOONS-EPISODES-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"episodes-section"(.*?)<script>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for Ga8xfYU6ht7cHjzn, title, NWqAr40jTLlMBemn3o79y in items:
            Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn
            NWqAr40jTLlMBemn3o79y = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + NWqAr40jTLlMBemn3o79y
            title = title.strip()
            EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 732, NWqAr40jTLlMBemn3o79y)
    return
def yv8LezRQifhw1Kx(url):
    owMxje0p9Ya3CkhJDX = []
    giRfrJxZdQ16bw2oe = hBRWs4K6t1nderkNEQo7bIvCFuZfS(url, 'url')
    headers = {'User-Agent': e9SaDhW4XdLY2HfyPU7JI(), 'Referer': giRfrJxZdQ16bw2oe}
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, headers, kh850jKbzmBwY, kh850jKbzmBwY, 'ARABICTOONS-PLAY-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('videoSrc = "(.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if Ga8xfYU6ht7cHjzn:
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
        owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=__embed')
    liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"player-switcher-form"(.*?)</div>', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if liroJ6qCK9k:
        ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
        items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('value="(.*?)".*?"btn-text">(.*?)<', ZZDUdXR52CMs9K73Ex, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
        for choice, title in items:
            Ga8xfYU6ht7cHjzn = url + '?player_choice=' + choice + '&form_submitted=1'
            owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=' + title + '__watch')
    W4WhVPnxYeHDQ8sCF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(r'dynamique.*?}\);', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if not W4WhVPnxYeHDQ8sCF: W4WhVPnxYeHDQ8sCF = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(r'dynamique.*?}\)', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if W4WhVPnxYeHDQ8sCF:
        M2MTsJFIhKvLARfoNcmGiYZj = W4WhVPnxYeHDQ8sCF[0]
        ZpGW1jga28VNzHryf = dict(sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(r'(\w+):\s*"([^"]+)"', M2MTsJFIhKvLARfoNcmGiYZj))
        oJtiQaVlwmMLZYCks1cy = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.search(r'const\s+(\w+)', M2MTsJFIhKvLARfoNcmGiYZj)
        moT0kOcKq7JPVSt3L = oJtiQaVlwmMLZYCks1cy.group(1) if oJtiQaVlwmMLZYCks1cy else ""
        keys = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall(r'\$\{' + moT0kOcKq7JPVSt3L + r'\.(\w+)\}', M2MTsJFIhKvLARfoNcmGiYZj)
        if ZpGW1jga28VNzHryf and keys:
            Ga8xfYU6ht7cHjzn = "%s://%s/%s?%s" % (ZpGW1jga28VNzHryf[keys[0]], ZpGW1jga28VNzHryf[keys[1]], ZpGW1jga28VNzHryf[keys[2]], ZpGW1jga28VNzHryf[keys[3]])
            owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=__embed')
    Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('source src="(http.*?)"', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    if Ga8xfYU6ht7cHjzn:
        Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn[0]
        if 'Referer=' not in Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = Ga8xfYU6ht7cHjzn + '|Referer=https://www.arabic-toons.com'
        owMxje0p9Ya3CkhJDX.append(Ga8xfYU6ht7cHjzn + '?named=__embed')
    import OO3KYXPMuI
    OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo(owMxje0p9Ya3CkhJDX, vkNGie5mhCqoTFRzPKaML0x6, 'video', url)
    return
def dStQzEeyknDaOs7q(search):
    search, kFdoZmlxSf8shU, showDialogs = gCI13c7MdXA8(search)
    if search == kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
    if search == kh850jKbzmBwY: return
    search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF, '%20')
    url = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + '/search_results.php?q=' + search
    bsZhnoqjD3U(url, 'search')
    return
    OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn, 'GET', url, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, kh850jKbzmBwY, 'ARABICTOONS-SEARCH-1st')
    uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
    items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)">(.*?)<', uP1m46pAK5a3UgdqvBz9rnL, sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
    for Ga8xfYU6ht7cHjzn, title in items:
        Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9 + i2xvIPUGcdqsV5FnDfwBklhjCNXo7M + Ga8xfYU6ht7cHjzn
        title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
        if type == 'm': EE6ysIeB8jKNgCfOkv('video', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 732)
        else: EE6ysIeB8jKNgCfOkv('folder', GalrcVUMy8bzORWX5E0exhYivBwgk + title, Ga8xfYU6ht7cHjzn, 733)
    return
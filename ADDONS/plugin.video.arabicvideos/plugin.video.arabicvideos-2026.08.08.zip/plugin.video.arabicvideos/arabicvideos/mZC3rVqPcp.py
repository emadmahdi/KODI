# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'DAILYMOTION'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_DLM_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
d0hVTC6pXnNEwLqm4zbt3x = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][1]
dwmfrA3kVjbRU7KMaqCEBXYx9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][2]
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text,type,QPZDaMKgtTUyNjB7EqvOLwph):
	if	 mode==400: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==401: PP3FsDicLyWuTR7GV5Ia = jjCfhXnayEdpNGx3cQ5wiT0ML(url,text)
	elif mode==402: PP3FsDicLyWuTR7GV5Ia = asjXD865qozl3AZQUr(url,text)
	elif mode==403: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url,text)
	elif mode==404: PP3FsDicLyWuTR7GV5Ia = QbncrHqYBgxaJjPyW92(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==405: PP3FsDicLyWuTR7GV5Ia = k6Y4hDtQdXBAbMypl(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==406: PP3FsDicLyWuTR7GV5Ia = NYzyhaW3AnwcI0ZSr7GTEpFDlq(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==407: PP3FsDicLyWuTR7GV5Ia = K4sFlQSYIipvPuZj(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==408: PP3FsDicLyWuTR7GV5Ia = AAfqgVUnybuNw(url,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==409: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==411: PP3FsDicLyWuTR7GV5Ia = TwtE2bPQCVj9xIy651NSh0fOqnk7(url,text)
	elif mode==414: PP3FsDicLyWuTR7GV5Ia = qxAja2I1Yo(text)
	elif mode==415: PP3FsDicLyWuTR7GV5Ia = UduPe3LjxQYp(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==416: PP3FsDicLyWuTR7GV5Ia = hOPNjgA7RUF6aY0KrIefMXbmt8ZH3(text,QPZDaMKgtTUyNjB7EqvOLwph)
	elif mode==417: PP3FsDicLyWuTR7GV5Ia = js37qfFPaDpS42V18lYNQvbZ6Utg(url,QPZDaMKgtTUyNjB7EqvOLwph)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'الرئيسية',kh850jKbzmBwY,414)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,409,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن فيديوهات',kh850jKbzmBwY,409,kh850jKbzmBwY,'videos?sortBy=','_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن آخر الفيديوهات',kh850jKbzmBwY,409,kh850jKbzmBwY,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن الفيديوهات الأكثر مشاهدة',kh850jKbzmBwY,409,kh850jKbzmBwY,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن قوائم التشغيل',kh850jKbzmBwY,409,kh850jKbzmBwY,'playlists','_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن مستخدم',kh850jKbzmBwY,409,kh850jKbzmBwY,'channels','_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن بث حي',kh850jKbzmBwY,409,kh850jKbzmBwY,'lives','_REMEMBERRESULTS_')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث عن هاشتاك',kh850jKbzmBwY,409,kh850jKbzmBwY,'hashtags','_REMEMBERRESULTS_')
	return
def asjXD865qozl3AZQUr(url,JRMUdHxaZIztg7GFCO0oLrQ):
	if '/dm_' in url:
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,False,kh850jKbzmBwY,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = OIjmsWqwACpDMT7l3GaYbxtvh0L.headers
		if 'Location' in list(headers.keys()): url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+headers['Location']
	JRMUdHxaZIztg7GFCO0oLrQ = HHFAVK8SwRUqBLuTfdeJ9nbD+JRMUdHxaZIztg7GFCO0oLrQ+wVvqN8LZCJW5ryAb1EHRPFkQ0
	JRMUdHxaZIztg7GFCO0oLrQ = ttajX8KVPCyDIOk46Y7EdizuvM(JRMUdHxaZIztg7GFCO0oLrQ)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: بث حي',url,411,kh850jKbzmBwY,kh850jKbzmBwY,'channel_lives_now')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: آخر الفيديوهات',url+'/videos',408)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: المميزة',url,411,kh850jKbzmBwY,kh850jKbzmBwY,'channel_featured_videos')
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: قوائم التشغيل',url+'/playlists',407)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+':: قنوات ذات صلة',url,411,kh850jKbzmBwY,kh850jKbzmBwY,'channel_related_channel')
	return
def ttajX8KVPCyDIOk46Y7EdizuvM(title):
	title = title.rstrip('\\').strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF).replace('\\\\','\\')
	title = Z4CP1xs5w7fi(title)
	return title
def yv8LezRQifhw1Kx(url,n2OPfWBHl0J):
	import OO3KYXPMuI
	OO3KYXPMuI.kkszSdKjH4buhYC9n2ERo([url],vkNGie5mhCqoTFRzPKaML0x6,'video',url)
	return
def QbncrHqYBgxaJjPyW92(search,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = kh850jKbzmBwY
	search = search.split('/videos')[0]
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysearchwords',search)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	if sort==kh850jKbzmBwY: jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysortmethod',kh850jKbzmBwY)
	else: jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/'+search+'/videos'
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"videos"(.*?)"VideoConnection"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for id,title,cjE4dzBtUbDHXsi3y7Gm8qMxV0o,JRMUdHxaZIztg7GFCO0oLrQ,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,NWqAr40jTLlMBemn3o79y in items:
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+id
			title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
			n2OPfWBHl0J = cjE4dzBtUbDHXsi3y7Gm8qMxV0o+'::'+JRMUdHxaZIztg7GFCO0oLrQ
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,n2OPfWBHl0J)
		if '"hasNextPage":true' in uP1m46pAK5a3UgdqvBz9rnL:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,404,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,search)
	return
def k6Y4hDtQdXBAbMypl(search,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysearchwords',search)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/'+search+'/playlists'
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for id,name,iTh4rIoAKl,cjE4dzBtUbDHXsi3y7Gm8qMxV0o,JRMUdHxaZIztg7GFCO0oLrQ,NWqAr40jTLlMBemn3o79y,count in items:
		NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
		n2OPfWBHl0J = cjE4dzBtUbDHXsi3y7Gm8qMxV0o+'::'+JRMUdHxaZIztg7GFCO0oLrQ
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,401,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,n2OPfWBHl0J)
	if '"hasNextPage":true' in uP1m46pAK5a3UgdqvBz9rnL:
		QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
		EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,405,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,search)
	return
def NYzyhaW3AnwcI0ZSr7GTEpFDlq(search,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysearchwords',search)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/'+search+'/channels'
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"channels"(.*?)"ChannelConnection"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for id,name,NWqAr40jTLlMBemn3o79y in items:
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+id
			title = 'USER:  '+name
			title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,402,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,name)
		if '"hasNextPage":true' in uP1m46pAK5a3UgdqvBz9rnL:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,406,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,search)
	return
def qxAja2I1Yo(EImLjp0YDb):
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	cJlny4ANrbOzWPEsGUqT = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	if cJlny4ANrbOzWPEsGUqT:
		hmg5Vqpi7PxMnSFy1Dc0zsU9 = tmYCsS329HanzjLFbJP('dict',cJlny4ANrbOzWPEsGUqT)
		hhMRXGmEPq9rDnIsUbWgcd8u5 = hmg5Vqpi7PxMnSFy1Dc0zsU9['data']['home']['neon']['sections']['edges']
		if not EImLjp0YDb:
			nZyvpl6zULQNBrD83uFGtP = []
			for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
				Ys09LEucwJxTHrA1yhMg4 = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['title']
				if Ys09LEucwJxTHrA1yhMg4 not in nZyvpl6zULQNBrD83uFGtP: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+Ys09LEucwJxTHrA1yhMg4,kh850jKbzmBwY,414,kh850jKbzmBwY,kh850jKbzmBwY,Ys09LEucwJxTHrA1yhMg4)
				nZyvpl6zULQNBrD83uFGtP.append(Ys09LEucwJxTHrA1yhMg4)
		else:
			for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
				Ys09LEucwJxTHrA1yhMg4 = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['title']
				if Ys09LEucwJxTHrA1yhMg4==EImLjp0YDb:
					X2RHcBuZ4AQ3D71qjTd = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['components']['edges']
					for NDpjtJU6yXBIidq in X2RHcBuZ4AQ3D71qjTd:
						qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = str(NDpjtJU6yXBIidq['node']['duration'])
						title = Z4CP1xs5w7fi(NDpjtJU6yXBIidq['node']['title'])
						title = title.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
						haCdQzBML5mw4yqDes6 = NDpjtJU6yXBIidq['node']['xid']
						NWqAr40jTLlMBemn3o79y = NDpjtJU6yXBIidq['node']['thumbnailx480']
						NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
						Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+haCdQzBML5mw4yqDes6
						EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	return
def UduPe3LjxQYp(search,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysearchwords',search)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/'+search+'/lives'
	cJlny4ANrbOzWPEsGUqT = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search)
	if cJlny4ANrbOzWPEsGUqT:
		hmg5Vqpi7PxMnSFy1Dc0zsU9 = tmYCsS329HanzjLFbJP('dict',cJlny4ANrbOzWPEsGUqT)
		try: hhMRXGmEPq9rDnIsUbWgcd8u5 = hmg5Vqpi7PxMnSFy1Dc0zsU9['data']['search']['lives']['edges']
		except: hhMRXGmEPq9rDnIsUbWgcd8u5 = []
		for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
			name = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['title']
			name = Z4CP1xs5w7fi(name)
			haCdQzBML5mw4yqDes6 = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['xid']
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+haCdQzBML5mw4yqDes6
			EE6ysIeB8jKNgCfOkv('live',GalrcVUMy8bzORWX5E0exhYivBwgk+'LIVE: '+name,Ga8xfYU6ht7cHjzn,403)
		if '"hasNextPage":true' in cJlny4ANrbOzWPEsGUqT:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,415,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,search)
	return
def vzKT4R7JBdpFHf(search,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysearchwords',search)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/'+search+'/topics'
	cJlny4ANrbOzWPEsGUqT = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search)
	if cJlny4ANrbOzWPEsGUqT:
		hmg5Vqpi7PxMnSFy1Dc0zsU9 = tmYCsS329HanzjLFbJP('dict',cJlny4ANrbOzWPEsGUqT)
		try: hhMRXGmEPq9rDnIsUbWgcd8u5 = hmg5Vqpi7PxMnSFy1Dc0zsU9['data']['search']['topics']['edges']
		except: hhMRXGmEPq9rDnIsUbWgcd8u5 = []
		for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
			name = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['name']
			haCdQzBML5mw4yqDes6 = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['xid']
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/topic/'+haCdQzBML5mw4yqDes6
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'TOPIC: '+name,Ga8xfYU6ht7cHjzn,413)
		if '"hasNextPage":true' in cJlny4ANrbOzWPEsGUqT:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,412,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,search)
	return
def pZeycbi9zB5fv4Cqj2F86AI7Hgm(url,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	haCdQzBML5mw4yqDes6 = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mytopicid',haCdQzBML5mw4yqDes6)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	cJlny4ANrbOzWPEsGUqT = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	if cJlny4ANrbOzWPEsGUqT:
		hmg5Vqpi7PxMnSFy1Dc0zsU9 = tmYCsS329HanzjLFbJP('dict',cJlny4ANrbOzWPEsGUqT)
		hhMRXGmEPq9rDnIsUbWgcd8u5 = hmg5Vqpi7PxMnSFy1Dc0zsU9['data']['topic']['videos']['edges']
		for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
			qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = str(GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['duration'])
			title = Z4CP1xs5w7fi(GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['title'])
			title = title.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			haCdQzBML5mw4yqDes6 = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['xid']
			NWqAr40jTLlMBemn3o79y = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['thumbnailx480']
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+haCdQzBML5mw4yqDes6
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
		if '"hasNextPage":true' in cJlny4ANrbOzWPEsGUqT:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,413,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph)
	return
def jjCfhXnayEdpNGx3cQ5wiT0ML(url,n2OPfWBHl0J):
	id = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
	cjE4dzBtUbDHXsi3y7Gm8qMxV0o,JRMUdHxaZIztg7GFCO0oLrQ = n2OPfWBHl0J.split('::',1)
	Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+cjE4dzBtUbDHXsi3y7Gm8qMxV0o
	JRMUdHxaZIztg7GFCO0oLrQ = ttajX8KVPCyDIOk46Y7EdizuvM(JRMUdHxaZIztg7GFCO0oLrQ)
	title = HHFAVK8SwRUqBLuTfdeJ9nbD+'OWNER:  '+JRMUdHxaZIztg7GFCO0oLrQ+wVvqN8LZCJW5ryAb1EHRPFkQ0
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,402,kh850jKbzmBwY,kh850jKbzmBwY,JRMUdHxaZIztg7GFCO0oLrQ)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('myplaylistid',id)
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"collection_videos"(.*?)"SectionEdge"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for id,title,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,NWqAr40jTLlMBemn3o79y,cjE4dzBtUbDHXsi3y7Gm8qMxV0o,JRMUdHxaZIztg7GFCO0oLrQ in items:
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+id
			title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
			n2OPfWBHl0J = cjE4dzBtUbDHXsi3y7Gm8qMxV0o+'::'+JRMUdHxaZIztg7GFCO0oLrQ
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,n2OPfWBHl0J)
	return
def AAfqgVUnybuNw(url,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	zzRGXieSsdC89MgBJDWL1IwPUFoak = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mychannelid',zzRGXieSsdC89MgBJDWL1IwPUFoak)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysortmethod',sort)
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for id,title,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,cjE4dzBtUbDHXsi3y7Gm8qMxV0o,JRMUdHxaZIztg7GFCO0oLrQ,NWqAr40jTLlMBemn3o79y in items:
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+id
			title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
			n2OPfWBHl0J = cjE4dzBtUbDHXsi3y7Gm8qMxV0o+'::'+JRMUdHxaZIztg7GFCO0oLrQ
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,n2OPfWBHl0J)
		if '"hasNextPage":true' in uP1m46pAK5a3UgdqvBz9rnL:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,408,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph)
	return
def K4sFlQSYIipvPuZj(url,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	zzRGXieSsdC89MgBJDWL1IwPUFoak = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mychannelid',zzRGXieSsdC89MgBJDWL1IwPUFoak)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysortmethod',sort)
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for id,name,NWqAr40jTLlMBemn3o79y,count,iTh4rIoAKl,cjE4dzBtUbDHXsi3y7Gm8qMxV0o,JRMUdHxaZIztg7GFCO0oLrQ in items:
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
			n2OPfWBHl0J = cjE4dzBtUbDHXsi3y7Gm8qMxV0o+'::'+JRMUdHxaZIztg7GFCO0oLrQ
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,401,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,n2OPfWBHl0J)
		if '"hasNextPage":true' in uP1m46pAK5a3UgdqvBz9rnL:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,407,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph)
	return
def TwtE2bPQCVj9xIy651NSh0fOqnk7(url,WG8nXJ063TcAqby):
	zzRGXieSsdC89MgBJDWL1IwPUFoak = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[3]
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mychannelid',zzRGXieSsdC89MgBJDWL1IwPUFoak)
	uP1m46pAK5a3UgdqvBz9rnL = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	swdGlE5irATy12HavB = vDVykQSI8dwipbZuJmG31RO7l6h.loads(uP1m46pAK5a3UgdqvBz9rnL)
	try: items = swdGlE5irATy12HavB['data']['channel'][WG8nXJ063TcAqby]['edges']
	except: items = []
	if not items: EE6ysIeB8jKNgCfOkv('link',GalrcVUMy8bzORWX5E0exhYivBwgk+'لا توجد نتائج',kh850jKbzmBwY,9999)
	else:
		for JJNIsO8Vcbx0 in items:
			rs9ymXih7G = JJNIsO8Vcbx0['node']
			haCdQzBML5mw4yqDes6 = rs9ymXih7G['xid']
			keys = list(rs9ymXih7G.keys())
			TI7EQOxdBSbC = rs9ymXih7G['__typename'].lower()
			if TI7EQOxdBSbC=='channel':
				name = rs9ymXih7G['name']
				zi5c0B1blV4t = rs9ymXih7G['displayName']
				title = 'USER:  '+zi5c0B1blV4t
				NWqAr40jTLlMBemn3o79y = rs9ymXih7G['coverURLx375']
			else:
				name = rs9ymXih7G['channel']['name']
				zi5c0B1blV4t = rs9ymXih7G['channel']['displayName']
				title = rs9ymXih7G['title']
				NWqAr40jTLlMBemn3o79y = rs9ymXih7G['thumbnailx360']
				if TI7EQOxdBSbC=='live': title = 'LIVE:  '+title
			title = ttajX8KVPCyDIOk46Y7EdizuvM(title)
			n2OPfWBHl0J = name+'::'+zi5c0B1blV4t
			if BBJYzRKgHkOqx:
				title = title.encode(NVbhZ0DTpOkCA)
				n2OPfWBHl0J = n2OPfWBHl0J.encode(NVbhZ0DTpOkCA)
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			if TI7EQOxdBSbC=='channel':
				Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+haCdQzBML5mw4yqDes6
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,402,NWqAr40jTLlMBemn3o79y,kh850jKbzmBwY,n2OPfWBHl0J)
			else:
				if TI7EQOxdBSbC=='video': qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = str(rs9ymXih7G['duration'])
				else: qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = kh850jKbzmBwY
				Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+haCdQzBML5mw4yqDes6
				EE6ysIeB8jKNgCfOkv(TI7EQOxdBSbC,GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ,n2OPfWBHl0J)
	return
def hOPNjgA7RUF6aY0KrIefMXbmt8ZH3(search,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mysearchwords',search)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagelimit','40')
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search/'+search+'/hashtags'
	cJlny4ANrbOzWPEsGUqT = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search)
	if cJlny4ANrbOzWPEsGUqT:
		hmg5Vqpi7PxMnSFy1Dc0zsU9 = tmYCsS329HanzjLFbJP('dict',cJlny4ANrbOzWPEsGUqT)
		try: hhMRXGmEPq9rDnIsUbWgcd8u5 = hmg5Vqpi7PxMnSFy1Dc0zsU9['data']['search']['hashtags']['edges']
		except: hhMRXGmEPq9rDnIsUbWgcd8u5 = []
		for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
			name = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['name']
			name = Z4CP1xs5w7fi(name)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/hashtag/'+name[1:]
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'HSHTG: '+name,Ga8xfYU6ht7cHjzn,417)
		if '"hasNextPage":true' in cJlny4ANrbOzWPEsGUqT:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,416,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph,search)
	return
def js37qfFPaDpS42V18lYNQvbZ6Utg(url,QPZDaMKgtTUyNjB7EqvOLwph=kh850jKbzmBwY):
	if QPZDaMKgtTUyNjB7EqvOLwph==kh850jKbzmBwY: QPZDaMKgtTUyNjB7EqvOLwph = '1'
	name = url.split(i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)[-1]
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('myhashtagname',name)
	jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.replace('mypagenumber',QPZDaMKgtTUyNjB7EqvOLwph)
	cJlny4ANrbOzWPEsGUqT = wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG)
	if cJlny4ANrbOzWPEsGUqT:
		hmg5Vqpi7PxMnSFy1Dc0zsU9 = tmYCsS329HanzjLFbJP('dict',cJlny4ANrbOzWPEsGUqT)
		hhMRXGmEPq9rDnIsUbWgcd8u5 = hmg5Vqpi7PxMnSFy1Dc0zsU9['data']['contentFeed']['edges']
		for GV4sOqH2CFIdgyLXnWJKDNP8UkBth in hhMRXGmEPq9rDnIsUbWgcd8u5:
			qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ = str(GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['post']['duration'])
			title = Z4CP1xs5w7fi(GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['post']['title'])
			title = title.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			haCdQzBML5mw4yqDes6 = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['post']['xid']
			NWqAr40jTLlMBemn3o79y = GV4sOqH2CFIdgyLXnWJKDNP8UkBth['node']['post']['thumbnailx480']
			NWqAr40jTLlMBemn3o79y = NWqAr40jTLlMBemn3o79y.replace('\/',i2xvIPUGcdqsV5FnDfwBklhjCNXo7M)
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/video/'+haCdQzBML5mw4yqDes6
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,403,NWqAr40jTLlMBemn3o79y,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
		if '"hasNextPage":true' in cJlny4ANrbOzWPEsGUqT:
			QPZDaMKgtTUyNjB7EqvOLwph = str(int(QPZDaMKgtTUyNjB7EqvOLwph)+1)
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'صفحة '+QPZDaMKgtTUyNjB7EqvOLwph,url,416,kh850jKbzmBwY,QPZDaMKgtTUyNjB7EqvOLwph)
	return
def wfyEKRNxMkP18sZrob9pGvgW(jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,search=kh850jKbzmBwY):
	if eOQJrvLAZC: jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG = jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG.encode(NVbhZ0DTpOkCA)
	CaWFx6Xfyjn5h81t3RL0wP = g7K3hDfIOF1c80aS5G6q()
	headers = {"Authorization":CaWFx6Xfyjn5h81t3RL0wP,"Origin":WLjaXVNk2dnAJzPpy6OlMv4qoi9}
	if search:
		giRfrJxZdQ16bw2oe = dwmfrA3kVjbRU7KMaqCEBXYx9
		headers.update({'Content-Type':'application/json','Referer':WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M,'X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		giRfrJxZdQ16bw2oe = d0hVTC6pXnNEwLqm4zbt3x
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',d0hVTC6pXnNEwLqm4zbt3x,jN6kXFny0ITpfsAD8UhQ5S2zMLcwBG,headers,kh850jKbzmBwY,kh850jKbzmBwY,'DAILYMOTION-GET_PAGEDATA-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	return uP1m46pAK5a3UgdqvBz9rnL
def g7K3hDfIOF1c80aS5G6q():
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'DAILYMOTION-GET_AUTHINTICATION-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	OYzABSduZLqK8 = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('apiClientId.*?return"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	OYzABSduZLqK8 = OYzABSduZLqK8[nxUveizbLEAT2FBNy3]
	pG3jUyuEqeQN1xalgStFd = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('apiClientSecret.*?return"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	pG3jUyuEqeQN1xalgStFd = pG3jUyuEqeQN1xalgStFd[nxUveizbLEAT2FBNy3]
	NNxvFgJkaLqV61Eu9RYX8 = 'https://graphql.api.dailymotion.com/oauth/token'
	Phd5mE2XW4RzoGq1b0sD = 'client_credentials'
	data = {'client_id':OYzABSduZLqK8,'client_secret':pG3jUyuEqeQN1xalgStFd,'grant_type':Phd5mE2XW4RzoGq1b0sD}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'POST',NNxvFgJkaLqV61Eu9RYX8,data,headers,kh850jKbzmBwY,kh850jKbzmBwY,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	pEbo7ydFALqNSDRwPX = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	WWkRXSUI6hHvnYMdpiuPaAfLQ,aAN7vf6HTV8q5YR10F2wPnDbLuJQ = pEbo7ydFALqNSDRwPX[0]
	CaWFx6Xfyjn5h81t3RL0wP = aAN7vf6HTV8q5YR10F2wPnDbLuJQ+" "+WWkRXSUI6hHvnYMdpiuPaAfLQ
	return CaWFx6Xfyjn5h81t3RL0wP
def dStQzEeyknDaOs7q(search,eRVKBkL2rNi=kh850jKbzmBwY):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if not eRVKBkL2rNi and showDialogs:
		aJq7pkbeWN19RsKPEVu = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('موقع ديلي موشن - اختر البحث',aJq7pkbeWN19RsKPEVu)
		if TTn7mZzPRjq5GBESh8aKy==-1: return
		elif TTn7mZzPRjq5GBESh8aKy==0: eRVKBkL2rNi = 'videos?sortBy='
		elif TTn7mZzPRjq5GBESh8aKy==1: eRVKBkL2rNi = 'videos?sortBy=RECENT'
		elif TTn7mZzPRjq5GBESh8aKy==2: eRVKBkL2rNi = 'videos?sortBy=VIEW_COUNT'
		elif TTn7mZzPRjq5GBESh8aKy==3: eRVKBkL2rNi = 'playlists'
		elif TTn7mZzPRjq5GBESh8aKy==4: eRVKBkL2rNi = 'channels'
		elif TTn7mZzPRjq5GBESh8aKy==5: eRVKBkL2rNi = 'lives'
		elif TTn7mZzPRjq5GBESh8aKy==6: eRVKBkL2rNi = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in kFdoZmlxSf8shU: eRVKBkL2rNi = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in kFdoZmlxSf8shU: eRVKBkL2rNi = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in kFdoZmlxSf8shU: eRVKBkL2rNi = 'channels'
	elif '_DAILYMOTION-LIVES_' in kFdoZmlxSf8shU: eRVKBkL2rNi = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in kFdoZmlxSf8shU: eRVKBkL2rNi = 'hashtags'
	elif not eRVKBkL2rNi: eRVKBkL2rNi = 'videos?sortBy='
	if not search:
		search = GG5Fs0hvURxyBV8gz()
		if not search: return
	if 'videos' in eRVKBkL2rNi: QbncrHqYBgxaJjPyW92(search+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+eRVKBkL2rNi)
	elif 'playlists' in eRVKBkL2rNi: k6Y4hDtQdXBAbMypl(search)
	elif 'channels' in eRVKBkL2rNi: NYzyhaW3AnwcI0ZSr7GTEpFDlq(search)
	elif 'lives' in eRVKBkL2rNi: UduPe3LjxQYp(search)
	elif 'hashtags' in eRVKBkL2rNi: hOPNjgA7RUF6aY0KrIefMXbmt8ZH3(search)
	return
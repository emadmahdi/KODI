# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'GOOGLESEARCH'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_GOS_'
def Z6V4AKYFUSWMmqBNXJ72p(eYN1APt8aZflKmByj0ioGzn,QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz):
	if   eYN1APt8aZflKmByj0ioGzn==1010: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif eYN1APt8aZflKmByj0ioGzn==1011: PP3FsDicLyWuTR7GV5Ia = X72phO4Lb1e6P0F9NmwVEtxKanjY(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==1012: PP3FsDicLyWuTR7GV5Ia = nn3QvFXKCGTD6pN(QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==1013: PP3FsDicLyWuTR7GV5Ia = Jcl08PwWxmRBkTZrfiyLh7KjY1FXd()
	elif eYN1APt8aZflKmByj0ioGzn==1014: PP3FsDicLyWuTR7GV5Ia = qeULpFE27fYwmIaud5vN(QmRL0swTcY9dXyIgrp82Aa1ekD,fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==1015: PP3FsDicLyWuTR7GV5Ia = ANhJR3asZSXI0icxjmgCo1z(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==1016: PP3FsDicLyWuTR7GV5Ia = oQYXdhJ5Uvi2CuxlOF07pe(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==1018: PP3FsDicLyWuTR7GV5Ia = H62b7Kp1iJl(fRJYhnSKHsZ7MqFwmiVz)
	elif eYN1APt8aZflKmByj0ioGzn==1019: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(fRJYhnSKHsZ7MqFwmiVz,False)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder','بحث جوجل جديد',kh850jKbzmBwY,1019)
	EE6ysIeB8jKNgCfOkv('link','كيف يعمل بحث جوجل','',1013)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'==== كلمات البحث المخزنة ===='+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	iov3SWN1Q9ZKUxCygGlsnTkb07 = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if iov3SWN1Q9ZKUxCygGlsnTkb07:
		iov3SWN1Q9ZKUxCygGlsnTkb07 = iov3SWN1Q9ZKUxCygGlsnTkb07['__SEQUENCED_COLUMNS__']
		for othRNaJrlCsOAymp4iQL6HPEVn9gb in reversed(iov3SWN1Q9ZKUxCygGlsnTkb07):
			EE6ysIeB8jKNgCfOkv('folder',othRNaJrlCsOAymp4iQL6HPEVn9gb,kh850jKbzmBwY,1019,kh850jKbzmBwY,kh850jKbzmBwY,othRNaJrlCsOAymp4iQL6HPEVn9gb)
	return
def H62b7Kp1iJl(search):
	dStQzEeyknDaOs7q(search,True)
	EoGNACuMnrFUzPyi(wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	return
def dStQzEeyknDaOs7q(search,S3shCpdQ1wEYbDrVc60=False):
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	D2vGheawHt3pBn9CbZs = search.replace(GalrcVUMy8bzORWX5E0exhYivBwgk,kh850jKbzmBwY).lower()
	OOz1mhfT28KvtrsRV9ZcI,y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = [],[],[]
	if not S3shCpdQ1wEYbDrVc60:
		OOz1mhfT28KvtrsRV9ZcI = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GOOGLESEARCH_RESULTS',D2vGheawHt3pBn9CbZs)
		if OOz1mhfT28KvtrsRV9ZcI: y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = OOz1mhfT28KvtrsRV9ZcI
	if S3shCpdQ1wEYbDrVc60 or not OOz1mhfT28KvtrsRV9ZcI:
		import IIMRV5FExJ
		IIMRV5FExJ.ccetYpEjky8Q5n(D2vGheawHt3pBn9CbZs,'_GOOGLE',True)
		qRDCs0GyN8kcPQFWK = XWZNFYfscHqJh9PkpLBw5m7oM1jne(D2vGheawHt3pBn9CbZs)
		for JJNIsO8Vcbx0 in qRDCs0GyN8kcPQFWK:
			name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa = JJNIsO8Vcbx0
			if CYil97XWVj4Z3SRKMUf8DGQeLa in iZWXTKRotAsDxqPd2p: y0kAUGoQ1qPD7Wam6VjpuZHdTn.append(JJNIsO8Vcbx0)
			else: enijVD0dR9Cc1uwJBrPyTMUqxH58.append(JJNIsO8Vcbx0)
		y0kAUGoQ1qPD7Wam6VjpuZHdTn = sorted(y0kAUGoQ1qPD7Wam6VjpuZHdTn,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[nxUveizbLEAT2FBNy3])
		enijVD0dR9Cc1uwJBrPyTMUqxH58 = sorted(enijVD0dR9Cc1uwJBrPyTMUqxH58,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[nxUveizbLEAT2FBNy3])
		l0S5ZkdnJ8OaNh6GVoK7m(S4hoIWjT9NP,'GOOGLESEARCH_RESULTS',D2vGheawHt3pBn9CbZs,[y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58],xCNH20myQLKTeJUVA1p7)
		pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_DETAILED_GOOGLE',D2vGheawHt3pBn9CbZs)
		IIMRV5FExJ.ccetYpEjky8Q5n(D2vGheawHt3pBn9CbZs,'_GOOGLE',False)
		pOTRnSzCLqGyVXvl0dZxErcJHBoQIK(S4hoIWjT9NP,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+D2vGheawHt3pBn9CbZs+"')")
		if y0kAUGoQ1qPD7Wam6VjpuZHdTn: o1OgjEBsS0aKNl6T7LyAXWfmQ('','',fWM6PeOrvciG0RQpIKzltojDqaYs,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(y0kAUGoQ1qPD7Wam6VjpuZHdTn))+'  مواقع')
		else: y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = nLhVlJtj69q2sviRyPFbOI85zT(D2vGheawHt3pBn9CbZs,wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1)
	EE6ysIeB8jKNgCfOkv('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('folder','بحث منفرد لمواقع جوجل',kh850jKbzmBwY,1011,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder','نتائج البحث مفصلة - '+D2vGheawHt3pBn9CbZs,'opened_sites_google',1012,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('folder','نتائج البحث مقسمة - '+D2vGheawHt3pBn9CbZs,'listed_sites_google',1012,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('folder','مواقع جوجل ('+str(len(y0kAUGoQ1qPD7Wam6VjpuZHdTn))+') - '+D2vGheawHt3pBn9CbZs,'',1016,kh850jKbzmBwY,kh850jKbzmBwY,D2vGheawHt3pBn9CbZs)
	EE6ysIeB8jKNgCfOkv('link','إعادة بحث جوجل - '+D2vGheawHt3pBn9CbZs,'',1018,kh850jKbzmBwY,kh850jKbzmBwY,search)
	return
def oQYXdhJ5Uvi2CuxlOF07pe(D2vGheawHt3pBn9CbZs):
	y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = nLhVlJtj69q2sviRyPFbOI85zT(D2vGheawHt3pBn9CbZs)
	if not y0kAUGoQ1qPD7Wam6VjpuZHdTn and not enijVD0dR9Cc1uwJBrPyTMUqxH58: return
	KRSv9XD4bG7kV3JLj = {}
	for name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa in y0kAUGoQ1qPD7Wam6VjpuZHdTn: KRSv9XD4bG7kV3JLj[CYil97XWVj4Z3SRKMUf8DGQeLa] = name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa
	RkwHM25AJNxyZLdrei4hsB = list(KRSv9XD4bG7kV3JLj.keys())
	import IIMRV5FExJ
	RRVhnK0JNDQ9vkZY = IIMRV5FExJ.S4xl5ZswLy3pGDuOqIFgvUCk8cB1i6(RkwHM25AJNxyZLdrei4hsB)
	for CYil97XWVj4Z3SRKMUf8DGQeLa in RRVhnK0JNDQ9vkZY:
		if isinstance(CYil97XWVj4Z3SRKMUf8DGQeLa,tuple):
			Y3Ny5eLHdp.menuItemsLIST.append(CYil97XWVj4Z3SRKMUf8DGQeLa)
			continue
		name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa = KRSv9XD4bG7kV3JLj[CYil97XWVj4Z3SRKMUf8DGQeLa]
		p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
		EE6ysIeB8jKNgCfOkv('folder',THiQ1ScLBrWuwmaj+name,Ga8xfYU6ht7cHjzn,1014,z94udvAFymNsjokCrnMWJU35hGi2,'',CYil97XWVj4Z3SRKMUf8DGQeLa)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+'مواقع بجوجل غير موجودة بالبرنامج'+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,1015)
	enijVD0dR9Cc1uwJBrPyTMUqxH58 = sorted(enijVD0dR9Cc1uwJBrPyTMUqxH58,reverse=wyIDOlMFzoBsu8J9KQ5iqXYpGgSvH1,key=lambda key: key[nxUveizbLEAT2FBNy3])
	for name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa in enijVD0dR9Cc1uwJBrPyTMUqxH58:
		EE6ysIeB8jKNgCfOkv('link','_GOS_'+name,Ga8xfYU6ht7cHjzn,1015,z94udvAFymNsjokCrnMWJU35hGi2,'',CYil97XWVj4Z3SRKMUf8DGQeLa)
	return
def nLhVlJtj69q2sviRyPFbOI85zT(D2vGheawHt3pBn9CbZs,WLX7eo3a86Q=dbo4vrnTM56I):
	y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = [],[]
	if WLX7eo3a86Q:
		OOz1mhfT28KvtrsRV9ZcI = uw1M8e0QOsZqRvUPLatyzmcN4DEBG(S4hoIWjT9NP,'list','GOOGLESEARCH_RESULTS',D2vGheawHt3pBn9CbZs)
		if OOz1mhfT28KvtrsRV9ZcI: y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = OOz1mhfT28KvtrsRV9ZcI
	if not y0kAUGoQ1qPD7Wam6VjpuZHdTn and not enijVD0dR9Cc1uwJBrPyTMUqxH58: o1OgjEBsS0aKNl6T7LyAXWfmQ('','',fWM6PeOrvciG0RQpIKzltojDqaYs,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58
def nn3QvFXKCGTD6pN(MN6Qdl47bwDo9hqxpmc2t3Xf,D2vGheawHt3pBn9CbZs):
	y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = nLhVlJtj69q2sviRyPFbOI85zT(D2vGheawHt3pBn9CbZs)
	if not y0kAUGoQ1qPD7Wam6VjpuZHdTn and not enijVD0dR9Cc1uwJBrPyTMUqxH58: return
	GZ8YvC1IUTjsSwkx5qR,rWFKNsVdqGMf0lPYxARJSuECz3wX = [],{}
	for name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa in y0kAUGoQ1qPD7Wam6VjpuZHdTn:
		GZ8YvC1IUTjsSwkx5qR.append(CYil97XWVj4Z3SRKMUf8DGQeLa)
		rWFKNsVdqGMf0lPYxARJSuECz3wX[CYil97XWVj4Z3SRKMUf8DGQeLa] = MMBJC6laIYhwPGjSmv(text)
	import IIMRV5FExJ
	IIMRV5FExJ.sUWKYyqP426FlOHxuhXotzS(D2vGheawHt3pBn9CbZs,MN6Qdl47bwDo9hqxpmc2t3Xf,kh850jKbzmBwY,GZ8YvC1IUTjsSwkx5qR,rWFKNsVdqGMf0lPYxARJSuECz3wX)
	return
def X72phO4Lb1e6P0F9NmwVEtxKanjY(D2vGheawHt3pBn9CbZs):
	y0kAUGoQ1qPD7Wam6VjpuZHdTn,enijVD0dR9Cc1uwJBrPyTMUqxH58 = nLhVlJtj69q2sviRyPFbOI85zT(D2vGheawHt3pBn9CbZs)
	if not y0kAUGoQ1qPD7Wam6VjpuZHdTn and not enijVD0dR9Cc1uwJBrPyTMUqxH58: return
	KRSv9XD4bG7kV3JLj = {}
	for name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa in y0kAUGoQ1qPD7Wam6VjpuZHdTn:
		KRSv9XD4bG7kV3JLj[CYil97XWVj4Z3SRKMUf8DGQeLa] = name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa
	RkwHM25AJNxyZLdrei4hsB = list(KRSv9XD4bG7kV3JLj.keys())
	import IIMRV5FExJ
	RRVhnK0JNDQ9vkZY = IIMRV5FExJ.S4xl5ZswLy3pGDuOqIFgvUCk8cB1i6(RkwHM25AJNxyZLdrei4hsB)
	for CYil97XWVj4Z3SRKMUf8DGQeLa in RRVhnK0JNDQ9vkZY:
		if isinstance(CYil97XWVj4Z3SRKMUf8DGQeLa,tuple):
			Y3Ny5eLHdp.menuItemsLIST.append(CYil97XWVj4Z3SRKMUf8DGQeLa)
			continue
		name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa = KRSv9XD4bG7kV3JLj[CYil97XWVj4Z3SRKMUf8DGQeLa]
		p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
		text = MMBJC6laIYhwPGjSmv(text)
		name = name+' - '+D2vGheawHt3pBn9CbZs
		EE6ysIeB8jKNgCfOkv('folder',THiQ1ScLBrWuwmaj+name,CYil97XWVj4Z3SRKMUf8DGQeLa,548,z94udvAFymNsjokCrnMWJU35hGi2,'',text)
	return
def MMBJC6laIYhwPGjSmv(title):
	WULSmfNH09tPIv58snzpCkR = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(.*?) (الحلقة|حلقة)',title,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	EVfKyFrmX1Mpb62tLuHS5w3W = WULSmfNH09tPIv58snzpCkR[0][0] if WULSmfNH09tPIv58snzpCkR else title
	EVfKyFrmX1Mpb62tLuHS5w3W = EVfKyFrmX1Mpb62tLuHS5w3W.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	EVfKyFrmX1Mpb62tLuHS5w3W = EVfKyFrmX1Mpb62tLuHS5w3W.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	EVfKyFrmX1Mpb62tLuHS5w3W = EVfKyFrmX1Mpb62tLuHS5w3W.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	EVfKyFrmX1Mpb62tLuHS5w3W = EVfKyFrmX1Mpb62tLuHS5w3W.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	EVfKyFrmX1Mpb62tLuHS5w3W = EVfKyFrmX1Mpb62tLuHS5w3W.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	EVfKyFrmX1Mpb62tLuHS5w3W = EVfKyFrmX1Mpb62tLuHS5w3W.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return EVfKyFrmX1Mpb62tLuHS5w3W
def XWZNFYfscHqJh9PkpLBw5m7oM1jne(search):
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	O9wzaDlICnq = url+'&start=0&num=100&tbm=vid&udm=7'
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'GET',O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'GOOGLESEARCH-SEARCH-1st')
	if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded: return []
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	HWJCljvcnREaGDIgSNP3 = YdDkIjFhgzuboBKca70ERt.path.join(N3sFYzhgMTQ,'googlesearch')
	if not YdDkIjFhgzuboBKca70ERt.path.exists(HWJCljvcnREaGDIgSNP3):
		try: YdDkIjFhgzuboBKca70ERt.makedirs(HWJCljvcnREaGDIgSNP3)
		except: pass
	items = []
	tKoDYsOPeyxM = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if tKoDYsOPeyxM:
		for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
			Ga8xfYU6ht7cHjzn,title,text,vvufbqFnUclCD5MxOz,name = ZZDUdXR52CMs9K73Ex
			vvufbqFnUclCD5MxOz = ''
			items.append([Ga8xfYU6ht7cHjzn,title,text,name,vvufbqFnUclCD5MxOz])
	else:
		O9wzaDlICnq = url+'&start=0&num=200'
		OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(uQIXMypK534GsVWetdl6Px9fTjUn,'GET:SCRAPERS',O9wzaDlICnq,kh850jKbzmBwY,headers,kh850jKbzmBwY,kh850jKbzmBwY,'GOOGLESEARCH-SEARCH-2nd')
		if not OIjmsWqwACpDMT7l3GaYbxtvh0L.succeeded: return []
		uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
		tKoDYsOPeyxM = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if not tKoDYsOPeyxM: tKoDYsOPeyxM = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for ZZDUdXR52CMs9K73Ex in tKoDYsOPeyxM:
			ZZDUdXR52CMs9K73Ex = tmYCsS329HanzjLFbJP('list',ZZDUdXR52CMs9K73Ex)
			if len(ZZDUdXR52CMs9K73Ex)>17:
				Ga8xfYU6ht7cHjzn = ZZDUdXR52CMs9K73Ex[17]
				title,text,name,vvufbqFnUclCD5MxOz = ZZDUdXR52CMs9K73Ex[31][0:4]
				items.append([Ga8xfYU6ht7cHjzn,title,text,name,vvufbqFnUclCD5MxOz])
	lg1SsuYOXr,VV7oyNlrqDn5Lmz4HeJECw8I = [],[]
	for JJNIsO8Vcbx0 in items:
		Ga8xfYU6ht7cHjzn,title,text,name,vvufbqFnUclCD5MxOz = JJNIsO8Vcbx0
		name = name.strip(' ')
		if not name: name = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
		name = MMNV8Ogb9iJ4TD1EQq(name)
		if 'http://' in vvufbqFnUclCD5MxOz or 'https://' in vvufbqFnUclCD5MxOz: z94udvAFymNsjokCrnMWJU35hGi2 = vvufbqFnUclCD5MxOz
		elif 'data:image/' in vvufbqFnUclCD5MxOz and ';base64,' in vvufbqFnUclCD5MxOz:
			B1KnMijSZVWrpfY = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('data:image/(\w+);base64,',vvufbqFnUclCD5MxOz)
			B1KnMijSZVWrpfY = B1KnMijSZVWrpfY[0]
			z94udvAFymNsjokCrnMWJU35hGi2 = YdDkIjFhgzuboBKca70ERt.path.join(HWJCljvcnREaGDIgSNP3,name+'.'+B1KnMijSZVWrpfY)
			if not YdDkIjFhgzuboBKca70ERt.path.exists(z94udvAFymNsjokCrnMWJU35hGi2):
				vvufbqFnUclCD5MxOz = vvufbqFnUclCD5MxOz.replace('\\u003d','=')
				vvufbqFnUclCD5MxOz = vvufbqFnUclCD5MxOz.replace('data:image/'+B1KnMijSZVWrpfY+';base64,','')
				PPsy5NYvHCZVX3WfbD = vPxW6op2YEF9yA8ILDwcUmXG0CZ.b64decode(vvufbqFnUclCD5MxOz)
				open(z94udvAFymNsjokCrnMWJU35hGi2,'wb').write(PPsy5NYvHCZVX3WfbD)
		else: z94udvAFymNsjokCrnMWJU35hGi2 = ''
		CYil97XWVj4Z3SRKMUf8DGQeLa = v1QWmKMcr2e3dXtOfsbD5lEJFTjq(name,Ga8xfYU6ht7cHjzn)
		if CYil97XWVj4Z3SRKMUf8DGQeLa not in VV7oyNlrqDn5Lmz4HeJECw8I:
			VV7oyNlrqDn5Lmz4HeJECw8I.append(CYil97XWVj4Z3SRKMUf8DGQeLa)
			name = Hczgh3TNkKXoq4AZ1wJiC(CYil97XWVj4Z3SRKMUf8DGQeLa)
			lg1SsuYOXr.append([name,Ga8xfYU6ht7cHjzn,title,text,z94udvAFymNsjokCrnMWJU35hGi2,CYil97XWVj4Z3SRKMUf8DGQeLa])
	return lg1SsuYOXr
def qeULpFE27fYwmIaud5vN(Ga8xfYU6ht7cHjzn,CYil97XWVj4Z3SRKMUf8DGQeLa):
	p0gCAJBwG1,VNevGUwBskhaFpPEr5oMyACH2q8,THiQ1ScLBrWuwmaj = jqnyGPlKC1bmwci(CYil97XWVj4Z3SRKMUf8DGQeLa)
	if THiQ1ScLBrWuwmaj: p0gCAJBwG1()
	else: ANhJR3asZSXI0icxjmgCo1z()
	return
def Jcl08PwWxmRBkTZrfiyLh7KjY1FXd():
	o1OgjEBsS0aKNl6T7LyAXWfmQ('','',fWM6PeOrvciG0RQpIKzltojDqaYs,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def ANhJR3asZSXI0icxjmgCo1z(CYil97XWVj4Z3SRKMUf8DGQeLa=''):
	o1OgjEBsS0aKNl6T7LyAXWfmQ('','',CYil97XWVj4Z3SRKMUf8DGQeLa,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def v1QWmKMcr2e3dXtOfsbD5lEJFTjq(name,Ga8xfYU6ht7cHjzn):
	I5v4YJoqbnd6DcOe7By = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	tVNeLEOXQU1osj = name.lower()
	pYMAch3kEg = ''
	for key in list(I5v4YJoqbnd6DcOe7By.keys()):
		if key.lower() in tVNeLEOXQU1osj: pYMAch3kEg = I5v4YJoqbnd6DcOe7By[key]
	if not pYMAch3kEg:
		jQOlvATLDcdquxVXaJib3Yo5 = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'url')
		for CYil97XWVj4Z3SRKMUf8DGQeLa in list(Y3Ny5eLHdp.SITESURLS.keys()):
			ZlKX7fiWVkAywdTUmMesrcR = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Y3Ny5eLHdp.SITESURLS[CYil97XWVj4Z3SRKMUf8DGQeLa][0],'url')
			if jQOlvATLDcdquxVXaJib3Yo5==ZlKX7fiWVkAywdTUmMesrcR: pYMAch3kEg = CYil97XWVj4Z3SRKMUf8DGQeLa
	if not pYMAch3kEg:
		tVNeLEOXQU1osj = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Ga8xfYU6ht7cHjzn,'name')
		for CYil97XWVj4Z3SRKMUf8DGQeLa in list(Y3Ny5eLHdp.SITESURLS.keys()):
			bg5txl14r2nR8padu = hBRWs4K6t1nderkNEQo7bIvCFuZfS(Y3Ny5eLHdp.SITESURLS[CYil97XWVj4Z3SRKMUf8DGQeLa][0],'name')
			if tVNeLEOXQU1osj==bg5txl14r2nR8padu: pYMAch3kEg = CYil97XWVj4Z3SRKMUf8DGQeLa
	if not pYMAch3kEg: pYMAch3kEg = name
	pYMAch3kEg = pYMAch3kEg.upper()
	return pYMAch3kEg
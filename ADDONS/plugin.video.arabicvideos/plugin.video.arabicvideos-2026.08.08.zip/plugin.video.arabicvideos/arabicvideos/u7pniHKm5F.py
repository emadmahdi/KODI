# -*- coding: utf-8 -*-
from EX1SxIMYj7 import *
vkNGie5mhCqoTFRzPKaML0x6 = 'SHIAVOICE'
GalrcVUMy8bzORWX5E0exhYivBwgk = '_SHV_'
WLjaXVNk2dnAJzPpy6OlMv4qoi9 = Y3Ny5eLHdp.SITESURLS[vkNGie5mhCqoTFRzPKaML0x6][0]
headers = {'User-Agent':None}
def Z6V4AKYFUSWMmqBNXJ72p(mode,url,text):
	if   mode==310: PP3FsDicLyWuTR7GV5Ia = ohG2UpvdmfAxONbuc()
	elif mode==311: PP3FsDicLyWuTR7GV5Ia = bsZhnoqjD3U(url)
	elif mode==312: PP3FsDicLyWuTR7GV5Ia = yv8LezRQifhw1Kx(url)
	elif mode==313: PP3FsDicLyWuTR7GV5Ia = J1mFhTilPspUeQ58GyoKaCbR(url)
	elif mode==314: PP3FsDicLyWuTR7GV5Ia = Em1lqDXHLbM6x0cv8Jiag(text)
	elif mode==319: PP3FsDicLyWuTR7GV5Ia = dStQzEeyknDaOs7q(text)
	else: PP3FsDicLyWuTR7GV5Ia = False
	return PP3FsDicLyWuTR7GV5Ia
def ohG2UpvdmfAxONbuc():
	EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+'بحث في الموقع',kh850jKbzmBwY,319,kh850jKbzmBwY,kh850jKbzmBwY,'_REMEMBERRESULTS_')
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(mXiE2RJGvS1DK4ZQuzl0sBFV,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHIAVOICE-MENU-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('id="menulinks"(.*?)</ul>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<h5>(.*?)</h5>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL|sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.IGNORECASE)
	for dUh1Xs4tY3yE in range(len(items)):
		title = items[dUh1Xs4tY3yE].strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,WLjaXVNk2dnAJzPpy6OlMv4qoi9,314,kh850jKbzmBwY,kh850jKbzmBwY,str(dUh1Xs4tY3yE+1))
	EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+'مقاطع شهر',WLjaXVNk2dnAJzPpy6OlMv4qoi9,314,kh850jKbzmBwY,kh850jKbzmBwY,'0')
	EE6ysIeB8jKNgCfOkv('link',HHFAVK8SwRUqBLuTfdeJ9nbD+' ===== ===== ===== '+wVvqN8LZCJW5ryAb1EHRPFkQ0,kh850jKbzmBwY,9999)
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<B>(.*?)</B>',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
		EE6ysIeB8jKNgCfOkv('folder',vkNGie5mhCqoTFRzPKaML0x6+'_SCRIPT_'+GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,311)
	return uP1m46pAK5a3UgdqvBz9rnL
def Em1lqDXHLbM6x0cv8Jiag(dUh1Xs4tY3yE):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',WLjaXVNk2dnAJzPpy6OlMv4qoi9,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHIAVOICE-LATEST-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	if dUh1Xs4tY3yE=='0':
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="tab-content"(.*?)</table>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,name,title in items:
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			title = title+' ('+name+')'
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,312)
	elif dUh1Xs4tY3yE in ['1','2','3']:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(<h5>.*?)<div class="col-lg',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		w5QEUqohdP = int(dUh1Xs4tY3yE)-1
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[w5QEUqohdP]
		if dUh1Xs4tY3yE=='1': items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		else: items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title,name in items:
			NWqAr40jTLlMBemn3o79y = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+NWqAr40jTLlMBemn3o79y
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			title = title+' ('+name+')'
			EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,311,NWqAr40jTLlMBemn3o79y)
	elif dUh1Xs4tY3yE in ['4','5','6']:
		liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('(<h5>.*?)</table>',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		dUh1Xs4tY3yE = int(dUh1Xs4tY3yE)-4
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[dUh1Xs4tY3yE]
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,FEGJjiSZXB5pNV,title,tVNeLEOXQU1osj in items:
			NWqAr40jTLlMBemn3o79y = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+NWqAr40jTLlMBemn3o79y
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
			title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			FEGJjiSZXB5pNV = FEGJjiSZXB5pNV.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			tVNeLEOXQU1osj = tVNeLEOXQU1osj.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
			if FEGJjiSZXB5pNV: name = FEGJjiSZXB5pNV
			else: name = tVNeLEOXQU1osj
			title = title+' ('+name+')'
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,312,NWqAr40jTLlMBemn3o79y)
	return
def bsZhnoqjD3U(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHIAVOICE-TITLES-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('ibox-heading"(.*?)class="float-right',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	if 'catsum-mobile' in ZZDUdXR52CMs9K73Ex:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		if items:
			for NWqAr40jTLlMBemn3o79y,Ga8xfYU6ht7cHjzn,title,count in items:
				NWqAr40jTLlMBemn3o79y = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+NWqAr40jTLlMBemn3o79y
				Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
				count = count.replace(' الصوتية: ',':')
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				title = title+' ('+count+')'
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,311,NWqAr40jTLlMBemn3o79y)
	else:
		items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
		for Ga8xfYU6ht7cHjzn,title,z2wnVEIQgsrFp,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ in items:
			if title==kh850jKbzmBwY or z2wnVEIQgsrFp==kh850jKbzmBwY: continue
			Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
			title = title+' ('+qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ+')'
			EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,312)
	if not items: do7Es2fUtFlM8ScLx(uP1m46pAK5a3UgdqvBz9rnL)
	return
def do7Es2fUtFlM8ScLx(uP1m46pAK5a3UgdqvBz9rnL):
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="ibox-content"(.*?)class="pagination',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title,name,count,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ in items:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		title = title+' ('+name+')'
		EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,312,kh850jKbzmBwY,qsS5bJ1dCpHKrUwTQaPNgvkBYe8MyZ)
	return
def J1mFhTilPspUeQ58GyoKaCbR(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHIAVOICE-SEARCH_ITEMS-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="ibox-content p-1"(.*?)class="ibox-content"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not liroJ6qCK9k:
		bsZhnoqjD3U(url)
		return
	ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
	items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?<strong>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	for Ga8xfYU6ht7cHjzn,title in items:
		Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+i2xvIPUGcdqsV5FnDfwBklhjCNXo7M+Ga8xfYU6ht7cHjzn
		title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
		if '/play-' in Ga8xfYU6ht7cHjzn: EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,312)
		else: EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,311)
	return
def yv8LezRQifhw1Kx(url):
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(qogplQ5vHLYt8Ci1fknObwMThe,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHIAVOICE-PLAY-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<audio.*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if not Ga8xfYU6ht7cHjzn: Ga8xfYU6ht7cHjzn = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('<video.*?src="(.*?)"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	Ga8xfYU6ht7cHjzn = WLjaXVNk2dnAJzPpy6OlMv4qoi9+Ga8xfYU6ht7cHjzn[0]
	NRlCaq1ndM(Ga8xfYU6ht7cHjzn,vkNGie5mhCqoTFRzPKaML0x6,'video')
	return
def dStQzEeyknDaOs7q(search):
	search,kFdoZmlxSf8shU,showDialogs = gCI13c7MdXA8(search)
	if search==kh850jKbzmBwY: search = GG5Fs0hvURxyBV8gz()
	if search==kh850jKbzmBwY: return
	search = search.replace(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF,'+')
	SzUZ0FXfmdJTpHalMhIVj = ['&t=a','&t=c','&t=s']
	if showDialogs:
		XXyMoINcdOPHt8GlQ7RpwBbTUrnYaj = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		TTn7mZzPRjq5GBESh8aKy = W6EMASlVYF0gvGmzo('موقع صوت الشيعة - أختر البحث', XXyMoINcdOPHt8GlQ7RpwBbTUrnYaj)
		if TTn7mZzPRjq5GBESh8aKy == -1: return
	elif '_SHIAVOICE-PERSONS_' in kFdoZmlxSf8shU: TTn7mZzPRjq5GBESh8aKy = 0
	elif '_SHIAVOICE-ALBUMS_' in kFdoZmlxSf8shU: TTn7mZzPRjq5GBESh8aKy = 1
	elif '_SHIAVOICE-AUDIOS_' in kFdoZmlxSf8shU: TTn7mZzPRjq5GBESh8aKy = 2
	else: return
	type = SzUZ0FXfmdJTpHalMhIVj[TTn7mZzPRjq5GBESh8aKy]
	url = WLjaXVNk2dnAJzPpy6OlMv4qoi9+'/search.php?q='+search+type
	OIjmsWqwACpDMT7l3GaYbxtvh0L = YaKMpWyQNmrhGov4TIg1SFOUXcB6(SSZixT0lqg4BaUOtf79JjFIurn,'GET',url,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,kh850jKbzmBwY,'SHIAVOICE-SEARCH-1st')
	uP1m46pAK5a3UgdqvBz9rnL = OIjmsWqwACpDMT7l3GaYbxtvh0L.content
	liroJ6qCK9k = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('class="ibox-content"(.*?)class="ibox-content"',uP1m46pAK5a3UgdqvBz9rnL,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
	if liroJ6qCK9k:
		ZZDUdXR52CMs9K73Ex = liroJ6qCK9k[0]
		if TTn7mZzPRjq5GBESh8aKy in [0,1]:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,NWqAr40jTLlMBemn3o79y,title,name in items:
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				title = title+' ('+name+')'
				EE6ysIeB8jKNgCfOkv('folder',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,313,NWqAr40jTLlMBemn3o79y)
		elif TTn7mZzPRjq5GBESh8aKy==2:
			items = sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',ZZDUdXR52CMs9K73Ex,sM9SGYQ26dkV1t4yN5LFjArWxgZT7p.DOTALL)
			for Ga8xfYU6ht7cHjzn,title,name in items:
				title = title.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				name = name.strip(EE3iZM15sTQ2t9cOhuCWwDjGSUzryF)
				title = title+' ('+name+')'
				EE6ysIeB8jKNgCfOkv('video',GalrcVUMy8bzORWX5E0exhYivBwgk+title,Ga8xfYU6ht7cHjzn,312)
	return
# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'CIMA4U'
headers = {'User-Agent':''}
W74fAyGxODoLPs5vMX2l8C93R = '_C4U_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==420: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==421: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==422: HkKfQCS7RIa4xi3houjvl = ix3SPh5KmdgfFrtHRk4QqwInAlC8(url)
	elif mode==423: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==424: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==427: HkKfQCS7RIa4xi3houjvl = oysOdNZQLc21AUrtqf6CxbvJRS4pm(url)
	elif mode==429: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','CIMA4U-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	pp5vX2CWHBtwOPzdq0Junij7 = pp5vX2CWHBtwOPzdq0Junij7[0].strip('/')
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(pp5vX2CWHBtwOPzdq0Junij7,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',pp5vX2CWHBtwOPzdq0Junij7,425)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',pp5vX2CWHBtwOPzdq0Junij7,424)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الرئيسية',pp5vX2CWHBtwOPzdq0Junij7,421)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('NavigationMenu(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="*(.*?)"*>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		if '/actors' in RRucmYBaXegTtNOdGHMQ: title = 'أفلام النجوم'
		elif '/netflix' in RRucmYBaXegTtNOdGHMQ: title = 'أفلام ومسلسلات نيتفلكس'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,421)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'قائمة تفصيلية',pp5vX2CWHBtwOPzdq0Junij7,427)
	return
def oysOdNZQLc21AUrtqf6CxbvJRS4pm(website=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','CIMA4U-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('FilteringTitle(.*?)PageTitle',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for p8pgXONsjY,id,RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		if 'netflix-movies' in RRucmYBaXegTtNOdGHMQ: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in RRucmYBaXegTtNOdGHMQ: title = 'مسلسلات نيتفلكس'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,421,'','',p8pgXONsjY+'|'+id)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,qzTpS3aBcFGiM=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if not qzTpS3aBcFGiM or '|' in qzTpS3aBcFGiM:
		if '|' not in qzTpS3aBcFGiM: we5JWlEPmtRkFc9gG = ''
		else: we5JWlEPmtRkFc9gG = '/archive/'+qzTpS3aBcFGiM
		cxvUhw6qRTP4oMJ3AzZ = False
		if 'PinSlider' in QstumvzTIEUMXCcx06aD4y8nSqH:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',url,421,'','','featured')
			cxvUhw6qRTP4oMJ3AzZ = True
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('PageTitle(.*?)PageContent',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			i9jtofq4JrV = IZGcQbePXxwAoyYR1n[0]
			kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('data-tab="(.*?)".*?<span>(.*?)<',i9jtofq4JrV,ZXFs0mEPR8qI2zj.DOTALL)
			for RMroHJXj7FdSB1I5TG6,Wu4CadwRTJfkbXMUVxO3jQ2 in kYoiqbhP2AfzOHWmjxS69sNdM:
				oKqQr8Ij0btxZ9SDm6h3Nd = pp5vX2CWHBtwOPzdq0Junij7+'/ajaxcenter/action/HomepageLoader/tab/'+RMroHJXj7FdSB1I5TG6+we5JWlEPmtRkFc9gG+'/'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,oKqQr8Ij0btxZ9SDm6h3Nd,421)
				cxvUhw6qRTP4oMJ3AzZ = True
		if cxvUhw6qRTP4oMJ3AzZ: Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if qzTpS3aBcFGiM=='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('PinSlider(.*?)MultiFilter',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('PinSlider(.*?)PageTitle',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		else: bdq4e6Wr2gslnSiA38 = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
	elif '/filter/' in url:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('PageContent(.*?)class="*pagination"*',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif '/actors' in url:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('PageContent(.*?)class="*pagination"*',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('Cima4uBlocks(.*?)</li></ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		else: bdq4e6Wr2gslnSiA38 = ''
	if not items: items = ZXFs0mEPR8qI2zj.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if not items: items = ZXFs0mEPR8qI2zj.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if not title: continue
		if '?news=' in RRucmYBaXegTtNOdGHMQ: continue
		title = title.replace('مشاهدة ','')
		title = qpob7TvxHSs4fEzO6(title)
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) حلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if LqYKJ36CBG and 'حلقة' in title:
			title = '_MOD_' + LqYKJ36CBG[0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,422,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/actor/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,421,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,422,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pagination(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n and qzTpS3aBcFGiM!='featured':
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = qpob7TvxHSs4fEzO6(title)
			title = title.replace('الصفحة ','')
			if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,421)
	Yt06jaVmgoDfUOu = ZXFs0mEPR8qI2zj.findall('</li><a href="(.*?)".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Yt06jaVmgoDfUOu:
		RRucmYBaXegTtNOdGHMQ,title = Yt06jaVmgoDfUOu[0]
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,421)
	return
def ix3SPh5KmdgfFrtHRk4QqwInAlC8(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="WatchNow".*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		url = IZGcQbePXxwAoyYR1n[0]
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('SeasonsSections(.*?)</div></div></div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if '/tag/' in url or '/actor' in url:
		RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif IZGcQbePXxwAoyYR1n:
		CrGO63LT7j2UxniW = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Thumb')
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall("href='(.*?)'>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		PPRTmdjgaJGvOwBIlCoNsVqHnZD38 = ['مسلسل','موسم','برنامج','حلقة']
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in PPRTmdjgaJGvOwBIlCoNsVqHnZD38):
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,423,CrGO63LT7j2UxniW)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,426,CrGO63LT7j2UxniW)
	else: pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('"background-image:url\((.*?)\)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0]
	else: CrGO63LT7j2UxniW = ''
	svw1K9Sp4Fl = ZXFs0mEPR8qI2zj.findall('EpisodesSection(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if svw1K9Sp4Fl:
		bdq4e6Wr2gslnSiA38 = svw1K9Sp4Fl[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,LqYKJ36CBG in items:
			title = title+' '+LqYKJ36CBG
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,426,CrGO63LT7j2UxniW)
	else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+'رابط التشغيل',url,426,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	basq7jluRvd = wpFmEA3z8JR.url
	if Yd6t3PjlLKk: basq7jluRvd = basq7jluRvd.encode('utf8')
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(basq7jluRvd,'url')
	YYmyQXglbEewzL3IA2Sd = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('WatchSection(.*?)</div></div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-link="(.*?)".*? />(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for uu2AypHEw6lW,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/structure/server.php?id='+uu2AypHEw6lW+'?named='+title+'__watch'
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\r','')
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('DownloadServers(.*?)</div></div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*? />(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): Wu4CadwRTJfkbXMUVxO3jQ2 = '__خاص'
			else: Wu4CadwRTJfkbXMUVxO3jQ2 = ''
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'+Wu4CadwRTJfkbXMUVxO3jQ2
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\r','')
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/Search?q='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
def VB2O0ktvjpGqC4JrTKlu9EWsIM(url):
	if 'smartemadfilter' not in url: url = d78KRnJmBWscGua0XMk(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('MultiFilter(.*?)PageTitle',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return jNFqoOewYB2mG
def ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38):
	items = ZXFs0mEPR8qI2zj.findall('data-id="(.*?)".*?</div>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return items
def mMV5WYge1qZDd3oU7QcP(url):
	ZFcjgy5Kb1GuRlmeCqY0vT = url.split('/smartemadfilter?')[0]
	SSybMXta8gxTFKrUZDwNLWPcoHfEQ = d78KRnJmBWscGua0XMk(url,'url')
	url = url.replace(ZFcjgy5Kb1GuRlmeCqY0vT,SSybMXta8gxTFKrUZDwNLWPcoHfEQ)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
E0tDmCreab3BWYTcdIupkU46v = ['category','types','release-year']
t1tvAd5EPXM = ['Quality','release-year','types','category']
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global E0tDmCreab3BWYTcdIupkU46v
			E0tDmCreab3BWYTcdIupkU46v = E0tDmCreab3BWYTcdIupkU46v[1:]
		if E0tDmCreab3BWYTcdIupkU46v[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(E0tDmCreab3BWYTcdIupkU46v[0:-1])):
			if E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
	elif type=='ALL_ITEMS_FILTER':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		lQHXdV9Nzf6BLqS8D = mMV5WYge1qZDd3oU7QcP(lQHXdV9Nzf6BLqS8D)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',lQHXdV9Nzf6BLqS8D,421,'','','filter')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',lQHXdV9Nzf6BLqS8D,421,'','','filter')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jNFqoOewYB2mG = VB2O0ktvjpGqC4JrTKlu9EWsIM(url)
	dict = {}
	for name,bdq4e6Wr2gslnSiA38,Lm4n6ZMXPrWpo in jNFqoOewYB2mG:
		if '/category/' in url and Lm4n6ZMXPrWpo=='category': continue
		name = name.replace('--','')
		items = ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='SPECIFIED_FILTER':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<2:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]:
					url = mMV5WYge1qZDd3oU7QcP(url)
					RxAy5lEFQ1chv0BrdU4p6Pt2(url)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'SPECIFIED_FILTER___'+tt6AbxYRgQ3aC4O)
				return
			else:
				lQHXdV9Nzf6BLqS8D = mMV5WYge1qZDd3oU7QcP(lQHXdV9Nzf6BLqS8D)
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,421,'','','filter')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,425,'','',tt6AbxYRgQ3aC4O)
		elif type=='ALL_ITEMS_FILTER':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع :'+name,lQHXdV9Nzf6BLqS8D,424,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if AARNPWHjQU9dEmDI=='196533': Z7ZzgCTMBsNlVi9 = 'أفلام نيتفلكس'
			elif AARNPWHjQU9dEmDI=='196531': Z7ZzgCTMBsNlVi9 = 'مسلسلات نيتفلكس'
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' :'#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' :'+name
			if type=='ALL_ITEMS_FILTER': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,424,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='SPECIFIED_FILTER' and E0tDmCreab3BWYTcdIupkU46v[-2]+'=' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
				aaIn3XlQKJ6zSfkmjuCyM = url+'/smartemadfilter?'+KMUEN9cD1OByji
				aaIn3XlQKJ6zSfkmjuCyM = mMV5WYge1qZDd3oU7QcP(aaIn3XlQKJ6zSfkmjuCyM)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,421,'','','filter')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,425,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.replace('=&','=0&')
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	for key in t1tvAd5EPXM:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('=0','=')
	return rXLaWluDjvi4xMwpOSF91JB7
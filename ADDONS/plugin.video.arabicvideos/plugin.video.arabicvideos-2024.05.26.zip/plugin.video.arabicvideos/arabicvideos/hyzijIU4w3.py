# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'DAILYMOTION'
W74fAyGxODoLPs5vMX2l8C93R = '_DLM_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
dJSW5LrBmHfxeu = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][1]
def OVQIAezo6U1NSTl4L(mode,url,text,type,wwNtFTLK2IqAszYBDV9J):
	if	 mode==400: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==401: HkKfQCS7RIa4xi3houjvl = HHtfMgV4UrRiplWjJEF1SXGk0eYohy(url,text)
	elif mode==402: HkKfQCS7RIa4xi3houjvl = PPnXxGcHjzRiV6YoE(url,text)
	elif mode==403: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,text)
	elif mode==404: HkKfQCS7RIa4xi3houjvl = dOFzUjyqgA7J2orcXiS6WbPt(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==405: HkKfQCS7RIa4xi3houjvl = bkxKhfST4pECRJPyiHow9Q(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==406: HkKfQCS7RIa4xi3houjvl = tdkCzfu2XAHsh36a(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==407: HkKfQCS7RIa4xi3houjvl = qN8Cpcwfs7ty0zaXnUmTlH6e(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==408: HkKfQCS7RIa4xi3houjvl = veilk59NMOc(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==409: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==411: HkKfQCS7RIa4xi3houjvl = bb71Zcw3CUzQ(url,text)
	elif mode==412: HkKfQCS7RIa4xi3houjvl = uMn0OAUw6eDCJsVivtB48IaZfk25r7(text,wwNtFTLK2IqAszYBDV9J)
	elif mode==413: HkKfQCS7RIa4xi3houjvl = rPRJn1pesAmbjVcghl3iL5d(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==414: HkKfQCS7RIa4xi3houjvl = wIB96LGR4Wfuscz(text)
	elif mode==415: HkKfQCS7RIa4xi3houjvl = ZtBWGpXTc2Cb(text,wwNtFTLK2IqAszYBDV9J)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الرئيسية','',414)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def PPnXxGcHjzRiV6YoE(url,e4LiD3xgMzabsKPqj):
	if '/dm_' in url:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = wpFmEA3z8JR.headers
		if 'Location' in list(headers.keys()): url = JJTrn6SEtYZV31eyR97+headers['Location']
	e4LiD3xgMzabsKPqj = '[COLOR FFC89008]'+e4LiD3xgMzabsKPqj+'[/COLOR]'
	e4LiD3xgMzabsKPqj = tBUH7AzLXw0qI9jrcxaMoSE(e4LiD3xgMzabsKPqj)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: بث حي',url,411,'','','channel_lives_now')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: آخر الفيديوهات',url+'/videos',408)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: المميزة',url,411,'','','channel_featured_videos')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: قوائم التشغيل',url+'/playlists',407)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def tBUH7AzLXw0qI9jrcxaMoSE(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = WhJe7bGx5XackTwOIZVLC8ut(title)
	return title
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,uk4V7BxXanKgeGcjAqDQLJ26SRr59d):
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs([url],ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def dOFzUjyqgA7J2orcXiS6WbPt(search,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	l3UpyxrXZ2 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysearchwords',search)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	if sort=='': l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysortmethod','')
	else: l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'/videos'
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"videos"(.*?)"VideoConnection"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for id,title,pZlfwRGuUEOTyHca19Q,e4LiD3xgMzabsKPqj,UombAD0Kk4XqOrYLB,CrGO63LT7j2UxniW in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('"','')
			if '"' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.replace('"','')
			if '"' in pZlfwRGuUEOTyHca19Q: pZlfwRGuUEOTyHca19Q = pZlfwRGuUEOTyHca19Q.replace('"','')
			if '"' in e4LiD3xgMzabsKPqj: e4LiD3xgMzabsKPqj = e4LiD3xgMzabsKPqj.replace('"','')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+id
			title = tBUH7AzLXw0qI9jrcxaMoSE(title)
			uk4V7BxXanKgeGcjAqDQLJ26SRr59d = pZlfwRGuUEOTyHca19Q+'::'+e4LiD3xgMzabsKPqj
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,403,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB,uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
		if '"hasNextPage":true' in QstumvzTIEUMXCcx06aD4y8nSqH:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,404,'',wwNtFTLK2IqAszYBDV9J,search)
	return
def bkxKhfST4pECRJPyiHow9Q(search,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	l3UpyxrXZ2 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysearchwords',search)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'/playlists'
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	items = ZXFs0mEPR8qI2zj.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for id,name,OOoNGmZhyR3HfY,pZlfwRGuUEOTyHca19Q,e4LiD3xgMzabsKPqj,CrGO63LT7j2UxniW,count in items:
		if '"' in OOoNGmZhyR3HfY: OOoNGmZhyR3HfY = OOoNGmZhyR3HfY.replace('"','')
		if '"' in pZlfwRGuUEOTyHca19Q: pZlfwRGuUEOTyHca19Q = pZlfwRGuUEOTyHca19Q.replace('"','')
		if '"' in e4LiD3xgMzabsKPqj: e4LiD3xgMzabsKPqj = e4LiD3xgMzabsKPqj.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('"','')
		if '"' in count: count = count.replace('"','')
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = tBUH7AzLXw0qI9jrcxaMoSE(title)
		uk4V7BxXanKgeGcjAqDQLJ26SRr59d = pZlfwRGuUEOTyHca19Q+'::'+e4LiD3xgMzabsKPqj
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,401,CrGO63LT7j2UxniW,'',uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
	if '"hasNextPage":true' in QstumvzTIEUMXCcx06aD4y8nSqH:
		wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,405,'',wwNtFTLK2IqAszYBDV9J,search)
	return
def tdkCzfu2XAHsh36a(search,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	l3UpyxrXZ2 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysearchwords',search)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'/channels'
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"channels"(.*?)"ChannelConnection"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for id,name,CrGO63LT7j2UxniW in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('"','')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+id
			title = 'CHNL:  '+name
			title = tBUH7AzLXw0qI9jrcxaMoSE(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,402,CrGO63LT7j2UxniW,'',name)
		if '"hasNextPage":true' in QstumvzTIEUMXCcx06aD4y8nSqH:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,406,'',wwNtFTLK2IqAszYBDV9J,search)
	return
def wIB96LGR4Wfuscz(ZZ65eHYdU472IQFCj1):
	l3UpyxrXZ2 = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	U9EPiz13FOSaL8YANvhQWKMktDZ = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	if U9EPiz13FOSaL8YANvhQWKMktDZ:
		RaBf1b25syNGxWY9Vc = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',U9EPiz13FOSaL8YANvhQWKMktDZ)
		IwUCnWT2hPcBz4V6uxoeAEr85d = RaBf1b25syNGxWY9Vc['data']['home']['neon']['sections']['edges']
		if not ZZ65eHYdU472IQFCj1:
			JlT0McdyYUZ536kPrFgVANB9DLpvjb = []
			for Rd3uCFOH4rBw6sg1YSIjelUJKV in IwUCnWT2hPcBz4V6uxoeAEr85d:
				nHoueUS6hLXcjy0dV9JFMwvECfZ5tN = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['title']
				if nHoueUS6hLXcjy0dV9JFMwvECfZ5tN not in JlT0McdyYUZ536kPrFgVANB9DLpvjb: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+nHoueUS6hLXcjy0dV9JFMwvECfZ5tN,'',414,'','',nHoueUS6hLXcjy0dV9JFMwvECfZ5tN)
				JlT0McdyYUZ536kPrFgVANB9DLpvjb.append(nHoueUS6hLXcjy0dV9JFMwvECfZ5tN)
		else:
			for Rd3uCFOH4rBw6sg1YSIjelUJKV in IwUCnWT2hPcBz4V6uxoeAEr85d:
				nHoueUS6hLXcjy0dV9JFMwvECfZ5tN = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['title']
				if nHoueUS6hLXcjy0dV9JFMwvECfZ5tN==ZZ65eHYdU472IQFCj1:
					jAbQSmhMvpt5X2UN8zyPkfdsnFq = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['components']['edges']
					for b84BIAPRowiKaj53rY0lQquOzeEm in jAbQSmhMvpt5X2UN8zyPkfdsnFq:
						UombAD0Kk4XqOrYLB = str(b84BIAPRowiKaj53rY0lQquOzeEm['node']['duration'])
						title = WhJe7bGx5XackTwOIZVLC8ut(b84BIAPRowiKaj53rY0lQquOzeEm['node']['title'])
						title = title.replace('\/','/')
						UuwLgGt0OhHXyQjrESYPql6zk3 = b84BIAPRowiKaj53rY0lQquOzeEm['node']['xid']
						CrGO63LT7j2UxniW = b84BIAPRowiKaj53rY0lQquOzeEm['node']['thumbnailx480']
						CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('\/','/')
						RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+UuwLgGt0OhHXyQjrESYPql6zk3
						Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,403,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB)
	return
def ZtBWGpXTc2Cb(search,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	l3UpyxrXZ2 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysearchwords',search)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'/lives'
	U9EPiz13FOSaL8YANvhQWKMktDZ = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	if U9EPiz13FOSaL8YANvhQWKMktDZ:
		RaBf1b25syNGxWY9Vc = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',U9EPiz13FOSaL8YANvhQWKMktDZ)
		try: IwUCnWT2hPcBz4V6uxoeAEr85d = RaBf1b25syNGxWY9Vc['data']['search']['lives']['edges']
		except: IwUCnWT2hPcBz4V6uxoeAEr85d = []
		for Rd3uCFOH4rBw6sg1YSIjelUJKV in IwUCnWT2hPcBz4V6uxoeAEr85d:
			name = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['title']
			UuwLgGt0OhHXyQjrESYPql6zk3 = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['xid']
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+UuwLgGt0OhHXyQjrESYPql6zk3
			Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+'LIVE: '+name,RRucmYBaXegTtNOdGHMQ,403)
		if '"hasNextPage":true' in U9EPiz13FOSaL8YANvhQWKMktDZ:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,415,'',wwNtFTLK2IqAszYBDV9J,search)
	return
def uMn0OAUw6eDCJsVivtB48IaZfk25r7(search,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	l3UpyxrXZ2 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysearchwords',search)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'/topics'
	U9EPiz13FOSaL8YANvhQWKMktDZ = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	if U9EPiz13FOSaL8YANvhQWKMktDZ:
		RaBf1b25syNGxWY9Vc = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',U9EPiz13FOSaL8YANvhQWKMktDZ)
		try: IwUCnWT2hPcBz4V6uxoeAEr85d = RaBf1b25syNGxWY9Vc['data']['search']['topics']['edges']
		except: IwUCnWT2hPcBz4V6uxoeAEr85d = []
		for Rd3uCFOH4rBw6sg1YSIjelUJKV in IwUCnWT2hPcBz4V6uxoeAEr85d:
			name = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['name']
			UuwLgGt0OhHXyQjrESYPql6zk3 = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['xid']
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/topic/'+UuwLgGt0OhHXyQjrESYPql6zk3
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'TOPIC: '+name,RRucmYBaXegTtNOdGHMQ,413)
		if '"hasNextPage":true' in U9EPiz13FOSaL8YANvhQWKMktDZ:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,412,'',wwNtFTLK2IqAszYBDV9J,search)
	return
def rPRJn1pesAmbjVcghl3iL5d(url,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	UuwLgGt0OhHXyQjrESYPql6zk3 = url.split('/')[-1]
	l3UpyxrXZ2 = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mytopicid',UuwLgGt0OhHXyQjrESYPql6zk3)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	U9EPiz13FOSaL8YANvhQWKMktDZ = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	if U9EPiz13FOSaL8YANvhQWKMktDZ:
		RaBf1b25syNGxWY9Vc = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',U9EPiz13FOSaL8YANvhQWKMktDZ)
		IwUCnWT2hPcBz4V6uxoeAEr85d = RaBf1b25syNGxWY9Vc['data']['topic']['videos']['edges']
		for Rd3uCFOH4rBw6sg1YSIjelUJKV in IwUCnWT2hPcBz4V6uxoeAEr85d:
			UombAD0Kk4XqOrYLB = str(Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['duration'])
			title = WhJe7bGx5XackTwOIZVLC8ut(Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['title'])
			title = title.replace('\/','/')
			UuwLgGt0OhHXyQjrESYPql6zk3 = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['xid']
			CrGO63LT7j2UxniW = Rd3uCFOH4rBw6sg1YSIjelUJKV['node']['thumbnailx480']
			CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('\/','/')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+UuwLgGt0OhHXyQjrESYPql6zk3
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,403,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB)
		if '"hasNextPage":true' in U9EPiz13FOSaL8YANvhQWKMktDZ:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,413,'',wwNtFTLK2IqAszYBDV9J)
	return
def HHtfMgV4UrRiplWjJEF1SXGk0eYohy(url,uk4V7BxXanKgeGcjAqDQLJ26SRr59d):
	id = url.split('/')[-1]
	pZlfwRGuUEOTyHca19Q,e4LiD3xgMzabsKPqj = uk4V7BxXanKgeGcjAqDQLJ26SRr59d.split('::',1)
	RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+pZlfwRGuUEOTyHca19Q
	e4LiD3xgMzabsKPqj = tBUH7AzLXw0qI9jrcxaMoSE(e4LiD3xgMzabsKPqj)
	title = '[COLOR FFC89008]OWNER:  '+e4LiD3xgMzabsKPqj+'[/COLOR]'
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,402,'','',e4LiD3xgMzabsKPqj)
	l3UpyxrXZ2 = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('myplaylistid',id)
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"collection_videos"(.*?)"SectionEdge"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for id,title,UombAD0Kk4XqOrYLB,CrGO63LT7j2UxniW,pZlfwRGuUEOTyHca19Q,e4LiD3xgMzabsKPqj in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('"','')
			if '"' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.replace('"','')
			if '"' in pZlfwRGuUEOTyHca19Q: pZlfwRGuUEOTyHca19Q = pZlfwRGuUEOTyHca19Q.replace('"','')
			if '"' in e4LiD3xgMzabsKPqj: e4LiD3xgMzabsKPqj = e4LiD3xgMzabsKPqj.replace('"','')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+id
			title = tBUH7AzLXw0qI9jrcxaMoSE(title)
			uk4V7BxXanKgeGcjAqDQLJ26SRr59d = pZlfwRGuUEOTyHca19Q+'::'+e4LiD3xgMzabsKPqj
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,403,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB,uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
	return
def veilk59NMOc(url,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	yfZpUog0Rbs8CFEv9 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	l3UpyxrXZ2 = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mychannelid',yfZpUog0Rbs8CFEv9)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysortmethod',sort)
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for id,title,UombAD0Kk4XqOrYLB,pZlfwRGuUEOTyHca19Q,e4LiD3xgMzabsKPqj,CrGO63LT7j2UxniW in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('"','')
			if '"' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.replace('"','')
			if '"' in pZlfwRGuUEOTyHca19Q: pZlfwRGuUEOTyHca19Q = pZlfwRGuUEOTyHca19Q.replace('"','')
			if '"' in e4LiD3xgMzabsKPqj: e4LiD3xgMzabsKPqj = e4LiD3xgMzabsKPqj.replace('"','')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+id
			title = tBUH7AzLXw0qI9jrcxaMoSE(title)
			uk4V7BxXanKgeGcjAqDQLJ26SRr59d = pZlfwRGuUEOTyHca19Q+'::'+e4LiD3xgMzabsKPqj
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,403,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB,uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
		if '"hasNextPage":true' in QstumvzTIEUMXCcx06aD4y8nSqH:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,408,'',wwNtFTLK2IqAszYBDV9J)
	return
def qN8Cpcwfs7ty0zaXnUmTlH6e(url,wwNtFTLK2IqAszYBDV9J=''):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	yfZpUog0Rbs8CFEv9 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	l3UpyxrXZ2 = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mychannelid',yfZpUog0Rbs8CFEv9)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagelimit','40')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mypagenumber',wwNtFTLK2IqAszYBDV9J)
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mysortmethod',sort)
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for id,name,CrGO63LT7j2UxniW,count,OOoNGmZhyR3HfY,pZlfwRGuUEOTyHca19Q,e4LiD3xgMzabsKPqj in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in OOoNGmZhyR3HfY: OOoNGmZhyR3HfY = OOoNGmZhyR3HfY.replace('"','')
			if '"' in pZlfwRGuUEOTyHca19Q: pZlfwRGuUEOTyHca19Q = pZlfwRGuUEOTyHca19Q.replace('"','')
			if '"' in e4LiD3xgMzabsKPqj: e4LiD3xgMzabsKPqj = e4LiD3xgMzabsKPqj.replace('"','')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = tBUH7AzLXw0qI9jrcxaMoSE(title)
			uk4V7BxXanKgeGcjAqDQLJ26SRr59d = pZlfwRGuUEOTyHca19Q+'::'+e4LiD3xgMzabsKPqj
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,401,CrGO63LT7j2UxniW,'',uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
		if '"hasNextPage":true' in QstumvzTIEUMXCcx06aD4y8nSqH:
			wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)+1)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+wwNtFTLK2IqAszYBDV9J,url,407,'',wwNtFTLK2IqAszYBDV9J)
	return
def bb71Zcw3CUzQ(url,y7mcfaDkwjBhg9V6pe):
	yfZpUog0Rbs8CFEv9 = url.split('/')[3]
	l3UpyxrXZ2 = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('mychannelid',yfZpUog0Rbs8CFEv9)
	QstumvzTIEUMXCcx06aD4y8nSqH = yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2)
	import json as VmSKvRtTw5WBYDI
	fAEDM46l9I3V0BxgkPqehmJcv = VmSKvRtTw5WBYDI.loads(QstumvzTIEUMXCcx06aD4y8nSqH)
	try: items = fAEDM46l9I3V0BxgkPqehmJcv['data']['channel'][y7mcfaDkwjBhg9V6pe]['edges']
	except: items = []
	if not items: Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'لا توجد نتائج','',9999)
	else:
		for q8BXZlN9sU1fP2JAxH7W in items:
			ddf1MCiZrRbkyvzPmh3D = q8BXZlN9sU1fP2JAxH7W['node']
			UuwLgGt0OhHXyQjrESYPql6zk3 = ddf1MCiZrRbkyvzPmh3D['xid']
			keys = list(ddf1MCiZrRbkyvzPmh3D.keys())
			PfS6VqvBcd1LZb2CGDeh3 = ddf1MCiZrRbkyvzPmh3D['__typename'].lower()
			if PfS6VqvBcd1LZb2CGDeh3=='channel':
				name = ddf1MCiZrRbkyvzPmh3D['name']
				AY1kP6c7LMQhgDdH0ZEuy4pX = ddf1MCiZrRbkyvzPmh3D['displayName']
				title = 'CHNL:  '+AY1kP6c7LMQhgDdH0ZEuy4pX
				CrGO63LT7j2UxniW = ddf1MCiZrRbkyvzPmh3D['coverURLx375']
			else:
				name = ddf1MCiZrRbkyvzPmh3D['channel']['name']
				AY1kP6c7LMQhgDdH0ZEuy4pX = ddf1MCiZrRbkyvzPmh3D['channel']['displayName']
				title = ddf1MCiZrRbkyvzPmh3D['title']
				CrGO63LT7j2UxniW = ddf1MCiZrRbkyvzPmh3D['thumbnailx360']
				if PfS6VqvBcd1LZb2CGDeh3=='live': title = 'LIVE:  '+title
			title = tBUH7AzLXw0qI9jrcxaMoSE(title)
			uk4V7BxXanKgeGcjAqDQLJ26SRr59d = name+'::'+AY1kP6c7LMQhgDdH0ZEuy4pX
			if Yd6t3PjlLKk:
				title = title.encode('utf8')
				uk4V7BxXanKgeGcjAqDQLJ26SRr59d = uk4V7BxXanKgeGcjAqDQLJ26SRr59d.encode('utf8')
			if PfS6VqvBcd1LZb2CGDeh3=='channel':
				RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+UuwLgGt0OhHXyQjrESYPql6zk3
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,402,CrGO63LT7j2UxniW,'',uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
			else:
				if PfS6VqvBcd1LZb2CGDeh3=='video': UombAD0Kk4XqOrYLB = str(ddf1MCiZrRbkyvzPmh3D['duration'])
				else: UombAD0Kk4XqOrYLB = ''
				RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/video/'+UuwLgGt0OhHXyQjrESYPql6zk3
				Tca7NsYPkIRWtBpFgxLZbSmCi(PfS6VqvBcd1LZb2CGDeh3,W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,403,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB,uk4V7BxXanKgeGcjAqDQLJ26SRr59d)
	return
def yBMUDti2A4LYnKdRzpShVxFl5kPo7g(l3UpyxrXZ2):
	l3UpyxrXZ2 = l3UpyxrXZ2.replace(' \"',' \\"')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('\", ','\\", ')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('\n','\\n')
	l3UpyxrXZ2 = l3UpyxrXZ2.replace('")','\\")')
	NzgsIyDqK7o0wClvpVcei = WWUiOlkjKHVwAaQ6LshcnyD()
	headers = {"Authorization":NzgsIyDqK7o0wClvpVcei,"Origin":JJTrn6SEtYZV31eyR97}
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',dJSW5LrBmHfxeu,l3UpyxrXZ2,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	return QstumvzTIEUMXCcx06aD4y8nSqH
def WWUiOlkjKHVwAaQ6LshcnyD():
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	CaUvZKNsLl5fAuoGSqBmwYz0iO3 = ZXFs0mEPR8qI2zj.findall('var r="(.*?)",o="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	Vb2kMWuDAx3dRE,eNESws89vT1hHjGm7DYzbO6Ccp5 = CaUvZKNsLl5fAuoGSqBmwYz0iO3[-1]
	PO54RXWCMEcJFaBtzoQKeG = 'https://graphql.api.dailymotion.com/oauth/token'
	RIH3QMB71sT60XWoyfzu = 'client_credentials'
	data = {'client_id':Vb2kMWuDAx3dRE,'client_secret':eNESws89vT1hHjGm7DYzbO6Ccp5,'grant_type':RIH3QMB71sT60XWoyfzu}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',PO54RXWCMEcJFaBtzoQKeG,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	CaUvZKNsLl5fAuoGSqBmwYz0iO3 = ZXFs0mEPR8qI2zj.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	r07YvIFan9Bpufe,e62fGDAqJonPYmpSjUcF = CaUvZKNsLl5fAuoGSqBmwYz0iO3[0]
	NzgsIyDqK7o0wClvpVcei = e62fGDAqJonPYmpSjUcF+" "+r07YvIFan9Bpufe
	return NzgsIyDqK7o0wClvpVcei
def F6OgHwYPRiX10tJEv8r(search,type=''):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not type and showDialogs:
		Vnajf5T0AOt7RSlvZXqgJbPp = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('موقع ديلي موشن - اختر البحث',Vnajf5T0AOt7RSlvZXqgJbPp)
		if jQ6w8xOrgYhSHIRpUqzL==-1: return
		elif jQ6w8xOrgYhSHIRpUqzL==0: type = 'videos?sortBy='
		elif jQ6w8xOrgYhSHIRpUqzL==1: type = 'videos?sortBy=RECENT'
		elif jQ6w8xOrgYhSHIRpUqzL==2: type = 'videos?sortBy=VIEW_COUNT'
		elif jQ6w8xOrgYhSHIRpUqzL==3: type = 'playlists'
		elif jQ6w8xOrgYhSHIRpUqzL==4: type = 'channels'
		elif jQ6w8xOrgYhSHIRpUqzL==5: type = 'topics'
		elif jQ6w8xOrgYhSHIRpUqzL==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in Y9RKmgsxBefkFcuIj2GULDHy3: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in Y9RKmgsxBefkFcuIj2GULDHy3: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in Y9RKmgsxBefkFcuIj2GULDHy3: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in Y9RKmgsxBefkFcuIj2GULDHy3: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in Y9RKmgsxBefkFcuIj2GULDHy3: type = 'lives'
	if not search:
		search = CjyEnpfQ23o0PYwDtLId()
		if not search: return
	if VYMZsxRpcQHPgkaiDKjyoh: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: dOFzUjyqgA7J2orcXiS6WbPt(search+'/'+type)
	elif 'playlists' in type: bkxKhfST4pECRJPyiHow9Q(search)
	elif 'channels' in type: tdkCzfu2XAHsh36a(search)
	elif 'topics' in type: uMn0OAUw6eDCJsVivtB48IaZfk25r7(search)
	elif 'lives' in type: ZtBWGpXTc2Cb(search)
	return
# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'YOUTUBE'
W74fAyGxODoLPs5vMX2l8C93R = '_YUT_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
kZSo0sOte7CXupBKWLx3YmEHFl = 0
def OVQIAezo6U1NSTl4L(mode,url,text,type,wwNtFTLK2IqAszYBDV9J,name,ttiasLcTXGvgqb41nC7DRF):
	if	 mode==140: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==141: HkKfQCS7RIa4xi3houjvl = N9NrDCp0UT6(url,name,ttiasLcTXGvgqb41nC7DRF)
	elif mode==143: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,type)
	elif mode==144: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J,text)
	elif mode==145: HkKfQCS7RIa4xi3houjvl = P7Z0G9vzMOlnidteTSwVsQCa6Ah3xp(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==147: HkKfQCS7RIa4xi3houjvl = ZAiFwv4qXaQVumyYc3G0KUPzkl()
	elif mode==148: HkKfQCS7RIa4xi3houjvl = bLXle32UrFNAH1CVKgDEa0YftP5x()
	elif mode==149: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	if 0:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'قائمة',JJTrn6SEtYZV31eyR97+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'شخص',JJTrn6SEtYZV31eyR97+'/user/TCNofficial',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'موقع',JJTrn6SEtYZV31eyR97+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'حساب',JJTrn6SEtYZV31eyR97+'/@TheSocialCTV',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'العاب',JJTrn6SEtYZV31eyR97+'/gaming',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'افلام',JJTrn6SEtYZV31eyR97+'/feed/storefront',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مختارات',JJTrn6SEtYZV31eyR97+'/feed/guide_builder',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'قصيرة',JJTrn6SEtYZV31eyR97+'/shorts',144,'','','_REMEMBERRESULTS_')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'تصفح',JJTrn6SEtYZV31eyR97+'/youtubei/v1/guide?key=',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'رئيسية',JJTrn6SEtYZV31eyR97+'',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'رائج',JJTrn6SEtYZV31eyR97+'/feed/trending?bp=',144)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الرائجة',JJTrn6SEtYZV31eyR97+'/feed/trending',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'التصفح',JJTrn6SEtYZV31eyR97+'/youtubei/v1/guide?key=',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'القصيرة',JJTrn6SEtYZV31eyR97+'/shorts',144,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مختارات يوتيوب',JJTrn6SEtYZV31eyR97+'/feed/guide_builder',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مختارات البرنامج','',290)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: قنوات عربية','',147)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: قنوات أجنبية','',148)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: افلام عربية',JJTrn6SEtYZV31eyR97+'/results?search_query=فيلم',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: افلام اجنبية',JJTrn6SEtYZV31eyR97+'/results?search_query=movie',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسرحيات عربية',JJTrn6SEtYZV31eyR97+'/results?search_query=مسرحية',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسلسلات عربية',JJTrn6SEtYZV31eyR97+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسلسلات اجنبية',JJTrn6SEtYZV31eyR97+'/results?search_query=series&sp=EgIQAw==',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: مسلسلات كارتون',JJTrn6SEtYZV31eyR97+'/results?search_query=كارتون&sp=EgIQAw==',144)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث: خطبة المرجعية',JJTrn6SEtYZV31eyR97+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def N9NrDCp0UT6(url,name,ttiasLcTXGvgqb41nC7DRF):
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'CHNL:  '+name,url,144,ttiasLcTXGvgqb41nC7DRF)
	return
def ZAiFwv4qXaQVumyYc3G0KUPzkl():
	RxAy5lEFQ1chv0BrdU4p6Pt2(JJTrn6SEtYZV31eyR97+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def bLXle32UrFNAH1CVKgDEa0YftP5x():
	RxAy5lEFQ1chv0BrdU4p6Pt2(JJTrn6SEtYZV31eyR97+'/results?search_query=tv&sp=EgJAAQ==')
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,type):
	url = url.split('&',1)[0]
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs([url],ll6f2wvU4FdqL3MJyDxORESCK197i,type,url)
	return
def sp1vMWbtHKfFG(xJ8ojkFpBUbMPglDA0LT4H,url,LcnYtXvRpST3U):
	level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = LcnYtXvRpST3U.split('::')
	FF9E6MD1B8WA0NKG,MM6mFZQK1chIuPdAfLp = [],[]
	if '/youtubei/v1/browse' in url: FF9E6MD1B8WA0NKG.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: FF9E6MD1B8WA0NKG.append("yccc['onResponseReceivedCommands']")
	FF9E6MD1B8WA0NKG.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': FF9E6MD1B8WA0NKG.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	FF9E6MD1B8WA0NKG.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	FF9E6MD1B8WA0NKG.append("yccc['entries']")
	FF9E6MD1B8WA0NKG.append("yccc['items'][3]['guideSectionRenderer']['items']")
	qPcVJh2SmwzybQFLOB8NT,b91u7sX8g32NWR,KBuNUkq8CzR2f1hgF = kDOJ3RNYFI(xJ8ojkFpBUbMPglDA0LT4H,'',FF9E6MD1B8WA0NKG)
	if level=='1' and qPcVJh2SmwzybQFLOB8NT:
		if len(b91u7sX8g32NWR)>1 and 'search_query' not in url:
			for DpPqhakxAX0Hn in range(len(b91u7sX8g32NWR)):
				YYaSjFAxlhtunNb1omd94 = str(DpPqhakxAX0Hn)
				FF9E6MD1B8WA0NKG = []
				FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['reloadContinuationItemsCommand']['continuationItems']")
				FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['command']")
				FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]")
				ybf3Qo7isaYVr,q8BXZlN9sU1fP2JAxH7W,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(b91u7sX8g32NWR,'',FF9E6MD1B8WA0NKG)
				if ybf3Qo7isaYVr: MM6mFZQK1chIuPdAfLp.append([q8BXZlN9sU1fP2JAxH7W,url,'2::'+YYaSjFAxlhtunNb1omd94+'::0::0'])
			FF9E6MD1B8WA0NKG.append("yccc['continuationEndpoint']")
			ybf3Qo7isaYVr,q8BXZlN9sU1fP2JAxH7W,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(xJ8ojkFpBUbMPglDA0LT4H,'',FF9E6MD1B8WA0NKG)
			if ybf3Qo7isaYVr and MM6mFZQK1chIuPdAfLp and 'continuationCommand' in list(q8BXZlN9sU1fP2JAxH7W.keys()):
				RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/my_main_page_shorts_link'
				MM6mFZQK1chIuPdAfLp.append([q8BXZlN9sU1fP2JAxH7W,RRucmYBaXegTtNOdGHMQ,'1::0::0::0'])
	return b91u7sX8g32NWR,qPcVJh2SmwzybQFLOB8NT,MM6mFZQK1chIuPdAfLp,KBuNUkq8CzR2f1hgF
def rrxfoGUO2Kd(xJ8ojkFpBUbMPglDA0LT4H,b91u7sX8g32NWR,url,LcnYtXvRpST3U):
	level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = LcnYtXvRpST3U.split('::')
	FF9E6MD1B8WA0NKG,ANxeMF0DKh = [],[]
	FF9E6MD1B8WA0NKG.append("yddd[0]['itemSectionRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['reloadContinuationItemsCommand']['continuationItems']")
	FF9E6MD1B8WA0NKG.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: FF9E6MD1B8WA0NKG.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: FF9E6MD1B8WA0NKG.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yddd["+YYaSjFAxlhtunNb1omd94+"]")
	y2Vm8lZriUtnHE7opRvhX,mDVLxtK2O0,EO38muZ47zHc5Lkd0JAXpF = kDOJ3RNYFI(b91u7sX8g32NWR,'',FF9E6MD1B8WA0NKG)
	if level=='2' and y2Vm8lZriUtnHE7opRvhX:
		if len(mDVLxtK2O0)>1:
			for DpPqhakxAX0Hn in range(len(mDVLxtK2O0)):
				KTPWbDAHS2kxNcB0j7nIhJdMCZ = str(DpPqhakxAX0Hn)
				FF9E6MD1B8WA0NKG = []
				FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['richSectionRenderer']['content']")
				FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]")
				FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['richItemRenderer']['content']")
				FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]")
				ybf3Qo7isaYVr,q8BXZlN9sU1fP2JAxH7W,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(mDVLxtK2O0,'',FF9E6MD1B8WA0NKG)
				if ybf3Qo7isaYVr: ANxeMF0DKh.append([q8BXZlN9sU1fP2JAxH7W,url,'3::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::0'])
			FF9E6MD1B8WA0NKG.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			FF9E6MD1B8WA0NKG.append("yddd[1]")
			ybf3Qo7isaYVr,q8BXZlN9sU1fP2JAxH7W,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(b91u7sX8g32NWR,'',FF9E6MD1B8WA0NKG)
			if ybf3Qo7isaYVr and ANxeMF0DKh and 'continuationItemRenderer' in list(q8BXZlN9sU1fP2JAxH7W.keys()):
				ANxeMF0DKh.append([q8BXZlN9sU1fP2JAxH7W,url,'3::0::0::0'])
	return mDVLxtK2O0,y2Vm8lZriUtnHE7opRvhX,ANxeMF0DKh,EO38muZ47zHc5Lkd0JAXpF
def VVzCxrstNYwA49HG8anMbvSI2(xJ8ojkFpBUbMPglDA0LT4H,mDVLxtK2O0,url,LcnYtXvRpST3U):
	level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = LcnYtXvRpST3U.split('::')
	FF9E6MD1B8WA0NKG,hIJ6fsq1LV0ng4TG3lcbrj = [],[]
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['reelShelfRenderer']['items']")
	FF9E6MD1B8WA0NKG.append("yeee["+KTPWbDAHS2kxNcB0j7nIhJdMCZ+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	FF9E6MD1B8WA0NKG.append("yeee")
	VKIWmgqSHLDcXp2helnt5v6wo7yCE,vvHVNd0afGhekMqP84DAKg9YJ,M1My5N28vKaQ3E = kDOJ3RNYFI(mDVLxtK2O0,'',FF9E6MD1B8WA0NKG)
	if level=='3' and VKIWmgqSHLDcXp2helnt5v6wo7yCE:
		if len(vvHVNd0afGhekMqP84DAKg9YJ)>0:
			for DpPqhakxAX0Hn in range(len(vvHVNd0afGhekMqP84DAKg9YJ)):
				JYElAaxM0gZeH42WQi1cumj = str(DpPqhakxAX0Hn)
				FF9E6MD1B8WA0NKG = []
				FF9E6MD1B8WA0NKG.append("yfff["+JYElAaxM0gZeH42WQi1cumj+"]['richItemRenderer']['content']")
				FF9E6MD1B8WA0NKG.append("yfff["+JYElAaxM0gZeH42WQi1cumj+"]['gameCardRenderer']['game']")
				FF9E6MD1B8WA0NKG.append("yfff["+JYElAaxM0gZeH42WQi1cumj+"]['itemSectionRenderer']['contents'][0]")
				FF9E6MD1B8WA0NKG.append("yfff["+JYElAaxM0gZeH42WQi1cumj+"]")
				ybf3Qo7isaYVr,q8BXZlN9sU1fP2JAxH7W,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(vvHVNd0afGhekMqP84DAKg9YJ,'',FF9E6MD1B8WA0NKG)
				if ybf3Qo7isaYVr: hIJ6fsq1LV0ng4TG3lcbrj.append([q8BXZlN9sU1fP2JAxH7W,url,'4::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj])
	return vvHVNd0afGhekMqP84DAKg9YJ,VKIWmgqSHLDcXp2helnt5v6wo7yCE,hIJ6fsq1LV0ng4TG3lcbrj,M1My5N28vKaQ3E
def kDOJ3RNYFI(ssMt96muVHx,umJRt83OTfvgsBzNi2V5L,rQFZhiOgTx0IPAEmoYC8ntv):
	xJ8ojkFpBUbMPglDA0LT4H,umJRt83OTfvgsBzNi2V5L = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	b91u7sX8g32NWR,umJRt83OTfvgsBzNi2V5L = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	mDVLxtK2O0,umJRt83OTfvgsBzNi2V5L = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	vvHVNd0afGhekMqP84DAKg9YJ,umJRt83OTfvgsBzNi2V5L = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt = ssMt96muVHx,umJRt83OTfvgsBzNi2V5L
	count = len(rQFZhiOgTx0IPAEmoYC8ntv)
	for OeT2Jo0sp6h1mGdqfFw in range(count):
		try:
			RkLU63KnoA7fSxQ5EgBYpHis0wIj = eval(rQFZhiOgTx0IPAEmoYC8ntv[OeT2Jo0sp6h1mGdqfFw])
			return True,RkLU63KnoA7fSxQ5EgBYpHis0wIj,OeT2Jo0sp6h1mGdqfFw+1
		except: pass
	return False,'',0
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,LcnYtXvRpST3U='',data=''):
	MM6mFZQK1chIuPdAfLp,ANxeMF0DKh,hIJ6fsq1LV0ng4TG3lcbrj = [],[],[]
	if '::' not in LcnYtXvRpST3U: LcnYtXvRpST3U = '1::0::0::0'
	level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = LcnYtXvRpST3U.split('::')
	if level=='4': level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = '1',YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj
	data = data.replace('_REMEMBERRESULTS_','')
	QstumvzTIEUMXCcx06aD4y8nSqH,xJ8ojkFpBUbMPglDA0LT4H,BTMputsaqV = TBHlpjUZ35mnoC6(url,data)
	LcnYtXvRpST3U = level+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
	if level in ['1','2','3']:
		b91u7sX8g32NWR,qPcVJh2SmwzybQFLOB8NT,MM6mFZQK1chIuPdAfLp,KBuNUkq8CzR2f1hgF = sp1vMWbtHKfFG(xJ8ojkFpBUbMPglDA0LT4H,url,LcnYtXvRpST3U)
		if not qPcVJh2SmwzybQFLOB8NT: return
		Uk2PHe9VtRvqBow7WM5cL41xsDZuY = len(MM6mFZQK1chIuPdAfLp)
		if Uk2PHe9VtRvqBow7WM5cL41xsDZuY<2:
			if level=='1': level = '2'
			MM6mFZQK1chIuPdAfLp = []
	LcnYtXvRpST3U = level+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
	if level in ['2','3']:
		mDVLxtK2O0,y2Vm8lZriUtnHE7opRvhX,ANxeMF0DKh,EO38muZ47zHc5Lkd0JAXpF = rrxfoGUO2Kd(xJ8ojkFpBUbMPglDA0LT4H,b91u7sX8g32NWR,url,LcnYtXvRpST3U)
		if not y2Vm8lZriUtnHE7opRvhX: return
		aw04q9uSlR2gZ1TdAkBh = len(ANxeMF0DKh)
		if aw04q9uSlR2gZ1TdAkBh<2:
			if level=='2': level = '3'
			ANxeMF0DKh = []
	LcnYtXvRpST3U = level+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
	if level in ['3']:
		vvHVNd0afGhekMqP84DAKg9YJ,VKIWmgqSHLDcXp2helnt5v6wo7yCE,hIJ6fsq1LV0ng4TG3lcbrj,M1My5N28vKaQ3E = VVzCxrstNYwA49HG8anMbvSI2(xJ8ojkFpBUbMPglDA0LT4H,mDVLxtK2O0,url,LcnYtXvRpST3U)
		if not VKIWmgqSHLDcXp2helnt5v6wo7yCE: return
		Ez0rFvaBj2xGqAbQ = len(hIJ6fsq1LV0ng4TG3lcbrj)
	for q8BXZlN9sU1fP2JAxH7W,url,LcnYtXvRpST3U in MM6mFZQK1chIuPdAfLp+ANxeMF0DKh+hIJ6fsq1LV0ng4TG3lcbrj:
		RMAgiUJIDre4 = KxAIS18pWBYyF6bJCMw5PtL(q8BXZlN9sU1fP2JAxH7W,url,LcnYtXvRpST3U)
	return
def KxAIS18pWBYyF6bJCMw5PtL(q8BXZlN9sU1fP2JAxH7W,url='',LcnYtXvRpST3U=''):
	if '::' in LcnYtXvRpST3U: level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = LcnYtXvRpST3U.split('::')
	else: level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = '1','0','0','0'
	ybf3Qo7isaYVr,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc,aGUh8Pmrs4Ej32WYAkFoN9l1Jw0HDf = u3DhGNOAY0ZS71pitafPy4d(q8BXZlN9sU1fP2JAxH7W)
	ssBUod0JflaI3OMm = '/videos?' in RRucmYBaXegTtNOdGHMQ or '/streams?' in RRucmYBaXegTtNOdGHMQ or '/playlists?' in RRucmYBaXegTtNOdGHMQ
	pYduixISz1FNHCwfKWanQUbTZO = '/channels?' in RRucmYBaXegTtNOdGHMQ or '/shorts?' in RRucmYBaXegTtNOdGHMQ
	if ssBUod0JflaI3OMm or pYduixISz1FNHCwfKWanQUbTZO: RRucmYBaXegTtNOdGHMQ = url
	ssBUod0JflaI3OMm = 'watch?v=' not in RRucmYBaXegTtNOdGHMQ and '/playlist?list=' not in RRucmYBaXegTtNOdGHMQ
	pYduixISz1FNHCwfKWanQUbTZO = '/gaming' not in RRucmYBaXegTtNOdGHMQ  and '/feed/storefront' not in RRucmYBaXegTtNOdGHMQ
	if LcnYtXvRpST3U[0:5]=='3::0::' and ssBUod0JflaI3OMm and pYduixISz1FNHCwfKWanQUbTZO: RRucmYBaXegTtNOdGHMQ = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in RRucmYBaXegTtNOdGHMQ:
		level,YYaSjFAxlhtunNb1omd94,KTPWbDAHS2kxNcB0j7nIhJdMCZ,JYElAaxM0gZeH42WQi1cumj = '1','0','0','0'
		LcnYtXvRpST3U = ''
	BTMputsaqV = ''
	if '/youtubei/v1/browse' in RRucmYBaXegTtNOdGHMQ or '/youtubei/v1/search' in RRucmYBaXegTtNOdGHMQ or '/my_main_page_shorts_link' in url:
		data = j2agIU0xsLS6c7T.getSetting('av.youtube.data')
		if data.count(':::')==4:
			qv2xgQPCXsm3aWVSuYKTOwhy,key,WrKdzhw7QSCXGEA846t3fnvupj2Pe,N30U6gJYef1v,Yhqjz4bLa1HB = data.split(':::')
			BTMputsaqV = qv2xgQPCXsm3aWVSuYKTOwhy+':::'+key+':::'+WrKdzhw7QSCXGEA846t3fnvupj2Pe+':::'+N30U6gJYef1v+':::'+aGUh8Pmrs4Ej32WYAkFoN9l1Jw0HDf
			if '/my_main_page_shorts_link' in url and not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = url
			else: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?key='+key
	if not title:
		global kZSo0sOte7CXupBKWLx3YmEHFl
		kZSo0sOte7CXupBKWLx3YmEHFl += 1
		title = 'فيديوهات '+str(kZSo0sOte7CXupBKWLx3YmEHFl)
		LcnYtXvRpST3U = '3'+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
	if not ybf3Qo7isaYVr: return False
	elif 'searchPyvRenderer' in str(q8BXZlN9sU1fP2JAxH7W): return False
	elif '/about' in RRucmYBaXegTtNOdGHMQ: return False
	elif '/community' in RRucmYBaXegTtNOdGHMQ: return False
	elif 'continuationItemRenderer' in list(q8BXZlN9sU1fP2JAxH7W.keys()) or 'continuationCommand' in list(q8BXZlN9sU1fP2JAxH7W.keys()):
		if int(level)>1: level = str(int(level)-1)
		LcnYtXvRpST3U = level+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+':: '+'صفحة أخرى',RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U,BTMputsaqV)
	elif '/search' in RRucmYBaXegTtNOdGHMQ:
		title = ':: '+title
		LcnYtXvRpST3U = '3'+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
		url = url.replace('/search','')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,145,'',LcnYtXvRpST3U,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not RRucmYBaXegTtNOdGHMQ:
		LcnYtXvRpST3U = '3'+'::'+YYaSjFAxlhtunNb1omd94+'::'+KTPWbDAHS2kxNcB0j7nIhJdMCZ+'::'+JYElAaxM0gZeH42WQi1cumj
		title = ':: '+title
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U,BTMputsaqV)
	elif '/browse' in RRucmYBaXegTtNOdGHMQ and url==JJTrn6SEtYZV31eyR97:
		title = ':: '+title
		LcnYtXvRpST3U = '2::0::0::0'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U,BTMputsaqV)
	elif not RRucmYBaXegTtNOdGHMQ and 'horizontalMovieListRenderer' in str(q8BXZlN9sU1fP2JAxH7W):
		title = ':: '+title
		LcnYtXvRpST3U = '3::0::0::0'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U)
	elif 'messageRenderer' in str(q8BXZlN9sU1fP2JAxH7W):
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+title,'',9999)
	elif u4u1TsmL6PDz2jW:
		Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+u4u1TsmL6PDz2jW+title,RRucmYBaXegTtNOdGHMQ,143,CrGO63LT7j2UxniW)
	elif '/playlist?list=' in RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('&playnext=1','')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'LIST'+count+':  '+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U)
	elif '/shorts/' in RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('&list=',1)[0]
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,143,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB)
	elif '/watch?v=' in RRucmYBaXegTtNOdGHMQ:
		if '&list=' in RRucmYBaXegTtNOdGHMQ and count:
			zVi08rx2RYC6oXsTQHEdgPJeS = RRucmYBaXegTtNOdGHMQ.split('&list=',1)[1]
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/playlist?list='+zVi08rx2RYC6oXsTQHEdgPJeS
			LcnYtXvRpST3U = '3::0::0::0'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'LIST'+count+':  '+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U)
		else:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('&list=',1)[0]
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,143,CrGO63LT7j2UxniW,UombAD0Kk4XqOrYLB)
	elif '/channel/' in RRucmYBaXegTtNOdGHMQ or '/c/' in RRucmYBaXegTtNOdGHMQ or ('/@' in RRucmYBaXegTtNOdGHMQ and RRucmYBaXegTtNOdGHMQ.count('/')==3):
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'CHNL'+count+':  '+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U)
	elif '/user/' in RRucmYBaXegTtNOdGHMQ:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'USER'+count+':  '+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U)
	else:
		if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = url
		title = ':: '+title
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,144,CrGO63LT7j2UxniW,LcnYtXvRpST3U,BTMputsaqV)
	return True
def u3DhGNOAY0ZS71pitafPy4d(q8BXZlN9sU1fP2JAxH7W):
	ybf3Qo7isaYVr,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc,Yhqjz4bLa1HB = False,'','','','','','','',''
	if not isinstance(q8BXZlN9sU1fP2JAxH7W,dict): return ybf3Qo7isaYVr,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc,Yhqjz4bLa1HB
	for LNeYbBgv50 in list(q8BXZlN9sU1fP2JAxH7W.keys()):
		ZZigz4KOWQFho0qAM7sa6xt = q8BXZlN9sU1fP2JAxH7W[LNeYbBgv50]
		if isinstance(ZZigz4KOWQFho0qAM7sa6xt,dict): break
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['header']['richListHeaderRenderer']['title']")
	FF9E6MD1B8WA0NKG.append("yrender['headline']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['unplayableText']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['formattedTitle']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['title']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['title']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("yrender['text']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['text']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("yrender['title']")
	FF9E6MD1B8WA0NKG.append("item['title']")
	FF9E6MD1B8WA0NKG.append("item['reelWatchEndpoint']['videoId']")
	ybf3Qo7isaYVr,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	FF9E6MD1B8WA0NKG.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	FF9E6MD1B8WA0NKG.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	FF9E6MD1B8WA0NKG.append("item['commandMetadata']['webCommandMetadata']['url']")
	ybf3Qo7isaYVr,RRucmYBaXegTtNOdGHMQ,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("yrender['thumbnail']['thumbnails'][0]['url']")
	FF9E6MD1B8WA0NKG.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	FF9E6MD1B8WA0NKG.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	ybf3Qo7isaYVr,CrGO63LT7j2UxniW,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("yrender['videoCount']")
	FF9E6MD1B8WA0NKG.append("yrender['videoCountText']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	ybf3Qo7isaYVr,count,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	FF9E6MD1B8WA0NKG.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['lengthText']['simpleText']")
	FF9E6MD1B8WA0NKG.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	FF9E6MD1B8WA0NKG.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	ybf3Qo7isaYVr,UombAD0Kk4XqOrYLB,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt,FF9E6MD1B8WA0NKG)
	FF9E6MD1B8WA0NKG = []
	FF9E6MD1B8WA0NKG.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	FF9E6MD1B8WA0NKG.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	ybf3Qo7isaYVr,Yhqjz4bLa1HB,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = kDOJ3RNYFI(q8BXZlN9sU1fP2JAxH7W,ZZigz4KOWQFho0qAM7sa6xt,FF9E6MD1B8WA0NKG)
	if 'LIVE' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW = '','LIVE:  '
	if 'مباشر' in UombAD0Kk4XqOrYLB: UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW = '','LIVE:  '
	if 'badges' in list(ZZigz4KOWQFho0qAM7sa6xt.keys()):
		Gjw1Oko2AT6PItCHsWxYQuK9mV0an = str(ZZigz4KOWQFho0qAM7sa6xt['badges'])
		if 'Free with Ads' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$:  '
		if 'LIVE' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: u4u1TsmL6PDz2jW = 'LIVE:  '
		if 'Buy' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an or 'Rent' in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$$:  '
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'مباشر') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: u4u1TsmL6PDz2jW = 'LIVE:  '
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'شراء') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$$:  '
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'استئجار') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$$:  '
		if PPMg73d1CAKIZS2hvHc5pLmXt4Fsez(u'إعلانات') in Gjw1Oko2AT6PItCHsWxYQuK9mV0an: oUX2bhl8gK5TRZc = '$:  '
	RRucmYBaXegTtNOdGHMQ = WhJe7bGx5XackTwOIZVLC8ut(RRucmYBaXegTtNOdGHMQ)
	if RRucmYBaXegTtNOdGHMQ and 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
	CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.split('?')[0]
	if  CrGO63LT7j2UxniW and 'http' not in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = 'https:'+CrGO63LT7j2UxniW
	title = WhJe7bGx5XackTwOIZVLC8ut(title)
	if oUX2bhl8gK5TRZc: title = oUX2bhl8gK5TRZc+title
	UombAD0Kk4XqOrYLB = UombAD0Kk4XqOrYLB.replace(',','')
	count = count.replace(',','')
	count = ZXFs0mEPR8qI2zj.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,count,UombAD0Kk4XqOrYLB,u4u1TsmL6PDz2jW,oUX2bhl8gK5TRZc,Yhqjz4bLa1HB
def TBHlpjUZ35mnoC6(url,data='',l3UpyxrXZ2=''):
	if l3UpyxrXZ2=='': l3UpyxrXZ2 = 'ytInitialData'
	k0kUAjI76Erhgf = SjMG7CYyUqbPVso0DErhXROvkl()
	obS4TpHeV3digGC = {'User-Agent':k0kUAjI76Erhgf,'Cookie':'PREF=hl=ar'}
	global j2agIU0xsLS6c7T
	if not data: data = j2agIU0xsLS6c7T.getSetting('av.youtube.data')
	if data.count(':::')==4: qv2xgQPCXsm3aWVSuYKTOwhy,key,WrKdzhw7QSCXGEA846t3fnvupj2Pe,N30U6gJYef1v,Yhqjz4bLa1HB = data.split(':::')
	else: qv2xgQPCXsm3aWVSuYKTOwhy,key,WrKdzhw7QSCXGEA846t3fnvupj2Pe,N30U6gJYef1v,Yhqjz4bLa1HB = '','','','',''
	BTMputsaqV = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":WrKdzhw7QSCXGEA846t3fnvupj2Pe}}}
	if url==JJTrn6SEtYZV31eyR97+'/shorts' or '/my_main_page_shorts_link' in url:
		url = JJTrn6SEtYZV31eyR97+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		BTMputsaqV['sequenceParams'] = qv2xgQPCXsm3aWVSuYKTOwhy
		BTMputsaqV = str(BTMputsaqV)
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',url,BTMputsaqV,obS4TpHeV3digGC,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = JJTrn6SEtYZV31eyR97+'/youtubei/v1/guide?key='+key
		BTMputsaqV = str(BTMputsaqV)
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',url,BTMputsaqV,obS4TpHeV3digGC,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and qv2xgQPCXsm3aWVSuYKTOwhy:
		BTMputsaqV['continuation'] = Yhqjz4bLa1HB
		BTMputsaqV['context']['client']['visitorData'] = qv2xgQPCXsm3aWVSuYKTOwhy
		BTMputsaqV = str(BTMputsaqV)
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',url,BTMputsaqV,obS4TpHeV3digGC,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and N30U6gJYef1v:
		obS4TpHeV3digGC.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':WrKdzhw7QSCXGEA846t3fnvupj2Pe})
		obS4TpHeV3digGC.update({'Cookie':'VISITOR_INFO1_LIVE='+N30U6gJYef1v})
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'',obS4TpHeV3digGC,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'',obS4TpHeV3digGC,'','','YOUTUBE-GET_PAGE_DATA-6th')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall('"innertubeApiKey".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if p3pw6HeVfqXcFnT: key = p3pw6HeVfqXcFnT[0]
	p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall('"cver".*?"value".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if p3pw6HeVfqXcFnT: WrKdzhw7QSCXGEA846t3fnvupj2Pe = p3pw6HeVfqXcFnT[0]
	p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall('"visitorData".*?"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.I)
	if p3pw6HeVfqXcFnT: qv2xgQPCXsm3aWVSuYKTOwhy = p3pw6HeVfqXcFnT[0]
	cookies = wpFmEA3z8JR.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): N30U6gJYef1v = cookies['VISITOR_INFO1_LIVE']
	hJl76MdBq9eF = qv2xgQPCXsm3aWVSuYKTOwhy+':::'+key+':::'+WrKdzhw7QSCXGEA846t3fnvupj2Pe+':::'+N30U6gJYef1v+':::'+Yhqjz4bLa1HB
	if l3UpyxrXZ2=='ytInitialData' and 'ytInitialData' in QstumvzTIEUMXCcx06aD4y8nSqH:
		O0XS7Kx1Hic3nr6eCNl = ZXFs0mEPR8qI2zj.findall('window\["ytInitialData"\] = ({.*?});',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not O0XS7Kx1Hic3nr6eCNl: O0XS7Kx1Hic3nr6eCNl = ZXFs0mEPR8qI2zj.findall('var ytInitialData = ({.*?});',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		NUKL7j2lO3kAWIZhormG19Qgc0b = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',O0XS7Kx1Hic3nr6eCNl[0])
	elif l3UpyxrXZ2=='ytInitialGuideData' and 'ytInitialGuideData' in QstumvzTIEUMXCcx06aD4y8nSqH:
		O0XS7Kx1Hic3nr6eCNl = ZXFs0mEPR8qI2zj.findall('var ytInitialGuideData = ({.*?});',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		NUKL7j2lO3kAWIZhormG19Qgc0b = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',O0XS7Kx1Hic3nr6eCNl[0])
	elif '</script>' not in QstumvzTIEUMXCcx06aD4y8nSqH: NUKL7j2lO3kAWIZhormG19Qgc0b = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',QstumvzTIEUMXCcx06aD4y8nSqH)
	else: NUKL7j2lO3kAWIZhormG19Qgc0b = ''
	if 0:
		xJ8ojkFpBUbMPglDA0LT4H = str(NUKL7j2lO3kAWIZhormG19Qgc0b)
		if VYMZsxRpcQHPgkaiDKjyoh: xJ8ojkFpBUbMPglDA0LT4H = xJ8ojkFpBUbMPglDA0LT4H.encode('utf8')
		open('S:\\0000emad.dat','wb').write(xJ8ojkFpBUbMPglDA0LT4H)
	j2agIU0xsLS6c7T.setSetting('av.youtube.data',hJl76MdBq9eF)
	return QstumvzTIEUMXCcx06aD4y8nSqH,NUKL7j2lO3kAWIZhormG19Qgc0b,hJl76MdBq9eF
def P7Z0G9vzMOlnidteTSwVsQCa6Ah3xp(url,LcnYtXvRpST3U):
	search = CjyEnpfQ23o0PYwDtLId()
	if not search: return
	search = search.replace(' ','+')
	lQHXdV9Nzf6BLqS8D = url+'/search?query='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D,LcnYtXvRpST3U)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search:
		search = CjyEnpfQ23o0PYwDtLId()
		if not search: return
	search = search.replace(' ','+')
	lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jvaS5uPA9R3nM17Nhics2fZOo = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jvaS5uPA9R3nM17Nhics2fZOo = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in Y9RKmgsxBefkFcuIj2GULDHy3: jvaS5uPA9R3nM17Nhics2fZOo = '&sp=EgIQAg%253D%253D'
		else: jvaS5uPA9R3nM17Nhics2fZOo = ''
		aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D+jvaS5uPA9R3nM17Nhics2fZOo
	else:
		RDG7CIKNsFj5XAcJl,lf3ekTjGuH7CVKA0X5nsi4,Wu4CadwRTJfkbXMUVxO3jQ2 = [],[],''
		X8IawbrEisGK = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		sVlFA6dw9qu3PRD2K0r = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		L7lUEM8KHDxzu = F2yZPukcUh09sqCI8nYw7e('موقع يوتيوب - اختر الترتيب',X8IawbrEisGK)
		if L7lUEM8KHDxzu == -1: return
		ZIA3hMQqbiDnCHgNUtOFLmVs1T = sVlFA6dw9qu3PRD2K0r[L7lUEM8KHDxzu]
		QstumvzTIEUMXCcx06aD4y8nSqH,i3huRfgNCQ0DszZV4bp8PlELqyv,data = TBHlpjUZ35mnoC6(lQHXdV9Nzf6BLqS8D+ZIA3hMQqbiDnCHgNUtOFLmVs1T)
		if i3huRfgNCQ0DszZV4bp8PlELqyv:
			try:
				Xt7HVfQSuR2aCM8YsLNoZp4db6K = i3huRfgNCQ0DszZV4bp8PlELqyv['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for EEpvM1LZJzd039gONoKrWweRkQD4 in range(len(Xt7HVfQSuR2aCM8YsLNoZp4db6K)):
					group = Xt7HVfQSuR2aCM8YsLNoZp4db6K[EEpvM1LZJzd039gONoKrWweRkQD4]['searchFilterGroupRenderer']['filters']
					for JRSGAxBO58a1cHdsIXPmY in range(len(group)):
						ZZigz4KOWQFho0qAM7sa6xt = group[JRSGAxBO58a1cHdsIXPmY]['searchFilterRenderer']
						if 'navigationEndpoint' in list(ZZigz4KOWQFho0qAM7sa6xt.keys()):
							RRucmYBaXegTtNOdGHMQ = ZZigz4KOWQFho0qAM7sa6xt['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\u0026','&')
							title = ZZigz4KOWQFho0qAM7sa6xt['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								Wu4CadwRTJfkbXMUVxO3jQ2 = title
								oKqQr8Ij0btxZ9SDm6h3Nd = RRucmYBaXegTtNOdGHMQ
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								Wu4CadwRTJfkbXMUVxO3jQ2 = title
								oKqQr8Ij0btxZ9SDm6h3Nd = RRucmYBaXegTtNOdGHMQ
							if 'Sort by' in title: continue
							RDG7CIKNsFj5XAcJl.append(WhJe7bGx5XackTwOIZVLC8ut(title))
							lf3ekTjGuH7CVKA0X5nsi4.append(RRucmYBaXegTtNOdGHMQ)
			except: pass
		if not Wu4CadwRTJfkbXMUVxO3jQ2: ha9BNgzAdunWcq0 = ''
		else:
			RDG7CIKNsFj5XAcJl = ['بدون فلتر',Wu4CadwRTJfkbXMUVxO3jQ2]+RDG7CIKNsFj5XAcJl
			lf3ekTjGuH7CVKA0X5nsi4 = ['',oKqQr8Ij0btxZ9SDm6h3Nd]+lf3ekTjGuH7CVKA0X5nsi4
			oKMLiWJOzgrl9xw5vD73d8UV = F2yZPukcUh09sqCI8nYw7e('موقع يوتيوب - اختر الفلتر',RDG7CIKNsFj5XAcJl)
			if oKMLiWJOzgrl9xw5vD73d8UV == -1: return
			ha9BNgzAdunWcq0 = lf3ekTjGuH7CVKA0X5nsi4[oKMLiWJOzgrl9xw5vD73d8UV]
		if ha9BNgzAdunWcq0: aaIn3XlQKJ6zSfkmjuCyM = JJTrn6SEtYZV31eyR97+ha9BNgzAdunWcq0
		elif ZIA3hMQqbiDnCHgNUtOFLmVs1T: aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D+ZIA3hMQqbiDnCHgNUtOFLmVs1T
		else: aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D
	RxAy5lEFQ1chv0BrdU4p6Pt2(aaIn3XlQKJ6zSfkmjuCyM)
	return
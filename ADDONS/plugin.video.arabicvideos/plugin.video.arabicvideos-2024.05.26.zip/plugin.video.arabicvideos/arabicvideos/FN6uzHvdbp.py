# -*- coding: utf-8 -*-
from j3x780FpaM import *
headers = { 'User-Agent' : '' }
ll6f2wvU4FdqL3MJyDxORESCK197i = 'AKWAM'
W74fAyGxODoLPs5vMX2l8C93R = '_AKW_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
y9YktIwab5dZHC3xD8eJU1KsFAqj = ''
SmgoEYJ7uyL = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==240: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==241: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==242: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==243: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==244: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FILTERS___'+text)
	elif mode==245: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'CATEGORIES___'+text)
	elif mode==246: HkKfQCS7RIa4xi3houjvl = UUprLCclRFPe53Snu2qZEYGkfj(url)
	elif mode==247: HkKfQCS7RIa4xi3houjvl = jXF0fB4GeQa(url)
	elif mode==248: HkKfQCS7RIa4xi3houjvl = U3GXaL1c84l9hyOIRp20fAqQ6()
	elif mode==249: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def U3GXaL1c84l9hyOIRp20fAqQ6():
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'',headers,'','','AKWAM-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	ooUTuZP6jxOIVsw = ZXFs0mEPR8qI2zj.findall('home-site-btn-container.*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if ooUTuZP6jxOIVsw: ooUTuZP6jxOIVsw = ooUTuZP6jxOIVsw[0]
	else: ooUTuZP6jxOIVsw = JJTrn6SEtYZV31eyR97
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',ooUTuZP6jxOIVsw,'',headers,'','','AKWAM-MENU-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',249,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',JJTrn6SEtYZV31eyR97,246)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',JJTrn6SEtYZV31eyR97,247)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المميزة',ooUTuZP6jxOIVsw,241,'','','featured')
	recent = ZXFs0mEPR8qI2zj.findall('recently-container.*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	RRucmYBaXegTtNOdGHMQ = recent[0]
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أضيف حديثا',RRucmYBaXegTtNOdGHMQ,241)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,name,bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
		if name in SmgoEYJ7uyL: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+name,RRucmYBaXegTtNOdGHMQ,241)
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title in SmgoEYJ7uyL: continue
			title = name+' '+title
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,241)
	return
def UUprLCclRFPe53Snu2qZEYGkfj(website=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','AKWAM-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="menu(.*?)<nav',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?text">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title not in SmgoEYJ7uyL:
				title = title+' مصنفة'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,245)
		if website=='': Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def jXF0fB4GeQa(website=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','AKWAM-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="menu(.*?)<nav',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?text">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title not in SmgoEYJ7uyL:
				title = title+' مفلترة'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,244)
		if website=='': Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,True,'AKWAM-TITLES-1st')
	if type=='featured': IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('swiper-container(.*?)swiper-button-prev',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="widget"(.*?)main-footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if not items:
			items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
			if '/series/' in RRucmYBaXegTtNOdGHMQ or '/shows/' in RRucmYBaXegTtNOdGHMQ:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,242,CrGO63LT7j2UxniW)
			elif '/movies/' in RRucmYBaXegTtNOdGHMQ:
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,243,CrGO63LT7j2UxniW)
			elif '/games/' not in RRucmYBaXegTtNOdGHMQ:
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,243,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,241)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','%20')
	url = JJTrn6SEtYZV31eyR97 + '/search?q='+H9IMP4eTVW8dji3EXnS7w
	HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in QstumvzTIEUMXCcx06aD4y8nSqH:
		CrGO63LT7j2UxniW = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Icon')
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+'رابط التشغيل',url,243,CrGO63LT7j2UxniW)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('-episodes">(.*?)<div class="widget-4',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		xvWJR3VCAcyLZ = ZXFs0mEPR8qI2zj.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in xvWJR3VCAcyLZ:
			title = title.replace('  ',' ')
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,242,CrGO63LT7j2UxniW)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,243,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'',headers,True,'AKWAM-PLAY-1st')
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('badge-danger.*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	YdIJ2BMWuebmqg5DNsZE = ZXFs0mEPR8qI2zj.findall('li><a href="#(.*?)".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI,n5nyDgxTuHbY0LNV4cWvoBtp,MILbuyp7Vr6ws9 = [],[],[],[]
	if YdIJ2BMWuebmqg5DNsZE:
		P1ajYzT8sKCx6tMl = 'mp4'
		for cOMy1A2uveIp978LxZ,PHUqTNVJ0ErRSwibn5gD in YdIJ2BMWuebmqg5DNsZE:
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('tab-content quality" id="'+cOMy1A2uveIp978LxZ+'".*?</div>.\s*</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			n5nyDgxTuHbY0LNV4cWvoBtp.append(bdq4e6Wr2gslnSiA38)
			MILbuyp7Vr6ws9.append(PHUqTNVJ0ErRSwibn5gD)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="qualities(.*?)<h3.*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			bdq4e6Wr2gslnSiA38,filename = IZGcQbePXxwAoyYR1n[0]
			bOwSnuzelp = ['zip','rar','txt','pdf','htm','tar','iso','html']
			P1ajYzT8sKCx6tMl = filename.rsplit('.',1)[1].strip(' ')
			if P1ajYzT8sKCx6tMl in bOwSnuzelp:
				HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		n5nyDgxTuHbY0LNV4cWvoBtp.append(bdq4e6Wr2gslnSiA38)
		MILbuyp7Vr6ws9.append('')
	for xxFhvt275i8MdUVuPkSXzmbT in range(len(n5nyDgxTuHbY0LNV4cWvoBtp)):
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?icon-(.*?)"',n5nyDgxTuHbY0LNV4cWvoBtp[xxFhvt275i8MdUVuPkSXzmbT],ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,iNS3KFQUud4ksHrCA1JyE7Lb in R28S4pFmAojEW7CGnx:
			if 'torrent' in iNS3KFQUud4ksHrCA1JyE7Lb: continue
			elif 'download' in iNS3KFQUud4ksHrCA1JyE7Lb: type = 'download'
			elif 'play' in iNS3KFQUud4ksHrCA1JyE7Lb: type = 'watch'
			else: type = 'unknown'
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named=__'+type+'____'+MILbuyp7Vr6ws9[xxFhvt275i8MdUVuPkSXzmbT]+'__akwam'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	E0tDmCreab3BWYTcdIupkU46v = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='CATEGORIES':
		if E0tDmCreab3BWYTcdIupkU46v[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(E0tDmCreab3BWYTcdIupkU46v[0:-1])):
			if E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'all')
		lQHXdV9Nzf6BLqS8D = url+'?'+KMUEN9cD1OByji
	elif type=='FILTERS':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'all')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها',lQHXdV9Nzf6BLqS8D,241,'','1')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',lQHXdV9Nzf6BLqS8D,241,'','1')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'',headers,True,'AKWAM-FILTERS_MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<form id(.*?)</form>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	dict = {}
	for Lm4n6ZMXPrWpo,name,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		items = ZXFs0mEPR8qI2zj.findall('<option(.*?)>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='CATEGORIES':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<=1:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'CATEGORIES___'+tt6AbxYRgQ3aC4O)
				return
			else:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,241,'','1')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,245,'','',tt6AbxYRgQ3aC4O)
		elif type=='FILTERS':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع : '+name,lQHXdV9Nzf6BLqS8D,244,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			if 'value' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = Z7ZzgCTMBsNlVi9
			else: AARNPWHjQU9dEmDI = ZXFs0mEPR8qI2zj.findall('"(.*?)"',AARNPWHjQU9dEmDI,ZXFs0mEPR8qI2zj.DOTALL)[0]
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' : '#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' : '+name
			if type=='FILTERS': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,244,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='CATEGORIES' and E0tDmCreab3BWYTcdIupkU46v[-2]+'=' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'all')
				aaIn3XlQKJ6zSfkmjuCyM = url+'?'+KMUEN9cD1OByji
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,241,'','1')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,245,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	t1tvAd5EPXM = ['section','category','rating','year','language','formats','quality']
	for key in t1tvAd5EPXM:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	return rXLaWluDjvi4xMwpOSF91JB7
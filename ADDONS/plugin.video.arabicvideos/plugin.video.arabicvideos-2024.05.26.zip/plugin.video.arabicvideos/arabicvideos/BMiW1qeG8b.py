# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'CIMAABDO'
W74fAyGxODoLPs5vMX2l8C93R = '_ABD_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['الرئيسية']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==550: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==551: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==552: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==553: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==559: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97+'/home','','','','','CIMAABDO-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(JJTrn6SEtYZV31eyR97,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',559,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'اخترنا لك',pp5vX2CWHBtwOPzdq0Junij7+'/home',551,'','','featured')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-content(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('data-name="(.*?)".*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for qzTpS3aBcFGiM,title in items:
		RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/ajax/getItem?item='+qzTpS3aBcFGiM+'&Ajax=1'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,551)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"nav-main"(.*?)</nav>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if RRucmYBaXegTtNOdGHMQ=='#': continue
		if title in SmgoEYJ7uyL: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,551)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if RRucmYBaXegTtNOdGHMQ=='#': continue
		if title in SmgoEYJ7uyL: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,551)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,qzTpS3aBcFGiM=''):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
		obS4TpHeV3digGC = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,'','','CIMAABDO-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH]
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMAABDO-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		if qzTpS3aBcFGiM=='featured':
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"container"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		elif '"section-post mb-10"' in QstumvzTIEUMXCcx06aD4y8nSqH:
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"section-post mb-10"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		else:
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<article(.*?)"pagination"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not items:
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if not items: items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if 'سلاسل' not in url and any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,552,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and 'الحلقة' in title:
			title = '_MOD_' + LqYKJ36CBG[0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,553,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/movies/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,551,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,553,CrGO63LT7j2UxniW)
	if qzTpS3aBcFGiM=='':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)<footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if RRucmYBaXegTtNOdGHMQ=="": continue
				if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'هناك المزيد',url,551)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMAABDO-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"getSeasonsBySeries(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"list-episodes"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Wgapb9wyGrVHo0 and '/series/' not in url:
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,553,CrGO63LT7j2UxniW)
	elif CCqaV18lM0OL:
		CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('"image" src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0]
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,552,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	aaIn3XlQKJ6zSfkmjuCyM = url.replace('/movies/','/watch_movies/')
	aaIn3XlQKJ6zSfkmjuCyM = aaIn3XlQKJ6zSfkmjuCyM.replace('/episodes/','/watch_episodes/')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',aaIn3XlQKJ6zSfkmjuCyM,'','','','','CIMAABDO-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(aaIn3XlQKJ6zSfkmjuCyM,'url')
	yf608hE5KeRG1DscunvrU = []
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('''<iframe.*?src=["'](.*?)["']''',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]
		NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'url')
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__embed')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"servers"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		mnt96JHiPpI = ZXFs0mEPR8qI2zj.findall('postID = "(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		mnt96JHiPpI = mnt96JHiPpI[0]
		items = ZXFs0mEPR8qI2zj.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if items:
			for NGmuWwXdLQ6nMltx39FYECohJ,title in items:
				title = title.replace('\n','').strip(' ')
				RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/ajax/getPlayer?server='+NGmuWwXdLQ6nMltx39FYECohJ+'&postID='+mnt96JHiPpI+'&Ajax=1'
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
		else:
			items = ZXFs0mEPR8qI2zj.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if items:
				NGmuWwXdLQ6nMltx39FYECohJ,MnliqKuY76zLOR8ZtgojsmWke,title = items[0]
				RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/ajax/getPlayerByName?server='+NGmuWwXdLQ6nMltx39FYECohJ+'&multipleServers='+MnliqKuY76zLOR8ZtgojsmWke+'&postID='+mnt96JHiPpI+'&Ajax=1'
				lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(RRucmYBaXegTtNOdGHMQ)
				obS4TpHeV3digGC = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,'','','CIMAABDO-PLAY-2nd')
				QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
				RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall('''<iframe src=["'](.*?)["']''',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
				oKqQr8Ij0btxZ9SDm6h3Nd = RRr48IPQSLEdunNcgGUhJozkY[0] if RRr48IPQSLEdunNcgGUhJozkY else ''
				if '/iframe/' in oKqQr8Ij0btxZ9SDm6h3Nd:
					wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',oKqQr8Ij0btxZ9SDm6h3Nd,'','','','','CIMAABDO-PLAY-3rd')
					QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
					fnqj91p8DHIoXbhmYJ4siTwS0Gr = ZXFs0mEPR8qI2zj.findall('version&quot;:&quot;(.*?)&',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
					fnqj91p8DHIoXbhmYJ4siTwS0Gr = fnqj91p8DHIoXbhmYJ4siTwS0Gr[0]
					obS4TpHeV3digGC = {}
					obS4TpHeV3digGC['X-Inertia-Partial-Component'] = 'files/mirror/video'
					obS4TpHeV3digGC['X-Inertia'] = 'true'
					obS4TpHeV3digGC['X-Inertia-Partial-Data'] = 'streams'
					obS4TpHeV3digGC['X-Inertia-Version'] = fnqj91p8DHIoXbhmYJ4siTwS0Gr
					wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',oKqQr8Ij0btxZ9SDm6h3Nd,'',obS4TpHeV3digGC,'','','CIMAABDO-PLAY-4th')
					QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
					fnPzKkthNYb5LTWDCGdgyVqX = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',QstumvzTIEUMXCcx06aD4y8nSqH)
					groups = fnPzKkthNYb5LTWDCGdgyVqX['props']['streams']['data']
					for group in groups:
						PHUqTNVJ0ErRSwibn5gD = group['label'].replace(' (source)','')
						BPYhoNW82sSz15m6 = group['mirrors']
						for DD6Z3bOIJRrqzjSHLCksGmnhMw in BPYhoNW82sSz15m6:
							NGmuWwXdLQ6nMltx39FYECohJ = DD6Z3bOIJRrqzjSHLCksGmnhMw['driver']
							RRucmYBaXegTtNOdGHMQ = 'http:'+DD6Z3bOIJRrqzjSHLCksGmnhMw['link']+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__watch____'+PHUqTNVJ0ErRSwibn5gD
							yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"downs"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download'
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','-')
	url = JJTrn6SEtYZV31eyR97+'/search/'+search+'.html'
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
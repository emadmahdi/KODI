# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'KATKOTTV'
W74fAyGxODoLPs5vMX2l8C93R = '_KTV_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = []
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==810: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==811: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==812: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==813: HkKfQCS7RIa4xi3houjvl = ZZ8Stq1IfWp7BHAQePTKy0JVFc(url)
	elif mode==819: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','KATKOTTV-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"primary-links"(.*?)"most-viewed"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,811)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"home-content"(.*?)"footer"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		FF1TYf6O5KENr8R72LUVievClmudxD = []
		for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|حلقة).\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if 'episodes' not in type and LqYKJ36CBG:
				title = '_MOD_' + LqYKJ36CBG[0][0]
				title = title.replace('اون لاين','')
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,813,CrGO63LT7j2UxniW)
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,812,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("'pagination'(.*?)footer",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = qpob7TvxHSs4fEzO6(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,811,'','',type)
	return
def ZZ8Stq1IfWp7BHAQePTKy0JVFc(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('"category".*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ: RxAy5lEFQ1chv0BrdU4p6Pt2(RRucmYBaXegTtNOdGHMQ[0],'episodes')
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	yf608hE5KeRG1DscunvrU = []
	lQHXdV9Nzf6BLqS8D = url+'?do=watch'
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','KATKOTTV-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('" src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		yVEAeqBJpG = ZXFs0mEPR8qI2zj.findall('post=(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if yVEAeqBJpG:
			yVEAeqBJpG = EGTVgQoSu6ZsD.b64decode(yVEAeqBJpG[0])
			if VYMZsxRpcQHPgkaiDKjyoh: yVEAeqBJpG = yVEAeqBJpG.decode('utf8')
			yVEAeqBJpG = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',yVEAeqBJpG)
			R28S4pFmAojEW7CGnx = yVEAeqBJpG['servers']
			mwXy4HaY1uWtlvbZVcN7 = list(R28S4pFmAojEW7CGnx.keys())
			R28S4pFmAojEW7CGnx = list(R28S4pFmAojEW7CGnx.values())
			xPDZRXulfK5CvcTz0gbV = zip(mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx)
			for title,RRucmYBaXegTtNOdGHMQ in xPDZRXulfK5CvcTz0gbV:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
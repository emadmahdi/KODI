# -*- coding: utf-8 -*-
from j3x780FpaM import *
LBtjHDg8yZz69QOp = 'FAVORITES'
def EXgQe7mIMsxD8kcOZ(nnPsf4XLIJ7RWF,ookOLrZNMj):
	if   nnPsf4XLIJ7RWF==270: RqIMxSdNAFb7P = rUedtQkCXJq(ookOLrZNMj)
	else: RqIMxSdNAFb7P = False
	return RqIMxSdNAFb7P
def hhUnvQ52jmRlVGxcyeK38NagAFI(dGlmU8JqW5yFAtcsg,ookOLrZNMj,viTe6LDbs7H):
	if not dGlmU8JqW5yFAtcsg: return
	if   viTe6LDbs7H=='UP1'	: XXzrFlnpkdOyGsJSfoN(ookOLrZNMj,True,1)
	elif viTe6LDbs7H=='DOWN1'	: XXzrFlnpkdOyGsJSfoN(ookOLrZNMj,False,1)
	elif viTe6LDbs7H=='UP4'	: XXzrFlnpkdOyGsJSfoN(ookOLrZNMj,True,4)
	elif viTe6LDbs7H=='DOWN4'	: XXzrFlnpkdOyGsJSfoN(ookOLrZNMj,False,4)
	elif viTe6LDbs7H=='ADD1'	: Acr3IjwMoqUl5WZSB9XsEGhVv4Pfa(ookOLrZNMj)
	elif viTe6LDbs7H=='REMOVE1': HHMnLhqYJo2xFiuNk5Dj(ookOLrZNMj)
	elif viTe6LDbs7H=='DELETELIST': hgn8uZU4Tm(ookOLrZNMj)
	return
def rUedtQkCXJq(ookOLrZNMj):
	ADC1HYnMN2xh7E3 = M83nAibIqYrhcdPvJl1aQExy()
	if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()):
		try:
			AQ36v8wUCVc4m = ADC1HYnMN2xh7E3[ookOLrZNMj]
			for RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo in AQ36v8wUCVc4m:
				Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo)
		except:
			ADC1HYnMN2xh7E3 = KJM5ELV47wTIWg(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql)
			AQ36v8wUCVc4m = ADC1HYnMN2xh7E3[ookOLrZNMj]
			for RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo in AQ36v8wUCVc4m:
				Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo)
	return
def Acr3IjwMoqUl5WZSB9XsEGhVv4Pfa(ookOLrZNMj):
	RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = q0tgURwzEOJIYc27DbG4aT(VPIEsaiROZwmp20Jdn8WrA7c3Y)
	llKa01dWnLzDMg = RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,'',WtmwkIxcKOZ3rB6PuSHCFL5vGqVo
	ADC1HYnMN2xh7E3 = M83nAibIqYrhcdPvJl1aQExy()
	X48Wm5UscuZK = {}
	for yJd6FCpefPw8Ksqo5 in list(ADC1HYnMN2xh7E3.keys()):
		if yJd6FCpefPw8Ksqo5!=ookOLrZNMj: X48Wm5UscuZK[yJd6FCpefPw8Ksqo5] = ADC1HYnMN2xh7E3[yJd6FCpefPw8Ksqo5]
		else:
			if aaYDh2EzJ5ky and aaYDh2EzJ5ky!='..':
				mk4Dnt7QrGyPjJFL3Z2v = ADC1HYnMN2xh7E3[yJd6FCpefPw8Ksqo5]
				if llKa01dWnLzDMg in mk4Dnt7QrGyPjJFL3Z2v:
					eesUxS9Pg8WJZyhR34kdj7OfGz = mk4Dnt7QrGyPjJFL3Z2v.index(llKa01dWnLzDMg)
					del mk4Dnt7QrGyPjJFL3Z2v[eesUxS9Pg8WJZyhR34kdj7OfGz]
				eQXqjbL3fTgMku91h2Ht5w = mk4Dnt7QrGyPjJFL3Z2v+[llKa01dWnLzDMg]
				X48Wm5UscuZK[yJd6FCpefPw8Ksqo5] = eQXqjbL3fTgMku91h2Ht5w
			else: X48Wm5UscuZK[yJd6FCpefPw8Ksqo5] = ADC1HYnMN2xh7E3[yJd6FCpefPw8Ksqo5]
	if ookOLrZNMj not in list(X48Wm5UscuZK.keys()): X48Wm5UscuZK[ookOLrZNMj] = [llKa01dWnLzDMg]
	BAh5jscKE4rYZLa0tfkbJC = str(X48Wm5UscuZK)
	if VYMZsxRpcQHPgkaiDKjyoh: BAh5jscKE4rYZLa0tfkbJC = BAh5jscKE4rYZLa0tfkbJC.encode('utf8')
	open(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql,'wb').write(BAh5jscKE4rYZLa0tfkbJC)
	return
def HHMnLhqYJo2xFiuNk5Dj(ookOLrZNMj):
	RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = q0tgURwzEOJIYc27DbG4aT(VPIEsaiROZwmp20Jdn8WrA7c3Y)
	llKa01dWnLzDMg = RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,'',WtmwkIxcKOZ3rB6PuSHCFL5vGqVo
	ADC1HYnMN2xh7E3 = M83nAibIqYrhcdPvJl1aQExy()
	if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()) and llKa01dWnLzDMg in ADC1HYnMN2xh7E3[ookOLrZNMj]:
		ADC1HYnMN2xh7E3[ookOLrZNMj].remove(llKa01dWnLzDMg)
		if len(ADC1HYnMN2xh7E3[ookOLrZNMj])==0: del ADC1HYnMN2xh7E3[ookOLrZNMj]
		BAh5jscKE4rYZLa0tfkbJC = str(ADC1HYnMN2xh7E3)
		if VYMZsxRpcQHPgkaiDKjyoh: BAh5jscKE4rYZLa0tfkbJC = BAh5jscKE4rYZLa0tfkbJC.encode('utf8')
		open(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql,'wb').write(BAh5jscKE4rYZLa0tfkbJC)
	return
def XXzrFlnpkdOyGsJSfoN(ookOLrZNMj,PYLrMEC7nGOWIRNauVDQdqiAFsKoH,XZbMv7FO0yRHIPntg):
	RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = q0tgURwzEOJIYc27DbG4aT(VPIEsaiROZwmp20Jdn8WrA7c3Y)
	llKa01dWnLzDMg = RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,'',WtmwkIxcKOZ3rB6PuSHCFL5vGqVo
	ADC1HYnMN2xh7E3 = M83nAibIqYrhcdPvJl1aQExy()
	if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()):
		mk4Dnt7QrGyPjJFL3Z2v = ADC1HYnMN2xh7E3[ookOLrZNMj]
		if llKa01dWnLzDMg not in mk4Dnt7QrGyPjJFL3Z2v: return
		BiTmIq4QuGXHdOfwD9r = len(mk4Dnt7QrGyPjJFL3Z2v)
		for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(0,XZbMv7FO0yRHIPntg):
			qqRjzGTn1FuSOwBoCVU = mk4Dnt7QrGyPjJFL3Z2v.index(llKa01dWnLzDMg)
			if PYLrMEC7nGOWIRNauVDQdqiAFsKoH: VcD0u76aQHwLzp5fNXS8G = qqRjzGTn1FuSOwBoCVU-1
			else: VcD0u76aQHwLzp5fNXS8G = qqRjzGTn1FuSOwBoCVU+1
			if VcD0u76aQHwLzp5fNXS8G>=BiTmIq4QuGXHdOfwD9r: VcD0u76aQHwLzp5fNXS8G = VcD0u76aQHwLzp5fNXS8G-BiTmIq4QuGXHdOfwD9r
			if VcD0u76aQHwLzp5fNXS8G<0: VcD0u76aQHwLzp5fNXS8G = VcD0u76aQHwLzp5fNXS8G+BiTmIq4QuGXHdOfwD9r
			mk4Dnt7QrGyPjJFL3Z2v.insert(VcD0u76aQHwLzp5fNXS8G, mk4Dnt7QrGyPjJFL3Z2v.pop(qqRjzGTn1FuSOwBoCVU))
		ADC1HYnMN2xh7E3[ookOLrZNMj] = mk4Dnt7QrGyPjJFL3Z2v
		BAh5jscKE4rYZLa0tfkbJC = str(ADC1HYnMN2xh7E3)
		if VYMZsxRpcQHPgkaiDKjyoh: BAh5jscKE4rYZLa0tfkbJC = BAh5jscKE4rYZLa0tfkbJC.encode('utf8')
		open(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql,'wb').write(BAh5jscKE4rYZLa0tfkbJC)
	return
def hgn8uZU4Tm(ookOLrZNMj):
	Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+ookOLrZNMj+' ؟!')
	if Bkab1Avo3fYG9s6lZcOITDXd4MFi!=1: return
	ADC1HYnMN2xh7E3 = M83nAibIqYrhcdPvJl1aQExy()
	if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()):
		del ADC1HYnMN2xh7E3[ookOLrZNMj]
		BAh5jscKE4rYZLa0tfkbJC = str(ADC1HYnMN2xh7E3)
		if VYMZsxRpcQHPgkaiDKjyoh: BAh5jscKE4rYZLa0tfkbJC = BAh5jscKE4rYZLa0tfkbJC.encode('utf8')
		open(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql,'wb').write(BAh5jscKE4rYZLa0tfkbJC)
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+ookOLrZNMj)
	return
def M83nAibIqYrhcdPvJl1aQExy():
	ADC1HYnMN2xh7E3 = {}
	if hhHq8m5vauKG9dl.path.exists(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql):
		llEWB4KhqNV5HuUogGZzcP9OTs0e = open(P71CANTSyWYptGs8JnZkUHu3Kwi6Ql,'rb').read()
		if VYMZsxRpcQHPgkaiDKjyoh: llEWB4KhqNV5HuUogGZzcP9OTs0e = llEWB4KhqNV5HuUogGZzcP9OTs0e.decode('utf8')
		ADC1HYnMN2xh7E3 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',llEWB4KhqNV5HuUogGZzcP9OTs0e)
	return ADC1HYnMN2xh7E3
def uwtI7SKjfJZYHzi5slFOebhc21qx(ADC1HYnMN2xh7E3,llKa01dWnLzDMg,E02Knb1UeQzLYtc6):
	RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = llKa01dWnLzDMg
	if not nnPsf4XLIJ7RWF: RGDQbxHAi1UpIuNveqTFXSw9gZjc4,nnPsf4XLIJ7RWF = 'folder','260'
	RlTL31u9wcP4QXHxCyh6Bkqr,ookOLrZNMj = [],''
	if 'context=' in VPIEsaiROZwmp20Jdn8WrA7c3Y:
		fwdL5DAnv6gJxMK = ZXFs0mEPR8qI2zj.findall('context=(\d+)',VPIEsaiROZwmp20Jdn8WrA7c3Y,ZXFs0mEPR8qI2zj.DOTALL)
		if fwdL5DAnv6gJxMK: ookOLrZNMj = str(fwdL5DAnv6gJxMK[0])
	if nnPsf4XLIJ7RWF=='270':
		ookOLrZNMj = dGlmU8JqW5yFAtcsg
		if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()):
			RlTL31u9wcP4QXHxCyh6Bkqr.append(('مسح قائمة مفضلة '+ookOLrZNMj,'RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_DELETELIST'+')'))
	else:
		if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()):
			count = len(ADC1HYnMN2xh7E3[ookOLrZNMj])
			if count>1: RlTL31u9wcP4QXHxCyh6Bkqr.append(('تحريك 1 للأعلى','RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_UP1)'))
			if count>4: RlTL31u9wcP4QXHxCyh6Bkqr.append(('تحريك 4 للأعلى','RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_UP4)'))
			if count>1: RlTL31u9wcP4QXHxCyh6Bkqr.append(('تحريك 1 للأسفل','RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_DOWN1)'))
			if count>4: RlTL31u9wcP4QXHxCyh6Bkqr.append(('تحريك 4 للأسفل','RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_DOWN4)'))
		for ookOLrZNMj in ['1','2','3','4','5']:
			if ookOLrZNMj in list(ADC1HYnMN2xh7E3.keys()) and llKa01dWnLzDMg in ADC1HYnMN2xh7E3[ookOLrZNMj]:
				RlTL31u9wcP4QXHxCyh6Bkqr.append(('مسح من مفضلة '+ookOLrZNMj,'RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_REMOVE1)'))
			else: RlTL31u9wcP4QXHxCyh6Bkqr.append(('إضافة لمفضلة '+ookOLrZNMj,'RunPlugin('+E02Knb1UeQzLYtc6+'&context='+ookOLrZNMj+'_ADD1)'))
	Cu49NSBdi0EDsZ26zbc = []
	for XM70RniZVcd6Jb98jupTxeomsA,JrfNaIyWhg3PeMD5v8E1LmpdQ7X in RlTL31u9wcP4QXHxCyh6Bkqr:
		XM70RniZVcd6Jb98jupTxeomsA = '[COLOR FFFFFF00]'+XM70RniZVcd6Jb98jupTxeomsA+'[/COLOR]'
		Cu49NSBdi0EDsZ26zbc.append((XM70RniZVcd6Jb98jupTxeomsA,JrfNaIyWhg3PeMD5v8E1LmpdQ7X,))
	return Cu49NSBdi0EDsZ26zbc
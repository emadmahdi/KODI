# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'FASELHD1'
headers = {'User-Agent':''}
W74fAyGxODoLPs5vMX2l8C93R = '_FH1_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['جوائز الأوسكار','المراجعات','wwe']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==570: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==571: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==572: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==573: HkKfQCS7RIa4xi3houjvl = DFjzy4r8hXNtR0(url,text)
	elif mode==576: HkKfQCS7RIa4xi3houjvl = O3KdfC9gol7()
	elif mode==579: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'لماذا الموقع بطيء','',576)
	pp5vX2CWHBtwOPzdq0Junij7,url,wpFmEA3z8JR = UUNdIkbzF3lKquAsr4Q9TJnHM8tYOf(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'faselhd1','فاصل إعلاني','dubbed-movies')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع',pp5vX2CWHBtwOPzdq0Junij7,579,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',pp5vX2CWHBtwOPzdq0Junij7,571,'','','featured1')
	items = ZXFs0mEPR8qI2zj.findall('class="h3">(.*?)<.*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not items:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,RRucmYBaXegTtNOdGHMQ in items:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,571,'','','details1')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"menu-primary"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		uLe9dW1C3gpXtNDGrvnRYq = ZXFs0mEPR8qI2zj.findall('<li (.*?)</li>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		tTa96FKWcqPvrgXhwdN01iyekRB3l7 = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		OeT2Jo0sp6h1mGdqfFw = 0
		for Iwo3ZzUA69btP5g21r in uLe9dW1C3gpXtNDGrvnRYq:
			if OeT2Jo0sp6h1mGdqfFw>0: Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',Iwo3ZzUA69btP5g21r,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if RRucmYBaXegTtNOdGHMQ=='#': continue
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+RRucmYBaXegTtNOdGHMQ
				if title=='': continue
				if any(AARNPWHjQU9dEmDI in title.lower() for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
				title = tTa96FKWcqPvrgXhwdN01iyekRB3l7[OeT2Jo0sp6h1mGdqfFw]+title
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,571,'','','details2')
			OeT2Jo0sp6h1mGdqfFw += 1
	return
def O3KdfC9gol7():
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FASELHD1-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('class="h4">(.*?)</div>(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not CCqaV18lM0OL: return
	if type=='filters':
		IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"homeSlide"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		Mbe4UmywtK8Pj9or,R28S4pFmAojEW7CGnx,mwXy4HaY1uWtlvbZVcN7 = zip(*items)
		items = zip(R28S4pFmAojEW7CGnx,Mbe4UmywtK8Pj9or,mwXy4HaY1uWtlvbZVcN7)
	elif type=='featured2':
		title,bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='details2' and len(CCqaV18lM0OL)>1:
		title = CCqaV18lM0OL[0][0]
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,571,'','','featured2')
		title = CCqaV18lM0OL[1][0]
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,571,'','','details3')
		return
	else:
		title,bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[-1]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if any(AARNPWHjQU9dEmDI in title.lower() for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
		CrGO63LT7j2UxniW = WhJe7bGx5XackTwOIZVLC8ut(CrGO63LT7j2UxniW)
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.split('?resize=')[0]
		title = qpob7TvxHSs4fEzO6(title)
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|حلقة).\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if '/collections/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,571,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and type=='':
			title = '_MOD_'+LqYKJ36CBG[0][0]
			title = title.strip(' –')
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,573,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif 'episodes/' in RRucmYBaXegTtNOdGHMQ or 'movies/' in RRucmYBaXegTtNOdGHMQ or 'hindi/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,572,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,573,CrGO63LT7j2UxniW)
	if type=='filters':
		jMD8RBfTGUlQwJCk = ZXFs0mEPR8qI2zj.findall('"more_button_page":(.*?),',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if jMD8RBfTGUlQwJCk:
			count = jMD8RBfTGUlQwJCk[0]
			RRucmYBaXegTtNOdGHMQ = url+'/offset/'+count
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة أخرى',RRucmYBaXegTtNOdGHMQ,571,'','','filters')
	elif 'details' in type:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("class='pagination(.*?)</div>",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall("href='(.*?)'.*?>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = 'صفحة '+qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,571,'','','details4')
	return
def DFjzy4r8hXNtR0(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	HEplfjN5wBxeYtD4ds6FvA38rK0U = False
	if not type:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"seasonList"(.*?)"container"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if len(items)>1:
				pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
				HEplfjN5wBxeYtD4ds6FvA38rK0U = True
				for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,name,title in items:
					name = qpob7TvxHSs4fEzO6(name)
					if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+RRucmYBaXegTtNOdGHMQ
					title = name+' - '+title
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,573,CrGO63LT7j2UxniW,'','episodes')
	if type=='episodes' or not HEplfjN5wBxeYtD4ds6FvA38rK0U:
		ttiasLcTXGvgqb41nC7DRF = ZXFs0mEPR8qI2zj.findall('"posterImg".*?src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if ttiasLcTXGvgqb41nC7DRF: CrGO63LT7j2UxniW = ttiasLcTXGvgqb41nC7DRF[0]
		else: CrGO63LT7j2UxniW = ''
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"epAll"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = title.strip(' ')
				title = qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,572,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	yf608hE5KeRG1DscunvrU,D21FvpPhVbtslNIXRwxZJiyB9,LngWDh4U7Qs0Jj2ty = [],[],[]
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'','','','','FASELHD1-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Cglu0VToFyv = ZXFs0mEPR8qI2zj.findall('مستوى المشاهدة.*?">(.*?)</span>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Cglu0VToFyv:
		z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('"tag">(.*?)</a>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"videoRow"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('&img=')[0]
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named=__embed')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="streamHeader(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall("href = '(.*?)'.*?</i>(.*?)</a>",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('&img=')[0]
			name = name.strip(' ')
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+name+'__watch')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="downloadLinks(.*?)blackwindow',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</span>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('&img=')[0]
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download')
	for BO9nRHDL2oS43eh6l in yf608hE5KeRG1DscunvrU:
		RRucmYBaXegTtNOdGHMQ,name = BO9nRHDL2oS43eh6l.split('?named')
		if RRucmYBaXegTtNOdGHMQ not in D21FvpPhVbtslNIXRwxZJiyB9:
			D21FvpPhVbtslNIXRwxZJiyB9.append(RRucmYBaXegTtNOdGHMQ)
			LngWDh4U7Qs0Jj2ty.append(BO9nRHDL2oS43eh6l)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(LngWDh4U7Qs0Jj2ty,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/?s='+search
	pp5vX2CWHBtwOPzdq0Junij7,lQHXdV9Nzf6BLqS8D,qShkDLtUac9u = UUNdIkbzF3lKquAsr4Q9TJnHM8tYOf(Z7uFdWIRv9ybj0,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D,'details5')
	return
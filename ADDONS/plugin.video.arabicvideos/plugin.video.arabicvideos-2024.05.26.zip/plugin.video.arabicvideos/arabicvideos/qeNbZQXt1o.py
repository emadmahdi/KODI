# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'EGYBESTVIP'
W74fAyGxODoLPs5vMX2l8C93R = '_EGV_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
def OVQIAezo6U1NSTl4L(mode,url,wwNtFTLK2IqAszYBDV9J,text):
	if   mode==220: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==221: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==222: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==223: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==224: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url)
	elif mode==229: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','EGYBEST-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="i i-home"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,222)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="ba(.*?)<script',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for title,RRucmYBaXegTtNOdGHMQ in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,221)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if 'html' not in RRucmYBaXegTtNOdGHMQ: continue
			if not RRucmYBaXegTtNOdGHMQ.endswith('/'): Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,221)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def yPzYJU5Wup8(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="rs_scroll"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,224)
	return
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url):
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',url,221)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="sub_nav(.*?)id="movies',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".+?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if RRucmYBaXegTtNOdGHMQ=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,221)
	else: RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J='1'):
	if wwNtFTLK2IqAszYBDV9J=='': wwNtFTLK2IqAszYBDV9J = '1'
	if '/search' in url or '?' in url: lQHXdV9Nzf6BLqS8D = url + '&'
	else: lQHXdV9Nzf6BLqS8D = url + '?'
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D + 'page=' + wwNtFTLK2IqAszYBDV9J
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('class="pda"(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[-1]
	elif '/series/' in url:
		IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('class="owl-carousel owl-carousel(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	else:
		IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('id="movies(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[-1]
	items = ZXFs0mEPR8qI2zj.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		title = qpob7TvxHSs4fEzO6(title)
		if '/movie/' in RRucmYBaXegTtNOdGHMQ or '/episode' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ.rstrip('/'),223,CrGO63LT7j2UxniW)
		else:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,221,CrGO63LT7j2UxniW)
	if len(items)>=16:
		dJPYwNXKV4c = ['/movies','/tv','/search','/trending']
		wwNtFTLK2IqAszYBDV9J = int(wwNtFTLK2IqAszYBDV9J)
		if any(AARNPWHjQU9dEmDI in url for AARNPWHjQU9dEmDI in dJPYwNXKV4c):
			for rrpZHIB0UcF4aoeuK9LnT21 in range(0,1000,100):
				if int(wwNtFTLK2IqAszYBDV9J/100)*100==rrpZHIB0UcF4aoeuK9LnT21:
					for xxFhvt275i8MdUVuPkSXzmbT in range(rrpZHIB0UcF4aoeuK9LnT21,rrpZHIB0UcF4aoeuK9LnT21+100,10):
						if int(wwNtFTLK2IqAszYBDV9J/10)*10==xxFhvt275i8MdUVuPkSXzmbT:
							for NCmGWzZ1SF3bPEt2nvkA7B6loh5 in range(xxFhvt275i8MdUVuPkSXzmbT,xxFhvt275i8MdUVuPkSXzmbT+10,1):
								if not wwNtFTLK2IqAszYBDV9J==NCmGWzZ1SF3bPEt2nvkA7B6loh5 and NCmGWzZ1SF3bPEt2nvkA7B6loh5!=0:
									Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+str(NCmGWzZ1SF3bPEt2nvkA7B6loh5),url,221,'',str(NCmGWzZ1SF3bPEt2nvkA7B6loh5))
						elif xxFhvt275i8MdUVuPkSXzmbT!=0: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+str(xxFhvt275i8MdUVuPkSXzmbT),url,221,'',str(xxFhvt275i8MdUVuPkSXzmbT))
						else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+str(1),url,221,'',str(1))
				elif rrpZHIB0UcF4aoeuK9LnT21!=0: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+str(rrpZHIB0UcF4aoeuK9LnT21),url,221,'',str(rrpZHIB0UcF4aoeuK9LnT21))
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+str(1),url,221)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'','','','EGYBESTVIP-PLAY-1st')
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('<td>التصنيف</td>.*?">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	MgkDv3qj6OAoNiapm82,HoevBlLf6CnKOYF7 = '',''
	ZUSThKn2CzvrIqsxRJj,GmyzthSfTIsg7RQEA68dcwPvrjYC = QstumvzTIEUMXCcx06aD4y8nSqH,QstumvzTIEUMXCcx06aD4y8nSqH
	tc0P4q5hN8gj = ZXFs0mEPR8qI2zj.findall('show_dl api" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if tc0P4q5hN8gj:
		for RRucmYBaXegTtNOdGHMQ in tc0P4q5hN8gj:
			if '/watch/' in RRucmYBaXegTtNOdGHMQ: MgkDv3qj6OAoNiapm82 = RRucmYBaXegTtNOdGHMQ
			elif '/download/' in RRucmYBaXegTtNOdGHMQ: HoevBlLf6CnKOYF7 = RRucmYBaXegTtNOdGHMQ
		if MgkDv3qj6OAoNiapm82!='': ZUSThKn2CzvrIqsxRJj = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,MgkDv3qj6OAoNiapm82,'','','','EGYBESTVIP-PLAY-2nd')
		if HoevBlLf6CnKOYF7!='': GmyzthSfTIsg7RQEA68dcwPvrjYC = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,HoevBlLf6CnKOYF7,'','','','EGYBESTVIP-PLAY-3rd')
	aRho5n047tvjA = ZXFs0mEPR8qI2zj.findall('id="video".*?data-src="(.*?)"',ZUSThKn2CzvrIqsxRJj,ZXFs0mEPR8qI2zj.DOTALL)
	if aRho5n047tvjA:
		lQHXdV9Nzf6BLqS8D = aRho5n047tvjA[0]
		if lQHXdV9Nzf6BLqS8D!='' and 'uploaded.egybest.download' in lQHXdV9Nzf6BLqS8D and '/?id=_' not in lQHXdV9Nzf6BLqS8D:
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'','','','EGYBESTVIP-PLAY-4th')
			bAP2juCxDMI0lVQK8RJBgS6WzOX = ZXFs0mEPR8qI2zj.findall('source src="(.*?)" title="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if bAP2juCxDMI0lVQK8RJBgS6WzOX:
				for RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD in bAP2juCxDMI0lVQK8RJBgS6WzOX:
					YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ+'?named=ed.egybest.do__watch__mp4__'+PHUqTNVJ0ErRSwibn5gD)
			else:
				NGmuWwXdLQ6nMltx39FYECohJ = lQHXdV9Nzf6BLqS8D.split('/')[2]
				YYmyQXglbEewzL3IA2Sd.append(lQHXdV9Nzf6BLqS8D+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__watch')
		elif lQHXdV9Nzf6BLqS8D!='':
			NGmuWwXdLQ6nMltx39FYECohJ = lQHXdV9Nzf6BLqS8D.split('/')[2]
			YYmyQXglbEewzL3IA2Sd.append(lQHXdV9Nzf6BLqS8D+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__watch')
	XMEfrmNUk5 = ZXFs0mEPR8qI2zj.findall('<table class="dls_table(.*?)</table>',GmyzthSfTIsg7RQEA68dcwPvrjYC,ZXFs0mEPR8qI2zj.DOTALL)
	if XMEfrmNUk5:
		XMEfrmNUk5 = XMEfrmNUk5[0]
		qA7XB0JtegOsRfYCQFPimyHM5Ww = ZXFs0mEPR8qI2zj.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',XMEfrmNUk5,ZXFs0mEPR8qI2zj.DOTALL)
		if qA7XB0JtegOsRfYCQFPimyHM5Ww:
			for PHUqTNVJ0ErRSwibn5gD,RRucmYBaXegTtNOdGHMQ in qA7XB0JtegOsRfYCQFPimyHM5Ww:
				if 'myegyvip' not in RRucmYBaXegTtNOdGHMQ: continue
				if RRucmYBaXegTtNOdGHMQ.count('/')>=2:
					NGmuWwXdLQ6nMltx39FYECohJ = RRucmYBaXegTtNOdGHMQ.split('/')[2]
					YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__download__mp4__'+PHUqTNVJ0ErRSwibn5gD)
	usLWRwnPVIOzf8JeGj = []
	for RRucmYBaXegTtNOdGHMQ in YYmyQXglbEewzL3IA2Sd:
		usLWRwnPVIOzf8JeGj.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(usLWRwnPVIOzf8JeGj,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','+')
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,JJTrn6SEtYZV31eyR97,'','','','EGYBESTVIP-SEARCH-1st')
	Yhqjz4bLa1HB = ZXFs0mEPR8qI2zj.findall('name="_token" value="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Yhqjz4bLa1HB:
		url = JJTrn6SEtYZV31eyR97+'/search?_token='+Yhqjz4bLa1HB[0]+'&q='+H9IMP4eTVW8dji3EXnS7w
		RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
﻿# -*- coding: utf-8 -*-
from j3x780FpaM import *
def OVQIAezo6U1NSTl4L(nnPsf4XLIJ7RWF,hI3ufY4tO9eZ28CB):
	if hI3ufY4tO9eZ28CB=='': return
	if nnPsf4XLIJ7RWF==1:
		MSXZoqyGgxAmhP09wW = kGEPsyxKnHDJ.getCurrentWindowDialogId()
		m8mkFvZWVyK02XwGxpeR9nIEifA4 = kGEPsyxKnHDJ.Window(MSXZoqyGgxAmhP09wW)
		hI3ufY4tO9eZ28CB = BXdJu6DpcG9k8ieCLWtZ(hI3ufY4tO9eZ28CB)
		m8mkFvZWVyK02XwGxpeR9nIEifA4.getControl(311).setLabel(hI3ufY4tO9eZ28CB)
	if nnPsf4XLIJ7RWF==0:
		m6egkRrjcavHEdwYDSOs='X'
		if VYMZsxRpcQHPgkaiDKjyoh: AVB0WwbT27 = isinstance(hI3ufY4tO9eZ28CB,str)
		else: AVB0WwbT27 = isinstance(hI3ufY4tO9eZ28CB,unicode)
		if AVB0WwbT27==True: m6egkRrjcavHEdwYDSOs='U'
		Uu6O0cAGL7BrmnSR=str(type(hI3ufY4tO9eZ28CB))+' '+hI3ufY4tO9eZ28CB+' '+m6egkRrjcavHEdwYDSOs+' '
		for xxFhvt275i8MdUVuPkSXzmbT in range(0,len(hI3ufY4tO9eZ28CB),1):
			Uu6O0cAGL7BrmnSR += hex(ord(hI3ufY4tO9eZ28CB[xxFhvt275i8MdUVuPkSXzmbT])).replace('0x','')+' '
		hI3ufY4tO9eZ28CB = BXdJu6DpcG9k8ieCLWtZ(hI3ufY4tO9eZ28CB)
		m6egkRrjcavHEdwYDSOs='X'
		if VYMZsxRpcQHPgkaiDKjyoh: AVB0WwbT27 = isinstance(hI3ufY4tO9eZ28CB, str)
		else: AVB0WwbT27 = isinstance(hI3ufY4tO9eZ28CB, unicode)
		if AVB0WwbT27==True: m6egkRrjcavHEdwYDSOs='U'
		svlyVi1SGtkwEQf0F6uoMBgK=str(type(hI3ufY4tO9eZ28CB))+' '+hI3ufY4tO9eZ28CB+' '+m6egkRrjcavHEdwYDSOs+' '
		for xxFhvt275i8MdUVuPkSXzmbT in range(0,len(hI3ufY4tO9eZ28CB),1):
			svlyVi1SGtkwEQf0F6uoMBgK += hex(ord(hI3ufY4tO9eZ28CB[xxFhvt275i8MdUVuPkSXzmbT])).replace('0x','')+' '
	return
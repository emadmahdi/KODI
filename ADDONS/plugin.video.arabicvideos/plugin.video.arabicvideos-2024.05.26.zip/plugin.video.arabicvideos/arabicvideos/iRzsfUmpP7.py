# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ARABSEED'
headers = {'User-Agent':SjMG7CYyUqbPVso0DErhXROvkl()}
W74fAyGxODoLPs5vMX2l8C93R = '_ARS_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==250: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==251: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==252: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==253: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==254: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'CATEGORIES___'+text)
	elif mode==255: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FILTERS___'+text)
	elif mode==256: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url,text)
	elif mode==259: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97+'/main','',headers,'','','ARABSEED-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',JJTrn6SEtYZV31eyR97+'/category/اخرى',254)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',JJTrn6SEtYZV31eyR97+'/category/اخرى',255)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',JJTrn6SEtYZV31eyR97+'/main',251,'','','featured_main')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'جديد الأفلام',JJTrn6SEtYZV31eyR97+'/main',251,'','','new_movies')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'جديد الحلقات',JJTrn6SEtYZV31eyR97+'/main',251,'','','new_episodes')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المضاف حديثاً',JJTrn6SEtYZV31eyR97+'/latest',251,'','','lastest')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('class="MenuHeader"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	i9jtofq4JrV = CCqaV18lM0OL[0]
	kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',i9jtofq4JrV,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in kYoiqbhP2AfzOHWmjxS69sNdM:
		title = qpob7TvxHSs4fEzO6(title)
		if title not in SmgoEYJ7uyL and title!='':
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,256)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def yPzYJU5Wup8(url,type):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if 'class="SliderInSection' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in QstumvzTIEUMXCcx06aD4y8nSqH: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in QstumvzTIEUMXCcx06aD4y8nSqH:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="LinksList(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			if len(IZGcQbePXxwAoyYR1n)>1 and type=='new_episodes': bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[1]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				Wu4CadwRTJfkbXMUVxO3jQ2 = ZXFs0mEPR8qI2zj.findall('</i>(.*?)<span>(.*?)<',title,ZXFs0mEPR8qI2zj.DOTALL)
				try: BkeMNv4iXH3 = Wu4CadwRTJfkbXMUVxO3jQ2[0][0].replace('\n','').strip(' ')
				except: BkeMNv4iXH3 = ''
				try: UXdpKgHOF1i7hmvjcDE2qLr = Wu4CadwRTJfkbXMUVxO3jQ2[0][1].replace('\n','').strip(' ')
				except: UXdpKgHOF1i7hmvjcDE2qLr = ''
				Wu4CadwRTJfkbXMUVxO3jQ2 = BkeMNv4iXH3+' '+UXdpKgHOF1i7hmvjcDE2qLr
				if '<strong>' in title:
					IIa6whCNrJmkRXeMqTb23lgB = ZXFs0mEPR8qI2zj.findall('</i>(.*?)<',title,ZXFs0mEPR8qI2zj.DOTALL)
					if IIa6whCNrJmkRXeMqTb23lgB: Wu4CadwRTJfkbXMUVxO3jQ2 = IIa6whCNrJmkRXeMqTb23lgB[0]
				if not Wu4CadwRTJfkbXMUVxO3jQ2:
					IIa6whCNrJmkRXeMqTb23lgB = ZXFs0mEPR8qI2zj.findall('alt="(.*?)"',title,ZXFs0mEPR8qI2zj.DOTALL)
					if IIa6whCNrJmkRXeMqTb23lgB: Wu4CadwRTJfkbXMUVxO3jQ2 = IIa6whCNrJmkRXeMqTb23lgB[0]
				if Wu4CadwRTJfkbXMUVxO3jQ2:
					if 'key=' in RRucmYBaXegTtNOdGHMQ: type = RRucmYBaXegTtNOdGHMQ.split('key=')[1]
					else: type = 'newest'
					Wu4CadwRTJfkbXMUVxO3jQ2 = Wu4CadwRTJfkbXMUVxO3jQ2.strip(' ')
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,RRucmYBaXegTtNOdGHMQ,251,'','',type)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type):
	q7ZsJYigubKLljme32W,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			REQYDPrVCOimAsG,BTMputsaqV = 'POST',{}
			lQHXdV9Nzf6BLqS8D,hJl76MdBq9eF = url.split('?')
			YYyAscnV8LouaiJz = hJl76MdBq9eF.split('&')
			for yJzVl8aho4tDk65mAsT3N in YYyAscnV8LouaiJz:
				key,AARNPWHjQU9dEmDI = yJzVl8aho4tDk65mAsT3N.split('=')
				BTMputsaqV[key] = AARNPWHjQU9dEmDI
			if YYyAscnV8LouaiJz: q7ZsJYigubKLljme32W,url,data = REQYDPrVCOimAsG,lQHXdV9Nzf6BLqS8D,BTMputsaqV
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,q7ZsJYigubKLljme32W,url,data,headers,'','','ARABSEED-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if type=='filters': IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH]
	elif 'featured' in type: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="MainSlides(.*?)class="LinksList',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='new_movies': IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='new_episodes': IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='most': IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="SliderInSection(.*?)class="LinksList',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="Blocks-UL"(.*?)class="AboElSeed"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if 'featured' in type:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		DpPqhakxAX0Hn = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if DpPqhakxAX0Hn:
			YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI,QR0IuBqPMJVUsjd4yY9o8f,JcSzrjHL0lVwM = zip(*DpPqhakxAX0Hn)
			items = zip(YYmyQXglbEewzL3IA2Sd,JcSzrjHL0lVwM,xCLQK8kh39sjyi5DXSZAVeI)
	else:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if 'WWE' in title: continue
		title = qpob7TvxHSs4fEzO6(title)
		if 'الحلقة' in title:
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if LqYKJ36CBG:
				title = '_MOD_' + LqYKJ36CBG[0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,253,CrGO63LT7j2UxniW)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,252,CrGO63LT7j2UxniW)
		elif '/selary/' in RRucmYBaXegTtNOdGHMQ or 'مسلسل' in title:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,253,CrGO63LT7j2UxniW)
		else:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,252,CrGO63LT7j2UxniW)
	if type in ['newest','best','most']:
		items = ZXFs0mEPR8qI2zj.findall('page-numbers" href="(.*?)">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
			title = qpob7TvxHSs4fEzO6(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,251,'','',type)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH[10000:]
	items = ZXFs0mEPR8qI2zj.findall('data-src="(.*?)".*?alt="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not items: return
	CrGO63LT7j2UxniW,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="ContainerEpisodesList"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<em>(.*?)</em>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,LqYKJ36CBG in items:
			title = name+' - الحلقة رقم '+LqYKJ36CBG
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,252,CrGO63LT7j2UxniW)
	else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+'ملف التشغيل',url,252,CrGO63LT7j2UxniW)
	return
def tBGn9uEk42VRrwUf8HOAzNhbF0xoe(title,RRucmYBaXegTtNOdGHMQ):
	Wu4CadwRTJfkbXMUVxO3jQ2 = ZXFs0mEPR8qI2zj.findall('[a-zA-Z-]+',title,ZXFs0mEPR8qI2zj.DOTALL)
	if Wu4CadwRTJfkbXMUVxO3jQ2: title = Wu4CadwRTJfkbXMUVxO3jQ2[0]
	else: title = title+' '+d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	lQHXdV9Nzf6BLqS8D = wpFmEA3z8JR.url
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,'url')
	headers['Referer'] = NGmuWwXdLQ6nMltx39FYECohJ+'/'
	MgkDv3qj6OAoNiapm82,HoevBlLf6CnKOYF7,YYmyQXglbEewzL3IA2Sd = '','',[]
	ErqGmJo89Dp0snbQ2 = ZXFs0mEPR8qI2zj.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if ErqGmJo89Dp0snbQ2: MgkDv3qj6OAoNiapm82,kpM5lOCec20mrw6hV7ILBd,HoevBlLf6CnKOYF7,DOVwrFbPi1kIm8n = ErqGmJo89Dp0snbQ2[0]
	else:
		ErqGmJo89Dp0snbQ2 = ZXFs0mEPR8qI2zj.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if ErqGmJo89Dp0snbQ2:
			RRucmYBaXegTtNOdGHMQ,kpM5lOCec20mrw6hV7ILBd = ErqGmJo89Dp0snbQ2[0]
			if 'watch' in kpM5lOCec20mrw6hV7ILBd: MgkDv3qj6OAoNiapm82 = RRucmYBaXegTtNOdGHMQ
			else: HoevBlLf6CnKOYF7 = RRucmYBaXegTtNOdGHMQ
	if MgkDv3qj6OAoNiapm82:
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',MgkDv3qj6OAoNiapm82,'',headers,'','','ARABSEED-PLAY-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="WatcherArea"(.*?</ul>)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			dfZjOeknGXTwDV462uL3yg = IZGcQbePXxwAoyYR1n[0]
			dfZjOeknGXTwDV462uL3yg = dfZjOeknGXTwDV462uL3yg.replace('</ul>','<h3>')
			dfZjOeknGXTwDV462uL3yg = dfZjOeknGXTwDV462uL3yg.replace('<h3>','<h3><h3>')
			n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall('<h3>.*?(\d+)(.*?)<h3>',dfZjOeknGXTwDV462uL3yg,ZXFs0mEPR8qI2zj.DOTALL)
			if not n5nyDgxTuHbY0LNV4cWvoBtp: n5nyDgxTuHbY0LNV4cWvoBtp = [('',dfZjOeknGXTwDV462uL3yg)]
			for PHUqTNVJ0ErRSwibn5gD,bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
				if PHUqTNVJ0ErRSwibn5gD: PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD
				items = ZXFs0mEPR8qI2zj.findall('data-link="(.*?)".*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
				for RRucmYBaXegTtNOdGHMQ,name in items:
					if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
					RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__watch'+PHUqTNVJ0ErRSwibn5gD
					YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not R28S4pFmAojEW7CGnx: R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if R28S4pFmAojEW7CGnx:
			RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD = R28S4pFmAojEW7CGnx[0]
			name = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
			if '%' in PHUqTNVJ0ErRSwibn5gD: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__embed__'
			else: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__embed____'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if HoevBlLf6CnKOYF7:
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',HoevBlLf6CnKOYF7,'',headers,'','','ARABSEED-PLAY-3rd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="DownloadArea"(.*?)function',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title,PHUqTNVJ0ErRSwibn5gD in items:
				if not RRucmYBaXegTtNOdGHMQ: continue
				if 'reviewstation' in RRucmYBaXegTtNOdGHMQ: continue
				RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download____'+PHUqTNVJ0ErRSwibn5gD
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	FGR9gJxockKmP6Hq = str(YYmyQXglbEewzL3IA2Sd)
	bOwSnuzelp = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(AARNPWHjQU9dEmDI in FGR9gJxockKmP6Hq for AARNPWHjQU9dEmDI in bOwSnuzelp):
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search: search = CjyEnpfQ23o0PYwDtLId()
	if not search: return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/find/?find='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='CATEGORIES':
		if g8MUskbACOmpZncvSW5QPr9zyTaJ[0]+'==' not in SFbYEzoech4wU1: p8pgXONsjY = g8MUskbACOmpZncvSW5QPr9zyTaJ[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(g8MUskbACOmpZncvSW5QPr9zyTaJ[0:-1])):
			if g8MUskbACOmpZncvSW5QPr9zyTaJ[xxFhvt275i8MdUVuPkSXzmbT]+'==' in SFbYEzoech4wU1: p8pgXONsjY = g8MUskbACOmpZncvSW5QPr9zyTaJ[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&&'+p8pgXONsjY+'==0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&&'+p8pgXONsjY+'==0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&&')+'___'+t9NhYxrZKcBf4u.strip('&&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'//getposts??'+KMUEN9cD1OByji
	elif type=='FILTERS':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'//getposts??'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		pqrfNVvo8H = opOK7W82fQ3HNJeFZkXqzndUCS(lQHXdV9Nzf6BLqS8D)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',pqrfNVvo8H,251,'','','filters')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',pqrfNVvo8H,251,'','','filters')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	lKtsr4iL0Yx58vmhe = ZXFs0mEPR8qI2zj.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	tx54UL7o1v = ZXFs0mEPR8qI2zj.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	jNFqoOewYB2mG = lKtsr4iL0Yx58vmhe+tx54UL7o1v
	dict = {}
	for name,Lm4n6ZMXPrWpo,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		items = ZXFs0mEPR8qI2zj.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('data-rate="(.*?)".*?<em>(.*?)</em>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			items = []
			for Z7ZzgCTMBsNlVi9,AARNPWHjQU9dEmDI in kYoiqbhP2AfzOHWmjxS69sNdM: items.append([Z7ZzgCTMBsNlVi9,'',AARNPWHjQU9dEmDI])
			Lm4n6ZMXPrWpo = 'rate'
			name = 'التقييم'
		else: Lm4n6ZMXPrWpo = items[0][1]
		if '==' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='CATEGORIES':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<=1:
				if Lm4n6ZMXPrWpo==g8MUskbACOmpZncvSW5QPr9zyTaJ[-1]: RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'CATEGORIES___'+tt6AbxYRgQ3aC4O)
				return
			else:
				pqrfNVvo8H = opOK7W82fQ3HNJeFZkXqzndUCS(lQHXdV9Nzf6BLqS8D)
				if Lm4n6ZMXPrWpo==g8MUskbACOmpZncvSW5QPr9zyTaJ[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',pqrfNVvo8H,251,'','','filters')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',lQHXdV9Nzf6BLqS8D,254,'','',tt6AbxYRgQ3aC4O)
		elif type=='FILTERS':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&&'+Lm4n6ZMXPrWpo+'==0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&&'+Lm4n6ZMXPrWpo+'==0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع :'+name,lQHXdV9Nzf6BLqS8D,255,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for Z7ZzgCTMBsNlVi9,vfLGDU1N0e8c,AARNPWHjQU9dEmDI in items:
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			if 'الكل' in Z7ZzgCTMBsNlVi9: continue
			Z7ZzgCTMBsNlVi9 = qpob7TvxHSs4fEzO6(Z7ZzgCTMBsNlVi9)
			QCDVzPGHj6IxMA,Wu4CadwRTJfkbXMUVxO3jQ2 = Z7ZzgCTMBsNlVi9,Z7ZzgCTMBsNlVi9
			Wu4CadwRTJfkbXMUVxO3jQ2 = name+': '+QCDVzPGHj6IxMA
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Wu4CadwRTJfkbXMUVxO3jQ2
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&&'+Lm4n6ZMXPrWpo+'=='+QCDVzPGHj6IxMA
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&&'+Lm4n6ZMXPrWpo+'=='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			if type=='FILTERS':
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,url,255,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='CATEGORIES' and g8MUskbACOmpZncvSW5QPr9zyTaJ[-2]+'==' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
				aaIn3XlQKJ6zSfkmjuCyM = url+'//getposts??'+KMUEN9cD1OByji
				pqrfNVvo8H = opOK7W82fQ3HNJeFZkXqzndUCS(aaIn3XlQKJ6zSfkmjuCyM)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,pqrfNVvo8H,251,'','','filters')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,url,254,'','',WYXmvw9l3jToq6rui1SCs)
	return
g8MUskbACOmpZncvSW5QPr9zyTaJ = ['category','country','release-year']
hU5JTpKRjbCGL2 = ['category','country','genre','release-year','language','quality','rate']
def opOK7W82fQ3HNJeFZkXqzndUCS(url):
	y8aeHptIKOCfYNEdGMs2QrlS1j5 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',y8aeHptIKOCfYNEdGMs2QrlS1j5)
	url = url.replace('/category/اخرى','')
	if y8aeHptIKOCfYNEdGMs2QrlS1j5 not in url: url = url+y8aeHptIKOCfYNEdGMs2QrlS1j5
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p,rXLaWluDjvi4xMwpOSF91JB7 = {},''
	if '==' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('==')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	for key in hU5JTpKRjbCGL2:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&&'+key+'=='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&&'+key+'=='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&&')
	return rXLaWluDjvi4xMwpOSF91JB7
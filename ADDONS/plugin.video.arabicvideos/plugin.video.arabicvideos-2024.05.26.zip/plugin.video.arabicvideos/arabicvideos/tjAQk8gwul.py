# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'TVFUN'
W74fAyGxODoLPs5vMX2l8C93R = '_TVF_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['بث مباشر']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==460: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==461: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==462: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==463: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==469: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','TVFUN-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"menu-btn"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in SmgoEYJ7uyL: continue
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,461)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,qzTpS3aBcFGiM=''):
	items = []
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','TVFUN-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="head-title"(.*?)id="footer"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		FF1TYf6O5KENr8R72LUVievClmudxD = []
		QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			title = '_MOD_'+title.replace('<br>',' ').replace('  ',' ').strip(' ')
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,462,CrGO63LT7j2UxniW)
			elif LqYKJ36CBG and 'الحلقة' in title:
				title = '_MOD_' + LqYKJ36CBG[0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,463,CrGO63LT7j2UxniW)
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,463,CrGO63LT7j2UxniW)
	if qzTpS3aBcFGiM!='latest':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('<a href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.strip(' ')
				if RRucmYBaXegTtNOdGHMQ=="": continue
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
				if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,461)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','TVFUN-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="head-title"(.*?)id="footer"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if items:
			for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
				title = '_MOD_'+title.replace('<br>',' ').replace('  ',' ').strip(' ')
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,462,CrGO63LT7j2UxniW)
		else:
			items = ZXFs0mEPR8qI2zj.findall('class="episode.*?href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,462)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.strip(' ')
			if RRucmYBaXegTtNOdGHMQ=="": continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,463)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd = []
	lQHXdV9Nzf6BLqS8D = url.replace('/video/','/watch/')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','TVFUN-PLAY-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('VideoServers"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for mUb59IPOXlzvnGg1uhrRJyC8eBsiSc,name in R28S4pFmAojEW7CGnx:
			mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = mUb59IPOXlzvnGg1uhrRJyC8eBsiSc[2:]
			if Yd6t3PjlLKk: mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = mUb59IPOXlzvnGg1uhrRJyC8eBsiSc.decode('utf8')
			mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = EGTVgQoSu6ZsD.b64decode(mUb59IPOXlzvnGg1uhrRJyC8eBsiSc)
			if VYMZsxRpcQHPgkaiDKjyoh: mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = mUb59IPOXlzvnGg1uhrRJyC8eBsiSc.decode('utf8')
			RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('src="(.*?)"',mUb59IPOXlzvnGg1uhrRJyC8eBsiSc,ZXFs0mEPR8qI2zj.DOTALL)
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]
			if 'http' not in RRucmYBaXegTtNOdGHMQ:
				if '//' in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
				else: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if RRucmYBaXegTtNOdGHMQ not in YYmyQXglbEewzL3IA2Sd:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__watch'
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search:
		search = CjyEnpfQ23o0PYwDtLId()
		if not search: return
	if ' ' in search:
		if showDialogs: HHTzVhiY079bvdluNkFQ4wCMpe('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = JJTrn6SEtYZV31eyR97+'/q/'+search+'/'
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'FAJERSHOW'
W74fAyGxODoLPs5vMX2l8C93R = '_FJS_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==390: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==391: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==392: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==393: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==399: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',399,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','FAJERSHOW-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	items = ZXFs0mEPR8qI2zj.findall('<header>.*?<h2>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for bznBHAX7xt6 in range(len(items)):
		title = items[bznBHAX7xt6]
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,JJTrn6SEtYZV31eyR97,391,'','','latest'+str(bznBHAX7xt6))
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مختارات عشوائية',JJTrn6SEtYZV31eyR97,391,'','','randoms')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أعلى الأفلام تقييماً',JJTrn6SEtYZV31eyR97,391,'','','top_imdb_movies')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أعلى المسلسلات تقييماً',JJTrn6SEtYZV31eyR97,391,'','','top_imdb_series')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أفلام مميزة',JJTrn6SEtYZV31eyR97+'/movies',391,'','','featured_movies')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات مميزة',JJTrn6SEtYZV31eyR97+'/tvshows',391,'','','featured_tvshows')
	bdq4e6Wr2gslnSiA38 = ''
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="menu"(.*?)id="contenedor"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 += IZGcQbePXxwAoyYR1n[0]
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97+'/movies','','','','','FAJERSHOW-MENU-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="releases"(.*?)aside',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 += IZGcQbePXxwAoyYR1n[0]
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	Fl9VDzobcU = True
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = qpob7TvxHSs4fEzO6(title)
		if title=='الأعلى مشاهدة':
			if Fl9VDzobcU:
				title = 'الافلام '+title
				Fl9VDzobcU = False
			else: title = 'المسلسلات '+title
		if title not in SmgoEYJ7uyL:
			if title=='أفلام': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,JJTrn6SEtYZV31eyR97+'/movies',391,'','','all_movies_tvshows')
			elif title=='مسلسلات': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,JJTrn6SEtYZV31eyR97+'/tvshows',391,'','','all_movies_tvshows')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,391)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type):
	bdq4e6Wr2gslnSiA38,items = [],[]
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FAJERSHOW-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if type in ['featured_movies','featured_tvshows']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="content"(.*?)id="archive-content"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif type=='all_movies_tvshows':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="archive-content"(.*?)class="pagination"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif type=='top_imdb_movies':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='top_imdb_series':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("class='top-imdb-list tright(.*?)footer",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='search':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="search-page"(.*?)class="sidebar',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='sider':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="widget(.*?)class="widget',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		xPDZRXulfK5CvcTz0gbV = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		YYmyQXglbEewzL3IA2Sd,JcSzrjHL0lVwM,xCLQK8kh39sjyi5DXSZAVeI = zip(*xPDZRXulfK5CvcTz0gbV)
		items = zip(JcSzrjHL0lVwM,YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI)
	elif type=='randoms':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="slider-movies-tvshows"(.*?)<header>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif 'latest' in type:
		bznBHAX7xt6 = int(type[-1:])
		QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('<header>','<end><start>')
		QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('</div></div></div>','</div></div></div><end>')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<start>(.*?)<end>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[bznBHAX7xt6]
		if bznBHAX7xt6==6:
			xPDZRXulfK5CvcTz0gbV = ZXFs0mEPR8qI2zj.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			JcSzrjHL0lVwM,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = zip(*xPDZRXulfK5CvcTz0gbV)
			items = zip(JcSzrjHL0lVwM,YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="content"(.*?)class="(pagination|sidebar)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0][0]
			if '/collection/' in url:
				items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			elif '/quality/' in url:
				items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if not items and bdq4e6Wr2gslnSiA38:
		items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = ZXFs0mEPR8qI2zj.findall('^(.*?)<.*?serie">(.*?)<',title,ZXFs0mEPR8qI2zj.DOTALL)
			title = title[0][1]
			if title in FF1TYf6O5KENr8R72LUVievClmudxD: continue
			FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
			title = '_MOD_'+title
		Wu4CadwRTJfkbXMUVxO3jQ2 = ZXFs0mEPR8qI2zj.findall('^(.*?)<',title,ZXFs0mEPR8qI2zj.DOTALL)
		if Wu4CadwRTJfkbXMUVxO3jQ2: title = Wu4CadwRTJfkbXMUVxO3jQ2[0]
		title = qpob7TvxHSs4fEzO6(title)
		if '/tvshows/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,393,CrGO63LT7j2UxniW)
		elif '/episodes/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,393,CrGO63LT7j2UxniW)
		elif '/seasons/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,393,CrGO63LT7j2UxniW)
		elif '/collection/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,391,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,392,CrGO63LT7j2UxniW)
	if type not in ['featured_movies','featured_tvshows']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,391,'','',type)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,'url')
	url = url.replace(NGmuWwXdLQ6nMltx39FYECohJ,JJTrn6SEtYZV31eyR97)
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FAJERSHOW-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('class="C rated".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<ul class="episodios">(.*?)</ul></div></div></div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,392,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = qdMurfa5o7CbOKU6xE(Z7uFdWIRv9ybj0,'GET',url,'','','FAJERSHOW-PLAY-1st')
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('class="C rated".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	YYmyQXglbEewzL3IA2Sd = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0][0]
		items = ZXFs0mEPR8qI2zj.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for type,yVEAeqBJpG,k4GrN6zDaX5U,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+yVEAeqBJpG+'&nume='+k4GrN6zDaX5U+'&type='+type
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD,EWMGN9wslbO5qRn34Sy in items:
			if '=' in CrGO63LT7j2UxniW:
				rTl7PF3UpGNJkiEs6BvCK = CrGO63LT7j2UxniW.split('=')[1]
				title = d78KRnJmBWscGua0XMk(rTl7PF3UpGNJkiEs6BvCK,'host')
			else: title = ''
			title = EWMGN9wslbO5qRn34Sy+' '+title
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download____'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
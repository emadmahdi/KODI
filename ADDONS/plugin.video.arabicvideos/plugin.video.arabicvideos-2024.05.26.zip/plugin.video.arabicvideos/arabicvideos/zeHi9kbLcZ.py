# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'CIMALIGHT'
W74fAyGxODoLPs5vMX2l8C93R = '_CML_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['قنوات فضائية']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==470: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==471: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==472: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==473: HkKfQCS7RIa4xi3houjvl = O3lxqtGmRwku(url,text)
	elif mode==474: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==479: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','CIMALIGHT-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = ZXFs0mEPR8qI2zj.findall('"url": "(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	pp5vX2CWHBtwOPzdq0Junij7 = pp5vX2CWHBtwOPzdq0Junij7[0].strip('/')
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(pp5vX2CWHBtwOPzdq0Junij7,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"content"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = title.replace('  ','').strip(' ')
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('cat=online-movies1','cat=online-movies')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,474)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('/category.php">(.*?)"navslide-divider"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("'dropdown-menu'(.*?)</ul>",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,474)
	return
def yPzYJU5Wup8(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if 'topvideos.php' in url: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"caret"(.*?)id="pm-grid"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"caret"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if 'topvideos.php' in RRucmYBaXegTtNOdGHMQ:
				if 'topvideos.php?c=english-movies' in RRucmYBaXegTtNOdGHMQ: continue
				if 'topvideos.php?c=online-movies1' in RRucmYBaXegTtNOdGHMQ: continue
				if 'topvideos.php?c=misc' in RRucmYBaXegTtNOdGHMQ: continue
				if 'topvideos.php?c=tv-channel' in RRucmYBaXegTtNOdGHMQ: continue
				if 'منذ البداية' in title and 'do=rating' not in RRucmYBaXegTtNOdGHMQ: continue
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,471)
	else: RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,l3UpyxrXZ2=''):
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	items = []
	if l3UpyxrXZ2=='featured_movies':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"container-fluid"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		R28S4pFmAojEW7CGnx,mwXy4HaY1uWtlvbZVcN7,NbhgF0qKnB4ZMA6 = zip(*items)
		items = zip(NbhgF0qKnB4ZMA6,R28S4pFmAojEW7CGnx,mwXy4HaY1uWtlvbZVcN7)
	elif l3UpyxrXZ2=='featured_series':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('المسلسلات المميزة(.*?)<style>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		R28S4pFmAojEW7CGnx,mwXy4HaY1uWtlvbZVcN7,NbhgF0qKnB4ZMA6 = zip(*items)
		items = zip(NbhgF0qKnB4ZMA6,R28S4pFmAojEW7CGnx,mwXy4HaY1uWtlvbZVcN7)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(data-echo=".*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"BlocksList"(.*?)"titleSectionCon"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="pm-grid"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="pm-related"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pm-ul-browse-videos(.*?)clearfix',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: return
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not items: items = ZXFs0mEPR8qI2zj.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if not items: items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/'+RRucmYBaXegTtNOdGHMQ.strip('/')
		if 'http' not in CrGO63LT7j2UxniW: CrGO63LT7j2UxniW = pp5vX2CWHBtwOPzdq0Junij7+'/'+CrGO63LT7j2UxniW.strip('/')
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|حلقة) \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			title = '_MOD_'+title
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,472,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and 'حلقة' in title:
			title = '_MOD_'+LqYKJ36CBG[0][0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,473,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/movseries/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,471,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,473,CrGO63LT7j2UxniW)
	if l3UpyxrXZ2 not in ['featured_movies','featured_series']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if RRucmYBaXegTtNOdGHMQ=='#': continue
				RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/'+RRucmYBaXegTtNOdGHMQ.strip('/')
				title = qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,471)
		Yt06jaVmgoDfUOu = ZXFs0mEPR8qI2zj.findall('showmore" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if Yt06jaVmgoDfUOu:
			RRucmYBaXegTtNOdGHMQ = Yt06jaVmgoDfUOu[0]
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مشاهدة المزيد',RRucmYBaXegTtNOdGHMQ,471)
	return
def O3lxqtGmRwku(url,xnu0LVmQHZEUyd9re8oKficb7):
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"SeasonsBox"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	items = []
	if Wgapb9wyGrVHo0 and not xnu0LVmQHZEUyd9re8oKficb7:
		CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('"series-header".*?src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0] if CrGO63LT7j2UxniW else ''
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		items = ZXFs0mEPR8qI2zj.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if len(items)==1: xnu0LVmQHZEUyd9re8oKficb7 = items[0][0]
		elif len(items)>1:
			for xnu0LVmQHZEUyd9re8oKficb7,title in items: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,473,CrGO63LT7j2UxniW,'',xnu0LVmQHZEUyd9re8oKficb7)
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('id="'+xnu0LVmQHZEUyd9re8oKficb7+'"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if CCqaV18lM0OL and len(items)<2:
		CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('"series-header".*?src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0] if CrGO63LT7j2UxniW else ''
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if items:
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = title.replace('ماي سيما','').replace('مسلسل','').strip(' ')
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/'+RRucmYBaXegTtNOdGHMQ.strip('/')
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,472,CrGO63LT7j2UxniW)
		else:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/'+RRucmYBaXegTtNOdGHMQ.strip('/')
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,472,CrGO63LT7j2UxniW)
	if 'id="pm-related"' in QstumvzTIEUMXCcx06aD4y8nSqH:
		if items: Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مواضيع ذات صلة',url,471)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd = []
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<div itemprop="description">(.*?)href=',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('<p>(.*?)</p>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg,True): return
	lQHXdV9Nzf6BLqS8D = url.replace('/watch.php','/play.php')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','CIMALIGHT-PLAY-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	iatNC81pnuWyXEcSQl6ewok = []
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('"embedURL" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]
		if RRucmYBaXegTtNOdGHMQ and RRucmYBaXegTtNOdGHMQ not in iatNC81pnuWyXEcSQl6ewok:
			iatNC81pnuWyXEcSQl6ewok.append(RRucmYBaXegTtNOdGHMQ)
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named=__embed'
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	items = ZXFs0mEPR8qI2zj.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if RRucmYBaXegTtNOdGHMQ not in iatNC81pnuWyXEcSQl6ewok:
			iatNC81pnuWyXEcSQl6ewok.append(RRucmYBaXegTtNOdGHMQ)
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	lQHXdV9Nzf6BLqS8D = url.replace('/watch.php','/downloads.php')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','CIMALIGHT-PLAY-3rd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"downloadlist"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<strong>(.*?)</strong>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if RRucmYBaXegTtNOdGHMQ not in iatNC81pnuWyXEcSQl6ewok:
				iatNC81pnuWyXEcSQl6ewok.append(RRucmYBaXegTtNOdGHMQ)
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(JJTrn6SEtYZV31eyR97,'url')
	url = NGmuWwXdLQ6nMltx39FYECohJ+'/search.php?keywords='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
﻿# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
def hLD0mk9HIuPOz7pw(Q6FbqZ9uIe8v2xaTHhfDCJ,apUdfIBTF7geqA62S):
	if apUdfIBTF7geqA62S=='': return
	if Q6FbqZ9uIe8v2xaTHhfDCJ==1:
		OXo0Ic9v7KUEYDg = yOuHBDmPps3vd24cnLagiK0.getCurrentWindowDialogId()
		b6zelCX9S2f = yOuHBDmPps3vd24cnLagiK0.Window(OXo0Ic9v7KUEYDg)
		apUdfIBTF7geqA62S = mL8hMBHF5CjbJk(apUdfIBTF7geqA62S)
		b6zelCX9S2f.getControl(311).setLabel(apUdfIBTF7geqA62S)
	if Q6FbqZ9uIe8v2xaTHhfDCJ==0:
		xEc7nR3qoAlv6C8YjD='X'
		if Nnxm30dfoBWRYpIC7KsQGl: PTQK1g5t9kwrhzSa4svmpUZAV = isinstance(apUdfIBTF7geqA62S,str)
		else: PTQK1g5t9kwrhzSa4svmpUZAV = isinstance(apUdfIBTF7geqA62S,unicode)
		if PTQK1g5t9kwrhzSa4svmpUZAV==True: xEc7nR3qoAlv6C8YjD='U'
		YVjOw6CaAW5K4o=str(type(apUdfIBTF7geqA62S))+' '+apUdfIBTF7geqA62S+' '+xEc7nR3qoAlv6C8YjD+' '
		for PXBFxvuUlLDHGpm58 in range(0,len(apUdfIBTF7geqA62S),1):
			YVjOw6CaAW5K4o += hex(ord(apUdfIBTF7geqA62S[PXBFxvuUlLDHGpm58])).replace('0x','')+' '
		apUdfIBTF7geqA62S = mL8hMBHF5CjbJk(apUdfIBTF7geqA62S)
		xEc7nR3qoAlv6C8YjD='X'
		if Nnxm30dfoBWRYpIC7KsQGl: PTQK1g5t9kwrhzSa4svmpUZAV = isinstance(apUdfIBTF7geqA62S, str)
		else: PTQK1g5t9kwrhzSa4svmpUZAV = isinstance(apUdfIBTF7geqA62S, unicode)
		if PTQK1g5t9kwrhzSa4svmpUZAV==True: xEc7nR3qoAlv6C8YjD='U'
		rrIfRtohybGUz2PnMKVNgXA6l0aW=str(type(apUdfIBTF7geqA62S))+' '+apUdfIBTF7geqA62S+' '+xEc7nR3qoAlv6C8YjD+' '
		for PXBFxvuUlLDHGpm58 in range(0,len(apUdfIBTF7geqA62S),1):
			rrIfRtohybGUz2PnMKVNgXA6l0aW += hex(ord(apUdfIBTF7geqA62S[PXBFxvuUlLDHGpm58])).replace('0x','')+' '
	return
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'CIMACLUP'
JE7QrkmhletLwA0OZXu = '_CMC_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['موقع نتفليكس']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==490: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==491: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==492: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==493: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==494: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==499: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text,url)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','CIMACLUP-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = QPuHKNAT4jmCRg.findall('href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ka6I93CnvublQMtjr = ka6I93CnvublQMtjr[0].strip('/')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(ka6I93CnvublQMtjr,'url')
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"filter AjaxifyFilter"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kk73xHNzri1P2wgULMv4sDtoTnybO:
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('data-filter="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/old/filter/'+VV7yf2htDCBU6EeSX8TJQM+'.php'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,491)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أفلام',ka6I93CnvublQMtjr+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مسلسلات',ka6I93CnvublQMtjr+'/category/مسلسلات/مسلسلات-اجنبى',494,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="navigation-menu"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if VV7yf2htDCBU6EeSX8TJQM=='/': continue
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+VV7yf2htDCBU6EeSX8TJQM
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,491)
	return Ht6Gg8lbciAd9FaUQVs
def pF0d4b2ZY9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMACLUP-SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"filter"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,491)
	return
def SPFl6UGK4mrBua(url,oN6FKz2SkGiLnJ3tx4=''):
	items = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMACLUP-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	wltPGJcYo12Ed = ''
	if '.php' in url: wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
	elif '?s=' in url:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"blocks(.*?)"manifest"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"Blocks(.*?)"manifest"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
	if not wltPGJcYo12Ed: return
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) حلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if not CiZxgXTGW9pv: CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if not CiZxgXTGW9pv or any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,492,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and 'حلقة' in title:
			title = '_MOD_' + CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,493,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,493,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<li><a href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = title.replace('الصفحة ','')
			if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,491)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMACLUP-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('"ButtonsBarCo".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','CIMACLUP-EPISODES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"img-responsive" src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
	else: G2WR0Oacvdq8ZQTjKboDU = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Thumb')
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"filter"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"Blocks(.*?)class="pagination"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO and '/series/' not in url:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,493,G2WR0Oacvdq8ZQTjKboDU)
	elif kk73xHNzri1P2wgULMv4sDtoTnybO:
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
				title = title.strip(' ')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,492,G2WR0Oacvdq8ZQTjKboDU)
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				title = title.replace('الصفحة ','')
				if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,491)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.strip('/')+'/?view=1'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','CIMACLUP-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	RRtUaOkQKgPCJTvFYz0 = QPuHKNAT4jmCRg.findall("data: 'q=(.*?)&",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	RRtUaOkQKgPCJTvFYz0 = RRtUaOkQKgPCJTvFYz0[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"serversList"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('data-server="(.*?)">(.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for uYFAR9lIDC3LZG7sTfcUwkyNna,title in items:
			title = title.strip(' ')
			VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/old/servers/server.php?q='+RRtUaOkQKgPCJTvFYz0+'&i='+uYFAR9lIDC3LZG7sTfcUwkyNna+'?named='+title+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"embedServer".*?SRC="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		title = 'مفضل'
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]+'?named=__embed__'+title
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"downloadsList"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<td>(.*?)</td>.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			title = title.strip(' ')
			if 'anavidz' in VV7yf2htDCBU6EeSX8TJQM: nUbpaNT0vhcj7ZsEz = '__خاص'
			else: nUbpaNT0vhcj7ZsEz = ''
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'+nUbpaNT0vhcj7ZsEz
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search,ka6I93CnvublQMtjr=''):
	if not ka6I93CnvublQMtjr: ka6I93CnvublQMtjr = GqcEfFR8XQPgBMLr
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	search = search.replace(' ','+')
	url = ka6I93CnvublQMtjr+'/index.php?s='+search
	SPFl6UGK4mrBua(url)
	return
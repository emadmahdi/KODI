# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'IFILM'
JE7QrkmhletLwA0OZXu = '_IFL_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
FWpjdmYqwgi = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][1]
CN9FtxiBuYWm0slAG = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][2]
mE2qbSxgAnGt78BRlNLPTehaFs = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][3]
def hLD0mk9HIuPOz7pw(mode,url,YSTbrKgPf7NyhIDizB,text):
	if   mode==20: RRMWBwU6pG = IQ2aXWqubCBs1cP8DMjhxEm()
	elif mode==21: RRMWBwU6pG = YpFfN68PZ132(url)
	elif mode==22: RRMWBwU6pG = SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB)
	elif mode==23: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,YSTbrKgPf7NyhIDizB)
	elif mode==24: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url,text)
	elif mode==25: RRMWBwU6pG = HLynIxhJjBiE0W2T4Qzel3pwF91(url)
	elif mode==27: RRMWBwU6pG = ppwOVfWkqTKEsUnghz(url)
	elif mode==28: RRMWBwU6pG = H3zpMbWVSleuk()
	elif mode==29: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def IQ2aXWqubCBs1cP8DMjhxEm():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'عربي',GqcEfFR8XQPgBMLr,21,'','101')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'English',FWpjdmYqwgi,21,'','101')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فارسى',CN9FtxiBuYWm0slAG,21,'','101')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فارسى 2',mE2qbSxgAnGt78BRlNLPTehaFs,21,'','101')
	return
def H3zpMbWVSleuk():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+'عربي',GqcEfFR8XQPgBMLr,27)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+'English',FWpjdmYqwgi,27)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+'فارسى',CN9FtxiBuYWm0slAG,27)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+'فارسى 2',mE2qbSxgAnGt78BRlNLPTehaFs,27)
	return
def YpFfN68PZ132(FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee):
	mm5vCBc4DOz2Fj = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee
	if FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee=='IFILM-ARABIC': FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee = GqcEfFR8XQPgBMLr
	elif FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee=='IFILM-ENGLISH': FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee = FWpjdmYqwgi
	else: mm5vCBc4DOz2Fj = ''
	ooR6tf4gCTFXP7 = VVSMYC1j4U6D(FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee)
	if ooR6tf4gCTFXP7=='ar' or mm5vCBc4DOz2Fj=='IFILM-ARABIC':
		cIPuTp46CiymQ0aRg = 'بحث في الموقع'
		OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = 'مسلسلات - حالية'
		Vuk3760YmGdQaZ92MfwcNKE = 'مسلسلات - أحدث'
		Js3EvhptYNzA9fPXjLZrOF7kd2 = 'مسلسلات - أبجدي'
		RRHMUSfOL29hbagdQVnBJu = 'بث حي آي فيلم'
		LePMS3VYoGr9b2THdDFg5QzniEZNl = 'أفلام'
		lQ0iexFNaXdgVtMrKv2IbOcm4Uo = 'موسيقى'
		LyWbMkglpZz = 'برامج'
	elif ooR6tf4gCTFXP7=='en' or mm5vCBc4DOz2Fj=='IFILM-ENGLISH':
		cIPuTp46CiymQ0aRg = 'Search in site'
		OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = 'Series - Current'
		Vuk3760YmGdQaZ92MfwcNKE = 'Series - Latest'
		Js3EvhptYNzA9fPXjLZrOF7kd2 = 'Series - Alphabet'
		RRHMUSfOL29hbagdQVnBJu = 'Live iFilm channel'
		LePMS3VYoGr9b2THdDFg5QzniEZNl = 'Movies'
		lQ0iexFNaXdgVtMrKv2IbOcm4Uo = 'Music'
		LyWbMkglpZz = 'Shows'
	elif ooR6tf4gCTFXP7 in ['fa','fa2']:
		cIPuTp46CiymQ0aRg = 'جستجو در سایت'
		OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = 'سريال - جاری'
		Vuk3760YmGdQaZ92MfwcNKE = 'سريال - آخرین'
		Js3EvhptYNzA9fPXjLZrOF7kd2 = 'سريال - الفبا'
		RRHMUSfOL29hbagdQVnBJu = 'پخش زنده اي فيلم'
		LePMS3VYoGr9b2THdDFg5QzniEZNl = 'فيلم'
		lQ0iexFNaXdgVtMrKv2IbOcm4Uo = 'موسيقى'
		LyWbMkglpZz = 'برنامه ها'
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+cIPuTp46CiymQ0aRg,FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee,29,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+RRHMUSfOL29hbagdQVnBJu,FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee,27)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	zik0WubZQEGj9Ym35NqwF = ['Series','Program','Music']
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/home','','','','IFILM-MENU-1st')
	TTCRYZroizb=QPuHKNAT4jmCRg.findall('button-menu(.*?)/Contact',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if any(pp8iHB3W9Cs in VV7yf2htDCBU6EeSX8TJQM for pp8iHB3W9Cs in zik0WubZQEGj9Ym35NqwF):
				url = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+VV7yf2htDCBU6EeSX8TJQM
				if 'Series' in VV7yf2htDCBU6EeSX8TJQM:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,url,22,'','100')
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+Vuk3760YmGdQaZ92MfwcNKE,url,22,'','101')
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+Js3EvhptYNzA9fPXjLZrOF7kd2,url,22,'','201')
				elif 'Film' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+LePMS3VYoGr9b2THdDFg5QzniEZNl,url,22,'','100')
				elif 'Music' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+lQ0iexFNaXdgVtMrKv2IbOcm4Uo,url,25,'','101')
				elif 'Program' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+LyWbMkglpZz,url,22,'','101')
	return Ht6Gg8lbciAd9FaUQVs
def HLynIxhJjBiE0W2T4Qzel3pwF91(url):
	FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee = TrSBn46MFeYUC10R(url)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'','','','IFILM-MUSIC_MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('Music-tools-header(.*?)Music-body',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	title = QPuHKNAT4jmCRg.findall('<p>(.*?)</p>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)[0]
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,22,'','101')
	items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + VV7yf2htDCBU6EeSX8TJQM
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,23,'','101')
	return
def SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB):
	FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee = TrSBn46MFeYUC10R(url)
	ooR6tf4gCTFXP7 = VVSMYC1j4U6D(url)
	type = url.split('/')[-1]
	gyq1vEmcFxldeoW = str(int(YSTbrKgPf7NyhIDizB)//100)
	YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)%100)
	if type=='Series' and YSTbrKgPf7NyhIDizB=='0':
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','','','IFILM-TITLES-1st')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('serial-body(.*?)class="row',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			title = kWfpQA7tTjSPyLbNIeMr1Hui5(title)
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			VV7yf2htDCBU6EeSX8TJQM = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + VV7yf2htDCBU6EeSX8TJQM
			G2WR0Oacvdq8ZQTjKboDU = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,23,G2WR0Oacvdq8ZQTjKboDU,gyq1vEmcFxldeoW+'01')
	kkDwsKNMG5xdcbj9BA84VCQe=0
	if type=='Series': jsEpRxQH76='3'
	if type=='Film': jsEpRxQH76='5'
	if type=='Program': jsEpRxQH76='7'
	if type in ['Series','Program','Film'] and YSTbrKgPf7NyhIDizB!='0':
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Home/PageingItem?category='+jsEpRxQH76+'&page='+YSTbrKgPf7NyhIDizB+'&size=30&orderby='+gyq1vEmcFxldeoW
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-TITLES-2nd')
		items = QPuHKNAT4jmCRg.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for id,title,G2WR0Oacvdq8ZQTjKboDU in items:
			title = kWfpQA7tTjSPyLbNIeMr1Hui5(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			kkDwsKNMG5xdcbj9BA84VCQe += 1
			VV7yf2htDCBU6EeSX8TJQM = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + '/' + type + '/Content/' + id
			G2WR0Oacvdq8ZQTjKboDU = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
			if type=='Film': fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,24,G2WR0Oacvdq8ZQTjKboDU,gyq1vEmcFxldeoW+'01')
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,23,G2WR0Oacvdq8ZQTjKboDU,gyq1vEmcFxldeoW+'01')
	if type=='Music':
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Music/Index?page='+YSTbrKgPf7NyhIDizB,'','','','IFILM-TITLES-3rd')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('pagination-demo(.*?)pagination-demo',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			kkDwsKNMG5xdcbj9BA84VCQe += 1
			G2WR0Oacvdq8ZQTjKboDU = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + G2WR0Oacvdq8ZQTjKboDU
			VV7yf2htDCBU6EeSX8TJQM = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee + VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,23,G2WR0Oacvdq8ZQTjKboDU,'101')
	if kkDwsKNMG5xdcbj9BA84VCQe>20:
		title='صفحة '
		if ooR6tf4gCTFXP7=='en': title = 'Page '
		if ooR6tf4gCTFXP7=='fa': title = 'صفحه '
		if ooR6tf4gCTFXP7=='fa2': title = 'صفحه '
		for HYW8ge29T6OiEpbPl in range(1,11) :
			if not YSTbrKgPf7NyhIDizB==str(HYW8ge29T6OiEpbPl):
				YT91DMLpb2BrFIZEiVewHcovazP = '0'+str(HYW8ge29T6OiEpbPl)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title+str(HYW8ge29T6OiEpbPl),url,22,'',gyq1vEmcFxldeoW+YT91DMLpb2BrFIZEiVewHcovazP[-2:])
	return
def opLlxOB2dUVZ5JF4j(url,YSTbrKgPf7NyhIDizB):
	if not YSTbrKgPf7NyhIDizB: YSTbrKgPf7NyhIDizB = 0
	FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee = TrSBn46MFeYUC10R(url)
	Qc0l2ofbVvZDM = TrSBn46MFeYUC10R(url)
	ooR6tf4gCTFXP7 = VVSMYC1j4U6D(url)
	FtKo2AMUynNdTaYCljkxOe = url.split('/')
	id,type = FtKo2AMUynNdTaYCljkxOe[-1],FtKo2AMUynNdTaYCljkxOe[3]
	gyq1vEmcFxldeoW = str(int(YSTbrKgPf7NyhIDizB)//100)
	YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)%100)
	kkDwsKNMG5xdcbj9BA84VCQe = 0
	if type=='Series':
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','','','IFILM-EPISODES-1st')
		items = QPuHKNAT4jmCRg.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		title = ' - الحلقة '
		if ooR6tf4gCTFXP7=='en': title = ' - Episode '
		if ooR6tf4gCTFXP7=='fa': title = ' - قسمت '
		if ooR6tf4gCTFXP7=='fa2': title = ' - قسمت '
		if ooR6tf4gCTFXP7=='fa': ADdIbg9pXtcOKUy = ''
		else: ADdIbg9pXtcOKUy = ooR6tf4gCTFXP7
		Duvjq9NHws4tRM8ElZIaXL = QPuHKNAT4jmCRg.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for name,count,G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM in items:
			for CiZxgXTGW9pv in range(int(count),0,-1):
				JVcZGH5BNOp6usaoqX = G2WR0Oacvdq8ZQTjKboDU + ADdIbg9pXtcOKUy + id + '/' + str(CiZxgXTGW9pv) + '.png'
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = name + title + str(CiZxgXTGW9pv)
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = UH1IuvwM9e4cl7if63nNdozJFSj(OnQ71fzhCAbTwMBg0kPxjG4i5VdSep)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,url,24,JVcZGH5BNOp6usaoqX,'',str(CiZxgXTGW9pv))
	elif type=='Program':
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+YSTbrKgPf7NyhIDizB+'&size=30&orderby=1'
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-EPISODES-2nd')
		items = QPuHKNAT4jmCRg.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		title = ' - الحلقة '
		if ooR6tf4gCTFXP7=='en': title = ' - Episode '
		if ooR6tf4gCTFXP7=='fa': title = ' - قسمت '
		if ooR6tf4gCTFXP7=='fa2': title = ' - قسمت '
		for CiZxgXTGW9pv,G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,hf0XPkRmBaTtVWc8liJZ,name in items:
			kkDwsKNMG5xdcbj9BA84VCQe += 1
			JVcZGH5BNOp6usaoqX = Qc0l2ofbVvZDM + oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
			name = kWfpQA7tTjSPyLbNIeMr1Hui5(name)
			OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = name + title + str(CiZxgXTGW9pv)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,24,JVcZGH5BNOp6usaoqX,'',str(kkDwsKNMG5xdcbj9BA84VCQe))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Music/GetTracksBy?id='+str(id)+'&page='+YSTbrKgPf7NyhIDizB+'&size=30&type=0'
			Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-EPISODES-3rd')
			items = QPuHKNAT4jmCRg.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,name,title in items:
				kkDwsKNMG5xdcbj9BA84VCQe += 1
				JVcZGH5BNOp6usaoqX = Qc0l2ofbVvZDM + oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = name + ' - ' + title
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = OnQ71fzhCAbTwMBg0kPxjG4i5VdSep.strip(' ')
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = kWfpQA7tTjSPyLbNIeMr1Hui5(OnQ71fzhCAbTwMBg0kPxjG4i5VdSep)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,24,JVcZGH5BNOp6usaoqX,'',str(kkDwsKNMG5xdcbj9BA84VCQe))
		elif 'Clips' in url:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Music/GetTracksBy?id=0&page='+YSTbrKgPf7NyhIDizB+'&size=30&type=15'
			Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-EPISODES-4th')
			items = QPuHKNAT4jmCRg.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			for G2WR0Oacvdq8ZQTjKboDU,title,VV7yf2htDCBU6EeSX8TJQM in items:
				kkDwsKNMG5xdcbj9BA84VCQe += 1
				JVcZGH5BNOp6usaoqX = Qc0l2ofbVvZDM + oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = title.strip(' ')
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = kWfpQA7tTjSPyLbNIeMr1Hui5(OnQ71fzhCAbTwMBg0kPxjG4i5VdSep)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,24,JVcZGH5BNOp6usaoqX,'',str(kkDwsKNMG5xdcbj9BA84VCQe))
		elif 'category' in url:
			if 'category=6' in url:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Music/GetTracksBy?id=0&page='+YSTbrKgPf7NyhIDizB+'&size=30&type=6'
				Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FNa3HsGz6S9LRM1lXxrWuDwPbU7Ee+'/Music/GetTracksBy?id=0&page='+YSTbrKgPf7NyhIDizB+'&size=30&type=4'
				Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-EPISODES-6th')
			items = QPuHKNAT4jmCRg.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,name,title in items:
				kkDwsKNMG5xdcbj9BA84VCQe += 1
				JVcZGH5BNOp6usaoqX = Qc0l2ofbVvZDM + oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = name + ' - ' + title
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = OnQ71fzhCAbTwMBg0kPxjG4i5VdSep.strip(' ')
				OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = kWfpQA7tTjSPyLbNIeMr1Hui5(OnQ71fzhCAbTwMBg0kPxjG4i5VdSep)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,24,JVcZGH5BNOp6usaoqX,'',str(kkDwsKNMG5xdcbj9BA84VCQe))
	if type=='Music' or type=='Program':
		if kkDwsKNMG5xdcbj9BA84VCQe>25:
			title='صفحة '
			if ooR6tf4gCTFXP7=='en': title = ' Page '
			if ooR6tf4gCTFXP7=='fa': title = ' صفحه '
			if ooR6tf4gCTFXP7=='fa2': title = ' صفحه '
			for HYW8ge29T6OiEpbPl in range(1,11):
				if not YSTbrKgPf7NyhIDizB==str(HYW8ge29T6OiEpbPl):
					YT91DMLpb2BrFIZEiVewHcovazP = '0'+str(HYW8ge29T6OiEpbPl)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title+str(HYW8ge29T6OiEpbPl),url,23,'',gyq1vEmcFxldeoW+YT91DMLpb2BrFIZEiVewHcovazP[-2:])
	return
def unQmcpAEF2DaNX87fTgMW(url,CiZxgXTGW9pv):
	Qc0l2ofbVvZDM = TrSBn46MFeYUC10R(url)
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','','','IFILM-PLAY-1st')
	items = QPuHKNAT4jmCRg.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		ooR6tf4gCTFXP7 = VVSMYC1j4U6D(url)
		FtKo2AMUynNdTaYCljkxOe = url.split('/')
		id,type = FtKo2AMUynNdTaYCljkxOe[-1],FtKo2AMUynNdTaYCljkxOe[3]
		VV7yf2htDCBU6EeSX8TJQM = items[0][0]+ooR6tf4gCTFXP7+id+'/,'+CiZxgXTGW9pv+','+CiZxgXTGW9pv+'_'+items[0][2]
		xitERh4TD2jGJPq5Nuv39CAmg.append('m3u8')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	items = QPuHKNAT4jmCRg.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		ooR6tf4gCTFXP7 = VVSMYC1j4U6D(url)
		FtKo2AMUynNdTaYCljkxOe = url.split('/')
		id,type = FtKo2AMUynNdTaYCljkxOe[-1],FtKo2AMUynNdTaYCljkxOe[3]
		VV7yf2htDCBU6EeSX8TJQM = items[0][0]+ooR6tf4gCTFXP7+id+'/'+CiZxgXTGW9pv+items[0][2]
		xitERh4TD2jGJPq5Nuv39CAmg.append('mp4 url')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	items = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM in items:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('//','/')
		xitERh4TD2jGJPq5Nuv39CAmg.append('mp4 src')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	items = QPuHKNAT4jmCRg.findall('VideoAddress":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		VV7yf2htDCBU6EeSX8TJQM = items[int(CiZxgXTGW9pv)-1]
		VV7yf2htDCBU6EeSX8TJQM = Qc0l2ofbVvZDM+oF0Yr4V7Ic(VV7yf2htDCBU6EeSX8TJQM)
		xitERh4TD2jGJPq5Nuv39CAmg.append('mp4 address')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	items = QPuHKNAT4jmCRg.findall('VoiceAddress":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		VV7yf2htDCBU6EeSX8TJQM = items[int(CiZxgXTGW9pv)-1]
		VV7yf2htDCBU6EeSX8TJQM = Qc0l2ofbVvZDM+oF0Yr4V7Ic(VV7yf2htDCBU6EeSX8TJQM)
		xitERh4TD2jGJPq5Nuv39CAmg.append('mp3 address')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==1: VV7yf2htDCBU6EeSX8TJQM = LL8heV7kxYI5bOjEZ6XaUQWwfPA[0]
	else:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الفيديو المناسب:', xitERh4TD2jGJPq5Nuv39CAmg)
		if ShT1xUHjlDotkRuPq7gv == -1 : return
		VV7yf2htDCBU6EeSX8TJQM = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	zT3xJQIVDmCgapBljs(VV7yf2htDCBU6EeSX8TJQM,mm5vCBc4DOz2Fj,'video')
	return
def TrSBn46MFeYUC10R(url):
	if GqcEfFR8XQPgBMLr in url: Xt7olBPDuFS4diy1 = GqcEfFR8XQPgBMLr
	elif FWpjdmYqwgi in url: Xt7olBPDuFS4diy1 = FWpjdmYqwgi
	elif CN9FtxiBuYWm0slAG in url: Xt7olBPDuFS4diy1 = CN9FtxiBuYWm0slAG
	elif mE2qbSxgAnGt78BRlNLPTehaFs in url: Xt7olBPDuFS4diy1 = mE2qbSxgAnGt78BRlNLPTehaFs
	else: Xt7olBPDuFS4diy1 = ''
	return Xt7olBPDuFS4diy1
def VVSMYC1j4U6D(url):
	if   GqcEfFR8XQPgBMLr in url: ooR6tf4gCTFXP7 = 'ar'
	elif FWpjdmYqwgi in url: ooR6tf4gCTFXP7 = 'en'
	elif CN9FtxiBuYWm0slAG in url: ooR6tf4gCTFXP7 = 'fa'
	elif mE2qbSxgAnGt78BRlNLPTehaFs in url: ooR6tf4gCTFXP7 = 'fa2'
	else: ooR6tf4gCTFXP7 = ''
	return ooR6tf4gCTFXP7
def ppwOVfWkqTKEsUnghz(url):
	ooR6tf4gCTFXP7 = VVSMYC1j4U6D(url)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url + '/Home/Live'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','IFILM-LIVE-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lc154VhT9DCqMk8 = items[0]
	zT3xJQIVDmCgapBljs(lc154VhT9DCqMk8,mm5vCBc4DOz2Fj,'live')
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','+')
	if showDialogs:
		u9w3AN4bOqK0MCQ8sLzg7ocSaxDX1R = [ GqcEfFR8XQPgBMLr , FWpjdmYqwgi , CN9FtxiBuYWm0slAG , mE2qbSxgAnGt78BRlNLPTehaFs ]
		hRicT4yFJ5ZbMPK2tVews = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر اللغة المناسبة:', hRicT4yFJ5ZbMPK2tVews)
		if ShT1xUHjlDotkRuPq7gv == -1 : return
		website = u9w3AN4bOqK0MCQ8sLzg7ocSaxDX1R[ShT1xUHjlDotkRuPq7gv]
	else:
		if '_IFILM-ARABIC_' in vwIN38HprDqTW5Sh61exF7EnA: website = GqcEfFR8XQPgBMLr
		elif '_IFILM-ENGLISH_' in vwIN38HprDqTW5Sh61exF7EnA: website = FWpjdmYqwgi
		else: website = ''
	if not website: return
	ooR6tf4gCTFXP7 = VVSMYC1j4U6D(website)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = website + "/Home/Search?searchstring=" + Unr6jRmMIv80lSGbkBCehpaWAdV
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','IFILM-SEARCH-1st')
	items = QPuHKNAT4jmCRg.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		for G2WR0Oacvdq8ZQTjKboDU,jsEpRxQH76,id,title in items:
			if jsEpRxQH76 in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if jsEpRxQH76=='3':
					type = 'Series'
					if ooR6tf4gCTFXP7=='ar': name = 'مسلسل : '
					elif ooR6tf4gCTFXP7=='en': name = 'Series : '
					elif ooR6tf4gCTFXP7=='fa': name = 'سريال ها : '
					elif ooR6tf4gCTFXP7=='fa2': name = 'سريال ها : '
				elif jsEpRxQH76=='5':
					type = 'Film'
					if ooR6tf4gCTFXP7=='ar': name = 'فيلم : '
					elif ooR6tf4gCTFXP7=='en': name = 'Movie : '
					elif ooR6tf4gCTFXP7=='fa': name = 'فيلم : '
					elif ooR6tf4gCTFXP7=='fa2': name = 'فلم ها : '
				elif jsEpRxQH76=='7':
					type = 'Program'
					if ooR6tf4gCTFXP7=='ar': name = 'برنامج : '
					elif ooR6tf4gCTFXP7=='en': name = 'Program : '
					elif ooR6tf4gCTFXP7=='fa': name = 'برنامه ها : '
					elif ooR6tf4gCTFXP7=='fa2': name = 'برنامه ها : '
				title = name + title
				VV7yf2htDCBU6EeSX8TJQM = website + '/' + type + '/Content/' + id
				G2WR0Oacvdq8ZQTjKboDU = oF0Yr4V7Ic(G2WR0Oacvdq8ZQTjKboDU)
				G2WR0Oacvdq8ZQTjKboDU = website+G2WR0Oacvdq8ZQTjKboDU
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,23,G2WR0Oacvdq8ZQTjKboDU,'101')
	return
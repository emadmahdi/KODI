# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'TVFUN'
JE7QrkmhletLwA0OZXu = '_TVF_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['بث مباشر']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==460: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==461: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==462: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==463: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==469: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','TVFUN-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"menu-btn"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,461)
	return
def SPFl6UGK4mrBua(url,oN6FKz2SkGiLnJ3tx4=''):
	items = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','TVFUN-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="head-title"(.*?)id="footer"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		gltHFKTroJfpLe = []
		OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,462,G2WR0Oacvdq8ZQTjKboDU)
			elif CiZxgXTGW9pv and 'الحلقة' in title:
				title = '_MOD_' + CiZxgXTGW9pv[0]
				if title not in gltHFKTroJfpLe:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,463,G2WR0Oacvdq8ZQTjKboDU)
					gltHFKTroJfpLe.append(title)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,463,G2WR0Oacvdq8ZQTjKboDU)
	if oN6FKz2SkGiLnJ3tx4!='latest':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('<a href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.strip(' ')
				if VV7yf2htDCBU6EeSX8TJQM=="": continue
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
				if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,461)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','TVFUN-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="head-title"(.*?)id="footer"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,462,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.strip(' ')
			if VV7yf2htDCBU6EeSX8TJQM=="": continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,463)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','TVFUN-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Ho7bIn9A21CfQ = QPuHKNAT4jmCRg.findall('"embedUrl": "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if Ho7bIn9A21CfQ:
		Ho7bIn9A21CfQ = Ho7bIn9A21CfQ[0]
		if 'http' not in Ho7bIn9A21CfQ:
			if '//' in Ho7bIn9A21CfQ: Ho7bIn9A21CfQ = 'http:'+Ho7bIn9A21CfQ
			else: Ho7bIn9A21CfQ = GqcEfFR8XQPgBMLr+Ho7bIn9A21CfQ
		Ho7bIn9A21CfQ = Ho7bIn9A21CfQ+'?named=__embed'
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(Ho7bIn9A21CfQ)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('VideoServers"(.*?)"Play"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for PVBk51YyXOnDcj0QwbI,name in Y4xiULzGTKjb8mulO:
			PVBk51YyXOnDcj0QwbI = PVBk51YyXOnDcj0QwbI[2:]
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: PVBk51YyXOnDcj0QwbI = PVBk51YyXOnDcj0QwbI.decode('utf8')
			PVBk51YyXOnDcj0QwbI = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(PVBk51YyXOnDcj0QwbI)
			if Nnxm30dfoBWRYpIC7KsQGl: PVBk51YyXOnDcj0QwbI = PVBk51YyXOnDcj0QwbI.decode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('src="(.*?)"',PVBk51YyXOnDcj0QwbI,QPuHKNAT4jmCRg.DOTALL)
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM:
				if '//' in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
				else: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	if ' ' in search:
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = GqcEfFR8XQPgBMLr+'/q/'+search+'/'
	SPFl6UGK4mrBua(url)
	return
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'ALARAB'
headers = {'User-Agent':''}
JE7QrkmhletLwA0OZXu = '_KLA_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==10: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==11: RRMWBwU6pG = SPFl6UGK4mrBua(url)
	elif mode==12: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==13: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==14: RRMWBwU6pG = YNtljB8xJEoSwiUZbAcI1aKHvsgh()
	elif mode==15: RRMWBwU6pG = nA6fEN8PCt()
	elif mode==16: RRMWBwU6pG = h1MBtynCr8xAqISR9vd2Dj7oOm()
	elif mode==19: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'آخر الإضافات','',14)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مسلسلات رمضان','',15)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','ALARAB-MENU-1st')
	TTCRYZroizb=QPuHKNAT4jmCRg.findall('id="nav-slider"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	xlWDvZsL80XV3nih = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',xlWDvZsL80XV3nih,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
		title = title.strip(' ')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="navbar"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	y8qSvx0Z9MY = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',y8qSvx0Z9MY,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,11)
	return Ht6Gg8lbciAd9FaUQVs
def nA6fEN8PCt():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'جميع المسلسلات العربية',GqcEfFR8XQPgBMLr+'/view-8/مسلسلات-عربية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات السنة الأخيرة','',16)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان الأخيرة 1',GqcEfFR8XQPgBMLr+'/view-8/مسلسلات-رمضان-2022',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان الأخيرة 2',GqcEfFR8XQPgBMLr+'/view-8/مسلسلات-رمضان-2023',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2023',GqcEfFR8XQPgBMLr+'/ramadan2023/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2022',GqcEfFR8XQPgBMLr+'/ramadan2022/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2021',GqcEfFR8XQPgBMLr+'/ramadan2021/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2020',GqcEfFR8XQPgBMLr+'/ramadan2020/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2019',GqcEfFR8XQPgBMLr+'/ramadan2019/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2018',GqcEfFR8XQPgBMLr+'/ramadan2018/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2017',GqcEfFR8XQPgBMLr+'/ramadan2017/مصرية',11)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رمضان 2016',GqcEfFR8XQPgBMLr+'/ramadan2016/مصرية',11)
	return
def YNtljB8xJEoSwiUZbAcI1aKHvsgh():
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,GqcEfFR8XQPgBMLr,'',headers,True,'ALARAB-LATEST-1st')
	TTCRYZroizb=QPuHKNAT4jmCRg.findall('heading-top(.*?)div class=',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]+TTCRYZroizb[1]
	items=QPuHKNAT4jmCRg.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		url = GqcEfFR8XQPgBMLr + VV7yf2htDCBU6EeSX8TJQM
		if 'series' in url: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,11,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,url,12,G2WR0Oacvdq8ZQTjKboDU)
	return
def SPFl6UGK4mrBua(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('video-category(.*?)right_content',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	VV7garqCfPMlbZTnzymGs946B = False
	items = QPuHKNAT4jmCRg.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe,PkbD315XqvpAKT8OoGIhZxetsd6M9c = [],[]
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if title=='': title = VV7yf2htDCBU6EeSX8TJQM.split('/')[-1].replace('-',' ')
		CfeaWGU28lvj4hoYRVwt6sy3p = QPuHKNAT4jmCRg.findall('(\d+)',title,QPuHKNAT4jmCRg.DOTALL)
		if CfeaWGU28lvj4hoYRVwt6sy3p: CfeaWGU28lvj4hoYRVwt6sy3p = int(CfeaWGU28lvj4hoYRVwt6sy3p[0])
		else: CfeaWGU28lvj4hoYRVwt6sy3p = 0
		PkbD315XqvpAKT8OoGIhZxetsd6M9c.append([G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title,CfeaWGU28lvj4hoYRVwt6sy3p])
	PkbD315XqvpAKT8OoGIhZxetsd6M9c = sorted(PkbD315XqvpAKT8OoGIhZxetsd6M9c, reverse=True, key=lambda key: key[3])
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title,CfeaWGU28lvj4hoYRVwt6sy3p in PkbD315XqvpAKT8OoGIhZxetsd6M9c:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr + VV7yf2htDCBU6EeSX8TJQM
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		nUbpaNT0vhcj7ZsEz = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
			if CiZxgXTGW9pv: nUbpaNT0vhcj7ZsEz = CiZxgXTGW9pv[0]
		if nUbpaNT0vhcj7ZsEz not in gltHFKTroJfpLe:
			gltHFKTroJfpLe.append(nUbpaNT0vhcj7ZsEz)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,VV7yf2htDCBU6EeSX8TJQM,13,G2WR0Oacvdq8ZQTjKboDU)
				VV7garqCfPMlbZTnzymGs946B = True
			elif 'series' in VV7yf2htDCBU6EeSX8TJQM:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,11,G2WR0Oacvdq8ZQTjKboDU)
				VV7garqCfPMlbZTnzymGs946B = True
			else:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,12,G2WR0Oacvdq8ZQTjKboDU)
				VV7garqCfPMlbZTnzymGs946B = True
	if VV7garqCfPMlbZTnzymGs946B:
		items = QPuHKNAT4jmCRg.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,YSTbrKgPf7NyhIDizB in items:
			url = GqcEfFR8XQPgBMLr + VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+YSTbrKgPf7NyhIDizB,url,11)
	return
def opLlxOB2dUVZ5JF4j(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,True,'ALARAB-EPISODES-1st')
	bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu = QPuHKNAT4jmCRg.findall('href="(/series.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu[0]
	RRMWBwU6pG = SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,True,'ALARAB-PLAY-1st')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('class="resp-iframe" src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('^(http.*?)(http.*?)$',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,QPuHKNAT4jmCRg.DOTALL)
		if Y4xiULzGTKjb8mulO:
			IP2cvAkDs87K9RjquUf60Xxy4e1d = Y4xiULzGTKjb8mulO[0][0]
			st9xXzZ2onYfKPriOvugQyE,soezS0bDYr3V9RKxMCQWtNa = Y4xiULzGTKjb8mulO[0][1].rsplit('/',1)
			lc154VhT9DCqMk8 = st9xXzZ2onYfKPriOvugQyE+'?named=__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(lc154VhT9DCqMk8)
			MPfKjlDAZTV6 = IP2cvAkDs87K9RjquUf60Xxy4e1d+soezS0bDYr3V9RKxMCQWtNa
		else:
			iRSILm7Nv6DZAaztp = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,False,'ALARAB-PLAY-2nd')
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('"src": "(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]+'?named=__watch__m3u8'
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('searchBox(.*?)<style>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]+'?named=__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def h1MBtynCr8xAqISR9vd2Dj7oOm():
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,True,'ALARAB-RAMADAN-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="content_sec"(.*?)id="left_content"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	RIScFJt4rLyXm = QPuHKNAT4jmCRg.findall('/ramadan([0-9]+)/',str(items),QPuHKNAT4jmCRg.DOTALL)
	RIScFJt4rLyXm = RIScFJt4rLyXm[0]
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		url = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
		title = title.strip(' ')+' '+RIScFJt4rLyXm
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,11)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr + "/q/" + Unr6jRmMIv80lSGbkBCehpaWAdV
	RRMWBwU6pG = SPFl6UGK4mrBua(url)
	return
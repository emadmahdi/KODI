# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'RESOLVERS'
My3IbejYugR8xLwk = []
headers = {'User-Agent':''}
dco65zne0R7lGBm = ['AKWAM','SHOOFMAX','IFILM','KARBALATV','ALMAAREF','SHIAVOICE','IPTV','M3U']
def DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,source,type,url):
	if not YsDryBSXquzdEUta8kxjfO:
		zRM3tZx2v6DjJU('ERROR_LINES',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		Xm4VWQHx8jzJvR2SLKZYEo3O = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'dict','MISC_PERM','SITES_ERRORS')
		lHvSOF9EpRL = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime('%Y.%m.%d %H:%M',vODi7LQeCnUaoRqZX9xs6djwm0tJA2.gmtime(Low1uSVG5OcafJmrYBC7D))
		ZmSt0LenHKEjq2BXQTz84vCO = lHvSOF9EpRL,url
		key = source+'    '+uVp7krjL48oWd3tqGYCRz5M+'    '+str(LRjqrQYBXFVPfu)
		qNEnDMwm1Vfastx2ZkpRh = ''
		if key not in list(Xm4VWQHx8jzJvR2SLKZYEo3O.keys()): Xm4VWQHx8jzJvR2SLKZYEo3O[key] = [ZmSt0LenHKEjq2BXQTz84vCO]
		else:
			if url not in str(Xm4VWQHx8jzJvR2SLKZYEo3O[key]): Xm4VWQHx8jzJvR2SLKZYEo3O[key].append(ZmSt0LenHKEjq2BXQTz84vCO)
			else: qNEnDMwm1Vfastx2ZkpRh = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		deHnPcoI5CQG8hVt4Zs = 0
		for key in list(Xm4VWQHx8jzJvR2SLKZYEo3O.keys()):
			Xm4VWQHx8jzJvR2SLKZYEo3O[key] = list(set(Xm4VWQHx8jzJvR2SLKZYEo3O[key]))
			deHnPcoI5CQG8hVt4Zs += len(Xm4VWQHx8jzJvR2SLKZYEo3O[key])
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+qNEnDMwm1Vfastx2ZkpRh+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(deHnPcoI5CQG8hVt4Zs))
		if deHnPcoI5CQG8hVt4Zs>=5:
			T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7('','','','رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if T4TGmZ9XWAzONaKygic==1:
				MqJ14AQVPkiX6 = ''
				for key in list(Xm4VWQHx8jzJvR2SLKZYEo3O.keys()):
					MqJ14AQVPkiX6 += '\n'+key
					lz1vRS0NQLFb6wD92nA = sorted(Xm4VWQHx8jzJvR2SLKZYEo3O[key],reverse=False,key=lambda roNZGUiInz3Mf1mK5: roNZGUiInz3Mf1mK5[0])
					for lHvSOF9EpRL,url in lz1vRS0NQLFb6wD92nA:
						MqJ14AQVPkiX6 += '\n'+lHvSOF9EpRL+'    '+NdVvO42riJpCWElX(url)
					MqJ14AQVPkiX6 += '\n\n'
				import IFHE2MSfi5
				BcMl3XdLS0zmK1jPvDJANfYH = IFHE2MSfi5.xWaZr7lMs6teC8('Videos','',False,'','RESOLVERS-PLAY_RESOLVERS','',MqJ14AQVPkiX6)
				if BcMl3XdLS0zmK1jPvDJANfYH: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم الإرسال بنجاح')
				else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','فشلت عملية الإرسال')
			if T4TGmZ9XWAzONaKygic!=-1:
				Xm4VWQHx8jzJvR2SLKZYEo3O = {}
				QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'MISC_PERM','SITES_ERRORS')
		if Xm4VWQHx8jzJvR2SLKZYEo3O: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'MISC_PERM','SITES_ERRORS',Xm4VWQHx8jzJvR2SLKZYEo3O,VYn9o683LCcspE7Jew5gMQrZbj)
		return
	YsDryBSXquzdEUta8kxjfO = list(set(YsDryBSXquzdEUta8kxjfO))
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = aa2ST0pZxBhRWFGY(YsDryBSXquzdEUta8kxjfO,source)
	Jgw6rfDQqyWnmo0hu71HLIRb = str(LL8heV7kxYI5bOjEZ6XaUQWwfPA).count('__watch')
	rPY9Fo5vLfV2kQDU = str(LL8heV7kxYI5bOjEZ6XaUQWwfPA).count('__download')
	y9628yL57mTKJh1gNcXzeRDjb = len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)-Jgw6rfDQqyWnmo0hu71HLIRb-rPY9Fo5vLfV2kQDU
	u1L0lEg6Rn = 'مشاهدة:'+str(Jgw6rfDQqyWnmo0hu71HLIRb)+'    تحميل:'+str(rPY9Fo5vLfV2kQDU)+'    أخرى:'+str(y9628yL57mTKJh1gNcXzeRDjb)
	if not LL8heV7kxYI5bOjEZ6XaUQWwfPA: t78SOQHR9JTBNAa,aCEzNgy0L4kujFlUToeIitBvX759 = 'unresolved',''
	else:
		add = 0
		if not any(pp8iHB3W9Cs in source for pp8iHB3W9Cs in dco65zne0R7lGBm):
			add = 1
			LL8heV7kxYI5bOjEZ6XaUQWwfPA = ['RESOLVE_ALL_LINKS']+list(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
			xitERh4TD2jGJPq5Nuv39CAmg = ['فحص جميع السيرفرات']+list(xitERh4TD2jGJPq5Nuv39CAmg)
		while True:
			aCEzNgy0L4kujFlUToeIitBvX759,t78SOQHR9JTBNAa = '',''
			if add and len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==2: ShT1xUHjlDotkRuPq7gv = 1
			else: ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB(u1L0lEg6Rn,xitERh4TD2jGJPq5Nuv39CAmg)
			if ShT1xUHjlDotkRuPq7gv==-1: t78SOQHR9JTBNAa = 'canceled_1st_menu'
			elif add and ShT1xUHjlDotkRuPq7gv==0:
				t78SOQHR9JTBNAa = 'canceled_2nd_menu'
				RRMWBwU6pG = pMAugbHylYz0kSVsKO(xitERh4TD2jGJPq5Nuv39CAmg[add:],LL8heV7kxYI5bOjEZ6XaUQWwfPA[add:],source)
				if RRMWBwU6pG:
					TY7PtqANDWkc = []
					for cu5XL4g8po7F,PSc013zIgQsVDKjv96mr4NneW,Q3Pa278elkxmhX,Z0Ys3m1GkEaj,ZGISPWmax42JV in RRMWBwU6pG:
						if ZGISPWmax42JV: TY7PtqANDWkc.append((cu5XL4g8po7F,PSc013zIgQsVDKjv96mr4NneW,Q3Pa278elkxmhX,Z0Ys3m1GkEaj,ZGISPWmax42JV))
					if TY7PtqANDWkc: xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,errors,lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO = zip(*TY7PtqANDWkc)
					else:
						qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						t78SOQHR9JTBNAa = 'failed'
						break
					u1L0lEg6Rn = 'السيرفرات الجيدة ( '+str(len(LL8heV7kxYI5bOjEZ6XaUQWwfPA))+' )'
					add = 0
					continue
			else:
				RRMWBwU6pG = pMAugbHylYz0kSVsKO([xitERh4TD2jGJPq5Nuv39CAmg[ShT1xUHjlDotkRuPq7gv]],[LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]],source)
				if RRMWBwU6pG:
					title,VV7yf2htDCBU6EeSX8TJQM,errors,lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO = RRMWBwU6pG[0]
					if not Y4xiULzGTKjb8mulO and not any(pp8iHB3W9Cs in source for pp8iHB3W9Cs in dco65zne0R7lGBm):
						errors,lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO = m2Pl5vYVjy7Lk3(VV7yf2htDCBU6EeSX8TJQM,source)
					if 'سيرفر' in title and '2مجهول2' in title:
						zRM3tZx2v6DjJU('ERROR_LINES',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Unknown Selected Server   Server: [ '+title+' ]   Link: [ '+VV7yf2htDCBU6EeSX8TJQM+' ]')
						import IFHE2MSfi5
						IFHE2MSfi5.fBrWTYn2Gc90()
						t78SOQHR9JTBNAa = 'unresolved'
					else:
						zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Playing Selected Server   Server: [ '+title+' ]   Link: [ '+VV7yf2htDCBU6EeSX8TJQM+' ]')
						t78SOQHR9JTBNAa,aCEzNgy0L4kujFlUToeIitBvX759,UdxpbPKgBScklJLj542O0feZsro = uDNFx5RE0LmgC8XkQtAOrz96pjSZGc(title,VV7yf2htDCBU6EeSX8TJQM,errors,lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO,source,type)
			if t78SOQHR9JTBNAa in ['EXIT_RESOLVER','download','playing','testing','canceled_1st_menu'] or len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==1+add: break
			elif t78SOQHR9JTBNAa in ['failed','timeout','tried']: break
			elif t78SOQHR9JTBNAa not in ['canceled_2nd_menu','https']:
				if '\n' in aCEzNgy0L4kujFlUToeIitBvX759: aCEzNgy0L4kujFlUToeIitBvX759 = '[LEFT]  '+aCEzNgy0L4kujFlUToeIitBvX759.replace('\n','\n[LEFT]  ')
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+'\n'+aCEzNgy0L4kujFlUToeIitBvX759,profile='confirm_mediumfont')
	if t78SOQHR9JTBNAa=='unresolved' and len(xitERh4TD2jGJPq5Nuv39CAmg)>0: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+'\n'+aCEzNgy0L4kujFlUToeIitBvX759,profile='confirm_mediumfont')
	elif t78SOQHR9JTBNAa in ['failed','timeout'] and aCEzNgy0L4kujFlUToeIitBvX759!='': qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج',aCEzNgy0L4kujFlUToeIitBvX759,profile='confirm_mediumfont')
	return t78SOQHR9JTBNAa
def pMAugbHylYz0kSVsKO(arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO,source):
	global NuJLzkOYmcXSQjKTA5n
	NuJLzkOYmcXSQjKTA5n,RRMWBwU6pG,jbt3YhRyw81TG,new = [],[],[],[]
	iBTbm82l5KZSGJN6t3(False,False,False)
	count = len(YsDryBSXquzdEUta8kxjfO)
	for R58BqYpOyeZs in range(count):
		NuJLzkOYmcXSQjKTA5n.append(None)
		title = arZijTmC4eXBKvgEAHxPD7JtwOh[R58BqYpOyeZs]
		VV7yf2htDCBU6EeSX8TJQM = YsDryBSXquzdEUta8kxjfO[R58BqYpOyeZs].strip(' ').strip('&').strip('?').strip('/')
		if count>1: uFCykYQW68S('فحص سيرفر رقم  '+str(R58BqYpOyeZs+1),title)
		zJI81jSwlL = VV7yf2htDCBU6EeSX8TJQM.split('?named=',1)[0]
		LCZSXjNzV2blkf5sKt = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','RESOLVED',zJI81jSwlL)
		if LCZSXjNzV2blkf5sKt and 'AKWAM' not in source:
			NuJLzkOYmcXSQjKTA5n[R58BqYpOyeZs] = LCZSXjNzV2blkf5sKt
		else:
			i2JGAOwby1ehDRlCgqjr9cNz = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=m2Pl5vYVjy7Lk3,args=(VV7yf2htDCBU6EeSX8TJQM,source,R58BqYpOyeZs))
			i2JGAOwby1ehDRlCgqjr9cNz.start()
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(0.5)
			jbt3YhRyw81TG.append(i2JGAOwby1ehDRlCgqjr9cNz)
			new.append(R58BqYpOyeZs)
	timeout = 60 if source=='AKWAM' else 20
	for i2JGAOwby1ehDRlCgqjr9cNz in jbt3YhRyw81TG: i2JGAOwby1ehDRlCgqjr9cNz.join(timeout)
	for R58BqYpOyeZs in range(count):
		title = arZijTmC4eXBKvgEAHxPD7JtwOh[R58BqYpOyeZs]
		VV7yf2htDCBU6EeSX8TJQM = YsDryBSXquzdEUta8kxjfO[R58BqYpOyeZs].strip(' ').strip('&').strip('?').strip('/')
		if NuJLzkOYmcXSQjKTA5n[R58BqYpOyeZs]: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = NuJLzkOYmcXSQjKTA5n[R58BqYpOyeZs]
		else: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '\nFailed:  Timeout ('+str(timeout)+' seconds)',[],[]
		RRMWBwU6pG.append([title,VV7yf2htDCBU6EeSX8TJQM,aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA])
		if R58BqYpOyeZs in new:
			zJI81jSwlL = VV7yf2htDCBU6EeSX8TJQM.split('?named=',1)[0]
			mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'RESOLVED',zJI81jSwlL,[aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA],t7rXIzJfMLWRwaDeKhTq4C6dG)
	iBTbm82l5KZSGJN6t3('','','')
	return RRMWBwU6pG
def m2Pl5vYVjy7Lk3(url,source,we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk=0):
	global NuJLzkOYmcXSQjKTA5n
	zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Resolving started   Original: [ '+url+' ]')
	VV7yf2htDCBU6EeSX8TJQM,Jp5RU7IPmbaXir4 = url,''
	RRbA6IvEhNrUlpQFSLa0OyjCxJP4m = 'INTERNAL_RESOLVER'
	aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = qqTbocXOdyrZQhDnVlLkW07iBSg(url,source)
	if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER':
		Jp5RU7IPmbaXir4 = '\nResolver 1:  Exit'
		NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
		return Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	elif 'NEED_EXTERNAL_RESOLVERS' in aCEzNgy0L4kujFlUToeIitBvX759:
		Jp5RU7IPmbaXir4 = '\nResolver 1:  Need External Resolver'
		VV7yf2htDCBU6EeSX8TJQM = RCKcfNus7yWjrolESk3ZT8mDwbpLh(LL8heV7kxYI5bOjEZ6XaUQWwfPA)[0]
		NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
		RRbA6IvEhNrUlpQFSLa0OyjCxJP4m,Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = F7pQ4LKYhXd8N(Jp5RU7IPmbaXir4,VV7yf2htDCBU6EeSX8TJQM,source,we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk)
	elif aCEzNgy0L4kujFlUToeIitBvX759: Jp5RU7IPmbaXir4 = 'Resolver 1:  '+aCEzNgy0L4kujFlUToeIitBvX759.replace('\n','').replace('\r','')[:80]
	if LL8heV7kxYI5bOjEZ6XaUQWwfPA:
		LL8heV7kxYI5bOjEZ6XaUQWwfPA = RCKcfNus7yWjrolESk3ZT8mDwbpLh(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
		zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Resolving succeeded   Resolver: [ '+RRbA6IvEhNrUlpQFSLa0OyjCxJP4m+' ]   Original: [ '+url+' ]   Link: [ '+VV7yf2htDCBU6EeSX8TJQM+' ]   Results: [ '+str(LL8heV7kxYI5bOjEZ6XaUQWwfPA)+' ]')
	else: zRM3tZx2v6DjJU('ERROR_LINES',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Resolving failed   Original: [ '+url+' ]   Link: [ '+VV7yf2htDCBU6EeSX8TJQM+' ]   Errors: [ '+Jp5RU7IPmbaXir4+' ]')
	Jp5RU7IPmbaXir4 = NdVvO42riJpCWElX(Jp5RU7IPmbaXir4)
	NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	return Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def F7pQ4LKYhXd8N(Jp5RU7IPmbaXir4,url,source,we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk):
	global NuJLzkOYmcXSQjKTA5n
	RRbA6IvEhNrUlpQFSLa0OyjCxJP4m = 'EXTERNAL_RESOLVER_2'
	aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = dhvREDZ0zFJwa1L(url,source)
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = RCKcfNus7yWjrolESk3ZT8mDwbpLh(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
	NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER': return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	elif 'Failed:' in aCEzNgy0L4kujFlUToeIitBvX759:
		Jp5RU7IPmbaXir4 += '\nResolver 2:  '+aCEzNgy0L4kujFlUToeIitBvX759.replace('\n','').replace('\r','')[:80]
		RRbA6IvEhNrUlpQFSLa0OyjCxJP4m = 'EXTERNAL_RESOLVER_3'
		aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = PQIfvyuHAdpJ9FntVR6a(url,source)
		LL8heV7kxYI5bOjEZ6XaUQWwfPA = RCKcfNus7yWjrolESk3ZT8mDwbpLh(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
		NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
		if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER': return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
		elif 'Failed:' in aCEzNgy0L4kujFlUToeIitBvX759:
			Jp5RU7IPmbaXir4 += '\nResolver 3:  '+aCEzNgy0L4kujFlUToeIitBvX759.replace('\n','').replace('\r','')[:80]
			RRbA6IvEhNrUlpQFSLa0OyjCxJP4m = 'EXTERNAL_RESOLVER_4'
			aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = KBA810YGlHILF79u63isTxarcX2C(url,source)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA = RCKcfNus7yWjrolESk3ZT8mDwbpLh(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
			NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
			if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER': return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
			elif 'Failed:' in aCEzNgy0L4kujFlUToeIitBvX759:
				Jp5RU7IPmbaXir4 += '\nResolver 4:  '+aCEzNgy0L4kujFlUToeIitBvX759.replace('\n','').replace('\r','')[:80]
				RRbA6IvEhNrUlpQFSLa0OyjCxJP4m = 'EXTERNAL_RESOLVER_5'
				aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = PPDy8JSwzREUG5MQiYTmLCNnrq7AxZ(url,source)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA = RCKcfNus7yWjrolESk3ZT8mDwbpLh(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
				NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
				if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER': return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
				elif 'Failed:' in aCEzNgy0L4kujFlUToeIitBvX759:
					Jp5RU7IPmbaXir4 += '\nResolver 5:  '+aCEzNgy0L4kujFlUToeIitBvX759.replace('\n','').replace('\r','')[:80]
	NuJLzkOYmcXSQjKTA5n[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk] = Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	return RRbA6IvEhNrUlpQFSLa0OyjCxJP4m,Jp5RU7IPmbaXir4,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def uDNFx5RE0LmgC8XkQtAOrz96pjSZGc(title,VV7yf2htDCBU6EeSX8TJQM,aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,source,type=''):
	if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER': return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	elif LL8heV7kxYI5bOjEZ6XaUQWwfPA:
		while True:
			if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==1: ShT1xUHjlDotkRuPq7gv = 0
			else: ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الملف المناسب:', xitERh4TD2jGJPq5Nuv39CAmg)
			if ShT1xUHjlDotkRuPq7gv==-1: t78SOQHR9JTBNAa = 'tried'
			else:
				t74tQ2bc8gsnfqmejDTPuSiaM = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
				title = xitERh4TD2jGJPq5Nuv39CAmg[ShT1xUHjlDotkRuPq7gv]
				zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Playing selected video   Selected: [ '+title+' ]   URL: [ '+str(t74tQ2bc8gsnfqmejDTPuSiaM)+' ]')
				if 'moshahda.' in t74tQ2bc8gsnfqmejDTPuSiaM and 'download_orig' in t74tQ2bc8gsnfqmejDTPuSiaM:
					M9U6xgr7nTv3,gyGwI3NoaQV8uC0YjZUTHS,UdxpbPKgBScklJLj542O0feZsro = czXN7QRslFr(t74tQ2bc8gsnfqmejDTPuSiaM)
					if UdxpbPKgBScklJLj542O0feZsro: t74tQ2bc8gsnfqmejDTPuSiaM = UdxpbPKgBScklJLj542O0feZsro[0]
					else: t74tQ2bc8gsnfqmejDTPuSiaM = ''
				if not t74tQ2bc8gsnfqmejDTPuSiaM: t78SOQHR9JTBNAa = 'unresolved'
				else: t78SOQHR9JTBNAa = zT3xJQIVDmCgapBljs(t74tQ2bc8gsnfqmejDTPuSiaM,source,type)
			if t78SOQHR9JTBNAa in ['playing','testing','canceled_2nd_menu'] or len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==1: break
			elif t78SOQHR9JTBNAa in ['failed','timeout','tried']: break
			else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		t78SOQHR9JTBNAa = 'unresolved'
		if H93DlbtKLEarfQ8w7GcoIukSexv0J(VV7yf2htDCBU6EeSX8TJQM): t78SOQHR9JTBNAa = zT3xJQIVDmCgapBljs(VV7yf2htDCBU6EeSX8TJQM,source,type)
	return t78SOQHR9JTBNAa,aCEzNgy0L4kujFlUToeIitBvX759,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def MUQn2XT9Np(url,source):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,Xw4NL1xdvtsYcWnD6,BHgLX9GZTb2jJrWiNKE,lI4fTEVw5qvmROY1,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF = url,'','','','','','',''
	if '?named=' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao,Xw4NL1xdvtsYcWnD6 = url.split('?named=',1)
		Xw4NL1xdvtsYcWnD6 = Xw4NL1xdvtsYcWnD6+'__'+'__'+'__'+'__'
		Xw4NL1xdvtsYcWnD6 = Xw4NL1xdvtsYcWnD6.lower()
		pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF,JohnQtKE9Gry14FwfgM = Xw4NL1xdvtsYcWnD6.split('__')[:5]
	if i5DftlhA6vQ2GF=='': i5DftlhA6vQ2GF = '0'
	else: i5DftlhA6vQ2GF = i5DftlhA6vQ2GF.replace('p','').replace(' ','')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.strip('?').strip('/').strip('&')
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'host')
	if pphVUbJkGtHXndg84iZl2DPImSzoC: lI4fTEVw5qvmROY1 = pphVUbJkGtHXndg84iZl2DPImSzoC
	else: lI4fTEVw5qvmROY1 = BHgLX9GZTb2jJrWiNKE
	lI4fTEVw5qvmROY1 = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lI4fTEVw5qvmROY1,'name')
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	Xw4NL1xdvtsYcWnD6 = Xw4NL1xdvtsYcWnD6.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	lI4fTEVw5qvmROY1 = lI4fTEVw5qvmROY1.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	return lZqkuhgaBHSVX8NItKG05cdLJe7Ao,Xw4NL1xdvtsYcWnD6,BHgLX9GZTb2jJrWiNKE,lI4fTEVw5qvmROY1,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF
def mEXbh0M7dDrP3LYzQgCTnKFBl(url,source):
	MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC,jj6acsmeo0NHJY7X4GFwIiU9Tx,tMyw8h4BZAv,RaBEwVrki0sexNoL,wzDT0Ej85gnQhialeW,RRbA6IvEhNrUlpQFSLa0OyjCxJP4m = '','',None,None,None,None,None
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,Xw4NL1xdvtsYcWnD6,BHgLX9GZTb2jJrWiNKE,lI4fTEVw5qvmROY1,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF = MUQn2XT9Np(url,source)
	if '?named=' in url:
		if   type=='embed': type = ' '+'مفضل'
		elif type=='watch': type = ' '+'%مشاهدة'
		elif type=='both': type = ' '+'%%مشاهدة وتحميل'
		elif type=='download': type = ' '+'%%%تحميل'
		elif type=='': type = ' '+'%%%%'
		if UQIq1jCWgFi4MTV0K97bfSe!='':
			if 'mp4' not in UQIq1jCWgFi4MTV0K97bfSe: UQIq1jCWgFi4MTV0K97bfSe = '%'+UQIq1jCWgFi4MTV0K97bfSe
			UQIq1jCWgFi4MTV0K97bfSe = ' '+UQIq1jCWgFi4MTV0K97bfSe
		if i5DftlhA6vQ2GF!='':
			i5DftlhA6vQ2GF = '%%%%%%%%%'+i5DftlhA6vQ2GF
			i5DftlhA6vQ2GF = ' '+i5DftlhA6vQ2GF[-9:]
	if   'AKOAM'		in source: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'AKWAM'		in source: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'akwam'
	elif 'katkoute'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'photos.app.g'	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'arabseed'		in source: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'alarab'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'fasel'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 't7meel'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'movs4u'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'myegyvip'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'fajer'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'فجر'			in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'fajer'
	elif 'فلسطين'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'palestine'
	elif 'gdrive'		in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'google'
	elif 'mycima'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'wecima'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'cimanow'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'newcima'		in pphVUbJkGtHXndg84iZl2DPImSzoC:   jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'dailymotion'	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'bokra'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'tvfun'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'tvksa'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'anavidz'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'shoofpro'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= lI4fTEVw5qvmROY1
	elif 'shahid4u'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'shahed4u'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'cima4u'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'egynow'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'halacima'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'cimaabdo'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'youtu'	 	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'youtube'
	elif 'y2u.be'	 	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'youtube'
	elif 'd.egybest.d'	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'egybestvip'
	elif 'egy.best'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'egybest1'
	elif 'egybest'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'egybest3'
	elif 'moshahda'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'moshahda'
	elif 'facultybooks'	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'facultybooks'
	elif 'inflam.cc'	in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'inflam'
	elif 'buzzvrl'		in BHgLX9GZTb2jJrWiNKE: jj6acsmeo0NHJY7X4GFwIiU9Tx	= 'buzzvrl'
	elif 'arabloads'	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'arabloads'
	elif 'archive'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'archive'
	elif 'catch.is'	 	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'catch'
	elif 'filerio'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'filerio'
	elif 'vidbm'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'vidbm'
	elif 'vidhd'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'myvid'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'myviid'		in BHgLX9GZTb2jJrWiNKE: wzDT0Ej85gnQhialeW	= lI4fTEVw5qvmROY1
	elif 'videobin'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'videobin'
	elif 'govid'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'govid'
	elif 'liivideo' 	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'liivideo'
	elif 'mp4upload'	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'mp4upload'
	elif 'publicvideo'	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'publicvideo'
	elif 'rapidvideo' 	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'rapidvideo'
	elif 'top4top'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'top4top'
	elif 'upp' 			in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'upbom'
	elif 'upb' 			in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'upbom'
	elif 'uqload' 		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'uqload'
	elif 'vcstream' 	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'vcstream'
	elif 'vidbob'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'vidbob'
	elif 'vidoza' 		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'vidoza'
	elif 'watchvideo' 	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'watchvideo'
	elif 'wintv.live'	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'wintv.live'
	elif 'zippyshare'	in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'zippyshare'
	elif 'hd-cdn'		in BHgLX9GZTb2jJrWiNKE: tMyw8h4BZAv	= 'hd-cdn'
	if   jj6acsmeo0NHJY7X4GFwIiU9Tx:	MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC = 'خاص',jj6acsmeo0NHJY7X4GFwIiU9Tx
	elif wzDT0Ej85gnQhialeW:		MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC = '%محدد',wzDT0Ej85gnQhialeW
	elif tMyw8h4BZAv:		MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC = '%%عام معروف',tMyw8h4BZAv
	elif RaBEwVrki0sexNoL:	MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC = '%%%عام خارجي',RaBEwVrki0sexNoL
	elif RRbA6IvEhNrUlpQFSLa0OyjCxJP4m:	MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC = '%%%%عام خارجي',lI4fTEVw5qvmROY1
	else:			MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC = '%%%%%عام مجهول',lI4fTEVw5qvmROY1
	return MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF
def qqTbocXOdyrZQhDnVlLkW07iBSg(url,source):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,wzDT0Ej85gnQhialeW,BHgLX9GZTb2jJrWiNKE,lI4fTEVw5qvmROY1,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF = MUQn2XT9Np(url,source)
	if   'AKOAM'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = OjZmrI0DKb(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,pphVUbJkGtHXndg84iZl2DPImSzoC)
	elif 'AKWAM'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = ETaRVFoBXD(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,type,i5DftlhA6vQ2GF)
	elif 'FASELHD1'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = ppGhAdLXIP(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'CIMA4U'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = kuNtEaWXm6(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'CIMACLUB'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = Vo1bUqIvAi(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'ARABSEED'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = CbnORTUHL5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'CIMAABDO'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = tBRqDYfagz(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'SHOFHA'		in source: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = qRtFebZi1J(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'katkoute'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = pDuINVgCYf(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'akoam.cam'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = yeoi8n2Xb1(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'alarab'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = LqZXvPfR14xbBOhEYu8VQ0r5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'shahid4u'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = f862dET1BF(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'shahed4u'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = f862dET1BF(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'egynow'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = gTS1D3NfJz(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'tvfun'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = DFkGWuYhdb(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'tvksa'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = DFkGWuYhdb(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'tv-f.com'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = DFkGWuYhdb(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'halacima'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = ksA2HucdFh(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'shoofpro'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = JE3trXDa7N(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'myegyvip'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = tjh8yKJSuBg70wAoX(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'vs4u'			in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = BM6R2vOGT9(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'fajer'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = p0aBKYXZUh(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'cimanow'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = wJbtYB85UM(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'newcima'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = wJbtYB85UM(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'cima-light'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = PeR0asuyA2(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'cimalight'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = PeR0asuyA2(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'mycima'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = vbokuZrzD6(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'wecima'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = F4b2neDjfi(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'bokra'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = LRMCkhDVuY(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'dailymotion'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = Ye6gQpcIJL(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'arblionz'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = nnPi78q5GO(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'd.egybest.d'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	elif 'egy.best'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = VPK7iuwqrt(url)
	elif 'egybest'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = EVXS46FUM7(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'series4watch'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = TzRiNDxkrd(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	elif 'upbam' 		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	else: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	return 'Failed:  '+aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def dhvREDZ0zFJwa1L(url,source):
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'name')
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	if   'youtu'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = DGetBjzwkV(url)
	elif 'y2u.be'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = DGetBjzwkV(url)
	elif 'googleuserco' in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = wgtb8LJOZi3XCKp5R19m(url)
	elif 'photos.app.g'	in url   : aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = Bn4aN5YTCDZolQ2Lv6JkO(url)
	elif 'dailymotion'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = Ye6gQpcIJL(url)
	elif 'moshahda'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = czXN7QRslFr(url)
	elif 'faselhd'		in url   : aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = ppGhAdLXIP(url)
	elif 'arabloads'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = fHEoUIkPrBQ1xZW6KLVOJea5A8v(url)
	elif 'archive'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = T6vDoUCWyLx3FdmzqefwiG5un8(url)
	elif 'buzzvrl'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = WczavojC5V8nqZ4kHQgd(url)
	elif 'e5tsar'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = OqpCoacN8DGS7jvQ(url)
	elif 'facultybooks'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = YYZ8fLtChS60aJD(url)
	elif 'inflam.cc'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = YYZ8fLtChS60aJD(url)
	elif 'upbam' 		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[''],[url]
	elif 'liivideo' 	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = qqz7vsFoublkNYQdUOnp(url)
	elif 'mp4upload'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = JqbwAjBkmO(url)
	elif 'rapidvideo' 	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = SzIyUxvdaHoMpt5bwNBifm(url)
	elif 'top4top'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = FF6raiNu2ECRhwcx3LW5(url)
	elif 'upb' 			in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = zljp9TyBPdLK13a84RMv2Co(url)
	elif 'upp' 			in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = zljp9TyBPdLK13a84RMv2Co(url)
	elif 'uqload' 		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = XzBr50hDdmRunEcw(url)
	elif 'vcstream' 	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = V3WhELQqXB9jFTPtn2p17(url)
	elif 'vidbob'		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = SfjtKlb26xOIVR8p(url)
	elif 'vidoza' 		in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = mt4Le1SxMdXKBvfUcklJ0DAP3F5W(url)
	elif 'watchvideo' 	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = PUodrjeQsE5VlfuDv12WCZz(url)
	elif 'wintv.live'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = L7zJXo4HYmQ1(url)
	elif 'zippyshare'	in BHgLX9GZTb2jJrWiNKE: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = PoOHN7MRXuYfaIjCrLwh1Wm(url)
	if LL8heV7kxYI5bOjEZ6XaUQWwfPA: return 'Failed: '+aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	return 'Failed:  ',[],[]
def TXbhJ1PANDj2zYfHRncxVF5OpWeyE3(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','',False,'RESOLVERS-URL_REDIRECT-1st')
	headers = nbdMp8UuhzP3oq4cDWj6eyZVt.headers
	if 'Location' in list(headers.keys()):
		VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		if H93DlbtKLEarfQ8w7GcoIukSexv0J(VV7yf2htDCBU6EeSX8TJQM): return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	return 'Failed:  ',[],[]
def PQIfvyuHAdpJ9FntVR6a(url,source):
	aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[],[]
	if H93DlbtKLEarfQ8w7GcoIukSexv0J(url): aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[''],[url]
	if not LL8heV7kxYI5bOjEZ6XaUQWwfPA: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = TXbhJ1PANDj2zYfHRncxVF5OpWeyE3(url)
	if not LL8heV7kxYI5bOjEZ6XaUQWwfPA: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = vJKC28bG6jrBe(url)
	if not LL8heV7kxYI5bOjEZ6XaUQWwfPA:
		if aCEzNgy0L4kujFlUToeIitBvX759=='EXIT_RESOLVER': aCEzNgy0L4kujFlUToeIitBvX759 = ''
		return 'Failed:  '+aCEzNgy0L4kujFlUToeIitBvX759,[],[]
	return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def RCKcfNus7yWjrolESk3ZT8mDwbpLh(deoTHkGNZX1s2mp4SvtJznIl3FyVA):
	if 'list' in str(type(deoTHkGNZX1s2mp4SvtJznIl3FyVA)):
		Y4xiULzGTKjb8mulO = []
		for VV7yf2htDCBU6EeSX8TJQM in deoTHkGNZX1s2mp4SvtJznIl3FyVA:
			if 'str' in str(type(VV7yf2htDCBU6EeSX8TJQM)):
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\r','').replace('\n','').strip(' ')
			Y4xiULzGTKjb8mulO.append(VV7yf2htDCBU6EeSX8TJQM)
	else: Y4xiULzGTKjb8mulO = deoTHkGNZX1s2mp4SvtJznIl3FyVA.replace('\r','').replace('\n','').strip(' ')
	return Y4xiULzGTKjb8mulO
def aa2ST0pZxBhRWFGY(UdxpbPKgBScklJLj542O0feZsro,source):
	ccHn2S5KzhpbZuB = lu4xpkY5LFOm6t2In
	data = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SERVERS',UdxpbPKgBScklJLj542O0feZsro)
	if data:
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = list(zip(*data))
		return xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,gg9cdDBInGPoWFmzlv6tK8LCVA = [],[],[]
	for VV7yf2htDCBU6EeSX8TJQM in UdxpbPKgBScklJLj542O0feZsro:
		if '//' not in VV7yf2htDCBU6EeSX8TJQM: continue
		MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF = mEXbh0M7dDrP3LYzQgCTnKFBl(VV7yf2htDCBU6EeSX8TJQM,source)
		i5DftlhA6vQ2GF = QPuHKNAT4jmCRg.findall('\d+',i5DftlhA6vQ2GF,QPuHKNAT4jmCRg.DOTALL)
		if i5DftlhA6vQ2GF: i5DftlhA6vQ2GF = int(i5DftlhA6vQ2GF[0])
		else: i5DftlhA6vQ2GF = 0
		BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
		gg9cdDBInGPoWFmzlv6tK8LCVA.append([MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF,VV7yf2htDCBU6EeSX8TJQM,BHgLX9GZTb2jJrWiNKE])
	if gg9cdDBInGPoWFmzlv6tK8LCVA:
		ULSz6R0JaCk7n4vZP = sorted(gg9cdDBInGPoWFmzlv6tK8LCVA,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		XrMKGecuElnAF = []
		for ZmSt0LenHKEjq2BXQTz84vCO in ULSz6R0JaCk7n4vZP:
			if ZmSt0LenHKEjq2BXQTz84vCO not in XrMKGecuElnAF:
				XrMKGecuElnAF.append(ZmSt0LenHKEjq2BXQTz84vCO)
		for MMAuXRltDZ3L2,pphVUbJkGtHXndg84iZl2DPImSzoC,type,UQIq1jCWgFi4MTV0K97bfSe,i5DftlhA6vQ2GF,VV7yf2htDCBU6EeSX8TJQM,BHgLX9GZTb2jJrWiNKE in XrMKGecuElnAF:
			if i5DftlhA6vQ2GF: i5DftlhA6vQ2GF = str(i5DftlhA6vQ2GF)
			else: i5DftlhA6vQ2GF = ''
			title = 'سيرفر'+' '+type+' '+MMAuXRltDZ3L2+' '+i5DftlhA6vQ2GF+' '+UQIq1jCWgFi4MTV0K97bfSe+' '+pphVUbJkGtHXndg84iZl2DPImSzoC
			if BHgLX9GZTb2jJrWiNKE not in title: title = title+' '+BHgLX9GZTb2jJrWiNKE
			title = title.replace('%','').strip(' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if VV7yf2htDCBU6EeSX8TJQM not in LL8heV7kxYI5bOjEZ6XaUQWwfPA:
				xitERh4TD2jGJPq5Nuv39CAmg.append(title)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		if LL8heV7kxYI5bOjEZ6XaUQWwfPA:
			data = list(zip(xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA))
			if data: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SERVERS',UdxpbPKgBScklJLj542O0feZsro,data,ccHn2S5KzhpbZuB)
	return xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def KBA810YGlHILF79u63isTxarcX2C(url,source):
	CeJXk5gb27o = ''
	RRMWBwU6pG = False
	try:
		import resolveurl as caKg2GU80X1Didlpyn
		RRMWBwU6pG = caKg2GU80X1Didlpyn.resolve(url)
	except Exception as nTcLSovCNZYedhjP5U7bp: CeJXk5gb27o = str(nTcLSovCNZYedhjP5U7bp)
	if not RRMWBwU6pG:
		if CeJXk5gb27o=='':
			CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
			if CeJXk5gb27o!='NoneType: None\n': GJtcqTv68ZQpwxYFiDg.stderr.write(CeJXk5gb27o)
		aCEzNgy0L4kujFlUToeIitBvX759 = CeJXk5gb27o.splitlines()[-1]
		return 'Failed:  '+aCEzNgy0L4kujFlUToeIitBvX759,[],[]
	return '',[''],[RRMWBwU6pG]
def PPDy8JSwzREUG5MQiYTmLCNnrq7AxZ(url,source):
	CeJXk5gb27o = ''
	RRMWBwU6pG = False
	try:
		import youtube_dl as MzL9nEu7earStK
		oWin10Rbm3qOJCG42NlFI = MzL9nEu7earStK.YoutubeDL({'no_color': True})
		RRMWBwU6pG = oWin10Rbm3qOJCG42NlFI.extract_info(url,download=False)
	except Exception as nTcLSovCNZYedhjP5U7bp: CeJXk5gb27o = str(nTcLSovCNZYedhjP5U7bp)
	if not RRMWBwU6pG or 'formats' not in list(RRMWBwU6pG.keys()):
		if CeJXk5gb27o=='':
			CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
			if CeJXk5gb27o!='NoneType: None\n': GJtcqTv68ZQpwxYFiDg.stderr.write(CeJXk5gb27o)
		aCEzNgy0L4kujFlUToeIitBvX759 = CeJXk5gb27o.splitlines()[-1]
		return 'Failed:  '+aCEzNgy0L4kujFlUToeIitBvX759,[],[]
	else:
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
		for VV7yf2htDCBU6EeSX8TJQM in RRMWBwU6pG['formats']:
			xitERh4TD2jGJPq5Nuv39CAmg.append(VV7yf2htDCBU6EeSX8TJQM['format'])
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM['url'])
		return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def LqZXvPfR14xbBOhEYu8VQ0r5(url):
	if '.m3u8' in url:
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = RjzVfbE0ILcNXFQJniSMBOskK13ox(url)
		if LL8heV7kxYI5bOjEZ6XaUQWwfPA: return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def pDuINVgCYf(url):
	YsDryBSXquzdEUta8kxjfO,arZijTmC4eXBKvgEAHxPD7JtwOh = [],[]
	if '/videos.mp4?vid=' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','',False,'','RESOLVERS-KATKOUTE-1st')
		if 'Location' in nbdMp8UuhzP3oq4cDWj6eyZVt.headers:
			VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
			BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
			arZijTmC4eXBKvgEAHxPD7JtwOh.append(BHgLX9GZTb2jJrWiNKE)
	elif 'katkoute.com' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','RESOLVERS-KATKOUTE-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		bbszZDlChGAiI8eV3r6Yk = QPuHKNAT4jmCRg.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if bbszZDlChGAiI8eV3r6Yk:
			bbszZDlChGAiI8eV3r6Yk = bbszZDlChGAiI8eV3r6Yk[0]
			cc1nabWT9B0zpYNQumyAkq = V7nq6gTU2NIe0OCtZMpKB(bbszZDlChGAiI8eV3r6Yk)
			FFxGIsEMpquf6 = QPuHKNAT4jmCRg.findall('sources:(\[.*?\]),',cc1nabWT9B0zpYNQumyAkq,QPuHKNAT4jmCRg.DOTALL)
			if FFxGIsEMpquf6:
				FFxGIsEMpquf6 = FFxGIsEMpquf6[0]
				FFxGIsEMpquf6 = kMLWTt2fO9dnGDUgHh('list',FFxGIsEMpquf6)
				for dict in FFxGIsEMpquf6:
					VV7yf2htDCBU6EeSX8TJQM = dict['file']
					i5DftlhA6vQ2GF = dict['label']
					YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
					BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
					arZijTmC4eXBKvgEAHxPD7JtwOh.append(i5DftlhA6vQ2GF+' '+BHgLX9GZTb2jJrWiNKE)
		elif 'Location' in nbdMp8UuhzP3oq4cDWj6eyZVt.headers:
			VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
			BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
			arZijTmC4eXBKvgEAHxPD7JtwOh.append(BHgLX9GZTb2jJrWiNKE)
		if '?url=https://photos.app.goo' in url:
			VV7yf2htDCBU6EeSX8TJQM = url.split('?url=')[1]
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&')[0]
			if VV7yf2htDCBU6EeSX8TJQM:
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
				arZijTmC4eXBKvgEAHxPD7JtwOh.append('photos google')
	else:
		YsDryBSXquzdEUta8kxjfO.append(url)
		BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'name')
		arZijTmC4eXBKvgEAHxPD7JtwOh.append(BHgLX9GZTb2jJrWiNKE)
	if not YsDryBSXquzdEUta8kxjfO: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(YsDryBSXquzdEUta8kxjfO)==1: VV7yf2htDCBU6EeSX8TJQM = YsDryBSXquzdEUta8kxjfO[0]
	else:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('أختر الملف المناسب',arZijTmC4eXBKvgEAHxPD7JtwOh)
		if ShT1xUHjlDotkRuPq7gv==-1: return 'EXIT_RESOLVER',[],[]
		VV7yf2htDCBU6EeSX8TJQM = YsDryBSXquzdEUta8kxjfO[ShT1xUHjlDotkRuPq7gv]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def wgtb8LJOZi3XCKp5R19m(url):
	headers = {'User-Agent':'Kodi/'+str(LRjqrQYBXFVPfu)}
	for kdWCpE9TjNh in range(50):
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(0.100)
		nbdMp8UuhzP3oq4cDWj6eyZVt = e94Oz3uF7KZJ('GET',url,'',headers,False,'','RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(nbdMp8UuhzP3oq4cDWj6eyZVt.headers.keys()):
			VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'|User-Agent='+headers['User-Agent']
			return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
		if nbdMp8UuhzP3oq4cDWj6eyZVt.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def Bn4aN5YTCDZolQ2Lv6JkO(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','RESOLVERS-PHOTOSGOOGLE-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF = VV7yf2htDCBU6EeSX8TJQM[0]
		return '',[i5DftlhA6vQ2GF],[VV7yf2htDCBU6EeSX8TJQM]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def ppGhAdLXIP(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-FASELHD1-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Ht6Gg8lbciAd9FaUQVs = vvSrTfCOiNqPcoLa7eZn2s5Mlxk9YV(Ht6Gg8lbciAd9FaUQVs)
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"file":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM: return '',[''],[VV7yf2htDCBU6EeSX8TJQM[0]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def qRtFebZi1J(url):
	if '/down.php' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-SHOFHA-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('video-wrapper.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		url = VV7yf2htDCBU6EeSX8TJQM[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def kuNtEaWXm6(url):
	if 'server.php' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-CIMA4U-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		if 'http' in VV7yf2htDCBU6EeSX8TJQM: return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def gTS1D3NfJz(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
	Eudgv5cTUHF2AzKpkx = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-EGYNOW-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: return 'Error: Resolver Failed EGYNOW',[],[]
	VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def JE3trXDa7N(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','RESOLVERS-SHOOFPRO-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	if not VV7yf2htDCBU6EeSX8TJQM: return 'Error: Resolver Failed SHOOFPRO',[],[]
	VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def ksA2HucdFh(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
	Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-HALACIMA-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('''<iframe src=["'](.*?)["']''',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	if not VV7yf2htDCBU6EeSX8TJQM: return 'Error: Resolver Failed HALACIMA',[],[]
	VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def tBRqDYfagz(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
	Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-CIMAABDO-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('''<iframe src=["'](.*?)["']''',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	if VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	else: VV7yf2htDCBU6EeSX8TJQM = url
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def DFkGWuYhdb(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','RESOLVERS-TVFUN-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	PVBk51YyXOnDcj0QwbI = QPuHKNAT4jmCRg.findall("var fserv =.*?'(.*?)'",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	if PVBk51YyXOnDcj0QwbI:
		PVBk51YyXOnDcj0QwbI = PVBk51YyXOnDcj0QwbI[0][2:]
		PVBk51YyXOnDcj0QwbI = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(PVBk51YyXOnDcj0QwbI)
		if Nnxm30dfoBWRYpIC7KsQGl: PVBk51YyXOnDcj0QwbI = PVBk51YyXOnDcj0QwbI.decode('utf8')
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('src="(.*?)"',PVBk51YyXOnDcj0QwbI,QPuHKNAT4jmCRg.DOTALL)
	else: VV7yf2htDCBU6EeSX8TJQM = ''
	if not VV7yf2htDCBU6EeSX8TJQM: return 'Error: Resolver Failed TVFUN',[],[]
	VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def tjh8yKJSuBg70wAoX(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-MYEGYVIP-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('class="col-sm-12".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: return 'Error: Resolver Failed MYEGYVIP',[],[]
	VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def Ye6gQpcIJL(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed','')
	url = url.replace('.com/','.com/player/metadata/')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-DAILYMOTION-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	aCEzNgy0L4kujFlUToeIitBvX759 = 'Error: Resolver Failed DAILYMOTION'
	nTcLSovCNZYedhjP5U7bp = QPuHKNAT4jmCRg.findall('"error".*?"messagee":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if nTcLSovCNZYedhjP5U7bp: aCEzNgy0L4kujFlUToeIitBvX759 = nTcLSovCNZYedhjP5U7bp[0]
	url = QPuHKNAT4jmCRg.findall('x-mpegURL","url":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not url and aCEzNgy0L4kujFlUToeIitBvX759:
		return aCEzNgy0L4kujFlUToeIitBvX759,[],[]
	VV7yf2htDCBU6EeSX8TJQM = url[0].replace('\\','')
	gyGwI3NoaQV8uC0YjZUTHS,UdxpbPKgBScklJLj542O0feZsro = RjzVfbE0ILcNXFQJniSMBOskK13ox(VV7yf2htDCBU6EeSX8TJQM)
	FFKnMSt5ROf9PLeBd = QPuHKNAT4jmCRg.findall('"owner":{"id":"(.*?)","screenname":"(.*?)","url":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if FFKnMSt5ROf9PLeBd: HFIoOg2hB7Q5E13,uc3tIV2WBfPmnsS4wbFhG,p5pgoLR7X1InKANeq = FFKnMSt5ROf9PLeBd[0]
	else: HFIoOg2hB7Q5E13,uc3tIV2WBfPmnsS4wbFhG,p5pgoLR7X1InKANeq = '','',''
	p5pgoLR7X1InKANeq = p5pgoLR7X1InKANeq.replace('\/','/')
	uc3tIV2WBfPmnsS4wbFhG = kWfpQA7tTjSPyLbNIeMr1Hui5(uc3tIV2WBfPmnsS4wbFhG)
	xitERh4TD2jGJPq5Nuv39CAmg = ['[COLOR FFC89008]OWNER:  '+uc3tIV2WBfPmnsS4wbFhG+'[/COLOR]']+gyGwI3NoaQV8uC0YjZUTHS
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = [p5pgoLR7X1InKANeq]+UdxpbPKgBScklJLj542O0feZsro
	ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الملف المناسب: ('+str(len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)-1)+' ملف)',xitERh4TD2jGJPq5Nuv39CAmg)
	if ShT1xUHjlDotkRuPq7gv==-1: return 'EXIT_RESOLVER',[],[]
	elif ShT1xUHjlDotkRuPq7gv==0:
		PMHouEth10egUaq8niQ = GJtcqTv68ZQpwxYFiDg.argv[0]+'?type=folder&mode=402&url='+p5pgoLR7X1InKANeq+'&textt='+uc3tIV2WBfPmnsS4wbFhG
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin("Container.Update("+PMHouEth10egUaq8niQ+")")
		return 'EXIT_RESOLVER',[],[]
	VV7yf2htDCBU6EeSX8TJQM =  LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
def LRMCkhDVuY(VV7yf2htDCBU6EeSX8TJQM):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',VV7yf2htDCBU6EeSX8TJQM,'','','','','RESOLVERS-BOKRA-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if '.json' in VV7yf2htDCBU6EeSX8TJQM: url = QPuHKNAT4jmCRg.findall('"src":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	else: url = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[0]
	if 'http' not in url: url = 'http:'+url
	return '',[''],[url]
def czXN7QRslFr(url):
	headers = { 'User-Agent' : '' }
	if 'op=download_orig' in url:
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-MOSHAHDA-1st')
		items = QPuHKNAT4jmCRg.findall('direct link.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if items: return '',[''],[items[0]]
		else:
			qNEnDMwm1Vfastx2ZkpRh = QPuHKNAT4jmCRg.findall('class="err">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if qNEnDMwm1Vfastx2ZkpRh:
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من الموقع الاصلي',qNEnDMwm1Vfastx2ZkpRh[0])
				return 'Error: '+qNEnDMwm1Vfastx2ZkpRh[0],[],[]
	else:
		Vuk3760YmGdQaZ92MfwcNKE = 'movizland'
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-MOSHAHDA-2nd')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('Form method="POST" action=\'(.*?)\'(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: return 'Error: Resolver Failed MOSHAHDA',[],[]
		FsnXTNzcG53RUk = TTCRYZroizb[0][0]
		wltPGJcYo12Ed = TTCRYZroizb[0][1]
		if '.rar' in wltPGJcYo12Ed or '.zip' in wltPGJcYo12Ed: return 'Error: MOSHAHDA Not a video file',[],[]
		items = QPuHKNAT4jmCRg.findall('name="(.*?)".*?value="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		E9ODYnfpm54GJTd2xRrV = {}
		for pphVUbJkGtHXndg84iZl2DPImSzoC,pp8iHB3W9Cs in items:
			E9ODYnfpm54GJTd2xRrV[pphVUbJkGtHXndg84iZl2DPImSzoC] = pp8iHB3W9Cs
		data = YZpVhcRlPs3n0FrD(E9ODYnfpm54GJTd2xRrV)
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,FsnXTNzcG53RUk,data,headers,'','RESOLVERS-MOSHAHDA-3rd')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = TTCRYZroizb[0][0]
		wltPGJcYo12Ed = TTCRYZroizb[0][1]
		items = QPuHKNAT4jmCRg.findall('file:"(.*?)"(,label:".*?"|)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		viJ8DjTKIVc3l1dernfBWmwY6yLs,xitERh4TD2jGJPq5Nuv39CAmg,H9Jxugok0p1bSMlzrs,LL8heV7kxYI5bOjEZ6XaUQWwfPA,XMk5qG7EFurCd = [],[],[],[],[]
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if '.m3u8' in VV7yf2htDCBU6EeSX8TJQM:
				viJ8DjTKIVc3l1dernfBWmwY6yLs,H9Jxugok0p1bSMlzrs = RjzVfbE0ILcNXFQJniSMBOskK13ox(VV7yf2htDCBU6EeSX8TJQM)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA = LL8heV7kxYI5bOjEZ6XaUQWwfPA + H9Jxugok0p1bSMlzrs
				if viJ8DjTKIVc3l1dernfBWmwY6yLs[0]=='-1': xitERh4TD2jGJPq5Nuv39CAmg.append(' سيرفر خاص '+'m3u8 '+Vuk3760YmGdQaZ92MfwcNKE)
				else:
					for title in viJ8DjTKIVc3l1dernfBWmwY6yLs:
						xitERh4TD2jGJPq5Nuv39CAmg.append(' سيرفر خاص '+'m3u8 '+Vuk3760YmGdQaZ92MfwcNKE+' '+title)
			else:
				title = title.replace(',label:"','')
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+Vuk3760YmGdQaZ92MfwcNKE+' '+title
				xitERh4TD2jGJPq5Nuv39CAmg.append(title)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		VV7yf2htDCBU6EeSX8TJQM = 'http://moshahda.online' + download
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,VV7yf2htDCBU6EeSX8TJQM,'',headers,'','RESOLVERS-MOSHAHDA-5th')
		items = QPuHKNAT4jmCRg.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for id,Q6FbqZ9uIe8v2xaTHhfDCJ,hash,P5xioNdCft6AVaWHRIszu in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+Vuk3760YmGdQaZ92MfwcNKE+' '+P5xioNdCft6AVaWHRIszu.split('x')[1]
			VV7yf2htDCBU6EeSX8TJQM = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+Q6FbqZ9uIe8v2xaTHhfDCJ+'&hash='+hash
			XMk5qG7EFurCd.append(P5xioNdCft6AVaWHRIszu)
			xitERh4TD2jGJPq5Nuv39CAmg.append(title)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		XMk5qG7EFurCd = set(XMk5qG7EFurCd)
		dehCJYB0N2mLp,WLC1unB3do = [],[]
		for title in xitERh4TD2jGJPq5Nuv39CAmg:
			yyXTVzB0FbxSrsHfi1J4uQYq = QPuHKNAT4jmCRg.findall(" (\d*x|\d*)&&",title+'&&',QPuHKNAT4jmCRg.DOTALL)
			for P5xioNdCft6AVaWHRIszu in XMk5qG7EFurCd:
				if yyXTVzB0FbxSrsHfi1J4uQYq[0] in P5xioNdCft6AVaWHRIszu:
					title = title.replace(yyXTVzB0FbxSrsHfi1J4uQYq[0],P5xioNdCft6AVaWHRIszu.split('x')[1])
			dehCJYB0N2mLp.append(title)
		for PXBFxvuUlLDHGpm58 in range(len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)):
			items = QPuHKNAT4jmCRg.findall("&&(.*?)(\d*)&&",'&&'+dehCJYB0N2mLp[PXBFxvuUlLDHGpm58]+'&&',QPuHKNAT4jmCRg.DOTALL)
			WLC1unB3do.append( [dehCJYB0N2mLp[PXBFxvuUlLDHGpm58],LL8heV7kxYI5bOjEZ6XaUQWwfPA[PXBFxvuUlLDHGpm58],items[0][0],items[0][1]] )
		WLC1unB3do = sorted(WLC1unB3do, key=lambda GToyYINutA0BV: GToyYINutA0BV[3], reverse=True)
		WLC1unB3do = sorted(WLC1unB3do, key=lambda GToyYINutA0BV: GToyYINutA0BV[2], reverse=False)
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
		for PXBFxvuUlLDHGpm58 in range(len(WLC1unB3do)):
			xitERh4TD2jGJPq5Nuv39CAmg.append(WLC1unB3do[PXBFxvuUlLDHGpm58][0])
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(WLC1unB3do[PXBFxvuUlLDHGpm58][1])
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==0: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def OqpCoacN8DGS7jvQ(url):
	FtKo2AMUynNdTaYCljkxOe = url.split('?')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = FtKo2AMUynNdTaYCljkxOe[0]
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','RESOLVERS-E5TSAR-1st')
	items = QPuHKNAT4jmCRg.findall('Please wait.*?href=\'(.*?)\'',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	url = items[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def WczavojC5V8nqZ4kHQgd(url):
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('redirect_url.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if lZqkuhgaBHSVX8NItKG05cdLJe7Ao: return '',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def YYZ8fLtChS60aJD(url):
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('href","(htt.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if lZqkuhgaBHSVX8NItKG05cdLJe7Ao: return '',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def p0aBKYXZUh(url):
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,errno = [],[],''
	if '/wp-admin/' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
		Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-FAJERSHOW-2nd')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		if iRSILm7Nv6DZAaztp.startswith('http'): lZqkuhgaBHSVX8NItKG05cdLJe7Ao = iRSILm7Nv6DZAaztp
		else:
			lc154VhT9DCqMk8 = QPuHKNAT4jmCRg.findall('''src=['"](.*?)['"]''',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			if lc154VhT9DCqMk8:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lc154VhT9DCqMk8[0]
				lc154VhT9DCqMk8 = QPuHKNAT4jmCRg.findall('source=(.*?)[&$]',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,QPuHKNAT4jmCRg.DOTALL)
				if lc154VhT9DCqMk8:
					lZqkuhgaBHSVX8NItKG05cdLJe7Ao = NdVvO42riJpCWElX(lc154VhT9DCqMk8[0])
					return '',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	elif '/links/' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','',True,'','RESOLVERS-FAJERSHOW-1st')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		if 'Location' in list(nbdMp8UuhzP3oq4cDWj6eyZVt.headers.keys()): lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('id="link".*?href="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)[0]
	if '/v/' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao or '/f/' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('/f/','/api/source/')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('/v/','/api/source/')
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','RESOLVERS-FAJERSHOW-3rd')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		items = QPuHKNAT4jmCRg.findall('"file":"(.*?)","label":"(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\\','')
				xitERh4TD2jGJPq5Nuv39CAmg.append(title)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		else:
			items = QPuHKNAT4jmCRg.findall('"file":"(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			if items:
				VV7yf2htDCBU6EeSX8TJQM = items[0]
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\\','')
				xitERh4TD2jGJPq5Nuv39CAmg.append('')
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	else: return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==0: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def BM6R2vOGT9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-MOVS4U-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,errno = [],[],''
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if 'movs4u' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','RESOLVERS-MOVS4U-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="player"(.*?)videojs',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<source src="(.*?)".*?label="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for VV7yf2htDCBU6EeSX8TJQM,G7XkvOrob5CBiAMFcVemDz4EZ1atxg in items:
				xitERh4TD2jGJPq5Nuv39CAmg.append(G7XkvOrob5CBiAMFcVemDz4EZ1atxg)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	elif 'main_player.php' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('url=(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','RESOLVERS-MOVS4U-3rd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		lc154VhT9DCqMk8 = QPuHKNAT4jmCRg.findall('"file": "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		lc154VhT9DCqMk8 = lc154VhT9DCqMk8[0]
		xitERh4TD2jGJPq5Nuv39CAmg.append('')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(lc154VhT9DCqMk8)
	elif 'download_link' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('<center><a href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==0: return 'Error: Resolver Failed MOVS4U',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def Vo1bUqIvAi(url):
	website = EGcFon0zR4mSL1['CIMACLUB'][0]
	headers = {'Referer':website}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',url,'',headers,'','','RESOLVERS-CIMACLUB-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('download=.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall("sources: \['(.*?)'",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall("file:'(.*?)'",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]+'|Referer='+website
		return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	if 'name="Xtoken"' in Ht6Gg8lbciAd9FaUQVs:
		RkK8s0IU5l1u46mWM3YBqzPh = QPuHKNAT4jmCRg.findall('name="Xtoken" content="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if RkK8s0IU5l1u46mWM3YBqzPh:
			VV7yf2htDCBU6EeSX8TJQM = RkK8s0IU5l1u46mWM3YBqzPh[0]
			VV7yf2htDCBU6EeSX8TJQM = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(VV7yf2htDCBU6EeSX8TJQM)
			if Nnxm30dfoBWRYpIC7KsQGl: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.decode('utf8','ignore')
			VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('http.*?(http.*?),',VV7yf2htDCBU6EeSX8TJQM,QPuHKNAT4jmCRg.DOTALL)
			if VV7yf2htDCBU6EeSX8TJQM:
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]+'|Referer='+website
				return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def VPK7iuwqrt(url):
	arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO = [],[]
	if '/1/' in url:
		VV7yf2htDCBU6EeSX8TJQM = url.replace('/1/','/4/')
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',VV7yf2htDCBU6EeSX8TJQM,'','',False,'','RESOLVERS-EGYBEST1-1st')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<video(.*?)</video>',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?size="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF in items:
				if VV7yf2htDCBU6EeSX8TJQM not in YsDryBSXquzdEUta8kxjfO:
					YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
					BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
					arZijTmC4eXBKvgEAHxPD7JtwOh.append(BHgLX9GZTb2jJrWiNKE+'  '+i5DftlhA6vQ2GF)
			return '',arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO
	elif '/d/' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',url,'','','','','RESOLVERS-EGYBEST1-2nd')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<iframe.*?src="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if VV7yf2htDCBU6EeSX8TJQM:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0].replace('/1/','/4/')
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',VV7yf2htDCBU6EeSX8TJQM,'','',False,'','RESOLVERS-EGYBEST1-3rd')
			iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
			VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('class.*?href="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			if VV7yf2htDCBU6EeSX8TJQM: return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def EVXS46FUM7(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',url,'','','','','RESOLVERS-EGYBEST3-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	data = QPuHKNAT4jmCRg.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if data:
		gqXKQD0MoUFenut,id,Aqvx5WitGpgnfMVmFD7rKb6 = data[0]
		data = 'op='+gqXKQD0MoUFenut+'&id='+id+'&fname='+Aqvx5WitGpgnfMVmFD7rKb6
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',url,data,headers,'','','RESOLVERS-EGYBEST3-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"referer" value="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if VV7yf2htDCBU6EeSX8TJQM: return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def iiRDUdxsca(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.split('?named=',1)[0].strip('?').strip('/').strip('&')
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,items,lc154VhT9DCqMk8 = [],[],[],''
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,True,'','RESOLVERS-EGYBEST-1st')
	if 'Location' in list(nbdMp8UuhzP3oq4cDWj6eyZVt.headers.keys()): lc154VhT9DCqMk8 = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
	if 'http' in lc154VhT9DCqMk8:
		if '__watch' in url: lc154VhT9DCqMk8 = lc154VhT9DCqMk8.replace('/f/','/v/')
		RRTy6Z9EV1sWl8MDwHtXidL0 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split('?PHPSID=')[1]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+RRTy6Z9EV1sWl8MDwHtXidL0 }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',lc154VhT9DCqMk8,'',headers,False,'','EGYBEST-PLAY-3rd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		if '/f/' in lc154VhT9DCqMk8: items = QPuHKNAT4jmCRg.findall('<h2>.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		elif '/v/' in lc154VhT9DCqMk8: items = QPuHKNAT4jmCRg.findall('id="video".*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if items: return [],[''],[ items[0] ]
		elif '<h1>404</h1>' in Ht6Gg8lbciAd9FaUQVs:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def TzRiNDxkrd(VV7yf2htDCBU6EeSX8TJQM):
	FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('postid=(.*?)&serverid=(.*?)&&',VV7yf2htDCBU6EeSX8TJQM+'&&',QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	ppKgjR9ki431DYoZswP0nFJOIuX,zHAUyrXjf1aSmh = FtKo2AMUynNdTaYCljkxOe[0]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+ppKgjR9ki431DYoZswP0nFJOIuX+'&serverid='+zHAUyrXjf1aSmh
	headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
def vbokuZrzD6(url):
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	Eudgv5cTUHF2AzKpkx = {'Referer':BHgLX9GZTb2jJrWiNKE,'Accept-Encoding':'gzip, deflate'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(ooDaNCkx4c0FjJs,'GET',url,'',Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-MYCIMA-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('player.qualityselector(.*?)formats:',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ''
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('format: \'(\d.*?)\', src: "(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			xitERh4TD2jGJPq5Nuv39CAmg.append(title)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==1: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = LL8heV7kxYI5bOjEZ6XaUQWwfPA[0]
		elif len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)>1:
			ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('أختر الملف المناسب', xitERh4TD2jGJPq5Nuv39CAmg)
			if ShT1xUHjlDotkRuPq7gv==-1: return '',[],[]
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = TTCRYZroizb[0]
	if not lZqkuhgaBHSVX8NItKG05cdLJe7Ao: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
def F4b2neDjfi(url):
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	Eudgv5cTUHF2AzKpkx = {'Referer':BHgLX9GZTb2jJrWiNKE,'Accept-Encoding':'gzip, deflate'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(ooDaNCkx4c0FjJs,'GET',url,'',Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-WECIMA-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('player.qualityselector(.*?)formats:',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ''
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('format: \'(\d.*?)\', src: "(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			xitERh4TD2jGJPq5Nuv39CAmg.append(title)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==1: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = LL8heV7kxYI5bOjEZ6XaUQWwfPA[0]
		elif len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)>1:
			ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('أختر الملف المناسب', xitERh4TD2jGJPq5Nuv39CAmg)
			if ShT1xUHjlDotkRuPq7gv==-1: return '',[],[]
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	if not lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = TTCRYZroizb[0]
	if not lZqkuhgaBHSVX8NItKG05cdLJe7Ao: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
def yeoi8n2Xb1(VV7yf2htDCBU6EeSX8TJQM):
	FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',VV7yf2htDCBU6EeSX8TJQM+'&&',QPuHKNAT4jmCRg.DOTALL)
	url,ppKgjR9ki431DYoZswP0nFJOIuX,zHAUyrXjf1aSmh = FtKo2AMUynNdTaYCljkxOe[0]
	data = {'post_id':ppKgjR9ki431DYoZswP0nFJOIuX,'server':zHAUyrXjf1aSmh}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',url,data,'','','','RESOLVERS-AKOAMCAM-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('iframe src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
def PeR0asuyA2(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','RESOLVERS-CIMALIGHT-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<iframe.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		if VV7yf2htDCBU6EeSX8TJQM: return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def oAOYptLgIS(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','RESOLVERS-CIMACLUP-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<IFRAME SRC="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
def wJbtYB85UM(url):
	rrU0IR1Aga6Y = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	if 'index=' in url:
		headers = {'Referer':rrU0IR1Aga6Y}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','RESOLVERS-CIMANOW-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
			if 'cimanow' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('https://','http://')
				nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','','RESOLVERS-CIMANOW-2nd')
				iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
				items = QPuHKNAT4jmCRg.findall('source src="(.*?)".*?size="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
				xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
				eek0phlJjL6MWVXsmy7wFPz2oT = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'url')
				for VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF in reversed(items):
					VV7yf2htDCBU6EeSX8TJQM = eek0phlJjL6MWVXsmy7wFPz2oT+VV7yf2htDCBU6EeSX8TJQM+'|Referer='+eek0phlJjL6MWVXsmy7wFPz2oT
					xitERh4TD2jGJPq5Nuv39CAmg.append(i5DftlhA6vQ2GF)
					LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
				return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
			else: return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'|Referer='+rrU0IR1Aga6Y
	return '',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
def btcIfR3Qvoza5(VV7yf2htDCBU6EeSX8TJQM):
	rrU0IR1Aga6Y = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'url')
	if 'postid' in VV7yf2htDCBU6EeSX8TJQM:
		FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',VV7yf2htDCBU6EeSX8TJQM+'&&',QPuHKNAT4jmCRg.DOTALL)
		url,ppKgjR9ki431DYoZswP0nFJOIuX,zHAUyrXjf1aSmh = FtKo2AMUynNdTaYCljkxOe[0]
		data = {'id':ppKgjR9ki431DYoZswP0nFJOIuX,'server':zHAUyrXjf1aSmh}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',url,data,'','','','RESOLVERS-CIMANOW-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('iframe src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
		if 'cimanow' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			headers = {'Referer':rrU0IR1Aga6Y,'User-Agent':''}
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','','RESOLVERS-CIMANOW-2nd')
			iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
			items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?size="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
			eek0phlJjL6MWVXsmy7wFPz2oT = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'url')
			for VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF in reversed(items):
				VV7yf2htDCBU6EeSX8TJQM = eek0phlJjL6MWVXsmy7wFPz2oT+VV7yf2htDCBU6EeSX8TJQM+'|Referer='+eek0phlJjL6MWVXsmy7wFPz2oT
				xitERh4TD2jGJPq5Nuv39CAmg.append(i5DftlhA6vQ2GF)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
			return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
		else: return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	else:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'|Referer='+rrU0IR1Aga6Y
		return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
def nnPi78q5GO(VV7yf2htDCBU6EeSX8TJQM):
	if 'postid' in VV7yf2htDCBU6EeSX8TJQM:
		FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('postid=(.*?)&serverid=(.*?)&&',VV7yf2htDCBU6EeSX8TJQM+'&&',QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		ppKgjR9ki431DYoZswP0nFJOIuX,zHAUyrXjf1aSmh = FtKo2AMUynNdTaYCljkxOe[0]
		qqivDAF1ZS = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'url')
		url = qqivDAF1ZS+'/ajaxCenter?_action=getserver&_post_id='+ppKgjR9ki431DYoZswP0nFJOIuX+'&serverid='+zHAUyrXjf1aSmh
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-ARBLIONZ-1st')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('\n','').replace('\r','')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	elif '/redirect/' in VV7yf2htDCBU6EeSX8TJQM:
		K0XWzFpPsn1JGoxZVr6gDali2eE = 0
		while '/redirect/' in VV7yf2htDCBU6EeSX8TJQM and K0XWzFpPsn1JGoxZVr6gDali2eE<5:
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',VV7yf2htDCBU6EeSX8TJQM,'','','','','RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(nbdMp8UuhzP3oq4cDWj6eyZVt.headers.keys()): VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
			K0XWzFpPsn1JGoxZVr6gDali2eE += 1
		return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def CbnORTUHL5(url):
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	headers = {'Referer':BHgLX9GZTb2jJrWiNKE,'User-Agent':yWgZFzdaNR5iw6m8Q9G7CL()}
	if '/embed-' in url:
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-ARABSEED-2nd')
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if VV7yf2htDCBU6EeSX8TJQM:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0].replace('https','http')
			return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	else:
		MiBzEPIrcWteljfUGO = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','RESOLVERS-ARABSEED-3rd')
		Ht6Gg8lbciAd9FaUQVs = MiBzEPIrcWteljfUGO.content
		Eudgv5cTUHF2AzKpkx = headers.copy()
		if '_lnk_' in str(MiBzEPIrcWteljfUGO.cookies):
			cookies = MiBzEPIrcWteljfUGO.cookies
			Eudgv5cTUHF2AzKpkx['Cookie'] = NdVvO42riJpCWElX(YZpVhcRlPs3n0FrD(cookies))
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('link.href = "(http.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not VV7yf2htDCBU6EeSX8TJQM: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
		else:
			VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM[0])+'&d=1'
			ykIAHx9E1umUdZqjSiBw6Kbar = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',VV7yf2htDCBU6EeSX8TJQM,'',Eudgv5cTUHF2AzKpkx,'','','RESOLVERS-ARABSEED-4th')
			Ht6Gg8lbciAd9FaUQVs = ykIAHx9E1umUdZqjSiBw6Kbar.content
			VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('id="btn".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if VV7yf2htDCBU6EeSX8TJQM:
				VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM[0])
				if 'mp4' in VV7yf2htDCBU6EeSX8TJQM and '/d/' in VV7yf2htDCBU6EeSX8TJQM: return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
				else: return 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
	return 'Error: Resolver Failed ARABSEED',[],[]
def f862dET1BF(VV7yf2htDCBU6EeSX8TJQM):
	if '_action=getserver' in VV7yf2htDCBU6EeSX8TJQM:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',VV7yf2htDCBU6EeSX8TJQM,'',headers,'','','RESOLVERS-SHAHID4U-1st')
		url = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
	else:
		FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('postid=(.*?)&serverid=(.*?)$',VV7yf2htDCBU6EeSX8TJQM,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		if not FtKo2AMUynNdTaYCljkxOe: FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('_post_id=(.*?)&serverid=(.*?)$',VV7yf2htDCBU6EeSX8TJQM,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		ppKgjR9ki431DYoZswP0nFJOIuX,zHAUyrXjf1aSmh = FtKo2AMUynNdTaYCljkxOe[0]
		BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'url')
		url = BHgLX9GZTb2jJrWiNKE+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':ppKgjR9ki431DYoZswP0nFJOIuX,'i':zHAUyrXjf1aSmh}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':VV7yf2htDCBU6EeSX8TJQM}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',url,data,headers,'','','RESOLVERS-SHAHID4U-2nd')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('src="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def WXU8hvgr1dt4FYmGJbsQe5j(Q6Q9TLeAFpYgyvVztuBEhHIb):
	bqtBMpGj1uhsK8FCe7xLi = fQ6kvwg1FrYAzXjbLT.getSetting('av.akwam.verification')
	headers = {'Cookie':bqtBMpGj1uhsK8FCe7xLi} if bqtBMpGj1uhsK8FCe7xLi else ''
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',Q6Q9TLeAFpYgyvVztuBEhHIb,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	q0MudN3AnSipB = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	bboH7uvCsfakJWimwpY = str(nbdMp8UuhzP3oq4cDWj6eyZVt.headers)
	FWklUAXSxT4q9z6fhPNs = bboH7uvCsfakJWimwpY+q0MudN3AnSipB
	if '.mp4' in FWklUAXSxT4q9z6fhPNs: VV7garqCfPMlbZTnzymGs946B = True
	else:
		v3OiwkVLEeB5sx1chgzX,uWCKp2UeRYGXINl,T7nUhk0APZCsJc4NyDuGqpOIa,BzI8SJ2jpTMb7,VV7garqCfPMlbZTnzymGs946B = '','','','',False
		captcha = QPuHKNAT4jmCRg.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',q0MudN3AnSipB,QPuHKNAT4jmCRg.DOTALL)
		if captcha: T7nUhk0APZCsJc4NyDuGqpOIa,BzI8SJ2jpTMb7 = captcha[0]
		rQyfIZxhDsvqPAlKJN7a4 = EGcFon0zR4mSL1['PYTHON'][7]
		wn0kd1pEgfSy4YG = Dx3jCK6X7lktdiE(32)
		if 0:
			data = {'user':wn0kd1pEgfSy4YG,'version':uVp7krjL48oWd3tqGYCRz5M,'url':Q6Q9TLeAFpYgyvVztuBEhHIb,'key':BzI8SJ2jpTMb7,'id':'','job':'geturls'}
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',rQyfIZxhDsvqPAlKJN7a4,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		Ht6Gg8lbciAd9FaUQVs = ''
		if Ht6Gg8lbciAd9FaUQVs.startswith('URLS='):
			deoTHkGNZX1s2mp4SvtJznIl3FyVA = kMLWTt2fO9dnGDUgHh('list',Ht6Gg8lbciAd9FaUQVs.split('URLS=',1)[1])
			for lp3eGht9uF4mMCR6YIWz in deoTHkGNZX1s2mp4SvtJznIl3FyVA:
				url = lp3eGht9uF4mMCR6YIWz['url']
				c54S3WpKgGCxhUMD2E = lp3eGht9uF4mMCR6YIWz['method']
				data = lp3eGht9uF4mMCR6YIWz['data']
				headers = lp3eGht9uF4mMCR6YIWz['headers']
				nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,c54S3WpKgGCxhUMD2E,url,data,headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				q0MudN3AnSipB = nbdMp8UuhzP3oq4cDWj6eyZVt.content
				if '.mp4' in q0MudN3AnSipB:
					VV7garqCfPMlbZTnzymGs946B = True
					break
				bboH7uvCsfakJWimwpY = str(nbdMp8UuhzP3oq4cDWj6eyZVt.headers)
				FWklUAXSxT4q9z6fhPNs = bboH7uvCsfakJWimwpY+q0MudN3AnSipB
				v3OiwkVLEeB5sx1chgzX = QPuHKNAT4jmCRg.findall('(akwamVerification\w+).*?"(eyJ.*?)"',FWklUAXSxT4q9z6fhPNs,QPuHKNAT4jmCRg.DOTALL)
				uWCKp2UeRYGXINl = QPuHKNAT4jmCRg.findall('recaptcha-token.*?"(03A.*?)"',FWklUAXSxT4q9z6fhPNs,QPuHKNAT4jmCRg.DOTALL)
				if uWCKp2UeRYGXINl: uWCKp2UeRYGXINl = uWCKp2UeRYGXINl[0]
				if v3OiwkVLEeB5sx1chgzX or uWCKp2UeRYGXINl: break
		if not VV7garqCfPMlbZTnzymGs946B:
			if not v3OiwkVLEeB5sx1chgzX:
				if captcha and not uWCKp2UeRYGXINl:
					if 1: uWCKp2UeRYGXINl = Bn9REoKDptlGYk80AJPsQj(BzI8SJ2jpTMb7,'ar',Q6Q9TLeAFpYgyvVztuBEhHIb)
					else:
						if not Ht6Gg8lbciAd9FaUQVs.startswith('ID='):
							data = {'user':wn0kd1pEgfSy4YG,'version':uVp7krjL48oWd3tqGYCRz5M,'url':Q6Q9TLeAFpYgyvVztuBEhHIb,'key':BzI8SJ2jpTMb7,'id':'','job':'getid'}
							nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',rQyfIZxhDsvqPAlKJN7a4,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
						else: Ht6Gg8lbciAd9FaUQVs = 'ID=1234::::TIMEOUT=45'
						if Ht6Gg8lbciAd9FaUQVs.startswith('ID='):
							SSH1l4UcnOdBpK5 = QPuHKNAT4jmCRg.findall('ID=(.*?)::::TIMEOUT=(.*?)$',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
							e6TK5L39Ul,GUSviMX7rNBgwVdbtf8p3ZEhaR0 = SSH1l4UcnOdBpK5[0]
							qNEnDMwm1Vfastx2ZkpRh = 'هذه العملية تحتاج وقت من 10 إلى '+GUSviMX7rNBgwVdbtf8p3ZEhaR0+' ثانية'
							smMzArf4FkJ1NDKEx = zzyalh3A275njbIKsD0EQ()
							smMzArf4FkJ1NDKEx.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',qNEnDMwm1Vfastx2ZkpRh)
							zzQBSbqLMJHZk18sYVwyn0UetR5xGW = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
							ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB,uvZEjhdLisWUKBHbXoAyRI4l = 0,0
							while ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB<int(GUSviMX7rNBgwVdbtf8p3ZEhaR0):
								Qm8DTfKEUrdMvXzO7(smMzArf4FkJ1NDKEx,int(ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB/int(GUSviMX7rNBgwVdbtf8p3ZEhaR0)*100),qNEnDMwm1Vfastx2ZkpRh,'',GUSviMX7rNBgwVdbtf8p3ZEhaR0+' / '+str(int(ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB))+'  ثانية')
								if ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB>uvZEjhdLisWUKBHbXoAyRI4l+10:
									data = {'user':wn0kd1pEgfSy4YG,'version':uVp7krjL48oWd3tqGYCRz5M,'url':Q6Q9TLeAFpYgyvVztuBEhHIb,'key':BzI8SJ2jpTMb7,'id':e6TK5L39Ul,'job':'gettoken'}
									nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',rQyfIZxhDsvqPAlKJN7a4,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
									if Ht6Gg8lbciAd9FaUQVs.startswith('TOKEN='):
										uWCKp2UeRYGXINl = Ht6Gg8lbciAd9FaUQVs.split('TOKEN=',1)[1]
										break
									uvZEjhdLisWUKBHbXoAyRI4l = ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB
								else: vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(1)
								ZJMyTnlK5zEwfcrs3mqpAoxUh8RPB = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()-zzQBSbqLMJHZk18sYVwyn0UetR5xGW
							smMzArf4FkJ1NDKEx.close()
				if uWCKp2UeRYGXINl:
					VFoX3vQTs5khH0KbICM2dr1z4UBcg = nbdMp8UuhzP3oq4cDWj6eyZVt.cookies
					gGZ6uVPSfTh25AH0kK = QPuHKNAT4jmCRg.findall('akwam_session=(.*?);',FWklUAXSxT4q9z6fhPNs,QPuHKNAT4jmCRg.DOTALL)
					if 'akwam_session' in list(VFoX3vQTs5khH0KbICM2dr1z4UBcg.keys()): gGZ6uVPSfTh25AH0kK = VFoX3vQTs5khH0KbICM2dr1z4UBcg['akwam_session']
					elif gGZ6uVPSfTh25AH0kK: gGZ6uVPSfTh25AH0kK = gGZ6uVPSfTh25AH0kK[0]
					captcha = QPuHKNAT4jmCRg.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',q0MudN3AnSipB,QPuHKNAT4jmCRg.DOTALL)
					if captcha: T7nUhk0APZCsJc4NyDuGqpOIa,BzI8SJ2jpTMb7 = captcha[0]
					if gGZ6uVPSfTh25AH0kK and captcha:
						headers = {'Cookie':'akwam_session='+gGZ6uVPSfTh25AH0kK,'Referer':Q6Q9TLeAFpYgyvVztuBEhHIb,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+uWCKp2UeRYGXINl
						nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'POST',T7nUhk0APZCsJc4NyDuGqpOIa,data,headers,False,'','RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						q0MudN3AnSipB = nbdMp8UuhzP3oq4cDWj6eyZVt.content
						try: cookies = nbdMp8UuhzP3oq4cDWj6eyZVt.cookies
						except: cookies = {}
						v3OiwkVLEeB5sx1chgzX = QPuHKNAT4jmCRg.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),QPuHKNAT4jmCRg.DOTALL)
			if v3OiwkVLEeB5sx1chgzX:
				pphVUbJkGtHXndg84iZl2DPImSzoC,v3OiwkVLEeB5sx1chgzX = v3OiwkVLEeB5sx1chgzX[0]
				bqtBMpGj1uhsK8FCe7xLi = pphVUbJkGtHXndg84iZl2DPImSzoC+'='+v3OiwkVLEeB5sx1chgzX
				fQ6kvwg1FrYAzXjbLT.setSetting('av.akwam.verification',bqtBMpGj1uhsK8FCe7xLi)
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in q0MudN3AnSipB:
					headers = {'Cookie':bqtBMpGj1uhsK8FCe7xLi}
					nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',Q6Q9TLeAFpYgyvVztuBEhHIb,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					q0MudN3AnSipB = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if not VV7garqCfPMlbZTnzymGs946B and not bqtBMpGj1uhsK8FCe7xLi: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return q0MudN3AnSipB
def ETaRVFoBXD(url,type,i5DftlhA6vQ2GF):
	YsDryBSXquzdEUta8kxjfO,arZijTmC4eXBKvgEAHxPD7JtwOh = [],[]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'','','','','RESOLVERS-AKWAM-1st')
	iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('<a href=".*?</a>',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in Y4xiULzGTKjb8mulO:
			if VV7yf2htDCBU6EeSX8TJQM in YsDryBSXquzdEUta8kxjfO: continue
			if '/watch/' not in VV7yf2htDCBU6EeSX8TJQM and '/download/' not in VV7yf2htDCBU6EeSX8TJQM: continue
			title = title.replace('</span>','').replace(' - ','').strip(' ').replace('  ',' ')
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
			arZijTmC4eXBKvgEAHxPD7JtwOh.append(title)
	if len(YsDryBSXquzdEUta8kxjfO)>1:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('بعضها يحتاج 60 ثانية',arZijTmC4eXBKvgEAHxPD7JtwOh)
		if ShT1xUHjlDotkRuPq7gv==-1: return 'Error: Resolver Canceled AKWAM',[],[]
	elif len(YsDryBSXquzdEUta8kxjfO)==1: ShT1xUHjlDotkRuPq7gv = 0
	else: return 'Error: Resolver Failed AKWAM',[],[]
	Q6Q9TLeAFpYgyvVztuBEhHIb = YsDryBSXquzdEUta8kxjfO[ShT1xUHjlDotkRuPq7gv]
	q0MudN3AnSipB = WXU8hvgr1dt4FYmGJbsQe5j(Q6Q9TLeAFpYgyvVztuBEhHIb)
	LL8heV7kxYI5bOjEZ6XaUQWwfPA,xitERh4TD2jGJPq5Nuv39CAmg = [],[]
	if type=='download':
		DrnXtHkmTPpvdEAiSJe0F9 = QPuHKNAT4jmCRg.findall('btn-loader.*?href="(.*?)"',q0MudN3AnSipB,QPuHKNAT4jmCRg.DOTALL)
		if DrnXtHkmTPpvdEAiSJe0F9:
			VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(DrnXtHkmTPpvdEAiSJe0F9[0])
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
			xitERh4TD2jGJPq5Nuv39CAmg.append(i5DftlhA6vQ2GF)
	elif type=='watch':
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('<source.*?src="(.*?)".*?size="(.*?)"',q0MudN3AnSipB,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,size in Y4xiULzGTKjb8mulO:
			if not VV7yf2htDCBU6EeSX8TJQM: continue
			if i5DftlhA6vQ2GF in size:
				xitERh4TD2jGJPq5Nuv39CAmg.append(size)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
				break
		if not LL8heV7kxYI5bOjEZ6XaUQWwfPA:
			for VV7yf2htDCBU6EeSX8TJQM,size in Y4xiULzGTKjb8mulO:
				if not VV7yf2htDCBU6EeSX8TJQM: continue
				xitERh4TD2jGJPq5Nuv39CAmg.append(size)
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if not LL8heV7kxYI5bOjEZ6XaUQWwfPA: return 'Error: Resolver Failed AKWAM',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def OjZmrI0DKb(url,pphVUbJkGtHXndg84iZl2DPImSzoC):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','',True,'','RESOLVERS-AKOAM-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	cookies = nbdMp8UuhzP3oq4cDWj6eyZVt.cookies
	if 'golink' in list(cookies.keys()):
		bqtBMpGj1uhsK8FCe7xLi = cookies['golink']
		bqtBMpGj1uhsK8FCe7xLi = NdVvO42riJpCWElX(kWfpQA7tTjSPyLbNIeMr1Hui5(bqtBMpGj1uhsK8FCe7xLi))
		items = QPuHKNAT4jmCRg.findall('route":"(.*?)"',bqtBMpGj1uhsK8FCe7xLi,QPuHKNAT4jmCRg.DOTALL)
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = items[0].replace('\/','/')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = kWfpQA7tTjSPyLbNIeMr1Hui5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
	if 'catch.is' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
		id = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split('%2F')[-1]
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = 'http://catch.is/'+id
		return 'NEED_EXTERNAL_RESOLVERS',[''],[lZqkuhgaBHSVX8NItKG05cdLJe7Ao]
	else:
		website = EGcFon0zR4mSL1['AKOAM'][0]
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',website,'','',True,'','RESOLVERS-AKOAM-2nd')
		t32JVcW6pqnkKm = nbdMp8UuhzP3oq4cDWj6eyZVt.url
		qZVG2R9dKvgpinoP7MFw0zNDmCrWk = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split('/')[2]
		pMO1bAkU4W9T = t32JVcW6pqnkKm.split('/')[2]
		lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace(qZVG2R9dKvgpinoP7MFw0zNDmCrWk,pMO1bAkU4W9T)
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' , 'Referer':lc154VhT9DCqMk8 }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST', lc154VhT9DCqMk8, '', headers, False,'','RESOLVERS-AKOAM-3rd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		items = QPuHKNAT4jmCRg.findall('direct_link":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		if not items:
			items = QPuHKNAT4jmCRg.findall('<iframe.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
			if not items:
				items = QPuHKNAT4jmCRg.findall('<embed.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		if items:
			VV7yf2htDCBU6EeSX8TJQM = items[0].replace('\/','/')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.rstrip('/')
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:' + VV7yf2htDCBU6EeSX8TJQM
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('http://','https://')
			if pphVUbJkGtHXndg84iZl2DPImSzoC=='': aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[''],[VV7yf2htDCBU6EeSX8TJQM]
			else: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = 'NEED_EXTERNAL_RESOLVERS',[''],[VV7yf2htDCBU6EeSX8TJQM]
		else: aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = 'Error: Resolver Failed AKOAM',[],[]
		return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def SzIyUxvdaHoMpt5bwNBifm(url):
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-RAPIDVIDEO-1st')
	items = QPuHKNAT4jmCRg.findall('<source src="(.*?)".*?label="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,errno = [],[],''
	if items:
		for VV7yf2htDCBU6EeSX8TJQM,G7XkvOrob5CBiAMFcVemDz4EZ1atxg in items:
			xitERh4TD2jGJPq5Nuv39CAmg.append(G7XkvOrob5CBiAMFcVemDz4EZ1atxg)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==0: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def XzBr50hDdmRunEcw(url):
	headers = {'User-Agent':''}
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-UQLOAD-1st')
	items = QPuHKNAT4jmCRg.findall('sources: \["(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		url = items[0]+'|Referer='+url
		return '',[''],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def V3WhELQqXB9jFTPtn2p17(url):
	url = url.strip('/')
	if '/embed/' in url: id = url.split('/')[4]
	else: id = url.split('/')[-1]
	url = 'https://vcstream.to/player?fid=' + id
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-VCSTREAM-1st')
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('\\','')
	items = QPuHKNAT4jmCRg.findall('file":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def mt4Le1SxMdXKBvfUcklJ0DAP3F5W(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-VIDOZA-1st')
	items = QPuHKNAT4jmCRg.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	for VV7yf2htDCBU6EeSX8TJQM,G7XkvOrob5CBiAMFcVemDz4EZ1atxg,yyXTVzB0FbxSrsHfi1J4uQYq in items:
		xitERh4TD2jGJPq5Nuv39CAmg.append(G7XkvOrob5CBiAMFcVemDz4EZ1atxg+' '+yyXTVzB0FbxSrsHfi1J4uQYq)
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==0: return 'Error: Resolver Failed VIDOZA',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def PUodrjeQsE5VlfuDv12WCZz(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-WATCHVIDEO-1st')
	items = QPuHKNAT4jmCRg.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	items = set(items)
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	for id,Q6FbqZ9uIe8v2xaTHhfDCJ,hash,G7XkvOrob5CBiAMFcVemDz4EZ1atxg,yyXTVzB0FbxSrsHfi1J4uQYq in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+id+'&mode='+Q6FbqZ9uIe8v2xaTHhfDCJ+'&hash='+hash
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-WATCHVIDEO-2nd')
		items = QPuHKNAT4jmCRg.findall('direct link.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM in items:
			xitERh4TD2jGJPq5Nuv39CAmg.append(G7XkvOrob5CBiAMFcVemDz4EZ1atxg+' '+yyXTVzB0FbxSrsHfi1J4uQYq)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)==0: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def zljp9TyBPdLK13a84RMv2Co(url):
	VV7yf2htDCBU6EeSX8TJQM = ''
	if 1 or 'Key=' not in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace('upbom.live','uppom.live')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split('/')
		id = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[3]
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = '/'.join(lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0:4])
		E9ODYnfpm54GJTd2xRrV = {'id':id,'op':'download2','method_free':'Free+Download+%3E%3E'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,E9ODYnfpm54GJTd2xRrV,'','','','RESOLVERS-UPBOM-1st')
		if 'Location' in list(nbdMp8UuhzP3oq4cDWj6eyZVt.headers.keys()): VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		if not VV7yf2htDCBU6EeSX8TJQM and nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
			VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('id="direct_link".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','RESOLVERS-UPBOM-2nd')
		if 'location' in list(nbdMp8UuhzP3oq4cDWj6eyZVt.headers.keys()): VV7yf2htDCBU6EeSX8TJQM = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['location']
	if VV7yf2htDCBU6EeSX8TJQM: return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	return 'Error: Resolver Failed UPBOM',[],[]
def qqz7vsFoublkNYQdUOnp(url):
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-LIIVIDEO-1st')
	items = QPuHKNAT4jmCRg.findall('sources:.*?"(.*?)","(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	if items:
		xitERh4TD2jGJPq5Nuv39CAmg.append('mp4')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(items[0][1])
		xitERh4TD2jGJPq5Nuv39CAmg.append('m3u8')
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(items[0][0])
		return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
def DGetBjzwkV(url):
	id = url.split('/')[-1]
	id = id.split('&')[0]
	id = id.replace('watch?v=','')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = EGcFon0zR4mSL1['YOUTUBE'][0]+'/watch?v='+id
	zhJqHKfVeudEGNAwQxSa70 = 'http://youtu.be/'+id
	F4FZOUThWuv,cOdf8WwNzTrSkl,Dpf3HrEJZQ7AiowCzGvYkx,VMBkagInZrW0RN3XOyf = '','','',''
	for kdWCpE9TjNh in range(5):
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','RESOLVERS-YOUTUBE-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		if 'itag' in Ht6Gg8lbciAd9FaUQVs: break
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(2)
	Rg2lOUamtETwQq9V = QPuHKNAT4jmCRg.findall('var ytInitialPlayerResponse = (.*?);</script>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if Rg2lOUamtETwQq9V: Rg2lOUamtETwQq9V = Rg2lOUamtETwQq9V[0]
	else: Rg2lOUamtETwQq9V = Ht6Gg8lbciAd9FaUQVs
	Rg2lOUamtETwQq9V = Rg2lOUamtETwQq9V.replace('\\u0026','&')
	VxK2NflE1Tu6iB5wUS07G8 = kMLWTt2fO9dnGDUgHh('dict',Rg2lOUamtETwQq9V)
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = ['بدون ترجمة يوتيوب'],['']
	try:
		oomTdku2YLReSbryXDWxZ = VxK2NflE1Tu6iB5wUS07G8['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for t20hY8NV5X9sobuneKjSgBZMIRGx4D in oomTdku2YLReSbryXDWxZ:
			VV7yf2htDCBU6EeSX8TJQM = t20hY8NV5X9sobuneKjSgBZMIRGx4D['baseUrl']
			try: title = t20hY8NV5X9sobuneKjSgBZMIRGx4D['name']['simpleText']
			except: title = t20hY8NV5X9sobuneKjSgBZMIRGx4D['name']['runs'][0]['textt']
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
			xitERh4TD2jGJPq5Nuv39CAmg.append(title)
	except: pass
	if len(xitERh4TD2jGJPq5Nuv39CAmg)>1:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الترجمة المناسبة:', xitERh4TD2jGJPq5Nuv39CAmg)
		if ShT1xUHjlDotkRuPq7gv==-1: return 'EXIT_RESOLVER',[],[]
		elif ShT1xUHjlDotkRuPq7gv!=0:
			VV7yf2htDCBU6EeSX8TJQM = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]+'&'
			ngvW1EwCXGdhi9T2Kp8ea = QPuHKNAT4jmCRg.findall('&(fmt=.*?)&',VV7yf2htDCBU6EeSX8TJQM)
			if ngvW1EwCXGdhi9T2Kp8ea: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace(ngvW1EwCXGdhi9T2Kp8ea[0],'fmt=vtt')
			else: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'fmt=vtt'
			F4FZOUThWuv = VV7yf2htDCBU6EeSX8TJQM.strip('&')
	qqNaQ65jokMWwLv,Ge86bi4xPVqB,oP1hA6f3q2lBbcuD7HG8kxrLi0p5J,KxU46dABV0uvmfpj2XrHWlIN,xwlYU6Frs8qoTLHy93 = [],[],[],[],[]
	try: cOdf8WwNzTrSkl = VxK2NflE1Tu6iB5wUS07G8['streamingData']['dashManifestUrl']
	except: pass
	try: Dpf3HrEJZQ7AiowCzGvYkx = VxK2NflE1Tu6iB5wUS07G8['streamingData']['hlsManifestUrl']
	except: pass
	try: qqNaQ65jokMWwLv = VxK2NflE1Tu6iB5wUS07G8['streamingData']['formats']
	except: pass
	try: Ge86bi4xPVqB = VxK2NflE1Tu6iB5wUS07G8['streamingData']['adaptiveFormats']
	except: pass
	hHf2KD01QLdUWM39xIJ8o5G6nybpw = qqNaQ65jokMWwLv+Ge86bi4xPVqB
	for dict in hHf2KD01QLdUWM39xIJ8o5G6nybpw:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			FOdvNRaAbfpUlLX7DIYt = dict['signatureCipher'].split('&')
			for F5o1sgcqZVlS in FOdvNRaAbfpUlLX7DIYt:
				key,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=',1)
				dict[key] = NdVvO42riJpCWElX(pp8iHB3W9Cs)
		if 'url' in list(dict.keys()): dict['url'] = NdVvO42riJpCWElX(dict['url'])
		oP1hA6f3q2lBbcuD7HG8kxrLi0p5J.append(dict)
	LBxV93OFmu = ''
	if 'sp=sig' in Rg2lOUamtETwQq9V:
		Lt3PdjVQyMl = QPuHKNAT4jmCRg.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if Lt3PdjVQyMl:
			Lt3PdjVQyMl = EGcFon0zR4mSL1['YOUTUBE'][0]+Lt3PdjVQyMl[0]
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',Lt3PdjVQyMl,'','','','','RESOLVERS-YOUTUBE-2nd')
			LBxV93OFmu = nbdMp8UuhzP3oq4cDWj6eyZVt.content
			import youtube_signature.cipher as HdTn7r2l1ZCNuIzGFj,youtube_signature.json_script_engine as x4KHCakLfBDr5nl0qNbtI3jmM
			FOdvNRaAbfpUlLX7DIYt = P8PRKJsak0pTSuql2ZCNe7LVHgGO5v.FOdvNRaAbfpUlLX7DIYt.Cipher()
			FOdvNRaAbfpUlLX7DIYt._object_cache = {}
			OhK65yQLJNEce9UDtsFga3X = FOdvNRaAbfpUlLX7DIYt._load_javascript(LBxV93OFmu)
			O6AUDswfZgByq7E40txCKj = kMLWTt2fO9dnGDUgHh('str',str(OhK65yQLJNEce9UDtsFga3X))
			aA6gP5ZjD3Fw9z0qXMV = P8PRKJsak0pTSuql2ZCNe7LVHgGO5v.w0U2qVIL8GmO571Q3Mhx.JsonScriptEngine(O6AUDswfZgByq7E40txCKj)
	for dict in oP1hA6f3q2lBbcuD7HG8kxrLi0p5J:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>1:
			KxU46dABV0uvmfpj2XrHWlIN.append(dict)
		elif LBxV93OFmu and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			wwCzgrfVHEOh03p1RMdkU8SPXc = aA6gP5ZjD3Fw9z0qXMV.execute(dict['s'])
			if wwCzgrfVHEOh03p1RMdkU8SPXc!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+wwCzgrfVHEOh03p1RMdkU8SPXc
				KxU46dABV0uvmfpj2XrHWlIN.append(dict)
	for dict in KxU46dABV0uvmfpj2XrHWlIN:
		UQIq1jCWgFi4MTV0K97bfSe,rGxfJKQqkbN9Wu0MhE8POigSId6o,dtSYvVs3WXcPH0ZDzNGeEaIMhjQ,bnZAcrOuJCM5z30RWQmlEYgqoLk,fKHWwULbCpDmNhIstJvk4EBO0,E03sXv1wm6 = 'unknown','unknown','unknown','Unknown','','0'
		try:
			ToW3576Ctw = dict['type']
			ToW3576Ctw = ToW3576Ctw.replace('+','')
			items = QPuHKNAT4jmCRg.findall('(.*?)/(.*?);.*?"(.*?)"',ToW3576Ctw,QPuHKNAT4jmCRg.DOTALL)
			bnZAcrOuJCM5z30RWQmlEYgqoLk,UQIq1jCWgFi4MTV0K97bfSe,fKHWwULbCpDmNhIstJvk4EBO0 = items[0]
			DqGn86HOe7Kb4U5tofYxszlNLE2Qu = fKHWwULbCpDmNhIstJvk4EBO0.split(',')
			rGxfJKQqkbN9Wu0MhE8POigSId6o = ''
			for F5o1sgcqZVlS in DqGn86HOe7Kb4U5tofYxszlNLE2Qu: rGxfJKQqkbN9Wu0MhE8POigSId6o += F5o1sgcqZVlS.split('.')[0]+','
			rGxfJKQqkbN9Wu0MhE8POigSId6o = rGxfJKQqkbN9Wu0MhE8POigSId6o.strip(',')
			if 'bitrate' in list(dict.keys()): E03sXv1wm6 = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: E03sXv1wm6 = ''
			if bnZAcrOuJCM5z30RWQmlEYgqoLk=='textt': continue
			elif ',' in ToW3576Ctw:
				bnZAcrOuJCM5z30RWQmlEYgqoLk = 'A+V'
				dtSYvVs3WXcPH0ZDzNGeEaIMhjQ = UQIq1jCWgFi4MTV0K97bfSe+'  '+E03sXv1wm6+dict['size'].split('x')[1]
			elif bnZAcrOuJCM5z30RWQmlEYgqoLk=='video':
				bnZAcrOuJCM5z30RWQmlEYgqoLk = 'Video'
				dtSYvVs3WXcPH0ZDzNGeEaIMhjQ = E03sXv1wm6+dict['size'].split('x')[1]+'  '+dict['fps']+'fps'+'  '+UQIq1jCWgFi4MTV0K97bfSe
			elif bnZAcrOuJCM5z30RWQmlEYgqoLk=='audio':
				bnZAcrOuJCM5z30RWQmlEYgqoLk = 'Audio'
				dtSYvVs3WXcPH0ZDzNGeEaIMhjQ = E03sXv1wm6+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+'  '+UQIq1jCWgFi4MTV0K97bfSe
		except:
			CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
			if CeJXk5gb27o!='NoneType: None\n': GJtcqTv68ZQpwxYFiDg.stderr.write(CeJXk5gb27o)
		if 'dur=' in dict['url']: VVaBpWQDAfx5dO4GSMmstz78eRFYw = round(0.5+float(dict['url'].split('dur=',1)[1].split('&',1)[0]))
		elif 'approxDurationMs' in list(dict.keys()): VVaBpWQDAfx5dO4GSMmstz78eRFYw = round(0.5+float(dict['approxDurationMs'])/1000)
		else: VVaBpWQDAfx5dO4GSMmstz78eRFYw = '0'
		if 'bitrate' not in list(dict.keys()): E03sXv1wm6 = dict['size'].split('x')[1]
		else: E03sXv1wm6 = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = bnZAcrOuJCM5z30RWQmlEYgqoLk+':  '+dtSYvVs3WXcPH0ZDzNGeEaIMhjQ+'  ('+rGxfJKQqkbN9Wu0MhE8POigSId6o+','+dict['itag']+')'
		dict['quality'] = dtSYvVs3WXcPH0ZDzNGeEaIMhjQ.split('  ')[0].split('kbps')[0]
		dict['type2'] = bnZAcrOuJCM5z30RWQmlEYgqoLk
		dict['filetype'] = UQIq1jCWgFi4MTV0K97bfSe
		dict['codecs'] = fKHWwULbCpDmNhIstJvk4EBO0
		dict['duration'] = VVaBpWQDAfx5dO4GSMmstz78eRFYw
		dict['bitrate'] = E03sXv1wm6
		xwlYU6Frs8qoTLHy93.append(dict)
	owaD504frQ7Y,ZoEcxTIrJzpWVCwnOm,lIpyCxfn3utAS,iW1xcE37SgjHtDXeAMP8aslUJLh9,sskqhHpgm5J1IvnwNRDYPrEi36Ft = [],[],[],[],[]
	VcusnrYUIK8GR1p0aCN3gxftF2bZ6,XBoeCHdRjbMGUkKtpr,Ci9I7t5EQrk0HYJ,n2ndtmeJwxGysTKiLkMgC73H1vYU,tBFC7gj5V6KdXWoPrG1RvfO = [],[],[],[],[]
	if cOdf8WwNzTrSkl:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
		dict['url'] = cOdf8WwNzTrSkl
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		xwlYU6Frs8qoTLHy93.append(dict)
	if Dpf3HrEJZQ7AiowCzGvYkx:
		viJ8DjTKIVc3l1dernfBWmwY6yLs,H9Jxugok0p1bSMlzrs = RjzVfbE0ILcNXFQJniSMBOskK13ox(Dpf3HrEJZQ7AiowCzGvYkx)
		qqwCeyToP62d9EJ3uks5zhiHvxVcZ = list(zip(viJ8DjTKIVc3l1dernfBWmwY6yLs,H9Jxugok0p1bSMlzrs))
		for title,VV7yf2htDCBU6EeSX8TJQM in qqwCeyToP62d9EJ3uks5zhiHvxVcZ:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = VV7yf2htDCBU6EeSX8TJQM
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[0].rsplit('  ')[-1]
			else: dict['bitrate'] = '10'
			if title.count('  ')>1:
				i5DftlhA6vQ2GF = title.rsplit('  ')[-3]
				if i5DftlhA6vQ2GF.isdigit(): dict['quality'] = i5DftlhA6vQ2GF
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+dict['bitrate']+'kbps  '+dict['quality']
			xwlYU6Frs8qoTLHy93.append(dict)
	xwlYU6Frs8qoTLHy93 = sorted(xwlYU6Frs8qoTLHy93,reverse=True,key=lambda key: float(key['bitrate']))
	if not xwlYU6Frs8qoTLHy93:
		GhpNfPVMB2uRnqasFL6K = QPuHKNAT4jmCRg.findall('class="messagee">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		fl57MHCK8LhbtieNY0QUck4AO = QPuHKNAT4jmCRg.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		IIEUd7xqAfnlYvgtaCMQ5h = QPuHKNAT4jmCRg.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		PPgIRJtB2XQhmfzoU4 = QPuHKNAT4jmCRg.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		try: Rs8TVdy7vYwnHEXqeU5If9K = VxK2NflE1Tu6iB5wUS07G8['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][0]['textt']
		except: Rs8TVdy7vYwnHEXqeU5If9K = ''
		try: RWKmiqnE5dtHVyrP60ACXBSJu = VxK2NflE1Tu6iB5wUS07G8['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][0]['runs'][0]['textt']
		except: RWKmiqnE5dtHVyrP60ACXBSJu = ''
		try: F0jXxDYfRI9TMPWs = VxK2NflE1Tu6iB5wUS07G8['playabilityStatus']['reason']
		except: F0jXxDYfRI9TMPWs = ''
		if GhpNfPVMB2uRnqasFL6K or fl57MHCK8LhbtieNY0QUck4AO or IIEUd7xqAfnlYvgtaCMQ5h or PPgIRJtB2XQhmfzoU4 or Rs8TVdy7vYwnHEXqeU5If9K or RWKmiqnE5dtHVyrP60ACXBSJu or F0jXxDYfRI9TMPWs:
			if   GhpNfPVMB2uRnqasFL6K: qNEnDMwm1Vfastx2ZkpRh = GhpNfPVMB2uRnqasFL6K[0]
			elif fl57MHCK8LhbtieNY0QUck4AO: qNEnDMwm1Vfastx2ZkpRh = fl57MHCK8LhbtieNY0QUck4AO[0]
			elif IIEUd7xqAfnlYvgtaCMQ5h: qNEnDMwm1Vfastx2ZkpRh = IIEUd7xqAfnlYvgtaCMQ5h[0]
			elif PPgIRJtB2XQhmfzoU4: qNEnDMwm1Vfastx2ZkpRh = PPgIRJtB2XQhmfzoU4[0]
			elif Rs8TVdy7vYwnHEXqeU5If9K: qNEnDMwm1Vfastx2ZkpRh = Rs8TVdy7vYwnHEXqeU5If9K
			elif RWKmiqnE5dtHVyrP60ACXBSJu: qNEnDMwm1Vfastx2ZkpRh = RWKmiqnE5dtHVyrP60ACXBSJu
			elif F0jXxDYfRI9TMPWs: qNEnDMwm1Vfastx2ZkpRh = F0jXxDYfRI9TMPWs
			iTMWQBKVHN62ewl = qNEnDMwm1Vfastx2ZkpRh.replace('\n','').strip(' ')
			HfjxYLnE1uQNXTDI = '[COLOR FFC89008]هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن[/COLOR]'
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من الموقع والمبرمج',HfjxYLnE1uQNXTDI+'\n\n'+iTMWQBKVHN62ewl)
			return 'Error    : Resolver YOUTUBE Failed: '+iTMWQBKVHN62ewl,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	t7tT9zyPWEJMxN,ruMJlsf0LIDmjX2N1vcPiw8,cM62KwiojhU0yHdq1QTmFLuaY3W = [],[],[]
	for dict in xwlYU6Frs8qoTLHy93:
		if dict['type2']=='Video':
			owaD504frQ7Y.append(dict['title'])
			VcusnrYUIK8GR1p0aCN3gxftF2bZ6.append(dict)
		elif dict['type2']=='Audio':
			ZoEcxTIrJzpWVCwnOm.append(dict['title'])
			XBoeCHdRjbMGUkKtpr.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): E03sXv1wm6 = '0'
			else: E03sXv1wm6 = dict['bitrate']
			t7tT9zyPWEJMxN.append([dict,{},title,E03sXv1wm6])
		else:
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): E03sXv1wm6 = '0'
			else: E03sXv1wm6 = dict['bitrate']
			t7tT9zyPWEJMxN.append([dict,{},title,E03sXv1wm6])
			lIpyCxfn3utAS.append(title)
			Ci9I7t5EQrk0HYJ.append(dict)
		qt3TxDVhSgR4WaK8kXz5LG = True
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: qt3TxDVhSgR4WaK8kXz5LG = False
			elif LRjqrQYBXFVPfu<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: qt3TxDVhSgR4WaK8kXz5LG = False
		if dict['type2']=='Video' and dict['init']!='0-0' and qt3TxDVhSgR4WaK8kXz5LG==True:
			sskqhHpgm5J1IvnwNRDYPrEi36Ft.append(dict['title'])
			tBFC7gj5V6KdXWoPrG1RvfO.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and qt3TxDVhSgR4WaK8kXz5LG==True:
			iW1xcE37SgjHtDXeAMP8aslUJLh9.append(dict['title'])
			n2ndtmeJwxGysTKiLkMgC73H1vYU.append(dict)
	for j5bNeID7dHvlX2Rm3PVuC in n2ndtmeJwxGysTKiLkMgC73H1vYU:
		FFkoPlC71X3OfzpaE60nd = j5bNeID7dHvlX2Rm3PVuC['bitrate']
		for GGpWUhefqHd86sLySmntTwgPC in tBFC7gj5V6KdXWoPrG1RvfO:
			TT0uzBoZYKO7A1Ismcv95HgLbN2S = GGpWUhefqHd86sLySmntTwgPC['bitrate']
			E03sXv1wm6 = TT0uzBoZYKO7A1Ismcv95HgLbN2S+FFkoPlC71X3OfzpaE60nd
			title = GGpWUhefqHd86sLySmntTwgPC['title'].replace('Video:  ','mpd  ')
			title = title.replace(GGpWUhefqHd86sLySmntTwgPC['filetype']+'  ','')
			title = title.replace(str((float(TT0uzBoZYKO7A1Ismcv95HgLbN2S*10)//1024/10))+'kbps',str((float(E03sXv1wm6*10)//1024/10))+'kbps')
			title = title+'('+j5bNeID7dHvlX2Rm3PVuC['title'].split('(',1)[1]
			t7tT9zyPWEJMxN.append([GGpWUhefqHd86sLySmntTwgPC,j5bNeID7dHvlX2Rm3PVuC,title,E03sXv1wm6])
	t7tT9zyPWEJMxN = sorted(t7tT9zyPWEJMxN, reverse=True, key=lambda key: float(key[3]))
	for GGpWUhefqHd86sLySmntTwgPC,j5bNeID7dHvlX2Rm3PVuC,title,E03sXv1wm6 in t7tT9zyPWEJMxN:
		CWf96dEokc3RJQNT = GGpWUhefqHd86sLySmntTwgPC['filetype']
		if 'filetype' in list(j5bNeID7dHvlX2Rm3PVuC.keys()):
			CWf96dEokc3RJQNT = 'mpd'
		if CWf96dEokc3RJQNT not in cM62KwiojhU0yHdq1QTmFLuaY3W:
			cM62KwiojhU0yHdq1QTmFLuaY3W.append(CWf96dEokc3RJQNT)
			ruMJlsf0LIDmjX2N1vcPiw8.append([GGpWUhefqHd86sLySmntTwgPC,j5bNeID7dHvlX2Rm3PVuC,title,E03sXv1wm6])
	pb7Mq8CFOBrP,XeuAMGWByCSwL,omcSni5PCOIezt = [],[],0
	uc3tIV2WBfPmnsS4wbFhG,xtfc1bWGJ5qo2jy = '',''
	try: uc3tIV2WBfPmnsS4wbFhG = VxK2NflE1Tu6iB5wUS07G8['videoDetails']['author']
	except: uc3tIV2WBfPmnsS4wbFhG = ''
	try: svIXeTVUqlG = VxK2NflE1Tu6iB5wUS07G8['videoDetails']['channelId']
	except: svIXeTVUqlG = ''
	if uc3tIV2WBfPmnsS4wbFhG and svIXeTVUqlG:
		omcSni5PCOIezt += 1
		title = '[COLOR FFC89008]OWNER:  '+uc3tIV2WBfPmnsS4wbFhG+'[/COLOR]'
		VV7yf2htDCBU6EeSX8TJQM = EGcFon0zR4mSL1['YOUTUBE'][0]+'/channel/'+svIXeTVUqlG
		pb7Mq8CFOBrP.append(title)
		XeuAMGWByCSwL.append(VV7yf2htDCBU6EeSX8TJQM)
		try: xtfc1bWGJ5qo2jy = VxK2NflE1Tu6iB5wUS07G8['videoDetails']['thumbnail']['thumbnails'][-1]['url']
		except: pass
	for GGpWUhefqHd86sLySmntTwgPC,j5bNeID7dHvlX2Rm3PVuC,title,E03sXv1wm6 in ruMJlsf0LIDmjX2N1vcPiw8:
		pb7Mq8CFOBrP.append(title) ; XeuAMGWByCSwL.append('highest')
	if lIpyCxfn3utAS: pb7Mq8CFOBrP.append('صورة وصوت محددة') ; XeuAMGWByCSwL.append('muxed')
	if t7tT9zyPWEJMxN: pb7Mq8CFOBrP.append('صورة وصوت المتوفر') ; XeuAMGWByCSwL.append('all')
	if sskqhHpgm5J1IvnwNRDYPrEi36Ft: pb7Mq8CFOBrP.append('mpd اختر الصورة والصوت') ; XeuAMGWByCSwL.append('mpd')
	if owaD504frQ7Y: pb7Mq8CFOBrP.append('صورة بدون صوت') ; XeuAMGWByCSwL.append('video')
	if ZoEcxTIrJzpWVCwnOm: pb7Mq8CFOBrP.append('صوت بدون صورة') ; XeuAMGWByCSwL.append('audio')
	RerLozb4W65ZuVP3haF1K = False
	while True:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB(zhJqHKfVeudEGNAwQxSa70, pb7Mq8CFOBrP)
		if ShT1xUHjlDotkRuPq7gv==-1: return 'EXIT_RESOLVER',[],[]
		elif ShT1xUHjlDotkRuPq7gv==0 and uc3tIV2WBfPmnsS4wbFhG:
			VV7yf2htDCBU6EeSX8TJQM = XeuAMGWByCSwL[ShT1xUHjlDotkRuPq7gv]
			PMHouEth10egUaq8niQ = GJtcqTv68ZQpwxYFiDg.argv[0]+'?type=folder&mode=141&name='+oF0Yr4V7Ic(uc3tIV2WBfPmnsS4wbFhG)+'&url='+VV7yf2htDCBU6EeSX8TJQM
			if xtfc1bWGJ5qo2jy: PMHouEth10egUaq8niQ = PMHouEth10egUaq8niQ+'&image='+oF0Yr4V7Ic(xtfc1bWGJ5qo2jy)
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin("Container.Update("+PMHouEth10egUaq8niQ+")")
			return 'EXIT_RESOLVER',[],[]
		Df3p8YoF4GVj1bShqTQk5z0Wn = XeuAMGWByCSwL[ShT1xUHjlDotkRuPq7gv]
		MIVWL9h6AZDY3myKopwXka8EtOPTN = pb7Mq8CFOBrP[ShT1xUHjlDotkRuPq7gv]
		if Df3p8YoF4GVj1bShqTQk5z0Wn=='dash':
			VMBkagInZrW0RN3XOyf = cOdf8WwNzTrSkl
			break
		elif Df3p8YoF4GVj1bShqTQk5z0Wn in ['audio','video','muxed']:
			if Df3p8YoF4GVj1bShqTQk5z0Wn=='muxed': xitERh4TD2jGJPq5Nuv39CAmg,gQrdmA9Nh1obFIKiL4uBMRvjc = lIpyCxfn3utAS,Ci9I7t5EQrk0HYJ
			elif Df3p8YoF4GVj1bShqTQk5z0Wn=='video': xitERh4TD2jGJPq5Nuv39CAmg,gQrdmA9Nh1obFIKiL4uBMRvjc = owaD504frQ7Y,VcusnrYUIK8GR1p0aCN3gxftF2bZ6
			elif Df3p8YoF4GVj1bShqTQk5z0Wn=='audio': xitERh4TD2jGJPq5Nuv39CAmg,gQrdmA9Nh1obFIKiL4uBMRvjc = ZoEcxTIrJzpWVCwnOm,XBoeCHdRjbMGUkKtpr
			ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الملف المناسب:', xitERh4TD2jGJPq5Nuv39CAmg)
			if ShT1xUHjlDotkRuPq7gv!=-1:
				VMBkagInZrW0RN3XOyf = gQrdmA9Nh1obFIKiL4uBMRvjc[ShT1xUHjlDotkRuPq7gv]['url']
				MIVWL9h6AZDY3myKopwXka8EtOPTN = xitERh4TD2jGJPq5Nuv39CAmg[ShT1xUHjlDotkRuPq7gv]
				break
		elif Df3p8YoF4GVj1bShqTQk5z0Wn=='mpd':
			ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر جودة الصورة:', sskqhHpgm5J1IvnwNRDYPrEi36Ft)
			if ShT1xUHjlDotkRuPq7gv!=-1:
				MIVWL9h6AZDY3myKopwXka8EtOPTN = sskqhHpgm5J1IvnwNRDYPrEi36Ft[ShT1xUHjlDotkRuPq7gv]
				IIPRBDtHwkYelA4236FKLiGuSWdn = tBFC7gj5V6KdXWoPrG1RvfO[ShT1xUHjlDotkRuPq7gv]
				ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر جودة الصوت:', iW1xcE37SgjHtDXeAMP8aslUJLh9)
				if ShT1xUHjlDotkRuPq7gv!=-1:
					MIVWL9h6AZDY3myKopwXka8EtOPTN += ' + '+iW1xcE37SgjHtDXeAMP8aslUJLh9[ShT1xUHjlDotkRuPq7gv]
					xhv6lqJY2iL5WAjZ17HeQ = n2ndtmeJwxGysTKiLkMgC73H1vYU[ShT1xUHjlDotkRuPq7gv]
					RerLozb4W65ZuVP3haF1K = True
					break
		elif Df3p8YoF4GVj1bShqTQk5z0Wn=='all':
			acoSymB12q,PPR9FLZztpChWUNIrmkny7go,wJaW5vE2y1Llj,PPnHqp37cSxhfXeV9Z0UgdL = list(zip(*t7tT9zyPWEJMxN))
			ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الملف المناسب:', wJaW5vE2y1Llj)
			if ShT1xUHjlDotkRuPq7gv!=-1:
				MIVWL9h6AZDY3myKopwXka8EtOPTN = wJaW5vE2y1Llj[ShT1xUHjlDotkRuPq7gv]
				IIPRBDtHwkYelA4236FKLiGuSWdn = acoSymB12q[ShT1xUHjlDotkRuPq7gv]
				if 'mpd' in wJaW5vE2y1Llj[ShT1xUHjlDotkRuPq7gv] and IIPRBDtHwkYelA4236FKLiGuSWdn['url']!=cOdf8WwNzTrSkl:
					xhv6lqJY2iL5WAjZ17HeQ = PPR9FLZztpChWUNIrmkny7go[ShT1xUHjlDotkRuPq7gv]
					RerLozb4W65ZuVP3haF1K = True
				else: VMBkagInZrW0RN3XOyf = IIPRBDtHwkYelA4236FKLiGuSWdn['url']
				break
		elif Df3p8YoF4GVj1bShqTQk5z0Wn=='highest':
			acoSymB12q,PPR9FLZztpChWUNIrmkny7go,wJaW5vE2y1Llj,PPnHqp37cSxhfXeV9Z0UgdL = list(zip(*ruMJlsf0LIDmjX2N1vcPiw8))
			IIPRBDtHwkYelA4236FKLiGuSWdn = acoSymB12q[ShT1xUHjlDotkRuPq7gv-omcSni5PCOIezt]
			if 'mpd' in wJaW5vE2y1Llj[ShT1xUHjlDotkRuPq7gv-omcSni5PCOIezt] and IIPRBDtHwkYelA4236FKLiGuSWdn['url']!=cOdf8WwNzTrSkl:
				xhv6lqJY2iL5WAjZ17HeQ = PPR9FLZztpChWUNIrmkny7go[ShT1xUHjlDotkRuPq7gv-omcSni5PCOIezt]
				RerLozb4W65ZuVP3haF1K = True
			else: VMBkagInZrW0RN3XOyf = IIPRBDtHwkYelA4236FKLiGuSWdn['url']
			MIVWL9h6AZDY3myKopwXka8EtOPTN = wJaW5vE2y1Llj[ShT1xUHjlDotkRuPq7gv-omcSni5PCOIezt]
			break
	if not RerLozb4W65ZuVP3haF1K: xj3NynO6iAEbCpLQ8tTYIh2J5Pcgum = VMBkagInZrW0RN3XOyf
	else: xj3NynO6iAEbCpLQ8tTYIh2J5Pcgum = 'Video: '+IIPRBDtHwkYelA4236FKLiGuSWdn['url']+' + Audio: '+xhv6lqJY2iL5WAjZ17HeQ['url']
	if RerLozb4W65ZuVP3haF1K:
		rH7podPLZevIW1Q = int(IIPRBDtHwkYelA4236FKLiGuSWdn['duration'])
		uNoZ2cEKWDRfhA8YBw = int(xhv6lqJY2iL5WAjZ17HeQ['duration'])
		VVaBpWQDAfx5dO4GSMmstz78eRFYw = str(max(rH7podPLZevIW1Q,uNoZ2cEKWDRfhA8YBw))
		ss7CkLXp8UIco9 = IIPRBDtHwkYelA4236FKLiGuSWdn['url'].replace('&','&amp;')
		rrIEte2mnPHYMo6OKyiSFdwzWu = xhv6lqJY2iL5WAjZ17HeQ['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+VVaBpWQDAfx5dO4GSMmstz78eRFYw+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+IIPRBDtHwkYelA4236FKLiGuSWdn['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+IIPRBDtHwkYelA4236FKLiGuSWdn['itag']+'" codecs="'+IIPRBDtHwkYelA4236FKLiGuSWdn['codecs']+'" startWithSAP="1" bandwidth="'+str(IIPRBDtHwkYelA4236FKLiGuSWdn['bitrate'])+'" width="'+str(IIPRBDtHwkYelA4236FKLiGuSWdn['width'])+'" height="'+str(IIPRBDtHwkYelA4236FKLiGuSWdn['height'])+'" frameRate="'+IIPRBDtHwkYelA4236FKLiGuSWdn['fps']+'">\n'
		mpd += '<BaseURL>'+ss7CkLXp8UIco9+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+IIPRBDtHwkYelA4236FKLiGuSWdn['index']+'">\n'
		mpd += '<Initialization range="'+IIPRBDtHwkYelA4236FKLiGuSWdn['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+xhv6lqJY2iL5WAjZ17HeQ['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+xhv6lqJY2iL5WAjZ17HeQ['itag']+'" codecs="'+xhv6lqJY2iL5WAjZ17HeQ['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+xhv6lqJY2iL5WAjZ17HeQ['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+rrIEte2mnPHYMo6OKyiSFdwzWu+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+xhv6lqJY2iL5WAjZ17HeQ['index']+'">\n'
		mpd += '<Initialization range="'+xhv6lqJY2iL5WAjZ17HeQ['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if Nnxm30dfoBWRYpIC7KsQGl:
			import http.server as zFgHmhBJaxOZC0LAnV1Y9qiywGE6vd
			import http.client as Om51s2ouUREie6cgA
		else:
			import BaseHTTPServer as zFgHmhBJaxOZC0LAnV1Y9qiywGE6vd
			import httplib as Om51s2ouUREie6cgA
		class bdRvKU4o1BxiFatLkMm7l6jDO(zFgHmhBJaxOZC0LAnV1Y9qiywGE6vd.HTTPServer):
			def __init__(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8,ip='localhost',port=55055,mpd='<>'):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.ip = ip
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.port = port
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.mpd = mpd
				zFgHmhBJaxOZC0LAnV1Y9qiywGE6vd.HTTPServer.__init__(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8,(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.ip,ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.port),Q3NTPiaEUnKfYzcbSO9y5Z)
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.threads = kZ05eRcAtxbP1ID(False)
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.threads.yP9H5KOS6TYglVdxurU(1,ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.qgvCd7RjfwW)
			def qgvCd7RjfwW(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.keeprunning = True
				while ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.keeprunning:
					ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.handle_request()
			def stop(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.keeprunning = False
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.N2PolKCmZqu()
			def pHO5PIY7BRMx4gqtFzCbrvJ8h(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.stop()
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.HKIPWB4JXYaEu6.close()
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.server_close()
			def HHoYtEqy8jnzw4LSv6mAX(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8,mpd):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.mpd = mpd
			def N2PolKCmZqu(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				qcOU43biDkaPQlZMB1wHEj = Om51s2ouUREie6cgA.HTTPConnection(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.ip+':'+str(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.port))
				qcOU43biDkaPQlZMB1wHEj.request("HEAD", "/")
		class Q3NTPiaEUnKfYzcbSO9y5Z(zFgHmhBJaxOZC0LAnV1Y9qiywGE6vd.BaseHTTPRequestHandler):
			def qL45Zarc2hEQp(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.send_response(200)
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.send_header('Content-type','textt/plain')
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.end_headers()
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.wfile.write(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.BHgLX9GZTb2jJrWiNKE.mpd.encode('utf8'))
				vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(1)
				if ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.path=='/youtube.mpd': ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.BHgLX9GZTb2jJrWiNKE.pHO5PIY7BRMx4gqtFzCbrvJ8h()
				if ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.path=='/shutdown': ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.BHgLX9GZTb2jJrWiNKE.pHO5PIY7BRMx4gqtFzCbrvJ8h()
			def itwaHcyjqIK(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.send_response(200)
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.end_headers()
		iVlO42GI8H0AJNaUcsjSZ9qDz = bdRvKU4o1BxiFatLkMm7l6jDO('127.0.0.1',55055,mpd)
		VMBkagInZrW0RN3XOyf = iVlO42GI8H0AJNaUcsjSZ9qDz.mpdurl
		iVlO42GI8H0AJNaUcsjSZ9qDz.start()
	else: iVlO42GI8H0AJNaUcsjSZ9qDz = ''
	if not VMBkagInZrW0RN3XOyf: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return '',[''],[[VMBkagInZrW0RN3XOyf,F4FZOUThWuv,iVlO42GI8H0AJNaUcsjSZ9qDz]]
def SfjtKlb26xOIVR8p(url):
	headers = { 'User-Agent' : '' }
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'',headers,'','RESOLVERS-VIDBOB-1st')
	items = QPuHKNAT4jmCRg.findall('file:"(.*?)"(,label:"(.*?)"|)\}',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	viJ8DjTKIVc3l1dernfBWmwY6yLs,xitERh4TD2jGJPq5Nuv39CAmg,H9Jxugok0p1bSMlzrs,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for VV7yf2htDCBU6EeSX8TJQM,aaxAKWtMwfPRE4zbqSQCOrBms0,G7XkvOrob5CBiAMFcVemDz4EZ1atxg in items:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('https:','http:')
		if '.m3u8' in VV7yf2htDCBU6EeSX8TJQM:
			viJ8DjTKIVc3l1dernfBWmwY6yLs,H9Jxugok0p1bSMlzrs = RjzVfbE0ILcNXFQJniSMBOskK13ox(VV7yf2htDCBU6EeSX8TJQM)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA = LL8heV7kxYI5bOjEZ6XaUQWwfPA + H9Jxugok0p1bSMlzrs
			if viJ8DjTKIVc3l1dernfBWmwY6yLs[0]=='-1': xitERh4TD2jGJPq5Nuv39CAmg.append('سيرفر خاص'+'   m3u8')
			else:
				for title in viJ8DjTKIVc3l1dernfBWmwY6yLs:
					xitERh4TD2jGJPq5Nuv39CAmg.append('سيرفر خاص'+'   '+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+G7XkvOrob5CBiAMFcVemDz4EZ1atxg
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
			xitERh4TD2jGJPq5Nuv39CAmg.append(title)
	return '',xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
def e5eQa1gmAYCuwkU3BKMOziZ(url,Ht6Gg8lbciAd9FaUQVs):
	arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO,mPqaRCgs8KuM0xfop,G3EtpuZ7ivHB9TxCYalcwDzSeoLM,Y4xiULzGTKjb8mulO = [],[],[],[],[]
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<video preload.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('direct_link.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		title = VV7yf2htDCBU6EeSX8TJQM.rsplit('.',1)[1]
		arZijTmC4eXBKvgEAHxPD7JtwOh.append(title)
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	else:
		N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('sources: *(\[.*?\])',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd: N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('var sources = (\{.*?\})',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd: N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('var jw = (\{.*?\})',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd: N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('var player = .*?\((\{.*?\})\)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
			N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd[0]
			tmh9HG4DfdykgZxREbP87QAo1rj = QPuHKNAT4jmCRg.findall('[,\{] *(\w+):',N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd,QPuHKNAT4jmCRg.DOTALL)
			for key in list(set(tmh9HG4DfdykgZxREbP87QAo1rj)): N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd.replace(key+':','"'+key+'":')
			N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = eval(N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd)
			if isinstance(N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd,dict): N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = [N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd]
			for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
				if isinstance(wltPGJcYo12Ed,dict):
					keys = list(wltPGJcYo12Ed.keys())
					if 'file' in keys: VV7yf2htDCBU6EeSX8TJQM = wltPGJcYo12Ed['file']
					elif 'hls' in keys: VV7yf2htDCBU6EeSX8TJQM = wltPGJcYo12Ed['hls']
					if 'label' in keys: title = str(wltPGJcYo12Ed['label'])
					elif 'video_height' in keys: title = str(wltPGJcYo12Ed['video_height'])
					else: title = VV7yf2htDCBU6EeSX8TJQM.rsplit('.',1)[1]
				elif isinstance(wltPGJcYo12Ed,str):
					VV7yf2htDCBU6EeSX8TJQM = wltPGJcYo12Ed
					title = VV7yf2htDCBU6EeSX8TJQM.rsplit('.',1)[1]
				arZijTmC4eXBKvgEAHxPD7JtwOh.append(title)
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	for VV7yf2htDCBU6EeSX8TJQM,title in zip(YsDryBSXquzdEUta8kxjfO,arZijTmC4eXBKvgEAHxPD7JtwOh):
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\\/','/')
		PYWfQI0KxebFTymtXdwBalCG58qg3L = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
		oOM6fji0UV3Yn2 = yWgZFzdaNR5iw6m8Q9G7CL()
		if '.m3u8' in VV7yf2htDCBU6EeSX8TJQM:
			headers = {'User-Agent':oOM6fji0UV3Yn2,'Referer':PYWfQI0KxebFTymtXdwBalCG58qg3L}
			OkLSzJKbCiIc6uw,ClHewYXSc7NUT8 = RjzVfbE0ILcNXFQJniSMBOskK13ox(VV7yf2htDCBU6EeSX8TJQM,headers)
			G3EtpuZ7ivHB9TxCYalcwDzSeoLM += ClHewYXSc7NUT8
			mPqaRCgs8KuM0xfop += OkLSzJKbCiIc6uw
		else:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'|User-Agent='+oOM6fji0UV3Yn2+'&Referer='+PYWfQI0KxebFTymtXdwBalCG58qg3L
			G3EtpuZ7ivHB9TxCYalcwDzSeoLM.append(VV7yf2htDCBU6EeSX8TJQM)
			mPqaRCgs8KuM0xfop.append(title)
	aCEzNgy0L4kujFlUToeIitBvX759,arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO = '',[],[]
	if G3EtpuZ7ivHB9TxCYalcwDzSeoLM: aCEzNgy0L4kujFlUToeIitBvX759,arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO = '',mPqaRCgs8KuM0xfop,G3EtpuZ7ivHB9TxCYalcwDzSeoLM
	else:
		if '<' not in Ht6Gg8lbciAd9FaUQVs and len(Ht6Gg8lbciAd9FaUQVs)<100 and Ht6Gg8lbciAd9FaUQVs: aCEzNgy0L4kujFlUToeIitBvX759 = Ht6Gg8lbciAd9FaUQVs
		else:
			msg = QPuHKNAT4jmCRg.findall('<div style=".*?">(File.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if not msg: msg = QPuHKNAT4jmCRg.findall('<div class="vp_video_stub_txt">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if not msg: msg = QPuHKNAT4jmCRg.findall('<h2>(Sorry.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if msg: aCEzNgy0L4kujFlUToeIitBvX759 = msg[0]
	return aCEzNgy0L4kujFlUToeIitBvX759,arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO
def QLfztq4oBkch3(vLOZMV7flJmion2dtCDSYby,url):
	global wrkpzsm2WKGZt5qPOCQdXVDMi0
	url = url.strip('/')
	cc1nabWT9B0zpYNQumyAkq,E9ODYnfpm54GJTd2xRrV = '',{}
	headers = {'User-Agent':yWgZFzdaNR5iw6m8Q9G7CL(),'Accept-Language':'en-US,en;q=0.9','Sec-Fetch-Dest':'iframe'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'',headers,'',False,'RESOLVERS-XSHARING-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	PvSI6sYn4KAu = nbdMp8UuhzP3oq4cDWj6eyZVt.code
	if not isinstance(Ht6Gg8lbciAd9FaUQVs,str): Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.decode('utf8','ignore')
	if 'function(p,a,c,k,e,' in Ht6Gg8lbciAd9FaUQVs:
		bbszZDlChGAiI8eV3r6Yk = QPuHKNAT4jmCRg.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if bbszZDlChGAiI8eV3r6Yk:
			try: cc1nabWT9B0zpYNQumyAkq = V7nq6gTU2NIe0OCtZMpKB(bbszZDlChGAiI8eV3r6Yk[0])
			except: cc1nabWT9B0zpYNQumyAkq = ''
	iRSILm7Nv6DZAaztp = Ht6Gg8lbciAd9FaUQVs+cc1nabWT9B0zpYNQumyAkq
	if '"id2"' in iRSILm7Nv6DZAaztp or '"id"' in iRSILm7Nv6DZAaztp:
		e9t76WDTUnVo = url.split('/')[3].replace('embed-','').replace('.html','')
		if '"id2"' in iRSILm7Nv6DZAaztp: E9ODYnfpm54GJTd2xRrV = {'id2':e9t76WDTUnVo,'op':'download2'}
		elif '"id"' in iRSILm7Nv6DZAaztp: E9ODYnfpm54GJTd2xRrV = {'id':e9t76WDTUnVo,'op':'download2'}
		Eudgv5cTUHF2AzKpkx = headers.copy()
		Eudgv5cTUHF2AzKpkx['Content-Type'] = 'application/x-www-form-urlencoded'
		ykIAHx9E1umUdZqjSiBw6Kbar = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',url,E9ODYnfpm54GJTd2xRrV,Eudgv5cTUHF2AzKpkx,'',False,'RESOLVERS-XSHARING-2nd')
		iRSILm7Nv6DZAaztp = ykIAHx9E1umUdZqjSiBw6Kbar.content
	ZwBOQCbDSMYhFkPzmNxa4LWI,cmu4SrG2FAOaLWPv7Zhjoxw9,AmPwesbYJNaUjBqpfr0 = e5eQa1gmAYCuwkU3BKMOziZ(url,iRSILm7Nv6DZAaztp)
	wrkpzsm2WKGZt5qPOCQdXVDMi0[vLOZMV7flJmion2dtCDSYby] = ZwBOQCbDSMYhFkPzmNxa4LWI,cmu4SrG2FAOaLWPv7Zhjoxw9,AmPwesbYJNaUjBqpfr0,PvSI6sYn4KAu
	return
wrkpzsm2WKGZt5qPOCQdXVDMi0,bYQ9ZFNTR3rHUz5 = {},0
def vJKC28bG6jrBe(url):
	global wrkpzsm2WKGZt5qPOCQdXVDMi0,bYQ9ZFNTR3rHUz5
	Y4xiULzGTKjb8mulO,threads = [],[]
	bYQ9ZFNTR3rHUz5 += 100
	v41jGehXFu8fMbCrskoS = bYQ9ZFNTR3rHUz5
	Y4xiULzGTKjb8mulO.append([1,url])
	wrkpzsm2WKGZt5qPOCQdXVDMi0[v41jGehXFu8fMbCrskoS+1] = [None,None,None,None]
	cdFHRazDU8is3rxBSX4Tv = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=QLfztq4oBkch3,args=(v41jGehXFu8fMbCrskoS+1,url))
	cdFHRazDU8is3rxBSX4Tv.start()
	cdFHRazDU8is3rxBSX4Tv.join(10)
	if not wrkpzsm2WKGZt5qPOCQdXVDMi0[v41jGehXFu8fMbCrskoS+1][2]:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace('/embed-','/')
		FtKo2AMUynNdTaYCljkxOe = QPuHKNAT4jmCRg.findall('^(.*?://.*?)/(.*?)/(.*?)$',lZqkuhgaBHSVX8NItKG05cdLJe7Ao+'/',QPuHKNAT4jmCRg.DOTALL)
		start,lbhQLSDVvi0PGf7gx,end = FtKo2AMUynNdTaYCljkxOe[0]
		end = end.strip('/')
		o9Oy4sqPVlDuje15LEWTwCH = len(lbhQLSDVvi0PGf7gx)<4 or lbhQLSDVvi0PGf7gx in ['file','video','videoembed']
		if not o9Oy4sqPVlDuje15LEWTwCH: Y4xiULzGTKjb8mulO.append([2,start+'/embed-'+lbhQLSDVvi0PGf7gx+'/'+end])
		if end: Y4xiULzGTKjb8mulO.append([3,start+'/'+lbhQLSDVvi0PGf7gx+'/embed-'+end])
		if '.html' in lbhQLSDVvi0PGf7gx:
			Ub3EBH5AeGo9mf = lbhQLSDVvi0PGf7gx.replace('.html','')
			Y4xiULzGTKjb8mulO.append([4,start+'/'+Ub3EBH5AeGo9mf+'/'+end])
			Y4xiULzGTKjb8mulO.append([5,start+'/embed-'+Ub3EBH5AeGo9mf+'/'+end])
			if end: Y4xiULzGTKjb8mulO.append([6,start+'/'+Ub3EBH5AeGo9mf+'/embed-'+end])
		elif '.html' in end:
			llWp2gSaAeNI = end.replace('.html','')
			Y4xiULzGTKjb8mulO.append([7,start+'/'+lbhQLSDVvi0PGf7gx+'/'+llWp2gSaAeNI])
			if not o9Oy4sqPVlDuje15LEWTwCH: Y4xiULzGTKjb8mulO.append([8,start+'/embed-'+lbhQLSDVvi0PGf7gx+'/'+llWp2gSaAeNI])
			Y4xiULzGTKjb8mulO.append([9,start+'/'+lbhQLSDVvi0PGf7gx+'/embed-'+llWp2gSaAeNI])
		else:
			if not o9Oy4sqPVlDuje15LEWTwCH: Y4xiULzGTKjb8mulO.append([10,start+'/'+lbhQLSDVvi0PGf7gx+'.html'])
			if not o9Oy4sqPVlDuje15LEWTwCH: Y4xiULzGTKjb8mulO.append([11,start+'/embed-'+lbhQLSDVvi0PGf7gx+'.html'])
			if end: Y4xiULzGTKjb8mulO.append([12,start+'/'+lbhQLSDVvi0PGf7gx+'/'+end+'.html'])
			if end: Y4xiULzGTKjb8mulO.append([13,start+'/'+lbhQLSDVvi0PGf7gx+'/embed-'+end+'.html'])
		if o9Oy4sqPVlDuje15LEWTwCH and end:
			end = end.replace('/embed-','/')
			Y4xiULzGTKjb8mulO.append([14,start+'/'+end])
			Y4xiULzGTKjb8mulO.append([15,start+'/embed-'+end])
			if '.html' in end:
				llWp2gSaAeNI = end.replace('.html','')
				Y4xiULzGTKjb8mulO.append([16,start+'/'+llWp2gSaAeNI])
				Y4xiULzGTKjb8mulO.append([17,start+'/embed-'+llWp2gSaAeNI])
			else:
				Y4xiULzGTKjb8mulO.append([18,start+'/'+end+'.html'])
				Y4xiULzGTKjb8mulO.append([19,start+'/embed-'+end+'.html'])
		for p2pr9R1hOVsHIlJnFB6PDKMx,VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO[1:]:
			wrkpzsm2WKGZt5qPOCQdXVDMi0[v41jGehXFu8fMbCrskoS+p2pr9R1hOVsHIlJnFB6PDKMx] = [None,None,None,None]
			cdFHRazDU8is3rxBSX4Tv = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=QLfztq4oBkch3,args=(v41jGehXFu8fMbCrskoS+p2pr9R1hOVsHIlJnFB6PDKMx,VV7yf2htDCBU6EeSX8TJQM))
			cdFHRazDU8is3rxBSX4Tv.start()
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(0.5)
			threads.append(cdFHRazDU8is3rxBSX4Tv)
		for cdFHRazDU8is3rxBSX4Tv in threads: cdFHRazDU8is3rxBSX4Tv.join(10)
	aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '',[],[]
	RRUjfvlE5GzNToxgcX7SpBCyDYq2 = []
	for p2pr9R1hOVsHIlJnFB6PDKMx,VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO:
		fxWP2HUVRhjaT8tY0LuwBr,xclA6j4XpuTYGntP8FiwSW70v2f9,viupJ25sKxF6,WqUws7uARxM8c2yoj = wrkpzsm2WKGZt5qPOCQdXVDMi0[v41jGehXFu8fMbCrskoS+p2pr9R1hOVsHIlJnFB6PDKMx]
		if not LL8heV7kxYI5bOjEZ6XaUQWwfPA and viupJ25sKxF6: xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = xclA6j4XpuTYGntP8FiwSW70v2f9,viupJ25sKxF6
		if not aCEzNgy0L4kujFlUToeIitBvX759 and fxWP2HUVRhjaT8tY0LuwBr: aCEzNgy0L4kujFlUToeIitBvX759 = fxWP2HUVRhjaT8tY0LuwBr
		if WqUws7uARxM8c2yoj: RRUjfvlE5GzNToxgcX7SpBCyDYq2.append(WqUws7uARxM8c2yoj)
	RRUjfvlE5GzNToxgcX7SpBCyDYq2 = list(set(RRUjfvlE5GzNToxgcX7SpBCyDYq2))
	if not aCEzNgy0L4kujFlUToeIitBvX759 and len(RRUjfvlE5GzNToxgcX7SpBCyDYq2)==1:
		PvSI6sYn4KAu = RRUjfvlE5GzNToxgcX7SpBCyDYq2[0]
		if PvSI6sYn4KAu!=200:
			if PvSI6sYn4KAu<0: aCEzNgy0L4kujFlUToeIitBvX759 = 'Video page/server is not accessible'
			else:
				aCEzNgy0L4kujFlUToeIitBvX759 = 'HTTP Error: '+str(PvSI6sYn4KAu)
				if Nnxm30dfoBWRYpIC7KsQGl: import http.client as Om51s2ouUREie6cgA
				else: import httplib as Om51s2ouUREie6cgA
				aCEzNgy0L4kujFlUToeIitBvX759 += ' ( '+Om51s2ouUREie6cgA.responses[PvSI6sYn4KAu]+' )'
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(1)
	return aCEzNgy0L4kujFlUToeIitBvX759,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA
class IQvYGbHir2cnjUVtPd(yOuHBDmPps3vd24cnLagiK0.WindowDialog):
	def __init__(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8, *args, **Nh9k7aMZdApYKDVx2i1):
		aNw07eptjJLqTldfhvOoWiCQ = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX, 'resources', 'recaptcha', 'background.png')
		tUkQfPyseIH = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX, 'resources', 'recaptcha', 'checked.png')
		RRkQtZHbxuUWm7wfD = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX, 'resources', 'recaptcha', 'button-fo.png')
		KonWSgseNph = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX, 'resources', 'recaptcha', 'button-nofo.png')
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelled = False
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chk = [0] * 9
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton = [0] * 9
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkstate = [False] * 9
		ff87gWEoBjeH3a9OPhnGt, fznMu9ETBxdqP6oD2WLZYI5tSvAg, K1uqMlyWkrz9gTGFvOQeE6x, ymVMlOipoIfEHKvbgCd9Nrtj = 436, 210, 408, 300
		S6mBDtOcpTZR3JHro7uvXeVIdElhiW, FRJp6OHzG1l3V9j2DNga8L = ymVMlOipoIfEHKvbgCd9Nrtj // 3, K1uqMlyWkrz9gTGFvOQeE6x // 3
		Pkar7UvqxC9NKgDRcE5SjAGz6 = 70
		wwzRNBfYxuHcFLPt4Es3pi = 70
		bVe6qpuNBA2v4ETaQjIwrKCYfJy = 40
		Y5pvbHD79Ea2S1J8oLzx = 40
		PEyVFCLs04xwj7akXHeD = fznMu9ETBxdqP6oD2WLZYI5tSvAg + ymVMlOipoIfEHKvbgCd9Nrtj + bVe6qpuNBA2v4ETaQjIwrKCYfJy
		lbhQLSDVvi0PGf7gx = ff87gWEoBjeH3a9OPhnGt + (K1uqMlyWkrz9gTGFvOQeE6x // 2)
		YCEF0n2SW751pamKcfZoVe = ff87gWEoBjeH3a9OPhnGt - Pkar7UvqxC9NKgDRcE5SjAGz6
		V9PO40dhGbMWv6lrpo3FQxBySft = fznMu9ETBxdqP6oD2WLZYI5tSvAg - wwzRNBfYxuHcFLPt4Es3pi
		a0aPYDWdBiuITnJ68j4EAcK1 = ymVMlOipoIfEHKvbgCd9Nrtj + 2 * wwzRNBfYxuHcFLPt4Es3pi + Y5pvbHD79Ea2S1J8oLzx + bVe6qpuNBA2v4ETaQjIwrKCYfJy
		fSgc5jKvM34Jm07LqG1FQ = K1uqMlyWkrz9gTGFvOQeE6x + 2 * Pkar7UvqxC9NKgDRcE5SjAGz6
		p0WzvPZ38Qt7aYOA4no69GNIF = yOuHBDmPps3vd24cnLagiK0.ControlImage(YCEF0n2SW751pamKcfZoVe, V9PO40dhGbMWv6lrpo3FQxBySft, fSgc5jKvM34Jm07LqG1FQ, a0aPYDWdBiuITnJ68j4EAcK1, aNw07eptjJLqTldfhvOoWiCQ)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(p0WzvPZ38Qt7aYOA4no69GNIF)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.msg = '[COLOR FFFFFF00]'+Nh9k7aMZdApYKDVx2i1.get('msg')+'[/COLOR]'
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.strActionInfo = yOuHBDmPps3vd24cnLagiK0.ControlLabel(ff87gWEoBjeH3a9OPhnGt - 20 , fznMu9ETBxdqP6oD2WLZYI5tSvAg - 40, K1uqMlyWkrz9gTGFvOQeE6x + 40 , 20, ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.msg, 'font13')
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.strActionInfo)
		G2WR0Oacvdq8ZQTjKboDU = yOuHBDmPps3vd24cnLagiK0.ControlImage(ff87gWEoBjeH3a9OPhnGt, fznMu9ETBxdqP6oD2WLZYI5tSvAg, K1uqMlyWkrz9gTGFvOQeE6x, ymVMlOipoIfEHKvbgCd9Nrtj, Nh9k7aMZdApYKDVx2i1.get('captcha'))
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(G2WR0Oacvdq8ZQTjKboDU)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.iteration = Nh9k7aMZdApYKDVx2i1.get('iteration')
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.strActionInfo = yOuHBDmPps3vd24cnLagiK0.ControlLabel(ff87gWEoBjeH3a9OPhnGt, fznMu9ETBxdqP6oD2WLZYI5tSvAg + ymVMlOipoIfEHKvbgCd9Nrtj, K1uqMlyWkrz9gTGFvOQeE6x, 20, 'المحاولة رقم: '+str(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.iteration), 'font40')
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.strActionInfo)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton = yOuHBDmPps3vd24cnLagiK0.ControlButton(lbhQLSDVvi0PGf7gx - 110, PEyVFCLs04xwj7akXHeD, 100, Y5pvbHD79Ea2S1J8oLzx, 'خروج', focusTexture=RRkQtZHbxuUWm7wfD, noFocusTexture=KonWSgseNph, alignment=2)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton = yOuHBDmPps3vd24cnLagiK0.ControlButton(lbhQLSDVvi0PGf7gx + 10, PEyVFCLs04xwj7akXHeD, 100, Y5pvbHD79Ea2S1J8oLzx, 'استمرار', focusTexture=RRkQtZHbxuUWm7wfD, noFocusTexture=KonWSgseNph, alignment=2)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton)
		for PXBFxvuUlLDHGpm58 in range(9):
			P6TFtUK5GVO8EkRNHaweQsYfCrI = PXBFxvuUlLDHGpm58 // 3
			gEW7ib4vJx = PXBFxvuUlLDHGpm58 % 3
			xRk0gOr7vnuC = ff87gWEoBjeH3a9OPhnGt + (FRJp6OHzG1l3V9j2DNga8L * gEW7ib4vJx)
			DcOEKTvYHaGC7 = fznMu9ETBxdqP6oD2WLZYI5tSvAg + (S6mBDtOcpTZR3JHro7uvXeVIdElhiW * P6TFtUK5GVO8EkRNHaweQsYfCrI)
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chk[PXBFxvuUlLDHGpm58] = yOuHBDmPps3vd24cnLagiK0.ControlImage(xRk0gOr7vnuC-10, DcOEKTvYHaGC7-15, FRJp6OHzG1l3V9j2DNga8L+20, S6mBDtOcpTZR3JHro7uvXeVIdElhiW+30, tUkQfPyseIH)
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chk[PXBFxvuUlLDHGpm58])
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chk[PXBFxvuUlLDHGpm58].setVisible(False)
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58] = yOuHBDmPps3vd24cnLagiK0.ControlButton(xRk0gOr7vnuC-10, DcOEKTvYHaGC7-15, FRJp6OHzG1l3V9j2DNga8L+20, S6mBDtOcpTZR3JHro7uvXeVIdElhiW+30, str(PXBFxvuUlLDHGpm58 + 1), font='font1', focusTexture=RRkQtZHbxuUWm7wfD, noFocusTexture=KonWSgseNph)
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.addControl(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58])
		for PXBFxvuUlLDHGpm58 in range(9):
			VbBZNidRHcxhG9gwQu58Y30TopMOj = (PXBFxvuUlLDHGpm58 // 3) * 3
			x5k1Pd3jGDZSnwmWTlO29uK = VbBZNidRHcxhG9gwQu58Y30TopMOj + (PXBFxvuUlLDHGpm58 + 1) % 3
			wLZaQO6PjNut = VbBZNidRHcxhG9gwQu58Y30TopMOj + (PXBFxvuUlLDHGpm58 - 1) % 3
			za172suYiVO5yImHRCMTJoktXWxf8 = (PXBFxvuUlLDHGpm58 - 3) % 9
			BBVRbyHFk6DYApUzESQ9IPJ12rKW = (PXBFxvuUlLDHGpm58 + 3) % 9
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58].controlRight(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[x5k1Pd3jGDZSnwmWTlO29uK])
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58].controlLeft(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[wLZaQO6PjNut])
			if PXBFxvuUlLDHGpm58 <= 2:
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58].controlUp(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton)
			else:
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58].controlUp(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[za172suYiVO5yImHRCMTJoktXWxf8])
			if PXBFxvuUlLDHGpm58 >= 6:
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58].controlDown(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton)
			else:
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[PXBFxvuUlLDHGpm58].controlDown(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[BBVRbyHFk6DYApUzESQ9IPJ12rKW])
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton.controlLeft(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton.controlRight(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton.controlLeft(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton.controlRight(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton)
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton.controlDown(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[2])
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton.controlUp(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[8])
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton.controlDown(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[0])
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton.controlUp(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkbutton[6])
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.setFocus(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton)
	def get(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8):
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.doModal()
		ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.close()
		if not ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelled:
			return [PXBFxvuUlLDHGpm58 for PXBFxvuUlLDHGpm58 in range(9) if ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkstate[PXBFxvuUlLDHGpm58]]
	def x4rOyjaVgfqI5(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8, rcNSCODa9gKteJEBzkvl):
		if rcNSCODa9gKteJEBzkvl.getId() == ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.okbutton.getId() and any(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkstate):
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.close()
		elif rcNSCODa9gKteJEBzkvl.getId() == ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelbutton.getId():
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelled = True
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.close()
		else:
			G7XkvOrob5CBiAMFcVemDz4EZ1atxg = rcNSCODa9gKteJEBzkvl.getLabel()
			if G7XkvOrob5CBiAMFcVemDz4EZ1atxg.isnumeric():
				index = int(G7XkvOrob5CBiAMFcVemDz4EZ1atxg) - 1
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkstate[index] = not ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkstate[index]
				ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chk[index].setVisible(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.chkstate[index])
	def biAYO8vLhkwe(ukcj4t1E2NRsZJKPvI5TGBAdfDQb8, VZBARNS6YiUwjQvKOLpnHql):
		if VZBARNS6YiUwjQvKOLpnHql == 10:
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.cancelled = True
			ukcj4t1E2NRsZJKPvI5TGBAdfDQb8.close()
def Bn9REoKDptlGYk80AJPsQj(key,ooR6tf4gCTFXP7,url):
	headers = {'Referer':url,'Accept-Language':ooR6tf4gCTFXP7}
	FVeXIPHLDlikNWJR4820w = 'http://www.google.com/recaptcha/api/fallback?k='+key
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',FVeXIPHLDlikNWJR4820w,'',headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	uWCKp2UeRYGXINl,iteration = '',0
	while True:
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		E9ODYnfpm54GJTd2xRrV = QPuHKNAT4jmCRg.findall('"(/recaptcha/api2/payload[^"]+)', Ht6Gg8lbciAd9FaUQVs)
		iteration += 1
		message = QPuHKNAT4jmCRg.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', Ht6Gg8lbciAd9FaUQVs)
		if not message: message = QPuHKNAT4jmCRg.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', Ht6Gg8lbciAd9FaUQVs)
		if not message:
			uWCKp2UeRYGXINl = QPuHKNAT4jmCRg.findall('readonly>(.*?)<', Ht6Gg8lbciAd9FaUQVs)[0]
			break
		else:
			message = message[0]
			E9ODYnfpm54GJTd2xRrV = E9ODYnfpm54GJTd2xRrV[0]
		fAoFem19ZvHOKlPEaXrs027DxQNV = QPuHKNAT4jmCRg.findall(r'name="c"\s+value="([^"]+)', Ht6Gg8lbciAd9FaUQVs)[0]
		ppDfNxeQFS0o = 'https://www.google.com%s' % (E9ODYnfpm54GJTd2xRrV.replace('&amp;', '&'))
		message = QPuHKNAT4jmCRg.sub('</?(div|strong)[^>]*>', '', message)
		kxrS5JKguUqQ4 = IQvYGbHir2cnjUVtPd(captcha=ppDfNxeQFS0o, msg=message, iteration=iteration)
		Mcz8ldZLIp = kxrS5JKguUqQ4.get()
		if not Mcz8ldZLIp: break
		data = {'c': fAoFem19ZvHOKlPEaXrs027DxQNV, 'response': Mcz8ldZLIp}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'POST',FVeXIPHLDlikNWJR4820w,data,headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return uWCKp2UeRYGXINl
def fHEoUIkPrBQ1xZW6KLVOJea5A8v(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-ARABLOADS-1st')
	items = QPuHKNAT4jmCRg.findall('color="red">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def FF6raiNu2ECRhwcx3LW5(url):
	return '',[''],[ url ]
def PoOHN7MRXuYfaIjCrLwh1Wm(url):
	BHgLX9GZTb2jJrWiNKE = url.split('/')
	aWYSmfEi4whvxKd1oZ7O0ltr8NM = '/'.join(BHgLX9GZTb2jJrWiNKE[0:3])
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-ZIPPYSHARE-1st')
	items = QPuHKNAT4jmCRg.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw,n0n5PiuAxCtspZvJqk6XU,HKSYMgOFjs4pil18efrVzn,u3HcBnw72FTmAg9z,D6BbJ3sgYv4uGzSfCVXt = items[0]
		AyM2r7eGEp69ul3vH4i0VN = int(atuT76Ci5bsopI1fWnxKS2EhcXRvQw) % int(n0n5PiuAxCtspZvJqk6XU) + int(HKSYMgOFjs4pil18efrVzn) % int(u3HcBnw72FTmAg9z)
		url = aWYSmfEi4whvxKd1oZ7O0ltr8NM + z8ty6aqx2wKOIsul + str(AyM2r7eGEp69ul3vH4i0VN) + D6BbJ3sgYv4uGzSfCVXt
		return '',[''],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def JqbwAjBkmO(url):
	id = url.split('/')[-1]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	E9ODYnfpm54GJTd2xRrV = { "id":id , "op":"download2" }
	lp3eGht9uF4mMCR6YIWz = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST', url, E9ODYnfpm54GJTd2xRrV, headers, '','','RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(lp3eGht9uF4mMCR6YIWz.headers.keys()): VV7yf2htDCBU6EeSX8TJQM = lp3eGht9uF4mMCR6YIWz.headers['Location']
	else: VV7yf2htDCBU6EeSX8TJQM = url
	if VV7yf2htDCBU6EeSX8TJQM: return '',[''],[VV7yf2htDCBU6EeSX8TJQM]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def L7zJXo4HYmQ1(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-WINTVLIVE-1st')
	items = QPuHKNAT4jmCRg.findall('mp4: \[\'(.*?)\'',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def T6vDoUCWyLx3FdmzqefwiG5un8(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-ARCHIVE-1st')
	items = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[0]
		return '',[''],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def GGoQRxNr9KUZ0ni8zlXvBasE3WPLOu(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,'','','','RESOLVERS-ESTREAM-1st')
	items = QPuHKNAT4jmCRg.findall('video preload.*?src=.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'YOUTUBE'
JE7QrkmhletLwA0OZXu = '_YUT_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
def hLD0mk9HIuPOz7pw(mode,url,text,type,YSTbrKgPf7NyhIDizB):
	if	 mode==140: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==143: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url,type)
	elif mode==144: RRMWBwU6pG = F42EXtwuzB7Hl(url,text,YSTbrKgPf7NyhIDizB)
	elif mode==145: RRMWBwU6pG = NhVHcnMi2ol3LrjmA8d4t9YUaDF1(url)
	elif mode==146: RRMWBwU6pG = AtIcqi31lbZ8saOTYBWg2HMdmQkSX6(url)
	elif mode==147: RRMWBwU6pG = N9kU2Sslw3gmpWOb6oaLF()
	elif mode==148: RRMWBwU6pG = hhatoMULjG0pHnXs()
	elif mode==149: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مواقع اختارها يوتيوب',GqcEfFR8XQPgBMLr+'/feed/guide_builder',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الصفحة الرئيسية',GqcEfFR8XQPgBMLr,144,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المحتوى الرائج',GqcEfFR8XQPgBMLr+'/feed/trending',146)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: قنوات عربية','',147)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: قنوات أجنبية','',148)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: افلام عربية',GqcEfFR8XQPgBMLr+'/results?search_query=فيلم',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: افلام اجنبية',GqcEfFR8XQPgBMLr+'/results?search_query=movie',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: مسرحيات عربية',GqcEfFR8XQPgBMLr+'/results?search_query=مسرحية',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: مسلسلات عربية',GqcEfFR8XQPgBMLr+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: مسلسلات اجنبية',GqcEfFR8XQPgBMLr+'/results?search_query=series&sp=EgIQAw==',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: مسلسلات كارتون',GqcEfFR8XQPgBMLr+'/results?search_query=كارتون&sp=EgIQAw==',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بحث: خطبة المرجعية',GqcEfFR8XQPgBMLr+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def N9kU2Sslw3gmpWOb6oaLF():
	F42EXtwuzB7Hl(GqcEfFR8XQPgBMLr+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def hhatoMULjG0pHnXs():
	F42EXtwuzB7Hl(GqcEfFR8XQPgBMLr+'/results?search_query=tv&sp=EgJAAQ==')
	return
def unQmcpAEF2DaNX87fTgMW(url,type):
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP([url],mm5vCBc4DOz2Fj,type,url)
	return
def AtIcqi31lbZ8saOTYBWg2HMdmQkSX6(url):
	Ht6Gg8lbciAd9FaUQVs,K2DlNXvQC65FzngUVyk3IGAq,data = zitPVCUuD4JEeGg(url)
	IwnFBatrHMx5 = K2DlNXvQC65FzngUVyk3IGAq['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for kdWCpE9TjNh in range(len(IwnFBatrHMx5)):
		F5o1sgcqZVlS = IwnFBatrHMx5[kdWCpE9TjNh]
		VpoiOrWUNSZqBY(F5o1sgcqZVlS,url,str(kdWCpE9TjNh))
	V08JplMKveN69wDoERsI = IwnFBatrHMx5[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	WbuxiAgNzqvPZCm5lwU = 0
	for kdWCpE9TjNh in range(len(V08JplMKveN69wDoERsI)):
		F5o1sgcqZVlS = V08JplMKveN69wDoERsI[kdWCpE9TjNh]['itemSectionRenderer']['contents'][0]
		if list(F5o1sgcqZVlS['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		tabjWm69HD,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u = qOf0QTKxvI(F5o1sgcqZVlS)
		if not title:
			WbuxiAgNzqvPZCm5lwU += 1
			title = 'فيديوهات رائجة '+str(WbuxiAgNzqvPZCm5lwU)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,144,'',str(kdWCpE9TjNh))
	key = QPuHKNAT4jmCRg.findall('"innertubeApiKey":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	Ht6Gg8lbciAd9FaUQVs,K2DlNXvQC65FzngUVyk3IGAq,BF8XfchlgKmOE0ru2 = zitPVCUuD4JEeGg(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	for B5uUMHex2L0W6b in range(3,4):
		IwnFBatrHMx5 = K2DlNXvQC65FzngUVyk3IGAq['items'][B5uUMHex2L0W6b]['guideSectionRenderer']['items']
		for kdWCpE9TjNh in range(len(IwnFBatrHMx5)):
			F5o1sgcqZVlS = IwnFBatrHMx5[kdWCpE9TjNh]
			if 'YouTube Premium' in str(F5o1sgcqZVlS): continue
			VpoiOrWUNSZqBY(F5o1sgcqZVlS)
	return
def F42EXtwuzB7Hl(url,data='',index=0):
	global fQ6kvwg1FrYAzXjbLT
	if not data: data = fQ6kvwg1FrYAzXjbLT.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	Ht6Gg8lbciAd9FaUQVs,K2DlNXvQC65FzngUVyk3IGAq,BF8XfchlgKmOE0ru2 = zitPVCUuD4JEeGg(url,data)
	XxIGVcwZTJmhdO26ynPzr7,w7xNs1GjAqhTroD8F4p6 = '',''
	FFKnMSt5ROf9PLeBd = QPuHKNAT4jmCRg.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not FFKnMSt5ROf9PLeBd: FFKnMSt5ROf9PLeBd = QPuHKNAT4jmCRg.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not FFKnMSt5ROf9PLeBd: FFKnMSt5ROf9PLeBd = QPuHKNAT4jmCRg.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if FFKnMSt5ROf9PLeBd:
		XxIGVcwZTJmhdO26ynPzr7 = '[COLOR FFC89008]'+FFKnMSt5ROf9PLeBd[0][0]+'[/COLOR]'
		VV7yf2htDCBU6EeSX8TJQM = FFKnMSt5ROf9PLeBd[0][1]
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
		if 'list=' in url: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+XxIGVcwZTJmhdO26ynPzr7,VV7yf2htDCBU6EeSX8TJQM,144)
	yyRimagT8K9xlkHQ1qErZGJLbMSXvU = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	TPgEr8n0ZoczHRjCYd59hml = not any(pp8iHB3W9Cs in url for pp8iHB3W9Cs in yyRimagT8K9xlkHQ1qErZGJLbMSXvU)
	if TPgEr8n0ZoczHRjCYd59hml and XxIGVcwZTJmhdO26ynPzr7:
		gH8mavstuiyE6RY2 = 'البحث'
		nUbpaNT0vhcj7ZsEz = 'قوائم التشغيل'
		cu5XL4g8po7F = 'الفيديوهات'
		xclA6j4XpuTYGntP8FiwSW70v2f9 = 'القنوات'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+XxIGVcwZTJmhdO26ynPzr7,url,9999)
		if '"title":"بحث"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+gH8mavstuiyE6RY2,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,url+'/playlists',144)
		if '"title":"الفيديوهات"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+cu5XL4g8po7F,url+'/videos',144)
		if '"title":"القنوات"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+xclA6j4XpuTYGntP8FiwSW70v2f9,url+'/channels',144)
		if '"title":"Search"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+gH8mavstuiyE6RY2,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,url+'/playlists',144)
		if '"title":"Videos"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+cu5XL4g8po7F,url+'/videos',144)
		if '"title":"Channels"' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+xclA6j4XpuTYGntP8FiwSW70v2f9,url+'/channels',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		IwnFBatrHMx5 = K2DlNXvQC65FzngUVyk3IGAq['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		lDF39TML4nzVkPmpyctGUN5riWjeg = 0
		for PXBFxvuUlLDHGpm58 in range(len(IwnFBatrHMx5)):
			if 'itemSectionRenderer' in list(IwnFBatrHMx5[PXBFxvuUlLDHGpm58].keys()):
				flLYmIPiboXjQrq1sVxu5ZNyDO = IwnFBatrHMx5[PXBFxvuUlLDHGpm58]['itemSectionRenderer']
				KOtnoe7NXMaF3jD8UfuLd = len(str(flLYmIPiboXjQrq1sVxu5ZNyDO))
				if KOtnoe7NXMaF3jD8UfuLd>lDF39TML4nzVkPmpyctGUN5riWjeg:
					lDF39TML4nzVkPmpyctGUN5riWjeg = KOtnoe7NXMaF3jD8UfuLd
					w7xNs1GjAqhTroD8F4p6 = flLYmIPiboXjQrq1sVxu5ZNyDO
		if lDF39TML4nzVkPmpyctGUN5riWjeg==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==GqcEfFR8XQPgBMLr:
		kNhfueKQUPm06lMv74 = []
		kNhfueKQUPm06lMv74.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		kNhfueKQUPm06lMv74.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		kNhfueKQUPm06lMv74.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		kNhfueKQUPm06lMv74.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		kNhfueKQUPm06lMv74.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		kNhfueKQUPm06lMv74.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		kNhfueKQUPm06lMv74.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		kNhfueKQUPm06lMv74.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		NhvK8u4J9Z0t,w7xNs1GjAqhTroD8F4p6 = ukJhB809FSjx(K2DlNXvQC65FzngUVyk3IGAq,'',kNhfueKQUPm06lMv74)
	if not w7xNs1GjAqhTroD8F4p6:
		try:
			IwnFBatrHMx5 = K2DlNXvQC65FzngUVyk3IGAq['contents']['twoColumnBrowseResultsRenderer']['tabs']
			YmT9oB2qsey6hJKFvXbDLkpa = '/videos' in url or '/playlists' in url or '/channels' in url
			eCMsNVfdH1oO9Yzy6Uv = '"title":"الفيديوهات"' in Ht6Gg8lbciAd9FaUQVs or '"title":"قوائم التشغيل"' in Ht6Gg8lbciAd9FaUQVs or '"title":"القنوات"' in Ht6Gg8lbciAd9FaUQVs
			YQVeJthG3Xiq27L1f0mdDPvk8 = '"title":"Videos"' in Ht6Gg8lbciAd9FaUQVs or '"title":"Playlists"' in Ht6Gg8lbciAd9FaUQVs or '"title":"Channels"' in Ht6Gg8lbciAd9FaUQVs
			if YmT9oB2qsey6hJKFvXbDLkpa and (eCMsNVfdH1oO9Yzy6Uv or YQVeJthG3Xiq27L1f0mdDPvk8):
				for kdWCpE9TjNh in range(len(IwnFBatrHMx5)):
					if 'tabRenderer' not in list(IwnFBatrHMx5[kdWCpE9TjNh].keys()): continue
					V08JplMKveN69wDoERsI = IwnFBatrHMx5[kdWCpE9TjNh]['tabRenderer']
					try: vbkmX346OYHjn8JIeFMWSLyNC5Pi = V08JplMKveN69wDoERsI['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][kdWCpE9TjNh]
					except: vbkmX346OYHjn8JIeFMWSLyNC5Pi = V08JplMKveN69wDoERsI
					try: VV7yf2htDCBU6EeSX8TJQM = vbkmX346OYHjn8JIeFMWSLyNC5Pi['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in VV7yf2htDCBU6EeSX8TJQM	and '/videos'		in url: V08JplMKveN69wDoERsI = IwnFBatrHMx5[kdWCpE9TjNh] ; break
					elif '/playlists'	in VV7yf2htDCBU6EeSX8TJQM	and '/playlists'	in url: V08JplMKveN69wDoERsI = IwnFBatrHMx5[kdWCpE9TjNh] ; break
					elif '/channels'	in VV7yf2htDCBU6EeSX8TJQM	and '/channels'		in url: V08JplMKveN69wDoERsI = IwnFBatrHMx5[kdWCpE9TjNh] ; break
					else: V08JplMKveN69wDoERsI = IwnFBatrHMx5[0]
			elif 'bp=' in url: V08JplMKveN69wDoERsI = IwnFBatrHMx5[index]
			else: V08JplMKveN69wDoERsI = IwnFBatrHMx5[0]
			w7xNs1GjAqhTroD8F4p6 = V08JplMKveN69wDoERsI['tabRenderer']['content']
		except: pass
	if not w7xNs1GjAqhTroD8F4p6: return
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("ff['sectionListRenderer']")
	kNhfueKQUPm06lMv74.append("ff['richGridRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("ff['contents']")
	kNhfueKQUPm06lMv74.append("ff")
	rZLsBFGvqJbwfHDp = PPpWoLVXID4(u'كل قوائم التشغيل')
	UWQR0piV5f = PPpWoLVXID4(u'كل الفيديوهات')
	yN6ZqOX7znao34SMGj = PPpWoLVXID4(u'كل القنوات')
	x2emCwIvD89KAjhG = [rZLsBFGvqJbwfHDp,UWQR0piV5f,yN6ZqOX7znao34SMGj,'All playlists','All videos','All channels']
	tW2XY1vHBwDfolpyZr8sN5dxKGu,vbkmX346OYHjn8JIeFMWSLyNC5Pi = ukJhB809FSjx(w7xNs1GjAqhTroD8F4p6,index,kNhfueKQUPm06lMv74)
	if 'list' in str(type(vbkmX346OYHjn8JIeFMWSLyNC5Pi)) and any(pp8iHB3W9Cs in str(vbkmX346OYHjn8JIeFMWSLyNC5Pi[0]) for pp8iHB3W9Cs in x2emCwIvD89KAjhG): del vbkmX346OYHjn8JIeFMWSLyNC5Pi[0]
	for qc8aUVGwZfi3MX in range(len(vbkmX346OYHjn8JIeFMWSLyNC5Pi)):
		kNhfueKQUPm06lMv74 = []
		kNhfueKQUPm06lMv74.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		kNhfueKQUPm06lMv74.append("gg[index2]['itemSectionRenderer']['header']")
		kNhfueKQUPm06lMv74.append("gg[index2]['horizontalCardListRenderer']['header']")
		kNhfueKQUPm06lMv74.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		kNhfueKQUPm06lMv74.append("gg[index2]['richSectionRenderer']['content']")
		kNhfueKQUPm06lMv74.append("gg[index2]['richItemRenderer']['content']")
		kNhfueKQUPm06lMv74.append("gg[index2]['gameCardRenderer']['game']")
		kNhfueKQUPm06lMv74.append("gg[index2]")
		NhvK8u4J9Z0t,F5o1sgcqZVlS = ukJhB809FSjx(vbkmX346OYHjn8JIeFMWSLyNC5Pi,qc8aUVGwZfi3MX,kNhfueKQUPm06lMv74)
		VpoiOrWUNSZqBY(F5o1sgcqZVlS,url,str(qc8aUVGwZfi3MX))
		if NhvK8u4J9Z0t=='4':
			try:
				f9cpWsXHU4hOlyCtReiqBAxb = F5o1sgcqZVlS['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for FFrZMHdmIWtg in range(len(f9cpWsXHU4hOlyCtReiqBAxb)):
					XuJCyrm9ifWO6DTSxVQp = f9cpWsXHU4hOlyCtReiqBAxb[FFrZMHdmIWtg]
					VpoiOrWUNSZqBY(XuJCyrm9ifWO6DTSxVQp)
			except: pass
	tX4e9uQrjYwl3I = False
	if 'view=' not in url and tW2XY1vHBwDfolpyZr8sN5dxKGu=='8': tX4e9uQrjYwl3I = True
	if ':::' in BF8XfchlgKmOE0ru2: rioeAlyX4qZ3gE7u,key,z1alIR7Jq5rd3xhKnHp,Ddypws9QcP1FlB6nKTzOeb2,uWCKp2UeRYGXINl,mQiagbuLRZHV2l6k9S = BF8XfchlgKmOE0ru2.split(':::')
	else: rioeAlyX4qZ3gE7u,key,z1alIR7Jq5rd3xhKnHp,Ddypws9QcP1FlB6nKTzOeb2,uWCKp2UeRYGXINl,mQiagbuLRZHV2l6k9S = '','','','','',''
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,VpolhzO6Kj = '',''
	if vvruH9wsBDfbhFtyq1MUd2zV:
		lJ3L7eFKQ5vYrzR = str(vvruH9wsBDfbhFtyq1MUd2zV[-1][1])
		if   JE7QrkmhletLwA0OZXu+'CHNL' in lJ3L7eFKQ5vYrzR: VpolhzO6Kj = 'CHANNELS'
		elif JE7QrkmhletLwA0OZXu+'USER' in lJ3L7eFKQ5vYrzR: VpolhzO6Kj = 'CHANNELS'
		elif JE7QrkmhletLwA0OZXu+'LIST' in lJ3L7eFKQ5vYrzR: VpolhzO6Kj = 'PLAYLISTS'
	if '"continuations"' in Ht6Gg8lbciAd9FaUQVs and '&list=' not in url and not tX4e9uQrjYwl3I and 'shelf_id' not in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+'/browse_ajax?ctoken='+z1alIR7Jq5rd3xhKnHp
	elif '"token"' in Ht6Gg8lbciAd9FaUQVs and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+'/youtubei/v1/search?key='+key
	elif '"token"' in Ht6Gg8lbciAd9FaUQVs and 'bp=' not in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+'/youtubei/v1/browse?key='+key
	if lZqkuhgaBHSVX8NItKG05cdLJe7Ao: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة أخرى',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,144,VpolhzO6Kj,'',BF8XfchlgKmOE0ru2)
	return
def ukJhB809FSjx(z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw,HLdTk7KGXpqRZoPjnUIx):
	K2DlNXvQC65FzngUVyk3IGAq = z8ty6aqx2wKOIsul
	w7xNs1GjAqhTroD8F4p6,index = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	vbkmX346OYHjn8JIeFMWSLyNC5Pi,qc8aUVGwZfi3MX = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	F5o1sgcqZVlS,wwtoDlG3c9TCHNagmV = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	count = len(HLdTk7KGXpqRZoPjnUIx)
	for kdWCpE9TjNh in range(count):
		try:
			Zf3UcusIdT = eval(HLdTk7KGXpqRZoPjnUIx[kdWCpE9TjNh])
			return str(kdWCpE9TjNh+1),Zf3UcusIdT
		except: pass
	return '',''
def qOf0QTKxvI(F5o1sgcqZVlS):
	try: KKhp83Z0bESgQUyTV6NB42RiGHwze = list(F5o1sgcqZVlS.keys())[0]
	except: return False,'','','','','','',''
	tabjWm69HD,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u = False,'','','','','','',''
	wwtoDlG3c9TCHNagmV = F5o1sgcqZVlS[KKhp83Z0bESgQUyTV6NB42RiGHwze]
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("render['unplayableText']['simpleText']")
	kNhfueKQUPm06lMv74.append("render['formattedTitle']['simpleText']")
	kNhfueKQUPm06lMv74.append("render['title']['simpleText']")
	kNhfueKQUPm06lMv74.append("render['title']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("render['text']['simpleText']")
	kNhfueKQUPm06lMv74.append("render['text']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("render['title']")
	kNhfueKQUPm06lMv74.append("item['title']")
	NhvK8u4J9Z0t,title = ukJhB809FSjx(F5o1sgcqZVlS,wwtoDlG3c9TCHNagmV,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	NhvK8u4J9Z0t,VV7yf2htDCBU6EeSX8TJQM = ukJhB809FSjx(F5o1sgcqZVlS,wwtoDlG3c9TCHNagmV,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("render['thumbnail']['thumbnails'][0]['url']")
	kNhfueKQUPm06lMv74.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	NhvK8u4J9Z0t,G2WR0Oacvdq8ZQTjKboDU = ukJhB809FSjx(F5o1sgcqZVlS,wwtoDlG3c9TCHNagmV,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("render['videoCount']")
	kNhfueKQUPm06lMv74.append("render['videoCountText']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	NhvK8u4J9Z0t,count = ukJhB809FSjx(F5o1sgcqZVlS,wwtoDlG3c9TCHNagmV,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("render['lengthText']['simpleText']")
	kNhfueKQUPm06lMv74.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	kNhfueKQUPm06lMv74.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	NhvK8u4J9Z0t,VVaBpWQDAfx5dO4GSMmstz78eRFYw = ukJhB809FSjx(F5o1sgcqZVlS,wwtoDlG3c9TCHNagmV,kNhfueKQUPm06lMv74)
	if 'LIVE' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56 = '','LIVE:  '
	if 'مباشر' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56 = '','LIVE:  '
	if 'badges' in list(wwtoDlG3c9TCHNagmV.keys()):
		AnuSziPdrF17lN = str(wwtoDlG3c9TCHNagmV['badges'])
		if 'Free with Ads' in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$:'
		if 'LIVE NOW' in AnuSziPdrF17lN: UQ7tunCIEc56 = 'LIVE:  '
		if 'Buy' in AnuSziPdrF17lN or 'Rent' in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$$:'
		if PPpWoLVXID4(u'مباشر') in AnuSziPdrF17lN: UQ7tunCIEc56 = 'LIVE:  '
		if PPpWoLVXID4(u'شراء') in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$$:'
		if PPpWoLVXID4(u'استئجار') in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$$:'
		if PPpWoLVXID4(u'إعلانات') in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$:'
	VV7yf2htDCBU6EeSX8TJQM = kWfpQA7tTjSPyLbNIeMr1Hui5(VV7yf2htDCBU6EeSX8TJQM)
	if VV7yf2htDCBU6EeSX8TJQM and 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
	G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.split('?')[0]
	if  G2WR0Oacvdq8ZQTjKboDU and 'http' not in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = 'https:'+G2WR0Oacvdq8ZQTjKboDU
	title = kWfpQA7tTjSPyLbNIeMr1Hui5(title)
	if APIWtCph8cLSvBRiU20u: title = APIWtCph8cLSvBRiU20u+'  '+title
	VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.replace(',','')
	count = count.replace(',','')
	count = QPuHKNAT4jmCRg.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u
def VpoiOrWUNSZqBY(F5o1sgcqZVlS,url='',index=''):
	tabjWm69HD,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u = qOf0QTKxvI(F5o1sgcqZVlS)
	if not tabjWm69HD: return
	elif 'continuationItemRenderer' in str(F5o1sgcqZVlS): return
	elif 'searchPyvRenderer' in str(F5o1sgcqZVlS): return
	elif not VV7yf2htDCBU6EeSX8TJQM and 'search_query' in url: return
	elif title and not VV7yf2htDCBU6EeSX8TJQM and ('search_query' in url or 'horizontalMovieListRenderer' in str(F5o1sgcqZVlS) or url==GqcEfFR8XQPgBMLr):
		title = '=== '+title+' ==='
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+title,'',9999)
	elif title and 'messageRenderer' in str(F5o1sgcqZVlS):
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+title,'',9999)
	elif '/feed/trending' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,index)
	elif not title: return
	elif UQ7tunCIEc56: fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+UQ7tunCIEc56+title,VV7yf2htDCBU6EeSX8TJQM,143,G2WR0Oacvdq8ZQTjKboDU)
	elif 'watch?v=' in VV7yf2htDCBU6EeSX8TJQM or '/shorts/' in VV7yf2htDCBU6EeSX8TJQM:
		if '&list=' in VV7yf2htDCBU6EeSX8TJQM and 'index=' not in VV7yf2htDCBU6EeSX8TJQM:
			KfQtAyIxdRBMFzo64U = VV7yf2htDCBU6EeSX8TJQM.split('&list=',1)[1]
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/playlist?list='+KfQtAyIxdRBMFzo64U
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'LIST'+count+':  '+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU)
		else:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&list=',1)[0]
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,143,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw)
	else:
		type = ''
		if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = url
		elif not any(pp8iHB3W9Cs in VV7yf2htDCBU6EeSX8TJQM for pp8iHB3W9Cs in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in VV7yf2htDCBU6EeSX8TJQM or '/c/' in VV7yf2htDCBU6EeSX8TJQM: type = 'CHNL'+count+':  '
			if '/user/' in VV7yf2htDCBU6EeSX8TJQM: type = 'USER'+count+':  '
			index,weWtXSPr0ohmzbZ4MsqJjYONVID = '',''
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+type+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,index)
	return
def zitPVCUuD4JEeGg(url,data='',lp3eGht9uF4mMCR6YIWz=''):
	global fQ6kvwg1FrYAzXjbLT
	if not data: data = fQ6kvwg1FrYAzXjbLT.getSetting('av.youtube.data')
	if lp3eGht9uF4mMCR6YIWz=='': lp3eGht9uF4mMCR6YIWz = 'ytInitialData'
	oOM6fji0UV3Yn2 = yWgZFzdaNR5iw6m8Q9G7CL()
	Eudgv5cTUHF2AzKpkx = {'User-Agent':oOM6fji0UV3Yn2,'Cookie':'PREF=hl=ar'}
	if ':::' in data: rioeAlyX4qZ3gE7u,key,z1alIR7Jq5rd3xhKnHp,Ddypws9QcP1FlB6nKTzOeb2,uWCKp2UeRYGXINl,mQiagbuLRZHV2l6k9S = data.split(':::')
	else: rioeAlyX4qZ3gE7u,key,z1alIR7Jq5rd3xhKnHp,Ddypws9QcP1FlB6nKTzOeb2,uWCKp2UeRYGXINl,mQiagbuLRZHV2l6k9S = '','','','','',''
	if 'guide?key=' in url:
		BF8XfchlgKmOE0ru2 = {}
		BF8XfchlgKmOE0ru2['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":Ddypws9QcP1FlB6nKTzOeb2}}
		BF8XfchlgKmOE0ru2 = str(BF8XfchlgKmOE0ru2)
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',url,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and rioeAlyX4qZ3gE7u:
		BF8XfchlgKmOE0ru2 = {'continuation':uWCKp2UeRYGXINl}
		BF8XfchlgKmOE0ru2['context'] = {"client":{"visitorData":rioeAlyX4qZ3gE7u,"clientName":"WEB","clientVersion":Ddypws9QcP1FlB6nKTzOeb2}}
		BF8XfchlgKmOE0ru2 = str(BF8XfchlgKmOE0ru2)
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',url,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and mQiagbuLRZHV2l6k9S:
		Eudgv5cTUHF2AzKpkx.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':Ddypws9QcP1FlB6nKTzOeb2})
		Eudgv5cTUHF2AzKpkx.update({'Cookie':'VISITOR_INFO1_LIVE='+mQiagbuLRZHV2l6k9S})
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'',Eudgv5cTUHF2AzKpkx,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'',Eudgv5cTUHF2AzKpkx,'','','YOUTUBE-GET_PAGE_DATA-4th')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	hpEW8DMltLq21bUvKk7dgeFAzVCJY = QPuHKNAT4jmCRg.findall('"innertubeApiKey".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if hpEW8DMltLq21bUvKk7dgeFAzVCJY: key = hpEW8DMltLq21bUvKk7dgeFAzVCJY[0]
	hpEW8DMltLq21bUvKk7dgeFAzVCJY = QPuHKNAT4jmCRg.findall('"cver".*?"value".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if hpEW8DMltLq21bUvKk7dgeFAzVCJY: Ddypws9QcP1FlB6nKTzOeb2 = hpEW8DMltLq21bUvKk7dgeFAzVCJY[0]
	hpEW8DMltLq21bUvKk7dgeFAzVCJY = QPuHKNAT4jmCRg.findall('"token".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if hpEW8DMltLq21bUvKk7dgeFAzVCJY: uWCKp2UeRYGXINl = hpEW8DMltLq21bUvKk7dgeFAzVCJY[0]
	hpEW8DMltLq21bUvKk7dgeFAzVCJY = QPuHKNAT4jmCRg.findall('"visitorData".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if hpEW8DMltLq21bUvKk7dgeFAzVCJY: rioeAlyX4qZ3gE7u = hpEW8DMltLq21bUvKk7dgeFAzVCJY[0]
	hpEW8DMltLq21bUvKk7dgeFAzVCJY = QPuHKNAT4jmCRg.findall('"continuation".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if hpEW8DMltLq21bUvKk7dgeFAzVCJY: z1alIR7Jq5rd3xhKnHp = hpEW8DMltLq21bUvKk7dgeFAzVCJY[0]
	cookies = nbdMp8UuhzP3oq4cDWj6eyZVt.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): mQiagbuLRZHV2l6k9S = cookies['VISITOR_INFO1_LIVE']
	data = rioeAlyX4qZ3gE7u+':::'+key+':::'+z1alIR7Jq5rd3xhKnHp+':::'+Ddypws9QcP1FlB6nKTzOeb2+':::'+uWCKp2UeRYGXINl+':::'+mQiagbuLRZHV2l6k9S
	if lp3eGht9uF4mMCR6YIWz=='ytInitialData' and 'ytInitialData' in Ht6Gg8lbciAd9FaUQVs:
		wZ72rPoBbdRYFOm4TzSEutN = QPuHKNAT4jmCRg.findall('window\["ytInitialData"\] = ({.*?});',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not wZ72rPoBbdRYFOm4TzSEutN: wZ72rPoBbdRYFOm4TzSEutN = QPuHKNAT4jmCRg.findall('var ytInitialData = ({.*?});',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		dQsPlfr7k2nDuiVgHz0tAEJ54 = kMLWTt2fO9dnGDUgHh('str',wZ72rPoBbdRYFOm4TzSEutN[0])
	elif lp3eGht9uF4mMCR6YIWz=='ytInitialGuideData' and 'ytInitialGuideData' in Ht6Gg8lbciAd9FaUQVs:
		wZ72rPoBbdRYFOm4TzSEutN = QPuHKNAT4jmCRg.findall('var ytInitialGuideData = ({.*?});',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		dQsPlfr7k2nDuiVgHz0tAEJ54 = kMLWTt2fO9dnGDUgHh('str',wZ72rPoBbdRYFOm4TzSEutN[0])
	elif '</script>' not in Ht6Gg8lbciAd9FaUQVs: dQsPlfr7k2nDuiVgHz0tAEJ54 = kMLWTt2fO9dnGDUgHh('str',Ht6Gg8lbciAd9FaUQVs)
	else: dQsPlfr7k2nDuiVgHz0tAEJ54 = ''
	fQ6kvwg1FrYAzXjbLT.setSetting('av.youtube.data',data)
	return Ht6Gg8lbciAd9FaUQVs,dQsPlfr7k2nDuiVgHz0tAEJ54,data
def NhVHcnMi2ol3LrjmA8d4t9YUaDF1(url):
	search = wod1HJ0fnvcTNAX2WIiMu9P()
	if not search: return
	search = search.replace(' ','+')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/search?query='+search
	F42EXtwuzB7Hl(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	search = search.replace(' ','+')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in vwIN38HprDqTW5Sh61exF7EnA: zdCvQa6xDuwple3H4nZ0WFKXMLg = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in vwIN38HprDqTW5Sh61exF7EnA: zdCvQa6xDuwple3H4nZ0WFKXMLg = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in vwIN38HprDqTW5Sh61exF7EnA: zdCvQa6xDuwple3H4nZ0WFKXMLg = '&sp=EgIQAg%253D%253D'
		lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+zdCvQa6xDuwple3H4nZ0WFKXMLg
	else:
		wxz1gjoBHmlY2IqZNk,d6dwmFerfbV2JYLnNT,nUbpaNT0vhcj7ZsEz = [],[],''
		RWvzaCEoOtYl45pq7LnsI02 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		yuqgGDemO2sjaBLkpNfAc = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		PRBLAwM5QD7djgXYIGkzoK8uanfvO = ISveRUGKjgM9wqL6FZpsku0bB('موقع يوتيوب - اختر الترتيب',RWvzaCEoOtYl45pq7LnsI02)
		if PRBLAwM5QD7djgXYIGkzoK8uanfvO == -1: return
		wwQATDIdKfcYx = yuqgGDemO2sjaBLkpNfAc[PRBLAwM5QD7djgXYIGkzoK8uanfvO]
		Ht6Gg8lbciAd9FaUQVs,sjhXNO10W4CTqlAS8JeZwtKBnPm9UG,data = zitPVCUuD4JEeGg(lZqkuhgaBHSVX8NItKG05cdLJe7Ao+wwQATDIdKfcYx)
		if sjhXNO10W4CTqlAS8JeZwtKBnPm9UG:
			NJHsCZEmV7l4hGMU = sjhXNO10W4CTqlAS8JeZwtKBnPm9UG['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for KLGFa4V95CDwtu1l in range(len(NJHsCZEmV7l4hGMU)):
				group = NJHsCZEmV7l4hGMU[KLGFa4V95CDwtu1l]['searchFilterGroupRenderer']['filters']
				for izJqrMn2oRxZj in range(len(group)):
					wwtoDlG3c9TCHNagmV = group[izJqrMn2oRxZj]['searchFilterRenderer']
					if 'navigationEndpoint' in list(wwtoDlG3c9TCHNagmV.keys()):
						VV7yf2htDCBU6EeSX8TJQM = wwtoDlG3c9TCHNagmV['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\u0026','&')
						title = wwtoDlG3c9TCHNagmV['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							nUbpaNT0vhcj7ZsEz = title
							FsnXTNzcG53RUk = VV7yf2htDCBU6EeSX8TJQM
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							nUbpaNT0vhcj7ZsEz = title
							FsnXTNzcG53RUk = VV7yf2htDCBU6EeSX8TJQM
						if 'Sort by' in title: continue
						wxz1gjoBHmlY2IqZNk.append(kWfpQA7tTjSPyLbNIeMr1Hui5(title))
						d6dwmFerfbV2JYLnNT.append(VV7yf2htDCBU6EeSX8TJQM)
		if not nUbpaNT0vhcj7ZsEz: JL5gMtXaYzTquOSFEbc6H = ''
		else:
			wxz1gjoBHmlY2IqZNk = ['بدون فلتر',nUbpaNT0vhcj7ZsEz]+wxz1gjoBHmlY2IqZNk
			d6dwmFerfbV2JYLnNT = ['',FsnXTNzcG53RUk]+d6dwmFerfbV2JYLnNT
			q95vKZkwaPGSz = ISveRUGKjgM9wqL6FZpsku0bB('موقع يوتيوب - اختر الفلتر',wxz1gjoBHmlY2IqZNk)
			if q95vKZkwaPGSz == -1: return
			JL5gMtXaYzTquOSFEbc6H = d6dwmFerfbV2JYLnNT[q95vKZkwaPGSz]
		if JL5gMtXaYzTquOSFEbc6H: lc154VhT9DCqMk8 = GqcEfFR8XQPgBMLr+JL5gMtXaYzTquOSFEbc6H
		elif wwQATDIdKfcYx: lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+wwQATDIdKfcYx
		else: lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao
	F42EXtwuzB7Hl(lc154VhT9DCqMk8)
	return
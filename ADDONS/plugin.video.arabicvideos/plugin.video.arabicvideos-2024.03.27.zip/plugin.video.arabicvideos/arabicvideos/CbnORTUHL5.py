# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'ARABSEED'
headers = {'User-Agent':yWgZFzdaNR5iw6m8Q9G7CL()}
JE7QrkmhletLwA0OZXu = '_ARS_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==250: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==251: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==252: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==253: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==254: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'CATEGORIES___'+text)
	elif mode==255: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'FILTERS___'+text)
	elif mode==256: RRMWBwU6pG = pF0d4b2ZY9(url,text)
	elif mode==259: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr+'/main','',headers,'','','ARABSEED-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',GqcEfFR8XQPgBMLr+'/category/اخرى',254)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',GqcEfFR8XQPgBMLr+'/category/اخرى',255)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',GqcEfFR8XQPgBMLr+'/main',251,'','','featured_main')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'جديد الأفلام',GqcEfFR8XQPgBMLr+'/main',251,'','','new_movies')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'جديد الحلقات',GqcEfFR8XQPgBMLr+'/main',251,'','','new_episodes')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المضاف حديثاً',GqcEfFR8XQPgBMLr+'/latest',251,'','','lastest')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('class="MenuHeader"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	y8qSvx0Z9MY = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
	eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',y8qSvx0Z9MY,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in eIXD9Ql3JREsm4WvKc:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if title not in EhRQ8zB1fdkj5vN6HlmqD7SOU and title!='':
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,256)
	return Ht6Gg8lbciAd9FaUQVs
def pF0d4b2ZY9(url,type):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if 'class="SliderInSection' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in Ht6Gg8lbciAd9FaUQVs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in Ht6Gg8lbciAd9FaUQVs:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="LinksList(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			if len(TTCRYZroizb)>1 and type=='new_episodes': wltPGJcYo12Ed = TTCRYZroizb[1]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)"(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				nUbpaNT0vhcj7ZsEz = QPuHKNAT4jmCRg.findall('</i>(.*?)<span>(.*?)<',title,QPuHKNAT4jmCRg.DOTALL)
				try: g27TaovWhPEzbHsY39Bw = nUbpaNT0vhcj7ZsEz[0][0]
				except: g27TaovWhPEzbHsY39Bw = ''
				try: PyicFLATx4z58m2I = nUbpaNT0vhcj7ZsEz[0][1]
				except: PyicFLATx4z58m2I = ''
				nUbpaNT0vhcj7ZsEz = g27TaovWhPEzbHsY39Bw+PyicFLATx4z58m2I
				nUbpaNT0vhcj7ZsEz = nUbpaNT0vhcj7ZsEz.replace('\n','')
				if '<strong>' in title:
					cu5XL4g8po7F = QPuHKNAT4jmCRg.findall('</i>(.*?)<',title,QPuHKNAT4jmCRg.DOTALL)
					if cu5XL4g8po7F: nUbpaNT0vhcj7ZsEz = cu5XL4g8po7F[0]
				if not nUbpaNT0vhcj7ZsEz:
					cu5XL4g8po7F = QPuHKNAT4jmCRg.findall('alt="(.*?)"',title,QPuHKNAT4jmCRg.DOTALL)
					if cu5XL4g8po7F: nUbpaNT0vhcj7ZsEz = cu5XL4g8po7F[0]
				if nUbpaNT0vhcj7ZsEz:
					if 'key=' in VV7yf2htDCBU6EeSX8TJQM: type = VV7yf2htDCBU6EeSX8TJQM.split('key=')[1]
					else: type = 'newest'
					nUbpaNT0vhcj7ZsEz = nUbpaNT0vhcj7ZsEz.strip(' ')
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,VV7yf2htDCBU6EeSX8TJQM,251,'','',type)
	return
def SPFl6UGK4mrBua(url,type):
	c54S3WpKgGCxhUMD2E,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			j13qZFY7B6kNM,BF8XfchlgKmOE0ru2 = 'POST',{}
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao,mOs52o91PbFZD7C = url.split('?')
			I7Q0GxoOc5ECkY6zfjhg = mOs52o91PbFZD7C.split('&')
			for ZmSt0LenHKEjq2BXQTz84vCO in I7Q0GxoOc5ECkY6zfjhg:
				key,pp8iHB3W9Cs = ZmSt0LenHKEjq2BXQTz84vCO.split('=')
				BF8XfchlgKmOE0ru2[key] = pp8iHB3W9Cs
			if I7Q0GxoOc5ECkY6zfjhg: c54S3WpKgGCxhUMD2E,url,data = j13qZFY7B6kNM,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,c54S3WpKgGCxhUMD2E,url,data,headers,'','','ARABSEED-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if type=='filters': TTCRYZroizb = [Ht6Gg8lbciAd9FaUQVs]
	elif 'featured' in type: TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="MainSlides(.*?)class="LinksList',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	elif type=='new_movies': TTCRYZroizb = QPuHKNAT4jmCRg.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	elif type=='new_episodes': TTCRYZroizb = QPuHKNAT4jmCRg.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	elif type=='most': TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="SliderInSection(.*?)class="LinksList',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	else: TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="Blocks-UL"(.*?)class="AboElSeed"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if 'featured' in type:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		EZNqlULKjPXaeJDBFdpsrAh = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if EZNqlULKjPXaeJDBFdpsrAh:
			LL8heV7kxYI5bOjEZ6XaUQWwfPA,xitERh4TD2jGJPq5Nuv39CAmg,IINRewBkoOz7XDGxcpYShHaK,cR4vMuiDFYW9LOXHt7xqg = zip(*EZNqlULKjPXaeJDBFdpsrAh)
			items = zip(LL8heV7kxYI5bOjEZ6XaUQWwfPA,cR4vMuiDFYW9LOXHt7xqg,xitERh4TD2jGJPq5Nuv39CAmg)
	else:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if 'WWE' in title: continue
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if 'الحلقة' in title:
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
			if CiZxgXTGW9pv:
				title = '_MOD_' + CiZxgXTGW9pv[0]
				if title not in gltHFKTroJfpLe:
					gltHFKTroJfpLe.append(title)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,253,G2WR0Oacvdq8ZQTjKboDU)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,252,G2WR0Oacvdq8ZQTjKboDU)
		elif '/selary/' in VV7yf2htDCBU6EeSX8TJQM or 'مسلسل' in title:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,253,G2WR0Oacvdq8ZQTjKboDU)
		else:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,252,G2WR0Oacvdq8ZQTjKboDU)
	if type in ['newest','best','most']:
		items = QPuHKNAT4jmCRg.findall('page-numbers" href="(.*?)">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			VV7yf2htDCBU6EeSX8TJQM = UH1IuvwM9e4cl7if63nNdozJFSj(VV7yf2htDCBU6EeSX8TJQM)
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,251,'','',type)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs[10000:]
	items = QPuHKNAT4jmCRg.findall('data-src="(.*?)".*?alt="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not items: return
	G2WR0Oacvdq8ZQTjKboDU,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="ContainerEpisodesList"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<em>(.*?)</em>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,CiZxgXTGW9pv in items:
			title = name+' - الحلقة رقم '+CiZxgXTGW9pv
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,252,G2WR0Oacvdq8ZQTjKboDU)
	else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+'ملف التشغيل',url,252,G2WR0Oacvdq8ZQTjKboDU)
	return
def NNXfWjp6TkxLKoDsP(title,VV7yf2htDCBU6EeSX8TJQM):
	nUbpaNT0vhcj7ZsEz = QPuHKNAT4jmCRg.findall('[a-zA-Z-]+',title,QPuHKNAT4jmCRg.DOTALL)
	if nUbpaNT0vhcj7ZsEz: title = nUbpaNT0vhcj7ZsEz[0]
	else: title = title+' '+znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nbdMp8UuhzP3oq4cDWj6eyZVt.url
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'url')
	headers['Referer'] = BHgLX9GZTb2jJrWiNKE+'/'
	eeq6V1bOZiD9JxjLkygKN,R1mtkuwgvEjCpJq0e,LL8heV7kxYI5bOjEZ6XaUQWwfPA = '','',[]
	BDHjNWdmGRc1wKfnPzuV = QPuHKNAT4jmCRg.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if BDHjNWdmGRc1wKfnPzuV: eeq6V1bOZiD9JxjLkygKN,WXKiUx9gNhG,R1mtkuwgvEjCpJq0e,bnZAcrOuJCM5z30RWQmlEYgqoLk = BDHjNWdmGRc1wKfnPzuV[0]
	else:
		BDHjNWdmGRc1wKfnPzuV = QPuHKNAT4jmCRg.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if BDHjNWdmGRc1wKfnPzuV:
			VV7yf2htDCBU6EeSX8TJQM,WXKiUx9gNhG = BDHjNWdmGRc1wKfnPzuV[0]
			if 'watch' in WXKiUx9gNhG: eeq6V1bOZiD9JxjLkygKN = VV7yf2htDCBU6EeSX8TJQM
			else: R1mtkuwgvEjCpJq0e = VV7yf2htDCBU6EeSX8TJQM
	if eeq6V1bOZiD9JxjLkygKN:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',eeq6V1bOZiD9JxjLkygKN,'',headers,'','','ARABSEED-PLAY-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="WatcherArea"(.*?</ul>)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			Rmb4FGfPuE7dLM3KlyWAJQN95UXrS = TTCRYZroizb[0]
			Rmb4FGfPuE7dLM3KlyWAJQN95UXrS = Rmb4FGfPuE7dLM3KlyWAJQN95UXrS.replace('</ul>','<h3>')
			Rmb4FGfPuE7dLM3KlyWAJQN95UXrS = Rmb4FGfPuE7dLM3KlyWAJQN95UXrS.replace('<h3>','<h3><h3>')
			N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('<h3>.*?(\d+)(.*?)<h3>',Rmb4FGfPuE7dLM3KlyWAJQN95UXrS,QPuHKNAT4jmCRg.DOTALL)
			if not N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd: N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = [('',Rmb4FGfPuE7dLM3KlyWAJQN95UXrS)]
			for i5DftlhA6vQ2GF,wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
				if i5DftlhA6vQ2GF: i5DftlhA6vQ2GF = '____'+i5DftlhA6vQ2GF
				items = QPuHKNAT4jmCRg.findall('data-link="(.*?)".*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				for VV7yf2htDCBU6EeSX8TJQM,name in items:
					if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
					VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__watch'+i5DftlhA6vQ2GF
					LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not Y4xiULzGTKjb8mulO: Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if Y4xiULzGTKjb8mulO:
			VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF = Y4xiULzGTKjb8mulO[0]
			name = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
			if '%' in i5DftlhA6vQ2GF: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__embed__'
			else: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__embed____'+i5DftlhA6vQ2GF
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if R1mtkuwgvEjCpJq0e:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',R1mtkuwgvEjCpJq0e,'',headers,'','','ARABSEED-PLAY-3rd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="DownloadArea"(.*?)function',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title,i5DftlhA6vQ2GF in items:
				if not VV7yf2htDCBU6EeSX8TJQM: continue
				if 'reviewstation' in VV7yf2htDCBU6EeSX8TJQM: continue
				VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download____'+i5DftlhA6vQ2GF
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	hY7gC1eV9TUJtcFPjOXMEksAzHo = str(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
	zGuHZYQ8xFVt3 = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(pp8iHB3W9Cs in hY7gC1eV9TUJtcFPjOXMEksAzHo for pp8iHB3W9Cs in zGuHZYQ8xFVt3):
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search: search = wod1HJ0fnvcTNAX2WIiMu9P()
	if not search: return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/find/?find='+search
	SPFl6UGK4mrBua(url,'search')
	return
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='CATEGORIES':
		if fugkyUNWIJGSslwLzx[0]+'==' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = fugkyUNWIJGSslwLzx[0]
		for PXBFxvuUlLDHGpm58 in range(len(fugkyUNWIJGSslwLzx[0:-1])):
			if fugkyUNWIJGSslwLzx[PXBFxvuUlLDHGpm58]+'==' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = fugkyUNWIJGSslwLzx[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&&'+jsEpRxQH76+'==0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&&'+jsEpRxQH76+'==0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'//getposts??'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='FILTERS':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'//getposts??'+Lb7kxwJZBPquygXoO4nTSN3
		MPfKjlDAZTV6 = AsOwHTp3NU1bgGLoa7cCWeSX8h(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',MPfKjlDAZTV6,251,'','','filters')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',MPfKjlDAZTV6,251,'','','filters')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	EVNyCZmIoiuP = QPuHKNAT4jmCRg.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	pkr5WQAoRVIPZHS1F4vd8f0guDe = QPuHKNAT4jmCRg.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	K0MwVeCGOmJho = EVNyCZmIoiuP+pkr5WQAoRVIPZHS1F4vd8f0guDe
	dict = {}
	for name,qQ3oR7maZGeFByA6uitjrd,wltPGJcYo12Ed in K0MwVeCGOmJho:
		items = QPuHKNAT4jmCRg.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('data-rate="(.*?)".*?<em>(.*?)</em>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			items = []
			for wMq2UBSjsfgchHzprXWFOTdn5,pp8iHB3W9Cs in eIXD9Ql3JREsm4WvKc: items.append([wMq2UBSjsfgchHzprXWFOTdn5,'',pp8iHB3W9Cs])
			qQ3oR7maZGeFByA6uitjrd = 'rate'
			name = 'التقييم'
		else: qQ3oR7maZGeFByA6uitjrd = items[0][1]
		if '==' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='CATEGORIES':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<=1:
				if qQ3oR7maZGeFByA6uitjrd==fugkyUNWIJGSslwLzx[-1]: SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'CATEGORIES___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				MPfKjlDAZTV6 = AsOwHTp3NU1bgGLoa7cCWeSX8h(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				if qQ3oR7maZGeFByA6uitjrd==fugkyUNWIJGSslwLzx[-1]: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع ',MPfKjlDAZTV6,251,'','','filters')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,254,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='FILTERS':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&&'+qQ3oR7maZGeFByA6uitjrd+'==0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&&'+qQ3oR7maZGeFByA6uitjrd+'==0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع :'+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,255,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for wMq2UBSjsfgchHzprXWFOTdn5,aaxAKWtMwfPRE4zbqSQCOrBms0,pp8iHB3W9Cs in items:
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			if 'الكل' in wMq2UBSjsfgchHzprXWFOTdn5: continue
			wMq2UBSjsfgchHzprXWFOTdn5 = UH1IuvwM9e4cl7if63nNdozJFSj(wMq2UBSjsfgchHzprXWFOTdn5)
			gH8mavstuiyE6RY2,nUbpaNT0vhcj7ZsEz = wMq2UBSjsfgchHzprXWFOTdn5,wMq2UBSjsfgchHzprXWFOTdn5
			nUbpaNT0vhcj7ZsEz = name+': '+gH8mavstuiyE6RY2
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = nUbpaNT0vhcj7ZsEz
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&&'+qQ3oR7maZGeFByA6uitjrd+'=='+gH8mavstuiyE6RY2
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&&'+qQ3oR7maZGeFByA6uitjrd+'=='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			if type=='FILTERS':
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,url,255,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='CATEGORIES' and fugkyUNWIJGSslwLzx[-2]+'==' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'modified_filters')
				lc154VhT9DCqMk8 = url+'//getposts??'+sJxYKGW7VODHcn0o4UBZkAtEMe
				MPfKjlDAZTV6 = AsOwHTp3NU1bgGLoa7cCWeSX8h(lc154VhT9DCqMk8)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,MPfKjlDAZTV6,251,'','','filters')
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,url,254,'','',q0NkUvatj1HcndbF9Yrsw)
	return
fugkyUNWIJGSslwLzx = ['category','country','release-year']
MNI2UuX0ODVBeKx9H37nJW = ['category','country','genre','release-year','language','quality','rate']
def AsOwHTp3NU1bgGLoa7cCWeSX8h(url):
	zKlehEfyZ6i9tQVq7 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',zKlehEfyZ6i9tQVq7)
	url = url.replace('/category/اخرى','')
	if zKlehEfyZ6i9tQVq7 not in url: url = url+zKlehEfyZ6i9tQVq7
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&&')
	XTiOm8cUEJCh3ryql,VAlPewLIfoQv6dash = {},''
	if '==' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('==')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	for key in MNI2UuX0ODVBeKx9H37nJW:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&&'+key+'=='+pp8iHB3W9Cs
		elif mode=='all': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&&'+key+'=='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&&')
	return VAlPewLIfoQv6dash
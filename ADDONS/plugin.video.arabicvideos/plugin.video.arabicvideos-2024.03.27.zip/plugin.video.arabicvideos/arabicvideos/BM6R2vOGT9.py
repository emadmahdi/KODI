# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'MOVS4U'
JE7QrkmhletLwA0OZXu = '_M4U_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['انواع افلام','جودات افلام']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==380: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==381: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==382: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==383: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==389: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المميزة',GqcEfFR8XQPgBMLr,381,'','','featured')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الجانبية',GqcEfFR8XQPgBMLr,381,'','','sider')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','MOVS4U-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = QPuHKNAT4jmCRg.findall('<header>.*?<h2>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for HY6PBsZvlUTGOW5eXcVnt27Ioi1 in range(len(items)):
		title = items[HY6PBsZvlUTGOW5eXcVnt27Ioi1]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,GqcEfFR8XQPgBMLr,381,'','','latest'+str(HY6PBsZvlUTGOW5eXcVnt27Ioi1))
	wltPGJcYo12Ed = ''
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="menu"(.*?)id="contenedor"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb: wltPGJcYo12Ed += TTCRYZroizb[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="sidebar(.*?)aside',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb: wltPGJcYo12Ed += TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IP2cvAkDs87K9RjquUf60Xxy4e1d = True
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if title=='الأعلى مشاهدة':
			if IP2cvAkDs87K9RjquUf60Xxy4e1d:
				title = 'الافلام '+title
				IP2cvAkDs87K9RjquUf60Xxy4e1d = False
			else: title = 'المسلسلات '+title
		if title not in EhRQ8zB1fdkj5vN6HlmqD7SOU:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,381)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,type):
	wltPGJcYo12Ed,items = [],[]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','MOVS4U-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if type=='search':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="search-page"(.*?)class="sidebar',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='sider':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="widget(.*?)class="widget',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		f85jANZg0iD4JravVm = QPuHKNAT4jmCRg.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		LL8heV7kxYI5bOjEZ6XaUQWwfPA,cR4vMuiDFYW9LOXHt7xqg,xitERh4TD2jGJPq5Nuv39CAmg = zip(*f85jANZg0iD4JravVm)
		items = zip(cR4vMuiDFYW9LOXHt7xqg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,xitERh4TD2jGJPq5Nuv39CAmg)
	elif type=='featured':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="slider-movies-tvshows"(.*?)<header>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif 'latest' in type:
		HY6PBsZvlUTGOW5eXcVnt27Ioi1 = int(type[-1:])
		Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('<header>','<end><start>')
		Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('<div class="sidebar','<end><div class="sidebar')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<start>(.*?)<end>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[HY6PBsZvlUTGOW5eXcVnt27Ioi1]
		if HY6PBsZvlUTGOW5eXcVnt27Ioi1==2: items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="content"(.*?)class="(pagination|sidebar)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0][0]
			if '/collection/' in url:
				items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			elif '/quality/' in url:
				items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if not items and wltPGJcYo12Ed:
		items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		if 'serie' in title:
			title = QPuHKNAT4jmCRg.findall('^(.*?)<.*?serie">(.*?)<',title,QPuHKNAT4jmCRg.DOTALL)
			title = title[0][1]
			if title in gltHFKTroJfpLe: continue
			gltHFKTroJfpLe.append(title)
			title = '_MOD_'+title
		nUbpaNT0vhcj7ZsEz = QPuHKNAT4jmCRg.findall('^(.*?)<',title,QPuHKNAT4jmCRg.DOTALL)
		if nUbpaNT0vhcj7ZsEz: title = nUbpaNT0vhcj7ZsEz[0]
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if '/tvshows/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,383,G2WR0Oacvdq8ZQTjKboDU)
		elif '/episodes/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,383,G2WR0Oacvdq8ZQTjKboDU)
		elif '/seasons/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,383,G2WR0Oacvdq8ZQTjKboDU)
		elif '/collection/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,381,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,382,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		XczYfUoGHM60pFlNLDtEiAgW = TTCRYZroizb[0][0]
		QgHLxpimcYa2 = TTCRYZroizb[0][1]
		wltPGJcYo12Ed = TTCRYZroizb[0][2]
		items = QPuHKNAT4jmCRg.findall("href='(.*?)'.*?>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title=='' or title==QgHLxpimcYa2: continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,381,'','',type)
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('/page/'+title+'/','/page/'+QgHLxpimcYa2+'/')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اخر صفحة '+QgHLxpimcYa2,VV7yf2htDCBU6EeSX8TJQM,381,'','',type)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('class="C rated".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy,False):
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('''class='item'><a href="(.*?)"''',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[1]
			opLlxOB2dUVZ5JF4j(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
			return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('''class='episodios'(.*?)id="cast"''',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for G2WR0Oacvdq8ZQTjKboDU,CiZxgXTGW9pv,VV7yf2htDCBU6EeSX8TJQM,name in items:
			title = CiZxgXTGW9pv+' : '+name+' الحلقة'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,382)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','MOVS4U-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('class="C rated".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0][0]
		items = QPuHKNAT4jmCRg.findall("data-url='(.*?)'.*?class='server'>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="remodal"(.*?)class="remodal-close"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/?s='+search
	SPFl6UGK4mrBua(url,'search')
	return
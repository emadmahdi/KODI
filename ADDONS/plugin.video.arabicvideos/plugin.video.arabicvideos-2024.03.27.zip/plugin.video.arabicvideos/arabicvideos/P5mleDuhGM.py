# -*- coding: utf-8 -*-
import sys as GJtcqTv68ZQpwxYFiDg
yyIoQrPWR1B = GJtcqTv68ZQpwxYFiDg.version_info [0] == 2
Duhwt2HMRTeBonVic0lz8bjUJ = 2048
BnAMltLNqzHfjxWkVi9eb3P = 7
def rrgVqwDZPsMjxvR3EylNz9 (tbA2GsXVSDNgm):
	global lzR5Gp9sjoDwb
	BZb90tzYkgeu3pcAo = ord (tbA2GsXVSDNgm [-1])
	fdK96q2bHgSIwE = tbA2GsXVSDNgm [:-1]
	klvdJbzV7PEMciQ61A0t25SGXq8 = BZb90tzYkgeu3pcAo % len (fdK96q2bHgSIwE)
	q5yMKdNsYpzDj8Oo = fdK96q2bHgSIwE [:klvdJbzV7PEMciQ61A0t25SGXq8] + fdK96q2bHgSIwE [klvdJbzV7PEMciQ61A0t25SGXq8:]
	if yyIoQrPWR1B:
		hq2Yj5TvMOKsRFroabWu = unicode () .join ([unichr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	else:
		hq2Yj5TvMOKsRFroabWu = str () .join ([chr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	return eval (hq2Yj5TvMOKsRFroabWu)
iRTygNp4Lf36wQKlD2MHUhG7B,KbL94nDHufSF0VcO2Nk3,qNZKwi2M1S4fBzGQYrmPnea=rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9
xxpPYJOnoAUrlBzyveui,ldOGfm56kWs8T03wcptQunqEUBDrvC,Arg2GFJDt3emTvpO6fZkSVdaUHywnN=qNZKwi2M1S4fBzGQYrmPnea,KbL94nDHufSF0VcO2Nk3,iRTygNp4Lf36wQKlD2MHUhG7B
v7reLlOXCgD5pZ14w2tUA,p1lrNRIXqLQJznH6O,ddK4MmwpX5oG=Arg2GFJDt3emTvpO6fZkSVdaUHywnN,ldOGfm56kWs8T03wcptQunqEUBDrvC,xxpPYJOnoAUrlBzyveui
OARzhnB9o7uYvQGFaIcZ,ZpH2IWt7veyFobTsAnhi41,q0JfWbP8vACLxSNIncpOXkR6j=ddK4MmwpX5oG,p1lrNRIXqLQJznH6O,v7reLlOXCgD5pZ14w2tUA
L91nVzxH4hYrgPDsOuljXd0J,uhOkAKtLVv4XTy1nWE6,d1JiVThqEO0nBaY2QRNyZxlujWw7SK=q0JfWbP8vACLxSNIncpOXkR6j,ZpH2IWt7veyFobTsAnhi41,OARzhnB9o7uYvQGFaIcZ
V391t7nQWUBR5euCkJ,IJ6VkihabRm,lunVJF2G5bZMgTcCje0vaIB371SX=d1JiVThqEO0nBaY2QRNyZxlujWw7SK,uhOkAKtLVv4XTy1nWE6,L91nVzxH4hYrgPDsOuljXd0J
xxBJoKG54uwQ,gr5K72RtvAZYPVwkdnspbzQWNjEI,u1ml5XcLiZ7oDPs3UjedgpYHhfV=lunVJF2G5bZMgTcCje0vaIB371SX,IJ6VkihabRm,V391t7nQWUBR5euCkJ
dxAs4otSE98YmZnKy2iwRCB,fcIm8tvxlXZsaEY3bwuG4B,f8PVRTseIuj9BckO6GoyF5Lxv=u1ml5XcLiZ7oDPs3UjedgpYHhfV,gr5K72RtvAZYPVwkdnspbzQWNjEI,xxBJoKG54uwQ
tKVplxqYIdngGF6TZkXeb2PiwfME,vkMRnTNV9jFm,HMO0QciekqVpLKmA=f8PVRTseIuj9BckO6GoyF5Lxv,fcIm8tvxlXZsaEY3bwuG4B,dxAs4otSE98YmZnKy2iwRCB
DKqQekNtF6WlJLhBP9M5ca,GGTRaYBDeNyI25zlF,Vv0lSjAOHLfMnam3wtdor=HMO0QciekqVpLKmA,vkMRnTNV9jFm,tKVplxqYIdngGF6TZkXeb2PiwfME
a06i2XFf3oBnDrJQZEKmHpqY9ACW,DDS79jdWzLtE,zOZvXaebGNwHKfjRA=Vv0lSjAOHLfMnam3wtdor,GGTRaYBDeNyI25zlF,DKqQekNtF6WlJLhBP9M5ca
import xbmc as AAsbUG0jZ5igBpNKQwFrJTd,re as QPuHKNAT4jmCRg,sys as GJtcqTv68ZQpwxYFiDg,xbmcaddon as x1KknCETNQp,random as KRjfaduUhzsPg6I1,os as YcJmC0W43u5idIELnHTU2XSsMPNt,xbmcvfs as NuU4yWvdlP08,time as vODi7LQeCnUaoRqZX9xs6djwm0tJA2,pickle as g1gmtbGkrcOVJU2QehTqsBjWzX,zlib as j7C3kwg1ob,xbmcgui as yOuHBDmPps3vd24cnLagiK0,xbmcplugin as LL2eGTPdkm,sqlite3 as csXRAak0iZIKQpfu1o,traceback as BOYy8o0JEr9gHKLakhbjTRd4Z5zD,threading as nt0ApgWuodKimeTxcNVLEs4U
mm5vCBc4DOz2Fj = q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
o76CsefkuZhcgDJlX = x1KknCETNQp.Addon().getAddonInfo(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬࡶࡡࡵࡪࠪ਱"))
ndtxzvNSbc = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,HMO0QciekqVpLKmA(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
GJtcqTv68ZQpwxYFiDg.path.append(ndtxzvNSbc)
Qk3Eo8cXgASw = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(xxBJoKG54uwQ(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
LRjqrQYBXFVPfu = QPuHKNAT4jmCRg.findall(V391t7nQWUBR5euCkJ(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),Qk3Eo8cXgASw,QPuHKNAT4jmCRg.DOTALL)
LRjqrQYBXFVPfu = float(LRjqrQYBXFVPfu[vkMRnTNV9jFm(u"࠱௴")])
wAiQRoBe2rypsq0H = AAsbUG0jZ5igBpNKQwFrJTd.Player
ocbOeyJvrhusDq72ZU4FmA = yOuHBDmPps3vd24cnLagiK0.WindowXMLDialog
rx3QcG7naDzKw5m6uJBq4H1AYZkdNM = LRjqrQYBXFVPfu<v7reLlOXCgD5pZ14w2tUA(u"࠳࠼௵")
Nnxm30dfoBWRYpIC7KsQGl = LRjqrQYBXFVPfu>ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠴࠼࠳࠿࠹௶")
if Nnxm30dfoBWRYpIC7KsQGl:
	poC83EY9uswHTeZrcD74VS1N = AAsbUG0jZ5igBpNKQwFrJTd.LOGINFO
	Pc98uK2GLvfMwq6UtyJSHe03g,lc6sH83woipUCaLnRVAkgtrEJd257 = xxpPYJOnoAUrlBzyveui(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),Vv0lSjAOHLfMnam3wtdor(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	uIjODTU1eqN9cd = NuU4yWvdlP08.translatePath(ddK4MmwpX5oG(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _2zJ7exSmQ4gjKBV9iaMEPU
else:
	poC83EY9uswHTeZrcD74VS1N = AAsbUG0jZ5igBpNKQwFrJTd.LOGNOTICE
	Pc98uK2GLvfMwq6UtyJSHe03g,lc6sH83woipUCaLnRVAkgtrEJd257 = IJ6VkihabRm(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(Vv0lSjAOHLfMnam3wtdor(u"࠭ࡵࡵࡨ࠻ࠫਹ")),Vv0lSjAOHLfMnam3wtdor(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(uhOkAKtLVv4XTy1nWE6(u"ࠨࡷࡷࡪ࠽࠭਻"))
	uIjODTU1eqN9cd = AAsbUG0jZ5igBpNKQwFrJTd.translatePath(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _2zJ7exSmQ4gjKBV9iaMEPU
Y2p641aldEnVtSgJAjs7 = fcIm8tvxlXZsaEY3bwuG4B(u"࠺࠵௷")
PVQeMKFimjdzY1OTqab = f8PVRTseIuj9BckO6GoyF5Lxv(u"࠻࠶௸")*Y2p641aldEnVtSgJAjs7
PLYNXBn8djb = q0JfWbP8vACLxSNIncpOXkR6j(u"࠸࠴௹")*PVQeMKFimjdzY1OTqab
dGkwSCPJt94LEINY0boARyVrWHf = p1lrNRIXqLQJznH6O(u"࠳࠱௺")*PLYNXBn8djb
vfj1VHSBpIks9JhLGmr = V391t7nQWUBR5euCkJ(u"࠱௻")
ooDaNCkx4c0FjJs = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵࠳௼")*Y2p641aldEnVtSgJAjs7
oXSZ6AEbPukBvwKmyarstdWR5qz0 = dxAs4otSE98YmZnKy2iwRCB(u"࠵௽")*PVQeMKFimjdzY1OTqab
t7rXIzJfMLWRwaDeKhTq4C6dG = DDS79jdWzLtE(u"࠵࠻௾")*PVQeMKFimjdzY1OTqab
lu4xpkY5LFOm6t2In = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠸௿")*PLYNXBn8djb
kkvBdWcON7RZoMJDr0YjmLE1 = f8PVRTseIuj9BckO6GoyF5Lxv(u"࠹࠰ఀ")*PLYNXBn8djb
VYn9o683LCcspE7Jew5gMQrZbj = q0JfWbP8vACLxSNIncpOXkR6j(u"࠱࠳ఁ")*dGkwSCPJt94LEINY0boARyVrWHf
iiKkCMqUwSWmAvcQ1YpT69l = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠲ం")*PVQeMKFimjdzY1OTqab
M0J6Pq3bH2 = GJtcqTv68ZQpwxYFiDg.argv[GGTRaYBDeNyI25zlF(u"࠲ః")].split(v7reLlOXCgD5pZ14w2tUA(u"ࠪ࠳ࠬ਽"))[qNZKwi2M1S4fBzGQYrmPnea(u"࠵ఄ")]
EhfrVPICebQ = int(GJtcqTv68ZQpwxYFiDg.argv[v7reLlOXCgD5pZ14w2tUA(u"࠵అ")])
a4EuYDiRdrA = GJtcqTv68ZQpwxYFiDg.argv[Vv0lSjAOHLfMnam3wtdor(u"࠷ఆ")]
sipwxAND14h8CKlBQ6ycnHWf5k = M0J6Pq3bH2.split(p1lrNRIXqLQJznH6O(u"ࠫ࠳࠭ਾ"))[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠸ఇ")]
uVp7krjL48oWd3tqGYCRz5M = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(OARzhnB9o7uYvQGFaIcZ(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+M0J6Pq3bH2+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠩࠨੀ"))
vBXJAQCwEpS0xZ6km9a = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(uIjODTU1eqN9cd,M0J6Pq3bH2)
oorOICHY4MvRsWg1Xk8 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
PPgJ3en0yKYWdzMAmCON1DTQG9 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
Low1uSVG5OcafJmrYBC7D = int(vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time())
fQ6kvwg1FrYAzXjbLT = x1KknCETNQp.Addon(id=M0J6Pq3bH2)
def Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(DDRulV7aKN3jCOWSBQkb95,JJGN7qxBnbcP=zOZvXaebGNwHKfjRA(u"ࠩࡂࠫ੃")):
	if L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡁࠬ੄") in DDRulV7aKN3jCOWSBQkb95:
		if JJGN7qxBnbcP in DDRulV7aKN3jCOWSBQkb95: lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ZGAKxHTX1t = DDRulV7aKN3jCOWSBQkb95.split(JJGN7qxBnbcP,iRTygNp4Lf36wQKlD2MHUhG7B(u"࠱ఈ"))
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ZGAKxHTX1t = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࠬ੅"),DDRulV7aKN3jCOWSBQkb95
		ZGAKxHTX1t = ZGAKxHTX1t.split(xxpPYJOnoAUrlBzyveui(u"ࠬࠬࠧ੆"))
		BF8XfchlgKmOE0ru2 = {}
		for gBU7t4bhYTFjrW13f in ZGAKxHTX1t:
			SonE0wpbWDiYV,ccgnvJDbLi3FuVKNdM6Ea = gBU7t4bhYTFjrW13f.split(xxBJoKG54uwQ(u"࠭࠽ࠨੇ"),Vv0lSjAOHLfMnam3wtdor(u"࠲ఉ"))
			BF8XfchlgKmOE0ru2[SonE0wpbWDiYV] = ccgnvJDbLi3FuVKNdM6Ea
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = DDRulV7aKN3jCOWSBQkb95,{}
	return lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2
def NdVvO42riJpCWElX(DDRulV7aKN3jCOWSBQkb95):
	return _2zJ7exSmQ4gjKBV9iaMEPU(DDRulV7aKN3jCOWSBQkb95)
def JJqxTSR6tZiQ79cpkwa3GMy(fhRC4eEvzgV1nK38oGqJIb60ZLdw):
	UUGdnSsDm0IuB7 = {p1lrNRIXqLQJznH6O(u"ࠧࡵࡻࡳࡩࠬੈ"):ddK4MmwpX5oG(u"ࠨࠩ੉"),xxBJoKG54uwQ(u"ࠩࡰࡳࡩ࡫ࠧ੊"):iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࠫੋ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡺࡸ࡬ࠨੌ"):iRTygNp4Lf36wQKlD2MHUhG7B(u"੍ࠬ࠭"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡴࡦࡺࡷࠫ੎"):Vv0lSjAOHLfMnam3wtdor(u"ࠧࠨ੏"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡲࡤ࡫ࡪ࠭੐"):Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࠪੑ"),v7reLlOXCgD5pZ14w2tUA(u"ࠪࡲࡦࡳࡥࠨ੒"):dxAs4otSE98YmZnKy2iwRCB(u"ࠫࠬ੓"),Vv0lSjAOHLfMnam3wtdor(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧ੕"),xxBJoKG54uwQ(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠩ੗"),dxAs4otSE98YmZnKy2iwRCB(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):KbL94nDHufSF0VcO2Nk3(u"ࠪࠫਖ਼")}
	if GGTRaYBDeNyI25zlF(u"ࠫࡄ࠭ਗ਼") in fhRC4eEvzgV1nK38oGqJIb60ZLdw: fhRC4eEvzgV1nK38oGqJIb60ZLdw = fhRC4eEvzgV1nK38oGqJIb60ZLdw.split(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࡅࠧਜ਼"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠳ఊ"))[d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠳ఊ")]
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,F6v9cwip5UDLhB2QVf8AGt = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(fhRC4eEvzgV1nK38oGqJIb60ZLdw)
	aargs = dict(list(UUGdnSsDm0IuB7.items())+list(F6v9cwip5UDLhB2QVf8AGt.items()))
	yc8hfeRS3AaQTjYNHgZxF4bMPuw = aargs[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭࡭ࡰࡦࡨࠫੜ")]
	KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp = NdVvO42riJpCWElX(aargs[ddK4MmwpX5oG(u"ࠧࡶࡴ࡯ࠫ੝")])
	vFbKkHaJMXBA7jOL860 = NdVvO42riJpCWElX(aargs[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	HG0vEntrbRUK4ZTNx = NdVvO42riJpCWElX(aargs[Vv0lSjAOHLfMnam3wtdor(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	wwZo35QLF2NKnChmkx = NdVvO42riJpCWElX(aargs[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡸࡾࡶࡥࠨ੠")])
	CuiSrRzIOtfqKX2FPVoAcELM9gv70J = NdVvO42riJpCWElX(aargs[lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	j6UVYSdO2Qy134nlvK = NdVvO42riJpCWElX(aargs[OARzhnB9o7uYvQGFaIcZ(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	wwQ2RT0B6kXoUznKEAgMcd = aargs[IJ6VkihabRm(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	gnrxOC2NAbLa1K0iXSlTzhVZqw = NdVvO42riJpCWElX(aargs[dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if gnrxOC2NAbLa1K0iXSlTzhVZqw: gnrxOC2NAbLa1K0iXSlTzhVZqw = eval(gnrxOC2NAbLa1K0iXSlTzhVZqw)
	else: gnrxOC2NAbLa1K0iXSlTzhVZqw = {}
	if not yc8hfeRS3AaQTjYNHgZxF4bMPuw: wwZo35QLF2NKnChmkx = OARzhnB9o7uYvQGFaIcZ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; yc8hfeRS3AaQTjYNHgZxF4bMPuw = vkMRnTNV9jFm(u"ࠩ࠵࠺࠵࠭੦")
	return wwZo35QLF2NKnChmkx,CuiSrRzIOtfqKX2FPVoAcELM9gv70J,KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp,yc8hfeRS3AaQTjYNHgZxF4bMPuw,j6UVYSdO2Qy134nlvK,HG0vEntrbRUK4ZTNx,vFbKkHaJMXBA7jOL860,wwQ2RT0B6kXoUznKEAgMcd,gnrxOC2NAbLa1K0iXSlTzhVZqw
def Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj):
	kD17l8sUAxMO = GJtcqTv68ZQpwxYFiDg._getframe(zOZvXaebGNwHKfjRA(u"࠴ఋ")).f_code.co_name
	if not mm5vCBc4DOz2Fj or not kD17l8sUAxMO or kD17l8sUAxMO==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࡠࠦࠧ੨")+sipwxAND14h8CKlBQ6ycnHWf5k.upper()+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬ࠳ࠧ੩")+uVp7krjL48oWd3tqGYCRz5M+HMO0QciekqVpLKmA(u"࠭࠭ࠨ੪")+str(LRjqrQYBXFVPfu)+DKqQekNtF6WlJLhBP9M5ca(u"ࠧࠡ࡟ࠪ੫")
	return ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨ࠰ࠣࠤࠬ੬")+kD17l8sUAxMO
def zRM3tZx2v6DjJU(nvif7hoWbCSzyuYk,hTZjiRxwmYoWpKtJIHVug36G):
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: hTZjiRxwmYoWpKtJIHVug36G = hTZjiRxwmYoWpKtJIHVug36G.decode(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	zZtsFLV6ajMflRCO = poC83EY9uswHTeZrcD74VS1N
	I7Q0GxoOc5ECkY6zfjhg = [DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠬ੯"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬ࠭ੰ")]
	if nvif7hoWbCSzyuYk: hTZjiRxwmYoWpKtJIHVug36G = hTZjiRxwmYoWpKtJIHVug36G.replace(ddK4MmwpX5oG(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),vkMRnTNV9jFm(u"ࠧࠨੲ")).replace(xxpPYJOnoAUrlBzyveui(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠩࠪੴ")).replace(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),v7reLlOXCgD5pZ14w2tUA(u"ࠫࠬ੶"))
	else: nvif7hoWbCSzyuYk = ZpH2IWt7veyFobTsAnhi41(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	Th9uD8biZGHB1d3,JJGN7qxBnbcP,omcSni5PCOIezt = ZpH2IWt7veyFobTsAnhi41(u"࠭ࠠࠡࠢࠣࠫ੸"),KbL94nDHufSF0VcO2Nk3(u"ࠧࠡࠢࠣࠫ੹"),xxBJoKG54uwQ(u"ࠨࠩ੺")
	if L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in nvif7hoWbCSzyuYk: zZtsFLV6ajMflRCO = AAsbUG0jZ5igBpNKQwFrJTd.LOGERROR
	if nvif7hoWbCSzyuYk==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		hTZjiRxwmYoWpKtJIHVug36G = hTZjiRxwmYoWpKtJIHVug36G+JJGN7qxBnbcP
		I7Q0GxoOc5ECkY6zfjhg = hTZjiRxwmYoWpKtJIHVug36G.split(JJGN7qxBnbcP)
		omcSni5PCOIezt = Th9uD8biZGHB1d3
	elif nvif7hoWbCSzyuYk==p1lrNRIXqLQJznH6O(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		hTZjiRxwmYoWpKtJIHVug36G = hTZjiRxwmYoWpKtJIHVug36G.replace(OARzhnB9o7uYvQGFaIcZ(u"ࠬ࠴ࠧ੾")+JJGN7qxBnbcP,vkMRnTNV9jFm(u"࠭࠮ࠡࠢࠪ੿"))
		I7Q0GxoOc5ECkY6zfjhg = hTZjiRxwmYoWpKtJIHVug36G.split(JJGN7qxBnbcP)
		I7Q0GxoOc5ECkY6zfjhg[V391t7nQWUBR5euCkJ(u"࠵఍")] = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࠯ࠩ઀")+I7Q0GxoOc5ECkY6zfjhg[V391t7nQWUBR5euCkJ(u"࠵఍")][xxpPYJOnoAUrlBzyveui(u"࠵ఌ"):]
		omcSni5PCOIezt = Th9uD8biZGHB1d3+JJGN7qxBnbcP
	elif nvif7hoWbCSzyuYk in [L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡈࡖࡗࡕࡒࠨં")]: I7Q0GxoOc5ECkY6zfjhg = hTZjiRxwmYoWpKtJIHVug36G.split(Th9uD8biZGHB1d3)
	omcSni5PCOIezt += v7reLlOXCgD5pZ14w2tUA(u"࠼ఎ")*Th9uD8biZGHB1d3
	XIgQ20RO8lbhNZms = xxpPYJOnoAUrlBzyveui(u"࠳ఏ")*Th9uD8biZGHB1d3
	if LRjqrQYBXFVPfu>OARzhnB9o7uYvQGFaIcZ(u"࠳࠺࠲࠾࠿఑"): omcSni5PCOIezt += DKqQekNtF6WlJLhBP9M5ca(u"࠲࠳ఐ")*tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࠤࠬઃ")
	ZQkTPN6q1G32BuMoac0 = I7Q0GxoOc5ECkY6zfjhg[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳ఒ")]
	for dJEmG7MFDQfxks9 in I7Q0GxoOc5ECkY6zfjhg[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠵ఓ"):]:
		if HMO0QciekqVpLKmA(u"ࠫࡡࡴࠧ઄") in dJEmG7MFDQfxks9: dJEmG7MFDQfxks9 = dJEmG7MFDQfxks9.replace(V391t7nQWUBR5euCkJ(u"ࠬࡢ࡮ࠨઅ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭࡜࡯ࠩઆ")+Th9uD8biZGHB1d3+Th9uD8biZGHB1d3)
		XIgQ20RO8lbhNZms += Th9uD8biZGHB1d3
		ZQkTPN6q1G32BuMoac0 += DKqQekNtF6WlJLhBP9M5ca(u"ࠧ࡝ࡴࠪઇ")+omcSni5PCOIezt+XIgQ20RO8lbhNZms+dJEmG7MFDQfxks9
	ZQkTPN6q1G32BuMoac0 += xxBJoKG54uwQ(u"ࠨࠢࡢࠫઈ")
	if IJ6VkihabRm(u"ࠩࠨࠫઉ") in ZQkTPN6q1G32BuMoac0: ZQkTPN6q1G32BuMoac0 = NdVvO42riJpCWElX(ZQkTPN6q1G32BuMoac0)
	AAsbUG0jZ5igBpNKQwFrJTd.log(ZQkTPN6q1G32BuMoac0,level=zZtsFLV6ajMflRCO)
	return
def ssVj9vLP2FS(RJpWL3qSwhg):
	qcOU43biDkaPQlZMB1wHEj = csXRAak0iZIKQpfu1o.connect(RJpWL3qSwhg)
	K2DlNXvQC65FzngUVyk3IGAq = qcOU43biDkaPQlZMB1wHEj.cursor()
	K2DlNXvQC65FzngUVyk3IGAq.execute(DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(DDS79jdWzLtE(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(p1lrNRIXqLQJznH6O(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(V391t7nQWUBR5euCkJ(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(xxpPYJOnoAUrlBzyveui(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	qcOU43biDkaPQlZMB1wHEj.text_factory = str
	return qcOU43biDkaPQlZMB1wHEj,K2DlNXvQC65FzngUVyk3IGAq
def QUydweutaN3vRfhF4qVk2P5W8BLJic(RJpWL3qSwhg,uzyCvaxZ5w6AKbg2MpOm4qV7EhR,BBEzmaH9MTeSLcNrwiqj1ds=None):
	try: qcOU43biDkaPQlZMB1wHEj,K2DlNXvQC65FzngUVyk3IGAq = ssVj9vLP2FS(RJpWL3qSwhg)
	except: return
	if BBEzmaH9MTeSLcNrwiqj1ds==None: K2DlNXvQC65FzngUVyk3IGAq.execute(L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+vkMRnTNV9jFm(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		s3THEqb70mYa1oXlVid = (str(BBEzmaH9MTeSLcNrwiqj1ds),)
		try:
			if GGTRaYBDeNyI25zlF(u"ࠫࠪ࠭઒") in BBEzmaH9MTeSLcNrwiqj1ds: K2DlNXvQC65FzngUVyk3IGAq.execute(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+DDS79jdWzLtE(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),s3THEqb70mYa1oXlVid)
			else: K2DlNXvQC65FzngUVyk3IGAq.execute(qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+DKqQekNtF6WlJLhBP9M5ca(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),s3THEqb70mYa1oXlVid)
		except: pass
	qcOU43biDkaPQlZMB1wHEj.commit()
	qcOU43biDkaPQlZMB1wHEj.close()
	return
class vwMoEtJj2hZ4OC1T5HBVYRDx(): pass
class HcLv5k0Ey9FG(vwMoEtJj2hZ4OC1T5HBVYRDx):
	def __init__(DD7zNq8ivSuIxpeM):
		DD7zNq8ivSuIxpeM.url = Vv0lSjAOHLfMnam3wtdor(u"ࠩࠪગ")
		DD7zNq8ivSuIxpeM.code = -OARzhnB9o7uYvQGFaIcZ(u"࠾࠿ఔ")
		DD7zNq8ivSuIxpeM.reason = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࠫઘ")
		DD7zNq8ivSuIxpeM.content = Vv0lSjAOHLfMnam3wtdor(u"ࠫࠬઙ")
		DD7zNq8ivSuIxpeM.headers = {}
		DD7zNq8ivSuIxpeM.cookies = {}
		DD7zNq8ivSuIxpeM.succeeded = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࡆࡢ࡮ࡶࡩ౜")
def ooqE7AfbkuxB36MYaPp(xEc7nR3qoAlv6C8YjD):
	if xEc7nR3qoAlv6C8YjD==DDS79jdWzLtE(u"ࠬࡪࡩࡤࡶࠪચ"): ZEJAFRNxIrQSU = {}
	elif xEc7nR3qoAlv6C8YjD==HMO0QciekqVpLKmA(u"࠭࡬ࡪࡵࡷࠫછ"): ZEJAFRNxIrQSU = []
	elif xEc7nR3qoAlv6C8YjD==DDS79jdWzLtE(u"ࠧࡴࡶࡵࠫજ"): ZEJAFRNxIrQSU = DDS79jdWzLtE(u"ࠨࠩઝ")
	elif xEc7nR3qoAlv6C8YjD==zOZvXaebGNwHKfjRA(u"ࠩ࡬ࡲࡹ࠭ઞ"): ZEJAFRNxIrQSU = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠶క")
	elif xEc7nR3qoAlv6C8YjD==L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): ZEJAFRNxIrQSU = HcLv5k0Ey9FG()
	elif not xEc7nR3qoAlv6C8YjD: ZEJAFRNxIrQSU = None
	else: ZEJAFRNxIrQSU = None
	return ZEJAFRNxIrQSU
def x9N7DKVT1rjsPmlieqQ8HJgU(BV3NOAo4zfqbkDv08Gh7MT):
	from hashlib import md5 as uIVUl3LvOfkK2NoGzq
	AAFI3nBZOt4zwK9MRh1 = fQ6kvwg1FrYAzXjbLT.getSetting(zOZvXaebGNwHKfjRA(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ઠ"))
	vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8 = Dx3jCK6X7lktdiE(Vv0lSjAOHLfMnam3wtdor(u"࠳࠳ఖ")).splitlines()
	iVTGzt1quQHnUMdKyewS = OARzhnB9o7uYvQGFaIcZ(u"࠱గ")
	for eYiGSpVwz2h1AIj in [Low1uSVG5OcafJmrYBC7D,Low1uSVG5OcafJmrYBC7D-oXSZ6AEbPukBvwKmyarstdWR5qz0]:
		DKqFLsl2d4N3iBXU9OHjunoW = str(eYiGSpVwz2h1AIj*Vv0lSjAOHLfMnam3wtdor(u"࠵࠵࠶࠰࠱࠲࠱࠴చ")/fcIm8tvxlXZsaEY3bwuG4B(u"࠷࠷࠷࠶࠰࠱ఙ"))[v7reLlOXCgD5pZ14w2tUA(u"࠲ఘ"):xxpPYJOnoAUrlBzyveui(u"࠹ఛ")]
		if DKqFLsl2d4N3iBXU9OHjunoW!=iVTGzt1quQHnUMdKyewS:
			for C12v5SKmRuhbzLFndAjW0g in vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8:
				tU0SnTRsDHJ9qQkMbo4Wc = fcIm8tvxlXZsaEY3bwuG4B(u"ࠬ࡞࠱࠺ࠩડ")+BV3NOAo4zfqbkDv08Gh7MT+fcIm8tvxlXZsaEY3bwuG4B(u"࠭࠱࠹࠿ࠪઢ")+C12v5SKmRuhbzLFndAjW0g[-HMO0QciekqVpLKmA(u"࠸࠴జ"):]+uVp7krjL48oWd3tqGYCRz5M+DKqFLsl2d4N3iBXU9OHjunoW
				tU0SnTRsDHJ9qQkMbo4Wc = uIVUl3LvOfkK2NoGzq(tU0SnTRsDHJ9qQkMbo4Wc.encode(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:uhOkAKtLVv4XTy1nWE6(u"࠳࠳ఝ")]
				if tU0SnTRsDHJ9qQkMbo4Wc in AAFI3nBZOt4zwK9MRh1: return gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࡕࡴࡸࡩౝ")
			iVTGzt1quQHnUMdKyewS = DKqFLsl2d4N3iBXU9OHjunoW
	return tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡈࡤࡰࡸ࡫౞")
def C2GD7eO9f6tEjiPuW4xVLv1QH30nh(RJpWL3qSwhg,w3G0OiS6kCvADZm7FnRbYe5,uzyCvaxZ5w6AKbg2MpOm4qV7EhR,BBEzmaH9MTeSLcNrwiqj1ds=None):
	ZEJAFRNxIrQSU = ooqE7AfbkuxB36MYaPp(w3G0OiS6kCvADZm7FnRbYe5)
	b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX = fQ6kvwg1FrYAzXjbLT.getSetting(DDS79jdWzLtE(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if uzyCvaxZ5w6AKbg2MpOm4qV7EhR!=d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and RJpWL3qSwhg==oorOICHY4MvRsWg1Xk8:
		if b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX==lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡗ࡙ࡕࡐࠨદ"): return ZEJAFRNxIrQSU
		PqREL0OwgzB = fQ6kvwg1FrYAzXjbLT.getSetting(v7reLlOXCgD5pZ14w2tUA(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if PqREL0OwgzB==IJ6VkihabRm(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			QUydweutaN3vRfhF4qVk2P5W8BLJic(RJpWL3qSwhg,uzyCvaxZ5w6AKbg2MpOm4qV7EhR,BBEzmaH9MTeSLcNrwiqj1ds)
			return ZEJAFRNxIrQSU
	ccVYw9uh46Ki3D1 = dxAs4otSE98YmZnKy2iwRCB(u"࠱ఞ")
	if b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): ccVYw9uh46Ki3D1 = iiKkCMqUwSWmAvcQ1YpT69l
	try: qcOU43biDkaPQlZMB1wHEj,K2DlNXvQC65FzngUVyk3IGAq = ssVj9vLP2FS(RJpWL3qSwhg)
	except: return ZEJAFRNxIrQSU
	AtZ2xfDEWqnov = L91nVzxH4hYrgPDsOuljXd0J(u"ࡗࡶࡺ࡫౟")
	try: K2DlNXvQC65FzngUVyk3IGAq.execute(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+GGTRaYBDeNyI25zlF(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: AtZ2xfDEWqnov = OARzhnB9o7uYvQGFaIcZ(u"ࡊࡦࡲࡳࡦౠ")
	if AtZ2xfDEWqnov:
		if ccVYw9uh46Ki3D1: K2DlNXvQC65FzngUVyk3IGAq.execute(V391t7nQWUBR5euCkJ(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(Low1uSVG5OcafJmrYBC7D+ccVYw9uh46Ki3D1)+ddK4MmwpX5oG(u"ࠫࠥࡁࠧમ"))
		qcOU43biDkaPQlZMB1wHEj.commit()
		K2DlNXvQC65FzngUVyk3IGAq.execute(ddK4MmwpX5oG(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+OARzhnB9o7uYvQGFaIcZ(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(Low1uSVG5OcafJmrYBC7D)+GGTRaYBDeNyI25zlF(u"ࠧࠡ࠽ࠪ઱"))
		qcOU43biDkaPQlZMB1wHEj.commit()
		if BBEzmaH9MTeSLcNrwiqj1ds:
			s3THEqb70mYa1oXlVid = (str(BBEzmaH9MTeSLcNrwiqj1ds),)
			K2DlNXvQC65FzngUVyk3IGAq.execute(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+xxpPYJOnoAUrlBzyveui(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),s3THEqb70mYa1oXlVid)
			u5hKSaFyVqLz90Zc6iG = K2DlNXvQC65FzngUVyk3IGAq.fetchall()
			if u5hKSaFyVqLz90Zc6iG:
				try:
					gq2FVNBUKPzIw1pZAnYHJG = j7C3kwg1ob.decompress(u5hKSaFyVqLz90Zc6iG[ddK4MmwpX5oG(u"࠲ట")][ddK4MmwpX5oG(u"࠲ట")])
					ZEJAFRNxIrQSU = g1gmtbGkrcOVJU2QehTqsBjWzX.loads(gq2FVNBUKPzIw1pZAnYHJG)
				except: pass
		else:
			K2DlNXvQC65FzngUVyk3IGAq.execute(DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠧࠦ࠻ࠨવ"))
			u5hKSaFyVqLz90Zc6iG = K2DlNXvQC65FzngUVyk3IGAq.fetchall()
			if u5hKSaFyVqLz90Zc6iG:
				ZEJAFRNxIrQSU,msTQnFKZXoe = {},[]
				for adTOzsphErC4f8xvgPtAW2JM79,BF8XfchlgKmOE0ru2 in u5hKSaFyVqLz90Zc6iG:
					rrnXRv2bFCatYNc6f0 = j7C3kwg1ob.decompress(BF8XfchlgKmOE0ru2)
					BF8XfchlgKmOE0ru2 = g1gmtbGkrcOVJU2QehTqsBjWzX.loads(rrnXRv2bFCatYNc6f0)
					ZEJAFRNxIrQSU[adTOzsphErC4f8xvgPtAW2JM79] = BF8XfchlgKmOE0ru2
					msTQnFKZXoe.append(adTOzsphErC4f8xvgPtAW2JM79)
				if msTQnFKZXoe:
					ZEJAFRNxIrQSU[IJ6VkihabRm(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = msTQnFKZXoe
					if w3G0OiS6kCvADZm7FnRbYe5==xxBJoKG54uwQ(u"࠭࡬ࡪࡵࡷࠫષ"): ZEJAFRNxIrQSU = msTQnFKZXoe
	qcOU43biDkaPQlZMB1wHEj.close()
	return ZEJAFRNxIrQSU
class hFN2jnP4Vb90Le1g(wAiQRoBe2rypsq0H):
	def __init__(DD7zNq8ivSuIxpeM):
		DD7zNq8ivSuIxpeM.c23hJXCAnF9Bx6OgerLulyk4mZaPt = x9N7DKVT1rjsPmlieqQ8HJgU(DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		DD7zNq8ivSuIxpeM.D1NpYskF0yL4 = x9N7DKVT1rjsPmlieqQ8HJgU(DKqQekNtF6WlJLhBP9M5ca(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		DD7zNq8ivSuIxpeM.vyKVEb6aqYtnUrNkm4TW1 = x9N7DKVT1rjsPmlieqQ8HJgU(dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if DD7zNq8ivSuIxpeM.c23hJXCAnF9Bx6OgerLulyk4mZaPt else fcIm8tvxlXZsaEY3bwuG4B(u"઼ࠫࠬ")
	def JSi6pt1I5d(DD7zNq8ivSuIxpeM,lkY6tyL52EB1ufgqR8QerO4Cz0Upd): DD7zNq8ivSuIxpeM.lkY6tyL52EB1ufgqR8QerO4Cz0Upd = lkY6tyL52EB1ufgqR8QerO4Cz0Upd
	def onPlayBackStopped(DD7zNq8ivSuIxpeM): DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = uhOkAKtLVv4XTy1nWE6(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(DD7zNq8ivSuIxpeM): DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = vkMRnTNV9jFm(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(DD7zNq8ivSuIxpeM): DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(DD7zNq8ivSuIxpeM):
		DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = zOZvXaebGNwHKfjRA(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		B3IuZzCx2hgd76QyOLlUmrf = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=DD7zNq8ivSuIxpeM.sV6QwdqIOpcRP,args=())
		B3IuZzCx2hgd76QyOLlUmrf.start()
	def onAVStarted(DD7zNq8ivSuIxpeM):
		if DD7zNq8ivSuIxpeM.D1NpYskF0yL4: DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = KbL94nDHufSF0VcO2Nk3(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = xxBJoKG54uwQ(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def sV6QwdqIOpcRP(DD7zNq8ivSuIxpeM):
		from gvn6IBeN7p import LMZrdQzbSEKc9FYCkl6W8GO,ZJizjHDV1Ec,aarhp43yvIqojdnWs6Sb
		aarhp43yvIqojdnWs6Sb(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		MQLBSHI8aYXjDp56U2F7 = qNZKwi2M1S4fBzGQYrmPnea(u"࠳ఠ")
		while not eval(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡸࡣ࡯ࡦࠫૅ"):AAsbUG0jZ5igBpNKQwFrJTd}) and DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5==tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			AAsbUG0jZ5igBpNKQwFrJTd.sleep(dxAs4otSE98YmZnKy2iwRCB(u"࠵࠵࠶࠰డ"))
			MQLBSHI8aYXjDp56U2F7 += uhOkAKtLVv4XTy1nWE6(u"࠶ఢ")
			if MQLBSHI8aYXjDp56U2F7>vkMRnTNV9jFm(u"࠼࠰ణ"): return
		if DD7zNq8ivSuIxpeM.c23hJXCAnF9Bx6OgerLulyk4mZaPt: DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = V391t7nQWUBR5euCkJ(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif DD7zNq8ivSuIxpeM.D1NpYskF0yL4: DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = ZpH2IWt7veyFobTsAnhi41(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif DD7zNq8ivSuIxpeM.vyKVEb6aqYtnUrNkm4TW1:
			DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			IrVFRP9MNCzsa6W52BJhfj = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=LMZrdQzbSEKc9FYCkl6W8GO,args=(DD7zNq8ivSuIxpeM.lkY6tyL52EB1ufgqR8QerO4Cz0Upd,))
			IrVFRP9MNCzsa6W52BJhfj.start()
			YDlrML3oXj04m1JRIcWUT7hweQf2N = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=ZJizjHDV1Ec,args=())
			YDlrML3oXj04m1JRIcWUT7hweQf2N.start()
		else: DD7zNq8ivSuIxpeM.q0IfRrl9AdimMsGnBcPNFu4LYz5 = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def UUL194WciyrfBKbxR3wAj():
	F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS = vkMRnTNV9jFm(u"ࠬ࠭ો"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࠧૌ")
	YRk4l0Jr9i5o7sdQhGyXvI = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		IIrg3YJpWtP = open(zOZvXaebGNwHKfjRA(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡵࡦࠬ૏")).read()
		if Nnxm30dfoBWRYpIC7KsQGl: IIrg3YJpWtP = IIrg3YJpWtP.decode(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		mPgNv58Zy9VhxjuekFJft6iM0w = QPuHKNAT4jmCRg.findall(ZpH2IWt7veyFobTsAnhi41(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),IIrg3YJpWtP,QPuHKNAT4jmCRg.IGNORECASE)
		if mPgNv58Zy9VhxjuekFJft6iM0w: F2poPYdJcC8qkGuEH = mPgNv58Zy9VhxjuekFJft6iM0w[xxpPYJOnoAUrlBzyveui(u"࠰త")]
	except: pass
	try:
		import subprocess as aM7hB1fcXrySIvplGQxni
		FXiLWqcjyHtu0Isp = aM7hB1fcXrySIvplGQxni.Popen(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=V391t7nQWUBR5euCkJ(u"࡙ࡸࡵࡦౡ"),stdin=aM7hB1fcXrySIvplGQxni.PIPE,stdout=aM7hB1fcXrySIvplGQxni.PIPE,stderr=aM7hB1fcXrySIvplGQxni.PIPE)
		R09HJOueKBD1ENzLQ = FXiLWqcjyHtu0Isp.stdout.read()
		if R09HJOueKBD1ENzLQ:
			if Nnxm30dfoBWRYpIC7KsQGl:
				R09HJOueKBD1ENzLQ = R09HJOueKBD1ENzLQ.decode(qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࡵࡵࡨ࠻ࠫ૓"),xxpPYJOnoAUrlBzyveui(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			vqk4cKOH68G79xarF = QPuHKNAT4jmCRg.findall(xxBJoKG54uwQ(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),R09HJOueKBD1ENzLQ,QPuHKNAT4jmCRg.IGNORECASE)
			if vqk4cKOH68G79xarF: WhC9felMHcRQBT03214yXixYEormS = min(vqk4cKOH68G79xarF)
	except: pass
	return YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS
def Dx3jCK6X7lktdiE(wwRk9qaXWGj5EoLmJIprzNUn23,RgPp0W1dD8fcXMnH9j6qaLbT=xxpPYJOnoAUrlBzyveui(u"࡚ࡲࡶࡧౢ")):
	caBbrSqulDNVjRKM7T8 = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࡔࡳࡷࡨౣ")
	if RgPp0W1dD8fcXMnH9j6qaLbT:
		JE0V1Lwz5Uba = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩ࡯࡭ࡸࡺࠧ૖"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),zOZvXaebGNwHKfjRA(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if JE0V1Lwz5Uba:
			vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8,Ku4TxptQl2,KGzcWXhsCrYkM0Btv7NJFel,ekgOEFS10CYDqwWKlaP23sIhzHJ = JE0V1Lwz5Uba
			caBbrSqulDNVjRKM7T8 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,Vv0lSjAOHLfMnam3wtdor(u"ࠬࡲࡩࡴࡶࠪ૙"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if caBbrSqulDNVjRKM7T8: YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS = caBbrSqulDNVjRKM7T8
			else: YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS = UUL194WciyrfBKbxR3wAj()
			if (Ku4TxptQl2,KGzcWXhsCrYkM0Btv7NJFel,ekgOEFS10CYDqwWKlaP23sIhzHJ)==(YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS): return ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨ࡞ࡱࠫ૜").join(vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8)
	if caBbrSqulDNVjRKM7T8: YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS = UUL194WciyrfBKbxR3wAj()
	global h43SjCBIikY1vonMRFTNbfQP7,GvXkZTmra2UWP3f8zRIBxne6tsE
	h43SjCBIikY1vonMRFTNbfQP7,GvXkZTmra2UWP3f8zRIBxne6tsE,XLCUjSTz6odraM01bx2kvKiWIhGtmy = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࠪ૝"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࠫ૞"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࠬ૟")
	wwRk9qaXWGj5EoLmJIprzNUn23 = wwRk9qaXWGj5EoLmJIprzNUn23//zOZvXaebGNwHKfjRA(u"࠳థ")
	nt0ApgWuodKimeTxcNVLEs4U.Thread(target=YvB43dFpQk0L1lPb9V2s7e6).start()
	nt0ApgWuodKimeTxcNVLEs4U.Thread(target=PGXH4MmW1h).start()
	for kdWCpE9TjNh in range(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠳࠳ద")):
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠳࠲࠺ధ"))
		if not XLCUjSTz6odraM01bx2kvKiWIhGtmy:
			try:
				Ihmxdln3kSZG = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if Ihmxdln3kSZG.count(DDS79jdWzLtE(u"࠭࠺ࠨૡ"))==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠺఩") and Ihmxdln3kSZG.count(OARzhnB9o7uYvQGFaIcZ(u"ࠧ࠱ࠩૢ"))<xxpPYJOnoAUrlBzyveui(u"࠽న"):
					Ihmxdln3kSZG = Ihmxdln3kSZG.lower().replace(v7reLlOXCgD5pZ14w2tUA(u"ࠨ࠼ࠪૣ"),uhOkAKtLVv4XTy1nWE6(u"ࠩࠪ૤"))
					XLCUjSTz6odraM01bx2kvKiWIhGtmy = str(int(Ihmxdln3kSZG,ddK4MmwpX5oG(u"࠷࠶ప")))
			except: pass
		if h43SjCBIikY1vonMRFTNbfQP7 and GvXkZTmra2UWP3f8zRIBxne6tsE and XLCUjSTz6odraM01bx2kvKiWIhGtmy: break
	HrA9e8OtZCIRscWlxV1EfQjSivU = [h43SjCBIikY1vonMRFTNbfQP7,GvXkZTmra2UWP3f8zRIBxne6tsE,XLCUjSTz6odraM01bx2kvKiWIhGtmy,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࠫ૥"),xxpPYJOnoAUrlBzyveui(u"ࠫࠬ૦"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if F2poPYdJcC8qkGuEH or WhC9felMHcRQBT03214yXixYEormS:
		from hashlib import md5 as uIVUl3LvOfkK2NoGzq
		IeaLt4ZrGMiQzD5vqHjc6 = [(uhOkAKtLVv4XTy1nWE6(u"࠵బ"),F2poPYdJcC8qkGuEH),(uhOkAKtLVv4XTy1nWE6(u"࠵ఫ"),WhC9felMHcRQBT03214yXixYEormS)]
		for SonE0wpbWDiYV,ccgnvJDbLi3FuVKNdM6Ea in IeaLt4ZrGMiQzD5vqHjc6:
			ccgnvJDbLi3FuVKNdM6Ea = ccgnvJDbLi3FuVKNdM6Ea.strip(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭࠰ࠨ૨"))
			if ccgnvJDbLi3FuVKNdM6Ea:
				if Nnxm30dfoBWRYpIC7KsQGl: ccgnvJDbLi3FuVKNdM6Ea = ccgnvJDbLi3FuVKNdM6Ea.encode(xxBJoKG54uwQ(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				ccgnvJDbLi3FuVKNdM6Ea = str(int(uIVUl3LvOfkK2NoGzq(ccgnvJDbLi3FuVKNdM6Ea).hexdigest(),zOZvXaebGNwHKfjRA(u"࠵࠹భ")))
				KLFuYw9mo4VC = [int(ccgnvJDbLi3FuVKNdM6Ea[wwIZJa26dhME4xNkUC597zFRo:wwIZJa26dhME4xNkUC597zFRo+qNZKwi2M1S4fBzGQYrmPnea(u"࠵࠺య")]) for wwIZJa26dhME4xNkUC597zFRo in range(len(ccgnvJDbLi3FuVKNdM6Ea)) if wwIZJa26dhME4xNkUC597zFRo%qNZKwi2M1S4fBzGQYrmPnea(u"࠵࠺య")==DDS79jdWzLtE(u"࠳మ")]
				HrA9e8OtZCIRscWlxV1EfQjSivU[SonE0wpbWDiYV-zOZvXaebGNwHKfjRA(u"࠶ర")] = str(sum(KLFuYw9mo4VC))
	vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8,ctbE31UjsBWXL7q5ag8CkI6nGvA = [],vkMRnTNV9jFm(u"ࡇࡣ࡯ࡷࡪ౤")
	for d6LsvScIuOe9Ni in range(len(HrA9e8OtZCIRscWlxV1EfQjSivU)):
		KLFuYw9mo4VC = HrA9e8OtZCIRscWlxV1EfQjSivU[d6LsvScIuOe9Ni]
		if not KLFuYw9mo4VC: continue
		if ctbE31UjsBWXL7q5ag8CkI6nGvA and KLFuYw9mo4VC==HrA9e8OtZCIRscWlxV1EfQjSivU[-Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠷ఱ")]: continue
		ctbE31UjsBWXL7q5ag8CkI6nGvA = Vv0lSjAOHLfMnam3wtdor(u"ࡖࡵࡹࡪ౥")
		KLFuYw9mo4VC = wwRk9qaXWGj5EoLmJIprzNUn23*zOZvXaebGNwHKfjRA(u"ࠨ࠲ࠪ૪")+KLFuYw9mo4VC
		KLFuYw9mo4VC = KLFuYw9mo4VC[-wwRk9qaXWGj5EoLmJIprzNUn23:]
		nHxqc7wjsd8yX3BPEir9,heiG1ZCXocsfJvIPtauB3pE = v7reLlOXCgD5pZ14w2tUA(u"ࠩࠪ૫"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࠫ૬")
		U6OfN7vsuPmdct = str(int(xxBJoKG54uwQ(u"ࠫ࠾࠭૭")*(wwRk9qaXWGj5EoLmJIprzNUn23+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠱ల")))-int(KLFuYw9mo4VC))[-wwRk9qaXWGj5EoLmJIprzNUn23:]
		for R58BqYpOyeZs in list(range(ZpH2IWt7veyFobTsAnhi41(u"࠱ళ"),wwRk9qaXWGj5EoLmJIprzNUn23,qNZKwi2M1S4fBzGQYrmPnea(u"࠶ఴ"))):
			LWGjeTpmcMakR0dVv2hQFfqJDy = U6OfN7vsuPmdct[R58BqYpOyeZs:R58BqYpOyeZs+f8PVRTseIuj9BckO6GoyF5Lxv(u"࠷వ")]
			nHxqc7wjsd8yX3BPEir9 += LWGjeTpmcMakR0dVv2hQFfqJDy+DKqQekNtF6WlJLhBP9M5ca(u"ࠬ࠳ࠧ૮")
			heiG1ZCXocsfJvIPtauB3pE += str(sum(map(int,KLFuYw9mo4VC[R58BqYpOyeZs:R58BqYpOyeZs+HMO0QciekqVpLKmA(u"࠹ష")]))%gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠵࠵శ"))
		C12v5SKmRuhbzLFndAjW0g = str(d6LsvScIuOe9Ni)+nHxqc7wjsd8yX3BPEir9+heiG1ZCXocsfJvIPtauB3pE
		vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8.append(C12v5SKmRuhbzLFndAjW0g)
	mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,IJ6VkihabRm(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),DDS79jdWzLtE(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS],t7rXIzJfMLWRwaDeKhTq4C6dG)
	mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),IJ6VkihabRm(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8,YRk4l0Jr9i5o7sdQhGyXvI,F2poPYdJcC8qkGuEH,WhC9felMHcRQBT03214yXixYEormS],lu4xpkY5LFOm6t2In)
	return dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡠࡳ࠭૳").join(vv2xQ4sjuUWJZBSaCH7ImEbzXcRoM8)
def BEt0xkYQrnLpwZ4JaFUDM8oX5vAN(xEc7nR3qoAlv6C8YjD,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,oBQqw316KAIpOdr7R0LxkZNW5lG4y,bB2eVZo9P8TpLU1Rw):
	Eudgv5cTUHF2AzKpkx = str(iPmj7p45q2duSAQaHvOnT)[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠶స"):ddK4MmwpX5oG(u"࠲࠶࠲హ")].replace(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡡࡴࠧ૴"),xxBJoKG54uwQ(u"ࠬࡢ࡜࡯ࠩ૵")).replace(KbL94nDHufSF0VcO2Nk3(u"࠭࡜ࡳࠩ૶"),uhOkAKtLVv4XTy1nWE6(u"ࠧ࡝࡞ࡵࠫ૷")).replace(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࠢࠣࠤࠥ࠭૸"),Vv0lSjAOHLfMnam3wtdor(u"ࠩࠣࠫૹ")).replace(L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࠤࠥࠦࠧૺ"),v7reLlOXCgD5pZ14w2tUA(u"ࠫࠥ࠭ૻ"))
	if len(str(iPmj7p45q2duSAQaHvOnT))>dxAs4otSE98YmZnKy2iwRCB(u"࠳࠷࠳఺"): Eudgv5cTUHF2AzKpkx = Eudgv5cTUHF2AzKpkx+HMO0QciekqVpLKmA(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	BF8XfchlgKmOE0ru2 = str(ZEJAFRNxIrQSU)[vkMRnTNV9jFm(u"࠲఻"):fcIm8tvxlXZsaEY3bwuG4B(u"࠵࠹࠵఼")].replace(HMO0QciekqVpLKmA(u"࠭࡜࡯ࠩ૽"),vkMRnTNV9jFm(u"ࠧ࡝࡞ࡱࠫ૾")).replace(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ࡞ࡵࠫ૿"),GGTRaYBDeNyI25zlF(u"ࠩ࡟ࡠࡷ࠭଀")).replace(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࠤࠥࠦࠠࠨଁ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࠥ࠭ଂ")).replace(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࠦࠠࠡࠩଃ"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠠࠨ଄"))
	if len(str(ZEJAFRNxIrQSU))>uhOkAKtLVv4XTy1nWE6(u"࠶࠺࠶ఽ"): BF8XfchlgKmOE0ru2 = BF8XfchlgKmOE0ru2+xxBJoKG54uwQ(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	zRM3tZx2v6DjJU(IJ6VkihabRm(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+xEc7nR3qoAlv6C8YjD+OARzhnB9o7uYvQGFaIcZ(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+DDRulV7aKN3jCOWSBQkb95+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+xxpPYJOnoAUrlBzyveui(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+bB2eVZo9P8TpLU1Rw+DDS79jdWzLtE(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(Eudgv5cTUHF2AzKpkx)+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+BF8XfchlgKmOE0ru2+ZpH2IWt7veyFobTsAnhi41(u"ࠨࠢࡠࠫ଍"))
	return
def YvB43dFpQk0L1lPb9V2s7e6():
	global h43SjCBIikY1vonMRFTNbfQP7
	import getmac82 as jjVOaMlFyvExo2Zq7N5bJcA
	try:
		thNmrY3WLF = jjVOaMlFyvExo2Zq7N5bJcA.get_mac_address()
		if thNmrY3WLF.count(IJ6VkihabRm(u"ࠩ࠽ࠫ଎"))==lunVJF2G5bZMgTcCje0vaIB371SX(u"࠻ి") and thNmrY3WLF.count(GGTRaYBDeNyI25zlF(u"ࠪ࠴ࠬଏ"))<lunVJF2G5bZMgTcCje0vaIB371SX(u"࠾ా"):
			thNmrY3WLF = thNmrY3WLF.lower().replace(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫ࠿࠭ଐ"),xxpPYJOnoAUrlBzyveui(u"ࠬ࠭଑"))
			h43SjCBIikY1vonMRFTNbfQP7 = str(int(thNmrY3WLF,ZpH2IWt7veyFobTsAnhi41(u"࠱࠷ీ")))
	except: pass
	return
def PGXH4MmW1h():
	global GvXkZTmra2UWP3f8zRIBxne6tsE
	import getmac94 as XKg4uWFMmHRPjJc5
	try:
		rVJTavqIPg70nds3BwR = XKg4uWFMmHRPjJc5.get_mac_address()
		if rVJTavqIPg70nds3BwR.count(DKqQekNtF6WlJLhBP9M5ca(u"࠭࠺ࠨ଒"))==qNZKwi2M1S4fBzGQYrmPnea(u"࠷ూ") and rVJTavqIPg70nds3BwR.count(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࠱ࠩଓ"))<a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠺ు"):
			rVJTavqIPg70nds3BwR = rVJTavqIPg70nds3BwR.lower().replace(L91nVzxH4hYrgPDsOuljXd0J(u"ࠨ࠼ࠪଔ"),p1lrNRIXqLQJznH6O(u"ࠩࠪକ"))
			GvXkZTmra2UWP3f8zRIBxne6tsE = str(int(rVJTavqIPg70nds3BwR,GGTRaYBDeNyI25zlF(u"࠴࠺ృ")))
	except: pass
	return
def aAl73ft1UpVOXoST5uL(bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࠫଖ"),iPmj7p45q2duSAQaHvOnT=L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠬଗ"),oBQqw316KAIpOdr7R0LxkZNW5lG4y=dxAs4otSE98YmZnKy2iwRCB(u"ࠬ࠭ଘ")):
	BEt0xkYQrnLpwZ4JaFUDM8oX5vAN(uhOkAKtLVv4XTy1nWE6(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,oBQqw316KAIpOdr7R0LxkZNW5lG4y,bB2eVZo9P8TpLU1Rw)
	if Nnxm30dfoBWRYpIC7KsQGl: import urllib.request as LvpAzYkfJHTBnF
	else: import urllib2 as LvpAzYkfJHTBnF
	if not iPmj7p45q2duSAQaHvOnT: iPmj7p45q2duSAQaHvOnT = {tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࠩଛ")}
	if not ZEJAFRNxIrQSU: ZEJAFRNxIrQSU = {}
	if bB2eVZo9P8TpLU1Rw==GGTRaYBDeNyI25zlF(u"ࠩࡊࡉ࡙࠭ଜ"):
		DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+ddK4MmwpX5oG(u"ࠪࡃࠬଝ")+YZpVhcRlPs3n0FrD(ZEJAFRNxIrQSU)
		ZEJAFRNxIrQSU = None
	elif bB2eVZo9P8TpLU1Rw==ZpH2IWt7veyFobTsAnhi41(u"ࠫࡕࡕࡓࡕࠩଞ") and L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡰࡳࡰࡰࠪଟ") in str(iPmj7p45q2duSAQaHvOnT):
		from json import dumps as LFgRCWvkM8hAD
		ZEJAFRNxIrQSU = LFgRCWvkM8hAD(ZEJAFRNxIrQSU)
		ZEJAFRNxIrQSU = str(ZEJAFRNxIrQSU).encode(KbL94nDHufSF0VcO2Nk3(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif bB2eVZo9P8TpLU1Rw==tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡑࡑࡖࡘࠬଡ"):
		ZEJAFRNxIrQSU = YZpVhcRlPs3n0FrD(ZEJAFRNxIrQSU)
		ZEJAFRNxIrQSU = ZEJAFRNxIrQSU.encode(xxBJoKG54uwQ(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		lW9KyqX1zRhLEuJxYVi = LvpAzYkfJHTBnF.Request(DDRulV7aKN3jCOWSBQkb95,headers=iPmj7p45q2duSAQaHvOnT,data=ZEJAFRNxIrQSU)
		djr0g3VkMzo1ehxE = LvpAzYkfJHTBnF.urlopen(lW9KyqX1zRhLEuJxYVi)
		RkLE6BzZ2KX = djr0g3VkMzo1ehxE.read()
		TIvkgj7OxW6Vzb35il,rreason = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶࠵࠶ౄ"),Vv0lSjAOHLfMnam3wtdor(u"ࠩࡒࡏࠬଣ")
	except:
		RkLE6BzZ2KX = KbL94nDHufSF0VcO2Nk3(u"ࠪࠫତ")
		TIvkgj7OxW6Vzb35il,rreason = -fcIm8tvxlXZsaEY3bwuG4B(u"࠶౅"),L91nVzxH4hYrgPDsOuljXd0J(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	zRM3tZx2v6DjJU(GGTRaYBDeNyI25zlF(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),V391t7nQWUBR5euCkJ(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(TIvkgj7OxW6Vzb35il)+GGTRaYBDeNyI25zlF(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+rreason+xxpPYJOnoAUrlBzyveui(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+DDRulV7aKN3jCOWSBQkb95+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࠤࡢ࠭ଫ"))
	if RkLE6BzZ2KX and Nnxm30dfoBWRYpIC7KsQGl: RkLE6BzZ2KX = RkLE6BzZ2KX.decode(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return RkLE6BzZ2KX
def ce30uS4tawJ26EdhVnxjp1(hhKmFa0blIXiZn1f5ytUekTjv,NNo1wGhcfBM3urDxObmVqg8WL=v7reLlOXCgD5pZ14w2tUA(u"ࠬ࠭ଭ")):
	PnbDkMzq3vGXTYSJWaH = str(KRjfaduUhzsPg6I1.randrange(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴ె"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽ే")))
	iPmj7p45q2duSAQaHvOnT = {gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	dHY30oZIxrt1DnwUJbzaX = {	qNZKwi2M1S4fBzGQYrmPnea(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):Dx3jCK6X7lktdiE(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵࠵౉")).splitlines()[xxpPYJOnoAUrlBzyveui(u"࠳ొ")][-ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳࠶ై"):],
				fcIm8tvxlXZsaEY3bwuG4B(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(LRjqrQYBXFVPfu),
				OARzhnB9o7uYvQGFaIcZ(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):uVp7krjL48oWd3tqGYCRz5M,
				V391t7nQWUBR5euCkJ(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):uVp7krjL48oWd3tqGYCRz5M,
				u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):hhKmFa0blIXiZn1f5ytUekTjv,
				q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): uVp7krjL48oWd3tqGYCRz5M,
				f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):fcIm8tvxlXZsaEY3bwuG4B(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				uhOkAKtLVv4XTy1nWE6(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{v7reLlOXCgD5pZ14w2tUA(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):hhKmFa0blIXiZn1f5ytUekTjv},
				Vv0lSjAOHLfMnam3wtdor(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):hhKmFa0blIXiZn1f5ytUekTjv},
				lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):ddK4MmwpX5oG(u"ࡉࡥࡱࡹࡥ౦"),
				lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠢࡪࡲࠥଽ"): Vv0lSjAOHLfMnam3wtdor(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not NNo1wGhcfBM3urDxObmVqg8WL: IxiYRhtsQUfV = [dHY30oZIxrt1DnwUJbzaX]
	else:
		rLiTaVXg4CO1DuIsoZBy39QSkwH = dHY30oZIxrt1DnwUJbzaX.copy()
		rLiTaVXg4CO1DuIsoZBy39QSkwH[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = NNo1wGhcfBM3urDxObmVqg8WL
		rLiTaVXg4CO1DuIsoZBy39QSkwH[iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {KbL94nDHufSF0VcO2Nk3(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):NNo1wGhcfBM3urDxObmVqg8WL}
		rLiTaVXg4CO1DuIsoZBy39QSkwH[qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):NNo1wGhcfBM3urDxObmVqg8WL}
		IxiYRhtsQUfV = [dHY30oZIxrt1DnwUJbzaX,rLiTaVXg4CO1DuIsoZBy39QSkwH]
	ZEJAFRNxIrQSU = {v7reLlOXCgD5pZ14w2tUA(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			KbL94nDHufSF0VcO2Nk3(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):PnbDkMzq3vGXTYSJWaH,
			IJ6VkihabRm(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): IxiYRhtsQUfV
		}
	DDRulV7aKN3jCOWSBQkb95 = zOZvXaebGNwHKfjRA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	RkLE6BzZ2KX = aAl73ft1UpVOXoST5uL(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡖࡏࡔࡖࠪ୉"),DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,xxpPYJOnoAUrlBzyveui(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return RkLE6BzZ2KX
def kMLWTt2fO9dnGDUgHh(w3G0OiS6kCvADZm7FnRbYe5,gq2FVNBUKPzIw1pZAnYHJG):
	gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.replace(V391t7nQWUBR5euCkJ(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.replace(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡷࡶࡺ࡫୍ࠧ"),HMO0QciekqVpLKmA(u"ࠪࡘࡷࡻࡥࠨ୎"))
	gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.replace(Vv0lSjAOHLfMnam3wtdor(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),uhOkAKtLVv4XTy1nWE6(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.replace(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭࡜࠰ࠩ୑"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧ࠰ࠩ୒"))
	try: rrnXRv2bFCatYNc6f0 = eval(gq2FVNBUKPzIw1pZAnYHJG)
	except: rrnXRv2bFCatYNc6f0 = ooqE7AfbkuxB36MYaPp(w3G0OiS6kCvADZm7FnRbYe5)
	return rrnXRv2bFCatYNc6f0
def DZP9fVUE7eCnTgQkiYy8RFGNraAKB():
	xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2 = JJqxTSR6tZiQ79cpkwa3GMy(a4EuYDiRdrA)
	uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall(vkMRnTNV9jFm(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),QEMyY8a9IoOcFqeuKztCVWmT7jXv,QPuHKNAT4jmCRg.DOTALL)
	if uuv3pk5MXdeaHt6sDxSFybTWz0Q: QEMyY8a9IoOcFqeuKztCVWmT7jXv = QEMyY8a9IoOcFqeuKztCVWmT7jXv.split(uuv3pk5MXdeaHt6sDxSFybTWz0Q[GGTRaYBDeNyI25zlF(u"࠵ౌ")],qNZKwi2M1S4fBzGQYrmPnea(u"࠵ో"))[qNZKwi2M1S4fBzGQYrmPnea(u"࠵ో")]
	lHvSOF9EpRL = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2.localtime(Low1uSVG5OcafJmrYBC7D))
	QEMyY8a9IoOcFqeuKztCVWmT7jXv = QEMyY8a9IoOcFqeuKztCVWmT7jXv+lHvSOF9EpRL
	ymraFo65GxbqVg8YeLHct4Zl2 = xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(PPgJ3en0yKYWdzMAmCON1DTQG9):
		g4gokw71hemBnS3xPIORXJNbLzV = open(PPgJ3en0yKYWdzMAmCON1DTQG9,ddK4MmwpX5oG(u"ࠪࡶࡧ࠭୕")).read()
		if Nnxm30dfoBWRYpIC7KsQGl: g4gokw71hemBnS3xPIORXJNbLzV = g4gokw71hemBnS3xPIORXJNbLzV.decode(IJ6VkihabRm(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		g4gokw71hemBnS3xPIORXJNbLzV = kMLWTt2fO9dnGDUgHh(IJ6VkihabRm(u"ࠬࡪࡩࡤࡶࠪୗ"),g4gokw71hemBnS3xPIORXJNbLzV)
	else: g4gokw71hemBnS3xPIORXJNbLzV = {}
	I5n6KcZWvLYtkrof0eMJsASTaU = {}
	for sRBAVUaf1jhbG5HLdq6OFcpM8tK3 in list(g4gokw71hemBnS3xPIORXJNbLzV.keys()):
		if sRBAVUaf1jhbG5HLdq6OFcpM8tK3!=xEc7nR3qoAlv6C8YjD: I5n6KcZWvLYtkrof0eMJsASTaU[sRBAVUaf1jhbG5HLdq6OFcpM8tK3] = g4gokw71hemBnS3xPIORXJNbLzV[sRBAVUaf1jhbG5HLdq6OFcpM8tK3]
		else:
			if QEMyY8a9IoOcFqeuKztCVWmT7jXv and QEMyY8a9IoOcFqeuKztCVWmT7jXv!=v7reLlOXCgD5pZ14w2tUA(u"࠭࠮࠯ࠩ୘"):
				NXE2GZahAt7mwnHVibKPJSlvUMB = g4gokw71hemBnS3xPIORXJNbLzV[sRBAVUaf1jhbG5HLdq6OFcpM8tK3]
				if ymraFo65GxbqVg8YeLHct4Zl2 in NXE2GZahAt7mwnHVibKPJSlvUMB:
					A1pJYqSia7V4wKMnuvLe30QbrkGj = NXE2GZahAt7mwnHVibKPJSlvUMB.index(ymraFo65GxbqVg8YeLHct4Zl2)
					del NXE2GZahAt7mwnHVibKPJSlvUMB[A1pJYqSia7V4wKMnuvLe30QbrkGj]
				H6hWCxi0SEZ8MI43qGursNodTvV = [ymraFo65GxbqVg8YeLHct4Zl2]+NXE2GZahAt7mwnHVibKPJSlvUMB
				H6hWCxi0SEZ8MI43qGursNodTvV = H6hWCxi0SEZ8MI43qGursNodTvV[:ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠻࠰్")]
				I5n6KcZWvLYtkrof0eMJsASTaU[sRBAVUaf1jhbG5HLdq6OFcpM8tK3] = H6hWCxi0SEZ8MI43qGursNodTvV
			else: I5n6KcZWvLYtkrof0eMJsASTaU[sRBAVUaf1jhbG5HLdq6OFcpM8tK3] = g4gokw71hemBnS3xPIORXJNbLzV[sRBAVUaf1jhbG5HLdq6OFcpM8tK3]
	if xEc7nR3qoAlv6C8YjD not in list(I5n6KcZWvLYtkrof0eMJsASTaU.keys()): I5n6KcZWvLYtkrof0eMJsASTaU[xEc7nR3qoAlv6C8YjD] = [ymraFo65GxbqVg8YeLHct4Zl2]
	I5n6KcZWvLYtkrof0eMJsASTaU = str(I5n6KcZWvLYtkrof0eMJsASTaU)
	if Nnxm30dfoBWRYpIC7KsQGl: I5n6KcZWvLYtkrof0eMJsASTaU = I5n6KcZWvLYtkrof0eMJsASTaU.encode(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(PPgJ3en0yKYWdzMAmCON1DTQG9,dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡹࡥࠫ୚")).write(I5n6KcZWvLYtkrof0eMJsASTaU)
	return
def mhr0way8dQLUMt6uSIPqGW(RJpWL3qSwhg,uzyCvaxZ5w6AKbg2MpOm4qV7EhR,BBEzmaH9MTeSLcNrwiqj1ds,ZEJAFRNxIrQSU,ccHn2S5KzhpbZuB,QCbwldOANUL=v7reLlOXCgD5pZ14w2tUA(u"ࡊࡦࡲࡳࡦ౧")):
	b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX = fQ6kvwg1FrYAzXjbLT.getSetting(V391t7nQWUBR5euCkJ(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX==V391t7nQWUBR5euCkJ(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and ccHn2S5KzhpbZuB>iiKkCMqUwSWmAvcQ1YpT69l: ccHn2S5KzhpbZuB = iiKkCMqUwSWmAvcQ1YpT69l
	if QCbwldOANUL:
		g27TaovWhPEzbHsY39Bw,PyicFLATx4z58m2I = [],[]
		for kdWCpE9TjNh in range(len(BBEzmaH9MTeSLcNrwiqj1ds)):
			gq2FVNBUKPzIw1pZAnYHJG = g1gmtbGkrcOVJU2QehTqsBjWzX.dumps(ZEJAFRNxIrQSU[kdWCpE9TjNh])
			fxQvnObhmY2pr60EcCuV = j7C3kwg1ob.compress(gq2FVNBUKPzIw1pZAnYHJG)
			g27TaovWhPEzbHsY39Bw.append((BBEzmaH9MTeSLcNrwiqj1ds[kdWCpE9TjNh],))
			PyicFLATx4z58m2I.append((ccHn2S5KzhpbZuB+Low1uSVG5OcafJmrYBC7D,str(BBEzmaH9MTeSLcNrwiqj1ds[kdWCpE9TjNh]),fxQvnObhmY2pr60EcCuV))
	else:
		gq2FVNBUKPzIw1pZAnYHJG = g1gmtbGkrcOVJU2QehTqsBjWzX.dumps(ZEJAFRNxIrQSU)
		jj9ybfZET2crAJYRsO = j7C3kwg1ob.compress(gq2FVNBUKPzIw1pZAnYHJG)
	try: qcOU43biDkaPQlZMB1wHEj,K2DlNXvQC65FzngUVyk3IGAq = ssVj9vLP2FS(RJpWL3qSwhg)
	except: return
	while Vv0lSjAOHLfMnam3wtdor(u"࡙ࡸࡵࡦ౨"):
		try:
			K2DlNXvQC65FzngUVyk3IGAq.execute(Vv0lSjAOHLfMnam3wtdor(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(IJ6VkihabRm(u"࠰࠯࠷౎"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+xxBJoKG54uwQ(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if QCbwldOANUL:
		K2DlNXvQC65FzngUVyk3IGAq.executemany(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+uhOkAKtLVv4XTy1nWE6(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),g27TaovWhPEzbHsY39Bw)
		K2DlNXvQC65FzngUVyk3IGAq.executemany(V391t7nQWUBR5euCkJ(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),PyicFLATx4z58m2I)
	else:
		if ccHn2S5KzhpbZuB:
			s3THEqb70mYa1oXlVid = (str(BBEzmaH9MTeSLcNrwiqj1ds),)
			K2DlNXvQC65FzngUVyk3IGAq.execute(DKqQekNtF6WlJLhBP9M5ca(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),s3THEqb70mYa1oXlVid)
			s3THEqb70mYa1oXlVid = (ccHn2S5KzhpbZuB+Low1uSVG5OcafJmrYBC7D,str(BBEzmaH9MTeSLcNrwiqj1ds),jj9ybfZET2crAJYRsO)
			K2DlNXvQC65FzngUVyk3IGAq.execute(DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+ZpH2IWt7veyFobTsAnhi41(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),s3THEqb70mYa1oXlVid)
		else:
			s3THEqb70mYa1oXlVid = (jj9ybfZET2crAJYRsO,str(BBEzmaH9MTeSLcNrwiqj1ds))
			K2DlNXvQC65FzngUVyk3IGAq.execute(uhOkAKtLVv4XTy1nWE6(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+uzyCvaxZ5w6AKbg2MpOm4qV7EhR+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),s3THEqb70mYa1oXlVid)
	qcOU43biDkaPQlZMB1wHEj.commit()
	qcOU43biDkaPQlZMB1wHEj.close()
	return
def YZpVhcRlPs3n0FrD(ZEJAFRNxIrQSU):
	if Nnxm30dfoBWRYpIC7KsQGl: import urllib.parse as hRkKLNIYAsXw
	else: import urllib as hRkKLNIYAsXw
	ZpVo6InvM2GKNCF79w1XAqd5e = hRkKLNIYAsXw.urlencode(ZEJAFRNxIrQSU)
	return ZpVo6InvM2GKNCF79w1XAqd5e
q0IfRrl9AdimMsGnBcPNFu4LYz5 = q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࠫ୪")
def zT3xJQIVDmCgapBljs(lc154VhT9DCqMk8,Qc0l2ofbVvZDM=xxBJoKG54uwQ(u"ࠫࠬ୫"),wwZo35QLF2NKnChmkx=Vv0lSjAOHLfMnam3wtdor(u"ࠬ࠭୬")):
	xaqr1OyIRm = Qc0l2ofbVvZDM not in [GGTRaYBDeNyI25zlF(u"࠭ࡍ࠴ࡗࠪ୭"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global q0IfRrl9AdimMsGnBcPNFu4LYz5
	if not wwZo35QLF2NKnChmkx: wwZo35QLF2NKnChmkx = xxBJoKG54uwQ(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	q0IfRrl9AdimMsGnBcPNFu4LYz5,KOSl45tpWZvMdqPQs8HuTDVj,iVlO42GI8H0AJNaUcsjSZ9qDz = DDS79jdWzLtE(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),vkMRnTNV9jFm(u"ࠪࠫୱ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࠬ୲")
	if len(lc154VhT9DCqMk8)==v7reLlOXCgD5pZ14w2tUA(u"࠴౏"):
		DDRulV7aKN3jCOWSBQkb95,BXtacnEVOZrICJzvQGo,iVlO42GI8H0AJNaUcsjSZ9qDz = lc154VhT9DCqMk8
		if BXtacnEVOZrICJzvQGo: KOSl45tpWZvMdqPQs8HuTDVj = v7reLlOXCgD5pZ14w2tUA(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+BXtacnEVOZrICJzvQGo+lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࠠ࡞ࠩ୴")
	else: DDRulV7aKN3jCOWSBQkb95,BXtacnEVOZrICJzvQGo,iVlO42GI8H0AJNaUcsjSZ9qDz = lc154VhT9DCqMk8,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࠨ୵"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࠩ୶")
	DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95.replace(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࠨ࠶࠵࠭୷"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࠤࠬ୸"))
	fBYse5u6VkLhmcZg = H93DlbtKLEarfQ8w7GcoIukSexv0J(DDRulV7aKN3jCOWSBQkb95)
	if Qc0l2ofbVvZDM not in [Vv0lSjAOHLfMnam3wtdor(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if Qc0l2ofbVvZDM!=KbL94nDHufSF0VcO2Nk3(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95.replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࠡࠩ୼"),GGTRaYBDeNyI25zlF(u"ࠨࠧ࠵࠴ࠬ୽"))
		zRM3tZx2v6DjJU(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+GGTRaYBDeNyI25zlF(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୿")+DDRulV7aKN3jCOWSBQkb95+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࠥࡣࠧ஀")+KOSl45tpWZvMdqPQs8HuTDVj)
		if fBYse5u6VkLhmcZg==KbL94nDHufSF0VcO2Nk3(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and Qc0l2ofbVvZDM not in [v7reLlOXCgD5pZ14w2tUA(u"࠭ࡉࡑࡖ࡙ࠫஂ"),xxpPYJOnoAUrlBzyveui(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from gvn6IBeN7p import RjzVfbE0ILcNXFQJniSMBOskK13ox,ISveRUGKjgM9wqL6FZpsku0bB,uFCykYQW68S
			xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = RjzVfbE0ILcNXFQJniSMBOskK13ox(DDRulV7aKN3jCOWSBQkb95)
			KDxoah0WRdY1 = len(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
			if KDxoah0WRdY1>tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠳౐"):
				ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB(DDS79jdWzLtE(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(KDxoah0WRdY1)+fcIm8tvxlXZsaEY3bwuG4B(u"้้ࠩࠣ็ࠩࠨஅ"), xitERh4TD2jGJPq5Nuv39CAmg)
				if ShT1xUHjlDotkRuPq7gv==-f8PVRTseIuj9BckO6GoyF5Lxv(u"࠴౑"):
					uFCykYQW68S(DKqQekNtF6WlJLhBP9M5ca(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭ஆ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠬஇ"))
					return q0IfRrl9AdimMsGnBcPNFu4LYz5
			else: ShT1xUHjlDotkRuPq7gv = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠴౒")
			DDRulV7aKN3jCOWSBQkb95 = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
			if xitERh4TD2jGJPq5Nuv39CAmg[q0JfWbP8vACLxSNIncpOXkR6j(u"࠵౓")]!=q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬ࠳࠱ࠨஈ"):
				zRM3tZx2v6DjJU(OARzhnB9o7uYvQGFaIcZ(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+ZpH2IWt7veyFobTsAnhi41(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+xitERh4TD2jGJPq5Nuv39CAmg[ShT1xUHjlDotkRuPq7gv]+ddK4MmwpX5oG(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ஋")+DDRulV7aKN3jCOWSBQkb95+GGTRaYBDeNyI25zlF(u"ࠩࠣࡡࠬ஌"))
		if lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in DDRulV7aKN3jCOWSBQkb95: DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+DDS79jdWzLtE(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif uhOkAKtLVv4XTy1nWE6(u"ࠬ࡮ࡴࡵࡲࠪஏ") in DDRulV7aKN3jCOWSBQkb95.lower() and vkMRnTNV9jFm(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in DDRulV7aKN3jCOWSBQkb95 and OARzhnB9o7uYvQGFaIcZ(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in DDRulV7aKN3jCOWSBQkb95:
			if V391t7nQWUBR5euCkJ(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in DDRulV7aKN3jCOWSBQkb95 and iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in DDRulV7aKN3jCOWSBQkb95.lower():
				if L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࢀࠬஔ") not in DDRulV7aKN3jCOWSBQkb95: DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+xxpPYJOnoAUrlBzyveui(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in DDRulV7aKN3jCOWSBQkb95.lower() and Qc0l2ofbVvZDM not in [OARzhnB9o7uYvQGFaIcZ(u"ࠧࡊࡒࡗ࡚ࠬ஘"),V391t7nQWUBR5euCkJ(u"ࠨࡏ࠶࡙ࠬங")]:
				if qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡿࠫச") not in DDRulV7aKN3jCOWSBQkb95: DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+GGTRaYBDeNyI25zlF(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	zRM3tZx2v6DjJU(qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬஞ")+DDRulV7aKN3jCOWSBQkb95+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࠡ࡟ࠪட"))
	ucNYdlisCy = yOuHBDmPps3vd24cnLagiK0.ListItem()
	wwZo35QLF2NKnChmkx,CuiSrRzIOtfqKX2FPVoAcELM9gv70J,KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp,yc8hfeRS3AaQTjYNHgZxF4bMPuw,j6UVYSdO2Qy134nlvK,HG0vEntrbRUK4ZTNx,vFbKkHaJMXBA7jOL860,wwQ2RT0B6kXoUznKEAgMcd,gnrxOC2NAbLa1K0iXSlTzhVZqw = JJqxTSR6tZiQ79cpkwa3GMy(a4EuYDiRdrA)
	if Qc0l2ofbVvZDM not in [lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),IJ6VkihabRm(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: BZePF26ukosb4iTrhwIqOUERp03A = KbL94nDHufSF0VcO2Nk3(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: BZePF26ukosb4iTrhwIqOUERp03A = ddK4MmwpX5oG(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		ucNYdlisCy.setProperty(BZePF26ukosb4iTrhwIqOUERp03A, uhOkAKtLVv4XTy1nWE6(u"ࠬ࠭த"))
		ucNYdlisCy.setMimeType(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if LRjqrQYBXFVPfu<Vv0lSjAOHLfMnam3wtdor(u"࠸࠰౔"): ucNYdlisCy.setInfo(p1lrNRIXqLQJznH6O(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{Vv0lSjAOHLfMnam3wtdor(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):ddK4MmwpX5oG(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			DvMcINlRCx3fyuawhEF2nLBJ4 = ucNYdlisCy.getVideoInfoTag()
			DvMcINlRCx3fyuawhEF2nLBJ4.setMediaType(qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		ucNYdlisCy.setArt({KbL94nDHufSF0VcO2Nk3(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):j6UVYSdO2Qy134nlvK,DDS79jdWzLtE(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):j6UVYSdO2Qy134nlvK,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):j6UVYSdO2Qy134nlvK,Vv0lSjAOHLfMnam3wtdor(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):j6UVYSdO2Qy134nlvK,L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):j6UVYSdO2Qy134nlvK,DKqQekNtF6WlJLhBP9M5ca(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):j6UVYSdO2Qy134nlvK,OARzhnB9o7uYvQGFaIcZ(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):j6UVYSdO2Qy134nlvK,vkMRnTNV9jFm(u"ࠫ࡮ࡩ࡯࡯ࠩற"):j6UVYSdO2Qy134nlvK})
		if fBYse5u6VkLhmcZg in [fcIm8tvxlXZsaEY3bwuG4B(u"ࠬ࠴࡭ࡱࡦࠪல"),xxpPYJOnoAUrlBzyveui(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: ucNYdlisCy.setContentLookup(f8PVRTseIuj9BckO6GoyF5Lxv(u"࡚ࡲࡶࡧ౩"))
		else: ucNYdlisCy.setContentLookup(p1lrNRIXqLQJznH6O(u"ࡆࡢ࡮ࡶࡩ౪"))
		from IFHE2MSfi5 import ua95I6RK27wGQgmYXqc
		if ZpH2IWt7veyFobTsAnhi41(u"ࠧࡳࡶࡰࡴࠬழ") in DDRulV7aKN3jCOWSBQkb95:
			ua95I6RK27wGQgmYXqc(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),IJ6VkihabRm(u"ࡇࡣ࡯ࡷࡪ౫"))
		elif fBYse5u6VkLhmcZg==v7reLlOXCgD5pZ14w2tUA(u"ࠩ࠱ࡱࡵࡪࠧஶ") or DKqQekNtF6WlJLhBP9M5ca(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in DDRulV7aKN3jCOWSBQkb95:
			ua95I6RK27wGQgmYXqc(uhOkAKtLVv4XTy1nWE6(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),Vv0lSjAOHLfMnam3wtdor(u"ࡈࡤࡰࡸ࡫౬"))
			ucNYdlisCy.setProperty(BZePF26ukosb4iTrhwIqOUERp03A,qNZKwi2M1S4fBzGQYrmPnea(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			ucNYdlisCy.setProperty(q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࡮ࡲࡧࠫ஻"))
		if BXtacnEVOZrICJzvQGo:
			ucNYdlisCy.setSubtitles([BXtacnEVOZrICJzvQGo])
	if wwZo35QLF2NKnChmkx==DDS79jdWzLtE(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and Qc0l2ofbVvZDM==ddK4MmwpX5oG(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		q0IfRrl9AdimMsGnBcPNFu4LYz5 = qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		Qc0l2ofbVvZDM = KbL94nDHufSF0VcO2Nk3(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif wwZo35QLF2NKnChmkx==iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡼࡩࡥࡧࡲࠫீ") and wwQ2RT0B6kXoUznKEAgMcd.startswith(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭࠶ࠨு")):
		q0IfRrl9AdimMsGnBcPNFu4LYz5 = Vv0lSjAOHLfMnam3wtdor(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		Qc0l2ofbVvZDM = Qc0l2ofbVvZDM+DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡡࡇࡐࠬ௃")
	if q0IfRrl9AdimMsGnBcPNFu4LYz5!=HMO0QciekqVpLKmA(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): DZP9fVUE7eCnTgQkiYy8RFGNraAKB()
	vaRI70ESPV6ydK9UJZ43DnbhTkg = hFN2jnP4Vb90Le1g()
	if vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5: return Vv0lSjAOHLfMnam3wtdor(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	vaRI70ESPV6ydK9UJZ43DnbhTkg.JSi6pt1I5d(Qc0l2ofbVvZDM)
	if wwZo35QLF2NKnChmkx==KbL94nDHufSF0VcO2Nk3(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not wwQ2RT0B6kXoUznKEAgMcd.startswith(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬ࠼ࠧே")):
		ucNYdlisCy.setPath(DDRulV7aKN3jCOWSBQkb95)
		zRM3tZx2v6DjJU(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+ddK4MmwpX5oG(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௉")+DDRulV7aKN3jCOWSBQkb95+qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࠢࡠࠫொ"))
		LL2eGTPdkm.setResolvedUrl(EhfrVPICebQ,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࡗࡶࡺ࡫౭"),ucNYdlisCy)
	elif wwZo35QLF2NKnChmkx==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		zRM3tZx2v6DjJU(V391t7nQWUBR5euCkJ(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ்ࠬ")+DDRulV7aKN3jCOWSBQkb95+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࠦ࡝ࠨ௎"))
		vaRI70ESPV6ydK9UJZ43DnbhTkg.play(DDRulV7aKN3jCOWSBQkb95,ucNYdlisCy)
	BcMl3XdLS0zmK1jPvDJANfYH = xxpPYJOnoAUrlBzyveui(u"ࡊࡦࡲࡳࡦ౮")
	if q0IfRrl9AdimMsGnBcPNFu4LYz5==V391t7nQWUBR5euCkJ(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from tHQRiskDv2 import DM0SiqWCmxHNnFKUjI6J
		BcMl3XdLS0zmK1jPvDJANfYH = DM0SiqWCmxHNnFKUjI6J(DDRulV7aKN3jCOWSBQkb95,fBYse5u6VkLhmcZg,Qc0l2ofbVvZDM)
		if BcMl3XdLS0zmK1jPvDJANfYH: DZP9fVUE7eCnTgQkiYy8RFGNraAKB()
	else:
		GUSviMX7rNBgwVdbtf8p3ZEhaR0,q0IfRrl9AdimMsGnBcPNFu4LYz5,mmYwaCAbIBjNPdch4HyrQUu,Hl9o76IXanBxMJkwDfVbm,ttToe18Aksn = HMO0QciekqVpLKmA(u"࠰ౕ"),IJ6VkihabRm(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࡋࡧ࡬ࡴࡧ౯"),zOZvXaebGNwHKfjRA(u"࠳࠳࠴࠵౗"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠴࠲࠳࠴࠵ౖ")
		if xaqr1OyIRm: from gvn6IBeN7p import uFCykYQW68S
		while GUSviMX7rNBgwVdbtf8p3ZEhaR0<ttToe18Aksn:
			AAsbUG0jZ5igBpNKQwFrJTd.sleep(Hl9o76IXanBxMJkwDfVbm)
			GUSviMX7rNBgwVdbtf8p3ZEhaR0 += Hl9o76IXanBxMJkwDfVbm
			if vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5==DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not mmYwaCAbIBjNPdch4HyrQUu:
				if xaqr1OyIRm: uFCykYQW68S(p1lrNRIXqLQJznH6O(u"้ࠩะาࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௒"),ZpH2IWt7veyFobTsAnhi41(u"ࠪࠫ௓"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=DDS79jdWzLtE(u"࠺࠹࠵ౘ"))
				zRM3tZx2v6DjJU(v7reLlOXCgD5pZ14w2tUA(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ௕")+DDRulV7aKN3jCOWSBQkb95+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࠠ࡞ࠩ௖")+KOSl45tpWZvMdqPQs8HuTDVj)
				mmYwaCAbIBjNPdch4HyrQUu = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࡚ࡲࡶࡧ౰")
			elif vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5 in [xxBJoKG54uwQ(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),KbL94nDHufSF0VcO2Nk3(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				zRM3tZx2v6DjJU(HMO0QciekqVpLKmA(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௚")+DDRulV7aKN3jCOWSBQkb95+IJ6VkihabRm(u"ࠫࠥࡣࠧ௛")+KOSl45tpWZvMdqPQs8HuTDVj)
				break
			elif vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				zRM3tZx2v6DjJU(qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭௞")+DDRulV7aKN3jCOWSBQkb95+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࠢࡠࠫ௟")+KOSl45tpWZvMdqPQs8HuTDVj)
				if xaqr1OyIRm: uFCykYQW68S(uhOkAKtLVv4XTy1nWE6(u"ࠩไุ้ࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௠"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࠫ௡"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=DDS79jdWzLtE(u"࠵࠷࠻࠰ౙ"))
				break
			elif vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5==GGTRaYBDeNyI25zlF(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				zRM3tZx2v6DjJU(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ௤")+DDRulV7aKN3jCOWSBQkb95+qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if xaqr1OyIRm: uFCykYQW68S(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨใื่ࠥะิ฻์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ௦"),xxpPYJOnoAUrlBzyveui(u"ࠩࠪ௧"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=HMO0QciekqVpLKmA(u"࠶࠸࠵࠱ౚ"))
			zRM3tZx2v6DjJU(p1lrNRIXqLQJznH6O(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ௩")+DDRulV7aKN3jCOWSBQkb95+qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࠦ࡝ࠨ௪")+KOSl45tpWZvMdqPQs8HuTDVj)
			q0IfRrl9AdimMsGnBcPNFu4LYz5 = v7reLlOXCgD5pZ14w2tUA(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if q0IfRrl9AdimMsGnBcPNFu4LYz5 in [xxBJoKG54uwQ(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5 in [ZpH2IWt7veyFobTsAnhi41(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),Vv0lSjAOHLfMnam3wtdor(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or BcMl3XdLS0zmK1jPvDJANfYH:
		if vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5==OARzhnB9o7uYvQGFaIcZ(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): Qc0l2ofbVvZDM = Qc0l2ofbVvZDM+GGTRaYBDeNyI25zlF(u"ࠫࡤ࡚ࡓࠨ௰")
		djr0g3VkMzo1ehxE = ce30uS4tawJ26EdhVnxjp1(Qc0l2ofbVvZDM)
	else: exec(L91nVzxH4hYrgPDsOuljXd0J(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return vaRI70ESPV6ydK9UJZ43DnbhTkg.q0IfRrl9AdimMsGnBcPNFu4LYz5
def H93DlbtKLEarfQ8w7GcoIukSexv0J(DDRulV7aKN3jCOWSBQkb95):
	fBYse5u6VkLhmcZg = QPuHKNAT4jmCRg.findall(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴ࡡࡢࡥࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭௲"),DDRulV7aKN3jCOWSBQkb95.lower(),QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	fBYse5u6VkLhmcZg = fBYse5u6VkLhmcZg[HMO0QciekqVpLKmA(u"࠶౛")][HMO0QciekqVpLKmA(u"࠶౛")] if fBYse5u6VkLhmcZg else IJ6VkihabRm(u"ࠧࠨ௳")
	return fBYse5u6VkLhmcZg
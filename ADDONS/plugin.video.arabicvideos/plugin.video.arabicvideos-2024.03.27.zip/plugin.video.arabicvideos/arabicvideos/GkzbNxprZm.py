# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
from PIL import ImageDraw as uIVUl3LvOfkK2NoGzq,ImageFont as LFgRCWvkM8hAD,Image as KlXvBMj7oFRhLxW3OpCI2s
from arabic_reshaper import ArabicReshaper as u3spdvWxnetUMfwPGoR
amlcehCxU3O2yoGf = 'EXCLUDES'
def B7OmH4ruFDi8VqY1KGZyLz(pphVUbJkGtHXndg84iZl2DPImSzoC,Ll7oCKWD2zrGV3cStkHj8):
	Ll7oCKWD2zrGV3cStkHj8 = Ll7oCKWD2zrGV3cStkHj8.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	BxymhVIivYGu50qZgwbrTLf8lWdjQp = QPuHKNAT4jmCRg.findall('[a-zA-Z]',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
	if 'بحث IPTV - ' in pphVUbJkGtHXndg84iZl2DPImSzoC: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('بحث IPTV - ',lc6sH83woipUCaLnRVAkgtrEJd257+'بحث IPTV - '+lc6sH83woipUCaLnRVAkgtrEJd257)
	elif ' IPTV' in pphVUbJkGtHXndg84iZl2DPImSzoC and Ll7oCKWD2zrGV3cStkHj8=='IPT': pphVUbJkGtHXndg84iZl2DPImSzoC = lc6sH83woipUCaLnRVAkgtrEJd257+pphVUbJkGtHXndg84iZl2DPImSzoC
	elif 'بحث M3U - ' in pphVUbJkGtHXndg84iZl2DPImSzoC: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('بحث M3U - ',lc6sH83woipUCaLnRVAkgtrEJd257+'بحث M3U - '+lc6sH83woipUCaLnRVAkgtrEJd257)
	elif ' M3U' in pphVUbJkGtHXndg84iZl2DPImSzoC and Ll7oCKWD2zrGV3cStkHj8=='M3U': pphVUbJkGtHXndg84iZl2DPImSzoC = lc6sH83woipUCaLnRVAkgtrEJd257+pphVUbJkGtHXndg84iZl2DPImSzoC
	elif 'بحث ' in pphVUbJkGtHXndg84iZl2DPImSzoC and ' - ' in pphVUbJkGtHXndg84iZl2DPImSzoC: pphVUbJkGtHXndg84iZl2DPImSzoC = lc6sH83woipUCaLnRVAkgtrEJd257+pphVUbJkGtHXndg84iZl2DPImSzoC
	elif not BxymhVIivYGu50qZgwbrTLf8lWdjQp:
		Dq7tZh2W3YLcvEXp0UjQSV6wPBT5H = QPuHKNAT4jmCRg.findall('^( *?)(.*?)( *?)$',pphVUbJkGtHXndg84iZl2DPImSzoC)
		L4CKnkUSGifhR1jwoIJ8pu5c,caQYHjyRKnEBUu5bkmFAz2,ttgHmCdzRUIfpKuQ1VN42BeO6 = Dq7tZh2W3YLcvEXp0UjQSV6wPBT5H[0]
		qTCgHS2bnABmJeocy = QPuHKNAT4jmCRg.findall('^([!-~])',caQYHjyRKnEBUu5bkmFAz2)
		if qTCgHS2bnABmJeocy: pphVUbJkGtHXndg84iZl2DPImSzoC = L4CKnkUSGifhR1jwoIJ8pu5c+Pc98uK2GLvfMwq6UtyJSHe03g+caQYHjyRKnEBUu5bkmFAz2+ttgHmCdzRUIfpKuQ1VN42BeO6
		else: pphVUbJkGtHXndg84iZl2DPImSzoC = ttgHmCdzRUIfpKuQ1VN42BeO6+lc6sH83woipUCaLnRVAkgtrEJd257+caQYHjyRKnEBUu5bkmFAz2+L4CKnkUSGifhR1jwoIJ8pu5c
	else:
		if 1:
			yTUBd2DEnXwNZGICo0 = pphVUbJkGtHXndg84iZl2DPImSzoC
			zTWK2JSBfRDiHnOMg7XbFel = GGgun1VSbfq8edk62vLxB.get_display(pphVUbJkGtHXndg84iZl2DPImSzoC,base_dir='L')
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: yTUBd2DEnXwNZGICo0 = yTUBd2DEnXwNZGICo0.decode('utf8')
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: zTWK2JSBfRDiHnOMg7XbFel = zTWK2JSBfRDiHnOMg7XbFel.decode('utf8')
			DrLhjmsXCcQ7k89FyROuqbTd6nPAS = yTUBd2DEnXwNZGICo0.split(' ')
			xkLfJvbg9Y4HujqMw5sX0RaVmt = zTWK2JSBfRDiHnOMg7XbFel.split(' ')
			epF5owuMDZWyx7qJjV,uk6SiDadQIn,zhi5vdW9nok,GyRUTPvL2c0i3HpDs1erx7 = [],[],'',''
			BLxX0ncR1rtZpQfamK = zip(DrLhjmsXCcQ7k89FyROuqbTd6nPAS,xkLfJvbg9Y4HujqMw5sX0RaVmt)
			for dFQzGXTZUjNsAH26CW0,EElFOiQUP3uq in BLxX0ncR1rtZpQfamK:
				if dFQzGXTZUjNsAH26CW0==EElFOiQUP3uq=='' and GyRUTPvL2c0i3HpDs1erx7:
					zhi5vdW9nok += ' '
					continue
				if dFQzGXTZUjNsAH26CW0==EElFOiQUP3uq:
					anr7TbEM4v = 'EN'
					if GyRUTPvL2c0i3HpDs1erx7==anr7TbEM4v: zhi5vdW9nok += ' '+dFQzGXTZUjNsAH26CW0
					elif dFQzGXTZUjNsAH26CW0:
						if zhi5vdW9nok:
							uk6SiDadQIn.append(zhi5vdW9nok)
							epF5owuMDZWyx7qJjV.append('')
						zhi5vdW9nok = dFQzGXTZUjNsAH26CW0
				else:
					anr7TbEM4v = 'AR'
					if GyRUTPvL2c0i3HpDs1erx7==anr7TbEM4v: zhi5vdW9nok += ' '+dFQzGXTZUjNsAH26CW0
					elif dFQzGXTZUjNsAH26CW0:
						if zhi5vdW9nok:
							epF5owuMDZWyx7qJjV.append(zhi5vdW9nok)
							uk6SiDadQIn.append('')
						zhi5vdW9nok = dFQzGXTZUjNsAH26CW0
				GyRUTPvL2c0i3HpDs1erx7 = anr7TbEM4v
			if anr7TbEM4v=='EN':
				epF5owuMDZWyx7qJjV.append(zhi5vdW9nok)
				uk6SiDadQIn.append('')
			else:
				uk6SiDadQIn.append(zhi5vdW9nok)
				epF5owuMDZWyx7qJjV.append('')
			DCSvTJ9pqU1if2x4mct3 = ''
			BLxX0ncR1rtZpQfamK = zip(epF5owuMDZWyx7qJjV,uk6SiDadQIn)
			for VPrd0GR7j1UMcFB9sOuK8C5S6qXi4,ppYT1xl9CMW3JsGXDSRqgcPur in BLxX0ncR1rtZpQfamK:
				if VPrd0GR7j1UMcFB9sOuK8C5S6qXi4: DCSvTJ9pqU1if2x4mct3 += ' '+VPrd0GR7j1UMcFB9sOuK8C5S6qXi4
				else:
					qTCgHS2bnABmJeocy = QPuHKNAT4jmCRg.findall('([!-~]) *$',ppYT1xl9CMW3JsGXDSRqgcPur)
					if qTCgHS2bnABmJeocy:
						qTCgHS2bnABmJeocy = qTCgHS2bnABmJeocy[0]
						try:
							dnuw89atJgbpFINh = N6MITLGyr4dlgqDA.MIRRORED[qTCgHS2bnABmJeocy]
							Dq7tZh2W3YLcvEXp0UjQSV6wPBT5H = QPuHKNAT4jmCRg.findall('^( *?)(.*?)( *?)$',ppYT1xl9CMW3JsGXDSRqgcPur)
							if Dq7tZh2W3YLcvEXp0UjQSV6wPBT5H: L4CKnkUSGifhR1jwoIJ8pu5c,ppYT1xl9CMW3JsGXDSRqgcPur,ttgHmCdzRUIfpKuQ1VN42BeO6 = Dq7tZh2W3YLcvEXp0UjQSV6wPBT5H[0]
							ppYT1xl9CMW3JsGXDSRqgcPur = L4CKnkUSGifhR1jwoIJ8pu5c+dnuw89atJgbpFINh+ppYT1xl9CMW3JsGXDSRqgcPur[:-1]+ttgHmCdzRUIfpKuQ1VN42BeO6
						except: pass
					DCSvTJ9pqU1if2x4mct3 += ' '+ppYT1xl9CMW3JsGXDSRqgcPur
			pphVUbJkGtHXndg84iZl2DPImSzoC = DCSvTJ9pqU1if2x4mct3[1:]
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.encode('utf8')
		else:
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.decode('utf8')
			pphVUbJkGtHXndg84iZl2DPImSzoC = GGgun1VSbfq8edk62vLxB.get_display(pphVUbJkGtHXndg84iZl2DPImSzoC)
			yTUBd2DEnXwNZGICo0,zTWK2JSBfRDiHnOMg7XbFel = pphVUbJkGtHXndg84iZl2DPImSzoC,pphVUbJkGtHXndg84iZl2DPImSzoC
			if 1:
				GyRUTPvL2c0i3HpDs1erx7,p2TkDxBa189htwYFsgdWqJZce = '',[]
				oSDtuAskBbw7 = pphVUbJkGtHXndg84iZl2DPImSzoC.split(' ')
				for JNpHSTG5fRsncZtq in oSDtuAskBbw7:
					if not JNpHSTG5fRsncZtq:
						if p2TkDxBa189htwYFsgdWqJZce: p2TkDxBa189htwYFsgdWqJZce[-1] += ' '
						else: p2TkDxBa189htwYFsgdWqJZce.append('')
						continue
					gtST0BfZEw3cVLhel9nrR = QPuHKNAT4jmCRg.findall('[!-~]',JNpHSTG5fRsncZtq[0])
					if gtST0BfZEw3cVLhel9nrR==GyRUTPvL2c0i3HpDs1erx7 and p2TkDxBa189htwYFsgdWqJZce: p2TkDxBa189htwYFsgdWqJZce[-1] += ' '+JNpHSTG5fRsncZtq
					else:
						if p2TkDxBa189htwYFsgdWqJZce:
							EOkT7IxjAeLSm820 = QPuHKNAT4jmCRg.findall('[^!-~]',p2TkDxBa189htwYFsgdWqJZce[-1])
							if EOkT7IxjAeLSm820:
								p2TkDxBa189htwYFsgdWqJZce[-1] = GGgun1VSbfq8edk62vLxB.get_display(p2TkDxBa189htwYFsgdWqJZce[-1])
								fKeL8TaUq9kH3irnvhp70G = QPuHKNAT4jmCRg.findall('^ +',p2TkDxBa189htwYFsgdWqJZce[-1])
								if fKeL8TaUq9kH3irnvhp70G: p2TkDxBa189htwYFsgdWqJZce[-1] = p2TkDxBa189htwYFsgdWqJZce[-1].lstrip(' ')+fKeL8TaUq9kH3irnvhp70G[0]
						p2TkDxBa189htwYFsgdWqJZce.append(JNpHSTG5fRsncZtq)
					GyRUTPvL2c0i3HpDs1erx7 = gtST0BfZEw3cVLhel9nrR
				if p2TkDxBa189htwYFsgdWqJZce: p2TkDxBa189htwYFsgdWqJZce[-1] = GGgun1VSbfq8edk62vLxB.get_display(p2TkDxBa189htwYFsgdWqJZce[-1])
				pphVUbJkGtHXndg84iZl2DPImSzoC = ' '.join(p2TkDxBa189htwYFsgdWqJZce)
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.encode('utf8')
	return pphVUbJkGtHXndg84iZl2DPImSzoC
def vWnPs3MOUKJCFGz(Gi8FAfgwEsPZ,rESAa7hdYKbq6l,hh2TYMvyPrWw17Vn):
	ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,gG3RHyAzZ26kmTbh8M7WKFqx19,lOekXhDpwcRAjvIy7,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo = Gi8FAfgwEsPZ
	Q6FbqZ9uIe8v2xaTHhfDCJ = int(Q6FbqZ9uIe8v2xaTHhfDCJ)
	w3XPQyaqYg2h = QPuHKNAT4jmCRg.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
	if w3XPQyaqYg2h:
		w3XPQyaqYg2h,A0HDETiub9mzLa8,YYzPm8OIEQ0UMKLZhTR = w3XPQyaqYg2h[0]
		pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace(w3XPQyaqYg2h,'')
	N5NqUDsWGbJXC = pphVUbJkGtHXndg84iZl2DPImSzoC
	Ll7oCKWD2zrGV3cStkHj8 = QPuHKNAT4jmCRg.findall('^_(\w\w\w)_(.*?)$',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
	if Ll7oCKWD2zrGV3cStkHj8:
		Ll7oCKWD2zrGV3cStkHj8,pphVUbJkGtHXndg84iZl2DPImSzoC = Ll7oCKWD2zrGV3cStkHj8[0]
		CIktBLscpMQnzNea135WYvdE = '_MOD_' in pphVUbJkGtHXndg84iZl2DPImSzoC
		vknQOmFaRT7sxDcr1zZyNGtBuA = ghLJETx5pD7=='folder'
		if CIktBLscpMQnzNea135WYvdE and vknQOmFaRT7sxDcr1zZyNGtBuA: UAoKrdqaMm = ';'
		elif CIktBLscpMQnzNea135WYvdE and not vknQOmFaRT7sxDcr1zZyNGtBuA: UAoKrdqaMm = ICxkgfWtNMBHQ40co8VsjFO
		elif not CIktBLscpMQnzNea135WYvdE and vknQOmFaRT7sxDcr1zZyNGtBuA: UAoKrdqaMm = ','
		elif not CIktBLscpMQnzNea135WYvdE and not vknQOmFaRT7sxDcr1zZyNGtBuA: UAoKrdqaMm = ' '
		pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('_MOD_','')
		Ll7oCKWD2zrGV3cStkHj8 = UAoKrdqaMm+'[COLOR FFC89008]'+Ll7oCKWD2zrGV3cStkHj8+' [/COLOR]'
	else: Ll7oCKWD2zrGV3cStkHj8 = ''
	if w3XPQyaqYg2h:
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			w3XPQyaqYg2h = '[COLOR FFFFFF00]'+A0HDETiub9mzLa8+' '+YYzPm8OIEQ0UMKLZhTR+'[/COLOR]'
			if Ll7oCKWD2zrGV3cStkHj8: pphVUbJkGtHXndg84iZl2DPImSzoC = w3XPQyaqYg2h+' '+lc6sH83woipUCaLnRVAkgtrEJd257+Ll7oCKWD2zrGV3cStkHj8+pphVUbJkGtHXndg84iZl2DPImSzoC
			else: pphVUbJkGtHXndg84iZl2DPImSzoC = w3XPQyaqYg2h+lc6sH83woipUCaLnRVAkgtrEJd257+pphVUbJkGtHXndg84iZl2DPImSzoC+' '
		elif Nnxm30dfoBWRYpIC7KsQGl:
			if Ll7oCKWD2zrGV3cStkHj8:
				w3XPQyaqYg2h = '[COLOR FFFFFF00]'+A0HDETiub9mzLa8+' '+YYzPm8OIEQ0UMKLZhTR+'[/COLOR]'
				pphVUbJkGtHXndg84iZl2DPImSzoC = w3XPQyaqYg2h+' '+Ll7oCKWD2zrGV3cStkHj8+pphVUbJkGtHXndg84iZl2DPImSzoC
			else:
				w3XPQyaqYg2h = '[COLOR FFFFFF00]'+YYzPm8OIEQ0UMKLZhTR+' '+A0HDETiub9mzLa8+'[/COLOR]'
				pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC+' '+lc6sH83woipUCaLnRVAkgtrEJd257+w3XPQyaqYg2h
	elif Ll7oCKWD2zrGV3cStkHj8:
		pphVUbJkGtHXndg84iZl2DPImSzoC = B7OmH4ruFDi8VqY1KGZyLz(pphVUbJkGtHXndg84iZl2DPImSzoC,Ll7oCKWD2zrGV3cStkHj8)
		pphVUbJkGtHXndg84iZl2DPImSzoC = Ll7oCKWD2zrGV3cStkHj8+pphVUbJkGtHXndg84iZl2DPImSzoC
	Gi8FAfgwEsPZ = ghLJETx5pD7,N5NqUDsWGbJXC,HbqSfZ6m7FAa,str(Q6FbqZ9uIe8v2xaTHhfDCJ),IsMuwXCDji,gG3RHyAzZ26kmTbh8M7WKFqx19,lOekXhDpwcRAjvIy7,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo
	ZBqJ0vHYpaS4RsgMmAc = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	ZBqJ0vHYpaS4RsgMmAc['name'] = oF0Yr4V7Ic(N5NqUDsWGbJXC)
	ZBqJ0vHYpaS4RsgMmAc['type'] = ghLJETx5pD7.strip(' ')
	ZBqJ0vHYpaS4RsgMmAc['mode'] = str(Q6FbqZ9uIe8v2xaTHhfDCJ).strip(' ')
	if ghLJETx5pD7=='folder' and gG3RHyAzZ26kmTbh8M7WKFqx19: ZBqJ0vHYpaS4RsgMmAc['page'] = oF0Yr4V7Ic(gG3RHyAzZ26kmTbh8M7WKFqx19.strip(' '))
	if C32AEk8uZTeFPI94LG6dmczv: ZBqJ0vHYpaS4RsgMmAc['context'] = C32AEk8uZTeFPI94LG6dmczv.strip(' ')
	if lOekXhDpwcRAjvIy7: ZBqJ0vHYpaS4RsgMmAc['text'] = oF0Yr4V7Ic(lOekXhDpwcRAjvIy7.strip(' '))
	if IsMuwXCDji: ZBqJ0vHYpaS4RsgMmAc['image'] = oF0Yr4V7Ic(IsMuwXCDji.strip(' '))
	if T1zaK6eDkFcyCBldWR3YMuJgIQo:
		T1zaK6eDkFcyCBldWR3YMuJgIQo = str(T1zaK6eDkFcyCBldWR3YMuJgIQo)
		ZBqJ0vHYpaS4RsgMmAc['infodict'] = oF0Yr4V7Ic(T1zaK6eDkFcyCBldWR3YMuJgIQo.strip(' '))
		T1zaK6eDkFcyCBldWR3YMuJgIQo = eval(T1zaK6eDkFcyCBldWR3YMuJgIQo)
	else: T1zaK6eDkFcyCBldWR3YMuJgIQo = {}
	if HbqSfZ6m7FAa: ZBqJ0vHYpaS4RsgMmAc['url'] = oF0Yr4V7Ic(HbqSfZ6m7FAa.strip(' '))
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	PI1k48oNQ2mwLdij7lU = []
	Y8Dx1rsCOdqeoJczaQIA = 'plugin://'+M0J6Pq3bH2+'/?type='+ZBqJ0vHYpaS4RsgMmAc['type']+'&mode='+ZBqJ0vHYpaS4RsgMmAc['mode']
	if ZBqJ0vHYpaS4RsgMmAc['page']: Y8Dx1rsCOdqeoJczaQIA += '&page='+ZBqJ0vHYpaS4RsgMmAc['page']
	if ZBqJ0vHYpaS4RsgMmAc['name']: Y8Dx1rsCOdqeoJczaQIA += '&name='+ZBqJ0vHYpaS4RsgMmAc['name']
	if ZBqJ0vHYpaS4RsgMmAc['text']: Y8Dx1rsCOdqeoJczaQIA += '&text='+ZBqJ0vHYpaS4RsgMmAc['text']
	if ZBqJ0vHYpaS4RsgMmAc['infodict']: Y8Dx1rsCOdqeoJczaQIA += '&infodict='+ZBqJ0vHYpaS4RsgMmAc['infodict']
	if ZBqJ0vHYpaS4RsgMmAc['image']: Y8Dx1rsCOdqeoJczaQIA += '&image='+ZBqJ0vHYpaS4RsgMmAc['image']
	if ZBqJ0vHYpaS4RsgMmAc['url']: Y8Dx1rsCOdqeoJczaQIA += '&url='+ZBqJ0vHYpaS4RsgMmAc['url']
	if Q6FbqZ9uIe8v2xaTHhfDCJ!=265: CCWTVuybzaFHqsL8OAEg3lnR1ifrc['favorites'] = True
	else: CCWTVuybzaFHqsL8OAEg3lnR1ifrc['favorites'] = False
	if ZBqJ0vHYpaS4RsgMmAc['context']: Y8Dx1rsCOdqeoJczaQIA += '&context='+ZBqJ0vHYpaS4RsgMmAc['context']
	if Q6FbqZ9uIe8v2xaTHhfDCJ in [235,238] and ghLJETx5pD7=='live' and 'EPG' in C32AEk8uZTeFPI94LG6dmczv:
		igpmSxnKFcMyDAGvXw3oe = 'plugin://'+M0J6Pq3bH2+'?mode=238&text=SHORT_EPG&url='+HbqSfZ6m7FAa
		fQgnqKtSb6 = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
		PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	if Q6FbqZ9uIe8v2xaTHhfDCJ==265:
		gWERLS6zcOC2FPt5b4xrfuDm0l1nUi = rESAa7hdYKbq6l(lOekXhDpwcRAjvIy7,True)
		if gWERLS6zcOC2FPt5b4xrfuDm0l1nUi>0:
			igpmSxnKFcMyDAGvXw3oe = 'plugin://'+M0J6Pq3bH2+'?mode=266&text='+lOekXhDpwcRAjvIy7
			fQgnqKtSb6 = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+S6YzAlHWcCwJI18(lOekXhDpwcRAjvIy7)+'[/COLOR]'
			n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
			PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	if ghLJETx5pD7=='video' and Q6FbqZ9uIe8v2xaTHhfDCJ!=331:
		igpmSxnKFcMyDAGvXw3oe = Y8Dx1rsCOdqeoJczaQIA+'&context=6_DOWNLOAD'
		fQgnqKtSb6 = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
		PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	if Q6FbqZ9uIe8v2xaTHhfDCJ==331:
		igpmSxnKFcMyDAGvXw3oe = Y8Dx1rsCOdqeoJczaQIA+'&context=6_DELETE'
		fQgnqKtSb6 = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
		PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	if ghLJETx5pD7=='folder' and Q6FbqZ9uIe8v2xaTHhfDCJ==540:
		dOQf3uY85PhxzU2CVqKNXokml1S = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','GLOBALSEARCH_SITES')
		if dOQf3uY85PhxzU2CVqKNXokml1S:
			igpmSxnKFcMyDAGvXw3oe = 'plugin://'+M0J6Pq3bH2+'?context=7'
			fQgnqKtSb6 = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
			PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	FUTf5SxlRuVIXrm7bGa0hB = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if Q6FbqZ9uIe8v2xaTHhfDCJ not in FUTf5SxlRuVIXrm7bGa0hB:
		igpmSxnKFcMyDAGvXw3oe = 'plugin://'+M0J6Pq3bH2+'?context=8&mode=260'
		fQgnqKtSb6 = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
		PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	VVSG3gpcui0lNK1wCndhkjXsLa = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if Q6FbqZ9uIe8v2xaTHhfDCJ%10 and Q6FbqZ9uIe8v2xaTHhfDCJ!=9990:
		WXoFIsvhxfM5ugPj3 = Q6FbqZ9uIe8v2xaTHhfDCJ-Q6FbqZ9uIe8v2xaTHhfDCJ%10
		if WXoFIsvhxfM5ugPj3==280: WXoFIsvhxfM5ugPj3 = 230
		if WXoFIsvhxfM5ugPj3==410: WXoFIsvhxfM5ugPj3 = 400
		if WXoFIsvhxfM5ugPj3==520: WXoFIsvhxfM5ugPj3 = 510
		if WXoFIsvhxfM5ugPj3 not in VVSG3gpcui0lNK1wCndhkjXsLa:
			igpmSxnKFcMyDAGvXw3oe = 'plugin://'+M0J6Pq3bH2+'?context=8&mode='+str(WXoFIsvhxfM5ugPj3)
			fQgnqKtSb6 = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
			PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	igpmSxnKFcMyDAGvXw3oe = Y8Dx1rsCOdqeoJczaQIA+'&context=9'
	fQgnqKtSb6 = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	n6xqDAvg38i4Q = (fQgnqKtSb6,'RunPlugin('+igpmSxnKFcMyDAGvXw3oe+')')
	PI1k48oNQ2mwLdij7lU.append(n6xqDAvg38i4Q)
	if ghLJETx5pD7 in ['link','video','live']: buKpnTBErN0PFmZz69c = False
	elif ghLJETx5pD7=='folder': buKpnTBErN0PFmZz69c = True
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['name'] = pphVUbJkGtHXndg84iZl2DPImSzoC
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['context_menu'] = PI1k48oNQ2mwLdij7lU
	if 'plot' in list(T1zaK6eDkFcyCBldWR3YMuJgIQo.keys()): CCWTVuybzaFHqsL8OAEg3lnR1ifrc['plot'] = T1zaK6eDkFcyCBldWR3YMuJgIQo['plot']
	if 'stars' in list(T1zaK6eDkFcyCBldWR3YMuJgIQo.keys()): CCWTVuybzaFHqsL8OAEg3lnR1ifrc['stars'] = T1zaK6eDkFcyCBldWR3YMuJgIQo['stars']
	if IsMuwXCDji: CCWTVuybzaFHqsL8OAEg3lnR1ifrc['image'] = IsMuwXCDji
	if ghLJETx5pD7=='video' and gG3RHyAzZ26kmTbh8M7WKFqx19:
		TlHOFn2rpj0Jh9MsWxfNgGd = QPuHKNAT4jmCRg.findall('[\d:]+',gG3RHyAzZ26kmTbh8M7WKFqx19,QPuHKNAT4jmCRg.DOTALL)
		if TlHOFn2rpj0Jh9MsWxfNgGd:
			TlHOFn2rpj0Jh9MsWxfNgGd = '0:0:0:0:0:'+TlHOFn2rpj0Jh9MsWxfNgGd[0]
			LLNfYeyZwd6283Ssrol9,IIgxFYkqjKvJuZcAM,nneC5kz6gHpxb2ONMwt3qds,t2wk0TYoLX6PrO4Sp9,WltBDxrFiEa2wPQJ = TlHOFn2rpj0Jh9MsWxfNgGd.rsplit(':',4)
			K81Ke6chFEsWOx = int(IIgxFYkqjKvJuZcAM)*24*PVQeMKFimjdzY1OTqab+int(nneC5kz6gHpxb2ONMwt3qds)*PVQeMKFimjdzY1OTqab+int(t2wk0TYoLX6PrO4Sp9)*60+int(WltBDxrFiEa2wPQJ)
			CCWTVuybzaFHqsL8OAEg3lnR1ifrc['duration'] = K81Ke6chFEsWOx
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['type'] = ghLJETx5pD7
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['isFolder'] = buKpnTBErN0PFmZz69c
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['newpath'] = Y8Dx1rsCOdqeoJczaQIA
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['menuItem'] = Gi8FAfgwEsPZ
	CCWTVuybzaFHqsL8OAEg3lnR1ifrc['mode'] = Q6FbqZ9uIe8v2xaTHhfDCJ
	return CCWTVuybzaFHqsL8OAEg3lnR1ifrc
def cFz8kLSvVWhX7Pqamu6jtb1n(rESAa7hdYKbq6l):
	NjRlK6eUJOIgpXACuF = []
	from pKTdzCL61S import Gmw6J5PRDV7kStnI0KzH9oa,yFAKIp45tgeszSo1hLX7nVxMEC
	hh2TYMvyPrWw17Vn = Gmw6J5PRDV7kStnI0KzH9oa()
	for Gi8FAfgwEsPZ in vvruH9wsBDfbhFtyq1MUd2zV:
		CCWTVuybzaFHqsL8OAEg3lnR1ifrc = vWnPs3MOUKJCFGz(Gi8FAfgwEsPZ,rESAa7hdYKbq6l,hh2TYMvyPrWw17Vn)
		if CCWTVuybzaFHqsL8OAEg3lnR1ifrc['favorites']:
			eHW5tqBndIob3yp6w8AEa = yFAKIp45tgeszSo1hLX7nVxMEC(hh2TYMvyPrWw17Vn,CCWTVuybzaFHqsL8OAEg3lnR1ifrc['menuItem'],CCWTVuybzaFHqsL8OAEg3lnR1ifrc['newpath'])
			CCWTVuybzaFHqsL8OAEg3lnR1ifrc['context_menu'] = eHW5tqBndIob3yp6w8AEa+CCWTVuybzaFHqsL8OAEg3lnR1ifrc['context_menu']
		NjRlK6eUJOIgpXACuF.append(CCWTVuybzaFHqsL8OAEg3lnR1ifrc)
	return NjRlK6eUJOIgpXACuF
def lL4YDV2HKj7CiPAfG1Orm3M8ycI6J(kM2FOrWe9XhQVaDI):
	UAoKrdqaMm,nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw, = [],''
	for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
		if not ssAiraohPKc5XpOjnI: UAoKrdqaMm.append('')
		else: break
	kM2FOrWe9XhQVaDI = kM2FOrWe9XhQVaDI[len(UAoKrdqaMm):]
	OO1XlVPzfQrMTmJv = '\n\n\n\n'.join(kM2FOrWe9XhQVaDI)
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('===== ===== =====','000001')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR FFC89008]','000002')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR FFFFFF00]','000003')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[/COLOR]','000004')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[RIGHT]','000005')
	we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk = 100000
	llYJbfN9hpAHcs6LaVkTd2W80D = {}
	cgzj5pL2I1hwHVSWAtu8 = QPuHKNAT4jmCRg.findall('http.*?[\r\n ]',OO1XlVPzfQrMTmJv,QPuHKNAT4jmCRg.DOTALL)
	for MmsNLcGiRpyC1x2VF in cgzj5pL2I1hwHVSWAtu8:
		we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk += 1
		OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace(MmsNLcGiRpyC1x2VF,str(we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk))
		llYJbfN9hpAHcs6LaVkTd2W80D[str(we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk)] = MmsNLcGiRpyC1x2VF
	for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(0,len(OO1XlVPzfQrMTmJv),4800):
		uDtXIpV61nlUA7fBQj0F3Y2MPE9J5O = OO1XlVPzfQrMTmJv[gI689nKoH2PlifU3AMW5vVEZpFYX1:gI689nKoH2PlifU3AMW5vVEZpFYX1+4800]
		LGivCYufsSNw0qmdjxEFXKDR3UlM4 = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.code')
		HbqSfZ6m7FAa = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+LGivCYufsSNw0qmdjxEFXKDR3UlM4
		JWZYMU9luoKCAD7ybSBQ = {'Content-Type':'text/plain'}
		UT2HOni53GWMsxv4oJzLgch = uDtXIpV61nlUA7fBQj0F3Y2MPE9J5O.encode('utf8')
		vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',HbqSfZ6m7FAa,UT2HOni53GWMsxv4oJzLgch,JWZYMU9luoKCAD7ybSBQ,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if vqUSBHDtn5Rl6Vyc8.succeeded:
			F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
			nnqJBQZdcbEax = kMLWTt2fO9dnGDUgHh('str',F3FUSpn5ZHPu6iwQ1sr8)
			if nnqJBQZdcbEax:
				nnqJBQZdcbEax = nnqJBQZdcbEax['translation']
				nnqJBQZdcbEax = kWfpQA7tTjSPyLbNIeMr1Hui5(nnqJBQZdcbEax)
				for RP8pdTOZKWQev0LGXrzxVhAm in range(len(nnqJBQZdcbEax)):
					nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw += nnqJBQZdcbEax[RP8pdTOZKWQev0LGXrzxVhAm][0]
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000001','===== ===== =====')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000002','[COLOR FFC89008]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000003','[COLOR FFFFFF00]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000004','[/COLOR]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000005','[RIGHT]')
	for we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk in list(llYJbfN9hpAHcs6LaVkTd2W80D.keys()):
		MmsNLcGiRpyC1x2VF = llYJbfN9hpAHcs6LaVkTd2W80D[we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk]
		nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace(we8hpZjGiaqmXcRbSvF2AgDWP7Ozfk,MmsNLcGiRpyC1x2VF)
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.split('\n\n\n\n')
	return UAoKrdqaMm+nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw
def k4v2gt3Vu7pMIOFRZ185Ge(kM2FOrWe9XhQVaDI):
	UAoKrdqaMm,nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw, = [],''
	for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
		if not ssAiraohPKc5XpOjnI: UAoKrdqaMm.append('')
		else: break
	kM2FOrWe9XhQVaDI = kM2FOrWe9XhQVaDI[len(UAoKrdqaMm):]
	OO1XlVPzfQrMTmJv = '\\n\\n\\n\\n'.join(kM2FOrWe9XhQVaDI)
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('كلا','no')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('استمرار','continue')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('===== ===== =====','000001')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR FFC89008]','000002')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR FFFFFF00]','000003')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[/COLOR]','000004')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[RIGHT]','000005')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[CENTER]','000006')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[RTL]','000007')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace("'","\\\\\\'")
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('"','\\\\\\"')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('\n','\\n')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('\r','\\\\r')
	for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(0,len(OO1XlVPzfQrMTmJv),4800):
		uDtXIpV61nlUA7fBQj0F3Y2MPE9J5O = OO1XlVPzfQrMTmJv[gI689nKoH2PlifU3AMW5vVEZpFYX1:gI689nKoH2PlifU3AMW5vVEZpFYX1+4800]
		HbqSfZ6m7FAa = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		JWZYMU9luoKCAD7ybSBQ = {'Content-Type':'application/x-www-form-urlencoded'}
		LGivCYufsSNw0qmdjxEFXKDR3UlM4 = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.code')
		UT2HOni53GWMsxv4oJzLgch = 'f.req='+oF0Yr4V7Ic('[[["MkEWBc","[[\\"'+uDtXIpV61nlUA7fBQj0F3Y2MPE9J5O+'\\",\\"ar\\",\\"'+LGivCYufsSNw0qmdjxEFXKDR3UlM4+'\\",1],[]]",null,"generic"]]]','')
		UT2HOni53GWMsxv4oJzLgch = UT2HOni53GWMsxv4oJzLgch.replace('%5Cn','%5C%5Cn')
		vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',HbqSfZ6m7FAa,UT2HOni53GWMsxv4oJzLgch,JWZYMU9luoKCAD7ybSBQ,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if vqUSBHDtn5Rl6Vyc8.succeeded:
			F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
			F3FUSpn5ZHPu6iwQ1sr8 = F3FUSpn5ZHPu6iwQ1sr8.split('\n')[-1]
			nnqJBQZdcbEax = kMLWTt2fO9dnGDUgHh('str',F3FUSpn5ZHPu6iwQ1sr8)[0][2]
			if nnqJBQZdcbEax:
				nnqJBQZdcbEax = kMLWTt2fO9dnGDUgHh('str',nnqJBQZdcbEax)[1][0][0][5]
				nnqJBQZdcbEax = kWfpQA7tTjSPyLbNIeMr1Hui5(nnqJBQZdcbEax)
				for RP8pdTOZKWQev0LGXrzxVhAm in range(len(nnqJBQZdcbEax)):
					nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw += nnqJBQZdcbEax[RP8pdTOZKWQev0LGXrzxVhAm][0]
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('00000','0000').replace('0000','000')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0001','===== ===== =====')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0002','[COLOR FFC89008]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0003','[COLOR FFFFFF00]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0004','[/COLOR]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0005','[RIGHT]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0006','[CENTER]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0007','[RTL]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.split('\n\n\n\n')
	return UAoKrdqaMm+nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw
def xCqeXzb2Hj36n(kM2FOrWe9XhQVaDI):
	UAoKrdqaMm,so7KUfDgj5cLVa2FwI3AQHTzuR = [],[]
	for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
		if not ssAiraohPKc5XpOjnI: UAoKrdqaMm.append('')
		else: break
	kM2FOrWe9XhQVaDI = kM2FOrWe9XhQVaDI[len(UAoKrdqaMm):]
	OO1XlVPzfQrMTmJv = '\n\n\n\n'.join(kM2FOrWe9XhQVaDI)
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('كلا','no')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('استمرار','continue')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('أدناه','below')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR FFC89008]','00001')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR FFFFFF00]','00002')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[/COLOR]','00003')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('=====','00004')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace(',','00005')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[RTL]','00009')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[CENTER]','0000A')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('\r','0000B')
	kM2FOrWe9XhQVaDI = OO1XlVPzfQrMTmJv.split('\n')
	OO1XlVPzfQrMTmJv,nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = '',''
	for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
		if len(OO1XlVPzfQrMTmJv+ssAiraohPKc5XpOjnI)<1800: OO1XlVPzfQrMTmJv += '\n'+ssAiraohPKc5XpOjnI
		else:
			so7KUfDgj5cLVa2FwI3AQHTzuR.append(OO1XlVPzfQrMTmJv)
			OO1XlVPzfQrMTmJv = ssAiraohPKc5XpOjnI
	so7KUfDgj5cLVa2FwI3AQHTzuR.append(OO1XlVPzfQrMTmJv)
	from json import dumps as om7a4pV8WXIHBzNwrYOFlq
	for ssAiraohPKc5XpOjnI in so7KUfDgj5cLVa2FwI3AQHTzuR:
		JWZYMU9luoKCAD7ybSBQ = {'Content-Type':'application/json','User-Agent':''}
		HbqSfZ6m7FAa = 'https://api.reverso.net/translate/v1/translation'
		LGivCYufsSNw0qmdjxEFXKDR3UlM4 = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.code')
		UT2HOni53GWMsxv4oJzLgch = {"format":"text","from":"ara","to":LGivCYufsSNw0qmdjxEFXKDR3UlM4,"input":ssAiraohPKc5XpOjnI,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		UT2HOni53GWMsxv4oJzLgch = om7a4pV8WXIHBzNwrYOFlq(UT2HOni53GWMsxv4oJzLgch)
		vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',HbqSfZ6m7FAa,UT2HOni53GWMsxv4oJzLgch,JWZYMU9luoKCAD7ybSBQ,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if vqUSBHDtn5Rl6Vyc8.succeeded:
			F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
			F3FUSpn5ZHPu6iwQ1sr8 = kMLWTt2fO9dnGDUgHh('dict',F3FUSpn5ZHPu6iwQ1sr8)
			nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw += '\n'+''.join(F3FUSpn5ZHPu6iwQ1sr8['translation'])
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw[2:]
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000000','00000').replace('00000','0000').replace('0000','000')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0001','[COLOR FFC89008]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0002','[COLOR FFFFFF00]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0003','[/COLOR]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0004','=====')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0005',',')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('0009','[RTL]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000A','[CENTER]')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.replace('000B','\r')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw.split('\n\n\n\n')
	return UAoKrdqaMm+nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw
def xdbtlGSXMug4nAm3TIc7(kM2FOrWe9XhQVaDI):
	Jv1PxZoU75O43IEMR8tksyWng2eT = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.translate')
	if not Jv1PxZoU75O43IEMR8tksyWng2eT or not kM2FOrWe9XhQVaDI: return kM2FOrWe9XhQVaDI
	wZja8s9exBG3HOyn1Ju2vSkqDdQ = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.provider')
	LGivCYufsSNw0qmdjxEFXKDR3UlM4 = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.code')
	E6YALVBh24kPCJxUjIvG5qsNpSw8D = LGivCYufsSNw0qmdjxEFXKDR3UlM4+'__'+str(kM2FOrWe9XhQVaDI)
	fQ6kvwg1FrYAzXjbLT.setSetting('av.language.translate','')
	nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','TRANSLATE_'+wZja8s9exBG3HOyn1Ju2vSkqDdQ,E6YALVBh24kPCJxUjIvG5qsNpSw8D)
	if not nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw:
		if wZja8s9exBG3HOyn1Ju2vSkqDdQ=='GOOGLE': nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = k4v2gt3Vu7pMIOFRZ185Ge(kM2FOrWe9XhQVaDI)
		elif wZja8s9exBG3HOyn1Ju2vSkqDdQ=='REVERSO': nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = xCqeXzb2Hj36n(kM2FOrWe9XhQVaDI)
		elif wZja8s9exBG3HOyn1Ju2vSkqDdQ=='GLOSBE': nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = lL4YDV2HKj7CiPAfG1Orm3M8ycI6J(kM2FOrWe9XhQVaDI)
		if len(kM2FOrWe9XhQVaDI)==len(nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw):
			mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'TRANSLATE_'+wZja8s9exBG3HOyn1Ju2vSkqDdQ,E6YALVBh24kPCJxUjIvG5qsNpSw8D,nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw,kkvBdWcON7RZoMJDr0YjmLE1)
		else:
			nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw = kM2FOrWe9XhQVaDI
			uFCykYQW68S('الترجمة فشلت','Translation Failed')
	fQ6kvwg1FrYAzXjbLT.setSetting('av.language.translate','1')
	return nSdB4FTcKmMJ9Ex1tIX8ob3aqrNZsw
def ttY9W3n7TpU(Gi8FAfgwEsPZ,NjRlK6eUJOIgpXACuF,tabjWm69HD,W4GxgNQcJUMj2mCA,p5hWO4jlVNZw):
	ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo = Gi8FAfgwEsPZ
	z5mgnTBIvcsu = []
	Jv1PxZoU75O43IEMR8tksyWng2eT = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.translate')
	if Jv1PxZoU75O43IEMR8tksyWng2eT:
		FxBvGruOaSy7YKkThH,lzKh3aveDWpJ2NrFjCLytn,AfvXsbK71IEaFyJS = [],[],[]
		if not z5mgnTBIvcsu:
			for CCWTVuybzaFHqsL8OAEg3lnR1ifrc in NjRlK6eUJOIgpXACuF:
				pphVUbJkGtHXndg84iZl2DPImSzoC = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['name'].replace(lc6sH83woipUCaLnRVAkgtrEJd257,'').replace(Pc98uK2GLvfMwq6UtyJSHe03g,'')
				w3XPQyaqYg2h = QPuHKNAT4jmCRg.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
				if w3XPQyaqYg2h:
					UAoKrdqaMm,A0HDETiub9mzLa8,YYzPm8OIEQ0UMKLZhTR,UGNWtinsC6cI48YK9bSzfeLgTaE,pphVUbJkGtHXndg84iZl2DPImSzoC = w3XPQyaqYg2h[0]
					w3XPQyaqYg2h = UAoKrdqaMm+A0HDETiub9mzLa8+' '+YYzPm8OIEQ0UMKLZhTR+UGNWtinsC6cI48YK9bSzfeLgTaE+' '
				else:
					w3XPQyaqYg2h = QPuHKNAT4jmCRg.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
					if w3XPQyaqYg2h:
						pphVUbJkGtHXndg84iZl2DPImSzoC,UAoKrdqaMm,YYzPm8OIEQ0UMKLZhTR,A0HDETiub9mzLa8,UGNWtinsC6cI48YK9bSzfeLgTaE = w3XPQyaqYg2h[0]
						w3XPQyaqYg2h = UAoKrdqaMm+A0HDETiub9mzLa8+' '+YYzPm8OIEQ0UMKLZhTR+UGNWtinsC6cI48YK9bSzfeLgTaE+' '
					else: w3XPQyaqYg2h = ''
				Ll7oCKWD2zrGV3cStkHj8 = QPuHKNAT4jmCRg.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
				if Ll7oCKWD2zrGV3cStkHj8: Ll7oCKWD2zrGV3cStkHj8,pphVUbJkGtHXndg84iZl2DPImSzoC = Ll7oCKWD2zrGV3cStkHj8[0]
				else: Ll7oCKWD2zrGV3cStkHj8 = ''
				FxBvGruOaSy7YKkThH.append(w3XPQyaqYg2h+Ll7oCKWD2zrGV3cStkHj8)
				lzKh3aveDWpJ2NrFjCLytn.append(pphVUbJkGtHXndg84iZl2DPImSzoC)
			AfvXsbK71IEaFyJS = xdbtlGSXMug4nAm3TIc7(lzKh3aveDWpJ2NrFjCLytn)
			if AfvXsbK71IEaFyJS:
				for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(len(NjRlK6eUJOIgpXACuF)):
					CCWTVuybzaFHqsL8OAEg3lnR1ifrc = NjRlK6eUJOIgpXACuF[gI689nKoH2PlifU3AMW5vVEZpFYX1]
					CCWTVuybzaFHqsL8OAEg3lnR1ifrc['name'] = FxBvGruOaSy7YKkThH[gI689nKoH2PlifU3AMW5vVEZpFYX1]+AfvXsbK71IEaFyJS[gI689nKoH2PlifU3AMW5vVEZpFYX1]
					z5mgnTBIvcsu.append(CCWTVuybzaFHqsL8OAEg3lnR1ifrc)
	if z5mgnTBIvcsu: NjRlK6eUJOIgpXACuF = z5mgnTBIvcsu
	LSYljxEpfM,WWjJC21BEZNQxks4,q29qFjNyLWgRu68SCUAfda = [],0,0
	nB1Sb94Qo3pjDIJhMugPlVG = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(E5bapZAYUTcnFCmuPGztDrfMq,Q6FbqZ9uIe8v2xaTHhfDCJ)
	try: HUxf3CNMb6AodtXVyLO = YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(nB1Sb94Qo3pjDIJhMugPlVG)
	except:
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.makedirs(nB1Sb94Qo3pjDIJhMugPlVG)
		except: pass
		HUxf3CNMb6AodtXVyLO = []
	aaQW5mKphiERxtUXq4 = Ppb8NvTZHBQ7we6('menu_item')
	for CCWTVuybzaFHqsL8OAEg3lnR1ifrc in NjRlK6eUJOIgpXACuF:
		pphVUbJkGtHXndg84iZl2DPImSzoC = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['name']
		PI1k48oNQ2mwLdij7lU = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['context_menu']
		FFcDVR7pXsS0ETfa = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['plot']
		lTrFxksRnEOCvVL = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['stars']
		IsMuwXCDji = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['image']
		ghLJETx5pD7 = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['type']
		TlHOFn2rpj0Jh9MsWxfNgGd = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['duration']
		buKpnTBErN0PFmZz69c = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['isFolder']
		Y8Dx1rsCOdqeoJczaQIA = CCWTVuybzaFHqsL8OAEg3lnR1ifrc['newpath']
		bFkZBvsxJSTj4Ee51OdKClh9o = yOuHBDmPps3vd24cnLagiK0.ListItem(pphVUbJkGtHXndg84iZl2DPImSzoC)
		bFkZBvsxJSTj4Ee51OdKClh9o.addContextMenuItems(PI1k48oNQ2mwLdij7lU)
		if IsMuwXCDji: bFkZBvsxJSTj4Ee51OdKClh9o.setArt({'icon':IsMuwXCDji,'thumb':IsMuwXCDji,'fanart':IsMuwXCDji,'banner':IsMuwXCDji,'clearart':IsMuwXCDji,'poster':IsMuwXCDji,'clearlogo':IsMuwXCDji,'landscape':IsMuwXCDji})
		else:
			pphVUbJkGtHXndg84iZl2DPImSzoC = q9AltNyD2Q1uL(pphVUbJkGtHXndg84iZl2DPImSzoC)
			pphVUbJkGtHXndg84iZl2DPImSzoC = ZVgGt1Ua7ChRz4ElJBp9YTqMS(pphVUbJkGtHXndg84iZl2DPImSzoC)
			YeAQFcLpT2mNRq5 = pphVUbJkGtHXndg84iZl2DPImSzoC+'.png'
			default = True
			if YeAQFcLpT2mNRq5 in HUxf3CNMb6AodtXVyLO:
				FF75c9Bn8yzZoP = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(nB1Sb94Qo3pjDIJhMugPlVG,YeAQFcLpT2mNRq5)
				bFkZBvsxJSTj4Ee51OdKClh9o.setArt({'icon':FF75c9Bn8yzZoP,'thumb':FF75c9Bn8yzZoP,'fanart':FF75c9Bn8yzZoP,'banner':FF75c9Bn8yzZoP,'clearart':FF75c9Bn8yzZoP,'poster':FF75c9Bn8yzZoP,'clearlogo':FF75c9Bn8yzZoP,'landscape':FF75c9Bn8yzZoP})
				default = False
			elif WWjJC21BEZNQxks4<60 and q29qFjNyLWgRu68SCUAfda<5:
				FF75c9Bn8yzZoP = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(nB1Sb94Qo3pjDIJhMugPlVG,YeAQFcLpT2mNRq5)
				try:
					CM4DLFlAnb = tsXIEiwLUmkl0TqAOS1yMpze(aaQW5mKphiERxtUXq4,'','','','',pphVUbJkGtHXndg84iZl2DPImSzoC,'menu_item','center',False,FF75c9Bn8yzZoP)
					bFkZBvsxJSTj4Ee51OdKClh9o.setArt({'icon':FF75c9Bn8yzZoP,'thumb':FF75c9Bn8yzZoP,'fanart':FF75c9Bn8yzZoP,'banner':FF75c9Bn8yzZoP,'clearart':FF75c9Bn8yzZoP,'poster':FF75c9Bn8yzZoP,'clearlogo':FF75c9Bn8yzZoP,'landscape':FF75c9Bn8yzZoP})
					WWjJC21BEZNQxks4 += 1
					default = False
				except: q29qFjNyLWgRu68SCUAfda += 1
			if default: bFkZBvsxJSTj4Ee51OdKClh9o.setArt({'icon':eLuH37gxlWFrXmPI9DRacKVvw8,'thumb':qhGXKtIAc7JDMl,'fanart':jpOd8ItEif,'banner':bbsXepLY6T,'clearart':CkUNxg1FhXOHI6uJ9tEw7q4DamZe,'poster':AwENosa4rb26JGLF851W7HkZeT3KC,'clearlogo':q4hAGKT3Uwjis2MeRrX8oF5Ivt,'landscape':tpSjmXfVBrEPso})
		if LRjqrQYBXFVPfu<20:
			if FFcDVR7pXsS0ETfa: bFkZBvsxJSTj4Ee51OdKClh9o.setInfo('video',{'Plot':FFcDVR7pXsS0ETfa,'PlotOutline':FFcDVR7pXsS0ETfa})
			if lTrFxksRnEOCvVL: bFkZBvsxJSTj4Ee51OdKClh9o.setInfo('video',{'Rating':lTrFxksRnEOCvVL})
			if not IsMuwXCDji:
				bFkZBvsxJSTj4Ee51OdKClh9o.setInfo('video',{'Title':pphVUbJkGtHXndg84iZl2DPImSzoC})
			if ghLJETx5pD7=='video':
				bFkZBvsxJSTj4Ee51OdKClh9o.setInfo('video',{'mediatype':'movie'})
				if TlHOFn2rpj0Jh9MsWxfNgGd: bFkZBvsxJSTj4Ee51OdKClh9o.setInfo('video',{'duration':TlHOFn2rpj0Jh9MsWxfNgGd})
				bFkZBvsxJSTj4Ee51OdKClh9o.setProperty('IsPlayable','true')
		else:
			h2hOcouwtxpsNMTYQ4kHg6b3I0DU = bFkZBvsxJSTj4Ee51OdKClh9o.getVideoInfoTag()
			if lTrFxksRnEOCvVL: h2hOcouwtxpsNMTYQ4kHg6b3I0DU.setRating(float(lTrFxksRnEOCvVL))
			if not IsMuwXCDji:
				h2hOcouwtxpsNMTYQ4kHg6b3I0DU.setTitle(pphVUbJkGtHXndg84iZl2DPImSzoC)
			if ghLJETx5pD7=='video':
				h2hOcouwtxpsNMTYQ4kHg6b3I0DU.setMediaType('tvshow')
				if TlHOFn2rpj0Jh9MsWxfNgGd: h2hOcouwtxpsNMTYQ4kHg6b3I0DU.setDuration(TlHOFn2rpj0Jh9MsWxfNgGd)
				bFkZBvsxJSTj4Ee51OdKClh9o.setProperty('IsPlayable','true')
		LSYljxEpfM.append((Y8Dx1rsCOdqeoJczaQIA,bFkZBvsxJSTj4Ee51OdKClh9o,buKpnTBErN0PFmZz69c))
	LL2eGTPdkm.setContent(EhfrVPICebQ,'tvshows')
	mbcEU9tHfVYCnWBJjOr = LL2eGTPdkm.addDirectoryItems(EhfrVPICebQ,LSYljxEpfM)
	LL2eGTPdkm.endOfDirectory(EhfrVPICebQ,tabjWm69HD,W4GxgNQcJUMj2mCA,p5hWO4jlVNZw)
	return mbcEU9tHfVYCnWBJjOr
def fpjEiKI9bTc1xhoeq37vPusDJ6SB(ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji='',zt1qZvA74HunVPWCON='',OO1XlVPzfQrMTmJv='',C32AEk8uZTeFPI94LG6dmczv='',T1zaK6eDkFcyCBldWR3YMuJgIQo={}):
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('\r','').replace('\n','').replace('\t','')
	HbqSfZ6m7FAa = HbqSfZ6m7FAa.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in pphVUbJkGtHXndg84iZl2DPImSzoC: amlcehCxU3O2yoGf,pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.split('_SCRIPT_',1)
	else: amlcehCxU3O2yoGf,pphVUbJkGtHXndg84iZl2DPImSzoC = '',pphVUbJkGtHXndg84iZl2DPImSzoC
	if amlcehCxU3O2yoGf:
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = pphVUbJkGtHXndg84iZl2DPImSzoC
		if not ffBRA0XqkwdxriZJlma6CWbU1Ph3T: ffBRA0XqkwdxriZJlma6CWbU1Ph3T = '....'
		elif ffBRA0XqkwdxriZJlma6CWbU1Ph3T.count('_')>1: ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.split('_',2)[2]
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace(' ','')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('|','').replace('~','')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('اون لاين','').replace('سيما لايت','')
		BkcLCXQgIGiobKJ9p = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(PwUO4g2mDJfNhZRkCq in ffBRA0XqkwdxriZJlma6CWbU1Ph3T for PwUO4g2mDJfNhZRkCq in BkcLCXQgIGiobKJ9p): ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('ال','')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		ffBRA0XqkwdxriZJlma6CWbU1Ph3T = ffBRA0XqkwdxriZJlma6CWbU1Ph3T.replace('  ',' ').strip(' ')
		amlcehCxU3O2yoGf = '_LST_'+S6YzAlHWcCwJI18(amlcehCxU3O2yoGf)
		if ffBRA0XqkwdxriZJlma6CWbU1Ph3T not in list(ZXFEJOV3vG5UIjAR2WxiD01tcML.keys()): ZXFEJOV3vG5UIjAR2WxiD01tcML[ffBRA0XqkwdxriZJlma6CWbU1Ph3T] = {}
		ZXFEJOV3vG5UIjAR2WxiD01tcML[ffBRA0XqkwdxriZJlma6CWbU1Ph3T][amlcehCxU3O2yoGf] = [ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo]
	vvruH9wsBDfbhFtyq1MUd2zV.append([ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo])
	return
def UH1IuvwM9e4cl7if63nNdozJFSj(csB3JEFC7PrwhduXojWyGVn5):
	if Nnxm30dfoBWRYpIC7KsQGl: from html import unescape as _xUiRWPnFZSGvwJs15p4y7
	else:
		from HTMLParser import HTMLParser as Vb4wFxdEeSUgKXMj3h8lQz1tqWya9
		_xUiRWPnFZSGvwJs15p4y7 = Vb4wFxdEeSUgKXMj3h8lQz1tqWya9().unescape
	if '&' in csB3JEFC7PrwhduXojWyGVn5 and ';' in csB3JEFC7PrwhduXojWyGVn5:
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: csB3JEFC7PrwhduXojWyGVn5 = csB3JEFC7PrwhduXojWyGVn5.decode('utf8')
		csB3JEFC7PrwhduXojWyGVn5 = _xUiRWPnFZSGvwJs15p4y7(csB3JEFC7PrwhduXojWyGVn5)
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: csB3JEFC7PrwhduXojWyGVn5 = csB3JEFC7PrwhduXojWyGVn5.encode('utf8')
	return csB3JEFC7PrwhduXojWyGVn5
def kWfpQA7tTjSPyLbNIeMr1Hui5(csB3JEFC7PrwhduXojWyGVn5):
	if '\\u' in csB3JEFC7PrwhduXojWyGVn5:
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: csB3JEFC7PrwhduXojWyGVn5 = csB3JEFC7PrwhduXojWyGVn5.decode('unicode_escape','ignore').encode('utf8')
		elif Nnxm30dfoBWRYpIC7KsQGl: csB3JEFC7PrwhduXojWyGVn5 = csB3JEFC7PrwhduXojWyGVn5.encode('utf8').decode('unicode_escape','ignore')
	return csB3JEFC7PrwhduXojWyGVn5
def wTRFaLkJX3nVH8CzcNMZG6pU7Pu2t(K3CH6VPpzWl51i,aXB2AncJmDKUqE9C3ulSxR,vkbLy2R5Yz3rPox9tJDZEpumq,FVIAthnZeULq86rmkCwviMu3EScY,OO1XlVPzfQrMTmJv,Lfhsr0eJyIB6Qui,ttdTxsuSiU2kZAPQcVqNFnvX4,wlWn2B6kdt9jKM1uOyF0Iv,WEjUrFYCBvpTt7d0c9gmasH6VKZ):
	rmjThWRbt2pHgKMcYVe8osZX = Ppb8NvTZHBQ7we6(Lfhsr0eJyIB6Qui)
	CM4DLFlAnb = tsXIEiwLUmkl0TqAOS1yMpze(rmjThWRbt2pHgKMcYVe8osZX,K3CH6VPpzWl51i,aXB2AncJmDKUqE9C3ulSxR,vkbLy2R5Yz3rPox9tJDZEpumq,FVIAthnZeULq86rmkCwviMu3EScY,OO1XlVPzfQrMTmJv,Lfhsr0eJyIB6Qui,ttdTxsuSiU2kZAPQcVqNFnvX4,wlWn2B6kdt9jKM1uOyF0Iv,WEjUrFYCBvpTt7d0c9gmasH6VKZ)
	return CM4DLFlAnb
def Ppb8NvTZHBQ7we6(Lfhsr0eJyIB6Qui):
	yqO2hlKo6EWxJRL7aHuiCDjgVd3kr = 5
	tKvaUMlFA5 = 20
	mcIO5HEFNS6Z = 20
	pvLClZGatfuPXEH7MNTeyB1 = 0
	b0bQapMC4nSxdEZXh = 'center'
	niYl1cKbALxIP3 = 0
	ttV0dSP7HcUQf8ZpGWh6ybze = 19
	UUXs1BPLc76YOEVz = 30
	ff2zvrax1Z37D9nSOwt8yIQ6 = 8
	ffwPui7WNecspj0bFEn5 = True
	gpCv7YNQ1FG0fXZDzr = 375
	uPWchRNlsbtZzCoU2n8x = 410
	w3w5PZJdy4CQvkHmhbKxEFGi2UDLrl = 50
	IlfyN3a9UA = 280
	PF3QAjfz5Vi1D0nCTsH = 28
	elcG8ay1sU6fO9tv = 5
	OXxGhrqAVyjSaoRt5QmlCF0n9LP = 0
	RCfBTDGzPpZb8aoAysH46v1dmlKeF = 31
	mhSV4lr5QCbRpOeKvtny8XYJdFc = [36,32,28]
	if Lfhsr0eJyIB6Qui in ['notification','notification_twohalfs']:
		if Lfhsr0eJyIB6Qui=='notification_twohalfs':
			YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = 'UPPER',720
			b0bQapMC4nSxdEZXh = 'right'
			ffwPui7WNecspj0bFEn5 = True
			pvLClZGatfuPXEH7MNTeyB1 = 10
		else:
			YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = 97+20,720
			b0bQapMC4nSxdEZXh = 'left'
			ffwPui7WNecspj0bFEn5 = False
		mhSV4lr5QCbRpOeKvtny8XYJdFc = [33,33,33]
		mcIO5HEFNS6Z = 20
		tKvaUMlFA5 = 0
		UUXs1BPLc76YOEVz = 20
		ttV0dSP7HcUQf8ZpGWh6ybze = 25+10
	elif Lfhsr0eJyIB6Qui=='menu_item':
		mhSV4lr5QCbRpOeKvtny8XYJdFc,YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = [48,44,40],200,400
		UUXs1BPLc76YOEVz,ttV0dSP7HcUQf8ZpGWh6ybze,tKvaUMlFA5 = 0,0,-16
		yEBAeWrKfX = KlXvBMj7oFRhLxW3OpCI2s.open(xp9lE7BnMwAidzfDa1rW60hymjoLc)
		CVGUbfnQAs = KlXvBMj7oFRhLxW3OpCI2s.new('RGBA',(200,200),(255,0,0,255))
	elif Lfhsr0eJyIB6Qui=='confirm_smallfont': mhSV4lr5QCbRpOeKvtny8XYJdFc,YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = [28,24,20],500,900
	elif Lfhsr0eJyIB6Qui=='confirm_mediumfont': mhSV4lr5QCbRpOeKvtny8XYJdFc,YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = [32,28,24],500,900
	elif Lfhsr0eJyIB6Qui=='confirm_bigfont': mhSV4lr5QCbRpOeKvtny8XYJdFc,YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = [36,32,28],500,900
	elif Lfhsr0eJyIB6Qui=='textview_bigfont': YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = 740,1270
	elif Lfhsr0eJyIB6Qui=='textview_bigfont_long': YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = 'UPPER',1270
	elif Lfhsr0eJyIB6Qui=='textview_smallfont': mhSV4lr5QCbRpOeKvtny8XYJdFc,YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = [28,23,18],740,1270
	elif Lfhsr0eJyIB6Qui=='textview_smallfont_long': mhSV4lr5QCbRpOeKvtny8XYJdFc,YSOMVhIgs46Z12yBfCFrJic3kl,HlRABNy6zi1vwUcWOxCh = [28,23,18],'UPPER',1270
	OKzYJyXtb7RhxGcDu1pQjwEeUN = mhSV4lr5QCbRpOeKvtny8XYJdFc[0]
	kHpUsoDrf0EiRY12yP3QczTa4 = mhSV4lr5QCbRpOeKvtny8XYJdFc[1]
	tKz4ErxpUcLFR3mn = mhSV4lr5QCbRpOeKvtny8XYJdFc[2]
	I3QpzgfSnHhxG1dsb = LFgRCWvkM8hAD.truetype(PJt3BgZiYnhGAI4kO,size=OKzYJyXtb7RhxGcDu1pQjwEeUN)
	JB9pK6omve = LFgRCWvkM8hAD.truetype(PJt3BgZiYnhGAI4kO,size=kHpUsoDrf0EiRY12yP3QczTa4)
	oazDjCNgbfAUr2ivxEnF5RlmeVISp = LFgRCWvkM8hAD.truetype(PJt3BgZiYnhGAI4kO,size=tKz4ErxpUcLFR3mn)
	h7pHmrZTb8Yn9AKQc = KlXvBMj7oFRhLxW3OpCI2s.new('RGBA',(100,100),(255,255,255,0))
	vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ = uIVUl3LvOfkK2NoGzq.Draw(h7pHmrZTb8Yn9AKQc)
	MVUNcPB9iZn5x,wGCp6jyA9TOY = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize('HHH BBB 888 000',font=JB9pK6omve)
	p9ETUw7rAX52lfxuvnGeDmZQ,zlNDiuXBdxZwt7 = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize('HHH BBB 888 000',font=I3QpzgfSnHhxG1dsb)
	PHRfAFw75rIm039St = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	XKBZzu8M0xo4vLp = u3spdvWxnetUMfwPGoR(configuration=PHRfAFw75rIm039St)
	rmjThWRbt2pHgKMcYVe8osZX = {}
	JJuyAtI07lxocKYrsdhF854XTaHN = locals()
	for yChXl3AKe7H9f in JJuyAtI07lxocKYrsdhF854XTaHN: rmjThWRbt2pHgKMcYVe8osZX[yChXl3AKe7H9f] = JJuyAtI07lxocKYrsdhF854XTaHN[yChXl3AKe7H9f]
	return rmjThWRbt2pHgKMcYVe8osZX
def tsXIEiwLUmkl0TqAOS1yMpze(rmjThWRbt2pHgKMcYVe8osZX,K3CH6VPpzWl51i,aXB2AncJmDKUqE9C3ulSxR,vkbLy2R5Yz3rPox9tJDZEpumq,FVIAthnZeULq86rmkCwviMu3EScY,OO1XlVPzfQrMTmJv,Lfhsr0eJyIB6Qui,ttdTxsuSiU2kZAPQcVqNFnvX4,wlWn2B6kdt9jKM1uOyF0Iv,WEjUrFYCBvpTt7d0c9gmasH6VKZ):
	for yChXl3AKe7H9f in rmjThWRbt2pHgKMcYVe8osZX: globals()[yChXl3AKe7H9f] = rmjThWRbt2pHgKMcYVe8osZX[yChXl3AKe7H9f]
	global PF3QAjfz5Vi1D0nCTsH,elcG8ay1sU6fO9tv
	Jv1PxZoU75O43IEMR8tksyWng2eT = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.translate')
	if Jv1PxZoU75O43IEMR8tksyWng2eT:
		if K3CH6VPpzWl51i=='نعم  Yes': K3CH6VPpzWl51i = 'Yes'
		elif K3CH6VPpzWl51i=='كلا  No': K3CH6VPpzWl51i = 'No'
		if aXB2AncJmDKUqE9C3ulSxR=='نعم  Yes': aXB2AncJmDKUqE9C3ulSxR = 'Yes'
		elif aXB2AncJmDKUqE9C3ulSxR=='كلا  No': aXB2AncJmDKUqE9C3ulSxR = 'No'
		if vkbLy2R5Yz3rPox9tJDZEpumq=='نعم  Yes': vkbLy2R5Yz3rPox9tJDZEpumq = 'Yes'
		elif vkbLy2R5Yz3rPox9tJDZEpumq=='كلا  No': vkbLy2R5Yz3rPox9tJDZEpumq = 'No'
		X8M3EvbVAIGCNpgU7 = xdbtlGSXMug4nAm3TIc7([K3CH6VPpzWl51i,aXB2AncJmDKUqE9C3ulSxR,vkbLy2R5Yz3rPox9tJDZEpumq,FVIAthnZeULq86rmkCwviMu3EScY,OO1XlVPzfQrMTmJv])
		if X8M3EvbVAIGCNpgU7: K3CH6VPpzWl51i,aXB2AncJmDKUqE9C3ulSxR,vkbLy2R5Yz3rPox9tJDZEpumq,FVIAthnZeULq86rmkCwviMu3EScY,OO1XlVPzfQrMTmJv = X8M3EvbVAIGCNpgU7
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
		OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.decode('utf8')
		FVIAthnZeULq86rmkCwviMu3EScY = FVIAthnZeULq86rmkCwviMu3EScY.decode('utf8')
		K3CH6VPpzWl51i = K3CH6VPpzWl51i.decode('utf8')
		aXB2AncJmDKUqE9C3ulSxR = aXB2AncJmDKUqE9C3ulSxR.decode('utf8')
		vkbLy2R5Yz3rPox9tJDZEpumq = vkbLy2R5Yz3rPox9tJDZEpumq.decode('utf8')
	at7V96IDyBn = FVIAthnZeULq86rmkCwviMu3EScY.count('\n')+1
	coa2lRE1GAX8IuL3NnjHqSBisVY = tKvaUMlFA5+at7V96IDyBn*(zlNDiuXBdxZwt7+pvLClZGatfuPXEH7MNTeyB1)-pvLClZGatfuPXEH7MNTeyB1
	if OO1XlVPzfQrMTmJv:
		wjMyDbT0nlSN2c5eUt7zvrP6I = HlRABNy6zi1vwUcWOxCh-UUXs1BPLc76YOEVz*2
		uHwRJzI9ld = wGCp6jyA9TOY+ff2zvrax1Z37D9nSOwt8yIQ6
		EIuD8jpk2KFSYzbHwZegtidrc = XKBZzu8M0xo4vLp.reshape(OO1XlVPzfQrMTmJv)
		if ffwPui7WNecspj0bFEn5:
			qOgh2UPSr3AM9F8Zm = rI48d7RQ5iWJlAGKPHsE(EIuD8jpk2KFSYzbHwZegtidrc,kHpUsoDrf0EiRY12yP3QczTa4,wjMyDbT0nlSN2c5eUt7zvrP6I,uHwRJzI9ld)
			LIWliX8FM3PAwzNerS = jbrpunX29PLNK8FvGCcWBYm5QR(qOgh2UPSr3AM9F8Zm)
			PPsOzlRyd8B = LIWliX8FM3PAwzNerS.count('\n')+1
			if PPsOzlRyd8B<6:
				Y2XehOwFPI49 = wjMyDbT0nlSN2c5eUt7zvrP6I
				qOgh2UPSr3AM9F8Zm = rI48d7RQ5iWJlAGKPHsE(EIuD8jpk2KFSYzbHwZegtidrc,kHpUsoDrf0EiRY12yP3QczTa4,Y2XehOwFPI49,uHwRJzI9ld)
				LIWliX8FM3PAwzNerS = jbrpunX29PLNK8FvGCcWBYm5QR(qOgh2UPSr3AM9F8Zm)
				PPsOzlRyd8B = LIWliX8FM3PAwzNerS.count('\n')+1
			J64nIHpw7xqkgV5jU = ttV0dSP7HcUQf8ZpGWh6ybze+PPsOzlRyd8B*uHwRJzI9ld-ff2zvrax1Z37D9nSOwt8yIQ6
		else:
			J64nIHpw7xqkgV5jU = ttV0dSP7HcUQf8ZpGWh6ybze+wGCp6jyA9TOY
			LIWliX8FM3PAwzNerS = EIuD8jpk2KFSYzbHwZegtidrc.split('\n')[0]
			qOgh2UPSr3AM9F8Zm = EIuD8jpk2KFSYzbHwZegtidrc.split('\n')[0]
	else: J64nIHpw7xqkgV5jU = ttV0dSP7HcUQf8ZpGWh6ybze
	xSlfoQVFznI = OXxGhrqAVyjSaoRt5QmlCF0n9LP+RCfBTDGzPpZb8aoAysH46v1dmlKeF
	if wlWn2B6kdt9jKM1uOyF0Iv:
		k5sSlCTywgVfj = uPWchRNlsbtZzCoU2n8x-gpCv7YNQ1FG0fXZDzr
		xSlfoQVFznI += k5sSlCTywgVfj
	else: k5sSlCTywgVfj = 0
	if K3CH6VPpzWl51i or aXB2AncJmDKUqE9C3ulSxR or vkbLy2R5Yz3rPox9tJDZEpumq: xSlfoQVFznI += w3w5PZJdy4CQvkHmhbKxEFGi2UDLrl
	if YSOMVhIgs46Z12yBfCFrJic3kl!='UPPER': CM4DLFlAnb = YSOMVhIgs46Z12yBfCFrJic3kl
	else: CM4DLFlAnb = coa2lRE1GAX8IuL3NnjHqSBisVY+J64nIHpw7xqkgV5jU+xSlfoQVFznI
	JilxkDYzvE7O = CM4DLFlAnb-coa2lRE1GAX8IuL3NnjHqSBisVY-xSlfoQVFznI-ttV0dSP7HcUQf8ZpGWh6ybze
	h7pHmrZTb8Yn9AKQc = KlXvBMj7oFRhLxW3OpCI2s.new('RGBA',(HlRABNy6zi1vwUcWOxCh,CM4DLFlAnb),(255,255,255,0))
	vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ = uIVUl3LvOfkK2NoGzq.Draw(h7pHmrZTb8Yn9AKQc)
	if not aXB2AncJmDKUqE9C3ulSxR and K3CH6VPpzWl51i and vkbLy2R5Yz3rPox9tJDZEpumq:
		PF3QAjfz5Vi1D0nCTsH += 105
		elcG8ay1sU6fO9tv -= 110
	if FVIAthnZeULq86rmkCwviMu3EScY:
		UjwVP1WaK2GeNmQyc93ITv = tKvaUMlFA5
		FVIAthnZeULq86rmkCwviMu3EScY = GGgun1VSbfq8edk62vLxB.get_display(XKBZzu8M0xo4vLp.reshape(FVIAthnZeULq86rmkCwviMu3EScY))
		kM2FOrWe9XhQVaDI = FVIAthnZeULq86rmkCwviMu3EScY.splitlines()
		for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
			if ssAiraohPKc5XpOjnI:
				OQ8UbnHs0RJYjBcL7NhDkK,IHSiJzB8KWwbCnMa = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(ssAiraohPKc5XpOjnI,font=I3QpzgfSnHhxG1dsb)
				if b0bQapMC4nSxdEZXh=='center': hTMbQVkDzGPqZc7xO0FRpUeXW49rB = yqO2hlKo6EWxJRL7aHuiCDjgVd3kr+(HlRABNy6zi1vwUcWOxCh-OQ8UbnHs0RJYjBcL7NhDkK)/2
				elif b0bQapMC4nSxdEZXh=='right': hTMbQVkDzGPqZc7xO0FRpUeXW49rB = yqO2hlKo6EWxJRL7aHuiCDjgVd3kr+HlRABNy6zi1vwUcWOxCh-OQ8UbnHs0RJYjBcL7NhDkK-mcIO5HEFNS6Z
				elif b0bQapMC4nSxdEZXh=='left': hTMbQVkDzGPqZc7xO0FRpUeXW49rB = yqO2hlKo6EWxJRL7aHuiCDjgVd3kr+mcIO5HEFNS6Z
				vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.text((hTMbQVkDzGPqZc7xO0FRpUeXW49rB,UjwVP1WaK2GeNmQyc93ITv),ssAiraohPKc5XpOjnI,font=I3QpzgfSnHhxG1dsb,fill='yellow')
			UjwVP1WaK2GeNmQyc93ITv += OKzYJyXtb7RhxGcDu1pQjwEeUN+pvLClZGatfuPXEH7MNTeyB1
	if K3CH6VPpzWl51i or aXB2AncJmDKUqE9C3ulSxR or vkbLy2R5Yz3rPox9tJDZEpumq:
		aDNbycRd5wPrYJZETj7AG = coa2lRE1GAX8IuL3NnjHqSBisVY+JilxkDYzvE7O+ttV0dSP7HcUQf8ZpGWh6ybze+k5sSlCTywgVfj+OXxGhrqAVyjSaoRt5QmlCF0n9LP
		if K3CH6VPpzWl51i:
			K3CH6VPpzWl51i = GGgun1VSbfq8edk62vLxB.get_display(XKBZzu8M0xo4vLp.reshape(K3CH6VPpzWl51i))
			hrmzdqfGapbkN,HJ7Vs9y38EKeaiuxSUN0A1zqlbwGg = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(K3CH6VPpzWl51i,font=oazDjCNgbfAUr2ivxEnF5RlmeVISp)
			xjgy4Bw3Oi0hGMqJ8z6uQDoSZEm = PF3QAjfz5Vi1D0nCTsH+0*(elcG8ay1sU6fO9tv+IlfyN3a9UA)+(IlfyN3a9UA-hrmzdqfGapbkN)/2
			vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.text((xjgy4Bw3Oi0hGMqJ8z6uQDoSZEm,aDNbycRd5wPrYJZETj7AG),K3CH6VPpzWl51i,font=oazDjCNgbfAUr2ivxEnF5RlmeVISp,fill='yellow')
		if aXB2AncJmDKUqE9C3ulSxR:
			aXB2AncJmDKUqE9C3ulSxR = GGgun1VSbfq8edk62vLxB.get_display(XKBZzu8M0xo4vLp.reshape(aXB2AncJmDKUqE9C3ulSxR))
			p9Xi8F6PjHkE7ylUdcKJ2VAsvQNS,hXmpgjy5FbdxCTL2z = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(aXB2AncJmDKUqE9C3ulSxR,font=oazDjCNgbfAUr2ivxEnF5RlmeVISp)
			uP9iUslFxwDeAo3ykZHWc = PF3QAjfz5Vi1D0nCTsH+1*(elcG8ay1sU6fO9tv+IlfyN3a9UA)+(IlfyN3a9UA-p9Xi8F6PjHkE7ylUdcKJ2VAsvQNS)/2
			vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.text((uP9iUslFxwDeAo3ykZHWc,aDNbycRd5wPrYJZETj7AG),aXB2AncJmDKUqE9C3ulSxR,font=oazDjCNgbfAUr2ivxEnF5RlmeVISp,fill='yellow')
		if vkbLy2R5Yz3rPox9tJDZEpumq:
			vkbLy2R5Yz3rPox9tJDZEpumq = GGgun1VSbfq8edk62vLxB.get_display(XKBZzu8M0xo4vLp.reshape(vkbLy2R5Yz3rPox9tJDZEpumq))
			y2PFwYS9vnQz4H6adlX,A5AQxkFt6Ypg1X = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(vkbLy2R5Yz3rPox9tJDZEpumq,font=oazDjCNgbfAUr2ivxEnF5RlmeVISp)
			Sdj5TfFzbxeY = PF3QAjfz5Vi1D0nCTsH+2*(elcG8ay1sU6fO9tv+IlfyN3a9UA)+(IlfyN3a9UA-y2PFwYS9vnQz4H6adlX)/2
			vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.text((Sdj5TfFzbxeY,aDNbycRd5wPrYJZETj7AG),vkbLy2R5Yz3rPox9tJDZEpumq,font=oazDjCNgbfAUr2ivxEnF5RlmeVISp,fill='yellow')
	if OO1XlVPzfQrMTmJv:
		oSjKkOi8mJWeLC51RA,ii7RcYd2pKEMJDyF34z = [],[]
		qOgh2UPSr3AM9F8Zm = SH3bZnoagFlq6TLJOEYXfBNdKRM(qOgh2UPSr3AM9F8Zm)
		zIREfLTjdc5GKvwarUSg30PDuMN8l6 = qOgh2UPSr3AM9F8Zm.split('_sss__newline_')
		for lYk0CUHViNfB in zIREfLTjdc5GKvwarUSg30PDuMN8l6:
			ezYEq2vZw6TliQa4V0MWD7j1Gyfx = ttdTxsuSiU2kZAPQcVqNFnvX4
			if   '_sss__lineleft_' in lYk0CUHViNfB: ezYEq2vZw6TliQa4V0MWD7j1Gyfx = 'left'
			elif '_sss__lineright_' in lYk0CUHViNfB: ezYEq2vZw6TliQa4V0MWD7j1Gyfx = 'right'
			elif '_sss__linecenter_' in lYk0CUHViNfB: ezYEq2vZw6TliQa4V0MWD7j1Gyfx = 'center'
			APWH59TLF2kUr3GgSev1wZIafi8hd = lYk0CUHViNfB
			gbFEcsrjiR7Ut = QPuHKNAT4jmCRg.findall('_sss__.*?_',lYk0CUHViNfB,QPuHKNAT4jmCRg.DOTALL)
			for xTgjn2StZAJP70ayeFV4YqmORk51 in gbFEcsrjiR7Ut: APWH59TLF2kUr3GgSev1wZIafi8hd = APWH59TLF2kUr3GgSev1wZIafi8hd.replace(xTgjn2StZAJP70ayeFV4YqmORk51,'')
			if APWH59TLF2kUr3GgSev1wZIafi8hd=='': OQ8UbnHs0RJYjBcL7NhDkK,IHSiJzB8KWwbCnMa = 0,uHwRJzI9ld
			else: OQ8UbnHs0RJYjBcL7NhDkK,IHSiJzB8KWwbCnMa = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(APWH59TLF2kUr3GgSev1wZIafi8hd,font=JB9pK6omve)
			if   ezYEq2vZw6TliQa4V0MWD7j1Gyfx=='left': AUb0dtwvlJC7IHO2f = niYl1cKbALxIP3+UUXs1BPLc76YOEVz
			elif ezYEq2vZw6TliQa4V0MWD7j1Gyfx=='right': AUb0dtwvlJC7IHO2f = niYl1cKbALxIP3+UUXs1BPLc76YOEVz+wjMyDbT0nlSN2c5eUt7zvrP6I-OQ8UbnHs0RJYjBcL7NhDkK
			elif ezYEq2vZw6TliQa4V0MWD7j1Gyfx=='center': AUb0dtwvlJC7IHO2f = niYl1cKbALxIP3+UUXs1BPLc76YOEVz+(wjMyDbT0nlSN2c5eUt7zvrP6I-OQ8UbnHs0RJYjBcL7NhDkK)/2
			if AUb0dtwvlJC7IHO2f<UUXs1BPLc76YOEVz: AUb0dtwvlJC7IHO2f = niYl1cKbALxIP3+UUXs1BPLc76YOEVz
			oSjKkOi8mJWeLC51RA.append(AUb0dtwvlJC7IHO2f)
			ii7RcYd2pKEMJDyF34z.append(OQ8UbnHs0RJYjBcL7NhDkK)
		AUb0dtwvlJC7IHO2f = oSjKkOi8mJWeLC51RA[0]
		jNY1Sw2gAu6z = qOgh2UPSr3AM9F8Zm.split('_sss_')
		D2dV6WBAxbpRI = (255,255,255,255)
		xbluaozce18HUP6GEndtDCNYp = D2dV6WBAxbpRI
		iiOkdz42wZNlqYSgQt0b9Uy5PBTFn7,TTNUKBS9VgdLJ5G1xfhoD = 0,0
		XbyjBEWCQNgw95D3MGhfZta = False
		f9fTNlWJI5p = 0
		qE457rLjCMXF = coa2lRE1GAX8IuL3NnjHqSBisVY+ttV0dSP7HcUQf8ZpGWh6ybze/2
		if J64nIHpw7xqkgV5jU<(JilxkDYzvE7O+ttV0dSP7HcUQf8ZpGWh6ybze):
			ygS2ZOePi3scr8LtFzmo = (JilxkDYzvE7O+ttV0dSP7HcUQf8ZpGWh6ybze-J64nIHpw7xqkgV5jU)/2
			qE457rLjCMXF = coa2lRE1GAX8IuL3NnjHqSBisVY+ttV0dSP7HcUQf8ZpGWh6ybze+ygS2ZOePi3scr8LtFzmo-wGCp6jyA9TOY/2
		for ssAiraohPKc5XpOjnI in jNY1Sw2gAu6z:
			if not ssAiraohPKc5XpOjnI or (ssAiraohPKc5XpOjnI and ord(ssAiraohPKc5XpOjnI[0])==65279): continue
			YXoPVCjuDvs6SwWmIZ0aAMGkJ = ssAiraohPKc5XpOjnI.split('_newline_',1)
			cG3Zk2QMPHChym1tAslNjFJ = ssAiraohPKc5XpOjnI.split('_newcolor',1)
			svgxw0fD7pKLiZd5XQ = ssAiraohPKc5XpOjnI.split('_endcolor_',1)
			zzTx8WmGlNrtSOKngqX4Hk1wiRh = ssAiraohPKc5XpOjnI.split('_linertl_',1)
			c0ldvU6G7OteKsB9ap5qwyhFD = ssAiraohPKc5XpOjnI.split('_lineleft_',1)
			EKyxFVOmpi2IeMbvDW6cB3HSPJr9js = ssAiraohPKc5XpOjnI.split('_lineright_',1)
			ki7uWmqGaD106Kw4rx = ssAiraohPKc5XpOjnI.split('_linecenter_',1)
			if len(YXoPVCjuDvs6SwWmIZ0aAMGkJ)>1:
				f9fTNlWJI5p += 1
				ssAiraohPKc5XpOjnI = YXoPVCjuDvs6SwWmIZ0aAMGkJ[1]
				iiOkdz42wZNlqYSgQt0b9Uy5PBTFn7 = 0
				AUb0dtwvlJC7IHO2f = oSjKkOi8mJWeLC51RA[f9fTNlWJI5p]
				TTNUKBS9VgdLJ5G1xfhoD += uHwRJzI9ld
				XbyjBEWCQNgw95D3MGhfZta = False
			elif len(cG3Zk2QMPHChym1tAslNjFJ)>1:
				ssAiraohPKc5XpOjnI = cG3Zk2QMPHChym1tAslNjFJ[1]
				xbluaozce18HUP6GEndtDCNYp = ssAiraohPKc5XpOjnI[0:8]
				xbluaozce18HUP6GEndtDCNYp = '#'+xbluaozce18HUP6GEndtDCNYp[2:]
				ssAiraohPKc5XpOjnI = ssAiraohPKc5XpOjnI[9:]
			elif len(svgxw0fD7pKLiZd5XQ)>1:
				ssAiraohPKc5XpOjnI = svgxw0fD7pKLiZd5XQ[1]
				xbluaozce18HUP6GEndtDCNYp = D2dV6WBAxbpRI
			elif len(zzTx8WmGlNrtSOKngqX4Hk1wiRh)>1:
				ssAiraohPKc5XpOjnI = zzTx8WmGlNrtSOKngqX4Hk1wiRh[1]
				XbyjBEWCQNgw95D3MGhfZta = True
				iiOkdz42wZNlqYSgQt0b9Uy5PBTFn7 = ii7RcYd2pKEMJDyF34z[f9fTNlWJI5p]
			elif len(c0ldvU6G7OteKsB9ap5qwyhFD)>1: ssAiraohPKc5XpOjnI = c0ldvU6G7OteKsB9ap5qwyhFD[1]
			elif len(EKyxFVOmpi2IeMbvDW6cB3HSPJr9js)>1: ssAiraohPKc5XpOjnI = EKyxFVOmpi2IeMbvDW6cB3HSPJr9js[1]
			elif len(ki7uWmqGaD106Kw4rx)>1: ssAiraohPKc5XpOjnI = ki7uWmqGaD106Kw4rx[1]
			if ssAiraohPKc5XpOjnI:
				N0NmHkDQ8XTq = qE457rLjCMXF+TTNUKBS9VgdLJ5G1xfhoD
				ssAiraohPKc5XpOjnI = GGgun1VSbfq8edk62vLxB.get_display(ssAiraohPKc5XpOjnI)
				OQ8UbnHs0RJYjBcL7NhDkK,IHSiJzB8KWwbCnMa = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(ssAiraohPKc5XpOjnI,font=JB9pK6omve)
				if XbyjBEWCQNgw95D3MGhfZta: iiOkdz42wZNlqYSgQt0b9Uy5PBTFn7 -= OQ8UbnHs0RJYjBcL7NhDkK
				Q8ilIYsOgBZWH79qPj0c1f = AUb0dtwvlJC7IHO2f+iiOkdz42wZNlqYSgQt0b9Uy5PBTFn7
				vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.text((Q8ilIYsOgBZWH79qPj0c1f,N0NmHkDQ8XTq),ssAiraohPKc5XpOjnI,font=JB9pK6omve,fill=xbluaozce18HUP6GEndtDCNYp)
				if Lfhsr0eJyIB6Qui=='menu_item':
					vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.text((Q8ilIYsOgBZWH79qPj0c1f+1,N0NmHkDQ8XTq+1),ssAiraohPKc5XpOjnI,font=JB9pK6omve,fill=xbluaozce18HUP6GEndtDCNYp)
				if not XbyjBEWCQNgw95D3MGhfZta: iiOkdz42wZNlqYSgQt0b9Uy5PBTFn7 += OQ8UbnHs0RJYjBcL7NhDkK
				if N0NmHkDQ8XTq>JilxkDYzvE7O+uHwRJzI9ld: break
	if Lfhsr0eJyIB6Qui=='menu_item':
		h7pHmrZTb8Yn9AKQc = h7pHmrZTb8Yn9AKQc.resize((200,200))
		PCQGYiydWfZLuS = yEBAeWrKfX.copy()
		PCQGYiydWfZLuS.paste(CVGUbfnQAs,(0,0),mask=h7pHmrZTb8Yn9AKQc)
	else: PCQGYiydWfZLuS = h7pHmrZTb8Yn9AKQc
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: WEjUrFYCBvpTt7d0c9gmasH6VKZ = WEjUrFYCBvpTt7d0c9gmasH6VKZ.decode('utf8')
	try: PCQGYiydWfZLuS.save(WEjUrFYCBvpTt7d0c9gmasH6VKZ)
	except:
		xjGMft5k8UF = YcJmC0W43u5idIELnHTU2XSsMPNt.path.dirname(WEjUrFYCBvpTt7d0c9gmasH6VKZ)
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.makedirs(xjGMft5k8UF)
		except: pass
		PCQGYiydWfZLuS.save(WEjUrFYCBvpTt7d0c9gmasH6VKZ)
	return CM4DLFlAnb
def rI48d7RQ5iWJlAGKPHsE(UmfqcN4OASJpIFEkuQgiyYnjPB,nspIk7zE2Wrf,MEhrpu4w2F1IjWkSXC,HIhQY4WnuMkmlaR5pPjC):
	s1sVGtM2dLWiRAxJYTK4laoSbBhF,HwvSzdDUq4yQfh2aVIJ,GBhXFjAIPC9UW1bswkaKpMcdRn = '',0,15000
	UmfqcN4OASJpIFEkuQgiyYnjPB = UmfqcN4OASJpIFEkuQgiyYnjPB.replace('[COLOR ','[COLOR:::')
	uzbiOxIKNclGT = LFgRCWvkM8hAD.truetype(PJt3BgZiYnhGAI4kO,size=nspIk7zE2Wrf)
	MEhrpu4w2F1IjWkSXC -= nspIk7zE2Wrf*2
	h7pHmrZTb8Yn9AKQc = KlXvBMj7oFRhLxW3OpCI2s.new('RGBA',(MEhrpu4w2F1IjWkSXC,99),(255,255,255,0))
	vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ = uIVUl3LvOfkK2NoGzq.Draw(h7pHmrZTb8Yn9AKQc)
	for Q9UgA6VGtDW5Lwj in UmfqcN4OASJpIFEkuQgiyYnjPB.splitlines():
		HwvSzdDUq4yQfh2aVIJ += HIhQY4WnuMkmlaR5pPjC
		XFKo5nbY4rUh2uBPeJk0fWExamHdjy,jbBYRuE93VL4SwiAMF68hKf7xWytN = 0,''
		for JNpHSTG5fRsncZtq in Q9UgA6VGtDW5Lwj.split(' '):
			s67AhvGV2p3R4W = jbrpunX29PLNK8FvGCcWBYm5QR(' '+JNpHSTG5fRsncZtq)
			rktpTSZLnNK4cWCRm8JQjYOz7bP0,A28Aab9SEe6 = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(s67AhvGV2p3R4W,font=uzbiOxIKNclGT)
			if XFKo5nbY4rUh2uBPeJk0fWExamHdjy+rktpTSZLnNK4cWCRm8JQjYOz7bP0<MEhrpu4w2F1IjWkSXC:
				if not jbBYRuE93VL4SwiAMF68hKf7xWytN: jbBYRuE93VL4SwiAMF68hKf7xWytN += JNpHSTG5fRsncZtq
				else: jbBYRuE93VL4SwiAMF68hKf7xWytN += ' '+JNpHSTG5fRsncZtq
				XFKo5nbY4rUh2uBPeJk0fWExamHdjy += rktpTSZLnNK4cWCRm8JQjYOz7bP0
			else:
				if rktpTSZLnNK4cWCRm8JQjYOz7bP0<MEhrpu4w2F1IjWkSXC:
					jbBYRuE93VL4SwiAMF68hKf7xWytN += '\n '+JNpHSTG5fRsncZtq
					HwvSzdDUq4yQfh2aVIJ += HIhQY4WnuMkmlaR5pPjC
					XFKo5nbY4rUh2uBPeJk0fWExamHdjy = rktpTSZLnNK4cWCRm8JQjYOz7bP0
				else:
					while rktpTSZLnNK4cWCRm8JQjYOz7bP0>MEhrpu4w2F1IjWkSXC:
						for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(1,len(' '+JNpHSTG5fRsncZtq),1):
							YunZbf5FoN = ' '+JNpHSTG5fRsncZtq[:gI689nKoH2PlifU3AMW5vVEZpFYX1]
							fsyvFNJtbp869c5rxokTSZWj2H = JNpHSTG5fRsncZtq[gI689nKoH2PlifU3AMW5vVEZpFYX1:]
							B0vmF1OI5x6fyiRkqQ8D = jbrpunX29PLNK8FvGCcWBYm5QR(YunZbf5FoN)
							o1Uwx0aSJu3Aj4FqHM7zp6,FleGqo6xv90yYtdSp = vstKiD4Z1kPjyVRl7ImFQxOhUBYGrJ.textsize(B0vmF1OI5x6fyiRkqQ8D,font=uzbiOxIKNclGT)
							if XFKo5nbY4rUh2uBPeJk0fWExamHdjy+o1Uwx0aSJu3Aj4FqHM7zp6>MEhrpu4w2F1IjWkSXC:
								GI5RrgumjlZ9hxU8dBtHk4DL6noW = rktpTSZLnNK4cWCRm8JQjYOz7bP0-o1Uwx0aSJu3Aj4FqHM7zp6
								jbBYRuE93VL4SwiAMF68hKf7xWytN += YunZbf5FoN+'\n'
								HwvSzdDUq4yQfh2aVIJ += HIhQY4WnuMkmlaR5pPjC
								rktpTSZLnNK4cWCRm8JQjYOz7bP0 = GI5RrgumjlZ9hxU8dBtHk4DL6noW
								if GI5RrgumjlZ9hxU8dBtHk4DL6noW>MEhrpu4w2F1IjWkSXC:
									XFKo5nbY4rUh2uBPeJk0fWExamHdjy = 0
									JNpHSTG5fRsncZtq = fsyvFNJtbp869c5rxokTSZWj2H
								else:
									XFKo5nbY4rUh2uBPeJk0fWExamHdjy = GI5RrgumjlZ9hxU8dBtHk4DL6noW
									jbBYRuE93VL4SwiAMF68hKf7xWytN += fsyvFNJtbp869c5rxokTSZWj2H
								break
				if HwvSzdDUq4yQfh2aVIJ>GBhXFjAIPC9UW1bswkaKpMcdRn: break
		s1sVGtM2dLWiRAxJYTK4laoSbBhF += '\n'+jbBYRuE93VL4SwiAMF68hKf7xWytN
		if HwvSzdDUq4yQfh2aVIJ>GBhXFjAIPC9UW1bswkaKpMcdRn: break
	s1sVGtM2dLWiRAxJYTK4laoSbBhF = s1sVGtM2dLWiRAxJYTK4laoSbBhF[1:]
	s1sVGtM2dLWiRAxJYTK4laoSbBhF = s1sVGtM2dLWiRAxJYTK4laoSbBhF.replace('[COLOR:::','[COLOR ')
	return s1sVGtM2dLWiRAxJYTK4laoSbBhF
def jbrpunX29PLNK8FvGCcWBYm5QR(JNpHSTG5fRsncZtq):
	if '[' in JNpHSTG5fRsncZtq and ']' in JNpHSTG5fRsncZtq:
		gbFEcsrjiR7Ut = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		npfJvqz1y0BxUD2ORcYbECMKmHQ = QPuHKNAT4jmCRg.findall('\[COLOR .*?\]',JNpHSTG5fRsncZtq,QPuHKNAT4jmCRg.DOTALL)
		WqIvgO2CERh4aXomTMpV8SjzAtNJ = QPuHKNAT4jmCRg.findall('\[COLOR:::.*?\]',JNpHSTG5fRsncZtq,QPuHKNAT4jmCRg.DOTALL)
		HOZSqJQli0rcgm3KuzaEtCFTUPxn = gbFEcsrjiR7Ut+npfJvqz1y0BxUD2ORcYbECMKmHQ+WqIvgO2CERh4aXomTMpV8SjzAtNJ
		for xTgjn2StZAJP70ayeFV4YqmORk51 in HOZSqJQli0rcgm3KuzaEtCFTUPxn: JNpHSTG5fRsncZtq = JNpHSTG5fRsncZtq.replace(xTgjn2StZAJP70ayeFV4YqmORk51,'')
	return JNpHSTG5fRsncZtq
def SH3bZnoagFlq6TLJOEYXfBNdKRM(OO1XlVPzfQrMTmJv):
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('\n','_sss__newline_')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[RTL]','_sss__linertl_')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[LEFT]','_sss__lineleft_')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[RIGHT]','_sss__lineright_')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[CENTER]','_sss__linecenter_')
	OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[/COLOR]','_sss__endcolor_')
	LqRKJjGn9t4aFHQ7XCE1 = QPuHKNAT4jmCRg.findall('\[COLOR (.*?)\]',OO1XlVPzfQrMTmJv,QPuHKNAT4jmCRg.DOTALL)
	for xjKOoBeg0kz7spqmnuL in LqRKJjGn9t4aFHQ7XCE1: OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.replace('[COLOR '+xjKOoBeg0kz7spqmnuL+']','_sss__newcolor'+xjKOoBeg0kz7spqmnuL+'_')
	return OO1XlVPzfQrMTmJv
def q9AltNyD2Q1uL(pphVUbJkGtHXndg84iZl2DPImSzoC=''):
	if not pphVUbJkGtHXndg84iZl2DPImSzoC: pphVUbJkGtHXndg84iZl2DPImSzoC = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Label')
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('[/COLOR]','')
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	m1cP9L8ilAIHnaJUR4K = QPuHKNAT4jmCRg.findall('\d\d:\d\d ',pphVUbJkGtHXndg84iZl2DPImSzoC,QPuHKNAT4jmCRg.DOTALL)
	if m1cP9L8ilAIHnaJUR4K: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.split(m1cP9L8ilAIHnaJUR4K[0],1)[1]
	if not pphVUbJkGtHXndg84iZl2DPImSzoC: pphVUbJkGtHXndg84iZl2DPImSzoC = 'Main Menu'
	return pphVUbJkGtHXndg84iZl2DPImSzoC
def ZVgGt1Ua7ChRz4ElJBp9YTqMS(E2YPvG7AZ81):
	SSo58nIXNF9peBlE = ''.join(gI689nKoH2PlifU3AMW5vVEZpFYX1 for gI689nKoH2PlifU3AMW5vVEZpFYX1 in E2YPvG7AZ81 if gI689nKoH2PlifU3AMW5vVEZpFYX1 not in '\/":*?<>|'+ICxkgfWtNMBHQ40co8VsjFO)
	return SSo58nIXNF9peBlE
def vvSrTfCOiNqPcoLa7eZn2s5Mlxk9YV(zt1qZvA74HunVPWCON):
	UT2HOni53GWMsxv4oJzLgch = QPuHKNAT4jmCRg.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",zt1qZvA74HunVPWCON,QPuHKNAT4jmCRg.S)
	if UT2HOni53GWMsxv4oJzLgch:
		LqimI0jkHnsKAdCelT6tONcRQfr,gqN5RVKbLSrp0sBJEGX1i46myUhju = UT2HOni53GWMsxv4oJzLgch[0]
		LqimI0jkHnsKAdCelT6tONcRQfr = QPuHKNAT4jmCRg.findall("=[\r\n\s\t]+'(.*?)';", LqimI0jkHnsKAdCelT6tONcRQfr, QPuHKNAT4jmCRg.S)[0]
		if LqimI0jkHnsKAdCelT6tONcRQfr and gqN5RVKbLSrp0sBJEGX1i46myUhju:
			BBS3ljra8NQLJ5Z1t06Oycd = LqimI0jkHnsKAdCelT6tONcRQfr.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			p35RL2kZiuSQmPOz8sFI = BBS3ljra8NQLJ5Z1t06Oycd.split('.')
			zt1qZvA74HunVPWCON = ''
			for kkWLc2YUpxDRHyB5bmi0raMSqOt in p35RL2kZiuSQmPOz8sFI:
				KiMqEuUBZOYdVQ8mLRl0e7yHvaPn = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(kkWLc2YUpxDRHyB5bmi0raMSqOt+'==').decode('utf8')
				H3DVJcaL2K9EXwN6Y5OnIsgSr1 = QPuHKNAT4jmCRg.findall('\d+', KiMqEuUBZOYdVQ8mLRl0e7yHvaPn, QPuHKNAT4jmCRg.S)
				if H3DVJcaL2K9EXwN6Y5OnIsgSr1:
					VgFLfj27rmltJwe1Pyz = int(H3DVJcaL2K9EXwN6Y5OnIsgSr1[0])
					VgFLfj27rmltJwe1Pyz += int(gqN5RVKbLSrp0sBJEGX1i46myUhju)
					zt1qZvA74HunVPWCON = zt1qZvA74HunVPWCON + chr(VgFLfj27rmltJwe1Pyz)
			if Nnxm30dfoBWRYpIC7KsQGl: zt1qZvA74HunVPWCON = zt1qZvA74HunVPWCON.encode('iso-8859-1').decode('utf8')
	return zt1qZvA74HunVPWCON
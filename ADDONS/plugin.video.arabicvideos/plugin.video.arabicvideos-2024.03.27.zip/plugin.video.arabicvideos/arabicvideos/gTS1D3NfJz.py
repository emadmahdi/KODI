# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'EGYNOW'
JE7QrkmhletLwA0OZXu = '_EGN_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==430: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==431: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==432: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==433: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==434: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==437: RRMWBwU6pG = Xv4qoz72aWmn(url)
	elif mode==439: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr+'/films','','','','','EGYNOW-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = QPuHKNAT4jmCRg.findall('"canonical" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ka6I93CnvublQMtjr = ka6I93CnvublQMtjr[0].strip('/')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(ka6I93CnvublQMtjr,'url')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',ka6I93CnvublQMtjr,435)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',ka6I93CnvublQMtjr,434)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المضاف حديثا',ka6I93CnvublQMtjr,431)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'افلام اون لاين',ka6I93CnvublQMtjr+'/films1',436)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مسلسلات اون لاين',ka6I93CnvublQMtjr+'/series-all1',436)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'قائمة تفصيلية',ka6I93CnvublQMtjr,437)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"SiteNavigation"(.*?)"Search"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,431)
	return
def Xv4qoz72aWmn(website=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = QPuHKNAT4jmCRg.findall('"canonical" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ka6I93CnvublQMtjr = ka6I93CnvublQMtjr[0].strip('/')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(ka6I93CnvublQMtjr,'url')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"ListDroped"(.*?)"SearchingMaster"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for jsEpRxQH76,pp8iHB3W9Cs,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		VV7yf2htDCBU6EeSX8TJQM = website+'/explore/?'+jsEpRxQH76+'='+pp8iHB3W9Cs
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,431)
	return
def pF0d4b2ZY9(url):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',url,431)
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"titleSectionCon"(.*?)</div></div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('data-key="(.*?)".*?<em>(.*?)</em>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for oN6FKz2SkGiLnJ3tx4,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ka6I93CnvublQMtjr+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+oN6FKz2SkGiLnJ3tx4
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,431)
	return
def SPFl6UGK4mrBua(url,lp3eGht9uF4mMCR6YIWz=''):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
		Eudgv5cTUHF2AzKpkx = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','EGYNOW-TITLES-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
	elif lp3eGht9uF4mMCR6YIWz=='featured':
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"MainSlider"(.*?)"MatchesTable"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"BlocksList"(.*?)"Paginate"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('"BlocksList"(.*?)"titleSectionCon"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
	if not items: items = QPuHKNAT4jmCRg.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM).strip('/')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,432,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and 'الحلقة' in title:
			title = '_MOD_' + CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,433,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif '/movseries/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,431,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,433,G2WR0Oacvdq8ZQTjKboDU)
	if lp3eGht9uF4mMCR6YIWz!='featured':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"Paginate"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+VV7yf2htDCBU6EeSX8TJQM
				VV7yf2htDCBU6EeSX8TJQM = UH1IuvwM9e4cl7if63nNdozJFSj(VV7yf2htDCBU6EeSX8TJQM)
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,431)
		lO6rM8NcKUL5g4wd31nEGQF7HRfu = QPuHKNAT4jmCRg.findall('showmore" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if lO6rM8NcKUL5g4wd31nEGQF7HRfu:
			VV7yf2htDCBU6EeSX8TJQM = lO6rM8NcKUL5g4wd31nEGQF7HRfu[0]
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مشاهدة المزيد',VV7yf2htDCBU6EeSX8TJQM,431)
	return
def opLlxOB2dUVZ5JF4j(url):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	kzlepwfG1iEyIJKTY45quXO,kk73xHNzri1P2wgULMv4sDtoTnybO = [],[]
	if 'Episodes.php' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
		Eudgv5cTUHF2AzKpkx = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','EGYNOW-EPISODES-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		kk73xHNzri1P2wgULMv4sDtoTnybO = [Ht6Gg8lbciAd9FaUQVs]
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"SeasonsList"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"EpisodesList"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO:
		G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"og:image" content="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for qqubH4jokedIstn1JP3fQ,EjDYkWFrAOM8Pm2UC91g5,title in items:
			VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+EjDYkWFrAOM8Pm2UC91g5+'&post_id='+qqubH4jokedIstn1JP3fQ
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,433,G2WR0Oacvdq8ZQTjKboDU)
	elif kk73xHNzri1P2wgULMv4sDtoTnybO:
		G2WR0Oacvdq8ZQTjKboDU = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Thumb')
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,CiZxgXTGW9pv in items:
			title = title+' '+CiZxgXTGW9pv
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,432,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/watch/'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','EGYNOW-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'url')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"container-servers"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		RRtUaOkQKgPCJTvFYz0 = QPuHKNAT4jmCRg.findall('data-id="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if RRtUaOkQKgPCJTvFYz0:
			RRtUaOkQKgPCJTvFYz0 = RRtUaOkQKgPCJTvFYz0[0]
			items = QPuHKNAT4jmCRg.findall('data-server="(.*?)".*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for BHgLX9GZTb2jJrWiNKE,title in items:
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+BHgLX9GZTb2jJrWiNKE+'&post_id='+RRtUaOkQKgPCJTvFYz0+'?named='+title+'__watch'
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	LzOgMVtEQxJkX560ITpCjqdc7Bfie = QPuHKNAT4jmCRg.findall('"container-iframe"><iframe src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if LzOgMVtEQxJkX560ITpCjqdc7Bfie:
		LzOgMVtEQxJkX560ITpCjqdc7Bfie = LzOgMVtEQxJkX560ITpCjqdc7Bfie[0].replace('\n','')
		title = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(LzOgMVtEQxJkX560ITpCjqdc7Bfie,'name')
		VV7yf2htDCBU6EeSX8TJQM = LzOgMVtEQxJkX560ITpCjqdc7Bfie+'?named='+title+'__embed'
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"container-download"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,i5DftlhA6vQ2GF in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\n','')
			if i5DftlhA6vQ2GF!='': i5DftlhA6vQ2GF = '____'+i5DftlhA6vQ2GF
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'+i5DftlhA6vQ2GF
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','%20')
	url = GqcEfFR8XQPgBMLr+'/?s='+search
	SPFl6UGK4mrBua(url)
	return
def PD19Sz64kNmaXxw(url):
	url = url.split('/smartemadfilter?')[0]
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',ka6I93CnvublQMtjr,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('("dropdown-button".*?)"SearchingMaster"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return K0MwVeCGOmJho
def zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed):
	items = QPuHKNAT4jmCRg.findall('data-term="(\d+)" data-name="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return items
def nGPYq9pSD5(url):
	rrU0IR1Aga6Y = url.split('/smartemadfilter?')[0]
	eek0phlJjL6MWVXsmy7wFPz2oT = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	url = url.replace(rrU0IR1Aga6Y,eek0phlJjL6MWVXsmy7wFPz2oT)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def nuAk2g6Qeb7rvfEyHNsh(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,url):
	sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'modified_filters')
	lc154VhT9DCqMk8 = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	lc154VhT9DCqMk8 = nGPYq9pSD5(lc154VhT9DCqMk8)
	return lc154VhT9DCqMk8
vMgBXHJ4ETR1qjkDAhKsc9SuY = ['category','country','genre','release-year']
RBkuwxQsqh6CaLzMcGWbftSrI = ['quality','release-year','genre','category','language','country']
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if vMgBXHJ4ETR1qjkDAhKsc9SuY[0]+'=' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[0]
		for PXBFxvuUlLDHGpm58 in range(len(vMgBXHJ4ETR1qjkDAhKsc9SuY[0:-1])):
			if vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+jsEpRxQH76+'=0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+jsEpRxQH76+'=0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='ALL_ITEMS_FILTER':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+Lb7kxwJZBPquygXoO4nTSN3
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nGPYq9pSD5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,431)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,431)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K0MwVeCGOmJho = PD19Sz64kNmaXxw(url)
	dict = {}
	for name,wltPGJcYo12Ed,qQ3oR7maZGeFByA6uitjrd in K0MwVeCGOmJho:
		name = name.replace('--','')
		items = zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed)
		if '=' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='SPECIFIED_FILTER':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<2:
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]:
					url = nGPYq9pSD5(url)
					SPFl6UGK4mrBua(url)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'SPECIFIED_FILTER___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nGPYq9pSD5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,431)
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,435,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='ALL_ITEMS_FILTER':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع :'+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,434,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			if pp8iHB3W9Cs=='196533': wMq2UBSjsfgchHzprXWFOTdn5 = 'أفلام نيتفلكس'
			elif pp8iHB3W9Cs=='196531': wMq2UBSjsfgchHzprXWFOTdn5 = 'مسلسلات نيتفلكس'
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = wMq2UBSjsfgchHzprXWFOTdn5
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'='+wMq2UBSjsfgchHzprXWFOTdn5
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'#+dict[qQ3oR7maZGeFByA6uitjrd]['0']
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'+name
			if type=='ALL_ITEMS_FILTER': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,434,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='SPECIFIED_FILTER' and vMgBXHJ4ETR1qjkDAhKsc9SuY[-2]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				lc154VhT9DCqMk8 = nuAk2g6Qeb7rvfEyHNsh(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,url)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lc154VhT9DCqMk8,431)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,435,'','',q0NkUvatj1HcndbF9Yrsw)
	return
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.replace('=&','=0&')
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&')
	XTiOm8cUEJCh3ryql = {}
	if '=' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	VAlPewLIfoQv6dash = ''
	for key in RBkuwxQsqh6CaLzMcGWbftSrI:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
		elif mode=='all_filters': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.replace('=0','=')
	return VAlPewLIfoQv6dash
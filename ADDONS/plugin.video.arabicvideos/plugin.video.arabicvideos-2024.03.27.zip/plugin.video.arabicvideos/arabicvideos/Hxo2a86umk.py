# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'EGYBESTVIP'
JE7QrkmhletLwA0OZXu = '_EGV_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
def hLD0mk9HIuPOz7pw(mode,url,YSTbrKgPf7NyhIDizB,text):
	if   mode==220: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==221: RRMWBwU6pG = SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB)
	elif mode==222: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==223: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==224: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url)
	elif mode==229: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','EGYBEST-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="i i-home"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)"(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,222)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="ba(.*?)<script',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,221)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if 'html' not in VV7yf2htDCBU6EeSX8TJQM: continue
			if not VV7yf2htDCBU6EeSX8TJQM.endswith('/'): fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,221)
	return Ht6Gg8lbciAd9FaUQVs
def pF0d4b2ZY9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="rs_scroll"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,224)
	return
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url):
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',url,221)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="sub_nav(.*?)id="movies',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".+?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if VV7yf2htDCBU6EeSX8TJQM=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,221)
	else: SPFl6UGK4mrBua(url)
	return
def SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB='1'):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	if '/search' in url or '?' in url: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url + '&'
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url + '?'
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao + 'page=' + YSTbrKgPf7NyhIDizB
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		TTCRYZroizb=QPuHKNAT4jmCRg.findall('class="pda"(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[-1]
	elif '/series/' in url:
		TTCRYZroizb=QPuHKNAT4jmCRg.findall('class="owl-carousel owl-carousel(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
	else:
		TTCRYZroizb=QPuHKNAT4jmCRg.findall('id="movies(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[-1]
	items = QPuHKNAT4jmCRg.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if '/movie/' in VV7yf2htDCBU6EeSX8TJQM or '/episode' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM.rstrip('/'),223,G2WR0Oacvdq8ZQTjKboDU)
		else:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,221,G2WR0Oacvdq8ZQTjKboDU)
	if len(items)>=16:
		rrxpI7agK8DCUF = ['/movies','/tv','/search','/trending']
		YSTbrKgPf7NyhIDizB = int(YSTbrKgPf7NyhIDizB)
		if any(pp8iHB3W9Cs in url for pp8iHB3W9Cs in rrxpI7agK8DCUF):
			for en2j3MCK8ZmsH in range(0,1000,100):
				if int(YSTbrKgPf7NyhIDizB/100)*100==en2j3MCK8ZmsH:
					for PXBFxvuUlLDHGpm58 in range(en2j3MCK8ZmsH,en2j3MCK8ZmsH+100,10):
						if int(YSTbrKgPf7NyhIDizB/10)*10==PXBFxvuUlLDHGpm58:
							for oebf8pTAIGOs3NC in range(PXBFxvuUlLDHGpm58,PXBFxvuUlLDHGpm58+10,1):
								if not YSTbrKgPf7NyhIDizB==oebf8pTAIGOs3NC and oebf8pTAIGOs3NC!=0:
									fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+str(oebf8pTAIGOs3NC),url,221,'',str(oebf8pTAIGOs3NC))
						elif PXBFxvuUlLDHGpm58!=0: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+str(PXBFxvuUlLDHGpm58),url,221,'',str(PXBFxvuUlLDHGpm58))
						else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+str(1),url,221,'',str(1))
				elif en2j3MCK8ZmsH!=0: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+str(en2j3MCK8ZmsH),url,221,'',str(en2j3MCK8ZmsH))
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+str(1),url,221)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = [],[]
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'','','','EGYBESTVIP-PLAY-1st')
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('<td>التصنيف</td>.*?">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	eeq6V1bOZiD9JxjLkygKN,R1mtkuwgvEjCpJq0e = '',''
	dJtuZ0e3p42,gsV1EnWFz9c = Ht6Gg8lbciAd9FaUQVs,Ht6Gg8lbciAd9FaUQVs
	IZfEyWjH2QqA = QPuHKNAT4jmCRg.findall('show_dl api" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if IZfEyWjH2QqA:
		for VV7yf2htDCBU6EeSX8TJQM in IZfEyWjH2QqA:
			if '/watch/' in VV7yf2htDCBU6EeSX8TJQM: eeq6V1bOZiD9JxjLkygKN = VV7yf2htDCBU6EeSX8TJQM
			elif '/download/' in VV7yf2htDCBU6EeSX8TJQM: R1mtkuwgvEjCpJq0e = VV7yf2htDCBU6EeSX8TJQM
		if eeq6V1bOZiD9JxjLkygKN!='': dJtuZ0e3p42 = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,eeq6V1bOZiD9JxjLkygKN,'','','','EGYBESTVIP-PLAY-2nd')
		if R1mtkuwgvEjCpJq0e!='': gsV1EnWFz9c = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,R1mtkuwgvEjCpJq0e,'','','','EGYBESTVIP-PLAY-3rd')
	ii43IejDrhU5s7E0TAcYMlm = QPuHKNAT4jmCRg.findall('id="video".*?data-src="(.*?)"',dJtuZ0e3p42,QPuHKNAT4jmCRg.DOTALL)
	if ii43IejDrhU5s7E0TAcYMlm:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ii43IejDrhU5s7E0TAcYMlm[0]
		if lZqkuhgaBHSVX8NItKG05cdLJe7Ao!='' and 'uploaded.egybest.download' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao and '/?id=_' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			iRSILm7Nv6DZAaztp = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','EGYBESTVIP-PLAY-4th')
			O2WPmME53VdDRJY = QPuHKNAT4jmCRg.findall('source src="(.*?)" title="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			if O2WPmME53VdDRJY:
				for VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF in O2WPmME53VdDRJY:
					LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM+'?named=ed.egybest.do__watch__mp4__'+i5DftlhA6vQ2GF)
			else:
				BHgLX9GZTb2jJrWiNKE = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split('/')[2]
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(lZqkuhgaBHSVX8NItKG05cdLJe7Ao+'?named='+BHgLX9GZTb2jJrWiNKE+'__watch')
		elif lZqkuhgaBHSVX8NItKG05cdLJe7Ao!='':
			BHgLX9GZTb2jJrWiNKE = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split('/')[2]
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(lZqkuhgaBHSVX8NItKG05cdLJe7Ao+'?named='+BHgLX9GZTb2jJrWiNKE+'__watch')
	srtY0XlAU3uOdkCghjMLmoi = QPuHKNAT4jmCRg.findall('<table class="dls_table(.*?)</table>',gsV1EnWFz9c,QPuHKNAT4jmCRg.DOTALL)
	if srtY0XlAU3uOdkCghjMLmoi:
		srtY0XlAU3uOdkCghjMLmoi = srtY0XlAU3uOdkCghjMLmoi[0]
		gGtSNYACID7Xcu2mJRMrqy = QPuHKNAT4jmCRg.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',srtY0XlAU3uOdkCghjMLmoi,QPuHKNAT4jmCRg.DOTALL)
		if gGtSNYACID7Xcu2mJRMrqy:
			for i5DftlhA6vQ2GF,VV7yf2htDCBU6EeSX8TJQM in gGtSNYACID7Xcu2mJRMrqy:
				if 'myegyvip' not in VV7yf2htDCBU6EeSX8TJQM: continue
				if VV7yf2htDCBU6EeSX8TJQM.count('/')>=2:
					BHgLX9GZTb2jJrWiNKE = VV7yf2htDCBU6EeSX8TJQM.split('/')[2]
					LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+BHgLX9GZTb2jJrWiNKE+'__download__mp4__'+i5DftlhA6vQ2GF)
	H6hWCxi0SEZ8MI43qGursNodTvV = []
	for VV7yf2htDCBU6EeSX8TJQM in LL8heV7kxYI5bOjEZ6XaUQWwfPA:
		H6hWCxi0SEZ8MI43qGursNodTvV.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(H6hWCxi0SEZ8MI43qGursNodTvV,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','+')
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,GqcEfFR8XQPgBMLr,'','','','EGYBESTVIP-SEARCH-1st')
	uWCKp2UeRYGXINl = QPuHKNAT4jmCRg.findall('name="_token" value="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if uWCKp2UeRYGXINl:
		url = GqcEfFR8XQPgBMLr+'/search?_token='+uWCKp2UeRYGXINl[0]+'&q='+Unr6jRmMIv80lSGbkBCehpaWAdV
		SPFl6UGK4mrBua(url)
	return
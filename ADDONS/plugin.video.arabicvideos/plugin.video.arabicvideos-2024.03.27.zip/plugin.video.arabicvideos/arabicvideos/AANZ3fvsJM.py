# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'ARABICTOONS'
JE7QrkmhletLwA0OZXu = '_ART_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==730: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==731: RRMWBwU6pG = SPFl6UGK4mrBua(url)
	elif mode==732: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==733: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==734: RRMWBwU6pG = ek6D8j9CRBnQ1ZAum(url)
	elif mode==735: RRMWBwU6pG = LLsMBmPTqkC4Rab(url)
	elif mode==739: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مسلسلات مميزة',GqcEfFR8XQPgBMLr+'/top.php',735)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مسلسلات',GqcEfFR8XQPgBMLr+'/cartoon.php',734)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'افلام',GqcEfFR8XQPgBMLr+'/movies.php',731)
	return
def ek6D8j9CRBnQ1ZAum(url):
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الكل',url,731)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('label="navigation"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall("href='(.*?)'>(.*?)</a>",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = 'حرف '+title
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,731)
	return
def LLsMBmPTqkC4Rab(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="slider"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			G2WR0Oacvdq8ZQTjKboDU = GqcEfFR8XQPgBMLr+'/'+G2WR0Oacvdq8ZQTjKboDU
			title = title.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,733,G2WR0Oacvdq8ZQTjKboDU)
	return
def SPFl6UGK4mrBua(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("class='moviesBlocks(.*?)navigation",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
		G2WR0Oacvdq8ZQTjKboDU = GqcEfFR8XQPgBMLr+'/'+G2WR0Oacvdq8ZQTjKboDU
		title = title.strip(' ')
		if 'movies.php' in url: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,732,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,733,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[-1]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = title.strip(' ')
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,731)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("class='moviesBlocks(.*?)script",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,cwaBpyYtN1kVAR2HiP in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			G2WR0Oacvdq8ZQTjKboDU = GqcEfFR8XQPgBMLr+'/'+G2WR0Oacvdq8ZQTjKboDU
			title = title.strip(' ')
			title = title+' '+cwaBpyYtN1kVAR2HiP.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,732,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	YsDryBSXquzdEUta8kxjfO = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if Y4xiULzGTKjb8mulO:
		VV7yf2htDCBU6EeSX8TJQM = Y4xiULzGTKjb8mulO[0]
		if 'Referer=' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'|Referer=https://www.arabic-toons.com'
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named=__embed')
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','%20')
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = ['','m']
	hRicT4yFJ5ZbMPK2tVews = ['مسلسلات','افلام']
	if showDialogs:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر النوع المطلوب:', hRicT4yFJ5ZbMPK2tVews)
		if ShT1xUHjlDotkRuPq7gv==-1: return
	else: ShT1xUHjlDotkRuPq7gv = 0
	type = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	url = GqcEfFR8XQPgBMLr+'/livesearch.php?'+type+'&q='+search
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
		title = title.strip(' ')
		if type=='m': fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,732)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,733)
	return
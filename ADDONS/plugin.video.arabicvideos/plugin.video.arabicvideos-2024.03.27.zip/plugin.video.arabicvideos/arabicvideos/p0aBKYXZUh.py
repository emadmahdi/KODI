# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'FAJERSHOW'
JE7QrkmhletLwA0OZXu = '_FJS_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==390: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==391: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==392: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==393: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==399: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',399,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','FAJERSHOW-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = QPuHKNAT4jmCRg.findall('<header>.*?<h2>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for HY6PBsZvlUTGOW5eXcVnt27Ioi1 in range(len(items)):
		title = items[HY6PBsZvlUTGOW5eXcVnt27Ioi1]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,GqcEfFR8XQPgBMLr,391,'','','latest'+str(HY6PBsZvlUTGOW5eXcVnt27Ioi1))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مختارات عشوائية',GqcEfFR8XQPgBMLr,391,'','','randoms')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أعلى الأفلام تقييماً',GqcEfFR8XQPgBMLr,391,'','','top_imdb_movies')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أعلى المسلسلات تقييماً',GqcEfFR8XQPgBMLr,391,'','','top_imdb_series')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أفلام مميزة',GqcEfFR8XQPgBMLr+'/movies',391,'','','featured_movies')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مسلسلات مميزة',GqcEfFR8XQPgBMLr+'/tvshows',391,'','','featured_tvshows')
	wltPGJcYo12Ed = ''
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="menu"(.*?)id="contenedor"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb: wltPGJcYo12Ed += TTCRYZroizb[0]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr+'/movies','','','','','FAJERSHOW-MENU-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="releases"(.*?)aside',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb: wltPGJcYo12Ed += TTCRYZroizb[0]
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	IP2cvAkDs87K9RjquUf60Xxy4e1d = True
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if title=='الأعلى مشاهدة':
			if IP2cvAkDs87K9RjquUf60Xxy4e1d:
				title = 'الافلام '+title
				IP2cvAkDs87K9RjquUf60Xxy4e1d = False
			else: title = 'المسلسلات '+title
		if title not in EhRQ8zB1fdkj5vN6HlmqD7SOU:
			if title=='أفلام': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,GqcEfFR8XQPgBMLr+'/movies',391,'','','all_movies_tvshows')
			elif title=='مسلسلات': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,GqcEfFR8XQPgBMLr+'/tvshows',391,'','','all_movies_tvshows')
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,391)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,type):
	wltPGJcYo12Ed,items = [],[]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FAJERSHOW-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if type in ['featured_movies','featured_tvshows']:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="content"(.*?)id="archive-content"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
	elif type=='all_movies_tvshows':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="archive-content"(.*?)class="pagination"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
	elif type=='top_imdb_movies':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='top_imdb_series':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall("class='top-imdb-list tright(.*?)footer",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='search':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="search-page"(.*?)class="sidebar',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='sider':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="widget(.*?)class="widget',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		QV8h5bD9YtNq1gfmx2jUyZlXASWv4L = QPuHKNAT4jmCRg.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		LL8heV7kxYI5bOjEZ6XaUQWwfPA,cR4vMuiDFYW9LOXHt7xqg,xitERh4TD2jGJPq5Nuv39CAmg = zip(*QV8h5bD9YtNq1gfmx2jUyZlXASWv4L)
		items = zip(cR4vMuiDFYW9LOXHt7xqg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,xitERh4TD2jGJPq5Nuv39CAmg)
	elif type=='randoms':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="slider-movies-tvshows"(.*?)<header>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif 'latest' in type:
		HY6PBsZvlUTGOW5eXcVnt27Ioi1 = int(type[-1:])
		Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('<header>','<end><start>')
		Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('</div></div></div>','</div></div></div><end>')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<start>(.*?)<end>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[HY6PBsZvlUTGOW5eXcVnt27Ioi1]
		if HY6PBsZvlUTGOW5eXcVnt27Ioi1==6:
			QV8h5bD9YtNq1gfmx2jUyZlXASWv4L = QPuHKNAT4jmCRg.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			cR4vMuiDFYW9LOXHt7xqg,xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = zip(*QV8h5bD9YtNq1gfmx2jUyZlXASWv4L)
			items = zip(cR4vMuiDFYW9LOXHt7xqg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,xitERh4TD2jGJPq5Nuv39CAmg)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="content"(.*?)class="(pagination|sidebar)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0][0]
			if '/collection/' in url:
				items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			elif '/quality/' in url:
				items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if not items and wltPGJcYo12Ed:
		items = QPuHKNAT4jmCRg.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = QPuHKNAT4jmCRg.findall('^(.*?)<.*?serie">(.*?)<',title,QPuHKNAT4jmCRg.DOTALL)
			title = title[0][1]
			if title in gltHFKTroJfpLe: continue
			gltHFKTroJfpLe.append(title)
			title = '_MOD_'+title
		nUbpaNT0vhcj7ZsEz = QPuHKNAT4jmCRg.findall('^(.*?)<',title,QPuHKNAT4jmCRg.DOTALL)
		if nUbpaNT0vhcj7ZsEz: title = nUbpaNT0vhcj7ZsEz[0]
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if '/tvshows/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,393,G2WR0Oacvdq8ZQTjKboDU)
		elif '/episodes/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,393,G2WR0Oacvdq8ZQTjKboDU)
		elif '/seasons/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,393,G2WR0Oacvdq8ZQTjKboDU)
		elif '/collection/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,391,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,392,G2WR0Oacvdq8ZQTjKboDU)
	if type not in ['featured_movies','featured_tvshows']:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,391,'','',type)
	return
def opLlxOB2dUVZ5JF4j(url):
	BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	url = url.replace(BHgLX9GZTb2jJrWiNKE,GqcEfFR8XQPgBMLr)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FAJERSHOW-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('class="C rated".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<ul class="episodios">(.*?)</ul></div></div></div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,392,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	Ht6Gg8lbciAd9FaUQVs = KwXiyRO72Gju(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','FAJERSHOW-PLAY-1st')
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('class="C rated".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0][0]
		items = QPuHKNAT4jmCRg.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for type,qqubH4jokedIstn1JP3fQ,AX3MjK95WRYDZPdTsq4Fz,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+qqubH4jokedIstn1JP3fQ+'&nume='+AX3MjK95WRYDZPdTsq4Fz+'&type='+type
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF,ooR6tf4gCTFXP7 in items:
			if '=' in G2WR0Oacvdq8ZQTjKboDU:
				qqivDAF1ZS = G2WR0Oacvdq8ZQTjKboDU.split('=')[1]
				title = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(qqivDAF1ZS,'host')
			else: title = ''
			title = ooR6tf4gCTFXP7+' '+title
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download____'+i5DftlhA6vQ2GF
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/?s='+search
	SPFl6UGK4mrBua(url,'search')
	return
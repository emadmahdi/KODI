# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'CIMANOW'
JE7QrkmhletLwA0OZXu = '_CMN_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['قائمتي']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==300: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==301: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==302: RRMWBwU6pG = SPFl6UGK4mrBua(url)
	elif mode==303: RRMWBwU6pG = VRktAN65nrGDCqs2vFXuOHcflSh(url)
	elif mode==304: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==305: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==306: RRMWBwU6pG = cIwQDWqvJU()
	elif mode==309: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+'لماذا الموقع بطيء','',306)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr+'/home','','','','','CIMANOW-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<header>(.*?)</header>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('<li><a href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = title.strip(' ')
		if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,301)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	pF0d4b2ZY9(GqcEfFR8XQPgBMLr+'/home',Ht6Gg8lbciAd9FaUQVs)
	return Ht6Gg8lbciAd9FaUQVs
def cIwQDWqvJU():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def pF0d4b2ZY9(url,Ht6Gg8lbciAd9FaUQVs=''):
	if not Ht6Gg8lbciAd9FaUQVs:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	HY6PBsZvlUTGOW5eXcVnt27Ioi1 = 0
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('(<section>.*?</section>)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		for wltPGJcYo12Ed in TTCRYZroizb:
			HY6PBsZvlUTGOW5eXcVnt27Ioi1 += 1
			items = QPuHKNAT4jmCRg.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for title,C8yk2pBrxKXv7ZYcm5gs19winAaI0,VV7yf2htDCBU6EeSX8TJQM in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in C8yk2pBrxKXv7ZYcm5gs19winAaI0:
					if wltPGJcYo12Ed.count('/category/')>0:
						K0FhCQTV4fPruR3JMDbwekY9scn = QPuHKNAT4jmCRg.findall('href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
						for VV7yf2htDCBU6EeSX8TJQM in K0FhCQTV4fPruR3JMDbwekY9scn:
							title = VV7yf2htDCBU6EeSX8TJQM.split('/')[-2]
							fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,301)
						continue
					else: VV7yf2htDCBU6EeSX8TJQM = url+'?sequence='+str(HY6PBsZvlUTGOW5eXcVnt27Ioi1)
				if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,302)
	else: SPFl6UGK4mrBua(url,Ht6Gg8lbciAd9FaUQVs)
	return
def SPFl6UGK4mrBua(url,Ht6Gg8lbciAd9FaUQVs=''):
	if Ht6Gg8lbciAd9FaUQVs=='':
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMANOW-TITLES-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if '?sequence=' in url:
		url,HY6PBsZvlUTGOW5eXcVnt27Ioi1 = url.split('?sequence=')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('(<section>.*?</section>)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[int(HY6PBsZvlUTGOW5eXcVnt27Ioi1)-1]
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"posts"(.*?)</body>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for VV7yf2htDCBU6EeSX8TJQM,data,G2WR0Oacvdq8ZQTjKboDU in items:
		title = QPuHKNAT4jmCRg.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,QPuHKNAT4jmCRg.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = QPuHKNAT4jmCRg.findall('title">.*?</em>(.*?)<',data,QPuHKNAT4jmCRg.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = QPuHKNAT4jmCRg.findall('title">(.*?)<',data,QPuHKNAT4jmCRg.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if title not in gltHFKTroJfpLe:
			gltHFKTroJfpLe.append(title)
			y8qSvx0Z9MY = VV7yf2htDCBU6EeSX8TJQM+data+G2WR0Oacvdq8ZQTjKboDU
			if '/selary/' in y8qSvx0Z9MY or 'مسلسل' in y8qSvx0Z9MY or '"episode"' in y8qSvx0Z9MY:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,303,G2WR0Oacvdq8ZQTjKboDU)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,305,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<li><a href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,302)
	return
def VRktAN65nrGDCqs2vFXuOHcflSh(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	name = QPuHKNAT4jmCRg.findall('<title>(.*?)</title>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<section(.*?)</section>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if len(items)>1:
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,304)
		else: opLlxOB2dUVZ5JF4j(url)
	return
def opLlxOB2dUVZ5JF4j(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if '/selary/' not in url:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"episodes"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,305)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"details"(.*?)"related"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			title = title.replace('\n','').strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,305,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'watching/'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','CIMANOW-PLAY-5th')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"download"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.replace('\n','').strip(' ')
			i5DftlhA6vQ2GF = QPuHKNAT4jmCRg.findall('\d\d\d+',title,QPuHKNAT4jmCRg.DOTALL)
			if i5DftlhA6vQ2GF:
				i5DftlhA6vQ2GF = '____'+i5DftlhA6vQ2GF[0]
				title = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
			else: i5DftlhA6vQ2GF = ''
			FsnXTNzcG53RUk = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'+i5DftlhA6vQ2GF
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(FsnXTNzcG53RUk)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"watch"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('"embed".*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
			title = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__embed'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		Y4xiULzGTKjb8mulO = [GqcEfFR8XQPgBMLr+'/wp-content/themes/Cima%20Now%20New/core.php']
		if Y4xiULzGTKjb8mulO:
			items = QPuHKNAT4jmCRg.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for A1pJYqSia7V4wKMnuvLe30QbrkGj,id,title in items:
				title = title.replace('\n','').strip(' ')
				VV7yf2htDCBU6EeSX8TJQM = Y4xiULzGTKjb8mulO[0]+'?action=switch&index='+A1pJYqSia7V4wKMnuvLe30QbrkGj+'&id='+id+'?named='+title+'__watch'
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr + '/?s='+search
	SPFl6UGK4mrBua(url)
	return
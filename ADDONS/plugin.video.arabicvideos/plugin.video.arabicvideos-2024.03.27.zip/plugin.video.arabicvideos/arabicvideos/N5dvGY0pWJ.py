# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'RANDOMS'
JE7QrkmhletLwA0OZXu = '_LST_'
pg5R9BfMYiaNumlJAk7eWtIsjh4z8 = 4
wPZ6BamXCMAFqnUyD5io = 10
def hLD0mk9HIuPOz7pw(Q6FbqZ9uIe8v2xaTHhfDCJ,url,OO1XlVPzfQrMTmJv,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2):
	try: vh8gAzLSEiuO6NkGYjRI13BKs2y = str(RkfstxEyua67K2['folder'])
	except: vh8gAzLSEiuO6NkGYjRI13BKs2y = ''
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==160: RRMWBwU6pG = YpFfN68PZ132()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==161: RRMWBwU6pG = CCM5Vs2jqeInNEKUloLazpt(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==162: RRMWBwU6pG = IQfBDot3J5zUE6hgwHeLYGTZn8sj(OO1XlVPzfQrMTmJv,162)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==163: RRMWBwU6pG = IQfBDot3J5zUE6hgwHeLYGTZn8sj(OO1XlVPzfQrMTmJv,163)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==164: RRMWBwU6pG = kkhQtHYXbu5T0Kzy3(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==165: RRMWBwU6pG = qqnW6L8KP42gQOiAIVmXs(url,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==166: RRMWBwU6pG = oHpnqMZfeOwK(url,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==167: RRMWBwU6pG = BBq5OZDh1Q8z2Sn(url,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==168: RRMWBwU6pG = s75DO40p2eoYt8xMN9c(url,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==761: RRMWBwU6pG = eeYlrqnud2Cs9mjhR68FL7Q()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==762: RRMWBwU6pG = uuStKFm4CcUJ37DLziwPQNX()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==763: RRMWBwU6pG = qZjyr6oJhMzapQfBV(vh8gAzLSEiuO6NkGYjRI13BKs2y,OO1XlVPzfQrMTmJv,YSTbrKgPf7NyhIDizB)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==764: RRMWBwU6pG = GUjMiKey7IEQoua(vh8gAzLSEiuO6NkGYjRI13BKs2y,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==765: RRMWBwU6pG = j3YUuwcJ1GWinQte2LCsB(vh8gAzLSEiuO6NkGYjRI13BKs2y,OO1XlVPzfQrMTmJv)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def eeYlrqnud2Cs9mjhR68FL7Q():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
		JE7QrkmhletLwA0OZXu = '_IP'+str(vh8gAzLSEiuO6NkGYjRI13BKs2y)+'_'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' فيديوهات مجلد '+aLDUVmBxsFnM[vh8gAzLSEiuO6NkGYjRI13BKs2y],'',764,'','','','',{'folder':vh8gAzLSEiuO6NkGYjRI13BKs2y})
	return
def uuStKFm4CcUJ37DLziwPQNX():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
		JE7QrkmhletLwA0OZXu = '_MU'+str(vh8gAzLSEiuO6NkGYjRI13BKs2y)+'_'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' فيديوهات مجلد '+aLDUVmBxsFnM[vh8gAzLSEiuO6NkGYjRI13BKs2y],'',765,'','','','',{'folder':vh8gAzLSEiuO6NkGYjRI13BKs2y})
	return
def o5wPvKzDtqMX1UjdVNZaQ8L7HxOsb(Xt7olBPDuFS4diy1):
	global wb70L8GVpgUy2uS5aiPQrlJ,nA196FG5dlJZ2uqx8wBb0c3CUkm
	ZQGzeTEil79pbsCtauf,Z1wMTVKApbNvinskL7,EYNDrC48cOLIKeUdq7ju0ptikxTSv = tfuri9cjL3JEgaOMPlynH0sUhW25(Xt7olBPDuFS4diy1)
	try:
		if 'IFILM' in Xt7olBPDuFS4diy1: ZQGzeTEil79pbsCtauf(Xt7olBPDuFS4diy1)
		else: ZQGzeTEil79pbsCtauf()
		AA1Xah7Ju2OEUKwj = False
	except:
		ETVMAFtlKdgY5WO3Uz6wNnPs8()
		AA1Xah7Ju2OEUKwj = True
	Xt7olBPDuFS4diy1 = S6YzAlHWcCwJI18(Xt7olBPDuFS4diy1)
	if AA1Xah7Ju2OEUKwj:
		uFCykYQW68S(Xt7olBPDuFS4diy1,'فشل للأسف',vODi7LQeCnUaoRqZX9xs6djwm0tJA2=2000)
		wb70L8GVpgUy2uS5aiPQrlJ += 1
		nA196FG5dlJZ2uqx8wBb0c3CUkm += ' '+Xt7olBPDuFS4diy1
	else: uFCykYQW68S(Xt7olBPDuFS4diy1,'',vODi7LQeCnUaoRqZX9xs6djwm0tJA2=1000)
	return
def tZfmvoMyg3AeF0iOK2(SxYHpPjy4F7WLkR=True):
	global wb70L8GVpgUy2uS5aiPQrlJ,nA196FG5dlJZ2uqx8wBb0c3CUkm
	if not SxYHpPjy4F7WLkR:
		global ZXFEJOV3vG5UIjAR2WxiD01tcML
		RRMWBwU6pG = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if RRMWBwU6pG:
			ZXFEJOV3vG5UIjAR2WxiD01tcML = RRMWBwU6pG
			return
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if T4TGmZ9XWAzONaKygic!=1: return
	iBTbm82l5KZSGJN6t3(False,False,False)
	VyLwICRpau56BKF4vcd = vvruH9wsBDfbhFtyq1MUd2zV
	wb70L8GVpgUy2uS5aiPQrlJ,nA196FG5dlJZ2uqx8wBb0c3CUkm,threads = 0,'',{}
	for Xt7olBPDuFS4diy1 in wwNYJgTxVyvAzeBka4coQ5tD6:
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(0.5)
		threads[Xt7olBPDuFS4diy1] = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=o5wPvKzDtqMX1UjdVNZaQ8L7HxOsb,args=(Xt7olBPDuFS4diy1,))
		threads[Xt7olBPDuFS4diy1].start()
		if wb70L8GVpgUy2uS5aiPQrlJ>=wPZ6BamXCMAFqnUyD5io: break
	else:
		for Xt7olBPDuFS4diy1 in list(threads.keys()):
			threads[Xt7olBPDuFS4diy1].join()
	vvruH9wsBDfbhFtyq1MUd2zV[:] = VyLwICRpau56BKF4vcd
	if wb70L8GVpgUy2uS5aiPQrlJ>=wPZ6BamXCMAFqnUyD5io: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','لديك مشكلة في '+str(wb70L8GVpgUy2uS5aiPQrlJ)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+nA196FG5dlJZ2uqx8wBb0c3CUkm)
	else:
		mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SECTIONS_SITES','SECTIONS_SITES_ALL',ZXFEJOV3vG5UIjAR2WxiD01tcML,VYn9o683LCcspE7Jew5gMQrZbj)
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	iBTbm82l5KZSGJN6t3('','','')
	return
def SPk9B5LEZMj(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi):
	aq06Wbp7PVnGxrw3ZANXvLkDyK9 = False
	k7HOBZxyPA1wqLm6lQReYh5aV = vvruH9wsBDfbhFtyq1MUd2zV
	vvruH9wsBDfbhFtyq1MUd2zV[:] = []
	if aq06Wbp7PVnGxrw3ZANXvLkDyK9 and '_CREATENEW_' not in W7d5UaTJVnySIM6OQ3fXi:
		RRMWBwU6pG = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+vh8gAzLSEiuO6NkGYjRI13BKs2y)
	elif '_LIVE_' not in W7d5UaTJVnySIM6OQ3fXi or '_VOD_' not in W7d5UaTJVnySIM6OQ3fXi:
		import Fh0QwtApKa
		qNEnDMwm1Vfastx2ZkpRh = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in W7d5UaTJVnySIM6OQ3fXi:
			try: Fh0QwtApKa.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'VOD_UNKNOWN_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـIPTV للفيديوهات',qNEnDMwm1Vfastx2ZkpRh)
			try: Fh0QwtApKa.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'VOD_MOVIES_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـIPTV للفيديوهات',qNEnDMwm1Vfastx2ZkpRh)
			try: Fh0QwtApKa.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'VOD_SERIES_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـIPTV للفيديوهات',qNEnDMwm1Vfastx2ZkpRh)
		if '_VOD_' not in W7d5UaTJVnySIM6OQ3fXi:
			try: Fh0QwtApKa.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'LIVE_UNKNOWN_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـIPTV للقنوات',qNEnDMwm1Vfastx2ZkpRh)
			try: Fh0QwtApKa.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'LIVE_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـIPTV للقنوات',qNEnDMwm1Vfastx2ZkpRh)
		RRMWBwU6pG = vvruH9wsBDfbhFtyq1MUd2zV
		if aq06Wbp7PVnGxrw3ZANXvLkDyK9: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SECTIONS_IPTV','SECTIONS_IPTV_'+vh8gAzLSEiuO6NkGYjRI13BKs2y,RRMWBwU6pG,VYn9o683LCcspE7Jew5gMQrZbj)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV
	return RRMWBwU6pG
def lyexpKswvi(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi):
	aq06Wbp7PVnGxrw3ZANXvLkDyK9 = False
	k7HOBZxyPA1wqLm6lQReYh5aV = vvruH9wsBDfbhFtyq1MUd2zV
	vvruH9wsBDfbhFtyq1MUd2zV[:] = []
	if aq06Wbp7PVnGxrw3ZANXvLkDyK9 and '_CREATENEW_' not in W7d5UaTJVnySIM6OQ3fXi:
		RRMWBwU6pG = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SECTIONS_M3U','SECTIONS_M3U_'+vh8gAzLSEiuO6NkGYjRI13BKs2y)
	elif '_LIVE_' not in W7d5UaTJVnySIM6OQ3fXi or '_VOD_' not in W7d5UaTJVnySIM6OQ3fXi:
		import RWoJSlvIC0
		qNEnDMwm1Vfastx2ZkpRh = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in W7d5UaTJVnySIM6OQ3fXi:
			try: RWoJSlvIC0.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'VOD_UNKNOWN_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـM3U للفيديوهات',qNEnDMwm1Vfastx2ZkpRh)
			try: RWoJSlvIC0.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'VOD_MOVIES_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـM3U للفيديوهات',qNEnDMwm1Vfastx2ZkpRh)
			try: RWoJSlvIC0.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'VOD_SERIES_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـM3U للفيديوهات',qNEnDMwm1Vfastx2ZkpRh)
		if '_VOD_' not in W7d5UaTJVnySIM6OQ3fXi:
			try: RWoJSlvIC0.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'LIVE_UNKNOWN_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـM3U للقنوات',qNEnDMwm1Vfastx2ZkpRh)
			try: RWoJSlvIC0.fAG7rpMnDyqzE(vh8gAzLSEiuO6NkGYjRI13BKs2y,'LIVE_GROUPED_SORTED','','',W7d5UaTJVnySIM6OQ3fXi+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع ـM3U للقنوات',qNEnDMwm1Vfastx2ZkpRh)
		RRMWBwU6pG = vvruH9wsBDfbhFtyq1MUd2zV
		if aq06Wbp7PVnGxrw3ZANXvLkDyK9: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SECTIONS_M3U','SECTIONS_M3U_'+vh8gAzLSEiuO6NkGYjRI13BKs2y,RRMWBwU6pG,VYn9o683LCcspE7Jew5gMQrZbj)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV
	return RRMWBwU6pG
def qZjyr6oJhMzapQfBV(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi,qxJRDBnh7WVbOdg):
	if '_CREATENEW_' in W7d5UaTJVnySIM6OQ3fXi and qxJRDBnh7WVbOdg=='': tZfmvoMyg3AeF0iOK2(True)
	elif qxJRDBnh7WVbOdg: tZfmvoMyg3AeF0iOK2(False)
	kkO8eAE23u9 = W7d5UaTJVnySIM6OQ3fXi.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not qxJRDBnh7WVbOdg:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+kkO8eAE23u9,'',{'folder':vh8gAzLSEiuO6NkGYjRI13BKs2y})
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K0FhCQTV4fPruR3JMDbwekY9scn = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	WtmlvhTBKEwi7YbVNkAf = ['افلام','movie','فيلم','فلم']
	VsLE4okmztlNIU8J = ['مسلسل','series']
	bbjmG6zd2kiMxaFerPgHq4 = ['مسارح','مسرحيات']
	iEwxqRWAtmN7D6BrKTbX5HFa8u12g = ['برامج','show','تلفزيون','تليفزيون']
	DcdPHOSvVQmpM6JAbx1BCRau0k = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	h1MBtynCr8xAqISR9vd2Dj7oOm = ['رمضان']
	YNtljB8xJEoSwiUZbAcI1aKHvsgh = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	E6g5kdtNysAGlivJCYPz1QSHx2nW = ['سلاسل','سلسله']
	TLp6FcYJPC = ['اغاني','موسيقى','كليب','حفل','music']
	FvucG4tVjiPQZx0b62O = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	k6g238lzFIxtT = ['الان','حالي','مثبت','رائج']
	sn4XLRglfcQ = ['ضحك','كوميدي']
	cSvVJb94a6jl2rWHqmQDMtgi = ['رياضه','كوره','مصارعه','شوت','رياضة']
	xQzIdg7k6jh51bslaD9Gr8UXPfoFM = ['نيتفلكس','netflix','نيتفليكس']
	YJjgINVBri = ['ممثلين','اشخاص','نجوم']
	ppwOVfWkqTKEsUnghz = ['بث حي','live','قناه','قنوات']
	pp8mvALbTyDhWni3ZY9q = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	JSlNzq0DTphgO7krZARYsvBKGdF = ['19','20','21','22','23','24','25','26']
	if not qxJRDBnh7WVbOdg:
		qxJRDBnh7WVbOdg = 0
		for vuOBsSUNpKMeo06tWRwjGxLfkg739 in K0FhCQTV4fPruR3JMDbwekY9scn:
			qxJRDBnh7WVbOdg += 1
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+vuOBsSUNpKMeo06tWRwjGxLfkg739,'',763,'',str(qxJRDBnh7WVbOdg),kkO8eAE23u9,'',{'folder':vh8gAzLSEiuO6NkGYjRI13BKs2y})
	else:
		for pphVUbJkGtHXndg84iZl2DPImSzoC in sorted(list(ZXFEJOV3vG5UIjAR2WxiD01tcML.keys())):
			Vuk3760YmGdQaZ92MfwcNKE = pphVUbJkGtHXndg84iZl2DPImSzoC.lower()
			jsEpRxQH76 = []
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in WtmlvhTBKEwi7YbVNkAf): jsEpRxQH76.append(1)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in VsLE4okmztlNIU8J): jsEpRxQH76.append(2)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in bbjmG6zd2kiMxaFerPgHq4): jsEpRxQH76.append(3)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in iEwxqRWAtmN7D6BrKTbX5HFa8u12g): jsEpRxQH76.append(4)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in DcdPHOSvVQmpM6JAbx1BCRau0k): jsEpRxQH76.append(5)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in h1MBtynCr8xAqISR9vd2Dj7oOm): jsEpRxQH76.append(6)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in YNtljB8xJEoSwiUZbAcI1aKHvsgh) and Vuk3760YmGdQaZ92MfwcNKE not in ['اخرى']: jsEpRxQH76.append(7)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in E6g5kdtNysAGlivJCYPz1QSHx2nW): jsEpRxQH76.append(8)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in TLp6FcYJPC): jsEpRxQH76.append(9)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in FvucG4tVjiPQZx0b62O): jsEpRxQH76.append(10)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in k6g238lzFIxtT): jsEpRxQH76.append(11)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in sn4XLRglfcQ): jsEpRxQH76.append(12)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in cSvVJb94a6jl2rWHqmQDMtgi): jsEpRxQH76.append(13)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in xQzIdg7k6jh51bslaD9Gr8UXPfoFM): jsEpRxQH76.append(14)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in YJjgINVBri): jsEpRxQH76.append(15)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in ppwOVfWkqTKEsUnghz): jsEpRxQH76.append(16)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in pp8mvALbTyDhWni3ZY9q): jsEpRxQH76.append(17)
			if any(pp8iHB3W9Cs in Vuk3760YmGdQaZ92MfwcNKE for pp8iHB3W9Cs in JSlNzq0DTphgO7krZARYsvBKGdF): jsEpRxQH76.append(18)
			if not jsEpRxQH76: jsEpRxQH76 = [19]
			for K9K6a4Tj7iUc0ugNstIrdzJVQqf5 in jsEpRxQH76:
				if str(K9K6a4Tj7iUc0ugNstIrdzJVQqf5)==qxJRDBnh7WVbOdg:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+pphVUbJkGtHXndg84iZl2DPImSzoC,pphVUbJkGtHXndg84iZl2DPImSzoC,166,'','',kkO8eAE23u9+'_REMEMBERRESULTS_')
	return
def GUjMiKey7IEQoua(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi):
	aq06Wbp7PVnGxrw3ZANXvLkDyK9 = False
	if aq06Wbp7PVnGxrw3ZANXvLkDyK9:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':vh8gAzLSEiuO6NkGYjRI13BKs2y})
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	k7HOBZxyPA1wqLm6lQReYh5aV = vvruH9wsBDfbhFtyq1MUd2zV[:]
	import Fh0QwtApKa
	if vh8gAzLSEiuO6NkGYjRI13BKs2y:
		if not Fh0QwtApKa.SSk6jtbsXxMo09lNiaVp4T(vh8gAzLSEiuO6NkGYjRI13BKs2y,True): return
		wrghtu6TQlqCF = SPk9B5LEZMj(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi)
		H6hWCxi0SEZ8MI43qGursNodTvV = sorted(wrghtu6TQlqCF,reverse=False,key=lambda key: key[1].lower())
	else:
		if not Fh0QwtApKa.SSk6jtbsXxMo09lNiaVp4T('',True): return
		if aq06Wbp7PVnGxrw3ZANXvLkDyK9 and '_CREATENEW_' not in W7d5UaTJVnySIM6OQ3fXi:
			H6hWCxi0SEZ8MI43qGursNodTvV = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			zJjPCwX6Ghxt5fBrs9KebdQOMv,H6hWCxi0SEZ8MI43qGursNodTvV,wrghtu6TQlqCF = [],[],[]
			for JODfE9Awpl2d4jzcVLvsrPC in range(1,nJHx2XSIEFA7+1):
				H6hWCxi0SEZ8MI43qGursNodTvV += SPk9B5LEZMj(str(JODfE9Awpl2d4jzcVLvsrPC),W7d5UaTJVnySIM6OQ3fXi)
			for type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in H6hWCxi0SEZ8MI43qGursNodTvV:
				if OO1XlVPzfQrMTmJv not in zJjPCwX6Ghxt5fBrs9KebdQOMv:
					zJjPCwX6Ghxt5fBrs9KebdQOMv.append(OO1XlVPzfQrMTmJv)
					adnmfurkUD1MOybjBF4N2qg = type,pphVUbJkGtHXndg84iZl2DPImSzoC,OO1XlVPzfQrMTmJv,165,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,W7d5UaTJVnySIM6OQ3fXi,ja74FTtz9hK,RkfstxEyua67K2
					wrghtu6TQlqCF.append(adnmfurkUD1MOybjBF4N2qg)
			H6hWCxi0SEZ8MI43qGursNodTvV = sorted(wrghtu6TQlqCF,reverse=False,key=lambda key: key[1].lower())
			if aq06Wbp7PVnGxrw3ZANXvLkDyK9: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',H6hWCxi0SEZ8MI43qGursNodTvV,VYn9o683LCcspE7Jew5gMQrZbj)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV+H6hWCxi0SEZ8MI43qGursNodTvV
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin('Container.Refresh')
	return
def j3YUuwcJ1GWinQte2LCsB(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi):
	aq06Wbp7PVnGxrw3ZANXvLkDyK9 = False
	if aq06Wbp7PVnGxrw3ZANXvLkDyK9:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':vh8gAzLSEiuO6NkGYjRI13BKs2y})
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	k7HOBZxyPA1wqLm6lQReYh5aV = vvruH9wsBDfbhFtyq1MUd2zV[:]
	import RWoJSlvIC0
	if vh8gAzLSEiuO6NkGYjRI13BKs2y:
		if not RWoJSlvIC0.SSk6jtbsXxMo09lNiaVp4T(vh8gAzLSEiuO6NkGYjRI13BKs2y,True): return
		wrghtu6TQlqCF = lyexpKswvi(vh8gAzLSEiuO6NkGYjRI13BKs2y,W7d5UaTJVnySIM6OQ3fXi)
		H6hWCxi0SEZ8MI43qGursNodTvV = sorted(wrghtu6TQlqCF,reverse=False,key=lambda key: key[1].lower())
	else:
		if not RWoJSlvIC0.SSk6jtbsXxMo09lNiaVp4T('',True): return
		if aq06Wbp7PVnGxrw3ZANXvLkDyK9 and '_CREATENEW_' not in W7d5UaTJVnySIM6OQ3fXi:
			H6hWCxi0SEZ8MI43qGursNodTvV = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			zJjPCwX6Ghxt5fBrs9KebdQOMv,H6hWCxi0SEZ8MI43qGursNodTvV,wrghtu6TQlqCF = [],[],[]
			for JODfE9Awpl2d4jzcVLvsrPC in range(1,nJHx2XSIEFA7+1):
				H6hWCxi0SEZ8MI43qGursNodTvV += lyexpKswvi(str(JODfE9Awpl2d4jzcVLvsrPC),W7d5UaTJVnySIM6OQ3fXi)
			for type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in H6hWCxi0SEZ8MI43qGursNodTvV:
				if OO1XlVPzfQrMTmJv not in zJjPCwX6Ghxt5fBrs9KebdQOMv:
					zJjPCwX6Ghxt5fBrs9KebdQOMv.append(OO1XlVPzfQrMTmJv)
					adnmfurkUD1MOybjBF4N2qg = type,pphVUbJkGtHXndg84iZl2DPImSzoC,OO1XlVPzfQrMTmJv,165,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,W7d5UaTJVnySIM6OQ3fXi,ja74FTtz9hK,RkfstxEyua67K2
					wrghtu6TQlqCF.append(adnmfurkUD1MOybjBF4N2qg)
			H6hWCxi0SEZ8MI43qGursNodTvV = sorted(wrghtu6TQlqCF,reverse=False,key=lambda key: key[1].lower())
			if aq06Wbp7PVnGxrw3ZANXvLkDyK9: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SECTIONS_M3U','SECTIONS_M3U_ALL',H6hWCxi0SEZ8MI43qGursNodTvV,VYn9o683LCcspE7Jew5gMQrZbj)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV+H6hWCxi0SEZ8MI43qGursNodTvV
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin('Container.Refresh')
	return
def qqnW6L8KP42gQOiAIVmXs(group,W7d5UaTJVnySIM6OQ3fXi):
	aq06Wbp7PVnGxrw3ZANXvLkDyK9 = False
	RRMWBwU6pG = []
	Z3dHeh0n2qoD7iRf9lWcwCX = '_IPTV_' if 'IPTV' in W7d5UaTJVnySIM6OQ3fXi else '_M3U_'
	if aq06Wbp7PVnGxrw3ZANXvLkDyK9: RRMWBwU6pG = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SECTIONS'+Z3dHeh0n2qoD7iRf9lWcwCX[:-1],group)
	if not RRMWBwU6pG:
		for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
			if aq06Wbp7PVnGxrw3ZANXvLkDyK9: RRMWBwU6pG += C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','SECTIONS'+Z3dHeh0n2qoD7iRf9lWcwCX[:-1],'SECTIONS'+Z3dHeh0n2qoD7iRf9lWcwCX+str(vh8gAzLSEiuO6NkGYjRI13BKs2y))
			elif Z3dHeh0n2qoD7iRf9lWcwCX=='_IPTV_': RRMWBwU6pG += SPk9B5LEZMj(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),'_CREATENEW_')
			elif Z3dHeh0n2qoD7iRf9lWcwCX=='_M3U_': RRMWBwU6pG += lyexpKswvi(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),'_CREATENEW_')
		for type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in RRMWBwU6pG:
			if OO1XlVPzfQrMTmJv==group: GCkWI4SZaQbPlj(type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2)
		items,eIXD9Ql3JREsm4WvKc = [],[]
		for type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in vvruH9wsBDfbhFtyq1MUd2zV:
			XuJCyrm9ifWO6DTSxVQp = type,pphVUbJkGtHXndg84iZl2DPImSzoC[4:],url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,''
			if XuJCyrm9ifWO6DTSxVQp not in eIXD9Ql3JREsm4WvKc:
				eIXD9Ql3JREsm4WvKc.append(XuJCyrm9ifWO6DTSxVQp)
				F5o1sgcqZVlS = type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2
				items.append(F5o1sgcqZVlS)
		RRMWBwU6pG = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if aq06Wbp7PVnGxrw3ZANXvLkDyK9: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'SECTIONS'+Z3dHeh0n2qoD7iRf9lWcwCX[:-1],group,RRMWBwU6pG,VYn9o683LCcspE7Jew5gMQrZbj)
	if '_RANDOM_' in W7d5UaTJVnySIM6OQ3fXi and len(RRMWBwU6pG)>pg5R9BfMYiaNumlJAk7eWtIsjh4z8:
		vvruH9wsBDfbhFtyq1MUd2zV[:] = []
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',Z3dHeh0n2qoD7iRf9lWcwCX+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',Z3dHeh0n2qoD7iRf9lWcwCX+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		RRMWBwU6pG = vvruH9wsBDfbhFtyq1MUd2zV+KRjfaduUhzsPg6I1.sample(RRMWBwU6pG,pg5R9BfMYiaNumlJAk7eWtIsjh4z8)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = RRMWBwU6pG
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin('Container.Refresh')
	return
def CCM5Vs2jqeInNEKUloLazpt(W7d5UaTJVnySIM6OQ3fXi):
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	KmfqE837iJ9pyVOQgMxaX4hL0Iu = vvruH9wsBDfbhFtyq1MUd2zV[:]
	vvruH9wsBDfbhFtyq1MUd2zV[:] = []
	import LbrlkD8oPw
	LbrlkD8oPw.F42EXtwuzB7Hl('0',False)
	LbrlkD8oPw.F42EXtwuzB7Hl('1',False)
	LbrlkD8oPw.F42EXtwuzB7Hl('2',False)
	if '_RANDOM_' in W7d5UaTJVnySIM6OQ3fXi:
		vvruH9wsBDfbhFtyq1MUd2zV[:] = BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV)
		if len(vvruH9wsBDfbhFtyq1MUd2zV)>pg5R9BfMYiaNumlJAk7eWtIsjh4z8: vvruH9wsBDfbhFtyq1MUd2zV[:] = KRjfaduUhzsPg6I1.sample(vvruH9wsBDfbhFtyq1MUd2zV,pg5R9BfMYiaNumlJAk7eWtIsjh4z8)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = KmfqE837iJ9pyVOQgMxaX4hL0Iu+vvruH9wsBDfbhFtyq1MUd2zV
	return
def kkhQtHYXbu5T0Kzy3(W7d5UaTJVnySIM6OQ3fXi):
	W7d5UaTJVnySIM6OQ3fXi = W7d5UaTJVnySIM6OQ3fXi.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = YZpVhcRlPs3n0FrD(data)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(ooDaNCkx4c0FjJs,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="content"(.*?)class="clearfix"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	WR0ab7MT8Khy6EDcsv3,mhNVwHxItq0XDBYZJpcyvRdk64jCr = list(zip(*items))
	LhOIHf1Jtrxu2Xqp9cjCNsi3d = []
	YCzuQONlisk5BVTqW3gb = [' ','"','`',',','.',':',';',"'",'-']
	bWszgu9KROEyVw3mtnkQLPphS = mhNVwHxItq0XDBYZJpcyvRdk64jCr+WR0ab7MT8Khy6EDcsv3
	for FQSBTuV1wpvcARZLsE3XCfHM8oy in bWszgu9KROEyVw3mtnkQLPphS:
		if FQSBTuV1wpvcARZLsE3XCfHM8oy in mhNVwHxItq0XDBYZJpcyvRdk64jCr: E7vkNZjOXznGyiW = 2
		if FQSBTuV1wpvcARZLsE3XCfHM8oy in WR0ab7MT8Khy6EDcsv3: E7vkNZjOXznGyiW = 4
		eeIm5t490QEdvkpNUb = [PXBFxvuUlLDHGpm58 in FQSBTuV1wpvcARZLsE3XCfHM8oy for PXBFxvuUlLDHGpm58 in YCzuQONlisk5BVTqW3gb]
		if any(eeIm5t490QEdvkpNUb):
			A1pJYqSia7V4wKMnuvLe30QbrkGj = eeIm5t490QEdvkpNUb.index(True)
			UURwg2uEhAseT0kMj1PSZF6 = YCzuQONlisk5BVTqW3gb[A1pJYqSia7V4wKMnuvLe30QbrkGj]
			sd57NJniuSw3ktMAaZ8mj0p = ''
			if FQSBTuV1wpvcARZLsE3XCfHM8oy.count(UURwg2uEhAseT0kMj1PSZF6)>1: zznweaRHTjL07A,X0rKm3YWfSg2MBNUk9p1qQVC,sd57NJniuSw3ktMAaZ8mj0p = FQSBTuV1wpvcARZLsE3XCfHM8oy.split(UURwg2uEhAseT0kMj1PSZF6,2)
			else: zznweaRHTjL07A,X0rKm3YWfSg2MBNUk9p1qQVC = FQSBTuV1wpvcARZLsE3XCfHM8oy.split(UURwg2uEhAseT0kMj1PSZF6,1)
			if len(zznweaRHTjL07A)>E7vkNZjOXznGyiW: LhOIHf1Jtrxu2Xqp9cjCNsi3d.append(zznweaRHTjL07A.lower())
			if len(X0rKm3YWfSg2MBNUk9p1qQVC)>E7vkNZjOXznGyiW: LhOIHf1Jtrxu2Xqp9cjCNsi3d.append(X0rKm3YWfSg2MBNUk9p1qQVC.lower())
			if len(sd57NJniuSw3ktMAaZ8mj0p)>E7vkNZjOXznGyiW: LhOIHf1Jtrxu2Xqp9cjCNsi3d.append(sd57NJniuSw3ktMAaZ8mj0p.lower())
		elif len(FQSBTuV1wpvcARZLsE3XCfHM8oy)>E7vkNZjOXznGyiW: LhOIHf1Jtrxu2Xqp9cjCNsi3d.append(FQSBTuV1wpvcARZLsE3XCfHM8oy.lower())
	for PXBFxvuUlLDHGpm58 in range(9): KRjfaduUhzsPg6I1.shuffle(LhOIHf1Jtrxu2Xqp9cjCNsi3d)
	if '_SITES_' in W7d5UaTJVnySIM6OQ3fXi:
		cG5RCxjhBIX9YuS3FDykV142ZTdE = pgF0ezZWMBqJaufs
	elif '_IPTV_' in W7d5UaTJVnySIM6OQ3fXi:
		cG5RCxjhBIX9YuS3FDykV142ZTdE = ['IPTV']
		import Fh0QwtApKa
		if not Fh0QwtApKa.SSk6jtbsXxMo09lNiaVp4T('',True): return
	elif '_M3U_' in W7d5UaTJVnySIM6OQ3fXi:
		cG5RCxjhBIX9YuS3FDykV142ZTdE = ['M3U']
		import RWoJSlvIC0
		if not RWoJSlvIC0.SSk6jtbsXxMo09lNiaVp4T('',True): return
	count,C0JLs1RyZEHO6vBqMzxrF8XiSuk7o = 0,0
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+W7d5UaTJVnySIM6OQ3fXi)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+W7d5UaTJVnySIM6OQ3fXi)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	U1BgIbTErlLsdRxp0NFiMhk = vvruH9wsBDfbhFtyq1MUd2zV[:]
	vvruH9wsBDfbhFtyq1MUd2zV[:] = []
	qFuv3C5kxcSM = []
	for FQSBTuV1wpvcARZLsE3XCfHM8oy in LhOIHf1Jtrxu2Xqp9cjCNsi3d:
		X0rKm3YWfSg2MBNUk9p1qQVC = QPuHKNAT4jmCRg.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',FQSBTuV1wpvcARZLsE3XCfHM8oy,QPuHKNAT4jmCRg.DOTALL)
		if X0rKm3YWfSg2MBNUk9p1qQVC: FQSBTuV1wpvcARZLsE3XCfHM8oy = FQSBTuV1wpvcARZLsE3XCfHM8oy.split(X0rKm3YWfSg2MBNUk9p1qQVC[0],1)[0]
		HUjVCOuYwq6Tm = FQSBTuV1wpvcARZLsE3XCfHM8oy.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		HUjVCOuYwq6Tm = HUjVCOuYwq6Tm.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if HUjVCOuYwq6Tm: qFuv3C5kxcSM.append(HUjVCOuYwq6Tm)
	Z0JyIEbhampt = []
	for kdWCpE9TjNh in range(0,20):
		search = KRjfaduUhzsPg6I1.sample(qFuv3C5kxcSM,1)[0]
		if search in Z0JyIEbhampt: continue
		Z0JyIEbhampt.append(search)
		Xt7olBPDuFS4diy1 = KRjfaduUhzsPg6I1.sample(cG5RCxjhBIX9YuS3FDykV142ZTdE,1)[0]
		zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Random Video Search   site:'+str(Xt7olBPDuFS4diy1)+'  search:'+search)
		ZQGzeTEil79pbsCtauf,Z1wMTVKApbNvinskL7,EYNDrC48cOLIKeUdq7ju0ptikxTSv = tfuri9cjL3JEgaOMPlynH0sUhW25(Xt7olBPDuFS4diy1)
		Z1wMTVKApbNvinskL7(search+'_NODIALOGS_')
		if len(vvruH9wsBDfbhFtyq1MUd2zV)>0: break
	search = search.replace('_MOD_','')
	U1BgIbTErlLsdRxp0NFiMhk[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	vvruH9wsBDfbhFtyq1MUd2zV[:] = BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV)
	if len(vvruH9wsBDfbhFtyq1MUd2zV)>pg5R9BfMYiaNumlJAk7eWtIsjh4z8: vvruH9wsBDfbhFtyq1MUd2zV[:] = KRjfaduUhzsPg6I1.sample(vvruH9wsBDfbhFtyq1MUd2zV,pg5R9BfMYiaNumlJAk7eWtIsjh4z8)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = U1BgIbTErlLsdRxp0NFiMhk+vvruH9wsBDfbhFtyq1MUd2zV
	return
def oHpnqMZfeOwK(aJv7C8ykOR3Qr,W7d5UaTJVnySIM6OQ3fXi):
	aJv7C8ykOR3Qr = aJv7C8ykOR3Qr.replace('_MOD_','')
	W7d5UaTJVnySIM6OQ3fXi = W7d5UaTJVnySIM6OQ3fXi.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	tZfmvoMyg3AeF0iOK2(False)
	if ZXFEJOV3vG5UIjAR2WxiD01tcML=={}: return
	if '_RANDOM_' in W7d5UaTJVnySIM6OQ3fXi:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','[[COLOR FFC89008]'+aJv7C8ykOR3Qr+'[/COLOR] :القسم]',aJv7C8ykOR3Qr,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+W7d5UaTJVnySIM6OQ3fXi)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة الطلب العشوائي من نفس القسم',aJv7C8ykOR3Qr,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+W7d5UaTJVnySIM6OQ3fXi)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(ZXFEJOV3vG5UIjAR2WxiD01tcML[aJv7C8ykOR3Qr].keys())):
		type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 = ZXFEJOV3vG5UIjAR2WxiD01tcML[aJv7C8ykOR3Qr][website]
		if '_RANDOM_' in W7d5UaTJVnySIM6OQ3fXi or len(ZXFEJOV3vG5UIjAR2WxiD01tcML[aJv7C8ykOR3Qr])==1:
			GCkWI4SZaQbPlj(type,'',url,MQrIDuiRAGExksvoLC9Onmgb,'',YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,'','')
			vvruH9wsBDfbhFtyq1MUd2zV[:] = BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV)
			k7HOBZxyPA1wqLm6lQReYh5aV,H6hWCxi0SEZ8MI43qGursNodTvV = vvruH9wsBDfbhFtyq1MUd2zV[:3],vvruH9wsBDfbhFtyq1MUd2zV[3:]
			for PXBFxvuUlLDHGpm58 in range(9): KRjfaduUhzsPg6I1.shuffle(H6hWCxi0SEZ8MI43qGursNodTvV)
			if '_RANDOM_' in W7d5UaTJVnySIM6OQ3fXi: vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV+H6hWCxi0SEZ8MI43qGursNodTvV[:pg5R9BfMYiaNumlJAk7eWtIsjh4z8]
			else: vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV+H6hWCxi0SEZ8MI43qGursNodTvV
		elif '_SITES_' in W7d5UaTJVnySIM6OQ3fXi: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',website,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2)
	return
def IQfBDot3J5zUE6hgwHeLYGTZn8sj(W7d5UaTJVnySIM6OQ3fXi,Q6FbqZ9uIe8v2xaTHhfDCJ):
	W7d5UaTJVnySIM6OQ3fXi = W7d5UaTJVnySIM6OQ3fXi.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	pphVUbJkGtHXndg84iZl2DPImSzoC,GaH0R4KBf5Fmn2UAQItYL9TlDX817x = '',[]
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','[[COLOR FFC89008]'+pphVUbJkGtHXndg84iZl2DPImSzoC+'[/COLOR] :القسم]','',Q6FbqZ9uIe8v2xaTHhfDCJ,'','','_FORGETRESULTS__REMEMBERRESULTS_'+W7d5UaTJVnySIM6OQ3fXi)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة طلب قسم عشوائي','',Q6FbqZ9uIe8v2xaTHhfDCJ,'','','_FORGETRESULTS__REMEMBERRESULTS_'+W7d5UaTJVnySIM6OQ3fXi)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	k7HOBZxyPA1wqLm6lQReYh5aV = vvruH9wsBDfbhFtyq1MUd2zV[:]
	vvruH9wsBDfbhFtyq1MUd2zV[:] = []
	RRMWBwU6pG = []
	if '_SITES_' in W7d5UaTJVnySIM6OQ3fXi:
		tZfmvoMyg3AeF0iOK2(False)
		if ZXFEJOV3vG5UIjAR2WxiD01tcML=={}: return
		x2emCwIvD89KAjhG = list(ZXFEJOV3vG5UIjAR2WxiD01tcML.keys())
		aJv7C8ykOR3Qr = KRjfaduUhzsPg6I1.sample(x2emCwIvD89KAjhG,1)[0]
		LhOIHf1Jtrxu2Xqp9cjCNsi3d = list(ZXFEJOV3vG5UIjAR2WxiD01tcML[aJv7C8ykOR3Qr].keys())
		website = KRjfaduUhzsPg6I1.sample(LhOIHf1Jtrxu2Xqp9cjCNsi3d,1)[0]
		type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 = ZXFEJOV3vG5UIjAR2WxiD01tcML[aJv7C8ykOR3Qr][website]
		zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Random Category   website: '+website+'   name: '+pphVUbJkGtHXndg84iZl2DPImSzoC+'   url: '+url+'   mode: '+str(MQrIDuiRAGExksvoLC9Onmgb))
	elif '_IPTV_' in W7d5UaTJVnySIM6OQ3fXi:
		import Fh0QwtApKa
		if not Fh0QwtApKa.SSk6jtbsXxMo09lNiaVp4T('',True): return
		for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
			RRMWBwU6pG += SPk9B5LEZMj(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),W7d5UaTJVnySIM6OQ3fXi)
		if not RRMWBwU6pG: return
		type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 = KRjfaduUhzsPg6I1.sample(RRMWBwU6pG,1)[0]
		zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Random Category   name: '+pphVUbJkGtHXndg84iZl2DPImSzoC+'   url: '+url+'   mode: '+str(MQrIDuiRAGExksvoLC9Onmgb))
	elif '_M3U_' in W7d5UaTJVnySIM6OQ3fXi:
		import RWoJSlvIC0
		if not RWoJSlvIC0.SSk6jtbsXxMo09lNiaVp4T('',True): return
		for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
			RRMWBwU6pG += lyexpKswvi(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),W7d5UaTJVnySIM6OQ3fXi)
		if not RRMWBwU6pG: return
		type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 = KRjfaduUhzsPg6I1.sample(RRMWBwU6pG,1)[0]
		zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Random Category   name: '+pphVUbJkGtHXndg84iZl2DPImSzoC+'   url: '+url+'   mode: '+str(MQrIDuiRAGExksvoLC9Onmgb))
	XY68lGWZbEcpFKvdL5Akse43Hu = pphVUbJkGtHXndg84iZl2DPImSzoC
	RRMxJvHIpYK5TfazBW0iASjUlq = []
	for PXBFxvuUlLDHGpm58 in range(0,10):
		if PXBFxvuUlLDHGpm58>0: zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Random Category   name: '+pphVUbJkGtHXndg84iZl2DPImSzoC+'   url: '+url+'   mode: '+str(MQrIDuiRAGExksvoLC9Onmgb))
		vvruH9wsBDfbhFtyq1MUd2zV[:] = []
		if MQrIDuiRAGExksvoLC9Onmgb==234 and '__IPTVSeries__' in OO1XlVPzfQrMTmJv: MQrIDuiRAGExksvoLC9Onmgb = 233
		if MQrIDuiRAGExksvoLC9Onmgb==714 and '__M3USeries__' in OO1XlVPzfQrMTmJv: MQrIDuiRAGExksvoLC9Onmgb = 713
		if MQrIDuiRAGExksvoLC9Onmgb==144: MQrIDuiRAGExksvoLC9Onmgb = 291
		aaxAKWtMwfPRE4zbqSQCOrBms0 = GCkWI4SZaQbPlj(type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2)
		if '_IPTV_' in W7d5UaTJVnySIM6OQ3fXi and MQrIDuiRAGExksvoLC9Onmgb==167: del vvruH9wsBDfbhFtyq1MUd2zV[:3]
		if '_M3U_' in W7d5UaTJVnySIM6OQ3fXi and MQrIDuiRAGExksvoLC9Onmgb==168: del vvruH9wsBDfbhFtyq1MUd2zV[:3]
		GaH0R4KBf5Fmn2UAQItYL9TlDX817x[:] = BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV)
		if RRMxJvHIpYK5TfazBW0iASjUlq and PPpWoLVXID4(u'حلقة') in str(GaH0R4KBf5Fmn2UAQItYL9TlDX817x) or PPpWoLVXID4(u'حلقه') in str(GaH0R4KBf5Fmn2UAQItYL9TlDX817x):
			pphVUbJkGtHXndg84iZl2DPImSzoC = XY68lGWZbEcpFKvdL5Akse43Hu
			GaH0R4KBf5Fmn2UAQItYL9TlDX817x[:] = RRMxJvHIpYK5TfazBW0iASjUlq
			break
		XY68lGWZbEcpFKvdL5Akse43Hu = pphVUbJkGtHXndg84iZl2DPImSzoC
		RRMxJvHIpYK5TfazBW0iASjUlq = GaH0R4KBf5Fmn2UAQItYL9TlDX817x
		if str(GaH0R4KBf5Fmn2UAQItYL9TlDX817x).count('video')>0: break
		if str(GaH0R4KBf5Fmn2UAQItYL9TlDX817x).count('live')>0: break
		if MQrIDuiRAGExksvoLC9Onmgb==233: break
		if MQrIDuiRAGExksvoLC9Onmgb==713: break
		if MQrIDuiRAGExksvoLC9Onmgb==291: break
		if GaH0R4KBf5Fmn2UAQItYL9TlDX817x: type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,MQrIDuiRAGExksvoLC9Onmgb,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 = KRjfaduUhzsPg6I1.sample(GaH0R4KBf5Fmn2UAQItYL9TlDX817x,1)[0]
	if not pphVUbJkGtHXndg84iZl2DPImSzoC: pphVUbJkGtHXndg84iZl2DPImSzoC = '....'
	elif pphVUbJkGtHXndg84iZl2DPImSzoC.count('_')>1: pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.split('_',2)[2]
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('UNKNOWN: ','')
	pphVUbJkGtHXndg84iZl2DPImSzoC = pphVUbJkGtHXndg84iZl2DPImSzoC.replace('_MOD_','')
	k7HOBZxyPA1wqLm6lQReYh5aV[0][1] = '[[COLOR FFC89008]'+pphVUbJkGtHXndg84iZl2DPImSzoC+'[/COLOR] :القسم]'
	for PXBFxvuUlLDHGpm58 in range(9): KRjfaduUhzsPg6I1.shuffle(GaH0R4KBf5Fmn2UAQItYL9TlDX817x)
	if '_RANDOM_' in W7d5UaTJVnySIM6OQ3fXi: vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV+GaH0R4KBf5Fmn2UAQItYL9TlDX817x[:pg5R9BfMYiaNumlJAk7eWtIsjh4z8]
	else: vvruH9wsBDfbhFtyq1MUd2zV[:] = k7HOBZxyPA1wqLm6lQReYh5aV+GaH0R4KBf5Fmn2UAQItYL9TlDX817x
	return
def BBq5OZDh1Q8z2Sn(AgOjLCp97XJUBWuMm4RSkl8Y,kHAXRPy6jEti0bZ):
	kHAXRPy6jEti0bZ = kHAXRPy6jEti0bZ.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	xvRDnYk3OB0iLcEauJs = kHAXRPy6jEti0bZ
	if '__IPTVSeries__' in kHAXRPy6jEti0bZ:
		xvRDnYk3OB0iLcEauJs = kHAXRPy6jEti0bZ.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in AgOjLCp97XJUBWuMm4RSkl8Y: type = ',VIDEOS: '
	elif 'LIVE' in AgOjLCp97XJUBWuMm4RSkl8Y: type = ',LIVE: '
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','[[COLOR FFC89008]'+type+xvRDnYk3OB0iLcEauJs+'[/COLOR] :القسم]',AgOjLCp97XJUBWuMm4RSkl8Y,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+kHAXRPy6jEti0bZ)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة الطلب العشوائي من نفس القسم',AgOjLCp97XJUBWuMm4RSkl8Y,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+kHAXRPy6jEti0bZ)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import Fh0QwtApKa
	for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
		if '__IPTVSeries__' in kHAXRPy6jEti0bZ: Fh0QwtApKa.fAG7rpMnDyqzE(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),AgOjLCp97XJUBWuMm4RSkl8Y,kHAXRPy6jEti0bZ,'',False)
		else: Fh0QwtApKa.F42EXtwuzB7Hl(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),AgOjLCp97XJUBWuMm4RSkl8Y,kHAXRPy6jEti0bZ,'',False)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV)
	if len(vvruH9wsBDfbhFtyq1MUd2zV)>(pg5R9BfMYiaNumlJAk7eWtIsjh4z8+3): vvruH9wsBDfbhFtyq1MUd2zV[:] = vvruH9wsBDfbhFtyq1MUd2zV[:3]+KRjfaduUhzsPg6I1.sample(vvruH9wsBDfbhFtyq1MUd2zV[3:],pg5R9BfMYiaNumlJAk7eWtIsjh4z8)
	return
def s75DO40p2eoYt8xMN9c(AgOjLCp97XJUBWuMm4RSkl8Y,kHAXRPy6jEti0bZ):
	kHAXRPy6jEti0bZ = kHAXRPy6jEti0bZ.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	xvRDnYk3OB0iLcEauJs = kHAXRPy6jEti0bZ
	if '__M3USeries__' in kHAXRPy6jEti0bZ:
		xvRDnYk3OB0iLcEauJs = kHAXRPy6jEti0bZ.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in AgOjLCp97XJUBWuMm4RSkl8Y: type = ',VIDEOS: '
	elif 'LIVE' in AgOjLCp97XJUBWuMm4RSkl8Y: type = ',LIVE: '
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','[[COLOR FFC89008]'+type+xvRDnYk3OB0iLcEauJs+'[/COLOR] :القسم]',AgOjLCp97XJUBWuMm4RSkl8Y,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+kHAXRPy6jEti0bZ)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','إعادة الطلب العشوائي من نفس القسم',AgOjLCp97XJUBWuMm4RSkl8Y,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+kHAXRPy6jEti0bZ)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import RWoJSlvIC0
	for vh8gAzLSEiuO6NkGYjRI13BKs2y in range(1,nJHx2XSIEFA7+1):
		if '__M3USeries__' in kHAXRPy6jEti0bZ: RWoJSlvIC0.fAG7rpMnDyqzE(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),AgOjLCp97XJUBWuMm4RSkl8Y,kHAXRPy6jEti0bZ,'',False)
		else: RWoJSlvIC0.F42EXtwuzB7Hl(str(vh8gAzLSEiuO6NkGYjRI13BKs2y),AgOjLCp97XJUBWuMm4RSkl8Y,kHAXRPy6jEti0bZ,'',False)
	vvruH9wsBDfbhFtyq1MUd2zV[:] = BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV)
	if len(vvruH9wsBDfbhFtyq1MUd2zV)>(pg5R9BfMYiaNumlJAk7eWtIsjh4z8+3): vvruH9wsBDfbhFtyq1MUd2zV[:] = vvruH9wsBDfbhFtyq1MUd2zV[:3]+KRjfaduUhzsPg6I1.sample(vvruH9wsBDfbhFtyq1MUd2zV[3:],pg5R9BfMYiaNumlJAk7eWtIsjh4z8)
	return
def BlFsNGw18cRfm(vvruH9wsBDfbhFtyq1MUd2zV):
	GaH0R4KBf5Fmn2UAQItYL9TlDX817x = []
	for type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in vvruH9wsBDfbhFtyq1MUd2zV:
		if 'صفحة' in pphVUbJkGtHXndg84iZl2DPImSzoC or 'صفحه' in pphVUbJkGtHXndg84iZl2DPImSzoC or 'page' in pphVUbJkGtHXndg84iZl2DPImSzoC.lower(): continue
		GaH0R4KBf5Fmn2UAQItYL9TlDX817x.append([type,pphVUbJkGtHXndg84iZl2DPImSzoC,url,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2])
	return GaH0R4KBf5Fmn2UAQItYL9TlDX817x
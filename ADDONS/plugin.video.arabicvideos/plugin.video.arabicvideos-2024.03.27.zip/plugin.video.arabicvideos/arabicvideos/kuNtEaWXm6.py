# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'CIMA4U'
headers = {'User-Agent':''}
JE7QrkmhletLwA0OZXu = '_C4U_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==420: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==421: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==422: RRMWBwU6pG = VRktAN65nrGDCqs2vFXuOHcflSh(url)
	elif mode==423: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==424: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==427: RRMWBwU6pG = Xv4qoz72aWmn(url)
	elif mode==429: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','CIMA4U-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = QPuHKNAT4jmCRg.findall('href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ka6I93CnvublQMtjr = ka6I93CnvublQMtjr[0].strip('/')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(ka6I93CnvublQMtjr,'url')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',ka6I93CnvublQMtjr,425)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',ka6I93CnvublQMtjr,424)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الرئيسية',ka6I93CnvublQMtjr,421)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('NavigationMenu(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="*(.*?)"*>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		if '/actors' in VV7yf2htDCBU6EeSX8TJQM: title = 'أفلام النجوم'
		elif '/netflix' in VV7yf2htDCBU6EeSX8TJQM: title = 'أفلام ومسلسلات نيتفلكس'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,421)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'قائمة تفصيلية',ka6I93CnvublQMtjr,427)
	return
def Xv4qoz72aWmn(website=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','CIMA4U-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('FilteringTitle(.*?)PageTitle',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for jsEpRxQH76,id,VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		if 'netflix-movies' in VV7yf2htDCBU6EeSX8TJQM: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in VV7yf2htDCBU6EeSX8TJQM: title = 'مسلسلات نيتفلكس'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,421,'','',jsEpRxQH76+'|'+id)
	return
def SPFl6UGK4mrBua(url,oN6FKz2SkGiLnJ3tx4=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if not oN6FKz2SkGiLnJ3tx4 or '|' in oN6FKz2SkGiLnJ3tx4:
		if '|' not in oN6FKz2SkGiLnJ3tx4: p1Dxy0qcJud43rmHX5nC = ''
		else: p1Dxy0qcJud43rmHX5nC = '/archive/'+oN6FKz2SkGiLnJ3tx4
		JJGN7qxBnbcP = False
		if 'PinSlider' in Ht6Gg8lbciAd9FaUQVs:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',url,421,'','','featured')
			JJGN7qxBnbcP = True
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('PageTitle(.*?)PageContent',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			y8qSvx0Z9MY = TTCRYZroizb[0]
			eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('data-tab="(.*?)".*?<span>(.*?)<',y8qSvx0Z9MY,QPuHKNAT4jmCRg.DOTALL)
			for agtXp9MzZ5u0JO,nUbpaNT0vhcj7ZsEz in eIXD9Ql3JREsm4WvKc:
				FsnXTNzcG53RUk = ka6I93CnvublQMtjr+'/ajaxcenter/action/HomepageLoader/tab/'+agtXp9MzZ5u0JO+p1Dxy0qcJud43rmHX5nC+'/'
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,FsnXTNzcG53RUk,421)
				JJGN7qxBnbcP = True
		if JJGN7qxBnbcP: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if oN6FKz2SkGiLnJ3tx4=='featured':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('PinSlider(.*?)MultiFilter',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('PinSlider(.*?)PageTitle',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
		else: wltPGJcYo12Ed = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
	elif '/filter/' in url:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('PageContent(.*?)class="*pagination"*',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
	elif '/actors' in url:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('PageContent(.*?)class="*pagination"*',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('Cima4uBlocks(.*?)</li></ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
		else: wltPGJcYo12Ed = ''
	if not items: items = QPuHKNAT4jmCRg.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if not items: items = QPuHKNAT4jmCRg.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if not title: continue
		if '?news=' in VV7yf2htDCBU6EeSX8TJQM: continue
		title = title.replace('مشاهدة ','')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) حلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if CiZxgXTGW9pv and 'حلقة' in title:
			title = '_MOD_' + CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,422,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif '/actor/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,421,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,422,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('pagination(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb and oN6FKz2SkGiLnJ3tx4!='featured':
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = title.replace('الصفحة ','')
			if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,421)
	lO6rM8NcKUL5g4wd31nEGQF7HRfu = QPuHKNAT4jmCRg.findall('</li><a href="(.*?)".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if lO6rM8NcKUL5g4wd31nEGQF7HRfu:
		VV7yf2htDCBU6EeSX8TJQM,title = lO6rM8NcKUL5g4wd31nEGQF7HRfu[0]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,421)
	return
def VRktAN65nrGDCqs2vFXuOHcflSh(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="WatchNow".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		url = TTCRYZroizb[0]
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('SeasonsSections(.*?)</div></div></div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if '/tag/' in url or '/actor' in url:
		SPFl6UGK4mrBua(url)
	elif TTCRYZroizb:
		G2WR0Oacvdq8ZQTjKboDU = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Thumb')
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall("href='(.*?)'>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		BQcAWug4Yw8Kq91Zhj5M6iyra = ['مسلسل','موسم','برنامج','حلقة']
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in BQcAWug4Yw8Kq91Zhj5M6iyra):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,423,G2WR0Oacvdq8ZQTjKboDU)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,426,G2WR0Oacvdq8ZQTjKboDU)
	else: opLlxOB2dUVZ5JF4j(url)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"background-image:url\((.*?)\)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
	else: G2WR0Oacvdq8ZQTjKboDU = ''
	p17lwyMzRK3YVjeG = QPuHKNAT4jmCRg.findall('EpisodesSection(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if p17lwyMzRK3YVjeG:
		wltPGJcYo12Ed = p17lwyMzRK3YVjeG[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,CiZxgXTGW9pv in items:
			title = title+' '+CiZxgXTGW9pv
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,426,G2WR0Oacvdq8ZQTjKboDU)
	else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+'رابط التشغيل',url,426,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	WZ2LwsE6xPzqdgrmVkF = nbdMp8UuhzP3oq4cDWj6eyZVt.url
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: WZ2LwsE6xPzqdgrmVkF = WZ2LwsE6xPzqdgrmVkF.encode('utf8')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(WZ2LwsE6xPzqdgrmVkF,'url')
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('WatchSection(.*?)</div></div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('data-link="(.*?)".*? />(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for zHAUyrXjf1aSmh,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/structure/server.php?id='+zHAUyrXjf1aSmh+'?named='+title+'__watch'
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\r','')
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('DownloadServers(.*?)</div></div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*? />(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): nUbpaNT0vhcj7ZsEz = '__خاص'
			else: nUbpaNT0vhcj7ZsEz = ''
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'+nUbpaNT0vhcj7ZsEz
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\r','')
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/Search?q='+search
	SPFl6UGK4mrBua(url,'search')
	return
def PD19Sz64kNmaXxw(url):
	if 'smartemadfilter' not in url: url = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('MultiFilter(.*?)PageTitle',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return K0MwVeCGOmJho
def zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed):
	items = QPuHKNAT4jmCRg.findall('data-id="(.*?)".*?</div>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return items
def nGPYq9pSD5(url):
	rrU0IR1Aga6Y = url.split('/smartemadfilter?')[0]
	eek0phlJjL6MWVXsmy7wFPz2oT = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	url = url.replace(rrU0IR1Aga6Y,eek0phlJjL6MWVXsmy7wFPz2oT)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
vMgBXHJ4ETR1qjkDAhKsc9SuY = ['category','types','release-year']
RBkuwxQsqh6CaLzMcGWbftSrI = ['Quality','release-year','types','category']
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global vMgBXHJ4ETR1qjkDAhKsc9SuY
			vMgBXHJ4ETR1qjkDAhKsc9SuY = vMgBXHJ4ETR1qjkDAhKsc9SuY[1:]
		if vMgBXHJ4ETR1qjkDAhKsc9SuY[0]+'=' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[0]
		for PXBFxvuUlLDHGpm58 in range(len(vMgBXHJ4ETR1qjkDAhKsc9SuY[0:-1])):
			if vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+jsEpRxQH76+'=0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+jsEpRxQH76+'=0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='ALL_ITEMS_FILTER':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+Lb7kxwJZBPquygXoO4nTSN3
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nGPYq9pSD5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,421,'','','filter')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,421,'','','filter')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K0MwVeCGOmJho = PD19Sz64kNmaXxw(url)
	dict = {}
	for name,wltPGJcYo12Ed,qQ3oR7maZGeFByA6uitjrd in K0MwVeCGOmJho:
		if '/category/' in url and qQ3oR7maZGeFByA6uitjrd=='category': continue
		name = name.replace('--','')
		items = zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed)
		if '=' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='SPECIFIED_FILTER':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<2:
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]:
					url = nGPYq9pSD5(url)
					SPFl6UGK4mrBua(url)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'SPECIFIED_FILTER___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nGPYq9pSD5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,421,'','','filter')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,425,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='ALL_ITEMS_FILTER':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع :'+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,424,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			if pp8iHB3W9Cs=='196533': wMq2UBSjsfgchHzprXWFOTdn5 = 'أفلام نيتفلكس'
			elif pp8iHB3W9Cs=='196531': wMq2UBSjsfgchHzprXWFOTdn5 = 'مسلسلات نيتفلكس'
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = wMq2UBSjsfgchHzprXWFOTdn5
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'='+wMq2UBSjsfgchHzprXWFOTdn5
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'#+dict[qQ3oR7maZGeFByA6uitjrd]['0']
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'+name
			if type=='ALL_ITEMS_FILTER': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,424,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='SPECIFIED_FILTER' and vMgBXHJ4ETR1qjkDAhKsc9SuY[-2]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'modified_filters')
				lc154VhT9DCqMk8 = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
				lc154VhT9DCqMk8 = nGPYq9pSD5(lc154VhT9DCqMk8)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lc154VhT9DCqMk8,421,'','','filter')
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,425,'','',q0NkUvatj1HcndbF9Yrsw)
	return
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.replace('=&','=0&')
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&')
	XTiOm8cUEJCh3ryql = {}
	if '=' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	VAlPewLIfoQv6dash = ''
	for key in RBkuwxQsqh6CaLzMcGWbftSrI:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
		elif mode=='all': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.replace('=0','=')
	return VAlPewLIfoQv6dash
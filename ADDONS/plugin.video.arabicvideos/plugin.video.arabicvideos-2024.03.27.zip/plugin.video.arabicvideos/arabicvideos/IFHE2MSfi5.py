# -*- coding: utf-8 -*-
import sys as GJtcqTv68ZQpwxYFiDg
yyIoQrPWR1B = GJtcqTv68ZQpwxYFiDg.version_info [0] == 2
Duhwt2HMRTeBonVic0lz8bjUJ = 2048
BnAMltLNqzHfjxWkVi9eb3P = 7
def rrgVqwDZPsMjxvR3EylNz9 (tbA2GsXVSDNgm):
	global lzR5Gp9sjoDwb
	BZb90tzYkgeu3pcAo = ord (tbA2GsXVSDNgm [-1])
	fdK96q2bHgSIwE = tbA2GsXVSDNgm [:-1]
	klvdJbzV7PEMciQ61A0t25SGXq8 = BZb90tzYkgeu3pcAo % len (fdK96q2bHgSIwE)
	q5yMKdNsYpzDj8Oo = fdK96q2bHgSIwE [:klvdJbzV7PEMciQ61A0t25SGXq8] + fdK96q2bHgSIwE [klvdJbzV7PEMciQ61A0t25SGXq8:]
	if yyIoQrPWR1B:
		hq2Yj5TvMOKsRFroabWu = unicode () .join ([unichr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	else:
		hq2Yj5TvMOKsRFroabWu = str () .join ([chr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	return eval (hq2Yj5TvMOKsRFroabWu)
iRTygNp4Lf36wQKlD2MHUhG7B,KbL94nDHufSF0VcO2Nk3,qNZKwi2M1S4fBzGQYrmPnea=rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9
xxpPYJOnoAUrlBzyveui,ldOGfm56kWs8T03wcptQunqEUBDrvC,Arg2GFJDt3emTvpO6fZkSVdaUHywnN=qNZKwi2M1S4fBzGQYrmPnea,KbL94nDHufSF0VcO2Nk3,iRTygNp4Lf36wQKlD2MHUhG7B
v7reLlOXCgD5pZ14w2tUA,p1lrNRIXqLQJznH6O,ddK4MmwpX5oG=Arg2GFJDt3emTvpO6fZkSVdaUHywnN,ldOGfm56kWs8T03wcptQunqEUBDrvC,xxpPYJOnoAUrlBzyveui
OARzhnB9o7uYvQGFaIcZ,ZpH2IWt7veyFobTsAnhi41,q0JfWbP8vACLxSNIncpOXkR6j=ddK4MmwpX5oG,p1lrNRIXqLQJznH6O,v7reLlOXCgD5pZ14w2tUA
L91nVzxH4hYrgPDsOuljXd0J,uhOkAKtLVv4XTy1nWE6,d1JiVThqEO0nBaY2QRNyZxlujWw7SK=q0JfWbP8vACLxSNIncpOXkR6j,ZpH2IWt7veyFobTsAnhi41,OARzhnB9o7uYvQGFaIcZ
V391t7nQWUBR5euCkJ,IJ6VkihabRm,lunVJF2G5bZMgTcCje0vaIB371SX=d1JiVThqEO0nBaY2QRNyZxlujWw7SK,uhOkAKtLVv4XTy1nWE6,L91nVzxH4hYrgPDsOuljXd0J
xxBJoKG54uwQ,gr5K72RtvAZYPVwkdnspbzQWNjEI,u1ml5XcLiZ7oDPs3UjedgpYHhfV=lunVJF2G5bZMgTcCje0vaIB371SX,IJ6VkihabRm,V391t7nQWUBR5euCkJ
dxAs4otSE98YmZnKy2iwRCB,fcIm8tvxlXZsaEY3bwuG4B,f8PVRTseIuj9BckO6GoyF5Lxv=u1ml5XcLiZ7oDPs3UjedgpYHhfV,gr5K72RtvAZYPVwkdnspbzQWNjEI,xxBJoKG54uwQ
tKVplxqYIdngGF6TZkXeb2PiwfME,vkMRnTNV9jFm,HMO0QciekqVpLKmA=f8PVRTseIuj9BckO6GoyF5Lxv,fcIm8tvxlXZsaEY3bwuG4B,dxAs4otSE98YmZnKy2iwRCB
DKqQekNtF6WlJLhBP9M5ca,GGTRaYBDeNyI25zlF,Vv0lSjAOHLfMnam3wtdor=HMO0QciekqVpLKmA,vkMRnTNV9jFm,tKVplxqYIdngGF6TZkXeb2PiwfME
a06i2XFf3oBnDrJQZEKmHpqY9ACW,DDS79jdWzLtE,zOZvXaebGNwHKfjRA=Vv0lSjAOHLfMnam3wtdor,GGTRaYBDeNyI25zlF,DKqQekNtF6WlJLhBP9M5ca
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩᶈ")
def hLD0mk9HIuPOz7pw(Q6FbqZ9uIe8v2xaTHhfDCJ,OO1XlVPzfQrMTmJv=V391t7nQWUBR5euCkJ(u"ࠨࠩᶉ")):
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==  d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠰৑"): z6ANjDq4rxkMcFtQsSLKo0hOJu72(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  q0JfWbP8vACLxSNIncpOXkR6j(u"࠳৒"): z4tZrfkMm92x3FQEv5dw1s6OJiXu(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  OARzhnB9o7uYvQGFaIcZ(u"࠵৓"): wXT9gd7KqLVlOB()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  OARzhnB9o7uYvQGFaIcZ(u"࠷৔"): rVwqOcjQa5zDPE(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  f8PVRTseIuj9BckO6GoyF5Lxv(u"࠹৕"): qOIuD53C0Ua4MGpc()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  dxAs4otSE98YmZnKy2iwRCB(u"࠻৖"): EbUFPLiZ7x2Xl()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  L91nVzxH4hYrgPDsOuljXd0J(u"࠽ৗ"): QpwoVDjc2Kir4GtfEuyJkUzX5YsR(uhOkAKtLVv4XTy1nWE6(u"ࡘࡷࡻࡥ઄"),uhOkAKtLVv4XTy1nWE6(u"ࡘࡷࡻࡥ઄"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  q0JfWbP8vACLxSNIncpOXkR6j(u"࠸৘"): KoD7fXZ8mcQGYkHzib16OJnLxB45()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==  a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠺৙"): eeCmjUOBLFfrbM64()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==vkMRnTNV9jFm(u"࠳࠸࠴৚"): zK8UIO7p413YnhjsTAde()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==lunVJF2G5bZMgTcCje0vaIB371SX(u"࠴࠹࠶৛"): UctAhZmGFMg0X3w()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵࠺࠸ড়"): KvrON73fF9WLckPBS2UEw()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶࠻࠳ঢ়"): k2ZSMBawCL8eEzt0hbArmx()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==lunVJF2G5bZMgTcCje0vaIB371SX(u"࠷࠵࠵৞"): zsrboPJhAxUZgpwVejHnLSQfI()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==L91nVzxH4hYrgPDsOuljXd0J(u"࠱࠶࠷য়"): wdfu72Jx8eWyVFjb()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==OARzhnB9o7uYvQGFaIcZ(u"࠲࠷࠹ৠ"): fBrWTYn2Gc90()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==ZpH2IWt7veyFobTsAnhi41(u"࠳࠸࠻ৡ"): shJ8PjmIVl6gOp2L1CbNy()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==iRTygNp4Lf36wQKlD2MHUhG7B(u"࠴࠹࠽ৢ"): V1K68rbwUBhjJfeoSX()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==qNZKwi2M1S4fBzGQYrmPnea(u"࠵࠺࠿ৣ"): EE0PlFd2ec9Ao(L91nVzxH4hYrgPDsOuljXd0J(u"࡙ࡸࡵࡦઅ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠶࠽࠰৤"): RR0Id1LXJgvof2GQOah()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠷࠷࠲৥"): m9mrFOgHlDWTKk()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==ddK4MmwpX5oG(u"࠱࠸࠴০"): QnXFVhjS03wM6d2DUGfZKgb4l(OO1XlVPzfQrMTmJv,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡚ࡲࡶࡧઆ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡚ࡲࡶࡧઆ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==vkMRnTNV9jFm(u"࠲࠹࠶১"): ua95I6RK27wGQgmYXqc(fcIm8tvxlXZsaEY3bwuG4B(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩᶊ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡔࡳࡷࡨઇ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==v7reLlOXCgD5pZ14w2tUA(u"࠳࠺࠸২"): ua95I6RK27wGQgmYXqc(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ᶋ"),vkMRnTNV9jFm(u"ࡕࡴࡸࡩઈ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠴࠻࠺৩"): GGi8ZJWRq2LT60pmCPj()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==fcIm8tvxlXZsaEY3bwuG4B(u"࠵࠼࠼৪"): YaVxdOeX6ykW3AB9gpES5H()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==iRTygNp4Lf36wQKlD2MHUhG7B(u"࠶࠽࠷৫"): xZfCkimFuYbaEloAzcBQ7sevT(xxBJoKG54uwQ(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨᶌ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==ddK4MmwpX5oG(u"࠷࠷࠹৬"): xZfCkimFuYbaEloAzcBQ7sevT(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩᶍ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==Vv0lSjAOHLfMnam3wtdor(u"࠱࠸࠻৭"): xZfCkimFuYbaEloAzcBQ7sevT(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ᶎ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==vkMRnTNV9jFm(u"࠲࠻࠳৮"): rrXHNg2IwUsxLQd()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==vkMRnTNV9jFm(u"࠳࠼࠵৯"): qY4xPg6AsJoVhj3rIXl0pSwWfL()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠴࠽࠷ৰ"): b0KNEgsmpWZdvDkTqU8BFYOcC6GIl()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==ZpH2IWt7veyFobTsAnhi41(u"࠵࠾࠹ৱ"): yiNWojhaz8wZU2LM()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==q0JfWbP8vACLxSNIncpOXkR6j(u"࠶࠿࠴৲"): K2zlrWQfItFTHmhUSNuCkRe5AJg()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠷࠹࠶৳"): LBbx75IPoEZ0rkRtfsaJ()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxpPYJOnoAUrlBzyveui(u"࠱࠺࠸৴"): VE4q8kruF7QTGt2fX1KjmheY()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==KbL94nDHufSF0VcO2Nk3(u"࠲࠻࠺৵"): z9X8gMaqTKAOu1e()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠳࠼࠼৶"): nOl7pCKWe3FtdSf()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠴࠽࠾৷"): zmM7RtsN51LkF392XeKqIByOSA()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==L91nVzxH4hYrgPDsOuljXd0J(u"࠷࠹࠶৸"): EEBPeLvbq5CFaniTKgcj6(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==qNZKwi2M1S4fBzGQYrmPnea(u"࠸࠺࠱৹"): T65coqAhLzyGMmQ7tlN()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==HMO0QciekqVpLKmA(u"࠹࠴࠳৺"): INOLAQ1fEX2n7CYH0WwyDc4KSF5Z()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==L91nVzxH4hYrgPDsOuljXd0J(u"࠳࠵࠵৻"): vvUgmO9zIrTM2ALs8c6dj7ZWYaJ()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==KbL94nDHufSF0VcO2Nk3(u"࠴࠶࠷ৼ"): I4Xlj3MYu2qNsbWfRF17Brc(xxBJoKG54uwQ(u"ࡖࡵࡹࡪઉ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxBJoKG54uwQ(u"࠵࠷࠹৽"): aBUopDxT6qikPfQmt4nC3Vd()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==ddK4MmwpX5oG(u"࠶࠸࠻৾"): zs1cdAxpVm6SNEhKFvOWyw(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡉࡥࡱࡹࡥઊ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==dxAs4otSE98YmZnKy2iwRCB(u"࠷࠹࠽৿"): i1eUnRIqv39loL(fcIm8tvxlXZsaEY3bwuG4B(u"ࡘࡷࡻࡥઋ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==q0JfWbP8vACLxSNIncpOXkR6j(u"࠸࠺࠸਀"): iRWd5hPA8TkqcEYj2CUK7woaD9mxH()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==IJ6VkihabRm(u"࠹࠴࠺ਁ"): pass
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==v7reLlOXCgD5pZ14w2tUA(u"࠵࠱࠲ਂ"): WkpF0VYlGfu4omScOQPXzT5NvZ6AR()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==Vv0lSjAOHLfMnam3wtdor(u"࠶࠲࠴ਃ"): V5V0CDoZW6HIYxq3bXz2LB()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==fcIm8tvxlXZsaEY3bwuG4B(u"࠷࠳࠶਄"): umWlhxIPytXBK2H4Voq8p(xxBJoKG54uwQ(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᶏ"),qNZKwi2M1S4fBzGQYrmPnea(u"࡙ࡸࡵࡦઌ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxpPYJOnoAUrlBzyveui(u"࠸࠴࠸ਅ"): c8nMPVbKZdhJRyN36zjBWk(PPgJ3en0yKYWdzMAmCON1DTQG9)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==f8PVRTseIuj9BckO6GoyF5Lxv(u"࠹࠵࠺ਆ"): c8nMPVbKZdhJRyN36zjBWk(KmlAH1VJObEkfZS3ToazF8qNP70t)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==DDS79jdWzLtE(u"࠺࠶࠵ਇ"): eG7yL3XhvCjrHdiWVwN41b()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==V391t7nQWUBR5euCkJ(u"࠻࠰࠷ਈ"): tb6VfQWohldXaqIvCYiw(fcIm8tvxlXZsaEY3bwuG4B(u"࡚ࡲࡶࡧઍ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==HMO0QciekqVpLKmA(u"࠵࠱࠹ਉ"): OAMvDTS3GVkCyjWzJgb(OO1XlVPzfQrMTmJv,xxpPYJOnoAUrlBzyveui(u"ࠨࠩᶐ"),ddK4MmwpX5oG(u"ࡔࡳࡷࡨ઎"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxBJoKG54uwQ(u"࠶࠲࠻ਊ"): y97dvB3rjq4()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==qNZKwi2M1S4fBzGQYrmPnea(u"࠷࠳࠽਋"): HZ0VtF1s5ug89exaOBdlcfq()
	return
def HZ0VtF1s5ug89exaOBdlcfq():
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(uhOkAKtLVv4XTy1nWE6(u"ࠩࠪᶑ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࠫᶒ"),p1lrNRIXqLQJznH6O(u"ࠫࠬᶓ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶔ"),GGTRaYBDeNyI25zlF(u"࠭็ๅࠢอี๏ีࠠโ฻็ห๋ࠥำฮࠢฯ้๏฿ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ࠲࠳่ࠦๆีะࠤัฺ๋๊่่ࠢๆอสࠡษ็ฬึ์วๆฮࠣห้่ฯ๋็ฬࠤ࠳࠴ࠠๅๅํࠤ๏฿่ะࠢส่อืๆศ็ฯࠤส๊้ࠡฯส่ฮࠦวๅืไีࠥ࠴࠮ࠡ์฼๊๏ࠦสอัํำࠥอไษำ้ห๊า้ࠠฬุๅ๏ื็ฺ๊๋ࠡ฾ํࠠษฯส่ฮࠦวๅ็ุ๊฾ࠦวๅฬํࠤํ฼ู่ษࠣห้๋ศา็ฯࠤฤࠧࠡࠨᶕ"))
	if T4TGmZ9XWAzONaKygic:
		I4Xlj3MYu2qNsbWfRF17Brc(dxAs4otSE98YmZnKy2iwRCB(u"ࡇࡣ࡯ࡷࡪએ"))
		Qzbnt3opXim(vBXJAQCwEpS0xZ6km9a,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡗࡶࡺ࡫ઑ"),KbL94nDHufSF0VcO2Nk3(u"ࡈࡤࡰࡸ࡫ઐ"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠨᶖ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࠩᶗ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶘ"),ZpH2IWt7veyFobTsAnhi41(u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡษ็้้็วหࠢส่็ี๊ๆห่้ࠣฮั็ษ่ะࠥ࠴࠮๊ࠡ฼หิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊ีโำࠣ࠲࠳่ࠦื฻ํอࠥอไๆื้฽ࠬᶙ"))
	return
def OAMvDTS3GVkCyjWzJgb(M0J6Pq3bH2,ewPSm7U64rIuJBbv,showDialogs):
	qcOU43biDkaPQlZMB1wHEj = csXRAak0iZIKQpfu1o.connect(zmL4569eBqGphRbKP7f2NOs)
	qcOU43biDkaPQlZMB1wHEj.text_factory = str
	K2DlNXvQC65FzngUVyk3IGAq = qcOU43biDkaPQlZMB1wHEj.cursor()
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: nvUojG2DINBhlifV8C = Vv0lSjAOHLfMnam3wtdor(u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧᶚ")
	else: nvUojG2DINBhlifV8C = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫᶛ")
	K2DlNXvQC65FzngUVyk3IGAq.execute(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧᶜ")+nvUojG2DINBhlifV8C+OARzhnB9o7uYvQGFaIcZ(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᶝ")+M0J6Pq3bH2+HMO0QciekqVpLKmA(u"ࠨࠤࠣ࠿ࠬᶞ"))
	u5hKSaFyVqLz90Zc6iG = K2DlNXvQC65FzngUVyk3IGAq.fetchall()
	if u5hKSaFyVqLz90Zc6iG and ewPSm7U64rIuJBbv in [iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࠪᶟ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪᶠ")]:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠬᶡ"),ddK4MmwpX5oG(u"ࠬ࠭ᶢ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࠧᶣ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶤ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᶥ")+M0J6Pq3bH2+p1lrNRIXqLQJznH6O(u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᶦ"))
		if T4TGmZ9XWAzONaKygic!=gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠴਌"): return
		K2DlNXvQC65FzngUVyk3IGAq.execute(xxBJoKG54uwQ(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩᶧ")+nvUojG2DINBhlifV8C+xxBJoKG54uwQ(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᶨ")+M0J6Pq3bH2+GGTRaYBDeNyI25zlF(u"ࠬࠨࠠ࠼ࠩᶩ"))
	elif ewPSm7U64rIuJBbv in [ddK4MmwpX5oG(u"࠭ࠧᶪ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨᶫ")]:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠩᶬ"),uhOkAKtLVv4XTy1nWE6(u"ࠩࠪᶭ"),OARzhnB9o7uYvQGFaIcZ(u"ࠪࠫᶮ"),DDS79jdWzLtE(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶯ"),HMO0QciekqVpLKmA(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩᶰ")+M0J6Pq3bH2+Vv0lSjAOHLfMnam3wtdor(u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᶱ"))
		if T4TGmZ9XWAzONaKygic!=zOZvXaebGNwHKfjRA(u"࠵਍"): return
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: K2DlNXvQC65FzngUVyk3IGAq.execute(OARzhnB9o7uYvQGFaIcZ(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᶲ")+M0J6Pq3bH2+vkMRnTNV9jFm(u"ࠨࠤࠬࠤࡀ࠭ᶳ"))
		else: K2DlNXvQC65FzngUVyk3IGAq.execute(xxBJoKG54uwQ(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩᶴ")+M0J6Pq3bH2+IJ6VkihabRm(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪᶵ"))
	qcOU43biDkaPQlZMB1wHEj.commit()
	qcOU43biDkaPQlZMB1wHEj.close()
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶਎"))
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(dxAs4otSE98YmZnKy2iwRCB(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨᶶ"))
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠷ਏ"))
	if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࠭ᶷ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࠧᶸ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶹ"),V391t7nQWUBR5euCkJ(u"ࠨฬ่ฮࠥอไฺ็็๎ฮࠦศ็ฮสัࠬᶺ"))
	if ewPSm7U64rIuJBbv in [zOZvXaebGNwHKfjRA(u"ࠩࠪᶻ"),DDS79jdWzLtE(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪᶼ")]: EE0PlFd2ec9Ao(showDialogs)
	return
def eG7yL3XhvCjrHdiWVwN41b():
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᶽ"),ddK4MmwpX5oG(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᶾ"))
	IR6EdvxHspW9GrFlbymXq = L19zfOaM6iKrnFUjSxQJ5dN(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡊࡦࡲࡳࡦ઒"))
	MwvT6niIWJk2B3gdANqScPtbXhH9R = Vv0lSjAOHLfMnam3wtdor(u"࠭࡜࡯ࠩᶿ")
	f6U0AIJZsvQ9Ncyz = L91nVzxH4hYrgPDsOuljXd0J(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᷀")
	gzxk1EHlUmuWLZQ9i8 = KbL94nDHufSF0VcO2Nk3(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ᷁")
	for id,wn0kd1pEgfSy4YG,DupnWHq2SvjtxNh67sBQkLT5mJM3aP,Iga6ZWzdXDuoFO7NPjEf2AMxL8,Qg09MKEjzlUCJdt78D1x4ThbrP,reason in reversed(IR6EdvxHspW9GrFlbymXq):
		if id==xxpPYJOnoAUrlBzyveui(u"ࠩ࠳᷂ࠫ"):
			hNVxa2sHRn,ZSo5irGsQTwLa = Iga6ZWzdXDuoFO7NPjEf2AMxL8.split(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡠࡳࡁ࠻ࠨ᷃"))
			continue
		if MwvT6niIWJk2B3gdANqScPtbXhH9R!=zOZvXaebGNwHKfjRA(u"ࠫࡡࡴࠧ᷄"): MwvT6niIWJk2B3gdANqScPtbXhH9R += gzxk1EHlUmuWLZQ9i8
		GhpNfPVMB2uRnqasFL6K = DDS79jdWzLtE(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭᷅")+id+f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࠠ࠻ࠢࠪ᷆")+zOZvXaebGNwHKfjRA(u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ᷇")+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᷈")+DupnWHq2SvjtxNh67sBQkLT5mJM3aP
		fl57MHCK8LhbtieNY0QUck4AO = V391t7nQWUBR5euCkJ(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᷉")+Iga6ZWzdXDuoFO7NPjEf2AMxL8
		IIEUd7xqAfnlYvgtaCMQ5h = GGTRaYBDeNyI25zlF(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ᷊࠭")+Qg09MKEjzlUCJdt78D1x4ThbrP
		PPgIRJtB2XQhmfzoU4 = fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีหฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᷋")+reason
		MwvT6niIWJk2B3gdANqScPtbXhH9R += GhpNfPVMB2uRnqasFL6K+fl57MHCK8LhbtieNY0QUck4AO+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡢ࡮ࠨ᷌")+f6U0AIJZsvQ9Ncyz+ZpH2IWt7veyFobTsAnhi41(u"࠭࡜࡯ࠩ᷍")+IIEUd7xqAfnlYvgtaCMQ5h+PPgIRJtB2XQhmfzoU4+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࡝ࡰ᷎ࠪ")
	qQL7e23RtCg4xOpf(v7reLlOXCgD5pZ14w2tUA(u"ࠨࡴ࡬࡫࡭ࡺ᷏ࠧ"),ZSo5irGsQTwLa,MwvT6niIWJk2B3gdANqScPtbXhH9R,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩ᷐ࠪ"))
	return
def c8nMPVbKZdhJRyN36zjBWk(file):
	if file==KmlAH1VJObEkfZS3ToazF8qNP70t: tX5VkCo9DUNm17 = Vv0lSjAOHLfMnam3wtdor(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ᷑")
	elif file==PPgJ3en0yKYWdzMAmCON1DTQG9: tX5VkCo9DUNm17 = KbL94nDHufSF0VcO2Nk3(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ᷒")
	Df3p8YoF4GVj1bShqTQk5z0Wn = GjZltWoCxuIwNfQ7EH9(uhOkAKtLVv4XTy1nWE6(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᷓ"),uhOkAKtLVv4XTy1nWE6(u"࠭ๅิฯࠪᷔ"),IJ6VkihabRm(u"ࠧฦื็หา࠭ᷕ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨะิ์ั࠭ᷖ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷗ"),ddK4MmwpX5oG(u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨᷘ")+tX5VkCo9DUNm17+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫᷙ"))
	if Df3p8YoF4GVj1bShqTQk5z0Wn==uhOkAKtLVv4XTy1nWE6(u"࠰ਐ"):
		if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(file):
			try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(file)
			except: pass
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(dxAs4otSE98YmZnKy2iwRCB(u"ࠬ࠭ᷚ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࠧᷛ"),IJ6VkihabRm(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᷜ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭ᷝ")+tX5VkCo9DUNm17)
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==qNZKwi2M1S4fBzGQYrmPnea(u"࠲਑"):
		data = MMnGsYl0Oh9zgub43E5m(file)
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(OARzhnB9o7uYvQGFaIcZ(u"ࠩࠪᷞ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࠫᷟ"),xxpPYJOnoAUrlBzyveui(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᷠ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬᷡ")+tX5VkCo9DUNm17)
	return
def V5V0CDoZW6HIYxq3bXz2LB():
	if LRjqrQYBXFVPfu<IJ6VkihabRm(u"࠳࠻਒"):
		qNEnDMwm1Vfastx2ZkpRh = dxAs4otSE98YmZnKy2iwRCB(u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩᷢ")+str(LRjqrQYBXFVPfu)+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨᷣ")
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠩᷤ"),HMO0QciekqVpLKmA(u"ࠩࠪᷥ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷦ"),qNEnDMwm1Vfastx2ZkpRh)
		return
	AsqvTSMpVNy = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᷧ"))
	BwiXRqKVEj = QNumy9zkeS([ZpH2IWt7veyFobTsAnhi41(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷨ")])
	xbkrlD0EILwKiPB68MhNpRuA,ZWI6kvdqPz7rOC0enX,gaBXSUFDeuIJyMpCYTrLZz05,OyQDJeVudN0c,ifWNgOL7zYB3eX6PRF1,tcRirKM2lfyWAhanvCe1om,zC5oqj0kfaiBZ83stxESyg = BwiXRqKVEj[uhOkAKtLVv4XTy1nWE6(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᷩ")]
	if xbkrlD0EILwKiPB68MhNpRuA or iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᷪ") not in str(AsqvTSMpVNy):
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(V391t7nQWUBR5euCkJ(u"ࠨࠩᷫ"),ZpH2IWt7veyFobTsAnhi41(u"ࠩࠪᷬ"),HMO0QciekqVpLKmA(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷭ"),DDS79jdWzLtE(u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩᷮ"))
		BcMl3XdLS0zmK1jPvDJANfYH = umWlhxIPytXBK2H4Voq8p(DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷯ"),xxpPYJOnoAUrlBzyveui(u"࡙ࡸࡵࡦઓ"))
		if not BcMl3XdLS0zmK1jPvDJANfYH: return
	DuBVAHl4FZjxJLcRp8ehst(Vv0lSjAOHLfMnam3wtdor(u"࡚ࡲࡶࡧઔ"))
	return
def DuBVAHl4FZjxJLcRp8ehst(showDialogs=KbL94nDHufSF0VcO2Nk3(u"ࡔࡳࡷࡨક")):
	AsqvTSMpVNy = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(V391t7nQWUBR5euCkJ(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩᷰ"))
	if a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᷱ") not in str(AsqvTSMpVNy):
		if showDialogs:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ddK4MmwpX5oG(u"ࠨࠩᷲ"),KbL94nDHufSF0VcO2Nk3(u"ࠩࠪᷳ"),xxpPYJOnoAUrlBzyveui(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷴ"),DDS79jdWzLtE(u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ᷵"))
		return
	BBeXpdEM5aroFUIlPbYVHjnAJ90KNO = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡧࡤࡥࡱࡱࡷࠬ᷶"),p1lrNRIXqLQJznH6O(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ᷷ࠬ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠧ࠸࠴࠳ࡴ᷸ࠬ"),p1lrNRIXqLQJznH6O(u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭᷹ࠩ"))
	if not YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(BBeXpdEM5aroFUIlPbYVHjnAJ90KNO): return
	g4gokw71hemBnS3xPIORXJNbLzV = open(BBeXpdEM5aroFUIlPbYVHjnAJ90KNO,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࡵࡦ᷺ࠬ")).read()
	if Nnxm30dfoBWRYpIC7KsQGl: g4gokw71hemBnS3xPIORXJNbLzV = g4gokw71hemBnS3xPIORXJNbLzV.decode(zOZvXaebGNwHKfjRA(u"ࠪࡹࡹ࡬࠸ࠨ᷻"))
	KHqEYex45ZXLC63rDmvTat = QPuHKNAT4jmCRg.findall(qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ᷼"),g4gokw71hemBnS3xPIORXJNbLzV,QPuHKNAT4jmCRg.DOTALL)
	rCx0Qi4P8FYdmpwzlyh,n7nH2tiqVRaD1pA = KHqEYex45ZXLC63rDmvTat[vkMRnTNV9jFm(u"࠳ਓ")]
	PQuYOvNSBDk8CWxTZ = V391t7nQWUBR5euCkJ(u"ࠬࡂࡶࡪࡧࡺࡷࡃ᷽࠭")+rCx0Qi4P8FYdmpwzlyh+dxAs4otSE98YmZnKy2iwRCB(u"࠭ࠬࠨ᷾")+n7nH2tiqVRaD1pA+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿᷿ࠩ")
	if showDialogs:
		bZ7RvU9GdMcnz3OAQkDB = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(ddK4MmwpX5oG(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭Ḁ"))
		if bZ7RvU9GdMcnz3OAQkDB==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬḁ"): YxltFNqsr6BSEy5uzdf7o = GGTRaYBDeNyI25zlF(u"ࠪๆํอฦๆࠢส่่ะวษหࠪḂ")
		elif bZ7RvU9GdMcnz3OAQkDB==ZpH2IWt7veyFobTsAnhi41(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪḃ"): YxltFNqsr6BSEy5uzdf7o = iRTygNp4Lf36wQKlD2MHUhG7B(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪḄ")
		else: YxltFNqsr6BSEy5uzdf7o = f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭โ้ษษ้ࠥษฮา๋ࠪḅ")
		Df3p8YoF4GVj1bShqTQk5z0Wn = GjZltWoCxuIwNfQ7EH9(GGTRaYBDeNyI25zlF(u"ࠧࡤࡧࡱࡸࡪࡸࠧḆ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨไ๋หห๋ࠠฤะิํࠬḇ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩḈ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨḉ"),GGTRaYBDeNyI25zlF(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨḊ")+YxltFNqsr6BSEy5uzdf7o,qNZKwi2M1S4fBzGQYrmPnea(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḋ"))
		if Df3p8YoF4GVj1bShqTQk5z0Wn==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠵ਔ"): BWCw5uULhQ6V9y4 = q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩḌ")
		elif Df3p8YoF4GVj1bShqTQk5z0Wn==q0JfWbP8vACLxSNIncpOXkR6j(u"࠷ਕ"): BWCw5uULhQ6V9y4 = zOZvXaebGNwHKfjRA(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ḍ")
		else: BWCw5uULhQ6V9y4 = p1lrNRIXqLQJznH6O(u"ࠨࠩḎ")
	else:
		bZ7RvU9GdMcnz3OAQkDB = fQ6kvwg1FrYAzXjbLT.getSetting(GGTRaYBDeNyI25zlF(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧḏ"))
		if   bZ7RvU9GdMcnz3OAQkDB==L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࠫḐ"): Df3p8YoF4GVj1bShqTQk5z0Wn = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶ਖ")
		elif bZ7RvU9GdMcnz3OAQkDB==xxBJoKG54uwQ(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧḑ"): Df3p8YoF4GVj1bShqTQk5z0Wn = f8PVRTseIuj9BckO6GoyF5Lxv(u"࠱ਗ")
		elif bZ7RvU9GdMcnz3OAQkDB==vkMRnTNV9jFm(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫḒ"): Df3p8YoF4GVj1bShqTQk5z0Wn = vkMRnTNV9jFm(u"࠳ਘ")
		BWCw5uULhQ6V9y4 = bZ7RvU9GdMcnz3OAQkDB
	if   Df3p8YoF4GVj1bShqTQk5z0Wn==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠲ਙ"): uO3RvdSijYkWrGxmlIXq = Vv0lSjAOHLfMnam3wtdor(u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪḓ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==fcIm8tvxlXZsaEY3bwuG4B(u"࠴ਚ"): uO3RvdSijYkWrGxmlIXq = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫḔ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==f8PVRTseIuj9BckO6GoyF5Lxv(u"࠶ਛ"): uO3RvdSijYkWrGxmlIXq = ZpH2IWt7veyFobTsAnhi41(u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬḕ")
	else: return
	fQ6kvwg1FrYAzXjbLT.setSetting(L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧḖ"),BWCw5uULhQ6V9y4)
	INTjKnMDUsPZpw = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫḗ")+uO3RvdSijYkWrGxmlIXq+DDS79jdWzLtE(u"ࠫ࠱࠭Ḙ")+n7nH2tiqVRaD1pA+f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧḙ")
	I5n6KcZWvLYtkrof0eMJsASTaU = g4gokw71hemBnS3xPIORXJNbLzV.replace(PQuYOvNSBDk8CWxTZ,INTjKnMDUsPZpw)
	if Nnxm30dfoBWRYpIC7KsQGl: I5n6KcZWvLYtkrof0eMJsASTaU = I5n6KcZWvLYtkrof0eMJsASTaU.encode(L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࡵࡵࡨ࠻ࠫḚ"))
	open(BBeXpdEM5aroFUIlPbYVHjnAJ90KNO,V391t7nQWUBR5euCkJ(u"ࠧࡸࡤࠪḛ")).write(I5n6KcZWvLYtkrof0eMJsASTaU)
	zRM3tZx2v6DjJU(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡐࡒࡘࡎࡉࡅࠨḜ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩ࠱ࠤ࡙ࠥ࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧḝ")+uO3RvdSijYkWrGxmlIXq+GGTRaYBDeNyI25zlF(u"ࠪࠤࡢ࠭Ḟ"))
	if showDialogs: AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(uhOkAKtLVv4XTy1nWE6(u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪḟ"))
	return
def WkpF0VYlGfu4omScOQPXzT5NvZ6AR():
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(qNZKwi2M1S4fBzGQYrmPnea(u"ࠬ࠭Ḡ"),KbL94nDHufSF0VcO2Nk3(u"࠭ࠧḡ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠨḢ"),uhOkAKtLVv4XTy1nWE6(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḣ"),ddK4MmwpX5oG(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧḤ"))
	if T4TGmZ9XWAzONaKygic==L91nVzxH4hYrgPDsOuljXd0J(u"࠶ਜ"): QpwoVDjc2Kir4GtfEuyJkUzX5YsR(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡕࡴࡸࡩખ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡕࡴࡸࡩખ"))
	return
def KoD7fXZ8mcQGYkHzib16OJnLxB45():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ddK4MmwpX5oG(u"ࠪࠫḥ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࠬḦ"),xxpPYJOnoAUrlBzyveui(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨḧ"),DDS79jdWzLtE(u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩḨ"))
	return
def iRWd5hPA8TkqcEYj2CUK7woaD9mxH():
	GhpNfPVMB2uRnqasFL6K = ddK4MmwpX5oG(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḩ")
	GhpNfPVMB2uRnqasFL6K += xxBJoKG54uwQ(u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧḪ")
	GhpNfPVMB2uRnqasFL6K += a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḫ")
	fl57MHCK8LhbtieNY0QUck4AO = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḬ")
	fl57MHCK8LhbtieNY0QUck4AO += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨḭ")
	fl57MHCK8LhbtieNY0QUck4AO += f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪḮ")
	qNEnDMwm1Vfastx2ZkpRh = zOZvXaebGNwHKfjRA(u"࡛࠭ࡓࡖࡏࡡࠬḯ")+GhpNfPVMB2uRnqasFL6K+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬḰ")+fl57MHCK8LhbtieNY0QUck4AO
	qQL7e23RtCg4xOpf(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡴ࡬࡫࡭ࡺࠧḱ"),ddK4MmwpX5oG(u"ࠩࠪḲ"),qNEnDMwm1Vfastx2ZkpRh)
	return
def zs1cdAxpVm6SNEhKFvOWyw(aq06Wbp7PVnGxrw3ZANXvLkDyK9):
	gkL8loKHRfJyQCYNz0ESU(aq06Wbp7PVnGxrw3ZANXvLkDyK9,KbL94nDHufSF0VcO2Nk3(u"ࡈࡤࡰࡸ࡫ગ"))
	IR6EdvxHspW9GrFlbymXq = L19zfOaM6iKrnFUjSxQJ5dN(aq06Wbp7PVnGxrw3ZANXvLkDyK9)
	id,wn0kd1pEgfSy4YG,DupnWHq2SvjtxNh67sBQkLT5mJM3aP,Iga6ZWzdXDuoFO7NPjEf2AMxL8,Qg09MKEjzlUCJdt78D1x4ThbrP,reason = IR6EdvxHspW9GrFlbymXq[ddK4MmwpX5oG(u"࠶ਝ")]
	hNVxa2sHRn,ZSo5irGsQTwLa = Iga6ZWzdXDuoFO7NPjEf2AMxL8.split(fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡠࡳࡁ࠻ࠨḳ"))
	fl57MHCK8LhbtieNY0QUck4AO,IIEUd7xqAfnlYvgtaCMQ5h,PPgIRJtB2XQhmfzoU4 = Qg09MKEjzlUCJdt78D1x4ThbrP.split(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡡࡴ࠻࠼ࠩḴ"))
	e6D4uNFvmdUXkMSYPgbtqsf7TWHaO = DDS79jdWzLtE(u"ࡗࡶࡺ࡫ઘ")
	while e6D4uNFvmdUXkMSYPgbtqsf7TWHaO:
		iiQKLdcloD = GjZltWoCxuIwNfQ7EH9(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࠭ḵ"),Vv0lSjAOHLfMnam3wtdor(u"࠭ฮา๊ฯࠫḶ"),V391t7nQWUBR5euCkJ(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ḷ"),v7reLlOXCgD5pZ14w2tUA(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩḸ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩḹ"),fl57MHCK8LhbtieNY0QUck4AO)
		if iiQKLdcloD==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠲ਞ"): LQq4rDEPVXaGR = GjZltWoCxuIwNfQ7EH9(Vv0lSjAOHLfMnam3wtdor(u"ࠪࠫḺ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࠬḻ"),xxpPYJOnoAUrlBzyveui(u"ࠬ฿่ะหࠪḼ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࠧḽ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠧๆสาวࠥอไหสิ฽ࠥเ๊าࠢๅหอ๊ࠠๅๆ้ๆฬฺࠧḾ"),IIEUd7xqAfnlYvgtaCMQ5h,DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬḿ"))
		elif iiQKLdcloD==p1lrNRIXqLQJznH6O(u"࠲ਟ"): z4tZrfkMm92x3FQEv5dw1s6OJiXu()
		else: e6D4uNFvmdUXkMSYPgbtqsf7TWHaO = p1lrNRIXqLQJznH6O(u"ࡊࡦࡲࡳࡦઙ")
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭Ṁ"))
	return
def I4Xlj3MYu2qNsbWfRF17Brc(showDialogs):
	T4TGmZ9XWAzONaKygic = qNZKwi2M1S4fBzGQYrmPnea(u"࡙ࡸࡵࡦચ")
	if showDialogs: T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(V391t7nQWUBR5euCkJ(u"ࠪࡧࡪࡴࡴࡦࡴࠪṁ"),p1lrNRIXqLQJznH6O(u"ࠫࠬṂ"),vkMRnTNV9jFm(u"ࠬ࠭ṃ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ำลษ็ࠫṄ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"่ࠧๆࠣว๋ะࠠๆฬฦ็ิ่ࠦหำํำ๋ࠥำฮ๋ࠢฮฺ็๊าࠢฯ้๏฿ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦอ๋อࠣฮ฾๎ฯࠡฮ่๎฾ࠦวๅว฼ำฬีวหࠢศ่๎่ࠦื฻ํอࠥะหษ์อࠤฬ๊ศา่ส้ัࠦฟࠨṅ"))
	if T4TGmZ9XWAzONaKygic:
		BcMl3XdLS0zmK1jPvDJANfYH = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࡚ࡲࡶࡧછ")
		if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(GmSzRNvTVLPZthXp6DjK0):
			try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(GmSzRNvTVLPZthXp6DjK0)
			except: BcMl3XdLS0zmK1jPvDJANfYH = q0JfWbP8vACLxSNIncpOXkR6j(u"ࡆࡢ࡮ࡶࡩજ")
		if showDialogs:
			if BcMl3XdLS0zmK1jPvDJANfYH: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࠩṆ"),OARzhnB9o7uYvQGFaIcZ(u"ࠩࠪṇ"),GGTRaYBDeNyI25zlF(u"ࠪࠫṈ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫṉ"))
			else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠬ࠭Ṋ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࠧṋ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠨṌ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨṍ"))
	return
def aBUopDxT6qikPfQmt4nC3Vd():
	rrXHNg2IwUsxLQd()
	LNj70iPQDFH6n = fQ6kvwg1FrYAzXjbLT.getSetting(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨṎ"))
	qNEnDMwm1Vfastx2ZkpRh = {}
	qNEnDMwm1Vfastx2ZkpRh[V391t7nQWUBR5euCkJ(u"ࠪࡅ࡚࡚ࡏࠨṏ")] = Vv0lSjAOHLfMnam3wtdor(u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪṐ")
	qNEnDMwm1Vfastx2ZkpRh[tKVplxqYIdngGF6TZkXeb2PiwfME(u"࡙ࠬࡔࡐࡒࠪṑ")] = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬṒ")
	qNEnDMwm1Vfastx2ZkpRh[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨṓ")] = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩṔ")+str(iiKkCMqUwSWmAvcQ1YpT69l/gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠸࠳ਠ"))+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࠣำ็๐โสࠢไๆ฼࠭ṕ")
	xbA62pwrsoca1 = qNEnDMwm1Vfastx2ZkpRh[LNj70iPQDFH6n]
	Df3p8YoF4GVj1bShqTQk5z0Wn = GjZltWoCxuIwNfQ7EH9(HMO0QciekqVpLKmA(u"ࠪࠫṖ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"่ࠫอิࠡࠩṗ")+str(iiKkCMqUwSWmAvcQ1YpT69l/dxAs4otSE98YmZnKy2iwRCB(u"࠹࠴ਡ"))+v7reLlOXCgD5pZ14w2tUA(u"ࠬࠦฯใ์ๅอࠬṘ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬṙ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠧฦ์ๅหๆࠦใศ็็ࠫṚ"),xbA62pwrsoca1,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫṛ"))
	if Df3p8YoF4GVj1bShqTQk5z0Wn==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠴ਢ"): sGEcRuYnN2VO7x9A = xxBJoKG54uwQ(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪṜ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==HMO0QciekqVpLKmA(u"࠶ਣ"): sGEcRuYnN2VO7x9A = IJ6VkihabRm(u"ࠪࡅ࡚࡚ࡏࠨṝ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==xxBJoKG54uwQ(u"࠸ਤ"): sGEcRuYnN2VO7x9A = uhOkAKtLVv4XTy1nWE6(u"ࠫࡘ࡚ࡏࡑࠩṞ")
	else: sGEcRuYnN2VO7x9A = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࠭ṟ")
	if sGEcRuYnN2VO7x9A:
		fQ6kvwg1FrYAzXjbLT.setSetting(IJ6VkihabRm(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬṠ"),sGEcRuYnN2VO7x9A)
		b9L8a3N4Rq2 = qNEnDMwm1Vfastx2ZkpRh[sGEcRuYnN2VO7x9A]
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࠨṡ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࠩṢ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࠪṣ"),b9L8a3N4Rq2)
	return
def vvUgmO9zIrTM2ALs8c6dj7ZWYaJ():
	qNEnDMwm1Vfastx2ZkpRh = {}
	qNEnDMwm1Vfastx2ZkpRh[xxBJoKG54uwQ(u"ࠪࡅ࡚࡚ࡏࠨṤ")] = HMO0QciekqVpLKmA(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠศๆอ่็อฦ๋ࠢํ฽๊๊࠺ࠡࠩṥ")
	qNEnDMwm1Vfastx2ZkpRh[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬࡇࡓࡌࠩṦ")] = zOZvXaebGNwHKfjRA(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็࠻ࠢࠪṧ")
	qNEnDMwm1Vfastx2ZkpRh[iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࡔࡖࡒࡔࠬṨ")] = DKqQekNtF6WlJLhBP9M5ca(u"ࠨีํีๆืࠠࡅࡐࡖࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫṩ")
	o1r6N42wHyOpvjqEf = fQ6kvwg1FrYAzXjbLT.getSetting(qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩṪ"))
	LNj70iPQDFH6n = fQ6kvwg1FrYAzXjbLT.getSetting(vkMRnTNV9jFm(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ṫ"))
	xbA62pwrsoca1 = qNEnDMwm1Vfastx2ZkpRh[LNj70iPQDFH6n]+o1r6N42wHyOpvjqEf
	Df3p8YoF4GVj1bShqTQk5z0Wn = GjZltWoCxuIwNfQ7EH9(v7reLlOXCgD5pZ14w2tUA(u"ࠫࠬṬ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪṭ"),DDS79jdWzLtE(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬṮ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧฦ์ๅหๆࠦใศ็็ࠫṯ"),xbA62pwrsoca1,GGTRaYBDeNyI25zlF(u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬṰ"))
	if Df3p8YoF4GVj1bShqTQk5z0Wn==V391t7nQWUBR5euCkJ(u"࠰ਥ"): sGEcRuYnN2VO7x9A = zOZvXaebGNwHKfjRA(u"ࠩࡄࡗࡐ࠭ṱ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==Vv0lSjAOHLfMnam3wtdor(u"࠲ਦ"): sGEcRuYnN2VO7x9A = uhOkAKtLVv4XTy1nWE6(u"ࠪࡅ࡚࡚ࡏࠨṲ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==qNZKwi2M1S4fBzGQYrmPnea(u"࠴ਧ"): sGEcRuYnN2VO7x9A = Vv0lSjAOHLfMnam3wtdor(u"ࠫࡘ࡚ࡏࡑࠩṳ")
	if Df3p8YoF4GVj1bShqTQk5z0Wn in [DDS79jdWzLtE(u"࠴਩"),vkMRnTNV9jFm(u"࠴ਨ")]:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬṴ"),v7reLlOXCgD5pZ14w2tUA(u"࠭ำ๋ำไี࠿ࠦࠧṵ")+aaAosTOK3Uegui0dNBIqDEy[DDS79jdWzLtE(u"࠶ਪ")],HMO0QciekqVpLKmA(u"ࠧิ์ิๅึࡀࠠࠨṶ")+aaAosTOK3Uegui0dNBIqDEy[Vv0lSjAOHLfMnam3wtdor(u"࠶ਫ")],iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࠩṷ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨṸ"))
		if T4TGmZ9XWAzONaKygic==Vv0lSjAOHLfMnam3wtdor(u"࠱ਬ"): cQ8GVSxAC9 = aaAosTOK3Uegui0dNBIqDEy[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠱ਭ")]
		else: cQ8GVSxAC9 = aaAosTOK3Uegui0dNBIqDEy[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠳ਮ")]
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠵ਯ"): cQ8GVSxAC9 = GGTRaYBDeNyI25zlF(u"ࠪࠫṹ")
	else: sGEcRuYnN2VO7x9A = DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠬṺ")
	if sGEcRuYnN2VO7x9A:
		fQ6kvwg1FrYAzXjbLT.setSetting(zOZvXaebGNwHKfjRA(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨṻ"),sGEcRuYnN2VO7x9A)
		fQ6kvwg1FrYAzXjbLT.setSetting(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭Ṽ"),cQ8GVSxAC9)
		b9L8a3N4Rq2 = qNEnDMwm1Vfastx2ZkpRh[sGEcRuYnN2VO7x9A]+cQ8GVSxAC9
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(GGTRaYBDeNyI25zlF(u"ࠧࠨṽ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨࠩṾ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࠪṿ"),b9L8a3N4Rq2)
	return
def INOLAQ1fEX2n7CYH0WwyDc4KSF5Z():
	LNj70iPQDFH6n = fQ6kvwg1FrYAzXjbLT.getSetting(OARzhnB9o7uYvQGFaIcZ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨẀ"))
	qNEnDMwm1Vfastx2ZkpRh = {}
	qNEnDMwm1Vfastx2ZkpRh[iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࡆ࡛ࡔࡐࠩẁ")] = HMO0QciekqVpLKmA(u"ࠬอไษำ๋็ุ๐ࠠศๆอ่็อฦ๋ࠢฯห์ุࠠๅๆ฼้้࠭Ẃ")
	qNEnDMwm1Vfastx2ZkpRh[xxBJoKG54uwQ(u"࠭ࡁࡔࡍࠪẃ")] = vkMRnTNV9jFm(u"ࠧศๆหีํ้ำ๋ࠢึ๎฾๋ไࠡส฼ำࠥอไิ็สั๊ࠥ็ࠨẄ")
	qNEnDMwm1Vfastx2ZkpRh[IJ6VkihabRm(u"ࠨࡕࡗࡓࡕ࠭ẅ")] = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩส่อื่ไีํࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫẆ")
	xbA62pwrsoca1 = qNEnDMwm1Vfastx2ZkpRh[LNj70iPQDFH6n]
	Df3p8YoF4GVj1bShqTQk5z0Wn = GjZltWoCxuIwNfQ7EH9(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࠫẇ"),xxpPYJOnoAUrlBzyveui(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩẈ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫẉ"),Vv0lSjAOHLfMnam3wtdor(u"࠭ล๋ไสๅ้ࠥวๆๆࠪẊ"),xbA62pwrsoca1,L91nVzxH4hYrgPDsOuljXd0J(u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪẋ"))
	if Df3p8YoF4GVj1bShqTQk5z0Wn==V391t7nQWUBR5euCkJ(u"࠴ਰ"): sGEcRuYnN2VO7x9A = IJ6VkihabRm(u"ࠨࡃࡖࡏࠬẌ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==V391t7nQWUBR5euCkJ(u"࠶਱"): sGEcRuYnN2VO7x9A = DKqQekNtF6WlJLhBP9M5ca(u"ࠩࡄ࡙࡙ࡕࠧẍ")
	elif Df3p8YoF4GVj1bShqTQk5z0Wn==vkMRnTNV9jFm(u"࠸ਲ"): sGEcRuYnN2VO7x9A = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡗ࡙ࡕࡐࠨẎ")
	else: sGEcRuYnN2VO7x9A = q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࠬẏ")
	if sGEcRuYnN2VO7x9A:
		fQ6kvwg1FrYAzXjbLT.setSetting(Vv0lSjAOHLfMnam3wtdor(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪẐ"),sGEcRuYnN2VO7x9A)
		b9L8a3N4Rq2 = qNEnDMwm1Vfastx2ZkpRh[sGEcRuYnN2VO7x9A]
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠧẑ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࠨẒ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨࠩẓ"),b9L8a3N4Rq2)
	return
def y97dvB3rjq4():
	XXYOVRlPJd5F9UjLG = fQ6kvwg1FrYAzXjbLT.getSetting(IJ6VkihabRm(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẔ"))
	if XXYOVRlPJd5F9UjLG==DDS79jdWzLtE(u"ࠪࡗ࡙ࡕࡐࠨẕ"): header = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊ะ่ใใࠪẖ")
	else: header = fcIm8tvxlXZsaEY3bwuG4B(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥแฺๆࠪẗ")
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(GGTRaYBDeNyI25zlF(u"࠭ࠧẘ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧฦ์ๅหๆ࠭ẙ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨฬไ฽๏๊ࠧẚ"),header,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭ẛ"))
	if T4TGmZ9XWAzONaKygic==-d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠱ਲ਼"): return
	elif T4TGmZ9XWAzONaKygic:
		fQ6kvwg1FrYAzXjbLT.setSetting(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪẜ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࡆ࡛ࡔࡐࠩẝ"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬ࠭ẞ"),IJ6VkihabRm(u"࠭ࠧẟ"),ZpH2IWt7veyFobTsAnhi41(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪẠ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠨฬ่ࠤฯ็ู๋ๆࠣฮำุ๊็ࠢส่็๎วว็ࠪạ"))
	else:
		fQ6kvwg1FrYAzXjbLT.setSetting(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẢ"),OARzhnB9o7uYvQGFaIcZ(u"ࠪࡗ࡙ࡕࡐࠨả"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠬẤ"),Vv0lSjAOHLfMnam3wtdor(u"ࠬ࠭ấ"),OARzhnB9o7uYvQGFaIcZ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩẦ"),ZpH2IWt7veyFobTsAnhi41(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩầ"))
	return
def z6ANjDq4rxkMcFtQsSLKo0hOJu72(OO1XlVPzfQrMTmJv):
	if OO1XlVPzfQrMTmJv!=V391t7nQWUBR5euCkJ(u"ࠨࠩẨ"):
		OO1XlVPzfQrMTmJv = mL8hMBHF5CjbJk(OO1XlVPzfQrMTmJv)
		OO1XlVPzfQrMTmJv = OO1XlVPzfQrMTmJv.decode(fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࡸࡸ࡫࠾ࠧẩ")).encode(zOZvXaebGNwHKfjRA(u"ࠪࡹࡹ࡬࠸ࠨẪ"))
		OXo0Ic9v7KUEYDg = uhOkAKtLVv4XTy1nWE6(u"࠲࠲࠴࠴࠸਴")
		b6zelCX9S2f = yOuHBDmPps3vd24cnLagiK0.Window(OXo0Ic9v7KUEYDg)
		b6zelCX9S2f.getControl(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠵࠴࠵ਵ")).setLabel(OO1XlVPzfQrMTmJv)
	return
YfAHwiz7EpvVJycGTLBoDX = [
			 q0JfWbP8vACLxSNIncpOXkR6j(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࠨࠩࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤẫ")
			,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨẬ")
			,IJ6VkihabRm(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨậ")
			,Vv0lSjAOHLfMnam3wtdor(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩẮ")
			,zOZvXaebGNwHKfjRA(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩắ")
			,dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫẰ")
			,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩằ")+DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠨ࠭Ẳ")+dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫẳ")
			,zOZvXaebGNwHKfjRA(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩẴ")
			,DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪẵ")
			,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩẶ")
			,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡡࡢࡣࡤ࡞ࠨặ")
			,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨẸ")
			]
def kRDxqrH4mNFAyIcbsO7z(ZmSt0LenHKEjq2BXQTz84vCO):
	if tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩẹ") in ZmSt0LenHKEjq2BXQTz84vCO and a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪẺ") in ZmSt0LenHKEjq2BXQTz84vCO: return OARzhnB9o7uYvQGFaIcZ(u"ࡕࡴࡸࡩઝ")
	for OO1XlVPzfQrMTmJv in YfAHwiz7EpvVJycGTLBoDX:
		if OO1XlVPzfQrMTmJv in ZmSt0LenHKEjq2BXQTz84vCO: return fcIm8tvxlXZsaEY3bwuG4B(u"ࡖࡵࡹࡪઞ")
	return a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡉࡥࡱࡹࡥટ")
def xOpgnaD7EPrd86JkfiURXVG(data):
	data = data.replace(L91nVzxH4hYrgPDsOuljXd0J(u"࠭࡜ࡳ࡞ࡱࠫẻ")+KbL94nDHufSF0VcO2Nk3(u"࠸࠵ਸ਼")*V391t7nQWUBR5euCkJ(u"ࠧࠡࠩẼ")+IJ6VkihabRm(u"ࠨ࡞ࡵࡠࡳ࠭ẽ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࡟ࡶࡡࡴࠧẾ"))
	data = data.replace(fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡠࡳ࠭ế")+dxAs4otSE98YmZnKy2iwRCB(u"࠹࠶਷")*DDS79jdWzLtE(u"ࠫࠥ࠭Ề")+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡢࡲ࡝ࡰࠪề"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭࡜ࡳ࡞ࡱࠫỂ"))
	data = data.replace(xxBJoKG54uwQ(u"ࠧ࡝ࡰࠪể")+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠺࠷ਸ")*GGTRaYBDeNyI25zlF(u"ࠨࠢࠪỄ")+p1lrNRIXqLQJznH6O(u"ࠩ࡟ࡲࠬễ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡠࡳ࠭Ệ"))
	data = data.replace(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡡࡴࠧệ")+xxpPYJOnoAUrlBzyveui(u"࠵࠲਺")*gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࠦࠧỈ"),zOZvXaebGNwHKfjRA(u"࠭࡜࡯ࠩỉ")+GGTRaYBDeNyI25zlF(u"࠹࠱ਹ")*p1lrNRIXqLQJznH6O(u"ࠧࠡࠩỊ"))
	data = data.replace(V391t7nQWUBR5euCkJ(u"ࠨࠢ࠿࡫ࡪࡴࡥࡳࡣ࡯ࡂ࠿ࠦࠧị"),HMO0QciekqVpLKmA(u"ࠩ࠽ࠤࠬỌ"))
	BF8XfchlgKmOE0ru2 = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠫọ")
	for ZmSt0LenHKEjq2BXQTz84vCO in data.splitlines():
		WQkZeCHGAfSLTrEgo0FRvaj = QPuHKNAT4jmCRg.findall(xxpPYJOnoAUrlBzyveui(u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠭ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪỎ"),ZmSt0LenHKEjq2BXQTz84vCO,QPuHKNAT4jmCRg.DOTALL)
		if WQkZeCHGAfSLTrEgo0FRvaj: ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(WQkZeCHGAfSLTrEgo0FRvaj[p1lrNRIXqLQJznH6O(u"࠱਻")],OARzhnB9o7uYvQGFaIcZ(u"ࠬ࠭ỏ"))
		BF8XfchlgKmOE0ru2 += uhOkAKtLVv4XTy1nWE6(u"࠭࡜࡯ࠩỐ")+ZmSt0LenHKEjq2BXQTz84vCO
	return BF8XfchlgKmOE0ru2
def EEBPeLvbq5CFaniTKgcj6(vsbZznoeIiYB49ajS8g5E6KGpw):
	if HMO0QciekqVpLKmA(u"ࠧࡐࡎࡇࠫố") in vsbZznoeIiYB49ajS8g5E6KGpw:
		c9cCYkDrq7 = aAnplEuShqTCBUg0k2y536ONrseGb
		header = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨỒ")
	else:
		c9cCYkDrq7 = ZFyXrxgYWeMS3RGsD670pb
		header = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩồ")
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(v7reLlOXCgD5pZ14w2tUA(u"ࠪࠫỔ"),OARzhnB9o7uYvQGFaIcZ(u"ࠫࠬổ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࠭Ỗ"),header,DKqQekNtF6WlJLhBP9M5ca(u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩỗ"))
	if T4TGmZ9XWAzONaKygic!=L91nVzxH4hYrgPDsOuljXd0J(u"࠳਼"): return
	eVE8l4MBNgG,K0XWzFpPsn1JGoxZVr6gDali2eE = [],tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠳਽")
	size,count = jGA1fuPNEcDJC7TFb9xhO30R(c9cCYkDrq7)
	file = open(c9cCYkDrq7,zOZvXaebGNwHKfjRA(u"ࠧࡳࡤࠪỘ"))
	if size>zOZvXaebGNwHKfjRA(u"࠶࠶࠰࠳࠲࠳ਿ"): file.seek(-V391t7nQWUBR5euCkJ(u"࠵࠵࠶࠱࠱࠲ਾ"),YcJmC0W43u5idIELnHTU2XSsMPNt.SEEK_END)
	data = file.read()
	file.close()
	if Nnxm30dfoBWRYpIC7KsQGl: data = data.decode(vkMRnTNV9jFm(u"ࠨࡷࡷࡪ࠽࠭ộ"))
	data = xOpgnaD7EPrd86JkfiURXVG(data)
	I7Q0GxoOc5ECkY6zfjhg = data.split(OARzhnB9o7uYvQGFaIcZ(u"ࠩ࡟ࡲࠬỚ"))
	for ZmSt0LenHKEjq2BXQTz84vCO in reversed(I7Q0GxoOc5ECkY6zfjhg):
		kW8mqOVgUSeMnzZFHTC = kRDxqrH4mNFAyIcbsO7z(ZmSt0LenHKEjq2BXQTz84vCO)
		if kW8mqOVgUSeMnzZFHTC: continue
		ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡣࠬớ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪỜ"))
		ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬờ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࡇࡕࡖࡔࡘ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩỞ"))
		h7BTtFfSInAwidQkL30u6j = IJ6VkihabRm(u"ࠧࠨở")
		vtxmRiy5SF = QPuHKNAT4jmCRg.findall(Vv0lSjAOHLfMnam3wtdor(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨỠ"),ZmSt0LenHKEjq2BXQTz84vCO,QPuHKNAT4jmCRg.DOTALL)
		if vtxmRiy5SF:
			ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(vtxmRiy5SF[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠰ੁ")][u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠰ੁ")],vtxmRiy5SF[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠰ੁ")][u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠷ੀ")]).replace(vtxmRiy5SF[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠰ੁ")][v7reLlOXCgD5pZ14w2tUA(u"࠳ੂ")],zOZvXaebGNwHKfjRA(u"ࠩࠪỡ"))
			h7BTtFfSInAwidQkL30u6j = vtxmRiy5SF[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠳੄")][u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠳੃")]
		else:
			vtxmRiy5SF = QPuHKNAT4jmCRg.findall(xxpPYJOnoAUrlBzyveui(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪỢ"),ZmSt0LenHKEjq2BXQTz84vCO,QPuHKNAT4jmCRg.DOTALL)
			if vtxmRiy5SF:
				ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(vtxmRiy5SF[HMO0QciekqVpLKmA(u"࠵੆")][vkMRnTNV9jFm(u"࠵੅")],v7reLlOXCgD5pZ14w2tUA(u"ࠫࠬợ"))
				h7BTtFfSInAwidQkL30u6j = vtxmRiy5SF[HMO0QciekqVpLKmA(u"࠶ੇ")][HMO0QciekqVpLKmA(u"࠶ੇ")]
		if h7BTtFfSInAwidQkL30u6j: ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(h7BTtFfSInAwidQkL30u6j,zOZvXaebGNwHKfjRA(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨỤ")+h7BTtFfSInAwidQkL30u6j+KbL94nDHufSF0VcO2Nk3(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨụ"))
		eVE8l4MBNgG.append(ZmSt0LenHKEjq2BXQTz84vCO)
		if len(str(eVE8l4MBNgG))>ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠵࠱࠳࠳࠴ੈ"): break
	eVE8l4MBNgG = reversed(eVE8l4MBNgG)
	xLED2NpoPZXHf = DKqQekNtF6WlJLhBP9M5ca(u"ࠧ࡝ࡰࠪỦ").join(eVE8l4MBNgG)
	qQL7e23RtCg4xOpf(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨ࡮ࡨࡪࡹ࠭ủ"),xxBJoKG54uwQ(u"ࠩลาึࠦริูิࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊࠭Ứ"),xLED2NpoPZXHf,IJ6VkihabRm(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ứ"))
	return
def zmM7RtsN51LkF392XeKqIByOSA():
	SxTY7bIGWUyakPl3 = open(chVmOk3KRSaCuDM,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡷࡨࠧỪ")).read()
	if Nnxm30dfoBWRYpIC7KsQGl: SxTY7bIGWUyakPl3 = SxTY7bIGWUyakPl3.decode(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡻࡴࡧ࠺ࠪừ"))
	SxTY7bIGWUyakPl3 = SxTY7bIGWUyakPl3.replace(xxBJoKG54uwQ(u"࠭࡜ࡵࠩỬ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠩử"))
	BwiXRqKVEj = QPuHKNAT4jmCRg.findall(qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࠪࡹࡠࡩ࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩỮ"),SxTY7bIGWUyakPl3,QPuHKNAT4jmCRg.DOTALL)
	for ZmSt0LenHKEjq2BXQTz84vCO in BwiXRqKVEj:
		SxTY7bIGWUyakPl3 = SxTY7bIGWUyakPl3.replace(ZmSt0LenHKEjq2BXQTz84vCO,qNZKwi2M1S4fBzGQYrmPnea(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬữ")+ZmSt0LenHKEjq2BXQTz84vCO+V391t7nQWUBR5euCkJ(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬỰ"))
	BwEG5gzkVsJcCRaQyhX4IqSHx0lnO(IJ6VkihabRm(u"ࠫฬ๊ส฻์ํีฬะࠠศๆฦา๏ืษࠡใํࠤฬ๊ศาษ่ะࠬự"),SxTY7bIGWUyakPl3)
	return
def nOl7pCKWe3FtdSf():
	GhpNfPVMB2uRnqasFL6K = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬฮูืࠢส่ศุัศำࠣ฽้๏ࠠศๆิ๎๊๎สࠡๅ๋๊ฯื่ๅࠢอ์ๆืࠠฦ็ๆห๋๐ษࠡฬๅำ๏๋้ࠠฬฦา๏ืࠠศๆไ๎ิ๐่๊๊ࠡิ์ࠦวๅลีีฬื่ࠠ์ࠣห้ษำ่็ࠣ์ฬ๊ราไสู้๋ࠥࠡส฼ฺࠥ๎ใศๆอห้๐ࠧỲ")
	fl57MHCK8LhbtieNY0QUck4AO = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ไหไา๎๊ࠦวๅใํำ๏๎ࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์่๎๋่ࠦๅฬฦา๏ื็ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํืฬืࠠ࠯ࠢฦ้ฬูࠦะหࠣหุํๅࠡ็อฮฬ๊๊สࠢไ๋ีํࠠหไ๋้ࠥฮสฮำํ็ࠥอไโ์า๎ํࠦศ้ไอࠤฬ้ศา่๊ࠢࠥ๎โหࠢสุ่ํๅࠡษ็์ฬำฯࠡ࠰ࠣว๊อࠠศๆึ๋๊ࠦวๅล฼่๎่ࠦศๆฦืๆ๊ࠠโ้๋ࠤ๏ำัไࠢส่ๆ๐ฯ๋๊ࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬว้ࠠๆๆ๊ࠥฮโโิฬࠤ่ฮ๊าหࠪỳ")
	IIEUd7xqAfnlYvgtaCMQ5h = KbL94nDHufSF0VcO2Nk3(u"ࠧฤ็สࠤฬ๊ราไส้ࠥ็็๋ࠢอืฯิฯๆࠢ็่ฯ่ฯ๋็ࠣ์ฬ๊สฤะํีࠥ๎ไไ่ࠣฬ๊่ฯศำࠣ฽ิีࠠศๆฮ์ฬ์๊๊ࠡส่ิ่ววไࠣ࠲๋ࠥหๅษࠣี็๋ࠠ࠶࠶࠷ࠤฯ฿ๆ๋ࠢ࠸ࠤิ่ววไࠣ์ࠥ࠺࠴ࠡอส๊๏ฯࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤอำำษࠢสืฯิฯศ็ๆࠤ้๊ำ่็ࠣห้๐ๅ๋่ࠣวํࠦำ่็ࠣห้๐ำศำࠪỴ")
	qNEnDMwm1Vfastx2ZkpRh = GhpNfPVMB2uRnqasFL6K+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨ࠼ࠣࠫỵ")+fl57MHCK8LhbtieNY0QUck4AO+Vv0lSjAOHLfMnam3wtdor(u"ࠩࠣ࠲ࠥ࠭Ỷ")+IIEUd7xqAfnlYvgtaCMQ5h
	qQL7e23RtCg4xOpf(HMO0QciekqVpLKmA(u"ࠪࡧࡪࡴࡴࡦࡴࠪỷ"),ddK4MmwpX5oG(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧỸ"),qNEnDMwm1Vfastx2ZkpRh,GGTRaYBDeNyI25zlF(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨỹ"))
	return
def xWaZr7lMs6teC8(type,qNEnDMwm1Vfastx2ZkpRh,showDialogs=d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡘࡷࡻࡥઠ"),url=lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࠧỺ"),oBQqw316KAIpOdr7R0LxkZNW5lG4y=xxpPYJOnoAUrlBzyveui(u"ࠧࠨỻ"),OO1XlVPzfQrMTmJv=v7reLlOXCgD5pZ14w2tUA(u"ࠨࠩỼ"),MqJ14AQVPkiX6=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࠪỽ")):
	voNuyVHA04CIM5DZ7dnti8eX = GGTRaYBDeNyI25zlF(u"࡙ࡸࡵࡦડ")
	if not x9N7DKVT1rjsPmlieqQ8HJgU(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫỾ")):
		if showDialogs:
			sFgn2pv4XGldbeL7IJWHy = (q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫฬ๊ำุำ࠽ࠫỿ") in qNEnDMwm1Vfastx2ZkpRh and p1lrNRIXqLQJznH6O(u"ࠬอไๆๅส๊࠿࠭ἀ") in qNEnDMwm1Vfastx2ZkpRh and xxBJoKG54uwQ(u"࠭วๅ็็ๅ࠿࠭ἁ") in qNEnDMwm1Vfastx2ZkpRh and V391t7nQWUBR5euCkJ(u"ࠧศๆั฻ศ࠭ἂ") in qNEnDMwm1Vfastx2ZkpRh and u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨษ็ฺ้ีั࠻ࠩἃ") in qNEnDMwm1Vfastx2ZkpRh)
			if not sFgn2pv4XGldbeL7IJWHy: voNuyVHA04CIM5DZ7dnti8eX = C5JBeSxPzuskXi1ROnMHAmWp06dE7(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡦࡩࡳࡺࡥࡳࠩἄ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࠫἅ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࠬἆ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอࠩἇ"),qNEnDMwm1Vfastx2ZkpRh.replace(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭࡜࡝ࡰࠪἈ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧ࡝ࡰࠪἉ")))
	elif showDialogs:
		qNEnDMwm1Vfastx2ZkpRh = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨ࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษࠨἊ")
		yerJlVUT9cZ = C5JBeSxPzuskXi1ROnMHAmWp06dE7(xxpPYJOnoAUrlBzyveui(u"ࠩࡦࡩࡳࡺࡥࡳࠩἋ"),GGTRaYBDeNyI25zlF(u"ࠪࠫἌ"),DDS79jdWzLtE(u"ࠫࠬἍ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬἎ")+lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࠠࠡ࠳࠲࠹ࠬἏ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬἐ"))
		ccLm294lXz3f7yv = C5JBeSxPzuskXi1ROnMHAmWp06dE7(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨἑ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࠪἒ"),OARzhnB9o7uYvQGFaIcZ(u"ࠪࠫἓ"),vkMRnTNV9jFm(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫἔ")+L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࠦࠠ࠳࠱࠸ࠫἕ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ἖"))
		DiHs7WXFnUdjRSo = C5JBeSxPzuskXi1ROnMHAmWp06dE7(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡤࡧࡱࡸࡪࡸࠧ἗"),KbL94nDHufSF0VcO2Nk3(u"ࠨࠩἘ"),p1lrNRIXqLQJznH6O(u"ࠩࠪἙ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪἚ")+dxAs4otSE98YmZnKy2iwRCB(u"ࠫࠥࠦ࠳࠰࠷ࠪἛ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪἜ"))
		yha5TjcKmYALOCulEtgpoRzk7x = C5JBeSxPzuskXi1ROnMHAmWp06dE7(GGTRaYBDeNyI25zlF(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ἕ"),OARzhnB9o7uYvQGFaIcZ(u"ࠧࠨ἞"),v7reLlOXCgD5pZ14w2tUA(u"ࠨࠩ἟"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩἠ")+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠤࠥ࠺࠯࠶ࠩἡ"),xxpPYJOnoAUrlBzyveui(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩἢ"))
		voNuyVHA04CIM5DZ7dnti8eX = C5JBeSxPzuskXi1ROnMHAmWp06dE7(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬἣ"),HMO0QciekqVpLKmA(u"࠭ࠧἤ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࠨἥ"),uhOkAKtLVv4XTy1nWE6(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨἦ")+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࠣࠤ࠺࠵࠵ࠨἧ"),HMO0QciekqVpLKmA(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨἨ"))
	wn0kd1pEgfSy4YG = Dx3jCK6X7lktdiE(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠴࠴੉"),DKqQekNtF6WlJLhBP9M5ca(u"ࡌࡡ࡭ࡵࡨઢ"))
	T1B4xmfHMg6QSAnjEkbdCsoN5 = DKqQekNtF6WlJLhBP9M5ca(u"ࠫࡆ࡜࠺ࠡࠩἩ")+wn0kd1pEgfSy4YG+V391t7nQWUBR5euCkJ(u"ࠬ࠳ࠧἪ")+type
	RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h = IJ6VkihabRm(u"ࡕࡴࡸࡩત") if xxpPYJOnoAUrlBzyveui(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩἫ") in OO1XlVPzfQrMTmJv else HMO0QciekqVpLKmA(u"ࡆࡢ࡮ࡶࡩણ")
	if not voNuyVHA04CIM5DZ7dnti8eX:
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠨἬ"),ddK4MmwpX5oG(u"ࠨࠩἭ"),zOZvXaebGNwHKfjRA(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἮ"),IJ6VkihabRm(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ่࠭Ἧ"))
		return vkMRnTNV9jFm(u"ࡈࡤࡰࡸ࡫થ")
	E32m5lIvayA8KGcDuWXfqnBOiURt = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪἰ"))
	qNEnDMwm1Vfastx2ZkpRh += uhOkAKtLVv4XTy1nWE6(u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫἱ")+uVp7krjL48oWd3tqGYCRz5M+iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࠠ࠻࡞࡟ࡲࠬἲ")
	qNEnDMwm1Vfastx2ZkpRh += q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨἳ")+wn0kd1pEgfSy4YG+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧἴ")+Qk3Eo8cXgASw+dxAs4otSE98YmZnKy2iwRCB(u"ࠩࠣ࠾ࡡࡢ࡮ࠨἵ")
	qNEnDMwm1Vfastx2ZkpRh += q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨἶ")+E32m5lIvayA8KGcDuWXfqnBOiURt
	PPFwCokDceHzlibVnvsNUMgfyEau = tRibZg70df5IVmvGWwAXuM14lncz()
	PPFwCokDceHzlibVnvsNUMgfyEau = oF0Yr4V7Ic(PPFwCokDceHzlibVnvsNUMgfyEau)
	if PPFwCokDceHzlibVnvsNUMgfyEau: qNEnDMwm1Vfastx2ZkpRh += ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭ἷ")+PPFwCokDceHzlibVnvsNUMgfyEau
	if url: qNEnDMwm1Vfastx2ZkpRh += uhOkAKtLVv4XTy1nWE6(u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩἸ")+url
	if oBQqw316KAIpOdr7R0LxkZNW5lG4y: qNEnDMwm1Vfastx2ZkpRh += iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭Ἱ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y
	qNEnDMwm1Vfastx2ZkpRh += f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࠡ࠼࡟ࡠࡳ࠭Ἲ")
	if showDialogs: uFCykYQW68S(Vv0lSjAOHLfMnam3wtdor(u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧἻ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫἼ"))
	if MqJ14AQVPkiX6:
		xLED2NpoPZXHf = MqJ14AQVPkiX6
		if Nnxm30dfoBWRYpIC7KsQGl: xLED2NpoPZXHf = xLED2NpoPZXHf.encode(DDS79jdWzLtE(u"ࠪࡹࡹ࡬࠸ࠨἽ"))
		xLED2NpoPZXHf = jm9LDJTlXsqZM8EAygS26twWQ70.b64encode(xLED2NpoPZXHf)
	elif RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h:
		if uhOkAKtLVv4XTy1nWE6(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫἾ") in OO1XlVPzfQrMTmJv: HHFY8NC93Z1GfT = aAnplEuShqTCBUg0k2y536ONrseGb
		else: HHFY8NC93Z1GfT = ZFyXrxgYWeMS3RGsD670pb
		if not YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(HHFY8NC93Z1GfT):
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠬ࠭Ἷ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠧὀ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪὁ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ὂ"))
			return OARzhnB9o7uYvQGFaIcZ(u"ࡉࡥࡱࡹࡥદ")
		eVE8l4MBNgG,K0XWzFpPsn1JGoxZVr6gDali2eE = [],q0JfWbP8vACLxSNIncpOXkR6j(u"࠲੊")
		size,count = jGA1fuPNEcDJC7TFb9xhO30R(HHFY8NC93Z1GfT)
		file = open(HHFY8NC93Z1GfT,L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡵࡦࠬὃ"))
		if size>OARzhnB9o7uYvQGFaIcZ(u"࠶࠺࠶࠲࠱࠲ੌ"): file.seek(-L91nVzxH4hYrgPDsOuljXd0J(u"࠵࠹࠵࠷࠰࠱ੋ"),YcJmC0W43u5idIELnHTU2XSsMPNt.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(ZpH2IWt7veyFobTsAnhi41(u"ࠪࡹࡹ࡬࠸ࠨὄ"))
		data = xOpgnaD7EPrd86JkfiURXVG(data)
		I7Q0GxoOc5ECkY6zfjhg = data.splitlines()
		for ZmSt0LenHKEjq2BXQTz84vCO in reversed(I7Q0GxoOc5ECkY6zfjhg):
			kW8mqOVgUSeMnzZFHTC = kRDxqrH4mNFAyIcbsO7z(ZmSt0LenHKEjq2BXQTz84vCO)
			if kW8mqOVgUSeMnzZFHTC: continue
			vtxmRiy5SF = QPuHKNAT4jmCRg.findall(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫὅ"),ZmSt0LenHKEjq2BXQTz84vCO,QPuHKNAT4jmCRg.DOTALL)
			if vtxmRiy5SF:
				ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(vtxmRiy5SF[zOZvXaebGNwHKfjRA(u"࠶੎")][zOZvXaebGNwHKfjRA(u"࠶੎")],vtxmRiy5SF[zOZvXaebGNwHKfjRA(u"࠶੎")][Vv0lSjAOHLfMnam3wtdor(u"࠶੍")]).replace(vtxmRiy5SF[zOZvXaebGNwHKfjRA(u"࠶੎")][tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠲੏")],f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࠭὆"))
			else:
				vtxmRiy5SF = QPuHKNAT4jmCRg.findall(ZpH2IWt7veyFobTsAnhi41(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭὇"),ZmSt0LenHKEjq2BXQTz84vCO,QPuHKNAT4jmCRg.DOTALL)
				if vtxmRiy5SF: ZmSt0LenHKEjq2BXQTz84vCO = ZmSt0LenHKEjq2BXQTz84vCO.replace(vtxmRiy5SF[tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠲ੑ")][HMO0QciekqVpLKmA(u"࠲੐")],dxAs4otSE98YmZnKy2iwRCB(u"ࠧࠨὈ"))
			eVE8l4MBNgG.append(ZmSt0LenHKEjq2BXQTz84vCO)
			if len(str(eVE8l4MBNgG))>V391t7nQWUBR5euCkJ(u"࠴࠶࠶࠶࠰࠱੒"): break
		eVE8l4MBNgG = reversed(eVE8l4MBNgG)
		xLED2NpoPZXHf = xxBJoKG54uwQ(u"ࠨ࡞ࡵࡠࡳ࠭Ὁ").join(eVE8l4MBNgG)
		xLED2NpoPZXHf = xLED2NpoPZXHf.encode(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࡸࡸ࡫࠾ࠧὊ"))
		xLED2NpoPZXHf = jm9LDJTlXsqZM8EAygS26twWQ70.b64encode(xLED2NpoPZXHf)
	else: xLED2NpoPZXHf = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࠫὋ")
	url = EGcFon0zR4mSL1[d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫὌ")][tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶੓")]
	E9ODYnfpm54GJTd2xRrV = {DDS79jdWzLtE(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭Ὅ"):T1B4xmfHMg6QSAnjEkbdCsoN5,KbL94nDHufSF0VcO2Nk3(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡥࠨ὎"):qNEnDMwm1Vfastx2ZkpRh,p1lrNRIXqLQJznH6O(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨ὏"):xLED2NpoPZXHf}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,GGTRaYBDeNyI25zlF(u"ࠨࡒࡒࡗ࡙࠭ὐ"),url,E9ODYnfpm54GJTd2xRrV,xxpPYJOnoAUrlBzyveui(u"ࠩࠪὑ"),xxpPYJOnoAUrlBzyveui(u"ࠪࠫὒ"),OARzhnB9o7uYvQGFaIcZ(u"ࠫࠬὓ"),KbL94nDHufSF0VcO2Nk3(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨὔ"))
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࠢࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠥ࠾ࠥ࠷ࠬࠨὕ") in Ht6Gg8lbciAd9FaUQVs: BcMl3XdLS0zmK1jPvDJANfYH = OARzhnB9o7uYvQGFaIcZ(u"ࡘࡷࡻࡥધ")
	else: BcMl3XdLS0zmK1jPvDJANfYH = p1lrNRIXqLQJznH6O(u"ࡋࡧ࡬ࡴࡧન")
	if showDialogs:
		if BcMl3XdLS0zmK1jPvDJANfYH:
			uFCykYQW68S(DDS79jdWzLtE(u"ࠧห็ࠣห้หัิษ็ࠫὖ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨส้ะฬำࠧὗ"))
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(V391t7nQWUBR5euCkJ(u"ࠩࠪ὘"),uhOkAKtLVv4XTy1nWE6(u"ࠪࠫὙ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡶࠪ὚"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬะๅࠡวิืฬ๊ࠠศๆิืฬ๊ษࠡส้ะฬำࠧὛ"))
		else:
			uFCykYQW68S(L91nVzxH4hYrgPDsOuljXd0J(u"࠭ไๅลึๅࠬ὜"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧโึ็ࠤๆ๐ࠠศๆศีุอไࠨὝ"))
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(p1lrNRIXqLQJznH6O(u"ࠨࠩ὞"),DDS79jdWzLtE(u"ࠩࠪὟ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ὠ"),p1lrNRIXqLQJznH6O(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩὡ"))
	return BcMl3XdLS0zmK1jPvDJANfYH
def UctAhZmGFMg0X3w():
	GhpNfPVMB2uRnqasFL6K = V391t7nQWUBR5euCkJ(u"ࠬ࠷࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠࡵࡧࡻࡸࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫὢ")
	fl57MHCK8LhbtieNY0QUck4AO = uhOkAKtLVv4XTy1nWE6(u"࠭࠱࠯ࠢࠣࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡว็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨὣ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(V391t7nQWUBR5euCkJ(u"ࠧࠨὤ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠩὥ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪὦ"),GhpNfPVMB2uRnqasFL6K+DDS79jdWzLtE(u"ࠪࡠࡳࡢ࡮ࠨὧ")+fl57MHCK8LhbtieNY0QUck4AO)
	GhpNfPVMB2uRnqasFL6K = ZpH2IWt7veyFobTsAnhi41(u"ࠫ࠷࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢࡦࡥࡳࡢࠧࡵࠢࡩ࡭ࡳࡪࠠࠣࡃࡵ࡭ࡦࡲࠢࠡࡨࡲࡲࡹࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡵ࡮࡭ࡳࠦࡡ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠪὨ")
	fl57MHCK8LhbtieNY0QUck4AO = KbL94nDHufSF0VcO2Nk3(u"ࠬ࠸࠮ࠡࠢࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแใ็ࠣฬฯเ๊๋ำࠣห้าไะࠢฮ้่ࠥๅࠡสอ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬὩ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࠧὪ"),xxpPYJOnoAUrlBzyveui(u"ࠧࠨὫ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧὬ"),GhpNfPVMB2uRnqasFL6K+IJ6VkihabRm(u"ࠩ࡟ࡲࡡࡴࠧὭ")+fl57MHCK8LhbtieNY0QUck4AO)
	GhpNfPVMB2uRnqasFL6K = V391t7nQWUBR5euCkJ(u"ࠪ࠷࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡦࡲࡲࡡ࠭ࡴࠡࡪࡤࡺࡪࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡶ࡫ࡩࡳࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡷ࡫ࡧࡪࡱࡱࡥࡱࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨὮ")
	fl57MHCK8LhbtieNY0QUck4AO = qNZKwi2M1S4fBzGQYrmPnea(u"ࠫ࠸࠴ࠠࠡࠢศิฬࠦไๆࠢํ็๋ࠦไะ์ๆࠤ้๎อส่ࠢๅฬะ๊ฮࠢ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋ๆุไฬࠤฬ๊ฬ฻ำสๅ๏ฯࠧὯ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(v7reLlOXCgD5pZ14w2tUA(u"ࠬ࠭ὰ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࠧά"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ὲ"),GhpNfPVMB2uRnqasFL6K+xxpPYJOnoAUrlBzyveui(u"ࠨ࡞ࡱࡠࡳ࠭έ")+fl57MHCK8LhbtieNY0QUck4AO)
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡦࡩࡳࡺࡥࡳࠩὴ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࠫή"),uhOkAKtLVv4XTy1nWE6(u"ࠫࠬὶ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬί"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪὸ")+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧ࡝ࡰ࡟ࡲࠬό")+DKqQekNtF6WlJLhBP9M5ca(u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨὺ"))
	if T4TGmZ9XWAzONaKygic==uhOkAKtLVv4XTy1nWE6(u"࠶੔"): EbUFPLiZ7x2Xl()
	return
def k2ZSMBawCL8eEzt0hbArmx():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠩࠪύ"),xxpPYJOnoAUrlBzyveui(u"ࠪࠫὼ"),GGTRaYBDeNyI25zlF(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧώ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ὾"))
	return
def zsrboPJhAxUZgpwVejHnLSQfI():
	qNEnDMwm1Vfastx2ZkpRh = L91nVzxH4hYrgPDsOuljXd0J(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭὿")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠨᾀ"),xxpPYJOnoAUrlBzyveui(u"ࠨࠩᾁ"),p1lrNRIXqLQJznH6O(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᾂ"),qNEnDMwm1Vfastx2ZkpRh)
	return
def wdfu72Jx8eWyVFjb():
	qNEnDMwm1Vfastx2ZkpRh = v7reLlOXCgD5pZ14w2tUA(u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧᾃ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxpPYJOnoAUrlBzyveui(u"ࠫࠬᾄ"),HMO0QciekqVpLKmA(u"ࠬ࠭ᾅ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᾆ"),qNEnDMwm1Vfastx2ZkpRh)
	return
def fBrWTYn2Gc90():
	qNEnDMwm1Vfastx2ZkpRh = xxpPYJOnoAUrlBzyveui(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫᾇ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(v7reLlOXCgD5pZ14w2tUA(u"ࠨࠩᾈ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࠪᾉ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᾊ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭ᾋ"),qNEnDMwm1Vfastx2ZkpRh)
	return
def shJ8PjmIVl6gOp2L1CbNy():
	qNEnDMwm1Vfastx2ZkpRh = dxAs4otSE98YmZnKy2iwRCB(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪᾌ")
	qQL7e23RtCg4xOpf(fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᾍ"),GGTRaYBDeNyI25zlF(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾎ"),qNEnDMwm1Vfastx2ZkpRh,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᾏ"))
	return
def V1K68rbwUBhjJfeoSX():
	GhpNfPVMB2uRnqasFL6K = fcIm8tvxlXZsaEY3bwuG4B(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪᾐ")
	fl57MHCK8LhbtieNY0QUck4AO = DKqQekNtF6WlJLhBP9M5ca(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬᾑ")
	IIEUd7xqAfnlYvgtaCMQ5h = DDS79jdWzLtE(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᾒ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬ࠭ᾓ"),OARzhnB9o7uYvQGFaIcZ(u"࠭ࠧᾔ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾕ"),GhpNfPVMB2uRnqasFL6K,fl57MHCK8LhbtieNY0QUck4AO,IIEUd7xqAfnlYvgtaCMQ5h)
	return
def rrXHNg2IwUsxLQd():
	fl57MHCK8LhbtieNY0QUck4AO = p1lrNRIXqLQJznH6O(u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩᾖ")
	fl57MHCK8LhbtieNY0QUck4AO += GGTRaYBDeNyI25zlF(u"ࠩ࡟ࡲࡡࡴࠧᾗ") + tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩᾘ") + str(VYn9o683LCcspE7Jew5gMQrZbj/iRTygNp4Lf36wQKlD2MHUhG7B(u"࠼࠰੕")/iRTygNp4Lf36wQKlD2MHUhG7B(u"࠼࠰੕")/Vv0lSjAOHLfMnam3wtdor(u"࠲࠵੖")/xxpPYJOnoAUrlBzyveui(u"࠴࠲੗")) + Vv0lSjAOHLfMnam3wtdor(u"ฺࠫࠥ็าࠩᾙ")
	fl57MHCK8LhbtieNY0QUck4AO += ddK4MmwpX5oG(u"ࠬࡢ࡮ࠨᾚ") + L91nVzxH4hYrgPDsOuljXd0J(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬᾛ") + str(kkvBdWcON7RZoMJDr0YjmLE1/zOZvXaebGNwHKfjRA(u"࠸࠳੘")/zOZvXaebGNwHKfjRA(u"࠸࠳੘")/v7reLlOXCgD5pZ14w2tUA(u"࠵࠸ਖ਼")) + vkMRnTNV9jFm(u"ࠧࠡ์๋้ࠬᾜ")
	fl57MHCK8LhbtieNY0QUck4AO += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ࡞ࡱࠫᾝ") + Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭ᾞ") + str(lu4xpkY5LFOm6t2In/vkMRnTNV9jFm(u"࠺࠵ਗ਼")/vkMRnTNV9jFm(u"࠺࠵ਗ਼")/KbL94nDHufSF0VcO2Nk3(u"࠷࠺ਜ਼")) + iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࠤ๏๎ๅࠨᾟ")
	fl57MHCK8LhbtieNY0QUck4AO += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡡࡴࠧᾠ") + u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧᾡ") + str(t7rXIzJfMLWRwaDeKhTq4C6dG/dxAs4otSE98YmZnKy2iwRCB(u"࠼࠰ੜ")/dxAs4otSE98YmZnKy2iwRCB(u"࠼࠰ੜ")) + iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࠠิษ฼อࠬᾢ")
	fl57MHCK8LhbtieNY0QUck4AO += zOZvXaebGNwHKfjRA(u"ࠧ࡝ࡰࠪᾣ") + IJ6VkihabRm(u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬᾤ") + str(oXSZ6AEbPukBvwKmyarstdWR5qz0/L91nVzxH4hYrgPDsOuljXd0J(u"࠶࠱੝")/L91nVzxH4hYrgPDsOuljXd0J(u"࠶࠱੝")) + d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࠣืฬ฿ษࠨᾥ")
	fl57MHCK8LhbtieNY0QUck4AO += qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡠࡳ࠭ᾦ") + uhOkAKtLVv4XTy1nWE6(u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬᾧ") + str(ooDaNCkx4c0FjJs/HMO0QciekqVpLKmA(u"࠷࠲ਫ਼")) + OARzhnB9o7uYvQGFaIcZ(u"ࠬࠦฯใ์ๅอࠬᾨ")
	fl57MHCK8LhbtieNY0QUck4AO += qNZKwi2M1S4fBzGQYrmPnea(u"࠭࡜࡯ࠩᾩ") + ddK4MmwpX5oG(u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩᾪ") + str(vfj1VHSBpIks9JhLGmr) + GGTRaYBDeNyI25zlF(u"ࠨࠢาๆ๏่ษࠨᾫ")
	fl57MHCK8LhbtieNY0QUck4AO += HMO0QciekqVpLKmA(u"ࠩ࡟ࡲࡡࡴࠧᾬ") + OARzhnB9o7uYvQGFaIcZ(u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧᾭ") + str(t7rXIzJfMLWRwaDeKhTq4C6dG/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")) + Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬᾮ") + str(lu4xpkY5LFOm6t2In/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")/vkMRnTNV9jFm(u"࠵࠸੠")) + Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫᾯ") + str(oXSZ6AEbPukBvwKmyarstdWR5qz0/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")) + uhOkAKtLVv4XTy1nWE6(u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪᾰ") + str(ooDaNCkx4c0FjJs/ZpH2IWt7veyFobTsAnhi41(u"࠸࠳੟")) + xxBJoKG54uwQ(u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩᾱ") + str(vfj1VHSBpIks9JhLGmr) + OARzhnB9o7uYvQGFaIcZ(u"ࠨࠢาๆ๏่ษࠨᾲ")
	qQL7e23RtCg4xOpf(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡵ࡭࡬࡮ࡴࠨᾳ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨᾴ"),fl57MHCK8LhbtieNY0QUck4AO,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ᾵"))
	return
def qY4xPg6AsJoVhj3rIXl0pSwWfL():
	qNEnDMwm1Vfastx2ZkpRh = ZpH2IWt7veyFobTsAnhi41(u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨᾶ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠧᾷ"),OARzhnB9o7uYvQGFaIcZ(u"ࠧࠨᾸ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᾹ"),qNEnDMwm1Vfastx2ZkpRh)
	return
def b0KNEgsmpWZdvDkTqU8BFYOcC6GIl():
	qNEnDMwm1Vfastx2ZkpRh = HMO0QciekqVpLKmA(u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪᾺ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠪࠫΆ"),uhOkAKtLVv4XTy1nWE6(u"ࠫࠬᾼ"),DDS79jdWzLtE(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᾽"),qNEnDMwm1Vfastx2ZkpRh)
	return
def yiNWojhaz8wZU2LM():
	qNEnDMwm1Vfastx2ZkpRh = ZpH2IWt7veyFobTsAnhi41(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪι")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxBJoKG54uwQ(u"ࠧࠨ᾿"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࠩ῀"),uhOkAKtLVv4XTy1nWE6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ῁"),qNEnDMwm1Vfastx2ZkpRh)
	return
def K2zlrWQfItFTHmhUSNuCkRe5AJg():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(uhOkAKtLVv4XTy1nWE6(u"ࠪࠫῂ"),ddK4MmwpX5oG(u"ࠫࠬῃ"),Vv0lSjAOHLfMnam3wtdor(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῄ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ῅"))
	ua95I6RK27wGQgmYXqc(OARzhnB9o7uYvQGFaIcZ(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧῆ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࡚ࡲࡶࡧ઩"))
	return
def LBbx75IPoEZ0rkRtfsaJ():
	qNEnDMwm1Vfastx2ZkpRh  = p1lrNRIXqLQJznH6O(u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪῇ")
	qNEnDMwm1Vfastx2ZkpRh += ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࠣ์๋ะ๊อห่ࠣ์ึวࠡษ็฽ฬฬโࠡใส๊์ࠦสใำํฬฬࠦฬๆ์฼ࠤู๊สฯั่๎ࠥฮั็ษ่ะ้่ࠥะ์่ࠣฬ๊ࠦิฬฺ๎฾๎ๆࠡษ็ำำ๎ไࠡๆฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡฯอํู๋ࠥࠡษึฮำีวๆࠩῈ")
	qNEnDMwm1Vfastx2ZkpRh += p1lrNRIXqLQJznH6O(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝แ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠧΈ")
	qNEnDMwm1Vfastx2ZkpRh += v7reLlOXCgD5pZ14w2tUA(u"ࠫࡡࡴไศ่๋ࠣีอࠠๅ่ࠣ๎า๊ࠠศๆุ่่๊ษ๊ࠡศ๊๊อࠠโไฺࠤุ๐โ้็ࠣฬส฻ไศฯࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡศ฽ฬ่ษࠡ็๋ห็฿ࠠศะิํ้ࠥว็ฬࠣฮ฾๋ไࠡีสฬ็อࠠษั๋๊๋ࠥิศๅ็ࠫῊ")
	qQL7e23RtCg4xOpf(vkMRnTNV9jFm(u"ࠬࡸࡩࡨࡪࡷࠫΉ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩῌ"),qNEnDMwm1Vfastx2ZkpRh,v7reLlOXCgD5pZ14w2tUA(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ῍"))
	qNEnDMwm1Vfastx2ZkpRh = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨษ็้ํอโฺࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫ῎")
	qNEnDMwm1Vfastx2ZkpRh += OARzhnB9o7uYvQGFaIcZ(u"ࠩ࡟ࡲࠬ῏")+dxAs4otSE98YmZnKy2iwRCB(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῐ")
	qNEnDMwm1Vfastx2ZkpRh += f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫࡡࡴ࡜࡯ࠩῑ")+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬอไะ๊็ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ῒ")
	qNEnDMwm1Vfastx2ZkpRh += L91nVzxH4hYrgPDsOuljXd0J(u"࠭࡜࡯ࠩΐ")+vkMRnTNV9jFm(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ู่ึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ῔")
	qNEnDMwm1Vfastx2ZkpRh += Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨ࡞ࡱࡠࡳ࠭῕")+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪῖ")
	qNEnDMwm1Vfastx2ZkpRh += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨῗ")
	qQL7e23RtCg4xOpf(qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࡷ࡯ࡧࡩࡶࠪῘ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῙ"),qNEnDMwm1Vfastx2ZkpRh,KbL94nDHufSF0VcO2Nk3(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩῚ"))
	return
def VE4q8kruF7QTGt2fX1KjmheY():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(DDS79jdWzLtE(u"ࠧࠨΊ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࠩ῜"),xxpPYJOnoAUrlBzyveui(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩ῝"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤำีๅศฬ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡩࡶࡷࡴ࠿࠵࠯ࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴร้ࠢหหึูวๅࠢส๎๊๐ไࠡษ็ํࠥษฯ็ษ๊ࠤࠥࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡆࡧ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ῞"))
	return
def eeCmjUOBLFfrbM64():
	rrXHNg2IwUsxLQd()
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(v7reLlOXCgD5pZ14w2tUA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ῟"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠭ῠ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠧῡ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣห้้วีࠢยࠫῢ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠨษ็็ฬฺ๋ࠠีิ฽ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤํ๋ำฮ้ࠣ๎฾๐ฯࠡีะฬࠥอไึใะหฯࠦๅ็ࠢส่ส์สา่อࠤ฾์ฯࠡษ็ัฬาษࠡว็๎์อ้ࠠษ็ุ้ำ๋ࠠฬ่ࠤฯ๊โศศํหࠥ฿ๆะࠢส๊ฯํวยࠢ฼้ึࠦวๅืไัฬะ้ࠠษ็ุ้ำࠠๅษࠣ๎฻ื้ࠠ็่็๋๊ࠦฮๆࠣฬ฾฼ࠠศๆุ่ฬ้ไࠨΰ"))
	if T4TGmZ9XWAzONaKygic==HMO0QciekqVpLKmA(u"࠵੡"):
		zKUEjGW1YecZHiyoPRal4LMQrvsX(L91nVzxH4hYrgPDsOuljXd0J(u"ࡔࡳࡷࡨપ"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࠪῤ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࠫῥ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣฬฬ๊ใศ็็ࠫῦ"),DDS79jdWzLtE(u"ࠬหะศࠢๆห๋ะฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศฯาࠤฬ๊ๅ้ษๅ฽ࠥ็ฬาสࠣห้๋่ใ฻ࠣห้ศๆࠡ࠰࠱࠲ࠥ๎รัษࠣห้๋ิไๆฬࠤู๊สๆำฬࠤๆหะ็ࠢสีุ๊ࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ั࠭ῧ"))
	return T4TGmZ9XWAzONaKygic
def rVwqOcjQa5zDPE(showDialogs=fcIm8tvxlXZsaEY3bwuG4B(u"ࡕࡴࡸࡩફ")):
	if not showDialogs: showDialogs = uhOkAKtLVv4XTy1nWE6(u"ࡖࡵࡹࡪબ")
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,v7reLlOXCgD5pZ14w2tUA(u"࠭ࡇࡆࡖࠪῨ"),xxpPYJOnoAUrlBzyveui(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭Ῡ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࠩῪ"),ddK4MmwpX5oG(u"ࠩࠪΎ"),vkMRnTNV9jFm(u"ࡉࡥࡱࡹࡥભ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠪࠫῬ"),xxpPYJOnoAUrlBzyveui(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ῭"))
	if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
		i3CFzXYd8tlnch6UMu = qNZKwi2M1S4fBzGQYrmPnea(u"ࡊࡦࡲࡳࡦમ")
		nZkScXxgspimo41H36h = q9AltNyD2Q1uL()
		zRM3tZx2v6DjJU(HMO0QciekqVpLKmA(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ΅"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࠠࠡࠢࡋࡘ࡙ࡖࡓࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡐࡦࡨࡥ࡭࠼࡞ࠫ`")+nZkScXxgspimo41H36h+Vv0lSjAOHLfMnam3wtdor(u"ࠧ࡞ࠩ῰"))
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(zOZvXaebGNwHKfjRA(u"ࠨࠩ῱"),xxpPYJOnoAUrlBzyveui(u"ࠩࠪῲ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ῳ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨῴ"))
	else:
		i3CFzXYd8tlnch6UMu = lunVJF2G5bZMgTcCje0vaIB371SX(u"࡙ࡸࡵࡦય")
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ZpH2IWt7veyFobTsAnhi41(u"ࠬ࠭῵"),KbL94nDHufSF0VcO2Nk3(u"࠭ࠧῶ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪῷ"),xxBJoKG54uwQ(u"ࠨฮํำࠥาฯศࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡ์฼ู้้ࠦ็ัๆࠤํอไษำ้ห๊าࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬῸ"))
	if not i3CFzXYd8tlnch6UMu and showDialogs: KvrON73fF9WLckPBS2UEw()
	return i3CFzXYd8tlnch6UMu
def KvrON73fF9WLckPBS2UEw():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(V391t7nQWUBR5euCkJ(u"ࠩࠪΌ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠫῺ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧΏ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫῼ"))
	zztDMTj1Fcd2xLfpNr()
	return
def z4tZrfkMm92x3FQEv5dw1s6OJiXu(OO1XlVPzfQrMTmJv=IJ6VkihabRm(u"࠭ࠧ´")):
	RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h = zOZvXaebGNwHKfjRA(u"࡚ࡲࡶࡧર")
	if ddK4MmwpX5oG(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ῾") not in OO1XlVPzfQrMTmJv:
		RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h = ddK4MmwpX5oG(u"ࡆࡢ࡮ࡶࡩ઱")
		Df3p8YoF4GVj1bShqTQk5z0Wn = GjZltWoCxuIwNfQ7EH9(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ῿"),IJ6VkihabRm(u"ࠫำื่อࠩࠀ"),vkMRnTNV9jFm(u"ࠬหัิษ็ࠤฺ๊ใๅหࠪࠁ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠭ลาีส่ࠥืำศๆฬࠫࠂ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠃ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫࠄ"))
		if Df3p8YoF4GVj1bShqTQk5z0Wn in [-v7reLlOXCgD5pZ14w2tUA(u"࠶੢"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠶੣")]: return
		elif Df3p8YoF4GVj1bShqTQk5z0Wn==qNZKwi2M1S4fBzGQYrmPnea(u"࠱੤"):
			RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h = vkMRnTNV9jFm(u"ࡕࡴࡸࡩલ")
			OO1XlVPzfQrMTmJv = qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬࠅ")
	if RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h:
		if KbL94nDHufSF0VcO2Nk3(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪࠆ") not in OO1XlVPzfQrMTmJv:
			T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࠇ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࠭ࠈ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࠧࠉ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ุ้ࠧ฼ࠤฬ๊ๅีๅ็อࠥ็๊ࠡษ็ืั๊ࠧࠊ"),xxpPYJOnoAUrlBzyveui(u"ࠨไห่ࠥหัิษ็ࠤฬ๊ำอๆࠣ฽้๐ใࠡล้ࠤฯ้ัา๊ࠢࠣๆูࠠศๆไ฽้ࠦวๅาํࠤศ฿ืศๅࠣห้๋ิไๆฬࠤ࠳ࠦไไ์ࠣ๎ฯ๋ࠠหีฯ๎้ࠦ็ั้ࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ࠱ࠤํฮฯ้่๋ࠣีอࠠศๆอืั๐ไࠡี๋ๅࠥะัิๆ้้ࠣ็ࠠๅษࠣๅฬฬฯส่๊ࠢ์ࠦไฦ่๊ࠤ้อ๋ࠠฯอ์๏ูࠦๅ๋ࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอี๏ีࠠศ่อࠤฬ๊ลษๆส฾ࠥ฿ๆ่ษࠣ࠲ࠥํไࠡไ่ฮࠥฮสไำสีࠥอไๆึๆ่ฮࠦฟࠨࠋ"))
			if T4TGmZ9XWAzONaKygic!=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠲੥"):
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(Vv0lSjAOHLfMnam3wtdor(u"ࠩࠪࠌ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࠫࠍ"),DDS79jdWzLtE(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧࠎ"),fcIm8tvxlXZsaEY3bwuG4B(u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨࠏ"))
				return
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ZpH2IWt7veyFobTsAnhi41(u"࠭ࠧࠐ"),p1lrNRIXqLQJznH6O(u"ࠧࠨࠑ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠒ"),zOZvXaebGNwHKfjRA(u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆศ๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠓ"))
	search = wod1HJ0fnvcTNAX2WIiMu9P(header=ZpH2IWt7veyFobTsAnhi41(u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬࠔ"),source=mm5vCBc4DOz2Fj)
	if not search: return
	qNEnDMwm1Vfastx2ZkpRh = search
	if RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h: type = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬࠕ")
	else: type = p1lrNRIXqLQJznH6O(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭ࠖ")
	BcMl3XdLS0zmK1jPvDJANfYH = xWaZr7lMs6teC8(type,qNEnDMwm1Vfastx2ZkpRh,qNZKwi2M1S4fBzGQYrmPnea(u"ࡖࡵࡹࡪળ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧࠗ"),zOZvXaebGNwHKfjRA(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪ࠘"),OO1XlVPzfQrMTmJv)
	return
def wXT9gd7KqLVlOB():
	OO1XlVPzfQrMTmJv = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ࠙")
	qQL7e23RtCg4xOpf(OARzhnB9o7uYvQGFaIcZ(u"ࠩࡵ࡭࡬࡮ࡴࠨࠚ"),uhOkAKtLVv4XTy1nWE6(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪࠛ"),OO1XlVPzfQrMTmJv,OARzhnB9o7uYvQGFaIcZ(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧࠜ"))
	OO1XlVPzfQrMTmJv = IJ6VkihabRm(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨࠝ")
	qQL7e23RtCg4xOpf(OARzhnB9o7uYvQGFaIcZ(u"࠭࡬ࡦࡨࡷࠫࠞ"),OARzhnB9o7uYvQGFaIcZ(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬࠟ"),OO1XlVPzfQrMTmJv,HMO0QciekqVpLKmA(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࠠ"))
	return
def HHzOL1ASbpGMKCx2gjEBuVQtrT3JI9(M0J6Pq3bH2):
	t78SOQHR9JTBNAa = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(xxpPYJOnoAUrlBzyveui(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࠡ")+M0J6Pq3bH2+zOZvXaebGNwHKfjRA(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩࠢ"))
	PqREL0OwgzB = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡗࡶࡺ࡫઴")
	if PqREL0OwgzB:
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳੦"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(p1lrNRIXqLQJznH6O(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨࠣ"))
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(xxBJoKG54uwQ(u"࠴੧"))
	return
def m9mrFOgHlDWTKk():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(Vv0lSjAOHLfMnam3wtdor(u"ࠬ࠭ࠤ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠧࠥ"),Vv0lSjAOHLfMnam3wtdor(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠦ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠨษ็ฬึ์วๆฮ่ࠣฬ๊ࠦโฯุࠤูํวะหࠣห้ะิโ์ิࠤ฾์ฯࠡษ็หฯ฻วๅࠢหห้๋่ศไ฼ࠤฬ๊ๅีใิอࠥ๎ไ่าสࠤๆ๐ࠠฮษ็ࠤํา่ะࠢื๋ฬีษࠡ฼ํีࠥ฻อ๋ฯฬࠤศ๎ࠠๆ่อ๋๏ฯࠠศๆุ่ฬำ๊สࠢฦ์๋ࠥา๋ใฬࠤๆอๆ้ࠡำห๊ࠥๆࠡ์๋ๆๆࠦวๅำห฻ࠥอไๆึไีࠥ๎ไ็ࠢํ์็็ฺࠠ็็ࠤฬ๊ศา่ส้ั࠭ࠧ"))
	yiNWojhaz8wZU2LM()
	return
def zztDMTj1Fcd2xLfpNr():
	url = p1lrNRIXqLQJznH6O(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࡭ࡷࡸ࡯ࡳࡵ࠱࡯ࡴࡪࡩ࠯ࡶࡹ࠳ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠵ࡷࡪࡰࡧࡳࡼࡹ࠯ࡸ࡫ࡱ࠺࠹࠵ࠧࠨ")
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡋࡊ࡚ࠧࠩ"),url,vkMRnTNV9jFm(u"ࠫࠬࠪ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬ࠭ࠫ"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠧࠬ"),v7reLlOXCgD5pZ14w2tUA(u"ࠧࠨ࠭"),v7reLlOXCgD5pZ14w2tUA(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫ࠮"))
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	odiy8qDkvQVP = QPuHKNAT4jmCRg.findall(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨ࠯"),Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	odiy8qDkvQVP = odiy8qDkvQVP[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠴੨")].split(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪ࠱ࠬ࠰"))[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠴੨")]
	VWBDhLTwUtlqiErMvKg65ob2ISY4X = str(LRjqrQYBXFVPfu)
	PPgIRJtB2XQhmfzoU4 = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭࠱")+fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࠲")+odiy8qDkvQVP+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠳")
	PPgIRJtB2XQhmfzoU4 += tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࡝ࡰ࡟ࡲࠬ࠴")+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ࠵")+V391t7nQWUBR5euCkJ(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࠶")+VWBDhLTwUtlqiErMvKg65ob2ISY4X+p1lrNRIXqLQJznH6O(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠷")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(GGTRaYBDeNyI25zlF(u"ࠫࠬ࠸"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࠭࠹"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠺"),PPgIRJtB2XQhmfzoU4)
	return
def YaVxdOeX6ykW3AB9gpES5H():
	GhpNfPVMB2uRnqasFL6K,fl57MHCK8LhbtieNY0QUck4AO,IIEUd7xqAfnlYvgtaCMQ5h,PPgIRJtB2XQhmfzoU4,clwziVSmv3NPUkFXCjerBMd6nx,Z7ZAv0IJgzT4CXwYbc,xUgtWXcNf8j4u2EQbGZMVAm = DDS79jdWzLtE(u"ࠧࠨ࠻"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࠩ࠼"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࠪ࠽"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠫ࠾"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࠬ࠿"),DDS79jdWzLtE(u"ࠬ࠭ࡀ"),OARzhnB9o7uYvQGFaIcZ(u"࠭ࠧࡁ")
	E9ODYnfpm54GJTd2xRrV,sbjlJMCufgZ8zpWrGRFdvE27aq,OYnaEcMty6g1,du2ka6Jr80opOjZsLCy9zMhQWqcIFX = {L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࡢࠩࡂ"):qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡣࠪࡃ")},{},[],{}
	url = EGcFon0zR4mSL1[ddK4MmwpX5oG(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩࡄ")][zOZvXaebGNwHKfjRA(u"࠶੩")]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(ooDaNCkx4c0FjJs,HMO0QciekqVpLKmA(u"ࠪࡔࡔ࡙ࡔࠨࡅ"),url,E9ODYnfpm54GJTd2xRrV,p1lrNRIXqLQJznH6O(u"ࠫࠬࡆ"),KbL94nDHufSF0VcO2Nk3(u"ࠬ࠭ࡇ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࠧࡈ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬࡉ"))
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨࡊ"),xxpPYJOnoAUrlBzyveui(u"ࠩࡘࡗࡆ࠭ࡋ"))
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(DKqQekNtF6WlJLhBP9M5ca(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫࡌ"),uhOkAKtLVv4XTy1nWE6(u"࡚ࠫࡑࠧࡍ"))
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(DDS79jdWzLtE(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬࡎ"),fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡕࡂࡇࠪࡏ"))
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭ࡐ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡍࡖࡅࠬࡑ"))
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(zOZvXaebGNwHKfjRA(u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫࡒ"),xxBJoKG54uwQ(u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨࡓ"))
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬࡔ"),vkMRnTNV9jFm(u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧࡕ"))
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace(Vv0lSjAOHLfMnam3wtdor(u"࠭࡟ࡠࡡࠪࡖ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࠡࠢࠪࡗ"))
	try: J01Ez85s4GLSpab = kMLWTt2fO9dnGDUgHh(Vv0lSjAOHLfMnam3wtdor(u"ࠨ࡮࡬ࡷࡹ࠭ࡘ"),Ht6Gg8lbciAd9FaUQVs)
	except:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(L91nVzxH4hYrgPDsOuljXd0J(u"࡙ࠩࠪ"),IJ6VkihabRm(u"࡚ࠪࠫ"),HMO0QciekqVpLKmA(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า࡛ࠧ"),V391t7nQWUBR5euCkJ(u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ࡜"))
		return
	FDTJWc65EMjlpL94Oie7r8qnUNAQH,OgmVbhK2564R,HjsVxRhOSuJlUb6fZpaND9F = J01Ez85s4GLSpab
	du2ka6Jr80opOjZsLCy9zMhQWqcIFX = {}
	iGLZ1C5VUc = [v7reLlOXCgD5pZ14w2tUA(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡉࡅࠩ࡝"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡕࡑࡎࡉࡓ࠭࡞")]
	qqiozPt5GZ = [IJ6VkihabRm(u"ࠨࡃࡏࡐࠬ࡟"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩࡠ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫࡡ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨࡢ"),xxpPYJOnoAUrlBzyveui(u"ࠬࡘࡅࡑࡑࡖࠫࡣ")]+iGLZ1C5VUc+zDemIpoFb2UJkGLZQ4+ggnJ1x5MSbshUDzXt06WcPrfl
	for Xt7olBPDuFS4diy1,rIjWBmtbHL2Qyh5GRx6T,vvVY4XxlE9NeZdLgqoTj6uWOtAF5I in OgmVbhK2564R:
		vvVY4XxlE9NeZdLgqoTj6uWOtAF5I = kWfpQA7tTjSPyLbNIeMr1Hui5(vvVY4XxlE9NeZdLgqoTj6uWOtAF5I)
		vvVY4XxlE9NeZdLgqoTj6uWOtAF5I = vvVY4XxlE9NeZdLgqoTj6uWOtAF5I.strip(GGTRaYBDeNyI25zlF(u"࠭ࠠࠨࡤ")).strip(HMO0QciekqVpLKmA(u"ࠧࠡ࠰ࠪࡥ"))
		PPgIRJtB2XQhmfzoU4 += KbL94nDHufSF0VcO2Nk3(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࡦ")+Xt7olBPDuFS4diy1+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡧ")+vvVY4XxlE9NeZdLgqoTj6uWOtAF5I+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡠࡳ࠭ࡨ")
		if rIjWBmtbHL2Qyh5GRx6T.isdigit():
			du2ka6Jr80opOjZsLCy9zMhQWqcIFX[Xt7olBPDuFS4diy1] = int(rIjWBmtbHL2Qyh5GRx6T)
			if int(rIjWBmtbHL2Qyh5GRx6T)>HMO0QciekqVpLKmA(u"࠷࠰࠱੪"): rIjWBmtbHL2Qyh5GRx6T = zOZvXaebGNwHKfjRA(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧࡩ")
			else: rIjWBmtbHL2Qyh5GRx6T = V391t7nQWUBR5euCkJ(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧࡪ")
		if Xt7olBPDuFS4diy1 not in qqiozPt5GZ:
			if   rIjWBmtbHL2Qyh5GRx6T==HMO0QciekqVpLKmA(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩ࡫"): GhpNfPVMB2uRnqasFL6K += qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࠡࠢࠪ࡬")+Xt7olBPDuFS4diy1
			elif rIjWBmtbHL2Qyh5GRx6T==v7reLlOXCgD5pZ14w2tUA(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ࡭"): fl57MHCK8LhbtieNY0QUck4AO += v7reLlOXCgD5pZ14w2tUA(u"ࠩࠣࠤࠬ࡮")+Xt7olBPDuFS4diy1
	gCYDe4rLJaqpfyS,NzcS2XwRaoFLmJhklHIjB1OVp,cxorC5ltBwW7if6hY01MFnQG = list(zip(*OgmVbhK2564R))
	for Xt7olBPDuFS4diy1 in sorted(pgF0ezZWMBqJaufs):
		if Xt7olBPDuFS4diy1 not in gCYDe4rLJaqpfyS:
			PPgIRJtB2XQhmfzoU4 += vkMRnTNV9jFm(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࡯")+Xt7olBPDuFS4diy1+ZpH2IWt7veyFobTsAnhi41(u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࡰ")+L91nVzxH4hYrgPDsOuljXd0J(u"๊ࠬวࠡ์๋ะิ࠭ࡱ")+lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭࡜࡯࡞ࡱࠫࡲ")
			if Xt7olBPDuFS4diy1 not in qqiozPt5GZ: IIEUd7xqAfnlYvgtaCMQ5h += p1lrNRIXqLQJznH6O(u"ࠧࠡࠢࠪࡳ")+Xt7olBPDuFS4diy1
	for vvVY4XxlE9NeZdLgqoTj6uWOtAF5I,K0XWzFpPsn1JGoxZVr6gDali2eE in FDTJWc65EMjlpL94Oie7r8qnUNAQH:
		vvVY4XxlE9NeZdLgqoTj6uWOtAF5I = kWfpQA7tTjSPyLbNIeMr1Hui5(vvVY4XxlE9NeZdLgqoTj6uWOtAF5I)
		clwziVSmv3NPUkFXCjerBMd6nx += vvVY4XxlE9NeZdLgqoTj6uWOtAF5I+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࡴ")+str(K0XWzFpPsn1JGoxZVr6gDali2eE)+dxAs4otSE98YmZnKy2iwRCB(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧࡵ")
	GhpNfPVMB2uRnqasFL6K = GhpNfPVMB2uRnqasFL6K.strip(V391t7nQWUBR5euCkJ(u"ࠪࠤࠬࡶ"))
	fl57MHCK8LhbtieNY0QUck4AO = fl57MHCK8LhbtieNY0QUck4AO.strip(ddK4MmwpX5oG(u"ࠫࠥ࠭ࡷ"))
	IIEUd7xqAfnlYvgtaCMQ5h = IIEUd7xqAfnlYvgtaCMQ5h.strip(V391t7nQWUBR5euCkJ(u"ࠬࠦࠧࡸ"))
	RWKmiqnE5dtHVyrP60ACXBSJu = GhpNfPVMB2uRnqasFL6K+DDS79jdWzLtE(u"࠭ࠠࠡࠩࡹ")+fl57MHCK8LhbtieNY0QUck4AO
	Rs8TVdy7vYwnHEXqeU5If9K  = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧๆ๊สๆ฾ࠦๆอฯࠣห้ฮั็ษ่ะࠥฮสี฼ํ่ࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫࡺ")+fcIm8tvxlXZsaEY3bwuG4B(u"ࠨ࡞ࡱࠫࡻ")+xxpPYJOnoAUrlBzyveui(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧࡼ")+ZpH2IWt7veyFobTsAnhi41(u"ࠪࡠࡳ࠭ࡽ")
	Rs8TVdy7vYwnHEXqeU5If9K += Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧࡾ")+RWKmiqnE5dtHVyrP60ACXBSJu+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫࡿ")
	Rs8TVdy7vYwnHEXqeU5If9K += u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬࢀ")+DDS79jdWzLtE(u"ࠧ࡝ࡰࠪࢁ")+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬࢂ")+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩ࡟ࡲࠬࢃ")
	Rs8TVdy7vYwnHEXqeU5If9K += HMO0QciekqVpLKmA(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࢄ")+IIEUd7xqAfnlYvgtaCMQ5h+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢅ")
	Xoq8pmrFikUg9wvaeu2WKh3xb5Z4A,Ipf1BJ6s03US7nHq,dVOxYXfgh3kH7tsURc8CpuJ0vqmQL,e7YkANfPosMiTF = ZpH2IWt7veyFobTsAnhi41(u"࠰੫"),ZpH2IWt7veyFobTsAnhi41(u"࠰੫"),ZpH2IWt7veyFobTsAnhi41(u"࠰੫"),ZpH2IWt7veyFobTsAnhi41(u"࠰੫")
	all = du2ka6Jr80opOjZsLCy9zMhQWqcIFX[L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡇࡌࡍࠩࢆ")]
	if Vv0lSjAOHLfMnam3wtdor(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ࢇ") in list(du2ka6Jr80opOjZsLCy9zMhQWqcIFX.keys()): Xoq8pmrFikUg9wvaeu2WKh3xb5Z4A = du2ka6Jr80opOjZsLCy9zMhQWqcIFX[HMO0QciekqVpLKmA(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ࢈")]
	if lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩࢉ") in list(du2ka6Jr80opOjZsLCy9zMhQWqcIFX.keys()): Ipf1BJ6s03US7nHq = du2ka6Jr80opOjZsLCy9zMhQWqcIFX[xxBJoKG54uwQ(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪࢊ")]
	if DDS79jdWzLtE(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧࢋ") in list(du2ka6Jr80opOjZsLCy9zMhQWqcIFX.keys()): dVOxYXfgh3kH7tsURc8CpuJ0vqmQL = du2ka6Jr80opOjZsLCy9zMhQWqcIFX[DDS79jdWzLtE(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨࢌ")]
	if KbL94nDHufSF0VcO2Nk3(u"ࠬࡘࡅࡑࡑࡖࠫࢍ") in list(du2ka6Jr80opOjZsLCy9zMhQWqcIFX.keys()): e7YkANfPosMiTF = du2ka6Jr80opOjZsLCy9zMhQWqcIFX[tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࡒࡆࡒࡒࡗࠬࢎ")]
	mfPLeAx2zl6UgY9r7GDkn0VItKF3X = all-Xoq8pmrFikUg9wvaeu2WKh3xb5Z4A-Ipf1BJ6s03US7nHq-dVOxYXfgh3kH7tsURc8CpuJ0vqmQL-e7YkANfPosMiTF
	aaxAKWtMwfPRE4zbqSQCOrBms0,HtNG7xMjn1wFa3KSzErUW9ViZ0 = HjsVxRhOSuJlUb6fZpaND9F[f8PVRTseIuj9BckO6GoyF5Lxv(u"࠱੬")]
	aaxAKWtMwfPRE4zbqSQCOrBms0,RU8OVXZoxn6NGwDfHz = HjsVxRhOSuJlUb6fZpaND9F[xxpPYJOnoAUrlBzyveui(u"࠳੭")]
	aLSU8OV7TAP1EZjydw4lQCbKGxmDM = HtNG7xMjn1wFa3KSzErUW9ViZ0-RU8OVXZoxn6NGwDfHz
	xUgtWXcNf8j4u2EQbGZMVAm += DKqQekNtF6WlJLhBP9M5ca(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ࢏")+str(RU8OVXZoxn6NGwDfHz)+ddK4MmwpX5oG(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࢐")+V391t7nQWUBR5euCkJ(u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭࢑")
	xUgtWXcNf8j4u2EQbGZMVAm += V391t7nQWUBR5euCkJ(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࢒")+str(aLSU8OV7TAP1EZjydw4lQCbKGxmDM)+f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࢓")+KbL94nDHufSF0VcO2Nk3(u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩ࢔")
	xUgtWXcNf8j4u2EQbGZMVAm += ddK4MmwpX5oG(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ࢕")+str(HtNG7xMjn1wFa3KSzErUW9ViZ0)+V391t7nQWUBR5euCkJ(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢖")+V391t7nQWUBR5euCkJ(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩࢗ")
	xUgtWXcNf8j4u2EQbGZMVAm += tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ࢘")+str(len(HjsVxRhOSuJlUb6fZpaND9F[v7reLlOXCgD5pZ14w2tUA(u"࠵੮"):]))+GGTRaYBDeNyI25zlF(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࢙ࠬ")+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯࢚ࠩ")
	for opOrMkINsZbSfcP8wYRzayFt,wn0kd1pEgfSy4YG in HjsVxRhOSuJlUb6fZpaND9F[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠶੯"):]:
		opOrMkINsZbSfcP8wYRzayFt = kWfpQA7tTjSPyLbNIeMr1Hui5(opOrMkINsZbSfcP8wYRzayFt)
		opOrMkINsZbSfcP8wYRzayFt = opOrMkINsZbSfcP8wYRzayFt.strip(vkMRnTNV9jFm(u"࢛ࠬࠦࠧ")).strip(OARzhnB9o7uYvQGFaIcZ(u"࠭ࠠ࠯ࠩ࢜"))
		xUgtWXcNf8j4u2EQbGZMVAm += opOrMkINsZbSfcP8wYRzayFt+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ࢝")+str(wn0kd1pEgfSy4YG)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭࢞")
	Z7ZAv0IJgzT4CXwYbc += L91nVzxH4hYrgPDsOuljXd0J(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࢟")+str(mfPLeAx2zl6UgY9r7GDkn0VItKF3X)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢠ")+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩࢡ")
	Z7ZAv0IJgzT4CXwYbc += GGTRaYBDeNyI25zlF(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࢢ")+str(Xoq8pmrFikUg9wvaeu2WKh3xb5Z4A)+lunVJF2G5bZMgTcCje0vaIB371SX(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࢣ")+q0JfWbP8vACLxSNIncpOXkR6j(u"ุࠧๆหหฯࠦำ๋ำไีࠥฮว๋อ๋๊ࠥࡀࠠࠨࢤ")
	Z7ZAv0IJgzT4CXwYbc += iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ࢥ")+str(e7YkANfPosMiTF)+ZpH2IWt7veyFobTsAnhi41(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢦ")+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ࢧ")
	Z7ZAv0IJgzT4CXwYbc += OARzhnB9o7uYvQGFaIcZ(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࢨ")+str(Ipf1BJ6s03US7nHq)+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢩ")+KbL94nDHufSF0VcO2Nk3(u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪࢪ")
	Z7ZAv0IJgzT4CXwYbc += p1lrNRIXqLQJznH6O(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࢫ")+str(dVOxYXfgh3kH7tsURc8CpuJ0vqmQL)+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢬ")+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩอฯอ๐สࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥࡀࠠࠨࢭ")
	Z7ZAv0IJgzT4CXwYbc += DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨࢮ")+str(len(FDTJWc65EMjlpL94Oie7r8qnUNAQH))+uhOkAKtLVv4XTy1nWE6(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢯ")+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬࢰ")
	Z7ZAv0IJgzT4CXwYbc += ZpH2IWt7veyFobTsAnhi41(u"࠭࡜࡯࡞ࡱࠫࢱ")+clwziVSmv3NPUkFXCjerBMd6nx
	qQL7e23RtCg4xOpf(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧࡤࡧࡱࡸࡪࡸࠧࢲ"),IJ6VkihabRm(u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨࢳ"),xUgtWXcNf8j4u2EQbGZMVAm,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬࢴ"))
	qQL7e23RtCg4xOpf(ddK4MmwpX5oG(u"ࠪࡧࡪࡴࡴࡦࡴࠪࢵ"),uhOkAKtLVv4XTy1nWE6(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬࢶ"),Z7ZAv0IJgzT4CXwYbc,ZpH2IWt7veyFobTsAnhi41(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࢷ"))
	qQL7e23RtCg4xOpf(DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢸ"),V391t7nQWUBR5euCkJ(u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪࢹ"),Rs8TVdy7vYwnHEXqeU5If9K,v7reLlOXCgD5pZ14w2tUA(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࢺ"))
	qQL7e23RtCg4xOpf(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩ࡯ࡩ࡫ࡺࠧࢻ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬࢼ"),PPgIRJtB2XQhmfzoU4,zOZvXaebGNwHKfjRA(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬࢽ"))
	return
def z9X8gMaqTKAOu1e():
	qNEnDMwm1Vfastx2ZkpRh = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫࢾ")
	qQL7e23RtCg4xOpf(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢿ"),ZpH2IWt7veyFobTsAnhi41(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣀ"),qNEnDMwm1Vfastx2ZkpRh,xxpPYJOnoAUrlBzyveui(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࣁ"))
	return
def T65coqAhLzyGMmQ7tlN():
	qNEnDMwm1Vfastx2ZkpRh = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧࣂ")+ddK4MmwpX5oG(u"ࠪࡠࡳ࠭ࣃ")+fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧࣄ")+EGcFon0zR4mSL1[ZpH2IWt7veyFobTsAnhi41(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫࣅ")][tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶ੱ")]+f8PVRTseIuj9BckO6GoyF5Lxv(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪࣆ")+EGcFon0zR4mSL1[v7reLlOXCgD5pZ14w2tUA(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ࣇ")][V391t7nQWUBR5euCkJ(u"࠶ੰ")]+xxBJoKG54uwQ(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣈ")
	qNEnDMwm1Vfastx2ZkpRh += qNZKwi2M1S4fBzGQYrmPnea(u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮืࠡลา๊ฬํ่๊ࠠࠣหู้่าีࠣห้ึ๊ࠡ์ะฮฬา็ࠡ็า๎ึࠦๅๅใสฮ้่ࠥะ์่ࠣฯัศ๋ฬࠣฬึ์วๆฮࠣ฽๊อฯࠡสส่฼ื๊ใหࠣห้ะโๅ์า๎ฮࠦวๅไา๎๊ฯ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫࣉ")+EGcFon0zR4mSL1[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ࣊")][q0JfWbP8vACLxSNIncpOXkR6j(u"࠱ੲ")]+fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࣋")
	qNEnDMwm1Vfastx2ZkpRh += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ࣌")+f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭࡜࡯ࠩ࣍")+zOZvXaebGNwHKfjRA(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ࣎")+EGcFon0zR4mSL1[gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔ࣏ࠩ")][ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳ੳ")]+KbL94nDHufSF0VcO2Nk3(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠ࣐ࠫ")
	qQL7e23RtCg4xOpf(v7reLlOXCgD5pZ14w2tUA(u"ࠪࡧࡪࡴࡴࡦࡴ࣑ࠪ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋ห࣒ࠪ"),qNEnDMwm1Vfastx2ZkpRh,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࣓"))
	return
def xZfCkimFuYbaEloAzcBQ7sevT(pJZ3NUaKVHWYt):
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(HMO0QciekqVpLKmA(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬࣔ")+pJZ3NUaKVHWYt+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࠪࠩࣕ"), p1lrNRIXqLQJznH6O(u"ࡘࡷࡻࡥવ"))
	return
def EbUFPLiZ7x2Xl():
	aarhp43yvIqojdnWs6Sb(OARzhnB9o7uYvQGFaIcZ(u"ࠨࡵࡷࡳࡵ࠭ࣖ"))
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣࣗ"))
	return
def qOIuD53C0Ua4MGpc():
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩࣘ"), a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡙ࡸࡵࡦશ"))
	return
def EE0PlFd2ec9Ao(showDialogs):
	if not showDialogs: T4TGmZ9XWAzONaKygic = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࡚ࡲࡶࡧષ")
	else: T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࣙ"),DDS79jdWzLtE(u"ࠬ࠭ࣚ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠧࣛ"),vkMRnTNV9jFm(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣜ"),ZpH2IWt7veyFobTsAnhi41(u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡษ็ฦ๋ࠦฟࠨࣝ"))
	if T4TGmZ9XWAzONaKygic==f8PVRTseIuj9BckO6GoyF5Lxv(u"࠳ੴ"):
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬࣞ"))
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(HMO0QciekqVpLKmA(u"ࠪࠫࣟ"),ZpH2IWt7veyFobTsAnhi41(u"ࠫࠬ࣠"),p1lrNRIXqLQJznH6O(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣡"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭࣢"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࣣࠫ"))
	return
def RR0Id1LXJgvof2GQOah():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࠩࣤ"),xxpPYJOnoAUrlBzyveui(u"ࠩࠪࣥ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัࣦ࠭"),v7reLlOXCgD5pZ14w2tUA(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫࣧ"))
	return
def zK8UIO7p413YnhjsTAde():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(V391t7nQWUBR5euCkJ(u"ࠬ࠭ࣨ"),DKqQekNtF6WlJLhBP9M5ca(u"ࣩ࠭ࠧ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࣪"),ddK4MmwpX5oG(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫ࣫"))
	return
def i1eUnRIqv39loL(showDialogs=iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡔࡳࡷࡨસ")):
	lh80pkBrNsFgWVqwDU6LiA9Ka = [f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ࣬"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨ࣭ࠫ"),zOZvXaebGNwHKfjRA(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࣮ࠧ"),V391t7nQWUBR5euCkJ(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨ࣯ࠧ"),dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࣰࠧ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࣱࠫ")]
	LCyNIjYA37UbrqxO = lh80pkBrNsFgWVqwDU6LiA9Ka+[IJ6VkihabRm(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࣲࠪ"),IJ6VkihabRm(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧࣳ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩࣴ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪࣵ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡹ࡫ࡪࡰ࠱ࡴ࡭࡫࡮ࡰ࡯ࡨࡲࡦࡲࡅࡎࡃࡇࣶࠫ"),uhOkAKtLVv4XTy1nWE6(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪࣷ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫࣸ")]
	BwiXRqKVEj = QNumy9zkeS([iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࣹࠪ")])
	pgyzj298CP = []
	for M0J6Pq3bH2 in [iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࣺࠫ")]:
		if M0J6Pq3bH2 not in list(BwiXRqKVEj.keys()): continue
		xbkrlD0EILwKiPB68MhNpRuA,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms,gaBXSUFDeuIJyMpCYTrLZz05,OyQDJeVudN0c,ifWNgOL7zYB3eX6PRF1,tcRirKM2lfyWAhanvCe1om,zC5oqj0kfaiBZ83stxESyg = BwiXRqKVEj[M0J6Pq3bH2]
		if not Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms or (Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms and xbkrlD0EILwKiPB68MhNpRuA): pgyzj298CP.append(M0J6Pq3bH2)
	Xs6mvyGHRzPBakgqpOWTLD54Z2 = len(pgyzj298CP)>iRTygNp4Lf36wQKlD2MHUhG7B(u"࠳ੵ")
	qcOU43biDkaPQlZMB1wHEj = csXRAak0iZIKQpfu1o.connect(zmL4569eBqGphRbKP7f2NOs)
	qcOU43biDkaPQlZMB1wHEj.text_factory = str
	K2DlNXvQC65FzngUVyk3IGAq = qcOU43biDkaPQlZMB1wHEj.cursor()
	IPMrV2ed5vi0gq73FLlWEktmSbGnCw = []
	for M0J6Pq3bH2 in lh80pkBrNsFgWVqwDU6LiA9Ka:
		K2DlNXvQC65FzngUVyk3IGAq.execute(KbL94nDHufSF0VcO2Nk3(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࠤ࠴ࠦࠥࡧ࡮ࡥࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࣻ")+M0J6Pq3bH2+ZpH2IWt7veyFobTsAnhi41(u"ࠫࠧࠦ࠻ࠨࣼ"))
		u5hKSaFyVqLz90Zc6iG = K2DlNXvQC65FzngUVyk3IGAq.fetchall()
		if u5hKSaFyVqLz90Zc6iG: IPMrV2ed5vi0gq73FLlWEktmSbGnCw.append(M0J6Pq3bH2)
	EykW83pGmNUlrHLxbfPMvI97DV4qF = len(IPMrV2ed5vi0gq73FLlWEktmSbGnCw)>fcIm8tvxlXZsaEY3bwuG4B(u"࠴੶")
	for M0J6Pq3bH2 in LCyNIjYA37UbrqxO:
		K2DlNXvQC65FzngUVyk3IGAq.execute(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࣽ")+M0J6Pq3bH2+vkMRnTNV9jFm(u"࠭ࠢࠡ࠽ࠪࣾ"))
		m4bKzleJRVDdASZTi5PQG = K2DlNXvQC65FzngUVyk3IGAq.fetchall()
		if m4bKzleJRVDdASZTi5PQG and tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩࣿ") not in str(m4bKzleJRVDdASZTi5PQG): pgyzj298CP.append(M0J6Pq3bH2)
	s6sduZxNc1 = len(pgyzj298CP)>DKqQekNtF6WlJLhBP9M5ca(u"࠵੷")
	pgyzj298CP = list(set(pgyzj298CP))
	qcOU43biDkaPQlZMB1wHEj.close()
	xbkrlD0EILwKiPB68MhNpRuA = V391t7nQWUBR5euCkJ(u"ࡇࡣ࡯ࡷࡪહ")
	if EykW83pGmNUlrHLxbfPMvI97DV4qF or s6sduZxNc1:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(KbL94nDHufSF0VcO2Nk3(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऀ"),KbL94nDHufSF0VcO2Nk3(u"ࠩࠪँ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࠫं"),DDS79jdWzLtE(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧः"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣๅ๏ࠦๅิฬ๋ำ฾ูࠦๆษาࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠤࡡࡴ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣห้ศๆࠡม࡞࠳ࡈࡕࡌࡐࡔࡠࠫऄ"))
		if T4TGmZ9XWAzONaKygic==Vv0lSjAOHLfMnam3wtdor(u"࠷੸"):
			afuZMze6gctrnl = qNZKwi2M1S4fBzGQYrmPnea(u"ࡖࡵࡹࡪ઺")
			if Xs6mvyGHRzPBakgqpOWTLD54Z2:
				afuZMze6gctrnl = QnXFVhjS03wM6d2DUGfZKgb4l(qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨअ"),zOZvXaebGNwHKfjRA(u"ࡉࡥࡱࡹࡥ઻"),zOZvXaebGNwHKfjRA(u"ࡉࡥࡱࡹࡥ઻"))
			fJ2hucwsCigFr = IJ6VkihabRm(u"ࡘࡷࡻࡥ઼")
			if EykW83pGmNUlrHLxbfPMvI97DV4qF:
				for M0J6Pq3bH2 in IPMrV2ed5vi0gq73FLlWEktmSbGnCw: HHzOL1ASbpGMKCx2gjEBuVQtrT3JI9(M0J6Pq3bH2)
				fJ2hucwsCigFr = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࡙ࡸࡵࡦઽ")
			N4SDd9c5gMqJWfZTw3Xb = qNZKwi2M1S4fBzGQYrmPnea(u"࡚ࡲࡶࡧા")
			if s6sduZxNc1:
				qcOU43biDkaPQlZMB1wHEj = csXRAak0iZIKQpfu1o.connect(zmL4569eBqGphRbKP7f2NOs)
				qcOU43biDkaPQlZMB1wHEj.text_factory = str
				K2DlNXvQC65FzngUVyk3IGAq = qcOU43biDkaPQlZMB1wHEj.cursor()
				for M0J6Pq3bH2 in pgyzj298CP:
					if DDS79jdWzLtE(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࠪआ") in M0J6Pq3bH2: m4bKzleJRVDdASZTi5PQG = M0J6Pq3bH2
					else: m4bKzleJRVDdASZTi5PQG = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪइ")
					try: K2DlNXvQC65FzngUVyk3IGAq.execute(V391t7nQWUBR5euCkJ(u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭ई")+m4bKzleJRVDdASZTi5PQG+f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩउ")+M0J6Pq3bH2+xxBJoKG54uwQ(u"ࠫࠧࠦ࠻ࠨऊ"))
					except: N4SDd9c5gMqJWfZTw3Xb = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࡆࡢ࡮ࡶࡩિ")
				qcOU43biDkaPQlZMB1wHEj.commit()
				qcOU43biDkaPQlZMB1wHEj.close()
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(OARzhnB9o7uYvQGFaIcZ(u"࠱੹"))
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(f8PVRTseIuj9BckO6GoyF5Lxv(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩऋ"))
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠲੺"))
			if afuZMze6gctrnl or fJ2hucwsCigFr or N4SDd9c5gMqJWfZTw3Xb:
				xbkrlD0EILwKiPB68MhNpRuA = xxpPYJOnoAUrlBzyveui(u"ࡇࡣ࡯ࡷࡪી")
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(GGTRaYBDeNyI25zlF(u"࠭ࠧऌ"),uhOkAKtLVv4XTy1nWE6(u"ࠧࠨऍ"),OARzhnB9o7uYvQGFaIcZ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫऎ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩฯ๎ิࠦ࠮࠯ࠢอ้ࠥฮๆอษะࠤฯ็ู๋ๆࠣ์ส฻ไศฯࠣห้๋ำห๊า฽ࠥ๎วๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ะ๊๐ูࠡวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭ए"))
			else:
				xbkrlD0EILwKiPB68MhNpRuA = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡖࡵࡹࡪુ")
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࠫऐ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࠬऑ"),xxpPYJOnoAUrlBzyveui(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥหีๅษะࠤู๊ส้ั฼ࠤ฾๋วะ๋ࠢษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫओ"))
	elif showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠨऔ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࠩक"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬख"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะุ่่๊ࠢษࠡใํࠤู๊ส้ั฼ࠤ฾๋วะࠢฦ์ࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪग"))
	return xbkrlD0EILwKiPB68MhNpRuA
def ISLxc2mBCWFjilUwn():
	qWmgtXCcSI6vMrGhx,FS7T1IVust2XBlzEQn3w9jYCfZ,DJxZ9rzHvRqnXIE4ySiufk1j67mh = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡉࡥࡱࡹࡥૂ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࠬघ"),OARzhnB9o7uYvQGFaIcZ(u"ࠬ࠭ङ")
	UASDI2W9tzX6,AA7ijcl2ZtK8MIJFfWYs41C0OpXTBr,rgh3tEMP6vTY0dj8wV51kBbpcyIin9 = OARzhnB9o7uYvQGFaIcZ(u"ࡊࡦࡲࡳࡦૃ"),Vv0lSjAOHLfMnam3wtdor(u"࠭ࠧच"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࠨछ")
	o4oVOHtrSlkM52Up = [Vv0lSjAOHLfMnam3wtdor(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ज"),ZpH2IWt7veyFobTsAnhi41(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨझ"),v7reLlOXCgD5pZ14w2tUA(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬञ"),vkMRnTNV9jFm(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪट")]
	BwiXRqKVEj = QNumy9zkeS(o4oVOHtrSlkM52Up)
	for M0J6Pq3bH2 in o4oVOHtrSlkM52Up:
		if M0J6Pq3bH2 not in list(BwiXRqKVEj.keys()): continue
		xbkrlD0EILwKiPB68MhNpRuA,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms,hhQUWqJdBPRlcf5kVLTG,ff2PVpLIujFJ4zEwOK,YafC2eqinBLW1sUOlKjp,UTOaf9HYGNCwi,ll63KQXzDgA9uLqt7Vbi = BwiXRqKVEj[M0J6Pq3bH2]
		if M0J6Pq3bH2==f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪठ"):
			UASDI2W9tzX6 = xbkrlD0EILwKiPB68MhNpRuA
			AA7ijcl2ZtK8MIJFfWYs41C0OpXTBr = HMO0QciekqVpLKmA(u"࠭ࠨࠨड")+Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠡࠩढ")+S6YzAlHWcCwJI18(UTOaf9HYGNCwi)+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠫࠪण")
			rgh3tEMP6vTY0dj8wV51kBbpcyIin9 = ff2PVpLIujFJ4zEwOK
		elif M0J6Pq3bH2==f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫत"):
			qWmgtXCcSI6vMrGhx = qWmgtXCcSI6vMrGhx or xbkrlD0EILwKiPB68MhNpRuA
			FS7T1IVust2XBlzEQn3w9jYCfZ += a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࠤࠥ࠲ࠠࠡࠪࠪथ")+Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms+OARzhnB9o7uYvQGFaIcZ(u"ࠫࠥ࠭द")+S6YzAlHWcCwJI18(UTOaf9HYGNCwi)+OARzhnB9o7uYvQGFaIcZ(u"ࠬ࠯ࠧध")
			DJxZ9rzHvRqnXIE4ySiufk1j67mh += L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠠࠡ࠮ࠣࠤࠬन")+ff2PVpLIujFJ4zEwOK
		elif M0J6Pq3bH2==DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ऩ"):
			b0tmCuPO1TM2yacsoQYXqhv = xbkrlD0EILwKiPB68MhNpRuA
			rzjavARsni7qJtBEDYO = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࠪࠪप")+Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms+Vv0lSjAOHLfMnam3wtdor(u"ࠩࠣࠫफ")+S6YzAlHWcCwJI18(UTOaf9HYGNCwi)+IJ6VkihabRm(u"ࠪ࠭ࠬब")
			x7YVBvXRPsCwEihS = ff2PVpLIujFJ4zEwOK
	FS7T1IVust2XBlzEQn3w9jYCfZ = FS7T1IVust2XBlzEQn3w9jYCfZ.strip(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࠥࠦࠬࠡࠢࠪभ"))
	DJxZ9rzHvRqnXIE4ySiufk1j67mh = DJxZ9rzHvRqnXIE4ySiufk1j67mh.strip(IJ6VkihabRm(u"ࠬࠦࠠ࠭ࠢࠣࠫम"))
	TNdKcREB9AwzlF6r0aHv  = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭य")+rgh3tEMP6vTY0dj8wV51kBbpcyIin9+vkMRnTNV9jFm(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩर")
	TNdKcREB9AwzlF6r0aHv += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ࡞ࡱࠫऱ")+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ल")+AA7ijcl2ZtK8MIJFfWYs41C0OpXTBr+zOZvXaebGNwHKfjRA(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬळ")
	TNdKcREB9AwzlF6r0aHv += GGTRaYBDeNyI25zlF(u"ࠫࡡࡴ࡜࡯ࠩऴ")+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬव")+DJxZ9rzHvRqnXIE4ySiufk1j67mh+dxAs4otSE98YmZnKy2iwRCB(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨश")
	TNdKcREB9AwzlF6r0aHv += iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧ࡝ࡰࠪष")+fcIm8tvxlXZsaEY3bwuG4B(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬस")+FS7T1IVust2XBlzEQn3w9jYCfZ+vkMRnTNV9jFm(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫह")
	TNdKcREB9AwzlF6r0aHv += p1lrNRIXqLQJznH6O(u"ࠪࡠࡳࡢ࡮ࠨऺ")+HMO0QciekqVpLKmA(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪऻ")+x7YVBvXRPsCwEihS+uhOkAKtLVv4XTy1nWE6(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ़ࠧ")
	TNdKcREB9AwzlF6r0aHv += uhOkAKtLVv4XTy1nWE6(u"࠭࡜࡯ࠩऽ")+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪा")+rzjavARsni7qJtBEDYO+zOZvXaebGNwHKfjRA(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪि")
	xbkrlD0EILwKiPB68MhNpRuA = (UASDI2W9tzX6 or qWmgtXCcSI6vMrGhx)
	if xbkrlD0EILwKiPB68MhNpRuA:
		header = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫी")
		rrnXRv2bFCatYNc6f0 = qNZKwi2M1S4fBzGQYrmPnea(u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫु")
	else:
		header = OARzhnB9o7uYvQGFaIcZ(u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬू")
		rrnXRv2bFCatYNc6f0 = DKqQekNtF6WlJLhBP9M5ca(u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧृ")
	ys2dHnSYIkaeo10cJzZWGA4VpNbf = zOZvXaebGNwHKfjRA(u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧॄ")
	IlOkTCHa8NoehuU9X6zbA = TNdKcREB9AwzlF6r0aHv+fcIm8tvxlXZsaEY3bwuG4B(u"ࠧ࡝ࡰ࡟ࡲࠬॅ")+rrnXRv2bFCatYNc6f0+uhOkAKtLVv4XTy1nWE6(u"ࠨ࡞ࡱࡠࡳ࠭ॆ")+ys2dHnSYIkaeo10cJzZWGA4VpNbf
	qQL7e23RtCg4xOpf(V391t7nQWUBR5euCkJ(u"ࠩࡵ࡭࡬࡮ࡴࠨे"),header,IlOkTCHa8NoehuU9X6zbA,xxpPYJOnoAUrlBzyveui(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ै"))
	return
def QpwoVDjc2Kir4GtfEuyJkUzX5YsR(showDialogs,Wk6n1DxB8awu0UTsvIZjKl4):
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,v7reLlOXCgD5pZ14w2tUA(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧॉ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ॊ"))
	if showDialogs:
		ISLxc2mBCWFjilUwn()
		zztDMTj1Fcd2xLfpNr()
	if Wk6n1DxB8awu0UTsvIZjKl4:
		i1eUnRIqv39loL(GGTRaYBDeNyI25zlF(u"ࡋࡧ࡬ࡴࡧૄ"))
		KdsoYmHkjqCTZX7 = [OARzhnB9o7uYvQGFaIcZ(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫो"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ौ"),zOZvXaebGNwHKfjRA(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ्ࠪ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ॎ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧॏ")]
		for FuEU2h6k41VvYlnBwj in KdsoYmHkjqCTZX7:
			BcMl3XdLS0zmK1jPvDJANfYH,i9bg5DnP3kQv7hwWpCz6,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms = QnXFVhjS03wM6d2DUGfZKgb4l(FuEU2h6k41VvYlnBwj,KbL94nDHufSF0VcO2Nk3(u"ࡔࡳࡷࡨ૆"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡌࡡ࡭ࡵࡨૅ"))
		EE0PlFd2ec9Ao(showDialogs)
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(ZpH2IWt7veyFobTsAnhi41(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨॐ"))
	return
def umWlhxIPytXBK2H4Voq8p(t0tRympesDwbuB=iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ॑"),showDialogs=u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࡕࡴࡸࡩે")):
	AsqvTSMpVNy = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(p1lrNRIXqLQJznH6O(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾ॒ࠩ"))
	import json as I3Iv0rxGQgMjk6bJLiaEcWZR
	data = I3Iv0rxGQgMjk6bJLiaEcWZR.loads(AsqvTSMpVNy)
	jgwER8GO3ceZTx1UhqD = data[DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡳࡧࡶࡹࡱࡺࠧ॓")][Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࡸࡤࡰࡺ࡫ࠧ॔")]
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: jgwER8GO3ceZTx1UhqD = jgwER8GO3ceZTx1UhqD.encode(ZpH2IWt7veyFobTsAnhi41(u"ࠩࡸࡸ࡫࠾ࠧॕ"))
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࠫॖ"),vkMRnTNV9jFm(u"ࠫࠬॗ"),zOZvXaebGNwHKfjRA(u"ࠬ࠭क़"),KbL94nDHufSF0VcO2Nk3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩख़"),xxpPYJOnoAUrlBzyveui(u"่ࠧๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠอๆาࠤࠬग़")+jgwER8GO3ceZTx1UhqD+vkMRnTNV9jFm(u"ࠨࠢส่ี๐ࠠๆีอาิ๋ࠠศๆล๊ࠥ็๊ࠡๅ๋ำ๏ࠦลๅ๋ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะࠢࠪज़")+t0tRympesDwbuB+xxBJoKG54uwQ(u"ࠩࠣรࠦ࠭ड़"))
		if T4TGmZ9XWAzONaKygic!=lunVJF2G5bZMgTcCje0vaIB371SX(u"࠳੻"): return ZpH2IWt7veyFobTsAnhi41(u"ࡈࡤࡰࡸ࡫ૈ")
	BcMl3XdLS0zmK1jPvDJANfYH,i9bg5DnP3kQv7hwWpCz6,qYJeF0pb12lWCATDmu7s = QnXFVhjS03wM6d2DUGfZKgb4l(t0tRympesDwbuB,xxpPYJOnoAUrlBzyveui(u"ࡉࡥࡱࡹࡥૉ"),xxpPYJOnoAUrlBzyveui(u"ࡉࡥࡱࡹࡥૉ"))
	if BcMl3XdLS0zmK1jPvDJANfYH:
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(HMO0QciekqVpLKmA(u"ࠪࠫढ़"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࠬफ़"),xxpPYJOnoAUrlBzyveui(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨय़"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭สๆฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ะ้ีࠠศๆฯำ๏ี้้๋ࠠࠤัอ็ำࠢ็่ฬูสฯัส้ࠥ࠴ࠠิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦส฻์ํีࠥหูะษาหฯࠦใ้ัํࠤ้้๊ࠡ์ึฮ฾๋ไࠡษ็ะ้ีࠠศๆฯำ๏ีࠠษั็ห๋ࠥๆࠡษ็ๆิ๐ๅࠨॠ"))
		t78SOQHR9JTBNAa = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(xxpPYJOnoAUrlBzyveui(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠥࠫॡ")+t0tRympesDwbuB+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࠤࢀࢁࠬॢ"))
		if gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡒࡏࠬॣ") in t78SOQHR9JTBNAa: BcMl3XdLS0zmK1jPvDJANfYH = q0JfWbP8vACLxSNIncpOXkR6j(u"ࡘࡷࡻࡥ૊")
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(q0JfWbP8vACLxSNIncpOXkR6j(u"࠴੼"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(xxBJoKG54uwQ(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ।"))
	elif showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࠬ॥"),OARzhnB9o7uYvQGFaIcZ(u"ࠬ࠭०"),v7reLlOXCgD5pZ14w2tUA(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ१"),Vv0lSjAOHLfMnam3wtdor(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩ२"))
	return BcMl3XdLS0zmK1jPvDJANfYH
def ua95I6RK27wGQgmYXqc(M0J6Pq3bH2,showDialogs=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࡙ࡸࡵࡦો")):
	if showDialogs==ZpH2IWt7veyFobTsAnhi41(u"ࠨࠩ३"): showDialogs = xxBJoKG54uwQ(u"࡚ࡲࡶࡧૌ")
	SQPqxUhbB7ZV8WECRoe6Tf5 = vtrSgBxFJ8HuO5mUqV0blNko1C([M0J6Pq3bH2])
	yyeTwX3xSdtquYh1mZo,EBfgyuHClxLv4XMQTwtn = SQPqxUhbB7ZV8WECRoe6Tf5[M0J6Pq3bH2]
	if EBfgyuHClxLv4XMQTwtn:
		BcMl3XdLS0zmK1jPvDJANfYH = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡔࡳࡷࡨ્")
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࠪ४"),v7reLlOXCgD5pZ14w2tUA(u"ࠪࠫ५"),OARzhnB9o7uYvQGFaIcZ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ६"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧ७")+M0J6Pq3bH2+xxpPYJOnoAUrlBzyveui(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩ८"))
	else:
		BcMl3XdLS0zmK1jPvDJANfYH = DKqQekNtF6WlJLhBP9M5ca(u"ࡇࡣ࡯ࡷࡪ૎")
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(OARzhnB9o7uYvQGFaIcZ(u"ࠧࡤࡧࡱࡸࡪࡸࠧ९"),DDS79jdWzLtE(u"ࠨࠩ॰"),zOZvXaebGNwHKfjRA(u"ࠩࠪॱ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ॲ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࠬॳ")+M0J6Pq3bH2+DKqQekNtF6WlJLhBP9M5ca(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪॴ"))
		if T4TGmZ9XWAzONaKygic==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠵੽"):
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(xxpPYJOnoAUrlBzyveui(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ॵ")+M0J6Pq3bH2+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࠪࠩॶ"))
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(Vv0lSjAOHLfMnam3wtdor(u"࠶੾"))
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(xxpPYJOnoAUrlBzyveui(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨॷ"))
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠷੿"))
			while AAsbUG0jZ5igBpNKQwFrJTd.getCondVisibility(OARzhnB9o7uYvQGFaIcZ(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭ॸ")): vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(OARzhnB9o7uYvQGFaIcZ(u"࠱઀"))
			t78SOQHR9JTBNAa = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ॹ")+M0J6Pq3bH2+uhOkAKtLVv4XTy1nWE6(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩॺ"))
			if OARzhnB9o7uYvQGFaIcZ(u"ࠬࡕࡋࠨॻ") in t78SOQHR9JTBNAa:
				BcMl3XdLS0zmK1jPvDJANfYH = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡖࡵࡹࡪ૏")
				if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ZpH2IWt7veyFobTsAnhi41(u"࠭ࠧॼ"),OARzhnB9o7uYvQGFaIcZ(u"ࠧࠨॽ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫॾ"),KbL94nDHufSF0VcO2Nk3(u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨॿ"))
			elif showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxBJoKG54uwQ(u"ࠪࠫঀ"),OARzhnB9o7uYvQGFaIcZ(u"ࠫࠬঁ"),zOZvXaebGNwHKfjRA(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨং"),HMO0QciekqVpLKmA(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨঃ"))
	return BcMl3XdLS0zmK1jPvDJANfYH
def m3mVZFewTaygB(M0J6Pq3bH2,ll63KQXzDgA9uLqt7Vbi,showDialogs):
	BcMl3XdLS0zmK1jPvDJANfYH = ddK4MmwpX5oG(u"ࡉࡥࡱࡹࡥૐ")
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(p1lrNRIXqLQJznH6O(u"ࠧࠨ঄"),zOZvXaebGNwHKfjRA(u"ࠨࠩঅ"),xxBJoKG54uwQ(u"ࠩࠪআ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ই"),q0JfWbP8vACLxSNIncpOXkR6j(u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧঈ"))
		if T4TGmZ9XWAzONaKygic!=DDS79jdWzLtE(u"࠲ઁ"): return fcIm8tvxlXZsaEY3bwuG4B(u"ࡊࡦࡲࡳࡦ૑")
	luj6etbY8qL0UdfPOEDyZkwvAMI = W6ndv5PCbAh(ll63KQXzDgA9uLqt7Vbi,{},showDialogs)
	if luj6etbY8qL0UdfPOEDyZkwvAMI:
		ise63NmwBv5J4AWV7OG0QuY19d = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(X8jt4IEY3WdFmbpreC2,M0J6Pq3bH2)
		Qzbnt3opXim(ise63NmwBv5J4AWV7OG0QuY19d,DKqQekNtF6WlJLhBP9M5ca(u"࡚ࡲࡶࡧ૓"),DKqQekNtF6WlJLhBP9M5ca(u"ࡋࡧ࡬ࡴࡧ૒"))
		import zipfile as eIGHfm61PoYxQ0LV5TUrSnFAdN,io as CCDUNEcJpV
		qBcSUWdo0APywjLz8RfT4IZs = CCDUNEcJpV.BytesIO(luj6etbY8qL0UdfPOEDyZkwvAMI)
		try:
			lU5ZXVDCTvWbspx8B6eQImPjt03 = eIGHfm61PoYxQ0LV5TUrSnFAdN.ZipFile(qBcSUWdo0APywjLz8RfT4IZs)
			lU5ZXVDCTvWbspx8B6eQImPjt03.extractall(X8jt4IEY3WdFmbpreC2)
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(V391t7nQWUBR5euCkJ(u"࠳ં"))
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(lunVJF2G5bZMgTcCje0vaIB371SX(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩউ"))
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(vkMRnTNV9jFm(u"࠵ઃ"))
			t78SOQHR9JTBNAa = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩঊ")+M0J6Pq3bH2+xxpPYJOnoAUrlBzyveui(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬঋ"))
			if fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡑࡎࠫঌ") in t78SOQHR9JTBNAa: BcMl3XdLS0zmK1jPvDJANfYH = V391t7nQWUBR5euCkJ(u"ࡔࡳࡷࡨ૔")
			QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,HMO0QciekqVpLKmA(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ঍"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ঎"))
		except: BcMl3XdLS0zmK1jPvDJANfYH = fcIm8tvxlXZsaEY3bwuG4B(u"ࡇࡣ࡯ࡷࡪ૕")
	if showDialogs:
		if BcMl3XdLS0zmK1jPvDJANfYH: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxpPYJOnoAUrlBzyveui(u"ࠫࠬএ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࠭ঐ"),GGTRaYBDeNyI25zlF(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ঑"),v7reLlOXCgD5pZ14w2tUA(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ঒"))
		else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠨࠩও"),GGTRaYBDeNyI25zlF(u"ࠩࠪঔ"),DDS79jdWzLtE(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ক"),iRTygNp4Lf36wQKlD2MHUhG7B(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩখ"))
	return BcMl3XdLS0zmK1jPvDJANfYH
def QnXFVhjS03wM6d2DUGfZKgb4l(M0J6Pq3bH2,showDialogs,eh5q86taAYCSXZ1PL0c2DMRBpy3sHb):
	T4TGmZ9XWAzONaKygic,BcMl3XdLS0zmK1jPvDJANfYH,i9bg5DnP3kQv7hwWpCz6,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms = xxpPYJOnoAUrlBzyveui(u"ࡗࡶࡺ࡫૗"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࡈࡤࡰࡸ࡫૖"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬগ"),DKqQekNtF6WlJLhBP9M5ca(u"࠭ࠧঘ")
	BwiXRqKVEj = QNumy9zkeS([M0J6Pq3bH2])
	if M0J6Pq3bH2 in list(BwiXRqKVEj.keys()):
		xbkrlD0EILwKiPB68MhNpRuA,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms,hhQUWqJdBPRlcf5kVLTG,ff2PVpLIujFJ4zEwOK,YafC2eqinBLW1sUOlKjp,UTOaf9HYGNCwi,ll63KQXzDgA9uLqt7Vbi = BwiXRqKVEj[M0J6Pq3bH2]
		if UTOaf9HYGNCwi==vkMRnTNV9jFm(u"ࠧࡨࡱࡲࡨࠬঙ"):
			BcMl3XdLS0zmK1jPvDJANfYH,i9bg5DnP3kQv7hwWpCz6 = vkMRnTNV9jFm(u"ࡘࡷࡻࡥ૘"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡰࡲࡸ࡭࡯࡮ࡨࠩচ")
			if eh5q86taAYCSXZ1PL0c2DMRBpy3sHb: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(DDS79jdWzLtE(u"ࠩࠪছ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࠫজ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧঝ"),uhOkAKtLVv4XTy1nWE6(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬঞ")+M0J6Pq3bH2)
		else:
			if showDialogs:
				if UTOaf9HYGNCwi==xxpPYJOnoAUrlBzyveui(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨট"): qNEnDMwm1Vfastx2ZkpRh = vkMRnTNV9jFm(u"ࠧๆฬ๋ๆๆฯࠧঠ")
				elif UTOaf9HYGNCwi==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࡱ࡯ࡨࠬড"): qNEnDMwm1Vfastx2ZkpRh = V391t7nQWUBR5euCkJ(u"ࠩๅำ๏๋ษࠨঢ")
				elif UTOaf9HYGNCwi==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫণ"): qNEnDMwm1Vfastx2ZkpRh = ZpH2IWt7veyFobTsAnhi41(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧত")
				T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(xxBJoKG54uwQ(u"ࠬ࠭থ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࠧদ"),ZpH2IWt7veyFobTsAnhi41(u"ࠧࠨধ"),xxpPYJOnoAUrlBzyveui(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫন"),lunVJF2G5bZMgTcCje0vaIB371SX(u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨ঩")+qNEnDMwm1Vfastx2ZkpRh+vkMRnTNV9jFm(u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬপ")+M0J6Pq3bH2)
			if not T4TGmZ9XWAzONaKygic: i9bg5DnP3kQv7hwWpCz6 = DDS79jdWzLtE(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ফ")
			else:
				if UTOaf9HYGNCwi==xxBJoKG54uwQ(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧব"):
					RRMWBwU6pG = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(OARzhnB9o7uYvQGFaIcZ(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩভ")+M0J6Pq3bH2+qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬম"))
					if iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡑࡎࠫয") in RRMWBwU6pG:
						BcMl3XdLS0zmK1jPvDJANfYH,i9bg5DnP3kQv7hwWpCz6 = zOZvXaebGNwHKfjRA(u"࡙ࡸࡵࡦ૙"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪর")
						if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(GGTRaYBDeNyI25zlF(u"ࠪࠫ঱"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࠬল"),vkMRnTNV9jFm(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ঳"),Vv0lSjAOHLfMnam3wtdor(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫ঴")+M0J6Pq3bH2)
					elif showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxBJoKG54uwQ(u"ࠧࠨ঵"),ddK4MmwpX5oG(u"ࠨࠩশ"),vkMRnTNV9jFm(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬষ"),DKqQekNtF6WlJLhBP9M5ca(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭স")+M0J6Pq3bH2)
				elif UTOaf9HYGNCwi in [zOZvXaebGNwHKfjRA(u"ࠫࡴࡲࡤࠨহ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭঺")]:
					BcMl3XdLS0zmK1jPvDJANfYH = m3mVZFewTaygB(M0J6Pq3bH2,ll63KQXzDgA9uLqt7Vbi,V391t7nQWUBR5euCkJ(u"ࡌࡡ࡭ࡵࡨ૚"))
					if BcMl3XdLS0zmK1jPvDJANfYH:
						if UTOaf9HYGNCwi==xxBJoKG54uwQ(u"࠭࡯࡭ࡦࠪ঻"): i9bg5DnP3kQv7hwWpCz6 = p1lrNRIXqLQJznH6O(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ়")
						elif UTOaf9HYGNCwi==qNZKwi2M1S4fBzGQYrmPnea(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩঽ"): i9bg5DnP3kQv7hwWpCz6 = qNZKwi2M1S4fBzGQYrmPnea(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬা")
						Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms = ff2PVpLIujFJ4zEwOK
						if showDialogs:
							if i9bg5DnP3kQv7hwWpCz6==v7reLlOXCgD5pZ14w2tUA(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫি"): qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࠬী"),zOZvXaebGNwHKfjRA(u"ࠬ࠭ু"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩূ"),v7reLlOXCgD5pZ14w2tUA(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬࠣๆิ๐ๅสࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฮัํฯ์อ࡜࡯࡞ࡱࠫৃ")+M0J6Pq3bH2)
							elif i9bg5DnP3kQv7hwWpCz6==q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫৄ"): qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࠪ৅"),ZpH2IWt7veyFobTsAnhi41(u"ࠪࠫ৆"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧে"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ৈ")+M0J6Pq3bH2)
					elif showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࠧ৉"),v7reLlOXCgD5pZ14w2tUA(u"ࠧࠨ৊"),xxpPYJOnoAUrlBzyveui(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫো"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬৌ")+M0J6Pq3bH2)
	elif showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"্ࠪࠫ"),HMO0QciekqVpLKmA(u"ࠫࠬৎ"),V391t7nQWUBR5euCkJ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ৏"),fcIm8tvxlXZsaEY3bwuG4B(u"࠭ไๅลึๅࠥ࠴࠮้ࠡำ๋ࠥอไฦุสๅฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪ৐")+M0J6Pq3bH2)
	return BcMl3XdLS0zmK1jPvDJANfYH,i9bg5DnP3kQv7hwWpCz6,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'DAILYMOTION'
JE7QrkmhletLwA0OZXu = '_DLM_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
FWpjdmYqwgi = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][1]
def hLD0mk9HIuPOz7pw(mode,url,text,type,YSTbrKgPf7NyhIDizB):
	if	 mode==400: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==401: RRMWBwU6pG = luUq2eO3HGRsyao8ZvnDXmpc(url,text)
	elif mode==402: RRMWBwU6pG = Msz94cPOmFwqjt1LuTebdnglXV7xr(url,text)
	elif mode==403: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url,text)
	elif mode==404: RRMWBwU6pG = nHrBWRNMDmlewFG53V6co(text,YSTbrKgPf7NyhIDizB)
	elif mode==405: RRMWBwU6pG = D89pxaUK2rSRcvmQ541GEnXwN(text,YSTbrKgPf7NyhIDizB)
	elif mode==406: RRMWBwU6pG = ZN2P4dyrhUmpVWsckeil6w3K(text,YSTbrKgPf7NyhIDizB)
	elif mode==407: RRMWBwU6pG = PIKTkeJ6UBonpCW(url,YSTbrKgPf7NyhIDizB)
	elif mode==408: RRMWBwU6pG = zBm4WLFbZRw(url,YSTbrKgPf7NyhIDizB)
	elif mode==409: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text,YSTbrKgPf7NyhIDizB)
	elif mode==411: RRMWBwU6pG = TTh1yIapcge8EdYWXUO7M2su0N(url,text)
	elif mode==412: RRMWBwU6pG = iKDfOa1PXwegYuLACV5(text,YSTbrKgPf7NyhIDizB)
	elif mode==413: RRMWBwU6pG = ZZy7agwxIr(url,YSTbrKgPf7NyhIDizB)
	elif mode==414: RRMWBwU6pG = B5tsyv6pHgNw0x8VchiCTlA(text)
	elif mode==415: RRMWBwU6pG = QgESNqJl7HptR8IV9M4KnYbekwf(text,YSTbrKgPf7NyhIDizB)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الرئيسية','',414)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def Msz94cPOmFwqjt1LuTebdnglXV7xr(url,XxIGVcwZTJmhdO26ynPzr7):
	if '/dm_' in url:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = nbdMp8UuhzP3oq4cDWj6eyZVt.headers
		if 'Location' in list(headers.keys()): url = GqcEfFR8XQPgBMLr+headers['Location']
	XxIGVcwZTJmhdO26ynPzr7 = '[COLOR FFC89008]'+XxIGVcwZTJmhdO26ynPzr7+'[/COLOR]'
	XxIGVcwZTJmhdO26ynPzr7 = SSOAhFK12wfRTWytnDJxpoPuI6Q(XxIGVcwZTJmhdO26ynPzr7)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: بث حي',url,411,'','','channel_lives_now')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: آخر الفيديوهات',url+'/videos',408)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: المميزة',url,411,'','','channel_featured_videos')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: قوائم التشغيل',url+'/playlists',407)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def SSOAhFK12wfRTWytnDJxpoPuI6Q(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = kWfpQA7tTjSPyLbNIeMr1Hui5(title)
	return title
def unQmcpAEF2DaNX87fTgMW(url,FFKnMSt5ROf9PLeBd):
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP([url],mm5vCBc4DOz2Fj,'video',url)
	return
def nHrBWRNMDmlewFG53V6co(search,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysearchwords',search)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	if sort=='': lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysortmethod','')
	else: lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = GqcEfFR8XQPgBMLr+'/search/'+search+'/videos'
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"videos"(.*?)"VideoConnection"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for id,title,f4fpOM6zyuQNZ7is,XxIGVcwZTJmhdO26ynPzr7,VVaBpWQDAfx5dO4GSMmstz78eRFYw,G2WR0Oacvdq8ZQTjKboDU in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('"','')
			if '"' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.replace('"','')
			if '"' in f4fpOM6zyuQNZ7is: f4fpOM6zyuQNZ7is = f4fpOM6zyuQNZ7is.replace('"','')
			if '"' in XxIGVcwZTJmhdO26ynPzr7: XxIGVcwZTJmhdO26ynPzr7 = XxIGVcwZTJmhdO26ynPzr7.replace('"','')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+id
			title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
			FFKnMSt5ROf9PLeBd = f4fpOM6zyuQNZ7is+'::'+XxIGVcwZTJmhdO26ynPzr7
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,403,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw,FFKnMSt5ROf9PLeBd)
		if '"hasNextPage":true' in Ht6Gg8lbciAd9FaUQVs:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,404,'',YSTbrKgPf7NyhIDizB,search)
	return
def D89pxaUK2rSRcvmQ541GEnXwN(search,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysearchwords',search)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	url = GqcEfFR8XQPgBMLr+'/search/'+search+'/playlists'
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	items = QPuHKNAT4jmCRg.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for id,name,S95E1QITqFlPZs7HRGgCmruAey,f4fpOM6zyuQNZ7is,XxIGVcwZTJmhdO26ynPzr7,G2WR0Oacvdq8ZQTjKboDU,count in items:
		if '"' in S95E1QITqFlPZs7HRGgCmruAey: S95E1QITqFlPZs7HRGgCmruAey = S95E1QITqFlPZs7HRGgCmruAey.replace('"','')
		if '"' in f4fpOM6zyuQNZ7is: f4fpOM6zyuQNZ7is = f4fpOM6zyuQNZ7is.replace('"','')
		if '"' in XxIGVcwZTJmhdO26ynPzr7: XxIGVcwZTJmhdO26ynPzr7 = XxIGVcwZTJmhdO26ynPzr7.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('"','')
		if '"' in count: count = count.replace('"','')
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
		FFKnMSt5ROf9PLeBd = f4fpOM6zyuQNZ7is+'::'+XxIGVcwZTJmhdO26ynPzr7
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,401,G2WR0Oacvdq8ZQTjKboDU,'',FFKnMSt5ROf9PLeBd)
	if '"hasNextPage":true' in Ht6Gg8lbciAd9FaUQVs:
		YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,405,'',YSTbrKgPf7NyhIDizB,search)
	return
def ZN2P4dyrhUmpVWsckeil6w3K(search,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysearchwords',search)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	url = GqcEfFR8XQPgBMLr+'/search/'+search+'/channels'
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"channels"(.*?)"ChannelConnection"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for id,name,G2WR0Oacvdq8ZQTjKboDU in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('"','')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+id
			title = 'CHNL:  '+name
			title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,402,G2WR0Oacvdq8ZQTjKboDU,'',name)
		if '"hasNextPage":true' in Ht6Gg8lbciAd9FaUQVs:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,406,'',YSTbrKgPf7NyhIDizB,search)
	return
def B5tsyv6pHgNw0x8VchiCTlA(VQviq4lCPFDAg9z0keBpoGrb23wu):
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	Rg2lOUamtETwQq9V = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	if Rg2lOUamtETwQq9V:
		T0tZeBSgkQ1 = kMLWTt2fO9dnGDUgHh('dict',Rg2lOUamtETwQq9V)
		MmvB7RSi4yGCU6cgEnOJ0 = T0tZeBSgkQ1['data']['home']['neon']['sections']['edges']
		if not VQviq4lCPFDAg9z0keBpoGrb23wu:
			h4vELlHzSNwpRgbfoTx6FVCkO7y8Z = []
			for aNtz5oWfJeC8Yb3npgcOTAsdj10 in MmvB7RSi4yGCU6cgEnOJ0:
				ElHn6OgwBufb09MAL = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['title']
				if ElHn6OgwBufb09MAL not in h4vELlHzSNwpRgbfoTx6FVCkO7y8Z: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+ElHn6OgwBufb09MAL,'',414,'','',ElHn6OgwBufb09MAL)
				h4vELlHzSNwpRgbfoTx6FVCkO7y8Z.append(ElHn6OgwBufb09MAL)
		else:
			for aNtz5oWfJeC8Yb3npgcOTAsdj10 in MmvB7RSi4yGCU6cgEnOJ0:
				ElHn6OgwBufb09MAL = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['title']
				if ElHn6OgwBufb09MAL==VQviq4lCPFDAg9z0keBpoGrb23wu:
					TOmYM9CfhP5Ukjy8 = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['components']['edges']
					for mmaMnsDwNQU2yBJriLfjhk46 in TOmYM9CfhP5Ukjy8:
						VVaBpWQDAfx5dO4GSMmstz78eRFYw = str(mmaMnsDwNQU2yBJriLfjhk46['node']['duration'])
						title = kWfpQA7tTjSPyLbNIeMr1Hui5(mmaMnsDwNQU2yBJriLfjhk46['node']['title'])
						title = title.replace('\/','/')
						iCpTbL2ldWyZ6QguEOAeN37 = mmaMnsDwNQU2yBJriLfjhk46['node']['xid']
						G2WR0Oacvdq8ZQTjKboDU = mmaMnsDwNQU2yBJriLfjhk46['node']['thumbnailx480']
						G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('\/','/')
						VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+iCpTbL2ldWyZ6QguEOAeN37
						fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,403,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw)
	return
def QgESNqJl7HptR8IV9M4KnYbekwf(search,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysearchwords',search)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	url = GqcEfFR8XQPgBMLr+'/search/'+search+'/lives'
	Rg2lOUamtETwQq9V = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	if Rg2lOUamtETwQq9V:
		T0tZeBSgkQ1 = kMLWTt2fO9dnGDUgHh('dict',Rg2lOUamtETwQq9V)
		try: MmvB7RSi4yGCU6cgEnOJ0 = T0tZeBSgkQ1['data']['search']['lives']['edges']
		except: MmvB7RSi4yGCU6cgEnOJ0 = []
		for aNtz5oWfJeC8Yb3npgcOTAsdj10 in MmvB7RSi4yGCU6cgEnOJ0:
			name = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['title']
			iCpTbL2ldWyZ6QguEOAeN37 = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['xid']
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+iCpTbL2ldWyZ6QguEOAeN37
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+'LIVE: '+name,VV7yf2htDCBU6EeSX8TJQM,403)
		if '"hasNextPage":true' in Rg2lOUamtETwQq9V:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,415,'',YSTbrKgPf7NyhIDizB,search)
	return
def iKDfOa1PXwegYuLACV5(search,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysearchwords',search)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	url = GqcEfFR8XQPgBMLr+'/search/'+search+'/topics'
	Rg2lOUamtETwQq9V = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	if Rg2lOUamtETwQq9V:
		T0tZeBSgkQ1 = kMLWTt2fO9dnGDUgHh('dict',Rg2lOUamtETwQq9V)
		try: MmvB7RSi4yGCU6cgEnOJ0 = T0tZeBSgkQ1['data']['search']['topics']['edges']
		except: MmvB7RSi4yGCU6cgEnOJ0 = []
		for aNtz5oWfJeC8Yb3npgcOTAsdj10 in MmvB7RSi4yGCU6cgEnOJ0:
			name = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['name']
			iCpTbL2ldWyZ6QguEOAeN37 = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['xid']
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/topic/'+iCpTbL2ldWyZ6QguEOAeN37
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'TOPIC: '+name,VV7yf2htDCBU6EeSX8TJQM,413)
		if '"hasNextPage":true' in Rg2lOUamtETwQq9V:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,412,'',YSTbrKgPf7NyhIDizB,search)
	return
def ZZy7agwxIr(url,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	iCpTbL2ldWyZ6QguEOAeN37 = url.split('/')[-1]
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mytopicid',iCpTbL2ldWyZ6QguEOAeN37)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	Rg2lOUamtETwQq9V = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	if Rg2lOUamtETwQq9V:
		T0tZeBSgkQ1 = kMLWTt2fO9dnGDUgHh('dict',Rg2lOUamtETwQq9V)
		MmvB7RSi4yGCU6cgEnOJ0 = T0tZeBSgkQ1['data']['topic']['videos']['edges']
		for aNtz5oWfJeC8Yb3npgcOTAsdj10 in MmvB7RSi4yGCU6cgEnOJ0:
			VVaBpWQDAfx5dO4GSMmstz78eRFYw = str(aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['duration'])
			title = kWfpQA7tTjSPyLbNIeMr1Hui5(aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['title'])
			title = title.replace('\/','/')
			iCpTbL2ldWyZ6QguEOAeN37 = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['xid']
			G2WR0Oacvdq8ZQTjKboDU = aNtz5oWfJeC8Yb3npgcOTAsdj10['node']['thumbnailx480']
			G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('\/','/')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+iCpTbL2ldWyZ6QguEOAeN37
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,403,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw)
		if '"hasNextPage":true' in Rg2lOUamtETwQq9V:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,413,'',YSTbrKgPf7NyhIDizB)
	return
def luUq2eO3HGRsyao8ZvnDXmpc(url,FFKnMSt5ROf9PLeBd):
	id = url.split('/')[-1]
	f4fpOM6zyuQNZ7is,XxIGVcwZTJmhdO26ynPzr7 = FFKnMSt5ROf9PLeBd.split('::',1)
	VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+f4fpOM6zyuQNZ7is
	XxIGVcwZTJmhdO26ynPzr7 = SSOAhFK12wfRTWytnDJxpoPuI6Q(XxIGVcwZTJmhdO26ynPzr7)
	title = '[COLOR FFC89008]OWNER:  '+XxIGVcwZTJmhdO26ynPzr7+'[/COLOR]'
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,402,'','',XxIGVcwZTJmhdO26ynPzr7)
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('myplaylistid',id)
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"collection_videos"(.*?)"SectionEdge"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for id,title,VVaBpWQDAfx5dO4GSMmstz78eRFYw,G2WR0Oacvdq8ZQTjKboDU,f4fpOM6zyuQNZ7is,XxIGVcwZTJmhdO26ynPzr7 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('"','')
			if '"' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.replace('"','')
			if '"' in f4fpOM6zyuQNZ7is: f4fpOM6zyuQNZ7is = f4fpOM6zyuQNZ7is.replace('"','')
			if '"' in XxIGVcwZTJmhdO26ynPzr7: XxIGVcwZTJmhdO26ynPzr7 = XxIGVcwZTJmhdO26ynPzr7.replace('"','')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+id
			title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
			FFKnMSt5ROf9PLeBd = f4fpOM6zyuQNZ7is+'::'+XxIGVcwZTJmhdO26ynPzr7
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,403,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw,FFKnMSt5ROf9PLeBd)
	return
def zBm4WLFbZRw(url,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	p2pr9R1hOVsHIlJnFB6PDKMx = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mychannelid',p2pr9R1hOVsHIlJnFB6PDKMx)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysortmethod',sort)
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for id,title,VVaBpWQDAfx5dO4GSMmstz78eRFYw,f4fpOM6zyuQNZ7is,XxIGVcwZTJmhdO26ynPzr7,G2WR0Oacvdq8ZQTjKboDU in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('"','')
			if '"' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.replace('"','')
			if '"' in f4fpOM6zyuQNZ7is: f4fpOM6zyuQNZ7is = f4fpOM6zyuQNZ7is.replace('"','')
			if '"' in XxIGVcwZTJmhdO26ynPzr7: XxIGVcwZTJmhdO26ynPzr7 = XxIGVcwZTJmhdO26ynPzr7.replace('"','')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+id
			title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
			FFKnMSt5ROf9PLeBd = f4fpOM6zyuQNZ7is+'::'+XxIGVcwZTJmhdO26ynPzr7
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,403,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw,FFKnMSt5ROf9PLeBd)
		if '"hasNextPage":true' in Ht6Gg8lbciAd9FaUQVs:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,408,'',YSTbrKgPf7NyhIDizB)
	return
def PIKTkeJ6UBonpCW(url,YSTbrKgPf7NyhIDizB=''):
	if YSTbrKgPf7NyhIDizB=='': YSTbrKgPf7NyhIDizB = '1'
	p2pr9R1hOVsHIlJnFB6PDKMx = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mychannelid',p2pr9R1hOVsHIlJnFB6PDKMx)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagelimit','40')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mypagenumber',YSTbrKgPf7NyhIDizB)
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mysortmethod',sort)
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for id,name,G2WR0Oacvdq8ZQTjKboDU,count,S95E1QITqFlPZs7HRGgCmruAey,f4fpOM6zyuQNZ7is,XxIGVcwZTJmhdO26ynPzr7 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in S95E1QITqFlPZs7HRGgCmruAey: S95E1QITqFlPZs7HRGgCmruAey = S95E1QITqFlPZs7HRGgCmruAey.replace('"','')
			if '"' in f4fpOM6zyuQNZ7is: f4fpOM6zyuQNZ7is = f4fpOM6zyuQNZ7is.replace('"','')
			if '"' in XxIGVcwZTJmhdO26ynPzr7: XxIGVcwZTJmhdO26ynPzr7 = XxIGVcwZTJmhdO26ynPzr7.replace('"','')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
			FFKnMSt5ROf9PLeBd = f4fpOM6zyuQNZ7is+'::'+XxIGVcwZTJmhdO26ynPzr7
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,401,G2WR0Oacvdq8ZQTjKboDU,'',FFKnMSt5ROf9PLeBd)
		if '"hasNextPage":true' in Ht6Gg8lbciAd9FaUQVs:
			YSTbrKgPf7NyhIDizB = str(int(YSTbrKgPf7NyhIDizB)+1)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+YSTbrKgPf7NyhIDizB,url,407,'',YSTbrKgPf7NyhIDizB)
	return
def TTh1yIapcge8EdYWXUO7M2su0N(url,NnG4mudLhKovqHj8Ci):
	p2pr9R1hOVsHIlJnFB6PDKMx = url.split('/')[3]
	lp3eGht9uF4mMCR6YIWz = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('mychannelid',p2pr9R1hOVsHIlJnFB6PDKMx)
	Ht6Gg8lbciAd9FaUQVs = lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz)
	import json as I3Iv0rxGQgMjk6bJLiaEcWZR
	G1X9uLDwcM = I3Iv0rxGQgMjk6bJLiaEcWZR.loads(Ht6Gg8lbciAd9FaUQVs)
	try: items = G1X9uLDwcM['data']['channel'][NnG4mudLhKovqHj8Ci]['edges']
	except: items = []
	if not items: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+'لا توجد نتائج','',9999)
	else:
		for F5o1sgcqZVlS in items:
			YwCq7XJIFAp = F5o1sgcqZVlS['node']
			iCpTbL2ldWyZ6QguEOAeN37 = YwCq7XJIFAp['xid']
			keys = list(YwCq7XJIFAp.keys())
			Pf2zT4w8haBp3rvsSbUOQluA1K7E = YwCq7XJIFAp['__typename'].lower()
			if Pf2zT4w8haBp3rvsSbUOQluA1K7E=='channel':
				name = YwCq7XJIFAp['name']
				a7VLd8qg9RhTNecxKWCbFUno5O = YwCq7XJIFAp['displayName']
				title = 'CHNL:  '+a7VLd8qg9RhTNecxKWCbFUno5O
				G2WR0Oacvdq8ZQTjKboDU = YwCq7XJIFAp['coverURLx375']
			else:
				name = YwCq7XJIFAp['channel']['name']
				a7VLd8qg9RhTNecxKWCbFUno5O = YwCq7XJIFAp['channel']['displayName']
				title = YwCq7XJIFAp['title']
				G2WR0Oacvdq8ZQTjKboDU = YwCq7XJIFAp['thumbnailx360']
				if Pf2zT4w8haBp3rvsSbUOQluA1K7E=='live': title = 'LIVE:  '+title
			title = SSOAhFK12wfRTWytnDJxpoPuI6Q(title)
			FFKnMSt5ROf9PLeBd = name+'::'+a7VLd8qg9RhTNecxKWCbFUno5O
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
				title = title.encode('utf8')
				FFKnMSt5ROf9PLeBd = FFKnMSt5ROf9PLeBd.encode('utf8')
			if Pf2zT4w8haBp3rvsSbUOQluA1K7E=='channel':
				VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+iCpTbL2ldWyZ6QguEOAeN37
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,402,G2WR0Oacvdq8ZQTjKboDU,'',FFKnMSt5ROf9PLeBd)
			else:
				if Pf2zT4w8haBp3rvsSbUOQluA1K7E=='video': VVaBpWQDAfx5dO4GSMmstz78eRFYw = str(YwCq7XJIFAp['duration'])
				else: VVaBpWQDAfx5dO4GSMmstz78eRFYw = ''
				VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/video/'+iCpTbL2ldWyZ6QguEOAeN37
				fpjEiKI9bTc1xhoeq37vPusDJ6SB(Pf2zT4w8haBp3rvsSbUOQluA1K7E,JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,403,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw,FFKnMSt5ROf9PLeBd)
	return
def lUpLDB1Y36JGbniXCkE7HAuzIc(lp3eGht9uF4mMCR6YIWz):
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace(' \"',' \\"')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('\", ','\\", ')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('\n','\\n')
	lp3eGht9uF4mMCR6YIWz = lp3eGht9uF4mMCR6YIWz.replace('")','\\")')
	H1HBzK2Muc = yyfZbJ2aS7HPIDi3wQkOXA()
	headers = {"Authorization":H1HBzK2Muc,"Origin":GqcEfFR8XQPgBMLr}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',FWpjdmYqwgi,lp3eGht9uF4mMCR6YIWz,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	return Ht6Gg8lbciAd9FaUQVs
def yyfZbJ2aS7HPIDi3wQkOXA():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',GqcEfFR8XQPgBMLr,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	bh1t4SgJHDUE0PRGVBuNnQMax2e = QPuHKNAT4jmCRg.findall('var r="(.*?)",o="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	zh1NWqP4iB,AQNtm6j5GXKJFlLI2VsOgfqwudTE4a = bh1t4SgJHDUE0PRGVBuNnQMax2e[-1]
	bhj0Y5nSeALcUCzO4K9dtlTE7k1 = 'https://graphql.api.dailymotion.com/oauth/token'
	fLYprosxJatvUbz1nhI3GX = 'client_credentials'
	data = {'client_id':zh1NWqP4iB,'client_secret':AQNtm6j5GXKJFlLI2VsOgfqwudTE4a,'grant_type':fLYprosxJatvUbz1nhI3GX}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',bhj0Y5nSeALcUCzO4K9dtlTE7k1,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	bh1t4SgJHDUE0PRGVBuNnQMax2e = QPuHKNAT4jmCRg.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	H1pQa4NuSxEt0YIPJwDKm,Hgtp4FcrYvDULx39MWR8a = bh1t4SgJHDUE0PRGVBuNnQMax2e[0]
	H1HBzK2Muc = Hgtp4FcrYvDULx39MWR8a+" "+H1pQa4NuSxEt0YIPJwDKm
	return H1HBzK2Muc
def mt4qhKoi9ynlYXFRszgZ7b3wr(search,type=''):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not type and showDialogs:
		DBXquSbAarJOZy21en5 = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('موقع ديلي موشن - اختر البحث',DBXquSbAarJOZy21en5)
		if ShT1xUHjlDotkRuPq7gv==-1: return
		elif ShT1xUHjlDotkRuPq7gv==0: type = 'videos?sortBy='
		elif ShT1xUHjlDotkRuPq7gv==1: type = 'videos?sortBy=RECENT'
		elif ShT1xUHjlDotkRuPq7gv==2: type = 'videos?sortBy=VIEW_COUNT'
		elif ShT1xUHjlDotkRuPq7gv==3: type = 'playlists'
		elif ShT1xUHjlDotkRuPq7gv==4: type = 'channels'
		elif ShT1xUHjlDotkRuPq7gv==5: type = 'topics'
		elif ShT1xUHjlDotkRuPq7gv==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in vwIN38HprDqTW5Sh61exF7EnA: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in vwIN38HprDqTW5Sh61exF7EnA: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in vwIN38HprDqTW5Sh61exF7EnA: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in vwIN38HprDqTW5Sh61exF7EnA: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in vwIN38HprDqTW5Sh61exF7EnA: type = 'lives'
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	if Nnxm30dfoBWRYpIC7KsQGl: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: nHrBWRNMDmlewFG53V6co(search+'/'+type)
	elif 'playlists' in type: D89pxaUK2rSRcvmQ541GEnXwN(search)
	elif 'channels' in type: ZN2P4dyrhUmpVWsckeil6w3K(search)
	elif 'topics' in type: iKDfOa1PXwegYuLACV5(search)
	elif 'lives' in type: QgESNqJl7HptR8IV9M4KnYbekwf(search)
	return
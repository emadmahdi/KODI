# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'LIVETV'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1['PYTHON'][0]
def hLD0mk9HIuPOz7pw(mode,url):
	if   mode==100: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==101: RRMWBwU6pG = F42EXtwuzB7Hl('0',True)
	elif mode==102: RRMWBwU6pG = F42EXtwuzB7Hl('1',True)
	elif mode==103: RRMWBwU6pG = F42EXtwuzB7Hl('2',True)
	elif mode==104: RRMWBwU6pG = F42EXtwuzB7Hl('3',True)
	elif mode==105: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==106: RRMWBwU6pG = F42EXtwuzB7Hl('4',True)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def F42EXtwuzB7Hl(zik0WubZQEGj9Ym35NqwF,showDialogs=True):
	JE7QrkmhletLwA0OZXu = '_TV'+zik0WubZQEGj9Ym35NqwF+'_'
	wn0kd1pEgfSy4YG = Dx3jCK6X7lktdiE(32)
	E9ODYnfpm54GJTd2xRrV = {'id':'','user':wn0kd1pEgfSy4YG,'function':'list','menu':zik0WubZQEGj9Ym35NqwF}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',GqcEfFR8XQPgBMLr,E9ODYnfpm54GJTd2xRrV,'','','','LIVETV-ITEMS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = QPuHKNAT4jmCRg.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		for PXBFxvuUlLDHGpm58 in range(len(items)):
			name = items[PXBFxvuUlLDHGpm58][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[PXBFxvuUlLDHGpm58] = items[PXBFxvuUlLDHGpm58][0],items[PXBFxvuUlLDHGpm58][1],items[PXBFxvuUlLDHGpm58][2],name,items[PXBFxvuUlLDHGpm58][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for oBQqw316KAIpOdr7R0LxkZNW5lG4y,BHgLX9GZTb2jJrWiNKE,p2pr9R1hOVsHIlJnFB6PDKMx,name,G2WR0Oacvdq8ZQTjKboDU in items:
			if '#' in oBQqw316KAIpOdr7R0LxkZNW5lG4y: continue
			if oBQqw316KAIpOdr7R0LxkZNW5lG4y!='URL': name = name+'[COLOR FFC89008]   '+oBQqw316KAIpOdr7R0LxkZNW5lG4y+'[/COLOR]'
			url = oBQqw316KAIpOdr7R0LxkZNW5lG4y+';;'+BHgLX9GZTb2jJrWiNKE+';;'+p2pr9R1hOVsHIlJnFB6PDKMx+';;'+zik0WubZQEGj9Ym35NqwF
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+''+name,url,105,G2WR0Oacvdq8ZQTjKboDU)
	else:
		if showDialogs: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def unQmcpAEF2DaNX87fTgMW(id):
	oBQqw316KAIpOdr7R0LxkZNW5lG4y,BHgLX9GZTb2jJrWiNKE,p2pr9R1hOVsHIlJnFB6PDKMx,zik0WubZQEGj9Ym35NqwF = id.split(';;')
	url = ''
	wn0kd1pEgfSy4YG = Dx3jCK6X7lktdiE(32)
	if oBQqw316KAIpOdr7R0LxkZNW5lG4y=='URL': url = p2pr9R1hOVsHIlJnFB6PDKMx
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y=='YOUTUBE':
		url = EGcFon0zR4mSL1['YOUTUBE'][0]+'/watch?v='+p2pr9R1hOVsHIlJnFB6PDKMx
		import bcQwT9tl1C
		bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP([url],mm5vCBc4DOz2Fj,'live',url)
		return
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y=='GA':
		E9ODYnfpm54GJTd2xRrV = { 'id' : '', 'user' : wn0kd1pEgfSy4YG , 'function' : 'playGA1' , 'menu' : '' }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',GqcEfFR8XQPgBMLr,E9ODYnfpm54GJTd2xRrV,'',False,'','LIVETV-PLAY-1st')
		if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		cookies = nbdMp8UuhzP3oq4cDWj6eyZVt.cookies
		gGZ6uVPSfTh25AH0kK = cookies['ASP.NET_SessionId']
		url = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		E9ODYnfpm54GJTd2xRrV = { 'id' : p2pr9R1hOVsHIlJnFB6PDKMx , 'user' : wn0kd1pEgfSy4YG , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+gGZ6uVPSfTh25AH0kK }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',GqcEfFR8XQPgBMLr,E9ODYnfpm54GJTd2xRrV,headers,'','','LIVETV-PLAY-2nd')
		if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		url = QPuHKNAT4jmCRg.findall('resp":"(http.*?m3u8)(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		VV7yf2htDCBU6EeSX8TJQM = url[0][0]
		kZtLuzN78xvem53 = url[0][1]
		wn6jEVAhs8LHQlb5iTIr4vf0gX1 = 'http://38.'+BHgLX9GZTb2jJrWiNKE+'777/'+p2pr9R1hOVsHIlJnFB6PDKMx+'_HD.m3u8'+kZtLuzN78xvem53
		RcPqfAMVnOsDeUluyS14 = wn6jEVAhs8LHQlb5iTIr4vf0gX1.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		puK2mnCbUk1f67yHZaX = wn6jEVAhs8LHQlb5iTIr4vf0gX1.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		xitERh4TD2jGJPq5Nuv39CAmg = ['HD','SD1','SD2']
		LL8heV7kxYI5bOjEZ6XaUQWwfPA = [wn6jEVAhs8LHQlb5iTIr4vf0gX1,RcPqfAMVnOsDeUluyS14,puK2mnCbUk1f67yHZaX]
		ShT1xUHjlDotkRuPq7gv = 0
		if ShT1xUHjlDotkRuPq7gv == -1: return
		else: url = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		E9ODYnfpm54GJTd2xRrV = { 'id' : p2pr9R1hOVsHIlJnFB6PDKMx , 'user' : wn0kd1pEgfSy4YG , 'function' : 'playNT' , 'menu' : zik0WubZQEGj9Ym35NqwF }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST', GqcEfFR8XQPgBMLr, E9ODYnfpm54GJTd2xRrV, headers, False,'','LIVETV-PLAY-3rd')
		if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		url = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in p2pr9R1hOVsHIlJnFB6PDKMx:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y=='PL':
		E9ODYnfpm54GJTd2xRrV = { 'id' : p2pr9R1hOVsHIlJnFB6PDKMx , 'user' : wn0kd1pEgfSy4YG , 'function' : 'playPL' , 'menu' : zik0WubZQEGj9Ym35NqwF }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST', GqcEfFR8XQPgBMLr, E9ODYnfpm54GJTd2xRrV, '',False,'','LIVETV-PLAY-4th')
		if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		url = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		headers = {'Referer':nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Referer']}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		items = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		url = items[0]
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if oBQqw316KAIpOdr7R0LxkZNW5lG4y=='TA': p2pr9R1hOVsHIlJnFB6PDKMx = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		E9ODYnfpm54GJTd2xRrV = { 'id' : p2pr9R1hOVsHIlJnFB6PDKMx , 'user' : wn0kd1pEgfSy4YG , 'function' : 'play'+oBQqw316KAIpOdr7R0LxkZNW5lG4y , 'menu' : zik0WubZQEGj9Ym35NqwF }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',GqcEfFR8XQPgBMLr,E9ODYnfpm54GJTd2xRrV,headers,'','','LIVETV-PLAY-6th')
		if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		url = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
		if oBQqw316KAIpOdr7R0LxkZNW5lG4y=='FM':
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = nbdMp8UuhzP3oq4cDWj6eyZVt.headers['Location']
			url = url.replace('https','http')
	zT3xJQIVDmCgapBljs(url,mm5vCBc4DOz2Fj,'live')
	return
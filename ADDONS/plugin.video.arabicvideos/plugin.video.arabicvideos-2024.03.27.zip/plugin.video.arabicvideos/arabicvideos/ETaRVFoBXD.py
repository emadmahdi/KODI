# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
headers = { 'User-Agent' : '' }
mm5vCBc4DOz2Fj = 'AKWAM'
JE7QrkmhletLwA0OZXu = '_AKW_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
KA4gLzraxpeMJcSydY = ''
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==240: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==241: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==242: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==243: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==244: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'FILTERS___'+text)
	elif mode==245: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'CATEGORIES___'+text)
	elif mode==246: RRMWBwU6pG = dy36UlWO8j(url)
	elif mode==247: RRMWBwU6pG = nCV2JkIN9LWFy6t8PbDK(url)
	elif mode==248: RRMWBwU6pG = F91zJZREnYVKCHkb7()
	elif mode==249: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def F91zJZREnYVKCHkb7():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'',headers,'','','AKWAM-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ZloXcumTGkqyQfv3502aBAE7zVP1 = QPuHKNAT4jmCRg.findall('home-site-btn-container.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if ZloXcumTGkqyQfv3502aBAE7zVP1: ZloXcumTGkqyQfv3502aBAE7zVP1 = ZloXcumTGkqyQfv3502aBAE7zVP1[0]
	else: ZloXcumTGkqyQfv3502aBAE7zVP1 = GqcEfFR8XQPgBMLr
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',ZloXcumTGkqyQfv3502aBAE7zVP1,'',headers,'','','AKWAM-MENU-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',249,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',GqcEfFR8XQPgBMLr,246)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',GqcEfFR8XQPgBMLr,247)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المميزة',ZloXcumTGkqyQfv3502aBAE7zVP1,241,'','','featured')
	recent = QPuHKNAT4jmCRg.findall('recently-container.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	VV7yf2htDCBU6EeSX8TJQM = recent[0]
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أضيف حديثا',VV7yf2htDCBU6EeSX8TJQM,241)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,name,wltPGJcYo12Ed in TTCRYZroizb:
		if name in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,241)
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			title = name+' '+title
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,241)
	return
def dy36UlWO8j(website=''):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','AKWAM-MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="menu(.*?)<nav',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?text">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title not in EhRQ8zB1fdkj5vN6HlmqD7SOU:
				title = title+' مصنفة'
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,245)
		if website=='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return Ht6Gg8lbciAd9FaUQVs
def nCV2JkIN9LWFy6t8PbDK(website=''):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','AKWAM-MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="menu(.*?)<nav',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?text">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title not in EhRQ8zB1fdkj5vN6HlmqD7SOU:
				title = title+' مفلترة'
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,244)
		if website=='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,type=''):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,True,'AKWAM-TITLES-1st')
	if type=='featured': TTCRYZroizb = QPuHKNAT4jmCRg.findall('swiper-container(.*?)swiper-button-prev',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	else: TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="widget"(.*?)main-footer',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if not items:
			items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
			if '/series/' in VV7yf2htDCBU6EeSX8TJQM or '/shows/' in VV7yf2htDCBU6EeSX8TJQM:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,242,G2WR0Oacvdq8ZQTjKboDU)
			elif '/movies/' in VV7yf2htDCBU6EeSX8TJQM:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,243,G2WR0Oacvdq8ZQTjKboDU)
			elif '/games/' not in VV7yf2htDCBU6EeSX8TJQM:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,243,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('pagination(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			VV7yf2htDCBU6EeSX8TJQM = UH1IuvwM9e4cl7if63nNdozJFSj(VV7yf2htDCBU6EeSX8TJQM)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,241)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','%20')
	url = GqcEfFR8XQPgBMLr + '/search?q='+Unr6jRmMIv80lSGbkBCehpaWAdV
	RRMWBwU6pG = SPFl6UGK4mrBua(url)
	return
def opLlxOB2dUVZ5JF4j(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in Ht6Gg8lbciAd9FaUQVs:
		G2WR0Oacvdq8ZQTjKboDU = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Icon')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+'رابط التشغيل',url,243,G2WR0Oacvdq8ZQTjKboDU)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('-episodes">(.*?)<div class="widget-4',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		jN1v92PmCGquRbcl = QPuHKNAT4jmCRg.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in jN1v92PmCGquRbcl:
			title = title.replace('  ',' ')
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,242,G2WR0Oacvdq8ZQTjKboDU)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,243,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,True,'AKWAM-PLAY-1st')
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('badge-danger.*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	j4HYvVUoNl8iFS97QCz5JAEnZhpIs0 = QPuHKNAT4jmCRg.findall('li><a href="#(.*?)".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	LL8heV7kxYI5bOjEZ6XaUQWwfPA,xitERh4TD2jGJPq5Nuv39CAmg,N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd,EoOhk6c3VjM8WQYNZaHs50vq = [],[],[],[]
	if j4HYvVUoNl8iFS97QCz5JAEnZhpIs0:
		UQIq1jCWgFi4MTV0K97bfSe = 'mp4'
		for ajpkWtS31Vuvf796UBcwiLE,i5DftlhA6vQ2GF in j4HYvVUoNl8iFS97QCz5JAEnZhpIs0:
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('tab-content quality" id="'+ajpkWtS31Vuvf796UBcwiLE+'".*?</div>.\s*</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			wltPGJcYo12Ed = TTCRYZroizb[0]
			N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd.append(wltPGJcYo12Ed)
			EoOhk6c3VjM8WQYNZaHs50vq.append(i5DftlhA6vQ2GF)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="qualities(.*?)<h3.*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			wltPGJcYo12Ed,filename = TTCRYZroizb[0]
			zGuHZYQ8xFVt3 = ['zip','rar','txt','pdf','htm','tar','iso','html']
			UQIq1jCWgFi4MTV0K97bfSe = filename.rsplit('.',1)[1].strip(' ')
			if UQIq1jCWgFi4MTV0K97bfSe in zGuHZYQ8xFVt3:
				qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd.append(wltPGJcYo12Ed)
		EoOhk6c3VjM8WQYNZaHs50vq.append('')
	for PXBFxvuUlLDHGpm58 in range(len(N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd)):
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('href="(.*?)".*?icon-(.*?)"',N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd[PXBFxvuUlLDHGpm58],QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,AiZoXlzQE93 in Y4xiULzGTKjb8mulO:
			if 'torrent' in AiZoXlzQE93: continue
			elif 'download' in AiZoXlzQE93: type = 'download'
			elif 'play' in AiZoXlzQE93: type = 'watch'
			else: type = 'unknown'
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named=__'+type+'____'+EoOhk6c3VjM8WQYNZaHs50vq[PXBFxvuUlLDHGpm58]+'__akwam'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	vMgBXHJ4ETR1qjkDAhKsc9SuY = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='CATEGORIES':
		if vMgBXHJ4ETR1qjkDAhKsc9SuY[0]+'=' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[0]
		for PXBFxvuUlLDHGpm58 in range(len(vMgBXHJ4ETR1qjkDAhKsc9SuY[0:-1])):
			if vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+jsEpRxQH76+'=0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+jsEpRxQH76+'=0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'all')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='FILTERS':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'all')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'?'+Lb7kxwJZBPquygXoO4nTSN3
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,241,'','1')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,241,'','1')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,True,'AKWAM-FILTERS_MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<form id(.*?)</form>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	dict = {}
	for qQ3oR7maZGeFByA6uitjrd,name,wltPGJcYo12Ed in K0MwVeCGOmJho:
		items = QPuHKNAT4jmCRg.findall('<option(.*?)>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if '=' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='CATEGORIES':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<=1:
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]: SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'CATEGORIES___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,241,'','1')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,245,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='FILTERS':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع : '+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,244,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			if 'value' not in pp8iHB3W9Cs: pp8iHB3W9Cs = wMq2UBSjsfgchHzprXWFOTdn5
			else: pp8iHB3W9Cs = QPuHKNAT4jmCRg.findall('"(.*?)"',pp8iHB3W9Cs,QPuHKNAT4jmCRg.DOTALL)[0]
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = wMq2UBSjsfgchHzprXWFOTdn5
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'='+wMq2UBSjsfgchHzprXWFOTdn5
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			title = wMq2UBSjsfgchHzprXWFOTdn5+' : '#+dict[qQ3oR7maZGeFByA6uitjrd]['0']
			title = wMq2UBSjsfgchHzprXWFOTdn5+' : '+name
			if type=='FILTERS': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,244,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='CATEGORIES' and vMgBXHJ4ETR1qjkDAhKsc9SuY[-2]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'all')
				lc154VhT9DCqMk8 = url+'?'+sJxYKGW7VODHcn0o4UBZkAtEMe
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lc154VhT9DCqMk8,241,'','1')
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,245,'','',q0NkUvatj1HcndbF9Yrsw)
	return
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&')
	XTiOm8cUEJCh3ryql = {}
	if '=' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	VAlPewLIfoQv6dash = ''
	RBkuwxQsqh6CaLzMcGWbftSrI = ['section','category','rating','year','language','formats','quality']
	for key in RBkuwxQsqh6CaLzMcGWbftSrI:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
		elif mode=='all': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&')
	return VAlPewLIfoQv6dash
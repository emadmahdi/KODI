# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'SHIAVOICE'
JE7QrkmhletLwA0OZXu = '_SHV_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
headers = {'User-Agent':None}
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==310: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==311: RRMWBwU6pG = SPFl6UGK4mrBua(url)
	elif mode==312: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==313: RRMWBwU6pG = JMDQxHpjZLyKTuR6kOc2hUft3wGX8(url)
	elif mode==314: RRMWBwU6pG = YNtljB8xJEoSwiUZbAcI1aKHvsgh(text)
	elif mode==319: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','SHIAVOICE-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="menulinks"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = QPuHKNAT4jmCRg.findall('<h5>(.*?)</h5>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	for HY6PBsZvlUTGOW5eXcVnt27Ioi1 in range(len(items)):
		title = items[HY6PBsZvlUTGOW5eXcVnt27Ioi1].strip(' ')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,GqcEfFR8XQPgBMLr,314,'','',str(HY6PBsZvlUTGOW5eXcVnt27Ioi1+1))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'مقاطع شهر',GqcEfFR8XQPgBMLr,314,'','','0')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<B>(.*?)</B>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,311)
	return Ht6Gg8lbciAd9FaUQVs
def YNtljB8xJEoSwiUZbAcI1aKHvsgh(HY6PBsZvlUTGOW5eXcVnt27Ioi1):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',GqcEfFR8XQPgBMLr,'','','','','SHIAVOICE-LATEST-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if HY6PBsZvlUTGOW5eXcVnt27Ioi1=='0':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="tab-content"(.*?)</table>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,312)
	elif HY6PBsZvlUTGOW5eXcVnt27Ioi1 in ['1','2','3']:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('(<h5>.*?)<div class="col-lg',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		GGM9wY2OU8n3EZop = int(HY6PBsZvlUTGOW5eXcVnt27Ioi1)-1
		wltPGJcYo12Ed = TTCRYZroizb[GGM9wY2OU8n3EZop]
		if HY6PBsZvlUTGOW5eXcVnt27Ioi1=='1': items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		else: items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title,name in items:
			G2WR0Oacvdq8ZQTjKboDU = GqcEfFR8XQPgBMLr+'/'+G2WR0Oacvdq8ZQTjKboDU
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,311,G2WR0Oacvdq8ZQTjKboDU)
	elif HY6PBsZvlUTGOW5eXcVnt27Ioi1 in ['4','5','6']:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('(<h5>.*?)</table>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		HY6PBsZvlUTGOW5eXcVnt27Ioi1 = int(HY6PBsZvlUTGOW5eXcVnt27Ioi1)-4
		wltPGJcYo12Ed = TTCRYZroizb[HY6PBsZvlUTGOW5eXcVnt27Ioi1]
		items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,OnQ71fzhCAbTwMBg0kPxjG4i5VdSep,title,Vuk3760YmGdQaZ92MfwcNKE in items:
			G2WR0Oacvdq8ZQTjKboDU = GqcEfFR8XQPgBMLr+'/'+G2WR0Oacvdq8ZQTjKboDU
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = title.strip(' ')
			OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = OnQ71fzhCAbTwMBg0kPxjG4i5VdSep.strip(' ')
			Vuk3760YmGdQaZ92MfwcNKE = Vuk3760YmGdQaZ92MfwcNKE.strip(' ')
			if OnQ71fzhCAbTwMBg0kPxjG4i5VdSep: name = OnQ71fzhCAbTwMBg0kPxjG4i5VdSep
			else: name = Vuk3760YmGdQaZ92MfwcNKE
			title = title+' ('+name+')'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,312,G2WR0Oacvdq8ZQTjKboDU)
	return
def SPFl6UGK4mrBua(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('ibox-heading"(.*?)class="float-right',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	if 'catsum-mobile' in wltPGJcYo12Ed:
		items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title,count in items:
				G2WR0Oacvdq8ZQTjKboDU = GqcEfFR8XQPgBMLr+'/'+G2WR0Oacvdq8ZQTjKboDU
				VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,311,G2WR0Oacvdq8ZQTjKboDU)
	else:
		items = QPuHKNAT4jmCRg.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,SSWZBiykX9LF7,VVaBpWQDAfx5dO4GSMmstz78eRFYw in items:
			if title=='' or SSWZBiykX9LF7=='': continue
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = title+' ('+VVaBpWQDAfx5dO4GSMmstz78eRFYw+')'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,312)
	if not items: opLlxOB2dUVZ5JF4j(Ht6Gg8lbciAd9FaUQVs)
	return
def opLlxOB2dUVZ5JF4j(Ht6Gg8lbciAd9FaUQVs):
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="ibox-content"(.*?)class="pagination',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title,name,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,312,'',VVaBpWQDAfx5dO4GSMmstz78eRFYw)
	return
def JMDQxHpjZLyKTuR6kOc2hUft3wGX8(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="ibox-content p-1"(.*?)class="ibox-content"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb:
		SPFl6UGK4mrBua(url)
		return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<strong>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
		title = title.strip(' ')
		if '/play-' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,312)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,311)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<audio.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<video.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM[0]
	zT3xJQIVDmCgapBljs(VV7yf2htDCBU6EeSX8TJQM,mm5vCBc4DOz2Fj,'video')
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	ncYEorgM4tsaCkN = ['&t=a','&t=c','&t=s']
	if showDialogs:
		oHkC2iJLz9DaBqYthQnf = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('موقع صوت الشيعة - أختر البحث', oHkC2iJLz9DaBqYthQnf)
		if ShT1xUHjlDotkRuPq7gv == -1: return
	elif '_SHIAVOICE-PERSONS_' in vwIN38HprDqTW5Sh61exF7EnA: ShT1xUHjlDotkRuPq7gv = 0
	elif '_SHIAVOICE-ALBUMS_' in vwIN38HprDqTW5Sh61exF7EnA: ShT1xUHjlDotkRuPq7gv = 1
	elif '_SHIAVOICE-AUDIOS_' in vwIN38HprDqTW5Sh61exF7EnA: ShT1xUHjlDotkRuPq7gv = 2
	else: return
	type = ncYEorgM4tsaCkN[ShT1xUHjlDotkRuPq7gv]
	url = GqcEfFR8XQPgBMLr+'/search.php?q='+search+type
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="ibox-content"(.*?)class="ibox-content"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		if ShT1xUHjlDotkRuPq7gv in [0,1]:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,313,G2WR0Oacvdq8ZQTjKboDU)
		elif ShT1xUHjlDotkRuPq7gv==2:
			items = QPuHKNAT4jmCRg.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,312)
	return
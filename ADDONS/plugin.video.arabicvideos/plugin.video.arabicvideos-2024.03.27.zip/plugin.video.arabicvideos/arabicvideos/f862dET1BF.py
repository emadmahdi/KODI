# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'SHAHID4U'
headers = ''
JE7QrkmhletLwA0OZXu = '_SH4_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==110: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==111: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==112: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==113: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,True)
	elif mode==114: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'FULL_FILTER___'+text)
	elif mode==115: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'DEFINED_FILTER___'+text)
	elif mode==116: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,False)
	elif mode==119: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	ka6I93CnvublQMtjr,url,nbdMp8UuhzP3oq4cDWj6eyZVt = PEkFUyjA3qRNpzgYX(vfj1VHSBpIks9JhLGmr,'GET',GqcEfFR8XQPgBMLr,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',ka6I93CnvublQMtjr,115)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',ka6I93CnvublQMtjr,114)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',ka6I93CnvublQMtjr,111,'','','featured')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('simple-filter(.*?)adv-filter',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for filter,G2WR0Oacvdq8ZQTjKboDU,title in items:
			url = ka6I93CnvublQMtjr+filter
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,url,111,G2WR0Oacvdq8ZQTjKboDU,'',filter)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="dropdown"(.*?)<script>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+VV7yf2htDCBU6EeSX8TJQM
			if 'netflix' in VV7yf2htDCBU6EeSX8TJQM: title = 'نيتفلكس'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,111)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,oN6FKz2SkGiLnJ3tx4='',nbdMp8UuhzP3oq4cDWj6eyZVt=''):
	if not nbdMp8UuhzP3oq4cDWj6eyZVt: nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb,items,gltHFKTroJfpLe = [],[],[]
	if oN6FKz2SkGiLnJ3tx4=='featured': TTCRYZroizb = QPuHKNAT4jmCRg.findall('glide__slides(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	else: TTCRYZroizb = QPuHKNAT4jmCRg.findall('shows-container(.*?)pagination',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	if not items: items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if 'javascript' in VV7yf2htDCBU6EeSX8TJQM: continue
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM).strip('/')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		title = title.strip(' ')
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if '/film/' in VV7yf2htDCBU6EeSX8TJQM or 'فيلم' in VV7yf2htDCBU6EeSX8TJQM or any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,112,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,113,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif '/actor/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,111,G2WR0Oacvdq8ZQTjKboDU)
		elif '/series/' in VV7yf2htDCBU6EeSX8TJQM and '/list' not in url:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'/list'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,111,G2WR0Oacvdq8ZQTjKboDU)
		elif '/list' in url and 'حلقة' in title:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,112,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,113,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		if oN6FKz2SkGiLnJ3tx4!='search': items = QPuHKNAT4jmCRg.findall('(updateQuery).*?>(.+?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		else: items = QPuHKNAT4jmCRg.findall('<li>.*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if oN6FKz2SkGiLnJ3tx4!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: VV7yf2htDCBU6EeSX8TJQM = url+'&page='+title
				else: VV7yf2htDCBU6EeSX8TJQM = url+'?page='+title
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			if title: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,111,'','',oN6FKz2SkGiLnJ3tx4)
	return
def opLlxOB2dUVZ5JF4j(url,BiDKomPrkFwXEc6NIqsjMSd):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('items d-flex(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if len(TTCRYZroizb)>1:
		if '/season/' in TTCRYZroizb[0]: Q1WJvEwGdh2mPfct9SKa,jN1v92PmCGquRbcl = TTCRYZroizb[0],TTCRYZroizb[1]
		else: Q1WJvEwGdh2mPfct9SKa,jN1v92PmCGquRbcl = TTCRYZroizb[1],TTCRYZroizb[0]
	else: Q1WJvEwGdh2mPfct9SKa,jN1v92PmCGquRbcl = TTCRYZroizb[0],TTCRYZroizb[0]
	for kdWCpE9TjNh in range(2):
		if BiDKomPrkFwXEc6NIqsjMSd: mode,type,wltPGJcYo12Ed = 116,'folder',Q1WJvEwGdh2mPfct9SKa
		else: mode,type,wltPGJcYo12Ed = 112,'video',jN1v92PmCGquRbcl
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if BiDKomPrkFwXEc6NIqsjMSd and len(items)<2:
			BiDKomPrkFwXEc6NIqsjMSd = False
			continue
		for VV7yf2htDCBU6EeSX8TJQM,gH8mavstuiyE6RY2,nUbpaNT0vhcj7ZsEz in items:
			title = gH8mavstuiyE6RY2+' '+nUbpaNT0vhcj7ZsEz
			fpjEiKI9bTc1xhoeq37vPusDJ6SB(type,JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,mode)
		break
	if not items and '/episodes' in Ht6Gg8lbciAd9FaUQVs:
		p17lwyMzRK3YVjeG = QPuHKNAT4jmCRg.findall('class="breadcrumb"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if p17lwyMzRK3YVjeG:
			wltPGJcYo12Ed = p17lwyMzRK3YVjeG[0]
			Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if len(Y4xiULzGTKjb8mulO)>2:
				VV7yf2htDCBU6EeSX8TJQM = Y4xiULzGTKjb8mulO[2]+'list'
				SPFl6UGK4mrBua(VV7yf2htDCBU6EeSX8TJQM)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="actions(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	BAqDYRnfbaz6hCHsm = '/watch/' in wltPGJcYo12Ed
	download = '/download/' in wltPGJcYo12Ed
	if   BAqDYRnfbaz6hCHsm and not download: xvfQD0EIPwStyjFMndguKckL58mZ,uXDUhxR6oY = Y4xiULzGTKjb8mulO[0],''
	elif not BAqDYRnfbaz6hCHsm and download: xvfQD0EIPwStyjFMndguKckL58mZ,uXDUhxR6oY = '',Y4xiULzGTKjb8mulO[0]
	elif BAqDYRnfbaz6hCHsm and download: xvfQD0EIPwStyjFMndguKckL58mZ,uXDUhxR6oY = Y4xiULzGTKjb8mulO[0],Y4xiULzGTKjb8mulO[1]
	else: xvfQD0EIPwStyjFMndguKckL58mZ,uXDUhxR6oY = '',''
	if BAqDYRnfbaz6hCHsm:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',xvfQD0EIPwStyjFMndguKckL58mZ,'',headers,'','','SHAHID4U-PLAY-2nd')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('let servers(.*?)player',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		if kk73xHNzri1P2wgULMv4sDtoTnybO:
			y8qSvx0Z9MY = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
			eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('"name":"(.*?)".*?"url":"(.*?)"',y8qSvx0Z9MY,QPuHKNAT4jmCRg.DOTALL)
			for title,VV7yf2htDCBU6EeSX8TJQM in eIXD9Ql3JREsm4WvKc:
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\\/','/')
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if download:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',uXDUhxR6oY,'',headers,'','','SHAHID4U-PLAY-3rd')
		iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"servers"(.*?)info-container',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if kk73xHNzri1P2wgULMv4sDtoTnybO:
			y8qSvx0Z9MY = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
			eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',y8qSvx0Z9MY,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title,i5DftlhA6vQ2GF in eIXD9Ql3JREsm4WvKc:
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'+'____'+i5DftlhA6vQ2GF
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/search?s='+search
	ka6I93CnvublQMtjr,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ykIAHx9E1umUdZqjSiBw6Kbar = PEkFUyjA3qRNpzgYX(vfj1VHSBpIks9JhLGmr,'GET',url,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'search',ykIAHx9E1umUdZqjSiBw6Kbar)
	return
def PD19Sz64kNmaXxw(url):
	url = url.split('/smartemadfilter?')[0]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	K0MwVeCGOmJho = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('adv-filter(.*?)shows-container',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		qBUEfFhoG5Mw0xgyl4nAkemHd6W9Z,xVQTW4gOUKEJtMzLXiChwk1BlRD2N,N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = zip(*K0MwVeCGOmJho)
		K0MwVeCGOmJho = zip(xVQTW4gOUKEJtMzLXiChwk1BlRD2N,qBUEfFhoG5Mw0xgyl4nAkemHd6W9Z,N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd)
	return K0MwVeCGOmJho
def zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed):
	items = QPuHKNAT4jmCRg.findall('value="(.*?)".*?>\s*(.*?)\s*<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return items
def AGN9FcR0k3(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	rrU0IR1Aga6Y = url.split('/smartemadfilter?')[0]
	eek0phlJjL6MWVXsmy7wFPz2oT = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	url = url.replace(rrU0IR1Aga6Y,eek0phlJjL6MWVXsmy7wFPz2oT)
	url = url.replace('/smartemadfilter?','/?')
	return url
CEMwAc5LsuN0V = ['quality','year','genre','category']
sjehmt4lTF0gkQ = ['category','genre','year']
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='DEFINED_FILTER':
		if sjehmt4lTF0gkQ[0]+'=' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = sjehmt4lTF0gkQ[0]
		for PXBFxvuUlLDHGpm58 in range(len(sjehmt4lTF0gkQ[0:-1])):
			if sjehmt4lTF0gkQ[PXBFxvuUlLDHGpm58]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = sjehmt4lTF0gkQ[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+jsEpRxQH76+'=0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+jsEpRxQH76+'=0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='FULL_FILTER':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+Lb7kxwJZBPquygXoO4nTSN3
		lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',lc154VhT9DCqMk8,111)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',lc154VhT9DCqMk8,111)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K0MwVeCGOmJho = PD19Sz64kNmaXxw(url)
	dict = {}
	for name,qQ3oR7maZGeFByA6uitjrd,wltPGJcYo12Ed in K0MwVeCGOmJho:
		name = name.replace('كل ','')
		items = zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed)
		if '=' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='DEFINED_FILTER':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<2:
				if qQ3oR7maZGeFByA6uitjrd==sjehmt4lTF0gkQ[-1]:
					lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
					SPFl6UGK4mrBua(lc154VhT9DCqMk8)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'DEFINED_FILTER___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				if qQ3oR7maZGeFByA6uitjrd==sjehmt4lTF0gkQ[-1]:
					lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lc154VhT9DCqMk8,111)
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,115,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='FULL_FILTER':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع :'+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,114,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			if pp8iHB3W9Cs=='196533': wMq2UBSjsfgchHzprXWFOTdn5 = 'أفلام نيتفلكس'
			elif pp8iHB3W9Cs=='196531': wMq2UBSjsfgchHzprXWFOTdn5 = 'مسلسلات نيتفلكس'
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = wMq2UBSjsfgchHzprXWFOTdn5
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'='+wMq2UBSjsfgchHzprXWFOTdn5
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'#+dict[qQ3oR7maZGeFByA6uitjrd]['0']
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'+name
			if type=='FULL_FILTER': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,114,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='DEFINED_FILTER' and sjehmt4lTF0gkQ[-2]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'modified_filters')
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
				lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lc154VhT9DCqMk8,111)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,115,'','',q0NkUvatj1HcndbF9Yrsw)
	return
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.replace('=&','=0&')
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&')
	XTiOm8cUEJCh3ryql = {}
	if '=' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	VAlPewLIfoQv6dash = ''
	for key in CEMwAc5LsuN0V:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
		elif mode=='all': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.replace('=0','=')
	return VAlPewLIfoQv6dash
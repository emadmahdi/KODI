# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'FABRAKA'
JE7QrkmhletLwA0OZXu = '_FBK_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['الصفحة الرئيسية','Sign in']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==620: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==621: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==622: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==623: RRMWBwU6pG = eRotYPZNvVqM0O2BAbfkhDujSp6(url,text)
	elif mode==624: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==629: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	ka6I93CnvublQMtjr,url,nbdMp8UuhzP3oq4cDWj6eyZVt = PEkFUyjA3qRNpzgYX(vfj1VHSBpIks9JhLGmr,'GET',GqcEfFR8XQPgBMLr,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',629,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'جديد الحلقات',ka6I93CnvublQMtjr,621,'','','new_episodes')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'جديد الأفلام',ka6I93CnvublQMtjr,621,'','','new_movies')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المسلسلات المميزة',ka6I93CnvublQMtjr,621,'','','featured_series')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"navslide-wrap"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,624)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('/category.php">(.*?)"navslide-divider"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("'dropdown-menu'(.*?)</ul>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for y8qSvx0Z9MY in TTCRYZroizb: wltPGJcYo12Ed = wltPGJcYo12Ed.replace(y8qSvx0Z9MY,'')
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,624)
	return
def pF0d4b2ZY9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FABRAKA-SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"caret"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		wltPGJcYo12Ed = wltPGJcYo12Ed.replace('"presentation"','</ul>')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = [('',wltPGJcYo12Ed)]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for jj8UuT2RMkfDGncsLorzHl0eaNgPB,wltPGJcYo12Ed in TTCRYZroizb:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if jj8UuT2RMkfDGncsLorzHl0eaNgPB: jj8UuT2RMkfDGncsLorzHl0eaNgPB = jj8UuT2RMkfDGncsLorzHl0eaNgPB+': '
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = jj8UuT2RMkfDGncsLorzHl0eaNgPB+title
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,621)
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"pm-category-subcats"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kk73xHNzri1P2wgULMv4sDtoTnybO:
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if len(items)<30:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,621)
	if not kzlepwfG1iEyIJKTY45quXO and not kk73xHNzri1P2wgULMv4sDtoTnybO: SPFl6UGK4mrBua(url)
	return
def SPFl6UGK4mrBua(url,lp3eGht9uF4mMCR6YIWz=''):
	if lp3eGht9uF4mMCR6YIWz=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',url,data,headers,'','','FABRAKA-TITLES-1st')
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FABRAKA-TITLES-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	wltPGJcYo12Ed,items = '',[]
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	if lp3eGht9uF4mMCR6YIWz=='ajax-search':
		wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
		eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in eIXD9Ql3JREsm4WvKc: items.append(('',VV7yf2htDCBU6EeSX8TJQM,title))
	elif lp3eGht9uF4mMCR6YIWz=='featured':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pm-video-watch-featured"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
	elif lp3eGht9uF4mMCR6YIWz=='new_episodes':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"row pm-ul-browse-videos(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
	elif lp3eGht9uF4mMCR6YIWz=='new_movies':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"row pm-ul-browse-videos(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if len(TTCRYZroizb)>1: wltPGJcYo12Ed = TTCRYZroizb[1]
	elif lp3eGht9uF4mMCR6YIWz=='featured_series':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
		eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in eIXD9Ql3JREsm4WvKc: items.append(('',VV7yf2htDCBU6EeSX8TJQM,title))
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('(data-echo=".*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
	if wltPGJcYo12Ed and not items: items = QPuHKNAT4jmCRg.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if not items: return
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) (الحلقة|حلقة).\d+',title,QPuHKNAT4jmCRg.DOTALL)
		if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,622,G2WR0Oacvdq8ZQTjKboDU)
		elif lp3eGht9uF4mMCR6YIWz=='new_episodes':
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,622,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv:
			title = '_MOD_' + CiZxgXTGW9pv[0][0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,623,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,623,G2WR0Oacvdq8ZQTjKboDU)
	if 1:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if VV7yf2htDCBU6EeSX8TJQM=='#': continue
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,621)
	return
def eRotYPZNvVqM0O2BAbfkhDujSp6(url,XpxUEd8SkCJHrst3):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FABRAKA-EPISODES-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	KKcFOCmYRENepQnxi = QPuHKNAT4jmCRg.findall('"series-header".*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KKcFOCmYRENepQnxi: G2WR0Oacvdq8ZQTjKboDU = KKcFOCmYRENepQnxi[0]
	else: G2WR0Oacvdq8ZQTjKboDU = ''
	items = []
	NGsk3KreLvExPqSh = False
	if kzlepwfG1iEyIJKTY45quXO and not XpxUEd8SkCJHrst3:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for XpxUEd8SkCJHrst3,title in items:
			XpxUEd8SkCJHrst3 = XpxUEd8SkCJHrst3.strip('#')
			if len(items)>1: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,623,G2WR0Oacvdq8ZQTjKboDU,'',XpxUEd8SkCJHrst3)
			else: NGsk3KreLvExPqSh = True
	else: NGsk3KreLvExPqSh = True
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('id="'+XpxUEd8SkCJHrst3+'"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kk73xHNzri1P2wgULMv4sDtoTnybO and NGsk3KreLvExPqSh:
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		eIXD9Ql3JREsm4WvKc = QPuHKNAT4jmCRg.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		items = []
		for VV7yf2htDCBU6EeSX8TJQM,title in eIXD9Ql3JREsm4WvKc: items.append((VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU))
		if not items: items = QPuHKNAT4jmCRg.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
			VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
			title = title.replace('</em><span>',' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,622,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	YsDryBSXquzdEUta8kxjfO = []
	url = url.replace('watch.php','see.php')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FABRAKA-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"WatchList"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<iframe src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]+'?named='+title+'__embed'
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"downloadlist"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/search.php?keywords='+search
	ka6I93CnvublQMtjr,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ykIAHx9E1umUdZqjSiBw6Kbar = PEkFUyjA3qRNpzgYX(vfj1VHSBpIks9JhLGmr,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'search')
	return
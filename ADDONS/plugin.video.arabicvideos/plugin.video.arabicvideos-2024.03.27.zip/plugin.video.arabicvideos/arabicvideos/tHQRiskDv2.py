# -*- coding: utf-8 -*-
import sys as GJtcqTv68ZQpwxYFiDg
yyIoQrPWR1B = GJtcqTv68ZQpwxYFiDg.version_info [0] == 2
Duhwt2HMRTeBonVic0lz8bjUJ = 2048
BnAMltLNqzHfjxWkVi9eb3P = 7
def rrgVqwDZPsMjxvR3EylNz9 (tbA2GsXVSDNgm):
	global lzR5Gp9sjoDwb
	BZb90tzYkgeu3pcAo = ord (tbA2GsXVSDNgm [-1])
	fdK96q2bHgSIwE = tbA2GsXVSDNgm [:-1]
	klvdJbzV7PEMciQ61A0t25SGXq8 = BZb90tzYkgeu3pcAo % len (fdK96q2bHgSIwE)
	q5yMKdNsYpzDj8Oo = fdK96q2bHgSIwE [:klvdJbzV7PEMciQ61A0t25SGXq8] + fdK96q2bHgSIwE [klvdJbzV7PEMciQ61A0t25SGXq8:]
	if yyIoQrPWR1B:
		hq2Yj5TvMOKsRFroabWu = unicode () .join ([unichr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	else:
		hq2Yj5TvMOKsRFroabWu = str () .join ([chr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	return eval (hq2Yj5TvMOKsRFroabWu)
iRTygNp4Lf36wQKlD2MHUhG7B,KbL94nDHufSF0VcO2Nk3,qNZKwi2M1S4fBzGQYrmPnea=rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9
xxpPYJOnoAUrlBzyveui,ldOGfm56kWs8T03wcptQunqEUBDrvC,Arg2GFJDt3emTvpO6fZkSVdaUHywnN=qNZKwi2M1S4fBzGQYrmPnea,KbL94nDHufSF0VcO2Nk3,iRTygNp4Lf36wQKlD2MHUhG7B
v7reLlOXCgD5pZ14w2tUA,p1lrNRIXqLQJznH6O,ddK4MmwpX5oG=Arg2GFJDt3emTvpO6fZkSVdaUHywnN,ldOGfm56kWs8T03wcptQunqEUBDrvC,xxpPYJOnoAUrlBzyveui
OARzhnB9o7uYvQGFaIcZ,ZpH2IWt7veyFobTsAnhi41,q0JfWbP8vACLxSNIncpOXkR6j=ddK4MmwpX5oG,p1lrNRIXqLQJznH6O,v7reLlOXCgD5pZ14w2tUA
L91nVzxH4hYrgPDsOuljXd0J,uhOkAKtLVv4XTy1nWE6,d1JiVThqEO0nBaY2QRNyZxlujWw7SK=q0JfWbP8vACLxSNIncpOXkR6j,ZpH2IWt7veyFobTsAnhi41,OARzhnB9o7uYvQGFaIcZ
V391t7nQWUBR5euCkJ,IJ6VkihabRm,lunVJF2G5bZMgTcCje0vaIB371SX=d1JiVThqEO0nBaY2QRNyZxlujWw7SK,uhOkAKtLVv4XTy1nWE6,L91nVzxH4hYrgPDsOuljXd0J
xxBJoKG54uwQ,gr5K72RtvAZYPVwkdnspbzQWNjEI,u1ml5XcLiZ7oDPs3UjedgpYHhfV=lunVJF2G5bZMgTcCje0vaIB371SX,IJ6VkihabRm,V391t7nQWUBR5euCkJ
dxAs4otSE98YmZnKy2iwRCB,fcIm8tvxlXZsaEY3bwuG4B,f8PVRTseIuj9BckO6GoyF5Lxv=u1ml5XcLiZ7oDPs3UjedgpYHhfV,gr5K72RtvAZYPVwkdnspbzQWNjEI,xxBJoKG54uwQ
tKVplxqYIdngGF6TZkXeb2PiwfME,vkMRnTNV9jFm,HMO0QciekqVpLKmA=f8PVRTseIuj9BckO6GoyF5Lxv,fcIm8tvxlXZsaEY3bwuG4B,dxAs4otSE98YmZnKy2iwRCB
DKqQekNtF6WlJLhBP9M5ca,GGTRaYBDeNyI25zlF,Vv0lSjAOHLfMnam3wtdor=HMO0QciekqVpLKmA,vkMRnTNV9jFm,tKVplxqYIdngGF6TZkXeb2PiwfME
a06i2XFf3oBnDrJQZEKmHpqY9ACW,DDS79jdWzLtE,zOZvXaebGNwHKfjRA=Vv0lSjAOHLfMnam3wtdor,GGTRaYBDeNyI25zlF,DKqQekNtF6WlJLhBP9M5ca
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def hLD0mk9HIuPOz7pw(Q6FbqZ9uIe8v2xaTHhfDCJ,HbqSfZ6m7FAa):
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==KbL94nDHufSF0VcO2Nk3(u"࠷࠸࠶৪"): RRMWBwU6pG = lsOaFUJQn0k1wiS4rxPY52LqyfEuG()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxpPYJOnoAUrlBzyveui(u"࠸࠹࠱৫"): RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(HbqSfZ6m7FAa)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==HMO0QciekqVpLKmA(u"࠹࠳࠳৬"): RRMWBwU6pG = WPbJc3GUuYAtyvOdg06()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxBJoKG54uwQ(u"࠳࠴࠵৭"): RRMWBwU6pG = IIcYOakn602PU9KLwTxvot7pib8AM()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==xxBJoKG54uwQ(u"࠴࠵࠷৮"): RRMWBwU6pG = w1iZgxuXfYOjmel5L6srWya4cnv(HbqSfZ6m7FAa)
	else: RRMWBwU6pG = fcIm8tvxlXZsaEY3bwuG4B(u"ࡋࡧ࡬ࡴࡧਜ")
	return RRMWBwU6pG
def w1iZgxuXfYOjmel5L6srWya4cnv(r0GEZyMkBOiY3IhA):
	try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(r0GEZyMkBOiY3IhA.decode(v7reLlOXCgD5pZ14w2tUA(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(r0GEZyMkBOiY3IhA)
	return
def unQmcpAEF2DaNX87fTgMW(HbqSfZ6m7FAa):
	zT3xJQIVDmCgapBljs(HbqSfZ6m7FAa,mm5vCBc4DOz2Fj,KbL94nDHufSF0VcO2Nk3(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def IIcYOakn602PU9KLwTxvot7pib8AM():
	qNEnDMwm1Vfastx2ZkpRh = p1lrNRIXqLQJznH6O(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࠭ठ"),DKqQekNtF6WlJLhBP9M5ca(u"࠭ࠧड"),KbL94nDHufSF0VcO2Nk3(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),qNEnDMwm1Vfastx2ZkpRh)
	return
def lsOaFUJQn0k1wiS4rxPY52LqyfEuG():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(fcIm8tvxlXZsaEY3bwuG4B(u"ࠨ࡮࡬ࡲࡰ࠭ण"),IJ6VkihabRm(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),dxAs4otSE98YmZnKy2iwRCB(u"ࠪࠫथ"),ddK4MmwpX5oG(u"࠵࠶࠷৯"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(v7reLlOXCgD5pZ14w2tUA(u"ࠫࡱ࡯࡮࡬ࠩद"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),vkMRnTNV9jFm(u"࠭ࠧन"),uhOkAKtLVv4XTy1nWE6(u"࠶࠷࠷ৰ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(p1lrNRIXqLQJznH6O(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࠪफ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠽࠾࠿࠹ৱ"))
	XXjnwM5QpPkISbdcWruxRetJ3 = wdqoXCGizgh8BIr0JyjHnQP()
	jj8a9Sq0FzyUkQA45PmwZnfelot1 = YcJmC0W43u5idIELnHTU2XSsMPNt.stat(XXjnwM5QpPkISbdcWruxRetJ3).st_mtime
	HVo1hFNm72wup35f = []
	if Nnxm30dfoBWRYpIC7KsQGl: qnJ3hHel9rGd = YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(XXjnwM5QpPkISbdcWruxRetJ3.encode(GGTRaYBDeNyI25zlF(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: qnJ3hHel9rGd = YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(XXjnwM5QpPkISbdcWruxRetJ3.decode(fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for E2YPvG7AZ81 in qnJ3hHel9rGd:
		if Nnxm30dfoBWRYpIC7KsQGl: E2YPvG7AZ81 = E2YPvG7AZ81.decode(v7reLlOXCgD5pZ14w2tUA(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not E2YPvG7AZ81.startswith(xxpPYJOnoAUrlBzyveui(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		WNJf94Oj2SC3InsRtK6 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XXjnwM5QpPkISbdcWruxRetJ3,E2YPvG7AZ81)
		jj8a9Sq0FzyUkQA45PmwZnfelot1 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.getmtime(WNJf94Oj2SC3InsRtK6)
		HVo1hFNm72wup35f.append([E2YPvG7AZ81,jj8a9Sq0FzyUkQA45PmwZnfelot1])
	HVo1hFNm72wup35f = sorted(HVo1hFNm72wup35f,reverse=IJ6VkihabRm(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠶৲")])
	for E2YPvG7AZ81,jj8a9Sq0FzyUkQA45PmwZnfelot1 in HVo1hFNm72wup35f:
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			try: E2YPvG7AZ81 = E2YPvG7AZ81.decode(L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			E2YPvG7AZ81 = E2YPvG7AZ81.encode(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		WNJf94Oj2SC3InsRtK6 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XXjnwM5QpPkISbdcWruxRetJ3,E2YPvG7AZ81)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),E2YPvG7AZ81,WNJf94Oj2SC3InsRtK6,tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠹࠳࠲৳"))
	return
def wdqoXCGizgh8BIr0JyjHnQP():
	XXjnwM5QpPkISbdcWruxRetJ3 = fQ6kvwg1FrYAzXjbLT.getSetting(ddK4MmwpX5oG(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if XXjnwM5QpPkISbdcWruxRetJ3: return XXjnwM5QpPkISbdcWruxRetJ3
	fQ6kvwg1FrYAzXjbLT.setSetting(fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),vBXJAQCwEpS0xZ6km9a)
	return vBXJAQCwEpS0xZ6km9a
def WPbJc3GUuYAtyvOdg06():
	XXjnwM5QpPkISbdcWruxRetJ3 = wdqoXCGizgh8BIr0JyjHnQP()
	Lm0qAYTM5cwrhdNsakVE = C5JBeSxPzuskXi1ROnMHAmWp06dE7(xxpPYJOnoAUrlBzyveui(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),xxBJoKG54uwQ(u"࠭ࠧश"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࠨष"),V391t7nQWUBR5euCkJ(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),IJ6VkihabRm(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+XXjnwM5QpPkISbdcWruxRetJ3+ZpH2IWt7veyFobTsAnhi41(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if Lm0qAYTM5cwrhdNsakVE==DKqQekNtF6WlJLhBP9M5ca(u"࠱৴"):
		ZVLdQqBI9O5St0AsGnMm3l1FroJKh = kHM96EzbxfBc3giF4CeIU(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠴৵"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),v7reLlOXCgD5pZ14w2tUA(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),zOZvXaebGNwHKfjRA(u"࠭ࠧऽ"),zOZvXaebGNwHKfjRA(u"ࡇࡣ࡯ࡷࡪਟ"),V391t7nQWUBR5euCkJ(u"ࡔࡳࡷࡨਞ"),XXjnwM5QpPkISbdcWruxRetJ3)
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(IJ6VkihabRm(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࠩि"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࠪी"),qNZKwi2M1S4fBzGQYrmPnea(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+XXjnwM5QpPkISbdcWruxRetJ3+zOZvXaebGNwHKfjRA(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if T4TGmZ9XWAzONaKygic==p1lrNRIXqLQJznH6O(u"࠳৶"):
			fQ6kvwg1FrYAzXjbLT.setSetting(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),ZVLdQqBI9O5St0AsGnMm3l1FroJKh)
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxBJoKG54uwQ(u"ࠧࠨॅ"),xxpPYJOnoAUrlBzyveui(u"ࠨࠩॆ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def DM0SiqWCmxHNnFKUjI6J(HbqSfZ6m7FAa,fBYse5u6VkLhmcZg=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࠬॉ"),website=Vv0lSjAOHLfMnam3wtdor(u"ࠬ࠭ॊ")):
	zRM3tZx2v6DjJU(KbL94nDHufSF0VcO2Nk3(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+DKqQekNtF6WlJLhBP9M5ca(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+HbqSfZ6m7FAa+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࠢࡠ्ࠫ"))
	if not fBYse5u6VkLhmcZg: fBYse5u6VkLhmcZg = H93DlbtKLEarfQ8w7GcoIukSexv0J(HbqSfZ6m7FAa)
	XXjnwM5QpPkISbdcWruxRetJ3 = wdqoXCGizgh8BIr0JyjHnQP()
	nZkScXxgspimo41H36h = q9AltNyD2Q1uL()
	E2YPvG7AZ81 = nZkScXxgspimo41H36h.replace(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࠣࠫॎ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡣࠬॏ"))
	E2YPvG7AZ81 = ZVgGt1Ua7ChRz4ElJBp9YTqMS(E2YPvG7AZ81)
	E2YPvG7AZ81 = qNZKwi2M1S4fBzGQYrmPnea(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(Low1uSVG5OcafJmrYBC7D))[-uhOkAKtLVv4XTy1nWE6(u"࠷৷"):]+HMO0QciekqVpLKmA(u"ࠬࡥࠧ॑")+E2YPvG7AZ81+fBYse5u6VkLhmcZg
	JzpbPSvGENtgV = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XXjnwM5QpPkISbdcWruxRetJ3,E2YPvG7AZ81)
	JWZYMU9luoKCAD7ybSBQ = {}
	JWZYMU9luoKCAD7ybSBQ[q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = ddK4MmwpX5oG(u"ࠧࠨ॓")
	JWZYMU9luoKCAD7ybSBQ[vkMRnTNV9jFm(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = zOZvXaebGNwHKfjRA(u"ࠩ࠭࠳࠯࠭ॕ")
	HbqSfZ6m7FAa = HbqSfZ6m7FAa.replace(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),GGTRaYBDeNyI25zlF(u"ࠫࠬॗ"))
	if ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in HbqSfZ6m7FAa:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao,oOM6fji0UV3Yn2 = HbqSfZ6m7FAa.rsplit(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),V391t7nQWUBR5euCkJ(u"࠵৸"))
		oOM6fji0UV3Yn2 = oOM6fji0UV3Yn2.replace(dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡽࠩग़"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࠩज़")).replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࠩࠫड़"),ZpH2IWt7veyFobTsAnhi41(u"ࠪࠫढ़"))
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao,oOM6fji0UV3Yn2 = HbqSfZ6m7FAa,None
	if not oOM6fji0UV3Yn2: oOM6fji0UV3Yn2 = yWgZFzdaNR5iw6m8Q9G7CL()
	if oOM6fji0UV3Yn2: JWZYMU9luoKCAD7ybSBQ[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = oOM6fji0UV3Yn2
	if fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao,PYWfQI0KxebFTymtXdwBalCG58qg3L = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.rsplit(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),GGTRaYBDeNyI25zlF(u"࠶৹"))
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao,PYWfQI0KxebFTymtXdwBalCG58qg3L = lZqkuhgaBHSVX8NItKG05cdLJe7Ao,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࠨॡ")
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.strip(ddK4MmwpX5oG(u"ࠨࡾࠪॢ")).strip(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࠩࠫॣ")).strip(fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࢀࠬ।")).strip(GGTRaYBDeNyI25zlF(u"ࠫࠫ࠭॥"))
	PYWfQI0KxebFTymtXdwBalCG58qg3L = PYWfQI0KxebFTymtXdwBalCG58qg3L.replace(xxpPYJOnoAUrlBzyveui(u"ࠬࢂࠧ०"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠧ१")).replace(xxBJoKG54uwQ(u"ࠧࠧࠩ२"),dxAs4otSE98YmZnKy2iwRCB(u"ࠨࠩ३"))
	if PYWfQI0KxebFTymtXdwBalCG58qg3L:	JWZYMU9luoKCAD7ybSBQ[d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = PYWfQI0KxebFTymtXdwBalCG58qg3L
	zRM3tZx2v6DjJU(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+dxAs4otSE98YmZnKy2iwRCB(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+uhOkAKtLVv4XTy1nWE6(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(JWZYMU9luoKCAD7ybSBQ)+OARzhnB9o7uYvQGFaIcZ(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+JzpbPSvGENtgV+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠡ࡟ࠪ९"))
	vjaYg08OXptG9rx4z67WKhB = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠷࠰࠳࠶৺")*tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠷࠰࠳࠶৺")
	oXChxZufs9Uvk1dqcD = Vv0lSjAOHLfMnam3wtdor(u"࠰৻")
	try:
		ZDw4sYmQEUkv =	AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(xxBJoKG54uwQ(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		ZDw4sYmQEUkv = QPuHKNAT4jmCRg.findall(Vv0lSjAOHLfMnam3wtdor(u"ࠩ࡟ࡨ࠰࠭ॱ"),ZDw4sYmQEUkv)
		oXChxZufs9Uvk1dqcD = int(ZDw4sYmQEUkv[uhOkAKtLVv4XTy1nWE6(u"࠱ৼ")])
	except: pass
	if not oXChxZufs9Uvk1dqcD:
		try:
			MJsCBK0NUPbdA8pzI9ixhgyo = YcJmC0W43u5idIELnHTU2XSsMPNt.statvfs(XXjnwM5QpPkISbdcWruxRetJ3)
			oXChxZufs9Uvk1dqcD = MJsCBK0NUPbdA8pzI9ixhgyo.f_frsize*MJsCBK0NUPbdA8pzI9ixhgyo.f_bavail//vjaYg08OXptG9rx4z67WKhB
		except: pass
	if not oXChxZufs9Uvk1dqcD:
		try:
			MJsCBK0NUPbdA8pzI9ixhgyo = YcJmC0W43u5idIELnHTU2XSsMPNt.fstatvfs(XXjnwM5QpPkISbdcWruxRetJ3)
			oXChxZufs9Uvk1dqcD = MJsCBK0NUPbdA8pzI9ixhgyo.f_frsize*MJsCBK0NUPbdA8pzI9ixhgyo.f_bavail//vjaYg08OXptG9rx4z67WKhB
		except: pass
	if not oXChxZufs9Uvk1dqcD:
		try:
			import shutil as ry5PWL9G4Jt
			deHnPcoI5CQG8hVt4Zs,LVa5g6Ul8y,ySKGvsxfc5MHYT = ry5PWL9G4Jt.disk_usage(XXjnwM5QpPkISbdcWruxRetJ3)
			oXChxZufs9Uvk1dqcD = ySKGvsxfc5MHYT//vjaYg08OXptG9rx4z67WKhB
		except: pass
	if not oXChxZufs9Uvk1dqcD:
		qQL7e23RtCg4xOpf(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),dxAs4otSE98YmZnKy2iwRCB(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),p1lrNRIXqLQJznH6O(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),zOZvXaebGNwHKfjRA(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		zRM3tZx2v6DjJU(ZpH2IWt7veyFobTsAnhi41(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+IJ6VkihabRm(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return fcIm8tvxlXZsaEY3bwuG4B(u"ࡈࡤࡰࡸ࡫ਠ")
	if fBYse5u6VkLhmcZg==GGTRaYBDeNyI25zlF(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = RjzVfbE0ILcNXFQJniSMBOskK13ox(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,JWZYMU9luoKCAD7ybSBQ)
		if len(xitERh4TD2jGJPq5Nuv39CAmg)==V391t7nQWUBR5euCkJ(u"࠲৽"):
			uFCykYQW68S(fcIm8tvxlXZsaEY3bwuG4B(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),uhOkAKtLVv4XTy1nWE6(u"ࠫࠬॺ"))
			return a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡉࡥࡱࡹࡥਡ")
		elif len(xitERh4TD2jGJPq5Nuv39CAmg)==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠴৾"): ShT1xUHjlDotkRuPq7gv = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠴৿")
		elif len(xitERh4TD2jGJPq5Nuv39CAmg)>ZpH2IWt7veyFobTsAnhi41(u"࠶਀"):
			ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB(p1lrNRIXqLQJznH6O(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), xitERh4TD2jGJPq5Nuv39CAmg)
			if ShT1xUHjlDotkRuPq7gv == -ZpH2IWt7veyFobTsAnhi41(u"࠷ਁ") :
				uFCykYQW68S(DKqQekNtF6WlJLhBP9M5ca(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࠨॽ"))
				return OARzhnB9o7uYvQGFaIcZ(u"ࡊࡦࡲࡳࡦਢ")
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = LL8heV7kxYI5bOjEZ6XaUQWwfPA[ShT1xUHjlDotkRuPq7gv]
	AZfqG4uMTlkWnpL = OARzhnB9o7uYvQGFaIcZ(u"࠰ਂ")
	if fBYse5u6VkLhmcZg==ZpH2IWt7veyFobTsAnhi41(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		JzpbPSvGENtgV = JzpbPSvGENtgV.rsplit(DDS79jdWzLtE(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[DKqQekNtF6WlJLhBP9M5ca(u"࠱ਃ")]+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,p1lrNRIXqLQJznH6O(u"ࠫࡌࡋࡔࠨঁ"),lZqkuhgaBHSVX8NItKG05cdLJe7Ao,zOZvXaebGNwHKfjRA(u"ࠬ࠭ং"),JWZYMU9luoKCAD7ybSBQ,zOZvXaebGNwHKfjRA(u"࠭ࠧঃ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠨ঄"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		BKr4YfRJvW7el6CUMk9qh = vqUSBHDtn5Rl6Vyc8.content
		Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),BKr4YfRJvW7el6CUMk9qh+ddK4MmwpX5oG(u"ࠪࡠࡳࡢࡲࠨই"),QPuHKNAT4jmCRg.DOTALL)
		if not Y4xiULzGTKjb8mulO:
			zRM3tZx2v6DjJU(Vv0lSjAOHLfMnam3wtdor(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+p1lrNRIXqLQJznH6O(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࠠ࡞ࠩঊ"))
			return V391t7nQWUBR5euCkJ(u"ࡋࡧ࡬ࡴࡧਣ")
		VV7yf2htDCBU6EeSX8TJQM = Y4xiULzGTKjb8mulO[DKqQekNtF6WlJLhBP9M5ca(u"࠲਄")]
		if not VV7yf2htDCBU6EeSX8TJQM.startswith(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if VV7yf2htDCBU6EeSX8TJQM.startswith(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨ࠱࠲ࠫঌ")): VV7yf2htDCBU6EeSX8TJQM = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split(IJ6VkihabRm(u"ࠩ࠽ࠫ঍"),DDS79jdWzLtE(u"࠴ਅ"))[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠴ਆ")]+DKqQekNtF6WlJLhBP9M5ca(u"ࠪ࠾ࠬ঎")+VV7yf2htDCBU6EeSX8TJQM
			elif VV7yf2htDCBU6EeSX8TJQM.startswith(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫ࠴࠭এ")): VV7yf2htDCBU6EeSX8TJQM = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,v7reLlOXCgD5pZ14w2tUA(u"ࠬࡻࡲ࡭ࠩঐ"))+VV7yf2htDCBU6EeSX8TJQM
			else: VV7yf2htDCBU6EeSX8TJQM = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.rsplit(DKqQekNtF6WlJLhBP9M5ca(u"࠭࠯ࠨ঑"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠶ਇ"))[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶ਈ")]+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࠰ࠩ঒")+VV7yf2htDCBU6EeSX8TJQM
		vqUSBHDtn5Rl6Vyc8 = D0nOE8Wu9jfHxPTIXiLVypGB.request(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡉࡈࡘࠬও"),VV7yf2htDCBU6EeSX8TJQM,headers=JWZYMU9luoKCAD7ybSBQ,verify=lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡌࡡ࡭ࡵࡨਤ"))
		vHEaZUKPOYmVxXeQ = vqUSBHDtn5Rl6Vyc8.content
		ZIXJhPtfAe2xyznYwjR = len(vHEaZUKPOYmVxXeQ)
		WIKOL4xFeGmz = len(Y4xiULzGTKjb8mulO)
		AZfqG4uMTlkWnpL = ZIXJhPtfAe2xyznYwjR*WIKOL4xFeGmz
	else:
		ZIXJhPtfAe2xyznYwjR = HMO0QciekqVpLKmA(u"࠱ਉ")*vjaYg08OXptG9rx4z67WKhB
		vqUSBHDtn5Rl6Vyc8 = D0nOE8Wu9jfHxPTIXiLVypGB.request(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡊࡉ࡙࠭ঔ"),lZqkuhgaBHSVX8NItKG05cdLJe7Ao,headers=JWZYMU9luoKCAD7ybSBQ,verify=zOZvXaebGNwHKfjRA(u"ࡇࡣ࡯ࡷࡪਦ"),stream=uhOkAKtLVv4XTy1nWE6(u"ࡔࡳࡷࡨਥ"))
		if zOZvXaebGNwHKfjRA(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in vqUSBHDtn5Rl6Vyc8.headers: AZfqG4uMTlkWnpL = int(vqUSBHDtn5Rl6Vyc8.headers[DKqQekNtF6WlJLhBP9M5ca(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		WIKOL4xFeGmz = int(AZfqG4uMTlkWnpL//ZIXJhPtfAe2xyznYwjR)
	X5uhI4RHtUmC3zY7GSx2Jowp1BENbv = int(AZfqG4uMTlkWnpL//vjaYg08OXptG9rx4z67WKhB)+q0JfWbP8vACLxSNIncpOXkR6j(u"࠲ਊ")
	if AZfqG4uMTlkWnpL<DKqQekNtF6WlJLhBP9M5ca(u"࠴࠴࠴࠵࠶਋"):
		zRM3tZx2v6DjJU(V391t7nQWUBR5euCkJ(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+lunVJF2G5bZMgTcCje0vaIB371SX(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+HMO0QciekqVpLKmA(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(X5uhI4RHtUmC3zY7GSx2Jowp1BENbv)+p1lrNRIXqLQJznH6O(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(oXChxZufs9Uvk1dqcD)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+JzpbPSvGENtgV+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࠤࡢ࠭জ"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxpPYJOnoAUrlBzyveui(u"ࠫࠬঝ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬ࠭ঞ"),V391t7nQWUBR5euCkJ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),DDS79jdWzLtE(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return dxAs4otSE98YmZnKy2iwRCB(u"ࡈࡤࡰࡸ࡫ਧ")
	Nw6czCgXvT8qyDJ9LOmuifeAk = fcIm8tvxlXZsaEY3bwuG4B(u"࠷࠴࠵਌")
	B3LSeljrZdv06tUFYV = oXChxZufs9Uvk1dqcD-X5uhI4RHtUmC3zY7GSx2Jowp1BENbv
	if B3LSeljrZdv06tUFYV<Nw6czCgXvT8qyDJ9LOmuifeAk:
		zRM3tZx2v6DjJU(ZpH2IWt7veyFobTsAnhi41(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+Vv0lSjAOHLfMnam3wtdor(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+OARzhnB9o7uYvQGFaIcZ(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(X5uhI4RHtUmC3zY7GSx2Jowp1BENbv)+xxBJoKG54uwQ(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(oXChxZufs9Uvk1dqcD)+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(Nw6czCgXvT8qyDJ9LOmuifeAk)+zOZvXaebGNwHKfjRA(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+JzpbPSvGENtgV+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠡ࡟ࠪধ"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ZpH2IWt7veyFobTsAnhi41(u"ࠨࠩন"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࠪ঩"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),zOZvXaebGNwHKfjRA(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(X5uhI4RHtUmC3zY7GSx2Jowp1BENbv)+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(oXChxZufs9Uvk1dqcD)+v7reLlOXCgD5pZ14w2tUA(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(Nw6czCgXvT8qyDJ9LOmuifeAk)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return vkMRnTNV9jFm(u"ࡉࡥࡱࡹࡥਨ")
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(v7reLlOXCgD5pZ14w2tUA(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࠪর"),xxBJoKG54uwQ(u"ࠪࠫ঱"),xxBJoKG54uwQ(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(X5uhI4RHtUmC3zY7GSx2Jowp1BENbv)+qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(oXChxZufs9Uvk1dqcD)+uhOkAKtLVv4XTy1nWE6(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if T4TGmZ9XWAzONaKygic!=u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠵਍"):
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࠩশ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࠪষ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࠫস"),DKqQekNtF6WlJLhBP9M5ca(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		zRM3tZx2v6DjJU(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+KbL94nDHufSF0VcO2Nk3(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+JzpbPSvGENtgV+f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࠢࡠࠫঽ"))
		return tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡊࡦࡲࡳࡦ਩")
	zRM3tZx2v6DjJU(p1lrNRIXqLQJznH6O(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+DKqQekNtF6WlJLhBP9M5ca(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	smMzArf4FkJ1NDKEx = zzyalh3A275njbIKsD0EQ()
	smMzArf4FkJ1NDKEx.create(JzpbPSvGENtgV,ddK4MmwpX5oG(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	HvxLXelj8K9ZaCJTn3so6fg5qdPb = xxBJoKG54uwQ(u"࡙ࡸࡵࡦਪ")
	g27TaovWhPEzbHsY39Bw = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
	if Nnxm30dfoBWRYpIC7KsQGl: EBFI0DK25XJb8CqPj3dscL6w = open(JzpbPSvGENtgV,GGTRaYBDeNyI25zlF(u"ࠬࡽࡢࠨু"))
	else: EBFI0DK25XJb8CqPj3dscL6w = open(JzpbPSvGENtgV.decode(KbL94nDHufSF0VcO2Nk3(u"࠭ࡵࡵࡨ࠻ࠫূ")),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧࡸࡤࠪৃ"))
	if fBYse5u6VkLhmcZg==DDS79jdWzLtE(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for kdWCpE9TjNh in range(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠶਎"),WIKOL4xFeGmz+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠶਎")):
			VV7yf2htDCBU6EeSX8TJQM = Y4xiULzGTKjb8mulO[kdWCpE9TjNh-lunVJF2G5bZMgTcCje0vaIB371SX(u"࠷ਏ")]
			if not VV7yf2htDCBU6EeSX8TJQM.startswith(ZpH2IWt7veyFobTsAnhi41(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if VV7yf2htDCBU6EeSX8TJQM.startswith(L91nVzxH4hYrgPDsOuljXd0J(u"ࠪ࠳࠴࠭৆")): VV7yf2htDCBU6EeSX8TJQM = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.split(p1lrNRIXqLQJznH6O(u"ࠫ࠿࠭ে"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠱ਐ"))[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠱਑")]+fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡀࠧৈ")+VV7yf2htDCBU6EeSX8TJQM
				elif VV7yf2htDCBU6EeSX8TJQM.startswith(dxAs4otSE98YmZnKy2iwRCB(u"࠭࠯ࠨ৉")): VV7yf2htDCBU6EeSX8TJQM = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,p1lrNRIXqLQJznH6O(u"ࠧࡶࡴ࡯ࠫ৊"))+VV7yf2htDCBU6EeSX8TJQM
				else: VV7yf2htDCBU6EeSX8TJQM = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.rsplit(IJ6VkihabRm(u"ࠨ࠱ࠪো"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠳਒"))[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠳ਓ")]+HMO0QciekqVpLKmA(u"ࠩ࠲ࠫৌ")+VV7yf2htDCBU6EeSX8TJQM
			vqUSBHDtn5Rl6Vyc8 = D0nOE8Wu9jfHxPTIXiLVypGB.request(vkMRnTNV9jFm(u"ࠪࡋࡊ্࡚ࠧ"),VV7yf2htDCBU6EeSX8TJQM,headers=JWZYMU9luoKCAD7ybSBQ,verify=fcIm8tvxlXZsaEY3bwuG4B(u"ࡌࡡ࡭ࡵࡨਫ"))
			vHEaZUKPOYmVxXeQ = vqUSBHDtn5Rl6Vyc8.content
			vqUSBHDtn5Rl6Vyc8.close()
			EBFI0DK25XJb8CqPj3dscL6w.write(vHEaZUKPOYmVxXeQ)
			N1ErdyMWIUaLnzPY = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
			zCoR75y3XPhics0 = N1ErdyMWIUaLnzPY-g27TaovWhPEzbHsY39Bw
			oLUwg8Hkj2qZcy4aQXpOreBvK9 = zCoR75y3XPhics0//kdWCpE9TjNh
			jGBp34bnRfk5U8Nxy = oLUwg8Hkj2qZcy4aQXpOreBvK9*(WIKOL4xFeGmz+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠵ਔ"))
			HqbKoWdRArgIJamLzh9fC = jGBp34bnRfk5U8Nxy-zCoR75y3XPhics0
			Qm8DTfKEUrdMvXzO7(smMzArf4FkJ1NDKEx,int(q0JfWbP8vACLxSNIncpOXkR6j(u"࠷࠰࠱ਖ")*kdWCpE9TjNh//(WIKOL4xFeGmz+p1lrNRIXqLQJznH6O(u"࠶ਕ"))),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(kdWCpE9TjNh*ZIXJhPtfAe2xyznYwjR//vjaYg08OXptG9rx4z67WKhB)+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭࠯ࠨ৐")+str(X5uhI4RHtUmC3zY7GSx2Jowp1BENbv)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime(OARzhnB9o7uYvQGFaIcZ(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2.gmtime(HqbKoWdRArgIJamLzh9fC))+V391t7nQWUBR5euCkJ(u"ࠩࠣไࠬ৓"))
			if smMzArf4FkJ1NDKEx.iscanceled():
				HvxLXelj8K9ZaCJTn3so6fg5qdPb = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		kdWCpE9TjNh = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠰ਗ")
		for vHEaZUKPOYmVxXeQ in vqUSBHDtn5Rl6Vyc8.iter_content(chunk_size=ZIXJhPtfAe2xyznYwjR):
			EBFI0DK25XJb8CqPj3dscL6w.write(vHEaZUKPOYmVxXeQ)
			kdWCpE9TjNh = kdWCpE9TjNh+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠲ਘ")
			N1ErdyMWIUaLnzPY = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
			zCoR75y3XPhics0 = N1ErdyMWIUaLnzPY-g27TaovWhPEzbHsY39Bw
			oLUwg8Hkj2qZcy4aQXpOreBvK9 = zCoR75y3XPhics0/kdWCpE9TjNh
			jGBp34bnRfk5U8Nxy = oLUwg8Hkj2qZcy4aQXpOreBvK9*(WIKOL4xFeGmz+fcIm8tvxlXZsaEY3bwuG4B(u"࠳ਙ"))
			HqbKoWdRArgIJamLzh9fC = jGBp34bnRfk5U8Nxy-zCoR75y3XPhics0
			Qm8DTfKEUrdMvXzO7(smMzArf4FkJ1NDKEx,int(uhOkAKtLVv4XTy1nWE6(u"࠵࠵࠶ਛ")*kdWCpE9TjNh/(WIKOL4xFeGmz+L91nVzxH4hYrgPDsOuljXd0J(u"࠴ਚ"))),ddK4MmwpX5oG(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(kdWCpE9TjNh*ZIXJhPtfAe2xyznYwjR//vjaYg08OXptG9rx4z67WKhB)+ddK4MmwpX5oG(u"ࠬ࠵ࠧ৖")+str(X5uhI4RHtUmC3zY7GSx2Jowp1BENbv)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime(ZpH2IWt7veyFobTsAnhi41(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2.gmtime(HqbKoWdRArgIJamLzh9fC))+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠢใࠫ৙"))
			if smMzArf4FkJ1NDKEx.iscanceled():
				HvxLXelj8K9ZaCJTn3so6fg5qdPb = xxpPYJOnoAUrlBzyveui(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		vqUSBHDtn5Rl6Vyc8.close()
	EBFI0DK25XJb8CqPj3dscL6w.close()
	smMzArf4FkJ1NDKEx.close()
	if not HvxLXelj8K9ZaCJTn3so6fg5qdPb:
		zRM3tZx2v6DjJU(Vv0lSjAOHLfMnam3wtdor(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+v7reLlOXCgD5pZ14w2tUA(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+JzpbPSvGENtgV+zOZvXaebGNwHKfjRA(u"ࠬࠦ࡝ࠨঢ়"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(p1lrNRIXqLQJznH6O(u"࠭ࠧ৞"),GGTRaYBDeNyI25zlF(u"ࠧࠨয়"),OARzhnB9o7uYvQGFaIcZ(u"ࠨࠩৠ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return uhOkAKtLVv4XTy1nWE6(u"ࡖࡵࡹࡪਮ")
	zRM3tZx2v6DjJU(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+V391t7nQWUBR5euCkJ(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+JzpbPSvGENtgV+dxAs4otSE98YmZnKy2iwRCB(u"࠭ࠠ࡞ࠩ৥"))
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(DDS79jdWzLtE(u"ࠧࠨ০"),ZpH2IWt7veyFobTsAnhi41(u"ࠨࠩ১"),Vv0lSjAOHLfMnam3wtdor(u"ࠩࠪ২"),GGTRaYBDeNyI25zlF(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return ZpH2IWt7veyFobTsAnhi41(u"ࡗࡶࡺ࡫ਯ")
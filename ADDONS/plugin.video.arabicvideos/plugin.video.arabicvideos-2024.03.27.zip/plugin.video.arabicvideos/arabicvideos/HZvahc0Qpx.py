# -*- coding: utf-8 -*-
import sys as GJtcqTv68ZQpwxYFiDg
yyIoQrPWR1B = GJtcqTv68ZQpwxYFiDg.version_info [0] == 2
Duhwt2HMRTeBonVic0lz8bjUJ = 2048
BnAMltLNqzHfjxWkVi9eb3P = 7
def rrgVqwDZPsMjxvR3EylNz9 (tbA2GsXVSDNgm):
	global lzR5Gp9sjoDwb
	BZb90tzYkgeu3pcAo = ord (tbA2GsXVSDNgm [-1])
	fdK96q2bHgSIwE = tbA2GsXVSDNgm [:-1]
	klvdJbzV7PEMciQ61A0t25SGXq8 = BZb90tzYkgeu3pcAo % len (fdK96q2bHgSIwE)
	q5yMKdNsYpzDj8Oo = fdK96q2bHgSIwE [:klvdJbzV7PEMciQ61A0t25SGXq8] + fdK96q2bHgSIwE [klvdJbzV7PEMciQ61A0t25SGXq8:]
	if yyIoQrPWR1B:
		hq2Yj5TvMOKsRFroabWu = unicode () .join ([unichr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	else:
		hq2Yj5TvMOKsRFroabWu = str () .join ([chr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	return eval (hq2Yj5TvMOKsRFroabWu)
iRTygNp4Lf36wQKlD2MHUhG7B,KbL94nDHufSF0VcO2Nk3,qNZKwi2M1S4fBzGQYrmPnea=rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9
xxpPYJOnoAUrlBzyveui,ldOGfm56kWs8T03wcptQunqEUBDrvC,Arg2GFJDt3emTvpO6fZkSVdaUHywnN=qNZKwi2M1S4fBzGQYrmPnea,KbL94nDHufSF0VcO2Nk3,iRTygNp4Lf36wQKlD2MHUhG7B
v7reLlOXCgD5pZ14w2tUA,p1lrNRIXqLQJznH6O,ddK4MmwpX5oG=Arg2GFJDt3emTvpO6fZkSVdaUHywnN,ldOGfm56kWs8T03wcptQunqEUBDrvC,xxpPYJOnoAUrlBzyveui
OARzhnB9o7uYvQGFaIcZ,ZpH2IWt7veyFobTsAnhi41,q0JfWbP8vACLxSNIncpOXkR6j=ddK4MmwpX5oG,p1lrNRIXqLQJznH6O,v7reLlOXCgD5pZ14w2tUA
L91nVzxH4hYrgPDsOuljXd0J,uhOkAKtLVv4XTy1nWE6,d1JiVThqEO0nBaY2QRNyZxlujWw7SK=q0JfWbP8vACLxSNIncpOXkR6j,ZpH2IWt7veyFobTsAnhi41,OARzhnB9o7uYvQGFaIcZ
V391t7nQWUBR5euCkJ,IJ6VkihabRm,lunVJF2G5bZMgTcCje0vaIB371SX=d1JiVThqEO0nBaY2QRNyZxlujWw7SK,uhOkAKtLVv4XTy1nWE6,L91nVzxH4hYrgPDsOuljXd0J
xxBJoKG54uwQ,gr5K72RtvAZYPVwkdnspbzQWNjEI,u1ml5XcLiZ7oDPs3UjedgpYHhfV=lunVJF2G5bZMgTcCje0vaIB371SX,IJ6VkihabRm,V391t7nQWUBR5euCkJ
dxAs4otSE98YmZnKy2iwRCB,fcIm8tvxlXZsaEY3bwuG4B,f8PVRTseIuj9BckO6GoyF5Lxv=u1ml5XcLiZ7oDPs3UjedgpYHhfV,gr5K72RtvAZYPVwkdnspbzQWNjEI,xxBJoKG54uwQ
tKVplxqYIdngGF6TZkXeb2PiwfME,vkMRnTNV9jFm,HMO0QciekqVpLKmA=f8PVRTseIuj9BckO6GoyF5Lxv,fcIm8tvxlXZsaEY3bwuG4B,dxAs4otSE98YmZnKy2iwRCB
DKqQekNtF6WlJLhBP9M5ca,GGTRaYBDeNyI25zlF,Vv0lSjAOHLfMnam3wtdor=HMO0QciekqVpLKmA,vkMRnTNV9jFm,tKVplxqYIdngGF6TZkXeb2PiwfME
a06i2XFf3oBnDrJQZEKmHpqY9ACW,DDS79jdWzLtE,zOZvXaebGNwHKfjRA=Vv0lSjAOHLfMnam3wtdor,GGTRaYBDeNyI25zlF,DKqQekNtF6WlJLhBP9M5ca
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
JE7QrkmhletLwA0OZXu = HMO0QciekqVpLKmA(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
fFprTtCJKyvzL5oN4uk = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(X8jt4IEY3WdFmbpreC2,KbL94nDHufSF0VcO2Nk3(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
O9OEHA52g1JN8r3 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(X8jt4IEY3WdFmbpreC2,vkMRnTNV9jFm(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
A7RfyBMGzi5tEnKxUN8I6L = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),OARzhnB9o7uYvQGFaIcZ(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
jjJVH1ZFzOIecS9mxfBibl2UEaqhsN = MbCGIVc1LiYlq9K4gyDZ
ASi3T9NhIqCJ8Fg2xf0uLt = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
SjBdhHTIK9 = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
kdtJeHNhzu = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
Nh6G7KPEvAORtYJ2ClI3xMQDgaSj = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
IxhYCHV2OGB631RXqp8gUwJTn = ZpH2IWt7veyFobTsAnhi41(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
NEOQx48CyzG2mnlDBscaHWRkb = xxpPYJOnoAUrlBzyveui(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def hLD0mk9HIuPOz7pw(mode):
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠹࠷࠴ࣉ"): RRMWBwU6pG = r2BXQPb0f9oMFNYJdwyOL5SAUhz()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==lunVJF2G5bZMgTcCje0vaIB371SX(u"࠺࠸࠶࣊"): RRMWBwU6pG = Qzbnt3opXim(fFprTtCJKyvzL5oN4uk,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡖࡵࡹࡪࣳ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡖࡵࡹࡪࣳ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠻࠹࠸࣋"): RRMWBwU6pG = Qzbnt3opXim(O9OEHA52g1JN8r3,xxBJoKG54uwQ(u"ࡗࡶࡺ࡫ࣴ"),xxBJoKG54uwQ(u"ࡗࡶࡺ࡫ࣴ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==DDS79jdWzLtE(u"࠼࠺࠳࣌"): RRMWBwU6pG = Qzbnt3opXim(A7RfyBMGzi5tEnKxUN8I6L,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡋࡧ࡬ࡴࡧࣶ"),xxBJoKG54uwQ(u"ࡘࡷࡻࡥࣵ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==qNZKwi2M1S4fBzGQYrmPnea(u"࠽࠴࠵࣍"): RRMWBwU6pG = CMakTmSPjrXiABu9zUJloHqbE3(jjJVH1ZFzOIecS9mxfBibl2UEaqhsN,DKqQekNtF6WlJLhBP9M5ca(u"࡚ࡲࡶࡧࣷ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠷࠵࠷࣎"): RRMWBwU6pG = JwDXYizBLv48(xxBJoKG54uwQ(u"ࡔࡳࡷࡨࣸ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==DKqQekNtF6WlJLhBP9M5ca(u"࠸࠷࠳࣏"): RRMWBwU6pG = UcopwziCYrSnj()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠹࠸࠵࣐"): RRMWBwU6pG = Qzbnt3opXim(ASi3T9NhIqCJ8Fg2xf0uLt,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡈࡤࡰࡸ࡫ࣺ"),HMO0QciekqVpLKmA(u"ࡕࡴࡸࡩࣹ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠺࠹࠷࣑"): RRMWBwU6pG = Qzbnt3opXim(SjBdhHTIK9,zOZvXaebGNwHKfjRA(u"ࡊࡦࡲࡳࡦࣼ"),OARzhnB9o7uYvQGFaIcZ(u"ࡗࡶࡺ࡫ࣻ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==L91nVzxH4hYrgPDsOuljXd0J(u"࠻࠺࠹࣒"): RRMWBwU6pG = Qzbnt3opXim(kdtJeHNhzu,KbL94nDHufSF0VcO2Nk3(u"ࡌࡡ࡭ࡵࡨࣾ"),DKqQekNtF6WlJLhBP9M5ca(u"࡙ࡸࡵࡦࣽ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==Vv0lSjAOHLfMnam3wtdor(u"࠼࠻࠴࣓"): RRMWBwU6pG = Qzbnt3opXim(Nh6G7KPEvAORtYJ2ClI3xMQDgaSj,p1lrNRIXqLQJznH6O(u"ࡇࡣ࡯ࡷࡪऀ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡔࡳࡷࡨࣿ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==qNZKwi2M1S4fBzGQYrmPnea(u"࠽࠵࠶ࣔ"): RRMWBwU6pG = Qzbnt3opXim(IxhYCHV2OGB631RXqp8gUwJTn,DKqQekNtF6WlJLhBP9M5ca(u"ࡉࡥࡱࡹࡥं"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡖࡵࡹࡪँ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠷࠶࠸ࣕ"): RRMWBwU6pG = Qzbnt3opXim(NEOQx48CyzG2mnlDBscaHWRkb,V391t7nQWUBR5euCkJ(u"ࡋࡧ࡬ࡴࡧऄ"),GGTRaYBDeNyI25zlF(u"ࡘࡷࡻࡥः"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠸࠷࠺ࣖ"): RRMWBwU6pG = KHbjG0hCl7yF3cUig6YIBrAVPEmL(xxBJoKG54uwQ(u"࡚ࡲࡶࡧअ"))
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠹࠸࠼ࣗ"): RRMWBwU6pG = vw5KyoYLCHINfVZPeF0jkcG69pxAJO()
	else: RRMWBwU6pG = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡆࡢ࡮ࡶࡩआ")
	return RRMWBwU6pG
def r2BXQPb0f9oMFNYJdwyOL5SAUhz():
	f57eoTEzNCr19PgbXAKhY8MLQtq6,yytFTW4gxlaV3sm2DGEb6 = HqC0JDhnG7cTFIBa2d4Wv(fFprTtCJKyvzL5oN4uk)
	G19uXt3rmcYvnjyJM7iPaI6zSQ,rKyiku9QZGDx = HqC0JDhnG7cTFIBa2d4Wv(O9OEHA52g1JN8r3)
	AUMZDfY6201RIpJk,cIkaWEhHsD2YpmqLeVRFu = HqC0JDhnG7cTFIBa2d4Wv(A7RfyBMGzi5tEnKxUN8I6L)
	Xer206Iq9VOc,xxIq3CEDYHT1QS5RzAJMX7oFrUK = jGA1fuPNEcDJC7TFb9xhO30R(jjJVH1ZFzOIecS9mxfBibl2UEaqhsN)
	Xer206Iq9VOc -= ddK4MmwpX5oG(u"࠶࠺࠽࠼࠴ࣘ")
	xxIq3CEDYHT1QS5RzAJMX7oFrUK -= ZpH2IWt7veyFobTsAnhi41(u"࠵ࣙ")
	TNdKcREB9AwzlF6r0aHv = GGTRaYBDeNyI25zlF(u"ࠩࠣࠬࠬࠌ")+e5MprbQaG8wDA4uJk(f57eoTEzNCr19PgbXAKhY8MLQtq6)+OARzhnB9o7uYvQGFaIcZ(u"ࠪࠤ࠲ࠦࠧࠍ")+str(yytFTW4gxlaV3sm2DGEb6)+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	rrnXRv2bFCatYNc6f0 = vkMRnTNV9jFm(u"ࠬࠦࠨࠨࠏ")+e5MprbQaG8wDA4uJk(G19uXt3rmcYvnjyJM7iPaI6zSQ)+zOZvXaebGNwHKfjRA(u"࠭ࠠ࠮ࠢࠪࠐ")+str(rKyiku9QZGDx)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	ys2dHnSYIkaeo10cJzZWGA4VpNbf = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠢࠫࠫࠒ")+e5MprbQaG8wDA4uJk(AUMZDfY6201RIpJk)+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(cIkaWEhHsD2YpmqLeVRFu)+uhOkAKtLVv4XTy1nWE6(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	IlOkTCHa8NoehuU9X6zbA = qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࠥ࠮ࠧࠕ")+e5MprbQaG8wDA4uJk(Xer206Iq9VOc)+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬ࠯ࠧࠖ")
	VlsnhMRiIb2 = f57eoTEzNCr19PgbXAKhY8MLQtq6+G19uXt3rmcYvnjyJM7iPaI6zSQ+AUMZDfY6201RIpJk+Xer206Iq9VOc
	Q92XJ4em80ugCsOKaNbL1P = yytFTW4gxlaV3sm2DGEb6+rKyiku9QZGDx+cIkaWEhHsD2YpmqLeVRFu+xxIq3CEDYHT1QS5RzAJMX7oFrUK
	OO1XlVPzfQrMTmJv = v7reLlOXCgD5pZ14w2tUA(u"࠭ࠠࠩࠩࠗ")+e5MprbQaG8wDA4uJk(VlsnhMRiIb2)+ddK4MmwpX5oG(u"ࠧࠡ࠯ࠣࠫ࠘")+str(Q92XJ4em80ugCsOKaNbL1P)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),JE7QrkmhletLwA0OZXu+DKqQekNtF6WlJLhBP9M5ca(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+OO1XlVPzfQrMTmJv,uhOkAKtLVv4XTy1nWE6(u"ࠫࠬࠜ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠼࠺࠵ࣚ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(DDS79jdWzLtE(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),GGTRaYBDeNyI25zlF(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࠨࠟ"),V391t7nQWUBR5euCkJ(u"࠿࠹࠺࠻ࣛ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(v7reLlOXCgD5pZ14w2tUA(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),JE7QrkmhletLwA0OZXu+tKVplxqYIdngGF6TZkXeb2PiwfME(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+TNdKcREB9AwzlF6r0aHv,uhOkAKtLVv4XTy1nWE6(u"ࠪࠫࠢ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠷࠵࠳ࣜ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),JE7QrkmhletLwA0OZXu+DKqQekNtF6WlJLhBP9M5ca(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+rrnXRv2bFCatYNc6f0,GGTRaYBDeNyI25zlF(u"࠭ࠧࠥ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠸࠶࠵ࣝ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(HMO0QciekqVpLKmA(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),JE7QrkmhletLwA0OZXu+DDS79jdWzLtE(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+ys2dHnSYIkaeo10cJzZWGA4VpNbf,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࠪࠨ"),ZpH2IWt7veyFobTsAnhi41(u"࠹࠷࠷ࣞ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(uhOkAKtLVv4XTy1nWE6(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),JE7QrkmhletLwA0OZXu+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+IlOkTCHa8NoehuU9X6zbA,IJ6VkihabRm(u"ࠬ࠭ࠫ"),xxpPYJOnoAUrlBzyveui(u"࠺࠸࠹ࣟ"))
	fQ6kvwg1FrYAzXjbLT.setSetting(p1lrNRIXqLQJznH6O(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),Vv0lSjAOHLfMnam3wtdor(u"ࠧࠨ࠭"))
	return
def UcopwziCYrSnj():
	S3YasxP9A2m70zgWtei8BwhNG = ZpH2IWt7veyFobTsAnhi41(u"ࡖࡵࡹࡪई") if xxBJoKG54uwQ(u"ࠨ࠱ࠪ࠮") in XJ4uqLcYdaT8nE3f else iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡇࡣ࡯ࡷࡪइ")
	if not S3YasxP9A2m70zgWtei8BwhNG:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxBJoKG54uwQ(u"ࠩࠪ࠯"),V391t7nQWUBR5euCkJ(u"ࠪࠫ࠰"),KbL94nDHufSF0VcO2Nk3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),Vv0lSjAOHLfMnam3wtdor(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	PqREL0OwgzB = fQ6kvwg1FrYAzXjbLT.getSetting(DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not PqREL0OwgzB: vw5KyoYLCHINfVZPeF0jkcG69pxAJO()
	f57eoTEzNCr19PgbXAKhY8MLQtq6,yytFTW4gxlaV3sm2DGEb6 = HqC0JDhnG7cTFIBa2d4Wv(ASi3T9NhIqCJ8Fg2xf0uLt)
	G19uXt3rmcYvnjyJM7iPaI6zSQ,rKyiku9QZGDx = HqC0JDhnG7cTFIBa2d4Wv(SjBdhHTIK9)
	AUMZDfY6201RIpJk,cIkaWEhHsD2YpmqLeVRFu = HqC0JDhnG7cTFIBa2d4Wv(kdtJeHNhzu)
	Xer206Iq9VOc,xxIq3CEDYHT1QS5RzAJMX7oFrUK = HqC0JDhnG7cTFIBa2d4Wv(Nh6G7KPEvAORtYJ2ClI3xMQDgaSj)
	srPtZucQwK4Fj9GdLvIRgyq7Bm,nUdAKl7PZ6wRuIsCq5X1ioT0Qx = HqC0JDhnG7cTFIBa2d4Wv(IxhYCHV2OGB631RXqp8gUwJTn)
	qAfpQv6FZLWKNljc2d74C,j2iAr0bQeNE5fkcxhyJ69OG = HqC0JDhnG7cTFIBa2d4Wv(NEOQx48CyzG2mnlDBscaHWRkb)
	TNdKcREB9AwzlF6r0aHv = HMO0QciekqVpLKmA(u"ࠧࠡࠪࠪ࠴")+e5MprbQaG8wDA4uJk(f57eoTEzNCr19PgbXAKhY8MLQtq6)+zOZvXaebGNwHKfjRA(u"ࠨࠢ࠰ࠤࠬ࠵")+str(yytFTW4gxlaV3sm2DGEb6)+xxBJoKG54uwQ(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	rrnXRv2bFCatYNc6f0 = IJ6VkihabRm(u"ࠪࠤ࠭࠭࠷")+e5MprbQaG8wDA4uJk(G19uXt3rmcYvnjyJM7iPaI6zSQ)+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠥ࠳ࠠࠨ࠸")+str(rKyiku9QZGDx)+xxBJoKG54uwQ(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	ys2dHnSYIkaeo10cJzZWGA4VpNbf = ddK4MmwpX5oG(u"࠭ࠠࠩࠩ࠺")+e5MprbQaG8wDA4uJk(AUMZDfY6201RIpJk)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࠡ࠯ࠣࠫ࠻")+str(cIkaWEhHsD2YpmqLeVRFu)+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	IlOkTCHa8NoehuU9X6zbA = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࠣࠬࠬ࠽")+e5MprbQaG8wDA4uJk(Xer206Iq9VOc)+OARzhnB9o7uYvQGFaIcZ(u"ࠪࠤ࠲ࠦࠧ࠾")+str(xxIq3CEDYHT1QS5RzAJMX7oFrUK)+DDS79jdWzLtE(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	BV5vsQpuzxmHCc6 = HMO0QciekqVpLKmA(u"ࠬࠦࠨࠨࡀ")+e5MprbQaG8wDA4uJk(srPtZucQwK4Fj9GdLvIRgyq7Bm)+v7reLlOXCgD5pZ14w2tUA(u"࠭ࠠ࠮ࠢࠪࡁ")+str(nUdAKl7PZ6wRuIsCq5X1ioT0Qx)+HMO0QciekqVpLKmA(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	QDqRMnfpBbXPKrWl = DKqQekNtF6WlJLhBP9M5ca(u"ࠨࠢࠫࠫࡃ")+e5MprbQaG8wDA4uJk(qAfpQv6FZLWKNljc2d74C)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(j2iAr0bQeNE5fkcxhyJ69OG)+zOZvXaebGNwHKfjRA(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	VlsnhMRiIb2 = f57eoTEzNCr19PgbXAKhY8MLQtq6+G19uXt3rmcYvnjyJM7iPaI6zSQ+AUMZDfY6201RIpJk+Xer206Iq9VOc+srPtZucQwK4Fj9GdLvIRgyq7Bm+qAfpQv6FZLWKNljc2d74C
	Q92XJ4em80ugCsOKaNbL1P = yytFTW4gxlaV3sm2DGEb6+rKyiku9QZGDx+cIkaWEhHsD2YpmqLeVRFu+xxIq3CEDYHT1QS5RzAJMX7oFrUK+nUdAKl7PZ6wRuIsCq5X1ioT0Qx+j2iAr0bQeNE5fkcxhyJ69OG
	OO1XlVPzfQrMTmJv = DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠥ࠮ࠧࡆ")+e5MprbQaG8wDA4uJk(VlsnhMRiIb2)+KbL94nDHufSF0VcO2Nk3(u"ࠬࠦ࠭ࠡࠩࡇ")+str(Q92XJ4em80ugCsOKaNbL1P)+IJ6VkihabRm(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),JE7QrkmhletLwA0OZXu+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),xxBJoKG54uwQ(u"ࠩࠪࡋ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠻࠺࠾࣠"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(Vv0lSjAOHLfMnam3wtdor(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),JE7QrkmhletLwA0OZXu+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+OO1XlVPzfQrMTmJv,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠭ࡎ"),uhOkAKtLVv4XTy1nWE6(u"࠼࠻࠷࣡"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(ddK4MmwpX5oG(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࠩࡑ"),p1lrNRIXqLQJznH6O(u"࠿࠹࠺࠻࣢"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(xxBJoKG54uwQ(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),JE7QrkmhletLwA0OZXu+ddK4MmwpX5oG(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+TNdKcREB9AwzlF6r0aHv,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࠬࡔ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"࠷࠶࠳ࣣ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(uhOkAKtLVv4XTy1nWE6(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),JE7QrkmhletLwA0OZXu+p1lrNRIXqLQJznH6O(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+rrnXRv2bFCatYNc6f0,IJ6VkihabRm(u"ࠧࠨࡗ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠸࠷࠵ࣤ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(dxAs4otSE98YmZnKy2iwRCB(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),JE7QrkmhletLwA0OZXu+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+ys2dHnSYIkaeo10cJzZWGA4VpNbf,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࡚ࠪࠫ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠹࠸࠷ࣥ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),JE7QrkmhletLwA0OZXu+V391t7nQWUBR5euCkJ(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+IlOkTCHa8NoehuU9X6zbA,Vv0lSjAOHLfMnam3wtdor(u"࠭ࠧ࡝"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠺࠹࠹ࣦ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(DDS79jdWzLtE(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),JE7QrkmhletLwA0OZXu+p1lrNRIXqLQJznH6O(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+BV5vsQpuzxmHCc6,IJ6VkihabRm(u"ࠩࠪࡠ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠻࠺࠻ࣧ"))
	fpjEiKI9bTc1xhoeq37vPusDJ6SB(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),JE7QrkmhletLwA0OZXu+p1lrNRIXqLQJznH6O(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+QDqRMnfpBbXPKrWl,GGTRaYBDeNyI25zlF(u"ࠬ࠭ࡣ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠼࠻࠶ࣨ"))
	fQ6kvwg1FrYAzXjbLT.setSetting(xxBJoKG54uwQ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠨࡥ"))
	return
def vw5KyoYLCHINfVZPeF0jkcG69pxAJO():
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࠩࡦ"),v7reLlOXCgD5pZ14w2tUA(u"ࠩࠪࡧ"),xxpPYJOnoAUrlBzyveui(u"ࠪࠫࡨ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),L91nVzxH4hYrgPDsOuljXd0J(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if T4TGmZ9XWAzONaKygic==-q0JfWbP8vACLxSNIncpOXkR6j(u"࠷ࣩ"): return
	if T4TGmZ9XWAzONaKygic:
		import subprocess as aM7hB1fcXrySIvplGQxni
		try:
			aM7hB1fcXrySIvplGQxni.Popen(dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡳࡶࠩ࡫"))
			OCgS257qzHG39bV0TE1McuFI = ZpH2IWt7veyFobTsAnhi41(u"ࡗࡶࡺ࡫उ")
		except: OCgS257qzHG39bV0TE1McuFI = OARzhnB9o7uYvQGFaIcZ(u"ࡊࡦࡲࡳࡦऊ")
		if OCgS257qzHG39bV0TE1McuFI:
			bbuADGQqzECVdXtPyfx7NIZl8ML = ASi3T9NhIqCJ8Fg2xf0uLt+GGTRaYBDeNyI25zlF(u"ࠧࠡࠩ࡬")+SjBdhHTIK9+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࠢࠪ࡭")+kdtJeHNhzu+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࠣࠫ࡮")+Nh6G7KPEvAORtYJ2ClI3xMQDgaSj+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࠤࠬ࡯")+IxhYCHV2OGB631RXqp8gUwJTn+Vv0lSjAOHLfMnam3wtdor(u"ࠫࠥ࠭ࡰ")+NEOQx48CyzG2mnlDBscaHWRkb
			YYSWUcE2DM9hRaGd = aM7hB1fcXrySIvplGQxni.Popen(HMO0QciekqVpLKmA(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+bbuADGQqzECVdXtPyfx7NIZl8ML+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࠢࠨࡲ"),shell=lunVJF2G5bZMgTcCje0vaIB371SX(u"࡙ࡸࡵࡦऋ"),stdin=aM7hB1fcXrySIvplGQxni.PIPE,stdout=aM7hB1fcXrySIvplGQxni.PIPE,stderr=aM7hB1fcXrySIvplGQxni.PIPE)
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxpPYJOnoAUrlBzyveui(u"ࠧࠨࡳ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠨࠩࡴ"),DDS79jdWzLtE(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),v7reLlOXCgD5pZ14w2tUA(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			fQ6kvwg1FrYAzXjbLT.setSetting(OARzhnB9o7uYvQGFaIcZ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(HMO0QciekqVpLKmA(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠨࡺ"),p1lrNRIXqLQJznH6O(u"ࠨࠩࡻ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),uhOkAKtLVv4XTy1nWE6(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def e5MprbQaG8wDA4uJk(VlsnhMRiIb2):
	for GToyYINutA0BV in [zOZvXaebGNwHKfjRA(u"ࠫࡇ࠭ࡾ"),IJ6VkihabRm(u"ࠬࡑࡂࠨࡿ"),dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡍࡃࠩࢀ"),ddK4MmwpX5oG(u"ࠧࡈࡄࠪࢁ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡖࡅࠫࢂ")]:
		if VlsnhMRiIb2<ZpH2IWt7veyFobTsAnhi41(u"࠱࠱࠴࠷࣪"): break
		else: VlsnhMRiIb2 /= ddK4MmwpX5oG(u"࠲࠲࠵࠸࠳࠶࣫")
	OO1XlVPzfQrMTmJv = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(VlsnhMRiIb2,GToyYINutA0BV)
	return OO1XlVPzfQrMTmJv
def HqC0JDhnG7cTFIBa2d4Wv(s1DTrajm82eF9Xf6SYtywlnGP=xxBJoKG54uwQ(u"ࠪ࠲ࠬࢄ")):
	global Mudq2A3Boi06lm,ktsDwofmreaK
	Mudq2A3Boi06lm,ktsDwofmreaK = ddK4MmwpX5oG(u"࠲࣬"),ddK4MmwpX5oG(u"࠲࣬")
	def dafwOLqn8NeW(s1DTrajm82eF9Xf6SYtywlnGP):
		global Mudq2A3Boi06lm,ktsDwofmreaK
		if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(s1DTrajm82eF9Xf6SYtywlnGP):
			if a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠳࣭") and DDS79jdWzLtE(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(YcJmC0W43u5idIELnHTU2XSsMPNt):
				for ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb in YcJmC0W43u5idIELnHTU2XSsMPNt.scandir(s1DTrajm82eF9Xf6SYtywlnGP):
					if ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb.is_dir(follow_symlinks=fcIm8tvxlXZsaEY3bwuG4B(u"ࡌࡡ࡭ࡵࡨऌ")):
						dafwOLqn8NeW(ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb.path)
					elif ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb.is_file(follow_symlinks=L91nVzxH4hYrgPDsOuljXd0J(u"ࡆࡢ࡮ࡶࡩऍ")):
						Mudq2A3Boi06lm += ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb.stat().st_size
						ktsDwofmreaK += OARzhnB9o7uYvQGFaIcZ(u"࠵࣮")
			else:
				for ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb in YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(s1DTrajm82eF9Xf6SYtywlnGP):
					Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps = YcJmC0W43u5idIELnHTU2XSsMPNt.path.abspath(YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(s1DTrajm82eF9Xf6SYtywlnGP,ma5wSQ2k91IO0Pnv7AgTxBHRLuZYb))
					if YcJmC0W43u5idIELnHTU2XSsMPNt.path.isdir(Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps):
						dafwOLqn8NeW(Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps)
					elif YcJmC0W43u5idIELnHTU2XSsMPNt.path.isfile(Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps):
						VlsnhMRiIb2,Q92XJ4em80ugCsOKaNbL1P = jGA1fuPNEcDJC7TFb9xhO30R(Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps)
						Mudq2A3Boi06lm += VlsnhMRiIb2
						ktsDwofmreaK += Q92XJ4em80ugCsOKaNbL1P
		return
	try: dafwOLqn8NeW(s1DTrajm82eF9Xf6SYtywlnGP)
	except: pass
	return Mudq2A3Boi06lm,ktsDwofmreaK
def w1iZgxuXfYOjmel5L6srWya4cnv(ZNSn59psAufcMYQ7lX3CJx16Pdzea,showDialogs):
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(vkMRnTNV9jFm(u"ࠬ࠭ࢆ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࠧࢇ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠨ࢈"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),ZNSn59psAufcMYQ7lX3CJx16Pdzea+dxAs4otSE98YmZnKy2iwRCB(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+qNZKwi2M1S4fBzGQYrmPnea(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if T4TGmZ9XWAzONaKygic!=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠶࣯"): return
	yjZgHkQETBJ6 = L91nVzxH4hYrgPDsOuljXd0J(u"ࡇࡣ࡯ࡷࡪऎ")
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(ZNSn59psAufcMYQ7lX3CJx16Pdzea):
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(ZNSn59psAufcMYQ7lX3CJx16Pdzea)
		except Exception as fPEkA5C7YyZ4T:
			if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(KbL94nDHufSF0VcO2Nk3(u"ࠫࠬࢌ"),zOZvXaebGNwHKfjRA(u"ࠬ࠭ࢍ"),zOZvXaebGNwHKfjRA(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(fPEkA5C7YyZ4T))
			yjZgHkQETBJ6 = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࡖࡵࡹࡪए")
	if showDialogs and not yjZgHkQETBJ6:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧࠨ࢏"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠩ࢐"),dxAs4otSE98YmZnKy2iwRCB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),ddK4MmwpX5oG(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		fQ6kvwg1FrYAzXjbLT.setSetting(HMO0QciekqVpLKmA(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),ZpH2IWt7veyFobTsAnhi41(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def JwDXYizBLv48(showDialogs):
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(v7reLlOXCgD5pZ14w2tUA(u"ࠧࠨ࢖"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࠩࢗ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࠪ࢘"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),ZpH2IWt7veyFobTsAnhi41(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡢ࡮ࠨ࢛")+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+dxAs4otSE98YmZnKy2iwRCB(u"ࠧ࡝ࡰࠪ࢝")+HMO0QciekqVpLKmA(u"ࠨมࠤࠥࠬ࢞")+KbL94nDHufSF0VcO2Nk3(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if T4TGmZ9XWAzONaKygic!=fcIm8tvxlXZsaEY3bwuG4B(u"࠷ࣰ"): return
	Qzbnt3opXim(fFprTtCJKyvzL5oN4uk,L91nVzxH4hYrgPDsOuljXd0J(u"ࡘࡷࡻࡥऑ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡉࡥࡱࡹࡥऐ"))
	Qzbnt3opXim(O9OEHA52g1JN8r3,vkMRnTNV9jFm(u"࡚ࡲࡶࡧओ"),ddK4MmwpX5oG(u"ࡋࡧ࡬ࡴࡧऒ"))
	Qzbnt3opXim(A7RfyBMGzi5tEnKxUN8I6L,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࡆࡢ࡮ࡶࡩऔ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࡆࡢ࡮ࡶࡩऔ"))
	CMakTmSPjrXiABu9zUJloHqbE3(jjJVH1ZFzOIecS9mxfBibl2UEaqhsN,DDS79jdWzLtE(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࠫࢠ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࠬࢡ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),HMO0QciekqVpLKmA(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),vkMRnTNV9jFm(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def KHbjG0hCl7yF3cUig6YIBrAVPEmL(showDialogs):
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(xxBJoKG54uwQ(u"ࠪࠫࢧ"),uhOkAKtLVv4XTy1nWE6(u"ࠫࠬࢨ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬ࠭ࢩ"),p1lrNRIXqLQJznH6O(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+vkMRnTNV9jFm(u"ࠨ࡞ࡱࠫࢬ")+dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+HMO0QciekqVpLKmA(u"ࠪࡠࡳ࠭ࢮ")+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡄࠧࠡࠨࢯ")+ddK4MmwpX5oG(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if T4TGmZ9XWAzONaKygic!=L91nVzxH4hYrgPDsOuljXd0J(u"࠱ࣱ"): return
	Qzbnt3opXim(ASi3T9NhIqCJ8Fg2xf0uLt,xxBJoKG54uwQ(u"ࡈࡤࡰࡸ࡫ख"),xxBJoKG54uwQ(u"ࡈࡤࡰࡸ࡫ख"))
	Qzbnt3opXim(SjBdhHTIK9,DDS79jdWzLtE(u"ࡉࡥࡱࡹࡥग"),DDS79jdWzLtE(u"ࡉࡥࡱࡹࡥग"))
	Qzbnt3opXim(kdtJeHNhzu,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡊࡦࡲࡳࡦघ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡊࡦࡲࡳࡦघ"))
	Qzbnt3opXim(Nh6G7KPEvAORtYJ2ClI3xMQDgaSj,vkMRnTNV9jFm(u"ࡋࡧ࡬ࡴࡧङ"),vkMRnTNV9jFm(u"ࡋࡧ࡬ࡴࡧङ"))
	Qzbnt3opXim(IxhYCHV2OGB631RXqp8gUwJTn,xxpPYJOnoAUrlBzyveui(u"ࡌࡡ࡭ࡵࡨच"),xxpPYJOnoAUrlBzyveui(u"ࡌࡡ࡭ࡵࡨच"))
	Qzbnt3opXim(NEOQx48CyzG2mnlDBscaHWRkb,Vv0lSjAOHLfMnam3wtdor(u"ࡆࡢ࡮ࡶࡩछ"),Vv0lSjAOHLfMnam3wtdor(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠧࢱ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠨࢲ"),ZpH2IWt7veyFobTsAnhi41(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(Vv0lSjAOHLfMnam3wtdor(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def CMakTmSPjrXiABu9zUJloHqbE3(RJpWL3qSwhg,showDialogs):
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(uhOkAKtLVv4XTy1nWE6(u"࠭ࠧࢸ"),HMO0QciekqVpLKmA(u"ࠧࠨࢹ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࠩࢺ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if T4TGmZ9XWAzONaKygic!=HMO0QciekqVpLKmA(u"࠲ࣲ"): return
	qcOU43biDkaPQlZMB1wHEj = csXRAak0iZIKQpfu1o.connect(RJpWL3qSwhg)
	qcOU43biDkaPQlZMB1wHEj.text_factory = str
	K2DlNXvQC65FzngUVyk3IGAq = qcOU43biDkaPQlZMB1wHEj.cursor()
	K2DlNXvQC65FzngUVyk3IGAq.execute(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	K2DlNXvQC65FzngUVyk3IGAq.execute(IJ6VkihabRm(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	qcOU43biDkaPQlZMB1wHEj.commit()
	K2DlNXvQC65FzngUVyk3IGAq.execute(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	qcOU43biDkaPQlZMB1wHEj.close()
	if showDialogs:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(xxpPYJOnoAUrlBzyveui(u"ࠩࠪࣂ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠪࠫࣃ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),Vv0lSjAOHLfMnam3wtdor(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(ZpH2IWt7veyFobTsAnhi41(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
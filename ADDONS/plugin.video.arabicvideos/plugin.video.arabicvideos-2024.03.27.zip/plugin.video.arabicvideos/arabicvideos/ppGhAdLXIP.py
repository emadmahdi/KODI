# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'FASELHD1'
headers = {'User-Agent':''}
JE7QrkmhletLwA0OZXu = '_FH1_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['جوائز الأوسكار','المراجعات','wwe']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==570: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==571: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==572: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==573: RRMWBwU6pG = o9LaYpVR1wKx3IGuHS(url,text)
	elif mode==576: RRMWBwU6pG = cIwQDWqvJU()
	elif mode==579: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+'لماذا الموقع بطيء','',576)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ka6I93CnvublQMtjr,url,nbdMp8UuhzP3oq4cDWj6eyZVt = PEkFUyjA3qRNpzgYX(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'faselhd1','فاصل إعلاني','dubbed-movies')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع',ka6I93CnvublQMtjr,579,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',ka6I93CnvublQMtjr,571,'','','featured1')
	items = QPuHKNAT4jmCRg.findall('class="h3">(.*?)<.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not items:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,VV7yf2htDCBU6EeSX8TJQM in items:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,571,'','','details1')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"menu-primary"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		oCfSOBpu97IY5zadW6gGEMVmwU = QPuHKNAT4jmCRg.findall('<li (.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		VHEYQ1vrPn85JU = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		kdWCpE9TjNh = 0
		for zik0WubZQEGj9Ym35NqwF in oCfSOBpu97IY5zadW6gGEMVmwU:
			if kdWCpE9TjNh>0: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',zik0WubZQEGj9Ym35NqwF,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if VV7yf2htDCBU6EeSX8TJQM=='#': continue
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+VV7yf2htDCBU6EeSX8TJQM
				if title=='': continue
				if any(pp8iHB3W9Cs in title.lower() for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
				title = VHEYQ1vrPn85JU[kdWCpE9TjNh]+title
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,571,'','','details2')
			kdWCpE9TjNh += 1
	return
def cIwQDWqvJU():
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def SPFl6UGK4mrBua(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FASELHD1-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('class="h4">(.*?)</div>(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not kk73xHNzri1P2wgULMv4sDtoTnybO: return
	if type=='filters':
		TTCRYZroizb = [Ht6Gg8lbciAd9FaUQVs.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"homeSlide"(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		e7pdI0Ez38ROVy,Y4xiULzGTKjb8mulO,lGKfCUP9XRTaBwQ6pq7n0 = zip(*items)
		items = zip(Y4xiULzGTKjb8mulO,e7pdI0Ez38ROVy,lGKfCUP9XRTaBwQ6pq7n0)
	elif type=='featured2':
		title,wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='details2' and len(kk73xHNzri1P2wgULMv4sDtoTnybO)>1:
		title = kk73xHNzri1P2wgULMv4sDtoTnybO[0][0]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,571,'','','featured2')
		title = kk73xHNzri1P2wgULMv4sDtoTnybO[1][0]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,571,'','','details3')
		return
	else:
		title,wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[-1]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if any(pp8iHB3W9Cs in title.lower() for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
		G2WR0Oacvdq8ZQTjKboDU = kWfpQA7tTjSPyLbNIeMr1Hui5(G2WR0Oacvdq8ZQTjKboDU)
		G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.split('?resize=')[0]
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) (الحلقة|حلقة).\d+',title,QPuHKNAT4jmCRg.DOTALL)
		if '/collections/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,571,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and type=='':
			title = '_MOD_'+CiZxgXTGW9pv[0][0]
			title = title.strip(' –')
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,573,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif 'episodes/' in VV7yf2htDCBU6EeSX8TJQM or 'movies/' in VV7yf2htDCBU6EeSX8TJQM or 'hindi/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,572,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,573,G2WR0Oacvdq8ZQTjKboDU)
	if type=='filters':
		VpolhzO6Kj = QPuHKNAT4jmCRg.findall('"more_button_page":(.*?),',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if VpolhzO6Kj:
			count = VpolhzO6Kj[0]
			VV7yf2htDCBU6EeSX8TJQM = url+'/offset/'+count
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة أخرى',VV7yf2htDCBU6EeSX8TJQM,571,'','','filters')
	elif 'details' in type:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall("class='pagination(.*?)</div>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall("href='(.*?)'.*?>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = 'صفحة '+UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,571,'','','details4')
	return
def o9LaYpVR1wKx3IGuHS(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Q1WJvEwGdh2mPfct9SKa = False
	if not type:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"seasonList"(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if len(items)>1:
				ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
				Q1WJvEwGdh2mPfct9SKa = True
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,name,title in items:
					name = UH1IuvwM9e4cl7if63nNdozJFSj(name)
					if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+VV7yf2htDCBU6EeSX8TJQM
					title = name+' - '+title
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,573,G2WR0Oacvdq8ZQTjKboDU,'','episodes')
	if type=='episodes' or not Q1WJvEwGdh2mPfct9SKa:
		KKcFOCmYRENepQnxi = QPuHKNAT4jmCRg.findall('"posterImg".*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if KKcFOCmYRENepQnxi: G2WR0Oacvdq8ZQTjKboDU = KKcFOCmYRENepQnxi[0]
		else: G2WR0Oacvdq8ZQTjKboDU = ''
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"epAll"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = title.strip(' ')
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,572,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	YsDryBSXquzdEUta8kxjfO,TrAEpY6wszL,G3EtpuZ7ivHB9TxCYalcwDzSeoLM = [],[],[]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','FASELHD1-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	E6eiGCWHx5sN3LpDZbwc = QPuHKNAT4jmCRg.findall('مستوى المشاهدة.*?">(.*?)</span>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if E6eiGCWHx5sN3LpDZbwc:
		KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('"tag">(.*?)</a>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"videoRow"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&img=')[0]
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named=__embed')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="streamHeader(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall("href = '(.*?)'.*?</i>(.*?)</a>",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&img=')[0]
			name = name.strip(' ')
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__watch')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="downloadLinks(.*?)blackwindow',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</span>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&img=')[0]
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__download')
	for fuCINda6HpvU1ljAJ3Sm5twyPZ8 in YsDryBSXquzdEUta8kxjfO:
		VV7yf2htDCBU6EeSX8TJQM,name = fuCINda6HpvU1ljAJ3Sm5twyPZ8.split('?named')
		if VV7yf2htDCBU6EeSX8TJQM not in TrAEpY6wszL:
			TrAEpY6wszL.append(VV7yf2htDCBU6EeSX8TJQM)
			G3EtpuZ7ivHB9TxCYalcwDzSeoLM.append(fuCINda6HpvU1ljAJ3Sm5twyPZ8)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(G3EtpuZ7ivHB9TxCYalcwDzSeoLM,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/?s='+search
	ka6I93CnvublQMtjr,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ykIAHx9E1umUdZqjSiBw6Kbar = PEkFUyjA3qRNpzgYX(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'details5')
	return
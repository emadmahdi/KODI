# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
amlcehCxU3O2yoGf = 'IPTV'
lCfDqYvaRW = '_IPT_'
ilwajn2UGYP = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def M8xBdHmhrtyWIoL1e6VNvk(Q6FbqZ9uIe8v2xaTHhfDCJ,HbqSfZ6m7FAa,OO1XlVPzfQrMTmJv,ghLJETx5pD7,zt1qZvA74HunVPWCON,T1zaK6eDkFcyCBldWR3YMuJgIQo):
	global lCfDqYvaRW
	try:
		vknQOmFaRT7sxDcr1zZyNGtBuA = str(T1zaK6eDkFcyCBldWR3YMuJgIQo['folder'])
		lCfDqYvaRW = '_IP'+vknQOmFaRT7sxDcr1zZyNGtBuA+'_'
	except: vknQOmFaRT7sxDcr1zZyNGtBuA = ''
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==230: X8M3EvbVAIGCNpgU7 = vvPs8IKa1E0cRod9lej()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==231: X8M3EvbVAIGCNpgU7 = LLFAGKJgjb1Iva50hPRdZ4(vknQOmFaRT7sxDcr1zZyNGtBuA)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==232: X8M3EvbVAIGCNpgU7 = nuXml1GPNCS8Z0HIcj(vknQOmFaRT7sxDcr1zZyNGtBuA)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==233: X8M3EvbVAIGCNpgU7 = fAG7rpMnDyqzE(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,OO1XlVPzfQrMTmJv,zt1qZvA74HunVPWCON)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==234: X8M3EvbVAIGCNpgU7 = F42EXtwuzB7Hl(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,OO1XlVPzfQrMTmJv,zt1qZvA74HunVPWCON)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==235: X8M3EvbVAIGCNpgU7 = unQmcpAEF2DaNX87fTgMW(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,ghLJETx5pD7)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==236: X8M3EvbVAIGCNpgU7 = DPE0OIv9k2LYp(vknQOmFaRT7sxDcr1zZyNGtBuA,True)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==237: X8M3EvbVAIGCNpgU7 = bIXayWVe45Q3(vknQOmFaRT7sxDcr1zZyNGtBuA,True)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==238: X8M3EvbVAIGCNpgU7 = apdH4oel9EsqOPLjGRg5ytY(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==239: X8M3EvbVAIGCNpgU7 = oThr70M9BuSwHkalZ6sV5tUyFNiW(OO1XlVPzfQrMTmJv,vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,zt1qZvA74HunVPWCON)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==280: X8M3EvbVAIGCNpgU7 = QKeHO0hSmMnC6GyRYxqzNVfXUbjd(vknQOmFaRT7sxDcr1zZyNGtBuA,True)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==281: X8M3EvbVAIGCNpgU7 = TyAoZj5puBINz1rwWGf(vknQOmFaRT7sxDcr1zZyNGtBuA)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==282: X8M3EvbVAIGCNpgU7 = ZZOEBlGHXnu8iD(vknQOmFaRT7sxDcr1zZyNGtBuA)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==283: X8M3EvbVAIGCNpgU7 = ooFcRxqYLvC45rWd18UI7(vknQOmFaRT7sxDcr1zZyNGtBuA)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==285: X8M3EvbVAIGCNpgU7 = nomqb0d1hBM(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==286: X8M3EvbVAIGCNpgU7 = uQtfjLAJKhwENi6sX27W8bzHOMre4(vknQOmFaRT7sxDcr1zZyNGtBuA)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==289: X8M3EvbVAIGCNpgU7 = Vtu3IopGiTP7mwfSRQOB(OO1XlVPzfQrMTmJv,vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,zt1qZvA74HunVPWCON)
	else: X8M3EvbVAIGCNpgU7 = False
	return X8M3EvbVAIGCNpgU7
def vvPs8IKa1E0cRod9lej():
	for vknQOmFaRT7sxDcr1zZyNGtBuA in range(1,nJHx2XSIEFA7+1):
		lCfDqYvaRW = '_IP'+str(vknQOmFaRT7sxDcr1zZyNGtBuA)+'_'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قائمة مجلد '+aLDUVmBxsFnM[vknQOmFaRT7sxDcr1zZyNGtBuA],'',280,'','','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	return
def QKeHO0hSmMnC6GyRYxqzNVfXUbjd(vknQOmFaRT7sxDcr1zZyNGtBuA='',kpRFrdX4B2iaJxwqcL0IUVt=''):
	if vknQOmFaRT7sxDcr1zZyNGtBuA:
		P7kDLtguW5KiQqfTvhFHwd02aVje = {'folder':vknQOmFaRT7sxDcr1zZyNGtBuA}
		SJLiAGmdTetOZqEQFD = ''
	else:
		P7kDLtguW5KiQqfTvhFHwd02aVje = ''
		SJLiAGmdTetOZqEQFD = ''
	n1DSjoCKW27O9 = SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt)
	if not n1DSjoCKW27O9:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'[COLOR FFFFFF00] إضافة أو تغيير اشتراك'+SJLiAGmdTetOZqEQFD+' [/COLOR]','',231,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'[COLOR FFFFFF00] جلب ملفات'+SJLiAGmdTetOZqEQFD+' [/COLOR]','',232,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'بحث في الملفات'+SJLiAGmdTetOZqEQFD,'',289,'','','_REMEMBERRESULTS_','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات مصنفة مرتبة'+SJLiAGmdTetOZqEQFD,'LIVE_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات مصنفة من القسم'+SJLiAGmdTetOZqEQFD,'LIVE_FROM_GROUP_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات مصنفة من الاسم'+SJLiAGmdTetOZqEQFD,'LIVE_FROM_NAME_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات مصنفة بلا ترتيب'+SJLiAGmdTetOZqEQFD,'LIVE_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات بلا ترتيب'+SJLiAGmdTetOZqEQFD,'LIVE_ORIGINAL_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات مجهولة مرتبة'+SJLiAGmdTetOZqEQFD,'LIVE_UNKNOWN_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'قنوات مجهولة بلا ترتيب'+SJLiAGmdTetOZqEQFD,'LIVE_UNKNOWN_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'أفلام مصنفة بلا ترتيب'+SJLiAGmdTetOZqEQFD,'VOD_MOVIES_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'أفلام مصنفة مرتبة'+SJLiAGmdTetOZqEQFD,'VOD_MOVIES_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'مسلسلات مصنفة بلا ترتيب'+SJLiAGmdTetOZqEQFD,'VOD_SERIES_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'مسلسلات مصنفة مرتبة'+SJLiAGmdTetOZqEQFD,'VOD_SERIES_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'فيديوهات بلا ترتيب'+SJLiAGmdTetOZqEQFD,'VOD_ORIGINAL_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'فيديوهات مصنفة من القسم'+SJLiAGmdTetOZqEQFD,'VOD_FROM_GROUP_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'فيديوهات مصنفة من الاسم'+SJLiAGmdTetOZqEQFD,'VOD_FROM_NAME_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'فيديوهات مجهولة بلا ترتيب'+SJLiAGmdTetOZqEQFD,'VOD_UNKNOWN_GROUPED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'فيديوهات مجهولة مرتبة'+SJLiAGmdTetOZqEQFD,'VOD_UNKNOWN_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'برامج القنوات (جدول فقط)'+SJLiAGmdTetOZqEQFD,'LIVE_EPG_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'أرشيف القنوات للأيام الماضية'+SJLiAGmdTetOZqEQFD,'LIVE_TIMESHIFT_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'أرشيف برامج القنوات للأيام الماضية'+SJLiAGmdTetOZqEQFD,'LIVE_ARCHIVED_GROUPED_SORTED',233,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'إضافة أو تغيير اشتراك'+SJLiAGmdTetOZqEQFD,'',231,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'جلب ملفات'+SJLiAGmdTetOZqEQFD,'',232,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'مسح ملفات'+SJLiAGmdTetOZqEQFD,'',237,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'فحص اشتراك'+SJLiAGmdTetOZqEQFD,'',236,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'عدد فيديوهات'+SJLiAGmdTetOZqEQFD,'',281,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'Referer تغيير'+SJLiAGmdTetOZqEQFD,'',286,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'User-Agent تغيير'+SJLiAGmdTetOZqEQFD,'',283,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'استخدم السيرفر الأسرع'+SJLiAGmdTetOZqEQFD,'',282,'','','','',P7kDLtguW5KiQqfTvhFHwd02aVje)
	return
def DPE0OIv9k2LYp(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt=True):
	HYGDvyINiwbVKlEJ7TjFO8dP,q0ed8iTnSEuJzfyF3NYlB9bPGj7 = False,''
	J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu = '',''
	RRVsEiIu9efhz,wwPhbdD6GL52AygQWFIHmp,j4bsZF9S25q1VGECt,UU8oBeXhQstYkGfx2cTyOHZS6bmR,CzjoN98nk0 = PALIf97ew3T0JispFkK(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if UU8oBeXhQstYkGfx2cTyOHZS6bmR=='': return False,'',''
	JWZYMU9luoKCAD7ybSBQ = WXx8yidSJvbDE(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if RRVsEiIu9efhz:
		vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',RRVsEiIu9efhz,'',JWZYMU9luoKCAD7ybSBQ,False,'','IPTV-CHECK_ACCOUNT-1st')
		F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
		if vqUSBHDtn5Rl6Vyc8.succeeded:
			yyjeY7uUCJ8aXmqD2Qb3oMOAB,MxsFrEHYmje3LtQJS02NwZfy5vR,j5joJD3OAVvSIybL,wIepOPQMabm29kfxAiH3yR,Fx2CEzBDvGZo9si0ql5dpRkP8 = 0,0,'','',''
			try:
				nEPScIkxvGwTBoQsmVAD6uCXOgdtr = kMLWTt2fO9dnGDUgHh('dict',F3FUSpn5ZHPu6iwQ1sr8)
				q0ed8iTnSEuJzfyF3NYlB9bPGj7 = nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['status']
				HYGDvyINiwbVKlEJ7TjFO8dP = True
				j5joJD3OAVvSIybL = nEPScIkxvGwTBoQsmVAD6uCXOgdtr['server_info']['time_now']
			except: pass
			if j5joJD3OAVvSIybL:
				try:
					dvYsGe0Z7wlz = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strptime(j5joJD3OAVvSIybL,'%Y.%m.%d %H:%M:%S')
					yyjeY7uUCJ8aXmqD2Qb3oMOAB = int(vODi7LQeCnUaoRqZX9xs6djwm0tJA2.mktime(dvYsGe0Z7wlz))
					MxsFrEHYmje3LtQJS02NwZfy5vR = int(Low1uSVG5OcafJmrYBC7D-yyjeY7uUCJ8aXmqD2Qb3oMOAB)
					MxsFrEHYmje3LtQJS02NwZfy5vR = int((MxsFrEHYmje3LtQJS02NwZfy5vR+900)/1800)*1800
				except: pass
				try:
					dvYsGe0Z7wlz = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.localtime(int(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['created_at']))
					wIepOPQMabm29kfxAiH3yR = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime('%Y.%m.%d %H:%M:%S',dvYsGe0Z7wlz)
				except: pass
				try:
					dvYsGe0Z7wlz = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.localtime(int(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['exp_date']))
					Fx2CEzBDvGZo9si0ql5dpRkP8 = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime('%Y.%m.%d %H:%M:%S',dvYsGe0Z7wlz)
				except: pass
			fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.timestamp_'+vknQOmFaRT7sxDcr1zZyNGtBuA,str(Low1uSVG5OcafJmrYBC7D))
			fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.timediff_'+vknQOmFaRT7sxDcr1zZyNGtBuA,str(MxsFrEHYmje3LtQJS02NwZfy5vR))
			try:
				HR8Af2N1XxyL = '"server_info":'+F3FUSpn5ZHPu6iwQ1sr8.split('"server_info":')[1]
				HR8Af2N1XxyL = HR8Af2N1XxyL.replace(':',': ').replace(',',', ').replace('}}','}')
				ZZ7uYQ8yKCPEhtXsVGUWxF2O0jmc = QPuHKNAT4jmCRg.findall('"url": "(.*?)", "port": "(.*?)"',HR8Af2N1XxyL,QPuHKNAT4jmCRg.DOTALL)
				J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu = ZZ7uYQ8yKCPEhtXsVGUWxF2O0jmc[0]
			except: HYGDvyINiwbVKlEJ7TjFO8dP = False
			if HYGDvyINiwbVKlEJ7TjFO8dP and kpRFrdX4B2iaJxwqcL0IUVt:
				max = nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['max_connections']
				Ib5BGeqvhuZVdTK2SPEjoA79 = nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['active_cons']
				LMbIlPuXUiEfnvQR3486 = nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['is_trial']
				onFdMC0Dakc8ijJrBu = RRVsEiIu9efhz.split('?',1)
				qNEnDMwm1Vfastx2ZkpRh = 'URL:  [COLOR FFC89008]'+RRVsEiIu9efhz+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\n\nStatus:  '+'[COLOR FFC89008]'+q0ed8iTnSEuJzfyF3NYlB9bPGj7+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\nTrial:    '+'[COLOR FFC89008]'+str(LMbIlPuXUiEfnvQR3486=='1')+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\nCreated  At:  '+'[COLOR FFC89008]'+wIepOPQMabm29kfxAiH3yR+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\nExpiry Date:  '+'[COLOR FFC89008]'+Fx2CEzBDvGZo9si0ql5dpRkP8+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+Ib5BGeqvhuZVdTK2SPEjoA79+' / '+max+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['user_info']['allowed_output_formats'])+'[/COLOR]'
				qNEnDMwm1Vfastx2ZkpRh += '\n\n'+HR8Af2N1XxyL
				if q0ed8iTnSEuJzfyF3NYlB9bPGj7=='Active': BwEG5gzkVsJcCRaQyhX4IqSHx0lnO('الاشتراك يعمل بدون مشاكل',qNEnDMwm1Vfastx2ZkpRh)
				else: BwEG5gzkVsJcCRaQyhX4IqSHx0lnO('يبدو أن هناك مشكلة في الاشتراك',qNEnDMwm1Vfastx2ZkpRh)
	if RRVsEiIu9efhz and HYGDvyINiwbVKlEJ7TjFO8dP and q0ed8iTnSEuJzfyF3NYlB9bPGj7=='Active':
		zRM3tZx2v6DjJU('NOTICE','.  Checking IPTV URL   [ IPTV account is OK ]   [ '+RRVsEiIu9efhz+' ]')
		tabjWm69HD = True
	else:
		zRM3tZx2v6DjJU('ERROR_LINES','Checking IPTV URL   [ Does not work ]   [ '+RRVsEiIu9efhz+' ]')
		if kpRFrdX4B2iaJxwqcL0IUVt: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		tabjWm69HD = False
	return tabjWm69HD,J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu
def F42EXtwuzB7Hl(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E,nkl2zvWBtHT5u03c1soePYIZdQqbK,NAeOBpCIyH4FrQqMaXv1ziG8kWU,kpRFrdX4B2iaJxwqcL0IUVt=True):
	if not NAeOBpCIyH4FrQqMaXv1ziG8kWU: NAeOBpCIyH4FrQqMaXv1ziG8kWU = '1'
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt): return
	KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E)
	aatNAwDZOBf1Co2MPdRm8v5sEzxKIh = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'list',L6wOQrDsfy94j8WIg3Kad7E,nkl2zvWBtHT5u03c1soePYIZdQqbK)
	UGNWtinsC6cI48YK9bSzfeLgTaE = int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)*100
	UAoKrdqaMm = UGNWtinsC6cI48YK9bSzfeLgTaE-100
	for C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R in aatNAwDZOBf1Co2MPdRm8v5sEzxKIh[UAoKrdqaMm:UGNWtinsC6cI48YK9bSzfeLgTaE]:
		l5hSqMoaeTCJyW3t9 = ('GROUPED' in L6wOQrDsfy94j8WIg3Kad7E or L6wOQrDsfy94j8WIg3Kad7E=='ALL')
		bbfPJh67IHZ = ('GROUPED' not in L6wOQrDsfy94j8WIg3Kad7E and L6wOQrDsfy94j8WIg3Kad7E!='ALL')
		if l5hSqMoaeTCJyW3t9 or bbfPJh67IHZ:
			if   'ARCHIVED'  in L6wOQrDsfy94j8WIg3Kad7E: vvruH9wsBDfbhFtyq1MUd2zV.append(['folder',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,238,HQ1EncuNLjBOl20R,'','ARCHIVED','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA}])
			elif 'EPG' 		 in L6wOQrDsfy94j8WIg3Kad7E: vvruH9wsBDfbhFtyq1MUd2zV.append(['folder',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,238,HQ1EncuNLjBOl20R,'','FULL_EPG','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA}])
			elif 'TIMESHIFT' in L6wOQrDsfy94j8WIg3Kad7E: vvruH9wsBDfbhFtyq1MUd2zV.append(['folder',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,238,HQ1EncuNLjBOl20R,'','TIMESHIFT','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA}])
			elif 'LIVE' 	 in L6wOQrDsfy94j8WIg3Kad7E: vvruH9wsBDfbhFtyq1MUd2zV.append(['live',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,235,HQ1EncuNLjBOl20R,'','',C32AEk8uZTeFPI94LG6dmczv,{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA}])
			else: vvruH9wsBDfbhFtyq1MUd2zV.append(['video',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,235,HQ1EncuNLjBOl20R,'','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA}])
	VMsYufnCR5HigB2x9P61TUp3bSZjc = len(aatNAwDZOBf1Co2MPdRm8v5sEzxKIh)
	y19z2fNAKaLtDvpguQI6sBPX7R(vknQOmFaRT7sxDcr1zZyNGtBuA,NAeOBpCIyH4FrQqMaXv1ziG8kWU,L6wOQrDsfy94j8WIg3Kad7E,234,VMsYufnCR5HigB2x9P61TUp3bSZjc,nkl2zvWBtHT5u03c1soePYIZdQqbK)
	return
def anjHtfsDxzvP1IACgJOT5kYiU(JJP6WIRuTSdUsXwBp):
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JJP6WIRuTSdUsXwBp+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JJP6WIRuTSdUsXwBp+'أو الخدمة غير موجودة في اشتراكك','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JJP6WIRuTSdUsXwBp+'أو رابط IPTVـ الذي أنت أضفته غير صحيح','',9999)
	return
def fAG7rpMnDyqzE(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E,nkl2zvWBtHT5u03c1soePYIZdQqbK,NAeOBpCIyH4FrQqMaXv1ziG8kWU,cPaontykhx='',kpRFrdX4B2iaJxwqcL0IUVt=True):
	if not NAeOBpCIyH4FrQqMaXv1ziG8kWU: NAeOBpCIyH4FrQqMaXv1ziG8kWU = '1'
	JJP6WIRuTSdUsXwBp = lCfDqYvaRW
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt): return False
	if '__SERIES__' in nkl2zvWBtHT5u03c1soePYIZdQqbK: EdriMjRko8,GhCIo3ZfJ89Web = nkl2zvWBtHT5u03c1soePYIZdQqbK.split('__SERIES__')
	else: EdriMjRko8,GhCIo3ZfJ89Web = nkl2zvWBtHT5u03c1soePYIZdQqbK,''
	KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E)
	CPNDshLxveorW9AFjEcgOzI2HX = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'list',L6wOQrDsfy94j8WIg3Kad7E,'__GROUPS__')
	if not CPNDshLxveorW9AFjEcgOzI2HX: return False
	SSwiNj7sxpPRh = []
	for HBmVXtdERwka,HQ1EncuNLjBOl20R in CPNDshLxveorW9AFjEcgOzI2HX:
		if cPaontykhx:
			if '__SERIES__' in HBmVXtdERwka: JJP6WIRuTSdUsXwBp = 'SERIES'
			elif '!!__UNKNOWN__!!' in HBmVXtdERwka: JJP6WIRuTSdUsXwBp = 'UNKNOWN'
			elif 'LIVE' in L6wOQrDsfy94j8WIg3Kad7E: JJP6WIRuTSdUsXwBp = 'LIVE'
			else: JJP6WIRuTSdUsXwBp = 'VIDEOS'
			JJP6WIRuTSdUsXwBp = ',[COLOR FFC89008]'+JJP6WIRuTSdUsXwBp+': [/COLOR]'
		if '__SERIES__' in HBmVXtdERwka: R0LaiTg5XePmnz34BSxO6wftVsKCJ,KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ = HBmVXtdERwka.split('__SERIES__')
		else: R0LaiTg5XePmnz34BSxO6wftVsKCJ,KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ = HBmVXtdERwka,''
		if not nkl2zvWBtHT5u03c1soePYIZdQqbK:
			if R0LaiTg5XePmnz34BSxO6wftVsKCJ in SSwiNj7sxpPRh: continue
			SSwiNj7sxpPRh.append(R0LaiTg5XePmnz34BSxO6wftVsKCJ)
			if 'RANDOM' in cPaontykhx: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JJP6WIRuTSdUsXwBp+R0LaiTg5XePmnz34BSxO6wftVsKCJ,L6wOQrDsfy94j8WIg3Kad7E,167,'','1',HBmVXtdERwka,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
			elif '__SERIES__' in HBmVXtdERwka: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JJP6WIRuTSdUsXwBp+R0LaiTg5XePmnz34BSxO6wftVsKCJ,L6wOQrDsfy94j8WIg3Kad7E,233,'','1',HBmVXtdERwka,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JJP6WIRuTSdUsXwBp+R0LaiTg5XePmnz34BSxO6wftVsKCJ,L6wOQrDsfy94j8WIg3Kad7E,234,'','1',HBmVXtdERwka,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
		elif '__SERIES__' in HBmVXtdERwka and R0LaiTg5XePmnz34BSxO6wftVsKCJ==EdriMjRko8:
			if KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ in SSwiNj7sxpPRh: continue
			SSwiNj7sxpPRh.append(KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ)
			if 'RANDOM' in cPaontykhx: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JJP6WIRuTSdUsXwBp+KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ,L6wOQrDsfy94j8WIg3Kad7E,167,'','1',HBmVXtdERwka,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JJP6WIRuTSdUsXwBp+KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ,L6wOQrDsfy94j8WIg3Kad7E,234,HQ1EncuNLjBOl20R,'1',HBmVXtdERwka,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	vvruH9wsBDfbhFtyq1MUd2zV[:] = sorted(vvruH9wsBDfbhFtyq1MUd2zV,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f[1].lower())
	if not cPaontykhx:
		UGNWtinsC6cI48YK9bSzfeLgTaE = int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)*100
		UAoKrdqaMm = UGNWtinsC6cI48YK9bSzfeLgTaE-100
		VMsYufnCR5HigB2x9P61TUp3bSZjc = len(Qk5YL3sflA)
		Qk5YL3sflA[:] = vvruH9wsBDfbhFtyq1MUd2zV[UAoKrdqaMm:UGNWtinsC6cI48YK9bSzfeLgTaE]
		y19z2fNAKaLtDvpguQI6sBPX7R(vknQOmFaRT7sxDcr1zZyNGtBuA,NAeOBpCIyH4FrQqMaXv1ziG8kWU,L6wOQrDsfy94j8WIg3Kad7E,233,VMsYufnCR5HigB2x9P61TUp3bSZjc,nkl2zvWBtHT5u03c1soePYIZdQqbK)
	return True
def apdH4oel9EsqOPLjGRg5ytY(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,YKg6awP1xfpHN8cdvS9):
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,True): return
	JWZYMU9luoKCAD7ybSBQ = WXx8yidSJvbDE(vknQOmFaRT7sxDcr1zZyNGtBuA)
	yyjeY7uUCJ8aXmqD2Qb3oMOAB = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.timestamp_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if not yyjeY7uUCJ8aXmqD2Qb3oMOAB or Low1uSVG5OcafJmrYBC7D-int(yyjeY7uUCJ8aXmqD2Qb3oMOAB)>24*PVQeMKFimjdzY1OTqab:
		tabjWm69HD,J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu = DPE0OIv9k2LYp(vknQOmFaRT7sxDcr1zZyNGtBuA,False)
		if not tabjWm69HD: return
	MxsFrEHYmje3LtQJS02NwZfy5vR = int(fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.timediff_'+vknQOmFaRT7sxDcr1zZyNGtBuA))
	j4bsZF9S25q1VGECt = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.server_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	UU8oBeXhQstYkGfx2cTyOHZS6bmR = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.username_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	CzjoN98nk0 = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.password_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	sV8zAk09ERMBdX2eJ36oO = HbqSfZ6m7FAa.split('/')
	WFKweYk98TnbvPtdl0D3 = sV8zAk09ERMBdX2eJ36oO[-1].replace('.ts','').replace('.m3u8','')
	if YKg6awP1xfpHN8cdvS9=='SHORT_EPG': HGme6fv4k3cuwa = 'get_short_epg'
	else: HGme6fv4k3cuwa = 'get_simple_data_table'
	RRVsEiIu9efhz,wwPhbdD6GL52AygQWFIHmp,j4bsZF9S25q1VGECt,UU8oBeXhQstYkGfx2cTyOHZS6bmR,CzjoN98nk0 = PALIf97ew3T0JispFkK(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if not UU8oBeXhQstYkGfx2cTyOHZS6bmR: return
	bvhz38RfACGH = RRVsEiIu9efhz+'&action='+HGme6fv4k3cuwa+'&stream_id='+WFKweYk98TnbvPtdl0D3
	F3FUSpn5ZHPu6iwQ1sr8 = woQGb3ThYm9NI8a4vfV(vfj1VHSBpIks9JhLGmr,bvhz38RfACGH,'',JWZYMU9luoKCAD7ybSBQ,'','IPTV-EPG_ITEMS-2nd')
	iOCLHMA2cayjIBf = kMLWTt2fO9dnGDUgHh('dict',F3FUSpn5ZHPu6iwQ1sr8)
	S8mfWAEnL3gFZl6UyYV = iOCLHMA2cayjIBf['epg_listings']
	uJnhD0BkiEyAvgad6zOIX = []
	if YKg6awP1xfpHN8cdvS9 in ['ARCHIVED','TIMESHIFT']:
		for nEPScIkxvGwTBoQsmVAD6uCXOgdtr in S8mfWAEnL3gFZl6UyYV:
			if nEPScIkxvGwTBoQsmVAD6uCXOgdtr['has_archive']==1:
				uJnhD0BkiEyAvgad6zOIX.append(nEPScIkxvGwTBoQsmVAD6uCXOgdtr)
				if YKg6awP1xfpHN8cdvS9 in ['TIMESHIFT']: break
		if not uJnhD0BkiEyAvgad6zOIX: return
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if YKg6awP1xfpHN8cdvS9 in ['TIMESHIFT']:
			oXCMcGR21ILJKZYqynfpEkVBm0airO = 2
			fiosv3dNu46LnXBw = oXCMcGR21ILJKZYqynfpEkVBm0airO*PVQeMKFimjdzY1OTqab
			uJnhD0BkiEyAvgad6zOIX = []
			Z5ZXxwMFVa8QspiDPenE0b = int(int(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['start_timestamp'])/fiosv3dNu46LnXBw)*fiosv3dNu46LnXBw
			TEQoMLpaPwch3YmJFdje0yqDR = Low1uSVG5OcafJmrYBC7D+fiosv3dNu46LnXBw
			TT4h8jUg1M0zsBu2PxZyEcbemD = int((TEQoMLpaPwch3YmJFdje0yqDR-Z5ZXxwMFVa8QspiDPenE0b)/PVQeMKFimjdzY1OTqab)
			for Q92XJ4em80ugCsOKaNbL1P in range(TT4h8jUg1M0zsBu2PxZyEcbemD):
				if Q92XJ4em80ugCsOKaNbL1P>=6:
					if Q92XJ4em80ugCsOKaNbL1P%oXCMcGR21ILJKZYqynfpEkVBm0airO!=0: continue
					TlHOFn2rpj0Jh9MsWxfNgGd = fiosv3dNu46LnXBw
				else: TlHOFn2rpj0Jh9MsWxfNgGd = fiosv3dNu46LnXBw//2
				wG4HfJvA1QrRNzVua3hIxyj = Z5ZXxwMFVa8QspiDPenE0b+Q92XJ4em80ugCsOKaNbL1P*PVQeMKFimjdzY1OTqab
				nEPScIkxvGwTBoQsmVAD6uCXOgdtr = {}
				nEPScIkxvGwTBoQsmVAD6uCXOgdtr['title'] = ''
				dvYsGe0Z7wlz = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.localtime(wG4HfJvA1QrRNzVua3hIxyj-MxsFrEHYmje3LtQJS02NwZfy5vR-PVQeMKFimjdzY1OTqab)
				nEPScIkxvGwTBoQsmVAD6uCXOgdtr['start'] = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime('%Y.%m.%d %H:%M:%S',dvYsGe0Z7wlz)
				nEPScIkxvGwTBoQsmVAD6uCXOgdtr['start_timestamp'] = str(wG4HfJvA1QrRNzVua3hIxyj)
				nEPScIkxvGwTBoQsmVAD6uCXOgdtr['stop_timestamp'] = str(wG4HfJvA1QrRNzVua3hIxyj+TlHOFn2rpj0Jh9MsWxfNgGd)
				uJnhD0BkiEyAvgad6zOIX.append(nEPScIkxvGwTBoQsmVAD6uCXOgdtr)
	elif YKg6awP1xfpHN8cdvS9 in ['SHORT_EPG','FULL_EPG']: uJnhD0BkiEyAvgad6zOIX = S8mfWAEnL3gFZl6UyYV
	if YKg6awP1xfpHN8cdvS9=='FULL_EPG' and len(uJnhD0BkiEyAvgad6zOIX)>0:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	GBFRvkXP0QeyI5 = []
	HQ1EncuNLjBOl20R = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Icon')
	for nEPScIkxvGwTBoQsmVAD6uCXOgdtr in uJnhD0BkiEyAvgad6zOIX:
		d8HBf4W3rvEaUYZSFlszD7qXOnk = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['title'])
		if Nnxm30dfoBWRYpIC7KsQGl: d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.decode('utf8')
		wG4HfJvA1QrRNzVua3hIxyj = int(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['start_timestamp'])
		W0poAM8sGhankquFHZezgvJC7EXy = int(nEPScIkxvGwTBoQsmVAD6uCXOgdtr['stop_timestamp'])
		uXWjymDQCSrBUk1cbT05naolO = str(int((W0poAM8sGhankquFHZezgvJC7EXy-wG4HfJvA1QrRNzVua3hIxyj+59)/60))
		KKLlCWFiz4 = nEPScIkxvGwTBoQsmVAD6uCXOgdtr['start'].replace(' ',':')
		dvYsGe0Z7wlz = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.localtime(wG4HfJvA1QrRNzVua3hIxyj-PVQeMKFimjdzY1OTqab)
		RKEbZYWdrq1IQO = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime('%H:%M',dvYsGe0Z7wlz)
		kiKOPjAESp69V = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.strftime('%a',dvYsGe0Z7wlz)
		if YKg6awP1xfpHN8cdvS9=='SHORT_EPG': d8HBf4W3rvEaUYZSFlszD7qXOnk = '[COLOR FFFFFF00]'+RKEbZYWdrq1IQO+' ـ '+d8HBf4W3rvEaUYZSFlszD7qXOnk+'[/COLOR]'
		elif YKg6awP1xfpHN8cdvS9=='TIMESHIFT': d8HBf4W3rvEaUYZSFlszD7qXOnk = kiKOPjAESp69V+' '+RKEbZYWdrq1IQO+' ('+uXWjymDQCSrBUk1cbT05naolO+'min)'
		else: d8HBf4W3rvEaUYZSFlszD7qXOnk = kiKOPjAESp69V+' '+RKEbZYWdrq1IQO+' ('+uXWjymDQCSrBUk1cbT05naolO+'min)   '+d8HBf4W3rvEaUYZSFlszD7qXOnk+' ـ'
		if YKg6awP1xfpHN8cdvS9 in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			PRdOBLva7gcwtKCyeiZVAhnM = j4bsZF9S25q1VGECt+'/timeshift/'+UU8oBeXhQstYkGfx2cTyOHZS6bmR+'/'+CzjoN98nk0+'/'+uXWjymDQCSrBUk1cbT05naolO+'/'+KKLlCWFiz4+'/'+WFKweYk98TnbvPtdl0D3+'.m3u8'
			if YKg6awP1xfpHN8cdvS9=='FULL_EPG': fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,PRdOBLva7gcwtKCyeiZVAhnM,9999,HQ1EncuNLjBOl20R,'','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,PRdOBLva7gcwtKCyeiZVAhnM,235,HQ1EncuNLjBOl20R,'','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
		GBFRvkXP0QeyI5.append(d8HBf4W3rvEaUYZSFlszD7qXOnk)
	if YKg6awP1xfpHN8cdvS9=='SHORT_EPG' and GBFRvkXP0QeyI5: HjK2tFNi9uwBYmVlcxR1GS8 = r4PGXcF6oTdYiMQ9jwn01SmUp(GBFRvkXP0QeyI5)
	return GBFRvkXP0QeyI5
def ZZOEBlGHXnu8iD(vknQOmFaRT7sxDcr1zZyNGtBuA):
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,True): return
	j4bsZF9S25q1VGECt,iCPxRlLVeJudBQ,b8MvfkVnE47PQu9TAteR602wDr = '',0,0
	tabjWm69HD,J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu = DPE0OIv9k2LYp(vknQOmFaRT7sxDcr1zZyNGtBuA,False)
	if tabjWm69HD:
		m3OB4iRfoDTAjtPWYgVK2xa5cpCLZ = oGtm30nXy6kYH9JRAhBDsvuO(J19QAZ0aIKwu)
		iCPxRlLVeJudBQ = gjUBboyawT4ZlRW0M3(m3OB4iRfoDTAjtPWYgVK2xa5cpCLZ[0],int(w3skRhb1cKt6NWYDGyEl4UAzvQu))
		KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,'LIVE_GROUPED')
		tuygpYwFkcJPqb3rhC5n4 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'list','LIVE_GROUPED')
		aatNAwDZOBf1Co2MPdRm8v5sEzxKIh = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'list','LIVE_GROUPED',tuygpYwFkcJPqb3rhC5n4[1])
		HbqSfZ6m7FAa = aatNAwDZOBf1Co2MPdRm8v5sEzxKIh[0][2]
		XwQYhcUBSk = QPuHKNAT4jmCRg.findall('://(.*?)/',HbqSfZ6m7FAa,QPuHKNAT4jmCRg.DOTALL)
		XwQYhcUBSk = XwQYhcUBSk[0]
		if ':' in XwQYhcUBSk: GtXx7UNgIv3cpS4WnF,xkIqQ7GgnsapOBFZ = XwQYhcUBSk.split(':')
		else: GtXx7UNgIv3cpS4WnF,xkIqQ7GgnsapOBFZ = XwQYhcUBSk,'80'
		jk0H3ZLB9I = oGtm30nXy6kYH9JRAhBDsvuO(GtXx7UNgIv3cpS4WnF)
		b8MvfkVnE47PQu9TAteR602wDr = gjUBboyawT4ZlRW0M3(jk0H3ZLB9I[0],int(xkIqQ7GgnsapOBFZ))
	if iCPxRlLVeJudBQ and b8MvfkVnE47PQu9TAteR602wDr:
		qNEnDMwm1Vfastx2ZkpRh = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		qNEnDMwm1Vfastx2ZkpRh += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(b8MvfkVnE47PQu9TAteR602wDr*1000))+' ملي ثانية'
		qNEnDMwm1Vfastx2ZkpRh += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(iCPxRlLVeJudBQ*1000))+' ملي ثانية'
		IjESVoUqQMhdb = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',qNEnDMwm1Vfastx2ZkpRh)
		if IjESVoUqQMhdb==1 and iCPxRlLVeJudBQ<b8MvfkVnE47PQu9TAteR602wDr: j4bsZF9S25q1VGECt = J19QAZ0aIKwu+':'+w3skRhb1cKt6NWYDGyEl4UAzvQu
	else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.server_'+vknQOmFaRT7sxDcr1zZyNGtBuA,j4bsZF9S25q1VGECt)
	return
def unQmcpAEF2DaNX87fTgMW(vknQOmFaRT7sxDcr1zZyNGtBuA,HbqSfZ6m7FAa,ghLJETx5pD7):
	AADxbeEu2MfRaU = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.useragent_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	gojiut7Z5n0W = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.referer_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if AADxbeEu2MfRaU or gojiut7Z5n0W:
		HbqSfZ6m7FAa += '|'
		if AADxbeEu2MfRaU: HbqSfZ6m7FAa += '&User-Agent='+AADxbeEu2MfRaU
		if gojiut7Z5n0W: HbqSfZ6m7FAa += '&Referer='+gojiut7Z5n0W
		HbqSfZ6m7FAa = HbqSfZ6m7FAa.replace('|&','|')
	lJjNtnhU5boFwiVk1DLY3Bau0HK = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.server_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if lJjNtnhU5boFwiVk1DLY3Bau0HK:
		CCxBRQkHImEytAD = QPuHKNAT4jmCRg.findall('://(.*?)/',HbqSfZ6m7FAa,QPuHKNAT4jmCRg.DOTALL)
		HbqSfZ6m7FAa = HbqSfZ6m7FAa.replace(CCxBRQkHImEytAD[0],lJjNtnhU5boFwiVk1DLY3Bau0HK)
	zT3xJQIVDmCgapBljs(HbqSfZ6m7FAa,amlcehCxU3O2yoGf,ghLJETx5pD7)
	return
def ooFcRxqYLvC45rWd18UI7(vknQOmFaRT7sxDcr1zZyNGtBuA):
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	AADxbeEu2MfRaU = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.useragent_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','استخدام الأصلي','تعديل القديم',AADxbeEu2MfRaU,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if dd8lCz9Tq30==1: AADxbeEu2MfRaU = wod1HJ0fnvcTNAX2WIiMu9P('أكتب ـIPTV User-Agent جديد',AADxbeEu2MfRaU,True)
	else: AADxbeEu2MfRaU = 'Unknown'
	if AADxbeEu2MfRaU==' ':
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','',AADxbeEu2MfRaU,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if dd8lCz9Tq30!=1:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم الإلغاء')
		return
	fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.useragent_'+vknQOmFaRT7sxDcr1zZyNGtBuA,AADxbeEu2MfRaU)
	TTWIS7KUQdAf1ZpCV5HDunGkt8(vknQOmFaRT7sxDcr1zZyNGtBuA)
	return
def uQtfjLAJKhwENi6sX27W8bzHOMre4(vknQOmFaRT7sxDcr1zZyNGtBuA):
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	gojiut7Z5n0W = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.referer_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','استخدام الأصلي','تعديل القديم',gojiut7Z5n0W,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if dd8lCz9Tq30==1: gojiut7Z5n0W = wod1HJ0fnvcTNAX2WIiMu9P('أكتب ـIPTV Referer جديد',gojiut7Z5n0W,True)
	else: gojiut7Z5n0W = ''
	if gojiut7Z5n0W==' ':
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','',gojiut7Z5n0W,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if dd8lCz9Tq30!=1:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم الإلغاء')
		return
	fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.referer_'+vknQOmFaRT7sxDcr1zZyNGtBuA,gojiut7Z5n0W)
	TTWIS7KUQdAf1ZpCV5HDunGkt8(vknQOmFaRT7sxDcr1zZyNGtBuA)
	return
def PALIf97ew3T0JispFkK(vknQOmFaRT7sxDcr1zZyNGtBuA,vrVojQGM2dU3eKRq=''):
	if not vrVojQGM2dU3eKRq: vrVojQGM2dU3eKRq = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.url_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	j4bsZF9S25q1VGECt = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(vrVojQGM2dU3eKRq,'url')
	UU8oBeXhQstYkGfx2cTyOHZS6bmR = QPuHKNAT4jmCRg.findall('username=(.*?)&',vrVojQGM2dU3eKRq+'&',QPuHKNAT4jmCRg.DOTALL)
	CzjoN98nk0 = QPuHKNAT4jmCRg.findall('password=(.*?)&',vrVojQGM2dU3eKRq+'&',QPuHKNAT4jmCRg.DOTALL)
	if not UU8oBeXhQstYkGfx2cTyOHZS6bmR or not CzjoN98nk0:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	UU8oBeXhQstYkGfx2cTyOHZS6bmR = UU8oBeXhQstYkGfx2cTyOHZS6bmR[0]
	CzjoN98nk0 = CzjoN98nk0[0]
	RRVsEiIu9efhz = j4bsZF9S25q1VGECt+'/player_api.php?username='+UU8oBeXhQstYkGfx2cTyOHZS6bmR+'&password='+CzjoN98nk0
	wwPhbdD6GL52AygQWFIHmp = j4bsZF9S25q1VGECt+'/get.php?username='+UU8oBeXhQstYkGfx2cTyOHZS6bmR+'&password='+CzjoN98nk0+'&type=m3u_plus'
	return RRVsEiIu9efhz,wwPhbdD6GL52AygQWFIHmp,j4bsZF9S25q1VGECt,UU8oBeXhQstYkGfx2cTyOHZS6bmR,CzjoN98nk0
def BSvMgDAR2mks798bifFuVt6(vknQOmFaRT7sxDcr1zZyNGtBuA,lg9jqIGnadfbDyMV8EQ=''):
	PlLbAY3yiROw9WXJIHMFoca = lg9jqIGnadfbDyMV8EQ.replace('/','_').replace(':','_').replace('.','_')
	PlLbAY3yiROw9WXJIHMFoca = PlLbAY3yiROw9WXJIHMFoca.replace('?','_').replace('=','_').replace('&','_')
	PlLbAY3yiROw9WXJIHMFoca = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,PlLbAY3yiROw9WXJIHMFoca).strip('.m3u')+'.m3u'
	return PlLbAY3yiROw9WXJIHMFoca
def LLFAGKJgjb1Iva50hPRdZ4(vknQOmFaRT7sxDcr1zZyNGtBuA):
	GGCDEyNr2UnlbARuV = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.url_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	zzQerRNkYfacX7 = True
	if GGCDEyNr2UnlbARuV:
		dd8lCz9Tq30 = GjZltWoCxuIwNfQ7EH9('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+GGCDEyNr2UnlbARuV+'[/COLOR]'+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if dd8lCz9Tq30==-1: return
		elif dd8lCz9Tq30==0: GGCDEyNr2UnlbARuV = ''
		elif dd8lCz9Tq30==2:
			dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if dd8lCz9Tq30 in [-1,0]: return
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم مسح الرابط')
			zzQerRNkYfacX7 = False
			mLAzbISCD3F7X1rJ0Wc6 = ''
	if zzQerRNkYfacX7:
		mLAzbISCD3F7X1rJ0Wc6 = wod1HJ0fnvcTNAX2WIiMu9P('اكتب رابط ـIPTV كاملا',GGCDEyNr2UnlbARuV)
		mLAzbISCD3F7X1rJ0Wc6 = mLAzbISCD3F7X1rJ0Wc6.strip(' ')
		if not mLAzbISCD3F7X1rJ0Wc6:
			dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if dd8lCz9Tq30 in [-1,0]: return
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم مسح الرابط')
	else:
		RRVsEiIu9efhz,wwPhbdD6GL52AygQWFIHmp,j4bsZF9S25q1VGECt,UU8oBeXhQstYkGfx2cTyOHZS6bmR,CzjoN98nk0 = PALIf97ew3T0JispFkK(vknQOmFaRT7sxDcr1zZyNGtBuA,mLAzbISCD3F7X1rJ0Wc6)
		if not UU8oBeXhQstYkGfx2cTyOHZS6bmR: return
		qNEnDMwm1Vfastx2ZkpRh = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		qNEnDMwm1Vfastx2ZkpRh += '\n[COLOR FFFFFF00]'+j4bsZF9S25q1VGECt+'[/COLOR]عنوان السيرفر: '
		qNEnDMwm1Vfastx2ZkpRh += '\n[COLOR FFFFFF00]'+UU8oBeXhQstYkGfx2cTyOHZS6bmR+'[/COLOR]اسم المستخدم: '
		qNEnDMwm1Vfastx2ZkpRh += '\n[COLOR FFFFFF00]'+CzjoN98nk0+'[/COLOR]كلمة السر: '
		dd8lCz9Tq30 = C5JBeSxPzuskXi1ROnMHAmWp06dE7('right','','','الرابط الجديد هو:','[COLOR FFC89008]'+mLAzbISCD3F7X1rJ0Wc6+'[/COLOR]'+'\n\n'+qNEnDMwm1Vfastx2ZkpRh)
		if dd8lCz9Tq30!=1:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم الإلغاء')
			return
	fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.url_'+vknQOmFaRT7sxDcr1zZyNGtBuA,mLAzbISCD3F7X1rJ0Wc6)
	fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.timestamp_'+vknQOmFaRT7sxDcr1zZyNGtBuA,'')
	fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.timediff_'+vknQOmFaRT7sxDcr1zZyNGtBuA,'')
	AADxbeEu2MfRaU = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.useragent_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if not AADxbeEu2MfRaU: fQ6kvwg1FrYAzXjbLT.setSetting('av.iptv.useragent_'+vknQOmFaRT7sxDcr1zZyNGtBuA,'Unknown')
	mIKUtx5lN48AGJrsDv6TbFg = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','',mLAzbISCD3F7X1rJ0Wc6+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if mIKUtx5lN48AGJrsDv6TbFg==1: tabjWm69HD,J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu = DPE0OIv9k2LYp(vknQOmFaRT7sxDcr1zZyNGtBuA,True)
	TTWIS7KUQdAf1ZpCV5HDunGkt8(vknQOmFaRT7sxDcr1zZyNGtBuA)
	return
def VFLsMxeS4ZtGoAujy7NvRKkl1CPrc(kM2FOrWe9XhQVaDI,grYvUt4HjyVh,qdAIVoTk42YaZvmKhWPU5H7QLMEXn,X8bUgFnQeI16CfxSuka7,gWERLS6zcOC2FPt5b4xrfuDm0l1nUi,RP8pdTOZKWQev0LGXrzxVhAm,wwPhbdD6GL52AygQWFIHmp):
	aatNAwDZOBf1Co2MPdRm8v5sEzxKIh,cd1QtHX0gBLSDzYpmou9WTsaK6 = [],[]
	IRM32nk0EF87LfSZuN = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
		if RP8pdTOZKWQev0LGXrzxVhAm%473==0:
			Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,40+int(10*RP8pdTOZKWQev0LGXrzxVhAm/gWERLS6zcOC2FPt5b4xrfuDm0l1nUi),'قراءة الفيديوهات','الفيديو رقم:-',str(RP8pdTOZKWQev0LGXrzxVhAm)+' / '+str(gWERLS6zcOC2FPt5b4xrfuDm0l1nUi))
			if X8bUgFnQeI16CfxSuka7.iscanceled():
				X8bUgFnQeI16CfxSuka7.close()
				return None,None,None
		HbqSfZ6m7FAa = QPuHKNAT4jmCRg.findall('^(.*?)\n+((http|https|rtmp).*?)$',ssAiraohPKc5XpOjnI,QPuHKNAT4jmCRg.DOTALL)
		if HbqSfZ6m7FAa:
			ssAiraohPKc5XpOjnI,HbqSfZ6m7FAa,LLNfYeyZwd6283Ssrol9 = HbqSfZ6m7FAa[0]
			HbqSfZ6m7FAa = HbqSfZ6m7FAa.replace('\n','')
			ssAiraohPKc5XpOjnI = ssAiraohPKc5XpOjnI.replace('\n','')
		else:
			cd1QtHX0gBLSDzYpmou9WTsaK6.append({'line':ssAiraohPKc5XpOjnI})
			continue
		F3F9MjihrId,C32AEk8uZTeFPI94LG6dmczv,HBmVXtdERwka,d8HBf4W3rvEaUYZSFlszD7qXOnk,ghLJETx5pD7,DDCMaqAdZros0l = {},'','','','',False
		try:
			ssAiraohPKc5XpOjnI,d8HBf4W3rvEaUYZSFlszD7qXOnk = ssAiraohPKc5XpOjnI.rsplit('",',1)
			ssAiraohPKc5XpOjnI = ssAiraohPKc5XpOjnI+'"'
		except:
			try: ssAiraohPKc5XpOjnI,d8HBf4W3rvEaUYZSFlszD7qXOnk = ssAiraohPKc5XpOjnI.rsplit('1,',1)
			except: d8HBf4W3rvEaUYZSFlszD7qXOnk = ''
		F3F9MjihrId['url'] = HbqSfZ6m7FAa
		FfVrlH8zoPtE0ZpnTsg6B = QPuHKNAT4jmCRg.findall(' (.*?)="(.*?)"',ssAiraohPKc5XpOjnI,QPuHKNAT4jmCRg.DOTALL)
		for yChXl3AKe7H9f,PwUO4g2mDJfNhZRkCq in FfVrlH8zoPtE0ZpnTsg6B:
			yChXl3AKe7H9f = yChXl3AKe7H9f.replace('"','').strip(' ')
			F3F9MjihrId[yChXl3AKe7H9f] = PwUO4g2mDJfNhZRkCq.strip(' ')
		Rm370qA1FdOtjIN2ycoiJ = list(F3F9MjihrId.keys())
		if not d8HBf4W3rvEaUYZSFlszD7qXOnk:
			if 'name' in Rm370qA1FdOtjIN2ycoiJ and F3F9MjihrId['name']: d8HBf4W3rvEaUYZSFlszD7qXOnk = F3F9MjihrId['name']
		F3F9MjihrId['title'] = d8HBf4W3rvEaUYZSFlszD7qXOnk.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in Rm370qA1FdOtjIN2ycoiJ:
			F3F9MjihrId['img'] = F3F9MjihrId['logo']
			del F3F9MjihrId['logo']
		else: F3F9MjihrId['img'] = ''
		if 'group' in Rm370qA1FdOtjIN2ycoiJ and F3F9MjihrId['group']: HBmVXtdERwka = F3F9MjihrId['group']
		if any(pp8iHB3W9Cs in HbqSfZ6m7FAa.lower() for pp8iHB3W9Cs in IRM32nk0EF87LfSZuN):
			DDCMaqAdZros0l = True if 'm3u' not in HbqSfZ6m7FAa else False
		if DDCMaqAdZros0l or '__SERIES__' in HBmVXtdERwka or '__MOVIES__' in HBmVXtdERwka:
			ghLJETx5pD7 = 'VOD'
			if '__SERIES__' in HBmVXtdERwka: ghLJETx5pD7 = ghLJETx5pD7+'_SERIES'
			elif '__MOVIES__' in HBmVXtdERwka: ghLJETx5pD7 = ghLJETx5pD7+'_MOVIES'
			else: ghLJETx5pD7 = ghLJETx5pD7+'_UNKNOWN'
			HBmVXtdERwka = HBmVXtdERwka.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			ghLJETx5pD7 = 'LIVE'
			if d8HBf4W3rvEaUYZSFlszD7qXOnk in grYvUt4HjyVh: C32AEk8uZTeFPI94LG6dmczv = C32AEk8uZTeFPI94LG6dmczv+'_EPG'
			if d8HBf4W3rvEaUYZSFlszD7qXOnk in qdAIVoTk42YaZvmKhWPU5H7QLMEXn: C32AEk8uZTeFPI94LG6dmczv = C32AEk8uZTeFPI94LG6dmczv+'_ARCHIVED'
			if not HBmVXtdERwka: ghLJETx5pD7 = ghLJETx5pD7+'_UNKNOWN'
			else: ghLJETx5pD7 = ghLJETx5pD7+C32AEk8uZTeFPI94LG6dmczv
		HBmVXtdERwka = HBmVXtdERwka.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in ghLJETx5pD7: HBmVXtdERwka = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in ghLJETx5pD7: HBmVXtdERwka = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in ghLJETx5pD7:
			XfC7QtHKNzavlE2TS1ZIm = QPuHKNAT4jmCRg.findall('(.*?) [Ss]\d+ +[Ee]\d+',F3F9MjihrId['title'],QPuHKNAT4jmCRg.DOTALL)
			if XfC7QtHKNzavlE2TS1ZIm: XfC7QtHKNzavlE2TS1ZIm = XfC7QtHKNzavlE2TS1ZIm[0]
			else: XfC7QtHKNzavlE2TS1ZIm = '!!__UNKNOWN_SERIES__!!'
			HBmVXtdERwka = HBmVXtdERwka+'__SERIES__'+XfC7QtHKNzavlE2TS1ZIm
		if 'id' in Rm370qA1FdOtjIN2ycoiJ: del F3F9MjihrId['id']
		if 'ID' in Rm370qA1FdOtjIN2ycoiJ: del F3F9MjihrId['ID']
		if 'name' in Rm370qA1FdOtjIN2ycoiJ: del F3F9MjihrId['name']
		d8HBf4W3rvEaUYZSFlszD7qXOnk = F3F9MjihrId['title']
		d8HBf4W3rvEaUYZSFlszD7qXOnk = kWfpQA7tTjSPyLbNIeMr1Hui5(d8HBf4W3rvEaUYZSFlszD7qXOnk)
		d8HBf4W3rvEaUYZSFlszD7qXOnk = uHQjAEokY7X(d8HBf4W3rvEaUYZSFlszD7qXOnk)
		aVHiYxNCDhwSoPqO3,HBmVXtdERwka = LCZDeTGgNXvqYwBcfQhH1UrRF(HBmVXtdERwka)
		GGmlxIA7fC2QrZXihsKbyOFzE,d8HBf4W3rvEaUYZSFlszD7qXOnk = LCZDeTGgNXvqYwBcfQhH1UrRF(d8HBf4W3rvEaUYZSFlszD7qXOnk)
		F3F9MjihrId['type'] = ghLJETx5pD7
		F3F9MjihrId['context'] = C32AEk8uZTeFPI94LG6dmczv
		F3F9MjihrId['group'] = HBmVXtdERwka.upper()
		F3F9MjihrId['title'] = d8HBf4W3rvEaUYZSFlszD7qXOnk.upper()
		F3F9MjihrId['country'] = GGmlxIA7fC2QrZXihsKbyOFzE.upper()
		F3F9MjihrId['language'] = aVHiYxNCDhwSoPqO3.upper()
		aatNAwDZOBf1Co2MPdRm8v5sEzxKIh.append(F3F9MjihrId)
		RP8pdTOZKWQev0LGXrzxVhAm += 1
	return aatNAwDZOBf1Co2MPdRm8v5sEzxKIh,RP8pdTOZKWQev0LGXrzxVhAm,cd1QtHX0gBLSDzYpmou9WTsaK6
def uHQjAEokY7X(d8HBf4W3rvEaUYZSFlszD7qXOnk):
	d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.replace('||','|').replace('___',':').replace('--','-')
	d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.replace('[[','[').replace(']]',']')
	d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.replace('((','(').replace('))',')')
	d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.replace('<<','<').replace('>>','>')
	d8HBf4W3rvEaUYZSFlszD7qXOnk = d8HBf4W3rvEaUYZSFlszD7qXOnk.strip(' ')
	return d8HBf4W3rvEaUYZSFlszD7qXOnk
def bdHK4FOuZMyhS58iUVk2Nw6pIPQzEA(drizJ6tc4Xl0mMZSIxCNYBjf9bu,X8bUgFnQeI16CfxSuka7):
	rs9vZJxbPqMKmD = {}
	for FFwS70Nu21yMzvlHxKcQ in ilwajn2UGYP: rs9vZJxbPqMKmD[FFwS70Nu21yMzvlHxKcQ] = []
	gWERLS6zcOC2FPt5b4xrfuDm0l1nUi = len(drizJ6tc4Xl0mMZSIxCNYBjf9bu)
	xigS38qVwcyhCarzAZF = str(gWERLS6zcOC2FPt5b4xrfuDm0l1nUi)
	RP8pdTOZKWQev0LGXrzxVhAm = 0
	cd1QtHX0gBLSDzYpmou9WTsaK6 = []
	for F3F9MjihrId in drizJ6tc4Xl0mMZSIxCNYBjf9bu:
		if RP8pdTOZKWQev0LGXrzxVhAm%873==0:
			Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,50+int(5*RP8pdTOZKWQev0LGXrzxVhAm/gWERLS6zcOC2FPt5b4xrfuDm0l1nUi),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(RP8pdTOZKWQev0LGXrzxVhAm)+' / '+xigS38qVwcyhCarzAZF)
			if X8bUgFnQeI16CfxSuka7.iscanceled():
				X8bUgFnQeI16CfxSuka7.close()
				return None,None
		HBmVXtdERwka,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R = F3F9MjihrId['group'],F3F9MjihrId['context'],F3F9MjihrId['title'],F3F9MjihrId['url'],F3F9MjihrId['img']
		GGmlxIA7fC2QrZXihsKbyOFzE,aVHiYxNCDhwSoPqO3,FFwS70Nu21yMzvlHxKcQ = F3F9MjihrId['country'],F3F9MjihrId['language'],F3F9MjihrId['type']
		AOPHa9ymfs6 = (HBmVXtdERwka,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R)
		RdAnHbDoBkr = False
		if 'LIVE' in FFwS70Nu21yMzvlHxKcQ:
			if 'UNKNOWN' in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['LIVE_UNKNOWN_GROUPED'].append(AOPHa9ymfs6)
			elif 'LIVE' in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['LIVE_GROUPED'].append(AOPHa9ymfs6)
			else: RdAnHbDoBkr = True
			rs9vZJxbPqMKmD['LIVE_ORIGINAL_GROUPED'].append(AOPHa9ymfs6)
		elif 'VOD' in FFwS70Nu21yMzvlHxKcQ:
			if 'UNKNOWN' in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['VOD_UNKNOWN_GROUPED'].append(AOPHa9ymfs6)
			elif 'MOVIES' in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['VOD_MOVIES_GROUPED'].append(AOPHa9ymfs6)
			elif 'SERIES' in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['VOD_SERIES_GROUPED'].append(AOPHa9ymfs6)
			else: RdAnHbDoBkr = True
			rs9vZJxbPqMKmD['VOD_ORIGINAL_GROUPED'].append(AOPHa9ymfs6)
		else: RdAnHbDoBkr = True
		if RdAnHbDoBkr: cd1QtHX0gBLSDzYpmou9WTsaK6.append(F3F9MjihrId)
		RP8pdTOZKWQev0LGXrzxVhAm += 1
	r3HaLnEW5sP9NQdTJzO6Bpj2 = sorted(drizJ6tc4Xl0mMZSIxCNYBjf9bu,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f['title'].lower())
	del drizJ6tc4Xl0mMZSIxCNYBjf9bu
	xigS38qVwcyhCarzAZF = str(gWERLS6zcOC2FPt5b4xrfuDm0l1nUi)
	RP8pdTOZKWQev0LGXrzxVhAm = 0
	for F3F9MjihrId in r3HaLnEW5sP9NQdTJzO6Bpj2:
		RP8pdTOZKWQev0LGXrzxVhAm += 1
		if RP8pdTOZKWQev0LGXrzxVhAm%873==0:
			Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,55+int(5*RP8pdTOZKWQev0LGXrzxVhAm/gWERLS6zcOC2FPt5b4xrfuDm0l1nUi),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(RP8pdTOZKWQev0LGXrzxVhAm)+' / '+xigS38qVwcyhCarzAZF)
			if X8bUgFnQeI16CfxSuka7.iscanceled():
				X8bUgFnQeI16CfxSuka7.close()
				return None,None
		FFwS70Nu21yMzvlHxKcQ = F3F9MjihrId['type']
		HBmVXtdERwka,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R = F3F9MjihrId['group'],F3F9MjihrId['context'],F3F9MjihrId['title'],F3F9MjihrId['url'],F3F9MjihrId['img']
		GGmlxIA7fC2QrZXihsKbyOFzE,aVHiYxNCDhwSoPqO3 = F3F9MjihrId['country'],F3F9MjihrId['language']
		eegMop4cTURLa3uVbiNS = (HBmVXtdERwka,C32AEk8uZTeFPI94LG6dmczv+'_TIMESHIFT',d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R)
		AOPHa9ymfs6 = (HBmVXtdERwka,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R)
		QZN3Jr2OPHyEglLU5FwMxbh = (GGmlxIA7fC2QrZXihsKbyOFzE,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R)
		g05p1dSB2n = (aVHiYxNCDhwSoPqO3,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R)
		if 'LIVE' in FFwS70Nu21yMzvlHxKcQ:
			if 'UNKNOWN' in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['LIVE_UNKNOWN_GROUPED_SORTED'].append(AOPHa9ymfs6)
			else: rs9vZJxbPqMKmD['LIVE_GROUPED_SORTED'].append(AOPHa9ymfs6)
			if 'EPG'		in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['LIVE_EPG_GROUPED_SORTED'].append(AOPHa9ymfs6)
			if 'ARCHIVED'	in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['LIVE_ARCHIVED_GROUPED_SORTED'].append(AOPHa9ymfs6)
			if 'ARCHIVED'	in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['LIVE_TIMESHIFT_GROUPED_SORTED'].append(eegMop4cTURLa3uVbiNS)
			rs9vZJxbPqMKmD['LIVE_FROM_NAME_SORTED'].append(QZN3Jr2OPHyEglLU5FwMxbh)
			rs9vZJxbPqMKmD['LIVE_FROM_GROUP_SORTED'].append(g05p1dSB2n)
		elif 'VOD' in FFwS70Nu21yMzvlHxKcQ:
			if   'UNKNOWN'	in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['VOD_UNKNOWN_GROUPED_SORTED'].append(AOPHa9ymfs6)
			elif 'MOVIES'	in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['VOD_MOVIES_GROUPED_SORTED'].append(AOPHa9ymfs6)
			elif 'SERIES'	in FFwS70Nu21yMzvlHxKcQ: rs9vZJxbPqMKmD['VOD_SERIES_GROUPED_SORTED'].append(AOPHa9ymfs6)
			rs9vZJxbPqMKmD['VOD_FROM_NAME_SORTED'].append(QZN3Jr2OPHyEglLU5FwMxbh)
			rs9vZJxbPqMKmD['VOD_FROM_GROUP_SORTED'].append(g05p1dSB2n)
	return rs9vZJxbPqMKmD,cd1QtHX0gBLSDzYpmou9WTsaK6
def LCZDeTGgNXvqYwBcfQhH1UrRF(d8HBf4W3rvEaUYZSFlszD7qXOnk):
	if len(d8HBf4W3rvEaUYZSFlszD7qXOnk)<3: return d8HBf4W3rvEaUYZSFlszD7qXOnk,d8HBf4W3rvEaUYZSFlszD7qXOnk
	anr7TbEM4v,w1EDlPriZB0eU5V = '',''
	Rwt3p9bLIdxU = d8HBf4W3rvEaUYZSFlszD7qXOnk
	TjnDGyzYAtCH42msRM9iFLOd = d8HBf4W3rvEaUYZSFlszD7qXOnk[:1]
	Z9BwJtUqivsS72l1c53LXTDkjepM = d8HBf4W3rvEaUYZSFlszD7qXOnk[1:]
	if   TjnDGyzYAtCH42msRM9iFLOd=='(': w1EDlPriZB0eU5V = ')'
	elif TjnDGyzYAtCH42msRM9iFLOd=='[': w1EDlPriZB0eU5V = ']'
	elif TjnDGyzYAtCH42msRM9iFLOd=='<': w1EDlPriZB0eU5V = '>'
	elif TjnDGyzYAtCH42msRM9iFLOd=='|': w1EDlPriZB0eU5V = '|'
	if w1EDlPriZB0eU5V and (w1EDlPriZB0eU5V in Z9BwJtUqivsS72l1c53LXTDkjepM):
		gGc9RZWVaMsx60UbTn,eAgtVHYdBzkLClsQ70J6uSKw8vMZx = Z9BwJtUqivsS72l1c53LXTDkjepM.split(w1EDlPriZB0eU5V,1)
		anr7TbEM4v = gGc9RZWVaMsx60UbTn
		Rwt3p9bLIdxU = TjnDGyzYAtCH42msRM9iFLOd+gGc9RZWVaMsx60UbTn+w1EDlPriZB0eU5V+' '+eAgtVHYdBzkLClsQ70J6uSKw8vMZx
	elif d8HBf4W3rvEaUYZSFlszD7qXOnk.count('|')>=2:
		gGc9RZWVaMsx60UbTn,eAgtVHYdBzkLClsQ70J6uSKw8vMZx = d8HBf4W3rvEaUYZSFlszD7qXOnk.split('|',1)
		anr7TbEM4v = gGc9RZWVaMsx60UbTn
		Rwt3p9bLIdxU = gGc9RZWVaMsx60UbTn+' |'+eAgtVHYdBzkLClsQ70J6uSKw8vMZx
	else:
		w1EDlPriZB0eU5V = QPuHKNAT4jmCRg.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',d8HBf4W3rvEaUYZSFlszD7qXOnk,QPuHKNAT4jmCRg.DOTALL)
		if not w1EDlPriZB0eU5V: w1EDlPriZB0eU5V = QPuHKNAT4jmCRg.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',d8HBf4W3rvEaUYZSFlszD7qXOnk,QPuHKNAT4jmCRg.DOTALL)
		if not w1EDlPriZB0eU5V: w1EDlPriZB0eU5V = QPuHKNAT4jmCRg.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',d8HBf4W3rvEaUYZSFlszD7qXOnk,QPuHKNAT4jmCRg.DOTALL)
		if w1EDlPriZB0eU5V:
			gGc9RZWVaMsx60UbTn,eAgtVHYdBzkLClsQ70J6uSKw8vMZx = d8HBf4W3rvEaUYZSFlszD7qXOnk.split(w1EDlPriZB0eU5V[0],1)
			anr7TbEM4v = gGc9RZWVaMsx60UbTn
			Rwt3p9bLIdxU = gGc9RZWVaMsx60UbTn+' '+w1EDlPriZB0eU5V[0]+' '+eAgtVHYdBzkLClsQ70J6uSKw8vMZx
	Rwt3p9bLIdxU = Rwt3p9bLIdxU.replace('   ',' ').replace('  ',' ')
	anr7TbEM4v = anr7TbEM4v.replace('  ',' ')
	if not anr7TbEM4v: anr7TbEM4v = '!!__UNKNOWN__!!'
	anr7TbEM4v = anr7TbEM4v.strip(' ')
	Rwt3p9bLIdxU = Rwt3p9bLIdxU.strip(' ')
	return anr7TbEM4v,Rwt3p9bLIdxU
def WXx8yidSJvbDE(vknQOmFaRT7sxDcr1zZyNGtBuA):
	JWZYMU9luoKCAD7ybSBQ = {}
	AADxbeEu2MfRaU = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.useragent_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if AADxbeEu2MfRaU: JWZYMU9luoKCAD7ybSBQ['User-Agent'] = AADxbeEu2MfRaU
	gojiut7Z5n0W = fQ6kvwg1FrYAzXjbLT.getSetting('av.iptv.referer_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if gojiut7Z5n0W: JWZYMU9luoKCAD7ybSBQ['Referer'] = gojiut7Z5n0W
	return JWZYMU9luoKCAD7ybSBQ
def nuXml1GPNCS8Z0HIcj(vknQOmFaRT7sxDcr1zZyNGtBuA):
	global X8bUgFnQeI16CfxSuka7,rs9vZJxbPqMKmD,zIHx52Ag4qMmN3k6iWlDFwra,esKz2tFvkiSNc,R16twcrPjd,tuygpYwFkcJPqb3rhC5n4,e67WucsCTYMZbFamBvg1yH5pE,oKM0nwyrs2GBC,A5QGHzOSWpmbDKy9B
	RRVsEiIu9efhz,wwPhbdD6GL52AygQWFIHmp,j4bsZF9S25q1VGECt,UU8oBeXhQstYkGfx2cTyOHZS6bmR,CzjoN98nk0 = PALIf97ew3T0JispFkK(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if not UU8oBeXhQstYkGfx2cTyOHZS6bmR: return
	JWZYMU9luoKCAD7ybSBQ = WXx8yidSJvbDE(vknQOmFaRT7sxDcr1zZyNGtBuA)
	IjESVoUqQMhdb = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if IjESVoUqQMhdb!=1: return
	PlLbAY3yiROw9WXJIHMFoca = odmkxW7uBXr.replace('___','_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	if 1:
		tabjWm69HD,J19QAZ0aIKwu,w3skRhb1cKt6NWYDGyEl4UAzvQu = DPE0OIv9k2LYp(vknQOmFaRT7sxDcr1zZyNGtBuA,False)
		if not tabjWm69HD:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not wwPhbdD6GL52AygQWFIHmp: zRM3tZx2v6DjJU('ERROR_LINES',Wt7AdOqj38VbHfwgoaKPilx(amlcehCxU3O2yoGf)+'   No IPTV URL found to download IPTV files')
			else: zRM3tZx2v6DjJU('ERROR_LINES',Wt7AdOqj38VbHfwgoaKPilx(amlcehCxU3O2yoGf)+'   Failed to download IPTV files')
			return
		rBNilgDRpOP2Sn7v = W6ndv5PCbAh(wwPhbdD6GL52AygQWFIHmp,JWZYMU9luoKCAD7ybSBQ,True)
		if not rBNilgDRpOP2Sn7v: return
		open(PlLbAY3yiROw9WXJIHMFoca,'wb').write(rBNilgDRpOP2Sn7v)
	else: rBNilgDRpOP2Sn7v = open(PlLbAY3yiROw9WXJIHMFoca,'rb').read()
	if Nnxm30dfoBWRYpIC7KsQGl and rBNilgDRpOP2Sn7v: rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.decode('utf8')
	X8bUgFnQeI16CfxSuka7 = zzyalh3A275njbIKsD0EQ()
	X8bUgFnQeI16CfxSuka7.create('جلب ملفات ـIPTV جديدة','')
	Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,15,'تنظيف الملف الرئيسي','')
	rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('"tvg-','" tvg-')
	rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('group-title=','group=').replace('tvg-','')
	qdAIVoTk42YaZvmKhWPU5H7QLMEXn,grYvUt4HjyVh = [],[]
	Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if X8bUgFnQeI16CfxSuka7.iscanceled():
		X8bUgFnQeI16CfxSuka7.close()
		return
	HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_series_categories'
	vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',HbqSfZ6m7FAa,'',JWZYMU9luoKCAD7ybSBQ,'','','IPTV-CREATE_STREAMS-1st')
	F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
	F3FUSpn5ZHPu6iwQ1sr8 = kWfpQA7tTjSPyLbNIeMr1Hui5(F3FUSpn5ZHPu6iwQ1sr8)
	qzF5Zliy0KSMImga3YBRQUTuA7D6 = QPuHKNAT4jmCRg.findall('category_name":"(.*?)"',F3FUSpn5ZHPu6iwQ1sr8,QPuHKNAT4jmCRg.DOTALL)
	del F3FUSpn5ZHPu6iwQ1sr8
	for HBmVXtdERwka in qzF5Zliy0KSMImga3YBRQUTuA7D6:
		HBmVXtdERwka = HBmVXtdERwka.replace('\/','/')
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: HBmVXtdERwka = HBmVXtdERwka.decode('utf8').encode('utf8')
		rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('group="'+HBmVXtdERwka+'"','group="__SERIES__'+HBmVXtdERwka+'"')
	del qzF5Zliy0KSMImga3YBRQUTuA7D6
	Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if X8bUgFnQeI16CfxSuka7.iscanceled():
		X8bUgFnQeI16CfxSuka7.close()
		return
	HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_vod_categories'
	vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',HbqSfZ6m7FAa,'',JWZYMU9luoKCAD7ybSBQ,'','','IPTV-CREATE_STREAMS-2nd')
	F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
	F3FUSpn5ZHPu6iwQ1sr8 = kWfpQA7tTjSPyLbNIeMr1Hui5(F3FUSpn5ZHPu6iwQ1sr8)
	aaslfOiH8uD7CRLZgx1vT = QPuHKNAT4jmCRg.findall('category_name":"(.*?)"',F3FUSpn5ZHPu6iwQ1sr8,QPuHKNAT4jmCRg.DOTALL)
	del F3FUSpn5ZHPu6iwQ1sr8
	for HBmVXtdERwka in aaslfOiH8uD7CRLZgx1vT:
		HBmVXtdERwka = HBmVXtdERwka.replace('\/','/')
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: HBmVXtdERwka = HBmVXtdERwka.decode('utf8').encode('utf8')
		rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('group="'+HBmVXtdERwka+'"','group="__MOVIES__'+HBmVXtdERwka+'"')
	del aaslfOiH8uD7CRLZgx1vT
	Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if X8bUgFnQeI16CfxSuka7.iscanceled():
		X8bUgFnQeI16CfxSuka7.close()
		return
	HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_live_streams'
	vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',HbqSfZ6m7FAa,'',JWZYMU9luoKCAD7ybSBQ,'','','IPTV-CREATE_STREAMS-3rd')
	F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
	F3FUSpn5ZHPu6iwQ1sr8 = kWfpQA7tTjSPyLbNIeMr1Hui5(F3FUSpn5ZHPu6iwQ1sr8)
	AYsVZFDmixqr1J2ke0PCRnySG769dz = QPuHKNAT4jmCRg.findall('"name":"(.*?)".*?"tv_archive":(.*?),',F3FUSpn5ZHPu6iwQ1sr8,QPuHKNAT4jmCRg.DOTALL)
	for pphVUbJkGtHXndg84iZl2DPImSzoC,P0aZ4viLjJhU1Qd3XnqR in AYsVZFDmixqr1J2ke0PCRnySG769dz:
		if P0aZ4viLjJhU1Qd3XnqR=='1': qdAIVoTk42YaZvmKhWPU5H7QLMEXn.append(pphVUbJkGtHXndg84iZl2DPImSzoC)
	del AYsVZFDmixqr1J2ke0PCRnySG769dz
	nL6NCxu1G9OPDrvfAXwdE = QPuHKNAT4jmCRg.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',F3FUSpn5ZHPu6iwQ1sr8,QPuHKNAT4jmCRg.DOTALL)
	del F3FUSpn5ZHPu6iwQ1sr8
	for pphVUbJkGtHXndg84iZl2DPImSzoC,ssG14aZnxRMUOmw50TKcdWHtueBr in nL6NCxu1G9OPDrvfAXwdE:
		if ssG14aZnxRMUOmw50TKcdWHtueBr!='null': grYvUt4HjyVh.append(pphVUbJkGtHXndg84iZl2DPImSzoC)
	del nL6NCxu1G9OPDrvfAXwdE
	rBNilgDRpOP2Sn7v = rBNilgDRpOP2Sn7v.replace('\r','\n')
	kM2FOrWe9XhQVaDI = QPuHKNAT4jmCRg.findall('NF:(.+?)'+'#'+'EXTI',rBNilgDRpOP2Sn7v+'\n+'+'#'+'EXTINF:',QPuHKNAT4jmCRg.DOTALL)
	if not kM2FOrWe9XhQVaDI:
		zRM3tZx2v6DjJU('ERROR_LINES',Wt7AdOqj38VbHfwgoaKPilx(amlcehCxU3O2yoGf)+'   Folder:'+vknQOmFaRT7sxDcr1zZyNGtBuA+'   No video links found in IPTV file')
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+vknQOmFaRT7sxDcr1zZyNGtBuA)
		X8bUgFnQeI16CfxSuka7.close()
		return
	yej6Zx9BmcPkIN = []
	for ssAiraohPKc5XpOjnI in kM2FOrWe9XhQVaDI:
		p6FlGfWqebxO7nc = ssAiraohPKc5XpOjnI.lower()
		if 'adult' in p6FlGfWqebxO7nc: continue
		if 'xxx' in p6FlGfWqebxO7nc: continue
		yej6Zx9BmcPkIN.append(ssAiraohPKc5XpOjnI)
	kM2FOrWe9XhQVaDI = yej6Zx9BmcPkIN
	del yej6Zx9BmcPkIN
	CCvxFPLRrHG1YbAdBaoVlMXw = 1024*1024
	Jd03NDWxo2cRTk = 1+len(rBNilgDRpOP2Sn7v)//CCvxFPLRrHG1YbAdBaoVlMXw//10
	del rBNilgDRpOP2Sn7v
	nngjVt9NrauQkJ2Ym65zIOLcfE = len(kM2FOrWe9XhQVaDI)
	a9u2Q0hXco8rMY = NhUILSwisA(kM2FOrWe9XhQVaDI,Jd03NDWxo2cRTk)
	del kM2FOrWe9XhQVaDI
	for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(Jd03NDWxo2cRTk):
		Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,35+int(5*gI689nKoH2PlifU3AMW5vVEZpFYX1/Jd03NDWxo2cRTk),'تقطيع الملف الرئيسي','الجزء رقم:-',str(gI689nKoH2PlifU3AMW5vVEZpFYX1+1)+' / '+str(Jd03NDWxo2cRTk))
		if X8bUgFnQeI16CfxSuka7.iscanceled():
			X8bUgFnQeI16CfxSuka7.close()
			return
		mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l = str(a9u2Q0hXco8rMY[gI689nKoH2PlifU3AMW5vVEZpFYX1])
		if Nnxm30dfoBWRYpIC7KsQGl: mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l = mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l.encode('utf8')
		open(PlLbAY3yiROw9WXJIHMFoca+'.00'+str(gI689nKoH2PlifU3AMW5vVEZpFYX1),'wb').write(mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l)
	del a9u2Q0hXco8rMY,mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l
	U2CIHmvowsGXN,drizJ6tc4Xl0mMZSIxCNYBjf9bu,RP8pdTOZKWQev0LGXrzxVhAm = [],[],0
	for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(Jd03NDWxo2cRTk):
		if X8bUgFnQeI16CfxSuka7.iscanceled():
			X8bUgFnQeI16CfxSuka7.close()
			return
		mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l = open(PlLbAY3yiROw9WXJIHMFoca+'.00'+str(gI689nKoH2PlifU3AMW5vVEZpFYX1),'rb').read()
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(1)
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(PlLbAY3yiROw9WXJIHMFoca+'.00'+str(gI689nKoH2PlifU3AMW5vVEZpFYX1))
		except: pass
		if Nnxm30dfoBWRYpIC7KsQGl: mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l = mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l.decode('utf8')
		qBIt6fosum = kMLWTt2fO9dnGDUgHh('list',mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l)
		del mDo8GHk4CLn0WrMxiYRhBpdFzUTc7l
		aatNAwDZOBf1Co2MPdRm8v5sEzxKIh,RP8pdTOZKWQev0LGXrzxVhAm,cd1QtHX0gBLSDzYpmou9WTsaK6 = VFLsMxeS4ZtGoAujy7NvRKkl1CPrc(qBIt6fosum,grYvUt4HjyVh,qdAIVoTk42YaZvmKhWPU5H7QLMEXn,X8bUgFnQeI16CfxSuka7,nngjVt9NrauQkJ2Ym65zIOLcfE,RP8pdTOZKWQev0LGXrzxVhAm,wwPhbdD6GL52AygQWFIHmp)
		if X8bUgFnQeI16CfxSuka7.iscanceled():
			X8bUgFnQeI16CfxSuka7.close()
			return
		if not aatNAwDZOBf1Co2MPdRm8v5sEzxKIh:
			X8bUgFnQeI16CfxSuka7.close()
			return
		drizJ6tc4Xl0mMZSIxCNYBjf9bu += aatNAwDZOBf1Co2MPdRm8v5sEzxKIh
		U2CIHmvowsGXN += cd1QtHX0gBLSDzYpmou9WTsaK6
	del qBIt6fosum,aatNAwDZOBf1Co2MPdRm8v5sEzxKIh
	rs9vZJxbPqMKmD,cd1QtHX0gBLSDzYpmou9WTsaK6 = bdHK4FOuZMyhS58iUVk2Nw6pIPQzEA(drizJ6tc4Xl0mMZSIxCNYBjf9bu,X8bUgFnQeI16CfxSuka7)
	if X8bUgFnQeI16CfxSuka7.iscanceled():
		X8bUgFnQeI16CfxSuka7.close()
		return
	U2CIHmvowsGXN += cd1QtHX0gBLSDzYpmou9WTsaK6
	del drizJ6tc4Xl0mMZSIxCNYBjf9bu,cd1QtHX0gBLSDzYpmou9WTsaK6
	esKz2tFvkiSNc,R16twcrPjd,tuygpYwFkcJPqb3rhC5n4,e67WucsCTYMZbFamBvg1yH5pE,oKM0nwyrs2GBC = {},{},{},0,0
	AdRI5ngVz9w0lf4cse2C7xX = list(rs9vZJxbPqMKmD.keys())
	A5QGHzOSWpmbDKy9B = len(AdRI5ngVz9w0lf4cse2C7xX)*3
	if 1:
		nnSuN2dObFiGflhcgRE8Z0HpqM = {}
		for L6wOQrDsfy94j8WIg3Kad7E in AdRI5ngVz9w0lf4cse2C7xX:
			nnSuN2dObFiGflhcgRE8Z0HpqM[L6wOQrDsfy94j8WIg3Kad7E] = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=p41MatVJHv3s895yTb,args=(L6wOQrDsfy94j8WIg3Kad7E,))
			nnSuN2dObFiGflhcgRE8Z0HpqM[L6wOQrDsfy94j8WIg3Kad7E].start()
		for L6wOQrDsfy94j8WIg3Kad7E in AdRI5ngVz9w0lf4cse2C7xX:
			nnSuN2dObFiGflhcgRE8Z0HpqM[L6wOQrDsfy94j8WIg3Kad7E].join()
		if X8bUgFnQeI16CfxSuka7.iscanceled():
			X8bUgFnQeI16CfxSuka7.close()
			return
	else:
		for L6wOQrDsfy94j8WIg3Kad7E in AdRI5ngVz9w0lf4cse2C7xX:
			p41MatVJHv3s895yTb(L6wOQrDsfy94j8WIg3Kad7E)
			if X8bUgFnQeI16CfxSuka7.iscanceled():
				X8bUgFnQeI16CfxSuka7.close()
				return
	bIXayWVe45Q3(vknQOmFaRT7sxDcr1zZyNGtBuA,False)
	AdRI5ngVz9w0lf4cse2C7xX = list(esKz2tFvkiSNc.keys())
	zIHx52Ag4qMmN3k6iWlDFwra = 0
	if 1:
		nnSuN2dObFiGflhcgRE8Z0HpqM = {}
		for L6wOQrDsfy94j8WIg3Kad7E in AdRI5ngVz9w0lf4cse2C7xX:
			nnSuN2dObFiGflhcgRE8Z0HpqM[L6wOQrDsfy94j8WIg3Kad7E] = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=vK39BDET2RrXQfwPtAkyobpJSl,args=(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E))
			nnSuN2dObFiGflhcgRE8Z0HpqM[L6wOQrDsfy94j8WIg3Kad7E].start()
		for L6wOQrDsfy94j8WIg3Kad7E in AdRI5ngVz9w0lf4cse2C7xX:
			nnSuN2dObFiGflhcgRE8Z0HpqM[L6wOQrDsfy94j8WIg3Kad7E].join()
		if X8bUgFnQeI16CfxSuka7.iscanceled():
			X8bUgFnQeI16CfxSuka7.close()
			return
	else:
		for L6wOQrDsfy94j8WIg3Kad7E in AdRI5ngVz9w0lf4cse2C7xX:
			vK39BDET2RrXQfwPtAkyobpJSl(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E)
			if X8bUgFnQeI16CfxSuka7.iscanceled():
				X8bUgFnQeI16CfxSuka7.close()
				return
	gI689nKoH2PlifU3AMW5vVEZpFYX1 = 0
	XX4wH1OUWg = len(U2CIHmvowsGXN)
	KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,'IGNORED')
	for lu53w68ZLNyqeDpFVCGBIPkM9Q7AbT in U2CIHmvowsGXN:
		if gI689nKoH2PlifU3AMW5vVEZpFYX1%27==0:
			Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,95+int(5*gI689nKoH2PlifU3AMW5vVEZpFYX1//XX4wH1OUWg),'تخزين المهملة','الفيديو رقم:-',str(gI689nKoH2PlifU3AMW5vVEZpFYX1)+' / '+str(XX4wH1OUWg))
			if X8bUgFnQeI16CfxSuka7.iscanceled():
				X8bUgFnQeI16CfxSuka7.close()
				return
		mhr0way8dQLUMt6uSIPqGW(KKEFMu8UyqYI,'IGNORED',str(lu53w68ZLNyqeDpFVCGBIPkM9Q7AbT),'',VYn9o683LCcspE7Jew5gMQrZbj)
		gI689nKoH2PlifU3AMW5vVEZpFYX1 += 1
	mhr0way8dQLUMt6uSIPqGW(KKEFMu8UyqYI,'IGNORED','__COUNT__',str(XX4wH1OUWg),VYn9o683LCcspE7Jew5gMQrZbj)
	mhr0way8dQLUMt6uSIPqGW(KKEFMu8UyqYI,'DUMMY','__DUMMY__','1',VYn9o683LCcspE7Jew5gMQrZbj)
	X8bUgFnQeI16CfxSuka7.close()
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(1)
	nksm578BUMxuY3SVq2DA64 = TyAoZj5puBINz1rwWGf(vknQOmFaRT7sxDcr1zZyNGtBuA,False)
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','[COLOR FFFFFF00]'+'تم جلب ملفات ـIPTV جديدة'+'[/COLOR]'+'\n\n'+nksm578BUMxuY3SVq2DA64)
	AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin('Container.Refresh')
	TTWIS7KUQdAf1ZpCV5HDunGkt8(vknQOmFaRT7sxDcr1zZyNGtBuA)
	return
def p41MatVJHv3s895yTb(L6wOQrDsfy94j8WIg3Kad7E):
	global X8bUgFnQeI16CfxSuka7,rs9vZJxbPqMKmD,zIHx52Ag4qMmN3k6iWlDFwra,esKz2tFvkiSNc,R16twcrPjd,tuygpYwFkcJPqb3rhC5n4,e67WucsCTYMZbFamBvg1yH5pE,oKM0nwyrs2GBC,A5QGHzOSWpmbDKy9B
	esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E] = {}
	y1SWlhH7pcEw4sd0kNJb3mGjqQ6,JJw5K0FdYPLZ3qDm = {},[]
	cZwkC0hi9FduOrEV2L3UX85flJte = len(rs9vZJxbPqMKmD[L6wOQrDsfy94j8WIg3Kad7E])
	esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E]['__COUNT__'] = cZwkC0hi9FduOrEV2L3UX85flJte
	if cZwkC0hi9FduOrEV2L3UX85flJte>0:
		qqcNIgEkjPUbB0Wh8eOKfFv6xXnL,KgVSJFYkaBcIv1827s5mfn6AL0Wyw3,LrmRhZuDkCgGb,Q3YPESe9zsF8rLoRh0mj2dCTBucJb,VJGAWXUsTyne1iZ = zip(*rs9vZJxbPqMKmD[L6wOQrDsfy94j8WIg3Kad7E])
		del KgVSJFYkaBcIv1827s5mfn6AL0Wyw3,LrmRhZuDkCgGb,Q3YPESe9zsF8rLoRh0mj2dCTBucJb
		krYOFaINJBtc1j0CRg2Q3dhmf = list(set(qqcNIgEkjPUbB0Wh8eOKfFv6xXnL))
		for HBmVXtdERwka in krYOFaINJBtc1j0CRg2Q3dhmf:
			y1SWlhH7pcEw4sd0kNJb3mGjqQ6[HBmVXtdERwka] = ''
			esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E][HBmVXtdERwka] = []
		Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,60+int(15*oKM0nwyrs2GBC//A5QGHzOSWpmbDKy9B),'تصنيع القوائم','الجزء رقم:-',str(oKM0nwyrs2GBC)+' / '+str(A5QGHzOSWpmbDKy9B))
		if X8bUgFnQeI16CfxSuka7.iscanceled(): return
		oKM0nwyrs2GBC += 1
		YUFyKBVLqv7ZJCloiD1jpWgm5 = len(krYOFaINJBtc1j0CRg2Q3dhmf)
		del krYOFaINJBtc1j0CRg2Q3dhmf
		JJw5K0FdYPLZ3qDm = list(set(zip(qqcNIgEkjPUbB0Wh8eOKfFv6xXnL,VJGAWXUsTyne1iZ)))
		del qqcNIgEkjPUbB0Wh8eOKfFv6xXnL,VJGAWXUsTyne1iZ
		for HBmVXtdERwka,IsMuwXCDji in JJw5K0FdYPLZ3qDm:
			if not y1SWlhH7pcEw4sd0kNJb3mGjqQ6[HBmVXtdERwka] and IsMuwXCDji: y1SWlhH7pcEw4sd0kNJb3mGjqQ6[HBmVXtdERwka] = IsMuwXCDji
		Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,60+int(15*oKM0nwyrs2GBC//A5QGHzOSWpmbDKy9B),'تصنيع القوائم','الجزء رقم:-',str(oKM0nwyrs2GBC)+' / '+str(A5QGHzOSWpmbDKy9B))
		if X8bUgFnQeI16CfxSuka7.iscanceled(): return
		oKM0nwyrs2GBC += 1
		FAD8RBwcqHdK3sMY2W7nCgUutfvG19 = list(y1SWlhH7pcEw4sd0kNJb3mGjqQ6.keys())
		kXvmzJSR81aAf3V7Hy6 = list(y1SWlhH7pcEw4sd0kNJb3mGjqQ6.values())
		del y1SWlhH7pcEw4sd0kNJb3mGjqQ6
		JJw5K0FdYPLZ3qDm = list(zip(FAD8RBwcqHdK3sMY2W7nCgUutfvG19,kXvmzJSR81aAf3V7Hy6))
		del FAD8RBwcqHdK3sMY2W7nCgUutfvG19,kXvmzJSR81aAf3V7Hy6
		JJw5K0FdYPLZ3qDm = sorted(JJw5K0FdYPLZ3qDm)
	else: oKM0nwyrs2GBC += 2
	esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E]['__GROUPS__'] = JJw5K0FdYPLZ3qDm
	del JJw5K0FdYPLZ3qDm
	for HBmVXtdERwka,C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R in rs9vZJxbPqMKmD[L6wOQrDsfy94j8WIg3Kad7E]:
		esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E][HBmVXtdERwka].append((C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R))
	Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,60+int(15*oKM0nwyrs2GBC//A5QGHzOSWpmbDKy9B),'تصنيع القوائم','الجزء رقم:-',str(oKM0nwyrs2GBC)+' / '+str(A5QGHzOSWpmbDKy9B))
	if X8bUgFnQeI16CfxSuka7.iscanceled(): return
	oKM0nwyrs2GBC += 1
	del rs9vZJxbPqMKmD[L6wOQrDsfy94j8WIg3Kad7E]
	tuygpYwFkcJPqb3rhC5n4[L6wOQrDsfy94j8WIg3Kad7E] = list(esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E].keys())
	R16twcrPjd[L6wOQrDsfy94j8WIg3Kad7E] = len(tuygpYwFkcJPqb3rhC5n4[L6wOQrDsfy94j8WIg3Kad7E])
	e67WucsCTYMZbFamBvg1yH5pE += R16twcrPjd[L6wOQrDsfy94j8WIg3Kad7E]
	return
def vK39BDET2RrXQfwPtAkyobpJSl(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E):
	global X8bUgFnQeI16CfxSuka7,rs9vZJxbPqMKmD,zIHx52Ag4qMmN3k6iWlDFwra,esKz2tFvkiSNc,R16twcrPjd,tuygpYwFkcJPqb3rhC5n4,e67WucsCTYMZbFamBvg1yH5pE,oKM0nwyrs2GBC,A5QGHzOSWpmbDKy9B
	KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E)
	for RP8pdTOZKWQev0LGXrzxVhAm in range(1+R16twcrPjd[L6wOQrDsfy94j8WIg3Kad7E]//273):
		JgWePnVcm9xbAjQiSa271 = []
		XIMKrdGUE98WYzohfbBnw0 = tuygpYwFkcJPqb3rhC5n4[L6wOQrDsfy94j8WIg3Kad7E][0:273]
		for HBmVXtdERwka in XIMKrdGUE98WYzohfbBnw0:
			JgWePnVcm9xbAjQiSa271.append(esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E][HBmVXtdERwka])
		mhr0way8dQLUMt6uSIPqGW(KKEFMu8UyqYI,L6wOQrDsfy94j8WIg3Kad7E,XIMKrdGUE98WYzohfbBnw0,JgWePnVcm9xbAjQiSa271,VYn9o683LCcspE7Jew5gMQrZbj,True)
		zIHx52Ag4qMmN3k6iWlDFwra += len(XIMKrdGUE98WYzohfbBnw0)
		Qm8DTfKEUrdMvXzO7(X8bUgFnQeI16CfxSuka7,75+int(20*zIHx52Ag4qMmN3k6iWlDFwra//e67WucsCTYMZbFamBvg1yH5pE),'تخزين القوائم','القائمة رقم:-',str(zIHx52Ag4qMmN3k6iWlDFwra)+' / '+str(e67WucsCTYMZbFamBvg1yH5pE))
		if X8bUgFnQeI16CfxSuka7.iscanceled(): return
		del tuygpYwFkcJPqb3rhC5n4[L6wOQrDsfy94j8WIg3Kad7E][0:273]
	del esKz2tFvkiSNc[L6wOQrDsfy94j8WIg3Kad7E],tuygpYwFkcJPqb3rhC5n4[L6wOQrDsfy94j8WIg3Kad7E],R16twcrPjd[L6wOQrDsfy94j8WIg3Kad7E]
	return
def TyAoZj5puBINz1rwWGf(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt=True):
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt): return
	vLVA6GoJNmFEu = 'رسالة من المبرمج'
	H2tryxbOIj = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,'LIVE_ORIGINAL_GROUPED')
	ZZHdQm3DpNCMEifXVWjSeA5l = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,'VOD_ORIGINAL_GROUPED')
	XX4wH1OUWg = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(H2tryxbOIj,'int','IGNORED','__COUNT__')
	ddTV17GDjegrEF = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(H2tryxbOIj,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	Inaur0EsJ7BUi = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(ZZHdQm3DpNCMEifXVWjSeA5l,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	Gfpj0ZgvWxqBYEFHMsTUo1C3Rd = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(H2tryxbOIj,'int','LIVE_GROUPED','__COUNT__')
	PtpjWOF8KLRerTyfvlaE43S6cXDoG = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(H2tryxbOIj,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	GgX0OQYTnvi1KxN67lwm4Pb = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(H2tryxbOIj,'int','VOD_MOVIES_GROUPED','__COUNT__')
	bby479PQJz = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(ZZHdQm3DpNCMEifXVWjSeA5l,'int','VOD_SERIES_GROUPED','__COUNT__')
	ppThPt3JSLbuHYgC2sqlNWo51x6K = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(H2tryxbOIj,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	tuygpYwFkcJPqb3rhC5n4 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(ZZHdQm3DpNCMEifXVWjSeA5l,'list','VOD_SERIES_GROUPED','__GROUPS__')
	mkMIfgE4hpBnlzu19 = []
	for HBmVXtdERwka,HQ1EncuNLjBOl20R in tuygpYwFkcJPqb3rhC5n4:
		q0ep2UlkdIPCF5icg3RSJmXx = HBmVXtdERwka.split('__SERIES__')[1]
		mkMIfgE4hpBnlzu19.append(q0ep2UlkdIPCF5icg3RSJmXx)
	OpCxBW7lHnIcA9 = len(mkMIfgE4hpBnlzu19)
	VMsYufnCR5HigB2x9P61TUp3bSZjc = int(GgX0OQYTnvi1KxN67lwm4Pb)+int(bby479PQJz)+int(ppThPt3JSLbuHYgC2sqlNWo51x6K)+int(PtpjWOF8KLRerTyfvlaE43S6cXDoG)+int(Gfpj0ZgvWxqBYEFHMsTUo1C3Rd)
	nksm578BUMxuY3SVq2DA64 = ''
	nksm578BUMxuY3SVq2DA64 += 'قنوات: '+str(Gfpj0ZgvWxqBYEFHMsTUo1C3Rd)
	nksm578BUMxuY3SVq2DA64 += '   .   أفلام: '+str(GgX0OQYTnvi1KxN67lwm4Pb)
	nksm578BUMxuY3SVq2DA64 += '\nمسلسلات: '+str(OpCxBW7lHnIcA9)
	nksm578BUMxuY3SVq2DA64 += '   .   حلقات: '+str(bby479PQJz)
	nksm578BUMxuY3SVq2DA64 += '\nقنوات مجهولة: '+str(PtpjWOF8KLRerTyfvlaE43S6cXDoG)
	nksm578BUMxuY3SVq2DA64 += '   .   فيدوهات مجهولة: '+str(ppThPt3JSLbuHYgC2sqlNWo51x6K)
	nksm578BUMxuY3SVq2DA64 += '\nمجموع القنوات: '+str(ddTV17GDjegrEF)
	nksm578BUMxuY3SVq2DA64 += '   .   مجموع الفيديوهات: '+str(Inaur0EsJ7BUi)
	nksm578BUMxuY3SVq2DA64 += '\n\nمجموع المضافة: '+str(VMsYufnCR5HigB2x9P61TUp3bSZjc)
	nksm578BUMxuY3SVq2DA64 += '   .   مجموع المهملة: '+str(XX4wH1OUWg)
	if kpRFrdX4B2iaJxwqcL0IUVt: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('center','',vLVA6GoJNmFEu,nksm578BUMxuY3SVq2DA64)
	K1G2OFhsN40QRlI5peLzYCnfxPM = nksm578BUMxuY3SVq2DA64.replace('\n\n','\n')
	zRM3tZx2v6DjJU('NOTICE','.  Counts of IPTV videos   Folder: '+vknQOmFaRT7sxDcr1zZyNGtBuA+'\n'+K1G2OFhsN40QRlI5peLzYCnfxPM)
	return nksm578BUMxuY3SVq2DA64
def bIXayWVe45Q3(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt=True):
	if kpRFrdX4B2iaJxwqcL0IUVt:
		IjESVoUqQMhdb = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if IjESVoUqQMhdb!=1: return
		EBFI0DK25XJb8CqPj3dscL6w = odmkxW7uBXr.replace('___','_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(EBFI0DK25XJb8CqPj3dscL6w)
		except: pass
	EBFI0DK25XJb8CqPj3dscL6w = zSr9lDgYab76LZRFXNdM3OhJ.replace('___','_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(EBFI0DK25XJb8CqPj3dscL6w)
	except: pass
	EBFI0DK25XJb8CqPj3dscL6w = BFc8ola35nEjJZyxw.replace('___','_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(EBFI0DK25XJb8CqPj3dscL6w)
	except: pass
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'SECTIONS_IPTV','SECTIONS_IPTV_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	tb6VfQWohldXaqIvCYiw(False)
	TTWIS7KUQdAf1ZpCV5HDunGkt8(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if kpRFrdX4B2iaJxwqcL0IUVt:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin('Container.Refresh')
	return
def SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA='',kpRFrdX4B2iaJxwqcL0IUVt=True):
	if vknQOmFaRT7sxDcr1zZyNGtBuA:
		KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(str(vknQOmFaRT7sxDcr1zZyNGtBuA),'DUMMY')
		LLNfYeyZwd6283Ssrol9 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'str','DUMMY','__DUMMY__')
		if LLNfYeyZwd6283Ssrol9: return True
	else:
		vknQOmFaRT7sxDcr1zZyNGtBuA = '1'
		for SJLiAGmdTetOZqEQFD in range(1,nJHx2XSIEFA7+1):
			KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(str(SJLiAGmdTetOZqEQFD),'DUMMY')
			LLNfYeyZwd6283Ssrol9 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'str','DUMMY','__DUMMY__')
			if LLNfYeyZwd6283Ssrol9: return True
	if kpRFrdX4B2iaJxwqcL0IUVt:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  [COLOR FFC89008] \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus [/COLOR]')
		vLVA6GoJNmFEu = 'إضافة وتغيير رابط '+aLDUVmBxsFnM[1]+' (مجلد '+aLDUVmBxsFnM[int(vknQOmFaRT7sxDcr1zZyNGtBuA)]+')'
		IjESVoUqQMhdb = C5JBeSxPzuskXi1ROnMHAmWp06dE7('','','',vLVA6GoJNmFEu,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if IjESVoUqQMhdb==1: LLFAGKJgjb1Iva50hPRdZ4(vknQOmFaRT7sxDcr1zZyNGtBuA)
	return False
def oThr70M9BuSwHkalZ6sV5tUyFNiW(zMtQjrZK7pPYRLlvCJG1mTV8Dy,vknQOmFaRT7sxDcr1zZyNGtBuA='',L6wOQrDsfy94j8WIg3Kad7E='',NAeOBpCIyH4FrQqMaXv1ziG8kWU=''):
	if not NAeOBpCIyH4FrQqMaXv1ziG8kWU: NAeOBpCIyH4FrQqMaXv1ziG8kWU = '1'
	ddXzLfOuFHBetSC,W7d5UaTJVnySIM6OQ3fXi,kpRFrdX4B2iaJxwqcL0IUVt = Gq9cSoCJU2p1e3T4MFkdWQvuD(zMtQjrZK7pPYRLlvCJG1mTV8Dy)
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt): return
	if not ddXzLfOuFHBetSC:
		ddXzLfOuFHBetSC = wod1HJ0fnvcTNAX2WIiMu9P()
		if not ddXzLfOuFHBetSC: return
	sS2EvpVNWH7tK6cw5zTfg1YICMyU = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not L6wOQrDsfy94j8WIg3Kad7E:
		if not kpRFrdX4B2iaJxwqcL0IUVt:
			if   '_IPTV-LIVE_' in W7d5UaTJVnySIM6OQ3fXi: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[1]
			elif '_IPTV-MOVIES' in W7d5UaTJVnySIM6OQ3fXi: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[2]
			elif '_IPTV-SERIES' in W7d5UaTJVnySIM6OQ3fXi: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[3]
			else: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[0]
		else:
			gg8D9uWNVa0Xt6LnAYSZFsCUE2pJ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			Df3p8YoF4GVj1bShqTQk5z0Wn = ISveRUGKjgM9wqL6FZpsku0bB('أختر البحث المناسب', gg8D9uWNVa0Xt6LnAYSZFsCUE2pJ)
			if Df3p8YoF4GVj1bShqTQk5z0Wn==-1: return
			L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[Df3p8YoF4GVj1bShqTQk5z0Wn]
	ddXzLfOuFHBetSC = ddXzLfOuFHBetSC+'_NODIALOGS_'
	if vknQOmFaRT7sxDcr1zZyNGtBuA: Vtu3IopGiTP7mwfSRQOB(ddXzLfOuFHBetSC,vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E,NAeOBpCIyH4FrQqMaXv1ziG8kWU)
	else:
		for vknQOmFaRT7sxDcr1zZyNGtBuA in range(1,nJHx2XSIEFA7+1):
			Vtu3IopGiTP7mwfSRQOB(ddXzLfOuFHBetSC,str(vknQOmFaRT7sxDcr1zZyNGtBuA),L6wOQrDsfy94j8WIg3Kad7E,NAeOBpCIyH4FrQqMaXv1ziG8kWU)
		vvruH9wsBDfbhFtyq1MUd2zV[:] = sorted(vvruH9wsBDfbhFtyq1MUd2zV,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f[1].lower())
	return
def Vtu3IopGiTP7mwfSRQOB(zMtQjrZK7pPYRLlvCJG1mTV8Dy,vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E='',NAeOBpCIyH4FrQqMaXv1ziG8kWU=''):
	if not NAeOBpCIyH4FrQqMaXv1ziG8kWU: NAeOBpCIyH4FrQqMaXv1ziG8kWU = '1'
	ddXzLfOuFHBetSC,W7d5UaTJVnySIM6OQ3fXi,kpRFrdX4B2iaJxwqcL0IUVt = Gq9cSoCJU2p1e3T4MFkdWQvuD(zMtQjrZK7pPYRLlvCJG1mTV8Dy)
	if not vknQOmFaRT7sxDcr1zZyNGtBuA: return
	if not SSk6jtbsXxMo09lNiaVp4T(vknQOmFaRT7sxDcr1zZyNGtBuA,kpRFrdX4B2iaJxwqcL0IUVt): return
	if not ddXzLfOuFHBetSC:
		ddXzLfOuFHBetSC = wod1HJ0fnvcTNAX2WIiMu9P()
		if not ddXzLfOuFHBetSC: return
	sS2EvpVNWH7tK6cw5zTfg1YICMyU = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not L6wOQrDsfy94j8WIg3Kad7E:
		if not kpRFrdX4B2iaJxwqcL0IUVt:
			if   '_IPTV-LIVE_' in W7d5UaTJVnySIM6OQ3fXi: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[1]
			elif '_IPTV-MOVIES' in W7d5UaTJVnySIM6OQ3fXi: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[2]
			elif '_IPTV-SERIES' in W7d5UaTJVnySIM6OQ3fXi: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[3]
			else: L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[0]
		else:
			gg8D9uWNVa0Xt6LnAYSZFsCUE2pJ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			Df3p8YoF4GVj1bShqTQk5z0Wn = ISveRUGKjgM9wqL6FZpsku0bB('أختر البحث المناسب', gg8D9uWNVa0Xt6LnAYSZFsCUE2pJ)
			if Df3p8YoF4GVj1bShqTQk5z0Wn==-1: return
			L6wOQrDsfy94j8WIg3Kad7E = sS2EvpVNWH7tK6cw5zTfg1YICMyU[Df3p8YoF4GVj1bShqTQk5z0Wn]
	obN5dCDq9tUi = ddXzLfOuFHBetSC.lower()
	KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,'SEARCH')
	X8M3EvbVAIGCNpgU7 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'list','SEARCH',(L6wOQrDsfy94j8WIg3Kad7E,obN5dCDq9tUi))
	if not X8M3EvbVAIGCNpgU7:
		XaKklde1oiv59f,Oh8ZL49UGIjP0l2 = [],[]
		if not L6wOQrDsfy94j8WIg3Kad7E: L0botZrCNqGxiPOf7ca = [1,2,3,4,5]
		else: L0botZrCNqGxiPOf7ca = [sS2EvpVNWH7tK6cw5zTfg1YICMyU.index(L6wOQrDsfy94j8WIg3Kad7E)]
		for gI689nKoH2PlifU3AMW5vVEZpFYX1 in L0botZrCNqGxiPOf7ca:
			KKEFMu8UyqYI = filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,sS2EvpVNWH7tK6cw5zTfg1YICMyU[gI689nKoH2PlifU3AMW5vVEZpFYX1])
			if gI689nKoH2PlifU3AMW5vVEZpFYX1!=3:
				aatNAwDZOBf1Co2MPdRm8v5sEzxKIh = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'dict',sS2EvpVNWH7tK6cw5zTfg1YICMyU[gI689nKoH2PlifU3AMW5vVEZpFYX1])
				del aatNAwDZOBf1Co2MPdRm8v5sEzxKIh['__COUNT__']
				del aatNAwDZOBf1Co2MPdRm8v5sEzxKIh['__GROUPS__']
				del aatNAwDZOBf1Co2MPdRm8v5sEzxKIh['__SEQUENCED_COLUMNS__']
				tuygpYwFkcJPqb3rhC5n4 = list(aatNAwDZOBf1Co2MPdRm8v5sEzxKIh.keys())
				for HBmVXtdERwka in tuygpYwFkcJPqb3rhC5n4:
					for C32AEk8uZTeFPI94LG6dmczv,d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R in aatNAwDZOBf1Co2MPdRm8v5sEzxKIh[HBmVXtdERwka]:
						if obN5dCDq9tUi in d8HBf4W3rvEaUYZSFlszD7qXOnk.lower(): Oh8ZL49UGIjP0l2.append((d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R))
					del aatNAwDZOBf1Co2MPdRm8v5sEzxKIh[HBmVXtdERwka]
				del aatNAwDZOBf1Co2MPdRm8v5sEzxKIh
			else: tuygpYwFkcJPqb3rhC5n4 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(KKEFMu8UyqYI,'list',sS2EvpVNWH7tK6cw5zTfg1YICMyU[gI689nKoH2PlifU3AMW5vVEZpFYX1],'__GROUPS__')
			for HBmVXtdERwka in tuygpYwFkcJPqb3rhC5n4:
				try: HBmVXtdERwka,HQ1EncuNLjBOl20R = HBmVXtdERwka
				except: HQ1EncuNLjBOl20R = ''
				if obN5dCDq9tUi in HBmVXtdERwka.lower():
					if gI689nKoH2PlifU3AMW5vVEZpFYX1!=3: pVrqRlC1EXc3I6s2W = HBmVXtdERwka
					else:
						R0LaiTg5XePmnz34BSxO6wftVsKCJ,KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ = HBmVXtdERwka.split('__SERIES__')
						if obN5dCDq9tUi in R0LaiTg5XePmnz34BSxO6wftVsKCJ.lower(): pVrqRlC1EXc3I6s2W = R0LaiTg5XePmnz34BSxO6wftVsKCJ
						else: pVrqRlC1EXc3I6s2W = KKXdoVbe5TsU8zvi4PQCLwJltcxpHZ
					XaKklde1oiv59f.append((HBmVXtdERwka,pVrqRlC1EXc3I6s2W,sS2EvpVNWH7tK6cw5zTfg1YICMyU[gI689nKoH2PlifU3AMW5vVEZpFYX1],HQ1EncuNLjBOl20R))
			del tuygpYwFkcJPqb3rhC5n4
		XaKklde1oiv59f = set(XaKklde1oiv59f)
		Oh8ZL49UGIjP0l2 = set(Oh8ZL49UGIjP0l2)
		XaKklde1oiv59f = sorted(XaKklde1oiv59f,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f[1])
		Oh8ZL49UGIjP0l2 = sorted(Oh8ZL49UGIjP0l2,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f[0])
		mhr0way8dQLUMt6uSIPqGW(KKEFMu8UyqYI,'SEARCH',(L6wOQrDsfy94j8WIg3Kad7E,obN5dCDq9tUi),(XaKklde1oiv59f,Oh8ZL49UGIjP0l2),VYn9o683LCcspE7Jew5gMQrZbj)
	else: XaKklde1oiv59f,Oh8ZL49UGIjP0l2 = X8M3EvbVAIGCNpgU7
	tuygpYwFkcJPqb3rhC5n4 = len(XaKklde1oiv59f)
	xRHmVlaI6ZQinTpS5L21DUKMrYj = len(Oh8ZL49UGIjP0l2)
	zt1qZvA74HunVPWCON = int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)
	rIqAEFJKQDiWgztvXoGfd9 = max(0,(zt1qZvA74HunVPWCON-1)*100)
	DDeCLIzowtqNpBP81fubQkXU0Vy5 = max(0,zt1qZvA74HunVPWCON*100)
	DirhMLbIC3SNlV = max(0,rIqAEFJKQDiWgztvXoGfd9-tuygpYwFkcJPqb3rhC5n4)
	U8UZBHeriVLbdFmTRh = max(0,DDeCLIzowtqNpBP81fubQkXU0Vy5-tuygpYwFkcJPqb3rhC5n4)
	for HBmVXtdERwka,pVrqRlC1EXc3I6s2W,JGntYoNcqdvIRQ7,HQ1EncuNLjBOl20R in XaKklde1oiv59f[rIqAEFJKQDiWgztvXoGfd9:DDeCLIzowtqNpBP81fubQkXU0Vy5]:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+pVrqRlC1EXc3I6s2W,JGntYoNcqdvIRQ7,234,HQ1EncuNLjBOl20R,'1',HBmVXtdERwka,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	del XaKklde1oiv59f
	for d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,HQ1EncuNLjBOl20R in Oh8ZL49UGIjP0l2[DirhMLbIC3SNlV:U8UZBHeriVLbdFmTRh]:
		sI81YLbyXznqxBOcp = H93DlbtKLEarfQ8w7GcoIukSexv0J(HbqSfZ6m7FAa)
		ghLJETx5pD7 = 'live'
		if '.mkv' in sI81YLbyXznqxBOcp or 'VOD' in L6wOQrDsfy94j8WIg3Kad7E: ghLJETx5pD7 = 'video'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB(ghLJETx5pD7,lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,235,HQ1EncuNLjBOl20R,'','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	del Oh8ZL49UGIjP0l2
	y19z2fNAKaLtDvpguQI6sBPX7R(vknQOmFaRT7sxDcr1zZyNGtBuA,NAeOBpCIyH4FrQqMaXv1ziG8kWU,L6wOQrDsfy94j8WIg3Kad7E,239,tuygpYwFkcJPqb3rhC5n4+xRHmVlaI6ZQinTpS5L21DUKMrYj,ddXzLfOuFHBetSC+'_NODIALOGS_')
	return
def y19z2fNAKaLtDvpguQI6sBPX7R(vknQOmFaRT7sxDcr1zZyNGtBuA,NAeOBpCIyH4FrQqMaXv1ziG8kWU,L6wOQrDsfy94j8WIg3Kad7E,Q6FbqZ9uIe8v2xaTHhfDCJ,VMsYufnCR5HigB2x9P61TUp3bSZjc,OO1XlVPzfQrMTmJv):
	if NAeOBpCIyH4FrQqMaXv1ziG8kWU!='1': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'صفحة '+str(1),L6wOQrDsfy94j8WIg3Kad7E,Q6FbqZ9uIe8v2xaTHhfDCJ,'',str(1),OO1XlVPzfQrMTmJv,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	if not VMsYufnCR5HigB2x9P61TUp3bSZjc: VMsYufnCR5HigB2x9P61TUp3bSZjc = 0
	PPqN2LHseCo8zEdm5ISW46 = int(VMsYufnCR5HigB2x9P61TUp3bSZjc/100)+1
	for zt1qZvA74HunVPWCON in range(2,PPqN2LHseCo8zEdm5ISW46):
		l5hSqMoaeTCJyW3t9 = (zt1qZvA74HunVPWCON%10==0 or int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)-4<zt1qZvA74HunVPWCON<int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)+4)
		bbfPJh67IHZ = (l5hSqMoaeTCJyW3t9 and int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)-40<zt1qZvA74HunVPWCON<int(NAeOBpCIyH4FrQqMaXv1ziG8kWU)+40)
		if str(zt1qZvA74HunVPWCON)!=NAeOBpCIyH4FrQqMaXv1ziG8kWU and (zt1qZvA74HunVPWCON%100==0 or bbfPJh67IHZ):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'صفحة '+str(zt1qZvA74HunVPWCON),L6wOQrDsfy94j8WIg3Kad7E,Q6FbqZ9uIe8v2xaTHhfDCJ,'',str(zt1qZvA74HunVPWCON),OO1XlVPzfQrMTmJv,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	if str(PPqN2LHseCo8zEdm5ISW46)!=NAeOBpCIyH4FrQqMaXv1ziG8kWU: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+'أخر صفحة '+str(PPqN2LHseCo8zEdm5ISW46),L6wOQrDsfy94j8WIg3Kad7E,Q6FbqZ9uIe8v2xaTHhfDCJ,'',str(PPqN2LHseCo8zEdm5ISW46),OO1XlVPzfQrMTmJv,'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	return
def filZkpPgIX3wmxTaeK4UtWOYq(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E):
	if 'SERIES' in L6wOQrDsfy94j8WIg3Kad7E or 'VOD_ORIGINAL' in L6wOQrDsfy94j8WIg3Kad7E: KKEFMu8UyqYI = BFc8ola35nEjJZyxw
	else: KKEFMu8UyqYI = zSr9lDgYab76LZRFXNdM3OhJ
	KKEFMu8UyqYI = KKEFMu8UyqYI.replace('___','_'+vknQOmFaRT7sxDcr1zZyNGtBuA)
	return KKEFMu8UyqYI
def nomqb0d1hBM(vknQOmFaRT7sxDcr1zZyNGtBuA,L6wOQrDsfy94j8WIg3Kad7E,nkl2zvWBtHT5u03c1soePYIZdQqbK):
	RRVsEiIu9efhz,wwPhbdD6GL52AygQWFIHmp,j4bsZF9S25q1VGECt,UU8oBeXhQstYkGfx2cTyOHZS6bmR,CzjoN98nk0 = PALIf97ew3T0JispFkK(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if not UU8oBeXhQstYkGfx2cTyOHZS6bmR: return
	JWZYMU9luoKCAD7ybSBQ = WXx8yidSJvbDE(vknQOmFaRT7sxDcr1zZyNGtBuA)
	if   L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_LIVE_GROUPS': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_live_categories'
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_VOD_GROUPS': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_vod_categories'
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_SERIES_GROUPS': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_series_categories'
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_LIVE_ITEMS': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_live_streams&category_id='+nkl2zvWBtHT5u03c1soePYIZdQqbK
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_VOD_ITEMS': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_vod_streams&category_id='+nkl2zvWBtHT5u03c1soePYIZdQqbK
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_SERIES_ITEMS': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_series&category_id='+nkl2zvWBtHT5u03c1soePYIZdQqbK
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_EPISODES': HbqSfZ6m7FAa = RRVsEiIu9efhz+'&action=get_series_info&series_id='+nkl2zvWBtHT5u03c1soePYIZdQqbK
	else: return
	vqUSBHDtn5Rl6Vyc8 = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',HbqSfZ6m7FAa,'',JWZYMU9luoKCAD7ybSBQ,'','','IPTV-XTREAM_MENUS-1st')
	F3FUSpn5ZHPu6iwQ1sr8 = vqUSBHDtn5Rl6Vyc8.content
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: F3FUSpn5ZHPu6iwQ1sr8 = F3FUSpn5ZHPu6iwQ1sr8.decode('utf8').encode('utf8')
	XVwBts637Gdp = kMLWTt2fO9dnGDUgHh('list',F3FUSpn5ZHPu6iwQ1sr8)
	if 'GROUPS' in L6wOQrDsfy94j8WIg3Kad7E:
		L6wOQrDsfy94j8WIg3Kad7E = L6wOQrDsfy94j8WIg3Kad7E.replace('_GROUPS','_ITEMS')
		XVwBts637Gdp = sorted(XVwBts637Gdp,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f['category_name'].lower())
		for HBmVXtdERwka in XVwBts637Gdp:
			djhgfYocH7rCwWspxeNGv = HBmVXtdERwka['category_id']
			d8HBf4W3rvEaUYZSFlszD7qXOnk = HBmVXtdERwka['category_name']
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,L6wOQrDsfy94j8WIg3Kad7E,285,'','',str(djhgfYocH7rCwWspxeNGv),'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_SERIES_ITEMS':
		XVwBts637Gdp = sorted(XVwBts637Gdp,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f['name'].lower())
		for vC8BJqTFDlx2VQoLeXkO1IU in XVwBts637Gdp:
			d8HBf4W3rvEaUYZSFlszD7qXOnk = vC8BJqTFDlx2VQoLeXkO1IU['name']
			IsMuwXCDji = vC8BJqTFDlx2VQoLeXkO1IU['cover']
			djhgfYocH7rCwWspxeNGv = vC8BJqTFDlx2VQoLeXkO1IU['series_id']
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,'XTREAM_EPISODES',285,IsMuwXCDji,'',str(djhgfYocH7rCwWspxeNGv),'',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	elif L6wOQrDsfy94j8WIg3Kad7E=='XTREAM_EPISODES':
		IsMuwXCDji = XVwBts637Gdp['info']['cover']
		pphVUbJkGtHXndg84iZl2DPImSzoC = XVwBts637Gdp['info']['name']
		E6oW1AFT3UHpO5any0wXZKVceirxQ = XVwBts637Gdp['episodes']
		for nnOfS0PgEi in E6oW1AFT3UHpO5any0wXZKVceirxQ:
			gl40cDiTzZxb3tjQa76Ao2H = E6oW1AFT3UHpO5any0wXZKVceirxQ[nnOfS0PgEi]
			for VzldOutrHBEXFgy5fQSw1D0sC in gl40cDiTzZxb3tjQa76Ao2H:
				d8HBf4W3rvEaUYZSFlszD7qXOnk = VzldOutrHBEXFgy5fQSw1D0sC['title']
				m1cP9L8ilAIHnaJUR4K = QPuHKNAT4jmCRg.findall('\d+.(S\d+E\d+)',d8HBf4W3rvEaUYZSFlszD7qXOnk,QPuHKNAT4jmCRg.DOTALL)
				if m1cP9L8ilAIHnaJUR4K: d8HBf4W3rvEaUYZSFlszD7qXOnk = pphVUbJkGtHXndg84iZl2DPImSzoC+' '+m1cP9L8ilAIHnaJUR4K[0]
				djhgfYocH7rCwWspxeNGv = VzldOutrHBEXFgy5fQSw1D0sC['id']
				yyNxfahAGK = VzldOutrHBEXFgy5fQSw1D0sC['container_extension']
				HbqSfZ6m7FAa = RRVsEiIu9efhz.split('/player_api.php')[0]+'/series/'+UU8oBeXhQstYkGfx2cTyOHZS6bmR+'/'+CzjoN98nk0+'/'+str(djhgfYocH7rCwWspxeNGv)+'.'+yyNxfahAGK
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,235,IsMuwXCDji,'','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	elif 'ITEMS' in L6wOQrDsfy94j8WIg3Kad7E:
		ghLJETx5pD7 = 'live' if 'LIVE' in L6wOQrDsfy94j8WIg3Kad7E else 'video'
		XVwBts637Gdp = sorted(XVwBts637Gdp,reverse=False,key=lambda yChXl3AKe7H9f: yChXl3AKe7H9f['name'].lower())
		for c2tX1kDGxsVhWQFI3BOPR86 in XVwBts637Gdp:
			d8HBf4W3rvEaUYZSFlszD7qXOnk = c2tX1kDGxsVhWQFI3BOPR86['name']
			IsMuwXCDji = c2tX1kDGxsVhWQFI3BOPR86['stream_icon']
			djhgfYocH7rCwWspxeNGv = c2tX1kDGxsVhWQFI3BOPR86['stream_id']
			try:
				yyNxfahAGK = c2tX1kDGxsVhWQFI3BOPR86['container_extension']
				if yyNxfahAGK: yyNxfahAGK = '.'+yyNxfahAGK
			except: yyNxfahAGK = ''
			if c2tX1kDGxsVhWQFI3BOPR86['stream_type']=='live': FFwS70Nu21yMzvlHxKcQ,R3imrnlDodZP76e = '','live'
			elif c2tX1kDGxsVhWQFI3BOPR86['stream_type']=='movie': FFwS70Nu21yMzvlHxKcQ,R3imrnlDodZP76e = 'movie/','video'
			HbqSfZ6m7FAa = RRVsEiIu9efhz.split('/player_api.php')[0]+'/'+FFwS70Nu21yMzvlHxKcQ+UU8oBeXhQstYkGfx2cTyOHZS6bmR+'/'+CzjoN98nk0+'/'+str(djhgfYocH7rCwWspxeNGv)+yyNxfahAGK
			fpjEiKI9bTc1xhoeq37vPusDJ6SB(ghLJETx5pD7,lCfDqYvaRW+d8HBf4W3rvEaUYZSFlszD7qXOnk,HbqSfZ6m7FAa,235,IsMuwXCDji,'','','',{'folder':vknQOmFaRT7sxDcr1zZyNGtBuA})
	return
def TTWIS7KUQdAf1ZpCV5HDunGkt8(vknQOmFaRT7sxDcr1zZyNGtBuA):
	wZja8s9exBG3HOyn1Ju2vSkqDdQ = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.provider')
	LGivCYufsSNw0qmdjxEFXKDR3UlM4 = fQ6kvwg1FrYAzXjbLT.getSetting('av.language.code')
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'MENUS_CACHE_'+wZja8s9exBG3HOyn1Ju2vSkqDdQ+'_'+LGivCYufsSNw0qmdjxEFXKDR3UlM4,'%_IP'+vknQOmFaRT7sxDcr1zZyNGtBuA+'_%')
	return
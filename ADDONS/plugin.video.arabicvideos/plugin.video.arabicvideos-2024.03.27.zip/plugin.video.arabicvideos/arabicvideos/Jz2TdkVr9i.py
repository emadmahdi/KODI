# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'ALFATIMI'
JE7QrkmhletLwA0OZXu = '_FTM_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
JxyU35SIZMQLiBKGpo2n9 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
jjln0zBmgwQiXf4Y = ['3030','628']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==60: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==61: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==62: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==63: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==64: RRMWBwU6pG = bbwVAeIloCfY(text)
	elif mode==69: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'ما يتم مشاهدته الان',GqcEfFR8XQPgBMLr,64,'','','recent_viewed_vids')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الاكثر مشاهدة',GqcEfFR8XQPgBMLr,64,'','','most_viewed_vids')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'اضيفت مؤخرا',GqcEfFR8XQPgBMLr,64,'','','recently_added_vids')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'فيديو عشوائي',GqcEfFR8XQPgBMLr,64,'','','random_vids')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'افلام ومسلسلات',GqcEfFR8XQPgBMLr,61,'','','-1')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'البرامج الدينية',GqcEfFR8XQPgBMLr,61,'','','-2')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'English Videos',GqcEfFR8XQPgBMLr,61,'','','-3')
	return ''
def SPFl6UGK4mrBua(url,jsEpRxQH76):
	K9K6a4Tj7iUc0ugNstIrdzJVQqf5 = ''
	if jsEpRxQH76 not in ['-1','-2','-3']: K9K6a4Tj7iUc0ugNstIrdzJVQqf5 = '?cat='+jsEpRxQH76
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+'/menu_level.php'+K9K6a4Tj7iUc0ugNstIrdzJVQqf5
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','ALFATIMI-TITLES-1st')
	items = QPuHKNAT4jmCRg.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	XS1aVgwF48tcvx2,VV7garqCfPMlbZTnzymGs946B = False,False
	for VV7yf2htDCBU6EeSX8TJQM,title,count in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		title = title.strip(' ')
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
		K9K6a4Tj7iUc0ugNstIrdzJVQqf5 = QPuHKNAT4jmCRg.findall('cat=(.*?)&',VV7yf2htDCBU6EeSX8TJQM,QPuHKNAT4jmCRg.DOTALL)[0]
		if jsEpRxQH76==K9K6a4Tj7iUc0ugNstIrdzJVQqf5: XS1aVgwF48tcvx2 = True
		elif XS1aVgwF48tcvx2 	or (jsEpRxQH76=='-1' and K9K6a4Tj7iUc0ugNstIrdzJVQqf5 in JxyU35SIZMQLiBKGpo2n9)  						or (jsEpRxQH76=='-2' and K9K6a4Tj7iUc0ugNstIrdzJVQqf5 not in jjln0zBmgwQiXf4Y and K9K6a4Tj7iUc0ugNstIrdzJVQqf5 not in JxyU35SIZMQLiBKGpo2n9)  						or (jsEpRxQH76=='-3' and K9K6a4Tj7iUc0ugNstIrdzJVQqf5 in jjln0zBmgwQiXf4Y):
							if count=='1': fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,63)
							else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,61,'','',K9K6a4Tj7iUc0ugNstIrdzJVQqf5)
							VV7garqCfPMlbZTnzymGs946B = True
	if not VV7garqCfPMlbZTnzymGs946B: opLlxOB2dUVZ5JF4j(url)
	return
def opLlxOB2dUVZ5JF4j(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','',True,'ALFATIMI-EPISODES-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('pagination(.*?)id="footer',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	VV7yf2htDCBU6EeSX8TJQM = ''
	for G2WR0Oacvdq8ZQTjKboDU,title,VV7yf2htDCBU6EeSX8TJQM in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,63,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb=QPuHKNAT4jmCRg.findall('(.*?)div',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed=TTCRYZroizb[0]
	wltPGJcYo12Ed=QPuHKNAT4jmCRg.findall('pagination(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	items=QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.split('?')[0]
	for VV7yf2htDCBU6EeSX8TJQM,MtNlbVreA4UswLKIiBa9fQ in items:
		VV7yf2htDCBU6EeSX8TJQM = lZqkuhgaBHSVX8NItKG05cdLJe7Ao + VV7yf2htDCBU6EeSX8TJQM
		title = UH1IuvwM9e4cl7if63nNdozJFSj(MtNlbVreA4UswLKIiBa9fQ)
		title = 'صفحة ' + title
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,62)
	return VV7yf2htDCBU6EeSX8TJQM
def unQmcpAEF2DaNX87fTgMW(url):
	if 'videos.php' in url: url = opLlxOB2dUVZ5JF4j(url)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'','',True,'ALFATIMI-PLAY-1st')
	items = QPuHKNAT4jmCRg.findall('playlistfile:"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	zT3xJQIVDmCgapBljs(url,mm5vCBc4DOz2Fj,'video')
	return
def bbwVAeIloCfY(jsEpRxQH76):
	E9ODYnfpm54GJTd2xRrV = { 'mode' : jsEpRxQH76 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = YZpVhcRlPs3n0FrD(E9ODYnfpm54GJTd2xRrV)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(oXSZ6AEbPukBvwKmyarstdWR5qz0,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
		title = title.strip(' ')
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,63,G2WR0Oacvdq8ZQTjKboDU)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr + '/search_result.php?query=' + Unr6jRmMIv80lSGbkBCehpaWAdV
	opLlxOB2dUVZ5JF4j(url)
	return
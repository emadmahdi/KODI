# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'YOUTUBE'
JE7QrkmhletLwA0OZXu = '_YUT_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
mGbScjqdeVlMDCJpnI0U = 0
def hLD0mk9HIuPOz7pw(mode,url,text,type,YSTbrKgPf7NyhIDizB,name,KKcFOCmYRENepQnxi):
	if	 mode==140: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==141: RRMWBwU6pG = jjkCryP1BxGYvmTI7V0S8QuLXdKZg(url,name,KKcFOCmYRENepQnxi)
	elif mode==143: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url,type)
	elif mode==144: RRMWBwU6pG = SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB,text)
	elif mode==145: RRMWBwU6pG = NhVHcnMi2ol3LrjmA8d4t9YUaDF1(url,YSTbrKgPf7NyhIDizB)
	elif mode==147: RRMWBwU6pG = N9kU2Sslw3gmpWOb6oaLF()
	elif mode==148: RRMWBwU6pG = hhatoMULjG0pHnXs()
	elif mode==149: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	if 0:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'قائمة',GqcEfFR8XQPgBMLr+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'شخص',GqcEfFR8XQPgBMLr+'/user/TCNofficial',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'موقع',GqcEfFR8XQPgBMLr+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'حساب',GqcEfFR8XQPgBMLr+'/@TheSocialCTV',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'العاب',GqcEfFR8XQPgBMLr+'/gaming',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'افلام',GqcEfFR8XQPgBMLr+'/feed/storefront',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مختارات',GqcEfFR8XQPgBMLr+'/feed/guide_builder',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'قصيرة',GqcEfFR8XQPgBMLr+'/shorts',144,'','','_REMEMBERRESULTS_')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'تصفح',GqcEfFR8XQPgBMLr+'/youtubei/v1/guide?key=',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'رئيسية',GqcEfFR8XQPgBMLr+'',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'رائج',GqcEfFR8XQPgBMLr+'/feed/trending?bp=',144)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الرئيسية',GqcEfFR8XQPgBMLr+'',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الرائجة',GqcEfFR8XQPgBMLr+'/feed/trending',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'التصفح',GqcEfFR8XQPgBMLr+'/youtubei/v1/guide?key=',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'القصيرة',GqcEfFR8XQPgBMLr+'/shorts',144,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مختارات يوتيوب',GqcEfFR8XQPgBMLr+'/feed/guide_builder',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مختارات البرنامج','',290)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: قنوات عربية','',147)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: قنوات أجنبية','',148)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: افلام عربية',GqcEfFR8XQPgBMLr+'/results?search_query=فيلم',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: افلام اجنبية',GqcEfFR8XQPgBMLr+'/results?search_query=movie',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: مسرحيات عربية',GqcEfFR8XQPgBMLr+'/results?search_query=مسرحية',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: مسلسلات عربية',GqcEfFR8XQPgBMLr+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: مسلسلات اجنبية',GqcEfFR8XQPgBMLr+'/results?search_query=series&sp=EgIQAw==',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: مسلسلات كارتون',GqcEfFR8XQPgBMLr+'/results?search_query=كارتون&sp=EgIQAw==',144)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث: خطبة المرجعية',GqcEfFR8XQPgBMLr+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def jjkCryP1BxGYvmTI7V0S8QuLXdKZg(url,name,KKcFOCmYRENepQnxi):
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'CHNL:  '+name,url,144,KKcFOCmYRENepQnxi)
	return
def N9kU2Sslw3gmpWOb6oaLF():
	SPFl6UGK4mrBua(GqcEfFR8XQPgBMLr+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def hhatoMULjG0pHnXs():
	SPFl6UGK4mrBua(GqcEfFR8XQPgBMLr+'/results?search_query=tv&sp=EgJAAQ==')
	return
def unQmcpAEF2DaNX87fTgMW(url,type):
	url = url.split('&',1)[0]
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP([url],mm5vCBc4DOz2Fj,type,url)
	return
def LDtdYlyPb4fKuIq6SCzahi1Tr(mt2wxKaGcp7Vy,url,A1pJYqSia7V4wKMnuvLe30QbrkGj):
	level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = A1pJYqSia7V4wKMnuvLe30QbrkGj.split('::')
	kNhfueKQUPm06lMv74,XS9CPAHQF1 = [],[]
	if '/youtubei/v1/browse' in url: kNhfueKQUPm06lMv74.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: kNhfueKQUPm06lMv74.append("yccc['onResponseReceivedCommands']")
	if level=='1': kNhfueKQUPm06lMv74.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	kNhfueKQUPm06lMv74.append("yccc['entries']")
	kNhfueKQUPm06lMv74.append("yccc['items'][3]['guideSectionRenderer']['items']")
	OsmBcN6paE7YogAuRyIGl5SKd,qSwomWuMO9hEjbQz1Hx5TsIYc2Up,KK1twgJxmr = a78zgfX26Oym(mt2wxKaGcp7Vy,'',kNhfueKQUPm06lMv74)
	if level=='1' and OsmBcN6paE7YogAuRyIGl5SKd:
		if len(qSwomWuMO9hEjbQz1Hx5TsIYc2Up)>1 and 'search_query' not in url:
			for EZNqlULKjPXaeJDBFdpsrAh in range(len(qSwomWuMO9hEjbQz1Hx5TsIYc2Up)):
				ZU49hbI8XPt2sm7zrqTBpSw3JE0 = str(EZNqlULKjPXaeJDBFdpsrAh)
				kNhfueKQUPm06lMv74 = []
				kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['reloadContinuationItemsCommand']['continuationItems']")
				kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['command']")
				kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]")
				BcMl3XdLS0zmK1jPvDJANfYH,F5o1sgcqZVlS,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(qSwomWuMO9hEjbQz1Hx5TsIYc2Up,'',kNhfueKQUPm06lMv74)
				if BcMl3XdLS0zmK1jPvDJANfYH: XS9CPAHQF1.append([F5o1sgcqZVlS,url,'2::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::0::0'])
			kNhfueKQUPm06lMv74.append("yccc['continuationEndpoint']")
			BcMl3XdLS0zmK1jPvDJANfYH,F5o1sgcqZVlS,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(mt2wxKaGcp7Vy,'',kNhfueKQUPm06lMv74)
			if BcMl3XdLS0zmK1jPvDJANfYH and XS9CPAHQF1 and 'continuationCommand' in list(F5o1sgcqZVlS.keys()):
				VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/my_main_page_shorts_link'
				XS9CPAHQF1.append([F5o1sgcqZVlS,VV7yf2htDCBU6EeSX8TJQM,'1::0::0::0'])
	return qSwomWuMO9hEjbQz1Hx5TsIYc2Up,OsmBcN6paE7YogAuRyIGl5SKd,XS9CPAHQF1,KK1twgJxmr
def DVg9mK2be86BzC5aNLx4U(mt2wxKaGcp7Vy,qSwomWuMO9hEjbQz1Hx5TsIYc2Up,url,A1pJYqSia7V4wKMnuvLe30QbrkGj):
	level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = A1pJYqSia7V4wKMnuvLe30QbrkGj.split('::')
	kNhfueKQUPm06lMv74,Yn1Xht82owgc4dvP6jDGEJCyeURxbf = [],[]
	kNhfueKQUPm06lMv74.append("yddd[0]['itemSectionRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['reloadContinuationItemsCommand']['continuationItems']")
	kNhfueKQUPm06lMv74.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: kNhfueKQUPm06lMv74.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: kNhfueKQUPm06lMv74.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yddd["+ZU49hbI8XPt2sm7zrqTBpSw3JE0+"]")
	iDIdhpOaVsbPjft79kuF,OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,lSEqRLrVHtvX67801U = a78zgfX26Oym(qSwomWuMO9hEjbQz1Hx5TsIYc2Up,'',kNhfueKQUPm06lMv74)
	if level=='2' and iDIdhpOaVsbPjft79kuF:
		if len(OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar)>1:
			for EZNqlULKjPXaeJDBFdpsrAh in range(len(OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar)):
				qc8aUVGwZfi3MX = str(EZNqlULKjPXaeJDBFdpsrAh)
				kNhfueKQUPm06lMv74 = []
				kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['richSectionRenderer']['content']")
				kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]")
				kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['richItemRenderer']['content']")
				kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]")
				BcMl3XdLS0zmK1jPvDJANfYH,F5o1sgcqZVlS,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,'',kNhfueKQUPm06lMv74)
				if BcMl3XdLS0zmK1jPvDJANfYH: Yn1Xht82owgc4dvP6jDGEJCyeURxbf.append([F5o1sgcqZVlS,url,'3::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::0'])
			kNhfueKQUPm06lMv74.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			kNhfueKQUPm06lMv74.append("yddd[1]")
			BcMl3XdLS0zmK1jPvDJANfYH,F5o1sgcqZVlS,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(qSwomWuMO9hEjbQz1Hx5TsIYc2Up,'',kNhfueKQUPm06lMv74)
			if BcMl3XdLS0zmK1jPvDJANfYH and Yn1Xht82owgc4dvP6jDGEJCyeURxbf and 'continuationItemRenderer' in list(F5o1sgcqZVlS.keys()):
				Yn1Xht82owgc4dvP6jDGEJCyeURxbf.append([F5o1sgcqZVlS,url,'3::0::0::0'])
	return OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,iDIdhpOaVsbPjft79kuF,Yn1Xht82owgc4dvP6jDGEJCyeURxbf,lSEqRLrVHtvX67801U
def EE3e8M6NmlyD5X(mt2wxKaGcp7Vy,OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,url,A1pJYqSia7V4wKMnuvLe30QbrkGj):
	level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = A1pJYqSia7V4wKMnuvLe30QbrkGj.split('::')
	kNhfueKQUPm06lMv74,MLpPNTFKn1l3YRa = [],[]
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['reelShelfRenderer']['items']")
	kNhfueKQUPm06lMv74.append("yeee["+qc8aUVGwZfi3MX+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	kNhfueKQUPm06lMv74.append("yeee")
	FPEwgXUkdjC95xqhpi,G0H3T1lM6y,upDy0Lq8iRA7OT5C291neGSF4Y = a78zgfX26Oym(OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,'',kNhfueKQUPm06lMv74)
	if level=='3' and FPEwgXUkdjC95xqhpi:
		if len(G0H3T1lM6y)>0:
			for EZNqlULKjPXaeJDBFdpsrAh in range(len(G0H3T1lM6y)):
				FFrZMHdmIWtg = str(EZNqlULKjPXaeJDBFdpsrAh)
				kNhfueKQUPm06lMv74 = []
				kNhfueKQUPm06lMv74.append("yfff["+FFrZMHdmIWtg+"]['richItemRenderer']['content']")
				kNhfueKQUPm06lMv74.append("yfff["+FFrZMHdmIWtg+"]['gameCardRenderer']['game']")
				kNhfueKQUPm06lMv74.append("yfff["+FFrZMHdmIWtg+"]['itemSectionRenderer']['contents'][0]")
				kNhfueKQUPm06lMv74.append("yfff["+FFrZMHdmIWtg+"]")
				BcMl3XdLS0zmK1jPvDJANfYH,F5o1sgcqZVlS,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(G0H3T1lM6y,'',kNhfueKQUPm06lMv74)
				if BcMl3XdLS0zmK1jPvDJANfYH: MLpPNTFKn1l3YRa.append([F5o1sgcqZVlS,url,'4::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg])
	return G0H3T1lM6y,FPEwgXUkdjC95xqhpi,MLpPNTFKn1l3YRa,upDy0Lq8iRA7OT5C291neGSF4Y
def a78zgfX26Oym(z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw,HLdTk7KGXpqRZoPjnUIx):
	mt2wxKaGcp7Vy,atuT76Ci5bsopI1fWnxKS2EhcXRvQw = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	qSwomWuMO9hEjbQz1Hx5TsIYc2Up,atuT76Ci5bsopI1fWnxKS2EhcXRvQw = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,atuT76Ci5bsopI1fWnxKS2EhcXRvQw = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	G0H3T1lM6y,atuT76Ci5bsopI1fWnxKS2EhcXRvQw = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX = z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw
	count = len(HLdTk7KGXpqRZoPjnUIx)
	for kdWCpE9TjNh in range(count):
		try:
			Zf3UcusIdT = eval(HLdTk7KGXpqRZoPjnUIx[kdWCpE9TjNh])
			return True,Zf3UcusIdT,kdWCpE9TjNh+1
		except: pass
	return False,'',0
def SPFl6UGK4mrBua(url,A1pJYqSia7V4wKMnuvLe30QbrkGj='',data=''):
	XS9CPAHQF1,Yn1Xht82owgc4dvP6jDGEJCyeURxbf,MLpPNTFKn1l3YRa = [],[],[]
	if '::' not in A1pJYqSia7V4wKMnuvLe30QbrkGj: A1pJYqSia7V4wKMnuvLe30QbrkGj = '1::0::0::0'
	level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = A1pJYqSia7V4wKMnuvLe30QbrkGj.split('::')
	if level=='4': level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = '1',ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg
	data = data.replace('_REMEMBERRESULTS_','')
	Ht6Gg8lbciAd9FaUQVs,mt2wxKaGcp7Vy,BF8XfchlgKmOE0ru2 = zitPVCUuD4JEeGg(url,data)
	A1pJYqSia7V4wKMnuvLe30QbrkGj = level+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
	if level in ['1','2','3']:
		qSwomWuMO9hEjbQz1Hx5TsIYc2Up,OsmBcN6paE7YogAuRyIGl5SKd,XS9CPAHQF1,KK1twgJxmr = LDtdYlyPb4fKuIq6SCzahi1Tr(mt2wxKaGcp7Vy,url,A1pJYqSia7V4wKMnuvLe30QbrkGj)
		if not OsmBcN6paE7YogAuRyIGl5SKd: return
		yytFTW4gxlaV3sm2DGEb6 = len(XS9CPAHQF1)
		if yytFTW4gxlaV3sm2DGEb6<2:
			if level=='1': level = '2'
			XS9CPAHQF1 = []
	A1pJYqSia7V4wKMnuvLe30QbrkGj = level+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
	if level in ['2','3']:
		OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,iDIdhpOaVsbPjft79kuF,Yn1Xht82owgc4dvP6jDGEJCyeURxbf,lSEqRLrVHtvX67801U = DVg9mK2be86BzC5aNLx4U(mt2wxKaGcp7Vy,qSwomWuMO9hEjbQz1Hx5TsIYc2Up,url,A1pJYqSia7V4wKMnuvLe30QbrkGj)
		if not iDIdhpOaVsbPjft79kuF: return
		rKyiku9QZGDx = len(Yn1Xht82owgc4dvP6jDGEJCyeURxbf)
		if rKyiku9QZGDx<2:
			if level=='2': level = '3'
			Yn1Xht82owgc4dvP6jDGEJCyeURxbf = []
	A1pJYqSia7V4wKMnuvLe30QbrkGj = level+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
	if level in ['3']:
		G0H3T1lM6y,FPEwgXUkdjC95xqhpi,MLpPNTFKn1l3YRa,upDy0Lq8iRA7OT5C291neGSF4Y = EE3e8M6NmlyD5X(mt2wxKaGcp7Vy,OKdLhe0Y1FTp7clDkfq6uvVJoAU4ar,url,A1pJYqSia7V4wKMnuvLe30QbrkGj)
		if not FPEwgXUkdjC95xqhpi: return
		cIkaWEhHsD2YpmqLeVRFu = len(MLpPNTFKn1l3YRa)
	for F5o1sgcqZVlS,url,A1pJYqSia7V4wKMnuvLe30QbrkGj in XS9CPAHQF1+Yn1Xht82owgc4dvP6jDGEJCyeURxbf+MLpPNTFKn1l3YRa:
		IIcLHvlEpRSxtdO3iWJqBQ169o0 = VpoiOrWUNSZqBY(F5o1sgcqZVlS,url,A1pJYqSia7V4wKMnuvLe30QbrkGj)
	return
def VpoiOrWUNSZqBY(F5o1sgcqZVlS,url='',A1pJYqSia7V4wKMnuvLe30QbrkGj=''):
	if '::' in A1pJYqSia7V4wKMnuvLe30QbrkGj: level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = A1pJYqSia7V4wKMnuvLe30QbrkGj.split('::')
	else: level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = '1','0','0','0'
	BcMl3XdLS0zmK1jPvDJANfYH,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u,jcut5HFCvweN18Vxf = qOf0QTKxvI(F5o1sgcqZVlS)
	YmT9oB2qsey6hJKFvXbDLkpa = '/videos?' in VV7yf2htDCBU6EeSX8TJQM or '/streams?' in VV7yf2htDCBU6EeSX8TJQM or '/playlists?' in VV7yf2htDCBU6EeSX8TJQM
	KCxYF74IvnoUsWqfJ83mzdBZleVSy = '/channels?' in VV7yf2htDCBU6EeSX8TJQM or '/shorts?' in VV7yf2htDCBU6EeSX8TJQM
	if YmT9oB2qsey6hJKFvXbDLkpa or KCxYF74IvnoUsWqfJ83mzdBZleVSy: VV7yf2htDCBU6EeSX8TJQM = url
	YmT9oB2qsey6hJKFvXbDLkpa = 'watch?v=' not in VV7yf2htDCBU6EeSX8TJQM and '/playlist?list=' not in VV7yf2htDCBU6EeSX8TJQM
	KCxYF74IvnoUsWqfJ83mzdBZleVSy = '/gaming' not in VV7yf2htDCBU6EeSX8TJQM  and '/feed/storefront' not in VV7yf2htDCBU6EeSX8TJQM
	if A1pJYqSia7V4wKMnuvLe30QbrkGj[0:5]=='3::0::' and YmT9oB2qsey6hJKFvXbDLkpa and KCxYF74IvnoUsWqfJ83mzdBZleVSy: VV7yf2htDCBU6EeSX8TJQM = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in VV7yf2htDCBU6EeSX8TJQM:
		level,ZU49hbI8XPt2sm7zrqTBpSw3JE0,qc8aUVGwZfi3MX,FFrZMHdmIWtg = '1','0','0','0'
		A1pJYqSia7V4wKMnuvLe30QbrkGj = ''
	BF8XfchlgKmOE0ru2 = ''
	if '/youtubei/v1/browse' in VV7yf2htDCBU6EeSX8TJQM or '/youtubei/v1/search' in VV7yf2htDCBU6EeSX8TJQM or '/my_main_page_shorts_link' in url:
		data = fQ6kvwg1FrYAzXjbLT.getSetting('av.youtube.data')
		if data.count(':::')==4:
			rioeAlyX4qZ3gE7u,key,Ddypws9QcP1FlB6nKTzOeb2,mQiagbuLRZHV2l6k9S,uWCKp2UeRYGXINl = data.split(':::')
			BF8XfchlgKmOE0ru2 = rioeAlyX4qZ3gE7u+':::'+key+':::'+Ddypws9QcP1FlB6nKTzOeb2+':::'+mQiagbuLRZHV2l6k9S+':::'+jcut5HFCvweN18Vxf
			if '/my_main_page_shorts_link' in url and not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = url
			else: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?key='+key
	if not title:
		global mGbScjqdeVlMDCJpnI0U
		mGbScjqdeVlMDCJpnI0U += 1
		title = 'فيديوهات '+str(mGbScjqdeVlMDCJpnI0U)
		A1pJYqSia7V4wKMnuvLe30QbrkGj = '3'+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
	if not BcMl3XdLS0zmK1jPvDJANfYH: return False
	elif 'searchPyvRenderer' in str(F5o1sgcqZVlS): return False
	elif '/about' in VV7yf2htDCBU6EeSX8TJQM: return False
	elif '/community' in VV7yf2htDCBU6EeSX8TJQM: return False
	elif 'continuationItemRenderer' in list(F5o1sgcqZVlS.keys()) or 'continuationCommand' in list(F5o1sgcqZVlS.keys()):
		if int(level)>1: level = str(int(level)-1)
		A1pJYqSia7V4wKMnuvLe30QbrkGj = level+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+':: '+'صفحة أخرى',VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj,BF8XfchlgKmOE0ru2)
	elif '/search' in VV7yf2htDCBU6EeSX8TJQM:
		title = ':: '+title
		A1pJYqSia7V4wKMnuvLe30QbrkGj = '3'+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
		url = url.replace('/search','')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,145,'',A1pJYqSia7V4wKMnuvLe30QbrkGj,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not VV7yf2htDCBU6EeSX8TJQM:
		A1pJYqSia7V4wKMnuvLe30QbrkGj = '3'+'::'+ZU49hbI8XPt2sm7zrqTBpSw3JE0+'::'+qc8aUVGwZfi3MX+'::'+FFrZMHdmIWtg
		title = ':: '+title
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj,BF8XfchlgKmOE0ru2)
	elif '/browse' in VV7yf2htDCBU6EeSX8TJQM and url==GqcEfFR8XQPgBMLr:
		title = ':: '+title
		A1pJYqSia7V4wKMnuvLe30QbrkGj = '2::0::0::0'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj,BF8XfchlgKmOE0ru2)
	elif not VV7yf2htDCBU6EeSX8TJQM and 'horizontalMovieListRenderer' in str(F5o1sgcqZVlS):
		title = ':: '+title
		A1pJYqSia7V4wKMnuvLe30QbrkGj = '3::0::0::0'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj)
	elif 'messageRenderer' in str(F5o1sgcqZVlS):
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+title,'',9999)
	elif UQ7tunCIEc56:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+UQ7tunCIEc56+title,VV7yf2htDCBU6EeSX8TJQM,143,G2WR0Oacvdq8ZQTjKboDU)
	elif '/playlist?list=' in VV7yf2htDCBU6EeSX8TJQM:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'LIST'+count+':  '+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj)
	elif '/shorts/' in VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&list=',1)[0]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,143,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw)
	elif '/watch?v=' in VV7yf2htDCBU6EeSX8TJQM:
		if '&list=' in VV7yf2htDCBU6EeSX8TJQM and count:
			KfQtAyIxdRBMFzo64U = VV7yf2htDCBU6EeSX8TJQM.split('&list=',1)[1]
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/playlist?list='+KfQtAyIxdRBMFzo64U
			A1pJYqSia7V4wKMnuvLe30QbrkGj = '3::0::0::0'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'LIST'+count+':  '+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj)
		else:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('&list=',1)[0]
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,143,G2WR0Oacvdq8ZQTjKboDU,VVaBpWQDAfx5dO4GSMmstz78eRFYw)
	elif '/channel/' in VV7yf2htDCBU6EeSX8TJQM or '/c/' in VV7yf2htDCBU6EeSX8TJQM or ('/@' in VV7yf2htDCBU6EeSX8TJQM and VV7yf2htDCBU6EeSX8TJQM.count('/')==3):
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'CHNL'+count+':  '+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj)
	elif '/user/' in VV7yf2htDCBU6EeSX8TJQM:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'USER'+count+':  '+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj)
	else:
		if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = url
		title = ':: '+title
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,144,G2WR0Oacvdq8ZQTjKboDU,A1pJYqSia7V4wKMnuvLe30QbrkGj,BF8XfchlgKmOE0ru2)
	return True
def qOf0QTKxvI(F5o1sgcqZVlS):
	BcMl3XdLS0zmK1jPvDJANfYH,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u,uWCKp2UeRYGXINl = False,'','','','','','','',''
	if not isinstance(F5o1sgcqZVlS,dict): return BcMl3XdLS0zmK1jPvDJANfYH,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u,uWCKp2UeRYGXINl
	for KKhp83Z0bESgQUyTV6NB42RiGHwze in list(F5o1sgcqZVlS.keys()):
		h6Sd108yOIKGvcCflWBL2rbpX = F5o1sgcqZVlS[KKhp83Z0bESgQUyTV6NB42RiGHwze]
		if isinstance(h6Sd108yOIKGvcCflWBL2rbpX,dict): break
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['header']['richListHeaderRenderer']['title']")
	kNhfueKQUPm06lMv74.append("yrender['headline']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['unplayableText']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['formattedTitle']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['title']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['title']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("yrender['text']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['text']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("yrender['title']")
	kNhfueKQUPm06lMv74.append("item['title']")
	kNhfueKQUPm06lMv74.append("item['reelWatchEndpoint']['videoId']")
	BcMl3XdLS0zmK1jPvDJANfYH,title,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	kNhfueKQUPm06lMv74.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	kNhfueKQUPm06lMv74.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	kNhfueKQUPm06lMv74.append("item['commandMetadata']['webCommandMetadata']['url']")
	BcMl3XdLS0zmK1jPvDJANfYH,VV7yf2htDCBU6EeSX8TJQM,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("yrender['thumbnail']['thumbnails'][0]['url']")
	kNhfueKQUPm06lMv74.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	kNhfueKQUPm06lMv74.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	BcMl3XdLS0zmK1jPvDJANfYH,G2WR0Oacvdq8ZQTjKboDU,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("yrender['videoCount']")
	kNhfueKQUPm06lMv74.append("yrender['videoCountText']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	BcMl3XdLS0zmK1jPvDJANfYH,count,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	kNhfueKQUPm06lMv74.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['lengthText']['simpleText']")
	kNhfueKQUPm06lMv74.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	kNhfueKQUPm06lMv74.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	BcMl3XdLS0zmK1jPvDJANfYH,VVaBpWQDAfx5dO4GSMmstz78eRFYw,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX,kNhfueKQUPm06lMv74)
	kNhfueKQUPm06lMv74 = []
	kNhfueKQUPm06lMv74.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	kNhfueKQUPm06lMv74.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	BcMl3XdLS0zmK1jPvDJANfYH,uWCKp2UeRYGXINl,CfeaWGU28lvj4hoYRVwt6sy3p = a78zgfX26Oym(F5o1sgcqZVlS,h6Sd108yOIKGvcCflWBL2rbpX,kNhfueKQUPm06lMv74)
	if 'LIVE' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56 = '','LIVE:  '
	if 'مباشر' in VVaBpWQDAfx5dO4GSMmstz78eRFYw: VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56 = '','LIVE:  '
	if 'badges' in list(h6Sd108yOIKGvcCflWBL2rbpX.keys()):
		AnuSziPdrF17lN = str(h6Sd108yOIKGvcCflWBL2rbpX['badges'])
		if 'Free with Ads' in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$:  '
		if 'LIVE' in AnuSziPdrF17lN: UQ7tunCIEc56 = 'LIVE:  '
		if 'Buy' in AnuSziPdrF17lN or 'Rent' in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$$:  '
		if PPpWoLVXID4(u'مباشر') in AnuSziPdrF17lN: UQ7tunCIEc56 = 'LIVE:  '
		if PPpWoLVXID4(u'شراء') in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$$:  '
		if PPpWoLVXID4(u'استئجار') in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$$:  '
		if PPpWoLVXID4(u'إعلانات') in AnuSziPdrF17lN: APIWtCph8cLSvBRiU20u = '$:  '
	VV7yf2htDCBU6EeSX8TJQM = kWfpQA7tTjSPyLbNIeMr1Hui5(VV7yf2htDCBU6EeSX8TJQM)
	if VV7yf2htDCBU6EeSX8TJQM and 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
	G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.split('?')[0]
	if  G2WR0Oacvdq8ZQTjKboDU and 'http' not in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = 'https:'+G2WR0Oacvdq8ZQTjKboDU
	title = kWfpQA7tTjSPyLbNIeMr1Hui5(title)
	if APIWtCph8cLSvBRiU20u: title = APIWtCph8cLSvBRiU20u+title
	VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.replace(',','')
	count = count.replace(',','')
	count = QPuHKNAT4jmCRg.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,count,VVaBpWQDAfx5dO4GSMmstz78eRFYw,UQ7tunCIEc56,APIWtCph8cLSvBRiU20u,uWCKp2UeRYGXINl
def zitPVCUuD4JEeGg(url,data='',lp3eGht9uF4mMCR6YIWz=''):
	if lp3eGht9uF4mMCR6YIWz=='': lp3eGht9uF4mMCR6YIWz = 'ytInitialData'
	oOM6fji0UV3Yn2 = yWgZFzdaNR5iw6m8Q9G7CL()
	Eudgv5cTUHF2AzKpkx = {'User-Agent':oOM6fji0UV3Yn2,'Cookie':'PREF=hl=ar'}
	global fQ6kvwg1FrYAzXjbLT
	if not data: data = fQ6kvwg1FrYAzXjbLT.getSetting('av.youtube.data')
	if data.count(':::')==4: rioeAlyX4qZ3gE7u,key,Ddypws9QcP1FlB6nKTzOeb2,mQiagbuLRZHV2l6k9S,uWCKp2UeRYGXINl = data.split(':::')
	else: rioeAlyX4qZ3gE7u,key,Ddypws9QcP1FlB6nKTzOeb2,mQiagbuLRZHV2l6k9S,uWCKp2UeRYGXINl = '','','','',''
	BF8XfchlgKmOE0ru2 = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":Ddypws9QcP1FlB6nKTzOeb2}}}
	if url==GqcEfFR8XQPgBMLr+'/shorts' or '/my_main_page_shorts_link' in url:
		url = GqcEfFR8XQPgBMLr+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		BF8XfchlgKmOE0ru2['sequenceParams'] = rioeAlyX4qZ3gE7u
		BF8XfchlgKmOE0ru2 = str(BF8XfchlgKmOE0ru2)
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',url,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = GqcEfFR8XQPgBMLr+'/youtubei/v1/guide?key='+key
		BF8XfchlgKmOE0ru2 = str(BF8XfchlgKmOE0ru2)
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',url,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and rioeAlyX4qZ3gE7u:
		BF8XfchlgKmOE0ru2['continuation'] = uWCKp2UeRYGXINl
		BF8XfchlgKmOE0ru2['context']['client']['visitorData'] = rioeAlyX4qZ3gE7u
		BF8XfchlgKmOE0ru2 = str(BF8XfchlgKmOE0ru2)
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'POST',url,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and mQiagbuLRZHV2l6k9S:
		Eudgv5cTUHF2AzKpkx.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':Ddypws9QcP1FlB6nKTzOeb2})
		Eudgv5cTUHF2AzKpkx.update({'Cookie':'VISITOR_INFO1_LIVE='+mQiagbuLRZHV2l6k9S})
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'',Eudgv5cTUHF2AzKpkx,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'',Eudgv5cTUHF2AzKpkx,'','','YOUTUBE-GET_PAGE_DATA-6th')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall('"innertubeApiKey".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if uuv3pk5MXdeaHt6sDxSFybTWz0Q: key = uuv3pk5MXdeaHt6sDxSFybTWz0Q[0]
	uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall('"cver".*?"value".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if uuv3pk5MXdeaHt6sDxSFybTWz0Q: Ddypws9QcP1FlB6nKTzOeb2 = uuv3pk5MXdeaHt6sDxSFybTWz0Q[0]
	uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall('"visitorData".*?"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.I)
	if uuv3pk5MXdeaHt6sDxSFybTWz0Q: rioeAlyX4qZ3gE7u = uuv3pk5MXdeaHt6sDxSFybTWz0Q[0]
	cookies = nbdMp8UuhzP3oq4cDWj6eyZVt.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): mQiagbuLRZHV2l6k9S = cookies['VISITOR_INFO1_LIVE']
	mOs52o91PbFZD7C = rioeAlyX4qZ3gE7u+':::'+key+':::'+Ddypws9QcP1FlB6nKTzOeb2+':::'+mQiagbuLRZHV2l6k9S+':::'+uWCKp2UeRYGXINl
	if lp3eGht9uF4mMCR6YIWz=='ytInitialData' and 'ytInitialData' in Ht6Gg8lbciAd9FaUQVs:
		wZ72rPoBbdRYFOm4TzSEutN = QPuHKNAT4jmCRg.findall('window\["ytInitialData"\] = ({.*?});',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not wZ72rPoBbdRYFOm4TzSEutN: wZ72rPoBbdRYFOm4TzSEutN = QPuHKNAT4jmCRg.findall('var ytInitialData = ({.*?});',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		dQsPlfr7k2nDuiVgHz0tAEJ54 = kMLWTt2fO9dnGDUgHh('str',wZ72rPoBbdRYFOm4TzSEutN[0])
	elif lp3eGht9uF4mMCR6YIWz=='ytInitialGuideData' and 'ytInitialGuideData' in Ht6Gg8lbciAd9FaUQVs:
		wZ72rPoBbdRYFOm4TzSEutN = QPuHKNAT4jmCRg.findall('var ytInitialGuideData = ({.*?});',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		dQsPlfr7k2nDuiVgHz0tAEJ54 = kMLWTt2fO9dnGDUgHh('str',wZ72rPoBbdRYFOm4TzSEutN[0])
	elif '</script>' not in Ht6Gg8lbciAd9FaUQVs: dQsPlfr7k2nDuiVgHz0tAEJ54 = kMLWTt2fO9dnGDUgHh('str',Ht6Gg8lbciAd9FaUQVs)
	else: dQsPlfr7k2nDuiVgHz0tAEJ54 = ''
	if 0:
		mt2wxKaGcp7Vy = str(dQsPlfr7k2nDuiVgHz0tAEJ54)
		if Nnxm30dfoBWRYpIC7KsQGl: mt2wxKaGcp7Vy = mt2wxKaGcp7Vy.encode('utf8')
		open('S:\\0000emad.dat','wb').write(mt2wxKaGcp7Vy)
	fQ6kvwg1FrYAzXjbLT.setSetting('av.youtube.data',mOs52o91PbFZD7C)
	return Ht6Gg8lbciAd9FaUQVs,dQsPlfr7k2nDuiVgHz0tAEJ54,mOs52o91PbFZD7C
def NhVHcnMi2ol3LrjmA8d4t9YUaDF1(url,A1pJYqSia7V4wKMnuvLe30QbrkGj):
	search = wod1HJ0fnvcTNAX2WIiMu9P()
	if not search: return
	search = search.replace(' ','+')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/search?query='+search
	SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,A1pJYqSia7V4wKMnuvLe30QbrkGj)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search:
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		if not search: return
	search = search.replace(' ','+')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in vwIN38HprDqTW5Sh61exF7EnA: zdCvQa6xDuwple3H4nZ0WFKXMLg = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in vwIN38HprDqTW5Sh61exF7EnA: zdCvQa6xDuwple3H4nZ0WFKXMLg = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in vwIN38HprDqTW5Sh61exF7EnA: zdCvQa6xDuwple3H4nZ0WFKXMLg = '&sp=EgIQAg%253D%253D'
		else: zdCvQa6xDuwple3H4nZ0WFKXMLg = ''
		lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+zdCvQa6xDuwple3H4nZ0WFKXMLg
	else:
		wxz1gjoBHmlY2IqZNk,d6dwmFerfbV2JYLnNT,nUbpaNT0vhcj7ZsEz = [],[],''
		RWvzaCEoOtYl45pq7LnsI02 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		yuqgGDemO2sjaBLkpNfAc = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		PRBLAwM5QD7djgXYIGkzoK8uanfvO = ISveRUGKjgM9wqL6FZpsku0bB('موقع يوتيوب - اختر الترتيب',RWvzaCEoOtYl45pq7LnsI02)
		if PRBLAwM5QD7djgXYIGkzoK8uanfvO == -1: return
		wwQATDIdKfcYx = yuqgGDemO2sjaBLkpNfAc[PRBLAwM5QD7djgXYIGkzoK8uanfvO]
		Ht6Gg8lbciAd9FaUQVs,sjhXNO10W4CTqlAS8JeZwtKBnPm9UG,data = zitPVCUuD4JEeGg(lZqkuhgaBHSVX8NItKG05cdLJe7Ao+wwQATDIdKfcYx)
		if sjhXNO10W4CTqlAS8JeZwtKBnPm9UG:
			try:
				NJHsCZEmV7l4hGMU = sjhXNO10W4CTqlAS8JeZwtKBnPm9UG['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for KLGFa4V95CDwtu1l in range(len(NJHsCZEmV7l4hGMU)):
					group = NJHsCZEmV7l4hGMU[KLGFa4V95CDwtu1l]['searchFilterGroupRenderer']['filters']
					for izJqrMn2oRxZj in range(len(group)):
						h6Sd108yOIKGvcCflWBL2rbpX = group[izJqrMn2oRxZj]['searchFilterRenderer']
						if 'navigationEndpoint' in list(h6Sd108yOIKGvcCflWBL2rbpX.keys()):
							VV7yf2htDCBU6EeSX8TJQM = h6Sd108yOIKGvcCflWBL2rbpX['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\u0026','&')
							title = h6Sd108yOIKGvcCflWBL2rbpX['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								nUbpaNT0vhcj7ZsEz = title
								FsnXTNzcG53RUk = VV7yf2htDCBU6EeSX8TJQM
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								nUbpaNT0vhcj7ZsEz = title
								FsnXTNzcG53RUk = VV7yf2htDCBU6EeSX8TJQM
							if 'Sort by' in title: continue
							wxz1gjoBHmlY2IqZNk.append(kWfpQA7tTjSPyLbNIeMr1Hui5(title))
							d6dwmFerfbV2JYLnNT.append(VV7yf2htDCBU6EeSX8TJQM)
			except: pass
		if not nUbpaNT0vhcj7ZsEz: JL5gMtXaYzTquOSFEbc6H = ''
		else:
			wxz1gjoBHmlY2IqZNk = ['بدون فلتر',nUbpaNT0vhcj7ZsEz]+wxz1gjoBHmlY2IqZNk
			d6dwmFerfbV2JYLnNT = ['',FsnXTNzcG53RUk]+d6dwmFerfbV2JYLnNT
			q95vKZkwaPGSz = ISveRUGKjgM9wqL6FZpsku0bB('موقع يوتيوب - اختر الفلتر',wxz1gjoBHmlY2IqZNk)
			if q95vKZkwaPGSz == -1: return
			JL5gMtXaYzTquOSFEbc6H = d6dwmFerfbV2JYLnNT[q95vKZkwaPGSz]
		if JL5gMtXaYzTquOSFEbc6H: lc154VhT9DCqMk8 = GqcEfFR8XQPgBMLr+JL5gMtXaYzTquOSFEbc6H
		elif wwQATDIdKfcYx: lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+wwQATDIdKfcYx
		else: lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao
	SPFl6UGK4mrBua(lc154VhT9DCqMk8)
	return
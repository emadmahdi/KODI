# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'CIMALIGHT'
JE7QrkmhletLwA0OZXu = '_CML_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['قنوات فضائية']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==470: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==471: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==472: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==473: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,text)
	elif mode==474: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==479: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','CIMALIGHT-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = QPuHKNAT4jmCRg.findall('"url": "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ka6I93CnvublQMtjr = ka6I93CnvublQMtjr[0].strip('/')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(ka6I93CnvublQMtjr,'url')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أفلام مميزة',ka6I93CnvublQMtjr,471,'','','featured_movies')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"content"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = title.replace('  ','').strip(' ')
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('cat=online-movies1','cat=online-movies')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,474)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('/category.php">(.*?)"navslide-divider"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("'dropdown-menu'(.*?)</ul>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,474)
	return
def pF0d4b2ZY9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if 'topvideos.php' in url: TTCRYZroizb = QPuHKNAT4jmCRg.findall('"caret"(.*?)id="pm-grid"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	else: TTCRYZroizb = QPuHKNAT4jmCRg.findall('"caret"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if 'topvideos.php' in VV7yf2htDCBU6EeSX8TJQM:
				if 'topvideos.php?c=english-movies' in VV7yf2htDCBU6EeSX8TJQM: continue
				if 'topvideos.php?c=online-movies1' in VV7yf2htDCBU6EeSX8TJQM: continue
				if 'topvideos.php?c=misc' in VV7yf2htDCBU6EeSX8TJQM: continue
				if 'topvideos.php?c=tv-channel' in VV7yf2htDCBU6EeSX8TJQM: continue
				if 'منذ البداية' in title and 'do=rating' not in VV7yf2htDCBU6EeSX8TJQM: continue
			else: title = 'ترتيب باستخدام:  '+title
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,471)
	else: SPFl6UGK4mrBua(url)
	return
def SPFl6UGK4mrBua(url,lp3eGht9uF4mMCR6YIWz=''):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = []
	if lp3eGht9uF4mMCR6YIWz=='featured_movies':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"container-fluid"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		Y4xiULzGTKjb8mulO,lGKfCUP9XRTaBwQ6pq7n0,V81XvdjcUZSxwAhTatFm = zip(*items)
		items = zip(V81XvdjcUZSxwAhTatFm,Y4xiULzGTKjb8mulO,lGKfCUP9XRTaBwQ6pq7n0)
	elif lp3eGht9uF4mMCR6YIWz=='featured_series':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('المسلسلات المميزة(.*?)<style>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		Y4xiULzGTKjb8mulO,lGKfCUP9XRTaBwQ6pq7n0,V81XvdjcUZSxwAhTatFm = zip(*items)
		items = zip(V81XvdjcUZSxwAhTatFm,Y4xiULzGTKjb8mulO,lGKfCUP9XRTaBwQ6pq7n0)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('(data-echo=".*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('"BlocksList"(.*?)"titleSectionCon"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="pm-grid"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="pm-related"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: return
		wltPGJcYo12Ed = TTCRYZroizb[0]
	if not items: items = QPuHKNAT4jmCRg.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if not items: items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
		if 'http' not in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = ka6I93CnvublQMtjr+'/'+G2WR0Oacvdq8ZQTjKboDU.strip('/')
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			title = '_MOD_'+title
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,472,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and 'الحلقة' in title:
			title = '_MOD_'+CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,473,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif '/movseries/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,471,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,473,G2WR0Oacvdq8ZQTjKboDU)
	if lp3eGht9uF4mMCR6YIWz not in ['featured_movies','featured_series']:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if VV7yf2htDCBU6EeSX8TJQM=='#': continue
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,471)
		lO6rM8NcKUL5g4wd31nEGQF7HRfu = QPuHKNAT4jmCRg.findall('showmore" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if lO6rM8NcKUL5g4wd31nEGQF7HRfu:
			VV7yf2htDCBU6EeSX8TJQM = lO6rM8NcKUL5g4wd31nEGQF7HRfu[0]
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مشاهدة المزيد',VV7yf2htDCBU6EeSX8TJQM,471)
	return
def opLlxOB2dUVZ5JF4j(url,XpxUEd8SkCJHrst3):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"SeasonsBox"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('id="'+XpxUEd8SkCJHrst3+'"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	items = []
	if kzlepwfG1iEyIJKTY45quXO and not XpxUEd8SkCJHrst3:
		G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"series-header".*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('openCity\(event\, \'(.*?)\'\)">(.*?)</button>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for XpxUEd8SkCJHrst3,title in items: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,473,G2WR0Oacvdq8ZQTjKboDU,'',XpxUEd8SkCJHrst3)
	elif kk73xHNzri1P2wgULMv4sDtoTnybO:
		G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"series-header".*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall("title='(.*?)' href='(.*?)'",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for title,VV7yf2htDCBU6EeSX8TJQM in items:
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,472,G2WR0Oacvdq8ZQTjKboDU)
		else:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,472,G2WR0Oacvdq8ZQTjKboDU)
	if 'id="pm-related"' in Ht6Gg8lbciAd9FaUQVs:
		if items: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مواضيع ذات صلة',url,471)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<div itemprop="description">(.*?)href=',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('<p>(.*?)</p>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy,True): return
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace('/watch.php','/play.php')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','CIMALIGHT-PLAY-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	vE8tNCWZAI7nml291gP = []
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"embedURL" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		if VV7yf2htDCBU6EeSX8TJQM and VV7yf2htDCBU6EeSX8TJQM not in vE8tNCWZAI7nml291gP:
			vE8tNCWZAI7nml291gP.append(VV7yf2htDCBU6EeSX8TJQM)
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named=__embed'
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	items = QPuHKNAT4jmCRg.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if VV7yf2htDCBU6EeSX8TJQM not in vE8tNCWZAI7nml291gP:
			vE8tNCWZAI7nml291gP.append(VV7yf2htDCBU6EeSX8TJQM)
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace('/watch.php','/downloads.php')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','CIMALIGHT-PLAY-3rd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"downloadlist"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<strong>(.*?)</strong>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if VV7yf2htDCBU6EeSX8TJQM not in vE8tNCWZAI7nml291gP:
				vE8tNCWZAI7nml291gP.append(VV7yf2htDCBU6EeSX8TJQM)
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/search.php?keywords='+search
	SPFl6UGK4mrBua(url)
	return
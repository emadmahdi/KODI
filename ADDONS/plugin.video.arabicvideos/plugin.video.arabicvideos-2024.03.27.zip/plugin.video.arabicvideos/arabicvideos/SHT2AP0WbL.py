# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
JE7QrkmhletLwA0OZXu = '_MVZ_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
FWpjdmYqwgi = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][1]
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==180: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==181: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==182: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==183: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==188: RRMWBwU6pG = TU6NzuDZSVAEb0fclY7LC1kFgqGtM2()
	elif mode==189: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def TU6NzuDZSVAEb0fclY7LC1kFgqGtM2():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج',message)
	return
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'بوكس اوفيس موفيز لاند',GqcEfFR8XQPgBMLr,181,'','','box-office')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أحدث الافلام',GqcEfFR8XQPgBMLr,181,'','','latest-movies')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'تليفزيون موفيز لاند',GqcEfFR8XQPgBMLr,181,'','','tv')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الاكثر مشاهدة',GqcEfFR8XQPgBMLr,181,'','','top-views')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أقوى الافلام الحالية',GqcEfFR8XQPgBMLr,181,'','','top-movies')
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','MOVIZLAND-MENU-1st')
	items = QPuHKNAT4jmCRg.findall('<h2><a href="(.*?)".*?">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,181)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,type=''):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': wltPGJcYo12Ed = QPuHKNAT4jmCRg.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	elif type=='box-office': wltPGJcYo12Ed = QPuHKNAT4jmCRg.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	elif type=='top-movies': wltPGJcYo12Ed = QPuHKNAT4jmCRg.findall('btn-2-overlay(.*?)<style>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	elif type=='top-views': wltPGJcYo12Ed = QPuHKNAT4jmCRg.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	elif type=='tv': wltPGJcYo12Ed = QPuHKNAT4jmCRg.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	else: wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
	if type in ['top-views','top-movies']:
		items = QPuHKNAT4jmCRg.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	else: items = QPuHKNAT4jmCRg.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	WWfUzKtSjs = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for G2WR0Oacvdq8ZQTjKboDU,z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw,n0n5PiuAxCtspZvJqk6XU in items:
		if type in ['top-views','top-movies']:
			G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,FsnXTNzcG53RUk,title = G2WR0Oacvdq8ZQTjKboDU,z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw,n0n5PiuAxCtspZvJqk6XU
		else: G2WR0Oacvdq8ZQTjKboDU,title,VV7yf2htDCBU6EeSX8TJQM,FsnXTNzcG53RUk = G2WR0Oacvdq8ZQTjKboDU,z8ty6aqx2wKOIsul,atuT76Ci5bsopI1fWnxKS2EhcXRvQw,n0n5PiuAxCtspZvJqk6XU
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('?view=true','')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) (الحلقة|الحلقه) \d+',title,QPuHKNAT4jmCRg.DOTALL)
			if CiZxgXTGW9pv:
				title = '_MOD_' + CiZxgXTGW9pv[0][0]
				if title not in gltHFKTroJfpLe:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,183,G2WR0Oacvdq8ZQTjKboDU)
					gltHFKTroJfpLe.append(title)
		elif any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in WWfUzKtSjs):
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM + '?servers=' + FsnXTNzcG53RUk
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,182,G2WR0Oacvdq8ZQTjKboDU)
		else:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM + '?servers=' + FsnXTNzcG53RUk
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,183,G2WR0Oacvdq8ZQTjKboDU)
	if type=='':
		items = QPuHKNAT4jmCRg.findall('\n<li><a href="(.*?)".*?>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = title.replace('الصفحة ','')
			if title!='':
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,181)
	return
def opLlxOB2dUVZ5JF4j(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.split('?servers=')[0]
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','MOVIZLAND-EPISODES-1st')
	wltPGJcYo12Ed = QPuHKNAT4jmCRg.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	title,aaxAKWtMwfPRE4zbqSQCOrBms0,G2WR0Oacvdq8ZQTjKboDU = wltPGJcYo12Ed[0]
	name = QPuHKNAT4jmCRg.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,QPuHKNAT4jmCRg.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="episodesNumbers"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM in items:
			VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
			title = QPuHKNAT4jmCRg.findall('(الحلقة|الحلقه)-([0-9]+)',VV7yf2htDCBU6EeSX8TJQM.split('/')[-2],QPuHKNAT4jmCRg.DOTALL)
			if not title: title = QPuHKNAT4jmCRg.findall('()-([0-9]+)',VV7yf2htDCBU6EeSX8TJQM.split('/')[-2],QPuHKNAT4jmCRg.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,182,G2WR0Oacvdq8ZQTjKboDU)
	if not items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,url,182,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	deoTHkGNZX1s2mp4SvtJznIl3FyVA = url.split('?servers=')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = deoTHkGNZX1s2mp4SvtJznIl3FyVA[0]
	del deoTHkGNZX1s2mp4SvtJznIl3FyVA[0]
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','MOVIZLAND-PLAY-1st')
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('font-size: 25px;" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	if VV7yf2htDCBU6EeSX8TJQM not in deoTHkGNZX1s2mp4SvtJznIl3FyVA: deoTHkGNZX1s2mp4SvtJznIl3FyVA.append(VV7yf2htDCBU6EeSX8TJQM)
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	for VV7yf2htDCBU6EeSX8TJQM in deoTHkGNZX1s2mp4SvtJznIl3FyVA:
		if '://moshahda.' in VV7yf2htDCBU6EeSX8TJQM:
			qXH6oeO7CATshcNLrxzYM = VV7yf2htDCBU6EeSX8TJQM
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(qXH6oeO7CATshcNLrxzYM+'?named=Main')
	for VV7yf2htDCBU6EeSX8TJQM in deoTHkGNZX1s2mp4SvtJznIl3FyVA:
		if '://vb.movizland.' in VV7yf2htDCBU6EeSX8TJQM:
			Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,VV7yf2htDCBU6EeSX8TJQM,'',headers,'','MOVIZLAND-PLAY-2nd')
			Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.decode('windows-1256').encode('utf8')
			Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if TTCRYZroizb:
				gyGwI3NoaQV8uC0YjZUTHS,UdxpbPKgBScklJLj542O0feZsro = [],[]
				if len(TTCRYZroizb)==1:
					title = ''
					wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
				else:
					for wltPGJcYo12Ed in TTCRYZroizb:
						y8qSvx0Z9MY = QPuHKNAT4jmCRg.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
						if y8qSvx0Z9MY: wltPGJcYo12Ed = 'src="/uploads/13721411411.png"  \n  ' + y8qSvx0Z9MY[0][1]
						y8qSvx0Z9MY = QPuHKNAT4jmCRg.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
						if y8qSvx0Z9MY: wltPGJcYo12Ed = 'src="/uploads/13721411411.png"  \n  ' + y8qSvx0Z9MY[0]
						y8qSvx0Z9MY = QPuHKNAT4jmCRg.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
						if y8qSvx0Z9MY: wltPGJcYo12Ed = y8qSvx0Z9MY[0] + '  \n  src="/uploads/13721411411.png"'
						teCHa8qZ154gT2fOjrWApF3YR = QPuHKNAT4jmCRg.findall('<(.*?)http://up.movizland.(online|com)/uploads/',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
						title = QPuHKNAT4jmCRg.findall('> *([^<>]+) *<',teCHa8qZ154gT2fOjrWApF3YR[0][0],QPuHKNAT4jmCRg.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						gyGwI3NoaQV8uC0YjZUTHS.append(title)
					ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('أختر الفيديو المطلوب:', gyGwI3NoaQV8uC0YjZUTHS)
					if ShT1xUHjlDotkRuPq7gv == -1 : return
					title = gyGwI3NoaQV8uC0YjZUTHS[ShT1xUHjlDotkRuPq7gv]
					wltPGJcYo12Ed = TTCRYZroizb[ShT1xUHjlDotkRuPq7gv]
				VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('href="(http://moshahda\..*?/\w+.html)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				mnvlDxKVokdpYWUyZsgehCQ5XFq3iw = VV7yf2htDCBU6EeSX8TJQM[0]
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(mnvlDxKVokdpYWUyZsgehCQ5XFq3iw+'?named=Forum')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('ـ','')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				wltPGJcYo12Ed = wltPGJcYo12Ed.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				NNknm6Wr3pxZB5wq4yHigazTUYVFsQ = QPuHKNAT4jmCRg.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				for ChJKeZpqTSfjwIGs1HdrY3x in NNknm6Wr3pxZB5wq4yHigazTUYVFsQ:
					type = QPuHKNAT4jmCRg.findall(' typetype="(.*?)" ',ChJKeZpqTSfjwIGs1HdrY3x)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = QPuHKNAT4jmCRg.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',ChJKeZpqTSfjwIGs1HdrY3x,QPuHKNAT4jmCRg.DOTALL)
					for npvaENQSstm5PZ9T1W63dOqryhji,VV7yf2htDCBU6EeSX8TJQM in items:
						title = QPuHKNAT4jmCRg.findall('(\w+[ \w]*)<',npvaENQSstm5PZ9T1W63dOqryhji)
						title = title[-1]
						VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM + '?named=' + title + type
						LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace(GqcEfFR8XQPgBMLr,FWpjdmYqwgi)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lc154VhT9DCqMk8,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = QPuHKNAT4jmCRg.findall('" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if items:
		PPTRhg4lsSvCcdwW90YIoOEe = items[-1]
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(PPTRhg4lsSvCcdwW90YIoOEe+'?named=Mobile')
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,GqcEfFR8XQPgBMLr,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = QPuHKNAT4jmCRg.findall('<option value="(.*?)">(.*?)</option>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ff6SaGrmZkRn7uFjXtgHpqiBlMU = [ '' ]
	ojqfwHUp1vhk87Y65c = [ 'الكل وبدون فلتر' ]
	for jsEpRxQH76,title in items:
		ff6SaGrmZkRn7uFjXtgHpqiBlMU.append(jsEpRxQH76)
		ojqfwHUp1vhk87Y65c.append(title)
	if jsEpRxQH76:
		ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الفلتر المناسب:', ojqfwHUp1vhk87Y65c)
		if ShT1xUHjlDotkRuPq7gv == -1 : return
		jsEpRxQH76 = ff6SaGrmZkRn7uFjXtgHpqiBlMU[ShT1xUHjlDotkRuPq7gv]
	else: jsEpRxQH76 = ''
	url = GqcEfFR8XQPgBMLr + '/?s='+search+'&mcat='+jsEpRxQH76
	SPFl6UGK4mrBua(url)
	return
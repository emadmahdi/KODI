# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'SHAHIDNEWS'
JE7QrkmhletLwA0OZXu = '_SHN_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['قنوات فضائية','فارسكو','Show more']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==580: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==581: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==582: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==583: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,text)
	elif mode==584: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==589: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','SHAHIDNEWS-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',589,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('/category.php">(.*?)"navslide-divider"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("'dropdown-menu'(.*?)</ul>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for y8qSvx0Z9MY in TTCRYZroizb: wltPGJcYo12Ed = wltPGJcYo12Ed.replace(y8qSvx0Z9MY,'')
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,584)
	return
def pF0d4b2ZY9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHAHIDNEWS-SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"caret"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		wltPGJcYo12Ed = wltPGJcYo12Ed.replace('"presentation"','</ul>')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = [('',wltPGJcYo12Ed)]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for jj8UuT2RMkfDGncsLorzHl0eaNgPB,wltPGJcYo12Ed in TTCRYZroizb:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if jj8UuT2RMkfDGncsLorzHl0eaNgPB: jj8UuT2RMkfDGncsLorzHl0eaNgPB = jj8UuT2RMkfDGncsLorzHl0eaNgPB+': '
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = jj8UuT2RMkfDGncsLorzHl0eaNgPB+title
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,581)
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"pm-category-subcats"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kk73xHNzri1P2wgULMv4sDtoTnybO:
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if len(items)<30:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,581)
	if not kzlepwfG1iEyIJKTY45quXO and not kk73xHNzri1P2wgULMv4sDtoTnybO: SPFl6UGK4mrBua(url)
	return
def SPFl6UGK4mrBua(url,lp3eGht9uF4mMCR6YIWz=''):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHAHIDNEWS-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('(data-echo=".*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('"BlocksList"(.*?)"titleSectionCon"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="pm-grid"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="pm-related"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	if not items: items = QPuHKNAT4jmCRg.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if not items: items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM).strip('/')
		if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
		if 'http' not in G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = ka6I93CnvublQMtjr+'/'+G2WR0Oacvdq8ZQTjKboDU.strip('/')
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,582,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and 'الحلقة' in title:
			title = '_MOD_' + CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,583,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif '/movseries/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,581,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,583,G2WR0Oacvdq8ZQTjKboDU)
	if lp3eGht9uF4mMCR6YIWz not in ['featured_movies','featured_series']:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if VV7yf2htDCBU6EeSX8TJQM=='#': continue
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,581)
		lO6rM8NcKUL5g4wd31nEGQF7HRfu = QPuHKNAT4jmCRg.findall('showmore" href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if lO6rM8NcKUL5g4wd31nEGQF7HRfu:
			VV7yf2htDCBU6EeSX8TJQM = lO6rM8NcKUL5g4wd31nEGQF7HRfu[0]
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مشاهدة المزيد',VV7yf2htDCBU6EeSX8TJQM,581)
	return
def opLlxOB2dUVZ5JF4j(url,XpxUEd8SkCJHrst3):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHAHIDNEWS-EPISODES-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('nav-seasons"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	items = []
	NGsk3KreLvExPqSh = False
	if kzlepwfG1iEyIJKTY45quXO and not XpxUEd8SkCJHrst3:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for XpxUEd8SkCJHrst3,title in items:
			XpxUEd8SkCJHrst3 = XpxUEd8SkCJHrst3.strip('#')
			if len(items)>1: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,583,'','',XpxUEd8SkCJHrst3)
			else: NGsk3KreLvExPqSh = True
	else: NGsk3KreLvExPqSh = True
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('id="'+XpxUEd8SkCJHrst3+'"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kk73xHNzri1P2wgULMv4sDtoTnybO and NGsk3KreLvExPqSh:
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,582)
		else:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/'+VV7yf2htDCBU6EeSX8TJQM.strip('/')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,582)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHAHIDNEWS-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"Playerholder".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
	if VV7yf2htDCBU6EeSX8TJQM and 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
	hash = VV7yf2htDCBU6EeSX8TJQM.split('hash=')[1]
	FtKo2AMUynNdTaYCljkxOe = hash.split('__')
	FDyrdx4Q9I05kgYEqLBnzN2ZajmR = []
	for aYUdkb9yum7AIeECR25r in FtKo2AMUynNdTaYCljkxOe:
		try:
			aYUdkb9yum7AIeECR25r = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(aYUdkb9yum7AIeECR25r+'=')
			if Nnxm30dfoBWRYpIC7KsQGl: aYUdkb9yum7AIeECR25r = aYUdkb9yum7AIeECR25r.decode('utf8')
			FDyrdx4Q9I05kgYEqLBnzN2ZajmR.append(aYUdkb9yum7AIeECR25r)
		except: pass
	Y4xiULzGTKjb8mulO = '>'.join(FDyrdx4Q9I05kgYEqLBnzN2ZajmR)
	Y4xiULzGTKjb8mulO = Y4xiULzGTKjb8mulO.splitlines()
	if 'farsol' not in str(Y4xiULzGTKjb8mulO):
		for VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO:
			title,VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split(' => ')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		import bcQwT9tl1C
		bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	else:
		title,VV7yf2htDCBU6EeSX8TJQM = Y4xiULzGTKjb8mulO[0].split(' => ')
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+'\n'+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/search.php?keywords='+search
	SPFl6UGK4mrBua(url)
	return
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'GLOBALSEARCH'
JE7QrkmhletLwA0OZXu = '_GLS_'
def hLD0mk9HIuPOz7pw(Q6FbqZ9uIe8v2xaTHhfDCJ,HbqSfZ6m7FAa,OO1XlVPzfQrMTmJv,YSTbrKgPf7NyhIDizB):
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==540: RRMWBwU6pG = YpFfN68PZ132()
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==541: RRMWBwU6pG = lPzkMXoNZ1fD8ngWQY25H(OO1XlVPzfQrMTmJv)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==542: RRMWBwU6pG = W9xjSIRnpzfVyEK8gLFN5QU(OO1XlVPzfQrMTmJv,HbqSfZ6m7FAa,YSTbrKgPf7NyhIDizB)
	elif Q6FbqZ9uIe8v2xaTHhfDCJ==549: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(OO1XlVPzfQrMTmJv)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','بحث جديد','',549)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	nAM2N4BKgqyzEhDZuLbxYovs1r67UW = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'dict','GLOBALSEARCH_SITES')
	if nAM2N4BKgqyzEhDZuLbxYovs1r67UW:
		nAM2N4BKgqyzEhDZuLbxYovs1r67UW = nAM2N4BKgqyzEhDZuLbxYovs1r67UW['__SEQUENCED_COLUMNS__']
		for ddXzLfOuFHBetSC in reversed(nAM2N4BKgqyzEhDZuLbxYovs1r67UW):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',ddXzLfOuFHBetSC,'',549,'','',ddXzLfOuFHBetSC)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(ddXzLfOuFHBetSC):
	if not ddXzLfOuFHBetSC:
		ddXzLfOuFHBetSC = wod1HJ0fnvcTNAX2WIiMu9P()
		if not ddXzLfOuFHBetSC: return
		ddXzLfOuFHBetSC = ddXzLfOuFHBetSC.lower()
	tip0WLfYmxEnD8lQIFTNBS = ddXzLfOuFHBetSC.replace(JE7QrkmhletLwA0OZXu,'')
	sckeiU8ovlRqm(tip0WLfYmxEnD8lQIFTNBS)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','عمل بحث جماعي - '+tip0WLfYmxEnD8lQIFTNBS,'search_sites',542,'','',tip0WLfYmxEnD8lQIFTNBS)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','نتائج البحث مفصلة - '+tip0WLfYmxEnD8lQIFTNBS,'opened_sites',542,'','',tip0WLfYmxEnD8lQIFTNBS)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','نتائج البحث مقسمة - '+tip0WLfYmxEnD8lQIFTNBS,'listed_sites',542,'','',tip0WLfYmxEnD8lQIFTNBS)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','بحث منفرد - '+tip0WLfYmxEnD8lQIFTNBS,'',541,'','',tip0WLfYmxEnD8lQIFTNBS)
	return
def sckeiU8ovlRqm(JJNE7dpRt4YQlKubIF8D9hiPBwj):
	mZ84P9AG0TWVK = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','GLOBALSEARCH_SITES',JJNE7dpRt4YQlKubIF8D9hiPBwj)
	khpfFuSTly3qX2m0HEjON = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','GLOBALSEARCH_SITES',JE7QrkmhletLwA0OZXu+JJNE7dpRt4YQlKubIF8D9hiPBwj)
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_SITES',JJNE7dpRt4YQlKubIF8D9hiPBwj)
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_SITES',JE7QrkmhletLwA0OZXu+JJNE7dpRt4YQlKubIF8D9hiPBwj)
	lANRoFmcZ4a2CIpQeT7W5kyJ3 = mZ84P9AG0TWVK+khpfFuSTly3qX2m0HEjON
	if lANRoFmcZ4a2CIpQeT7W5kyJ3: JJNE7dpRt4YQlKubIF8D9hiPBwj = JE7QrkmhletLwA0OZXu+JJNE7dpRt4YQlKubIF8D9hiPBwj
	mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_SITES',JJNE7dpRt4YQlKubIF8D9hiPBwj,lANRoFmcZ4a2CIpQeT7W5kyJ3,kkvBdWcON7RZoMJDr0YjmLE1)
	return
def Qz7ke2rZDJNlGjhn0fx9qOH():
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if T4TGmZ9XWAzONaKygic!=1: return
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_SITES')
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_OPENED')
	QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_CLOSED')
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def W9xjSIRnpzfVyEK8gLFN5QU(MKZEzsoR8CgalJQvDjAd1pFGcr5fmi,uFdLJamfxYr5P86DWo7ik0gRA,Xt7olBPDuFS4diy1=''):
	dCo7xQbevpUt2OIVH,ggGIcp9NUAqr,XNCJ8h5VIRDolbxwk1,tkYWN8gvodeiDbUMH,MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G,mdGY3VDXNBCySoqJHIAvcjzsanwR,nnSuN2dObFiGflhcgRE8Z0HpqM = [],[],[],{},{},{},{}
	if uFdLJamfxYr5P86DWo7ik0gRA!='search_sites':
		if uFdLJamfxYr5P86DWo7ik0gRA=='listed_sites': XNCJ8h5VIRDolbxwk1 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','GLOBALSEARCH_SITES',JE7QrkmhletLwA0OZXu+MKZEzsoR8CgalJQvDjAd1pFGcr5fmi)
		elif uFdLJamfxYr5P86DWo7ik0gRA=='opened_sites': XNCJ8h5VIRDolbxwk1 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','GLOBALSEARCH_OPENED',MKZEzsoR8CgalJQvDjAd1pFGcr5fmi)
		elif uFdLJamfxYr5P86DWo7ik0gRA=='closed_sites': XNCJ8h5VIRDolbxwk1 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,'list','GLOBALSEARCH_CLOSED',(Xt7olBPDuFS4diy1,MKZEzsoR8CgalJQvDjAd1pFGcr5fmi))
	if not XNCJ8h5VIRDolbxwk1:
		GhpNfPVMB2uRnqasFL6K = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		fl57MHCK8LhbtieNY0QUck4AO = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+MKZEzsoR8CgalJQvDjAd1pFGcr5fmi+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if uFdLJamfxYr5P86DWo7ik0gRA=='search_sites': qNEnDMwm1Vfastx2ZkpRh = fl57MHCK8LhbtieNY0QUck4AO
		else: qNEnDMwm1Vfastx2ZkpRh = GhpNfPVMB2uRnqasFL6K+fl57MHCK8LhbtieNY0QUck4AO
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7('','','','رسالة من المبرمج',qNEnDMwm1Vfastx2ZkpRh)
		if T4TGmZ9XWAzONaKygic!=1: return
		iBTbm82l5KZSGJN6t3(False,False,False)
		zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Search For: [ '+MKZEzsoR8CgalJQvDjAd1pFGcr5fmi+' ]')
		vg3iVMQSpXlsdKWRTkGrEFt4Hm = 1
		for Xt7olBPDuFS4diy1 in BF5e4E9xmzQ81di03DUcPWsaKupgrq:
			tkYWN8gvodeiDbUMH[Xt7olBPDuFS4diy1] = []
			W7d5UaTJVnySIM6OQ3fXi = '_NODIALOGS_'
			if '-' in Xt7olBPDuFS4diy1: W7d5UaTJVnySIM6OQ3fXi = W7d5UaTJVnySIM6OQ3fXi+'_REMEMBERRESULTS__'+Xt7olBPDuFS4diy1+'_'
			ZQGzeTEil79pbsCtauf,Z1wMTVKApbNvinskL7,EYNDrC48cOLIKeUdq7ju0ptikxTSv = tfuri9cjL3JEgaOMPlynH0sUhW25(Xt7olBPDuFS4diy1)
			if vg3iVMQSpXlsdKWRTkGrEFt4Hm:
				vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(0.5)
				nnSuN2dObFiGflhcgRE8Z0HpqM[Xt7olBPDuFS4diy1] = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=Z1wMTVKApbNvinskL7,args=(MKZEzsoR8CgalJQvDjAd1pFGcr5fmi+W7d5UaTJVnySIM6OQ3fXi,))
				nnSuN2dObFiGflhcgRE8Z0HpqM[Xt7olBPDuFS4diy1].start()
			else: Z1wMTVKApbNvinskL7(MKZEzsoR8CgalJQvDjAd1pFGcr5fmi+W7d5UaTJVnySIM6OQ3fXi)
			uFCykYQW68S(S6YzAlHWcCwJI18(Xt7olBPDuFS4diy1),'',vODi7LQeCnUaoRqZX9xs6djwm0tJA2=1000)
		if vg3iVMQSpXlsdKWRTkGrEFt4Hm:
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(2)
			for Xt7olBPDuFS4diy1 in BF5e4E9xmzQ81di03DUcPWsaKupgrq:
				nnSuN2dObFiGflhcgRE8Z0HpqM[Xt7olBPDuFS4diy1].join(10)
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(2)
		for Xt7olBPDuFS4diy1 in BF5e4E9xmzQ81di03DUcPWsaKupgrq:
			ZQGzeTEil79pbsCtauf,Z1wMTVKApbNvinskL7,EYNDrC48cOLIKeUdq7ju0ptikxTSv = tfuri9cjL3JEgaOMPlynH0sUhW25(Xt7olBPDuFS4diy1)
			for ymraFo65GxbqVg8YeLHct4Zl2 in vvruH9wsBDfbhFtyq1MUd2zV:
				ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 = ymraFo65GxbqVg8YeLHct4Zl2
				if EYNDrC48cOLIKeUdq7ju0ptikxTSv in pphVUbJkGtHXndg84iZl2DPImSzoC:
					if 'IPTV-' in Xt7olBPDuFS4diy1 and (239>=Q6FbqZ9uIe8v2xaTHhfDCJ>=230 or 289>=Q6FbqZ9uIe8v2xaTHhfDCJ>=280):
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['IPTV-LIVE']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['IPTV-MOVIES']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['IPTV-SERIES']: continue
						if 'صفحة' not in pphVUbJkGtHXndg84iZl2DPImSzoC:
							if   ghLJETx5pD7=='live': Xt7olBPDuFS4diy1 = 'IPTV-LIVE'
							elif ghLJETx5pD7=='video': Xt7olBPDuFS4diy1 = 'IPTV-MOVIES'
							elif ghLJETx5pD7=='folder': Xt7olBPDuFS4diy1 = 'IPTV-SERIES'
						else:
							if   'LIVE' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'IPTV-LIVE'
							elif 'MOVIES' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'IPTV-MOVIES'
							elif 'SERIES' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'IPTV-SERIES'
					elif 'M3U-' in Xt7olBPDuFS4diy1 and 729>=Q6FbqZ9uIe8v2xaTHhfDCJ>=710:
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['M3U-LIVE']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['M3U-MOVIES']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['M3U-SERIES']: continue
						if 'صفحة' not in pphVUbJkGtHXndg84iZl2DPImSzoC:
							if   ghLJETx5pD7=='live': Xt7olBPDuFS4diy1 = 'M3U-LIVE'
							elif ghLJETx5pD7=='video': Xt7olBPDuFS4diy1 = 'M3U-MOVIES'
							elif ghLJETx5pD7=='folder': Xt7olBPDuFS4diy1 = 'M3U-SERIES'
						else:
							if   'LIVE' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'M3U-LIVE'
							elif 'MOVIES' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'M3U-MOVIES'
							elif 'SERIES' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'M3U-SERIES'
					elif 'YOUTUBE-' in Xt7olBPDuFS4diy1 and 149>=Q6FbqZ9uIe8v2xaTHhfDCJ>=140:
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['YOUTUBE-CHANNELS']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['YOUTUBE-PLAYLISTS']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in pphVUbJkGtHXndg84iZl2DPImSzoC or ':: ' in pphVUbJkGtHXndg84iZl2DPImSzoC:
							continue
						else:
							if   Q6FbqZ9uIe8v2xaTHhfDCJ==144 and 'USER' in pphVUbJkGtHXndg84iZl2DPImSzoC: Xt7olBPDuFS4diy1 = 'YOUTUBE-CHANNELS'
							elif Q6FbqZ9uIe8v2xaTHhfDCJ==144 and 'CHNL' in pphVUbJkGtHXndg84iZl2DPImSzoC: Xt7olBPDuFS4diy1 = 'YOUTUBE-CHANNELS'
							elif Q6FbqZ9uIe8v2xaTHhfDCJ==144 and 'LIST' in pphVUbJkGtHXndg84iZl2DPImSzoC: Xt7olBPDuFS4diy1 = 'YOUTUBE-PLAYLISTS'
							elif Q6FbqZ9uIe8v2xaTHhfDCJ==143: Xt7olBPDuFS4diy1 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in Xt7olBPDuFS4diy1 and 419>=Q6FbqZ9uIe8v2xaTHhfDCJ>=400:
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['DAILYMOTION-PLAYLISTS']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['DAILYMOTION-CHANNELS']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['DAILYMOTION-VIDEOS']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['DAILYMOTION-TOPICS']: continue
						if   Q6FbqZ9uIe8v2xaTHhfDCJ in [401,405]: Xt7olBPDuFS4diy1 = 'DAILYMOTION-PLAYLISTS'
						elif Q6FbqZ9uIe8v2xaTHhfDCJ in [402,406]: Xt7olBPDuFS4diy1 = 'DAILYMOTION-CHANNELS'
						elif Q6FbqZ9uIe8v2xaTHhfDCJ in [404]: Xt7olBPDuFS4diy1 = 'DAILYMOTION-VIDEOS'
						elif Q6FbqZ9uIe8v2xaTHhfDCJ in [415]: Xt7olBPDuFS4diy1 = 'DAILYMOTION-LIVES'
						elif Q6FbqZ9uIe8v2xaTHhfDCJ in [412,413]: Xt7olBPDuFS4diy1 = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in Xt7olBPDuFS4diy1 and 39>=Q6FbqZ9uIe8v2xaTHhfDCJ>=30:
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['PANET-SERIES']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['PANET-MOVIES']: continue
						if   Q6FbqZ9uIe8v2xaTHhfDCJ in [32,39]: Xt7olBPDuFS4diy1 = 'PANET-SERIES'
						elif Q6FbqZ9uIe8v2xaTHhfDCJ in [33,39]: Xt7olBPDuFS4diy1 = 'PANET-MOVIES'
					elif 'IFILM-' in Xt7olBPDuFS4diy1 and 29>=Q6FbqZ9uIe8v2xaTHhfDCJ>=20:
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['IFILM-ARABIC']: continue
						if ymraFo65GxbqVg8YeLHct4Zl2 in tkYWN8gvodeiDbUMH['IFILM-ENGLISH']: continue
						if   '/ar.' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'IFILM-ARABIC'
						elif '/en.' in HbqSfZ6m7FAa: Xt7olBPDuFS4diy1 = 'IFILM-ENGLISH'
					tkYWN8gvodeiDbUMH[Xt7olBPDuFS4diy1].append(ymraFo65GxbqVg8YeLHct4Zl2)
		vvruH9wsBDfbhFtyq1MUd2zV[:] = []
		for Xt7olBPDuFS4diy1 in list(tkYWN8gvodeiDbUMH.keys()):
			MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G[Xt7olBPDuFS4diy1] = []
			mdGY3VDXNBCySoqJHIAvcjzsanwR[Xt7olBPDuFS4diy1] = []
			for ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in tkYWN8gvodeiDbUMH[Xt7olBPDuFS4diy1]:
				ymraFo65GxbqVg8YeLHct4Zl2 = (ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2)
				if 'صفحة' in pphVUbJkGtHXndg84iZl2DPImSzoC and ghLJETx5pD7=='folder': mdGY3VDXNBCySoqJHIAvcjzsanwR[Xt7olBPDuFS4diy1].append(ymraFo65GxbqVg8YeLHct4Zl2)
				else: MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G[Xt7olBPDuFS4diy1].append(ymraFo65GxbqVg8YeLHct4Zl2)
		ppUGhEiFONL2kfIRJu1zQaWBSmMHD = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for Xt7olBPDuFS4diy1 in piQDKyzne4fXxP7MCqv5lTUOZ:
			if Xt7olBPDuFS4diy1==lu0Fg2DL3MR[0]: ppUGhEiFONL2kfIRJu1zQaWBSmMHD = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif Xt7olBPDuFS4diy1==e0qL2XFIxmo3YGW[0]: ppUGhEiFONL2kfIRJu1zQaWBSmMHD = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif Xt7olBPDuFS4diy1==RVHbUrThqOLfY4u27mB[0]: ppUGhEiFONL2kfIRJu1zQaWBSmMHD = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if Xt7olBPDuFS4diy1 not in MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G.keys(): continue
			if MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G[Xt7olBPDuFS4diy1]:
				ohvtNjg0T9VE86JKHY4n2WyPXae5 = S6YzAlHWcCwJI18(Xt7olBPDuFS4diy1)
				omJtxEM0l7 = [('link','[COLOR FFFFFF00]===== '+ohvtNjg0T9VE86JKHY4n2WyPXae5+' =====[/COLOR]','',9999,'','','','','')]
				if 0: ii9czW7YVD0nemLt = MKZEzsoR8CgalJQvDjAd1pFGcr5fmi+' - '+'بحث'+' '+ohvtNjg0T9VE86JKHY4n2WyPXae5
				else: ii9czW7YVD0nemLt = 'بحث'+' '+ohvtNjg0T9VE86JKHY4n2WyPXae5+' - '+MKZEzsoR8CgalJQvDjAd1pFGcr5fmi
				if len(MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G[Xt7olBPDuFS4diy1])<8: B4WRsJbohU2ZnHxfzAwY0SFNgcje = []
				else:
					dNBwISzsjXeLlypHC8nFiJ = '[COLOR FFC89008]'+ii9czW7YVD0nemLt+'[/COLOR]'
					B4WRsJbohU2ZnHxfzAwY0SFNgcje = [('folder',JE7QrkmhletLwA0OZXu+dNBwISzsjXeLlypHC8nFiJ,'closed_sites',542,'',Xt7olBPDuFS4diy1,MKZEzsoR8CgalJQvDjAd1pFGcr5fmi,'','')]
				FVgMxqDPzke4TJBEbLmrlj9XA12f = MCQmNn0dZ3Dfqr2lXk16wKzFuRjB7G[Xt7olBPDuFS4diy1]+mdGY3VDXNBCySoqJHIAvcjzsanwR[Xt7olBPDuFS4diy1]
				ggGIcp9NUAqr += ppUGhEiFONL2kfIRJu1zQaWBSmMHD+omJtxEM0l7+FVgMxqDPzke4TJBEbLmrlj9XA12f[:7]+B4WRsJbohU2ZnHxfzAwY0SFNgcje
				VkyQuC7EZXHLh = [('folder',JE7QrkmhletLwA0OZXu+ii9czW7YVD0nemLt,'closed_sites',542,'',Xt7olBPDuFS4diy1,MKZEzsoR8CgalJQvDjAd1pFGcr5fmi,'','')]
				dCo7xQbevpUt2OIVH += ppUGhEiFONL2kfIRJu1zQaWBSmMHD+VkyQuC7EZXHLh
				ppUGhEiFONL2kfIRJu1zQaWBSmMHD = []
				mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_CLOSED',(Xt7olBPDuFS4diy1,MKZEzsoR8CgalJQvDjAd1pFGcr5fmi),FVgMxqDPzke4TJBEbLmrlj9XA12f,kkvBdWcON7RZoMJDr0YjmLE1)
		mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_OPENED',MKZEzsoR8CgalJQvDjAd1pFGcr5fmi,ggGIcp9NUAqr,kkvBdWcON7RZoMJDr0YjmLE1)
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_SITES',MKZEzsoR8CgalJQvDjAd1pFGcr5fmi)
		mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,'GLOBALSEARCH_SITES',JE7QrkmhletLwA0OZXu+MKZEzsoR8CgalJQvDjAd1pFGcr5fmi,dCo7xQbevpUt2OIVH,kkvBdWcON7RZoMJDr0YjmLE1)
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if uFdLJamfxYr5P86DWo7ik0gRA=='listed_sites' and dCo7xQbevpUt2OIVH: XNCJ8h5VIRDolbxwk1 = dCo7xQbevpUt2OIVH
		else: XNCJ8h5VIRDolbxwk1 = ggGIcp9NUAqr
	if uFdLJamfxYr5P86DWo7ik0gRA!='search_sites':
		for ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2 in XNCJ8h5VIRDolbxwk1:
			if uFdLJamfxYr5P86DWo7ik0gRA in ['listed_sites','opened_sites'] and 'صفحة' in pphVUbJkGtHXndg84iZl2DPImSzoC and ghLJETx5pD7=='folder': continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB(ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,OO1XlVPzfQrMTmJv,ja74FTtz9hK,RkfstxEyua67K2)
	iBTbm82l5KZSGJN6t3('','','')
	return
def lPzkMXoNZ1fD8ngWQY25H(MKZEzsoR8CgalJQvDjAd1pFGcr5fmi=''):
	ddXzLfOuFHBetSC,W7d5UaTJVnySIM6OQ3fXi,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(MKZEzsoR8CgalJQvDjAd1pFGcr5fmi)
	if not ddXzLfOuFHBetSC:
		ddXzLfOuFHBetSC = wod1HJ0fnvcTNAX2WIiMu9P()
		if not ddXzLfOuFHBetSC: return
		ddXzLfOuFHBetSC = ddXzLfOuFHBetSC.lower()
	zRM3tZx2v6DjJU('NOTICE',Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+'   Search For: [ '+ddXzLfOuFHBetSC+' ]')
	Unr6jRmMIv80lSGbkBCehpaWAdV = ddXzLfOuFHBetSC+W7d5UaTJVnySIM6OQ3fXi
	if 0: SACEZ7y69TpRkJuXOzg,tip0WLfYmxEnD8lQIFTNBS = ddXzLfOuFHBetSC+' - ',''
	else: SACEZ7y69TpRkJuXOzg,tip0WLfYmxEnD8lQIFTNBS = '',' - '+ddXzLfOuFHBetSC
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_M3U_'+SACEZ7y69TpRkJuXOzg+'بحث M3U'+tip0WLfYmxEnD8lQIFTNBS,'',719,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_IPT_'+SACEZ7y69TpRkJuXOzg+'بحث IPTV'+tip0WLfYmxEnD8lQIFTNBS,'',239,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_BKR_'+SACEZ7y69TpRkJuXOzg+'بحث موقع بكرا'+tip0WLfYmxEnD8lQIFTNBS,'',379,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_KLA_'+SACEZ7y69TpRkJuXOzg+'بحث موقع كل العرب'+tip0WLfYmxEnD8lQIFTNBS,'',19,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_ART_'+SACEZ7y69TpRkJuXOzg+'بحث موقع تونز عربية'+tip0WLfYmxEnD8lQIFTNBS,'',739,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_KRB_'+SACEZ7y69TpRkJuXOzg+'بحث موقع قناة كربلاء'+tip0WLfYmxEnD8lQIFTNBS,'',329,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_FH1_'+SACEZ7y69TpRkJuXOzg+'بحث موقع فاصل الأول'+tip0WLfYmxEnD8lQIFTNBS,'',579,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_KTV_'+SACEZ7y69TpRkJuXOzg+'بحث موقع كتكوت تيفي'+tip0WLfYmxEnD8lQIFTNBS,'',819,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_EB1_'+SACEZ7y69TpRkJuXOzg+'بحث موقع ايجي بيست 1'+tip0WLfYmxEnD8lQIFTNBS,'',779,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_EB2_'+SACEZ7y69TpRkJuXOzg+'بحث موقع ايجي بيست 2'+tip0WLfYmxEnD8lQIFTNBS,'',789,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_IFL_'+SACEZ7y69TpRkJuXOzg+'  بحث موقع قناة آي فيلم'+tip0WLfYmxEnD8lQIFTNBS+'  ','',29,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_AKO_'+SACEZ7y69TpRkJuXOzg+'بحث موقع أكوام القديم'+tip0WLfYmxEnD8lQIFTNBS,'',79,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_AKW_'+SACEZ7y69TpRkJuXOzg+'بحث موقع أكوام الجديد'+tip0WLfYmxEnD8lQIFTNBS,'',249,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_MRF_'+SACEZ7y69TpRkJuXOzg+'بحث موقع قناة المعارف'+tip0WLfYmxEnD8lQIFTNBS,'',49,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_SHM_'+SACEZ7y69TpRkJuXOzg+'بحث موقع شوف ماكس'+tip0WLfYmxEnD8lQIFTNBS,'',59,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_FJS_'+SACEZ7y69TpRkJuXOzg+' بحث موقع فجر شو'+tip0WLfYmxEnD8lQIFTNBS+' ','',399,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_TVF_'+SACEZ7y69TpRkJuXOzg+'بحث موقع تيفي فان'+tip0WLfYmxEnD8lQIFTNBS,'',469,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_LDN_'+SACEZ7y69TpRkJuXOzg+'بحث موقع لودي نت'+tip0WLfYmxEnD8lQIFTNBS,'',459,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_CMN_'+SACEZ7y69TpRkJuXOzg+'بحث موقع سيما ناو'+tip0WLfYmxEnD8lQIFTNBS,'',309,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_WCM_'+SACEZ7y69TpRkJuXOzg+'بحث موقع وي سيما'+tip0WLfYmxEnD8lQIFTNBS,'',569,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_SHN_'+SACEZ7y69TpRkJuXOzg+'بحث موقع شاهد نيوز'+tip0WLfYmxEnD8lQIFTNBS,'',589,'','',Unr6jRmMIv80lSGbkBCehpaWAdV+'_NODIALOGS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_ARS_'+SACEZ7y69TpRkJuXOzg+'بحث موقع عرب سييد'+tip0WLfYmxEnD8lQIFTNBS,'',259,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_CCB_'+SACEZ7y69TpRkJuXOzg+'بحث موقع سيما كلوب'+tip0WLfYmxEnD8lQIFTNBS,'',829,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_SH4_'+SACEZ7y69TpRkJuXOzg+'بحث موقع شاهد فوريو'+tip0WLfYmxEnD8lQIFTNBS,'',119,'','',Unr6jRmMIv80lSGbkBCehpaWAdV+'_NODIALOGS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_SHT_'+SACEZ7y69TpRkJuXOzg+'بحث موقع شوفها تيفي'+tip0WLfYmxEnD8lQIFTNBS,'',649,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_FST_'+SACEZ7y69TpRkJuXOzg+'بحث موقع فوستا'+tip0WLfYmxEnD8lQIFTNBS,'',609,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_FBK_'+SACEZ7y69TpRkJuXOzg+'بحث موقع فبركة'+tip0WLfYmxEnD8lQIFTNBS,'',629,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_YQT_'+SACEZ7y69TpRkJuXOzg+'بحث موقع ياقوت'+tip0WLfYmxEnD8lQIFTNBS,'',669,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_BRS_'+SACEZ7y69TpRkJuXOzg+'بحث موقع برستيج'+tip0WLfYmxEnD8lQIFTNBS,'',659,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_HLC_'+SACEZ7y69TpRkJuXOzg+'بحث موقع هلا سيما'+tip0WLfYmxEnD8lQIFTNBS,'',89,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_DR7_'+SACEZ7y69TpRkJuXOzg+'بحث موقع دراما صح'+tip0WLfYmxEnD8lQIFTNBS,'',689,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_CMF_'+SACEZ7y69TpRkJuXOzg+'بحث موقع سيما فانز'+tip0WLfYmxEnD8lQIFTNBS,'',99,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_CML_'+SACEZ7y69TpRkJuXOzg+'بحث موقع سيما لايت'+tip0WLfYmxEnD8lQIFTNBS,'',479,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_ABD_'+SACEZ7y69TpRkJuXOzg+'بحث موقع سيما عبدو'+tip0WLfYmxEnD8lQIFTNBS,'',559,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_C4H_'+SACEZ7y69TpRkJuXOzg+'بحث موقع سيما 400'+tip0WLfYmxEnD8lQIFTNBS,'',699,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_AHK_'+SACEZ7y69TpRkJuXOzg+'بحث موقع أهواك تيفي'+tip0WLfYmxEnD8lQIFTNBS,'',619,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_EB4_'+SACEZ7y69TpRkJuXOzg+'بحث موقع ايجي بيست 4'+tip0WLfYmxEnD8lQIFTNBS,'',809,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_YUT_'+SACEZ7y69TpRkJuXOzg+'بحث موقع يوتيوب'+tip0WLfYmxEnD8lQIFTNBS,'',149,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder','_DLM_'+SACEZ7y69TpRkJuXOzg+'بحث موقع ديلي موشن'+tip0WLfYmxEnD8lQIFTNBS,'',409,'','',Unr6jRmMIv80lSGbkBCehpaWAdV)
	return
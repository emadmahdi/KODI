# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'EGYBEST4'
JE7QrkmhletLwA0OZXu = '_EB4_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def hLD0mk9HIuPOz7pw(mode,url,YSTbrKgPf7NyhIDizB,text):
	if   mode==800: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==801: RRMWBwU6pG = SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB)
	elif mode==802: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==803: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==804: RRMWBwU6pG = d3HBGsTc79uQvXE0iVamKL5rpOS(url)
	elif mode==806: RRMWBwU6pG = o9LaYpVR1wKx3IGuHS(url,YSTbrKgPf7NyhIDizB)
	elif mode==809: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر',GqcEfFR8XQPgBMLr+'/trending',804,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','EGYBEST4-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('nav-categories(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('mainContent(.*?)<footer>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801,'','mainmenu')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-menu(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801)
	return Ht6Gg8lbciAd9FaUQVs
def o9LaYpVR1wKx3IGuHS(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('mainTitle.*?>(.*?)<(.*?)pageContent',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		Q1WJvEwGdh2mPfct9SKa,jN1v92PmCGquRbcl,items = '','',[]
		for name,wltPGJcYo12Ed in TTCRYZroizb:
			if 'حلقات' in name: jN1v92PmCGquRbcl = wltPGJcYo12Ed
			if 'مواسم' in name: Q1WJvEwGdh2mPfct9SKa = wltPGJcYo12Ed
		if Q1WJvEwGdh2mPfct9SKa and not type:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',Q1WJvEwGdh2mPfct9SKa,QPuHKNAT4jmCRg.DOTALL)
			if len(items)>1:
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,806,G2WR0Oacvdq8ZQTjKboDU,'season')
		if jN1v92PmCGquRbcl and len(items)<2:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',jN1v92PmCGquRbcl,QPuHKNAT4jmCRg.DOTALL)
			if items:
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,803,G2WR0Oacvdq8ZQTjKboDU)
			else:
				items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',jN1v92PmCGquRbcl,QPuHKNAT4jmCRg.DOTALL)
				for VV7yf2htDCBU6EeSX8TJQM,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,803)
	return
def SPFl6UGK4mrBua(url,type=''):
	jt48CzhPJ7Y19r5kBGfH2eZ,start,bnZAcrOuJCM5z30RWQmlEYgqoLk,select,DD1CtsHA8WdUEXVJgPi5y = 0,0,'','',''
	if 'pagination' in type:
		umtfFbLz9slJ8rOed4kKMaIHyj05RG,BF8XfchlgKmOE0ru2 = url.split('?next=page&')
		Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',umtfFbLz9slJ8rOed4kKMaIHyj05RG,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','EGYBEST4-TITLES-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		iRSILm7Nv6DZAaztp = 'secContent'+Ht6Gg8lbciAd9FaUQVs+'<footer>'
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		iRSILm7Nv6DZAaztp = Ht6Gg8lbciAd9FaUQVs
	items,tX4e9uQrjYwl3I,JWVlUxnpBbjv20w7 = [],False,False
	if not type and '/collections' not in url:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('mainContent(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = title.strip(' ')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801,'','submenu')
				tX4e9uQrjYwl3I = True
	if not tX4e9uQrjYwl3I:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('secContent(.*?)mainContent',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
				VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
				G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.strip('\n')
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				if '/series/' in VV7yf2htDCBU6EeSX8TJQM and type=='season': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,806,G2WR0Oacvdq8ZQTjKboDU,'season')
				elif '/series/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,806,G2WR0Oacvdq8ZQTjKboDU)
				elif '/seasons/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801,G2WR0Oacvdq8ZQTjKboDU,'season')
				elif '/collections' in url: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801,G2WR0Oacvdq8ZQTjKboDU,'collections')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,803,G2WR0Oacvdq8ZQTjKboDU)
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('loadMoreParams = (.*?);',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			kZtLuzN78xvem53 = kMLWTt2fO9dnGDUgHh('dict',wltPGJcYo12Ed)
			DD1CtsHA8WdUEXVJgPi5y = kZtLuzN78xvem53['ajaxurl']
			VpolhzO6Kj = int(kZtLuzN78xvem53['current_page'])+1
			mdY2uAc9ipN3I8JOPj0n = int(kZtLuzN78xvem53['max_page'])
			kAfTxWCXOotKHaG2 = kZtLuzN78xvem53['posts'].replace('False','false').replace('True','true').replace('None','null')
			if VpolhzO6Kj<mdY2uAc9ipN3I8JOPj0n:
				BF8XfchlgKmOE0ru2 = 'action=loadmore&query='+oF0Yr4V7Ic(kAfTxWCXOotKHaG2,'')+'&page='+str(VpolhzO6Kj)
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = DD1CtsHA8WdUEXVJgPi5y+'?next=page&'+BF8XfchlgKmOE0ru2
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'جلب المزيد',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,801,'','pagination_'+type)
		elif '?next=page&' in url:
			BF8XfchlgKmOE0ru2,MtNlbVreA4UswLKIiBa9fQ = BF8XfchlgKmOE0ru2.rsplit('=',1)
			MtNlbVreA4UswLKIiBa9fQ = int(MtNlbVreA4UswLKIiBa9fQ)+1
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = umtfFbLz9slJ8rOed4kKMaIHyj05RG+'?next=page&'+BF8XfchlgKmOE0ru2+'='+str(MtNlbVreA4UswLKIiBa9fQ)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'جلب المزيد',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,801,'','pagination_'+type)
	return
def d3HBGsTc79uQvXE0iVamKL5rpOS(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('sub_nav(.*?)secContent ',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('"current_opt">(.*?)<(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for name,wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,pp8iHB3W9Cs in items:
				title = name+':  '+pp8iHB3W9Cs
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,801,'','filter')
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('<td>التصنيف</td>.*?">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	YsDryBSXquzdEUta8kxjfO,uuonPvOwRZp90QJh = [],[]
	xEifcBA3nmFzkNPVRC04 = QPuHKNAT4jmCRg.findall('postEmbed.*?post=(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if xEifcBA3nmFzkNPVRC04:
		Y4xiULzGTKjb8mulO = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(xEifcBA3nmFzkNPVRC04[0])
		if Nnxm30dfoBWRYpIC7KsQGl: Y4xiULzGTKjb8mulO = Y4xiULzGTKjb8mulO.decode('utf8')
		Y4xiULzGTKjb8mulO = kMLWTt2fO9dnGDUgHh('dict',Y4xiULzGTKjb8mulO)
		Y4xiULzGTKjb8mulO = list(Y4xiULzGTKjb8mulO.values())
		for VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO:
			if VV7yf2htDCBU6EeSX8TJQM not in uuonPvOwRZp90QJh:
				uuonPvOwRZp90QJh.append(VV7yf2htDCBU6EeSX8TJQM)
				BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+BHgLX9GZTb2jJrWiNKE+'__watch')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('pageContentDown(.*?)</table>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for i5DftlhA6vQ2GF,VV7yf2htDCBU6EeSX8TJQM in items:
			if VV7yf2htDCBU6EeSX8TJQM not in uuonPvOwRZp90QJh:
				if '/?url=' in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('/?url=')[1]
				uuonPvOwRZp90QJh.append(VV7yf2htDCBU6EeSX8TJQM)
				BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+BHgLX9GZTb2jJrWiNKE+'__download____'+i5DftlhA6vQ2GF)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search: search = wod1HJ0fnvcTNAX2WIiMu9P()
	if not search: return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/?s='+Unr6jRmMIv80lSGbkBCehpaWAdV
	SPFl6UGK4mrBua(url,'search')
	return
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'WECIMA'
headers = {'User-Agent':''}
JE7QrkmhletLwA0OZXu = '_WCM_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['مصارعة حرة','wwe']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==560: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==561: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==562: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==563: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,text)
	elif mode==564: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'CATEGORIES___'+text)
	elif mode==565: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'FILTERS___'+text)
	elif mode==566: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==569: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text,url)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع',GqcEfFR8XQPgBMLr,569,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',GqcEfFR8XQPgBMLr+'/AjaxCenter/RightBar',564)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',GqcEfFR8XQPgBMLr+'/AjaxCenter/RightBar',565)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','WECIMA-MENU-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('class="menu-item.*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title=='': continue
			if any(pp8iHB3W9Cs in title.lower() for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,566)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('hoverable activable(.*?)hoverable activable',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,566,G2WR0Oacvdq8ZQTjKboDU)
	return Ht6Gg8lbciAd9FaUQVs
def pF0d4b2ZY9(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'','','','','WECIMA-SUBMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if 'class="Slider--Grid"' in Ht6Gg8lbciAd9FaUQVs:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',url,561,'','','featured')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="list--Tabsui"(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,561)
	return
def SPFl6UGK4mrBua(wwtDgAROoBVI2sKzP97N,type=''):
	if '::' in wwtDgAROoBVI2sKzP97N:
		lc154VhT9DCqMk8,url = wwtDgAROoBVI2sKzP97N.split('::')
		BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lc154VhT9DCqMk8,'url')
		url = BHgLX9GZTb2jJrWiNKE+url
	else: url,lc154VhT9DCqMk8 = wwtDgAROoBVI2sKzP97N,wwtDgAROoBVI2sKzP97N
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','WECIMA-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if type=='featured':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	elif type in ['filters','search']:
		TTCRYZroizb = [Ht6Gg8lbciAd9FaUQVs.replace('\\/','/').replace('\\"','"')]
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"Grid--WecimaPosts"(.*?)"RightUI"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
			if any(pp8iHB3W9Cs in title.lower() for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			G2WR0Oacvdq8ZQTjKboDU = kWfpQA7tTjSPyLbNIeMr1Hui5(G2WR0Oacvdq8ZQTjKboDU)
			VV7yf2htDCBU6EeSX8TJQM = kWfpQA7tTjSPyLbNIeMr1Hui5(VV7yf2htDCBU6EeSX8TJQM)
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = kWfpQA7tTjSPyLbNIeMr1Hui5(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,563,G2WR0Oacvdq8ZQTjKboDU)
			elif 'حلقة' in title:
				CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) +حلقة +\d+',title,QPuHKNAT4jmCRg.DOTALL)
				if CiZxgXTGW9pv: title = '_MOD_' + CiZxgXTGW9pv[0]
				if title not in gltHFKTroJfpLe:
					gltHFKTroJfpLe.append(title)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,563,G2WR0Oacvdq8ZQTjKboDU)
			else:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,562,G2WR0Oacvdq8ZQTjKboDU)
		if type=='filters':
			VpolhzO6Kj = QPuHKNAT4jmCRg.findall('"more_button_page":(.*?),',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if VpolhzO6Kj:
				count = VpolhzO6Kj[0]
				VV7yf2htDCBU6EeSX8TJQM = url+'/offset/'+count
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة أخرى',VV7yf2htDCBU6EeSX8TJQM,561,'','','filters')
		elif type=='':
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if TTCRYZroizb:
				wltPGJcYo12Ed = TTCRYZroizb[0]
				items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				for VV7yf2htDCBU6EeSX8TJQM,title in items:
					if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
					title = 'صفحة '+UH1IuvwM9e4cl7if63nNdozJFSj(title)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,561)
	return
def opLlxOB2dUVZ5JF4j(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','WECIMA-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Ht6Gg8lbciAd9FaUQVs = NdVvO42riJpCWElX(Ht6Gg8lbciAd9FaUQVs)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="Seasons--Episodes"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not type and TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if len(items)>1:
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,563,'','','episodes')
			return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,562)
	if not vvruH9wsBDfbhFtyq1MUd2zV:
		title = QPuHKNAT4jmCRg.findall('<title>(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,url,562)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','WECIMA-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy:
		KQMJtrow90bCy = [KQMJtrow90bCy[0][0],KQMJtrow90bCy[0][1]]
		if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('data-url="(.*?)".*?strong>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name in items:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if name=='سيرفر وي سيما': name = 'wecima'
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__watch'
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\n','').replace('\r','')
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="List--Download(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,i5DftlhA6vQ2GF in items:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			i5DftlhA6vQ2GF = QPuHKNAT4jmCRg.findall('\d\d\d+',i5DftlhA6vQ2GF,QPuHKNAT4jmCRg.DOTALL)
			if i5DftlhA6vQ2GF: i5DftlhA6vQ2GF = '____'+i5DftlhA6vQ2GF[0]
			else: i5DftlhA6vQ2GF = ''
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named=wecima'+'__download'+i5DftlhA6vQ2GF
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.replace('\n','').replace('\r','')
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search,O90aQtMFVN6hw1qf8Xbenopyu=''):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	if not O90aQtMFVN6hw1qf8Xbenopyu:
		O90aQtMFVN6hw1qf8Xbenopyu = GqcEfFR8XQPgBMLr
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = O90aQtMFVN6hw1qf8Xbenopyu+'/AjaxCenter/Searching/'+search+'/'
	SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'search')
	return
def UviJploL2R7xqH68eI5MdFm0Dn9h4(wwtDgAROoBVI2sKzP97N,filter):
	if '??' in wwtDgAROoBVI2sKzP97N: url = wwtDgAROoBVI2sKzP97N.split('//getposts??')[0]
	else: url = wwtDgAROoBVI2sKzP97N
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='CATEGORIES':
		if fugkyUNWIJGSslwLzx[0]+'==' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = fugkyUNWIJGSslwLzx[0]
		for PXBFxvuUlLDHGpm58 in range(len(fugkyUNWIJGSslwLzx[0:-1])):
			if fugkyUNWIJGSslwLzx[PXBFxvuUlLDHGpm58]+'==' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = fugkyUNWIJGSslwLzx[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&&'+jsEpRxQH76+'==0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&&'+jsEpRxQH76+'==0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'//getposts??'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='FILTERS':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'//getposts??'+Lb7kxwJZBPquygXoO4nTSN3
		MPfKjlDAZTV6 = AsOwHTp3NU1bgGLoa7cCWeSX8h(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,wwtDgAROoBVI2sKzP97N)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',MPfKjlDAZTV6,561,'','','filters')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',MPfKjlDAZTV6,561,'','','filters')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'','','','','WECIMA-FILTERS_MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Ht6Gg8lbciAd9FaUQVs = Ht6Gg8lbciAd9FaUQVs.replace('\\"','"').replace('\\/','/')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<wecima--filter(.*?)</wecima--filter>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',wltPGJcYo12Ed+'<filterbox',QPuHKNAT4jmCRg.DOTALL)
	dict = {}
	for qQ3oR7maZGeFByA6uitjrd,name,wltPGJcYo12Ed in K0MwVeCGOmJho:
		name = kWfpQA7tTjSPyLbNIeMr1Hui5(name)
		if 'interest' in qQ3oR7maZGeFByA6uitjrd: continue
		items = QPuHKNAT4jmCRg.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if '==' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='CATEGORIES':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<=1:
				if qQ3oR7maZGeFByA6uitjrd==fugkyUNWIJGSslwLzx[-1]: SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'CATEGORIES___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				MPfKjlDAZTV6 = AsOwHTp3NU1bgGLoa7cCWeSX8h(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,wwtDgAROoBVI2sKzP97N)
				if qQ3oR7maZGeFByA6uitjrd==fugkyUNWIJGSslwLzx[-1]:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',MPfKjlDAZTV6,561,'','','filters')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,564,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='FILTERS':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&&'+qQ3oR7maZGeFByA6uitjrd+'==0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&&'+qQ3oR7maZGeFByA6uitjrd+'==0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name+': الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,565,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF+'_FORGETRESULTS_')
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			name = kWfpQA7tTjSPyLbNIeMr1Hui5(name)
			wMq2UBSjsfgchHzprXWFOTdn5 = kWfpQA7tTjSPyLbNIeMr1Hui5(wMq2UBSjsfgchHzprXWFOTdn5)
			if pp8iHB3W9Cs=='r' or pp8iHB3W9Cs=='nc-17': continue
			if any(pp8iHB3W9Cs in wMq2UBSjsfgchHzprXWFOTdn5.lower() for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' in wMq2UBSjsfgchHzprXWFOTdn5: continue
			if 'الكل' in wMq2UBSjsfgchHzprXWFOTdn5: continue
			if 'n-a' in pp8iHB3W9Cs: continue
			if wMq2UBSjsfgchHzprXWFOTdn5=='': wMq2UBSjsfgchHzprXWFOTdn5 = pp8iHB3W9Cs
			gH8mavstuiyE6RY2 = wMq2UBSjsfgchHzprXWFOTdn5
			OnQ71fzhCAbTwMBg0kPxjG4i5VdSep = QPuHKNAT4jmCRg.findall('<name>(.*?)</name>',wMq2UBSjsfgchHzprXWFOTdn5,QPuHKNAT4jmCRg.DOTALL)
			if OnQ71fzhCAbTwMBg0kPxjG4i5VdSep: gH8mavstuiyE6RY2 = OnQ71fzhCAbTwMBg0kPxjG4i5VdSep[0]
			nUbpaNT0vhcj7ZsEz = name+': '+gH8mavstuiyE6RY2
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = nUbpaNT0vhcj7ZsEz
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&&'+qQ3oR7maZGeFByA6uitjrd+'=='+gH8mavstuiyE6RY2
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&&'+qQ3oR7maZGeFByA6uitjrd+'=='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			if type=='FILTERS':
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,url,565,'','',q0NkUvatj1HcndbF9Yrsw+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and fugkyUNWIJGSslwLzx[-2]+'==' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'modified_filters')
				lc154VhT9DCqMk8 = url+'//getposts??'+sJxYKGW7VODHcn0o4UBZkAtEMe
				MPfKjlDAZTV6 = AsOwHTp3NU1bgGLoa7cCWeSX8h(lc154VhT9DCqMk8,wwtDgAROoBVI2sKzP97N)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,MPfKjlDAZTV6,561,'','','filters')
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+nUbpaNT0vhcj7ZsEz,url,564,'','',q0NkUvatj1HcndbF9Yrsw)
	return
fugkyUNWIJGSslwLzx = ['genre','release-year','nation']
MNI2UuX0ODVBeKx9H37nJW = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def AsOwHTp3NU1bgGLoa7cCWeSX8h(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,lc154VhT9DCqMk8):
	if '/AjaxCenter/RightBar' in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('//getposts??','::/AjaxCenter/Filtering/')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('==','/')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('&&','/')
	return lZqkuhgaBHSVX8NItKG05cdLJe7Ao
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&&')
	XTiOm8cUEJCh3ryql,VAlPewLIfoQv6dash = {},''
	if '==' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('==')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	for key in MNI2UuX0ODVBeKx9H37nJW:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&&'+key+'=='+pp8iHB3W9Cs
		elif mode=='all': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&&'+key+'=='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&&')
	return VAlPewLIfoQv6dash
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'BOKRA'
JE7QrkmhletLwA0OZXu = '_BKR_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
headers = {'User-Agent':''}
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['افلام للكبار','بكرا TV']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==370: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==371: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==372: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==374: RRMWBwU6pG = PKHSjlXJZdnp5BokE1439(url)
	elif mode==375: RRMWBwU6pG = FvucG4tVjiPQZx0b62O(url)
	elif mode==376: RRMWBwU6pG = xK0lvkYQPeVE(0,url)
	elif mode==377: RRMWBwU6pG = xK0lvkYQPeVE(1,url)
	elif mode==379: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','BOKRA-MENU-1st')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('right-side(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المميزة',GqcEfFR8XQPgBMLr,375)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الأحدث',GqcEfFR8XQPgBMLr,376)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'قائمة الممثلين',GqcEfFR8XQPgBMLr,374)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="container"(.*?)top-menu',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items[7:]:
			title = title.strip(' ')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371)
		for VV7yf2htDCBU6EeSX8TJQM,title in items[0:7]:
			title = title.strip(' ')
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371)
	return
def PKHSjlXJZdnp5BokE1439(website=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','BOKRA-ACTORSMENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="row cat Tags"(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if 'http' in VV7yf2htDCBU6EeSX8TJQM: continue
			else: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371)
	return
def FvucG4tVjiPQZx0b62O(website=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',GqcEfFR8XQPgBMLr,'','','','','BOKRA-FEATURED-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"MainContent"(.*?)main-title2',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
				G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('://',':///').replace('//','/').replace(' ','%20')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,372,G2WR0Oacvdq8ZQTjKboDU)
	return
def xK0lvkYQPeVE(id,website=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',GqcEfFR8XQPgBMLr,'','','','','BOKRA-WATCHINGNOW-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-title2(.*?)class="row',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[id]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
				G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('://',':///').replace('//','/').replace(' ','%20')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,372,G2WR0Oacvdq8ZQTjKboDU)
	return
def SPFl6UGK4mrBua(url,WXKiUx9gNhG=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','BOKRA-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	if 'vidpage_' in url:
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('href="(/Album-.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if VV7yf2htDCBU6EeSX8TJQM:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM[0]
			SPFl6UGK4mrBua(VV7yf2htDCBU6EeSX8TJQM)
			return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class=" subcats"(.*?)class="col-md-3',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if WXKiUx9gNhG=='' and TTCRYZroizb and TTCRYZroizb[0].count('href')>1:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',url,371,'','','titles')
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/'+VV7yf2htDCBU6EeSX8TJQM
			title = title.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371)
	else:
		gltHFKTroJfpLe = []
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="col-md-3(.*?)col-xs-12',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if not TTCRYZroizb: TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="col-sm-8"(.*?)col-xs-12',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
				VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
				title = title.strip(' ')
				G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in VV7yf2htDCBU6EeSX8TJQM:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371,G2WR0Oacvdq8ZQTjKboDU)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) - +الحلقة +\d+',title,QPuHKNAT4jmCRg.DOTALL)
					if CiZxgXTGW9pv: title = '_MOD_مسلسل '+CiZxgXTGW9pv[0]
					if title not in gltHFKTroJfpLe:
						gltHFKTroJfpLe.append(title)
						fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371,G2WR0Oacvdq8ZQTjKboDU)
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,372,G2WR0Oacvdq8ZQTjKboDU)
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('class="".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
				title = 'صفحة '+UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,371,'','','titles')
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','BOKRA-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('label-success mrg-btm-5 ">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	lc154VhT9DCqMk8 = ''
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('var url = "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[0]
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace('/vidpage_','/Play/')
	if 'http' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr+lZqkuhgaBHSVX8NItKG05cdLJe7Ao
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.strip('-')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','BOKRA-PLAY-2nd')
	iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	lc154VhT9DCqMk8 = QPuHKNAT4jmCRg.findall('src="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
	if lc154VhT9DCqMk8:
		lc154VhT9DCqMk8 = lc154VhT9DCqMk8[-1]
		if 'http' not in lc154VhT9DCqMk8: lc154VhT9DCqMk8 = 'http:'+lc154VhT9DCqMk8
		if '/PLAY/' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
			if 'embed.min.js' in lc154VhT9DCqMk8:
				itYecGahQpOKBIw0F2UR7uqXCfjx8 = QPuHKNAT4jmCRg.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
				if itYecGahQpOKBIw0F2UR7uqXCfjx8:
					biAhLDIKGyuQxMkJq97O, iRIcO3FTtno = itYecGahQpOKBIw0F2UR7uqXCfjx8[0]
					lc154VhT9DCqMk8 = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lc154VhT9DCqMk8,'url')+'/v2/'+biAhLDIKGyuQxMkJq97O+'/config/'+iRIcO3FTtno+'.json'
		import bcQwT9tl1C
		bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP([lc154VhT9DCqMk8],mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/Search/'+search
	SPFl6UGK4mrBua(url)
	return
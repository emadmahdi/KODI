# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'EGYBEST1'
JE7QrkmhletLwA0OZXu = '_EB1_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['مكتبتي','ايجي بست']
def hLD0mk9HIuPOz7pw(mode,url,YSTbrKgPf7NyhIDizB,text):
	if   mode==770: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==771: RRMWBwU6pG = SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB)
	elif mode==772: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==773: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==774: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'FULL_FILTER___'+text)
	elif mode==775: RRMWBwU6pG = UviJploL2R7xqH68eI5MdFm0Dn9h4(url,'DEFINED_FILTER___'+text)
	elif mode==776: RRMWBwU6pG = o9LaYpVR1wKx3IGuHS(url,YSTbrKgPf7NyhIDizB)
	elif mode==779: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text,url)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',779,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','EGYBEST1-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('nav-list(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,771)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-article(.*?)social-box',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('main-title.*?">(.*?)<.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			title = title.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,771,'','mainmenu')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-menu(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,771)
	return Ht6Gg8lbciAd9FaUQVs
def o9LaYpVR1wKx3IGuHS(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST1-SEASONS_EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-article".*?">(.*?)<(.*?)article',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		Q1WJvEwGdh2mPfct9SKa,jN1v92PmCGquRbcl,items = '','',[]
		for name,wltPGJcYo12Ed in TTCRYZroizb:
			if 'حلقات' in name: jN1v92PmCGquRbcl = wltPGJcYo12Ed
			if 'مواسم' in name: Q1WJvEwGdh2mPfct9SKa = wltPGJcYo12Ed
		if Q1WJvEwGdh2mPfct9SKa and not type:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',Q1WJvEwGdh2mPfct9SKa,QPuHKNAT4jmCRg.DOTALL)
			if len(items)>1:
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,776,G2WR0Oacvdq8ZQTjKboDU,'season')
		if jN1v92PmCGquRbcl and len(items)<2:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',jN1v92PmCGquRbcl,QPuHKNAT4jmCRg.DOTALL)
			if items:
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,773,G2WR0Oacvdq8ZQTjKboDU)
			else:
				items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',jN1v92PmCGquRbcl,QPuHKNAT4jmCRg.DOTALL)
				for VV7yf2htDCBU6EeSX8TJQM,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,773)
	return
def SPFl6UGK4mrBua(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST1-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items,tX4e9uQrjYwl3I,JWVlUxnpBbjv20w7 = [],False,False
	if not type:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-content(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = title.strip(' ')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,771,'','submenu')
				tX4e9uQrjYwl3I = True
	if not type and 'p=' not in url:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('searchform(.*?)</form>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			if tX4e9uQrjYwl3I: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر محدد',url,775,'','filter')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فلتر كامل',url,774,'','filter')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث',url,779)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			JWVlUxnpBbjv20w7 = True
	if not tX4e9uQrjYwl3I:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('blocks(.*?)article',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
				G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.strip('\n')
				VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
				if '/serie/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,776,G2WR0Oacvdq8ZQTjKboDU,'season')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,773,G2WR0Oacvdq8ZQTjKboDU)
			YSTbrKgPf7NyhIDizB = '1'
			if 'p=' in url: url,YSTbrKgPf7NyhIDizB = url.split('p=',1)
			qcOU43biDkaPQlZMB1wHEj = '&' if '?' in url else '?'
			url = url+qcOU43biDkaPQlZMB1wHEj
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(YSTbrKgPf7NyhIDizB)+1)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الصفحة التالية',url,771)
			elif YSTbrKgPf7NyhIDizB!='1':
				url = url+'p='+str(int(YSTbrKgPf7NyhIDizB)-1)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الصفحة السابقة',url,771)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',url,'','','','','EGYBEST1-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('<label>التصنيف</label>.*?">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	arZijTmC4eXBKvgEAHxPD7JtwOh,YsDryBSXquzdEUta8kxjfO,uuonPvOwRZp90QJh = [],[],[]
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('video-play-iframe.*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		if VV7yf2htDCBU6EeSX8TJQM not in uuonPvOwRZp90QJh:
			uuonPvOwRZp90QJh.append(VV7yf2htDCBU6EeSX8TJQM)
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named=__embed')
	items = QPuHKNAT4jmCRg.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for i5DftlhA6vQ2GF,VV7yf2htDCBU6EeSX8TJQM in items:
		if VV7yf2htDCBU6EeSX8TJQM not in uuonPvOwRZp90QJh:
			uuonPvOwRZp90QJh.append(VV7yf2htDCBU6EeSX8TJQM)
			i5DftlhA6vQ2GF = i5DftlhA6vQ2GF.strip(' ')
			BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+BHgLX9GZTb2jJrWiNKE+'__download____'+i5DftlhA6vQ2GF)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search,url=''):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search: search = wod1HJ0fnvcTNAX2WIiMu9P()
	if not search: return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','%20')
	if not url: url = GqcEfFR8XQPgBMLr+'/search?query='+Unr6jRmMIv80lSGbkBCehpaWAdV
	else: url = url+'?title='+Unr6jRmMIv80lSGbkBCehpaWAdV+'&genre=&year=&lang='
	SPFl6UGK4mrBua(url,'search')
	return
def PD19Sz64kNmaXxw(url):
	url = url.split('/smartemadfilter?')[0]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'','','','','EGYBEST1-GET_FILTERS_BLOCKS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	K0MwVeCGOmJho = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('form-row(.*?)</form>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		qBUEfFhoG5Mw0xgyl4nAkemHd6W9Z,xVQTW4gOUKEJtMzLXiChwk1BlRD2N,N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = zip(*K0MwVeCGOmJho)
		K0MwVeCGOmJho = zip(xVQTW4gOUKEJtMzLXiChwk1BlRD2N,qBUEfFhoG5Mw0xgyl4nAkemHd6W9Z,N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd)
	return K0MwVeCGOmJho
def zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed):
	items = QPuHKNAT4jmCRg.findall('value="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return items
def AGN9FcR0k3(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
CEMwAc5LsuN0V = ['year','lang','genre']
sjehmt4lTF0gkQ = ['year','lang','genre']
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='DEFINED_FILTER':
		if sjehmt4lTF0gkQ[0]+'=' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = sjehmt4lTF0gkQ[0]
		for PXBFxvuUlLDHGpm58 in range(len(sjehmt4lTF0gkQ[0:-1])):
			if sjehmt4lTF0gkQ[PXBFxvuUlLDHGpm58]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = sjehmt4lTF0gkQ[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+jsEpRxQH76+'=0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+jsEpRxQH76+'=0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'all')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='FULL_FILTER':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3: Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'all')
		if not Lb7kxwJZBPquygXoO4nTSN3: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+Lb7kxwJZBPquygXoO4nTSN3
		lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',lc154VhT9DCqMk8,771,'','filter')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',lc154VhT9DCqMk8,771,'','filter')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K0MwVeCGOmJho = PD19Sz64kNmaXxw(url)
	dict = {}
	for name,qQ3oR7maZGeFByA6uitjrd,wltPGJcYo12Ed in K0MwVeCGOmJho:
		name = name.replace('كل ','')
		items = zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed)
		if '=' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='DEFINED_FILTER':
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<2:
				if qQ3oR7maZGeFByA6uitjrd==sjehmt4lTF0gkQ[-1]:
					lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
					SPFl6UGK4mrBua(lc154VhT9DCqMk8)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'DEFINED_FILTER___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				if qQ3oR7maZGeFByA6uitjrd==sjehmt4lTF0gkQ[-1]:
					lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع ',lc154VhT9DCqMk8,771,'','filter')
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,775,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='FULL_FILTER':
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع :'+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,774,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			if not pp8iHB3W9Cs: continue
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = wMq2UBSjsfgchHzprXWFOTdn5
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'='+wMq2UBSjsfgchHzprXWFOTdn5
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'#+dict[qQ3oR7maZGeFByA6uitjrd]['0']
			title = wMq2UBSjsfgchHzprXWFOTdn5+' :'+name
			if type=='FULL_FILTER': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,774,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='DEFINED_FILTER' and sjehmt4lTF0gkQ[-2]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'modified_filters')
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
				lc154VhT9DCqMk8 = AGN9FcR0k3(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lc154VhT9DCqMk8,771,'','filter')
			elif type=='DEFINED_FILTER': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,775,'','',q0NkUvatj1HcndbF9Yrsw)
	return
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.replace('=&','=0&')
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&')
	XTiOm8cUEJCh3ryql = {}
	if '=' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	VAlPewLIfoQv6dash = ''
	for key in CEMwAc5LsuN0V:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
		elif mode=='all': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.replace('=0','=')
	return VAlPewLIfoQv6dash
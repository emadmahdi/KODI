# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'EGYBEST3'
JE7QrkmhletLwA0OZXu = '_EB3_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def hLD0mk9HIuPOz7pw(mode,url,YSTbrKgPf7NyhIDizB,text):
	if   mode==790: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==791: RRMWBwU6pG = SPFl6UGK4mrBua(url,YSTbrKgPf7NyhIDizB)
	elif mode==792: RRMWBwU6pG = pF0d4b2ZY9(url)
	elif mode==793: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==796: RRMWBwU6pG = o9LaYpVR1wKx3IGuHS(url,YSTbrKgPf7NyhIDizB)
	elif mode==799: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr,'','','','','EGYBEST3-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('list-pages(.*?)fa-folder',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,791)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-article(.*?)social-box',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('main-title.*?">(.*?)<.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,791,'','mainmenu')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-menu(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,791)
	return Ht6Gg8lbciAd9FaUQVs
def o9LaYpVR1wKx3IGuHS(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-article".*?">(.*?)<(.*?)article',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		Q1WJvEwGdh2mPfct9SKa,jN1v92PmCGquRbcl,items = '','',[]
		for name,wltPGJcYo12Ed in TTCRYZroizb:
			if 'حلقات' in name: jN1v92PmCGquRbcl = wltPGJcYo12Ed
			if 'مواسم' in name: Q1WJvEwGdh2mPfct9SKa = wltPGJcYo12Ed
		if Q1WJvEwGdh2mPfct9SKa and not type:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',Q1WJvEwGdh2mPfct9SKa,QPuHKNAT4jmCRg.DOTALL)
			if len(items)>1:
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,796,G2WR0Oacvdq8ZQTjKboDU,'season')
		if jN1v92PmCGquRbcl and len(items)<2:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',jN1v92PmCGquRbcl,QPuHKNAT4jmCRg.DOTALL)
			if items:
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,793,G2WR0Oacvdq8ZQTjKboDU)
			else:
				items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',jN1v92PmCGquRbcl,QPuHKNAT4jmCRg.DOTALL)
				for VV7yf2htDCBU6EeSX8TJQM,title in items:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,793)
	return
def SPFl6UGK4mrBua(url,type=''):
	jt48CzhPJ7Y19r5kBGfH2eZ,start,bnZAcrOuJCM5z30RWQmlEYgqoLk,select,DD1CtsHA8WdUEXVJgPi5y = 0,0,'','',''
	if 'pagination' in type:
		umtfFbLz9slJ8rOed4kKMaIHyj05RG,data = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
		jt48CzhPJ7Y19r5kBGfH2eZ = int(data['limit'])
		start = int(data['start'])
		bnZAcrOuJCM5z30RWQmlEYgqoLk = data['type']
		select = data['select']
		BF8XfchlgKmOE0ru2 = 'limit='+str(jt48CzhPJ7Y19r5kBGfH2eZ)+'&start='+str(start)+'&type='+bnZAcrOuJCM5z30RWQmlEYgqoLk+'&select='+select
		Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',umtfFbLz9slJ8rOed4kKMaIHyj05RG,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','EGYBEST3-TITLES-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		iRSILm7Nv6DZAaztp = 'blocks'+Ht6Gg8lbciAd9FaUQVs+'article'
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		iRSILm7Nv6DZAaztp = Ht6Gg8lbciAd9FaUQVs
		code = QPuHKNAT4jmCRg.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			aaxAKWtMwfPRE4zbqSQCOrBms0,data = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu('?'+code)
			jt48CzhPJ7Y19r5kBGfH2eZ = int(data['limit'])
			start = int(data['start'])
			bnZAcrOuJCM5z30RWQmlEYgqoLk = data['type']
			select = data['select']
			DD1CtsHA8WdUEXVJgPi5y = data['ajaxurl']
			BF8XfchlgKmOE0ru2 = 'limit='+str(jt48CzhPJ7Y19r5kBGfH2eZ)+'&start='+str(start)+'&type='+bnZAcrOuJCM5z30RWQmlEYgqoLk+'&select='+select
			umtfFbLz9slJ8rOed4kKMaIHyj05RG = GqcEfFR8XQPgBMLr+DD1CtsHA8WdUEXVJgPi5y
			Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded'}
			nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',umtfFbLz9slJ8rOed4kKMaIHyj05RG,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','EGYBEST3-TITLES-3rd')
			iRSILm7Nv6DZAaztp = nbdMp8UuhzP3oq4cDWj6eyZVt.content
			iRSILm7Nv6DZAaztp = 'blocks'+iRSILm7Nv6DZAaztp+'article'
	items,tX4e9uQrjYwl3I,JWVlUxnpBbjv20w7 = [],False,False
	if not type:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-content(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</i>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = title.strip(' ')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,791,'','submenu')
				tX4e9uQrjYwl3I = True
	if not type:
		JWVlUxnpBbjv20w7 = d3HBGsTc79uQvXE0iVamKL5rpOS(Ht6Gg8lbciAd9FaUQVs)
	if not tX4e9uQrjYwl3I and not JWVlUxnpBbjv20w7:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('blocks(.*?)article',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
				G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU.strip('\n')
				VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
				if '/selary/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,791,G2WR0Oacvdq8ZQTjKboDU)
				elif 'مسلسل' in VV7yf2htDCBU6EeSX8TJQM and 'حلقة' not in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,796,G2WR0Oacvdq8ZQTjKboDU)
				elif 'موسم' in VV7yf2htDCBU6EeSX8TJQM and 'حلقة' not in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,796,G2WR0Oacvdq8ZQTjKboDU)
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,793,G2WR0Oacvdq8ZQTjKboDU)
		KOtnoe7NXMaF3jD8UfuLd = 12
		data = QPuHKNAT4jmCRg.findall('class="(load-more.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if len(items)==KOtnoe7NXMaF3jD8UfuLd and (data or 'pagination' in type):
			BF8XfchlgKmOE0ru2 = 'limit='+str(KOtnoe7NXMaF3jD8UfuLd)+'&start='+str(start+KOtnoe7NXMaF3jD8UfuLd)+'&type='+bnZAcrOuJCM5z30RWQmlEYgqoLk+'&select='+select
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = umtfFbLz9slJ8rOed4kKMaIHyj05RG+'?next=page&'+BF8XfchlgKmOE0ru2
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المزيد',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,791,'','pagination_'+type)
	return
def d3HBGsTc79uQvXE0iVamKL5rpOS(Ht6Gg8lbciAd9FaUQVs):
	JWVlUxnpBbjv20w7 = False
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-article(.*?)article',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd: fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for jsEpRxQH76,name,wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
			name = name.strip(' ')
			items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,pp8iHB3W9Cs in items:
				title = name+':  '+pp8iHB3W9Cs
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,791,'','filter')
				JWVlUxnpBbjv20w7 = True
	return JWVlUxnpBbjv20w7
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	YsDryBSXquzdEUta8kxjfO,uuonPvOwRZp90QJh = [],[]
	items = QPuHKNAT4jmCRg.findall('server-item.*?data-code="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for xEifcBA3nmFzkNPVRC04 in items:
		kqFHyXaSxN1IOeZJfzC = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(xEifcBA3nmFzkNPVRC04)
		if Nnxm30dfoBWRYpIC7KsQGl: kqFHyXaSxN1IOeZJfzC = kqFHyXaSxN1IOeZJfzC.decode('utf8')
		VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('src="(.*?)"',kqFHyXaSxN1IOeZJfzC,QPuHKNAT4jmCRg.DOTALL)
		if VV7yf2htDCBU6EeSX8TJQM:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
			if VV7yf2htDCBU6EeSX8TJQM not in uuonPvOwRZp90QJh:
				uuonPvOwRZp90QJh.append(VV7yf2htDCBU6EeSX8TJQM)
				BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+BHgLX9GZTb2jJrWiNKE+'__watch')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="downloads(.*?)</section>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for i5DftlhA6vQ2GF,VV7yf2htDCBU6EeSX8TJQM in items:
			if VV7yf2htDCBU6EeSX8TJQM not in uuonPvOwRZp90QJh:
				if '/?url=' in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.split('/?url=')[1]
				uuonPvOwRZp90QJh.append(VV7yf2htDCBU6EeSX8TJQM)
				BHgLX9GZTb2jJrWiNKE = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM,'name')
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+BHgLX9GZTb2jJrWiNKE+'__download____'+i5DftlhA6vQ2GF)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(text):
	return
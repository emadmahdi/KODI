# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'CIMAFANS'
headers = { 'User-Agent' : '' }
JE7QrkmhletLwA0OZXu = '_CMF_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==90: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==91: RRMWBwU6pG = F42EXtwuzB7Hl(url)
	elif mode==92: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==94: RRMWBwU6pG = YNtljB8xJEoSwiUZbAcI1aKHvsgh()
	elif mode==95: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==99: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المضاف حديثا','',94)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الأحدث',GqcEfFR8XQPgBMLr+'/?type=latest',91)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الأعلى تقيماً',GqcEfFR8XQPgBMLr+'/?type=imdb',91)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الأكثر مشاهدة',GqcEfFR8XQPgBMLr+'/?type=view',91)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المثبت',GqcEfFR8XQPgBMLr+'/?type=pin',91)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'جديد الأفلام',GqcEfFR8XQPgBMLr+'/?type=newMovies',91)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'جديد الحلقات',GqcEfFR8XQPgBMLr+'/?type=newEpisodes',91)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','CIMAFANS-MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="mainmenu(.*?)nav',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('<li><a href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	EhRQ8zB1fdkj5vN6HlmqD7SOU = ['افلام للكبار فقط']
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = title.strip(' ')
		if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,91)
	return Ht6Gg8lbciAd9FaUQVs
def F42EXtwuzB7Hl(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	else:
		headers = { 'User-Agent' : '' }
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="movies-items(.*?)class="listfoot"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
	else: wltPGJcYo12Ed = ''
	items = QPuHKNAT4jmCRg.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة [0-9]+',title,QPuHKNAT4jmCRg.DOTALL)
			if CiZxgXTGW9pv:
				title = '_MOD_'+CiZxgXTGW9pv[0]
				if title not in gltHFKTroJfpLe:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,95,G2WR0Oacvdq8ZQTjKboDU)
					gltHFKTroJfpLe.append(title)
		elif '/video/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,92,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,91,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<a href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = title.replace('الصفحة ','')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,91)
	return
def opLlxOB2dUVZ5JF4j(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,'','CIMAFANS-EPISODES-1st')
	G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('img src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="episodes-panel(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		name = QPuHKNAT4jmCRg.findall('itemprop="title">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if name: name = name[1]
		else:
			name = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?name">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+name+' - '+title,VV7yf2htDCBU6EeSX8TJQM,92,G2WR0Oacvdq8ZQTjKboDU)
	else:
		uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall('class="movietitle"><a href="(.*?)">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if uuv3pk5MXdeaHt6sDxSFybTWz0Q: VV7yf2htDCBU6EeSX8TJQM,title = uuv3pk5MXdeaHt6sDxSFybTWz0Q[0]
		else: VV7yf2htDCBU6EeSX8TJQM,title = url,name
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,92,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA,u9w3AN4bOqK0MCQ8sLzg7ocSaxDX1R = [],[]
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,'','CIMAFANS-PLAY-1st')
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('text-shadow: none;">(.*?)<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="links-panel(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?__download'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('nav-tabs"(.*?)video-panel-more',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('id="(.*?)".*?embed src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for id,VV7yf2htDCBU6EeSX8TJQM in items:
			title = 'سيرفر '+id
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		items = QPuHKNAT4jmCRg.findall('data-server-src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM in items:
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
			VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def YNtljB8xJEoSwiUZbAcI1aKHvsgh():
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,GqcEfFR8XQPgBMLr,'',headers,'','CIMAFANS-LATEST-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('id="index-last-movie(.*?)id="index-slider-movie',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		if '/video/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,92,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,91,G2WR0Oacvdq8ZQTjKboDU)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr + '/search.php?t='+search
	F42EXtwuzB7Hl(url)
	return
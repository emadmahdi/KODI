# -*- coding: utf-8 -*-
import sys as GJtcqTv68ZQpwxYFiDg
yyIoQrPWR1B = GJtcqTv68ZQpwxYFiDg.version_info [0] == 2
Duhwt2HMRTeBonVic0lz8bjUJ = 2048
BnAMltLNqzHfjxWkVi9eb3P = 7
def rrgVqwDZPsMjxvR3EylNz9 (tbA2GsXVSDNgm):
	global lzR5Gp9sjoDwb
	BZb90tzYkgeu3pcAo = ord (tbA2GsXVSDNgm [-1])
	fdK96q2bHgSIwE = tbA2GsXVSDNgm [:-1]
	klvdJbzV7PEMciQ61A0t25SGXq8 = BZb90tzYkgeu3pcAo % len (fdK96q2bHgSIwE)
	q5yMKdNsYpzDj8Oo = fdK96q2bHgSIwE [:klvdJbzV7PEMciQ61A0t25SGXq8] + fdK96q2bHgSIwE [klvdJbzV7PEMciQ61A0t25SGXq8:]
	if yyIoQrPWR1B:
		hq2Yj5TvMOKsRFroabWu = unicode () .join ([unichr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	else:
		hq2Yj5TvMOKsRFroabWu = str () .join ([chr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	return eval (hq2Yj5TvMOKsRFroabWu)
iRTygNp4Lf36wQKlD2MHUhG7B,KbL94nDHufSF0VcO2Nk3,qNZKwi2M1S4fBzGQYrmPnea=rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9
xxpPYJOnoAUrlBzyveui,ldOGfm56kWs8T03wcptQunqEUBDrvC,Arg2GFJDt3emTvpO6fZkSVdaUHywnN=qNZKwi2M1S4fBzGQYrmPnea,KbL94nDHufSF0VcO2Nk3,iRTygNp4Lf36wQKlD2MHUhG7B
v7reLlOXCgD5pZ14w2tUA,p1lrNRIXqLQJznH6O,ddK4MmwpX5oG=Arg2GFJDt3emTvpO6fZkSVdaUHywnN,ldOGfm56kWs8T03wcptQunqEUBDrvC,xxpPYJOnoAUrlBzyveui
OARzhnB9o7uYvQGFaIcZ,ZpH2IWt7veyFobTsAnhi41,q0JfWbP8vACLxSNIncpOXkR6j=ddK4MmwpX5oG,p1lrNRIXqLQJznH6O,v7reLlOXCgD5pZ14w2tUA
L91nVzxH4hYrgPDsOuljXd0J,uhOkAKtLVv4XTy1nWE6,d1JiVThqEO0nBaY2QRNyZxlujWw7SK=q0JfWbP8vACLxSNIncpOXkR6j,ZpH2IWt7veyFobTsAnhi41,OARzhnB9o7uYvQGFaIcZ
V391t7nQWUBR5euCkJ,IJ6VkihabRm,lunVJF2G5bZMgTcCje0vaIB371SX=d1JiVThqEO0nBaY2QRNyZxlujWw7SK,uhOkAKtLVv4XTy1nWE6,L91nVzxH4hYrgPDsOuljXd0J
xxBJoKG54uwQ,gr5K72RtvAZYPVwkdnspbzQWNjEI,u1ml5XcLiZ7oDPs3UjedgpYHhfV=lunVJF2G5bZMgTcCje0vaIB371SX,IJ6VkihabRm,V391t7nQWUBR5euCkJ
dxAs4otSE98YmZnKy2iwRCB,fcIm8tvxlXZsaEY3bwuG4B,f8PVRTseIuj9BckO6GoyF5Lxv=u1ml5XcLiZ7oDPs3UjedgpYHhfV,gr5K72RtvAZYPVwkdnspbzQWNjEI,xxBJoKG54uwQ
tKVplxqYIdngGF6TZkXeb2PiwfME,vkMRnTNV9jFm,HMO0QciekqVpLKmA=f8PVRTseIuj9BckO6GoyF5Lxv,fcIm8tvxlXZsaEY3bwuG4B,dxAs4otSE98YmZnKy2iwRCB
DKqQekNtF6WlJLhBP9M5ca,GGTRaYBDeNyI25zlF,Vv0lSjAOHLfMnam3wtdor=HMO0QciekqVpLKmA,vkMRnTNV9jFm,tKVplxqYIdngGF6TZkXeb2PiwfME
a06i2XFf3oBnDrJQZEKmHpqY9ACW,DDS79jdWzLtE,zOZvXaebGNwHKfjRA=Vv0lSjAOHLfMnam3wtdor,GGTRaYBDeNyI25zlF,DKqQekNtF6WlJLhBP9M5ca
from P5mleDuhGM import *
import bidi.algorithm as GGgun1VSbfq8edk62vLxB,bidi.mirror as N6MITLGyr4dlgqDA,base64 as jm9LDJTlXsqZM8EAygS26twWQ70,requests as D0nOE8Wu9jfHxPTIXiLVypGB
mm5vCBc4DOz2Fj = OARzhnB9o7uYvQGFaIcZ(u"ࠧࡍࡋࡅࡗ࡙࡝ࡏࠨ౱")
ZXFEJOV3vG5UIjAR2WxiD01tcML = {}
vvruH9wsBDfbhFtyq1MUd2zV = []
if Nnxm30dfoBWRYpIC7KsQGl:
	LLztTXv6YWnpjqVMldZE = NuU4yWvdlP08.translatePath(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ౲"))
	XJ4uqLcYdaT8nE3f = NuU4yWvdlP08.translatePath(uhOkAKtLVv4XTy1nWE6(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ౳"))
	mMVPrWTSgHopRO8UEzKbjJY = NuU4yWvdlP08.translatePath(GGTRaYBDeNyI25zlF(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ౴"))
	zmL4569eBqGphRbKP7f2NOs = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౵"),GGTRaYBDeNyI25zlF(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౶"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ౷"))
	ZyO9CA3fKtkBgiTGIp0j = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ౸"),xxBJoKG54uwQ(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ౹"),ZpH2IWt7veyFobTsAnhi41(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ౺"))
	MbCGIVc1LiYlq9K4gyDZ = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ౻"),V391t7nQWUBR5euCkJ(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭౼"),fcIm8tvxlXZsaEY3bwuG4B(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ౽"))
	ICxkgfWtNMBHQ40co8VsjFO = V391t7nQWUBR5euCkJ(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ౾")
	from urllib.parse import quote as _dnwNWD5Ze
else:
	LLztTXv6YWnpjqVMldZE = AAsbUG0jZ5igBpNKQwFrJTd.translatePath(xxpPYJOnoAUrlBzyveui(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ౿"))
	XJ4uqLcYdaT8nE3f = AAsbUG0jZ5igBpNKQwFrJTd.translatePath(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩಀ"))
	mMVPrWTSgHopRO8UEzKbjJY = AAsbUG0jZ5igBpNKQwFrJTd.translatePath(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ಁ"))
	zmL4569eBqGphRbKP7f2NOs = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಂ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಃ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪ಄"))
	ZyO9CA3fKtkBgiTGIp0j = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಅ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಆ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨಇ"))
	MbCGIVc1LiYlq9K4gyDZ = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,Vv0lSjAOHLfMnam3wtdor(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಈ"),xxBJoKG54uwQ(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಉ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫಊ"))
	ICxkgfWtNMBHQ40co8VsjFO = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭ಋ").encode(V391t7nQWUBR5euCkJ(u"࠭ࡵࡵࡨ࠻ࠫಌ"))
	from urllib import quote as _dnwNWD5Ze
ZFyXrxgYWeMS3RGsD670pb = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(mMVPrWTSgHopRO8UEzKbjJY,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ಍"))
aAnplEuShqTCBUg0k2y536ONrseGb = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(mMVPrWTSgHopRO8UEzKbjJY,V391t7nQWUBR5euCkJ(u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧಎ"))
zSr9lDgYab76LZRFXNdM3OhJ = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,Vv0lSjAOHLfMnam3wtdor(u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫಏ"))
BFc8ola35nEjJZyxw = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಐ"))
FGQSU4dIRi3CVvEO7bZ = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ಑"))
KmlAH1VJObEkfZS3ToazF8qNP70t = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,Vv0lSjAOHLfMnam3wtdor(u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭ಒ"))
odmkxW7uBXr = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,HMO0QciekqVpLKmA(u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಓ"))
SfgvFt3yAQ8n2UMYHkB5LZOeG0 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,ZpH2IWt7veyFobTsAnhi41(u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಔ"))
E5bapZAYUTcnFCmuPGztDrfMq = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,HMO0QciekqVpLKmA(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨಕ"))
F0Dqd4Z5JgjmxCPYQ8M29VEekG = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(E5bapZAYUTcnFCmuPGztDrfMq,p1lrNRIXqLQJznH6O(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡵࠪಖ"))
Q0MT56yqDcNnGk = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(F0Dqd4Z5JgjmxCPYQ8M29VEekG,HMO0QciekqVpLKmA(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭ಗ"))
o76CsefkuZhcgDJlX = x1KknCETNQp.Addon().getAddonInfo(OARzhnB9o7uYvQGFaIcZ(u"ࠫࡵࡧࡴࡩࠩಘ"))
eLuH37gxlWFrXmPI9DRacKVvw8 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,DDS79jdWzLtE(u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧಙ"))
qhGXKtIAc7JDMl = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩಚ"))
jpOd8ItEif = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,ddK4MmwpX5oG(u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫಛ"))
bbsXepLY6T = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,DDS79jdWzLtE(u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬಜ"))
tpSjmXfVBrEPso = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩಝ"))
AwENosa4rb26JGLF851W7HkZeT3KC = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧಞ"))
q4hAGKT3Uwjis2MeRrX8oF5Ivt = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫಟ"))
CkUNxg1FhXOHI6uJ9tEw7q4DamZe = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫಠ"))
xp9lE7BnMwAidzfDa1rW60hymjoLc = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭࡭ࡦࡰࡸ࠲ࡵࡴࡧࠨಡ"))
chVmOk3KRSaCuDM = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,HMO0QciekqVpLKmA(u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧಢ"))
X8jt4IEY3WdFmbpreC2 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,vkMRnTNV9jFm(u"ࠨࡣࡧࡨࡴࡴࡳࠨಣ"))
GmSzRNvTVLPZthXp6DjK0 = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫತ"),p1lrNRIXqLQJznH6O(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧಥ"),M0J6Pq3bH2,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪದ"))
PJt3BgZiYnhGAI4kO = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(LLztTXv6YWnpjqVMldZE,KbL94nDHufSF0VcO2Nk3(u"ࠬࡳࡥࡥ࡫ࡤࠫಧ"),ddK4MmwpX5oG(u"࠭ࡆࡰࡰࡷࡷࠬನ"),GGTRaYBDeNyI25zlF(u"ࠧࡢࡴ࡬ࡥࡱ࠴ࡴࡵࡨࠪ಩"))
nJHx2XSIEFA7 = DKqQekNtF6WlJLhBP9M5ca(u"࠵ᒞ")
aLDUVmBxsFnM = [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨืไีࠬಪ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩฦ์้࠭ಫ"),V391t7nQWUBR5euCkJ(u"ࠪฯฬ์๊ࠨಬ"),vkMRnTNV9jFm(u"ࠫะอไฬࠩಭ"),zOZvXaebGNwHKfjRA(u"ࠬืวษ฻ࠪಮ"),DDS79jdWzLtE(u"࠭ฮศ็ึࠫಯ"),vkMRnTNV9jFm(u"ࠧิษาืࠬರ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨีสฬ฾࠭ಱ"),xxpPYJOnoAUrlBzyveui(u"ࠩฮห๊์ࠧಲ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪฮฬููࠨಳ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫ฾อิาࠩ಴")]
n7gbTfNzlivJFG = HMO0QciekqVpLKmA(u"ࠬ⹁ࠠ⼞ࠢ⸭ࠤ⹀࠭ವ")
muJyTVLlj36EopGDrnbeIRK = [xxBJoKG54uwQ(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬಶ")]
ZZwYPs2y1UWfqdpB = [OARzhnB9o7uYvQGFaIcZ(u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩಷ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫಸ"),ddK4MmwpX5oG(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭ಹ"),IJ6VkihabRm(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ಺"),OARzhnB9o7uYvQGFaIcZ(u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ಻"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࡓࡏࡗࡕ࠷಼࡙ࠬ"),dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ಽ"),uhOkAKtLVv4XTy1nWE6(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧಾ"),xxpPYJOnoAUrlBzyveui(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪಿ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫೀ")]
ZZwYPs2y1UWfqdpB += [qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡌࡊࡒࡁࡍࠩು"),v7reLlOXCgD5pZ14w2tUA(u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪೂ"),HMO0QciekqVpLKmA(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧೃ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧೄ"),ddK4MmwpX5oG(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ೅"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨೆ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫೇ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡔࡆࡔࡅࡕࠩೈ"),xxpPYJOnoAUrlBzyveui(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ೉"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫೊ")]
LDhgMOVFsx0JlBfkSap7e9Pm8jG = [L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࡉࡑࡖ࡙ࠫೋ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪೌ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ್࠭"),v7reLlOXCgD5pZ14w2tUA(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ೎")]
LDhgMOVFsx0JlBfkSap7e9Pm8jG += [KbL94nDHufSF0VcO2Nk3(u"ࠪࡑ࠸࡛ࠧ೏"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭೐"),xxpPYJOnoAUrlBzyveui(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ೑"),ZpH2IWt7veyFobTsAnhi41(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ೒")]
LDhgMOVFsx0JlBfkSap7e9Pm8jG += [zOZvXaebGNwHKfjRA(u"ࠧࡊࡈࡌࡐࡒ࠭೓"),xxBJoKG54uwQ(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ೔"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩೕ")]
LDhgMOVFsx0JlBfkSap7e9Pm8jG += [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡅࡑࡇࡒࡂࡄࠪೖ"),IJ6VkihabRm(u"ࠫࡆࡑࡗࡂࡏࠪ೗"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ೘"),HMO0QciekqVpLKmA(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ೙"),ddK4MmwpX5oG(u"ࠧࡂࡍࡒࡅࡒ࠭೚"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ೛")]
LDhgMOVFsx0JlBfkSap7e9Pm8jG += [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ೜"),p1lrNRIXqLQJznH6O(u"ࠪࡆࡔࡑࡒࡂࠩೝ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ೞ"),HMO0QciekqVpLKmA(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ೟"),DDS79jdWzLtE(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨೠ"),HMO0QciekqVpLKmA(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩೡ")]
RVHbUrThqOLfY4u27mB = [qNZKwi2M1S4fBzGQYrmPnea(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩೢ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪೣ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ೤"),vkMRnTNV9jFm(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ೥")]
RVHbUrThqOLfY4u27mB += [DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೦"),fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ೧"),GGTRaYBDeNyI25zlF(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ೨"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ೩"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ೪"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ೫")]
lu0Fg2DL3MR = [DKqQekNtF6WlJLhBP9M5ca(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ೬"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭೭"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ೮"),HMO0QciekqVpLKmA(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ೯"),xxBJoKG54uwQ(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ೰")]
lu0Fg2DL3MR += [d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫೱ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡘ࡛ࡌࡕࡏࠩೲ"),xxpPYJOnoAUrlBzyveui(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫೳ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ೴")]
e0qL2XFIxmo3YGW = [DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ೵"),GGTRaYBDeNyI25zlF(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ೶"),OARzhnB9o7uYvQGFaIcZ(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ೷"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡉࡓࡘ࡚ࡁࠨ೸"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡅࡍ࡝ࡁࡌࠩ೹"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ೺")]
e0qL2XFIxmo3YGW += [iRTygNp4Lf36wQKlD2MHUhG7B(u"࡙ࠬࡈࡐࡈࡋࡅࠬ೻"),xxBJoKG54uwQ(u"࠭ࡂࡓࡕࡗࡉࡏ࠭೼"),V391t7nQWUBR5euCkJ(u"࡚ࠧࡃࡔࡓ࡙࠭೽"),xxpPYJOnoAUrlBzyveui(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ೾"),IJ6VkihabRm(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ೿"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬഀ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഁ")]
NcZnzj89hFGQ2EtCP6dorTS  = [zOZvXaebGNwHKfjRA(u"ࠬࡇࡋࡘࡃࡐࠫം"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ഃ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩഄ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡄࡒࡏࡗࡇࠧഅ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡄࡏࡔࡇࡍࠨആ"),xxBJoKG54uwQ(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬഇ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ഈ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഉ")]
NcZnzj89hFGQ2EtCP6dorTS += [IJ6VkihabRm(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨഊ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪഋ"),GGTRaYBDeNyI25zlF(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩഌ"),L91nVzxH4hYrgPDsOuljXd0J(u"࡚ࠩࡉࡈࡏࡍࡂࠩ഍"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧഎ"),p1lrNRIXqLQJznH6O(u"ࠫࡋࡕࡓࡕࡃࠪഏ"),ZpH2IWt7veyFobTsAnhi41(u"ࠬࡇࡈࡘࡃࡎࠫഐ")]
NcZnzj89hFGQ2EtCP6dorTS += [u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ഑"),xxpPYJOnoAUrlBzyveui(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪഒ"),xxpPYJOnoAUrlBzyveui(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪഓ"),vkMRnTNV9jFm(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫഔ"),zOZvXaebGNwHKfjRA(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬക"),V391t7nQWUBR5euCkJ(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഖ")]
NcZnzj89hFGQ2EtCP6dorTS += [u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ഗ"),zOZvXaebGNwHKfjRA(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨഘ"),vkMRnTNV9jFm(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩങ"),xxpPYJOnoAUrlBzyveui(u"ࠨࡖ࡙ࡊ࡚ࡔࠧച"),KbL94nDHufSF0VcO2Nk3(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫഛ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡗࡍࡕࡆࡉࡃࠪജ")]
NcZnzj89hFGQ2EtCP6dorTS += [KbL94nDHufSF0VcO2Nk3(u"ࠫࡇࡘࡓࡕࡇࡍࠫഝ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬ࡟ࡁࡒࡑࡗࠫഞ"),xxpPYJOnoAUrlBzyveui(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧട"),v7reLlOXCgD5pZ14w2tUA(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨഠ"),uhOkAKtLVv4XTy1nWE6(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ഡ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫഢ"),p1lrNRIXqLQJznH6O(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬണ")]
JZNpY68faPyu79i1QFo  = [ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩത"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ഥ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ദ"),IJ6VkihabRm(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬധ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬന")]
JZNpY68faPyu79i1QFo += [DDS79jdWzLtE(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨഩ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪപ")]
JZNpY68faPyu79i1QFo += [iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬഫ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩബ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩഭ")]
JZNpY68faPyu79i1QFo += [xxpPYJOnoAUrlBzyveui(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪമ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭യ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧര")]
JZNpY68faPyu79i1QFo += [qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬറ"),GGTRaYBDeNyI25zlF(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨല"),Vv0lSjAOHLfMnam3wtdor(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩള")]
wwoA8dieOYFatQ2b = [ddK4MmwpX5oG(u"࠭ࡍ࠴ࡗࠪഴ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡊࡒࡗ࡚ࠬവ"),uhOkAKtLVv4XTy1nWE6(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ശ"),OARzhnB9o7uYvQGFaIcZ(u"ࠩࡌࡊࡎࡒࡍࠨഷ"),uhOkAKtLVv4XTy1nWE6(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫസ")]
BF5e4E9xmzQ81di03DUcPWsaKupgrq = NcZnzj89hFGQ2EtCP6dorTS+JZNpY68faPyu79i1QFo
pgF0ezZWMBqJaufs = NcZnzj89hFGQ2EtCP6dorTS+wwoA8dieOYFatQ2b
wwNYJgTxVyvAzeBka4coQ5tD6 = NcZnzj89hFGQ2EtCP6dorTS+JZNpY68faPyu79i1QFo
piQDKyzne4fXxP7MCqv5lTUOZ = LDhgMOVFsx0JlBfkSap7e9Pm8jG+lu0Fg2DL3MR+e0qL2XFIxmo3YGW+RVHbUrThqOLfY4u27mB
sr71pJ08eD2ZhutRolF = [
						v7reLlOXCgD5pZ14w2tUA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ഹ")
						,qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧഺ")
						,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺ഻ࠧ")
						]
jtJRLy3balg2pFK = [
						Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸ഼ࠬ")
						,HMO0QciekqVpLKmA(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬഽ")
						,L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪാ")
						,zOZvXaebGNwHKfjRA(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫി")
						,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭ീ")
						,dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨു")
						,KbL94nDHufSF0VcO2Nk3(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪൂ")
						,V391t7nQWUBR5euCkJ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫൃ")
						,xxBJoKG54uwQ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬൄ")
						,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭൅")
						,qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪെ")
						,KbL94nDHufSF0VcO2Nk3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫേ")
						,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫൈ")
						]
MFPHOQCR4rstkBTx = jtJRLy3balg2pFK+[
				 IJ6VkihabRm(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡔࡒ࡜࡞ࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ൉")
				,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡋࡘ࡙ࡖࡓࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬൊ")
				,HMO0QciekqVpLKmA(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫോ")
				,xxBJoKG54uwQ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠴ࡱࡨࠬൌ")
				,fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠴ࡷࡹ്࠭")
				,Vv0lSjAOHLfMnam3wtdor(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠶ࡳࡪࠧൎ")
				,HMO0QciekqVpLKmA(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠵ࡸࡺࠧ൏")
				,tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠷ࡴࡤࠨ൐")
				,OARzhnB9o7uYvQGFaIcZ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠹ࡲࡥࠩ൑")
				,IJ6VkihabRm(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡆࡌࡊࡉࡋࡠࡊࡗࡘࡕ࡙࡟ࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ൒")
				,dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ൓")
				,v7reLlOXCgD5pZ14w2tUA(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠴ࡷࡹ࠭ൔ")
				,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠶ࡳࡪࠧൕ")
				,DDS79jdWzLtE(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪൖ")
				,IJ6VkihabRm(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧൗ")
				,uhOkAKtLVv4XTy1nWE6(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ൘")
				]
aaAosTOK3Uegui0dNBIqDEy = [fcIm8tvxlXZsaEY3bwuG4B(u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ൙"),xxpPYJOnoAUrlBzyveui(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ൚"),v7reLlOXCgD5pZ14w2tUA(u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫ൛"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬ൜"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭൝"),Vv0lSjAOHLfMnam3wtdor(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧ൞")]
EGcFon0zR4mSL1 = {
			 fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡂࡍࡒࡅࡒ࠭ൟ")		:[GGTRaYBDeNyI25zlF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶ࠰ࡱ࡯ࡨࠬൠ")]
			,DKqQekNtF6WlJLhBP9M5ca(u"ࠩࡄࡌ࡜ࡇࡋࠨൡ")		:[L91nVzxH4hYrgPDsOuljXd0J(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬൢ")]
			,zOZvXaebGNwHKfjRA(u"ࠫࡆࡑࡗࡂࡏࠪൣ")		:[d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺࠬ൤")]
			,xxBJoKG54uwQ(u"࠭ࡁࡍࡃࡕࡅࡇ࠭൥")		:[xxBJoKG54uwQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ൦")]
			,DDS79jdWzLtE(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ൧")		:[KbL94nDHufSF0VcO2Nk3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼࠧ൨")]
			,dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ൩")		:[v7reLlOXCgD5pZ14w2tUA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ൪")]
			,p1lrNRIXqLQJznH6O(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ൫")	:[OARzhnB9o7uYvQGFaIcZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭൬")]
			,dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ൭")		:[V391t7nQWUBR5euCkJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ൮")]
			,v7reLlOXCgD5pZ14w2tUA(u"ࠩࡅࡓࡐࡘࡁࠨ൯")		:[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ൰")]
			,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫࡇࡘࡓࡕࡇࡍࠫ൱")		:[f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪ൲")]
			,Vv0lSjAOHLfMnam3wtdor(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ൳")		:[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭൴")]
			,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ൵")		:[uhOkAKtLVv4XTy1nWE6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ൶")]
			,uhOkAKtLVv4XTy1nWE6(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ൷")		:[L91nVzxH4hYrgPDsOuljXd0J(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ൸")]
			,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ൹")		:[tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡯࡮ࡴࠧൺ")]
			,HMO0QciekqVpLKmA(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ൻ")	:[ddK4MmwpX5oG(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭ർ")]
			,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫൽ")		:[xxpPYJOnoAUrlBzyveui(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧൾ")]
			,dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧൿ")	:[Vv0lSjAOHLfMnam3wtdor(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠸࠱ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨ඀")]
			,xxBJoKG54uwQ(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧඁ")		:[tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡦࡧࠬං")]
			,zOZvXaebGNwHKfjRA(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ඃ")	:[v7reLlOXCgD5pZ14w2tUA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ඄"),GGTRaYBDeNyI25zlF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫඅ")]
			,xxpPYJOnoAUrlBzyveui(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬආ")		:[L91nVzxH4hYrgPDsOuljXd0J(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧඇ")]
			,uhOkAKtLVv4XTy1nWE6(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨඈ")		:[ddK4MmwpX5oG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰ࠰ࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬඉ")]
			,dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪඊ")		:[DKqQekNtF6WlJLhBP9M5ca(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡦࡩࡴࡰࡴࠪඋ")]
			,DDS79jdWzLtE(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬඌ")		:[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫඍ")]
			,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧඎ")		:[uhOkAKtLVv4XTy1nWE6(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭ඏ")]
			,KbL94nDHufSF0VcO2Nk3(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨඐ")		:[V391t7nQWUBR5euCkJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨඑ")]
			,ZpH2IWt7veyFobTsAnhi41(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫඒ")		:[vkMRnTNV9jFm(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪඓ")]
			,KbL94nDHufSF0VcO2Nk3(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬඔ")		:[xxBJoKG54uwQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡤࡵ࡯ࡦ࠴ࡣࡰ࡯ࠪඕ")]
			,v7reLlOXCgD5pZ14w2tUA(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩඖ")	:[ZpH2IWt7veyFobTsAnhi41(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࡮ࡪࡸ࠮ࡴࡪࡲࡻࠬ඗")]
			,v7reLlOXCgD5pZ14w2tUA(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ඘")		:[fcIm8tvxlXZsaEY3bwuG4B(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯࡮࡬ࡲࡰ࠭඙")]
			,fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬක")		:[tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࡭ࡣ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪඛ")]
			,DDS79jdWzLtE(u"ࠬࡌࡏࡔࡖࡄࠫග")		:[ddK4MmwpX5oG(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹ࡭࠲࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴࡮ࡦࡶࠪඝ")]
			,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩඞ")		:[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪඟ")]
			,OARzhnB9o7uYvQGFaIcZ(u"ࠩࡌࡊࡎࡒࡍࠨච")		:[OARzhnB9o7uYvQGFaIcZ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫඡ"),vkMRnTNV9jFm(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬජ"),uhOkAKtLVv4XTy1nWE6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ඣ"),v7reLlOXCgD5pZ14w2tUA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨඤ"),xxBJoKG54uwQ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧඥ")]
			,KbL94nDHufSF0VcO2Nk3(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫඦ")	:[ddK4MmwpX5oG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪට")]
			,v7reLlOXCgD5pZ14w2tUA(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬඨ")		:[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࡯ࡰ࠰࡮࡭ࡹࡱ࡯ࡵ࠰ࡷࡺࠬඩ")]
			,DDS79jdWzLtE(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫඪ")	:[xxpPYJOnoAUrlBzyveui(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦࠪණ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺࠱ࡪࡼࡹ࠮ࡴࡶࡲࡶࡪ࠭ඬ")]
			,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩත")		:[DDS79jdWzLtE(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰࡴࡪࡹ࡯ࡧࡷ࠲ࡨࡧ࡭ࠨථ")]
			,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡔࡆࡔࡅࡕࠩද")		:[fcIm8tvxlXZsaEY3bwuG4B(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭ධ")]
			,HMO0QciekqVpLKmA(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧන")		:[dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤࡥ࠳ࡩࡡ࡮ࠩ඲")]
			,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫඳ")	:[xxpPYJOnoAUrlBzyveui(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧප")]
			,vkMRnTNV9jFm(u"ࠩࡖࡌࡔࡌࡈࡂࠩඵ")		:[V391t7nQWUBR5euCkJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤ࠯ࡵ࡫ࡳ࡫࡮ࡡ࠯ࡶࡹࠫබ")]
			,xxpPYJOnoAUrlBzyveui(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭භ")		:[fcIm8tvxlXZsaEY3bwuG4B(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬම"),OARzhnB9o7uYvQGFaIcZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ඹ"),ddK4MmwpX5oG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪය")]
			,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡖ࡙ࡊ࡚ࡔࠧර")		:[iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳ࡺࡶࡧࡷࡱ࠲ࡲ࡫ࠧ඼")]
			,OARzhnB9o7uYvQGFaIcZ(u"࡛ࠪࡊࡉࡉࡎࡃࠪල")		:[v7reLlOXCgD5pZ14w2tUA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡾ࡮࠮࠯࠰࠱࠲࠳࡮ࡻࡧࡥࡧࡦ࠻ࡧࡥ࠹ࡲࡨࡪ࠶ࡢࡪࡩ࡯࡬࠳ࡳࡹࡤ࡫࡬ࡱࡦ࠳ࡷࡦࡥ࡬࡭ࡲࡧ࠮ࡴࡪࡲࡴࠬ඾")]
			,dxAs4otSE98YmZnKy2iwRCB(u"ࠬ࡟ࡁࡒࡑࡗࠫ඿")		:[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺ࠰ࡼࡥࡶࡵࡴ࠯ࡶࡹࠫව")]
			,lunVJF2G5bZMgTcCje0vaIB371SX(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨශ")		:[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰࠫෂ")]
			,uhOkAKtLVv4XTy1nWE6(u"ࠩࡕࡉࡕࡕࡓࠨස")		:[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪහ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨළ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩෆ")]
			,L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩ෇")	:[q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ෈"),dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ෉"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯්ࠫ")]
			,DDS79jdWzLtE(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ෋")		:[uhOkAKtLVv4XTy1nWE6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫ෌"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪ෍"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐࠩ෎")]
			}
if a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠲ᒟ"):
	EGcFon0zR4mSL1[zOZvXaebGNwHKfjRA(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧා")] = [p1lrNRIXqLQJznH6O(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪැ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧෑ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ි"),KbL94nDHufSF0VcO2Nk3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩී"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩු"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෕"),zOZvXaebGNwHKfjRA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨූ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡥࡤࡴࡹࡩࡨࡢࠩ෗"),xxpPYJOnoAUrlBzyveui(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪෘ")]
	EGcFon0zR4mSL1[xxBJoKG54uwQ(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧෙ")] = [iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧේ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫෛ"),Vv0lSjAOHLfMnam3wtdor(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪො"),uhOkAKtLVv4XTy1nWE6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ෝ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ෞ"),vkMRnTNV9jFm(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩෟ"),KbL94nDHufSF0VcO2Nk3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ෠"),ddK4MmwpX5oG(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭෡"),p1lrNRIXqLQJznH6O(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ෢")]
else:
	EGcFon0zR4mSL1[v7reLlOXCgD5pZ14w2tUA(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭෣")] = [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ෤"),xxpPYJOnoAUrlBzyveui(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ෥"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭෦"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ෧"),OARzhnB9o7uYvQGFaIcZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ෨"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෩"),OARzhnB9o7uYvQGFaIcZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ෪"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ෫"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ෬")]
	EGcFon0zR4mSL1[xxBJoKG54uwQ(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭෭")] = [V391t7nQWUBR5euCkJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭෮"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ෯"),HMO0QciekqVpLKmA(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ෰"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ෱"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬෲ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨෳ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ෴"),Vv0lSjAOHLfMnam3wtdor(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ෵"),vkMRnTNV9jFm(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭෶")]
zDemIpoFb2UJkGLZQ4 = [p1lrNRIXqLQJznH6O(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ෷"),uhOkAKtLVv4XTy1nWE6(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ෸"),xxpPYJOnoAUrlBzyveui(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ෹"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ෺"),HMO0QciekqVpLKmA(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ෻"),KbL94nDHufSF0VcO2Nk3(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭෼"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩ෽"),KbL94nDHufSF0VcO2Nk3(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭෾"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧ෿")]
ggnJ1x5MSbshUDzXt06WcPrfl = [fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧ฀"),uhOkAKtLVv4XTy1nWE6(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪก"),IJ6VkihabRm(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫข")]
class aMeyPB6AZUTC(ocbOeyJvrhusDq72ZU4FmA):
	def __init__(DD7zNq8ivSuIxpeM,*aargs,**kkwargs):
		DD7zNq8ivSuIxpeM.choiceID = -dxAs4otSE98YmZnKy2iwRCB(u"࠳ᒠ")
	def onClick(DD7zNq8ivSuIxpeM,VYumHcJlzPWkFGb1gX):
		if VYumHcJlzPWkFGb1gX>=p1lrNRIXqLQJznH6O(u"࠼࠴࠶࠶ᒡ"): DD7zNq8ivSuIxpeM.choiceID = VYumHcJlzPWkFGb1gX-p1lrNRIXqLQJznH6O(u"࠼࠴࠶࠶ᒡ")
		DD7zNq8ivSuIxpeM.WQkZeCHGAfSLTrEgo0FRvaj()
	def jjWdipx8KzI(DD7zNq8ivSuIxpeM,*aargs):
		DD7zNq8ivSuIxpeM.button0,DD7zNq8ivSuIxpeM.button1,DD7zNq8ivSuIxpeM.button2 = aargs[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠵ᒣ")],aargs[IJ6VkihabRm(u"࠵ᒢ")],aargs[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠸ᒤ")]
		DD7zNq8ivSuIxpeM.header,DD7zNq8ivSuIxpeM.text = aargs[GGTRaYBDeNyI25zlF(u"࠳ᒥ")],aargs[GGTRaYBDeNyI25zlF(u"࠵ᒦ")]
		DD7zNq8ivSuIxpeM.profile,DD7zNq8ivSuIxpeM.direction = aargs[uhOkAKtLVv4XTy1nWE6(u"࠷ᒧ")],aargs[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠹ᒨ")]
		DD7zNq8ivSuIxpeM.buttonstimeout,DD7zNq8ivSuIxpeM.closetimeout = aargs[V391t7nQWUBR5euCkJ(u"࠼ᒪ")],aargs[DDS79jdWzLtE(u"࠼ᒩ")]
		if DD7zNq8ivSuIxpeM.buttonstimeout>DKqQekNtF6WlJLhBP9M5ca(u"࠶ᒫ") or DD7zNq8ivSuIxpeM.closetimeout>DKqQekNtF6WlJLhBP9M5ca(u"࠶ᒫ"): DD7zNq8ivSuIxpeM.enable_progressbar = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡙ࡸࡵࡦᛨ")
		else: DD7zNq8ivSuIxpeM.enable_progressbar = ddK4MmwpX5oG(u"ࡌࡡ࡭ࡵࡨᛩ")
		DD7zNq8ivSuIxpeM.image_filename = Q0MT56yqDcNnGk.replace(HMO0QciekqVpLKmA(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪฃ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡤ࠭ค")+str(vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time())+dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡥࠧฅ"))
		DD7zNq8ivSuIxpeM.image_filename = DD7zNq8ivSuIxpeM.image_filename.replace(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭࡜࡝ࠩฆ"),HMO0QciekqVpLKmA(u"ࠧ࡝࡞࡟ࡠࠬง")).replace(xxBJoKG54uwQ(u"ࠨ࠱࠲ࠫจ"),GGTRaYBDeNyI25zlF(u"ࠩ࠲࠳࠴࠵ࠧฉ"))
		DD7zNq8ivSuIxpeM.image_height = wTRFaLkJX3nVH8CzcNMZG6pU7Pu2t(DD7zNq8ivSuIxpeM.button0,DD7zNq8ivSuIxpeM.button1,DD7zNq8ivSuIxpeM.button2,DD7zNq8ivSuIxpeM.header,DD7zNq8ivSuIxpeM.text,DD7zNq8ivSuIxpeM.profile,DD7zNq8ivSuIxpeM.direction,DD7zNq8ivSuIxpeM.enable_progressbar,DD7zNq8ivSuIxpeM.image_filename)
		DD7zNq8ivSuIxpeM.show()
		DD7zNq8ivSuIxpeM.getControl(qNZKwi2M1S4fBzGQYrmPnea(u"࠹࠱࠷࠳ᒬ")).setImage(DD7zNq8ivSuIxpeM.image_filename)
		DD7zNq8ivSuIxpeM.getControl(Vv0lSjAOHLfMnam3wtdor(u"࠺࠲࠸࠴ᒭ")).setHeight(DD7zNq8ivSuIxpeM.image_height)
		if not DD7zNq8ivSuIxpeM.button1 and DD7zNq8ivSuIxpeM.button0 and DD7zNq8ivSuIxpeM.button2: DD7zNq8ivSuIxpeM.getControl(L91nVzxH4hYrgPDsOuljXd0J(u"࠼࠴࠶࠸ᒯ")).setPosition(-fcIm8tvxlXZsaEY3bwuG4B(u"࠶࠷࠶ᒰ"),ZpH2IWt7veyFobTsAnhi41(u"࠲ᒮ"))
		return DD7zNq8ivSuIxpeM.image_filename,DD7zNq8ivSuIxpeM.image_height
	def WXaGyudmFB9DUE3vT60r(DD7zNq8ivSuIxpeM):
		if DD7zNq8ivSuIxpeM.buttonstimeout:
			DD7zNq8ivSuIxpeM.th1 = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=DD7zNq8ivSuIxpeM.ccHQZXMvV2wPeIx,args=())
			DD7zNq8ivSuIxpeM.th1.start()
		else: DD7zNq8ivSuIxpeM.DS2CbsYxLQUdzGfW7tjIEwhqM3()
	def ccHQZXMvV2wPeIx(DD7zNq8ivSuIxpeM):
		DD7zNq8ivSuIxpeM.getControl(uhOkAKtLVv4XTy1nWE6(u"࠾࠶࠲࠱ᒱ")).setEnabled(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡔࡳࡷࡨᛪ"))
		for kdWCpE9TjNh in range(xxBJoKG54uwQ(u"࠷ᒲ"),DD7zNq8ivSuIxpeM.buttonstimeout+xxBJoKG54uwQ(u"࠷ᒲ")):
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠱ᒳ"))
			hNfoJ0ItGVPmz5gZHQ4a6nuRBlAF = int(uhOkAKtLVv4XTy1nWE6(u"࠲࠲࠳ᒴ")*kdWCpE9TjNh/DD7zNq8ivSuIxpeM.buttonstimeout)
			DD7zNq8ivSuIxpeM.vfrP7FQled8Kpsx3SJgq(hNfoJ0ItGVPmz5gZHQ4a6nuRBlAF)
			if DD7zNq8ivSuIxpeM.choiceID>qNZKwi2M1S4fBzGQYrmPnea(u"࠲ᒵ"): break
		DD7zNq8ivSuIxpeM.DS2CbsYxLQUdzGfW7tjIEwhqM3()
	def XF1C6ruN9bKpPndc3kIZ(DD7zNq8ivSuIxpeM):
		if DD7zNq8ivSuIxpeM.closetimeout:
			DD7zNq8ivSuIxpeM.th2 = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=DD7zNq8ivSuIxpeM.ngcJArLj1xk,args=())
			DD7zNq8ivSuIxpeM.th2.start()
		else: DD7zNq8ivSuIxpeM.DS2CbsYxLQUdzGfW7tjIEwhqM3()
	def ngcJArLj1xk(DD7zNq8ivSuIxpeM):
		DD7zNq8ivSuIxpeM.getControl(dxAs4otSE98YmZnKy2iwRCB(u"࠼࠴࠷࠶ᒶ")).setEnabled(KbL94nDHufSF0VcO2Nk3(u"ࡕࡴࡸࡩ᛫"))
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(DD7zNq8ivSuIxpeM.buttonstimeout)
		for kdWCpE9TjNh in range(DD7zNq8ivSuIxpeM.closetimeout-d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵ᒷ"),-d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵ᒷ"),-d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵ᒷ")):
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(v7reLlOXCgD5pZ14w2tUA(u"࠶ᒸ"))
			hNfoJ0ItGVPmz5gZHQ4a6nuRBlAF = int(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠷࠰࠱ᒹ")*kdWCpE9TjNh/DD7zNq8ivSuIxpeM.closetimeout)
			DD7zNq8ivSuIxpeM.vfrP7FQled8Kpsx3SJgq(hNfoJ0ItGVPmz5gZHQ4a6nuRBlAF)
			if DD7zNq8ivSuIxpeM.choiceID>L91nVzxH4hYrgPDsOuljXd0J(u"࠰ᒺ"): break
		if DD7zNq8ivSuIxpeM.closetimeout>Vv0lSjAOHLfMnam3wtdor(u"࠱ᒻ"): DD7zNq8ivSuIxpeM.choiceID = ZpH2IWt7veyFobTsAnhi41(u"࠳࠳ᒼ")
		DD7zNq8ivSuIxpeM.WQkZeCHGAfSLTrEgo0FRvaj()
	def vfrP7FQled8Kpsx3SJgq(DD7zNq8ivSuIxpeM,hNfoJ0ItGVPmz5gZHQ4a6nuRBlAF):
		DD7zNq8ivSuIxpeM.precent = hNfoJ0ItGVPmz5gZHQ4a6nuRBlAF
		DD7zNq8ivSuIxpeM.getControl(Vv0lSjAOHLfMnam3wtdor(u"࠼࠴࠷࠶ᒽ")).setPercent(DD7zNq8ivSuIxpeM.precent)
	def DS2CbsYxLQUdzGfW7tjIEwhqM3(DD7zNq8ivSuIxpeM):
		if DD7zNq8ivSuIxpeM.button0: DD7zNq8ivSuIxpeM.getControl(v7reLlOXCgD5pZ14w2tUA(u"࠽࠵࠷࠰ᒾ")).setEnabled(fcIm8tvxlXZsaEY3bwuG4B(u"ࡖࡵࡹࡪ᛬"))
		if DD7zNq8ivSuIxpeM.button1: DD7zNq8ivSuIxpeM.getControl(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠾࠶࠱࠲ᒿ")).setEnabled(KbL94nDHufSF0VcO2Nk3(u"ࡗࡶࡺ࡫᛭"))
		if DD7zNq8ivSuIxpeM.button2: DD7zNq8ivSuIxpeM.getControl(GGTRaYBDeNyI25zlF(u"࠿࠰࠲࠴ᓀ")).setEnabled(OARzhnB9o7uYvQGFaIcZ(u"ࡘࡷࡻࡥᛮ"))
	def WQkZeCHGAfSLTrEgo0FRvaj(DD7zNq8ivSuIxpeM):
		DD7zNq8ivSuIxpeM.close()
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(DD7zNq8ivSuIxpeM.image_filename)
		except: pass
class kZ05eRcAtxbP1ID():
	def __init__(DD7zNq8ivSuIxpeM,showDialogs=f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡌࡡ࡭ࡵࡨᛰ"),logErrors=v7reLlOXCgD5pZ14w2tUA(u"࡙ࡸࡵࡦᛯ")):
		DD7zNq8ivSuIxpeM.showDialogs = showDialogs
		DD7zNq8ivSuIxpeM.logErrors = logErrors
		DD7zNq8ivSuIxpeM.finishedLIST,DD7zNq8ivSuIxpeM.failedLIST = [],[]
		DD7zNq8ivSuIxpeM.statusDICT,DD7zNq8ivSuIxpeM.resultsDICT = {},{}
		DD7zNq8ivSuIxpeM.processesLIST = []
		DD7zNq8ivSuIxpeM.starttimeDICT,DD7zNq8ivSuIxpeM.finishtimeDICT,DD7zNq8ivSuIxpeM.elpasedtimeDICT = {},{},{}
	def NLgdvIUqGZ1enEjfW7bkrsy48a(DD7zNq8ivSuIxpeM,ouHBbYIgr2,xamBlEfohPg1nzw3SRQisLG,*aargs):
		ouHBbYIgr2 = str(ouHBbYIgr2)
		DD7zNq8ivSuIxpeM.statusDICT[ouHBbYIgr2] = p1lrNRIXqLQJznH6O(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫช")
		if DD7zNq8ivSuIxpeM.showDialogs: uFCykYQW68S(qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࠬซ"),ouHBbYIgr2)
		PFwTfcL1r0eS3VqH9GmQkY2hx = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=DD7zNq8ivSuIxpeM.YDFBWVAmMvzKE3tQOwkN8dCLUS0,args=(ouHBbYIgr2,xamBlEfohPg1nzw3SRQisLG,aargs))
		DD7zNq8ivSuIxpeM.processesLIST.append(PFwTfcL1r0eS3VqH9GmQkY2hx)
		return PFwTfcL1r0eS3VqH9GmQkY2hx
	def yP9H5KOS6TYglVdxurU(DD7zNq8ivSuIxpeM,ouHBbYIgr2,xamBlEfohPg1nzw3SRQisLG,*aargs):
		PFwTfcL1r0eS3VqH9GmQkY2hx = DD7zNq8ivSuIxpeM.NLgdvIUqGZ1enEjfW7bkrsy48a(ouHBbYIgr2,xamBlEfohPg1nzw3SRQisLG,*aargs)
		PFwTfcL1r0eS3VqH9GmQkY2hx.start()
	def YDFBWVAmMvzKE3tQOwkN8dCLUS0(DD7zNq8ivSuIxpeM,ouHBbYIgr2,xamBlEfohPg1nzw3SRQisLG,aargs):
		ouHBbYIgr2 = str(ouHBbYIgr2)
		DD7zNq8ivSuIxpeM.starttimeDICT[ouHBbYIgr2] = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
		try:
			DD7zNq8ivSuIxpeM.resultsDICT[ouHBbYIgr2] = xamBlEfohPg1nzw3SRQisLG(*aargs)
			if p1lrNRIXqLQJznH6O(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ฌ") in str(xamBlEfohPg1nzw3SRQisLG) and not DD7zNq8ivSuIxpeM.resultsDICT[ouHBbYIgr2].succeeded:
				RYNAu9Eo7mgOi0sG1j(HMO0QciekqVpLKmA(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬญ"))
			DD7zNq8ivSuIxpeM.finishedLIST.append(ouHBbYIgr2)
			DD7zNq8ivSuIxpeM.statusDICT[ouHBbYIgr2] = zOZvXaebGNwHKfjRA(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩฎ")
		except Exception as L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA:
			if DD7zNq8ivSuIxpeM.logErrors:
				CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
				if CeJXk5gb27o!=xxpPYJOnoAUrlBzyveui(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫฏ"): GJtcqTv68ZQpwxYFiDg.stderr.write(CeJXk5gb27o)
			DD7zNq8ivSuIxpeM.failedLIST.append(ouHBbYIgr2)
			DD7zNq8ivSuIxpeM.statusDICT[ouHBbYIgr2] = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩฐ")
		DD7zNq8ivSuIxpeM.finishtimeDICT[ouHBbYIgr2] = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
		DD7zNq8ivSuIxpeM.elpasedtimeDICT[ouHBbYIgr2] = DD7zNq8ivSuIxpeM.finishtimeDICT[ouHBbYIgr2] - DD7zNq8ivSuIxpeM.starttimeDICT[ouHBbYIgr2]
	def ChL39J5erzSfMZv76(DD7zNq8ivSuIxpeM):
		for FXiLWqcjyHtu0Isp in DD7zNq8ivSuIxpeM.processesLIST:
			FXiLWqcjyHtu0Isp.start()
	def n6pOjVhX2U(DD7zNq8ivSuIxpeM):
		while q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫฑ") in list(DD7zNq8ivSuIxpeM.statusDICT.values()): vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠱࠯࠲࠳࠴ᓁ"))
def mclVBgDPzrQLK6I573():
	LHOA6hkrq47JzTQ85ZnUu = fQ6kvwg1FrYAzXjbLT.getSetting(ZpH2IWt7veyFobTsAnhi41(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨฒ"))
	if LHOA6hkrq47JzTQ85ZnUu==uVp7krjL48oWd3tqGYCRz5M:
		yF0rb7IBDNSHhmWA1ZEQ6d2spPUc,ZKlH8DTFWhJPO1R9vxboUe = fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨณ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡆࡢ࡮ࡶࡩᛱ")
		return yF0rb7IBDNSHhmWA1ZEQ6d2spPUc,ZKlH8DTFWhJPO1R9vxboUe
	try: YcJmC0W43u5idIELnHTU2XSsMPNt.makedirs(vBXJAQCwEpS0xZ6km9a)
	except: pass
	yF0rb7IBDNSHhmWA1ZEQ6d2spPUc,ZKlH8DTFWhJPO1R9vxboUe = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫด"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡕࡴࡸࡩᛲ")
	GxWpPovnEYDwfCtVcb85QdL6ayXJ = [v7reLlOXCgD5pZ14w2tUA(u"ࠧ࠹࠰࠸࠲࠵࠭ต"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ࠬถ"),zOZvXaebGNwHKfjRA(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧࠧท"),OARzhnB9o7uYvQGFaIcZ(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧธ"),uhOkAKtLVv4XTy1nWE6(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨน"),vkMRnTNV9jFm(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩบ"),fcIm8tvxlXZsaEY3bwuG4B(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪป"),GGTRaYBDeNyI25zlF(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫผ"),IJ6VkihabRm(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬฝ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭พ"),xxBJoKG54uwQ(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧฟ")]
	zyhnltJdqoBGprkFUINKRj = GxWpPovnEYDwfCtVcb85QdL6ayXJ[-xxBJoKG54uwQ(u"࠲ᓂ")]
	lzQPaZstdyg6RE0C89 = XQCSoqYpy2EAu6J(zyhnltJdqoBGprkFUINKRj)
	QM8XmHE5VeP = XQCSoqYpy2EAu6J(uVp7krjL48oWd3tqGYCRz5M)
	if QM8XmHE5VeP>lzQPaZstdyg6RE0C89:
		yF0rb7IBDNSHhmWA1ZEQ6d2spPUc = HMO0QciekqVpLKmA(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫภ")
	return yF0rb7IBDNSHhmWA1ZEQ6d2spPUc,ZKlH8DTFWhJPO1R9vxboUe
def gMmSViGyftbOI():
	if HMO0QciekqVpLKmA(u"࠳ᓃ"):
		ktsDwofmreaK = lunVJF2G5bZMgTcCje0vaIB371SX(u"࠳ᓄ")
		for g8DC39dWMXIQzbL,RuTpf6SV4Odzc3UA,HVo1hFNm72wup35f in YcJmC0W43u5idIELnHTU2XSsMPNt.walk(E5bapZAYUTcnFCmuPGztDrfMq,topdown=q0JfWbP8vACLxSNIncpOXkR6j(u"ࡈࡤࡰࡸ࡫ᛳ")):
			ktsDwofmreaK += len(HVo1hFNm72wup35f)
	if ktsDwofmreaK>DDS79jdWzLtE(u"࠹࠵࠶࠰ᓅ"): Qzbnt3opXim(E5bapZAYUTcnFCmuPGztDrfMq,Vv0lSjAOHLfMnam3wtdor(u"ࡘࡷࡻࡥᛵ"),p1lrNRIXqLQJznH6O(u"ࡉࡥࡱࡹࡥᛴ"))
	return
def p69eMXdJCmFbIw(ymraFo65GxbqVg8YeLHct4Zl2,G7XkvOrob5CBiAMFcVemDz4EZ1atxg):
	BcMl3XdLS0zmK1jPvDJANfYH,eyVMOEac7fTNr3xg0ZwktiGJl,LnsZiRWqVNw2Ju = p1lrNRIXqLQJznH6O(u"࡚ࡲࡶࡧᛷ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡋࡧ࡬ࡴࡧᛶ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡋࡧ࡬ࡴࡧᛶ")
	xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp,PBem6Hqsfgjvz,j6UVYSdO2Qy134nlvK,HG0vEntrbRUK4ZTNx,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2 = ymraFo65GxbqVg8YeLHct4Zl2
	zzsnJpTkul = xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp,PBem6Hqsfgjvz,j6UVYSdO2Qy134nlvK,HG0vEntrbRUK4ZTNx,gq2FVNBUKPzIw1pZAnYHJG,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠭ม"),RkfstxEyua67K2
	hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j = int(PBem6Hqsfgjvz)
	h1SR3xf9Ak0ZQKgYFbzBGNDp = int(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j%q0JfWbP8vACLxSNIncpOXkR6j(u"࠶࠶ᓆ"))
	MQrIDuiRAGExksvoLC9Onmgb = int(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j/Vv0lSjAOHLfMnam3wtdor(u"࠷࠰ᓇ"))
	XXYOVRlPJd5F9UjLG = fQ6kvwg1FrYAzXjbLT.getSetting(fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ย"))
	if not XXYOVRlPJd5F9UjLG: fQ6kvwg1FrYAzXjbLT.setSetting(uhOkAKtLVv4XTy1nWE6(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧร"),HMO0QciekqVpLKmA(u"ࠨࡃࡘࡘࡔ࠭ฤ"))
	OU647KvMtLAfFm,ZKlH8DTFWhJPO1R9vxboUe = mclVBgDPzrQLK6I573()
	if ZKlH8DTFWhJPO1R9vxboUe:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠩࠪล"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࠫฦ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧว"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬศ")+uVp7krjL48oWd3tqGYCRz5M)
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,GGTRaYBDeNyI25zlF(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩษ"),zOZvXaebGNwHKfjRA(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪส"))
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,Vv0lSjAOHLfMnam3wtdor(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫห"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪฬ"))
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭อ"),IJ6VkihabRm(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩฮ"))
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,KbL94nDHufSF0VcO2Nk3(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨฯ"),dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫะ"))
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,p1lrNRIXqLQJznH6O(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪั"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧา"))
		fQ6kvwg1FrYAzXjbLT.setSetting(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩำ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࠫิ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(uhOkAKtLVv4XTy1nWE6(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭ี"),DDS79jdWzLtE(u"ࠬ࠭ึ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(DDS79jdWzLtE(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩื"),ddK4MmwpX5oG(u"ࠧࠨุ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ูࠫ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ฺࠩࠪ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷࠬ฻"),OARzhnB9o7uYvQGFaIcZ(u"ࠫࠬ฼"))
		fQ6kvwg1FrYAzXjbLT.setSetting(V391t7nQWUBR5euCkJ(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ฽"),p1lrNRIXqLQJznH6O(u"࠭ࠧ฾"))
		fQ6kvwg1FrYAzXjbLT.setSetting(xxBJoKG54uwQ(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫ฿"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࠩเ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(zOZvXaebGNwHKfjRA(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩแ"),IJ6VkihabRm(u"ࠪࠫโ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(DDS79jdWzLtE(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬใ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࠭ไ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨๅ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࠨๆ"))
		import IFHE2MSfi5
		if OU647KvMtLAfFm==p1lrNRIXqLQJznH6O(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ็"):
			zRM3tZx2v6DjJU(zOZvXaebGNwHKfjRA(u"ࠩࡑࡓ࡙ࡏࡃࡆ่ࠩ"),DDS79jdWzLtE(u"ࠪ࠲ࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿้࡛ࠦࠡࠩ")+a4EuYDiRdrA+p1lrNRIXqLQJznH6O(u"ࠫࠥࡣ๊ࠧ"))
			QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,p1lrNRIXqLQJznH6O(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ๋࠭"))
			QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭์"))
			QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ํ"))
			zKUEjGW1YecZHiyoPRal4LMQrvsX(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࡔࡳࡷࡨᛸ"),[oorOICHY4MvRsWg1Xk8])
		else:
			zRM3tZx2v6DjJU(p1lrNRIXqLQJznH6O(u"ࠨࡐࡒࡘࡎࡉࡅࠨ๎"),HMO0QciekqVpLKmA(u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭๏")+a4EuYDiRdrA+xxpPYJOnoAUrlBzyveui(u"ࠪࠤࡢ࠭๐"))
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(DKqQekNtF6WlJLhBP9M5ca(u"ࠫࠬ๑"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬ࠭๒"),vkMRnTNV9jFm(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ๓"),vkMRnTNV9jFm(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪ๔"))
			zKUEjGW1YecZHiyoPRal4LMQrvsX(fcIm8tvxlXZsaEY3bwuG4B(u"ࡇࡣ࡯ࡷࡪ᛹"),[])
			tb6VfQWohldXaqIvCYiw(vkMRnTNV9jFm(u"ࡈࡤࡰࡸ࡫᛺"))
			IFHE2MSfi5.T65coqAhLzyGMmQ7tlN()
			IFHE2MSfi5.ua95I6RK27wGQgmYXqc(IJ6VkihabRm(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๕"),p1lrNRIXqLQJznH6O(u"ࡉࡥࡱࡹࡥ᛻"))
			IFHE2MSfi5.ua95I6RK27wGQgmYXqc(DKqQekNtF6WlJLhBP9M5ca(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ๖"),V391t7nQWUBR5euCkJ(u"ࡊࡦࡲࡳࡦ᛼"))
			IFHE2MSfi5.rVwqOcjQa5zDPE(ZpH2IWt7veyFobTsAnhi41(u"ࡋࡧ࡬ࡴࡧ᛽"))
			IFHE2MSfi5.i1eUnRIqv39loL(vkMRnTNV9jFm(u"ࡌࡡ࡭ࡵࡨ᛾"))
			IFHE2MSfi5.OAMvDTS3GVkCyjWzJgb(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ๗"),dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫ๘"),V391t7nQWUBR5euCkJ(u"ࡆࡢ࡮ࡶࡩ᛿"))
			try:
				Y18YnezD9vuWTLZVcxFrflBg = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๙"),vkMRnTNV9jFm(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๚"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ๛"),ZpH2IWt7veyFobTsAnhi41(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๜"))
				K6W7q3ygn21frhxL = x1KknCETNQp.Addon(id=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭๝"))
				K6W7q3ygn21frhxL.setSetting(OARzhnB9o7uYvQGFaIcZ(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩ๞"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ๟"))
			except: pass
			try:
				Y18YnezD9vuWTLZVcxFrflBg = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๠"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๡"),V391t7nQWUBR5euCkJ(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ๢"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๣"))
				K6W7q3ygn21frhxL = x1KknCETNQp.Addon(id=L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭๤"))
				K6W7q3ygn21frhxL.setSetting(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭๥"),IJ6VkihabRm(u"ࠫ࠸࠭๦"))
			except: pass
			try:
				Y18YnezD9vuWTLZVcxFrflBg = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,xxpPYJOnoAUrlBzyveui(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๧"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๨"),v7reLlOXCgD5pZ14w2tUA(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ๩"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๪"))
				K6W7q3ygn21frhxL = x1KknCETNQp.Addon(id=dxAs4otSE98YmZnKy2iwRCB(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๫"))
				K6W7q3ygn21frhxL.setSetting(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ๬"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫ࠷࠭๭"))
			except: pass
		ZEJAFRNxIrQSU = MMnGsYl0Oh9zgub43E5m(PPgJ3en0yKYWdzMAmCON1DTQG9)
		ZEJAFRNxIrQSU = MMnGsYl0Oh9zgub43E5m(KmlAH1VJObEkfZS3ToazF8qNP70t)
		fQ6kvwg1FrYAzXjbLT.setSetting(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ๮"),uVp7krjL48oWd3tqGYCRz5M)
		IFHE2MSfi5.DuBVAHl4FZjxJLcRp8ehst(fcIm8tvxlXZsaEY3bwuG4B(u"ࡇࡣ࡯ࡷࡪᜀ"))
		return
	PqREL0OwgzB = fQ6kvwg1FrYAzXjbLT.getSetting(IJ6VkihabRm(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ๯"))
	nZkScXxgspimo41H36h = rIPlaEZu19UKnXGAFzcyfM6oegdSj(G7XkvOrob5CBiAMFcVemDz4EZ1atxg)
	CuiSrRzIOtfqKX2FPVoAcELM9gv70J = rIPlaEZu19UKnXGAFzcyfM6oegdSj(QEMyY8a9IoOcFqeuKztCVWmT7jXv)
	A94UXIVglhTv = [OARzhnB9o7uYvQGFaIcZ(u"࠰ᓏ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠲࠷ᓉ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳࠺ᓊ"),p1lrNRIXqLQJznH6O(u"࠴࠽ᓋ"),DDS79jdWzLtE(u"࠲࠷ᓈ"),DDS79jdWzLtE(u"࠹࠴ᓎ"),Vv0lSjAOHLfMnam3wtdor(u"࠹࠵ᓌ"),v7reLlOXCgD5pZ14w2tUA(u"࠺࠹ᓍ")]
	SaXLTb8pMdl0ZUEf = [GGTRaYBDeNyI25zlF(u"࠱ᓗ"),Vv0lSjAOHLfMnam3wtdor(u"࠳࠸ᓑ"),dxAs4otSE98YmZnKy2iwRCB(u"࠴࠻ᓒ"),xxBJoKG54uwQ(u"࠵࠾ᓓ"),OARzhnB9o7uYvQGFaIcZ(u"࠳࠸ᓐ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠳࠵ᓖ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠺࠶ᓔ"),DKqQekNtF6WlJLhBP9M5ca(u"࠻࠳ᓕ")]
	o5UYGk21fg6sjr7aHdlD9hQcuxZ = MQrIDuiRAGExksvoLC9Onmgb not in SaXLTb8pMdl0ZUEf
	uNCpTL5UKV3i6cjtHgyWzMP = MQrIDuiRAGExksvoLC9Onmgb in [lunVJF2G5bZMgTcCje0vaIB371SX(u"࠷࠹ᓛ"),OARzhnB9o7uYvQGFaIcZ(u"࠴࠻ᓘ"),xxpPYJOnoAUrlBzyveui(u"࠻࠶ᓚ"),ddK4MmwpX5oG(u"࠺࠶ᓙ")]
	vGtAoB3UVHClhXQOx0Zmd6cg2 = hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j in [HMO0QciekqVpLKmA(u"࠲࠷࠷ᓝ"),dxAs4otSE98YmZnKy2iwRCB(u"࠸࠷࠱ᓜ")]
	XHZ1GxfvDC4Mtz = (o5UYGk21fg6sjr7aHdlD9hQcuxZ or uNCpTL5UKV3i6cjtHgyWzMP) and not vGtAoB3UVHClhXQOx0Zmd6cg2
	MMjmzq2wGXWDdFefPON49BYx5 = PqREL0OwgzB!=dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ๰") and (PqREL0OwgzB or not ja74FTtz9hK)
	C7v9ko0fqa4g1zSYZlUTdVBWEJ5y = qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡶࡼࡴࡪࡃࠧ๱") in PqREL0OwgzB
	N5dvGY0pWJ = hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j in [Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠵࠻࠷ᓨ"),zOZvXaebGNwHKfjRA(u"࠶࠼࠲ᓩ"),v7reLlOXCgD5pZ14w2tUA(u"࠷࠶࠴ᓪ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠱࠷࠶ᓤ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠲࠸࠸ᓥ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠳࠹࠺ᓦ"),ZpH2IWt7veyFobTsAnhi41(u"࠴࠺࠼ᓧ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠷࠶࠹ᓣ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠺࠺࠶ᓠ"),V391t7nQWUBR5euCkJ(u"࠸࠸࠵ᓞ"),DDS79jdWzLtE(u"࠹࠹࠷ᓟ"),OARzhnB9o7uYvQGFaIcZ(u"࠻࠻࠺ᓡ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠼࠼࠵ᓢ")]
	mt4qhKoi9ynlYXFRszgZ7b3wr = h1SR3xf9Ak0ZQKgYFbzBGNDp==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠹ᓫ") or hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j in [xxBJoKG54uwQ(u"࠳࠷࠹ᓭ"),p1lrNRIXqLQJznH6O(u"࠹࠶࠼ᓯ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠸࠶࠸ᓮ"),p1lrNRIXqLQJznH6O(u"࠵࠷ᓬ")]
	oUTjkWYSX4P26g3fHOLw = not N5dvGY0pWJ
	xAgDFRYGUVdh5bOZ3fuTNcikyBp = not mt4qhKoi9ynlYXFRszgZ7b3wr
	jj9k8Z4coMfiEdCx0K = nZkScXxgspimo41H36h in [DKqQekNtF6WlJLhBP9M5ca(u"ࠩࠪ๲"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࠲࠳࠭๳")]
	uuzOYt6Xcq = jj9k8Z4coMfiEdCx0K or oUTjkWYSX4P26g3fHOLw
	OzmL7sNeQvkcElajw = jj9k8Z4coMfiEdCx0K or xAgDFRYGUVdh5bOZ3fuTNcikyBp or C7v9ko0fqa4g1zSYZlUTdVBWEJ5y
	xo3pWsUKaHyPIkbgG4XA = hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j not in [d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠴࠹࠴ᓴ"),GGTRaYBDeNyI25zlF(u"࠷࠼࠱ᓰ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠵࠺࠺ᓵ"),xxBJoKG54uwQ(u"࠲࠸࠲ᓲ"),Vv0lSjAOHLfMnam3wtdor(u"࠹࠳࠱ᓱ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"࠶࠶࠳ᓳ")]
	if XXYOVRlPJd5F9UjLG==uhOkAKtLVv4XTy1nWE6(u"ࠫࡘ࡚ࡏࡑࠩ๴"): xBcZnOKfd3vs4PEzULMT2Ro = mt4qhKoi9ynlYXFRszgZ7b3wr or N5dvGY0pWJ
	else: xBcZnOKfd3vs4PEzULMT2Ro = zOZvXaebGNwHKfjRA(u"ࡖࡵࡹࡪᜁ")
	HZvahc0Qpx = MQrIDuiRAGExksvoLC9Onmgb in [Vv0lSjAOHLfMnam3wtdor(u"࠼࠺ᓷ"),fcIm8tvxlXZsaEY3bwuG4B(u"࠻࠺ᓶ")]
	pKeSBvams1NITiPW73xDOAcok0468 = hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j in [a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠸࠸࠱ᓸ"),Vv0lSjAOHLfMnam3wtdor(u"࠷࠳࠲ᓹ")]
	U3PmWw59Hq2SFdX = not HZvahc0Qpx and not pKeSBvams1NITiPW73xDOAcok0468
	zznqPZeV4B = uuzOYt6Xcq and OzmL7sNeQvkcElajw and xo3pWsUKaHyPIkbgG4XA and xBcZnOKfd3vs4PEzULMT2Ro and U3PmWw59Hq2SFdX
	QQp0Gjr3lRF6TPudnkwV4ezDOZ7at8 = xo3pWsUKaHyPIkbgG4XA and xBcZnOKfd3vs4PEzULMT2Ro and U3PmWw59Hq2SFdX
	HOf5JibCMpvjKLZtq9m1TSR8hz = QQp0Gjr3lRF6TPudnkwV4ezDOZ7at8
	okifblJcEvFe9AWunXBCHs72 = fQ6kvwg1FrYAzXjbLT.getSetting(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡴࡷࡵࡶࡪࡦࡨࡶࠬ๵"))
	dzsUr8Z9yqMlTLSG = fQ6kvwg1FrYAzXjbLT.getSetting(p1lrNRIXqLQJznH6O(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡨࡵࡤࡦࠩ๶"))
	if f8PVRTseIuj9BckO6GoyF5Lxv(u"࠲ᓺ") and MMjmzq2wGXWDdFefPON49BYx5 and zznqPZeV4B:
		PX0li7GsoDQUnuI2ZONybSd9hY = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,GGTRaYBDeNyI25zlF(u"ࠧ࡭࡫ࡶࡸࠬ๷"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ๸")+okifblJcEvFe9AWunXBCHs72+Vv0lSjAOHLfMnam3wtdor(u"ࠩࡢࠫ๹")+dzsUr8Z9yqMlTLSG,zzsnJpTkul)
		if PX0li7GsoDQUnuI2ZONybSd9hY:
			zRM3tZx2v6DjJU(IJ6VkihabRm(u"ࠪࠫ๺"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭๻")+okifblJcEvFe9AWunXBCHs72+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࡥࠧ๼")+dzsUr8Z9yqMlTLSG+DDS79jdWzLtE(u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ๽"))
			if fcIm8tvxlXZsaEY3bwuG4B(u"࠳ᓻ") and C7v9ko0fqa4g1zSYZlUTdVBWEJ5y:
				vUqdiZGEWlgY1b8RXfS4aoCnsuV5B = []
				from nhi96mOBQf import XXAJlsZf2voNP8r
				from pKTdzCL61S import Gmw6J5PRDV7kStnI0KzH9oa,yFAKIp45tgeszSo1hLX7nVxMEC
				OdWFr62gJwzDRoBMeT9Zm = XXAJlsZf2voNP8r
				HH4dKrUWtahnkl7YI = Gmw6J5PRDV7kStnI0KzH9oa()
				w6V3bGjHMLO01fPv5tInupA = PqREL0OwgzB
				PbimW7038Z29HRTNC,wtP5U7DjFWNqdbGOJomR,wwtDgAROoBVI2sKzP97N,tzcRiGgINyMVjqHQ4sDS9Jb0eFUEL,mINvUGLl8STsC2XyOuxQ7bhq,XMCmpKfS0QE2xUhuvg4lR16rTq,Ewc3qAmxiZ,AJzliwC4emMfjBd7I,Pi0H3cXFM4EWa = JJqxTSR6tZiQ79cpkwa3GMy(w6V3bGjHMLO01fPv5tInupA)
				OKDjlZcGaCdwFmPpfTBiXUqsJE6 = PbimW7038Z29HRTNC,wtP5U7DjFWNqdbGOJomR,wwtDgAROoBVI2sKzP97N,tzcRiGgINyMVjqHQ4sDS9Jb0eFUEL,mINvUGLl8STsC2XyOuxQ7bhq,XMCmpKfS0QE2xUhuvg4lR16rTq,Ewc3qAmxiZ,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࠨ๾"),Pi0H3cXFM4EWa
				for yHaCElem83DpR0SNrqPs in PX0li7GsoDQUnuI2ZONybSd9hY:
					aa6rdVMlZ8xwfJYPiQF2UN7 = yHaCElem83DpR0SNrqPs[xxBJoKG54uwQ(u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ๿")]
					if aa6rdVMlZ8xwfJYPiQF2UN7==OKDjlZcGaCdwFmPpfTBiXUqsJE6 or yHaCElem83DpR0SNrqPs[dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡰࡳࡩ࡫ࠧ຀")] in [xxpPYJOnoAUrlBzyveui(u"࠶࠻࠻ᓽ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠵࠻࠵ᓼ")]:
						yHaCElem83DpR0SNrqPs = vWnPs3MOUKJCFGz(aa6rdVMlZ8xwfJYPiQF2UN7,OdWFr62gJwzDRoBMeT9Zm,HH4dKrUWtahnkl7YI)
						if yHaCElem83DpR0SNrqPs[HMO0QciekqVpLKmA(u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭ກ")]:
							maC4Mi29k6ZQINFHUw = yFAKIp45tgeszSo1hLX7nVxMEC(HH4dKrUWtahnkl7YI,aa6rdVMlZ8xwfJYPiQF2UN7,yHaCElem83DpR0SNrqPs[DDS79jdWzLtE(u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬຂ")])
							yHaCElem83DpR0SNrqPs[KbL94nDHufSF0VcO2Nk3(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ຃")] = maC4Mi29k6ZQINFHUw+yHaCElem83DpR0SNrqPs[qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬຄ")]
					vUqdiZGEWlgY1b8RXfS4aoCnsuV5B.append(yHaCElem83DpR0SNrqPs)
				fQ6kvwg1FrYAzXjbLT.setSetting(ZpH2IWt7veyFobTsAnhi41(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ຅"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠩຆ"))
				if xEc7nR3qoAlv6C8YjD==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡩࡳࡱࡪࡥࡳࠩງ"): mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,zOZvXaebGNwHKfjRA(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩຈ")+okifblJcEvFe9AWunXBCHs72+xxpPYJOnoAUrlBzyveui(u"ࠫࡤ࠭ຉ")+dzsUr8Z9yqMlTLSG,zzsnJpTkul,vUqdiZGEWlgY1b8RXfS4aoCnsuV5B,t7rXIzJfMLWRwaDeKhTq4C6dG)
			else: vUqdiZGEWlgY1b8RXfS4aoCnsuV5B = PX0li7GsoDQUnuI2ZONybSd9hY
			if xEc7nR3qoAlv6C8YjD==xxpPYJOnoAUrlBzyveui(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬຊ") and nZkScXxgspimo41H36h!=fcIm8tvxlXZsaEY3bwuG4B(u"࠭࠮࠯ࠩ຋") and XHZ1GxfvDC4Mtz: DZP9fVUE7eCnTgQkiYy8RFGNraAKB()
			zmJjq3PXn06UMuvV7k = ttY9W3n7TpU(zzsnJpTkul,vUqdiZGEWlgY1b8RXfS4aoCnsuV5B,BcMl3XdLS0zmK1jPvDJANfYH,eyVMOEac7fTNr3xg0ZwktiGJl,LnsZiRWqVNw2Ju)
			return
	elif xEc7nR3qoAlv6C8YjD==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຌ") and PqREL0OwgzB==ZpH2IWt7veyFobTsAnhi41(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫຍ") and QQp0Gjr3lRF6TPudnkwV4ezDOZ7at8:
		QUydweutaN3vRfhF4qVk2P5W8BLJic(oorOICHY4MvRsWg1Xk8,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨຎ")+okifblJcEvFe9AWunXBCHs72+V391t7nQWUBR5euCkJ(u"ࠪࡣࠬຏ")+dzsUr8Z9yqMlTLSG,zzsnJpTkul)
	if ja74FTtz9hK:
		if HMO0QciekqVpLKmA(u"ࠫࡤ࠭ຐ") in ja74FTtz9hK: mnB6YkIKS4oZuMHOqT,oKreBlqv3sAP1XaV = ja74FTtz9hK.split(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡥࠧຑ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠶ᓾ"))
		else: mnB6YkIKS4oZuMHOqT,oKreBlqv3sAP1XaV = ja74FTtz9hK,ZpH2IWt7veyFobTsAnhi41(u"࠭ࠧຒ")
		if mnB6YkIKS4oZuMHOqT in [vkMRnTNV9jFm(u"ࠧ࠲ࠩຓ"),V391t7nQWUBR5euCkJ(u"ࠨ࠴ࠪດ"),uhOkAKtLVv4XTy1nWE6(u"ࠩ࠶ࠫຕ"),ddK4MmwpX5oG(u"ࠪ࠸ࠬຖ"),DDS79jdWzLtE(u"ࠫ࠺࠭ທ")] and oKreBlqv3sAP1XaV:
			from pKTdzCL61S import Ty3qJ1wj7MIphX
			Ty3qJ1wj7MIphX(ja74FTtz9hK)
			fQ6kvwg1FrYAzXjbLT.setSetting(DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩຘ"),a4EuYDiRdrA)
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪນ"))
			return
		elif mnB6YkIKS4oZuMHOqT==iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧ࠷ࠩບ"):
			if oKreBlqv3sAP1XaV==xxpPYJOnoAUrlBzyveui(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪປ"): uFCykYQW68S(IJ6VkihabRm(u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩຜ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪຝ"))
			elif oKreBlqv3sAP1XaV==f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫࡉࡋࡌࡆࡖࡈࠫພ"): hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠹࠳࠵ᓿ")
			RRMWBwU6pG = GCkWI4SZaQbPlj(xEc7nR3qoAlv6C8YjD,CuiSrRzIOtfqKX2FPVoAcELM9gv70J,KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp,hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,j6UVYSdO2Qy134nlvK,HG0vEntrbRUK4ZTNx,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2)
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩຟ"))
			return
		elif ja74FTtz9hK==uhOkAKtLVv4XTy1nWE6(u"࠭࠷ࠨຠ"):
			from vcs7yZGKQM import Qz7ke2rZDJNlGjhn0fx9qOH
			Qz7ke2rZDJNlGjhn0fx9qOH()
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(GGTRaYBDeNyI25zlF(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫມ"))
			return
		elif ja74FTtz9hK==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨ࠺ࠪຢ"):
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(xxpPYJOnoAUrlBzyveui(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨຣ")+M0J6Pq3bH2+vkMRnTNV9jFm(u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ຤")+str(PBem6Hqsfgjvz)+dxAs4otSE98YmZnKy2iwRCB(u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫລ"))
			return
		elif ja74FTtz9hK==ZpH2IWt7veyFobTsAnhi41(u"ࠬ࠿ࠧ຦"):
			fQ6kvwg1FrYAzXjbLT.setSetting(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪວ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪຨ"))
			AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(ddK4MmwpX5oG(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬຩ"))
			return
	if fQ6kvwg1FrYAzXjbLT.getSetting(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨສ")) not in [q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡅ࡚࡚ࡏࠨຫ"),Vv0lSjAOHLfMnam3wtdor(u"ࠫࡘ࡚ࡏࡑࠩຬ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ອ")]:
		fQ6kvwg1FrYAzXjbLT.setSetting(fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬຮ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࡂࡗࡗࡓࠬຯ"))
	if not fQ6kvwg1FrYAzXjbLT.getSetting(xxpPYJOnoAUrlBzyveui(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨະ")): fQ6kvwg1FrYAzXjbLT.setSetting(xxpPYJOnoAUrlBzyveui(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩັ"),aaAosTOK3Uegui0dNBIqDEy[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠰ᔀ")])
	FAXinaw7gWQxRyo = fQ6kvwg1FrYAzXjbLT.getSetting(xxpPYJOnoAUrlBzyveui(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪາ"))
	FAXinaw7gWQxRyo = dxAs4otSE98YmZnKy2iwRCB(u"࠱ᔁ") if not FAXinaw7gWQxRyo else int(FAXinaw7gWQxRyo)
	if not FAXinaw7gWQxRyo or not ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠲ᔂ")<=Low1uSVG5OcafJmrYBC7D-FAXinaw7gWQxRyo<=t7rXIzJfMLWRwaDeKhTq4C6dG:
		PFwTfcL1r0eS3VqH9GmQkY2hx = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=gMmSViGyftbOI)
		PFwTfcL1r0eS3VqH9GmQkY2hx.start()
		fQ6kvwg1FrYAzXjbLT.setSetting(V391t7nQWUBR5euCkJ(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫຳ"),str(Low1uSVG5OcafJmrYBC7D))
	vbOPa78VAlnt0g361dIJ = fQ6kvwg1FrYAzXjbLT.getSetting(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩິ"))
	vbOPa78VAlnt0g361dIJ = DDS79jdWzLtE(u"࠳ᔃ") if not vbOPa78VAlnt0g361dIJ else int(vbOPa78VAlnt0g361dIJ)
	if not vbOPa78VAlnt0g361dIJ or not zOZvXaebGNwHKfjRA(u"࠴ᔄ")<=Low1uSVG5OcafJmrYBC7D-vbOPa78VAlnt0g361dIJ<=lu4xpkY5LFOm6t2In:
		import IFHE2MSfi5
		IFHE2MSfi5.QpwoVDjc2Kir4GtfEuyJkUzX5YsR(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡊࡦࡲࡳࡦᜃ"),ddK4MmwpX5oG(u"ࡗࡶࡺ࡫ᜂ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(xxBJoKG54uwQ(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪີ"),str(Low1uSVG5OcafJmrYBC7D))
	NZPhM1KyL4GDERacWB35FY8O = fQ6kvwg1FrYAzXjbLT.getSetting(V391t7nQWUBR5euCkJ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬຶ"))
	NFs5ZEujPW2hBG7vy = mmVNtesjMRgxqrAziOH(fQ6kvwg1FrYAzXjbLT.getSetting(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩື")))
	NFs5ZEujPW2hBG7vy = Vv0lSjAOHLfMnam3wtdor(u"࠵ᔅ") if not NFs5ZEujPW2hBG7vy else int(NFs5ZEujPW2hBG7vy)
	if NZPhM1KyL4GDERacWB35FY8O in [uhOkAKtLVv4XTy1nWE6(u"ຸࠩࠪ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡉࡗࡘࡏࡓູࠩ")] or not NFs5ZEujPW2hBG7vy or not qNZKwi2M1S4fBzGQYrmPnea(u"࠶ᔆ")<=Low1uSVG5OcafJmrYBC7D-NFs5ZEujPW2hBG7vy<=oXSZ6AEbPukBvwKmyarstdWR5qz0:
		vofQLAVmKBw0O4kpi52cetRz = gkL8loKHRfJyQCYNz0ESU(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࡋࡧ࡬ࡴࡧᜄ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࡋࡧ࡬ࡴࡧᜄ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(HMO0QciekqVpLKmA(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷ຺ࠬ"),AkEMLcQGwo0qnlB8VJeKiUTpX(Low1uSVG5OcafJmrYBC7D))
		if vofQLAVmKBw0O4kpi52cetRz:
			uFCykYQW68S(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬาัษ่ࠢีฮࠦรฯำ์ࠫົ"),xxBJoKG54uwQ(u"࠭ࡔࡳࡻࠣࡥ࡬ࡧࡩ࡯ࠩຼ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠱࠱࠲࠳ᔇ"))
			return
	ukdUoFQDPLtzSlAs9j = mmVNtesjMRgxqrAziOH(fQ6kvwg1FrYAzXjbLT.getSetting(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩຽ")))
	ukdUoFQDPLtzSlAs9j = fcIm8tvxlXZsaEY3bwuG4B(u"࠱ᔈ") if not ukdUoFQDPLtzSlAs9j else int(ukdUoFQDPLtzSlAs9j)
	jvGXDrBibgR9lCJQ7F = mmVNtesjMRgxqrAziOH(fQ6kvwg1FrYAzXjbLT.getSetting(KbL94nDHufSF0VcO2Nk3(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ຾")))
	jvGXDrBibgR9lCJQ7F = qNZKwi2M1S4fBzGQYrmPnea(u"࠲ᔉ") if not jvGXDrBibgR9lCJQ7F else int(jvGXDrBibgR9lCJQ7F)
	if not ukdUoFQDPLtzSlAs9j or not jvGXDrBibgR9lCJQ7F or not q0JfWbP8vACLxSNIncpOXkR6j(u"࠳ᔊ")<=Low1uSVG5OcafJmrYBC7D-jvGXDrBibgR9lCJQ7F<=ukdUoFQDPLtzSlAs9j:
		wH4tev2jPLDrQRKlYaMxn0NUzFdBhb = ZpH2IWt7veyFobTsAnhi41(u"࠵ᔋ")
		FprSL6W5AIzRXmoMjGTu2Ug1ys = ddK4MmwpX5oG(u"ࡆࡢ࡮ࡶࡩᜆ") if x9N7DKVT1rjsPmlieqQ8HJgU(ddK4MmwpX5oG(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪ຿")) else ddK4MmwpX5oG(u"࡚ࡲࡶࡧᜅ")
		if FprSL6W5AIzRXmoMjGTu2Ug1ys:
			IR6EdvxHspW9GrFlbymXq = L19zfOaM6iKrnFUjSxQJ5dN(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࡕࡴࡸࡩᜇ"))
			if len(IR6EdvxHspW9GrFlbymXq)>Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠶ᔌ"):
				zRM3tZx2v6DjJU(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪເ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠫ࠳ࠦࠠࡔࡪࡲࡻ࡮ࡴࡧࠡࡓࡸࡩࡸࡺࡩࡰࡰࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧແ")+a4EuYDiRdrA+L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࠦ࡝ࠨໂ"))
				ouHBbYIgr2,wn0kd1pEgfSy4YG,DupnWHq2SvjtxNh67sBQkLT5mJM3aP,Iga6ZWzdXDuoFO7NPjEf2AMxL8,Qg09MKEjzlUCJdt78D1x4ThbrP,rreason = IR6EdvxHspW9GrFlbymXq[OARzhnB9o7uYvQGFaIcZ(u"࠶ᔍ")]
				hNVxa2sHRn,ZSo5irGsQTwLa = Iga6ZWzdXDuoFO7NPjEf2AMxL8.split(DDS79jdWzLtE(u"࠭࡜࡯࠽࠾ࠫໃ"))
				del IR6EdvxHspW9GrFlbymXq[OARzhnB9o7uYvQGFaIcZ(u"࠰ᔎ")]
				ugAaNZztpbGeQI2Rm94k7S3s = KRjfaduUhzsPg6I1.sample(IR6EdvxHspW9GrFlbymXq,OARzhnB9o7uYvQGFaIcZ(u"࠲ᔏ"))
				ouHBbYIgr2,wn0kd1pEgfSy4YG,DupnWHq2SvjtxNh67sBQkLT5mJM3aP,Iga6ZWzdXDuoFO7NPjEf2AMxL8,Qg09MKEjzlUCJdt78D1x4ThbrP,rreason = ugAaNZztpbGeQI2Rm94k7S3s[p1lrNRIXqLQJznH6O(u"࠲ᔐ")]
				DupnWHq2SvjtxNh67sBQkLT5mJM3aP = xxpPYJOnoAUrlBzyveui(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠼ࠣࠫໄ")+ouHBbYIgr2+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ໅")+DupnWHq2SvjtxNh67sBQkLT5mJM3aP
				Qg09MKEjzlUCJdt78D1x4ThbrP = Vv0lSjAOHLfMnam3wtdor(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨໆ")
				n7gbTfNzlivJFG = xxpPYJOnoAUrlBzyveui(u"ࠪห้ะศา฻สฮࠬ໇")
				button0,button1 = Iga6ZWzdXDuoFO7NPjEf2AMxL8,Qg09MKEjzlUCJdt78D1x4ThbrP
				j4HYvVUoNl8iFS97QCz5JAEnZhpIs0 = [button0,button1,n7gbTfNzlivJFG]
				cWfQHtRy0qme = KbL94nDHufSF0VcO2Nk3(u"࠴ᔑ") if x9N7DKVT1rjsPmlieqQ8HJgU(DDS79jdWzLtE(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜່ࠬ")) else xxpPYJOnoAUrlBzyveui(u"࠵࠵ᔒ")
				FFwQqPEoCp = -ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠾ᔓ")
				while FFwQqPEoCp<lunVJF2G5bZMgTcCje0vaIB371SX(u"࠶ᔔ"):
					DUzXgM4adyJ3TKHchFE = KRjfaduUhzsPg6I1.sample(j4HYvVUoNl8iFS97QCz5JAEnZhpIs0,DKqQekNtF6WlJLhBP9M5ca(u"࠳ᔕ"))
					FFwQqPEoCp = GjZltWoCxuIwNfQ7EH9(vkMRnTNV9jFm(u"້ࠬ࠭"),DUzXgM4adyJ3TKHchFE[dxAs4otSE98YmZnKy2iwRCB(u"࠲ᔗ")],DUzXgM4adyJ3TKHchFE[KbL94nDHufSF0VcO2Nk3(u"࠲ᔖ")],DUzXgM4adyJ3TKHchFE[ZpH2IWt7veyFobTsAnhi41(u"࠵ᔘ")],hNVxa2sHRn,DupnWHq2SvjtxNh67sBQkLT5mJM3aP,zOZvXaebGNwHKfjRA(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ໊"),cWfQHtRy0qme,lunVJF2G5bZMgTcCje0vaIB371SX(u"࠺࠵ᔙ"))
					if FFwQqPEoCp==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠶࠶ᔚ"): break
					from IFHE2MSfi5 import z4tZrfkMm92x3FQEv5dw1s6OJiXu,zs1cdAxpVm6SNEhKFvOWyw
					if FFwQqPEoCp>=xxBJoKG54uwQ(u"࠰ᔜ") and DUzXgM4adyJ3TKHchFE[FFwQqPEoCp]==j4HYvVUoNl8iFS97QCz5JAEnZhpIs0[L91nVzxH4hYrgPDsOuljXd0J(u"࠷ᔛ")]:
						z4tZrfkMm92x3FQEv5dw1s6OJiXu()
						if FFwQqPEoCp>=iRTygNp4Lf36wQKlD2MHUhG7B(u"࠲ᔞ"): FFwQqPEoCp = -uhOkAKtLVv4XTy1nWE6(u"࠺ᔝ")
					elif FFwQqPEoCp>=d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠳ᔟ") and DUzXgM4adyJ3TKHchFE[FFwQqPEoCp]==j4HYvVUoNl8iFS97QCz5JAEnZhpIs0[uhOkAKtLVv4XTy1nWE6(u"࠶ᔠ")]:
						zs1cdAxpVm6SNEhKFvOWyw(V391t7nQWUBR5euCkJ(u"ࡈࡤࡰࡸ࡫ᜈ"))
					if FFwQqPEoCp==-L91nVzxH4hYrgPDsOuljXd0J(u"࠶ᔡ"): qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࠨ໋"),dxAs4otSE98YmZnKy2iwRCB(u"ࠨࠩ໌"),zOZvXaebGNwHKfjRA(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬໍ"),OARzhnB9o7uYvQGFaIcZ(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ໎"))
				wH4tev2jPLDrQRKlYaMxn0NUzFdBhb = xxpPYJOnoAUrlBzyveui(u"࠷ᔢ")
			else: wH4tev2jPLDrQRKlYaMxn0NUzFdBhb = ddK4MmwpX5oG(u"࠰ᔣ")
		mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,DDS79jdWzLtE(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ໏"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ໐"),wH4tev2jPLDrQRKlYaMxn0NUzFdBhb,VYn9o683LCcspE7Jew5gMQrZbj)
	RRMWBwU6pG = GCkWI4SZaQbPlj(xEc7nR3qoAlv6C8YjD,CuiSrRzIOtfqKX2FPVoAcELM9gv70J,KHeFaNZ7SULzAbTcojDw9fWmiJ1Rp,PBem6Hqsfgjvz,j6UVYSdO2Qy134nlvK,HG0vEntrbRUK4ZTNx,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2)
	if dxAs4otSE98YmZnKy2iwRCB(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ໑") in gq2FVNBUKPzIw1pZAnYHJG: eyVMOEac7fTNr3xg0ZwktiGJl = L91nVzxH4hYrgPDsOuljXd0J(u"ࡗࡶࡺ࡫ᜉ")
	if xEc7nR3qoAlv6C8YjD==ddK4MmwpX5oG(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໒"):
		if nZkScXxgspimo41H36h!=KbL94nDHufSF0VcO2Nk3(u"ࠨ࠰࠱ࠫ໓") and XHZ1GxfvDC4Mtz: DZP9fVUE7eCnTgQkiYy8RFGNraAKB()
		if EhfrVPICebQ>-fcIm8tvxlXZsaEY3bwuG4B(u"࠲ᔤ"):
			if (C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,Vv0lSjAOHLfMnam3wtdor(u"ࠩ࡬ࡲࡹ࠭໔"),V391t7nQWUBR5euCkJ(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭໕"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ໖")) or hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j not in A94UXIVglhTv) and not x9N7DKVT1rjsPmlieqQ8HJgU(GGTRaYBDeNyI25zlF(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭໗")):
				from nhi96mOBQf import XXAJlsZf2voNP8r
				PX0li7GsoDQUnuI2ZONybSd9hY = cFz8kLSvVWhX7Pqamu6jtb1n(XXAJlsZf2voNP8r)
				zmJjq3PXn06UMuvV7k = ttY9W3n7TpU(zzsnJpTkul,PX0li7GsoDQUnuI2ZONybSd9hY,BcMl3XdLS0zmK1jPvDJANfYH,eyVMOEac7fTNr3xg0ZwktiGJl,LnsZiRWqVNw2Ju)
				if ZpH2IWt7veyFobTsAnhi41(u"࠳ᔥ") and PX0li7GsoDQUnuI2ZONybSd9hY and HOf5JibCMpvjKLZtq9m1TSR8hz:
					mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,vkMRnTNV9jFm(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ໘")+okifblJcEvFe9AWunXBCHs72+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡠࠩ໙")+dzsUr8Z9yqMlTLSG,zzsnJpTkul,PX0li7GsoDQUnuI2ZONybSd9hY,t7rXIzJfMLWRwaDeKhTq4C6dG)
			else:
				LL2eGTPdkm.addDirectoryItem(EhfrVPICebQ,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ໚")+M0J6Pq3bH2+vkMRnTNV9jFm(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ໛"),yOuHBDmPps3vd24cnLagiK0.ListItem(qNZKwi2M1S4fBzGQYrmPnea(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩໜ")))
				LL2eGTPdkm.addDirectoryItem(EhfrVPICebQ,xxBJoKG54uwQ(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧໝ")+M0J6Pq3bH2+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬໞ"),yOuHBDmPps3vd24cnLagiK0.ListItem(tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬໟ")))
			LL2eGTPdkm.endOfDirectory(EhfrVPICebQ,BcMl3XdLS0zmK1jPvDJANfYH,eyVMOEac7fTNr3xg0ZwktiGJl,LnsZiRWqVNw2Ju)
	return
def GCkWI4SZaQbPlj(xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2):
	hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j = int(PBem6Hqsfgjvz)
	MQrIDuiRAGExksvoLC9Onmgb = int(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j//p1lrNRIXqLQJznH6O(u"࠴࠴ᔦ"))
	if   MQrIDuiRAGExksvoLC9Onmgb==uhOkAKtLVv4XTy1nWE6(u"࠴ᔧ"):  from IFHE2MSfi5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==KbL94nDHufSF0VcO2Nk3(u"࠶ᔨ"):  from nCIOoXFS1A 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠸ᔩ"):  from y8PYivouwU 			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==GGTRaYBDeNyI25zlF(u"࠳ᔪ"):  from k8vP7K6OlS 			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DDS79jdWzLtE(u"࠵ᔫ"):  from jOXEQYC1T7 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,YSTbrKgPf7NyhIDizB)
	elif MQrIDuiRAGExksvoLC9Onmgb==p1lrNRIXqLQJznH6O(u"࠷ᔬ"):  from hdIpkHazRx 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==L91nVzxH4hYrgPDsOuljXd0J(u"࠹ᔭ"):  from Jz2TdkVr9i 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==zOZvXaebGNwHKfjRA(u"࠻ᔮ"):  from OjZmrI0DKb 			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠽ᔯ"):  from ksA2HucdFh 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==uhOkAKtLVv4XTy1nWE6(u"࠿ᔰ"):  from HHrKwoj5pc		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==ddK4MmwpX5oG(u"࠱࠱ᔱ"): from LbrlkD8oPw 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95)
	elif MQrIDuiRAGExksvoLC9Onmgb==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠲࠳ᔲ"): from f862dET1BF 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠳࠵ᔳ"): from iiRDUdxsca 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==KbL94nDHufSF0VcO2Nk3(u"࠴࠷ᔴ"): from RtkbPs9yKS		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==HMO0QciekqVpLKmA(u"࠵࠹ᔵ"): from DGetBjzwkV 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB,QEMyY8a9IoOcFqeuKztCVWmT7jXv,KKcFOCmYRENepQnxi)
	elif MQrIDuiRAGExksvoLC9Onmgb==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠶࠻ᔶ"): from IFHE2MSfi5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==L91nVzxH4hYrgPDsOuljXd0J(u"࠷࠶ᔷ"): from N5dvGY0pWJ		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2)
	elif MQrIDuiRAGExksvoLC9Onmgb==V391t7nQWUBR5euCkJ(u"࠱࠸ᔸ"): from IFHE2MSfi5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==f8PVRTseIuj9BckO6GoyF5Lxv(u"࠲࠺ᔹ"): from SHT2AP0WbL		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==vkMRnTNV9jFm(u"࠳࠼ᔺ"): from IFHE2MSfi5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠵࠴ᔻ"): from nnPi78q5GO		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==q0JfWbP8vACLxSNIncpOXkR6j(u"࠶࠶ᔼ"): from TzRiNDxkrd	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==vkMRnTNV9jFm(u"࠷࠸ᔽ"): from Hxo2a86umk		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==v7reLlOXCgD5pZ14w2tUA(u"࠸࠳ᔾ"): from Fh0QwtApKa	import M8xBdHmhrtyWIoL1e6VNvk	; RRMWBwU6pG = M8xBdHmhrtyWIoL1e6VNvk(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2)
	elif MQrIDuiRAGExksvoLC9Onmgb==zOZvXaebGNwHKfjRA(u"࠲࠵ᔿ"): from ETaRVFoBXD 			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠳࠷ᕀ"): from CbnORTUHL5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==V391t7nQWUBR5euCkJ(u"࠴࠹ᕁ"): from nhi96mOBQf 			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==f8PVRTseIuj9BckO6GoyF5Lxv(u"࠵࠻ᕂ"): from pKTdzCL61S	import M8xBdHmhrtyWIoL1e6VNvk	; RRMWBwU6pG = M8xBdHmhrtyWIoL1e6VNvk(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,ja74FTtz9hK)
	elif MQrIDuiRAGExksvoLC9Onmgb==Vv0lSjAOHLfMnam3wtdor(u"࠶࠽ᕃ"): from Fh0QwtApKa	import M8xBdHmhrtyWIoL1e6VNvk	; RRMWBwU6pG = M8xBdHmhrtyWIoL1e6VNvk(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2)
	elif MQrIDuiRAGExksvoLC9Onmgb==q0JfWbP8vACLxSNIncpOXkR6j(u"࠷࠿ᕄ"): from LbPKDg3wS6	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠹࠰ᕅ"): from wJbtYB85UM		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==HMO0QciekqVpLKmA(u"࠳࠲ᕆ"): from qkPlF3hXrB		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==OARzhnB9o7uYvQGFaIcZ(u"࠴࠴ᕇ"): from jj1WteBzhQ		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==qNZKwi2M1S4fBzGQYrmPnea(u"࠵࠶ᕈ"): from tHQRiskDv2		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95)
	elif MQrIDuiRAGExksvoLC9Onmgb==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶࠸ᕉ"): from IFHE2MSfi5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠷࠺ᕊ"): from yeoi8n2Xb1		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==lunVJF2G5bZMgTcCje0vaIB371SX(u"࠸࠼ᕋ"): from vbokuZrzD6			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==xxpPYJOnoAUrlBzyveui(u"࠹࠷ᕌ"): from LRMCkhDVuY			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==p1lrNRIXqLQJznH6O(u"࠳࠹ᕍ"): from BM6R2vOGT9 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==xxBJoKG54uwQ(u"࠴࠻ᕎ"): from p0aBKYXZUh		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==Vv0lSjAOHLfMnam3wtdor(u"࠶࠳ᕏ"): from Ye6gQpcIJL	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB)
	elif MQrIDuiRAGExksvoLC9Onmgb==L91nVzxH4hYrgPDsOuljXd0J(u"࠷࠵ᕐ"): from Ye6gQpcIJL	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB)
	elif MQrIDuiRAGExksvoLC9Onmgb==p1lrNRIXqLQJznH6O(u"࠸࠷ᕑ"): from kuNtEaWXm6			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==ZpH2IWt7veyFobTsAnhi41(u"࠹࠹ᕒ"): from gTS1D3NfJz			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==HMO0QciekqVpLKmA(u"࠺࠴ᕓ"): from uFrycA7jOJ		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠴࠶ᕔ"): from N7ORfApWM4		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==L91nVzxH4hYrgPDsOuljXd0J(u"࠵࠸ᕕ"): from DFkGWuYhdb			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶࠺ᕖ"): from PeR0asuyA2		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==xxpPYJOnoAUrlBzyveui(u"࠷࠼ᕗ"): from JE3trXDa7N		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠸࠾ᕘ"): from oAOYptLgIS		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==xxBJoKG54uwQ(u"࠺࠶ᕙ"): from IFHE2MSfi5 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==L91nVzxH4hYrgPDsOuljXd0J(u"࠻࠱ᕚ"): from eezhL6rBtn 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠵࠳ᕛ"): from eezhL6rBtn 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==uhOkAKtLVv4XTy1nWE6(u"࠶࠵ᕜ"): from nhi96mOBQf 			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠷࠷ᕝ"): from vcs7yZGKQM	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,YSTbrKgPf7NyhIDizB)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠸࠹ᕞ"): from tBRqDYfagz 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==xxpPYJOnoAUrlBzyveui(u"࠹࠻ᕟ"): from F4b2neDjfi			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠺࠽ᕠ"): from ppGhAdLXIP		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠻࠸ᕡ"): from kdQ7U8EY5L		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵࠺ᕢ"): from YvuiySjmd9		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==ddK4MmwpX5oG(u"࠷࠲ᕣ"): from xx35gBdP1Y			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠸࠴ᕤ"): from rzEFQokM8A			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠹࠶ᕥ"): from XXVYTUMI40		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==uhOkAKtLVv4XTy1nWE6(u"࠺࠸ᕦ"): from NHJ8MUiSxZ	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==ZpH2IWt7veyFobTsAnhi41(u"࠻࠺ᕧ"): from qRtFebZi1J			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==OARzhnB9o7uYvQGFaIcZ(u"࠼࠵ᕨ"): from pUz3CwB5hP			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==L91nVzxH4hYrgPDsOuljXd0J(u"࠶࠷ᕩ"): from NqbsyBwugI			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠷࠹ᕪ"): from pDuINVgCYf		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠸࠻ᕫ"): from dV94ow7KIx		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠹࠽ᕬ"): from D8K7V39IUc		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==KbL94nDHufSF0VcO2Nk3(u"࠻࠵ᕭ"): from ssotCShO9a			import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==DKqQekNtF6WlJLhBP9M5ca(u"࠼࠷ᕮ"): from RWoJSlvIC0	import M8xBdHmhrtyWIoL1e6VNvk	; RRMWBwU6pG = M8xBdHmhrtyWIoL1e6VNvk(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2)
	elif MQrIDuiRAGExksvoLC9Onmgb==GGTRaYBDeNyI25zlF(u"࠽࠲ᕯ"): from RWoJSlvIC0	import M8xBdHmhrtyWIoL1e6VNvk	; RRMWBwU6pG = M8xBdHmhrtyWIoL1e6VNvk(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,xEc7nR3qoAlv6C8YjD,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2)
	elif MQrIDuiRAGExksvoLC9Onmgb==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠷࠴ᕰ"): from AANZ3fvsJM	import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==GGTRaYBDeNyI25zlF(u"࠸࠶ᕱ"): from HZvahc0Qpx		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j)
	elif MQrIDuiRAGExksvoLC9Onmgb==qNZKwi2M1S4fBzGQYrmPnea(u"࠹࠸ᕲ"): from HZvahc0Qpx		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j)
	elif MQrIDuiRAGExksvoLC9Onmgb==p1lrNRIXqLQJznH6O(u"࠺࠺ᕳ"): from N5dvGY0pWJ		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG,YSTbrKgPf7NyhIDizB,RkfstxEyua67K2)
	elif MQrIDuiRAGExksvoLC9Onmgb==fcIm8tvxlXZsaEY3bwuG4B(u"࠻࠼ᕴ"): from VPK7iuwqrt 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==OARzhnB9o7uYvQGFaIcZ(u"࠼࠾ᕵ"): from k2pMg0U8ml 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠽࠹ᕶ"): from EVXS46FUM7 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠸࠱ᕷ"): from QOEaAPsFBw 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==KbL94nDHufSF0VcO2Nk3(u"࠹࠳ᕸ"): from uuXO2oJlpQ 		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,gq2FVNBUKPzIw1pZAnYHJG)
	elif MQrIDuiRAGExksvoLC9Onmgb==xxBJoKG54uwQ(u"࠺࠵ᕹ"): from Vo1bUqIvAi		import hLD0mk9HIuPOz7pw	; RRMWBwU6pG = hLD0mk9HIuPOz7pw(hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j,DDRulV7aKN3jCOWSBQkb95,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG)
	else: RRMWBwU6pG = None
	return RRMWBwU6pG
def t0ihfB5qMGW6(TIvkgj7OxW6Vzb35il,rreason,oBQqw316KAIpOdr7R0LxkZNW5lG4y,showDialogs):
	EEtGsIqDNX = fQ6kvwg1FrYAzXjbLT.getSetting(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ໠"))
	fQ6kvwg1FrYAzXjbLT.setSetting(fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ໡"),ddK4MmwpX5oG(u"ࠩࠪ໢"))
	if GGTRaYBDeNyI25zlF(u"ࠪ࠱ࠬ໣") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: Xt7olBPDuFS4diy1 = oBQqw316KAIpOdr7R0LxkZNW5lG4y.split(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫ࠲࠭໤"),fcIm8tvxlXZsaEY3bwuG4B(u"࠴ᕺ"))[f8PVRTseIuj9BckO6GoyF5Lxv(u"࠴ᕻ")]
	else: Xt7olBPDuFS4diy1 = oBQqw316KAIpOdr7R0LxkZNW5lG4y
	vvP3LlXZ4DEeM15UyOFHdqR7wfSh = TIvkgj7OxW6Vzb35il in [L91nVzxH4hYrgPDsOuljXd0J(u"࠸ᕿ"),vkMRnTNV9jFm(u"࠷࠱࠱࠲࠴ᕽ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠶࠷࠰࠱࠴ᕼ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠱࠱࠲࠸࠸ᕾ")]
	uuoB2vGm6blU = rreason.lower()
	iiDHmjsc37JfNB2nRuCWZ1OeM = TIvkgj7OxW6Vzb35il in [uhOkAKtLVv4XTy1nWE6(u"࠲ᖀ"),DKqQekNtF6WlJLhBP9M5ca(u"࠶࠶࠴ᖃ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠴࠴࠵࠼࠱ᖁ"),V391t7nQWUBR5euCkJ(u"࠵࠶࠷ᖂ")]
	hkjGa1y93izB6JDvueNs = xxpPYJOnoAUrlBzyveui(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭໥") in uuoB2vGm6blU
	erRHP9bCs6QwlAvUoVgcJuT = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭໦") in uuoB2vGm6blU
	T2PHcA8RQyFxuzYqkV7 = IJ6VkihabRm(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ໧") in uuoB2vGm6blU
	cv2iVbBH08kIFz3y = KbL94nDHufSF0VcO2Nk3(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ໨") in uuoB2vGm6blU
	PlsMeTIwxmcAO = fQ6kvwg1FrYAzXjbLT.getSetting(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ໩"))
	FDKOt1Gm0LYR = fQ6kvwg1FrYAzXjbLT.getSetting(KbL94nDHufSF0VcO2Nk3(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭໪"))
	m2FvkHZeUxpYM3BTw1LnAuKcXGW9 = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭໫")
	SIbYKwjhWx8JQf6v1iAkXcu3ser04 = fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡋࡲࡳࡱࡵࠤࠬ໬")+str(TIvkgj7OxW6Vzb35il)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭࠺ࠡࠩ໭")+rreason
	SIbYKwjhWx8JQf6v1iAkXcu3ser04 = NdVvO42riJpCWElX(SIbYKwjhWx8JQf6v1iAkXcu3ser04)
	if iiDHmjsc37JfNB2nRuCWZ1OeM or hkjGa1y93izB6JDvueNs or erRHP9bCs6QwlAvUoVgcJuT or T2PHcA8RQyFxuzYqkV7 or cv2iVbBH08kIFz3y:
		m2FvkHZeUxpYM3BTw1LnAuKcXGW9 += v7reLlOXCgD5pZ14w2tUA(u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧ໮")
	if vvP3LlXZ4DEeM15UyOFHdqR7wfSh: m2FvkHZeUxpYM3BTw1LnAuKcXGW9 += f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨ໯")
	SIbYKwjhWx8JQf6v1iAkXcu3ser04 = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ໰")+SIbYKwjhWx8JQf6v1iAkXcu3ser04+OARzhnB9o7uYvQGFaIcZ(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ໱")
	if PlsMeTIwxmcAO==dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡆ࡙ࡋࠨ໲") or FDKOt1Gm0LYR==lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡇࡓࡌࠩ໳"):
		m2FvkHZeUxpYM3BTw1LnAuKcXGW9 += KbL94nDHufSF0VcO2Nk3(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋้ࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡมࠤࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭໴")
	m1mNjq3Hfw2OKp56oaFEXQGxkCsu = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࡊࡦࡲࡳࡦᜊ")
	if showDialogs and oBQqw316KAIpOdr7R0LxkZNW5lG4y not in jtJRLy3balg2pFK:
		if PlsMeTIwxmcAO==V391t7nQWUBR5euCkJ(u"ࠧࡂࡕࡎࠫ໵") or FDKOt1Gm0LYR==iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡃࡖࡏࠬ໶"):
			FFwQqPEoCp = GjZltWoCxuIwNfQ7EH9(vkMRnTNV9jFm(u"ࠩࡦࡩࡳࡺࡥࡳࠩ໷"),dxAs4otSE98YmZnKy2iwRCB(u"ࠪาึ๎ฬࠨ໸"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ໹"),IJ6VkihabRm(u"ࠬหีๅษะࠤฬ๊ๅีๅ็อࠬ໺"),Xt7olBPDuFS4diy1+OARzhnB9o7uYvQGFaIcZ(u"࠭ࠠࠡࠢࠪ໻")+S6YzAlHWcCwJI18(Xt7olBPDuFS4diy1),m2FvkHZeUxpYM3BTw1LnAuKcXGW9+V391t7nQWUBR5euCkJ(u"ࠧ࡝ࡰࠪ໼")+SIbYKwjhWx8JQf6v1iAkXcu3ser04)
			if FFwQqPEoCp==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠷ᖄ"):
				from IFHE2MSfi5 import z4tZrfkMm92x3FQEv5dw1s6OJiXu
				z4tZrfkMm92x3FQEv5dw1s6OJiXu()
			elif FFwQqPEoCp==p1lrNRIXqLQJznH6O(u"࠲ᖅ"): m1mNjq3Hfw2OKp56oaFEXQGxkCsu = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡙ࡸࡵࡦᜋ")
		else: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(KbL94nDHufSF0VcO2Nk3(u"ࠨࠩ໽"),dxAs4otSE98YmZnKy2iwRCB(u"ࠩࠪ໾"),Xt7olBPDuFS4diy1+KbL94nDHufSF0VcO2Nk3(u"ࠪࠤࠥࠦࠧ໿")+S6YzAlHWcCwJI18(Xt7olBPDuFS4diy1),m2FvkHZeUxpYM3BTw1LnAuKcXGW9,SIbYKwjhWx8JQf6v1iAkXcu3ser04)
	fQ6kvwg1FrYAzXjbLT.setSetting(L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬༀ"),EEtGsIqDNX)
	return m1mNjq3Hfw2OKp56oaFEXQGxkCsu
def zKUEjGW1YecZHiyoPRal4LMQrvsX(mH1P9fiNsd7q4gb3DIvZ=xxpPYJOnoAUrlBzyveui(u"ࡌࡡ࡭ࡵࡨᜌ"),eu5l30ptkni7yz1IhCMrFTYK=[]):
	RthANWHZKfqOVp0 = [PPgJ3en0yKYWdzMAmCON1DTQG9,KmlAH1VJObEkfZS3ToazF8qNP70t]+eu5l30ptkni7yz1IhCMrFTYK
	for l0uAW3wIvSC in YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(vBXJAQCwEpS0xZ6km9a):
		if mH1P9fiNsd7q4gb3DIvZ and (l0uAW3wIvSC.startswith(vkMRnTNV9jFm(u"ࠬ࡯ࡰࡵࡸࠪ༁")) or l0uAW3wIvSC.startswith(zOZvXaebGNwHKfjRA(u"࠭࡭࠴ࡷࠪ༂"))): continue
		if l0uAW3wIvSC.startswith(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡧ࡫࡯ࡩࡤ࠭༃")): continue
		hNAYgBdKtOEQMkri2WszbG7LjCef = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,l0uAW3wIvSC)
		if hNAYgBdKtOEQMkri2WszbG7LjCef in RthANWHZKfqOVp0: continue
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(hNAYgBdKtOEQMkri2WszbG7LjCef)
		except: pass
	if E5bapZAYUTcnFCmuPGztDrfMq not in RthANWHZKfqOVp0: Qzbnt3opXim(E5bapZAYUTcnFCmuPGztDrfMq,fcIm8tvxlXZsaEY3bwuG4B(u"ࡕࡴࡸࡩᜎ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࡆࡢ࡮ࡶࡩᜍ"))
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠲ᖆ"))
	return
def TGFahVMcpBPsO(Y2a1H5gKbpjW0DhMuvdUF3fVLI7,bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y,ELYSOBmvzgoX2u53=ZpH2IWt7veyFobTsAnhi41(u"ࡖࡵࡹࡪᜏ"),adHF267eXilBUAPhgjSL0R3=ZpH2IWt7veyFobTsAnhi41(u"ࡖࡵࡹࡪᜏ")):
	DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95+OARzhnB9o7uYvQGFaIcZ(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ༄")+Y2a1H5gKbpjW0DhMuvdUF3fVLI7
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y,ELYSOBmvzgoX2u53,adHF267eXilBUAPhgjSL0R3)
	if DDRulV7aKN3jCOWSBQkb95 in djr0g3VkMzo1ehxE.content: djr0g3VkMzo1ehxE.succeeded = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡉࡥࡱࡹࡥᜐ")
	if not djr0g3VkMzo1ehxE.succeeded:
		RYNAu9Eo7mgOi0sG1j(qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡋࡘ࡙ࡖࠠࡓࡧࡴࡹࡪࡹࡴࠡࡈࡤ࡭ࡱࡻࡲࡦࠩ༅"))
	return djr0g3VkMzo1ehxE
def aCI305zTbwLAJWKmS1ofdjqnsx(DDRulV7aKN3jCOWSBQkb95):
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡋࡊ࡚ࠧ༆"),DDRulV7aKN3jCOWSBQkb95,V391t7nQWUBR5euCkJ(u"ࠫࠬ༇"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠭༈"),GGTRaYBDeNyI25zlF(u"࡙ࡸࡵࡦᜒ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠧ༉"),ZpH2IWt7veyFobTsAnhi41(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨ༊"),GGTRaYBDeNyI25zlF(u"࡙ࡸࡵࡦᜒ"),dxAs4otSE98YmZnKy2iwRCB(u"ࡊࡦࡲࡳࡦᜑ"))
	LanyhKEAXuvgUJd4GHlemQO9Cj = []
	if djr0g3VkMzo1ehxE.succeeded:
		RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
		XtIm3Ciry4hkPjZFleB6 = QPuHKNAT4jmCRg.findall(OARzhnB9o7uYvQGFaIcZ(u"ࠨࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡧࡿ࠶࠲࠳ࡾ࡯ࡶࠫ་"),RkLE6BzZ2KX)
		if XtIm3Ciry4hkPjZFleB6: RkLE6BzZ2KX = ZpH2IWt7veyFobTsAnhi41(u"ࠩ࡟ࡲࠬ༌").join(XtIm3Ciry4hkPjZFleB6)
		SiugcTfJZkP8KIrmxACOweoN3HQ5lR = RkLE6BzZ2KX.replace(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡠࡷ࠭།"),vkMRnTNV9jFm(u"ࠫࠬ༎")).strip(Vv0lSjAOHLfMnam3wtdor(u"ࠬࡢ࡮ࠨ༏")).split(L91nVzxH4hYrgPDsOuljXd0J(u"࠭࡜࡯ࠩ༐"))
		LanyhKEAXuvgUJd4GHlemQO9Cj = []
		for Y2a1H5gKbpjW0DhMuvdUF3fVLI7 in SiugcTfJZkP8KIrmxACOweoN3HQ5lR:
			if Y2a1H5gKbpjW0DhMuvdUF3fVLI7.count(L91nVzxH4hYrgPDsOuljXd0J(u"ࠧ࠯ࠩ༑"))==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠵ᖇ"): LanyhKEAXuvgUJd4GHlemQO9Cj.append(Y2a1H5gKbpjW0DhMuvdUF3fVLI7)
	return LanyhKEAXuvgUJd4GHlemQO9Cj
def CCkRfcY4W6IrBEOiFsNhZ7Tw31P8lM(*aargs):
	yBIdDRAbxplsvr9iemkJw1HF = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ༒")
	ZNuXcJf7RqyCI6vhmonPsQOzL = p1lrNRIXqLQJznH6O(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭༓")
	T7rL1Fhyq5KVYSagbOJokXd860s = aCI305zTbwLAJWKmS1ofdjqnsx(ZNuXcJf7RqyCI6vhmonPsQOzL)
	LanyhKEAXuvgUJd4GHlemQO9Cj = aCI305zTbwLAJWKmS1ofdjqnsx(yBIdDRAbxplsvr9iemkJw1HF)
	JUBzFalQoRXvLkt = T7rL1Fhyq5KVYSagbOJokXd860s+LanyhKEAXuvgUJd4GHlemQO9Cj
	zRM3tZx2v6DjJU(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ༔"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ༕")+str(len(T7rL1Fhyq5KVYSagbOJokXd860s))+vkMRnTNV9jFm(u"ࠬ࠱ࠧ༖")+str(len(LanyhKEAXuvgUJd4GHlemQO9Cj))+GGTRaYBDeNyI25zlF(u"࠭ࠠ࡞ࠩ༗"))
	Y2a1H5gKbpjW0DhMuvdUF3fVLI7 = fQ6kvwg1FrYAzXjbLT.getSetting(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺ༘ࠧ"))
	djr0g3VkMzo1ehxE = HcLv5k0Ey9FG()
	fQ6kvwg1FrYAzXjbLT.setSetting(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ༙"),p1lrNRIXqLQJznH6O(u"ࠩࠪ༚"))
	if Y2a1H5gKbpjW0DhMuvdUF3fVLI7 or JUBzFalQoRXvLkt:
		ouHBbYIgr2,GUSviMX7rNBgwVdbtf8p3ZEhaR0 = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠳ᖈ"),OARzhnB9o7uYvQGFaIcZ(u"࠵࠵ᖉ")
		s6bHuh1Pcf = len(JUBzFalQoRXvLkt)
		K4FCbjG7uIwMf9P6XtD = GUSviMX7rNBgwVdbtf8p3ZEhaR0
		if s6bHuh1Pcf>K4FCbjG7uIwMf9P6XtD: hH0op2C7T4lq = K4FCbjG7uIwMf9P6XtD
		else: hH0op2C7T4lq = s6bHuh1Pcf
		xxhqvDegLyi = KRjfaduUhzsPg6I1.sample(JUBzFalQoRXvLkt,hH0op2C7T4lq)
		if Y2a1H5gKbpjW0DhMuvdUF3fVLI7: xxhqvDegLyi = [Y2a1H5gKbpjW0DhMuvdUF3fVLI7]+xxhqvDegLyi
		Pw5npBg0rxjQ1L3zoaFYNlRWsDvtIk = kZ05eRcAtxbP1ID(ddK4MmwpX5oG(u"ࡌࡡ࡭ࡵࡨᜓ"),ddK4MmwpX5oG(u"ࡌࡡ࡭ࡵࡨᜓ"))
		g27TaovWhPEzbHsY39Bw = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
		while vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()-g27TaovWhPEzbHsY39Bw<=GUSviMX7rNBgwVdbtf8p3ZEhaR0 and not Pw5npBg0rxjQ1L3zoaFYNlRWsDvtIk.finishedLIST:
			if ouHBbYIgr2<hH0op2C7T4lq:
				Y2a1H5gKbpjW0DhMuvdUF3fVLI7 = xxhqvDegLyi[ouHBbYIgr2]
				Pw5npBg0rxjQ1L3zoaFYNlRWsDvtIk.yP9H5KOS6TYglVdxurU(ouHBbYIgr2,TGFahVMcpBPsO,Y2a1H5gKbpjW0DhMuvdUF3fVLI7,*aargs)
			vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(GGTRaYBDeNyI25zlF(u"࠶ᖊ"))
			ouHBbYIgr2 += ddK4MmwpX5oG(u"࠷ᖋ")
			zRM3tZx2v6DjJU(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ༛"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+vkMRnTNV9jFm(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༜")+Y2a1H5gKbpjW0DhMuvdUF3fVLI7+Vv0lSjAOHLfMnam3wtdor(u"ࠬࠦ࡝ࠨ༝"))
		finishedLIST = Pw5npBg0rxjQ1L3zoaFYNlRWsDvtIk.finishedLIST
		if finishedLIST:
			resultsDICT = Pw5npBg0rxjQ1L3zoaFYNlRWsDvtIk.resultsDICT
			MTh64JFw8XtdcUkjrnPqmAD = finishedLIST[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠰ᖌ")]
			djr0g3VkMzo1ehxE = resultsDICT[MTh64JFw8XtdcUkjrnPqmAD]
			Y2a1H5gKbpjW0DhMuvdUF3fVLI7 = xxhqvDegLyi[int(MTh64JFw8XtdcUkjrnPqmAD)]
			fQ6kvwg1FrYAzXjbLT.setSetting(xxpPYJOnoAUrlBzyveui(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭༞"),Y2a1H5gKbpjW0DhMuvdUF3fVLI7)
			if MTh64JFw8XtdcUkjrnPqmAD!=HMO0QciekqVpLKmA(u"࠱ᖍ"): zRM3tZx2v6DjJU(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭༟"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ༠")+Y2a1H5gKbpjW0DhMuvdUF3fVLI7+OARzhnB9o7uYvQGFaIcZ(u"ࠩࠣࡡࠬ༡"))
			else: zRM3tZx2v6DjJU(uhOkAKtLVv4XTy1nWE6(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ༢"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+OARzhnB9o7uYvQGFaIcZ(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭༣")+Y2a1H5gKbpjW0DhMuvdUF3fVLI7+ddK4MmwpX5oG(u"ࠬࠦ࡝ࠨ༤"))
	return djr0g3VkMzo1ehxE
def hpjE68oSiwr0LBCU(V46HmwyZFCk01plbaKd7QYhcr,SAxhNOBlQazEiXKFbIk2yZ7qRTY905):
	sNl76zMfepb3n = V46HmwyZFCk01plbaKd7QYhcr.create_connection
	def Dy8EbS1KBks7hIjTOn2(O5s3w6SjabRCG,*aargs,**kkwargs):
		zfSh8JxwD9AFiG2e5l,rracq9NlRupJh30ZixLbYVKTEGP6 = O5s3w6SjabRCG
		ip = oGtm30nXy6kYH9JRAhBDsvuO(zfSh8JxwD9AFiG2e5l,SAxhNOBlQazEiXKFbIk2yZ7qRTY905)
		if ip: zfSh8JxwD9AFiG2e5l = ip[V391t7nQWUBR5euCkJ(u"࠲ᖎ")]
		else:
			if SAxhNOBlQazEiXKFbIk2yZ7qRTY905 in aaAosTOK3Uegui0dNBIqDEy: aaAosTOK3Uegui0dNBIqDEy.remove(SAxhNOBlQazEiXKFbIk2yZ7qRTY905)
			if aaAosTOK3Uegui0dNBIqDEy:
				bAB0mERTj9sSZPGdq = aaAosTOK3Uegui0dNBIqDEy[KbL94nDHufSF0VcO2Nk3(u"࠳ᖏ")]
				ip = oGtm30nXy6kYH9JRAhBDsvuO(zfSh8JxwD9AFiG2e5l,bAB0mERTj9sSZPGdq)
				if ip: zfSh8JxwD9AFiG2e5l = ip[q0JfWbP8vACLxSNIncpOXkR6j(u"࠴ᖐ")]
		O5s3w6SjabRCG = (zfSh8JxwD9AFiG2e5l,rracq9NlRupJh30ZixLbYVKTEGP6)
		return sNl76zMfepb3n(O5s3w6SjabRCG,*aargs,**kkwargs)
	V46HmwyZFCk01plbaKd7QYhcr.create_connection = Dy8EbS1KBks7hIjTOn2
	return sNl76zMfepb3n
def xxdSlUpZMX1NEgv8DnBbhO(DDRulV7aKN3jCOWSBQkb95):
	HvaVQAwjrsLhfkn0PO,lJox9cjkF0aDemMsCE84 = DDRulV7aKN3jCOWSBQkb95.split(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭࠯ࠨ༥"))[qNZKwi2M1S4fBzGQYrmPnea(u"࠸ᖒ")],gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠽࠶ᖑ")
	if xxBJoKG54uwQ(u"ࠧ࠻ࠩ༦") in HvaVQAwjrsLhfkn0PO: HvaVQAwjrsLhfkn0PO,lJox9cjkF0aDemMsCE84 = HvaVQAwjrsLhfkn0PO.split(p1lrNRIXqLQJznH6O(u"ࠨ࠼ࠪ༧"))
	lx1vPyNXA4eGjpTf2059kbU6CuHJI = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩ࠲ࠫ༨")+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࠳ࠬ༩").join(DDRulV7aKN3jCOWSBQkb95.split(xxpPYJOnoAUrlBzyveui(u"ࠫ࠴࠭༪"))[L91nVzxH4hYrgPDsOuljXd0J(u"࠳ᖓ"):])
	lp3eGht9uF4mMCR6YIWz = Vv0lSjAOHLfMnam3wtdor(u"ࠬࡍࡅࡕࠢࠪ༫")+lx1vPyNXA4eGjpTf2059kbU6CuHJI+L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭༬")
	lp3eGht9uF4mMCR6YIWz += Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡉࡱࡶࡸ࠿ࠦࠧ༭")+HvaVQAwjrsLhfkn0PO+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨ࡞ࡵࡠࡳ࠭༮")
	lp3eGht9uF4mMCR6YIWz += a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩ࡟ࡶࡡࡴࠧ༯")
	from socket import socket as HKIPWB4JXYaEu6,AF_INET as LFgRCWvkM8hAD,SOCK_STREAM as KlXvBMj7oFRhLxW3OpCI2s
	try:
		JlTYEGXnOH3u = HKIPWB4JXYaEu6(LFgRCWvkM8hAD,KlXvBMj7oFRhLxW3OpCI2s)
		JlTYEGXnOH3u.connect((HvaVQAwjrsLhfkn0PO,lJox9cjkF0aDemMsCE84))
		JlTYEGXnOH3u.send(lp3eGht9uF4mMCR6YIWz.encode(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡹࡹ࡬࠸ࠨ༰")))
		ii5q4bEewGzm3r70NlTWA2oKg9sPp = JlTYEGXnOH3u.recv(vkMRnTNV9jFm(u"࠶࠳࠽࠻ᖕ")*iRTygNp4Lf36wQKlD2MHUhG7B(u"࠲࠲࠵࠸ᖔ"))
		RkLE6BzZ2KX = repr(ii5q4bEewGzm3r70NlTWA2oKg9sPp)
	except: RkLE6BzZ2KX = fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࠬ༱")
	return RkLE6BzZ2KX
def znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(SSXgFdnlqLO8y4Rkiu,xEc7nR3qoAlv6C8YjD):
	if Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬ࠴ࠧ༲") not in SSXgFdnlqLO8y4Rkiu: return SSXgFdnlqLO8y4Rkiu
	SSXgFdnlqLO8y4Rkiu = SSXgFdnlqLO8y4Rkiu+GGTRaYBDeNyI25zlF(u"࠭࠯ࠨ༳")
	o2ohRQlzZAeHaTt3,lMhRv6FarcutGm = SSXgFdnlqLO8y4Rkiu.split(ddK4MmwpX5oG(u"ࠧ࠯ࠩ༴"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠴ᖖ"))
	jleT5zbO8SNMRgY1QJ7GkfyKdAn,DBCS7LxlV5tH = lMhRv6FarcutGm.split(ZpH2IWt7veyFobTsAnhi41(u"ࠨ࠱༵ࠪ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠵ᖗ"))
	ympS917x6nz = o2ohRQlzZAeHaTt3+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩ࠱ࠫ༶")+jleT5zbO8SNMRgY1QJ7GkfyKdAn
	if xEc7nR3qoAlv6C8YjD in [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪ࡬ࡴࡹࡴࠨ༷"),dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡳࡧ࡭ࡦࠩ༸")] and IJ6VkihabRm(u"ࠬ࠵༹ࠧ") in ympS917x6nz: ympS917x6nz = ympS917x6nz.rsplit(HMO0QciekqVpLKmA(u"࠭࠯ࠨ༺"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠶ᖘ"))[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠶ᖘ")]
	if xEc7nR3qoAlv6C8YjD==GGTRaYBDeNyI25zlF(u"ࠧ࡯ࡣࡰࡩࠬ༻") and zOZvXaebGNwHKfjRA(u"ࠨ࠰ࠪ༼") in ympS917x6nz:
		NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8 = ympS917x6nz.split(qNZKwi2M1S4fBzGQYrmPnea(u"ࠩ࠱ࠫ༽"))
		wwRk9qaXWGj5EoLmJIprzNUn23 = len(NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8)
		if wwRk9qaXWGj5EoLmJIprzNUn23<=xxBJoKG54uwQ(u"࠲ᖚ") or ZpH2IWt7veyFobTsAnhi41(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ༾") in ympS917x6nz: NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8 = NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8[zOZvXaebGNwHKfjRA(u"࠶ᖙ")]
		elif wwRk9qaXWGj5EoLmJIprzNUn23>=lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵ᖜ"): NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8 = NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8[V391t7nQWUBR5euCkJ(u"࠲ᖛ")]
		if len(NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8)>zOZvXaebGNwHKfjRA(u"࠴ᖝ"): ympS917x6nz = NrjRi5MYQCh6ZGWHaBbKwEzUcVT0n8
	return ympS917x6nz
def PPpWoLVXID4(rZLsBFGvqJbwfHDp):
	UWQR0piV5f = repr(rZLsBFGvqJbwfHDp.encode(KbL94nDHufSF0VcO2Nk3(u"ࠫࡺࡺࡦ࠹ࠩ༿"))).replace(vkMRnTNV9jFm(u"ࠧ࠭ࠢཀ"),HMO0QciekqVpLKmA(u"࠭ࠧཁ"))
	return UWQR0piV5f
def mL8hMBHF5CjbJk(RRDYFqb1MzZQLIsoArn):
	rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࠨག")
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: RRDYFqb1MzZQLIsoArn = RRDYFqb1MzZQLIsoArn.decode(Vv0lSjAOHLfMnam3wtdor(u"ࠨࡷࡷࡪ࠽࠭གྷ"))
	from unicodedata import decomposition as u3spdvWxnetUMfwPGoR
	for n9lebqy5JCKDBTh8ZoVOvNQHMwf in RRDYFqb1MzZQLIsoArn:
		if   n9lebqy5JCKDBTh8ZoVOvNQHMwf==DKqQekNtF6WlJLhBP9M5ca(u"ࡷࠪฦࠬང"): fl5RqZsAQDhxpi2wv1UMIjuoHgy = KbL94nDHufSF0VcO2Nk3(u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫཅ")
		elif n9lebqy5JCKDBTh8ZoVOvNQHMwf==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࡹࠬษࠧཆ"): fl5RqZsAQDhxpi2wv1UMIjuoHgy = dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭ཇ")
		elif n9lebqy5JCKDBTh8ZoVOvNQHMwf==KbL94nDHufSF0VcO2Nk3(u"ࡻࠧลࠩ཈"): fl5RqZsAQDhxpi2wv1UMIjuoHgy = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨཉ")
		elif n9lebqy5JCKDBTh8ZoVOvNQHMwf==dxAs4otSE98YmZnKy2iwRCB(u"ࡶࠩศࠫཊ"): fl5RqZsAQDhxpi2wv1UMIjuoHgy = ZpH2IWt7veyFobTsAnhi41(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪཋ")
		elif n9lebqy5JCKDBTh8ZoVOvNQHMwf==dxAs4otSE98YmZnKy2iwRCB(u"ࡸࠫห࠭ཌ"): fl5RqZsAQDhxpi2wv1UMIjuoHgy = ZpH2IWt7veyFobTsAnhi41(u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬཌྷ")
		else:
			OlFUbJCMB4n8 = u3spdvWxnetUMfwPGoR(n9lebqy5JCKDBTh8ZoVOvNQHMwf)
			if zOZvXaebGNwHKfjRA(u"ࠬࠦࠧཎ") in OlFUbJCMB4n8: fl5RqZsAQDhxpi2wv1UMIjuoHgy = IJ6VkihabRm(u"࠭࡜࡝ࡷࠪཏ")+OlFUbJCMB4n8.split(DDS79jdWzLtE(u"ࠧࠡࠩཐ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠵ᖞ"))[q0JfWbP8vACLxSNIncpOXkR6j(u"࠵ᖞ")]
			else:
				fl5RqZsAQDhxpi2wv1UMIjuoHgy = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨ࠲࠳࠴࠵࠭ད")+hex(ord(n9lebqy5JCKDBTh8ZoVOvNQHMwf)).replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࠳ࡼࠬདྷ"),ZpH2IWt7veyFobTsAnhi41(u"ࠪࠫན"))
				fl5RqZsAQDhxpi2wv1UMIjuoHgy = DKqQekNtF6WlJLhBP9M5ca(u"ࠫࡡࡢࡵࠨཔ")+fl5RqZsAQDhxpi2wv1UMIjuoHgy[-q0JfWbP8vACLxSNIncpOXkR6j(u"࠹ᖟ"):]
		rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi += fl5RqZsAQDhxpi2wv1UMIjuoHgy
	rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi = rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi.replace(fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭ཕ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧབ"))
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi = rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi.decode(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨབྷ")).encode(DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡷࡷࡪ࠽࠭མ"))
	else: rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi = rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi.encode(KbL94nDHufSF0VcO2Nk3(u"ࠩࡸࡸ࡫࠾ࠧཙ")).decode(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫཚ"))
	return rrVkfoxhGNKv3Ocymz6p2HMTRC5Wqi
def wod1HJ0fnvcTNAX2WIiMu9P(header=a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"้ࠫ๎อสࠢส่๊็วห์ะࠫཛ"),default=ddK4MmwpX5oG(u"ࠬ࠭ཛྷ"),ni20BfA6cYHTRDt5OeaU8bkxMVW=ddK4MmwpX5oG(u"ࡆࡢ࡮ࡶࡩ᜔"),source=DKqQekNtF6WlJLhBP9M5ca(u"࠭ࠧཝ")):
	gq2FVNBUKPzIw1pZAnYHJG = kVtL26DzXNPoB3aehscng4rJ9bICqj(header,default,type=yOuHBDmPps3vd24cnLagiK0.INPUT_ALPHANUM)
	gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.replace(xxBJoKG54uwQ(u"ࠧࠡࠢࠪཞ"),vkMRnTNV9jFm(u"ࠨࠢࠪཟ")).replace(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࠣࠤࠬའ"),GGTRaYBDeNyI25zlF(u"ࠪࠤࠬཡ")).replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠥࠦࠧར"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬࠦࠧལ"))
	if not gq2FVNBUKPzIw1pZAnYHJG and not ni20BfA6cYHTRDt5OeaU8bkxMVW:
		zRM3tZx2v6DjJU(xxpPYJOnoAUrlBzyveui(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ཤ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫཥ")+gq2FVNBUKPzIw1pZAnYHJG+ZpH2IWt7veyFobTsAnhi41(u"ࠨࠤࠪས"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ddK4MmwpX5oG(u"ࠩࠪཧ"),uhOkAKtLVv4XTy1nWE6(u"ࠪࠫཨ"),v7reLlOXCgD5pZ14w2tUA(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཀྵ"),ddK4MmwpX5oG(u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨཪ"))
		return uhOkAKtLVv4XTy1nWE6(u"࠭ࠧཫ")
	if gq2FVNBUKPzIw1pZAnYHJG not in [iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࠨཬ"),uhOkAKtLVv4XTy1nWE6(u"ࠨࠢࠪ཭")]:
		gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.strip(DKqQekNtF6WlJLhBP9M5ca(u"ࠩࠣࠫ཮"))
		gq2FVNBUKPzIw1pZAnYHJG = mL8hMBHF5CjbJk(gq2FVNBUKPzIw1pZAnYHJG)
	if source!=DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ཯") and twUoB7cHNRhq(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭཰"),fcIm8tvxlXZsaEY3bwuG4B(u"ཱࠬ࠭"),[gq2FVNBUKPzIw1pZAnYHJG],Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡇࡣ࡯ࡷࡪ᜕")):
		zRM3tZx2v6DjJU(fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡎࡐࡖࡌࡇࡊི࠭"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤཱིࠪ")+gq2FVNBUKPzIw1pZAnYHJG+OARzhnB9o7uYvQGFaIcZ(u"ࠨࠤུࠪ"))
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(IJ6VkihabRm(u"ཱུࠩࠪ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠪࠫྲྀ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཷ"),KbL94nDHufSF0VcO2Nk3(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧླྀ"))
		return u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࠧཹ")
	zRM3tZx2v6DjJU(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡏࡑࡗࡍࡈࡋེࠧ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀཻࠠࠡࠢࠥࠫ")+gq2FVNBUKPzIw1pZAnYHJG+xxBJoKG54uwQ(u"ོࠩࠥࠫ"))
	return gq2FVNBUKPzIw1pZAnYHJG
def RjzVfbE0ILcNXFQJniSMBOskK13ox(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,Eudgv5cTUHF2AzKpkx={}):
	DDRulV7aKN3jCOWSBQkb95,f3iXFyRONxb6v2EjBJqoGu7ac,BvCbTl1dO9,HvDCJrZMGAYxRnTsSz = lZqkuhgaBHSVX8NItKG05cdLJe7Ao,{},{},vkMRnTNV9jFm(u"ཽࠪࠫ")
	if KbL94nDHufSF0VcO2Nk3(u"ࠫࢁ࠭ཾ") in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: DDRulV7aKN3jCOWSBQkb95,f3iXFyRONxb6v2EjBJqoGu7ac = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,KbL94nDHufSF0VcO2Nk3(u"ࠬࢂࠧཿ"))
	C37rfh5cAuMOWkXGpF4iQZdogLKn6 = list(set(list(Eudgv5cTUHF2AzKpkx.keys())+list(f3iXFyRONxb6v2EjBJqoGu7ac.keys())))
	for SonE0wpbWDiYV in C37rfh5cAuMOWkXGpF4iQZdogLKn6:
		if SonE0wpbWDiYV in list(f3iXFyRONxb6v2EjBJqoGu7ac.keys()): BvCbTl1dO9[SonE0wpbWDiYV] = f3iXFyRONxb6v2EjBJqoGu7ac[SonE0wpbWDiYV]
		else: BvCbTl1dO9[SonE0wpbWDiYV] = Eudgv5cTUHF2AzKpkx[SonE0wpbWDiYV]
	if iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶྀࠪ") not in C37rfh5cAuMOWkXGpF4iQZdogLKn6: BvCbTl1dO9[f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷཱྀࠫ")] = yWgZFzdaNR5iw6m8Q9G7CL()
	if OARzhnB9o7uYvQGFaIcZ(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩྂ") not in C37rfh5cAuMOWkXGpF4iQZdogLKn6: BvCbTl1dO9[v7reLlOXCgD5pZ14w2tUA(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪྃ")] = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(DDRulV7aKN3jCOWSBQkb95,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡹࡷࡲ྄ࠧ"))
	for SonE0wpbWDiYV in list(BvCbTl1dO9.keys()): HvDCJrZMGAYxRnTsSz += xxpPYJOnoAUrlBzyveui(u"ࠫࠫ࠭྅")+SonE0wpbWDiYV+DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡃࠧ྆")+BvCbTl1dO9[SonE0wpbWDiYV]
	if HvDCJrZMGAYxRnTsSz: HvDCJrZMGAYxRnTsSz = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡼࠨ྇")+HvDCJrZMGAYxRnTsSz[dxAs4otSE98YmZnKy2iwRCB(u"࠷ᖠ"):]
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(ooDaNCkx4c0FjJs,xxpPYJOnoAUrlBzyveui(u"ࠧࡈࡇࡗࠫྈ"),DDRulV7aKN3jCOWSBQkb95,ddK4MmwpX5oG(u"ࠨࠩྉ"),BvCbTl1dO9,uhOkAKtLVv4XTy1nWE6(u"ࠩࠪྊ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࠫྋ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨྌ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡈࡤࡰࡸ࡫᜖"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡈࡤࡰࡸ࡫᜖"))
	RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
	if GGTRaYBDeNyI25zlF(u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩྍ") not in RkLE6BzZ2KX: return [fcIm8tvxlXZsaEY3bwuG4B(u"࠭࠭࠲ࠩྎ")],[DDRulV7aKN3jCOWSBQkb95+HvDCJrZMGAYxRnTsSz]
	if V391t7nQWUBR5euCkJ(u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫྏ") in RkLE6BzZ2KX: return [tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨ࠯࠴ࠫྐ")],[DDRulV7aKN3jCOWSBQkb95+HvDCJrZMGAYxRnTsSz]
	if q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭ྑ") in RkLE6BzZ2KX: return [ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪ࠱࠶࠭ྒ")],[DDRulV7aKN3jCOWSBQkb95+HvDCJrZMGAYxRnTsSz]
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,o6Pm3NElhX9,CWSkpDJUihE = [],[],[],[]
	I7Q0GxoOc5ECkY6zfjhg = QPuHKNAT4jmCRg.findall(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬྒྷ"),RkLE6BzZ2KX+DDS79jdWzLtE(u"ࠬࡢ࡮ࠨྔ"),QPuHKNAT4jmCRg.DOTALL)
	if not I7Q0GxoOc5ECkY6zfjhg: return [V391t7nQWUBR5euCkJ(u"࠭࠭࠲ࠩྕ")],[DDRulV7aKN3jCOWSBQkb95+HvDCJrZMGAYxRnTsSz]
	for dJEmG7MFDQfxks9,SSXgFdnlqLO8y4Rkiu in I7Q0GxoOc5ECkY6zfjhg:
		vhJt8jNQ4qFMrAxcb7Imy2OpH,E03sXv1wm6,i5DftlhA6vQ2GF = {},-HMO0QciekqVpLKmA(u"࠱ᖡ"),-HMO0QciekqVpLKmA(u"࠱ᖡ")
		ZXfH79LrSqVNAlD4ghCsFyPR = OARzhnB9o7uYvQGFaIcZ(u"ࠧࠨྖ")
		wknFHsBv9VP = dJEmG7MFDQfxks9.split(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨ࠮ࠪྗ"))
		for zO0UA5L7ta1sIHpmqjbeBvXf3Kky in wknFHsBv9VP:
			if DDS79jdWzLtE(u"ࠩࡀࠫ྘") in zO0UA5L7ta1sIHpmqjbeBvXf3Kky:
				SonE0wpbWDiYV,ccgnvJDbLi3FuVKNdM6Ea = zO0UA5L7ta1sIHpmqjbeBvXf3Kky.split(vkMRnTNV9jFm(u"ࠪࡁࠬྙ"),dxAs4otSE98YmZnKy2iwRCB(u"࠲ᖢ"))
				vhJt8jNQ4qFMrAxcb7Imy2OpH[SonE0wpbWDiYV.lower()] = ccgnvJDbLi3FuVKNdM6Ea
		if ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨྚ") in dJEmG7MFDQfxks9.lower():
			E03sXv1wm6 = int(vhJt8jNQ4qFMrAxcb7Imy2OpH[xxpPYJOnoAUrlBzyveui(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྛ")])//Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠳࠳࠶࠹ᖣ")
			ZXfH79LrSqVNAlD4ghCsFyPR += str(E03sXv1wm6)+ddK4MmwpX5oG(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ྜ")
		elif d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྜྷ") in dJEmG7MFDQfxks9.lower():
			E03sXv1wm6 = int(vhJt8jNQ4qFMrAxcb7Imy2OpH[L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྞ")])//iRTygNp4Lf36wQKlD2MHUhG7B(u"࠴࠴࠷࠺ᖤ")
			ZXfH79LrSqVNAlD4ghCsFyPR += str(E03sXv1wm6)+qNZKwi2M1S4fBzGQYrmPnea(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩྟ")
		if V391t7nQWUBR5euCkJ(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧྠ") in dJEmG7MFDQfxks9.lower():
			i5DftlhA6vQ2GF = int(vhJt8jNQ4qFMrAxcb7Imy2OpH[uhOkAKtLVv4XTy1nWE6(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨྡ")].split(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡾࠧྡྷ"))[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵ᖥ")])
			ZXfH79LrSqVNAlD4ghCsFyPR += str(i5DftlhA6vQ2GF)+f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࠠࠡࠩྣ")
		ZXfH79LrSqVNAlD4ghCsFyPR = ZXfH79LrSqVNAlD4ghCsFyPR.strip(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࠡࠢࠪྤ"))
		if not ZXfH79LrSqVNAlD4ghCsFyPR: ZXfH79LrSqVNAlD4ghCsFyPR = v7reLlOXCgD5pZ14w2tUA(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩྥ")
		if not SSXgFdnlqLO8y4Rkiu.startswith(zOZvXaebGNwHKfjRA(u"ࠩ࡫ࡸࡹࡶࠧྦ")):
			if SSXgFdnlqLO8y4Rkiu.startswith(OARzhnB9o7uYvQGFaIcZ(u"ࠪ࠳࠴࠭ྦྷ")): SSXgFdnlqLO8y4Rkiu = DDRulV7aKN3jCOWSBQkb95.split(HMO0QciekqVpLKmA(u"ࠫ࠿࠭ྨ"),L91nVzxH4hYrgPDsOuljXd0J(u"࠶ᖦ"))[v7reLlOXCgD5pZ14w2tUA(u"࠶ᖧ")]+vkMRnTNV9jFm(u"ࠬࡀࠧྩ")+SSXgFdnlqLO8y4Rkiu
			elif SSXgFdnlqLO8y4Rkiu.startswith(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭࠯ࠨྪ")): SSXgFdnlqLO8y4Rkiu = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(DDRulV7aKN3jCOWSBQkb95,DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡶࡴ࡯ࠫྫ"))+SSXgFdnlqLO8y4Rkiu
			else: SSXgFdnlqLO8y4Rkiu = DDRulV7aKN3jCOWSBQkb95.rsplit(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨ࠱ࠪྫྷ"),dxAs4otSE98YmZnKy2iwRCB(u"࠱ᖨ"))[ddK4MmwpX5oG(u"࠱ᖩ")]+ddK4MmwpX5oG(u"ࠩ࠲ࠫྭ")+SSXgFdnlqLO8y4Rkiu
		if DDS79jdWzLtE(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬྮ") in list(vhJt8jNQ4qFMrAxcb7Imy2OpH.keys()):
			FsnXTNzcG53RUk = vhJt8jNQ4qFMrAxcb7Imy2OpH[ddK4MmwpX5oG(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭ྯ")]
			FsnXTNzcG53RUk = FsnXTNzcG53RUk.replace(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࠨࠧྰ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࠧྱ")).replace(OARzhnB9o7uYvQGFaIcZ(u"ࠢࠨࠤྲ"),uhOkAKtLVv4XTy1nWE6(u"ࠨࠩླ")).split(xxpPYJOnoAUrlBzyveui(u"ࠩࠦࠫྴ"),DDS79jdWzLtE(u"࠳ᖪ"))[fcIm8tvxlXZsaEY3bwuG4B(u"࠳ᖫ")]
			fBYse5u6VkLhmcZg = H93DlbtKLEarfQ8w7GcoIukSexv0J(FsnXTNzcG53RUk)
			if fBYse5u6VkLhmcZg: nUbpaNT0vhcj7ZsEz = ZXfH79LrSqVNAlD4ghCsFyPR+dxAs4otSE98YmZnKy2iwRCB(u"ࠪࠤࠥ࠭ྵ")+fBYse5u6VkLhmcZg
			else: nUbpaNT0vhcj7ZsEz = ZXfH79LrSqVNAlD4ghCsFyPR
			nUbpaNT0vhcj7ZsEz = nUbpaNT0vhcj7ZsEz+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫྶ")
			nUbpaNT0vhcj7ZsEz = nUbpaNT0vhcj7ZsEz+xxBJoKG54uwQ(u"ࠬࠦࠠࠨྷ")+znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(FsnXTNzcG53RUk,L91nVzxH4hYrgPDsOuljXd0J(u"࠭࡮ࡢ࡯ࡨࠫྸ"))
			xitERh4TD2jGJPq5Nuv39CAmg.append(nUbpaNT0vhcj7ZsEz)
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(FsnXTNzcG53RUk)
			o6Pm3NElhX9.append(i5DftlhA6vQ2GF)
			CWSkpDJUihE.append(E03sXv1wm6)
		SSXgFdnlqLO8y4Rkiu = SSXgFdnlqLO8y4Rkiu.split(fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࠤࠩྐྵ"),ddK4MmwpX5oG(u"࠵ᖬ"))[IJ6VkihabRm(u"࠵ᖭ")]
		fBYse5u6VkLhmcZg = H93DlbtKLEarfQ8w7GcoIukSexv0J(SSXgFdnlqLO8y4Rkiu)
		if fBYse5u6VkLhmcZg: ZXfH79LrSqVNAlD4ghCsFyPR = ZXfH79LrSqVNAlD4ghCsFyPR+zOZvXaebGNwHKfjRA(u"ࠨࠢࠣࠫྺ")+fBYse5u6VkLhmcZg
		ZXfH79LrSqVNAlD4ghCsFyPR = ZXfH79LrSqVNAlD4ghCsFyPR+ZpH2IWt7veyFobTsAnhi41(u"ࠩࠣࠤࠬྻ")+znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(SSXgFdnlqLO8y4Rkiu,vkMRnTNV9jFm(u"ࠪࡲࡦࡳࡥࠨྼ"))
		xitERh4TD2jGJPq5Nuv39CAmg.append(ZXfH79LrSqVNAlD4ghCsFyPR)
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(SSXgFdnlqLO8y4Rkiu)
		o6Pm3NElhX9.append(i5DftlhA6vQ2GF)
		CWSkpDJUihE.append(E03sXv1wm6)
	QV8h5bD9YtNq1gfmx2jUyZlXASWv4L = list(zip(xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,o6Pm3NElhX9,CWSkpDJUihE))
	QV8h5bD9YtNq1gfmx2jUyZlXASWv4L = sorted(QV8h5bD9YtNq1gfmx2jUyZlXASWv4L, reverse=a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡗࡶࡺ࡫᜗"), key=lambda key: key[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠹ᖮ")])
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA,o6Pm3NElhX9,CWSkpDJUihE = list(zip(*QV8h5bD9YtNq1gfmx2jUyZlXASWv4L))
	xitERh4TD2jGJPq5Nuv39CAmg,LL8heV7kxYI5bOjEZ6XaUQWwfPA = list(xitERh4TD2jGJPq5Nuv39CAmg),list(LL8heV7kxYI5bOjEZ6XaUQWwfPA)
	UdxpbPKgBScklJLj542O0feZsro = []
	for SSXgFdnlqLO8y4Rkiu in LL8heV7kxYI5bOjEZ6XaUQWwfPA: UdxpbPKgBScklJLj542O0feZsro.append(SSXgFdnlqLO8y4Rkiu+HvDCJrZMGAYxRnTsSz)
	return xitERh4TD2jGJPq5Nuv39CAmg,UdxpbPKgBScklJLj542O0feZsro
def oGtm30nXy6kYH9JRAhBDsvuO(zfSh8JxwD9AFiG2e5l,SAxhNOBlQazEiXKFbIk2yZ7qRTY905=GGTRaYBDeNyI25zlF(u"ࠫࠬ྽")):
	if not SAxhNOBlQazEiXKFbIk2yZ7qRTY905: SAxhNOBlQazEiXKFbIk2yZ7qRTY905 = aaAosTOK3Uegui0dNBIqDEy[GGTRaYBDeNyI25zlF(u"࠰ᖯ")]
	if zfSh8JxwD9AFiG2e5l.replace(fcIm8tvxlXZsaEY3bwuG4B(u"ࠬ࠴ࠧ྾"),Vv0lSjAOHLfMnam3wtdor(u"࠭ࠧ྿")).isdigit(): return [zfSh8JxwD9AFiG2e5l]
	from struct import pack as om7a4pV8WXIHBzNwrYOFlq,unpack_from as phbaAWe6IVG1vg4Sx8Ls2zfOmUR9
	from socket import socket as HKIPWB4JXYaEu6,AF_INET as LFgRCWvkM8hAD,SOCK_DGRAM as vkRzXqBOAWo8u3fwJPGtjZY0gNEI5
	try:
		pCERDO1wdH7gKVxaltMSvA6hreNP = om7a4pV8WXIHBzNwrYOFlq(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠢ࠿ࡊࠥ࿀"), vkMRnTNV9jFm(u"࠲࠴࠳࠸࠾ᖰ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠣࡀࡋࠦ࿁"), iRTygNp4Lf36wQKlD2MHUhG7B(u"࠴࠸࠺ᖱ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(dxAs4otSE98YmZnKy2iwRCB(u"ࠤࡁࡌࠧ࿂"), KbL94nDHufSF0VcO2Nk3(u"࠴ᖲ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(uhOkAKtLVv4XTy1nWE6(u"ࠥࡂࡍࠨ࿃"), GGTRaYBDeNyI25zlF(u"࠴ᖳ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠦࡃࡎࠢ࿄"), KbL94nDHufSF0VcO2Nk3(u"࠵ᖴ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࡄࡈࠣ࿅"), Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠶ᖵ"))
		if Nnxm30dfoBWRYpIC7KsQGl: vapb7rThjJlLWC8kfgM = zfSh8JxwD9AFiG2e5l.split(IJ6VkihabRm(u"࠭࠮ࠨ࿆"))
		else: vapb7rThjJlLWC8kfgM = zfSh8JxwD9AFiG2e5l.decode(IJ6VkihabRm(u"ࠧࡶࡶࡩ࠼ࠬ࿇")).split(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨ࠰ࠪ࿈"))
		for igZANacQEH0s14UGPSje367q8KBOC in vapb7rThjJlLWC8kfgM:
			L2ZaRFG5myvEj1hDrqOu6NYWMf = igZANacQEH0s14UGPSje367q8KBOC.encode(xxBJoKG54uwQ(u"ࠩࡸࡸ࡫࠾ࠧ࿉"))
			pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(DKqQekNtF6WlJLhBP9M5ca(u"ࠥࡆࠧ࿊"), len(igZANacQEH0s14UGPSje367q8KBOC))
			for GTt6BPSxNMqhzmUOAsCKLaDc in igZANacQEH0s14UGPSje367q8KBOC:
				pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(vkMRnTNV9jFm(u"ࠦࡨࠨ࿋"), GTt6BPSxNMqhzmUOAsCKLaDc.encode(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡻࡴࡧ࠺ࠪ࿌")))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡂࠣ࿍"), DKqQekNtF6WlJLhBP9M5ca(u"࠰ᖶ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(HMO0QciekqVpLKmA(u"ࠢ࠿ࡊࠥ࿎"), u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠲ᖷ"))
		pCERDO1wdH7gKVxaltMSvA6hreNP += om7a4pV8WXIHBzNwrYOFlq(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠣࡀࡋࠦ࿏"), ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳ᖸ"))
		kicW9IrCgpV5PwOnGhLFBm4b3dA = HKIPWB4JXYaEu6(LFgRCWvkM8hAD,vkRzXqBOAWo8u3fwJPGtjZY0gNEI5)
		kicW9IrCgpV5PwOnGhLFBm4b3dA.sendto(bytes(pCERDO1wdH7gKVxaltMSvA6hreNP), (SAxhNOBlQazEiXKFbIk2yZ7qRTY905, Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠸࠷ᖹ")))
		kicW9IrCgpV5PwOnGhLFBm4b3dA.settimeout(Vv0lSjAOHLfMnam3wtdor(u"࠺ᖺ"))
		ZEJAFRNxIrQSU, qFzBuU9nvtVR8HlMQDSWTke4rdNi1J = kicW9IrCgpV5PwOnGhLFBm4b3dA.recvfrom(GGTRaYBDeNyI25zlF(u"࠶࠶࠲࠵ᖻ"))
		kicW9IrCgpV5PwOnGhLFBm4b3dA.close()
		rWkpgZhP6lNSmGn = phbaAWe6IVG1vg4Sx8Ls2zfOmUR9(OARzhnB9o7uYvQGFaIcZ(u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ࿐"), ZEJAFRNxIrQSU, u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶ᖼ"))
		EgK64PTWOJzwH8N = rWkpgZhP6lNSmGn[IJ6VkihabRm(u"࠳ᖽ")]
		DhoFazTsNZtI3gAxSl = len(zfSh8JxwD9AFiG2e5l)+f8PVRTseIuj9BckO6GoyF5Lxv(u"࠲࠺ᖾ")
		Iga6ZWzdXDuoFO7NPjEf2AMxL8 = []
		for _IL5i20GnYFXRlHC7ZzS8P in range(EgK64PTWOJzwH8N):
			mxTYvDE4dtLkgFycseWhizQ5oSH = DhoFazTsNZtI3gAxSl
			Y2Qcokw4lJ7bFO1p = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠳ᖿ")
			EQkP4ZmJjLepVbSxAWi = zOZvXaebGNwHKfjRA(u"ࡊࡦࡲࡳࡦ᜘")
			while IJ6VkihabRm(u"࡙ࡸࡵࡦ᜙"):
				GTt6BPSxNMqhzmUOAsCKLaDc = phbaAWe6IVG1vg4Sx8Ls2zfOmUR9(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠥࡂࡇࠨ࿑"), ZEJAFRNxIrQSU, mxTYvDE4dtLkgFycseWhizQ5oSH)[qNZKwi2M1S4fBzGQYrmPnea(u"࠳ᗀ")]
				if GTt6BPSxNMqhzmUOAsCKLaDc == ZpH2IWt7veyFobTsAnhi41(u"࠴ᗁ"):
					mxTYvDE4dtLkgFycseWhizQ5oSH += GGTRaYBDeNyI25zlF(u"࠶ᗂ")
					break
				if GTt6BPSxNMqhzmUOAsCKLaDc >= HMO0QciekqVpLKmA(u"࠷࠹࠳ᗃ"):
					fQYzGksWX9RmPOM = phbaAWe6IVG1vg4Sx8Ls2zfOmUR9(zOZvXaebGNwHKfjRA(u"ࠦࡃࡈࠢ࿒"), ZEJAFRNxIrQSU, mxTYvDE4dtLkgFycseWhizQ5oSH + ZpH2IWt7veyFobTsAnhi41(u"࠱ᗄ"))[zOZvXaebGNwHKfjRA(u"࠱ᗅ")]
					mxTYvDE4dtLkgFycseWhizQ5oSH = ((GTt6BPSxNMqhzmUOAsCKLaDc << zOZvXaebGNwHKfjRA(u"࠻ᗇ")) + fQYzGksWX9RmPOM - 0xc000) - DDS79jdWzLtE(u"࠳ᗆ")
					EQkP4ZmJjLepVbSxAWi = DKqQekNtF6WlJLhBP9M5ca(u"࡚ࡲࡶࡧ᜚")
				mxTYvDE4dtLkgFycseWhizQ5oSH += DDS79jdWzLtE(u"࠵ᗈ")
				if EQkP4ZmJjLepVbSxAWi == tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡆࡢ࡮ࡶࡩ᜛"): Y2Qcokw4lJ7bFO1p += qNZKwi2M1S4fBzGQYrmPnea(u"࠶ᗉ")
			if EQkP4ZmJjLepVbSxAWi == DKqQekNtF6WlJLhBP9M5ca(u"ࡕࡴࡸࡩ᜜"): Y2Qcokw4lJ7bFO1p += L91nVzxH4hYrgPDsOuljXd0J(u"࠷ᗊ")
			DhoFazTsNZtI3gAxSl = DhoFazTsNZtI3gAxSl + Y2Qcokw4lJ7bFO1p
			uuwEXVjpk6vlSgyJfeYiHTzsC3bFG = phbaAWe6IVG1vg4Sx8Ls2zfOmUR9(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡄࡈࡉࡋࡋࠦ࿓"), ZEJAFRNxIrQSU, DhoFazTsNZtI3gAxSl)
			DhoFazTsNZtI3gAxSl = DhoFazTsNZtI3gAxSl + lunVJF2G5bZMgTcCje0vaIB371SX(u"࠱࠱ᗋ")
			hQBfH4WrNjPF7Em = uuwEXVjpk6vlSgyJfeYiHTzsC3bFG[xxBJoKG54uwQ(u"࠱ᗌ")]
			E20C3anHklvchXBI6MLqWKZAi = uuwEXVjpk6vlSgyJfeYiHTzsC3bFG[vkMRnTNV9jFm(u"࠵ᗍ")]
			if hQBfH4WrNjPF7Em == f8PVRTseIuj9BckO6GoyF5Lxv(u"࠴ᗎ"):
				YwCLOTdfzG = phbaAWe6IVG1vg4Sx8Ls2zfOmUR9(IJ6VkihabRm(u"ࠨ࠾ࠣ࿔")+vkMRnTNV9jFm(u"ࠢࡃࠤ࿕")*E20C3anHklvchXBI6MLqWKZAi, ZEJAFRNxIrQSU, DhoFazTsNZtI3gAxSl)
				ip = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠩ࿖")
				for GTt6BPSxNMqhzmUOAsCKLaDc in YwCLOTdfzG: ip += str(GTt6BPSxNMqhzmUOAsCKLaDc) + OARzhnB9o7uYvQGFaIcZ(u"ࠩ࠱ࠫ࿗")
				ip = ip[IJ6VkihabRm(u"࠵ᗐ"):-gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠵ᗏ")]
				Iga6ZWzdXDuoFO7NPjEf2AMxL8.append(ip)
			if hQBfH4WrNjPF7Em in [zOZvXaebGNwHKfjRA(u"࠲ᗓ"),DDS79jdWzLtE(u"࠴ᗔ"),zOZvXaebGNwHKfjRA(u"࠸ᗕ"),ZpH2IWt7veyFobTsAnhi41(u"࠺ᗖ"),L91nVzxH4hYrgPDsOuljXd0J(u"࠷࠵ᗑ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠲࠹ᗒ")]: DhoFazTsNZtI3gAxSl = DhoFazTsNZtI3gAxSl + E20C3anHklvchXBI6MLqWKZAi
	except: Iga6ZWzdXDuoFO7NPjEf2AMxL8 = []
	if not Iga6ZWzdXDuoFO7NPjEf2AMxL8: zRM3tZx2v6DjJU(qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࿘"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+p1lrNRIXqLQJznH6O(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ࿙")+zfSh8JxwD9AFiG2e5l+p1lrNRIXqLQJznH6O(u"ࠬࠦ࡝ࠨ࿚"))
	return Iga6ZWzdXDuoFO7NPjEf2AMxL8
def twUoB7cHNRhq(mm5vCBc4DOz2Fj,DDRulV7aKN3jCOWSBQkb95,KQMJtrow90bCy,showDialogs=dxAs4otSE98YmZnKy2iwRCB(u"ࡖࡵࡹࡪ᜝")):
	if KQMJtrow90bCy:
		qCc1PMQwpNSnuE6 = [d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ใษษิࠫ࿛"),vkMRnTNV9jFm(u"ࠧษษ็฾ࠬ࿜"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡣࡧࡹࡱࡺࠧ࿝"),zOZvXaebGNwHKfjRA(u"ࠩࡻࡼࠬ࿞"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡷࡪࡾࠧ࿟")]
		if mm5vCBc4DOz2Fj!=ddK4MmwpX5oG(u"ࠫࡇࡕࡋࡓࡃࠪ࿠"):
			qCc1PMQwpNSnuE6 += [HMO0QciekqVpLKmA(u"ࠬࡸ࠺ࠨ࿡"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡲ࠮ࠩ࿢"),OARzhnB9o7uYvQGFaIcZ(u"ࠧ࠮࡯ࡤࠫ࿣")]
			qCc1PMQwpNSnuE6 += [dxAs4otSE98YmZnKy2iwRCB(u"ࠨ࠼ࡵࠫ࿤"),V391t7nQWUBR5euCkJ(u"ࠩ࠰ࡶࠬ࿥"),IJ6VkihabRm(u"ࠪࡱࡦ࠳ࠧ࿦")]
		for yN6vzYlOoCD5KMB02qjfLFn in KQMJtrow90bCy:
			if p1lrNRIXqLQJznH6O(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭࿧") in yN6vzYlOoCD5KMB02qjfLFn: continue
			if vkMRnTNV9jFm(u"ࠬำไใหࠪ࿨") in yN6vzYlOoCD5KMB02qjfLFn: continue
			yN6vzYlOoCD5KMB02qjfLFn = yN6vzYlOoCD5KMB02qjfLFn.lower()
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: yN6vzYlOoCD5KMB02qjfLFn = yN6vzYlOoCD5KMB02qjfLFn.decode(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࡵࡵࡨ࠻ࠫ࿩")).encode(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡶࡶࡩ࠼ࠬ࿪"))
			yN6vzYlOoCD5KMB02qjfLFn = yN6vzYlOoCD5KMB02qjfLFn.replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨ࠼ࠪ࿫"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࠪ࿬"))
			w2WAq7ufbL = QPuHKNAT4jmCRg.findall(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ࿭"),yN6vzYlOoCD5KMB02qjfLFn,QPuHKNAT4jmCRg.DOTALL)
			Bso0W6CHxYAZuTl48gePNUzpF = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡉࡥࡱࡹࡥ᜞")
			for WXr1RNVPGyU4HEbSIamOl7KweYsiJ in w2WAq7ufbL:
				if len(WXr1RNVPGyU4HEbSIamOl7KweYsiJ)==xxBJoKG54uwQ(u"࠷ᗗ"):
					Bso0W6CHxYAZuTl48gePNUzpF = xxpPYJOnoAUrlBzyveui(u"ࡘࡷࡻࡥᜟ")
					break
			if a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ࿮") in yN6vzYlOoCD5KMB02qjfLFn: continue
			elif d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭࿯") in yN6vzYlOoCD5KMB02qjfLFn: continue
			elif Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ฺ๋࠭ำฺ้ࠣ์แࠨ࿰") in yN6vzYlOoCD5KMB02qjfLFn: continue
			elif x9N7DKVT1rjsPmlieqQ8HJgU(KbL94nDHufSF0VcO2Nk3(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ࿱")): continue
			elif yN6vzYlOoCD5KMB02qjfLFn in [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡴࠪ࿲")] or Bso0W6CHxYAZuTl48gePNUzpF or any(pp8iHB3W9Cs in yN6vzYlOoCD5KMB02qjfLFn for pp8iHB3W9Cs in qCc1PMQwpNSnuE6):
				zRM3tZx2v6DjJU(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ࿳"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+V391t7nQWUBR5euCkJ(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ࿴")+DDRulV7aKN3jCOWSBQkb95+OARzhnB9o7uYvQGFaIcZ(u"ࠫࠥࡣࠧ࿵"))
				if showDialogs: uFCykYQW68S(V391t7nQWUBR5euCkJ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿶"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ࿷"))
				return GGTRaYBDeNyI25zlF(u"࡙ࡸࡵࡦᜠ")
	return V391t7nQWUBR5euCkJ(u"ࡌࡡ࡭ࡵࡨᜡ")
def qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(*aargs,**kkwargs):
	if aargs:
		direction = aargs[V391t7nQWUBR5euCkJ(u"࠶ᗘ")]
		ajpkWtS31Vuvf796UBcwiLE = aargs[KbL94nDHufSF0VcO2Nk3(u"࠱ᗙ")]
		if not direction: direction = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿸")
		if not ajpkWtS31Vuvf796UBcwiLE: ajpkWtS31Vuvf796UBcwiLE = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨษึฮ๊ืวาࠩ࿹")
		qYF8frkpLDEO = aargs[xxBJoKG54uwQ(u"࠳ᗚ")]
		gq2FVNBUKPzIw1pZAnYHJG = v7reLlOXCgD5pZ14w2tUA(u"ࠩ࡟ࡲࠬ࿺").join(aargs[IJ6VkihabRm(u"࠵ᗛ"):])
	else: direction,ajpkWtS31Vuvf796UBcwiLE,qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࠫ࿻"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡔࡑࠧ࿼"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࠭࿽"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࠧ࿾")
	GjZltWoCxuIwNfQ7EH9(direction,HMO0QciekqVpLKmA(u"ࠧࠨ࿿"),ajpkWtS31Vuvf796UBcwiLE,p1lrNRIXqLQJznH6O(u"ࠨࠩက"),qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,**kkwargs)
	return
def C5JBeSxPzuskXi1ROnMHAmWp06dE7(*aargs,**kkwargs):
	direction = aargs[KbL94nDHufSF0VcO2Nk3(u"࠳ᗜ")]
	qasNMWopRQnAPUg9kbvSFBmY = aargs[uhOkAKtLVv4XTy1nWE6(u"࠵ᗝ")]
	DAIlM7BSQFKWfaNzc8R5e = aargs[xxpPYJOnoAUrlBzyveui(u"࠷ᗞ")]
	if DAIlM7BSQFKWfaNzc8R5e or qasNMWopRQnAPUg9kbvSFBmY: cIgUhuZ2TqRH8vQoWPS6ja = V391t7nQWUBR5euCkJ(u"ࡔࡳࡷࡨᜢ")
	else: cIgUhuZ2TqRH8vQoWPS6ja = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡇࡣ࡯ࡷࡪᜣ")
	qYF8frkpLDEO = aargs[v7reLlOXCgD5pZ14w2tUA(u"࠹ᗟ")]
	gq2FVNBUKPzIw1pZAnYHJG = aargs[p1lrNRIXqLQJznH6O(u"࠴ᗠ")]
	if not direction: direction = xxpPYJOnoAUrlBzyveui(u"ࠩࡦࡩࡳࡺࡥࡳࠩခ")
	if not qasNMWopRQnAPUg9kbvSFBmY: qasNMWopRQnAPUg9kbvSFBmY = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪ็้อࠠࠡࡐࡲࠫဂ")
	if not DAIlM7BSQFKWfaNzc8R5e: DAIlM7BSQFKWfaNzc8R5e = ddK4MmwpX5oG(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ဃ")
	if len(aargs)>=u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠸ᗢ"): gq2FVNBUKPzIw1pZAnYHJG += dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡢ࡮ࠨင")+aargs[iRTygNp4Lf36wQKlD2MHUhG7B(u"࠶ᗡ")]
	if len(aargs)>=f8PVRTseIuj9BckO6GoyF5Lxv(u"࠺ᗣ"): gq2FVNBUKPzIw1pZAnYHJG += gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭࡜࡯ࠩစ")+aargs[L91nVzxH4hYrgPDsOuljXd0J(u"࠺ᗤ")]
	FFwQqPEoCp = GjZltWoCxuIwNfQ7EH9(direction,qasNMWopRQnAPUg9kbvSFBmY,xxpPYJOnoAUrlBzyveui(u"ࠧࠨဆ"),DAIlM7BSQFKWfaNzc8R5e,qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,**kkwargs)
	if FFwQqPEoCp==-u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶ᗥ") and cIgUhuZ2TqRH8vQoWPS6ja: FFwQqPEoCp = -u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶ᗥ")
	elif FFwQqPEoCp==-p1lrNRIXqLQJznH6O(u"࠷ᗦ") and not cIgUhuZ2TqRH8vQoWPS6ja: FFwQqPEoCp = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡈࡤࡰࡸ࡫ᜤ")
	elif FFwQqPEoCp==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠰ᗧ"): FFwQqPEoCp = fcIm8tvxlXZsaEY3bwuG4B(u"ࡉࡥࡱࡹࡥᜥ")
	elif FFwQqPEoCp==dxAs4otSE98YmZnKy2iwRCB(u"࠳ᗨ"): FFwQqPEoCp = DKqQekNtF6WlJLhBP9M5ca(u"ࡘࡷࡻࡥᜦ")
	return FFwQqPEoCp
def ISveRUGKjgM9wqL6FZpsku0bB(*aargs,**kkwargs):
	return yOuHBDmPps3vd24cnLagiK0.Dialog().select(*aargs,**kkwargs)
def uFCykYQW68S(*aargs,**kkwargs):
	qYF8frkpLDEO = aargs[HMO0QciekqVpLKmA(u"࠲ᗩ")]
	gq2FVNBUKPzIw1pZAnYHJG = aargs[GGTRaYBDeNyI25zlF(u"࠴ᗪ")]
	if gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡶ࡬ࡱࡪ࠭ဇ") in list(kkwargs.keys()): XNMEqrFJkS = kkwargs[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡷ࡭ࡲ࡫ࠧဈ")]
	else: XNMEqrFJkS = V391t7nQWUBR5euCkJ(u"࠵࠵࠶࠰ᗫ")
	if len(aargs)>q0JfWbP8vACLxSNIncpOXkR6j(u"࠷ᗬ") and xxpPYJOnoAUrlBzyveui(u"ࠪࡸ࡮ࡳࡥࠨဉ") not in aargs[q0JfWbP8vACLxSNIncpOXkR6j(u"࠷ᗬ")]: profile = aargs[q0JfWbP8vACLxSNIncpOXkR6j(u"࠷ᗬ")]
	else: profile = ddK4MmwpX5oG(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪည")
	N3GkMR4dCtDFiJacqUjv = ocbOeyJvrhusDq72ZU4FmA(ddK4MmwpX5oG(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬဋ"),o76CsefkuZhcgDJlX,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧဌ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧ࠸࠴࠳ࡴࠬဍ"))
	image_filename = Q0MT56yqDcNnGk.replace(ddK4MmwpX5oG(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨဎ"),xxBJoKG54uwQ(u"ࠩࡢࠫဏ")+str(vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time())+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡣࠬတ"))
	image_filename = image_filename.replace(IJ6VkihabRm(u"ࠫࡡࡢࠧထ"),v7reLlOXCgD5pZ14w2tUA(u"ࠬࡢ࡜࡝࡞ࠪဒ")).replace(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭࠯࠰ࠩဓ"),KbL94nDHufSF0VcO2Nk3(u"ࠧ࠰࠱࠲࠳ࠬန"))
	image_height = wTRFaLkJX3nVH8CzcNMZG6pU7Pu2t(p1lrNRIXqLQJznH6O(u"ࠨࠩပ"),uhOkAKtLVv4XTy1nWE6(u"ࠩࠪဖ"),zOZvXaebGNwHKfjRA(u"ࠪࠫဗ"),qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,profile,qNZKwi2M1S4fBzGQYrmPnea(u"ࠫࡱ࡫ࡦࡵࠩဘ"),OARzhnB9o7uYvQGFaIcZ(u"ࡋࡧ࡬ࡴࡧᜧ"),image_filename)
	N3GkMR4dCtDFiJacqUjv.show()
	if profile==uhOkAKtLVv4XTy1nWE6(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭မ"):
		N3GkMR4dCtDFiJacqUjv.getControl(ZpH2IWt7veyFobTsAnhi41(u"࠹࠱࠶࠳ᗮ")).setHeight(fcIm8tvxlXZsaEY3bwuG4B(u"࠸࠱࠶ᗭ"))
		N3GkMR4dCtDFiJacqUjv.getControl(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠼࠴࠹࠶ᗱ")).setPosition(OARzhnB9o7uYvQGFaIcZ(u"࠶࠷ᗯ"),-xxpPYJOnoAUrlBzyveui(u"࠺࠳ᗰ"))
		N3GkMR4dCtDFiJacqUjv.getControl(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠽࠵࠻࠰ᗲ")).setPosition(GGTRaYBDeNyI25zlF(u"࠶࠸࠰ᗳ"),-Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠼࠰ᗴ"))
		N3GkMR4dCtDFiJacqUjv.getControl(v7reLlOXCgD5pZ14w2tUA(u"࠶࠳࠴ᗷ")).setPosition(KbL94nDHufSF0VcO2Nk3(u"࠹࠱ᗵ"),-fcIm8tvxlXZsaEY3bwuG4B(u"࠴࠷ᗶ"))
	N3GkMR4dCtDFiJacqUjv.getControl(V391t7nQWUBR5euCkJ(u"࠷࠴࠶ᗸ")).setVisible(uhOkAKtLVv4XTy1nWE6(u"ࡌࡡ࡭ࡵࡨᜨ"))
	N3GkMR4dCtDFiJacqUjv.getControl(L91nVzxH4hYrgPDsOuljXd0J(u"࠸࠵࠸ᗹ")).setVisible(Vv0lSjAOHLfMnam3wtdor(u"ࡆࡢ࡮ࡶࡩᜩ"))
	N3GkMR4dCtDFiJacqUjv.getControl(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠾࠶࠵࠱ᗺ")).setImage(image_filename)
	N3GkMR4dCtDFiJacqUjv.getControl(qNZKwi2M1S4fBzGQYrmPnea(u"࠿࠰࠶࠲ᗻ")).setHeight(image_height)
	PFwTfcL1r0eS3VqH9GmQkY2hx = nt0ApgWuodKimeTxcNVLEs4U.Thread(target=Xpbe6cdq5DCfhN8n9QklESmI7L,args=(N3GkMR4dCtDFiJacqUjv,image_filename,XNMEqrFJkS))
	PFwTfcL1r0eS3VqH9GmQkY2hx.start()
	return
def Xpbe6cdq5DCfhN8n9QklESmI7L(N3GkMR4dCtDFiJacqUjv,image_filename,XNMEqrFJkS):
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(XNMEqrFJkS//tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠱࠱࠲࠳࠲࠵ᗼ"))
	vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(HMO0QciekqVpLKmA(u"࠱࠰࠴࠴࠵ᗽ"))
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(image_filename):
		try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(image_filename)
		except: pass
	return
def BwEG5gzkVsJcCRaQyhX4IqSHx0lnO(*aargs,**kkwargs):
	qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,profile,direction = DKqQekNtF6WlJLhBP9M5ca(u"࠭ࠧယ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࠨရ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩလ"),xxBJoKG54uwQ(u"ࠩ࡯ࡩ࡫ࡺࠧဝ")
	if len(aargs)>=zOZvXaebGNwHKfjRA(u"࠳ᗾ"): qYF8frkpLDEO = aargs[DKqQekNtF6WlJLhBP9M5ca(u"࠳ᗿ")]
	if len(aargs)>=xxpPYJOnoAUrlBzyveui(u"࠷ᘁ"): gq2FVNBUKPzIw1pZAnYHJG = aargs[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠵ᘀ")]
	if len(aargs)>=IJ6VkihabRm(u"࠹ᘂ"): profile = aargs[ZpH2IWt7veyFobTsAnhi41(u"࠲ᘃ")]
	if len(aargs)>=f8PVRTseIuj9BckO6GoyF5Lxv(u"࠶ᘅ"): direction = aargs[OARzhnB9o7uYvQGFaIcZ(u"࠴ᘄ")]
	return qQL7e23RtCg4xOpf(direction,qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,profile)
def r4PGXcF6oTdYiMQ9jwn01SmUp(*aargs,**kkwargs):
	return yOuHBDmPps3vd24cnLagiK0.Dialog().contextmenu(*aargs,**kkwargs)
def kHM96EzbxfBc3giF4CeIU(*aargs,**kkwargs):
	return yOuHBDmPps3vd24cnLagiK0.Dialog().browseSingle(*aargs,**kkwargs)
def kVtL26DzXNPoB3aehscng4rJ9bICqj(*aargs,**kkwargs):
	return yOuHBDmPps3vd24cnLagiK0.Dialog().input(*aargs,**kkwargs)
def zzyalh3A275njbIKsD0EQ(*aargs,**kkwargs):
	return yOuHBDmPps3vd24cnLagiK0.DialogProgress(*aargs,**kkwargs)
def aarhp43yvIqojdnWs6Sb(Hycjun1sgXaYWxibE5):
	if LRjqrQYBXFVPfu>vkMRnTNV9jFm(u"࠴࠻࠳࠿࠹ᘆ"): N3GkMR4dCtDFiJacqUjv = v7reLlOXCgD5pZ14w2tUA(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨသ")
	else: N3GkMR4dCtDFiJacqUjv = xxBJoKG54uwQ(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨဟ")
	Hycjun1sgXaYWxibE5 = Hycjun1sgXaYWxibE5.lower()
	if Hycjun1sgXaYWxibE5==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡹࡴࡢࡴࡷࠫဠ"): AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨအ")+N3GkMR4dCtDFiJacqUjv+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࠪࠩဢ"))
	elif Hycjun1sgXaYWxibE5==ddK4MmwpX5oG(u"ࠨࡵࡷࡳࡵ࠭ဣ"): AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩဤ")+N3GkMR4dCtDFiJacqUjv+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪ࠭ࠬဥ"))
	return
def GjZltWoCxuIwNfQ7EH9(direction,button0=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࠬဦ"),button1=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬ࠭ဧ"),button2=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠧဨ"),qYF8frkpLDEO=KbL94nDHufSF0VcO2Nk3(u"ࠧࠨဩ"),gq2FVNBUKPzIw1pZAnYHJG=DDS79jdWzLtE(u"ࠨࠩဪ"),profile=zOZvXaebGNwHKfjRA(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫါ"),lcsdaUL4oCkPQeE3b5SxX82fuFiZH=q0JfWbP8vACLxSNIncpOXkR6j(u"࠴ᘇ"),zXDEWbA1wOy4N9YvGfsF=q0JfWbP8vACLxSNIncpOXkR6j(u"࠴ᘇ")):
	if not direction: direction = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡧࡪࡴࡴࡦࡴࠪာ")
	N3GkMR4dCtDFiJacqUjv = aMeyPB6AZUTC(KbL94nDHufSF0VcO2Nk3(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ိ"),o76CsefkuZhcgDJlX,ddK4MmwpX5oG(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ီ"),V391t7nQWUBR5euCkJ(u"࠭࠷࠳࠲ࡳࠫု"))
	N3GkMR4dCtDFiJacqUjv.jjWdipx8KzI(button0,button1,button2,qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,profile,direction,lcsdaUL4oCkPQeE3b5SxX82fuFiZH,zXDEWbA1wOy4N9YvGfsF)
	if lcsdaUL4oCkPQeE3b5SxX82fuFiZH>Vv0lSjAOHLfMnam3wtdor(u"࠵ᘈ"): N3GkMR4dCtDFiJacqUjv.WXaGyudmFB9DUE3vT60r()
	if zXDEWbA1wOy4N9YvGfsF>q0JfWbP8vACLxSNIncpOXkR6j(u"࠶ᘉ"): N3GkMR4dCtDFiJacqUjv.XF1C6ruN9bKpPndc3kIZ()
	if lcsdaUL4oCkPQeE3b5SxX82fuFiZH==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠰ᘊ") and zXDEWbA1wOy4N9YvGfsF==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠰ᘊ"): N3GkMR4dCtDFiJacqUjv.DS2CbsYxLQUdzGfW7tjIEwhqM3()
	N3GkMR4dCtDFiJacqUjv.doModal()
	FFwQqPEoCp = N3GkMR4dCtDFiJacqUjv.choiceID
	return FFwQqPEoCp
def qQL7e23RtCg4xOpf(direction,qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,profile=fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨူ")):
	if not direction: direction = zOZvXaebGNwHKfjRA(u"ࠨ࡮ࡨࡪࡹ࠭ေ")
	N3GkMR4dCtDFiJacqUjv = ocbOeyJvrhusDq72ZU4FmA(qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬဲ"),o76CsefkuZhcgDJlX,L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫဳ"),vkMRnTNV9jFm(u"ࠫ࠼࠸࠰ࡱࠩဴ"))
	image_filename = Q0MT56yqDcNnGk.replace(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬဵ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭࡟ࠨံ")+str(vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time())+xxpPYJOnoAUrlBzyveui(u"ࠧࡠ့ࠩ"))
	image_filename = image_filename.replace(ZpH2IWt7veyFobTsAnhi41(u"ࠨ࡞࡟ࠫး"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩ࡟ࡠࡡࡢ္ࠧ")).replace(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪ࠳࠴်࠭"),OARzhnB9o7uYvQGFaIcZ(u"ࠫ࠴࠵࠯࠰ࠩျ"))
	image_height = wTRFaLkJX3nVH8CzcNMZG6pU7Pu2t(DKqQekNtF6WlJLhBP9M5ca(u"ࠬ࠭ြ"),ZpH2IWt7veyFobTsAnhi41(u"࠭ࠧွ"),HMO0QciekqVpLKmA(u"ࠧࠨှ"),qYF8frkpLDEO,gq2FVNBUKPzIw1pZAnYHJG,profile,direction,L91nVzxH4hYrgPDsOuljXd0J(u"ࡇࡣ࡯ࡷࡪᜪ"),image_filename)
	N3GkMR4dCtDFiJacqUjv.show()
	N3GkMR4dCtDFiJacqUjv.getControl(L91nVzxH4hYrgPDsOuljXd0J(u"࠺࠲࠸࠴ᘋ")).setHeight(image_height)
	N3GkMR4dCtDFiJacqUjv.getControl(uhOkAKtLVv4XTy1nWE6(u"࠻࠳࠹࠵ᘌ")).setImage(image_filename)
	XkmDQevS23waz0pfAJ5KYHUVTG = N3GkMR4dCtDFiJacqUjv.doModal()
	try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(image_filename)
	except: pass
	return XkmDQevS23waz0pfAJ5KYHUVTG
def yWgZFzdaNR5iw6m8Q9G7CL(NnOmb0tFDw6SucIfr3UAo=v7reLlOXCgD5pZ14w2tUA(u"ࡖࡵࡹࡪᜫ")):
	if NnOmb0tFDw6SucIfr3UAo:
		oOM6fji0UV3Yn2 = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡵࡷࡶࠬဿ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ၀"),DDS79jdWzLtE(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭၁"))
		if oOM6fji0UV3Yn2: return oOM6fji0UV3Yn2
	gq2FVNBUKPzIw1pZAnYHJG = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࠬ၂")
	if gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠳ᘍ") and djr0g3VkMzo1ehxE.succeeded:
		RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
		KDxoah0WRdY1 = RkLE6BzZ2KX.count(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭၃"))
		if KDxoah0WRdY1>uhOkAKtLVv4XTy1nWE6(u"࠼࠵ᘎ"):
			gq2FVNBUKPzIw1pZAnYHJG = QPuHKNAT4jmCRg.findall(DDS79jdWzLtE(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၄"),RkLE6BzZ2KX,QPuHKNAT4jmCRg.DOTALL)
			gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG[ZpH2IWt7veyFobTsAnhi41(u"࠵ᘏ")]
	if not gq2FVNBUKPzIw1pZAnYHJG:
		RBUV0oHIyW25NsgdKme = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,OARzhnB9o7uYvQGFaIcZ(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭၅"),Vv0lSjAOHLfMnam3wtdor(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩ၆"))
		gq2FVNBUKPzIw1pZAnYHJG = open(RBUV0oHIyW25NsgdKme,zOZvXaebGNwHKfjRA(u"ࠩࡵࡦࠬ၇")).read()
		if Nnxm30dfoBWRYpIC7KsQGl: gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.decode(v7reLlOXCgD5pZ14w2tUA(u"ࠪࡹࡹ࡬࠸ࠨ၈"))
		gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.replace(dxAs4otSE98YmZnKy2iwRCB(u"ࠫࡡࡸࠧ၉"),ddK4MmwpX5oG(u"ࠬ࠭၊"))
	D4MeOU9THZt1YwjW = QPuHKNAT4jmCRg.findall(qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧ။"),gq2FVNBUKPzIw1pZAnYHJG,QPuHKNAT4jmCRg.DOTALL)
	ZZV1aU5NIohWyQmKHSrtfzOjMe6R = []
	for dJEmG7MFDQfxks9 in D4MeOU9THZt1YwjW:
		A1AF5JLQb6chsfuyEZRUCVnzlxt9gd = dJEmG7MFDQfxks9.lower()
		if ddK4MmwpX5oG(u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨ၌") in A1AF5JLQb6chsfuyEZRUCVnzlxt9gd: continue
		if DDS79jdWzLtE(u"ࠨࡷࡥࡹࡳࡺࡵࠨ၍") in A1AF5JLQb6chsfuyEZRUCVnzlxt9gd: continue
		if DKqQekNtF6WlJLhBP9M5ca(u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩ၎") in A1AF5JLQb6chsfuyEZRUCVnzlxt9gd: continue
		if qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡧࡷࡵࡳࠨ၏") in A1AF5JLQb6chsfuyEZRUCVnzlxt9gd: continue
		ZZV1aU5NIohWyQmKHSrtfzOjMe6R.append(dJEmG7MFDQfxks9)
	oOM6fji0UV3Yn2 = KRjfaduUhzsPg6I1.sample(ZZV1aU5NIohWyQmKHSrtfzOjMe6R,KbL94nDHufSF0VcO2Nk3(u"࠷ᘐ"))
	oOM6fji0UV3Yn2 = oOM6fji0UV3Yn2[q0JfWbP8vACLxSNIncpOXkR6j(u"࠰ᘑ")]
	mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧၐ"),L91nVzxH4hYrgPDsOuljXd0J(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨၑ"),oOM6fji0UV3Yn2,t7rXIzJfMLWRwaDeKhTq4C6dG)
	return oOM6fji0UV3Yn2
def ETVMAFtlKdgY5WO3Uz6wNnPs8(CeJXk5gb27o=lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࠧၒ")):
	if not CeJXk5gb27o: CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
	if CeJXk5gb27o!=IJ6VkihabRm(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪၓ"): GJtcqTv68ZQpwxYFiDg.stderr.write(CeJXk5gb27o)
	I7Q0GxoOc5ECkY6zfjhg = CeJXk5gb27o.splitlines()
	ezX76WkqKRxdtsvh = I7Q0GxoOc5ECkY6zfjhg[-xxBJoKG54uwQ(u"࠲ᘒ")]
	tdvTbF0J6EBgaCqoNc = open(ZFyXrxgYWeMS3RGsD670pb,vkMRnTNV9jFm(u"ࠨࡴࡥࠫၔ")).read()
	if Nnxm30dfoBWRYpIC7KsQGl: tdvTbF0J6EBgaCqoNc = tdvTbF0J6EBgaCqoNc.decode(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡸࡸ࡫࠾ࠧၕ"))
	tdvTbF0J6EBgaCqoNc = tdvTbF0J6EBgaCqoNc[-KbL94nDHufSF0VcO2Nk3(u"࠺࠳࠴࠵ᘓ"):]
	JJGN7qxBnbcP = zOZvXaebGNwHKfjRA(u"ࠪࡁࠬၖ")*HMO0QciekqVpLKmA(u"࠴࠴࠵ᘔ")
	if JJGN7qxBnbcP in tdvTbF0J6EBgaCqoNc: tdvTbF0J6EBgaCqoNc = tdvTbF0J6EBgaCqoNc.rsplit(JJGN7qxBnbcP,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠵ᘕ"))[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠵ᘕ")]
	if ezX76WkqKRxdtsvh in tdvTbF0J6EBgaCqoNc: tdvTbF0J6EBgaCqoNc = tdvTbF0J6EBgaCqoNc.rsplit(ezX76WkqKRxdtsvh,v7reLlOXCgD5pZ14w2tUA(u"࠶ᘖ"))[fcIm8tvxlXZsaEY3bwuG4B(u"࠶ᘗ")]
	FFxGIsEMpquf6 = QPuHKNAT4jmCRg.findall(zOZvXaebGNwHKfjRA(u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪၗ"),tdvTbF0J6EBgaCqoNc,QPuHKNAT4jmCRg.DOTALL)
	for y5BUqEeWNn,oBQqw316KAIpOdr7R0LxkZNW5lG4y in reversed(FFxGIsEMpquf6):
		if oBQqw316KAIpOdr7R0LxkZNW5lG4y: break
	else: oBQqw316KAIpOdr7R0LxkZNW5lG4y = Vv0lSjAOHLfMnam3wtdor(u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬၘ")
	AeX8tIu4jVHh9p6STsFBq57KrmxU,dJEmG7MFDQfxks9,xamBlEfohPg1nzw3SRQisLG = f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࠧၙ"),vkMRnTNV9jFm(u"ࠧࠨၚ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨࠩၛ")
	qR8NUBG1TchkHrngbOz76FDQCtKZA = KbL94nDHufSF0VcO2Nk3(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽ร࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬၜ")+ezX76WkqKRxdtsvh
	JohnQtKE9Gry14FwfgM = ZpH2IWt7veyFobTsAnhi41(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ีะำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၝ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y
	for vuVtHOK0qWfowByzGiYJQsMeRDx in reversed(I7Q0GxoOc5ECkY6zfjhg):
		if ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫၞ") in vuVtHOK0qWfowByzGiYJQsMeRDx and v7reLlOXCgD5pZ14w2tUA(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫၟ") in vuVtHOK0qWfowByzGiYJQsMeRDx: break
	vuVtHOK0qWfowByzGiYJQsMeRDx = QPuHKNAT4jmCRg.findall(V391t7nQWUBR5euCkJ(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩၠ"),vuVtHOK0qWfowByzGiYJQsMeRDx,QPuHKNAT4jmCRg.DOTALL)
	if vuVtHOK0qWfowByzGiYJQsMeRDx:
		AeX8tIu4jVHh9p6STsFBq57KrmxU,dJEmG7MFDQfxks9,xamBlEfohPg1nzw3SRQisLG = vuVtHOK0qWfowByzGiYJQsMeRDx[d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠰ᘘ")]
		if p1lrNRIXqLQJznH6O(u"ࠧ࠰ࠩၡ") in AeX8tIu4jVHh9p6STsFBq57KrmxU: AeX8tIu4jVHh9p6STsFBq57KrmxU = AeX8tIu4jVHh9p6STsFBq57KrmxU.rsplit(vkMRnTNV9jFm(u"ࠨ࠱ࠪၢ"),IJ6VkihabRm(u"࠲ᘙ"))[IJ6VkihabRm(u"࠲ᘙ")]
		else: AeX8tIu4jVHh9p6STsFBq57KrmxU = AeX8tIu4jVHh9p6STsFBq57KrmxU.rsplit(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࡟ࡠࠬၣ"),OARzhnB9o7uYvQGFaIcZ(u"࠳ᘚ"))[OARzhnB9o7uYvQGFaIcZ(u"࠳ᘚ")]
		ZwhRkzb3ueXD4 = DDS79jdWzLtE(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ไโ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၤ")+AeX8tIu4jVHh9p6STsFBq57KrmxU
		BJm24Kg9fPDeWipynFohuj = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำุำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၥ")+dJEmG7MFDQfxks9
		I45fTYKnQL2N7lzOthmFP0eAkya96 = qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๅส๊࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၦ")+xamBlEfohPg1nzw3SRQisLG
		ApaZ4kBdDSwyL0oXj9NiO = ZwhRkzb3ueXD4+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭࡜࡯ࠩၧ")+BJm24Kg9fPDeWipynFohuj+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧ࡝ࡰࠪၨ")+I45fTYKnQL2N7lzOthmFP0eAkya96+KbL94nDHufSF0VcO2Nk3(u"ࠨ࡞ࡱࠫၩ")+JohnQtKE9Gry14FwfgM+xxBJoKG54uwQ(u"ࠩ࡟ࡲࠬၪ")+qR8NUBG1TchkHrngbOz76FDQCtKZA
		AWsMm0gK6vLqDoEUHBp5YFd7b1wli = BJm24Kg9fPDeWipynFohuj+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡠࡳ࠭ၫ")+JohnQtKE9Gry14FwfgM+OARzhnB9o7uYvQGFaIcZ(u"ࠫࡡࡴࠧၬ")+qR8NUBG1TchkHrngbOz76FDQCtKZA+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࡢ࡮ࠨၭ")+ZwhRkzb3ueXD4+IJ6VkihabRm(u"࠭࡜࡯ࠩၮ")+I45fTYKnQL2N7lzOthmFP0eAkya96
		ZGltHXfR1nUqsCvc3xY74 = BJm24Kg9fPDeWipynFohuj+HMO0QciekqVpLKmA(u"ࠧ࡝ࡰࠪၯ")+qR8NUBG1TchkHrngbOz76FDQCtKZA+V391t7nQWUBR5euCkJ(u"ࠨ࡞ࡱࠫၰ")+ZwhRkzb3ueXD4+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩ࡟ࡲࠬၱ")+I45fTYKnQL2N7lzOthmFP0eAkya96
	else:
		ZwhRkzb3ueXD4,BJm24Kg9fPDeWipynFohuj,I45fTYKnQL2N7lzOthmFP0eAkya96 = xxBJoKG54uwQ(u"ࠪࠫၲ"),uhOkAKtLVv4XTy1nWE6(u"ࠫࠬၳ"),V391t7nQWUBR5euCkJ(u"ࠬ࠭ၴ")
		ApaZ4kBdDSwyL0oXj9NiO = JohnQtKE9Gry14FwfgM+vkMRnTNV9jFm(u"࠭࡜࡯࡞ࡱࠫၵ")+qR8NUBG1TchkHrngbOz76FDQCtKZA
		AWsMm0gK6vLqDoEUHBp5YFd7b1wli = JohnQtKE9Gry14FwfgM+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧ࡝ࡰ࡟ࡲࠬၶ")+qR8NUBG1TchkHrngbOz76FDQCtKZA
		ZGltHXfR1nUqsCvc3xY74 = qR8NUBG1TchkHrngbOz76FDQCtKZA
	n1cgIBZ0eYrNC4bktzASU = DDS79jdWzLtE(u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬၷ")+vkMRnTNV9jFm(u"ࠩ࡟ࡲࠬၸ")
	pHFTt5UYjQAI = NNK2SqgVPy()
	HnkgLX5s8GtdNybAICpaVZDMc = []
	RRMWBwU6pG = pHFTt5UYjQAI[fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨၹ")]
	QM8XmHE5VeP = XQCSoqYpy2EAu6J(uVp7krjL48oWd3tqGYCRz5M)
	if gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၺ") in list(pHFTt5UYjQAI.keys()):
		for LHOA6hkrq47JzTQ85ZnUu,OgLr1D6ZnuphIFETK2f0bmMCjcl5,cc8Il7HmGas in RRMWBwU6pG: HnkgLX5s8GtdNybAICpaVZDMc = max(HnkgLX5s8GtdNybAICpaVZDMc,OgLr1D6ZnuphIFETK2f0bmMCjcl5)
		if QM8XmHE5VeP<HnkgLX5s8GtdNybAICpaVZDMc:
			qYF8frkpLDEO = OARzhnB9o7uYvQGFaIcZ(u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨၻ")
			FFwQqPEoCp = GjZltWoCxuIwNfQ7EH9(L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࡲࡪࡩ࡫ࡸࠬၼ"),uhOkAKtLVv4XTy1nWE6(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫၽ"),KbL94nDHufSF0VcO2Nk3(u"ࠨฬะำ๏ัࠧၾ"),GGTRaYBDeNyI25zlF(u"ࠩัีําࠧၿ"),n1cgIBZ0eYrNC4bktzASU+qYF8frkpLDEO,ApaZ4kBdDSwyL0oXj9NiO)
			if FFwQqPEoCp==DDS79jdWzLtE(u"࠳ᘛ"):
				T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(p1lrNRIXqLQJznH6O(u"ࠪࡧࡪࡴࡴࡦࡴࠪႀ"),zOZvXaebGNwHKfjRA(u"ࠫำื่อࠩႁ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬะอะ์ฮࠫႂ"),OARzhnB9o7uYvQGFaIcZ(u"࠭ࠧႃ"),qYF8frkpLDEO)
				if T4TGmZ9XWAzONaKygic==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵ᘜ"): FFwQqPEoCp = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵ᘜ")
			if FFwQqPEoCp==p1lrNRIXqLQJznH6O(u"࠶ᘝ"):
				import IFHE2MSfi5
				IFHE2MSfi5.QpwoVDjc2Kir4GtfEuyJkUzX5YsR(qNZKwi2M1S4fBzGQYrmPnea(u"ࡗࡶࡺ࡫ᜬ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࡗࡶࡺ࡫ᜬ"))
			return
	eCvz0lBFjb18PMJAfqKipGNROU = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࡭࡫ࡶࡸࠬႄ"),HMO0QciekqVpLKmA(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫႅ"),OARzhnB9o7uYvQGFaIcZ(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫႆ"))
	if not eCvz0lBFjb18PMJAfqKipGNROU: eCvz0lBFjb18PMJAfqKipGNROU = []
	AWsMm0gK6vLqDoEUHBp5YFd7b1wli = AWsMm0gK6vLqDoEUHBp5YFd7b1wli.replace(v7reLlOXCgD5pZ14w2tUA(u"ࠪࡠࡳ࠭ႇ"),zOZvXaebGNwHKfjRA(u"ࠫࡡࡢ࡮ࠨႈ")).replace(KbL94nDHufSF0VcO2Nk3(u"ࠬࡡࡒࡕࡎࡠࠫႉ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧႊ")).replace(vkMRnTNV9jFm(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪႋ"),p1lrNRIXqLQJznH6O(u"ࠨࠩႌ")).replace(GGTRaYBDeNyI25zlF(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠႍࠫ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࠫႎ"))
	ZGltHXfR1nUqsCvc3xY74 = ZGltHXfR1nUqsCvc3xY74.replace(zOZvXaebGNwHKfjRA(u"ࠫࡡࡴࠧႏ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡢ࡜࡯ࠩ႐")).replace(p1lrNRIXqLQJznH6O(u"࡛࠭ࡓࡖࡏࡡࠬ႑"),DDS79jdWzLtE(u"ࠧࠨ႒")).replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ႓"),xxpPYJOnoAUrlBzyveui(u"ࠩࠪ႔")).replace(KbL94nDHufSF0VcO2Nk3(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ႕"),xxpPYJOnoAUrlBzyveui(u"ࠫࠬ႖"))
	GGkagUEKqmZwSQHo = uVp7krjL48oWd3tqGYCRz5M+uhOkAKtLVv4XTy1nWE6(u"ࠬࡀ࠺ࠨ႗")+ZGltHXfR1nUqsCvc3xY74
	if GGkagUEKqmZwSQHo in eCvz0lBFjb18PMJAfqKipGNROU:
		qYF8frkpLDEO = IJ6VkihabRm(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ႘")
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(DDS79jdWzLtE(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭႙"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࠩႚ"),n1cgIBZ0eYrNC4bktzASU+qYF8frkpLDEO,ApaZ4kBdDSwyL0oXj9NiO)
		return
	EFQABIYqL5k8Mph2ViSnyv = str(LRjqrQYBXFVPfu).split(KbL94nDHufSF0VcO2Nk3(u"ࠩ࠱ࠫႛ"))[Vv0lSjAOHLfMnam3wtdor(u"࠶ᘞ")]
	DDRulV7aKN3jCOWSBQkb95 = EGcFon0zR4mSL1[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪႜ")][DKqQekNtF6WlJLhBP9M5ca(u"࠶ᘟ")]
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,V391t7nQWUBR5euCkJ(u"ࠫࡕࡕࡓࡕࠩႝ"),DDRulV7aKN3jCOWSBQkb95,V391t7nQWUBR5euCkJ(u"ࠬ࠭႞"),L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠧ႟"),vkMRnTNV9jFm(u"ࠧࠨႠ"),ZpH2IWt7veyFobTsAnhi41(u"ࠨࠩႡ"),Vv0lSjAOHLfMnam3wtdor(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪႢ"),OARzhnB9o7uYvQGFaIcZ(u"ࡊࡦࡲࡳࡦᜭ"),OARzhnB9o7uYvQGFaIcZ(u"ࡊࡦࡲࡳࡦᜭ"))
	RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
	qGo2mOSTinwP = QPuHKNAT4jmCRg.findall(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪႣ"),RkLE6BzZ2KX,QPuHKNAT4jmCRg.DOTALL)
	for vowl0neIXiT92,lbsCrBaqxHp9VXI0,vCjfhunZrBb4iALs0Jdx,DAIU58gJVWc73dsHpxvkf in qGo2mOSTinwP:
		vowl0neIXiT92 = vowl0neIXiT92.split(qNZKwi2M1S4fBzGQYrmPnea(u"ࠫ࠰࠭Ⴄ"))
		vCjfhunZrBb4iALs0Jdx = vCjfhunZrBb4iALs0Jdx.split(v7reLlOXCgD5pZ14w2tUA(u"ࠬ࠱ࠧႥ"))
		DAIU58gJVWc73dsHpxvkf = DAIU58gJVWc73dsHpxvkf.split(dxAs4otSE98YmZnKy2iwRCB(u"࠭ࠫࠨႦ"))
		if dJEmG7MFDQfxks9 in vowl0neIXiT92 and ezX76WkqKRxdtsvh==lbsCrBaqxHp9VXI0 and uVp7krjL48oWd3tqGYCRz5M in vCjfhunZrBb4iALs0Jdx and EFQABIYqL5k8Mph2ViSnyv in DAIU58gJVWc73dsHpxvkf:
			qYF8frkpLDEO = v7reLlOXCgD5pZ14w2tUA(u"่ࠧาสࠤฬ๊ฮุล้ࠣ฾ื่โ๋ࠢื๏฿วๅฮࠣฬฬ๊ลึัสีࠥอไใษา้ࠬႧ")
			T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡴ࡬࡫࡭ࡺࠧႨ"),zOZvXaebGNwHKfjRA(u"ࠩัีําࠧႩ"),V391t7nQWUBR5euCkJ(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧႪ"),n1cgIBZ0eYrNC4bktzASU+qYF8frkpLDEO,ApaZ4kBdDSwyL0oXj9NiO)
			if T4TGmZ9XWAzONaKygic==xxBJoKG54uwQ(u"࠲ᘠ"): qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႫ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠬ࠭Ⴌ"),GGTRaYBDeNyI25zlF(u"࠭ࠧႭ"),qYF8frkpLDEO)
			return
	qYF8frkpLDEO = uhOkAKtLVv4XTy1nWE6(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧႮ")
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡴ࡬࡫࡭ࡺࠧႯ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭Ⴐ"),n1cgIBZ0eYrNC4bktzASU+qYF8frkpLDEO,ApaZ4kBdDSwyL0oXj9NiO)
	T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡧࡪࡴࡴࡦࡴࠪႱ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࠬႲ"),p1lrNRIXqLQJznH6O(u"ࠬ࠭Ⴓ"),DKqQekNtF6WlJLhBP9M5ca(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႴ"),DDS79jdWzLtE(u"ࠧิ๊ไࠤ๏ะๅࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏฿ัโࠢส่๊ฮัๆฮࠣว๏์้ࠠ็อํࠥ๎ใ๋ใࠣ์้๋วัษࠣัฺ๊ส้ࠡำ๋ࠥอไๆึๆ่ฮࠦไฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠤํ๊วࠡ์ึฮ฼๐ูࠡษุ่ฬำࠠๆึๆ่ฮ่่๊่ࠦࠣฬฺ๊ࠦำไࠤ่๐แฺ๊ࠡีฯ่ࠦๅ็สิฬุ่ࠦำอࠤํ๋ส๊ࠢ฻๋ึะ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ࠴่ࠠๆࠣฮึ๐ฯࠡลิืฬ๊ࠠศๆึะ้ࠦฟࠨႵ"))
	if T4TGmZ9XWAzONaKygic==Vv0lSjAOHLfMnam3wtdor(u"࠳ᘡ"): RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h = IJ6VkihabRm(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫႶ")
	else:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(vkMRnTNV9jFm(u"ࠩࡦࡩࡳࡺࡥࡳࠩႷ"),GGTRaYBDeNyI25zlF(u"ࠪࠫႸ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႹ"),GGTRaYBDeNyI25zlF(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤส฻ไศฯࠣห้ิืฤࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥอไั์้่ࠣะ่ษࠢไ๎์ࠦฬๆ์฼ࠤฯ็วึ์็ࠤ์ึวࠡษ็า฼ษ้ࠠ฼ํี์ࠦๅ็ࠢส่ศิืศรࠪႺ"))
		return
	hTZjiRxwmYoWpKtJIHVug36G = AWsMm0gK6vLqDoEUHBp5YFd7b1wli
	from IFHE2MSfi5 import xWaZr7lMs6teC8
	BcMl3XdLS0zmK1jPvDJANfYH = xWaZr7lMs6teC8(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࡅࡳࡴࡲࡶࡸ࠭Ⴛ"),hTZjiRxwmYoWpKtJIHVug36G,V391t7nQWUBR5euCkJ(u"࡙ࡸࡵࡦᜮ"),dxAs4otSE98YmZnKy2iwRCB(u"ࠧࠨႼ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨႽ"),RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h)
	if BcMl3XdLS0zmK1jPvDJANfYH and RSp5Lwm2Ki6Cxq34F1WekMvzPQ0j8h:
		eCvz0lBFjb18PMJAfqKipGNROU.append(GGkagUEKqmZwSQHo)
		mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,zOZvXaebGNwHKfjRA(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬႾ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬႿ"),eCvz0lBFjb18PMJAfqKipGNROU,VYn9o683LCcspE7Jew5gMQrZbj)
	return
def rCB8xbUpQ3Wqa1YF(ZEJAFRNxIrQSU):
	if Nnxm30dfoBWRYpIC7KsQGl: ZEJAFRNxIrQSU = ZEJAFRNxIrQSU.encode(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡺࡺࡦ࠹ࠩჀ"))
	l0uAW3wIvSC = xxBJoKG54uwQ(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬჁ")+str(vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time())+IJ6VkihabRm(u"࠭࠮ࡥࡣࡷࠫჂ")
	open(l0uAW3wIvSC,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡸࡤࠪჃ")).write(ZEJAFRNxIrQSU)
	return
def L19zfOaM6iKrnFUjSxQJ5dN(aq06Wbp7PVnGxrw3ZANXvLkDyK9):
	if aq06Wbp7PVnGxrw3ZANXvLkDyK9:
		IR6EdvxHspW9GrFlbymXq = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ࡮࡬ࡷࡹ࠭Ⴤ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬჅ"),GGTRaYBDeNyI25zlF(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭჆"))
		if IR6EdvxHspW9GrFlbymXq: return IR6EdvxHspW9GrFlbymXq
	DDRulV7aKN3jCOWSBQkb95 = EGcFon0zR4mSL1[zOZvXaebGNwHKfjRA(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫჇ")][vkMRnTNV9jFm(u"࠸ᘢ")]
	wn0kd1pEgfSy4YG = Dx3jCK6X7lktdiE(f8PVRTseIuj9BckO6GoyF5Lxv(u"࠷࠷ᘣ"),aq06Wbp7PVnGxrw3ZANXvLkDyK9)
	PPFwCokDceHzlibVnvsNUMgfyEau = tRibZg70df5IVmvGWwAXuM14lncz()
	opOrMkINsZbSfcP8wYRzayFt = PPFwCokDceHzlibVnvsNUMgfyEau.split(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࠲ࠧ჈"))[xxpPYJOnoAUrlBzyveui(u"࠷ᘤ")]
	cRYSn9hOXfyTW3bVirFwvKL61s = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ჉"))
	NlwZ7X0p9jRJut48UdQmce6qy5HL = poQSnU831cKyYaW9IMfeFt2g()
	G2fV3SCnXjM9F0Qrpd7t = {a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡶࡵࡨࡶࠬ჊"):wn0kd1pEgfSy4YG,uhOkAKtLVv4XTy1nWE6(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ჋"):uVp7krjL48oWd3tqGYCRz5M,fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ჌"):opOrMkINsZbSfcP8wYRzayFt,DKqQekNtF6WlJLhBP9M5ca(u"ࠪ࡭ࡩࡹࠧჍ"):AkEMLcQGwo0qnlB8VJeKiUTpX(NlwZ7X0p9jRJut48UdQmce6qy5HL)}
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡕࡕࡓࡕࠩ჎"),DDRulV7aKN3jCOWSBQkb95,G2fV3SCnXjM9F0Qrpd7t,uhOkAKtLVv4XTy1nWE6(u"ࠬ࠭჏"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࠧა"),IJ6VkihabRm(u"ࠧࠨბ"),HMO0QciekqVpLKmA(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭გ"))
	IR6EdvxHspW9GrFlbymXq = []
	if djr0g3VkMzo1ehxE.succeeded:
		RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
		IR6EdvxHspW9GrFlbymXq = RkLE6BzZ2KX.replace(DKqQekNtF6WlJLhBP9M5ca(u"ࠩ࡟ࡠࡷ࠭დ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࡠࡳ࠭ე")).replace(Vv0lSjAOHLfMnam3wtdor(u"ࠫࡡࡢ࡮ࠨვ"),uhOkAKtLVv4XTy1nWE6(u"ࠬࡢ࡮ࠨზ")).replace(DDS79jdWzLtE(u"࠭࡜ࡳ࡞ࡱࠫთ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠧ࡝ࡰࠪი")).replace(V391t7nQWUBR5euCkJ(u"ࠨ࡞ࡵࠫკ"),Vv0lSjAOHLfMnam3wtdor(u"ࠩ࡟ࡲࠬლ"))
		IR6EdvxHspW9GrFlbymXq = QPuHKNAT4jmCRg.findall(DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭მ"),IR6EdvxHspW9GrFlbymXq,QPuHKNAT4jmCRg.DOTALL)
		if IR6EdvxHspW9GrFlbymXq:
			IR6EdvxHspW9GrFlbymXq = sorted(IR6EdvxHspW9GrFlbymXq,reverse=OARzhnB9o7uYvQGFaIcZ(u"ࡌࡡ࡭ࡵࡨᜯ"),key=lambda key: int(key[uhOkAKtLVv4XTy1nWE6(u"࠶ᘥ")]))
			ouHBbYIgr2,wn0kd1pEgfSy4YG,DupnWHq2SvjtxNh67sBQkLT5mJM3aP,Iga6ZWzdXDuoFO7NPjEf2AMxL8,Qg09MKEjzlUCJdt78D1x4ThbrP,rreason = IR6EdvxHspW9GrFlbymXq[DDS79jdWzLtE(u"࠰ᘦ")]
			zzalqpuJSygc6r5neXf7DPB0HFj = rreason if x9N7DKVT1rjsPmlieqQ8HJgU(KbL94nDHufSF0VcO2Nk3(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪნ")) else DupnWHq2SvjtxNh67sBQkLT5mJM3aP
			fQ6kvwg1FrYAzXjbLT.setSetting(ZpH2IWt7veyFobTsAnhi41(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧო"),zzalqpuJSygc6r5neXf7DPB0HFj)
			mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,HMO0QciekqVpLKmA(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩპ"),ddK4MmwpX5oG(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪჟ"),IR6EdvxHspW9GrFlbymXq,t7rXIzJfMLWRwaDeKhTq4C6dG)
			fQ6kvwg1FrYAzXjbLT.setSetting(uhOkAKtLVv4XTy1nWE6(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪრ"),AkEMLcQGwo0qnlB8VJeKiUTpX(Low1uSVG5OcafJmrYBC7D))
	return IR6EdvxHspW9GrFlbymXq
def NhUILSwisA(wknFHsBv9VP,ZfFoAXCdn0VJGmDcuOT1p=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠱ᘧ"),hpVQ4Sr9XTzdfGP6Ln0sFvUx5IW=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠱ᘧ")):
	if ZfFoAXCdn0VJGmDcuOT1p and not hpVQ4Sr9XTzdfGP6Ln0sFvUx5IW: hpVQ4Sr9XTzdfGP6Ln0sFvUx5IW = len(wknFHsBv9VP)//ZfFoAXCdn0VJGmDcuOT1p
	UUQjWZzkxDowXrpqFAJf50,kdWCpE9TjNh,B5uUMHex2L0W6b = [],-qNZKwi2M1S4fBzGQYrmPnea(u"࠳ᘨ"),OARzhnB9o7uYvQGFaIcZ(u"࠳ᘩ")
	for zO0UA5L7ta1sIHpmqjbeBvXf3Kky in wknFHsBv9VP:
		if B5uUMHex2L0W6b%hpVQ4Sr9XTzdfGP6Ln0sFvUx5IW==f8PVRTseIuj9BckO6GoyF5Lxv(u"࠴ᘪ"):
			kdWCpE9TjNh += tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠶ᘫ")
			UUQjWZzkxDowXrpqFAJf50.append([])
		UUQjWZzkxDowXrpqFAJf50[kdWCpE9TjNh].append(zO0UA5L7ta1sIHpmqjbeBvXf3Kky)
		B5uUMHex2L0W6b += ZpH2IWt7veyFobTsAnhi41(u"࠷ᘬ")
	return UUQjWZzkxDowXrpqFAJf50
def XhGZuwpMWFtNTgQHIVOyqazd5i391e(l0uAW3wIvSC,ZEJAFRNxIrQSU):
	foRZD05OyirbCcmLK = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,l0uAW3wIvSC)
	if L91nVzxH4hYrgPDsOuljXd0J(u"࠱ᘭ") or a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࡌࡔ࡙࡜࡟ࠨს") not in l0uAW3wIvSC or tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡑ࠸࡛࡟ࠨტ") not in l0uAW3wIvSC: gq2FVNBUKPzIw1pZAnYHJG = str(ZEJAFRNxIrQSU)
	else:
		UUQjWZzkxDowXrpqFAJf50 = NhUILSwisA(ZEJAFRNxIrQSU,uhOkAKtLVv4XTy1nWE6(u"࠹ᘮ"))
		gq2FVNBUKPzIw1pZAnYHJG = V391t7nQWUBR5euCkJ(u"ࠫࠬუ")
		for fH7GFeJOBliSh0pMKA in UUQjWZzkxDowXrpqFAJf50:
			gq2FVNBUKPzIw1pZAnYHJG += str(fH7GFeJOBliSh0pMKA)+vkMRnTNV9jFm(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫფ")
		gq2FVNBUKPzIw1pZAnYHJG = gq2FVNBUKPzIw1pZAnYHJG.strip(xxpPYJOnoAUrlBzyveui(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬქ"))
	jj9ybfZET2crAJYRsO = j7C3kwg1ob.compress(gq2FVNBUKPzIw1pZAnYHJG)
	open(foRZD05OyirbCcmLK,zOZvXaebGNwHKfjRA(u"ࠧࡸࡤࠪღ")).write(jj9ybfZET2crAJYRsO)
	return
def ffQvnxhtSOYElWRH097gVTomwApK5X(w3G0OiS6kCvADZm7FnRbYe5,l0uAW3wIvSC):
	if w3G0OiS6kCvADZm7FnRbYe5==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡦ࡬ࡧࡹ࠭ყ"): ZEJAFRNxIrQSU = {}
	elif w3G0OiS6kCvADZm7FnRbYe5==iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩ࡯࡭ࡸࡺࠧშ"): ZEJAFRNxIrQSU = []
	elif w3G0OiS6kCvADZm7FnRbYe5==DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡷࡹࡸࠧჩ"): ZEJAFRNxIrQSU = L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠬც")
	elif w3G0OiS6kCvADZm7FnRbYe5==zOZvXaebGNwHKfjRA(u"ࠬ࡯࡮ࡵࠩძ"): ZEJAFRNxIrQSU = zOZvXaebGNwHKfjRA(u"࠲ᘯ")
	else: ZEJAFRNxIrQSU = None
	foRZD05OyirbCcmLK = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,l0uAW3wIvSC)
	jj9ybfZET2crAJYRsO = open(foRZD05OyirbCcmLK,lunVJF2G5bZMgTcCje0vaIB371SX(u"࠭ࡲࡣࠩწ")).read()
	gq2FVNBUKPzIw1pZAnYHJG = j7C3kwg1ob.decompress(jj9ybfZET2crAJYRsO)
	if OARzhnB9o7uYvQGFaIcZ(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ჭ") not in gq2FVNBUKPzIw1pZAnYHJG: ZEJAFRNxIrQSU = eval(gq2FVNBUKPzIw1pZAnYHJG)
	else:
		UUQjWZzkxDowXrpqFAJf50 = gq2FVNBUKPzIw1pZAnYHJG.split(KbL94nDHufSF0VcO2Nk3(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧხ"))
		del gq2FVNBUKPzIw1pZAnYHJG
		ZEJAFRNxIrQSU = []
		ruFTbk1KvcfptHQZG798COYBd2jUA = kZ05eRcAtxbP1ID()
		ouHBbYIgr2 = KbL94nDHufSF0VcO2Nk3(u"࠳ᘰ")
		for fH7GFeJOBliSh0pMKA in UUQjWZzkxDowXrpqFAJf50:
			ruFTbk1KvcfptHQZG798COYBd2jUA.NLgdvIUqGZ1enEjfW7bkrsy48a(str(ouHBbYIgr2),eval,fH7GFeJOBliSh0pMKA)
			ouHBbYIgr2 += HMO0QciekqVpLKmA(u"࠵ᘱ")
		del UUQjWZzkxDowXrpqFAJf50
		ruFTbk1KvcfptHQZG798COYBd2jUA.ChL39J5erzSfMZv76()
		ruFTbk1KvcfptHQZG798COYBd2jUA.n6pOjVhX2U()
		pBekyRc5HiKhfDSsF3YvOT = list(ruFTbk1KvcfptHQZG798COYBd2jUA.resultsDICT.keys())
		bG8wFBTqUPoAMjyQ = sorted(pBekyRc5HiKhfDSsF3YvOT,reverse=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡆࡢ࡮ࡶࡩᜰ"),key=lambda key: int(key))
		for ouHBbYIgr2 in bG8wFBTqUPoAMjyQ:
			ZEJAFRNxIrQSU += ruFTbk1KvcfptHQZG798COYBd2jUA.resultsDICT[ouHBbYIgr2]
	return ZEJAFRNxIrQSU
def tVWYlTUyzvOH(M0J6Pq3bH2):
	YYtS4omFIV9D52OUpq8Q1ufdG0x6M = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(XJ4uqLcYdaT8nE3f,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩჯ"),M0J6Pq3bH2,p1lrNRIXqLQJznH6O(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭ჰ"))
	try: UCAkXsYLENnjruMt9hJ = open(YYtS4omFIV9D52OUpq8Q1ufdG0x6M,HMO0QciekqVpLKmA(u"ࠫࡷࡨࠧჱ")).read()
	except:
		vReVr71MmT = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(LLztTXv6YWnpjqVMldZE,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡧࡤࡥࡱࡱࡷࠬჲ"),M0J6Pq3bH2,HMO0QciekqVpLKmA(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩჳ"))
		try: UCAkXsYLENnjruMt9hJ = open(vReVr71MmT,fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡳࡤࠪჴ")).read()
		except: return gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࠩჵ"),[]
	if Nnxm30dfoBWRYpIC7KsQGl: UCAkXsYLENnjruMt9hJ = UCAkXsYLENnjruMt9hJ.decode(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࡸࡸ࡫࠾ࠧჶ"))
	qILERgV5chsdC18M = QPuHKNAT4jmCRg.findall(qNZKwi2M1S4fBzGQYrmPnea(u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧჷ"),UCAkXsYLENnjruMt9hJ,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
	if not qILERgV5chsdC18M: return p1lrNRIXqLQJznH6O(u"ࠫࠬჸ"),[]
	rmKTWB87u0oPRGDatdIUANSpLVCXe,v8kTHaIKAVoNOriy20L1EDJxpqB7Y5 = qILERgV5chsdC18M[IJ6VkihabRm(u"࠵ᘲ")],XQCSoqYpy2EAu6J(qILERgV5chsdC18M[IJ6VkihabRm(u"࠵ᘲ")])
	return rmKTWB87u0oPRGDatdIUANSpLVCXe,v8kTHaIKAVoNOriy20L1EDJxpqB7Y5
def NNK2SqgVPy():
	sIlUzFjmN0adpWctL = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬࡪࡩࡤࡶࠪჹ"),fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩჺ"),DDS79jdWzLtE(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ჻"))
	if sIlUzFjmN0adpWctL: return sIlUzFjmN0adpWctL
	pHFTt5UYjQAI,sIlUzFjmN0adpWctL = {},{}
	FFxGIsEMpquf6 = [EGcFon0zR4mSL1[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࡔࡈࡔࡔ࡙ࠧჼ")][v7reLlOXCgD5pZ14w2tUA(u"࠶ᘳ")]]
	if LRjqrQYBXFVPfu>u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠲࠹࠱࠽࠾ᘵ"): FFxGIsEMpquf6.append(EGcFon0zR4mSL1[lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࡕࡉࡕࡕࡓࠨჽ")][OARzhnB9o7uYvQGFaIcZ(u"࠱ᘴ")])
	if Nnxm30dfoBWRYpIC7KsQGl: FFxGIsEMpquf6.append(EGcFon0zR4mSL1[xxpPYJOnoAUrlBzyveui(u"ࠪࡖࡊࡖࡏࡔࠩჾ")][xxpPYJOnoAUrlBzyveui(u"࠴ᘶ")])
	for qyZChzMLUdoNH4VbFeuWg3r in FFxGIsEMpquf6:
		djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡌࡋࡔࠨჿ"),qyZChzMLUdoNH4VbFeuWg3r,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࠭ᄀ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࠧᄁ"),zOZvXaebGNwHKfjRA(u"ࠧࠨᄂ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࠩᄃ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ᄄ"))
		if djr0g3VkMzo1ehxE.succeeded:
			RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
			n8iuV5rPTlXLJH3NsZp = qyZChzMLUdoNH4VbFeuWg3r.rsplit(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪ࠳ࠬᄅ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠴ᘷ"))[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠴ᘸ")]
			r6oAjJNITmDiSfRGce0 = QPuHKNAT4jmCRg.findall(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᄆ"),RkLE6BzZ2KX,QPuHKNAT4jmCRg.DOTALL|QPuHKNAT4jmCRg.IGNORECASE)
			for M0J6Pq3bH2,mmB3rfHxXQCbacJKp in r6oAjJNITmDiSfRGce0:
				arY72VBMZiGywceNgSdRQk5uOK9oF = n8iuV5rPTlXLJH3NsZp+ZpH2IWt7veyFobTsAnhi41(u"ࠬ࠵ࠧᄇ")+M0J6Pq3bH2+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭࠯ࠨᄈ")+M0J6Pq3bH2+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧ࠮ࠩᄉ")+mmB3rfHxXQCbacJKp+ddK4MmwpX5oG(u"ࠨ࠰ࡽ࡭ࡵ࠭ᄊ")
				if M0J6Pq3bH2 not in list(pHFTt5UYjQAI.keys()):
					pHFTt5UYjQAI[M0J6Pq3bH2] = []
					sIlUzFjmN0adpWctL[M0J6Pq3bH2] = []
				RZMrBzya9I0A2VP4NFn = XQCSoqYpy2EAu6J(mmB3rfHxXQCbacJKp)
				pHFTt5UYjQAI[M0J6Pq3bH2].append((mmB3rfHxXQCbacJKp,RZMrBzya9I0A2VP4NFn,arY72VBMZiGywceNgSdRQk5uOK9oF))
	for M0J6Pq3bH2 in list(pHFTt5UYjQAI.keys()):
		sIlUzFjmN0adpWctL[M0J6Pq3bH2] = sorted(pHFTt5UYjQAI[M0J6Pq3bH2],reverse=v7reLlOXCgD5pZ14w2tUA(u"ࡕࡴࡸࡩᜱ"),key=lambda key: key[Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠶ᘹ")])
	mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,vkMRnTNV9jFm(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬᄋ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫᄌ"),sIlUzFjmN0adpWctL,t7rXIzJfMLWRwaDeKhTq4C6dG)
	return sIlUzFjmN0adpWctL
def XQCSoqYpy2EAu6J(mmB3rfHxXQCbacJKp):
	RZMrBzya9I0A2VP4NFn = []
	VHEYQ1vrPn85JU = mmB3rfHxXQCbacJKp.split(uhOkAKtLVv4XTy1nWE6(u"ࠫ࠳࠭ᄍ"))
	for ElHn6OgwBufb09MAL in VHEYQ1vrPn85JU:
		L2ZaRFG5myvEj1hDrqOu6NYWMf = QPuHKNAT4jmCRg.findall(ZpH2IWt7veyFobTsAnhi41(u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩᄎ"),ElHn6OgwBufb09MAL,QPuHKNAT4jmCRg.DOTALL)
		FDyrdx4Q9I05kgYEqLBnzN2ZajmR = []
		for igZANacQEH0s14UGPSje367q8KBOC in L2ZaRFG5myvEj1hDrqOu6NYWMf:
			if igZANacQEH0s14UGPSje367q8KBOC.isdigit(): igZANacQEH0s14UGPSje367q8KBOC = int(igZANacQEH0s14UGPSje367q8KBOC)
			FDyrdx4Q9I05kgYEqLBnzN2ZajmR.append(igZANacQEH0s14UGPSje367q8KBOC)
		RZMrBzya9I0A2VP4NFn.append(FDyrdx4Q9I05kgYEqLBnzN2ZajmR)
	return RZMrBzya9I0A2VP4NFn
def G7vAEe5dDqJi40Rfrs(RZMrBzya9I0A2VP4NFn):
	mmB3rfHxXQCbacJKp = xxpPYJOnoAUrlBzyveui(u"࠭ࠧᄏ")
	for ElHn6OgwBufb09MAL in RZMrBzya9I0A2VP4NFn:
		for igZANacQEH0s14UGPSje367q8KBOC in ElHn6OgwBufb09MAL: mmB3rfHxXQCbacJKp += str(igZANacQEH0s14UGPSje367q8KBOC)
		mmB3rfHxXQCbacJKp += tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧ࠯ࠩᄐ")
	mmB3rfHxXQCbacJKp = mmB3rfHxXQCbacJKp.strip(vkMRnTNV9jFm(u"ࠨ࠰ࠪᄑ"))
	return mmB3rfHxXQCbacJKp
def QNumy9zkeS(o4oVOHtrSlkM52Up):
	BwiXRqKVEj = {}
	pHFTt5UYjQAI = NNK2SqgVPy()
	SQPqxUhbB7ZV8WECRoe6Tf5 = vtrSgBxFJ8HuO5mUqV0blNko1C(o4oVOHtrSlkM52Up)
	for M0J6Pq3bH2 in o4oVOHtrSlkM52Up:
		if M0J6Pq3bH2 not in list(pHFTt5UYjQAI.keys()): continue
		sIlUzFjmN0adpWctL = pHFTt5UYjQAI[M0J6Pq3bH2]
		ff2PVpLIujFJ4zEwOK,YafC2eqinBLW1sUOlKjp,ll63KQXzDgA9uLqt7Vbi = sIlUzFjmN0adpWctL[dxAs4otSE98YmZnKy2iwRCB(u"࠶ᘺ")]
		Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms,hhQUWqJdBPRlcf5kVLTG = tVWYlTUyzvOH(M0J6Pq3bH2)
		yyeTwX3xSdtquYh1mZo,EBfgyuHClxLv4XMQTwtn = SQPqxUhbB7ZV8WECRoe6Tf5[M0J6Pq3bH2]
		yL2enPBTmruNl76 = YafC2eqinBLW1sUOlKjp>hhQUWqJdBPRlcf5kVLTG and yyeTwX3xSdtquYh1mZo
		xbkrlD0EILwKiPB68MhNpRuA = ZpH2IWt7veyFobTsAnhi41(u"ࡖࡵࡹࡪᜲ")
		if not yyeTwX3xSdtquYh1mZo: UTOaf9HYGNCwi = xxpPYJOnoAUrlBzyveui(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᄒ")
		elif not EBfgyuHClxLv4XMQTwtn: UTOaf9HYGNCwi = q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬᄓ")
		elif yL2enPBTmruNl76: UTOaf9HYGNCwi = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࡴࡲࡤࠨᄔ")
		else:
			UTOaf9HYGNCwi = v7reLlOXCgD5pZ14w2tUA(u"ࠬ࡭࡯ࡰࡦࠪᄕ")
			xbkrlD0EILwKiPB68MhNpRuA = GGTRaYBDeNyI25zlF(u"ࡉࡥࡱࡹࡥᜳ")
		BwiXRqKVEj[M0J6Pq3bH2] = (xbkrlD0EILwKiPB68MhNpRuA,Sa9YZ6nU40wHeNRp3jFzc8dAQvo1Ms,hhQUWqJdBPRlcf5kVLTG,ff2PVpLIujFJ4zEwOK,YafC2eqinBLW1sUOlKjp,UTOaf9HYGNCwi,ll63KQXzDgA9uLqt7Vbi)
	return BwiXRqKVEj
def Qm8DTfKEUrdMvXzO7(smMzArf4FkJ1NDKEx,DLtNqyBUhIoFe3QafZ7nz5,AABo8Mfz5RS0pTJZLyXEqs=iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࠧᄖ"),BJm24Kg9fPDeWipynFohuj=zOZvXaebGNwHKfjRA(u"ࠧࠨᄗ"),vowl0neIXiT92=u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࠩᄘ")):
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: smMzArf4FkJ1NDKEx.update(DLtNqyBUhIoFe3QafZ7nz5,AABo8Mfz5RS0pTJZLyXEqs,BJm24Kg9fPDeWipynFohuj,vowl0neIXiT92)
	else: smMzArf4FkJ1NDKEx.update(DLtNqyBUhIoFe3QafZ7nz5,AABo8Mfz5RS0pTJZLyXEqs+HMO0QciekqVpLKmA(u"ࠩ࡟ࡲࠬᄙ")+BJm24Kg9fPDeWipynFohuj+v7reLlOXCgD5pZ14w2tUA(u"ࠪࡠࡳ࠭ᄚ")+vowl0neIXiT92)
	return
def V7nq6gTU2NIe0OCtZMpKB(bbszZDlChGAiI8eV3r6Yk):
	def rIg236zpoh7PTHJNdCqv05nAUiX(LDcXJR0zGijMvagUK,qXcWdHt5VEZ1xioT6rUQ9NGPwFIk,hh84GWrCUT7nFvmYR6MAIVyPbL=d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦᄛ")):
		return ((LDcXJR0zGijMvagUK == lunVJF2G5bZMgTcCje0vaIB371SX(u"࠰ᘻ")) and hh84GWrCUT7nFvmYR6MAIVyPbL[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠰ᘻ")]) or (rIg236zpoh7PTHJNdCqv05nAUiX(LDcXJR0zGijMvagUK // qXcWdHt5VEZ1xioT6rUQ9NGPwFIk, qXcWdHt5VEZ1xioT6rUQ9NGPwFIk, hh84GWrCUT7nFvmYR6MAIVyPbL).lstrip(hh84GWrCUT7nFvmYR6MAIVyPbL[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠰ᘻ")]) + hh84GWrCUT7nFvmYR6MAIVyPbL[LDcXJR0zGijMvagUK % qXcWdHt5VEZ1xioT6rUQ9NGPwFIk])
	def ddZbHikLQhDs1UYxMGjzPK5TI2t(DDXjPS3Wsvy5RBYG, URFCA28wLdY1x6OTl, sjhXNO10W4CTqlAS8JeZwtKBnPm9UG, z15udFwAbyktjYo, GxEszH0XJBIeS=None, NJHsCZEmV7l4hGMU=None, yBjYf1NmrDR4K3Ute5li=None):
		while (sjhXNO10W4CTqlAS8JeZwtKBnPm9UG):
			sjhXNO10W4CTqlAS8JeZwtKBnPm9UG-=Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠲ᘼ")
			if (z15udFwAbyktjYo[sjhXNO10W4CTqlAS8JeZwtKBnPm9UG]): DDXjPS3Wsvy5RBYG = QPuHKNAT4jmCRg.sub(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡢ࡜ࡣࠤᄜ") + rIg236zpoh7PTHJNdCqv05nAUiX(sjhXNO10W4CTqlAS8JeZwtKBnPm9UG, URFCA28wLdY1x6OTl) + ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨ࡜࡝ࡤࠥᄝ"),  z15udFwAbyktjYo[sjhXNO10W4CTqlAS8JeZwtKBnPm9UG], DDXjPS3Wsvy5RBYG)
		return DDXjPS3Wsvy5RBYG
	bbszZDlChGAiI8eV3r6Yk = bbszZDlChGAiI8eV3r6Yk.split(IJ6VkihabRm(u"ࠧࡾࠪࠪᄞ"))[p1lrNRIXqLQJznH6O(u"࠳ᘽ")]
	bbszZDlChGAiI8eV3r6Yk = bbszZDlChGAiI8eV3r6Yk.rsplit(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࡵࡳࡰ࡮ࡺࠧᄟ"))[DKqQekNtF6WlJLhBP9M5ca(u"࠳ᘾ")]+Vv0lSjAOHLfMnam3wtdor(u"ࠤࡶࡴࡱ࡯ࡴࠩࠩࡿࠫ࠮࠯ࠢᄠ")
	cc1nabWT9B0zpYNQumyAkq = eval(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫᄡ")+bbszZDlChGAiI8eV3r6Yk,{u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࡧࡧࡳࡦࡐࠪᄢ"):rIg236zpoh7PTHJNdCqv05nAUiX,dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬᄣ"):ddZbHikLQhDs1UYxMGjzPK5TI2t})
	return cc1nabWT9B0zpYNQumyAkq
def egAThx8vmPdizHXo(DDRulV7aKN3jCOWSBQkb95,MMujCxRNDH2aUsS1wfzvL=fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࠧᄤ")):
	if MMujCxRNDH2aUsS1wfzvL==ZpH2IWt7veyFobTsAnhi41(u"ࠧ࡭ࡱࡺࡩࡷ࠭ᄥ"): DDRulV7aKN3jCOWSBQkb95 = QPuHKNAT4jmCRg.sub(DDS79jdWzLtE(u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨᄦ"),lambda DW9tpvsr1yFAmnHLhlz74xqJj3fSwM: DW9tpvsr1yFAmnHLhlz74xqJj3fSwM.group(ddK4MmwpX5oG(u"࠴ᘿ")).lower(),DDRulV7aKN3jCOWSBQkb95)
	elif MMujCxRNDH2aUsS1wfzvL==xxpPYJOnoAUrlBzyveui(u"ࠩࡸࡴࡵ࡫ࡲࠨᄧ"): DDRulV7aKN3jCOWSBQkb95 = QPuHKNAT4jmCRg.sub(DDS79jdWzLtE(u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪᄨ"),lambda DW9tpvsr1yFAmnHLhlz74xqJj3fSwM: DW9tpvsr1yFAmnHLhlz74xqJj3fSwM.group(zOZvXaebGNwHKfjRA(u"࠵ᙀ")).upper(),DDRulV7aKN3jCOWSBQkb95)
	return DDRulV7aKN3jCOWSBQkb95
def vtrSgBxFJ8HuO5mUqV0blNko1C(o4oVOHtrSlkM52Up):
	uuwfpNU0d9ye,shpOx2JnZYE3Itj7oaNie = xxBJoKG54uwQ(u"ࡊࡦࡲࡳࡦ᜴"),xxBJoKG54uwQ(u"ࡊࡦࡲࡳࡦ᜴")
	qcOU43biDkaPQlZMB1wHEj = csXRAak0iZIKQpfu1o.connect(zmL4569eBqGphRbKP7f2NOs)
	qcOU43biDkaPQlZMB1wHEj.text_factory = str
	K2DlNXvQC65FzngUVyk3IGAq = qcOU43biDkaPQlZMB1wHEj.cursor()
	if len(o4oVOHtrSlkM52Up)==V391t7nQWUBR5euCkJ(u"࠷ᙁ"): ZZnjFAwi1ChfX49gWbmHNvxIkBJ = v7reLlOXCgD5pZ14w2tUA(u"ࠫ࠭ࠨࠧᄩ")+o4oVOHtrSlkM52Up[HMO0QciekqVpLKmA(u"࠰ᙂ")]+p1lrNRIXqLQJznH6O(u"ࠬࠨࠩࠨᄪ")
	else: ZZnjFAwi1ChfX49gWbmHNvxIkBJ = str(tuple(o4oVOHtrSlkM52Up))
	K2DlNXvQC65FzngUVyk3IGAq.execute(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭ᄫ")+ZZnjFAwi1ChfX49gWbmHNvxIkBJ+L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠡ࠽ࠪᄬ"))
	u5hKSaFyVqLz90Zc6iG = K2DlNXvQC65FzngUVyk3IGAq.fetchall()
	SQPqxUhbB7ZV8WECRoe6Tf5 = {}
	for M0J6Pq3bH2 in o4oVOHtrSlkM52Up: SQPqxUhbB7ZV8WECRoe6Tf5[M0J6Pq3bH2] = (ZpH2IWt7veyFobTsAnhi41(u"ࡋࡧ࡬ࡴࡧ᜵"),ZpH2IWt7veyFobTsAnhi41(u"ࡋࡧ࡬ࡴࡧ᜵"))
	for M0J6Pq3bH2,shpOx2JnZYE3Itj7oaNie in u5hKSaFyVqLz90Zc6iG:
		uuwfpNU0d9ye = p1lrNRIXqLQJznH6O(u"࡚ࡲࡶࡧ᜶")
		shpOx2JnZYE3Itj7oaNie = shpOx2JnZYE3Itj7oaNie==q0JfWbP8vACLxSNIncpOXkR6j(u"࠲ᙃ")
		SQPqxUhbB7ZV8WECRoe6Tf5[M0J6Pq3bH2] = (uuwfpNU0d9ye,shpOx2JnZYE3Itj7oaNie)
	qcOU43biDkaPQlZMB1wHEj.close()
	return SQPqxUhbB7ZV8WECRoe6Tf5
def MMnGsYl0Oh9zgub43E5m(AeX8tIu4jVHh9p6STsFBq57KrmxU):
	RRMWBwU6pG = zOZvXaebGNwHKfjRA(u"ࠨࠩᄭ")
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(AeX8tIu4jVHh9p6STsFBq57KrmxU):
		g4gokw71hemBnS3xPIORXJNbLzV = open(AeX8tIu4jVHh9p6STsFBq57KrmxU,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡵࡦࠬᄮ")).read()
		if Nnxm30dfoBWRYpIC7KsQGl: g4gokw71hemBnS3xPIORXJNbLzV = g4gokw71hemBnS3xPIORXJNbLzV.decode(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡹࡹ࡬࠸ࠨᄯ"))
		dQZKVkrwWAsCJyl5UpFR3mz = kMLWTt2fO9dnGDUgHh(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࡩ࡯ࡣࡵࠩᄰ"),g4gokw71hemBnS3xPIORXJNbLzV)
		if dQZKVkrwWAsCJyl5UpFR3mz:
			RRMWBwU6pG = {}
			for SonE0wpbWDiYV in dQZKVkrwWAsCJyl5UpFR3mz.keys():
				RRMWBwU6pG[SonE0wpbWDiYV] = []
				for alpPFury18sIf5WnwdZ in dQZKVkrwWAsCJyl5UpFR3mz[SonE0wpbWDiYV]:
					xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2 = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬ࠭ᄱ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧᄲ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠨᄳ"),HMO0QciekqVpLKmA(u"ࠨࠩᄴ"),uhOkAKtLVv4XTy1nWE6(u"ࠩࠪᄵ"),OARzhnB9o7uYvQGFaIcZ(u"ࠪࠫᄶ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࠬᄷ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࠭ᄸ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࠧᄹ")
					xEc7nR3qoAlv6C8YjD = alpPFury18sIf5WnwdZ[xxBJoKG54uwQ(u"࠲ᙄ")]
					QEMyY8a9IoOcFqeuKztCVWmT7jXv = alpPFury18sIf5WnwdZ[xxpPYJOnoAUrlBzyveui(u"࠴ᙅ")]
					QEMyY8a9IoOcFqeuKztCVWmT7jXv = rIPlaEZu19UKnXGAFzcyfM6oegdSj(QEMyY8a9IoOcFqeuKztCVWmT7jXv)
					DDRulV7aKN3jCOWSBQkb95 = alpPFury18sIf5WnwdZ[DKqQekNtF6WlJLhBP9M5ca(u"࠶ᙆ")]
					PBem6Hqsfgjvz = alpPFury18sIf5WnwdZ[zOZvXaebGNwHKfjRA(u"࠸ᙇ")]
					KKcFOCmYRENepQnxi = alpPFury18sIf5WnwdZ[DDS79jdWzLtE(u"࠺ᙈ")]
					YSTbrKgPf7NyhIDizB = alpPFury18sIf5WnwdZ[lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵ᙉ")]
					if len(alpPFury18sIf5WnwdZ)>xxpPYJOnoAUrlBzyveui(u"࠷ᙊ"): gq2FVNBUKPzIw1pZAnYHJG = alpPFury18sIf5WnwdZ[xxpPYJOnoAUrlBzyveui(u"࠷ᙊ")]
					if len(alpPFury18sIf5WnwdZ)>ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠹ᙋ"): ja74FTtz9hK = alpPFury18sIf5WnwdZ[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠹ᙋ")]
					if len(alpPFury18sIf5WnwdZ)>p1lrNRIXqLQJznH6O(u"࠻ᙌ"): RkfstxEyua67K2 = alpPFury18sIf5WnwdZ[p1lrNRIXqLQJznH6O(u"࠻ᙌ")]
					if AeX8tIu4jVHh9p6STsFBq57KrmxU==KmlAH1VJObEkfZS3ToazF8qNP70t: wwqLsuTtfRC75Uz2WFD3ip = xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ZpH2IWt7veyFobTsAnhi41(u"ࠧࠨᄺ"),RkfstxEyua67K2
					else: wwqLsuTtfRC75Uz2WFD3ip = xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2
					RRMWBwU6pG[SonE0wpbWDiYV].append(wwqLsuTtfRC75Uz2WFD3ip)
		I5n6KcZWvLYtkrof0eMJsASTaU = str(RRMWBwU6pG)
		if Nnxm30dfoBWRYpIC7KsQGl: I5n6KcZWvLYtkrof0eMJsASTaU = I5n6KcZWvLYtkrof0eMJsASTaU.encode(zOZvXaebGNwHKfjRA(u"ࠨࡷࡷࡪ࠽࠭ᄻ"))
		open(AeX8tIu4jVHh9p6STsFBq57KrmxU,xxpPYJOnoAUrlBzyveui(u"ࠩࡺࡦࠬᄼ")).write(I5n6KcZWvLYtkrof0eMJsASTaU)
	return RRMWBwU6pG
def tfuri9cjL3JEgaOMPlynH0sUhW25(Xt7olBPDuFS4diy1):
	AxHSmUzQtPeKFRDIaLp1kB4 = Xt7olBPDuFS4diy1.split(V391t7nQWUBR5euCkJ(u"ࠪ࠱ࠬᄽ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠵ᙍ"))[xxpPYJOnoAUrlBzyveui(u"࠵ᙎ")]
	ZQGzeTEil79pbsCtauf,Z1wMTVKApbNvinskL7,EYNDrC48cOLIKeUdq7ju0ptikxTSv = p1lrNRIXqLQJznH6O(u"ࠫࠬᄾ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠭ᄿ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧᅀ")
	if   AxHSmUzQtPeKFRDIaLp1kB4==iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠧࡂࡊ࡚ࡅࡐ࠭ᅁ")		:	from rzEFQokM8A			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡃࡎࡓࡆࡓࠧᅂ")		:	from OjZmrI0DKb			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==V391t7nQWUBR5euCkJ(u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫᅃ")	:	from yeoi8n2Xb1		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡅࡐ࡝ࡁࡎࠩᅄ")		:	from ETaRVFoBXD			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡆࡒࡁࡓࡃࡅࠫᅅ")	:	from nCIOoXFS1A			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧᅆ")	:	from Jz2TdkVr9i		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==uhOkAKtLVv4XTy1nWE6(u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩᅇ")	: 	from RtkbPs9yKS		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==GGTRaYBDeNyI25zlF(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩᅈ")	:	from jOXEQYC1T7		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ᅉ"):	from AANZ3fvsJM	import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ddK4MmwpX5oG(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫᅊ")	:	from CbnORTUHL5		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ddK4MmwpX5oG(u"ࠪࡆࡔࡑࡒࡂࠩᅋ")		:	from LRMCkhDVuY			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==xxpPYJOnoAUrlBzyveui(u"ࠫࡇࡘࡓࡕࡇࡍࠫᅌ")	:	from pUz3CwB5hP			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᅍ")	:	from D8K7V39IUc		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==p1lrNRIXqLQJznH6O(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᅎ")	:	from kuNtEaWXm6			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==IJ6VkihabRm(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᅏ")	:	from tBRqDYfagz		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==p1lrNRIXqLQJznH6O(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧᅐ"):	from NHJ8MUiSxZ	import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==DDS79jdWzLtE(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫᅑ"):		from Vo1bUqIvAi		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==IJ6VkihabRm(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᅒ")	:	from oAOYptLgIS		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ᅓ")	:	from HHrKwoj5pc		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ZpH2IWt7veyFobTsAnhi41(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᅔ")	:	from PeR0asuyA2		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==v7reLlOXCgD5pZ14w2tUA(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧᅕ")	:	from wJbtYB85UM		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==p1lrNRIXqLQJznH6O(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬᅖ"):	from Ye6gQpcIJL	import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==V391t7nQWUBR5euCkJ(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩᅗ")	:	from dV94ow7KIx		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪᅘ")	:	from iiRDUdxsca		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬᅙ")	:	from VPK7iuwqrt		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ᅚ")	:	from k2pMg0U8ml		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧᅛ")	:	from EVXS46FUM7		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨᅜ")	:	from QOEaAPsFBw		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==V391t7nQWUBR5euCkJ(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨᅝ")	:	from uFrycA7jOJ		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==GGTRaYBDeNyI25zlF(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨᅞ")	:	from gTS1D3NfJz			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪᅟ")	:	from XXVYTUMI40		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==dxAs4otSE98YmZnKy2iwRCB(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ᅠ")	:	from p0aBKYXZUh		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᅡ")	:	from ppGhAdLXIP		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==xxBJoKG54uwQ(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧᅢ")	:	from YvuiySjmd9		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࡆࡐࡕࡗࡅࠬᅣ")		:	from xx35gBdP1Y			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩᅤ")	:	from ksA2HucdFh		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡋࡉࡍࡑࡓࠧᅥ")		:	from y8PYivouwU			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==xxpPYJOnoAUrlBzyveui(u"ࠩࡌࡔ࡙࡜ࠧᅦ")		:	from Fh0QwtApKa	import QKeHO0hSmMnC6GyRYxqzNVfXUbjd as ZQGzeTEil79pbsCtauf,oThr70M9BuSwHkalZ6sV5tUyFNiW as Z1wMTVKApbNvinskL7,lCfDqYvaRW as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==xxBJoKG54uwQ(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ᅧ")	:	from jj1WteBzhQ		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==GGTRaYBDeNyI25zlF(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ᅨ")	:	from uuXO2oJlpQ		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==Vv0lSjAOHLfMnam3wtdor(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧᅩ")	:	from pDuINVgCYf		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==v7reLlOXCgD5pZ14w2tUA(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ᅪ")	:	from ssotCShO9a			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨᅫ")	:	from N7ORfApWM4		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡏ࠶࡙ࠬᅬ")		:	from RWoJSlvIC0	import QKeHO0hSmMnC6GyRYxqzNVfXUbjd as ZQGzeTEil79pbsCtauf,oThr70M9BuSwHkalZ6sV5tUyFNiW as Z1wMTVKApbNvinskL7,lCfDqYvaRW as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩᅭ")	:	from BM6R2vOGT9			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪᅮ")	:	from vbokuZrzD6			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡕࡇࡎࡆࡖࠪᅯ")		:	from k8vP7K6OlS			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧᅰ")	:	from f862dET1BF		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪᅱ"):	from kdQ7U8EY5L		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==ZpH2IWt7veyFobTsAnhi41(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪᅲ")	:	from qkPlF3hXrB		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࡕࡋࡓࡋࡎࡁࠨᅳ")	:	from qRtFebZi1J			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==v7reLlOXCgD5pZ14w2tUA(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫᅴ")	:	from hdIpkHazRx		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬᅵ")	:	from JE3trXDa7N		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==vkMRnTNV9jFm(u"࡙ࠫ࡜ࡆࡖࡐࠪᅶ")		:	from DFkGWuYhdb			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==qNZKwi2M1S4fBzGQYrmPnea(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬᅷ")	:	from F4b2neDjfi			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==qNZKwi2M1S4fBzGQYrmPnea(u"࡙࠭ࡂࡓࡒࡘࠬᅸ")		:	from NqbsyBwugI			import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==IJ6VkihabRm(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᅹ")	:	from DGetBjzwkV		import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf,mt4qhKoi9ynlYXFRszgZ7b3wr as Z1wMTVKApbNvinskL7,JE7QrkmhletLwA0OZXu as EYNDrC48cOLIKeUdq7ju0ptikxTSv
	elif AxHSmUzQtPeKFRDIaLp1kB4==V391t7nQWUBR5euCkJ(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧᅺ"):	from LbPKDg3wS6	import YpFfN68PZ132 as ZQGzeTEil79pbsCtauf
	return ZQGzeTEil79pbsCtauf,Z1wMTVKApbNvinskL7,EYNDrC48cOLIKeUdq7ju0ptikxTSv
def W6ndv5PCbAh(Trt9xo75Lh,iPmj7p45q2duSAQaHvOnT,showDialogs):
	zRM3tZx2v6DjJU(vkMRnTNV9jFm(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᅻ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨᅼ")+Trt9xo75Lh+p1lrNRIXqLQJznH6O(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᅽ")+str(iPmj7p45q2duSAQaHvOnT)+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࠦ࡝ࠨᅾ"))
	smMzArf4FkJ1NDKEx = zzyalh3A275njbIKsD0EQ()
	smMzArf4FkJ1NDKEx.create(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅿ"),p1lrNRIXqLQJznH6O(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩᆀ"))
	vjaYg08OXptG9rx4z67WKhB = DDS79jdWzLtE(u"࠷࠰࠳࠶ᙏ")*DDS79jdWzLtE(u"࠷࠰࠳࠶ᙏ")
	A0HBTij1koLlYtbS8 = ddK4MmwpX5oG(u"࠱ᙐ")*vjaYg08OXptG9rx4z67WKhB
	djr0g3VkMzo1ehxE = D0nOE8Wu9jfHxPTIXiLVypGB.get(Trt9xo75Lh,stream=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࡔࡳࡷࡨ᜷"),headers=iPmj7p45q2duSAQaHvOnT)
	SScqW5jHowBOtA0 = djr0g3VkMzo1ehxE.headers
	djr0g3VkMzo1ehxE.close()
	KKMdNrcWXLt = bytes()
	if not SScqW5jHowBOtA0:
		if showDialogs: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(V391t7nQWUBR5euCkJ(u"ࠨࠩᆁ"),v7reLlOXCgD5pZ14w2tUA(u"ࠩࠪᆂ"),OARzhnB9o7uYvQGFaIcZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆃ"),GGTRaYBDeNyI25zlF(u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧᆄ"))
		smMzArf4FkJ1NDKEx.close()
	else:
		if HMO0QciekqVpLKmA(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ᆅ") not in list(SScqW5jHowBOtA0.keys()): BvY2nJaXeWMPAyHDrmQRg9jK = GGTRaYBDeNyI25zlF(u"࠱ᙑ")
		else: BvY2nJaXeWMPAyHDrmQRg9jK = int(SScqW5jHowBOtA0[v7reLlOXCgD5pZ14w2tUA(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᆆ")])
		X5uhI4RHtUmC3zY7GSx2Jowp1BENbv = str(int(fcIm8tvxlXZsaEY3bwuG4B(u"࠴࠴࠵࠶ᙓ")*BvY2nJaXeWMPAyHDrmQRg9jK/vjaYg08OXptG9rx4z67WKhB)/xxBJoKG54uwQ(u"࠳࠳࠴࠵࠴࠰ᙒ"))
		WIKOL4xFeGmz = int(BvY2nJaXeWMPAyHDrmQRg9jK/A0HBTij1koLlYtbS8)+V391t7nQWUBR5euCkJ(u"࠵ᙔ")
		if ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧᆇ") in list(SScqW5jHowBOtA0.keys()) and BvY2nJaXeWMPAyHDrmQRg9jK>vjaYg08OXptG9rx4z67WKhB:
			jaAONFoI2r3 = q0JfWbP8vACLxSNIncpOXkR6j(u"ࡕࡴࡸࡩ᜸")
			njqaA6gvwItUmcP2TQ7liRGr1FSZ = []
			D6EPXm1M5nx = fcIm8tvxlXZsaEY3bwuG4B(u"࠶࠶ᙕ")
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(DDS79jdWzLtE(u"࠰ᙗ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+OARzhnB9o7uYvQGFaIcZ(u"ࠨ࠯ࠪᆈ")+str(HMO0QciekqVpLKmA(u"࠷ᙖ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-HMO0QciekqVpLKmA(u"࠷ᙖ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(zOZvXaebGNwHKfjRA(u"࠲ᙘ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࠰ࠫᆉ")+str(zOZvXaebGNwHKfjRA(u"࠴ᙙ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-zOZvXaebGNwHKfjRA(u"࠲ᙘ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠷ᙜ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+dxAs4otSE98YmZnKy2iwRCB(u"ࠪ࠱ࠬᆊ")+str(vkMRnTNV9jFm(u"࠷ᙛ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-v7reLlOXCgD5pZ14w2tUA(u"࠴ᙚ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(uhOkAKtLVv4XTy1nWE6(u"࠳ᙞ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+V391t7nQWUBR5euCkJ(u"ࠫ࠲࠭ᆋ")+str(ZpH2IWt7veyFobTsAnhi41(u"࠵ᙟ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-L91nVzxH4hYrgPDsOuljXd0J(u"࠷ᙝ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(xxpPYJOnoAUrlBzyveui(u"࠸ᙢ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+xxBJoKG54uwQ(u"ࠬ࠳ࠧᆌ")+str(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠸ᙡ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠳ᙠ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(OARzhnB9o7uYvQGFaIcZ(u"࠻ᙤ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭࠭ࠨᆍ")+str(vkMRnTNV9jFm(u"࠶ᙥ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-dxAs4otSE98YmZnKy2iwRCB(u"࠶ᙣ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(fcIm8tvxlXZsaEY3bwuG4B(u"࠹ᙨ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+OARzhnB9o7uYvQGFaIcZ(u"ࠧ࠮ࠩᆎ")+str(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠹ᙧ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-ddK4MmwpX5oG(u"࠲ᙦ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠽ᙫ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+ddK4MmwpX5oG(u"ࠨ࠯ࠪᆏ")+str(Vv0lSjAOHLfMnam3wtdor(u"࠽ᙪ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-vkMRnTNV9jFm(u"࠵ᙩ")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(dxAs4otSE98YmZnKy2iwRCB(u"࠹᙭")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩ࠰ࠫᆐ")+str(L91nVzxH4hYrgPDsOuljXd0J(u"࠹ᙬ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx-xxpPYJOnoAUrlBzyveui(u"࠳᙮")))
			njqaA6gvwItUmcP2TQ7liRGr1FSZ.append(str(DDS79jdWzLtE(u"࠼ᙯ")*BvY2nJaXeWMPAyHDrmQRg9jK//D6EPXm1M5nx)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪ࠱ࠬᆑ"))
			e8Yhrl2FBa7D5i1NPECqI = float(WIKOL4xFeGmz)/D6EPXm1M5nx
			EhAKamnelG = e8Yhrl2FBa7D5i1NPECqI/int(v7reLlOXCgD5pZ14w2tUA(u"࠵ᙰ")+e8Yhrl2FBa7D5i1NPECqI)
		else:
			jaAONFoI2r3 = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࡈࡤࡰࡸ࡫᜹")
			D6EPXm1M5nx = qNZKwi2M1S4fBzGQYrmPnea(u"࠶ᙱ")
			EhAKamnelG = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠷ᙲ")
		zRM3tZx2v6DjJU(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡓࡕࡔࡊࡅࡈࠫᆒ"),IJ6VkihabRm(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭ᆓ")+str(jaAONFoI2r3)+xxpPYJOnoAUrlBzyveui(u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᆔ")+str(BvY2nJaXeWMPAyHDrmQRg9jK)+IJ6VkihabRm(u"ࠧࠡ࡟ࠪᆕ"))
		kdWCpE9TjNh,T6lOkGEp1KcWCH2FiyfvbMBhNudn = lunVJF2G5bZMgTcCje0vaIB371SX(u"࠰ᙳ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"࠰ᙳ")
		for B5uUMHex2L0W6b in range(D6EPXm1M5nx):
			Eudgv5cTUHF2AzKpkx = iPmj7p45q2duSAQaHvOnT.copy()
			if jaAONFoI2r3: Eudgv5cTUHF2AzKpkx[v7reLlOXCgD5pZ14w2tUA(u"ࠨࡔࡤࡲ࡬࡫ࠧᆖ")] = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩᆗ")+njqaA6gvwItUmcP2TQ7liRGr1FSZ[B5uUMHex2L0W6b]
			djr0g3VkMzo1ehxE = D0nOE8Wu9jfHxPTIXiLVypGB.get(Trt9xo75Lh,stream=dxAs4otSE98YmZnKy2iwRCB(u"ࡗࡶࡺ࡫᜺"),headers=Eudgv5cTUHF2AzKpkx,timeout=fcIm8tvxlXZsaEY3bwuG4B(u"࠴࠲࠳ᙴ"))
			for U3XhZW5TDgv9afrANE4mY0I in djr0g3VkMzo1ehxE.iter_content(chunk_size=A0HBTij1koLlYtbS8):
				if smMzArf4FkJ1NDKEx.iscanceled():
					zRM3tZx2v6DjJU(L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆘ"),zOZvXaebGNwHKfjRA(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫᆙ"))
					break
				kdWCpE9TjNh += EhAKamnelG
				KKMdNrcWXLt += U3XhZW5TDgv9afrANE4mY0I
				if not T6lOkGEp1KcWCH2FiyfvbMBhNudn: T6lOkGEp1KcWCH2FiyfvbMBhNudn = len(U3XhZW5TDgv9afrANE4mY0I)
				if BvY2nJaXeWMPAyHDrmQRg9jK: Qm8DTfKEUrdMvXzO7(smMzArf4FkJ1NDKEx,xxpPYJOnoAUrlBzyveui(u"࠳࠳࠴ᙵ")*kdWCpE9TjNh//WIKOL4xFeGmz,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ᆚ"),str(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠴࠴࠵࠴࠰ᙶ")*T6lOkGEp1KcWCH2FiyfvbMBhNudn*kdWCpE9TjNh//A0HBTij1koLlYtbS8//d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠴࠴࠵࠴࠰ᙶ"))+zOZvXaebGNwHKfjRA(u"࠭ࠠ࠰ࠢࠪᆛ")+X5uhI4RHtUmC3zY7GSx2Jowp1BENbv+uhOkAKtLVv4XTy1nWE6(u"ࠧࠡࡏࡅࠫᆜ"))
				else: Qm8DTfKEUrdMvXzO7(smMzArf4FkJ1NDKEx,T6lOkGEp1KcWCH2FiyfvbMBhNudn*kdWCpE9TjNh//A0HBTij1koLlYtbS8,DKqQekNtF6WlJLhBP9M5ca(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ᆝ"),str(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵࠵࠶࠮࠱ᙷ")*T6lOkGEp1KcWCH2FiyfvbMBhNudn*kdWCpE9TjNh//A0HBTij1koLlYtbS8//lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵࠵࠶࠮࠱ᙷ"))+DKqQekNtF6WlJLhBP9M5ca(u"ࠩࠣࡑࡇ࠭ᆞ"))
			djr0g3VkMzo1ehxE.close()
		smMzArf4FkJ1NDKEx.close()
		if len(KKMdNrcWXLt)<BvY2nJaXeWMPAyHDrmQRg9jK and BvY2nJaXeWMPAyHDrmQRg9jK>uhOkAKtLVv4XTy1nWE6(u"࠵ᙸ"):
			zRM3tZx2v6DjJU(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆟ"),KbL94nDHufSF0VcO2Nk3(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧᆠ")+str(len(KKMdNrcWXLt)//vjaYg08OXptG9rx4z67WKhB)+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪᆡ")+X5uhI4RHtUmC3zY7GSx2Jowp1BENbv+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࠠࡎࡄࠣࡡࠬᆢ"))
			FFwQqPEoCp = GjZltWoCxuIwNfQ7EH9(uhOkAKtLVv4XTy1nWE6(u"ࠧࠨᆣ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠨว็฾ฬว้ࠠะิ์ั࠭ᆤ"),Vv0lSjAOHLfMnam3wtdor(u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩᆥ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬᆦ"),Vv0lSjAOHLfMnam3wtdor(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆧ"),zOZvXaebGNwHKfjRA(u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩᆨ")+str(len(KKMdNrcWXLt)//vjaYg08OXptG9rx4z67WKhB)+GGTRaYBDeNyI25zlF(u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬᆩ")+X5uhI4RHtUmC3zY7GSx2Jowp1BENbv+zOZvXaebGNwHKfjRA(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩᆪ"))
			if FFwQqPEoCp==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠸ᙹ"): KKMdNrcWXLt = W6ndv5PCbAh(Trt9xo75Lh,iPmj7p45q2duSAQaHvOnT,showDialogs)
			elif FFwQqPEoCp==xxpPYJOnoAUrlBzyveui(u"࠱ᙺ"): zRM3tZx2v6DjJU(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࡐࡒࡘࡎࡉࡅࠨᆫ"),OARzhnB9o7uYvQGFaIcZ(u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨᆬ"))
			else: return ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࠫᆭ")
			if not KKMdNrcWXLt: return zOZvXaebGNwHKfjRA(u"ࠫࠬᆮ")
		else: zRM3tZx2v6DjJU(KbL94nDHufSF0VcO2Nk3(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆯ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪᆰ")+X5uhI4RHtUmC3zY7GSx2Jowp1BENbv+DKqQekNtF6WlJLhBP9M5ca(u"ࠧࠡࡏࡅࠤࡢ࠭ᆱ"))
	return KKMdNrcWXLt
def FFCJXmSiNjcTG2bV(mm5vCBc4DOz2Fj):
	return djr0g3VkMzo1ehxE
def tRibZg70df5IVmvGWwAXuM14lncz(ip=d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠩᆲ")):
	Q8ipsvbOFMDIhjmC6tAW1cw5qdyEXR,opOrMkINsZbSfcP8wYRzayFt,NXTypmHorJt,dvDlR1QuJxg5ynjre,iF4EcUDG97g8NK0r,otxKsceaC7MVqm3DGZAzyipN6T = qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࠪᆳ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࠫᆴ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࠬᆵ"),p1lrNRIXqLQJznH6O(u"ࠬ࠭ᆶ"),q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧᆷ"),xxpPYJOnoAUrlBzyveui(u"ࠧࠨᆸ")
	DDRulV7aKN3jCOWSBQkb95 = iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫᆹ")+ip+IJ6VkihabRm(u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧᆺ")
	iPmj7p45q2duSAQaHvOnT = {zOZvXaebGNwHKfjRA(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᆻ"):Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࠬᆼ")}
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,ddK4MmwpX5oG(u"ࠬࡍࡅࡕࠩᆽ"),DDRulV7aKN3jCOWSBQkb95,KbL94nDHufSF0VcO2Nk3(u"࠭ࠧᆾ"),iPmj7p45q2duSAQaHvOnT,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࠨᆿ"),v7reLlOXCgD5pZ14w2tUA(u"ࠨࠩᇀ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬᇁ"))
	if not djr0g3VkMzo1ehxE.succeeded: PPFwCokDceHzlibVnvsNUMgfyEau = ip+DKqQekNtF6WlJLhBP9M5ca(u"ࠪ࠰ࠬᇂ")+Q8ipsvbOFMDIhjmC6tAW1cw5qdyEXR+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫ࠱࠭ᇃ")+opOrMkINsZbSfcP8wYRzayFt+q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬ࠲ࠧᇄ")+dvDlR1QuJxg5ynjre+L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠬࠨᇅ")+iF4EcUDG97g8NK0r+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧ࠭ࠩᇆ")+otxKsceaC7MVqm3DGZAzyipN6T
	else:
		RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
		RkLE6BzZ2KX = QPuHKNAT4jmCRg.findall(DKqQekNtF6WlJLhBP9M5ca(u"ࠨ࡞ࡾ࠲࠯ࡅ࡜ࡾ࡞ࢀࠫᇇ"),RkLE6BzZ2KX,QPuHKNAT4jmCRg.DOTALL)
		if RkLE6BzZ2KX:
			RkLE6BzZ2KX = RkLE6BzZ2KX[p1lrNRIXqLQJznH6O(u"࠱ᙻ")]
			jmWrxnCBVXkhoMSQl35aEd1cY = kMLWTt2fO9dnGDUgHh(HMO0QciekqVpLKmA(u"ࠩࡧ࡭ࡨࡺࠧᇈ"),RkLE6BzZ2KX)
			JJzRlLgKeEjfU = list(jmWrxnCBVXkhoMSQl35aEd1cY.keys())
			if xxBJoKG54uwQ(u"ࠪ࡭ࡵ࠭ᇉ") in JJzRlLgKeEjfU: ip = jmWrxnCBVXkhoMSQl35aEd1cY[ddK4MmwpX5oG(u"ࠫ࡮ࡶࠧᇊ")]
			if xxBJoKG54uwQ(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨᇋ") in JJzRlLgKeEjfU: Q8ipsvbOFMDIhjmC6tAW1cw5qdyEXR = jmWrxnCBVXkhoMSQl35aEd1cY[dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᇌ")]
			if V391t7nQWUBR5euCkJ(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᇍ") in JJzRlLgKeEjfU: opOrMkINsZbSfcP8wYRzayFt = jmWrxnCBVXkhoMSQl35aEd1cY[V391t7nQWUBR5euCkJ(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᇎ")]
			if v7reLlOXCgD5pZ14w2tUA(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨᇏ") in JJzRlLgKeEjfU: NXTypmHorJt = jmWrxnCBVXkhoMSQl35aEd1cY[vkMRnTNV9jFm(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᇐ")]
			if lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫᇑ") in JJzRlLgKeEjfU: dvDlR1QuJxg5ynjre = jmWrxnCBVXkhoMSQl35aEd1cY[IJ6VkihabRm(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᇒ")]
			if a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡣࡪࡶࡼࠫᇓ") in JJzRlLgKeEjfU: iF4EcUDG97g8NK0r = jmWrxnCBVXkhoMSQl35aEd1cY[gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࡤ࡫ࡷࡽࠬᇔ")]
			if u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᇕ") in JJzRlLgKeEjfU:
				otxKsceaC7MVqm3DGZAzyipN6T = jmWrxnCBVXkhoMSQl35aEd1cY[fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫᇖ")][xxBJoKG54uwQ(u"ࠪࡹࡹࡩࠧᇗ")]
				if otxKsceaC7MVqm3DGZAzyipN6T[fcIm8tvxlXZsaEY3bwuG4B(u"࠲ᙼ")] not in [uhOkAKtLVv4XTy1nWE6(u"ࠫ࠲࠭ᇘ"),p1lrNRIXqLQJznH6O(u"ࠬ࠱ࠧᇙ")]: otxKsceaC7MVqm3DGZAzyipN6T = fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࠫࠨᇚ")+otxKsceaC7MVqm3DGZAzyipN6T
			PPFwCokDceHzlibVnvsNUMgfyEau = ip+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧ࠭ࠩᇛ")+Q8ipsvbOFMDIhjmC6tAW1cw5qdyEXR+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨ࠮ࠪᇜ")+opOrMkINsZbSfcP8wYRzayFt+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩ࠯ࠫᇝ")+dvDlR1QuJxg5ynjre+HMO0QciekqVpLKmA(u"ࠪ࠰ࠬᇞ")+iF4EcUDG97g8NK0r+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫ࠱࠭ᇟ")+otxKsceaC7MVqm3DGZAzyipN6T
			if Nnxm30dfoBWRYpIC7KsQGl: PPFwCokDceHzlibVnvsNUMgfyEau = PPFwCokDceHzlibVnvsNUMgfyEau.encode(L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡻࡴࡧ࠺ࠪᇠ")).decode(fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧᇡ"))
	PPFwCokDceHzlibVnvsNUMgfyEau = kWfpQA7tTjSPyLbNIeMr1Hui5(PPFwCokDceHzlibVnvsNUMgfyEau)
	return PPFwCokDceHzlibVnvsNUMgfyEau
def Gq9cSoCJU2p1e3T4MFkdWQvuD(rcR7Z8QnWKGPoMaUJeYEjTC2):
	u6oHpfXZes8rh,showDialogs = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࠨᇢ"),xxpPYJOnoAUrlBzyveui(u"ࡘࡷࡻࡥ᜻")
	if rcR7Z8QnWKGPoMaUJeYEjTC2.count(xxpPYJOnoAUrlBzyveui(u"ࠨࡡࠪᇣ"))>=vkMRnTNV9jFm(u"࠵ᙽ"):
		rcR7Z8QnWKGPoMaUJeYEjTC2,u6oHpfXZes8rh = rcR7Z8QnWKGPoMaUJeYEjTC2.split(zOZvXaebGNwHKfjRA(u"ࠩࡢࠫᇤ"),V391t7nQWUBR5euCkJ(u"࠵ᙾ"))
		u6oHpfXZes8rh = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡣࠬᇥ")+u6oHpfXZes8rh
		if ZpH2IWt7veyFobTsAnhi41(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᇦ") in u6oHpfXZes8rh: showDialogs = IJ6VkihabRm(u"ࡋࡧ࡬ࡴࡧ᜼")
		else: showDialogs = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࡚ࡲࡶࡧ᜽")
	return rcR7Z8QnWKGPoMaUJeYEjTC2,u6oHpfXZes8rh,showDialogs
def poQSnU831cKyYaW9IMfeFt2g():
	cRYSn9hOXfyTW3bVirFwvKL61s = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,v7reLlOXCgD5pZ14w2tUA(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᇧ"))
	NlwZ7X0p9jRJut48UdQmce6qy5HL = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠵ᙿ")
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(cRYSn9hOXfyTW3bVirFwvKL61s):
		for l0uAW3wIvSC in YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(cRYSn9hOXfyTW3bVirFwvKL61s):
			if Vv0lSjAOHLfMnam3wtdor(u"࠭࠮ࡱࡻࡲࠫᇨ") in l0uAW3wIvSC: continue
			if xxpPYJOnoAUrlBzyveui(u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬᇩ") in l0uAW3wIvSC: continue
			Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(cRYSn9hOXfyTW3bVirFwvKL61s,l0uAW3wIvSC)
			Ke9kQrDVvBJ5Ao7yMFz84iChj,KDxoah0WRdY1 = jGA1fuPNEcDJC7TFb9xhO30R(Xfdxjp12ou5mLngcTQyMI3BJUEV6Ps)
			NlwZ7X0p9jRJut48UdQmce6qy5HL += Ke9kQrDVvBJ5Ao7yMFz84iChj
	return NlwZ7X0p9jRJut48UdQmce6qy5HL
def gkL8loKHRfJyQCYNz0ESU(aq06Wbp7PVnGxrw3ZANXvLkDyK9,showDialogs):
	zz8l7PSFoTKUkabR3jIuq = fQ6kvwg1FrYAzXjbLT.getSetting(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ᇪ"))
	ypq2GsOQCfaD8K = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡶࡸࡷ࠭ᇫ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᇬ"),DDS79jdWzLtE(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᇭ"))
	kkiSE15zgZP9dF7R,xn1SEUu72c = zz8l7PSFoTKUkabR3jIuq,ypq2GsOQCfaD8K
	aZHU7R3LyFPn4eptSzb9fdhKOjT,JMPrevuN2QRs1oj0Xhbq9 = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬ࠭ᇮ"),dxAs4otSE98YmZnKy2iwRCB(u"࠭ࠧᇯ")
	if not aq06Wbp7PVnGxrw3ZANXvLkDyK9 or not ypq2GsOQCfaD8K or zz8l7PSFoTKUkabR3jIuq in [xxpPYJOnoAUrlBzyveui(u"ࠧࠨᇰ"),xxBJoKG54uwQ(u"ࠨࡇࡕࡖࡔࡘࠧᇱ")]:
		DDRulV7aKN3jCOWSBQkb95 = EGcFon0zR4mSL1[gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩᇲ")][ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠹ ")]
		wn0kd1pEgfSy4YG = Dx3jCK6X7lktdiE(p1lrNRIXqLQJznH6O(u"࠳࠳ᚁ"),aq06Wbp7PVnGxrw3ZANXvLkDyK9)
		PPFwCokDceHzlibVnvsNUMgfyEau = tRibZg70df5IVmvGWwAXuM14lncz()
		opOrMkINsZbSfcP8wYRzayFt = PPFwCokDceHzlibVnvsNUMgfyEau.split(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪ࠰ࠬᇳ"))[KbL94nDHufSF0VcO2Nk3(u"࠳ᚂ")]
		NlwZ7X0p9jRJut48UdQmce6qy5HL = poQSnU831cKyYaW9IMfeFt2g()
		G2fV3SCnXjM9F0Qrpd7t = {iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࡺࡹࡥࡳࠩᇴ"):wn0kd1pEgfSy4YG,p1lrNRIXqLQJznH6O(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᇵ"):uVp7krjL48oWd3tqGYCRz5M,IJ6VkihabRm(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᇶ"):opOrMkINsZbSfcP8wYRzayFt,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡪࡦࡶࠫᇷ"):AkEMLcQGwo0qnlB8VJeKiUTpX(NlwZ7X0p9jRJut48UdQmce6qy5HL)}
		djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(vfj1VHSBpIks9JhLGmr,fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡒࡒࡗ࡙࠭ᇸ"),DDRulV7aKN3jCOWSBQkb95,G2fV3SCnXjM9F0Qrpd7t,vkMRnTNV9jFm(u"ࠩࠪᇹ"),uhOkAKtLVv4XTy1nWE6(u"ࠪࠫᇺ"),V391t7nQWUBR5euCkJ(u"ࠫࠬᇻ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩᇼ"))
		if not djr0g3VkMzo1ehxE.succeeded: kkiSE15zgZP9dF7R = qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࡅࡓࡔࡒࡖࠬᇽ")
		else:
			tcUqdifBDLv60W = djr0g3VkMzo1ehxE.content
			tcUqdifBDLv60W = kMLWTt2fO9dnGDUgHh(GGTRaYBDeNyI25zlF(u"ࠧ࡭࡫ࡶࡸࠬᇾ"),tcUqdifBDLv60W)
			tcUqdifBDLv60W = sorted(tcUqdifBDLv60W,reverse=q0JfWbP8vACLxSNIncpOXkR6j(u"ࡔࡳࡷࡨ᜾"),key=lambda key: int(key[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠲ᚃ")]))
			JMPrevuN2QRs1oj0Xhbq9,xn1SEUu72c = uhOkAKtLVv4XTy1nWE6(u"ࠨࠩᇿ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࠪሀ")
			for vjI6MkACbNq7f5E8zHcuKw1GR,yuUOh9bfBSNHJtoPz3L6lQ,hTZjiRxwmYoWpKtJIHVug36G in tcUqdifBDLv60W:
				if vjI6MkACbNq7f5E8zHcuKw1GR==ddK4MmwpX5oG(u"ࠪ࠴ࠬሁ"):
					JMPrevuN2QRs1oj0Xhbq9 += hTZjiRxwmYoWpKtJIHVug36G+IJ6VkihabRm(u"ࠫ࠿ࡀࠧሂ")
					continue
				if xn1SEUu72c: xn1SEUu72c += iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭ሃ")
				Pnsmt20lAqxZI3 = hTZjiRxwmYoWpKtJIHVug36G.split(GGTRaYBDeNyI25zlF(u"࠭࡜࡯ࠩሄ"))[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠳ᚄ")]
				jj6acsmeo0NHJY7X4GFwIiU9Tx = Vv0lSjAOHLfMnam3wtdor(u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫህ") if yuUOh9bfBSNHJtoPz3L6lQ else d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠩሆ")
				xn1SEUu72c += hTZjiRxwmYoWpKtJIHVug36G.replace(Pnsmt20lAqxZI3,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬሇ")+Pnsmt20lAqxZI3+jj6acsmeo0NHJY7X4GFwIiU9Tx+fcIm8tvxlXZsaEY3bwuG4B(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬለ"))+p1lrNRIXqLQJznH6O(u"ࠫࡡࡴࠧሉ")
			xn1SEUu72c = DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡢ࡮ࠨሊ")+xn1SEUu72c+p1lrNRIXqLQJznH6O(u"࠭࡜࡯࡞ࡱࠫላ")
			JMPrevuN2QRs1oj0Xhbq9 = JMPrevuN2QRs1oj0Xhbq9.strip(qNZKwi2M1S4fBzGQYrmPnea(u"ࠧ࠻࠼ࠪሌ"))
			aZHU7R3LyFPn4eptSzb9fdhKOjT = fQ6kvwg1FrYAzXjbLT.getSetting(zOZvXaebGNwHKfjRA(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵࠪል"))
			if xn1SEUu72c!=ypq2GsOQCfaD8K or zz8l7PSFoTKUkabR3jIuq in [a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࠪሎ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠪࡉࡗࡘࡏࡓࠩሏ")]: kkiSE15zgZP9dF7R = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡓࡋࡗࠨሐ")
			mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,HMO0QciekqVpLKmA(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨሑ"),p1lrNRIXqLQJznH6O(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨሒ"),xn1SEUu72c,VYn9o683LCcspE7Jew5gMQrZbj)
			fQ6kvwg1FrYAzXjbLT.setSetting(ZpH2IWt7veyFobTsAnhi41(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴࠩሓ"),JMPrevuN2QRs1oj0Xhbq9)
			fQ6kvwg1FrYAzXjbLT.setSetting(OARzhnB9o7uYvQGFaIcZ(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሔ"),AkEMLcQGwo0qnlB8VJeKiUTpX(Low1uSVG5OcafJmrYBC7D))
	if showDialogs:
		if kkiSE15zgZP9dF7R==tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࡈࡖࡗࡕࡒࠨሕ"):
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(zOZvXaebGNwHKfjRA(u"ࠪࠫሖ"),xxBJoKG54uwQ(u"ࠫࠬሗ"),Vv0lSjAOHLfMnam3wtdor(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨመ"),HMO0QciekqVpLKmA(u"࠭็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢํ็ํ์ࠠิสห๋ฬࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦวๅำส์ฯืࠠศๆัหฺࠦศไࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆฦื้อใࠡ฻้ำ่࠭ሙ"))
		else:
			qQL7e23RtCg4xOpf(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ሚ"),v7reLlOXCgD5pZ14w2tUA(u"ࠨำึหห๊ࠠๆ่ࠣห้๋ศา็ฯࠤส๊้ࠡ็ึฮำีๅ๋ࠢส่อืๆศ็ฯࠫማ"),xn1SEUu72c,ddK4MmwpX5oG(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪሜ"))
			kkiSE15zgZP9dF7R = xxpPYJOnoAUrlBzyveui(u"ࠪࡓࡑࡊࠧም")
	if kkiSE15zgZP9dF7R!=zz8l7PSFoTKUkabR3jIuq:
		fQ6kvwg1FrYAzXjbLT.setSetting(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሞ"),kkiSE15zgZP9dF7R)
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(ZpH2IWt7veyFobTsAnhi41(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩሟ"))
	vofQLAVmKBw0O4kpi52cetRz = v7reLlOXCgD5pZ14w2tUA(u"ࡖࡵࡹࡪᝀ") if JMPrevuN2QRs1oj0Xhbq9!=aZHU7R3LyFPn4eptSzb9fdhKOjT else uhOkAKtLVv4XTy1nWE6(u"ࡇࡣ࡯ࡷࡪ᜿")
	return vofQLAVmKBw0O4kpi52cetRz
def gjUBboyawT4ZlRW0M3(zfSh8JxwD9AFiG2e5l,rracq9NlRupJh30ZixLbYVKTEGP6):
	from socket import socket as HKIPWB4JXYaEu6,AF_INET as LFgRCWvkM8hAD,SOCK_STREAM as KlXvBMj7oFRhLxW3OpCI2s
	kicW9IrCgpV5PwOnGhLFBm4b3dA = HKIPWB4JXYaEu6(LFgRCWvkM8hAD,KlXvBMj7oFRhLxW3OpCI2s)
	kicW9IrCgpV5PwOnGhLFBm4b3dA.settimeout(q0JfWbP8vACLxSNIncpOXkR6j(u"࠵ᚅ"))
	IIcLHvlEpRSxtdO3iWJqBQ169o0,l5S8j6Wrq4biVwHdxGe2UoRD0LsYZ = qNZKwi2M1S4fBzGQYrmPnea(u"ࡗࡶࡺ࡫ᝁ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠵ᚆ")
	g27TaovWhPEzbHsY39Bw = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
	try: kicW9IrCgpV5PwOnGhLFBm4b3dA.connect((zfSh8JxwD9AFiG2e5l,rracq9NlRupJh30ZixLbYVKTEGP6))
	except: IIcLHvlEpRSxtdO3iWJqBQ169o0 = p1lrNRIXqLQJznH6O(u"ࡊࡦࡲࡳࡦᝂ")
	N1ErdyMWIUaLnzPY = vODi7LQeCnUaoRqZX9xs6djwm0tJA2.time()
	if IIcLHvlEpRSxtdO3iWJqBQ169o0: l5S8j6Wrq4biVwHdxGe2UoRD0LsYZ = N1ErdyMWIUaLnzPY-g27TaovWhPEzbHsY39Bw
	return l5S8j6Wrq4biVwHdxGe2UoRD0LsYZ
def tb6VfQWohldXaqIvCYiw(showDialogs):
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࠧሠ"),v7reLlOXCgD5pZ14w2tUA(u"ࠧࠨሡ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨࠩሢ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬሣ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡ฻่่๏ฯࠠศๆอ๊฽๐แࠡษ็ฦ๋ࠦฟࠢࠩሤ"))
	else: T4TGmZ9XWAzONaKygic = tKVplxqYIdngGF6TZkXeb2PiwfME(u"࡙ࡸࡵࡦᝃ")
	if T4TGmZ9XWAzONaKygic==tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠷ᚇ"):
		for l0uAW3wIvSC in YcJmC0W43u5idIELnHTU2XSsMPNt.listdir(vBXJAQCwEpS0xZ6km9a):
			if l0uAW3wIvSC.endswith(ddK4MmwpX5oG(u"ࠫ࠳ࡪࡢࠨሥ")) and v7reLlOXCgD5pZ14w2tUA(u"ࠬࡪࡡࡵࡣࠪሦ") in l0uAW3wIvSC:
				RJpWL3qSwhg = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(vBXJAQCwEpS0xZ6km9a,l0uAW3wIvSC)
				try: qcOU43biDkaPQlZMB1wHEj,K2DlNXvQC65FzngUVyk3IGAq = ssVj9vLP2FS(RJpWL3qSwhg)
				except: return
				K2DlNXvQC65FzngUVyk3IGAq.execute(xxpPYJOnoAUrlBzyveui(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩሧ"))
				K2DlNXvQC65FzngUVyk3IGAq.execute(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪረ"))
				K2DlNXvQC65FzngUVyk3IGAq.execute(HMO0QciekqVpLKmA(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩሩ"))
				qcOU43biDkaPQlZMB1wHEj.commit()
				qcOU43biDkaPQlZMB1wHEj.close()
		if showDialogs:
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࠪሪ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࠫራ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሬ"),zOZvXaebGNwHKfjRA(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ር"))
	return
def iBTbm82l5KZSGJN6t3(GFjtPKrUYA7pbLw,tM3UDEK856,showDialogs):
	if GFjtPKrUYA7pbLw!=None:
		global j3AZ6GQ84iwLNlecbhBHRs
		j3AZ6GQ84iwLNlecbhBHRs = GFjtPKrUYA7pbLw
	if tM3UDEK856!=None:
		global UIzad134qC8Av7nEOl
		UIzad134qC8Av7nEOl = tM3UDEK856
	if showDialogs!=None:
		global gaUxNbd2Rq
		gaUxNbd2Rq = showDialogs
	return
j3AZ6GQ84iwLNlecbhBHRs,UIzad134qC8Av7nEOl,gaUxNbd2Rq = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࠧሮ"),ddK4MmwpX5oG(u"ࠧࠨሯ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨࠩሰ")
def e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y,ELYSOBmvzgoX2u53=DKqQekNtF6WlJLhBP9M5ca(u"ࠩࠪሱ"),adHF267eXilBUAPhgjSL0R3=HMO0QciekqVpLKmA(u"ࠪࠫሲ")):
	global EGcFon0zR4mSL1
	if showDialogs==zOZvXaebGNwHKfjRA(u"ࠫࠬሳ"): showDialogs = HMO0QciekqVpLKmA(u"࡚ࡲࡶࡧᝄ") if gaUxNbd2Rq==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬ࠭ሴ") else gaUxNbd2Rq
	if adHF267eXilBUAPhgjSL0R3==q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠧስ"): adHF267eXilBUAPhgjSL0R3 = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࡔࡳࡷࡨᝅ") if UIzad134qC8Av7nEOl==KbL94nDHufSF0VcO2Nk3(u"ࠧࠨሶ") else UIzad134qC8Av7nEOl
	if ELYSOBmvzgoX2u53==ddK4MmwpX5oG(u"ࠨࠩሷ"): ELYSOBmvzgoX2u53 = KbL94nDHufSF0VcO2Nk3(u"ࡕࡴࡸࡩᝆ") if j3AZ6GQ84iwLNlecbhBHRs==q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࠪሸ") else j3AZ6GQ84iwLNlecbhBHRs
	if bbOwTfLHWEY==v7reLlOXCgD5pZ14w2tUA(u"ࠪࠫሹ"): ONzqvQm5TFMsPhdk7gRUp = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡖࡵࡹࡪᝇ")
	else: ONzqvQm5TFMsPhdk7gRUp = bbOwTfLHWEY
	if ZEJAFRNxIrQSU==None: BF8XfchlgKmOE0ru2 = None
	elif ZEJAFRNxIrQSU==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠬሺ"): BF8XfchlgKmOE0ru2 = {}
	else: BF8XfchlgKmOE0ru2 = ZEJAFRNxIrQSU
	if iPmj7p45q2duSAQaHvOnT==None: Eudgv5cTUHF2AzKpkx = None
	elif iPmj7p45q2duSAQaHvOnT==xxBJoKG54uwQ(u"ࠬ࠭ሻ"): Eudgv5cTUHF2AzKpkx = {}
	else: Eudgv5cTUHF2AzKpkx = iPmj7p45q2duSAQaHvOnT
	NVjGc0r9h2godfPB = list(Eudgv5cTUHF2AzKpkx.keys())
	if KbL94nDHufSF0VcO2Nk3(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪሼ") not in NVjGc0r9h2godfPB: Eudgv5cTUHF2AzKpkx[zOZvXaebGNwHKfjRA(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫሽ")] = vkMRnTNV9jFm(u"ࠨࡂࡃࡄࡘࡑࡉࡑࡡࡋࡉࡆࡊࡅࡓࡂࡃࡄࠬሾ")
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ppim7Ofn2Nx,otFfgXKET5vz3YV0lI6,bZ5puKhzrkQcvRiqV0XgP3JxNLST = llpngAoQVzND(DDRulV7aKN3jCOWSBQkb95)
	SAxhNOBlQazEiXKFbIk2yZ7qRTY905 = fQ6kvwg1FrYAzXjbLT.getSetting(fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩሿ"))
	FDKOt1Gm0LYR = fQ6kvwg1FrYAzXjbLT.getSetting(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ቀ"))
	PlsMeTIwxmcAO = fQ6kvwg1FrYAzXjbLT.getSetting(fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩቁ"))
	nfTOxvjIMHZPiqRoGF6S = (ppim7Ofn2Nx==None and otFfgXKET5vz3YV0lI6==None)
	kkvPdlNBOK6ems3wRZMhnLAgaX = EGcFon0zR4mSL1[ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬቂ")]
	bgMk9J2Be06hwyROn = lZqkuhgaBHSVX8NItKG05cdLJe7Ao in kkvPdlNBOK6ems3wRZMhnLAgaX
	yvfJZwS0hl5G8rgqW6M = EGcFon0zR4mSL1[v7reLlOXCgD5pZ14w2tUA(u"࠭ࡒࡆࡒࡒࡗࠬቃ")]
	wVP2J80kxiOURstGalg = lZqkuhgaBHSVX8NItKG05cdLJe7Ao in yvfJZwS0hl5G8rgqW6M
	l0ezoGxwkNrdP8EFZ7Q1numaW2O = bgMk9J2Be06hwyROn or wVP2J80kxiOURstGalg
	if nfTOxvjIMHZPiqRoGF6S and l0ezoGxwkNrdP8EFZ7Q1numaW2O:
		if bgMk9J2Be06hwyROn:
			Jg80XdOY4hLpkol9T1ez2 = kkvPdlNBOK6ems3wRZMhnLAgaX.index(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
			ITlrWqMFhCGxyE9JpKu7m8DP = EGcFon0zR4mSL1[Vv0lSjAOHLfMnam3wtdor(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫቄ")][Jg80XdOY4hLpkol9T1ez2]
			c5qxjReiDAzVgBwpZ2yonKYOW = zDemIpoFb2UJkGLZQ4[Jg80XdOY4hLpkol9T1ez2]
		elif wVP2J80kxiOURstGalg:
			Jg80XdOY4hLpkol9T1ez2 = yvfJZwS0hl5G8rgqW6M.index(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
			ITlrWqMFhCGxyE9JpKu7m8DP = EGcFon0zR4mSL1[HMO0QciekqVpLKmA(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫቅ")][Jg80XdOY4hLpkol9T1ez2]
			c5qxjReiDAzVgBwpZ2yonKYOW = ggnJ1x5MSbshUDzXt06WcPrfl[Jg80XdOY4hLpkol9T1ez2]
	if otFfgXKET5vz3YV0lI6==qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࠪቆ"): otFfgXKET5vz3YV0lI6 = SAxhNOBlQazEiXKFbIk2yZ7qRTY905
	elif otFfgXKET5vz3YV0lI6==None and FDKOt1Gm0LYR in [qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡅ࡚࡚ࡏࠨቇ"),KbL94nDHufSF0VcO2Nk3(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ቈ")] and ELYSOBmvzgoX2u53: otFfgXKET5vz3YV0lI6 = SAxhNOBlQazEiXKFbIk2yZ7qRTY905
	gzi9KnXwC6G5x1c = lZqkuhgaBHSVX8NItKG05cdLJe7Ao==EGcFon0zR4mSL1[p1lrNRIXqLQJznH6O(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ቉")][q0JfWbP8vACLxSNIncpOXkR6j(u"࠷ᚈ")]
	IIL5G4cKvqJP1oblwHE = ppim7Ofn2Nx and fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡳࡤࡴࡤࡴࡪ࠭ቊ") in ppim7Ofn2Nx
	if IIL5G4cKvqJP1oblwHE: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = IJ6VkihabRm(u"࠷࠲ᚉ")
	elif bgMk9J2Be06hwyROn or wVP2J80kxiOURstGalg: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = xxBJoKG54uwQ(u"࠳࠸ᚊ")
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y in jtJRLy3balg2pFK: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = p1lrNRIXqLQJznH6O(u"࠴࠴ᚋ")
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y==qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩቋ"): GUSviMX7rNBgwVdbtf8p3ZEhaR0 = v7reLlOXCgD5pZ14w2tUA(u"࠶࠵ᚌ")
	elif oBQqw316KAIpOdr7R0LxkZNW5lG4y==tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩቌ"): GUSviMX7rNBgwVdbtf8p3ZEhaR0 = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠷࠶ᚍ")
	elif IJ6VkihabRm(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫቍ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠽࠰ᚎ")
	elif d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡗࡍࡕࡆࡉࡃࠪ቎") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = ddK4MmwpX5oG(u"࠷࠶ᚏ")
	elif p1lrNRIXqLQJznH6O(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ቏") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠳࠷ᚐ")
	elif tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡇࡈࡘࡃࡎࠫቐ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = qNZKwi2M1S4fBzGQYrmPnea(u"࠴࠳ᚑ")
	elif zOZvXaebGNwHKfjRA(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩቑ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = f8PVRTseIuj9BckO6GoyF5Lxv(u"࠵࠴ᚒ")
	elif L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ቒ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = dxAs4otSE98YmZnKy2iwRCB(u"࠷࠵ᚓ")
	elif DDS79jdWzLtE(u"ࠨࡃࡎࡓࡆࡓࠧቓ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠷࠻ᚔ")
	elif GGTRaYBDeNyI25zlF(u"ࠩࡄࡏ࡜ࡇࡍࠨቔ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = p1lrNRIXqLQJznH6O(u"࠹࠰ᚕ")
	elif ddK4MmwpX5oG(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬቕ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = q0JfWbP8vACLxSNIncpOXkR6j(u"࠲࠱ᚖ")
	elif GGTRaYBDeNyI25zlF(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ቖ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠷࠲ᚗ")
	else: GUSviMX7rNBgwVdbtf8p3ZEhaR0 = xxpPYJOnoAUrlBzyveui(u"࠳࠸ᚘ")
	if GGTRaYBDeNyI25zlF(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ቗") in oBQqw316KAIpOdr7R0LxkZNW5lG4y and not BF8XfchlgKmOE0ru2 and Vv0lSjAOHLfMnam3wtdor(u"࠭ࠦࠨቘ") not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao and Vv0lSjAOHLfMnam3wtdor(u"ࠧࡀࠩ቙") not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.rstrip(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠨ࠱ࠪቚ"))+Vv0lSjAOHLfMnam3wtdor(u"ࠩ࠲ࠫቛ")
	JgsVyBSMD2F3KuN = (ppim7Ofn2Nx!=None)
	HzxgWALEsfTvjONK71buCMlGQJePF = (otFfgXKET5vz3YV0lI6!=None and FDKOt1Gm0LYR!=tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡗ࡙ࡕࡐࠨቜ"))
	if JgsVyBSMD2F3KuN and not IIL5G4cKvqJP1oblwHE: uFCykYQW68S(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧቝ"),ppim7Ofn2Nx)
	elif HzxgWALEsfTvjONK71buCMlGQJePF: uFCykYQW68S(GGTRaYBDeNyI25zlF(u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬ቞"),otFfgXKET5vz3YV0lI6)
	if JgsVyBSMD2F3KuN:
		SiugcTfJZkP8KIrmxACOweoN3HQ5lR = {vkMRnTNV9jFm(u"ࠨࡨࡵࡶࡳࠦ቟"):ppim7Ofn2Nx,GGTRaYBDeNyI25zlF(u"ࠢࡩࡶࡷࡴࡸࠨበ"):ppim7Ofn2Nx}
		ffp5ZIvzcxajb6J1 = ppim7Ofn2Nx
	else: SiugcTfJZkP8KIrmxACOweoN3HQ5lR,ffp5ZIvzcxajb6J1 = {},GGTRaYBDeNyI25zlF(u"ࠨࠩቡ")
	if HzxgWALEsfTvjONK71buCMlGQJePF:
		import urllib3.util.connection as V46HmwyZFCk01plbaKd7QYhcr
		sNl76zMfepb3n = hpjE68oSiwr0LBCU(V46HmwyZFCk01plbaKd7QYhcr,SAxhNOBlQazEiXKFbIk2yZ7qRTY905)
	ijvJZPS2hX1lunbRxwsOTKNVpgEF,JohnQtKE9Gry14FwfgM,j13qZFY7B6kNM,jlUIZNwY1X,qmtaljwCkh5WYQEGg,verify = ONzqvQm5TFMsPhdk7gRUp,oBQqw316KAIpOdr7R0LxkZNW5lG4y,bB2eVZo9P8TpLU1Rw,fcIm8tvxlXZsaEY3bwuG4B(u"ࡉࡥࡱࡹࡥᝈ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࡉࡥࡱࡹࡥᝈ"),bZ5puKhzrkQcvRiqV0XgP3JxNLST
	if gzi9KnXwC6G5x1c: qmtaljwCkh5WYQEGg = zOZvXaebGNwHKfjRA(u"ࡘࡷࡻࡥᝉ")
	if l0ezoGxwkNrdP8EFZ7Q1numaW2O or ONzqvQm5TFMsPhdk7gRUp: ijvJZPS2hX1lunbRxwsOTKNVpgEF = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡋࡧ࡬ࡴࡧᝊ")
	if bgMk9J2Be06hwyROn: j13qZFY7B6kNM = zOZvXaebGNwHKfjRA(u"ࠩࡓࡓࡘ࡚ࠧቢ")
	TIvkgj7OxW6Vzb35il,rreason = -zOZvXaebGNwHKfjRA(u"࠴ᚙ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪባ")
	for kdWCpE9TjNh in range(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠽ᚚ")):
		W5hDksH9UqOdGSTvaP = Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࡚ࡲࡶࡧᝋ")
		BcMl3XdLS0zmK1jPvDJANfYH = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡆࡢ࡮ࡶࡩᝌ")
		try:
			if kdWCpE9TjNh: JohnQtKE9Gry14FwfgM = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠳ࡶࡸࠬቤ")
			if IIL5G4cKvqJP1oblwHE or not JgsVyBSMD2F3KuN: BEt0xkYQrnLpwZ4JaFUDM8oX5vAN(IJ6VkihabRm(u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡑࡓࡉࡓࡥࡕࡓࡎࠪብ"),lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,JohnQtKE9Gry14FwfgM,j13qZFY7B6kNM)
			try: djr0g3VkMzo1ehxE.close()
			except: pass
			lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao
			djr0g3VkMzo1ehxE = D0nOE8Wu9jfHxPTIXiLVypGB.request(j13qZFY7B6kNM,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,data=BF8XfchlgKmOE0ru2,headers=Eudgv5cTUHF2AzKpkx,verify=verify,allow_redirects=ijvJZPS2hX1lunbRxwsOTKNVpgEF,timeout=GUSviMX7rNBgwVdbtf8p3ZEhaR0,proxies=SiugcTfJZkP8KIrmxACOweoN3HQ5lR)
			if fcIm8tvxlXZsaEY3bwuG4B(u"࠸࠶࠰᚛")<=djr0g3VkMzo1ehxE.status_code<=qNZKwi2M1S4fBzGQYrmPnea(u"࠹࠹࠺᚜"):
				if not jlUIZNwY1X:
					c458gen2CyAOPb7asG0DUoYru = list(djr0g3VkMzo1ehxE.headers.keys())
					if u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨቦ") in c458gen2CyAOPb7asG0DUoYru: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = djr0g3VkMzo1ehxE.headers[HMO0QciekqVpLKmA(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩቧ")]
					elif zOZvXaebGNwHKfjRA(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪቨ") in c458gen2CyAOPb7asG0DUoYru: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = djr0g3VkMzo1ehxE.headers[KbL94nDHufSF0VcO2Nk3(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫቩ")]
					else: jlUIZNwY1X = KbL94nDHufSF0VcO2Nk3(u"ࡕࡴࡸࡩᝍ")
					if not jlUIZNwY1X: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.encode(vkMRnTNV9jFm(u"ࠪࡰࡦࡺࡩ࡯࠯࠴ࠫቪ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫቫ")).decode(Vv0lSjAOHLfMnam3wtdor(u"ࠬࡻࡴࡧ࠺ࠪቬ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ቭ"))
					if l0ezoGxwkNrdP8EFZ7Q1numaW2O and djr0g3VkMzo1ehxE.status_code==DKqQekNtF6WlJLhBP9M5ca(u"࠳࠱࠹᚝"):
						ijvJZPS2hX1lunbRxwsOTKNVpgEF = ONzqvQm5TFMsPhdk7gRUp
						j13qZFY7B6kNM = bB2eVZo9P8TpLU1Rw
						jlUIZNwY1X = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡖࡵࡹࡪᝎ")
						bBaNhF2f59RTgYJqdDQ403oCiZ7
				if not jlUIZNwY1X or ONzqvQm5TFMsPhdk7gRUp:
					if vkMRnTNV9jFm(u"ࠧࡩࡶࡷࡴࠬቮ") not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao:
						ympS917x6nz = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lc154VhT9DCqMk8,qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡷࡵࡰࠬቯ"))
						lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ympS917x6nz+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩ࠲ࠫተ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao.lstrip(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪ࠳ࠬቱ"))
				if not jlUIZNwY1X and ONzqvQm5TFMsPhdk7gRUp and H93DlbtKLEarfQ8w7GcoIukSexv0J(lZqkuhgaBHSVX8NItKG05cdLJe7Ao): f51fRcvx6QUgAVYheukLDXT
			elif DDS79jdWzLtE(u"࠷࠸࠴᚟")<=djr0g3VkMzo1ehxE.status_code<=V391t7nQWUBR5euCkJ(u"࠶࠻࠼᚞"):
				djr0g3VkMzo1ehxE.rreason = djr0g3VkMzo1ehxE.content
				qmtaljwCkh5WYQEGg = f8PVRTseIuj9BckO6GoyF5Lxv(u"ࡗࡶࡺ࡫ᝏ")
			lc154VhT9DCqMk8 = djr0g3VkMzo1ehxE.url
			TIvkgj7OxW6Vzb35il = djr0g3VkMzo1ehxE.status_code
			rreason = djr0g3VkMzo1ehxE.reason
			djr0g3VkMzo1ehxE.raise_for_status()
			BcMl3XdLS0zmK1jPvDJANfYH = HMO0QciekqVpLKmA(u"ࡘࡷࡻࡥᝐ")
		except D0nOE8Wu9jfHxPTIXiLVypGB.exceptions.HTTPError as L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA:
			pass
		except D0nOE8Wu9jfHxPTIXiLVypGB.exceptions.Timeout as L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA:
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: rreason = str(L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA.message).split(qNZKwi2M1S4fBzGQYrmPnea(u"ࠫ࠿ࠦࠧቲ"))[xxpPYJOnoAUrlBzyveui(u"࠴ᚠ")]
			else: rreason = str(L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA).split(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡀࠠࠨታ"))[ddK4MmwpX5oG(u"࠵ᚡ")]
		except D0nOE8Wu9jfHxPTIXiLVypGB.exceptions.ConnectionError as L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA:
			try:
				ezX76WkqKRxdtsvh = L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA.message[V391t7nQWUBR5euCkJ(u"࠵ᚢ")]
				rreason = ezX76WkqKRxdtsvh
				if Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ࡅࡳࡴࡱࡳࠬቴ") in ezX76WkqKRxdtsvh: TIvkgj7OxW6Vzb35il,rreason = QPuHKNAT4jmCRg.findall(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤት"),ezX76WkqKRxdtsvh)[u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶ᚣ")]
				elif GGTRaYBDeNyI25zlF(u"ࠨ࠮ࠣࡩࡷࡸ࡯ࡳࠪࠪቶ") in ezX76WkqKRxdtsvh: TIvkgj7OxW6Vzb35il,rreason = QPuHKNAT4jmCRg.findall(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧቷ"),ezX76WkqKRxdtsvh)[gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠰ᚤ")]
				elif ezX76WkqKRxdtsvh.count(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪ࠾ࠬቸ"))>=KbL94nDHufSF0VcO2Nk3(u"࠴ᚦ"): rreason,TIvkgj7OxW6Vzb35il = QPuHKNAT4jmCRg.findall(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠧቹ"),ezX76WkqKRxdtsvh)[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠱ᚥ")]
			except: pass
		except D0nOE8Wu9jfHxPTIXiLVypGB.exceptions.RequestException as L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA:
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: rreason = L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA.message
			else: rreason = str(L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA)
		except:
			W5hDksH9UqOdGSTvaP = dxAs4otSE98YmZnKy2iwRCB(u"ࡋࡧ࡬ࡴࡧᝑ")
			try: TIvkgj7OxW6Vzb35il = djr0g3VkMzo1ehxE.status_code
			except: pass
			try: rreason = djr0g3VkMzo1ehxE.reason
			except: pass
		rreason = str(rreason)
		zRM3tZx2v6DjJU(vkMRnTNV9jFm(u"ࠬࡔࡏࡕࡋࡆࡉࠬቺ"),ddK4MmwpX5oG(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫቻ")+str(TIvkgj7OxW6Vzb35il)+ddK4MmwpX5oG(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩቼ")+rreason+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪች")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+p1lrNRIXqLQJznH6O(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨቾ")+DDRulV7aKN3jCOWSBQkb95+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠤࡢ࠭ቿ"))
		if nfTOxvjIMHZPiqRoGF6S and l0ezoGxwkNrdP8EFZ7Q1numaW2O and W5hDksH9UqOdGSTvaP and not qmtaljwCkh5WYQEGg and TIvkgj7OxW6Vzb35il!=lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵࠴࠵ᚧ"):
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = ITlrWqMFhCGxyE9JpKu7m8DP
			qmtaljwCkh5WYQEGg = DKqQekNtF6WlJLhBP9M5ca(u"࡚ࡲࡶࡧᝒ")
			continue
		if W5hDksH9UqOdGSTvaP: break
	if otFfgXKET5vz3YV0lI6!=None and FDKOt1Gm0LYR!=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠫࡘ࡚ࡏࡑࠩኀ"): V46HmwyZFCk01plbaKd7QYhcr.create_connection = sNl76zMfepb3n
	if FDKOt1Gm0LYR==q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬࡇࡌࡘࡃ࡜ࡗࠬኁ") and ELYSOBmvzgoX2u53: otFfgXKET5vz3YV0lI6 = None
	if not BcMl3XdLS0zmK1jPvDJANfYH and ppim7Ofn2Nx==None and oBQqw316KAIpOdr7R0LxkZNW5lG4y not in jtJRLy3balg2pFK:
		CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
		if CeJXk5gb27o!=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩኂ"): GJtcqTv68ZQpwxYFiDg.stderr.write(CeJXk5gb27o)
	ykIAHx9E1umUdZqjSiBw6Kbar = HcLv5k0Ey9FG()
	ykIAHx9E1umUdZqjSiBw6Kbar.url = lc154VhT9DCqMk8
	try: Tnltuh8WrS = djr0g3VkMzo1ehxE.content
	except: Tnltuh8WrS = OARzhnB9o7uYvQGFaIcZ(u"ࠧࠨኃ")
	try: BvCbTl1dO9 = djr0g3VkMzo1ehxE.headers
	except: BvCbTl1dO9 = {}
	try: KUMGa1JyFh = djr0g3VkMzo1ehxE.cookies.get_dict()
	except: KUMGa1JyFh = {}
	try: djr0g3VkMzo1ehxE.close()
	except: pass
	if Nnxm30dfoBWRYpIC7KsQGl:
		try: Tnltuh8WrS = Tnltuh8WrS.decode(IJ6VkihabRm(u"ࠨࡷࡷࡪ࠽࠭ኄ"))
		except: pass
	TIvkgj7OxW6Vzb35il = int(TIvkgj7OxW6Vzb35il)
	ykIAHx9E1umUdZqjSiBw6Kbar.code = TIvkgj7OxW6Vzb35il
	ykIAHx9E1umUdZqjSiBw6Kbar.reason = rreason
	ykIAHx9E1umUdZqjSiBw6Kbar.content = Tnltuh8WrS
	ykIAHx9E1umUdZqjSiBw6Kbar.headers = BvCbTl1dO9
	ykIAHx9E1umUdZqjSiBw6Kbar.cookies = KUMGa1JyFh
	ykIAHx9E1umUdZqjSiBw6Kbar.succeeded = BcMl3XdLS0zmK1jPvDJANfYH
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM or isinstance(ykIAHx9E1umUdZqjSiBw6Kbar.content,str): NqvYW9nmj3CMupIcL6efxE8ho5Xb = ykIAHx9E1umUdZqjSiBw6Kbar.content.lower()
	else: NqvYW9nmj3CMupIcL6efxE8ho5Xb = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࠪኅ")
	YmT9oB2qsey6hJKFvXbDLkpa = (gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኆ") in NqvYW9nmj3CMupIcL6efxE8ho5Xb or HMO0QciekqVpLKmA(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫኇ") in NqvYW9nmj3CMupIcL6efxE8ho5Xb) and NqvYW9nmj3CMupIcL6efxE8ho5Xb.count(uhOkAKtLVv4XTy1nWE6(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨኈ"))>u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠶ᚨ") and fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ኉") not in oBQqw316KAIpOdr7R0LxkZNW5lG4y and dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩኊ") not in NqvYW9nmj3CMupIcL6efxE8ho5Xb and not IIL5G4cKvqJP1oblwHE
	if TIvkgj7OxW6Vzb35il==GGTRaYBDeNyI25zlF(u"࠷࠶࠰ᚩ") and YmT9oB2qsey6hJKFvXbDLkpa: ykIAHx9E1umUdZqjSiBw6Kbar.succeeded = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࡆࡢ࡮ࡶࡩᝓ")
	if ykIAHx9E1umUdZqjSiBw6Kbar.succeeded and nfTOxvjIMHZPiqRoGF6S and l0ezoGxwkNrdP8EFZ7Q1numaW2O:
		if gzi9KnXwC6G5x1c: c5qxjReiDAzVgBwpZ2yonKYOW = vkMRnTNV9jFm(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩኋ")+BF8XfchlgKmOE0ru2[IJ6VkihabRm(u"ࠩ࡭ࡳࡧ࠭ኌ")].upper().replace(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡋࡊ࡚ࠧኍ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࠬ኎"))
		ylJ6Z5bHDuYwf8dK = ce30uS4tawJ26EdhVnxjp1(c5qxjReiDAzVgBwpZ2yonKYOW)
	if not ykIAHx9E1umUdZqjSiBw6Kbar.succeeded and nfTOxvjIMHZPiqRoGF6S:
		KCxYF74IvnoUsWqfJ83mzdBZleVSy = (tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ኏") in NqvYW9nmj3CMupIcL6efxE8ho5Xb and KbL94nDHufSF0VcO2Nk3(u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨነ") in NqvYW9nmj3CMupIcL6efxE8ho5Xb)
		Z2YAGMhBkbIRqFP43toLEg = (fcIm8tvxlXZsaEY3bwuG4B(u"ࠧ࠶ࠢࡶࡩࡨ࠭ኑ") in NqvYW9nmj3CMupIcL6efxE8ho5Xb and fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩኒ") in NqvYW9nmj3CMupIcL6efxE8ho5Xb)
		uKdFaiXkQBehG = (TIvkgj7OxW6Vzb35il in [DKqQekNtF6WlJLhBP9M5ca(u"࠺࠰࠴ᚪ")] and v7reLlOXCgD5pZ14w2tUA(u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬና") in NqvYW9nmj3CMupIcL6efxE8ho5Xb)
		H164tnEpPUTBvxJgIKecdrVQLmSG = (u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬኔ") in NqvYW9nmj3CMupIcL6efxE8ho5Xb and a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨን") in NqvYW9nmj3CMupIcL6efxE8ho5Xb)
		if   YmT9oB2qsey6hJKFvXbDLkpa: rreason = L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬኖ")
		elif KCxYF74IvnoUsWqfJ83mzdBZleVSy: rreason = iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኗ")
		elif Z2YAGMhBkbIRqFP43toLEg: rreason = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧኘ")
		elif uKdFaiXkQBehG: rreason = q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩኙ")
		elif H164tnEpPUTBvxJgIKecdrVQLmSG: rreason = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫኚ")
		else: rreason = str(rreason)
		if oBQqw316KAIpOdr7R0LxkZNW5lG4y in sr71pJ08eD2ZhutRolF: pass
		elif oBQqw316KAIpOdr7R0LxkZNW5lG4y in jtJRLy3balg2pFK:
			zRM3tZx2v6DjJU(xxpPYJOnoAUrlBzyveui(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩኛ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧኜ")+str(TIvkgj7OxW6Vzb35il)+L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ኝ")+rreason+HMO0QciekqVpLKmA(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨኞ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ኟ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+xxpPYJOnoAUrlBzyveui(u"ࠨࠢࡠࠫአ"))
		else: zRM3tZx2v6DjJU(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧኡ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+Vv0lSjAOHLfMnam3wtdor(u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧኢ")+str(TIvkgj7OxW6Vzb35il)+V391t7nQWUBR5euCkJ(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬኣ")+rreason+HMO0QciekqVpLKmA(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧኤ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬእ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧࠡ࡟ࠪኦ"))
		wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j = NdVvO42riJpCWElX(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM and isinstance(wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j,unicode): wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j = wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j.encode(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡷࡷࡪ࠽࠭ኧ"))
		if l0ezoGxwkNrdP8EFZ7Q1numaW2O: wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j = wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j.split(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩ࠲ࠫከ"))[-L91nVzxH4hYrgPDsOuljXd0J(u"࠱ᚫ")]
		bbsf2GHCdc = rreason
		rreason = str(rreason)+HMO0QciekqVpLKmA(u"ࠪࡠࡳ࠮ࠠࠨኩ")+wqvXDsHfPBG8mVRrFpx7KinLtkaQ6j+uhOkAKtLVv4XTy1nWE6(u"ࠫࠥ࠯ࠧኪ")
		if YmT9oB2qsey6hJKFvXbDLkpa or KCxYF74IvnoUsWqfJ83mzdBZleVSy or Z2YAGMhBkbIRqFP43toLEg or uKdFaiXkQBehG or H164tnEpPUTBvxJgIKecdrVQLmSG:
			TIvkgj7OxW6Vzb35il = -HMO0QciekqVpLKmA(u"࠳ᚬ")
			ykIAHx9E1umUdZqjSiBw6Kbar.code = TIvkgj7OxW6Vzb35il
			ykIAHx9E1umUdZqjSiBw6Kbar.reason = rreason
			if adHF267eXilBUAPhgjSL0R3:
				zRM3tZx2v6DjJU(DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫካ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+uhOkAKtLVv4XTy1nWE6(u"࠭ࠠࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࡦࡾࡶࡡࡴࡵࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨኬ")+str(TIvkgj7OxW6Vzb35il)+v7reLlOXCgD5pZ14w2tUA(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨክ")+bbsf2GHCdc+V391t7nQWUBR5euCkJ(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪኮ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨኯ")+lZqkuhgaBHSVX8NItKG05cdLJe7Ao+fcIm8tvxlXZsaEY3bwuG4B(u"ࠪࠤࡢ࠭ኰ"))
				uFCykYQW68S(ddK4MmwpX5oG(u"๊ࠫำว้ๆฬࠤฯาว้ิࠣห้็อึࠢส่ศ๋ๆ๋ࠩ኱"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠬ࠭ኲ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=GGTRaYBDeNyI25zlF(u"࠳࠸࠴࠵ᚭ"))
				ZQA3WroxLwOikYqvjdtS6sy4eH = fQ6kvwg1FrYAzXjbLT.getSetting(xxpPYJOnoAUrlBzyveui(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫኳ"))
				tprFexz1voyGLaBcbUsh95wu = fQ6kvwg1FrYAzXjbLT.getSetting(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠶ࠬኴ"))
				ZQA3WroxLwOikYqvjdtS6sy4eH = DKqQekNtF6WlJLhBP9M5ca(u"࠼࠽࠾࠿ᚮ") if not ZQA3WroxLwOikYqvjdtS6sy4eH else int(ZQA3WroxLwOikYqvjdtS6sy4eH)
				tprFexz1voyGLaBcbUsh95wu = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠽࠾࠿࠹ᚯ") if not tprFexz1voyGLaBcbUsh95wu else int(tprFexz1voyGLaBcbUsh95wu)
				cumP0L5EGJFRIWvZdHAnz = []
				if ZQA3WroxLwOikYqvjdtS6sy4eH>OARzhnB9o7uYvQGFaIcZ(u"࠷࠰ᚱ"): cumP0L5EGJFRIWvZdHAnz.append(q0JfWbP8vACLxSNIncpOXkR6j(u"࠶ᚰ"))
				if tprFexz1voyGLaBcbUsh95wu>ddK4MmwpX5oG(u"࠱࠱ᚲ"): cumP0L5EGJFRIWvZdHAnz.append(HMO0QciekqVpLKmA(u"࠳ᚳ"))
				cumP0L5EGJFRIWvZdHAnz.append(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠵ᚴ"))
				iyIA2bL8VdsZQru3WmY91SGJfk6xOz = KRjfaduUhzsPg6I1.sample(cumP0L5EGJFRIWvZdHAnz,DKqQekNtF6WlJLhBP9M5ca(u"࠴ᚵ"))[a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠴ᚶ")]
				if iyIA2bL8VdsZQru3WmY91SGJfk6xOz==DKqQekNtF6WlJLhBP9M5ca(u"࠶ᚷ"):
					ntjxGqD0RoCYBH4Fs67iINkw = OARzhnB9o7uYvQGFaIcZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵࠽ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫኵ")
					MPfKjlDAZTV6 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ኶")+ntjxGqD0RoCYBH4Fs67iINkw+zOZvXaebGNwHKfjRA(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ኷")
					VGfzRDntZS9108LaldY3Tcgh = e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,MPfKjlDAZTV6,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,ddK4MmwpX5oG(u"ࡇࡣ࡯ࡷࡪ᝔"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠴ࡱࡨࠬኸ"),ddK4MmwpX5oG(u"ࡇࡣ࡯ࡷࡪ᝔"),ddK4MmwpX5oG(u"ࡇࡣ࡯ࡷࡪ᝔"))
				elif iyIA2bL8VdsZQru3WmY91SGJfk6xOz==dxAs4otSE98YmZnKy2iwRCB(u"࠸ᚸ"):
					ntjxGqD0RoCYBH4Fs67iINkw = DKqQekNtF6WlJLhBP9M5ca(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿࠺ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨኹ")
					MPfKjlDAZTV6 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+zOZvXaebGNwHKfjRA(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ኺ")+ntjxGqD0RoCYBH4Fs67iINkw+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧኻ")
					VGfzRDntZS9108LaldY3Tcgh = e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,MPfKjlDAZTV6,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,zOZvXaebGNwHKfjRA(u"ࡈࡤࡰࡸ࡫᝕"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠹ࡲࡥࠩኼ"),zOZvXaebGNwHKfjRA(u"ࡈࡤࡰࡸ࡫᝕"),zOZvXaebGNwHKfjRA(u"ࡈࡤࡰࡸ࡫᝕"))
				elif iyIA2bL8VdsZQru3WmY91SGJfk6xOz==u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠳ᚹ"):
					ntjxGqD0RoCYBH4Fs67iINkw = zOZvXaebGNwHKfjRA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮ࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩኽ")
					MPfKjlDAZTV6 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+DDS79jdWzLtE(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪኾ")+ntjxGqD0RoCYBH4Fs67iINkw+DKqQekNtF6WlJLhBP9M5ca(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ኿")
					VGfzRDntZS9108LaldY3Tcgh = e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,MPfKjlDAZTV6,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠷ࡸ࡭࠭ዀ"),GGTRaYBDeNyI25zlF(u"ࡉࡥࡱࡹࡥ᝖"),GGTRaYBDeNyI25zlF(u"ࡉࡥࡱࡹࡥ᝖"))
				else: VGfzRDntZS9108LaldY3Tcgh = ykIAHx9E1umUdZqjSiBw6Kbar
				TIvkgj7OxW6Vzb35il,rreason = VGfzRDntZS9108LaldY3Tcgh.code,VGfzRDntZS9108LaldY3Tcgh.reason
				if not VGfzRDntZS9108LaldY3Tcgh.succeeded:
					zRM3tZx2v6DjJU(DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ዁"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+V391t7nQWUBR5euCkJ(u"ࠧࠡࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡧࡿࡰࡢࡵࡶࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩዂ")+str(TIvkgj7OxW6Vzb35il)+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩዃ")+rreason+qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫዄ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+HMO0QciekqVpLKmA(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩዅ")+MPfKjlDAZTV6+L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࠥࡣࠧ዆"))
					uFCykYQW68S(Vv0lSjAOHLfMnam3wtdor(u"๊ࠬไฤีไࠤๆฺไࠡษ็ๅา฻ࠠศๆฦ้๋๐ࠧ዇"),DKqQekNtF6WlJLhBP9M5ca(u"࠭ฬาส้ࠣึฯࠠฤะิํࠬወ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=DDS79jdWzLtE(u"࠳࠲࠳࠴ᚺ"))
				else:
					zRM3tZx2v6DjJU(L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ዉ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+Vv0lSjAOHLfMnam3wtdor(u"ࠨࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡢࡺࡲࡤࡷࡸࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዊ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+xxpPYJOnoAUrlBzyveui(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨዋ")+MPfKjlDAZTV6+uhOkAKtLVv4XTy1nWE6(u"ࠪࠤࡢ࠭ዌ"))
					if iyIA2bL8VdsZQru3WmY91SGJfk6xOz in [v7reLlOXCgD5pZ14w2tUA(u"࠳ᚻ"),qNZKwi2M1S4fBzGQYrmPnea(u"࠵ᚼ")]:
						Wex6rGDaCXUYkyOsAmgpz8 = VGfzRDntZS9108LaldY3Tcgh.headers[xxBJoKG54uwQ(u"ࠫࡘࡩࡲࡢࡲࡨ࠲ࡩࡵ࠭ࡓࡧࡰࡥ࡮ࡴࡩ࡯ࡩ࠰ࡇࡷ࡫ࡤࡪࡶࡶࠫው")]
						if iyIA2bL8VdsZQru3WmY91SGJfk6xOz==GGTRaYBDeNyI25zlF(u"࠵ᚽ"): fQ6kvwg1FrYAzXjbLT.setSetting(v7reLlOXCgD5pZ14w2tUA(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠳ࠪዎ"),Wex6rGDaCXUYkyOsAmgpz8)
						if iyIA2bL8VdsZQru3WmY91SGJfk6xOz==xxpPYJOnoAUrlBzyveui(u"࠷ᚾ"): fQ6kvwg1FrYAzXjbLT.setSetting(u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠵ࠫዏ"),Wex6rGDaCXUYkyOsAmgpz8)
					uFCykYQW68S(vkMRnTNV9jFm(u"ࠧ็ฮะࠤฬ๊แฮืࠣห้ษๅ็์ࠪዐ"),u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩዑ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=uhOkAKtLVv4XTy1nWE6(u"࠸࠰࠱࠲ᚿ"))
					return VGfzRDntZS9108LaldY3Tcgh
		T4TGmZ9XWAzONaKygic = a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࡘࡷࡻࡥ᝗")
		if (FDKOt1Gm0LYR==uhOkAKtLVv4XTy1nWE6(u"ࠩࡄࡗࡐ࠭ዒ") or PlsMeTIwxmcAO==DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡅࡘࡑࠧዓ")) and (ELYSOBmvzgoX2u53 or adHF267eXilBUAPhgjSL0R3):
			T4TGmZ9XWAzONaKygic = t0ihfB5qMGW6(TIvkgj7OxW6Vzb35il,rreason,oBQqw316KAIpOdr7R0LxkZNW5lG4y,showDialogs)
			if T4TGmZ9XWAzONaKygic and FDKOt1Gm0LYR==d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡆ࡙ࡋࠨዔ"): FDKOt1Gm0LYR = uhOkAKtLVv4XTy1nWE6(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዕ")
			else: FDKOt1Gm0LYR = Vv0lSjAOHLfMnam3wtdor(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨዖ")
			if T4TGmZ9XWAzONaKygic and PlsMeTIwxmcAO==HMO0QciekqVpLKmA(u"ࠧࡂࡕࡎࠫ዗"): PlsMeTIwxmcAO = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪዘ")
			else: PlsMeTIwxmcAO = Vv0lSjAOHLfMnam3wtdor(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫዙ")
			fQ6kvwg1FrYAzXjbLT.setSetting(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ዚ"),FDKOt1Gm0LYR)
			fQ6kvwg1FrYAzXjbLT.setSetting(vkMRnTNV9jFm(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩዛ"),PlsMeTIwxmcAO)
		if T4TGmZ9XWAzONaKygic:
			q4xy5I6Y9CSLlMKrzemB = GGTRaYBDeNyI25zlF(u"࡙ࡸࡵࡦ᝘")
			if TIvkgj7OxW6Vzb35il==vkMRnTNV9jFm(u"࠸ᛀ") and ZpH2IWt7veyFobTsAnhi41(u"ࠬ࡮ࡴࡵࡲࡶࠫዜ") in lZqkuhgaBHSVX8NItKG05cdLJe7Ao and q4xy5I6Y9CSLlMKrzemB:
				if showDialogs: uFCykYQW68S(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭ዝ"),ddK4MmwpX5oG(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩዞ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=f8PVRTseIuj9BckO6GoyF5Lxv(u"࠳࠲࠳࠴ᛁ"))
				lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+xxpPYJOnoAUrlBzyveui(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨዟ")
				ylJ6Z5bHDuYwf8dK = e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,lc154VhT9DCqMk8,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠵ࡵࡪࠪዠ"))
				if ylJ6Z5bHDuYwf8dK.succeeded:
					ykIAHx9E1umUdZqjSiBw6Kbar = ylJ6Z5bHDuYwf8dK
					zRM3tZx2v6DjJU(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩዡ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ዢ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+OARzhnB9o7uYvQGFaIcZ(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫዣ")+DDRulV7aKN3jCOWSBQkb95+p1lrNRIXqLQJznH6O(u"࠭ࠠ࡞ࠩዤ"))
					if showDialogs: uFCykYQW68S(DDS79jdWzLtE(u"ࠧ็ฮสัࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫዥ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪዦ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=IJ6VkihabRm(u"࠴࠳࠴࠵ᛂ"))
				else:
					zRM3tZx2v6DjJU(Vv0lSjAOHLfMnam3wtdor(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧዧ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩየ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+HMO0QciekqVpLKmA(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪዩ")+DDRulV7aKN3jCOWSBQkb95+HMO0QciekqVpLKmA(u"ࠬࠦ࡝ࠨዪ"))
					if showDialogs: uFCykYQW68S(xxBJoKG54uwQ(u"࠭แีๆࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩያ"),p1lrNRIXqLQJznH6O(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩዬ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=vkMRnTNV9jFm(u"࠵࠴࠵࠶ᛃ"))
			if not ykIAHx9E1umUdZqjSiBw6Kbar.succeeded and PlsMeTIwxmcAO in [vkMRnTNV9jFm(u"ࠨࡃࡘࡘࡔ࠭ይ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫዮ")] and adHF267eXilBUAPhgjSL0R3:
				if showDialogs: uFCykYQW68S(ddK4MmwpX5oG(u"ࠪฮๆ฿๊ๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪዯ"),L91nVzxH4hYrgPDsOuljXd0J(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ደ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=IJ6VkihabRm(u"࠶࠵࠶࠰ᛄ"))
				ylJ6Z5bHDuYwf8dK = CCkRfcY4W6IrBEOiFsNhZ7Tw31P8lM(bB2eVZo9P8TpLU1Rw,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,V391t7nQWUBR5euCkJ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠹ࡸ࡭࠭ዱ"))
				if ylJ6Z5bHDuYwf8dK.succeeded:
					ykIAHx9E1umUdZqjSiBw6Kbar = ylJ6Z5bHDuYwf8dK
					zRM3tZx2v6DjJU(tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬዲ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዳ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧዴ")+DDRulV7aKN3jCOWSBQkb95+V391t7nQWUBR5euCkJ(u"ࠩࠣࡡࠬድ"))
					if showDialogs: uFCykYQW68S(fcIm8tvxlXZsaEY3bwuG4B(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩዶ"),xxBJoKG54uwQ(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ዷ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=p1lrNRIXqLQJznH6O(u"࠷࠶࠰࠱ᛅ"))
				else:
					zRM3tZx2v6DjJU(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪዸ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪዹ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+fcIm8tvxlXZsaEY3bwuG4B(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዺ")+DDRulV7aKN3jCOWSBQkb95+uhOkAKtLVv4XTy1nWE6(u"ࠨࠢࡠࠫዻ"))
					if showDialogs: uFCykYQW68S(vkMRnTNV9jFm(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧዼ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬዽ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=OARzhnB9o7uYvQGFaIcZ(u"࠸࠰࠱࠲ᛆ"))
			if not ykIAHx9E1umUdZqjSiBw6Kbar.succeeded and FDKOt1Gm0LYR in [gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠫࡆ࡛ࡔࡐࠩዾ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዿ")] and ELYSOBmvzgoX2u53:
				if showDialogs: uFCykYQW68S(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨጀ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩጁ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࠲࠱࠲࠳ᛇ"))
				lc154VhT9DCqMk8 = lZqkuhgaBHSVX8NItKG05cdLJe7Ao+ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ጂ")
				ylJ6Z5bHDuYwf8dK = e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,lc154VhT9DCqMk8,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠷ࡵࡪࠪጃ"))
				if ylJ6Z5bHDuYwf8dK.succeeded:
					ykIAHx9E1umUdZqjSiBw6Kbar = ylJ6Z5bHDuYwf8dK
					zRM3tZx2v6DjJU(p1lrNRIXqLQJznH6O(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩጄ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+fcIm8tvxlXZsaEY3bwuG4B(u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫጅ")+SAxhNOBlQazEiXKFbIk2yZ7qRTY905+V391t7nQWUBR5euCkJ(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧጆ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+ddK4MmwpX5oG(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጇ")+DDRulV7aKN3jCOWSBQkb95+v7reLlOXCgD5pZ14w2tUA(u"ࠧࠡ࡟ࠪገ"))
					if showDialogs: uFCykYQW68S(L91nVzxH4hYrgPDsOuljXd0J(u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩጉ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጊ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠳࠲࠳࠴ᛈ"))
				else:
					zRM3tZx2v6DjJU(Vv0lSjAOHLfMnam3wtdor(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨጋ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+OARzhnB9o7uYvQGFaIcZ(u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨጌ")+SAxhNOBlQazEiXKFbIk2yZ7qRTY905+uhOkAKtLVv4XTy1nWE6(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧግ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y+q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጎ")+DDRulV7aKN3jCOWSBQkb95+IJ6VkihabRm(u"ࠧࠡ࡟ࠪጏ"))
					if showDialogs: uFCykYQW68S(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨጐ"),DDS79jdWzLtE(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ጑"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=dxAs4otSE98YmZnKy2iwRCB(u"࠴࠳࠴࠵ᛉ"))
		if PlsMeTIwxmcAO==L91nVzxH4hYrgPDsOuljXd0J(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬጒ") or FDKOt1Gm0LYR==p1lrNRIXqLQJznH6O(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ጓ"): showDialogs = u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࡌࡡ࡭ࡵࡨ᝙")
		if not ykIAHx9E1umUdZqjSiBw6Kbar.succeeded:
			if showDialogs: m1mNjq3Hfw2OKp56oaFEXQGxkCsu = t0ihfB5qMGW6(TIvkgj7OxW6Vzb35il,rreason,oBQqw316KAIpOdr7R0LxkZNW5lG4y,showDialogs)
			if TIvkgj7OxW6Vzb35il!=qNZKwi2M1S4fBzGQYrmPnea(u"࠵࠴࠵ᛊ") and oBQqw316KAIpOdr7R0LxkZNW5lG4y not in MFPHOQCR4rstkBTx and gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩጔ") not in oBQqw316KAIpOdr7R0LxkZNW5lG4y:
				RYNAu9Eo7mgOi0sG1j(v7reLlOXCgD5pZ14w2tUA(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬጕ")+oBQqw316KAIpOdr7R0LxkZNW5lG4y)
	if fQ6kvwg1FrYAzXjbLT.getSetting(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ጖")) not in [v7reLlOXCgD5pZ14w2tUA(u"ࠨࡃࡘࡘࡔ࠭጗"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡖࡘࡔࡖࠧጘ"),GGTRaYBDeNyI25zlF(u"ࠪࡅࡘࡑࠧጙ")]: fQ6kvwg1FrYAzXjbLT.setSetting(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧጚ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡇࡓࡌࠩጛ"))
	if fQ6kvwg1FrYAzXjbLT.getSetting(ddK4MmwpX5oG(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫጜ")) not in [DKqQekNtF6WlJLhBP9M5ca(u"ࠧࡂࡗࡗࡓࠬጝ"),v7reLlOXCgD5pZ14w2tUA(u"ࠨࡕࡗࡓࡕ࠭ጞ"),qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡄࡗࡐ࠭ጟ")]: fQ6kvwg1FrYAzXjbLT.setSetting(V391t7nQWUBR5euCkJ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨጠ"),IJ6VkihabRm(u"ࠫࡆ࡙ࡋࠨጡ"))
	return ykIAHx9E1umUdZqjSiBw6Kbar
def jjXeDpKN9HRh1ZY(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y,ELYSOBmvzgoX2u53=p1lrNRIXqLQJznH6O(u"ࠬ࠭ጢ"),adHF267eXilBUAPhgjSL0R3=qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࠧጣ")):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ppim7Ofn2Nx,otFfgXKET5vz3YV0lI6,bZ5puKhzrkQcvRiqV0XgP3JxNLST = llpngAoQVzND(DDRulV7aKN3jCOWSBQkb95)
	zO0UA5L7ta1sIHpmqjbeBvXf3Kky = bB2eVZo9P8TpLU1Rw,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY
	if b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX:
		djr0g3VkMzo1ehxE = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩጤ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫጥ"),zO0UA5L7ta1sIHpmqjbeBvXf3Kky)
		if djr0g3VkMzo1ehxE.succeeded:
			BEt0xkYQrnLpwZ4JaFUDM8oX5vAN(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩጦ"),lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,oBQqw316KAIpOdr7R0LxkZNW5lG4y,bB2eVZo9P8TpLU1Rw)
			return djr0g3VkMzo1ehxE
	djr0g3VkMzo1ehxE = e94Oz3uF7KZJ(bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,bbOwTfLHWEY,showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y,ELYSOBmvzgoX2u53,adHF267eXilBUAPhgjSL0R3)
	if djr0g3VkMzo1ehxE.succeeded:
		if iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫጧ") in oBQqw316KAIpOdr7R0LxkZNW5lG4y: djr0g3VkMzo1ehxE.content = vvSrTfCOiNqPcoLa7eZn2s5Mlxk9YV(djr0g3VkMzo1ehxE.content)
		if b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,KbL94nDHufSF0VcO2Nk3(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧጨ"),zO0UA5L7ta1sIHpmqjbeBvXf3Kky,djr0g3VkMzo1ehxE,b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX)
	return djr0g3VkMzo1ehxE
def ZZUyb9R7MFizwXkhd4gC(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y):
	if not ZEJAFRNxIrQSU or isinstance(ZEJAFRNxIrQSU,dict): bB2eVZo9P8TpLU1Rw = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡍࡅࡕࠩጩ")
	else:
		bB2eVZo9P8TpLU1Rw = qNZKwi2M1S4fBzGQYrmPnea(u"࠭ࡐࡐࡕࡗࠫጪ")
		ZEJAFRNxIrQSU = NdVvO42riJpCWElX(ZEJAFRNxIrQSU)
		iaC5GtXyYqxsEBhpOrdocAu,ZEJAFRNxIrQSU = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(ZEJAFRNxIrQSU)
	djr0g3VkMzo1ehxE = jjXeDpKN9HRh1ZY(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࡔࡳࡷࡨ᝚"),showDialogs,oBQqw316KAIpOdr7R0LxkZNW5lG4y)
	RkLE6BzZ2KX = djr0g3VkMzo1ehxE.content
	RkLE6BzZ2KX = str(RkLE6BzZ2KX)
	return RkLE6BzZ2KX
def llpngAoQVzND(DDRulV7aKN3jCOWSBQkb95):
	JCRBxjfUtYca2K = DDRulV7aKN3jCOWSBQkb95.split(xxpPYJOnoAUrlBzyveui(u"ࠧࡽࡾࠪጫ"))
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ppim7Ofn2Nx,otFfgXKET5vz3YV0lI6,bZ5puKhzrkQcvRiqV0XgP3JxNLST = JCRBxjfUtYca2K[OARzhnB9o7uYvQGFaIcZ(u"࠴ᛋ")],None,None,OARzhnB9o7uYvQGFaIcZ(u"ࡕࡴࡸࡩ᝛")
	for zO0UA5L7ta1sIHpmqjbeBvXf3Kky in JCRBxjfUtYca2K:
		if qNZKwi2M1S4fBzGQYrmPnea(u"ࠨࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ጬ") in zO0UA5L7ta1sIHpmqjbeBvXf3Kky: ppim7Ofn2Nx = zO0UA5L7ta1sIHpmqjbeBvXf3Kky.split(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡀࠫጭ"))[uhOkAKtLVv4XTy1nWE6(u"࠶ᛌ")]
		elif KbL94nDHufSF0VcO2Nk3(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ጮ") in zO0UA5L7ta1sIHpmqjbeBvXf3Kky: otFfgXKET5vz3YV0lI6 = zO0UA5L7ta1sIHpmqjbeBvXf3Kky.split(GGTRaYBDeNyI25zlF(u"ࠫࡂ࠭ጯ"))[dxAs4otSE98YmZnKy2iwRCB(u"࠷ᛍ")]
		elif L91nVzxH4hYrgPDsOuljXd0J(u"ࠬࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪጰ") in zO0UA5L7ta1sIHpmqjbeBvXf3Kky: bZ5puKhzrkQcvRiqV0XgP3JxNLST = xxpPYJOnoAUrlBzyveui(u"ࡈࡤࡰࡸ࡫᝜")
	return lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ppim7Ofn2Nx,otFfgXKET5vz3YV0lI6,bZ5puKhzrkQcvRiqV0XgP3JxNLST
def rIPlaEZu19UKnXGAFzcyfM6oegdSj(QEMyY8a9IoOcFqeuKztCVWmT7jXv):
	iORcCabIUmnW5AyTrphwEg0D39,Xt7olBPDuFS4diy1,ZZkfCK7NToEu = HMO0QciekqVpLKmA(u"࠭ࠧጱ"),KbL94nDHufSF0VcO2Nk3(u"ࠧࠨጲ"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࠩጳ")
	QEMyY8a9IoOcFqeuKztCVWmT7jXv = QEMyY8a9IoOcFqeuKztCVWmT7jXv.replace(Pc98uK2GLvfMwq6UtyJSHe03g,HMO0QciekqVpLKmA(u"ࠩࠪጴ")).replace(lc6sH83woipUCaLnRVAkgtrEJd257,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠪࠫጵ"))
	uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall(qNZKwi2M1S4fBzGQYrmPnea(u"ࠫ࠭࠴ࠩ࡝࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺࡟ࡡ࠭ࡢࡷ࡝ࡹ࡟ࡻ࠮ࠦࠫ࡝࡝࡟࠳ࡈࡕࡌࡐࡔ࡟ࡡ࠭࠴ࠪࡀࠫࠧࠫጶ"),QEMyY8a9IoOcFqeuKztCVWmT7jXv,QPuHKNAT4jmCRg.DOTALL)
	if uuv3pk5MXdeaHt6sDxSFybTWz0Q: iORcCabIUmnW5AyTrphwEg0D39,Xt7olBPDuFS4diy1,QEMyY8a9IoOcFqeuKztCVWmT7jXv = uuv3pk5MXdeaHt6sDxSFybTWz0Q[IJ6VkihabRm(u"࠰ᛎ")]
	if iORcCabIUmnW5AyTrphwEg0D39 not in [V391t7nQWUBR5euCkJ(u"ࠬࠦࠧጷ"),xxpPYJOnoAUrlBzyveui(u"࠭ࠬࠨጸ"),p1lrNRIXqLQJznH6O(u"ࠧࠨጹ")]: ZZkfCK7NToEu = p1lrNRIXqLQJznH6O(u"ࠨࡡࡐࡓࡉࡥࠧጺ")
	if Xt7olBPDuFS4diy1: Xt7olBPDuFS4diy1 = ZpH2IWt7veyFobTsAnhi41(u"ࠩࡢࠫጻ")+Xt7olBPDuFS4diy1+GGTRaYBDeNyI25zlF(u"ࠪࡣࠬጼ")
	QEMyY8a9IoOcFqeuKztCVWmT7jXv = Xt7olBPDuFS4diy1+ZZkfCK7NToEu+QEMyY8a9IoOcFqeuKztCVWmT7jXv
	return QEMyY8a9IoOcFqeuKztCVWmT7jXv
def PEkFUyjA3qRNpzgYX(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,K7Oa0AJDVrUmPbGtdQy,dtjHuoGE0A7CXK8siQz4Tay,ltsN9uQG0Yjv,iPmj7p45q2duSAQaHvOnT=xxpPYJOnoAUrlBzyveui(u"ࠫࠬጽ")):
	o3dqv0ACPODycQihun7Njw = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(DDRulV7aKN3jCOWSBQkb95,GGTRaYBDeNyI25zlF(u"ࠬࡻࡲ࡭ࠩጾ"))
	cQ8GVSxAC9 = fQ6kvwg1FrYAzXjbLT.getSetting(uhOkAKtLVv4XTy1nWE6(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨጿ")+K7Oa0AJDVrUmPbGtdQy)
	if o3dqv0ACPODycQihun7Njw==cQ8GVSxAC9: fQ6kvwg1FrYAzXjbLT.setSetting(dxAs4otSE98YmZnKy2iwRCB(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩፀ")+K7Oa0AJDVrUmPbGtdQy,dxAs4otSE98YmZnKy2iwRCB(u"ࠨࠩፁ"))
	if cQ8GVSxAC9: lc154VhT9DCqMk8 = DDRulV7aKN3jCOWSBQkb95.replace(o3dqv0ACPODycQihun7Njw,cQ8GVSxAC9)
	else:
		lc154VhT9DCqMk8 = DDRulV7aKN3jCOWSBQkb95
		cQ8GVSxAC9 = o3dqv0ACPODycQihun7Njw
	ylJ6Z5bHDuYwf8dK = jjXeDpKN9HRh1ZY(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,lc154VhT9DCqMk8,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠩࠪፂ"),iPmj7p45q2duSAQaHvOnT,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠪࠫፃ"),ZpH2IWt7veyFobTsAnhi41(u"ࠫࠬፄ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩፅ"))
	RkLE6BzZ2KX = ylJ6Z5bHDuYwf8dK.content
	if Nnxm30dfoBWRYpIC7KsQGl:
		try: RkLE6BzZ2KX = RkLE6BzZ2KX.decode(iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡵࡵࡨ࠻ࠫፆ"),xxBJoKG54uwQ(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧፇ"))
		except: pass
	TIvkgj7OxW6Vzb35il = ylJ6Z5bHDuYwf8dK.code
	if TIvkgj7OxW6Vzb35il!=-DDS79jdWzLtE(u"࠳ᛏ") and (not ylJ6Z5bHDuYwf8dK.succeeded or ltsN9uQG0Yjv not in RkLE6BzZ2KX):
		dtjHuoGE0A7CXK8siQz4Tay = dtjHuoGE0A7CXK8siQz4Tay.replace(vkMRnTNV9jFm(u"ࠨࠢࠪፈ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩ࠮ࠫፉ"))
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = zOZvXaebGNwHKfjRA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨፊ")+dtjHuoGE0A7CXK8siQz4Tay
		Eudgv5cTUHF2AzKpkx = {d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨፋ"):xxpPYJOnoAUrlBzyveui(u"ࠬ࠭ፌ")}
		ykIAHx9E1umUdZqjSiBw6Kbar = jjXeDpKN9HRh1ZY(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࠧፍ"),Eudgv5cTUHF2AzKpkx,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࠨፎ"),v7reLlOXCgD5pZ14w2tUA(u"ࠨࠩፏ"),IJ6VkihabRm(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ፐ"))
		if ykIAHx9E1umUdZqjSiBw6Kbar.succeeded:
			RkLE6BzZ2KX = ykIAHx9E1umUdZqjSiBw6Kbar.content
			if Nnxm30dfoBWRYpIC7KsQGl:
				try: RkLE6BzZ2KX = RkLE6BzZ2KX.decode(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࡹࡹ࡬࠸ࠨፑ"),Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫፒ"))
				except: pass
			Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰࡞ࡺ࠮ࡡࡅ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ፓ"),RkLE6BzZ2KX,QPuHKNAT4jmCRg.DOTALL)
			KxfPr4vIJupjsc5aH8CekQNm2O7 = [cQ8GVSxAC9]
			Q2QSxwcpTUL1zPaq3BG = [dxAs4otSE98YmZnKy2iwRCB(u"࠭ࡡࡱ࡭ࠪፔ"),xxpPYJOnoAUrlBzyveui(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧፕ"),DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡶࡺ࡭ࡹࡺࡥࡳࠩፖ"),DDS79jdWzLtE(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪፗ"),uhOkAKtLVv4XTy1nWE6(u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬፘ"),V391t7nQWUBR5euCkJ(u"ࠫࡵ࡮ࡰࠨፙ"),lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡧࡴ࡭ࡣࡴࠫፚ"),Vv0lSjAOHLfMnam3wtdor(u"࠭ࡳࡪࡶࡨ࡭ࡳࡪࡩࡤࡧࡶࠫ፛"),vkMRnTNV9jFm(u"ࠧࡴࡷࡵ࠲ࡱࡿࠧ፜"),ddK4MmwpX5oG(u"ࠨࡤ࡯ࡳ࡬ࡹࡰࡰࡶࠪ፝"),DKqQekNtF6WlJLhBP9M5ca(u"ࠩ࡬ࡲ࡫ࡵࡲ࡮ࡧࡵࠫ፞"),ZpH2IWt7veyFobTsAnhi41(u"ࠪࡷ࡮ࡺࡥ࡭࡫࡮ࡩࠬ፟"),Vv0lSjAOHLfMnam3wtdor(u"ࠫ࡮ࡴࡳࡵࡣࡪࡶࡦࡳࠧ፠"),uhOkAKtLVv4XTy1nWE6(u"ࠬࡹ࡮ࡢࡲࡦ࡬ࡦࡺࠧ፡"),zOZvXaebGNwHKfjRA(u"࠭ࡨࡵࡶࡳ࠱ࡪࡷࡵࡪࡸࠪ።"),GGTRaYBDeNyI25zlF(u"ࠧࡧࡣࡶࡩࡱࡶ࡬ࡶࡵࠪ፣")]
			for SSXgFdnlqLO8y4Rkiu in Y4xiULzGTKjb8mulO:
				if any(pp8iHB3W9Cs in SSXgFdnlqLO8y4Rkiu for pp8iHB3W9Cs in Q2QSxwcpTUL1zPaq3BG): continue
				cQ8GVSxAC9 = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(SSXgFdnlqLO8y4Rkiu,dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡷࡵࡰࠬ፤"))
				if cQ8GVSxAC9 in KxfPr4vIJupjsc5aH8CekQNm2O7: continue
				if len(KxfPr4vIJupjsc5aH8CekQNm2O7)==DDS79jdWzLtE(u"࠻ᛐ"):
					zRM3tZx2v6DjJU(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ፥"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ፦")+K7Oa0AJDVrUmPbGtdQy+u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ፧")+o3dqv0ACPODycQihun7Njw+DDS79jdWzLtE(u"ࠬࠦ࡝ࠨ፨"))
					fQ6kvwg1FrYAzXjbLT.setSetting(a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ፩")+K7Oa0AJDVrUmPbGtdQy,v7reLlOXCgD5pZ14w2tUA(u"ࠧࠨ፪"))
					break
				KxfPr4vIJupjsc5aH8CekQNm2O7.append(cQ8GVSxAC9)
				lc154VhT9DCqMk8 = DDRulV7aKN3jCOWSBQkb95.replace(o3dqv0ACPODycQihun7Njw,cQ8GVSxAC9)
				ylJ6Z5bHDuYwf8dK = jjXeDpKN9HRh1ZY(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,lc154VhT9DCqMk8,xxpPYJOnoAUrlBzyveui(u"ࠨࠩ፫"),iPmj7p45q2duSAQaHvOnT,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࠪ፬"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࠫ፭"),L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨ፮"))
				RkLE6BzZ2KX = ylJ6Z5bHDuYwf8dK.content
				if ylJ6Z5bHDuYwf8dK.succeeded and ltsN9uQG0Yjv in RkLE6BzZ2KX:
					zRM3tZx2v6DjJU(xxpPYJOnoAUrlBzyveui(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ፯"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+DKqQekNtF6WlJLhBP9M5ca(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭፰")+K7Oa0AJDVrUmPbGtdQy+vkMRnTNV9jFm(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭፱")+cQ8GVSxAC9+dxAs4otSE98YmZnKy2iwRCB(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭፲")+o3dqv0ACPODycQihun7Njw+a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠩࠣࡡࠬ፳"))
					fQ6kvwg1FrYAzXjbLT.setSetting(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ፴")+K7Oa0AJDVrUmPbGtdQy,cQ8GVSxAC9)
					break
	return cQ8GVSxAC9,lc154VhT9DCqMk8,ylJ6Z5bHDuYwf8dK
def S6YzAlHWcCwJI18(gq2FVNBUKPzIw1pZAnYHJG):
	FEtAPKBz8buQHmwxS1h2 = {
	 lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠫࡴࡲࡤࠨ፵")			:DKqQekNtF6WlJLhBP9M5ca(u"่ࠬฯ๋็ࠪ፶")
	,tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ፷")		:qNZKwi2M1S4fBzGQYrmPnea(u"ࠧๆฬ๋ๆๆ࠭፸")
	,v7reLlOXCgD5pZ14w2tUA(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ፹")		:u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"่ࠩๅ็๎ฯࠨ፺")
	,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪ࡫ࡴࡵࡤࠨ፻")			:uhOkAKtLVv4XTy1nWE6(u"ࠫั๐ฯࠨ፼")
	,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ፽")		:qNZKwi2M1S4fBzGQYrmPnea(u"࠭แีๆࠪ፾")
	,GGTRaYBDeNyI25zlF(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፿")		:xxpPYJOnoAUrlBzyveui(u"ࠨ็ฯ่ิ࠭ᎀ")
	,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡹ࡭ࡩ࡫࡯ࠨᎁ")		:KbL94nDHufSF0VcO2Nk3(u"ࠪๅ๏ี๊้ࠩᎂ")
	,xxBJoKG54uwQ(u"ࠫࡱ࡯ࡶࡦࠩᎃ")			:tKVplxqYIdngGF6TZkXeb2PiwfME(u"่ࠬๆศหࠪᎄ")
	,fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡡ࡬ࡱࡤࡱࠬᎅ")		:Vv0lSjAOHLfMnam3wtdor(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫᎆ")
	,Vv0lSjAOHLfMnam3wtdor(u"ࠨࡣ࡮ࡻࡦࡳࠧᎇ")		:xxBJoKG54uwQ(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᎈ")
	,p1lrNRIXqLQJznH6O(u"ࠪࡥࡰࡵࡡ࡮ࡥࡤࡱࠬᎉ")		:f8PVRTseIuj9BckO6GoyF5Lxv(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡๅส้ࠬᎊ")
	,V391t7nQWUBR5euCkJ(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬᎋ")		:fcIm8tvxlXZsaEY3bwuG4B(u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭ᎌ")
	,OARzhnB9o7uYvQGFaIcZ(u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩᎍ")		:gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧᎎ")
	,ZpH2IWt7veyFobTsAnhi41(u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬᎏ")	:IJ6VkihabRm(u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭᎐")
	,DDS79jdWzLtE(u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭᎑")		:v7reLlOXCgD5pZ14w2tUA(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ᎒")
	,IJ6VkihabRm(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨ᎓")		:dxAs4otSE98YmZnKy2iwRCB(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨ᎔")
	,fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ᎕")	:qNZKwi2M1S4fBzGQYrmPnea(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ᎖")
	,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠪࡩࡱࡩࡩ࡯ࡧࡰࡥࠬ᎗")		:xxBJoKG54uwQ(u"๊ࠫ๎โฺࠢสุ่๐ๆๆษࠪ᎘")
	,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࡮ࡥ࡭ࡣ࡯ࠫ᎙")		:IJ6VkihabRm(u"࠭ๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩ᎚")
	,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩ᎛")		:xxpPYJOnoAUrlBzyveui(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ᎜")
	,ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ᎝")		:ZpH2IWt7veyFobTsAnhi41(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬ᎞")
	,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭᎟")		:L91nVzxH4hYrgPDsOuljXd0J(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬᎠ")
	,ZpH2IWt7veyFobTsAnhi41(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨᎡ")		:IJ6VkihabRm(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧᎢ")
	,dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩᎣ")		:v7reLlOXCgD5pZ14w2tUA(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩᎤ")
	,IJ6VkihabRm(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭Ꭵ")	:zOZvXaebGNwHKfjRA(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧᎦ")
	,qNZKwi2M1S4fBzGQYrmPnea(u"ࠬࡿࡴࡣࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᎧ")	:Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ๅ้ษๅ฽ࠥ๐่ห์๋ฬࠬᎨ")
	,xxBJoKG54uwQ(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧᎩ")		:DDS79jdWzLtE(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨᎪ")
	,OARzhnB9o7uYvQGFaIcZ(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩᎫ")		:f8PVRTseIuj9BckO6GoyF5Lxv(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠩᎬ")
	,qNZKwi2M1S4fBzGQYrmPnea(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭Ꭽ")		:xxpPYJOnoAUrlBzyveui(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧᎮ")
	,vkMRnTNV9jFm(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨᎯ")		:zOZvXaebGNwHKfjRA(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪᎰ")
	,L91nVzxH4hYrgPDsOuljXd0J(u"ࠨࡤࡲ࡯ࡷࡧࠧᎱ")		:lunVJF2G5bZMgTcCje0vaIB371SX(u"่ࠩ์็฿ࠠษๅิหࠬᎲ")
	,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬᎳ")		:zOZvXaebGNwHKfjRA(u"๊ࠫ๎โฺࠢึ๎๊อฺࠠสา์ࠬᎴ")
	,xxpPYJOnoAUrlBzyveui(u"ࠬࡲࡩࡷࡧࡷࡺࠬᎵ")		:f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ๅๅใࠪᎶ")
	,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨᎷ")		:lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨ็็ๅࠬᎸ")
	,DKqQekNtF6WlJLhBP9M5ca(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩᎹ")		:xxBJoKG54uwQ(u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬᎺ")
	,p1lrNRIXqLQJznH6O(u"ࠫ࡫ࡧࡪࡦࡴࡶ࡬ࡴࡽࠧᎻ")	:v7reLlOXCgD5pZ14w2tUA(u"๋่ࠬใ฻ࠣๅัืࠠี๊ࠪᎼ")
	,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧᎽ")		:IJ6VkihabRm(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠨᎾ")
	,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪᎿ")		:ldOGfm56kWs8T03wcptQunqEUBDrvC(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠵ࠬᏀ")
	,V391t7nQWUBR5euCkJ(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠶ࠬᏁ")		:L91nVzxH4hYrgPDsOuljXd0J(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧᏂ")
	,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧᏃ")		:IJ6VkihabRm(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠴ࠩᏄ")
	,vkMRnTNV9jFm(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠵ࠩᏅ")		:v7reLlOXCgD5pZ14w2tUA(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫᏆ")
	,L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩᏇ")		:fcIm8tvxlXZsaEY3bwuG4B(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬᏈ")
	,HMO0QciekqVpLKmA(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫᏉ")		:vkMRnTNV9jFm(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬᏊ")
	,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧᏋ")		:IJ6VkihabRm(u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧᏌ")
	,HMO0QciekqVpLKmA(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪᏍ")		:DKqQekNtF6WlJLhBP9M5ca(u"่ࠩ์็฿่ࠠๆสࠤุ๐ๅศࠩᏎ")
	,v7reLlOXCgD5pZ14w2tUA(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫᏏ")		:dxAs4otSE98YmZnKy2iwRCB(u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪᏐ")
	,DKqQekNtF6WlJLhBP9M5ca(u"ࠬࡺࡶࡧࡷࡱࠫᏑ")		:HMO0QciekqVpLKmA(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭Ꮢ")
	,DDS79jdWzLtE(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪᏓ")	:dxAs4otSE98YmZnKy2iwRCB(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩᏔ")
	,DKqQekNtF6WlJLhBP9M5ca(u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭Ꮥ")	:xxpPYJOnoAUrlBzyveui(u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫᏖ")
	,u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠫ࡫ࡵࡳࡵࡣࠪᏗ")		:lunVJF2G5bZMgTcCje0vaIB371SX(u"๋่ࠬใ฻ࠣๅํูสศࠩᏘ")
	,OARzhnB9o7uYvQGFaIcZ(u"࠭ࡡࡩࡹࡤ࡯ࠬᏙ")		:zOZvXaebGNwHKfjRA(u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩᏚ")
	,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩᏛ")		:ldOGfm56kWs8T03wcptQunqEUBDrvC(u"่ࠩ์็฿ࠠโสิ็ฮ࠭Ꮬ")
	,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩᏝ")	:gr5K72RtvAZYPVwkdnspbzQWNjEI(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩᏞ")
	,xxBJoKG54uwQ(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࠧᏟ")		:f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧᏠ")
	,HMO0QciekqVpLKmA(u"ࠧࡴࡪࡲࡪ࡭ࡧࠧᏡ")		:L91nVzxH4hYrgPDsOuljXd0J(u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪᏢ")
	,dxAs4otSE98YmZnKy2iwRCB(u"ࠩࡥࡶࡸࡺࡥ࡫ࠩᏣ")		:xxBJoKG54uwQ(u"้ࠪํู่ࠡสิืฯ๐ฬࠨᏤ")
	,HMO0QciekqVpLKmA(u"ࠫࡨ࡯࡭ࡢ࠶࠳࠴ࠬᏥ")		:L91nVzxH4hYrgPDsOuljXd0J(u"๋่ࠬใ฻ࠣื๏๋วࠡ࠶࠳࠴ࠬᏦ")
	,ddK4MmwpX5oG(u"࠭࡬ࡢࡴࡲࡾࡦ࠭Ꮷ")		:qNZKwi2M1S4fBzGQYrmPnea(u"ࠧๆ๊ๅ฽๊ࠥวา๊ีหࠬᏨ")
	,DDS79jdWzLtE(u"ࠨࡻࡤࡵࡴࡺࠧᏩ")		:Vv0lSjAOHLfMnam3wtdor(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭Ꮺ")
	,v7reLlOXCgD5pZ14w2tUA(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬᏫ")		:Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"๊ࠫ๎โฺࠢๆฮ่๎สࠨᏬ")
	,zOZvXaebGNwHKfjRA(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧᏭ")		:KbL94nDHufSF0VcO2Nk3(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨᏮ")
	,zOZvXaebGNwHKfjRA(u"ࠧࡢࡴࡤࡦ࡮ࡩࡴࡰࡱࡱࡷࠬᏯ")	:iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠨ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪᏰ")
	,qNZKwi2M1S4fBzGQYrmPnea(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪᏱ")		:v7reLlOXCgD5pZ14w2tUA(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪᏲ")
	,uhOkAKtLVv4XTy1nWE6(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭Ᏻ")		:zOZvXaebGNwHKfjRA(u"๋่ࠬใ฻ุࠣํ็ࠠษำ๋ࠫᏴ")
	,ZpH2IWt7veyFobTsAnhi41(u"࠭ࡩࡧ࡫࡯ࡱࠬᏵ")				:qNZKwi2M1S4fBzGQYrmPnea(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫ᏶")
	,HMO0QciekqVpLKmA(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡢࡴࡤࡦ࡮ࡩࠧ᏷")			:xxpPYJOnoAUrlBzyveui(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํู่๊ࠦาสํࠫᏸ")
	,L91nVzxH4hYrgPDsOuljXd0J(u"ࠪ࡭࡫࡯࡬࡮࠯ࡨࡲ࡬ࡲࡩࡴࡪࠪᏹ")		:lunVJF2G5bZMgTcCje0vaIB371SX(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡษ้ะ้๐า๋ࠩᏺ")
	,V391t7nQWUBR5euCkJ(u"ࠬࡶࡡ࡯ࡧࡷࠫᏻ")				:iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪᏼ")
	,GGTRaYBDeNyI25zlF(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᏽ")			:Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫ᏾")
	,q0JfWbP8vACLxSNIncpOXkR6j(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨ᏿")			:iRTygNp4Lf36wQKlD2MHUhG7B(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨ᐀")
	,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬᐁ")				:iRTygNp4Lf36wQKlD2MHUhG7B(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠪᐂ")
	,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠧᐃ")		:ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ็๊ะ์๋๋ฬะࠧᐄ")
	,a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᐅ")	:KbL94nDHufSF0VcO2Nk3(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ᐆ")
	,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐇ")		:DKqQekNtF6WlJLhBP9M5ca(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨᐈ")
	,dxAs4otSE98YmZnKy2iwRCB(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨᐉ")			:ZpH2IWt7veyFobTsAnhi41(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨᐊ")
	,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫᐋ")	:IJ6VkihabRm(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨᐌ")
	,Vv0lSjAOHLfMnam3wtdor(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧ࡬ࡣࡷࡰࡷࠬᐍ")		:KbL94nDHufSF0VcO2Nk3(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥอไษ๊่ࠫᐎ")
	,DDS79jdWzLtE(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢࡷࡧ࡭ࡴࡹࠧᐏ")		:HMO0QciekqVpLKmA(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧᐐ")
	,ZpH2IWt7veyFobTsAnhi41(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫᐑ")			:a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠨᐒ")
	,v7reLlOXCgD5pZ14w2tUA(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡶࡪࡦࡨࡳࡸ࠭ᐓ")	:qNZKwi2M1S4fBzGQYrmPnea(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๅ๏ี๊้้สฮࠬᐔ")
	,vkMRnTNV9jFm(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᐕ"):gr5K72RtvAZYPVwkdnspbzQWNjEI(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊่่ࠥศศ่ࠫᐖ")
	,Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᐗ")	:Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠใ่๋หฯ࠭ᐘ")
	,v7reLlOXCgD5pZ14w2tUA(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡺ࡯ࡱ࡫ࡦࡷࠬᐙ")	:V391t7nQWUBR5euCkJ(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็่ࠢ์ฬ฼ฺ๊ࠩᐚ")
	,vkMRnTNV9jFm(u"ࠩ࡬ࡴࡹࡼࠧᐛ")					:a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠪࡍࡕ࡚ࡖࠨᐜ")
	,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧᐝ")			:tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩᐞ")
	,q0JfWbP8vACLxSNIncpOXkR6j(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫᐟ")			:vkMRnTNV9jFm(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫᐠ")
	,lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᐡ")			:Vv0lSjAOHLfMnam3wtdor(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨᐢ")
	,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪࡱ࠸ࡻࠧᐣ")					:L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡒ࠹ࡕࠨᐤ")
	,tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠬࡳ࠳ࡶ࠯࡯࡭ࡻ࡫ࠧᐥ")				:OARzhnB9o7uYvQGFaIcZ(u"࠭ࡍ࠴ࡗࠣๆ๋๎วหࠩᐦ")
	,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠧ࡮࠵ࡸ࠱ࡲࡵࡶࡪࡧࡶࠫᐧ")			:HMO0QciekqVpLKmA(u"ࠨࡏ࠶࡙ࠥษแๅษ่ࠫᐨ")
	,HMO0QciekqVpLKmA(u"ࠩࡰ࠷ࡺ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᐩ")			:Vv0lSjAOHLfMnam3wtdor(u"ࠪࡑ࠸࡛ࠠๆี็ื้อสࠨᐪ")
	}
	try: XkmDQevS23waz0pfAJ5KYHUVTG = FEtAPKBz8buQHmwxS1h2[gq2FVNBUKPzIw1pZAnYHJG.lower()]
	except: XkmDQevS23waz0pfAJ5KYHUVTG = tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࠬᐫ")
	return XkmDQevS23waz0pfAJ5KYHUVTG
def RYNAu9Eo7mgOi0sG1j(hTZjiRxwmYoWpKtJIHVug36G=u1ml5XcLiZ7oDPs3UjedgpYHhfV(u"ࠬ࠭ᐬ")):
	wwXV0G1ObAMk()
	if not hTZjiRxwmYoWpKtJIHVug36G: hTZjiRxwmYoWpKtJIHVug36G = DKqQekNtF6WlJLhBP9M5ca(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡅࡹ࡫ࡷࠫᐭ")
	zRM3tZx2v6DjJU(xxBJoKG54uwQ(u"ࠧࠨᐮ"),OARzhnB9o7uYvQGFaIcZ(u"ࠨ࡞ࡱࠫᐯ")+hTZjiRxwmYoWpKtJIHVug36G+xxBJoKG54uwQ(u"ࠩ࡟ࡲࠬᐰ"))
	try: GJtcqTv68ZQpwxYFiDg.exit()
	except: pass
	return
def oF0Yr4V7Ic(DDRulV7aKN3jCOWSBQkb95,h5hL2k0Zt9AGYUWVMFToNQs7DS=qNZKwi2M1S4fBzGQYrmPnea(u"ࠪ࠾࠴࠭ᐱ")):
	return _dnwNWD5Ze(DDRulV7aKN3jCOWSBQkb95,h5hL2k0Zt9AGYUWVMFToNQs7DS)
def k968FPxJ4HRGTLDENAnO2Z7c(cwaBpyYtN1kVAR2HiP):
	if cwaBpyYtN1kVAR2HiP in [q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࠬᐲ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠬ࠶ࠧᐳ"),xxBJoKG54uwQ(u"࠳ᛑ")]: return zOZvXaebGNwHKfjRA(u"࠭ࠧᐴ")
	cwaBpyYtN1kVAR2HiP = int(cwaBpyYtN1kVAR2HiP)
	RKJ6xs4wmiWfrTt2AFqPNhXOcL = cwaBpyYtN1kVAR2HiP^lu4xpkY5LFOm6t2In
	YtWRbyDUc10 = cwaBpyYtN1kVAR2HiP^t7rXIzJfMLWRwaDeKhTq4C6dG
	soezS0bDYr3V9RKxMCQWtNa = cwaBpyYtN1kVAR2HiP^oXSZ6AEbPukBvwKmyarstdWR5qz0
	XkmDQevS23waz0pfAJ5KYHUVTG = str(RKJ6xs4wmiWfrTt2AFqPNhXOcL)+str(YtWRbyDUc10)+str(soezS0bDYr3V9RKxMCQWtNa)
	return XkmDQevS23waz0pfAJ5KYHUVTG
def QchkyieO4zK0YmZlHvCETP7F(cwaBpyYtN1kVAR2HiP):
	if cwaBpyYtN1kVAR2HiP in [zOZvXaebGNwHKfjRA(u"ࠧࠨᐵ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠨ࠲ࠪᐶ"),dxAs4otSE98YmZnKy2iwRCB(u"࠴ᛒ")]: return DDS79jdWzLtE(u"ࠩࠪᐷ")
	cwaBpyYtN1kVAR2HiP = str(cwaBpyYtN1kVAR2HiP)
	XkmDQevS23waz0pfAJ5KYHUVTG = GGTRaYBDeNyI25zlF(u"ࠪࠫᐸ")
	if len(cwaBpyYtN1kVAR2HiP)==zOZvXaebGNwHKfjRA(u"࠶࠻ᛓ"):
		RKJ6xs4wmiWfrTt2AFqPNhXOcL,YtWRbyDUc10,soezS0bDYr3V9RKxMCQWtNa = cwaBpyYtN1kVAR2HiP[gr5K72RtvAZYPVwkdnspbzQWNjEI(u"࠰ᛕ"):Vv0lSjAOHLfMnam3wtdor(u"࠵ᛖ")],cwaBpyYtN1kVAR2HiP[Vv0lSjAOHLfMnam3wtdor(u"࠵ᛖ"):OARzhnB9o7uYvQGFaIcZ(u"࠿ᛔ")],cwaBpyYtN1kVAR2HiP[OARzhnB9o7uYvQGFaIcZ(u"࠿ᛔ"):]
		RKJ6xs4wmiWfrTt2AFqPNhXOcL = int(RKJ6xs4wmiWfrTt2AFqPNhXOcL)^oXSZ6AEbPukBvwKmyarstdWR5qz0
		YtWRbyDUc10 = int(YtWRbyDUc10)^t7rXIzJfMLWRwaDeKhTq4C6dG
		soezS0bDYr3V9RKxMCQWtNa = int(soezS0bDYr3V9RKxMCQWtNa)^lu4xpkY5LFOm6t2In
		if RKJ6xs4wmiWfrTt2AFqPNhXOcL==YtWRbyDUc10==soezS0bDYr3V9RKxMCQWtNa: XkmDQevS23waz0pfAJ5KYHUVTG = str(RKJ6xs4wmiWfrTt2AFqPNhXOcL*dxAs4otSE98YmZnKy2iwRCB(u"࠸࠳ᛗ"))
	return XkmDQevS23waz0pfAJ5KYHUVTG
def AkEMLcQGwo0qnlB8VJeKiUTpX(cwaBpyYtN1kVAR2HiP,yEDBWJgx7UiN=IJ6VkihabRm(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ᐹ")):
	if cwaBpyYtN1kVAR2HiP==IJ6VkihabRm(u"ࠬ࠭ᐺ"): return L91nVzxH4hYrgPDsOuljXd0J(u"࠭ࠧᐻ")
	cwaBpyYtN1kVAR2HiP = int(cwaBpyYtN1kVAR2HiP)+int(yEDBWJgx7UiN)
	RKJ6xs4wmiWfrTt2AFqPNhXOcL = cwaBpyYtN1kVAR2HiP^lu4xpkY5LFOm6t2In
	YtWRbyDUc10 = cwaBpyYtN1kVAR2HiP^t7rXIzJfMLWRwaDeKhTq4C6dG
	soezS0bDYr3V9RKxMCQWtNa = cwaBpyYtN1kVAR2HiP^oXSZ6AEbPukBvwKmyarstdWR5qz0
	XkmDQevS23waz0pfAJ5KYHUVTG = str(RKJ6xs4wmiWfrTt2AFqPNhXOcL)+str(YtWRbyDUc10)+str(soezS0bDYr3V9RKxMCQWtNa)
	return XkmDQevS23waz0pfAJ5KYHUVTG
def mmVNtesjMRgxqrAziOH(cwaBpyYtN1kVAR2HiP,yEDBWJgx7UiN=ddK4MmwpX5oG(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᐼ")):
	if cwaBpyYtN1kVAR2HiP==xxpPYJOnoAUrlBzyveui(u"ࠨࠩᐽ"): return L91nVzxH4hYrgPDsOuljXd0J(u"ࠩࠪᐾ")
	cwaBpyYtN1kVAR2HiP = str(cwaBpyYtN1kVAR2HiP)
	wwRk9qaXWGj5EoLmJIprzNUn23 = int(len(cwaBpyYtN1kVAR2HiP)/DDS79jdWzLtE(u"࠶ᛘ"))
	RKJ6xs4wmiWfrTt2AFqPNhXOcL = int(cwaBpyYtN1kVAR2HiP[v7reLlOXCgD5pZ14w2tUA(u"࠴ᛙ"):wwRk9qaXWGj5EoLmJIprzNUn23])^lu4xpkY5LFOm6t2In
	YtWRbyDUc10 = int(cwaBpyYtN1kVAR2HiP[wwRk9qaXWGj5EoLmJIprzNUn23:IJ6VkihabRm(u"࠷ᛚ")*wwRk9qaXWGj5EoLmJIprzNUn23])^t7rXIzJfMLWRwaDeKhTq4C6dG
	soezS0bDYr3V9RKxMCQWtNa = int(cwaBpyYtN1kVAR2HiP[uhOkAKtLVv4XTy1nWE6(u"࠲ᛜ")*wwRk9qaXWGj5EoLmJIprzNUn23:GGTRaYBDeNyI25zlF(u"࠹ᛛ")*wwRk9qaXWGj5EoLmJIprzNUn23])^oXSZ6AEbPukBvwKmyarstdWR5qz0
	XkmDQevS23waz0pfAJ5KYHUVTG = ZpH2IWt7veyFobTsAnhi41(u"ࠪࠫᐿ")
	if RKJ6xs4wmiWfrTt2AFqPNhXOcL==YtWRbyDUc10==soezS0bDYr3V9RKxMCQWtNa: XkmDQevS23waz0pfAJ5KYHUVTG = str(int(RKJ6xs4wmiWfrTt2AFqPNhXOcL)-int(yEDBWJgx7UiN))
	return XkmDQevS23waz0pfAJ5KYHUVTG
def LMZrdQzbSEKc9FYCkl6W8GO(lkY6tyL52EB1ufgqR8QerO4Cz0Upd):
	n0nwqJ6Pdj = EGcFon0zR4mSL1[L91nVzxH4hYrgPDsOuljXd0J(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᑀ")][tKVplxqYIdngGF6TZkXeb2PiwfME(u"࠹ᛝ")]
	HHeMRB2blgL5NpZ = Dx3jCK6X7lktdiE(lunVJF2G5bZMgTcCje0vaIB371SX(u"࠵࠵ᛞ"))
	tcJqdRPC6K0aNH1YSshW8joFiAb7XV = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(o76CsefkuZhcgDJlX,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨᑁ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡳ࡬࡫ࡱࡷࠬᑂ"),GGTRaYBDeNyI25zlF(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨᑃ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠨ࠹࠵࠴ࡵ࠭ᑄ"),tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫᑅ"))
	FFZsWuoVx09TC,w7qNAgWsPMope3TZ2 = jGA1fuPNEcDJC7TFb9xhO30R(tcJqdRPC6K0aNH1YSshW8joFiAb7XV)
	FFZsWuoVx09TC = AkEMLcQGwo0qnlB8VJeKiUTpX(FFZsWuoVx09TC,ddK4MmwpX5oG(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᑆ"))
	O2ckxvB436D = {iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫ࡮ࡪࡳࠨᑇ"):vkMRnTNV9jFm(u"ࠬࡊࡉࡂࡎࡒࡋࠬᑈ"),OARzhnB9o7uYvQGFaIcZ(u"࠭ࡵࡴࡴࠪᑉ"):HHeMRB2blgL5NpZ,f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡷࡧࡵࠫᑊ"):uVp7krjL48oWd3tqGYCRz5M,V391t7nQWUBR5euCkJ(u"ࠨࡵࡦࡶࠬᑋ"):lkY6tyL52EB1ufgqR8QerO4Cz0Upd,gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡶ࡭ࡿ࠭ᑌ"):FFZsWuoVx09TC}
	f3fnZ6AQH0jBGPvXOFL = {DDS79jdWzLtE(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᑍ"):tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪᑎ")}
	Um9IVQRTNFx30OLfJPpDAsBdCcnwe = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡖࡏࡔࡖࠪᑏ"),n0nwqJ6Pdj,O2ckxvB436D,f3fnZ6AQH0jBGPvXOFL,DKqQekNtF6WlJLhBP9M5ca(u"࠭ࠧᑐ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠨᑑ"),ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩᑒ"))
	u9EgjMmdbLFD5KQh7XBR6TJCfqtWsl = Um9IVQRTNFx30OLfJPpDAsBdCcnwe.content
	try:
		if not u9EgjMmdbLFD5KQh7XBR6TJCfqtWsl: bmFY3HKR7twVpGjB5iW0hOcdLeaDX
		rrjwPDp8UaiFSzGs6 = kMLWTt2fO9dnGDUgHh(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠩࡧ࡭ࡨࡺࠧᑓ"),u9EgjMmdbLFD5KQh7XBR6TJCfqtWsl)
		Fuedn0hYfzLN = rrjwPDp8UaiFSzGs6[p1lrNRIXqLQJznH6O(u"ࠪࡱࡸ࡭ࠧᑔ")]
		ztZVJ4lcwvOeFkA9IDBgjX = rrjwPDp8UaiFSzGs6[HMO0QciekqVpLKmA(u"ࠫࡸ࡫ࡣࠨᑕ")]
		Q26uAYzZ30M4CISrHpeRBfP = rrjwPDp8UaiFSzGs6[V391t7nQWUBR5euCkJ(u"ࠬࡹࡴࡱࠩᑖ")]
		ztZVJ4lcwvOeFkA9IDBgjX = int(mmVNtesjMRgxqrAziOH(ztZVJ4lcwvOeFkA9IDBgjX,v7reLlOXCgD5pZ14w2tUA(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᑗ")))
		Q26uAYzZ30M4CISrHpeRBfP = int(mmVNtesjMRgxqrAziOH(Q26uAYzZ30M4CISrHpeRBfP,DDS79jdWzLtE(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᑘ")))
		for jTP5d6tfznqH1A in range(ztZVJ4lcwvOeFkA9IDBgjX,DDS79jdWzLtE(u"࠳ᛟ"),-Q26uAYzZ30M4CISrHpeRBfP):
			if not eval(ddK4MmwpX5oG(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫᑙ"),{iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩࡻࡦࡲࡩࠧᑚ"):AAsbUG0jZ5igBpNKQwFrJTd}): bmFY3HKR7twVpGjB5iW0hOcdLeaDX
			uFCykYQW68S(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩᑛ"),str(jTP5d6tfznqH1A)+Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠫࠥࠦหศ่ํอࠬᑜ"),vODi7LQeCnUaoRqZX9xs6djwm0tJA2=xxBJoKG54uwQ(u"࠷࠵࠶ᛠ")*Q26uAYzZ30M4CISrHpeRBfP)
			AAsbUG0jZ5igBpNKQwFrJTd.sleep(xxpPYJOnoAUrlBzyveui(u"࠶࠶࠰࠱ᛡ")*Q26uAYzZ30M4CISrHpeRBfP)
		if eval(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨᑝ"),{p1lrNRIXqLQJznH6O(u"࠭ࡸࡣ࡯ࡦࠫᑞ"):AAsbUG0jZ5igBpNKQwFrJTd}):
			Fuedn0hYfzLN = Fuedn0hYfzLN.replace(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠧ࡝ࡰࠪᑟ"),V391t7nQWUBR5euCkJ(u"ࠨ࡞࡟ࡲࠬᑠ")).replace(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩ࡟ࡶࠬᑡ"),q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࡠࡡࡸࠧᑢ"))
			qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(Vv0lSjAOHLfMnam3wtdor(u"ࠫࠬᑣ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠬิั้ฮࠪᑤ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᑥ"),Fuedn0hYfzLN)
		bmFY3HKR7twVpGjB5iW0hOcdLeaDX
	except: exec(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧᑦ"),{DKqQekNtF6WlJLhBP9M5ca(u"ࠨࡺࡥࡱࡨ࠭ᑧ"):AAsbUG0jZ5igBpNKQwFrJTd})
	return
def ZJizjHDV1Ec():
	exec(OARzhnB9o7uYvQGFaIcZ(u"ࠩࠪࠫࠒࠐࡴࡳࡻ࠽ࠑࠏࠏࡷࡪࡰࡧࡳࡼ࠷࠲࠴ࠢࡀࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳࡝ࡩ࡯ࡦࡲࡻ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠒࠐࠉࠊࡺࡥࡱࡨ࠴ࡳ࡭ࡧࡨࡴ࠭࠷࠰࠱࠲ࠬࠑࠏࠏࠉࡵࡴࡼ࠾ࠥࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳࠯ࡩࡨࡸࡋࡵࡣࡶࡵࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡣࡴࡨࡥࡰࠓࠊࠊࡼࡦࡶࡪࡧࡴࡦࡡࡨࡶࡴࡸࡲࠎࠌࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠐࠎࠬ࠭ࠧᑨ"),{zOZvXaebGNwHKfjRA(u"ࠪࡼࡧࡳࡣࡨࡷ࡬ࠫᑩ"):yOuHBDmPps3vd24cnLagiK0,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡽࡨ࡭ࡤࠩᑪ"):AAsbUG0jZ5igBpNKQwFrJTd})
	return
def jGA1fuPNEcDJC7TFb9xhO30R(AeX8tIu4jVHh9p6STsFBq57KrmxU):
	Ke9kQrDVvBJ5Ao7yMFz84iChj,KDxoah0WRdY1 = xxpPYJOnoAUrlBzyveui(u"࠶ᛢ"),xxpPYJOnoAUrlBzyveui(u"࠶ᛢ")
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(AeX8tIu4jVHh9p6STsFBq57KrmxU):
		try: Ke9kQrDVvBJ5Ao7yMFz84iChj = YcJmC0W43u5idIELnHTU2XSsMPNt.path.getsize(AeX8tIu4jVHh9p6STsFBq57KrmxU)
		except: pass
		if not Ke9kQrDVvBJ5Ao7yMFz84iChj:
			try: Ke9kQrDVvBJ5Ao7yMFz84iChj = YcJmC0W43u5idIELnHTU2XSsMPNt.stat(AeX8tIu4jVHh9p6STsFBq57KrmxU).st_size
			except: pass
		if not Ke9kQrDVvBJ5Ao7yMFz84iChj:
			try:
				from pathlib import Path as CuROXkImdhA5
				Ke9kQrDVvBJ5Ao7yMFz84iChj = CuROXkImdhA5(AeX8tIu4jVHh9p6STsFBq57KrmxU).stat().st_size
			except: pass
		if Ke9kQrDVvBJ5Ao7yMFz84iChj: KDxoah0WRdY1 = HMO0QciekqVpLKmA(u"࠱ᛣ")
	return Ke9kQrDVvBJ5Ao7yMFz84iChj,KDxoah0WRdY1
def Qzbnt3opXim(V0pq8XkbWRN2aw,WwP7nt1Q5O6NGhYzE4AckiJu,showDialogs):
	if showDialogs:
		T4TGmZ9XWAzONaKygic = C5JBeSxPzuskXi1ROnMHAmWp06dE7(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬ࠭ᑫ"),xxpPYJOnoAUrlBzyveui(u"࠭ࠧᑬ"),a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"ࠧࠨᑭ"),zOZvXaebGNwHKfjRA(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᑮ"),V0pq8XkbWRN2aw+vkMRnTNV9jFm(u"ࠩ࡟ࡲࡡࡴࠧᑯ")+iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑰ"))
		if T4TGmZ9XWAzONaKygic!=fcIm8tvxlXZsaEY3bwuG4B(u"࠲ᛤ"): return
	ezX76WkqKRxdtsvh = d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡉࡥࡱࡹࡥ᝝")
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(V0pq8XkbWRN2aw):
		for g8DC39dWMXIQzbL,RuTpf6SV4Odzc3UA,HVo1hFNm72wup35f in YcJmC0W43u5idIELnHTU2XSsMPNt.walk(V0pq8XkbWRN2aw,topdown=IJ6VkihabRm(u"ࡊࡦࡲࡳࡦ᝞")):
			for AeX8tIu4jVHh9p6STsFBq57KrmxU in HVo1hFNm72wup35f:
				foRZD05OyirbCcmLK = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(g8DC39dWMXIQzbL,AeX8tIu4jVHh9p6STsFBq57KrmxU)
				try: YcJmC0W43u5idIELnHTU2XSsMPNt.remove(foRZD05OyirbCcmLK)
				except Exception as L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA:
					if showDialogs and not ezX76WkqKRxdtsvh: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠫࠬᑱ"),DDS79jdWzLtE(u"ࠬ࠭ᑲ"),f8PVRTseIuj9BckO6GoyF5Lxv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᑳ"),str(L5lVOBQvKrq9Fx1UgEeJGh8NtjYzA))
					ezX76WkqKRxdtsvh = ldOGfm56kWs8T03wcptQunqEUBDrvC(u"࡙ࡸࡵࡦ᝟")
			if WwP7nt1Q5O6NGhYzE4AckiJu:
				for dir in RuTpf6SV4Odzc3UA:
					ise63NmwBv5J4AWV7OG0QuY19d = YcJmC0W43u5idIELnHTU2XSsMPNt.path.join(g8DC39dWMXIQzbL,dir)
					try: YcJmC0W43u5idIELnHTU2XSsMPNt.rmdir(ise63NmwBv5J4AWV7OG0QuY19d)
					except: pass
		if WwP7nt1Q5O6NGhYzE4AckiJu:
			try: YcJmC0W43u5idIELnHTU2XSsMPNt.rmdir(g8DC39dWMXIQzbL)
			except: pass
	if showDialogs and not ezX76WkqKRxdtsvh:
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u(Arg2GFJDt3emTvpO6fZkSVdaUHywnN(u"ࠧࠨᑴ"),fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࠩᑵ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᑶ"),uhOkAKtLVv4XTy1nWE6(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᑷ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(GGTRaYBDeNyI25zlF(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᑸ"),ddK4MmwpX5oG(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᑹ"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(DDS79jdWzLtE(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᑺ"))
	return
def wwXV0G1ObAMk(CeJXk5gb27o=L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠨᑻ")):
	aarhp43yvIqojdnWs6Sb(dxAs4otSE98YmZnKy2iwRCB(u"ࠨࡵࡷࡳࡵ࠭ᑼ"))
	if CeJXk5gb27o:
		EEtGsIqDNX = fQ6kvwg1FrYAzXjbLT.getSetting(fcIm8tvxlXZsaEY3bwuG4B(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᑽ"))
		fQ6kvwg1FrYAzXjbLT.setSetting(DKqQekNtF6WlJLhBP9M5ca(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫᑾ"),ddK4MmwpX5oG(u"ࠫࠬᑿ"))
		ETVMAFtlKdgY5WO3Uz6wNnPs8(CeJXk5gb27o)
		fQ6kvwg1FrYAzXjbLT.setSetting(fcIm8tvxlXZsaEY3bwuG4B(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ᒀ"),EEtGsIqDNX)
	PqREL0OwgzB = fQ6kvwg1FrYAzXjbLT.getSetting(HMO0QciekqVpLKmA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᒁ"))
	if PqREL0OwgzB==ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪᒂ"): fQ6kvwg1FrYAzXjbLT.setSetting(gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᒃ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬᒄ"))
	elif PqREL0OwgzB==uhOkAKtLVv4XTy1nWE6(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭ᒅ"): fQ6kvwg1FrYAzXjbLT.setSetting(V391t7nQWUBR5euCkJ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᒆ"),gr5K72RtvAZYPVwkdnspbzQWNjEI(u"ࠬ࠭ᒇ"))
	if fQ6kvwg1FrYAzXjbLT.getSetting(KbL94nDHufSF0VcO2Nk3(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᒈ")) not in [f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠧࡂࡗࡗࡓࠬᒉ"),DDS79jdWzLtE(u"ࠨࡕࡗࡓࡕ࠭ᒊ"),uhOkAKtLVv4XTy1nWE6(u"ࠩࡄࡗࡐ࠭ᒋ")]: fQ6kvwg1FrYAzXjbLT.setSetting(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᒌ"),iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠫࡆ࡙ࡋࠨᒍ"))
	if fQ6kvwg1FrYAzXjbLT.getSetting(iRTygNp4Lf36wQKlD2MHUhG7B(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᒎ")) not in [fcIm8tvxlXZsaEY3bwuG4B(u"࠭ࡁࡖࡖࡒࠫᒏ"),uhOkAKtLVv4XTy1nWE6(u"ࠧࡔࡖࡒࡔࠬᒐ"),Vv0lSjAOHLfMnam3wtdor(u"ࠨࡃࡖࡏࠬᒑ")]: fQ6kvwg1FrYAzXjbLT.setSetting(ddK4MmwpX5oG(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᒒ"),GGTRaYBDeNyI25zlF(u"ࠪࡅࡘࡑࠧᒓ"))
	YxltFNqsr6BSEy5uzdf7o = fQ6kvwg1FrYAzXjbLT.getSetting(OARzhnB9o7uYvQGFaIcZ(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩᒔ"))
	AsqvTSMpVNy = AAsbUG0jZ5igBpNKQwFrJTd.executeJSONRPC(vkMRnTNV9jFm(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨᒕ"))
	if d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᒖ") in str(AsqvTSMpVNy) and YxltFNqsr6BSEy5uzdf7o in [Vv0lSjAOHLfMnam3wtdor(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪᒗ"),KbL94nDHufSF0VcO2Nk3(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧᒘ")]:
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2.sleep(OARzhnB9o7uYvQGFaIcZ(u"࠲࠱࠵࠵࠶ᛥ"))
		AAsbUG0jZ5igBpNKQwFrJTd.executebuiltin(vkMRnTNV9jFm(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭ᒙ"))
	if Vv0lSjAOHLfMnam3wtdor(u"࠴ᛧ") and EhfrVPICebQ>-xxBJoKG54uwQ(u"࠴ᛦ"):
		LL2eGTPdkm.setResolvedUrl(EhfrVPICebQ,d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࡌࡡ࡭ࡵࡨᝠ"),yOuHBDmPps3vd24cnLagiK0.ListItem())
		BcMl3XdLS0zmK1jPvDJANfYH,eyVMOEac7fTNr3xg0ZwktiGJl,LnsZiRWqVNw2Ju = p1lrNRIXqLQJznH6O(u"ࡆࡢ࡮ࡶࡩᝡ"),p1lrNRIXqLQJznH6O(u"ࡆࡢ࡮ࡶࡩᝡ"),p1lrNRIXqLQJznH6O(u"ࡆࡢ࡮ࡶࡩᝡ")
		LL2eGTPdkm.endOfDirectory(EhfrVPICebQ,BcMl3XdLS0zmK1jPvDJANfYH,eyVMOEac7fTNr3xg0ZwktiGJl,LnsZiRWqVNw2Ju)
	return
def KwXiyRO72Gju(b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX,bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,oBQqw316KAIpOdr7R0LxkZNW5lG4y):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ppim7Ofn2Nx,otFfgXKET5vz3YV0lI6,bZ5puKhzrkQcvRiqV0XgP3JxNLST = llpngAoQVzND(DDRulV7aKN3jCOWSBQkb95)
	zO0UA5L7ta1sIHpmqjbeBvXf3Kky = bB2eVZo9P8TpLU1Rw,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT
	if b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX:
		RkLE6BzZ2KX = C2GD7eO9f6tEjiPuW4xVLv1QH30nh(oorOICHY4MvRsWg1Xk8,ddK4MmwpX5oG(u"ࠪࡷࡹࡸࠧᒚ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬᒛ"),zO0UA5L7ta1sIHpmqjbeBvXf3Kky)
		if RkLE6BzZ2KX:
			BEt0xkYQrnLpwZ4JaFUDM8oX5vAN(p1lrNRIXqLQJznH6O(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᒜ"),DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,oBQqw316KAIpOdr7R0LxkZNW5lG4y,bB2eVZo9P8TpLU1Rw)
			return RkLE6BzZ2KX
	RkLE6BzZ2KX = aAl73ft1UpVOXoST5uL(bB2eVZo9P8TpLU1Rw,DDRulV7aKN3jCOWSBQkb95,ZEJAFRNxIrQSU,iPmj7p45q2duSAQaHvOnT,oBQqw316KAIpOdr7R0LxkZNW5lG4y)
	if RkLE6BzZ2KX and b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX: mhr0way8dQLUMt6uSIPqGW(oorOICHY4MvRsWg1Xk8,iRTygNp4Lf36wQKlD2MHUhG7B(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧᒝ"),zO0UA5L7ta1sIHpmqjbeBvXf3Kky,RkLE6BzZ2KX,b4JMDSl5sV7R6wIKq0E8xk1hFvaUGX)
	return RkLE6BzZ2KX
from GkzbNxprZm import *
# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
amlcehCxU3O2yoGf = 'FAVORITES'
def M8xBdHmhrtyWIoL1e6VNvk(Q6FbqZ9uIe8v2xaTHhfDCJ,mVBTWrCAcnxS):
	if   Q6FbqZ9uIe8v2xaTHhfDCJ==270: X8M3EvbVAIGCNpgU7 = QKeHO0hSmMnC6GyRYxqzNVfXUbjd(mVBTWrCAcnxS)
	else: X8M3EvbVAIGCNpgU7 = False
	return X8M3EvbVAIGCNpgU7
def Ty3qJ1wj7MIphX(C32AEk8uZTeFPI94LG6dmczv):
	if not C32AEk8uZTeFPI94LG6dmczv: return
	if '_' in C32AEk8uZTeFPI94LG6dmczv: mVBTWrCAcnxS,paRuwvcbSJKq10TZBhon9Yfjy8Akr = C32AEk8uZTeFPI94LG6dmczv.split('_',1)
	else: mVBTWrCAcnxS,paRuwvcbSJKq10TZBhon9Yfjy8Akr = C32AEk8uZTeFPI94LG6dmczv,''
	if   paRuwvcbSJKq10TZBhon9Yfjy8Akr=='UP1'	: NlxzqmrZDCeoksO(mVBTWrCAcnxS,True,1)
	elif paRuwvcbSJKq10TZBhon9Yfjy8Akr=='DOWN1'	: NlxzqmrZDCeoksO(mVBTWrCAcnxS,False,1)
	elif paRuwvcbSJKq10TZBhon9Yfjy8Akr=='UP4'	: NlxzqmrZDCeoksO(mVBTWrCAcnxS,True,4)
	elif paRuwvcbSJKq10TZBhon9Yfjy8Akr=='DOWN4'	: NlxzqmrZDCeoksO(mVBTWrCAcnxS,False,4)
	elif paRuwvcbSJKq10TZBhon9Yfjy8Akr=='ADD1'	: JwjvdQ9XxhoWGUr0Mz1aOsE4Cp(mVBTWrCAcnxS)
	elif paRuwvcbSJKq10TZBhon9Yfjy8Akr=='REMOVE1': ojTxKdrWAYuDs(mVBTWrCAcnxS)
	elif paRuwvcbSJKq10TZBhon9Yfjy8Akr=='DELETELIST': Un3g0wH2VSh51eiTkaAW8v4(mVBTWrCAcnxS)
	return
def QKeHO0hSmMnC6GyRYxqzNVfXUbjd(mVBTWrCAcnxS):
	UL9SFJloiGeWzfIa7154jg = Gmw6J5PRDV7kStnI0KzH9oa()
	if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()):
		try:
			ooluxmzwbc8JdAfIOQBWqDS = UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]
			for ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo in ooluxmzwbc8JdAfIOQBWqDS:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB(ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo)
		except:
			UL9SFJloiGeWzfIa7154jg = MMnGsYl0Oh9zgub43E5m(KmlAH1VJObEkfZS3ToazF8qNP70t)
			ooluxmzwbc8JdAfIOQBWqDS = UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]
			for ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo in ooluxmzwbc8JdAfIOQBWqDS:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB(ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo)
	return
def JwjvdQ9XxhoWGUr0Mz1aOsE4Cp(mVBTWrCAcnxS):
	ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo = JJqxTSR6tZiQ79cpkwa3GMy(a4EuYDiRdrA)
	Gi8FAfgwEsPZ = ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,'',T1zaK6eDkFcyCBldWR3YMuJgIQo
	UL9SFJloiGeWzfIa7154jg = Gmw6J5PRDV7kStnI0KzH9oa()
	IpCgcHbG3PlZ8rY = {}
	for oT6L5Ohwdiu3vj4exZY7J in list(UL9SFJloiGeWzfIa7154jg.keys()):
		if oT6L5Ohwdiu3vj4exZY7J!=mVBTWrCAcnxS: IpCgcHbG3PlZ8rY[oT6L5Ohwdiu3vj4exZY7J] = UL9SFJloiGeWzfIa7154jg[oT6L5Ohwdiu3vj4exZY7J]
		else:
			if pphVUbJkGtHXndg84iZl2DPImSzoC and pphVUbJkGtHXndg84iZl2DPImSzoC!='..':
				fPvcO8ReZgSJVqQr17FzC = UL9SFJloiGeWzfIa7154jg[oT6L5Ohwdiu3vj4exZY7J]
				if Gi8FAfgwEsPZ in fPvcO8ReZgSJVqQr17FzC:
					cFf45qZHQNB = fPvcO8ReZgSJVqQr17FzC.index(Gi8FAfgwEsPZ)
					del fPvcO8ReZgSJVqQr17FzC[cFf45qZHQNB]
				aaLseWxHl5BzrDhq = fPvcO8ReZgSJVqQr17FzC+[Gi8FAfgwEsPZ]
				IpCgcHbG3PlZ8rY[oT6L5Ohwdiu3vj4exZY7J] = aaLseWxHl5BzrDhq
			else: IpCgcHbG3PlZ8rY[oT6L5Ohwdiu3vj4exZY7J] = UL9SFJloiGeWzfIa7154jg[oT6L5Ohwdiu3vj4exZY7J]
	if mVBTWrCAcnxS not in list(IpCgcHbG3PlZ8rY.keys()): IpCgcHbG3PlZ8rY[mVBTWrCAcnxS] = [Gi8FAfgwEsPZ]
	I6ZOA2afDQiT9YCwrqhdpozJy = str(IpCgcHbG3PlZ8rY)
	if Nnxm30dfoBWRYpIC7KsQGl: I6ZOA2afDQiT9YCwrqhdpozJy = I6ZOA2afDQiT9YCwrqhdpozJy.encode('utf8')
	open(KmlAH1VJObEkfZS3ToazF8qNP70t,'wb').write(I6ZOA2afDQiT9YCwrqhdpozJy)
	return
def ojTxKdrWAYuDs(mVBTWrCAcnxS):
	ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo = JJqxTSR6tZiQ79cpkwa3GMy(a4EuYDiRdrA)
	Gi8FAfgwEsPZ = ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,'',T1zaK6eDkFcyCBldWR3YMuJgIQo
	UL9SFJloiGeWzfIa7154jg = Gmw6J5PRDV7kStnI0KzH9oa()
	if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()) and Gi8FAfgwEsPZ in UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]:
		UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS].remove(Gi8FAfgwEsPZ)
		if len(UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS])==0: del UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]
		I6ZOA2afDQiT9YCwrqhdpozJy = str(UL9SFJloiGeWzfIa7154jg)
		if Nnxm30dfoBWRYpIC7KsQGl: I6ZOA2afDQiT9YCwrqhdpozJy = I6ZOA2afDQiT9YCwrqhdpozJy.encode('utf8')
		open(KmlAH1VJObEkfZS3ToazF8qNP70t,'wb').write(I6ZOA2afDQiT9YCwrqhdpozJy)
	return
def NlxzqmrZDCeoksO(mVBTWrCAcnxS,ZGy3jmqO2earJSEgB4iM7YLc6VA05,F7jOUsryzAe):
	ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo = JJqxTSR6tZiQ79cpkwa3GMy(a4EuYDiRdrA)
	Gi8FAfgwEsPZ = ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,'',T1zaK6eDkFcyCBldWR3YMuJgIQo
	UL9SFJloiGeWzfIa7154jg = Gmw6J5PRDV7kStnI0KzH9oa()
	if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()):
		fPvcO8ReZgSJVqQr17FzC = UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]
		if Gi8FAfgwEsPZ not in fPvcO8ReZgSJVqQr17FzC: return
		VlsnhMRiIb2 = len(fPvcO8ReZgSJVqQr17FzC)
		for gI689nKoH2PlifU3AMW5vVEZpFYX1 in range(0,F7jOUsryzAe):
			aLW6tn8mxF0uBOQ = fPvcO8ReZgSJVqQr17FzC.index(Gi8FAfgwEsPZ)
			if ZGy3jmqO2earJSEgB4iM7YLc6VA05: FqPmCIKl0xbVUskt = aLW6tn8mxF0uBOQ-1
			else: FqPmCIKl0xbVUskt = aLW6tn8mxF0uBOQ+1
			if FqPmCIKl0xbVUskt>=VlsnhMRiIb2: FqPmCIKl0xbVUskt = FqPmCIKl0xbVUskt-VlsnhMRiIb2
			if FqPmCIKl0xbVUskt<0: FqPmCIKl0xbVUskt = FqPmCIKl0xbVUskt+VlsnhMRiIb2
			fPvcO8ReZgSJVqQr17FzC.insert(FqPmCIKl0xbVUskt, fPvcO8ReZgSJVqQr17FzC.pop(aLW6tn8mxF0uBOQ))
		UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS] = fPvcO8ReZgSJVqQr17FzC
		I6ZOA2afDQiT9YCwrqhdpozJy = str(UL9SFJloiGeWzfIa7154jg)
		if Nnxm30dfoBWRYpIC7KsQGl: I6ZOA2afDQiT9YCwrqhdpozJy = I6ZOA2afDQiT9YCwrqhdpozJy.encode('utf8')
		open(KmlAH1VJObEkfZS3ToazF8qNP70t,'wb').write(I6ZOA2afDQiT9YCwrqhdpozJy)
	return
def Un3g0wH2VSh51eiTkaAW8v4(mVBTWrCAcnxS):
	IjESVoUqQMhdb = C5JBeSxPzuskXi1ROnMHAmWp06dE7('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+mVBTWrCAcnxS+' ؟!')
	if IjESVoUqQMhdb!=1: return
	UL9SFJloiGeWzfIa7154jg = Gmw6J5PRDV7kStnI0KzH9oa()
	if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()):
		del UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]
		I6ZOA2afDQiT9YCwrqhdpozJy = str(UL9SFJloiGeWzfIa7154jg)
		if Nnxm30dfoBWRYpIC7KsQGl: I6ZOA2afDQiT9YCwrqhdpozJy = I6ZOA2afDQiT9YCwrqhdpozJy.encode('utf8')
		open(KmlAH1VJObEkfZS3ToazF8qNP70t,'wb').write(I6ZOA2afDQiT9YCwrqhdpozJy)
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+mVBTWrCAcnxS)
	return
def Gmw6J5PRDV7kStnI0KzH9oa():
	UL9SFJloiGeWzfIa7154jg = {}
	if YcJmC0W43u5idIELnHTU2XSsMPNt.path.exists(KmlAH1VJObEkfZS3ToazF8qNP70t):
		S7SGY20dR5qlOzgbkrPImF3M = open(KmlAH1VJObEkfZS3ToazF8qNP70t,'rb').read()
		if Nnxm30dfoBWRYpIC7KsQGl: S7SGY20dR5qlOzgbkrPImF3M = S7SGY20dR5qlOzgbkrPImF3M.decode('utf8')
		UL9SFJloiGeWzfIa7154jg = kMLWTt2fO9dnGDUgHh('dict',S7SGY20dR5qlOzgbkrPImF3M)
	return UL9SFJloiGeWzfIa7154jg
def yFAKIp45tgeszSo1hLX7nVxMEC(UL9SFJloiGeWzfIa7154jg,Gi8FAfgwEsPZ,lbHQygoU0Xkfd):
	ghLJETx5pD7,pphVUbJkGtHXndg84iZl2DPImSzoC,HbqSfZ6m7FAa,Q6FbqZ9uIe8v2xaTHhfDCJ,IsMuwXCDji,zt1qZvA74HunVPWCON,OO1XlVPzfQrMTmJv,C32AEk8uZTeFPI94LG6dmczv,T1zaK6eDkFcyCBldWR3YMuJgIQo = Gi8FAfgwEsPZ
	if not Q6FbqZ9uIe8v2xaTHhfDCJ: ghLJETx5pD7,Q6FbqZ9uIe8v2xaTHhfDCJ = 'folder','260'
	p6r2PTU4an1jqAVRH,mVBTWrCAcnxS = [],''
	if 'context=' in a4EuYDiRdrA:
		m1cP9L8ilAIHnaJUR4K = QPuHKNAT4jmCRg.findall('context=(\d+)',a4EuYDiRdrA,QPuHKNAT4jmCRg.DOTALL)
		if m1cP9L8ilAIHnaJUR4K: mVBTWrCAcnxS = str(m1cP9L8ilAIHnaJUR4K[0])
	if Q6FbqZ9uIe8v2xaTHhfDCJ=='270':
		mVBTWrCAcnxS = C32AEk8uZTeFPI94LG6dmczv
		if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()):
			p6r2PTU4an1jqAVRH.append(('مسح قائمة مفضلة '+mVBTWrCAcnxS,'RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_DELETELIST'+')'))
	else:
		if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()):
			count = len(UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS])
			if count>1: p6r2PTU4an1jqAVRH.append(('تحريك 1 للأعلى','RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_UP1)'))
			if count>4: p6r2PTU4an1jqAVRH.append(('تحريك 4 للأعلى','RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_UP4)'))
			if count>1: p6r2PTU4an1jqAVRH.append(('تحريك 1 للأسفل','RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_DOWN1)'))
			if count>4: p6r2PTU4an1jqAVRH.append(('تحريك 4 للأسفل','RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_DOWN4)'))
		for mVBTWrCAcnxS in ['1','2','3','4','5']:
			if mVBTWrCAcnxS in list(UL9SFJloiGeWzfIa7154jg.keys()) and Gi8FAfgwEsPZ in UL9SFJloiGeWzfIa7154jg[mVBTWrCAcnxS]:
				p6r2PTU4an1jqAVRH.append(('مسح من مفضلة '+mVBTWrCAcnxS,'RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_REMOVE1)'))
			else: p6r2PTU4an1jqAVRH.append(('إضافة إلى مفضلة '+mVBTWrCAcnxS,'RunPlugin('+lbHQygoU0Xkfd+'&context='+mVBTWrCAcnxS+'_ADD1)'))
	bDsBECYNvLKSqm2eWZFAuga = []
	for aWuvB7NU9knLyZfmVsHdR6eG1,bD3nxgCzGpwt1ulV0SBQO8YTkMcU4e in p6r2PTU4an1jqAVRH:
		aWuvB7NU9knLyZfmVsHdR6eG1 = '[COLOR FFFFFF00]'+aWuvB7NU9knLyZfmVsHdR6eG1+'[/COLOR]'
		bDsBECYNvLKSqm2eWZFAuga.append((aWuvB7NU9knLyZfmVsHdR6eG1,bD3nxgCzGpwt1ulV0SBQO8YTkMcU4e,))
	return bDsBECYNvLKSqm2eWZFAuga
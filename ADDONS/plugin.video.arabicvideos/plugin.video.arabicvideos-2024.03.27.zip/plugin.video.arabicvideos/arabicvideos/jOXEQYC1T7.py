﻿# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'ALMAAREF'
headers = {'User-Agent':''}
JE7QrkmhletLwA0OZXu = '_MRF_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def hLD0mk9HIuPOz7pw(mode,url,text,YSTbrKgPf7NyhIDizB):
	if   mode==40: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==41: RRMWBwU6pG = ppwOVfWkqTKEsUnghz()
	elif mode==42: RRMWBwU6pG = mAJEMXa3lHojhkd(text,YSTbrKgPf7NyhIDizB)
	elif mode==43: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==44: RRMWBwU6pG = SPFl6UGK4mrBua(text,YSTbrKgPf7NyhIDizB)
	elif mode==49: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('live',JE7QrkmhletLwA0OZXu+'البث الحي لقناة المعارف','',41)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',49)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	mAJEMXa3lHojhkd('','1')
	return
def F8FukV1MHUwd(vwIN38HprDqTW5Sh61exF7EnA,JWAQmTunlMk):
	search,sort,bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu,jsEpRxQH76,Y8RDiAxpEjS6PQkJHcMmF0aXo = '',[],[],[],[]
	aaxAKWtMwfPRE4zbqSQCOrBms0,W1Y5vuMjFXGsSoJq07cN = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(vwIN38HprDqTW5Sh61exF7EnA)
	for wMq2UBSjsfgchHzprXWFOTdn5 in list(W1Y5vuMjFXGsSoJq07cN.keys()):
		pp8iHB3W9Cs = W1Y5vuMjFXGsSoJq07cN[wMq2UBSjsfgchHzprXWFOTdn5]
		if not pp8iHB3W9Cs: continue
		if   wMq2UBSjsfgchHzprXWFOTdn5=='sort': sort = [pp8iHB3W9Cs]
		elif wMq2UBSjsfgchHzprXWFOTdn5=='series': bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu = [pp8iHB3W9Cs]
		elif wMq2UBSjsfgchHzprXWFOTdn5=='search': search = pp8iHB3W9Cs
		elif wMq2UBSjsfgchHzprXWFOTdn5=='category': jsEpRxQH76 = [pp8iHB3W9Cs]
		elif wMq2UBSjsfgchHzprXWFOTdn5=='specialist': Y8RDiAxpEjS6PQkJHcMmF0aXo = [pp8iHB3W9Cs]
	E9ODYnfpm54GJTd2xRrV = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":jsEpRxQH76,"specialist":Y8RDiAxpEjS6PQkJHcMmF0aXo,"series":bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(JWAQmTunlMk)}}
	import json as I3Iv0rxGQgMjk6bJLiaEcWZR
	E9ODYnfpm54GJTd2xRrV = I3Iv0rxGQgMjk6bJLiaEcWZR.dumps(E9ODYnfpm54GJTd2xRrV)
	VV7yf2htDCBU6EeSX8TJQM = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',VV7yf2htDCBU6EeSX8TJQM,E9ODYnfpm54GJTd2xRrV,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	data = kMLWTt2fO9dnGDUgHh('dict',Ht6Gg8lbciAd9FaUQVs)
	return data
def mAJEMXa3lHojhkd(vwIN38HprDqTW5Sh61exF7EnA,level):
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = F8FukV1MHUwd(vwIN38HprDqTW5Sh61exF7EnA,'1')
	wltPGJcYo12Ed = N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd['facets']
	if level=='1':
		wltPGJcYo12Ed = wltPGJcYo12Ed['video_categories']
		items = QPuHKNAT4jmCRg.findall('<div(.*?)/div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for F5o1sgcqZVlS in items:
			uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',F5o1sgcqZVlS+'<',QPuHKNAT4jmCRg.DOTALL)
			if not uuv3pk5MXdeaHt6sDxSFybTWz0Q: uuv3pk5MXdeaHt6sDxSFybTWz0Q = QPuHKNAT4jmCRg.findall('data-value=\\"(.*?)\\">(.*?)<',F5o1sgcqZVlS+'<',QPuHKNAT4jmCRg.DOTALL)
			jsEpRxQH76,title = uuv3pk5MXdeaHt6sDxSFybTWz0Q[0]
			if not vwIN38HprDqTW5Sh61exF7EnA: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,'',42,'','2','?category='+jsEpRxQH76)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,'',42,'','2',vwIN38HprDqTW5Sh61exF7EnA+'&category='+jsEpRxQH76)
	if level=='2':
		wltPGJcYo12Ed = wltPGJcYo12Ed['specialist']
		items = QPuHKNAT4jmCRg.findall('value="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for Y8RDiAxpEjS6PQkJHcMmF0aXo,title in items:
			if not Y8RDiAxpEjS6PQkJHcMmF0aXo: title = title = 'الجميع'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,'',42,'','3',vwIN38HprDqTW5Sh61exF7EnA+'&specialist='+Y8RDiAxpEjS6PQkJHcMmF0aXo)
	elif level=='3':
		wltPGJcYo12Ed = wltPGJcYo12Ed['series']
		items = QPuHKNAT4jmCRg.findall('value="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu,title in items:
			if not bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu: title = title = 'الجميع'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,'',42,'','4',vwIN38HprDqTW5Sh61exF7EnA+'&series='+bYAsHya7QJgfw6LKdj0l3M4zWZ8Nu)
	elif level=='4':
		wltPGJcYo12Ed = wltPGJcYo12Ed['sort_video']
		items = QPuHKNAT4jmCRg.findall('value="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for sort,title in items:
			if not sort: continue
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,'',44,'','1',vwIN38HprDqTW5Sh61exF7EnA+'&sort='+sort)
	return
def SPFl6UGK4mrBua(vwIN38HprDqTW5Sh61exF7EnA,JWAQmTunlMk):
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = F8FukV1MHUwd(vwIN38HprDqTW5Sh61exF7EnA,JWAQmTunlMk)
	wltPGJcYo12Ed = N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd['template']
	items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,43,G2WR0Oacvdq8ZQTjKboDU)
	wltPGJcYo12Ed = N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd['facets']['pagination']
	items = QPuHKNAT4jmCRg.findall('data-page="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for YSTbrKgPf7NyhIDizB,title in items:
		if JWAQmTunlMk==YSTbrKgPf7NyhIDizB: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,'',44,'',YSTbrKgPf7NyhIDizB,vwIN38HprDqTW5Sh61exF7EnA)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<video src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('youtube_url.*?(http.*?)&',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	YsDryBSXquzdEUta8kxjfO = []
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0].replace('\/','/')
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def ppwOVfWkqTKEsUnghz():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	items = QPuHKNAT4jmCRg.findall('source src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	url = NdVvO42riJpCWElX(items[0])
	zT3xJQIVDmCgapBljs(url,mm5vCBc4DOz2Fj,'live')
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	A9skbYtDioxf4IHT7XyO3Zu5pd = False
	if search=='':
		search = wod1HJ0fnvcTNAX2WIiMu9P()
		A9skbYtDioxf4IHT7XyO3Zu5pd = True
	if search=='': return
	if not A9skbYtDioxf4IHT7XyO3Zu5pd: SPFl6UGK4mrBua('?search='+search,'1')
	else: mAJEMXa3lHojhkd('?search='+search,'1')
	return
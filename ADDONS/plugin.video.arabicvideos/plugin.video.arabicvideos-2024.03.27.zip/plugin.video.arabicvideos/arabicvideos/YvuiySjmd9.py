# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'FASELHD2'
headers = {'User-Agent':''}
JE7QrkmhletLwA0OZXu = '_FH2_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['wwe']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==590: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==591: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==592: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==593: RRMWBwU6pG = o9LaYpVR1wKx3IGuHS(url,text)
	elif mode==599: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	ka6I93CnvublQMtjr = GqcEfFR8XQPgBMLr
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',ka6I93CnvublQMtjr,'','','','','FASELHD2-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع',ka6I93CnvublQMtjr,599,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'المميزة',ka6I93CnvublQMtjr,591,'','','featured1')
	items = QPuHKNAT4jmCRg.findall('<strong>(.*?)</strong>.*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for title,VV7yf2htDCBU6EeSX8TJQM in items:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,591,'','','details1')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-menu"(.*?)header-social',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		oCfSOBpu97IY5zadW6gGEMVmwU = QPuHKNAT4jmCRg.findall('<li (.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for zik0WubZQEGj9Ym35NqwF in oCfSOBpu97IY5zadW6gGEMVmwU:
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',zik0WubZQEGj9Ym35NqwF,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+VV7yf2htDCBU6EeSX8TJQM
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,591,'','','details2')
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FASELHD2-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	II2qAWwlR9xe = 0
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"archive-slider(.*?)<h4>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kk73xHNzri1P2wgULMv4sDtoTnybO: y8qSvx0Z9MY = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
	else: y8qSvx0Z9MY = ''
	if type=='featured1':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"slider-carousel"(.*?)</container>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		e7pdI0Ez38ROVy,lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO = zip(*items)
		items = zip(Y4xiULzGTKjb8mulO,e7pdI0Ez38ROVy,lGKfCUP9XRTaBwQ6pq7n0)
	elif type=='featured2':
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',y8qSvx0Z9MY,QPuHKNAT4jmCRg.DOTALL)
	elif type=='filters':
		TTCRYZroizb = [Ht6Gg8lbciAd9FaUQVs.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in y8qSvx0Z9MY:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<h4>(.*?)</h4>(.*?)</container>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مميزة',url,591,'','','featured2')
		title = TTCRYZroizb[0][0]
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,591,'','','details3')
		return
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<h4>(.*?)</h4>(.*?)</container>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		title,wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	gltHFKTroJfpLe = []
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if any(pp8iHB3W9Cs in title.lower() for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU): continue
		title = title.strip(' ')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) (الحلقة|حلقة).\d+',title,QPuHKNAT4jmCRg.DOTALL)
		if '/movseries/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,591,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and type=='':
			title = '_MOD_'+CiZxgXTGW9pv[0][0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,593,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,592,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,593,G2WR0Oacvdq8ZQTjKboDU)
	if type=='filters':
		VpolhzO6Kj = QPuHKNAT4jmCRg.findall('"more_button_page":(.*?),',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if VpolhzO6Kj:
			count = VpolhzO6Kj[0]
			VV7yf2htDCBU6EeSX8TJQM = url+'/offset/'+count
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة أخرى',VV7yf2htDCBU6EeSX8TJQM,591,'','','filters')
	elif 'details' in type:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = 'صفحة '+UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,591,'','','details4')
	return
def o9LaYpVR1wKx3IGuHS(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	Q1WJvEwGdh2mPfct9SKa = False
	if not type:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<seasons(.*?)</seasons>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if len(items)>1:
				ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
				Q1WJvEwGdh2mPfct9SKa = True
				for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
					title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,593,G2WR0Oacvdq8ZQTjKboDU,'','episodes')
	if type=='episodes' or not Q1WJvEwGdh2mPfct9SKa:
		KKcFOCmYRENepQnxi = QPuHKNAT4jmCRg.findall('<bkز*?image:url\((.*?)\)"></bk>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if KKcFOCmYRENepQnxi: G2WR0Oacvdq8ZQTjKboDU = KKcFOCmYRENepQnxi[0]
		else: G2WR0Oacvdq8ZQTjKboDU = ''
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<all-episodes(.*?)</all-episodes>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = title.strip(' ')
				title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,592,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	YsDryBSXquzdEUta8kxjfO,TrAEpY6wszL,G3EtpuZ7ivHB9TxCYalcwDzSeoLM = [],[],[]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(oXSZ6AEbPukBvwKmyarstdWR5qz0,'GET',url,'','','','','FASELHD2-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	E6eiGCWHx5sN3LpDZbwc = QPuHKNAT4jmCRg.findall('العمر :.*?<strong">(.*?)</strong>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if E6eiGCWHx5sN3LpDZbwc and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,E6eiGCWHx5sN3LpDZbwc): return
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('<iframe src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named=__embed')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<slice-title(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('data-url="(.*?)".*?</i>(.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name in items:
			name = name.strip(' ')
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__watch')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('<downloads(.*?)</downloads>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</div>(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name in items:
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__download')
	for fuCINda6HpvU1ljAJ3Sm5twyPZ8 in YsDryBSXquzdEUta8kxjfO:
		VV7yf2htDCBU6EeSX8TJQM,name = fuCINda6HpvU1ljAJ3Sm5twyPZ8.split('?named')
		if VV7yf2htDCBU6EeSX8TJQM not in TrAEpY6wszL:
			TrAEpY6wszL.append(VV7yf2htDCBU6EeSX8TJQM)
			G3EtpuZ7ivHB9TxCYalcwDzSeoLM.append(fuCINda6HpvU1ljAJ3Sm5twyPZ8)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(G3EtpuZ7ivHB9TxCYalcwDzSeoLM,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	ka6I93CnvublQMtjr = GqcEfFR8XQPgBMLr
	url = ka6I93CnvublQMtjr+'/?s='+search
	SPFl6UGK4mrBua(url,'details5')
	return
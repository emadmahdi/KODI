# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'CIMAABDO'
JE7QrkmhletLwA0OZXu = '_ABD_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['الرئيسية']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==550: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==551: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==552: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==553: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==559: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr+'/home','','','','','CIMAABDO-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(GqcEfFR8XQPgBMLr,'url')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',559,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اخترنا لك',ka6I93CnvublQMtjr+'/home',551,'','','featured')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('main-content(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('data-name="(.*?)".*?</i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for oN6FKz2SkGiLnJ3tx4,title in items:
		VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/ajax/getItem?item='+oN6FKz2SkGiLnJ3tx4+'&Ajax=1'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,551)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"nav-main"(.*?)</nav>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if VV7yf2htDCBU6EeSX8TJQM=='#': continue
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,551)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if VV7yf2htDCBU6EeSX8TJQM=='#': continue
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,551)
	return
def SPFl6UGK4mrBua(url,oN6FKz2SkGiLnJ3tx4=''):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2 = Yy43BzxwoGjUnQ6NH1VOpd0RPMgu(url)
		Eudgv5cTUHF2AzKpkx = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'POST',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,BF8XfchlgKmOE0ru2,Eudgv5cTUHF2AzKpkx,'','','CIMAABDO-TITLES-1st')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		TTCRYZroizb = [Ht6Gg8lbciAd9FaUQVs]
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMAABDO-TITLES-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		if oN6FKz2SkGiLnJ3tx4=='featured':
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('"container"(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		elif '"section-post mb-10"' in Ht6Gg8lbciAd9FaUQVs:
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('"section-post mb-10"(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		else:
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('<article(.*?)"pagination"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	if not items:
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if not items: items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM).strip('/')
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if 'سلاسل' not in url and any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in OWBqwsUjLbiGrKhlD):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,552,G2WR0Oacvdq8ZQTjKboDU)
		elif CiZxgXTGW9pv and 'الحلقة' in title:
			title = '_MOD_' + CiZxgXTGW9pv[0]
			if title not in gltHFKTroJfpLe:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,553,G2WR0Oacvdq8ZQTjKboDU)
				gltHFKTroJfpLe.append(title)
		elif '/movies/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,551,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,553,G2WR0Oacvdq8ZQTjKboDU)
	if oN6FKz2SkGiLnJ3tx4=='':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('"pagination"(.*?)<footer',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				if VV7yf2htDCBU6EeSX8TJQM=="": continue
				if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'هناك المزيد',url,551)
	return
def opLlxOB2dUVZ5JF4j(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','CIMAABDO-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"getSeasonsBySeries(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"list-episodes"(.*?)"container"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO and '/series/' not in url:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,553,G2WR0Oacvdq8ZQTjKboDU)
	elif kk73xHNzri1P2wgULMv4sDtoTnybO:
		G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"image" src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
		wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,552,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace('/movies/','/watch_movies/')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao.replace('/episodes/','/watch_episodes/')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','CIMAABDO-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'url')
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"servers"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		ppKgjR9ki431DYoZswP0nFJOIuX = QPuHKNAT4jmCRg.findall('postID = "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		ppKgjR9ki431DYoZswP0nFJOIuX = ppKgjR9ki431DYoZswP0nFJOIuX[0]
		items = QPuHKNAT4jmCRg.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for BHgLX9GZTb2jJrWiNKE,title in items:
				title = title.replace('\n','').strip(' ')
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/ajax/getPlayer?server='+BHgLX9GZTb2jJrWiNKE+'&postID='+ppKgjR9ki431DYoZswP0nFJOIuX+'&Ajax=1'
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
		else:
			items = QPuHKNAT4jmCRg.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			for BHgLX9GZTb2jJrWiNKE,AAwqRbx7l5c4JfCMavyW8uIF,title in items:
				title = title.replace('\n','').strip(' ')
				VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/ajax/getPlayerByName?server='+BHgLX9GZTb2jJrWiNKE+'&multipleServers='+AAwqRbx7l5c4JfCMavyW8uIF+'&postID='+ppKgjR9ki431DYoZswP0nFJOIuX+'&Ajax=1'
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
				LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"downs"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,name in items:
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__download'
			if 'http' not in VV7yf2htDCBU6EeSX8TJQM: VV7yf2htDCBU6EeSX8TJQM = 'http:'+VV7yf2htDCBU6EeSX8TJQM
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','-')
	url = GqcEfFR8XQPgBMLr+'/search/'+search+'.html'
	SPFl6UGK4mrBua(url)
	return
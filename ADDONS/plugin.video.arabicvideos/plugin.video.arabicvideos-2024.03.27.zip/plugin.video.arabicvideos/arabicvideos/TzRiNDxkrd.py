# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
JE7QrkmhletLwA0OZXu = '_SFW_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==210: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==211: RRMWBwU6pG = SPFl6UGK4mrBua(url)
	elif mode==212: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==213: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==214: RRMWBwU6pG = JDKGvHBjpR21m3iPItqoh7V(url)
	elif mode==215: RRMWBwU6pG = skx3e86fjp(url)
	elif mode==218: RRMWBwU6pG = TU6NzuDZSVAEb0fclY7LC1kFgqGtM2()
	elif mode==219: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def TU6NzuDZSVAEb0fclY7LC1kFgqGtM2():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = GqcEfFR8XQPgBMLr+'/getpostsPin?type=one&data=pin&limit=25'
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المميزة',url,211)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','SERIES4WATCH-MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('FiltersButtons(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('data-get="(.*?)".*?</i>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		url = GqcEfFR8XQPgBMLr+'/getposts?type=one&data='+VV7yf2htDCBU6EeSX8TJQM
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,url,211)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('navigation-menu(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(http.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	EhRQ8zB1fdkj5vN6HlmqD7SOU = ['مسلسلات انمي','الرئيسية']
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = title.strip(' ')
		if not any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in EhRQ8zB1fdkj5vN6HlmqD7SOU):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,211)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('MediaGrid"(.*?)class="pagination"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb: wltPGJcYo12Ed = TTCRYZroizb[0]
		else: return
	items = QPuHKNAT4jmCRg.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	WWfUzKtSjs = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
		if '/series/' in VV7yf2htDCBU6EeSX8TJQM: continue
		VV7yf2htDCBU6EeSX8TJQM = NdVvO42riJpCWElX(VV7yf2htDCBU6EeSX8TJQM).strip('/')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		title = title.strip(' ')
		if '/film/' in VV7yf2htDCBU6EeSX8TJQM or any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in WWfUzKtSjs):
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,212,G2WR0Oacvdq8ZQTjKboDU)
		elif '/episode/' in VV7yf2htDCBU6EeSX8TJQM and 'الحلقة' in title:
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
			if CiZxgXTGW9pv:
				title = '_MOD_' + CiZxgXTGW9pv[0]
				if title not in gltHFKTroJfpLe:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,213,G2WR0Oacvdq8ZQTjKboDU)
					gltHFKTroJfpLe.append(title)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,213,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			VV7yf2htDCBU6EeSX8TJQM = UH1IuvwM9e4cl7if63nNdozJFSj(VV7yf2htDCBU6EeSX8TJQM)
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = title.replace('الصفحة ','')
			if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,211)
	return
def opLlxOB2dUVZ5JF4j(url):
	PAyEqD6U2IgNjYRlzZB5JMs,items,PkbD315XqvpAKT8OoGIhZxetsd6M9c = -1,[],[]
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('ti-list-numbered(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = ''.join(TTCRYZroizb)
		items = QPuHKNAT4jmCRg.findall('href="(.*?)"',N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd,QPuHKNAT4jmCRg.DOTALL)
	items.append(url)
	items = set(items)
	for VV7yf2htDCBU6EeSX8TJQM in items:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.strip('/')
		title = '_MOD_' + VV7yf2htDCBU6EeSX8TJQM.split('/')[-1].replace('-',' ')
		CfeaWGU28lvj4hoYRVwt6sy3p = QPuHKNAT4jmCRg.findall('الحلقة-(\d+)',VV7yf2htDCBU6EeSX8TJQM.split('/')[-1],QPuHKNAT4jmCRg.DOTALL)
		if CfeaWGU28lvj4hoYRVwt6sy3p: CfeaWGU28lvj4hoYRVwt6sy3p = CfeaWGU28lvj4hoYRVwt6sy3p[0]
		else: CfeaWGU28lvj4hoYRVwt6sy3p = '0'
		PkbD315XqvpAKT8OoGIhZxetsd6M9c.append([VV7yf2htDCBU6EeSX8TJQM,title,CfeaWGU28lvj4hoYRVwt6sy3p])
	items = sorted(PkbD315XqvpAKT8OoGIhZxetsd6M9c, reverse=False, key=lambda key: int(key[2]))
	H3gvqdVRrWAzebm98nFIk7Mx2i = str(items).count('/season/')
	PAyEqD6U2IgNjYRlzZB5JMs = str(items).count('/episode/')
	if H3gvqdVRrWAzebm98nFIk7Mx2i>1 and PAyEqD6U2IgNjYRlzZB5JMs>0 and '/season/' not in url:
		for VV7yf2htDCBU6EeSX8TJQM,title,CfeaWGU28lvj4hoYRVwt6sy3p in items:
			if '/season/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,213)
	else:
		for VV7yf2htDCBU6EeSX8TJQM,title,CfeaWGU28lvj4hoYRVwt6sy3p in items:
			if '/season/' not in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,212)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	FtKo2AMUynNdTaYCljkxOe = url.split('/')
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in Ht6Gg8lbciAd9FaUQVs:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace(FtKo2AMUynNdTaYCljkxOe[3],'watch')
		iRSILm7Nv6DZAaztp = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','SERIES4WATCH-PLAY-2nd')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="servers-list(.*?)</div>',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if TTCRYZroizb:
			wltPGJcYo12Ed = TTCRYZroizb[0]
			items = QPuHKNAT4jmCRg.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
			if items:
				id = QPuHKNAT4jmCRg.findall('post_id=(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
				if id:
					p2pr9R1hOVsHIlJnFB6PDKMx = id[0]
					for VV7yf2htDCBU6EeSX8TJQM,title in items:
						VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/?postid='+p2pr9R1hOVsHIlJnFB6PDKMx+'&serverid='+VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
						LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
			else:
				items = QPuHKNAT4jmCRg.findall('data-embedd=".*?(http.*?)("|&quot;)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				for VV7yf2htDCBU6EeSX8TJQM,aaxAKWtMwfPRE4zbqSQCOrBms0 in items:
					LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	if '/download/' in Ht6Gg8lbciAd9FaUQVs:
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.replace(FtKo2AMUynNdTaYCljkxOe[3],'download')
		iRSILm7Nv6DZAaztp = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = QPuHKNAT4jmCRg.findall('postId:"(.*?)"',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
		if id:
			p2pr9R1hOVsHIlJnFB6PDKMx = id[0]
			Eudgv5cTUHF2AzKpkx = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr + '/ajaxCenter?_action=getdownloadlinks&postId='+p2pr9R1hOVsHIlJnFB6PDKMx
			iRSILm7Nv6DZAaztp = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',Eudgv5cTUHF2AzKpkx,'','SERIES4WATCH-PLAY-4th')
			TTCRYZroizb = QPuHKNAT4jmCRg.findall('<h3.*?(\d+)(.*?)</div>',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
			if TTCRYZroizb:
				for P5xioNdCft6AVaWHRIszu,wltPGJcYo12Ed in TTCRYZroizb:
					items = QPuHKNAT4jmCRg.findall('<td>(.*?)<.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
					for name,VV7yf2htDCBU6EeSX8TJQM in items:
						LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+name+'__download'+'____'+P5xioNdCft6AVaWHRIszu)
			else:
				TTCRYZroizb = QPuHKNAT4jmCRg.findall('<h6(.*?)</table>',iRSILm7Nv6DZAaztp,QPuHKNAT4jmCRg.DOTALL)
				if not TTCRYZroizb: TTCRYZroizb = [iRSILm7Nv6DZAaztp]
				for wltPGJcYo12Ed in TTCRYZroizb:
					name = ''
					items = QPuHKNAT4jmCRg.findall('href="(http.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
					for VV7yf2htDCBU6EeSX8TJQM in items:
						BHgLX9GZTb2jJrWiNKE = '&&' + VV7yf2htDCBU6EeSX8TJQM.split('/')[2].lower() + '&&'
						BHgLX9GZTb2jJrWiNKE = BHgLX9GZTb2jJrWiNKE.replace('.com&&','').replace('.co&&','')
						BHgLX9GZTb2jJrWiNKE = BHgLX9GZTb2jJrWiNKE.replace('.net&&','').replace('.org&&','')
						BHgLX9GZTb2jJrWiNKE = BHgLX9GZTb2jJrWiNKE.replace('.live&&','').replace('.online&&','')
						BHgLX9GZTb2jJrWiNKE = BHgLX9GZTb2jJrWiNKE.replace('&&hd.','').replace('&&www.','')
						BHgLX9GZTb2jJrWiNKE = BHgLX9GZTb2jJrWiNKE.replace('&&','')
						VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM + '?named=' + name + BHgLX9GZTb2jJrWiNKE + '__download'
						LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr + '/search?s='+search
	SPFl6UGK4mrBua(url)
	return
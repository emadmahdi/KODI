# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
headers = { 'User-Agent' : '' }
mm5vCBc4DOz2Fj = 'AKOAM'
JE7QrkmhletLwA0OZXu = '_AKO_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
aOCfdILg6vcteNZRAH = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==70: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==71: RRMWBwU6pG = nnQqLWAIUd3MxC(url)
	elif mode==72: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==73: RRMWBwU6pG = N59bGVPmH0ZhWXYR(url)
	elif mode==74: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==79: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'سلسلة افلام','',79,'','','سلسلة افلام')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'سلاسل منوعة','',79,'','','سلسلة')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EhRQ8zB1fdkj5vN6HlmqD7SOU = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,GqcEfFR8XQPgBMLr,'',headers,'','AKOAM-MENU-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="partions"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			if title not in EhRQ8zB1fdkj5vN6HlmqD7SOU:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,71)
	return Ht6Gg8lbciAd9FaUQVs
def nnQqLWAIUd3MxC(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,'','AKOAM-CATEGORIES-1st')
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('sect_parts(.*?)</div>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = title.strip(' ')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,72)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'جميع الفروع',url,72)
	else: SPFl6UGK4mrBua(url,'')
	return
def SPFl6UGK4mrBua(url,type):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('section_title featured_title(.*?)subjects-crousel',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='search':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('akoam_result(.*?)<script',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	elif type=='more':
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('section_title more_title(.*?)footer_bottom_services',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	else:
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('navigation(.*?)<script',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not items and TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		if any(pp8iHB3W9Cs in title for pp8iHB3W9Cs in aOCfdILg6vcteNZRAH): fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,73,G2WR0Oacvdq8ZQTjKboDU)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,73,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="pagination"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall("</li><li >.*?href='(.*?)'>(.*?)<",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,72,'','',type)
	return
def iHZMPLN1W47(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = QPuHKNAT4jmCRg.findall('"href","(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = lZqkuhgaBHSVX8NItKG05cdLJe7Ao[1]
	return lZqkuhgaBHSVX8NItKG05cdLJe7Ao
def N59bGVPmH0ZhWXYR(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'',headers,True,'AKOAM-SECTIONS-1st')
	ggqxjpiEKG5 = QPuHKNAT4jmCRg.findall('"(https*://akwam.net/\w+.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	lq2cs9k6SUtA5bKQgIXiJHEja = QPuHKNAT4jmCRg.findall('"(https*://underurl.com/\w+.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if ggqxjpiEKG5 or lq2cs9k6SUtA5bKQgIXiJHEja:
		if ggqxjpiEKG5: lc154VhT9DCqMk8 = ggqxjpiEKG5[0]
		elif lq2cs9k6SUtA5bKQgIXiJHEja: lc154VhT9DCqMk8 = iHZMPLN1W47(lq2cs9k6SUtA5bKQgIXiJHEja[0])
		lc154VhT9DCqMk8 = NdVvO42riJpCWElX(lc154VhT9DCqMk8)
		import ETaRVFoBXD
		if '/series/' in lc154VhT9DCqMk8 or '/shows/' in lc154VhT9DCqMk8: ETaRVFoBXD.opLlxOB2dUVZ5JF4j(lc154VhT9DCqMk8)
		else: ETaRVFoBXD.unQmcpAEF2DaNX87fTgMW(lc154VhT9DCqMk8)
		return
	KQMJtrow90bCy = QPuHKNAT4jmCRg.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if KQMJtrow90bCy and twUoB7cHNRhq(mm5vCBc4DOz2Fj,url,KQMJtrow90bCy): return
	items = QPuHKNAT4jmCRg.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,73)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb:
		uFCykYQW68S('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,G2WR0Oacvdq8ZQTjKboDU,wltPGJcYo12Ed = TTCRYZroizb[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in wltPGJcYo12Ed:
		items = QPuHKNAT4jmCRg.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	else:
		PPIQgSu6feNO7aYh2dTCbcnsi = QPuHKNAT4jmCRg.findall('sub_file_title\'>(.*?) - <i>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		items = []
		for filename in PPIQgSu6feNO7aYh2dTCbcnsi:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	xitERh4TD2jGJPq5Nuv39CAmg,YYOcCBQVXx51lp = [],[]
	size = len(items)
	for title,filename in items:
		UQIq1jCWgFi4MTV0K97bfSe = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: UQIq1jCWgFi4MTV0K97bfSe = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		xitERh4TD2jGJPq5Nuv39CAmg.append(title)
		YYOcCBQVXx51lp.append(count)
		count += 1
	if size>0:
		if any(pp8iHB3W9Cs in name for pp8iHB3W9Cs in aOCfdILg6vcteNZRAH):
			if size==1:
				ShT1xUHjlDotkRuPq7gv = 0
			else:
				ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('اختر الفيديو المناسب:', xitERh4TD2jGJPq5Nuv39CAmg)
				if ShT1xUHjlDotkRuPq7gv == -1: return
			unQmcpAEF2DaNX87fTgMW(url+'?section='+str(1+YYOcCBQVXx51lp[size-ShT1xUHjlDotkRuPq7gv-1]))
		else:
			for PXBFxvuUlLDHGpm58 in reversed(range(size)):
				title = name + ' - ' + xitERh4TD2jGJPq5Nuv39CAmg[PXBFxvuUlLDHGpm58]
				title = title.replace('\n','').strip(' ')
				VV7yf2htDCBU6EeSX8TJQM = url + '?section='+str(size-PXBFxvuUlLDHGpm58)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,74,G2WR0Oacvdq8ZQTjKboDU)
	else:
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+'الرابط ليس فيديو','',9999,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao,CiZxgXTGW9pv = url.split('?section=')
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	shpzQ7VoabOvADrZMBwG = TTCRYZroizb[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	shpzQ7VoabOvADrZMBwG = shpzQ7VoabOvADrZMBwG + 'direct_link_box'
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = QPuHKNAT4jmCRg.findall('epsoide_box(.*?)direct_link_box',shpzQ7VoabOvADrZMBwG,QPuHKNAT4jmCRg.DOTALL)
	CiZxgXTGW9pv = len(N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd)-int(CiZxgXTGW9pv)
	wltPGJcYo12Ed = N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd[CiZxgXTGW9pv]
	YsDryBSXquzdEUta8kxjfO = []
	zik5evMqXs = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = QPuHKNAT4jmCRg.findall("class='download_btn.*?href='(.*?)'",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM in items:
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named=________akoam')
	items = QPuHKNAT4jmCRg.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for gg34OWf6Ep9tZyqilkrMwd7XxDac2,VV7yf2htDCBU6EeSX8TJQM in items:
		gg34OWf6Ep9tZyqilkrMwd7XxDac2 = gg34OWf6Ep9tZyqilkrMwd7XxDac2.split('/')[-1]
		gg34OWf6Ep9tZyqilkrMwd7XxDac2 = gg34OWf6Ep9tZyqilkrMwd7XxDac2.split('.')[0]
		if gg34OWf6Ep9tZyqilkrMwd7XxDac2 in zik5evMqXs:
			YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+zik5evMqXs[gg34OWf6Ep9tZyqilkrMwd7XxDac2]+'________akoam')
		else: YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM+'?named='+gg34OWf6Ep9tZyqilkrMwd7XxDac2+'________akoam')
	if not YsDryBSXquzdEUta8kxjfO:
		message = QPuHKNAT4jmCRg.findall('sub-no-file.*?\n(.*?)\n',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if message: qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من الموقع الاصلي',message[0])
	else:
		import bcQwT9tl1C
		bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','%20')
	url = GqcEfFR8XQPgBMLr + '/search/'+Unr6jRmMIv80lSGbkBCehpaWAdV
	RRMWBwU6pG = SPFl6UGK4mrBua(url,'search')
	return
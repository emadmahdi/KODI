# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
import bs4 as ir2q5OPksZf7IwKtlGxvjYdN3c1
mm5vCBc4DOz2Fj = 'ELCINEMA'
JE7QrkmhletLwA0OZXu = '_ELC_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
headers = {'Referer':GqcEfFR8XQPgBMLr}
EhRQ8zB1fdkj5vN6HlmqD7SOU = []
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==510: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==511: RRMWBwU6pG = tE47gckzAsF(url)
	elif mode==512: RRMWBwU6pG = o06fsXjuvkrOn1B(url)
	elif mode==513: RRMWBwU6pG = Fh8QYmaJUybz(url)
	elif mode==514: RRMWBwU6pG = CoeEfV8aNyW(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: RRMWBwU6pG = CoeEfV8aNyW(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: RRMWBwU6pG = TfiUwSMNEyCd1pg0VKB(text)
	elif mode==517: RRMWBwU6pG = Q5iLGHyCuj62VvR1NA09tqcOPap4(url)
	elif mode==518: RRMWBwU6pG = O7OaIXxBRWspDqTrV4HGLoUK96iCNw(url)
	elif mode==519: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	elif mode==520: RRMWBwU6pG = ZHLNkPbv0RaCitqcn4gOV5BGz7(url)
	elif mode==521: RRMWBwU6pG = t5SipdfZNF(url)
	elif mode==522: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==523: RRMWBwU6pG = DNalu7t4GjT1BMVw8ezJdXI0Scm(text)
	elif mode==524: RRMWBwU6pG = kIDGJp1YiLChf7wSyK()
	elif mode==525: RRMWBwU6pG = Ii0lKZGq6F()
	elif mode==526: RRMWBwU6pG = tAd9hvpDMaEmC2KNTsx1g()
	elif mode==527: RRMWBwU6pG = JTlm5QxSzCuDd1cMvYto8aFE3eLWky()
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث بموسوعة السينما','',519)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'موسوعة الأعمال','',525)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'موسوعة الأشخاص','',526)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'موسوعة المصنفات','',527)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'موسوعة المنوعات','',524)
	return
def kIDGJp1YiLChf7wSyK():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' فيديوهات - خاصة',GqcEfFR8XQPgBMLr+'/video',520)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فيديوهات - أحدث',GqcEfFR8XQPgBMLr+'/video/latest',521)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فيديوهات - أقدم',GqcEfFR8XQPgBMLr+'/video/oldest',521)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فيديوهات - أكثر مشاهدة',GqcEfFR8XQPgBMLr+'/video/views',521)
	return
def Ii0lKZGq6F():
	XBRI0rOCHZLpl8zobKeh9jEyYNdm2 = GqcEfFR8XQPgBMLr+'/lineup?utf8=%E2%9C%93'
	M0od4eVFJsB7g2WjOL1Gb3qtKm9 = XBRI0rOCHZLpl8zobKeh9jEyYNdm2+'&type=2&category=1&foreign=false&tag='
	uuLIyo6AFRVawcqtbJ2XgmDHNB0nPC = XBRI0rOCHZLpl8zobKeh9jEyYNdm2+'&type=2&category=3&foreign=false&tag='
	VK78iovIzA2SZjfFypkQBlGTP6a = XBRI0rOCHZLpl8zobKeh9jEyYNdm2+'&type=2&category=1&foreign=true&tag='
	FKO3qeWNxn = XBRI0rOCHZLpl8zobKeh9jEyYNdm2+'&type=2&category=3&foreign=true&tag='
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات أفلام عربي',M0od4eVFJsB7g2WjOL1Gb3qtKm9,511)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات مسلسلات عربي',uuLIyo6AFRVawcqtbJ2XgmDHNB0nPC,511)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات أفلام اجنبي',VK78iovIzA2SZjfFypkQBlGTP6a,511)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات مسلسلات اجنبي',FKO3qeWNxn,511)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس أعمال أبجدي',GqcEfFR8XQPgBMLr+'/index/work/alphabet',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس  بلد الإنتاج',GqcEfFR8XQPgBMLr+'/index/work/country',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس اللغة',GqcEfFR8XQPgBMLr+'/index/work/language',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس مصنفات العمل',GqcEfFR8XQPgBMLr+'/index/work/genre',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس سنة الإصدار',GqcEfFR8XQPgBMLr+'/index/work/release_year',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مواسم - فلتر محدد',GqcEfFR8XQPgBMLr+'/seasonals',515)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مواسم - فلتر كامل',GqcEfFR8XQPgBMLr+'/seasonals',514)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات - فلتر محدد',GqcEfFR8XQPgBMLr+'/lineup',515)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات - فلتر كامل',GqcEfFR8XQPgBMLr+'/lineup',514)
	return
def JTlm5QxSzCuDd1cMvYto8aFE3eLWky():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',GqcEfFR8XQPgBMLr+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	wltPGJcYo12Ed = AACDLPsfGY9u.find('select',attrs={'name':'tag'})
	vwIN38HprDqTW5Sh61exF7EnA = wltPGJcYo12Ed.find_all('option')
	for wMq2UBSjsfgchHzprXWFOTdn5 in vwIN38HprDqTW5Sh61exF7EnA:
		pp8iHB3W9Cs = wMq2UBSjsfgchHzprXWFOTdn5.get('value')
		if not pp8iHB3W9Cs: continue
		title = wMq2UBSjsfgchHzprXWFOTdn5.text
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			title = title.encode('utf8')
			pp8iHB3W9Cs = pp8iHB3W9Cs.encode('utf8')
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+pp8iHB3W9Cs
		title = title.replace('قائمة ','')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,511)
	return
def tAd9hvpDMaEmC2KNTsx1g():
	XBRI0rOCHZLpl8zobKeh9jEyYNdm2 = GqcEfFR8XQPgBMLr+'/lineup?utf8=%E2%9C%93'
	vcT6MZNBFPVubLqJktOyjr3CfGpH9 = XBRI0rOCHZLpl8zobKeh9jEyYNdm2+'&type=1&category=&foreign=&tag='
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات أشخاص',vcT6MZNBFPVubLqJktOyjr3CfGpH9,511)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس أشخاص أبجدي',GqcEfFR8XQPgBMLr+'/index/person/alphabet',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس موطن',GqcEfFR8XQPgBMLr+'/index/person/nationality',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس  تاريخ الميلاد',GqcEfFR8XQPgBMLr+'/index/person/birth_year',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'فهرس  تاريخ الوفاة',GqcEfFR8XQPgBMLr+'/index/person/death_year',517)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات - فلتر محدد',GqcEfFR8XQPgBMLr+'/lineup',515)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مصنفات - فلتر كامل',GqcEfFR8XQPgBMLr+'/lineup',514)
	return
def tE47gckzAsF(url):
	if '/seasonals' in url: A1pJYqSia7V4wKMnuvLe30QbrkGj = 0
	elif '/lineup' in url: A1pJYqSia7V4wKMnuvLe30QbrkGj = 1
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = AACDLPsfGY9u.find_all(class_='jumbo-theater clearfix')
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		title = wltPGJcYo12Ed.find_all('a')[A1pJYqSia7V4wKMnuvLe30QbrkGj].text
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+wltPGJcYo12Ed.find_all('a')[A1pJYqSia7V4wKMnuvLe30QbrkGj].get('href')
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			title = title.encode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
		if not N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
			o06fsXjuvkrOn1B(VV7yf2htDCBU6EeSX8TJQM)
			return
		else:
			title = title.replace('قائمة ','')
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,512)
	y19z2fNAKaLtDvpguQI6sBPX7R(AACDLPsfGY9u,511)
	return
def y19z2fNAKaLtDvpguQI6sBPX7R(AACDLPsfGY9u,mode):
	wltPGJcYo12Ed = AACDLPsfGY9u.find(class_='pagination')
	if wltPGJcYo12Ed:
		ghwC2Uz74LTtRbpD8asXVn1GO = wltPGJcYo12Ed.find_all('a')
		Yxf0ZHJzOiDwjACu3m = wltPGJcYo12Ed.find_all('li')
		L34XF52SAOpngbRCret = list(zip(ghwC2Uz74LTtRbpD8asXVn1GO,Yxf0ZHJzOiDwjACu3m))
		kdWCpE9TjNh = -1
		KOtnoe7NXMaF3jD8UfuLd = len(L34XF52SAOpngbRCret)
		for MtNlbVreA4UswLKIiBa9fQ,yI8YrDmkcp3futNlXQEj in L34XF52SAOpngbRCret:
			kdWCpE9TjNh += 1
			yI8YrDmkcp3futNlXQEj = yI8YrDmkcp3futNlXQEj['class']
			if 'unavailable' in yI8YrDmkcp3futNlXQEj or 'current' in yI8YrDmkcp3futNlXQEj: continue
			Vuk3760YmGdQaZ92MfwcNKE = MtNlbVreA4UswLKIiBa9fQ.text
			FsnXTNzcG53RUk = GqcEfFR8XQPgBMLr+MtNlbVreA4UswLKIiBa9fQ.get('href')
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
				Vuk3760YmGdQaZ92MfwcNKE = Vuk3760YmGdQaZ92MfwcNKE.encode('utf8')
				FsnXTNzcG53RUk = FsnXTNzcG53RUk.encode('utf8')
			if   kdWCpE9TjNh==0: Vuk3760YmGdQaZ92MfwcNKE = 'أولى'
			elif kdWCpE9TjNh==1: Vuk3760YmGdQaZ92MfwcNKE = 'سابقة'
			elif kdWCpE9TjNh==KOtnoe7NXMaF3jD8UfuLd-2: Vuk3760YmGdQaZ92MfwcNKE = 'لاحقة'
			elif kdWCpE9TjNh==KOtnoe7NXMaF3jD8UfuLd-1: Vuk3760YmGdQaZ92MfwcNKE = 'أخيرة'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+Vuk3760YmGdQaZ92MfwcNKE,FsnXTNzcG53RUk,mode)
	return
def o06fsXjuvkrOn1B(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = AACDLPsfGY9u.find_all(class_='row')
	items,IP2cvAkDs87K9RjquUf60Xxy4e1d = [],True
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		if not wltPGJcYo12Ed.find(class_='thumbnail-wrapper'): continue
		if IP2cvAkDs87K9RjquUf60Xxy4e1d: IP2cvAkDs87K9RjquUf60Xxy4e1d = False ; continue
		yr6v5aEumXYUOpZl = []
		E5ashBpgqTjAMH2w3IWz4i = wltPGJcYo12Ed.find_all(class_=['censorship red','censorship purple'])
		for XCAK64a7QdshZ8w1oYStmR in E5ashBpgqTjAMH2w3IWz4i:
			yN6vzYlOoCD5KMB02qjfLFn = XCAK64a7QdshZ8w1oYStmR.find_all('li')[1].text
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
				yN6vzYlOoCD5KMB02qjfLFn = yN6vzYlOoCD5KMB02qjfLFn.encode('utf8')
			yr6v5aEumXYUOpZl.append(yN6vzYlOoCD5KMB02qjfLFn)
		if not twUoB7cHNRhq(mm5vCBc4DOz2Fj,'',yr6v5aEumXYUOpZl,False):
			KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('data-src')
			title = wltPGJcYo12Ed.find('h3')
			name = title.find('a').text
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+title.find('a').get('href')
			sLJwTVXbyH1Yg = wltPGJcYo12Ed.find(class_='no-margin')
			Fx6X9bEcMZjpz3W1O2wP5JiU = wltPGJcYo12Ed.find(class_='legend')
			if sLJwTVXbyH1Yg: sLJwTVXbyH1Yg = sLJwTVXbyH1Yg.text
			if Fx6X9bEcMZjpz3W1O2wP5JiU: Fx6X9bEcMZjpz3W1O2wP5JiU = Fx6X9bEcMZjpz3W1O2wP5JiU.text
			if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
				KKcFOCmYRENepQnxi = KKcFOCmYRENepQnxi.encode('utf8')
				name = name.encode('utf8')
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
				if sLJwTVXbyH1Yg: sLJwTVXbyH1Yg = sLJwTVXbyH1Yg.encode('utf8')
			RkfstxEyua67K2 = {}
			if Fx6X9bEcMZjpz3W1O2wP5JiU: RkfstxEyua67K2['stars'] = Fx6X9bEcMZjpz3W1O2wP5JiU
			if sLJwTVXbyH1Yg:
				sLJwTVXbyH1Yg = sLJwTVXbyH1Yg.replace('\n',' .. ')
				RkfstxEyua67K2['plot'] = sLJwTVXbyH1Yg.replace('...اقرأ المزيد','')
			if '/work/' in VV7yf2htDCBU6EeSX8TJQM:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,516,KKcFOCmYRENepQnxi,'',name,'',RkfstxEyua67K2)
			elif '/person/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,513,KKcFOCmYRENepQnxi,'',name,'',RkfstxEyua67K2)
	y19z2fNAKaLtDvpguQI6sBPX7R(AACDLPsfGY9u,512)
	return
def Fh8QYmaJUybz(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = AACDLPsfGY9u.find_all('li')
	xVQTW4gOUKEJtMzLXiChwk1BlRD2N,items = [],[]
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		if not wltPGJcYo12Ed.find(class_='thumbnail-wrapper'): continue
		if not wltPGJcYo12Ed.find(class_=['unstyled','unstyled text-center']): continue
		if wltPGJcYo12Ed.find(class_='hide'): continue
		title = wltPGJcYo12Ed.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in xVQTW4gOUKEJtMzLXiChwk1BlRD2N: continue
		xVQTW4gOUKEJtMzLXiChwk1BlRD2N.append(name)
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+title.find('a').get('href')
		if '/search/work/' in url: KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('src')
		elif '/search/person/' in url: KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('data-src')
		elif '/search/video/' in url: KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('data-src')
		else: KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('src')
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			name = name.encode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
			KKcFOCmYRENepQnxi = KKcFOCmYRENepQnxi.encode('utf8')
		name = name.strip(' ')
		items.append((name,VV7yf2htDCBU6EeSX8TJQM,KKcFOCmYRENepQnxi))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,VV7yf2htDCBU6EeSX8TJQM,KKcFOCmYRENepQnxi in items:
		if '/search/video/' in url: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,522,KKcFOCmYRENepQnxi)
		elif '/search/person/' in url: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,513,KKcFOCmYRENepQnxi,'',name)
		else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,516,KKcFOCmYRENepQnxi,'',name)
	return
def TfiUwSMNEyCd1pg0VKB(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	ssyiwOb81lUxd = text.count(' ')+1
	if ssyiwOb81lUxd==1:
		DNalu7t4GjT1BMVw8ezJdXI0Scm(text)
		return
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link',JE7QrkmhletLwA0OZXu+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	It0jfumlLBU7NpnDc1C8ay5zMJRE = text.split(' ')
	QAVGt97z3PbyoHUXs6a4M = pow(2,ssyiwOb81lUxd)
	wguh3s9ESVdq = []
	def dNygnaVe9iT1(URFCA28wLdY1x6OTl,qXcWdHt5VEZ1xioT6rUQ9NGPwFIk):
		if URFCA28wLdY1x6OTl=='1': return qXcWdHt5VEZ1xioT6rUQ9NGPwFIk
		return ''
	for kdWCpE9TjNh in range(QAVGt97z3PbyoHUXs6a4M,0,-1):
		uewaDyjWBpiKLc7tgQzhZm = list(ssyiwOb81lUxd*'0'+bin(kdWCpE9TjNh)[2:])[-ssyiwOb81lUxd:]
		uewaDyjWBpiKLc7tgQzhZm = reversed(uewaDyjWBpiKLc7tgQzhZm)
		t78SOQHR9JTBNAa = map(dNygnaVe9iT1,uewaDyjWBpiKLc7tgQzhZm,It0jfumlLBU7NpnDc1C8ay5zMJRE)
		title = ' '.join(filter(None,t78SOQHR9JTBNAa))
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: nUbpaNT0vhcj7ZsEz = title.decode('utf8')
		else: nUbpaNT0vhcj7ZsEz = title
		if len(nUbpaNT0vhcj7ZsEz)>2 and title not in wguh3s9ESVdq:
			wguh3s9ESVdq.append(title)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,'',523,'','',title)
	return
def DNalu7t4GjT1BMVw8ezJdXI0Scm(tip0WLfYmxEnD8lQIFTNBS):
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
		tip0WLfYmxEnD8lQIFTNBS = tip0WLfYmxEnD8lQIFTNBS.decode('utf8')
		import arabic_reshaper as p6gK2EMsRDbjVU3uk
		tip0WLfYmxEnD8lQIFTNBS = p6gK2EMsRDbjVU3uk.ArabicReshaper().reshape(tip0WLfYmxEnD8lQIFTNBS)
		tip0WLfYmxEnD8lQIFTNBS = GGgun1VSbfq8edk62vLxB.get_display(tip0WLfYmxEnD8lQIFTNBS)
	import vcs7yZGKQM
	tip0WLfYmxEnD8lQIFTNBS = wod1HJ0fnvcTNAX2WIiMu9P(default=tip0WLfYmxEnD8lQIFTNBS)
	vcs7yZGKQM.mt4qhKoi9ynlYXFRszgZ7b3wr(tip0WLfYmxEnD8lQIFTNBS)
	return
def Q5iLGHyCuj62VvR1NA09tqcOPap4(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	wltPGJcYo12Ed = AACDLPsfGY9u.find(class_='list-separator list-title')
	lGKfCUP9XRTaBwQ6pq7n0 = wltPGJcYo12Ed.find_all('a')
	items = []
	for title in lGKfCUP9XRTaBwQ6pq7n0:
		name = title.text
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+title.get('href')
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			name = name.encode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
		if '#' not in VV7yf2htDCBU6EeSX8TJQM: items.append((name,VV7yf2htDCBU6EeSX8TJQM))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for F5o1sgcqZVlS in items:
		name,VV7yf2htDCBU6EeSX8TJQM = F5o1sgcqZVlS
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,518)
	return
def O7OaIXxBRWspDqTrV4HGLoUK96iCNw(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = AACDLPsfGY9u.find(class_='expand').find_all('tr')
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		dpcAmlugfVN8KCHwGbQStzUqvnWB = wltPGJcYo12Ed.find_all('a')
		if not dpcAmlugfVN8KCHwGbQStzUqvnWB: continue
		KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('data-src')
		name = dpcAmlugfVN8KCHwGbQStzUqvnWB[1].text
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+dpcAmlugfVN8KCHwGbQStzUqvnWB[1].get('href')
		Fx6X9bEcMZjpz3W1O2wP5JiU = wltPGJcYo12Ed.find(class_='legend')
		if Fx6X9bEcMZjpz3W1O2wP5JiU: Fx6X9bEcMZjpz3W1O2wP5JiU = Fx6X9bEcMZjpz3W1O2wP5JiU.text
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			name = name.encode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
			KKcFOCmYRENepQnxi = KKcFOCmYRENepQnxi.encode('utf8')
		RkfstxEyua67K2 = {}
		if Fx6X9bEcMZjpz3W1O2wP5JiU: RkfstxEyua67K2['stars'] = Fx6X9bEcMZjpz3W1O2wP5JiU
		if '/work/' in VV7yf2htDCBU6EeSX8TJQM:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,516,KKcFOCmYRENepQnxi,'',name,'',RkfstxEyua67K2)
		elif '/person/' in VV7yf2htDCBU6EeSX8TJQM: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+name,VV7yf2htDCBU6EeSX8TJQM,513,KKcFOCmYRENepQnxi,'',name,'',RkfstxEyua67K2)
	y19z2fNAKaLtDvpguQI6sBPX7R(AACDLPsfGY9u,518)
	return
def ZHLNkPbv0RaCitqcn4gOV5BGz7(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	lGKfCUP9XRTaBwQ6pq7n0 = AACDLPsfGY9u.find_all(class_='section-title inline')
	Y4xiULzGTKjb8mulO = AACDLPsfGY9u.find_all(class_='button green small right')
	items = zip(lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO)
	for title,VV7yf2htDCBU6EeSX8TJQM in items:
		title = title.text
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+VV7yf2htDCBU6EeSX8TJQM.get('href')
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			title = title.encode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,521)
	return
def t5SipdfZNF(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	HxAXNuFm1DU9JMOtoj0k2z73sR = AACDLPsfGY9u.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = HxAXNuFm1DU9JMOtoj0k2z73sR.find_all('li')
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		title = wltPGJcYo12Ed.find(class_='title').text
		VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr+wltPGJcYo12Ed.find('a').get('href')
		KKcFOCmYRENepQnxi = wltPGJcYo12Ed.find('img').get('data-src')
		VVaBpWQDAfx5dO4GSMmstz78eRFYw = wltPGJcYo12Ed.find(class_='duration').text
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			title = title.encode('utf8')
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
			KKcFOCmYRENepQnxi = KKcFOCmYRENepQnxi.encode('utf8')
			VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.encode('utf8')
		VVaBpWQDAfx5dO4GSMmstz78eRFYw = VVaBpWQDAfx5dO4GSMmstz78eRFYw.replace('\n','').strip(' ')
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,522,KKcFOCmYRENepQnxi,VVaBpWQDAfx5dO4GSMmstz78eRFYw)
	y19z2fNAKaLtDvpguQI6sBPX7R(AACDLPsfGY9u,521)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	VV7yf2htDCBU6EeSX8TJQM = AACDLPsfGY9u.find(class_='flex-video').find('iframe').get('src')
	if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM: VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM.encode('utf8')
	zT3xJQIVDmCgapBljs(VV7yf2htDCBU6EeSX8TJQM,mm5vCBc4DOz2Fj,'video')
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','%20')
	url = GqcEfFR8XQPgBMLr+'/search/?q='+search
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not nbdMp8UuhzP3oq4cDWj6eyZVt.succeeded:
		vcT6MZNBFPVubLqJktOyjr3CfGpH9 = GqcEfFR8XQPgBMLr+'/search_entity/?q='+search+'&entity=work'
		FsnXTNzcG53RUk = GqcEfFR8XQPgBMLr+'/search_entity/?q='+search+'&entity=person'
		PSc013zIgQsVDKjv96mr4NneW = GqcEfFR8XQPgBMLr+'/search_entity/?q='+search+'&entity=video'
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن أعمال',vcT6MZNBFPVubLqJktOyjr3CfGpH9,513,'',search)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن أشخاص',FsnXTNzcG53RUk,513,'',search)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث عن فيديوهات',PSc013zIgQsVDKjv96mr4NneW,513,'',search)
		return
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	AACDLPsfGY9u = ir2q5OPksZf7IwKtlGxvjYdN3c1.BeautifulSoup(Ht6Gg8lbciAd9FaUQVs,'html.parser',multi_valued_attributes=None)
	N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd = AACDLPsfGY9u.find_all(class_='section-title left')
	for wltPGJcYo12Ed in N1e9RYqtO5J6KE4AkG7Z3iHfF2oDLd:
		title = wltPGJcYo12Ed.text
		if rx3QcG7naDzKw5m6uJBq4H1AYZkdNM:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: VV7yf2htDCBU6EeSX8TJQM = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: VV7yf2htDCBU6EeSX8TJQM = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: VV7yf2htDCBU6EeSX8TJQM = url.replace('/search/','/search/video/')
		else: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,513)
	return
def CoeEfV8aNyW(url,text):
	global vMgBXHJ4ETR1qjkDAhKsc9SuY,RBkuwxQsqh6CaLzMcGWbftSrI
	if '/seasonals' in url:
		vMgBXHJ4ETR1qjkDAhKsc9SuY = ['seasonal','year','category']
		RBkuwxQsqh6CaLzMcGWbftSrI = ['seasonal','year','category']
	elif '/lineup' in url:
		vMgBXHJ4ETR1qjkDAhKsc9SuY = ['category','foreign','type']
		RBkuwxQsqh6CaLzMcGWbftSrI = ['category','foreign','type']
	UviJploL2R7xqH68eI5MdFm0Dn9h4(url,text)
	return
def PD19Sz64kNmaXxw(url):
	url = url.split('/smartemadfilter?')[0]
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(lu4xpkY5LFOm6t2In,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('form action="/(.*?)</form>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	K0MwVeCGOmJho = QPuHKNAT4jmCRg.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return K0MwVeCGOmJho
def zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed):
	items = QPuHKNAT4jmCRg.findall('<option value="(.*?)">(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	return items
def nGPYq9pSD5(url):
	rrU0IR1Aga6Y = url.split('/smartemadfilter?')[0]
	eek0phlJjL6MWVXsmy7wFPz2oT = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def Ysfrq91cAj(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,url):
	sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,'all_filters')
	lc154VhT9DCqMk8 = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	lc154VhT9DCqMk8 = nGPYq9pSD5(lc154VhT9DCqMk8)
	return lc154VhT9DCqMk8
def UviJploL2R7xqH68eI5MdFm0Dn9h4(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = '',''
	else: A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,Lb7kxwJZBPquygXoO4nTSN3 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if vMgBXHJ4ETR1qjkDAhKsc9SuY[0]+'=' not in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[0]
		for PXBFxvuUlLDHGpm58 in range(len(vMgBXHJ4ETR1qjkDAhKsc9SuY[0:-1])):
			if vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs: jsEpRxQH76 = vMgBXHJ4ETR1qjkDAhKsc9SuY[PXBFxvuUlLDHGpm58+1]
		uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+jsEpRxQH76+'=0'
		ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+jsEpRxQH76+'=0'
		tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX.strip('&')+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV.strip('&')
		sJxYKGW7VODHcn0o4UBZkAtEMe = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+sJxYKGW7VODHcn0o4UBZkAtEMe
	elif type=='ALL_ITEMS_FILTER':
		MMbGXFqNEjRiB = yvulo0RfU7G2NaeK6g9r(A4W5oV8qu3DvLfwOnlcmRXCKzYUTs,'modified_values')
		MMbGXFqNEjRiB = NdVvO42riJpCWElX(MMbGXFqNEjRiB)
		if Lb7kxwJZBPquygXoO4nTSN3!='': Lb7kxwJZBPquygXoO4nTSN3 = yvulo0RfU7G2NaeK6g9r(Lb7kxwJZBPquygXoO4nTSN3,'modified_filters')
		if Lb7kxwJZBPquygXoO4nTSN3=='': lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'/smartemadfilter?'+Lb7kxwJZBPquygXoO4nTSN3
		lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nGPYq9pSD5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'أظهار قائمة الفيديو التي تم اختيارها ',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,511)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+' [[   '+MMbGXFqNEjRiB+'   ]]',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,511)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	K0MwVeCGOmJho = PD19Sz64kNmaXxw(url)
	dict = {}
	for name,qQ3oR7maZGeFByA6uitjrd,wltPGJcYo12Ed in K0MwVeCGOmJho:
		name = name.replace('--','')
		items = zrGAbXDcP2wtHai0sv3g7T(wltPGJcYo12Ed)
		if '=' not in lZqkuhgaBHSVX8NItKG05cdLJe7Ao: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url
		if type=='SPECIFIED_FILTER':
			if qQ3oR7maZGeFByA6uitjrd not in vMgBXHJ4ETR1qjkDAhKsc9SuY: continue
			if jsEpRxQH76!=qQ3oR7maZGeFByA6uitjrd: continue
			elif len(items)<2:
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]:
					url = nGPYq9pSD5(url)
					o06fsXjuvkrOn1B(url)
				else: UviJploL2R7xqH68eI5MdFm0Dn9h4(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'SPECIFIED_FILTER___'+tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
				return
			else:
				lZqkuhgaBHSVX8NItKG05cdLJe7Ao = nGPYq9pSD5(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
				if qQ3oR7maZGeFByA6uitjrd==vMgBXHJ4ETR1qjkDAhKsc9SuY[-1]: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,511)
				else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,515,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		elif type=='ALL_ITEMS_FILTER':
			if qQ3oR7maZGeFByA6uitjrd not in RBkuwxQsqh6CaLzMcGWbftSrI: continue
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'=0'
			tdbgJ5nGrlNBkTy168eP9sH7QCUKaF = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'الجميع: '+name,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,514,'','',tdbgJ5nGrlNBkTy168eP9sH7QCUKaF)
		dict[qQ3oR7maZGeFByA6uitjrd] = {}
		for pp8iHB3W9Cs,wMq2UBSjsfgchHzprXWFOTdn5 in items:
			if wMq2UBSjsfgchHzprXWFOTdn5 in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
			if 'مصنفات أخرى' in wMq2UBSjsfgchHzprXWFOTdn5: continue
			if 'الكل' in wMq2UBSjsfgchHzprXWFOTdn5: continue
			if 'اللغة' in wMq2UBSjsfgchHzprXWFOTdn5: continue
			wMq2UBSjsfgchHzprXWFOTdn5 = wMq2UBSjsfgchHzprXWFOTdn5.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[qQ3oR7maZGeFByA6uitjrd][pp8iHB3W9Cs] = wMq2UBSjsfgchHzprXWFOTdn5
			uuWdClPqIjEX = A4W5oV8qu3DvLfwOnlcmRXCKzYUTs+'&'+qQ3oR7maZGeFByA6uitjrd+'='+wMq2UBSjsfgchHzprXWFOTdn5
			ZIYTefaLBGl7gc14sx25dbFUHQXmWV = Lb7kxwJZBPquygXoO4nTSN3+'&'+qQ3oR7maZGeFByA6uitjrd+'='+pp8iHB3W9Cs
			q0NkUvatj1HcndbF9Yrsw = uuWdClPqIjEX+'___'+ZIYTefaLBGl7gc14sx25dbFUHQXmWV
			if name: title = wMq2UBSjsfgchHzprXWFOTdn5+' :'+name
			else: title = wMq2UBSjsfgchHzprXWFOTdn5
			if type=='ALL_ITEMS_FILTER': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,514,'','',q0NkUvatj1HcndbF9Yrsw)
			elif type=='SPECIFIED_FILTER' and vMgBXHJ4ETR1qjkDAhKsc9SuY[-2]+'=' in A4W5oV8qu3DvLfwOnlcmRXCKzYUTs:
				lc154VhT9DCqMk8 = Ysfrq91cAj(ZIYTefaLBGl7gc14sx25dbFUHQXmWV,url)
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,lc154VhT9DCqMk8,511)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,515,'','',q0NkUvatj1HcndbF9Yrsw)
	return
def yvulo0RfU7G2NaeK6g9r(JWVlUxnpBbjv20w7,mode):
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.replace('=&','=0&')
	JWVlUxnpBbjv20w7 = JWVlUxnpBbjv20w7.strip('&')
	XTiOm8cUEJCh3ryql = {}
	if '=' in JWVlUxnpBbjv20w7:
		items = JWVlUxnpBbjv20w7.split('&')
		for F5o1sgcqZVlS in items:
			AyM2r7eGEp69ul3vH4i0VN,pp8iHB3W9Cs = F5o1sgcqZVlS.split('=')
			XTiOm8cUEJCh3ryql[AyM2r7eGEp69ul3vH4i0VN] = pp8iHB3W9Cs
	VAlPewLIfoQv6dash = ''
	for key in RBkuwxQsqh6CaLzMcGWbftSrI:
		if key in list(XTiOm8cUEJCh3ryql.keys()): pp8iHB3W9Cs = XTiOm8cUEJCh3ryql[key]
		else: pp8iHB3W9Cs = '0'
		if '%' not in pp8iHB3W9Cs: pp8iHB3W9Cs = oF0Yr4V7Ic(pp8iHB3W9Cs)
		if mode=='modified_values' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+' + '+pp8iHB3W9Cs
		elif mode=='modified_filters' and pp8iHB3W9Cs!='0': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
		elif mode=='all_filters': VAlPewLIfoQv6dash = VAlPewLIfoQv6dash+'&'+key+'='+pp8iHB3W9Cs
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip(' + ')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.strip('&')
	VAlPewLIfoQv6dash = VAlPewLIfoQv6dash.replace('=0','=')
	return VAlPewLIfoQv6dash
vMgBXHJ4ETR1qjkDAhKsc9SuY = []
RBkuwxQsqh6CaLzMcGWbftSrI = []
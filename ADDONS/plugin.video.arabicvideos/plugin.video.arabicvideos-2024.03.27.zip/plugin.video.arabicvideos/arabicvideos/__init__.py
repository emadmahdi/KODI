# -*- coding: utf-8 -*-
import sys as GJtcqTv68ZQpwxYFiDg
yyIoQrPWR1B = GJtcqTv68ZQpwxYFiDg.version_info [0] == 2
Duhwt2HMRTeBonVic0lz8bjUJ = 2048
BnAMltLNqzHfjxWkVi9eb3P = 7
def rrgVqwDZPsMjxvR3EylNz9 (tbA2GsXVSDNgm):
	global lzR5Gp9sjoDwb
	BZb90tzYkgeu3pcAo = ord (tbA2GsXVSDNgm [-1])
	fdK96q2bHgSIwE = tbA2GsXVSDNgm [:-1]
	klvdJbzV7PEMciQ61A0t25SGXq8 = BZb90tzYkgeu3pcAo % len (fdK96q2bHgSIwE)
	q5yMKdNsYpzDj8Oo = fdK96q2bHgSIwE [:klvdJbzV7PEMciQ61A0t25SGXq8] + fdK96q2bHgSIwE [klvdJbzV7PEMciQ61A0t25SGXq8:]
	if yyIoQrPWR1B:
		hq2Yj5TvMOKsRFroabWu = unicode () .join ([unichr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	else:
		hq2Yj5TvMOKsRFroabWu = str () .join ([chr (ord (EES5dwWybNu0KmGt3o) - Duhwt2HMRTeBonVic0lz8bjUJ - (PPjFBRNHmtUd0qDZu + BZb90tzYkgeu3pcAo) % BnAMltLNqzHfjxWkVi9eb3P) for PPjFBRNHmtUd0qDZu, EES5dwWybNu0KmGt3o in enumerate (q5yMKdNsYpzDj8Oo)])
	return eval (hq2Yj5TvMOKsRFroabWu)
iRTygNp4Lf36wQKlD2MHUhG7B,KbL94nDHufSF0VcO2Nk3,qNZKwi2M1S4fBzGQYrmPnea=rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9,rrgVqwDZPsMjxvR3EylNz9
xxpPYJOnoAUrlBzyveui,ldOGfm56kWs8T03wcptQunqEUBDrvC,Arg2GFJDt3emTvpO6fZkSVdaUHywnN=qNZKwi2M1S4fBzGQYrmPnea,KbL94nDHufSF0VcO2Nk3,iRTygNp4Lf36wQKlD2MHUhG7B
v7reLlOXCgD5pZ14w2tUA,p1lrNRIXqLQJznH6O,ddK4MmwpX5oG=Arg2GFJDt3emTvpO6fZkSVdaUHywnN,ldOGfm56kWs8T03wcptQunqEUBDrvC,xxpPYJOnoAUrlBzyveui
OARzhnB9o7uYvQGFaIcZ,ZpH2IWt7veyFobTsAnhi41,q0JfWbP8vACLxSNIncpOXkR6j=ddK4MmwpX5oG,p1lrNRIXqLQJznH6O,v7reLlOXCgD5pZ14w2tUA
L91nVzxH4hYrgPDsOuljXd0J,uhOkAKtLVv4XTy1nWE6,d1JiVThqEO0nBaY2QRNyZxlujWw7SK=q0JfWbP8vACLxSNIncpOXkR6j,ZpH2IWt7veyFobTsAnhi41,OARzhnB9o7uYvQGFaIcZ
V391t7nQWUBR5euCkJ,IJ6VkihabRm,lunVJF2G5bZMgTcCje0vaIB371SX=d1JiVThqEO0nBaY2QRNyZxlujWw7SK,uhOkAKtLVv4XTy1nWE6,L91nVzxH4hYrgPDsOuljXd0J
xxBJoKG54uwQ,gr5K72RtvAZYPVwkdnspbzQWNjEI,u1ml5XcLiZ7oDPs3UjedgpYHhfV=lunVJF2G5bZMgTcCje0vaIB371SX,IJ6VkihabRm,V391t7nQWUBR5euCkJ
dxAs4otSE98YmZnKy2iwRCB,fcIm8tvxlXZsaEY3bwuG4B,f8PVRTseIuj9BckO6GoyF5Lxv=u1ml5XcLiZ7oDPs3UjedgpYHhfV,gr5K72RtvAZYPVwkdnspbzQWNjEI,xxBJoKG54uwQ
tKVplxqYIdngGF6TZkXeb2PiwfME,vkMRnTNV9jFm,HMO0QciekqVpLKmA=f8PVRTseIuj9BckO6GoyF5Lxv,fcIm8tvxlXZsaEY3bwuG4B,dxAs4otSE98YmZnKy2iwRCB
DKqQekNtF6WlJLhBP9M5ca,GGTRaYBDeNyI25zlF,Vv0lSjAOHLfMnam3wtdor=HMO0QciekqVpLKmA,vkMRnTNV9jFm,tKVplxqYIdngGF6TZkXeb2PiwfME
a06i2XFf3oBnDrJQZEKmHpqY9ACW,DDS79jdWzLtE,zOZvXaebGNwHKfjRA=Vv0lSjAOHLfMnam3wtdor,GGTRaYBDeNyI25zlF,DKqQekNtF6WlJLhBP9M5ca
from P5mleDuhGM import *
mm5vCBc4DOz2Fj = V391t7nQWUBR5euCkJ(u"ࠧࡊࡐࡌࡘࠬૢ")
zRM3tZx2v6DjJU(OARzhnB9o7uYvQGFaIcZ(u"ࠨࡐࡒࡘࡎࡉࡅࠨૣ"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩ૤"))
ymraFo65GxbqVg8YeLHct4Zl2 = JJqxTSR6tZiQ79cpkwa3GMy(a4EuYDiRdrA)
xEc7nR3qoAlv6C8YjD,QEMyY8a9IoOcFqeuKztCVWmT7jXv,DDRulV7aKN3jCOWSBQkb95,PBem6Hqsfgjvz,KKcFOCmYRENepQnxi,YSTbrKgPf7NyhIDizB,gq2FVNBUKPzIw1pZAnYHJG,ja74FTtz9hK,RkfstxEyua67K2 = ymraFo65GxbqVg8YeLHct4Zl2
hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j = int(PBem6Hqsfgjvz)
G7XkvOrob5CBiAMFcVemDz4EZ1atxg = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel(tKVplxqYIdngGF6TZkXeb2PiwfME(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ૥"))
G7XkvOrob5CBiAMFcVemDz4EZ1atxg = G7XkvOrob5CBiAMFcVemDz4EZ1atxg.replace(Pc98uK2GLvfMwq6UtyJSHe03g,ddK4MmwpX5oG(u"ࠫࠬ૦")).replace(lc6sH83woipUCaLnRVAkgtrEJd257,OARzhnB9o7uYvQGFaIcZ(u"ࠬ࠭૧"))
if hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j==KbL94nDHufSF0VcO2Nk3(u"࠵࠺࠵ଏ"): hTZjiRxwmYoWpKtJIHVug36G = V391t7nQWUBR5euCkJ(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ૨")+uVp7krjL48oWd3tqGYCRz5M+L91nVzxH4hYrgPDsOuljXd0J(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ૩")+Qk3Eo8cXgASw+HMO0QciekqVpLKmA(u"ࠨࠢࡠࠫ૪")
else:
	jh97BT4K2ekx1Q6vfgUu = NdVvO42riJpCWElX(a4EuYDiRdrA).replace(uhOkAKtLVv4XTy1nWE6(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ૫"),f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠪࠫ૬")).replace(xxBJoKG54uwQ(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ૭"),d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠬ࠭૮"))
	jh97BT4K2ekx1Q6vfgUu = jh97BT4K2ekx1Q6vfgUu.replace(f8PVRTseIuj9BckO6GoyF5Lxv(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ૯"),GGTRaYBDeNyI25zlF(u"ࠧࠨ૰")).strip(fcIm8tvxlXZsaEY3bwuG4B(u"ࠨࠢࠪ૱"))
	jh97BT4K2ekx1Q6vfgUu = jh97BT4K2ekx1Q6vfgUu.replace(f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠩࠣࠤࠥࠦࠧ૲"),ddK4MmwpX5oG(u"ࠪࠤࠬ૳")).replace(d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"ࠫࠥࠦࠠࠨ૴"),xxBJoKG54uwQ(u"ࠬࠦࠧ૵")).replace(zOZvXaebGNwHKfjRA(u"࠭ࠠࠡࠩ૶"),dxAs4otSE98YmZnKy2iwRCB(u"ࠧࠡࠩ૷"))
	hTZjiRxwmYoWpKtJIHVug36G = DDS79jdWzLtE(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ૸")+G7XkvOrob5CBiAMFcVemDz4EZ1atxg+xxBJoKG54uwQ(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩૹ")+PBem6Hqsfgjvz+p1lrNRIXqLQJznH6O(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪૺ")+jh97BT4K2ekx1Q6vfgUu+p1lrNRIXqLQJznH6O(u"ࠫࠥࡣࠧૻ")
zRM3tZx2v6DjJU(ddK4MmwpX5oG(u"ࠬࡔࡏࡕࡋࡆࡉࠬૼ"),Wt7AdOqj38VbHfwgoaKPilx(mm5vCBc4DOz2Fj)+hTZjiRxwmYoWpKtJIHVug36G)
LHOA6hkrq47JzTQ85ZnUu = fQ6kvwg1FrYAzXjbLT.getSetting(ZpH2IWt7veyFobTsAnhi41(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ૽"))
ZKlH8DTFWhJPO1R9vxboUe = v7reLlOXCgD5pZ14w2tUA(u"ࡈࡤࡰࡸ࡫କ") if LHOA6hkrq47JzTQ85ZnUu==uVp7krjL48oWd3tqGYCRz5M else xxpPYJOnoAUrlBzyveui(u"ࡕࡴࡸࡩଔ")
if not ZKlH8DTFWhJPO1R9vxboUe and hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j in [iRTygNp4Lf36wQKlD2MHUhG7B(u"࠶࠸࠻ଐ"),p1lrNRIXqLQJznH6O(u"࠼࠷࠵଑")]:
	vh8gAzLSEiuO6NkGYjRI13BKs2y = str(RkfstxEyua67K2[GGTRaYBDeNyI25zlF(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૾")])
	mm5vCBc4DOz2Fj = lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠨ࡫ࡳࡸࡻ࠭૿") if hJ4cBOf9NoqZ7EDebaS1xmVGzdY5j==a06i2XFf3oBnDrJQZEKmHpqY9ACW(u"࠸࠳࠶଒") else xxpPYJOnoAUrlBzyveui(u"ࠩࡰ࠷ࡺ࠭଀")
	oOM6fji0UV3Yn2 = fQ6kvwg1FrYAzXjbLT.getSetting(qNZKwi2M1S4fBzGQYrmPnea(u"ࠪࡥࡻ࠴ࠧଁ")+mm5vCBc4DOz2Fj+f8PVRTseIuj9BckO6GoyF5Lxv(u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩଂ")+vh8gAzLSEiuO6NkGYjRI13BKs2y)
	PYWfQI0KxebFTymtXdwBalCG58qg3L = fQ6kvwg1FrYAzXjbLT.getSetting(lunVJF2G5bZMgTcCje0vaIB371SX(u"ࠬࡧࡶ࠯ࠩଃ")+mm5vCBc4DOz2Fj+KbL94nDHufSF0VcO2Nk3(u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ଄")+vh8gAzLSEiuO6NkGYjRI13BKs2y)
	if oOM6fji0UV3Yn2 or PYWfQI0KxebFTymtXdwBalCG58qg3L:
		DDRulV7aKN3jCOWSBQkb95 += qNZKwi2M1S4fBzGQYrmPnea(u"ࠧࡽࠩଅ")
		if oOM6fji0UV3Yn2: DDRulV7aKN3jCOWSBQkb95 += ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧଆ")+oOM6fji0UV3Yn2
		if PYWfQI0KxebFTymtXdwBalCG58qg3L: DDRulV7aKN3jCOWSBQkb95 += p1lrNRIXqLQJznH6O(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬଇ")+PYWfQI0KxebFTymtXdwBalCG58qg3L
		DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95.replace(q0JfWbP8vACLxSNIncpOXkR6j(u"ࠪࢀࠫ࠭ଈ"),uhOkAKtLVv4XTy1nWE6(u"ࠫࢁ࠭ଉ"))
	R6BcuHJwV3vlrW2ihQIMbs19xE = fQ6kvwg1FrYAzXjbLT.getSetting(ldOGfm56kWs8T03wcptQunqEUBDrvC(u"ࠬࡧࡶ࠯ࠩଊ")+mm5vCBc4DOz2Fj+fcIm8tvxlXZsaEY3bwuG4B(u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨଋ")+vh8gAzLSEiuO6NkGYjRI13BKs2y)
	if R6BcuHJwV3vlrW2ihQIMbs19xE:
		FFW08qJA4d6otuYZ3NnjCHPm = QPuHKNAT4jmCRg.findall(ddK4MmwpX5oG(u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪଌ"),DDRulV7aKN3jCOWSBQkb95,QPuHKNAT4jmCRg.DOTALL)
		DDRulV7aKN3jCOWSBQkb95 = DDRulV7aKN3jCOWSBQkb95.replace(FFW08qJA4d6otuYZ3NnjCHPm[d1JiVThqEO0nBaY2QRNyZxlujWw7SK(u"࠰ଓ")],R6BcuHJwV3vlrW2ihQIMbs19xE)
	mm5vCBc4DOz2Fj = mm5vCBc4DOz2Fj.upper()
	zT3xJQIVDmCgapBljs(DDRulV7aKN3jCOWSBQkb95,mm5vCBc4DOz2Fj,xEc7nR3qoAlv6C8YjD)
else:
	from gvn6IBeN7p import aarhp43yvIqojdnWs6Sb,p69eMXdJCmFbIw,wwXV0G1ObAMk
	CeJXk5gb27o = DDS79jdWzLtE(u"ࠨࠩ଍")
	aarhp43yvIqojdnWs6Sb(xxpPYJOnoAUrlBzyveui(u"ࠩࡶࡸࡦࡸࡴࠨ଎"))
	try: p69eMXdJCmFbIw(ymraFo65GxbqVg8YeLHct4Zl2,G7XkvOrob5CBiAMFcVemDz4EZ1atxg)
	except Exception as ezX76WkqKRxdtsvh: CeJXk5gb27o = BOYy8o0JEr9gHKLakhbjTRd4Z5zD.format_exc()
	wwXV0G1ObAMk(CeJXk5gb27o)
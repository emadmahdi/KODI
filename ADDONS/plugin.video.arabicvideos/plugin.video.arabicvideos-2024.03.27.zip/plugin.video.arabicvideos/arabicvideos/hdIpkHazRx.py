# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'SHOOFMAX'
JE7QrkmhletLwA0OZXu = '_SHM_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
FWpjdmYqwgi = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][1]
CN9FtxiBuYWm0slAG = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][2]
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==50: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==51: RRMWBwU6pG = SPFl6UGK4mrBua(url)
	elif mode==52: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url)
	elif mode==53: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==55: RRMWBwU6pG = k043CcqUuNl()
	elif mode==56: RRMWBwU6pG = YYZPrlugvQTw1NszAJDC()
	elif mode==57: RRMWBwU6pG = d3HBGsTc79uQvXE0iVamKL5rpOS(url,1)
	elif mode==58: RRMWBwU6pG = d3HBGsTc79uQvXE0iVamKL5rpOS(url,2)
	elif mode==59: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'المسلسلات','',56)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'الافلام','',55)
	return ''
def k043CcqUuNl():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'احدث الافلام',GqcEfFR8XQPgBMLr+'/movie/1/newest',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'افلام رائجة',GqcEfFR8XQPgBMLr+'/movie/1/popular',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اخر اضافات الافلام',GqcEfFR8XQPgBMLr+'/movie/1/latest',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'افلام كلاسيكية',GqcEfFR8XQPgBMLr+'/movie/1/classic',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اختيار افلام مرتبة بسنة الانتاج',GqcEfFR8XQPgBMLr+'/movie/1/yop',57)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اختيار افلام مرتبة بالافضل تقييم',GqcEfFR8XQPgBMLr+'/movie/1/review',57)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اختيار افلام مرتبة بالاكثر مشاهدة',GqcEfFR8XQPgBMLr+'/movie/1/views',57)
	return
def YYZPrlugvQTw1NszAJDC():
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'احدث المسلسلات',GqcEfFR8XQPgBMLr+'/series/1/newest',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات رائجة',GqcEfFR8XQPgBMLr+'/series/1/popular',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اخر اضافات المسلسلات',GqcEfFR8XQPgBMLr+'/series/1/latest',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسلات كلاسيكية',GqcEfFR8XQPgBMLr+'/series/1/classic',51)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اختيار مسلسلات مرتبة بسنة الانتاج',GqcEfFR8XQPgBMLr+'/series/1/yop',57)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اختيار مسلسلات مرتبة بالافضل تقييم',GqcEfFR8XQPgBMLr+'/series/1/review',57)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'اختيار مسلسلات مرتبة بالاكثر مشاهدة',GqcEfFR8XQPgBMLr+'/series/1/views',57)
	return
def SPFl6UGK4mrBua(url):
	if '?' in url:
		FtKo2AMUynNdTaYCljkxOe = url.split('?')
		url = FtKo2AMUynNdTaYCljkxOe[0]
		filter = '?' + oF0Yr4V7Ic(FtKo2AMUynNdTaYCljkxOe[1],'=&:/%')
	else: filter = ''
	FtKo2AMUynNdTaYCljkxOe = url.split('/')
	sort,YSTbrKgPf7NyhIDizB,type = FtKo2AMUynNdTaYCljkxOe[-1],FtKo2AMUynNdTaYCljkxOe[-2],FtKo2AMUynNdTaYCljkxOe[-3]
	if sort in ['yop','review','views']:
		if type=='movie': WXKiUx9gNhG='فيلم'
		elif type=='series': WXKiUx9gNhG='مسلسل'
		url = GqcEfFR8XQPgBMLr + '/genre/filter/' + oF0Yr4V7Ic(WXKiUx9gNhG) + '/' + YSTbrKgPf7NyhIDizB + '/' + sort + filter
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','','','SHOOFMAX-TITLES-1st')
		items = QPuHKNAT4jmCRg.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		kkDwsKNMG5xdcbj9BA84VCQe=0
		for id,title,nm8zlapr4oHMWxwfitc,G2WR0Oacvdq8ZQTjKboDU in items:
			kkDwsKNMG5xdcbj9BA84VCQe += 1
			G2WR0Oacvdq8ZQTjKboDU = CN9FtxiBuYWm0slAG + '/v2/img/program/main/' + G2WR0Oacvdq8ZQTjKboDU + '-2.jpg'
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr + '/program/' + id
			if type=='movie': fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,53,G2WR0Oacvdq8ZQTjKboDU)
			if type=='series': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسل '+title,VV7yf2htDCBU6EeSX8TJQM+'?ep='+nm8zlapr4oHMWxwfitc+'='+title+'='+G2WR0Oacvdq8ZQTjKboDU,52,G2WR0Oacvdq8ZQTjKboDU)
	else:
		if type=='movie': WXKiUx9gNhG='movies'
		elif type=='series': WXKiUx9gNhG='series'
		url = FWpjdmYqwgi + '/json/selected/' + sort + '-' + WXKiUx9gNhG + '-WW.json'
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','','','SHOOFMAX-TITLES-2nd')
		items = QPuHKNAT4jmCRg.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		kkDwsKNMG5xdcbj9BA84VCQe=0
		for id,nm8zlapr4oHMWxwfitc,G2WR0Oacvdq8ZQTjKboDU,title in items:
			kkDwsKNMG5xdcbj9BA84VCQe += 1
			G2WR0Oacvdq8ZQTjKboDU = FWpjdmYqwgi + '/img/program/' + G2WR0Oacvdq8ZQTjKboDU + '-2.jpg'
			VV7yf2htDCBU6EeSX8TJQM = GqcEfFR8XQPgBMLr + '/program/' + id
			if type=='movie': fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,53,G2WR0Oacvdq8ZQTjKboDU)
			elif type=='series': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'مسلسل '+title,VV7yf2htDCBU6EeSX8TJQM+'?ep='+nm8zlapr4oHMWxwfitc+'='+title+'='+G2WR0Oacvdq8ZQTjKboDU,52,G2WR0Oacvdq8ZQTjKboDU)
	title='صفحة '
	if kkDwsKNMG5xdcbj9BA84VCQe==16:
		for HYW8ge29T6OiEpbPl in range(1,13) :
			if not YSTbrKgPf7NyhIDizB==str(HYW8ge29T6OiEpbPl):
				url = GqcEfFR8XQPgBMLr+'/genre/filter/'+type+'/'+str(HYW8ge29T6OiEpbPl)+'/'+sort + filter
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title+str(HYW8ge29T6OiEpbPl),url,51)
	return
def opLlxOB2dUVZ5JF4j(url):
	FtKo2AMUynNdTaYCljkxOe = url.split('=')
	nm8zlapr4oHMWxwfitc = int(FtKo2AMUynNdTaYCljkxOe[1])
	name = NdVvO42riJpCWElX(FtKo2AMUynNdTaYCljkxOe[2])
	name = name.replace('_MOD_مسلسل ','')
	G2WR0Oacvdq8ZQTjKboDU = FtKo2AMUynNdTaYCljkxOe[3]
	url = url.split('?')[0]
	if nm8zlapr4oHMWxwfitc==0:
		Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(t7rXIzJfMLWRwaDeKhTq4C6dG,url,'','','','SHOOFMAX-EPISODES-1st')
		TTCRYZroizb = QPuHKNAT4jmCRg.findall('<select(.*?)</select>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('option value="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		nm8zlapr4oHMWxwfitc = int(items[-1])
	for CiZxgXTGW9pv in range(nm8zlapr4oHMWxwfitc,0,-1):
		VV7yf2htDCBU6EeSX8TJQM = url + '?ep=' + str(CiZxgXTGW9pv)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(CiZxgXTGW9pv)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,53,G2WR0Oacvdq8ZQTjKboDU)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,url,'','','','SHOOFMAX-PLAY-1st')
	tslUhOIR43vwBSzdr0 = QPuHKNAT4jmCRg.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if tslUhOIR43vwBSzdr0:
		vODi7LQeCnUaoRqZX9xs6djwm0tJA2 = tslUhOIR43vwBSzdr0[1].replace('T','    ')
		qbBvF2ra0jVHlNeOItzgdTnL6Kf3u('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+vODi7LQeCnUaoRqZX9xs6djwm0tJA2)
		return
	CmE0IlhScbjG1nk,NdX4kHCKlIy6GLPuA13oEZw = [],[]
	mTa7BI1EWLXvr4z5Vy6 = QPuHKNAT4jmCRg.findall('var origin_link = "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	lYyV3TBRsp5grbLo0i1j6PAQnw28I = QPuHKNAT4jmCRg.findall('var backup_origin_link = "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)[0]
	Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('hls: (.*?)_link\+"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for BHgLX9GZTb2jJrWiNKE,VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO:
		if 'backup' in BHgLX9GZTb2jJrWiNKE:
			BHgLX9GZTb2jJrWiNKE = 'backup server'
			url = lYyV3TBRsp5grbLo0i1j6PAQnw28I + VV7yf2htDCBU6EeSX8TJQM
		else:
			BHgLX9GZTb2jJrWiNKE = 'main server'
			url = mTa7BI1EWLXvr4z5Vy6 + VV7yf2htDCBU6EeSX8TJQM
		if '.m3u8' in url:
			CmE0IlhScbjG1nk.append(url)
			NdX4kHCKlIy6GLPuA13oEZw.append('m3u8  '+BHgLX9GZTb2jJrWiNKE)
	Y4xiULzGTKjb8mulO = QPuHKNAT4jmCRg.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	Y4xiULzGTKjb8mulO += QPuHKNAT4jmCRg.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	for BHgLX9GZTb2jJrWiNKE,VV7yf2htDCBU6EeSX8TJQM in Y4xiULzGTKjb8mulO:
		filename = VV7yf2htDCBU6EeSX8TJQM.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in BHgLX9GZTb2jJrWiNKE:
			BHgLX9GZTb2jJrWiNKE = 'backup server'
			url = lYyV3TBRsp5grbLo0i1j6PAQnw28I + VV7yf2htDCBU6EeSX8TJQM
		else:
			BHgLX9GZTb2jJrWiNKE = 'main server'
			url = mTa7BI1EWLXvr4z5Vy6 + VV7yf2htDCBU6EeSX8TJQM
		CmE0IlhScbjG1nk.append(url)
		NdX4kHCKlIy6GLPuA13oEZw.append('mp4  '+BHgLX9GZTb2jJrWiNKE+'  '+filename)
	ShT1xUHjlDotkRuPq7gv = ISveRUGKjgM9wqL6FZpsku0bB('Select Video Quality:', NdX4kHCKlIy6GLPuA13oEZw)
	if ShT1xUHjlDotkRuPq7gv == -1 : return
	url = CmE0IlhScbjG1nk[ShT1xUHjlDotkRuPq7gv]
	zT3xJQIVDmCgapBljs(url,mm5vCBc4DOz2Fj,'video')
	return
def d3HBGsTc79uQvXE0iVamKL5rpOS(url,type):
	if 'series' in url: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr + '/genre/مسلسل'
	else: lZqkuhgaBHSVX8NItKG05cdLJe7Ao = GqcEfFR8XQPgBMLr + '/genre/فيلم'
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = oF0Yr4V7Ic(lZqkuhgaBHSVX8NItKG05cdLJe7Ao)
	Ht6Gg8lbciAd9FaUQVs = ZZUyb9R7MFizwXkhd4gC(lu4xpkY5LFOm6t2In,lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: TTCRYZroizb = QPuHKNAT4jmCRg.findall('subgenre(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	elif type==2: TTCRYZroizb = QPuHKNAT4jmCRg.findall('country(.*?)div',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('option value="(.*?)">(.*?)</option',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if type==1:
		for sk7UwxvnGzaFtYf,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url+'?subgenre='+sk7UwxvnGzaFtYf,58)
	elif type==2:
		url,sk7UwxvnGzaFtYf = url.split('?')
		for opOrMkINsZbSfcP8wYRzayFt,title in items:
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url+'?country='+opOrMkINsZbSfcP8wYRzayFt+'&'+sk7UwxvnGzaFtYf,51)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if not search: search = wod1HJ0fnvcTNAX2WIiMu9P()
	if not search: return
	Unr6jRmMIv80lSGbkBCehpaWAdV = search.replace(' ','%20')
	url = GqcEfFR8XQPgBMLr+'/search?q='+Unr6jRmMIv80lSGbkBCehpaWAdV
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('general-body(.*?)search-bottom-padding',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	if items:
		for VV7yf2htDCBU6EeSX8TJQM,G2WR0Oacvdq8ZQTjKboDU,title in items:
			url = GqcEfFR8XQPgBMLr + VV7yf2htDCBU6EeSX8TJQM
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+oF0Yr4V7Ic(title)+'='+G2WR0Oacvdq8ZQTjKboDU
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,url,52,G2WR0Oacvdq8ZQTjKboDU)
				else:
					title = '_MOD_فيلم '+title
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,url,53,G2WR0Oacvdq8ZQTjKboDU)
	return
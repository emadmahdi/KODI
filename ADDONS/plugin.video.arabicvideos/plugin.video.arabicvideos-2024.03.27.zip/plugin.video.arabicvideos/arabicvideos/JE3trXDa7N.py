# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'SHOOFPRO'
JE7QrkmhletLwA0OZXu = '_SHP_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = ['مصارعة','بث مباشر']
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==480: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==481: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==482: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==483: RRMWBwU6pG = opLlxOB2dUVZ5JF4j(url,text)
	elif mode==489: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text,url)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','SHOOFPRO-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = QPuHKNAT4jmCRg.findall('href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	ka6I93CnvublQMtjr = ka6I93CnvublQMtjr[0].strip('/')
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(ka6I93CnvublQMtjr,'url')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع',ka6I93CnvublQMtjr,489,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+'أحدث المواضيع',ka6I93CnvublQMtjr,481)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"navigation"(.*?)"myAccount"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?</span>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if VV7yf2htDCBU6EeSX8TJQM=='#': continue
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,481)
	return Ht6Gg8lbciAd9FaUQVs
def SPFl6UGK4mrBua(url,cDRSijU9Pmx27NgvLKda5rM0eJ3nQC):
	items = []
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"post(.*?)"footer"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not TTCRYZroizb: return
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	gltHFKTroJfpLe = []
	OWBqwsUjLbiGrKhlD = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	fNzZo6jVKyMRIT5rW8UB27lCYsHqx9 = '/'.join(cDRSijU9Pmx27NgvLKda5rM0eJ3nQC.strip('/').split('/')[4:]).split('-')
	for VV7yf2htDCBU6EeSX8TJQM,title,G2WR0Oacvdq8ZQTjKboDU in items:
		title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
		CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) حلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
		if cDRSijU9Pmx27NgvLKda5rM0eJ3nQC:
			FsnXTNzcG53RUk = '/'.join(VV7yf2htDCBU6EeSX8TJQM.strip('/').split('/')[4:]).split('-')
			YRZE5cwje9 = len([GToyYINutA0BV for GToyYINutA0BV in fNzZo6jVKyMRIT5rW8UB27lCYsHqx9 if GToyYINutA0BV in FsnXTNzcG53RUk])
			if YRZE5cwje9>2 and '/episodes/' in VV7yf2htDCBU6EeSX8TJQM:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,482,G2WR0Oacvdq8ZQTjKboDU)
		else:
			if not CiZxgXTGW9pv: CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) الحلقة \d+',title,QPuHKNAT4jmCRg.DOTALL)
			if set(title.split()) & set(OWBqwsUjLbiGrKhlD) and 'مسلسل' not in title:
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,482,G2WR0Oacvdq8ZQTjKboDU)
			elif CiZxgXTGW9pv and 'حلقة' in title:
				title = '_MOD_' + CiZxgXTGW9pv[0]
				if title not in gltHFKTroJfpLe:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,483,G2WR0Oacvdq8ZQTjKboDU,'',url)
					gltHFKTroJfpLe.append(title)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,483,G2WR0Oacvdq8ZQTjKboDU,'',url)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("'pagination'(.*?)</div>",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall("href='(.*?)'.*?>(.*?)</a>",wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			title = title.replace('الصفحة ','')
			if title!='': fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,481,'','',cDRSijU9Pmx27NgvLKda5rM0eJ3nQC)
	return
def opLlxOB2dUVZ5JF4j(url,lZqkuhgaBHSVX8NItKG05cdLJe7Ao):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	G2WR0Oacvdq8ZQTjKboDU = QPuHKNAT4jmCRg.findall('"img-responsive" src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if G2WR0Oacvdq8ZQTjKboDU: G2WR0Oacvdq8ZQTjKboDU = G2WR0Oacvdq8ZQTjKboDU[0]
	else: G2WR0Oacvdq8ZQTjKboDU = AAsbUG0jZ5igBpNKQwFrJTd.getInfoLabel('ListItem.Thumb')
	HcupdiZrjKDa017AkO = True
	kzlepwfG1iEyIJKTY45quXO = QPuHKNAT4jmCRg.findall('"listSeasons(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if kzlepwfG1iEyIJKTY45quXO and '/ajax/seasons' not in url:
		wltPGJcYo12Ed = kzlepwfG1iEyIJKTY45quXO[0]
		count = wltPGJcYo12Ed.count('data-slug=')
		if count==0: count = wltPGJcYo12Ed.count('data-season=')
		if count>1:
			HcupdiZrjKDa017AkO = False
			if 'data-slug="' in wltPGJcYo12Ed:
				items = QPuHKNAT4jmCRg.findall('data-slug="(.*?)">(.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				for id,title in items:
					VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,483,G2WR0Oacvdq8ZQTjKboDU)
			else:
				items = QPuHKNAT4jmCRg.findall('data-season="(.*?)">(.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
				for id,title in items:
					VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,483,G2WR0Oacvdq8ZQTjKboDU)
	if HcupdiZrjKDa017AkO:
		wltPGJcYo12Ed = ''
		if '/ajax/seasons' in url: wltPGJcYo12Ed = Ht6Gg8lbciAd9FaUQVs
		else:
			kk73xHNzri1P2wgULMv4sDtoTnybO = QPuHKNAT4jmCRg.findall('"eplist"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
			if kk73xHNzri1P2wgULMv4sDtoTnybO: wltPGJcYo12Ed = kk73xHNzri1P2wgULMv4sDtoTnybO[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)" title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		if items:
			for VV7yf2htDCBU6EeSX8TJQM,title in items:
				title = title.strip(' ')
				fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,482,G2WR0Oacvdq8ZQTjKboDU)
	if not vvruH9wsBDfbhFtyq1MUd2zV: SPFl6UGK4mrBua(lZqkuhgaBHSVX8NItKG05cdLJe7Ao,url)
	return
def unQmcpAEF2DaNX87fTgMW(url):
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.strip('/')+'/?do=watch'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','SHOOFPRO-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	LL8heV7kxYI5bOjEZ6XaUQWwfPA = []
	ka6I93CnvublQMtjr = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(url,'url')
	RRtUaOkQKgPCJTvFYz0 = QPuHKNAT4jmCRg.findall('vo_postID = "(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if not RRtUaOkQKgPCJTvFYz0: RRtUaOkQKgPCJTvFYz0 = QPuHKNAT4jmCRg.findall('\(this\.id\,0\,(.*?)\)',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	RRtUaOkQKgPCJTvFYz0 = RRtUaOkQKgPCJTvFYz0[0]
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"serversList"(.*?)</ul>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('id="(.*?)".*?">(.*?)</li>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for uYFAR9lIDC3LZG7sTfcUwkyNna,title in items:
			title = title.strip(' ')
			VV7yf2htDCBU6EeSX8TJQM = ka6I93CnvublQMtjr+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+RRtUaOkQKgPCJTvFYz0+'&video='+uYFAR9lIDC3LZG7sTfcUwkyNna[2:]+'?named='+title+'__watch'
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"getEmbed".*?src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		title = znCZ7g9Fl1iBEStdWrUv3RmwIfpXoT(VV7yf2htDCBU6EeSX8TJQM[0],'url')
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]+'?named='+title+'__embed'
		LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url.strip('/')+'/?do=download'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','SHOOFPRO-PLAY-2nd')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"table-responsive"(.*?)</table>',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('<td>(.*?)</td>.*?href="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for title,VV7yf2htDCBU6EeSX8TJQM in items:
			title = title.strip(' ')
			if 'anavidz' in VV7yf2htDCBU6EeSX8TJQM: nUbpaNT0vhcj7ZsEz = '__خاص'
			else: nUbpaNT0vhcj7ZsEz = ''
			VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__download'+nUbpaNT0vhcj7ZsEz
			LL8heV7kxYI5bOjEZ6XaUQWwfPA.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(LL8heV7kxYI5bOjEZ6XaUQWwfPA,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search,ka6I93CnvublQMtjr=''):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	if ka6I93CnvublQMtjr=='': ka6I93CnvublQMtjr = GqcEfFR8XQPgBMLr
	url = ka6I93CnvublQMtjr+'/search/'+search+'/'
	SPFl6UGK4mrBua(url,'')
	return
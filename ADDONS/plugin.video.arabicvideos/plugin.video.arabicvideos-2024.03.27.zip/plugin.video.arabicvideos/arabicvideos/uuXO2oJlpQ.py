# -*- coding: utf-8 -*-
from gvn6IBeN7p import *
mm5vCBc4DOz2Fj = 'KATKOTTV'
JE7QrkmhletLwA0OZXu = '_KTV_'
GqcEfFR8XQPgBMLr = EGcFon0zR4mSL1[mm5vCBc4DOz2Fj][0]
EhRQ8zB1fdkj5vN6HlmqD7SOU = []
def hLD0mk9HIuPOz7pw(mode,url,text):
	if   mode==810: RRMWBwU6pG = YpFfN68PZ132()
	elif mode==811: RRMWBwU6pG = SPFl6UGK4mrBua(url,text)
	elif mode==812: RRMWBwU6pG = unQmcpAEF2DaNX87fTgMW(url)
	elif mode==813: RRMWBwU6pG = VsLE4okmztlNIU8J(url)
	elif mode==819: RRMWBwU6pG = mt4qhKoi9ynlYXFRszgZ7b3wr(text)
	else: RRMWBwU6pG = False
	return RRMWBwU6pG
def YpFfN68PZ132():
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',GqcEfFR8XQPgBMLr,'','','','','KATKOTTV-MENU-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	fpjEiKI9bTc1xhoeq37vPusDJ6SB('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"primary-links"(.*?)"most-viewed"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	wltPGJcYo12Ed = TTCRYZroizb[0]
	items = QPuHKNAT4jmCRg.findall('href="(.*?)".*?<span>(.*?)<',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
	for VV7yf2htDCBU6EeSX8TJQM,title in items:
		if title in EhRQ8zB1fdkj5vN6HlmqD7SOU: continue
		fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',mm5vCBc4DOz2Fj+'_SCRIPT_'+JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,811)
	return
def SPFl6UGK4mrBua(url,type=''):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	TTCRYZroizb = QPuHKNAT4jmCRg.findall('"home-content"(.*?)"footer"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		gltHFKTroJfpLe = []
		for G2WR0Oacvdq8ZQTjKboDU,VV7yf2htDCBU6EeSX8TJQM,title in items:
			CiZxgXTGW9pv = QPuHKNAT4jmCRg.findall('(.*?) (الحلقة|حلقة).\d+',title,QPuHKNAT4jmCRg.DOTALL)
			if 'episodes' not in type and CiZxgXTGW9pv:
				title = '_MOD_' + CiZxgXTGW9pv[0][0]
				title = title.replace('اون لاين','')
				if title not in gltHFKTroJfpLe:
					fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,813,G2WR0Oacvdq8ZQTjKboDU)
					gltHFKTroJfpLe.append(title)
			else: fpjEiKI9bTc1xhoeq37vPusDJ6SB('video',JE7QrkmhletLwA0OZXu+title,VV7yf2htDCBU6EeSX8TJQM,812,G2WR0Oacvdq8ZQTjKboDU)
	TTCRYZroizb = QPuHKNAT4jmCRg.findall("'pagination'(.*?)footer",Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if TTCRYZroizb:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		wltPGJcYo12Ed = TTCRYZroizb[0]
		items = QPuHKNAT4jmCRg.findall('href="(.*?)">(.*?)</a>',wltPGJcYo12Ed,QPuHKNAT4jmCRg.DOTALL)
		for VV7yf2htDCBU6EeSX8TJQM,title in items:
			title = UH1IuvwM9e4cl7if63nNdozJFSj(title)
			fpjEiKI9bTc1xhoeq37vPusDJ6SB('folder',JE7QrkmhletLwA0OZXu+'صفحة '+title,VV7yf2htDCBU6EeSX8TJQM,811,'','',type)
	return
def VsLE4okmztlNIU8J(url):
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('"category".*?href="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM: SPFl6UGK4mrBua(VV7yf2htDCBU6EeSX8TJQM[0],'episodes')
	return
def unQmcpAEF2DaNX87fTgMW(url):
	YsDryBSXquzdEUta8kxjfO = []
	lZqkuhgaBHSVX8NItKG05cdLJe7Ao = url+'?do=watch'
	nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',lZqkuhgaBHSVX8NItKG05cdLJe7Ao,'','','','','KATKOTTV-PLAY-1st')
	Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
	VV7yf2htDCBU6EeSX8TJQM = QPuHKNAT4jmCRg.findall('" src="(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
	if VV7yf2htDCBU6EeSX8TJQM:
		VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM[0]
		YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	else:
		nbdMp8UuhzP3oq4cDWj6eyZVt = jjXeDpKN9HRh1ZY(t7rXIzJfMLWRwaDeKhTq4C6dG,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		Ht6Gg8lbciAd9FaUQVs = nbdMp8UuhzP3oq4cDWj6eyZVt.content
		qqubH4jokedIstn1JP3fQ = QPuHKNAT4jmCRg.findall('post=(.*?)"',Ht6Gg8lbciAd9FaUQVs,QPuHKNAT4jmCRg.DOTALL)
		if qqubH4jokedIstn1JP3fQ:
			qqubH4jokedIstn1JP3fQ = jm9LDJTlXsqZM8EAygS26twWQ70.b64decode(qqubH4jokedIstn1JP3fQ[0])
			if Nnxm30dfoBWRYpIC7KsQGl: qqubH4jokedIstn1JP3fQ = qqubH4jokedIstn1JP3fQ.decode('utf8')
			qqubH4jokedIstn1JP3fQ = kMLWTt2fO9dnGDUgHh('dict',qqubH4jokedIstn1JP3fQ)
			Y4xiULzGTKjb8mulO = qqubH4jokedIstn1JP3fQ['servers']
			lGKfCUP9XRTaBwQ6pq7n0 = list(Y4xiULzGTKjb8mulO.keys())
			Y4xiULzGTKjb8mulO = list(Y4xiULzGTKjb8mulO.values())
			QV8h5bD9YtNq1gfmx2jUyZlXASWv4L = zip(lGKfCUP9XRTaBwQ6pq7n0,Y4xiULzGTKjb8mulO)
			for title,VV7yf2htDCBU6EeSX8TJQM in QV8h5bD9YtNq1gfmx2jUyZlXASWv4L:
				VV7yf2htDCBU6EeSX8TJQM = VV7yf2htDCBU6EeSX8TJQM+'?named='+title+'__watch'
				YsDryBSXquzdEUta8kxjfO.append(VV7yf2htDCBU6EeSX8TJQM)
	import bcQwT9tl1C
	bcQwT9tl1C.DDOan0hgGHMNcq4fZiVU1SJRP(YsDryBSXquzdEUta8kxjfO,mm5vCBc4DOz2Fj,'video',url)
	return
def mt4qhKoi9ynlYXFRszgZ7b3wr(search):
	search,vwIN38HprDqTW5Sh61exF7EnA,showDialogs = Gq9cSoCJU2p1e3T4MFkdWQvuD(search)
	if search=='': search = wod1HJ0fnvcTNAX2WIiMu9P()
	if search=='': return
	search = search.replace(' ','+')
	url = GqcEfFR8XQPgBMLr+'/?s='+search
	SPFl6UGK4mrBua(url,'search')
	return
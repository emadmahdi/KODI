# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ䏨")
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䏩"):l1l111_l1_ (u"ࠬ࠭䏪")}
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡎࡅࡐࡣࠬ䏫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ䏬"),l1l111_l1_ (u"ࠨࡹࡺࡩࠬ䏭")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ䏮")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ䏯")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䏰"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䏱"),l111l1_l1_,369,l1l111_l1_ (u"࠭ࠧ䏲"),l1l111_l1_ (u"ࠧࠨ䏳"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䏴"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏵"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭䏶"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䏷"),364)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䏸"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䏹"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䏺"),365)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䏻"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䏼"),l1l111_l1_ (u"ࠪࠫ䏽"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䏾"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭䏿"),l1l111_l1_ (u"࠭ࠧ䐀"),l1l111_l1_ (u"ࠧࠨ䐁"),l1l111_l1_ (u"ࠨࠩ䐂"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ䐃"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ䐄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䐅"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠬ࠭䐆"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐇"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䐈")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䐉"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐊"),l1l111_l1_ (u"ࠪࠫ䐋"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭䐌"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ䐍"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐎"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䐏")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䐐"),url,l1l111_l1_ (u"ࠩࠪ䐑"),l1l111_l1_ (u"ࠪࠫ䐒"),l1l111_l1_ (u"ࠫࠬ䐓"),l1l111_l1_ (u"ࠬ࠭䐔"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䐕"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ䐖") in html:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐗"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ䐘"),url,361,l1l111_l1_ (u"ࠪࠫ䐙"),l1l111_l1_ (u"ࠫࠬ䐚"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䐛"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ䐜"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐝"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐞"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1lllll1lll1_l1_,type=l1l111_l1_ (u"ࠩࠪ䐟")):
	if l1l111_l1_ (u"ࠪ࠾࠿࠭䐠") in l1lllll1lll1_l1_:
		l1llllll_l1_,url = l1lllll1lll1_l1_.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ䐡"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䐢"))
		url = server+url
	else: url,l1llllll_l1_ = l1lllll1lll1_l1_,l1lllll1lll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䐣"),url,l1l111_l1_ (u"ࠧࠨ䐤"),l1l111_l1_ (u"ࠨࠩ䐥"),l1l111_l1_ (u"ࠩࠪ䐦"),l1l111_l1_ (u"ࠪࠫ䐧"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ䐨"))
	html = response.content
	if type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䐩"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠪ䐪"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䐫"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠨ࡞࡟࠳ࠬ䐬"),l1l111_l1_ (u"ࠩ࠲ࠫ䐭")).replace(l1l111_l1_ (u"ࠪࡠࡡࠨࠧ䐮"),l1l111_l1_ (u"ࠫࠧ࠭䐯"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡍࡲࡪࡦ࠰࠱ࡒࡿࡣࡪ࡯ࡤࡔࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ䐰"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡇࡳ࡫ࡧࡍࡹ࡫࡭ࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ䐱"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠠࠨ䐲"),l1l111_l1_ (u"ࠨࠩ䐳"))
			if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䐴") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐵"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠫา๊โสࠩ䐶") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠰ำไใหࠣ࠯ࡡࡪࠫࠨ䐷"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䐸") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐹"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䐺"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䐻"):
			l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ䐼"),block,re.DOTALL)
			if l111l1llll_l1_:
				count = l111l1llll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭䐽")+count
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐾"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ䐿"),l1ll1ll_l1_,361,l1l111_l1_ (u"ࠧࠨ䑀"),l1l111_l1_ (u"ࠨࠩ䑁"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䑂"))
		elif type==l1l111_l1_ (u"ࠪࠫ䑃"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䑄"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䑅"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"࠭ีโฯฬࠤࠬ䑆")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑇"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠨࠩ䑈")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䑉"),url,l1l111_l1_ (u"ࠪࠫ䑊"),l1l111_l1_ (u"ࠫࠬ䑋"),l1l111_l1_ (u"ࠬ࠭䑌"),l1l111_l1_ (u"࠭ࠧ䑍"),l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䑎"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭䑏"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"ࠩ࠰ࠫ䑐"),l1l111_l1_ (u"ࠪࠤࠬ䑑")).strip(l1l111_l1_ (u"ࠫ࠴࠭䑒"))
	if l1l111_l1_ (u"๋่ࠬิ็ࠪ䑓") in name and type==l1l111_l1_ (u"࠭ࠧ䑔"):
		name = name.split(l1l111_l1_ (u"ࠧๆ๊ึ้ࠬ䑕"))[0]
		name = name.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠨ䑖"),l1l111_l1_ (u"ࠩࠪ䑗")).strip(l1l111_l1_ (u"ࠪࠤࠬ䑘"))
	elif l1l111_l1_ (u"ࠫา๊โสࠩ䑙") in name:
		name = name.split(l1l111_l1_ (u"ࠬำไใหࠪ䑚"))[0]
		name = name.replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭䑛"),l1l111_l1_ (u"ࠧࠨ䑜")).strip(l1l111_l1_ (u"ࠨࠢࠪ䑝"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳ࠭䑞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠪࠫ䑟"):
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭䑠"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࠫ䑡") in title: continue
				if l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ䑢") in title: continue
				title = name+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䑣")+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑤"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"ࠩࠪ䑥"),l1l111_l1_ (u"ࠪࠫ䑦"),l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䑧"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠪࠫ࠭䑨"),block+l1l111_l1_ (u"࠭ࠦࠧࠩ䑩"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䑪"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ䑫"))
				title = name+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䑬")+title
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䑭"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䑮"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠬࠦ࠭ࠡ็ส๎ู๊ࠥๆษࠪ䑯"),l1l111_l1_ (u"࠭ࠧ䑰")).replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠠࠨ䑱"),l1l111_l1_ (u"ࠨࠩ䑲"))
		else: title = l1l111_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ䑳")
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䑴"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䑵"),url,l1l111_l1_ (u"ࠬ࠭䑶"),l1l111_l1_ (u"࠭ࠧ䑷"),l1l111_l1_ (u"ࠧࠨ䑸"),l1l111_l1_ (u"ࠨࠩ䑹"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䑺"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀส่ฯ฻ๆ๋ใ࠿࠲࠯ࡅ࠼ࡢ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䑻"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡉࡲࡨࡥࡥࠤࠪ䑼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䑽"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䑾") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠧิ์ิๅึࠦๅศ์ࠣื๏๋วࠨ䑿"): name = l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䒀")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䒁")+name+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䒂")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯ࡳࡵ࠯࠰ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䒃"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䒄"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䒅") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ䒆"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭䒇")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ䒈")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡱࡾࡩࡩ࡮ࡣࠪ䒉")+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䒊")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䒋"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"࠭ࠧ䒌")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ䒍"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ䒎"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ䒏"),l1l111_l1_ (u"ࠪ࠯ࠬ䒐"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ䒑"),l1l111_l1_ (u"ࠬ࠵ࠧ䒒"),l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡹࡥࡳ࡫ࡨࡷࠬ䒓"),l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡡ࡯࡫ࡰࡩࠬ䒔"),l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡵࡸࠪ䒕")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠩส่่๊ࠧ䒖"),l1l111_l1_ (u"ࠪห้ษแๅษ่ࠫ䒗"),l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ䒘"),l1l111_l1_ (u"ࠬอไศ่ํ้๏่ࠦࠡษ็็ึะ่็ࠩ䒙"),l1l111_l1_ (u"࠭วๅสิห๊าࠠหๆํๅื๐่็์ฬࠫ䒚")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไ็๊฼ࠤฬ๊ๅุๆ๋ฬ࠿࠭䒛"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"ࠨࠩ䒜"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䒝"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ䒞"),l1l111_l1_ (u"ࠫࠬ䒟"),False,l1l111_l1_ (u"ࠬ࠭䒠"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䒡"))
		hostname = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䒢")]
		hostname = hostname.strip(l1l111_l1_ (u"ࠨ࠱ࠪ䒣"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ䒤")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lllll1lll1_l1_,filter):
	if l1l111_l1_ (u"ࠪࡃࡄ࠭䒥") in l1lllll1lll1_l1_: url = l1lllll1lll1_l1_.split(l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䒦"))[0]
	else: url = l1lllll1lll1_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䒧"),l1l111_l1_ (u"࠭ࠧ䒨"))
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ䒩"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ䒪"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ䒫"),l1l111_l1_ (u"ࠪࠫ䒬")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ䒭"))
	if type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ䒮"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"࠭࠽࠾ࠩ䒯") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠧ࠾࠿ࠪ䒰") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䒱")+category+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭䒲")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䒳")+category+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ䒴")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ䒵"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ䒶")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ䒷"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䒸"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䒹")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䒺"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䒻"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠬ࠭䒼"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䒽"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠧࠨ䒾"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䒿")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lllll1lll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓀"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭䓁"),l1111111_l1_,361,l1l111_l1_ (u"ࠫࠬ䓂"),l1l111_l1_ (u"ࠬ࠭䓃"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䓄"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓅"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ䓆")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ䓇"),l1111111_l1_,361,l1l111_l1_ (u"ࠪࠫ䓈"),l1l111_l1_ (u"ࠫࠬ䓉"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䓊"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䓋"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䓌"),l1l111_l1_ (u"ࠨࠩ䓍"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䓎"),url,l1l111_l1_ (u"ࠪࠫ䓏"),l1l111_l1_ (u"ࠫࠬ䓐"),l1l111_l1_ (u"ࠬ࠭䓑"),l1l111_l1_ (u"࠭ࠧ䓒"),l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䓓"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ䓔"),l1l111_l1_ (u"ࠩࠥࠫ䓕")).replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ䓖"),l1l111_l1_ (u"ࠫ࠴࠭䓗"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂ࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ䓘"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ䓙"),block+l1l111_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ䓚"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ䓛") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ䓜"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠪࡁࡂ࠭䓝") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䓞"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ䓟")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lllll1lll1_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓠"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ䓡"),l1111111_l1_,361,l1l111_l1_ (u"ࠨࠩ䓢"),l1l111_l1_ (u"ࠩࠪ䓣"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䓤"))
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓥"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ䓦"),l1lllll1_l1_,364,l1l111_l1_ (u"࠭ࠧ䓧"),l1l111_l1_ (u"ࠧࠨ䓨"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ䓩"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䓪")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ䓫")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䓬")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ䓭")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ䓮")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓯"),l1lllll_l1_+name+l1l111_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ䓰"),l1lllll1_l1_,365,l1l111_l1_ (u"ࠩࠪ䓱"),l1l111_l1_ (u"ࠪࠫ䓲"),l1l111l1_l1_+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䓳"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠬࡸࠧ䓴") or value==l1l111_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ䓵"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䓶") in option: continue
			if l1l111_l1_ (u"ࠨษ็็้࠭䓷") in option: continue
			if l1l111_l1_ (u"ࠩࡱ࠱ࡦ࠭䓸") in value: continue
			if option==l1l111_l1_ (u"ࠪࠫ䓹"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡴࡡ࡮ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡳࡥ࠿ࠩ䓺"),option,re.DOTALL)
			if l1ll1l11ll1_l1_: l1l11l1ll_l1_ = l1ll1l11ll1_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠬࡀࠠࠨ䓻")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䓼")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿ࠪ䓽")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䓾")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁࠬ䓿")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ䔀")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ䔁"):
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔂"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"࠭ࠧ䔃"),l1l111_l1_ (u"ࠧࠨ䔄"),l1l1l11l_l1_+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䔅"))
			elif type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䔆") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠪࡁࡂ࠭䔇") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ䔈"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䔉")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lllll1lll1_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔊"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"ࠧࠨ䔋"),l1l111_l1_ (u"ࠨࠩ䔌"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䔍"))
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔎"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"ࠫࠬ䔏"),l1l111_l1_ (u"ࠬ࠭䔐"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ䔑"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭䔒"),l1l111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ䔓")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠩࡰࡴࡦࡧࠧ䔔"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ䔕"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ䔖"),l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ䔗"),l1l111_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧ䔘"),l1l111_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ䔙"),l1l111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ䔚"),l1l111_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ䔛")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䔜") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䔝"),l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠭䔞"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䔟"),l1l111_l1_ (u"ࠧ࠻࠼࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩ࠲ࠫ䔠"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠿ࡀࠫ䔡"),l1l111_l1_ (u"ࠩ࠲ࠫ䔢"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪࠪࠫ࠭䔣"),l1l111_l1_ (u"ࠫ࠴࠭䔤"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ䔥"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"࠭ࠧ䔦")
	if l1l111_l1_ (u"ࠧ࠾࠿ࠪ䔧") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠩࠫ䔨"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࡁࠬ䔩"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ䔪")
		if l1l111_l1_ (u"ࠫࠪ࠭䔫") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ䔬") and value!=l1l111_l1_ (u"࠭࠰ࠨ䔭"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ䔮")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䔯") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ䔰"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䔱")+key+l1l111_l1_ (u"ࠫࡂࡃࠧ䔲")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ䔳"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䔴")+key+l1l111_l1_ (u"ࠧ࠾࠿ࠪ䔵")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ䔶"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ䔷"))
	return l1l1l111_l1_
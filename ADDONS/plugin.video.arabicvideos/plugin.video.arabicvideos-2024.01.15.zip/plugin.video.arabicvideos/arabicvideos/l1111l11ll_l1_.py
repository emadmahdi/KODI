# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
import bs4
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ◐")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡏࡇࡤ࠭◑")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ◒"):l111l1_l1_}
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==510: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==511: l1lll_l1_ = l1llllll1l1_l1_(url)
	elif mode==512: l1lll_l1_ = l1111llll1_l1_(url)
	elif mode==513: l1lll_l1_ = l1111lll1l_l1_(url)
	elif mode==514: l1lll_l1_ = l1lllllll11_l1_(url,l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ◓")+text)
	elif mode==515: l1lll_l1_ = l1lllllll11_l1_(url,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ◔")+text)
	elif mode==516: l1lll_l1_ = l11111lll1_l1_(text)
	elif mode==517: l1lll_l1_ = l1111l1ll1_l1_(url)
	elif mode==518: l1lll_l1_ = l1111l1lll_l1_(url)
	elif mode==519: l1lll_l1_ = l1lll1_l1_(text)
	elif mode==520: l1lll_l1_ = l1111l111l_l1_(url)
	elif mode==521: l1lll_l1_ = l1llllll11l_l1_(url)
	elif mode==522: l1lll_l1_ = PLAY(url)
	elif mode==523: l1lll_l1_ = l1lllllllll_l1_(text)
	elif mode==524: l1lll_l1_ = l1111111l1_l1_()
	elif mode==525: l1lll_l1_ = l1111lll11_l1_()
	elif mode==526: l1lll_l1_ = l1111l1111_l1_()
	elif mode==527: l1lll_l1_ = l1111111ll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬ◕")):
	if not l1l11l11_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◖"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣฬ๊๎ำ้฻ฬࠤฬ๊ำ๋่่หࠬ◗"),l1l111_l1_ (u"ࠧࠨ◘"),519)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭◙"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ◚"),l1l111_l1_ (u"ࠪࠫ◛"),9999)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◜"),l1lllll_l1_+l1l111_l1_ (u"๋่ࠬิ๊฼อࠥอไฤ฻่ห้࠭◝"),l1l111_l1_ (u"࠭ࠧ◞"),525)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◟"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็วูิวึࠩ◠"),l1l111_l1_ (u"ࠩࠪ◡"),526)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◢"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊ๅึ่ไหฯ࠭◣"),l1l111_l1_ (u"ࠬ࠭◤"),527)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◥"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆ่๊ํ฿วหࠩ◦"),l1l111_l1_ (u"ࠨࠩ◧"),524)
	return
def l1111111l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◨"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦ࠭ࠡะสูฮ࠭◩"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࠫ◪"),520)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◫"),l1lllll_l1_+l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡ࠯ࠣวาีหࠨ◬"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯࡭ࡣࡷࡩࡸࡺࠧ◭"),521)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◮"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ࠲ࠦรใั่ࠫ◯"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࡳࡱࡪࡥࡴࡶࠪ◰"),521)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◱"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦ็ะืࠠๆึส๋ิฯࠧ◲"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࡶࡪࡧࡺࡷࠬ◳"),521)
	return
def l1111lll11_l1_():
	l1lllllll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠩ◴")
	l11111l1l1_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫ◵")
	l1111ll1ll_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬ◶")
	l111111l11_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬ◷")
	l111111l1l_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭◸")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◹"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅึ่ไหฯࠦรโๆส้ࠥ฿ัษ์ࠪ◺"),l11111l1l1_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◻"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡ็ึุ่๊วหࠢ฼ีอ๐ࠧ◼"),l1111ll1ll_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◽"),l1lllll_l1_+l1l111_l1_ (u"ฺ้ࠪ์แศฬࠣวๆ๊วๆࠢสะ๋ฮ๊ࠨ◾"),l111111l11_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◿"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮ๋ࠥำๅี็หฯࠦวอ่ห๎ࠬ☀"),l111111l1l_l1_,511)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ☁"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ☂"),l1l111_l1_ (u"ࠨࠩ☃"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☄"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡล฼้ฬ๊ࠠฤสฯำ๏࠭★"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡤࡰࡵ࡮ࡡࡣࡧࡷࠫ☆"),517)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☇"),l1lllll_l1_+l1l111_l1_ (u"࠭แ่ำึࠤࠥฮไะࠢส่ส์สศฮࠪ☈"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡩ࡯ࡶࡰࡷࡶࡾ࠭☉"),517)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☊"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๋ึูࠠศๆ็฾ฮ࠭☋"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ☌"),517)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☍"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็็าีฺ้ࠣ์แศฬࠣห้฿ๅๅࠩ☎"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳࡬࡫࡮ࡳࡧࠪ☏"),517)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☐"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦำ็หࠣห้หีะษิࠫ☑"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡳࡧ࡯ࡩࡦࡹࡥࡠࡻࡨࡥࡷ࠭☒"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ☓"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭☔"),l1l111_l1_ (u"ࠬ࠭☕"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☖"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊สื๊ࠦ࠭ࠡใ็ฮึࠦๅฮัาࠫ☗"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ☘"),515)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☙"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํอำๆࠢ࠰ࠤๆ๊สาࠢๆห๊๊ࠧ☚"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ☛"),514)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ☜"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ☝"),l1l111_l1_ (u"ࠧࠨ☞"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☟"),l1lllll_l1_+l1l111_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สา่ࠢัิีࠧ☠"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ☡"),515)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☢"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ☣"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ☤"),514)
	return
def l1111111ll_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ☥"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ☦"),l1l111_l1_ (u"ࠩࠪ☧"),headers,l1l111_l1_ (u"ࠪࠫ☨"),l1l111_l1_ (u"ࠫࠬ☩"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ☪"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ☫"),multi_valued_attributes=None)
	block = l1llllll111_l1_.find(l1l111_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺࠧ☬"),attrs={l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭☭"):l1l111_l1_ (u"ࠩࡷࡥ࡬࠭☮")})
	options = block.find_all(l1l111_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠪ☯"))
	for option in options:
		value = option.get(l1l111_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ☰"))
		if not value: continue
		title = option.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ☱"))
			value = value.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ☲"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠨࡷࡽࡵ࡫࠽ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫ☳")+value
		title = title.replace(l1l111_l1_ (u"ࠨไสส๊ฯࠠࠨ☴"),l1l111_l1_ (u"ࠩࠪ☵"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☶"),l1lllll_l1_+title,l1ll1ll_l1_,511)
	return
def l1111l1111_l1_():
	l1lllllll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸࠭☷")
	l11111l11l_l1_ = l1lllllll1l_l1_+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠶ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࠪࡹࡧࡧ࠾ࠩ☸")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☹"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆื้ๅฬะࠠฤึัหฺ࠭☺"),l11111l11l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭☻"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ☼"),l1l111_l1_ (u"ࠪࠫ☽"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☾"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็็าีࠣวูิวึࠢฦฬัี๊ࠨ☿"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵ࡡ࡭ࡲ࡫ࡥࡧ࡫ࡴࠨ♀"),517)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ♁"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦๅู้้ࠫ♂"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡱࡥࡹ࡯࡯࡯ࡣ࡯࡭ࡹࡿࠧ♃"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ♄"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิࠢࠣฮฬื๊ฯࠢส่๊๐ไศัࠪ♅"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡨࡩࡳࡶ࡫ࡣࡾ࡫ࡡࡳࠩ♆"),517)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♇"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิืࠥࠦสศำําࠥอไ้ใสอࠬ♈"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡦࡨࡥࡹ࡮࡟ࡺࡧࡤࡶࠬ♉"),517)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ♊"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ♋"),l1l111_l1_ (u"ࠫࠬ♌"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♍"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦๅฮัาࠫ♎"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ♏"),515)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♐"),l1lllll_l1_+l1l111_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สาࠢๆห๊๊ࠧ♑"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ♒"),514)
	return
def l1llllll1l1_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ♓") in url: index = 0
	elif l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭♔") in url: index = 1
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ♕"),url,l1l111_l1_ (u"ࠧࠨ♖"),headers,l1l111_l1_ (u"ࠨࠩ♗"),l1l111_l1_ (u"ࠩࠪ♘"),l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨ♙"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ♚"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠬࡰࡵ࡮ࡤࡲ࠱ࡹ࡮ࡥࡢࡶࡨࡶࠥࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠧ♛"))
	for block in l1lll1l1_l1_:
		title = block.find_all(l1l111_l1_ (u"࠭ࡡࠨ♜"))[index].text
		l1ll1ll_l1_ = l111l1_l1_+block.find_all(l1l111_l1_ (u"ࠧࡢࠩ♝"))[index].get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭♞"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♟"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♠"))
		if not l1lll1l1_l1_:
			l1111llll1_l1_(l1ll1ll_l1_)
			return
		else:
			title = title.replace(l1l111_l1_ (u"ࠫ็อฦๆหࠣࠫ♡"),l1l111_l1_ (u"ࠬ࠭♢"))
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♣"),l1lllll_l1_+title,l1ll1ll_l1_,512)
	PAGINATION(l1llllll111_l1_,511)
	return
def PAGINATION(l1llllll111_l1_,mode):
	block = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ♤"))
	if block:
		l1ll1l1ll_l1_ = block.find_all(l1l111_l1_ (u"ࠨࡣࠪ♥"))
		l1lllll1lll_l1_ = block.find_all(l1l111_l1_ (u"ࠩ࡯࡭ࠬ♦"))
		l11111llll_l1_ = list(zip(l1ll1l1ll_l1_,l1lllll1lll_l1_))
		l1l111llll_l1_ = -1
		length = len(l11111llll_l1_)
		for l1lll1l1l_l1_,l1llllllll1_l1_ in l11111llll_l1_:
			l1l111llll_l1_ += 1
			l1llllllll1_l1_ = l1llllllll1_l1_[l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴࠩ♧")]
			if l1l111_l1_ (u"ࠫࡺࡴࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠩ♨") in l1llllllll1_l1_ or l1l111_l1_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹ࠭♩") in l1llllllll1_l1_: continue
			l11111111l_l1_ = l1lll1l1l_l1_.text
			l111lllll_l1_ = l111l1_l1_+l1lll1l1l_l1_.get(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠫ♪"))
			if PY2:
				l11111111l_l1_ = l11111111l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♫"))
				l111lllll_l1_ = l111lllll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭♬"))
			if   l1l111llll_l1_==0: l11111111l_l1_ = l1l111_l1_ (u"ࠩฦ์้๏ࠧ♭")
			elif l1l111llll_l1_==1: l11111111l_l1_ = l1l111_l1_ (u"ࠪืฬฮโสࠩ♮")
			elif l1l111llll_l1_==length-2: l11111111l_l1_ = l1l111_l1_ (u"้ࠫออใหࠪ♯")
			elif l1l111llll_l1_==length-1: l11111111l_l1_ = l1l111_l1_ (u"ࠬษฮ๋ำฬࠫ♰")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♱"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭♲")+l11111111l_l1_,l111lllll_l1_,mode)
	return
def l1111llll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ♳"),url,l1l111_l1_ (u"ࠩࠪ♴"),headers,l1l111_l1_ (u"ࠪࠫ♵"),l1l111_l1_ (u"ࠫࠬ♶"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠱࠮࠳ࡶࡸࠬ♷"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ♸"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠧࡳࡱࡺࠫ♹"))
	items,first = [],True
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠱ࡼࡸࡡࡱࡲࡨࡶࠬ♺")): continue
		if first: first = False ; continue
		l111111ll1_l1_ = []
		l1lllll1ll1_l1_ = block.find_all(class_=[l1l111_l1_ (u"ࠩࡦࡩࡳࡹ࡯ࡳࡵ࡫࡭ࡵࠦࡲࡦࡦࠪ♻"),l1l111_l1_ (u"ࠪࡧࡪࡴࡳࡰࡴࡶ࡬࡮ࡶࠠࡱࡷࡵࡴࡱ࡫ࠧ♼")])
		for l111111111_l1_ in l1lllll1ll1_l1_:
			l1111lllll_l1_ = l111111111_l1_.find_all(l1l111_l1_ (u"ࠫࡱ࡯ࠧ♽"))[1].text
			if PY2:
				l1111lllll_l1_ = l1111lllll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♾"))
			l111111ll1_l1_.append(l1111lllll_l1_)
		if not l11111l_l1_(l1ll1_l1_,l1l111_l1_ (u"࠭ࠧ♿"),l111111ll1_l1_,False):
			l11l_l1_ = block.find(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠫ⚀")).get(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ⚁"))
			title = block.find(l1l111_l1_ (u"ࠩ࡫࠷ࠬ⚂"))
			name = title.find(l1l111_l1_ (u"ࠪࡥࠬ⚃")).text
			l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠫࡦ࠭⚄")).get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ⚅"))
			l1111l1l1l_l1_ = block.find(class_=l1l111_l1_ (u"࠭࡮ࡰ࠯ࡰࡥࡷ࡭ࡩ࡯ࠩ⚆"))
			l11111l111_l1_ = block.find(class_=l1l111_l1_ (u"ࠧ࡭ࡧࡪࡩࡳࡪࠧ⚇"))
			if l1111l1l1l_l1_: l1111l1l1l_l1_ = l1111l1l1l_l1_.text
			if l11111l111_l1_: l11111l111_l1_ = l11111l111_l1_.text
			if PY2:
				l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚈"))
				name = name.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚉"))
				l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚊"))
				if l1111l1l1l_l1_: l1111l1l1l_l1_ = l1111l1l1l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚋"))
			l1llllll1ll_l1_ = {}
			if l11111l111_l1_: l1llllll1ll_l1_[l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡶࠫ⚌")] = l11111l111_l1_
			if l1111l1l1l_l1_:
				l1111l1l1l_l1_ = l1111l1l1l_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ⚍"),l1l111_l1_ (u"ࠧࠡ࠰࠱ࠤࠬ⚎"))
				l1llllll1ll_l1_[l1l111_l1_ (u"ࠨࡲ࡯ࡳࡹ࠭⚏")] = l1111l1l1l_l1_.replace(l1l111_l1_ (u"ࠩ࠱࠲࠳อโาลࠣห้๋า๋ัࠪ⚐"),l1l111_l1_ (u"ࠪࠫ⚑"))
			if l1l111_l1_ (u"ࠫ࠴ࡽ࡯ࡳ࡭࠲ࠫ⚒") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚓"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"࠭ࠧ⚔"),name,l1l111_l1_ (u"ࠧࠨ⚕"),l1llllll1ll_l1_)
			elif l1l111_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⚖") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⚗"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠪࠫ⚘"),name,l1l111_l1_ (u"ࠫࠬ⚙"),l1llllll1ll_l1_)
	PAGINATION(l1llllll111_l1_,512)
	return
def l1111lll1l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⚚"),url,l1l111_l1_ (u"࠭ࠧ⚛"),headers,l1l111_l1_ (u"ࠧࠨ⚜"),l1l111_l1_ (u"ࠨࠩ⚝"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠶࠲࠷ࡳࡵࠩ⚞"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ⚟"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(l1l111_l1_ (u"ࠫࡱ࡯ࠧ⚠"))
	names,items = [],[]
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠮ࡹࡵࡥࡵࡶࡥࡳࠩ⚡")): continue
		if not block.find(class_=[l1l111_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠨ⚢"),l1l111_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠢࡷࡩࡽࡺ࠭ࡤࡧࡱࡸࡪࡸࠧ⚣")]): continue
		if block.find(class_=l1l111_l1_ (u"ࠨࡪ࡬ࡨࡪ࠭⚤")): continue
		title = block.find(class_=[l1l111_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠫ⚥"),l1l111_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠥࡺࡥࡹࡶ࠰ࡧࡪࡴࡴࡦࡴࠪ⚦")])
		name = title.find(l1l111_l1_ (u"ࠫࡦ࠭⚧")).text
		if name in names: continue
		names.append(name)
		l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠬࡧࠧ⚨")).get(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠫ⚩"))
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ⚪") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⚫")).get(l1l111_l1_ (u"ࠩࡶࡶࡨ࠭⚬"))
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⚭") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠨ⚮")).get(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ⚯"))
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ⚰") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠫ⚱")).get(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ⚲"))
		else: l11l_l1_ = block.find(l1l111_l1_ (u"ࠩ࡬ࡱ࡬࠭⚳")).get(l1l111_l1_ (u"ࠪࡷࡷࡩࠧ⚴"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚵"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚶"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚷"))
		name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ⚸"))
		items.append((name,l1ll1ll_l1_,l11l_l1_))
	if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⚹") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1ll1ll_l1_,l11l_l1_ in items:
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ⚺") in url: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⚻"),l1lllll_l1_+name,l1ll1ll_l1_,522,l11l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭⚼") in url: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚽"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"࠭ࠧ⚾"),name)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚿"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠨࠩ⛀"),name)
	return
def l11111lll1_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠩส่ส฿ไศ่ࠪ⛁"),l1l111_l1_ (u"ࠪࠫ⛂")).replace(l1l111_l1_ (u"้ࠫ็๊ๅ็ࠪ⛃"),l1l111_l1_ (u"ࠬ࠭⛄")).replace(l1l111_l1_ (u"࠭วๅำึ้๏࠭⛅"),l1l111_l1_ (u"ࠧࠨ⛆"))
	text = text.replace(l1l111_l1_ (u"ࠨว฼่ฬ์ࠧ⛇"),l1l111_l1_ (u"ࠩࠪ⛈")).replace(l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ⛉"),l1l111_l1_ (u"ࠫࠬ⛊")).replace(l1l111_l1_ (u"ࠬอไษำ๋้ํ࠭⛋"),l1l111_l1_ (u"࠭ࠧ⛌"))
	text = text.replace(l1l111_l1_ (u"ࠧศๆอุํ๐โ๋ࠩ⛍"),l1l111_l1_ (u"ࠨࠩ⛎")).replace(l1l111_l1_ (u"ࠩ็ุ้๊ำๅࠩ⛏"),l1l111_l1_ (u"ࠪࠫ⛐")).replace(l1l111_l1_ (u"ู๊ࠫไิๆࠪ⛑"),l1l111_l1_ (u"ࠬ࠭⛒"))
	text = text.replace(l1l111_l1_ (u"࠭࠺ࠨ⛓"),l1l111_l1_ (u"ࠧࠨ⛔")).replace(l1l111_l1_ (u"ࠨࠫࠪ⛕"),l1l111_l1_ (u"ࠩࠪ⛖")).replace(l1l111_l1_ (u"ࠪࠬࠬ⛗"),l1l111_l1_ (u"ࠫࠬ⛘")).replace(l1l111_l1_ (u"ࠬ࠲ࠧ⛙"),l1l111_l1_ (u"࠭ࠧ⛚"))
	text = text.replace(l1l111_l1_ (u"ࠧࡠࠩ⛛"),l1l111_l1_ (u"ࠨࠩ⛜")).replace(l1l111_l1_ (u"ࠩ࠾ࠫ⛝"),l1l111_l1_ (u"ࠪࠫ⛞")).replace(l1l111_l1_ (u"ࠫ࠲࠭⛟"),l1l111_l1_ (u"ࠬ࠭⛠")).replace(l1l111_l1_ (u"࠭࠮ࠨ⛡"),l1l111_l1_ (u"ࠧࠨ⛢"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡞ࠪࠫ⛣"),l1l111_l1_ (u"ࠩࠪ⛤")).replace(l1l111_l1_ (u"ࠪࡠࠧ࠭⛥"),l1l111_l1_ (u"ࠫࠬ⛦"))
	text = text.replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ⛧"),l1l111_l1_ (u"࠭ࠠࠨ⛨")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ⛩"),l1l111_l1_ (u"ࠨࠢࠪ⛪")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ⛫"),l1l111_l1_ (u"ࠪࠤࠬ⛬"))
	text = text.strip(l1l111_l1_ (u"ࠫࠥ࠭⛭"))
	l1111ll111_l1_ = text.count(l1l111_l1_ (u"ࠬࠦࠧ⛮"))+1
	if l1111ll111_l1_==1:
		l1lllllllll_l1_(text)
		return
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⛯"),l1lllll_l1_+l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃࠠไๆ่หฯࠦไๅสะฯࠥࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⛰"),l1l111_l1_ (u"ࠨࠩ⛱"),9999)
	l11111ll11_l1_ = text.split(l1l111_l1_ (u"ࠩࠣࠫ⛲"))
	l1111ll1l1_l1_ = pow(2,l1111ll111_l1_)
	l111l1111_l1_ = []
	def l11111l1ll_l1_(a,b):
		if a==l1l111_l1_ (u"ࠪ࠵ࠬ⛳"): return b
		return l1l111_l1_ (u"ࠫࠬ⛴")
	for l1l111llll_l1_ in range(l1111ll1l1_l1_,0,-1):
		l1111l11l1_l1_ = list(l1111ll111_l1_*l1l111_l1_ (u"ࠬ࠶ࠧ⛵")+bin(l1l111llll_l1_)[2:])[-l1111ll111_l1_:]
		l1111l11l1_l1_ = reversed(l1111l11l1_l1_)
		result = map(l11111l1ll_l1_,l1111l11l1_l1_,l11111ll11_l1_)
		title = l1l111_l1_ (u"࠭ࠠࠨ⛶").join(filter(None,result))
		if PY2: l1lllllll_l1_ = title.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⛷"))
		else: l1lllllll_l1_ = title
		if len(l1lllllll_l1_)>2 and title not in l111l1111_l1_:
			l111l1111_l1_.append(title)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⛸"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ⛹"),523,l1l111_l1_ (u"ࠪࠫ⛺"),l1l111_l1_ (u"ࠫࠬ⛻"),title)
	return
def l1lllllllll_l1_(l1111ll11l_l1_):
	if PY2:
		l1111ll11l_l1_ = l1111ll11l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⛼"))
		import arabic_reshaper
		l1111ll11l_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1111ll11l_l1_)
		l1111ll11l_l1_ = bidi.algorithm.get_display(l1111ll11l_l1_)
	import l1111l1l11_l1_
	l1111ll11l_l1_ = l1llll1_l1_(default=l1111ll11l_l1_)
	l1111l1l11_l1_.l1lll1_l1_(l1111ll11l_l1_)
	return
def l1111l1ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⛽"),url,l1l111_l1_ (u"ࠧࠨ⛾"),headers,l1l111_l1_ (u"ࠨࠩ⛿"),l1l111_l1_ (u"ࠩࠪ✀"),l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡏࡎࡅࡇ࡛ࡉࡘࡥࡌࡊࡕࡗࡗ࠲࠷ࡳࡵࠩ✁"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ✂"),multi_valued_attributes=None)
	block = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠬࡲࡩࡴࡶ࠰ࡷࡪࡶࡡࡳࡣࡷࡳࡷࠦ࡬ࡪࡵࡷ࠱ࡹ࡯ࡴ࡭ࡧࠪ✃"))
	l11l11_l1_ = block.find_all(l1l111_l1_ (u"࠭ࡡࠨ✄"))
	items = []
	for title in l11l11_l1_:
		name = title.text
		l1ll1ll_l1_ = l111l1_l1_+title.get(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬ✅"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭✆"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ✇"))
		if l1l111_l1_ (u"ࠪࠧࠬ✈") not in l1ll1ll_l1_: items.append((name,l1ll1ll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1ll1ll_l1_ = item
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✉"),l1lllll_l1_+name,l1ll1ll_l1_,518)
	return
def l1111l1lll_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ✊"),url,l1l111_l1_ (u"࠭ࠧ✋"),headers,l1l111_l1_ (u"ࠧࠨ✌"),l1l111_l1_ (u"ࠨࠩ✍"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡎࡔࡄࡆ࡚ࡈࡗࡤ࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ✎"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ✏"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠫࡪࡾࡰࡢࡰࡧࠫ✐")).find_all(l1l111_l1_ (u"ࠬࡺࡲࠨ✑"))
	for block in l1lll1l1_l1_:
		l11111ll1l_l1_ = block.find_all(l1l111_l1_ (u"࠭ࡡࠨ✒"))
		if not l11111ll1l_l1_: continue
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠫ✓")).get(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ✔"))
		name = l11111ll1l_l1_[1].text
		l1ll1ll_l1_ = l111l1_l1_+l11111ll1l_l1_[1].get(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ✕"))
		l11111l111_l1_ = block.find(class_=l1l111_l1_ (u"ࠪࡰࡪ࡭ࡥ࡯ࡦࠪ✖"))
		if l11111l111_l1_: l11111l111_l1_ = l11111l111_l1_.text
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✗"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✘"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ✙"))
		l1llllll1ll_l1_ = {}
		if l11111l111_l1_: l1llllll1ll_l1_[l1l111_l1_ (u"ࠧࡴࡶࡤࡶࡸ࠭✚")] = l11111l111_l1_
		if l1l111_l1_ (u"ࠨ࠱ࡺࡳࡷࡱ࠯ࠨ✛") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ✜"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠪࠫ✝"),name,l1l111_l1_ (u"ࠫࠬ✞"),l1llllll1ll_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ✟") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✠"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠧࠨ✡"),name,l1l111_l1_ (u"ࠨࠩ✢"),l1llllll1ll_l1_)
	PAGINATION(l1llllll111_l1_,518)
	return
def l1111l111l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭✣"),url,l1l111_l1_ (u"ࠪࠫ✤"),headers,l1l111_l1_ (u"ࠫࠬ✥"),l1l111_l1_ (u"ࠬ࠭✦"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡘࡌࡈࡊࡕࡓࡠࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫ✧"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ✨"),multi_valued_attributes=None)
	l11l11_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯࠯ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࡰ࡮ࡴࡥࠨ✩"))
	l1ll_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠩࡥࡹࡹࡺ࡯࡯ࠢࡪࡶࡪ࡫࡮ࠡࡵࡰࡥࡱࡲࠠࡳ࡫ࡪ࡬ࡹ࠭✪"))
	items = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in items:
		title = title.text
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.get(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ✫"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✬"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✭"))
		title = title.replace(l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ✮"),l1l111_l1_ (u"ࠧࠡࠩ✯")).replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠬ✰"),l1l111_l1_ (u"ࠩࠣࠫ✱")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭✲"),l1l111_l1_ (u"ࠫࠥ࠭✳"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✴"),l1lllll_l1_+title,l1ll1ll_l1_,521)
	return
def l1llllll11l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ✵"),url,l1l111_l1_ (u"ࠧࠨ✶"),headers,l1l111_l1_ (u"ࠨࠩ✷"),l1l111_l1_ (u"ࠩࠪ✸"),l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡜ࡉࡅࡇࡒࡗࡤ࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ✹"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ✺"),multi_valued_attributes=None)
	l111l11111_l1_ = l1llllll111_l1_.find(class_=l1l111_l1_ (u"ࠬࡲࡡࡳࡩࡨ࠱ࡧࡲ࡯ࡤ࡭࠰࡫ࡷ࡯ࡤ࠮࠶ࠣࡱࡪࡪࡩࡶ࡯࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠵ࠢࡶࡱࡦࡲ࡬࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠸ࠧ✻"))
	l1lll1l1_l1_ = l111l11111_l1_.find_all(l1l111_l1_ (u"࠭࡬ࡪࠩ✼"))
	for block in l1lll1l1_l1_:
		title = block.find(class_=l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭✽")).text
		l1ll1ll_l1_ = l111l1_l1_+block.find(l1l111_l1_ (u"ࠨࡣࠪ✾")).get(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ✿"))
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠧ❀")).get(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭❁"))
		l1l1lll111_l1_ = block.find(class_=l1l111_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ❂")).text
		if PY2:
			title = title.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ❃"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ❄"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭❅"))
			l1l1lll111_l1_ = l1l1lll111_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ❆"))
		l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭❇"),l1l111_l1_ (u"ࠫࠬ❈")).strip(l1l111_l1_ (u"ࠬࠦࠧ❉"))
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ❊"),l1lllll_l1_+title,l1ll1ll_l1_,522,l11l_l1_,l1l1lll111_l1_)
	PAGINATION(l1llllll111_l1_,521)
	return
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ❋"),url,l1l111_l1_ (u"ࠨࠩ❌"),headers,l1l111_l1_ (u"ࠩࠪ❍"),l1l111_l1_ (u"ࠪࠫ❎"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ❏"))
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ❐"),multi_valued_attributes=None)
	l1ll1ll_l1_ = l1llllll111_l1_.find(class_=l1l111_l1_ (u"࠭ࡦ࡭ࡧࡻ࠱ࡻ࡯ࡤࡦࡱࠪ❑")).find(l1l111_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠧ❒")).get(l1l111_l1_ (u"ࠨࡵࡵࡧࠬ❓"))
	if PY2: l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ❔"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ❕"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ❖"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭❗"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ❘"),l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ❙"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡂࡵࡂ࠭❚")+search
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭❛"),url,l1l111_l1_ (u"ࠪࠫ❜"),headers,l1l111_l1_ (u"ࠫࠬ❝"),l1l111_l1_ (u"ࠬ࠭❞"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ❟"))
	if not response.succeeded:
		l11111l11l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡠࡧࡱࡸ࡮ࡺࡹ࠰ࡁࡴࡁࠬ❠")+search+l1l111_l1_ (u"ࠨࠨࡨࡲࡹ࡯ࡴࡺ࠿ࡺࡳࡷࡱࠧ❡")
		l111lllll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡢࡩࡳࡺࡩࡵࡻ࠲ࡃࡶࡃࠧ❢")+search+l1l111_l1_ (u"ࠪࠪࡪࡴࡴࡪࡶࡼࡁࡵ࡫ࡲࡴࡱࡱࠫ❣")
		l111111lll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡤ࡫࡮ࡵ࡫ࡷࡽ࠴ࡅࡱ࠾ࠩ❤")+search+l1l111_l1_ (u"ࠬࠬࡥ࡯ࡶ࡬ࡸࡾࡃࡶࡪࡦࡨࡳࠬ❥")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❦"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ฾์ࠠฤ฻่ห้࠭❧"),l11111l11l_l1_,513,l1l111_l1_ (u"ࠨࠩ❨"),search)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❩"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัฺ่ࠠࠣวูิวึࠩ❪"),l111lllll_l1_,513,l1l111_l1_ (u"ࠫࠬ❫"),search)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❬"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣ฽๋ࠦแ๋ัํ์์อสࠨ❭"),l111111lll_l1_,513,l1l111_l1_ (u"ࠧࠨ❮"),search)
		return
	html = response.content
	l1llllll111_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭❯"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1llllll111_l1_.find_all(class_=l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰ࠰ࡸ࡮ࡺ࡬ࡦࠢ࡯ࡩ࡫ࡺࠧ❰"))
	for block in l1lll1l1_l1_:
		title = block.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ❱"))
		title = title.split(l1l111_l1_ (u"ࠫ࠭࠭❲"),1)[0].strip(l1l111_l1_ (u"ࠬࠦࠧ❳"))
		if   l1l111_l1_ (u"࠭รฺ็ส่ࠬ❴") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ❵"),l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡺࡳࡷࡱ࠯ࠨ❶"))
		elif l1l111_l1_ (u"ࠩฦุำอีࠨ❷") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ❸"),l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭❹"))
		elif l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠧ❺") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ❻"),l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ❼"))
		else: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❽"),l1lllll_l1_+title,l1ll1ll_l1_,513)
	return
def l1lllllll11_l1_(url,text):
	global l1l11111_l1_,l1l11lll_l1_
	if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭❾") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ❿"),l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ➀"),l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ➁")]
		l1l11lll_l1_ = [l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ➂"),l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬ➃"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ➄")]
	elif l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ➅") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ➆"),l1l111_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ➇"),l1l111_l1_ (u"ࠬࡺࡹࡱࡧࠪ➈")]
		l1l11lll_l1_ = [l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ➉"),l1l111_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ➊"),l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠭➋")]
	l1l1ll1l_l1_(url,text)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭➌"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ➍"),url,l1l111_l1_ (u"ࠫࠬ➎"),headers,l1l111_l1_ (u"ࠬ࠭➏"),l1l111_l1_ (u"࠭ࠧ➐"),l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ➑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨࡲࡶࡲࠦࡡࡤࡶ࡬ࡳࡳࡃࠢ࠰ࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ➒"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶࠣࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ➓"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ➔"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ➕"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ➖"))
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ➗"),l1l111_l1_ (u"ࠧ࠰ࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠩࠫ➘"))
	return url
def l11l1l11ll_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭➙"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭➚")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠪࡃࠬ➛") in url: url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ➜"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ➝"),1)
	if filter==l1l111_l1_ (u"࠭ࠧ➞"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠧࠨ➟"),l1l111_l1_ (u"ࠨࠩ➠")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭➡"))
	if type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭➢"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠫࡂ࠭➣") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠬࡃࠧ➤") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ➥")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪ➦")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ➧")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬ➨")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬ➩"))+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ➪")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ➫"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ➬"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ➭")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ➮"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ➯"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠪࠫ➰"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ➱"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠬ࠭➲"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ➳")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➴"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ➵"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➶"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ➷")+l11l1l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ➸"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ➹"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ➺"),l1l111_l1_ (u"ࠧࠨ➻"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠨ࠯࠰ࠫ➼"),l1l111_l1_ (u"ࠩࠪ➽"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠪࡁࠬ➾") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ➿"):
			if l1l111ll_l1_ not in l1l11111_l1_: continue
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1111llll1_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⟀")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟁"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ⟂"),l1lllll1_l1_,511)
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⟃"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩ⟄"),l1lllll1_l1_,515,l1l111_l1_ (u"ࠪࠫ⟅"),l1l111_l1_ (u"ࠫࠬ⟆"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ⟇"):
			if l1l111ll_l1_ not in l1l11lll_l1_: continue
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ⟈")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪ⟉")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ⟊")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ⟋")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ⟌")+l1l1ll11_l1_
			if   name==l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ⟍"): name = l1l111_l1_ (u"ࠬอไ็๊฼ࠫ⟎")
			elif name==l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⟏"): name = l1l111_l1_ (u"ࠧศๆ฼้้࠭⟐")
			elif name==l1l111_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ⟑"): name = l1l111_l1_ (u"ࠩส่้เษࠨ⟒")
			elif name==l1l111_l1_ (u"ࠪࡽࡪࡧࡲࠨ⟓"): name = l1l111_l1_ (u"ࠫฬ๊ำ็หࠪ⟔")
			elif name==l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ⟕"): name = l1l111_l1_ (u"࠭วๅ็๋ื๊࠭⟖")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⟗"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ู࠻ࠢࠪ⟘")+name,l1lllll1_l1_,514,l1l111_l1_ (u"ࠩࠪ⟙"),l1l111_l1_ (u"ࠪࠫ⟚"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤศิั๊ࠩ⟛") in option: continue
			if l1l111_l1_ (u"ࠬอไไๆࠪ⟜") in option: continue
			if l1l111_l1_ (u"࠭วๅๆ฽อࠬ⟝") in option: continue
			option = option.replace(l1l111_l1_ (u"ࠧใษษ้ฮࠦࠧ⟞"),l1l111_l1_ (u"ࠨࠩ⟟"))
			if   name==l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ⟠"): name = l1l111_l1_ (u"ࠪห้์ฺ่ࠩ⟡")
			elif name==l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⟢"): name = l1l111_l1_ (u"ࠬอไฺ็็ࠫ⟣")
			elif name==l1l111_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ⟤"): name = l1l111_l1_ (u"ࠧศๆ็฾ฮ࠭⟥")
			elif name==l1l111_l1_ (u"ࠨࡻࡨࡥࡷ࠭⟦"): name = l1l111_l1_ (u"ࠩสุ่์ษࠨ⟧")
			elif name==l1l111_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ⟨"): name = l1l111_l1_ (u"ࠫฬ๊ๅ้ี่ࠫ⟩")
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ⟪")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨ⟫")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ⟬")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ⟭")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭⟮")+l1l1ll11_l1_
			if name: title = option+l1l111_l1_ (u"ࠪࠤ࠿࠭⟯")+name
			else: title = option
			if type==l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ⟰"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟱"),l1lllll_l1_+title,url,514,l1l111_l1_ (u"࠭ࠧ⟲"),l1l111_l1_ (u"ࠧࠨ⟳"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⟴") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠩࡀࠫ⟵") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11ll_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟶"),l1lllll_l1_+title,l1llllll_l1_,511)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟷"),l1lllll_l1_+title,url,515,l1l111_l1_ (u"ࠬ࠭⟸"),l1l111_l1_ (u"࠭ࠧ⟹"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠧ࠾ࠨࠪ⟺"),l1l111_l1_ (u"ࠨ࠿࠳ࠪࠬ⟻"))
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫ⟼"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬ⟽") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭⟾"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ⟿"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧ⠀")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ⠁")
		if l1l111_l1_ (u"ࠨࠧࠪ⠂") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ⠃") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ⠄"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ⠅")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⠆") and value!=l1l111_l1_ (u"࠭࠰ࠨ⠇"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ⠈")+key+l1l111_l1_ (u"ࠨ࠿ࠪ⠉")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⠊"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ⠋")+key+l1l111_l1_ (u"ࠫࡂ࠭⠌")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ⠍"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ⠎"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠧ࠾࠲ࠪ⠏"),l1l111_l1_ (u"ࠨ࠿ࠪ⠐"))
	return l1l1l111_l1_
l1l11111_l1_ = []
l1l11lll_l1_ = []
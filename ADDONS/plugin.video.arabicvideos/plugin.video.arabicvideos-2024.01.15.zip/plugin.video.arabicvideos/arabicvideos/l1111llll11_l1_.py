# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭娮")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡗ࡚ࡋࡥࠧ娯")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ娰")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ娱"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ娲"),l1l111_l1_ (u"ࠬ࠭娳"),l1l111_l1_ (u"࠭ࠧ娴"),l1l111_l1_ (u"ࠧࠨ娵"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ娶"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娷"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ娸"),l1l111_l1_ (u"ࠫࠬ娹"),469,l1l111_l1_ (u"ࠬ࠭娺"),l1l111_l1_ (u"࠭ࠧ娻"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ娼"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭娽"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ娾"),l1l111_l1_ (u"ࠪࠫ娿"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳࡥ࡯ࡷ࠰ࡦࡹࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ婀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ婁"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ婂") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩ婃"): title = l1l111_l1_ (u"ࠨฮา๎ิࠦอๅไสฮࠥะ๊โ์ࠣๅฬ์ࠧ婄")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婅"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ婆")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬ婇")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ婈"),url,l1l111_l1_ (u"࠭ࠧ婉"),l1l111_l1_ (u"ࠧࠨ婊"),l1l111_l1_ (u"ࠨࠩ婋"),l1l111_l1_ (u"ࠩࠪ婌"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭婍"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥ࠯ࡷ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡪࡴࡵࡴࡦࡴࠥࠫ婎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡶ࡯ࡥࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭婏"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭婐"),l1l111_l1_ (u"ࠧโ์็้ࠬ婑"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ婒"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ婓"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ婔"),l1l111_l1_ (u"ࠫ์ีวโࠩ婕"),l1l111_l1_ (u"๋ࠬศศำสอࠬ婖"),l1l111_l1_ (u"ู࠭าุࠪ婗"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ婘"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ婙")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ婚") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭婛"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ婜"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬ婝") in title:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ婞") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ婟"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ婠"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ婡"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ婢"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ婣"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ婤"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠢ婥"): continue
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ婦") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠨࠩ婧"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婨"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ婩")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ婪"),url,l1l111_l1_ (u"ࠬ࠭婫"),l1l111_l1_ (u"࠭ࠧ婬"),l1l111_l1_ (u"ࠧࠨ婭"),l1l111_l1_ (u"ࠨࠩ婮"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ婯"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ婰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ婱"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ婲") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ婳"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ婴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ婵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ婶"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠥࠦ婷"): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ婸") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠬ࠭婹"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婺"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭婻")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ婼"),url,l1l111_l1_ (u"ࠩࠪ婽"),l1l111_l1_ (u"ࠪࠫ婾"),l1l111_l1_ (u"ࠫࠬ婿"),l1l111_l1_ (u"ࠬ࠭媀"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ媁"))
	html = response.content
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡕࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭媂"),html,re.DOTALL)
	if l11l1l11l1_l1_:
		l11l1l11l1_l1_ = l11l1l11l1_l1_[0]
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭媃") not in l11l1l11l1_l1_:
			if l1l111_l1_ (u"ࠩ࠲࠳ࠬ媄") in l11l1l11l1_l1_: l11l1l11l1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ媅")+l11l1l11l1_l1_
			else: l11l1l11l1_l1_ = l111l1_l1_+l11l1l11l1_l1_
		l11l1l11l1_l1_ = l11l1l11l1_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ媆")
		l1llll_l1_.append(l11l1l11l1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡨ࠱࠶࠼ࡥࡩ࡫ࡵࡲࡦࠪ࠱࠮ࡄ࠯ࡳ࡮ࡣ࡯ࡰ࠳࠰࠿ࠣࡘ࡬ࡨࡪࡵࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡐ࡭ࡣࡼࠦࠬ媇"),html,re.DOTALL)
	if l11llll_l1_:
		l11l1l1l1l11_l1_,l11l1l1l1l1l_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ媈"),l11l1l1l1l11_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡴࡧࡷ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ媉"),l11l1l1l1l1l_l1_,re.DOTALL)
		l11l1l1l11ll_l1_ = zip(names,l1ll_l1_)
		for name,l1l1111ll111_l1_ in l11l1l1l11ll_l1_:
			l1l1111ll111_l1_ = l1l1111ll111_l1_[2:]
			if PY2: l1l1111ll111_l1_ = l1l1111ll111_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭媊"))
			l1l1111ll111_l1_ = base64.b64decode(l1l1111ll111_l1_)
			if PY3: l1l1111ll111_l1_ = l1l1111ll111_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ媋"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ媌"),l1l1111ll111_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ媍") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠬ࠵࠯ࠨ媎") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ媏")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ媐")+name+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ媑")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ媒"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"ࠪࠤࠬ媓") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ媔"),l1l111_l1_ (u"ࠬ࠭媕"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬ媖"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦวๅสะฯࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽๊ࠥวࠡ์฼ู้้ࠦ็ัࠣ฻้ฮࠠฤๅฮี๋ࠥๆࠡๅ็้ฮ่ࠦศฯาอࠥ࠴࠮࠯ࠢํีั๏ࠠศๆหัะูࠦ็ࠢๆ่๊ฯ้ࠠษะำฮࠦแใูࠪ媗"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡴ࠳ࠬ媘")+search+l1l111_l1_ (u"ࠩ࠲ࠫ媙")
	l1lll11_l1_(url)
	return
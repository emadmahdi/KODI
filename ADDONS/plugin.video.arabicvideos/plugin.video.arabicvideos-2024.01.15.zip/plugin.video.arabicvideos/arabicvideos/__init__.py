# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l111l1_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡍࡓࡏࡔࠨ揟")
l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ揠"),l1l111_l1_ (u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠬ握"))
l1lll11l11l_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
l1lll1ll111l_l1_ = int(mode)
l1llllll111l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ揢"))
l1llllll111l_l1_ = l1llllll111l_l1_.replace(ltr,l1l111_l1_ (u"ࠧࠨ揣")).replace(rtl,l1l111_l1_ (u"ࠨࠩ揤"))
if l1lll1ll111l_l1_==260: message = l1l111_l1_ (u"ࠩࠣࠤࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠ࡜ࠢࠪ揥")+l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡍࡲࡨ࡮ࡀࠠ࡜ࠢࠪ揦")+l1l1l11ll11_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ揧")
else:
	l11l1111lll1_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ揨"),l1l111_l1_ (u"࠭ࠧ揩")).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ揪"),l1l111_l1_ (u"ࠨࠩ揫"))
	l11l1111lll1_l1_ = l11l1111lll1_l1_.replace(l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ揬"),l1l111_l1_ (u"ࠪࠫ揭")).strip(l1l111_l1_ (u"ࠫࠥ࠭揮"))
	l11l1111lll1_l1_ = l11l1111lll1_l1_.replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ揯"),l1l111_l1_ (u"࠭ࠠࠨ揰")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ揱"),l1l111_l1_ (u"ࠨࠢࠪ揲")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ揳"),l1l111_l1_ (u"ࠪࠤࠬ援"))
	message = l1l111_l1_ (u"ࠫࠥࠦࠠࡍࡣࡥࡩࡱࡀࠠ࡜ࠢࠪ揵")+l1llllll111l_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡑࡴࡪࡥ࠻ࠢ࡞ࠤࠬ揶")+mode+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭揷")+l11l1111lll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ揸")
l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ揹"),l11lllll1l_l1_(l1ll1_l1_)+message)
l1lll1l111ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭揺"))
l111ll1l11l_l1_ = False if l1lll1l111ll_l1_==l1l11l1l1l1_l1_ else True
if not l111ll1l11l_l1_ and l1lll1ll111l_l1_ in [235,715]:
	l1l1lll11l1l_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ揻")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷࠩ揼") if l1lll1ll111l_l1_==235 else l1l111_l1_ (u"ࠬࡳ࠳ࡶࠩ揽")
	l11ll1l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࠪ揾")+l1ll1_l1_+l1l111_l1_ (u"ࠧ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ揿")+l1l1lll11l1l_l1_)
	l11lll1lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࠬ搀")+l1ll1_l1_+l1l111_l1_ (u"ࠩ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬ搁")+l1l1lll11l1l_l1_)
	if l11ll1l1ll_l1_ or l11lll1lll_l1_:
		url += l1l111_l1_ (u"ࠪࢀࠬ搂")
		if l11ll1l1ll_l1_: url += l1l111_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ搃")+l11ll1l1ll_l1_
		if l11lll1lll_l1_: url += l1l111_l1_ (u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ搄")+l11lll1lll_l1_
		url = url.replace(l1l111_l1_ (u"࠭ࡼࠧࠩ搅"),l1l111_l1_ (u"ࠧࡽࠩ搆"))
	l11l11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࠬ搇")+l1ll1_l1_+l1l111_l1_ (u"ࠩ࠱ࡷࡪࡸࡶࡦࡴࡢࠫ搈")+l1l1lll11l1l_l1_)
	if l11l11ll1l_l1_:
		l11l1111llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭搉"),url,re.DOTALL)
		url = url.replace(l11l1111llll_l1_[0],l11l11ll1l_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll1ll11l_l1_,l1111lll1l1_l1_,l1lll1llllll_l1_
	l111l1ll1ll_l1_ = l1l111_l1_ (u"ࠫࠬ搊")
	l11ll1ll11l_l1_(l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ搋"))
	try: l1111lll1l1_l1_(l1lll11l11l_l1_,l1llllll111l_l1_)
	except Exception as error: l111l1ll1ll_l1_ = traceback.format_exc()
	l1lll1llllll_l1_(l111l1ll1ll_l1_)
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ妏")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡐࡠࠩ妐")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠫ妑"),l1l111_l1_ (u"ࠬฮหࠡ็หหูืࠧ妒")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ妓"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ妔"),l1l111_l1_ (u"ࠨࠩ妕"),l1l111_l1_ (u"ࠩࠪ妖"),l1l111_l1_ (u"ࠪࠫ妗"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ妘"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ妙"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"࠭࠯ࠨ妚"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ妛"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妜"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ妝"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠪࠫ妞"),l1l111_l1_ (u"ࠫࠬ妟"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ妠"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ妡"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ妢"),l1l111_l1_ (u"ࠨࠩ妣"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妤"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ妥")+l1lllll_l1_+l1l111_l1_ (u"ࠫศำฯฬࠢส่๊๎วื์฼ࠫ妦"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪࠤࡰࡽࡆࡩࡣࡰࡷࡱࡸࠧ࠭妧"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ妨"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ妩"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妪"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ妫")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l11l1l1ll111_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ妬"),url,l1l111_l1_ (u"ࠫࠬ妭"),l1l111_l1_ (u"ࠬ࠭妮"),l1l111_l1_ (u"࠭ࠧ妯"),l1l111_l1_ (u"ࠧࠨ妰"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ妱"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡴࡹࡴࠩ࠰࠭ࡃ࠮ࠨࡦࡰࡱࡷࡩࡷࠨࠧ妲"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ妳"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ妴"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ妵"),l1l111_l1_ (u"࠭ว฻่ํอࠬ妶"),l1l111_l1_ (u"ࠧฤ฼้๎ฮ࠭妷"),l1l111_l1_ (u"ࠨๅ็๎อ࠭妸"),l1l111_l1_ (u"ࠩส฽้อๆࠨ妹"),l1l111_l1_ (u"๋ࠪิอแࠨ妺"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ妻"),l1l111_l1_ (u"ࠬ฿ัืࠩ妼"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭妽"),l1l111_l1_ (u"ࠧศๆห์๊࠭妾"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨ妿")]
	l11l1l1ll11l_l1_ = l1l111_l1_ (u"ࠩ࠲ࠫ姀").join(l11l1l1ll111_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ姁")).split(l1l111_l1_ (u"ࠫ࠴࠭姂"))[4:]).split(l1l111_l1_ (u"ࠬ࠳ࠧ姃"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ姄"),title,re.DOTALL)
		if l11l1l1ll111_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ姅").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ姆")).split(l1l111_l1_ (u"ࠩ࠲ࠫ姇"))[4:]).split(l1l111_l1_ (u"ࠪ࠱ࠬ姈"))
			l11l1l1ll1l1_l1_ = len([x for x in l11l1l1ll11l_l1_ if x in l111lllll_l1_])
			if l11l1l1ll1l1_l1_>2 and l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ姉") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ姊"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ始"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ࠧๆี็ื้࠭姌") not in title:
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ姍"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧ姎") in title:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ姏") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姐"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭姑"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姒"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ姓"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠦ委"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ姕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫ姖"),l1l111_l1_ (u"ࠫࠬ姗"))
			if title!=l1l111_l1_ (u"ࠬ࠭姘"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姙"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭姚")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠨࠩ姛"),l1l111_l1_ (u"ࠩࠪ姜"),l11l1l1ll111_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭姝"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ姞")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ姟"),url,l1l111_l1_ (u"࠭ࠧ姠"),headers,l1l111_l1_ (u"ࠧࠨ姡"),l1l111_l1_ (u"ࠨࠩ姢"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ姣"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ姤"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡭ࡨ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ姥"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭姦"))
	l11l1l1l1lll_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡭࡫ࡶࡸࡘ࡫ࡡࡴࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ姧"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ姨") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠬ姩"))
		if count==0: count = block.count(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠨ姪"))
		if count>1:
			l11l1l1l1lll_l1_ = False
			if l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠨ姫") in block:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ姬"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠲࠯ࡲ࡫ࡴࡄࡹ࡬ࡶࡩࡀࠫ姭")+id
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姮"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ姯"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵ࡭ࡪࡹࡉࡅ࠿ࠪ姰")+id
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姱"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l11l1l1l1lll_l1_:
		block = l1l111_l1_ (u"ࠪࠫ姲")
		if l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ姳") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡥࡱ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ姴"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ姵"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ姶"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ姷"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠩ࠲ࠫ姸"))+l1l111_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡹࡤࡸࡨ࡮ࠧ姹")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ姺"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭姻"),l1l111_l1_ (u"࠭ࠧ姼"),l1l111_l1_ (u"ࠧࠨ姽"),l1l111_l1_ (u"ࠨࠩ姾"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭姿"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ娀"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡵ࡟ࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ威"),html,re.DOTALL)
	if not l11111l11_l1_: l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࠨࡵࡪ࡬ࡷࡡ࠴ࡩࡥ࡞࠯࠴ࡡ࠲ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ娂"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ娃"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ娄"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ娅"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲࡭࡫ࡸࡡ࡮ࡧ࠵࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ娆")+l11111l11_l1_+l1l111_l1_ (u"ࠪࠪࡻ࡯ࡤࡦࡱࡀࠫ娇")+l111111ll_l1_[2:]+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ娈")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭娉")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡨࡧࡷࡉࡲࡨࡥࡥࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ娊"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ娋"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ娌")+title+l1l111_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ娍")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠪ࠳ࠬ娎"))+l1l111_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ娏")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ娐"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ娑"),l1l111_l1_ (u"ࠧࠨ娒"),l1l111_l1_ (u"ࠨࠩ娓"),l1l111_l1_ (u"ࠩࠪ娔"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ娕"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡺࡡࡣ࡮ࡨ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ娖"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ娗"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ娘"))
			if l1l111_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ娙") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠨࡡࡢาฬ฻ࠧ娚")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠩࠪ娛")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ娜")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ娝")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ娞"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"࠭ࠧ娟")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ娠"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ娡"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ娢"),l1l111_l1_ (u"ࠪ࠯ࠬ娣"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠫࠬ娤"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ娥")+search+l1l111_l1_ (u"࠭࠯ࠨ娦")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࠨ娧"))
	return
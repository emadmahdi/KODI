# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫງ")
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧຈ"):l1l1ll11l_l1_()}
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡇࡒࡔࡡࠪຉ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧຊ"),l1l111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮห๐࠭຋"),l1l111_l1_ (u"ࠧๆืสี฾ํࠧຌ"),l1l111_l1_ (u"ࠨษ฼่๋ࠦๅฺ่สࠤ⠘ࠦࡆࡰࡴࠣࡥࡩࡹࠧຍ"),l1l111_l1_ (u"่ࠩ์ออ๊ๅษอࠫຎ"),l1l111_l1_ (u"ࠪฬึอๅอࠢๆ้อ๐่หำࠪຏ"),l1l111_l1_ (u"ࠫฬู๊ศสࠣ็๊ฮ๊้ฬิࠫຐ"),l1l111_l1_ (u"ࠬอำๅษ่๎ฬะࠧຑ"),l1l111_l1_ (u"࠭วฯำ์ࠫຒ"),l1l111_l1_ (u"ࠧศไึห๊ࠦวฯำํࠫຓ"),l1l111_l1_ (u"ࠨษืฮึอใศฬࠪດ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==250: l1lll_l1_ = l1l1l11_l1_()
	elif mode==251: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==252: l1lll_l1_ = PLAY(url)
	elif mode==253: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==254: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩຕ")+text)
	elif mode==255: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧຖ")+text)
	elif mode==256: l1lll_l1_ = l11ll1_l1_(url,text)
	elif mode==259: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨທ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡢ࡫ࡱࠫຘ"),l1l111_l1_ (u"࠭ࠧນ"),headers,l1l111_l1_ (u"ࠧࠨບ"),l1l111_l1_ (u"ࠨࠩປ"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ຜ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪຝ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫພ"),l1l111_l1_ (u"ࠬ࠭ຟ"),259,l1l111_l1_ (u"࠭ࠧຠ"),l1l111_l1_ (u"ࠧࠨມ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬຢ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩຣ"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭຤"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬລ"),254)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ຦"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩວ"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨຨ"),255)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ຩ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫສ"),l1l111_l1_ (u"ࠪࠫຫ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫຬ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭ອ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬຮ"),251,l1l111_l1_ (u"ࠧࠨຯ"),l1l111_l1_ (u"ࠨࠩະ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩັ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪາ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ຳ")+l1lllll_l1_+l1l111_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫິ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬີ"),251,l1l111_l1_ (u"ࠧࠨຶ"),l1l111_l1_ (u"ࠨࠩື"),l1l111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸຸ࠭"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴູࠪ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ຺࠭")+l1lllll_l1_+l1l111_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫົ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬຼ"),251,l1l111_l1_ (u"ࠧࠨຽ"),l1l111_l1_ (u"ࠨࠩ຾"),l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ຿"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪເ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ແ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬໂ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭ࡣࡷࡩࡸࡺࠧໃ"),251,l1l111_l1_ (u"ࠧࠨໄ"),l1l111_l1_ (u"ࠨࠩ໅"),l1l111_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪໆ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ໇"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ່࠭"),l1l111_l1_ (u"້ࠬ࠭"),9999)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡦࡰࡸࡌࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ໊"),html,re.DOTALL)
	l1l1l1l_l1_ = l11ll11_l1_[0]
	l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽໋ࠩ"),l1l1l1l_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in l1l1111_l1_:
		title = unescapeHTML(title)
		if title not in l11lll_l1_ and title!=l1l111_l1_ (u"ࠨࠩ໌"):
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧໍ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ໎"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭໏")+l1lllll_l1_+title,l1ll1ll_l1_,256)
	return html
def l11ll1_l1_(url,type):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ໐"),url,l1l111_l1_ (u"࠭ࠧ໑"),headers,l1l111_l1_ (u"ࠧࠨ໒"),l1l111_l1_ (u"ࠨࠩ໓"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ໔"))
	html = response.content
	if l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴࡌࡲࡘ࡫ࡣࡵ࡫ࡲࡲࠬ໕") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ໖"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไฤๅฮี๋ࠥิศ้าอࠬ໗"),url,251,l1l111_l1_ (u"࠭ࠧ໘"),l1l111_l1_ (u"ࠧࠨ໙"),l1l111_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭໚"))
	if l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡸ࠭໛") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪໜ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬໝ"),url,251,l1l111_l1_ (u"ࠬ࠭ໞ"),l1l111_l1_ (u"࠭ࠧໟ"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ໠"))
	if l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠫ໡") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡳࡱࡳࡍ࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ໢"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			if len(l11llll_l1_)>1 and type==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ໣"): block = l11llll_l1_[1]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ໤"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭໥"),title,re.DOTALL)
				try: l1l11ll11_l1_ = l1lllllll_l1_[0][0]
				except: l1l11ll11_l1_ = l1l111_l1_ (u"࠭ࠧ໦")
				try: l1l11ll1l_l1_ = l1lllllll_l1_[0][1]
				except: l1l11ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ໧")
				l1lllllll_l1_ = l1l11ll11_l1_+l1l11ll1l_l1_
				l1lllllll_l1_ = l1lllllll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ໨"),l1l111_l1_ (u"ࠩࠪ໩"))
				if l1l111_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂࠬ໪") in title:
					l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ໫"),title,re.DOTALL)
					if l1l11l1l1_l1_: l1lllllll_l1_ = l1l11l1l1_l1_[0]
				if not l1lllllll_l1_:
					l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ໬"),title,re.DOTALL)
					if l1l11l1l1_l1_: l1lllllll_l1_ = l1l11l1l1_l1_[0]
				if l1lllllll_l1_:
					if l1l111_l1_ (u"࠭࡫ࡦࡻࡀࠫ໭") in l1ll1ll_l1_: type = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ໮"))[1]
					else: type = l1l111_l1_ (u"ࠨࡰࡨࡻࡪࡹࡴࠨ໯")
					l1lllllll_l1_ = l1lllllll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ໰"))
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ໱"),l1lllll_l1_+l1lllllll_l1_,l1ll1ll_l1_,251,l1l111_l1_ (u"ࠫࠬ໲"),l1l111_l1_ (u"ࠬ࠭໳"),type)
	return
def l1lll11_l1_(url,type):
	method,data,items = l1l111_l1_ (u"࠭ࡇࡆࡖࠪ໴"),l1l111_l1_ (u"ࠧࠨ໵"),[]
	if type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ໶"):
		if l1l111_l1_ (u"ࠩࡂࠫ໷") in url:
			l1l11lll1_l1_,l1l11llll_l1_ = l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ໸"),{}
			l1lllll1_l1_,l1l1l1111_l1_ = url.split(l1l111_l1_ (u"ࠫࡄ࠭໹"))
			lines = l1l1l1111_l1_.split(l1l111_l1_ (u"ࠬࠬࠧ໺"))
			for line in lines:
				key,value = line.split(l1l111_l1_ (u"࠭࠽ࠨ໻"))
				l1l11llll_l1_[key] = value
			if lines: method,url,data = l1l11lll1_l1_,l1lllll1_l1_,l1l11llll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,method,url,data,headers,l1l111_l1_ (u"ࠧࠨ໼"),l1l111_l1_ (u"ࠨࠩ໽"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ໾"))
	html = response.content
	if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ໿"): l11llll_l1_ = [html]
	elif l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ༀ") in type: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡓࡡࡪࡰࡖࡰ࡮ࡪࡥࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠩ༁"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ༂"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧอัํำࠥอไศใ็ห๊࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ༃"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ༄"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อส࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴࡌࡲࡘ࡫ࡣࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ༅"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠪࡱࡴࡹࡴࠨ༆"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵࡍࡳ࡙ࡥࡤࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠭༇"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡈ࡬ࡰࡥ࡮ࡷ࠲࡛ࡌࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡁࡣࡱࡈࡰࡘ࡫ࡥࡥࠤࠪ༈"),html,re.DOTALL)
	if l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ༉") in type:
		block = l11llll_l1_[0]
		zz = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳࡬ࡢࡼࡼ࠲࠯ࡅࠠࠩࡵࡵࡧࢁࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦࠫࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༊"),block,re.DOTALL)
		if zz:
			l1llll_l1_,l1l1lll1_l1_,l1l1l1l1l_l1_,l1l1ll1ll_l1_ = zip(*zz)
			items = zip(l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_)
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࡃࡵࡩࡦ࠴ࠪࡀࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡩࡧࡴࡢ࠯࡟ࡻࢀ࠹ࠬ࠶ࡿࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ་"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"࡚࡛ࠩࡊ࠭༌") in title: continue
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠪห้ำไใหࠪ།") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ༎"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ༏") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭༐"),l1lllll_l1_+title,l1ll1ll_l1_,253,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭༑"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡱࡧࡲࡺ࠱ࠪ༒") in l1ll1ll_l1_ or l1l111_l1_ (u"่ࠩืู้ไࠨ༓") in title:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༔"),l1lllll_l1_+title,l1ll1ll_l1_,253,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ༕"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
	if type in [l1l111_l1_ (u"ࠬࡴࡥࡸࡧࡶࡸࠬ༖"),l1l111_l1_ (u"࠭ࡢࡦࡵࡷࠫ༗"),l1l111_l1_ (u"ࠧ࡮ࡱࡶࡸ༘ࠬ")]:
		items = re.findall(l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳࡮ࡶ࡯ࡥࡩࡷࡹࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ༙ࠧ"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ༚"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ༛")+title,l1ll1ll_l1_,251,l1l111_l1_ (u"ࠫࠬ༜"),l1l111_l1_ (u"ࠬ࠭༝"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ༞"),url,l1l111_l1_ (u"ࠧࠨ༟"),headers,l1l111_l1_ (u"ࠨࠩ༠"),l1l111_l1_ (u"ࠩࠪ༡"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ༢"))
	html = response.content
	html = html[10000:]
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༣"),html,re.DOTALL)
	if not items: return
	l1ll1l_l1_,name = items[0]
	if l1l111_l1_ (u"ࠬอไฮๆๅอࠬ༤") in name: name = name.split(l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭༥"))[0].strip(l1l111_l1_ (u"ࠧࠡࠩ༦"))
	elif l1l111_l1_ (u"ࠨฯ็ๆฮ࠭༧") in name: name = name.split(l1l111_l1_ (u"ࠩะ่็ฯࠧ༨"))[0].strip(l1l111_l1_ (u"ࠪࠤࠬ༩"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ༪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ༫"),block,re.DOTALL)
		for l1ll1ll_l1_,l1l1lll_l1_ in items:
			title = name+l1l111_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢิๆ๊ࠦࠧ༬")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭༭"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
	else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ༮"),l1lllll_l1_+l1l111_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ༯"),url,252,l1ll1l_l1_)
	return
def l1l111lll_l1_(title,l1ll1ll_l1_):
	l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡟ࡦ࠳ࡺࡂ࠯࡝࠱ࡢ࠱ࠧ༰"),title,re.DOTALL)
	if l1lllllll_l1_: title = l1lllllll_l1_[0]
	else: title = title+l1l111_l1_ (u"ࠫࠥ࠭༱")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ༲"))
	title = title.replace(l1l111_l1_ (u"ู࠭าสࠣื๏ีࠧ༳"),l1l111_l1_ (u"ࠧࠨ༴")).replace(l1l111_l1_ (u"ࠨ็หหูื༵ࠧ"),l1l111_l1_ (u"ࠩࠪ༶")).replace(l1l111_l1_ (u"ู้ࠪอ็ะห༷ࠪ"),l1l111_l1_ (u"ࠫࠬ༸"))
	title = title.replace(l1l111_l1_ (u"ࠬ๓༹ࠧ"),l1l111_l1_ (u"࠭ࠧ༺"))
	title = title.replace(l1l111_l1_ (u"ࠧࠡࠢࠪ༻"),l1l111_l1_ (u"ࠨࠢࠪ༼")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ༽"),l1l111_l1_ (u"ࠪࠤࠬ༾"))
	return title
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ༿"),url,l1l111_l1_ (u"ࠬ࠭ཀ"),headers,l1l111_l1_ (u"࠭ࠧཁ"),l1l111_l1_ (u"ࠧࠨག"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬགྷ"))
	html = response.content
	l1lllll1_l1_ = response.url
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ང"))
	headers[l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫཅ")] = server+l1l111_l1_ (u"ࠫ࠴࠭ཆ")
	l1l111ll1_l1_,l1l1l11ll_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬ࠭ཇ"),l1l111_l1_ (u"࠭ࠧ཈"),[]
	l1l1ll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡺࡥࡹࡩࡨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱࠮ࡄ࠯ࠢࠨཉ"),html,re.DOTALL)
	if l1l1ll1l1_l1_: l1l111ll1_l1_,l1l1l1lll_l1_,l1l1l11ll_l1_,l1l1l1ll1_l1_ = l1l1ll1l1_l1_[0]
	else:
		l1l1ll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡂࡶࡶࡷࡳࡳࡹࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩཊ"),html,re.DOTALL)
		if l1l1ll1l1_l1_:
			l1ll1ll_l1_,l1l1l1lll_l1_ = l1l1ll1l1_l1_[0]
			if l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨཋ") in l1l1l1lll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			else: l1l1l11ll_l1_ = l1ll1ll_l1_
	if l1l111ll1_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧཌ"),l1l111ll1_l1_,l1l111_l1_ (u"ࠫࠬཌྷ"),headers,l1l111_l1_ (u"ࠬ࠭ཎ"),l1l111_l1_ (u"࠭ࠧཏ"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫཐ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡥࡳࡃࡵࡩࡦࠨࠨ࠯ࠬࡂࡀ࠴ࡻ࡬࠿ࠫࠪད"),html,re.DOTALL)
		if l11llll_l1_:
			l1l111l11_l1_ = l11llll_l1_[0]
			l1l111l11_l1_ = l1l111l11_l1_.replace(l1l111_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨདྷ"),l1l111_l1_ (u"ࠪࡀ࡭࠹࠾ࠨན"))
			l1l111l11_l1_ = l1l111l11_l1_.replace(l1l111_l1_ (u"ࠫࡁ࡮࠳࠿ࠩཔ"),l1l111_l1_ (u"ࠬࡂࡨ࠴ࡀ࠿࡬࠸ࡄࠧཕ"))
			l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡩ࠵ࡁ࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࡬࠸ࡄࠧབ"),l1l111l11_l1_,re.DOTALL)
			if not l1lll1l1_l1_: l1lll1l1_l1_ = [(l1l111_l1_ (u"ࠧࠨབྷ"),l1l111l11_l1_)]
			for l111l1ll_l1_,block in l1lll1l1_l1_:
				if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭མ")+l111l1ll_l1_
				items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ཙ"),block,re.DOTALL)
				for l1ll1ll_l1_,name in items:
					if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨཚ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪཛ")+l1ll1ll_l1_
					l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ཛྷ")+name+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧཝ")+l111l1ll_l1_
					l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࡌࡪࡷࡧ࡭ࡦࠤ࠱࠮ࡄࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨཞ"),html,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡊࡈࡍࡌࡎࡔ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩཟ"),html,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_,l111l1ll_l1_ = l1ll_l1_[0]
			name = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧའ"))
			if l1l111_l1_ (u"ࠪࠩࠬཡ") in l111l1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬར")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࠨལ")
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧཤ")+name+l1l111_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࡢࡣࠬཥ")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	if l1l1l11ll_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬས"),l1l1l11ll_l1_,l1l111_l1_ (u"ࠩࠪཧ"),headers,l1l111_l1_ (u"ࠪࠫཨ"),l1l111_l1_ (u"ࠫࠬཀྵ"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩཪ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡄࡰࡹࡱࡰࡴࡧࡤࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࡪࡺࡴࡣࡵ࡫ࡲࡲࠬཫ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧཬ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
				if not l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡴࡶࡤࡸ࡮ࡵ࡮ࠨ཭") in l1ll1ll_l1_: continue
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ཮")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ཯")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	l1l11l11l_l1_ = str(l1llll_l1_)
	l111ll1l_l1_ = [l1l111_l1_ (u"ࠫ࠳ࢀࡩࡱࡁࠪ཰"),l1l111_l1_ (u"ࠬ࠴ࡲࡢࡴࡂཱࠫ"),l1l111_l1_ (u"࠭࠮ࡵࡺࡷࡃིࠬ"),l1l111_l1_ (u"ࠧ࠯ࡲࡧࡪࡄཱི࠭"),l1l111_l1_ (u"ࠨ࠰ࡷࡥࡷࡅུࠧ"),l1l111_l1_ (u"ࠩ࠱࡭ࡸࡵ࠿ࠨཱུ"),l1l111_l1_ (u"ࠪ࠲ࡿ࡯ࡰ࠯ࠩྲྀ"),l1l111_l1_ (u"ࠫ࠳ࡸࡡࡳ࠰ࠪཷ"),l1l111_l1_ (u"ࠬ࠴ࡴࡹࡶ࠱ࠫླྀ"),l1l111_l1_ (u"࠭࠮ࡱࡦࡩ࠲ࠬཹ"),l1l111_l1_ (u"ࠧ࠯ࡶࡤࡶ࠳ེ࠭"),l1l111_l1_ (u"ࠨ࠰࡬ࡷࡴ࠴ཻࠧ")]
	if any(value in l1l11l11l_l1_ for value in l111ll1l_l1_):
		l1111l1_l1_(l1l111_l1_ (u"ོࠩࠪ"),l1l111_l1_ (u"ཽࠪࠫ"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧཾ"),l1l111_l1_ (u"ࠬาัษࠢิหอ฽ࠠๆะอ่ๆࠦไฤ่๋ࠣีอࠠศๆิหอ฽ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤฬ๊ั้ษห฻ࠥอไห์ࠣๅ๏ํวࠡ็็ๅฬะࠠโ์า๎ํࠦ࠮࠯ࠢ็ว๋ࠦ็ัษࠣห้๋่ใ฻ࠣๅ๏ํࠠฯั่หฯࠦรฯำ์ࠤ฿๐ัࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨཿ"))
		return
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳྀࠬ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ཱྀࠧࠡࠩ"),l1l111_l1_ (u"ࠨ࠭ࠪྂ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪ࡮ࡴࡤ࠰ࡁࡩ࡭ࡳࡪ࠽ࠨྃ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪ྄ࠪ"))
	return
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠫࡄࡅࠧ྅") in url: url = url.split(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ྆"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ྇"),1)
	if filter==l1l111_l1_ (u"ࠧࠨྈ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩྉ"),l1l111_l1_ (u"ࠩࠪྊ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧྋ"))
	if type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨྌ"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠬࡃ࠽ࠨྍ") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"࠭࠽࠾ࠩྎ") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪྏ")+category+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬྐ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬྑ")+category+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧྒ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧྒྷ"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩྔ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩྕ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪྖ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧྗ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ྘"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬྙ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬྚ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨྛ"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧྜ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭ྜྷ")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨྞ"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬྟ"),l1111111_l1_,251,l1l111_l1_ (u"ࠪࠫྠ"),l1l111_l1_ (u"ࠫࠬྡ"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ྡྷ"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ྣ"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧྤ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧྥ"),l1111111_l1_,251,l1l111_l1_ (u"ࠩࠪྦ"),l1l111_l1_ (u"ࠪࠫྦྷ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬྨ"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪྩ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨྪ"),l1l111_l1_ (u"ࠧࠨྫ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ྫྷ"),url,l1l111_l1_ (u"ࠩࠪྭ"),headers,l1l111_l1_ (u"ࠪࠫྮ"),l1l111_l1_ (u"ࠫࠬྯ"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪྰ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡔࡢࡺࡓࡥ࡬࡫ࡆࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡙ࠦ࡫ࡲ࡮ࡄࡗࡒࡸࠨࠧྱ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l1l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡕࡣࡻࡔࡦ࡭ࡥࡇ࡫࡯ࡸࡪࡸࡉࡵࡧࡰࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩྲ"),block,re.DOTALL)
	l1l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡔࡤࡸ࡮ࡴࡧࡇ࡫࡯ࡸࡪࡸࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁ࠲࠯ࡅࠨ࠽ࡷ࡯ࡂ࠮࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩླ"),block,re.DOTALL)
	l1l11l1l_l1_ = l1l1l1l11_l1_+l1l1l111l_l1_
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪྴ"),block,re.DOTALL)
		if name==l1l111_l1_ (u"ࠪหำื้ࠨྵ"): name = l1l111_l1_ (u"ࠫฬ๊วใีส้ࠬྶ")
		if not items:
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡶࡦࡺࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬྷ"),block,re.DOTALL)
			items = []
			for option,value in l1l1111_l1_: items.append([option,l1l111_l1_ (u"࠭ࠧྸ"),value])
			l1l111ll_l1_ = l1l111_l1_ (u"ࠧࡳࡣࡷࡩࠬྐྵ")
			name = l1l111_l1_ (u"ࠨษ็ฮ็๐๊ๆࠩྺ")
		else: l1l111ll_l1_ = items[0][1]
		if l1l111_l1_ (u"ࠩࡀࡁࠬྻ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧྼ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ྽")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ྾"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ྿"),l1111111_l1_,251,l1l111_l1_ (u"ࠧࠨ࿀"),l1l111_l1_ (u"ࠨࠩ࿁"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ࿂"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿃"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ࿄"),l1lllll1_l1_,254,l1l111_l1_ (u"ࠬ࠭࿅"),l1l111_l1_ (u"࿆࠭ࠧ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ࿇"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ࿈")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭࿉")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭࿊")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ࿋")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ࿌")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭࿍"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ࿎")+name,l1lllll1_l1_,255,l1l111_l1_ (u"ࠨࠩ࿏"),l1l111_l1_ (u"ࠩࠪ࿐"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for option,dummy,value in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠪห้้ไࠨ࿑") in option: continue
			option = unescapeHTML(option)
			l1l11l1ll_l1_,l1lllllll_l1_ = option,option
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠫ࠿ࠦࠧ࿒")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ࿓")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾ࠩ࿔")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ࿕")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀࠫ࿖")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭࿗")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ࿘"):
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿙"),l1lllll_l1_+l1lllllll_l1_,url,255,l1l111_l1_ (u"ࠬ࠭࿚"),l1l111_l1_ (u"࠭ࠧ࿛"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ࿜") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ࿝") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ࿞"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ࿟")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿠"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,251,l1l111_l1_ (u"ࠬ࠭࿡"),l1l111_l1_ (u"࠭ࠧ࿢"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ࿣"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿤"),l1lllll_l1_+l1lllllll_l1_,url,254,l1l111_l1_ (u"ࠩࠪ࿥"),l1l111_l1_ (u"ࠪࠫ࿦"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭࿧"),l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭࿨"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ࿩")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ࿪"),l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ࿫"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ࿬"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ࿭"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭࿮"),l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭࿯"),l1l111_l1_ (u"࠭ࡲࡢࡶࡨࠫ࿰")]
def l1l1l11l1_l1_(url):
	l1l111l1l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠲࠱࠴࠴࠳ࡆࡰࡡࡹࡣࡷ࠳ࡍࡵ࡭ࡦ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡍࡵ࡭ࡦ࠰ࡳ࡬ࡵ࠭࿱")
	url = url.replace(l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࠬ࿲"),l1l111l1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อฮา๋ࠪ࿳"),l1l111_l1_ (u"ࠪࠫ࿴"))
	if l1l111l1l_l1_ not in url: url = url+l1l111l1l_l1_
	url = url.replace(l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ࿵"),l1l111_l1_ (u"ࠬࡿࡥࡢࡴࠪ࿶"))
	url = url.replace(l1l111_l1_ (u"࠭࠿ࡀࠩ࿷"),l1l111_l1_ (u"ࠧࡀࠩ࿸"))
	url = url.replace(l1l111_l1_ (u"ࠨࠨࠩࠫ࿹"),l1l111_l1_ (u"ࠩࠩࠫ࿺"))
	url = url.replace(l1l111_l1_ (u"ࠪࡁࡂ࠭࿻"),l1l111_l1_ (u"ࠫࡂ࠭࿼"))
	return url
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ࿽"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"࠭ࠧ࿾")
	if l1l111_l1_ (u"ࠧ࠾࠿ࠪ࿿") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠩࠫက"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࡁࠬခ"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬဂ")
		if l1l111_l1_ (u"ࠫࠪ࠭ဃ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧင") and value!=l1l111_l1_ (u"࠭࠰ࠨစ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫဆ")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫဇ") and value!=l1l111_l1_ (u"ࠩ࠳ࠫဈ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭ဉ")+key+l1l111_l1_ (u"ࠫࡂࡃࠧည")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩဋ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩဌ")+key+l1l111_l1_ (u"ࠧ࠾࠿ࠪဍ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬဎ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬဏ"))
	return l1l1l111_l1_
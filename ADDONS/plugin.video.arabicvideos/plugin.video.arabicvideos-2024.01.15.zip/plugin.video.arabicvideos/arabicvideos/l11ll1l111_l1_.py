# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬᶨ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡄࡓ࠹ࡢࠫᶩ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨᶪ"),l1l111_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨᶫ"),l1l111_l1_ (u"ࠨฬึะ๏๊ࠧᶬ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==680: l1lll_l1_ = l1l1l11_l1_()
	elif mode==681: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==682: l1lll_l1_ = PLAY(url)
	elif mode==683: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==684: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==689: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᶭ"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫᶮ"),l1l111_l1_ (u"ࠫࠬᶯ"),l1l111_l1_ (u"ࠬ࠭ᶰ"),l1l111_l1_ (u"࠭ࠧᶱ"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᶲ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᶳ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᶴ"),l1l111_l1_ (u"ࠪࠫᶵ"),689,l1l111_l1_ (u"ࠫࠬᶶ"),l1l111_l1_ (u"ࠬ࠭ᶷ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶸ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᶹ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᶺ"),l1l111_l1_ (u"ࠩࠪᶻ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᶽ")+l1lllll_l1_+l1l111_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫᶾ"),l111l1_l1_,681,l1l111_l1_ (u"࠭ࠧᶿ"),l1l111_l1_ (u"ࠧࠨ᷀"),l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ᷁"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ᷂ࠩ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᷃")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ᷄"),l111l1_l1_,681,l1l111_l1_ (u"ࠬ࠭᷅"),l1l111_l1_ (u"࠭ࠧ᷆"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ᷇"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᷈"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᷉"),l1l111_l1_ (u"᷊ࠪࠫ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ᷋"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ᷌"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"࠭ࠧ᷍"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ᷎ࠬ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᷏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢ᷐ࠫ")+l1lllll_l1_+title,l1ll1ll_l1_,684)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ᷑"),url,l1l111_l1_ (u"ࠫࠬ᷒"),l1l111_l1_ (u"ࠬ࠭ᷓ"),l1l111_l1_ (u"࠭ࠧᷔ"),l1l111_l1_ (u"ࠧࠨᷕ"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᷖ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᷗ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫᷘ"),l1l111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪᷙ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᷚ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"࠭ࠧᷛ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᷜ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᷝ"),l1l111_l1_ (u"ࠩࠪᷞ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᷟ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠫ࠿ࠦࠧᷠ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷡ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᷢ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᷣ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᷤ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᷥ"),l1l111_l1_ (u"ࠪࠫᷦ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᷧ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭ᷨ")):
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᷩ"):
		url,search = url.split(l1l111_l1_ (u"ࠧࡀࠩᷪ"),1)
		data = l1l111_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᷫ")+search
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᷬ"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᷭ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩᷮ"),url,data,headers,l1l111_l1_ (u"ࠬ࠭ᷯ"),l1l111_l1_ (u"࠭ࠧᷰ"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᷱ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᷲ"),url,l1l111_l1_ (u"ࠩࠪᷳ"),l1l111_l1_ (u"ࠪࠫᷴ"),l1l111_l1_ (u"ࠫࠬ᷵"),l1l111_l1_ (u"ࠬ࠭᷶"),l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧ᷷ࠫ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠧࠨ᷸"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰ᷹ࠬ"))
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮᷺ࠧ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᷻"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬ᷼"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ᷽ࠧ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᷾"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ᷿࠭"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨḀ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ḁ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪḂ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ḃ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧḄ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨḅ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨḆ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩḇ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪḈ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪḉ"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩḊ"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫḋ"),l1l111_l1_ (u"࠭ใๅ์หࠫḌ"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ḍ"),l1l111_l1_ (u"ࠨ้าหๆ࠭Ḏ"),l1l111_l1_ (u"่ࠩฬฬืวสࠩḏ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧḐ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫḑ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫḒ"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭ḓ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪḔ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧḕ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨḖ"):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩḗ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪḘ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḙ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ḛ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨḛ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭Ḝ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫḝ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬḞ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ḟ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḠ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬḡ")+title,l1ll1ll_l1_,681)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫḢ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬḣ"),url,l1l111_l1_ (u"ࠩࠪḤ"),l1l111_l1_ (u"ࠪࠫḥ"),l1l111_l1_ (u"ࠫࠬḦ"),l1l111_l1_ (u"ࠬ࠭ḧ"),l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭Ḩ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪḩ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪḪ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪḫ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡵ࡮ࡤ࡮࡬ࡧࡰࡃࠢࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪḬ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠫࠨ࠭ḭ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḮ"),l1lllll_l1_+title,url,683,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧḯ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࠬḰ")+l1l11_l1_+l1l111_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ḱ"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣḲ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḳ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭Ḵ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧḵ"))
			title = title.replace(l1l111_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫḶ"),l1l111_l1_ (u"ࠧࠡࠩḷ"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧḸ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l11ll11lll_l1_ = [],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬḹ"),l1l111_l1_ (u"ࠪࡴࡱࡧࡹ࠯ࡲ࡫ࡴࠬḺ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨḻ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭Ḽ"),l1l111_l1_ (u"࠭ࠧḽ"),l1l111_l1_ (u"ࠧࠨḾ"),l1l111_l1_ (u"ࠨࠩḿ"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬṀ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫṁ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬṂ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪṃ"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧṄ")+server+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨṅ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧṆ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l11ll11lll_l1_:
			l11ll11lll_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧṇ"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫṈ")+server+l1l111_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬṉ")
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤ࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩṊ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪṋ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬṌ"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩṍ")+server+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭Ṏ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩṏ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬṐ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭ṑ"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨṒ"),l1l111_l1_ (u"ࠧࠬࠩṓ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩṔ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩṕ"))
	return
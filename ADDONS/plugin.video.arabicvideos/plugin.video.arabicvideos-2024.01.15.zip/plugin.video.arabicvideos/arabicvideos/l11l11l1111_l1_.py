# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ傘")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ備") : l1l111_l1_ (u"ࠬ࠭傚") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡈ࡚ࡣࠬ傛")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l1l11111l11l_l1_(url)
	elif mode==215: l1lll_l1_ = l1l11111l1l1_l1_(url)
	elif mode==218: l1lll_l1_ = l1ll111l11l1_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll111l11l1_l1_():
	message = l1l111_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ傜")
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ傝"),l1l111_l1_ (u"ࠩࠪ傞"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭傟"),l1l111_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠪ傠"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傡"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭傢"),l1l111_l1_ (u"ࠧࠨ傣"),219,l1l111_l1_ (u"ࠨࠩ傤"),l1l111_l1_ (u"ࠩࠪ傥"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ傦"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ傧")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ储"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ傩")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ傪"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩ傫"),headers,l1l111_l1_ (u"ࠩࠪ催"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ傭"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ傮"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ傯"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ傰")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ傱"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ傲")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ傳"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭傴"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ債"),l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ傶")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ傷"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ傸"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ傹")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ傺"),headers,l1l111_l1_ (u"ࠪࠫ傻"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ傼"))
	if l1l111_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧ傽") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ傾") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭傿"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭僀"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ僁"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ僂"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ僃"),l1l111_l1_ (u"้ࠬไ๋สࠪ僄"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ僅"),l1l111_l1_ (u"่ࠧัสๅࠬ僆"),l1l111_l1_ (u"ࠨ็หหึอษࠨ僇"),l1l111_l1_ (u"ࠩ฼ี฻࠭僈"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ僉"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ僊")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ僋") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ僌"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ働"))
		if l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ僎") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ像"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭僐") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ僑") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ僒"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ僓") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僔"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僕"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ僖"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭僗"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ僘"),l1l111_l1_ (u"ࠬ࠭僙"))
			if title!=l1l111_l1_ (u"࠭ࠧ僚"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僛"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ僜")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ僝"),headers,l1l111_l1_ (u"ࠪࠫ僞"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ僟"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ僠"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"࠭ࠧ僡").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭僢"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ僣"))
		title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ僤") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ僥"))[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭僦"),l1l111_l1_ (u"ࠬࠦࠧ僧"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬ僨"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ僩"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ僪")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ僫"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭僬"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭僭") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ僮") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭僯"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ僰") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ僱"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ僲"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ僳"),headers,l1l111_l1_ (u"ࠫࠬ僴"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭僵"))
	if l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ僶") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭僷"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ僸"),headers,l1l111_l1_ (u"ࠩࠪ價"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ僺"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ僻"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ僼"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ僽"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l1111l_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡳࡳࡸࡺࡩࡥ࠿ࠪ僾")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ僿")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ儀")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ儁")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪࠥࢀࠫࡷࡵࡰࡶ࠾࠭ࠬ儂"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ儃") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ億"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ儅"),headers,l1l111_l1_ (u"ࠨࠩ儆"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ儇"))
		id = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ儈"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l1111l_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ儉"):l1l111_l1_ (u"ࠬ࠭儊") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ儋"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ儌") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ儍")+l1l1l1111l_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ儎"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ儏"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ儐"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠴࠰࠭ࡃ࠭ࡢࡤࠬࠫࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ儑"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ儒"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ儓")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ儔")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ儕")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠼ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭儖"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠫࠬ儗")
					items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ儘"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"࠭ࠦࠧࠩ儙") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ儚"))[2].lower() + l1l111_l1_ (u"ࠨࠨࠩࠫ儛")
						server = server.replace(l1l111_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ儜"),l1l111_l1_ (u"ࠪࠫ儝")).replace(l1l111_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ儞"),l1l111_l1_ (u"ࠬ࠭償"))
						server = server.replace(l1l111_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭儠"),l1l111_l1_ (u"ࠧࠨ儡")).replace(l1l111_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ儢"),l1l111_l1_ (u"ࠩࠪ儣"))
						server = server.replace(l1l111_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ儤"),l1l111_l1_ (u"ࠫࠬ儥")).replace(l1l111_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ儦"),l1l111_l1_ (u"࠭ࠧ儧"))
						server = server.replace(l1l111_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭儨"),l1l111_l1_ (u"ࠨࠩ儩")).replace(l1l111_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ優"),l1l111_l1_ (u"ࠪࠫ儫"))
						server = server.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ儬"),l1l111_l1_ (u"ࠬ࠭儭"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ儮") + name + server + l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ儯")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ儰"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ儱"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ儲"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭儳"),l1l111_l1_ (u"ࠬ࠱ࠧ儴"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ儵")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࢸ") : l1l111_l1_ (u"ࠧࠨࢹ") }
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧࢺ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡅࡐࡕ࡟ࠨࢻ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l111ll1_l1_ = [l1l111_l1_ (u"ࠪๅ๏๊ๅࠨࢼ"),l1l111_l1_ (u"่๊๊ࠫษࠩࢽ"),l1l111_l1_ (u"ࠬอไฺำูࠤฬ๊วิส๋฽๏࠭ࢾ"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭ࢿ"),l1l111_l1_ (u"ࠧๆีิั๏ํࠧࣀ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧࣁ"),l1l111_l1_ (u"ࠩส฽้อๆࠨࣂ"),l1l111_l1_ (u"่ࠪ็อมࠨࣃ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==70: l1lll_l1_ = l1l1l11_l1_()
	elif mode==71: l1lll_l1_ = CATEGORIES(url)
	elif mode==72: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==73: l1lll_l1_ = l1ll1111_l1_(url)
	elif mode==74: l1lll_l1_ = PLAY(url)
	elif mode==79: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࣄ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬࣅ"),l1l111_l1_ (u"࠭ࠧࣆ"),79,l1l111_l1_ (u"ࠧࠨࣇ"),l1l111_l1_ (u"ࠨࠩࣈ"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࣉ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࣊"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࣋")+l1lllll_l1_+l1l111_l1_ (u"ูࠬไิๆฬࠤฬ็ไศ็ࠪ࣌"),l1l111_l1_ (u"࠭ࠧ࣍"),79,l1l111_l1_ (u"ࠧࠨ࣎"),l1l111_l1_ (u"ࠨ࣏ࠩ"),l1l111_l1_ (u"ࠩึุ่๊ษࠡษไ่ฬ๋࣐ࠧ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ࣑ࠪ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࣒࠭")+l1lllll_l1_+l1l111_l1_ (u"ูࠬไศี็ࠤ๊์ฺ่ห࣓ࠪ"),l1l111_l1_ (u"࠭ࠧࣔ"),79,l1l111_l1_ (u"ࠧࠨࣕ"),l1l111_l1_ (u"ࠨࠩࣖ"),l1l111_l1_ (u"ࠩึุ่๊ษࠨࣗ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨࣘ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࣙ"),l1l111_l1_ (u"ࠬ࠭ࣚ"),9999)
	l11lll_l1_ = [l1l111_l1_ (u"࠭วๅๅอฬࠥ๎ࠠศๆสฬาอหࠨࣛ"),l1l111_l1_ (u"ࠧศๆๆ์ึูวหࠢส่ฯ฿ไ๋็ํอࠬࣜ"),l1l111_l1_ (u"ࠨษ็ว้฿วษࠩࣝ"),l1l111_l1_ (u"ࠩส่อืวๆฮࠪࣞ"),l1l111_l1_ (u"ࠪห้อฬ่ิฬࠤฬ๊ไ้ฯํอࠬࣟ"),l1l111_l1_ (u"ࠫฬ๊ี้ำࠣ์ࠥอไฯๆไ๎ฬะࠧ࣠"),l1l111_l1_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭࣡")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ࣢"),headers,l1l111_l1_ (u"ࠧࠨࣣ"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩࣤ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥࡷࡺࡩࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨࣥ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࣦࠩ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࣧ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࣨ")+l1lllll_l1_+title,l1ll1ll_l1_,71)
	return html
def CATEGORIES(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࣩ࠭ࠧ"),headers,l1l111_l1_ (u"ࠧࠨ࣪"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨ࣫"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡨࡺ࡟ࡱࡣࡵࡸࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ࣬"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࣭ࠬ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࣮ࠫࠥ࠭"))
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ࣯ࠬ"),l1lllll_l1_+title,l1ll1ll_l1_,72)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࣰ࠭"),l1lllll_l1_+l1l111_l1_ (u"ࠧอ็ํ฽ࠥอไโำ๋฽ࣱࠬ"),url,72)
	else: l1lll11_l1_(url,l1l111_l1_ (u"ࠨࣲࠩ"))
	return
def l1lll11_l1_(url,type):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪࣳ"),headers,True,l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ࣴ"))
	items = []
	if type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ࣵ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡥࡴࡪࡶ࡯ࡩࠥ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡷࡺࡨࡪࡦࡥࡷࡷ࠲ࡩࡲࡰࡷࡶࡩࡱࣶ࠭"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨࡪࡦࡥࡷࡣࡧࡵࡸ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧࣷ"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧࣸ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࡟ࡳࡧࡶࡹࡱࡺࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࣹࠬ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠱࠿ࣺࠩ"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠪࡱࡴࡸࡥࠨࣻ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡤࡺࡩࡵ࡮ࡨࠤࡲࡵࡲࡦࡡࡷ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶࡤࡨ࡯ࡵࡶࡲࡱࡤࡹࡥࡳࡸ࡬ࡧࡪࡹࠧࣼ"),html,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺࠧࣽ"),html,re.DOTALL)
	if not items and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨࡪࡦࡥࡷࡣࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨࣾ"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠧหู๊๎าࠦ็ศ็ࠪࣿ") in title: continue
		title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫऀ"),l1l111_l1_ (u"ࠩࠪँ")).strip(l1l111_l1_ (u"ࠪࠤࠬं"))
		title = unescapeHTML(title)
		if any(value in title for value in l111ll1_l1_): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪः"),l1lllll_l1_+title,l1ll1ll_l1_,73,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬऄ"),l1lllll_l1_+title,l1ll1ll_l1_,73,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧअ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠢ࠽࠱࡯࡭ࡃࡂ࡬ࡪࠢࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧआ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨइ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨई")+title,l1ll1ll_l1_,72,l1l111_l1_ (u"ࠪࠫउ"),l1l111_l1_ (u"ࠫࠬऊ"),type)
	return
def l1llll11_l1_(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭ऋ"),headers,True,l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑ࠲࡙ࡅࡄࡖࡌࡓࡓ࡙࠭࠳ࡰࡧࠫऌ"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡵࡩ࡫ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨऍ"),html,re.DOTALL)
	l1lllll1_l1_ = l1lllll1_l1_[1]
	return l1lllll1_l1_
def l1ll1111_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩऎ"),headers,True,l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡕࡈࡇ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧए"))
	l1lll111_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠮࠿࠵࠯ࡢ࡭ࡺࡥࡲ࠴࡮ࡦࡶ࠲ࡠࡼ࠱࠮ࠫࡁࠬࠦࠬऐ"),html,re.DOTALL)
	l1lll11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠯ࡀ࠯࠰ࡷࡱࡨࡪࡸࡵࡳ࡮࠱ࡧࡴࡳ࠯࡝ࡹ࠮࠲࠯ࡅࠩࠣࠩऑ"),html,re.DOTALL)
	if l1lll111_l1_ or l1lll11l_l1_:
		if l1lll111_l1_: l1llllll_l1_ = l1lll111_l1_[0]
		elif l1lll11l_l1_: l1llllll_l1_ = l1llll11_l1_(l1lll11l_l1_[0])
		l1llllll_l1_ = l111l11_l1_(l1llllll_l1_)
		import l1ll1l1l_l1_
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧऒ") in l1llllll_l1_ or l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡻࡸ࠵ࠧओ") in l1llllll_l1_: l1ll1l1l_l1_.l1ll1l11_l1_(l1llllll_l1_)
		else: l1ll1l1l_l1_.PLAY(l1llllll_l1_)
		return
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧๆฯอ์๎ࠦวๅใํ่๊࠴ࠪࡀࡀ࠱࠮ࡄ࠮࡜ࡸࠬࡂ࠭ࡡ࡝ࠪࡀ࠾ࠪऔ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡥࡶࠥ࠵࠾࡝ࡰ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨक"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩख"),l1lllll_l1_+title,l1ll1ll_l1_,73)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨ࡟ࡵ࡫ࡷࡰࡪࠨ࠮ࠫࡁ࠿࡬࠶࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡤ࡭ࡳࡥࡩ࡮ࡩࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡࡥ࠯࠶࠴࠵࠳࠲࠶࠲ࠫ࠲࠯ࡅࠩࡢ࡭ࡲ࠱࡫࡫ࡥࡥࡤࡤࡧࡰ࠭ग"),html,re.DOTALL)
	if not l11llll_l1_:
		l1ll1lll_l1_(l1l111_l1_ (u"ࠫำ฽รࠡะสีั๐ࠧघ"),l1l111_l1_ (u"๊ࠬวࠡ์๋ะิࠦๅๅใࠣๅ๏ี๊้ࠩङ"))
		return
	name,l1ll1l_l1_,block = l11llll_l1_[0]
	name = name.strip(l1l111_l1_ (u"࠭ࠠࠨच"))
	if l1l111_l1_ (u"ࠧࡴࡷࡥࡣࡪࡶࡳࡪࡱࡧࡩࡤࡺࡩࡵ࡮ࡨࠫछ") in block:
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡸࡦࡤ࡫ࡰࡴ࡫ࡲࡨࡪࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀ࠱࠮ࡄࡹࡵࡣࡡࡩ࡭ࡱ࡫࡟ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩज"),block,re.DOTALL)
	else:
		filenames = re.findall(l1l111_l1_ (u"ࠩࡶࡹࡧࡥࡦࡪ࡮ࡨࡣࡹ࡯ࡴ࡭ࡧ࡟ࠫࡃ࠮࠮ࠫࡁࠬࠤ࠲ࠦ࠼ࡪࡀࠪझ"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l1l111_l1_ (u"ࠪีฬฮืࠡษ็ฮูเ๊ๅࠩञ"),filename) )
	if not items: items = [ (l1l111_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪट"),l1l111_l1_ (u"ࠬ࠭ठ")) ]
	count = 0
	l1l1lll1_l1_,l1llll1l_l1_ = [],[]
	size = len(items)
	for title,filename in items:
		l111lll_l1_ = l1l111_l1_ (u"࠭ࠧड")
		if l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫढ") in filename: filename = filename.split(l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬण"))[0]
		else: filename = l1l111_l1_ (u"ࠩࡧࡹࡲࡳࡹ࠯ࡼ࡬ࡴࠬत")
		if l1l111_l1_ (u"ࠪ࠲ࠬथ") in filename: l111lll_l1_ = filename.split(l1l111_l1_ (u"ࠫ࠳࠭द"))[-1]
		title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨध"),l1l111_l1_ (u"࠭ࠧन")).strip(l1l111_l1_ (u"ࠧࠡࠩऩ"))
		l1l1lll1_l1_.append(title)
		l1llll1l_l1_.append(count)
		count += 1
	if size>0:
		if any(value in name for value in l111ll1_l1_):
			if size==1:
				l11l11l_l1_ = 0
			else:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩप"), l1l1lll1_l1_)
				if l11l11l_l1_ == -1: return
			PLAY(url+l1l111_l1_ (u"ࠩࡂࡷࡪࡩࡴࡪࡱࡱࡁࠬफ")+str(1+l1llll1l_l1_[size-l11l11l_l1_-1]))
		else:
			for i in reversed(range(size)):
				title = name + l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧब") + l1l1lll1_l1_[i]
				title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧभ"),l1l111_l1_ (u"ࠬ࠭म")).strip(l1l111_l1_ (u"࠭ࠠࠨय"))
				l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠧࡀࡵࡨࡧࡹ࡯࡯࡯࠿ࠪर")+str(size-i)
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧऱ"),l1lllll_l1_+title,l1ll1ll_l1_,74,l1ll1l_l1_)
	else:
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้ืวษู่ࠣ๏ูࠠโ์า๎ํ࠭ळ"),l1l111_l1_ (u"ࠫࠬऴ"),9999,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1lll_l1_ = url.split(l1l111_l1_ (u"ࠬࡅࡳࡦࡥࡷ࡭ࡴࡴ࠽ࠨव"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪश"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨष"),headers,True,l1l111_l1_ (u"ࠨࠩस"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡒࡏࡅ࡞ࡥࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩह"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡩ࠳࠳࠱࠲࠰࠶࠺࠶࠮ࠫࡁࡤࡨ࠲࠹࠰࠱࠯࠵࠹࠵࠮࠮ࠫࡁࠬࡥࡰࡵ࠭ࡧࡧࡨࡨࡧࡧࡣ࡬ࠩऺ"),html,re.DOTALL)
	l111111_l1_ = l11llll_l1_[0].replace(l1l111_l1_ (u"ࠦࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠢऻ"),l1l111_l1_ (u"ࠬࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠡࡧࡳࡷࡴ࡯ࡤࡦࡡࡥࡳࡽ़࠭"))
	l111111_l1_ = l111111_l1_ + l1l111_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠨऽ")
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡦࡲࡶࡳ࡮ࡪࡥࡠࡤࡲࡼ࠭࠴ࠪࡀࠫࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࡟ࡣࡱࡻࠫा"),l111111_l1_,re.DOTALL)
	l1l1lll_l1_ = len(l1lll1l1_l1_)-int(l1l1lll_l1_)
	block = l1lll1l1_l1_[l1l1lll_l1_]
	l1ll11l1_l1_ = []
	l1ll111l_l1_ = {l1l111_l1_ (u"ࠨ࠳࠷࠶࠸࠶࠷࠶࠺࠹࠶ࠬि"):l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧी"),l1l111_l1_ (u"ࠪ࠵࠹࠽࠷࠵࠺࠺࠺࠵࠷ࠧु"):l1l111_l1_ (u"ࠫࡪࡹࡴࡳࡧࡤࡱࠬू"),l1l111_l1_ (u"ࠬ࠷࠵࠱࠷࠶࠶࠽࠺࠰࠵ࠩृ"):l1l111_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲࡧ࡮ࡨࡱࠪॄ"),
		l1l111_l1_ (u"ࠧ࠲࠶࠵࠷࠵࠾࠰࠱࠳࠸ࠫॅ"):l1l111_l1_ (u"ࠨࡨ࡯ࡥࡸ࡮ࡸࠨॆ"),l1l111_l1_ (u"ࠩ࠴࠸࠺࠾࠱࠲࠹࠵࠽࠺࠭े"):l1l111_l1_ (u"ࠪࡳࡵ࡫࡮࡭ࡱࡤࡨࠬै"),l1l111_l1_ (u"ࠫ࠶࠺࠲࠴࠲࠺࠽࠸࠶࠶ࠨॉ"):l1l111_l1_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬॊ"),l1l111_l1_ (u"࠭࠱࠵࠵࠳࠴࠺࠸࠳࠸࠳ࠪो"):l1l111_l1_ (u"ࠧࡰ࡭࠱ࡶࡺ࠭ौ"),
		l1l111_l1_ (u"ࠨ࠳࠷࠻࠼࠺࠸࠹࠴࠴࠷्ࠬ"):l1l111_l1_ (u"ࠩࡷ࡬ࡪࡼࡩࡥࠩॎ"),l1l111_l1_ (u"ࠪ࠵࠺࠻࠸࠳࠹࠻࠴࠵࠼ࠧॏ"):l1l111_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫॐ"),l1l111_l1_ (u"ࠬ࠷࠴࠸࠹࠷࠼࠼࠿࠹࠱ࠩ॑"):l1l111_l1_ (u"࠭ࡶࡪࡦࡷࡳࡩࡵ॒ࠧ")}
	items = re.findall(l1l111_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡥࡸࡳ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢ॓"),block,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨ॔"))
	items = re.findall(l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨॕ"),block,re.DOTALL)
	for l111l1l_l1_,l1ll1ll_l1_ in items:
		l111l1l_l1_ = l111l1l_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬॖ"))[-1]
		l111l1l_l1_ = l111l1l_l1_.split(l1l111_l1_ (u"ࠫ࠳࠭ॗ"))[0]
		if l111l1l_l1_ in l1ll111l_l1_:
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭क़")+l1ll111l_l1_[l111l1l_l1_]+l1l111_l1_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡢ࡭ࡲࡥࡲ࠭ख़"))
		else: l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨग़")+l111l1l_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨज़"))
	if not l1ll11l1_l1_:
		message = re.findall(l1l111_l1_ (u"ࠩࡶࡹࡧ࠳࡮ࡰ࠯ࡩ࡭ࡱ࡫࠮ࠫࡁ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬड़"),block,re.DOTALL)
		if message: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫढ़"),l1l111_l1_ (u"ࠫࠬफ़"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧय़"),message[0])
	else:
		import ll_l1_
		ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬॠ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨॡ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩॢ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫॣ"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ।"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭॥")+l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ०"))
	return
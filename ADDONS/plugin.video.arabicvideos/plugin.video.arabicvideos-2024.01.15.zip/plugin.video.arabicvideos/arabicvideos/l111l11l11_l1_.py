# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭␤")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡉࡇࡣࠬ␥")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆืสี฾ฯࠧ␦"),l1l111_l1_ (u"ࠨษะำะࠦวๅสิห๊าࠧ␧"),l1l111_l1_ (u"ࠩสัิัࠠศๆส่฾อศࠨ␨"),l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ␩"),l1l111_l1_ (u"ࠫฬำฯฬࠢส่ฬเว็๋ࠪ␪")]
def l11l1ll_l1_(mode,url,text):
	if   mode==440: l1lll_l1_ = l1l1l11_l1_()
	elif mode==441: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==442: l1lll_l1_ = PLAY(url)
	elif mode==443: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==449: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ␫"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ␬"),l1l111_l1_ (u"ࠧࠨ␭"),l1l111_l1_ (u"ࠨࠩ␮"),l1l111_l1_ (u"ࠩࠪ␯"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭␰"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ␱"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ␲"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭␳"),l1l111_l1_ (u"ࠧࠨ␴"),449,l1l111_l1_ (u"ࠨࠩ␵"),l1l111_l1_ (u"ࠩࠪ␶"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ␷"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␸"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ␹")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ␺"),l111l1_l1_,441)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ␻"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ␼"),l1l111_l1_ (u"ࠩࠪ␽"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡡࡰࡩࡳࡻ࡟ࡳ࡫ࡪ࡬ࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ␾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭␿"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ⑀"): continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⑁"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⑂")+l1lllll_l1_+title,l1ll1ll_l1_,441)
	return
def l1lll11_l1_(url,l1111ll1_l1_=l1l111_l1_ (u"ࠨࠩ⑃")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⑄"),url,l1l111_l1_ (u"ࠪࠫ⑅"),l1l111_l1_ (u"ࠫࠬ⑆"),l1l111_l1_ (u"ࠬ࠭⑇"),l1l111_l1_ (u"࠭ࠧ⑈"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⑉"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ⑊"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠳ࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⑋"),block,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		if l1l111_l1_ (u"ࠪ࠳ࡺࡸ࡬࠰ࠩ⑌") in l1ll1ll_l1_: continue
		elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭⑍") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⑎"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ⑏") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑐"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⑑"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⑒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⑓"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⑔"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⑕")+title,l1ll1ll_l1_,441)
	return
def l1ll1l11_l1_(url):
	data = {l1l111_l1_ (u"࠭ࡖࡪࡧࡺࠫ⑖"):1}
	headers = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⑗"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ⑘")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⑙"),url,data,headers,l1l111_l1_ (u"ࠪࠫ⑚"),l1l111_l1_ (u"ࠫࠬ⑛"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⑜"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡤࡷࡴࡴࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ⑝"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡳ࡭ࡸࡵࡤࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭⑞"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⑟"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ①"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡴ࡭࠺ࡪ࡯ࡤ࡫ࡪࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ②"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭③"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ④"),l1l111_l1_ (u"࠭ࠧ⑤")).strip(l1l111_l1_ (u"ࠧࠡࠩ⑥"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⑦"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	return
def PLAY(url):
	data = {l1l111_l1_ (u"࡙ࠩ࡭ࡪࡽࠧ⑧"):1}
	headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⑨"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⑩")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ⑪"),url,data,headers,l1l111_l1_ (u"࠭ࠧ⑫"),l1l111_l1_ (u"ࠧࠨ⑬"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⑭"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡻࡦࡺࡣࡩࡃࡵࡩࡦࡓࡡࡴࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⑮"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡮࡬ࡲࡰࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ⑯"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ⑰"),l1l111_l1_ (u"ࠬ࠭⑱")).strip(l1l111_l1_ (u"࠭ࠠࠨ⑲"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⑳")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⑴")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡴࡴࡷ࡭ࡱࡤࡨ࠲ࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⑵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲ࠮ࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⑶"),block,re.DOTALL)
		for title,l111l1ll_l1_,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ⑷"),l1l111_l1_ (u"ࠬ࠭⑸"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⑹")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⑺")+l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭⑻")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⑼"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ⑽"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ⑾"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⑿"),l1l111_l1_ (u"࠭ࠫࠨ⒀"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⒁")+search
	l1lll11_l1_(url)
	return
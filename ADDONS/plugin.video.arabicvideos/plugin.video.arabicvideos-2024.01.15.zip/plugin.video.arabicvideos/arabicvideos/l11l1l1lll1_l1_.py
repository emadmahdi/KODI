# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ坃")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ坄")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ坅"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l1ll11lll_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ坆"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭均"),l1l111_l1_ (u"ࠧࠨ坈"),319,l1l111_l1_ (u"ࠨࠩ坉"),l1l111_l1_ (u"ࠩࠪ坊"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ坋"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ坌"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭坍"),l1l111_l1_ (u"࠭ࠧ坎"),l1l111_l1_ (u"ࠧࠨ坏"),l1l111_l1_ (u"ࠨࠩ坐"),l1l111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ坑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࡱ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ坒"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ坓"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ坔"),l1l111_l1_ (u"࠭ࠧ坕"),9999)
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠻࠾ࠨ坖"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠨࠢࠪ块"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坘"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ坙")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠫࠬ坚"),l1l111_l1_ (u"ࠬ࠭坛"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭坜"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ坝")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ๅห฼฿ࠠี้ิࠫ坞"),l111l1_l1_,314,l1l111_l1_ (u"ࠩࠪ坟"),l1l111_l1_ (u"ࠪࠫ坠"),l1l111_l1_ (u"ࠫ࠵࠭坡"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ坢"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ坣"),l1l111_l1_ (u"ࠧࠨ坤"),9999)
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡆࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡈ࠾ࠨ坥"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ坦")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坧"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭坨")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ坩"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ坪"),l1l111_l1_ (u"ࠧࠨ坫"),l1l111_l1_ (u"ࠨࠩ坬"),l1l111_l1_ (u"ࠩࠪ坭"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ坮"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠫ࠵࠭坯"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡡࡣ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ坰"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭坱"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ坲")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ坳"))
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ坴"))
			title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭坵")+name+l1l111_l1_ (u"ࠫ࠮࠭坶")
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ坷"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"࠭࠱ࠨ坸"),l1l111_l1_ (u"ࠧ࠳ࠩ坹"),l1l111_l1_ (u"ࠨ࠵ࠪ坺")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡀ࡭࠻࠾࠯ࠬࡂ࠭ࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡬ࡨࠩ坻"),html,re.DOTALL)
		l11l1ll1l111_l1_ = int(seq)-1
		block = l11llll_l1_[l11l1ll1l111_l1_]
		if seq==l1l111_l1_ (u"ࠪ࠵ࠬ坼"): items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ坽"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭坾"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ坿")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ垀")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ垁"))
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ垂"))
			title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭垃")+name+l1l111_l1_ (u"ࠫ࠮࠭垄")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垅"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"࠭࠴ࠨ垆"),l1l111_l1_ (u"ࠧ࠶ࠩ垇"),l1l111_l1_ (u"ࠨ࠸ࠪ垈")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡀ࡭࠻࠾࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭垉"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅ࠭ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭垊"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11ll1_l1_,title,l11111111l_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭型")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垌")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垍"))
			l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ垎"))
			l11111111l_l1_ = l11111111l_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ垏"))
			if l1ll1l11ll1_l1_: name = l1ll1l11ll1_l1_
			else: name = l11111111l_l1_
			title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ垐")+name+l1l111_l1_ (u"ࠪ࠭ࠬ垑")
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ垒"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ垓"),url,l1l111_l1_ (u"࠭ࠧ垔"),l1l111_l1_ (u"ࠧࠨ垕"),l1l111_l1_ (u"ࠨࠩ垖"),l1l111_l1_ (u"ࠩࠪ垗"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ垘"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡨ࡯ࡹ࠯࡫ࡩࡦࡪࡩ࡯ࡩࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡯ࡳࡦࡺ࠭ࡳ࡫ࡪ࡬ࡹ࠭垙"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠬࡩࡡࡵࡵࡸࡱ࠲ࡳ࡯ࡣ࡫࡯ࡩࠬ垚") in block:
		items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃࡨࡧࡴࡴࡷࡰ࠱ࡲࡵࡢࡪ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ垛"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ垜")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ垝")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠩࠣห้฻่ห์ฬ࠾ࠥ࠭垞"),l1l111_l1_ (u"ࠪ࠾ࠬ垟"))
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭垠"))
				title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ垡")+count+l1l111_l1_ (u"࠭ࠩࠨ垢")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垣"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ垤"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l1ll1l11l_l1_,l1l1lll111_l1_ in items:
			if title==l1l111_l1_ (u"ࠩࠪ垥") or l11l1ll1l11l_l1_==l1l111_l1_ (u"ࠪࠫ垦"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭垧")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ垨")+l1l1lll111_l1_+l1l111_l1_ (u"࠭ࠩࠨ垩")
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭垪"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ垫"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ垬"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll111_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ垭")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭垮"))
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ垯"))
		title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ垰")+name+l1l111_l1_ (u"ࠧࠪࠩ垱")
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ垲"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠩࠪ垳"),l1l1lll111_l1_)
	return
def l11l1ll11lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ垴"),url,l1l111_l1_ (u"ࠫࠬ垵"),l1l111_l1_ (u"ࠬ࠭垶"),l1l111_l1_ (u"࠭ࠧ垷"),l1l111_l1_ (u"ࠧࠨ垸"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡘࡋࡁࡓࡅࡋࡣࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ垹"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠡࡲ࠰࠵ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ垺"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ垻"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭垼")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ垽"))
		if l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠲࠭垾") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭垿"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ埀"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭埁"),url,l1l111_l1_ (u"ࠪࠫ埂"),l1l111_l1_ (u"ࠫࠬ埃"),l1l111_l1_ (u"ࠬ࠭埄"),l1l111_l1_ (u"࠭ࠧ埅"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ埆"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࡹࡩ࡯࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ埇"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡺ࡮ࡪࡥࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ埈"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ埉"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ埊"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭埋"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ埌"),l1l111_l1_ (u"ࠧࠬࠩ埍"))
	l11l1ll1l1l1_l1_ = [l1l111_l1_ (u"ࠨࠨࡷࡁࡦ࠭城"),l1l111_l1_ (u"ࠩࠩࡸࡂࡩࠧ埏"),l1l111_l1_ (u"ࠪࠪࡹࡃࡳࠨ埐")]
	if l11_l1_:
		l11l1ll11ll1_l1_ = [l1l111_l1_ (u"ࠫ็อัวࠩ埑"),l1l111_l1_ (u"ࠬหีะษิࠤ࠴ࠦๅอๆาࠫ埒"),l1l111_l1_ (u"࠭ๅใู฼ࠤฬ๊ี้ฬํࠫ埓")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢ࠰ࠤศิสาࠢส่อำหࠨ埔"), l11l1ll11ll1_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘࡥࠧ埕") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘࡥࠧ埖") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡗࡇࡍࡔ࡙࡟ࠨ埗") in options: l11l11l_l1_ = 2
	else: return
	type = l11l1ll1l1l1_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ埘")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ埙"),url,l1l111_l1_ (u"࠭ࠧ埚"),l1l111_l1_ (u"ࠧࠨ埛"),l1l111_l1_ (u"ࠨࠩ埜"),l1l111_l1_ (u"ࠩࠪ埝"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ埞"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ域"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ埠"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ埡"))
				name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ埢"))
				title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ埣")+name+l1l111_l1_ (u"ࠩࠬࠫ埤")
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ埥"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡸࡩࡄ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埦"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ埧"))
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ埨"))
				title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ埩")+name+l1l111_l1_ (u"ࠨࠫࠪ埪")
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ埫"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
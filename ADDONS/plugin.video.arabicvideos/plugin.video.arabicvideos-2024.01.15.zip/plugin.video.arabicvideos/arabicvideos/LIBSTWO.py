# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l111l1_l1_ import *
import bidi.algorithm,base64
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡃࡕࡗ࡛ࡔ࠭㍭")
contentsDICT = {}
menuItemsLIST = []
if PY3:
	l111l111111_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ㍮"))
	l1ll11ll11_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ㍯"))
	l11l1ll1l11_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬ㍰"))
	l111lll1l11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㍱"),l1l111_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㍲"),l1l111_l1_ (u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩ㍳"))
	l11ll11l111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㍴"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㍵"),l1l111_l1_ (u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ㍶"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍷"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㍸"),l1l111_l1_ (u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪ㍹"))
	half_triangular_colon = l1l111_l1_ (u"ࡹࠬࡢࡵ࠱࠴ࡧ࠵ࠬ㍺")
	from urllib.parse import quote as _111111ll11_l1_
else:
	l111l111111_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡺࡥࡱࡨ࠭㍻"))
	l1ll11ll11_l1_ = xbmc.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ㍼"))
	l11l1ll1l11_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫ㍽"))
	l111lll1l11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍾"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㍿"),l1l111_l1_ (u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ㎀"))
	l11ll11l111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㎁"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㎂"),l1l111_l1_ (u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭㎃"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㎄"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㎅"),l1l111_l1_ (u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩ㎆"))
	half_triangular_colon = l1l111_l1_ (u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫ㎇").encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㎈"))
	from urllib import quote as _111111ll11_l1_
l11l1111ll1_l1_ = os.path.join(l11l1ll1l11_l1_,l1l111_l1_ (u"ࠬࡱ࡯ࡥ࡫࠱ࡰࡴ࡭ࠧ㎉"))
l1111l1l1l1_l1_ = os.path.join(l11l1ll1l11_l1_,l1l111_l1_ (u"࠭࡫ࡰࡦ࡬࠲ࡴࡲࡤ࠯࡮ࡲ࡫ࠬ㎊"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠶ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㎋"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠸ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ㎌"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰ࠷ࡺࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㎍"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࠮ࡥࡣࡷࠫ㎎"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭㎏"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳ࠳ࡶࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭㎐"))
l1ll11lll1ll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡦࡤࡸࠬ㎑"))
addonimagesfolder = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪࡹࠧ㎒"))
l1lll1111l1l_l1_ = os.path.join(addonimagesfolder,l1l111_l1_ (u"ࠨࡦ࡬ࡥࡱࡵࡧࡴࠩ㎓"))
l1ll1l1l11l1_l1_ = os.path.join(l1lll1111l1l_l1_,l1l111_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬ㎔"))
l1l1l1l1lll_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠪࡴࡦࡺࡨࠨ㎕"))
defaulticon = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭㎖"))
defaultthumb = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ㎗"))
defaultfanart = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㎘"))
defaultbanner = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫ㎙"))
defaultlandscape = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨ㎚"))
defaultposter = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭㎛"))
defaultclearlogo = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪ㎜"))
defaultclearart = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㎝"))
defaultmenu = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷ࠱ࡴࡳ࡭ࠧ㎞"))
l1lll1lllll1_l1_ = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭㎟"))
l1lllll1ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㎠"))
l1lll1ll1l11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㎡"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㎢"),addon_id,l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㎣"))
fontfile = os.path.join(l111l111111_l1_,l1l111_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࠪ㎤"),l1l111_l1_ (u"ࠬࡌ࡯࡯ࡶࡶࠫ㎥"),l1l111_l1_ (u"࠭ࡡࡳ࡫ࡤࡰ࠳ࡺࡴࡧࠩ㎦"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ࠧึใิࠫ㎧"),l1l111_l1_ (u"ࠨล๋่ࠬ㎨"),l1l111_l1_ (u"ࠩฮห๋๐ࠧ㎩"),l1l111_l1_ (u"ࠪฯฬ๊หࠨ㎪"),l1l111_l1_ (u"ࠫึอศฺࠩ㎫"),l1l111_l1_ (u"ࠬิวๆีࠪ㎬"),l1l111_l1_ (u"࠭ำศัึࠫ㎭"),l1l111_l1_ (u"ࠧิษห฽ࠬ㎮"),l1l111_l1_ (u"ࠨอส้๋࠭㎯"),l1l111_l1_ (u"ࠩอหุ฿ࠧ㎰"),l1l111_l1_ (u"ࠪ฽ฬฺัࠨ㎱")]
l1111l1l111_l1_ = l1l111_l1_ (u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬ㎲")
l11ll11l_l1_ = 0
l1llll1ll11l_l1_ = 30*l1l1lll11l1_l1_
l111l11l_l1_ = 2*l1l1l111111_l1_
l11l1l1_l1_ = 16*l1l1l111111_l1_
l1lll11lll1_l1_ = 30*l1l11llll11_l1_
l1l11l1l11l_l1_ = 1*l1l1l111111_l1_
l1ll1ll1111l_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㎳")]
l1111llllll_l1_ = [l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㎴"),l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㎵"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ㎶"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㎷"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭㎸"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㎹"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ㎺"),l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㎻")]
l1111llllll_l1_ += [l1l111_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㎼"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㎽"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㎾"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㎿"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㏀"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㏁"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ㏂"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㏃")]
l1ll11lllll1_l1_ = [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㏄"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㏅"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㏆"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㏇")]
l1ll11lllll1_l1_ += [l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㏈"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ㏉"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㏊"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㏋")]
l1ll11lllll1_l1_ += [l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㏌"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ㏍"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ㏎")]
l1ll11lllll1_l1_ += [l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㏏"),l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㏐"),l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㏑"),l1l111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ㏒"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㏓"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㏔"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㏕")]
l1ll11lllll1_l1_ += [l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㏖"),l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㏗"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㏘"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㏙"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㏚"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㏛")]
l1ll1llll11_l1_ = [l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㏜"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭㏝"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㏞"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㏟")]
l1ll1llll11_l1_ += [l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㏠"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㏡"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㏢"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㏣"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ㏤")]
l1lll111l1l_l1_ = [l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㏥"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㏦"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㏧"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㏨"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㏩"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㏪")]
l1lll111l1l_l1_ += [l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㏫"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㏬"),l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㏭"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㏮"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㏯"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㏰")]
l1llll11111_l1_ = [l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㏱"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㏲"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㏳"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㏴"),l1l111_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㏵"),l1l111_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㏶"),l1l111_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㏷")]
l1llll11111_l1_ += [l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㏸"),l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㏹"),l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㏺"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㏻"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㏼"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㏽")]
l1llll111l11_l1_  = [l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㏾"),l1l111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ㏿"),l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㐀"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㐁"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㐂"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㐃"),l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㐄"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㐅")]
l1llll111l11_l1_ += [l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㐆"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㐇"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㐈"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㐉"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㐊"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭㐋"),l1l111_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ㐌"),l1l111_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ㐍"),l1l111_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭㐎")]
l1llll111l11_l1_ += [l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㐏"),l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㐐"),l1l111_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ㐑"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㐒"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㐓"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭㐔"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㐕")]
l1llll111l11_l1_ += [l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㐖"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㐗"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㐘"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ㐙"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ㐚"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㐛"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ㐜")]
l1llll111l11_l1_ += [l1l111_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭㐝"),l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㐞"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㐟"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ㐠"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ㐡"),l1l111_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㐢"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㐣")]
l1ll1lll1ll1_l1_  = [l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ㐤"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ㐥"),l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ㐦"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ㐧")]
l1ll1lll1ll1_l1_ += [l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ㐨"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ㐩")]
l1ll1lll1ll1_l1_ += [l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭㐪"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㐫"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㐬")]
l1ll1lll1ll1_l1_ += [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ㐭"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㐮"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ㐯")]
l1ll1lll1ll1_l1_ += [l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭㐰"),l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㐱"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ㐲")]
l1lll111lll1_l1_ = [l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ㐳"),l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㐴"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㐵"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㐶"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㐷")]
l1lll1l11l1_l1_ = l1llll111l11_l1_+l1ll1lll1ll1_l1_
l1lll1l1ll1l_l1_ = l1llll111l11_l1_+l1lll111lll1_l1_
l1l1111ll11_l1_ = l1llll111l11_l1_+l1ll1lll1ll1_l1_
l1lll1l111l_l1_ = l1ll11lllll1_l1_+l1lll111l1l_l1_+l1llll11111_l1_+l1ll1llll11_l1_
l1111l11111_l1_ = [
						l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ㐸")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ㐹")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡄࡒࡉࡕࡍࡠࡗࡖࡉࡗࡇࡇࡆࡐࡗ࠱࠶ࡹࡴࠨ㐺")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ㐻")
						,l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡄࡊࡈࡇࡐࡥࡁࡄࡅࡒ࡙ࡓ࡚࠭࠲ࡵࡷࠫ㐼")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭㐽")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨ㐾")
						,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ㐿")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪ㑀")
						,l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚࠭࠲ࡵࡷࠫ㑁")
						,l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ㑂")
						,l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠻ࡴࡩࠩ㑃")
						,l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ㑄")
						]
l11l1lll1ll_l1_ = l1111l11111_l1_+[
				 l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭㑅")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㑆")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㑇")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ㑈")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ㑉")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ㑊")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ㑋")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭㑌")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ㑍")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㑎")
				,l1l111_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㑏")
				,l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫ㑐")
				,l1l111_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬ㑑")
				,l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨ㑒")
				,l1l111_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ㑓")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㑔")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㑕")
				]
l111l11l1ll_l1_ = [l1l111_l1_ (u"ࠧ࠹࠰࠻࠲࠽࠴࠸ࠨ㑖"),l1l111_l1_ (u"ࠨ࠳࠱࠵࠳࠷࠮࠲ࠩ㑗"),l1l111_l1_ (u"ࠩ࠴࠲࠵࠴࠰࠯࠳ࠪ㑘"),l1l111_l1_ (u"ࠪ࠼࠳࠾࠮࠵࠰࠷ࠫ㑙"),l1l111_l1_ (u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠲࠯࠴࠵࠶ࠬ㑚"),l1l111_l1_ (u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠱࠰࠵࠶࠵࠭㑛")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㑜")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮ࡳࡦࡳ࠮࡯ࡧࡷࠫ㑝")]
			,l1l111_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ㑞")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫ㑟")]
			,l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㑠")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫ࡸࡣࡰ࠲ࡳ࡫ࡴࠨ㑡")]
			,l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㑢")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭ࠨ㑣")]
			,l1l111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ㑤")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡪࡦࡺࡩ࡮࡫࠱ࡸࡻ࠭㑥")]
			,l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㑦")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩ㑧")]
			,l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㑨")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱࠬ㑩")]
			,l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㑪")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡥࡧࡹࡥࡦࡦ࠱ࡲࡪࡺࠧ㑫")]
			,l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㑬")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡷࡱࡧ࠲ࡨࡵ࡭ࠨ㑭")]
			,l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㑮")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩ㑯")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㑰")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬ㑱")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㑲")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠴ࡧ࡮ࡳࡡ࠵ࡷ࠱ࡧࡴࡳࠧ㑳")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ㑴")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠵ࡥࡨࡴ࠴ࡣࡰ࡯ࠪ㑵")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭㑶")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡮࡭ࡳ࠭㑷")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㑸")	:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨ㑹")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㑺")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭㑻")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㑼")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠲࠷࠰ࡰࡽ࠲ࡩࡩ࡮ࡣ࠱ࡲࡪࡺࠧ㑽")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㑾")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡥࡦࠫ㑿")]
			,l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ㒀")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㒁"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ㒂")]
			,l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㒃")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡣ࠯ࡦࡵࡥࡲࡧࡳ࠸࠰ࡦࡳࡲ࠭㒄")]
			,l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ㒅")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯࠯ࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ㒆")]
			,l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㒇")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡧ࡫ࡳࡵ࠰ࡶࡸࡴࡸࡥࠨ㒈")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㒉")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪ㒊")]
			,l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭㒋")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ㒌")]
			,l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㒍")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ㒎")]
			,l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ㒏")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ㒐")]
			,l1l111_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㒑")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩ㒒")]
			,l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㒓")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫ㒔")]
			,l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㒕")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡦࡺࡳࡶࡪࡹࡳࠨ㒖")]
			,l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ㒗")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࡬ࡢ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩ㒘")]
			,l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㒙")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࡬࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩ㒚")]
			,l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㒛")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡱࡪࡪࡩࡢࠩ㒜")]
			,l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㒝")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㒞"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㒟"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㒠"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㒡"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭㒢")]
			,l1l111_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ㒣")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡥࡷࡨࡡ࡭ࡣ࠰ࡸࡻ࠴ࡩࡲࠩ㒤")]
			,l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ㒥")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵ࡯࠯࡭࡬ࡸࡰࡵࡴ࠯ࡶࡹࠫ㒦")]
			,l1l111_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ㒧")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ㒨"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࠰ࡩࡻࡸ࠴ࡳࡵࡱࡵࡩࠬ㒩")]
			,l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㒪")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡧࡦࡳࠧ㒫")]
			,l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ㒬")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬ㒭")]
			,l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㒮")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣࡤ࠲ࡨࡧ࡭ࠨ㒯")]
			,l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ㒰")	:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭㒱")]
			,l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㒲")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪ࠮ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪ㒳")]
			,l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㒴")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ㒵"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬ㒶"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ㒷")]
			,l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㒸")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲ࡹࡼࡦࡶࡰ࠱ࡱࡪ࠭㒹")]
			,l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㒺")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡽࡴ࠭࠮࠯࠰࠱࠲ࡴࡺࡦࡤࡦࡥ࠺࡭ࡤ࠸ࡱࡧࡩ࠵ࡨࡩࡨ࡮࡫࠲ࡲࡿࡣࡪ࡫ࡰࡥ࠲ࡽࡥࡤ࡫࡬ࡱࡦ࠴ࡳࡩࡱࡳࠫ㒻")]
			,l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㒼")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹ࠯ࡻࡤࡵࡴࡺ࠮ࡵࡸࠪ㒽")]
			,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㒾")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯ࠪ㒿")]
			,l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㓀")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㓁"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ㓂"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ㓃")]
			,l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐࠨ㓄")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㓅"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ㓆"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ㓇")]
			,l1l111_l1_ (u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪ㓈")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡱ࡯ࡥ࡫ࠪ㓉"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩࠩ㓊"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏࠨ㓋")]
			}
if 1:
	l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㓌")] = [l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㓍"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㓎"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㓏"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㓐"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㓑"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㓒"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㓓"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ㓔"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ㓕")]
	l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭㓖")] = [l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㓗"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㓘"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㓙"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㓚"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㓛"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㓜"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㓝"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ㓞"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭㓟")]
else:
	l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㓠")] = [l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㓡"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㓢"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㓣"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㓤"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㓥"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㓦"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㓧"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ㓨"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ㓩")]
	l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㓪")] = [l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㓫"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㓬"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㓭"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㓮"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㓯"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㓰"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㓱"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㓲"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ㓳")]
l111l1llll1_l1_ = [l1l111_l1_ (u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭㓴"),l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭㓵"),l1l111_l1_ (u"࠭ࡅࡎࡃࡌࡐࡘ࠭㓶"),l1l111_l1_ (u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ㓷"),l1l111_l1_ (u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ㓸"),l1l111_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㓹"),l1l111_l1_ (u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨ㓺"),l1l111_l1_ (u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬ㓻"),l1l111_l1_ (u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭㓼")]
l11l1l1l1l1_l1_ = [l1l111_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘ࠭㓽"),l1l111_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠹ࠩ㓾"),l1l111_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠻ࠪ㓿")]
class l1lll11l1111_l1_(l1l1l1lllll_l1_):
	def __init__(self,*args,**kwargs):
		self.l1l1111111l_l1_ = -1
	def onClick(self,l111l11lll1_l1_):
		if l111l11lll1_l1_>=9010: self.l1l1111111l_l1_ = l111l11lll1_l1_-9010
		self.delete()
	def l11l1l11lll_l1_(self,*args):
		self.l111ll1ll11_l1_,self.l1lll1111l11_l1_,self.l111111l11l_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1llll11ll11_l1_ = args[5],args[6]
		self.l1ll11lll111_l1_,self.l1ll1ll1l11l_l1_ = args[7],args[8]
		if self.l1ll11lll111_l1_>0 or self.l1ll1ll1l11l_l1_>0: self.l1lll1ll1lll_l1_ = True
		else: self.l1lll1ll1lll_l1_ = False
		self.l1111l1ll1l_l1_ = l1ll1l1l11l1_l1_.replace(l1l111_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ㔀"),l1l111_l1_ (u"ࠪࡣࠬ㔁")+str(time.time())+l1l111_l1_ (u"ࠫࡤ࠭㔂"))
		self.l1111l1ll1l_l1_ = self.l1111l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ㔃"),l1l111_l1_ (u"࠭࡜࡝࡞࡟ࠫ㔄")).replace(l1l111_l1_ (u"ࠧ࠰࠱ࠪ㔅"),l1l111_l1_ (u"ࠨ࠱࠲࠳࠴࠭㔆"))
		self.l11l11l1l11_l1_ = CREATE_IMAGE(self.l111ll1ll11_l1_,self.l1lll1111l11_l1_,self.l111111l11l_l1_,self.header,self.text,self.profile,self.l1llll11ll11_l1_,self.l1lll1ll1lll_l1_,self.l1111l1ll1l_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1111l1ll1l_l1_)
		self.getControl(9050).setHeight(self.l11l11l1l11_l1_)
		if not self.l1lll1111l11_l1_ and self.l111ll1ll11_l1_ and self.l111111l11l_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1111l1ll1l_l1_,self.l11l11l1l11_l1_
	def l11lllllll1_l1_(self):
		if self.l1ll11lll111_l1_:
			self.l1l11l11l1l_l1_ = threading.Thread(target=self.l1lllll11111_l1_,args=())
			self.l1l11l11l1l_l1_.start()
		else: self.l11l1l111l1_l1_()
	def l1lllll11111_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l111llll_l1_ in range(1,self.l1ll11lll111_l1_+1):
			time.sleep(1)
			l1ll11llll11_l1_ = int(100*l1l111llll_l1_/self.l1ll11lll111_l1_)
			self.l1ll1l1l1lll_l1_(l1ll11llll11_l1_)
			if self.l1l1111111l_l1_>0: break
		self.l11l1l111l1_l1_()
	def l11lll1l11l_l1_(self):
		if self.l1ll1ll1l11l_l1_:
			self.l1l11l11ll1_l1_ = threading.Thread(target=self.l1111ll1111_l1_,args=())
			self.l1l11l11ll1_l1_.start()
		else: self.l11l1l111l1_l1_()
	def l1111ll1111_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1ll11lll111_l1_)
		for l1l111llll_l1_ in range(self.l1ll1ll1l11l_l1_-1,-1,-1):
			time.sleep(1)
			l1ll11llll11_l1_ = int(100*l1l111llll_l1_/self.l1ll1ll1l11l_l1_)
			self.l1ll1l1l1lll_l1_(l1ll11llll11_l1_)
			if self.l1l1111111l_l1_>0: break
		if self.l1ll1ll1l11l_l1_>0: self.l1l1111111l_l1_ = 10
		self.delete()
	def l1ll1l1l1lll_l1_(self,l1ll11llll11_l1_):
		self.l1111l1l11l_l1_ = l1ll11llll11_l1_
		self.getControl(9020).setPercent(self.l1111l1l11l_l1_)
	def l11l1l111l1_l1_(self):
		if self.l111ll1ll11_l1_: self.getControl(9010).setEnabled(True)
		if self.l1lll1111l11_l1_: self.getControl(9011).setEnabled(True)
		if self.l111111l11l_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1111l1ll1l_l1_)
		except: pass
class l11l1l11l11_l1_():
	def __init__(self,l11_l1_=False,l1lll1lll1l1_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1lll1lll1l1_l1_ = l1lll1lll1l1_l1_
		self.l11l1ll1l1l_l1_,self.l1l1111l1ll_l1_ = [],[]
		self.l111l11llll_l1_,self.l111l111ll1_l1_ = {},{}
		self.l11l11111l1_l1_ = []
		self.l1ll1l1ll111_l1_,self.l1111l11l11_l1_,self.l11lllll111_l1_ = {},{},{}
	def l11l11ll1ll_l1_(self,id,func,*args):
		id = str(id)
		self.l111l11llll_l1_[id] = l1l111_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ㔇")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪࠫ㔈"),id)
		l1l111111ll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l11l11111l1_l1_.append(l1l111111ll_l1_)
		return l1l111111ll_l1_
	def start_new_thread(self,id,func,*args):
		l1l111111ll_l1_ = self.l11l11ll1ll_l1_(id,func,*args)
		l1l111111ll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1ll1l1ll111_l1_[id] = time.time()
		try:
			self.l111l111ll1_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ㔉") in str(func) and not self.l111l111ll1_l1_[id].succeeded:
				l1111lll1ll_l1_(l1l111_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫ㔊"))
			self.l11l1ll1l1l_l1_.append(id)
			self.l111l11llll_l1_[id] = l1l111_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㔋")
		except Exception as err:
			if self.l1lll1lll1l1_l1_:
				l111l1ll1ll_l1_ = traceback.format_exc()
				sys.stderr.write(l111l1ll1ll_l1_)
			self.l1l1111l1ll_l1_.append(id)
			self.l111l11llll_l1_[id] = l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㔌")
		self.l1111l11l11_l1_[id] = time.time()
		self.l11lllll111_l1_[id] = self.l1111l11l11_l1_[id] - self.l1ll1l1ll111_l1_[id]
	def l1lll1lll11l_l1_(self):
		for proc in self.l11l11111l1_l1_:
			proc.start()
	def l1ll1l111111_l1_(self):
		while l1l111_l1_ (u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩ㔍") in list(self.l111l11llll_l1_.values()): time.sleep(1.000)
def l1llll11l11l_l1_():
	l1lll1l111ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭㔎"))
	if l1lll1l111ll_l1_==l1l11l1l1l1_l1_:
		status,l111ll1l11l_l1_ = l1l111_l1_ (u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭㔏"),False
		return status,l111ll1l11l_l1_
	try: os.makedirs(addoncachefolder)
	except: pass
	status,l111ll1l11l_l1_ = l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ㔐"),True
	l11ll111l1l_l1_ = [l1l111_l1_ (u"ࠬ࠾࠮࠶࠰࠳ࠫ㔑"),l1l111_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ㔒"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬ㔓"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬ㔔"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭㔕"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧ㔖"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨ㔗"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩ㔘"),l1l111_l1_ (u"࠭࠲࠱࠴࠶࠲࠵࠼࠮࠱࠸ࠪ㔙"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠷࠰࠯࠴࠻ࠫ㔚"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠹࠴࠰࠲࠰࠴࠸ࠬ㔛")]
	l11111l111l_l1_ = l11ll111l1l_l1_[-1]
	l111lll11ll_l1_ = l1ll11lll1l1_l1_(l11111l111l_l1_)
	l1llllll1ll1_l1_ = l1ll11lll1l1_l1_(l1l11l1l1l1_l1_)
	if l1llllll1ll1_l1_>l111lll11ll_l1_:
		status = l1l111_l1_ (u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ㔜")
	return status,l111ll1l11l_l1_
def l1111l1111l_l1_():
	l11ll1l1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡩ࡮ࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㔝"))
	if not l11ll1l1l1l_l1_: l1lll1lll1_l1_ = 5001
	else:
		l1lll1lll1_l1_ = 0
		for root,dirs,l1l1111111_l1_ in os.walk(addonimagesfolder,topdown=False):
			l1lll1lll1_l1_ += len(l1l1111111_l1_)
	if l1lll1lll1_l1_>5000: l1llll1ll1_l1_(addonimagesfolder,True,False)
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡪ࡯ࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㔞"),str(now))
	return
def l1111lll1l1_l1_(l1lll11l11l_l1_,l1llllll111l_l1_):
	succeeded,l111l1ll11l_l1_,l11ll1ll1ll_l1_ = True,False,False
	type,name,l1l1l1l11l1_l1_,mode,l1l1ll111l1_l1_,l1l111l1l11_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
	l1ll1ll11111_l1_ = type,name,l1l1l1l11l1_l1_,mode,l1l1ll111l1_l1_,l1l111l1l11_l1_,text,l1l111_l1_ (u"ࠬ࠭㔟"),l1llllll1ll_l1_
	l1lll1ll111l_l1_ = int(mode)
	l1lll1ll1111_l1_ = int(l1lll1ll111l_l1_%10)
	l1lll1ll11l1_l1_ = int(l1lll1ll111l_l1_/10)
	l1ll11llllll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㔠"))
	l11l11lll1l_l1_,l111ll1l11l_l1_ = l1llll11l11l_l1_()
	if l111ll1l11l_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㔡"),l1l111_l1_ (u"ࠨࠩ㔢"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㔣"),l1l111_l1_ (u"ࠪฮ๊ࠦสฮัํฯࠥอไษำ้ห๊าࠠโ์ࠣะ์อาไ࡞ࡱษ้๏ࠠศๆศูิอัࠡำๅ้࠿ࡢ࡮࡝ࡰࠪ㔤")+l1l11l1l1l1_l1_)
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㔥"),l1l111_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㔦"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㔧"),l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ㔨"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㔩"),l1l111_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ㔪"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㔫"),l1l111_l1_ (u"ࠫࡎࡊࡓ࠳ࠩ㔬"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠱ࠨ㔭"),l1l111_l1_ (u"࠭ࠧ㔮"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡲࡷࡹࡧࠧ㔯"),l1l111_l1_ (u"ࠨࠩ㔰"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫ㔱"),l1l111_l1_ (u"ࠪࠫ㔲"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳ࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ㔳"),l1l111_l1_ (u"ࠬ࠭㔴"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㔵"),l1l111_l1_ (u"ࠧࠨ㔶"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡰࡰࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㔷"),l1l111_l1_ (u"ࠩࠪ㔸"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㔹"),l1l111_l1_ (u"ࠫࠬ㔺"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡫ࡰࡥ࡬࡫ࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㔻"),l1l111_l1_ (u"࠭ࠧ㔼"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㔽"),l1l111_l1_ (u"ࠨࠩ㔾"))
		if not settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡧ࡫ࡸࡣࡰ࠲ࡻ࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㔿")):
			l1ll1l11l11l_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㕀"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㕁"),l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࡣ࡛ࡋࡒࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠪ㕂"))
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ㕃"),l1ll1l11l11l_l1_)
		import l1l1l1111ll_l1_
		if l11l11lll1l_l1_==l1l111_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㕄"):
			l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㕅"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㕆")+addon_path+l1l111_l1_ (u"ࠪࠤࡢ࠭㕇"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ㕈"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ㕉"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ㕊"))
			l11ll111ll1_l1_(True,[main_dbfile])
		else:
			l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㕋"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ㕌")+addon_path+l1l111_l1_ (u"ࠩࠣࡡࠬ㕍"))
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㕎"),l1l111_l1_ (u"ࠫࠬ㕏"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㕐"),l1l111_l1_ (u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ㕑"))
			l11ll111ll1_l1_()
			FIX_ALL_DATABASES(False)
			l1l1l1111ll_l1_.l1lll111111l_l1_()
			l1l1l1111ll_l1_.l1l1l1llll1_l1_(l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㕒"),False)
			l1l1l1111ll_l1_.l1l1l1llll1_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ㕓"),False)
			l1l1l1111ll_l1_.l1111l1ll11_l1_(False)
			l1l1l1111ll_l1_.l1ll1llll1l1_l1_(False)
			l1l1l1111ll_l1_.l111lllll1l_l1_(l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㕔"),l1l111_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ㕕"),False)
			try:
				l11ll11111l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㕖"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㕗"),l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㕘"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㕙"))
				l111l11l1l1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ㕚"))
				l111l11l1l1_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ㕛"),l1l111_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ㕜"))
			except: pass
			try:
				l11ll11111l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㕝"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㕞"),l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㕟"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㕠"))
				l111l11l1l1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ㕡"))
				l111l11l1l1_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ㕢"),l1l111_l1_ (u"ࠪ࠷ࠬ㕣"))
			except: pass
			try:
				l11ll11111l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㕤"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㕥"),l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㕦"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㕧"))
				l111l11l1l1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㕨"))
				l111l11l1l1_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ㕩"),l1l111_l1_ (u"ࠪ࠶ࠬ㕪"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l11l111_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll11lll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㕫"),l1l11l1l1l1_l1_)
		l1l1l1111ll_l1_.l11lll111ll_l1_(False)
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㕬"))
	l1l111ll11_l1_ = l11lll1ll1l_l1_(l1llllll111l_l1_)
	l1l11lll1ll_l1_ = l11lll1ll1l_l1_(name)
	l111l11ll11_l1_ = [0,15,17,19,26,34,50,53]
	l1llll11llll_l1_ = [0,15,17,19,26,34,50,53]
	l11llllll11_l1_ = l1lll1ll11l1_l1_ not in l1llll11llll_l1_
	l1ll1l1111l1_l1_ = l1lll1ll11l1_l1_ in [23,28,71,72]
	l1lllll1ll1l_l1_ = l1lll1ll111l_l1_ in [265,270]
	l11111lll11_l1_ = (l11llllll11_l1_ or l1ll1l1111l1_l1_) and not l1lllll1ll1l_l1_
	l11ll1111ll_l1_ = l1ll11l1l1_l1_!=l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㕭") and (l1ll11l1l1_l1_!=l1l111_l1_ (u"ࠧࠨ㕮") or context==l1l111_l1_ (u"ࠨࠩ㕯"))
	l1lll1ll1l1l_l1_ = l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠽ࠨ㕰") in l1ll11l1l1_l1_
	l1ll1lllll1l_l1_ = l1lll1ll111l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1lll1ll1111_l1_==9 or l1lll1ll111l_l1_ in [145,516,523,45]
	l11lll1ll11_l1_ = not l1ll1lllll1l_l1_
	l11l1ll11l1_l1_ = not l1lll1_l1_
	l1llllll1l11_l1_ = l1l111ll11_l1_ in [l1l111_l1_ (u"ࠪࠫ㕱"),l1l111_l1_ (u"ࠫ࠳࠴ࠧ㕲")]
	l111lll1111_l1_ = l1llllll1l11_l1_ or l11lll1ll11_l1_
	l1111llll1l_l1_ = l1llllll1l11_l1_ or l11l1ll11l1_l1_ or l1lll1ll1l1l_l1_
	l1ll1ll111ll_l1_ = l1lll1ll111l_l1_ not in [260,261,265,270,330,540]
	if l1ll11llllll_l1_: l111ll1ll1l_l1_ = l1lll1_l1_ or l1ll1lllll1l_l1_
	else: l111ll1ll1l_l1_ = True
	l1ll1ll1ll_l1_ = l1lll1ll11l1_l1_ in [74,75]
	l1111ll11l1_l1_ = l1lll1ll111l_l1_ in [280,720]
	l111llll1ll_l1_ = not l1ll1ll1ll_l1_ and not l1111ll11l1_l1_
	l1ll1l111l1l_l1_ = l111lll1111_l1_ and l1111llll1l_l1_ and l1ll1ll111ll_l1_ and l111ll1ll1l_l1_ and l111llll1ll_l1_
	l11l1l1ll1l_l1_ = l1ll1ll111ll_l1_ and l111ll1ll1l_l1_ and l111llll1ll_l1_
	l11l1l1llll_l1_ = l11l1l1ll1l_l1_
	l1l1111lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡴࡷࡵࡶࡪࡦࡨࡶࠬ㕳"))
	l11l111l11l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡨࡵࡤࡦࠩ㕴"))
	if 1 and l11ll1111ll_l1_ and l1ll1l111l1l_l1_:
		l11111ll111_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㕵"),l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㕶")+l1l1111lll1_l1_+l1l111_l1_ (u"ࠩࡢࠫ㕷")+l11l111l11l_l1_,l1ll1ll11111_l1_)
		if l11111ll111_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࠫ㕸"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㕹")+l1l1111lll1_l1_+l1l111_l1_ (u"ࠬࡥࠧ㕺")+l11l111l11l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ㕻"))
			if 1 and l1lll1ll1l1l_l1_:
				l11lll11ll1_l1_ = []
				from l1ll1ll1ll11_l1_ import l11111l1l11_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1llllll11l1_l1_ = l11111l1l11_l1_
				l11lll11111_l1_ = GET_ALL_FAVORITES()
				l111l1l11l1_l1_ = l1ll11l1l1_l1_
				l11l1l1l1ll_l1_,l11l1ll1ll1_l1_,l1lllll1lll1_l1_,l1lll1l1l1ll_l1_,l11ll11ll11_l1_,l1111ll1ll1_l1_,l11l1ll1lll_l1_,l1llll1l1ll1_l1_,l1111lllll1_l1_ = EXTRACT_KODI_PATH(l111l1l11l1_l1_)
				l1llllll11ll_l1_ = l11l1l1l1ll_l1_,l11l1ll1ll1_l1_,l1lllll1lll1_l1_,l1lll1l1l1ll_l1_,l11ll11ll11_l1_,l1111ll1ll1_l1_,l11l1ll1lll_l1_,l1l111_l1_ (u"ࠧࠨ㕼"),l1111lllll1_l1_
				for l1l1111llll_l1_ in l11111ll111_l1_:
					l1lll11l1l11_l1_ = l1l1111llll_l1_[l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ㕽")]
					if l1lll11l1l11_l1_==l1llllll11ll_l1_ or l1l1111llll_l1_[l1l111_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ㕾")] in [265,270]:
						l1l1111llll_l1_ = GET_LIST_ITEM(l1lll11l1l11_l1_,l1llllll11l1_l1_,l11lll11111_l1_)
						if l1l1111llll_l1_[l1l111_l1_ (u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭㕿")]:
							l1lll1l11l11_l1_ = GET_FAVORITES_CONTEXT_MENU(l11lll11111_l1_,l1lll11l1l11_l1_,l1l1111llll_l1_[l1l111_l1_ (u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬ㖀")])
							l1l1111llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㖁")] = l1lll1l11l11_l1_+l1l1111llll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㖂")]
					l11lll11ll1_l1_.append(l1l1111llll_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㖃"),l1l111_l1_ (u"ࠨࠩ㖄"))
				if type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㖅"): l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㖆")+l1l1111lll1_l1_+l1l111_l1_ (u"ࠫࡤ࠭㖇")+l11l111l11l_l1_,l1ll1ll11111_l1_,l11lll11ll1_l1_,l11l1l1_l1_)
			else: l11lll11ll1_l1_ = l11111ll111_l1_
			if type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㖈") and l1l111ll11_l1_!=l1l111_l1_ (u"࠭࠮࠯ࠩ㖉") and l11111lll11_l1_: l1l1l1lll1l_l1_()
			l11l1llllll_l1_ = CREATE_KODI_MENU(l1ll1ll11111_l1_,l11lll11ll1_l1_,succeeded,l111l1ll11l_l1_,l11ll1ll1ll_l1_)
			return
	elif type==l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖊") and l1ll11l1l1_l1_==l1l111_l1_ (u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ㖋") and l11l1l1ll1l_l1_:
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㖌")+l1l1111lll1_l1_+l1l111_l1_ (u"ࠪࡣࠬ㖍")+l11l111l11l_l1_,l1ll1ll11111_l1_)
	if l1l111_l1_ (u"ࠫࡤ࠭㖎") in context: l1llll1l111l_l1_,l1llll1l11l1_l1_ = context.split(l1l111_l1_ (u"ࠬࡥࠧ㖏"),1)
	else: l1llll1l111l_l1_,l1llll1l11l1_l1_ = context,l1l111_l1_ (u"࠭ࠧ㖐")
	if l1llll1l111l_l1_ in [l1l111_l1_ (u"ࠧ࠲ࠩ㖑"),l1l111_l1_ (u"ࠨ࠴ࠪ㖒"),l1l111_l1_ (u"ࠩ࠶ࠫ㖓"),l1l111_l1_ (u"ࠪ࠸ࠬ㖔"),l1l111_l1_ (u"ࠫ࠺࠭㖕")] and l1llll1l11l1_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㖖"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㖗"))
		return
	elif l1llll1l111l_l1_==l1l111_l1_ (u"ࠧ࠷ࠩ㖘"):
		if l1llll1l11l1_l1_==l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㖙"): l1ll1lll_l1_(l1l111_l1_ (u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ㖚"),l1l111_l1_ (u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ㖛"))
		elif l1llll1l11l1_l1_==l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠫ㖜"): l1lll1ll111l_l1_ = 334
		l1lll_l1_ = l1lll11l1ll1_l1_(type,l1l11lll1ll_l1_,l1l1l1l11l1_l1_,l1lll1ll111l_l1_,l1l1ll111l1_l1_,l1l111l1l11_l1_,text,context,l1llllll1ll_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㖝"))
		return
	elif context==l1l111_l1_ (u"࠭࠷ࠨ㖞"):
		from l1111l1l11_l1_ import l1lll111ll1_l1_
		l1lll111ll1_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㖟"))
		return
	elif context==l1l111_l1_ (u"ࠨ࠺ࠪ㖠"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㖡")+addon_id+l1l111_l1_ (u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ㖢")+str(mode)+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ㖣"))
		return
	elif context==l1l111_l1_ (u"ࠬ࠿ࠧ㖤"):
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㖥"),l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㖦"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㖧"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㖨")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㖩"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㖪"),l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㖫")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㖬"),l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㖭"))
	if not settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ㖮")): settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ㖯"),l111l11l1ll_l1_[0])
	l11ll1l1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡩ࡮ࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㖰"))
	l11ll1l1l1l_l1_ = 0 if not l11ll1l1l1l_l1_ else int(l11ll1l1l1l_l1_)
	if not l11ll1l1l1l_l1_ or now-l11ll1l1l1l_l1_<=0 or now-l11ll1l1l1l_l1_>l11l1l1_l1_:
		l1l111111ll_l1_ = threading.Thread(target=l1111l1111l_l1_)
		l1l111111ll_l1_.start()
	l1ll1l11llll_l1_ = False if l1l11ll1lll_l1_(l1l111_l1_ (u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬ㖱")) else True
	l1l11111111_l1_ = l111l11l_l1_ if l1ll1l11llll_l1_ else l11l1l1_l1_
	l11lll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㖲"))
	l1ll1ll11l11_l1_ = l1111lll11l_l1_(settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㖳")))
	l1ll1ll11l11_l1_ = 0 if not l1ll1ll11l11_l1_ else int(l1ll1ll11l11_l1_)
	if l11lll1llll_l1_ in [l1l111_l1_ (u"ࠧࠨ㖴"),l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘࠧ㖵")] or not l1l11111111_l1_ or not l1ll1ll11l11_l1_ or now-l1ll1ll11l11_l1_<0 or now-l1ll1ll11l11_l1_>l1l11111111_l1_:
		l11lll1llll_l1_ = l1ll1ll11lll_l1_(True,False)
	l11lllll11l_l1_ = l1111lll11l_l1_(settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ㖶")))
	l11lllll11l_l1_ = 0 if not l11lllll11l_l1_ else int(l11lllll11l_l1_)
	l11l1ll11ll_l1_ = l1111lll11l_l1_(settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㖷")))
	l11l1ll11ll_l1_ = 0 if not l11l1ll11ll_l1_ else int(l11l1ll11ll_l1_)
	if not l11lllll11l_l1_ or not l11l1ll11ll_l1_ or now-l11l1ll11ll_l1_<0 or now-l11l1ll11ll_l1_>l11lllll11l_l1_:
		l1lll1l11111_l1_ = 1
		if l1ll1l11llll_l1_:
			l1lll11l1l1l_l1_ = l11llll1l1l_l1_(True)
			if len(l1lll11l1l1l_l1_)>1:
				l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㖸"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㖹")+addon_path+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㖺"))
				id,l1l111llll1_l1_,l111l1l1ll1_l1_,l11l1l11111_l1_,l11l11lll11_l1_,reason = l1lll11l1l1l_l1_[0]
				l111l1l1111_l1_,l111l1l111l_l1_ = l11l1l11111_l1_.split(l1l111_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㖻"))
				del l1lll11l1l1l_l1_[0]
				l1lll1ll11ll_l1_ = random.sample(l1lll11l1l1l_l1_,1)
				id,l1l111llll1_l1_,l111l1l1ll1_l1_,l11l1l11111_l1_,l11l11lll11_l1_,reason = l1lll1ll11ll_l1_[0]
				l111l1l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ㖼")+id+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㖽")+l111l1l1ll1_l1_
				l11l11lll11_l1_ = l1l111_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ㖾")
				l1111l1l111_l1_ = l1l111_l1_ (u"ࠫฬ๊สษำ฼หฯ࠭㖿")
				l111ll1ll11_l1_,l1lll1111l11_l1_ = l11l1l11111_l1_,l11l11lll11_l1_
				l111llll_l1_ = [l111ll1ll11_l1_,l1lll1111l11_l1_,l1111l1l111_l1_]
				l11l11l111l_l1_ = 1 if l1l11ll1lll_l1_(l1l111_l1_ (u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭㗀")) else 10
				l11l11l11l1_l1_ = -9
				while l11l11l11l1_l1_<0:
					l11l1lll1l1_l1_ = random.sample(l111llll_l1_,3)
					l11l11l11l1_l1_ = l1ll1l111ll1_l1_(l1l111_l1_ (u"࠭ࠧ㗁"),l11l1lll1l1_l1_[0],l11l1lll1l1_l1_[1],l11l1lll1l1_l1_[2],l111l1l1111_l1_,l111l1l1ll1_l1_,l1l111_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㗂"),l11l11l111l_l1_,60)
					if l11l11l11l1_l1_==10: break
					from l1l1l1111ll_l1_ import l1llll111111_l1_,l1l1l1l1l1l_l1_
					if l11l11l11l1_l1_>=0 and l11l1lll1l1_l1_[l11l11l11l1_l1_]==l111llll_l1_[1]:
						l1llll111111_l1_()
						if l11l11l11l1_l1_>=0: l11l11l11l1_l1_ = -9
					elif l11l11l11l1_l1_>=0 and l11l1lll1l1_l1_[l11l11l11l1_l1_]==l111llll_l1_[2]:
						l1l1l1l1l1l_l1_(False)
					if l11l11l11l1_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㗃"),l1l111_l1_ (u"ࠩࠪ㗄"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㗅"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ࠭㗆"))
				l1lll1l11111_l1_ = 1
			else: l1lll1l11111_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㗇"),l1llll1111ll_l1_(now))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㗈"),l1l111_l1_ (u"ࠧࡂࡗࡗࡌࠬ㗉"),l1lll1l11111_l1_,l1ll111ll11_l1_)
	l1lll_l1_ = l1lll11l1ll1_l1_(type,l1l11lll1ll_l1_,l1l1l1l11l1_l1_,mode,l1l1ll111l1_l1_,l1l111l1l11_l1_,text,context,l1llllll1ll_l1_)
	if l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㗊") in text: l111l1ll11l_l1_ = True
	if type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㗋"):
		if l1l111ll11_l1_!=l1l111_l1_ (u"ࠪ࠲࠳࠭㗌") and l11111lll11_l1_: l1l1l1lll1l_l1_()
		if addon_handle>-1:
			if (l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫ࡮ࡴࡴࠨ㗍"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㗎"),l1l111_l1_ (u"࠭ࡁࡖࡖࡋࠫ㗏")) or l1lll1ll111l_l1_ not in l111l11ll11_l1_) and not l1l11ll1lll_l1_(l1l111_l1_ (u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ㗐")):
				from l1ll1ll1ll11_l1_ import l11111l1l11_l1_
				l11111ll111_l1_ = GET_ALL_LIST_ITEMS(l11111l1l11_l1_)
				l11l1llllll_l1_ = CREATE_KODI_MENU(l1ll1ll11111_l1_,l11111ll111_l1_,succeeded,l111l1ll11l_l1_,l11ll1ll1ll_l1_)
				if 1 and l11111ll111_l1_ and l11l1l1llll_l1_:
					l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㗑")+l1l1111lll1_l1_+l1l111_l1_ (u"ࠩࡢࠫ㗒")+l11l111l11l_l1_,l1ll1ll11111_l1_,l11111ll111_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㗓")+addon_id+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㗔"),xbmcgui.ListItem(l1l111_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไส่๊ࠢࠥา็ศิๆࠫ㗕")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㗖")+addon_id+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ㗗"),xbmcgui.ListItem(l1l111_l1_ (u"ࠨลไฮาࠦไหไิวࠥอไหใสู๏๊ࠧ㗘")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l1ll11l_l1_,l11ll1ll1ll_l1_)
	return
def l1lll11l1ll1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_):
	l1lll1ll111l_l1_ = int(mode)
	l1lll1ll11l1_l1_ = int(l1lll1ll111l_l1_//10)
	if   l1lll1ll11l1_l1_==0:  from l1l1l1111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,text)
	elif l1lll1ll11l1_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==2:  from l1ll1lll11l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==3:  from l11l1l1l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,l1llllll1_l1_)
	elif l1lll1ll11l1_l1_==5:  from l11llll1lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==8:  from l1ll1lll1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==9:  from l111111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==10: from l1llllll1111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url)
	elif l1lll1ll11l1_l1_==11: from l1lll111l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==12: from l11l11ll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==14: from l11lll1l1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1lll1ll11l1_l1_==15: from l1l1l1111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,text)
	elif l1lll1ll11l1_l1_==16: from l1ll1lllll1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1ll11l1_l1_==17: from l1l1l1111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,text)
	elif l1lll1ll11l1_l1_==18: from l1ll1l11l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==19: from l1l1l1111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,text)
	elif l1lll1ll11l1_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==21: from l11l11l1111_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==22: from l111l1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1ll11l1_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==26: from l1ll1ll1ll11_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1lll1ll111l_l1_,context)
	elif l1lll1ll11l1_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1ll11l1_l1_==29: from l11ll1l11l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==30: from l1lllllll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==31: from l11l1l1lll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==32: from l1ll1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==33: from l11lll1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url)
	elif l1lll1ll11l1_l1_==34: from l1l1l1111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,text)
	elif l1lll1ll11l1_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==36: from l1llll1llll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==38: from l1lll1l1ll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==39: from l1lllll1111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==40: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll1ll11l1_l1_==41: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll1ll11l1_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==43: from l111l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==44: from l111l11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==45: from l1l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==46: from l1111llll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==47: from l11111111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==48: from l1ll1lll111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==49: from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==50: from l1l1l1111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,text)
	elif l1lll1ll11l1_l1_==51: from l1111l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==52: from l1111l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==53: from l1ll1ll1ll11_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==54: from l1111l1l11_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,l1llllll1_l1_)
	elif l1lll1ll11l1_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==56: from l1lll11l111l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==57: from l1llll1ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==58: from l11ll1llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==59: from l1llll11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==60: from l1llll11l1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==62: from l1lllll1l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==63: from l11111ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==64: from l111l1ll111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==66: from l11lll1lll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==67: from l1ll11lll1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==68: from l11ll1l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==70: from l1ll111lll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1ll11l1_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll1ll111l_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1ll11l1_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==74: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_)
	elif l1lll1ll11l1_l1_==75: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_)
	elif l1lll1ll11l1_l1_==76: from l1ll1lllll1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1ll11l1_l1_==77: from l111llll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==78: from l111ll1l1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==79: from l111ll11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==80: from l111l1lll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	elif l1lll1ll11l1_l1_==81: from l1ll1l11111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,text)
	elif l1lll1ll11l1_l1_==82: from l1111ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll1ll111l_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l11111l1l1l_l1_(code,reason,source,l11_l1_):
	l1111ll111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㗙"))
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㗚"),l1l111_l1_ (u"ࠫࠬ㗛"))
	if l1l111_l1_ (u"ࠬ࠳ࠧ㗜") in source: l1lll11ll1l_l1_ = source.split(l1l111_l1_ (u"࠭࠭ࠨ㗝"),1)[0]
	else: l1lll11ll1l_l1_ = source
	l11ll111111_l1_ = code in [7,11001,11002,10054]
	l1ll1l111l11_l1_ = reason.lower()
	l111lll111l_l1_ = code in [0,104,10061,111]
	l111111l111_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㗞") in l1ll1l111l11_l1_
	l1111111lll_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ㗟") in l1ll1l111l11_l1_
	l1111111ll1_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㗠") in l1ll1l111l11_l1_
	l1111111l1l_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ㗡") in l1ll1l111l11_l1_
	l1lll1111111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㗢"))
	l1ll1ll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㗣"))
	l111l111l11_l1_ = l1l111_l1_ (u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ㗤")
	l1111ll1lll_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠧ㗥")+str(code)+l1l111_l1_ (u"ࠨ࠼ࠣࠫ㗦")+reason
	l1111ll1lll_l1_ = l111l11_l1_(l1111ll1lll_l1_)
	if l111lll111l_l1_ or l111111l111_l1_ or l1111111lll_l1_ or l1111111ll1_l1_ or l1111111l1l_l1_:
		l111l111l11_l1_ += l1l111_l1_ (u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ㗧")
	if l11ll111111_l1_: l111l111l11_l1_ += l1l111_l1_ (u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ㗨")
	l1111ll1lll_l1_ = l1l111_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㗩")+l1111ll1lll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㗪")
	if l1lll1111111_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㗫") or l1ll1ll1llll_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㗬"):
		l111l111l11_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣร࡛ࠦࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗭")
	l11llll111l_l1_ = False
	if l11_l1_ and source not in l1111l11111_l1_:
		if l1lll1111111_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㗮") or l1ll1ll1llll_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㗯"):
			l11l11l11l1_l1_ = l1ll1l111ll1_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㗰"),l1l111_l1_ (u"ࠬิั้ฮࠪ㗱"),l1l111_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠫ㗲"),l1l111_l1_ (u"ࠧฦื็หาࠦวๅ็ื็้ฯࠧ㗳"),l1lll11ll1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠬ㗴")+TRANSLATE(l1lll11ll1l_l1_),l111l111l11_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㗵")+l1111ll1lll_l1_)
			if l11l11l11l1_l1_==1:
				from l1l1l1111ll_l1_ import l1llll111111_l1_
				l1llll111111_l1_()
			elif l11l11l11l1_l1_==2: l11llll111l_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㗶"),l1l111_l1_ (u"ࠫࠬ㗷"),l1lll11ll1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㗸")+TRANSLATE(l1lll11ll1l_l1_),l111l111l11_l1_,l1111ll1lll_l1_)
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㗹"),l1111ll111l_l1_)
	return l11llll111l_l1_
def l11ll111ll1_l1_(l1ll1ll1l1l1_l1_=False,l1ll1lllll11_l1_=[]):
	l111l111lll_l1_ = [l1l1l11l111_l1_,favoritesfile,l1ll11lll1ll_l1_]+l1ll1lllll11_l1_
	for filename in os.listdir(addoncachefolder):
		if l1ll1ll1l1l1_l1_ and (filename.startswith(l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ㗺")) or filename.startswith(l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ㗻"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ㗼")): continue
		l11111ll1ll_l1_ = os.path.join(addoncachefolder,filename)
		if l11111ll1ll_l1_ in l111l111lll_l1_: continue
		try: os.remove(l11111ll1ll_l1_)
		except: pass
	if addonimagesfolder not in l111l111lll_l1_: l1llll1ll1_l1_(addonimagesfolder,True,False)
	time.sleep(1)
	return
def l1lllll11lll_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll111_l1_=True,l1llll111lll_l1_=True):
	url = url+l1l111_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ㗽")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll111_l1_,l1llll111lll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l1111lll1ll_l1_(l1l111_l1_ (u"ࠫࡍ࡚ࡔࡑࠢࡕࡩࡶࡻࡥࡴࡶࠣࡊࡦ࡯࡬ࡶࡴࡨࠫ㗾"))
	return response
def l1ll1ll1ll1l_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㗿"),url,l1l111_l1_ (u"࠭ࠧ㘀"),l1l111_l1_ (u"ࠧࠨ㘁"),True,l1l111_l1_ (u"ࠨࠩ㘂"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㘃"),True,False)
	l1l1111l1l1_l1_ = []
	if response.succeeded:
		html = response.content
		l1llll11111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭㘄"),html)
		if l1llll11111l_l1_: html = l1l111_l1_ (u"ࠫࡡࡴࠧ㘅").join(l1llll11111l_l1_)
		proxies = html.replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㘆"),l1l111_l1_ (u"࠭ࠧ㘇")).strip(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㘈")).split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㘉"))
		l1l1111l1l1_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠩ࠱ࠫ㘊"))==3: l1l1111l1l1_l1_.append(proxy)
	return l1l1111l1l1_l1_
def l11ll1ll1l1_l1_(*args):
	l11lllll1l1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡲࡵࡳࡽࡿࡳࡤࡴࡤࡴࡪ࠴ࡣࡰ࡯࠲ࡺ࠷࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ㘋")
	l111111ll1l_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡴࡵࡳࡵࡧࡵ࡯࡮ࡪ࠯ࡰࡲࡨࡲࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯࡮ࡣ࡬ࡲ࠴ࡎࡔࡕࡒࡖ࠲ࡹࡾࡴࠨ㘌")
	l111ll1llll_l1_ = l1ll1ll1ll1l_l1_(l111111ll1l_l1_)
	l1l1111l1l1_l1_ = l1ll1ll1ll1l_l1_(l11lllll1l1_l1_)
	l1l11111ll1_l1_ = l111ll1llll_l1_+l1l1111l1l1_l1_
	l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㘍"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬ㘎")+str(len(l111ll1llll_l1_))+l1l111_l1_ (u"ࠧࠬࠩ㘏")+str(len(l1l1111l1l1_l1_))+l1l111_l1_ (u"ࠨࠢࡠࠫ㘐"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㘑"))
	response = l1l1llllll1_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ㘒"),l1l111_l1_ (u"ࠫࠬ㘓"))
	if proxy or l1l11111ll1_l1_:
		id,l1l111l11l1_l1_ = 0,10
		l111llllll1_l1_ = len(l1l11111ll1_l1_)
		l11l111ll1l_l1_ = l1l111l11l1_l1_
		if l111llllll1_l1_>l11l111ll1l_l1_: counts = l11l111ll1l_l1_
		else: counts = l111llllll1_l1_
		l11l1lll11l_l1_ = random.sample(l1l11111ll1_l1_,counts)
		if proxy: l11l1lll11l_l1_ = [proxy]+l11l1lll11l_l1_
		threads = l11l1l11l11_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l111l11l1_l1_ and not threads.l11l1ll1l1l_l1_:
			if id<counts:
				proxy = l11l1lll11l_l1_[id]
				threads.start_new_thread(id,l1lllll11lll_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㘔"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㘕")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㘖"))
		l11l1ll1l1l_l1_ = threads.l11l1ll1l1l_l1_
		if l11l1ll1l1l_l1_:
			l111l111ll1_l1_ = threads.l111l111ll1_l1_
			l1111ll1l1l_l1_ = l11l1ll1l1l_l1_[0]
			response = l111l111ll1_l1_[l1111ll1l1l_l1_]
			proxy = l11l1lll11l_l1_[int(l1111ll1l1l_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㘗"),proxy)
			if l1111ll1l1l_l1_!=0: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㘘"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㘙")+proxy+l1l111_l1_ (u"ࠫࠥࡣࠧ㘚"))
			else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㘛"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㘜")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㘝"))
	return response
def l1ll1l1llll1_l1_(connection,l1ll1l11lll1_l1_):
	l11l11llll1_l1_ = connection.create_connection
	def l1lll11ll11l_l1_(address,*args,**kwargs):
		host,port = address
		l1lll1ll1ll1_l1_ = DNS_RESOLVER(host,l1ll1l11lll1_l1_)
		if l1lll1ll1ll1_l1_: host = l1lll1ll1ll1_l1_[0]
		else:
			if l1ll1l11lll1_l1_ in l111l11l1ll_l1_: l111l11l1ll_l1_.remove(l1ll1l11lll1_l1_)
			if l111l11l1ll_l1_:
				l11l1111l11_l1_ = l111l11l1ll_l1_[0]
				l1lll1ll1ll1_l1_ = DNS_RESOLVER(host,l11l1111l11_l1_)
				if l1lll1ll1ll1_l1_: host = l1lll1ll1ll1_l1_[0]
		address = (host,port)
		return l11l11llll1_l1_(address,*args,**kwargs)
	connection.create_connection = l1lll11ll11l_l1_
	return l11l11llll1_l1_
def l1ll1l11l111_l1_(url):
	l11ll111l11_l1_,l111ll11l11_l1_ = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ㘞"))[2],80
	if l1l111_l1_ (u"ࠩ࠽ࠫ㘟") in l11ll111l11_l1_: l11ll111l11_l1_,l111ll11l11_l1_ = l11ll111l11_l1_.split(l1l111_l1_ (u"ࠪ࠾ࠬ㘠"))
	l11l11l1lll_l1_ = l1l111_l1_ (u"ࠫ࠴࠭㘡")+l1l111_l1_ (u"ࠬ࠵ࠧ㘢").join(url.split(l1l111_l1_ (u"࠭࠯ࠨ㘣"))[3:])
	request = l1l111_l1_ (u"ࠧࡈࡇࡗࠤࠬ㘤")+l11l11l1lll_l1_+l1l111_l1_ (u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ㘥")
	request += l1l111_l1_ (u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ㘦")+l11ll111l11_l1_+l1l111_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ㘧")
	request += l1l111_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㘨")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11ll111l11_l1_,l111ll11l11_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"ࠬ࠭㘩")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"࠭࠮ࠨ㘪") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ㘫")
	l1lll11llll1_l1_,l1lll11lll1l_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠰ࠪ㘬"),1)
	l1lll11lll11_l1_,l1lll11ll1ll_l1_ = l1lll11lll1l_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ㘭"),1)
	server = l1lll11llll1_l1_+l1l111_l1_ (u"ࠪ࠲ࠬ㘮")+l1lll11lll11_l1_
	if type in [l1l111_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ㘯"),l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㘰")] and l1l111_l1_ (u"࠭࠯ࠨ㘱") in server: server = server.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩ㘲"),1)[1]
	if type==l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㘳") and l1l111_l1_ (u"ࠩ࠱ࠫ㘴") in server:
		l1llll11ll1l_l1_ = server.split(l1l111_l1_ (u"ࠪ࠲ࠬ㘵"))
		l1l1l1l1111_l1_ = len(l1llll11ll1l_l1_)
		if l1l1l1l1111_l1_<=2 or l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㘶") in server: l1llll11ll1l_l1_ = l1llll11ll1l_l1_[0]
		elif l1l1l1l1111_l1_>=3: l1llll11ll1l_l1_ = l1llll11ll1l_l1_[1]
		if len(l1llll11ll1l_l1_)>1: server = l1llll11ll1l_l1_
	return server
def l111lllllll_l1_(l11l1l11ll1_l1_):
	l11l11l11ll_l1_ = repr(l11l1l11ll1_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㘷"))).replace(l1l111_l1_ (u"ࠨࠧࠣ㘸"),l1l111_l1_ (u"ࠧࠨ㘹"))
	return l11l11l11ll_l1_
def l1ll11l11ll_l1_(string):
	l1ll1l1lllll_l1_ = l1l111_l1_ (u"ࠨࠩ㘺")
	if PY2: string = string.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㘻"))
	from unicodedata import decomposition
	for l1111l11l1l_l1_ in string:
		if   l1111l11l1l_l1_==l1l111_l1_ (u"ࡸࠫว࠭㘼"): l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ㘽")
		elif l1111l11l1l_l1_==l1l111_l1_ (u"ࡺ࠭รࠨ㘾"): l11l11l1l1l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧ㘿")
		elif l1111l11l1l_l1_==l1l111_l1_ (u"ࡵࠨฦࠪ㙀"): l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ㙁")
		elif l1111l11l1l_l1_==l1l111_l1_ (u"ࡷࠪษࠬ㙂"): l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ㙃")
		elif l1111l11l1l_l1_==l1l111_l1_ (u"ࡹࠬฬࠧ㙄"): l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭㙅")
		else:
			l1ll11ll1l1l_l1_ = decomposition(l1111l11l1l_l1_)
			if l1l111_l1_ (u"࠭ࠠࠨ㙆") in l1ll11ll1l1l_l1_: l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸࠫ㙇")+l1ll11ll1l1l_l1_.split(l1l111_l1_ (u"ࠨࠢࠪ㙈"),1)[1]
			else:
				l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ㙉")+hex(ord(l1111l11l1l_l1_)).replace(l1l111_l1_ (u"ࠪ࠴ࡽ࠭㙊"),l1l111_l1_ (u"ࠫࠬ㙋"))
				l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶࠩ㙌")+l11l11l1l1l_l1_[-4:]
		l1ll1l1lllll_l1_ += l11l11l1l1l_l1_
	l1ll1l1lllll_l1_ = l1ll1l1lllll_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧ㙍"),l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨ㙎"))
	if PY2: l1ll1l1lllll_l1_ = l1ll1l1lllll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㙏")).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㙐"))
	else: l1ll1l1lllll_l1_ = l1ll1l1lllll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㙑")).decode(l1l111_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㙒"))
	return l1ll1l1lllll_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"๊่ࠬฮหࠣห้๋แศฬํัࠬ㙓"),default=l1l111_l1_ (u"࠭ࠧ㙔"),l11l111l1ll_l1_=False,source=l1l111_l1_ (u"ࠧࠨ㙕")):
	text = l1lll1lll1ll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠨࠢࠣࠫ㙖"),l1l111_l1_ (u"ࠩࠣࠫ㙗")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭㙘"),l1l111_l1_ (u"ࠫࠥ࠭㙙")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ㙚"),l1l111_l1_ (u"࠭ࠠࠨ㙛"))
	if not text and not l11l111l1ll_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㙜"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ㙝")+text+l1l111_l1_ (u"ࠩࠥࠫ㙞"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㙟"),l1l111_l1_ (u"ࠫࠬ㙠"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㙡"),l1l111_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩ㙢"))
		return l1l111_l1_ (u"ࠧࠨ㙣")
	if text not in [l1l111_l1_ (u"ࠨࠩ㙤"),l1l111_l1_ (u"ࠩࠣࠫ㙥")]:
		text = text.strip(l1l111_l1_ (u"ࠪࠤࠬ㙦"))
		text = l1ll11l11ll_l1_(text)
	if source!=l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭㙧") and l11111l_l1_(l1l111_l1_ (u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧ㙨"),l1l111_l1_ (u"࠭ࠧ㙩"),[text],False):
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㙪"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ㙫")+text+l1l111_l1_ (u"ࠩࠥࠫ㙬"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㙭"),l1l111_l1_ (u"ࠫࠬ㙮"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㙯"),l1l111_l1_ (u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨ㙰"))
		return l1l111_l1_ (u"ࠧࠨ㙱")
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㙲"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ㙳")+text+l1l111_l1_ (u"ࠪࠦࠬ㙴"))
	return text
def l1l11l11ll_l1_(l1lllll1_l1_,headers={}):
	url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ㙵")
	if l1l111_l1_ (u"ࠬࢂࠧ㙶") in l1lllll1_l1_:
		url,params = l1lllll1_l1_.split(l1l111_l1_ (u"࠭ࡼࠨ㙷"),1)
		if l1l111_l1_ (u"ࠧ࠾ࠩ㙸") not in params: url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ㙹")
	response = l11l1l_l1_(l1llll1ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㙺"),url,l1l111_l1_ (u"ࠪࠫ㙻"),headers,l1l111_l1_ (u"ࠫࠬ㙼"),l1l111_l1_ (u"ࠬ࠭㙽"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ㙾"),False,False)
	html = response.content
	if l1l111_l1_ (u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫ㙿") not in html: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㚀")],[l1lllll1_l1_]
	if l1l111_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭㚁") in html: return [l1l111_l1_ (u"ࠪ࠱࠶࠭㚂")],[l1lllll1_l1_]
	if l1l111_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ㚃") in html: return [l1l111_l1_ (u"ࠬ࠳࠱ࠨ㚄")],[l1lllll1_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111lll1lll_l1_,l1llll11l1ll_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ㚅"),html+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㚆"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㚇")],[l1lllll1_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1ll1l1ll11l_l1_,l11ll1l11ll_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠩࠪ㚈")
		items = line.split(l1l111_l1_ (u"ࠪ࠰ࠬ㚉"))
		for item in items:
			if l1l111_l1_ (u"ࠫࡂ࠭㚊") in item:
				key,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ㚋"),1)
				l1ll1l1ll11l_l1_[key.lower()] = value
		if l1l111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㚌") in line.lower():
			l11ll1l11ll_l1_ = int(l1ll1l1ll11l_l1_[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㚍")])//1024
			title += str(l11ll1l11ll_l1_)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㚎")
		elif l1l111_l1_ (u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㚏") in line.lower():
			l11ll1l11ll_l1_ = int(l1ll1l1ll11l_l1_[l1l111_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㚐")])//1024
			title += str(l11ll1l11ll_l1_)+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㚑")
		if l1l111_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㚒") in line.lower():
			l111l1ll_l1_ = int(l1ll1l1ll11l_l1_[l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ㚓")].split(l1l111_l1_ (u"ࠧࡹࠩ㚔"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠫ㚕")
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠤࠬ㚖"))
		if not title: title = l1l111_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ㚗")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㚘")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࠵࠯ࠨ㚙")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"࠭࠺ࠨ㚚"),1)[0]+l1l111_l1_ (u"ࠧ࠻ࠩ㚛")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨ࠱ࠪ㚜")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭㚝"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㚞"),1)[0]+l1l111_l1_ (u"ࠫ࠴࠭㚟")+l1ll1ll_l1_
		if params!=l1l111_l1_ (u"ࠬ࠭㚠"): l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࠨ㚡")+params
		if l1l111_l1_ (u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ㚢") in list(l1ll1l1ll11l_l1_.keys()):
			l111lllll_l1_ = l1ll1l1ll11l_l1_[l1l111_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ㚣")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠩࠥࠫ㚤"),l1l111_l1_ (u"ࠪࠫ㚥")).replace(l1l111_l1_ (u"ࠦࠬࠨ㚦"),l1l111_l1_ (u"ࠬ࠭㚧")).split(l1l111_l1_ (u"࠭ࠣࠨ㚨"),1)[0]
			l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l111lllll_l1_)
			if l11ll1l1l1_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠧࠡࠢࠪ㚩")+l11ll1l1l1_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ㚪")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠩࠣࠤࠬ㚫")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ㚬"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111lll1lll_l1_.append(l111l1ll_l1_)
			l1llll11l1ll_l1_.append(l11ll1l11ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠨ࠭㚭"),1)[0]
		l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1ll1ll_l1_)
		if l11ll1l1l1_l1_: title = title+l1l111_l1_ (u"ࠬࠦࠠࠨ㚮")+l11ll1l1l1_l1_
		title = title+l1l111_l1_ (u"࠭ࠠࠡࠩ㚯")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㚰"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111lll1lll_l1_.append(l111l1ll_l1_)
		l1llll11l1ll_l1_.append(l11ll1l11ll_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111lll1lll_l1_,l1llll11l1ll_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111lll1lll_l1_,l1llll11l1ll_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1ll1l11lll1_l1_=l1l111_l1_ (u"ࠨࠩ㚱")):
	if not l1ll1l11lll1_l1_: l1ll1l11lll1_l1_ = l111l11l1ll_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠩ࠱ࠫ㚲"),l1l111_l1_ (u"ࠪࠫ㚳")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l1lllllll1l1_l1_ = pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㚴"), 12049)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㚵"), 256)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㚶"), 1)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㚷"), 0)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㚸"), 0)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚹"), 0)
		if PY3: l11111l11ll_l1_ = host.split(l1l111_l1_ (u"ࠪ࠲ࠬ㚺"))
		else: l11111l11ll_l1_ = host.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㚻")).split(l1l111_l1_ (u"ࠬ࠴ࠧ㚼"))
		for part in l11111l11ll_l1_:
			parts = part.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㚽"))
			l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠢࡃࠤ㚾"), len(part))
			for l111ll1111l_l1_ in part:
				l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠣࡥࠥ㚿"), l111ll1111l_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㛀")))
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠥࡆࠧ㛁"), 0)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㛂"), 1)
		l1lllllll1l1_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㛃"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l1lllllll1l1_l1_), (l1ll1l11lll1_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1lllll1_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࡉࡊࡋࡌࡍࡎࠢ㛄"), data, 0)
		l11l111111l_l1_ = l11l1lllll1_l1_[3]
		offset = len(host)+18
		l11l1l11111_l1_ = []
		for _ in range(l11l111111l_l1_):
			l111lll1l1l_l1_ = offset
			l1lllll1llll_l1_ = 1
			l111l1111ll_l1_ = False
			while True:
				l111ll1111l_l1_ = unpack_from(l1l111_l1_ (u"ࠢ࠿ࡄࠥ㛅"), data, l111lll1l1l_l1_)[0]
				if l111ll1111l_l1_ == 0:
					l111lll1l1l_l1_ += 1
					break
				if l111ll1111l_l1_ >= 192:
					l111l1ll1l1_l1_ = unpack_from(l1l111_l1_ (u"ࠣࡀࡅࠦ㛆"), data, l111lll1l1l_l1_ + 1)[0]
					l111lll1l1l_l1_ = ((l111ll1111l_l1_ << 8) + l111l1ll1l1_l1_ - 0xc000) - 1
					l111l1111ll_l1_ = True
				l111lll1l1l_l1_ += 1
				if l111l1111ll_l1_ == False: l1lllll1llll_l1_ += 1
			if l111l1111ll_l1_ == True: l1lllll1llll_l1_ += 1
			offset = offset + l1lllll1llll_l1_
			l1l111111l1_l1_ = unpack_from(l1l111_l1_ (u"ࠤࡁࡌࡍࡏࡈࠣ㛇"), data, offset)
			offset = offset + 10
			l11ll1111l1_l1_ = l1l111111l1_l1_[0]
			l111l111l1l_l1_ = l1l111111l1_l1_[3]
			if l11ll1111l1_l1_ == 1:
				l111ll111ll_l1_ = unpack_from(l1l111_l1_ (u"ࠥࡂࠧ㛈")+l1l111_l1_ (u"ࠦࡇࠨ㛉")*l111l111l1l_l1_, data, offset)
				l1lll1ll1ll1_l1_ = l1l111_l1_ (u"ࠬ࠭㛊")
				for l111ll1111l_l1_ in l111ll111ll_l1_: l1lll1ll1ll1_l1_ += str(l111ll1111l_l1_) + l1l111_l1_ (u"࠭࠮ࠨ㛋")
				l1lll1ll1ll1_l1_ = l1lll1ll1ll1_l1_[0:-1]
				l11l1l11111_l1_.append(l1lll1ll1ll1_l1_)
			if l11ll1111l1_l1_ in [1,2,5,6,15,28]: offset = offset + l111l111l1l_l1_
	except: l11l1l11111_l1_ = []
	if not l11l1l11111_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㛌"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࡠࡔࡈࡗࡔࡒࡖࡆࡔࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡎ࡯ࡴࡶ࠽ࠤࡠࠦࠧ㛍")+host+l1l111_l1_ (u"ࠩࠣࡡࠬ㛎"))
	return l11l1l11111_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1llll1l_l1_ = [l1l111_l1_ (u"ࠪ็ออัࠨ㛏"),l1l111_l1_ (u"ࠫออไ฻ࠩ㛐"),l1l111_l1_ (u"ࠬࡧࡤࡶ࡮ࡷࠫ㛑"),l1l111_l1_ (u"࠭ࡸࡹࠩ㛒"),l1l111_l1_ (u"ࠧࡴࡧࡻࠫ㛓")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㛔"):
			l11l1llll1l_l1_ += [l1l111_l1_ (u"ࠩࡵ࠾ࠬ㛕"),l1l111_l1_ (u"ࠪࡶ࠲࠭㛖"),l1l111_l1_ (u"ࠫ࠲ࡳࡡࠨ㛗")]
			l11l1llll1l_l1_ += [l1l111_l1_ (u"ࠬࡀࡲࠨ㛘"),l1l111_l1_ (u"࠭࠭ࡳࠩ㛙"),l1l111_l1_ (u"ࠧ࡮ࡣ࠰ࠫ㛚")]
		for l1111lllll_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ㛛") in l1111lllll_l1_: continue
			if l1l111_l1_ (u"ࠩะ่็ฯࠧ㛜") in l1111lllll_l1_: continue
			l1111lllll_l1_ = l1111lllll_l1_.lower()
			if PY2: l1111lllll_l1_ = l1111lllll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㛝")).encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㛞"))
			l1111lllll_l1_ = l1111lllll_l1_.replace(l1l111_l1_ (u"ࠬࡀࠧ㛟"),l1l111_l1_ (u"࠭ࠧ㛠"))
			l111l1lllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞࠭ࠬࠫ㛡"),l1111lllll_l1_,re.DOTALL)
			l1llll11lll1_l1_ = False
			for digits in l111l1lllll_l1_:
				if len(digits)==2:
					l1llll11lll1_l1_ = True
					break
			if l1l111_l1_ (u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫ㛢") in l1111lllll_l1_: continue
			elif l1l111_l1_ (u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪ㛣") in l1111lllll_l1_: continue
			elif l1l111_l1_ (u"ࠪ฾๏ืࠠๆื้ๅࠬ㛤") in l1111lllll_l1_: continue
			elif l1l11ll1lll_l1_(l1l111_l1_ (u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭㛥")): continue
			elif l1111lllll_l1_ in [l1l111_l1_ (u"ࠬࡸࠧ㛦")] or l1llll11lll1_l1_ or any(value in l1111lllll_l1_ for value in l11l1llll1l_l1_):
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㛧"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㛨")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㛩"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㛪"),l1l111_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬ㛫"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1llll11ll11_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1llll11ll11_l1_: l1llll11ll11_l1_ = l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㛬")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠬอำห็ิหึ࠭㛭")
		header = args[2]
		text = l1l111_l1_ (u"࠭࡜࡯ࠩ㛮").join(args[3:])
	else: l1llll11ll11_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠧࠨ㛯"),l1l111_l1_ (u"ࠨࡑࡎࠫ㛰"),l1l111_l1_ (u"ࠩࠪ㛱"),l1l111_l1_ (u"ࠪࠫ㛲")
	l1ll1l111ll1_l1_(l1llll11ll11_l1_,l1l111_l1_ (u"ࠫࠬ㛳"),l11l111l_l1_,l1l111_l1_ (u"ࠬ࠭㛴"),header,text,**kwargs)
	return
def l1ll11ll1l_l1_(*args,**kwargs):
	l1llll11ll11_l1_ = args[0]
	l1lllllll1ll_l1_ = args[1]
	l1lllll1l1ll_l1_ = args[2]
	if l1lllll1l1ll_l1_ or l1lllllll1ll_l1_: l1llllll1lll_l1_ = True
	else: l1llllll1lll_l1_ = False
	header = args[3]
	text = args[4]
	if not l1llll11ll11_l1_: l1llll11ll11_l1_ = l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㛵")
	if not l1lllllll1ll_l1_: l1lllllll1ll_l1_ = l1l111_l1_ (u"ࠧไๆสࠤࠥࡔ࡯ࠨ㛶")
	if not l1lllll1l1ll_l1_: l1lllll1l1ll_l1_ = l1l111_l1_ (u"ࠨ่฼้࡙ࠥࠦࡦࡵࠪ㛷")
	if len(args)>=6: text += l1l111_l1_ (u"ࠩ࡟ࡲࠬ㛸")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"ࠪࡠࡳ࠭㛹")+args[6]
	l11l11l11l1_l1_ = l1ll1l111ll1_l1_(l1llll11ll11_l1_,l1lllllll1ll_l1_,l1l111_l1_ (u"ࠫࠬ㛺"),l1lllll1l1ll_l1_,header,text,**kwargs)
	if l11l11l11l1_l1_==-1 and l1llllll1lll_l1_: l11l11l11l1_l1_ = -1
	elif l11l11l11l1_l1_==-1 and not l1llllll1lll_l1_: l11l11l11l1_l1_ = False
	elif l11l11l11l1_l1_==0: l11l11l11l1_l1_ = False
	elif l11l11l11l1_l1_==2: l11l11l11l1_l1_ = True
	return l11l11l11l1_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ㛻") in list(kwargs.keys()): l111ll1lll1_l1_ = kwargs[l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ㛼")]
	else: l111ll1lll1_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ㛽") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ㛾")
	l1ll1ll1l111_l1_ = l1l1l1lllll_l1_(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࡉ࡮ࡣࡪࡩ࠳ࡾ࡭࡭ࠩ㛿"),l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㜀"),l1l111_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㜁"))
	l1111l1ll1l_l1_ = l1ll1l1l11l1_l1_.replace(l1l111_l1_ (u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ㜂"),l1l111_l1_ (u"࠭࡟ࠨ㜃")+str(time.time())+l1l111_l1_ (u"ࠧࡠࠩ㜄"))
	l1111l1ll1l_l1_ = l1111l1ll1l_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ㜅"),l1l111_l1_ (u"ࠩ࡟ࡠࡡࡢࠧ㜆")).replace(l1l111_l1_ (u"ࠪ࠳࠴࠭㜇"),l1l111_l1_ (u"ࠫ࠴࠵࠯࠰ࠩ㜈"))
	l11l11l1l11_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠬ࠭㜉"),l1l111_l1_ (u"࠭ࠧ㜊"),l1l111_l1_ (u"ࠧࠨ㜋"),header,text,profile,l1l111_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㜌"),False,l1111l1ll1l_l1_)
	l1ll1ll1l111_l1_.show()
	if profile==l1l111_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ㜍"):
		l1ll1ll1l111_l1_.getControl(9040).setHeight(215)
		l1ll1ll1l111_l1_.getControl(9040).setPosition(55,-80)
		l1ll1ll1l111_l1_.getControl(9050).setPosition(120,-60)
		l1ll1ll1l111_l1_.getControl(400).setPosition(90,-35)
	l1ll1ll1l111_l1_.getControl(401).setVisible(False)
	l1ll1ll1l111_l1_.getControl(402).setVisible(False)
	l1ll1ll1l111_l1_.getControl(9050).setImage(l1111l1ll1l_l1_)
	l1ll1ll1l111_l1_.getControl(9050).setHeight(l11l11l1l11_l1_)
	l1l111111ll_l1_ = threading.Thread(target=l1ll11ll1lll_l1_,args=(l1ll1ll1l111_l1_,l1111l1ll1l_l1_,l111ll1lll1_l1_))
	l1l111111ll_l1_.start()
	return
def l1ll11ll1lll_l1_(l1ll1ll1l111_l1_,l1111l1ll1l_l1_,l111ll1lll1_l1_):
	time.sleep(l111ll1lll1_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1111l1ll1l_l1_):
		try: os.remove(l1111l1ll1l_l1_)
		except: pass
	return
def l1ll1lll1lll_l1_(*args,**kwargs):
	header,text,profile,l1llll11ll11_l1_ = l1l111_l1_ (u"ࠪࠫ㜎"),l1l111_l1_ (u"ࠫࠬ㜏"),l1l111_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㜐"),l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㜑")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1llll11ll11_l1_ = args[3]
	return l1l11l1l1l_l1_(l1llll11ll11_l1_,header,text,profile)
def l11ll11ll1l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1lll1l1111l_l1_(*args,**kwargs)
def l1l11111l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1lll1lll1ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l111lll1_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll1ll11l_l1_(l1lllll1l111_l1_):
	if kodi_version>17.99: l1ll1ll1l111_l1_ = l1l111_l1_ (u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬ㜒")
	else: l1ll1ll1l111_l1_ = l1l111_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬ㜓")
	l1lllll1l111_l1_ = l1lllll1l111_l1_.lower()
	if l1lllll1l111_l1_==l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ㜔"): xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬ㜕")+l1ll1ll1l111_l1_+l1l111_l1_ (u"ࠫ࠮࠭㜖"))
	elif l1lllll1l111_l1_==l1l111_l1_ (u"ࠬࡹࡴࡰࡲࠪ㜗"): xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭࠭㜘")+l1ll1ll1l111_l1_+l1l111_l1_ (u"ࠧࠪࠩ㜙"))
	return
def l1ll1l111ll1_l1_(l1llll11ll11_l1_,l111ll1ll11_l1_=l1l111_l1_ (u"ࠨࠩ㜚"),l1lll1111l11_l1_=l1l111_l1_ (u"ࠩࠪ㜛"),l111111l11l_l1_=l1l111_l1_ (u"ࠪࠫ㜜"),header=l1l111_l1_ (u"ࠫࠬ㜝"),text=l1l111_l1_ (u"ࠬ࠭㜞"),profile=l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㜟"),l1llllll1l1l_l1_=0,l1lll1l1lll1_l1_=0):
	if not l1llll11ll11_l1_: l1llll11ll11_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㜠")
	l1ll1ll1l111_l1_ = l1lll11l1111_l1_(l1l111_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㜡"),l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㜢"),l1l111_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㜣"))
	l1ll1ll1l111_l1_.l11l1l11lll_l1_(l111ll1ll11_l1_,l1lll1111l11_l1_,l111111l11l_l1_,header,text,profile,l1llll11ll11_l1_,l1llllll1l1l_l1_,l1lll1l1lll1_l1_)
	if l1llllll1l1l_l1_>0: l1ll1ll1l111_l1_.l11lllllll1_l1_()
	if l1lll1l1lll1_l1_>0: l1ll1ll1l111_l1_.l11lll1l11l_l1_()
	if l1llllll1l1l_l1_==0 and l1lll1l1lll1_l1_==0: l1ll1ll1l111_l1_.l11l1l111l1_l1_()
	l1ll1ll1l111_l1_.doModal()
	l11l11l11l1_l1_ = l1ll1ll1l111_l1_.l1l1111111l_l1_
	return l11l11l11l1_l1_
def l1l11l1l1l_l1_(l1llll11ll11_l1_,header,text,profile=l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㜤")):
	if not l1llll11ll11_l1_: l1llll11ll11_l1_ = l1l111_l1_ (u"ࠬࡲࡥࡧࡶࠪ㜥")
	l1ll1ll1l111_l1_ = l1l1l1lllll_l1_(l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࡚ࡥࡹࡶ࡙࡭ࡪࡽࡥࡳࡈࡸࡰࡱ࡙ࡣࡳࡧࡨࡲ࠳ࡾ࡭࡭ࠩ㜦"),l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ㜧"),l1l111_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭㜨"))
	l1111l1ll1l_l1_ = l1ll1l1l11l1_l1_.replace(l1l111_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ㜩"),l1l111_l1_ (u"ࠪࡣࠬ㜪")+str(time.time())+l1l111_l1_ (u"ࠫࡤ࠭㜫"))
	l1111l1ll1l_l1_ = l1111l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ㜬"),l1l111_l1_ (u"࠭࡜࡝࡞࡟ࠫ㜭")).replace(l1l111_l1_ (u"ࠧ࠰࠱ࠪ㜮"),l1l111_l1_ (u"ࠨ࠱࠲࠳࠴࠭㜯"))
	l11l11l1l11_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠩࠪ㜰"),l1l111_l1_ (u"ࠪࠫ㜱"),l1l111_l1_ (u"ࠫࠬ㜲"),header,text,profile,l1llll11ll11_l1_,False,l1111l1ll1l_l1_)
	l1ll1ll1l111_l1_.show()
	l1ll1ll1l111_l1_.getControl(9050).setHeight(l11l11l1l11_l1_)
	l1ll1ll1l111_l1_.getControl(9050).setImage(l1111l1ll1l_l1_)
	result = l1ll1ll1l111_l1_.doModal()
	try: os.remove(l1111l1ll1l_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1lll1l11l1l_l1_=True):
	if l1lll1l11l1l_l1_:
		l11ll1l1ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㜳"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㜴"),l1l111_l1_ (u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ㜵"))
		if l11ll1l1ll_l1_: return l11ll1l1ll_l1_
	text = l1l111_l1_ (u"ࠨࠩ㜶")
	if 0 and response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪ㜷"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㜸"),html,re.DOTALL)
			text = text[0]
	if not text:
		l11111l11l1_l1_ = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㜹"),l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭㜺"))
		text = open(l11111l11l1_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㜻")).read()
		if PY3: text = text.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㜼"))
		text = text.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㜽"),l1l111_l1_ (u"ࠩࠪ㜾"))
	l1111l111l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫ㜿"),text,re.DOTALL)
	l11ll1l1lll_l1_ = []
	for line in l1111l111l1_l1_:
		l1lllll11l1l_l1_ = line.lower()
		if l1l111_l1_ (u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬ㝀") in l1lllll11l1l_l1_: continue
		if l1l111_l1_ (u"ࠬࡻࡢࡶࡰࡷࡹࠬ㝁") in l1lllll11l1l_l1_: continue
		if l1l111_l1_ (u"࠭ࡩࡱࡪࡲࡲࡪ࠭㝂") in l1lllll11l1l_l1_: continue
		if l1l111_l1_ (u"ࠧࡤࡴࡲࡷࠬ㝃") in l1lllll11l1l_l1_: continue
		l11ll1l1lll_l1_.append(line)
	l11ll1l1ll_l1_ = random.sample(l11ll1l1lll_l1_,1)
	l11ll1l1ll_l1_ = l11ll1l1ll_l1_[0]
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㝄"),l1l111_l1_ (u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ㝅"),l11ll1l1ll_l1_,l11l1l1_l1_)
	return l11ll1l1ll_l1_
def l11ll11l1ll_l1_(l111l1ll1ll_l1_=l1l111_l1_ (u"ࠪࠫ㝆")):
	if not l111l1ll1ll_l1_: l111l1ll1ll_l1_ = traceback.format_exc()
	sys.stderr.write(l111l1ll1ll_l1_)
	lines = l111l1ll1ll_l1_.splitlines()
	error = lines[-1]
	l111lll1ll1_l1_ = open(l11l1111ll1_l1_,l1l111_l1_ (u"ࠫࡷࡨࠧ㝇")).read()
	if PY3: l111lll1ll1_l1_ = l111lll1ll1_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㝈"))
	l111lll1ll1_l1_ = l111lll1ll1_l1_[-8000:]
	sep = l1l111_l1_ (u"࠭࠽ࠨ㝉")*100
	if sep in l111lll1ll1_l1_: l111lll1ll1_l1_ = l111lll1ll1_l1_.rsplit(sep,1)[1]
	if error in l111lll1ll1_l1_: l111lll1ll1_l1_ = l111lll1ll1_l1_.rsplit(error,1)[0]
	l1lll11l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭㝊"),l111lll1ll1_l1_,re.DOTALL)
	for typ,source in reversed(l1lll11l1lll_l1_):
		if source: break
	else: source = l1l111_l1_ (u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨ㝋")
	file,line,func = l1l111_l1_ (u"ࠩࠪ㝌"),l1l111_l1_ (u"ࠪࠫ㝍"),l1l111_l1_ (u"ࠫࠬ㝎")
	l11ll11llll_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㝏")+error
	l1lll1l111l1_l1_ = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ุำึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㝐")+source
	for l1lllllll11l_l1_ in reversed(lines):
		if l1l111_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠧ㝑") in l1lllllll11l_l1_ and l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㝒") in l1lllllll11l_l1_: break
	l1lllllll11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬ㝓"),l1lllllll11l_l1_,re.DOTALL)
	if l1lllllll11l_l1_:
		file,line,func = l1lllllll11l_l1_[0]
		if l1l111_l1_ (u"ࠪ࠳ࠬ㝔") in file: file = file.rsplit(l1l111_l1_ (u"ࠫ࠴࠭㝕"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠬࡢ࡜ࠨ㝖"),1)[1]
		l1ll1ll111l1_l1_ = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็็ๅ࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㝗")+file
		line2 = l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึ฻ึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㝘")+line
		l11llllllll_l1_ = l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็้่อๆ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㝙")+func
		l1lllllll111_l1_ = l1ll1ll111l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝚")+line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㝛")+l11llllllll_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㝜")+l1lll1l111l1_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㝝")+l11ll11llll_l1_
		l1llll1ll1ll_l1_ = line2+l1l111_l1_ (u"࠭࡜࡯ࠩ㝞")+l1lll1l111l1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㝟")+l11ll11llll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㝠")+l1ll1ll111l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝡")+l11llllllll_l1_
		l11111ll11l_l1_ = line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㝢")+l11ll11llll_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㝣")+l1ll1ll111l1_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㝤")+l11llllllll_l1_
	else:
		l1ll1ll111l1_l1_,line2,l11llllllll_l1_ = l1l111_l1_ (u"࠭ࠧ㝥"),l1l111_l1_ (u"ࠧࠨ㝦"),l1l111_l1_ (u"ࠨࠩ㝧")
		l1lllllll111_l1_ = l1lll1l111l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㝨")+l11ll11llll_l1_
		l1llll1ll1ll_l1_ = l1lll1l111l1_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㝩")+l11ll11llll_l1_
		l11111ll11l_l1_ = l11ll11llll_l1_
	l11l1l1l11l_l1_ = l1l111_l1_ (u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨ㝪")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㝫")
	l1ll1ll11ll1_l1_ = l11l111l1l1_l1_()
	l111111l1ll_l1_ = []
	l1lll_l1_ = l1ll1ll11ll1_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㝬")]
	l1llllll1ll1_l1_ = l1ll11lll1l1_l1_(l1l11l1l1l1_l1_)
	if l1l111_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㝭") in list(l1ll1ll11ll1_l1_.keys()):
		for l1lll1l111ll_l1_,l111l1l1l1l_l1_,l11ll1l111l_l1_ in l1lll_l1_: l111111l1ll_l1_ = max(l111111l1ll_l1_,l111l1l1l1l_l1_)
		if l1llllll1ll1_l1_<l111111l1ll_l1_:
			header = l1l111_l1_ (u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫ㝮")
			l11l11l11l1_l1_ = l1ll1l111ll1_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㝯"),l1l111_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㝰"),l1l111_l1_ (u"ࠫฯำฯ๋อࠪ㝱"),l1l111_l1_ (u"ࠬิั้ฮࠪ㝲"),l11l1l1l11l_l1_+header,l1lllllll111_l1_)
			if l11l11l11l1_l1_==0:
				l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㝳"),l1l111_l1_ (u"ࠧฯำ๋ะࠬ㝴"),l1l111_l1_ (u"ࠨฬะำ๏ัࠧ㝵"),l1l111_l1_ (u"ࠩࠪ㝶"),header)
				if l1llll111l_l1_==1: l11l11l11l1_l1_ = 1
			if l11l11l11l1_l1_==1:
				from l1l1l1111ll_l1_ import l1lllll1l1l1_l1_
				l1lllll1l1l1_l1_()
			return
	l1ll11ll1ll1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㝷"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㝸"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㝹"))
	if not l1ll11ll1ll1_l1_: l1ll11ll1ll1_l1_ = []
	l1llll1ll1ll_l1_ = l1llll1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㝺"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㝻")).replace(l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㝼"),l1l111_l1_ (u"ࠩࠪ㝽")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㝾"),l1l111_l1_ (u"ࠫࠬ㝿")).replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㞀"),l1l111_l1_ (u"࠭ࠧ㞁"))
	l11111ll11l_l1_ = l11111ll11l_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㞂"),l1l111_l1_ (u"ࠨ࡞࡟ࡲࠬ㞃")).replace(l1l111_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ㞄"),l1l111_l1_ (u"ࠪࠫ㞅")).replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㞆"),l1l111_l1_ (u"ࠬ࠭㞇")).replace(l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㞈"),l1l111_l1_ (u"ࠧࠨ㞉"))
	l1ll1l1111ll_l1_ = l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ㞊")+l11111ll11l_l1_
	if l1ll1l1111ll_l1_ in l1ll11ll1ll1_l1_:
		header = l1l111_l1_ (u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ㞋")
		l1111l1_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㞌"),l1l111_l1_ (u"ࠫࠬ㞍"),l11l1l1l11l_l1_+header,l1lllllll111_l1_)
		return
	l1ll1l11ll1l_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠬ࠴ࠧ㞎"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㞏")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㞐"),url,l1l111_l1_ (u"ࠨࠩ㞑"),l1l111_l1_ (u"ࠩࠪ㞒"),l1l111_l1_ (u"ࠪࠫ㞓"),l1l111_l1_ (u"ࠫࠬ㞔"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭㞕"),False,False)
	html = response.content
	l11lll1l111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭㞖"),html,re.DOTALL)
	for l11l1l11l1l_l1_,l11ll11lll1_l1_,l1111ll11ll_l1_,l1llll1ll1l1_l1_ in l11lll1l111_l1_:
		l11l1l11l1l_l1_ = l11l1l11l1l_l1_.split(l1l111_l1_ (u"ࠧࠬࠩ㞗"))
		l1111ll11ll_l1_ = l1111ll11ll_l1_.split(l1l111_l1_ (u"ࠨ࠭ࠪ㞘"))
		l1llll1ll1l1_l1_ = l1llll1ll1l1_l1_.split(l1l111_l1_ (u"ࠩ࠮ࠫ㞙"))
		if line in l11l1l11l1l_l1_ and error==l11ll11lll1_l1_ and l1l11l1l1l1_l1_ in l1111ll11ll_l1_ and l1ll1l11ll1l_l1_ in l1llll1ll1l1_l1_:
			header = l1l111_l1_ (u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨ㞚")
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㞛"),l1l111_l1_ (u"ࠬิั้ฮࠪ㞜"),l1l111_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ㞝"),l11l1l1l11l_l1_+header,l1lllllll111_l1_)
			if l1llll111l_l1_==1: l1111l1_l1_(l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㞞"),l1l111_l1_ (u"ࠨࠩ㞟"),l1l111_l1_ (u"ࠩࠪ㞠"),header)
			return
	header = l1l111_l1_ (u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ㞡")
	l1111l1_l1_(l1l111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㞢"),l1l111_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㞣"),l11l1l1l11l_l1_+header,l1lllllll111_l1_)
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㞤"),l1l111_l1_ (u"ࠧࠨ㞥"),l1l111_l1_ (u"ࠨࠩ㞦"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㞧"),l1l111_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫ㞨"))
	if l1llll111l_l1_==1: l1ll1l111lll_l1_ = l1l111_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ㞩")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㞪"),l1l111_l1_ (u"࠭ࠧ㞫"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㞬"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ๊ࠦลๅ฼สลࠥหัิษ็ࠤฬ๊ฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭㞭"))
		return
	message = l1llll1ll1ll_l1_
	from l1l1l1111ll_l1_ import l11l1ll111l_l1_
	succeeded = l11l1ll111l_l1_(l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࡴࠩ㞮"),message,True,l1l111_l1_ (u"ࠪࠫ㞯"),l1l111_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫ㞰"),l1ll1l111lll_l1_)
	if succeeded and l1ll1l111lll_l1_:
		l1ll11ll1ll1_l1_.append(l1ll1l1111ll_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㞱"),l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ㞲"),l1ll11ll1ll1_l1_,l1ll111ll11_l1_)
	return
def l1lll1l11ll1_l1_(data):
	if PY3: data = data.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㞳"))
	filename = l1l111_l1_ (u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨ㞴")+str(time.time())+l1l111_l1_ (u"ࠩ࠱ࡨࡦࡺࠧ㞵")
	open(filename,l1l111_l1_ (u"ࠪࡻࡧ࠭㞶")).write(data)
	return
def l11llll1l1l_l1_(l1l1lll111l_l1_):
	if l1l1lll111l_l1_:
		l1lll11l1l1l_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㞷"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㞸"),l1l111_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㞹"))
		if l1lll11l1l1l_l1_: return l1lll11l1l1l_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㞺")][5]
	l1l111llll1_l1_ = l1l1ll11l11_l1_(32,l1l1lll111l_l1_)
	l1ll1l1ll1ll_l1_ = l111l11l11l_l1_()
	l1lllll111ll_l1_ = l1ll1l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠮ࠪ㞻"))[2]
	l1lll111l11l_l1_ = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㞼"))
	l11111llll1_l1_ = l1ll1l1lll1l_l1_()
	payload = {l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㞽"):l1l111llll1_l1_,l1l111_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㞾"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㞿"):l1lllll111ll_l1_,l1l111_l1_ (u"࠭ࡩࡥࡵࠪ㟀"):l1llll1111ll_l1_(l11111llll1_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㟁"),url,payload,l1l111_l1_ (u"ࠨࠩ㟂"),l1l111_l1_ (u"ࠩࠪ㟃"),l1l111_l1_ (u"ࠪࠫ㟄"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗ࠲࠷ࡳࡵࠩ㟅"))
	if not response.succeeded: return []
	html = response.content
	l1lll11l1l1l_l1_ = html.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡳࠩ㟆"),l1l111_l1_ (u"࠭࡜࡯ࠩ㟇")).replace(l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㟈"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㟉")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㟊"),l1l111_l1_ (u"ࠪࡠࡳ࠭㟋")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㟌"),l1l111_l1_ (u"ࠬࡢ࡮ࠨ㟍"))
	l1lll11l1l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ㟎"),l1lll11l1l1l_l1_,re.DOTALL)
	if not l1lll11l1l1l_l1_: return []
	l1lll11l1l1l_l1_ = sorted(l1lll11l1l1l_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l111llll1_l1_,l111l1l1ll1_l1_,l11l1l11111_l1_,l11l11lll11_l1_,reason = l1lll11l1l1l_l1_[0]
	l1llll1lll1l_l1_ = reason if l1l11ll1lll_l1_(l1l111_l1_ (u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭㟏")) else l111l1l1ll1_l1_
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㟐"),l1llll1lll1l_l1_)
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㟑"),l1l111_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㟒"),l1lll11l1l1l_l1_,l11l1l1_l1_)
	return l1lll11l1l1l_l1_
def SPLIT_BIGLIST(items,l1ll1l11111l_l1_=0,l11111ll1l1_l1_=0):
	if l1ll1l11111l_l1_ and not l11111ll1l1_l1_: l11111ll1l1_l1_ = len(items)//l1ll1l11111l_l1_
	l1llll111l1l_l1_,l1l111llll_l1_,l1lllll11ll1_l1_ = [],-1,0
	for item in items:
		if l1lllll11ll1_l1_%l11111ll1l1_l1_==0:
			l1l111llll_l1_ += 1
			l1llll111l1l_l1_.append([])
		l1llll111l1l_l1_[l1l111llll_l1_].append(item)
		l1lllll11ll1_l1_ += 1
	return l1llll111l1l_l1_
def l11l1111l1l_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ㟓") not in filename or l1l111_l1_ (u"ࠬࡓ࠳ࡖࡡࠪ㟔") not in filename: text = str(data)
	else:
		l1llll111l1l_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"࠭ࠧ㟕")
		for split in l1llll111l1l_l1_:
			text += str(split)+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㟖")
		text = text.strip(l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㟗"))
	l1l1l1l1l11_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠩࡺࡦࠬ㟘")).write(l1l1l1l1l11_l1_)
	return
def l11ll1l1ll1_l1_(l1l1l1ll1l1_l1_,filename):
	if l1l1l1ll1l1_l1_==l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㟙"): data = {}
	elif l1l1l1ll1l1_l1_==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㟚"): data = []
	elif l1l1l1ll1l1_l1_==l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㟛"): data = l1l111_l1_ (u"࠭ࠧ㟜")
	elif l1l1l1ll1l1_l1_==l1l111_l1_ (u"ࠧࡪࡰࡷࠫ㟝"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l1l1l11_l1_ = open(filepath,l1l111_l1_ (u"ࠨࡴࡥࠫ㟞")).read()
	text = zlib.decompress(l1l1l1l1l11_l1_)
	if l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㟟") not in text: data = eval(text)
	else:
		l1llll111l1l_l1_ = text.split(l1l111_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ㟠"))
		del text
		data = []
		l11l1lll111_l1_ = l11l1l11l11_l1_()
		id = 0
		for split in l1llll111l1l_l1_:
			l11l1lll111_l1_.l11l11ll1ll_l1_(str(id),eval,split)
			id += 1
		del l1llll111l1l_l1_
		l11l1lll111_l1_.l1lll1lll11l_l1_()
		l11l1lll111_l1_.l1ll1l111111_l1_()
		l1ll1l1ll1l1_l1_ = list(l11l1lll111_l1_.l111l111ll1_l1_.keys())
		l1ll1llll11l_l1_ = sorted(l1ll1l1ll1l1_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll1llll11l_l1_:
			data += l11l1lll111_l1_.l111l111ll1_l1_[id]
	return data
def l1lll111llll_l1_(addon_id):
	l11ll11l1l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ㟡"),addon_id,l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ㟢"))
	try: l1l1111ll1l_l1_ = open(l11ll11l1l1_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㟣")).read()
	except:
		l1lllll11l11_l1_ = os.path.join(l111l111111_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㟤"),addon_id,l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ㟥"))
		try: l1l1111ll1l_l1_ = open(l1lllll11l11_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㟦")).read()
		except: return l1l111_l1_ (u"ࠪࠫ㟧"),[]
	if PY3: l1l1111ll1l_l1_ = l1l1111ll1l_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㟨"))
	version = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩ㟩"),l1l1111ll1l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"࠭ࠧ㟪"),[]
	l1l11111lll_l1_,l11l11ll11l_l1_ = version[0],l1ll11lll1l1_l1_(version[0])
	return l1l11111lll_l1_,l11l11ll11l_l1_
def l11l111l1l1_l1_():
	l111ll1l1l1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㟫"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㟬"),l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㟭"))
	if l111ll1l1l1_l1_: return l111ll1l1l1_l1_
	l1ll1ll11ll1_l1_,l111ll1l1l1_l1_ = {},{}
	l1lll11l1lll_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㟮")][0]]
	if kodi_version>17.99: l1lll11l1lll_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㟯")][1])
	if PY3: l1lll11l1lll_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ㟰")][2])
	for l1lll11111l1_l1_ in l1lll11l1lll_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㟱"),l1lll11111l1_l1_,l1l111_l1_ (u"ࠧࠨ㟲"),l1l111_l1_ (u"ࠨࠩ㟳"),l1l111_l1_ (u"ࠩࠪ㟴"),l1l111_l1_ (u"ࠪࠫ㟵"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ㟶"))
		if response.succeeded:
			html = response.content
			l1ll1l11l1ll_l1_ = l1lll11111l1_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧ㟷"),1)[0]
			l111ll1l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㟸"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l11l11111ll_l1_ in l111ll1l1ll_l1_:
				l11l11ll1l1_l1_ = l1ll1l11l1ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ㟹")+addon_id+l1l111_l1_ (u"ࠨ࠱ࠪ㟺")+addon_id+l1l111_l1_ (u"ࠩ࠰ࠫ㟻")+l11l11111ll_l1_+l1l111_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ㟼")
				if addon_id not in list(l1ll1ll11ll1_l1_.keys()):
					l1ll1ll11ll1_l1_[addon_id] = []
					l111ll1l1l1_l1_[addon_id] = []
				l1lllll1ll11_l1_ = l1ll11lll1l1_l1_(l11l11111ll_l1_)
				l1ll1ll11ll1_l1_[addon_id].append((l11l11111ll_l1_,l1lllll1ll11_l1_,l11l11ll1l1_l1_))
	for addon_id in list(l1ll1ll11ll1_l1_.keys()):
		l111ll1l1l1_l1_[addon_id] = sorted(l1ll1ll11ll1_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㟽"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭㟾"),l111ll1l1l1_l1_,l11l1l1_l1_)
	return l111ll1l1l1_l1_
def l1ll11lll1l1_l1_(l11l11111ll_l1_):
	l1lllll1ll11_l1_ = []
	l1llll1l11l_l1_ = l11l11111ll_l1_.split(l1l111_l1_ (u"࠭࠮ࠨ㟿"))
	for l1l1ll11l1_l1_ in l1llll1l11l_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫ㠀"),l1l1ll11l1_l1_,re.DOTALL)
		l1ll1l1lll11_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1ll1l1lll11_l1_.append(part)
		l1lllll1ll11_l1_.append(l1ll1l1lll11_l1_)
	return l1lllll1ll11_l1_
def l1llll1l11ll_l1_(l1lllll1ll11_l1_):
	l11l11111ll_l1_ = l1l111_l1_ (u"ࠨࠩ㠁")
	for l1l1ll11l1_l1_ in l1lllll1ll11_l1_:
		for part in l1l1ll11l1_l1_: l11l11111ll_l1_ += str(part)
		l11l11111ll_l1_ += l1l111_l1_ (u"ࠩ࠱ࠫ㠂")
	l11l11111ll_l1_ = l11l11111ll_l1_.strip(l1l111_l1_ (u"ࠪ࠲ࠬ㠃"))
	return l11l11111ll_l1_
def l1111l11ll1_l1_(l11ll1l1l11_l1_):
	l1ll1l11ll11_l1_ = {}
	l1ll1ll11ll1_l1_ = l11l111l1l1_l1_()
	l11lll1l1ll_l1_ = l1lll1lll111_l1_(l11ll1l1l11_l1_)
	for addon_id in l11ll1l1l11_l1_:
		if addon_id not in list(l1ll1ll11ll1_l1_.keys()): continue
		l111ll1l1l1_l1_ = l1ll1ll11ll1_l1_[addon_id]
		l11lll11l11_l1_,l11lll111l1_l1_,l1ll11ll11l1_l1_ = l111ll1l1l1_l1_[0]
		l11111111ll_l1_,l11l11l1ll1_l1_ = l1lll111llll_l1_(addon_id)
		l11ll111lll_l1_,l11111l1lll_l1_ = l11lll1l1ll_l1_[addon_id]
		l11llll1ll1_l1_ = l11lll111l1_l1_>l11l11l1ll1_l1_ and l11ll111lll_l1_
		l1ll11ll1l11_l1_ = True
		if not l11ll111lll_l1_: l1l1111l111_l1_ = l1l111_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ㠄")
		elif not l11111l1lll_l1_: l1l1111l111_l1_ = l1l111_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ㠅")
		elif l11llll1ll1_l1_: l1l1111l111_l1_ = l1l111_l1_ (u"࠭࡯࡭ࡦࠪ㠆")
		else:
			l1l1111l111_l1_ = l1l111_l1_ (u"ࠧࡨࡱࡲࡨࠬ㠇")
			l1ll11ll1l11_l1_ = False
		l1ll1l11ll11_l1_[addon_id] = (l1ll11ll1l11_l1_,l11111111ll_l1_,l11l11l1ll1_l1_,l11lll11l11_l1_,l11lll111l1_l1_,l1l1111l111_l1_,l1ll11ll11l1_l1_)
	return l1ll1l11ll11_l1_
def l1l1111l11_l1_(l1l1111lll_l1_,l111l11ll1l_l1_,l11l1l111ll_l1_=l1l111_l1_ (u"ࠨࠩ㠈"),line2=l1l111_l1_ (u"ࠩࠪ㠉"),l11l1l11l1l_l1_=l1l111_l1_ (u"ࠪࠫ㠊")):
	if PY2: l1l1111lll_l1_.update(l111l11ll1l_l1_,l11l1l111ll_l1_,line2,l11l1l11l1l_l1_)
	else: l1l1111lll_l1_.update(l111l11ll1l_l1_,l11l1l111ll_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㠋")+line2+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㠌")+l11l1l11l1l_l1_)
	return
def l1lll1llll11_l1_(l1111l1llll_l1_):
	def l11111lll1l_l1_(num,b,l1lll1l1l111_l1_=l1l111_l1_ (u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨ㠍")):
		return ((num == 0) and l1lll1l1l111_l1_[0]) or (l11111lll1l_l1_(num // b, b, l1lll1l1l111_l1_).lstrip(l1lll1l1l111_l1_[0]) + l1lll1l1l111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠢ࡝࡞ࡥࠦ㠎") + l11111lll1l_l1_(c, a) + l1l111_l1_ (u"ࠣ࡞࡟ࡦࠧ㠏"),  k[c], p)
		return p
	l1111l1llll_l1_ = l1111l1llll_l1_.split(l1l111_l1_ (u"ࠩࢀࠬࠬ㠐"))[1][:-1]
	l1lll11lllll_l1_ = eval(l1l111_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫ㠑")+l1111l1llll_l1_,{l1l111_l1_ (u"ࠫࡧࡧࡳࡦࡐࠪ㠒"):l11111lll1l_l1_,l1l111_l1_ (u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬ㠓"):unpack})
	return l1lll11lllll_l1_
def l11l1111lll_l1_(url,l1llll111ll1_l1_=l1l111_l1_ (u"࠭ࠧ㠔")):
	if l1llll111ll1_l1_==l1l111_l1_ (u"ࠧ࡭ࡱࡺࡩࡷ࠭㠕"): url = re.sub(l1l111_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨ㠖"),lambda l11llllll1l_l1_: l11llllll1l_l1_.group(0).lower(),url)
	elif l1llll111ll1_l1_==l1l111_l1_ (u"ࠩࡸࡴࡵ࡫ࡲࠨ㠗"): url = re.sub(l1l111_l1_ (u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪ㠘"),lambda l11llllll1l_l1_: l11llllll1l_l1_.group(0).upper(),url)
	return url
def l1lll1lll111_l1_(l11ll1l1l11_l1_):
	l111111lll1_l1_,l111l11111l_l1_ = False,False
	conn = sqlite3.connect(l111lll1l11_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	if len(l11ll1l1l11_l1_)==1: l11l111lll1_l1_ = l1l111_l1_ (u"ࠫ࠭ࠨࠧ㠙")+l11ll1l1l11_l1_[0]+l1l111_l1_ (u"ࠬࠨࠩࠨ㠚")
	else: l11l111lll1_l1_ = str(tuple(l11ll1l1l11_l1_))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭㠛")+l11l111lll1_l1_+l1l111_l1_ (u"ࠧࠡ࠽ࠪ㠜"))
	l1l1l11111l_l1_ = l1llll1lll_l1_.fetchall()
	l11lll1l1ll_l1_ = {}
	for addon_id in l11ll1l1l11_l1_: l11lll1l1ll_l1_[addon_id] = (False,False)
	for addon_id,l111l11111l_l1_ in l1l1l11111l_l1_:
		l111111lll1_l1_ = True
		l111l11111l_l1_ = l111l11111l_l1_==1
		l11lll1l1ll_l1_[addon_id] = (l111111lll1_l1_,l111l11111l_l1_)
	conn.close()
	return l11lll1l1ll_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"ࠨࠩ㠝")
	if file==l1ll11lll1ll_l1_: status = l1ll1ll11lll_l1_(True,False)
	if os.path.exists(file):
		l1l11ll1ll1_l1_ = open(file,l1l111_l1_ (u"ࠩࡵࡦࠬ㠞")).read()
		if PY3: l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㠟"))
		if file==l1ll11lll1ll_l1_: l1lll_l1_ = l1l11ll1ll1_l1_
		else:
			l111ll11111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㠠"),l1l11ll1ll1_l1_)
			if l111ll11111_l1_:
				l1lll_l1_ = {}
				for key in l111ll11111_l1_.keys():
					l1lll_l1_[key] = []
					for l1111l11lll_l1_ in l111ll11111_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1l111_l1_ (u"ࠬ࠭㠡"),l1l111_l1_ (u"࠭ࠧ㠢"),l1l111_l1_ (u"ࠧࠨ㠣"),l1l111_l1_ (u"ࠨࠩ㠤"),l1l111_l1_ (u"ࠩࠪ㠥"),l1l111_l1_ (u"ࠪࠫ㠦"),l1l111_l1_ (u"ࠫࠬ㠧"),l1l111_l1_ (u"ࠬ࠭㠨"),l1l111_l1_ (u"࠭ࠧ㠩")
						type = l1111l11lll_l1_[0]
						name = l1111l11lll_l1_[1]
						name = l11lll1ll1l_l1_(name)
						url = l1111l11lll_l1_[2]
						mode = l1111l11lll_l1_[3]
						l11l_l1_ = l1111l11lll_l1_[4]
						l1llllll1_l1_ = l1111l11lll_l1_[5]
						if len(l1111l11lll_l1_)>6: text = l1111l11lll_l1_[6]
						if len(l1111l11lll_l1_)>7: context = l1111l11lll_l1_[7]
						if len(l1111l11lll_l1_)>8: l1llllll1ll_l1_ = l1111l11lll_l1_[8]
						if file==favoritesfile: l1ll1l1l1l1l_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"ࠧࠨ㠪"),l1llllll1ll_l1_
						else: l1ll1l1l1l1l_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
						l1lll_l1_[key].append(l1ll1l1l1l1l_l1_)
			l1l11l1l1ll_l1_ = str(l1lll_l1_)
			if PY3: l1l11l1l1ll_l1_ = l1l11l1l1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㠫"))
			open(file,l1l111_l1_ (u"ࠩࡺࡦࠬ㠬")).write(l1l11l1l1ll_l1_)
	return l1lll_l1_
def l1ll1llllll_l1_(l1lll11ll1l_l1_):
	l1lllll1111l_l1_ = l1lll11ll1l_l1_.split(l1l111_l1_ (u"ࠪ࠱ࠬ㠭"),1)[0]
	l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1l111_l1_ (u"ࠫࠬ㠮"),l1l111_l1_ (u"ࠬ࠭㠯"),l1l111_l1_ (u"࠭ࠧ㠰")
	if   l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㠱")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㠲")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㠳")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㠴")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ㠵")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㠶")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ㠷")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ㠸")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㠹"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㠺")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㠻")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ㠼")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㠽")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㠾")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㠿")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ㡀"):	from l11111ll1_l1_	import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㡁"):		from l1111ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ㡂")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭㡃")	:	from l111111l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ㡄")	:	from l11111111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ㡅")	:	from l1lllllll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ㡆"):	from l1l1l111l1_l1_	import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㡇")	:	from l11ll1l111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ㡈")	:	from l11l11ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㡉")	:	from l111llll1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㡊")	:	from l111ll1l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㡋")	:	from l111ll11ll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㡌")	:	from l111l1lll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ㡍")	:	from l111l11l11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ㡎")	:	from l111l111ll_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ㡏")	:	from l1lllll1l11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㡐")	:	from l1lllll1111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㡑")	:	from l1llll1ll11_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ㡒")	:	from l1llll11lll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㡓")		:	from l1llll11l1l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㡔")	:	from l1ll1lll1l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㡕")		:	from l1ll1lll11l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㡖")		:	from IPTV			import MENUu as l1lll111l11_l1_,SEARCHh as l1lll11ll11_l1_,menu_namee as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㡗")	:	from l1ll1l1111l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㡘")	:	from l1ll1l11111_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ㡙")	:	from l1ll11lll1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㡚")	:	from l1ll111lll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㡛")	:	from l1l11111l1l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㡜")		:	from M3U			import MENUu as l1lll111l11_l1_,SEARCHh as l1lll11ll11_l1_,menu_namee as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ㡝")	:	from l1lll1l1ll11_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ㡞")	:	from l1llll1llll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㡟")		:	from l11l1l1l111_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㡠")	:	from l1lll111l1ll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ㡡"):	from l11ll1llll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㡢")	:	from l11l1l1lll1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㡣")	:	from l111l1ll111_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㡤")	:	from l11llll1lll_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ㡥")	:	from l1ll1lll111l_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㡦")		:	from l1111llll11_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ㡧")	:	from l1lll11l111l_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㡨")		:	from l11lll1lll1_l1_			import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㡩")	:	from l11lll1l1l1_l1_		import l1l1l11_l1_ as l1lll111l11_l1_,l1lll1_l1_ as l1lll11ll11_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1lllll1111l_l1_==l1l111_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㡪"):	from l11ll1l11l1_l1_	import l1l1l11_l1_ as l1lll111l11_l1_
	return l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_
def l11111111l1_l1_(l1ll11ll11ll_l1_,headers,l11_l1_):
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㡫"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨ㡬")+l1ll11ll11ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ㡭")+str(headers)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㡮"))
	l1l1111lll_l1_ = l1l111lll1_l1_()
	l1l1111lll_l1_.create(l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㡯"),l1l111_l1_ (u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩ㡰"))
	l1l11l11l1_l1_ = 1024*1024
	chunksize = 1*l1l11l11l1_l1_
	from requests import get
	response = get(l1ll11ll11ll_l1_,stream=True,headers=headers)
	l1ll1lll1111_l1_ = response.headers
	response.close()
	l1ll1ll1l1ll_l1_ = bytes()
	if not l1ll1lll1111_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㡱"),l1l111_l1_ (u"ࠩࠪ㡲"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㡳"),l1l111_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧ㡴"))
		l1l1111lll_l1_.close()
	else:
		if l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭㡵") not in list(l1ll1lll1111_l1_.keys()): filesize = 0
		else: filesize = int(l1ll1lll1111_l1_[l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ㡶")])
		l1l111ll1l_l1_ = str(int(1000*filesize/l1l11l11l1_l1_)/1000.0)
		l11llll11l_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧ㡷") in list(l1ll1lll1111_l1_.keys()) and filesize>l1l11l11l1_l1_:
			l1lll11111ll_l1_ = True
			ranges = []
			l1ll1l1l11ll_l1_ = 10
			ranges.append(str(0*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡸")+str(1*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(1*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㡹")+str(2*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(2*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㡺")+str(3*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(3*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㡻")+str(4*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(4*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㡼")+str(5*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(5*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㡽")+str(6*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(6*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㡾")+str(7*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(7*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡿")+str(8*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(8*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㢀")+str(9*filesize//l1ll1l1l11ll_l1_-1))
			ranges.append(str(9*filesize//l1ll1l1l11ll_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㢁"))
			l11ll1lll11_l1_ = float(l11llll11l_l1_)/l1ll1l1l11ll_l1_
			l1111ll1l11_l1_ = l11ll1lll11_l1_/int(1+l11ll1lll11_l1_)
		else:
			l1lll11111ll_l1_ = False
			l1ll1l1l11ll_l1_ = 1
			l1111ll1l11_l1_ = 1
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㢂"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭㢃")+str(l1lll11111ll_l1_)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ㢄")+str(filesize)+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㢅"))
		l1l111llll_l1_,l1lll111ll11_l1_ = 0,0
		for l1lllll11ll1_l1_ in range(l1ll1l1l11ll_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1lll11111ll_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠨࡔࡤࡲ࡬࡫ࠧ㢆")] = l1l111_l1_ (u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩ㢇")+ranges[l1lllll11ll1_l1_]
			response = get(l1ll11ll11ll_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l1111lll_l1_.iscanceled():
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㢈"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫ㢉"))
					break
				l1l111llll_l1_ += l1111ll1l11_l1_
				l1ll1ll1l1ll_l1_ += chunk
				if not l1lll111ll11_l1_: l1lll111ll11_l1_ = len(chunk)
				if filesize: l1l1111l11_l1_(l1l1111lll_l1_,100*l1l111llll_l1_//l11llll11l_l1_,l1l111_l1_ (u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭㢊"),str(100.0*l1lll111ll11_l1_*l1l111llll_l1_//chunksize//100.0)+l1l111_l1_ (u"࠭ࠠ࠰ࠢࠪ㢋")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠧࠡࡏࡅࠫ㢌"))
				else: l1l1111l11_l1_(l1l1111lll_l1_,l1lll111ll11_l1_*l1l111llll_l1_//chunksize,l1l111_l1_ (u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭㢍"),str(100.0*l1lll111ll11_l1_*l1l111llll_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠩࠣࡑࡇ࠭㢎"))
			response.close()
		l1l1111lll_l1_.close()
		if len(l1ll1ll1l1ll_l1_)<filesize and filesize>0:
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㢏"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧ㢐")+str(len(l1ll1ll1l1ll_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪ㢑")+l1l111ll1l_l1_+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ㢒"))
			l11l11l11l1_l1_ = l1ll1l111ll1_l1_(l1l111_l1_ (u"ࠧࠨ㢓"),l1l111_l1_ (u"ࠨว็฾ฬว้ࠠะิ์ั࠭㢔"),l1l111_l1_ (u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩ㢕"),l1l111_l1_ (u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬ㢖"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㢗"),l1l111_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩ㢘")+str(len(l1ll1ll1l1ll_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬ㢙")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩ㢚"))
			if l11l11l11l1_l1_==2: l1ll1ll1l1ll_l1_ = l11111111l1_l1_(l1ll11ll11ll_l1_,headers,l11_l1_)
			elif l11l11l11l1_l1_==1: l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㢛"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ㢜"))
			else: return l1l111_l1_ (u"ࠪࠫ㢝")
			if not l1ll1ll1l1ll_l1_: return l1l111_l1_ (u"ࠫࠬ㢞")
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㢟"),l1l111_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪ㢠")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭㢡"))
	return l1ll1ll1l1ll_l1_
def l1111lll111_l1_(l1ll1_l1_):
	return response
def l111l11l11l_l1_(l1lll1ll1ll1_l1_=l1l111_l1_ (u"ࠨࠩ㢢")):
	l1lll111l1l1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡶࡸࡷ࠭㢣"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㢤"),l1l111_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ㢥"))
	if l1lll111l1l1_l1_: return l1lll111l1l1_l1_
	l1lll1ll1ll1_l1_,l1lll11l11l1_l1_,l1lllll111ll_l1_,l1l1111l11l_l1_,l1lllll111l1_l1_,l111l1l1l11_l1_,timezone = l1l111_l1_ (u"ࠬ࠭㢦"),l1l111_l1_ (u"࠭ࠧ㢧"),l1l111_l1_ (u"ࠧࠨ㢨"),l1l111_l1_ (u"ࠨࠩ㢩"),l1l111_l1_ (u"ࠩࠪ㢪"),l1l111_l1_ (u"ࠪࠫ㢫"),l1l111_l1_ (u"ࠫࠬ㢬")
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ㢭")+l1lll1ll1ll1_l1_+l1l111_l1_ (u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㢮")
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㢯"):l1l111_l1_ (u"ࠨࠩ㢰")}
	response = l111l1lll1l_l1_(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㢱"),url,l1l111_l1_ (u"ࠪࠫ㢲"),headers,l1l111_l1_ (u"ࠫࠬ㢳"),l1l111_l1_ (u"ࠬ࠭㢴"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㢵"))
	if not response.succeeded: l1ll1l1ll1ll_l1_ = l1lll1ll1ll1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢶")+l1lll11l11l1_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㢷")+l1lllll111ll_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㢸")+l1lllll111l1_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㢹")+l111l1l1l11_l1_+l1l111_l1_ (u"ࠫ࠱࠭㢺")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠬࡢࡻ࠯ࠬࡂࡠࢂࡢࡽࠨ㢻"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l11lllll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㢼"),html)
			if l1l111_l1_ (u"ࠧࡪࡲࠪ㢽") in list(l11l11lllll_l1_.keys()): l1lll1ll1ll1_l1_ = l11l11lllll_l1_[l1l111_l1_ (u"ࠨ࡫ࡳࠫ㢾")]
			if l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ㢿") in list(l11l11lllll_l1_.keys()): l1lll11l11l1_l1_ = l11l11lllll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭㣀")]
			if l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㣁") in list(l11l11lllll_l1_.keys()): l1lllll111ll_l1_ = l11l11lllll_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㣂")]
			if l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ㣃") in list(l11l11lllll_l1_.keys()): l1l1111l11l_l1_ = l11l11lllll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭㣄")]
			if l1l111_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ㣅") in list(l11l11lllll_l1_.keys()): l1lllll111l1_l1_ = l11l11lllll_l1_[l1l111_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ㣆")]
			if l1l111_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ㣇") in list(l11l11lllll_l1_.keys()): l111l1l1l11_l1_ = l11l11lllll_l1_[l1l111_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ㣈")]
			if l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㣉") in list(l11l11lllll_l1_.keys()):
				timezone = l11l11lllll_l1_[l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㣊")][l1l111_l1_ (u"ࠧࡶࡶࡦࠫ㣋")]
				if timezone[0] not in [l1l111_l1_ (u"ࠨ࠯ࠪ㣌"),l1l111_l1_ (u"ࠩ࠮ࠫ㣍")]: timezone = l1l111_l1_ (u"ࠪ࠯ࠬ㣎")+timezone
			l1ll1l1ll1ll_l1_ = l1lll1ll1ll1_l1_+l1l111_l1_ (u"ࠫ࠱࠭㣏")+l1lll11l11l1_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㣐")+l1lllll111ll_l1_+l1l111_l1_ (u"࠭ࠬࠨ㣑")+l1lllll111l1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㣒")+l111l1l1l11_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㣓")+timezone
			if PY3: l1ll1l1ll1ll_l1_ = l1ll1l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㣔")).decode(l1l111_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㣕"))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㣖"),l1l111_l1_ (u"ࠬࡏࡐࡍࡑࡆࡅ࡙ࡏࡏࡏࠩ㣗"),l1ll1l1ll1ll_l1_,l111l11l_l1_)
	l1ll1l1ll1ll_l1_ = escapeUNICODE(l1ll1l1ll1ll_l1_)
	return l1ll1l1ll1ll_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"࠭ࠧ㣘"),True
	if search.count(l1l111_l1_ (u"ࠧࡠࠩ㣙"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠨࡡࠪ㣚"),1)
		options = l1l111_l1_ (u"ࠩࡢࠫ㣛")+options
		if l1l111_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ㣜") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1ll1l1lll1l_l1_():
	l1lll111l11l_l1_ = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㣝"))
	l11111llll1_l1_ = 0
	if os.path.exists(l1lll111l11l_l1_):
		for filename in os.listdir(l1lll111l11l_l1_):
			if l1l111_l1_ (u"ࠬ࠴ࡰࡺࡱࠪ㣞") in filename: continue
			if l1l111_l1_ (u"࠭࡟ࡠࡲࡼࡧࡦࡩࡨࡦࡡࡢࠫ㣟") in filename: continue
			l1ll111111_l1_ = os.path.join(l1lll111l11l_l1_,filename)
			size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
			l11111llll1_l1_ += size
	return l11111llll1_l1_
def l1ll1ll11lll_l1_(l1l1lll111l_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㣠")][3]
	l1l111llll1_l1_ = l1l1ll11l11_l1_(32,l1l1lll111l_l1_)
	l1ll1l1ll1ll_l1_ = l111l11l11l_l1_()
	l1lllll111ll_l1_ = l1ll1l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠮ࠪ㣡"))[2]
	l11111llll1_l1_ = l1ll1l1lll1l_l1_()
	payload = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㣢"):l1l111llll1_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ㣣"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㣤"):l1lllll111ll_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㣥"):l1llll1111ll_l1_(l11111llll1_l1_)}
	if not l1l1lll111l_l1_: l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ㣦"),(l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㣧"),url,payload,l1l111_l1_ (u"ࠨࠩ㣨"),l1l111_l1_ (u"ࠩࠪ㣩")))
	l111l1111l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㣪"))
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ㣫"),l1l111_l1_ (u"ࠬ࠭㣬"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㣭"),url,payload,l1l111_l1_ (u"ࠧࠨ㣮"),l1l111_l1_ (u"ࠨࠩ㣯"),l1l111_l1_ (u"ࠩࠪ㣰"),l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔ࠯ࡖࡌࡔ࡝࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭㣱"),True,True)
	l11llll1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㣲"))
	if not l11llll1l11_l1_: l11llll1l11_l1_ = l1l111_l1_ (u"ࠬࡔࡅࡘࠩ㣳")
	l1llll1l1lll_l1_ = l11llll1l11_l1_
	l11lll11lll_l1_ = l1l111_l1_ (u"࠭ࠧ㣴")
	if not response.succeeded: l1llll1l1lll_l1_ = l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㣵")
	else:
		l111l1lll11_l1_,l111ll11ll1_l1_,l11l1l1ll11_l1_ = l1l111_l1_ (u"ࠨࠩ㣶"),l1l111_l1_ (u"ࠩࠪ㣷"),[]
		newfile = response.content
		if newfile:
			l11l1l1ll11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㣸"),newfile)
			for l11111l1111_l1_,l1lll11ll111_l1_,message in l11l1l1ll11_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㣹")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㣺"))
				if l11111l1111_l1_==l1l111_l1_ (u"࠭࠰ࠨ㣻"): l11lll11lll_l1_ += message+l1l111_l1_ (u"ࠧ࠻࠼ࠪ㣼")
				else: l111l1lll11_l1_ += message+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㣽")
			l111l1lll11_l1_ = l111l1lll11_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㣾"))
			l11lll11lll_l1_ = l11lll11lll_l1_.strip(l1l111_l1_ (u"ࠪ࠾࠿࠭㣿"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ㤀"),l11lll11lll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㤁"),l1llll1111ll_l1_(now))
		if os.path.exists(l1ll11lll1ll_l1_): l111ll11ll1_l1_ = open(l1ll11lll1ll_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㤂")).read()
		if PY3: l111l1lll11_l1_ = l111l1lll11_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㤃"))
		if l111l1lll11_l1_!=l111ll11ll1_l1_:
			l1llll1l1lll_l1_ = l1l111_l1_ (u"ࠨࡐࡈ࡛ࠬ㤄")
			try: open(l1ll11lll1ll_l1_,l1l111_l1_ (u"ࠩࡺࡦࠬ㤅")).write(l111l1lll11_l1_)
			except: pass
		if l11_l1_:
			l11l1l1ll11_l1_ = sorted(l11l1l1ll11_l1_,reverse=True,key=lambda key: int(key[0]))
			l111ll11l1l_l1_ = l1l111_l1_ (u"ࠪࠫ㤆")
			for l11111l1111_l1_,l1lll11ll111_l1_,message in l11l1l1ll11_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㤇")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤈"))
				if l111ll11l1l_l1_: l111ll11l1l_l1_ += l1l111_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ㤉")
				if l11111l1111_l1_==l1l111_l1_ (u"ࠧ࠱ࠩ㤊"): continue
				date = message.split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤋"))[0]
				l11ll11l11l_l1_ = l1l111_l1_ (u"ࠩࠪ㤌")
				if l1lll11ll111_l1_:
					l11ll11l11l_l1_ = l1l111_l1_ (u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧ㤍")
					if PY3: l11ll11l11l_l1_ = l11ll11l11l_l1_.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㤎")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤏"))
				l111ll11l1l_l1_ += message.replace(date,l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㤐")+date+l11ll11l11l_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㤑"))+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤒")
			l111ll11l1l_l1_ = escapeUNICODE(l111ll11l1l_l1_)
			l1l11l1l1l_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㤓"),l1l111_l1_ (u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭㤔"),l111ll11l1l_l1_,l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㤕"))
			l1llll1l1lll_l1_ = l1l111_l1_ (u"ࠬࡕࡌࡅࠩ㤖")
		if l1llll1l1lll_l1_!=l11llll1l11_l1_:
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㤗"),l1llll1l1lll_l1_)
	if l11_l1_: xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㤘"))
	if l111l1111l1_l1_!=l11lll11lll_l1_:
		if not l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨฮิฬ๋ࠥัสࠢฦาึ๏ࠧ㤙"),l1l111_l1_ (u"ࠩࡗࡶࡾࠦࡡࡨࡣ࡬ࡲࠬ㤚"),time=2000)
		l1111lll1ll_l1_(l1l111_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡶࡲࠤࡦࡶࡰ࡭ࡻࠣࡲࡪࡽࠠࡱࡴ࡬ࡺ࡮ࡲࡥࡨࡧࡶࠫ㤛"))
	return l1llll1l1lll_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll1lllllll_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll1lllllll_l1_ = False
	l11lll1111_l1_ = time.time()
	if l1ll1lllllll_l1_: resp = l11lll1111_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࠬ㤜"),l1l111_l1_ (u"ࠬ࠭㤝"),l1l111_l1_ (u"࠭ࠧ㤞"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㤟"),l1l111_l1_ (u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧ㤠"))
	else: l1llll111l_l1_ = True
	if l1llll111l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠩ࠱ࡨࡧ࠭㤡")) and l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ㤢") in filename:
				l1ll1lll1l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1llll1lll_l1_ = l1l1lllll11_l1_(l1ll1lll1l_l1_)
				except: return
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧ㤣"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨ㤤"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧ㤥"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㤦"),l1l111_l1_ (u"ࠨࠩ㤧"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㤨"),l1l111_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ㤩"))
	return
def l111l1lll1l_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll111_l1_=l1l111_l1_ (u"ࠫࠬ㤪"),l1llll111lll_l1_=l1l111_l1_ (u"ࠬ࠭㤫")):
	if l11_l1_==l1l111_l1_ (u"࠭ࠧ㤬"): l11_l1_ = True
	if l11ll1ll111_l1_==l1l111_l1_ (u"ࠧࠨ㤭"): l11ll1ll111_l1_ = True
	if l1llll111lll_l1_==l1l111_l1_ (u"ࠨࠩ㤮"): l1llll111lll_l1_ = True
	if allow_redirects==l1l111_l1_ (u"ࠩࠪ㤯"): l1lll1111ll1_l1_ = True
	else: l1lll1111ll1_l1_ = allow_redirects
	if data==None: l1l11llll_l1_ = None
	elif data==l1l111_l1_ (u"ࠪࠫ㤰"): l1l11llll_l1_ = {}
	else: l1l11llll_l1_ = data
	if headers==None: l1ll1ll1l_l1_ = None
	elif headers==l1l111_l1_ (u"ࠫࠬ㤱"): l1ll1ll1l_l1_ = {}
	else: l1ll1ll1l_l1_ = headers
	l1llll1lllll_l1_ = list(l1ll1ll1l_l1_.keys())
	if l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㤲") not in l1llll1lllll_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㤳")] = l1l111_l1_ (u"ࠧࡁࡂࡃࡗࡐࡏࡐࡠࡊࡈࡅࡉࡋࡒࡁࡂࡃࠫ㤴")
	l1lllll1_l1_,l1ll1llll111_l1_,l1llll11l1l1_l1_,l1llll1l1l11_l1_ = l1ll1ll11l1l_l1_(url)
	l1ll1l11lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ㤵"))
	l1ll1ll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㤶"))
	l1lll1111111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㤷"))
	l1lll111l111_l1_ = (l1ll1llll111_l1_==None and l1llll11l1l1_l1_==None)
	l11l1111111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㤸")]
	l1ll1ll1lll1_l1_ = l1lllll1_l1_ in l11l1111111_l1_
	l11l111l111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ㤹")]
	l11ll1lll1l_l1_ = l1lllll1_l1_ in l11l111l111_l1_
	l11l111ll11_l1_ = l1ll1ll1lll1_l1_ or l11ll1lll1l_l1_
	if l1lll111l111_l1_ and l11l111ll11_l1_:
		if l1ll1ll1lll1_l1_:
			l1111l111ll_l1_ = l11l1111111_l1_.index(l1lllll1_l1_)
			l111l1l1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ㤺")][l1111l111ll_l1_]
			l111lll11l1_l1_ = l111l1llll1_l1_[l1111l111ll_l1_]
		elif l11ll1lll1l_l1_:
			l1111l111ll_l1_ = l11l111l111_l1_.index(l1lllll1_l1_)
			l111l1l1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ㤻")][l1111l111ll_l1_]
			l111lll11l1_l1_ = l11l1l1l1l1_l1_[l1111l111ll_l1_]
	if l1llll11l1l1_l1_==l1l111_l1_ (u"ࠨࠩ㤼"): l1llll11l1l1_l1_ = l1ll1l11lll1_l1_
	elif l1llll11l1l1_l1_==None and l1ll1ll1llll_l1_ in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㤽"),l1l111_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ㤾")] and l11ll1ll111_l1_: l1llll11l1l1_l1_ = l1ll1l11lll1_l1_
	l1llll11l111_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㤿")][7]
	l1lll111ll1l_l1_ = l1ll1llll111_l1_ and l1l111_l1_ (u"ࠬࡹࡣࡳࡣࡳࡩࠬ㥀") in l1ll1llll111_l1_
	if l1lll111ll1l_l1_: l1l111l11l1_l1_ = 60
	elif l1ll1ll1lll1_l1_ or l11ll1lll1l_l1_: l1l111l11l1_l1_ = 15
	elif source in l1111l11111_l1_: l1l111l11l1_l1_ = 10
	elif source==l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭㥁"): l1l111l11l1_l1_ = 120
	elif source==l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㥂"): l1l111l11l1_l1_ = 20
	elif source==l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㥃"): l1l111l11l1_l1_ = 20
	elif l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫ㥄") in source: l1l111l11l1_l1_ = 70
	elif l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ㥅") in source: l1l111l11l1_l1_ = 75
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㥆") in source: l1l111l11l1_l1_ = 25
	elif l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㥇") in source: l1l111l11l1_l1_ = 20
	elif l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㥈") in source: l1l111l11l1_l1_ = 20
	elif l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㥉") in source: l1l111l11l1_l1_ = 30
	elif l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㥊") in source: l1l111l11l1_l1_ = 25
	elif l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㥋") in source: l1l111l11l1_l1_ = 30
	elif l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㥌") in source: l1l111l11l1_l1_ = 20
	elif l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭㥍") in source: l1l111l11l1_l1_ = 60
	else: l1l111l11l1_l1_ = 15
	if l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㥎") in source and not l1l11llll_l1_ and l1l111_l1_ (u"࠭ࠦࠨ㥏") not in l1lllll1_l1_ and l1l111_l1_ (u"ࠧࡀࠩ㥐") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪ㥑"))+l1l111_l1_ (u"ࠩ࠲ࠫ㥒")
	l11lll1111l_l1_ = (l1ll1llll111_l1_!=None)
	l1llll1111l1_l1_ = (l1llll11l1l1_l1_!=None and l1ll1ll1llll_l1_!=l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㥓"))
	if l11lll1111l_l1_ and not l1lll111ll1l_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧ㥔"),l1ll1llll111_l1_)
	elif l1llll1111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬ㥕"),l1llll11l1l1_l1_)
	if l11lll1111l_l1_:
		proxies = {l1l111_l1_ (u"ࠨࡨࡵࡶࡳࠦ㥖"):l1ll1llll111_l1_,l1l111_l1_ (u"ࠢࡩࡶࡷࡴࡸࠨ㥗"):l1ll1llll111_l1_}
		l1111l1l1ll_l1_ = l1ll1llll111_l1_
	else: proxies,l1111l1l1ll_l1_ = {},l1l111_l1_ (u"ࠨࠩ㥘")
	if l1llll1111l1_l1_:
		import urllib3.util.connection as connection
		l11l11llll1_l1_ = l1ll1l1llll1_l1_(connection,l1ll1l11lll1_l1_)
	l1lll1111lll_l1_,l1lll1l111l1_l1_,l1l11lll1_l1_,l11llll1111_l1_,l11ll1lllll_l1_,verify = l1lll1111ll1_l1_,source,method,False,False,l1llll1l1l11_l1_
	if l1llll11l111_l1_: l11ll1lllll_l1_ = True
	if l11l111ll11_l1_ or l1lll1111ll1_l1_: l1lll1111lll_l1_ = False
	if l1ll1ll1lll1_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㥙")
	import requests
	code,reason = -1,l1l111_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪ㥚")
	for l1l111llll_l1_ in range(9):
		l111111llll_l1_ = True
		succeeded = False
		try:
			if l1l111llll_l1_: l1lll1l111l1_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠳ࡶࡸࠬ㥛")
			if l1lll111ll1l_l1_ or not l11lll1111l_l1_: l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡑࡓࡉࡓࡥࡕࡓࡎࠪ㥜"),url,l1l11llll_l1_,l1ll1ll1l_l1_,l1lll1l111l1_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=l1l11llll_l1_,headers=l1ll1ll1l_l1_,verify=verify,allow_redirects=l1lll1111lll_l1_,timeout=l1l111l11l1_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11llll1111_l1_:
					l1111l1lll1_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㥝") in l1111l1lll1_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㥞")]
					elif l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ㥟") in l1111l1lll1_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ㥠")]
					else: l11llll1111_l1_ = True
					if not l11llll1111_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠪࡰࡦࡺࡩ࡯࠯࠴ࠫ㥡"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ㥢")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㥣"),l1l111_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭㥤"))
					if l11l111ll11_l1_ and response.status_code==307:
						l1lll1111lll_l1_ = l1lll1111ll1_l1_
						l1l11lll1_l1_ = method
						l11llll1111_l1_ = True
						l1llll1lll11_l1_
				if not l11llll1111_l1_ or l1lll1111ll1_l1_:
					if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ㥥") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ㥦"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠩ࠲ࠫ㥧")+l1lllll1_l1_.lstrip(l1l111_l1_ (u"ࠪ࠳ࠬ㥨"))
				if not l11llll1111_l1_ and l1lll1111ll1_l1_:
					l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1lllll1_l1_)
					if l11ll1l1l1_l1_ not in [l1l111_l1_ (u"ࠫ࠳ࡧࡶࡪࠩ㥩"),l1l111_l1_ (u"ࠬ࠴ࡴࡴࠩ㥪"),l1l111_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ㥫"),l1l111_l1_ (u"ࠧ࠯ࡣࡤࡧࠬ㥬"),l1l111_l1_ (u"ࠨ࠰ࡰ࡯ࡻ࠭㥭"),l1l111_l1_ (u"ࠩ࠱ࡱࡵ࠹ࠧ㥮"),l1l111_l1_ (u"ࠪ࠲ࡼ࡫ࡢ࡮ࠩ㥯")]: l1llll1lll11_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11ll1lllll_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if PY2: reason = str(err.message).split(l1l111_l1_ (u"ࠫ࠿ࠦࠧ㥰"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠬࡀࠠࠨ㥱"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"࠭ࡅࡳࡴࡱࡳࠬ㥲") in error: code,reason = re.findall(l1l111_l1_ (u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤ㥳"),error)[0]
				elif l1l111_l1_ (u"ࠨ࠮ࠣࡩࡷࡸ࡯ࡳࠪࠪ㥴") in error: code,reason = re.findall(l1l111_l1_ (u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ㥵"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠪ࠾ࠬ㥶"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠫ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠧ㥷"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if PY2: reason = err.message
			else: reason = str(err)
		except:
			l111111llll_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㥸"),l1l111_l1_ (u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㥹")+str(code)+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ㥺")+reason+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㥻")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㥼")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㥽"))
		if l1lll111l111_l1_ and l11l111ll11_l1_ and l111111llll_l1_ and not l11ll1lllll_l1_ and code!=200:
			l1lllll1_l1_ = l111l1l1lll_l1_
			l11ll1lllll_l1_ = True
			continue
		if l111111llll_l1_: break
	if l1llll11l1l1_l1_!=None and l1ll1ll1llll_l1_!=l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㥾"): connection.create_connection = l11l11llll1_l1_
	if l1ll1ll1llll_l1_==l1l111_l1_ (u"ࠬࡇࡌࡘࡃ࡜ࡗࠬ㥿") and l11ll1ll111_l1_: l1llll11l1l1_l1_ = None
	if not succeeded and l1ll1llll111_l1_==None and source not in l1111l11111_l1_:
		l111l1ll1ll_l1_ = traceback.format_exc()
		sys.stderr.write(l111l1ll1ll_l1_)
	l1lll1l11_l1_ = l1l1llllll1_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"࠭ࠧ㦀")
	try: l1ll1ll11_l1_ = response.headers
	except: l1ll1ll11_l1_ = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if PY3:
		try: content = content.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㦁"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = l1ll1ll11_l1_
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if PY2 or isinstance(l1lll1l11_l1_.content,str): l111llll1l1_l1_ = l1lll1l11_l1_.content.lower()
	else: l111llll1l1_l1_ = l1l111_l1_ (u"ࠨࠩ㦂")
	l1lllllllll1_l1_ = (l1l111_l1_ (u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㦃") in l111llll1l1_l1_ or l1l111_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪ㦄") in l111llll1l1_l1_) and l111llll1l1_l1_.count(l1l111_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ㦅"))>2 and l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㦆") not in source and l1l111_l1_ (u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨ㦇") not in l111llll1l1_l1_
	if code==200 and l1lllllllll1_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1lll111l111_l1_ and l11l111ll11_l1_:
		if l1llll11l111_l1_: l111lll11l1_l1_ = l1l111_l1_ (u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨ㦈")+l1l11llll_l1_[l1l111_l1_ (u"ࠨ࡬ࡲࡦࠬ㦉")].upper().replace(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㦊"),l1l111_l1_ (u"ࠪࠫ㦋"))
		l1lll11ll_l1_ = l1ll1111111_l1_(l111lll11l1_l1_)
	if not l1lll1l11_l1_.succeeded and l1lll111l111_l1_:
		l1llllllll11_l1_ = (l1l111_l1_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㦌") in l111llll1l1_l1_ and l1l111_l1_ (u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧ㦍") in l111llll1l1_l1_)
		l1llllllll1l_l1_ = (l1l111_l1_ (u"࠭࠵ࠡࡵࡨࡧࠬ㦎") in l111llll1l1_l1_ and l1l111_l1_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨ㦏") in l111llll1l1_l1_)
		l1111111111_l1_ = (code in [403] and l1l111_l1_ (u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫ㦐") in l111llll1l1_l1_)
		l111111111l_l1_ = (l1l111_l1_ (u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫ㦑") in l111llll1l1_l1_ and l1l111_l1_ (u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧ㦒") in l111llll1l1_l1_)
		if   l1lllllllll1_l1_: reason = l1l111_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ㦓")
		elif l1llllllll11_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㦔")
		elif l1llllllll1l_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭㦕")
		elif l1111111111_l1_: reason = l1l111_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨ㦖")
		elif l111111111l_l1_: reason = l1l111_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ㦗")
		else: reason = str(reason)
		if source in l1111l11111_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㦘"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㦙")+str(code)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ㦚")+reason+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㦛")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㦜")+l1lllll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㦝"))
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㦞"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㦟")+str(code)+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ㦠")+reason+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㦡")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㦢")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㦣"))
		l111l11l111_l1_ = l111l11_l1_(l1lllll1_l1_)
		if PY2 and isinstance(l111l11l111_l1_,unicode): l111l11l111_l1_ = l111l11l111_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㦤"))
		if l11l111ll11_l1_: l111l11l111_l1_ = l111l11l111_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ㦥"))[-1]
		reason = str(reason)+l1l111_l1_ (u"ࠩ࡟ࡲ࠭ࠦࠧ㦦")+l111l11l111_l1_+l1l111_l1_ (u"ࠪࠤ࠮࠭㦧")
		if l1lllllllll1_l1_ or l1llllllll11_l1_ or l1llllllll1l_l1_ or l1111111111_l1_ or l111111111l_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
			l1ll1lll_l1_(l1l111_l1_ (u"๊ࠫำว้ๆฬࠤฯาว้ิࠪ㦨"),l1l111_l1_ (u"ࠬอไโฯุࠤฬ๊รๆ่ํࠫ㦩"),time=1500)
			l1ll1lll11ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫ㦪"))
			l1ll1lll1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠶ࠬ㦫"))
			l1ll1lll11ll_l1_ = 9999 if not l1ll1lll11ll_l1_ else int(l1ll1lll11ll_l1_)
			l1ll1lll1l11_l1_ = 9999 if not l1ll1lll1l11_l1_ else int(l1ll1lll1l11_l1_)
			l11llll11l1_l1_ = []
			if l1ll1lll11ll_l1_>10: l11llll11l1_l1_.append(1)
			if l1ll1lll1l11_l1_>10: l11llll11l1_l1_.append(2)
			l11llll11l1_l1_.append(3)
			l11lll11l1l_l1_ = random.sample(l11llll11l1_l1_,1)[0]
			if l11lll11l1l_l1_==1:
				l11111l1ll1_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵࠽ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫ㦬")
				l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ㦭")+l11111l1ll1_l1_+l1l111_l1_ (u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ㦮")
				l1llllllllll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠴ࡱࡨࠬ㦯"),False,False)
				if l1llllllllll_l1_.succeeded:
					l1ll1l1l1111_l1_ = l1llllllllll_l1_.headers[l1l111_l1_ (u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬ㦰")]
					settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫ㦱"),l1ll1l1l1111_l1_)
					return l1llllllllll_l1_
			elif l11lll11l1l_l1_==2:
				l11111l1ll1_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲ࡥ࠶ࡨ࠸ࡧࡥ࠲࠺࠸ࡨ࡫࠺ࡢࡧ࠸ࡤࡪ࠺࠹࠳ࡤ࠹࠳࠸࠵ࡨ࠳࠵࠹ࡦ࠽ࡪ࠿࠹ࡣࡧ࠷࠺࠻ࡧࡥ࠺࠼ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪ㦲")
				l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㦳")+l11111l1ll1_l1_+l1l111_l1_ (u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ㦴")
				l1llllllllll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠴ࡴࡧࠫ㦵"),False,False)
				if l1llllllllll_l1_.succeeded:
					l1ll1l1l1111_l1_ = l1llllllllll_l1_.headers[l1l111_l1_ (u"ࠫࡘࡩࡲࡢࡲࡨ࠲ࡩࡵ࠭ࡓࡧࡰࡥ࡮ࡴࡩ࡯ࡩ࠰ࡇࡷ࡫ࡤࡪࡶࡶࠫ㦶")]
					settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠴ࠪ㦷"),l1ll1l1l1111_l1_)
					return l1llllllllll_l1_
			elif l11lll11l1l_l1_==3:
				l11111l1ll1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭㦸")
				l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ㦹")+l11111l1ll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨ㦺")
				l1llllllllll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,method,l1111111_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠴ࡵࡪࠪ㦻"),False,False)
				if l1llllllllll_l1_.succeeded: return l1llllllllll_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"่้ࠪษำโࠢไุ้ࠦวๅใะูࠥอไฤ็้๎ࠬ㦼"),l1l111_l1_ (u"ࠫัืศࠡ็ิอࠥษฮา๋ࠪ㦽"),time=2000)
		l1llll111l_l1_ = True
		if (l1ll1ll1llll_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㦾") or l1lll1111111_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㦿")) and (l11ll1ll111_l1_ or l1llll111lll_l1_):
			l1llll111l_l1_ = l11111l1l1l_l1_(code,reason,source,l11_l1_)
			if l1llll111l_l1_ and l1ll1ll1llll_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧀"): l1ll1ll1llll_l1_ = l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧁")
			else: l1ll1ll1llll_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㧂")
			if l1llll111l_l1_ and l1lll1111111_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㧃"): l1lll1111111_l1_ = l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㧄")
			else: l1lll1111111_l1_ = l1l111_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ㧅")
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㧆"),l1ll1ll1llll_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㧇"),l1lll1111111_l1_)
		if l1llll111l_l1_:
			l1ll1l1l1l11_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ㧈") in l1lllll1_l1_ and l1ll1l1l1l11_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩ㧉"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧊"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ㧋")
				l1lll11ll_l1_ = l111l1lll1l_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠸ࡸ࡭࠭㧌"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㧍"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㧎")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧏")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㧐"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧ㧑"),l1l111_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭㧒"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㧓"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧔")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㧕")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㧖"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬ㧗"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧘"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1lll1111111_l1_ in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㧙"),l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㧚")] and l1llll111lll_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭㧛"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧜"),time=2000)
				l1lll11ll_l1_ = l11ll1ll1l1_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠼ࡴࡩࠩ㧝"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㧞"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡐࡳࡱࡻ࡭ࡪࡹࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㧟")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㧠")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㧡"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอษะࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㧢"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧣"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㧤"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㧥")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧦")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧧"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ㧨"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧩"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1ll1llll_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㧪"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧫")] and l11ll1ll111_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืࠠࡅࡐࡖࠫ㧬"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧭"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠫࢁࢂࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩ㧮")
				l1lll11ll_l1_ = l111l1lll1l_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠺ࡸ࡭࠭㧯"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㧰"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧ㧱")+l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㧲")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧳")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㧴"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㧵"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧶"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㧷"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ㧸")+l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㧹")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧺")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㧻"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫๆฺไࠡีํีๆืࠠࡅࡐࡖࠫ㧼"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧽"),time=2000)
		if l1lll1111111_l1_==l1l111_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㧾") or l1ll1ll1llll_l1_==l1l111_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㧿"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11llll111l_l1_ = l11111l1l1l_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1lll1ll_l1_ and l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࠬ㨀") not in source:
				l1111lll1ll_l1_(l1l111_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡹ࡬ࡸ࡭ࡀࠠࠨ㨁")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㨂")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㨃"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㨄"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㨅")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㨆"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㨇"))
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ㨈")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㨉"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㨊"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㨋")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㨌"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㨍"))
	return l1lll1l11_l1_
def l11l1l_l1_(cache,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll111_l1_=True,l1llll111lll_l1_=True):
	l1lllll1_l1_,l1ll1llll111_l1_,l1llll11l1l1_l1_,l1llll1l1l11_l1_ = l1ll1ll11l1l_l1_(url)
	item = method,l1lllll1_l1_,data,headers,allow_redirects
	if cache:
		response = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ㨎"),l1l111_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ㨏"),item)
		if response.succeeded:
			l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪ㨐"),url,data,headers,source,method)
			return response
	response = l111l1lll1l_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll111_l1_,l1llll111lll_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㨑") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if cache: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ㨒"),item,response,cache)
	return response
def l1l1llll_l1_(cache,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㨓")
	else:
		method = l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㨔")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(cache,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll1ll11l1l_l1_(url):
	l1ll1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠨࡾࡿࠫ㨕"))
	l1lllll1_l1_,l1ll1llll111_l1_,l1llll11l1l1_l1_,l1llll1l1l11_l1_ = l1ll1llllll1_l1_[0],None,None,True
	for item in l1ll1llllll1_l1_:
		if l1l111_l1_ (u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ㨖") in item: l1ll1llll111_l1_ = item.split(l1l111_l1_ (u"ࠪࡁࠬ㨗"))[1]
		elif l1l111_l1_ (u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ㨘") in item: l1llll11l1l1_l1_ = item.split(l1l111_l1_ (u"ࠬࡃࠧ㨙"))[1]
		elif l1l111_l1_ (u"࠭ࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ㨚") in item: l1llll1l1l11_l1_ = False
	return l1lllll1_l1_,l1ll1llll111_l1_,l1llll11l1l1_l1_,l1llll1l1l11_l1_
def l11lll1ll1l_l1_(name):
	start,l1lll11ll1l_l1_,modified = l1l111_l1_ (u"ࠧࠨ㨛"),l1l111_l1_ (u"ࠨࠩ㨜"),l1l111_l1_ (u"ࠩࠪ㨝")
	name = name.replace(ltr,l1l111_l1_ (u"ࠪࠫ㨞")).replace(rtl,l1l111_l1_ (u"ࠫࠬ㨟"))
	tmp = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠪ࡞࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡠࡢ࠮࡜ࡸ࡞ࡺࡠࡼ࠯ࠠࠬ࡞࡞ࡠ࠴ࡉࡏࡍࡑࡕࡠࡢ࠮࠮ࠫࡁࠬࠨࠬ㨠"),name,re.DOTALL)
	if tmp: start,l1lll11ll1l_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"࠭ࠠࠨ㨡"),l1l111_l1_ (u"ࠧ࠭ࠩ㨢"),l1l111_l1_ (u"ࠨࠩ㨣")]: modified = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㨤")
	if l1lll11ll1l_l1_: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡣࠬ㨥")+l1lll11ll1l_l1_+l1l111_l1_ (u"ࠫࡤ࠭㨦")
	name = l1lll11ll1l_l1_+modified+name
	return name
def l1lllll1l1l_l1_(cache,method,url,l1lll1l1llll_l1_,l1lll1llll1l_l1_,l11111lllll_l1_,headers=l1l111_l1_ (u"ࠬ࠭㨧")):
	l1ll11llll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㨨"))
	l11l1ll1111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ㨩")+l1lll1l1llll_l1_)
	if l1ll11llll1l_l1_==l11l1ll1111_l1_: settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ㨪")+l1lll1l1llll_l1_,l1l111_l1_ (u"ࠩࠪ㨫"))
	if l11l1ll1111_l1_: l1llllll_l1_ = url.replace(l1ll11llll1l_l1_,l11l1ll1111_l1_)
	else:
		l1llllll_l1_ = url
		l11l1ll1111_l1_ = l1ll11llll1l_l1_
	l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠪࠫ㨬"),headers,l1l111_l1_ (u"ࠫࠬ㨭"),l1l111_l1_ (u"ࠬ࠭㨮"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ㨯"))
	html = l1lll11ll_l1_.content
	if PY3:
		try: html = html.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㨰"),l1l111_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ㨱"))
		except: pass
	code = l1lll11ll_l1_.code
	if code!=-2 and (not l1lll11ll_l1_.succeeded or l11111lllll_l1_ not in html):
		l1lll1llll1l_l1_ = l1lll1llll1l_l1_.replace(l1l111_l1_ (u"ࠩࠣࠫ㨲"),l1l111_l1_ (u"ࠪ࠯ࠬ㨳"))
		l1lllll1_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ㨴")+l1lll1llll1l_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㨵"):l1l111_l1_ (u"࠭ࠧ㨶")}
		l1lll1l11_l1_ = l11l1l_l1_(cache,method,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㨷"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ㨸"),l1l111_l1_ (u"ࠩࠪ㨹"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠶ࡳࡪࠧ㨺"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if PY3:
				try: html = html.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㨻"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㨼"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱࡟ࡻ࠯ࡢ࠿࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ㨽"),html,re.DOTALL)
			l111l1l11ll_l1_ = [l11l1ll1111_l1_]
			l111ll1l111_l1_ = [l1l111_l1_ (u"ࠧࡢࡲ࡮ࠫ㨾"),l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㨿"),l1l111_l1_ (u"ࠩࡷࡻ࡮ࡺࡴࡦࡴࠪ㩀"),l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ㩁"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭㩂"),l1l111_l1_ (u"ࠬࡶࡨࡱࠩ㩃"),l1l111_l1_ (u"࠭ࡡࡵ࡮ࡤࡵࠬ㩄"),l1l111_l1_ (u"ࠧࡴ࡫ࡷࡩ࡮ࡴࡤࡪࡥࡨࡷࠬ㩅"),l1l111_l1_ (u"ࠨࡵࡸࡶ࠳ࡲࡹࠨ㩆"),l1l111_l1_ (u"ࠩࡥࡰࡴ࡭ࡳࡱࡱࡷࠫ㩇"),l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡳ࡯ࡨࡶࠬ㩈"),l1l111_l1_ (u"ࠫࡸ࡯ࡴࡦ࡮࡬࡯ࡪ࠭㩉"),l1l111_l1_ (u"ࠬ࡯࡮ࡴࡶࡤ࡫ࡷࡧ࡭ࠨ㩊"),l1l111_l1_ (u"࠭ࡳ࡯ࡣࡳࡧ࡭ࡧࡴࠨ㩋"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠲࡫ࡱࡶ࡫ࡹࠫ㩌"),l1l111_l1_ (u"ࠨࡨࡤࡷࡪࡲࡰ࡭ࡷࡶࠫ㩍")]
			for l1ll1ll_l1_ in l1ll_l1_:
				if any(value in l1ll1ll_l1_ for value in l111ll1l111_l1_): continue
				l11l1ll1111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭㩎"))
				if l11l1ll1111_l1_ in l111l1l11ll_l1_: continue
				if len(l111l1l11ll_l1_)==9:
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㩏"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫ㩐")+l1lll1l1llll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪ㩑")+l1ll11llll1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㩒"))
					settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ㩓")+l1lll1l1llll_l1_,l1l111_l1_ (u"ࠨࠩ㩔"))
					break
				l111l1l11ll_l1_.append(l11l1ll1111_l1_)
				l1llllll_l1_ = url.replace(l1ll11llll1l_l1_,l11l1ll1111_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㩕"),headers,l1l111_l1_ (u"ࠪࠫ㩖"),l1l111_l1_ (u"ࠫࠬ㩗"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ㩘"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l11111lllll_l1_ in html:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㩙"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡪࡴࡻ࡮ࡥࠢࡤࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ㩚")+l1lll1l1llll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡎࡦࡹ࠽ࠤࡠࠦࠧ㩛")+l11l1ll1111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ㩜")+l1ll11llll1l_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㩝"))
					settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭㩞")+l1lll1l1llll_l1_,l11l1ll1111_l1_)
					break
	return l11l1ll1111_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠬࡵ࡬ࡥࠩ㩟")			:l1l111_l1_ (u"࠭โะ์่ࠫ㩠")
	,l1l111_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ㩡")		:l1l111_l1_ (u"ࠨ็อ์็็ࠧ㩢")
	,l1l111_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㩣")		:l1l111_l1_ (u"้ࠪๆ่่ะࠩ㩤")
	,l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ㩥")			:l1l111_l1_ (u"ࠬา๊ะࠩ㩦")
	,l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㩧")		:l1l111_l1_ (u"ࠧโึ็ࠫ㩨")
	,l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㩩")		:l1l111_l1_ (u"่ࠩะ้ีࠧ㩪")
	,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㩫")		:l1l111_l1_ (u"ࠫๆ๐ฯ๋๊ࠪ㩬")
	,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㩭")			:l1l111_l1_ (u"࠭โ็ษฬࠫ㩮")
	,l1l111_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠭㩯")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬ㩰")
	,l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㩱")		:l1l111_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ㩲")
	,l1l111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭㩳")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭㩴")
	,l1l111_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭㩵")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ㩶")
	,l1l111_l1_ (u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ㩷")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ㩸")
	,l1l111_l1_ (u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭㩹")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ㩺")
	,l1l111_l1_ (u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ㩻")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ㩼")
	,l1l111_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ㩽")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ㩾")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭㩿")	:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ㪀")
	,l1l111_l1_ (u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭㪁")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣหู้๊็็สࠫ㪂")
	,l1l111_l1_ (u"࠭ࡨࡦ࡮ࡤࡰࠬ㪃")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ㪄")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪ㪅")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ㪆")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ㪇")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭㪈")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧ㪉")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭㪊")
	,l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ㪋")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ㪌")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ㪍")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪ㪎")
	,l1l111_l1_ (u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧ㪏")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨ㪐")
	,l1l111_l1_ (u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㪑")	:l1l111_l1_ (u"ࠧๆ๊สๆ฾๊้ࠦฬํ์อ࠭㪒")
	,l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㪓")		:l1l111_l1_ (u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩ㪔")
	,l1l111_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㪕")		:l1l111_l1_ (u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠪ㪖")
	,l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ㪗")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ㪘")
	,l1l111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩ㪙")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫ㪚")
	,l1l111_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ㪛")		:l1l111_l1_ (u"้ࠪํู่ࠡสๆีฬ࠭㪜")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭㪝")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭㪞")
	,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࡸࡻ࠭㪟")		:l1l111_l1_ (u"ࠧๆๆไࠫ㪠")
	,l1l111_l1_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺࠩ㪡")		:l1l111_l1_ (u"่่ࠩๆ࠭㪢")
	,l1l111_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ㪣")		:l1l111_l1_ (u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭㪤")
	,l1l111_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨ㪥")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫ㪦")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ㪧")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ㪨")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ㪩")		:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭㪪")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠷࠭㪫")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠲ࠨ㪬")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ㪭")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪ㪮")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠶ࠪ㪯")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬ㪰")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ㪱")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭㪲")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ㪳")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭㪴")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨ㪵")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨ㪶")
	,l1l111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ㪷")		:l1l111_l1_ (u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪ㪸")
	,l1l111_l1_ (u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬ㪹")		:l1l111_l1_ (u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫ㪺")
	,l1l111_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ㪻")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ㪼")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ㪽")	:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ㪾")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧ㪿")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬ㫀")
	,l1l111_l1_ (u"ࠬ࡬࡯ࡴࡶࡤࠫ㫁")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪ㫂")
	,l1l111_l1_ (u"ࠧࡢࡪࡺࡥࡰ࠭㫃")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪ㫄")
	,l1l111_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ㫅")		:l1l111_l1_ (u"้ࠪํู่ࠡใหี่ฯࠧ㫆")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪ㫇")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪ㫈")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨ㫉")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨ㫊")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡳ࡫࡮ࡡࠨ㫋")		:l1l111_l1_ (u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫ㫌")
	,l1l111_l1_ (u"ࠪࡦࡷࡹࡴࡦ࡬ࠪ㫍")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢหีุะ๊อࠩ㫎")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷࠴࠵࠭㫏")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭㫐")
	,l1l111_l1_ (u"ࠧ࡭ࡣࡵࡳࡿࡧࠧ㫑")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭㫒")
	,l1l111_l1_ (u"ࠩࡼࡥࡶࡵࡴࠨ㫓")		:l1l111_l1_ (u"้ࠪํู่ࠡ์สๆํะࠧ㫔")
	,l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭㫕")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ็ฯ้่หࠩ㫖")
	,l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨ㫗")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩ㫘")
	,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭㫙")	:l1l111_l1_ (u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫ㫚")
	,l1l111_l1_ (u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫ㫛")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫ㫜")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ㫝")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬ㫞")
	,l1l111_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠭㫟")				:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ㫠")
	,l1l111_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨ㫡")			:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬ㫢")
	,l1l111_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫ㫣")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪ㫤")
	,l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸࠬ㫥")				:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠫ㫦")
	,l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㫧")			:l1l111_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬ㫨")
	,l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡶࡩࡷ࡯ࡥࡴࠩ㫩")			:l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩ㫪")
	,l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭㫫")				:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫ㫬")
	,l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨ㫭")		:l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ㫮")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭㫯")	:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧ㫰")
	,l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧ㫱")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩ㫲")
	,l1l111_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩ㫳")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩ㫴")
	,l1l111_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬ㫵")	:l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩ㫶")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭㫷")		:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬ㫸")
	,l1l111_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨ㫹")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨ㫺")
	,l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㫻")			:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩ㫼")
	,l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧ㫽")	:l1l111_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭㫾")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ㫿"):l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬ㬀")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭㬁")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧ㬂")
	,l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭㬃")	:l1l111_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪ㬄")
	,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶࠨ㬅")					:l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㬆")
	,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨ㬇")			:l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪ㬈")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬉")			:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬ㬊")
	,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬋")			:l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩ㬌")
	,l1l111_l1_ (u"ࠫࡲ࠹ࡵࠨ㬍")					:l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㬎")
	,l1l111_l1_ (u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨ㬏")				:l1l111_l1_ (u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪ㬐")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬑")			:l1l111_l1_ (u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬ㬒")
	,l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬓")			:l1l111_l1_ (u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩ㬔")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠬ࠭㬕")
	return result
def l1111lll1ll_l1_(message=l1l111_l1_ (u"࠭ࠧ㬖")):
	l1lll1llllll_l1_()
	if not message: message = l1l111_l1_ (u"ࠧࡇࡱࡵࡧࡪࡪࠠࡆࡺ࡬ࡸࠬ㬗")
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࠩ㬘"),l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㬙")+message+l1l111_l1_ (u"ࠪࡠࡳ࠭㬚"))
	try: sys.exit()
	except: pass
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠫ࠿࠵ࠧ㬛")):
	return _111111ll11_l1_(urll,exceptions)
def l11l11ll111_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠬ࠭㬜"),l1l111_l1_ (u"࠭࠰ࠨ㬝"),0]: return l1l111_l1_ (u"ࠧࠨ㬞")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1llll11_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111lllll11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1llll11_l1_)+str(l111lllll11_l1_)+str(l111l111_l1_)
	return result
def l1ll1llll1ll_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠨࠩ㬟"),l1l111_l1_ (u"ࠩ࠳ࠫ㬠"),0]: return l1l111_l1_ (u"ࠪࠫ㬡")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠫࠬ㬢")
	if len(l1l1llll1_l1_)==15:
		l11l1llll11_l1_,l111lllll11_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1llll11_l1_ = int(l11l1llll11_l1_)^l111l11l_l1_
		l111lllll11_l1_ = int(l111lllll11_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1llll11_l1_==l111lllll11_l1_==l111l111_l1_: result = str(l11l1llll11_l1_*60)
	return result
def l1llll1111ll_l1_(l1l1llll1_l1_,l1llll1l1111_l1_=l1l111_l1_ (u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧ㬣")):
	if l1l1llll1_l1_==l1l111_l1_ (u"࠭ࠧ㬤"): return l1l111_l1_ (u"ࠧࠨ㬥")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1llll1l1111_l1_)
	l11l1llll11_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111lllll11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1llll11_l1_)+str(l111lllll11_l1_)+str(l111l111_l1_)
	return result
def l1111lll11l_l1_(l1l1llll1_l1_,l1llll1l1111_l1_=l1l111_l1_ (u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪ㬦")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠩࠪ㬧"): return l1l111_l1_ (u"ࠪࠫ㬨")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l1l1111_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1llll11_l1_ = int(l1l1llll1_l1_[0:l1l1l1l1111_l1_])^l1ll1ll1_l1_
	l111lllll11_l1_ = int(l1l1llll1_l1_[l1l1l1l1111_l1_:2*l1l1l1l1111_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l1l1111_l1_:3*l1l1l1l1111_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠫࠬ㬩")
	if l11l1llll11_l1_==l111lllll11_l1_==l111l111_l1_: result = str(int(l11l1llll11_l1_)-int(l1llll1l1111_l1_))
	return result
def l1l1ll111ll_l1_(l1l11ll111l_l1_):
	l1111111l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㬪")][8]
	l1lll1l11lll_l1_ = l1l1ll11l11_l1_(32)
	l1lll1l1l1l1_l1_ = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ㬫"),l1l111_l1_ (u"ࠧࡴ࡭࡬ࡲࡸ࠭㬬"),l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㬭"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㬮"),l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ㬯"))
	l11ll1l1111_l1_,l11l111llll_l1_ = l1ll1l11ll_l1_(l1lll1l1l1l1_l1_)
	l11ll1l1111_l1_ = l1llll1111ll_l1_(l11ll1l1111_l1_,l1l111_l1_ (u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧ㬰"))
	l111llll111_l1_ = {l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㬱"):l1l111_l1_ (u"࠭ࡄࡊࡃࡏࡓࡌ࠭㬲"),l1l111_l1_ (u"ࠧࡶࡵࡵࠫ㬳"):l1lll1l11lll_l1_,l1l111_l1_ (u"ࠨࡸࡨࡶࠬ㬴"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠩࡶࡧࡷ࠭㬵"):l1l11ll111l_l1_,l1l111_l1_ (u"ࠪࡷ࡮ࢀࠧ㬶"):l11ll1l1111_l1_}
	l1llll1ll111_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㬷"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㬸")}
	l111111l1l1_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㬹"),l1111111l11_l1_,l111llll111_l1_,l1llll1ll111_l1_,l1l111_l1_ (u"ࠧࠨ㬺"),l1l111_l1_ (u"ࠨࠩ㬻"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪ㬼"))
	l1ll1l1l1ll1_l1_ = l111111l1l1_l1_.content
	try:
		if not l1ll1l1l1ll1_l1_: l1ll1lll11l1_l1_
		l1llll1l1l1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㬽"),l1ll1l1l1ll1_l1_)
		l1ll1l1l111l_l1_ = l1llll1l1l1l_l1_[l1l111_l1_ (u"ࠫࡲࡹࡧࠨ㬾")]
		l1ll1lll1l1l_l1_ = l1llll1l1l1l_l1_[l1l111_l1_ (u"ࠬࡹࡥࡤࠩ㬿")]
		l1lllll1l11l_l1_ = l1llll1l1l1l_l1_[l1l111_l1_ (u"࠭ࡳࡵࡲࠪ㭀")]
		l1ll1lll1l1l_l1_ = int(l1111lll11l_l1_(l1ll1lll1l1l_l1_,l1l111_l1_ (u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪ㭁")))
		l1lllll1l11l_l1_ = int(l1111lll11l_l1_(l1lllll1l11l_l1_,l1l111_l1_ (u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫ㭂")))
		for l111ll111l1_l1_ in range(l1ll1lll1l1l_l1_,0,-l1lllll1l11l_l1_):
			if not eval(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬ㭃")): l1ll1lll11l1_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩ㭄"),str(l111ll111l1_l1_)+l1l111_l1_ (u"ࠫࠥࠦหศ่ํอࠬ㭅"),time=300*l1lllll1l11l_l1_)
			xbmc.sleep(1000*l1lllll1l11l_l1_)
		if eval(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨ㭆")):
			l111llll11l_l1_ = l1l111_l1_ (u"ࠨࡄࡊࡃࡏࡓࡌ࡭࡟ࡐࡍࠫࠫࠬ࠲ࠧฯำ๋ะࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬࠨ㭇")+l1ll1l1l111l_l1_+l1l111_l1_ (u"ࠢࠨࠫࠥ㭈")
			l111llll11l_l1_ = l111llll11l_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㭉"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㭊")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㭋"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㭌"))
			exec(l111llll11l_l1_)
		l1ll1lll11l1_l1_
	except: exec(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ㭍"))
	return
def l1l111l1l1l_l1_():
	exec(l1l111_l1_ (u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫ㭎"))
	return
def l1ll1l11ll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1llll1ll1_l1_(l1lll11ll1l1_l1_,l1lll11l11ll_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨ㭏"),l1l111_l1_ (u"ࠨࠩ㭐"),l1l111_l1_ (u"ࠩࠪ㭑"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㭒"),l1lll11ll1l1_l1_+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㭓")+l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㭔"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1lll11ll1l1_l1_):
		for root,dirs,l1l1111111_l1_ in os.walk(l1lll11ll1l1_l1_,topdown=False):
			for file in l1l1111111_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㭕"),l1l111_l1_ (u"ࠧࠨ㭖"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㭗"),str(err))
					error = True
			if l1lll11l11ll_l1_:
				for dir in dirs:
					l1ll11lll11l_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1ll11lll11l_l1_)
					except: pass
		if l1lll11l11ll_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㭘"),l1l111_l1_ (u"ࠪࠫ㭙"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㭚"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭㭛"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㭜"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ㭝"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㭞"))
	return
def l1lll1llllll_l1_(l111l1ll1ll_l1_=l1l111_l1_ (u"ࠩࠪ㭟")):
	l11ll1ll11l_l1_(l1l111_l1_ (u"ࠪࡷࡹࡵࡰࠨ㭠"))
	if l111l1ll1ll_l1_:
		l1111ll111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㭡"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㭢"),l1l111_l1_ (u"࠭ࠧ㭣"))
		l11ll11l1ll_l1_(l111l1ll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㭤"),l1111ll111l_l1_)
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭥"))
	if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ㭦"): settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㭧"),l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㭨"))
	elif l1ll11l1l1_l1_==l1l111_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㭩"): settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㭪"),l1l111_l1_ (u"ࠧࠨ㭫"))
	if settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㭬")) not in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㭭"),l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㭮"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㭯")]: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㭰"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㭱"))
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㭲")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㭳"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㭴"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㭵")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㭶"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㭷"))
	l11lllll1ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ㭸"))
	l11l1l1111l_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ㭹"))
	if l1l111_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ㭺") in str(l11l1l1111l_l1_) and l11lllll1ll_l1_ in [l1l111_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ㭻"),l1l111_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ㭼")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨ㭽"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l111l1ll11l_l1_,l11ll1ll1ll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l1ll11l_l1_,l11ll1ll1ll_l1_)
	return
def l1lllll111l_l1_(cache,method,url,data,headers,source):
	l1lllll1_l1_,l1ll1llll111_l1_,l1llll11l1l1_l1_,l1llll1l1l11_l1_ = l1ll1ll11l1l_l1_(url)
	item = method,l1lllll1_l1_,data,headers
	if cache:
		html = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㭾"),l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ㭿"),item)
		if html:
			l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬ㮀"),url,data,headers,source,method)
			return html
	html = l1l111l1ll1_l1_(method,url,data,headers,source)
	if html and cache: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ㮁"),item,html,cache)
	return html
DIALOGg_OK = l1111l1_l1_
l1l11111l11_l1_ = l11ll1ll11l_l1_
l11llll11ll_l1_ = l1lll1lll1ll_l1_
DIALOGg_YESNO = l1ll11ll1l_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l111lll1_l1_
DIALOGg_TEXTVIEWER = l1ll1lll1lll_l1_
DIALOGg_CONTEXTMENU = l11ll11ll1l_l1_
l111ll11lll_l1_ = l1l11111l1_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1ll1l111ll1_l1_
l1lll1l1l11l_l1_ = l1l11l1l1l_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l1111l11_l1_
DOWNLOADd_USING_PROGRESSBAR = l11111111l1_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l1l111111_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11lll1_l1_
PERMANENT_CACHEe = l1ll111ll11_l1_
from EXCLUDES import *
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᢃ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉࡍࡍࡡࠪᢄ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"่ࠬๆ้ษอࠤๆ฼วว์ฬࠫᢅ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==470: l1lll_l1_ = l1l1l11_l1_()
	elif mode==471: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==472: l1lll_l1_ = PLAY(url)
	elif mode==473: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==474: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==479: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᢆ"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨᢇ"),l1l111_l1_ (u"ࠨࠩᢈ"),l1l111_l1_ (u"ࠩࠪᢉ"),l1l111_l1_ (u"ࠪࠫᢊ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᢋ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᢌ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"࠭࠯ࠨᢍ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᢎ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢏ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᢐ"),l1l111_l1_ (u"ࠪࠫᢑ"),479,l1l111_l1_ (u"ࠫࠬᢒ"),l1l111_l1_ (u"ࠬ࠭ᢓ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᢔ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᢕ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᢖ"),l1l111_l1_ (u"ࠩࠪᢗ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᢘ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᢙ")+l1lllll_l1_+l1l111_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪᢚ"),l1l11ll_l1_,471,l1l111_l1_ (u"࠭ࠧᢛ"),l1l111_l1_ (u"ࠧࠨᢜ"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪᢝ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᢞ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᢟ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠫࠥࠦࠧᢠ"),l1l111_l1_ (u"ࠬ࠭ᢡ")).strip(l1l111_l1_ (u"࠭ࠠࠨᢢ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧࡤࡣࡷࡁࡴࡴ࡬ࡪࡰࡨ࠱ࡲࡵࡶࡪࡧࡶ࠵ࠬᢣ"),l1l111_l1_ (u"ࠨࡥࡤࡸࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᢤ"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᢥ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᢦ")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᢧ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᢨ"),l1l111_l1_ (u"ᢩ࠭ࠧ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫᢪ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ᢫"),html,re.DOTALL)
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᢬"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ุ้๊ࠪำๅࠢࠪ᢭") in title: continue
		if l1l111_l1_ (u"ࠫอืๆศ็ฯࠤࠬ᢮") in title: continue
		if l1l111_l1_ (u"๊ࠬไไสสีࠬ᢯") in title: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᢰ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᢱ")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᢲ"),url,l1l111_l1_ (u"ࠩࠪᢳ"),l1l111_l1_ (u"ࠪࠫᢴ"),l1l111_l1_ (u"ࠫࠬᢵ"),l1l111_l1_ (u"ࠬ࠭ᢶ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᢷ"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶࠧᢸ") in url: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦࠬᢹ"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᢺ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᢻ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫᢼ") in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡦࡰࡪࡰ࡮ࡹࡨ࠮࡯ࡲࡺ࡮࡫ࡳࠨᢽ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳ࠲ࠩᢾ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡰ࡭ࡸࡩࠧᢿ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡸࡻ࠳ࡣࡩࡣࡱࡲࡪࡲࠧᣀ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"่๊ࠩีࠦวๅสาห๏ฯࠧᣁ") in title and l1l111_l1_ (u"ࠪࡨࡴࡃࡲࡢࡶ࡬ࡲ࡬࠭ᣂ") not in l1ll1ll_l1_: continue
			else: title = l1l111_l1_ (u"ࠫฯืส๋สࠣฬฬูสฯัส้࠿ࠦࠠࠨᣃ")+title
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᣄ"),l1lllll_l1_+title,l1ll1ll_l1_,471)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"࠭ࠧᣅ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᣆ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᣇ"),url,l1l111_l1_ (u"ࠩࠪᣈ"),l1l111_l1_ (u"ࠪࠫᣉ"),l1l111_l1_ (u"ࠫࠬᣊ"),l1l111_l1_ (u"ࠬ࠭ᣋ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᣌ"))
	html = response.content
	items = []
	if request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩᣍ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲࡬࡬ࡶ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣎ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮࠭ᣏ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l1111l11l_l1_ = zip(*items)
		items = zip(l1111l11l_l1_,l1ll_l1_,l11l11_l1_)
	elif request==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᣐ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭ᣑ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪᣒ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l1111l11l_l1_ = zip(*items)
		items = zip(l1111l11l_l1_,l1ll_l1_,l11l11_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᣓ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧᣔ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᣕ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᣖ"),html,re.DOTALL)
		if not l11llll_l1_: return
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᣗ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᣘ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬᣙ"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫᣚ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭ᣛ"),l1l111_l1_ (u"ࠨๅ็๎อ࠭ᣜ"),l1l111_l1_ (u"ࠩส฽้อๆࠨᣝ"),l1l111_l1_ (u"๋ࠪิอแࠨᣞ"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫᣟ"),l1l111_l1_ (u"ࠬ฿ัืࠩᣠ"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭ᣡ"),l1l111_l1_ (u"ࠧศๆห์๊࠭ᣢ"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨᣣ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫᣤ"))
		title = title.replace(l1l111_l1_ (u"้ࠪฬ๐ࠠิ์่หࠬᣥ"),l1l111_l1_ (u"ࠫࠬᣦ")).replace(l1l111_l1_ (u"๋ࠬิศ้าอࠬᣧ"),l1l111_l1_ (u"࠭ࠧᣨ")).strip(l1l111_l1_ (u"ࠧࠡࠩᣩ")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫᣪ"),l1l111_l1_ (u"ࠩࠣࠫᣫ"))
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᣬ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭ᣭ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧᣮ"))
		if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᣯ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩᣰ")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪᣱ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᣲ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᣳ")+title
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᣴ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬᣵ") in title:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ᣶")+l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᣷"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭᣸") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᣹"),l1lllll_l1_+title,l1ll1ll_l1_,471,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᣺"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭᣻"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ᣼")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᣽"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᣾"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ᣿"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫᤀ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬᤁ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤂ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫᤃ")+title,l1ll1ll_l1_,471)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᤄ"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᤅ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨᤆ"),l1ll1ll_l1_,471)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ᤇ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᤈ"),url,l1l111_l1_ (u"ࠫࠬᤉ"),l1l111_l1_ (u"ࠬ࠭ᤊ"),l1l111_l1_ (u"࠭ࠧᤋ"),l1l111_l1_ (u"ࠧࠨᤌ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪᤍ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᤎ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᤏ")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᤐ"),html,re.DOTALL)
	items = []
	if l11ll1l_l1_ and not l1l11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᤑ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࡝࠮ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪᤒ"),block,re.DOTALL)
		for l1l11_l1_,title in items: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᤓ"),l1lllll_l1_+title,url,473,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩᤔ"),l1l11_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᤕ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠥࡸ࡮ࡺ࡬ࡦ࠿ࠪࠬ࠳࠰࠿ࠪࠩࠣ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࠤᤖ"),block,re.DOTALL)
		if items:
			for title,l1ll1ll_l1_ in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭ᤗ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧᤘ"))
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᤙ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨᤚ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᤛ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫᤜ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬᤝ"))
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᤞ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
	if l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠧ᤟") in html:
		if items: addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᤠ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᤡ"),l1l111_l1_ (u"ࠨࠩᤢ"),9999)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤣ"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํอึ๋฻ࠣิฬะࠠึๆฬࠫᤤ"),url,471)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᤥ"),url,l1l111_l1_ (u"ࠬ࠭ᤦ"),l1l111_l1_ (u"࠭ࠧᤧ"),l1l111_l1_ (u"ࠧࠨᤨ"),l1l111_l1_ (u"ࠨࠩᤩ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᤪ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡩ࡯ࡶࠡ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪࡪࡵࡩ࡫ࡃࠧᤫ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪ᤬"),block,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,True): return
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩ᤭"),l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩ᤮"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ᤯"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩᤰ"),l1l111_l1_ (u"ࠩࠪᤱ"),l1l111_l1_ (u"ࠪࠫᤲ"),l1l111_l1_ (u"ࠫࠬᤳ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪᤴ"))
	html = response.content
	l1llllllll_l1_ = []
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩ࡛ࡒࡍࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᤵ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ and l1ll1ll_l1_ not in l1llllllll_l1_:
			l1llllllll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨᤶ")
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᤷ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᤸ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠥࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃࠨ᤹"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l1llllllll_l1_:
			l1llllllll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᤺")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭᤻࠭")
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ᤼") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭᤽")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬ᤾"),l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪ᤿"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ᥀"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ᥁"),l1l111_l1_ (u"ࠬ࠭᥂"),l1l111_l1_ (u"࠭ࠧ᥃"),l1l111_l1_ (u"ࠧࠨ᥄"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭᥅"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᥆"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭᥇"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l1llllllll_l1_:
				l1llllllll_l1_.append(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᥈")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ᥉")
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ᥊") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭᥋")+l1ll1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᥌"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ᥍"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ᥎"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭᥏"),l1l111_l1_ (u"ࠬ࠱ࠧᥐ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧᥑ")+search
	l1lll11_l1_(url)
	return
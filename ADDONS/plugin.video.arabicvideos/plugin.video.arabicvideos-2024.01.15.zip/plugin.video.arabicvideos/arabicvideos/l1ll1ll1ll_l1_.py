# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡄࡎࡈࡅࡓࡋࡒࠨᨈ")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡆࡐࡓࡥࠧᨉ")
l1lll11l11_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠩࡷࡩࡲࡶࠧᨊ"))
l1ll1111ll_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬᨋ"))
l1lll111l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ᨌ"),l1l111_l1_ (u"࡚ࠬࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩᨍ"))
l1ll11lll1_l1_ = l1llll11l1_l1_
l1ll111l11_l1_ = l1l111_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡹࡹࡴࡶࡨࡱ࠴ࡻࡳࡢࡩࡨࡷࡹࡧࡴࡴࠩᨎ")
l1ll111l1l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡤࡳࡱࡳࡦࡴࡾࠧᨏ")
l1lll1111l_l1_ = l1l111_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶࠫᨐ")
l1lll11l1l_l1_ = l1l111_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰࡮ࡲ࡫࡬࡫ࡲࠨᨑ")
l1ll11l111_l1_ = l1l111_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࠭ᨒ")
l1ll11l11l_l1_ = l1l111_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡥࡳࡸࠧᨓ")
def l11l1ll_l1_(mode):
	if   mode==740: l1lll_l1_ = l1lllll1l1_l1_()
	elif mode==741: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l11_l1_,True,True)
	elif mode==742: l1lll_l1_ = l1llll1ll1_l1_(l1ll1111ll_l1_,True,True)
	elif mode==743: l1lll_l1_ = l1llll1ll1_l1_(l1lll111l1_l1_,False,True)
	elif mode==744: l1lll_l1_ = l1ll11l1ll_l1_(l1ll11lll1_l1_,True)
	elif mode==745: l1lll_l1_ = l1ll11111l_l1_(True)
	elif mode==750: l1lll_l1_ = l1ll1ll1l1_l1_()
	elif mode==751: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l11_l1_,False,True)
	elif mode==752: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l1l_l1_,False,True)
	elif mode==753: l1lll_l1_ = l1llll1ll1_l1_(l1lll1111l_l1_,False,True)
	elif mode==754: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l1l_l1_,False,True)
	elif mode==755: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l111_l1_,False,True)
	elif mode==756: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l11l_l1_,False,True)
	elif mode==757: l1lll_l1_ = l1ll1lll11_l1_(True)
	elif mode==758: l1lll_l1_ = l1ll1l1lll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lllll1l1_l1_():
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1lll11l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll1111ll_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll111l1_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll1l11ll_l1_(l1ll11lll1_l1_)
	l1lll1ll11_l1_ -= 36864
	l1ll11llll_l1_ -= 1
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨔ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᨕ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᨖ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᨗ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ᨘࠥ࠭")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᨙ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᨚ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᨛ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ᨜")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪ᨝")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠨࠫࠪ᨞")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_
	text = l1l111_l1_ (u"ࠩࠣࠬࠬ᨟")+l1lllll111_l1_(size)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨠ")+str(count)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨡ")
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨢ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯࠣห้าๅ๋฻ࠪᨣ")+text,l1l111_l1_ (u"ࠧࠨᨤ"),745)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᨥ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᨦ"),l1l111_l1_ (u"ࠪࠫᨧ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨨ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ฤใฬฬࠫᨩ")+l1ll111lll_l1_,l1l111_l1_ (u"࠭ࠧᨪ"),741)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨫ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึัࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠨᨬ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠩࠪᨭ"),742)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨮ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨᨯ")+l1ll1ll111_l1_,l1l111_l1_ (u"ࠬ࠭ᨰ"),743)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᨱ"),l1lllll_l1_+l1l111_l1_ (u"ࠧหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠩᨲ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠨࠩᨳ"),744)
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ᨴ"),l1l111_l1_ (u"ࠪࠫᨵ"))
	return
def l1ll1ll1l1_l1_():
	l1llll1l11_l1_ = True if l1l111_l1_ (u"ࠫ࠴࠭ᨶ") in l1ll11ll11_l1_ else False
	if not l1llll1l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭ᨷ"),l1l111_l1_ (u"࠭ࠧᨸ"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᨹ"),l1l111_l1_ (u"ࠨ฻่่๏ฯࠠห่฻๎ๆࠦวๅฮ๊หืࠦๅห๊ไีฮࠦแใู่ࠣศา็ำหࠣ๎ํ์ใิࠢ࠱࠲ࠥ๎ฬ่ษี็๊๊ࠥิ่๊ࠢࠥ์ฺ่ࠢํ์๋้ำࠨᨺ"))
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ᨻ"))
	if not l1ll11l1l1_l1_: l1ll1l1lll_l1_()
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1ll111l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll111l1l_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll1111l_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll111ll1_l1_(l1lll11l1l_l1_)
	l1lll1l1ll_l1_,l1ll1l1111_l1_ = l1ll111ll1_l1_(l1ll11l111_l1_)
	l1lll1l1l1_l1_,l1lll11ll1_l1_ = l1ll111ll1_l1_(l1ll11l11l_l1_)
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨼ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᨽ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᨾ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᨿ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᩀ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᩁ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᩂ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᩃ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᩄ")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᩅ")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᩆ")+str(l1ll11llll_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᩇ")
	l1ll1l1l11_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᩈ")+l1lllll111_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᩉ")+str(l1ll1l1111_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᩊ")
	l1ll1l1ll1_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᩋ")+l1lllll111_l1_(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᩌ")+str(l1lll11ll1_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᩍ")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_+l1lll1l1ll_l1_+l1lll1l1l1_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_+l1ll1l1111_l1_+l1lll11ll1_l1_
	text = l1l111_l1_ (u"ࠧࠡࠪࠪᩎ")+l1lllll111_l1_(size)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᩏ")+str(count)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᩐ")
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩑ"),l1lllll_l1_+l1l111_l1_ (u"ࠫส฿ืศรࠣีำ฻ษࠡไิหฦฯ้ࠠๅอหอฯࠧᩒ"),l1l111_l1_ (u"ࠬ࠭ᩓ"),758)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩔ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤฬ๊ฬๆ์฼ࠫᩕ")+text,l1l111_l1_ (u"ࠨࠩᩖ"),757)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩗ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᩘ"),l1l111_l1_ (u"ࠫࠬᩙ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩚ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ᩛ")+l1ll111lll_l1_,l1l111_l1_ (u"ࠧࠨᩜ"),751)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩝ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭ᩞ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠪࠫ᩟"),752)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬᩠ࠩ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬᩡ")+l1ll1ll111_l1_,l1l111_l1_ (u"࠭ࠧᩢ"),753)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩣ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࡨࡧࡵࠫᩤ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠩࠪᩥ"),754)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩦ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪࠫᩧ")+l1ll1l1l11_l1_,l1l111_l1_ (u"ࠬ࠭ᩨ"),755)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩩ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡥࡳࡸࠧᩪ")+l1ll1l1ll1_l1_,l1l111_l1_ (u"ࠨࠩᩫ"),756)
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ᩬ"),l1l111_l1_ (u"ࠪࠫᩭ"))
	return
def l1ll1l1lll_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࠬᩮ"),l1l111_l1_ (u"ࠬ࠭ᩯ"),l1l111_l1_ (u"࠭ࠧᩰ"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᩱ"),l1l111_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆࠣห้ะๆู์ไࠤ฾์ฯไࠢ࠱࠲ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬาอฬสࠢศ่๎ࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦไๅ็็ๅฬะ้ࠠษ็้ั๊ฯศฬࠣห้ะ๊ࠡี๋ๅࠥ๐ๅิฯ๊หࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤส฿ืศร๋ࠣีํࠠศๆิาฺฯࠠศๆล๊ࠥลࠡࠨᩲ"))
	if l1llll111l_l1_==-1: return
	if l1llll111l_l1_:
		l1llll11ll_l1_ = True
		import subprocess
		try: subprocess.Popen(l1l111_l1_ (u"ࠩࡶࡹࠬᩳ"))
		except: l1llll11ll_l1_ = False
		if l1llll11ll_l1_:
			l1ll1llll1_l1_ = l1ll111l11_l1_+l1l111_l1_ (u"ࠪࠤࠬᩴ")+l1ll111l1l_l1_+l1l111_l1_ (u"ࠫࠥ࠭᩵")+l1lll1111l_l1_+l1l111_l1_ (u"ࠬࠦࠧ᩶")+l1lll11l1l_l1_+l1l111_l1_ (u"࠭ࠠࠨ᩷")+l1ll11l111_l1_+l1l111_l1_ (u"ࠧࠡࠩ᩸")+l1ll11l11l_l1_
			proc = subprocess.Popen(l1l111_l1_ (u"ࠨࡵࡸࠤ࠲ࡩࠠࠣࡥ࡫ࡱࡴࡪࠠ࠮ࡔࠣ࠴࠼࠽࠷ࠡࠩ᩹")+l1ll1llll1_l1_+l1l111_l1_ (u"ࠩࠥࠫ᩺"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᩻"),l1l111_l1_ (u"ࠫࠬ᩼"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᩽"),l1l111_l1_ (u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩ᩾"))
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶ᩿ࠫ"),l1l111_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫ᪀"))
			xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭᪁"))
		else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᪂"),l1l111_l1_ (u"ࠫࠬ᪃"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪄"),l1l111_l1_ (u"ู࠭ๆๆํอࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอࠥะอหษฯࠤอืๆศ็ฯࠤࠥࡸ࡯ࡰࡶࠣࠤศ๎ࠠࠡࡵࡸࡴࡪࡸࡵࡴࡧࡵࠤࠥษ่ࠡࠢࡶࡹ่ࠥࠦอ้สึ่ࠦไศࠢํ์ัีࠠโ์๊ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦร้ࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ั࠭᪅"))
	return
def l1lllll111_l1_(size):
	for x in [l1l111_l1_ (u"ࠧࡃࠩ᪆"),l1l111_l1_ (u"ࠨࡍࡅࠫ᪇"),l1l111_l1_ (u"ࠩࡐࡆࠬ᪈"),l1l111_l1_ (u"ࠪࡋࡇ࠭᪉"),l1l111_l1_ (u"࡙ࠫࡈࠧ᪊")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l111_l1_ (u"ࠧࠫ࠳࠯࠳ࡩࠤࠪࡹࠢ᪋")%(size,x)
	return text
def l1ll111ll1_l1_(l1llll1111_l1_=l1l111_l1_ (u"࠭࠮ࠨ᪌")):
	global l1lll11111_l1_,l1lll1lll1_l1_
	l1lll11111_l1_,l1lll1lll1_l1_ = 0,0
	def l1lll111ll_l1_(l1llll1111_l1_):
		global l1lll11111_l1_,l1lll1lll1_l1_
		if os.path.exists(l1llll1111_l1_):
			if 0 and l1l111_l1_ (u"ࠧࡴࡥࡤࡲࡩ࡯ࡲࠨ᪍") in dir(os):
				for l1ll1111l1_l1_ in os.scandir(l1llll1111_l1_):
					if l1ll1111l1_l1_.l1lll1llll_l1_(follow_symlinks=False):
						l1lll111ll_l1_(l1ll1111l1_l1_.path)
					elif l1ll1111l1_l1_.l1ll1l1l1l_l1_(follow_symlinks=False):
						l1lll11111_l1_ += l1ll1111l1_l1_.stat().st_size
						l1lll1lll1_l1_ += 1
			else:
				for l1ll1111l1_l1_ in os.listdir(l1llll1111_l1_):
					l1ll111111_l1_ = os.path.abspath(os.path.join(l1llll1111_l1_,l1ll1111l1_l1_))
					if os.path.isdir(l1ll111111_l1_):
						l1lll111ll_l1_(l1ll111111_l1_)
					elif os.path.isfile(l1ll111111_l1_):
						size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
						l1lll11111_l1_ += size
						l1lll1lll1_l1_ += count
		return
	try: l1lll111ll_l1_(l1llll1111_l1_)
	except: pass
	return l1lll11111_l1_,l1lll1lll1_l1_
def l1lll1ll1l_l1_(l1ll1lllll_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࠩ᪎"),l1l111_l1_ (u"ࠩࠪ᪏"),l1l111_l1_ (u"ࠪࠫ᪐"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪑"),l1ll1lllll_l1_+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ᪒")+l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᪓"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1ll1lllll_l1_):
		try: os.remove(l1ll1lllll_l1_)
		except Exception as err:
			if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ᪔"),l1l111_l1_ (u"ࠨࠩ᪕"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪖"),str(err))
			error = True
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᪗"),l1l111_l1_ (u"ࠫࠬ᪘"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪙"),l1l111_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧ᪚"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ᪛"),l1l111_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫ᪜"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭᪝"))
	return
def l1ll11111l_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࠫ᪞"),l1l111_l1_ (u"ࠫࠬ᪟"),l1l111_l1_ (u"ࠬ࠭᪠"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪡"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠧ᪢")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ᪣")+l1l111_l1_ (u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨ᪤")+l1l111_l1_ (u"ࠪࡠࡳ࠭᪥")+l1l111_l1_ (u"ࠫฤࠧࠡࠨ᪦")+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᪧ"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1lll11l11_l1_,True,False)
	l1llll1ll1_l1_(l1ll1111ll_l1_,True,False)
	l1llll1ll1_l1_(l1lll111l1_l1_,False,False)
	l1ll11l1ll_l1_(l1ll11lll1_l1_,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ᪨"),l1l111_l1_ (u"ࠧࠨ᪩"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪪"),l1l111_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ᪫"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᪬"),l1l111_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᪭"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ᪮"))
	return
def l1ll1lll11_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࠧ᪯"),l1l111_l1_ (u"ࠧࠨ᪰"),l1l111_l1_ (u"ࠨࠩ᪱"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪲"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠩ᪳")+l1l111_l1_ (u"ࠫࡡࡴࠧ᪴")+l1l111_l1_ (u"ࠬࡻࡳࡢࡩࡨࡷࡹࡧࡴࡴࠢ࠱࠲ࠥࡪࡲࡰࡲࡥࡳࡽࠦ࠮࠯ࠢࡷࡳࡲࡨࡳࡵࡱࡱࡩࡸࠦ࠮࠯ࠢ࡯ࡳ࡬࡭ࡥࡳࠢ࠱࠲ࠥࡲ࡯ࡨࠢ࠱࠲ࠥࡧ࡮ࡳ᪵ࠩ")+l1l111_l1_ (u"࠭࡜࡯᪶ࠩ")+l1l111_l1_ (u"ࠧࡀࠣࠤ᪷ࠫ")+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟᪸ࠪ"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1ll111l11_l1_,False,False)
	l1llll1ll1_l1_(l1ll111l1l_l1_,False,False)
	l1llll1ll1_l1_(l1lll1111l_l1_,False,False)
	l1llll1ll1_l1_(l1lll11l1l_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l111_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l11l_l1_,False,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"᪹ࠩࠪ"),l1l111_l1_ (u"᪺ࠪࠫ"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪻"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭᪼"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵ᪽ࠪ"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ᪾"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ᪿࠬ"))
	return
def l1ll11l1ll_l1_(l1ll1lll1l_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ᫀࠩࠪ"),l1l111_l1_ (u"ࠪࠫ᫁"),l1l111_l1_ (u"ࠫࠬ᫂"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᫃"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤ᫄ࠫ")+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᫅"))
		if l1llll111l_l1_!=1: return
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡰࡢࡶ࡫࠿ࠬ᫆"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡴ࡫ࡽࡩࡸࡁࠧ᫇"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡶࡨࡼࡹࡻࡲࡦ࠽ࠪ᫈"))
	conn.commit()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬ᫉"))
	conn.close()
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"᫊ࠬ࠭"),l1l111_l1_ (u"࠭ࠧ᫋"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᫌ"),l1l111_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩᫍ"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ᫎ"),l1l111_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭᫏"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ᫐"))
	return
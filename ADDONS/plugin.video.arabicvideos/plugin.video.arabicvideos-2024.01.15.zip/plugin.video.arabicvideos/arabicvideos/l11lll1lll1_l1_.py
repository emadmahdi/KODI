# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ富")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢ࡝ࡖ࡚࡟ࠨ寍")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ寎"),l1l111_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ寏"),l1l111_l1_ (u"ࠬะำอ์็ࠫ寐"),l1l111_l1_ (u"࠭สิฮํ่ࠥอไะะ๋่ࠬ寑"),l1l111_l1_ (u"ฺࠧำูࠤฬ๊ๅำ์าࠫ寒")]
def l11l1ll_l1_(mode,url,text):
	if   mode==660: l1lll_l1_ = l1l1l11_l1_()
	elif mode==661: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==662: l1lll_l1_ = PLAY(url)
	elif mode==663: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==664: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==669: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ寓"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ寔"),l1l111_l1_ (u"ࠪࠫ寕"),l1l111_l1_ (u"ࠫࠬ寖"),l1l111_l1_ (u"ࠬ࠭寗"),l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ寘"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ寙"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ寚"),l1l111_l1_ (u"ࠩࠪ寛"),669,l1l111_l1_ (u"ࠪࠫ寜"),l1l111_l1_ (u"ࠫࠬ寝"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ寞"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ察"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ寠"),l1l111_l1_ (u"ࠨࠩ寡"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ寢"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ寣")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ寤"),l111l1_l1_,661,l1l111_l1_ (u"ࠬ࠭寥"),l1l111_l1_ (u"࠭ࠧ實"),l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭寧"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭寨"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ審"),l1l111_l1_ (u"ࠪࠫ寪"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ寫"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ寬"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"࠭ࠧ寭"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ寮"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠨ࠾ࡥࡂࠬ寯"),l1l111_l1_ (u"ࠩࠪ寰")).replace(l1l111_l1_ (u"ࠪࡀ࠴ࡨ࠾ࠨ寱"),l1l111_l1_ (u"ࠫࠬ寲")).replace(l1l111_l1_ (u"ࠬࡂࡢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡶࡪࡺࠢ࠿ࠩ寳"),l1l111_l1_ (u"࠭ࠧ寴")).replace(l1l111_l1_ (u"ࠧ࠽ࡤࡁࠫ寵"),l1l111_l1_ (u"ࠨࠩ寶")).strip(l1l111_l1_ (u"ࠩࠣࠫ寷"))
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ寸"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭对")+l1lllll_l1_+title,l1ll1ll_l1_,664)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ寺"),url,l1l111_l1_ (u"࠭ࠧ寻"),l1l111_l1_ (u"ࠧࠨ导"),l1l111_l1_ (u"ࠨࠩ寽"),l1l111_l1_ (u"ࠩࠪ対"),l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ寿"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭尀"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭封"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ専"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ尃"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩ射"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ尅"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ将"),l1l111_l1_ (u"ࠫࠬ將"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ專"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩ尉")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ尊"),l1lllll_l1_+title,l1ll1ll_l1_,661)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ尋"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ尌"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ對"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭導"),l1l111_l1_ (u"ࠬ࠭小"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭尐"),l1lllll_l1_+title,l1ll1ll_l1_,661)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨ少")):
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭尒"):
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࠫ尓"),1)
		data = l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ尔")+search
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ尕"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ尖")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ尗"),url,data,headers,l1l111_l1_ (u"ࠧࠨ尘"),l1l111_l1_ (u"ࠨࠩ尙"),l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ尚"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ尛"),url,l1l111_l1_ (u"ࠫࠬ尜"),l1l111_l1_ (u"ࠬ࠭尝"),l1l111_l1_ (u"࠭ࠧ尞"),l1l111_l1_ (u"ࠧࠨ尟"),l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ尠"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠩࠪ尡"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ尢"))
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ尣"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ尤"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"࠭ࠧ尥"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ尦"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ尧"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ尨"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ尩"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ尪"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ尫"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ尬"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ尭"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ尮"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠩࠪ尯"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ尰"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ就"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ尲"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ尳"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭尴"),l1l111_l1_ (u"ࠨๅ็๎อ࠭尵"),l1l111_l1_ (u"ࠩส฽้อๆࠨ尶"),l1l111_l1_ (u"๋ࠪิอแࠨ尷"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ尸"),l1l111_l1_ (u"ࠬ฿ัืࠩ尹"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭尺"),l1l111_l1_ (u"ࠧศๆห์๊࠭尻"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨ尼")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠩส์๋ࠦไศ์้ࠤࠬ尽"),l1l111_l1_ (u"ࠪࠫ尾")).replace(l1l111_l1_ (u"ࠫฬ๎ๆๅษํ๊ࠥ࠭尿"),l1l111_l1_ (u"ࠬ࠭局")).replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ屁"),l1l111_l1_ (u"ࠧࠨ层"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ屃"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ屄"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ居"):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ屆"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ屇") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屈"),l1lllll_l1_+title,l1ll1ll_l1_,663,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ屉"),l1lllll_l1_+title,l1ll1ll_l1_,663,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ届"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ屋"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ屌"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭屍")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ屎"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屏"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭屐")+title,l1ll1ll_l1_,661)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ屑"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭屒"),url,l1l111_l1_ (u"ࠪࠫ屓"),l1l111_l1_ (u"ࠫࠬ屔"),l1l111_l1_ (u"ࠬ࠭展"),l1l111_l1_ (u"࠭ࠧ屖"),l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭屗"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ屘"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ屙"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ屚")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ屛"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧ屜"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屝"),l1lllll_l1_+title,url,663,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ属"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩ屟")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ屠"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ屡"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭屢")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠴࠯ࠨ屣"))
			title = title.replace(l1l111_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫ層"),l1l111_l1_ (u"ࠧࠡࠩ履"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ屦"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠰ࡳ࡬ࡵ࠭屧"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭屨"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ屩"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭屪"),l1l111_l1_ (u"࠭ࠧ屫"),l1l111_l1_ (u"ࠧࠨ屬"),l1l111_l1_ (u"ࠨࠩ屭"),l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ屮"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡑ࡮ࡤࡽࡪࡸࡨࡰ࡮ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ屯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ屰"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭山"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ屲"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠨࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ屳"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ屴")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ屵"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ屶"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ屷"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭屸"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ屹"),l1l111_l1_ (u"ࠧࠬࠩ屺"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ屻")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ屼"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ੫") : l1l111_l1_ (u"ࠨࠩ੬") }
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ੭")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩ੮")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
proxy = l1l111_l1_ (u"ࠫࠬ੯")
l11lll_l1_ = [l1l111_l1_ (u"ࠬษไฺษหࠫੰ"),l1l111_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧੱ"),l1l111_l1_ (u"ࠧศๆๅีฬ์ࠠศๆๆี๏๋ࠧੲ"),l1l111_l1_ (u"ࠨษ็็ฯฮ้ࠠࠢส่ฬฮอศอࠪੳ"),l1l111_l1_ (u"ࠩสฺ่๎ั๊ࠡࠣห้ิไโ์สฮࠬੴ"),l1l111_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅษำห฾๐ษࠨੵ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==240: l1lll_l1_ = l1l1l11_l1_()
	elif mode==241: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==242: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==243: l1lll_l1_ = PLAY(url)
	elif mode==244: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ੶")+text)
	elif mode==245: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ੷")+text)
	elif mode==246: l1lll_l1_ = l11llll1_l1_(url)
	elif mode==247: l1lll_l1_ = l11l11ll_l1_(url)
	elif mode==248: l1lll_l1_ = l111lll1_l1_()
	elif mode==249: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l111lll1_l1_():
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ੸"),l1l111_l1_ (u"ࠧࠨ੹"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ੺"),l1l111_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦࠢฤๅ๋ห๊ࠦวๅฮา๎ิࠨࠠโ์ࠣฬ฾฼ࠠศๆฦั๏อๆࠡใํ๋ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฻ีࠠศๆหีฬ๋ฬࠡ࠰ࠣ์์ึวࠡ์ึฬอࠦๅีๅ็อࠥ็๊ࠡฬื฾๏๊ࠠศๆไ๎ิ๐่่ษอࠤ࠳ࠦ็ั้ࠣห้๋ิไๆฬࠤุฮศ่ษ้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏่่ࠦ์ࠣฮ฽ํั๊ࠡอาฯ็๊ࠡสุ์ึฯฺࠠึ๋หห๐ษࠨ੻"))
	return
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ੼"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ੽"),headers,l1l111_l1_ (u"ࠬ࠭੾"),l1l111_l1_ (u"࠭ࠧ੿"),l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ઀"))
	html = response.content
	l11l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡲࡱࡪ࠳ࡳࡪࡶࡨ࠱ࡧࡺ࡮࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬઁ"),html,re.DOTALL)
	if l11l1111_l1_: l11l1111_l1_ = l11l1111_l1_[0]
	else: l11l1111_l1_ = l111l1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ં"),l11l1111_l1_,l1l111_l1_ (u"ࠪࠫઃ"),headers,l1l111_l1_ (u"ࠫࠬ઄"),l1l111_l1_ (u"ࠬ࠭અ"),l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧઆ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧઇ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨઈ"),l1l111_l1_ (u"ࠩࠪઉ"),249,l1l111_l1_ (u"ࠪࠫઊ"),l1l111_l1_ (u"ࠫࠬઋ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩઌ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઍ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ઎"),l111l1_l1_,246)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨએ"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬઐ"),l111l1_l1_,247)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨઑ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭઒"),l1l111_l1_ (u"ࠬ࠭ઓ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઔ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩક")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩખ"),l11l1111_l1_,241,l1l111_l1_ (u"ࠩࠪગ"),l1l111_l1_ (u"ࠪࠫઘ"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ઙ"))
	l111l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡸࡥࡤࡧࡱࡸࡱࡿ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫચ"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1l1_l1_[0]
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭છ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩજ")+l1lllll_l1_+l1l111_l1_ (u"ࠨลู๎ๆࠦอะ์ฮหࠬઝ"),l1ll1ll_l1_,241)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧઞ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬટ"),l1l111_l1_ (u"ࠫࠬઠ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡢ࠮࠶ࠣࡨ࠲࡬࡬ࡦࡺࠣࡥࡱ࡯ࡧ࡯࠯࡬ࡸࡪࡳࡳ࠮ࡥࡨࡲࡹ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥࡧࡵ࠱ࡱ࡯࡮࡬ࠢࡷࡩࡽࡺ࠭ࡸࡪ࡬ࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬડ"),html,re.DOTALL)
	for l1ll1ll_l1_,name,block in l11llll_l1_:
		if name in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ઢ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩણ")+l1lllll_l1_+name,l1ll1ll_l1_,241)
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧત"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			title = name+l1l111_l1_ (u"ࠩࠣࠫથ")+title
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪદ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ધ")+l1lllll_l1_+title,l1ll1ll_l1_,241)
	return
def l11llll1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠬ࠭ન")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ઩"),headers,l1l111_l1_ (u"ࠧࠨપ"),l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩફ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩબ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪભ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"๋ࠫࠥี็ใฬࠫમ")
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬય"),l1lllll_l1_+title,l1ll1ll_l1_,245)
		if l1l11l11_l1_==l1l111_l1_ (u"࠭ࠧર"): addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ઱"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪલ"),l1l111_l1_ (u"ࠩࠪળ"),9999)
	return html
def l11l11ll_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠪࠫ઴")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬવ"),headers,l1l111_l1_ (u"ࠬ࠭શ"),l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧષ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿ࡲࡦࡼࠧસ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨહ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"้ࠩࠣๆ๊สาหࠪ઺")
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ઻"),l1lllll_l1_+title,l1ll1ll_l1_,244)
		if l1l11l11_l1_==l1l111_l1_ (u"઼ࠫࠬ"): addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪઽ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨા"),l1l111_l1_ (u"ࠧࠨિ"),9999)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠨࠩી")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪુ"),headers,True,l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ૂ"))
	if type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ૃ"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡷࡪࡲࡨࡶ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡷࡪࡲࡨࡶ࠲ࡨࡵࡵࡶࡲࡲ࠲ࡶࡲࡦࡸࠪૄ"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩૅ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ૆"),block,re.DOTALL)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺ࠭ࡸࡪ࡬ࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧે"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫૈ") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡸࡵ࠲ࠫૉ") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ૊"),l1lllll_l1_+title,l1ll1ll_l1_,242,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧો") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬૌ"),l1lllll_l1_+title,l1ll1ll_l1_,243,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠧ࠰ࡩࡤࡱࡪࡹ࠯ࠨ્") not in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ૎"),l1lllll_l1_+title,l1ll1ll_l1_,243,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ૏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬૐ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠫࠫࡲࡳࡢࡳࡸࡳࡀ࠭૑"): title = l1l111_l1_ (u"ูࠬวษไฬࠫ૒")
			if title==l1l111_l1_ (u"࠭ࠦࡳࡵࡤࡵࡺࡵ࠻ࠨ૓"): title = l1l111_l1_ (u"ࠧๅษะๆฮ࠭૔")
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ૕"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ૖")+title,l1ll1ll_l1_,241)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ૗"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ૘"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ૙"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ૚"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ૛")+l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ૜"),headers,True,l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ૝"))
	if l1l111_l1_ (u"ࠪ࠱ࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠾ࠨ૞") not in html:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫ૟"))
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫૠ"),l1lllll_l1_+l1l111_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬૡ"),url,243,l1ll1l_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺ࠭࠵ࠩૢ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		l1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧૣ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in l1l1l1l1_l1_:
			title = title.replace(l1l111_l1_ (u"ࠩࠣࠤࠬ૤"),l1l111_l1_ (u"ࠪࠤࠬ૥"))
			if l1l111_l1_ (u"ࠫฬ๊อๅไสฮࠬ૦") in title or l1l111_l1_ (u"๋่ࠬศี่ࠤฬิั๊ࠩ૧") in title: continue
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ૨") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૩"),l1lllll_l1_+title,l1ll1ll_l1_,242,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ૪"),l1lllll_l1_+title,l1ll1ll_l1_,243,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ૫"),headers,True,l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ૬"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧ࠰ࡨࡦࡴࡧࡦࡴ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭૭"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l111llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ૮"),html,re.DOTALL)
	l1llll_l1_,l1l1lll1_l1_,l1lll1l1_l1_,l11l11l1_l1_ = [],[],[],[]
	if l111llll_l1_:
		l111lll_l1_ = l1l111_l1_ (u"࠭࡭ࡱ࠶ࠪ૯")
		for l11l111l_l1_,l111l1ll_l1_ in l111llll_l1_:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠥࡷࡵࡢ࡮࡬ࡸࡾࠨࠠࡪࡦࡀࠦࠬ૰")+l11l111l_l1_+l1l111_l1_ (u"ࠨࠤ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠳ࡢࡳࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ૱"),html,re.DOTALL)
			block = l11llll_l1_[0]
			l1lll1l1_l1_.append(block)
			l11l11l1_l1_.append(l111l1ll_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡴࡹࡦࡲࡩࡵ࡫ࡨࡷ࠭࠴ࠪࡀࠫ࠿࡬࠸࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ૲"),html,re.DOTALL)
		if not l11llll_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ૳"),l1l111_l1_ (u"ࠫࠬ૴"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ૵"),l1l111_l1_ (u"࠭ไศࠢํ์ัีࠠๆๆไࠤๆ๐ฯ๋๊ࠣๅ๏ࠦ็ัษࠣห้ืวษูࠪ૶"))
			return
		else:
			block,filename = l11llll_l1_[0]
			l111ll1l_l1_ = [l1l111_l1_ (u"ࠧࡻ࡫ࡳࠫ૷"),l1l111_l1_ (u"ࠨࡴࡤࡶࠬ૸"),l1l111_l1_ (u"ࠩࡷࡼࡹ࠭ૹ"),l1l111_l1_ (u"ࠪࡴࡩ࡬ࠧૺ"),l1l111_l1_ (u"ࠫ࡭ࡺ࡭ࠨૻ"),l1l111_l1_ (u"ࠬࡺࡡࡳࠩૼ"),l1l111_l1_ (u"࠭ࡩࡴࡱࠪ૽"),l1l111_l1_ (u"ࠧࡩࡶࡰࡰࠬ૾")]
			l111lll_l1_ = filename.rsplit(l1l111_l1_ (u"ࠨ࠰ࠪ૿"),1)[1].strip(l1l111_l1_ (u"ࠩࠣࠫ଀"))
			if l111lll_l1_ in l111ll1l_l1_:
				l1111l1_l1_(l1l111_l1_ (u"ࠪࠫଁ"),l1l111_l1_ (u"ࠫࠬଂ"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨଃ"),l1l111_l1_ (u"࠭วๅ็็ๅ๊๊ࠥิࠢไ๎ิ๐่๊ࠡ็หࠥ฻่หࠩ଄"))
				return
		l1lll1l1_l1_.append(block)
		l11l11l1_l1_.append(l1l111_l1_ (u"ࠧࠨଅ"))
	for i in range(len(l1lll1l1_l1_)):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡧࡴࡴ࠭ࠩ࠰࠭ࡃ࠮ࠨࠧଆ"),l1lll1l1_l1_[i],re.DOTALL)
		for l1ll1ll_l1_,l111ll11_l1_ in l1ll_l1_:
			if l1l111_l1_ (u"ࠩࡷࡳࡷࡸࡥ࡯ࡶࠪଇ") in l111ll11_l1_: continue
			elif l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬଈ") in l111ll11_l1_: type = l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ଉ")
			elif l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࠪଊ") in l111ll11_l1_: type = l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬଋ")
			else: type = l1l111_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨଌ")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࠫ଍")+type+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ଎")+l11l11l1_l1_[i]+l1l111_l1_ (u"ࠪࡣࡤࡧ࡫ࡸࡣࡰࠫଏ")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪଐ"),url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳ࠭଑"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ଒"),l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬଓ"),l1l111_l1_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨଔ")]
	if l1l111_l1_ (u"ࠩࡂࠫକ") in url: url = url.split(l1l111_l1_ (u"ࠪࡃࠬଖ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨଗ"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭ଘ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧଙ"),l1l111_l1_ (u"ࠧࠨଚ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬଛ"))
	if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ଜ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬଝ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭ଞ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧଟ")+category+l1l111_l1_ (u"࠭࠽࠱ࠩଠ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩଡ")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫଢ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫଣ"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧତ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭ଥ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩଦ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠿ࠨଧ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨନ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ଩"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪପ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡥࡱࡲࠧଫ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬବ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬࡅࠧଭ")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ମ"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠩଯ"),l1lllll1_l1_,241,l1l111_l1_ (u"ࠨࠩର"),l1l111_l1_ (u"ࠩ࠴ࠫ଱"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪଲ"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫଳ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ଴"),l1lllll1_l1_,241,l1l111_l1_ (u"࠭ࠧଵ"),l1l111_l1_ (u"ࠧ࠲ࠩଶ"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ଷ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫସ"),l1l111_l1_ (u"ࠪࠫହ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ଺"),headers,True,l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ଻"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡧࡱࡵࡱࠥ࡯ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ଼࠭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴ࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭ଽ"),block,re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡲࡴࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧା"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠩࡀࠫି") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧୀ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫୁ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬୂ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭ୃ"),l1lllll1_l1_,241,l1l111_l1_ (u"ࠧࠨୄ"),l1l111_l1_ (u"ࠨ࠳ࠪ୅"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୆"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪେ"),l1lllll1_l1_,245,l1l111_l1_ (u"ࠫࠬୈ"),l1l111_l1_ (u"ࠬ࠭୉"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ୊"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩୋ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫୌ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"୍ࠩࠩࠫ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭୎")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ୏")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୐"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠡࠩ୑")+name,l1lllll1_l1_,244,l1l111_l1_ (u"ࠧࠨ୒"),l1l111_l1_ (u"ࠨࠩ୓"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ୔") not in value: value = option
			else: value = re.findall(l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫ୕"),value,re.DOTALL)[0]
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ୖ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧୗ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ୘")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ୙")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ୚")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠥ࠭୛")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠪ࠴ࠬଡ଼")]
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠠࠨଢ଼")+name
			if type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭୞"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ୟ"),l1lllll_l1_+title,url,244,l1l111_l1_ (u"ࠧࠨୠ"),l1l111_l1_ (u"ࠨࠩୡ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ୢ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬୣ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ୤"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠬࡅࠧ୥")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭୦"),l1lllll_l1_+title,l1llllll_l1_,241,l1l111_l1_ (u"ࠧࠨ୧"),l1l111_l1_ (u"ࠨ࠳ࠪ୨"))
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୩"),l1lllll_l1_+title,url,245,l1l111_l1_ (u"ࠪࠫ୪"),l1l111_l1_ (u"ࠫࠬ୫"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ୬"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ୭") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ୮"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ୯"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ୰")
	l1l11lll_l1_ = [l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࠫୱ"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭୲"),l1l111_l1_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬ୳"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ୴"),l1l111_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ୵"),l1l111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ୶"),l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ୷")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ୸")
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭୹") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ୺"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪ୻")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ୼") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ୽"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ୾")+key+l1l111_l1_ (u"ࠪࡁࠬ୿")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ஀"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ஁")+key+l1l111_l1_ (u"࠭࠽ࠨஂ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫஃ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ஄"))
	return l1l1l111_l1_
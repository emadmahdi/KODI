# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࠬ⮣")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡉࡏࡗࡤ࠭⮤")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll1l1lll_l1_(text)
	elif mode==542: l1lll_l1_ = l1lll11l1l1_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮥"),l1l111_l1_ (u"ࠩหัะࠦฬะ์าࠫ⮦"),l1l111_l1_ (u"ࠪࠫ⮧"),549)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⮨"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁ้ࠥไๆษอࠤ๊ิา็หࠣࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⮩"),l1l111_l1_ (u"࠭ࠧ⮪"),9999)
	l1lll1l11ll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⮫"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮬"))
	if l1lll1l11ll_l1_:
		l1lll1l11ll_l1_ = l1lll1l11ll_l1_[l1l111_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ⮭")]
		for search in reversed(l1lll1l11ll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮮"),search,l1l111_l1_ (u"ࠫࠬ⮯"),549,l1l111_l1_ (u"ࠬ࠭⮰"),l1l111_l1_ (u"࠭ࠧ⮱"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111ll11l_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"ࠧࠨ⮲"))
	l1lll1111l1_l1_(l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⮳"),l1l111_l1_ (u"ࠩ฼้้ࠦศฮอࠣะ๊อู๋ࠢ࠰ࠤࠬ⮴")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡷ࡮ࡺࡥࡴࠩ⮵"),542,l1l111_l1_ (u"ࠫࠬ⮶"),l1l111_l1_ (u"ࠬ࠭⮷"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⮸"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⮹"),l1l111_l1_ (u"ࠨࠩ⮺"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮻"),l1l111_l1_ (u"๊ࠪฯอฦอࠢส่อำหࠡ็ไู้ฯࠠ࠮ࠢࠪ⮼")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⮽"),542,l1l111_l1_ (u"ࠬ࠭⮾"),l1l111_l1_ (u"࠭ࠧ⮿"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯀"),l1l111_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅใี่อࠥ࠳ࠠࠨ⯁")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⯂"),542,l1l111_l1_ (u"ࠪࠫ⯃"),l1l111_l1_ (u"ࠫࠬ⯄"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯅"),l1l111_l1_ (u"࠭ศฮอ้๋ࠣ็ัะࠢ࠰ࠤࠬ⯆")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨ⯇"),541,l1l111_l1_ (u"ࠨࠩ⯈"),l1l111_l1_ (u"ࠩࠪ⯉"),l1111ll11l_l1_)
	return
def l1lll1111l1_l1_(l1lll1lll1l_l1_):
	l1lll1lllll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯊"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⯋"),l1lll1lll1l_l1_)
	l1lll1llll1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ⯌"),l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⯍"),l1lllll_l1_+l1lll1lll1l_l1_)
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⯎"),l1lll1lll1l_l1_)
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⯏"),l1lllll_l1_+l1lll1lll1l_l1_)
	old_value = l1lll1lllll_l1_+l1lll1llll1_l1_
	if old_value: l1lll1lll1l_l1_ = l1lllll_l1_+l1lll1lll1l_l1_
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⯐"),l1lll1lll1l_l1_,old_value,l1lll11lll1_l1_)
	return
def l1lll111ll1_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࠫ⯑"),l1l111_l1_ (u"ࠫࠬ⯒"),l1l111_l1_ (u"ࠬ࠭⯓"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⯔"),l1l111_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠤࠫ⯕"))
	if l1llll111l_l1_!=1: return
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⯖"))
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡑࡓࡉࡓࡋࡄࠨ⯗"))
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⯘"))
	l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ⯙"),l1l111_l1_ (u"ࠬ࠭⯚"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⯛"),l1l111_l1_ (u"ࠧห็ࠣฬ๋าวฮ่ࠢืาࠦฬๆ์฼ࠤ่๊ๅศฬࠣห้ฮอฬࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ⯜"))
	return
def l1lll11l1l1_l1_(l1lll111lll_l1_,action,l1lll11ll1l_l1_=l1l111_l1_ (u"ࠨࠩ⯝")):
	l1lll11llll_l1_,l1lll1l1111_l1_,l1lll1l1l11_l1_,l1ll1lll1ll_l1_,l1ll1lllll1_l1_,l1ll1llll1l_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⯞"):
		if action==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⯟"): l1lll1l1l11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⯠"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⯡"),l1lllll_l1_+l1lll111lll_l1_)
		elif action==l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬ⯢"): l1lll1l1l11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⯣"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⯤"),l1lll111lll_l1_)
		elif action==l1l111_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⯥"): l1lll1l1l11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯦"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪ⯧"),(l1lll11ll1l_l1_,l1lll111lll_l1_))
	if not l1lll1l1l11_l1_:
		l1lll1ll111_l1_ = l1l111_l1_ (u"ࠬํะศࠢส่อำหࠡ฼ํี๋่ࠥอ๊าࠤๆ๐ࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࡠࡳ࠭⯨")
		l1lll1ll11l_l1_ = l1l111_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆล๊ࠥอไษฯฮࠤๆ๐ࠠอ็ํ฽ࠥอไๆ๊สๆ฾ูࠦ็ࠢ࡟ࡲࠥࠨ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢࠪ⯩")+l1lll111lll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥࠤࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไษฯฮࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠩ⯪")
		if action==l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⯫"): message = l1lll1ll11l_l1_
		else: message = l1lll1ll111_l1_+l1lll1ll11l_l1_
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ⯬"),l1l111_l1_ (u"ࠪࠫ⯭"),l1l111_l1_ (u"ࠫࠬ⯮"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⯯"),message)
		if l1llll111l_l1_!=1: return
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⯰"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡪࡧࡲࡤࡪࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫ⯱")+l1lll111lll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ⯲"))
		l1llll11l11_l1_ = 1
		for l1lll11ll1l_l1_ in l1lll1l11l1_l1_:
			l1ll1lll1ll_l1_[l1lll11ll1l_l1_] = []
			options = l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⯳")
			if l1l111_l1_ (u"ࠪ࠱ࠬ⯴") in l1lll11ll1l_l1_: options = options+l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ⯵")+l1lll11ll1l_l1_+l1l111_l1_ (u"ࠬࡥࠧ⯶")
			l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
			if l1llll11l11_l1_:
				time.sleep(0.5)
				threads[l1lll11ll1l_l1_] = threading.Thread(target=l1lll11ll11_l1_,args=(l1lll111lll_l1_+options,))
				threads[l1lll11ll1l_l1_].start()
			else: l1lll11ll11_l1_(l1lll111lll_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1lll11ll1l_l1_),l1l111_l1_ (u"࠭ࠧ⯷"),time=1000)
		if l1llll11l11_l1_:
			time.sleep(2)
			for l1lll11ll1l_l1_ in l1lll1l11l1_l1_:
				threads[l1lll11ll1l_l1_].join(10)
			time.sleep(2)
		for l1lll11ll1l_l1_ in l1lll1l11l1_l1_:
			l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
			for l1lll11l11l_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
				if l1llll111ll_l1_ in name:
					if l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࠭⯸") in l1lll11ll1l_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⯹")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯺")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⯻")]: continue
						if l1l111_l1_ (u"ฺࠫ็อสࠩ⯼") not in name:
							if   type==l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⯽"): l1lll11ll1l_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⯾")
							elif type==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⯿"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭Ⰰ")
							elif type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰁ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨⰂ")
						else:
							if   l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩⰃ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨⰄ")
							elif l1l111_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭Ⰵ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬⰆ")
							elif l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨⰇ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧⰈ")
					elif l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࠨⰉ") in l1lll11ll1l_l1_ and 729>=mode>=710:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭Ⰺ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩⰋ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪⰌ")]: continue
						if l1l111_l1_ (u"ࠧึใะอࠬⰍ") not in name:
							if   type==l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭Ⰾ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫⰏ")
							elif type==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩⰐ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨⰑ")
							elif type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰒ"): l1lll11ll1l_l1_ = l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪⰓ")
						else:
							if   l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬⰔ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪⰕ")
							elif l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩⰖ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰗ")
							elif l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫⰘ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩⰙ")
					elif l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࠨⰚ") in l1lll11ll1l_l1_ and 149>=mode>=140:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪⰛ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬⰜ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪⰝ")]: continue
						if l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭Ⱎ") in name or l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨⰟ") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪⰠ") in name: l1lll11ll1l_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩⰡ")
							elif mode==144 and l1l111_l1_ (u"ࠧࡄࡊࡑࡐࠬⰢ") in name: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫⰣ")
							elif mode==144 and l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧⰤ") in name: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧⰥ")
							elif mode==143: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬⰦ")
							else: continue
					elif l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࠫⰧ") in l1lll11ll1l_l1_ and 419>=mode>=400:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧⰨ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧⰩ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭Ⱚ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧⰫ")]: continue
						if   mode in [401,405]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫⰬ")
						elif mode in [402,406]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫⰭ")
						elif mode in [403,404]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪⰮ")
						elif mode in [412,413]: l1lll11ll1l_l1_ = l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫⰯ")
					elif l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࠧⰰ") in l1lll11ll1l_l1_ and 39>=mode>=30:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙ࠧⰱ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨⰲ")]: continue
						if   mode in [32,39]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩⰳ")
						elif mode in [33,39]: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪⰴ")
					elif l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࠬⰵ") in l1lll11ll1l_l1_ and 29>=mode>=20:
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬⰶ")]: continue
						if l1lll11l11l_l1_ in l1ll1lll1ll_l1_[l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧⰷ")]: continue
						if   l1l111_l1_ (u"ࠨ࠱ࡤࡶ࠳࠭ⰸ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨⰹ")
						elif l1l111_l1_ (u"ࠪ࠳ࡪࡴ࠮ࠨⰺ") in url: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫⰻ")
					l1ll1lll1ll_l1_[l1lll11ll1l_l1_].append(l1lll11l11l_l1_)
		menuItemsLIST[:] = []
		for l1lll11ll1l_l1_ in list(l1ll1lll1ll_l1_.keys()):
			l1ll1lllll1_l1_[l1lll11ll1l_l1_] = []
			l1ll1llll1l_l1_[l1lll11ll1l_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1ll1lll1ll_l1_[l1lll11ll1l_l1_]:
				l1lll11l11l_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
				if l1l111_l1_ (u"ࠬ฻แฮหࠪⰼ") in name and type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⰽ"): l1ll1llll1l_l1_[l1lll11ll1l_l1_].append(l1lll11l11l_l1_)
				else: l1ll1lllll1_l1_[l1lll11ll1l_l1_].append(l1lll11l11l_l1_)
		l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰾ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰿ"),l1l111_l1_ (u"ࠩࠪⱀ"),157,l1l111_l1_ (u"ࠪࠫⱁ"),l1l111_l1_ (u"ࠫࠬⱂ"),l1l111_l1_ (u"ࠬ࠭ⱃ"),l1l111_l1_ (u"࠭ࠧⱄ"),l1l111_l1_ (u"ࠧࠨⱅ"))]
		for l1lll11ll1l_l1_ in l1lll1l111l_l1_:
			if l1lll11ll1l_l1_==l1lll111l1l_l1_[0]: l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⱆ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⱇ"),l1l111_l1_ (u"ࠪࠫⱈ"),157,l1l111_l1_ (u"ࠫࠬⱉ"),l1l111_l1_ (u"ࠬ࠭ⱊ"),l1l111_l1_ (u"࠭ࠧⱋ"),l1l111_l1_ (u"ࠧࠨⱌ"),l1l111_l1_ (u"ࠨࠩⱍ"))]
			elif l1lll11ll1l_l1_==l1llll11111_l1_[0]: l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⱎ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⱏ"),l1l111_l1_ (u"ࠫࠬⱐ"),157,l1l111_l1_ (u"ࠬ࠭ⱑ"),l1l111_l1_ (u"࠭ࠧⱒ"),l1l111_l1_ (u"ࠧࠨⱓ"),l1l111_l1_ (u"ࠨࠩⱔ"),l1l111_l1_ (u"ࠩࠪⱕ"))]
			elif l1lll11ll1l_l1_==l1ll1llll11_l1_[0]: l1lll1l1ll1_l1_ = [(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱖ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱗ"),l1l111_l1_ (u"ࠬ࠭ⱘ"),157,l1l111_l1_ (u"࠭ࠧⱙ"),l1l111_l1_ (u"ࠧࠨⱚ"),l1l111_l1_ (u"ࠨࠩⱛ"),l1l111_l1_ (u"ࠩࠪⱜ"),l1l111_l1_ (u"ࠪࠫⱝ"))]
			if l1lll11ll1l_l1_ not in l1ll1lllll1_l1_.keys(): continue
			if l1ll1lllll1_l1_[l1lll11ll1l_l1_]:
				l1lll11111l_l1_ = TRANSLATE(l1lll11ll1l_l1_)
				l1lll11l111_l1_ = [(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⱞ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࠦࠧⱟ")+l1lll11111l_l1_+l1l111_l1_ (u"࠭ࠠ࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱠ"),l1l111_l1_ (u"ࠧࠨⱡ"),9999,l1l111_l1_ (u"ࠨࠩⱢ"),l1l111_l1_ (u"ࠩࠪⱣ"),l1l111_l1_ (u"ࠪࠫⱤ"),l1l111_l1_ (u"ࠫࠬⱥ"),l1l111_l1_ (u"ࠬ࠭ⱦ"))]
				if 0:
					l1llll1111l_l1_ = l1lll111lll_l1_+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪⱧ")+l1l111_l1_ (u"ࠧษฯฮࠫⱨ")+l1l111_l1_ (u"ࠨࠢࠪⱩ")+l1lll11111l_l1_
				else:
					l1llll1111l_l1_ = l1l111_l1_ (u"ࠩหัะ࠭ⱪ")+l1l111_l1_ (u"ࠪࠤࠬⱫ")+l1lll11111l_l1_+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨⱬ")+l1lll111lll_l1_
				if len(l1ll1lllll1_l1_[l1lll11ll1l_l1_])<8: l1lll1l1l1l_l1_ = []
				else:
					l1llll111l1_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨⱭ")+l1llll1111l_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨⱮ")
					l1lll1l1l1l_l1_ = [(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱯ"),l1lllll_l1_+l1llll111l1_l1_,l1l111_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱰ"),542,l1l111_l1_ (u"ࠩࠪⱱ"),l1lll11ll1l_l1_,l1lll111lll_l1_,l1l111_l1_ (u"ࠪࠫⱲ"),l1l111_l1_ (u"ࠫࠬⱳ"))]
				l1lll1ll1ll_l1_ = l1ll1lllll1_l1_[l1lll11ll1l_l1_]+l1ll1llll1l_l1_[l1lll11ll1l_l1_]
				l1lll1l1111_l1_ += l1lll1l1ll1_l1_+l1lll11l111_l1_+l1lll1ll1ll_l1_[:7]+l1lll1l1l1l_l1_
				l1lll111111_l1_ = [(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱴ"),l1lllll_l1_+l1llll1111l_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬⱵ"),542,l1l111_l1_ (u"ࠧࠨⱶ"),l1lll11ll1l_l1_,l1lll111lll_l1_,l1l111_l1_ (u"ࠨࠩⱷ"),l1l111_l1_ (u"ࠩࠪⱸ"))]
				l1lll11llll_l1_ += l1lll1l1ll1_l1_+l1lll111111_l1_
				l1lll1l1ll1_l1_ = []
				l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩⱹ"),(l1lll11ll1l_l1_,l1lll111lll_l1_),l1lll1ll1ll_l1_,l1lll11lll1_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡓࡕࡋࡎࡆࡆࠪⱺ"),l1lll111lll_l1_,l1lll1l1111_l1_,l1lll11lll1_l1_)
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱻ"),l1lll111lll_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⱼ"),l1lllll_l1_+l1lll111lll_l1_,l1lll11llll_l1_,l1lll11lll1_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨⱽ"),l1l111_l1_ (u"ࠨࠩⱾ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⱿ"),l1l111_l1_ (u"ࠪห้ฮอฬࠢส่ั๋วฺ์ࠣห๋ะ็๊ࠢห๊ัออࠡ࡞ࡱࡠࡳࠦสๆࠢอาื๐ๆࠡษ็๊ฯอฦอࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤ้๋ฯสࠢฮ่ฬั๊็ࠢํ์๊ࠦไไ์ࠣฮุะื๋฻ࠣห้฿่ะหࠣษ้๐็ศࠢหำํ์ฺࠠ็็ࠤอำหࠡฮา๎ิ࠭Ⲁ"))
		if action==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⲁ") and l1lll11llll_l1_: l1lll1l1l11_l1_ = l1lll11llll_l1_
		else: l1lll1l1l11_l1_ = l1lll1l1111_l1_
	if action!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫⲂ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1lll1l1l11_l1_:
			if action in [l1l111_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬⲃ"),l1l111_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ⲅ")] and l1l111_l1_ (u"ࠨืไัฮ࠭ⲅ") in name and type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲆ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
	return
def l1lll1l1lll_l1_(l1lll111lll_l1_=l1l111_l1_ (u"ࠪࠫⲇ")):
	search,options,l11_l1_ = l111ll_l1_(l1lll111lll_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⲈ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩⲉ")+search+l1l111_l1_ (u"࠭ࠠ࡞ࠩⲊ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll1lll11_l1_,l1111ll11l_l1_ = search+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫⲋ"),l1l111_l1_ (u"ࠨࠩⲌ")
	else: l1lll1lll11_l1_,l1111ll11l_l1_ = l1l111_l1_ (u"ࠩࠪⲍ"),l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⲎ")+search
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⲏ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⲐ"),l1l111_l1_ (u"࠭ࠧⲑ"),157)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲒ"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧⲓ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦࡍ࠴ࡗࠪⲔ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⲕ"),719,l1l111_l1_ (u"ࠫࠬⲖ"),l1l111_l1_ (u"ࠬ࠭ⲗ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲙ"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭ⲙ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯࠥࡏࡐࡕࡘࠪⲚ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⲛ"),239,l1l111_l1_ (u"ࠪࠫⲜ"),l1l111_l1_ (u"ࠫࠬⲝ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲞ"),l1l111_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬⲟ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢห็ึอࠧⲠ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⲡ"),379,l1l111_l1_ (u"ࠩࠪⲢ"),l1l111_l1_ (u"ࠪࠫⲣ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲤ"),l1l111_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫⲥ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅ็ࠤฬู๊าสࠪⲦ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⲧ"),19,l1l111_l1_ (u"ࠨࠩⲨ"),l1l111_l1_ (u"ࠩࠪⲩ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲪ"),l1l111_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪⲫ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫⲬ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⲭ"),739,l1l111_l1_ (u"ࠧࠨⲮ"),l1l111_l1_ (u"ࠨࠩⲯ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲰ"),l1l111_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩⲱ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫⲲ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⲳ"),329,l1l111_l1_ (u"࠭ࠧⲴ"),l1l111_l1_ (u"ࠧࠨⲵ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲶ"),l1l111_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨⲷ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩⲸ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⲹ"),579,l1l111_l1_ (u"ࠬ࠭Ⲻ"),l1l111_l1_ (u"࠭ࠧⲻ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲼ"),l1l111_l1_ (u"ࠨࡡࡎࡘ࡛ࡥࠧⲽ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨⲾ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⲿ"),819,l1l111_l1_ (u"ࠫࠬⳀ"),l1l111_l1_ (u"ࠬ࠭ⳁ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳃ"),l1l111_l1_ (u"ࠧࡠࡇࡅ࠵ࡤ࠭ⳃ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨⳄ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⳅ"),779,l1l111_l1_ (u"ࠪࠫⳆ"),l1l111_l1_ (u"ࠫࠬⳇ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳈ"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠵ࡣࠬⳉ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧⳊ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⳋ"),789,l1l111_l1_ (u"ࠩࠪⳌ"),l1l111_l1_ (u"ࠪࠫⳍ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳎ"),l1l111_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⳏ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ࠠࠡสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩⳐ")+l1111ll11l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠪⳑ"),l1l111_l1_ (u"ࠨࠩⳒ"),29,l1l111_l1_ (u"ࠩࠪⳓ"),l1l111_l1_ (u"ࠪࠫⳔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳕ"),l1l111_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫⳖ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧⳗ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⳘ"),79,l1l111_l1_ (u"ࠨࠩⳙ"),l1l111_l1_ (u"ࠩࠪⳚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳛ"),l1l111_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪⳜ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ⳝ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⳞ"),249,l1l111_l1_ (u"ࠧࠨⳟ"),l1l111_l1_ (u"ࠨࠩⳠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳡ"),l1l111_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩⳢ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬⳣ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⳤ"),49,l1l111_l1_ (u"࠭ࠧ⳥"),l1l111_l1_ (u"ࠧࠨ⳦"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⳧"),l1l111_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ⳨")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧ⳩")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬ⳪"),59,l1l111_l1_ (u"ࠬ࠭Ⳬ"),l1l111_l1_ (u"࠭ࠧⳬ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳭ"),l1l111_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧⳮ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬ⳯")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫ⳰"),69,l1l111_l1_ (u"ࠫࠬ⳱"),l1l111_l1_ (u"ࠬ࠭Ⳳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⳳ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⳴"),l1l111_l1_ (u"ࠨࠩ⳵"),157)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳶"),l1l111_l1_ (u"ࠪࡣࡋࡐࡓࡠࠩ⳷")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫࠥฮอฬ่ࠢ์็฿ࠠโฮิࠤู๎ࠧ⳸")+l1111ll11l_l1_+l1l111_l1_ (u"ࠬࠦࠧ⳹"),l1l111_l1_ (u"࠭ࠧ⳺"),399,l1l111_l1_ (u"ࠧࠨ⳻"),l1l111_l1_ (u"ࠨࠩ⳼"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳽"),l1l111_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩ⳾")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨ⳿")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⴀ"),469,l1l111_l1_ (u"࠭ࠧⴁ"),l1l111_l1_ (u"ࠧࠨⴂ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴃ"),l1l111_l1_ (u"ࠩࡢࡐࡉࡔ࡟ࠨⴄ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭ⴅ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⴆ"),459,l1l111_l1_ (u"ࠬ࠭ⴇ"),l1l111_l1_ (u"࠭ࠧⴈ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴉ"),l1l111_l1_ (u"ࠨࡡࡆࡑࡓࡥࠧⴊ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭ⴋ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⴌ"),309,l1l111_l1_ (u"ࠫࠬⴍ"),l1l111_l1_ (u"ࠬ࠭ⴎ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴏ"),l1l111_l1_ (u"ࠧࡠ࡙ࡆࡑࡤ࠭ⴐ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ์๏ࠦำ๋็สࠫⴑ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⴒ"),569,l1l111_l1_ (u"ࠪࠫⴓ"),l1l111_l1_ (u"ࠫࠬⴔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴕ"),l1l111_l1_ (u"࠭࡟ࡔࡊࡑࡣࠬⴖ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢืห์ีࠠ็์๋ึࠬⴗ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⴘ"),589,l1l111_l1_ (u"ࠩࠪⴙ"),l1l111_l1_ (u"ࠪࠫⴚ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩⴛ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴜ"),l1l111_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬⴝ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦำ๋์าࠫⴞ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⴟ"),259,l1l111_l1_ (u"ࠩࠪⴠ"),l1l111_l1_ (u"ࠪࠫⴡ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴢ"),l1l111_l1_ (u"ࠬࡥࡃ࠵ࡗࡢࠫⴣ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦแ้ำํ์ࠬⴤ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⴥ"),429,l1l111_l1_ (u"ࠨࠩ⴦"),l1l111_l1_ (u"ࠩࠪⴧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l1l111_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪ⴩")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠪ⴪")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⴫"),829,l1l111_l1_ (u"ࠧࠨ⴬"),l1l111_l1_ (u"ࠨࠩⴭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⴮"),l1l111_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩ⴯")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪⴰ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⴱ"),119,l1l111_l1_ (u"࠭ࠧⴲ"),l1l111_l1_ (u"ࠧࠨⴳ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ⴴ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴵ"),l1l111_l1_ (u"ࠪࡣࡘࡎࡔࡠࠩⴶ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪⴷ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⴸ"),649,l1l111_l1_ (u"࠭ࠧⴹ"),l1l111_l1_ (u"ࠧࠨⴺ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴻ"),l1l111_l1_ (u"ࠩࡢࡉࡇ࠹࡟ࠨⴼ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪⴽ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⴾ"),799,l1l111_l1_ (u"ࠬ࠭ⴿ"),l1l111_l1_ (u"࠭ࠧⵀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⵁ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⵂ"),l1l111_l1_ (u"ࠩࠪⵃ"),157)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵄ"),l1l111_l1_ (u"ࠫࡤࡌࡓࡕࡡࠪⵅ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโ๊ึฮฬ࠭ⵆ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⵇ"),609,l1l111_l1_ (u"ࠧࠨⵈ"),l1l111_l1_ (u"ࠨࠩⵉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵊ"),l1l111_l1_ (u"ࠪࡣࡋࡈࡋࡠࠩⵋ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแษำๆอࠬⵌ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⵍ"),629,l1l111_l1_ (u"࠭ࠧⵎ"),l1l111_l1_ (u"ࠧࠨⵏ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵐ"),l1l111_l1_ (u"ࠩࡢ࡝ࡖ࡚࡟ࠨⵑ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๐วใ๊อࠫⵒ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⵓ"),669,l1l111_l1_ (u"ࠬ࠭ⵔ"),l1l111_l1_ (u"࠭ࠧⵕ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵖ"),l1l111_l1_ (u"ࠨࡡࡅࡖࡘࡥࠧⵗ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤอืำห์ฯࠫⵘ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⵙ"),659,l1l111_l1_ (u"ࠫࠬⵚ"),l1l111_l1_ (u"ࠬ࠭ⵛ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵜ"),l1l111_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭ⵝ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻๋้ࠣอࠠิ์่หࠬⵞ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⵟ"),89,l1l111_l1_ (u"ࠪࠫⵠ"),l1l111_l1_ (u"ࠫࠬⵡ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵢ"),l1l111_l1_ (u"࠭࡟ࡅࡔ࠺ࡣࠬⵣ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢาีฬ๋วࠡืะࠫⵤ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⵥ"),689,l1l111_l1_ (u"ࠩࠪⵦ"),l1l111_l1_ (u"ࠪࠫⵧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⵨"),l1l111_l1_ (u"ࠬࡥࡃࡎࡈࡢࠫ⵩")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦแศ่ีࠫ⵪")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨ⵫"),99,l1l111_l1_ (u"ࠨࠩ⵬"),l1l111_l1_ (u"ࠩࠪ⵭"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⵮"),l1l111_l1_ (u"ࠫࡤࡉࡍࡍࡡࠪⵯ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ⵰")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⵱"),479,l1l111_l1_ (u"ࠧࠨ⵲"),l1l111_l1_ (u"ࠨࠩ⵳"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵴"),l1l111_l1_ (u"ࠪࡣࡆࡈࡄࡠࠩ⵵")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩ⵶")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭⵷"),559,l1l111_l1_ (u"࠭ࠧ⵸"),l1l111_l1_ (u"ࠧࠨ⵹"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵺"),l1l111_l1_ (u"ࠩࡢࡇ࠹ࡎ࡟ࠨ⵻")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧ⵼")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬ⵽"),699,l1l111_l1_ (u"ࠬ࠭⵾"),l1l111_l1_ (u"⵿࠭ࠧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶀ"),l1l111_l1_ (u"ࠨࡡࡄࡌࡐࡥࠧⶁ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨⶂ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⶃ"),619,l1l111_l1_ (u"ࠫࠬⶄ"),l1l111_l1_ (u"ࠬ࠭ⶅ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶆ"),l1l111_l1_ (u"ࠧࡠࡇࡅ࠸ࡤ࠭ⶇ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨⶈ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⶉ"),809,l1l111_l1_ (u"ࠪࠫⶊ"),l1l111_l1_ (u"ࠫࠬⶋ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶌ"),l1l111_l1_ (u"࠭࡟ࡄࡅ࡚ࡣࠬⶍ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩⶎ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⶏ"),639,l1l111_l1_ (u"ࠩࠪⶐ"),l1l111_l1_ (u"ࠪࠫⶑ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⶒ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⶓ"),l1l111_l1_ (u"࠭ࠧⶔ"),157)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶕ"),l1l111_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧⶖ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏๎ส๋๊หࠫ⶗")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫ⶘"),149,l1l111_l1_ (u"ࠫࠬ⶙"),l1l111_l1_ (u"ࠬ࠭⶚"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⶛"),l1l111_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭⶜")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭⶝")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪ⶞"),409,l1l111_l1_ (u"ࠪࠫ⶟"),l1l111_l1_ (u"ࠫࠬⶠ"),l1lll1ll_l1_)
	return
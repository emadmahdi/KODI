# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ媚")
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ媛"):l1l111_l1_ (u"ࠬ࠭媜")}
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬ媝")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ媞"),l1l111_l1_ (u"ࠨࡹࡺࡩࠬ媟")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ媠")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ媡")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ媢"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ媣"),l111l1_l1_,569,l1l111_l1_ (u"࠭ࠧ媤"),l1l111_l1_ (u"ࠧࠨ媥"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ媦"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媧"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭媨"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ媩"),564)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媪"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ媫"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ媬"),565)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭媭"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ媮"),l1l111_l1_ (u"ࠪࠫ媯"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ媰"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭媱"),l1l111_l1_ (u"࠭ࠧ媲"),l1l111_l1_ (u"ࠧࠨ媳"),l1l111_l1_ (u"ࠨࠩ媴"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ媵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ媶"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ媷"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠬ࠭媸"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媹"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ媺")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭媻"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ媼"),l1l111_l1_ (u"ࠪࠫ媽"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭媾"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ媿"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫀"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嫁")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嫂"),url,l1l111_l1_ (u"ࠩࠪ嫃"),l1l111_l1_ (u"ࠪࠫ嫄"),l1l111_l1_ (u"ࠫࠬ嫅"),l1l111_l1_ (u"ࠬ࠭嫆"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ嫇"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ嫈") in html:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫉"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ嫊"),url,561,l1l111_l1_ (u"ࠪࠫ嫋"),l1l111_l1_ (u"ࠫࠬ嫌"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ嫍"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ嫎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嫏"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫐"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1lllll1lll1_l1_,type=l1l111_l1_ (u"ࠩࠪ嫑")):
	if l1l111_l1_ (u"ࠪ࠾࠿࠭嫒") in l1lllll1lll1_l1_:
		l1llllll_l1_,url = l1lllll1lll1_l1_.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ嫓"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ嫔"))
		url = server+url
	else: url,l1llllll_l1_ = l1lllll1lll1_l1_,l1lllll1lll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嫕"),url,l1l111_l1_ (u"ࠧࠨ嫖"),l1l111_l1_ (u"ࠨࠩ嫗"),l1l111_l1_ (u"ࠩࠪ嫘"),l1l111_l1_ (u"ࠪࠫ嫙"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ嫚"))
	html = response.content
	if type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ嫛"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠪ嫜"),html,re.DOTALL)
	elif type in [l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ嫝"),l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ嫞")]:
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭嫟"),l1l111_l1_ (u"ࠪ࠳ࠬ嫠")).replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ嫡"),l1l111_l1_ (u"ࠬࠨࠧ嫢"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡈࡴ࡬ࡨ࠲࠳ࡗࡦࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫࠥࡖ࡮࡭ࡨࡵࡗࡌࠦࠬ嫣"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡖ࡫ࡹࡲࡨ࠭࠮ࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭嫤"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ嫥"),l1l111_l1_ (u"ࠩࠪ嫦"))
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ嫧") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫨"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠬำไใหࠪ嫩") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ嫪"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭嫫") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫬"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嫭"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ嫮"):
			l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ嫯"),block,re.DOTALL)
			if l111l1llll_l1_:
				count = l111l1llll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ嫰")+count
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫱"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ嫲"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠨࠩ嫳"),l1l111_l1_ (u"ࠩࠪ嫴"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ嫵"))
		elif type==l1l111_l1_ (u"ࠫࠬ嫶"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嫷"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嫸"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠧึใะอࠥ࠭嫹")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫺"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ嫻")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嫼"),url,l1l111_l1_ (u"ࠫࠬ嫽"),l1l111_l1_ (u"ࠬ࠭嫾"),l1l111_l1_ (u"࠭ࠧ嫿"),l1l111_l1_ (u"ࠧࠨ嬀"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ嬁"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ嬂"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ嬃"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嬄"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠬ࠭嬅"),l1l111_l1_ (u"࠭ࠧ嬆"),l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ嬇"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࡳ࠿ࠩ嬈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠪ嬉"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ嬊"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嬋"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ嬌"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ嬍"),l1l111_l1_ (u"ࠧࠨ嬎")).replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ嬏"),l1l111_l1_ (u"ࠩࠪ嬐"))
		else: title = l1l111_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ嬑")
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嬒"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嬓"),url,l1l111_l1_ (u"࠭ࠧ嬔"),l1l111_l1_ (u"ࠧࠨ嬕"),l1l111_l1_ (u"ࠨࠩ嬖"),l1l111_l1_ (u"ࠩࠪ嬗"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ嬘"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嬙"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ嬚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嬛"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嬜") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠨีํีๆื้ࠠ์ࠣื๏๋วࠨ嬝"): name = l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ嬞")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ嬟")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ嬠")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ嬡"),l1l111_l1_ (u"࠭ࠧ嬢")).replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ嬣"),l1l111_l1_ (u"ࠨࠩ嬤"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嬥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嬦"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嬧") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭嬨"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ嬩")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ嬪")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡹࡨࡧ࡮ࡳࡡࠨ嬫")+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭嬬")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭嬭"),l1l111_l1_ (u"ࠫࠬ嬮")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ嬯"),l1l111_l1_ (u"࠭ࠧ嬰"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嬱"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠨࠩ嬲")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ嬳"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ嬴"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭嬵"),l1l111_l1_ (u"ࠬ࠱ࠧ嬶"))
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪ嬷")+search
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ嬸"))
	return
def l1l1ll1l_l1_(l1lllll1lll1_l1_,filter):
	if l1l111_l1_ (u"ࠨࡁࡂࠫ嬹") in l1lllll1lll1_l1_: url = l1lllll1lll1_l1_.split(l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ嬺"))[0]
	else: url = l1lllll1lll1_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嬻"),l1l111_l1_ (u"ࠫࠬ嬼"))
	type,filter = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ嬽"),1)
	if filter==l1l111_l1_ (u"࠭ࠧ嬾"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠧࠨ嬿"),l1l111_l1_ (u"ࠨࠩ孀")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭孁"))
	if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ孂"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠫࡂࡃࠧ孃") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ孄") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ孅")+category+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ孆")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ孇")+category+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭孈")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭孉"))+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ孊")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ孋"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ孌"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭孍")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ孎"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ孏"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠪࠫ子"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ孑"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠬ࠭孒"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ孓")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lllll1lll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ孔"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ孕"),l1111111_l1_,561,l1l111_l1_ (u"ࠩࠪ孖"),l1l111_l1_ (u"ࠪࠫ字"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ存"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孙"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭孚")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭孛"),l1111111_l1_,561,l1l111_l1_ (u"ࠨࠩ孜"),l1l111_l1_ (u"ࠩࠪ孝"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ孞"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ孟"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ孠"),l1l111_l1_ (u"࠭ࠧ孡"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ孢"),url,l1l111_l1_ (u"ࠨࠩ季"),l1l111_l1_ (u"ࠩࠪ孤"),l1l111_l1_ (u"ࠪࠫ孥"),l1l111_l1_ (u"ࠫࠬ学"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ孧"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"࠭࡜࡝ࠤࠪ孨"),l1l111_l1_ (u"ࠧࠣࠩ孩")).replace(l1l111_l1_ (u"ࠨ࡞࡟࠳ࠬ孪"),l1l111_l1_ (u"ࠩ࠲ࠫ孫"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡼ࡫ࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡼ࡫ࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭孬"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ孭"),block+l1l111_l1_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ孮"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ孯") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩ孰"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠨ࠿ࡀࠫ孱") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭孲"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ孳")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lllll1lll1_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ孴"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ孵"),l1111111_l1_,561,l1l111_l1_ (u"࠭ࠧ孶"),l1l111_l1_ (u"ࠧࠨ孷"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ學"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ孹"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ孺"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠫࠬ孻"),l1l111_l1_ (u"ࠬ࠭孼"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ孽"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ孾")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ孿")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ宀")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ宁")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ宂")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ它"),l1lllll_l1_+name+l1l111_l1_ (u"࠭࠺ࠡษ็ะ๊๐ูࠨ宄"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠧࠨ宅"),l1l111_l1_ (u"ࠨࠩ宆"),l1l111l1_l1_+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ宇"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠪࡶࠬ守") or value==l1l111_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ安"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ宊") in option: continue
			if l1l111_l1_ (u"࠭วๅๅ็ࠫ宋") in option: continue
			if l1l111_l1_ (u"ࠧ࡯࠯ࡤࠫ完") in value: continue
			if option==l1l111_l1_ (u"ࠨࠩ宍"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧ宎"),option,re.DOTALL)
			if l1ll1l11ll1_l1_: l1l11l1ll_l1_ = l1ll1l11ll1_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠪ࠾ࠥ࠭宏")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ宐")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨ宑")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ宒")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿ࠪ宓")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ宔")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ宕"):
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宖"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠫࠬ宗"),l1l111_l1_ (u"ࠬ࠭官"),l1l1l11l_l1_+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ宙"))
			elif type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ定") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ宛") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ宜"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ宝")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lllll1lll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ实"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠬ࠭実"),l1l111_l1_ (u"࠭ࠧ宠"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ审"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ客"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠩࠪ宣"),l1l111_l1_ (u"ࠪࠫ室"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ宥"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ宦"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭宧")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ宨"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ宩"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ宪"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ宫"),l1l111_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ宬"),l1l111_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ宭"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭宮"),l1l111_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ宯")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ宰") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ宱"),l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ宲"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ害"),l1l111_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ宴"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠽࠾ࠩ宵"),l1l111_l1_ (u"ࠧ࠰ࠩ家"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨࠨࠩࠫ宷"),l1l111_l1_ (u"ࠩ࠲ࠫ宸"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭容"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠫࠬ宺")
	if l1l111_l1_ (u"ࠬࡃ࠽ࠨ宻") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠧࠩ宼"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾࠿ࠪ宽"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪ宾")
		if l1l111_l1_ (u"ࠩࠨࠫ宿") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ寀") and value!=l1l111_l1_ (u"ࠫ࠵࠭寁"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩ寂")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ寃") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ寄"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ寅")+key+l1l111_l1_ (u"ࠩࡀࡁࠬ密")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧ寇"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ寈")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨ寉")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ寊"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ寋"))
	return l1l1l111_l1_
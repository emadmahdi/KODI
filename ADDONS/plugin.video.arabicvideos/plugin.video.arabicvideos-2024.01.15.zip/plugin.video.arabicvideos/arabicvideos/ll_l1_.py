# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䢈")
l1l11ll11111_l1_ = []
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䢉"):l1l111_l1_ (u"࠭ࠧ䢊")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䢋"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤ࡫࡯࡮ࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࡵࠣࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ䢌")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪ䢍")+type+l1l111_l1_ (u"ࠪࠤࡢ࠭䢎"))
		l1l111l111l1_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䢏"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䢐"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ䢑"))
		datetime = time.strftime(l1l111_l1_ (u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍࠨ䢒"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭䢓")+l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ䢔")+str(kodi_version)
		message = l1l111_l1_ (u"ࠪࠫ䢕")
		if key not in list(l1l111l111l1_l1_.keys()): l1l111l111l1_l1_[key] = [line]
		else:
			if url not in str(l1l111l111l1_l1_[key]): l1l111l111l1_l1_[key].append(line)
			else: message = l1l111_l1_ (u"ࠫࡡࡴ่ࠠาสࠤฬ๊แ๋ัํ์๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡๆ่ࠤฯ฿ๅๅࠩ䢖")
		total = 0
		for key in list(l1l111l111l1_l1_.keys()):
			l1l111l111l1_l1_[key] = list(set(l1l111l111l1_l1_[key]))
			total += len(l1l111l111l1_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䢗"),l1l111_l1_ (u"࠭ࠧ䢘"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䢙"),l1l111_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ䢚")+message+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠠๅๆ฼่๊ࠦวๅสิ๊ฬ๋ฬࠡ์ๅ์๊ࠦศอ็฼ࠤ็อฦๆหࠣฬฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢํะิࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่๊ࠡึ์ๆฺ๊ࠦำูࠤ฾๊๊ไࠢส่อืๆศ็ฯࠤศ์ࠠหำึ่ࠥํะ่ࠢส่็อฦๆหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻้ำ๊อ๋ࠠืหัࠥ฿ฯะ้สࠤ࠺ࠦแ๋ัํ์์อสࠨ䢛")+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䢜")+l1l111_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡษ็ๆฬฬๅสࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠧ䢝")+str(total))
		if total>=5:
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬ࠭䢞"),l1l111_l1_ (u"࠭ࠧ䢟"),l1l111_l1_ (u"ࠧࠨ䢠"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䢡"),l1l111_l1_ (u"ࠩส่อืๆศ็ฯࠤัู๋ࠡไสส๊ฯࠠโ์๊หࠥ࠻ࠠโ์า๎ํํวหࠢ็้ࠥ๐ฬะࠢส่อืๆศ็ฯࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํࠦ࠮࠯ࠢึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ๋ำฮ๊ࠢิ์ࠦวๅไสส๊ฯࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦลาีส่ࠥํะ่ࠢส่็อฦๆหࠣๆอ๊ࠠๆีะ๋ฬࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅ็หี๊าࠠษใะูࠥํะ่ࠢส่ๆ๐ฯ๋๊๊หฯࠦฟࠢࠣࠪ䢢"))
			if l1llll111l_l1_==1:
				l1l111l11l11_l1_ = l1l111_l1_ (u"ࠪࠫ䢣")
				for key in list(l1l111l111l1_l1_.keys()):
					l1l111l11l11_l1_ += l1l111_l1_ (u"ࠫࡡࡴࠧ䢤")+key
					l1l1l11l1lll_l1_ = sorted(l1l111l111l1_l1_[key],reverse=False,key=lambda l1l1111l1l1l_l1_: l1l1111l1l1l_l1_[0])
					for datetime,url in l1l1l11l1lll_l1_:
						l1l111l11l11_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࠨ䢥")+datetime+l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ䢦")+l111l11_l1_(url)
					l1l111l11l11_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䢧")
				import l1l1l1111ll_l1_
				succeeded = l1l1l1111ll_l1_.l11l1ll111l_l1_(l1l111_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࡳࠨ䢨"),l1l111_l1_ (u"ࠩࠪ䢩"),False,l1l111_l1_ (u"ࠪࠫ䢪"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䢫"),l1l111_l1_ (u"ࠬ࠭䢬"),l1l111l11l11_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䢭"),l1l111_l1_ (u"ࠧࠨ䢮"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䢯"),l1l111_l1_ (u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬ䢰"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䢱"),l1l111_l1_ (u"ࠫࠬ䢲"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䢳"),l1l111_l1_ (u"࠭แีๆอࠤ฾๋ไ๋หࠣห้หัิษ็ࠫ䢴"))
			if l1llll111l_l1_!=-1:
				l1l111l111l1_l1_ = {}
				l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䢵"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ䢶"))
		if l1l111l111l1_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ䢷"),l1l111_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ䢸"),l1l111l111l1_l1_,l1ll111ll11_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l1l11111l1ll_l1_(l1ll11l1_l1_,source)
	l1l1l111lll1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䢹"))
	l1l1111l11l1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䢺"))
	l1l1l11ll1ll_l1_ = len(l1llll_l1_)-l1l1l111lll1_l1_-l1l1111l11l1_l1_
	l1l111ll1111_l1_ = l1l111_l1_ (u"࠭ๅีษ๊ำฮࡀࠧ䢻")+str(l1l1l111lll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࠤฯำๅ๋ๆ࠽ࠫ䢼")+str(l1l1111l11l1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࠥษฮา๋࠽ࠫ䢽")+str(l1l1l11ll1ll_l1_)
	if not l1llll_l1_: result,l1l1l11lll1l_l1_ = l1l111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䢾"),l1l111_l1_ (u"ࠪࠫ䢿")
	else:
		while True:
			l1l1l11lll1l_l1_ = l1l111_l1_ (u"ࠫࠬ䣀")
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111ll1111_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ䣁")
			else:
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"࠭ำ๋ำไีࠬ䣂") in title and l1l111_l1_ (u"ࠧ࠳็ฯ๋ํ๊࠲ࠨ䣃") in title:
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䣄"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ䣅")+title+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䣆")+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ䣇"))
					import l1l1l1111ll_l1_
					l1l1l1111ll_l1_.l11l1ll_l1_(156)
					result = l1l111_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ䣈")
				else:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䣉"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࡓࡦࡴࡹࡩࡷࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ䣊")+title+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䣋")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ䣌"))
					result,l1l1l11lll1l_l1_,l1ll111l1111_l1_ = l1l11l11llll_l1_(l1ll1ll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䣍"),l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䣎"),l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭䣏"),l1l111_l1_ (u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ䣐"),l1l111_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ䣑")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ䣒"),l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ䣓"),l1l111_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ䣔")]: break
			elif result not in [l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ䣕"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ䣖")]:
				l1l1l11lll1l_l1_ = l1l111_l1_ (u"࡛࠭ࡍࡇࡉࡘࡢ࠭䣗")+l1l1l11lll1l_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ䣘"),l1l111_l1_ (u"ࠨ࡞ࡱ࡟ࡑࡋࡆࡕ࡟ࠪ䣙")) if l1l111_l1_ (u"ࠩ࡟ࡲࠬ䣚") in l1l1l11lll1l_l1_ else l1l111_l1_ (u"ࠪࠫ䣛")
				l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䣜"),l1l111_l1_ (u"ࠬ࠭䣝"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䣞"),l1l111_l1_ (u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪ䣟")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ䣠")+l1l1l11lll1l_l1_,profile=l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧ䣡"))
	if result==l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䣢") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䣣"),l1l111_l1_ (u"ࠬ࠭䣤"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䣥"),l1l111_l1_ (u"ࠧิ์ิๅึࠦ็ัษࠣห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠥาัษࠢไ๎ิ๐่ࠡ฼ํี์࠭䣦")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ䣧")+l1l1l11lll1l_l1_)
	elif result in [l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ䣨"),l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ䣩")] and l1l1l11lll1l_l1_!=l1l111_l1_ (u"ࠫࠬ䣪"): l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䣫"),l1l111_l1_ (u"࠭ࠧ䣬"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䣭"),l1l1l11lll1l_l1_)
	return result
def l1l11l11llll_l1_(url,source,type=l1l111_l1_ (u"ࠨࠩ䣮")):
	url = url.strip(l1l111_l1_ (u"ࠩࠣࠫ䣯")).strip(l1l111_l1_ (u"ࠪࠪࠬ䣰")).strip(l1l111_l1_ (u"ࠫࡄ࠭䣱")).strip(l1l111_l1_ (u"ࠬ࠵ࠧ䣲"))
	l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111ll1l_l1_(url,source)
	if l1l1l11lll1l_l1_==l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䣳"): return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭䣴"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ䣵")
			else:
				l1l1l1ll1lll_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䣶"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡴࡧ࡯ࡩࡨࡺࡥࡥࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ䣷")+title+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ䣸")+str(l1l1l1ll1lll_l1_)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ䣹"))
				if l1l111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ䣺") in l1l1l1ll1lll_l1_ and l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ䣻") in l1l1l1ll1lll_l1_:
					l1l1l1lll1l1_l1_,l1ll1111l1l1_l1_,l1ll111l1111_l1_ = l1l111ll1l1l_l1_(l1l1l1ll1lll_l1_)
					if l1ll111l1111_l1_: l1l1l1ll1lll_l1_ = l1ll111l1111_l1_[0]
					else: l1l1l1ll1lll_l1_ = l1l111_l1_ (u"ࠨࠩ䣼")
				if not l1l1l1ll1lll_l1_: result = l1l111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䣽")
				else: result = l1llll111_l1_(l1l1l1ll1lll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ䣾"),l1l111_l1_ (u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ䣿"),l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ䤀")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䤁"),l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䤂"),l1l111_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ䤃")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䤄"),l1l111_l1_ (u"ࠪࠫ䤅"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䤆"),l1l111_l1_ (u"ࠬอไๆๆไࠤ้๋๋ࠠ฻่่ࠥาัษ่่ࠢๆฺ๋ࠦำ๊ࠫ䤇"))
	else:
		result = l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䤈")
		l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(url)
		if l11ll1l1l1_l1_: result = l1llll111_l1_(url,source,type)
	return result,l1l1l11lll1l_l1_,l1llll_l1_
def l1l11l111lll_l1_(url,source):
	l1lllll1_l1_,l1l11l11ll1l_l1_,server,l1l1111l1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠧࠨ䤉"),l1l111_l1_ (u"ࠨࠩ䤊"),l1l111_l1_ (u"ࠩࠪ䤋"),l1l111_l1_ (u"ࠪࠫ䤌"),l1l111_l1_ (u"ࠫࠬ䤍"),l1l111_l1_ (u"ࠬ࠭䤎"),l1l111_l1_ (u"࠭ࠧ䤏")
	if l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䤐") in url:
		l1lllll1_l1_,l1l11l11ll1l_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䤑"),1)
		l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_+l1l111_l1_ (u"ࠩࡢࡣࠬ䤒")+l1l111_l1_ (u"ࠪࡣࡤ࠭䤓")+l1l111_l1_ (u"ࠫࡤࡥࠧ䤔")+l1l111_l1_ (u"ࠬࡥ࡟ࠨ䤕")
		l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1lll1l111l1_l1_ = l1l11l11ll1l_l1_.split(l1l111_l1_ (u"࠭࡟ࡠࠩ䤖"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠧࠨ䤗"): l111l1ll_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ䤘")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠩࡳࠫ䤙"),l1l111_l1_ (u"ࠪࠫ䤚")).replace(l1l111_l1_ (u"ࠫࠥ࠭䤛"),l1l111_l1_ (u"ࠬ࠭䤜"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"࠭࠿ࠨ䤝")).strip(l1l111_l1_ (u"ࠧ࠰ࠩ䤞")).strip(l1l111_l1_ (u"ࠨࠨࠪ䤟"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ䤠"))
	if name: l1l1111l1ll1_l1_ = name
	else: l1l1111l1ll1_l1_ = server
	l1l1111l1ll1_l1_ = l1l111l_l1_(l1l1111l1ll1_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ䤡"))
	name = name.replace(l1l111_l1_ (u"๊ࠫฮวีำࠪ䤢"),l1l111_l1_ (u"ࠬ࠭䤣")).replace(l1l111_l1_ (u"࠭ำ๋ำไีࠬ䤤"),l1l111_l1_ (u"ࠧࠨ䤥")).replace(l1l111_l1_ (u"ࠨษ็ࠤࠬ䤦"),l1l111_l1_ (u"ࠩࠣࠫ䤧")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䤨"),l1l111_l1_ (u"ࠫࠥ࠭䤩"))
	l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.replace(l1l111_l1_ (u"๋ࠬศศึิࠫ䤪"),l1l111_l1_ (u"࠭ࠧ䤫")).replace(l1l111_l1_ (u"ࠧิ์ิๅึ࠭䤬"),l1l111_l1_ (u"ࠨࠩ䤭")).replace(l1l111_l1_ (u"ࠩส่ࠥ࠭䤮"),l1l111_l1_ (u"ࠪࠤࠬ䤯")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䤰"),l1l111_l1_ (u"ࠬࠦࠧ䤱"))
	l1l1111l1ll1_l1_ = l1l1111l1ll1_l1_.replace(l1l111_l1_ (u"࠭ๅษษืีࠬ䤲"),l1l111_l1_ (u"ࠧࠨ䤳")).replace(l1l111_l1_ (u"ࠨีํีๆืࠧ䤴"),l1l111_l1_ (u"ࠩࠪ䤵")).replace(l1l111_l1_ (u"ࠪห้ࠦࠧ䤶"),l1l111_l1_ (u"ࠫࠥ࠭䤷")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䤸"),l1l111_l1_ (u"࠭ࠠࠨ䤹"))
	return l1lllll1_l1_,l1l11l11ll1l_l1_,server,l1l1111l1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l1l111llll_l1_(url,source):
	l1l1l1l11ll1_l1_,name,l11ll11l11l_l1_,l1l11l11l111_l1_,l1l11l11l11l_l1_,l1l11ll1111l_l1_,l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠧࠨ䤺"),l1l111_l1_ (u"ࠨࠩ䤻"),None,None,None,None,None
	l1lllll1_l1_,l1l11l11ll1l_l1_,server,l1l1111l1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l11l111lll_l1_(url,source)
	if l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䤼") in url:
		if   type==l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥࠩ䤽"): type = l1l111_l1_ (u"ࠫࠥ࠭䤾")+l1l111_l1_ (u"๋ࠬแืๆࠪ䤿")
		elif type==l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ䥀"): type = l1l111_l1_ (u"ࠧࠡࠩ䥁")+l1l111_l1_ (u"ࠨุ่ࠧฬํฯสࠩ䥂")
		elif type==l1l111_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䥃"): type = l1l111_l1_ (u"ࠪࠤࠬ䥄")+l1l111_l1_ (u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭䥅")
		elif type==l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䥆"): type = l1l111_l1_ (u"࠭ࠠࠨ䥇")+l1l111_l1_ (u"ࠧࠦࠧࠨฮา๋๊ๅࠩ䥈")
		elif type==l1l111_l1_ (u"ࠨࠩ䥉"): type = l1l111_l1_ (u"ࠩࠣࠫ䥊")+l1l111_l1_ (u"ࠪࠩࠪࠫࠥࠨ䥋")
		if l111lll_l1_!=l1l111_l1_ (u"ࠫࠬ䥌"):
			if l1l111_l1_ (u"ࠬࡳࡰ࠵ࠩ䥍") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"࠭ࠥࠨ䥎")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠧࠡࠩ䥏")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠨࠩ䥐"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬ䥑")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠤࠬ䥒")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ䥓")		in source: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ䥔")		in source: l11ll11l11l_l1_	= l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࠬ䥕")
	elif l1l111_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ䥖")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ䥗")	in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ䥘")		in source: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ䥙")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮ࠪ䥚")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡺ࠷࡮ࡧࡨࡰࠬ䥛")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭䥜")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ䥝")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䥞")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠩไะึ࠭䥟")			in name:   l11ll11l11l_l1_	= l1l111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䥠")
	elif l1l111_l1_ (u"ࠫๆ๊ำุ์้ࠫ䥡")		in name:   l11ll11l11l_l1_	= l1l111_l1_ (u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨ䥢")
	elif l1l111_l1_ (u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭䥣")		in l1lllll1_l1_:   l11ll11l11l_l1_	= l1l111_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ䥤")
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䥥")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ䥦")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䥧")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬ䥨")		in name:   l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ䥩")	in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ䥪")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭䥫")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ䥬")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪ䥭")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ䥮")		in server: l11ll11l11l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭䥯")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧ䥰")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭䥱")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠧࡦࡩࡼࡲࡴࡽࠧ䥲")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ䥳")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ䥴")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࠩ䥵")	 	in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ䥶")
	elif l1l111_l1_ (u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ䥷")	 	in server: l11ll11l11l_l1_	= l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ䥸")
	elif l1l111_l1_ (u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ䥹")	in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ䥺")
	elif l1l111_l1_ (u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ䥻")		in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬ䥼")
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䥽")		in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧ䥾")
	elif l1l111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ䥿")		in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䦀")
	elif l1l111_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ䦁")	in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ䦂")
	elif l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭䦃")	in server: l11ll11l11l_l1_	= l1l111_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ䦄")
	elif l1l111_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䦅")		in server: l11ll11l11l_l1_	= l1l111_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ䦆")
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ䦇")	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䦈")
	elif l1l111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ䦉")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䦊")
	elif l1l111_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭䦋")	 	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠬࡩࡡࡵࡥ࡫ࠫ䦌")
	elif l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ䦍")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ䦎")
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ䦏")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䦐")
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ䦑")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪ䦒")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ䦓")		in server: l1l11ll1111l_l1_	= l1l1111l1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ䦔")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ䦕")
	elif l1l111_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ䦖")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ䦗")
	elif l1l111_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ䦘") 	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭䦙")
	elif l1l111_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ䦚")	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䦛")
	elif l1l111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ䦜")	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭䦝")
	elif l1l111_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭䦞") 	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䦟")
	elif l1l111_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ䦠")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䦡")
	elif l1l111_l1_ (u"࠭ࡵࡱࡲࠪ䦢") 			in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭䦣")
	elif l1l111_l1_ (u"ࠨࡷࡳࡦࠬ䦤") 			in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ䦥")
	elif l1l111_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ䦦") 		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ䦧")
	elif l1l111_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ䦨") 	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䦩")
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䦪")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ䦫")
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ䦬") 		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䦭")
	elif l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䦮") 	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䦯")
	elif l1l111_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䦰")	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䦱")
	elif l1l111_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ䦲")	in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭䦳")
	elif l1l111_l1_ (u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪ䦴")		in server: l1l11l11l111_l1_	= l1l111_l1_ (u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫ䦵")
	if   l11ll11l11l_l1_:	l1l1l1l11ll1_l1_,name = l1l111_l1_ (u"ࠬิวึࠩ䦶"),l11ll11l11l_l1_
	elif l1l11ll1111l_l1_:		l1l1l1l11ll1_l1_,name = l1l111_l1_ (u"࠭ࠥๆฯาำࠬ䦷"),l1l11ll1111l_l1_
	elif l1l11l11l111_l1_:		l1l1l1l11ll1_l1_,name = l1l111_l1_ (u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬ䦸"),l1l11l11l111_l1_
	elif l1l11l11l11l_l1_:	l1l1l1l11ll1_l1_,name = l1l111_l1_ (u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧ䦹"),l1l11l11l11l_l1_
	elif l1l1l1l111l1_l1_:	l1l1l1l11ll1_l1_,name = l1l111_l1_ (u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ䦺"),l1l1111l1ll1_l1_
	else:			l1l1l1l11ll1_l1_,name = l1l111_l1_ (u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫ䦻"),l1l1111l1ll1_l1_
	return l1l1l1l11ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l11l1ll111_l1_(url,source):
	l1lllll1_l1_,l1l11ll1111l_l1_,server,l1l1111l1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l11l111lll_l1_(url,source)
	if   l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ䦼")		in source: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ䦽")		in source: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ䦾")		in source: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ䦿")		in source: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ䧀")		in source: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ䧁")		in source: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ䧂")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ䧃")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ䧄")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11llll11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ䧅")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll111l1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ䧆")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll111l1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ䧇")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡷࡺ࡫ࡻ࡮ࠨ䧈")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111llll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡸࡻࡱࡳࡢࠩ䧉")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111llll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡹࡼ࠭ࡧ࠰ࡦࡳࡲ࠭䧊")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111llll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ䧋")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ䧌")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䧍")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䧎")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11lll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ䧏")			in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll1l1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䧐")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllll1111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䧑")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭䧒")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪ䧓")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ䧔")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䧕")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1llll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ䧖")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll11l111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ䧗")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ䧘")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ䧙")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ䧚")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䧛"),[l1l111_l1_ (u"ࠨࠩ䧜")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ䧝")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111llll1l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ䧞")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll11ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠪ䧟")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l11l1111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡻࡰࡣࡣࡰࠫ䧠") 		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࠧ䧡"),[l1l111_l1_ (u"ࠧࠨ䧢")],[l1lllll1_l1_]
	else: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䧣"),[l1l111_l1_ (u"ࠩࠪ䧤")],[l1lllll1_l1_]
	return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l11l1111l1_l1_(url,source):
	l1l111llll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䧥"),[],[]
	l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ䧦")
	if l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭䧧") in url and l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ䧨") in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ䧩"),l1l111_l1_ (u"ࠨ࠱ࠪ䧪")).replace(l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ䧫"),l1l111_l1_ (u"ࠪࠫ䧬"))
		l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll1l11_l1_(l1lllll1_l1_)
		l1l111llll1l_l1_ += l1l111_l1_ (u"ࠫࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠣࠤࠬ䧭")+l1l1l11lll1l_l1_
		if not l1llll_l1_: l1l1l1l111l1_l1_,l1l111llll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1llll1l_l1_(l1l111llll1l_l1_,l1lllll1_l1_,source)
		if l1llll_l1_: return l1l111llll1l_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠤࡋࡧࡩ࡭ࡧࡧࠫ䧮"),[],[]
def l1l11l11111l_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䧯"))
	l1l11l1l1lll_l1_ = False
	if   l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭䧰")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ䧱")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨ䧲") in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1111l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ䧳")	in url   : l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll111ll_l1_(url)
	elif l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ䧴")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ䧵")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1l1l_l1_(url)
	elif l1l111_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ䧶")		in url   : l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll11_l1_(url)
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ䧷")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111l1l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ䧸")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l111ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ䧹")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11llll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡩ࠺ࡺࡳࡢࡴࠪ䧺")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111lll1_l1_(url)
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ䧻")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ䧼")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䧽") 		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䧾"),[l1l111_l1_ (u"ࠨࠩ䧿")],[url]
	elif l1l111_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ䨀") 	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䨁")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll1ll1l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ䨂") 	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䨃")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll111l_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࠪ䨄") 			in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll11l1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡶࡲࡳࠫ䨅") 			in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll11l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䨆") 		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll111l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䨇") 	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ䨈")		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll1111_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ䨉") 		in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111111_l1_(url)
	elif l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䨊") 	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll1ll11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䨋")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111ll1l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ䨌")	in server: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11l1ll1_l1_(url)
	else:
		l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll1l11_l1_(url)
		if not l1llll_l1_: l1l11l1l1lll_l1_ = True
	if l1l11l1l1lll_l1_ or l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ䨍") in l1l1l11lll1l_l1_:
		l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䨎"),[],[]
	return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l1l1llll1l_l1_(l1l111llll1l_l1_,url,source):
	l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䨏")
	l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11111l_l1_(url,source)
	l1llll_l1_ = l1l111llll11_l1_(l1llll_l1_)
	if l1l1l11lll1l_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䨐"): return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠫ䨑") in l1l1l11lll1l_l1_:
		l1l111llll1l_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࡀࠠࠡࠩ䨒")+l1l1l11lll1l_l1_
		l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠹࠭䨓")
		l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111l1l_l1_(url,source)
		l1llll_l1_ = l1l111llll11_l1_(l1llll_l1_)
		if l1l1l11lll1l_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䨔"): return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠴ࠨ䨕") in l1l1l11lll1l_l1_:
			l1l111llll1l_l1_ += l1l111_l1_ (u"ࠪࡠࡳࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠶࠽ࠤࠥ࠭䨖")+l1l1l11lll1l_l1_
			l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠷ࠪ䨗")
			l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111l11_l1_(url,source)
			l1llll_l1_ = l1l111llll11_l1_(l1llll_l1_)
			if l1l1l11lll1l_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䨘"): return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠹ࠬ䨙") in l1l1l11lll1l_l1_:
				l1l111llll1l_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠻࠺ࠡࠢࠪ䨚")+l1l1l11lll1l_l1_
	return l1l1l1l111l1_l1_,l1l111llll1l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111llll11_l1_(l1ll1111lll1_l1_):
	if l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䨛") in str(type(l1ll1111lll1_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1ll1111lll1_l1_:
			if l1l111_l1_ (u"ࠩࡶࡸࡷ࠭䨜") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡷ࠭䨝"),l1l111_l1_ (u"ࠫࠬ䨞")).replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ䨟"),l1l111_l1_ (u"࠭ࠧ䨠")).strip(l1l111_l1_ (u"ࠧࠡࠩ䨡"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1ll1111lll1_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ䨢"),l1l111_l1_ (u"ࠩࠪ䨣")).replace(l1l111_l1_ (u"ࠪࡠࡳ࠭䨤"),l1l111_l1_ (u"ࠫࠬ䨥")).strip(l1l111_l1_ (u"ࠬࠦࠧ䨦"))
	return l1ll_l1_
def l1l1l111ll1l_l1_(url,source):
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䨧"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡵࡣࡵࡸࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ䨨")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ䨩"))
	l1l1l1l111l1_l1_,l1ll1ll_l1_,l1l111llll1l_l1_ = l1l111_l1_ (u"ࠩࡌࡒ࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠭䨪"),url,l1l111_l1_ (u"ࠪࠫ䨫")
	l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll111_l1_(url,source)
	l1llll_l1_ = l1l111llll11_l1_(l1llll_l1_)
	if l1l1l11lll1l_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䨬"): return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_: l1ll1ll_l1_ = l1llll_l1_[0]
	if l1l1l11lll1l_l1_!=l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䨭"): l1l111llll1l_l1_ = l1l111_l1_ (u"࠭ࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥࠦࠧ䨮")+l1l1l11lll1l_l1_
	else:
		l1l111llll1l_l1_ = l1l111_l1_ (u"ࠧࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠵࠿ࠦࠠࡏࡧࡨࡨࠥ࡫ࡸࡵࡧࡵࡲࡦࡲࠠࡳࡧࡶࡳࡱࡼࡥࡳࡵࠪ䨯")
		l1l1l1l111l1_l1_ = l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧ䨰")
		l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1111l1_l1_(url,source)
		l1llll_l1_ = l1l111llll11_l1_(l1llll_l1_)
		if l1l1l11lll1l_l1_==l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䨱"): return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ䨲") in l1l1l11lll1l_l1_:
			l1l111llll1l_l1_ += l1l111_l1_ (u"ࠫࡡࡴࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥࠦࠧ䨳")+l1l1l11lll1l_l1_
			l1l1l1l111l1_l1_,l1l111llll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1llll1l_l1_(l1l111llll1l_l1_,l1ll1ll_l1_,source)
	if l1llll_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䨴"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩ䨵")+l1l1l1l111l1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䨶")+url+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䨷")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡶࡹࡱࡺࡳ࠻ࠢ࡞ࠤࠬ䨸")+str(l1llll_l1_)+l1l111_l1_ (u"ࠪࠤࡢ࠭䨹"))
	else: l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䨺"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䨻")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䨼")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡋࡲࡳࡱࡵࡷ࠿࡛ࠦࠡࠩ䨽")+l1l111llll1l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ䨾"))
	l1l111llll1l_l1_ = l111l11_l1_(l1l111llll1l_l1_)
	return l1l111llll1l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l11111l1ll_l1_(l1ll111l1111_l1_,source):
	l1l1l1ll111_l1_ = l1ll1ll1_l1_
	data = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䨿"),l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ䩀"),l1ll111l1111_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l1l11l1l1l_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1ll111l1111_l1_:
		if l1l111_l1_ (u"ࠫ࠴࠵ࠧ䩁") not in l1ll1ll_l1_: continue
		l1l1l1l11ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l1l111llll_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤࠬࠩ䩂"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䩃"))
		l1l1l11l1l1l_l1_.append([l1l1l1l11ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l1l11l1l1l_l1_:
		l1l111llllll_l1_ = sorted(l1l1l11l1l1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll11lll_l1_ = []
		for line in l1l111llllll_l1_:
			if line not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(line)
		for l1l1l1l11ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll11lll_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ䩄")
			title = l1l111_l1_ (u"ࠨีํีๆืࠧ䩅")+l1l111_l1_ (u"ࠩࠣࠫ䩆")+type+l1l111_l1_ (u"ࠪࠤࠬ䩇")+l1l1l1l11ll1_l1_+l1l111_l1_ (u"ࠫࠥ࠭䩈")+l111l1ll_l1_+l1l111_l1_ (u"ࠬࠦࠧ䩉")+l111lll_l1_+l1l111_l1_ (u"࠭ࠠࠨ䩊")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠧࠡࠩ䩋")+server
			title = title.replace(l1l111_l1_ (u"ࠨࠧࠪ䩌"),l1l111_l1_ (u"ࠩࠪ䩍")).strip(l1l111_l1_ (u"ࠪࠤࠬ䩎")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䩏"),l1l111_l1_ (u"ࠬࠦࠧ䩐")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䩑"),l1l111_l1_ (u"ࠧࠡࠩ䩒")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䩓"),l1l111_l1_ (u"ࠩࠣࠫ䩔"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ䩕"),l1ll111l1111_l1_,data,l1l1l1ll111_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l1l11l111l1l_l1_(url,source):
	l111l1ll1ll_l1_ = l1l111_l1_ (u"ࠫࠬ䩖")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l111l1ll1ll_l1_ = str(error)
	if not l1lll_l1_:
		if l111l1ll1ll_l1_==l1l111_l1_ (u"ࠬ࠭䩗"):
			l111l1ll1ll_l1_ = traceback.format_exc()
			sys.stderr.write(l111l1ll1ll_l1_)
		l1l1l11lll1l_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠸ࠥࡌࡡࡪ࡮ࡨࡨࠬ䩘")
		l1l1l11lll1l_l1_ += l1l111_l1_ (u"ࠧࠡࠩ䩙")+l111l1ll1ll_l1_.splitlines()[-1]
		return l1l1l11lll1l_l1_,[],[]
	return l1l111_l1_ (u"ࠨࠩ䩚"),[l1l111_l1_ (u"ࠩࠪ䩛")],[l1lll_l1_]
def l1l11l111l11_l1_(url,source):
	l111l1ll1ll_l1_ = l1l111_l1_ (u"ࠪࠫ䩜")
	l1lll_l1_ = False
	try:
		import youtube_dl
		l1l11lllll11_l1_ = youtube_dl.YoutubeDL({l1l111_l1_ (u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭䩝"): True})
		l1lll_l1_ = l1l11lllll11_l1_.extract_info(url,download=False)
	except Exception as error: l111l1ll1ll_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭䩞") not in list(l1lll_l1_.keys()):
		if l111l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠧ䩟"):
			l111l1ll1ll_l1_ = traceback.format_exc()
			sys.stderr.write(l111l1ll1ll_l1_)
		l1l1l11lll1l_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠺ࠦࡆࡢ࡫࡯ࡩࡩ࠭䩠")
		l1l1l11lll1l_l1_ += l1l111_l1_ (u"ࠨࠢࠪ䩡")+l111l1ll1ll_l1_.splitlines()[-1]
		return l1l1l11lll1l_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ䩢")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࠪ䩣")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䩤")])
		return l1l111_l1_ (u"ࠬ࠭䩥"),l1l1lll1_l1_,l1llll_l1_
def l1l11llll11l_l1_(url):
	if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䩦") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠧࠨ䩧"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡑࡇࡒࡂࡄࠪ䩨"),[],[]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䩩"),[l1l111_l1_ (u"ࠪࠫ䩪")],[url]
def l1ll11lll1l_l1_(url):
	l1ll11l1_l1_,l111llll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷ࠳ࡳࡰ࠵ࡁࡹ࡭ࡩࡃࠧ䩫") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䩬"),url,l1l111_l1_ (u"࠭ࠧ䩭"),l1l111_l1_ (u"ࠧࠨ䩮"),False,l1l111_l1_ (u"ࠨࠩ䩯"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫ䩰"))
		if l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䩱") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䩲")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䩳"))
			l111llll11_l1_.append(server)
	elif l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ䩴") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䩵"),url,l1l111_l1_ (u"ࠨࠩ䩶"),l1l111_l1_ (u"ࠩࠪ䩷"),l1l111_l1_ (u"ࠪࠫ䩸"),l1l111_l1_ (u"ࠫࠬ䩹"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠶ࡳࡪࠧ䩺"))
		html = response.content
		l1111l1llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪࠫ࠱ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭䩻"),html,re.DOTALL)
		if l1111l1llll_l1_:
			l1111l1llll_l1_ = l1111l1llll_l1_[0]
			l1lll11lllll_l1_ = l1lll1llll11_l1_(l1111l1llll_l1_)
			l1lll11l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࡟࡟࠳࠰࠿࡝࡟ࠬ࠰ࠬ䩼"),l1lll11lllll_l1_,re.DOTALL)
			if l1lll11l1lll_l1_:
				l1lll11l1lll_l1_ = l1lll11l1lll_l1_[0]
				l1lll11l1lll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䩽"),l1lll11l1lll_l1_)
				for dict in l1lll11l1lll_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠧ䩾")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ䩿")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䪀"))
					l111llll11_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"ࠬࠦࠧ䪁")+server)
		elif l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䪂") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䪃")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䪄"))
			l111llll11_l1_.append(server)
		if l1l111_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭࡯ࡰࠩ䪅") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࠩ䪆"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫ࠭䪇"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111llll11_l1_.append(l1l111_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷࠥ࡭࡯ࡰࡩ࡯ࡩࠬ䪈"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䪉"))
		l111llll11_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ䪊"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䪋"),l111llll11_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䪌"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪍"),[l1l111_l1_ (u"ࠫࠬ䪎")],[l1ll1ll_l1_]
def l1l111l1111l_l1_(url):
	headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䪏"):l1l111_l1_ (u"࠭ࡋࡰࡦ࡬࠳ࠬ䪐")+str(kodi_version)}
	for l1l111llll_l1_ in range(50):
		time.sleep(0.100)
		response = l111l1lll1l_l1_(l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䪑"),url,l1l111_l1_ (u"ࠨࠩ䪒"),headers,False,l1l111_l1_ (u"ࠩࠪ䪓"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ䪔"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䪕") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪖")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ䪗")+headers[l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䪘")]
			return l1l111_l1_ (u"ࠨࠩ䪙"),[l1l111_l1_ (u"ࠩࠪ䪚")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ䪛"),[],[]
def l1l11ll111ll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䪜"),url,l1l111_l1_ (u"ࠬ࠭䪝"),l1l111_l1_ (u"࠭ࠧ䪞"),l1l111_l1_ (u"ࠧࠨ䪟"),l1l111_l1_ (u"ࠨࠩ䪠"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨ䪡"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧ䪢"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"ࠫࠬ䪣"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠭䪤"),[],[]
def l1llll1ll11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䪥"),url,l1l111_l1_ (u"ࠧࠨ䪦"),l1l111_l1_ (u"ࠨࠩ䪧"),l1l111_l1_ (u"ࠩࠪ䪨"),l1l111_l1_ (u"ࠪࠫ䪩"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡖࡉࡑࡎࡄ࠲࠯࠴ࡷࡹ࠭䪪"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䪫"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࠧ䪬"),[l1l111_l1_ (u"ࠧࠨ䪭")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ䪮"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭䪯") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䪰"),url,l1l111_l1_ (u"ࠫࠬ䪱"),l1l111_l1_ (u"ࠬ࠭䪲"),l1l111_l1_ (u"࠭ࠧ䪳"),l1l111_l1_ (u"ࠧࠨ䪴"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨ䪵"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䪶"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䪷") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䪸"),[l1l111_l1_ (u"ࠬ࠭䪹")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨ䪺"),[],[]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䪻"),[l1l111_l1_ (u"ࠨࠩ䪼")],[url]
def l111l111ll_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䪽"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䪾"),l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䪿"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䫀")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䫁"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䫂"),l1l111_l1_ (u"ࠨࠩ䫃"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡐࡒ࡛࠲࠷ࡳࡵࠩ䫄"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫅"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡑࡓ࡜࠭䫆"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫇"),[l1l111_l1_ (u"࠭ࠧ䫈")],[l1ll1ll_l1_]
def l1ll1lll111l_l1_(url):
	headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䫉"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䫊")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䫋"),url,l1l111_l1_ (u"ࠪࠫ䫌"),headers,l1l111_l1_ (u"ࠫࠬ䫍"),l1l111_l1_ (u"ࠬ࠭䫎"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨ䫏"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䫐"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ䫑"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䫒"),[l1l111_l1_ (u"ࠪࠫ䫓")],[l1ll1ll_l1_]
def l1ll1lll1l1_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䫔"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䫕")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䫖"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䫗"),l1l111_l1_ (u"ࠨࠩ䫘"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡎࡁࡍࡃࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ䫙"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ䫚"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡈࡂࡎࡄࡇࡎࡓࡁࠨ䫛"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䫜") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䫝")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䫞"),[l1l111_l1_ (u"ࠨࠩ䫟")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䫠"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䫡")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䫢"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䫣"),l1l111_l1_ (u"࠭ࠧ䫤"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡂࡄࡇࡓ࠲࠷ࡳࡵࠩ䫥"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ䫦"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂࡃࡅࡈࡔ࠭䫧"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䫨"),[l1l111_l1_ (u"ࠫࠬ䫩")],[l1ll1ll_l1_]
def l1111llll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䫪"),url,l1l111_l1_ (u"࠭ࠧ䫫"),l1l111_l1_ (u"ࠧࠨ䫬"),l1l111_l1_ (u"ࠨࠩ䫭"),l1l111_l1_ (u"ࠩࠪ䫮"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩ䫯"))
	html = response.content
	l1l1111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ䫰"),html,re.DOTALL|re.IGNORECASE)
	if l1l1111ll111_l1_:
		l1l1111ll111_l1_ = l1l1111ll111_l1_[0][2:]
		l1l1111ll111_l1_ = base64.b64decode(l1l1111ll111_l1_)
		if PY3: l1l1111ll111_l1_ = l1l1111ll111_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䫱"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䫲"),l1l1111ll111_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࠨ䫳")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡘ࡛ࡌࡕࡏࠩ䫴"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䫵") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䫶")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䫷"),[l1l111_l1_ (u"ࠬ࠭䫸")],[l1ll1ll_l1_]
def l1l1l11lll11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䫹"),url,l1l111_l1_ (u"ࠧࠨ䫺"),l1l111_l1_ (u"ࠨࠩ䫻"),l1l111_l1_ (u"ࠩࠪ䫼"),l1l111_l1_ (u"ࠪࠫ䫽"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭䫾"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䫿"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪ䬀"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䬁"),[l1l111_l1_ (u"ࠨࠩ䬂")],[l1ll1ll_l1_]
def l1l1l111l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䬃"))[-1]
	if l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ䬄") in url: url = url.replace(l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ䬅"),l1l111_l1_ (u"ࠬ࠭䬆"))
	url = url.replace(l1l111_l1_ (u"࠭࠮ࡤࡱࡰ࠳ࠬ䬇"),l1l111_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡳࡥࡵࡣࡧࡥࡹࡧ࠯ࠨ䬈"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䬉"),url,l1l111_l1_ (u"ࠩࠪ䬊"),l1l111_l1_ (u"ࠪࠫ䬋"),l1l111_l1_ (u"ࠫࠬ䬌"),l1l111_l1_ (u"ࠬ࠭䬍"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ䬎"))
	html = response.content
	l1l1l11lll1l_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ䬏")
	error = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡶࡷࡵࡲࠣ࠰࠭ࡃࠧࡳࡥࡴࡵࡤ࡫ࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䬐"),html,re.DOTALL)
	if error: l1l1l11lll1l_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠩࡻ࠱ࡲࡶࡥࡨࡗࡕࡐࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬑"),html,re.DOTALL)
	if not url and l1l1l11lll1l_l1_:
		return l1l1l11lll1l_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠪࡠࡡ࠭䬒"),l1l111_l1_ (u"ࠫࠬ䬓"))
	l1ll1111l1l1_l1_,l1ll111l1111_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࠧࡀࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬔"),html,re.DOTALL)
	if owner: l1l11lllll1l_l1_,l1l11llll1ll_l1_,l1l1l1l1llll_l1_ = owner[0]
	else: l1l11lllll1l_l1_,l1l11llll1ll_l1_,l1l1l1l1llll_l1_ = l1l111_l1_ (u"࠭ࠧ䬕"),l1l111_l1_ (u"ࠧࠨ䬖"),l1l111_l1_ (u"ࠨࠩ䬗")
	l1l1l1l1llll_l1_ = l1l1l1l1llll_l1_.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䬘"),l1l111_l1_ (u"ࠪ࠳ࠬ䬙"))
	l1l11llll1ll_l1_ = escapeUNICODE(l1l11llll1ll_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ䬚")+l1l11llll1ll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䬛")]+l1ll1111l1l1_l1_
	l1llll_l1_ = [l1l1l1l1llll_l1_]+l1ll111l1111_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ䬜")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"ࠧࠡ็็ๅ࠮࠭䬝"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䬞"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨ䬟")+l1l1l1l1llll_l1_+l1l111_l1_ (u"ࠪࠪࡹ࡫ࡸࡵ࠿ࠪ䬠")+l1l11llll1ll_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ䬡")+new_path+l1l111_l1_ (u"ࠧ࠯ࠢ䬢"))
		return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䬣"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠧࠨ䬤"),[l1l111_l1_ (u"ࠨࠩ䬥")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䬦"),l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䬧"),l1l111_l1_ (u"ࠫࠬ䬨"),l1l111_l1_ (u"ࠬ࠭䬩"),l1l111_l1_ (u"࠭ࠧ䬪"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆࡔࡑࡒࡂ࠯࠴ࡷࡹ࠭䬫"))
	html = response.content
	if l1l111_l1_ (u"ࠨ࠰࡭ࡷࡴࡴࠧ䬬") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡷࡩࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䬭"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䬮"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡐࡍࡕࡅࠬ䬯"),[],[]
	url = url[0]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䬰") not in url: url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䬱")+url
	return l1l111_l1_ (u"ࠧࠨ䬲"),[l1l111_l1_ (u"ࠨࠩ䬳")],[url]
def l1l111ll1l1l_l1_(url):
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䬴") : l1l111_l1_ (u"ࠪࠫ䬵") }
	if l1l111_l1_ (u"ࠫࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ䬶") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䬷"),headers,l1l111_l1_ (u"࠭ࠧ䬸"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠷ࡳࡵࠩ䬹"))
		items = re.findall(l1l111_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬺"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠩࠪ䬻"),[l1l111_l1_ (u"ࠪࠫ䬼")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䬽"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䬾"),l1l111_l1_ (u"࠭ࠧ䬿"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩ䭀"),message[0])
				return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩ䭁")+message[0],[],[]
	else:
		l11111111l_l1_ = l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬ䭂")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䭃"),headers,l1l111_l1_ (u"ࠫࠬ䭄"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠶ࡳࡪࠧ䭅"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡆࡰࡴࡰࠤࡲ࡫ࡴࡩࡱࡧࡁࠧࡖࡏࡔࡖࠥࠤࡦࡩࡴࡪࡱࡱࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䭆"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ䭇"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠨ࠰ࡵࡥࡷ࠭䭈") in block or l1l111_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ䭉") in block: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠥࡔ࡯ࡵࠢࡤࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨ䭊"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䭋"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"ࠬ࠭䭌"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠸ࡸࡤࠨ䭍"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥ࡙ࠢ࡭ࡩ࡫࡯࠯ࠬࡂ࡫ࡪࡺ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡯࡭ࡢࡩࡨ࠾ࠬ䭎"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䭏"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤ࠱࠮ࡄࠨࡼࠪࠩ䭐"),block,re.DOTALL)
		l1l1l11ll111_l1_,l1l1lll1_l1_,l1l11l11lll1_l1_,l1llll_l1_,l1l11l11l1l1_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䭑") in l1ll1ll_l1_:
				l1l1l11ll111_l1_,l1l11l11lll1_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l1l11l11lll1_l1_
				if l1l1l11ll111_l1_[0]==l1l111_l1_ (u"ࠫ࠲࠷ࠧ䭒"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ䭓")+l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ䭔")+l11111111l_l1_)
				else:
					for title in l1l1l11ll111_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ䭕")+l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ䭖")+l11111111l_l1_+l1l111_l1_ (u"ࠩࠣࠫ䭗")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠪ࠰ࡱࡧࡢࡦ࡮࠽ࠦࠬ䭘"),l1l111_l1_ (u"ࠫࠬ䭙"))
				title = title.strip(l1l111_l1_ (u"ࠬࠨࠧ䭚"))
				title = l1l111_l1_ (u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤࠬ䭛")+l1l111_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭䭜")+l11111111l_l1_+l1l111_l1_ (u"ࠨࠢࠪ䭝")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ䭞") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䭟"),headers,l1l111_l1_ (u"ࠫࠬ䭠"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧ䭡"))
		items = re.findall(l1l111_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥ䭢"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫ䭣")+l1l111_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ䭤")+l11111111l_l1_+l1l111_l1_ (u"ࠩࠣࠫ䭥")+resolution.split(l1l111_l1_ (u"ࠪࡼࠬ䭦"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ䭧")+id+l1l111_l1_ (u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ䭨")+mode+l1l111_l1_ (u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭䭩")+hash
			l1l11l11l1l1_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l1l11l11l1l1_l1_ = set(l1l11l11l1l1_l1_)
		l1l11ll11l1l_l1_,l1l1l1ll1l1l_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢ䭪"),title+l1l111_l1_ (u"ࠨࠨࠩࠫ䭫"),re.DOTALL)
			for resolution in l1l11l11l1l1_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠩࡻࠫ䭬"))[1])
			l1l11ll11l1l_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦ䭭"),l1l111_l1_ (u"ࠫࠫࠬࠧ䭮")+l1l11ll11l1l_l1_[i]+l1l111_l1_ (u"ࠬࠬࠦࠨ䭯"),re.DOTALL)
			l1l1l1ll1l1l_l1_.append( [l1l11ll11l1l_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l1l1ll1l1l_l1_ = sorted(l1l1l1ll1l1l_l1_, key=lambda x: x[3], reverse=True)
		l1l1l1ll1l1l_l1_ = sorted(l1l1l1ll1l1l_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l1l1ll1l1l_l1_)):
			l1l1lll1_l1_.append(l1l1l1ll1l1l_l1_[i][0])
			l1llll_l1_.append(l1l1l1ll1l1l_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ䭰"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䭱"),l1l1lll1_l1_,l1llll_l1_
def l1l11111lll1_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠨࡁࠪ䭲"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䭳") : l1l111_l1_ (u"ࠪࠫ䭴") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䭵"),headers,l1l111_l1_ (u"ࠬ࠭䭶"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭䭷"))
	items = re.findall(l1l111_l1_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ䭸"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䭹"),[l1l111_l1_ (u"ࠩࠪ䭺")],[url]
def l1l11llll1l1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䭻") : l1l111_l1_ (u"ࠫࠬ䭼") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭䭽"),headers,l1l111_l1_ (u"࠭ࠧ䭾"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭䭿"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡹࡷࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䮀"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠩࠪ䮁"),[l1l111_l1_ (u"ࠪࠫ䮂")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧ䮃"),[],[]
def l1l1111l1l11_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䮄") : l1l111_l1_ (u"࠭ࠧ䮅") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ䮆"),headers,l1l111_l1_ (u"ࠨࠩ䮇"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ䮈"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭䮉"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠫࠬ䮊"),[l1l111_l1_ (u"ࠬ࠭䮋")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙ࠧ䮌"),[],[]
def l1lllll1111_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠧࠨ䮍")
	if l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬ䮎") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䮏"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䮐")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䮑"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䮒"),l1l111_l1_ (u"࠭ࠧ䮓"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪ䮔"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䮕")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡸࡸࡣ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝ࠨࠩࠪ䮖"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡀࠬ࠳࠰࠿ࠪࠦࠪ䮗"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠫࠬ䮘"),[l1l111_l1_ (u"ࠬ࠭䮙")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࠧ䮚") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䮛"),url,l1l111_l1_ (u"ࠨࠩ䮜"),l1l111_l1_ (u"ࠩࠪ䮝"),True,l1l111_l1_ (u"ࠪࠫ䮞"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧ䮟"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䮠") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䮡")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䮢"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䮣") in l1lllll1_l1_ or l1l111_l1_ (u"ࠩ࠲ࡪ࠴࠭䮤") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䮥"),l1l111_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ䮦"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䮧"),l1l111_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ䮨"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䮩"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䮪"),l1l111_l1_ (u"ࠩࠪ䮫"),l1l111_l1_ (u"ࠪࠫ䮬"),l1l111_l1_ (u"ࠫࠬ䮭"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠸ࡸࡤࠨ䮮"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䮯"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ䮰"),l1l111_l1_ (u"ࠨࠩ䮱"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䮲"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭䮳"),l1l111_l1_ (u"ࠫࠬ䮴"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬ࠭䮵"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䮶"),[l1l111_l1_ (u"ࠧࠨ䮷")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭䮸"),[],[]
	return l1l111_l1_ (u"ࠩࠪ䮹"),l1l1lll1_l1_,l1llll_l1_
def l1lll1l1ll11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䮺"),url,l1l111_l1_ (u"ࠫࠬ䮻"),l1l111_l1_ (u"ࠬ࠭䮼"),l1l111_l1_ (u"࠭ࠧ䮽"),l1l111_l1_ (u"ࠧࠨ䮾"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠶ࡹࡴࠨ䮿"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠩࠪ䯀")
	if l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭䯁") in url or l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ䯂") in url:
		if l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ䯃") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯄"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ䯅") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䯆"),[l1l111_l1_ (u"ࠩࠪ䯇")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䯈"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䯉"),l1l111_l1_ (u"ࠬ࠭䯊"),l1l111_l1_ (u"࠭ࠧ䯋"),l1l111_l1_ (u"ࠧࠨ䯌"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠷ࡴࡤࠨ䯍"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࡭ࡷࠬ䯎"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯏"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1llllll111l_l1_ in items:
				l1l1lll1_l1_.append(l1llllll111l_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵ࠭䯐") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡻࡲ࡭࠿ࠫ࠲࠯ࡅࠩࠣࠩ䯑"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䯒"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䯓"),l1l111_l1_ (u"ࠨࠩ䯔"),l1l111_l1_ (u"ࠩࠪ䯕"),l1l111_l1_ (u"ࠪࠫ䯖"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ䯗"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯘"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ࠧ䯙"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧ䯚") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯛"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䯜"),[l1l111_l1_ (u"ࠪࠫ䯝")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡘࡖ࠸࡚࠭䯞"),[],[]
	return l1l111_l1_ (u"ࠬ࠭䯟"),l1l1lll1_l1_,l1llll_l1_
def l1111ll11_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ䯠")][0]
	headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䯡"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䯢"),url,l1l111_l1_ (u"ࠩࠪ䯣"),headers,l1l111_l1_ (u"ࠪࠫ䯤"),l1l111_l1_ (u"ࠫࠬ䯥"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡄ࠰࠶ࡳࡪࠧ䯦"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䯧"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯨"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠣࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ䯩"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡩ࡭ࡱ࡫࠺ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ䯪"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䯫")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠫࠬ䯬"),[l1l111_l1_ (u"ࠬ࠭䯭")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧ࡞ࡴࡰ࡭ࡨࡲࠧ࠭䯮") in html:
		l1l11lll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䯯"),html,re.DOTALL)
		if l1l11lll1ll1_l1_:
			l1ll1ll_l1_ = l1l11lll1ll1_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䯰"),l1l111_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ䯱"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠲ࠧ䯲"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䯳")+l1l11l11_l1_
				return l1l111_l1_ (u"ࠬ࠭䯴"),[l1l111_l1_ (u"࠭ࠧ䯵")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䯶"),[l1l111_l1_ (u"ࠨࠩ䯷")],[url]
def l111llll1l_l1_(url):
	l111llll11_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠩ࠲࠵࠴࠭䯸") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳࠶࠵ࠧ䯹"),l1l111_l1_ (u"ࠫ࠴࠺࠯ࠨ䯺"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䯻"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䯼"),l1l111_l1_ (u"ࠧࠨ䯽"),False,l1l111_l1_ (u"ࠨࠩ䯾"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠲ࡵࡷࠫ䯿"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡩ࡫࡯࠿ࠩ䰀"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰁"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䰂"))
					l111llll11_l1_.append(server+l1l111_l1_ (u"࠭ࠠࠡࠩ䰃")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠧࠨ䰄"),l111llll11_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨ࠱ࡧ࠳ࠬ䰅") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䰆"),url,l1l111_l1_ (u"ࠪࠫ䰇"),l1l111_l1_ (u"ࠫࠬ䰈"),l1l111_l1_ (u"ࠬ࠭䰉"),l1l111_l1_ (u"࠭ࠧ䰊"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠸࡮ࡥࠩ䰋"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰌"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠩ࠲࠵࠴࠭䰍"),l1l111_l1_ (u"ࠪ࠳࠹࠵ࠧ䰎"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䰏"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䰐"),l1l111_l1_ (u"࠭ࠧ䰑"),False,l1l111_l1_ (u"ࠧࠨ䰒"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠳ࡳࡦࠪ䰓"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰔"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䰕"),[l1l111_l1_ (u"ࠫࠬ䰖")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ䰗"),[],[]
def l111ll11ll_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䰘"),url,l1l111_l1_ (u"ࠧࠨ䰙"),l1l111_l1_ (u"ࠨࠩ䰚"),l1l111_l1_ (u"ࠩࠪ䰛"),l1l111_l1_ (u"ࠪࠫ䰜"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭䰝"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰞"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"࠭࡯ࡱ࠿ࠪ䰟")+op+l1l111_l1_ (u"ࠧࠧ࡫ࡧࡁࠬ䰠")+id+l1l111_l1_ (u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩ䰡")+fname
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䰢"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䰣")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䰤"),url,data,headers,l1l111_l1_ (u"ࠬ࠭䰥"),l1l111_l1_ (u"࠭ࠧ䰦"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠸࡮ࡥࠩ䰧"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡩ࡫࡫ࡲࡦࡴࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰨"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䰩"),[l1l111_l1_ (u"ࠪࠫ䰪")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ䰫"),[],[]
def l11l11ll11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䰬"),1)[0].strip(l1l111_l1_ (u"࠭࠿ࠨ䰭")).strip(l1l111_l1_ (u"ࠧ࠰ࠩ䰮")).strip(l1l111_l1_ (u"ࠨࠨࠪ䰯"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠩࠪ䰰")
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䰱"):l1l111_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫ䰲") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䰳"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䰴"),headers,True,l1l111_l1_ (u"ࠧࠨ䰵"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩ䰶"))
	if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䰷") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䰸")]
	if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䰹") in l1llllll_l1_:
		if l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䰺") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"࠭࠯ࡧ࠱ࠪ䰻"),l1l111_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䰼"))
		l1l11ll1l1l1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪ䰽"))[1]
		headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䰾"):headers[l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䰿")] , l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䱀"):l1l111_l1_ (u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭䱁")+l1l11ll1l1l1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䱂"),l1llllll_l1_,l1l111_l1_ (u"ࠧࠨ䱃"),headers,False,l1l111_l1_ (u"ࠨࠩ䱄"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䱅"))
		html = response.content
		if l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䱆") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱇"),html,re.DOTALL)
		elif l1l111_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䱈") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱉"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠧࠨ䱊")],[ items[0] ]
		elif l1l111_l1_ (u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧ䱋") in html:
			return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬ䱌"),[],[]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭䱍"),[],[]
def l11l11l1111_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䱎"),l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䱏"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ䱐")+l11l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ䱑")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䱒"):l1l111_l1_ (u"ࠩࠪ䱓") , l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䱔"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䱕") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䱖"),headers,l1l111_l1_ (u"࠭ࠧ䱗"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭䱘"))
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䱙"),[l1l111_l1_ (u"ࠩࠪ䱚")],[l1lllll1_l1_]
def l1llll1llll1_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䱛"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䱜"):server,l1l111_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ䱝"):l1l111_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭䱞")}
	response = l11l1l_l1_(l1llll1ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱟"),url,l1l111_l1_ (u"ࠨࠩ䱠"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ䱡"),l1l111_l1_ (u"ࠪࠫ䱢"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ䱣"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭䱤"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"࠭ࠧ䱥")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱦"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䱧"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࠪ䱨"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱩"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡅࡌࡑࡆ࠭䱪"),[],[]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䱫"),[l1l111_l1_ (u"࠭ࠧ䱬")],[l1lllll1_l1_]
def l1lll11l111l_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䱭"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䱮"):server,l1l111_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ䱯"):l1l111_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ䱰")}
	response = l11l1l_l1_(l1llll1ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䱱"),url,l1l111_l1_ (u"ࠬ࠭䱲"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䱳"),l1l111_l1_ (u"ࠧࠨ䱴"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ䱵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ䱶"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠪࠫ䱷")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䱸"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ䱹"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࠧ䱺"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱻"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪ䱼"),[],[]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䱽"),[l1l111_l1_ (u"ࠪࠫ䱾")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䱿"),l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䲀"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧ䲁"):l11l1l11_l1_,l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ䲂"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䲃"),url,data,l1l111_l1_ (u"ࠩࠪ䲄"),l1l111_l1_ (u"ࠪࠫ䲅"),l1l111_l1_ (u"ࠫࠬ䲆"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ䲇"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲈"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䲉"),[l1l111_l1_ (u"ࠨࠩ䲊")],[l1lllll1_l1_]
def l11111111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䲋"),url,l1l111_l1_ (u"ࠪࠫ䲌"),l1l111_l1_ (u"ࠫࠬ䲍"),l1l111_l1_ (u"ࠬ࠭䲎"),l1l111_l1_ (u"࠭ࠧ䲏"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳࠱ࡴࡶࠪ䲐"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䲑"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䲒"),[l1l111_l1_ (u"ࠪࠫ䲓")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ䲔"),[],[]
def l11111l1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲕"),url,l1l111_l1_ (u"࠭ࠧ䲖"),l1l111_l1_ (u"ࠧࠨ䲗"),l1l111_l1_ (u"ࠨࠩ䲘"),l1l111_l1_ (u"ࠩࠪ䲙"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬ䲚"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲛"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䲜"),[l1l111_l1_ (u"࠭ࠧ䲝")],[l1ll1ll_l1_]
def l1lllllll1_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䲞"))
	if l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ䲟") in url:
		headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䲠"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䲡"),url,l1l111_l1_ (u"ࠫࠬ䲢"),headers,l1l111_l1_ (u"ࠬ࠭䲣"),l1l111_l1_ (u"࠭ࠧ䲤"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ䲥"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲦"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䲧") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ䲨"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ䲩"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲪"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䲫"),headers,l1l111_l1_ (u"ࠧࠨ䲬"),l1l111_l1_ (u"ࠨࠩ䲭"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ䲮"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䲯"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䲰"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䲱")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"࠭ࠧ䲲"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䲳"),[l1l111_l1_ (u"ࠨࠩ䲴")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䲵")+l11l11111_l1_
	return l1l111_l1_ (u"ࠪࠫ䲶"),[l1l111_l1_ (u"ࠫࠬ䲷")],[l1lllll1_l1_]
def l1l11l1llll1_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䲸"))
	if l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭䲹") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䲺"),l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䲻"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠩ࡬ࡨࠬ䲼"):l11l1l11_l1_,l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ䲽"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䲾"),url,data,l1l111_l1_ (u"ࠬ࠭䲿"),l1l111_l1_ (u"࠭ࠧ䳀"),l1l111_l1_ (u"ࠧࠨ䳁"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ䳂"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳃"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䳄") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䳅"):l11l11111_l1_,l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䳆"):l1l111_l1_ (u"࠭ࠧ䳇")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䳈"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䳉"),headers,l1l111_l1_ (u"ࠩࠪ䳊"),l1l111_l1_ (u"ࠪࠫ䳋"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ䳌"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䳍"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䳎"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䳏")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠨࠩ䳐"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䳑"),[l1l111_l1_ (u"ࠪࠫ䳒")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䳓")+l11l11111_l1_
		return l1l111_l1_ (u"ࠬ࠭䳔"),[l1l111_l1_ (u"࠭ࠧ䳕")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ䳖") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䳗"),l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䳘"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䳙"))
		url = host+l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䳚")+l11l1l11_l1_+l1l111_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ䳛")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䳜"):l1l111_l1_ (u"ࠧࠨ䳝") , l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䳞"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䳟") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䳠"),headers,l1l111_l1_ (u"ࠫࠬ䳡"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ䳢"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ䳣"),l1l111_l1_ (u"ࠧࠨ䳤")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ䳥"),l1l111_l1_ (u"ࠩࠪ䳦"))
		return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䳧"),[l1l111_l1_ (u"ࠫࠬ䳨")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ䳩") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ䳪") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䳫"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䳬"),l1l111_l1_ (u"ࠩࠪ䳭"),l1l111_l1_ (u"ࠪࠫ䳮"),l1l111_l1_ (u"ࠫࠬ䳯"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠶ࡳࡪࠧ䳰"))
			if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䳱") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䳲")]
			counts += 1
		return l1l111_l1_ (u"ࠨࠩ䳳"),[l1l111_l1_ (u"ࠩࠪ䳴")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧ䳵"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䳶"))
	headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䳷"):server,l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䳸"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ䳹") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ䳺"),headers,l1l111_l1_ (u"ࠩࠪ䳻"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ䳼"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䳽"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ䳾"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䳿"))
			return l1l111_l1_ (u"ࠧࠨ䴀"),[l1l111_l1_ (u"ࠨࠩ䴁")],[l1ll1ll_l1_]
	else:
		l1l1l11l111l_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䴂"),url,l1l111_l1_ (u"ࠪࠫ䴃"),headers,l1l111_l1_ (u"ࠫࠬ䴄"),l1l111_l1_ (u"ࠬ࠭䴅"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨ䴆"))
		html = l1l1l11l111l_l1_.content
		l1ll1ll1l_l1_ = headers.copy()
		if l1l111_l1_ (u"ࠧࡠ࡮ࡱ࡯ࡤ࠭䴇") in str(l1l1l11l111l_l1_.cookies):
			cookies = l1l1l11l111l_l1_.cookies
			l1ll1ll1l_l1_[l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䴈")] = l111l11_l1_(l1lllll11_l1_(cookies))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ䴉"),html,re.DOTALL)
		if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䴊"),[l1l111_l1_ (u"ࠫࠬ䴋")],[url]
		else:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠬࠬࡤ࠾࠳ࠪ䴌")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䴍"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䴎"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䴏"),l1l111_l1_ (u"ࠩࠪ䴐"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠶ࡷ࡬ࠬ䴑"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡤࡷࡲࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䴒"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				if l1l111_l1_ (u"ࠬࡳࡰ࠵ࠩ䴓") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭࠯ࡥ࠱ࠪ䴔") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࠨ䴕"),[l1l111_l1_ (u"ࠨࠩ䴖")],[l1ll1ll_l1_]
				else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䴗"),[l1l111_l1_ (u"ࠪࠫ䴘")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ䴙"),[],[]
def l1lll111l1ll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠬࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠩ䴚") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䴛"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䴜")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䴝"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䴞"),headers,l1l111_l1_ (u"ࠪࠫ䴟"),l1l111_l1_ (u"ࠫࠬ䴠"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧ䴡"))
		url = response.content
		if url: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䴢"),[l1l111_l1_ (u"ࠧࠨ䴣")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䴤"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠩࡢࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ䴥"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䴦"))
		url = server+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡷ࡬ࡪࡳࡥ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䴧")
		data = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ䴨"):l11l1l11_l1_,l1l111_l1_ (u"࠭ࡩࠨ䴩"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䴪"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䴫"),l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䴬"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䴭"),url,data,headers,l1l111_l1_ (u"ࠫࠬ䴮"),l1l111_l1_ (u"ࠬ࠭䴯"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠷ࡴࡤࠨ䴰"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䴱"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䴲"),[l1l111_l1_ (u"ࠩࠪ䴳")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡂࡊࡌࡈ࠹࡛ࠧ䴴"),[],[]
def l1l1l111l1l1_l1_(l1l1111ll1l1_l1_):
	l1l1l11ll11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬ䴵"))
	headers = {l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䴶"):l1l1l11ll11l_l1_} if l1l1l11ll11l_l1_ else l1l111_l1_ (u"࠭ࠧ䴷")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䴸"),l1l1111ll1l1_l1_,l1l111_l1_ (u"ࠨࠩ䴹"),headers,l1l111_l1_ (u"ࠩࠪ䴺"),l1l111_l1_ (u"ࠪࠫ䴻"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠲ࡵࡷࠫ䴼"))
	l1l11l1l11ll_l1_ = response.content
	l1l1l1l1111l_l1_ = str(response.headers)
	l1l11111llll_l1_ = l1l1l1l1111l_l1_+l1l11l1l11ll_l1_
	if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䴽") in l1l11111llll_l1_: found = True
	else:
		l1ll1l11l11l_l1_,token,l1l1111l11ll_l1_,l1l11l111ll1_l1_,found = l1l111_l1_ (u"࠭ࠧ䴾"),l1l111_l1_ (u"ࠧࠨ䴿"),l1l111_l1_ (u"ࠨࠩ䵀"),l1l111_l1_ (u"ࠩࠪ䵁"),False
		l1l111ll11ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䵂"),l1l11l1l11ll_l1_,re.DOTALL)
		if l1l111ll11ll_l1_: l1l1111l11ll_l1_,l1l11l111ll1_l1_ = l1l111ll11ll_l1_[0]
		l1l111ll1l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䵃")][7]
		l1l111llll1_l1_ = l1l1ll11l11_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵄"):l1l111llll1_l1_,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵅"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵆"):l1l1111ll1l1_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵇"):l1l11l111ll1_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䵈"):l1l111_l1_ (u"ࠪࠫ䵉"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵊"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭䵋")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵌"),l1l111ll1l11_l1_,data,l1l111_l1_ (u"ࠧࠨ䵍"),l1l111_l1_ (u"ࠨࠩ䵎"),l1l111_l1_ (u"ࠩࠪ䵏"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠲࡯ࡦࠪ䵐"))
			html = response.content
		html = l1l111_l1_ (u"ࠫࠬ䵑")
		if html.startswith(l1l111_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ䵒")):
			l1ll1111lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䵓"),html.split(l1l111_l1_ (u"ࠧࡖࡔࡏࡗࡂ࠭䵔"),1)[1])
			for request in l1ll1111lll1_l1_:
				url = request[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵕")]
				method = request[l1l111_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࠩ䵖")]
				data = request[l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ䵗")]
				headers = request[l1l111_l1_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬ䵘")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠬ࠭䵙"),l1l111_l1_ (u"࠭ࠧ䵚"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ䵛"))
				l1l11l1l11ll_l1_ = response.content
				if l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䵜") in l1l11l1l11ll_l1_:
					found = True
					break
				l1l1l1l1111l_l1_ = str(response.headers)
				l1l11111llll_l1_ = l1l1l1l1111l_l1_+l1l11l1l11ll_l1_
				l1ll1l11l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ䵝"),l1l11111llll_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫ䵞"),l1l11111llll_l1_,re.DOTALL)
				if token: token = token[0]
				if l1ll1l11l11l_l1_ or token: break
		if not found:
			if not l1ll1l11l11l_l1_:
				if not token and l1l111ll11ll_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠫࡎࡊ࠽ࠨ䵟")):
						data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵠"):l1l111llll1_l1_,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵡"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵢"):l1l1111ll1l1_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵣"):l1l11l111ll1_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䵤"):l1l111_l1_ (u"ࠪࠫ䵥"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵦"):l1l111_l1_ (u"ࠬ࡭ࡥࡵ࡫ࡧࠫ䵧")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵨"),l1l111ll1l11_l1_,data,l1l111_l1_ (u"ࠧࠨ䵩"),l1l111_l1_ (u"ࠨࠩ䵪"),l1l111_l1_ (u"ࠩࠪ䵫"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠴ࡵࡪࠪ䵬"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠫࡎࡊ࠽࠲࠴࠶࠸࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿࠷࠹ࠬ䵭")
					if html.startswith(l1l111_l1_ (u"ࠬࡏࡄ࠾ࠩ䵮")):
						l1l1111l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡉࡅ࠿ࠫ࠲࠯ࡅࠩ࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠮࠮ࠫࡁࠬࠨࠬ䵯"),html,re.DOTALL)
						l1l1l1ll111l_l1_,l1l111l11l1_l1_ = l1l1111l1lll_l1_[0]
						message = l1l111_l1_ (u"่ࠧา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤํ่สࠡ็้ࠤ࠶࠶ࠠฦๆ์ࠤࠬ䵰")+l1l111l11l1_l1_+l1l111_l1_ (u"ࠨࠢฮห๋๐ษࠨ䵱")
						l1l1111lll_l1_ = l1l111lll1_l1_()
						l1l1111lll_l1_.create(l1l111_l1_ (u"่ࠩัฬ๎ไสࠢอะฬ๎าࠡใะูࠥษๆศࠢฦุ๊อๆ๊ࠡ็ืฯࠦศา่ส้ัࠦใ้็ห๎ํะัࠨ䵲"),message)
						t1 = time.time()
						l1l11l1ll11l_l1_,l1l111l1l111_l1_ = 0,0
						while l1l11l1ll11l_l1_<int(l1l111l11l1_l1_):
							l1l1111l11_l1_(l1l1111lll_l1_,int(l1l11l1ll11l_l1_/int(l1l111l11l1_l1_)*100),message,l1l111_l1_ (u"ࠪࠫ䵳"),l1l111l11l1_l1_+l1l111_l1_ (u"ࠫࠥ࠵ࠠࠨ䵴")+str(int(l1l11l1ll11l_l1_))+l1l111_l1_ (u"ࠬࠦࠠฬษ้๎ฮ࠭䵵"))
							if l1l11l1ll11l_l1_>l1l111l1l111_l1_+10:
								data = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ䵶"):l1l111llll1_l1_,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䵷"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵸"):l1l1111ll1l1_l1_,l1l111_l1_ (u"ࠩ࡮ࡩࡾ࠭䵹"):l1l11l111ll1_l1_,l1l111_l1_ (u"ࠪ࡭ࡩ࠭䵺"):l1l1l1ll111l_l1_,l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵻"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡶࡲ࡯ࡪࡴࠧ䵼")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵽"),l1l111ll1l11_l1_,data,l1l111_l1_ (u"ࠧࠨ䵾"),l1l111_l1_ (u"ࠨࠩ䵿"),l1l111_l1_ (u"ࠩࠪ䶀"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ䶁"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"࡙ࠫࡕࡋࡆࡐࡀࠫ䶂")):
									token = html.split(l1l111_l1_ (u"࡚ࠬࡏࡌࡇࡑࡁࠬ䶃"),1)[1]
									break
								l1l111l1l111_l1_ = l1l11l1ll11l_l1_
							else: time.sleep(1)
							l1l11l1ll11l_l1_ = time.time()-t1
						l1l1111lll_l1_.close()
				if token:
					l1l1111ll11l_l1_ = response.cookies
					l1ll11ll1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭䶄"),l1l11111llll_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ䶅") in list(l1l1111ll11l_l1_.keys()): l1ll11ll1111_l1_ = l1l1111ll11l_l1_[l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ䶆")]
					elif l1ll11ll1111_l1_: l1ll11ll1111_l1_ = l1ll11ll1111_l1_[0]
					l1l111ll11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䶇"),l1l11l1l11ll_l1_,re.DOTALL)
					if l1l111ll11ll_l1_: l1l1111l11ll_l1_,l1l11l111ll1_l1_ = l1l111ll11ll_l1_[0]
					if l1ll11ll1111_l1_ and l1l111ll11ll_l1_:
						headers = {l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䶈"):l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬ䶉")+l1ll11ll1111_l1_,l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䶊"):l1l1111ll1l1_l1_,l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䶋"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䶌")}
						data = l1l111_l1_ (u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ䶍")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䶎"),l1l1111l11ll_l1_,data,headers,False,l1l111_l1_ (u"ࠪࠫ䶏"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫ䶐"))
						l1l11l1l11ll_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l1ll1l11l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ䶑"),str(cookies),re.DOTALL)
			if l1ll1l11l11l_l1_:
				name,l1ll1l11l11l_l1_ = l1ll1l11l11l_l1_[0]
				l1l1l11ll11l_l1_ = name+l1l111_l1_ (u"࠭࠽ࠨ䶒")+l1ll1l11l11l_l1_
				settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ䶓"),l1l1l11ll11l_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䶔"),l1l111_l1_ (u"ࠩࠪ䶕"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䶖"),l1l111_l1_ (u"๋ࠫาอหࠢ฼้้๐ษࠡใะูࠥษๆศࠢศุ๊อๆࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอิา็้ࠢฮฬฬฬ้ࠡำหࠥอไโฯุࠤ้้๊ࠡ์ึฮำีๅ่ษ่ࠣฬำโศࠢ࠱࠲ࠥ๎ไศࠢอ์ัีࠠฮษฯอ๊ࠥลฺษาอࠥํะศࠢส่ๆำีࠡๆ฼ำฮࠦรี้ิࠤࡡࡴ࡜࡯ࠢ฼่๊อࠠฤ่๋ࠣีอࠠศๆไัฺࠦำ้ใࠣ๎ฯ้ัาࠢไ๎ࠥำวๅหࠣฮ฿๐ัࠡำห฻ࠥอไอ้สึࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠฦูไหฦࠦัศ๊อีࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦแึๆࠣื้้ࠠศๆิหํะัࠡ࠰࠱ࠤศ๎ࠠศีอาิอๅࠡࡘࡓࡒࠥษ่ࠡสิ์ู่๊ࠨ䶗"))
				if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䶘") not in l1l11l1l11ll_l1_:
					headers = {l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭䶙"):l1l1l11ll11l_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䶚"),l1l1111ll1l1_l1_,l1l111_l1_ (u"ࠨࠩ䶛"),headers,l1l111_l1_ (u"ࠩࠪ䶜"),l1l111_l1_ (u"ࠪࠫ䶝"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫ䶞"))
					l1l11l1l11ll_l1_ = response.content
	if not found and not l1l1l11ll11l_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䶟"),l1l111_l1_ (u"࠭ࠧ䶠"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䶡"),l1l111_l1_ (u"ࠨ฻่่๏ฯࠠโฯุࠤศ์วࠡล้ืฬ์ࠠโึ็ฮࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨ䶢"))
	return l1l11l1l11ll_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111llll11_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䶣"),url,l1l111_l1_ (u"ࠪࠫ䶤"),l1l111_l1_ (u"ࠫࠬ䶥"),l1l111_l1_ (u"ࠬ࠭䶦"),l1l111_l1_ (u"࠭ࠧ䶧"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭䶨"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ䶩"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭䶪"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ䶫") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ䶬") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭䶭"),l1l111_l1_ (u"࠭ࠧ䶮")).replace(l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䶯"),l1l111_l1_ (u"ࠨࠩ䶰")).strip(l1l111_l1_ (u"ࠩࠣࠫ䶱")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䶲"),l1l111_l1_ (u"ࠫࠥ࠭䶳"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111llll11_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬ䶴"),l111llll11_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ䶵"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䶶"),[],[]
	l1l1111ll1l1_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l1l11l1l11ll_l1_ = l1l1l111l1l1_l1_(l1l1111ll1l1_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䶷"):
		l1l1l1111111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䶸"),l1l11l1l11ll_l1_,re.DOTALL)
		if l1l1l1111111_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l1l1111111_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ䶹"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䶺"),l1l11l1l11ll_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭䶻"),[],[]
	return l1l111_l1_ (u"࠭ࠧ䶼"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䶽"),url,l1l111_l1_ (u"ࠨࠩ䶾"),l1l111_l1_ (u"ࠩࠪ䶿"),True,l1l111_l1_ (u"ࠪࠫ䷀"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠱ࡴࡶࠪ䷁"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ䷂") in list(cookies.keys()):
		l1l1l11ll11l_l1_ = cookies[l1l111_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭䷃")]
		l1l1l11ll11l_l1_ = l111l11_l1_(escapeUNICODE(l1l1l11ll11l_l1_))
		items = re.findall(l1l111_l1_ (u"ࠧࡳࡱࡸࡸࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷄"),l1l1l11ll11l_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ䷅"),l1l111_l1_ (u"ࠩ࠲ࠫ䷆"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ䷇") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠫࠪ࠸ࡆࠨ䷈"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡡࡵࡥ࡫࠲࡮ࡹ࠯ࠨ䷉")+id
		return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䷊"),[l1l111_l1_ (u"ࠧࠨ䷋")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䷌")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䷍"),l1l11l11_l1_,l1l111_l1_ (u"ࠪࠫ䷎"),l1l111_l1_ (u"ࠫࠬ䷏"),True,l1l111_l1_ (u"ࠬ࠭䷐"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬ䷑"))
		l1l1l11llll1_l1_ = response.url
		l1l1l1l1lll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䷒"))[2]
		l1l1l1lll1ll_l1_ = l1l1l11llll1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ䷓"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l1l1l1lll1_l1_,l1l1l1lll1ll_l1_)
		headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䷔"):l1l111_l1_ (u"ࠪࠫ䷕") , l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䷖"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䷗") , l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䷘"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䷙"), l1llllll_l1_, l1l111_l1_ (u"ࠨࠩ䷚"), headers, False,l1l111_l1_ (u"ࠩࠪ䷛"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠹ࡲࡥࠩ䷜"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䷝"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷞"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"࠭࠼ࡦ࡯ࡥࡩࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷟"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ䷠"),l1l111_l1_ (u"ࠨ࠱ࠪ䷡"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠩ࠲ࠫ䷢"))
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䷣") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䷤") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䷥"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ䷦"))
			if name==l1l111_l1_ (u"ࠧࠨ䷧"): l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ䷨"),[l1l111_l1_ (u"ࠩࠪ䷩")],[l1ll1ll_l1_]
			else: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䷪"),[l1l111_l1_ (u"ࠫࠬ䷫")],[l1ll1ll_l1_]
		else: l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭䷬"),[],[]
		return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111l1l1ll_l1_(url):
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䷭") : l1l111_l1_ (u"ࠧࠨ䷮") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ䷯"),headers,l1l111_l1_ (u"ࠩࠪ䷰"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ䷱"))
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䷲"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠬ࠭䷳")
	if items:
		for l1ll1ll_l1_,l1llllll111l_l1_ in items:
			l1l1lll1_l1_.append(l1llllll111l_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓࠬ䷴"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䷵"),l1l1lll1_l1_,l1llll_l1_
def l1l11ll111l1_l1_(url):
	headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䷶"):l1l111_l1_ (u"ࠩࠪ䷷")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䷸"),headers,l1l111_l1_ (u"ࠫࠬ䷹"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡔࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ䷺"))
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫ䷻"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䷼")+url
		return l1l111_l1_ (u"ࠨࠩ䷽"),[l1l111_l1_ (u"ࠩࠪ䷾")],[url]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡑࡍࡑࡄࡈࠬ䷿"),[],[]
def l1l11l1l1l11_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠫ࠴࠭一"))
	if l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭丁") in url: id = url.split(l1l111_l1_ (u"࠭࠯ࠨ丂"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ七"))[-1]
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡧࡸࡺࡲࡦࡣࡰ࠲ࡹࡵ࠯ࡱ࡮ࡤࡽࡪࡸ࠿ࡧ࡫ࡧࡁࠬ丄") + id
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭丅") : l1l111_l1_ (u"ࠪࠫ丆") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ万"),headers,l1l111_l1_ (u"ࠬ࠭丈"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ三"))
	html = html.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ上"),l1l111_l1_ (u"ࠨࠩ下"))
	items = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ丌"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ不"),[l1l111_l1_ (u"ࠫࠬ与")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡅࡖࡘࡗࡋࡁࡎࠩ丏"),[],[]
def l1l11l111111_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ丐"),l1l111_l1_ (u"ࠧࠨ丑"),l1l111_l1_ (u"ࠨࠩ丒"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩ专"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ且"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1llllll111l_l1_,res in items:
		l1l1lll1_l1_.append(l1llllll111l_l1_+l1l111_l1_ (u"ࠫࠥ࠭丕")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧ世"),[],[]
	return l1l111_l1_ (u"࠭ࠧ丗"),l1l1lll1_l1_,l1llll_l1_
def l1l11ll1ll11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ丘"),l1l111_l1_ (u"ࠨࠩ丙"),l1l111_l1_ (u"ࠩࠪ业"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ丛"))
	items = re.findall(l1l111_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ东"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1llllll111l_l1_,res in items:
		url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ丝")+id+l1l111_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭丞")+mode+l1l111_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ丟")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ丠"),l1l111_l1_ (u"ࠩࠪ両"),l1l111_l1_ (u"ࠪࠫ丢"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ丣"))
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ两"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1llllll111l_l1_+l1l111_l1_ (u"࠭ࠠࠨ严")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭並"),[],[]
	return l1l111_l1_ (u"ࠨࠩ丧"),l1l1lll1_l1_,l1llll_l1_
def l1l111ll11l1_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠩࠪ丨")
	if 1 or l1l111_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ丩") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ个"),l1l111_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ丫"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ丬"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ中").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ丮"):id,l1l111_l1_ (u"ࠩࡲࡴࠬ丯"):l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭丰"),l1l111_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ丱"):l1l111_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ串")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ丳"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠧࠨ临"),l1l111_l1_ (u"ࠨࠩ丵"),l1l111_l1_ (u"ࠩࠪ丶"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ丷"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭丸") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ丹")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ为"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ主"),url,l1l111_l1_ (u"ࠨࠩ丼"),l1l111_l1_ (u"ࠩࠪ丽"),l1l111_l1_ (u"ࠪࠫ举"),l1l111_l1_ (u"ࠫࠬ丿"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠳ࡰࡧࠫ乀"))
		if l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ乁") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ乂")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࠩ乃"),[l1l111_l1_ (u"ࠩࠪ乄")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫ久"),[],[]
def l1l11l1ll1l1_l1_(url):
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ乆") : l1l111_l1_ (u"ࠬ࠭乇") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ么"),headers,l1l111_l1_ (u"ࠧࠨ义"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ乊"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨ之"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠧ乌"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ乍"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠬ࠭乎"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪ乏"),[],[]
def l11lll1l1l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ乐"))[-1]
	id = id.split(l1l111_l1_ (u"ࠨࠨࠪ乑"))[0]
	id = id.replace(l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ乒"),l1l111_l1_ (u"ࠪࠫ乓"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ乔")][0]+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ乕")+id
	l1l111lll111_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩ乖")+id
	l1l1l111ll11_l1_,l1l111lllll1_l1_,l1l11lll11ll_l1_,l1l11l1l11l1_l1_ = l1l111_l1_ (u"ࠧࠨ乗"),l1l111_l1_ (u"ࠨࠩ乘"),l1l111_l1_ (u"ࠩࠪ乙"),l1l111_l1_ (u"ࠪࠫ乚")
	for l1l111llll_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ乛"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭乜"),l1l111_l1_ (u"࠭ࠧ九"),l1l111_l1_ (u"ࠧࠨ乞"),l1l111_l1_ (u"ࠨࠩ也"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ习"))
		html = response.content
		if l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ乡") in html: break
		time.sleep(2)
	l1l11lllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ乢"),html,re.DOTALL)
	if l1l11lllll_l1_: l1l11lllll_l1_ = l1l11lllll_l1_[0]
	else: l1l11lllll_l1_ = html
	l1l11lllll_l1_ = l1l11lllll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭乣"),l1l111_l1_ (u"࠭ࠦࠨ乤"))
	l1l1l11lllll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ乥"),l1l11lllll_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬ书")],[l1l111_l1_ (u"ࠩࠪ乧")]
	try:
		l1l1l1lll11l_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ乨")][l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ乩")][l1l111_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ乪")]
		for l1l11ll1l11l_l1_ in l1l1l1lll11l_l1_:
			l1ll1ll_l1_ = l1l11ll1l11l_l1_[l1l111_l1_ (u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ乫")]
			try: title = l1l11ll1l11l_l1_[l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ乬")][l1l111_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬ乭")]
			except: title = l1l11ll1l11l_l1_[l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ乮")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ乯")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ买")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ乱"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ乲"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠧࠧࠩ乳")
			l1l11l1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭乴"),l1ll1ll_l1_)
			if l1l11l1lll1l_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l11l1lll1l_l1_[0],l1l111_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ乵"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ乶")
			l1l1l111ll11_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭乷"))
	formats,l1l1l1l11111_l1_,l1l111l1lll1_l1_,l1l111l1llll_l1_,l1l111l1ll1l_l1_ = [],[],[],[],[]
	try: l1l111lllll1_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ乸")][l1l111_l1_ (u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ乹")]
	except: pass
	try: l1l11lll11ll_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ乺")][l1l111_l1_ (u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ乻")]
	except: pass
	try: formats = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ乼")][l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ乽")]
	except: pass
	try: l1l1l1l11111_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ乾")][l1l111_l1_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧ乿")]
	except: pass
	l1l1l111l1ll_l1_ = formats+l1l1l1l11111_l1_
	for dict in l1l1l111l1ll_l1_:
		if l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ亀") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ亁")] = str(dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭亂")])
		if l1l111_l1_ (u"ࠩࡩࡴࡸ࠭亃") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ亄")] = str(dict[l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ亅")])
		if l1l111_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ了") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ亇")] = dict[l1l111_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ予")]
		if l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ争") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭亊")] = str(dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ事")])
		if l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ二") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亍")] = str(dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭于")])
		if l1l111_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭亏") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭亐")] = str(dict[l1l111_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ云")])+l1l111_l1_ (u"ࠪࡼࠬ互")+str(dict[l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ亓")])
		if l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ五") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ井")] = dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ亖")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ亗")]+l1l111_l1_ (u"ࠩ࠰ࠫ亘")+dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭亙")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ亚")]
		if l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ些") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ亜")] = dict[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ亝")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ亞")]+l1l111_l1_ (u"ࠩ࠰ࠫ亟")+dict[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ亠")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ亡")]
		if l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭亢") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ亣")] = dict[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ交")]
		if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ亥") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ亦")])>111222333: del dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ产")]
		if l1l111_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭亨") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ亩")].split(l1l111_l1_ (u"࠭ࠦࠨ亪"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ享"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠨࡷࡵࡰࠬ京") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭亭")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ亮")])
		l1l111l1lll1_l1_.append(dict)
	l1l11lll1lll_l1_ = l1l111_l1_ (u"ࠫࠬ亯")
	if l1l111_l1_ (u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ亰") in l1l11lllll_l1_:
		l1l1l11l1l11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ亱"),html,re.DOTALL)
		if l1l1l11l1l11_l1_:
			l1l1l11l1l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ亲")][0]+l1l1l11l1l11_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ亳"),l1l1l11l1l11_l1_,l1l111_l1_ (u"ࠩࠪ亴"),l1l111_l1_ (u"ࠪࠫ亵"),l1l111_l1_ (u"ࠫࠬ亶"),l1l111_l1_ (u"ࠬ࠭亷"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ亸"))
			l1l11lll1lll_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1l1111lll1l_l1_ = cipher._load_javascript(l1l11lll1lll_l1_)
			l1l111lll1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ亹"),str(l1l1111lll1l_l1_))
			l1l1111lllll_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1l111lll1ll_l1_)
	for dict in l1l111l1lll1_l1_:
		url = dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ人")]
		if l1l111_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭亻") in url or url.count(l1l111_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ亼"))>1:
			l1l111l1llll_l1_.append(dict)
		elif l1l11lll1lll_l1_ and l1l111_l1_ (u"ࠫࡸ࠭亽") in list(dict.keys()) and l1l111_l1_ (u"ࠬࡹࡰࠨ亾") in list(dict.keys()):
			l1l11ll11ll1_l1_ = l1l1111lllll_l1_.execute(dict[l1l111_l1_ (u"࠭ࡳࠨ亿")])
			if l1l11ll11ll1_l1_!=dict[l1l111_l1_ (u"ࠧࡴࠩ什")]:
				dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仁")] = url+l1l111_l1_ (u"ࠩࠩࠫ仂")+dict[l1l111_l1_ (u"ࠪࡷࡵ࠭仃")]+l1l111_l1_ (u"ࠫࡂ࠭仄")+l1l11ll11ll1_l1_
				l1l111l1llll_l1_.append(dict)
	for dict in l1l111l1llll_l1_:
		l111lll_l1_,l1l111l11l1l_l1_,l1l1l1ll1ll1_l1_,l1l1l1ll1_l1_,codecs,l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭仅"),l1l111_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ仆"),l1l111_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ仇"),l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ仈"),l1l111_l1_ (u"ࠩࠪ仉"),l1l111_l1_ (u"ࠪ࠴ࠬ今")
		try:
			l1l111l1l11l_l1_ = dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ介")]
			l1l111l1l11l_l1_ = l1l111l1l11l_l1_.replace(l1l111_l1_ (u"ࠬ࠱ࠧ仌"),l1l111_l1_ (u"࠭ࠧ仍"))
			items = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ从"),l1l111l1l11l_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l1l11l11l1_l1_ = codecs.split(l1l111_l1_ (u"ࠨ࠮ࠪ仏"))
			l1l111l11l1l_l1_ = l1l111_l1_ (u"ࠩࠪ仐")
			for item in l1l1l11l11l1_l1_: l1l111l11l1l_l1_ += item.split(l1l111_l1_ (u"ࠪ࠲ࠬ仑"))[0]+l1l111_l1_ (u"ࠫ࠱࠭仒")
			l1l111l11l1l_l1_ = l1l111l11l1l_l1_.strip(l1l111_l1_ (u"ࠬ࠲ࠧ仓"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ仔") in list(dict.keys()): l11ll1l11ll_l1_ = str(float(dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ仕")]*10)//1024/10)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ他")
			else: l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠩࠪ仗")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨ付"): continue
			elif l1l111_l1_ (u"ࠫ࠱࠭仙") in l1l111l1l11l_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ仚")
				l1l1l1ll1ll1_l1_ = l111lll_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ仛")+l11ll1l11ll_l1_+dict[l1l111_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ仜")].split(l1l111_l1_ (u"ࠨࡺࠪ仝"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ仞"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ仟")
				l1l1l1ll1ll1_l1_ = l11ll1l11ll_l1_+dict[l1l111_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ仠")].split(l1l111_l1_ (u"ࠬࡾࠧ仡"))[1]+l1l111_l1_ (u"࠭ࠠࠡࠩ仢")+dict[l1l111_l1_ (u"ࠧࡧࡲࡶࠫ代")]+l1l111_l1_ (u"ࠨࡨࡳࡷࠬ令")+l1l111_l1_ (u"ࠩࠣࠤࠬ以")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ仦"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ仧")
				l1l1l1ll1ll1_l1_ = l11ll1l11ll_l1_+str(int(dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ仨")])/1000)+l1l111_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ仩")+dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ仪")]+l1l111_l1_ (u"ࠨࡥ࡫ࠫ仫")+l1l111_l1_ (u"ࠩࠣࠤࠬ们")+l111lll_l1_
		except:
			l111l1ll1ll_l1_ = traceback.format_exc()
			sys.stderr.write(l111l1ll1ll_l1_)
		if l1l111_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ仭") in dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ仮")]: l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ仯")].split(l1l111_l1_ (u"࠭ࡤࡶࡴࡀࠫ仰"),1)[1].split(l1l111_l1_ (u"ࠧࠧࠩ仱"),1)[0]))
		elif l1l111_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ仲") in list(dict.keys()): l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ仳")])/1000)
		else: l1l1lll111_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ仴")
		if l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ仵") not in list(dict.keys()): l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠬࡹࡩࡻࡧࠪ件")].split(l1l111_l1_ (u"࠭ࡸࠨ价"))[1]
		else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ仸")]
		if l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭仹") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ仺")] = l1l111_l1_ (u"ࠪ࠴࠲࠶ࠧ任")
		dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ仼")] = l1l1l1ll1_l1_+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ份")+l1l1l1ll1ll1_l1_+l1l111_l1_ (u"࠭ࠠࠡࠪࠪ仾")+l1l111l11l1l_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ仿")+dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭伀")]+l1l111_l1_ (u"ࠩࠬࠫ企")
		dict[l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ伂")] = l1l1l1ll1ll1_l1_.split(l1l111_l1_ (u"ࠫࠥࠦࠧ伃"))[0].split(l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ伄"))[0]
		dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伅")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伆")] = l111lll_l1_
		dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ伇")] = codecs
		dict[l1l111_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ伈")] = l1l1lll111_l1_
		dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ伉")] = l11ll1l11ll_l1_
		l1l111l1ll1l_l1_.append(dict)
	l1l1l111l111_l1_,l1l11l1ll1ll_l1_,l1l1l1l1ll11_l1_,l1l1l1ll11l1_l1_,l1l1111l1111_l1_ = [],[],[],[],[]
	l1l1l11l11ll_l1_,l1l111ll1lll_l1_,l1l111lll1l1_l1_,l1l1l11l1111_l1_,l1l1l1l11l1l_l1_ = [],[],[],[],[]
	if l1l111lllll1_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ伊")] = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ伋")
		dict[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ伌")] = l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ伍")
		dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ伎")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ伏")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ伐")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭休")]+l1l111_l1_ (u"ࠬࠦࠠࠨ伒")+l1l111_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ伓")
		dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ伔")] = l1l111lllll1_l1_
		dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ伕")] = l1l111_l1_ (u"ࠩ࠳ࠫ伖")
		dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ众")] = l1l111_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ优")
		l1l111l1ll1l_l1_.append(dict)
	if l1l11lll11ll_l1_:
		l1l1l11ll111_l1_,l1l11l11lll1_l1_ = l1l11l11ll_l1_(l1l11lll11ll_l1_)
		l1l11ll1llll_l1_ = list(zip(l1l1l11ll111_l1_,l1l11l11lll1_l1_))
		for title,l1ll1ll_l1_ in l1l11ll1llll_l1_:
			dict = {}
			dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ伙")] = l1l111_l1_ (u"࠭ࡁࠬࡘࠪ会")
			dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伛")] = l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭伜")
			dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭伝")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ伞") in title: dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伟")] = title.split(l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ传"))[0].rsplit(l1l111_l1_ (u"࠭ࠠࠡࠩ伡"))[-1]
			else: dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伢")] = l1l111_l1_ (u"ࠨ࠳࠳ࠫ伣")
			if title.count(l1l111_l1_ (u"ࠩࠣࠤࠬ伤"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠪࠤࠥ࠭伥"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ伦")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭伧")] = l1l111_l1_ (u"࠭࠰࠱࠲࠳ࠫ伨")
			if title==l1l111_l1_ (u"ࠧ࠮࠳ࠪ伩"): dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ伪")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ伫")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ伬")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭伭")]+l1l111_l1_ (u"ࠬࠦࠠࠨ伮")+l1l111_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ伯")
			else: dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭估")] = dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ伱")]+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭伲")+dict[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ伳")]+l1l111_l1_ (u"ࠫࠥࠦࠧ伴")+dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭伵")]+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭伶")+dict[l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ伷")]
			l1l111l1ll1l_l1_.append(dict)
	l1l111l1ll1l_l1_ = sorted(l1l111l1ll1l_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ伸")]))
	if not l1l111l1ll1l_l1_:
		l1lll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ伹"),html,re.DOTALL)
		l1lll1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ伺"),html,re.DOTALL)
		l1l1l11111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ伻"),html,re.DOTALL)
		l1l1l1111l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ似"),html,re.DOTALL)
		try: l1l11111ll11_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ伽")][l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ伾")][l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ伿")][l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ佀")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ佁")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ佂")]
		except: l1l11111ll11_l1_ = l1l111_l1_ (u"ࠬ࠭佃")
		try: l1l1l1111ll1_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ佄")][l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ佅")][l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ但")][l1l111_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ佇")][0][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ佈")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ佉")]
		except: l1l1l1111ll1_l1_ = l1l111_l1_ (u"ࠬ࠭佊")
		try: l1l1l1111lll_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ佋")][l1l111_l1_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ佌")]
		except: l1l1l1111lll_l1_ = l1l111_l1_ (u"ࠨࠩ位")
		if l1lll1ll111_l1_ or l1lll1ll11l_l1_ or l1l1l11111ll_l1_ or l1l1l1111l11_l1_ or l1l11111ll11_l1_ or l1l1l1111ll1_l1_ or l1l1l1111lll_l1_:
			if   l1lll1ll111_l1_: message = l1lll1ll111_l1_[0]
			elif l1lll1ll11l_l1_: message = l1lll1ll11l_l1_[0]
			elif l1l1l11111ll_l1_: message = l1l1l11111ll_l1_[0]
			elif l1l1l1111l11_l1_: message = l1l1l1111l11_l1_[0]
			elif l1l11111ll11_l1_: message = l1l11111ll11_l1_
			elif l1l1l1111ll1_l1_: message = l1l1l1111ll1_l1_
			elif l1l1l1111lll_l1_: message = l1l1l1111lll_l1_
			l1l1l1ll1l11_l1_ = message.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ低"),l1l111_l1_ (u"ࠪࠫ住")).strip(l1l111_l1_ (u"ࠫࠥ࠭佐"))
			l1l1l1ll11ll_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่าสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษ๊ࠡๅำࠥ๐ใ้่ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭佑")
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ佒"),l1l111_l1_ (u"ࠧࠨ体"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ佔"),l1l1l1ll11ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ何")+l1l1l1ll1l11_l1_)
			return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ佖")+l1l1l1ll1l11_l1_,[],[]
		else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ佗"),[],[]
	l1l111l11ll1_l1_,l1l111l11lll_l1_,l1l11l1lllll_l1_ = [],[],[]
	for dict in l1l111l1ll1l_l1_:
		if dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ佘")]==l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ余"):
			l1l1l111l111_l1_.append(dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭佚")])
			l1l1l11l11ll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ佛")]==l1l111_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ作"):
			l1l11l1ll1ll_l1_.append(dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ佝")])
			l1l111ll1lll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佞")]==l1l111_l1_ (u"ࠬࡳࡰࡥࠩ佟"):
			title = dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ你")].replace(l1l111_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ佡"),l1l111_l1_ (u"ࠨࠩ佢"))
			if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ佣") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ佤")
			else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ佥")]
			l1l111l11ll1_l1_.append([dict,{},title,l11ll1l11ll_l1_])
		else:
			title = dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ佦")].replace(l1l111_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭佧"),l1l111_l1_ (u"ࠧࠨ佨"))
			if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ佩") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ佪")
			else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ佫")]
			l1l111l11ll1_l1_.append([dict,{},title,l11ll1l11ll_l1_])
			l1l1l1l1ll11_l1_.append(title)
			l1l111lll1l1_l1_.append(dict)
		l1l11llll111_l1_ = True
		if l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ佬") in list(dict.keys()):
			if l1l111_l1_ (u"ࠬࡧࡶ࠱ࠩ佭") in dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭佮")]: l1l11llll111_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠧࡢࡸࡦࠫ佯") not in dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ佰")] and l1l111_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ佱") not in dict[l1l111_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ佲")]: l1l11llll111_l1_ = False
		if dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ佳")]==l1l111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ佴") and dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ併")]!=l1l111_l1_ (u"ࠧ࠱࠯࠳ࠫ佶") and l1l11llll111_l1_==True:
			l1l1111l1111_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ佷")])
			l1l1l1l11l1l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ佸")]==l1l111_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ佹") and dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ佺")]!=l1l111_l1_ (u"ࠬ࠶࠭࠱ࠩ佻") and l1l11llll111_l1_==True:
			l1l1l1ll11l1_l1_.append(dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ佼")])
			l1l1l11l1111_l1_.append(dict)
	for l1l11lll1l1l_l1_ in l1l1l11l1111_l1_:
		l1l1l1lll111_l1_ = l1l11lll1l1l_l1_[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ佽")]
		for l1l1l111111l_l1_ in l1l1l1l11l1l_l1_:
			l1l1l1llll11_l1_ = l1l1l111111l_l1_[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ佾")]
			l11ll1l11ll_l1_ = l1l1l1llll11_l1_+l1l1l1lll111_l1_
			title = l1l1l111111l_l1_[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ使")].replace(l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬ侀"),l1l111_l1_ (u"ࠫࡲࡶࡤࠡࠢࠪ侁"))
			title = title.replace(l1l1l111111l_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ侂")]+l1l111_l1_ (u"࠭ࠠࠡࠩ侃"),l1l111_l1_ (u"ࠧࠨ侄"))
			title = title.replace(str((float(l1l1l1llll11_l1_*10)//1024/10))+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭侅"),str((float(l11ll1l11ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ來"))
			title = title+l1l111_l1_ (u"ࠪࠬࠬ侇")+l1l11lll1l1l_l1_[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ侈")].split(l1l111_l1_ (u"ࠬ࠮ࠧ侉"),1)[1]
			l1l111l11ll1_l1_.append([l1l1l111111l_l1_,l1l11lll1l1l_l1_,title,l11ll1l11ll_l1_])
	l1l111l11ll1_l1_ = sorted(l1l111l11ll1_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l1l111111l_l1_,l1l11lll1l1l_l1_,title,l11ll1l11ll_l1_ in l1l111l11ll1_l1_:
		l1l111l1l1l1_l1_ = l1l1l111111l_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ侊")]
		if l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ例") in list(l1l11lll1l1l_l1_.keys()):
			l1l111l1l1l1_l1_ = l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ侌")
		if l1l111l1l1l1_l1_ not in l1l11l1lllll_l1_:
			l1l11l1lllll_l1_.append(l1l111l1l1l1_l1_)
			l1l111l11lll_l1_.append([l1l1l111111l_l1_,l1l11lll1l1l_l1_,title,l11ll1l11ll_l1_])
	l1l1111ll1ll_l1_,l1l1l11ll1l1_l1_,shift = [],[],0
	l1l11llll1ll_l1_,l1l1l1l11l11_l1_ = l1l111_l1_ (u"ࠩࠪ侍"),l1l111_l1_ (u"ࠪࠫ侎")
	try: l1l11llll1ll_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ侏")][l1l111_l1_ (u"ࠬࡧࡵࡵࡪࡲࡶࠬ侐")]
	except: l1l11llll1ll_l1_ = l1l111_l1_ (u"࠭ࠧ侑")
	try: l1l11l1l1ll1_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭侒")][l1l111_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ侓")]
	except: l1l11l1l1ll1_l1_ = l1l111_l1_ (u"ࠩࠪ侔")
	if l1l11llll1ll_l1_ and l1l11l1l1ll1_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ侕")+l1l11llll1ll_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭侖")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭侗")][0]+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ侘")+l1l11l1l1ll1_l1_
		l1l1111ll1ll_l1_.append(title)
		l1l1l11ll1l1_l1_.append(l1ll1ll_l1_)
		try: l1l1l1l11l11_l1_ = l1l1l11lllll_l1_[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭侙")][l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ侚")][l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭供")][-1][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ侜")]
		except: pass
	for l1l1l111111l_l1_,l1l11lll1l1l_l1_,title,l11ll1l11ll_l1_ in l1l111l11lll_l1_:
		l1l1111ll1ll_l1_.append(title) ; l1l1l11ll1l1_l1_.append(l1l111_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ依"))
	if l1l1l1l1ll11_l1_: l1l1111ll1ll_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡ็ะำิฯࠧ侞")) ; l1l1l11ll1l1_l1_.append(l1l111_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ侟"))
	if l1l111l11ll1_l1_: l1l1111ll1ll_l1_.append(l1l111_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬࠣห้๋ส้ใิࠫ侠")) ; l1l1l11ll1l1_l1_.append(l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ価"))
	if l1l1111l1111_l1_: l1l1111ll1ll_l1_.append(l1l111_l1_ (u"ࠩࡰࡴࡩࠦวฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ侢")) ; l1l1l11ll1l1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵࡪࠧ侣"))
	if l1l1l111l111_l1_: l1l1111ll1ll_l1_.append(l1l111_l1_ (u"ฺࠫ๎ัสࠢหำํ์ࠠึ๊อࠫ侤")) ; l1l1l11ll1l1_l1_.append(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ侥"))
	if l1l11l1ll1ll_l1_: l1l1111ll1ll_l1_.append(l1l111_l1_ (u"࠭ี้ฬࠣฬิ๎ๆࠡื๋ีฮ࠭侦")) ; l1l1l11ll1l1_l1_.append(l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭侧"))
	l1l1l1ll1111_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111lll111_l1_, l1l1111ll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭侨"),[],[]
		elif l11l11l_l1_==0 and l1l11llll1ll_l1_:
			l1ll1ll_l1_ = l1l1l11ll1l1_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠳ࠩࡲࡦࡳࡥ࠾ࠩ侩")+QUOTE(l1l11llll1ll_l1_)+l1l111_l1_ (u"ࠪࠪࡺࡸ࡬࠾ࠩ侪")+l1ll1ll_l1_
			if l1l1l1l11l11_l1_: new_path = new_path+l1l111_l1_ (u"ࠫࠫ࡯࡭ࡢࡩࡨࡁࠬ侫")+QUOTE(l1l1l1l11l11_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ侬")+new_path+l1l111_l1_ (u"ࠨࠩࠣ侭"))
			return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ侮"),[],[]
		choice = l1l1l11ll1l1_l1_[l11l11l_l1_]
		l1l1l111l11l_l1_ = l1l1111ll1ll_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"ࠨࡦࡤࡷ࡭࠭侯"):
			l1l11l1l11l1_l1_ = l1l111lllll1_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ侰"),l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ侱"),l1l111_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ侲")]:
			if choice==l1l111_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ侳"): l1l1lll1_l1_,l1l11ll1lll1_l1_ = l1l1l1l1ll11_l1_,l1l111lll1l1_l1_
			elif choice==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ侴"): l1l1lll1_l1_,l1l11ll1lll1_l1_ = l1l1l111l111_l1_,l1l1l11l11ll_l1_
			elif choice==l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭侵"): l1l1lll1_l1_,l1l11ll1lll1_l1_ = l1l11l1ll1ll_l1_,l1l111ll1lll_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ侶"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l1l11l1l11l1_l1_ = l1l11ll1lll1_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭侷")]
				l1l1l111l11l_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠪࡱࡵࡪࠧ侸"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯ࠺ࠨ侹"), l1l1111l1111_l1_)
			if l11l11l_l1_!=-1:
				l1l1l111l11l_l1_ = l1l1111l1111_l1_[l11l11l_l1_]
				l1l1111llll1_l1_ = l1l1l1l11l1l_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํะ࠺ࠨ侺"), l1l1l1ll11l1_l1_)
				if l11l11l_l1_!=-1:
					l1l1l111l11l_l1_ += l1l111_l1_ (u"࠭ࠠࠬࠢࠪ侻")+l1l1l1ll11l1_l1_[l11l11l_l1_]
					l1l11ll1l111_l1_ = l1l1l11l1111_l1_[l11l11l_l1_]
					l1l1l1ll1111_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ侼"):
			l1l11l1111ll_l1_,l1l1111l111l_l1_,l1l111ll111l_l1_,l1l1l1l1ll1l_l1_ = list(zip(*l1l111l11ll1_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ侽"), l1l111ll111l_l1_)
			if l11l11l_l1_!=-1:
				l1l1l111l11l_l1_ = l1l111ll111l_l1_[l11l11l_l1_]
				l1l1111llll1_l1_ = l1l11l1111ll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠩࡰࡴࡩ࠭侾") in l1l111ll111l_l1_[l11l11l_l1_] and l1l1111llll1_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ便")]!=l1l111lllll1_l1_:
					l1l11ll1l111_l1_ = l1l1111l111l_l1_[l11l11l_l1_]
					l1l1l1ll1111_l1_ = True
				else: l1l11l1l11l1_l1_ = l1l1111llll1_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俀")]
				break
		elif choice==l1l111_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭俁"):
			l1l11l1111ll_l1_,l1l1111l111l_l1_,l1l111ll111l_l1_,l1l1l1l1ll1l_l1_ = list(zip(*l1l111l11lll_l1_))
			l1l1111llll1_l1_ = l1l11l1111ll_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"࠭࡭ࡱࡦࠪ係") in l1l111ll111l_l1_[l11l11l_l1_-shift] and l1l1111llll1_l1_[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ促")]!=l1l111lllll1_l1_:
				l1l11ll1l111_l1_ = l1l1111l111l_l1_[l11l11l_l1_-shift]
				l1l1l1ll1111_l1_ = True
			else: l1l11l1l11l1_l1_ = l1l1111llll1_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俄")]
			l1l1l111l11l_l1_ = l1l111ll111l_l1_[l11l11l_l1_-shift]
			break
	if not l1l1l1ll1111_l1_: l1l11l1l1111_l1_ = l1l11l1l11l1_l1_
	else: l1l11l1l1111_l1_ = l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪ俅")+l1l1111llll1_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俆")]+l1l111_l1_ (u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨ俇")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俈")]
	if l1l1l1ll1111_l1_:
		l1l1l1l111ll_l1_ = int(l1l1111llll1_l1_[l1l111_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ俉")])
		l1l11l1l1l1l_l1_ = int(l1l11ll1l111_l1_[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ俊")])
		l1l1lll111_l1_ = str(max(l1l1l1l111ll_l1_,l1l11l1l1l1l_l1_))
		l1l111ll1ll1_l1_ = l1l1111llll1_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俋")].replace(l1l111_l1_ (u"ࠩࠩࠫ俌"),l1l111_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ俍"))
		l1l11l1lll11_l1_ = l1l11ll1l111_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俎")].replace(l1l111_l1_ (u"ࠬࠬࠧ俏"),l1l111_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ俐"))
		l1l1l1l1l11l_l1_ = l1l111_l1_ (u"ࠧ࠽ࡁࡻࡱࡱࠦࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣ࠳࠱࠴ࠧࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠾ࠤࡘࡘࡋ࠳࠸ࠣࡁࡁࡠࡳ࠭俑")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡐࡔࡉࠦࡸ࡮࡮ࡱࡷ࠿ࡾࡳࡪ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠳࠲࠳࠵࠴࡞ࡍࡍࡕࡦ࡬ࡪࡳࡡ࠮࡫ࡱࡷࡹࡧ࡮ࡤࡧࠥࠤࡽࡳ࡬࡯ࡵࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠨࠠࡹ࡯࡯ࡲࡸࡀࡸ࡭࡫ࡱ࡯ࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡻ࠸࠴࡯ࡳࡩ࠲࠵࠾࠿࠹࠰ࡺ࡯࡭ࡳࡱࠢࠡࡺࡶ࡭࠿ࡹࡣࡩࡧࡰࡥࡑࡵࡣࡢࡶ࡬ࡳࡳࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡴࡥ࡫ࡩࡲࡧ࠺࡮ࡲࡧ࠾࠷࠶࠱࠲ࠢ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡸࡦࡴࡤࡢࡴࡧࡷ࠳࡯ࡳࡰ࠰ࡲࡶ࡬࠵ࡩࡵࡶࡩ࠳ࡕࡻࡢ࡭࡫ࡦࡰࡾࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࡔࡶࡤࡲࡩࡧࡲࡥࡵ࠲ࡑࡕࡋࡇ࠮ࡆࡄࡗࡍࡥࡳࡤࡪࡨࡱࡦࡥࡦࡪ࡮ࡨࡷ࠴ࡊࡁࡔࡊ࠰ࡑࡕࡊ࠮ࡹࡵࡧࠦࠥࡳࡩ࡯ࡄࡸࡪ࡫࡫ࡲࡕ࡫ࡰࡩࡂࠨࡐࡕ࠳࠱࠹ࡘࠨࠠ࡮ࡧࡧ࡭ࡦࡖࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡈࡺࡸࡡࡵ࡫ࡲࡲࡂࠨࡐࡕࠩ俒")+l1l1lll111_l1_+l1l111_l1_ (u"ࠩࡖࠦࠥࡺࡹࡱࡧࡀࠦࡸࡺࡡࡵ࡫ࡦࠦࠥࡶࡲࡰࡨ࡬ࡰࡪࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡲࡵࡳ࡫࡯࡬ࡦ࠼࡬ࡷࡴ࡬ࡦ࠮࡯ࡤ࡭ࡳࡀ࠲࠱࠳࠴ࠦࡃࡢ࡮ࠨ俓")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠪࡀࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ俔")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠳ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡸ࡬ࡨࡪࡵ࠯ࠨ俕")+l1l1111llll1_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ俖")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡶࡵࡹࡪࠨ࠾࡝ࡰࠪ俗")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ俘")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ俙")+l1l1111llll1_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ俚")]+l1l111_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ俛")+l1l1111llll1_l1_[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ俜")]+l1l111_l1_ (u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢࠨ保")+str(l1l1111llll1_l1_[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ俞")])+l1l111_l1_ (u"ࠧࠣࠢࡺ࡭ࡩࡺࡨ࠾ࠤࠪ俟")+str(l1l1111llll1_l1_[l1l111_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ俠")])+l1l111_l1_ (u"ࠩࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠭信")+str(l1l1111llll1_l1_[l1l111_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ俢")])+l1l111_l1_ (u"ࠫࠧࠦࡦࡳࡣࡰࡩࡗࡧࡴࡦ࠿ࠥࠫ俣")+l1l1111llll1_l1_[l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ俤")]+l1l111_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ俥")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ俦")+l1l111ll1ll1_l1_+l1l111_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ俧")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ俨")+l1l1111llll1_l1_[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ俩")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ俪")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ俫")+l1l1111llll1_l1_[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ俬")]+l1l111_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ俭")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ修")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ俯")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ俰")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠴ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨ俱")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ俲")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡶࡵࡹࡪࠨ࠾࡝ࡰࠪ俳")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ俴")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ俵")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ俶")]+l1l111_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ俷")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ俸")]+l1l111_l1_ (u"ࠬࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦ࠶࠹࠰࠵࠹࠸ࠦࡃࡢ࡮ࠨ俹")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"࠭࠼ࡂࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡉ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾࠷࠹࠰࠱࠵࠽࠷࠿ࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠬ俺")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ俻")]+l1l111_l1_ (u"ࠨࠤ࠲ࡂࡡࡴࠧ俼")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ俽")+l1l11l1lll11_l1_+l1l111_l1_ (u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ俾")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ俿")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ倀")]+l1l111_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ倁")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ倂")+l1l11ll1l111_l1_[l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭倃")]+l1l111_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ倄")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭倅")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ倆")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ倇")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ倈")
		l1l1l1l1l11l_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ倉")
		if PY3:
			import http.server as l1l11l11l1ll_l1_
			import http.client as l1l11ll11l11_l1_
		else:
			import BaseHTTPServer as l1l11l11l1ll_l1_
			import httplib as l1l11ll11l11_l1_
		class l1l11lllllll_l1_(l1l11l11l1ll_l1_.HTTPServer):
			def __init__(self,l1lll1ll1ll1_l1_=l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ倊"),port=55055,l1l1l1l1l11l_l1_=l1l111_l1_ (u"ࠩ࠿ࡂࠬ個")):
				self.l1lll1ll1ll1_l1_ = l1lll1ll1ll1_l1_
				self.port = port
				self.l1l1l1l1l11l_l1_ = l1l1l1l1l11l_l1_
				l1l11l11l1ll_l1_.HTTPServer.__init__(self,(self.l1lll1ll1ll1_l1_,self.port),l1l1l1l11lll_l1_)
				self.l1l11lll11l1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ倌")+l1lll1ll1ll1_l1_+l1l111_l1_ (u"ࠫ࠿࠭倍")+str(port)+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ倎")
			def start(self):
				self.threads = l11l1l11l11_l1_(False)
				self.threads.start_new_thread(1,self.l1l11l11ll11_l1_)
			def l1l11l11ll11_l1_(self):
				self.l1l111l11111_l1_ = True
				while self.l1l111l11111_l1_:
					self.handle_request()
			def stop(self):
				self.l1l111l11111_l1_ = False
				self.l1l11llllll1_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l1l1l1l11l_l1_):
				self.l1l1l1l1l11l_l1_ = l1l1l1l1l11l_l1_
			def l1l11llllll1_l1_(self):
				conn = l1l11ll11l11_l1_.HTTPConnection(self.l1lll1ll1ll1_l1_+l1l111_l1_ (u"࠭࠺ࠨ倏")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠢࡉࡇࡄࡈࠧ倐"), l1l111_l1_ (u"ࠣ࠱ࠥ們"))
		class l1l1l1l11lll_l1_(l1l11l11l1ll_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ倒"),l1l111_l1_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ倓"))
				self.end_headers()
				self.wfile.write(self.server.l1l1l1l1l11l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ倔")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ倕"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ倖"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l11lllllll_l1_(l1l111_l1_ (u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪ倗"),55055,l1l1l1l1l11l_l1_)
		l1l11l1l11l1_l1_ = httpd.l1l11lll11l1_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"ࠨࠩ倘")
	if not l1l11l1l11l1_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ候"),[],[]
	return l1l111_l1_ (u"ࠪࠫ倚"),[l1l111_l1_ (u"ࠫࠬ倛")],[[l1l11l1l11l1_l1_,l1l1l111ll11_l1_,httpd]]
def l1l11lll1111_l1_(url):
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ倜") : l1l111_l1_ (u"࠭ࠧ倝") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ倞"),headers,l1l111_l1_ (u"ࠨࠩ借"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡄࡒࡆ࠲࠷ࡳࡵࠩ倠"))
	items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤࡿ࠭ࡡࢃࠧ倡"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l1l11ll111_l1_,l1l1lll1_l1_,l1l11l11lll1_l1_,l1llll_l1_ = [],[],[],[]
	if not items: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡅࡓࡇ࠭倢"),[],[]
	for l1ll1ll_l1_,dummy,l1llllll111l_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ倣"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ値"))
		if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭倥") in l1ll1ll_l1_:
			l1l1l11ll111_l1_,l1l11l11lll1_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
			l1llll_l1_ = l1llll_l1_ + l1l11l11lll1_l1_
			if l1l1l11ll111_l1_[0]==l1l111_l1_ (u"ࠨ࠯࠴ࠫ倦"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ倧")+l1l111_l1_ (u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ倨"))
			else:
				for title in l1l1l11ll111_l1_:
					l1l1lll1_l1_.append(l1l111_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ倩")+l1l111_l1_ (u"ࠬࠦࠠࠡࠩ倪")+title)
		else:
			title = l1l111_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ倫")+l1l111_l1_ (u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪ倬")+l1llllll111l_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	return l1l111_l1_ (u"ࠨࠩ倭"),l1l1lll1_l1_,l1llll_l1_
def l1l11l1l111l_l1_(html):
	l111llll11_l1_,l1ll11l1_l1_,l1l1111lll11_l1_,l1llll1lll1_l1_ = [],[],[],[]
	if l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠫ倮") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥ࠰࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ倯"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			if l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠪ倰") in block and l1l111_l1_ (u"ࠬࡲࡡࡣࡧ࡯࠾ࠬ倱") in block:
				l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠧࠨࡨ࡬ࡰࡪࡀࠠࠫ࡝ࠥࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧ࠭࡝࠭࡮ࡤࡦࡪࡲ࠺ࠡࠬ࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫ倲"),block,re.DOTALL)
				for l1ll1ll_l1_,title in l1ll_l1_:
					if not title: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠧ࠯ࠩ倳"),1)[1]
					l111llll11_l1_.append(title)
					l1ll11l1_l1_.append(l1ll1ll_l1_)
			else:
				l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠩࠪࡪ࡮ࡲࡥ࠻ࠢ࠭࡟ࠧ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢࠨ࡟ࠪࠫࠬ倴"),block,re.DOTALL)
				if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭倵"),block,re.DOTALL)
				for l1ll1ll_l1_ in l1ll_l1_:
					title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠪ࠲ࠬ倶"),1)[1]
					l111llll11_l1_.append(title)
					l1ll11l1_l1_.append(l1ll1ll_l1_)
	if not l1ll11l1_l1_ and l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠪ倷") in html:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡧ࡫࡯ࡩ࠿ࠦࠪ࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩ倸"),html,re.DOTALL)
		for l1ll1ll_l1_ in l1ll_l1_:
			title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"࠭࠮ࠨ倹"),1)[1]
			l111llll11_l1_.append(title)
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1ll11l1_l1_,l111llll11_l1_)
	for l1ll1ll_l1_,title in l1lll1l_l1_:
		if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭债") in l1ll1ll_l1_:
			l1l11ll11lll_l1_,l1l11ll1l1ll_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
			l1llll1lll1_l1_ += l1l11ll1l1ll_l1_
			l1l1111lll11_l1_ += l1l11ll11lll_l1_
		else:
			l1llll1lll1_l1_.append(l1ll1ll_l1_)
			l1l1111lll11_l1_.append(title)
	if l1llll1lll1_l1_: return l1l111_l1_ (u"ࠨࠩ倻"),l1l1111lll11_l1_,l1llll1lll1_l1_
	return l1l111_l1_ (u"ࠩࠪ值"),[],[]
def l1l11lll1l11_l1_(url):
	l1lll11lllll_l1_,payload = l1l111_l1_ (u"ࠪࠫ倽"),{}
	headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ倾"):l1l111_l1_ (u"ࠬ࠭倿")}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ偀"),url,l1l111_l1_ (u"ࠧࠨ偁"),headers,l1l111_l1_ (u"ࠨࠩ偂"),l1l111_l1_ (u"ࠩࠪ偃"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ偄"))
	html = response.content
	if l1l111_l1_ (u"ࠫࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠧ偅") in html:
		l1111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡠࡪࡲ࡞࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬࡠ࠮࠯ࠧ偆"),html,re.DOTALL)
		if l1111l1llll_l1_: l1lll11lllll_l1_ = l1lll1llll11_l1_(l1111l1llll_l1_[0])
	l11l1ll1_l1_ = html+l1lll11lllll_l1_
	l1l1l11111l1_l1_ = url.split(l1l111_l1_ (u"࠭࠯ࠨ假"))[3]
	if l1l111_l1_ (u"ࠧࠣ࡫ࡧ࠶ࠧ࠭偈") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠨ࡫ࡧ࠶ࠬ偉"):l1l1l11111l1_l1_,l1l111_l1_ (u"ࠩࡲࡴࠬ偊"):l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭偋")}
	elif l1l111_l1_ (u"ࠫࠧ࡯ࡤࠣࠩ偌") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ偍"):l1l1l11111l1_l1_,l1l111_l1_ (u"࠭࡯ࡱࠩ偎"):l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ偏")}
	if not payload:
		l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1l111l_l1_(l11l1ll1_l1_)
		if l1llll_l1_: return l1l1l11lll1l_l1_,l1l1lll1_l1_,l1llll_l1_
	headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ偐"):l1l111_l1_ (u"ࠩࠪ偑"),l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ偒"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ偓")}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ偔"),url,payload,headers,l1l111_l1_ (u"࠭ࠧ偕"),l1l111_l1_ (u"ࠧࠨ偖"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ偗"))
	l1ll1lll1_l1_ = response.content
	l1l111lll11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ偘"),l1ll1lll1_l1_,re.DOTALL)
	if l1l111lll11l_l1_: return l1l111_l1_ (u"ࠪࠫ偙"),[l1l111_l1_ (u"ࠫࠬ做")],[l1l111lll11l_l1_[0]]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡙ࠠࡕࡋࡅࡗࡏࡎࡈࠩ偛"),[],[]
def l1l1l1111l1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ停"),l1l111_l1_ (u"ࠧࠨ偝"),l1l111_l1_ (u"ࠨࠩ偞"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ偟"))
	items = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ偠"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ偡"),[l1l111_l1_ (u"ࠬ࠭偢")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫ偣"),[],[]
def l1l11lll111l_l1_(url):
	return l1l111_l1_ (u"ࠧࠨ偤"),[l1l111_l1_ (u"ࠨࠩ健")],[ url ]
def l1l1l11l1ll1_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ偦"))
	basename = l1l111_l1_ (u"ࠪ࠳ࠬ偧").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ偨"),l1l111_l1_ (u"ࠬ࠭偩"),l1l111_l1_ (u"࠭ࠧ偪"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ偫"))
	items = re.findall(l1l111_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ偬"),html,re.DOTALL)
	if items:
		l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l1ll111l1l11_l1_,l1l1l1l1l1l1_l1_,l1l1l1l1l1ll_l1_,l1l1l1l1l111_l1_ = items[0]
		var = int(l1ll111l11ll_l1_) % int(l1ll111l1l11_l1_) + int(l1l1l1l1l1l1_l1_) % int(l1l1l1l1l1ll_l1_)
		url = basename + l1ll1111l1ll_l1_ + str(var) + l1l1l1l1l111_l1_
		return l1l111_l1_ (u"ࠩࠪ偭"),[l1l111_l1_ (u"ࠪࠫ偮")],[url]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࡚ࠦࡊࡒࡓ࡝ࡘࡎࡁࡓࡇࠪ偯"),[],[]
def l1l11ll1ll1l_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ偰"))[-1]
	headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ偱") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭偲") }
	payload = { l1l111_l1_ (u"ࠣ࡫ࡧࠦ偳"):id , l1l111_l1_ (u"ࠤࡲࡴࠧ側"):l1l111_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷ࠨ偵") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ偶"), url, payload, headers, l1l111_l1_ (u"ࠬ࠭偷"),l1l111_l1_ (u"࠭ࠧ偸"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ偹"))
	if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ偺") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ偻")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࠫ偼"),[l1l111_l1_ (u"ࠫࠬ偽")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡒ࠷࡙ࡕࡒࡏࡂࡆࠪ偾"),[],[]
def l1l11111ll1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ偿"),l1l111_l1_ (u"ࠧࠨ傀"),l1l111_l1_ (u"ࠨࠩ傁"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬ傂"))
	items = re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺ࠡ࡞࡞ࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭傃"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ傄"),[l1l111_l1_ (u"ࠬ࠭傅")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡌࡒ࡙࡜ࡌࡊࡘࡈࠫ傆"),[],[]
def l1l111l111ll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ傇"),l1l111_l1_ (u"ࠨࠩ傈"),l1l111_l1_ (u"ࠩࠪ傉"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡅࡋࡍ࡛ࡋ࠭࠲ࡵࡷࠫ傊"))
	items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ傋"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ傌") + items[0]
		return l1l111_l1_ (u"࠭ࠧ傍"),[l1l111_l1_ (u"ࠧࠨ傎")],[ url ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ傏"),[],[]
def l1l111l1ll11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ傐"),l1l111_l1_ (u"ࠪࠫ傑"),l1l111_l1_ (u"ࠫࠬ傒"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭傓"))
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭傔"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ傕"),[l1l111_l1_ (u"ࠨࠩ傖")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ傗"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ⿩")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡏ࡙࡜࡟ࠨ⿪")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==810: l1lll_l1_ = l1l1l11_l1_()
	elif mode==811: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==812: l1lll_l1_ = PLAY(url)
	elif mode==813: l1lll_l1_ = l1ll11lllll_l1_(url)
	elif mode==819: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⿫"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ⿬"),l1l111_l1_ (u"ࠬ࠭⿭"),l1l111_l1_ (u"࠭ࠧ⿮"),l1l111_l1_ (u"ࠧࠨ⿯"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⿰"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿱"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⿲"),l1l111_l1_ (u"ࠫࠬ⿳"),819,l1l111_l1_ (u"ࠬ࠭⿴"),l1l111_l1_ (u"࠭ࠧ⿵"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⿶"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⿷"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⿸"),l1l111_l1_ (u"ࠪࠫ⿹"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡲࡪ࡯ࡤࡶࡾ࠳࡬ࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࠦࡲࡵࡳࡵ࠯ࡹ࡭ࡪࡽࡥࡥࠤࠪ⿺"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ⿻"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿼"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⿽")+l1lllll_l1_+title,l1ll1ll_l1_,811)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠨࠩ⿾")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⿿"),url,l1l111_l1_ (u"ࠪࠫ　"),l1l111_l1_ (u"ࠫࠬ、"),l1l111_l1_ (u"ࠬ࠭。"),l1l111_l1_ (u"࠭ࠧ〃"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭〄"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡧࡱࡲࡸࡪࡸࠢࠨ々"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ〆"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭〇"),title,re.DOTALL)
			if l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭〈") not in type and l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ〉") + l1l1lll_l1_[0][0]
				title = title.replace(l1l111_l1_ (u"࠭ว้่่ࠣฬ๐ๆࠨ《"),l1l111_l1_ (u"ࠧࠨ》"))
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ「"),l1lllll_l1_+title,l1ll1ll_l1_,813,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ」"),l1lllll_l1_+title,l1ll1ll_l1_,812,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷࠨ『"),html,re.DOTALL)
	if l11llll_l1_:
		type = l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸࡥࡰࡢࡩࡨࡷࠬ』") if l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ【") in type else l1l111_l1_ (u"࠭ࡰࡢࡩࡨࡷࠬ】")
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ〒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ〓"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ〔")+title,l1ll1ll_l1_,811,l1l111_l1_ (u"ࠪࠫ〕"),l1l111_l1_ (u"ࠫࠬ〖"),type)
	return
def l1ll11lllll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ〗"),url,l1l111_l1_ (u"࠭ࠧ〘"),l1l111_l1_ (u"ࠧࠨ〙"),l1l111_l1_ (u"ࠨࠩ〚"),l1l111_l1_ (u"ࠩࠪ〛"),l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚࠲࡙ࡅࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ〜"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡵࡧࡪࡳࡷࡿࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ〝"),html,re.DOTALL)
	if l1ll1ll_l1_: l1lll11_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ〞"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠿ࡥࡱࡀࡻࡦࡺࡣࡩࠩ〟")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ〠"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ〡"),l1l111_l1_ (u"ࠩࠪ〢"),l1l111_l1_ (u"ࠪࠫ〣"),l1l111_l1_ (u"ࠫࠬ〤"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ〥"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭〦"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ〧"),url,l1l111_l1_ (u"ࠨࠩ〨"),l1l111_l1_ (u"ࠩࠪ〩"),l1l111_l1_ (u"〪ࠪࠫ"),l1l111_l1_ (u"〫ࠫࠬ"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ〬"))
		html = response.content
		l1ll11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡁ࠭࠴ࠪࡀ〭ࠫࠥࠫ"),html,re.DOTALL)
		if l1ll11l_l1_:
			l1ll11l_l1_ = base64.b64decode(l1ll11l_l1_[0])
			if PY3: l1ll11l_l1_ = l1ll11l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼〮ࠬ"))
			l1ll11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ〯࠭"),l1ll11l_l1_)
			l1ll_l1_ = l1ll11l_l1_[l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡵࠪ〰")]
			l11l11_l1_ = list(l1ll_l1_.keys())
			l1ll_l1_ = list(l1ll_l1_.values())
			l1lll1l_l1_ = zip(l11l11_l1_,l1ll_l1_)
			for title,l1ll1ll_l1_ in l1lll1l_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ〱")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ〲")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ〳"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ〴"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ〵"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ〶"),l1l111_l1_ (u"ࠩ࠮ࠫ〷"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ〸")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ〹"))
	return
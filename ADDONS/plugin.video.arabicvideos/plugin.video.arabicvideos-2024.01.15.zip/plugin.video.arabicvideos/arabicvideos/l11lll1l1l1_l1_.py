# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ屽")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ屾")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11l11l1lll1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l11l11l1ll11_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l11l1l11lll1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l11l11llllll_l1_()
	elif mode==148: l1lll_l1_ = l11l1l11111l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屿"),l1lllll_l1_+l1l111_l1_ (u"࠭โศศ่อࠬ岀"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࡒࡏࡅ࡯࠻ࡇࡴ࠺ࡉࡌ࠽ࡠ࡮ࡖࡤࡉ࠴ࡗ࡜࠭࠸ࡉ࠶ࡆࡴࡷࡉࡺ࡜ࡄ࠸ࡺ࡙ࡁࠨ岁"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岂"),l1lllll_l1_+l1l111_l1_ (u"ࠩืาฺ࠭岃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࡗࡇࡓࡵࡦࡧ࡫ࡦ࡭ࡦࡲࠧ岄"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岅"),l1lllll_l1_+l1l111_l1_ (u"๋่ࠬใ฻ࠪ岆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࡗࡆࡵ࠺࠿ࡡࡈࡐࡶࡵ࠾ࡨࡢࡩࡹ࡙ࡘࡶ࠷ࡕࡵࡸࡪࡻࠬ岇"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岈"),l1lllll_l1_+l1l111_l1_ (u"ࠨฯึหอ࠭岉"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡄ࡙࡮ࡥࡔࡱࡦ࡭ࡦࡲࡃࡕࡘࠪ岊"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岋"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬู๊ศสࠪ岌"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭岍"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岎"),l1lllll_l1_+l1l111_l1_ (u"ࠧศใ็ห๊࠭岏"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡴࡶࡲࡶࡪ࡬ࡲࡰࡰࡷࠫ岐"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岑"),l1lllll_l1_+l1l111_l1_ (u"้ࠪำะวาษอࠫ岒"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ岓"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岔"),l1lllll_l1_+l1l111_l1_ (u"࠭โึ์ิอࠬ岕"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ岖"),144,l1l111_l1_ (u"ࠨࠩ岗"),l1l111_l1_ (u"ࠩࠪ岘"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ岙"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岚"),l1lllll_l1_+l1l111_l1_ (u"ࠬะีโฯࠪ岛"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ岜"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岝"),l1lllll_l1_+l1l111_l1_ (u"ࠨำษ๎ุ๐ษࠨ岞"),l111l1_l1_+l1l111_l1_ (u"ࠩࠪ岟"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岠"),l1lllll_l1_+l1l111_l1_ (u"ࠫึอฦอࠩ岡"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡅࡢࡱ࠿ࠪ岢"),144)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ岣"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ岤"),l1l111_l1_ (u"ࠨࠩ岥"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岦"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ岧"),l1l111_l1_ (u"ࠫࠬ岨"),149,l1l111_l1_ (u"ࠬ࠭岩"),l1l111_l1_ (u"࠭ࠧ岪"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ岫"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭岬"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ岭"),l1l111_l1_ (u"ࠪࠫ岮"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岯"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ岰"),l111l1_l1_+l1l111_l1_ (u"࠭ࠧ岱"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岲"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ีฬฬฬสࠩ岳"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ岴"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岵"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊สึใะࠫ岶"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ岷"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岸"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆๅู๏ืษࠨ岹"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ岺"),144,l1l111_l1_ (u"ࠩࠪ岻"),l1l111_l1_ (u"ࠪࠫ岼"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ岽"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岾"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅฯฬสีฬะ๋๊ࠠอ๎ํฮࠧ岿"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭峀"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峁"),l1lllll_l1_+l1l111_l1_ (u"่ࠩาฯอัศฬࠣห้ฮั็ษ่ะࠬ峂"),l1l111_l1_ (u"ࠪࠫ峃"),290)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ峄"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ峅"),l1l111_l1_ (u"࠭ࠧ峆"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峇"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥ฿ัษ์ฬࠫ峈"),l1l111_l1_ (u"ࠩࠪ峉"),147)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峊"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ峋"),l1l111_l1_ (u"ࠬ࠭峌"),148)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峍"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ峎"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ峏"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峐"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬ๋ࠠศฮ้ฬ๏ฯࠧ峑"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡳ࡯ࡷ࡫ࡨࠫ峒"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峓"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ峔"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ峕"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峖"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ峗"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ峘"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峙"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ峚"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ峛"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峜"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠไษิฮํ์ࠧ峝"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀ็ฬืส้่ࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ峞"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峟"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ峠"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ峡"),144)
	return
def l11l11l1ll11_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峢"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡄࡊࡑࡐ࠿ࠦࠠࠨ峣")+name,url,144,l11l_l1_)
	return
def l11l11llllll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ峤"))
	return
def l11l1l11111l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ峥"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠪࠪࠬ峦"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l11lll111_l1_(yccc,url,index):
	level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ峧"))
	l11l11l1l1l1_l1_,l11l11lll11l_l1_ = [],[]
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ峨") in url: l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࠧ峩"))
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭峪") in url: l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡈࡵ࡭࡮ࡣࡱࡨࡸ࠭࡝ࠣ峫"))
	if level==l1l111_l1_ (u"ࠩ࠴ࠫ峬"): l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峭"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ峮"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝ࠣ峯"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬ࡫࡮ࡵࡴ࡬ࡩࡸ࠭࡝ࠣ峰"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡩࡵࡧࡰࡷࠬࡣ࡛࠴࡟࡞ࠫ࡬ࡻࡩࡥࡧࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ峱"))
	l11l1l111l11_l1_,yddd,l11l11ll1lll_l1_ = l11l11l1l111_l1_(yccc,l1l111_l1_ (u"ࠨࠩ峲"),l11l11l1l1l1_l1_)
	if level==l1l111_l1_ (u"ࠩ࠴ࠫ峳") and l11l1l111l11_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ峴") not in url:
			for zz in range(len(yddd)):
				l11l11ll111l_l1_ = str(zz)
				l11l11l1l1l1_l1_ = []
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ峵")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ島"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ峷")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࠫࡢࠨ峸"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ峹")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠤࡠࠦ峺"))
				succeeded,item,l1111ll1_l1_ = l11l11l1l111_l1_(yddd,l1l111_l1_ (u"ࠪࠫ峻"),l11l11l1l1l1_l1_)
				if succeeded: l11l11lll11l_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠷ࡀ࠺ࠨ峼")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ峽")])
			l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣࠢ峾"))
			succeeded,item,l1111ll1_l1_ = l11l11l1l111_l1_(yccc,l1l111_l1_ (u"ࠧࠨ峿"),l11l11l1l1l1_l1_)
			if succeeded and l11l11lll11l_l1_ and l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ崀") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ崁")
				l11l11lll11l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ崂")])
	return yddd,l11l1l111l11_l1_,l11l11lll11l_l1_,l11l11ll1lll_l1_
def l11l11l11l1l_l1_(yccc,yddd,url,index):
	level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ崃"))
	l11l11l1l1l1_l1_,l11l11lll1l1_l1_ = [],[]
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ崄"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ崅")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ崆"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ崇"))
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ崈") in url: l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ崉"))
	elif l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ崊") in url: l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ崋"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ崌")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ崍"))
	if l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ崎") in url or (l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ崏") in url and l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ崐") not in url):
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ崑")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ崒"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ崓")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崔"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ崕")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡦࡨ࡬ࡦࡖࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ崖"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ崗")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ崘"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ崙")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠨ࡝ࠣ崚"))
	l11l1l1111l1_l1_,yeee,l11l11ll1ll1_l1_ = l11l11l1l111_l1_(yddd,l1l111_l1_ (u"ࠧࠨ崛"),l11l11l1l1l1_l1_)
	if level==l1l111_l1_ (u"ࠨ࠴ࠪ崜") and l11l1l1111l1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l11l11l1l1l1_l1_ = []
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崝")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ崞"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崟")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ崠"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崡")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ崢"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崣")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ崤"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崥")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ崦"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崧")+index2+l1l111_l1_ (u"ࠨ࡝ࠣ崨"))
				succeeded,item,l1111ll1_l1_ = l11l11l1l111_l1_(yeee,l1l111_l1_ (u"ࠧࠨ崩"),l11l11l1l1l1_l1_)
				if succeeded: l11l11lll1l1_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠵࠽࠾ࠬ崪")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ崫")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠶ࠧ崬")])
			l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠵ࡢࠨ崭"))
			l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠵ࡢࠨ崮"))
			succeeded,item,l1111ll1_l1_ = l11l11l1l111_l1_(yddd,l1l111_l1_ (u"࠭ࠧ崯"),l11l11l1l1l1_l1_)
			if succeeded and l11l11lll1l1_l1_ and l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ崰") in list(item.keys()):
				l11l11lll1l1_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ崱")])
	return yeee,l11l1l1111l1_l1_,l11l11lll1l1_l1_,l11l11ll1ll1_l1_
def l11l11l1ll1l_l1_(yccc,yeee,url,index):
	level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = index.split(l1l111_l1_ (u"ࠩ࠽࠾ࠬ崲"))
	l11l11l1l1l1_l1_,l11l11l1llll_l1_ = [],[]
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崳")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡷࡧࡵࡸ࡮ࡩࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ崴"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崵")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崶"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崷")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡳࡧࡨࡰࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崸"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崹")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崺"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崻")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崼"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崽")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崾"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崿")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ嵀"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ嵁")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ嵂"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ嵃"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ嵄"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嵅"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ嵆")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡥࡦ࡮ࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ嵇"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ嵈")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嵉"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧࠥ嵊"))
	l11l1l111ll1_l1_,yfff,l11l1l1l1111_l1_ = l11l11l1l111_l1_(yeee,l1l111_l1_ (u"࠭ࠧ嵋"),l11l11l1l1l1_l1_)
	if level==l1l111_l1_ (u"ࠧ࠴ࠩ嵌") and l11l1l111ll1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l11l11ll11ll_l1_ = str(zz)
				l11l11l1l1l1_l1_ = []
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡩࡪ࡫ࡡࠢ嵍")+l11l11ll11ll_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ嵎"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽ࡫࡬ࡦ࡜ࠤ嵏")+l11l11ll11ll_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ嵐"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡦࡧࡨ࡞ࠦ嵑")+l11l11ll11ll_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ嵒"))
				l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡨࡩࡪࡠࠨ嵓")+l11l11ll11ll_l1_+l1l111_l1_ (u"ࠣ࡟ࠥ嵔"))
				succeeded,item,l1111ll1_l1_ = l11l11l1l111_l1_(yfff,l1l111_l1_ (u"ࠩࠪ嵕"),l11l11l1l1l1_l1_)
				if succeeded: l11l11l1llll_l1_.append([item,url,l1l111_l1_ (u"ࠪ࠸࠿ࡀࠧ嵖")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵗")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵘")+l11l11ll11ll_l1_])
	return yfff,l11l1l111ll1_l1_,l11l11l1llll_l1_,l11l1l1l1111_l1_
def l11l11l1l111_l1_(l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l11l11ll1111_l1_):
	yccc,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	yddd,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	yeee,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	yfff,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	item,yrender = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	count = len(l11l11ll1111_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l11ll1111_l1_[l1l111llll_l1_])
			return True,out,l1l111llll_l1_+1
		except: pass
	return False,l1l111_l1_ (u"࠭ࠧ嵙"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠧࠨ嵚"),data=l1l111_l1_ (u"ࠨࠩ嵛")):
	l11l11lll11l_l1_,l11l11lll1l1_l1_,l11l11l1llll_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵜") not in index: index = l1l111_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ嵝")
	level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵞"))
	if level==l1l111_l1_ (u"ࠬ࠺ࠧ嵟"): level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = l1l111_l1_ (u"࠭࠱ࠨ嵠"),l11l11ll111l_l1_,index2,l11l11ll11ll_l1_
	data = data.replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ嵡"),l1l111_l1_ (u"ࠨࠩ嵢"))
	html,yccc,l1l11llll_l1_ = l11l11lll1ll_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵣")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭嵤")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵥")+l11l11ll11ll_l1_
	if level in [l1l111_l1_ (u"ࠬ࠷ࠧ嵦"),l1l111_l1_ (u"࠭࠲ࠨ嵧"),l1l111_l1_ (u"ࠧ࠴ࠩ嵨")]:
		yddd,l11l1l111l11_l1_,l11l11lll11l_l1_,l11l11ll1lll_l1_ = l11l11lll111_l1_(yccc,url,index)
		if not l11l1l111l11_l1_: return
		l1llll1l1l_l1_ = len(l11l11lll11l_l1_)
		if l1llll1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠨ࠳ࠪ嵩"): level = l1l111_l1_ (u"ࠩ࠵ࠫ嵪")
			l11l11lll11l_l1_ = []
	index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭嵫")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵬")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵭")+l11l11ll11ll_l1_
	if level in [l1l111_l1_ (u"࠭࠲ࠨ嵮"),l1l111_l1_ (u"ࠧ࠴ࠩ嵯")]:
		yeee,l11l1l1111l1_l1_,l11l11lll1l1_l1_,l11l11ll1ll1_l1_ = l11l11l11l1l_l1_(yccc,yddd,url,index)
		if not l11l1l1111l1_l1_: return
		l1ll1l111l_l1_ = len(l11l11lll1l1_l1_)
		if l1ll1l111l_l1_<2:
			if level==l1l111_l1_ (u"ࠨ࠴ࠪ嵰"): level = l1l111_l1_ (u"ࠩ࠶ࠫ嵱")
			l11l11lll1l1_l1_ = []
	index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭嵲")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵳")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵴")+l11l11ll11ll_l1_
	if level in [l1l111_l1_ (u"࠭࠳ࠨ嵵")]:
		yfff,l11l1l111ll1_l1_,l11l11l1llll_l1_,l11l1l1l1111_l1_ = l11l11l1ll1l_l1_(yccc,yeee,url,index)
		if not l11l1l111ll1_l1_: return
		l1ll1l11l1_l1_ = len(l11l11l1llll_l1_)
	for item,url,index in l11l11lll11l_l1_+l11l11lll1l1_l1_+l11l11l1llll_l1_:
		l1ll1lllllll_l1_ = l11l11l1l1ll_l1_(item,url,index)
	return
def l11l11l1l1ll_l1_(item,url=l1l111_l1_ (u"ࠧࠨ嵶"),index=l1l111_l1_ (u"ࠨࠩ嵷")):
	if l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵸") in index: level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = index.split(l1l111_l1_ (u"ࠪ࠾࠿࠭嵹"))
	else: level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = l1l111_l1_ (u"ࠫ࠶࠭嵺"),l1l111_l1_ (u"ࠬ࠶ࠧ嵻"),l1l111_l1_ (u"࠭࠰ࠨ嵼"),l1l111_l1_ (u"ࠧ࠱ࠩ嵽")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_,l11l1l11ll1l_l1_ = l11l1l1l11l1_l1_(item)
	l1lllllllll1_l1_ = l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࡁࠪ嵾") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡷࡹࡸࡥࡢ࡯ࡶࡃࠬ嵿") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹ࠿ࠨ嶀") in l1ll1ll_l1_
	l1llllllll11_l1_ = l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹ࠿ࠨ嶁") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸࡅࠧ嶂") in l1ll1ll_l1_
	if l1lllllllll1_l1_ or l1llllllll11_l1_: l1ll1ll_l1_ = url
	l1lllllllll1_l1_ = l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ嶃") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ嶄") not in l1ll1ll_l1_
	l1llllllll11_l1_ = l1l111_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ嶅") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ嶆") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼ࠪ嶇") and l1lllllllll1_l1_ and l1llllllll11_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ嶈") in url or l1l111_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭嶉") in l1ll1ll_l1_:
		level,l11l11ll111l_l1_,index2,l11l11ll11ll_l1_ = l1l111_l1_ (u"࠭࠱ࠨ嶊"),l1l111_l1_ (u"ࠧ࠱ࠩ嶋"),l1l111_l1_ (u"ࠨ࠲ࠪ嶌"),l1l111_l1_ (u"ࠩ࠳ࠫ嶍")
		index = l1l111_l1_ (u"ࠪࠫ嶎")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠫࠬ嶏")
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ嶐") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ嶑") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ嶒") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ嶓"))
		if data.count(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭嶔"))==4:
			l11l1l111l1l_l1_,key,l11l1l111111_l1_,l11l11llll1l_l1_,token = data.split(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ嶕"))
			l1l11llll_l1_ = l11l1l111l1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ嶖")+key+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ嶗")+l11l1l111111_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ嶘")+l11l11llll1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ嶙")+l11l1l11ll1l_l1_
			if l1l111_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭嶚") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ嶛")+key
	if not title:
		global l11l11l1lll1_l1_
		l11l11l1lll1_l1_ += 1
		title = l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠭嶜")+str(l11l11l1lll1_l1_)
		index = l1l111_l1_ (u"ࠫ࠸࠭嶝")+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶞")+l11l11ll111l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ嶟")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶠")+l11l11ll11ll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡑࡻࡹࡖࡪࡴࡤࡦࡴࡨࡶࠬ嶡") in str(item): return False
	elif l1l111_l1_ (u"ࠩ࠲ࡥࡧࡵࡵࡵࠩ嶢") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡭࡮ࡷࡱ࡭ࡹࡿࠧ嶣") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ嶤") in list(item.keys()) or l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ嶥") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ嶦")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶧")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶨")+l11l11ll11ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶩"),l1lllll_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ嶪")+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ嶫"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭嶬") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"࠭࠺࠻ࠢࠪ嶭")+title
		index = l1l111_l1_ (u"ࠧ࠴ࠩ嶮")+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶯")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶰")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嶱")+l11l11ll11ll_l1_
		url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ嶲"),l1l111_l1_ (u"ࠬ࠭嶳"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶴"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠧࠨ嶵"),index,l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嶶"))
	elif l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ嶷") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠪ࠷ࠬ嶸")+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶹")+l11l11ll111l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶺")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ嶻")+l11l11ll11ll_l1_
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ嶼")+title
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嶽"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࠪ嶾") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ嶿")+title
		index = l1l111_l1_ (u"ࠫ࠷ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ巀")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巁"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭巂") in str(item):
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ巃")+title
		index = l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ巄")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巅"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ巆") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ巇"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭巈"),9999)
	elif l11l1l111lll_l1_:
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ巉"),l1lllll_l1_+l11l1l111lll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ巊") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巋"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ巌")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ巍")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭巎") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ巏"),1)[0]
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ巐"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ巑") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ巒") in l1ll1ll_l1_ and count:
			l11l1l1111ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ巓"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ巔")+l11l1l1111ll_l1_
			index = l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ巕")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巖"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ巗")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ巘")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ巙"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ巚"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭巛") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡩ࠯ࠨ巜") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠬ࠵ࡀࠨ川") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"࠭࠯ࠨ州"))==3):
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ巟"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡅࡋࡒࡑ࠭巠")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭巡")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ巢") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巣"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪ巤")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ工")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ左")+title
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巧"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l11l1l1l11l1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_,token = False,l1l111_l1_ (u"ࠩࠪ巨"),l1l111_l1_ (u"ࠪࠫ巩"),l1l111_l1_ (u"ࠫࠬ巪"),l1l111_l1_ (u"ࠬ࠭巫"),l1l111_l1_ (u"࠭ࠧ巬"),l1l111_l1_ (u"ࠧࠨ巭"),l1l111_l1_ (u"ࠨࠩ差"),l1l111_l1_ (u"ࠩࠪ巯")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_,token
	for l11l11lllll1_l1_ in list(item.keys()):
		yrender = item[l11l11lllll1_l1_]
		if isinstance(yrender,dict): break
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ巰"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡌࡪࡵࡷࡌࡪࡧࡤࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ己"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡱ࡯࡮ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ已"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡷࡱࡴࡱࡧࡹࡢࡤ࡯ࡩ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ巳"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡩࡳࡷࡳࡡࡵࡶࡨࡨ࡙࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ巴"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ巵"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ巶"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ巷"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ巸"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ巹"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ巺"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ巻"))
	succeeded,title,l1111ll1_l1_ = l11l11l1l111_l1_(item,yrender,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ巼"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ巽"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ巾"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ巿"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ帀"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ币"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ市"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l11l11l1l111_l1_(item,yrender,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ布"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ帄"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ帅"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l11l11l1l111_l1_(item,yrender,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࠪࡡࠧ帆"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࡘࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ帇"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡂࡰࡶࡷࡳࡲࡖࡡ࡯ࡧ࡯ࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ师"))
	succeeded,count,l1111ll1_l1_ = l11l11l1l111_l1_(item,yrender,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ帉"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ帊"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡱ࡫࡮ࡨࡶ࡫ࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ帋"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࠩࡠ࡟ࠬ࡯ࡣࡰࡰࡗࡽࡵ࡫ࠧ࡞ࠤ希"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡹࡴࡺ࡮ࡨࠫࡢࠨ帍"))
	succeeded,l1l1lll111_l1_,l1111ll1_l1_ = l11l11l1l111_l1_(item,yrender,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ帎"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ帏"))
	succeeded,token,l1111ll1_l1_ = l11l11l1l111_l1_(item,yrender,l11l11l1l1l1_l1_)
	if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ帐") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l111lll_l1_ = l1l111_l1_ (u"ࠨࠩ帑"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ帒")
	if l1l111_l1_ (u"้ࠪออิาࠩ帓") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l111lll_l1_ = l1l111_l1_ (u"ࠫࠬ帔"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭帕")
	if l1l111_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭帖") in list(yrender.keys()):
		l11l1l11l1ll_l1_ = str(yrender[l1l111_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ帗")])
		if l1l111_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ帘") in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠩࠧ࠾ࠥࠦࠧ帙")
		if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ帚") in l11l1l11l1ll_l1_: l11l1l111lll_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ帛")
		if l1l111_l1_ (u"ࠬࡈࡵࡺࠩ帜") in l11l1l11l1ll_l1_ or l1l111_l1_ (u"࠭ࡒࡦࡰࡷࠫ帝") in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭帞")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡶ่ࠩฬฬฺัࠨ帟")) in l11l1l11l1ll_l1_: l11l1l111lll_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ帠")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡸูࠫืวยࠩ帡")) in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ帢")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡺ࠭วิฬษะฬืࠧ帣")) in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ帤")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ帥")) in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠨࠦ࠽ࠤࠥ࠭带")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ帧") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠪࡃࠬ帨"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ帩") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ帪")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l11llll11_l1_: title = l11l11llll11_l1_+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"࠭ࠬࠨ師"),l1l111_l1_ (u"ࠧࠨ帬"))
	count = count.replace(l1l111_l1_ (u"ࠨ࠮ࠪ席"),l1l111_l1_ (u"ࠩࠪ帮"))
	count = re.findall(l1l111_l1_ (u"ࠪࡠࡩ࠱ࠧ帯"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠫࠬ帰")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_,token
def l11l11lll1ll_l1_(url,data=l1l111_l1_ (u"ࠬ࠭帱"),request=l1l111_l1_ (u"࠭ࠧ帲")):
	if request==l1l111_l1_ (u"ࠧࠨ帳"): request = l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ帴")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭帵"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ帶"):l1l111_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ帷")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ常"))
	if data.count(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ帹"))==4: l11l1l111l1l_l1_,key,l11l1l111111_l1_,l11l11llll1l_l1_,token = data.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ帺"))
	else: l11l1l111l1l_l1_,key,l11l1l111111_l1_,l11l11llll1l_l1_,token = l1l111_l1_ (u"ࠨࠩ帻"),l1l111_l1_ (u"ࠩࠪ帼"),l1l111_l1_ (u"ࠪࠫ帽"),l1l111_l1_ (u"ࠫࠬ帾"),l1l111_l1_ (u"ࠬ࠭帿")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ幀"):{l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ幁"):{l1l111_l1_ (u"ࠣࡪ࡯ࠦ幂"):l1l111_l1_ (u"ࠤࡤࡶࠧ幃"),l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ幄"):l1l111_l1_ (u"ࠦ࡜ࡋࡂࠣ幅"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ幆"):l11l1l111111_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ幇") or l1l111_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ幈") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ幉")+l1l111_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ幊")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ幋")] = l11l1l111l1l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ幌"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ幍"))
	elif l1l111_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ幎") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ幏")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭幐"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ幑"))
	elif l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ幒") in url and l11l1l111l1l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ幓")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭幔")][l1l111_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭幕")][l1l111_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ幖")] = l11l1l111l1l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭幗"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ幘"))
	elif l1l111_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ幙") in url and l11l11llll1l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ幚"):l1l111_l1_ (u"ࠬ࠷ࠧ幛"),l1l111_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ幜"):l11l1l111111_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ幝"):l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ幞")+l11l11llll1l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭幟"),url,l1l111_l1_ (u"ࠪࠫ幠"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ幡"),l1l111_l1_ (u"ࠬ࠭幢"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ幣"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ幤"),url,l1l111_l1_ (u"ࠨࠩ幥"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ幦"),l1l111_l1_ (u"ࠪࠫ幧"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ幨"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ幩"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ幪"),html,re.DOTALL|re.I)
	if tmp: l11l1l111111_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ幫"),html,re.DOTALL|re.I)
	if tmp: l11l1l111l1l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭幬") in list(cookies.keys()): l11l11llll1l_l1_ = cookies[l1l111_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ幭")]
	l1l1l1111_l1_ = l11l1l111l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ幮")+key+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ幯")+l11l1l111111_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ幰")+l11l11llll1l_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ幱")+token
	if request==l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ干") and l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ平") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ年"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ幵"),html,re.DOTALL)
		l11l1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ并"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ幷") and l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ幸") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭幹"),html,re.DOTALL)
		l11l1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ幺"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"ࠩ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ幻") not in html: l11l1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ幼"),html)
	else: l11l1l11l1l1_l1_ = l1l111_l1_ (u"ࠫࠬ幽")
	if 0:
		yccc = str(l11l1l11l1l1_l1_)
		if PY3: yccc = yccc.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ幾"))
		open(l1l111_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳ࡪࡡࡵࠩ广"),l1l111_l1_ (u"ࠧࡸࡤࠪ庀")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ庁"),l1l1l1111_l1_)
	return html,l11l1l11l1l1_l1_,l1l1l1111_l1_
def l11l1l11lll1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ庂"),l1l111_l1_ (u"ࠪ࠯ࠬ広"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ庄")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ庅"),l1l111_l1_ (u"࠭ࠫࠨ庆"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ庇")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ庈") in options: l11l11ll1l1l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ庉")
		elif l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ床") in options: l11l11ll1l1l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ庋")
		elif l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ庌") in options: l11l11ll1l1l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭庍")
		else: l11l11ll1l1l_l1_ = l1l111_l1_ (u"ࠧࠨ庎")
		l1llllll_l1_ = l1lllll1_l1_+l11l11ll1l1l_l1_
	else:
		l11l11ll1l11_l1_,l11l11l11lll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠨࠩ序")
		l11l11l1l11l_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭庐"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ庑"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ庒"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ库"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ应")]
		l11l1l11l11l_l1_ = [l1l111_l1_ (u"ࠧࠨ底"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ庖"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ店"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ庘"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ庙")]
		l11l1l11ll11_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ庚"),l11l11l1l11l_l1_)
		if l11l1l11ll11_l1_ == -1: return
		l11l11ll11l1_l1_ = l11l1l11l11l_l1_[l11l1l11ll11_l1_]
		html,c,data = l11l11lll1ll_l1_(l1lllll1_l1_+l11l11ll11l1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ庛")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ府")][l1l111_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ庝")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ庞")][l1l111_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ废")][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ庠")][l1l111_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ庡")]
				for l11l11l11ll1_l1_ in range(len(d)):
					group = d[l11l11l11ll1_l1_][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ庢")][l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ庣")]
					for l11l1l11llll_l1_ in range(len(group)):
						yrender = group[l11l1l11llll_l1_][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ庤")]
						if l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ庥") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ度")][l1l111_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭座")][l1l111_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ庨")][l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ庩")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ庪"),l1l111_l1_ (u"ࠨࠨࠪ庫"))
							title = yrender[l1l111_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ庬")]
							title = title.replace(l1l111_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭庭"),l1l111_l1_ (u"ࠫࠬ庮"))
							if l1l111_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ庯") in title: continue
							if l1l111_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ庰") in title:
								title = l1l111_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ庱")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ庲") in title: continue
							title = title.replace(l1l111_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ庳"),l1l111_l1_ (u"ࠪࠫ庴"))
							if l1l111_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ庵") in title: continue
							if l1l111_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ庶") in title:
								title = l1l111_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ康")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ庸") in title: continue
							l11l11ll1l11_l1_.append(escapeUNICODE(title))
							l11l11l11lll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l11l1l11l111_l1_ = l1l111_l1_ (u"ࠨࠩ庹")
		else:
			l11l11ll1l11_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ庺"),l1lllllll_l1_]+l11l11ll1l11_l1_
			l11l11l11lll_l1_ = [l1l111_l1_ (u"ࠪࠫ庻"),l111lllll_l1_]+l11l11l11lll_l1_
			l11l1l1l111l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ庼"),l11l11ll1l11_l1_)
			if l11l1l1l111l_l1_ == -1: return
			l11l1l11l111_l1_ = l11l11l11lll_l1_[l11l1l1l111l_l1_]
		if l11l1l11l111_l1_: l1llllll_l1_ = l111l1_l1_+l11l1l11l111_l1_
		elif l11l11ll11l1_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l11ll11l1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
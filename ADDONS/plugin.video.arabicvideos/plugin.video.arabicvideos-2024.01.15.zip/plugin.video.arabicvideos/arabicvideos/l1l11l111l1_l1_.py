# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback,threading
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡏࡍࡇ࡙ࡏࡏࡇࠪㆱ")
l1l1l1l1lll_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠪࡴࡦࡺࡨࠨㆲ"))
l1l111ll11l_l1_ = os.path.join(l1l1l1l1lll_l1_,l1l111_l1_ (u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࠭ㆳ"))
sys.path.append(l1l111ll11l_l1_)
l1l1l11ll11_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࡙ࠧࡹࡴࡶࡨࡱ࠳ࡈࡵࡪ࡮ࡧ࡚ࡪࡸࡳࡪࡱࡱࠦㆴ"))
kodi_version = re.findall(l1l111_l1_ (u"࠭ࠨ࡝ࡦ࡟ࡨࡡ࠴࡜ࡥࠫࠪㆵ"),l1l1l11ll11_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1ll11lll_l1_ = xbmc.Player
l1l1l1lllll_l1_ = xbmcgui.WindowXMLDialog
PY2 = kodi_version<19
PY3 = kodi_version>18.99
if PY3:
	l1ll111l1ll_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨㆶ"),l1l111_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩㆷ")
	l1l1l1111l1_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪㆸ"))
	from urllib.parse import unquote as _1l1l11l1ll_l1_
else:
	l1ll111l1ll_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫㆹ").encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩㆺ")),l1l111_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭ㆻ").encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫㆼ"))
	l1l1l1111l1_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨㆽ"))
	from urllib import unquote as _1l1l11l1ll_l1_
l1l1lll11l1_l1_ = 60
l1l1l111111_l1_ = 60*l1l1lll11l1_l1_
l1l11llll11_l1_ = 24*l1l1l111111_l1_
l1l1ll1ll1l_l1_ = 30*l1l11llll11_l1_
l1ll1ll1_l1_ = 3*l1l11llll11_l1_
l1ll111ll11_l1_ = 12*l1l1ll1ll1l_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"ࠨ࠱ࠪㆾ"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1llll1l1_l1_ = addon_id.split(l1l111_l1_ (u"ࠩ࠱ࠫㆿ"))[2]
l1l11l1l1l1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡘࡨࡶࡸ࡯࡯࡯ࠪࠪ㇀")+addon_id+l1l111_l1_ (u"ࠫ࠮࠭㇁"))
addoncachefolder = os.path.join(l1l1l1111l1_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡧࡥࡹࡧ࠮ࡥࡤࠪ㇂"))
l1l1l11l111_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭࡬ࡢࡵࡷࡺ࡮ࡪࡥࡰࡵ࠱ࡨࡦࡺࠧ㇃"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url):
	if l1l111_l1_ (u"ࠧ࠾ࠩ㇄") in url:
		if l1l111_l1_ (u"ࠨࡁࠪ㇅") in url: l1lllll1_l1_,filters = url.split(l1l111_l1_ (u"ࠩࡂࠫ㇆"),1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"ࠪࠫ㇇"),url
		filters = filters.split(l1l111_l1_ (u"ࠫࠫ࠭㇈"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠬࡃࠧ㇉"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l11l1ll_l1_(urll)
def EXTRACT_KODI_PATH(l1l11l11111_l1_):
	l1ll11111ll_l1_ = {l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ㇊"):l1l111_l1_ (u"ࠧࠨ㇋"),l1l111_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭㇌"):l1l111_l1_ (u"ࠩࠪ㇍"),l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㇎"):l1l111_l1_ (u"ࠫࠬ㇏"),l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪ㇐"):l1l111_l1_ (u"࠭ࠧ㇑"),l1l111_l1_ (u"ࠧࡱࡣࡪࡩࠬ㇒"):l1l111_l1_ (u"ࠨࠩ㇓"),l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㇔"):l1l111_l1_ (u"ࠪࠫ㇕"),l1l111_l1_ (u"ࠫ࡮ࡳࡡࡨࡧࠪ㇖"):l1l111_l1_ (u"ࠬ࠭㇗"),l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ㇘"):l1l111_l1_ (u"ࠧࠨ㇙"),l1l111_l1_ (u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪ㇚"):l1l111_l1_ (u"ࠩࠪ㇛")}
	if l1l111_l1_ (u"ࠪࡃࠬ㇜") in l1l11l11111_l1_: l1l11l11111_l1_ = l1l11l11111_l1_.split(l1l111_l1_ (u"ࠫࡄ࠭㇝"),1)[1]
	l1lllll1_l1_,l1ll11111l1_l1_ = l1ll11ll1_l1_(l1l11l11111_l1_)
	args = dict(list(l1ll11111ll_l1_.items())+list(l1ll11111l1_l1_.items()))
	l1l111ll1l1_l1_ = args[l1l111_l1_ (u"ࠬࡳ࡯ࡥࡧࠪ㇞")]
	l1l1l1l11l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㇟")])
	l1l11lll1l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠧࡵࡧࡻࡸࠬ㇠")])
	l1l111l1l11_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭㇡")])
	l1l111l11ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ㇢")])
	l1l11lll1ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ㇣")])
	l1l1ll111l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫ࡮ࡳࡡࡨࡧࠪ㇤")])
	l1l11lll111_l1_ = args[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭㇥")]
	l1l1l11l11l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨ㇦")])
	if l1l1l11l11l_l1_: l1l1l11l11l_l1_ = eval(l1l1l11l11l_l1_)
	else: l1l1l11l11l_l1_ = {}
	if not l1l111ll1l1_l1_: l1l111l11ll_l1_ = l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㇧") ; l1l111ll1l1_l1_ = l1l111_l1_ (u"ࠨ࠴࠹࠴ࠬ㇨")
	return l1l111l11ll_l1_,l1l11lll1ll_l1_,l1l1l1l11l1_l1_,l1l111ll1l1_l1_,l1l1ll111l1_l1_,l1l111l1l11_l1_,l1l11lll1l1_l1_,l1l11lll111_l1_,l1l1l11l11l_l1_
def l11lllll1l_l1_(l1ll1_l1_):
	l1l11lll11l_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l11lll11l_l1_ or l1l11lll11l_l1_==l1l111_l1_ (u"ࠩ࠿ࡱࡴࡪࡵ࡭ࡧࡁࠫ㇩"):
		return l1l111_l1_ (u"ࠪ࡟ࠥ࠭㇪")+l1l1llll1l1_l1_.upper()+l1l111_l1_ (u"ࠫ࠲࠭㇫")+l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠬ࠳ࠧ㇬")+str(kodi_version)+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㇭")
	return l1l111_l1_ (u"ࠧ࠯ࠢࠣࠫ㇮")+l1l11lll11l_l1_
def l1l111111l_l1_(level,message):
	if PY2: message = message.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㇯")).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㇰ"))
	l1l11l1ll11_l1_ = l1ll111l1ll_l1_
	lines = [l1l111_l1_ (u"ࠪࠫㇱ"),l1l111_l1_ (u"ࠫࠬㇲ")]
	if level: message = message.replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨㇳ"),l1l111_l1_ (u"࠭ࠧㇴ")).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪㇵ"),l1l111_l1_ (u"ࠨࠩㇶ")).replace(l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㇷ"),l1l111_l1_ (u"ࠪࠫㇸ"))
	else: level = l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫㇹ")
	l11ll1111l_l1_,sep,shift = l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪㇺ"),l1l111_l1_ (u"࠭ࠠࠡࠢࠪㇻ"),l1l111_l1_ (u"ࠧࠨㇼ")
	if l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘࠧㇽ") in level: l1l11l1ll11_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧㇾ"):
		message = message+sep
		lines = message.split(sep)
		shift = l11ll1111l_l1_
	elif level==l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩㇿ"):
		message = message.replace(l1l111_l1_ (u"ࠫ࠳࠭㈀")+sep,l1l111_l1_ (u"ࠬ࠴ࠠࠡࠩ㈁"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"࠭࠮ࠨ㈂")+lines[0][1:]
		shift = l11ll1111l_l1_+sep
	elif level in [l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㈃"),l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘࠧ㈄")]: lines = message.split(l11ll1111l_l1_)
	shift += 6*l11ll1111l_l1_
	l1l11l1llll_l1_ = 3*l11ll1111l_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"ࠩࠣࠫ㈅")
	l1l1ll1l1l1_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"ࠪࡠࡳ࠭㈆") in line: line = line.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㈇"),l1l111_l1_ (u"ࠬࡢ࡮ࠨ㈈")+l11ll1111l_l1_+l11ll1111l_l1_)
		l1l11l1llll_l1_ += l11ll1111l_l1_
		l1l1ll1l1l1_l1_ += l1l111_l1_ (u"࠭࡜ࡳࠩ㈉")+shift+l1l11l1llll_l1_+line
	l1l1ll1l1l1_l1_ += l1l111_l1_ (u"ࠧࠡࡡࠪ㈊")
	if l1l111_l1_ (u"ࠨࠧࠪ㈋") in l1l1ll1l1l1_l1_: l1l1ll1l1l1_l1_ = l111l11_l1_(l1l1ll1l1l1_l1_)
	xbmc.log(l1l1ll1l1l1_l1_,level=l1l11l1ll11_l1_)
	return
def l1l1lllll11_l1_(l1ll1lll1l_l1_):
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨ㈌"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭㈍"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭㈎"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩ㈏"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫ㈐"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪ㈑"))
	conn.text_factory = str
	return conn,l1llll1lll_l1_
def l1lll1ll1l1_l1_(l1ll1lll1l_l1_,table,l1l1l11lll1_l1_=None):
	try: conn,l1llll1lll_l1_ = l1l1lllll11_l1_(l1ll1lll1l_l1_)
	except: return
	if l1l1l11lll1_l1_==None: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ㈒")+table+l1l111_l1_ (u"ࠩࠥࠤࡀ࠭㈓"))
	else:
		tt = (str(l1l1l11lll1_l1_),)
		try:
			if l1l111_l1_ (u"ࠪࠩࠬ㈔") in l1l1l11lll1_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㈕")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨ㈖"),tt)
			else: l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭㈗")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㈘"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1ll1lll1_l1_(): pass
class l1l1llllll1_l1_(l1l1ll1lll1_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"ࠨࠩ㈙")
		self.code = -99
		self.reason = l1l111_l1_ (u"ࠩࠪ㈚")
		self.content = l1l111_l1_ (u"ࠪࠫ㈛")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l11ll1l_l1_(type):
	if type==l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㈜"): data = {}
	elif type==l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ㈝"): data = []
	elif type==l1l111_l1_ (u"࠭ࡳࡵࡴࠪ㈞"): data = l1l111_l1_ (u"ࠧࠨ㈟")
	elif type==l1l111_l1_ (u"ࠨ࡫ࡱࡸࠬ㈠"): data = 0
	elif type==l1l111_l1_ (u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ㈡"): data = l1l1llllll1_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1l11ll1lll_l1_(l1ll111111l_l1_):
	from hashlib import md5
	l1l11ll1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㈢"))
	l1l1ll1l1ll_l1_ = l1l1ll11l11_l1_(32).splitlines()
	for l1l11l11l11_l1_ in l1l1ll1l1ll_l1_:
		l1l11l11l11_l1_ = l1l11l11l11_l1_[-24:]
		l1l1l1ll11l_l1_ = md5((l1l111_l1_ (u"ࠫ࡝࠷࠹ࠨ㈣")+l1ll111111l_l1_+l1l111_l1_ (u"ࠬ࠷࠸࠾ࠩ㈤")+l1l11l11l11_l1_).encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㈥"))).hexdigest()[:32]
		if l1l1l1ll11l_l1_ in l1l11ll1l11_l1_:
			return True
	return False
def l1lll11l1ll_l1_(l1ll1lll1l_l1_,l1l1l1ll1l1_l1_,table,l1l1l11lll1_l1_=None):
	data = l1l1l11ll1l_l1_(l1l1l1ll1l1_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㈦"))
	if table!=l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㈧") and l1ll1lll1l_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㈨"): return data
		l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㈩"))
		if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㈪"):
			l1lll1ll1l1_l1_(l1ll1lll1l_l1_,table,l1l1l11lll1_l1_)
			return data
	l1ll111ll1l_l1_ = 0
	if cache==l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㈫"): l1ll111ll1l_l1_ = l1l11l1l11l_l1_
	try: conn,l1llll1lll_l1_ = l1l1lllll11_l1_(l1ll1lll1l_l1_)
	except: return data
	l1l1l111ll1_l1_ = True
	try: l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠢࠨ㈬")+table+l1l111_l1_ (u"ࠧࠣࠢࡏࡍࡒࡏࡔࠡ࠳ࠣ࠿ࠬ㈭"))
	except: l1l1l111ll1_l1_ = False
	if l1l1l111ll1_l1_:
		if l1ll111ll1l_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㈮")+table+l1l111_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫ㈯")+str(now+l1ll111ll1l_l1_)+l1l111_l1_ (u"ࠪࠤࡀ࠭㈰"))
		conn.commit()
		l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㈱")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧ㈲")+str(now)+l1l111_l1_ (u"࠭ࠠ࠼ࠩ㈳"))
		conn.commit()
		if l1l1l11lll1_l1_:
			tt = (str(l1l1l11lll1_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬ㈴")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㈵"),tt)
			l1l1l11111l_l1_ = l1llll1lll_l1_.fetchall()
			if l1l1l11111l_l1_:
				try:
					text = zlib.decompress(l1l1l11111l_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ㈶")+table+l1l111_l1_ (u"ࠪࠦࠥࡁࠧ㈷"))
			l1l1l11111l_l1_ = l1llll1lll_l1_.fetchall()
			if l1l1l11111l_l1_:
				data,l1l1llll1ll_l1_ = {},[]
				for l1l1ll1l111_l1_,l1l11llll_l1_ in l1l1l11111l_l1_:
					l1ll1ll11l_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1ll11l_l1_)
					data[l1l1ll1l111_l1_] = l1l11llll_l1_
					l1l1llll1ll_l1_.append(l1l1ll1l111_l1_)
				if l1l1llll1ll_l1_:
					data[l1l111_l1_ (u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬ㈸")] = l1l1llll1ll_l1_
					if l1l1l1ll1l1_l1_==l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ㈹"): data = l1l1llll1ll_l1_
	conn.close()
	return data
def l1l1ll11l11_l1_(l1l1l1l1111_l1_,l1l1lll111l_l1_=True):
	l1l1ll11ll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ㈺"))
	l1l111llll1_l1_ = []
	l1l1ll1l11l_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㈻"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㈼"),l1l111_l1_ (u"ࠩࡌࡈࡘ࠸ࠧ㈽"))
	if l1l1ll1l11l_l1_:
		l1l111llll1_l1_,l1l11l1lll1_l1_ = l1l1ll1l11l_l1_
		if l1l1ll11ll1_l1_!=l1l11l1lll1_l1_: l1l111llll1_l1_ = []
		elif l1l1lll111l_l1_: return l1l111_l1_ (u"ࠪࡠࡳ࠭㈾").join(l1l111llll1_l1_)
	l1l1l1l1111_l1_ = l1l1l1l1111_l1_//2
	if not l1l1llll111_l1_:
		l1l11l11l1l_l1_ = threading.Thread(target=l1l1l111lll_l1_)
		l1l11l11l1l_l1_.start()
	if not l1l1lll1lll_l1_:
		l1l11l11ll1_l1_ = threading.Thread(target=l1l1ll1111l_l1_)
		l1l11l11ll1_l1_.start()
	l1l1lll1ll1_l1_,l1l1lll1l1l_l1_,l1l1l111l11_l1_ = l1l111_l1_ (u"ࠫࠬ㈿"),l1l111_l1_ (u"ࠬ࠭㉀"),l1l111_l1_ (u"࠭࠰࠱࠳࠴࠶࠷࠹࠳࠵࠶࠸࠹࠻࠼࠷࠸ࠩ㉁")
	for l1l111llll_l1_ in range(10):
		time.sleep(0.5)
		if not l1l1lll1ll1_l1_:
			try:
				l1ll111l111_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡏࡧࡷࡻࡴࡸ࡫࠯ࡏࡤࡧࡆࡪࡤࡳࡧࡶࡷࠬ㉂"))
				if l1ll111l111_l1_.count(l1l111_l1_ (u"ࠨ࠼ࠪ㉃"))==5 and l1ll111l111_l1_.count(l1l111_l1_ (u"ࠩ࠳ࠫ㉄"))<9:
					l1ll111l111_l1_ = l1ll111l111_l1_.lower().replace(l1l111_l1_ (u"ࠪ࠾ࠬ㉅"),l1l111_l1_ (u"ࠫࠬ㉆"))
					l1l1lll1ll1_l1_ = str(int(l1ll111l111_l1_,16))
			except: pass
		if l1l1llll111_l1_ and l1l1lll1lll_l1_ and l1l1lll1ll1_l1_: break
	try:
		l1l11ll1l1l_l1_ = open(l1l111_l1_ (u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬ㉇"),l1l111_l1_ (u"࠭ࡲࡣࠩ㉈")).read()
		if PY3: l1l11ll1l1l_l1_ = l1l11ll1l1l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㉉"))
		l1l111ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡕࡨࡶ࡮ࡧ࡬࠯ࠬࡂ࠾ࠥ࠮࠮ࠫࡁࠬࠨࠬ㉊"),l1l11ll1l1l_l1_,re.IGNORECASE)
		if l1l111ll1ll_l1_:
			l1l111ll1ll_l1_ = l1l111ll1ll_l1_[0].strip(l1l111_l1_ (u"ࠩ࠳ࠫ㉋"))
			if l1l111ll1ll_l1_:
				from hashlib import md5
				if PY3: l1l111ll1ll_l1_ = l1l111ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㉌"))
				l1l111ll1ll_l1_ = str(int(md5(l1l111ll1ll_l1_).hexdigest(),36))
				l1l111ll1ll_l1_ = [int(l1l111ll1ll_l1_[l1ll111l11l_l1_:l1ll111l11l_l1_+15]) for l1ll111l11l_l1_ in range(len(l1l111ll1ll_l1_)) if l1ll111l11l_l1_%15==0]
				l1l1lll1l1l_l1_ = str(sum(l1l111ll1ll_l1_))
	except: pass
	found = False
	l1ll1111l11_l1_ = [l1l1llll111_l1_,l1l1lll1lll_l1_,l1l1lll1ll1_l1_,l1l1lll1l1l_l1_,l1l1l111l11_l1_]
	for l1l1l1l11ll_l1_ in range(len(l1ll1111l11_l1_)):
		l1l1ll11l1l_l1_ = l1ll1111l11_l1_[l1l1l1l11ll_l1_]
		if not l1l1ll11l1l_l1_: continue
		if found and l1l1ll11l1l_l1_==l1l1l111l11_l1_: continue
		found = True
		l1l1ll11l1l_l1_ = l1l1l1l1111_l1_*l1l111_l1_ (u"ࠫ࠵࠭㉍")+l1l1ll11l1l_l1_
		l1l1ll11l1l_l1_ = l1l1ll11l1l_l1_[-l1l1l1l1111_l1_:]
		mm,ss = l1l111_l1_ (u"ࠬ࠭㉎"),l1l111_l1_ (u"࠭ࠧ㉏")
		l1l11lllll1_l1_ = str(int(l1l111_l1_ (u"ࠧ࠺ࠩ㉐")*(l1l1l1l1111_l1_+1))-int(l1l1ll11l1l_l1_))[-l1l1l1l1111_l1_:]
		for l1l111llll_l1_ in list(range(0,l1l1l1l1111_l1_,4)):
			l1l11l1l111_l1_ = l1l11lllll1_l1_[l1l111llll_l1_:l1l111llll_l1_+4]
			mm += l1l11l1l111_l1_+l1l111_l1_ (u"ࠨ࠯ࠪ㉑")
			ss += str(sum(map(int,l1l1ll11l1l_l1_[l1l111llll_l1_:l1l111llll_l1_+4]))%10)
		l1l1ll1ll11_l1_ = str(l1l1l1l11ll_l1_)+mm+ss
		l1l111llll1_l1_.append(l1l1ll1ll11_l1_)
	l1l111llll1_l1_ = sorted(list(set(l1l111llll1_l1_)))
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㉒"),l1l111_l1_ (u"ࠪࡍࡉ࡙࠲ࠨ㉓"),[l1l111llll1_l1_,l1l1ll11ll1_l1_],l1ll1ll1_l1_)
	return l1l111_l1_ (u"ࠫࡡࡴࠧ㉔").join(l1l111llll1_l1_)
class l1l1l1l1ll1_l1_(l1l1ll11lll_l1_):
	def __init__(self): self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠬ࠭㉕")
	def init(self,l1l11ll111l_l1_):
		self.l1l11ll111l_l1_ = l1l11ll111l_l1_
		self.l1ll111l1l1_l1_ = l1l11ll1lll_l1_(l1l111_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ㉖"))
		self.l1l1ll11111_l1_ = l1l11ll1lll_l1_(l1l111_l1_ (u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨ㉗"))
		self.l1l1l11llll_l1_ = l1l11ll1lll_l1_(l1l111_l1_ (u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭㉘"))
		if self.l1ll111l1l1_l1_: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ㉙")
		elif self.l1l1ll11111_l1_: return
		elif self.l1l1l11llll_l1_:
			from l1l1l1111ll_l1_ import l1l1l1l1l1l_l1_
			l1l1l1l1l1l_l1_(False)
		else:
			self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ㉚")
			from l1l1l1111ll_l1_ import l1l1l1l1l1l_l1_
			l1l1l1l1l1l_l1_(False)
	def onPlayBackStopped(self): self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㉛")
	def onPlayBackError(self): self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㉜")
	def onPlayBackEnded(self): self.l1l1lll1l11_l1_ = l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㉝")
	def onPlayBackStarted(self):
		self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ㉞")
		l1l111lll1l_l1_ = threading.Thread(target=self.l1l11l111ll_l1_,args=())
		l1l111lll1l_l1_.start()
	def l1l1llll11l_l1_(self):
		if self.l1ll111l1l1_l1_: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㉟")
		elif self.l1l1ll11111_l1_: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㉠")
		elif self.l1l1l11llll_l1_: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ㉡")
		else: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㉢")
	def l1l11l111ll_l1_(self):
		l1l1l1l111l_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨ㉣")) and self.l1l1lll1l11_l1_==l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ㉤"):
			xbmc.sleep(1500)
			l1l1l1l111l_l1_ += 1.5
			if l1l1l1l111l_l1_>60: return
		if self.l1ll111l1l1_l1_: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㉥")
		elif self.l1l1ll11111_l1_: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㉦")
		elif self.l1l1l11llll_l1_:
			self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ㉧")
			from LIBSTWO import l1l1ll111ll_l1_,l1l111l1l1l_l1_
			l1l111lll11_l1_ = threading.Thread(target=l1l1ll111ll_l1_,args=(self.l1l11ll111l_l1_,))
			l1l111lll11_l1_.start()
			l1l111lllll_l1_ = threading.Thread(target=l1l111l1l1l_l1_,args=())
			l1l111lllll_l1_.start()
		else: self.l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ㉨")
def l1l1l1ll1ll_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㉩"),l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㉪")).replace(l1l111_l1_ (u"࠭࡜ࡳࠩ㉫"),l1l111_l1_ (u"ࠧ࡝࡞ࡵࠫ㉬")).replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭㉭"),l1l111_l1_ (u"ࠩࠣࠫ㉮")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ㉯"),l1l111_l1_ (u"ࠫࠥ࠭㉰"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠬࠦ࠮࠯࠰ࠪ㉱")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㉲"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㉳")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㉴"),l1l111_l1_ (u"ࠩ࡟ࡠࡷ࠭㉵")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ㉶"),l1l111_l1_ (u"ࠫࠥ࠭㉷")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㉸"),l1l111_l1_ (u"࠭ࠠࠨ㉹"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠧࠡ࠰࠱࠲ࠬ㉺")
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㉻"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧ㉼")+type+l1l111_l1_ (u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㉽")+url+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㉾")+source+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧ㉿")+method+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩ㊀")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧ㊁")+l1l11llll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㊂"))
	return
l1l1llll111_l1_ = l1l111_l1_ (u"ࠩࠪ㊃")
def l1l1l111lll_l1_():
	global l1l1llll111_l1_
	try:
		import getmac82
		l1ll1111ll1_l1_ = getmac82.get_mac_address()
		if l1ll1111ll1_l1_.count(l1l111_l1_ (u"ࠪ࠾ࠬ㊄"))==5 and l1ll1111ll1_l1_.count(l1l111_l1_ (u"ࠫ࠵࠭㊅"))<9:
			l1ll1111ll1_l1_ = l1ll1111ll1_l1_.lower().replace(l1l111_l1_ (u"ࠬࡀࠧ㊆"),l1l111_l1_ (u"࠭ࠧ㊇"))
			l1l1llll111_l1_ = str(int(l1ll1111ll1_l1_,16))
	except: pass
	return
l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠧࠨ㊈")
def l1l1ll1111l_l1_():
	global l1l1lll1lll_l1_
	try:
		import getmac94
		l1ll1111lll_l1_ = getmac94.get_mac_address()
		if l1ll1111lll_l1_.count(l1l111_l1_ (u"ࠨ࠼ࠪ㊉"))==5 and l1ll1111lll_l1_.count(l1l111_l1_ (u"ࠩ࠳ࠫ㊊"))<9:
			l1ll1111lll_l1_ = l1ll1111lll_l1_.lower().replace(l1l111_l1_ (u"ࠪ࠾ࠬ㊋"),l1l111_l1_ (u"ࠫࠬ㊌"))
			l1l1lll1lll_l1_ = str(int(l1ll1111lll_l1_,16))
	except: pass
	return
def l1l111l1ll1_l1_(method,url,data=l1l111_l1_ (u"ࠬ࠭㊍"),headers=l1l111_l1_ (u"࠭ࠧ㊎"),source=l1l111_l1_ (u"ࠧࠨ㊏")):
	l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡒࡔࡊࡔ࡟ࡖࡔࡏࠫ㊐"),url,data,headers,source,method)
	if PY3: import urllib.request as l1l1lll1111_l1_
	else: import urllib2 as l1l1lll1111_l1_
	if not headers: headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㊑"):l1l111_l1_ (u"ࠪࠫ㊒")}
	if not data: data = {}
	if method==l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㊓"):
		url = url+l1l111_l1_ (u"ࠬࡅࠧ㊔")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㊕") and l1l111_l1_ (u"ࠧ࡫ࡵࡲࡲࠬ㊖") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㊗"))
	elif method==l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㊘"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㊙"))
	try:
		req = l1l1lll1111_l1_.Request(url,headers=headers,data=data)
		response = l1l1lll1111_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"ࠫࡔࡑࠧ㊚")
	except:
		html = l1l111_l1_ (u"ࠬ࠭㊛")
		code,reason = -1,l1l111_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭㊜")
	l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㊝"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㊞")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㊟")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㊠")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㊡")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㊢"))
	if html and PY3: html = html.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㊣"))
	return html
def l1ll1111111_l1_(l1l11ll11l1_l1_,l1l11ll11ll_l1_=l1l111_l1_ (u"ࠧࠨ㊤")):
	l1l11ll1111_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㊥"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ㊦")}
	l1l111l1111_l1_ = {	l1l111_l1_ (u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦ㊧"):l1l1ll11l11_l1_(32).splitlines()[0][-24:],
				l1l111_l1_ (u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣ㊨"):str(kodi_version),
				l1l111_l1_ (u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥ㊩"):l1l11l1l1l1_l1_,
				l1l111_l1_ (u"ࠨࡤࡦࡸ࡬ࡧࡪࡥࡦࡢ࡯࡬ࡰࡾࠨ㊪"):l1l11l1l1l1_l1_,
				l1l111_l1_ (u"ࠢࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠦ㊫"):l1l11ll11l1_l1_,
				l1l111_l1_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥ㊬"): l1l11l1l1l1_l1_,
				l1l111_l1_ (u"ࠤࡦࡥࡷࡸࡩࡦࡴࠥ㊭"):l1l111_l1_ (u"ࠥࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࠥ㊮"),
				l1l111_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ㊯"):{l1l111_l1_ (u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㊰"):l1l11ll11l1_l1_},
				l1l111_l1_ (u"ࠨࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ㊱"): {l1l111_l1_ (u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㊲"):l1l11ll11l1_l1_},
				l1l111_l1_ (u"ࠣࠦࡶ࡯࡮ࡶ࡟ࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࡡࡶࡽࡳࡩࠢ㊳"):False,
				l1l111_l1_ (u"ࠤ࡬ࡴࠧ㊴"): l1l111_l1_ (u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ㊵")
			}
	if not l1l11ll11ll_l1_: l1l11l1111l_l1_ = [l1l111l1111_l1_]
	else:
		l1l111l111l_l1_ = l1l111l1111_l1_.copy()
		l1l111l111l_l1_[l1l111_l1_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ㊶")] = l1l11ll11ll_l1_
		l1l111l111l_l1_[l1l111_l1_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ㊷")] = {l1l111_l1_ (u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㊸"):l1l11ll11ll_l1_}
		l1l111l111l_l1_[l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ㊹")] = {l1l111_l1_ (u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㊺"):l1l11ll11ll_l1_}
		l1l11l1111l_l1_ = [l1l111l1111_l1_,l1l111l111l_l1_]
	data = {l1l111_l1_ (u"ࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ㊻"):l1l111_l1_ (u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ㊼"),
			l1l111_l1_ (u"ࠦ࡮ࡴࡳࡦࡴࡷࡣ࡮ࡪࠢ㊽"):l1l11ll1111_l1_,
			l1l111_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡷࠧ㊾"): l1l11l1111l_l1_
		}
	url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ㊿")
	html = l1l111l1ll1_l1_(l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㋀"),url,data,headers,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭㋁"))
	return html
def l1ll1l1_l1_(l1l1l1ll1l1_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠩࡱࡹࡱࡲࠧ㋂"),l1l111_l1_ (u"ࠪࡒࡴࡴࡥࠨ㋃"))
	text = text.replace(l1l111_l1_ (u"ࠫࡹࡸࡵࡦࠩ㋄"),l1l111_l1_ (u"࡚ࠬࡲࡶࡧࠪ㋅"))
	text = text.replace(l1l111_l1_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ㋆"),l1l111_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭㋇"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ㋈"),l1l111_l1_ (u"ࠩ࠲ࠫ㋉"))
	try: l1ll1ll11l_l1_ = eval(text)
	except: l1ll1ll11l_l1_ = l1l1l11ll1l_l1_(l1l1l1ll1l1_l1_)
	return l1ll1ll11l_l1_
def l1l1l1lll1l_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦ࡜࡜࠱ࡆࡓࡑࡕࡒ࡝࡟ࠪ㋊"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"ࠫࡤࠫ࡭࠯ࠧࡧࡣࠪࡎ࠺ࠦࡏࡢࠫ㋋"),time.localtime(now))
	name = name+datetime
	l1lll11l11l_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
	if os.path.exists(l1l1l11l111_l1_):
		l1l11ll1ll1_l1_ = open(l1l1l11l111_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㋌")).read()
		if PY3: l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㋍"))
		l1l11ll1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㋎"),l1l11ll1ll1_l1_)
	else: l1l11ll1ll1_l1_ = {}
	l1l11l1l1ll_l1_ = {}
	for l1l1lll11ll_l1_ in list(l1l11ll1ll1_l1_.keys()):
		if l1l1lll11ll_l1_!=type: l1l11l1l1ll_l1_[l1l1lll11ll_l1_] = l1l11ll1ll1_l1_[l1l1lll11ll_l1_]
		else:
			if name and name!=l1l111_l1_ (u"ࠨ࠰࠱ࠫ㋏"):
				l1l11l11lll_l1_ = l1l11ll1ll1_l1_[l1l1lll11ll_l1_]
				if l1lll11l11l_l1_ in l1l11l11lll_l1_:
					index = l1l11l11lll_l1_.index(l1lll11l11l_l1_)
					del l1l11l11lll_l1_[index]
				l111l1ll11_l1_ = [l1lll11l11l_l1_]+l1l11l11lll_l1_
				l111l1ll11_l1_ = l111l1ll11_l1_[:50]
				l1l11l1l1ll_l1_[l1l1lll11ll_l1_] = l111l1ll11_l1_
			else: l1l11l1l1ll_l1_[l1l1lll11ll_l1_] = l1l11ll1ll1_l1_[l1l1lll11ll_l1_]
	if type not in list(l1l11l1l1ll_l1_.keys()): l1l11l1l1ll_l1_[type] = [l1lll11l11l_l1_]
	l1l11l1l1ll_l1_ = str(l1l11l1l1ll_l1_)
	if PY3: l1l11l1l1ll_l1_ = l1l11l1l1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㋐"))
	open(l1l1l11l111_l1_,l1l111_l1_ (u"ࠪࡻࡧ࠭㋑")).write(l1l11l1l1ll_l1_)
	return
def l1lll1111ll_l1_(l1ll1lll1l_l1_,table,l1l1l11lll1_l1_,data,l1l1l1ll111_l1_,l1l1ll1llll_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭㋒"))
	if cache==l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㋓") and l1l1l1ll111_l1_>l1l11l1l11l_l1_: l1l1l1ll111_l1_ = l1l11l1l11l_l1_
	if l1l1ll1llll_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l111llll_l1_ in range(len(l1l1l11lll1_l1_)):
			text = pickle.dumps(data[l1l111llll_l1_])
			l1l11l1ll1l_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l11lll1_l1_[l1l111llll_l1_],))
			l1l11ll1l_l1_.append((l1l1l1ll111_l1_+now,str(l1l1l11lll1_l1_[l1l111llll_l1_]),l1l11l1ll1l_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l1l1l11_l1_ = zlib.compress(text)
	try: conn,l1llll1lll_l1_ = l1l1lllll11_l1_(l1ll1lll1l_l1_)
	except: return
	while True:
		try:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨ㋔"))
			break
		except: time.sleep(0.5)
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡄࡔࡈࡅ࡙ࡋࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡑࡓ࡙ࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ㋕")+table+l1l111_l1_ (u"ࠨࠤࠣࠬࡪࡾࡰࡪࡴࡼ࠰ࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠫࠣ࠿ࠬ㋖"))
	if l1l1ll1llll_l1_:
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㋗")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㋘"),l1l11ll11_l1_)
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ㋙")+table+l1l111_l1_ (u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ㋚"),l1l11ll1l_l1_)
	else:
		if l1l1l1ll111_l1_:
			tt = (str(l1l1l11lll1_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭㋛")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㋜"),tt)
			tt = (l1l1l1ll111_l1_+now,str(l1l1l11lll1_l1_),l1l1l1l1l11_l1_)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ㋝")+table+l1l111_l1_ (u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ㋞"),tt)
		else:
			tt = (l1l1l1l1l11_l1_,str(l1l1l11lll1_l1_))
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣࠦࠬ㋟")+table+l1l111_l1_ (u"ࠫࠧࠦࡓࡆࡖࠣࡨࡦࡺࡡࠡ࠿ࠣࡃࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㋠"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if PY3: import urllib.parse as l1l1lllll1l_l1_
	else: import urllib as l1l1lllll1l_l1_
	l1ll1111l1l_l1_ = l1l1lllll1l_l1_.urlencode(data)
	return l1ll1111l1l_l1_
l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠬ࠭㋡")
def l1llll111_l1_(l1llllll_l1_,l1ll1ll1l1l_l1_=l1l111_l1_ (u"࠭ࠧ㋢"),l1l111l11ll_l1_=l1l111_l1_ (u"ࠧࠨ㋣")):
	l1l1l1lll11_l1_ = l1ll1ll1l1l_l1_ not in [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㋤"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㋥")]
	global l1l1lll1l11_l1_
	if not l1l111l11ll_l1_: l1l111l11ll_l1_ = l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㋦")
	l1l1lll1l11_l1_,l1l11llll1l_l1_,httpd = l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠶ࠧ㋧"),l1l111_l1_ (u"ࠬ࠭㋨"),l1l111_l1_ (u"࠭ࠧ㋩")
	if len(l1llllll_l1_)==3:
		url,l1l1l111l1l_l1_,httpd = l1llllll_l1_
		if l1l1l111l1l_l1_: l1l11llll1l_l1_ = l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ㋪")+l1l1l111l1l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㋫")
	else: url,l1l1l111l1l_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㋬"),l1l111_l1_ (u"ࠪࠫ㋭")
	url = url.replace(l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ㋮"),l1l111_l1_ (u"ࠬࠦࠧ㋯"))
	l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(url)
	if l1ll1ll1l1l_l1_ not in [l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㋰"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㋱")]:
		if l1ll1ll1l1l_l1_!=l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㋲"): url = url.replace(l1l111_l1_ (u"ࠩࠣࠫ㋳"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ㋴"))
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㋵"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡱ࡮ࡤࡽ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋶")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㋷")+l1l11llll1l_l1_)
		if l11ll1l1l1_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㋸") and l1ll1ll1l1l_l1_ not in [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㋹"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㋺")]:
			headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㋻"):l1l111_l1_ (u"ࠫࠬ㋼")}
			from LIBSTWO import l1l11l11ll_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭㋽")+str(count)+l1l111_l1_ (u"࠭ࠠๆๆไ࠭ࠬ㋾"), l1l1lll1_l1_)
				if l11l11l_l1_ == -1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠪ㋿"),l1l111_l1_ (u"ࠨࠩ㌀"))
					return l1l1lll1l11_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠩ࠰࠵ࠬ㌁"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㌂"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡀࠠ࡜ࠢࠪ㌃")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㌄")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㌅"))
		if l1l111_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ㌆") in url: url = url+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㌇")
		elif l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㌈") in url.lower() and l1l111_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ㌉") not in url and l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㌊") not in url:
			if l1l111_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ㌋") not in url and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ㌌") in url.lower():
				if l1l111_l1_ (u"ࠧࡽࠩ㌍") not in url: url = url+l1l111_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ㌎")
				else: url = url+l1l111_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭㌏")
			if l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ㌐") not in url.lower() and l1ll1ll1l1l_l1_ not in [l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㌑"),l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㌒")]:
				if l1l111_l1_ (u"࠭ࡼࠨ㌓") not in url: url = url+l1l111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㌔")
				else: url = url+l1l111_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㌕")
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㌖"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡇࡰࡶࠣࡪ࡮ࡴࡡ࡭ࠢࡸࡶࡱࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㌗")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㌘"))
	l1l111l1lll_l1_ = xbmcgui.ListItem()
	l1l111l11ll_l1_,l1l11lll1ll_l1_,l1l1l1l11l1_l1_,l1l111ll1l1_l1_,l1l1ll111l1_l1_,l1l111l1l11_l1_,l1l11lll1l1_l1_,l1l11lll111_l1_,l1l1l11l11l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll1ll1l1l_l1_ not in [l1l111_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㌙"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㌚")]:
		if PY2: l1l111ll111_l1_ = l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࡦࡪࡤࡰࡰࠪ㌛")
		else: l1l111ll111_l1_ = l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠭㌜")
		l1l111l1lll_l1_.setProperty(l1l111ll111_l1_, l1l111_l1_ (u"ࠩࠪ㌝"))
		l1l111l1lll_l1_.setMimeType(l1l111_l1_ (u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨ㌞"))
		if kodi_version<20: l1l111l1lll_l1_.setInfo(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㌟"),{l1l111_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨ㌠"):l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㌡")})
		else:
			l1l1l11l1l1_l1_ = l1l111l1lll_l1_.getVideoInfoTag()
			l1l1l11l1l1_l1_.setMediaType(l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭㌢"))
		l1l111l1lll_l1_.setArt({l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ㌣"):l1l1ll111l1_l1_,l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩ㌤"):l1l1ll111l1_l1_,l1l111_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪ㌥"):l1l1ll111l1_l1_,l1l111_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ㌦"):l1l1ll111l1_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧ㌧"):l1l1ll111l1_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩ㌨"):l1l1ll111l1_l1_,l1l111_l1_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ㌩"):l1l1ll111l1_l1_,l1l111_l1_ (u"ࠨ࡫ࡦࡳࡳ࠭㌪"):l1l1ll111l1_l1_})
		if l11ll1l1l1_l1_ in [l1l111_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ㌫"),l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㌬")]: l1l111l1lll_l1_.setContentLookup(True)
		else: l1l111l1lll_l1_.setContentLookup(False)
		from l1l1l1111ll_l1_ import l1l1l1llll1_l1_
		if l1l111_l1_ (u"ࠫࡷࡺ࡭ࡱࠩ㌭") in url:
			l1l1l1llll1_l1_(l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㌮"),False)
		elif l11ll1l1l1_l1_==l1l111_l1_ (u"࠭࠮࡮ࡲࡧࠫ㌯") or l1l111_l1_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ㌰") in url:
			l1l1l1llll1_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㌱"),False)
			l1l111l1lll_l1_.setProperty(l1l111ll111_l1_,l1l111_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㌲"))
			l1l111l1lll_l1_.setProperty(l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ㌳"),l1l111_l1_ (u"ࠫࡲࡶࡤࠨ㌴"))
		if l1l1l111l1l_l1_:
			l1l111l1lll_l1_.setSubtitles([l1l1l111l1l_l1_])
	if l1l111l11ll_l1_==l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㌵") and l1ll1ll1l1l_l1_==l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㌶"):
		l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㌷")
		l1ll1ll1l1l_l1_ = l1l111_l1_ (u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ㌸")
	elif l1l111l11ll_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㌹") and l1l11lll111_l1_.startswith(l1l111_l1_ (u"ࠪ࠺ࠬ㌺")):
		l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㌻")
		l1ll1ll1l1l_l1_ = l1ll1ll1l1l_l1_+l1l111_l1_ (u"ࠬࡥࡄࡍࠩ㌼")
	if l1l1lll1l11_l1_!=l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㌽"): l1l1l1lll1l_l1_()
	l1l11llllll_l1_ = l1l1l1l1ll1_l1_()
	l1l11llllll_l1_.init(l1ll1ll1l1l_l1_)
	if l1l11llllll_l1_.l1l1lll1l11_l1_: l1l1lll1l11_l1_ == l1l111_l1_ (u"ࠧࠨ㌾")
	elif l1l111l11ll_l1_==l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㌿") and not l1l11lll111_l1_.startswith(l1l111_l1_ (u"ࠩ࠹ࠫ㍀")):
		l1l111l1lll_l1_.setPath(url)
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㍁"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㍂")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㍃"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l111l1lll_l1_)
	elif l1l111l11ll_l1_==l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㍄"):
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㍅"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡑ࡯ࡶࡦࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡰ࡭ࡣࡼࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㍆")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㍇"))
		l1l11llllll_l1_.play(url,l1l111l1lll_l1_)
	succeeded = False
	if l1l1lll1l11_l1_==l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㍈"):
		from l11lll1l1l_l1_ import l11lll11l1_l1_
		succeeded = l11lll11l1_l1_(url,l11ll1l1l1_l1_,l1ll1ll1l1l_l1_)
		if succeeded: l1l1l1lll1l_l1_()
	else:
		l1l111l11l1_l1_,l1l1lll1l11_l1_,l1l1lllllll_l1_,delay = 0,l1l111_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㍉"),False,2
		if l1l1l1lll11_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l111l11l1_l1_<30:
			l1l1lll1l11_l1_ = l1l11llllll_l1_.l1l1lll1l11_l1_
			if l1l1lll1l11_l1_==l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭㍊") and not l1l1lllllll_l1_:
				if l1l1l1lll11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭วๅใํำ๏๎ࠠๆ๊ฯ์ิ࠭㍋"),l1l111_l1_ (u"ࠧࠨ㍌"),time=500)
				l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㍍"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡴࡶࡤࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㍎")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㍏")+l1l11llll1l_l1_)
				l1l1lllllll_l1_ = True
			elif l1l1lll1l11_l1_ in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㍐"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㍑")]:
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㍒"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㍓")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㍔")+l1l11llll1l_l1_)
				break
			elif l1l1lll1l11_l1_==l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㍕"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㍖"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㍗")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㍘")+l1l11llll1l_l1_)
				if l1l1l1lll11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭วๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠪ㍙"),l1l111_l1_ (u"ࠧࠨ㍚"),time=500)
				break
			elif l1l1lll1l11_l1_==l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㍛"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㍜"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡥࡰࡴࡩ࡫ࡦࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㍝")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㍞"))
				break
			xbmc.sleep(delay*1000)
			l1l111l11l1_l1_ += delay
		else:
			if l1l1l1lll11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬอไโ์า๎ํࠦไๆࠢํ฽๊๊ࠧ㍟"),l1l111_l1_ (u"࠭ࠧ㍠"),time=500)
			l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㍡"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤ࡙࡯࡭ࡦࡱࡸࡸ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㍢")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㍣")+l1l11llll1l_l1_)
			l1l1lll1l11_l1_ = l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㍤")
	if l1l1lll1l11_l1_ in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㍥"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㍦"),l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㍧")] or succeeded:
		if l1l1lll1l11_l1_==l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㍨"): l1ll1ll1l1l_l1_ = l1ll1ll1l1l_l1_+l1l111_l1_ (u"ࠨࡡࡗࡗࠬ㍩")
		response = l1ll1111111_l1_(l1ll1ll1l1l_l1_)
	else: exec(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩ㍪"))
	return l1l1lll1l11_l1_
def GET_VIDEOFILETYPE(url):
	l11ll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡡ࠴ࡡࡷ࡫ࡿࡠ࠳ࡺࡳࡽ࡞࠱ࡥࡦࡩࡼ࡝࠰ࡰࡴ࠹ࢂ࡜࠯࡯࠶ࡹࢁࡢ࠮࡮࠵ࡸ࠼ࢁࡢ࠮࡮ࡲࡧࢀࡡ࠴࡭࡬ࡸࡿࡠ࠳࡬࡬ࡷࡾ࡟࠲ࡲࡶ࠳ࡽ࡞࠱ࡻࡪࡨ࡭ࠪࠪࡿࡠࡄ࠴ࠪࡀࡾ࠲ࡠࡄ࠴ࠪࡀࡾ࡟ࢀ࠳࠰࠿ࠪࠦࠪ㍫"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11ll1l1l1_l1_: l11ll1l1l1_l1_ = l11ll1l1l1_l1_[0][0]
	else: l11ll1l1l1_l1_ = l1l111_l1_ (u"ࠫࠬ㍬")
	return l11ll1l1l1_l1_
WRITE_TO_sSQL3 = l1lll1111ll_l1_
READ_FROM_sSQL3 = l1lll11l1ll_l1_
DELETE_FROM_sSQL3 = l1lll1ll1l1_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11lllll1l_l1_
LOGg_THIS = l1l111111l_l1_
PLAY_VIDEOo = l1llll111_l1_
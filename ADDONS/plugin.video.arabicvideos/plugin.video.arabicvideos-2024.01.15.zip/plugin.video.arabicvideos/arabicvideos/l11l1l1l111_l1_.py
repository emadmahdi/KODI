# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䔸"):l1l111_l1_ (u"ࠫࠬ䔹")}
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ䔺")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ䔻")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠧ࠴ࠩ䔼"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠨ࠳ࠪ䔽"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠩ࠵ࠫ䔾"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠪ࠸ࠬ䔿"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䕀"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䕁")+l1lllll_l1_+l1l111_l1_ (u"࠭โ็ษฬࠤ์๊วࠡ็้ࠤ๊๎โฺࠢหห๋๐สࠨ䕂"),l1l111_l1_ (u"ࠧࠨ䕃"),38)
	return l1l111_l1_ (u"ࠨࠩ䕄")
def CATEGORIES(url,select=l1l111_l1_ (u"ࠩࠪ䕅")):
	type = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ䕆"))[3]
	if type==l1l111_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䕇"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭䕈"),headers,l1l111_l1_ (u"࠭ࠧ䕉"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠵ࡸࡺࠧ䕊"))
		if select==l1l111_l1_ (u"ࠨ࠵ࠪ䕋"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸࡓࡥ࡯ࡷࠫ࠲࠯ࡅࠩࡴࡧࡵ࡭ࡪࡹࡆࡰࡴࡰࠫ䕌"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䕍"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"่๊๊ࠫษษอࠤ๊฼อไหࠪ䕎") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ䕏"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕐"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"ࠧ࠵ࠩ䕑"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡥࡧࡷࡥ࡮ࡲࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡻࡄ࠼࠰ࡣࡁࡀ࠴ࡪࡩࡷࡀࠪ䕒"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕓"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ䕔"))
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕕"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䕖"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ䕗"),headers,l1l111_l1_ (u"ࠧࠨ䕘"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠷ࡴࡤࠨ䕙"))
		if select==l1l111_l1_ (u"ࠩ࠴ࠫ䕚"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࡊࡩࡳࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䕛"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࡂࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䕜"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡧࡦࡰࡵࡩ࠴࠭䕝") + value
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ䕞"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䕟"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"ࠨ࠴ࠪ䕠"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡃࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ䕡"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕢"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭䕣"))
				url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡡࡤࡶࡲࡶ࠴࠭䕤") + value
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕥"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䕦"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ䕧"),headers,l1l111_l1_ (u"ࠩࠪ䕨"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䕩"))
	if l1l111_l1_ (u"ࠫ࡭ࡵ࡭ࡦࠩ䕪") in url: type=l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ䕫")
	if type==l1l111_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䕬"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠫ࠲࠯ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ䕭"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䕮"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ䕯"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䕰"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ䕱"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ䕲"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠱࠿ࠪࠤࠪ䕳"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ䕴"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䕵"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ䕶"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ䕷"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠫ࠶࠭䕸"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠪ䕹"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼࠧ䕺"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䕻") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䕼"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠴ࠪࡀࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠭࠴ࠫࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ䕽"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࠫ䕾"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭䕿"))
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ䖀"))
			name = title + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ䖁") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䖂"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡩ࡯ࡽࡵ࡮ࡩࡤࡱࡱ࠱ࡨ࡮ࡥࡷࡴࡲࡲ࠲ࡸࡩࡨࡪࡷࠬ࠳࠱࠿ࠪࡦࡤࡸࡦ࠳ࡲࡦࡸ࡬ࡺࡪ࠳ࡺࡰࡰࡨ࡭ࡩࡃࠢ࠵ࠤࠪ䖃"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䖄"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ูࠪๆำษࠡࠩ䖅") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䖆"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ䖇") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷ࠳ࡻ࠷࠯ࡴࡧࡵ࡭ࡪࡹࡌࡪࡰ࡮࠳ࠬ䖈") + url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䖉"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䖊"),url,l1l111_l1_ (u"ࠩࠪ䖋"),headers,l1l111_l1_ (u"ࠪࠫ䖌"),l1l111_l1_ (u"ࠫࠬ䖍"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䖎"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"࠭ࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䖏"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ䖐"),l1l111_l1_ (u"ࠨ࠱ࠪ䖑"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䖒"),url,l1l111_l1_ (u"ࠪࠫ䖓"),headers,l1l111_l1_ (u"ࠫࠬ䖔"),l1l111_l1_ (u"ࠬ࠭䖕"),l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ䖖"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡖࡔࡏࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䖗"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䖘"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"ࠩࠪ䖙")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬ䖚"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ䖛"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䖜"),l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭䖝")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ䖞")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ䖟"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠩหัะูࠦ็ࠢสๅ้อๅࠨ䖠") , l1l111_l1_ (u"ࠪฬาัฺุ่้๊ࠠࠣำๅษอࠫ䖡")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡ࠯ࠣหำะัࠡษ็ฬาัࠧ䖢"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠬࡥࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࡤ࠭䖣") in options: type = l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䖤")
		elif l1l111_l1_ (u"ࠧࡠࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙࡟ࠨ䖥") in options: type = l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䖦")
		else: return
	headers[l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䖧")] = l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䖨")
	data = {l1l111_l1_ (u"ࠫࡶࡻࡥࡳࡻࠪ䖩"):l1lll1ll_l1_ , l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡉࡵ࡭ࡢ࡫ࡱࠫ䖪"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"࠭࠱ࠨ䖫"): data[l1l111_l1_ (u"ࠧࡧࡴࡲࡱࠬ䖬")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䖭"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ䖮"),data,headers,l1l111_l1_ (u"ࠪࠫ䖯"),l1l111_l1_ (u"ࠫࠬ䖰"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ䖱"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䖲"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ䖳"),l1l111_l1_ (u"ࠨ࠱ࠪ䖴"))
			if l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ䖵") in url: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䖶"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๐ไๆࠢࠪ䖷")+title,url,33)
			elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䖸") in url:
				url = url.replace(l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䖹"),l1l111_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸ࠴࠭䖺"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䖻"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไࠡࠩ䖼")+title,url+l1l111_l1_ (u"ࠪ࠳࠶࠭䖽"),32)
	count=re.findall(l1l111_l1_ (u"ࠫࠧࡺ࡯ࡵࡣ࡯ࠦ࠿࠮࠮ࠫࡁࠬࢁࠬ䖾"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䖿"),l1l111_l1_ (u"࠭ีโฯฬࠤࠬ䗀")+l1lll1l1l_l1_,l1l111_l1_ (u"ࠧࠨ䗁"),39,l1l111_l1_ (u"ࠨࠩ䗂"),l1lll1l1l_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ䗃")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠪࡥࡍࡘ࠰ࡤࡆࡲࡺࡑ࠸ࡤࡻࡦࡋࡎࡱ࡟ࡗ࠱࠲ࡏࡲࡇ࡮ࡢ࡮ࡘ࠳ࡐࡲࡔࡶࡍ࡯࡯ࡷࡑ࠸ࡖ࡬࡜࠵࡚࡫࡟ࡗࡋࡻࡏ࠶࡭࡮ࡢࡈࡈࡘ࡚࡮࠿ࡷࡣࡉࡉ࠹ࡧࡍ࡬ࡻࡦࡆ࠹ࡹࡓ࠳ࡖ࠶ࠪ䗄")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䗅"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ䗆"))
	return
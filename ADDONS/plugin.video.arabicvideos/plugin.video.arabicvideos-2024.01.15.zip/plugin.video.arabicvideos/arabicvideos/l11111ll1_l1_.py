# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧᚬ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡇࡈ࡝࡟ࠨᚭ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬᚮ"),l1l111_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬᚯ"),l1l111_l1_ (u"ࠬะำอ์็ࠫᚰ"),l1l111_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫᚱ")]
headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᚲ"):l111l1_l1_}
def l11l1ll_l1_(mode,url,text):
	if   mode==630: l1lll_l1_ = l1l1l11_l1_()
	elif mode==631: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==632: l1lll_l1_ = PLAY(url)
	elif mode==633: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==634: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==639: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᚳ"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪᚴ"),l1l111_l1_ (u"ࠪࠫᚵ"),l1l111_l1_ (u"ࠫࠬᚶ"),l1l111_l1_ (u"ࠬ࠭ᚷ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᚸ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚹ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᚺ"),l1l111_l1_ (u"ࠩࠪᚻ"),639,l1l111_l1_ (u"ࠪࠫᚼ"),l1l111_l1_ (u"ࠫࠬᚽ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᚾ"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᚿ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᛀ"),l1l111_l1_ (u"ࠨࠩᛁ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᛂ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᛃ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬᛄ"),l111l1_l1_,631,l1l111_l1_ (u"ࠬ࠭ᛅ"),l1l111_l1_ (u"࠭ࠧᛆ"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᛇ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᛈ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᛉ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"ࠪวาีหࠡษ็ั้่วหࠩᛊ"): mode,request = 631,l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᛋ")
		else: mode,request = 634,l1l111_l1_ (u"ࠬ࠭ᛌ")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛍ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᛎ")+l1lllll_l1_+title,l1ll1ll_l1_,mode,l1l111_l1_ (u"ࠨࠩᛏ"),l1l111_l1_ (u"ࠩࠪᛐ"),request)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᛑ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᛒ"),l1l111_l1_ (u"ࠬ࠭ᛓ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᛔ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᛕ"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠨࠩᛖ"))
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᛗ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᛘ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᛙ")+l1lllll_l1_+title,l1ll1ll_l1_,634)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᛚ"),url,l1l111_l1_ (u"࠭ࠧᛛ"),l1l111_l1_ (u"ࠧࠨᛜ"),l1l111_l1_ (u"ࠨࠩᛝ"),l1l111_l1_ (u"ࠩࠪᛞ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᛟ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᛠ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ᛡ"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬᛢ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᛣ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩᛤ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᛥ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᛦ"),l1l111_l1_ (u"ࠫࠬᛧ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᛨ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩᛩ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛪ"),l1lllll_l1_+title,l1ll1ll_l1_,631)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᛫"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ᛬"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᛭"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᛮ"),l1l111_l1_ (u"ࠬ࠭ᛯ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛰ"),l1lllll_l1_+title,l1ll1ll_l1_,631)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨᛱ")):
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᛲ"):
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࠫᛳ"),1)
		data = l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩᛴ")+search
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᛵ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᛶ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫᛷ"),url,data,headers,l1l111_l1_ (u"ࠧࠨᛸ"),l1l111_l1_ (u"ࠨࠩ᛹"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ᛺"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ᛻"),url,l1l111_l1_ (u"ࠫࠬ᛼"),l1l111_l1_ (u"ࠬ࠭᛽"),l1l111_l1_ (u"࠭ࠧ᛾"),l1l111_l1_ (u"ࠧࠨ᛿"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᜀ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠩࠪᜁ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧᜂ"))
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᜃ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᜄ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1l111_l1_ (u"࠭ࠧᜅ")))
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᜆ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡳࡱࡸࡷࡪࡲ࡟ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᜇ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩࠪࠫࠧࡶ࡯ࡴࡶࡅࡰࡴࡩ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠬ࠭ࠧᜈ"),block,re.DOTALL)
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᜉ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᜊ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩᜋ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᜌ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᜍ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪᜎ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᜏ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1l111_l1_ (u"ࠪࠫᜐ")))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᜑ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᜒ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ᜓ"),l1l111_l1_ (u"ࠧโ์็᜔้ࠬ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯ᜕ࠧ"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ᜖"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ᜗"),l1l111_l1_ (u"ࠫ์ีวโࠩ᜘"),l1l111_l1_ (u"๋ࠬศศำสอࠬ᜙"),l1l111_l1_ (u"ู࠭าุࠪ᜚"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ᜛"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ᜜"),l1l111_l1_ (u"่ࠩืึำ๊สࠩ᜝")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = title.replace(l1l111_l1_ (u"ࠪࠤุ๐ๅศࠢๆ่ํฮࠧ᜞"),l1l111_l1_ (u"ࠫࠬᜟ"))
		title = title.replace(l1l111_l1_ (u"ࠬࠦว้่่ࠣฬ๐ๆࠨᜠ"),l1l111_l1_ (u"࠭ࠧᜡ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪᜢ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠨ࡙࡚ࡉࠬᜣ") in title: continue
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᜤ"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᜥ"):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᜦ"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᜧ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜨ"),l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜩ"),l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᜪ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᜫ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬᜬ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭ᜭ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧᜮ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜯ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ᜰ")+title,l1ll1ll_l1_,631)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᜱ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᜲ"),url,l1l111_l1_ (u"ࠪࠫᜳ"),l1l111_l1_ (u"᜴ࠫࠬ"),l1l111_l1_ (u"ࠬ࠭᜵"),l1l111_l1_ (u"࠭ࠧ᜶"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ᜷"))
	html = response.content
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᜸"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪ᜹")
	items = []
	l11l1_l1_ = False
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭᜺"),html,re.DOTALL)
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࠬ࠭࡯࡯ࡥ࡯࡭ࡨࡱ࠽ࠣࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࠯࠲ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ᜻"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧ᜼"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᜽"),l1lllll_l1_+title,url,633,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ᜾"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭᜿")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᝀ"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᝁ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᝂ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧᝃ"))
			title = title.replace(l1l111_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫᝄ"),l1l111_l1_ (u"ࠧࠡࠩᝅ"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᝆ"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ᝇ"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭ᝈ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᝉ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ᝊ"),l1l111_l1_ (u"࠭ࠧᝋ"),l1l111_l1_ (u"ࠧࠨᝌ"),l1l111_l1_ (u"ࠨࠩᝍ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᝎ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᝏ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠦࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃࠨᝐ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᝑ")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᝒ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫᝓ"),l1l111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠳ࡶࡨࡱࠩ᝔"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭᝕"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ᝖"),l1l111_l1_ (u"ࠫࠬ᝗"),l1l111_l1_ (u"ࠬ࠭᝘"),l1l111_l1_ (u"࠭ࠧ᝙"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ᝚"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᝛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬ᝜"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᝝")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ᝞"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᝟"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧᝠ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨᝡ"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪᝢ"),l1l111_l1_ (u"ࠩ࠮ࠫᝣ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫᝤ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫᝥ"))
	return
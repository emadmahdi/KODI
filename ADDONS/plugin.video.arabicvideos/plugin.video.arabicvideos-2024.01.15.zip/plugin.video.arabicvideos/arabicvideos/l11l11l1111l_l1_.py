# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭庽")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ庾")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l11l1l11lll1_l1_(url)
	elif mode==146: l1lll_l1_ = l11l111ll111_l1_(url)
	elif mode==147: l1lll_l1_ = l11l11llllll_l1_()
	elif mode==148: l1lll_l1_ = l11l1l11111l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ庿"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ廀"),l1l111_l1_ (u"ࠩࠪ廁"),149,l1l111_l1_ (u"ࠪࠫ廂"),l1l111_l1_ (u"ࠫࠬ廃"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ廄"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廅"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廆")+l1l111_l1_ (u"ࠨࡡ࡜ࡘࡈࡥࠧ廇")+l1l111_l1_ (u"่ࠩ์ฬู่ࠡษัฮฬื็ศࠢส่๊ฮัๆฮࠪ廈"),l1l111_l1_ (u"ࠪࠫ廉"),290)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廊"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廋")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬ๊้ࠦฬํ์อ࠭廌"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭廍"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廎"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廏")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ廐"),l111l1_l1_,144,l1l111_l1_ (u"ࠫࠬ廑"),l1l111_l1_ (u"ࠬ࠭廒"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ廓"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廔"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廕")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊ำส้๋ࠣห้ืววฮࠪ廖"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ廗"),146)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ廘"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ廙"),l1l111_l1_ (u"࠭ࠧ廚"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廛"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廜")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠใ่๋หฯูࠦาสํอࠬ廝"),l1l111_l1_ (u"ࠪࠫ廞"),147)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廟"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廠")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣวั์ศ๋หࠪ廡"),l1l111_l1_ (u"ࠧࠨ廢"),148)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廣"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廤")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭廥"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ廦"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廧"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廨")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤฬาๆษ์ฬࠫ廩"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡰࡳࡻ࡯ࡥࠨ廪"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廫"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廬")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืึำ๊ศฬࠣ฽ึฮ๊สࠩ廭"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิำะ๎ฮ࠭廮"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廯"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廰")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะฺࠠำห๎ฮ࠭廱"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้๊ำๅࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ廲"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廳"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廴")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ廵"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ延"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廷"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廸")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡๅสีฯ๎ๆࠨ廹"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ่อัห๊้ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ建"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廻"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廼")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤำ฽ศสࠢส่๊ืฬฺ์ฬࠫ廽"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ใาส็หฦ࠱วๅใูหห๐ษࠬะฺฬฮ࠱วๅฮ่฽ฮࠬࡳࡱ࠿ࡆࡅࡎ࡙ࡁࡩࡃࡅࠫ廾"),144)
	return
def l11l11llllll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ廿"))
	return
def l11l1l11111l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ开"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l111ll111_l1_(url):
	html,l1llll1lll_l1_,data = l11l11lll1ll_l1_(url)
	dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ弁")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ异")][l1l111_l1_ (u"ࠬࡺࡡࡣࡵࠪ弃")]
	for l1l111llll_l1_ in range(len(dd)):
		item = dd[l1l111llll_l1_]
		l11l11l1l1ll_l1_(item,url,str(l1l111llll_l1_))
	l11l111lllll_l1_ = dd[0][l1l111_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ弄")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ弅")][l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弆")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ弇")]
	s = 0
	for l1l111llll_l1_ in range(len(l11l111lllll_l1_)):
		item = l11l111lllll_l1_[l1l111llll_l1_][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ弈")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭弉")][0]
		if list(item[l1l111_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ弊")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ弋")].keys())[0]==l1l111_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ弌"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_ = l11l1l1l11l1_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣีฬฬฬสࠢࠪ弍")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弎"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠪࠫ式"),str(l1l111llll_l1_))
	key = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡮࡯ࡧࡵࡸࡺࡨࡥࡂࡲ࡬ࡏࡪࡿࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ弐"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ弑")+key[0]
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11lll1ll_l1_(l1lllll1_l1_)
	for l1lllll11ll1_l1_ in range(3,4):
		dd = l1llll1lll_l1_[l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ弒")][l1lllll11ll1_l1_][l1l111_l1_ (u"ࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弓")][l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ弔")]
		for l1l111llll_l1_ in range(len(dd)):
			item = dd[l1l111llll_l1_]
			if l1l111_l1_ (u"ࠩ࡜ࡳࡺ࡚ࡵࡣࡧࠣࡔࡷ࡫࡭ࡪࡷࡰࠫ引") in str(item): continue
			l11l11l1l1ll_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠪࠫ弖"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭弗"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ弘"),l1l111_l1_ (u"࠭ࠧ弙"))
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11lll1ll_l1_(url,data)
	l1l11ll11l_l1_,l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ弚"),l1l111_l1_ (u"ࠨࠩ弛")
	owner = re.findall(l1l111_l1_ (u"ࠩࠥࡳࡼࡴࡥࡳࡐࡤࡱࡪࠨ࠮ࠫࡁࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ弜"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ弝"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡨࡢࡰࡱࡩࡱࡓࡥࡵࡣࡧࡥࡹࡧࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡲࡻࡳ࡫ࡲࡖࡴ࡯ࡷࠧࡀ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ弞"),html,re.DOTALL)
	if owner:
		l1l11ll11l_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ弟")+owner[0][0]+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ张")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ弡") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ弢") in url: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弣"),l1lllll_l1_+l1l11ll11l_l1_,l1ll1ll_l1_,144)
	l11l111lll11_l1_ = [l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ弤"),l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ弥"),l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ弦"),l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ弧"),l1l111_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ弨"),l1l111_l1_ (u"ࠨࡵࡶࡁࠬ弩"),l1l111_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ弪"),l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ弫"),l1l111_l1_ (u"ࠫࡧࡶ࠽ࠨ弬"),l1l111_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪ࠽ࠨ弭")]
	l11l111l1l1l_l1_ = not any(value in url for value in l11l111lll11_l1_)
	if l11l111l1l1l_l1_ and l1l11ll11l_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"࠭วๅสะฯࠬ弮")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠧใ๊สส๊ࠦวๅฬื฾๏๊ࠧ弯")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠨษ็ๅ๏ี๊้้สฮࠬ弰")
		l11l111l1lll_l1_ = l1l111_l1_ (u"ࠩส่็์่ศฬࠪ弱")
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ弲"),l1lllll_l1_+l1l11ll11l_l1_,url,9999)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨศฮอࠥࠫ弳") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弴"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"࠭ࠧ張"),l1l111_l1_ (u"ࠧࠨ弶"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ強"))
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ็๎วว็ࠣห้ะิ฻์็ࠦࠬ弸") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弹"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ强"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆไ๎ิ๐่่ษอࠦࠬ弻") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弼"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ弽"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ弾") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弿"),l1lllll_l1_+l11l111l1lll_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭彀"),144)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡓࡦࡣࡵࡧ࡭ࠨࠧ彁") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彂"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"࠭ࠧ彃"),l1l111_l1_ (u"ࠧࠨ彄"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ彅"))
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹࡹࠢࠨ彆") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彇"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ彈"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡗ࡫ࡧࡩࡴࡹࠢࠨ彉") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彊"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ彋"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭彌") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彍"),l1lllll_l1_+l11l111l1lll_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭彎"),144)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ彏"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ彐"),l1l111_l1_ (u"࠭ࠧ彑"),9999)
	if l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭归") in url:
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ当")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ彔")][l1l111_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ录")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彖")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ彗")]
		l11l111l11ll_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ彘") in list(dd[i].keys()):
				l11l111l11l1_l1_ = dd[i][l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彙")]
				length = len(str(l11l111l11l1_l1_))
				if length>l11l111l11ll_l1_:
					l11l111l11ll_l1_ = length
					l11l111l1ll1_l1_ = l11l111l11l1_l1_
		if l11l111l11ll_l1_==0: return
	elif l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ彚") in url or l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂ࡯ࡪࡿ࠽ࠨ彛") in url or l1l111_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡃࡰ࡫ࡹ࠾ࠩ彜") in url or l1l111_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ彝") in url or l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭彞") in url or url==l111l1_l1_:
		l11l11l1l1l1_l1_ = []
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ彟"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ彠"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ彡"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ形"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ彣"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠳࠱࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡤࡦࡱ࡫ࡔࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ彤"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ彥"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱ࡛ࡦࡺࡣࡩࡐࡨࡼࡹࡘࡥࡴࡷ࡯ࡸࡸ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠩࡠࠦ彦"))
		l11l111ll1ll_l1_,l11l111l1ll1_l1_ = l11l111l111l_l1_(l1llll1lll_l1_,l1l111_l1_ (u"ࠧࠨ彧"),l11l11l1l1l1_l1_)
	if not l11l111l1ll1_l1_:
		try:
			dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ彨")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ彩")][l1l111_l1_ (u"ࠪࡸࡦࡨࡳࠨ彪")]
			l1lllllllll1_l1_ = l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ彫") in url or l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ彬") in url or l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ彭") in url
			l11l11l11l11_l1_ = l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่ๆ๐ฯ๋๊๊หฯࠨࠧ彮") in html or l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ彯") in html or l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊โ็๊สฮࠧ࠭彰") in html
			l11l11l111ll_l1_ = l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࡜ࡩࡥࡧࡲࡷࠧ࠭影") in html or l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠤࠪ彲") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡄࡪࡤࡲࡳ࡫࡬ࡴࠤࠪ彳") in html
			if l1lllllllll1_l1_ and (l11l11l11l11_l1_ or l11l11l111ll_l1_):
				for l1l111llll_l1_ in range(len(dd)):
					if l1l111_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ彴") not in list(dd[l1l111llll_l1_].keys()): continue
					l11l111lllll_l1_ = dd[l1l111llll_l1_][l1l111_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ彵")]
					try: l11l111ll1l1_l1_ = l11l111lllll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ彶")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彷")][l1l111_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ彸")][l1l111_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭役")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡚ࡹࡱࡧࡖࡹࡧࡓࡥ࡯ࡷࡌࡸࡪࡳࡳࠨ彺")][l1l111llll_l1_]
					except: l11l111ll1l1_l1_ = l11l111lllll_l1_
					try: l1ll1ll_l1_ = l11l111ll1l1_l1_[l1l111_l1_ (u"࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ彻")][l1l111_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ彼")][l1l111_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭彽")][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭彾")]
					except: continue
					if   l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ彿")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ往")		in url: l11l111lllll_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ征")	in l1ll1ll_l1_	and l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ徂")	in url: l11l111lllll_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ徃")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ径")		in url: l11l111lllll_l1_ = dd[l1l111llll_l1_] ; break
					else: l11l111lllll_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠩࡥࡴࡂ࠭待") in url: l11l111lllll_l1_ = dd[index]
			else: l11l111lllll_l1_ = dd[0]
			l11l111l1ll1_l1_ = l11l111lllll_l1_[l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ徆")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ徇")]
		except: pass
	if not l11l111l1ll1_l1_: return
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ很"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ徉"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ徊"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ律"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ後"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ徍"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ徎"))
	if l1l111_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ徏") not in url: l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡹࡵࡣࡏࡨࡲࡺ࠭࡝࡜ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡕࡻࡳࡩࡘࡻࡢࡎࡧࡱࡹࡎࡺࡥ࡮ࡵࠪࡡࠧ徐"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ徑"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ徒"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ従"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ徔"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ徕"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ徖"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ得"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ徘"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩࠦ徙"))
	l11l1l11ll1_l1_ = l111lllllll_l1_(l1l111_l1_ (u"ࡷࠪ็้ࠦโ้ษษ้ࠥอไหึ฽๎้࠭徚"))
	l11l11l11ll_l1_ = l111lllllll_l1_(l1l111_l1_ (u"ࡸ่๊ࠫࠠศๆไ๎ิ๐่่ษอࠫ徛"))
	l11l111ll11l_l1_ = l111lllllll_l1_(l1l111_l1_ (u"ࡹ้ࠬไࠡษ็ๆ๋๎วหࠩ徜"))
	l1l1ll1lll1l_l1_ = [l11l1l11ll1_l1_,l11l11l11ll_l1_,l11l111ll11l_l1_,l1l111_l1_ (u"ࠬࡇ࡬࡭ࠢࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ徝"),l1l111_l1_ (u"࠭ࡁ࡭࡮ࠣࡺ࡮ࡪࡥࡰࡵࠪ從"),l1l111_l1_ (u"ࠧࡂ࡮࡯ࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭徟")]
	l11l111lll1l_l1_,l11l111ll1l1_l1_ = l11l111l111l_l1_(l11l111l1ll1_l1_,index,l11l11l1l1l1_l1_)
	if l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭徠") in str(type(l11l111ll1l1_l1_)) and any(value in str(l11l111ll1l1_l1_[0]) for value in l1l1ll1lll1l_l1_): del l11l111ll1l1_l1_[0]
	for index2 in range(len(l11l111ll1l1_l1_)):
		l11l11l1l1l1_l1_ = []
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ御"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ徢"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ徣"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ徤"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ徥"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ徦"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡧࡢ࡯ࡨࡇࡦࡸࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡭ࡡ࡮ࡧࠪࡡࠧ徧"))
		l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࠨ徨"))
		l11l111ll1ll_l1_,item = l11l111l111l_l1_(l11l111ll1l1_l1_,index2,l11l11l1l1l1_l1_)
		l11l11l1l1ll_l1_(item,url,str(index2))
		if l11l111ll1ll_l1_==l1l111_l1_ (u"ࠪ࠸ࠬ復"):
			try:
				hh = item[l1l111_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫ循")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭徫")][l1l111_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭徬")][l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭徭")]
				for l11l11ll11ll_l1_ in range(len(hh)):
					l1l1lll1llll_l1_ = hh[l11l11ll11ll_l1_]
					l11l11l1l1ll_l1_(l1l1lll1llll_l1_)
			except: pass
	l111llllll_l1_ = False
	if l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ微") not in url and l11l111lll1l_l1_==l1l111_l1_ (u"ࠩ࠻ࠫ徯"): l111llllll_l1_ = True
	if l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ徰") in l1l11llll_l1_: l11l1l111l1l_l1_,key,l11l111l1l11_l1_,l11l1l111111_l1_,token,l11l11llll1l_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ徱"))
	else: l11l1l111l1l_l1_,key,l11l111l1l11_l1_,l11l1l111111_l1_,token,l11l11llll1l_l1_ = l1l111_l1_ (u"ࠬ࠭徲"),l1l111_l1_ (u"࠭ࠧ徳"),l1l111_l1_ (u"ࠧࠨ徴"),l1l111_l1_ (u"ࠨࠩ徵"),l1l111_l1_ (u"ࠩࠪ徶"),l1l111_l1_ (u"ࠪࠫ德")
	l1lllll1_l1_,l111l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ徸"),l1l111_l1_ (u"ࠬ࠭徹")
	if menuItemsLIST:
		l11l11l111l1_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"࠭ࡃࡉࡐࡏࠫ徺") in l11l11l111l1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠧࡄࡊࡄࡒࡓࡋࡌࡔࠩ徻")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠨࡗࡖࡉࡗ࠭徼") in l11l11l111l1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ徽")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ徾") in l11l11l111l1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠫࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ徿")
	if l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡸࠨࠧ忀") in html and l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭忁") not in url and not l111llllll_l1_ and l1l111_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥࠩ忂") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ心")+l11l111l1l11_l1_
	elif l1l111_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ忄") in html and l1l111_l1_ (u"ࠪࡦࡵࡃࠧ必") not in url and l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ忆") in url or l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ忇") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ忈")+key
	elif l1l111_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ忉") in html and l1l111_l1_ (u"ࠨࡤࡳࡁࠬ忊") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭忋")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ忌"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ忍"),l1lllll1_l1_,144,l111l1llll_l1_,l1l111_l1_ (u"ࠬ࠭忎"),l1l11llll_l1_)
	return
def l11l111l111l_l1_(l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l11l11ll1111_l1_):
	l1llll1lll_l1_ = l1ll1111l1ll_l1_
	l11l111l1ll1_l1_,index = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	l11l111ll1l1_l1_,index2 = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	item,l11l11l11111_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	count = len(l11l11ll1111_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l11ll1111_l1_[l1l111llll_l1_])
			return str(l1l111llll_l1_+1),out
		except: pass
	return l1l111_l1_ (u"࠭ࠧ忏"),l1l111_l1_ (u"ࠧࠨ忐")
def l11l1l1l11l1_l1_(item):
	try: l11l11lllll1_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠨࠩ忑"),l1l111_l1_ (u"ࠩࠪ忒"),l1l111_l1_ (u"ࠪࠫ忓"),l1l111_l1_ (u"ࠫࠬ忔"),l1l111_l1_ (u"ࠬ࠭忕"),l1l111_l1_ (u"࠭ࠧ忖"),l1l111_l1_ (u"ࠧࠨ志")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_ = False,l1l111_l1_ (u"ࠨࠩ忘"),l1l111_l1_ (u"ࠩࠪ忙"),l1l111_l1_ (u"ࠪࠫ忚"),l1l111_l1_ (u"ࠫࠬ忛"),l1l111_l1_ (u"ࠬ࠭応"),l1l111_l1_ (u"࠭ࠧ忝"),l1l111_l1_ (u"ࠧࠨ忞")
	l11l11l11111_l1_ = item[l11l11lllll1_l1_]
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡸࡲࡵࡲࡡࡺࡣࡥࡰࡪ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ忟"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡪࡴࡸ࡭ࡢࡶࡷࡩࡩ࡚ࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ忠"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ忡"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ忢"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ忣"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ忤"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ忥"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ忦"))
	l11l111ll1ll_l1_,title = l11l111l111l_l1_(item,l11l11l11111_l1_,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ忧"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ忨"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ忩"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ忪"))
	l11l111ll1ll_l1_,l1ll1ll_l1_ = l11l111l111l_l1_(item,l11l11l11111_l1_,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ快"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ忬"))
	l11l111ll1ll_l1_,l1ll1l_l1_ = l11l111l111l_l1_(item,l11l11l11111_l1_,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ忭"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ忮"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ忯"))
	l11l111ll1ll_l1_,count = l11l111l111l_l1_(item,l11l11l11111_l1_,l11l11l1l1l1_l1_)
	l11l11l1l1l1_l1_ = []
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ忰"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ忱"))
	l11l11l1l1l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ忲"))
	l11l111ll1ll_l1_,l1l1lll111_l1_ = l11l111l111l_l1_(item,l11l11l11111_l1_,l11l11l1l1l1_l1_)
	if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ忳") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l111lll_l1_ = l1l111_l1_ (u"ࠨࠩ忴"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ念")
	if l1l111_l1_ (u"้ࠪออิาࠩ忶") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l111lll_l1_ = l1l111_l1_ (u"ࠫࠬ忷"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭忸")
	if l1l111_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭忹") in list(l11l11l11111_l1_.keys()):
		l11l1l11l1ll_l1_ = str(l11l11l11111_l1_[l1l111_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ忺")])
		if l1l111_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ忻") in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠩࠧ࠾ࠬ忼")
		if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠡࡐࡒ࡛ࠬ忽") in l11l1l11l1ll_l1_: l11l1l111lll_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ忾")
		if l1l111_l1_ (u"ࠬࡈࡵࡺࠩ忿") in l11l1l11l1ll_l1_ or l1l111_l1_ (u"࠭ࡒࡦࡰࡷࠫ怀") in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠫ态")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡶ่ࠩฬฬฺัࠨ怂")) in l11l1l11l1ll_l1_: l11l1l111lll_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ怃")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡸูࠫืวยࠩ怄")) in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠨ怅")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡺ࠭วิฬษะฬืࠧ怆")) in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"࠭ࠤࠥ࠼ࠪ怇")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ怈")) in l11l1l11l1ll_l1_: l11l11llll11_l1_ = l1l111_l1_ (u"ࠨࠦ࠽ࠫ怉")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ怊") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠪࡃࠬ怋"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ怌") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ怍")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l11llll11_l1_: title = l11l11llll11_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ怎")+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠧ࠭ࠩ怏"),l1l111_l1_ (u"ࠨࠩ怐"))
	count = count.replace(l1l111_l1_ (u"ࠩ࠯ࠫ怑"),l1l111_l1_ (u"ࠪࠫ怒"))
	count = re.findall(l1l111_l1_ (u"ࠫࡡࡪࠫࠨ怓"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠬ࠭怔")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_
def l11l11l1l1ll_l1_(item,url=l1l111_l1_ (u"࠭ࠧ怕"),index=l1l111_l1_ (u"ࠧࠨ怖")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l111lll_l1_,l11l11llll11_l1_ = l11l1l1l11l1_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ怗") in str(item): return
	elif l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怘") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ怙") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ怚") in url or l1l111_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ怛") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"࠭࠽࠾࠿ࠣࠫ怜")+title+l1l111_l1_ (u"ࠧࠡ࠿ࡀࡁࠬ思")
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭怞"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ怟"),9999)
	elif title and l1l111_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ怠") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ怡"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭怢"),9999)
	elif l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ怣") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ怤"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l11l1l111lll_l1_: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭急"),l1lllll_l1_+l11l1l111lll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ怦") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ性") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ怨") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ怩") not in l1ll1ll_l1_:
			l11l1l1111ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭怪"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ怫")+l11l1l1111ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ怬"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ怭")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ怮")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ怯"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ怰"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	else:
		type = l1l111_l1_ (u"࠭ࠧ怱")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ怲"),l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ怳"),l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ怴"),l1l111_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭怵"),l1l111_l1_ (u"ࠫࡸࡹ࠽ࠨ怶"),l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ怷")]):
			if l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ怸")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡥ࠲ࠫ怹") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠨࡅࡋࡒࡑ࠭怺")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭总")
			if l1l111_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ怼") in l1ll1ll_l1_: type = l1l111_l1_ (u"࡚࡙ࠫࡅࡓࠩ怽")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ怾")
			index,l11l111llll1_l1_ = l1l111_l1_ (u"࠭ࠧ怿"),l1l111_l1_ (u"ࠧࠨ恀")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ恁"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l11l11lll1ll_l1_(url,data=l1l111_l1_ (u"ࠩࠪ恂"),request=l1l111_l1_ (u"ࠪࠫ恃")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭恄"))
	if request==l1l111_l1_ (u"ࠬ࠭恅"): request = l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭恆")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ恇"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ恈"):l1l111_l1_ (u"ࠩࡓࡖࡊࡌ࠽ࡩ࡮ࡀࡥࡷ࠭恉")}
	if l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ恊") in data: l11l1l111l1l_l1_,key,l11l111l1l11_l1_,l11l1l111111_l1_,token,l11l11llll1l_l1_ = data.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ恋"))
	else: l11l1l111l1l_l1_,key,l11l111l1l11_l1_,l11l1l111111_l1_,token,l11l11llll1l_l1_ = l1l111_l1_ (u"ࠬ࠭恌"),l1l111_l1_ (u"࠭ࠧ恍"),l1l111_l1_ (u"ࠧࠨ恎"),l1l111_l1_ (u"ࠨࠩ恏"),l1l111_l1_ (u"ࠩࠪ恐"),l1l111_l1_ (u"ࠪࠫ恑")
	if l1l111_l1_ (u"ࠫ࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ恒") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭恓")] = {l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ恔"):{l1l111_l1_ (u"ࠢࡩ࡮ࠥ恕"):l1l111_l1_ (u"ࠣࡣࡵࠦ恖"),l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ恗"):l1l111_l1_ (u"࡛ࠥࡊࡈࠢ恘"),l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ恙"):l11l1l111111_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ恚"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠲ࡵࡷࠫ恛"))
	elif l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ恜") in url and l11l1l111l1l_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ恝"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ恞")] = {l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ恟"):{l1l111_l1_ (u"ࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ恠"):l11l1l111l1l_l1_,l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ恡"):l1l111_l1_ (u"ࠨࡗࡆࡄࠥ恢"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ恣"):l11l1l111111_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭恤"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠶ࡳࡪࠧ恥"))
	elif l1l111_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ恦") in url and l11l11llll1l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ恧"):l1l111_l1_ (u"ࠬ࠷ࠧ恨"),l1l111_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ恩"):l11l1l111111_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ恪"):l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ恫")+l11l11llll1l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭恬"),url,l1l111_l1_ (u"ࠪࠫ恭"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ恮"),l1l111_l1_ (u"ࠬ࠭息"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ恰"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ恱"),url,l1l111_l1_ (u"ࠨࠩ恲"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ恳"),l1l111_l1_ (u"ࠪࠫ恴"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠺ࡴࡩࠩ恵"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ恶"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ恷"),html,re.DOTALL|re.I)
	if tmp: l11l1l111111_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ恸"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ恹"),html,re.DOTALL|re.I)
	if tmp: l11l1l111l1l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭恺"),html,re.DOTALL|re.I)
	if tmp: l11l111l1l11_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ恻") in list(cookies.keys()): l11l11llll1l_l1_ = cookies[l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ恼")]
	data = l11l1l111l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ恽")+key+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ恾")+l11l111l1l11_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ恿")+l11l1l111111_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ悀")+token+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭悁")+l11l11llll1l_l1_
	if request==l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ悂") and l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ悃") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ悄"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ悅"),html,re.DOTALL)
		l11l1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ悆"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭悇") and l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ悈") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ悉"),html,re.DOTALL)
		l11l1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ悊"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ悋") not in html: l11l1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ悌"),html)
	else: l11l1l11l1l1_l1_ = l1l111_l1_ (u"ࠧࠨ悍")
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ悎"),data)
	return html,l11l1l11l1l1_l1_,data
def l11l1l11lll1_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ悏"),l1l111_l1_ (u"ࠪ࠯ࠬ悐"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ悑")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ悒"),l1l111_l1_ (u"࠭ࠫࠨ悓"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ悔")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ悕") in options: l11l11ll1l1l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ悖")
		elif l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ悗") in options: l11l11ll1l1l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ悘")
		elif l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ悙") in options: l11l11ll1l1l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭悚")
		l1llllll_l1_ = l1lllll1_l1_+l11l11ll1l1l_l1_
	else:
		l11l11ll1l11_l1_,l11l11l11lll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠧࠨ悛")
		l11l11l1l11l_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ悜"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ悝"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭悞"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ悟"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ悠")]
		l11l1l11l11l_l1_ = [l1l111_l1_ (u"࠭ࠧ悡"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭悢"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ患"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ悤"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ悥")]
		l11l1l11ll11_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ悦"),l11l11l1l11l_l1_)
		if l11l1l11ll11_l1_ == -1: return
		l11l11ll11l1_l1_ = l11l1l11l11l_l1_[l11l1l11ll11_l1_]
		html,c,data = l11l11lll1ll_l1_(l1lllll1_l1_+l11l11ll11l1_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ悧")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ您")][l1l111_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ悩")][l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ悪")][l1l111_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ悫")][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ悬")][l1l111_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ悭")]
			for l11l11l11ll1_l1_ in range(len(d)):
				group = d[l11l11l11ll1_l1_][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ悮")][l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ悯")]
				for l11l1l11llll_l1_ in range(len(group)):
					l11l11l11111_l1_ = group[l11l1l11llll_l1_][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ悰")]
					if l1l111_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭悱") in list(l11l11l11111_l1_.keys()):
						l1ll1ll_l1_ = l11l11l11111_l1_[l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ悲")][l1l111_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ悳")][l1l111_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ悴")][l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ悵")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭悶"),l1l111_l1_ (u"ࠧࠧࠩ悷"))
						title = l11l11l11111_l1_[l1l111_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ悸")]
						title = title.replace(l1l111_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ悹"),l1l111_l1_ (u"ࠪࠫ悺"))
						if l1l111_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ悻") in title: continue
						if l1l111_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ悼") in title:
							title = l1l111_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ悽")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠪ悾") in title: continue
						title = title.replace(l1l111_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭悿"),l1l111_l1_ (u"ࠩࠪ惀"))
						if l1l111_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ惁") in title: continue
						if l1l111_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭惂") in title:
							title = l1l111_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭惃")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ惄") in title: continue
						l11l11ll1l11_l1_.append(escapeUNICODE(title))
						l11l11l11lll_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l11l1l11l111_l1_ = l1l111_l1_ (u"ࠧࠨ情")
		else:
			l11l11ll1l11_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ惆"),l1lllllll_l1_]+l11l11ll1l11_l1_
			l11l11l11lll_l1_ = [l1l111_l1_ (u"ࠩࠪ惇"),l111lllll_l1_]+l11l11l11lll_l1_
			l11l1l1l111l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ惈"),l11l11ll1l11_l1_)
			if l11l1l1l111l_l1_ == -1: return
			l11l1l11l111_l1_ = l11l11l11lll_l1_[l11l1l1l111l_l1_]
		if l11l1l11l111_l1_: l1llllll_l1_ = l111l1_l1_+l11l1l11l111_l1_
		elif l11l11ll11l1_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l11ll11l1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
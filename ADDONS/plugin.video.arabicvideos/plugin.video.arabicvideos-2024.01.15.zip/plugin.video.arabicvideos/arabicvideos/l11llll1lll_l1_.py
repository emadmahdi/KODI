# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ墹")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬ墺")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l1ll111ll_l1_()
	elif mode==56: l1lll_l1_ = l11l1l1llll1_l1_()
	elif mode==57: l1lll_l1_ = l111ll11l1_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll11l1_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墻"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ墼"),l1l111_l1_ (u"ࠩࠪ墽"),59,l1l111_l1_ (u"ࠪࠫ墾"),l1l111_l1_ (u"ࠫࠬ墿"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ壀"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ壁"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ壂"),l1l111_l1_ (u"ࠨࠩ壃"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壄"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ壅")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ壆"),l1l111_l1_ (u"ࠬ࠭壇"),56)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壈"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ壉")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็หๆ๊วๆࠩ壊"),l1l111_l1_ (u"ࠩࠪ壋"),55)
	return l1l111_l1_ (u"ࠪࠫ壌")
def l11l1ll111ll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壍"),l1lllll_l1_+l1l111_l1_ (u"ࠬออะอࠣห้อแๅษ่ࠫ壎"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ壏"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壐"),l1lllll_l1_+l1l111_l1_ (u"ࠨษไ่ฬ๋ࠠาษษะฮ࠭壑"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ壒"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壓"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็หๆ๊วๆࠩ壔"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ壕"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壖"),l1lllll_l1_+l1l111_l1_ (u"ࠧศใ็ห๊ࠦใๅษึ๎่๐ษࠨ壗"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ壘"),51)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ壙"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ壚"),l1l111_l1_ (u"ࠫࠬ壛"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壜"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ壝"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡼࡳࡵ࠭壞"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壟"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ壠"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ壡"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壢"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ壣"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ壤"),57)
	return
def l11l1l1llll1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壥"),l1lllll_l1_+l1l111_l1_ (u"ࠨษะำะࠦวๅ็ึุ่๊วหࠩ壦"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ壧"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壨"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืววฮฬࠫ壩"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ壪"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭士"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊ๅิๆึ่ฬะࠧ壬"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ壭"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壮"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤ่๊วิ์ๆ๎ฮ࠭壯"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ声"),51)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ壱"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ売"),l1l111_l1_ (u"ࠧࠨ壳"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壴"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ壵"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡹࡰࡲࠪ壶"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壷"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ壸"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ壹"),57)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壺"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ壻"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ壼"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠪࡃࠬ壽") in url:
		parts = url.split(l1l111_l1_ (u"ࠫࡄ࠭壾"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠬࡅࠧ壿") + QUOTE(parts[1],l1l111_l1_ (u"࠭࠽ࠧ࠼࠲ࠩࠬ夀"))
	else: filter = l1l111_l1_ (u"ࠧࠨ夁")
	parts = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ夂"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"ࠩࡼࡳࡵ࠭夃"),l1l111_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࠪ处"),l1l111_l1_ (u"ࠫࡻ࡯ࡥࡸࡵࠪ夅")]:
		if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ夆"): l1l1l1lll_l1_=l1l111_l1_ (u"࠭แ๋ๆ่ࠫ备")
		elif type==l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ夈"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ変")
		url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪ夊") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠪ࠳ࠬ夋") + l1llllll1_l1_ + l1l111_l1_ (u"ࠫ࠴࠭夌") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭复"),l1l111_l1_ (u"࠭ࠧ夎"),l1l111_l1_ (u"ࠧࠨ夏"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ夐"))
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡴ࡮ࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡵࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࠤࡳࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡰࡳࡧࡶࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ夑"),html,re.DOTALL)
		l1ll1l111ll_l1_=0
		for id,title,l11l1l1lll1l_l1_,l1ll1l_l1_ in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1ll1l1lll1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡻ࠸࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴ࡳࡡࡪࡰ࠲ࠫ夒") + l1ll1l_l1_ + l1l111_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ夓")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ夔") + id
			if type==l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ夕"): addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭外"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ夗"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ夘"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅࠢࠪ夙")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ多")+l11l1l1lll1l_l1_+l1l111_l1_ (u"ࠬࡃࠧ夛")+title+l1l111_l1_ (u"࠭࠽ࠨ夜")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭夝"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ夞")
		elif type==l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ够"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ夠")
		url = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡰࡳࡰࡰ࠲ࡷࡪࡲࡥࡤࡶࡨࡨ࠴࠭夡") + sort + l1l111_l1_ (u"ࠬ࠳ࠧ夢") + l1l1l1lll_l1_ + l1l111_l1_ (u"࠭࠭ࡘ࡙࠱࡮ࡸࡵ࡮ࠨ夣")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ夤"),l1l111_l1_ (u"ࠨࠩ夥"),l1l111_l1_ (u"ࠩࠪ夦"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ大"))
		items = re.findall(l1l111_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡩࡵࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ夨"),html,re.DOTALL)
		l1ll1l111ll_l1_=0
		for id,l11l1l1lll1l_l1_,l1ll1l_l1_,title in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ天") + l1ll1l_l1_ + l1l111_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭太")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ夫") + id
			if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ夬"): addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ夭"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ央"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夯"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็ࠤࠬ夰")+title,l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿ࡦࡲࡀࠫ失")+l11l1l1lll1l_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ夲")+title+l1l111_l1_ (u"ࠨ࠿ࠪ夳")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"ุࠩๅาฯࠠࠨ头")
	if l1ll1l111ll_l1_==16:
		for l1ll1l1llll_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ夵")+type+l1l111_l1_ (u"ࠫ࠴࠭夶")+str(l1ll1l1llll_l1_)+l1l111_l1_ (u"ࠬ࠵ࠧ夷")+sort + filter
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭夸"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠧ࠾ࠩ夹"))
	l11l1l1lll1l_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭夺"),l1l111_l1_ (u"ࠩࠪ夻"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠪࡃࠬ夼"))[0]
	if l11l1l1lll1l_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ夽"),l1l111_l1_ (u"ࠬ࠭夾"),l1l111_l1_ (u"࠭ࠧ夿"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ奀"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡰࡪࡩࡴ࠿ࠩ奁"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ奂"),block,re.DOTALL)
		l11l1l1lll1l_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l1l1lll1l_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ奃") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ奄")+name+l1l111_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩ奅")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ奆"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ奇"),l1l111_l1_ (u"ࠨࠩ奈"),l1l111_l1_ (u"ࠩࠪ奉"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ奊"))
	l11l1l1lllll_l1_ = re.findall(l1l111_l1_ (u"๊ࠫะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิ࠴ࠪࡀ࡯ࡲࡱࡪࡴࡴ࡝ࠪࠥࠬ࠳࠰࠿ࠪࠤࠪ奋"),html,re.DOTALL)
	if l11l1l1lllll_l1_:
		time = l11l1l1lllll_l1_[1].replace(l1l111_l1_ (u"࡚ࠬࠧ奌"),l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ奍"))
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ奎"),l1l111_l1_ (u"ࠨࠩ奏"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠫ奐"),l1l111_l1_ (u"๋ࠪีอࠠศๆไ๎ิ๐่ࠡีํ็ํ์ࠠๆฬ๋ๅึูࠦๅุ๋ࠣํ็ࠠๆษๆืࠥฮูะ๊ࠢิฬࠦวๅ๊ๅฮࠬ契")+l1l111_l1_ (u"ࠫࡡࡴࠧ奒")+time)
		return
	l11l1l1ll1ll_l1_,l11l1ll1111l_l1_ = [],[]
	l11l1ll111l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ奓"),html,re.DOTALL)[0]
	l11l1ll11111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡦࡦࡩ࡫ࡶࡲࡢࡳࡷ࡯ࡧࡪࡰࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ奔"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩ࡮ࡶ࠾ࠥ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ奕"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ奖") in server:
			server = l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ套")
			url = l11l1ll11111_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ奘")
			url = l11l1ll111l1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ奙") in url:
			l11l1l1ll1ll_l1_.append(url)
			l11l1ll1111l_l1_.append(l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠤࠬ奚")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡱ࠶࠽࠲࠯ࡅ࡟࡭࡫ࡱ࡯࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ奛"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ奜"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ奝"))[-1]
		filename = filename.replace(l1l111_l1_ (u"ࠩࡩࡥࡱࡲࡢࡢࡥ࡮ࠫ奞"),l1l111_l1_ (u"ࠪࠫ奟"))
		filename = filename.replace(l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ奠"),l1l111_l1_ (u"ࠬ࠭奡"))
		filename = filename.replace(l1l111_l1_ (u"࠭࠭ࠨ奢"),l1l111_l1_ (u"ࠧࠨ奣"))
		if l1l111_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ奤") in server:
			server = l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ奥")
			url = l11l1ll11111_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ奦")
			url = l11l1ll111l1_l1_ + l1ll1ll_l1_
		l11l1l1ll1ll_l1_.append(url)
		l11l1ll1111l_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠴ࠡࠢࠪ奧")+server+l1l111_l1_ (u"ࠬࠦࠠࠨ奨")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡖࡪࡦࡨࡳࠥࡗࡵࡢ࡮࡬ࡸࡾࡀࠧ奩"), l11l1ll1111l_l1_)
	if l11l11l_l1_ == -1 : return
	url = l11l1l1ll1ll_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭奪"))
	return
def l111ll11l1_l1_(url,type):
	if l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ奫") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱่ืู้ไࠨ奬")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ๅ๏๊ๅࠨ奭")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ奮"),l1l111_l1_ (u"ࠬ࠭奯"),l1l111_l1_ (u"࠭ࠧ奰"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ奱"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ奲"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ女"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ奴"),block,re.DOTALL)
	if type==1:
		for l11l1l1lll11_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奵"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ奶")+l11l1l1lll11_l1_,58)
	elif type==2:
		url,l11l1l1lll11_l1_ = url.split(l1l111_l1_ (u"࠭࠿ࠨ奷"))
		for l1lllll111ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奸"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ她")+l1lllll111ll_l1_+l1l111_l1_ (u"ࠩࠩࠫ奺")+l11l1l1lll11_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬ奻"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ奼"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ好")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ奾"),url,l1l111_l1_ (u"ࠧࠨ奿"),l1l111_l1_ (u"ࠨࠩ妀"),True,l1l111_l1_ (u"ࠩࠪ妁"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ如"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡬࡫࡮ࡦࡴࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡴࡧࡤࡶࡨ࡮࠭ࡣࡱࡷࡸࡴࡳ࠭ࡱࡣࡧࡨ࡮ࡴࡧࠨ妃"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ妄"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ妅") in url:
				if l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ妆") in url:
					title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭妇")+title
					url = url.replace(l1l111_l1_ (u"ࠩࡂࡩࡵࡃ࠱ࠨ妈"),l1l111_l1_ (u"ࠪࡃࡪࡶ࠽࠱ࠩ妉"))
					url = url+l1l111_l1_ (u"ࠫࡂ࠭妊")+QUOTE(title)+l1l111_l1_ (u"ࠬࡃࠧ妋")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妌"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ็๊ๅ็ࠣࠫ妍")+title
					addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ妎"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
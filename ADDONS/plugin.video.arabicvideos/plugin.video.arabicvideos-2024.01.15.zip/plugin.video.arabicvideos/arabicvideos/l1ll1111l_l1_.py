# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪณ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡂࡔࡗࡣࠬด")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==730: l1lll_l1_ = l1l1l11_l1_()
	elif mode==731: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==732: l1lll_l1_ = PLAY(url)
	elif mode==733: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==734: l1lll_l1_ = l1l1lll1l_l1_(url)
	elif mode==735: l1lll_l1_ = l1l1lllll_l1_(url)
	elif mode==739: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧต"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨถ"),l1l111_l1_ (u"ࠩࠪท"),739,l1l111_l1_ (u"ࠪࠫธ"),l1l111_l1_ (u"ࠫࠬน"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩบ"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫป"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩผ"),l1l111_l1_ (u"ࠨࠩฝ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩพ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬฟ")+l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥๅ๋ิฬࠫภ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡴࡰࡲ࠱ࡴ࡭ࡶࠧม"),735)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ย"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩร")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠩฤ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡸࡴࡰࡱࡱ࠲ࡵ࡮ࡰࠨล"),734)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪฦ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ว")+l1lllll_l1_+l1l111_l1_ (u"ࠬอแๅษ่ࠫศ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠮ࡱࡪࡳࠫษ"),731)
	return
def l1l1lll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧส"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็็้࠭ห"),url,731)
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ฬ"),url,l1l111_l1_ (u"ࠪࠫอ"),l1l111_l1_ (u"ࠫࠬฮ"),l1l111_l1_ (u"ࠬ࠭ฯ"),l1l111_l1_ (u"࠭ࠧะ"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡙ࡅࡓࡋࡈࡗࡤ࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪั"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮ࡤࡦࡪࡲ࠽ࠣࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩา"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦำ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬิ")+l1ll1ll_l1_
			title = l1l111_l1_ (u"ࠫาืแࠡࠩี")+title
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬึ"),l1lllll_l1_+title,l1ll1ll_l1_,731)
	return
def l1l1lllll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪื"),url,l1l111_l1_ (u"ࠧࠨุ"),l1l111_l1_ (u"ࠨูࠩ"),l1l111_l1_ (u"ฺࠩࠪ"),l1l111_l1_ (u"ࠪࠫ฻"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔ࠯ࡖࡉࡗࡏࡅࡔࡡࡉࡉࡆ࡚ࡕࡓࡇࡇ࠱࠷ࡴࡤࠨ฼"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹ࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ฽"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ฾"),block,re.DOTALL)
		for title,l1ll1ll_l1_,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ฿")+l1ll1ll_l1_
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪเ")+l1ll1l_l1_
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫแ"))
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪโ"),l1lllll_l1_+title,l1ll1ll_l1_,733,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨใ"),url,l1l111_l1_ (u"ࠬ࠭ไ"),l1l111_l1_ (u"࠭ࠧๅ"),l1l111_l1_ (u"ࠧࠨๆ"),l1l111_l1_ (u"ࠨࠩ็"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷ่ࠫ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡱࡴࡼࡩࡦࡵࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ้ࠥ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡃ๊࠭"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵๋ࠧ")+l1ll1ll_l1_
		l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ์")+l1ll1l_l1_
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩํ"))
		if l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳ࠯ࡲ࡫ࡴࠬ๎") in url: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๏"),l1lllll_l1_+title,l1ll1ll_l1_,732,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๐"),l1lllll_l1_+title,l1ll1ll_l1_,733,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ๑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ๒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ๓")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ๔"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ๕"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ๖")+title,l1ll1ll_l1_,731)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ๗"),url,l1l111_l1_ (u"ࠫࠬ๘"),l1l111_l1_ (u"ࠬ࠭๙"),l1l111_l1_ (u"࠭ࠧ๚"),l1l111_l1_ (u"ࠧࠨ๛"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ๜"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡰࡳࡻ࡯ࡥࡴࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡹࡣࡳ࡫ࡳࡸࠧ๝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡴࡼࡩࡦࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡄࠧ๞"),block,re.DOTALL)
		for title,l1ll1ll_l1_,l1ll1l_l1_,l1l1llll1_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭๟")+l1ll1ll_l1_
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ๠")+l1ll1l_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ๡"))
			title = title+l1l111_l1_ (u"ࠧࠡࠩ๢")+l1l1llll1_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ๣"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๤"),l1lllll_l1_+title,l1ll1ll_l1_,732,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ๥"),url,l1l111_l1_ (u"ࠫࠬ๦"),l1l111_l1_ (u"ࠬ࠭๧"),l1l111_l1_ (u"࠭ࠧ๨"),l1l111_l1_ (u"ࠧࠨ๩"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ๪"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ๫"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ๬") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡸࡡࡣ࡫ࡦ࠱ࡹࡵ࡯࡯ࡵ࠱ࡧࡴࡳࠧ๭")
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭๮"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ๯"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ๰"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ๱"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ๲"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ๳"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠫࠬ๴"),l1l111_l1_ (u"ࠬࡳࠧ๵")]
	l1ll11111_l1_ = [l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠧ๶"),l1l111_l1_ (u"ࠧศใ็ห๊࠭๷")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆู็์อࡀࠧ๸"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	type = l1llll_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡼࡥࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ๹")+type+l1l111_l1_ (u"ࠪࠪࡶࡃࠧ๺")+search
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ๻"),url,l1l111_l1_ (u"ࠬ࠭๼"),l1l111_l1_ (u"࠭ࠧ๽"),l1l111_l1_ (u"ࠧࠨ๾"),l1l111_l1_ (u"ࠨࠩ๿"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ຀"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩກ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭ຂ")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ຃"))
		if type==l1l111_l1_ (u"࠭࡭ࠨຄ"): addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭຅"),l1lllll_l1_+title,l1ll1ll_l1_,732)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨຆ"),l1lllll_l1_+title,l1ll1ll_l1_,733)
	return
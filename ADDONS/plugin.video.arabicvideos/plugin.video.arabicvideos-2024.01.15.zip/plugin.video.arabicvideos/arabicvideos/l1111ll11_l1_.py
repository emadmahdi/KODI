# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧᖑ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡄࡅࡅࡣࠬᖒ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺࠧำฺ๋ࠥอไๆืสี฾ํࠧᖓ"),l1l111_l1_ (u"ࠨๆ็็ออัࠡใๅ฻ࠥ࠱࠱࠹ࠩᖔ"),l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᖕ"),l1l111_l1_ (u"ࠪหๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭ᖖ"),l1l111_l1_ (u"ࠫࡉࡓࡃࡂࠩᖗ")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==820: l1lll_l1_ = l1l1l11_l1_()
	elif mode==821: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==822: l1lll_l1_ = PLAY(url)
	elif mode==823: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==824: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ᖘ")+text)
	elif mode==825: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᖙ")+text)
	elif mode==829: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᖚ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩᖛ"),l1l111_l1_ (u"ࠩࠪᖜ"),l1l111_l1_ (u"ࠪࠫᖝ"),l1l111_l1_ (u"ࠫࠬᖞ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᖟ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖠ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᖡ"),l111l1_l1_,829,l1l111_l1_ (u"ࠨࠩᖢ"),l1l111_l1_ (u"ࠩࠪᖣ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᖤ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᖥ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖦ"),l1l111_l1_ (u"࠭ࠧᖧ"),9999)
	l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵ࡯࡭ࡩ࡫ࡲࡩࡱࡰࡩ࠳ࡶࡨࡱࠩᖨ")
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖩ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᖪ")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᖫ"),l1ll1ll_l1_,821,l1l111_l1_ (u"ࠫࠬᖬ"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᖭ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᖮ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡖࡤࡦࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᖯ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᖰ"),block,re.DOTALL)
		for data,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂ࠭ᖱ")+data
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖲ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᖳ")+l1lllll_l1_+title,l1ll1ll_l1_,821,l1l111_l1_ (u"ࠬ࠭ᖴ"),l1l111_l1_ (u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧᖵ"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᖶ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖷ"),l1l111_l1_ (u"ࠩࠪᖸ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᖹ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᖺ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠬ࠵ࠧᖻ") not in l1ll1ll_l1_: continue
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖼ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᖽ")+l1lllll_l1_+title,l1ll1ll_l1_,821)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠨࠩᖾ")):
	block,items = l1l111_l1_ (u"ࠩࠪᖿ"),[]
	if type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᗀ"):
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᗁ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫᗂ")}
		payload = l1l111_l1_ (u"࠭ࡧࡦࡶࠪᗃ")
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬᗄ"),url,payload,headers,l1l111_l1_ (u"ࠨࠩᗅ"),l1l111_l1_ (u"ࠩࠪᗆ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᗇ"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡭ࡢࡩࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᗈ"),html,re.DOTALL)
		l1111l11l_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l1111l11l_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭ᗉ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᗊ"),url,l1l111_l1_ (u"ࠧࠨᗋ"),l1l111_l1_ (u"ࠨࠩᗌ"),l1l111_l1_ (u"ࠩࠪᗍ"),l1l111_l1_ (u"ࠪࠫᗎ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᗏ"))
		html = response.content
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᗐ"),url,l1l111_l1_ (u"࠭ࠧᗑ"),l1l111_l1_ (u"ࠧࠨᗒ"),l1l111_l1_ (u"ࠨࠩᗓ"),l1l111_l1_ (u"ࠩࠪᗔ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩᗕ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲ࡫ࡤࡪࡣ࠰ࡦࡱࡵࡣ࡬ࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷ࠳࡭ࡦࡰࡸࠫᗖ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if not block: block = html
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᗗ"),block,re.DOTALL)
	l111l1111_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࠰ࠩᗘ"),l1l111_l1_ (u"ࠧ࠰ࠩᗙ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫᗚ"),l1l111_l1_ (u"ࠩ࠲ࠫᗛ"))
		l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
		title = escapeUNICODE(title)
		if l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ᗜ") in l1ll1ll_l1_:
			l1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀ๊ࠫࠣࠬ๎ำๆࡾส่๊๎ำๆࠫࠪᗝ"),title,re.DOTALL)
			if l1111l1l_l1_: title = l1111l1l_l1_[0][0]
			else:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭ำไใหࡿห้ำไใหࠬࠫᗞ"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l1lll_l1_[0][0]
			if title in l111l1111_l1_: continue
			l111l1111_l1_.append(title)
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᗟ")+title.strip(l1l111_l1_ (u"ࠧࠡ⠕ࠣࠫᗠ"))
		if l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᗡ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),l1lllll_l1_+title,l1ll1ll_l1_,821,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬᗣ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗤ"),l1lllll_l1_+title,l1ll1ll_l1_,821,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩ࠴࠭ᗥ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗦ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡣࡱ࡭ࡲ࡫࠭ࡴࡧࡵ࡭ࡪ࠵ࠧᗧ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗨ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᗩ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗪ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧᗫ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗬ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᗭ"),l1lllll_l1_+title,l1ll1ll_l1_,822,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᗮ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗯ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗰ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩᗱ")+title,l1ll1ll_l1_,821)
	return
def l1111lll1_l1_(url,l1l11_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᗲ"),url,l1l111_l1_ (u"ࠬ࠭ᗳ"),l1l111_l1_ (u"࠭ࠧᗴ"),l1l111_l1_ (u"ࠧࠨᗵ"),l1l111_l1_ (u"ࠨࠩᗶ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡘࡋࡁࡔࡑࡑࡗࡤࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᗷ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴ࠰࡭ࡲࡧࡧࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᗸ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0] if l1ll1l_l1_ else l1l111_l1_ (u"ࠫࠬᗹ")
	items = []
	if not l1l11_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᗺ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭࠼࡭࡫࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡖࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡆࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᗻ"),block,re.DOTALL)
			if len(items)>1:
				for l1l11_l1_,l1111ll1l_l1_,l1111llll_l1_,title in items:
					title = title.replace(l1l111_l1_ (u"ࠧࠡࠢࠪᗼ"),l1l111_l1_ (u"ࠨࠢࠪᗽ"))
					l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡉࡨࡸࡘ࡫ࡡࡴࡱࡱࡉࡵࠬ࡟ࡴࡧࡤࡷࡴࡴ࠽ࠨᗾ")+l1l11_l1_+l1l111_l1_ (u"ࠪࠪࡤ࡙࠽ࠨᗿ")+l1111ll1l_l1_+l1l111_l1_ (u"ࠫࠫࡥࡂ࠾ࠩᘀ")+l1111llll_l1_
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘁ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧᘂ"),l1l11_l1_)
	if len(items)<2:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡇࡳ࡭ࡸࡵࡤࡦࡵࠣࡷࡪࡲࡥࡤࡶࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᘃ"),html,re.DOTALL)
		if l11llll_l1_: l111l11l1_l1_,block = l1l111_l1_ (u"ࠨࠩᘄ"),l11llll_l1_[0]
		else: l111l11l1_l1_,block = l1l111_l1_ (u"่ࠩ์ุ๋ࠠࠨᘅ")+l1l11_l1_,html
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧᘆ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = l111l11l1_l1_+l1l111_l1_ (u"ࠫࠥำไใหࠣࠫᘇ")+l1l1lll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧᘈ"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᘉ"),l1lllll_l1_+title,l1ll1ll_l1_,822,l1ll1l_l1_)
	return
def PLAY(url):
	url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪᘊ"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩᘋ")).replace(l1l111_l1_ (u"ࠩ࠲ࡥࡳ࡯࡭ࡦ࠱ࠪᘌ"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫᘍ")).replace(l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࠬᘎ"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭ᘏ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᘐ"),url,l1l111_l1_ (u"ࠧࠨᘑ"),l1l111_l1_ (u"ࠨࠩᘒ"),l1l111_l1_ (u"ࠩࠪᘓ"),l1l111_l1_ (u"ࠪࠫᘔ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᘕ"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠲ࡽࡲࡢࡲࡨࡶ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᘖ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1111l1ll_l1_.append(l1ll1ll_l1_)
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫᘗ"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᘘ")+server+l1l111_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩᘙ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᘚ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘛ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫ࡯࡭ࡨ࠿ࠪᘜ"),1)[0]
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᘝ"))
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᘞ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᘟ"))
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠰ࡦࡱࡵࡣ࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭ᘠ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			title = title.replace(l1l111_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠩᘡ"),l1l111_l1_ (u"ࠪࠤࠬᘢ")).replace(l1l111_l1_ (u"ࠫࡁ࠵ࡳࡱࡣࡱࡂࠬᘣ"),l1l111_l1_ (u"ࠬ࠭ᘤ")).replace(l1l111_l1_ (u"࠭࠼ࡪࡀࠪᘥ"),l1l111_l1_ (u"ࠧࠨᘦ")).replace(l1l111_l1_ (u"ࠨ࠾࠲࡭ࡃ࠭ᘧ"),l1l111_l1_ (u"ࠩࠣࠫᘨ"))
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬᘩ"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᘪ")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᘫ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᘬ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩᘭ"),l1l111_l1_ (u"ࠨ࠭ࠪᘮ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭ᘯ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪᘰ"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᘱ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᘲ"),url,l1l111_l1_ (u"࠭ࠧᘳ"),l1l111_l1_ (u"ࠧࠨᘴ"),l1l111_l1_ (u"ࠨࠩᘵ"),l1l111_l1_ (u"ࠩࠪᘶ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧᘷ"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡪࡶࡢࡰࡦࡩࡩ࠳ࡳࡦࡣࡵࡧ࡭࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫᘸ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥ࡯ࡷࠥࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᘹ"),block,re.DOTALL)
		names,l1111l111_l1_,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"࠭ࡣࡢࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰ࡮ࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᘺ"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᘻ") in url:
		url,filters = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᘼ"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᘽ")+filters
	else: l1ll1ll_l1_ = l111l1_l1_
	return l1ll1ll_l1_
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᘾ"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᘿ"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫᙀ"),l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧᙁ")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᙂ"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᙃ"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨᙄ")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᙅ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᙆ"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭ᙇ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧᙈ"),l1l111_l1_ (u"ࠧࠨᙉ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬᙊ"))
	if type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᙋ"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬᙌ") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭ᙍ") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧᙎ")+category+l1l111_l1_ (u"࠭࠽࠱ࠩᙏ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩᙐ")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫᙑ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫᙒ"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧᙓ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭ᙔ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᙕ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᙖ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬᙗ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᙘ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᙙ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᙚ")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙛ"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨᙜ"),l1llllll_l1_,821,l1l111_l1_ (u"࠭ࠧᙝ"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᙞ"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙟ"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩᙠ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩᙡ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠫࠬᙢ"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᙣ"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᙤ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᙥ"),l1l111_l1_ (u"ࠨࠩᙦ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠩๆ่ࠥ࠭ᙧ"),l1l111_l1_ (u"ࠪࠫᙨ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠫࡂ࠭ᙩ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᙪ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᙫ"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᙬ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᙭"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ᙮"),l1llllll_l1_,821,l1l111_l1_ (u"ࠪࠫᙯ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᙰ"))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙱ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧᙲ"),l1lllll1_l1_,825,l1l111_l1_ (u"ࠧࠨᙳ"),l1l111_l1_ (u"ࠨࠩᙴ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧᙵ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᙶ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧᙷ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᙸ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩᙹ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᙺ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙻ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫᙼ")+name,l1lllll1_l1_,824,l1l111_l1_ (u"ࠪࠫᙽ"),l1l111_l1_ (u"ࠫࠬᙾ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧᙿ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨ ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩᚁ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪᚂ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ᚃ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠪࠤ࠿࠭ᚄ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠫ࠵࠭ᚅ")]
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨᚆ")+name
			if type==l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫᚇ"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚈ"),l1lllll_l1_+title,url,824,l1l111_l1_ (u"ࠨࠩᚉ"),l1l111_l1_ (u"ࠩࠪᚊ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫᚋ") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠫࡂ࠭ᚌ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᚍ"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᚎ")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚏ"),l1lllll_l1_+title,l1llllll_l1_,821,l1l111_l1_ (u"ࠨࠩᚐ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᚑ"))
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᚒ"),l1lllll_l1_+title,url,825,l1l111_l1_ (u"ࠫࠬᚓ"),l1l111_l1_ (u"ࠬ࠭ᚔ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"࠭࠽ࠧࠩᚕ"),l1l111_l1_ (u"ࠧ࠾࠲ࠩࠫᚖ"))
	filters = filters.strip(l1l111_l1_ (u"ࠨࠨࠪᚗ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠩࡀࠫᚘ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠬᚙ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭ᚚ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭᚛")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"࠭࠰ࠨ᚜")
		if l1l111_l1_ (u"ࠧࠦࠩ᚝") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ᚞") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ᚟"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧᚠ")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᚡ") and value!=l1l111_l1_ (u"ࠬ࠶ࠧᚢ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨᚣ")+key+l1l111_l1_ (u"ࠧ࠾ࠩᚤ")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬᚥ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫᚦ")+key+l1l111_l1_ (u"ࠪࡁࠬᚧ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨᚨ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧᚩ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"࠭࠽࠱ࠩᚪ"),l1l111_l1_ (u"ࠧ࠾ࠩᚫ"))
	return l1l1l111_l1_
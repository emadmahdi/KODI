# -*- coding: utf-8 -*-
from LIBSTWO import *

script_namee = 'FAVORITES'

def MAINn(modee,favoriteIDd):
	if   modee==270: resultss = MENUu(favoriteIDd)
	#elif modee==271: resultss = DELETE_FAVORITES(favoriteIDd)
	else: resultss = False
	return resultss

def FAVORITES_DISPATCHER(contextt):
	if not contextt: return
	if '_' in contextt: favoriteIDd,contextt2 = contextt.split('_',1)
	else: favoriteIDd,contextt2 = contextt,''
	if   contextt2=='UP1'	: MOVE_FAVORITES(favoriteIDd,True,1)
	elif contextt2=='DOWN1'	: MOVE_FAVORITES(favoriteIDd,False,1)
	elif contextt2=='UP4'	: MOVE_FAVORITES(favoriteIDd,True,4)
	elif contextt2=='DOWN4'	: MOVE_FAVORITES(favoriteIDd,False,4)
	elif contextt2=='ADD1'	: ADD_TO_FAVORITES(favoriteIDd)
	elif contextt2=='REMOVE1': REMOVE_FROM_FAVORITES(favoriteIDd)
	elif contextt2=='DELETELIST': DELETE_FAVORITES(favoriteIDd)
	return

def MENUu(favoriteIDd):
	favoritesDICTt = GET_ALL_FAVORITES()
	if favoriteIDd in list(favoritesDICTt.keys()):
		#addMenuItem('folder','مسح هذه القائمة','',271,'','','',favoriteIDd)
		#addMenuItem('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		try:
			menuLISTt = favoritesDICTt[favoriteIDd]
			for typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt in menuLISTt:
				addMenuItem(typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt)
		except:
			favoritesDICTt = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
			menuLISTt = favoritesDICTt[favoriteIDd]
			for typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt in menuLISTt:
				addMenuItem(typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt)
	return

def ADD_TO_FAVORITES(favoriteIDd):
	typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt = EXTRACT_KODI_PATH(addon_path)
	#namee = RESTORE_PATH_NAME(namee)
	menuItemm = typee,namee,urll,modee,imagee,pagee,textt,'',infodictt
	favoritesDICTt = GET_ALL_FAVORITES()
	new_dictt = {}
	for IDd in list(favoritesDICTt.keys()):
		if IDd!=favoriteIDd: new_dictt[IDd] = favoritesDICTt[IDd]
		else:
			if namee and namee!='..':
				oldLISTt = favoritesDICTt[IDd]
				if menuItemm in oldLISTt:
					indexx = oldLISTt.index(menuItemm)
					del oldLISTt[indexx]
				newLISTt = oldLISTt+[menuItemm]
				new_dictt[IDd] = newLISTt
			else: new_dictt[IDd] = favoritesDICTt[IDd]
	if favoriteIDd not in list(new_dictt.keys()): new_dictt[favoriteIDd] = [menuItemm]
	newFILEe = str(new_dictt)
	if PY3: newFILEe = newFILEe.encode('utf8')
	open(favoritesfile,'wb').write(newFILEe)
	return

def REMOVE_FROM_FAVORITES(favoriteIDd):
	typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt = EXTRACT_KODI_PATH(addon_path)
	#namee = RESTORE_PATH_NAME(namee)
	menuItemm = typee,namee,urll,modee,imagee,pagee,textt,'',infodictt
	favoritesDICTt = GET_ALL_FAVORITES()
	if favoriteIDd in list(favoritesDICTt.keys()) and menuItemm in favoritesDICTt[favoriteIDd]:
		favoritesDICTt[favoriteIDd].remove(menuItemm)
		if len(favoritesDICTt[favoriteIDd])==0: del favoritesDICTt[favoriteIDd]
		newFILEe = str(favoritesDICTt)
		if PY3: newFILEe = newFILEe.encode('utf8')
		open(favoritesfile,'wb').write(newFILEe)
	return

def MOVE_FAVORITES(favoriteIDd,move_upp,repeatt):
	typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt = EXTRACT_KODI_PATH(addon_path)
	#namee = RESTORE_PATH_NAME(namee)
	menuItemm = typee,namee,urll,modee,imagee,pagee,textt,'',infodictt
	favoritesDICTt = GET_ALL_FAVORITES()
	if favoriteIDd in list(favoritesDICTt.keys()):
		oldLISTt = favoritesDICTt[favoriteIDd]
		#WRITE_THIS(namee+' +++++++++++ '+str(namee)+' +++++++++++ '+str('')+' +++++++++++++++ '+str(oldLISTt[0]))
		if menuItemm not in oldLISTt: return
		sizee = len(oldLISTt)
		for iiii in range(0,repeatt):
			old_indexx = oldLISTt.index(menuItemm)
			if move_upp: new_indexx = old_indexx-1
			else: new_indexx = old_indexx+1
			if new_indexx>=sizee: new_indexx = new_indexx-sizee
			if new_indexx<0: new_indexx = new_indexx+sizee
			oldLISTt.insert(new_indexx, oldLISTt.pop(old_indexx))
		favoritesDICTt[favoriteIDd] = oldLISTt
		newFILEe = str(favoritesDICTt)
		if PY3: newFILEe = newFILEe.encode('utf8')
		open(favoritesfile,'wb').write(newFILEe)
	return

def DELETE_FAVORITES(favoriteIDd):
	yess = DIALOGg_YESNO('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+favoriteIDd+' ؟!')
	if yess!=1: return
	favoritesDICTt = GET_ALL_FAVORITES()
	if favoriteIDd in list(favoritesDICTt.keys()):
		del favoritesDICTt[favoriteIDd]
		newFILEe = str(favoritesDICTt)
		if PY3: newFILEe = newFILEe.encode('utf8')
		open(favoritesfile,'wb').write(newFILEe)
		DIALOGg_OK('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+favoriteIDd)
	return

def GET_ALL_FAVORITES():
	favoritesDICTt = {}
	if os.path.exists(favoritesfile):
		oldFILEe = open(favoritesfile,'rb').read()
		if PY3: oldFILEe = oldFILEe.decode('utf8')
		favoritesDICTt = EVALl('dict',oldFILEe)
	return favoritesDICTt

def GET_FAVORITES_CONTEXT_MENU(favoritesDICTt,menuItemm,kodipathh):
	#LOGg_THIS('',str(menuItemm))
	#LOGg_THIS('',str(kodipathh))
	typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt = menuItemm
	if not modee: typee,modee = 'folder','260'
	contextMenuu,favoriteIDd = [],''
	if 'context=' in addon_path:
		tmpp = re.findall('context=(\d+)',addon_path,re.DOTALL)
		if tmpp: favoriteIDd = str(tmpp[0])
	if modee=='270':
		favoriteIDd = contextt
		if favoriteIDd in list(favoritesDICTt.keys()):
			contextMenuu.append(('مسح قائمة مفضلة '+favoriteIDd,'RunPlugin('+kodipathh+'&context='+favoriteIDd+'_DELETELIST'+')'))
	else:
		if favoriteIDd in list(favoritesDICTt.keys()):
			count = len(favoritesDICTt[favoriteIDd])
			if count>1: contextMenuu.append(('تحريك 1 للأعلى','RunPlugin('+kodipathh+'&context='+favoriteIDd+'_UP1)'))
			if count>4: contextMenuu.append(('تحريك 4 للأعلى','RunPlugin('+kodipathh+'&context='+favoriteIDd+'_UP4)'))
			if count>1: contextMenuu.append(('تحريك 1 للأسفل','RunPlugin('+kodipathh+'&context='+favoriteIDd+'_DOWN1)'))
			if count>4: contextMenuu.append(('تحريك 4 للأسفل','RunPlugin('+kodipathh+'&context='+favoriteIDd+'_DOWN4)'))
		for favoriteIDd in ['1','2','3','4','5']:
			if favoriteIDd in list(favoritesDICTt.keys()) and menuItemm in favoritesDICTt[favoriteIDd]:
				contextMenuu.append(('مسح من مفضلة '+favoriteIDd,'RunPlugin('+kodipathh+'&context='+favoriteIDd+'_REMOVE1)'))
			else: contextMenuu.append(('إضافة إلى مفضلة '+favoriteIDd,'RunPlugin('+kodipathh+'&context='+favoriteIDd+'_ADD1)'))
	contextMenuNEWw = []
	for iiii1,iiii2 in contextMenuu:
		iiii1 = '[COLOR FFFFFF00]'+iiii1+'[/COLOR]'
		contextMenuNEWw.append((iiii1,iiii2,))
	return contextMenuNEWw

#"""
#def FIX_OLD_FAVORITE_ITEMS():
#	newDICTt = {}
#	favoritesDICTt = GET_ALL_FAVORITES()
#	for favoriteIDd in list(favoritesDICTt.keys()):
#		newDICTt[favoriteIDd] = []
#		menuLISTt = favoritesDICTt[favoriteIDd]
#		for typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt in menuLISTt:
#			#namee = RESTORE_PATH_NAME(namee)
#			menuItemm = typee,namee,urll,modee,imagee,pagee,textt,'',infodictt
#			newDICTt[favoriteIDd].append(menuItemm)
#	newFILEe = str(newDICTt)
#	if PY3: newFILEe = newFILEe.encode('utf8')
#	open(favoritesfile,'wb').write(newFILEe)
#	return
#"""







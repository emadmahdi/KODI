# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1lll_l1_(l1l111_l1_ (u"ࠨࡖࡈࡗ࡙࠭娨"),l1l111_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ娩"))
l1ll11ll11ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡼ࠴࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡸ࡭࡯࡮࡬ࡤࡵࡳࡦࡪࡢࡢࡰࡧ࠲ࡨࡵ࡭࠰࠳࠳ࡑࡇ࠴ࡺࡪࡲࠪ娪")
l1ll11ll11ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶࡥࡦࡦࡷࡩࡸࡺ࠮ࡧࡶࡳ࠲ࡴࡺࡥ࡯ࡧࡷ࠲࡬ࡸ࠯ࡧ࡫࡯ࡩࡸ࠵ࡴࡦࡵࡷ࠵࠵࠶࡫࠯ࡦࡥࠫ娫")
l11111111l1_l1_(l1ll11ll11ll_l1_,{},True)
url = l1l111_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜โฯุ࠲ࡲࡶ࠳ࠨ娬")
url = l1l111_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ࡨ࡬ࡰࡪࡥ࠴࠹࠵࠷ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫ娭")
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ啿")
headers = l1l111_l1_ (u"࠭ࠧ喀")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭喁")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭喂"),l1l111_l1_ (u"ࠩส่่๊ࠧ喃"),l1l111_l1_ (u"ࠪหๆ๊วๆࠩ善"),l1l111_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ喅"),l1l111_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ喆")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ喇")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ喈")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ喉"),l111l1_l1_,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ喊"),l1l111_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ喋"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵࠩ喌"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喍"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭喎"),l1l111_l1_ (u"ࠧࠨ喏"),119,l1l111_l1_ (u"ࠨࠩ喐"),l1l111_l1_ (u"ࠩࠪ喑"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ喒"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ喓"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ喔"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喕"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ喖"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭喗"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ喘"),l1l111_l1_ (u"ࠪࠫ喙"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ喚"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭喛"),l1l11ll_l1_,111,l1l111_l1_ (u"࠭ࠧ喜"),l1l111_l1_ (u"ࠧࠨ喝"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ喞"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠪ喟"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ喠"),l1l111_l1_ (u"ࠫࠬ喡"),l1l111_l1_ (u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧ喢"),l1l111_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส๐ฬศัࠣ฽๋๎ว็ࠢส่๊๎โฺࠢฦ์ࠥะีๆ์่ࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠩ喣"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭喤"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喥"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ喦")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ喧"),filter)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ喨"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ喩"),l1l111_l1_ (u"࠭ࠧ喪"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡴࡲࡴࡩࡵࡷ࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ喫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ喬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ喭"),l1l111_l1_ (u"ࠪࠫ單")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ喯"),l1l111_l1_ (u"ࠬ࠭喰")).strip(l1l111_l1_ (u"࠭ࠠࠨ喱"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ喲") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ喳") in l1ll1ll_l1_: title = l1l111_l1_ (u"้ࠩ๎ฯ็ไไีࠪ喴")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喵"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭営")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠬ࠭喷"),response=l1l111_l1_ (u"࠭ࠧ喸")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ喹"),url,l1l111_l1_ (u"ࠨࠩ喺"),headers,l1l111_l1_ (u"ࠩࠪ喻"),l1l111_l1_ (u"ࠪࠫ喼"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ喽"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ喾"): l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡧ࡭࡫ࡧࡩࡤࡥࡳ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ喿"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ嗀"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ嗁"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ嗂"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ嗃"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ嗄"),l1l111_l1_ (u"้ࠬไ๋สࠪ嗅"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ嗆"),l1l111_l1_ (u"่ࠧัสๅࠬ嗇"),l1l111_l1_ (u"ࠨ็หหึอษࠨ嗈"),l1l111_l1_ (u"ࠩ฼ี฻࠭嗉"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ嗊"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ嗋")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ嗌") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ嗍"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ嗎"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ嗏"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ嗐") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ嗑") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嗒"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬ嗓") in title and l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ嗔") not in url:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭嗕") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嗖"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ嗗") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗘"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭嗙") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嗚") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ嗛")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗜"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ嗝") in url and l1l111_l1_ (u"ࠩะ่็ฯࠧ嗞") in title:
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嗟"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嗠"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ嗡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭嗢"): items = re.findall(l1l111_l1_ (u"ࠧࠩࡷࡳࡨࡦࡺࡥࡒࡷࡨࡶࡾ࠯࠮ࠫࡁࡁࠬ࠳࠱࠿ࠪ࠾ࠪ嗣"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嗤"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ嗥"):
				title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭嗦"),l1l111_l1_ (u"ࠫࠬ嗧")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ嗨"),l1l111_l1_ (u"࠭ࠧ嗩"))
				if l1l111_l1_ (u"ࠧࡀࠩ嗪") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ嗫")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩ嗬")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗭"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ嗮")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠬ࠭嗯"),l1l111_l1_ (u"࠭ࠧ嗰"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1ll1ll11_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嗱"),url,l1l111_l1_ (u"ࠨࠩ嗲"),headers,l1l111_l1_ (u"ࠩࠪ嗳"),l1l111_l1_ (u"ࠪࠫ嗴"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ嗵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠤࡩ࠳ࡦ࡭ࡧࡻࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ嗶"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ嗷") in l11llll_l1_[0]: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l111llll_l1_ in range(2):
		if l11l1ll1ll11_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗸"),l111lllll1_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嗹"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嗺"),block,re.DOTALL)
		if l11l1ll1ll11_l1_ and len(items)<2:
			l11l1ll1ll11_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠪࠤࠬ嗻")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹࠧ嗼") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡲࡦࡣࡧࡧࡷࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嗽"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嗾"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ嗿")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嘀"),url,l1l111_l1_ (u"ࠩࠪ嘁"),headers,l1l111_l1_ (u"ࠪࠫ嘂"),l1l111_l1_ (u"ࠫࠬ嘃"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ嘄"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡡࡤࡶ࡬ࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ嘅"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘆"),block,re.DOTALL)
	l11l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ嘇") in block
	download = l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭嘈") in block
	if   l11l1ll1ll1l_l1_ and not download: l11l1ll1lll1_l1_,l11l1ll1l1ll_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠪࠫ嘉")
	elif not l11l1ll1ll1l_l1_ and download: l11l1ll1lll1_l1_,l11l1ll1l1ll_l1_ = l1l111_l1_ (u"ࠫࠬ嘊"),l1ll_l1_[0]
	elif l11l1ll1ll1l_l1_ and download: l11l1ll1lll1_l1_,l11l1ll1l1ll_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l1ll1lll1_l1_,l11l1ll1l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭嘋"),l1l111_l1_ (u"࠭ࠧ嘌")
	if l11l1ll1ll1l_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嘍"),l11l1ll1lll1_l1_,l1l111_l1_ (u"ࠨࠩ嘎"),headers,l1l111_l1_ (u"ࠩࠪ嘏"),l1l111_l1_ (u"ࠪࠫ嘐"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ嘑"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲࡥࡵࠢࡶࡩࡷࡼࡥࡳࡵࠫ࠲࠯ࡅࠩࡱ࡮ࡤࡽࡪࡸࠧ嘒"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ嘓"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞࠲ࠫ嘔"),l1l111_l1_ (u"ࠨ࠱ࠪ嘕"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ嘖")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ嘗")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嘘"),l11l1ll1l1ll_l1_,l1l111_l1_ (u"ࠬ࠭嘙"),headers,l1l111_l1_ (u"࠭ࠧ嘚"),l1l111_l1_ (u"ࠧࠨ嘛"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ嘜"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࡬ࡲ࡫ࡵ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠪ嘝"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嘞"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嘟")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ嘠")+l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ嘡")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嘢"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ嘣"),l1l111_l1_ (u"ࠩ࠮ࠫ嘤"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧ嘥")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嘦"),url,l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ嘧"),l1l111_l1_ (u"࠭ิศ้าࠤๆ๎ั๋๊ࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨࠥ࠺ࡵࠨ嘨"),l1l111_l1_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠯ࡰࡨࡸࠬ嘩"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ嘪"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭嘫"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嘬"),url,l1l111_l1_ (u"ࠫࠬ嘭"),headers,l1l111_l1_ (u"ࠬ࠭嘮"),l1l111_l1_ (u"࠭ࠧ嘯"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ嘰"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣࡧࡺ࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡶ࡬ࡴࡽࡳ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠫ嘱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡸࡴࡩࡧࡴࡦࡓࡸࡩࡷࡿ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺࠧ嘲"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄ࡜ࡴࠬࠫ࠲࠯ࡅࠩ࡝ࡵ࠭ࡀࠬ嘳"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ嘴") not in url: url = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ嘵")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ嘶"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ嘷"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ嘸"),l1l111_l1_ (u"ࠩ࠲ࡃࠬ嘹"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ嘺"),l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ嘻"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ嘼"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ嘽")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ嘾"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ嘿"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ噀")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ噁"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ噂"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭噃"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧ噄"),l1l111_l1_ (u"ࠧࠨ噅")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ噆"))
	if type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ噇"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬ噈") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭噉") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ噊")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ噋")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ噌")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ噍")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ噎"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ噏")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭噐"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ噑"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ噒")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ噓"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ噔"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪ噕"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭噖"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬ噗"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ噘")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭噙"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ噚"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噛"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ噜")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ噝"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ噞"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ噟"),l1l111_l1_ (u"࠭ࠧ噠"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠧไๆࠣࠫ噡"),l1l111_l1_ (u"ࠨࠩ噢"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫ噣") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ噤"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ噥")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ噦"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ噧"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ器"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ噩"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠩࠪ噪"),l1l111_l1_ (u"ࠪࠫ噫"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ噬"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ噭")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ噮")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ噯")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ噰")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭噱")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噲"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭噳")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠬ࠭噴"),l1l111_l1_ (u"࠭ࠧ噵"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧ噶"): option = l1l111_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ噷")
			elif value==l1l111_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ噸"): option = l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ噹")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭噺")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ噻")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ噼")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ噽")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ噾")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ噿")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠪ࠴ࠬ嚀")]
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧ嚁")+name
			if type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ嚂"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚃"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠧࠨ嚄"),l1l111_l1_ (u"ࠨࠩ嚅"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ嚆") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬ嚇") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ嚈"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ嚉")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚊"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嚋"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠨࠩ嚌"),l1l111_l1_ (u"ࠩࠪ嚍"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁࠫ࠭嚎"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨ嚏"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ嚐"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ嚑") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ嚒"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ嚓"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ嚔")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ嚕")
		if l1l111_l1_ (u"ࠫࠪ࠭嚖") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ嚗") and value!=l1l111_l1_ (u"࠭࠰ࠨ嚘"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ嚙")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嚚") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ嚛"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ嚜")+key+l1l111_l1_ (u"ࠫࡂ࠭嚝")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ嚞"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ嚟")+key+l1l111_l1_ (u"ࠧ࠾ࠩ嚠")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ嚡"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ嚢"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭嚣"),l1l111_l1_ (u"ࠫࡂ࠭嚤"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㱰")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ㱱")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭㱲"),l1l111_l1_ (u"ࠬอำหใึหึะใๆ๋ࠢࠤฬ๊ืๅสสฮࠬ㱳")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㱴"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ㱵"),l1l111_l1_ (u"ࠨࠩ㱶"),l1l111_l1_ (u"ࠩࠪ㱷"),l1l111_l1_ (u"ࠪࠫ㱸"),l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㱹"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㱺"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㱻"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㱼"),l1l111_l1_ (u"ࠨࠩ㱽"),459,l1l111_l1_ (u"ࠩࠪ㱾"),l1l111_l1_ (u"ࠪࠫ㱿"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㲀"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲁"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㲂")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆอหฮฬะࠠๅ๊า๎ࠥ์สࠨ㲃"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠨࠩ㲄"),l1l111_l1_ (u"ࠩࠪ㲅"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㲆"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲇"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㲈")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ㲉"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠧࠨ㲊"),l1l111_l1_ (u"ࠨࠩ㲋"),l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ㲌"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㲍"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㲎"),l1l111_l1_ (u"ࠬ࠭㲏"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡎࡣ࡬ࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠭㲐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㲑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ㲒"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲓"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㲔")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬ㲕")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㲖"),url,l1l111_l1_ (u"࠭ࠧ㲗"),l1l111_l1_ (u"ࠧࠨ㲘"),l1l111_l1_ (u"ࠨࠩ㲙"),l1l111_l1_ (u"ࠩࠪ㲚"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ㲛"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㲜"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡺࡥࡻ࡫ࡳࠣࠩ㲝"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㲞"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡔࡨࡧࡪࡴࡴࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ㲟"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠧ㲠") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ㲡"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࠢࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㲢"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"ࠫ࠵࠭㲣"),l1l111_l1_ (u"ࠬ࠷ࠧ㲤"),l1l111_l1_ (u"࠭࠲ࠨ㲥")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࠫ㲦"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㲧"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ㲨"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ㲩"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ㲪"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ㲫"),l1l111_l1_ (u"࠭ร฻่ํอࠬ㲬"),l1l111_l1_ (u"ࠧไๆํฬࠬ㲭"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ㲮"),l1l111_l1_ (u"๊ࠩำฬ็ࠧ㲯"),l1l111_l1_ (u"้ࠪออัศหࠪ㲰"),l1l111_l1_ (u"ࠫ฾ืึࠨ㲱"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬ㲲"),l1l111_l1_ (u"࠭วๅส๋้ࠬ㲳")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭㲴") in html and l1l111_l1_ (u"ࠨࡵࡵࡧࡂ࠭㲵") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㲶"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬ㲷"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ㲸"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ㲹"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"࠭ๅิๆึ่ࠬ㲺") not in title:
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㲻"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠨฯ็ๆฮ࠭㲼") in title:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㲽") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲾"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲿"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠬ࠭㳀"),l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㳁")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㳂"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㳃"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳄"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ㳅")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㳆"),url,l1l111_l1_ (u"ࠬ࠭㳇"),l1l111_l1_ (u"࠭ࠧ㳈"),l1l111_l1_ (u"ࠧࠨ㳉"),l1l111_l1_ (u"ࠨࠩ㳊"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨ㳋"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡈࡧࡴࡦࡩࡲࡶࡾ࡙ࡵࡣࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㳌"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ㳍") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬ࠱ࠬ㳎"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"࠭ࠠࠨ㳏"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳐"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㳑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳒"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㳓"),url,l1l111_l1_ (u"ࠫࠬ㳔"),l1l111_l1_ (u"ࠬ࠭㳕"),l1l111_l1_ (u"࠭ࠧ㳖"),l1l111_l1_ (u"ࠧࠨ㳗"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ㳘"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡄࡶࡪࡧࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ㳙"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂࠬ㳚"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㳛"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㳜"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㳝"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳞"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ㳟")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫ㳠"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫ㳡"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㳢"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㳣"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㳤"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㳥"),l1l111_l1_ (u"ࠨࠩ㳦"),l1l111_l1_ (u"ࠩࠪ㳧"),l1l111_l1_ (u"ࠪࠫ㳨"),l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㳩"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㳪"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡚ࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡹࡩࡥࡧࡁࠫ㳫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ㳬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㳭")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ㳮")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫࠥࡷࡪࡲࡡࡳࡻࠥࠫ㳯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㳰"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭㳱"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ㳲")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"ࠧࠨ㳳")
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ㳴")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㳵")+name+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㳶")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㳷"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭㳸"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ㳹"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ㳺"),l1l111_l1_ (u"ࠨ࠭ࠪ㳻"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ㳼")+search
	l1lll11_l1_(url)
	return
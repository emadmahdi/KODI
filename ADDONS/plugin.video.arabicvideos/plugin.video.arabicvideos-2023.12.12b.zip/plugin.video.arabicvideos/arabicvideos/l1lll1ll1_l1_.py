# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ఩")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡇࡖࡐࡣࠬప")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1llll1l1_l1_ = [l1l111_l1_ (u"ࠧ࠲࠴࠶࠽ࠬఫ"),l1l111_l1_ (u"ࠨ࠳࠵࠹࠵࠭బ"),l1l111_l1_ (u"ࠩ࠴࠶࠹࠻ࠧభ"),l1l111_l1_ (u"ࠪ࠶࠵࠭మ"),l1l111_l1_ (u"ࠫ࠶࠸࠵࠺ࠩయ"),l1l111_l1_ (u"ࠬ࠸࠱࠹ࠩర"),l1l111_l1_ (u"࠭࠴࠹࠷ࠪఱ"),l1l111_l1_ (u"ࠧ࠲࠴࠶࠼ࠬల"),l1l111_l1_ (u"ࠨ࠳࠵࠹࠽࠭ళ"),l1l111_l1_ (u"ࠩ࠵࠽࠷࠭ఴ")]
l1llll11l_l1_ = [l1l111_l1_ (u"ࠪ࠷࠵࠹࠰ࠨవ"),l1l111_l1_ (u"ࠫ࠻࠸࠸ࠨశ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==60: l1lll_l1_ = l1l1l11_l1_()
	elif mode==61: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==62: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==63: l1lll_l1_ = PLAY(url)
	elif mode==64: l1lll_l1_ = l1llll1ll_l1_(text)
	elif mode==69: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬష"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭స"),l1l111_l1_ (u"ࠧࠨహ"),69,l1l111_l1_ (u"ࠨࠩ఺"),l1l111_l1_ (u"ࠩࠪ఻"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ఼ࠧ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫఽ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧా")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅศࠢํฮ๊ࠦๅีษ๊ำฯํࠠศๆส๊ࠬి"),l111l1_l1_,64,l1l111_l1_ (u"ࠧࠨీ"),l1l111_l1_ (u"ࠨࠩు"),l1l111_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵࡡࡹ࡭ࡪࡽࡥࡥࡡࡹ࡭ࡩࡹࠧూ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪృ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ౄ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไศๅฮี๋ࠥิศ้าอࠬ౅"),l111l1_l1_,64,l1l111_l1_ (u"࠭ࠧె"),l1l111_l1_ (u"ࠧࠨే"),l1l111_l1_ (u"ࠨ࡯ࡲࡷࡹࡥࡶࡪࡧࡺࡩࡩࡥࡶࡪࡦࡶࠫై"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ౉"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬొ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ฼๊โฬ้ࠣษิัศࠩో"),l111l1_l1_,64,l1l111_l1_ (u"ࠬ࠭ౌ"),l1l111_l1_ (u"్࠭ࠧ"),l1l111_l1_ (u"ࠧࡳࡧࡦࡩࡳࡺ࡬ࡺࡡࡤࡨࡩ࡫ࡤࡠࡸ࡬ࡨࡸ࠭౎"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ౏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ౐")+l1lllll_l1_+l1l111_l1_ (u"ࠪๅ๏ี๊้ࠢ฼ุํอฦ๋ࠩ౑"),l111l1_l1_,64,l1l111_l1_ (u"ࠫࠬ౒"),l1l111_l1_ (u"ࠬ࠭౓"),l1l111_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡥࡶࡪࡦࡶࠫ౔"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸౕࠧ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡౖࠪ")+l1lllll_l1_+l1l111_l1_ (u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪ౗"),l111l1_l1_,61,l1l111_l1_ (u"ࠪࠫౘ"),l1l111_l1_ (u"ࠫࠬౙ"),l1l111_l1_ (u"ࠬ࠳࠱ࠨౚ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౛"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ౜")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ฬึอๅอࠢส่ิ๐ๆ๋หࠪౝ"),l111l1_l1_,61,l1l111_l1_ (u"ࠩࠪ౞"),l1l111_l1_ (u"ࠪࠫ౟"),l1l111_l1_ (u"ࠫ࠲࠸ࠧౠ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬౡ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨౢ")+l1lllll_l1_+l1l111_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠡࡘ࡬ࡨࡪࡵࡳࠨౣ"),l111l1_l1_,61,l1l111_l1_ (u"ࠨࠩ౤"),l1l111_l1_ (u"ࠩࠪ౥"),l1l111_l1_ (u"ࠪ࠱࠸࠭౦"))
	return l1l111_l1_ (u"ࠫࠬ౧")
def l1lll11_l1_(url,category):
	cat = l1l111_l1_ (u"ࠬ࠭౨")
	if category not in [l1l111_l1_ (u"࠭࠭࠲ࠩ౩"),l1l111_l1_ (u"ࠧ࠮࠴ࠪ౪"),l1l111_l1_ (u"ࠨ࠯࠶ࠫ౫")]: cat = l1l111_l1_ (u"ࠩࡂࡧࡦࡺ࠽ࠨ౬")+category
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲ࡫࡮ࡶࡡ࡯ࡩࡻ࡫࡬࠯ࡲ࡫ࡴࠬ౭")+cat
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ౮"),l1l111_l1_ (u"ࠬ࠭౯"),l1l111_l1_ (u"࠭ࠧ౰"),l1l111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭౱"))
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ౲"),html,re.DOTALL)
	l1lll1lll_l1_,found = False,False
	for l1ll1ll_l1_,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ౳"))
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ౴") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ౵")+l1ll1ll_l1_
		cat = re.findall(l1l111_l1_ (u"ࠬࡩࡡࡵ࠿ࠫ࠲࠯ࡅࠩࠧࠩ౶"),l1ll1ll_l1_,re.DOTALL)[0]
		if category==cat: l1lll1lll_l1_ = True
		elif l1lll1lll_l1_ 	or (category==l1l111_l1_ (u"࠭࠭࠲ࠩ౷") and cat in l1llll1l1_l1_) \
						or (category==l1l111_l1_ (u"ࠧ࠮࠴ࠪ౸") and cat not in l1llll11l_l1_ and cat not in l1llll1l1_l1_) \
						or (category==l1l111_l1_ (u"ࠨ࠯࠶ࠫ౹") and cat in l1llll11l_l1_):
							if count==l1l111_l1_ (u"ࠩ࠴ࠫ౺"): addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ౻"),l1lllll_l1_+title,l1ll1ll_l1_,63)
							else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ౼"),l1lllll_l1_+title,l1ll1ll_l1_,61,l1l111_l1_ (u"ࠬ࠭౽"),l1l111_l1_ (u"࠭ࠧ౾"),cat)
							found = True
	if not found: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ౿"),l1l111_l1_ (u"ࠨࠩಀ"),True,l1l111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪಁ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠨಂ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡬ࡸࡩࡥࡡࡹ࡭ࡪࡽ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩಃ"),block,re.DOTALL)
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࠭಄")
	for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
		title = title.replace(l1l111_l1_ (u"࠭ࡁࡥࡦࠪಅ"),l1l111_l1_ (u"ࠧࠨಆ")).replace(l1l111_l1_ (u"ࠨࡶࡲࠤࡖࡻࡩࡤ࡭࡯࡭ࡸࡺࠧಇ"),l1l111_l1_ (u"ࠩࠪಈ")).strip(l1l111_l1_ (u"ࠪࠤࠬಉ"))
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩಊ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫಋ")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬಌ"),l1lllll_l1_+title,l1ll1ll_l1_,63,l1ll1l_l1_)
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ಍"),block,re.DOTALL)
	block=l11llll_l1_[0]
	block=re.findall(l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩಎ"),html,re.DOTALL)[0]
	items=re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫಏ"),block,re.DOTALL)
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࠬಐ"))[0]
	for l1ll1ll_l1_,l1lll1l1l_l1_ in items:
		l1ll1ll_l1_ = l1lllll1_l1_ + l1ll1ll_l1_
		title = unescapeHTML(l1lll1l1l_l1_)
		title = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ಑") + title
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಒ"),l1lllll_l1_+title,l1ll1ll_l1_,62)
	return l1ll1ll_l1_
def PLAY(url):
	if l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪಓ") in url: url = l1ll1l11_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨಔ"),l1l111_l1_ (u"ࠨࠩಕ"),True,l1l111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ಖ"))
	items = re.findall(l1l111_l1_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪಗ"),html,re.DOTALL)
	url = items[0]
	if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩಘ") not in url: url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫಙ")+url
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬಚ"))
	return
def l1llll1ll_l1_(category):
	payload = { l1l111_l1_ (u"ࠧ࡮ࡱࡧࡩࠬಛ") : category }
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡪࡦࡺࡩ࡮࡫࠱ࡸࡻ࠵ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࠨಜ")
	headers = { l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨಝ") : l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩಞ") }
	data = l1lllll11_l1_(payload)
	html = l1l1llll_l1_(l111l11l_l1_,url,data,headers,True,l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠳ࡍࡐࡕࡗࡗ࠲࠷ࡳࡵࠩಟ"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫࠭ಠ"),html,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨಡ"))
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬಢ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧಣ")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨತ"),l1lllll_l1_+title,l1ll1ll_l1_,63,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫಥ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬದ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧಧ"),l1l111_l1_ (u"࠭ࠫࠨನ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡠࡴࡨࡷࡺࡲࡴ࠯ࡲ࡫ࡴࡄࡷࡵࡦࡴࡼࡁࠬ಩") + l1lll1ll_l1_
	l1ll1l11_l1_(url)
	return
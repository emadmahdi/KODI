# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭ስ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡄࡕࡗࡤ࠭ሶ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪሷ"),l1l111_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪሸ"),l1l111_l1_ (u"ࠪห้อโิษ่ࠫሹ"),l1l111_l1_ (u"ࠫ฾ืึࠡษ็้ื๐ฯࠨሺ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==650: l1lll_l1_ = l1l1l11_l1_()
	elif mode==651: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==652: l1lll_l1_ = PLAY(url)
	elif mode==653: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==654: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==659: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩሻ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧሼ"),l1l111_l1_ (u"ࠧࠨሽ"),l1l111_l1_ (u"ࠨࠩሾ"),l1l111_l1_ (u"ࠩࠪሿ"),l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬቀ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫቁ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬቂ"),l1l111_l1_ (u"࠭ࠧቃ"),659,l1l111_l1_ (u"ࠧࠨቄ"),l1l111_l1_ (u"ࠨࠩቅ"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ቆ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨቇ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫቈ"),l1l111_l1_ (u"ࠬ࠭቉"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ቊ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩቋ")+l1lllll_l1_+l1l111_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧቌ"),l111l1_l1_,651,l1l111_l1_ (u"ࠩࠪቍ"),l1l111_l1_ (u"ࠪࠫ቎"),l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ቏"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬቐ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨቑ")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧቒ"),l111l1_l1_,651,l1l111_l1_ (u"ࠨࠩቓ"),l1l111_l1_ (u"ࠩࠪቔ"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬቕ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩቖ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ቗"),l1l111_l1_ (u"࠭ࠧቘ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ቙"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫቚ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		title = title.replace(l1l111_l1_ (u"ࠩ࠿ࡦࡃ࠭ቛ"),l1l111_l1_ (u"ࠪࠫቜ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ቝ"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ቞"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ቟")+l1lllll_l1_+title,l1ll1ll_l1_,654)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫበ"),url,l1l111_l1_ (u"ࠨࠩቡ"),l1l111_l1_ (u"ࠩࠪቢ"),l1l111_l1_ (u"ࠪࠫባ"),l1l111_l1_ (u"ࠫࠬቤ"),l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪብ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪቦ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨቧ"),l1l111_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧቨ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ቩ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠪࠫቪ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩቫ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪቬ"),l1l111_l1_ (u"࠭ࠧቭ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬቮ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠨ࠼ࠣࠫቯ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩተ"),l1lllll_l1_+title,l1ll1ll_l1_,651)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧቱ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ቲ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪታ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ቴ"),l1l111_l1_ (u"ࠧࠨት"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨቶ"),l1lllll_l1_+title,l1ll1ll_l1_,651)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠩࠪቷ")):
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨቸ"):
		url,search = url.split(l1l111_l1_ (u"ࠫࡄ࠭ቹ"),1)
		data = l1l111_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫቺ")+search
		headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬቻ"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧቼ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ች"),url,data,headers,l1l111_l1_ (u"ࠩࠪቾ"),l1l111_l1_ (u"ࠪࠫቿ"),l1l111_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨኀ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩኁ"),url,l1l111_l1_ (u"࠭ࠧኂ"),l1l111_l1_ (u"ࠧࠨኃ"),l1l111_l1_ (u"ࠨࠩኄ"),l1l111_l1_ (u"ࠩࠪኅ"),l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧኆ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠫࠬኇ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩኈ"))
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ኉"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩኊ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩኋ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫኌ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫኍ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ኎"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ኏"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪነ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧኑ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪኒ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡦࡦࠦ࡭ࡨࡤࠣࡸࡦࡨ࡬ࡦࠢࡩࡹࡱࡲࠢࠩ࠰࠭ࡃ࠮ࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩና"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩኔ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬን"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ኖ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧኗ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧኘ"),l1l111_l1_ (u"ࠨใํ่๊࠭ኙ"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨኚ"),l1l111_l1_ (u"ࠪ็้๐ศࠨኛ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪኜ"),l1l111_l1_ (u"ࠬํฯศใࠪኝ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭ኞ"),l1l111_l1_ (u"ฺࠧำูࠫኟ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨአ"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨኡ"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪኢ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧኣ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫኤ"),l1lllll_l1_+title,l1ll1ll_l1_,652,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬእ"):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ኦ"),l1lllll_l1_+title,l1ll1ll_l1_,652,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧኧ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩከ"),l1lllll_l1_+title,l1ll1ll_l1_,653,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪኩ"),l1lllll_l1_+title,l1ll1ll_l1_,653,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬኪ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪካ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨኬ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩክ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪኮ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩኯ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩኰ")+title,l1ll1ll_l1_,651)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ኱"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩኲ"),url,l1l111_l1_ (u"࠭ࠧኳ"),l1l111_l1_ (u"ࠧࠨኴ"),l1l111_l1_ (u"ࠨࠩኵ"),l1l111_l1_ (u"ࠩࠪ኶"),l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ኷"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧኸ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧኹ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࠧኺ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࠨࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ࠭ࠧኻ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࠪኼ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠩࠦࠫኽ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪኾ"),l1lllll_l1_+title,url,653,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ኿"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠭࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠪ࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩዀ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࠫ዁")+l1l11_l1_+l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬዂ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠧዃ")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨዄ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡔࡧࡤࡷࡴࡴࠧዅ")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ዆"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂࡁࡲࡩ࠿࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠦ዇"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪወ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ዉ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠰࠲ࠫዊ"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫዋ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬዌ"))
			title = title.replace(l1l111_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩው"),l1l111_l1_ (u"ࠬࠦࠧዎ"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬዏ"),l1lllll_l1_+title,l1ll1ll_l1_,652,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫዐ"),l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫዑ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ዒ"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫዓ"),l1l111_l1_ (u"ࠫࠬዔ"),l1l111_l1_ (u"ࠬ࠭ዕ"),l1l111_l1_ (u"࠭ࠧዖ"),l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ዗"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩዘ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨዙ"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫዚ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ዛ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧ࠱ࡺࡸ࡬࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭ዜ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨዝ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨዞ")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩዟ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨዠ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫዡ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬዢ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧዣ"),l1l111_l1_ (u"࠭ࠫࠨዤ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨዥ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨዦ"))
	return
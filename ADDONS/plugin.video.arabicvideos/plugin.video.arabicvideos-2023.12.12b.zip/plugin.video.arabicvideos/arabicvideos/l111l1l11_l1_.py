# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ᓨ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡁࡃࡆࡢࠫᓩ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᓪ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==550: l1lll_l1_ = l1l1l11_l1_()
	elif mode==551: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==552: l1lll_l1_ = PLAY(url)
	elif mode==553: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==559: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᓫ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᓬ"),l1l111_l1_ (u"ࠩࠪᓭ"),l1l111_l1_ (u"ࠪࠫᓮ"),l1l111_l1_ (u"ࠫࠬᓯ"),l1l111_l1_ (u"ࠬ࠭ᓰ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᓱ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᓲ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓳ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᓴ"),l1l111_l1_ (u"ࠪࠫᓵ"),559,l1l111_l1_ (u"ࠫࠬᓶ"),l1l111_l1_ (u"ࠬ࠭ᓷ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᓸ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᓹ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᓺ"),l1l111_l1_ (u"ࠩࠪᓻ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᓼ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิสา่สࠤ้้ࠧᓽ"),l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᓾ"),551,l1l111_l1_ (u"࠭ࠧᓿ"),l1l111_l1_ (u"ࠧࠨᔀ"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᔁ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔂ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᔃ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࡃ࡮ࡺࡥ࡮࠿ࠪᔄ")+l111l1l1l_l1_+l1l111_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭ᔅ")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔆ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔇ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻ࠳࡭ࡢ࡫ࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧࡶ࠿ࠩᔈ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᔉ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬᔊ"): continue
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫᔋ") in title: continue
		if l1l111_l1_ (u"ࠬษอะอࠪᔌ") in title: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔍ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔎ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᔏ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᔐ"),l1l111_l1_ (u"ࠪࠫᔑ"),9999)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭ᔒ"): continue
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"๋ࠬำๅี็ࠤࠬᔓ") in title: continue
		if l1l111_l1_ (u"࠭รฮัฮࠫᔔ") not in title: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᔕ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᔖ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪᔗ")):
	items = []
	if l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪᔘ") in url or l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᔙ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᔚ"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᔛ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬᔜ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩᔝ"),l1l111_l1_ (u"ࠩࠪᔞ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᔟ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᔠ"),url,l1l111_l1_ (u"ࠬ࠭ᔡ"),l1l111_l1_ (u"࠭ࠧᔢ"),l1l111_l1_ (u"ࠧࠨᔣ"),l1l111_l1_ (u"ࠨࠩᔤ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᔥ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᔦ"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᔧ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᔨ"),block,re.DOTALL)
		elif l1l111_l1_ (u"࠭ࠢࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡲࡲࡷࡹࠦ࡭ࡣ࠯࠴࠴ࠧ࠭ᔩ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩᔪ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭ᔫ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᔬ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᔭ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫᔮ"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪᔯ"),l1l111_l1_ (u"࠭ว฻่ํอࠬᔰ"),l1l111_l1_ (u"ࠧไๆํฬࠬᔱ"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧᔲ"),l1l111_l1_ (u"๊ࠩำฬ็ࠧᔳ"),l1l111_l1_ (u"้ࠪออัศหࠪᔴ"),l1l111_l1_ (u"ࠫ฾ืึࠨᔵ"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬᔶ"),l1l111_l1_ (u"࠭วๅส๋้ࠬᔷ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠧ࠰ࠩᔸ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫᔹ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠩึ่ฬูไࠨᔺ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᔻ"),l1lllll_l1_+title,l1ll1ll_l1_,552,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫᔼ") in title:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᔽ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔾ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᔿ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕀ"),l1lllll_l1_+title,l1ll1ll_l1_,551,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕁ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠪࠫᕂ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲࠨᕃ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᕄ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠢᕅ"): continue
				if title!=l1l111_l1_ (u"ࠧࠨᕆ"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕇ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨᕈ")+title,l1ll1ll_l1_,551)
	if l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪᕉ") in url or l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᕊ") in url:
		if l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬᕋ") in url:
			url = url.replace(l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ᕌ"),l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨᕍ"))+l1l111_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿࠵࠴ࠬᕎ")
		elif l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪᕏ") in url:
			url,offset = url.split(l1l111_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬᕐ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠭ᕑ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕒ"),l1lllll_l1_+l1l111_l1_ (u"࠭็็ษๆࠤฬ๊ๅำ์าࠫᕓ"),url,551)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᕔ"),url,l1l111_l1_ (u"ࠨࠩᕕ"),l1l111_l1_ (u"ࠩࠪᕖ"),l1l111_l1_ (u"ࠪࠫᕗ"),l1l111_l1_ (u"ࠫࠬᕘ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᕙ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࡆࡾ࡙ࡥࡳ࡫ࡨࡷ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧᕚ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᕛ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪᕜ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕝ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕞ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡭ࡢࡩࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᕟ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᕠ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᕡ"),l1lllll_l1_+title,l1ll1ll_l1_,552,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᕢ"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᕣ"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ᕤ"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ᕥ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᕦ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ᕧ"),l1l111_l1_ (u"࠭ࠧᕨ"),l1l111_l1_ (u"ࠧࠨᕩ"),l1l111_l1_ (u"ࠨࠩᕪ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᕫ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧᕬ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᕭ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕮ"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨᕯ"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪᕰ"),l1l111_l1_ (u"ࠨࠩᕱ")).strip(l1l111_l1_ (u"ࠩࠣࠫᕲ"))
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭ᕳ")+server+l1l111_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭ᕴ")+l11l1l11_l1_+l1l111_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭ᕵ")
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᕶ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᕷ")
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠣࡩࡨࡸࡕࡲࡡࡺࡧࡵࡆࡾࡔࡡ࡮ࡧ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࡞ࠥࡷࡪࡸࡶࡦࡴ࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣᕸ"),block,re.DOTALL)
			for server,l111l11ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬᕹ"),l1l111_l1_ (u"ࠪࠫᕺ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᕻ"))
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸࡂࡺࡐࡤࡱࡪࡅࡳࡦࡴࡹࡩࡷࡃࠧᕼ")+server+l1l111_l1_ (u"࠭ࠦ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦࡕࡨࡶࡻ࡫ࡲࡴ࠿ࠪᕽ")+l111l11ll_l1_+l1l111_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩᕾ")+l11l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩᕿ")
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᖀ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᖁ")
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᖂ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᖃ"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᖄ")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᖅ")
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᖆ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᖇ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᖈ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬᖉ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭ᖊ"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨᖋ"),l1l111_l1_ (u"ࠧ࠮ࠩᖌ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪᖍ")+search+l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨᖎ")
	l1lll11_l1_(url)
	return
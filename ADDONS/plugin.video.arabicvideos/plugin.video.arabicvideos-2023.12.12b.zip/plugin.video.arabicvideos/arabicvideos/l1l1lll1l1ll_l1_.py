# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ䊁")
headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䊂") : l1l111_l1_ (u"ࠪࠫ䊃") }
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓࡖ࡛ࡡࠪ䊄")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1l1l1ll1111_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l1ll1111_l1_():
	message = l1l111_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠡ࠰࠱࠲ࠥ๎ศฮษฯอࠥอไ๊ࠢส฽ฬีษࠡสิ้ัฯࠠๆ่ࠣห้฻แาࠢ࠱࠲࠳่ࠦศๆ่ฬึ๋ฬࠡฯส่๏อࠠๆึ฽์้่๋ࠦ฻ส๊๏ࠦๅ็๋ࠢ฽่ฯࠠึฯํอࠥ࠴࠮࠯๋่ࠢ์ึวࠡี๋ๅࠥ๐ศใ๋ࠣห้๋่ใ฻้ࠣ฿๊โࠡษ็ํ๋ࠥวࠡึสลࠥอไๅ้ࠪ䊅")
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䊆"),l1l111_l1_ (u"ࠧࠨ䊇"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䊈"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊉"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䊊"),l1l111_l1_ (u"ࠫࠬ䊋"),189,l1l111_l1_ (u"ࠬ࠭䊌"),l1l111_l1_ (u"࠭ࠧ䊍"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䊎"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䊐")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࠫ䊑"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䊒"),l1l111_l1_ (u"ࠬ࠭䊓"),l1l111_l1_ (u"࠭ࡢࡰࡺ࠰ࡳ࡫࡬ࡩࡤࡧࠪ䊔"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊕"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䊖")+l1lllll_l1_+l1l111_l1_ (u"ࠩฦัิัࠠศๆสๅ้อๅࠨ䊗"),l111l1_l1_,181,l1l111_l1_ (u"ࠪࠫ䊘"),l1l111_l1_ (u"ࠫࠬ䊙"),l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䊚"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊛"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䊜")+l1lllll_l1_+l1l111_l1_ (u"ࠨฬ็๎ๆุ๊้่้ࠣํ็๊ำࠢ็ห๋ีࠧ䊝"),l111l1_l1_,181,l1l111_l1_ (u"ࠩࠪ䊞"),l1l111_l1_ (u"ࠪࠫ䊟"),l1l111_l1_ (u"ࠫࡹࡼࠧ䊠"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊡"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䊢")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆส็ะืࠠๆึส๋ิฯࠧ䊣"),l111l1_l1_,181,l1l111_l1_ (u"ࠨࠩ䊤"),l1l111_l1_ (u"ࠩࠪ䊥"),l1l111_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䊦"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊧"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䊨")+l1lllll_l1_+l1l111_l1_ (u"࠭รใ๊์ࠤฬ๊วโๆส้ࠥอไฮษ็๎ฮ࠭䊩"),l111l1_l1_,181,l1l111_l1_ (u"ࠧࠨ䊪"),l1l111_l1_ (u"ࠨࠩ䊫"),l1l111_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䊬"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠪࠫ䊭"),headers,l1l111_l1_ (u"ࠫࠬ䊮"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䊯"))
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡩ࠴ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䊰"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊱"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䊲")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ䊳")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ䊴"),headers,l1l111_l1_ (u"ࠫࠬ䊵"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䊶"))
	if type==l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䊷"): block = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾ฤฯาฯࠥอไฤใ็ห๊ࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࡫࠵ࠬ䊸"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠨࡤࡲࡼ࠲ࡵࡦࡧ࡫ࡦࡩࠬ䊹"): block = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀห์ู่ࠠศ๊ไ๎ุࠦๅ้ใํึ๊ࠥว็ั࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࡨ࠲ࠩ䊺"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䊻"): block = re.findall(l1l111_l1_ (u"ࠫࡧࡺ࡮࠮࠴࠰ࡳࡻ࡫ࡲ࡭ࡣࡼࠬ࠳࠰࠿ࠪ࠾ࡶࡸࡾࡲࡥ࠿ࠩ䊼"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䊽"): block = re.findall(l1l111_l1_ (u"࠭ࡢࡵࡰ࠰࠵ࠥࡨࡴ࡯࠯ࡤࡦࡸࡵ࡬ࡺࠪ࠱࠮ࡄ࠯ࡢࡵࡰ࠰࠶ࠥࡨࡴ࡯࠯ࡤࡦࡸࡵ࡬ࡺࠩ䊾"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠧࡵࡸࠪ䊿"): block = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ฬ็๎ๆุ๊้่้ࠣํ็๊ำࠢ็ห๋ี࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡨࠤࠪ䋀"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䋁"),l1l111_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䋂")]:
		items = re.findall(l1l111_l1_ (u"ࠫࡸࡺࡹ࡭ࡧࡀࠦࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨ࡯ࡵࡶࡲࡱ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䋃"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࡂࠨ࠳࡜࠲࠰࠽ࡢ࠱ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡸࡹࡵ࡭࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䋄"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"࠭แ๋ๆ่ࠫ䋅"),l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ䋆"),l1l111_l1_ (u"ࠨษ็ั้่็ࠨ䋇"),l1l111_l1_ (u"ࠩ฼ี฻࠭䋈"),l1l111_l1_ (u"ࠪࡖࡦࡽࠧ䋉"),l1l111_l1_ (u"ࠫࡘࡳࡡࡤ࡭ࡇࡳࡼࡴࠧ䋊"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ䋋"),l1l111_l1_ (u"࠭วอิสลࠬ䋌")]
	for l1ll1l_l1_,l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_ in items:
		if type in [l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䋍"),l1l111_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䋎")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩࡂࡺ࡮࡫ࡷ࠾ࡶࡵࡹࡪ࠭䋏"),l1l111_l1_ (u"ࠪࠫ䋐"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䋑") in title or l1l111_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䋒") in title:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䋓") + title.replace(l1l111_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䋔"),l1l111_l1_ (u"ࠨࠩ䋕")).replace(l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䋖"),l1l111_l1_ (u"ࠪࠫ䋗"))
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭䋘"))
		if l1l111_l1_ (u"ࠬอไฮๆๅอࠬ䋙") in title or l1l111_l1_ (u"࠭วๅฯ็ๆ์࠭䋚") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼศๆะ่็ํࠩࠡ࡞ࡧ࠯ࠬ䋛"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䋜") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋝"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭䋞") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䋟"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ䋠") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋡"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠧࠨ䋢"):
		items = re.findall(l1l111_l1_ (u"ࠨ࡞ࡱࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䋣"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠩสฺ่็อสࠢࠪ䋤"),l1l111_l1_ (u"ࠪࠫ䋥"))
			if title!=l1l111_l1_ (u"ࠫࠬ䋦"):
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䋧"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ䋨")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䋩"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䋪"),headers,l1l111_l1_ (u"ࠩࠪ䋫"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䋬"))
	block = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹ࡯ࡴ࡭ࡧࡁ࠲࠯ࡅࡨࡦ࡫ࡪ࡬ࡹࡃࠢࠩ࡝࠳࠱࠾ࡣࠫࠪࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䋭"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁอไฮๆๅ๋࠮࡛ࠦ࠱࠯࠼ࡡ࠰࠭䋮"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䋯") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡲ࡬ࡷࡴࡪࡥࡴࡐࡸࡱࡧ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䋰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䋱"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"ࠩࠫห้ำไใหࡿห้ำไใ้ࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭䋲"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ䋳"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠫ࠭࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ䋴"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ䋵"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"࠭ࠠࠨ䋶") + title[0][1]
			else: title = l1l111_l1_ (u"ࠧࠨ䋷")
			title = name + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䋸") + l1l111_l1_ (u"ࠩส่า๊โสࠩ䋹") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䋺"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䋻") in title or l1l111_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䋼") in title:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䋽") + title.replace(l1l111_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䋾"),l1l111_l1_ (u"ࠨࠩ䋿")).replace(l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䌀"),l1l111_l1_ (u"ࠪࠫ䌁"))
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䌂"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1l1l1ll11_l1_ = url.split(l1l111_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ䌃"))
	l1lllll1_l1_ = l1l1l1l1ll11_l1_[0]
	del l1l1l1l1ll11_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䌄"),headers,l1l111_l1_ (u"ࠧࠨ䌅"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䌆"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡩࡳࡳࡺ࠭ࡴ࡫ࡽࡩ࠿ࠦ࠲࠶ࡲࡻ࠿ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䌇"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1l1l1ll11_l1_: l1l1l1l1ll11_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1l1l1ll11_l1_:
		if l1l111_l1_ (u"ࠪ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ䌈") in l1ll1ll_l1_:
			l1l1l1l11lll_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1l1l11lll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡒࡧࡩ࡯ࠩ䌉"))
	for l1ll1ll_l1_ in l1l1l1l1ll11_l1_:
		if l1l111_l1_ (u"ࠬࡀ࠯࠰ࡸࡥ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠨ䌊") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䌋"),headers,l1l111_l1_ (u"ࠧࠨ䌌"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭䌍"))
			html = html.decode(l1l111_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨ䌎")).encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䌏"))
			html = html.replace(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌐"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌑"))
			html = html.replace(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䌒"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌓"))
			html = html.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࡁࡨࡲࠡ࠱ࡁࡀࡩ࡯ࡶࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࡀࠪ䌔"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䌕"))
			html = html.replace(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡧࡵࡲࡥࡧࡵࠦࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧ࠭䌖"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䌗"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䌘"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1l1l1l111_l1_,l1l1l1l1lll1_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"࠭ࠧ䌙")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲࠭ࡵ࡮࡭࡫ࡱࡩࢁࡩ࡯࡮ࠫ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠳࠰࠿࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪࠬࠪ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䌚"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࠪ䌛") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿࠽ࡪࡵࠤࡸ࡯ࡺࡦ࠿ࠥ࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿࠭䌜")+l1l111_l1_ (u"ࠪࠧࠬ䌝")+l1l111_l1_ (u"ࠫ࠸࠹࠳࠼ࠢࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡣࡰ࡮ࡲࡶ࠿࠭䌞")+l1l111_l1_ (u"ࠬࠩࠧ䌟")+l1l111_l1_ (u"࠭࠳࠴࠵ࠥࠤ࠴ࡄࠨ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䌠"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ䌡") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃ࠮ࡂࡨࡳࠢࡶ࡭ࡿ࡫࠽ࠣ࠳ࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࠫ䌢")+l1l111_l1_ (u"ࠩࠦࠫ䌣")+l1l111_l1_ (u"ࠪ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠬ䌤")+l1l111_l1_ (u"ࠫࠨ࠭䌥")+l1l111_l1_ (u"ࠬ࠹࠳࠴ࠤࠣ࠳ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌦"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"࠭ࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌧")
						l1l1l1l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࠪ࠱࠮ࡄ࠯ࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠮࡯࡯࡮࡬ࡲࡪࢂࡣࡰ࡯ࠬ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠭䌨"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠨࡀࠣ࠮࠭ࡡ࡞࠽ࡀࡠ࠯࠮ࠦࠪ࠽ࠩ䌩"),l1l1l1l1llll_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"ࠩࠣࠫ䌪").join(title)
						title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ䌫"))
						title = title.replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䌬"),l1l111_l1_ (u"ࠬࠦࠧ䌭")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䌮"),l1l111_l1_ (u"ࠧࠡࠩ䌯")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䌰"),l1l111_l1_ (u"ࠩࠣࠫ䌱")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䌲"),l1l111_l1_ (u"ࠫࠥ࠭䌳")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䌴"),l1l111_l1_ (u"࠭ࠠࠨ䌵"))
						l1l1l1l1l111_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧฤะอีࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮ࠺ࠨ䌶"), l1l1l1l1l111_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1l1l1l111_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠬࠦࠬ䌷"),block,re.DOTALL)
				l1l1l1l11ll1_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡉࡳࡷࡻ࡭ࠨ䌸"))
				block = block.replace(l1l111_l1_ (u"ࠪไࠬ䌹"),l1l111_l1_ (u"ࠫࠬ䌺"))
				block = block.replace(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ䌻"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡧࡵࡴࡩࠤࠣࠤࡡࡴࠠࠡࠩ䌼"))
				block = block.replace(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡨࡵ࡭࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠹࠶࠽࠴࠲࠴࠴࠻࠺࠸࠹࠷࠰ࡳࡲ࡬ࠨࠧ䌽"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䌾"))
				block = block.replace(l1l111_l1_ (u"ࠩึ๎ึ็ัศฬࠣห้ะอๆ์็ࠫ䌿"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠤࠥࡢ࡮ࠡࠢࠪ䍀"))
				block = block.replace(l1l111_l1_ (u"ࠫึ๎วษูࠣห้ะอๆ์็ࠫ䍁"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ䍂"))
				block = block.replace(l1l111_l1_ (u"࠭ำ๋ำไีฬะࠠศๆุ่ฬํฯࠨ䍃"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡽࡡࡵࡥ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䍄"))
				block = block.replace(l1l111_l1_ (u"ࠨำ๋หอ฽ࠠศๆุ่ฬํฯࠨ䍅"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䍆"))
				l1l1l1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴ࡢࡤࠬࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䍇"),block,re.DOTALL)
				for l1l1l1l1ll1l_l1_ in l1l1l1l1l1l1_l1_:
					type = re.findall(l1l111_l1_ (u"ࠫࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࠩ䍈"),l1l1l1l1ll1l_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠬࡨ࡯ࡵࡪࠪ䍉"): type = l1l111_l1_ (u"࠭࡟ࡠࠩ䍊")+type[0]
						else: type = l1l111_l1_ (u"ࠧࠨ䍋")
					items = re.findall(l1l111_l1_ (u"ࠨࠪࡂࡀࠦ࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱ࠬࠬࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰࠼࠰ࡨࡲࡲࡹࡄ࠮ࠫࡁࡿࡠࡼ࠱࡛ࠡ࡞ࡺࡡ࠯ࡂࡢࡳࠢ࠲ࡂ࠳࠰࠿ࠪࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴࠴ࠪࡀࠫࠥࠫ䍌"),l1l1l1l1ll1l_l1_,re.DOTALL)
					for l1l1l1l1l1ll_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"ࠩࠫࡠࡼ࠱࡛ࠡ࡞ࡺࡡ࠯࠯࠼ࠨ䍍"),l1l1l1l1l1ll_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䍎") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1ll1l_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠫࠬ䍏"),headers,l1l111_l1_ (u"ࠬ࠭䍐"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䍑"))
	items = re.findall(l1l111_l1_ (u"ࠧࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䍒"),html,re.DOTALL)
	if items:
		l1l1l1ll11ll_l1_ = items[-1]
		l1llll_l1_.append(l1l1l1ll11ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡲࡦ࡮ࡲࡥࠨ䍓"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䍔"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ䍕"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ䍖"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ䍗"),l1l111_l1_ (u"࠭ࠫࠨ䍘"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䍙"),headers,l1l111_l1_ (u"ࠨࠩ䍚"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䍛"))
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࡂࠬ䍜"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠫࠬ䍝") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠬอไไๆࠣ์อี่็ࠢไ่ฯืࠧ䍞") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭䍟"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠧࠨ䍠")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭䍡")+search+l1l111_l1_ (u"ࠩࠩࡱࡨࡧࡴ࠾ࠩ䍢")+category
	l1lll11_l1_(url)
	return
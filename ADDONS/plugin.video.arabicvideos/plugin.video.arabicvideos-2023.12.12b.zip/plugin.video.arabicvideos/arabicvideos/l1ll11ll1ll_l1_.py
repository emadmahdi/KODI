# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ〕")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡑࡔࡌࡡࠪ〖")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ〗"),l1l111_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ〘"),l1l111_l1_ (u"ࠧศๆฦๆุอๅࠨ〙")]
def l11l1ll_l1_(mode,url,text):
	if   mode==670: l1lll_l1_ = l1l1l11_l1_()
	elif mode==671: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==672: l1lll_l1_ = PLAY(url)
	elif mode==673: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==674: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==679: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ〚"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ〛"),l1l111_l1_ (u"ࠪࠫ〜"),l1l111_l1_ (u"ࠫࠬ〝"),l1l111_l1_ (u"ࠬ࠭〞"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ〟"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ〠"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ〡"),l1l111_l1_ (u"ࠩࠪ〢"),679,l1l111_l1_ (u"ࠪࠫ〣"),l1l111_l1_ (u"ࠫࠬ〤"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ〥"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ〦"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〧"),l1l111_l1_ (u"ࠨࠩ〨"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ〩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ〪ࠬ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			if title==l1l111_l1_ (u"ࠫฬ๊รใีส้〫ࠬ"): mode = 675
			else: mode = 674
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ〬"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ〭")+l1lllll_l1_+title,l1ll1ll_l1_,mode)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯〮ࠬ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ〯"),l1l111_l1_ (u"ࠩࠪ〰"),9999)
	items = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࡦࡷࡵࡷࡴࡧ࠱࡬ࡹࡳ࡬ࠨ〱"))
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ〲"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ〳")+l1lllll_l1_+title,l1ll1ll_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l1llllllll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ〴"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ〵"),l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ〶"))
	if l1llllllll_l1_: return l1llllllll_l1_
	l1llllllll_l1_ = []
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭〷"),url,l1l111_l1_ (u"ࠪࠫ〸"),l1l111_l1_ (u"ࠫࠬ〹"),l1l111_l1_ (u"ࠬ࠭〺"),l1l111_l1_ (u"࠭ࠧ〻"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪ〼"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱࡭࡫ࡡࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࡁࠫ〽"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llllllll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭〾"),block,re.DOTALL)
		if l1llllllll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ〿"),l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ぀"),l1llllllll_l1_,l1ll1ll1_l1_)
	return l1llllllll_l1_
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩぁ"),url,l1l111_l1_ (u"࠭ࠧあ"),l1l111_l1_ (u"ࠧࠨぃ"),l1l111_l1_ (u"ࠨࠩい"),l1l111_l1_ (u"ࠩࠪぅ"),l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪう"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨぇ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭え"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬぉ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫお"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩか"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧが"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨき"),l1l111_l1_ (u"ࠫࠬぎ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪく"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩぐ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧけ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬげ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫこ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨご"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫさ"),l1l111_l1_ (u"ࠬ࠭ざ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭し"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨじ")):
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭す"):
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࠫず"),1)
		data = l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩせ")+search
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪぜ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬそ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫぞ"),url,data,headers,l1l111_l1_ (u"ࠧࠨた"),l1l111_l1_ (u"ࠨࠩだ"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨち"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧぢ"),url,l1l111_l1_ (u"ࠫࠬっ"),l1l111_l1_ (u"ࠬ࠭つ"),l1l111_l1_ (u"࠭ࠧづ"),l1l111_l1_ (u"ࠧࠨて"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧで"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠩࠪと"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧど"))
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩな"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧに"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"࠭ࠧぬ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩね"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩの"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨは"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪば"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨぱ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬひ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨび"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩぴ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪふ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠩࠪぶ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫぷ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬへ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬべ"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫぺ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭ほ"),l1l111_l1_ (u"ࠨๅ็๎อ࠭ぼ"),l1l111_l1_ (u"ࠩส฽้อๆࠨぽ"),l1l111_l1_ (u"๋ࠪิอแࠨま"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫみ"),l1l111_l1_ (u"ࠬ฿ัืࠩむ"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭め"),l1l111_l1_ (u"ࠧศๆห์๊࠭も"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨゃ"),l1l111_l1_ (u"ࠩไ่๊࠭や")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭ゅ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪゆ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫょ"):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬよ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ら") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨり"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧる") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪれ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫろ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ゎ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫわ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩゐ"): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ゑ") not in l1ll1ll_l1_:
				l1lllll1_l1_ = url.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫを"),1)[0]
				l1ll1ll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬん")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ゔ"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬゕ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬゖ")+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠧࠨ゗"),l1l111_l1_ (u"ࠨࠩ゘"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ゙"),l1lllll_l1_+l1l111_l1_ (u"ࠪฮูเ๊ๅࠢส่ๆ๐ฯ゚๋๊ࠪ"),url,672)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ゛"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ゜"),l1l111_l1_ (u"࠭ࠧゝ"),9999)
	l1llllllll_l1_ = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡣࡴࡲࡻࡸ࡫࠮ࡩࡶࡰࡰࠬゞ"))
	l1ll11ll111_l1_,l1ll11ll1l1_l1_,l1ll11ll11l_l1_ = zip(*l1llllllll_l1_)
	l1ll11lll11_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬゟ"),url,l1l111_l1_ (u"ࠩࠪ゠"),l1l111_l1_ (u"ࠪࠫァ"),l1l111_l1_ (u"ࠫࠬア"),l1l111_l1_ (u"ࠬ࠭ィ"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧイ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠫゥ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡼࡆࡺࡺࡴࡰࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾ࠪウ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1ll11ll111_l1_:
				item = (l1ll1ll_l1_,title)
				l1ll11lll11_l1_.append(item)
		if len(l1ll11lll11_l1_)==1:
			l1ll1ll_l1_,title = l1ll11lll11_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨェ"))
			return
		else:
			for l1ll1ll_l1_,title in l1ll11lll11_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪエ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠫࠬォ"),l1l111_l1_ (u"ࠬ࠭オ"),l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬカ"))
	if not l1ll11lll11_l1_: l1lll11_l1_(url,l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ガ"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬキ"),url,l1l111_l1_ (u"ࠩࠪギ"),l1l111_l1_ (u"ࠪࠫク"),l1l111_l1_ (u"ࠫࠬグ"),l1l111_l1_ (u"ࠬ࠭ケ"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪゲ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡦ࡭ࡣࡶ࡬ࡵࡲࡡࡺࡧࡵࠫコ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫゴ"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࡢࡣࠬサ")+l111l1ll_l1_
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡧࡩࡩ࠳ࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ザ"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠦ࡫࡯࡬ࡦ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦシ"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪジ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬス")+l1ll1ll_l1_
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨズ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧセ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪゼ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫソ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ゾ"),l1l111_l1_ (u"ࠬ࠱ࠧタ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ダ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧチ"))
	return
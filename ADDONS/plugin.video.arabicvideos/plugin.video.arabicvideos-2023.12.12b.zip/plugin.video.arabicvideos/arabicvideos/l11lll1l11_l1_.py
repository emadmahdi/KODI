# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊ᳗ࠧ")
def l11l1ll_l1_(mode,url):
	if   mode==330: l1lll_l1_ = l1l11l1l11_l1_()
	elif mode==331: l1lll_l1_ = PLAY(url)
	elif mode==332: l1lll_l1_ = l11llllll1_l1_()
	elif mode==333: l1lll_l1_ = l11ll1ll11_l1_()
	elif mode==334: l1lll_l1_ = l1llll1111_l1_(url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1llll1111_l1_(l1l1111l1l_l1_):
	try: os.remove(l1l1111l1l_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻᳘ࠫ")))
	except: os.remove(l1l1111l1l_l1_)
	return
def PLAY(url):
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ᳙࠭"))
	return
def l11ll1ll11_l1_():
	message = l1l111_l1_ (u"ࠨลำ๋อࠦลๅ๋ࠣีฬฮืࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไึ๊อࠤๆ๐ࠠศๆ่์็฿ࠠศๆ่฻้๎ศࠡอ่ࠤศ฼ฺุࠢ฼่๎ࠦาาࠢส่็อฦๆหࠣห้๐ๅ๋่ࠣฯ๊ࠦรฯฬสีࠥࠨสฮ็ํ่๋ࠥไโษอࠤๆ๐ฯ๋๊ࠥࠤะ๋ࠠศะอหึࠦฯใหࠣห้฻่าหࠣ์ฬิสศำ๊ࠣํ฿ࠠๆๆไࠤฬ๊ี้ำฬࠤํฮูะ้สࠤุ๎แࠡ์หำศࠦวๅฬะ้๏๊ࠧ᳚")
	l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ᳛"),l1l111_l1_ (u"᳜ࠪࠫ"),l1l111_l1_ (u"ࠫ฼ื๊ใหࠣฮา๋๊ๅࠢส่๊๊แศฬ᳝ࠪ"),message)
	return
def l1l11l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭᳞ࠪ"),l1l111_l1_ (u"࠭ืา์ๅอࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋᳟ࠫ"),l1l111_l1_ (u"ࠧࠨ᳠"),333)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᳡"),l1l111_l1_ (u"ࠩอ฾๏๐ัࠡ็ๆห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวห᳢ࠩ"),l1l111_l1_ (u"᳣ࠪࠫ"),332)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬᳤ࠩ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡ᳥ࠬ"),l1l111_l1_ (u"᳦࠭ࠧ"),9999)
	l1l111l1l1_l1_ = l11llll1l1_l1_()
	mtime = os.stat(l1l111l1l1_l1_).st_mtime
	l1l1111111_l1_ = []
	if kodi_version>18.99: l1l111l11l_l1_ = os.listdir(l1l111l1l1_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼᳧ࠬ")))
	else: l1l111l11l_l1_ = os.listdir(l1l111l1l1_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽᳨࠭")))
	for filename in l1l111l11l_l1_:
		if kodi_version>18.99: filename = filename.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᳩ"))
		if not filename.startswith(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩᳪ")): continue
		filepath = os.path.join(l1l111l1l1_l1_,filename)
		mtime = os.path.getmtime(filepath)
		l1l1111111_l1_.append([filename,mtime])
	l1l1111111_l1_ = sorted(l1l1111111_l1_,reverse=True,key=lambda key: key[1])
	for filename,mtime in l1l1111111_l1_:
		if kodi_version<19:
			try: filename = filename.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᳫ"))
			except: pass
			filename = filename.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᳬ"))
		filepath = os.path.join(l1l111l1l1_l1_,filename)
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳ᳭ࠬ"),filename,filepath,331)
	return
def l11llll1l1_l1_():
	l1l111l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪᳮ"))
	if l1l111l1l1_l1_: return l1l111l1l1_l1_
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫᳯ"),addoncachefolder)
	return addoncachefolder
def l11llllll1_l1_():
	l1l111l1l1_l1_ = l11llll1l1_l1_()
	l11lll11ll_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩᳰ"),l1l111_l1_ (u"ࠪࠫᳱ"),l1l111_l1_ (u"ࠫࠬᳲ"),l1l111_l1_ (u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩᳳ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ᳴")+l1l111l1l1_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳํะศ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠศๆ่็ฬ์ࠠภࠩᳵ"))
	if l11lll11ll_l1_==1:
		newpath = l1l11111l1_l1_(3,l1l111_l1_ (u"ࠨ็ๆห๋ࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬᳶ"),l1l111_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࠨ᳷"),l1l111_l1_ (u"ࠪࠫ᳸"),False,True,l1l111l1l1_l1_)
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ᳹"),l1l111_l1_ (u"ࠬ࠭ᳺ"),l1l111_l1_ (u"࠭ࠧ᳻"),l1l111_l1_ (u"ࠧๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠫ᳼"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ᳽")+l1l111l1l1_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮่าสࠤ์๎ࠠศๆ่็ฬ์ࠠศๆฯำ๏ีࠠๅฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋็ࠡสา่ฬࠦๅ็ࠢส่๊้ว็ࠢส่็ี๊ๆࠢยࠫ᳾"))
		if l1llll1l11_l1_==1:
			settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭᳿"),newpath)
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬᴀ"),l1l111_l1_ (u"ࠬ࠭ᴁ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᴂ"),l1l111_l1_ (u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨᴃ"))
	return
def l11lllllll_l1_(filename):
	l1l11l11ll_l1_ = l1l111_l1_ (u"ࠨࠩᴄ").join(l1l11l111l_l1_ for l1l11l111l_l1_ in filename if l1l11l111l_l1_ not in l1l111_l1_ (u"ࠩ࡟࠳ࠧࡀࠪࡀ࠾ࡁࢀࠬᴅ")+half_triangular_colon)
	return l1l11l11ll_l1_
def l11lll111l_l1_(url,l11ll1l11l_l1_=l1l111_l1_ (u"ࠪࠫᴆ"),l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬᴇ")):
	l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᴈ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᴉ")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪᴊ"))
	if not l11ll1l11l_l1_: l11ll1l11l_l1_ = l1l111ll1l_l1_(url,l1l11l11_l1_)
	l1l111l1l1_l1_ = l11llll1l1_l1_()
	l1l111lll1_l1_ = l1l1111lll_l1_()
	filename = l1l111lll1_l1_.replace(l1l111_l1_ (u"ࠨࠢࠪᴋ"),l1l111_l1_ (u"ࠩࡢࠫᴌ"))
	filename = l11lllllll_l1_(filename)
	filename = l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩᴍ")+str(int(now))[-4:]+l1l111_l1_ (u"ࠫࡤ࠭ᴎ")+filename+l11ll1l11l_l1_
	l11ll1ll1l_l1_ = os.path.join(l1l111l1l1_l1_,filename)
	headers = {}
	headers[l1l111_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧᴏ")] = l1l111_l1_ (u"࠭ࠧᴐ")
	headers[l1l111_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧᴑ")] = l1l111_l1_ (u"ࠨࠬ࠲࠮ࠬᴒ")
	url = url.replace(l1l111_l1_ (u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬᴓ"),l1l111_l1_ (u"ࠪࠫᴔ"))
	if l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩᴕ") in url:
		l1lllll1_l1_,l11ll1l1l1_l1_ = url.rsplit(l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᴖ"),1)
		l11ll1l1l1_l1_ = l11ll1l1l1_l1_.replace(l1l111_l1_ (u"࠭ࡼࠨᴗ"),l1l111_l1_ (u"ࠧࠨᴘ")).replace(l1l111_l1_ (u"ࠨࠨࠪᴙ"),l1l111_l1_ (u"ࠩࠪᴚ"))
	else: l1lllll1_l1_,l11ll1l1l1_l1_ = url,None
	if not l11ll1l1l1_l1_: l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	if l11ll1l1l1_l1_: headers[l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᴛ")] = l11ll1l1l1_l1_
	if l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᴜ") in l1lllll1_l1_: l1lllll1_l1_,l11lll1ll1_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧᴝ"),1)
	else: l1lllll1_l1_,l11lll1ll1_l1_ = l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧᴞ")
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠧࡽࠩᴟ")).strip(l1l111_l1_ (u"ࠨࠨࠪᴠ")).strip(l1l111_l1_ (u"ࠩࡿࠫᴡ")).strip(l1l111_l1_ (u"ࠪࠪࠬᴢ"))
	l11lll1ll1_l1_ = l11lll1ll1_l1_.replace(l1l111_l1_ (u"ࠫࢁ࠭ᴣ"),l1l111_l1_ (u"ࠬ࠭ᴤ")).replace(l1l111_l1_ (u"࠭ࠦࠨᴥ"),l1l111_l1_ (u"ࠧࠨᴦ"))
	if l11lll1ll1_l1_:	headers[l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᴧ")] = l11lll1ll1_l1_
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᴨ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᴩ")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᴪ")+str(headers)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᴫ")+l11ll1ll1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᴬ"))
	l1l11l1l1l_l1_ = 1024*1024
	l1l111ll11_l1_ = 0
	try:
		l1l111l1ll_l1_ =	xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪᴭ"))
		l1l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧ࠯ࠬᴮ"),l1l111l1ll_l1_)
		l1l111ll11_l1_ = int(l1l111l1ll_l1_[0])
	except: pass
	if not l1l111ll11_l1_:
		try:
			l1l1111ll1_l1_ = os.l11ll1l111_l1_(l1l111l1l1_l1_)
			l1l111ll11_l1_ = l1l1111ll1_l1_.f_frsize*l1l1111ll1_l1_.f_bavail//l1l11l1l1l_l1_
		except: pass
	if not l1l111ll11_l1_:
		try:
			l1l1111ll1_l1_ = os.l1l11l11l1_l1_(l1l111l1l1_l1_)
			l1l111ll11_l1_ = l1l1111ll1_l1_.f_frsize*l1l1111ll1_l1_.f_bavail//l1l11l1l1l_l1_
		except: pass
	if not l1l111ll11_l1_:
		try:
			import shutil
			total,l11lllll1l_l1_,l11llll11l_l1_ = shutil.l1l11l1lll_l1_(l1l111l1l1_l1_)
			l1l111ll11_l1_ = l11llll11l_l1_//l1l11l1l1l_l1_
		except: pass
	if not l1l111ll11_l1_:
		l1l11ll111_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨᴯ"),l1l111_l1_ (u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪᴰ"),l1l111_l1_ (u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨᴱ"),l1l111_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᴲ"))
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫᴳ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡙ࠧࠡࠢࠣࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡷ࡬ࡪࠦࡤࡪࡵ࡮ࠤ࡫ࡸࡥࡦࠢࡶࡴࡦࡩࡥࠨᴴ"))
		return False
	import requests
	if l11ll1l11l_l1_==l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧᴵ"):
		l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1_l1_(l1lllll1_l1_,headers)
		if len(l1l1lll1_l1_)==0:
			l1ll1lll_l1_(l1l111_l1_ (u"ࠩไุ้ࠦแ๋ࠢศ๎ัอฯࠡ็็ๅࠥอไหฯ่๎้࠭ᴶ"),l1l111_l1_ (u"ࠪࠫᴷ"))
			return False
		elif len(l1l1lll1_l1_)==1: l11l11l_l1_ = 0
		elif len(l1l1lll1_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษࠩᴸ"), l1l1lll1_l1_)
			if l11l11l_l1_ == -1 :
				l1ll1lll_l1_(l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอั๊๐ไࠨᴹ"),l1l111_l1_ (u"࠭ࠧᴺ"))
				return False
		l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	filesize = 0
	if l11ll1l11l_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ᴻ"):
		l11ll1ll1l_l1_ = l11ll1ll1l_l1_.rsplit(l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧᴼ"))[0]+l1l111_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧᴽ")
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᴾ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬᴿ"),headers,l1l111_l1_ (u"ࠬ࠭ᵀ"),l1l111_l1_ (u"࠭ࠧᵁ"),l1l111_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧᵂ"))
		l11llll1ll_l1_ = response.content
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩᵃ"),l11llll1ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡸࠧᵄ"),re.DOTALL)
		if not l1ll_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨᵅ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᵆ")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨᵇ"))
			return False
		l1ll1ll_l1_ = l1ll_l1_[0]
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᵈ")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧ࠰࠱ࠪᵉ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨ࠼ࠪᵊ"),1)[0]+l1l111_l1_ (u"ࠩ࠽ࠫᵋ")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࠳ࠬᵌ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᵍ"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧᵎ"),1)[0]+l1l111_l1_ (u"࠭࠯ࠨᵏ")+l1ll1ll_l1_
		response = requests.request(l1l111_l1_ (u"ࠧࡈࡇࡗࠫᵐ"),l1ll1ll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11llll111_l1_ = len(l1ll_l1_)
		filesize = chunksize*l11llll111_l1_
	else:
		chunksize = 1*l1l11l1l1l_l1_
		response = requests.request(l1l111_l1_ (u"ࠨࡉࡈࡘࠬᵑ"),l1lllll1_l1_,headers=headers,verify=False,stream=True)
		if l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪᵒ") in response.headers: filesize = int(response.headers[l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫᵓ")])
		l11llll111_l1_ = int(filesize//chunksize)
	l1l111llll_l1_ = int(filesize//l1l11l1l1l_l1_)+1
	if filesize<21000:
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩᵔ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡶࡲࡳࠥࡹ࡭ࡢ࡮࡯ࠤࡴࡸࠠࡪࡶࠣ࡭ࡸࠦ࡭࠴ࡷ࠻ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᵕ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᵖ")+str(l1l111llll_l1_)+l1l111_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᵗ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫᵘ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬᵙ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫᵚ"),l1l111_l1_ (u"ࠫࠬᵛ"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᵜ"),l1l111_l1_ (u"࠭แีๆࠣๅ๏ࠦๅฺำไอࠥำฬๆ่่ࠢๆࠦวๅใํำ๏๎ࠠฤ๊ࠣห้๋ไโุࠢ฾๏ืࠠอัสࠤํ๊็ัษ่ࠣฬ๊ࠦๆๅ้ࠤ้๊ศา่ส้ัࠦสฮ็ํ่ࠥํะศࠢส่๊๊แࠨᵝ"))
		return False
	l11lll1l1l_l1_ = 400
	l11lll1111_l1_ = l1l111ll11_l1_-l1l111llll_l1_
	if l11lll1111_l1_<l11lll1l1l_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬᵞ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᵟ")+l1lllll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᵠ")+str(l1l111llll_l1_)+l1l111_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩᵡ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࠯ࠣࠫᵢ")+str(l11lll1l1l_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᵣ")+l11ll1ll1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᵤ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᵥ"),l1l111_l1_ (u"ࠨࠩᵦ"),l1l111_l1_ (u"ࠩ็หࠥ๐่อัุ้ࠣออสࠢๆหๆ๐ษࠡๆ็ฮา๋๊ๅࠩᵧ"),l1l111_l1_ (u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣัั๋็ࠡࠩᵨ")+str(l1l111llll_l1_)+l1l111_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢࠪᵩ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡ็่๊ำวโฺฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอี่็ุ่ࠢฬ้ไࠡ์ฯฬࠥหศใษฤࠤࠬᵪ")+str(l11lll1l1l_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢไหึเษࠡัสส๊อ้้ࠠำหู๋ࠥ็ษ๊ࠤศ์ࠠอ้สึ่ࠦไศࠢอ์ัีࠠโ์๊ࠤู๊วฮหࠣ็ฬ็๊สࠢ็ฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศࠨᵫ"))
		return False
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧᵬ"),l1l111_l1_ (u"ࠨࠩᵭ"),l1l111_l1_ (u"ࠩࠪᵮ"),l1l111_l1_ (u"๋้ࠪࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢยࠫᵯ"),l1l111_l1_ (u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤาาๅ่ࠢอๆึ๐ศศࠢࠪᵰ")+str(l1l111llll_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣฮ็ื๊ษษࠣࠫᵱ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋๋ࠢีอࠠศๆ่่ๆࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ้๊สฮ็ํ่๋ࠥๆࠡษ็ษ๋ะั็ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩᵲ"))
	if l1llll1l11_l1_!=1:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᵳ"),l1l111_l1_ (u"ࠨࠩᵴ"),l1l111_l1_ (u"ࠩࠪᵵ"),l1l111_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᵶ"))
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᵷ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡲࡦࡨࡸࡷࡪࡪࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡱࡩࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᵸ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᵹ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪᵺ"))
		return False
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᵻ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠧᵼ"))
	l1l111l111_l1_ = l1l11l1111_l1_()
	l1l111l111_l1_.create(l11ll1ll1l_l1_,l1l111_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫᵽ"))
	l11lll1lll_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l11ll1ll1l_l1_,l1l111_l1_ (u"ࠫࡼࡨࠧᵾ"))
	else: file = open(l11ll1ll1l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᵿ")),l1l111_l1_ (u"࠭ࡷࡣࠩᶀ"))
	if l11ll1l11l_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ᶁ"):
		for l1l11l111l_l1_ in range(1,l11llll111_l1_+1):
			l1ll1ll_l1_ = l1ll_l1_[l1l11l111l_l1_-1]
			if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᶂ")):
				if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠩ࠲࠳ࠬᶃ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠾ࠬᶄ"),1)[0]+l1l111_l1_ (u"ࠫ࠿࠭ᶅ")+l1ll1ll_l1_
				elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࠵ࠧᶆ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᶇ"))+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩᶈ"),1)[0]+l1l111_l1_ (u"ࠨ࠱ࠪᶉ")+l1ll1ll_l1_
			response = requests.request(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᶊ"),l1ll1ll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11ll1llll_l1_ = time.time()
			l11ll1l1ll_l1_ = l11ll1llll_l1_-t1
			l11ll1lll1_l1_ = l11ll1l1ll_l1_//l1l11l111l_l1_
			l1l11111ll_l1_ = l11ll1lll1_l1_*(l11llll111_l1_+1)
			l11lll11l1_l1_ = l1l11111ll_l1_-l11ll1l1ll_l1_
			l1l1111l11_l1_(l1l111l111_l1_,int(100*l1l11l111l_l1_//(l11llll111_l1_+1)),l1l111_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫᶋ"),l1l111_l1_ (u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫᶌ"),str(l1l11l111l_l1_*chunksize//l1l11l1l1l_l1_)+l1l111_l1_ (u"ࠬ࠵ࠧᶍ")+str(l1l111llll_l1_)+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫᶎ")+time.strftime(l1l111_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤᶏ"),time.gmtime(l11lll11l1_l1_))+l1l111_l1_ (u"ࠨࠢใࠫᶐ"))
			if l1l111l111_l1_.iscanceled():
				l11lll1lll_l1_ = False
				break
	else:
		l1l11l111l_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l1l11l111l_l1_ = l1l11l111l_l1_+1
			l11ll1llll_l1_ = time.time()
			l11ll1l1ll_l1_ = l11ll1llll_l1_-t1
			l11ll1lll1_l1_ = l11ll1l1ll_l1_/l1l11l111l_l1_
			l1l11111ll_l1_ = l11ll1lll1_l1_*(l11llll111_l1_+1)
			l11lll11l1_l1_ = l1l11111ll_l1_-l11ll1l1ll_l1_
			l1l1111l11_l1_(l1l111l111_l1_,int(100*l1l11l111l_l1_/(l11llll111_l1_+1)),l1l111_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᶑ"),l1l111_l1_ (u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪᶒ"),str(l1l11l111l_l1_*chunksize//l1l11l1l1l_l1_)+l1l111_l1_ (u"ࠫ࠴࠭ᶓ")+str(l1l111llll_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪᶔ")+time.strftime(l1l111_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᶕ"),time.gmtime(l11lll11l1_l1_))+l1l111_l1_ (u"ࠧࠡโࠪᶖ"))
			if l1l111l111_l1_.iscanceled():
				l11lll1lll_l1_ = False
				break
		response.close()
	file.close()
	l1l111l111_l1_.close()
	if not l11lll1lll_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᶗ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠴࡯࡮ࡵࡧࡵࡶࡺࡶࡴࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡶࡴࡩࡥࡴࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᶘ")+l1lllll1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᶙ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧᶚ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭ᶛ"),l1l111_l1_ (u"࠭ࠧᶜ"),l1l111_l1_ (u"ࠧࠨᶝ"),l1l111_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ᶞ"))
		return True
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᶟ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᶠ")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫᶡ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨᶢ"))
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧᶣ"),l1l111_l1_ (u"ࠧࠨᶤ"),l1l111_l1_ (u"ࠨࠩᶥ"),l1l111_l1_ (u"ࠩอ้ࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢห๊ัออࠨᶦ"))
	return True
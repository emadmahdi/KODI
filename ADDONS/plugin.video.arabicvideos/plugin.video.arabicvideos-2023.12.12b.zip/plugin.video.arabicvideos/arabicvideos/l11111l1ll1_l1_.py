# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ娪")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ娫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬฮหࠡ็หหูืࠧ娬")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ娭"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ娮"),l1l111_l1_ (u"ࠨࠩ娯"),l1l111_l1_ (u"ࠩࠪ娰"),l1l111_l1_ (u"ࠪࠫ娱"),l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ娲"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ娳"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭娴"),l1l111_l1_ (u"ࠧࠨ娵"),469,l1l111_l1_ (u"ࠨࠩ娶"),l1l111_l1_ (u"ࠩࠪ娷"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ娸"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ娹"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ娺"),l1l111_l1_ (u"࠭ࠧ娻"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡨࡲࡺ࠳ࡢࡵࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ娼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ娽"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ娾") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ娿"): title = l1l111_l1_ (u"ࠫัี๊ะࠢะ่็อสࠡฬํๅ๏ࠦแศ่ࠪ婀")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婁"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ婂")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠧࠨ婃")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ婄"),url,l1l111_l1_ (u"ࠩࠪ婅"),l1l111_l1_ (u"ࠪࠫ婆"),l1l111_l1_ (u"ࠫࠬ婇"),l1l111_l1_ (u"ࠬ࠭婈"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ婉"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ婊"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ婋"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ婌"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ婍"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ婎"),l1l111_l1_ (u"้ࠬไ๋สࠪ婏"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ婐"),l1l111_l1_ (u"่ࠧัสๅࠬ婑"),l1l111_l1_ (u"ࠨ็หหึอษࠨ婒"),l1l111_l1_ (u"ࠩ฼ี฻࠭婓"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ婔"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ婕")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ婖") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ婗"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭婘"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠨษ็ั้่ษࠨ婙") in title:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ婚") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ婛"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婜"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ婝"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ婞"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ婟"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ婠"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠤࠥ婡"): continue
				if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ婢") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠫࠬ婣"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婤"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ婥")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ婦"),url,l1l111_l1_ (u"ࠨࠩ婧"),l1l111_l1_ (u"ࠩࠪ婨"),l1l111_l1_ (u"ࠪࠫ婩"),l1l111_l1_ (u"ࠫࠬ婪"),l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ婫"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭婬"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ婭"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭婮") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ婯"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ婰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭婱"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ婲"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠢ婳"): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ婴") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠨࠩ婵"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婶"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ婷")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ婸"),url,l1l111_l1_ (u"ࠬ࠭婹"),l1l111_l1_ (u"࠭ࠧ婺"),l1l111_l1_ (u"ࠧࠨ婻"),l1l111_l1_ (u"ࠨࠩ婼"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ婽"))
	html = response.content
	l11l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ婾"),html,re.DOTALL)
	if l11l1l111l_l1_:
		l11l1l111l_l1_ = l11l1l111l_l1_[0]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ婿") not in l11l1l111l_l1_:
			if l1l111_l1_ (u"ࠬ࠵࠯ࠨ媀") in l11l1l111l_l1_: l11l1l111l_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ媁")+l11l1l111l_l1_
			else: l11l1l111l_l1_ = l111l1_l1_+l11l1l111l_l1_
		l11l1l111l_l1_ = l11l1l111l_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ媂")
		l1llll_l1_.append(l11l1l111l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡤ࠴࠹࠿ࡨࡥࡧࡱࡵࡩ࠭࠴ࠪࡀࠫࡶࡱࡦࡲ࡬࠯ࠬࡂ࡛ࠦ࡯ࡤࡦࡱࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪࠤࡓࡰࡦࡿࠢࠨ媃"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll111_l1_,l111lllll11l_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ媄"),l111lllll111_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡷࡪࡺࡖࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤ媅"),l111lllll11l_l1_,re.DOTALL)
		l111llll1lll_l1_ = zip(names,l1ll_l1_)
		for name,l11ll1lll1l1_l1_ in l111llll1lll_l1_:
			l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_[2:]
			if kodi_version<19: l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ媆"))
			l11ll1lll1l1_l1_ = base64.b64decode(l11ll1lll1l1_l1_)
			if kodi_version>18.99: l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ媇"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ媈"),l11ll1lll1l1_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ媉") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠨ࠱࠲ࠫ媊") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ媋")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ媌")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ媍")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ媎"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"࠭ࠠࠨ媏") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ媐"),l1l111_l1_ (u"ࠨࠩ媑"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠡ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨ媒"),l1l111_l1_ (u"่้ࠪษำโࠢส่อำหࠡใํࠤ์ึวࠡษ็้ํู่ࠡๆสࠤ๏฿ๅๅࠢ฼๊ิࠦืๅสࠣว่ััࠡ็้ࠤ่๊ๅส๋ࠢหาีษࠡ࠰࠱࠲ࠥ๐ัอ๋ࠣห้ฮอฬࠢ฼๊้ࠥไๆหࠣ์ฬำฯสࠢไๆ฼࠭媓"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡷ࠯ࠨ媔")+search+l1l111_l1_ (u"ࠬ࠵ࠧ媕")
	l1lll11_l1_(url)
	return
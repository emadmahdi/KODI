# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ៾")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ៿") : l1l111_l1_ (u"ࠬ࠭᠀") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡄࡏࡉࡣࠬ᠁")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==90: l1lll_l1_ = l1l1l11_l1_()
	elif mode==91: l1lll_l1_ = ITEMS(url)
	elif mode==92: l1lll_l1_ = PLAY(url)
	elif mode==94: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==95: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==99: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠂"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ᠃"),l1l111_l1_ (u"ࠩࠪ᠄"),99,l1l111_l1_ (u"ࠪࠫ᠅"),l1l111_l1_ (u"ࠫࠬ᠆"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᠇"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᠈"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᠉"),l1l111_l1_ (u"ࠨࠩ᠊"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᠋"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᠌")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ᠍"),l1l111_l1_ (u"ࠬ࠭᠎"),94)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᠏"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᠐")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็วาีหࠨ᠑"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯ࡥࡹ࡫ࡳࡵࠩ᠒"),91)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠓"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᠔")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไฤ฻็ํࠥะโ๋็ส๏ࠬ᠕"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࡩ࡮ࡦࡥࠫ᠖"),91)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠗"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᠘")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ศ้หาุ่ࠢฬํฯสࠩ᠙"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡺ࡮࡫ࡷࠨ᠚"),91)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠛"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᠜")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ฮฬฯ࠭᠝"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡱ࡫ࡱࠫ᠞"),91)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠟"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᠠ")+l1lllll_l1_+l1l111_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩᠡ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡳ࡫ࡷࡎࡱࡹ࡭ࡪࡹࠧᠢ"),91)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᠣ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᠤ")+l1lllll_l1_+l1l111_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ᠥ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡰࡨࡻࡊࡶࡩࡴࡱࡧࡩࡸ࠭ᠦ"),91)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᠧ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᠨ"),l1l111_l1_ (u"ࠫࠬᠩ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ᠪ"),headers,l1l111_l1_ (u"࠭ࠧᠫ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᠬ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡤ࡭ࡳࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࡯ࡣࡹࠫᠭ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᠮ"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ࠪหๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭ᠯ")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ᠰ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᠱ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᠲ")+l1lllll_l1_+title,l1ll1ll_l1_,91)
	return html
def ITEMS(url):
	if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࠬᠳ") in url:
		url,search = url.split(l1l111_l1_ (u"ࠨࡁࡷࡁࠬᠴ"))
		headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᠵ") : l1l111_l1_ (u"ࠪࠫᠶ") , l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᠷ") : l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫᠸ") }
		data = { l1l111_l1_ (u"࠭ࡴࠨᠹ") : search }
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬᠺ"),url,data,headers,l1l111_l1_ (u"ࠨࠩᠻ"),l1l111_l1_ (u"ࠩࠪᠼ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨᠽ"))
		html = response.content
	else:
		headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᠾ") : l1l111_l1_ (u"ࠬ࠭ᠿ") }
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧᡀ"),headers,l1l111_l1_ (u"ࠧࠨᡁ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡍ࡙ࡋࡍࡔ࠯࠵ࡲࡩ࠭ᡂ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠳ࡩࡵࡧࡰࡷ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺࡦࡰࡱࡷࠦࠬᡃ"),html,re.DOTALL)
	if l11llll_l1_: block = l11llll_l1_[0]
	else: block = l1l111_l1_ (u"ࠪࠫᡄ")
	items = re.findall(l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡰࡳࡻ࡯ࡥ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᡅ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬอไฮๆๅอࠬᡆ") in title and l1l111_l1_ (u"࠭࠯ࡤ࠱ࠪᡇ") not in url and l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸ࠴࠭ᡈ") not in url:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡜࠲࠰࠽ࡢ࠱ࠧᡉ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᡊ")+l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᡋ"),l1lllll_l1_+title,l1ll1ll_l1_,95,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࠬᡌ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᡍ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᡎ"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᡏ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᡐ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠩสฺ่็อสࠢࠪᡑ"),l1l111_l1_ (u"ࠪࠫᡒ"))
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᡓ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫᡔ")+title,l1ll1ll_l1_,91)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧᡕ"),headers,l1l111_l1_ (u"ࠧࠨᡖ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᡗ"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᡘ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡦࡲ࡬ࡷࡴࡪࡥࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩᡙ"),html,re.DOTALL)
	if l11llll_l1_:
		name = re.findall(l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᡚ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭ᡛ"))
			if l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᡜ") in name: name = name.split(l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᡝ"),1)[1]
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᡞ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᡟ"),l1lllll_l1_+name+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᡠ")+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	else:
		tmp = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࡷ࡭ࡹࡲࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᡡ"),html,re.DOTALL)
		if tmp: l1ll1ll_l1_,title = tmp[0]
		else: l1ll1ll_l1_,title = url,name
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᡢ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l11111l11_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧᡣ"),headers,l1l111_l1_ (u"ࠧࠨᡤ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᡥ"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡷࡩࡽࡺ࠭ࡴࡪࡤࡨࡴࡽ࠺ࠡࡰࡲࡲࡪࡁࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᡦ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࡸ࠳ࡰࡢࡰࡨࡰ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᡧ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᡨ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᡩ")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡮ࡢࡸ࠰ࡸࡦࡨࡳࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࠲ࡶࡡ࡯ࡧ࡯࠱ࡲࡵࡲࡦࠩᡪ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡥ࡮ࡤࡨࡨࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᡫ"),block,re.DOTALL)
		for id,l1ll1ll_l1_ in items:
			title = l1l111_l1_ (u"ࠨีํีๆืࠠࠨᡬ")+id
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᡭ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᡮ")
			l1llll_l1_.append(l1ll1ll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷࡼࡥࡳ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᡯ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᡰ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᡱ")+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᡲ"),url)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩᡳ"),headers,l1l111_l1_ (u"ࠩࠪᡴ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡒࡁࡕࡇࡖࡘ࠲࠷ࡳࡵࠩᡵ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡫ࡱࡨࡪࡾ࠭࡭ࡣࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡯࡮ࡥࡧࡻ࠱ࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࠪᡶ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᡷ"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࠧᡸ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᡹"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᡺"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ᡻"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ᡼"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭᡽"),l1l111_l1_ (u"ࠬ࠱ࠧ᡾"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡹࡃࠧ᡿")+search
	ITEMS(url)
	return
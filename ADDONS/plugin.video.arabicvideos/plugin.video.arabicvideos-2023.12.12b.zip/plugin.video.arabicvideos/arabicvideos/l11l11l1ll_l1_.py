# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪṕ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡍࡂࡠࠩṖ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨṗ"):l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠪṘ")}
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==120: l1lll_l1_ = l1l1l11_l1_()
	elif mode==121: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==122: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==123: l1lll_l1_ = PLAY(url)
	elif mode==124: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬṙ")+text)
	elif mode==125: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Ṛ")+text)
	elif mode==129: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṛ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩṜ"),l1l111_l1_ (u"ࠪࠫṝ"),129,l1l111_l1_ (u"ࠫࠬṞ"),l1l111_l1_ (u"ࠬ࠭ṟ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṠ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬṡ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨṢ"),l1l111_l1_ (u"ࠩࠪṣ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧṤ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬṥ"),headers,l1l111_l1_ (u"ࠬ࠭Ṧ"),l1l111_l1_ (u"࠭ࠧṧ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪṨ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡮࡯࡮ࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡬࡯࡭ࡦࡨࡶࠧ࠭ṩ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫṪ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪห้๋ีศำ฼อࠬṫ") in title: continue
			title = title.rsplit(l1l111_l1_ (u"ࠫࡃ࠭Ṭ"),1)[1]
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧṭ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨṮ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṯ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪṰ")+l1lllll_l1_+title,l1ll1ll_l1_,122)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧṱ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪṲ"),l1l111_l1_ (u"ࠫࠬṳ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡥ࡮ࡴࡌࡰࡣࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡹࡩࡷࡺࡩࡤࡣ࡯ࡈࡾࡴࡡ࡮࡫ࡦࠦࠬṴ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡰࡥࡣࠣࡦࡩࡨࠢ࠿࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪṵ"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩṶ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪṷ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠩส่๊฻วา฻ฬࠫṸ") in title: continue
			if l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬṹ") in l1ll1ll_l1_: continue
			if not title and l1l111_l1_ (u"ࠫ࠴ࡺࡶ࠰ࡣࡵࡥࡧ࡯ࡣࠨṺ") in l1ll1ll_l1_: title = l1l111_l1_ (u"๋ࠬำๅี็หฯูࠦาสํอࠬṻ")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ṽ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩṽ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ṿ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩṿ"),l1l111_l1_ (u"ࠪࠫẀ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠨ࠯ࠬࡂ࠭ࡃࡋࡧࡺࡄࡨࡷࡹࡂ࠯ࡢࡀࠪẁ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧẂ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨẃ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẄ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪẅ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭Ẇ"),url,l1l111_l1_ (u"ࠪࠫẇ"),headers,l1l111_l1_ (u"ࠫࠬẈ"),l1l111_l1_ (u"ࠬ࠭ẉ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬẊ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡵࡢࡷࡨࡸ࡯࡭࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨẋ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩẌ"),block,re.DOTALL)
	if l1l111_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࠫẍ") not in url:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẎ"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧẏ"),url,125)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẐ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩẑ"),url,124)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬẒ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨẓ"),l1l111_l1_ (u"ࠩࠪẔ"),9999)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẕ"),l1lllll_l1_+title,l1ll1ll_l1_,121)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠫ࠶࠭ẖ")):
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠬ࠷ࠧẗ")
	if l1l111_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࠩẘ") in url or l1l111_l1_ (u"ࠧࡀࠩẙ") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠨࠨࠪẚ")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠩࡂࠫẛ")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠪࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡀ࡮ࡸࡵ࡮ࠧࡱࡸࡸࡵࡻࡴࡠ࡯ࡲࡨࡪࡃ࡭ࡰࡸ࡬ࡩࡸࡥ࡬ࡪࡵࡷࠪࡵࡧࡧࡦ࠿ࠪẜ")+l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨẝ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ẞ"),headers,l1l111_l1_ (u"࠭ࠧẟ"),l1l111_l1_ (u"ࠧࠨẠ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ạ"))
	html = response.content
	name,items = l1l111_l1_ (u"ࠩࠪẢ"),[]
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬả") in url:
		name = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࠨẤ"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l1l111_l1_ (u"ࠬࠦࠧấ")) + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪẦ")
		else: name = xbmc.getInfoLabel( l1l111_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠣầ") ) + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬẨ")
	if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࠪẩ") not in url: items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡡࡢ࡜࡝ࠤࠫࡠࡡࡢ࡜࡝࠱ࡶࡩࡦࡹ࡯࡯࠰࠭ࡃ࠮ࡢ࡜࡝࡞ࠥ࠲࠯ࡅࡳࡳࡥࡀࡠࡡࡢ࡜ࠣࠪ࠱࠮ࡄ࠯࡜࡝࡞࡟ࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫࡜࡝࡞࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬẪ"),html,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡢ࡜࡝࡞ࠥࠬ࠳࠰࠿ࠪ࡞࡟ࡠࡡࠨ࠮ࠫࡁࡶࡶࡨࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࡞࡟ࡠࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧẫ"),html,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧẬ") in url and l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࡜࠰ࠩậ") not in l1ll1ll_l1_: continue
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩẮ") in url and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࡟࠳ࠬắ") not in l1ll1ll_l1_: continue
		title = name+escapeUNICODE(title).strip(l1l111_l1_ (u"ࠩࠣࠫẰ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭ằ"),l1l111_l1_ (u"ࠫ࠴࠭Ẳ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨẳ"),l1l111_l1_ (u"࠭࠯ࠨẴ"))
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬẵ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧẶ")+l1ll1l_l1_
		l1lllll1_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱ࠪặ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭Ẹ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠫ࠴ࡳࡡࡴࡴࡤ࡬࡮ࡿࡡࡵ࠱ࠪẹ") in url:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫẺ"),l1lllll_l1_+title,l1lllll1_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨẻ")),123,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẼ"),l1lllll_l1_+title,l1lllll1_l1_,121,l1ll1l_l1_)
	if len(items)>=12:
		l11l1l1l11_l1_ = [l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪẽ"),l1l111_l1_ (u"ࠩ࠲ࡸࡻ࠵ࠧẾ"),l1l111_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴࠭ế"),l1l111_l1_ (u"ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠯ࠨỀ"),l1l111_l1_ (u"ࠬ࠵࡭ࡢࡵࡵࡥ࡭࡯ࡹࡢࡶ࠲ࠫề")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l11_l1_):
			for n in range(0,1100,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ể"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ể")+str(j),url,121,l1l111_l1_ (u"ࠨࠩỄ"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩễ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩỆ")+str(i),url,121,l1l111_l1_ (u"ࠫࠬệ"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỈ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬỉ")+str(1),url,121,l1l111_l1_ (u"ࠧࠨỊ"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨị"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨỌ")+str(n),url,121,l1l111_l1_ (u"ࠪࠫọ"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫỎ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫỏ")+str(1),url,121)
	return
def PLAY(url):
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪỐ"):l1l111_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠬố")}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬỒ"),url,l1l111_l1_ (u"ࠩࠪồ"),headers,l1l111_l1_ (u"ࠪࠫỔ"),l1l111_l1_ (u"ࠫࠬổ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨỖ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁห้ะี็์ไࡀ࠴ࡺࡤ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ỗ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡱࡪ࠾ࡺࡸ࡬ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫỘ"),html,re.DOTALL)
	if l11l11ll11_l1_: server = l1l111l_l1_(l11l11ll11_l1_[0],l1l111_l1_ (u"ࠨࡷࡵࡰࠬộ"))
	else: server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭Ớ"))
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	l11l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡺࡺ࡯࠮ࡵ࡬ࡾࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬớ"),html,re.DOTALL)
	if l11l1l111l_l1_:
		l11l1l111l_l1_ = server+l11l1l111l_l1_[0]
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨỜ"),l11l1l111l_l1_,l1l111_l1_ (u"ࠬ࠭ờ"),headers,l1l111_l1_ (u"࠭ࠧỞ"),l1l111_l1_ (u"ࠧࠨở"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫỠ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠩࡧࡳࡸࡺࡲࡦࡣࡰࠫỡ") not in l11l1ll1_l1_:
			l11l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡩࡲࡪࡲࡷ࠲࠯ࡅ࠾ࡧࡷࡱࡧࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩỢ"),l11l1ll1_l1_,re.DOTALL)
			l11l1111ll_l1_ = l11l1111ll_l1_[0]
			result = l11l11ll1l_l1_(l11l1111ll_l1_)
			try: l11l11l1l1_l1_,l11l11111l_l1_,l11ll111ll_l1_ = result
			except:
				l1111l1_l1_(l1l111_l1_ (u"ࠫࠬợ"),l1l111_l1_ (u"ࠬ࠭Ụ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩụ"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡ࠰ࠣๆิ๊ࠦไ๊้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ็อๅࠡสอัิ๐หࠡืไัฬะ็๊ࠡส่อืๆศ็ฯࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣๆึอมสࠢสฺ่็อศฬࠣห้าฯ๋ัฬࠫỦ"))
				return
			l11l11111l_l1_ = server+l11l11111l_l1_
			l11l11l1l1_l1_ = server+l11l11l1l1_l1_
			cookies = response.cookies
			if l1l111_l1_ (u"ࠨࡒࡖࡗࡎࡊࠧủ") in cookies.keys():
				l11l111111_l1_ = cookies[l1l111_l1_ (u"ࠩࡓࡗࡘࡏࡄࠨỨ")]
				headers[l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪứ")] = l1l111_l1_ (u"ࠫࡕ࡙ࡓࡊࡆࡀࠫỪ")+l11l111111_l1_
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩừ"),l11l11l1l1_l1_,l1l111_l1_ (u"࠭ࠧỬ"),headers,l1l111_l1_ (u"ࠧࠨử"),l1l111_l1_ (u"ࠨࠩỮ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬữ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨỰ"),l11l11111l_l1_,l11ll111ll_l1_,headers,l1l111_l1_ (u"ࠫࠬự"),l1l111_l1_ (u"ࠬ࠭Ỳ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩỳ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫỴ"),l11l1l111l_l1_,l1l111_l1_ (u"ࠨࠩỵ"),headers,l1l111_l1_ (u"ࠩࠪỶ"),l1l111_l1_ (u"ࠪࠫỷ"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧỸ"))
				l11l1ll1_l1_ = response.content
		l11llll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪỹ"),l11l1ll1_l1_,re.DOTALL)
		if l11llll1ll_l1_:
			l11llll1ll_l1_ = server+l11llll1ll_l1_[0]
			l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1_l1_(l11llll1ll_l1_,headers)
			zz = zip(l1l1lll1_l1_,l1llll_l1_)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			for title,l1ll1ll_l1_ in zz:
				l111l1ll_l1_ = title.split(l1l111_l1_ (u"࠭ࠠࠡࠩỺ"))[1]
				l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲ࠹ࡵ࠹ࡡࡢࠫỻ")+l111l1ll_l1_)
				l11ll111l1_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡸࡷ࡫ࡡ࡮࠱ࠪỼ"),l1l111_l1_ (u"ࠩ࠲ࡨࡱ࠵ࠧỽ")).replace(l1l111_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰ࠲ࡲ࠹ࡵ࠹ࠩỾ"),l1l111_l1_ (u"ࠫࠬỿ"))
				l1llll_l1_.append(l11ll111l1_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡼࡩࡥࡵࡷࡶࡪࡧ࡭ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡳࡰ࠵ࡡࡢࠫἀ")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬἁ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨἂ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩἃ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫἄ"),l1l111_l1_ (u"ࠪ࠯ࠬἅ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࡲ࠿ࠪἆ") + l1lll1ll_l1_
	l1lll11_l1_(url)
	return
l1l11111_l1_ = [l1l111_l1_ (u"ࠬอไ็๊฼ࠫἇ"),l1l111_l1_ (u"࠭วๅี้อࠬἈ"),l1l111_l1_ (u"ࠧศๆห่ิ࠭Ἁ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ื๋ฯࠧἊ"),l1l111_l1_ (u"ࠩส่้เษࠨἋ"),l1l111_l1_ (u"ࠪห้ฮไะࠩἌ"),l1l111_l1_ (u"ࠫฬ๊ฯใหࠪἍ"),l1l111_l1_ (u"ࠬอไอ๊าอࠬἎ"),l1l111_l1_ (u"࠭วๅฬิะ๊ฯࠧἏ"),l1l111_l1_ (u"ࠧศๆ้์฾࠭ἐ"),l1l111_l1_ (u"ࠨษ็ฮฺ์๊โࠩἑ")]
l11lll_l1_ = []
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ἒ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧἓ"),url,l1l111_l1_ (u"ࠫࠬἔ"),headers,l1l111_l1_ (u"ࠬ࠭ἕ"),l1l111_l1_ (u"࠭ࠧ἖"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ἗"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷࠧ࠭Ἐ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	zz = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡹࡷࡸࡥ࡯ࡶࡢࡳࡵࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫἙ"),block,re.DOTALL)
	l11l1l1lll_l1_,l11l1lll11_l1_ = zip(*zz)
	l1l11l1l_l1_ = zip(l11l1l1lll_l1_,l11l1lll11_l1_,l11l1l1lll_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩἚ"),block,re.DOTALL)
	l111llllll_l1_ = []
	for l1ll1ll_l1_,name in items:
		name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭Ἓ"))
		value = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧἜ"),1)[1]
		if name in l11lll_l1_: continue
		if l1l111_l1_ (u"࠭ไๅๅหหึ࠭Ἕ") in name: continue
		if l1l111_l1_ (u"ࠧࡕࡘ࠰ࡑࡆ࠭἞") in name: continue
		if l1l111_l1_ (u"ࠨࡖ࡙࠱࠶࠺ࠧ἟") in name: continue
		l111llllll_l1_.append((value,name))
	return l111llllll_l1_
def l11l1l11l1_l1_(l1l1ll11_l1_,url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ἠ"),1)[0]
	url = url.strip(l1l111_l1_ (u"ࠪ࠳ࠬἡ"))
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ἢ"))
	l11ll111_l1_ = l11ll111_l1_.replace(l1l111_l1_ (u"ࠬࠦࠫࠡࠩἣ"),l1l111_l1_ (u"࠭࠭ࠨἤ"))
	url = url+l1l111_l1_ (u"ࠧ࠰ࠩἥ")+l11ll111_l1_
	return url
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠨࡁࠪἦ") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ἧ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧἨ"),1)
	if filter==l1l111_l1_ (u"ࠫࠬἩ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭Ἢ"),l1l111_l1_ (u"࠭ࠧἫ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫἬ"))
	if type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫἭ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫἮ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬἯ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ἰ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨἱ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨἲ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪἳ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪἴ"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ἵ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬἶ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧἷ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩἸ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩἹ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩἺ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫἻ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ἴ")+l11lll11_l1_
		l1llllll_l1_ = l11l1l11l1_l1_(l11lll11_l1_,l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪἽ"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧἾ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἿ"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ὀ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ὁ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ὂ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩὃ"),l1l111_l1_ (u"ࠪࠫὄ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		l1l111ll_l1_ = l1l111ll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭ὅ"))
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ὆"))
		name = name.replace(l1l111_l1_ (u"࠭࠭࠮ࠩ὇"),l1l111_l1_ (u"ࠧࠨὈ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪὉ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬὊ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					l1llllll_l1_ = l11l1l11l1_l1_(l11lll11_l1_,url)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩὋ")+l1l111l1_l1_)
				return
			else:
				l1llllll_l1_ = l11l1l11l1_l1_(l11lll11_l1_,l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫὌ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭Ὅ"),l1llllll_l1_,121)
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭὎"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ὏"),l1lllll1_l1_,125,l1l111_l1_ (u"ࠨࠩὐ"),l1l111_l1_ (u"ࠩࠪὑ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ὒ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ὓ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨὔ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨὕ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪὖ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬὗ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ὘"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬὙ")+name,l1lllll1_l1_,124,l1l111_l1_ (u"ࠫࠬ὚"),l1l111_l1_ (u"ࠬ࠭Ὓ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ὜")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩὝ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ὞")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫὟ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧὠ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧὡ")+name
			if type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨὢ"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ὣ"),l1lllll_l1_+title,url,124,l1l111_l1_ (u"ࠧࠨὤ"),l1l111_l1_ (u"ࠨࠩὥ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬὦ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬὧ") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11l1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫὨ"),l1lllll_l1_+title,l1llllll_l1_,121)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὩ"),l1lllll_l1_+title,url,125,l1l111_l1_ (u"࠭ࠧὪ"),l1l111_l1_ (u"ࠧࠨὫ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫὬ"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭Ὥ"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬὮ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭Ὧ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧὰ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨά"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨὲ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪέ")
		if l1l111_l1_ (u"ࠩࠨࠫὴ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬή") and value!=l1l111_l1_ (u"ࠫ࠵࠭ὶ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩί")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩὸ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩό"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪὺ")+key+l1l111_l1_ (u"ࠩࡀࠫύ")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨὼ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ώ")+key+l1l111_l1_ (u"ࠬࡃࠧ὾")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ὿"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩᾀ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫᾁ"),l1l111_l1_ (u"ࠩࡀࠫᾂ"))
	return l1l1l111_l1_
def l11l1lllll_l1_(l11l1111l1_l1_):
	m = re.search(l1l111_l1_ (u"ࡵࠫࡣ࠮࡜ࡥ࠭ࠬ࡟࠳࠲࡝ࡀ࡞ࡧ࠮ࡄ࠭ᾃ"), str(l11l1111l1_l1_))
	return int(m.groups()[-1]) if m and not callable(l11l1111l1_l1_) else 0
def l11l11l111_l1_(l11l1lll1l_l1_):
	try:
		l11l1ll11l_l1_ = base64.b64decode(l11l1lll1l_l1_)
	except:
		try:
			l11l1ll11l_l1_ = base64.b64decode(l11l1lll1l_l1_+l1l111_l1_ (u"ࠫࡂ࠭ᾄ"))
		except:
			try:
				l11l1ll11l_l1_ = base64.b64decode(l11l1lll1l_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨᾅ"))
			except:
				l11l1ll11l_l1_ = l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡧࡧࡳࡦ࠸࠷ࠤࡩ࡫ࡣࡰࡦࡨࠤࡪࡸࡲࡰࡴࠪᾆ")
	if kodi_version>18.99: l11l1ll11l_l1_ = l11l1ll11l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᾇ"))
	return l11l1ll11l_l1_
def l11l111ll1_l1_(l11l1ll111_l1_,l11l1l1l1l_l1_,a):
	a = a - l11l1l1l1l_l1_
	if a<0:
		c = l1l111_l1_ (u"ࠨࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠫᾈ")
	else:
		c = l11l1ll111_l1_[a]
	return c
def x(l11l1ll111_l1_,l11l1l1l1l_l1_,a):
	return(l11l111ll1_l1_(l11l1ll111_l1_,l11l1l1l1l_l1_,a))
def l11l1ll1l1_l1_(l11ll11111_l1_,step,l11l1l1l1l_l1_,l11l11lll1_l1_):
	l11l11lll1_l1_ = l11l11lll1_l1_.replace(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࠧᾉ"),l1l111_l1_ (u"ࠪ࡫ࡱࡵࡢࡢ࡮ࠣࡨࡀࠦࠧᾊ"))
	l11l11lll1_l1_ = l11l11lll1_l1_.replace(l1l111_l1_ (u"ࠫࡽ࠮ࠧᾋ"),l1l111_l1_ (u"ࠬࡾࠨࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠫᾌ"))
	l11l11lll1_l1_ = l11l11lll1_l1_.replace(l1l111_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡤ࠼ࠢࡧࡁࠬᾍ"),l1l111_l1_ (u"ࠧࠨᾎ"))
	d = eval(l11l11lll1_l1_,{l1l111_l1_ (u"ࠨࡲࡤࡶࡸ࡫ࡉ࡯ࡶࠪᾏ"):l11l1lllll_l1_,l1l111_l1_ (u"ࠩࡻࠫᾐ"):x,l1l111_l1_ (u"ࠪࡸࡦࡨࠧᾑ"):l11ll11111_l1_,l1l111_l1_ (u"ࠫࡸࡺࡥࡱ࠴ࠪᾒ"):l11l1l1l1l_l1_})
	l11ll11l1l_l1_=0
	while True:
		l11ll11l1l_l1_=l11ll11l1l_l1_+1
		l11ll11111_l1_.append(l11ll11111_l1_[0])
		del l11ll11111_l1_[0]
		d = eval(l11l11lll1_l1_,{l1l111_l1_ (u"ࠬࡶࡡࡳࡵࡨࡍࡳࡺࠧᾓ"):l11l1lllll_l1_,l1l111_l1_ (u"࠭ࡸࠨᾔ"):x,l1l111_l1_ (u"ࠧࡵࡣࡥࠫᾕ"):l11ll11111_l1_,l1l111_l1_ (u"ࠨࡵࡷࡩࡵ࠸ࠧᾖ"):l11l1l1l1l_l1_})
		if ((d == step) or (l11ll11l1l_l1_>10000)): break
	return
def l11l11ll1l_l1_(l11l1111ll_l1_):
	tmp = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷ࠴ࠪࡀ࠿ࠫ࠲ࢀ࠸ࠬ࠵ࡿࠬࡠ࠭ࡢࠩࠨᾗ"), l11l1111ll_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠪࡉࡗࡘ࠺ࡗࡣࡵࡧࡴࡴࡳࡵࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾘ")
	l11l111l11_l1_ = tmp[0].strip()
	_print(l1l111_l1_ (u"࡛ࠫࡧࡲࡤࡱࡱࡷࡹࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨᾙ") % l11l111l11_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࢃ࡜ࠩࠩᾚ")+l11l111l11_l1_+l1l111_l1_ (u"࠭࠿࠭ࠪ࠳ࡼࡠ࠶࠭࠺ࡣ࠰ࡪࡢࢁ࠱࠭࠳࠳ࢁ࠮ࡢࠩ࡝ࠫ࠾ࠫᾛ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾࡙ࠥࡴࡦࡲ࠴ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧᾜ")
	step = eval(tmp[0])
	_print(l1l111_l1_ (u"ࠨࡕࡷࡩࡵ࠷ࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢ࠳ࡼࠪࡹࠧᾝ") % l1l111_l1_ (u"ࠩࡾ࠾࠵࠸ࡘࡾࠩᾞ").format(step).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠪࡨࡂࡪ࠭ࠩ࠲ࡻ࡟࠵࠳࠹ࡢ࠯ࡩࡡࢀ࠷ࠬ࠲࠲ࢀ࠭ࡀ࠭ᾟ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡕࡷࡩࡵ࠸ࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪᾠ")
	l11l1l1l1l_l1_ = eval(tmp[0])
	_print(l1l111_l1_ (u"࡙ࠬࡴࡦࡲ࠵ࠤࠥࠦࠠࠡࠢࠣࠤࡂࠦ࠰ࡹࠧࡶࠫᾡ") % l1l111_l1_ (u"࠭ࡻ࠻࠲࠵࡜ࢂ࠭ᾢ").format(l11l1l1l1l_l1_).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠢࡵࡴࡼࡿ࠭ࡼࡡࡳ࠰࠭ࡃ࠮ࡁࠢᾣ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࡪࡥࡤࡣ࡯ࡣ࡫ࡴࡣࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾤ")
	l11l11lll1_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠩࡇࡩࡨࡧ࡬ࠡࡨࡸࡲࡨࠦࠠࠡ࠿ࠣࠦࠥࠫࡳ࠯࠰࠱ࠦࠬᾥ") % l11l11lll1_l1_[0:135])
	tmp = re.findall(l1l111_l1_ (u"ࠥࠫࡩࡧࡴࡢࠩ࠽ࡿࠬ࠮࡟࡜࠲࠰࠽ࡦ࠳ࡺࡂ࠯࡝ࡡࢀ࠷࠰࠭࠴࠳ࢁ࠮࠭࠺ࠨࡱ࡮ࠫࠧᾦ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡒࡲࡷࡹࡑࡥࡺࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾧ")
	l11l1llll1_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠬࡖ࡯ࡴࡶࡎࡩࡾࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩᾨ") % l11l1llll1_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࠤᾩ")+l11l111l11_l1_+l1l111_l1_ (u"ࠢ࠯ࠬࡂࡺࡦࡸ࠮ࠫࡁࡀࠬࡡࡡ࠮ࠫࡁࡠ࠭ࠧᾪ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿࡚ࡡࡣࡎ࡬ࡷࡹࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩᾫ")
	l11l1l11ll_l1_ = tmp[0]
	l11l1l11ll_l1_ = l11l111l11_l1_ + l1l111_l1_ (u"ࠤࡀࠦᾬ") + l11l1l11ll_l1_
	exec(l11l1l11ll_l1_) in globals(), locals()
	l11l1ll111_l1_ = locals()[l11l111l11_l1_]
	_print(l11l111l11_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧ࠱࠽࠵ࡹ࠮࠯࠰ࠪᾭ")%str(l11l1ll111_l1_))
	l11l1ll1l1_l1_(l11l1ll111_l1_,step,l11l1l1l1l_l1_,l11l11lll1_l1_)
	_print(l11l111l11_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨ࠲࠾࠶ࡳ࠯࠰࠱ࠫᾮ")%str(l11l1ll111_l1_))
	tmp = re.findall(l1l111_l1_ (u"ࠧࡢࠨ࡝ࠫ࠾ࠬࡻࡧࡲࠡ࠰࠭ࡃ࠮ࡢࠤ࡝ࠪࠪࡠ࠯࠭࡜ࠪࠤᾯ"), l11l1111ll_l1_, re.S)
	if not tmp:
		tmp = re.findall(l1l111_l1_ (u"ࠨࡡ࠱ࡣ࡟ࠬࡡ࠯࠻ࠩ࠰࠭ࡃ࠮ࡢࠤ࡝ࠪࠪࡠ࠯࠭࡜ࠪࠤᾰ"), l11l1111ll_l1_, re.S)
		if not tmp:
			return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾ࡑ࡯ࡳࡵࡡ࡙ࡥࡷࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩᾱ")
	l11ll11l11_l1_ = tmp[0]
	l11ll11l11_l1_ = re.sub(l1l111_l1_ (u"ࠣࠪࡩࡹࡳࡩࡴࡪࡱࡱࠤ࠳࠰࠿ࡾ࠰࠭ࡃࢂ࠯ࠢᾲ"), l1l111_l1_ (u"ࠤࠥᾳ"), l11ll11l11_l1_)
	_print(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡠࡘࡤࡶࠥࠦࠠࠡࠢࡀࠤࠪ࠴࠹࠱ࡵ࠱࠲࠳࠭ᾴ") % l11ll11l11_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠦ࠭ࡥ࡛ࡢ࠯ࡽࡅ࠲ࢀ࠰࠮࠻ࡠࡿ࠹࠲࠸ࡾࠫࡀࡠࡠࡢ࡝ࠣ᾵") , l11ll11l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠬࡋࡒࡓ࠼࠶࡚ࡦࡸࡳࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾶ")
	_11l1l1ll1_l1_ = tmp
	_print(l1l111_l1_ (u"࠭࠳ࡗࡣࡵࡷࠥࠦࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪᾷ")%str(_11l1l1ll1_l1_))
	l11l1l1111_l1_ = _11l1l1ll1_l1_[1]
	_print(l1l111_l1_ (u"ࠧࡣ࡫ࡪࡣࡸࡺࡲࡠࡸࡤࡶࠥࠦ࠽ࠡࠧࡶࠫᾸ")%l11l1l1111_l1_)
	l11ll11l11_l1_ = l11ll11l11_l1_.replace(l1l111_l1_ (u"ࠨ࠮ࠪᾹ"),l1l111_l1_ (u"ࠩ࠾ࠫᾺ")).split(l1l111_l1_ (u"ࠪ࠿ࠬΆ"))
	for l11l1lll1l_l1_ in l11ll11l11_l1_:
		l11l1lll1l_l1_ = l11l1lll1l_l1_.strip()
		if l1l111_l1_ (u"ࠫ࡮ࡹ࡭ࡰࡤࠪᾼ") in l11l1lll1l_l1_: l11l1lll1l_l1_=l1l111_l1_ (u"ࠬ࠭᾽")
		if l1l111_l1_ (u"࠭࠽࡜࡟ࠪι")   in l11l1lll1l_l1_: l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠧ࠾࡝ࡠࠫ᾿"),l1l111_l1_ (u"ࠨ࠿ࡾࢁࠬ῀"))
		l11l1lll1l_l1_ = re.sub(l1l111_l1_ (u"ࠤࠫࡥ࠵࠴࡜ࠩࠫࠥ῁"), l1l111_l1_ (u"ࠥࡥ࠵ࡪࠨ࡮ࡣ࡬ࡲࡤࡺࡡࡣ࠮ࡶࡸࡪࡶ࠲࠭ࠤῂ"), l11l1lll1l_l1_)
		if l11l1lll1l_l1_!=l1l111_l1_ (u"ࠫࠬῃ"):
			l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠬࠧࠡ࡜࡟ࠪῄ"),l1l111_l1_ (u"࠭ࡔࡳࡷࡨࠫ῅"));
			l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠧࠢ࡝ࡠࠫῆ"),l1l111_l1_ (u"ࠨࡈࡤࡰࡸ࡫ࠧῇ"));
			l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࠧῈ"),l1l111_l1_ (u"ࠪࠫΈ"));
			try:
				exec(l11l1lll1l_l1_,{l1l111_l1_ (u"ࠫࡵࡧࡲࡴࡧࡌࡲࡹ࠭Ὴ"):l11l1lllll_l1_,l1l111_l1_ (u"ࠬࡧࡴࡰࡤࠪΉ"):l11l11l111_l1_,l1l111_l1_ (u"࠭ࡡ࠱ࡦࠪῌ"):l11l111ll1_l1_,l1l111_l1_ (u"ࠧࡹࠩ῍"):x,l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡴࡢࡤࠪ῎"):l11l1ll111_l1_,l1l111_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨ῏"):l11l1l1l1l_l1_},locals())
			except:
				pass
	l11ll1111l_l1_ = l1l111_l1_ (u"ࠪࠫῐ")
	for i in range(0,len(locals()[_11l1l1ll1_l1_[2]])):
		if locals()[_11l1l1ll1_l1_[2]][i] in locals()[_11l1l1ll1_l1_[1]]:
			l11ll1111l_l1_ = l11ll1111l_l1_ + locals()[_11l1l1ll1_l1_[1]][locals()[_11l1l1ll1_l1_[2]][i]]
	_print(l1l111_l1_ (u"ࠫࡧ࡯ࡧࡔࡶࡵ࡭ࡳ࡭ࠠࠡࠢࠣࡁࠥࠫ࠮࠺࠲ࡶ࠲࠳࠴ࠧῑ")%l11ll1111l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡥࡁࡡ࠭࠯࡝ࠩ࡟࠯࠭࠴ࠪࡀࠫࠫࡃ࠿࠲ࡼ࠼ࠫࠪῒ"), l11l1111ll_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡌ࡫ࡴࡖࡴ࡯ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧΐ")
	l11l111l1l_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡈࡧࡷ࡙ࡷࡲࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫ῔") % l11l111l1l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࠪࡢ࠲࠯ࡅࠩ࡝࡝ࠪ῕"), l11l111l1l_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࠠࡈࡧࡷ࡚ࡦࡸࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪῖ")
	l11l111lll_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠪࡋࡪࡺࡖࡢࡴࠣࠤࠥࠦࠠࠡࠢࡀࠤࠪࡹࠧῗ") % l11l111lll_l1_)
	l11l1ll1ll_l1_ = locals()[l11l111lll_l1_][0]
	l11l1ll1ll_l1_ = l11l11l111_l1_(l11l1ll1ll_l1_)
	_print(l1l111_l1_ (u"ࠫࡌ࡫ࡴࡗࡣ࡯ࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨῘ") % l11l1ll1ll_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࢃࡶࡢࡴࠣࠬ࡫ࡃ࠮ࠫࡁࠬ࠿ࠬῙ"), l11l1111ll_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡕࡵࡳࡵࡗࡵࡰࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨῚ")
	l11l11l11l_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡑࡱࡶࡸ࡚ࡸ࡬ࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫΊ") % l11l11l11l_l1_)
	l11l11l11l_l1_ = re.sub(l1l111_l1_ (u"ࠣࠪࡺ࡭ࡳࡪ࡯ࡸ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠥ῜"), l1l111_l1_ (u"ࠤࡤࡸࡴࡨࠢ῝"), l11l11l11l_l1_)
	l11l11l11l_l1_ = re.sub(l1l111_l1_ (u"ࠥࠬࡠࡇ࡛࠭࡟ࡾ࠵࠱࠸ࡽ࡝ࠪࠬࠦ῞"), l1l111_l1_ (u"ࠦࡦ࠶ࡤࠩ࡯ࡤ࡭ࡳࡥࡴࡢࡤ࠯ࡷࡹ࡫ࡰ࠳࠮ࠥ῟"), l11l11l11l_l1_)
	l11l11l11l_l1_ = l1l111_l1_ (u"ࠬ࡭࡬ࡰࡤࡤࡰࠥ࡬࠻ࠡࠩῠ")+l11l11l11l_l1_
	verify = re.findall(l1l111_l1_ (u"࠭࡜ࠬࠪࡢ࠲࠯ࡅࠩࠥࠩῡ"),l11l11l11l_l1_,re.DOTALL)[0]
	l11l11llll_l1_ = eval(verify)
	l11l11l11l_l1_ = l11l11l11l_l1_.replace(l1l111_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡧ࠽ࠣࡪࡂ࠭ῢ"),l1l111_l1_ (u"ࠨࠩΰ"))
	f = eval(l11l11l11l_l1_,{l1l111_l1_ (u"ࠩࡤࡸࡴࡨࠧῤ"):l11l11l111_l1_,l1l111_l1_ (u"ࠪࡥ࠵ࡪࠧῥ"):l11l111ll1_l1_,l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡷࡥࡧ࠭ῦ"):l11l1ll111_l1_,l1l111_l1_ (u"ࠬࡹࡴࡦࡲ࠵ࠫῧ"):l11l1l1l1l_l1_,verify:l11l11llll_l1_})
	_print(l1l111_l1_ (u"࠭࠯ࠨῨ")+l11l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬῩ")+f+l11ll1111l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭Ὺ")+l11l1llll1_l1_)
	return([l1l111_l1_ (u"ࠩ࠲ࠫΎ")+l11l1ll1ll_l1_,f+l11ll1111l_l1_,{ l11l1llll1_l1_ : l1l111_l1_ (u"ࠪࡳࡰ࠭Ῥ")}])
def _print(text):
	return
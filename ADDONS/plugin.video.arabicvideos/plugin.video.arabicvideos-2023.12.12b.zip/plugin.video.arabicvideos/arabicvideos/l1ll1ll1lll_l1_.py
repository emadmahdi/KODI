# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ⸕")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ⸖")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1ll11_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
l1ll1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][3]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==20: l1lll_l1_ = l1ll1l1llll_l1_()
	elif mode==21: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==22: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==23: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==24: l1lll_l1_ = PLAY(url,text)
	elif mode==25: l1lll_l1_ = l1ll1l111ll_l1_(url)
	elif mode==27: l1lll_l1_ = l1ll1llll_l1_(url)
	elif mode==28: l1lll_l1_ = l1ll1ll111l_l1_()
	elif mode==29: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll1l1llll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸗"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฿ัษ์ࠪ⸘"),l111l1_l1_,21,l1l111_l1_ (u"࠭ࠧ⸙"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⸚"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸛"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠪ⸜"),l1l1l1ll1l_l1_,21,l1l111_l1_ (u"ࠪࠫ⸝"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⸞"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸟"),l1lllll_l1_+l1l111_l1_ (u"࠭แศำึํࠬ⸠"),l1ll1l1ll11_l1_,21,l1l111_l1_ (u"ࠧࠨ⸡"),l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⸢"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸣"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ⸤"),l1ll1l1lll1_l1_,21,l1l111_l1_ (u"ࠫࠬ⸥"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⸦"))
	return
def l1ll1ll111l_l1_():
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ⸧"),l1lllll_l1_+l1l111_l1_ (u"ฺࠧำห๎ࠬ⸨"),l111l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⸩"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠪ⸪"),l1l1l1ll1l_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⸫"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆอัิ๋ࠪ⸬"),l1ll1l1ll11_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⸭"),l1lllll_l1_+l1l111_l1_ (u"࠭แศำึํࠥ࠸ࠧ⸮"),l1ll1l1lll1_l1_,27)
	return
def l1l1l11_l1_(l1ll1ll11l1_l1_):
	l1ll1_l1_ = l1ll1ll11l1_l1_
	if l1ll1ll11l1_l1_==l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭ⸯ"): l1ll1ll11l1_l1_ = l111l1_l1_
	elif l1ll1ll11l1_l1_==l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⸰"): l1ll1ll11l1_l1_ = l1l1l1ll1l_l1_
	else: l1ll1_l1_ = l1l111_l1_ (u"ࠩࠪ⸱")
	l1lllll111l_l1_ = l1ll1ll1l11_l1_(l1ll1ll11l1_l1_)
	if l1lllll111l_l1_==l1l111_l1_ (u"ࠪࡥࡷ࠭⸲") or l1ll1_l1_==l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ⸳"):
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⸴")
		l1ll1l11l11_l1_ = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢะห้๐ษࠨ⸵")
		l1lllllllll_l1_ = l1l111_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣวาีหࠨ⸶")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤศฮฬะ์ࠪ⸷")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠩหฯࠥำ๊ࠡฤํࠤๆ๐ไๆࠩ⸸")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠪวๆ๊วๆࠩ⸹")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ⸺")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠬฮัศ็ฯࠫ⸻")
	elif l1lllll111l_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⸼") or l1ll1_l1_==l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ⸽"):
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡ࡫ࡱࠤࡸ࡯ࡴࡦࠩ⸾")
		l1ll1l11l11_l1_ = l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡈࡻࡲࡳࡧࡱࡸࠬ⸿")
		l1lllllllll_l1_ = l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡒࡡࡵࡧࡶࡸࠬ⹀")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡁ࡭ࡲ࡫ࡥࡧ࡫ࡴࠨ⹁")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠬࡒࡩࡷࡧࠣ࡭ࡋ࡯࡬࡮ࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪ⹂")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"࠭ࡍࡰࡸ࡬ࡩࡸ࠭⹃")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⹄")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠨࡕ࡫ࡳࡼࡹࠧ⹅")
	elif l1lllll111l_l1_ in [l1l111_l1_ (u"ࠩࡩࡥࠬ⹆"),l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⹇")]:
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ࠫัูสอ๊ࠣำึࠦำศ໎อࠫ⹈")
		l1ll1l11l11_l1_ = l1l111_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦฬศำ໏ࠫ⹉")
		l1lllllllll_l1_ = l1l111_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠระิ໐๋࠭⹊")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠧิำํห้ࠦ࠭ࠡษ็ๅออࠧ⹋")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠨ຀ัุุࠥๆะ้ࠣห๏ࠦแ๋ๆ่ࠫ⹌")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠩไ๎้๋ࠧ⹍")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"้ࠪํู๊ใ๋ࠪ⹎")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠫอืๆศ็๊ࠤ์อࠧ⹏")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹐"),l1lllll_l1_+l1ll1l11l1l_l1_,l1ll1ll11l1_l1_,29,l1l111_l1_ (u"࠭ࠧ⹑"),l1l111_l1_ (u"ࠧࠨ⹒"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⹓"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⹔"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⹕")+l1lllll_l1_+l1ll1l1l111_l1_,l1ll1ll11l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⹖"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⹗"),l1l111_l1_ (u"࠭ࠧ⹘"),9999)
	l1llll1ll1l_l1_ = [l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⹙"),l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⹚"),l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⹛")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩ⹜"),l1l111_l1_ (u"ࠫࠬ⹝"),l1l111_l1_ (u"ࠬ࠭⹞"),l1l111_l1_ (u"࠭ࠧ⹟"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⹠"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨࡤࡸࡸࡹࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬ࠳ࡈࡵ࡮ࡵࡣࡦࡸࠬ⹡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⹢"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if any(value in l1ll1ll_l1_ for value in l1llll1ll1l_l1_):
				url = l1ll1ll11l1_l1_+l1ll1ll_l1_
				if l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⹣") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹤"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⹥")+l1lllll_l1_+l1ll1l11l11_l1_,url,22,l1l111_l1_ (u"࠭ࠧ⹦"),l1l111_l1_ (u"ࠧ࠲࠲࠳ࠫ⹧"))
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹨"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⹩")+l1lllll_l1_+l1lllllllll_l1_,url,22,l1l111_l1_ (u"ࠪࠫ⹪"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⹫"))
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹬"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⹭")+l1lllll_l1_+l1ll1l11ll1_l1_,url,22,l1l111_l1_ (u"ࠧࠨ⹮"),l1l111_l1_ (u"ࠨ࠴࠳࠵ࠬ⹯"))
				elif l1l111_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⹰") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹱"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⹲")+l1lllll_l1_+l1ll1l11lll_l1_,url,22,l1l111_l1_ (u"ࠬ࠭⹳"),l1l111_l1_ (u"࠭࠱࠱࠲ࠪ⹴"))
				elif l1l111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⹵") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹶"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⹷")+l1lllll_l1_+l1ll1l1l1l1_l1_,url,25,l1l111_l1_ (u"ࠪࠫ⹸"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⹹"))
				elif l1l111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⹺") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹻"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⹼")+l1lllll_l1_+l1ll1l1l11l_l1_,url,22,l1l111_l1_ (u"ࠨࠩ⹽"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⹾"))
	return html
def l1ll1l111ll_l1_(url):
	l1ll1ll11l1_l1_ = l1ll1l1l1ll_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ⹿"),l1l111_l1_ (u"ࠫࠬ⺀"),l1l111_l1_ (u"ࠬ࠭⺁"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡕࡔࡋࡆࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⺂"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠳ࡴࡰࡱ࡯ࡷ࠲࡮ࡥࡢࡦࡨࡶ࠭࠴ࠪࡀࠫࡐࡹࡸ࡯ࡣ࠮ࡤࡲࡨࡾ࠭⺃"),html,re.DOTALL)
	block = l11llll_l1_[0]
	title = re.findall(l1l111_l1_ (u"ࠨ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ⺄"),block,re.DOTALL)[0]
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺅"),l1lllll_l1_+title,url,22,l1l111_l1_ (u"ࠪࠫ⺆"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⺇"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⺈"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l1ll1ll11l1_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺉"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1l111_l1_ (u"ࠧࠨ⺊"),l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⺋"))
	return
def l1lll11_l1_(url,l1llllll1_l1_):
	l1ll1ll11l1_l1_ = l1ll1l1l1ll_l1_(url)
	l1lllll111l_l1_ = l1ll1ll1l11_l1_(url)
	type = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ⺌"))[-1]
	l1ll1l11111_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	if type==l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⺍") and l1llllll1_l1_==l1l111_l1_ (u"ࠫ࠵࠭⺎"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭⺏"),l1l111_l1_ (u"࠭ࠧ⺐"),l1l111_l1_ (u"ࠧࠨ⺑"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⺒"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨ⺓"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠪ࠱࠮ࡄ࠯࠾࠯ࠬࡂ࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⺔"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1ll1ll_l1_ = l1ll1ll11l1_l1_ + l1ll1ll_l1_
			l1ll1l_l1_ = l1ll1ll11l1_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺕"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l11111_l1_+l1l111_l1_ (u"ࠬ࠶࠱ࠨ⺖"))
	l1ll1l1111l_l1_=0
	if type==l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⺗"): category=l1l111_l1_ (u"ࠧ࠴ࠩ⺘")
	if type==l1l111_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⺙"): category=l1l111_l1_ (u"ࠩ࠸ࠫ⺚")
	if type==l1l111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⺛"): category=l1l111_l1_ (u"ࠫ࠼࠭⺜")
	if type in [l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⺝"),l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⺞"),l1l111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⺟")] and l1llllll1_l1_!=l1l111_l1_ (u"ࠨ࠲ࠪ⺠"):
		l1lllll1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡒࡤ࡫ࡪ࡯࡮ࡨࡋࡷࡩࡲࡅࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ⺡")+category+l1l111_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⺢")+l1llllll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬ࡯ࡳࡦࡨࡶࡧࡿ࠽ࠨ⺣")+l1ll1l11111_l1_
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⺤"),l1l111_l1_ (u"࠭ࠧ⺥"),l1l111_l1_ (u"ࠧࠨ⺦"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⺧"))
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡍࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲࠮ࠬࡁࠥࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⺨"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭⺩"),l1l111_l1_ (u"ࠫࠬ⺪"))
			title = title.replace(l1l111_l1_ (u"ࠬࠨࠧ⺫"),l1l111_l1_ (u"࠭ࠧ⺬"))
			l1ll1l1111l_l1_ += 1
			l1ll1ll_l1_ = l1ll1ll11l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࠩ⺭") + type + l1l111_l1_ (u"ࠨ࠱ࡆࡳࡳࡺࡥ࡯ࡶ࠲ࠫ⺮") + id
			l1ll1l_l1_ = l1ll1ll11l1_l1_ + QUOTE(l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⺯"): addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⺰"),l1lllll_l1_+title,l1ll1ll_l1_,24,l1ll1l_l1_,l1ll1l11111_l1_+l1l111_l1_ (u"ࠫ࠵࠷ࠧ⺱"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺲"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l11111_l1_+l1l111_l1_ (u"࠭࠰࠲ࠩ⺳"))
	if type==l1l111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⺴"):
		html = l1l1llll_l1_(l11l1l1_l1_,l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡋࡱࡨࡪࡾ࠿ࡱࡣࡪࡩࡂ࠭⺵")+l1llllll1_l1_,l1l111_l1_ (u"ࠩࠪ⺶"),l1l111_l1_ (u"ࠪࠫ⺷"),l1l111_l1_ (u"ࠫࠬ⺸"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠸ࡸࡤࠨ⺹"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ࠰ࡨࡪࡳ࡯ࠩ࠰࠭ࡃ࠮ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯࠯ࡧࡩࡲࡵࠧ⺺"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩ⺻"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1ll1ll11l1_l1_ + l1ll1l_l1_
			l1ll1ll_l1_ = l1ll1ll11l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⺼"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⺽"))
	if l1ll1l1111l_l1_>20:
		title=l1l111_l1_ (u"ูࠪๆำษࠡࠩ⺾")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠫࡪࡴࠧ⺿"): title = l1l111_l1_ (u"ࠬࡖࡡࡨࡧࠣࠫ⻀")
		if l1lllll111l_l1_==l1l111_l1_ (u"࠭ࡦࡢࠩ⻁"): title = l1l111_l1_ (u"ࠧึใะ๋ࠥ࠭⻂")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⻃"): title = l1l111_l1_ (u"ุࠩๅาํࠠࠨ⻄")
		for l1ll1l1ll1l_l1_ in range(1,11) :
			if not l1llllll1_l1_==str(l1ll1l1ll1l_l1_):
				l1ll1l111l1_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ⻅")+str(l1ll1l1ll1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻆"),l1lllll_l1_+title+str(l1ll1l1ll1l_l1_),url,22,l1l111_l1_ (u"ࠬ࠭⻇"),l1ll1l11111_l1_+l1ll1l111l1_l1_[-2:])
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	if not l1llllll1_l1_: l1llllll1_l1_ = 0
	l1ll1ll11l1_l1_ = l1ll1l1l1ll_l1_(url)
	l1ll1ll11ll_l1_ = l1ll1l1l1ll_l1_(url)
	l1lllll111l_l1_ = l1ll1ll1l11_l1_(url)
	parts = url.split(l1l111_l1_ (u"࠭࠯ࠨ⻈"))
	id,type = parts[-1],parts[3]
	l1ll1l11111_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	l1ll1l1111l_l1_ = 0
	if type==l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⻉"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ⻊"),l1l111_l1_ (u"ࠩࠪ⻋"),l1l111_l1_ (u"ࠪࠫ⻌"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⻍"))
		items = re.findall(l1l111_l1_ (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡥࡰࡢࡰࡨࡰࡤࡏࡴࡦ࡯࠱࠮ࡄࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࡩ࠯࠭ࡂࡺࡦࡸࠠࡪࡰࡷࡩࡷࡥࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨࠩ⻎"),html,re.DOTALL)
		title = l1l111_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ⻏")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠧࡦࡰࠪ⻐"): title = l1l111_l1_ (u"ࠨࠢ࠰ࠤࡊࡶࡩࡴࡱࡧࡩࠥ࠭⻑")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠩࡩࡥࠬ⻒"): title = l1l111_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ⻓")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⻔"): title = l1l111_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ⻕")
		if l1lllll111l_l1_==l1l111_l1_ (u"࠭ࡦࡢࠩ⻖"): l1ll1ll1111_l1_ = l1l111_l1_ (u"ࠧࠨ⻗")
		else: l1ll1ll1111_l1_ = l1lllll111l_l1_
		l1ll1ll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ⻘"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1ll1ll_l1_ in items:
			for l1l1lll_l1_ in range(int(count),0,-1):
				l1ll1ll1l1l_l1_ = l1ll1l_l1_ + l1ll1ll1111_l1_ + id + l1l111_l1_ (u"ࠩ࠲ࠫ⻙") + str(l1l1lll_l1_) + l1l111_l1_ (u"ࠪ࠲ࡵࡴࡧࠨ⻚")
				l1ll1l11l11_l1_ = name + title + str(l1l1lll_l1_)
				l1ll1l11l11_l1_ = unescapeHTML(l1ll1l11l11_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⻛"),l1lllll_l1_+l1ll1l11l11_l1_,url,24,l1ll1ll1l1l_l1_,l1l111_l1_ (u"ࠬ࠭⻜"),str(l1l1lll_l1_))
	elif type==l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⻝"):
		l1lllll1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡊࡲࡱࡪ࠵ࡐࡢࡩࡨ࡭ࡳ࡭ࡁࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡌࡸࡪࡳ࠿ࡪࡦࡀࠫ⻞")+str(id)+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ⻟")+l1llllll1_l1_+l1l111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡴࡸࡤࡦࡴࡥࡽࡂ࠷ࠧ⻠")
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⻡"),l1l111_l1_ (u"ࠫࠬ⻢"),l1l111_l1_ (u"ࠬ࠭⻣"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ⻤"))
		items = re.findall(l1l111_l1_ (u"ࠧࡆࡲ࡬ࡷࡴࡪࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡊࡩࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡄࡣࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⻥"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤࠬ⻦")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⻧"): title = l1l111_l1_ (u"ࠪࠤ࠲ࠦࡅࡱ࡫ࡶࡳࡩ࡫ࠠࠨ⻨")
		if l1lllll111l_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⻩"): title = l1l111_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ⻪")
		if l1lllll111l_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⻫"): title = l1l111_l1_ (u"ࠧࠡ࠯ࠣๆุ๋สࠡࠩ⻬")
		for l1l1lll_l1_,l1ll1l_l1_,l1ll1ll_l1_,desc,name in items:
			l1ll1l1111l_l1_ += 1
			l1ll1ll1l1l_l1_ = l1ll1ll11ll_l1_ + QUOTE(l1ll1l_l1_)
			name = escapeUNICODE(name)
			l1ll1l11l11_l1_ = name + title + str(l1l1lll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⻭"),l1lllll_l1_+l1ll1l11l11_l1_,l1lllll1_l1_,24,l1ll1ll1l1l_l1_,l1l111_l1_ (u"ࠩࠪ⻮"),str(l1ll1l1111l_l1_))
	elif type==l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⻯"):
		if l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸࠬ⻰") in url and l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⻱") not in url:
			l1lllll1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽ࠨ⻲")+str(id)+l1l111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ⻳")+l1llllll1_l1_+l1l111_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠲ࠪ⻴")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⻵"),l1l111_l1_ (u"ࠪࠫ⻶"),l1l111_l1_ (u"ࠫࠬ⻷"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠳ࡳࡦࠪ⻸"))
			items = re.findall(l1l111_l1_ (u"࠭ࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡛ࡵࡩࡤࡧࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡄࡣࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯࡙ࠦ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⻹"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l1111l_l1_ += 1
				l1ll1ll1l1l_l1_ = l1ll1ll11ll_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11l11_l1_ = name + l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ⻺") + title
				l1ll1l11l11_l1_ = l1ll1l11l11_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ⻻"))
				l1ll1l11l11_l1_ = escapeUNICODE(l1ll1l11l11_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⻼"),l1lllll_l1_+l1ll1l11l11_l1_,l1lllll1_l1_,24,l1ll1ll1l1l_l1_,l1l111_l1_ (u"ࠪࠫ⻽"),str(l1ll1l1111l_l1_))
		elif l1l111_l1_ (u"ࠫࡈࡲࡩࡱࡵࠪ⻾") in url:
			l1lllll1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃ࠰ࠧࡲࡤ࡫ࡪࡃࠧ⻿")+l1llllll1_l1_+l1l111_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠱࠶ࠩ⼀")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⼁"),l1l111_l1_ (u"ࠨࠩ⼂"),l1l111_l1_ (u"ࠩࠪ⼃"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠹ࡺࡨࠨ⼄"))
			items = re.findall(l1l111_l1_ (u"ࠫࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗ࡫ࡧࡩࡴࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⼅"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
				l1ll1l1111l_l1_ += 1
				l1ll1ll1l1l_l1_ = l1ll1ll11ll_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11l11_l1_ = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⼆"))
				l1ll1l11l11_l1_ = escapeUNICODE(l1ll1l11l11_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⼇"),l1lllll_l1_+l1ll1l11l11_l1_,l1lllll1_l1_,24,l1ll1ll1l1l_l1_,l1l111_l1_ (u"ࠧࠨ⼈"),str(l1ll1l1111l_l1_))
		elif l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⼉") in url:
			if l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠻࠭⼊") in url:
				l1lllll1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡋࡪࡺࡔࡳࡣࡦ࡯ࡸࡈࡹࡀ࡫ࡧࡁ࠵ࠬࡰࡢࡩࡨࡁࠬ⼋")+l1llllll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠻࠭⼌")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⼍"),l1l111_l1_ (u"࠭ࠧ⼎"),l1l111_l1_ (u"ࠧࠨ⼏"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠸ࡸ࡭࠭⼐"))
			elif l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠹࠭⼑") in url:
				l1lllll1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡋࡪࡺࡔࡳࡣࡦ࡯ࡸࡈࡹࡀ࡫ࡧࡁ࠵ࠬࡰࡢࡩࡨࡁࠬ⼒")+l1llllll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠹࠭⼓")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⼔"),l1l111_l1_ (u"࠭ࠧ⼕"),l1l111_l1_ (u"ࠧࠨ⼖"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠹ࡸ࡭࠭⼗"))
			items = re.findall(l1l111_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⼘"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l1111l_l1_ += 1
				l1ll1ll1l1l_l1_ = l1ll1ll11ll_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11l11_l1_ = name + l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ⼙") + title
				l1ll1l11l11_l1_ = l1ll1l11l11_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭⼚"))
				l1ll1l11l11_l1_ = escapeUNICODE(l1ll1l11l11_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⼛"),l1lllll_l1_+l1ll1l11l11_l1_,l1lllll1_l1_,24,l1ll1ll1l1l_l1_,l1l111_l1_ (u"࠭ࠧ⼜"),str(l1ll1l1111l_l1_))
	if type==l1l111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⼝") or type==l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⼞"):
		if l1ll1l1111l_l1_>25:
			title=l1l111_l1_ (u"ุࠩๅาฯࠠࠨ⼟")
			if l1lllll111l_l1_==l1l111_l1_ (u"ࠪࡩࡳ࠭⼠"): title = l1l111_l1_ (u"ࠫࠥࡖࡡࡨࡧࠣࠫ⼡")
			if l1lllll111l_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⼢"): title = l1l111_l1_ (u"࠭ࠠึใะ๋ࠥ࠭⼣")
			if l1lllll111l_l1_==l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⼤"): title = l1l111_l1_ (u"ࠨุࠢๅาํࠠࠨ⼥")
			for l1ll1l1ll1l_l1_ in range(1,11):
				if not l1llllll1_l1_==str(l1ll1l1ll1l_l1_):
					l1ll1l111l1_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ⼦")+str(l1ll1l1ll1l_l1_)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼧"),l1lllll_l1_+title+str(l1ll1l1ll1l_l1_),url,23,l1l111_l1_ (u"ࠫࠬ⼨"),l1ll1l11111_l1_+l1ll1l111l1_l1_[-2:])
	return
def PLAY(url,l1l1lll_l1_):
	l1ll1ll11ll_l1_ = l1ll1l1l1ll_l1_(url)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭⼩"),l1l111_l1_ (u"࠭ࠧ⼪"),l1l111_l1_ (u"ࠧࠨ⼫"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⼬"))
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡷ࡫ࡧࡩࡴࡃࠢࠩ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭࡟ࠪࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ⼭"),html,re.DOTALL)
	if items:
		l1lllll111l_l1_ = l1ll1ll1l11_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ⼮"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll111l_l1_+id+l1l111_l1_ (u"ࠫ࠴࠲ࠧ⼯")+l1l1lll_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ⼰")+l1l1lll_l1_+l1l111_l1_ (u"࠭࡟ࠨ⼱")+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠬ⼲"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨ࡝ࠩ࠱࠮ࡄࡢࠧࠪࠪ࡟࠲࠳࠰࠿ࠪࠤࠪ⼳"),html,re.DOTALL)
	if items:
		l1lllll111l_l1_ = l1ll1ll1l11_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ⼴"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll111l_l1_+id+l1l111_l1_ (u"ࠪ࠳ࠬ⼵")+l1l1lll_l1_+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠴ࠡࡷࡵࡰࠬ⼶"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⼷"),html,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࠯࠰ࠩ⼸"),l1l111_l1_ (u"ࠧ࠰ࠩ⼹"))
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࡹࡲࡤࠩ⼺"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⼻"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll11ll_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠠࡢࡦࡧࡶࡪࡹࡳࠨ⼼"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࡛ࠫࡵࡩࡤࡧࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⼽"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll11ll_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࡳࡰ࠴ࠢࡤࡨࡩࡸࡥࡴࡵࠪ⼾"))
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==1: l1ll1ll_l1_ = l1llll_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ⼿"), l1l1lll1_l1_)
		if l11l11l_l1_ == -1 : return
		l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⽀"))
	return
def l1ll1l1l1ll_l1_(url):
	if l111l1_l1_ in url: l1lll11l1ll_l1_ = l111l1_l1_
	elif l1l1l1ll1l_l1_ in url: l1lll11l1ll_l1_ = l1l1l1ll1l_l1_
	elif l1ll1l1ll11_l1_ in url: l1lll11l1ll_l1_ = l1ll1l1ll11_l1_
	elif l1ll1l1lll1_l1_ in url: l1lll11l1ll_l1_ = l1ll1l1lll1_l1_
	else: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ⽁")
	return l1lll11l1ll_l1_
def l1ll1ll1l11_l1_(url):
	if   l111l1_l1_ in url: l1lllll111l_l1_ = l1l111_l1_ (u"ࠩࡤࡶࠬ⽂")
	elif l1l1l1ll1l_l1_ in url: l1lllll111l_l1_ = l1l111_l1_ (u"ࠪࡩࡳ࠭⽃")
	elif l1ll1l1ll11_l1_ in url: l1lllll111l_l1_ = l1l111_l1_ (u"ࠫ࡫ࡧࠧ⽄")
	elif l1ll1l1lll1_l1_ in url: l1lllll111l_l1_ = l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⽅")
	else: l1lllll111l_l1_ = l1l111_l1_ (u"࠭ࠧ⽆")
	return l1lllll111l_l1_
def l1ll1llll_l1_(url):
	l1lllll111l_l1_ = l1ll1ll1l11_l1_(url)
	l1lllll1_l1_ = url + l1l111_l1_ (u"ࠧ࠰ࡊࡲࡱࡪ࠵ࡌࡪࡸࡨࠫ⽇")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⽈"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⽉"),l1l111_l1_ (u"ࠪࠫ⽊"),l1l111_l1_ (u"ࠫࠬ⽋"),l1l111_l1_ (u"ࠬ࠭⽌"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧ⽍"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⽎"),html,re.DOTALL)
	l1llllll_l1_ = items[0]
	l1llll111_l1_(l1llllll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⽏"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ⽐"),l1l111_l1_ (u"ࠪ࠯ࠬ⽑"))
	if l11_l1_:
		l11111l11_l1_ = [ l111l1_l1_ , l1l1l1ll1l_l1_ , l1ll1l1ll11_l1_ , l1ll1l1lll1_l1_ ]
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠫ฾ืศ๋ࠩ⽒") , l1l111_l1_ (u"ࠬࡋ࡮ࡨ࡮࡬ࡷ࡭࠭⽓") , l1l111_l1_ (u"࠭แศำึํࠬ⽔") , l1l111_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ⽕") ]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅๆ฽อࠥอไๆ่สือฯ࠺ࠨ⽖"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		l1l11l11_l1_ = l11111l11_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠩࡢࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࡡࠪ⽗") in options: l1l11l11_l1_ = l111l1_l1_
		elif l1l111_l1_ (u"ࠪࡣࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࡣࠬ⽘") in options: l1l11l11_l1_ = l1l1l1ll1l_l1_
		else: l1l11l11_l1_ = l1l111_l1_ (u"ࠫࠬ⽙")
	if not l1l11l11_l1_: return
	l1lllll111l_l1_ = l1ll1ll1l11_l1_(l1l11l11_l1_)
	l1lllll1_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠧ࠵ࡈࡰ࡯ࡨ࠳ࡘ࡫ࡡࡳࡥ࡫ࡃࡸ࡫ࡡࡳࡥ࡫ࡷࡹࡸࡩ࡯ࡩࡀࠦ⽚") + l1lll1ll_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⽛"),l1l111_l1_ (u"ࠧࠨ⽜"),l1l111_l1_ (u"ࠨࠩ⽝"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ⽞"))
	items = re.findall(l1l111_l1_ (u"ࠪࠦࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡇࡦࡺࡥࡨࡱࡵࡽࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡋࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠧ⽟"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			if category in [l1l111_l1_ (u"ࠫ࠸࠭⽠"),l1l111_l1_ (u"ࠬ࠽ࠧ⽡")]:
				title = title.replace(l1l111_l1_ (u"࠭࡜࡝ࠩ⽢"),l1l111_l1_ (u"ࠧࠨ⽣"))
				title = title.replace(l1l111_l1_ (u"ࠨࠤࠪ⽤"),l1l111_l1_ (u"ࠩࠪ⽥"))
				if category==l1l111_l1_ (u"ࠪ࠷ࠬ⽦"):
					type = l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⽧")
					if l1lllll111l_l1_==l1l111_l1_ (u"ࠬࡧࡲࠨ⽨"): name = l1l111_l1_ (u"࠭ๅิๆึ่ࠥࡀࠠࠨ⽩")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠧࡦࡰࠪ⽪"): name = l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠼ࠣࠫ⽫")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠩࡩࡥࠬ⽬"): name = l1l111_l1_ (u"ࠪืึ๐วๅ๊ࠢหࠥࡀࠠࠨ⽭")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⽮"): name = l1l111_l1_ (u"ูࠬั๋ษ็ࠤ์อࠠ࠻ࠢࠪ⽯")
				elif category==l1l111_l1_ (u"࠭࠵ࠨ⽰"):
					type = l1l111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⽱")
					if l1lllll111l_l1_==l1l111_l1_ (u"ࠨࡣࡵࠫ⽲"): name = l1l111_l1_ (u"ࠩไ๎้๋ࠠ࠻ࠢࠪ⽳")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠪࡩࡳ࠭⽴"): name = l1l111_l1_ (u"ࠫࡒࡵࡶࡪࡧࠣ࠾ࠥ࠭⽵")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⽶"): name = l1l111_l1_ (u"࠭แ๋ๆ่ࠤ࠿ࠦࠧ⽷")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⽸"): name = l1l111_l1_ (u"ࠨใ็้ࠥํวࠡ࠼ࠣࠫ⽹")
				elif category==l1l111_l1_ (u"ࠩ࠺ࠫ⽺"):
					type = l1l111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⽻")
					if l1lllll111l_l1_==l1l111_l1_ (u"ࠫࡦࡸࠧ⽼"): name = l1l111_l1_ (u"ࠬฮั็ษ่ะࠥࡀࠠࠨ⽽")
					elif l1lllll111l_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⽾"): name = l1l111_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠡ࠼ࠣࠫ⽿")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⾀"): name = l1l111_l1_ (u"ࠩหี๋อๅ่๊ࠢหࠥࡀࠠࠨ⾁")
					elif l1lllll111l_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⾂"): name = l1l111_l1_ (u"ࠫอืๆศ็๊ࠤ์อࠠ࠻ࠢࠪ⾃")
				title = name + title
				l1ll1ll_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠬ࠵ࠧ⾄") + type + l1l111_l1_ (u"࠭࠯ࡄࡱࡱࡸࡪࡴࡴ࠰ࠩ⾅") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11l11_l1_+l1ll1l_l1_
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⾆"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⾇"))
	return
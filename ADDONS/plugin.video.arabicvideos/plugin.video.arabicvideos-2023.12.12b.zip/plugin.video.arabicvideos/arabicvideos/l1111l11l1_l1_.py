# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࠫ⭿")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡈࡎࡖࡣࠬ⮀")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll1l1l1l_l1_(text)
	elif mode==542: l1lll_l1_ = l1lll11l111_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮁"),l1l111_l1_ (u"ࠨสะฯࠥาฯ๋ัࠪ⮂"),l1l111_l1_ (u"ࠩࠪ⮃"),549)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⮄"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࠤ่๊ๅศฬ้ࠣำุๆสࠢࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⮅"),l1l111_l1_ (u"ࠬ࠭⮆"),9999)
	l1lll1l111l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ⮇"),l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮈"))
	if l1lll1l111l_l1_:
		l1lll1l111l_l1_ = l1lll1l111l_l1_[l1l111_l1_ (u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ⮉")]
		for search in reversed(l1lll1l111l_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮊"),search,l1l111_l1_ (u"ࠪࠫ⮋"),549,l1l111_l1_ (u"ࠫࠬ⮌"),l1l111_l1_ (u"ࠬ࠭⮍"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111l1lll_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"࠭ࠧ⮎"))
	l1lll111111_l1_(l1111l1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⮏"),l1l111_l1_ (u"ࠨ฻่่ࠥฮอฬࠢฯ้ฬ฿๊ࠡ࠯ࠣࠫ⮐")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⮑"),542,l1l111_l1_ (u"ࠪࠫ⮒"),l1l111_l1_ (u"ࠫࠬ⮓"),l1111l1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⮔"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⮕"),l1l111_l1_ (u"ࠧࠨ⮖"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮗"),l1l111_l1_ (u"้ࠩฮฬฬฬࠡษ็ฬาัࠠๆใุ่ฮࠦ࠭ࠡࠩ⮘")+l1111l1lll_l1_,l1l111_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮙"),542,l1l111_l1_ (u"ࠫࠬ⮚"),l1l111_l1_ (u"ࠬ࠭⮛"),l1111l1lll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⮜"),l1l111_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥโิ็ฬࠤ࠲ࠦࠧ⮝")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⮞"),542,l1l111_l1_ (u"ࠩࠪ⮟"),l1l111_l1_ (u"ࠪࠫ⮠"),l1111l1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⮡"),l1l111_l1_ (u"ࠬฮอฬ่๊ࠢๆืฯࠡ࠯ࠣࠫ⮢")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧ⮣"),541,l1l111_l1_ (u"ࠧࠨ⮤"),l1l111_l1_ (u"ࠨࠩ⮥"),l1111l1lll_l1_)
	return
def l1lll111111_l1_(l1lll1ll1ll_l1_):
	l1lll1lll1l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮦"),l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⮧"),l1lll1ll1ll_l1_)
	l1lll1lll11_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮨"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮩"),l1lllll_l1_+l1lll1ll1ll_l1_)
	l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮪"),l1lll1ll1ll_l1_)
	l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮫"),l1lllll_l1_+l1lll1ll1ll_l1_)
	old_value = l1lll1lll1l_l1_+l1lll1lll11_l1_
	if old_value: l1lll1ll1ll_l1_ = l1lllll_l1_+l1lll1ll1ll_l1_
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮬"),l1lll1ll1ll_l1_,old_value,l1lll11ll11_l1_)
	return
def l1lll111l11_l1_():
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠩࠪ⮭"),l1l111_l1_ (u"ࠪࠫ⮮"),l1l111_l1_ (u"ࠫࠬ⮯"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⮰"),l1l111_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪ⮱"))
	if l1llll1l11_l1_!=1: return
	l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮲"))
	l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⮳"))
	l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨ⮴"))
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ⮵"),l1l111_l1_ (u"ࠫࠬ⮶"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⮷"),l1l111_l1_ (u"࠭สๆࠢห๊ัออࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠧ⮸"))
	return
def l1lll11l111_l1_(l1lll111l1l_l1_,action,l1lll11l1ll_l1_=l1l111_l1_ (u"ࠧࠨ⮹")):
	l1lll11ll1l_l1_,l1lll11lll1_l1_,l1lll1l11l1_l1_,l1ll1lll11l_l1_,l1ll1llll11_l1_,l1ll1lll1ll_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⮺"):
		if action==l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⮻"): l1lll1l11l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⮼"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮽"),l1lllll_l1_+l1lll111l1l_l1_)
		elif action==l1l111_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫ⮾"): l1lll1l11l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ⮿"),l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭⯀"),l1lll111l1l_l1_)
		elif action==l1l111_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⯁"): l1lll1l11l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⯂"),l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⯃"),(l1lll11l1ll_l1_,l1lll111l1l_l1_))
	if not l1lll1l11l1_l1_:
		l1lll1l1ll1_l1_ = l1l111_l1_ (u"ࠫ์ึวࠡษ็ฬาัࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰ࡟ࡲࠬ⯄")
		l1lll1l1lll_l1_ = l1l111_l1_ (u"ࠬํไࠡฬิ๎ิࠦวๅฤ้ࠤฬ๊ศฮอࠣๅ๏ࠦฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥ฿ๆࠡ࡞ࡱࠤࠧࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡࠩ⯅")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࠣࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊ศฮอࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠨ⯆")
		if action==l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⯇"): message = l1lll1l1lll_l1_
		else: message = l1lll1l1ll1_l1_+l1lll1l1lll_l1_
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠨࠩ⯈"),l1l111_l1_ (u"ࠩࠪ⯉"),l1l111_l1_ (u"ࠪࠫ⯊"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⯋"),message)
		if l1llll1l11_l1_!=1: return
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⯌"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪ⯍")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ⯎"))
		import threading
		l1llll111l1_l1_ = 1
		for l1lll11l1ll_l1_ in l1lll1l1111_l1_:
			l1ll1lll11l_l1_[l1lll11l1ll_l1_] = []
			options = l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭⯏")
			if l1l111_l1_ (u"ࠩ࠰ࠫ⯐") in l1lll11l1ll_l1_: options = options+l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࠨ⯑")+l1lll11l1ll_l1_+l1l111_l1_ (u"ࠫࡤ࠭⯒")
			l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
			if l1llll111l1_l1_:
				time.sleep(0.5)
				threads[l1lll11l1ll_l1_] = threading.Thread(target=l1lll11l1l1_l1_,args=(l1lll111l1l_l1_+options,))
				threads[l1lll11l1ll_l1_].start()
			else: l1lll11l1l1_l1_(l1lll111l1l_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1lll11l1ll_l1_),l1l111_l1_ (u"ࠬ࠭⯓"),time=1000)
		if l1llll111l1_l1_:
			time.sleep(2)
			for l1lll11l1ll_l1_ in l1lll1l1111_l1_:
				threads[l1lll11l1ll_l1_].join(10)
			time.sleep(2)
		for l1lll11l1ll_l1_ in l1lll1l1111_l1_:
			l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
			for l1lll111lll_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = l1lll111lll_l1_
				if l1llll1111l_l1_ in name:
					if l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࠬ⯔") in l1lll11l1ll_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ⯕")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⯖")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯗")]: continue
						if l1l111_l1_ (u"ูࠪๆำษࠨ⯘") not in name:
							if   type==l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⯙"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⯚")
							elif type==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⯛"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⯜")
							elif type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯝"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯞")
						else:
							if   l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ⯟") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⯠")
							elif l1l111_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ⯡") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ⯢")
							elif l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ⯣") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭⯤")
					elif l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࠧ⯥") in l1lll11l1ll_l1_ and 729>=mode>=710:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬ⯦")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⯧")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ⯨")]: continue
						if l1l111_l1_ (u"࠭ีโฯฬࠫ⯩") not in name:
							if   type==l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⯪"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ⯫")
							elif type==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⯬"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯭")
							elif type==l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯮"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ⯯")
						else:
							if   l1l111_l1_ (u"࠭ࡌࡊࡘࡈࠫ⯰") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⯱")
							elif l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡋࡓࠨ⯲") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭⯳")
							elif l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ⯴") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ⯵")
					elif l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࠧ⯶") in l1lll11l1ll_l1_ and 149>=mode>=140:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⯷")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⯸")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ⯹")]: continue
						if l1l111_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ⯺") in name or l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ⯻") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"࡚࡙ࠫࡅࡓࠩ⯼") in name: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯽")
							elif mode==144 and l1l111_l1_ (u"࠭ࡃࡉࡐࡏࠫ⯾") in name: l1lll11l1ll_l1_ = l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯿")
							elif mode==144 and l1l111_l1_ (u"ࠨࡎࡌࡗ࡙࠭Ⰰ") in name: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭Ⰱ")
							elif mode==143: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫⰂ")
							else: continue
					elif l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࠪⰃ") in l1lll11l1ll_l1_ and 419>=mode>=400:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭Ⰴ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭Ⰵ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬⰆ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭Ⰷ")]: continue
						if   mode in [401,405]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪⰈ")
						elif mode in [402,406]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪⰉ")
						elif mode in [403,404]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩⰊ")
						elif mode in [412,413]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪⰋ")
					elif l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࠭Ⰼ") in l1lll11l1ll_l1_ and 39>=mode>=30:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭Ⰽ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰎ")]: continue
						if   mode in [32,39]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨⰏ")
						elif mode in [33,39]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩⰐ")
					elif l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࠫⰑ") in l1lll11l1ll_l1_ and 29>=mode>=20:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫⰒ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭Ⱃ")]: continue
						if   l1l111_l1_ (u"ࠧ࠰ࡣࡵ࠲ࠬⰔ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧⰕ")
						elif l1l111_l1_ (u"ࠩ࠲ࡩࡳ࠴ࠧⰖ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪⰗ")
					l1ll1lll11l_l1_[l1lll11l1ll_l1_].append(l1lll111lll_l1_)
		menuItemsLIST[:] = []
		for l1lll11l1ll_l1_ in list(l1ll1lll11l_l1_.keys()):
			l1ll1llll11_l1_[l1lll11l1ll_l1_] = []
			l1ll1lll1ll_l1_[l1lll11l1ll_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l1ll1lll11l_l1_[l1lll11l1ll_l1_]:
				l1lll111lll_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
				if l1l111_l1_ (u"ฺࠫ็อสࠩⰘ") in name and type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰙ"): l1ll1lll1ll_l1_[l1lll11l1ll_l1_].append(l1lll111lll_l1_)
				else: l1ll1llll11_l1_[l1lll11l1ll_l1_].append(l1lll111lll_l1_)
		l1lll1l1l11_l1_ = [(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⰚ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰛ"),l1l111_l1_ (u"ࠨࠩⰜ"),157,l1l111_l1_ (u"ࠩࠪⰝ"),l1l111_l1_ (u"ࠪࠫⰞ"),l1l111_l1_ (u"ࠫࠬⰟ"),l1l111_l1_ (u"ࠬ࠭Ⱐ"),l1l111_l1_ (u"࠭ࠧⰡ"))]
		for l1lll11l1ll_l1_ in l1lll11llll_l1_:
			if l1lll11l1ll_l1_==l1lll1111ll_l1_[0]: l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰢ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰣ"),l1l111_l1_ (u"ࠩࠪⰤ"),157,l1l111_l1_ (u"ࠪࠫⰥ"),l1l111_l1_ (u"ࠫࠬⰦ"),l1l111_l1_ (u"ࠬ࠭Ⱗ"),l1l111_l1_ (u"࠭ࠧⰨ"),l1l111_l1_ (u"ࠧࠨⰩ"))]
			elif l1lll11l1ll_l1_==l1lll1llll1_l1_[0]: l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⱚ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰫ"),l1l111_l1_ (u"ࠪࠫⰬ"),157,l1l111_l1_ (u"ࠫࠬⰭ"),l1l111_l1_ (u"ࠬ࠭Ⱞ"),l1l111_l1_ (u"࠭ࠧⰯ"),l1l111_l1_ (u"ࠧࠨⰰ"),l1l111_l1_ (u"ࠨࠩⰱ"))]
			elif l1lll11l1ll_l1_==l1ll1lll1l1_l1_[0]: l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰲ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⰳ"),l1l111_l1_ (u"ࠫࠬⰴ"),157,l1l111_l1_ (u"ࠬ࠭ⰵ"),l1l111_l1_ (u"࠭ࠧⰶ"),l1l111_l1_ (u"ࠧࠨⰷ"),l1l111_l1_ (u"ࠨࠩⰸ"),l1l111_l1_ (u"ࠩࠪⰹ"))]
			if l1lll11l1ll_l1_ not in l1ll1llll11_l1_.keys(): continue
			if l1ll1llll11_l1_[l1lll11l1ll_l1_]:
				l1ll1llllll_l1_ = TRANSLATE(l1lll11l1ll_l1_)
				l1lll111ll1_l1_ = [(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰺ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࠥ࠭ⰻ")+l1ll1llllll_l1_+l1l111_l1_ (u"ࠬࠦ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⰼ"),l1l111_l1_ (u"࠭ࠧⰽ"),9999,l1l111_l1_ (u"ࠧࠨⰾ"),l1l111_l1_ (u"ࠨࠩⰿ"),l1l111_l1_ (u"ࠩࠪⱀ"),l1l111_l1_ (u"ࠪࠫⱁ"),l1l111_l1_ (u"ࠫࠬⱂ"))]
				if 0:
					l1lll1lllll_l1_ = l1lll111l1l_l1_+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩⱃ")+l1l111_l1_ (u"࠭ศฮอࠪⱄ")+l1l111_l1_ (u"ࠧࠡࠩⱅ")+l1ll1llllll_l1_
				else:
					l1lll1lllll_l1_ = l1l111_l1_ (u"ࠨสะฯࠬⱆ")+l1l111_l1_ (u"ࠩࠣࠫⱇ")+l1ll1llllll_l1_+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⱈ")+l1lll111l1l_l1_
				if len(l1ll1llll11_l1_[l1lll11l1ll_l1_])<8: l1lll1l11ll_l1_ = []
				else:
					l1llll11111_l1_ = l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧⱉ")+l1lll1lllll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱊ")
					l1lll1l11ll_l1_ = [(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱋ"),l1lllll_l1_+l1llll11111_l1_,l1l111_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱌ"),542,l1l111_l1_ (u"ࠨࠩⱍ"),l1lll11l1ll_l1_,l1lll111l1l_l1_,l1l111_l1_ (u"ࠩࠪⱎ"),l1l111_l1_ (u"ࠪࠫⱏ"))]
				l1lll1ll11l_l1_ = l1ll1llll11_l1_[l1lll11l1ll_l1_]+l1ll1lll1ll_l1_[l1lll11l1ll_l1_]
				l1lll11lll1_l1_ += l1lll1l1l11_l1_+l1lll111ll1_l1_+l1lll1ll11l_l1_[:7]+l1lll1l11ll_l1_
				l1ll1lllll1_l1_ = [(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱐ"),l1lllll_l1_+l1lll1lllll_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫⱑ"),542,l1l111_l1_ (u"࠭ࠧⱒ"),l1lll11l1ll_l1_,l1lll111l1l_l1_,l1l111_l1_ (u"ࠧࠨⱓ"),l1l111_l1_ (u"ࠨࠩⱔ"))]
				l1lll11ll1l_l1_ += l1lll1l1l11_l1_+l1ll1lllll1_l1_
				l1lll1l1l11_l1_ = []
				l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨⱕ"),(l1lll11l1ll_l1_,l1lll111l1l_l1_),l1lll1ll11l_l1_,l1lll11ll11_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩⱖ"),l1lll111l1l_l1_,l1lll11lll1_l1_,l1lll11ll11_l1_)
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩⱗ"),l1lll111l1l_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱘ"),l1lllll_l1_+l1lll111l1l_l1_,l1lll11ll1l_l1_,l1lll11ll11_l1_)
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧⱙ"),l1l111_l1_ (u"ࠧࠨⱚ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⱛ"),l1l111_l1_ (u"ࠩส่อำหࠡษ็ะ๊อู๋ࠢส๊ฯํ้ࠡส้ะฬำࠠ࡝ࡰ࡟ࡲࠥะๅࠡฬัึ๏์ࠠศๆ้ฮฬฬฬࠡใํࠤ่อิࠡษ็ฬึ์วๆฮ่๊ࠣีษࠡอ็หะ๐ๆࠡ์๋้๊ࠥใ๋ࠢอืฯ฽ฺ๊ࠢส่฾๎ฯสࠢศ่๏ํวࠡสา์ู๋ࠦๆๆࠣฬาัࠠอัํำࠬⱜ"))
		if action==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⱝ") and l1lll11ll1l_l1_: l1lll1l11l1_l1_ = l1lll11ll1l_l1_
		else: l1lll1l11l1_l1_ = l1lll11lll1_l1_
	if action!=l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪⱞ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l1lll1l11l1_l1_:
			if action in [l1l111_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⱟ"),l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬⱠ")] and l1l111_l1_ (u"ࠧึใะอࠬⱡ") in name and type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱢ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
	return
def l1lll1l1l1l_l1_(l1lll111l1l_l1_=l1l111_l1_ (u"ࠩࠪⱣ")):
	search,options,l11_l1_ = l111ll_l1_(l1lll111l1l_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪⱤ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨⱥ")+search+l1l111_l1_ (u"ࠬࠦ࡝ࠨⱦ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll1ll1l1_l1_,l1111l1lll_l1_ = search+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪⱧ"),l1l111_l1_ (u"ࠧࠨⱨ")
	else: l1lll1ll1l1_l1_,l1111l1lll_l1_ = l1l111_l1_ (u"ࠨࠩⱩ"),l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ⱪ")+search
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱫ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱬ"),l1l111_l1_ (u"ࠬ࠭Ɑ"),157)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ɱ"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭Ɐ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠨสะฯࠥࡓ࠳ࡖࠩⱰ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࠪⱱ"),719,l1l111_l1_ (u"ࠪࠫⱲ"),l1l111_l1_ (u"ࠫࠬⱳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱴ"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬⱵ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠧษฯฮࠤࡎࡖࡔࡗࠩⱶ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨࠩⱷ"),239,l1l111_l1_ (u"ࠩࠪⱸ"),l1l111_l1_ (u"ࠪࠫⱹ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱺ"),l1l111_l1_ (u"ࠬࡥࡂࡌࡔࡢࠫⱻ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสๆีฬ࠭ⱼ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨⱽ"),379,l1l111_l1_ (u"ࠨࠩⱾ"),l1l111_l1_ (u"ࠩࠪⱿ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲀ"),l1l111_l1_ (u"ࠫࡤࡑࡌࡂࡡࠪⲁ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠไๆࠣห้฿ัษࠩⲂ")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧⲃ"),19,l1l111_l1_ (u"ࠧࠨⲄ"),l1l111_l1_ (u"ࠨࠩⲅ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲆ"),l1l111_l1_ (u"ࠪࡣࡆࡘࡔࡠࠩⲇ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪⲈ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠬ࠭ⲉ"),739,l1l111_l1_ (u"࠭ࠧⲊ"),l1l111_l1_ (u"ࠧࠨⲋ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲌ"),l1l111_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨⲍ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪⲎ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬⲏ"),329,l1l111_l1_ (u"ࠬ࠭Ⲑ"),l1l111_l1_ (u"࠭ࠧⲑ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲒ"),l1l111_l1_ (u"ࠨࡡࡉࡌ࠶ࡥࠧⲓ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨⲔ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠪࠫⲕ"),579,l1l111_l1_ (u"ࠫࠬⲖ"),l1l111_l1_ (u"ࠬ࠭ⲗ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲙ"),l1l111_l1_ (u"ࠧࡠࡍࡗ࡚ࡤ࠭ⲙ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧⲚ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࠪⲛ"),819,l1l111_l1_ (u"ࠪࠫⲜ"),l1l111_l1_ (u"ࠫࠬⲝ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲞ"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠴ࡣࠬⲟ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠷ࠧⲠ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨࠩⲡ"),779,l1l111_l1_ (u"ࠩࠪⲢ"),l1l111_l1_ (u"ࠪࠫⲣ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲤ"),l1l111_l1_ (u"ࠬࡥࡅࡃ࠴ࡢࠫⲥ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭Ⲧ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨⲧ"),789,l1l111_l1_ (u"ࠨࠩⲨ"),l1l111_l1_ (u"ࠩࠪⲩ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲪ"),l1l111_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪⲫ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬࠦࠠษฯฮࠤ๊๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨⲬ")+l1111l1lll_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩⲭ"),l1l111_l1_ (u"ࠧࠨⲮ"),29,l1l111_l1_ (u"ࠨࠩⲯ"),l1l111_l1_ (u"ࠩࠪⲰ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲱ"),l1l111_l1_ (u"ࠫࡤࡇࡋࡐࡡࠪⲲ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅไา๎๊࠭ⲳ")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧⲴ"),79,l1l111_l1_ (u"ࠧࠨⲵ"),l1l111_l1_ (u"ࠨࠩⲶ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲷ"),l1l111_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩⲸ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬⲹ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠬ࠭Ⲻ"),249,l1l111_l1_ (u"࠭ࠧⲻ"),l1l111_l1_ (u"ࠧࠨⲼ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲽ"),l1l111_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨⲾ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫⲿ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬⳀ"),49,l1l111_l1_ (u"ࠬ࠭ⳁ"),l1l111_l1_ (u"࠭ࠧⳂ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳃ"),l1l111_l1_ (u"ࠨࡡࡖࡌࡒࡥࠧⳄ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭ⳅ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠪࠫⳆ"),59,l1l111_l1_ (u"ࠫࠬⳇ"),l1l111_l1_ (u"ࠬ࠭Ⳉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳉ"),l1l111_l1_ (u"ࠧࡠࡈࡗࡑࡤ࠭Ⳋ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห้๋ๆษำࠣห้็วุ็ํࠫⳋ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࠪⳌ"),69,l1l111_l1_ (u"ࠪࠫⳍ"),l1l111_l1_ (u"ࠫࠬⳎ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⳏ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮฺ่ࠦษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⳐ"),l1l111_l1_ (u"ࠧࠨⳑ"),157)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳒ"),l1l111_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨⳓ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪࠤอำหࠡ็๋ๆ฾ࠦแอำุࠣํ࠭Ⳕ")+l1111l1lll_l1_+l1l111_l1_ (u"ࠫࠥ࠭ⳕ"),l1l111_l1_ (u"ࠬ࠭Ⳗ"),399,l1l111_l1_ (u"࠭ࠧⳗ"),l1l111_l1_ (u"ࠧࠨⳘ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳙ"),l1l111_l1_ (u"ࠩࡢࡘ࡛ࡌ࡟ࠨⳚ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧⳛ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬⳜ"),469,l1l111_l1_ (u"ࠬ࠭ⳝ"),l1l111_l1_ (u"࠭ࠧⳞ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳟ"),l1l111_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧⳠ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬⳡ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠪࠫⳢ"),459,l1l111_l1_ (u"ࠫࠬⳣ"),l1l111_l1_ (u"ࠬ࠭ⳤ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⳥"),l1l111_l1_ (u"ࠧࡠࡅࡐࡒࡤ࠭⳦")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋ว่ࠡส์ࠬ⳧")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࠪ⳨"),309,l1l111_l1_ (u"ࠪࠫ⳩"),l1l111_l1_ (u"ࠫࠬ⳪"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳫ"),l1l111_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬⳬ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๋ࠢ๎ู๊ࠥๆษࠪⳭ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨࠩⳮ"),569,l1l111_l1_ (u"ࠩࠪ⳯"),l1l111_l1_ (u"ࠪࠫ⳰"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳱"),l1l111_l1_ (u"ࠬࡥࡓࡉࡐࡢࠫⳲ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦๆ๋๊ีࠫⳳ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨ⳴"),589,l1l111_l1_ (u"ࠨࠩ⳵"),l1l111_l1_ (u"ࠩࠪ⳶"),l1lll1ll_l1_+l1l111_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ⳷"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳸"),l1l111_l1_ (u"ࠬࡥࡁࡓࡕࡢࠫ⳹")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ฻ิฬู๊๋ࠥัࠪ⳺")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨ⳻"),259,l1l111_l1_ (u"ࠨࠩ⳼"),l1l111_l1_ (u"ࠩࠪ⳽"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳾"),l1l111_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪ⳿")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠪⴀ")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧⴁ"),829,l1l111_l1_ (u"ࠧࠨⴂ"),l1l111_l1_ (u"ࠨࠩⴃ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴄ"),l1l111_l1_ (u"ࠪࡣࡈ࠺ࡕࡠࠩⴅ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪⴆ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠬ࠭ⴇ"),429,l1l111_l1_ (u"࠭ࠧⴈ"),l1l111_l1_ (u"ࠧࠨⴉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴊ"),l1l111_l1_ (u"ࠩࡢࡗࡍ࠺࡟ࠨⴋ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺࠥว่ัࠣๅํื๊้ࠩⴌ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬⴍ"),119,l1l111_l1_ (u"ࠬ࠭ⴎ"),l1l111_l1_ (u"࠭ࠧⴏ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬⴐ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴑ"),l1l111_l1_ (u"ࠩࡢࡉࡇ࠹࡟ࠨⴒ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪⴓ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬⴔ"),799,l1l111_l1_ (u"ࠬ࠭ⴕ"),l1l111_l1_ (u"࠭ࠧⴖ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⴗ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⴘ"),l1l111_l1_ (u"ࠩࠪⴙ"),157)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴚ"),l1l111_l1_ (u"ࠫࡤࡌࡓࡕࡡࠪⴛ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโ๊ึฮฬ࠭ⴜ")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧⴝ"),609,l1l111_l1_ (u"ࠧࠨⴞ"),l1l111_l1_ (u"ࠨࠩⴟ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴠ"),l1l111_l1_ (u"ࠪࡣࡋࡈࡋࡠࠩⴡ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแษำๆอࠬⴢ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠬ࠭ⴣ"),629,l1l111_l1_ (u"࠭ࠧⴤ"),l1l111_l1_ (u"ࠧࠨⴥ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⴦"),l1l111_l1_ (u"ࠩࡢ࡝ࡖ࡚࡟ࠨⴧ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๐วใ๊อࠫ⴨")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬ⴩"),669,l1l111_l1_ (u"ࠬ࠭⴪"),l1l111_l1_ (u"࠭ࠧ⴫"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⴬"),l1l111_l1_ (u"ࠨࡡࡅࡖࡘࡥࠧⴭ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤอืำห์ฯࠫ⴮")+l1111l1lll_l1_,l1l111_l1_ (u"ࠪࠫ⴯"),659,l1l111_l1_ (u"ࠫࠬⴰ"),l1l111_l1_ (u"ࠬ࠭ⴱ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴲ"),l1l111_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭ⴳ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻๋้ࠣอࠠิ์่หࠬⴴ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࠪⴵ"),89,l1l111_l1_ (u"ࠪࠫⴶ"),l1l111_l1_ (u"ࠫࠬⴷ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴸ"),l1l111_l1_ (u"࠭࡟ࡅࡔ࠺ࡣࠬⴹ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢาีฬ๋วࠡืะࠫⴺ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨࠩⴻ"),689,l1l111_l1_ (u"ࠩࠪⴼ"),l1l111_l1_ (u"ࠪࠫⴽ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴾ"),l1l111_l1_ (u"ࠬࡥࡃࡎࡈࡢࠫⴿ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦแศ่ีࠫⵀ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨⵁ"),99,l1l111_l1_ (u"ࠨࠩⵂ"),l1l111_l1_ (u"ࠩࠪⵃ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵄ"),l1l111_l1_ (u"ࠫࡤࡉࡍࡍࡡࠪⵅ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪⵆ")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧⵇ"),479,l1l111_l1_ (u"ࠧࠨⵈ"),l1l111_l1_ (u"ࠨࠩⵉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵊ"),l1l111_l1_ (u"ࠪࡣࡆࡈࡄࡠࠩⵋ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩⵌ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠬ࠭ⵍ"),559,l1l111_l1_ (u"࠭ࠧⵎ"),l1l111_l1_ (u"ࠧࠨⵏ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵐ"),l1l111_l1_ (u"ࠩࡢࡇ࠹ࡎ࡟ࠨⵑ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧⵒ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠫࠬⵓ"),699,l1l111_l1_ (u"ࠬ࠭ⵔ"),l1l111_l1_ (u"࠭ࠧⵕ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵖ"),l1l111_l1_ (u"ࠨࡡࡄࡌࡐࡥࠧⵗ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨⵘ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠪࠫⵙ"),619,l1l111_l1_ (u"ࠫࠬⵚ"),l1l111_l1_ (u"ࠬ࠭ⵛ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵜ"),l1l111_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭ⵝ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧⵞ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠩࠪⵟ"),649,l1l111_l1_ (u"ࠪࠫⵠ"),l1l111_l1_ (u"ࠫࠬⵡ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵢ"),l1l111_l1_ (u"࠭࡟ࡇࡊ࠵ࡣࠬⵣ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧⵤ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨࠩⵥ"),599,l1l111_l1_ (u"ࠩࠪⵦ"),l1l111_l1_ (u"ࠪࠫⵧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⵨"),l1l111_l1_ (u"ࠬࡥࡅࡃ࠶ࡢࠫ⵩")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠹࠭⵪")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨ⵫"),809,l1l111_l1_ (u"ࠨࠩ⵬"),l1l111_l1_ (u"ࠩࠪ⵭"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⵮"),l1l111_l1_ (u"ࠫࡤࡉࡃࡘࡡࠪⵯ")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠣ฽๊๊ࠧ⵰")+l1111l1lll_l1_,l1l111_l1_ (u"࠭ࠧ⵱"),639,l1l111_l1_ (u"ࠧࠨ⵲"),l1l111_l1_ (u"ࠨࠩ⵳"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⵴"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⵵"),l1l111_l1_ (u"ࠫࠬ⵶"),157)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵷"),l1l111_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ⵸")+l1lll1ll1l1_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํ์ฯ๐่ษࠩ⵹")+l1111l1lll_l1_,l1l111_l1_ (u"ࠨࠩ⵺"),149,l1l111_l1_ (u"ࠩࠪ⵻"),l1l111_l1_ (u"ࠪࠫ⵼"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⵽"),l1l111_l1_ (u"ࠬࡥࡄࡍࡏࡢࠫ⵾")+l1lll1ll1l1_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัํ่๏ࠦๅ้ึ⵿้ࠫ")+l1111l1lll_l1_,l1l111_l1_ (u"ࠧࠨⶀ"),409,l1l111_l1_ (u"ࠨࠩⶁ"),l1l111_l1_ (u"ࠩࠪⶂ"),l1lll1ll_l1_)
	return
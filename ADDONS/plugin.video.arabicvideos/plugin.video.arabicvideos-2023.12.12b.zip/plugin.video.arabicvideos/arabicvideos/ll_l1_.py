# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䢔")
l1l1111111ll_l1_ = []
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䢕"):l1l111_l1_ (u"ࠫࠬ䢖")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䢗"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭䢘")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨ䢙")+type+l1l111_l1_ (u"ࠨࠢࡠࠫ䢚"))
		l11lll1111ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䢛"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䢜"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ䢝"))
		datetime = time.strftime(l1l111_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭䢞"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ䢟")+l1l11l1llll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ䢠")+str(kodi_version)
		message = l1l111_l1_ (u"ࠨࠩ䢡")
		if key not in list(l11lll1111ll_l1_.keys()): l11lll1111ll_l1_[key] = [line]
		else:
			if url not in str(l11lll1111ll_l1_[key]): l11lll1111ll_l1_[key].append(line)
			else: message = l1l111_l1_ (u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧ䢢")
		total = 0
		for key in list(l11lll1111ll_l1_.keys()):
			l11lll1111ll_l1_[key] = list(set(l11lll1111ll_l1_[key]))
			total += len(l11lll1111ll_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䢣"),l1l111_l1_ (u"ࠫࠬ䢤"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䢥"),l1l111_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧ䢦")+message+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭䢧")+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䢨")+l1l111_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ䢩")+str(total))
		if total>=5:
			l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠪࠫ䢪"),l1l111_l1_ (u"ࠫࠬ䢫"),l1l111_l1_ (u"ࠬ࠭䢬"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䢭"),l1l111_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ䢮"))
			if l1llll1l11_l1_==1:
				l11lll111l1l_l1_ = l1l111_l1_ (u"ࠨࠩ䢯")
				for key in list(l11lll1111ll_l1_.keys()):
					l11lll111l1l_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࠬ䢰")+key
					l1l111ll1lll_l1_ = sorted(l11lll1111ll_l1_[key],reverse=False,key=lambda l11ll1ll1lll_l1_: l11ll1ll1lll_l1_[0])
					for datetime,url in l1l111ll1lll_l1_:
						l11lll111l1l_l1_ += l1l111_l1_ (u"ࠪࡠࡳ࠭䢱")+datetime+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠩ䢲")+l111l11_l1_(url)
					l11lll111l1l_l1_ += l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䢳")
				import l1l1l11l1ll_l1_
				succeeded = l1l1l11l1ll_l1_.l11l1l11lll_l1_(l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࡸ࠭䢴"),l1l111_l1_ (u"ࠧࠨ䢵"),False,l1l111_l1_ (u"ࠨࠩ䢶"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䢷"),l1l111_l1_ (u"ࠪࠫ䢸"),l11lll111l1l_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䢹"),l1l111_l1_ (u"ࠬ࠭䢺"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䢻"),l1l111_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ䢼"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䢽"),l1l111_l1_ (u"ࠩࠪ䢾"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䢿"),l1l111_l1_ (u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩ䣀"))
			if l1llll1l11_l1_!=-1:
				l11lll1111ll_l1_ = {}
				l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䣁"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ䣂"))
		if l11lll1111ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䣃"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ䣄"),l11lll1111ll_l1_,l1ll111l1l1_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11ll1l1ll1l_l1_(l1ll11l1_l1_,source)
	l1l111l1lll1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䣅"))
	l11ll1ll1l11_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䣆"))
	l1l111lll1l1_l1_ = len(l1llll_l1_)-l1l111l1lll1_l1_-l11ll1ll1l11_l1_
	l11lll11l1l1_l1_ = l1l111_l1_ (u"ฺ๊ࠫว่ัฬ࠾ࠬ䣇")+str(l1l111l1lll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩ䣈")+str(l11ll1ll1l11_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࠣวำื้࠻ࠩ䣉")+str(l1l111lll1l1_l1_)
	if not l1llll_l1_: result,l1l111llll11_l1_ = l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䣊"),l1l111_l1_ (u"ࠨࠩ䣋")
	else:
		while True:
			l1l111llll11_l1_ = l1l111_l1_ (u"ࠩࠪ䣌")
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l11lll11l1l1_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠷ࡳࡵࡡࡰࡩࡳࡻࠧ䣍")
			else:
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ุࠫ๐ัโำࠪ䣎") in title and l1l111_l1_ (u"ࠬ࠸ๅอ้๋่࠷࠭䣏") in title:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䣐"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡙ࠧࠡࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࡓࡦࡴࡹࡩࡷࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ䣑")+title+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䣒")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ䣓"))
					import l1l1l11l1ll_l1_
					l1l1l11l1ll_l1_.l11l1ll_l1_(156)
					result = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䣔")
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䣕"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒ࡯ࡥࡾ࡯࡮ࡨࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࡘ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪ䣖")+title+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䣗")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ䣘"))
					result,l1l111llll11_l1_,l1l1l1l1lll1_l1_ = l11lllll11l1_l1_(l1ll1ll_l1_,source,type)
			if l1l111_l1_ (u"ࠨ࡞ࡱࠫ䣙") not in l1l111llll11_l1_: l11lllll1111_l1_,l11ll11lll1_l1_ = l1l111llll11_l1_,l1l111_l1_ (u"ࠩࠪ䣚")
			else: l11lllll1111_l1_,l11ll11lll1_l1_ = l1l111llll11_l1_.split(l1l111_l1_ (u"ࠪࡠࡳ࠭䣛"),1)
			if result in [l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䣜"),l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䣝"),l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ䣞"),l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ䣟"),l1l111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ䣠")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ䣡"),l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ䣢"),l1l111_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ䣣")]: break
			elif result not in [l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ䣤"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ䣥")]: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䣦"),l1l111_l1_ (u"ࠨࠩ䣧"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣨"),l1l111_l1_ (u"ࠪหู้๊าใิࠤ้๋๋ࠠ฻่่ࠥาัษࠢึ๎ึ็ัࠡ฼ํี์࠭䣩")+l1l111_l1_ (u"ࠫࡡࡴࠧ䣪")+l11lllll1111_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ䣫")+l11ll11lll1_l1_)
	if result==l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䣬") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䣭"),l1l111_l1_ (u"ࠨࠩ䣮"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣯"),l1l111_l1_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ䣰")+l1l111_l1_ (u"ࠫࡡࡴࠧ䣱")+l1l111llll11_l1_)
	elif result in [l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ䣲"),l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ䣳")] and l1l111llll11_l1_!=l1l111_l1_ (u"ࠧࠨ䣴"): l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䣵"),l1l111_l1_ (u"ࠩࠪ䣶"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䣷"),l1l111llll11_l1_)
	return result
def l11lllll11l1_l1_(url,source,type=l1l111_l1_ (u"ࠫࠬ䣸")):
	url = url.strip(l1l111_l1_ (u"ࠬࠦࠧ䣹")).strip(l1l111_l1_ (u"࠭ࠦࠨ䣺")).strip(l1l111_l1_ (u"ࠧࡀࠩ䣻")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䣼"))
	l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1ll1l_l1_(url,source)
	if l1l111llll11_l1_==l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䣽"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ䣾"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ䣿")
			else:
				l1l11l1l1l1l_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䤀"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡪࡲࡥࡤࡶࡨࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬ䤁")+title+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭䤂")+str(l1l11l1l1l1l_l1_)+l1l111_l1_ (u"ࠨࠢࡠࠫ䤃"))
				if l1l111_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ䤄") in l1l11l1l1l1l_l1_ and l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ䤅") in l1l11l1l1l1l_l1_:
					l1l11l1ll111_l1_,l1l1l1l1l111_l1_,l1l1l1l1lll1_l1_ = l11lll1l1lll_l1_(l1l11l1l1l1l_l1_)
					if l1l1l1l1lll1_l1_: l1l11l1l1l1l_l1_ = l1l1l1l1lll1_l1_[0]
					else: l1l11l1l1l1l_l1_ = l1l111_l1_ (u"ࠫࠬ䤆")
				if not l1l11l1l1l1l_l1_: result = l1l111_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ䤇")
				else: result = l1llll111_l1_(l1l11l1l1l1l_l1_,source,type)
			if result in [l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ䤈"),l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ䤉"),l1l111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ䤊")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ䤋"),l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ䤌"),l1l111_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ䤍")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䤎"),l1l111_l1_ (u"࠭ࠧ䤏"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䤐"),l1l111_l1_ (u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧ䤑"))
	else:
		result = l1l111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䤒")
		l11ll1l11l_l1_ = l1l111ll1l_l1_(url)
		if l11ll1l11l_l1_: result = l1llll111_l1_(url,source,type)
	return result,l1l111llll11_l1_,l1llll_l1_
def l11llll1l1l1_l1_(url,source):
	l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠪࠫ䤓"),l1l111_l1_ (u"ࠫࠬ䤔"),l1l111_l1_ (u"ࠬ࠭䤕"),l1l111_l1_ (u"࠭ࠧ䤖"),l1l111_l1_ (u"ࠧࠨ䤗"),l1l111_l1_ (u"ࠨࠩ䤘"),l1l111_l1_ (u"ࠩࠪ䤙")
	if l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䤚") in url:
		l1lllll1_l1_,l11lllll1l11_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䤛"),1)
		l11lllll1l11_l1_ = l11lllll1l11_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࠨ䤜")+l1l111_l1_ (u"࠭࡟ࡠࠩ䤝")+l1l111_l1_ (u"ࠧࡠࡡࠪ䤞")+l1l111_l1_ (u"ࠨࡡࡢࠫ䤟")
		l11lllll1l11_l1_ = l11lllll1l11_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1ll1l1ll1ll_l1_ = l11lllll1l11_l1_.split(l1l111_l1_ (u"ࠩࡢࡣࠬ䤠"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠪࠫ䤡"): l111l1ll_l1_ = l1l111_l1_ (u"ࠫ࠵࠭䤢")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠬࡶࠧ䤣"),l1l111_l1_ (u"࠭ࠧ䤤")).replace(l1l111_l1_ (u"ࠧࠡࠩ䤥"),l1l111_l1_ (u"ࠨࠩ䤦"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠩࡂࠫ䤧")).strip(l1l111_l1_ (u"ࠪ࠳ࠬ䤨")).strip(l1l111_l1_ (u"ࠫࠫ࠭䤩"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ䤪"))
	if name: l11ll1lll111_l1_ = name
	else: l11ll1lll111_l1_ = server
	l11ll1lll111_l1_ = l1l111l_l1_(l11ll1lll111_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䤫"))
	name = name.replace(l1l111_l1_ (u"ࠧๆสสุึ࠭䤬"),l1l111_l1_ (u"ࠨࠩ䤭")).replace(l1l111_l1_ (u"ࠩึ๎ึ็ัࠨ䤮"),l1l111_l1_ (u"ࠪࠫ䤯")).replace(l1l111_l1_ (u"ࠫฬ๊ࠠࠨ䤰"),l1l111_l1_ (u"ࠬࠦࠧ䤱")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䤲"),l1l111_l1_ (u"ࠧࠡࠩ䤳"))
	l11lllll1l11_l1_ = l11lllll1l11_l1_.replace(l1l111_l1_ (u"ࠨ็หหูืࠧ䤴"),l1l111_l1_ (u"ࠩࠪ䤵")).replace(l1l111_l1_ (u"ࠪื๏ืแาࠩ䤶"),l1l111_l1_ (u"ࠫࠬ䤷")).replace(l1l111_l1_ (u"ࠬอไࠡࠩ䤸"),l1l111_l1_ (u"࠭ࠠࠨ䤹")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䤺"),l1l111_l1_ (u"ࠨࠢࠪ䤻"))
	l11ll1lll111_l1_ = l11ll1lll111_l1_.replace(l1l111_l1_ (u"่ࠩฬฬฺัࠨ䤼"),l1l111_l1_ (u"ࠪࠫ䤽")).replace(l1l111_l1_ (u"ุࠫ๐ัโำࠪ䤾"),l1l111_l1_ (u"ࠬ࠭䤿")).replace(l1l111_l1_ (u"࠭วๅࠢࠪ䥀"),l1l111_l1_ (u"ࠧࠡࠩ䥁")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䥂"),l1l111_l1_ (u"ࠩࠣࠫ䥃"))
	return l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l111l1llll_l1_(url,source):
	l1l11l111l11_l1_,name,l11ll1111l1_l1_,l11llll1l1ll_l1_,l11llll1ll11_l1_,l1l111111l11_l1_,l1l11l111111_l1_ = l1l111_l1_ (u"ࠪࠫ䥄"),l1l111_l1_ (u"ࠫࠬ䥅"),None,None,None,None,None
	l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11llll1l1l1_l1_(url,source)
	if l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䥆") in url:
		if   type==l1l111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨࠬ䥇"): type = l1l111_l1_ (u"ࠧࠡࠩ䥈")+l1l111_l1_ (u"ࠨ็ไฺ้࠭䥉")
		elif type==l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ䥊"): type = l1l111_l1_ (u"ࠪࠤࠬ䥋")+l1l111_l1_ (u"๋ࠫࠪิศ้าอࠬ䥌")
		elif type==l1l111_l1_ (u"ࠬࡨ࡯ࡵࡪࠪ䥍"): type = l1l111_l1_ (u"࠭ࠠࠨ䥎")+l1l111_l1_ (u"ุ่ࠧࠦࠧฬํฯส๋ࠢฮา๋๊ๅࠩ䥏")
		elif type==l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䥐"): type = l1l111_l1_ (u"ࠩࠣࠫ䥑")+l1l111_l1_ (u"ࠪࠩࠪࠫสฮ็ํ่ࠬ䥒")
		elif type==l1l111_l1_ (u"ࠫࠬ䥓"): type = l1l111_l1_ (u"ࠬࠦࠧ䥔")+l1l111_l1_ (u"࠭ࠥࠦࠧࠨࠫ䥕")
		if l111lll_l1_!=l1l111_l1_ (u"ࠧࠨ䥖"):
			if l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠬ䥗") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"ࠩࠨࠫ䥘")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠪࠤࠬ䥙")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠫࠬ䥚"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨ䥛")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠠࠨ䥜")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭䥝")		in source: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ䥞")		in source: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ䥟")
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ䥠")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭䥡")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫ䥢")	in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭䥣")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䥤")
	elif l1l111_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ䥥")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ䥦")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࠩ䥧")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫ䥨")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ䥩")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ䥪")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭䥫")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨใฯีࠬ䥬")			in name:   l11ll1111l1_l1_	= l1l111_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ䥭")
	elif l1l111_l1_ (u"ࠪๅู้ื๋่ࠪ䥮")		in name:   l11ll1111l1_l1_	= l1l111_l1_ (u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧ䥯")
	elif l1l111_l1_ (u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬ䥰")		in l1lllll1_l1_:   l11ll1111l1_l1_	= l1l111_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠭䥱")
	elif l1l111_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ䥲")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ䥳")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䥴")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ䥵")		in name:   l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ䥶")	in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ䥷")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ䥸")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧࡵࡸ࡮ࡷࡦ࠭䥹")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ䥺")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ䥻")		in server: l11ll1111l1_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ䥼")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭䥽")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ䥾")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭䥿")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ䦀")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ䦁")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ䦂")	 	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ䦃")
	elif l1l111_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ䦄")	 	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭䦅")
	elif l1l111_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ䦆")	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ䦇")
	elif l1l111_l1_ (u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ䦈")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ䦉")
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ䦊")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭䦋")
	elif l1l111_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ䦌")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ䦍")
	elif l1l111_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭䦎")	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ䦏")
	elif l1l111_l1_ (u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬ䦐")	in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯ࠪ䦑")
	elif l1l111_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ䦒")		in server: l11ll1111l1_l1_	= l1l111_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䦓")
	elif l1l111_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ䦔")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ䦕")
	elif l1l111_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ䦖")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ䦗")
	elif l1l111_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ䦘")	 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠫࡨࡧࡴࡤࡪࠪ䦙")
	elif l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭䦚")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ䦛")
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡲ࠭䦜")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ䦝")
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡮ࡤࠨ䦞")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠪࡱࡾࡼࡩࡥࠩ䦟")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠫࡲࡿࡶࡪ࡫ࡧࠫ䦠")		in server: l1l111111l11_l1_	= l11ll1lll111_l1_
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ䦡")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ䦢")
	elif l1l111_l1_ (u"ࠧࡨࡱࡹ࡭ࡩ࠭䦣")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ䦤")
	elif l1l111_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ䦥") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ䦦")
	elif l1l111_l1_ (u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ䦧")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ䦨")
	elif l1l111_l1_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫ䦩")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ䦪")
	elif l1l111_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ䦫") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭䦬")
	elif l1l111_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ䦭")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ䦮")
	elif l1l111_l1_ (u"ࠬࡻࡰࡱࠩ䦯") 			in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ䦰")
	elif l1l111_l1_ (u"ࠧࡶࡲࡥࠫ䦱") 			in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ䦲")
	elif l1l111_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ䦳") 		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ䦴")
	elif l1l111_l1_ (u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭䦵") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ䦶")
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡥࡳࡧ࠭䦷")		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䦸")
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ䦹") 		in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ䦺")
	elif l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧ䦻") 	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䦼")
	elif l1l111_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ䦽")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䦾")
	elif l1l111_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ䦿")	in server: l11llll1l1ll_l1_	= l1l111_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ䧀")
	if   l11ll1111l1_l1_:	l1l11l111l11_l1_,name = l1l111_l1_ (u"ࠩัหฺ࠭䧁"),l11ll1111l1_l1_
	elif l1l111111l11_l1_:		l1l11l111l11_l1_,name = l1l111_l1_ (u"๊ࠪࠩำฯะࠩ䧂"),l1l111111l11_l1_
	elif l11llll1l1ll_l1_:		l1l11l111l11_l1_,name = l1l111_l1_ (u"ูࠫࠪࠫศ็้ࠣ฾ื่โࠩ䧃"),l11llll1l1ll_l1_
	elif l11llll1ll11_l1_:	l1l11l111l11_l1_,name = l1l111_l1_ (u"ࠬࠫࠥࠦ฻ส้ࠥิวาฮํࠫ䧄"),l11llll1ll11_l1_
	elif l1l11l111111_l1_:	l1l11l111l11_l1_,name = l1l111_l1_ (u"࠭ࠥࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭䧅"),l11ll1lll111_l1_
	else:			l1l11l111l11_l1_,name = l1l111_l1_ (u"ࠧࠦࠧࠨࠩࠪ฿วๆ่ࠢะ์๎ไࠨ䧆"),l11ll1lll111_l1_
	return l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l11llllll1ll_l1_(url,source):
	l1lllll1_l1_,l11lllll1l11_l1_,server,l11ll1lll111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11llll1l1l1_l1_(url,source)
	if   l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䧇")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ䧈")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ䧉")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ䧊")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ䧋")		in source: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111llll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ䧌")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11ll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ䧍")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ䧎")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ䧏")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬ䧐")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ䧑")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ䧒")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l1ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡴࡷ࡭ࡶࡥࠬ䧓")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l1ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡵࡸ࠰ࡪ࠳ࡩ࡯࡮ࠩ䧔")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l1ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ䧕")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ䧖")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ䧗")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll111lll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭䧘")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111lll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡼࡳ࠵ࡷࠪ䧙")			in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1ll11lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ䧚")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1lll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ䧛")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ䧜")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࠭࡭࡫ࡪ࡬ࡹ࠭䧝")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠭䧞")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ䧟")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll1l11l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ䧠")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ䧡")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ䧢")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11l1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ䧣")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ䧤")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡷࡩࡨ࡮ࠧ䧥")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫ࡬ࡻ࡬ࡧࡶࡨࡧ࡭࠭䧦")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡷࡧࡴࡦࠩ䧧")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡰࡤࡴࡨࡺ࡮࡫ࡷࠨ䧨")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࠧ䧩")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪ䧪")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪࠧ䧫")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䧬"),[l1l111_l1_ (u"ࠫࠬ䧭")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ䧮")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111llll11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ䧯")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll11l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠭䧰")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l111lllllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡷࡳࡦࡦࡳࠧ䧱") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ䧲"),[l1l111_l1_ (u"ࠪࠫ䧳")],[l1lllll1_l1_]
	else: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䧴"),[l1l111_l1_ (u"ࠬ࠭䧵")],[l1lllll1_l1_]
	return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11llll11ll1_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䧶"))
	l11llllll1l1_l1_ = False
	if   l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭䧷")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ䧸")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠭䧹") in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1111l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ䧺")	in url: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111ll1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䧻")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡷࡧࡴࡦࠩ䧼")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䧽")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11l1l_l1_(url)
	elif l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䧾")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1lll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ䧿")		in url   : l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l1l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ䨀")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11l1l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䨁")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111l11_l1_(url)
	elif l1l111_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ䨂")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡫࠵ࡵࡵࡤࡶࠬ䨃")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1111_l1_(url)
	elif l1l111_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ䨄")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1ll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ䨅")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1ll1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ䨆")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ䨇")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ䨈")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ䨉")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ䨊")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"࠭࡬ࡪ࡫࡬ࡺ࡮ࡪࡥࡰࠩ䨋")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11lll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡳࡧࡧࠧ䨌")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll111l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡸࡶࡥࡦࡦࠪ䨍")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll111l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ䨎") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䨏"),[l1l111_l1_ (u"ࠫࠬ䨐")],[url]
	elif l1l111_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䨑") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllllll1l_l1_(url)
	elif l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䨒")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111lll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳ࡭ࡵࠧ䨓")in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ䨔") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11ll11_l1_(url)
	elif l1l111_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䨕")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l11l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡹࡵࡨࠧ䨖") 			in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠫࡺࡶࡰࠨ䨗") 			in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ䨘") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111l1l_l1_(url)
	elif l1l111_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䨙") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1l1l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䨚")		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l111l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ䨛") 		in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll111ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䨜") 	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111ll1l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䨝")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l1llll_l1_(url)
	elif l1l111_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ䨞")	in server: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1ll1_l1_(url)
	else: l11llllll1l1_l1_ = True
	if l11llllll1l1_l1_ or l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ䨟") in l1l111llll11_l1_:
		l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠥࡌࡡࡪ࡮ࡨࡨࠬ䨠"),[],[]
	return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll1llll1_l1_(l1l1l1l1ll11_l1_):
	if l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䨡") in str(type(l1l1l1l1ll11_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1l1l1ll11_l1_:
			if l1l111_l1_ (u"ࠨࡵࡷࡶࠬ䨢") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ䨣"),l1l111_l1_ (u"ࠪࠫ䨤")).replace(l1l111_l1_ (u"ࠫࡡࡴࠧ䨥"),l1l111_l1_ (u"ࠬ࠭䨦")).strip(l1l111_l1_ (u"࠭ࠠࠨ䨧"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1l1l1ll11_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ䨨"),l1l111_l1_ (u"ࠨࠩ䨩")).replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ䨪"),l1l111_l1_ (u"ࠪࠫ䨫")).strip(l1l111_l1_ (u"ࠫࠥ࠭䨬"))
	return l1ll_l1_
def l1l111l1ll1l_l1_(url,source):
	l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䨭"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ䨮")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ䨯"))
	l1l11l111111_l1_,l1ll1ll_l1_,l11lll1lllll_l1_ = l1l111_l1_ (u"ࠨࡋࡑࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ䨰"),l1l111_l1_ (u"ࠩࠪ䨱"),l1l111_l1_ (u"ࠪࠫ䨲")
	l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll1ll_l1_(url,source)
	l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
	if l1l111llll11_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䨳"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_: l1ll1ll_l1_ = l1llll_l1_[0]
	if l1l111llll11_l1_==l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䨴"):
		l1l11l111111_l1_ = l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠬ䨵")
		l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11ll1_l1_(l1ll1ll_l1_,source)
		l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
		if l1l111llll11_l1_==l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䨶"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ䨷") in l1l111llll11_l1_:
			l11lll1lllll_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠪ䨸")+l1l111llll11_l1_
			l1l11l111111_l1_ = l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ䨹")
			l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11l1l_l1_(l1ll1ll_l1_,source)
			l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
			if l1l111llll11_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䨺"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ䨻") in l1l111llll11_l1_:
				l11lll1lllll_l1_ += l1l111_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠧ䨼")+l1l111llll11_l1_
				l1l11l111111_l1_ = l1l111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭䨽")
				l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11l11_l1_(l1ll1ll_l1_,source)
				l1llll_l1_ = l11lll1llll1_l1_(l1llll_l1_)
				if l1l111llll11_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䨾"): return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ䨿") in l1l111llll11_l1_:
					l11lll1lllll_l1_ += l1l111_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠫ䩀")+l1l111llll11_l1_
	elif l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࠭䩁") in l1l111llll11_l1_: l11lll1lllll_l1_ = l1l111_l1_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠱࠼ࠣࠫ䩂")+l1l111llll11_l1_
	if l1llll_l1_: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䩃"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠠ࡜ࠢࠪ䩄")+l1l11l111111_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䩅")+url+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䩆")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴࡴ࠼ࠣ࡟ࠥ࠭䩇")+str(l1llll_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠧ䩈"))
	else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䩉"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭䩊")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ䩋")+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ䩌")+l11lll1lllll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ䩍"))
	l11lll1lllll_l1_ = l111l11_l1_(l11lll1lllll_l1_)
	return l11lll1lllll_l1_,l1l1lll1_l1_,l1llll_l1_
def l11ll1l1ll1l_l1_(l1l1l1l1lll1_l1_,source):
	l1l1l1llll1_l1_ = l1ll1ll1_l1_
	data = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䩎"),l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䩏"),l1l1l1l1lll1_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l111ll1l1l_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1l1l1l1lll1_l1_:
		if l1l111_l1_ (u"ࠬ࠵࠯ࠨ䩐") not in l1ll1ll_l1_: continue
		l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111l1llll_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࠪ䩑"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䩒"))
		l1l111ll1l1l_l1_.append([l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l111ll1l1l_l1_:
		l11llll1111l_l1_ = sorted(l1l111ll1l1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll11ll1_l1_ = []
		for line in l11llll1111l_l1_:
			if line not in l11ll11ll1_l1_:
				l11ll11ll1_l1_.append(line)
		for l1l11l111l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll11ll1_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ䩓")
			title = l1l111_l1_ (u"ࠩึ๎ึ็ัࠨ䩔")+l1l111_l1_ (u"ࠪࠤࠬ䩕")+type+l1l111_l1_ (u"ࠫࠥ࠭䩖")+l1l11l111l11_l1_+l1l111_l1_ (u"ࠬࠦࠧ䩗")+l111l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ䩘")+l111lll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䩙")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠨࠢࠪ䩚")+server
			title = title.replace(l1l111_l1_ (u"ࠩࠨࠫ䩛"),l1l111_l1_ (u"ࠪࠫ䩜")).strip(l1l111_l1_ (u"ࠫࠥ࠭䩝")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䩞"),l1l111_l1_ (u"࠭ࠠࠨ䩟")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䩠"),l1l111_l1_ (u"ࠨࠢࠪ䩡")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䩢"),l1l111_l1_ (u"ࠪࠤࠬ䩣"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䩤"),l1l1l1l1lll1_l1_,data,l1l1l1llll1_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l11llll11l1l_l1_(url,source):
	l1111llll11_l1_ = l1l111_l1_ (u"ࠬ࠭䩥")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l1111llll11_l1_ = str(error)
	if not l1lll_l1_:
		if l1111llll11_l1_==l1l111_l1_ (u"࠭ࠧ䩦"):
			l1111llll11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111llll11_l1_)
		l1l111llll11_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷ࠦࡆࡢ࡫࡯ࡩࡩ࠭䩧")
		l1l111llll11_l1_ += l1l111_l1_ (u"ࠨࠢࠪ䩨")+l1111llll11_l1_.splitlines()[-1]
		return l1l111llll11_l1_,[],[]
	return l1l111_l1_ (u"ࠩࠪ䩩"),[l1l111_l1_ (u"ࠪࠫ䩪")],[l1lll_l1_]
def l11llll11l11_l1_(url,source):
	l1111llll11_l1_ = l1l111_l1_ (u"ࠫࠬ䩫")
	l1lll_l1_ = False
	try:
		import youtube_dl
		l1l1111lll1l_l1_ = youtube_dl.YoutubeDL({l1l111_l1_ (u"ࠬࡴ࡯ࡠࡥࡲࡰࡴࡸࠧ䩬"): True})
		l1lll_l1_ = l1l1111lll1l_l1_.extract_info(url,download=False)
	except Exception as error: l1111llll11_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ䩭") not in list(l1lll_l1_.keys()):
		if l1111llll11_l1_==l1l111_l1_ (u"ࠧࠨ䩮"):
			l1111llll11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111llll11_l1_)
		l1l111llll11_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠠࡇࡣ࡬ࡰࡪࡪࠧ䩯")
		l1l111llll11_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䩰")+l1111llll11_l1_.splitlines()[-1]
		return l1l111llll11_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ䩱")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫ䩲")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䩳")])
		return l1l111_l1_ (u"࠭ࠧ䩴"),l1l1lll1_l1_,l1llll_l1_
def l1l1111ll1l1_l1_(url):
	if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭䩵") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠨࠩ䩶"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡁࡓࡃࡅࠫ䩷"),[],[]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䩸"),[l1l111_l1_ (u"ࠫࠬ䩹")],[url]
def l1ll11ll1ll_l1_(url):
	l1ll11l1_l1_,l111lll1ll_l1_ = [],[]
	if l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠴࡭ࡱ࠶ࡂࡺ࡮ࡪ࠽ࠨ䩺") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䩻"),url,l1l111_l1_ (u"ࠧࠨ䩼"),l1l111_l1_ (u"ࠨࠩ䩽"),False,l1l111_l1_ (u"ࠩࠪ䩾"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠳ࡶࡸࠬ䩿"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䪀") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪁")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䪂"))
			l111lll1ll_l1_.append(server)
	elif l1l111_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦ࠰ࡦࡳࡲ࠭䪃") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䪄"),url,l1l111_l1_ (u"ࠩࠪ䪅"),l1l111_l1_ (u"ࠪࠫ䪆"),l1l111_l1_ (u"ࠫࠬ䪇"),l1l111_l1_ (u"ࠬ࠭䪈"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠷ࡴࡤࠨ䪉"))
		html = response.content
		l1111111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࡤ࡝ࠫ࠱࠮ࡄࡢࠩ࡝ࠫࠬ࠲ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ䪊"),html,re.DOTALL)
		if l1111111l1l_l1_:
			l1111111l1l_l1_ = l1111111l1l_l1_[0]
			l1ll1l1ll111_l1_ = l1ll1llll11l_l1_(l1111111l1l_l1_)
			l1ll1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭࠱࠭䪋"),l1ll1l1ll111_l1_,re.DOTALL)
			if l1ll1l11l1l1_l1_:
				l1ll1l11l1l1_l1_ = l1ll1l11l1l1_l1_[0]
				l1ll1l11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䪌"),l1ll1l11l1l1_l1_)
				for dict in l1ll1l11l1l1_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࠨ䪍")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ䪎")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䪏"))
					l111lll1ll_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ䪐")+server)
		elif l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䪑") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䪒")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䪓"))
			l111lll1ll_l1_.append(server)
		if l1l111_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࡰࡱࠪ䪔") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡻࡲ࡭࠿ࠪ䪕"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬࠧ䪖"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111lll1ll_l1_.append(l1l111_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸࠦࡧࡰࡱࡪࡰࡪ࠭䪗"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䪘"))
		l111lll1ll_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ䪙"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䪚"),l111lll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䪛"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䪜"),[l1l111_l1_ (u"ࠬ࠭䪝")],[l1ll1ll_l1_]
def l11lll1111l1_l1_(url):
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䪞"):l1l111_l1_ (u"ࠧࡌࡱࡧ࡭࠴࠭䪟")+str(kodi_version)}
	for l1l11l111l_l1_ in range(50):
		time.sleep(0.100)
		response = l1111llllll_l1_(l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䪠"),url,l1l111_l1_ (u"ࠩࠪ䪡"),headers,False,l1l111_l1_ (u"ࠪࠫ䪢"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨ䪣"))
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪤") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䪥")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭䪦")+headers[l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䪧")]
			return l1l111_l1_ (u"ࠩࠪ䪨"),[l1l111_l1_ (u"ࠪࠫ䪩")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪ䪪"),[],[]
def l1l111111ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䪫"),url,l1l111_l1_ (u"࠭ࠧ䪬"),l1l111_l1_ (u"ࠧࠨ䪭"),l1l111_l1_ (u"ࠨࠩ䪮"),l1l111_l1_ (u"ࠩࠪ䪯"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩ䪰"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨ䪱"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"ࠬ࠭䪲"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧ䪳"),[],[]
def l1llll1l1l1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䪴"),url,l1l111_l1_ (u"ࠨࠩ䪵"),l1l111_l1_ (u"ࠩࠪ䪶"),l1l111_l1_ (u"ࠪࠫ䪷"),l1l111_l1_ (u"ࠫࠬ䪸"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ䪹"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䪺"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࠨ䪻"),[l1l111_l1_ (u"ࠨࠩ䪼")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠶࠭䪽"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䪾") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䪿"),url,l1l111_l1_ (u"ࠬ࠭䫀"),l1l111_l1_ (u"࠭ࠧ䫁"),l1l111_l1_ (u"ࠧࠨ䫂"),l1l111_l1_ (u"ࠨࠩ䫃"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩ䫄"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫅"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䫆") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫇"),[l1l111_l1_ (u"࠭ࠧ䫈")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇ࠴ࡖࠩ䫉"),[],[]
	else: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䫊"),[l1l111_l1_ (u"ࠩࠪ䫋")],[url]
def l111l111l1_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䫌"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䫍"),l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䫎"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䫏")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䫐"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䫑"),l1l111_l1_ (u"ࠩࠪ䫒"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪ䫓"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䫔"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ䫕"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䫖"),[l1l111_l1_ (u"ࠧࠨ䫗")],[l1ll1ll_l1_]
def l1ll111lll11_l1_(url):
	headers = {l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䫘"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䫙")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䫚"),url,l1l111_l1_ (u"ࠫࠬ䫛"),headers,l1l111_l1_ (u"ࠬ࠭䫜"),l1l111_l1_ (u"࠭ࠧ䫝"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡏࡇࡒࡕࡓ࠲࠷ࡳࡵࠩ䫞"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫟"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡏࡐࡈࡓࡖࡔ࠭䫠"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䫡"),[l1l111_l1_ (u"ࠫࠬ䫢")],[l1ll1ll_l1_]
def l1ll1lll111_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䫣"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䫤")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䫥"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䫦"),l1l111_l1_ (u"ࠩࠪ䫧"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䫨"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ䫩"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩ䫪"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䫫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䫬")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䫭"),[l1l111_l1_ (u"ࠩࠪ䫮")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䫯"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䫰")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䫱"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䫲"),l1l111_l1_ (u"ࠧࠨ䫳"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡃࡅࡈࡔ࠳࠱ࡴࡶࠪ䫴"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ䫵"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡄࡆࡉࡕࠧ䫶"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䫷"),[l1l111_l1_ (u"ࠬ࠭䫸")],[l1ll1ll_l1_]
def l11111l1ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䫹"),url,l1l111_l1_ (u"ࠧࠨ䫺"),l1l111_l1_ (u"ࠨࠩ䫻"),l1l111_l1_ (u"ࠩࠪ䫼"),l1l111_l1_ (u"ࠪࠫ䫽"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪ䫾"))
	html = response.content
	l11ll1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ䫿"),html,re.DOTALL|re.IGNORECASE)
	if l11ll1lll1l1_l1_:
		l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_[0][2:]
		l11ll1lll1l1_l1_ = base64.b64decode(l11ll1lll1l1_l1_)
		if kodi_version>18.99: l11ll1lll1l1_l1_ = l11ll1lll1l1_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䬀"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䬁"),l11ll1lll1l1_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ䬂")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪ䬃"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䬄") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䬅")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䬆"),[l1l111_l1_ (u"࠭ࠧ䬇")],[l1ll1ll_l1_]
def l1l111lll1ll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䬈"),url,l1l111_l1_ (u"ࠨࠩ䬉"),l1l111_l1_ (u"ࠩࠪ䬊"),l1l111_l1_ (u"ࠪࠫ䬋"),l1l111_l1_ (u"ࠫࠬ䬌"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧ䬍"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䬎"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫ䬏"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䬐"),[l1l111_l1_ (u"ࠩࠪ䬑")],[l1ll1ll_l1_]
def l1l1l11l1l_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ䬒"))[-1]
	if l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ䬓") in url: url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ䬔"),l1l111_l1_ (u"࠭ࠧ䬕"))
	url = url.replace(l1l111_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴࠭䬖"),l1l111_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩ䬗"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䬘"),url,l1l111_l1_ (u"ࠪࠫ䬙"),l1l111_l1_ (u"ࠫࠬ䬚"),l1l111_l1_ (u"ࠬ࠭䬛"),l1l111_l1_ (u"࠭ࠧ䬜"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ䬝"))
	html = response.content
	l1l111llll11_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ䬞")
	error = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡷࡸ࡯ࡳࠤ࠱࠮ࡄࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䬟"),html,re.DOTALL)
	if error: l1l111llll11_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠪࡼ࠲ࡳࡰࡦࡩࡘࡖࡑࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬠"),html,re.DOTALL)
	if not url and l1l111llll11_l1_:
		return l1l111llll11_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠫࡡࡢࠧ䬡"),l1l111_l1_ (u"ࠬ࠭䬢"))
	l1l1l1l1l111_l1_,l1l1l1l1lll1_l1_ = l1l11l1ll1_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࠨ࠺ࡼࠤ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬣"),html,re.DOTALL)
	if owner: l1l1111llll1_l1_,l1l1111lll11_l1_,l1l11l11ll1l_l1_ = owner[0]
	else: l1l1111llll1_l1_,l1l1111lll11_l1_,l1l11l11ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ䬤"),l1l111_l1_ (u"ࠨࠩ䬥"),l1l111_l1_ (u"ࠩࠪ䬦")
	l1l11l11ll1l_l1_ = l1l11l11ll1l_l1_.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭䬧"),l1l111_l1_ (u"ࠫ࠴࠭䬨"))
	l1l1111lll11_l1_ = escapeUNICODE(l1l1111lll11_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ䬩")+l1l1111lll11_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䬪")]+l1l1l1l1l111_l1_
	l1llll_l1_ = [l1l11l11ll1l_l1_]+l1l1l1l1lll1_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ䬫")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"ࠨ่่ࠢๆ࠯ࠧ䬬"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䬭"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩ䬮")+l1l11l11ll1l_l1_+l1l111_l1_ (u"ࠫࠫࡺࡥࡹࡶࡀࠫ䬯")+l1l1111lll11_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ䬰")+new_path+l1l111_l1_ (u"ࠨࠩࠣ䬱"))
		return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䬲"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠨࠩ䬳"),[l1l111_l1_ (u"ࠩࠪ䬴")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䬵"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䬶"),l1l111_l1_ (u"ࠬ࠭䬷"),l1l111_l1_ (u"࠭ࠧ䬸"),l1l111_l1_ (u"ࠧࠨ䬹"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧ䬺"))
	html = response.content
	if l1l111_l1_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨ䬻") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬼"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䬽"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭䬾"),[],[]
	url = url[0]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䬿") not in url: url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䭀")+url
	return l1l111_l1_ (u"ࠨࠩ䭁"),[l1l111_l1_ (u"ࠩࠪ䭂")],[url]
def l11lll1l1lll_l1_(url):
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䭃") : l1l111_l1_ (u"ࠫࠬ䭄") }
	if l1l111_l1_ (u"ࠬࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ䭅") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䭆"),headers,l1l111_l1_ (u"ࠧࠨ䭇"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠱ࡴࡶࠪ䭈"))
		items = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䭉"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠪࠫ䭊"),[l1l111_l1_ (u"ࠫࠬ䭋")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䭌"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䭍"),l1l111_l1_ (u"ࠧࠨ䭎"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ䭏"),message[0])
				return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ䭐")+message[0],[],[]
	else:
		l1lllllllll_l1_ = l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭䭑")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䭒"),headers,l1l111_l1_ (u"ࠬ࠭䭓"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠷ࡴࡤࠨ䭔"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡇࡱࡵࡱࠥࡳࡥࡵࡪࡲࡨࡂࠨࡐࡐࡕࡗࠦࠥࡧࡣࡵ࡫ࡲࡲࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ䭕"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䭖"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠩ࠱ࡶࡦࡸࠧ䭗") in block or l1l111_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨ䭘") in block: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡒࡕࡓࡉࡃࡋࡈࡆࠦࡎࡰࡶࠣࡥࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠩ䭙"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䭚"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"࠭ࠧ䭛"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩ䭜"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿࠭䭝"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭䭞"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪ䭟"),block,re.DOTALL)
		l1l111lll111_l1_,l1l1lll1_l1_,l11lllll111l_l1_,l1llll_l1_,l11llll1ll1l_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䭠") in l1ll1ll_l1_:
				l1l111lll111_l1_,l11lllll111l_l1_ = l1l11l1ll1_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11lllll111l_l1_
				if l1l111lll111_l1_[0]==l1l111_l1_ (u"ࠬ࠳࠱ࠨ䭡"): l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫ䭢")+l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥ࠭䭣")+l1lllllllll_l1_)
				else:
					for title in l1l111lll111_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭䭤")+l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ䭥")+l1lllllllll_l1_+l1l111_l1_ (u"ࠪࠤࠬ䭦")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭䭧"),l1l111_l1_ (u"ࠬ࠭䭨"))
				title = title.strip(l1l111_l1_ (u"࠭ࠢࠨ䭩"))
				title = l1l111_l1_ (u"ࠧࠡีํีๆืࠠࠡะสูࠥ࠭䭪")+l1l111_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ䭫")+l1lllllllll_l1_+l1l111_l1_ (u"ࠩࠣࠫ䭬")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩࠬ䭭") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䭮"),headers,l1l111_l1_ (u"ࠬ࠭䭯"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠺ࡺࡨࠨ䭰"))
		items = re.findall(l1l111_l1_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯ࠦ䭱"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠨࠢึ๎ึ็ัࠡฬะ้๏๊ࠠฯษุࠤࠬ䭲")+l1l111_l1_ (u"ࠩࠣࡱࡵ࠺ࠠࠨ䭳")+l1lllllllll_l1_+l1l111_l1_ (u"ࠪࠤࠬ䭴")+resolution.split(l1l111_l1_ (u"ࠫࡽ࠭䭵"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ䭶")+id+l1l111_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭䭷")+mode+l1l111_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ䭸")+hash
			l11llll1ll1l_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l11llll1ll1l_l1_ = set(l11llll1ll1l_l1_)
		l1l11111l111_l1_,l1l11l1l11ll_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠣࠢࠫࡠࡩ࠰ࡸࡽ࡞ࡧ࠮࠮ࠬࠦࠣ䭹"),title+l1l111_l1_ (u"ࠩࠩࠪࠬ䭺"),re.DOTALL)
			for resolution in l11llll1ll1l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠪࡼࠬ䭻"))[1])
			l1l11111l111_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠦࠫࠬࠨ࠯ࠬࡂ࠭࠭ࡢࡤࠫࠫࠩࠪࠧ䭼"),l1l111_l1_ (u"ࠬࠬࠦࠨ䭽")+l1l11111l111_l1_[i]+l1l111_l1_ (u"࠭ࠦࠧࠩ䭾"),re.DOTALL)
			l1l11l1l11ll_l1_.append( [l1l11111l111_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l11l1l11ll_l1_ = sorted(l1l11l1l11ll_l1_, key=lambda x: x[3], reverse=True)
		l1l11l1l11ll_l1_ = sorted(l1l11l1l11ll_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l11l1l11ll_l1_)):
			l1l1lll1_l1_.append(l1l11l1l11ll_l1_[i][0])
			l1llll_l1_.append(l1l11l1l11ll_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ䭿"),[],[]
	return l1l111_l1_ (u"ࠨࠩ䮀"),l1l1lll1_l1_,l1llll_l1_
def l11ll1ll1111_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠩࡂࠫ䮁"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䮂") : l1l111_l1_ (u"ࠫࠬ䮃") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䮄"),headers,l1l111_l1_ (u"࠭ࠧ䮅"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࠺࡚ࡓࡂࡔ࠰࠵ࡸࡺࠧ䮆"))
	items = re.findall(l1l111_l1_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡹࡤ࡭ࡹ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ䮇"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䮈"),[l1l111_l1_ (u"ࠪࠫ䮉")],[url]
def l1l1111ll1ll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䮊") : l1l111_l1_ (u"ࠬ࠭䮋") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ䮌"),headers,l1l111_l1_ (u"ࠧࠨ䮍"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ䮎"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡺࡸ࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䮏"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠪࠫ䮐"),[l1l111_l1_ (u"ࠫࠬ䮑")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡗ࡝࡞࡛ࡘࡌࠨ䮒"),[],[]
def l11ll1ll1ll1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䮓") : l1l111_l1_ (u"ࠧࠨ䮔") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ䮕"),headers,l1l111_l1_ (u"ࠩࠪ䮖"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ䮗"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠤ࠯ࠦ࠭࡮ࡴࡵ࠰࠭ࡃ࠮ࠨࠧ䮘"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠬ࠭䮙"),[l1l111_l1_ (u"࠭ࠧ䮚")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓࠨ䮛"),[],[]
def l1llll1lll1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠨࠩ䮜")
	if l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴࠭䮝") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䮞"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䮟")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䮠"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䮡"),l1l111_l1_ (u"ࠧࠨ䮢"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠳ࡰࡧࠫ䮣"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䮤")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫ䮥"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡁ࠭࠴ࠪࡀࠫࠧࠫ䮦"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠬ࠭䮧"),[l1l111_l1_ (u"࠭ࠧ䮨")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡰࡹ࠯ࠨ䮩") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䮪"),url,l1l111_l1_ (u"ࠩࠪ䮫"),l1l111_l1_ (u"ࠪࠫ䮬"),True,l1l111_l1_ (u"ࠫࠬ䮭"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨ䮮"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䮯") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䮰")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䮱"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠩ࠲ࡺ࠴࠭䮲") in l1lllll1_l1_ or l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䮳") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࡬࠯ࠨ䮴"),l1l111_l1_ (u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫ䮵"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡷ࠱ࠪ䮶"),l1l111_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭䮷"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䮸"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䮹"),l1l111_l1_ (u"ࠪࠫ䮺"),l1l111_l1_ (u"ࠫࠬ䮻"),l1l111_l1_ (u"ࠬ࠭䮼"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠹ࡲࡥࠩ䮽"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤ࡯ࡥࡧ࡫࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䮾"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ䮿"),l1l111_l1_ (u"ࠩࠪ䯀"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䯁"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ䯂"),l1l111_l1_ (u"ࠬ࠭䯃"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ࠧ䯄"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䯅"),[l1l111_l1_ (u"ࠨࠩ䯆")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ䯇"),[],[]
	return l1l111_l1_ (u"ࠪࠫ䯈"),l1l1lll1_l1_,l1llll_l1_
def l1ll1ll11lll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䯉"),url,l1l111_l1_ (u"ࠬ࠭䯊"),l1l111_l1_ (u"࠭ࠧ䯋"),l1l111_l1_ (u"ࠧࠨ䯌"),l1l111_l1_ (u"ࠨࠩ䯍"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩ䯎"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠪࠫ䯏")
	if l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ䯐") in url or l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭䯑") in url:
		if l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ䯒") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯓"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ䯔") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䯕"),[l1l111_l1_ (u"ࠪࠫ䯖")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䯗"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䯘"),l1l111_l1_ (u"࠭ࠧ䯙"),l1l111_l1_ (u"ࠧࠨ䯚"),l1l111_l1_ (u"ࠨࠩ䯛"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠸࡮ࡥࠩ䯜"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࡮ࡸ࠭䯝"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯞"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1lll1lllll1_l1_ in items:
				l1l1lll1_l1_.append(l1lll1lllll1_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡢࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶࠧ䯟") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡵࡳ࡮ࡀࠬ࠳࠰࠿ࠪࠤࠪ䯠"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䯡"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䯢"),l1l111_l1_ (u"ࠩࠪ䯣"),l1l111_l1_ (u"ࠪࠫ䯤"),l1l111_l1_ (u"ࠫࠬ䯥"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬ䯦"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯧"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧࠨ䯨"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨ䯩") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯪"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䯫"),[l1l111_l1_ (u"ࠫࠬ䯬")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑ࡙ࡗ࠹࡛ࠧ䯭"),[],[]
	return l1l111_l1_ (u"࠭ࠧ䯮"),l1l1lll1_l1_,l1llll_l1_
def l1111llll_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ䯯")][0]
	headers = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䯰"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䯱"),url,l1l111_l1_ (u"ࠪࠫ䯲"),headers,l1l111_l1_ (u"ࠫࠬ䯳"),l1l111_l1_ (u"ࠬ࠭䯴"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡅ࠱࠷ࡴࡤࠨ䯵"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䯶"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯷"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䯸"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡪ࡮ࡲࡥ࠻ࠩࠫ࠲࠯ࡅࠩࠨࠤ䯹"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䯺")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠬ࠭䯻"),[l1l111_l1_ (u"࠭ࠧ䯼")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠧ䯽") in html:
		l1l11111llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䯾"),html,re.DOTALL)
		if l1l11111llll_l1_:
			l1ll1ll_l1_ = l1l11111llll_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if kodi_version>18.99: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䯿"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ䰀"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠬࠨ䰁"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䰂")+l1l11l11_l1_
				return l1l111_l1_ (u"࠭ࠧ䰃"),[l1l111_l1_ (u"ࠧࠨ䰄")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䰅"),[l1l111_l1_ (u"ࠩࠪ䰆")],[url]
def l111llll11_l1_(url):
	l111lll1ll_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠪ࠳࠶࠵ࠧ䰇") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴࠷࠯ࠨ䰈"),l1l111_l1_ (u"ࠬ࠵࠴࠰ࠩ䰉"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䰊"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䰋"),l1l111_l1_ (u"ࠨࠩ䰌"),False,l1l111_l1_ (u"ࠩࠪ䰍"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠳ࡶࡸࠬ䰎"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮ࡪࡥࡰࡀࠪ䰏"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰐"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䰑"))
					l111lll1ll_l1_.append(server+l1l111_l1_ (u"ࠧࠡࠢࠪ䰒")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠨࠩ䰓"),l111lll1ll_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠩ࠲ࡨ࠴࠭䰔") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䰕"),url,l1l111_l1_ (u"ࠫࠬ䰖"),l1l111_l1_ (u"ࠬ࠭䰗"),l1l111_l1_ (u"࠭ࠧ䰘"),l1l111_l1_ (u"ࠧࠨ䰙"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠲࡯ࡦࠪ䰚"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰛"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠪ࠳࠶࠵ࠧ䰜"),l1l111_l1_ (u"ࠫ࠴࠺࠯ࠨ䰝"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䰞"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䰟"),l1l111_l1_ (u"ࠧࠨ䰠"),False,l1l111_l1_ (u"ࠨࠩ䰡"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠴ࡴࡧࠫ䰢"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰣"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䰤"),[l1l111_l1_ (u"ࠬ࠭䰥")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ䰦"),[],[]
def l111ll11l1_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䰧"),url,l1l111_l1_ (u"ࠨࠩ䰨"),l1l111_l1_ (u"ࠩࠪ䰩"),l1l111_l1_ (u"ࠪࠫ䰪"),l1l111_l1_ (u"ࠫࠬ䰫"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠵ࡸࡺࠧ䰬"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"࠭ࠢࡢࡥࡷ࡭ࡴࡴࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰭"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"ࠧࡰࡲࡀࠫ䰮")+op+l1l111_l1_ (u"ࠨࠨ࡬ࡨࡂ࠭䰯")+id+l1l111_l1_ (u"ࠩࠩࡪࡳࡧ࡭ࡦ࠿ࠪ䰰")+fname
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䰱"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ䰲")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䰳"),url,data,headers,l1l111_l1_ (u"࠭ࠧ䰴"),l1l111_l1_ (u"ࠧࠨ䰵"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳࠲࡯ࡦࠪ䰶"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡪ࡬ࡥࡳࡧࡵࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰷"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䰸"),[l1l111_l1_ (u"ࠫࠬ䰹")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ䰺"),[],[]
def l11l11l1ll_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䰻"),1)[0].strip(l1l111_l1_ (u"ࠧࡀࠩ䰼")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䰽")).strip(l1l111_l1_ (u"ࠩࠩࠫ䰾"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠪࠫ䰿")
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䱀"):l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬ䱁") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䱂"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䱃"),headers,True,l1l111_l1_ (u"ࠨࠩ䱄"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪ䱅"))
	if l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䱆") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䱇")]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䱈") in l1llllll_l1_:
		if l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䱉") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䱊"),l1l111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䱋"))
		l1l11111ll11_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ䱌"))[1]
		headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䱍"):headers[l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䱎")] , l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䱏"):l1l111_l1_ (u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧ䱐")+l1l11111ll11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱑"),l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ䱒"),headers,False,l1l111_l1_ (u"ࠩࠪ䱓"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭䱔"))
		html = response.content
		if l1l111_l1_ (u"ࠫ࠴࡬࠯ࠨ䱕") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱖"),html,re.DOTALL)
		elif l1l111_l1_ (u"࠭࠯ࡷ࠱ࠪ䱗") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱘"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠨࠩ䱙")],[ items[0] ]
		elif l1l111_l1_ (u"ࠩ࠿࡬࠶ࡄ࠴࠱࠶࠿࠳࡭࠷࠾ࠨ䱚") in html:
			return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣื๏ืแาࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎ࠥ๎ๅึัิ๋๋ࠥๆࠡษ็ษ๋ะั็ฬࠣห้ิวึหࠣฬ่࠭䱛"),[],[]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚ࠧ䱜"),[],[]
def l111lllllll_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䱝"),l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䱞"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮࠮࡯ࡧࡷ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ䱟")+l11l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ䱠")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䱡"):l1l111_l1_ (u"ࠪࠫ䱢") , l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䱣"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䱤") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ䱥"),headers,l1l111_l1_ (u"ࠧࠨ䱦"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰࠵ࡸࡺࠧ䱧"))
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䱨"),[l1l111_l1_ (u"ࠪࠫ䱩")],[l1lllll1_l1_]
def l1lll1l11l11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䱪"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䱫"):server,l1l111_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䱬"):l1l111_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䱭")}
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䱮"),url,l1l111_l1_ (u"ࠩࠪ䱯"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䱰"),l1l111_l1_ (u"ࠫࠬ䱱"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䱲"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ䱳"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠧࠨ䱴")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䱵"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䱶"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࠫ䱷"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䱸"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡆࡍࡒࡇࠧ䱹"),[],[]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䱺"),[l1l111_l1_ (u"ࠧࠨ䱻")],[l1lllll1_l1_]
def l1ll1l1111ll_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䱼"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䱽"):server,l1l111_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ䱾"):l1l111_l1_ (u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫ䱿")}
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲀"),url,l1l111_l1_ (u"࠭ࠧ䲁"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䲂"),l1l111_l1_ (u"ࠨࠩ䲃"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ䲄"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ䲅"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠫࠬ䲆")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䲇"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ䲈"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠧࠨ䲉"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲊"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄࠫ䲋"),[],[]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䲌"),[l1l111_l1_ (u"ࠫࠬ䲍")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䲎"),l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䲏"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤࠨ䲐"):l11l1l11_l1_,l1l111_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ䲑"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䲒"),url,data,l1l111_l1_ (u"ࠪࠫ䲓"),l1l111_l1_ (u"ࠫࠬ䲔"),l1l111_l1_ (u"ࠬ࠭䲕"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ䲖"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲗"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䲘"),[l1l111_l1_ (u"ࠩࠪ䲙")],[l1lllll1_l1_]
def l111111ll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䲚"),url,l1l111_l1_ (u"ࠫࠬ䲛"),l1l111_l1_ (u"ࠬ࠭䲜"),l1l111_l1_ (u"࠭ࠧ䲝"),l1l111_l1_ (u"ࠧࠨ䲞"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫ䲟"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲠"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䲡"),[l1l111_l1_ (u"ࠫࠬ䲢")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ䲣"),[],[]
def l1111l111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲤"),url,l1l111_l1_ (u"ࠧࠨ䲥"),l1l111_l1_ (u"ࠨࠩ䲦"),l1l111_l1_ (u"ࠩࠪ䲧"),l1l111_l1_ (u"ࠪࠫ䲨"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡑ࠯࠴ࡷࡹ࠭䲩"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡉࡇࡔࡄࡑࡊࠦࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲪"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䲫"),[l1l111_l1_ (u"ࠧࠨ䲬")],[l1ll1ll_l1_]
def l1111111l_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䲭"))
	if l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ䲮") in url:
		headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䲯"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䲰"),url,l1l111_l1_ (u"ࠬ࠭䲱"),headers,l1l111_l1_ (u"࠭ࠧ䲲"),l1l111_l1_ (u"ࠧࠨ䲳"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ䲴"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䲵"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䲶") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭䲷"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䲸"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲹"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䲺"),headers,l1l111_l1_ (u"ࠨࠩ䲻"),l1l111_l1_ (u"ࠩࠪ䲼"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ䲽"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲾"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䲿"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䳀")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"ࠧࠨ䳁"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䳂"),[l1l111_l1_ (u"ࠩࠪ䳃")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䳄")+l11l11111_l1_
	return l1l111_l1_ (u"ࠫࠬ䳅"),[l1l111_l1_ (u"ࠬ࠭䳆")],[l1lllll1_l1_]
def l1l11111111l_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䳇"))
	if l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ䳈") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䳉"),l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䳊"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠪ࡭ࡩ࠭䳋"):l11l1l11_l1_,l1l111_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ䳌"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䳍"),url,data,l1l111_l1_ (u"࠭ࠧ䳎"),l1l111_l1_ (u"ࠧࠨ䳏"),l1l111_l1_ (u"ࠨࠩ䳐"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ䳑"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䳒"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䳓") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䳔"):l11l11111_l1_,l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䳕"):l1l111_l1_ (u"ࠧࠨ䳖")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䳗"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䳘"),headers,l1l111_l1_ (u"ࠪࠫ䳙"),l1l111_l1_ (u"ࠫࠬ䳚"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭䳛"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䳜"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䳝"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䳞")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠩࠪ䳟"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䳠"),[l1l111_l1_ (u"ࠫࠬ䳡")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䳢")+l11l11111_l1_
		return l1l111_l1_ (u"࠭ࠧ䳣"),[l1l111_l1_ (u"ࠧࠨ䳤")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ䳥") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䳦"),l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䳧"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䳨"))
		url = host+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ䳩")+l11l1l11_l1_+l1l111_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䳪")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䳫"):l1l111_l1_ (u"ࠨࠩ䳬") , l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䳭"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䳮") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䳯"),headers,l1l111_l1_ (u"ࠬ࠭䳰"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠶ࡹࡴࠨ䳱"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ䳲"),l1l111_l1_ (u"ࠨࠩ䳳")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ䳴"),l1l111_l1_ (u"ࠪࠫ䳵"))
		return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䳶"),[l1l111_l1_ (u"ࠬ࠭䳷")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ䳸") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ䳹") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䳺"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䳻"),l1l111_l1_ (u"ࠪࠫ䳼"),l1l111_l1_ (u"ࠫࠬ䳽"),l1l111_l1_ (u"ࠬ࠭䳾"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠷ࡴࡤࠨ䳿"))
			if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䴀") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䴁")]
			counts += 1
		return l1l111_l1_ (u"ࠩࠪ䴂"),[l1l111_l1_ (u"ࠪࠫ䴃")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ䴄"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䴅"))
	if l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ䴆") in url and l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䴇") not in url: url = server+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ䴈")+url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䴉"))[-1]+l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ䴊")
	headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䴋"):server,l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䴌"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"࠭࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ䴍") in url:
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䴎"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䴏")}
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䴐"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠪࠫ䴑"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠴ࡷࡹ࠭䴒"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠬࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䴓"),html,re.DOTALL|re.IGNORECASE)
		if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࠧ䴔"),[l1l111_l1_ (u"ࠧࠨ䴕")],[l1ll1ll_l1_[0]]
	elif l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ䴖") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ䴗"),headers,l1l111_l1_ (u"ࠪࠫ䴘"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭䴙"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䴚"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ䴛"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䴜"))
			return l1l111_l1_ (u"ࠨࠩ䴝"),[l1l111_l1_ (u"ࠩࠪ䴞")],[l1ll1ll_l1_]
	else:
		l1l111ll111l_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䴟"),url,l1l111_l1_ (u"ࠫࠬ䴠"),headers,l1l111_l1_ (u"ࠬ࠭䴡"),l1l111_l1_ (u"࠭ࠧ䴢"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ䴣"))
		html = l1l111ll111l_l1_.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ䴤"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠩࠩࡨࡂ࠷ࠧ䴥")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䴦"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䴧"),headers,l1l111_l1_ (u"ࠬ࠭䴨"),l1l111_l1_ (u"࠭ࠧ䴩"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩ䴪"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䴫"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠩࠪ䴬"),[l1l111_l1_ (u"ࠪࠫ䴭")],[l1ll1ll_l1_]
		if l1l111_l1_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ䴮") in list(l1l111ll111l_l1_.headers.keys()):
			cookies = l1l111ll111l_l1_.headers[l1l111_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ䴯")]
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡟࡭ࡰ࡮ࡣ࠳࠰࠿࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ䴰"),cookies,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䴱"),[l1l111_l1_ (u"ࠨࠩ䴲")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡕࡈࡉࡉ࠭䴳"),[],[]
def l1ll11lll1ll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠪࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠧ䴴") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䴵"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䴶")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䴷"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䴸"),headers,l1l111_l1_ (u"ࠨࠩ䴹"),l1l111_l1_ (u"ࠩࠪ䴺"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬ䴻"))
		url = response.content
		if url: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䴼"),[l1l111_l1_ (u"ࠬ࠭䴽")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ䴾"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠧࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪ䴿"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵀"))
		url = server+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ䵁")
		data = {l1l111_l1_ (u"ࠪ࡭ࡩ࠭䵂"):l11l1l11_l1_,l1l111_l1_ (u"ࠫ࡮࠭䵃"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䵄"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䵅"),l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䵆"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䵇"),url,data,headers,l1l111_l1_ (u"ࠩࠪ䵈"),l1l111_l1_ (u"ࠪࠫ䵉"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠵ࡲࡩ࠭䵊"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䵋"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䵌"),[l1l111_l1_ (u"ࠧࠨ䵍")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ䵎"),[],[]
def l1l111l1l1l1_l1_(l11ll1llll11_l1_):
	l1l1111l1l1l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡶࡸࡷ࠭䵏"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䵐"),l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࡢ࡚ࡊࡘࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠩ䵑"))
	headers = {l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䵒"):l1l1111l1l1l_l1_} if l1l1111l1l1l_l1_ else l1l111_l1_ (u"࠭ࠧ䵓")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䵔"),l11ll1llll11_l1_,l1l111_l1_ (u"ࠨࠩ䵕"),headers,l1l111_l1_ (u"ࠩࠪ䵖"),l1l111_l1_ (u"ࠪࠫ䵗"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠲ࡵࡷࠫ䵘"))
	l11lllll1lll_l1_ = response.content
	l1l111llllll_l1_ = str(response.headers)
	l11ll1ll111l_l1_ = l1l111llllll_l1_+l11lllll1lll_l1_
	if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䵙") in l11ll1ll111l_l1_: found = True
	else:
		l11lll1ll1ll_l1_,token,l11ll1ll1l1l_l1_,l11llll1l11l_l1_,found = l1l111_l1_ (u"࠭ࠧ䵚"),l1l111_l1_ (u"ࠧࠨ䵛"),l1l111_l1_ (u"ࠨࠩ䵜"),l1l111_l1_ (u"ࠩࠪ䵝"),False
		l11lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䵞"),l11lllll1lll_l1_,re.DOTALL)
		if l11lll1l1l1l_l1_: l11ll1ll1l1l_l1_,l11llll1l11l_l1_ = l11lll1l1l1l_l1_[0]
		l11lll1l1ll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䵟")][7]
		user = l1l1ll1l11l_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵠"):user,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵡"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵢"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵣"):l11llll1l11l_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䵤"):l1l111_l1_ (u"ࠪࠫ䵥"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵦"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭䵧")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵨"),l11lll1l1ll1_l1_,data,l1l111_l1_ (u"ࠧࠨ䵩"),l1l111_l1_ (u"ࠨࠩ䵪"),l1l111_l1_ (u"ࠩࠪ䵫"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠲࡯ࡦࠪ䵬"))
			html = response.content
		html = l1l111_l1_ (u"ࠫࠬ䵭")
		if html.startswith(l1l111_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ䵮")):
			l1l1l1l1ll11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䵯"),html.split(l1l111_l1_ (u"ࠧࡖࡔࡏࡗࡂ࠭䵰"),1)[1])
			for request in l1l1l1l1ll11_l1_:
				url = request[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵱")]
				method = request[l1l111_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࠩ䵲")]
				data = request[l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ䵳")]
				headers = request[l1l111_l1_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬ䵴")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠬ࠭䵵"),l1l111_l1_ (u"࠭ࠧ䵶"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ䵷"))
				l11lllll1lll_l1_ = response.content
				if l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䵸") in l11lllll1lll_l1_:
					found = True
					break
				l1l111llllll_l1_ = str(response.headers)
				l11ll1ll111l_l1_ = l1l111llllll_l1_+l11lllll1lll_l1_
				l11lll1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ䵹"),l11ll1ll111l_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫ䵺"),l11ll1ll111l_l1_,re.DOTALL)
				if token: token = token[0]
				if l11lll1ll1ll_l1_ or token: break
		if not found:
			if not l11lll1ll1ll_l1_:
				if not token and l11lll1l1l1l_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠫࡎࡊ࠽ࠨ䵻")):
						data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵼"):user,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵽"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵾"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵿"):l11llll1l11l_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䶀"):l1l111_l1_ (u"ࠪࠫ䶁"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䶂"):l1l111_l1_ (u"ࠬ࡭ࡥࡵ࡫ࡧࠫ䶃")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䶄"),l11lll1l1ll1_l1_,data,l1l111_l1_ (u"ࠧࠨ䶅"),l1l111_l1_ (u"ࠨࠩ䶆"),l1l111_l1_ (u"ࠩࠪ䶇"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠴ࡵࡪࠪ䶈"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠫࡎࡊ࠽࠲࠴࠶࠸࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿࠷࠹ࠬ䶉")
					if html.startswith(l1l111_l1_ (u"ࠬࡏࡄ࠾ࠩ䶊")):
						l11ll1lll11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡉࡅ࠿ࠫ࠲࠯ࡅࠩ࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠮࠮ࠫࡁࠬࠨࠬ䶋"),html,re.DOTALL)
						l1l11l11llll_l1_,l1l111ll11l_l1_ = l11ll1lll11l_l1_[0]
						message = l1l111_l1_ (u"่ࠧา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤํ่สࠡ็้ࠤ࠶࠶ࠠฦๆ์ࠤࠬ䶌")+l1l111ll11l_l1_+l1l111_l1_ (u"ࠨࠢฮห๋๐ษࠨ䶍")
						l1l111l111_l1_ = l1l11l1111_l1_()
						l1l111l111_l1_.create(l1l111_l1_ (u"่ࠩัฬ๎ไสࠢอะฬ๎าࠡใะูࠥษๆศࠢฦุ๊อๆ๊ࠡ็ืฯࠦศา่ส้ัࠦใ้็ห๎ํะัࠨ䶎"),message)
						t1 = time.time()
						l11lllllll11_l1_,l11lll11l11l_l1_ = 0,0
						while l11lllllll11_l1_<int(l1l111ll11l_l1_):
							l1l1111l11_l1_(l1l111l111_l1_,int(l11lllllll11_l1_/int(l1l111ll11l_l1_)*100),message,l1l111_l1_ (u"ࠪࠫ䶏"),l1l111ll11l_l1_+l1l111_l1_ (u"ࠫࠥ࠵ࠠࠨ䶐")+str(int(l11lllllll11_l1_))+l1l111_l1_ (u"ࠬࠦࠠฬษ้๎ฮ࠭䶑"))
							if l11lllllll11_l1_>l11lll11l11l_l1_+10:
								data = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ䶒"):user,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䶓"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䶔"):l11ll1llll11_l1_,l1l111_l1_ (u"ࠩ࡮ࡩࡾ࠭䶕"):l11llll1l11l_l1_,l1l111_l1_ (u"ࠪ࡭ࡩ࠭䶖"):l1l11l11llll_l1_,l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䶗"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡶࡲ࡯ࡪࡴࠧ䶘")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䶙"),l11lll1l1ll1_l1_,data,l1l111_l1_ (u"ࠧࠨ䶚"),l1l111_l1_ (u"ࠨࠩ䶛"),l1l111_l1_ (u"ࠩࠪ䶜"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ䶝"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"࡙ࠫࡕࡋࡆࡐࡀࠫ䶞")):
									token = html.split(l1l111_l1_ (u"࡚ࠬࡏࡌࡇࡑࡁࠬ䶟"),1)[1]
									break
								l11lll11l11l_l1_ = l11lllllll11_l1_
							else: time.sleep(1)
							l11lllllll11_l1_ = time.time()-t1
						l1l111l111_l1_.close()
				if token:
					l11ll1lll1ll_l1_ = response.cookies
					l1l1ll11lll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭䶠"),l11ll1ll111l_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ䶡") in list(l11ll1lll1ll_l1_.keys()): l1l1ll11lll1_l1_ = l11ll1lll1ll_l1_[l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ䶢")]
					elif l1l1ll11lll1_l1_: l1l1ll11lll1_l1_ = l1l1ll11lll1_l1_[0]
					l11lll1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䶣"),l11lllll1lll_l1_,re.DOTALL)
					if l11lll1l1l1l_l1_: l11ll1ll1l1l_l1_,l11llll1l11l_l1_ = l11lll1l1l1l_l1_[0]
					if l1l1ll11lll1_l1_ and l11lll1l1l1l_l1_:
						headers = {l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䶤"):l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬ䶥")+l1l1ll11lll1_l1_,l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䶦"):l11ll1llll11_l1_,l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䶧"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䶨")}
						data = l1l111_l1_ (u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ䶩")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䶪"),l11ll1ll1l1l_l1_,data,headers,False,l1l111_l1_ (u"ࠪࠫ䶫"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫ䶬"))
						l11lllll1lll_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l11lll1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ䶭"),str(cookies),re.DOTALL)
			if l11lll1ll1ll_l1_:
				name,l11lll1ll1ll_l1_ = l11lll1ll1ll_l1_[0]
				l1l1111l1l1l_l1_ = name+l1l111_l1_ (u"࠭࠽ࠨ䶮")+l11lll1ll1ll_l1_
				l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䶯"),l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࡟ࡗࡇࡕࡍࡋࡏࡃࡂࡖࡌࡓࡓ࠭䶰"),l1l1111l1l1l_l1_,l1ll111l1l1_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䶱"),l1l111_l1_ (u"ࠪࠫ䶲"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䶳"),l1l111_l1_ (u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢไัฺࠦร็ษࠣษู๋ว็ࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮฮำ่๊ࠣฯอฦอ๊ࠢิฬࠦวๅใะู๊ࠥใ๋ࠢํืฯิฯๆ้สࠤ้ออใษࠣ࠲࠳่ࠦๅษࠣฮําฯࠡฯสะฮࠦไฦ฻สำฮࠦ็ัษࠣห้็อึࠢ็฽ิฯࠠฤึ๊ีࠥࡢ࡮࡝ࡰࠣ฽้๋วࠡล้ࠤ์ึวࠡษ็ๅา฻ࠠิ๊ไࠤ๏ะใาำࠣๅ๏ࠦอศๆฬࠤฯเ๊าࠢิฬ฼ࠦวๅฮ๊หืࠦศศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡวฺๅฬวࠠาษ๋ฮึࠦวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠโื็ࠤุ๊ใࠡษ็ีฬ๎สาࠢ࠱࠲ࠥษ่ࠡษึฮำีวๆ࡙ࠢࡔࡓࠦร้ࠢหีํ้ำ๋ࠩ䶴"))
				if l1l111_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ䶵") not in l11lllll1lll_l1_:
					headers = {l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ䶶"):l1l1111l1l1l_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䶷"),l11ll1llll11_l1_,l1l111_l1_ (u"ࠩࠪ䶸"),headers,l1l111_l1_ (u"ࠪࠫ䶹"),l1l111_l1_ (u"ࠫࠬ䶺"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬ䶻"))
					l11lllll1lll_l1_ = response.content
	if not found and not l1l1111l1l1l_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䶼"),l1l111_l1_ (u"ࠧࠨ䶽"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䶾"),l1l111_l1_ (u"ࠩ฼้้๐ษࠡใะูࠥษๆศࠢฦุ๊อๆࠡใื่ฯࠦ࠮࠯ࠢะหํ๊ࠠฦ฻สำฮࠦวๅ฻่่๏ฯࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤ๋็ำࠡษ็ๅ๏ี๊้ࠢฦ์ࠥ็๊ะ์๋ࠤ฿๐ั่่๊ࠢࠥ์แิࠢส่๊๎โฺࠩ䶿"))
	return l11lllll1lll_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111lll1ll_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䷀"),url,l1l111_l1_ (u"ࠫࠬ䷁"),l1l111_l1_ (u"ࠬ࠭䷂"),l1l111_l1_ (u"࠭ࠧ䷃"),l1l111_l1_ (u"ࠧࠨ䷄"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ䷅"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠽࠱ࡤࡂࠬ䷆"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ䷇"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ䷈") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ䷉") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"࠭࠼࠰ࡵࡳࡥࡳࡄࠧ䷊"),l1l111_l1_ (u"ࠧࠨ䷋")).replace(l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䷌"),l1l111_l1_ (u"ࠩࠪ䷍")).strip(l1l111_l1_ (u"ࠪࠤࠬ䷎")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䷏"),l1l111_l1_ (u"ࠬࠦࠧ䷐"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111lll1ll_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭䷑"),l111lll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ䷒"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ䷓"),[],[]
	l11ll1llll11_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l11lllll1lll_l1_ = l1l111l1l1l1_l1_(l11ll1llll11_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䷔"):
		l1l111l1111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷕"),l11lllll1lll_l1_,re.DOTALL)
		if l1l111l1111l_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l111l1111l_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ䷖"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷗"),l11lllll1lll_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ䷘"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䷙"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䷚"),url,l1l111_l1_ (u"ࠩࠪ䷛"),l1l111_l1_ (u"ࠪࠫ䷜"),True,l1l111_l1_ (u"ࠫࠬ䷝"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫ䷞"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭䷟") in list(cookies.keys()):
		l1l1111l1l1l_l1_ = cookies[l1l111_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ䷠")]
		l1l1111l1l1l_l1_ = l111l11_l1_(escapeUNICODE(l1l1111l1l1l_l1_))
		items = re.findall(l1l111_l1_ (u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䷡"),l1l1111l1l1l_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䷢"),l1l111_l1_ (u"ࠪ࠳ࠬ䷣"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭䷤") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠬࠫ࠲ࡇࠩ䷥"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩ䷦")+id
		return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䷧"),[l1l111_l1_ (u"ࠨࠩ䷨")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䷩")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䷪"),l1l11l11_l1_,l1l111_l1_ (u"ࠫࠬ䷫"),l1l111_l1_ (u"ࠬ࠭䷬"),True,l1l111_l1_ (u"࠭ࠧ䷭"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭䷮"))
		l11llll1l111_l1_ = response.url
		l1l11l11ll11_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ䷯"))[2]
		l1l11l1ll11l_l1_ = l11llll1l111_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䷰"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l11l11ll11_l1_,l1l11l1ll11l_l1_)
		headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䷱"):l1l111_l1_ (u"ࠫࠬ䷲") , l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䷳"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䷴") , l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䷵"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䷶"), l1llllll_l1_, l1l111_l1_ (u"ࠩࠪ䷷"), headers, False,l1l111_l1_ (u"ࠪࠫ䷸"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪ䷹"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䷺"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷻"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷼"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ䷽"),l1l111_l1_ (u"ࠩ࠲ࠫ䷾"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠪ࠳ࠬ䷿"))
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ一") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ丁") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ丂"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ七"))
			if name==l1l111_l1_ (u"ࠨࠩ丄"): l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ丅"),[l1l111_l1_ (u"ࠪࠫ丆")],[l1ll1ll_l1_]
			else: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ万"),[l1l111_l1_ (u"ࠬ࠭丈")],[l1ll1ll_l1_]
		else: l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧ三"),[],[]
		return l1l111llll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll11ll11_l1_(url):
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ上") : l1l111_l1_ (u"ࠨࠩ下") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ丌"),headers,l1l111_l1_ (u"ࠪࠫ不"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ与"))
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丏"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"࠭ࠧ丐")
	if items:
		for l1ll1ll_l1_,l1lll1lllll1_l1_ in items:
			l1l1lll1_l1_.append(l1lll1lllll1_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭丑"),[],[]
	return l1l111_l1_ (u"ࠨࠩ丒"),l1l1lll1_l1_,l1llll_l1_
def l1l111111l1l_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ专"),l1l111_l1_ (u"ࠪࠫ且"))
	headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ丕"):l1l111_l1_ (u"ࠬ࠭世")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ丗"),headers,l1l111_l1_ (u"ࠧࠨ丘"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ丙"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ业"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭丛")+url
		return l1l111_l1_ (u"ࠫࠬ东"),[l1l111_l1_ (u"ࠬ࠭丝")],[url]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨ丞"),[],[]
def l11lllll1l1l_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩ丟"))
	if l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ丠") in url: id = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ両"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ丢"))[-1]
	url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ丣") + id
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ两") : l1l111_l1_ (u"࠭ࠧ严") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ並"),headers,l1l111_l1_ (u"ࠨࠩ丧"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡃࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ丨"))
	html = html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭丩"),l1l111_l1_ (u"ࠫࠬ个"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ丫"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ丬"),[l1l111_l1_ (u"ࠧࠨ中")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ丮"),[],[]
def l11llll111ll_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ丯"),l1l111_l1_ (u"ࠪࠫ丰"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ丱"),l1l111_l1_ (u"ࠬ࠭串"),l1l111_l1_ (u"࠭ࠧ丳"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧ临"))
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ丵"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1lll1lllll1_l1_,res in items:
		l1l1lll1_l1_.append(l1lll1lllll1_l1_+l1l111_l1_ (u"ࠩࠣࠫ丶")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬ丷"),[],[]
	return l1l111_l1_ (u"ࠫࠬ丸"),l1l1lll1_l1_,l1llll_l1_
def l1l11111ll1l_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ丹"),l1l111_l1_ (u"࠭ࠧ为"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ主"),l1l111_l1_ (u"ࠨࠩ丼"),l1l111_l1_ (u"ࠩࠪ丽"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ举"))
	items = re.findall(l1l111_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ丿"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1lll1lllll1_l1_,res in items:
		url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ乀")+id+l1l111_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭乁")+mode+l1l111_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ乂")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ乃"),l1l111_l1_ (u"ࠩࠪ乄"),l1l111_l1_ (u"ࠪࠫ久"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ乆"))
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ乇"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1lll1lllll1_l1_+l1l111_l1_ (u"࠭ࠠࠨ么")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭义"),[],[]
	return l1l111_l1_ (u"ࠨࠩ乊"),l1l1lll1_l1_,l1llll_l1_
def l11lll1l1l11_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠩࠪ之")
	if 1 or l1l111_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ乌") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ乍"),l1l111_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ乎"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ乏"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ乐").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ乑"):id,l1l111_l1_ (u"ࠩࡲࡴࠬ乒"):l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭乓"),l1l111_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ乔"):l1l111_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ乕")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ乖"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠧࠨ乗"),l1l111_l1_ (u"ࠨࠩ乘"),l1l111_l1_ (u"ࠩࠪ乙"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ乚"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭乛") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ乜")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ九"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ乞"),url,l1l111_l1_ (u"ࠨࠩ也"),l1l111_l1_ (u"ࠩࠪ习"),l1l111_l1_ (u"ࠪࠫ乡"),l1l111_l1_ (u"ࠫࠬ乢"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠳ࡰࡧࠫ乣"))
		if l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ乤") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ乥")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࠩ书"),[l1l111_l1_ (u"ࠩࠪ乧")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫ乨"),[],[]
def l11lllllll1l_l1_(url):
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ乩") : l1l111_l1_ (u"ࠬ࠭乪") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ乫"),headers,l1l111_l1_ (u"ࠧࠨ乬"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ乭"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨ乮"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠧ乯"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ买"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠬ࠭乱"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪ乲"),[],[]
def l11lll1l1ll_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ乳"))[-1]
	id = id.split(l1l111_l1_ (u"ࠨࠨࠪ乴"))[0]
	id = id.replace(l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ乵"),l1l111_l1_ (u"ࠪࠫ乶"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ乷")][0]+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ乸")+id
	l11lll1ll1l1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩ乹")+id
	l1l111l1ll11_l1_,l11llll11111_l1_,l1l1111l1l11_l1_,l11lllll1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ乺"),l1l111_l1_ (u"ࠨࠩ乻"),l1l111_l1_ (u"ࠩࠪ乼"),l1l111_l1_ (u"ࠪࠫ乽")
	for l1l11l111l_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ乾"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭乿"),l1l111_l1_ (u"࠭ࠧ亀"),l1l111_l1_ (u"ࠧࠨ亁"),l1l111_l1_ (u"ࠨࠩ亂"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ亃"))
		html = response.content
		if l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ亄") in html: break
		time.sleep(2)
	l1l1l111l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ亅"),html,re.DOTALL)
	if l1l1l111l1_l1_: l1l1l111l1_l1_ = l1l1l111l1_l1_[0]
	else: l1l1l111l1_l1_ = html
	l1l1l111l1_l1_ = l1l1l111l1_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭了"),l1l111_l1_ (u"࠭ࠦࠨ亇"))
	l1l111llll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ予"),l1l1l111l1_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬ争")],[l1l111_l1_ (u"ࠩࠪ亊")]
	try:
		l1l11l1l1lll_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ事")][l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ二")][l1l111_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ亍")]
		for l1l11111l1ll_l1_ in l1l11l1l1lll_l1_:
			l1ll1ll_l1_ = l1l11111l1ll_l1_[l1l111_l1_ (u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ于")]
			try: title = l1l11111l1ll_l1_[l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ亏")][l1l111_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬ亐")]
			except: title = l1l11111l1ll_l1_[l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ云")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ互")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ亓")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ五"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ井"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠧࠧࠩ亖")
			l1l111111111_l1_ = re.findall(l1l111_l1_ (u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭亗"),l1ll1ll_l1_)
			if l1l111111111_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111111111_l1_[0],l1l111_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ亘"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ亙")
			l1l111l1ll11_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭亚"))
	formats,l1l111lllll1_l1_,l11lll1l1111_l1_,l11lll1l111l_l1_,l11lll11llll_l1_ = [],[],[],[],[]
	try: l11llll11111_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ些")][l1l111_l1_ (u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ亜")]
	except: pass
	try: l1l1111l1l11_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ亝")][l1l111_l1_ (u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ亞")]
	except: pass
	try: formats = l1l111llll1l_l1_[l1l111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ亟")][l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ亠")]
	except: pass
	try: l1l111lllll1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ亡")][l1l111_l1_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧ亢")]
	except: pass
	l1l111l1l1ll_l1_ = formats+l1l111lllll1_l1_
	for dict in l1l111l1l1ll_l1_:
		if l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ亣") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ交")] = str(dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭亥")])
		if l1l111_l1_ (u"ࠩࡩࡴࡸ࠭亦") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ产")] = str(dict[l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ亨")])
		if l1l111_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ亩") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ亪")] = dict[l1l111_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ享")]
		if l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ京") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭亭")] = str(dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ亮")])
		if l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ亯") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亰")] = str(dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亱")])
		if l1l111_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭亲") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭亳")] = str(dict[l1l111_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ亴")])+l1l111_l1_ (u"ࠪࡼࠬ亵")+str(dict[l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ亶")])
		if l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ亷") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ亸")] = dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ亹")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ人")]+l1l111_l1_ (u"ࠩ࠰ࠫ亻")+dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭亼")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ亽")]
		if l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ亾") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ亿")] = dict[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ什")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ仁")]+l1l111_l1_ (u"ࠩ࠰ࠫ仂")+dict[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ仃")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ仄")]
		if l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭仅") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ仆")] = dict[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ仇")]
		if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ仈") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ仉")])>111222333: del dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ今")]
		if l1l111_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭介") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ仌")].split(l1l111_l1_ (u"࠭ࠦࠨ仍"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ从"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仏") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仐")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ仑")])
		l11lll1l1111_l1_.append(dict)
	l1l1111ll111_l1_ = l1l111_l1_ (u"ࠫࠬ仒")
	if l1l111_l1_ (u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ仓") in l1l1l111l1_l1_:
		l1l111ll1l11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ仔"),html,re.DOTALL)
		if l1l111ll1l11_l1_:
			l1l111ll1l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ仕")][0]+l1l111ll1l11_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ他"),l1l111ll1l11_l1_,l1l111_l1_ (u"ࠩࠪ仗"),l1l111_l1_ (u"ࠪࠫ付"),l1l111_l1_ (u"ࠫࠬ仙"),l1l111_l1_ (u"ࠬ࠭仚"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ仛"))
			l1l1111ll111_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11ll1lllll1_l1_ = cipher._load_javascript(l1l1111ll111_l1_)
			l11lll1lll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ仜"),str(l11ll1lllll1_l1_))
			l11lll111111_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l11lll1lll1l_l1_)
	for dict in l11lll1l1111_l1_:
		url = dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仝")]
		if l1l111_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭仞") in url or url.count(l1l111_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ仟"))>1:
			l11lll1l111l_l1_.append(dict)
		elif l1l1111ll111_l1_ and l1l111_l1_ (u"ࠫࡸ࠭仠") in list(dict.keys()) and l1l111_l1_ (u"ࠬࡹࡰࠨ仡") in list(dict.keys()):
			l1l11111l11l_l1_ = l11lll111111_l1_.execute(dict[l1l111_l1_ (u"࠭ࡳࠨ仢")])
			if l1l11111l11l_l1_!=dict[l1l111_l1_ (u"ࠧࡴࠩ代")]:
				dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ令")] = url+l1l111_l1_ (u"ࠩࠩࠫ以")+dict[l1l111_l1_ (u"ࠪࡷࡵ࠭仦")]+l1l111_l1_ (u"ࠫࡂ࠭仧")+l1l11111l11l_l1_
				l11lll1l111l_l1_.append(dict)
	for dict in l11lll1l111l_l1_:
		l111lll_l1_,l11lll111ll1_l1_,l1l11l1l1l11_l1_,l1l1l1ll1_l1_,codecs,l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭仨"),l1l111_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ仩"),l1l111_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ仪"),l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ仫"),l1l111_l1_ (u"ࠩࠪ们"),l1l111_l1_ (u"ࠪ࠴ࠬ仭")
		try:
			l11lll1l11l1_l1_ = dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ仮")]
			l11lll1l11l1_l1_ = l11lll1l11l1_l1_.replace(l1l111_l1_ (u"ࠬ࠱ࠧ仯"),l1l111_l1_ (u"࠭ࠧ仰"))
			items = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ仱"),l11lll1l11l1_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l111ll11l1_l1_ = codecs.split(l1l111_l1_ (u"ࠨ࠮ࠪ仲"))
			l11lll111ll1_l1_ = l1l111_l1_ (u"ࠩࠪ仳")
			for item in l1l111ll11l1_l1_: l11lll111ll1_l1_ += item.split(l1l111_l1_ (u"ࠪ࠲ࠬ仴"))[0]+l1l111_l1_ (u"ࠫ࠱࠭仵")
			l11lll111ll1_l1_ = l11lll111ll1_l1_.strip(l1l111_l1_ (u"ࠬ࠲ࠧ件"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ价") in list(dict.keys()): l11ll1l11ll_l1_ = str(float(dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ仸")]*10)//1024/10)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ仹")
			else: l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠩࠪ仺")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨ任"): continue
			elif l1l111_l1_ (u"ࠫ࠱࠭仼") in l11lll1l11l1_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ份")
				l1l11l1l1l11_l1_ = l111lll_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ仾")+l11ll1l11ll_l1_+dict[l1l111_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ仿")].split(l1l111_l1_ (u"ࠨࡺࠪ伀"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ企"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ伂")
				l1l11l1l1l11_l1_ = l11ll1l11ll_l1_+dict[l1l111_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ伃")].split(l1l111_l1_ (u"ࠬࡾࠧ伄"))[1]+l1l111_l1_ (u"࠭ࠠࠡࠩ伅")+dict[l1l111_l1_ (u"ࠧࡧࡲࡶࠫ伆")]+l1l111_l1_ (u"ࠨࡨࡳࡷࠬ伇")+l1l111_l1_ (u"ࠩࠣࠤࠬ伈")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ伉"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ伊")
				l1l11l1l1l11_l1_ = l11ll1l11ll_l1_+str(int(dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ伋")])/1000)+l1l111_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ伌")+dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ伍")]+l1l111_l1_ (u"ࠨࡥ࡫ࠫ伎")+l1l111_l1_ (u"ࠩࠣࠤࠬ伏")+l111lll_l1_
		except:
			l1111llll11_l1_ = traceback.format_exc()
			sys.stderr.write(l1111llll11_l1_)
		if l1l111_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ伐") in dict[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ休")]: l1l1lll1ll_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ伒")].split(l1l111_l1_ (u"࠭ࡤࡶࡴࡀࠫ伓"),1)[1].split(l1l111_l1_ (u"ࠧࠧࠩ伔"),1)[0]))
		elif l1l111_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ伕") in list(dict.keys()): l1l1lll1ll_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ伖")])/1000)
		else: l1l1lll1ll_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ众")
		if l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ优") not in list(dict.keys()): l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠬࡹࡩࡻࡧࠪ伙")].split(l1l111_l1_ (u"࠭ࡸࠨ会"))[1]
		else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伛")]
		if l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭伜") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ伝")] = l1l111_l1_ (u"ࠪ࠴࠲࠶ࠧ伞")
		dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ伟")] = l1l1l1ll1_l1_+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ传")+l1l11l1l1l11_l1_+l1l111_l1_ (u"࠭ࠠࠡࠪࠪ伡")+l11lll111ll1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ伢")+dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭伣")]+l1l111_l1_ (u"ࠩࠬࠫ伤")
		dict[l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ伥")] = l1l11l1l1l11_l1_.split(l1l111_l1_ (u"ࠫࠥࠦࠧ伦"))[0].split(l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ伧"))[0]
		dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伨")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伩")] = l111lll_l1_
		dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ伪")] = codecs
		dict[l1l111_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ伫")] = l1l1lll1ll_l1_
		dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ伬")] = l11ll1l11ll_l1_
		l11lll11llll_l1_.append(dict)
	l1l111l1l111_l1_,l11llllllll1_l1_,l1l11l11l1l1_l1_,l1l11l1l1111_l1_,l11ll1ll11l1_l1_ = [],[],[],[],[]
	l1l111ll11ll_l1_,l11lll1ll11l_l1_,l11lll1lll11_l1_,l1l111ll1111_l1_,l1l11l1111ll_l1_ = [],[],[],[],[]
	if l11llll11111_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ伭")] = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ伮")
		dict[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ伯")] = l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ估")
		dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ伱")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ伲")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ伳")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭伴")]+l1l111_l1_ (u"ࠬࠦࠠࠨ伵")+l1l111_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ伶")
		dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ伷")] = l11llll11111_l1_
		dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ伸")] = l1l111_l1_ (u"ࠩ࠳ࠫ伹")
		dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ伺")] = l1l111_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ伻")
		l11lll11llll_l1_.append(dict)
	if l1l1111l1l11_l1_:
		l1l111lll111_l1_,l11lllll111l_l1_ = l1l11l1ll1_l1_(l1l1111l1l11_l1_)
		l1l1111l1111_l1_ = list(zip(l1l111lll111_l1_,l11lllll111l_l1_))
		for title,l1ll1ll_l1_ in l1l1111l1111_l1_:
			dict = {}
			dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ似")] = l1l111_l1_ (u"࠭ࡁࠬࡘࠪ伽")
			dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伾")] = l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭伿")
			dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭佀")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ佁") in title: dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ佂")] = title.split(l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠪ佃"))[0].rsplit(l1l111_l1_ (u"࠭ࠠࠡࠩ佄"))[-1]
			else: dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ佅")] = l1l111_l1_ (u"ࠨ࠳࠳ࠫ但")
			if title.count(l1l111_l1_ (u"ࠩࠣࠤࠬ佇"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠪࠤࠥ࠭佈"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ佉")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭佊")] = l1l111_l1_ (u"࠭࠰࠱࠲࠳ࠫ佋")
			if title==l1l111_l1_ (u"ࠧ࠮࠳ࠪ佌"): dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ位")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ低")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ住")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佐")]+l1l111_l1_ (u"ࠬࠦࠠࠨ佑")+l1l111_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ佒")
			else: dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭体")] = dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ佔")]+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭何")+dict[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ佖")]+l1l111_l1_ (u"ࠫࠥࠦࠧ佗")+dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佘")]+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭余")+dict[l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ佚")]
			l11lll11llll_l1_.append(dict)
	l11lll11llll_l1_ = sorted(l11lll11llll_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ佛")]))
	if not l11lll11llll_l1_:
		l1lll1l1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ作"),html,re.DOTALL)
		l1lll1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ佝"),html,re.DOTALL)
		l1l111l111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ佞"),html,re.DOTALL)
		l1l111l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ佟"),html,re.DOTALL)
		try: l11ll1l1lll1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ你")][l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ佡")][l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ佢")][l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ佣")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ佤")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ佥")]
		except: l11ll1l1lll1_l1_ = l1l111_l1_ (u"ࠬ࠭佦")
		try: l1l111l11ll1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ佧")][l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ佨")][l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ佩")][l1l111_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ佪")][0][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ佫")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ佬")]
		except: l1l111l11ll1_l1_ = l1l111_l1_ (u"ࠬ࠭佭")
		try: l1l111l11lll_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ佮")][l1l111_l1_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ佯")]
		except: l1l111l11lll_l1_ = l1l111_l1_ (u"ࠨࠩ佰")
		if l1lll1l1ll1_l1_ or l1lll1l1lll_l1_ or l1l111l111ll_l1_ or l1l111l11l11_l1_ or l11ll1l1lll1_l1_ or l1l111l11ll1_l1_ or l1l111l11lll_l1_:
			if   l1lll1l1ll1_l1_: message = l1lll1l1ll1_l1_[0]
			elif l1lll1l1lll_l1_: message = l1lll1l1lll_l1_[0]
			elif l1l111l111ll_l1_: message = l1l111l111ll_l1_[0]
			elif l1l111l11l11_l1_: message = l1l111l11l11_l1_[0]
			elif l11ll1l1lll1_l1_: message = l11ll1l1lll1_l1_
			elif l1l111l11ll1_l1_: message = l1l111l11ll1_l1_
			elif l1l111l11lll_l1_: message = l1l111l11lll_l1_
			l1l11l1l11l1_l1_ = message.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ佱"),l1l111_l1_ (u"ࠪࠫ佲")).strip(l1l111_l1_ (u"ࠫࠥ࠭佳"))
			l1l11l1l111l_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่าสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษ๊ࠡๅำࠥ๐ใ้่ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭佴")
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ併"),l1l111_l1_ (u"ࠧࠨ佶"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ佷"),l1l11l1l111l_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ佸")+l1l11l1l11l1_l1_)
			return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ佹")+l1l11l1l11l1_l1_,[],[]
		else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ佺"),[],[]
	l11lll111lll_l1_,l11lll11l111_l1_,l1l1111111l1_l1_ = [],[],[]
	for dict in l11lll11llll_l1_:
		if dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ佻")]==l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ佼"):
			l1l111l1l111_l1_.append(dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭佽")])
			l1l111ll11ll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ佾")]==l1l111_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ使"):
			l11llllllll1_l1_.append(dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ侀")])
			l11lll1ll11l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭侁")]==l1l111_l1_ (u"ࠬࡳࡰࡥࠩ侂"):
			title = dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侃")].replace(l1l111_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ侄"),l1l111_l1_ (u"ࠨࠩ侅"))
			if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ來") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ侇")
			else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ侈")]
			l11lll111lll_l1_.append([dict,{},title,l11ll1l11ll_l1_])
		else:
			title = dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ侉")].replace(l1l111_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭侊"),l1l111_l1_ (u"ࠧࠨ例"))
			if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ侌") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ侍")
			else: l11ll1l11ll_l1_ = dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ侎")]
			l11lll111lll_l1_.append([dict,{},title,l11ll1l11ll_l1_])
			l1l11l11l1l1_l1_.append(title)
			l11lll1lll11_l1_.append(dict)
		l1l1111ll11l_l1_ = True
		if l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ侏") in list(dict.keys()):
			if l1l111_l1_ (u"ࠬࡧࡶ࠱ࠩ侐") in dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭侑")]: l1l1111ll11l_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠧࡢࡸࡦࠫ侒") not in dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ侓")] and l1l111_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ侔") not in dict[l1l111_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ侕")]: l1l1111ll11l_l1_ = False
		if dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ侖")]==l1l111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ侗") and dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ侘")]!=l1l111_l1_ (u"ࠧ࠱࠯࠳ࠫ侙") and l1l1111ll11l_l1_==True:
			l11ll1ll11l1_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ侚")])
			l1l11l1111ll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ供")]==l1l111_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ侜") and dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ依")]!=l1l111_l1_ (u"ࠬ࠶࠭࠱ࠩ侞") and l1l1111ll11l_l1_==True:
			l1l11l1l1111_l1_.append(dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侟")])
			l1l111ll1111_l1_.append(dict)
	for l1l1111l1ll1_l1_ in l1l111ll1111_l1_:
		l1l11l1l1ll1_l1_ = l1l1111l1ll1_l1_[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ侠")]
		for l1l111l111l1_l1_ in l1l11l1111ll_l1_:
			l1l11l1ll1ll_l1_ = l1l111l111l1_l1_[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ価")]
			l11ll1l11ll_l1_ = l1l11l1ll1ll_l1_+l1l11l1l1ll1_l1_
			title = l1l111l111l1_l1_[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ侢")].replace(l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬ侣"),l1l111_l1_ (u"ࠫࡲࡶࡤࠡࠢࠪ侤"))
			title = title.replace(l1l111l111l1_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ侥")]+l1l111_l1_ (u"࠭ࠠࠡࠩ侦"),l1l111_l1_ (u"ࠧࠨ侧"))
			title = title.replace(str((float(l1l11l1ll1ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭侨"),str((float(l11ll1l11ll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ侩"))
			title = title+l1l111_l1_ (u"ࠪࠬࠬ侪")+l1l1111l1ll1_l1_[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ侫")].split(l1l111_l1_ (u"ࠬ࠮ࠧ侬"),1)[1]
			l11lll111lll_l1_.append([l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_])
	l11lll111lll_l1_ = sorted(l11lll111lll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_ in l11lll111lll_l1_:
		l11lll11l1ll_l1_ = l1l111l111l1_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ侭")]
		if l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ侮") in list(l1l1111l1ll1_l1_.keys()):
			l11lll11l1ll_l1_ = l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ侯")
		if l11lll11l1ll_l1_ not in l1l1111111l1_l1_:
			l1l1111111l1_l1_.append(l11lll11l1ll_l1_)
			l11lll11l111_l1_.append([l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_])
	l11ll1llll1l_l1_,l1l111lll11l_l1_,shift = [],[],0
	l1l1111lll11_l1_,l1l11l1111l1_l1_ = l1l111_l1_ (u"ࠩࠪ侰"),l1l111_l1_ (u"ࠪࠫ侱")
	try: l1l1111lll11_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ侲")][l1l111_l1_ (u"ࠬࡧࡵࡵࡪࡲࡶࠬ侳")]
	except: l1l1111lll11_l1_ = l1l111_l1_ (u"࠭ࠧ侴")
	try: l11llllll11l_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭侵")][l1l111_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ侶")]
	except: l11llllll11l_l1_ = l1l111_l1_ (u"ࠩࠪ侷")
	if l1l1111lll11_l1_ and l11llllll11l_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ侸")+l1l1111lll11_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭侹")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭侺")][0]+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ侻")+l11llllll11l_l1_
		l11ll1llll1l_l1_.append(title)
		l1l111lll11l_l1_.append(l1ll1ll_l1_)
		try: l1l11l1111l1_l1_ = l1l111llll1l_l1_[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭侼")][l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ侽")][l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭侾")][-1][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ便")]
		except: pass
	for l1l111l111l1_l1_,l1l1111l1ll1_l1_,title,l11ll1l11ll_l1_ in l11lll11l111_l1_:
		l11ll1llll1l_l1_.append(title) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ俀"))
	if l1l11l11l1l1_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡ็ะำิฯࠧ俁")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ係"))
	if l11lll111lll_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬࠣห้๋ส้ใิࠫ促")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ俄"))
	if l11ll1ll11l1_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ࠩࡰࡴࡩࠦวฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ俅")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俆"))
	if l1l111l1l111_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"ฺࠫ๎ัสࠢหำํ์ࠠึ๊อࠫ俇")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ俈"))
	if l11llllllll1_l1_: l11ll1llll1l_l1_.append(l1l111_l1_ (u"࠭ี้ฬࠣฬิ๎ๆࠡื๋ีฮ࠭俉")) ; l1l111lll11l_l1_.append(l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭俊"))
	l1l11l11lll1_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l11lll1ll1l1_l1_, l11ll1llll1l_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭俋"),[],[]
		elif l11l11l_l1_==0 and l1l1111lll11_l1_:
			l1ll1ll_l1_ = l1l111lll11l_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠳ࠩࡲࡦࡳࡥ࠾ࠩ俌")+QUOTE(l1l1111lll11_l1_)+l1l111_l1_ (u"ࠪࠪࡺࡸ࡬࠾ࠩ俍")+l1ll1ll_l1_
			if l1l11l1111l1_l1_: new_path = new_path+l1l111_l1_ (u"ࠫࠫ࡯࡭ࡢࡩࡨࡁࠬ俎")+QUOTE(l1l11l1111l1_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ俏")+new_path+l1l111_l1_ (u"ࠨࠩࠣ俐"))
			return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ俑"),[],[]
		choice = l1l111lll11l_l1_[l11l11l_l1_]
		l1l111l1l11l_l1_ = l11ll1llll1l_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"ࠨࡦࡤࡷ࡭࠭俒"):
			l11lllll1ll1_l1_ = l11llll11111_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ俓"),l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ俔"),l1l111_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ俕")]:
			if choice==l1l111_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ俖"): l1l1lll1_l1_,l1l1111l1lll_l1_ = l1l11l11l1l1_l1_,l11lll1lll11_l1_
			elif choice==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ俗"): l1l1lll1_l1_,l1l1111l1lll_l1_ = l1l111l1l111_l1_,l1l111ll11ll_l1_
			elif choice==l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭俘"): l1l1lll1_l1_,l1l1111l1lll_l1_ = l11llllllll1_l1_,l11lll1ll11l_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ俙"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l11lllll1ll1_l1_ = l1l1111l1lll_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭俚")]
				l1l111l1l11l_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俛"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯ࠺ࠨ俜"), l11ll1ll11l1_l1_)
			if l11l11l_l1_!=-1:
				l1l111l1l11l_l1_ = l11ll1ll11l1_l1_[l11l11l_l1_]
				l11ll1llllll_l1_ = l1l11l1111ll_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํะ࠺ࠨ保"), l1l11l1l1111_l1_)
				if l11l11l_l1_!=-1:
					l1l111l1l11l_l1_ += l1l111_l1_ (u"࠭ࠠࠬࠢࠪ俞")+l1l11l1l1111_l1_[l11l11l_l1_]
					l1l11111l1l1_l1_ = l1l111ll1111_l1_[l11l11l_l1_]
					l1l11l11lll1_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ俟"):
			l11llll11lll_l1_,l11ll1ll11ll_l1_,l11lll1l11ll_l1_,l1l11l11l1ll_l1_ = list(zip(*l11lll111lll_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ俠"), l11lll1l11ll_l1_)
			if l11l11l_l1_!=-1:
				l1l111l1l11l_l1_ = l11lll1l11ll_l1_[l11l11l_l1_]
				l11ll1llllll_l1_ = l11llll11lll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠩࡰࡴࡩ࠭信") in l11lll1l11ll_l1_[l11l11l_l1_] and l11ll1llllll_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俢")]!=l11llll11111_l1_:
					l1l11111l1l1_l1_ = l11ll1ll11ll_l1_[l11l11l_l1_]
					l1l11l11lll1_l1_ = True
				else: l11lllll1ll1_l1_ = l11ll1llllll_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俣")]
				break
		elif choice==l1l111_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭俤"):
			l11llll11lll_l1_,l11ll1ll11ll_l1_,l11lll1l11ll_l1_,l1l11l11l1ll_l1_ = list(zip(*l11lll11l111_l1_))
			l11ll1llllll_l1_ = l11llll11lll_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"࠭࡭ࡱࡦࠪ俥") in l11lll1l11ll_l1_[l11l11l_l1_-shift] and l11ll1llllll_l1_[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ俦")]!=l11llll11111_l1_:
				l1l11111l1l1_l1_ = l11ll1ll11ll_l1_[l11l11l_l1_-shift]
				l1l11l11lll1_l1_ = True
			else: l11lllll1ll1_l1_ = l11ll1llllll_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俧")]
			l1l111l1l11l_l1_ = l11lll1l11ll_l1_[l11l11l_l1_-shift]
			break
	if not l1l11l11lll1_l1_: l11lllll11ll_l1_ = l11lllll1ll1_l1_
	else: l11lllll11ll_l1_ = l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪ俨")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俩")]+l1l111_l1_ (u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨ俪")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俫")]
	if l1l11l11lll1_l1_:
		l1l11l11111l_l1_ = int(l11ll1llllll_l1_[l1l111_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ俬")])
		l11llllll111_l1_ = int(l1l11111l1l1_l1_[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ俭")])
		l1l1lll1ll_l1_ = str(max(l1l11l11111l_l1_,l11llllll111_l1_))
		l11lll1ll111_l1_ = l11ll1llllll_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ修")].replace(l1l111_l1_ (u"ࠩࠩࠫ俯"),l1l111_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ俰"))
		l11lllllllll_l1_ = l1l11111l1l1_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俱")].replace(l1l111_l1_ (u"ࠬࠬࠧ俲"),l1l111_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ俳"))
		l1l11l111lll_l1_ = l1l111_l1_ (u"ࠧ࠽ࡁࡻࡱࡱࠦࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣ࠳࠱࠴ࠧࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠾ࠤࡘࡘࡋ࠳࠸ࠣࡁࡁࡠࡳ࠭俴")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡐࡔࡉࠦࡸ࡮࡮ࡱࡷ࠿ࡾࡳࡪ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠳࠲࠳࠵࠴࡞ࡍࡍࡕࡦ࡬ࡪࡳࡡ࠮࡫ࡱࡷࡹࡧ࡮ࡤࡧࠥࠤࡽࡳ࡬࡯ࡵࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠨࠠࡹ࡯࡯ࡲࡸࡀࡸ࡭࡫ࡱ࡯ࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡻ࠸࠴࡯ࡳࡩ࠲࠵࠾࠿࠹࠰ࡺ࡯࡭ࡳࡱࠢࠡࡺࡶ࡭࠿ࡹࡣࡩࡧࡰࡥࡑࡵࡣࡢࡶ࡬ࡳࡳࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡴࡥ࡫ࡩࡲࡧ࠺࡮ࡲࡧ࠾࠷࠶࠱࠲ࠢ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡸࡦࡴࡤࡢࡴࡧࡷ࠳࡯ࡳࡰ࠰ࡲࡶ࡬࠵ࡩࡵࡶࡩ࠳ࡕࡻࡢ࡭࡫ࡦࡰࡾࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࡔࡶࡤࡲࡩࡧࡲࡥࡵ࠲ࡑࡕࡋࡇ࠮ࡆࡄࡗࡍࡥࡳࡤࡪࡨࡱࡦࡥࡦࡪ࡮ࡨࡷ࠴ࡊࡁࡔࡊ࠰ࡑࡕࡊ࠮ࡹࡵࡧࠦࠥࡳࡩ࡯ࡄࡸࡪ࡫࡫ࡲࡕ࡫ࡰࡩࡂࠨࡐࡕ࠳࠱࠹ࡘࠨࠠ࡮ࡧࡧ࡭ࡦࡖࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡈࡺࡸࡡࡵ࡫ࡲࡲࡂࠨࡐࡕࠩ俵")+l1l1lll1ll_l1_+l1l111_l1_ (u"ࠩࡖࠦࠥࡺࡹࡱࡧࡀࠦࡸࡺࡡࡵ࡫ࡦࠦࠥࡶࡲࡰࡨ࡬ࡰࡪࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡲࡵࡳ࡫࡯࡬ࡦ࠼࡬ࡷࡴ࡬ࡦ࠮࡯ࡤ࡭ࡳࡀ࠲࠱࠳࠴ࠦࡃࡢ࡮ࠨ俶")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠪࡀࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ俷")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠳ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡸ࡬ࡨࡪࡵ࠯ࠨ俸")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ俹")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡶࡵࡹࡪࠨ࠾࡝ࡰࠪ俺")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ俻")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ俼")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ俽")]+l1l111_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ俾")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ俿")]+l1l111_l1_ (u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢࠨ倀")+str(l11ll1llllll_l1_[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ倁")])+l1l111_l1_ (u"ࠧࠣࠢࡺ࡭ࡩࡺࡨ࠾ࠤࠪ倂")+str(l11ll1llllll_l1_[l1l111_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ倃")])+l1l111_l1_ (u"ࠩࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠭倄")+str(l11ll1llllll_l1_[l1l111_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ倅")])+l1l111_l1_ (u"ࠫࠧࠦࡦࡳࡣࡰࡩࡗࡧࡴࡦ࠿ࠥࠫ倆")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ倇")]+l1l111_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ倈")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ倉")+l11lll1ll111_l1_+l1l111_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ倊")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ個")+l11ll1llllll_l1_[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ倌")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ倍")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ倎")+l11ll1llllll_l1_[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ倏")]+l1l111_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ倐")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ們")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ倒")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ倓")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠴ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨ倔")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ倕")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡶࡵࡹࡪࠨ࠾࡝ࡰࠪ倖")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ倗")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ倘")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ候")]+l1l111_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ倚")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ倛")]+l1l111_l1_ (u"ࠬࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦ࠶࠹࠰࠵࠹࠸ࠦࡃࡢ࡮ࠨ倜")
		l1l11l111lll_l1_ += l1l111_l1_ (u"࠭࠼ࡂࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡉ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾࠷࠹࠰࠱࠵࠽࠷࠿ࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠬ倝")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ倞")]+l1l111_l1_ (u"ࠨࠤ࠲ࡂࡡࡴࠧ借")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ倠")+l11lllllllll_l1_+l1l111_l1_ (u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ倡")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ倢")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ倣")]+l1l111_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ値")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ倥")+l1l11111l1l1_l1_[l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭倦")]+l1l111_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ倧")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭倨")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ倩")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ倪")
		l1l11l111lll_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ倫")
		l1l11l111lll_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ倬")
		if kodi_version>18.99:
			import http.server as l11llll1lll1_l1_
			import http.client as l1l111111lll_l1_
		else:
			import BaseHTTPServer as l11llll1lll1_l1_
			import httplib as l1l111111lll_l1_
		class l1l111l11111_l1_(l11llll1lll1_l1_.HTTPServer):
			def __init__(self,l1ll1lll11ll_l1_=l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ倭"),port=55055,l1l11l111lll_l1_=l1l111_l1_ (u"ࠩ࠿ࡂࠬ倮")):
				self.l1ll1lll11ll_l1_ = l1ll1lll11ll_l1_
				self.port = port
				self.l1l11l111lll_l1_ = l1l11l111lll_l1_
				l11llll1lll1_l1_.HTTPServer.__init__(self,(self.l1ll1lll11ll_l1_,self.port),l1l11l111l1l_l1_)
				self.l1l1111l11ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ倯")+l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠫ࠿࠭倰")+str(port)+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ倱")
			def start(self):
				self.threads = l11l11ll111_l1_(False)
				self.threads.start_new_thread(1,self.l11llll1llll_l1_)
			def l11llll1llll_l1_(self):
				self.l11lll11111l_l1_ = True
				while self.l11lll11111l_l1_:
					self.handle_request()
			def stop(self):
				self.l11lll11111l_l1_ = False
				self.l1l1111lllll_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l11l111lll_l1_):
				self.l1l11l111lll_l1_ = l1l11l111lll_l1_
			def l1l1111lllll_l1_(self):
				conn = l1l111111lll_l1_.HTTPConnection(self.l1ll1lll11ll_l1_+l1l111_l1_ (u"࠭࠺ࠨ倲")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠢࡉࡇࡄࡈࠧ倳"), l1l111_l1_ (u"ࠣ࠱ࠥ倴"))
		class l1l11l111l1l_l1_(l11llll1lll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ倵"),l1l111_l1_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ倶"))
				self.end_headers()
				self.wfile.write(self.server.l1l11l111lll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ倷")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ倸"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ倹"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l111l11111_l1_(l1l111_l1_ (u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪ债"),55055,l1l11l111lll_l1_)
		l11lllll1ll1_l1_ = httpd.l1l1111l11ll_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"ࠨࠩ倻")
	if not l11lllll1ll1_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ值"),[],[]
	return l1l111_l1_ (u"ࠪࠫ倽"),[l1l111_l1_ (u"ࠫࠬ倾")],[[l11lllll1ll1_l1_,l1l111l1ll11_l1_,httpd]]
def l1l1111l111l_l1_(url):
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ倿") : l1l111_l1_ (u"࠭ࠧ偀") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ偁"),headers,l1l111_l1_ (u"ࠨࠩ偂"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡄࡒࡆ࠲࠷ࡳࡵࠩ偃"))
	items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤࡿ࠭ࡡࢃࠧ偄"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l111lll111_l1_,l1l1lll1_l1_,l11lllll111l_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1ll1ll_l1_,dummy,l1lll1lllll1_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ偅"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ偆"))
			if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ假") in l1ll1ll_l1_:
				l1l111lll111_l1_,l11lllll111l_l1_ = l1l11l1ll1_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11lllll111l_l1_
				if l1l111lll111_l1_[0]==l1l111_l1_ (u"ࠧ࠮࠳ࠪ偈"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨีํีๆืࠠฯษุࠫ偉")+l1l111_l1_ (u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ偊"))
				else:
					for title in l1l111lll111_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭偋")+l1l111_l1_ (u"ࠫࠥࠦࠠࠨ偌")+title)
			else:
				title = l1l111_l1_ (u"ู๊ࠬาใิࠤำอีࠨ偍")+l1l111_l1_ (u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩ偎")+l1lll1lllll1_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
				l1l1lll1_l1_.append(title)
		return l1l111_l1_ (u"ࠧࠨ偏"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ偐"),[],[]
def l11llll111l1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭偑"),url,l1l111_l1_ (u"ࠪࠫ偒"),l1l111_l1_ (u"ࠫࠬ偓"),l1l111_l1_ (u"ࠬ࠭偔"),l1l111_l1_ (u"࠭ࠧ偕"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜࡛ࡏࡄࡆࡑࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ偖"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ偗"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		return l1l111_l1_ (u"ࠩࠪ偘"),[l1l111_l1_ (u"ࠪࠫ偙")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࠬ做"),[],[]
def l11lll11lll1_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ偛"),l1l111_l1_ (u"࠭ࠧ停")).replace(l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭偝"),l1l111_l1_ (u"ࠨࠩ偞"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭偟"),url,l1l111_l1_ (u"ࠪࠫ偠"),l1l111_l1_ (u"ࠫࠬ偡"),l1l111_l1_ (u"ࠬ࠭偢"),l1l111_l1_ (u"࠭ࠧ偣"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭偤"))
	html = response.content
	l1111111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬࡠ࠮࠯ࠧ健"),html,re.DOTALL)
	if l1111111l1l_l1_:
		l1111111l1l_l1_ = l1111111l1l_l1_[0]
		l1ll1l1ll111_l1_ = l1ll1llll11l_l1_(l1111111l1l_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ偦"),l1ll1l1ll111_l1_,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪࠬࢁࠬ偧"),l1ll1l1ll111_l1_,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_,title in l1ll_l1_:
			if not title: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠫ࠳࠭偨"),1)[1]
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		return l1l111_l1_ (u"ࠬ࠭偩"),l1l1lll1_l1_,l1llll_l1_
	id = url.split(l1l111_l1_ (u"࠭࠯ࠨ偪"))[3]
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ偫"):l1l111_l1_ (u"ࠨࠩ偬") , l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ偭"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ偮") }
	payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ偯"):id , l1l111_l1_ (u"ࠬࡵࡰࠨ偰"):l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ偱") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ偲"),url,payload,headers,l1l111_l1_ (u"ࠨࠩ偳"),l1l111_l1_ (u"ࠩࠪ側"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ偵"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ偶"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠬ࠭偷"),[l1l111_l1_ (u"࠭ࠧ偸")],[ items[0] ]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡛ࠢࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇࠨ偹"),[],[]
def l1l111l11l1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ偺"),l1l111_l1_ (u"ࠩࠪ偻"),l1l111_l1_ (u"ࠪࠫ偼"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡑࡕࡁࡅࡕ࠰࠵ࡸࡺࠧ偽"))
	items = re.findall(l1l111_l1_ (u"ࠬࡩ࡯࡭ࡱࡵࡁࠧࡸࡥࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ偾"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ偿"),[l1l111_l1_ (u"ࠧࠨ傀")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡍࡑࡄࡈࡘ࠭傁"),[],[]
def l1l1111l11l1_l1_(url):
	return l1l111_l1_ (u"ࠩࠪ傂"),[l1l111_l1_ (u"ࠪࠫ傃")],[ url ]
def l1l111ll1ll1_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠫ࠴࠭傄"))
	basename = l1l111_l1_ (u"ࠬ࠵ࠧ傅").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ傆"),l1l111_l1_ (u"ࠧࠨ傇"),l1l111_l1_ (u"ࠨࠩ傈"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭傉"))
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ傊"),html,re.DOTALL)
	if items:
		l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_,l1l11l11l111_l1_,l1l11l11l11l_l1_,l1l11l111ll1_l1_ = items[0]
		var = int(l1l1l1ll111l_l1_) % int(l1l1l1ll11l1_l1_) + int(l1l11l11l111_l1_) % int(l1l11l11l11l_l1_)
		url = basename + l1l1l1l1l11l_l1_ + str(var) + l1l11l111ll1_l1_
		return l1l111_l1_ (u"ࠫࠬ傋"),[l1l111_l1_ (u"ࠬ࠭傌")],[url]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ傍"),[],[]
def l1l11111lll1_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ傎"),l1l111_l1_ (u"ࠨࠩ傏"))
	url = url.replace(l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ傐"),l1l111_l1_ (u"ࠪࠫ傑"))
	id = url.split(l1l111_l1_ (u"ࠫ࠴࠭傒"))[-1]
	headers = { l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ傓") : l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ傔") }
	payload = { l1l111_l1_ (u"ࠢࡪࡦࠥ傕"):id , l1l111_l1_ (u"ࠣࡱࡳࠦ傖"):l1l111_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ傗") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ傘"), url, payload, headers, l1l111_l1_ (u"ࠫࠬ備"),l1l111_l1_ (u"ࠬ࠭傚"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ傛"))
	if l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ傜") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ傝")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࠪ傞"),[l1l111_l1_ (u"ࠪࠫ傟")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ傠"),[],[]
def l11ll1l1llll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭傡"),l1l111_l1_ (u"࠭ࠧ傢"),l1l111_l1_ (u"ࠧࠨ傣"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ傤"))
	items = re.findall(l1l111_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ傥"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ傦"),[l1l111_l1_ (u"ࠫࠬ傧")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ储"),[],[]
def l11lll111l11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ傩"),l1l111_l1_ (u"ࠧࠨ傪"),l1l111_l1_ (u"ࠨࠩ傫"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ催"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ傭"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ傮") + items[0]
		return l1l111_l1_ (u"ࠬ࠭傯"),[l1l111_l1_ (u"࠭ࠧ傰")],[ url ]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ傱"),[],[]
def l1l11l1ll1l1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ傲"),l1l111_l1_ (u"ࠩࠪ傳"),l1l111_l1_ (u"ࠪࠫ傴"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡗࡅࡐࡎࡉࡖࡊࡆࡈࡓࡍࡕࡓࡕ࠯࠴ࡷࡹ࠭債"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ傶"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"࠭ࠧ傷"),[l1l111_l1_ (u"ࠧࠨ傸")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘࠬ傹"),[],[]
def l11lll11ll1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ傺"),l1l111_l1_ (u"ࠪࠫ傻"),l1l111_l1_ (u"ࠫࠬ傼"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭傽"))
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭傾"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ傿"),[l1l111_l1_ (u"ࠨࠩ僀")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ僁"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l1l11l_l1_ import *
import bidi.algorithm,base64
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ㍆")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l11111ll11l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ㍇"))
	l1ll11llll_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ㍈"))
	l11l1l1l1l1_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ㍉"))
	l111l1ll1l1_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㍊"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㍋"),l1l111_l1_ (u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ㍌"))
	l11ll111111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍍"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㍎"),l1l111_l1_ (u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ㍏"))
	l1llll1l1l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㍐"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㍑"),l1l111_l1_ (u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭㍒"))
	half_triangular_colon = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ㍓")
	from urllib.parse import quote as _1llll1ll1ll_l1_
else:
	l11111ll11l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ㍔"))
	l1ll11llll_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ㍕"))
	l11l1l1l1l1_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ㍖"))
	l111l1ll1l1_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㍗"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㍘"),l1l111_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫ㍙"))
	l11ll111111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㍚"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㍛"),l1l111_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ㍜"))
	l1llll1l1l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㍝"),l1l111_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㍞"),l1l111_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ㍟"))
	half_triangular_colon = l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ㍠").encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㍡"))
	from urllib import quote as _1llll1ll1ll_l1_
l1llll1llll1_l1_ = os.path.join(l11l1l1l1l1_l1_,l1l111_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪ㍢"))
l1llllllllll_l1_ = os.path.join(l11l1l1l1l1_l1_,l1l111_l1_ (u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨ㍣"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㍤"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㍥"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㍦"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ㍧"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㍨"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㍩"))
l1l1ll1ll1ll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡩࡧࡴࠨ㍪"))
l1l1llll11ll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭㍫"))
l1l1l1lll1l_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠫࡵࡧࡴࡩࠩ㍬"))
defaulticon = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧ㍭"))
defaultthumb = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩ㍮"))
defaultfanart = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫ㍯"))
defaultbanner = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬ㍰"))
defaultlandscape = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩ㍱"))
defaultposter = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧ㍲"))
defaultclearlogo = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫ㍳"))
defaultclearart = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫ㍴"))
l1ll1llll1ll_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭㍵"))
l1lllllll1_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㍶"))
l1ll1lll111l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍷"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㍸"),addon_id,l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㍹"))
l1111l1l111_l1_ = os.path.join(l11111ll11l_l1_,l1l111_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࠪ㍺"),l1l111_l1_ (u"ࠬࡌ࡯࡯ࡶࡶࠫ㍻"),l1l111_l1_ (u"࠭ࡡࡳ࡫ࡤࡰ࠳ࡺࡴࡧࠩ㍼"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ࠧึใิࠫ㍽"),l1l111_l1_ (u"ࠨล๋่ࠬ㍾"),l1l111_l1_ (u"ࠩฮห๋๐ࠧ㍿"),l1l111_l1_ (u"ࠪฯฬ๊หࠨ㎀"),l1l111_l1_ (u"ࠫึอศฺࠩ㎁"),l1l111_l1_ (u"ࠬิวๆีࠪ㎂"),l1l111_l1_ (u"࠭ำศัึࠫ㎃"),l1l111_l1_ (u"ࠧิษห฽ࠬ㎄"),l1l111_l1_ (u"ࠨอส้๋࠭㎅"),l1l111_l1_ (u"ࠩอหุ฿ࠧ㎆"),l1l111_l1_ (u"ࠪ฽ฬฺัࠨ㎇")]
l1llllllll1l_l1_ = l1l111_l1_ (u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬ㎈")
l11ll11l_l1_ = 0
l1lll11lll1l_l1_ = 30*l1l1lll1l11_l1_
l111l11l_l1_ = 2*l1l1l11l111_l1_
l11l1l1_l1_ = 16*l1l1l11l111_l1_
l1lll11ll11_l1_ = 30*l1l1l111l11_l1_
l1l11l1lll1_l1_ = 1*l1l1l11l111_l1_
l1ll11111l1l_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㎉")]
l11111ll111_l1_ = [l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㎊"),l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㎋"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ㎌"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㎍"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭㎎"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㎏"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ㎐"),l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㎑")]
l11111ll111_l1_ += [l1l111_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㎒"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㎓"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㎔"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㎕"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㎖"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㎗"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ㎘"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㎙")]
l1l1ll1llll1_l1_ = [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㎚"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㎛"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㎜"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㎝")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㎞"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ㎟"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㎠"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㎡")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㎢"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ㎣"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ㎤")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㎥"),l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㎦"),l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㎧"),l1l111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ㎨"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㎩"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㎪"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㎫")]
l1l1ll1llll1_l1_ += [l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㎬"),l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㎭"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㎮"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㎯"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㎰"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㎱")]
l1ll1lll1l1_l1_ = [l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㎲"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭㎳"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㎴"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㎵")]
l1ll1lll1l1_l1_ += [l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㎶"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㎷"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㎸"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㎹"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ㎺")]
l1lll1111ll_l1_ = [l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㎻"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㎼"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㎽"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㎾"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㎿"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㏀")]
l1lll1111ll_l1_ += [l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㏁"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㏂"),l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㏃"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㏄"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㏅"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㏆")]
l1lll1llll1_l1_ = [l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㏇"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㏈"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㏉"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㏊"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㏋"),l1l111_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㏌"),l1l111_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㏍"),l1l111_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ㏎")]
l1lll1llll1_l1_ += [l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㏏"),l1l111_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭㏐"),l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㏑"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㏒"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ㏓"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㏔")]
l1lll111111l_l1_  = [l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㏕"),l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㏖"),l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㏗"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㏘"),l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㏙"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㏚"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㏛"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㏜"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ㏝")]
l1lll111111l_l1_ += [l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㏞"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ㏟"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㏠"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㏡"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ㏢"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㏣"),l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㏤"),l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㏥"),l1l111_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㏦")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ㏧"),l1l111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ㏨"),l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㏩"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭㏪"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㏫"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ㏬"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ㏭")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㏮"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㏯"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㏰"),l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㏱"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㏲"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㏳"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㏴")]
l1lll111111l_l1_ += [l1l111_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㏵"),l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㏶"),l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㏷"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㏸"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ㏹"),l1l111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㏺"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ㏻")]
l1ll11l111ll_l1_  = [l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭㏼"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㏽"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㏾"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩ㏿")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ㐀"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㐁")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ㐂"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㐃"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㐄")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㐅"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㐆"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㐇")]
l1ll11l111ll_l1_ += [l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ㐈"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㐉"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㐊")]
l1ll1l111111_l1_ = [l1l111_l1_ (u"ࠩࡐ࠷࡚࠭㐋"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㐌"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㐍"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㐎"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㐏")]
l1lll1l1111_l1_ = l1lll111111l_l1_+l1ll11l111ll_l1_
l1ll1ll1l11l_l1_ = l1lll111111l_l1_+l1ll1l111111_l1_
l1l111l11l1_l1_ = l1lll111111l_l1_+l1ll1l111111_l1_
l1lll11llll_l1_ = l1l1ll1llll1_l1_+l1lll1111ll_l1_+l1lll1llll1_l1_+l1ll1lll1l1_l1_
l1llllll1ll1_l1_ = [
						l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ㐐")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ㐑")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ㐒")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ㐓")
						,l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭㐔")
						,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ㐕")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ㐖")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫ㐗")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ㐘")
						,l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭㐙")
						,l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪ㐚")
						,l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫ㐛")
						]
l11l1ll111l_l1_ = l1llllll1ll1_l1_+[
				 l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ㐜")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ㐝")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㐞")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧࠫ㐟")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬ㐠")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭㐡")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭㐢")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪࠧ㐣")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨ㐤")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ㐥")
				,l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ㐦")
				,l1l111_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬ㐧")
				,l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭㐨")
				,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩ㐩")
				,l1l111_l1_ (u"ࠬࡓࡅࡏࡗࡖ࠱ࡘࡎࡏࡘࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨ㐪")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧ㐫")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㐬")
				]
l1111l11lll_l1_ = [l1l111_l1_ (u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ㐭"),l1l111_l1_ (u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ㐮"),l1l111_l1_ (u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫ㐯"),l1l111_l1_ (u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬ㐰"),l1l111_l1_ (u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭㐱"),l1l111_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧ㐲")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㐳")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡰࡨࡸࠬ㐴")]
			,l1l111_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㐵")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬ㐶")]
			,l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㐷")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬ࡹࡤࡱ࠳ࡴࡥࡵࠩ㐸")]
			,l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㐹")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ㐺")]
			,l1l111_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㐻")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼࠧ㐼")]
			,l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ㐽")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ㐾")]
			,l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ㐿")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡷࡧࡢࡪࡥ࠰ࡸࡴࡵ࡮ࡴ࠰ࡦࡳࡲ࠭㑀")]
			,l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㑁")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡦࡨࡳࡦࡧࡧ࠲ࡳ࡫ࡴࠨ㑂")]
			,l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㑃")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ㑄")]
			,l1l111_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ㑅")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯ࠪ㑆")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㑇")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭㑈")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㑉")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ㑊")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ㑋")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡤࡦࡩࡵ࠮ࡤࡱࡰࠫ㑌")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ㑍")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡯࡮ࡴࠧ㑎")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㑏")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡼࡵࡲ࡬ࠩ㑐")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㑑")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧ㑒")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㑓")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠸࠱ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨ㑔")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ㑕")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳࡮ࡰࡹ࠱ࡧࡴࡳࠧ㑖")]
			,l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㑗")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ㑘"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ㑙")]
			,l1l111_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㑚")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧ㑛")]
			,l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ㑜")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰ࠰ࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ㑝")]
			,l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ㑞")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡨࡥࡴࡶ࠱ࡷࡹࡵࡲࡦࠩ㑟")]
			,l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㑠")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫ㑡")]
			,l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㑢")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭㑣")]
			,l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ㑤")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨ㑥")]
			,l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ㑦")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪ㑧")]
			,l1l111_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ㑨")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡤࡵ࡯ࡦ࠴ࡣࡰ࡯ࠪ㑩")]
			,l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㑪")	:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࡮ࡪࡸ࠮ࡴࡪࡲࡻࠬ㑫")]
			,l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㑬")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡸ࡬ࡴࠬ㑭")]
			,l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ㑮")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࡭ࡣ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪ㑯")]
			,l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㑰")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹ࡭࠲࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴࡮ࡦࡶࠪ㑱")]
			,l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㑲")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡺࡹࠧ㑳")]
			,l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㑴")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㑵"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㑶"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭㑷"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㑸"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧ㑹")]
			,l1l111_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ㑺")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪ㑻")]
			,l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㑼")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨ㑽")]
			,l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㑾")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡱࡹ࠲ࡰ࡯ࡴ࡬ࡱࡷ࠲ࡹࡼࠧ㑿")]
			,l1l111_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭㒀")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ㒁"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨ㒂")]
			,l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㒃")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴ࡣࡢ࡯ࠪ㒄")]
			,l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㒅")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨ㒆")]
			,l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㒇")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡦࡧ࠮ࡤࡣࡰࠫ㒈")]
			,l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭㒉")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࠴ࡳࡩ࠶ࡸ࠲ࡳ࡫ࡷࡴࠩ㒊")]
			,l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㒋")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫ࡳ࡫࡮ࡡ࠯ࡶࡹࠫ㒌")]
			,l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㒍")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ㒎"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡸࡦࡺࡩࡤ࠰ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ㒏"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬ㒐")]
			,l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㒑")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩ㒒")]
			,l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ㒓")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡦ࡭ࡲࡧ࠮ࡤ࡮࡬ࡧࡰ࠭㒔")]
			,l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㒕")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭㒖")]
			,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㒗")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭㒘")]
			,l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㒙")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ㒚"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ㒛"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ㒜"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㒝"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭㒞"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㒟"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ㒠"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭㒡"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㒢")]
			,l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ㒣")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㒤"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㒥"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㒦"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㒧"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㒨"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㒩"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㒪"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡦࡥࡵࡺࡣࡩࡣࠪ㒫"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡸࡪࡹࡴࡪࡰࡪࠫ㒬")]
			,l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㒭")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㒮"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ㒯"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ㒰")]
			,l1l111_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ㒱")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㒲"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ㒳"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ㒴")]
			,l1l111_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ㒵")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ㒶"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫ࠫ㒷"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ㒸")]
			}
l111l111111_l1_ = [l1l111_l1_ (u"ࠨࡎࡌࡗ࡙ࡖࡌࡂ࡛ࠪ㒹"),l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡒࡕࡕࠪ㒺"),l1l111_l1_ (u"ࠪࡉࡒࡇࡉࡍࡕࠪ㒻"),l1l111_l1_ (u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭㒼"),l1l111_l1_ (u"ࠬࡏࡓࡍࡃࡐࡍࡈ࡙ࠧ㒽"),l1l111_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㒾"),l1l111_l1_ (u"ࠧࡌࡐࡒ࡛ࡓࡋࡒࡓࡑࡕࡗࠬ㒿"),l1l111_l1_ (u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩ㓀"),l1l111_l1_ (u"ࠩࡗࡉࡘ࡚ࡉࡏࡉࠪ㓁")]
l11l11llll1_l1_ = [l1l111_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࠪ㓂"),l1l111_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭㓃"),l1l111_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ㓄")]
class l1ll1l1111l1_l1_(l1l1ll11l1l_l1_):
	def __init__(self,*args,**kwargs):
		self.l1l11111l11_l1_ = -1
	def onClick(self,l1111l1l1ll_l1_):
		if l1111l1l1ll_l1_>=9010: self.l1l11111l11_l1_ = l1111l1l1ll_l1_-9010
		self.delete()
	def l11l11111l1_l1_(self,*args):
		self.l111l1l11l1_l1_,self.l1ll11ll1l11_l1_,self.l111l1l1lll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1lll111ll1l_l1_ = args[5],args[6]
		self.l1lll11l11l1_l1_,self.l1l1ll1l1lll_l1_,self.l1ll1111lll1_l1_ = args[7],args[8],args[9]
		if self.l1l1ll1l1lll_l1_>0 or self.l1ll1111lll1_l1_>0: self.l1ll1lll1l11_l1_ = True
		else: self.l1ll1lll1l11_l1_ = False
		self.l1lll11l11ll_l1_,self.l11l11111ll_l1_ = l1lllllllll1_l1_(self.l111l1l11l1_l1_,self.l1ll11ll1l11_l1_,self.l111l1l1lll_l1_,self.header,self.text,self.profile,self.l1lll111ll1l_l1_,self.l1lll11l11l1_l1_,self.l1ll1lll1l11_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll11l11ll_l1_)
		self.getControl(9050).setHeight(self.l11l11111ll_l1_)
		if not self.l1ll11ll1l11_l1_ and self.l111l1l11l1_l1_ and self.l111l1l1lll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll11l11ll_l1_,self.l11l11111ll_l1_
	def l1l1111111l_l1_(self):
		if self.l1l1ll1l1lll_l1_:
			from threading import Thread
			self.l1l11l1l1ll_l1_ = Thread(target=self.l1lll1l11lll_l1_,args=())
			self.l1l11l1l1ll_l1_.start()
		else: self.l11l11l1ll1_l1_()
	def l1lll1l11lll_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l11l111l_l1_ in range(1,self.l1l1ll1l1lll_l1_+1):
			time.sleep(1)
			l1l1ll1lll11_l1_ = int(100*l1l11l111l_l1_/self.l1l1ll1l1lll_l1_)
			self.l1l1lllll111_l1_(l1l1ll1lll11_l1_)
			if self.l1l11111l11_l1_>0: break
		self.l11l11l1ll1_l1_()
	def l11lll1l1l1_l1_(self):
		if self.l1ll1111lll1_l1_:
			from threading import Thread
			self.l1ll1ll1l111_l1_ = Thread(target=self.l1111111ll1_l1_,args=())
			self.l1ll1ll1l111_l1_.start()
		else: self.l11l11l1ll1_l1_()
	def l1111111ll1_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l1ll1l1lll_l1_)
		for l1l11l111l_l1_ in range(self.l1ll1111lll1_l1_-1,-1,-1):
			time.sleep(1)
			l1l1ll1lll11_l1_ = int(100*l1l11l111l_l1_/self.l1ll1111lll1_l1_)
			self.l1l1lllll111_l1_(l1l1ll1lll11_l1_)
			if self.l1l11111l11_l1_>0: break
		if self.l1ll1111lll1_l1_>0: self.l1l11111l11_l1_ = 10
		self.delete()
	def l1l1lllll111_l1_(self,l1l1ll1lll11_l1_):
		self.l1ll111l11ll_l1_ = l1l1ll1lll11_l1_
		self.getControl(9020).setPercent(self.l1ll111l11ll_l1_)
	def l11l11l1ll1_l1_(self):
		if self.l111l1l11l1_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll11ll1l11_l1_: self.getControl(9011).setEnabled(True)
		if self.l111l1l1lll_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll11l11ll_l1_)
		except: pass
class l11l11ll111_l1_():
	def __init__(self,l11_l1_=False,l1ll1lll1lll_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1ll1lll1lll_l1_ = l1ll1lll1lll_l1_
		self.l11l1l1l1ll_l1_,self.l1l111l111l_l1_ = [],[]
		self.l1111l1ll11_l1_,self.l1lllll1ll11_l1_ = {},{}
		self.l111ll1lll1_l1_ = []
		self.l1l1lllll11l_l1_,self.l1ll111111ll_l1_,self.l11lllll1l1_l1_ = {},{},{}
	def l11l111ll11_l1_(self,id,func,*args):
		id = str(id)
		self.l1111l1ll11_l1_[id] = l1l111_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ㓅")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧࠨ㓆"),id)
		from threading import Thread
		l1l11111ll1_l1_ = Thread(target=self.run,args=(id,func,args))
		self.l111ll1lll1_l1_.append(l1l11111ll1_l1_)
		return l1l11111ll1_l1_
	def start_new_thread(self,id,func,*args):
		l1l11111ll1_l1_ = self.l11l111ll11_l1_(id,func,*args)
		l1l11111ll1_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l1lllll11l_l1_[id] = time.time()
		try:
			self.l1lllll1ll11_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩ㓇") in str(func) and not self.l1lllll1ll11_l1_[id].succeeded:
				l11111l11l1_l1_(l1l111_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠࡵࡪࡵࡩࡦࡪࡥࡥࠢࡒࡔࡊࡔࡕࡓࡎࠣࡪࡦ࡯࡬ࠨ㓈"))
			self.l11l1l1l1ll_l1_.append(id)
			self.l1111l1ll11_l1_[id] = l1l111_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ㓉")
		except Exception as err:
			if self.l1ll1lll1lll_l1_:
				l1111llll11_l1_ = traceback.format_exc()
				sys.stderr.write(l1111llll11_l1_)
			self.l1l111l111l_l1_.append(id)
			self.l1111l1ll11_l1_[id] = l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㓊")
		self.l1ll111111ll_l1_[id] = time.time()
		self.l11lllll1l1_l1_[id] = self.l1ll111111ll_l1_[id] - self.l1l1lllll11l_l1_[id]
	def l1ll1lll1ll1_l1_(self):
		for proc in self.l111ll1lll1_l1_:
			proc.start()
	def l1l1lll1111l_l1_(self):
		while l1l111_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㓋") in list(self.l1111l1ll11_l1_.values()): time.sleep(1.000)
def l1lll111l11l_l1_():
	l1ll1l1lll11_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㓌"))
	l111l11lll1_l1_ = True
	if l1ll1l1lll11_l1_==l1l11l1llll_l1_:
		status = l1l111_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ㓍")
		l111l11lll1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭㓎")
		os.makedirs(addoncachefolder)
	else:
		status = l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㓏")
		l1ll11l1111l_l1_ = [l1l111_l1_ (u"ࠪ࠼࠳࠻࠮࠱ࠩ㓐"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠴࠳࠷࠹ࠨ㓑"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠶࠴࠲࠵ࡣࠪ㓒"),l1l111_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠸࠮࠴࠲ࠪ㓓"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠶࠳࠶࠲࠯࠲࠵ࠫ㓔"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠱࠱࠰࠵࠶ࠬ㓕"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠵࠱࠴࠻࠭㓖"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠸࠲࠶࠼ࠧ㓗"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠺࠳࠶࠶ࠨ㓘"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠵࠵࠴࠲࠹ࠩ㓙")]
		l1lllll1111l_l1_ = l1ll11l1111l_l1_[-1]
		l111l1ll11l_l1_ = l1l1ll1ll1l1_l1_(l1lllll1111l_l1_)
		l1llll111l1l_l1_ = l1l1ll1ll1l1_l1_(l1l11l1llll_l1_)
		if l1llll111l1l_l1_>l111l1ll11l_l1_:
			status = l1l111_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㓚")
	return status,l111l11lll1_l1_
def l11111l1111_l1_(l1lll111lll_l1_,l1lll1lllll1_l1_):
	succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_ = True,False,False
	type,name,l1l1l1ll11l_l1_,mode,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,context,l1llllll11l_l1_ = l1lll111lll_l1_
	l1ll11111l11_l1_ = type,name,l1l1l1ll11l_l1_,mode,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,l1l111_l1_ (u"ࠧࠨ㓛"),l1llllll11l_l1_
	l1ll1ll1ll1l_l1_ = int(mode)
	l1ll1ll1ll11_l1_ = int(l1ll1ll1ll1l_l1_%10)
	l1ll1ll1lll1_l1_ = int(l1ll1ll1ll1l_l1_/10)
	l1l1lll11111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㓜"))
	l111l11111l_l1_,l111l11lll1_l1_ = l1lll111l11l_l1_()
	if l111l11lll1_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㓝"),l1l111_l1_ (u"ࠪࠫ㓞"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㓟"),l1l111_l1_ (u"ࠬะๅࠡฬะำ๏ัࠠศๆหี๋อๅอࠢไ๎ࠥา็ศิๆࡠࡳหไ๊ࠢส่ส฻ฯศำࠣี็๋࠺࡝ࡰ࡟ࡲࠬ㓠")+l1l11l1llll_l1_)
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㓡"),l1l111_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㓢"))
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㓣"),l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㓤"))
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㓥"),l1l111_l1_ (u"ࠫࡆ࡛ࡔࡉࠩ㓦"))
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㓧"),l1l111_l1_ (u"࠭ࡉࡅࡕࠪ㓨"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ㓩"),l1l111_l1_ (u"ࠨࠩ㓪"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡴࡹࡴࡢࠩ㓫"),l1l111_l1_ (u"ࠪࠫ㓬"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡣࡴࡤ࡯ࡦ࠭㓭"),l1l111_l1_ (u"ࠬ࠭㓮"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㓯"),l1l111_l1_ (u"ࠧࠨ㓰"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㓱"),l1l111_l1_ (u"ࠩࠪ㓲"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㓳"),l1l111_l1_ (u"ࠫࠬ㓴"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ㓵"),l1l111_l1_ (u"࠭ࠧ㓶"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥࠩ㓷"),l1l111_l1_ (u"ࠨࠩ㓸"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡱࡱࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㓹"),l1l111_l1_ (u"ࠪࠫ㓺"))
		import l1l1l11l1ll_l1_
		if l111l11111l_l1_==l1l111_l1_ (u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ㓻"):
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㓼"),l1l111_l1_ (u"࠭࠮ࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡕࡌࡑࡕࡒࡅࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ㓽")+addon_path+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㓾"))
			l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ㓿"))
			l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ㔀"))
			l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ㔁"))
		else:
			l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㔂"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡇࡗࡏࡐ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ㔃")+addon_path+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㔄"))
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㔅"),l1l111_l1_ (u"ࠨࠩ㔆"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㔇"),l1l111_l1_ (u"ࠪฮ๊ࠦสฬสํฮࠥษ่ࠡฬะำ๏ัࠠศๆศูิอัࠡษ็ะิ๐ฯࠡๆหี๋อๅอࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢฦ์ࠥะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤࡡࡴ࡜࡯ࠢึ๎็๎ๅࠡษ็ฦ๋ࠦวๅสิ๊ฬ๋ฬࠡสห฽฻ࠦวๅใะ์ฺอสࠡๆู้ฬ์ฺࠠ็็ࠤฬ๊ศา่ส้ัࠦศึ๊ิอࠥ฻อ๋ฯฬࠤํ๋สไษ่่ฮ࠭㔈"))
			l11l1lllll1_l1_()
			FIX_ALL_DATABASES(False)
			l1l1l11l1ll_l1_.l1ll11l1llll_l1_()
			l1l1l11l1ll_l1_.l1l1ll11l11_l1_(l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㔉"),False)
			l1l1l11l1ll_l1_.l1l1ll11l11_l1_(l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㔊"),False)
			l1l1l11l1ll_l1_.l111111111l_l1_(False)
			l1l1l11l1ll_l1_.l1ll11l1l111_l1_(False)
			l1l1l11l1ll_l1_.l111ll11l1l_l1_(l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㔋"),l1l111_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࠧ㔌"),False)
			try:
				l11l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㔍"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㔎"),l1l111_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ㔏"),l1l111_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ㔐"))
				l1111l11l1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ㔑"))
				l1111l11l1l_l1_.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡤࡹࡹࡵ࡟ࡱ࡫ࡦ࡯ࠬ㔒"),l1l111_l1_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭㔓"))
			except: pass
			try:
				l11l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㔔"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㔕"),l1l111_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ㔖"),l1l111_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ㔗"))
				l1111l11l1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ㔘"))
				l1111l11l1l_l1_.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡹ࡭ࡩ࡫࡯ࡠࡳࡸࡥࡱ࡯ࡴࡺࠩ㔙"),l1l111_l1_ (u"ࠧ࠴ࠩ㔚"))
			except: pass
			try:
				l11l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㔛"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㔜"),l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ㔝"),l1l111_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ㔞"))
				l1111l11l1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㔟"))
				l1111l11l1l_l1_.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡖࡘࡗࡋࡁࡎࡕࡈࡐࡊࡉࡔࡊࡑࡑࠫ㔠"),l1l111_l1_ (u"ࠧ࠳ࠩ㔡"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l11llll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l1ll1ll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㔢"),l1l11l1llll_l1_)
		l1l1l11l1ll_l1_.l11lll11l11_l1_(False)
	l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㔣"))
	l1l111lll1_l1_ = l11lll1llll_l1_(l1lll1lllll1_l1_)
	l1l1l1111ll_l1_ = l11lll1llll_l1_(name)
	l11111l1l11_l1_ = [0,15,17,19,26,34,50,53]
	l1lll11l1111_l1_ = [0,15,17,19,26,34,50,53]
	l11llllllll_l1_ = l1ll1ll1lll1_l1_ not in l1lll11l1111_l1_
	l1l1lll111ll_l1_ = l1ll1ll1lll1_l1_ in [23,28,71,72]
	l1lll1lll111_l1_ = l1ll1ll1ll1l_l1_ in [265,270]
	l1llllll1111_l1_ = (l11llllllll_l1_ or l1l1lll111ll_l1_) and not l1lll1lll111_l1_
	l11l1lll1l1_l1_ = l1ll11ll1l_l1_!=l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㔤") and (l1ll11ll1l_l1_!=l1l111_l1_ (u"ࠫࠬ㔥") or context==l1l111_l1_ (u"ࠬ࠭㔦"))
	l1ll1lll11l1_l1_ = l1l111_l1_ (u"࠭ࡴࡺࡲࡨࡁࠬ㔧") in l1ll11ll1l_l1_
	l1ll11l1l1l1_l1_ = l1ll1ll1ll1l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1ll1ll1ll11_l1_==9 or l1ll1ll1ll1l_l1_ in [145,516,523,45]
	l11lll1lll1_l1_ = not l1ll11l1l1l1_l1_
	l11l1l1l111_l1_ = not l1lll1_l1_
	l1llll1111ll_l1_ = l1l111lll1_l1_ in [l1l111_l1_ (u"ࠧࠨ㔨"),l1l111_l1_ (u"ࠨ࠰࠱ࠫ㔩")]
	l111l1l1ll1_l1_ = l1llll1111ll_l1_ or l11lll1lll1_l1_
	l11111l1lll_l1_ = l1llll1111ll_l1_ or l11l1l1l111_l1_ or l1ll1lll11l1_l1_
	l1ll11111lll_l1_ = l1ll1ll1ll1l_l1_ not in [260,261,265,270,330,540]
	if l1l1lll11111_l1_: l111l1l11ll_l1_ = l1lll1_l1_ or l1ll11l1l1l1_l1_
	else: l111l1l11ll_l1_ = True
	l1ll1llll1_l1_ = l1ll1ll1lll1_l1_ in [74,75]
	l11lll11ll1_l1_ = l1ll1ll1ll1l_l1_ in [280,720]
	l111ll111l1_l1_ = not l1ll1llll1_l1_ and not l11lll11ll1_l1_
	l1l1lll11ll1_l1_ = l111l1l1ll1_l1_ and l11111l1lll_l1_ and l1ll11111lll_l1_ and l111l1l11ll_l1_ and l111ll111l1_l1_
	l11l1l111l1_l1_ = l1ll11111lll_l1_ and l111l1l11ll_l1_ and l111ll111l1_l1_
	l11ll111ll1_l1_ = l11l1l111l1_l1_
	l1l111l1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡱࡴࡲࡺ࡮ࡪࡥࡳࠩ㔪"))
	l111lll1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡥࡲࡨࡪ࠭㔫"))
	if 1 and l11l1lll1l1_l1_ and l1l1lll11ll1_l1_:
		l1lllll1l11l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㔬"),l1l111_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㔭")+l1l111l1l11_l1_+l1l111_l1_ (u"࠭࡟ࠨ㔮")+l111lll1l1l_l1_,l1ll11111l11_l1_)
		if l1lllll1l11l_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠧࠨ㔯"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㔰")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠩࡢࠫ㔱")+l111lll1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࡌࡰࡣࡧ࡭ࡳ࡭ࠠ࡮ࡧࡱࡹࠥ࡬ࡲࡰ࡯ࠣࡧࡦࡩࡨࡦࠩ㔲"))
			if 1 and l1ll1lll11l1_l1_:
				l11lll1l111_l1_ = []
				from l1ll111l1l1l_l1_ import l1lllll11ll1_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1llll111111_l1_ = l1lllll11ll1_l1_
				l11lll1111l_l1_ = GET_ALL_FAVORITES()
				l1111l1llll_l1_ = l1ll11ll1l_l1_
				l11l11lllll_l1_,l11l1l1ll11_l1_,l1lll1lll11l_l1_,l1ll1ll11ll1_l1_,l11ll11l1l1_l1_,l111111ll11_l1_,l11l1l1ll1l_l1_,l1lll11ll11l_l1_,l111111l111_l1_ = EXTRACT_KODI_PATH(l1111l1llll_l1_)
				l1llll1111l1_l1_ = l11l11lllll_l1_,l11l1l1ll11_l1_,l1lll1lll11l_l1_,l1ll1ll11ll1_l1_,l11ll11l1l1_l1_,l111111ll11_l1_,l11l1l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ㔳"),l111111l111_l1_
				for l1l111l1l1l_l1_ in l1lllll1l11l_l1_:
					l1ll1l111ll1_l1_ = l1l111l1l1l_l1_[l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࡌࡸࡪࡳࠧ㔴")]
					if l1ll1l111ll1_l1_==l1llll1111l1_l1_ or l1l111l1l1l_l1_[l1l111_l1_ (u"࠭࡭ࡰࡦࡨࠫ㔵")] in [265,270]:
						l1l111l1l1l_l1_ = GET_LIST_ITEM(l1ll1l111ll1_l1_,l1llll111111_l1_,l11lll1111l_l1_)
						if l1l111l1l1l_l1_[l1l111_l1_ (u"ࠧࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࠪ㔶")]:
							l1ll1l1lll1l_l1_ = GET_FAVORITES_CONTEXT_MENU(l11lll1111l_l1_,l1ll1l111ll1_l1_,l1l111l1l1l_l1_[l1l111_l1_ (u"ࠨࡰࡨࡻࡵࡧࡴࡩࠩ㔷")])
							l1l111l1l1l_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ㔸")] = l1ll1l1lll1l_l1_+l1l111l1l1l_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ㔹")]
					l11lll1l111_l1_.append(l1l111l1l1l_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㔺"),l1l111_l1_ (u"ࠬ࠭㔻"))
				if type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㔼"): l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㔽")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠨࡡࠪ㔾")+l111lll1l1l_l1_,l1ll11111l11_l1_,l11lll1l111_l1_,l11l1l1_l1_)
			else: l11lll1l111_l1_ = l1lllll1l11l_l1_
			if type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔿") and l1l111lll1_l1_!=l1l111_l1_ (u"ࠪ࠲࠳࠭㕀") and l1llllll1111_l1_: l1l1ll111ll_l1_()
			l11l1ll1ll1_l1_ = CREATE_KODI_MENU(l1ll11111l11_l1_,l11lll1l111_l1_,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
			return
	elif type==l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕁") and l1ll11ll1l_l1_==l1l111_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㕂") and l11l1l111l1_l1_:
		l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㕃")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠧࡠࠩ㕄")+l111lll1l1l_l1_,l1ll11111l11_l1_)
	if l1l111_l1_ (u"ࠨࡡࠪ㕅") in context: l1lll11l1l11_l1_,l1ll1111ll11_l1_ = context.split(l1l111_l1_ (u"ࠩࡢࠫ㕆"),1)
	else: l1lll11l1l11_l1_,l1ll1111ll11_l1_ = context,l1l111_l1_ (u"ࠪࠫ㕇")
	if l1lll11l1l11_l1_ in [l1l111_l1_ (u"ࠫ࠶࠭㕈"),l1l111_l1_ (u"ࠬ࠸ࠧ㕉"),l1l111_l1_ (u"࠭࠳ࠨ㕊"),l1l111_l1_ (u"ࠧ࠵ࠩ㕋"),l1l111_l1_ (u"ࠨ࠷ࠪ㕌")] and l1ll1111ll11_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㕍"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㕎"))
		return
	elif l1lll11l1l11_l1_==l1l111_l1_ (u"ࠫ࠻࠭㕏"):
		if l1ll1111ll11_l1_==l1l111_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㕐"): l1ll1lll_l1_(l1l111_l1_ (u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭㕑"),l1l111_l1_ (u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧ㕒"))
		elif l1ll1111ll11_l1_==l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠨ㕓"): l1ll1ll1ll1l_l1_ = 334
		l1lll_l1_ = l1ll1l11l11l_l1_(type,l1l1l1111ll_l1_,l1l1l1ll11l_l1_,l1ll1ll1ll1l_l1_,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,context,l1llllll11l_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㕔"))
		return
	elif context==l1l111_l1_ (u"ࠪ࠻ࠬ㕕"):
		from l1111l11l1_l1_ import l1lll111l11_l1_
		l1lll111l11_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㕖"))
		return
	elif context==l1l111_l1_ (u"ࠬ࠾ࠧ㕗"):
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㕘")+addon_id+l1l111_l1_ (u"ࠧࡀ࡯ࡲࡨࡪࡃࠧ㕙")+str(mode)+l1l111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠩࠨ㕚"))
		return
	elif context==l1l111_l1_ (u"ࠩ࠼ࠫ㕛"):
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㕜"),l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ㕝"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㕞"))
		return
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㕟")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㕠"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㕡"),l1l111_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ㕢")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㕣"),l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㕤"))
	if not settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ㕥")): settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭㕦"),l1111l11lll_l1_[0])
	l1l1llll1111_l1_ = False if l1l11llllll_l1_(l1l111_l1_ (u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ㕧")) else True
	l1l111111ll_l1_ = l111l11l_l1_ if l1l1llll1111_l1_ else l11l1l1_l1_
	l11llll111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㕨"))
	l1ll1111l111_l1_ = l111111llll_l1_(settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㕩")))
	l1ll1111l111_l1_ = 0 if not l1ll1111l111_l1_ else int(l1ll1111l111_l1_)
	if l11llll111l_l1_ in [l1l111_l1_ (u"ࠪࠫ㕪"),l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㕫")] or not l1l111111ll_l1_ or not l1ll1111l111_l1_ or now-l1ll1111l111_l1_<0 or now-l1ll1111l111_l1_>l1l111111ll_l1_:
		l11llll111l_l1_ = l11111ll1l1_l1_(True,False)
	l11lllll1ll_l1_ = l111111llll_l1_(settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡫ࡱࡪࡴࡹ࠮ࡱࡧࡵ࡭ࡴࡪࠧ㕬")))
	l11lllll1ll_l1_ = 0 if not l11lllll1ll_l1_ else int(l11lllll1ll_l1_)
	l11l1l1l11l_l1_ = l111111llll_l1_(settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ㕭")))
	l11l1l1l11l_l1_ = 0 if not l11l1l1l11l_l1_ else int(l11l1l1l11l_l1_)
	if not l11lllll1ll_l1_ or not l11l1l1l11l_l1_ or now-l11l1l1l11l_l1_<0 or now-l11l1l1l11l_l1_>l11lllll1ll_l1_:
		l1ll1l1ll11l_l1_ = 1
		if l1l1llll1111_l1_:
			l1ll1l11l111_l1_ = l11llll1lll_l1_(True)
			if len(l1ll1l11l111_l1_)>1:
				l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㕮"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ㕯")+addon_path+l1l111_l1_ (u"ࠩࠣࡡࠬ㕰"))
				id,l1l1ll1ll111_l1_,l1l1llllll1l_l1_,l11l11l1l11_l1_,l11l111ll1l_l1_,reason = l1ll1l11l111_l1_[0]
				l1111l1ll1l_l1_,l1111l1lll1_l1_ = l11l11l1l11_l1_.split(l1l111_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ㕱"))
				del l1ll1l11l111_l1_[0]
				l1ll1ll1llll_l1_ = random.sample(l1ll1l11l111_l1_,1)
				id,l1l1ll1ll111_l1_,l1l1llllll1l_l1_,l11l11l1l11_l1_,l11l111ll1l_l1_,reason = l1ll1ll1llll_l1_[0]
				l1l1llllll1l_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥࡀࠠࠨ㕲")+id+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㕳")+l1l1llllll1l_l1_
				l11l111ll1l_l1_ = l1l111_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠫ㕴")
				l1llllllll1l_l1_ = l1l111_l1_ (u"ࠧศๆอฬึ฿วหࠩ㕵")
				l111l1l11l1_l1_,l1ll11ll1l11_l1_ = l11l11l1l11_l1_,l11l111ll1l_l1_
				l111llll_l1_ = [l111l1l11l1_l1_,l1ll11ll1l11_l1_,l1llllllll1l_l1_]
				l11l1111111_l1_ = 5 if l1l11llllll_l1_(l1l111_l1_ (u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩ㕶")) else 5
				l11l111111l_l1_ = -9
				while l11l111111l_l1_<0:
					l11l1ll1111_l1_ = random.sample(l111llll_l1_,3)
					l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠩࠪ㕷"),l11l1ll1111_l1_[0],l11l1ll1111_l1_[1],l11l1ll1111_l1_[2],l1111l1ll1l_l1_,l1l1llllll1l_l1_,l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㕸"),l11l1111111_l1_,60)
					if l11l111111l_l1_==10: break
					from l1l1l11l1ll_l1_ import l1ll1lllll1l_l1_,l1l1l1ll1ll_l1_
					if l11l111111l_l1_>=0 and l11l1ll1111_l1_[l11l111111l_l1_]==l111llll_l1_[1]:
						l1ll1lllll1l_l1_()
						if l11l111111l_l1_>=0: l11l111111l_l1_ = -9
					elif l11l111111l_l1_>=0 and l11l1ll1111_l1_[l11l111111l_l1_]==l111llll_l1_[2]:
						l1l1l1ll1ll_l1_(False)
					if l11l111111l_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㕹"),l1l111_l1_ (u"ࠬ࠭㕺"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㕻"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ัีําࠠฯูฦ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠠๅๆัีําࠠศๆุั๏ำࠠฤะอีࠥ๎วฮั้๋ࠣࠦวๅลฯ์อฯࠠศๆ่ฮํ็ัสࠩ㕼"))
				l1ll1l1ll11l_l1_ = 1
			else: l1ll1l1ll11l_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㕽"),l1lll1111111_l1_(now))
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㕾"),l1l111_l1_ (u"ࠪࡅ࡚࡚ࡈࠨ㕿"),l1ll1l1ll11l_l1_,l1ll111l1l1_l1_)
	l1lll_l1_ = l1ll1l11l11l_l1_(type,l1l1l1111ll_l1_,l1l1l1ll11l_l1_,mode,l1l1ll11lll_l1_,l1l111ll1ll_l1_,text,context,l1llllll11l_l1_)
	if l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㖀") in text: l1111lll1l1_l1_ = True
	if type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㖁"):
		if l1l111lll1_l1_!=l1l111_l1_ (u"࠭࠮࠯ࠩ㖂") and l1llllll1111_l1_: l1l1ll111ll_l1_()
		if addon_handle>-1:
			if (l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡪࡰࡷࠫ㖃"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㖄"),l1l111_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ㖅")) or l1ll1ll1ll1l_l1_ not in l11111l1l11_l1_) and not l1l11llllll_l1_(l1l111_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㖆")):
				from l1ll111l1l1l_l1_ import l1lllll11ll1_l1_
				l1lllll1l11l_l1_ = GET_ALL_LIST_ITEMS(l1lllll11ll1_l1_)
				l11l1ll1ll1_l1_ = CREATE_KODI_MENU(l1ll11111l11_l1_,l1lllll1l11l_l1_,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
				if 1 and l1lllll1l11l_l1_ and l11ll111ll1_l1_:
					l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㖇")+l1l111l1l11_l1_+l1l111_l1_ (u"ࠬࡥࠧ㖈")+l111lll1l1l_l1_,l1ll11111l11_l1_,l1lllll1l11l_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㖉")+addon_id+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ㖊"),xbmcgui.ListItem(l1l111_l1_ (u"ࠨๆา๎่ࠦๅีๅ็อ๋ࠥๆࠡฮ๊หื้ࠧ㖋")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㖌")+addon_id+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ㖍"),xbmcgui.ListItem(l1l111_l1_ (u"ࠫศ็สฮࠢ็ฮ็ืรࠡษ็ฮๆอี๋ๆࠪ㖎")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
	return
def l1ll1l11l11l_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_):
	l1ll1ll1ll1l_l1_ = int(mode)
	l1ll1ll1lll1_l1_ = int(l1ll1ll1ll1l_l1_//10)
	if   l1ll1ll1lll1_l1_==0:  from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==2:  from l1ll1ll1lll_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==3:  from l11l11lll11_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==5:  from l11lllll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==8:  from l1ll1lll111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==9:  from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==10: from l1lll1llll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url)
	elif l1ll1ll1lll1_l1_==11: from l1ll11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==12: from l11l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==14: from l11lll1l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1ll1ll1lll1_l1_==15: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==16: from l1ll11l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==17: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==18: from l1l1lll1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==19: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==21: from l111lllllll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==22: from l111l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==26: from l1ll111l1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,context)
	elif l1ll1ll1lll1_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==29: from l11ll1l111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==30: from l1111111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==31: from l11l1l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==32: from l1ll11lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==33: from l11lll1l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url)
	elif l1ll1ll1lll1_l1_==34: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==36: from l1lll1l11l11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==38: from l1ll1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==39: from l1llll1lll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==40: from l1l1l11l1l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==41: from l1l1l11l1l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==43: from l111l111l1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==44: from l111l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==45: from l1l1111l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==46: from l11111l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==47: from l111111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==48: from l1ll111lll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==49: from l1111l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==50: from l1l1l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,text)
	elif l1ll1ll1lll1_l1_==51: from l1111l111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==52: from l1111l111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==53: from l1ll111l1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==54: from l1111l11l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1ll1lll1_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==56: from l1ll1l1111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==57: from l1llll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==58: from l11ll1lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==59: from l1llll11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==60: from l1llll111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==62: from l1lllll11l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==63: from l1111l11l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==64: from l1111lll11l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==66: from l11llll1111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==67: from l1ll11ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==68: from l11ll11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==70: from l1ll111ll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll1ll1l_l1_,url,text,type,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==74: from l1ll1llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_)
	elif l1ll1ll1lll1_l1_==75: from l1ll1llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_)
	elif l1ll1ll1lll1_l1_==76: from l1ll11l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text,l1llllll1_l1_,l1llllll11l_l1_)
	elif l1ll1ll1lll1_l1_==77: from l111llll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==78: from l111ll1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==79: from l111ll11l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==80: from l111l1ll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll1lll1_l1_==81: from l1ll11llll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,text)
	elif l1ll1ll1lll1_l1_==82: from l1111llll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll1ll1l_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l1l1111lll_l1_(name=l1l111_l1_ (u"ࠬ࠭㖏")):
	if not name: name = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ㖐"))
	name = name.replace(l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㖑"),l1l111_l1_ (u"ࠨࠩ㖒"))
	name = name.replace(l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ㖓"),l1l111_l1_ (u"ࠪࠤࠬ㖔")).replace(l1l111_l1_ (u"ࠫࠥࠦࠠࠨ㖕"),l1l111_l1_ (u"ࠬࠦࠧ㖖")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ㖗"),l1l111_l1_ (u"ࠧࠡࠩ㖘")).strip(l1l111_l1_ (u"ࠨࠢࠪ㖙"))
	name = name.replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㖚"),l1l111_l1_ (u"ࠪࠫ㖛")).replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㖜"),l1l111_l1_ (u"ࠬ࠭㖝"))
	tmp = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢࠪ㖞"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l111_l1_ (u"ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪ㖟")
	return name
def l1lllll11lll_l1_(code,reason,source,l11_l1_):
	l1111111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ㖠"))
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㖡"),l1l111_l1_ (u"ࠪࠫ㖢"))
	if l1l111_l1_ (u"ࠫ࠲࠭㖣") in source: l1lll11l1ll_l1_ = source.split(l1l111_l1_ (u"ࠬ࠳ࠧ㖤"),1)[0]
	else: l1lll11l1ll_l1_ = source
	l11l1ll1lll_l1_ = code in [7,11001,11002,10054]
	l1l1lll11l1l_l1_ = reason.lower()
	l1llll1l1lll_l1_ = code in [0,104,10061,111]
	l1llll1l1ll1_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ㖥") in l1l1lll11l1l_l1_
	l1llll1l1l1l_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ㖦") in l1l1lll11l1l_l1_
	l1llll1l1l11_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ㖧") in l1l1lll11l1l_l1_
	l1llll1l11ll_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ㖨") in l1l1lll11l1l_l1_
	l1ll11l1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㖩"))
	l1ll111ll11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㖪"))
	l11111lll1l_l1_ = l1l111_l1_ (u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ㖫")
	l111111ll1l_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥ࠭㖬")+str(code)+l1l111_l1_ (u"ࠧ࠻ࠢࠪ㖭")+reason
	l111111ll1l_l1_ = l111l11_l1_(l111111ll1l_l1_)
	if l1llll1l1lll_l1_ or l1llll1l1ll1_l1_ or l1llll1l1l1l_l1_ or l1llll1l1l11_l1_ or l1llll1l11ll_l1_:
		l11111lll1l_l1_ += l1l111_l1_ (u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨ㖮")
	if l11l1ll1lll_l1_: l11111lll1l_l1_ += l1l111_l1_ (u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩ㖯")
	l111111ll1l_l1_ = l1l111_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㖰")+l111111ll1l_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㖱")
	if l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㖲") or l1ll111ll11l_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㖳"):
		l11111lll1l_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㖴")
	l11llll1l11_l1_ = False
	if l11_l1_ and source not in l1llllll1ll1_l1_:
		if l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㖵") or l1ll111ll11l_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㖶"):
			l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㖷"),l1l111_l1_ (u"ࠫำื่อࠩ㖸"),l1l111_l1_ (u"ࠬหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠪ㖹"),l1l111_l1_ (u"࠭ลึๆสัࠥอไๆึๆ่ฮ࠭㖺"),l1lll11l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㖻")+TRANSLATE(l1lll11l1ll_l1_),l11111lll1l_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㖼")+l111111ll1l_l1_)
			if l11l111111l_l1_==1:
				from l1l1l11l1ll_l1_ import l1ll1lllll1l_l1_
				l1ll1lllll1l_l1_()
			elif l11l111111l_l1_==2: l11llll1l11_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㖽"),l1l111_l1_ (u"ࠪࠫ㖾"),l1lll11l1ll_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠨ㖿")+TRANSLATE(l1lll11l1ll_l1_),l11111lll1l_l1_,l111111ll1l_l1_)
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㗀"),l1111111lll_l1_)
	return l11llll1l11_l1_
def l11l1lllll1_l1_(l1ll111l11l1_l1_=False):
	l1111l111l1_l1_ = [l1l1l11llll_l1_,favoritesfile,l1l1ll1ll1ll_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1ll111l11l1_l1_ and (filename.startswith(l1l111_l1_ (u"࠭ࡩࡱࡶࡹࠫ㗁")) or filename.startswith(l1l111_l1_ (u"ࠧ࡮࠵ࡸࠫ㗂"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡥࠧ㗃")): continue
		l1lllll1l1ll_l1_ = os.path.join(addoncachefolder,filename)
		if l1lllll1l1ll_l1_ in l1111l111l1_l1_: continue
		try: os.remove(l1lllll1l1ll_l1_)
		except: pass
	time.sleep(1)
	return
def l1lll1ll1111_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_=True,l1lll1111lll_l1_=True):
	l1ll11lllll1_l1_,l1lll1ll11ll_l1_ = proxy.split(l1l111_l1_ (u"ࠩ࠽ࠫ㗄"))
	url = url+l1l111_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ㗅")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_,l1lll1111lll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l11111l11l1_l1_(l1l111_l1_ (u"ࠫࡍ࡚ࡔࡑࠢࡕࡩࡶࡻࡥࡴࡶࠣࡊࡦ࡯࡬ࡶࡴࡨࠫ㗆"))
	return response
def l1ll111l1ll1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㗇"),url,l1l111_l1_ (u"࠭ࠧ㗈"),l1l111_l1_ (u"ࠧࠨ㗉"),True,l1l111_l1_ (u"ࠨࠩ㗊"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㗋"),True,False)
	l111l1l1l11_l1_ = []
	if response.succeeded:
		html = response.content
		l1ll1llllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭㗌"),html)
		if l1ll1llllll1_l1_: html = l1l111_l1_ (u"ࠫࡡࡴࠧ㗍").join(l1ll1llllll1_l1_)
		proxies = html.replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㗎"),l1l111_l1_ (u"࠭ࠧ㗏")).strip(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㗐")).split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㗑"))
		l111l1l1l11_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠩ࠱ࠫ㗒"))==3: l111l1l1l11_l1_.append(proxy)
	return l111l1l1l11_l1_
def l11ll1ll1ll_l1_(*args):
	l11llllll11_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡲࡵࡳࡽࡿࡳࡤࡴࡤࡴࡪ࠴ࡣࡰ࡯࠲ࡺ࠷࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ㗓")
	l1llll1lll11_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡴࡵࡳࡵࡧࡵ࡯࡮ࡪ࠯ࡰࡲࡨࡲࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯࡮ࡣ࡬ࡲ࠴ࡎࡔࡕࡒࡖ࠲ࡹࡾࡴࠨ㗔")
	l111l1l1l1l_l1_ = l1ll111l1ll1_l1_(l1llll1lll11_l1_)
	l111l1l1l11_l1_ = l1ll111l1ll1_l1_(l11llllll11_l1_)
	l1l1111l11l_l1_ = l111l1l1l1l_l1_+l111l1l1l11_l1_
	l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㗕"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬ㗖")+str(len(l111l1l1l1l_l1_))+l1l111_l1_ (u"ࠧࠬࠩ㗗")+str(len(l111l1l1l11_l1_))+l1l111_l1_ (u"ࠨࠢࡠࠫ㗘"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㗙"))
	response = l1l1lllll1l_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ㗚"),l1l111_l1_ (u"ࠫࠬ㗛"))
	if proxy or l1l1111l11l_l1_:
		id,l1l111ll11l_l1_ = 0,10
		l111ll11ll1_l1_ = len(l1l1111l11l_l1_)
		l111llll1ll_l1_ = l1l111ll11l_l1_
		if l111ll11ll1_l1_>l111llll1ll_l1_: counts = l111llll1ll_l1_
		else: counts = l111ll11ll1_l1_
		l11l1l1llll_l1_ = random.sample(l1l1111l11l_l1_,counts)
		if proxy: l11l1l1llll_l1_ = [proxy]+l11l1l1llll_l1_
		threads = l11l11ll111_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l111ll11l_l1_ and not threads.l11l1l1l1ll_l1_:
			if id<counts:
				proxy = l11l1l1llll_l1_[id]
				threads.start_new_thread(id,l1lll1ll1111_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㗜"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㗝")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㗞"))
		l11l1l1l1ll_l1_ = threads.l11l1l1l1ll_l1_
		if l11l1l1l1ll_l1_:
			l1lllll1ll11_l1_ = threads.l1lllll1ll11_l1_
			l111111l1ll_l1_ = l11l1l1l1ll_l1_[0]
			response = l1lllll1ll11_l1_[l111111l1ll_l1_]
			proxy = l11l1l1llll_l1_[int(l111111l1ll_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㗟"),proxy)
			if l111111l1ll_l1_!=0: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㗠"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㗡")+proxy+l1l111_l1_ (u"ࠫࠥࡣࠧ㗢"))
			else: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㗣"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ㗤")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㗥"))
	return response
def l1ll11111111_l1_(connection,l1l1lll1llll_l1_):
	l11l11l1111_l1_ = connection.create_connection
	def l1ll1l11ll1l_l1_(address,*args,**kwargs):
		host,port = address
		l1ll1lll11ll_l1_ = DNS_RESOLVER(host,l1l1lll1llll_l1_)
		if l1ll1lll11ll_l1_: host = l1ll1lll11ll_l1_[0]
		else:
			if l1l1lll1llll_l1_ in l1111l11lll_l1_: l1111l11lll_l1_.remove(l1l1lll1llll_l1_)
			if l1111l11lll_l1_:
				l111lll1111_l1_ = l1111l11lll_l1_[0]
				l1ll1lll11ll_l1_ = DNS_RESOLVER(host,l111lll1111_l1_)
				if l1ll1lll11ll_l1_: host = l1ll1lll11ll_l1_[0]
		address = (host,port)
		return l11l11l1111_l1_(address,*args,**kwargs)
	connection.create_connection = l1ll1l11ll1l_l1_
	return l11l11l1111_l1_
def l1l1lll1l11l_l1_(url):
	l11l1lll1ll_l1_,l111l111lll_l1_ = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ㗦"))[2],80
	if l1l111_l1_ (u"ࠩ࠽ࠫ㗧") in l11l1lll1ll_l1_: l11l1lll1ll_l1_,l111l111lll_l1_ = l11l1lll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠾ࠬ㗨"))
	l11l111l111_l1_ = l1l111_l1_ (u"ࠫ࠴࠭㗩")+l1l111_l1_ (u"ࠬ࠵ࠧ㗪").join(url.split(l1l111_l1_ (u"࠭࠯ࠨ㗫"))[3:])
	request = l1l111_l1_ (u"ࠧࡈࡇࡗࠤࠬ㗬")+l11l111l111_l1_+l1l111_l1_ (u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ㗭")
	request += l1l111_l1_ (u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ㗮")+l11l1lll1ll_l1_+l1l111_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ㗯")
	request += l1l111_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㗰")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1lll1ll_l1_,l111l111lll_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"ࠬ࠭㗱")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"࠭࠮ࠨ㗲") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ㗳")
	l1ll1l1l1lll_l1_,l1ll1l1l1ll1_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠰ࠪ㗴"),1)
	l1ll1l1l1l1l_l1_,l1ll1l1l1l11_l1_ = l1ll1l1l1ll1_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ㗵"),1)
	server = l1ll1l1l1lll_l1_+l1l111_l1_ (u"ࠪ࠲ࠬ㗶")+l1ll1l1l1l1l_l1_
	if type in [l1l111_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ㗷"),l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㗸")] and l1l111_l1_ (u"࠭࠯ࠨ㗹") in server: server = server.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩ㗺"),1)[1]
	if type==l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㗻") and l1l111_l1_ (u"ࠩ࠱ࠫ㗼") in server:
		l1lll111lll1_l1_ = server.split(l1l111_l1_ (u"ࠪ࠲ࠬ㗽"))
		l1l1l1l1lll_l1_ = len(l1lll111lll1_l1_)
		if l1l1l1l1lll_l1_<=2 or l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㗾") in server: l1lll111lll1_l1_ = l1lll111lll1_l1_[0]
		elif l1l1l1l1lll_l1_>=3: l1lll111lll1_l1_ = l1lll111lll1_l1_[1]
		if len(l1lll111lll1_l1_)>1: server = l1lll111lll1_l1_
	return server
def l111ll11lll_l1_(l11l11ll1l1_l1_):
	l11l11ll1ll_l1_ = repr(l11l11ll1l1_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㗿"))).replace(l1l111_l1_ (u"ࠨࠧࠣ㘀"),l1l111_l1_ (u"ࠧࠨ㘁"))
	return l11l11ll1ll_l1_
def l1ll11l111l_l1_(string):
	l1ll111111l1_l1_ = l1l111_l1_ (u"ࠨࠩ㘂")
	if kodi_version<19: string = string.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㘃"))
	from unicodedata import decomposition
	for l1lllllll1l1_l1_ in string:
		if   l1lllllll1l1_l1_==l1l111_l1_ (u"ࡸࠫว࠭㘄"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ㘅")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡺ࠭รࠨ㘆"): l11111l1l1l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧ㘇")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡵࠨฦࠪ㘈"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ㘉")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡷࠪษࠬ㘊"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ㘋")
		elif l1lllllll1l1_l1_==l1l111_l1_ (u"ࡹࠬฬࠧ㘌"): l11111l1l1l_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭㘍")
		else:
			l1l1ll1l11ll_l1_ = decomposition(l1lllllll1l1_l1_)
			if l1l111_l1_ (u"࠭ࠠࠨ㘎") in l1l1ll1l11ll_l1_: l11111l1l1l_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸࠫ㘏")+l1l1ll1l11ll_l1_.split(l1l111_l1_ (u"ࠨࠢࠪ㘐"),1)[1]
			else:
				l11111l1l1l_l1_ = l1l111_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ㘑")+hex(ord(l1lllllll1l1_l1_)).replace(l1l111_l1_ (u"ࠪ࠴ࡽ࠭㘒"),l1l111_l1_ (u"ࠫࠬ㘓"))
				l11111l1l1l_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶࠩ㘔")+l11111l1l1l_l1_[-4:]
		l1ll111111l1_l1_ += l11111l1l1l_l1_
	l1ll111111l1_l1_ = l1ll111111l1_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧ㘕"),l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨ㘖"))
	if kodi_version<19: l1ll111111l1_l1_ = l1ll111111l1_l1_.decode(l1l111_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㘗")).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㘘"))
	else: l1ll111111l1_l1_ = l1ll111111l1_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㘙")).decode(l1l111_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㘚"))
	return l1ll111111l1_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"๊่ࠬฮหࠣห้๋แศฬํัࠬ㘛"),default=l1l111_l1_ (u"࠭ࠧ㘜"),l111llll11l_l1_=False,source=l1l111_l1_ (u"ࠧࠨ㘝")):
	text = l1ll1llll111_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠨࠢࠣࠫ㘞"),l1l111_l1_ (u"ࠩࠣࠫ㘟")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭㘠"),l1l111_l1_ (u"ࠫࠥ࠭㘡")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ㘢"),l1l111_l1_ (u"࠭ࠠࠨ㘣"))
	if not text and not l111llll11l_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㘤"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ㘥")+text+l1l111_l1_ (u"ࠩࠥࠫ㘦"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㘧"),l1l111_l1_ (u"ࠫࠬ㘨"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㘩"),l1l111_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩ㘪"))
		return l1l111_l1_ (u"ࠧࠨ㘫")
	if text not in [l1l111_l1_ (u"ࠨࠩ㘬"),l1l111_l1_ (u"ࠩࠣࠫ㘭")]:
		text = text.strip(l1l111_l1_ (u"ࠪࠤࠬ㘮"))
		text = l1ll11l111l_l1_(text)
	if source!=l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭㘯") and l11111l_l1_(l1l111_l1_ (u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧ㘰"),l1l111_l1_ (u"࠭ࠧ㘱"),[text],False):
		l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㘲"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ㘳")+text+l1l111_l1_ (u"ࠩࠥࠫ㘴"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㘵"),l1l111_l1_ (u"ࠫࠬ㘶"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㘷"),l1l111_l1_ (u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨ㘸"))
		return l1l111_l1_ (u"ࠧࠨ㘹")
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㘺"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ㘻")+text+l1l111_l1_ (u"ࠪࠦࠬ㘼"))
	return text
def l1l11l1ll1_l1_(l1lllll1_l1_,headers={}):
	url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ㘽")
	if l1l111_l1_ (u"ࠬࢂࠧ㘾") in l1lllll1_l1_:
		url,params = l1lllll1_l1_.split(l1l111_l1_ (u"࠭ࡼࠨ㘿"),1)
		if l1l111_l1_ (u"ࠧ࠾ࠩ㙀") not in params: url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ㙁")
	response = l11l1l_l1_(l1lll11lll1l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㙂"),url,l1l111_l1_ (u"ࠪࠫ㙃"),headers,l1l111_l1_ (u"ࠫࠬ㙄"),l1l111_l1_ (u"ࠬ࠭㙅"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ㙆"),False,False)
	html = response.content
	if l1l111_l1_ (u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫ㙇") not in html: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㙈")],[l1lllll1_l1_]
	if l1l111_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭㙉") in html: return [l1l111_l1_ (u"ࠪ࠱࠶࠭㙊")],[l1lllll1_l1_]
	if l1l111_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ㙋") in html: return [l1l111_l1_ (u"ࠬ࠳࠱ࠨ㙌")],[l1lllll1_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111l1llll1_l1_,l1lll111ll11_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ㙍"),html+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㙎"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㙏")],[l1lllll1_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1l1lllll1l1_l1_,l11ll1l11ll_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠩࠪ㙐")
		items = line.split(l1l111_l1_ (u"ࠪ࠰ࠬ㙑"))
		for item in items:
			if l1l111_l1_ (u"ࠫࡂ࠭㙒") in item:
				key,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ㙓"),1)
				l1l1lllll1l1_l1_[key.lower()] = value
		if l1l111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㙔") in line.lower():
			l11ll1l11ll_l1_ = int(l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㙕")])//1024
			title += str(l11ll1l11ll_l1_)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㙖")
		elif l1l111_l1_ (u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㙗") in line.lower():
			l11ll1l11ll_l1_ = int(l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㙘")])//1024
			title += str(l11ll1l11ll_l1_)+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㙙")
		if l1l111_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㙚") in line.lower():
			l111l1ll_l1_ = int(l1l1lllll1l1_l1_[l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ㙛")].split(l1l111_l1_ (u"ࠧࡹࠩ㙜"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠫ㙝")
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠤࠬ㙞"))
		if not title: title = l1l111_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ㙟")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㙠")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࠵࠯ࠨ㙡")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"࠭࠺ࠨ㙢"),1)[0]+l1l111_l1_ (u"ࠧ࠻ࠩ㙣")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨ࠱ࠪ㙤")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭㙥"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㙦"),1)[0]+l1l111_l1_ (u"ࠫ࠴࠭㙧")+l1ll1ll_l1_
		if params!=l1l111_l1_ (u"ࠬ࠭㙨"): l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࠨ㙩")+params
		if l1l111_l1_ (u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ㙪") in list(l1l1lllll1l1_l1_.keys()):
			l111lllll_l1_ = l1l1lllll1l1_l1_[l1l111_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ㙫")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠩࠥࠫ㙬"),l1l111_l1_ (u"ࠪࠫ㙭")).replace(l1l111_l1_ (u"ࠦࠬࠨ㙮"),l1l111_l1_ (u"ࠬ࠭㙯")).split(l1l111_l1_ (u"࠭ࠣࠨ㙰"),1)[0]
			l11ll1l11l_l1_ = l1l111ll1l_l1_(l111lllll_l1_)
			if l11ll1l11l_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠧࠡࠢࠪ㙱")+l11ll1l11l_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ㙲")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠩࠣࠤࠬ㙳")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ㙴"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111l1llll1_l1_.append(l111l1ll_l1_)
			l1lll111ll11_l1_.append(l11ll1l11ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠨ࠭㙵"),1)[0]
		l11ll1l11l_l1_ = l1l111ll1l_l1_(l1ll1ll_l1_)
		if l11ll1l11l_l1_: title = title+l1l111_l1_ (u"ࠬࠦࠠࠨ㙶")+l11ll1l11l_l1_
		title = title+l1l111_l1_ (u"࠭ࠠࠡࠩ㙷")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㙸"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111l1llll1_l1_.append(l111l1ll_l1_)
		l1lll111ll11_l1_.append(l11ll1l11ll_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111l1llll1_l1_,l1lll111ll11_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111l1llll1_l1_,l1lll111ll11_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1l1lll1llll_l1_=l1l111_l1_ (u"ࠨࠩ㙹")):
	if not l1l1lll1llll_l1_: l1l1lll1llll_l1_ = l1111l11lll_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠩ࠱ࠫ㙺"),l1l111_l1_ (u"ࠪࠫ㙻")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l1111l11111_l1_ = pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㙼"), 12049)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㙽"), 256)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㙾"), 1)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㙿"), 0)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㚀"), 0)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚁"), 0)
		if kodi_version>18.99: l1lllll11l1l_l1_ = host.split(l1l111_l1_ (u"ࠪ࠲ࠬ㚂"))
		else: l1lllll11l1l_l1_ = host.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㚃")).split(l1l111_l1_ (u"ࠬ࠴ࠧ㚄"))
		for part in l1lllll11l1l_l1_:
			parts = part.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㚅"))
			l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠢࡃࠤ㚆"), len(part))
			for l111l1111ll_l1_ in part:
				l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠣࡥࠥ㚇"), l111l1111ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚈")))
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠥࡆࠧ㚉"), 0)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㚊"), 1)
		l1111l11111_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㚋"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l1111l11111_l1_), (l1l1lll1llll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1ll1l1l_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࡉࡊࡋࡌࡍࡎࠢ㚌"), data, 0)
		l111ll1l1ll_l1_ = l11l1ll1l1l_l1_[3]
		offset = len(host)+18
		l11l11l1l11_l1_ = []
		for _ in range(l111ll1l1ll_l1_):
			l111l1lll11_l1_ = offset
			l1lll1lll1l1_l1_ = 1
			l11111lll11_l1_ = False
			while True:
				l111l1111ll_l1_ = unpack_from(l1l111_l1_ (u"ࠢ࠿ࡄࠥ㚍"), data, l111l1lll11_l1_)[0]
				if l111l1111ll_l1_ == 0:
					l111l1lll11_l1_ += 1
					break
				if l111l1111ll_l1_ >= 192:
					l1111lll1ll_l1_ = unpack_from(l1l111_l1_ (u"ࠣࡀࡅࠦ㚎"), data, l111l1lll11_l1_ + 1)[0]
					l111l1lll11_l1_ = ((l111l1111ll_l1_ << 8) + l1111lll1ll_l1_ - 0xc000) - 1
					l11111lll11_l1_ = True
				l111l1lll11_l1_ += 1
				if l11111lll11_l1_ == False: l1lll1lll1l1_l1_ += 1
			if l11111lll11_l1_ == True: l1lll1lll1l1_l1_ += 1
			offset = offset + l1lll1lll1l1_l1_
			l1l11111l1l_l1_ = unpack_from(l1l111_l1_ (u"ࠤࡁࡌࡍࡏࡈࠣ㚏"), data, offset)
			offset = offset + 10
			l11l1lll11l_l1_ = l1l11111l1l_l1_[0]
			l11111llll1_l1_ = l1l11111l1l_l1_[3]
			if l11l1lll11l_l1_ == 1:
				l111l111l1l_l1_ = unpack_from(l1l111_l1_ (u"ࠥࡂࠧ㚐")+l1l111_l1_ (u"ࠦࡇࠨ㚑")*l11111llll1_l1_, data, offset)
				l1ll1lll11ll_l1_ = l1l111_l1_ (u"ࠬ࠭㚒")
				for l111l1111ll_l1_ in l111l111l1l_l1_: l1ll1lll11ll_l1_ += str(l111l1111ll_l1_) + l1l111_l1_ (u"࠭࠮ࠨ㚓")
				l1ll1lll11ll_l1_ = l1ll1lll11ll_l1_[0:-1]
				l11l11l1l11_l1_.append(l1ll1lll11ll_l1_)
			if l11l1lll11l_l1_ in [1,2,5,6,15,28]: offset = offset + l11111llll1_l1_
	except: l11l11l1l11_l1_ = []
	if not l11l11l1l11_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㚔"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࡠࡔࡈࡗࡔࡒࡖࡆࡔࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡎ࡯ࡴࡶ࠽ࠤࡠࠦࠧ㚕")+host+l1l111_l1_ (u"ࠩࠣࡡࠬ㚖"))
	return l11l11l1l11_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1ll11ll_l1_ = [l1l111_l1_ (u"ࠪ็ออัࠨ㚗"),l1l111_l1_ (u"ࠫออไ฻ࠩ㚘"),l1l111_l1_ (u"ࠬࡧࡤࡶ࡮ࡷࠫ㚙"),l1l111_l1_ (u"࠭ࡸࡹࠩ㚚"),l1l111_l1_ (u"ࠧࡴࡧࡻࠫ㚛")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㚜"):
			l11l1ll11ll_l1_ += [l1l111_l1_ (u"ࠩࡵ࠾ࠬ㚝"),l1l111_l1_ (u"ࠪࡶ࠲࠭㚞"),l1l111_l1_ (u"ࠫ࠲ࡳࡡࠨ㚟")]
			l11l1ll11ll_l1_ += [l1l111_l1_ (u"ࠬࡀࡲࠨ㚠"),l1l111_l1_ (u"࠭࠭ࡳࠩ㚡"),l1l111_l1_ (u"ࠧ࡮ࡣ࠰ࠫ㚢")]
		for l1111lll1l_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ㚣") in l1111lll1l_l1_: continue
			if l1l111_l1_ (u"ࠩะ่็ฯࠧ㚤") in l1111lll1l_l1_: continue
			l1111lll1l_l1_ = l1111lll1l_l1_.lower()
			if kodi_version<19: l1111lll1l_l1_ = l1111lll1l_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㚥")).encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㚦"))
			l1111lll1l_l1_ = l1111lll1l_l1_.replace(l1l111_l1_ (u"ࠬࡀࠧ㚧"),l1l111_l1_ (u"࠭ࠧ㚨"))
			l11l111lll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞࠭ࠬࠫ㚩"),l1111lll1l_l1_,re.DOTALL)
			l1lll111llll_l1_ = False
			for digits in l11l111lll1_l1_:
				if len(digits)==2:
					l1lll111llll_l1_ = True
					break
			if l1l111_l1_ (u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫ㚪") in l1111lll1l_l1_: continue
			elif l1l111_l1_ (u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪ㚫") in l1111lll1l_l1_: continue
			elif l1l111_l1_ (u"ࠪ฾๏ืࠠๆื้ๅࠬ㚬") in l1111lll1l_l1_: continue
			elif l1l11llllll_l1_(l1l111_l1_ (u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭㚭")): continue
			elif l1111lll1l_l1_ in [l1l111_l1_ (u"ࠬࡸࠧ㚮")] or l1lll111llll_l1_ or any(value in l1111lll1l_l1_ for value in l11l1ll11ll_l1_):
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㚯"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㚰")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㚱"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㚲"),l1l111_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬ㚳"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1lll111ll1l_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㚴")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠬอำห็ิหึ࠭㚵")
		header = args[2]
		text = l1l111_l1_ (u"࠭࡜࡯ࠩ㚶").join(args[3:])
	else: l1lll111ll1l_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠧࠨ㚷"),l1l111_l1_ (u"ࠨࡑࡎࠫ㚸"),l1l111_l1_ (u"ࠩࠪ㚹"),l1l111_l1_ (u"ࠪࠫ㚺")
	l1l1lll11lll_l1_(l1lll111ll1l_l1_,l1l111_l1_ (u"ࠫࠬ㚻"),l11l111l_l1_,l1l111_l1_ (u"ࠬ࠭㚼"),header,text,**kwargs)
	return
def l1ll1l1111_l1_(*args,**kwargs):
	l1lll111ll1l_l1_ = args[0]
	l1llll11l11l_l1_ = args[1]
	l1lll1ll1ll1_l1_ = args[2]
	if l1lll1ll1ll1_l1_ or l1llll11l11l_l1_: l1llll111ll1_l1_ = True
	else: l1llll111ll1_l1_ = False
	header = args[3]
	text = args[4]
	if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㚽")
	if not l1llll11l11l_l1_: l1llll11l11l_l1_ = l1l111_l1_ (u"ࠧไๆสࠫ㚾")
	if not l1lll1ll1ll1_l1_: l1lll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨ่฼้ࠬ㚿")
	if len(args)>=6: text += l1l111_l1_ (u"ࠩ࡟ࡲࠬ㛀")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"ࠪࡠࡳ࠭㛁")+args[6]
	l11l111111l_l1_ = l1l1lll11lll_l1_(l1lll111ll1l_l1_,l1llll11l11l_l1_,l1l111_l1_ (u"ࠫࠬ㛂"),l1lll1ll1ll1_l1_,header,text,**kwargs)
	if l11l111111l_l1_==-1 and l1llll111ll1_l1_: l11l111111l_l1_ = -1
	elif l11l111111l_l1_==-1 and not l1llll111ll1_l1_: l11l111111l_l1_ = False
	elif l11l111111l_l1_==0: l11l111111l_l1_ = False
	elif l11l111111l_l1_==2: l11l111111l_l1_ = True
	return l11l111111l_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ㛃") in list(kwargs.keys()): l1l1111llll_l1_ = kwargs[l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ㛄")]
	else: l1l1111llll_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ㛅") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ㛆")
	l1ll1111ll1l_l1_ = l1l1ll11l1l_l1_(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࡉ࡮ࡣࡪࡩ࠳ࡾ࡭࡭ࠩ㛇"),l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㛈"),l1l111_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㛉"))
	l1lll11l11ll_l1_,l11l11111ll_l1_ = l1lllllllll1_l1_(l1l111_l1_ (u"ࠬ࠭㛊"),l1l111_l1_ (u"࠭ࠧ㛋"),l1l111_l1_ (u"ࠧࠨ㛌"),header,text,profile,l1l111_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㛍"),720,False)
	l1ll1111ll1l_l1_.show()
	if profile==l1l111_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ㛎"):
		l1ll1111ll1l_l1_.getControl(9040).setHeight(215)
		l1ll1111ll1l_l1_.getControl(9040).setPosition(55,-80)
		l1ll1111ll1l_l1_.getControl(9050).setPosition(120,-60)
		l1ll1111ll1l_l1_.getControl(400).setPosition(90,-35)
	l1ll1111ll1l_l1_.getControl(401).setVisible(False)
	l1ll1111ll1l_l1_.getControl(402).setVisible(False)
	l1ll1111ll1l_l1_.getControl(9050).setImage(l1lll11l11ll_l1_)
	l1ll1111ll1l_l1_.getControl(9050).setHeight(l11l11111ll_l1_)
	from threading import Thread
	l1l11111ll1_l1_ = Thread(target=l1l1ll1l1l1l_l1_,args=(l1ll1111ll1l_l1_,l1lll11l11ll_l1_,l1l1111llll_l1_))
	l1l11111ll1_l1_.start()
	return
def l1l1ll1l1l1l_l1_(l1ll1111ll1l_l1_,l1lll11l11ll_l1_,l1l1111llll_l1_):
	time.sleep(l1l1111llll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll11l11ll_l1_):
		try: os.remove(l1lll11l11ll_l1_)
		except: pass
	return
def l1ll11l11l11_l1_(*args,**kwargs):
	header,text,profile,l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ㛏"),l1l111_l1_ (u"ࠫࠬ㛐"),l1l111_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㛑"),l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㛒")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1lll111ll1l_l1_ = args[3]
	return l1l11ll111_l1_(l1lll111ll1l_l1_,header,text,profile)
def l11ll11l1ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1ll1l1ll1l1_l1_(*args,**kwargs)
def l1l11111l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1ll1llll111_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l11l1111_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll1ll1l1_l1_(l1lll1ll111l_l1_):
	if kodi_version>17.99: l1ll1111ll1l_l1_ = l1l111_l1_ (u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬ㛓")
	else: l1ll1111ll1l_l1_ = l1l111_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬ㛔")
	l1lll1ll111l_l1_ = l1lll1ll111l_l1_.lower()
	if l1lll1ll111l_l1_==l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ㛕"): xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬ㛖")+l1ll1111ll1l_l1_+l1l111_l1_ (u"ࠫ࠮࠭㛗"))
	elif l1lll1ll111l_l1_==l1l111_l1_ (u"ࠬࡹࡴࡰࡲࠪ㛘"): xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭࠭㛙")+l1ll1111ll1l_l1_+l1l111_l1_ (u"ࠧࠪࠩ㛚"))
	return
def l1l1lll11lll_l1_(l1lll111ll1l_l1_,l111l1l11l1_l1_=l1l111_l1_ (u"ࠨࠩ㛛"),l1ll11ll1l11_l1_=l1l111_l1_ (u"ࠩࠪ㛜"),l111l1l1lll_l1_=l1l111_l1_ (u"ࠪࠫ㛝"),header=l1l111_l1_ (u"ࠫࠬ㛞"),text=l1l111_l1_ (u"ࠬ࠭㛟"),profile=l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㛠"),l1llll111l11_l1_=0,l1ll1ll1l1l1_l1_=0):
	if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㛡")
	l1ll1111ll1l_l1_ = l1ll1l1111l1_l1_(l1l111_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㛢"),l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㛣"),l1l111_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㛤"))
	l1ll1111ll1l_l1_.l11l11111l1_l1_(l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text,profile,l1lll111ll1l_l1_,900,l1llll111l11_l1_,l1ll1ll1l1l1_l1_)
	if l1llll111l11_l1_>0: l1ll1111ll1l_l1_.l1l1111111l_l1_()
	if l1ll1ll1l1l1_l1_>0: l1ll1111ll1l_l1_.l11lll1l1l1_l1_()
	if l1llll111l11_l1_==0 and l1ll1ll1l1l1_l1_==0: l1ll1111ll1l_l1_.l11l11l1ll1_l1_()
	l1ll1111ll1l_l1_.doModal()
	l11l111111l_l1_ = l1ll1111ll1l_l1_.l1l11111l11_l1_
	return l11l111111l_l1_
def l1l11ll111_l1_(l1lll111ll1l_l1_,header,text,profile=l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㛥")):
	if not l1lll111ll1l_l1_: l1lll111ll1l_l1_ = l1l111_l1_ (u"ࠬࡲࡥࡧࡶࠪ㛦")
	l1ll1111ll1l_l1_ = l1l1ll11l1l_l1_(l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࡚ࡥࡹࡶ࡙࡭ࡪࡽࡥࡳࡈࡸࡰࡱ࡙ࡣࡳࡧࡨࡲ࠳ࡾ࡭࡭ࠩ㛧"),l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ㛨"),l1l111_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭㛩"))
	l1lll11l11ll_l1_,l11l11111ll_l1_ = l1lllllllll1_l1_(l1l111_l1_ (u"ࠩࠪ㛪"),l1l111_l1_ (u"ࠪࠫ㛫"),l1l111_l1_ (u"ࠫࠬ㛬"),header,text,profile,l1lll111ll1l_l1_,1270,False)
	l1ll1111ll1l_l1_.show()
	l1ll1111ll1l_l1_.getControl(9050).setHeight(l11l11111ll_l1_)
	l1ll1111ll1l_l1_.getControl(9050).setImage(l1lll11l11ll_l1_)
	result = l1ll1111ll1l_l1_.doModal()
	try: os.remove(l1lll11l11ll_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1ll1l1llll1_l1_=True):
	if l1ll1l1llll1_l1_:
		l11ll1l1l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㛭"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㛮"),l1l111_l1_ (u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ㛯"))
		if l11ll1l1l1_l1_: return l11ll1l1l1_l1_
	text = l1l111_l1_ (u"ࠨࠩ㛰")
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡪࡩࡨࡣ࡮ࡲ࡫࠳ࡽࡩ࡭࡮ࡶ࡬ࡴࡻࡳࡦ࠰ࡦࡳࡲ࠵࠲࠱࠳࠵࠳࠵࠷࠯࠱࠵࠲ࡱࡴࡹࡴ࠮ࡥࡲࡱࡲࡵ࡮࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࡸ࠵ࠧ㛱")
	headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㛲"):url}
	response = l11l1l_l1_(l1lll11ll11_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㛳"),url,l1l111_l1_ (u"ࠬ࠭㛴"),headers,l1l111_l1_ (u"࠭ࠧ㛵"),l1l111_l1_ (u"ࠧࠨ㛶"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ㛷"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪ㛸"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㛹"),html,re.DOTALL)
			text = text[0]
	if not text:
		l1lllll11l11_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㛺"),l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭㛻"))
		text = open(l1lllll11l11_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㛼")).read()
		if kodi_version>18.99: text = text.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㛽"))
		text = text.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㛾"),l1l111_l1_ (u"ࠩࠪ㛿"))
	l1llllll1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫ㜀"),text,re.DOTALL)
	l11ll1l1lll_l1_ = []
	for line in l1llllll1lll_l1_:
		l1lll1l1lll1_l1_ = line.lower()
		if l1l111_l1_ (u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬ㜁") in l1lll1l1lll1_l1_: continue
		if l1l111_l1_ (u"ࠬࡻࡢࡶࡰࡷࡹࠬ㜂") in l1lll1l1lll1_l1_: continue
		if l1l111_l1_ (u"࠭ࡩࡱࡪࡲࡲࡪ࠭㜃") in l1lll1l1lll1_l1_: continue
		if l1l111_l1_ (u"ࠧࡤࡴࡲࡷࠬ㜄") in l1lll1l1lll1_l1_: continue
		l11ll1l1lll_l1_.append(line)
	l11ll1l1l1_l1_ = random.sample(l11ll1l1lll_l1_,1)
	l11ll1l1l1_l1_ = l11ll1l1l1_l1_[0]
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㜅"),l1l111_l1_ (u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ㜆"),l11ll1l1l1_l1_,l11l1l1_l1_)
	return l11ll1l1l1_l1_
def l11l1l1111l_l1_(l1111llll11_l1_):
	sys.stderr.write(l1111llll11_l1_)
	lines = l1111llll11_l1_.splitlines()
	error = lines[-1]
	l111l1lll1l_l1_ = open(l1llll1llll1_l1_,l1l111_l1_ (u"ࠪࡶࡧ࠭㜇")).read()
	if kodi_version>18.99: l111l1lll1l_l1_ = l111l1lll1l_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㜈"))
	l111l1lll1l_l1_ = l111l1lll1l_l1_[-8000:]
	sep = l1l111_l1_ (u"ࠬࡃࠧ㜉")*100
	if sep in l111l1lll1l_l1_: l111l1lll1l_l1_ = l111l1lll1l_l1_.rsplit(sep,1)[1]
	if error in l111l1lll1l_l1_: l111l1lll1l_l1_ = l111l1lll1l_l1_.rsplit(error,1)[0]
	l1ll1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬ㜊"),l111l1lll1l_l1_,re.DOTALL)
	for typ,source in reversed(l1ll1l11l1l1_l1_):
		if source: break
	else: source = l1l111_l1_ (u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧ㜋")
	file,line,func = l1l111_l1_ (u"ࠨࠩ㜌"),l1l111_l1_ (u"ࠩࠪ㜍"),l1l111_l1_ (u"ࠪࠫ㜎")
	l11ll11lll1_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุล࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㜏")+error
	l1ll1l1ll1ll_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆืาี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㜐")+source
	for l1llll111lll_l1_ in reversed(lines):
		if l1l111_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭㜑") in l1llll111lll_l1_ and l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㜒") in l1llll111lll_l1_: break
	l1llll111lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫ㜓"),l1llll111lll_l1_,re.DOTALL)
	if l1llll111lll_l1_:
		file,line,func = l1llll111lll_l1_[0]
		if l1l111_l1_ (u"ࠩ࠲ࠫ㜔") in file: file = file.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㜕"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠫࡡࡢࠧ㜖"),1)[1]
		l1ll11111ll1_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๆไ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㜗")+file
		line2 = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีฺี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㜘")+line
		l1l111111l1_l1_ = l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่็ฬ์࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㜙")+func
		l111ll1111l_l1_ = l1ll11111ll1_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㜚")+line2+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㜛")+l1l111111l1_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㜜")+l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㜝")+l11ll11lll1_l1_
		l1lll11lllll_l1_ = line2+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜞")+l1ll1l1ll1ll_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ㜟")+l11ll11lll1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㜠")+l1ll11111ll1_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㜡")+l1l111111l1_l1_
		l11111111l1_l1_ = line2+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㜢")+l11ll11lll1_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㜣")+l1ll11111ll1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㜤")+l1l111111l1_l1_
	else:
		l1ll11111ll1_l1_,line2,l1l111111l1_l1_ = l1l111_l1_ (u"ࠬ࠭㜥"),l1l111_l1_ (u"࠭ࠧ㜦"),l1l111_l1_ (u"ࠧࠨ㜧")
		l111ll1111l_l1_ = l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㜨")+l11ll11lll1_l1_
		l1lll11lllll_l1_ = l1ll1l1ll1ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㜩")+l11ll11lll1_l1_
		l11111111l1_l1_ = l11ll11lll1_l1_
	l11l11lll1l_l1_ = l1l111_l1_ (u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧ㜪")+l1l111_l1_ (u"ࠫࡡࡴࠧ㜫")
	l1ll1111l1ll_l1_ = l111llll111_l1_()
	l1llll1ll1l1_l1_ = []
	l1lll_l1_ = l1ll1111l1ll_l1_[l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㜬")]
	l1llll111l1l_l1_ = l1l1ll1ll1l1_l1_(l1l11l1llll_l1_)
	if l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㜭") in list(l1ll1111l1ll_l1_.keys()):
		for l1ll1l1lll11_l1_,l1111ll11ll_l1_,l11ll1l1111_l1_ in l1lll_l1_: l1llll1ll1l1_l1_ = max(l1llll1ll1l1_l1_,l1111ll11ll_l1_)
		if l1llll111l1l_l1_<l1llll1ll1l1_l1_:
			header = l1l111_l1_ (u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪ㜮")
			l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㜯"),l1l111_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㜰"),l1l111_l1_ (u"ࠪฮาี๊ฬࠩ㜱"),l1l111_l1_ (u"ࠫำื่อࠩ㜲"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
			if l11l111111l_l1_==0:
				l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㜳"),l1l111_l1_ (u"࠭ฮา๊ฯࠫ㜴"),l1l111_l1_ (u"ࠧหฯา๎ะ࠭㜵"),l1l111_l1_ (u"ࠨࠩ㜶"),header)
				if l1llll1l11_l1_==1: l11l111111l_l1_ = 1
			if l11l111111l_l1_==1:
				from l1l1l11l1ll_l1_ import l1lll1ll1l1l_l1_
				l1lll1ll1l1l_l1_()
			return
	l1l1ll1l1l11_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㜷"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㜸"),l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㜹"))
	if not l1l1ll1l1l11_l1_: l1l1ll1l1l11_l1_ = []
	l1lll11lllll_l1_ = l1lll11lllll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜺"),l1l111_l1_ (u"࠭࡜࡝ࡰࠪ㜻")).replace(l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㜼"),l1l111_l1_ (u"ࠨࠩ㜽")).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㜾"),l1l111_l1_ (u"ࠪࠫ㜿")).replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㝀"),l1l111_l1_ (u"ࠬ࠭㝁"))
	l11111111l1_l1_ = l11111111l1_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㝂"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㝃")).replace(l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㝄"),l1l111_l1_ (u"ࠩࠪ㝅")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㝆"),l1l111_l1_ (u"ࠫࠬ㝇")).replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㝈"),l1l111_l1_ (u"࠭ࠧ㝉"))
	l1l1lll11l11_l1_ = l1l11l1llll_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ㝊")+l11111111l1_l1_
	if l1l1lll11l11_l1_ in l1l1ll1l1l11_l1_:
		header = l1l111_l1_ (u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭㝋")
		l1111l1_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㝌"),l1l111_l1_ (u"ࠪࠫ㝍"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
		return
	l1l1lll1lll1_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠫ࠳࠭㝎"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㝏")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㝐"),url,l1l111_l1_ (u"ࠧࠨ㝑"),l1l111_l1_ (u"ࠨࠩ㝒"),l1l111_l1_ (u"ࠩࠪ㝓"),l1l111_l1_ (u"ࠪࠫ㝔"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕ࠰࠵ࡸࡺࠧ㝕"),False,False)
	html = response.content
	l11lll1l11l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ㝖"),html,re.DOTALL)
	for l11l11ll11l_l1_,l11ll11ll1l_l1_,l111111l11l_l1_,l1lll11llll1_l1_ in l11lll1l11l_l1_:
		l11l11ll11l_l1_ = l11l11ll11l_l1_.split(l1l111_l1_ (u"࠭ࠫࠨ㝗"))
		l111111l11l_l1_ = l111111l11l_l1_.split(l1l111_l1_ (u"ࠧࠬࠩ㝘"))
		l1lll11llll1_l1_ = l1lll11llll1_l1_.split(l1l111_l1_ (u"ࠨ࠭ࠪ㝙"))
		if line in l11l11ll11l_l1_ and error==l11ll11ll1l_l1_ and l1l11l1llll_l1_ in l111111l11l_l1_ and l1l1lll1lll1_l1_ in l1lll11llll1_l1_:
			header = l1l111_l1_ (u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧ㝚")
			l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㝛"),l1l111_l1_ (u"ࠫำื่อࠩ㝜"),l1l111_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㝝"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
			if l1llll1l11_l1_==1: l1111l1_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㝞"),l1l111_l1_ (u"ࠧࠨ㝟"),l1l111_l1_ (u"ࠨࠩ㝠"),header)
			return
	header = l1l111_l1_ (u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ㝡")
	l1111l1_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㝢"),l1l111_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㝣"),l11l11lll1l_l1_+header,l111ll1111l_l1_)
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㝤"),l1l111_l1_ (u"࠭ใๅษࠪ㝥"),l1l111_l1_ (u"ࠧ็฻่ࠫ㝦"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㝧"),l1l111_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪ㝨"))
	if l1llll1l11_l1_==1: l1l1lll1l111_l1_ = l1l111_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭㝩")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㝪"),l1l111_l1_ (u"ࠬ࠭㝫"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㝬"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬ㝭"))
		return
	message = l1lll11lllll_l1_
	from l1l1l11l1ll_l1_ import l11l1l11lll_l1_
	succeeded = l11l1l11lll_l1_(l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸࡳࠨ㝮"),message,True,l1l111_l1_ (u"ࠩࠪ㝯"),l1l111_l1_ (u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗࠬ㝰"),l1l1lll1l111_l1_)
	if succeeded and l1l1lll1l111_l1_:
		l1l1ll1l1l11_l1_.append(l1l1lll11l11_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㝱"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㝲"),l1l1ll1l1l11_l1_,l1ll111l1l1_l1_)
	return
def l1ll1l1lllll_l1_(data):
	if kodi_version>18.99: data = data.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㝳"))
	filename = l1l111_l1_ (u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧ㝴")+str(time.time())+l1l111_l1_ (u"ࠨ࠰ࡧࡥࡹ࠭㝵")
	open(filename,l1l111_l1_ (u"ࠩࡺࡦࠬ㝶")).write(data)
	return
def l11llll1lll_l1_(l1l1lll11ll_l1_):
	if l1l1lll11ll_l1_:
		l1ll1l11l111_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㝷"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㝸"),l1l111_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㝹"))
		if l1ll1l11l111_l1_: return l1ll1l11l111_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㝺")][5]
	user = l1l1ll1l11l_l1_(32)
	l1111ll1l11_l1_ = l11l1111lll_l1_()
	l1lll1l1l1ll_l1_ = l1111ll1l11_l1_.split(l1l111_l1_ (u"ࠧ࠭ࠩ㝻"))[2]
	l1lll1111l1l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㝼"))
	l1llllll1l11_l1_ = l1l1llllllll_l1_()
	payload = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㝽"):user,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ㝾"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㝿"):l1lll1l1l1ll_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㞀"):l1lll1111111_l1_(l1llllll1l11_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㞁"),url,payload,l1l111_l1_ (u"ࠧࠨ㞂"),l1l111_l1_ (u"ࠨࠩ㞃"),l1l111_l1_ (u"ࠩࠪ㞄"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨ㞅"))
	if not response.succeeded: return []
	html = response.content
	l1ll1l11l111_l1_ = html.replace(l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㞆"),l1l111_l1_ (u"ࠬࡢ࡮ࠨ㞇")).replace(l1l111_l1_ (u"࠭࡜࡝ࡰࠪ㞈"),l1l111_l1_ (u"ࠧ࡝ࡰࠪ㞉")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㞊"),l1l111_l1_ (u"ࠩ࡟ࡲࠬ㞋")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㞌"),l1l111_l1_ (u"ࠫࡡࡴࠧ㞍"))
	l1ll1l11l111_l1_ = re.findall(l1l111_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨ㞎"),l1ll1l11l111_l1_,re.DOTALL)
	if not l1ll1l11l111_l1_: return []
	l1ll1l11l111_l1_ = sorted(l1ll1l11l111_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1ll1ll111_l1_,l1l1llllll1l_l1_,l11l11l1l11_l1_,l11l111ll1l_l1_,reason = l1ll1l11l111_l1_[0]
	l1lll1l111l1_l1_ = reason if l1l11llllll_l1_(l1l111_l1_ (u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬ㞏")) else l1l1llllll1l_l1_
	settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥࠩ㞐"),l1lll1l111l1_l1_)
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㞑"),l1l111_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㞒"),l1ll1l11l111_l1_,l11l1l1_l1_)
	return l1ll1l11l111_l1_
def SPLIT_BIGLIST(items,l1l1lll111l1_l1_=0,l1lllll1l1l1_l1_=0):
	if l1l1lll111l1_l1_ and not l1lllll1l1l1_l1_: l1lllll1l1l1_l1_ = len(items)//l1l1lll111l1_l1_
	l1lll11111l1_l1_,l1l11l111l_l1_,l1lll1l1llll_l1_ = [],-1,0
	for item in items:
		if l1lll1l1llll_l1_%l1lllll1l1l1_l1_==0:
			l1l11l111l_l1_ += 1
			l1lll11111l1_l1_.append([])
		l1lll11111l1_l1_[l1l11l111l_l1_].append(item)
		l1lll1l1llll_l1_ += 1
	return l1lll11111l1_l1_
def l111lll111l_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࡠࠩ㞓") not in filename or l1l111_l1_ (u"ࠫࡒ࠹ࡕࡠࠩ㞔") not in filename: text = str(data)
	else:
		l1lll11111l1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"ࠬ࠭㞕")
		for split in l1lll11111l1_l1_:
			text += str(split)+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㞖")
		text = text.strip(l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㞗"))
	l1l1l1ll1l1_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠨࡹࡥࠫ㞘")).write(l1l1l1ll1l1_l1_)
	return
def l11ll1l1ll1_l1_(l1l1ll11111_l1_,filename):
	if l1l1ll11111_l1_==l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㞙"): data = {}
	elif l1l1ll11111_l1_==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㞚"): data = []
	elif l1l1ll11111_l1_==l1l111_l1_ (u"ࠫࡸࡺࡲࠨ㞛"): data = l1l111_l1_ (u"ࠬ࠭㞜")
	elif l1l1ll11111_l1_==l1l111_l1_ (u"࠭ࡩ࡯ࡶࠪ㞝"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l1ll1l1_l1_ = open(filepath,l1l111_l1_ (u"ࠧࡳࡤࠪ㞞")).read()
	text = zlib.decompress(l1l1l1ll1l1_l1_)
	if l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㞟") not in text: data = eval(text)
	else:
		l1lll11111l1_l1_ = text.split(l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㞠"))
		del text
		data = []
		l11l1l1lll1_l1_ = l11l11ll111_l1_()
		id = 0
		for split in l1lll11111l1_l1_:
			l11l1l1lll1_l1_.l11l111ll11_l1_(str(id),eval,split)
			id += 1
		del l1lll11111l1_l1_
		l11l1l1lll1_l1_.l1ll1lll1ll1_l1_()
		l11l1l1lll1_l1_.l1l1lll1111l_l1_()
		l1l1llllll11_l1_ = list(l11l1l1lll1_l1_.l1lllll1ll11_l1_.keys())
		l1ll11l11ll1_l1_ = sorted(l1l1llllll11_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll11l11ll1_l1_:
			data += l11l1l1lll1_l1_.l1lllll1ll11_l1_[id]
	return data
def l1ll1l11111l_l1_(addon_id):
	l1ll11llllll_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㞡"),addon_id,l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ㞢"))
	try: l1111ll111l_l1_ = open(l1ll11llllll_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㞣")).read()
	except:
		l1lll1l1ll11_l1_ = os.path.join(l11111ll11l_l1_,l1l111_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㞤"),addon_id,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ㞥"))
		try: l1111ll111l_l1_ = open(l1lll1l1ll11_l1_,l1l111_l1_ (u"ࠨࡴࡥࠫ㞦")).read()
		except: return l1l111_l1_ (u"ࠩࠪ㞧"),[]
	if kodi_version>18.99: l1111ll111l_l1_ = l1111ll111l_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㞨"))
	version = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨ㞩"),l1111ll111l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"ࠬ࠭㞪"),[]
	l1l1111l1ll_l1_,l11l111l1l1_l1_ = version[0],l1l1ll1ll1l1_l1_(version[0])
	return l1l1111l1ll_l1_,l11l111l1l1_l1_
def l111llll111_l1_():
	l111l11llll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㞫"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㞬"),l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ㞭"))
	if l111l11llll_l1_: return l111l11llll_l1_
	l1ll1111l1ll_l1_,l111l11llll_l1_ = {},{}
	l1ll1l11l1l1_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㞮")][0]]
	if kodi_version>17.99: l1ll1l11l1l1_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㞯")][1])
	if kodi_version>18.99: l1ll1l11l1l1_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㞰")][2])
	for l1ll11ll111l_l1_ in l1ll1l11l1l1_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㞱"),l1ll11ll111l_l1_,l1l111_l1_ (u"࠭ࠧ㞲"),l1l111_l1_ (u"ࠧࠨ㞳"),l1l111_l1_ (u"ࠨࠩ㞴"),l1l111_l1_ (u"ࠩࠪ㞵"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ㞶"))
		if response.succeeded:
			html = response.content
			l1l1lll1ll11_l1_ = l1ll11ll111l_l1_.rsplit(l1l111_l1_ (u"ࠫ࠴࠭㞷"),1)[0]
			l111l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㞸"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111ll1llll_l1_ in l111l1l111l_l1_:
				l11l111l1ll_l1_ = l1l1lll1ll11_l1_+l1l111_l1_ (u"࠭࠯ࠨ㞹")+addon_id+l1l111_l1_ (u"ࠧ࠰ࠩ㞺")+addon_id+l1l111_l1_ (u"ࠨ࠯ࠪ㞻")+l111ll1llll_l1_+l1l111_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ㞼")
				if addon_id not in list(l1ll1111l1ll_l1_.keys()):
					l1ll1111l1ll_l1_[addon_id] = []
					l111l11llll_l1_[addon_id] = []
				l1lll1ll1lll_l1_ = l1l1ll1ll1l1_l1_(l111ll1llll_l1_)
				l1ll1111l1ll_l1_[addon_id].append((l111ll1llll_l1_,l1lll1ll1lll_l1_,l11l111l1ll_l1_))
	for addon_id in list(l1ll1111l1ll_l1_.keys()):
		l111l11llll_l1_[addon_id] = sorted(l1ll1111l1ll_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㞽"),l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ㞾"),l111l11llll_l1_,l11l1l1_l1_)
	return l111l11llll_l1_
def l1l1ll1ll1l1_l1_(l111ll1llll_l1_):
	l1lll1ll1lll_l1_ = []
	l1llll11lll_l1_ = l111ll1llll_l1_.split(l1l111_l1_ (u"ࠬ࠴ࠧ㞿"))
	for l1l1ll1l1l_l1_ in l1llll11lll_l1_:
		parts = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪ㟀"),l1l1ll1l1l_l1_,re.DOTALL)
		l1l1lllllll1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l1lllllll1_l1_.append(part)
		l1lll1ll1lll_l1_.append(l1l1lllllll1_l1_)
	return l1lll1ll1lll_l1_
def l1lll11l1ll1_l1_(l1lll1ll1lll_l1_):
	l111ll1llll_l1_ = l1l111_l1_ (u"ࠧࠨ㟁")
	for l1l1ll1l1l_l1_ in l1lll1ll1lll_l1_:
		for part in l1l1ll1l1l_l1_: l111ll1llll_l1_ += str(part)
		l111ll1llll_l1_ += l1l111_l1_ (u"ࠨ࠰ࠪ㟂")
	l111ll1llll_l1_ = l111ll1llll_l1_.strip(l1l111_l1_ (u"ࠩ࠱ࠫ㟃"))
	return l111ll1llll_l1_
def l1lllllll1ll_l1_(l11ll1l1l11_l1_):
	l1l1lll1ll1l_l1_ = {}
	l1ll1111l1ll_l1_ = l111llll111_l1_()
	l11lll1ll1l_l1_ = l1ll1lll1l1l_l1_(l11ll1l1l11_l1_)
	for addon_id in l11ll1l1l11_l1_:
		if addon_id not in list(l1ll1111l1ll_l1_.keys()): continue
		l111l11llll_l1_ = l1ll1111l1ll_l1_[addon_id]
		l11lll11l1l_l1_,l11lll111ll_l1_,l1l1ll1l1111_l1_ = l111l11llll_l1_[0]
		l1111lllll1_l1_,l1111l11l11_l1_ = l1ll1l11111l_l1_(addon_id)
		l11l1llllll_l1_,l1lllll1l111_l1_ = l11lll1ll1l_l1_[addon_id]
		l11lllll111_l1_ = l11lll111ll_l1_>l1111l11l11_l1_ and l11l1llllll_l1_
		l1l1ll1l11l1_l1_ = True
		if not l11l1llllll_l1_: l1l1111ll1l_l1_ = l1l111_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ㟄")
		elif not l1lllll1l111_l1_: l1l1111ll1l_l1_ = l1l111_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭㟅")
		elif l11lllll111_l1_: l1l1111ll1l_l1_ = l1l111_l1_ (u"ࠬࡵ࡬ࡥࠩ㟆")
		else:
			l1l1111ll1l_l1_ = l1l111_l1_ (u"࠭ࡧࡰࡱࡧࠫ㟇")
			l1l1ll1l11l1_l1_ = False
		l1l1lll1ll1l_l1_[addon_id] = (l1l1ll1l11l1_l1_,l1111lllll1_l1_,l1111l11l11_l1_,l11lll11l1l_l1_,l11lll111ll_l1_,l1l1111ll1l_l1_,l1l1ll1l1111_l1_)
	return l1l1lll1ll1l_l1_
def l1l1111l11_l1_(l1l111l111_l1_,l1111l1l1l1_l1_,l11l11l1lll_l1_=l1l111_l1_ (u"ࠧࠨ㟈"),line2=l1l111_l1_ (u"ࠨࠩ㟉"),l11l11ll11l_l1_=l1l111_l1_ (u"ࠩࠪ㟊")):
	if kodi_version<19: l1l111l111_l1_.update(l1111l1l1l1_l1_,l11l11l1lll_l1_,line2,l11l11ll11l_l1_)
	else: l1l111l111_l1_.update(l1111l1l1l1_l1_,l11l11l1lll_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㟋")+line2+l1l111_l1_ (u"ࠫࡡࡴࠧ㟌")+l11l11ll11l_l1_)
	return
def l1ll1llll11l_l1_(l1111111l1l_l1_):
	def l1llllll11ll_l1_(num,b,l1ll1ll11111_l1_=l1l111_l1_ (u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧ㟍")):
		return ((num == 0) and l1ll1ll11111_l1_[0]) or (l1llllll11ll_l1_(num // b, b, l1ll1ll11111_l1_).lstrip(l1ll1ll11111_l1_[0]) + l1ll1ll11111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠨ࡜࡝ࡤࠥ㟎") + l1llllll11ll_l1_(c, a) + l1l111_l1_ (u"ࠢ࡝࡞ࡥࠦ㟏"),  k[c], p)
		return p
	l1111111l1l_l1_ = l1111111l1l_l1_.split(l1l111_l1_ (u"ࠨࡿࠫࠫ㟐"))[1][:-1]
	l1ll1l1ll111_l1_ = eval(l1l111_l1_ (u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ㟑")+l1111111l1l_l1_,{l1l111_l1_ (u"ࠪࡦࡦࡹࡥࡏࠩ㟒"):l1llllll11ll_l1_,l1l111_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠫ㟓"):unpack})
	return l1ll1l1ll111_l1_
def l111lll11ll_l1_(url,l1lll1111l11_l1_=l1l111_l1_ (u"ࠬ࠭㟔")):
	if l1lll1111l11_l1_==l1l111_l1_ (u"࠭࡬ࡰࡹࡨࡶࠬ㟕"): url = re.sub(l1l111_l1_ (u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧ㟖"),lambda l1l11111111_l1_: l1l11111111_l1_.group(0).lower(),url)
	elif l1lll1111l11_l1_==l1l111_l1_ (u"ࠨࡷࡳࡴࡪࡸࠧ㟗"): url = re.sub(l1l111_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩ㟘"),lambda l1l11111111_l1_: l1l11111111_l1_.group(0).upper(),url)
	return url
def l1ll1lll1l1l_l1_(l11ll1l1l11_l1_):
	l111lllll11_l1_,l11111ll1ll_l1_ = False,False
	conn = sqlite3.connect(l111l1ll1l1_l1_)
	conn.text_factory = str
	l1lllll1l1_l1_ = conn.cursor()
	if len(l11ll1l1l11_l1_)==1: l111lll1lll_l1_ = l1l111_l1_ (u"ࠪࠬࠧ࠭㟙")+l11ll1l1l11_l1_[0]+l1l111_l1_ (u"ࠫࠧ࠯ࠧ㟚")
	else: l111lll1lll_l1_ = str(tuple(l11ll1l1l11_l1_))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬ㟛")+l111lll1lll_l1_+l1l111_l1_ (u"࠭ࠠ࠼ࠩ㟜"))
	l1l1l11l11l_l1_ = l1lllll1l1_l1_.fetchall()
	l11lll1ll1l_l1_ = {}
	for addon_id in l11ll1l1l11_l1_: l11lll1ll1l_l1_[addon_id] = (False,False)
	for addon_id,l11111ll1ll_l1_ in l1l1l11l11l_l1_:
		l111lllll11_l1_ = True
		l11111ll1ll_l1_ = l11111ll1ll_l1_==1
		l11lll1ll1l_l1_[addon_id] = (l111lllll11_l1_,l11111ll1ll_l1_)
	conn.close()
	return l11lll1ll1l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"ࠧࠨ㟝")
	if file==l1l1ll1ll1ll_l1_: status = l11111ll1l1_l1_(True,False)
	if os.path.exists(file):
		l1l11lllll1_l1_ = open(file,l1l111_l1_ (u"ࠨࡴࡥࠫ㟞")).read()
		if kodi_version>18.99: l1l11lllll1_l1_ = l1l11lllll1_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㟟"))
		if file==l1l1ll1ll1ll_l1_: l1lll_l1_ = l1l11lllll1_l1_
		else:
			l111l1111l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㟠"),l1l11lllll1_l1_)
			if l111l1111l1_l1_:
				l1lll_l1_ = {}
				for key in l111l1111l1_l1_.keys():
					l1lll_l1_[key] = []
					for l1llllllll11_l1_ in l111l1111l1_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = l1l111_l1_ (u"ࠫࠬ㟡"),l1l111_l1_ (u"ࠬ࠭㟢"),l1l111_l1_ (u"࠭ࠧ㟣"),l1l111_l1_ (u"ࠧࠨ㟤"),l1l111_l1_ (u"ࠨࠩ㟥"),l1l111_l1_ (u"ࠩࠪ㟦"),l1l111_l1_ (u"ࠪࠫ㟧"),l1l111_l1_ (u"ࠫࠬ㟨"),l1l111_l1_ (u"ࠬ࠭㟩")
						type = l1llllllll11_l1_[0]
						name = l1llllllll11_l1_[1]
						name = l11lll1llll_l1_(name)
						url = l1llllllll11_l1_[2]
						mode = l1llllllll11_l1_[3]
						l11l_l1_ = l1llllllll11_l1_[4]
						l1llllll1_l1_ = l1llllllll11_l1_[5]
						if len(l1llllllll11_l1_)>6: text = l1llllllll11_l1_[6]
						if len(l1llllllll11_l1_)>7: context = l1llllllll11_l1_[7]
						if len(l1llllllll11_l1_)>8: l1llllll11l_l1_ = l1llllllll11_l1_[8]
						if file==favoritesfile: l1l1llll1ll1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"࠭ࠧ㟪"),l1llllll11l_l1_
						else: l1l1llll1ll1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_
						l1lll_l1_[key].append(l1l1llll1ll1_l1_)
			l1l11ll1111_l1_ = str(l1lll_l1_)
			if kodi_version>18.99: l1l11ll1111_l1_ = l1l11ll1111_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㟫"))
			open(file,l1l111_l1_ (u"ࠨࡹࡥࠫ㟬")).write(l1l11ll1111_l1_)
	return l1lll_l1_
def l1ll1llll1l_l1_(l1lll11l1ll_l1_):
	l1lll1l1l11l_l1_ = l1lll11l1ll_l1_.split(l1l111_l1_ (u"ࠩ࠰ࠫ㟭"),1)[0]
	l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1l111_l1_ (u"ࠪࠫ㟮"),l1l111_l1_ (u"ࠫࠬ㟯"),l1l111_l1_ (u"ࠬ࠭㟰")
	if   l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㟱")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㟲")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ㟳")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㟴")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ㟵")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭㟶")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ㟷")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㟸")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ㟹"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㟺")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㟻")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㟼")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㟽")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㟾")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㟿")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㠀"):	from l1111l11l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㠁"):		from l1111llll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫ㠂")	:	from l1111l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㠃")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㠄")	:	from l111111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㠅")	:	from l1111111l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ㠆"):	from l1l1l11l1l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㠇")	:	from l11ll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ㠈")	:	from l11l11l1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㠉")	:	from l111llll11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㠊")	:	from l111ll1l11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭㠋")	:	from l111ll11l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㠌")	:	from l111l1ll1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㠍")	:	from l111l111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ㠎")	:	from l111l111l1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㠏")	:	from l1lllll11l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㠐")	:	from l1llll1lll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㠑")	:	from l1llll1l1l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㠒")	:	from l1llll11l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㠓")		:	from l1llll111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㠔")	:	from l1ll1lll111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭㠕")		:	from l1ll1ll1lll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㠖")		:	from IPTV			import MENUu as l1lll1111l1_l1_,SEARCHh as l1lll11l1l1_l1_,menu_namee as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㠗")	:	from l1ll11lllll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ㠘")	:	from l1ll11llll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭㠙")	:	from l1ll11ll1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ㠚")	:	from l1ll111ll11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㠛")	:	from l1l1111l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ㠜")		:	from M3U			import MENUu as l1lll1111l1_l1_,SEARCHh as l1lll11l1l1_l1_,menu_namee as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ㠝")	:	from l1ll1ll11lll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ㠞")	:	from l1lll1l11l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ㠟")		:	from l11l11lll11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㠠")	:	from l1ll11lll1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㠡"):	from l11ll1lllll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ㠢")	:	from l11l1l111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㠣")	:	from l1111lll11l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㠤")	:	from l11lllll11l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㠥")	:	from l1ll111lll11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㠦")		:	from l11111l1ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㠧")	:	from l1ll1l1111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬ࡟ࡁࡒࡑࡗࠫ㠨")		:	from l11llll1111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㠩")	:	from l11lll1l1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll1111l_l1_
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭㠪"):	from l11ll1l111l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_
	return l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_
def l1llll11llll_l1_(l1l1ll1l111l_l1_,headers,l11_l1_):
	l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㠫"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧ㠬")+l1l1ll1l111l_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭㠭")+str(headers)+l1l111_l1_ (u"ࠫࠥࡣࠧ㠮"))
	l1l111l111_l1_ = l1l11l1111_l1_()
	l1l111l111_l1_.create(l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㠯"),l1l111_l1_ (u"๊࠭อำํࠤฬ๊ย็ࠢไัฺࠦวๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์่ࠦษ฻า๋ฬࠦำ้ใࠣฮอีรࠡ฻่่๏ฯࠠอๆหࠤฬ๊ๅๅใ้๋ࠣࠦวๅว้ฮึ์สࠨ㠰"))
	l1l11l1l1l_l1_ = 1024*1024
	chunksize = 1*l1l11l1l1l_l1_
	from requests import get
	response = get(l1l1ll1l111l_l1_,stream=True,headers=headers)
	l1ll111ll1ll_l1_ = response.headers
	response.close()
	l1ll111l1l11_l1_ = bytes()
	if not l1ll111ll1ll_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㠱"),l1l111_l1_ (u"ࠨࠩ㠲"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㠳"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭㠴"))
		l1l111l111_l1_.close()
	else:
		if l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬ㠵") not in list(l1ll111ll1ll_l1_.keys()): filesize = 0
		else: filesize = int(l1ll111ll1ll_l1_[l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭㠶")])
		l1l111llll_l1_ = str(int(1000*filesize/l1l11l1l1l_l1_)/1000.0)
		l11llll111_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡓࡣࡱ࡫ࡪ࠭㠷") in list(l1ll111ll1ll_l1_.keys()) and filesize>l1l11l1l1l_l1_:
			l1ll11ll11ll_l1_ = True
			ranges = []
			l11ll111l1l_l1_ = 10
			ranges.append(str(0*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㠸")+str(1*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(1*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㠹")+str(2*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(2*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㠺")+str(3*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(3*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㠻")+str(4*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(4*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㠼")+str(5*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(5*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㠽")+str(6*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(6*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㠾")+str(7*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(7*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㠿")+str(8*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(8*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡀")+str(9*filesize//l11ll111l1l_l1_-1))
			ranges.append(str(9*filesize//l11ll111l1l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㡁"))
			l11ll1lll1l_l1_ = float(l11llll111_l1_)/l11ll111l1l_l1_
			l111111l1l1_l1_ = l11ll1lll1l_l1_/int(1+l11ll1lll1l_l1_)
		else:
			l1ll11ll11ll_l1_ = False
			l11ll111l1l_l1_ = 1
			l111111l1l1_l1_ = 1
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㡂"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡸࡷ࡮ࡴࡧࠡࡴࡤࡲ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬ㡃")+str(l1ll11ll11ll_l1_)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ㡄")+str(filesize)+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㡅"))
		l1l11l111l_l1_,l1ll11llll1l_l1_ = 0,0
		for l1lll1l1llll_l1_ in range(l11ll111l1l_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll11ll11ll_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠧࡓࡣࡱ࡫ࡪ࠭㡆")] = l1l111_l1_ (u"ࠨࡤࡼࡸࡪࡹ࠽ࠨ㡇")+ranges[l1lll1l1llll_l1_]
			response = get(l1l1ll1l111l_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l111l111_l1_.iscanceled():
					l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㡈"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠪ㡉"))
					break
				l1l11l111l_l1_ += l111111l1l1_l1_
				l1ll111l1l11_l1_ += chunk
				if not l1ll11llll1l_l1_: l1ll11llll1l_l1_ = len(chunk)
				if filesize: l1l1111l11_l1_(l1l111l111_l1_,100*l1l11l111l_l1_//l11llll111_l1_,l1l111_l1_ (u"ࠫั๊ศࠡษ็้้็࠺࠮ࠢส่ัุมࠡำๅ้ࠬ㡊"),str(100.0*l1ll11llll1l_l1_*l1l11l111l_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠬࠦ࠯ࠡࠩ㡋")+l1l111llll_l1_+l1l111_l1_ (u"࠭ࠠࡎࡄࠪ㡌"))
				else: l1l1111l11_l1_(l1l111l111_l1_,l1ll11llll1l_l1_*l1l11l111l_l1_//chunksize,l1l111_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠬ㡍"),str(100.0*l1ll11llll1l_l1_*l1l11l111l_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠨࠢࡐࡆࠬ㡎"))
			response.close()
		l1l111l111_l1_.close()
		if len(l1ll111l1l11_l1_)<filesize and filesize>0:
			l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㡏"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭㡐")+str(len(l1ll111l1l11_l1_)//l1l11l1l1l_l1_)+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩ㡑")+l1l111llll_l1_+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ㡒"))
			l11l111111l_l1_ = l1l1lll11lll_l1_(l1l111_l1_ (u"࠭ࠧ㡓"),l1l111_l1_ (u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬ㡔"),l1l111_l1_ (u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨ㡕"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫ㡖"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㡗"),l1l111_l1_ (u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨ㡘")+str(len(l1ll111l1l11_l1_)//l1l11l1l1l_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫ㡙")+l1l111llll_l1_+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨ㡚"))
			if l11l111111l_l1_==2: l1ll111l1l11_l1_ = l1llll11llll_l1_(l1l1ll1l111l_l1_,headers,l11_l1_)
			elif l11l111111l_l1_==1: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㡛"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡓࡵࡴࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡤࡧࡨ࡫ࡰࡵࡧࡧࠤࡦࡴࡤࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡸࡷࡪࡪࠧ㡜"))
			else: return l1l111_l1_ (u"ࠩࠪ㡝")
			if not l1ll111l1l11_l1_: return l1l111_l1_ (u"ࠪࠫ㡞")
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㡟"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩ࠴ࠠࠡࠢࡉ࡭ࡱ࡫ࠠࡔ࡫ࡽࡩ࠿࡛ࠦࠡࠩ㡠")+l1l111llll_l1_+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ㡡"))
	return l1ll111l1l11_l1_
def l111111lll1_l1_(l1ll1_l1_):
	return response
def l11l1111lll_l1_(l1ll1lll11ll_l1_=l1l111_l1_ (u"ࠧࠨ㡢")):
	l1ll11lll1l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡵࡷࡶࠬ㡣"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㡤"),l1l111_l1_ (u"ࠪࡍࡕࡒࡏࡄࡃࡗࡍࡔࡔࠧ㡥"))
	if l1ll11lll1l1_l1_: return l1ll11lll1l1_l1_
	l1ll1lll11ll_l1_,l1ll1l111l11_l1_,l1lll1l1l1ll_l1_,l1l1111lll1_l1_,l1lll1l1l1l1_l1_,l1111ll11l1_l1_,timezone = l1l111_l1_ (u"ࠫࠬ㡦"),l1l111_l1_ (u"ࠬ࠭㡧"),l1l111_l1_ (u"࠭ࠧ㡨"),l1l111_l1_ (u"ࠧࠨ㡩"),l1l111_l1_ (u"ࠨࠩ㡪"),l1l111_l1_ (u"ࠩࠪ㡫"),l1l111_l1_ (u"ࠪࠫ㡬")
	url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡷࡩࡱ࠱࡭ࡸ࠵ࠧ㡭")+l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠬࡅ࡯ࡶࡶࡳࡹࡹࡃࡪࡴࡱࡱࠪ࡫࡯ࡥ࡭ࡦࡶࡁ࡮ࡶࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰ࠯ࡧ࡮ࡺࡹ࠭ࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ㡮")
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㡯"):l1l111_l1_ (u"ࠧࠨ㡰")}
	response = l1111llllll_l1_(l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㡱"),url,l1l111_l1_ (u"ࠩࠪ㡲"),headers,l1l111_l1_ (u"ࠪࠫ㡳"),l1l111_l1_ (u"ࠫࠬ㡴"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ㡵"))
	if not response.succeeded: l1111ll1l11_l1_ = l1ll1lll11ll_l1_+l1l111_l1_ (u"࠭ࠬࠨ㡶")+l1ll1l111l11_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㡷")+l1lll1l1l1ll_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㡸")+l1lll1l1l1l1_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㡹")+l1111ll11l1_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㡺")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠫࡡࢁ࠮ࠫࡁ࡟ࢁࡡࢃࠧ㡻"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l11l111l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㡼"),html)
			if l1l111_l1_ (u"࠭ࡩࡱࠩ㡽") in list(l11l11l111l_l1_.keys()): l1ll1lll11ll_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠧࡪࡲࠪ㡾")]
			if l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫ㡿") in list(l11l11l111l_l1_.keys()): l1ll1l111l11_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ㢀")]
			if l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㢁") in list(l11l11l111l_l1_.keys()): l1lll1l1l1ll_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㢂")]
			if l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ㢃") in list(l11l11l111l_l1_.keys()): l1l1111lll1_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ㢄")]
			if l1l111_l1_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ㢅") in list(l11l11l111l_l1_.keys()): l1lll1l1l1l1_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ㢆")]
			if l1l111_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ㢇") in list(l11l11l111l_l1_.keys()): l1111ll11l1_l1_ = l11l11l111l_l1_[l1l111_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ㢈")]
			if l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭㢉") in list(l11l11l111l_l1_.keys()):
				timezone = l11l11l111l_l1_[l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㢊")][l1l111_l1_ (u"࠭ࡵࡵࡥࠪ㢋")]
				if timezone[0] not in [l1l111_l1_ (u"ࠧ࠮ࠩ㢌"),l1l111_l1_ (u"ࠨ࠭ࠪ㢍")]: timezone = l1l111_l1_ (u"ࠩ࠮ࠫ㢎")+timezone
			l1111ll1l11_l1_ = l1ll1lll11ll_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㢏")+l1ll1l111l11_l1_+l1l111_l1_ (u"ࠫ࠱࠭㢐")+l1lll1l1l1ll_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㢑")+l1lll1l1l1l1_l1_+l1l111_l1_ (u"࠭ࠬࠨ㢒")+l1111ll11l1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢓")+timezone
			if kodi_version>18.99: l1111ll1l11_l1_ = l1111ll1l11_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㢔")).decode(l1l111_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㢕"))
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㢖"),l1l111_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ㢗"),l1111ll1l11_l1_,l111l11l_l1_)
	return l1111ll1l11_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"ࠬ࠭㢘"),True
	if search.count(l1l111_l1_ (u"࠭࡟ࠨ㢙"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠧࡠࠩ㢚"),1)
		options = l1l111_l1_ (u"ࠨࡡࠪ㢛")+options
		if l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ㢜") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1l1llllllll_l1_():
	l1lll1111l1l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㢝"))
	l1llllll1l11_l1_ = 0
	if os.path.exists(l1lll1111l1l_l1_):
		for filename in os.listdir(l1lll1111l1l_l1_):
			if l1l111_l1_ (u"ࠫ࠳ࡶࡹࡰࠩ㢞") in filename: continue
			if l1l111_l1_ (u"ࠬࡥ࡟ࡱࡻࡦࡥࡨ࡮ࡥࡠࡡࠪ㢟") in filename: continue
			l1ll1111ll_l1_ = os.path.join(l1lll1111l1l_l1_,filename)
			size,count = l1ll1l1ll1_l1_(l1ll1111ll_l1_)
			l1llllll1l11_l1_ += size
	return l1llllll1l11_l1_
def l11111ll1l1_l1_(l1l1lll11ll_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㢠")][3]
	user = l1l1ll1l11l_l1_(32)
	l1111ll1l11_l1_ = l11l1111lll_l1_()
	l1lll1l1l1ll_l1_ = l1111ll1l11_l1_.split(l1l111_l1_ (u"ࠧ࠭ࠩ㢡"))[2]
	l1llllll1l11_l1_ = l1l1llllllll_l1_()
	payload = {l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㢢"):user,l1l111_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ㢣"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㢤"):l1lll1l1l1ll_l1_,l1l111_l1_ (u"ࠫ࡮ࡪࡳࠨ㢥"):l1lll1111111_l1_(l1llllll1l11_l1_)}
	if not l1l1lll11ll_l1_: l1lll1ll111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ㢦"),(l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㢧"),url,payload,l1l111_l1_ (u"ࠧࠨ㢨"),l1l111_l1_ (u"ࠨࠩ㢩"),l1l111_l1_ (u"ࠩࠪ㢪")))
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㢫"),l1l111_l1_ (u"ࠫࠬ㢬"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㢭"),url,payload,l1l111_l1_ (u"࠭ࠧ㢮"),l1l111_l1_ (u"ࠧࠨ㢯"),l1l111_l1_ (u"ࠨࠩ㢰"),l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓ࠮ࡕࡋࡓ࡜ࡥࡍࡆࡕࡖࡅࡌࡋࡓ࠮࠳ࡶࡸࠬ㢱"),True,True)
	l11llll1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㢲"))
	if not l11llll1ll1_l1_: l11llll1ll1_l1_ = l1l111_l1_ (u"ࠫࡓࡋࡗࠨ㢳")
	l1lll11ll1l1_l1_ = l11llll1ll1_l1_
	if not response.succeeded: l1lll11ll1l1_l1_ = l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㢴")
	else:
		l1l11lll1ll_l1_,l1111llll1l_l1_,l111l11l11l_l1_,l11l1l11111_l1_ = l1l111_l1_ (u"࠭ࠧ㢵"),l1l111_l1_ (u"ࠧࠨ㢶"),l1l111_l1_ (u"ࠨࠩ㢷"),[]
		newfile = response.content
		if newfile:
			l11l1l11111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㢸"),newfile)
			for l1lllll11111_l1_,l1ll1l11l1ll_l1_,message in l11l1l11111_l1_:
				if kodi_version>18.99: message = message.encode(l1l111_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㢹")).decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㢺"))
				if l1lllll11111_l1_==l1l111_l1_ (u"ࠬ࠶ࠧ㢻"): l1l11lll1ll_l1_ += message+l1l111_l1_ (u"࠭࠺࠻ࠩ㢼")
				else: l1111llll1l_l1_ += message+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㢽")
			l1111llll1l_l1_ = l1111llll1l_l1_.strip(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㢾"))
			l1l11lll1ll_l1_ = l1l11lll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠽࠾ࠬ㢿"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㣀"),l1l11lll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㣁"),l1lll1111111_l1_(now))
		if os.path.exists(l1l1ll1ll1ll_l1_): l111l11l11l_l1_ = open(l1l1ll1ll1ll_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㣂")).read()
		if kodi_version>18.99: l1111llll1l_l1_ = l1111llll1l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㣃"))
		if l1111llll1l_l1_!=l111l11l11l_l1_:
			l1lll11ll1l1_l1_ = l1l111_l1_ (u"ࠧࡏࡇ࡚ࠫ㣄")
			try: open(l1l1ll1ll1ll_l1_,l1l111_l1_ (u"ࠨࡹࡥࠫ㣅")).write(l1111llll1l_l1_)
			except: pass
		if l11_l1_:
			l11l1l11111_l1_ = sorted(l11l1l11111_l1_,reverse=True,key=lambda key: int(key[0]))
			l111l11l111_l1_ = l1l111_l1_ (u"ࠩࠪ㣆")
			for l1lllll11111_l1_,l1ll1l11l1ll_l1_,message in l11l1l11111_l1_:
				if kodi_version>18.99: message = message.encode(l1l111_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㣇")).decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㣈"))
				if l111l11l111_l1_: l111l11l111_l1_ += l1l111_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭㣉")
				if l1lllll11111_l1_==l1l111_l1_ (u"࠭࠰ࠨ㣊"): continue
				date = message.split(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㣋"))[0]
				l11ll1111l1_l1_ = l1l111_l1_ (u"ࠨࠩ㣌")
				if l1ll1l11l1ll_l1_:
					l11ll1111l1_l1_ = l1l111_l1_ (u"ࠩิืฬ๊ษࠡะสูฮࠦไไࠢไๆ฼࠭㣍")
					if kodi_version>18.99: l11ll1111l1_l1_ = l11ll1111l1_l1_.encode(l1l111_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㣎")).decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㣏"))
				l111l11l111_l1_ += message.replace(date,l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㣐")+date+l11ll1111l1_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㣑"))+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㣒")
			l111l11l111_l1_ = escapeUNICODE(l111l11l111_l1_)
			l1l11ll111_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㣓"),l1l111_l1_ (u"ࠩิืฬฬไࠡ็้ࠤฬ๊ๅษำ่ะࠥหไ๊่ࠢืฯิฯๆ์ࠣห้ฮั็ษ่ะࠬ㣔"),l111l11l111_l1_,l1l111_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ㣕"))
			l1lll11ll1l1_l1_ = l1l111_l1_ (u"ࠫࡔࡒࡄࠨ㣖")
		if l1lll11ll1l1_l1_!=l11llll1ll1_l1_:
			settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㣗"),l1lll11ll1l1_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㣘"))
	return l1lll11ll1l1_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll11l1ll1l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll11l1ll1l_l1_ = False
	l11ll1llll_l1_ = time.time()
	if l1ll11l1ll1l_l1_: resp = l11ll1llll_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠧࠨ㣙"),l1l111_l1_ (u"ࠨࠩ㣚"),l1l111_l1_ (u"ࠩࠪ㣛"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㣜"),l1l111_l1_ (u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪ㣝"))
	else: l1llll1l11_l1_ = True
	if l1llll1l11_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠬ࠴ࡤࡣࠩ㣞")) and l1l111_l1_ (u"࠭ࡤࡢࡶࡤࠫ㣟") in filename:
				l1lll11111_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
				except: return
				l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡰࡷࡩ࡬ࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬࠽ࠪ㣠"))
				l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡱࡳࡸ࡮ࡳࡩࡻࡧ࠾ࠫ㣡"))
				l1lllll1l1_l1_.execute(l1l111_l1_ (u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪ㣢"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㣣"),l1l111_l1_ (u"ࠫࠬ㣤"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㣥"),l1l111_l1_ (u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧ㣦"))
	return
def l1ll11lll111_l1_(word):
	if l1l111_l1_ (u"ࠧ࡜ࠩ㣧") in word and l1l111_l1_ (u"ࠨ࡟ࠪ㣨") in word:
		l11ll1ll111_l1_ = [l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㣩"),l1l111_l1_ (u"ࠪ࡟࠴ࡘࡔࡍ࡟ࠪ㣪"),l1l111_l1_ (u"ࠫࡠ࠵ࡌࡆࡈࡗࡡࠬ㣫"),l1l111_l1_ (u"ࠬࡡ࠯ࡓࡋࡊࡌ࡙ࡣࠧ㣬"),l1l111_l1_ (u"࡛࠭࠰ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ㣭"),l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㣮"),l1l111_l1_ (u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠨ㣯"),l1l111_l1_ (u"ࠩ࡞ࡖࡎࡍࡈࡕ࡟ࠪ㣰"),l1l111_l1_ (u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ㣱")]
		l11ll1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠴ࠪࡀ࡞ࡠࠫ㣲"),word,re.DOTALL)
		l11ll111l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࡀ࠺࠻࠰࠭ࡃࡡࡣࠧ㣳"),word,re.DOTALL)
		l1ll1l111lll_l1_ = l11ll1ll111_l1_+l11ll1111ll_l1_+l11ll111l11_l1_
		for tag in l1ll1l111lll_l1_: word = word.replace(tag,l1l111_l1_ (u"࠭ࠧ㣴"))
	return word
def l1lllll111ll_l1_(l1l111l11ll_l1_,l1111l1111l_l1_,l1lll1llll11_l1_,l1ll1ll111l1_l1_):
	from PIL import ImageDraw,ImageFont,Image
	l11ll1l1l1l_l1_,l11l1l11l1l_l1_,l1ll111ll111_l1_ = l1l111_l1_ (u"ࠧࠨ㣵"),0,15000
	l1l111l11ll_l1_ = l1l111l11ll_l1_.replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ㣶"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓ࠼࠽࠾ࠬ㣷"))
	l1l1llll1l11_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l1111l1111l_l1_)
	l1lll1llll11_l1_ -= l1111l1111l_l1_*2
	l11l1llll1l_l1_ = Image.new(l1l111_l1_ (u"ࠪࡖࡌࡈࡁࠨ㣸"),(l1lll1llll11_l1_,99),(255,255,255,0))
	l111lll11l1_l1_ = ImageDraw.Draw(l11l1llll1l_l1_)
	for l1ll11ll1111_l1_ in l1l111l11ll_l1_.splitlines():
		l11l1l11l1l_l1_ += l1ll1ll111l1_l1_
		l1111l11ll1_l1_,newline = 0,l1l111_l1_ (u"ࠫࠬ㣹")
		for word in l1ll11ll1111_l1_.split(l1l111_l1_ (u"ࠬࠦࠧ㣺")):
			l111ll111ll_l1_ = l1ll11lll111_l1_(l1l111_l1_ (u"࠭ࠠࠨ㣻")+word)
			l1lllll1ll1l_l1_,l111ll1l111_l1_ = l111lll11l1_l1_.textsize(l111ll111ll_l1_,font=l1l1llll1l11_l1_)
			if l1111l11ll1_l1_+l1lllll1ll1l_l1_<l1lll1llll11_l1_:
				if not newline: newline += word
				else: newline += l1l111_l1_ (u"ࠧࠡࠩ㣼")+word
				l1111l11ll1_l1_ += l1lllll1ll1l_l1_
			else:
				if l1lllll1ll1l_l1_<l1lll1llll11_l1_:
					newline += l1l111_l1_ (u"ࠨ࡞ࡱࠤࠬ㣽")+word
					l11l1l11l1l_l1_ += l1ll1ll111l1_l1_
					l1111l11ll1_l1_ = l1lllll1ll1l_l1_
				else:
					while l1lllll1ll1l_l1_>l1lll1llll11_l1_:
						for l1l11l111l_l1_ in range(1,len(l1l111_l1_ (u"ࠩࠣࠫ㣾")+word),1):
							l111lll1ll1_l1_ = l1l111_l1_ (u"ࠪࠤࠬ㣿")+word[:l1l11l111l_l1_]
							l11l111llll_l1_ = word[l1l11l111l_l1_:]
							l1llll11111l_l1_ = l1ll11lll111_l1_(l111lll1ll1_l1_)
							l11ll11ll11_l1_,l111l1l1111_l1_ = l111lll11l1_l1_.textsize(l1llll11111l_l1_,font=l1l1llll1l11_l1_)
							if l1111l11ll1_l1_+l11ll11ll11_l1_>l1lll1llll11_l1_:
								l1lll1l1l111_l1_ = l1lllll1ll1l_l1_-l11ll11ll11_l1_
								newline += l111lll1ll1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㤀")
								l11l1l11l1l_l1_ += l1ll1ll111l1_l1_
								l1lllll1ll1l_l1_ = l1lll1l1l111_l1_
								if l1lll1l1l111_l1_>l1lll1llll11_l1_:
									l1111l11ll1_l1_ = 0
									word = l11l111llll_l1_
								else:
									l1111l11ll1_l1_ = l1lll1l1l111_l1_
									newline += l11l111llll_l1_
								break
				if l11l1l11l1l_l1_>l1ll111ll111_l1_: break
		l11ll1l1l1l_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࠨ㤁")+newline
		if l11l1l11l1l_l1_>l1ll111ll111_l1_: break
	l11ll1l1l1l_l1_ = l11ll1l1l1l_l1_[1:]
	l11ll1l1l1l_l1_ = l11ll1l1l1l_l1_.replace(l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࡀ࠺࠻ࠩ㤂"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨ㤃"))
	return l11ll1l1l1l_l1_
def l11l1ll1l11_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤄"),l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ㤅"))
	text = text.replace(l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ㤆"),l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳࡶ࡯ࡣࠬ㤇"))
	text = text.replace(l1l111_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠬ㤈"),l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧ࡯ࡩ࡫ࡺ࡟ࠨ㤉"))
	text = text.replace(l1l111_l1_ (u"ࠧ࡜ࡔࡌࡋࡍ࡚࡝ࠨ㤊"),l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ㤋"))
	text = text.replace(l1l111_l1_ (u"ࠩ࡞ࡇࡊࡔࡔࡆࡔࡠࠫ㤌"),l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫ࡣࡦࡰࡷࡩࡷࡥࠧ㤍"))
	text = text.replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㤎"),l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧ㤏"))
	l1llllll11l1_l1_ = re.findall(l1l111_l1_ (u"࠭࡜࡜ࡅࡒࡐࡔࡘࠠࠩ࠰࠭ࡃ࠮ࡢ࡝ࠨ㤐"),text,re.DOTALL)
	for l1lll1l111ll_l1_ in l1llllll11l1_l1_: text = text.replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨ㤑")+l1lll1l111ll_l1_+l1l111_l1_ (u"ࠨ࡟ࠪ㤒"),l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡨࡵ࡬ࡰࡴࠪ㤓")+l1lll1l111ll_l1_+l1l111_l1_ (u"ࠪࡣࠬ㤔"))
	return text
def l1lllllllll1_l1_(l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text,profile,l11ll1l11l1_l1_,l1lll11l11l1_l1_,l1ll1lll1l11_l1_):
	l1111111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㤕"))
	if l1111111lll_l1_:
		l1lll_l1_ = LANGUAGE_TRANSLATE([l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text])
		if l1lll_l1_: l111l1l11l1_l1_,l1ll11ll1l11_l1_,l111l1l1lll_l1_,header,text = l1lll_l1_
	from PIL import ImageDraw,ImageFont,Image
	if kodi_version<19:
		text = text.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤖"))
		header = header.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㤗"))
		l111l1l11l1_l1_ = l111l1l11l1_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㤘"))
		l1ll11ll1l11_l1_ = l1ll11ll1l11_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㤙"))
		l111l1l1lll_l1_ = l111l1l1lll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㤚"))
	l111ll1ll11_l1_ = 5
	l1l1llll111l_l1_ = 20
	l1llll1ll111_l1_ = 20
	l1lll1l1ll1l_l1_ = 0
	l1l111l1ll1_l1_ = l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㤛")
	l1ll1111llll_l1_ = 0
	l1ll11l11111_l1_ = 19
	l11l1l11l11_l1_ = 30
	l1llll1l1111_l1_ = 8
	l1lll1l11ll1_l1_ = True
	l1ll11ll1l1l_l1_ = 375
	l1l1lllll1ll_l1_ = 410
	l1l1ll1lllll_l1_ = 50
	l1ll1ll11l11_l1_ = 280
	l111l111ll1_l1_ = 28
	l1ll1111l11l_l1_ = 5
	l11l1111l11_l1_ = 0
	l1lll1lll1ll_l1_ = 31
	l11l1111ll1_l1_ = [36,32,28]
	if profile in [l1l111_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㤜"),l1l111_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㤝")]:
		if profile==l1l111_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ㤞"):
			l1l111l1111_l1_ = l1l111_l1_ (u"ࠧࡖࡒࡓࡉࡗ࠭㤟")
			l1l111l1ll1_l1_ = l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㤠")
			l1lll1l11ll1_l1_ = True
			l1lll1l1ll1l_l1_ = 10
		else:
			l1l111l1111_l1_ = 97+20
			l1l111l1ll1_l1_ = l1l111_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㤡")
			l1lll1l11ll1_l1_ = False
		l11l1111ll1_l1_ = [33,33,33]
		l1llll1ll111_l1_ = 20
		l1l1llll111l_l1_ = 0
		l11l1l11l11_l1_ = 20
		l1ll11l11111_l1_ = 25+10
	elif profile==l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧ㤢"): l11l1111ll1_l1_ = [28,24,20] ; l1l111l1111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ㤣"): l11l1111ll1_l1_ = [32,28,24] ; l1l111l1111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ㤤"): l11l1111ll1_l1_ = [36,32,28] ; l1l111l1111_l1_ = 500
	elif profile==l1l111_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㤥"): l1l111l1111_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㤦"): l1l111l1111_l1_ = l1l111_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ㤧")
	elif profile==l1l111_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧ㤨"): l11l1111ll1_l1_ = [28,23,18] ; l1l111l1111_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㤩"): l11l1111ll1_l1_ = [28,23,18] ; l1l111l1111_l1_ = l1l111_l1_ (u"࡚ࠫࡖࡐࡆࡔࠪ㤪")
	l11111lllll_l1_ = l11l1111ll1_l1_[0]
	l11l11l11ll_l1_ = l11l1111ll1_l1_[1]
	l1l1111ll11_l1_ = l11l1111ll1_l1_[2]
	l1111l1l11l_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l11111lllll_l1_)
	l1llll1lll1l_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l11l11l11ll_l1_)
	l1llllll111l_l1_ = ImageFont.truetype(l1111l1l111_l1_,size=l1l1111ll11_l1_)
	l11l1llll1l_l1_ = Image.new(l1l111_l1_ (u"ࠬࡘࡇࡃࡃࠪ㤫"),(100,100),(255,255,255,0))
	l111lll11l1_l1_ = ImageDraw.Draw(l11l1llll1l_l1_)
	l1ll11l11lll_l1_,l1lll1111ll1_l1_ = l111lll11l1_l1_.textsize(l1l111_l1_ (u"࠭ࡈࡉࡊࠣࡆࡇࡈࠠ࠹࠺࠻ࠤ࠵࠶࠰ࠨ㤬"),font=l1llll1lll1l_l1_)
	l1ll11ll11l1_l1_,l111l11ll1l_l1_ = l111lll11l1_l1_.textsize(l1l111_l1_ (u"ࠧࡉࡊࡋࠤࡇࡈࡂࠡ࠺࠻࠼ࠥ࠶࠰࠱ࠩ㤭"),font=l1111l1l11l_l1_)
	l1ll111l111l_l1_ = header.count(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤮"))+1
	l11ll11l11l_l1_ = l1l1llll111l_l1_+l1ll111l111l_l1_*(l111l11ll1l_l1_+l1lll1l1ll1l_l1_)-l1lll1l1ll1l_l1_
	l1lll11l1lll_l1_ = {l1l111_l1_ (u"ࠩࡧࡩࡱ࡫ࡴࡦࡡ࡫ࡥࡷࡧ࡫ࡢࡶࠪ㤯"):False,l1l111_l1_ (u"ࠪࡷࡺࡶࡰࡰࡴࡷࡣࡱ࡯ࡧࡢࡶࡸࡶࡪࡹࠧ㤰"):True,l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࠤࡑࡏࡇࡂࡖࡘࡖࡊࠦࡁࡍࡎࡄࡌࠬ㤱"):False}
	from arabic_reshaper import ArabicReshaper
	l11ll11l111_l1_ = ArabicReshaper(configuration=l1lll11l1lll_l1_)
	if text:
		l1l1111l1l1_l1_ = l1lll11l11l1_l1_-l11l1l11l11_l1_*2
		l1ll111lllll_l1_ = l1lll1111ll1_l1_+l1llll1l1111_l1_
		l1lll11lll11_l1_ = l11ll11l111_l1_.reshape(text)
		if l1lll1l11ll1_l1_:
			l1l1ll1l1ll1_l1_ = l1lllll111ll_l1_(l1lll11lll11_l1_,l11l11l11ll_l1_,l1l1111l1l1_l1_,l1ll111lllll_l1_)
			l11111111ll_l1_ = l1ll11lll111_l1_(l1l1ll1l1ll1_l1_)
			l1lll11l1l1l_l1_ = l11111111ll_l1_.count(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㤲"))+1
			if l1lll11l1l1l_l1_<6:
				l1ll11ll1lll_l1_ = l1l1111l1l1_l1_
				l1l1ll1l1ll1_l1_ = l1lllll111ll_l1_(l1lll11lll11_l1_,l11l11l11ll_l1_,l1ll11ll1lll_l1_,l1ll111lllll_l1_)
				l11111111ll_l1_ = l1ll11lll111_l1_(l1l1ll1l1ll1_l1_)
				l1lll11l1l1l_l1_ = l11111111ll_l1_.count(l1l111_l1_ (u"࠭࡜࡯ࠩ㤳"))+1
			l11lll11lll_l1_ = l1ll11l11111_l1_+l1lll11l1l1l_l1_*l1ll111lllll_l1_-l1llll1l1111_l1_
		else:
			l11lll11lll_l1_ = l1ll11l11111_l1_+l1lll1111ll1_l1_
			l11111111ll_l1_ = l1lll11lll11_l1_.split(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㤴"))[0]
			l1l1ll1l1ll1_l1_ = l1lll11lll11_l1_.split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤵"))[0]
	else: l11lll11lll_l1_ = l1ll11l11111_l1_
	l1lll1ll1l11_l1_ = l11l1111l11_l1_+l1lll1lll1ll_l1_
	if l1ll1lll1l11_l1_:
		l1ll1l1l11ll_l1_ = l1l1lllll1ll_l1_-l1ll11ll1l1l_l1_
		l1lll1ll1l11_l1_ += l1ll1l1l11ll_l1_
	else: l1ll1l1l11ll_l1_ = 0
	if l111l1l11l1_l1_ or l1ll11ll1l11_l1_ or l111l1l1lll_l1_: l1lll1ll1l11_l1_ += l1l1ll1lllll_l1_
	if l1l111l1111_l1_!=l1l111_l1_ (u"ࠩࡘࡔࡕࡋࡒࠨ㤶"): l11l11111ll_l1_ = l1l111l1111_l1_
	else: l11l11111ll_l1_ = l11ll11l11l_l1_+l11lll11lll_l1_+l1lll1ll1l11_l1_
	l1lllllll11l_l1_ = l11l11111ll_l1_-l11ll11l11l_l1_-l1lll1ll1l11_l1_-l1ll11l11111_l1_
	l11l1llll1l_l1_ = Image.new(l1l111_l1_ (u"ࠪࡖࡌࡈࡁࠨ㤷"),(l1lll11l11l1_l1_,l11l11111ll_l1_),(255,255,255,0))
	l111lll11l1_l1_ = ImageDraw.Draw(l11l1llll1l_l1_)
	if not l1ll11ll1l11_l1_ and l111l1l11l1_l1_ and l111l1l1lll_l1_:
		l111l111ll1_l1_ += 105
		l1ll1111l11l_l1_ -= 110
	if header:
		l111ll1ll1l_l1_ = l1l1llll111l_l1_
		header = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1lll1l11111_l1_ = l111lll11l1_l1_.textsize(line,font=l1111l1l11l_l1_)
				if l1l111l1ll1_l1_==l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㤸"): l1ll11llll11_l1_ = l111ll1ll11_l1_+(l1lll11l11l1_l1_-width)/2
				elif l1l111l1ll1_l1_==l1l111_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㤹"): l1ll11llll11_l1_ = l111ll1ll11_l1_+l1lll11l11l1_l1_-width-l1llll1ll111_l1_
				elif l1l111l1ll1_l1_==l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㤺"): l1ll11llll11_l1_ = l111ll1ll11_l1_+l1llll1ll111_l1_
				l111lll11l1_l1_.text((l1ll11llll11_l1_,l111ll1ll1l_l1_),line,font=l1111l1l11l_l1_,fill=l1l111_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ㤻"))
			l111ll1ll1l_l1_ += l11111lllll_l1_+l1lll1l1ll1l_l1_
	if l111l1l11l1_l1_ or l1ll11ll1l11_l1_ or l111l1l1lll_l1_:
		l11ll111lll_l1_ = l11ll11l11l_l1_+l1lllllll11l_l1_+l1ll11l11111_l1_+l1ll1l1l11ll_l1_+l11l1111l11_l1_
		if l111l1l11l1_l1_:
			l111l1l11l1_l1_ = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(l111l1l11l1_l1_))
			l1lll111l1ll_l1_,l111llllll1_l1_ = l111lll11l1_l1_.textsize(l111l1l11l1_l1_,font=l1llllll111l_l1_)
			l11l1111l1l_l1_ = l111l111ll1_l1_+0*(l1ll1111l11l_l1_+l1ll1ll11l11_l1_)+(l1ll1ll11l11_l1_-l1lll111l1ll_l1_)/2
			l111lll11l1_l1_.text((l11l1111l1l_l1_,l11ll111lll_l1_),l111l1l11l1_l1_,font=l1llllll111l_l1_,fill=l1l111_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ㤼"))
		if l1ll11ll1l11_l1_:
			l1ll11ll1l11_l1_ = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(l1ll11ll1l11_l1_))
			l1llll1l111l_l1_,l1lll1llllll_l1_ = l111lll11l1_l1_.textsize(l1ll11ll1l11_l1_,font=l1llllll111l_l1_)
			l11l11l11l1_l1_ = l111l111ll1_l1_+1*(l1ll1111l11l_l1_+l1ll1ll11l11_l1_)+(l1ll1ll11l11_l1_-l1llll1l111l_l1_)/2
			l111lll11l1_l1_.text((l11l11l11l1_l1_,l11ll111lll_l1_),l1ll11ll1l11_l1_,font=l1llllll111l_l1_,fill=l1l111_l1_ (u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ㤽"))
		if l111l1l1lll_l1_:
			l111l1l1lll_l1_ = bidi.algorithm.get_display(l11ll11l111_l1_.reshape(l111l1l1lll_l1_))
			l11l1llll11_l1_,l111l11l1l1_l1_ = l111lll11l1_l1_.textsize(l111l1l1lll_l1_,font=l1llllll111l_l1_)
			l11111l11ll_l1_ = l111l111ll1_l1_+2*(l1ll1111l11l_l1_+l1ll1ll11l11_l1_)+(l1ll1ll11l11_l1_-l11l1llll11_l1_)/2
			l111lll11l1_l1_.text((l11111l11ll_l1_,l11ll111lll_l1_),l111l1l1lll_l1_,font=l1llllll111l_l1_,fill=l1l111_l1_ (u"ࠪࡽࡪࡲ࡬ࡰࡹࠪ㤾"))
	if text:
		l1l1lll1l1l1_l1_,l11ll11111l_l1_ = [],[]
		l1l1ll1l1ll1_l1_ = l11l1ll1l11_l1_(l1l1ll1l1ll1_l1_)
		l1ll11l1l1ll_l1_ = l1l1ll1l1ll1_l1_.split(l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ㤿"))
		for l1ll1111111l_l1_ in l1ll11l1l1ll_l1_:
			l11lll1ll11_l1_ = l11ll1l11l1_l1_
			if   l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧ㥀") in l1ll1111111l_l1_: l11lll1ll11_l1_ = l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㥁")
			elif l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪ㥂") in l1ll1111111l_l1_: l11lll1ll11_l1_ = l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㥃")
			elif l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭㥄") in l1ll1111111l_l1_: l11lll1ll11_l1_ = l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㥅")
			l11llll11ll_l1_ = l1ll1111111l_l1_
			l11ll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢ࠲࠯ࡅ࡟ࠨ㥆"),l1ll1111111l_l1_,re.DOTALL)
			for tag in l11ll1ll111_l1_: l11llll11ll_l1_ = l11llll11ll_l1_.replace(tag,l1l111_l1_ (u"ࠬ࠭㥇"))
			if l11llll11ll_l1_==l1l111_l1_ (u"࠭ࠧ㥈"): width,l1lll1l11111_l1_ = 0,l1ll111lllll_l1_
			else: width,l1lll1l11111_l1_ = l111lll11l1_l1_.textsize(l11llll11ll_l1_,font=l1llll1lll1l_l1_)
			if   l11lll1ll11_l1_==l1l111_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㥉"): l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_
			elif l11lll1ll11_l1_==l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㥊"): l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_+l1l1111l1l1_l1_-width
			elif l11lll1ll11_l1_==l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㥋"): l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_+(l1l1111l1l1_l1_-width)/2
			if l1111ll1ll1_l1_<l11l1l11l11_l1_: l1111ll1ll1_l1_ = l1ll1111llll_l1_+l11l1l11l11_l1_
			l1l1lll1l1l1_l1_.append(l1111ll1ll1_l1_)
			l11ll11111l_l1_.append(width)
		l1111ll1ll1_l1_ = l1l1lll1l1l1_l1_[0]
		l1ll11lll11l_l1_ = l1l1ll1l1ll1_l1_.split(l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࠩ㥌"))
		l11lllllll1_l1_ = (255,255,255,255)
		l1lllll111l1_l1_ = l11lllllll1_l1_
		l1ll111llll1_l1_,l1llll11l111_l1_ = 0,0
		l11111l111l_l1_ = False
		l111l1ll1ll_l1_ = 0
		l1ll111l1111_l1_ = l11ll11l11l_l1_+l1ll11l11111_l1_/2
		if l11lll11lll_l1_<(l1lllllll11l_l1_+l1ll11l11111_l1_):
			l111ll1l11l_l1_ = (l1lllllll11l_l1_+l1ll11l11111_l1_-l11lll11lll_l1_)/2
			l1ll111l1111_l1_ = l11ll11l11l_l1_+l1ll11l11111_l1_+l111ll1l11l_l1_-l1lll1111ll1_l1_/2
		for line in l1ll11lll11l_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1ll1l1l1111_l1_ = line.split(l1l111_l1_ (u"ࠫࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ㥍"),1)
			l1ll1l1l111l_l1_ = line.split(l1l111_l1_ (u"ࠬࡥ࡮ࡦࡹࡦࡳࡱࡵࡲࠨ㥎"),1)
			l1ll1l1l11l1_l1_ = line.split(l1l111_l1_ (u"࠭࡟ࡦࡰࡧࡧࡴࡲ࡯ࡳࡡࠪ㥏"),1)
			l1ll1l11ll11_l1_ = line.split(l1l111_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ㥐"),1)
			l1lllll1lll1_l1_ = line.split(l1l111_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ㥑"),1)
			l1ll1l11lll1_l1_ = line.split(l1l111_l1_ (u"ࠩࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ㥒"),1)
			l1ll1l11llll_l1_ = line.split(l1l111_l1_ (u"ࠪࡣࡱ࡯࡮ࡦࡥࡨࡲࡹ࡫ࡲࡠࠩ㥓"),1)
			if len(l1ll1l1l1111_l1_)>1:
				l111l1ll1ll_l1_ += 1
				line = l1ll1l1l1111_l1_[1]
				l1ll111llll1_l1_ = 0
				l1111ll1ll1_l1_ = l1l1lll1l1l1_l1_[l111l1ll1ll_l1_]
				l1llll11l111_l1_ += l1ll111lllll_l1_
				l11111l111l_l1_ = False
			elif len(l1ll1l1l111l_l1_)>1:
				line = l1ll1l1l111l_l1_[1]
				l1lllll111l1_l1_ = line[0:8]
				l1lllll111l1_l1_ = l1l111_l1_ (u"ࠫࠨ࠭㥔")+l1lllll111l1_l1_[2:]
				line = line[9:]
			elif len(l1ll1l1l11l1_l1_)>1:
				line = l1ll1l1l11l1_l1_[1]
				l1lllll111l1_l1_ = l11lllllll1_l1_
			elif len(l1ll1l11ll11_l1_)>1:
				line = l1ll1l11ll11_l1_[1]
				l11111l111l_l1_ = True
				l1ll111llll1_l1_ = l11ll11111l_l1_[l111l1ll1ll_l1_]
			elif len(l1lllll1lll1_l1_)>1:
				line = l1lllll1lll1_l1_[1]
			elif len(l1ll1l11lll1_l1_)>1:
				line = l1ll1l11lll1_l1_[1]
			elif len(l1ll1l11llll_l1_)>1:
				line = l1ll1l11llll_l1_[1]
			if line:
				l1ll1ll111ll_l1_ = l1ll111l1111_l1_+l1llll11l111_l1_
				line = bidi.algorithm.get_display(line)
				width,l1lll1l11111_l1_ = l111lll11l1_l1_.textsize(line,font=l1llll1lll1l_l1_)
				if l11111l111l_l1_: l1ll111llll1_l1_ -= width
				l1111ll1l1l_l1_ = l1111ll1ll1_l1_+l1ll111llll1_l1_
				l111lll11l1_l1_.text((l1111ll1l1l_l1_,l1ll1ll111ll_l1_),line,font=l1llll1lll1l_l1_,fill=l1lllll111l1_l1_)
				if not l11111l111l_l1_: l1ll111llll1_l1_ += width
				if l1ll1ll111ll_l1_>l1lllllll11l_l1_+l1ll111lllll_l1_: break
	l1lll11l11ll_l1_ = l1l1llll11ll_l1_.replace(l1l111_l1_ (u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ㥕"),l1l111_l1_ (u"࠭࡟ࠨ㥖")+str(time.time())+l1l111_l1_ (u"ࠧࡠࠩ㥗"))
	l1lll11l11ll_l1_ = l1lll11l11ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ㥘"),l1l111_l1_ (u"ࠩ࡟ࡠࡡࡢࠧ㥙")).replace(l1l111_l1_ (u"ࠪ࠳࠴࠭㥚"),l1l111_l1_ (u"ࠫ࠴࠵࠯࠰ࠩ㥛"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	l11l1llll1l_l1_.save(l1lll11l11ll_l1_)
	return l1lll11l11ll_l1_,l11l11111ll_l1_
def l1111llllll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_=True,l1lll1111lll_l1_=True):
	if allow_redirects==l1l111_l1_ (u"ࠬ࠭㥜"): allow_redirects = True
	if l11_l1_==l1l111_l1_ (u"࠭ࠧ㥝"): l11_l1_ = True
	if l11ll1ll11l_l1_==l1l111_l1_ (u"ࠧࠨ㥞"): l11ll1ll11l_l1_ = True
	if l1lll1111lll_l1_==l1l111_l1_ (u"ࠨࠩ㥟"): l1lll1111lll_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1lll1l11l1l_l1_ = list(headers.keys())
	if l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㥠") not in l1lll1l11l1l_l1_: headers[l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㥡")] = l1l111_l1_ (u"ࠫࡅࡆࡀࡔࡍࡌࡔࡤࡎࡅࡂࡆࡈࡖࡅࡆࡀࠨ㥢")
	l1lllll1_l1_,l1ll11l11l1l_l1_,l1lll111l1l1_l1_,l1ll1lll1111_l1_ = l1ll1111l1l1_l1_(url)
	l1l1lll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ㥣"))
	l1ll111ll11l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㥤"))
	l1ll11l1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㥥"))
	l1lll11111ll_l1_ = (l1ll11l11l1l_l1_==None and l1lll111l1l1_l1_==None and l1ll1lll1111_l1_==None)
	l111ll1l1l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㥦")]
	l1ll111l1lll_l1_ = l1lllll1_l1_ in l111ll1l1l1_l1_
	l111lll1l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㥧")]
	l11ll1llll1_l1_ = l1lllll1_l1_ in l111lll1l11_l1_
	l111llll1l1_l1_ = l1ll111l1lll_l1_ or l11ll1llll1_l1_
	if l1lll11111ll_l1_ and l111llll1l1_l1_:
		if l1ll111l1lll_l1_:
			l1lllllll111_l1_ = l111ll1l1l1_l1_.index(l1lllll1_l1_)
			l1111ll1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧ㥨")][l1lllllll111_l1_]
			l111l1ll111_l1_ = l111l111111_l1_[l1lllllll111_l1_]
		elif l11ll1llll1_l1_:
			l1lllllll111_l1_ = l111lll1l11_l1_.index(l1lllll1_l1_)
			l1111ll1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖࠧ㥩")][l1lllllll111_l1_]
			l111l1ll111_l1_ = l11l11llll1_l1_[l1lllllll111_l1_]
	if l1lll111l1l1_l1_==l1l111_l1_ (u"ࠬ࠭㥪"): l1lll111l1l1_l1_ = l1l1lll1llll_l1_
	elif l1lll111l1l1_l1_==None and l1ll111ll11l_l1_ in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㥫"),l1l111_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ㥬")] and l11ll1ll11l_l1_: l1lll111l1l1_l1_ = l1l1lll1llll_l1_
	l1lll111l111_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㥭")][7]
	if source==l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ㥮"): l1l111ll11l_l1_ = 120
	elif source==l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ㥯"): l1l111ll11l_l1_ = 20
	elif source==l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ㥰"): l1l111ll11l_l1_ = 20
	elif source in l1llllll1ll1_l1_: l1l111ll11l_l1_ = 10
	elif l1ll111l1lll_l1_ or l11ll1llll1_l1_: l1l111ll11l_l1_ = 15
	elif l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓࠧ㥱") in source: l1l111ll11l_l1_ = 70
	elif l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㥲") in source: l1l111ll11l_l1_ = 75
	elif l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㥳") in source: l1l111ll11l_l1_ = 25
	elif l1l111_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ㥴") in source: l1l111ll11l_l1_ = 20
	elif l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㥵") in source: l1l111ll11l_l1_ = 20
	elif l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩ㥶") in source: l1l111ll11l_l1_ = 30
	elif l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㥷") in source: l1l111ll11l_l1_ = 25
	elif l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㥸") in source: l1l111ll11l_l1_ = 30
	elif l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ㥹") in source: l1l111ll11l_l1_ = 20
	else: l1l111ll11l_l1_ = 15
	if l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㥺") in source and not data and l1l111_l1_ (u"ࠨࠨࠪ㥻") not in l1lllll1_l1_ and l1l111_l1_ (u"ࠩࡂࠫ㥼") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠪ࠳ࠬ㥽"))+l1l111_l1_ (u"ࠫ࠴࠭㥾")
	l11lll111l1_l1_ = (l1ll11l11l1l_l1_!=None)
	l1ll1lllllll_l1_ = (l1lll111l1l1_l1_!=None and l1ll111ll11l_l1_!=l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㥿"))
	if l11lll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩ㦀"),l1ll11l11l1l_l1_)
	elif l1ll1lllllll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧ㦁"),l1lll111l1l1_l1_)
	if l11lll111l1_l1_:
		proxies = {l1l111_l1_ (u"ࠣࡪࡷࡸࡵࠨ㦂"):l1ll11l11l1l_l1_,l1l111_l1_ (u"ࠤ࡫ࡸࡹࡶࡳࠣ㦃"):l1ll11l11l1l_l1_}
		l1111111111_l1_ = l1ll11l11l1l_l1_
	else: proxies,l1111111111_l1_ = {},l1l111_l1_ (u"ࠪࠫ㦄")
	if l1ll1lllllll_l1_:
		import urllib3.util.connection as connection
		l11l11l1111_l1_ = l1ll11111111_l1_(connection,l1l1lll1llll_l1_)
	verify = True
	l1ll11ll1ll1_l1_,l1ll1l1ll1ll_l1_,l1l11lll1_l1_,l11llll11l1_l1_,l11lll11111_l1_ = allow_redirects,source,method,False,False
	if l1lll111l111_l1_: l11lll11111_l1_ = True
	if l111llll1l1_l1_ or allow_redirects: l1ll11ll1ll1_l1_ = False
	if l1ll111l1lll_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㦅")
	import requests
	code,reason = -1,l1l111_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ㦆")
	for l1l11l111l_l1_ in range(9):
		l1llll1lllll_l1_ = True
		succeeded = False
		try:
			if l1l11l111l_l1_: l1ll1l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠵ࡸࡺࠧ㦇")
			if not l11lll111l1_l1_: l1l1ll1111l_l1_(l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡓࡕࡋࡎࡠࡗࡕࡐࠬ㦈"),l1lllll1_l1_,data,headers,l1ll1l1ll1ll_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1ll11ll1ll1_l1_,timeout=l1l111ll11l_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11llll11l1_l1_:
					l1111111l11_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㦉") in l1111111l11_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㦊")]
					elif l1l111_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ㦋") in l1111111l11_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭㦌")]
					else: l11llll11l1_l1_ = True
					if not l11llll11l1_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭㦍"),l1l111_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭㦎")).decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㦏"),l1l111_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ㦐"))
					if l111llll1l1_l1_ and response.status_code==307:
						l1ll11ll1ll1_l1_ = allow_redirects
						l1l11lll1_l1_ = method
						l11llll11l1_l1_ = True
						l1lll1l1111l_l1_
				if not l11llll11l1_l1_ or allow_redirects:
					if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㦑") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㦒"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠫ࠴࠭㦓")+l1lllll1_l1_
				if not l11llll11l1_l1_ and allow_redirects:
					l11ll1l11l_l1_ = l1l111ll1l_l1_(l1lllll1_l1_)
					if l11ll1l11l_l1_ not in [l1l111_l1_ (u"ࠬ࠴ࡡࡷ࡫ࠪ㦔"),l1l111_l1_ (u"࠭࠮ࡵࡵࠪ㦕"),l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ㦖"),l1l111_l1_ (u"ࠨ࠰ࡤࡥࡨ࠭㦗"),l1l111_l1_ (u"ࠩ࠱ࡱࡰࡼࠧ㦘"),l1l111_l1_ (u"ࠪ࠲ࡲࡶ࠳ࠨ㦙"),l1l111_l1_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪ㦚")]: l1lll1l1111l_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11lll11111_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l1l111_l1_ (u"ࠬࡀࠠࠨ㦛"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"࠭࠺ࠡࠩ㦜"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠧࡆࡴࡵࡲࡴ࠭㦝") in error: code,reason = re.findall(l1l111_l1_ (u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥ㦞"),error)[0]
				elif l1l111_l1_ (u"ࠩ࠯ࠤࡪࡸࡲࡰࡴࠫࠫ㦟") in error: code,reason = re.findall(l1l111_l1_ (u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ㦠"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠫ࠿࠭㦡"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠬࡀࠠࠩ࠰࠭ࡃ࠮ࡀ࠮ࠫࡁࠫࡠࡩ࠱ࠩࠨ㦢"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1llll1lllll_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㦣"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㦤")+str(code)+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㦥")+reason+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㦦")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㦧")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ㦨"))
		if l1llll1lllll_l1_ and l111llll1l1_l1_ and not l11lll11111_l1_ and code!=200:
			l1lllll1_l1_ = l1111ll1lll_l1_
			l11lll11111_l1_ = True
			continue
		if l1llll1lllll_l1_: break
	if l1lll111l1l1_l1_!=None and l1ll111ll11l_l1_!=l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㦩"): connection.create_connection = l11l11l1111_l1_
	if l1ll111ll11l_l1_==l1l111_l1_ (u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭㦪") and l11ll1ll11l_l1_: l1lll111l1l1_l1_ = None
	if not succeeded and l1ll11l11l1l_l1_==None and source not in l1llllll1ll1_l1_:
		l1111llll11_l1_ = traceback.format_exc()
		sys.stderr.write(l1111llll11_l1_)
	l1lll1l11_l1_ = l1l1lllll1l_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"ࠧࠨ㦫")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if kodi_version>18.99:
		try: content = content.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㦬"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = headers
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1lll1l11_l1_.content,str): l1ll111ll1l1_l1_ = l1lll1l11_l1_.content.lower()
	else: l1ll111ll1l1_l1_ = l1l111_l1_ (u"ࠩࠪ㦭")
	l1llll11ll11_l1_ = (l1l111_l1_ (u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ㦮") in l1ll111ll1l1_l1_ or l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ㦯") in l1ll111ll1l1_l1_) and l1ll111ll1l1_l1_.count(l1l111_l1_ (u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ㦰"))>2 and l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ㦱") not in source and l1l111_l1_ (u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩ㦲") not in l1ll111ll1l1_l1_
	if code==200 and l1llll11ll11_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1lll11111ll_l1_ and l111llll1l1_l1_:
		if l1lll111l111_l1_: l111l1ll111_l1_ = l1l111_l1_ (u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩ㦳")+data[l1l111_l1_ (u"ࠩ࡭ࡳࡧ࠭㦴")].upper().replace(l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㦵"),l1l111_l1_ (u"ࠫࠬ㦶"))
		l1lll11ll_l1_ = l1ll1111111_l1_(l111l1ll111_l1_)
	if not l1lll1l11_l1_.succeeded and l1lll11111ll_l1_:
		l1llll11l1l1_l1_ = (l1l111_l1_ (u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ㦷") in l1ll111ll1l1_l1_ and l1l111_l1_ (u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨ㦸") in l1ll111ll1l1_l1_)
		l1llll11l1ll_l1_ = (l1l111_l1_ (u"ࠧ࠶ࠢࡶࡩࡨ࠭㦹") in l1ll111ll1l1_l1_ and l1l111_l1_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩ㦺") in l1ll111ll1l1_l1_)
		l1llll11ll1l_l1_ = (code in [403] and l1l111_l1_ (u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬ㦻") in l1ll111ll1l1_l1_)
		l1llll11lll1_l1_ = (l1l111_l1_ (u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬ㦼") in l1ll111ll1l1_l1_ and l1l111_l1_ (u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨ㦽") in l1ll111ll1l1_l1_)
		if   l1llll11ll11_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㦾")
		elif l1llll11l1l1_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ㦿")
		elif l1llll11l1ll_l1_: reason = l1l111_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ㧀")
		elif l1llll11ll1l_l1_: reason = l1l111_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩ㧁")
		elif l1llll11lll1_l1_: reason = l1l111_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ㧂")
		else: reason = str(reason)
		if source in l1llllll1ll1_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㧃"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ㧄")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㧅")+reason+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧆")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㧇")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㧈"))
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㧉"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ㧊")+str(code)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㧋")+reason+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㧌")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㧍")+l1lllll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㧎"))
		l1111l111ll_l1_ = l111l11_l1_(l1lllll1_l1_)
		if kodi_version<19 and isinstance(l1111l111ll_l1_,unicode): l1111l111ll_l1_ = l1111l111ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㧏"))
		if l111llll1l1_l1_: l1111l111ll_l1_ = l1111l111ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ㧐"))[-1]
		reason = str(reason)+l1l111_l1_ (u"ࠪࡠࡳ࠮ࠠࠨ㧑")+l1111l111ll_l1_+l1l111_l1_ (u"ࠫࠥ࠯ࠧ㧒")
		if l1llll11ll11_l1_ or l1llll11l1l1_l1_ or l1llll11l1ll_l1_ or l1llll11ll1l_l1_ or l1llll11lll1_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
		l1llll1l11_l1_ = True
		if (l1ll111ll11l_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㧓") or l1ll11l1lll1_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㧔")) and (l11ll1ll11l_l1_ or l1lll1111lll_l1_):
			l1llll1l11_l1_ = l1lllll11lll_l1_(code,reason,source,l11_l1_)
			if l1llll1l11_l1_ and l1ll111ll11l_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧕"): l1ll111ll11l_l1_ = l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧖")
			else: l1ll111ll11l_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㧗")
			if l1llll1l11_l1_ and l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㧘"): l1ll11l1lll1_l1_ = l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㧙")
			else: l1ll11l1lll1_l1_ = l1l111_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ㧚")
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㧛"),l1ll111ll11l_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㧜"),l1ll11l1lll1_l1_)
		if l1llll1l11_l1_:
			l1l1llll1l1l_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ㧝") in l1lllll1_l1_ and l1l1llll1l1l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡใะฺูࠥ็ศัฬࠤฬ๊สีใํี࡙ࠥࡓࡍࠩ㧞"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧟"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠫࢁࢂࡍࡺࡕࡖࡐ࡚ࡸ࡬࠾ࠩ㧠")
				l1lll11ll_l1_ = l1111llllll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㧡"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧢")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㧣")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㧤"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"้ࠩะฬำࠠษษึฮำีวๆࠢࡖࡗࡑ࠭㧥"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧦"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㧧"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㧨")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㧩")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㧪"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫ㧫"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㧬"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll11l1lll1_l1_ in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㧭"),l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㧮")] and l1lll1111lll_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㧯"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧰"),time=2000)
				l1lll11ll_l1_ = l11ll1ll1ll_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㧱"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧲")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧳")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㧴"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ㧵"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧶"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㧷"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㧸")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧹")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㧺"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ㧻"),l1l111_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭㧼"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll111ll11l_l1_ in [l1l111_l1_ (u"ࠬࡇࡕࡕࡑࠪ㧽"),l1l111_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ㧾")] and l11ll1ll11l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩ㧿"),l1l111_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㨀"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ㨁")
				l1lll11ll_l1_ = l1111llllll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㨂"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫ㨃")+l1l1lll1llll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㨄")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㨅")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㨆"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩ㨇"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㨈"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㨉"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ㨊")+l1l1lll1llll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㨋")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㨌")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㨍"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨใืู่๊ࠥาใิࠤࡉࡔࡓࠨ㨎"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㨏"),time=2000)
		if l1ll11l1lll1_l1_==l1l111_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ㨐") or l1ll111ll11l_l1_==l1l111_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭㨑"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11llll1l11_l1_ = l1lllll11lll_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1ll111l_l1_ and l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࠩ㨒") not in source:
				l11111l11l1_l1_(l1l111_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥ࡯ࡳࡴࡷࡨࡷࠥࡽࡩࡵࡪ࠽ࠤࠬ㨓")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㨔")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㨕"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㨖"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㨗")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㨘"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㨙"))
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㨚")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㨛"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㨜"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㨝")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㨞"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㨟"))
	return l1lll1l11_l1_
def l11l1l_l1_(l1l1l1llll1_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_=True,l1lll1111lll_l1_=True):
	item = method,url,data,headers,allow_redirects,l11_l1_
	if l1l1l1llll1_l1_:
		response = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ㨠"),l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ㨡"),item)
		if response.succeeded:
			l1l1ll1111l_l1_(l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ㨢"),url,data,headers,source,method)
			return response
	response = l1111llllll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1ll11l_l1_,l1lll1111lll_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㨣") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l1l1l1llll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ㨤"),item,response,l1l1l1llll1_l1_)
	return response
def l1l1llll_l1_(l1l1l1llll1_l1_,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㨥")
	else:
		method = l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㨦")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(l1l1l1llll1_l1_,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll1111l1l1_l1_(url):
	l1ll11l1ll11_l1_ = url.split(l1l111_l1_ (u"ࠬࢂࡼࠨ㨧"))
	l1lllll1_l1_,l1ll11l11l1l_l1_,l1lll111l1l1_l1_,l1ll1lll1111_l1_ = l1ll11l1ll11_l1_[0],None,None,None
	for item in l1ll11l1ll11_l1_:
		if l1l111_l1_ (u"࠭ࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ㨨") in item: l1ll11l11l1l_l1_ = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ㨩"))[1]
		elif l1l111_l1_ (u"ࠨࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ㨪") in item: l1lll111l1l1_l1_ = item.split(l1l111_l1_ (u"ࠩࡀࠫ㨫"))[1]
		elif l1l111_l1_ (u"ࠪࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭㨬") in item: l1ll1lll1111_l1_ = item.split(l1l111_l1_ (u"ࠫࡂ࠭㨭"))[1]
	return l1lllll1_l1_,l1ll11l11l1l_l1_,l1lll111l1l1_l1_,l1ll1lll1111_l1_
def l11lll1llll_l1_(name):
	start,l1lll11l1ll_l1_,modified = l1l111_l1_ (u"ࠬ࠭㨮"),l1l111_l1_ (u"࠭ࠧ㨯"),l1l111_l1_ (u"ࠧࠨ㨰")
	name = name.replace(ltr,l1l111_l1_ (u"ࠨࠩ㨱")).replace(rtl,l1l111_l1_ (u"ࠩࠪ㨲"))
	tmp = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠯࡜࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡞ࡠࠬࡡࡽ࡜ࡸ࡞ࡺ࠭ࠥ࠱࡜࡜࡞࠲ࡇࡔࡒࡏࡓ࡞ࡠࠬ࠳࠰࠿ࠪࠦࠪ㨳"),name,re.DOTALL)
	if tmp: start,l1lll11l1ll_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"ࠫࠥ࠭㨴"),l1l111_l1_ (u"ࠬ࠲ࠧ㨵"),l1l111_l1_ (u"࠭ࠧ㨶")]: modified = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㨷")
	if l1lll11l1ll_l1_: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࠪ㨸")+l1lll11l1ll_l1_+l1l111_l1_ (u"ࠩࡢࠫ㨹")
	name = l1lll11l1ll_l1_+modified+name
	return name
def l1lllll11ll_l1_(url,l1ll1ll1l1ll_l1_,l1ll1llll1l1_l1_,l1llllll1l1l_l1_,headers={}):
	l1l1ll1lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㨺"))
	l11l1l11ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭㨻")+l1ll1ll1l1ll_l1_)
	if l1l1ll1lll1l_l1_==l11l1l11ll1_l1_: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ㨼")+l1ll1ll1l1ll_l1_,l1l111_l1_ (u"࠭ࠧ㨽"))
	if l11l1l11ll1_l1_: l1llllll_l1_ = url.replace(l1l1ll1lll1l_l1_,l11l1l11ll1_l1_)
	else:
		l1llllll_l1_ = url
		l11l1l11ll1_l1_ = l1l1ll1lll1l_l1_
	l1lll11ll_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㨾"),l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ㨿"),headers,l1l111_l1_ (u"ࠩࠪ㩀"),l1l111_l1_ (u"ࠪࠫ㩁"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨ㩂"))
	html = l1lll11ll_l1_.content
	try: html = html.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㩃"),l1l111_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭㩄"))
	except: pass
	if not l1lll11ll_l1_.succeeded or l1llllll1l1l_l1_ not in html:
		l1ll1llll1l1_l1_ = l1ll1llll1l1_l1_.replace(l1l111_l1_ (u"ࠧࠡࠩ㩅"),l1l111_l1_ (u"ࠨ࠭ࠪ㩆"))
		l1lllll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ㩇")+l1ll1llll1l1_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㩈"):l1l111_l1_ (u"ࠫࠬ㩉")}
		l1lll1l11_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㩊"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ㩋"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ㩌"),l1l111_l1_ (u"ࠨࠩ㩍"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭㩎"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㩏"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ㩐"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰࡞ࡺ࠮ࡡࡅ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭㩑"),html,re.DOTALL)
			l1111ll1111_l1_ = [l11l1l11ll1_l1_]
			l111l11ll11_l1_ = [l1l111_l1_ (u"࠭ࡡࡱ࡭ࠪ㩒"),l1l111_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ㩓"),l1l111_l1_ (u"ࠨࡶࡺ࡭ࡹࡺࡥࡳࠩ㩔"),l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ㩕"),l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬ㩖")]
			for l1ll1ll_l1_ in l1ll_l1_:
				l11l1l11ll1_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㩗"))
				if any(value in l1ll1ll_l1_ for value in l111l11ll11_l1_): continue
				if l11l1l11ll1_l1_ in l1111ll1111_l1_: continue
				if len(l1111ll1111_l1_)==9:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㩘"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ㩙")+l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬ㩚")+l1l1ll1lll1l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㩛"))
					settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ㩜")+l1ll1ll1l1ll_l1_,l1l111_l1_ (u"ࠪࠫ㩝"))
					break
				l1111ll1111_l1_.append(l11l1l11ll1_l1_)
				l1llllll_l1_ = url.replace(l1l1ll1lll1l_l1_,l11l1l11ll1_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㩞"),l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭㩟"),headers,l1l111_l1_ (u"࠭ࠧ㩠"),l1l111_l1_ (u"ࠧࠨ㩡"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬ㩢"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l1llllll1l1l_l1_ in html:
					l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㩣"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡦࡰࡷࡱࡨࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ㩤")+l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡑࡩࡼࡀࠠ࡜ࠢࠪ㩥")+l11l1l11ll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪ㩦")+l1l1ll1lll1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㩧"))
					settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ㩨")+l1ll1ll1l1ll_l1_,l11l1l11ll1_l1_)
					break
	return l11l1l11ll1_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠨࡱ࡯ࡨࠬ㩩")			:l1l111_l1_ (u"ࠩๅำ๏๋ࠧ㩪")
	,l1l111_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ㩫")		:l1l111_l1_ (u"๊ࠫะ่ใใࠪ㩬")
	,l1l111_l1_ (u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭㩭")		:l1l111_l1_ (u"࠭ๅโไ๋ำࠬ㩮")
	,l1l111_l1_ (u"ࠧࡨࡱࡲࡨࠬ㩯")			:l1l111_l1_ (u"ࠨฮํำࠬ㩰")
	,l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㩱")		:l1l111_l1_ (u"ࠪๅู๊ࠧ㩲")
	,l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㩳")		:l1l111_l1_ (u"๋ࠬฬๅัࠪ㩴")
	,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㩵")		:l1l111_l1_ (u"ࠧโ์า๎ํ࠭㩶")
	,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㩷")			:l1l111_l1_ (u"ࠩๅ๊ฬฯࠧ㩸")
	,l1l111_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࠩ㩹")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨ㩺")
	,l1l111_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࠫ㩻")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪ㩼")
	,l1l111_l1_ (u"ࠧࡢ࡭ࡲࡥࡲࡩࡡ࡮ࠩ㩽")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩ㩾")
	,l1l111_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ㩿")		:l1l111_l1_ (u"้ࠪํู่ࠡๅ็ࠤฬู๊าสࠪ㪀")
	,l1l111_l1_ (u"ࠫࡦࡲࡦࡢࡶ࡬ࡱ࡮࠭㪁")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห้๋ๆษำࠣห้็วุ็ํࠫ㪂")
	,l1l111_l1_ (u"࠭ࡡ࡭࡭ࡤࡻࡹ࡮ࡡࡳࠩ㪃")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣห้้่ฬำࠪ㪄")
	,l1l111_l1_ (u"ࠨࡣ࡯ࡱࡦࡧࡲࡦࡨࠪ㪅")		:l1l111_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥอไๆ฻สีๆ࠭㪆")
	,l1l111_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ㪇")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢ฼ีอࠦไ๋๊้ึࠬ㪈")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩ㪉")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫ㪊")
	,l1l111_l1_ (u"ࠧࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢࠩ㪋")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦวๅีํ๊๊อࠧ㪌")
	,l1l111_l1_ (u"ࠩ࡫ࡩࡱࡧ࡬ࠨ㪍")		:l1l111_l1_ (u"้ࠪํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭㪎")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡨࡤࡲࡸ࠭㪏")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡใส๊ื࠭㪐")
	,l1l111_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ㪑")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ฺࠥว่ัࠣๅํื๊้ࠩ㪒")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬࡭ࡢࡺࠪ㪓")		:l1l111_l1_ (u"่ࠩ์็฿ࠠี๊ไࠤ๊อใิࠩ㪔")
	,l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ㪕")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢ฼ีอࠦำ๋์าࠫ㪖")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭㪗")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭㪘")
	,l1l111_l1_ (u"ࠧ࡬ࡣࡵࡦࡦࡲࡡࡵࡸࠪ㪙")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫ㪚")
	,l1l111_l1_ (u"ࠩࡼࡸࡧࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ㪛")	:l1l111_l1_ (u"้ࠪํอโฺࠢํ์ฯ๐่ษࠩ㪜")
	,l1l111_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ㪝")		:l1l111_l1_ (u"๋่ࠬใ฻้ࠣฬ๐ࠠิ์่หࠬ㪞")
	,l1l111_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭㪟")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬ࠭㪠")
	,l1l111_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ㪡")		:l1l111_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫ㪢")
	,l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠶ࠬ㪣")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧ㪤")
	,l1l111_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ㪥")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤอ้ัศࠩ㪦")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩ㪧")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ฾ฮฯ้ࠩ㪨")
	,l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࡴࡷࠩ㪩")		:l1l111_l1_ (u"้้ࠪ็ࠧ㪪")
	,l1l111_l1_ (u"ࠫࡱ࡯ࡢࡳࡣࡵࡽࠬ㪫")		:l1l111_l1_ (u"๋ࠬไโࠩ㪬")
	,l1l111_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭㪭")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩ㪮")
	,l1l111_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࡳࡩࡱࡺࠫ㪯")	:l1l111_l1_ (u"่ࠩ์็฿ࠠโฮิࠤู๎ࠧ㪰")
	,l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ㪱")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠬ㪲")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧ㪳")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠲ࠩ㪴")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠳ࠩ㪵")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫ㪶")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫ㪷")		:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠸࠭㪸")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠹࠭㪹")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠴ࠨ㪺")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭㪻")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩ㪼")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ㪽")		:l1l111_l1_ (u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩ㪾")
	,l1l111_l1_ (u"ࠪࡩ࡬ࡿࡤࡦࡣࡧࠫ㪿")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢศ๎ั๐ࠠะ์าࠫ㫀")
	,l1l111_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ㫁")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭㫂")
	,l1l111_l1_ (u"ࠧ࡭ࡱࡧࡽࡳ࡫ࡴࠨ㫃")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦไ้ัํࠤ๋ะࠧ㫄")
	,l1l111_l1_ (u"ࠩࡷࡺ࡫ࡻ࡮ࠨ㫅")		:l1l111_l1_ (u"้ࠪํู่ࠡฬํๅ๏ࠦแศ่ࠪ㫆")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧ㫇")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๆส๎ฯ࠭㫈")
	,l1l111_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩࡴࡥࡸࡵࠪ㫉")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨ㫊")
	,l1l111_l1_ (u"ࠨࡨࡲࡷࡹࡧࠧ㫋")		:l1l111_l1_ (u"่ࠩ์็฿ࠠโ๊ึฮฬ࠭㫌")
	,l1l111_l1_ (u"ࠪࡥ࡭ࡽࡡ࡬ࠩ㫍")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭㫎")
	,l1l111_l1_ (u"ࠬ࡬ࡡࡣࡴࡤ࡯ࡦ࠭㫏")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆฮัไหࠪ㫐")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡣࡹࡲࡶࡰ࠭㫑")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠢ฼้้࠭㫒")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࠫ㫓")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠫ㫔")
	,l1l111_l1_ (u"ࠫࡸ࡮࡯ࡧࡪࡤࠫ㫕")		:l1l111_l1_ (u"๋่ࠬใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧ㫖")
	,l1l111_l1_ (u"࠭ࡢࡳࡵࡷࡩ࡯࠭㫗")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬ㫘")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺࠰࠱ࠩ㫙")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ࠺࠰࠱ࠩ㫚")
	,l1l111_l1_ (u"ࠪࡰࡦࡸ࡯ࡻࡣࠪ㫛")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢ็หึ๎าศࠩ㫜")
	,l1l111_l1_ (u"ࠬࡿࡡࡲࡱࡷࠫ㫝")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏อโ้ฬࠪ㫞")
	,l1l111_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ㫟")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬ㫠")
	,l1l111_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡵࡶࡹࠫ㫡")		:l1l111_l1_ (u"้ࠪํู่ࠡๅอ็ํะࠠห์ไ๎ࠬ㫢")
	,l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩ㫣")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣฮํ์าࠡ฻ิฬ๏ฯࠧ㫤")
	,l1l111_l1_ (u"࠭ࡤࡳࡣࡰࡥࡸ࠽ࠧ㫥")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤฺำࠧ㫦")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ㫧")		:l1l111_l1_ (u"่ࠩ์็฿ࠠี๊ไࠤอื่ࠨ㫨")
	,l1l111_l1_ (u"ࠪ࡭࡫࡯࡬࡮ࠩ㫩")				:l1l111_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ㫪")
	,l1l111_l1_ (u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫ㫫")			:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨ㫬")
	,l1l111_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧ㫭")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭㫮")
	,l1l111_l1_ (u"ࠩࡳࡥࡳ࡫ࡴࠨ㫯")				:l1l111_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠧ㫰")
	,l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ㫱")			:l1l111_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨ㫲")
	,l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬ㫳")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬ㫴")
	,l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ㫵")				:l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠧ㫶")
	,l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠫ㫷")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢไ๎ิ๐่่ษอࠫ㫸")
	,l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ㫹")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็๎วว็ࠪ㫺")
	,l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ㫻")		:l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ㫼")
	,l1l111_l1_ (u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬ㫽")			:l1l111_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬ㫾")
	,l1l111_l1_ (u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨ㫿")	:l1l111_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬ㬀")
	,l1l111_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡰࡧࡻ࡭ࡴࠩ㬁")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢส่อ๎ๅࠨ㬂")
	,l1l111_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡻࡤࡪࡱࡶࠫ㬃")		:l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫ㬄")
	,l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㬅")			:l1l111_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠬ㬆")
	,l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡺ࡮ࡪࡥࡰࡵࠪ㬇")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩ㬈")
	,l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ㬉"):l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨ㬊")
	,l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ㬋")	:l1l111_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็์่ศฬࠪ㬌")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡷࡳࡵ࡯ࡣࡴࠩ㬍")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦๅ้ษู๎฾࠭㬎")
	,l1l111_l1_ (u"࠭ࡩࡱࡶࡹࠫ㬏")					:l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㬐")
	,l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠳࡬ࡪࡸࡨࠫ㬑")			:l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠠใ่๋หฯ࠭㬒")
	,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮࡯ࡲࡺ࡮࡫ࡳࠨ㬓")			:l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠢฦๅ้อๅࠨ㬔")
	,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡷࡪࡸࡩࡦࡵࠪ㬕")			:l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠤู๊ไิๆสฮࠬ㬖")
	,l1l111_l1_ (u"ࠧ࡮࠵ࡸࠫ㬗")					:l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㬘")
	,l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫ㬙")				:l1l111_l1_ (u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭㬚")
	,l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨ㬛")			:l1l111_l1_ (u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨ㬜")
	,l1l111_l1_ (u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪ㬝")			:l1l111_l1_ (u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬ㬞")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠨࠩ㬟")
	return result
def l11111l11l1_l1_(message=l1l111_l1_ (u"ࠩࠪ㬠")):
	l1ll1lllll11_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠪ࠾࠴࠭㬡")):
	return _1llll1ll1ll_l1_(urll,exceptions)
def l11l111l11l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠫࠬ㬢"),l1l111_l1_ (u"ࠬ࠶ࠧ㬣"),0]: return l1l111_l1_ (u"࠭ࠧ㬤")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1ll11l1_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll11l11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll11l1_l1_)+str(l111ll11l11_l1_)+str(l111l111_l1_)
	return result
def l1ll11l1l11l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠧࠨ㬥"),l1l111_l1_ (u"ࠨ࠲ࠪ㬦"),0]: return l1l111_l1_ (u"ࠩࠪ㬧")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠪࠫ㬨")
	if len(l1l1llll1_l1_)==15:
		l11l1ll11l1_l1_,l111ll11l11_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1ll11l1_l1_ = int(l11l1ll11l1_l1_)^l111l11l_l1_
		l111ll11l11_l1_ = int(l111ll11l11_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1ll11l1_l1_==l111ll11l11_l1_==l111l111_l1_: result = str(l11l1ll11l1_l1_*60)
	return result
def l1lll1111111_l1_(l1l1llll1_l1_,l1lll11l111l_l1_=l1l111_l1_ (u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭㬩")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠬ࠭㬪"): return l1l111_l1_ (u"࠭ࠧ㬫")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1lll11l111l_l1_)
	l11l1ll11l1_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll11l11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll11l1_l1_)+str(l111ll11l11_l1_)+str(l111l111_l1_)
	return result
def l111111llll_l1_(l1l1llll1_l1_,l1lll11l111l_l1_=l1l111_l1_ (u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩ㬬")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠨࠩ㬭"): return l1l111_l1_ (u"ࠩࠪ㬮")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l1l1lll_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1ll11l1_l1_ = int(l1l1llll1_l1_[0:l1l1l1l1lll_l1_])^l1ll1ll1_l1_
	l111ll11l11_l1_ = int(l1l1llll1_l1_[l1l1l1l1lll_l1_:2*l1l1l1l1lll_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l1l1lll_l1_:3*l1l1l1l1lll_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠪࠫ㬯")
	if l11l1ll11l1_l1_==l111ll11l11_l1_==l111l111_l1_: result = str(int(l11l1ll11l1_l1_)-int(l1lll11l111l_l1_))
	return result
def l1l1ll1l111_l1_(l1l11ll1ll1_l1_):
	l1llll1l11l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㬰")][8]
	l1111lll111_l1_ = l1l1ll1l11l_l1_(32)
	l1ll1ll11l1l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ㬱"),l1l111_l1_ (u"࠭ࡳ࡬࡫ࡱࡷࠬ㬲"),l1l111_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ㬳"),l1l111_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭㬴"),l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㬵"))
	l11ll11llll_l1_,l111lllll1l_l1_ = l1ll1l1ll1_l1_(l1ll1ll11l1l_l1_)
	l11ll11llll_l1_ = l1lll1111111_l1_(l11ll11llll_l1_,l1l111_l1_ (u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭㬶"))
	l111l1lllll_l1_ = {l1l111_l1_ (u"ࠫ࡮ࡪࡳࠨ㬷"):l1l111_l1_ (u"ࠬࡊࡉࡂࡎࡒࡋࠬ㬸"),l1l111_l1_ (u"࠭ࡵࡴࡴࠪ㬹"):l1111lll111_l1_,l1l111_l1_ (u"ࠧࡷࡧࡵࠫ㬺"):l1l11l1llll_l1_,l1l111_l1_ (u"ࠨࡵࡦࡶࠬ㬻"):l1l11ll1ll1_l1_,l1l111_l1_ (u"ࠩࡶ࡭ࡿ࠭㬼"):l11ll11llll_l1_}
	l1lll11ll1ll_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㬽"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㬾")}
	l1llll1ll11l_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㬿"),l1llll1l11l1_l1_,l111l1lllll_l1_,l1lll11ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ㭀"),l1l111_l1_ (u"ࠧࠨ㭁"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩ㭂"))
	l1l1llll1lll_l1_ = l1llll1ll11l_l1_.content
	try:
		if not l1l1llll1lll_l1_: l1ll111lll1l_l1_
		l1lll11ll111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㭃"),l1l1llll1lll_l1_)
		l1l1llll11l1_l1_ = l1lll11ll111_l1_[l1l111_l1_ (u"ࠪࡱࡸ࡭ࠧ㭄")]
		l1ll11l111l1_l1_ = l1lll11ll111_l1_[l1l111_l1_ (u"ࠫࡸ࡫ࡣࠨ㭅")]
		l1lll1ll11l1_l1_ = l1lll11ll111_l1_[l1l111_l1_ (u"ࠬࡹࡴࡱࠩ㭆")]
		l1ll11l111l1_l1_ = int(l111111llll_l1_(l1ll11l111l1_l1_,l1l111_l1_ (u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩ㭇")))
		l1lll1ll11l1_l1_ = int(l111111llll_l1_(l1lll1ll11l1_l1_,l1l111_l1_ (u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪ㭈")))
		for l111l111l11_l1_ in range(l1ll11l111l1_l1_,0,-l1lll1ll11l1_l1_):
			if not eval(l1l111_l1_ (u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫ㭉")): l1ll111lll1l_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠩหห็๐ࠠๅๆอะึฮษ๊ࠡส่ๆำีࠨ㭊"),str(l111l111l11_l1_)+l1l111_l1_ (u"ࠪࠤࠥัว็์ฬࠫ㭋"),time=500)
			xbmc.sleep(l1lll1ll11l1_l1_*1000)
		if eval(l1l111_l1_ (u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧ㭌")):
			l111ll11111_l1_ = l1l111_l1_ (u"ࠧࡊࡉࡂࡎࡒࡋ࡬ࡥࡏࡌࠪࠪࠫ࠱࠭ฮา๊ฯࠫ࠱࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠯ࠫࠧ㭍")+l1l1llll11l1_l1_+l1l111_l1_ (u"ࠨࠧࠪࠤ㭎")
			l111ll11111_l1_ = l111ll11111_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㭏"),l1l111_l1_ (u"ࠨ࡞࡟ࡲࠬ㭐")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ㭑"),l1l111_l1_ (u"ࠪࡠࡡࡸࠧ㭒"))
			exec(l111ll11111_l1_)
		l1ll111lll1l_l1_
	except: exec(l1l111_l1_ (u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫ㭓"))
	return
def l1l111lll1l_l1_():
	exec(l1l111_l1_ (u"ࠬ࠭ࠧࠎࠌࡷࡶࡾࡀࠍࠋࠋࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷ࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯࡙࡬ࡲࡩࡵࡷࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࡻ࡭࡯࡬ࡦࠢࡗࡶࡺ࡫࠺ࠎࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡶࡰࡪ࡫ࡰࠩ࠳࠳࠴࠵࠯ࠍࠋࠋࠌࡸࡷࡿ࠺ࠡࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶࠲࡬࡫ࡴࡇࡱࡦࡹࡸ࠮࠱࠱࠲࠵࠹࠮ࠓࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡦࡷ࡫ࡡ࡬ࠏࠍࠍࡿࡩࡲࡦࡣࡷࡩࡤ࡫ࡲࡰࡴࡵࠑࠏ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮ࠓࠊࠨࠩࠪ㭔"))
	return
def l1ll1l1ll1_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1lllll11l_l1_(l1lllll1llll_l1_,l1ll1l111l1l_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"࠭ࠧ㭕"),l1l111_l1_ (u"ࠧࠨ㭖"),l1l111_l1_ (u"ࠨࠩ㭗"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㭘"),l1lllll1llll_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㭙")+l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㭚"))
		if l1llll1l11_l1_!=1: return
	error = False
	if os.path.exists(l1lllll1llll_l1_):
		for root,dirs,l1l1111111_l1_ in os.walk(l1lllll1llll_l1_,topdown=False):
			for file in l1l1111111_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㭛"),l1l111_l1_ (u"࠭ࠧ㭜"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㭝"),str(err))
					error = True
			if l1ll1l111l1l_l1_:
				for dir in dirs:
					l1l1ll1ll11l_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l1ll1ll11l_l1_)
					except: pass
		if l1ll1l111l1l_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㭞"),l1l111_l1_ (u"ࠩࠪ㭟"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㭠"),l1l111_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ㭡"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㭢"),l1l111_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩ㭣"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㭤"))
	return
def l1ll1lllll11_l1_(l1111llll11_l1_=l1l111_l1_ (u"ࠨࠩ㭥")):
	if l1111llll11_l1_:
		l1111111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㭦"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㭧"),l1l111_l1_ (u"ࠫࠬ㭨"))
		l11l1l1111l_l1_(l1111llll11_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㭩"),l1111111lll_l1_)
	l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㭪"))
	if l1ll11ll1l_l1_==l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㭫"): settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭬"),l1l111_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㭭"))
	elif l1ll11ll1l_l1_==l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㭮"): settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㭯"),l1l111_l1_ (u"ࠬ࠭㭰"))
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㭱")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㭲"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㭳"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㭴")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㭵"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㭶"))
	if settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ㭷")) not in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㭸"),l1l111_l1_ (u"ࠧࡔࡖࡒࡔࠬ㭹"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㭺")]: settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ㭻"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㭼"))
	l11llllll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ㭽"))
	l11l11l1l1l_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ㭾"))
	if l1l111_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ㭿") in str(l11l11l1l1l_l1_) and l11llllll1l_l1_ in [l1l111_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ㮀"),l1l111_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ㮁")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭㮂"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111lll1l1_l1_,l11ll1lll11_l1_)
	return
def l1llll1llll_l1_(l1l1l1llll1_l1_,method,url,data,headers,source):
	if l1l1l1llll1_l1_:
		html = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㮃"),l1l111_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬ㮄"),(method,url,data,headers))
		if html:
			l1l1ll1111l_l1_(l1l111_l1_ (u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪ㮅"),url,data,headers,source,method)
			return html
	html = l1l111llll1_l1_(method,url,data,headers,source)
	if html and l1l1l1llll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ㮆"),(method,url,data,headers),html,l1l1l1llll1_l1_)
	return html
DIALOGg_OK = l1111l1_l1_
l1l11111lll_l1_ = l11ll1ll1l1_l1_
l11llll1l1l_l1_ = l1ll1llll111_l1_
DIALOGg_YESNO = l1ll1l1111_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l11l1111_l1_
DIALOGg_TEXTVIEWER = l1ll11l11l11_l1_
DIALOGg_CONTEXTMENU = l11ll11l1ll_l1_
l111l11l1ll_l1_ = l1l11111l1_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1l1lll11lll_l1_
l1ll1ll1111l_l1_ = l1l11ll111_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l1111l11_l1_
DOWNLOADd_USING_PROGRESSBAR = l1llll11llll_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l1l11l111_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11ll11_l1_
PERMANENT_CACHEe = l1ll111l1l1_l1_
from EXCLUDES import *
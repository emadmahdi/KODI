# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗࠬ䗓")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡌࡔࡖࡢࠫ䗔")
l1l1l11l1lll_l1_ = 4
l1l1l11l11ll_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll11l_l1_):
	try: l1l1l1111l11_l1_ = str(l1llllll11l_l1_[l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗕")])
	except: l1l1l1111l11_l1_ = l1l111_l1_ (u"ࠧࠨ䗖")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1l1l11ll1_l1_(text)
	elif mode==162: l1lll_l1_ = l1l11llll1l1_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l11llll1l1_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1l1l11l11_l1_(text)
	elif mode==165: l1lll_l1_ = l1l11ll1lll1_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1l11lll11_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l11ll1ll1l_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l11ll111l1_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1l1l1111l_l1_()
	elif mode==762: l1lll_l1_ = l1l1l111l11l_l1_()
	elif mode==763: l1lll_l1_ = l1l1l1111lll_l1_(l1l1l1111l11_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1l11l1l1l_l1_(l1l1l1111l11_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1l11lllll_l1_(l1l1l1111l11_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗗"),l1l111_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪ䗘"),l1l111_l1_ (u"ࠪࠫ䗙"),161,l1l111_l1_ (u"ࠫࠬ䗚"),l1l111_l1_ (u"ࠬ࠭䗛"),l1l111_l1_ (u"࠭࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗜"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗝"),l1l111_l1_ (u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬ䗞"),l1l111_l1_ (u"ࠩࠪ䗟"),162,l1l111_l1_ (u"ࠪࠫ䗠"),l1l111_l1_ (u"ࠫࠬ䗡"),l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䗢"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗣"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋หࠪ䗤"),l1l111_l1_ (u"ࠨࠩ䗥"),163,l1l111_l1_ (u"ࠩࠪ䗦"),l1l111_l1_ (u"ࠪࠫ䗧"),l1l111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䗨"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗩"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡสะฯࠥ฿ิ้ษษ๎ࠬ䗪"),l1l111_l1_ (u"ࠧࠨ䗫"),164,l1l111_l1_ (u"ࠨࠩ䗬"),l1l111_l1_ (u"ࠩࠪ䗭"),l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䗮"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗯"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ䗰"),l1l111_l1_ (u"࠭ࠧ䗱"),763,l1l111_l1_ (u"ࠧࠨ䗲"),l1l111_l1_ (u"ࠨࠩ䗳"),l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫ䗴"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䗵"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䗶"),l1l111_l1_ (u"ࠬ࠭䗷"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗸"),l1l111_l1_ (u"ࠧใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ䗹"),l1l111_l1_ (u"ࠨࠩ䗺"),163,l1l111_l1_ (u"ࠩࠪ䗻"),l1l111_l1_ (u"ࠪࠫ䗼"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗽"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗾"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮ࠭䗿"),l1l111_l1_ (u"ࠧࠨ䘀"),163,l1l111_l1_ (u"ࠨࠩ䘁"),l1l111_l1_ (u"ࠩࠪ䘂"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘃"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘄"),l1l111_l1_ (u"่ࠬำๆࠢๅ๊ํอสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬ䘅"),l1l111_l1_ (u"࠭ࠧ䘆"),162,l1l111_l1_ (u"ࠧࠨ䘇"),l1l111_l1_ (u"ࠨࠩ䘈"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘉"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘊"),l1l111_l1_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ䘋"),l1l111_l1_ (u"ࠬ࠭䘌"),162,l1l111_l1_ (u"࠭ࠧ䘍"),l1l111_l1_ (u"ࠧࠨ䘎"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘏"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘐"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭䘑"),l1l111_l1_ (u"ࠫࠬ䘒"),164,l1l111_l1_ (u"ࠬ࠭䘓"),l1l111_l1_ (u"࠭ࠧ䘔"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘕"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘖"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ䘗"),l1l111_l1_ (u"ࠪࠫ䘘"),765,l1l111_l1_ (u"ࠫࠬ䘙"),l1l111_l1_ (u"ࠬ࠭䘚"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘛"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䘜"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䘝"),l1l111_l1_ (u"ࠩࠪ䘞"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘟"),l1l111_l1_ (u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩ䘠"),l1l111_l1_ (u"ࠬ࠭䘡"),163,l1l111_l1_ (u"࠭ࠧ䘢"),l1l111_l1_ (u"ࠧࠨ䘣"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘤"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘥"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫ䘦"),l1l111_l1_ (u"ࠫࠬ䘧"),163,l1l111_l1_ (u"ࠬ࠭䘨"),l1l111_l1_ (u"࠭ࠧ䘩"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘪"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘫"),l1l111_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪ䘬"),l1l111_l1_ (u"ࠪࠫ䘭"),162,l1l111_l1_ (u"ࠫࠬ䘮"),l1l111_l1_ (u"ࠬ࠭䘯"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘰"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘱"),l1l111_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ䘲"),l1l111_l1_ (u"ࠩࠪ䘳"),162,l1l111_l1_ (u"ࠪࠫ䘴"),l1l111_l1_ (u"ࠫࠬ䘵"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘶"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘷"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠠษฯฮࠤ฾ฺ่ศศํࠫ䘸"),l1l111_l1_ (u"ࠨࠩ䘹"),164,l1l111_l1_ (u"ࠩࠪ䘺"),l1l111_l1_ (u"ࠪࠫ䘻"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘼"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘽"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ䘾"),l1l111_l1_ (u"ࠧࠨ䘿"),764,l1l111_l1_ (u"ࠨࠩ䙀"),l1l111_l1_ (u"ࠩࠪ䙁"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䙂"))
	return
def l1l1l1l1111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙃"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖࡢࠫ䙄")+l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡉࡑࡖ࡙ࠫ䙅"),l1l111_l1_ (u"ࠧࠨ䙆"),764)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䙇"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䙈"),l1l111_l1_ (u"ࠪࠫ䙉"),9999)
	for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡏࡐࠨ䙊")+str(l1l1l1111l11_l1_)+l1l111_l1_ (u"ࠬࡥࠧ䙋")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙌"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ䙍")+NUMBERS_SEQ_NAME[l1l1l1111l11_l1_],l1l111_l1_ (u"ࠨࠩ䙎"),764,l1l111_l1_ (u"ࠩࠪ䙏"),l1l111_l1_ (u"ࠪࠫ䙐"),l1l111_l1_ (u"ࠫࠬ䙑"),l1l111_l1_ (u"ࠬ࠭䙒"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙓"):l1l1l1111l11_l1_})
	return
def l1l1l111l11l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䙔"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䙕")+l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡐ࠷࡚࠭䙖"),l1l111_l1_ (u"ࠪࠫ䙗"),765)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䙘"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䙙"),l1l111_l1_ (u"࠭ࠧ䙚"),9999)
	for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡏࡘࠫ䙛")+str(l1l1l1111l11_l1_)+l1l111_l1_ (u"ࠨࡡࠪ䙜")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙝"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬ䙞")+NUMBERS_SEQ_NAME[l1l1l1111l11_l1_],l1l111_l1_ (u"ࠫࠬ䙟"),765,l1l111_l1_ (u"ࠬ࠭䙠"),l1l111_l1_ (u"࠭ࠧ䙡"),l1l111_l1_ (u"ࠧࠨ䙢"),l1l111_l1_ (u"ࠨࠩ䙣"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙤"):l1l1l1111l11_l1_})
	return
def l1l1l1l11111_l1_(l1lll11l1ll_l1_):
	l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
	try:
		if l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ䙥") in l1lll11l1ll_l1_: l1lll1111l1_l1_(l1lll11l1ll_l1_)
		else: l1lll1111l1_l1_()
		l1l1l111l111_l1_ = False
	except: l1l1l111l111_l1_ = True
	l1lll11l1ll_l1_ = TRANSLATE(l1lll11l1ll_l1_)
	if l1l1l111l111_l1_: l1ll1lll_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"ࠫๆฺไࠡส๊ิฬࠦวๅ็๋ๆ฾࠭䙦"),time=2000)
	else: l1ll1lll_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"ࠬะๅࠡฮ็ฬࠥอไฤไึห๊࠭䙧"),time=2000)
	return l1l1l111l111_l1_
def l1l1l11111l1_l1_(l1l1l111l1l1_l1_=True):
	if not l1l1l111l1l1_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ䙨"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ䙩"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭䙪"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䙫"),l1l111_l1_ (u"ࠪࠫ䙬"),l1l111_l1_ (u"ࠫࠬ䙭"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䙮"),l1l111_l1_ (u"࠭ไไ์ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮ࠡษ็ฬึ์วๆฮࠣ๎าะวอࠢฦ๊ࠥ๐แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳ูࠦๆๆํอ๋ࠥไวࠢฯ้๏฿ࠠศๆฦๆุอๅࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪ䙯"))
	if l1llll1l11_l1_!=1: return
	l1l11ll11lll_l1_ = menuItemsLIST
	l1l1l1111111_l1_,l1l11llllll1_l1_ = 0,l1l111_l1_ (u"ࠧࠨ䙰")
	for l1lll11l1ll_l1_ in l1l111l1l11_l1_:
		time.sleep(0.5)
		l1l1l111l111_l1_ = l1l1l1l11111_l1_(l1lll11l1ll_l1_)
		if l1l1l111l111_l1_:
			l1l1l1111111_l1_ += 1
			l1l11llllll1_l1_ += l1l111_l1_ (u"ࠨࠢࠪ䙱")+l1lll11l1ll_l1_
			if l1l1l1111111_l1_>=l1l1l11l11ll_l1_: break
	menuItemsLIST[:] = l1l11ll11lll_l1_
	if l1l1l1111111_l1_>=l1l1l11l11ll_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䙲"),l1l111_l1_ (u"ࠪࠫ䙳"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䙴"),l1l111_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไสࠢไ๎ࠥ࠭䙵")+str(l1l1l1111111_l1_)+l1l111_l1_ (u"࠭ࠠๆ๊สๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้ࠠีหฬ์อࠠใัࠣ๎่๎ๆࠡ฻า้ࠥ๎ฬ้ัࠣษ๋ะั็์อࠤๆ๐ࠠอ้สึ่่่ࠦ์࠽ࠫ䙶")+l1l11llllll1_l1_)
	else:
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ䙷"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭䙸"),contentsDICT,l1ll111l1l1_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䙹"),l1l111_l1_ (u"ࠪࠫ䙺"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䙻"),l1l111_l1_ (u"ࠬะๅࠡฮ็ฬࠥาๅ๋฻ࠣห้ษโิษ่ࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่อืๆศ็ฯࠫ䙼"))
	return
def l1l11lll1lll_l1_(l1l1l1111l11_l1_,options):
	l1l1lll11ll_l1_ = False
	l1l11ll111ll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1lll11ll_l1_ and l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䙽") not in options:
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䙾"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䙿"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䚀")+l1l1l1111l11_l1_)
	elif l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䚁") not in options or l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䚂") not in options:
		import IPTV
		message = l1l111_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ䚃")
		if l1l111_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭䚄") not in options:
			try: IPTV.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚅"),l1l111_l1_ (u"ࠨࠩ䚆"),l1l111_l1_ (u"ࠩࠪ䚇"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚈"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚉"),l1l111_l1_ (u"ࠬ࠭䚊"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ䚋"),message)
			try: IPTV.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚌"),l1l111_l1_ (u"ࠨࠩ䚍"),l1l111_l1_ (u"ࠩࠪ䚎"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚏"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚐"),l1l111_l1_ (u"ࠬ࠭䚑"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ䚒"),message)
			try: IPTV.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚓"),l1l111_l1_ (u"ࠨࠩ䚔"),l1l111_l1_ (u"ࠩࠪ䚕"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚖"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚗"),l1l111_l1_ (u"ࠬ࠭䚘"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ䚙"),message)
		if l1l111_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䚚") not in options:
			try: IPTV.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䚛"),l1l111_l1_ (u"ࠩࠪ䚜"),l1l111_l1_ (u"ࠪࠫ䚝"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚞"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚟"),l1l111_l1_ (u"࠭ࠧ䚠"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䚡"),message)
			try: IPTV.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚢"),l1l111_l1_ (u"ࠩࠪ䚣"),l1l111_l1_ (u"ࠪࠫ䚤"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚥"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚦"),l1l111_l1_ (u"࠭ࠧ䚧"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䚨"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䚩"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䚪")+l1l1l1111l11_l1_,l1lll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111ll_l1_
	return l1lll_l1_
def l1l1l1111ll1_l1_(l1l1l1111l11_l1_,options):
	l1l1lll11ll_l1_ = False
	l1l11ll111ll_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1lll11ll_l1_ and l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䚫") not in options:
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䚬"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ䚭"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䚮")+l1l1l1111l11_l1_)
	elif l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䚯") not in options or l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䚰") not in options:
		import M3U
		message = l1l111_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ䚱")
		if l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䚲") not in options:
			try: M3U.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䚳"),l1l111_l1_ (u"ࠬ࠭䚴"),l1l111_l1_ (u"࠭ࠧ䚵"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䚶"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䚷"),l1l111_l1_ (u"ࠩࠪ䚸"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ䚹"),message)
			try: M3U.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚺"),l1l111_l1_ (u"ࠬ࠭䚻"),l1l111_l1_ (u"࠭ࠧ䚼"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䚽"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䚾"),l1l111_l1_ (u"ࠩࠪ䚿"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ䛀"),message)
			try: M3U.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䛁"),l1l111_l1_ (u"ࠬ࠭䛂"),l1l111_l1_ (u"࠭ࠧ䛃"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛄"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䛅"),l1l111_l1_ (u"ࠩࠪ䛆"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ䛇"),message)
		if l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䛈") not in options:
			try: M3U.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䛉"),l1l111_l1_ (u"࠭ࠧ䛊"),l1l111_l1_ (u"ࠧࠨ䛋"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䛌"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䛍"),l1l111_l1_ (u"ࠪࠫ䛎"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䛏"),message)
			try: M3U.GROUPS(l1l1l1111l11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䛐"),l1l111_l1_ (u"࠭ࠧ䛑"),l1l111_l1_ (u"ࠧࠨ䛒"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䛓"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䛔"),l1l111_l1_ (u"ࠪࠫ䛕"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䛖"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ䛗"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䛘")+l1l1l1111l11_l1_,l1lll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111ll_l1_
	return l1lll_l1_
def l1l1l1111lll_l1_(l1l1l1111l11_l1_,options,l1l11lll1111_l1_):
	if l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䛙") in options and l1l11lll1111_l1_==l1l111_l1_ (u"ࠨࠩ䛚"): l1l1l11111l1_l1_(True)
	elif l1l11lll1111_l1_: l1l1l11111l1_l1_(False)
	l1l11lll11ll_l1_ = options.replace(l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䛛"),l1l111_l1_ (u"ࠪࠫ䛜")).replace(l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䛝"),l1l111_l1_ (u"ࠬ࠭䛞")).replace(l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䛟"),l1l111_l1_ (u"ࠧࠨ䛠"))
	if not l1l11lll1111_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䛡"),l1l111_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭䛢"),l1l111_l1_ (u"ࠪࠫ䛣"),763,l1l111_l1_ (u"ࠫࠬ䛤"),l1l111_l1_ (u"ࠬ࠭䛥"),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䛦")+l1l11lll11ll_l1_,l1l111_l1_ (u"ࠧࠨ䛧"),{l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䛨"):l1l1l1111l11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䛩"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䛪"),l1l111_l1_ (u"ࠫࠬ䛫"),9999)
	l1llllllll_l1_ = [l1l111_l1_ (u"ࠬษแๅษ่ࠫ䛬"),l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠧ䛭"),l1l111_l1_ (u"ࠧๆีิั๏อสࠨ䛮"),l1l111_l1_ (u"ࠨสิห๊าࠧ䛯"),l1l111_l1_ (u"ࠩฦ฻ๆอไ๊ࠡๆีฯ๎ๆࠨ䛰"),l1l111_l1_ (u"ࠪี๊฼ว็ࠩ䛱"),l1l111_l1_ (u"ࠫศำฯฬ࠯ฦาึ࠭䛲"),l1l111_l1_ (u"ูࠬไศี็ࠫ䛳"),l1l111_l1_ (u"࠭ๅ้ีํๆ๎࠭䛴"),l1l111_l1_ (u"ࠧฤึ๊ี࠲ษใฬำࠪ䛵"),l1l111_l1_ (u"ࠨษ็ฦ๋࠭䛶"),l1l111_l1_ (u"ูࠩั่࠭䛷"),l1l111_l1_ (u"ࠪี๏อึสࠩ䛸"),l1l111_l1_ (u"๋ࠫ๐สโๆๆืࠬ䛹"),l1l111_l1_ (u"๋ࠬๅฬๆํ๊ࠬ䛺"),l1l111_l1_ (u"࠭ศฬࠢะ๎ࠬ䛻"),l1l111_l1_ (u"ࠧะ์้๎ฮ࠭䛼"),l1l111_l1_ (u"ࠨี้์ฬะࠧ䛽"),l1l111_l1_ (u"ࠩฦาึ๏ࠧ䛾")]
	l1l11ll1l111_l1_ = [l1l111_l1_ (u"ࠪหๆ๊วๆࠩ䛿"),l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ䜀"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ䜁"),l1l111_l1_ (u"࠭แๅ็ࠪ䜂")]
	l1ll11lll1l_l1_ = [l1l111_l1_ (u"ࠧๆี็ื้࠭䜃"),l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䜄")]
	l1l1l1l11l1l_l1_ = [l1l111_l1_ (u"่ࠩืฬือࠨ䜅"),l1l111_l1_ (u"ุ้ࠪือ๋ษอࠫ䜆")]
	l1l11lll11l1_l1_ = [l1l111_l1_ (u"ࠫอืวๆฮࠪ䜇"),l1l111_l1_ (u"ࠬࡹࡨࡰࡹࠪ䜈"),l1l111_l1_ (u"࠭สๅใี๎ํ์ࠧ䜉"),l1l111_l1_ (u"ࠧหๆํๅื๐่็ࠩ䜊")]
	l1l1l11l111l_l1_ = [l1l111_l1_ (u"ࠨษ้้๏࠭䜋"),l1l111_l1_ (u"ࠩๆีฯ๎ๆࠨ䜌"),l1l111_l1_ (u"ࠪ็ฬืส้่ࠪ䜍"),l1l111_l1_ (u"ࠫࡰ࡯ࡤࡴࠩ䜎"),l1l111_l1_ (u"ࠬ฽แๅࠩ䜏"),l1l111_l1_ (u"࠭วุใส่ࠬ䜐")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠧา็ูห๋࠭䜑")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠨษะำะ࠭䜒"),l1l111_l1_ (u"ࠩสาึ࠭䜓"),l1l111_l1_ (u"้ࠪํิัࠨ䜔"),l1l111_l1_ (u"ࠫัี๊ะࠩ䜕"),l1l111_l1_ (u"๋ࠬึศใࠪ䜖"),l1l111_l1_ (u"࠭อะ์ฮࠫ䜗")]
	l1l11llll111_l1_ = [l1l111_l1_ (u"ࠧิๆสื้࠭䜘"),l1l111_l1_ (u"ࠨี็ื้ํࠧ䜙")]
	l1l11ll1111l_l1_ = [l1l111_l1_ (u"ࠩส฾ฬ์๊ࠨ䜚"),l1l111_l1_ (u"้ࠪํู๊ใ๋ࠪ䜛"),l1l111_l1_ (u"่๊๊ࠫษࠩ䜜"),l1l111_l1_ (u"ࠬำแๅࠩ䜝"),l1l111_l1_ (u"࠭࡭ࡶࡵ࡬ࡧࠬ䜞")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠧศๅฮีࠬ䜟"),l1l111_l1_ (u"ࠨษื๋ึ࠭䜠"),l1l111_l1_ (u"่้ࠩ๏ุ็ࠨ䜡"),l1l111_l1_ (u"ࠪห฾๊้ࠨ䜢"),l1l111_l1_ (u"๊ࠫิสศำ๊ࠫ䜣"),l1l111_l1_ (u"๋ࠬฮหษิหฯ࠭䜤"),l1l111_l1_ (u"࠭วใ๊์ࠫ䜥")]
	l1l11ll11111_l1_ = [l1l111_l1_ (u"ࠧศๆส๊ࠬ䜦"),l1l111_l1_ (u"ࠨฯส่๏࠭䜧"),l1l111_l1_ (u"่ࠩฯอะࠧ䜨"),l1l111_l1_ (u"ࠪีฬฬฬࠨ䜩")]
	l1l11ll11l11_l1_ = [l1l111_l1_ (u"ࠫ฻ำใࠨ䜪"),l1l111_l1_ (u"้่ࠬๆ์า๎ࠬ䜫")]
	l1l1l11ll1ll_l1_ = [l1l111_l1_ (u"࠭ั๋ษู๋ࠬ䜬"),l1l111_l1_ (u"ࠧไ๊ิ๋ࠬ䜭"),l1l111_l1_ (u"ࠨ็ุหึ฿็ࠨ䜮"),l1l111_l1_ (u"ࠩื์ฯ࠭䜯"),l1l111_l1_ (u"ࠪี๏อึสࠩ䜰")]
	l1l1l111ll11_l1_ = [l1l111_l1_ (u"๋ࠫ๐สโๆๆืࠬ䜱"),l1l111_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭䜲"),l1l111_l1_ (u"࠭ๆ๋ฬไ่๏้ำࠨ䜳")]
	l1l11ll11ll1_l1_ = [l1l111_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䜴"),l1l111_l1_ (u"ࠨษืาฬ฻ࠧ䜵"),l1l111_l1_ (u"้ࠩะํ๋ࠧ䜶")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠪฬะࠦอ๋ࠩ䜷"),l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䜸"),l1l111_l1_ (u"่ࠬๆศ้ࠪ䜹"),l1l111_l1_ (u"࠭โ็๊สฮࠬ䜺")]
	l1l1l111llll_l1_ = [l1l111_l1_ (u"ࠧะ์้ࠫ䜻"),l1l111_l1_ (u"ࠨษา฽๏ํࠧ䜼"),l1l111_l1_ (u"ࠩี๎ฬืวหࠩ䜽"),l1l111_l1_ (u"่ࠪ฼๋๊ศฬࠪ䜾"),l1l111_l1_ (u"ࠫิ฿วยࠩ䜿"),l1l111_l1_ (u"่ࠬัศ่ࠪ䝀"),l1l111_l1_ (u"࠭โึษษำࠬ䝁"),l1l111_l1_ (u"ࠧาอสลࠬ䝂"),l1l111_l1_ (u"ࠨ็ิะ฾๐็ࠨ䝃"),l1l111_l1_ (u"ࠩสิฬ์ࠧ䝄"),l1l111_l1_ (u"ࠪหุ๊วๆࠩ䝅"),l1l111_l1_ (u"ࠫฯ๎วี์ะࠫ䝆"),l1l111_l1_ (u"ࠬิืษࠩ䝇"),l1l111_l1_ (u"࠭อ้ิ๋๎ࠬ䝈"),l1l111_l1_ (u"ฺࠧฬหหฯ࠭䝉"),l1l111_l1_ (u"ࠨ็๋ห้๐ฯࠨ䝊"),l1l111_l1_ (u"้ࠩ์ฬ฿๊ࠨ䝋"),l1l111_l1_ (u"ࠪ฽็อฦะࠩ䝌"),l1l111_l1_ (u"ࠫฬ์วี์าࠫ䝍")]
	l1l11ll1l11l_l1_ = [l1l111_l1_ (u"ࠬ࠷࠹ࠨ䝎"),l1l111_l1_ (u"࠭࠲࠱ࠩ䝏"),l1l111_l1_ (u"ࠧ࠳࠳ࠪ䝐"),l1l111_l1_ (u"ࠨ࠴࠵ࠫ䝑"),l1l111_l1_ (u"ࠩ࠵࠷ࠬ䝒"),l1l111_l1_ (u"ࠪ࠶࠹࠭䝓"),l1l111_l1_ (u"ࠫ࠷࠻ࠧ䝔"),l1l111_l1_ (u"ࠬ࠸࠶ࠨ䝕")]
	if not l1l11lll1111_l1_:
		l1l11lll1111_l1_ = 0
		for l1l1l11111ll_l1_ in l1llllllll_l1_:
			l1l11lll1111_l1_ += 1
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝖"),l1lllll_l1_+l1l1l11111ll_l1_,l1l111_l1_ (u"ࠧࠨ䝗"),763,l1l111_l1_ (u"ࠨࠩ䝘"),str(l1l11lll1111_l1_),l1l11lll11ll_l1_,l1l111_l1_ (u"ࠩࠪ䝙"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝚"):l1l1l1111l11_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1lllllllll_l1_ = name.lower()
			category = []
			if any(value in l1lllllllll_l1_ for value in l1l11ll1l111_l1_): category.append(1)
			if any(value in l1lllllllll_l1_ for value in l1ll11lll1l_l1_): category.append(2)
			if any(value in l1lllllllll_l1_ for value in l1l1l1l11l1l_l1_): category.append(3)
			if any(value in l1lllllllll_l1_ for value in l1l11lll11l1_l1_): category.append(4)
			if any(value in l1lllllllll_l1_ for value in l1l1l11l111l_l1_): category.append(5)
			if any(value in l1lllllllll_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l1lllllllll_l1_ for value in l1lllll1l_l1_) and l1lllllllll_l1_ not in [l1l111_l1_ (u"ࠫฬิั๊ࠩ䝛")]: category.append(7)
			if any(value in l1lllllllll_l1_ for value in l1l11llll111_l1_): category.append(8)
			if any(value in l1lllllllll_l1_ for value in l1l11ll1111l_l1_): category.append(9)
			if any(value in l1lllllllll_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l1lllllllll_l1_ for value in l1l11ll11111_l1_): category.append(11)
			if any(value in l1lllllllll_l1_ for value in l1l11ll11l11_l1_): category.append(12)
			if any(value in l1lllllllll_l1_ for value in l1l1l11ll1ll_l1_): category.append(13)
			if any(value in l1lllllllll_l1_ for value in l1l1l111ll11_l1_): category.append(14)
			if any(value in l1lllllllll_l1_ for value in l1l11ll11ll1_l1_): category.append(15)
			if any(value in l1lllllllll_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l1lllllllll_l1_ for value in l1l1l111llll_l1_): category.append(17)
			if any(value in l1lllllllll_l1_ for value in l1l11ll1l11l_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l11lll1111_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䝜"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"࠭ࠧ䝝"),l1l111_l1_ (u"ࠧࠨ䝞"),l1l11lll11ll_l1_+l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䝟"))
	return
def l1l1l11l1l1l_l1_(l1l1l1111l11_l1_,options):
	l1l1lll11ll_l1_ = False
	if l1l1lll11ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䝠"),l1l111_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ䝡"),l1l111_l1_ (u"ࠫࠬ䝢"),764,l1l111_l1_ (u"ࠬ࠭䝣"),l1l111_l1_ (u"࠭ࠧ䝤"),l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䝥"),l1l111_l1_ (u"ࠨࠩ䝦"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝧"):l1l1l1111l11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䝨"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䝩"),l1l111_l1_ (u"ࠬ࠭䝪"),9999)
	l1l11ll111ll_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l1l1111l11_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l1l1111l11_l1_,True): return
		l1l11llll11l_l1_ = l1l11lll1lll_l1_(l1l1l1111l11_l1_,options)
		l111l1l1ll_l1_ = sorted(l1l11llll11l_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䝫"),True): return
		if l1l1lll11ll_l1_ and l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䝬") not in options:
			l111l1l1ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䝭"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ䝮"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࡅࡑࡒࠧ䝯"))
		else:
			l1l11ll1l1l1_l1_,l111l1l1ll_l1_,l1l11llll11l_l1_ = [],[],[]
			for l1l1l111111l_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l1ll_l1_ += l1l11lll1lll_l1_(str(l1l1l111111l_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l111l1l1ll_l1_:
				if text not in l1l11ll1l1l1_l1_:
					l1l11ll1l1l1_l1_.append(text)
					l1l1l11lll1l_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll11l_l1_
					l1l11llll11l_l1_.append(l1l1l11lll1l_l1_)
			l111l1l1ll_l1_ = sorted(l1l11llll11l_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ䝰"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤࡇࡌࡍࠩ䝱"),l111l1l1ll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111ll_l1_+l111l1l1ll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䝲"))
	return
def l1l1l11lllll_l1_(l1l1l1111l11_l1_,options):
	l1l1lll11ll_l1_ = False
	if l1l1lll11ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䝳"),l1l111_l1_ (u"ࠨฬะำ๏ั่ࠠา๊ࠤฬ๊โศศ่อࠬ䝴"),l1l111_l1_ (u"ࠩࠪ䝵"),765,l1l111_l1_ (u"ࠪࠫ䝶"),l1l111_l1_ (u"ࠫࠬ䝷"),l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䝸"),l1l111_l1_ (u"࠭ࠧ䝹"),{l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝺"):l1l1l1111l11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䝻"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䝼"),l1l111_l1_ (u"ࠪࠫ䝽"),9999)
	l1l11ll111ll_l1_ = menuItemsLIST[:]
	import M3U
	if l1l1l1111l11_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l1l1111l11_l1_,True): return
		l1l11llll11l_l1_ = l1l1l1111ll1_l1_(l1l1l1111l11_l1_,options)
		l111l1l1ll_l1_ = sorted(l1l11llll11l_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠫࠬ䝾"),True): return
		if l1l1lll11ll_l1_ and l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䝿") not in options:
			l111l1l1ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䞀"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭䞁"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࡂࡎࡏࠫ䞂"))
		else:
			l1l11ll1l1l1_l1_,l111l1l1ll_l1_,l1l11llll11l_l1_ = [],[],[]
			for l1l1l111111l_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l1ll_l1_ += l1l1l1111ll1_l1_(str(l1l1l111111l_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l111l1l1ll_l1_:
				if text not in l1l11ll1l1l1_l1_:
					l1l11ll1l1l1_l1_.append(text)
					l1l1l11lll1l_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll11l_l1_
					l1l11llll11l_l1_.append(l1l1l11lll1l_l1_)
			l111l1l1ll_l1_ = sorted(l1l11llll11l_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䞃"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࡄࡐࡑ࠭䞄"),l111l1l1ll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l11ll111ll_l1_+l111l1l1ll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䞅"))
	return
def l1l11ll1lll1_l1_(group,options):
	l1l1lll11ll_l1_ = False
	l1lll_l1_ = []
	l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䞆") if l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ䞇") in options else l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䞈")
	if l1l1lll11ll_l1_: l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䞉"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫ䞊")+l1l1l1111l1l_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
			if l1l1lll11ll_l1_: l1lll_l1_ += l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䞋"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭䞌")+l1l1l1111l1l_l1_[:-1],l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ䞍")+l1l1l1111l1l_l1_+str(l1l1l1111l11_l1_))
			elif l1l1l1111l1l_l1_==l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䞎"): l1lll_l1_ += l1l11lll1lll_l1_(str(l1l1l1111l11_l1_),l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䞏"))
			elif l1l1l1111l1l_l1_==l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䞐"): l1lll_l1_ += l1l1l1111ll1_l1_(str(l1l1l1111l11_l1_),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䞑"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in l1lll_l1_:
			if text==group: l1ll1l11l1l1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in menuItemsLIST:
			l1l1l111lll1_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠪࠫ䞒")
			if l1l1l111lll1_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1l111lll1_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l1l1lll11ll_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭䞓")+l1l1l1111l1l_l1_[:-1],group,l1lll_l1_,l1ll111l1l1_l1_)
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䞔") in options and len(l1lll_l1_)>l1l1l11l1lll_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䞕"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䞖")+group+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䞗"),group,165,l1l111_l1_ (u"ࠩࠪ䞘"),l1l111_l1_ (u"ࠪࠫ䞙"),l1l1l1111l1l_l1_+l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䞚"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䞛"),l1l111_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䞜"),group,165,l1l111_l1_ (u"ࠧࠨ䞝"),l1l111_l1_ (u"ࠨࠩ䞞"),l1l1l1111l1l_l1_+l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䞟"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䞠"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䞡"),l1l111_l1_ (u"ࠬ࠭䞢"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1l11l1lll_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䞣"))
	return
def l1l1l1l11ll1_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䞤"),l1l111_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫ䞥"),l1l111_l1_ (u"ࠩࠪ䞦"),161,l1l111_l1_ (u"ࠪࠫ䞧"),l1l111_l1_ (u"ࠫࠬ䞨"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ䞩"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䞪"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䞫"),l1l111_l1_ (u"ࠨࠩ䞬"),9999)
	l1l1l11l1l11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1lll1lllll1_l1_
	l1lll1lllll1_l1_.ITEMS(l1l111_l1_ (u"ࠩ࠳ࠫ䞭"),False)
	l1lll1lllll1_l1_.ITEMS(l1l111_l1_ (u"ࠪ࠵ࠬ䞮"),False)
	l1lll1lllll1_l1_.ITEMS(l1l111_l1_ (u"ࠫ࠷࠭䞯"),False)
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䞰") in options:
		menuItemsLIST[:] = l1l11lllll1l_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1l11l1lll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11l1lll_l1_)
	menuItemsLIST[:] = l1l1l11l1l11_l1_+menuItemsLIST
	return
def l1l1l1l11l11_l1_(options):
	options = options.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䞱"),l1l111_l1_ (u"ࠧࠨ䞲")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞳"),l1l111_l1_ (u"ࠩࠪ䞴"))
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䞵") : l1l111_l1_ (u"ࠫࠬ䞶") }
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫ䞷")
	data = {l1l111_l1_ (u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨ䞸"):l1l111_l1_ (u"ࠧ࠶࠲ࠪ䞹")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1lll11llll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䞺"),url,data,headers,l1l111_l1_ (u"ࠩࠪ䞻"),l1l111_l1_ (u"ࠪࠫ䞼"),l1l111_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭䞽"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧ䞾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ䞿"),block,re.DOTALL)
	l1l11l1llll1_l1_,l1l11ll1l1ll_l1_ = list(zip(*items))
	l1l1l11llll1_l1_ = []
	l1l1l1l111ll_l1_ = [l1l111_l1_ (u"ࠧࠡࠩ䟀"),l1l111_l1_ (u"ࠨࠤࠪ䟁"),l1l111_l1_ (u"ࠩࡣࠫ䟂"),l1l111_l1_ (u"ࠪ࠰ࠬ䟃"),l1l111_l1_ (u"ࠫ࠳࠭䟄"),l1l111_l1_ (u"ࠬࡀࠧ䟅"),l1l111_l1_ (u"࠭࠻ࠨ䟆"),l1l111_l1_ (u"ࠢࠨࠤ䟇"),l1l111_l1_ (u"ࠨ࠯ࠪ䟈")]
	l1l11lll1l11_l1_ = l1l11ll1l1ll_l1_+l1l11l1llll1_l1_
	for word in l1l11lll1l11_l1_:
		if word in l1l11ll1l1ll_l1_: l1l1l111l1ll_l1_ = 2
		if word in l1l11l1llll1_l1_: l1l1l111l1ll_l1_ = 4
		l1l11lll1ll1_l1_ = [i in word for i in l1l1l1l111ll_l1_]
		if any(l1l11lll1ll1_l1_):
			index = l1l11lll1ll1_l1_.index(True)
			l1l11lll111l_l1_ = l1l1l1l111ll_l1_[index]
			l1l1l11ll11l_l1_ = l1l111_l1_ (u"ࠩࠪ䟉")
			if word.count(l1l11lll111l_l1_)>1: l1l1l11ll1l1_l1_,l1l1l11ll111_l1_,l1l1l11ll11l_l1_ = word.split(l1l11lll111l_l1_,2)
			else: l1l1l11ll1l1_l1_,l1l1l11ll111_l1_ = word.split(l1l11lll111l_l1_,1)
			if len(l1l1l11ll1l1_l1_)>l1l1l111l1ll_l1_: l1l1l11llll1_l1_.append(l1l1l11ll1l1_l1_.lower())
			if len(l1l1l11ll111_l1_)>l1l1l111l1ll_l1_: l1l1l11llll1_l1_.append(l1l1l11ll111_l1_.lower())
			if len(l1l1l11ll11l_l1_)>l1l1l111l1ll_l1_: l1l1l11llll1_l1_.append(l1l1l11ll11l_l1_.lower())
		elif len(word)>l1l1l111l1ll_l1_: l1l1l11llll1_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1l11llll1_l1_)
	if l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䟊") in options:
		l1l11ll11l1l_l1_ = l1ll1ll1l1l1_l1_
	elif l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䟋") in options:
		l1l11ll11l1l_l1_ = [l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ䟌")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䟍"),True): return
	elif l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䟎") in options:
		l1l11ll11l1l_l1_ = [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ䟏")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠩࠪ䟐"),True): return
	count,l1l11ll1ll11_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䟑"),l1l111_l1_ (u"ࠫࡠࠦࠠ࡞ࠢ࠽ห้ฮอฬࠢ฼๊ࠬ䟒"),l1l111_l1_ (u"ࠬ࠭䟓"),164,l1l111_l1_ (u"࠭ࠧ䟔"),l1l111_l1_ (u"ࠧࠨ䟕"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䟖")+options)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟗"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪ䟘"),l1l111_l1_ (u"ࠫࠬ䟙"),164,l1l111_l1_ (u"ࠬ࠭䟚"),l1l111_l1_ (u"࠭ࠧ䟛"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟜")+options)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䟝"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䟞"),l1l111_l1_ (u"ࠪࠫ䟟"),9999)
	l1l11l1lll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1l1l111l1_l1_ = []
	for word in l1l1l11llll1_l1_:
		l1l1l11ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡠࠦ࡜࠭࡞࠾ࡠ࠿ࡢ࠭࡝࠭࡟ࡁࡡࠨ࡜ࠨ࡞࡞ࡠࡢࡢࠨ࡝ࠫ࡟ࡿࡡࢃ࡜ࠢ࡞ࡃࠫ䟠")+l1l111_l1_ (u"ࠬࠩࠧ䟡")+l1l111_l1_ (u"࠭࡜ࠥ࡞ࠨࡠࡣࡢࠦ࡝ࠬ࡟ࡣࡡࡂ࡜࠿࡟ࠪ䟢"),word,re.DOTALL)
		if l1l1l11ll111_l1_: word = word.split(l1l1l11ll111_l1_[0],1)[0]
		l1l1l11l11l1_l1_ = word.replace(l1l111_l1_ (u"ࠧ๒ࠩ䟣"),l1l111_l1_ (u"ࠨࠩ䟤")).replace(l1l111_l1_ (u"ࠩ๑ࠫ䟥"),l1l111_l1_ (u"ࠪࠫ䟦")).replace(l1l111_l1_ (u"ࠫ๐࠭䟧"),l1l111_l1_ (u"ࠬ࠭䟨")).replace(l1l111_l1_ (u"࠭๏ࠨ䟩"),l1l111_l1_ (u"ࠧࠨ䟪")).replace(l1l111_l1_ (u"ࠨ๎ࠪ䟫"),l1l111_l1_ (u"ࠩࠪ䟬"))
		l1l1l11l11l1_l1_ = l1l1l11l11l1_l1_.replace(l1l111_l1_ (u"ࠪ๔ࠬ䟭"),l1l111_l1_ (u"ࠫࠬ䟮")).replace(l1l111_l1_ (u"ࠬ๓ࠧ䟯"),l1l111_l1_ (u"࠭ࠧ䟰")).replace(l1l111_l1_ (u"ࠧ๓ࠩ䟱"),l1l111_l1_ (u"ࠨࠩ䟲")).replace(l1l111_l1_ (u"ࠩฏࠫ䟳"),l1l111_l1_ (u"ࠪࠫ䟴")).replace(l1l111_l1_ (u"ࠫๅ࠭䟵"),l1l111_l1_ (u"ࠬ࠭䟶"))
		if l1l1l11l11l1_l1_: l1l1l1l111l1_l1_.append(l1l1l11l11l1_l1_)
	l1l1l11l1111_l1_ = []
	for l1l11l111l_l1_ in range(0,20):
		search = random.sample(l1l1l1l111l1_l1_,1)[0]
		if search in l1l1l11l1111_l1_: continue
		l1l1l11l1111_l1_.append(search)
		l1lll11l1ll_l1_ = random.sample(l1l11ll11l1l_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䟷"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪ䟸")+str(l1lll11l1ll_l1_)+l1l111_l1_ (u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫ䟹")+search)
		l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll1111l_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
		l1lll11l1l1_l1_(search+l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䟺"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䟻"),l1l111_l1_ (u"ࠫࠬ䟼"))
	l1l11l1lll1l_l1_[0][1] = l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䟽")+search+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼หัะูࠦ็࡟ࠪ䟾")
	menuItemsLIST[:] = l1l11lllll1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1l11l1lll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11l1lll_l1_)
	menuItemsLIST[:] = l1l11l1lll1l_l1_+menuItemsLIST
	return
def l1l1l11lll11_l1_(l1l11ll1llll_l1_,options):
	l1l11ll1llll_l1_ = l1l11ll1llll_l1_.replace(l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䟿"),l1l111_l1_ (u"ࠨࠩ䠀"))
	options = options.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠁"),l1l111_l1_ (u"ࠪࠫ䠂")).replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠃"),l1l111_l1_ (u"ࠬ࠭䠄"))
	l1l1l11111l1_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䠅") in options:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䠆"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䠇")+l1l11ll1llll_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䠈"),l1l11ll1llll_l1_,166,l1l111_l1_ (u"ࠪࠫ䠉"),l1l111_l1_ (u"ࠫࠬ䠊"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䠋")+options)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䠌"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䠍"),l1l11ll1llll_l1_,166,l1l111_l1_ (u"ࠨࠩ䠎"),l1l111_l1_ (u"ࠩࠪ䠏"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠐")+options)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䠑"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䠒"),l1l111_l1_ (u"࠭ࠧ䠓"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l11ll1llll_l1_].keys())):
		type,name,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = contentsDICT[l1l11ll1llll_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䠔") in options or len(contentsDICT[l1l11ll1llll_l1_])==1:
			l1ll1l11l1l1_l1_(type,l1l111_l1_ (u"ࠨࠩ䠕"),url,l1ll1ll1llll_l1_,l1l111_l1_ (u"ࠩࠪ䠖"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠪࠫ䠗"),l1l111_l1_ (u"ࠫࠬ䠘"))
			menuItemsLIST[:] = l1l11lllll1l_l1_(menuItemsLIST)
			l1l11ll111ll_l1_,l111l1l1ll_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1l1ll_l1_)
			if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䠙") in options: menuItemsLIST[:] = l1l11ll111ll_l1_+l111l1l1ll_l1_[:l1l1l11l1lll_l1_]
			else: menuItemsLIST[:] = l1l11ll111ll_l1_+l111l1l1ll_l1_
		elif l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䠚") in options: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䠛"),l1l11l11_l1_,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
	return
def l1l11llll1l1_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䠜"),l1l111_l1_ (u"ࠩࠪ䠝")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠞"),l1l111_l1_ (u"ࠫࠬ䠟"))
	name,l1l11lll1l1l_l1_ = l1l111_l1_ (u"ࠬ࠭䠠"),[]
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䠡"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䠢")+name+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䠣"),l1l111_l1_ (u"ࠩࠪ䠤"),mode,l1l111_l1_ (u"ࠪࠫ䠥"),l1l111_l1_ (u"ࠫࠬ䠦"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䠧")+options)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䠨"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦืๅสࠣๆฺุ๋ࠠึ๋หห๐ࠧ䠩"),l1l111_l1_ (u"ࠨࠩ䠪"),mode,l1l111_l1_ (u"ࠩࠪ䠫"),l1l111_l1_ (u"ࠪࠫ䠬"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠭")+options)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䠮"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䠯"),l1l111_l1_ (u"ࠧࠨ䠰"),9999)
	l1l11ll111ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ䠱") in options:
		l1l1l11111l1_l1_(False)
		if contentsDICT=={}: return
		l1l11lllll11_l1_ = list(contentsDICT.keys())
		l1l11ll1llll_l1_ = random.sample(l1l11lllll11_l1_,1)[0]
		l1l1l11llll1_l1_ = list(contentsDICT[l1l11ll1llll_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1l11llll1_l1_,1)[0]
		type,name,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = contentsDICT[l1l11ll1llll_l1_][l1l11l11_l1_]
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䠲"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡻࡪࡨࡳࡪࡶࡨ࠾ࠥ࠭䠳")+l1l11l11_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䠴")+name+l1l111_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䠵")+url+l1l111_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䠶")+str(l1ll1ll1llll_l1_))
	elif l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䠷") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䠸"),True): return
		for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l11lll1lll_l1_(str(l1l1l1111l11_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䠹"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䠺")+name+l1l111_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䠻")+url+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䠼")+str(l1ll1ll1llll_l1_))
	elif l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䠽") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠧࠨ䠾"),True): return
		for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1l1111ll1_l1_(str(l1l1l1111l11_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䠿"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ䡀")+name+l1l111_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䡁")+url+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䡂")+str(l1ll1ll1llll_l1_))
	l1l1l111ll1l_l1_ = name
	l1l11lllllll_l1_ = []
	for i in range(0,10):
		if i>0: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䡃"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䡄")+name+l1l111_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䡅")+url+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䡆")+str(l1ll1ll1llll_l1_))
		menuItemsLIST[:] = []
		if l1ll1ll1llll_l1_==234 and l1l111_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡇") in text: l1ll1ll1llll_l1_ = 233
		if l1ll1ll1llll_l1_==714 and l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡈") in text: l1ll1ll1llll_l1_ = 713
		if l1ll1ll1llll_l1_==144: l1ll1ll1llll_l1_ = 291
		dummy = l1ll1l11l1l1_l1_(type,name,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_)
		if l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䡉") in options and l1ll1ll1llll_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䡊") in options and l1ll1ll1llll_l1_==168: del menuItemsLIST[:3]
		l1l11lll1l1l_l1_[:] = l1l11lllll1l_l1_(menuItemsLIST)
		if l1l11lllllll_l1_ and l111ll1l11l_l1_(l1l111_l1_ (u"ࡻࠧฮๆๅอࠬ䡋")) in str(l1l11lll1l1l_l1_) or l111ll1l11l_l1_(l1l111_l1_ (u"ࡵࠨฯ็ๆ์࠭䡌")) in str(l1l11lll1l1l_l1_):
			name = l1l1l111ll1l_l1_
			l1l11lll1l1l_l1_[:] = l1l11lllllll_l1_
			break
		l1l1l111ll1l_l1_ = name
		l1l11lllllll_l1_ = l1l11lll1l1l_l1_
		if str(l1l11lll1l1l_l1_).count(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䡍"))>0: break
		if str(l1l11lll1l1l_l1_).count(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䡎"))>0: break
		if l1ll1ll1llll_l1_==233: break
		if l1ll1ll1llll_l1_==713: break
		if l1ll1ll1llll_l1_==291: break
		if l1l11lll1l1l_l1_: type,name,url,l1ll1ll1llll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = random.sample(l1l11lll1l1l_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠪ࠲࠳࠴࠮ࠨ䡏")
	elif name.count(l1l111_l1_ (u"ࠫࡤ࠭䡐"))>1: name = name.split(l1l111_l1_ (u"ࠬࡥࠧ䡑"),2)[2]
	name = name.replace(l1l111_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔ࠺ࠡࠩ䡒"),l1l111_l1_ (u"ࠧࠨ䡓"))
	name = name.replace(l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䡔"),l1l111_l1_ (u"ࠩࠪ䡕"))
	l1l11ll111ll_l1_[0][1] = l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䡖")+name+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䡗")
	for i in range(9): random.shuffle(l1l11lll1l1l_l1_)
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䡘") in options: menuItemsLIST[:] = l1l11ll111ll_l1_+l1l11lll1l1l_l1_[:l1l1l11l1lll_l1_]
	else: menuItemsLIST[:] = l1l11ll111ll_l1_+l1l11lll1l1l_l1_
	return
def l1l11ll1ll1l_l1_(l1l11l1lllll_l1_,l1l1l11l1ll1_l1_):
	l1l1l11l1ll1_l1_ = l1l1l11l1ll1_l1_.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡙"),l1l111_l1_ (u"ࠧࠨ䡚")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡛"),l1l111_l1_ (u"ࠩࠪ䡜"))
	l1l11llll1ll_l1_ = l1l1l11l1ll1_l1_
	if l1l111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡝") in l1l1l11l1ll1_l1_:
		l1l11llll1ll_l1_ = l1l1l11l1ll1_l1_.split(l1l111_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䡞"))[0]
		type = l1l111_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ䡟")
	elif l1l111_l1_ (u"࠭ࡖࡐࡆࠪ䡠") in l1l11l1lllll_l1_: type = l1l111_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ䡡")
	elif l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䡢") in l1l11l1lllll_l1_: type = l1l111_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ䡣")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䡤"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䡥")+type+l1l11llll1ll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䡦"),l1l11l1lllll_l1_,167,l1l111_l1_ (u"࠭ࠧ䡧"),l1l111_l1_ (u"ࠧࠨ䡨"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䡩")+l1l1l11l1ll1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䡪"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䡫"),l1l11l1lllll_l1_,167,l1l111_l1_ (u"ࠫࠬ䡬"),l1l111_l1_ (u"ࠬ࠭䡭"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䡮")+l1l1l11l1ll1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䡯"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䡰"),l1l111_l1_ (u"ࠩࠪ䡱"),9999)
	import IPTV
	for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡲") in l1l1l11l1ll1_l1_: IPTV.GROUPS(str(l1l1l1111l11_l1_),l1l11l1lllll_l1_,l1l1l11l1ll1_l1_,l1l111_l1_ (u"ࠫࠬ䡳"),False)
		else: IPTV.ITEMS(str(l1l1l1111l11_l1_),l1l11l1lllll_l1_,l1l1l11l1ll1_l1_,l1l111_l1_ (u"ࠬ࠭䡴"),False)
	menuItemsLIST[:] = l1l11lllll1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11l1lll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11l1lll_l1_)
	return
def l1l11ll111l1_l1_(l1l11l1lllll_l1_,l1l1l11l1ll1_l1_):
	l1l1l11l1ll1_l1_ = l1l1l11l1ll1_l1_.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡵"),l1l111_l1_ (u"ࠧࠨ䡶")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡷"),l1l111_l1_ (u"ࠩࠪ䡸"))
	l1l11llll1ll_l1_ = l1l1l11l1ll1_l1_
	if l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡹") in l1l1l11l1ll1_l1_:
		l1l11llll1ll_l1_ = l1l1l11l1ll1_l1_.split(l1l111_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䡺"))[0]
		type = l1l111_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ䡻")
	elif l1l111_l1_ (u"࠭ࡖࡐࡆࠪ䡼") in l1l11l1lllll_l1_: type = l1l111_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ䡽")
	elif l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䡾") in l1l11l1lllll_l1_: type = l1l111_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ䡿")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䢀"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䢁")+type+l1l11llll1ll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䢂"),l1l11l1lllll_l1_,168,l1l111_l1_ (u"࠭ࠧ䢃"),l1l111_l1_ (u"ࠧࠨ䢄"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䢅")+l1l1l11l1ll1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢆"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䢇"),l1l11l1lllll_l1_,168,l1l111_l1_ (u"ࠫࠬ䢈"),l1l111_l1_ (u"ࠬ࠭䢉"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䢊")+l1l1l11l1ll1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䢋"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䢌"),l1l111_l1_ (u"ࠩࠪ䢍"),9999)
	import M3U
	for l1l1l1111l11_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䢎") in l1l1l11l1ll1_l1_: M3U.GROUPS(str(l1l1l1111l11_l1_),l1l11l1lllll_l1_,l1l1l11l1ll1_l1_,l1l111_l1_ (u"ࠫࠬ䢏"),False)
		else: M3U.ITEMS(str(l1l1l1111l11_l1_),l1l11l1lllll_l1_,l1l1l11l1ll1_l1_,l1l111_l1_ (u"ࠬ࠭䢐"),False)
	menuItemsLIST[:] = l1l11lllll1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11l1lll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11l1lll_l1_)
	return
def l1l11lllll1l_l1_(menuItemsLIST):
	l1l11lll1l1l_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"࠭ีโฯฬࠫ䢑") in name or l1l111_l1_ (u"ࠧึใะ๋ࠬ䢒") in name or l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭䢓") in name.lower(): continue
		l1l11lll1l1l_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_])
	return l1l11lll1l1l_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧᆈ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨᆉ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᆊ"):l1l111_l1_ (u"ࠫࠬᆋ")}
l11lll_l1_ = [l1l111_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠫᆌ"),l1l111_l1_ (u"࠭ศไำสࠤ࡙࡜ࠧᆍ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==370: l1lll_l1_ = l1l1l11_l1_()
	elif mode==371: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==372: l1lll_l1_ = PLAY(url)
	elif mode==374: l1lll_l1_ = l11l1ll11_l1_(url)
	elif mode==375: l1lll_l1_ = l11l1l111_l1_(url)
	elif mode==376: l1lll_l1_ = l11l1l11l_l1_(0,url)
	elif mode==377: l1lll_l1_ = l11l1l11l_l1_(1,url)
	elif mode==379: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᆎ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩᆏ"),l1l111_l1_ (u"ࠩࠪᆐ"),l1l111_l1_ (u"ࠪࠫᆑ"),l1l111_l1_ (u"ࠫࠬᆒ"),l1l111_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᆓ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆔ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᆕ"),l1l111_l1_ (u"ࠨࠩᆖ"),379,l1l111_l1_ (u"ࠩࠪᆗ"),l1l111_l1_ (u"ࠪࠫᆘ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᆙ"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᆚ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᆛ"),l1l111_l1_ (u"ࠧࠨᆜ"),9999)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺ࠭ࡴ࡫ࡧࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᆝ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᆞ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆟ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᆠ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆡ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆢ")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨᆣ"),l111l1_l1_,375)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆤ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᆥ")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้ษอะอࠪᆦ"),l111l1_l1_,376)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆧ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᆨ")+l1lllll_l1_+l1l111_l1_ (u"࠭โศศ่อࠥอไๆ็ฮ่๏์ࠧᆩ"),l111l1_l1_,374)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᆪ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᆫ"),l1l111_l1_ (u"ࠩࠪᆬ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡹࡵࡰ࠮࡯ࡨࡲࡺ࠭ᆭ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᆮ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items[7:]:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᆯ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆰ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆱ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
		for l1ll1ll_l1_,title in items[0:7]:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪᆲ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᆳ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᆴ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	return
def l11l1ll11_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬᆵ")):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᆶ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧᆷ"),l1l111_l1_ (u"ࠧࠨᆸ"),l1l111_l1_ (u"ࠨࠩᆹ"),l1l111_l1_ (u"ࠩࠪᆺ"),l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡄࡇ࡙ࡕࡒࡔࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᆻ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠡࡥࡤࡸ࡚ࠥࡡࡨࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᆼ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᆽ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᆾ") in l1ll1ll_l1_: continue
			else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆿ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᇀ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	return
def l11l1l111_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠩࠪᇁ")):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᇂ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬᇃ"),l1l111_l1_ (u"ࠬ࠭ᇄ"),l1l111_l1_ (u"࠭ࠧᇅ"),l1l111_l1_ (u"ࠧࠨᇆ"),l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡇࡇࡄࡘ࡚ࡘࡅࡅ࠯࠴ࡷࡹ࠭ᇇ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡄࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠵ࠫᇈ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡻ࡯ࡤࡱࡣࡪࡩࡤ࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨᇉ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠫ࠿࠵࠯ࠨᇊ"),l1l111_l1_ (u"ࠬࡀ࠯࠰࠱ࠪᇋ")).replace(l1l111_l1_ (u"࠭࠯࠰ࠩᇌ"),l1l111_l1_ (u"ࠧ࠰ࠩᇍ")).replace(l1l111_l1_ (u"ࠨࠢࠪᇎ"),l1l111_l1_ (u"ࠩࠨ࠶࠵࠭ᇏ"))
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᇐ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᇑ")+l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
	return
def l11l1l11l_l1_(id,l1l11l11_l1_=l1l111_l1_ (u"ࠬ࠭ᇒ")):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᇓ"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨᇔ"),l1l111_l1_ (u"ࠨࠩᇕ"),l1l111_l1_ (u"ࠩࠪᇖ"),l1l111_l1_ (u"ࠪࠫᇗ"),l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰࡛ࡆ࡚ࡃࡉࡋࡑࡋࡓࡕࡗ࠮࠳ࡶࡸࠬᇘ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡸ࡮ࡺ࡬ࡦ࠴ࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠫᇙ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[id]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠴࠿ࠩᇚ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠧ࠻࠱࠲ࠫᇛ"),l1l111_l1_ (u"ࠨ࠼࠲࠳࠴࠭ᇜ")).replace(l1l111_l1_ (u"ࠩ࠲࠳ࠬᇝ"),l1l111_l1_ (u"ࠪ࠳ࠬᇞ")).replace(l1l111_l1_ (u"ࠫࠥ࠭ᇟ"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩᇠ"))
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᇡ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᇢ")+l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
	return
def l1lll11_l1_(url,l1l1l1lll_l1_=l1l111_l1_ (u"ࠨࠩᇣ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᇤ"),url,l1l111_l1_ (u"ࠪࠫᇥ"),l1l111_l1_ (u"ࠫࠬᇦ"),l1l111_l1_ (u"ࠬ࠭ᇧ"),l1l111_l1_ (u"࠭ࠧᇨ"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᇩ"))
	html = response.content
	if l1l111_l1_ (u"ࠨࡸ࡬ࡨࡵࡧࡧࡦࡡࠪᇪ") in url:
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡅࡱࡨࡵ࡮࠯࠱࠮ࡄ࠯ࠢࠨᇫ"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࠤࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡮ࡦ࠰࠷ࠬᇬ"),html,re.DOTALL)
	if l1l1l1lll_l1_==l1l111_l1_ (u"ࠫࠬᇭ") and l11llll_l1_ and l11llll_l1_[0].count(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪᇮ"))>1:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇯ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧᇰ"),url,371,l1l111_l1_ (u"ࠨࠩᇱ"),l1l111_l1_ (u"ࠩࠪᇲ"),l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡵࠪᇳ"))
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᇴ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧᇵ")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨᇶ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇷ"),l1lllll_l1_+title,l1ll1ll_l1_,371)
	else:
		l1l1_l1_ = []
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡳࡤ࠮࠵ࠫ࠲࠯ࡅࠩࡤࡱ࡯࠱ࡽࡹ࠭࠲࠴ࠪᇸ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠻ࠦ࠭࠴ࠪࡀࠫࡦࡳࡱ࠳ࡸࡴ࠯࠴࠶ࠬᇹ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂࠬᇺ"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ᇻ"))
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡀ࠯࠰ࠩᇼ"),l1l111_l1_ (u"࠭࠺࠰࠱࠲ࠫᇽ")).replace(l1l111_l1_ (u"ࠧ࠰࠱ࠪᇾ"),l1l111_l1_ (u"ࠨ࠱ࠪᇿ")).replace(l1l111_l1_ (u"ࠩࠣࠫሀ"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧሁ"))
				if l1l111_l1_ (u"ࠫ࠴ࡧ࡬ࡠࠩሂ") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬሃ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1ll1l_l1_)
				elif l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭ሄ") in title and (l1l111_l1_ (u"ࠧ࠰ࡅࡤࡸ࠲࠭ህ") in url or l1l111_l1_ (u"ࠨ࠱ࡖࡩࡦࡸࡣࡩ࠱ࠪሆ") in url):
					l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠯ࠣ࠯ฬ๊อๅไฬࠤ࠰ࡢࡤࠬࠩሇ"),title,re.DOTALL)
					if l1l1lll_l1_: title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨለ")+l1l1lll_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሉ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫሊ"),l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧላ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪሌ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				title = l1l111_l1_ (u"ࠨืไัฮࠦࠧል")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩሎ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1l111_l1_ (u"ࠪࠫሏ"),l1l111_l1_ (u"ࠫࠬሐ"),l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࡷࠬሑ"))
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪሒ"),url,l1l111_l1_ (u"ࠧࠨሓ"),l1l111_l1_ (u"ࠨࠩሔ"),l1l111_l1_ (u"ࠩࠪሕ"),l1l111_l1_ (u"ࠪࠫሖ"),l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬሗ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲࡡࡣࡧ࡯࠱ࡸࡻࡣࡤࡧࡶࡷࠥࡳࡲࡨ࠯ࡥࡸࡲ࠳࠵ࠡࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪመ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llllll_l1_ = l1l111_l1_ (u"࠭ࠧሙ")
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡺࡸ࡬ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫሚ"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩࡶࡡࡨࡧࡢࠫማ"),l1l111_l1_ (u"ࠩ࠲ࡔࡱࡧࡹ࠰ࠩሜ"))
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨም") not in l1lllll1_l1_: l1lllll1_l1_ = l111l1_l1_+l1lllll1_l1_
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠫ࠲࠭ሞ"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩሟ"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧሠ"),l1l111_l1_ (u"ࠧࠨሡ"),l1l111_l1_ (u"ࠨࠩሢ"),l1l111_l1_ (u"ࠩࠪሣ"),l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫሤ"))
	l11l1ll1_l1_ = response.content
	l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩሥ"),l11l1ll1_l1_,re.DOTALL)
	if l1llllll_l1_:
		l1llllll_l1_ = l1llllll_l1_[-1]
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪሦ") not in l1llllll_l1_: l1llllll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬሧ")+l1llllll_l1_
		if l1l111_l1_ (u"ࠧ࠰ࡒࡏࡅ࡞࠵ࠧረ") not in l1lllll1_l1_:
			if l1l111_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠮࡮࡫ࡱ࠲࡯ࡹࠧሩ") in l1llllll_l1_:
				l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨሪ"),l11l1ll1_l1_,re.DOTALL)
				if l11l1l1l1_l1_:
					l11l11lll_l1_, l11l1l1ll_l1_ = l11l1l1l1_l1_[0]
					l1llllll_l1_ = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧራ"))+l1l111_l1_ (u"ࠫ࠴ࡼ࠲࠰ࠩሬ")+l11l11lll_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡰࡰࡩ࡭࡬࠵ࠧር")+l11l1l1ll_l1_+l1l111_l1_ (u"࠭࠮࡫ࡵࡲࡲࠬሮ")
		import ll_l1_
		ll_l1_.l1l_l1_([l1llllll_l1_],l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ሯ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩሰ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪሱ"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬሲ"),l1l111_l1_ (u"ࠫ࠰࠭ሳ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡓࡦࡣࡵࡧ࡭࠵ࠧሴ")+search
	l1lll11_l1_(url)
	return
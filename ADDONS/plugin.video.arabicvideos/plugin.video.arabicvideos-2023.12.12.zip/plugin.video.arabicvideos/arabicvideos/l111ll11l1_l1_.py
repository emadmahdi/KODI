# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ∘")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡅ࠷ࡤ࠭∙")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ฺ้อัฺหࠣห้ำัสࠩ√"),l1l111_l1_ (u"ࠩส๎ั๐ࠠษีอࠫ∛"),l1l111_l1_ (u"ࠪห้ะีๆ์่ࠤฬ๊ฬะ์าࠫ∜"),l1l111_l1_ (u"ࠫ฾ื่ืࠢส่๊฻วา฻ฬࠫ∝"),l1l111_l1_ (u"๋ࠬใหสอ๎ࠬ∞"),l1l111_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็ะิ๐ฯࠨ∟"),l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่อี๊ๅࠩ∠"),l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ∡"),l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮำหࠩ∢"),l1l111_l1_ (u"้ࠪํู่่ࠡอๅ้๐ใิࠩ∣")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==790: l1lll_l1_ = l1l1l11_l1_()
	elif mode==791: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==792: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==793: l1lll_l1_ = PLAY(url)
	elif mode==796: l1lll_l1_ = l111l1111_l1_(url,l1llllll1_l1_)
	elif mode==799: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ∤"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭∥"),l1l111_l1_ (u"࠭ࠧ∦"),l1l111_l1_ (u"ࠧࠨ∧"),l1l111_l1_ (u"ࠨࠩ∨"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭∩"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴ࠮ࡲࡤ࡫ࡪࡹࠨ࠯ࠬࡂ࠭࡫ࡧ࠭ࡧࡱ࡯ࡨࡪࡸࠧ∪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ∫"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ∬"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ∭") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ∮"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ∯")+l1lllll_l1_+title,l1ll1ll_l1_,791)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ∰"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ∱"),l1l111_l1_ (u"ࠫࠬ∲"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࡵࡲࡧ࡮ࡧ࡬࠮ࡤࡲࡼࠬ∳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ∴"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ∵"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭∶") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ∷"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ∸")+l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠫࠬ∹"),l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡰࡩࡳࡻࠧ∺"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ∻"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ∼"),l1l111_l1_ (u"ࠨࠩ∽"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ∾"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ∿"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭≀"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ≁") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭≂"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ≃")+l1lllll_l1_+title,l1ll1ll_l1_,791)
	return html
def l111l1111_l1_(url,type=l1l111_l1_ (u"ࠨࠩ≄")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭≅"),url,l1l111_l1_ (u"ࠪࠫ≆"),l1l111_l1_ (u"ࠫࠬ≇"),l1l111_l1_ (u"ࠬ࠭≈"),l1l111_l1_ (u"࠭ࠧ≉"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ≊"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡡࡳࡶ࡬ࡧࡱ࡫ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫࡤࡶࡹ࡯ࡣ࡭ࡧࠪ≋"),html,re.DOTALL)
	if l11llll_l1_:
		l111llll1l_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠩࠪ≌"),l1l111_l1_ (u"ࠪࠫ≍"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠫา๊โศฬࠪ≎") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๋่ࠬศี่ࠫ≏") in name: l111llll1l_l1_ = block
		if l111llll1l_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭≐"),l111llll1l_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ≑"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ≒"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ≓"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ≔"),l1lllll_l1_+title,l1ll1ll_l1_,793,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ≕"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ≖"),l1lllll_l1_+title,l1ll1ll_l1_,793)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ≗")):
	limit,start,l1l1l1ll1_l1_,select,l111ll1111_l1_ = 0,0,l1l111_l1_ (u"ࠧࠨ≘"),l1l111_l1_ (u"ࠨࠩ≙"),l1l111_l1_ (u"ࠩࠪ≚")
	if l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ≛") in type:
		l111ll11ll_l1_,data = l1ll11ll1_l1_(url)
		limit = int(data[l1l111_l1_ (u"ࠫࡱ࡯࡭ࡪࡶࠪ≜")])
		start = int(data[l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ≝")])
		l1l1l1ll1_l1_ = data[l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ≞")]
		select = data[l1l111_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺࠧ≟")]
		l1l11llll_l1_ = l1l111_l1_ (u"ࠨ࡮࡬ࡱ࡮ࡺ࠽ࠨ≠")+str(limit)+l1l111_l1_ (u"ࠩࠩࡷࡹࡧࡲࡵ࠿ࠪ≡")+str(start)+l1l111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࠪ≢")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡥ࡭ࡧࡦࡸࡂ࠭≣")+select
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ≤"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ≥")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ≦"),l111ll11ll_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ≧"),l1l111_l1_ (u"ࠩࠪ≨"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ≩"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡶࠫ≪")+html+l1l111_l1_ (u"ࠬࡧࡲࡵ࡫ࡦࡰࡪ࠭≫")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ≬"),url,l1l111_l1_ (u"ࠧࠨ≭"),l1l111_l1_ (u"ࠨࠩ≮"),l1l111_l1_ (u"ࠩࠪ≯"),l1l111_l1_ (u"ࠪࠫ≰"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ≱"))
		html = response.content
		l11l1ll1_l1_ = html
		code = re.findall(l1l111_l1_ (u"ࠧࡂࡳࡤࡴ࡬ࡴࡹࡄࠨࡷࡣࡵ࠲࠯ࡅ࠽࠯ࠬࡂ࠿ࡻࡧࡲ࠯ࠬࡂࡁ࠳࠰࠿࠼ࡸࡤࡶ࠳࠰࠿࠾࠰࠭ࡃࡀࡼࡡࡳ࠰࠭ࡃࡂ࠴ࠪࡀ࠽ࡹࡥࡷ࠴ࠪࡀ࠿࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠥ≲"),html,re.DOTALL)
		if code:
			code = code[0].replace(l1l111_l1_ (u"࠭ࡶࡢࡴࠪ≳"),l1l111_l1_ (u"ࠧࠨ≴")).replace(l1l111_l1_ (u"ࠨࠢࠪ≵"),l1l111_l1_ (u"ࠩࠪ≶")).replace(l1l111_l1_ (u"ࠥࠫࠧ≷"),l1l111_l1_ (u"ࠫࠬ≸")).replace(l1l111_l1_ (u"ࠬࡁࠧ≹"),l1l111_l1_ (u"࠭ࠦࠨ≺"))
			dummy,data = l1ll11ll1_l1_(l1l111_l1_ (u"ࠧࡀࠩ≻")+code)
			limit = int(data[l1l111_l1_ (u"ࠨ࡮࡬ࡱ࡮ࡺࠧ≼")])
			start = int(data[l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ≽")])
			l1l1l1ll1_l1_ = data[l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ≾")]
			select = data[l1l111_l1_ (u"ࠫࡸ࡫࡬ࡦࡥࡷࠫ≿")]
			l111ll1111_l1_ = data[l1l111_l1_ (u"ࠬࡧࡪࡢࡺࡸࡶࡱ࠭⊀")]
			l1l11llll_l1_ = l1l111_l1_ (u"࠭࡬ࡪ࡯࡬ࡸࡂ࠭⊁")+str(limit)+l1l111_l1_ (u"ࠧࠧࡵࡷࡥࡷࡺ࠽ࠨ⊂")+str(start)+l1l111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࠨ⊃")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠩࠩࡷࡪࡲࡥࡤࡶࡀࠫ⊄")+select
			l111ll11ll_l1_ = l111l1_l1_+l111ll1111_l1_
			l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⊅"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⊆")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ⊇"),l111ll11ll_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ⊈"),l1l111_l1_ (u"ࠧࠨ⊉"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠷ࡷࡪࠧ⊊"))
			l11l1ll1_l1_ = response.content
			l11l1ll1_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠩ⊋")+l11l1ll1_l1_+l1l111_l1_ (u"ࠪࡥࡷࡺࡩࡤ࡮ࡨࠫ⊌")
	items,l111lllll1_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⊍"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⊎"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ⊏"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊐"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠨࠩ⊑"),l1l111_l1_ (u"ࠩࡶࡹࡧࡳࡥ࡯ࡷࠪ⊒"))
				l111lllll1_l1_ = True
	if not type:
		filters = l111ll111l_l1_(html)
	if not l111lllll1_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨ⊓"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⊔"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠬࡢ࡮ࠨ⊕"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ⊖") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊗"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ⊘") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧ⊙") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⊚"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_)
				elif l1l111_l1_ (u"๊ࠫ๎ำๆࠩ⊛") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬำไใหࠪ⊜") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊝"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⊞"),l1lllll_l1_+title,l1ll1ll_l1_,793,l1ll1l_l1_)
		length = 12
		data = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠪ࡯ࡳࡦࡪ࠭࡮ࡱࡵࡩ࠳࠰࠿ࠪ࠾ࠪ⊟"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭⊠") in type):
			l1l11llll_l1_ = l1l111_l1_ (u"ࠪࡰ࡮ࡳࡩࡵ࠿ࠪ⊡")+str(length)+l1l111_l1_ (u"ࠫࠫࡹࡴࡢࡴࡷࡁࠬ⊢")+str(start+length)+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ⊣")+l1l1l1ll1_l1_+l1l111_l1_ (u"࠭ࠦࡴࡧ࡯ࡩࡨࡺ࠽ࠨ⊤")+select
			l1lllll1_l1_ = l111ll11ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ⊥")+l1l11llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊦"),l1lllll_l1_+l1l111_l1_ (u"ࠩสุ่๊๊ะࠩ⊧"),l1lllll1_l1_,791,l1l111_l1_ (u"ࠪࠫ⊨"),l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡠࠩ⊩")+type)
	return
def l111ll111l_l1_(html):
	filters = False
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩ⊪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⊫"),block,re.DOTALL)
		if l1lll1l1_l1_: addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⊬"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⊭"),l1l111_l1_ (u"ࠩࠪ⊮"),9999)
		for category,name,block in l1lll1l1_l1_:
			name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ⊯"))
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⊰"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ⊱")+value
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊲"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠧࠨ⊳"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⊴"))
				filters = True
	return filters
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⊵"),url,l1l111_l1_ (u"ࠪࠫ⊶"),l1l111_l1_ (u"ࠫࠬ⊷"),l1l111_l1_ (u"ࠬ࠭⊸"),l1l111_l1_ (u"࠭ࠧ⊹"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⊺"))
	html = response.content
	l1ll11l1_l1_,l111l11l1_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⊻"),html,re.DOTALL)
	for l111ll1l1l_l1_ in items:
		l111ll1lll_l1_ = base64.b64decode(l111ll1l1l_l1_)
		if kodi_version>18.99: l111ll1lll_l1_ = l111ll1lll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⊼"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⊽"),l111ll1lll_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1ll1ll_l1_ not in l111l11l1_l1_:
				l111l11l1_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ⊾"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⊿")+server+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⋀"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫ⋁"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡷࡶࠥ࡬࡬ࡦࡺ࠰ࡷࡹࡧࡲࡵࠤ࠱࠮ࡄࡂࡤࡪࡸࡁ࡟ࠥࡧ࠭ࡻࡃ࠰࡞ࡢ࠰ࠨ࡝ࡦࡾ࠷࠱࠺ࡽࠪ࡝ࠣࡥ࠲ࢀࡁ࠮࡜ࡠ࠮ࡁ࠵ࡤࡪࡸࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋂"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l111l11l1_l1_:
				if l1l111_l1_ (u"ࠩ࠲ࡃࡺࡸ࡬࠾ࠩ⋃") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ⋄"))[1]
				l111l11l1_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ⋅"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⋆")+server+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡤࡥࠧ⋇")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⋈"),url)
	return
def l1lll1_l1_(text):
	return
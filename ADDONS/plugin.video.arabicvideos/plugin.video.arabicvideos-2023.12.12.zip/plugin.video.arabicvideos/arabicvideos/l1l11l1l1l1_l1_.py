# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡍࡋࡅࡗࡔࡔࡅࠨㆌ")
l1l1l1l1l11_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢㆍ"))
kodi_version = re.findall(l1l111_l1_ (u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭ㆎ"),l1l1l1l1l11_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1ll1ll11_l1_ = xbmc.Player
l1l1ll11l1l_l1_ = xbmcgui.WindowXMLDialog
if kodi_version>18.99:
	l1ll111l11l_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ㆏"),l1l111_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ㆐")
	l1l1l11l1ll_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭㆑"))
	from urllib.parse import unquote as _1l1l1l11ll_l1_
else:
	l1ll111l11l_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ㆒").encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㆓")),l1l111_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩ㆔").encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㆕"))
	l1l1l11l1ll_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ㆖"))
	from urllib import unquote as _1l1l1l11ll_l1_
l1l1lll1l11_l1_ = 60
l1l1l11l11l_l1_ = 60*l1l1lll1l11_l1_
l1l1l111l1l_l1_ = 24*l1l1l11l11l_l1_
l1l1ll1llll_l1_ = 30*l1l1l111l1l_l1_
l1ll1ll1_l1_ = 3*l1l1l111l1l_l1_
l1ll111l1l1_l1_ = 12*l1l1ll1llll_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"ࠫ࠴࠭㆗"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1llll11l_l1_ = addon_id.split(l1l111_l1_ (u"ࠬ࠴ࠧ㆘"))[2]
l1l11ll1111_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭㆙")+addon_id+l1l111_l1_ (u"ࠧࠪࠩ㆚"))
addoncachefolder = os.path.join(l1l1l11l1ll_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡪࡡࡵࡣ࠱ࡨࡧ࠭㆛"))
l1l1l1l1111_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩ࡯ࡥࡸࡺࡶࡪࡦࡨࡳࡸ࠴ࡤࡢࡶࠪ㆜"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url):
	if l1l111_l1_ (u"ࠪࡁࠬ㆝") in url:
		if l1l111_l1_ (u"ࠫࡄ࠭㆞") in url: l1lllll1_l1_,filters = url.split(l1l111_l1_ (u"ࠬࡅࠧ㆟"),1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"࠭ࠧㆠ"),url
		filters = filters.split(l1l111_l1_ (u"ࠧࠧࠩㆡ"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠨ࠿ࠪㆢ"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l1l11ll_l1_(urll)
def EXTRACT_KODI_PATH(l1l11l1l111_l1_):
	l1l1ll1l1ll_l1_ = {l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧㆣ"):l1l111_l1_ (u"ࠪࠫㆤ"),l1l111_l1_ (u"ࠫࡲࡵࡤࡦࠩㆥ"):l1l111_l1_ (u"ࠬ࠭ㆦ"),l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪㆧ"):l1l111_l1_ (u"ࠧࠨㆨ"),l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠭ㆩ"):l1l111_l1_ (u"ࠩࠪㆪ"),l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥࠨㆫ"):l1l111_l1_ (u"ࠫࠬㆬ"),l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪㆭ"):l1l111_l1_ (u"࠭ࠧㆮ"),l1l111_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ㆯ"):l1l111_l1_ (u"ࠨࠩㆰ"),l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪㆱ"):l1l111_l1_ (u"ࠪࠫㆲ"),l1l111_l1_ (u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ㆳ"):l1l111_l1_ (u"ࠬ࠭ㆴ")}
	if l1l111_l1_ (u"࠭࠿ࠨㆵ") in l1l11l1l111_l1_: l1l11l1l111_l1_ = l1l11l1l111_l1_.split(l1l111_l1_ (u"ࠧࡀࠩㆶ"),1)[1]
	l1lllll1_l1_,l1ll11111l1_l1_ = l1ll11ll1_l1_(l1l11l1l111_l1_)
	args = dict(list(l1l1ll1l1ll_l1_.items())+list(l1ll11111l1_l1_.items()))
	l1l11l111ll_l1_ = args[l1l111_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭ㆷ")]
	l1l1l1ll1l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ㆸ")])
	l1l1l1111ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨㆹ")])
	l1l111lll1l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫࡵࡧࡧࡦࠩㆺ")])
	l1l111lll11_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬࡺࡹࡱࡧࠪㆻ")])
	l1l1l111l11_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫㆼ")])
	l1l1ll11lll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ㆽ")])
	l1l1l11111l_l1_ = args[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩㆾ")]
	l1l1l1l111l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫㆿ")])
	if l1l1l1l111l_l1_: l1l1l1l111l_l1_ = eval(l1l1l1l111l_l1_)
	else: l1l1l1l111l_l1_ = {}
	if not l1l11l111ll_l1_: l1l111lll11_l1_ = l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㇀") ; l1l11l111ll_l1_ = l1l111_l1_ (u"ࠫ࠷࠼࠰ࠨ㇁")
	return l1l111lll11_l1_,l1l1l111l11_l1_,l1l1l1ll1l1_l1_,l1l11l111ll_l1_,l1l1ll11lll_l1_,l1l111lll1l_l1_,l1l1l1111ll_l1_,l1l1l11111l_l1_,l1l1l1l111l_l1_
def l11lllll11_l1_(l1ll1_l1_):
	l1l1l1111l1_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l1l1111l1_l1_ or l1l1l1111l1_l1_==l1l111_l1_ (u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧ㇂"):
		return l1l111_l1_ (u"࡛࠭ࠡࠩ㇃")+l1l1llll11l_l1_.upper()+l1l111_l1_ (u"ࠧ࠮ࠩ㇄")+l1l11ll1111_l1_+l1l111_l1_ (u"ࠨ࠯ࠪ㇅")+str(kodi_version)+l1l111_l1_ (u"ࠩࠣࡡࠬ㇆")
	return l1l111_l1_ (u"ࠪ࠲ࠥࠦࠧ㇇")+l1l1l1111l1_l1_
def l1l111111l_l1_(level,message):
	if kodi_version<19: message = message.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇈")).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㇉"))
	l1l11ll11l1_l1_ = l1ll111l11l_l1_
	lines = [l1l111_l1_ (u"࠭ࠧ㇊"),l1l111_l1_ (u"ࠧࠨ㇋")]
	if level: message = message.replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㇌"),l1l111_l1_ (u"ࠩࠪ㇍")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭㇎"),l1l111_l1_ (u"ࠫࠬ㇏")).replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㇐"),l1l111_l1_ (u"࠭ࠧ㇑"))
	else: level = l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㇒")
	l11ll11111_l1_,sep,shift = l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭㇓"),l1l111_l1_ (u"ࠩࠣࠤࠥ࠭㇔"),l1l111_l1_ (u"ࠪࠫ㇕")
	if l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㇖") in level: l1l11ll11l1_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㇗"):
		message = message+sep
		lines = message.split(sep)
		shift = l11ll11111_l1_
	elif level==l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㇘"):
		message = message.replace(l1l111_l1_ (u"ࠧ࠯ࠩ㇙")+sep,l1l111_l1_ (u"ࠨ࠰ࠣࠤࠬ㇚"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"ࠩ࠱ࠫ㇛")+lines[0][1:]
		shift = l11ll11111_l1_+sep
	elif level in [l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㇜"),l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㇝")]: lines = message.split(l11ll11111_l1_)
	shift += 6*l11ll11111_l1_
	l1l11ll1l1l_l1_ = 3*l11ll11111_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"ࠬࠦࠧ㇞")
	l1l1ll1lll1_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"࠭࡜࡯ࠩ㇟") in line: line = line.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㇠"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㇡")+l11ll11111_l1_+l11ll11111_l1_)
		l1l11ll1l1l_l1_ += l11ll11111_l1_
		l1l1ll1lll1_l1_ += l1l111_l1_ (u"ࠩ࡟ࡶࠬ㇢")+shift+l1l11ll1l1l_l1_+line
	l1l1ll1lll1_l1_ += l1l111_l1_ (u"ࠪࠤࡤ࠭㇣")
	if l1l111_l1_ (u"ࠫࠪ࠭㇤") in l1l1ll1lll1_l1_: l1l1ll1lll1_l1_ = l111l11_l1_(l1l1ll1lll1_l1_)
	xbmc.log(l1l1ll1lll1_l1_,level=l1l11ll11l1_l1_)
	return
def l1l1llll1ll_l1_(l1lll11111_l1_):
	conn = sqlite3.connect(l1lll11111_l1_)
	l1lllll1l1_l1_ = conn.cursor()
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱ࠾ࠫ㇥"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡦࡰࡴࡨ࡭࡬ࡴ࡟࡬ࡧࡼࡷࡂࡴ࡯࠼ࠩ㇦"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡩࡱࡳࡷ࡫࡟ࡤࡪࡨࡧࡰࡥࡣࡰࡰࡶࡸࡷࡧࡩ࡯ࡶࡶࡁࡾ࡫ࡳ࠼ࠩ㇧"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫࠽ࡐࡈࡉ࠿ࠬ㇨"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧ㇩"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡷࡾࡴࡣࡩࡴࡲࡲࡴࡻࡳ࠾ࡑࡉࡊࡀ࠭㇪"))
	conn.text_factory = str
	return conn,l1lllll1l1_l1_
def l1lll1ll111_l1_(l1lll11111_l1_,table,l1l1l1l1ll1_l1_=None):
	try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
	except: return
	if l1l1l1l1ll1_l1_==None: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠫࡉࡘࡏࡑࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㇫")+table+l1l111_l1_ (u"ࠬࠨࠠ࠼ࠩ㇬"))
	else:
		tt = (str(l1l1l1l1ll1_l1_),)
		try:
			if l1l111_l1_ (u"࠭ࠥࠨ㇭") in l1l1l1l1ll1_l1_: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㇮")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫ㇯"),tt)
			else: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩㇰ")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪㇱ"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1lll1111_l1_(): pass
class l1l1lllll1l_l1_(l1l1lll1111_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"ࠫࠬㇲ")
		self.code = -99
		self.reason = l1l111_l1_ (u"ࠬ࠭ㇳ")
		self.content = l1l111_l1_ (u"࠭ࠧㇴ")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l1l1l1l_l1_(type):
	if type==l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬㇵ"): data = {}
	elif type==l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭ㇶ"): data = []
	elif type==l1l111_l1_ (u"ࠩࡶࡸࡷ࠭ㇷ"): data = l1l111_l1_ (u"ࠪࠫㇸ")
	elif type==l1l111_l1_ (u"ࠫ࡮ࡴࡴࠨㇹ"): data = 0
	elif type==l1l111_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧㇺ"): data = l1l1lllll1l_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1lll11l11l_l1_(l1lll11111_l1_,l1l1ll11111_l1_,table,l1l1l1l1ll1_l1_=None):
	data = l1l1l1l1l1l_l1_(l1l1ll11111_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨㇻ"))
	if table!=l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪㇼ") and l1lll11111_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭ㇽ"): return data
		l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ㇾ"))
		if l1ll11ll1l_l1_==l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭ㇿ"):
			l1lll1ll111_l1_(l1lll11111_l1_,table,l1l1l1l1ll1_l1_)
			return data
	l1ll111l1ll_l1_ = 0
	if cache==l1l111_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㈀"): l1ll111l1ll_l1_ = l1l11l1llll_l1_
	try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
	except: return data
	l1l1l11llll_l1_ = True
	try: l1lllll1l1_l1_.execute(l1l111_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥࠨࠧ㈁")+table+l1l111_l1_ (u"࠭ࠢࠡࡎࡌࡑࡎ࡚ࠠ࠲ࠢ࠾ࠫ㈂"))
	except: l1l1l11llll_l1_ = False
	if l1l1l11llll_l1_:
		if l1ll111l1ll_l1_: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㈃")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺࡀࠪ㈄")+str(now+l1ll111l1ll_l1_)+l1l111_l1_ (u"ࠩࠣ࠿ࠬ㈅"))
		conn.commit()
		l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㈆")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡁ࠭㈇")+str(now)+l1l111_l1_ (u"ࠬࠦ࠻ࠨ㈈"))
		conn.commit()
		if l1l1l1l1ll1_l1_:
			tt = (str(l1l1l1l1ll1_l1_),)
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫ㈉")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㈊"),tt)
			l1l1l11l1l1_l1_ = l1lllll1l1_l1_.fetchall()
			if l1l1l11l1l1_l1_:
				try:
					text = zlib.decompress(l1l1l11l1l1_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭㈋")+table+l1l111_l1_ (u"ࠩࠥࠤࡀ࠭㈌"))
			l1l1l11l1l1_l1_ = l1lllll1l1_l1_.fetchall()
			if l1l1l11l1l1_l1_:
				data,l1l1llll1l1_l1_ = {},[]
				for l1l1ll1ll1l_l1_,l1l11llll_l1_ in l1l1l11l1l1_l1_:
					l1ll1lll11_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1lll11_l1_)
					data[l1l1ll1ll1l_l1_] = l1l11llll_l1_
					l1l1llll1l1_l1_.append(l1l1ll1ll1l_l1_)
				if l1l1llll1l1_l1_:
					data[l1l111_l1_ (u"ࠪࡣࡤ࡙ࡅࡒࡗࡈࡒࡈࡋࡄࡠࡅࡒࡐ࡚ࡓࡎࡔࡡࡢࠫ㈍")] = l1l1llll1l1_l1_
					if l1l1ll11111_l1_==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㈎"): data = l1l1llll1l1_l1_
	conn.close()
	return data
l1l11lll1l1_l1_ = l1l111_l1_ (u"ࠬ࠭㈏")
def l1l1l11ll1l_l1_():
	global l1l11lll1l1_l1_
	from getmac import get_mac_address
	l1l11lll1l1_l1_ = get_mac_address()
	return
def l1l1ll1l11l_l1_(l1l1l1ll111_l1_,l1l1lll11ll_l1_=True):
	l1l111llll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡊࡒࡄࡨࡩࡸࡥࡴࡵࠪ㈐"))
	l1ll11111ll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭㈑"))
	if l1l1lll11ll_l1_:
		try: l1l1l1l11l_l1_,l1l1lll1ll1_l1_,l1l11ll1l11_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㈒"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㈓"),l1l111_l1_ (u"ࠪࡍࡉ࡙ࠧ㈔"))
		except: l1l1l1l11l_l1_,l1l1lll1ll1_l1_,l1l11ll1l11_l1_ = l1l111_l1_ (u"ࠫࠬ㈕"),l1l111_l1_ (u"ࠬ࠭㈖"),l1l111_l1_ (u"࠭ࠧ㈗")
		if l1l1l1l11l_l1_ and l1l111llll1_l1_==l1l1lll1ll1_l1_ and l1ll11111ll_l1_==l1l11ll1l11_l1_: return l1l1l1l11l_l1_
	global l1l11lll1l1_l1_
	l1l1l1ll111_l1_ = l1l1l1ll111_l1_//2
	from threading import Thread
	l1l11l1ll11_l1_ = Thread(target=l1l1l11ll1l_l1_,args=())
	l1l11l1ll11_l1_.start()
	l1ll1111l1l_l1_,l1ll1111ll1_l1_,l1l1ll1l1l1_l1_ = l1l111_l1_ (u"ࠧࠨ㈘"),l1l111_l1_ (u"ࠨࠩ㈙"),l1l111_l1_ (u"ࠩࠪ㈚")
	for l1l11l111l_l1_ in range(10):
		time.sleep(0.5)
		if not l1ll1111l1l_l1_:
			l1l11lll1ll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨ㈛"))
			if l1l11lll1ll_l1_.count(l1l111_l1_ (u"ࠫ࠿࠭㈜"))==5 and l1l11lll1ll_l1_.count(l1l111_l1_ (u"ࠬ࠶ࠧ㈝"))<9: l1ll1111l1l_l1_ = l1l11lll1ll_l1_
		if not l1ll1111ll1_l1_ and l1l11lll1l1_l1_:
			if l1l11lll1l1_l1_.count(l1l111_l1_ (u"࠭࠺ࠨ㈞"))==5 and l1l11lll1l1_l1_.count(l1l111_l1_ (u"ࠧ࠱ࠩ㈟"))<9: l1ll1111ll1_l1_ = l1l11lll1l1_l1_
		if l1ll1111l1l_l1_ and l1ll1111ll1_l1_: break
	if l1ll1111l1l_l1_ or l1ll1111ll1_l1_:
		l1l11llll1l_l1_ = l1ll1111ll1_l1_ if l1ll1111ll1_l1_ else l1ll1111l1l_l1_
		l1l11llll1l_l1_ = l1l11llll1l_l1_.lower().replace(l1l111_l1_ (u"ࠨ࠼ࠪ㈠"),l1l111_l1_ (u"ࠩࠪ㈡"))
		l1l1ll1l1l1_l1_ = str(int(l1l11llll1l_l1_,16))
	if not l1l1ll1l1l1_l1_:
		l1l11lllll1_l1_ = open(l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡤ࠱ࡦࡴࡺ࡯࡮ࡧࡱࠪ㈢"),l1l111_l1_ (u"ࠫࡷࡨࠧ㈣")).read()
		if kodi_version>18.99: l1l11lllll1_l1_ = l1l11lllll1_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㈤"))
		l1l11l11l11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡥࡱ࠴ࠪࡀ࠼ࠣࠬ࠳࠰࠿ࠪࠦࠪ㈥"),l1l11lllll1_l1_,re.IGNORECASE)
		if l1l11l11l11_l1_:
			l1l11l11l11_l1_ = l1l11l11l11_l1_[0].strip(l1l111_l1_ (u"ࠧ࠱ࠩ㈦"))
			if l1l11l11l11_l1_:
				from hashlib import md5
				if kodi_version>18.99: l1l11l11l11_l1_ = l1l11l11l11_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㈧"))
				l1l11l11l11_l1_ = str(int(md5(l1l11l11l11_l1_).hexdigest(),36))
				l1l11l11l11_l1_ = [int(l1l11l11l11_l1_[l1ll1111lll_l1_:l1ll1111lll_l1_+15]) for l1ll1111lll_l1_ in range(len(l1l11l11l11_l1_)) if l1ll1111lll_l1_%15==0]
				l1l1ll1l1l1_l1_ = str(sum(l1l11l11l11_l1_))
	if not l1l1ll1l1l1_l1_: l1l1ll1l1l1_l1_ = l1l111_l1_ (u"ࠩ࠳࠴࠶࠷࠲࠳࠵࠶࠸࠹࠻࠵࠷࠸࠺࠻ࠬ㈨")
	l1l1ll1l1l1_l1_ = l1l1l1ll111_l1_*l1l111_l1_ (u"ࠪ࠴ࠬ㈩")+l1l1ll1l1l1_l1_
	l1l1ll1l1l1_l1_ = l1l1ll1l1l1_l1_[-l1l1l1ll111_l1_:]
	mm,ss = l1l111_l1_ (u"ࠫࠬ㈪"),l1l111_l1_ (u"ࠬ࠭㈫")
	l1l1l111lll_l1_ = str(int(l1l111_l1_ (u"࠭࠹ࠨ㈬")*(l1l1l1ll111_l1_+1))-int(l1l1ll1l1l1_l1_))[-l1l1l1ll111_l1_:]
	for l1l11l111l_l1_ in list(range(0,l1l1l1ll111_l1_,4)):
		l1l11l1lll1_l1_ = l1l1l111lll_l1_[l1l11l111l_l1_:l1l11l111l_l1_+4]
		mm += l1l11l1lll1_l1_+l1l111_l1_ (u"ࠧ࠮ࠩ㈭")
		ss += str(sum(map(int,l1l1ll1l1l1_l1_[l1l11l111l_l1_:l1l11l111l_l1_+4]))%10)
	l1l1llllll1_l1_ = mm+ss
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㈮"),l1l111_l1_ (u"ࠩࡌࡈࡘ࠭㈯"),[l1l1llllll1_l1_,l1l111llll1_l1_,l1ll11111ll_l1_],l1ll1ll1_l1_)
	return l1l1llllll1_l1_
def l1l1l111111_l1_(l1ll111111l_l1_):
	l1l11llll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ㈰"))
	user = l1l1ll1l11l_l1_(32)
	from hashlib import md5
	l1l1l1lllll_l1_ = md5((l1l111_l1_ (u"ࠫ࡝࠷࠹ࠨ㈱")+l1ll111111l_l1_+l1l111_l1_ (u"ࠬ࠷࠸࠾ࠩ㈲")+user).encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㈳"))).hexdigest()[:32]
	if l1l1l1lllll_l1_ in l1l11llll11_l1_: return True
	return False
class l1l1l1lll1l_l1_(l1l1ll1ll11_l1_):
	def __init__(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠧࠨ㈴")
	def init(self,l1l11ll1lll_l1_):
		self.l1l11ll1lll_l1_ = l1l11ll1lll_l1_
		self.l1ll111l111_l1_ = l1l1l111111_l1_(l1l111_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ㈵"))
		self.l1l1ll11ll1_l1_ = l1l1l111111_l1_(l1l111_l1_ (u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪ㈶"))
		self.l1l1l1l1lll_l1_ = l1l1l111111_l1_(l1l111_l1_ (u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽࡚ࡘࡖࡏࡗࡖ࡙࠺ࡎࡘࠨ㈷"))
		if self.l1ll111l111_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㈸")
		elif self.l1l1ll11ll1_l1_: return
		elif self.l1l1l1l1lll_l1_:
			from l1l1l11ll11_l1_ import l1l1l1lll11_l1_
			l1l1l1lll11_l1_(False)
		else:
			self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㈹")
			from l1l1l11ll11_l1_ import l1l1l1lll11_l1_
			l1l1l1lll11_l1_(False)
	def onPlayBackStopped(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㈺")
	def onPlayBackError(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㈻")
	def onPlayBackEnded(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㈼")
	def onPlayBackStarted(self):
		self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ㈽")
		from threading import Thread
		l1l11l11ll1_l1_ = Thread(target=self.l1l11l1l1ll_l1_,args=())
		l1l11l11ll1_l1_.start()
	def l1l1llll111_l1_(self):
		if self.l1ll111l111_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ㈾")
		elif self.l1l1ll11ll1_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㈿")
		elif self.l1l1l1l1lll_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㉀")
		else: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㉁")
	def l1l11l1l1ll_l1_(self):
		l1l1l1ll11l_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪ㉂")) and self.l1l1lll1lll_l1_==l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ㉃"):
			xbmc.sleep(1500)
			l1l1l1ll11l_l1_ += 1.5
			if l1l1l1ll11l_l1_>60: return
		if self.l1ll111l111_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ㉄")
		elif self.l1l1ll11ll1_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ㉅")
		elif self.l1l1l1l1lll_l1_:
			self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ㉆")
			from LIBSTWO import l1l1ll1l111_l1_,l1l111lllll_l1_
			from threading import Thread
			l1l11l11l1l_l1_ = Thread(target=l1l1ll1l111_l1_,args=(self.l1l11ll1lll_l1_,))
			l1l11l11l1l_l1_.start()
			l1l11l11lll_l1_ = Thread(target=l1l111lllll_l1_,args=())
			l1l11l11lll_l1_.start()
		else: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㉇")
def l1l1ll1111l_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㉈"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㉉")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㉊"),l1l111_l1_ (u"ࠩ࡟ࡠࡷ࠭㉋")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ㉌"),l1l111_l1_ (u"ࠫࠥ࠭㉍")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㉎"),l1l111_l1_ (u"࠭ࠠࠨ㉏"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠧࠡ࠰࠱࠲ࠬ㉐")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㉑"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㉒")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㉓"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㉔")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ㉕"),l1l111_l1_ (u"࠭ࠠࠨ㉖")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㉗"),l1l111_l1_ (u"ࠨࠢࠪ㉘"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠩࠣ࠲࠳࠴ࠧ㉙")
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㉚"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࠩ㉛")+type+l1l111_l1_ (u"ࠬࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㉜")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㉝")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡵࡪࡲࡨ࠿࡛ࠦࠡࠩ㉞")+method+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫ㉟")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡅࡣࡷࡥ࠿࡛ࠦࠡࠩ㉠")+l1l11llll_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㉡"))
	return
def l1l11l11111_l1_(method,url,data=l1l111_l1_ (u"ࠫࠬ㉢"),headers=l1l111_l1_ (u"ࠬ࠭㉣"),source=l1l111_l1_ (u"࠭ࠧ㉤")):
	l1l1ll1111l_l1_(l1l111_l1_ (u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡑࡓࡉࡓࡥࡕࡓࡎࠪ㉥"),url,data,headers,source,method)
	if kodi_version>18.99: import urllib.request as l1l1lll11l1_l1_
	else: import urllib2 as l1l1lll11l1_l1_
	if not headers: headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㉦"):l1l111_l1_ (u"ࠩࠪ㉧")}
	if not data: data = {}
	if method==l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㉨"):
		url = url+l1l111_l1_ (u"ࠫࡄ࠭㉩")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㉪") and l1l111_l1_ (u"࠭ࡪࡴࡱࡱࠫ㉫") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㉬"))
	elif method==l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㉭"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㉮"))
	try:
		req = l1l1lll11l1_l1_.Request(url,headers=headers,data=data)
		response = l1l1lll11l1_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"ࠪࡓࡐ࠭㉯")
	except:
		html = l1l111_l1_ (u"ࠫࠬ㉰")
		code,reason = -1,l1l111_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ㉱")
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㉲"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠤࠥࡘࡅࡔࡒࡒࡒࡘࡋࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ㉳")+str(code)+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㉴")+reason+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㉵")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㉶")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㉷"))
	if html and kodi_version>18.99: html = html.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㉸"))
	return html
def l1ll1111111_l1_(l1l11lll111_l1_,l1l11lll11l_l1_=l1l111_l1_ (u"࠭ࠧ㉹")):
	l1l11ll1ll1_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㉺"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ㉻")}
	l1l111ll11l_l1_ = {	l1l111_l1_ (u"ࠤࡸࡷࡪࡸ࡟ࡪࡦࠥ㉼"):l1l1ll1l11l_l1_(32),
				l1l111_l1_ (u"ࠥࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ㉽"):str(kodi_version),
				l1l111_l1_ (u"ࠦࡦࡶࡰࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ㉾"):l1l11ll1111_l1_,
				l1l111_l1_ (u"ࠧࡪࡥࡷ࡫ࡦࡩࡤ࡬ࡡ࡮࡫࡯ࡽࠧ㉿"):l1l11ll1111_l1_,
				l1l111_l1_ (u"ࠨࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠥ㊀"):l1l11lll111_l1_,
				l1l111_l1_ (u"ࠢࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ㊁"):{l1l111_l1_ (u"ࠣࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ㊂"):l1l11lll111_l1_},
				l1l111_l1_ (u"ࠤࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ㊃"): {l1l111_l1_ (u"࡙ࠥࡸ࡫ࡲࡠࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ㊄"):l1l11lll111_l1_},
				l1l111_l1_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ㊅"): l1l111_l1_ (u"ࠧࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࠧ㊆"),
				l1l111_l1_ (u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧࠧ㊇"):False,
				l1l111_l1_ (u"ࠢࡪࡲࠥ㊈"): l1l111_l1_ (u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ㊉")
			}
	if not l1l11lll11l_l1_: l1l11l1l11l_l1_ = [l1l111ll11l_l1_]
	else:
		l1l111ll1l1_l1_ = l1l111ll11l_l1_.copy()
		l1l111ll1l1_l1_[l1l111_l1_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭㊊")] = l1l11lll11l_l1_
		l1l111ll1l1_l1_[l1l111_l1_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭㊋")] = {l1l111_l1_ (u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ㊌"):l1l11lll11l_l1_}
		l1l111ll1l1_l1_[l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ㊍")] = {l1l111_l1_ (u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ㊎"):l1l11lll11l_l1_}
		l1l11l1l11l_l1_ = [l1l111ll11l_l1_,l1l111ll1l1_l1_]
	data = {l1l111_l1_ (u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣ㊏"):l1l111_l1_ (u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭㊐"),
			l1l111_l1_ (u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ㊑"):l1l11ll1ll1_l1_,
			l1l111_l1_ (u"ࠥࡩࡻ࡫࡮ࡵࡵࠥ㊒"): l1l11l1l11l_l1_
		}
	url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭㊓")
	html = l1l11l11111_l1_(l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㊔"),url,data,headers,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㊕"))
	return html
def l1ll1l1_l1_(l1l1ll11111_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠧ࡯ࡷ࡯ࡰࠬ㊖"),l1l111_l1_ (u"ࠨࡐࡲࡲࡪ࠭㊗"))
	text = text.replace(l1l111_l1_ (u"ࠩࡷࡶࡺ࡫ࠧ㊘"),l1l111_l1_ (u"ࠪࡘࡷࡻࡥࠨ㊙"))
	text = text.replace(l1l111_l1_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ㊚"),l1l111_l1_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ㊛"))
	text = text.replace(l1l111_l1_ (u"࠭࡜࠰ࠩ㊜"),l1l111_l1_ (u"ࠧ࠰ࠩ㊝"))
	try: l1ll1lll11_l1_ = eval(text)
	except: l1ll1lll11_l1_ = l1l1l1l1l1l_l1_(l1l1ll11111_l1_)
	return l1ll1lll11_l1_
def l1l1ll111ll_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ㊞"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ㊟"),time.localtime(now))
	name = name+datetime
	l1lll111lll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_
	if os.path.exists(l1l1l1l1111_l1_):
		l1l11llllll_l1_ = open(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠪࡶࡧ࠭㊠")).read()
		if kodi_version>18.99: l1l11llllll_l1_ = l1l11llllll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㊡"))
		l1l11llllll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㊢"),l1l11llllll_l1_)
	else: l1l11llllll_l1_ = {}
	l1l11ll111l_l1_ = {}
	for l1l1lll1l1l_l1_ in list(l1l11llllll_l1_.keys()):
		if l1l1lll1l1l_l1_!=type: l1l11ll111l_l1_[l1l1lll1l1l_l1_] = l1l11llllll_l1_[l1l1lll1l1l_l1_]
		else:
			if name and name!=l1l111_l1_ (u"࠭࠮࠯ࠩ㊣"):
				l1l11l1ll1l_l1_ = l1l11llllll_l1_[l1l1lll1l1l_l1_]
				if l1lll111lll_l1_ in l1l11l1ll1l_l1_:
					index = l1l11l1ll1l_l1_.index(l1lll111lll_l1_)
					del l1l11l1ll1l_l1_[index]
				l111l1l1ll_l1_ = [l1lll111lll_l1_]+l1l11l1ll1l_l1_
				l111l1l1ll_l1_ = l111l1l1ll_l1_[:50]
				l1l11ll111l_l1_[l1l1lll1l1l_l1_] = l111l1l1ll_l1_
			else: l1l11ll111l_l1_[l1l1lll1l1l_l1_] = l1l11llllll_l1_[l1l1lll1l1l_l1_]
	if type not in list(l1l11ll111l_l1_.keys()): l1l11ll111l_l1_[type] = [l1lll111lll_l1_]
	l1l11ll111l_l1_ = str(l1l11ll111l_l1_)
	if kodi_version>18.99: l1l11ll111l_l1_ = l1l11ll111l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㊤"))
	open(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠨࡹࡥࠫ㊥")).write(l1l11ll111l_l1_)
	return
def l1lll11111l_l1_(l1lll11111_l1_,table,l1l1l1l1ll1_l1_,data,l1l1l1llll1_l1_,l1l1lll111l_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㊦"))
	if cache==l1l111_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ㊧") and l1l1l1llll1_l1_>l1l11l1llll_l1_: l1l1l1llll1_l1_ = l1l11l1llll_l1_
	if l1l1lll111l_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l11l111l_l1_ in range(len(l1l1l1l1ll1_l1_)):
			text = pickle.dumps(data[l1l11l111l_l1_])
			l1l11ll11ll_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l1l1ll1_l1_[l1l11l111l_l1_],))
			l1l11ll1l_l1_.append((l1l1l1llll1_l1_+now,str(l1l1l1l1ll1_l1_[l1l11l111l_l1_]),l1l11ll11ll_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l1ll1ll_l1_ = zlib.compress(text)
	try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
	except: return
	while True:
		try:
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭㊨"))
			break
		except: time.sleep(0.5)
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㊩")+table+l1l111_l1_ (u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪ㊪"))
	if l1l1lll111l_l1_:
		l1lllll1l1_l1_.executemany(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㊫")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㊬"),l1l11ll11_l1_)
		l1lllll1l1_l1_.executemany(l1l111_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ㊭")+table+l1l111_l1_ (u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ㊮"),l1l11ll1l_l1_)
	else:
		if l1l1l1llll1_l1_:
			tt = (str(l1l1l1l1ll1_l1_),)
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㊯")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㊰"),tt)
			tt = (l1l1l1llll1_l1_+now,str(l1l1l1l1ll1_l1_),l1l1l1ll1ll_l1_)
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭㊱")+table+l1l111_l1_ (u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ㊲"),tt)
		else:
			tt = (l1l1l1ll1ll_l1_,str(l1l1l1l1ll1_l1_))
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ㊳")+table+l1l111_l1_ (u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㊴"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l1lllll11_l1_
	else: import urllib as l1l1lllll11_l1_
	l1ll1111l11_l1_ = l1l1lllll11_l1_.urlencode(data)
	return l1ll1111l11_l1_
l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠪࠫ㊵")
def l1llll111_l1_(l1llllll_l1_,l1ll1ll11ll_l1_=l1l111_l1_ (u"ࠫࠬ㊶"),l1l111lll11_l1_=l1l111_l1_ (u"ࠬ࠭㊷")):
	l1l1ll111l1_l1_ = l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"࠭ࡍ࠴ࡗࠪ㊸"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㊹")]
	global l1l1lll1lll_l1_
	if not l1l111lll11_l1_: l1l111lll11_l1_ = l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㊺")
	l1l1lll1lll_l1_,l1l1l111ll1_l1_,httpd = l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ㊻"),l1l111_l1_ (u"ࠪࠫ㊼"),l1l111_l1_ (u"ࠫࠬ㊽")
	if len(l1llllll_l1_)==3:
		url,l1l1l11lll1_l1_,httpd = l1llllll_l1_
		if l1l1l11lll1_l1_: l1l1l111ll1_l1_ = l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ㊾")+l1l1l11lll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㊿")
	else: url,l1l1l11lll1_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠧࠨ㋀"),l1l111_l1_ (u"ࠨࠩ㋁")
	url = url.replace(l1l111_l1_ (u"ࠩࠨ࠶࠵࠭㋂"),l1l111_l1_ (u"ࠪࠤࠬ㋃"))
	l11ll1l11l_l1_ = l1l111ll1l_l1_(url,l1ll1ll11ll_l1_)
	if l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㋄"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ㋅")]:
		if l1ll1ll11ll_l1_!=l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㋆"): url = url.replace(l1l111_l1_ (u"ࠧࠡࠩ㋇"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ㋈"))
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㋉"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㋊")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㋋")+l1l1l111ll1_l1_)
		if l11ll1l11l_l1_==l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㋌") and l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㋍"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㋎")]:
			headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㋏"):l1l111_l1_ (u"ࠩࠪ㋐")}
			from LIBSTWO import l1l11l1ll1_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ㋑")+str(count)+l1l111_l1_ (u"๋ࠫࠥไโࠫࠪ㋒"), l1l1lll1_l1_)
				if l11l11l_l1_ == -1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอุ฿๐ไࠨ㋓"),l1l111_l1_ (u"࠭ࠧ㋔"))
					return l1l1lll1lll_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠧ࠮࠳ࠪ㋕"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㋖"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ㋗")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋘")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㋙"))
		if l1l111_l1_ (u"ࠬ࠵ࡩࡧ࡫࡯ࡱ࠴࠭㋚") in url: url = url+l1l111_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㋛")
		elif l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ㋜") in url.lower() and l1l111_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ㋝") not in url and l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ㋞") not in url:
			if l1l111_l1_ (u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࠨ㋟") not in url and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭㋠") in url.lower():
				if l1l111_l1_ (u"ࠬࢂࠧ㋡") not in url: url = url+l1l111_l1_ (u"࠭ࡼࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪ㋢")
				else: url = url+l1l111_l1_ (u"ࠧࠧࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫ㋣")
			if l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ㋤") not in url.lower() and l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㋥"),l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ㋦")]:
				if l1l111_l1_ (u"ࠫࢁ࠭㋧") not in url: url = url+l1l111_l1_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬ㋨")
				else: url = url+l1l111_l1_ (u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㋩")
	l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㋪"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡨ࡬ࡲࡦࡲࠠࡶࡴ࡯ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㋫")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㋬"))
	l1l11l1111l_l1_ = xbmcgui.ListItem()
	l1l111lll11_l1_,l1l1l111l11_l1_,l1l1l1ll1l1_l1_,l1l11l111ll_l1_,l1l1ll11lll_l1_,l1l111lll1l_l1_,l1l1l1111ll_l1_,l1l1l11111l_l1_,l1l1l1l111l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㋭"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㋮")]:
		if kodi_version<19: l1l11l111l1_l1_ = l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࡤࡨࡩࡵ࡮ࠨ㋯")
		else: l1l11l111l1_l1_ = l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࠫ㋰")
		l1l11l1111l_l1_.setProperty(l1l11l111l1_l1_, l1l111_l1_ (u"ࠧࠨ㋱"))
		l1l11l1111l_l1_.setMimeType(l1l111_l1_ (u"ࠨ࡯࡬ࡱࡪ࠵ࡸ࠮ࡶࡼࡴࡪ࠭㋲"))
		if kodi_version<20: l1l11l1111l_l1_.setInfo(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㋳"),{l1l111_l1_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭㋴"):l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ㋵")})
		else:
			l1l1l1l11l1_l1_ = l1l11l1111l_l1_.getVideoInfoTag()
			l1l1l1l11l1_l1_.setMediaType(l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ㋶"))
		l1l11l1111l_l1_.setArt({l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦࠬ㋷"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧ㋸"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲࠨ㋹"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ㋺"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬ㋻"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ㋼"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ㋽"):l1l1ll11lll_l1_,l1l111_l1_ (u"࠭ࡩࡤࡱࡱࠫ㋾"):l1l1ll11lll_l1_})
		if l11ll1l11l_l1_ in [l1l111_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ㋿"),l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㌀")]: l1l11l1111l_l1_.setContentLookup(True)
		else: l1l11l1111l_l1_.setContentLookup(False)
		from l1l1l11ll11_l1_ import l1l1ll11l11_l1_
		if l1l111_l1_ (u"ࠩࡵࡸࡲࡶࠧ㌁") in url:
			l1l1ll11l11_l1_(l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭㌂"),False)
		elif l11ll1l11l_l1_==l1l111_l1_ (u"ࠫ࠳ࡳࡰࡥࠩ㌃") or l1l111_l1_ (u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ㌄") in url:
			l1l1ll11l11_l1_(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㌅"),False)
			l1l11l1111l_l1_.setProperty(l1l11l111l1_l1_,l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㌆"))
			l1l11l1111l_l1_.setProperty(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨ㌇"),l1l111_l1_ (u"ࠩࡰࡴࡩ࠭㌈"))
		if l1l1l11lll1_l1_:
			l1l11l1111l_l1_.setSubtitles([l1l1l11lll1_l1_])
	if l1l111lll11_l1_==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㌉") and l1ll1ll11ll_l1_==l1l111_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㌊"):
		l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㌋")
		l1ll1ll11ll_l1_ = l1l111_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡉࡒ࡟ࡇࡋࡏࡉࡘ࠭㌌")
	elif l1l111lll11_l1_==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㌍") and l1l1l11111l_l1_.startswith(l1l111_l1_ (u"ࠨ࠸ࠪ㌎")):
		l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㌏")
		l1ll1ll11ll_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠪࡣࡉࡒࠧ㌐")
	if l1l1lll1lll_l1_!=l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㌑"): l1l1ll111ll_l1_()
	l1l1l11l111_l1_ = l1l1l1lll1l_l1_()
	l1l1l11l111_l1_.init(l1ll1ll11ll_l1_)
	if l1l1l11l111_l1_.l1l1lll1lll_l1_: l1l1lll1lll_l1_ == l1l111_l1_ (u"ࠬ࠭㌒")
	elif l1l111lll11_l1_==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㌓") and not l1l1l11111l_l1_.startswith(l1l111_l1_ (u"ࠧ࠷ࠩ㌔")):
		l1l11l1111l_l1_.setPath(url)
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㌕"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌖")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㌗"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l11l1111l_l1_)
	elif l1l111lll11_l1_==l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㌘"):
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㌙"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌚")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㌛"))
		l1l1l11l111_l1_.play(url,l1l11l1111l_l1_)
	succeeded = False
	if l1l1lll1lll_l1_==l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㌜"):
		from l11lll1l11_l1_ import l11lll111l_l1_
		succeeded = l11lll111l_l1_(url,l11ll1l11l_l1_,l1ll1ll11ll_l1_)
		if succeeded: l1l1ll111ll_l1_()
	else:
		l1l111ll1ll_l1_,l1l1lll1lll_l1_,l1l1lllllll_l1_,delay = 0,l1l111_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ㌝"),False,2
		if l1l1ll111l1_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l111ll1ll_l1_<30:
			l1l1lll1lll_l1_ = l1l1l11l111_l1_.l1l1lll1lll_l1_
			if l1l1lll1lll_l1_==l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ㌞") and not l1l1lllllll_l1_:
				if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์๋่ࠥอ๊าࠫ㌟"),l1l111_l1_ (u"ࠬ࠭㌠"),time=500)
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㌡"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㌢")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㌣")+l1l1l111ll1_l1_)
				l1l1lllllll_l1_ = True
			elif l1l1lll1lll_l1_ in [l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㌤"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ㌥")]:
				if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥ๐ูๆๆࠪ㌦"),l1l111_l1_ (u"ࠬ࠭㌧"),time=500)
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㌨"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㌩")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㌪")+l1l1l111ll1_l1_)
				break
			elif l1l1lll1lll_l1_==l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㌫"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㌬"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㌭")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㌮")+l1l1l111ll1_l1_)
				if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭วๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠪ㌯"),l1l111_l1_ (u"ࠧࠨ㌰"),time=500)
				break
			elif l1l1lll1lll_l1_==l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㌱"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㌲"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡥࡰࡴࡩ࡫ࡦࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㌳")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㌴"))
				break
			xbmc.sleep(delay*1000)
			l1l111ll1ll_l1_ += delay
		else:
			if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬอไโ์า๎ํࠦไๆࠢํ฽๊๊ࠧ㌵"),l1l111_l1_ (u"࠭ࠧ㌶"),time=500)
			l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㌷"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤ࡙࡯࡭ࡦࡱࡸࡸ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㌸")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㌹")+l1l1l111ll1_l1_)
			l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㌺")
	if l1l1lll1lll_l1_ in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㌻"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㌼"),l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㌽")] or succeeded:
		if l1l1lll1lll_l1_==l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㌾"): l1ll1ll11ll_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠨࡡࡗࡗࠬ㌿")
		response = l1ll1111111_l1_(l1ll1ll11ll_l1_)
	else: exec(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩ㍀"))
	return l1l1lll1lll_l1_
def l1l111ll1l_l1_(url,l1l11l11_l1_=l1l111_l1_ (u"ࠪࠫ㍁")):
	l11ll1l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡢ࠮ࡢࡸ࡬ࢀࡡ࠴ࡴࡴࡾ࡟࠲ࡦࡧࡣࡽ࡞࠱ࡱࡵ࠺ࡼ࡝࠰ࡰ࠷ࡺࢂ࡜࠯࡯࠶ࡹ࠽ࢂ࡜࠯࡯ࡳࡨࢁࡢ࠮࡮࡭ࡹࢀࡡ࠴ࡦ࡭ࡸࡿࡠ࠳ࡳࡰ࠴ࡾ࡟࠲ࡼ࡫ࡢ࡮ࠫࠫࢀࡡࡅ࠮ࠫࡁࡿ࠳ࡡࡅ࠮ࠫࡁࡿࡠࢁ࠴ࠪࡀࠫࠧࠫ㍂"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11ll1l11l_l1_: l11ll1l11l_l1_ = l11ll1l11l_l1_[0][0]
	else: l11ll1l11l_l1_ = l1l111_l1_ (u"ࠬ࠭㍃")
	return l11ll1l11l_l1_
WRITE_TO_sSQL3 = l1lll11111l_l1_
READ_FROM_sSQL3 = l1lll11l11l_l1_
DELETE_FROM_sSQL3 = l1lll1ll111_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11lllll11_l1_
LOGg_THIS = l1l111111l_l1_
PLAY_VIDEOo = l1llll111_l1_
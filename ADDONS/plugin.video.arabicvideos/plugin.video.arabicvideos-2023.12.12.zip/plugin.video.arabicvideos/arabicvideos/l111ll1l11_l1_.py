# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭⃰")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡅࡃ࠴ࡢࠫ⃱")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧ⃲"),l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮ๊ิฬࠪ⃳"),l1l111_l1_ (u"ࠨ฻ิ์฻ࠦวๅ็ุหึ฿ษࠨ⃴"),l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ⃵"),l1l111_l1_ (u"ࠪห๏า๊ࠡสึฮࠥอไษัํ่ࠬ⃶"),l1l111_l1_ (u"ࠫฬ๐ฬ๊ࠢหืฯࠦวๅฮา๎ิ࠭⃷")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==780: l1lll_l1_ = l1l1l11_l1_()
	elif mode==781: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==782: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==783: l1lll_l1_ = PLAY(url)
	elif mode==784: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⃸")+text)
	elif mode==785: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⃹")+text)
	elif mode==786: l1lll_l1_ = l111l1111_l1_(url,l1llllll1_l1_)
	elif mode==789: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⃺"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⃻"),l1l111_l1_ (u"ࠩࠪ⃼"),789,l1l111_l1_ (u"ࠪࠫ⃽"),l1l111_l1_ (u"ࠫࠬ⃾"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⃿"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ℀"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ℁"),l1l111_l1_ (u"ࠨࠩℂ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭℃"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ℄"),l1l111_l1_ (u"ࠫࠬ℅"),l1l111_l1_ (u"ࠬ࠭℆"),l1l111_l1_ (u"࠭ࠧℇ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ℈"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠳ࡰࡢࡩࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ℉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨℊ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬℋ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩℌ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬℍ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨℎ")+l1lllll_l1_+title,l1ll1ll_l1_,781)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬℏ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨℐ"),l1l111_l1_ (u"ࠩࠪℑ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡣࡵࡸ࡮ࡩ࡬ࡦࠪ࠱࠮ࡄ࠯ࡳࡰࡥ࡬ࡥࡱ࠳ࡢࡰࡺࠪℒ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ℓ"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ℔"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫℕ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ№"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ℗")+l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"ࠩࠪ℘"),l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࡮ࡧࡱࡹࠬℙ"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩℚ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬℛ"),l1l111_l1_ (u"࠭ࠧℜ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ℝ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ℞"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ℟"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ℠") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ℡"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ™")+l1lllll_l1_+title,l1ll1ll_l1_,781)
	return
def l111l1111_l1_(url,type=l1l111_l1_ (u"࠭ࠧ℣")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫℤ"),url,l1l111_l1_ (u"ࠨࠩ℥"),l1l111_l1_ (u"ࠩࠪΩ"),l1l111_l1_ (u"ࠪࠫ℧"),l1l111_l1_ (u"ࠫࠬℨ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ℩"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨK"),html,re.DOTALL)
	if l11llll_l1_:
		l111llll1l_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠧࠨÅ"),l1l111_l1_ (u"ࠨࠩℬ"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠩะ่็อสࠨℭ") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"้ࠪํอำๆࠩ℮") in name: l111llll1l_l1_ = block
		if l111llll1l_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫℯ"),l111llll1l_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬℰ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ℱ"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⅎ"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧℳ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨℴ"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩℵ"),l1lllll_l1_+title,l1ll1ll_l1_,783)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠫࠬℶ")):
	if l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩℷ") in type or l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ℸ") in type:
		l1lllll1_l1_,data = url.split(l1l111_l1_ (u"ࠧࡀࡵࡨࡴࡦࡸࡡࡵࡱࡵࠪࠬℹ"))
		headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ℺"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ℻")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨℼ"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"ࠫࠬℽ"),l1l111_l1_ (u"ࠬ࠭ℾ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬℿ"))
		html = response.content
		html = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰࡹࠧ⅀")+html+l1l111_l1_ (u"ࠨࡣࡵࡸ࡮ࡩ࡬ࡦࠩ⅁")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⅂"),url,l1l111_l1_ (u"ࠪࠫ⅃"),l1l111_l1_ (u"ࠫࠬ⅄"),l1l111_l1_ (u"ࠬ࠭ⅅ"),l1l111_l1_ (u"࠭ࠧⅆ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ⅇ"))
		html = response.content
	items,l111lllll1_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫⅈ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪⅉ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⅊"))
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⅋"),l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"ࠬ࠭⅌"),l1l111_l1_ (u"࠭ࡳࡶࡤࡰࡩࡳࡻࠧ⅍"))
				l111lllll1_l1_ = True
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢ࡮࡯࠱ࡹࡧࡸࡦࡵࠫ࠲࠯ࡅࠩࠣ࡮ࡲࡥࡩࠨࠧⅎ"),html,re.DOTALL)
		if l11llll_l1_ and type!=l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⅏"):
			if l111lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⅐"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⅑"),l1l111_l1_ (u"ࠫࠬ⅒"),9999)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅓"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ⅔"),url,785,l1l111_l1_ (u"ࠧࠨ⅕"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⅖"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⅗"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭⅘"),url,784,l1l111_l1_ (u"ࠫࠬ⅙"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⅚"))
			filters = True
	if not l111lllll1_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࡥࡷࡺࡩࡤ࡮ࡨࠫ⅛"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⅜"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠨ࡞ࡱࠫ⅝"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫ⅞") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⅟"),l1lllll_l1_+title,l1ll1ll_l1_,781,l1ll1l_l1_)
				elif l1l111_l1_ (u"ู๊ࠫไิๆࠪⅠ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬำไใหࠪⅡ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⅲ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠧๆ๊ึ้ࠬⅣ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨฯ็ๆฮ࠭Ⅴ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⅥ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩⅦ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
		length = 12 if l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫⅧ") in type else 16
		data = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࠮࡬ࡰࡣࡧ࠱ࡲࡵࡲࡦ࠰࠭ࡃ࠮ࠦ࠮ࠫࡁࡧࡥࡹࡧ࠭ࠩ࠰࠭ࡃ࠮ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⅨ"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪⅩ") in type):
			if data:
				offset = length
				action,name,value = data[0]
				action = action.replace(l1l111_l1_ (u"ࠧ࡭ࡱࡤࡨࠬⅪ"),l1l111_l1_ (u"ࠨࡩࡨࡸࠬⅫ")).replace(l1l111_l1_ (u"ࠩ࠰ࠫⅬ"),l1l111_l1_ (u"ࠪࡣࠬⅭ")).replace(l1l111_l1_ (u"ࠫࠧ࠭Ⅾ"),l1l111_l1_ (u"ࠬ࠭Ⅿ"))
			else:
				data = re.findall(l1l111_l1_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࠫࡵࡦࡧࡵࡨࡸࡂ࠮࠮ࠫࡁࠬࠪ࠭࠴ࠪࡀࠫࡀࠬ࠳࠰࠿ࠪࠦࠪⅰ"),url,re.DOTALL)
				if data: action,offset,name,value = data[0]
				offset = int(offset)+length
			data = l1l111_l1_ (u"ࠧࡢࡥࡷ࡭ࡴࡴ࠽ࠨⅱ")+action+l1l111_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪⅲ")+str(offset)+l1l111_l1_ (u"ࠩࠩࠫⅳ")+name+l1l111_l1_ (u"ࠪࡁࠬⅴ")+value
			url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࡢࡦࡰ࡭ࡳ࠳ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࡀࡵࡨࡴࡦࡸࡡࡵࡱࡵࠪࠬⅵ")+data
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⅶ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ี๎ิ࠭ⅷ"),url,781,l1l111_l1_ (u"ࠧࠨⅸ"),l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࡤ࠭ⅹ")+type)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ⅺ"),url,l1l111_l1_ (u"ࠪࠫⅻ"),l1l111_l1_ (u"ࠫࠬⅼ"),l1l111_l1_ (u"ࠬ࠭ⅽ"),l1l111_l1_ (u"࠭ࠧⅾ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫⅿ"))
	html = response.content
	l1ll11l1_l1_,l111l11l1_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬↀ"),html,re.DOTALL)
	for l111ll1l1l_l1_ in items:
		l111ll1lll_l1_ = base64.b64decode(l111ll1l1l_l1_)
		if kodi_version>18.99: l111ll1lll_l1_ = l111ll1lll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧↁ"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨↂ"),l111ll1lll_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩↃ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫↄ")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l111l11l1_l1_:
				l111l11l1_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫↅ"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨↆ")+server+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩↇ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠭ↈ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡩ࡯ࡶ࠿࡝ࠣࡥ࠲ࢀࡁ࠮࡜ࡠ࠮࠭ࡢࡤࡼ࠵࠯࠸ࢂ࠯࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࡤࡰࡹࡱࡰࡴࡧࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ↉"),block,re.DOTALL)
		for l111l1ll_l1_,l111lll1l1_l1_ in items:
			l1ll1ll_l1_ = base64.b64decode(l111lll1l1_l1_)
			if kodi_version>18.99: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ↊"))
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ↋") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ↌")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l111l11l1_l1_:
				l111l11l1_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ↍"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ↎")+server+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟ࡠࡡࠪ↏")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ←"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭↑"),l1l111_l1_ (u"ࠬ࠳ࠧ→"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧ࡫ࡱࡨ࠴ࡅࡱ࠾ࠩ↓")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ↔"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ↕"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭↖"),url,l1l111_l1_ (u"ࠪࠫ↗"),l1l111_l1_ (u"ࠫࠬ↘"),l1l111_l1_ (u"ࠬ࠭↙"),l1l111_l1_ (u"࠭ࠧ↚"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ↛"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࡦࡸࡴࡪࡥ࡯ࡩࠬ↜"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ↝"),block,re.DOTALL)
		l1111lll1_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111lll1_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ↞"),block,re.DOTALL)
	return items
def l1111l1l1_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸࠧ↟") not in url: l1lllll1_l1_,l111lll111_l1_ = url,l1l111_l1_ (u"ࠬ࠭↠")
	else: l1lllll1_l1_,l111lll111_l1_ = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩ↡"))
	l1llllll_l1_,l111lll11l_l1_ = l1ll11ll1_l1_(l111lll111_l1_)
	l111ll1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ↢")
	for key in list(l111lll11l_l1_.keys()):
		l111ll1ll1_l1_ += l1l111_l1_ (u"ࠨࠨࡤࡶ࡬ࡹࠥ࠶ࡄࠪ↣")+key+l1l111_l1_ (u"ࠩࠨ࠹ࡉࡃࠧ↤")+l111lll11l_l1_[key]
	l1111111_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ࠿ࡴࡧࡳࡥࡷࡧࡴࡰࡴࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟ࡧ࡫࡯ࡸࡪࡸࡤࡠࡤ࡯ࡳࡨࡱࡳࠨ↥")+l111ll1ll1_l1_
	return l1111111_l1_
l1111ll11_l1_ = [l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ↦"),l1l111_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ↧"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ↨"),l1l111_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ↩"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ↪"),l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ↫"),l1l111_l1_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ↬")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ↭"),l1l111_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ↮"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ↯")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ↰"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ↱"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ↲"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ↳"),l1l111_l1_ (u"ࠫࠬ↴")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ↵"))
	if type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ↶"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩ↷") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪ↸") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ↹")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭↺")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭↻")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨ↼")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ↽"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ↾")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ↿"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⇀"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⇁")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ⇂"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⇃"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⇄"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⇅")+l11lll11_l1_
		l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⇆"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ⇇"),l1llllll_l1_,781,l1l111_l1_ (u"ࠪࠫ⇈"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ⇉"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇊"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭⇋")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭⇌"),l1llllll_l1_,781,l1l111_l1_ (u"ࠨࠩ⇍"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⇎"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⇏"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⇐"),l1l111_l1_ (u"ࠬ࠭⇑"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"࠭ใๅࠢࠪ⇒"),l1l111_l1_ (u"ࠧࠨ⇓"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪ⇔") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⇕"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⇖"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⇗")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇘"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ⇙"),l1llllll_l1_,781,l1l111_l1_ (u"ࠧࠨ⇚"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⇛"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇜"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ⇝"),l1lllll1_l1_,785,l1l111_l1_ (u"ࠫࠬ⇞"),l1l111_l1_ (u"ࠬ࠭⇟"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ⇠"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ⇡")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ⇢")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ⇣")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭⇤")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ⇥")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇦"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨ⇧")+name,l1lllll1_l1_,784,l1l111_l1_ (u"ࠧࠨ⇨"),l1l111_l1_ (u"ࠨࠩ⇩"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ⇪")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ⇫")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭⇬")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ⇭")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ⇮")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ⇯")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪ⇰")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ⇱")+name
			if type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ⇲"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇳"),l1lllll_l1_+title,url,784,l1l111_l1_ (u"ࠬ࠭⇴"),l1l111_l1_ (u"࠭ࠧ⇵"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⇶") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪ⇷") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⇸"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⇹")+l11ll111_l1_
				l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇺"),l1lllll_l1_+title,l1llllll_l1_,781,l1l111_l1_ (u"ࠬ࠭⇻"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⇼"))
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⇽"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⇾"),l1lllll_l1_+title,url,785,l1l111_l1_ (u"ࠩࠪ⇿"),l1l111_l1_ (u"ࠪࠫ∀"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠫࡂࠬࠧ∁"),l1l111_l1_ (u"ࠬࡃ࠰ࠧࠩ∂"))
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠨ∃"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠧ࠾ࠩ∄") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠪ∅"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࠫ∆"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠪࠫ∇")
	for key in l1111ll11_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭∈")
		if l1l111_l1_ (u"ࠬࠫࠧ∉") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ∊") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ∋"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ∌")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ∍") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ∎"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭∏")+key+l1l111_l1_ (u"ࠬࡃࠧ∐")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ∑"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ−")+key+l1l111_l1_ (u"ࠨ࠿ࠪ∓")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭∔"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬ∕"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠫࡂ࠶ࠧ∖"),l1l111_l1_ (u"ࠬࡃࠧ∗"))
	return l1l1l111_l1_
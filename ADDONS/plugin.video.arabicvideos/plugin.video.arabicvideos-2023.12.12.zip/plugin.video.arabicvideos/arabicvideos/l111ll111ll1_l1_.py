# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ庺")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ庻")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l111llll11ll_l1_(url)
	elif mode==146: l1lll_l1_ = l111l1llll1l_l1_(url)
	elif mode==147: l1lll_l1_ = l111lll11l11_l1_()
	elif mode==148: l1lll_l1_ = l111lll11ll1_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ庼"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ庽"),l1l111_l1_ (u"࠭ࠧ庾"),149,l1l111_l1_ (u"ࠧࠨ庿"),l1l111_l1_ (u"ࠨࠩ廀"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭廁"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廂"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廃")+l1l111_l1_ (u"ࠬࡥ࡙ࡕࡅࡢࠫ廄")+l1l111_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬࠦวๅ็หี๊าࠧ廅"),l1l111_l1_ (u"ࠧࠨ廆"),290)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廇"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廈")+l1lllll_l1_+l1l111_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣ๎ํะ๊้สࠪ廉"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ廊"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廋"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廌")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ廍"),l111l1_l1_,144,l1l111_l1_ (u"ࠨࠩ廎"),l1l111_l1_ (u"ࠩࠪ廏"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ廐"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廑"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廒")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ะฮํ๏ࠠศๆิหหาࠧ廓"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ廔"),146)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭廕"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ廖"),l1l111_l1_ (u"ࠪࠫ廗"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廘"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廙")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ廚"),l1l111_l1_ (u"ࠧࠨ廛"),147)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廜"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廝")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ廞"),l1l111_l1_ (u"ࠫࠬ廟"),148)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廠"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廡")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ廢"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ廣"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廤"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廥")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ廦"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ廧"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廨"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廩")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭廪"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ廫"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廬"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廭")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ廮"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ廯"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廰"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廱")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ廲"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ廳"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廴"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廵")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ延"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭廷"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廸"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廹")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ建"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ廻"),144)
	return
def l111lll11l11_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯อัࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ廼"))
	return
def l111lll11ll1_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡵࡸࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ廽"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111l1llll1l_l1_(url):
	html,l1lllll1l1_l1_,data = l111lll11111_l1_(url)
	dd = l1lllll1l1_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ廾")][l1l111_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ廿")][l1l111_l1_ (u"ࠩࡷࡥࡧࡹࠧ开")]
	for l1l11l111l_l1_ in range(len(dd)):
		item = dd[l1l11l111l_l1_]
		l111ll1l1111_l1_(item,url,str(l1l11l111l_l1_))
	l111ll111l11_l1_ = dd[0][l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ弁")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ异")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ弃")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ弄")]
	s = 0
	for l1l11l111l_l1_ in range(len(l111ll111l11_l1_)):
		item = l111ll111l11_l1_[l1l11l111l_l1_][l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭弅")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ弆")][0]
		if list(item[l1l111_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩ弇")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ弈")].keys())[0]==l1l111_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭弉"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1ll11_l1_,l111lll1111l_l1_ = l111llll1lll_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠาษษะฮࠦࠧ弊")+str(s)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弋"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠧࠨ弌"),str(l1l11l111l_l1_))
	key = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭弍"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ弎")+key[0]
	html,l1lllll1l1_l1_,l1l11llll_l1_ = l111lll11111_l1_(l1lllll1_l1_)
	for l1lll1ll1111_l1_ in range(3,4):
		dd = l1lllll1l1_l1_[l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ式")][l1lll1ll1111_l1_][l1l111_l1_ (u"ࠫ࡬ࡻࡩࡥࡧࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ弐")][l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ弑")]
		for l1l11l111l_l1_ in range(len(dd)):
			item = dd[l1l11l111l_l1_]
			if l1l111_l1_ (u"࡙࠭ࡰࡷࡗࡹࡧ࡫ࠠࡑࡴࡨࡱ࡮ࡻ࡭ࠨ弒") in str(item): continue
			l111ll1l1111_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠧࠨ弓"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ弔"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭引"),l1l111_l1_ (u"ࠪࠫ弖"))
	html,l1lllll1l1_l1_,l1l11llll_l1_ = l111lll11111_l1_(url,data)
	l1l11lll11_l1_,l111l1lll1ll_l1_ = l1l111_l1_ (u"ࠫࠬ弗"),l1l111_l1_ (u"ࠬ࠭弘")
	owner = re.findall(l1l111_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࡔࡡ࡮ࡧࠥ࠲࠯ࡅࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ弙"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠧࠣࡸ࡬ࡨࡪࡵࡏࡸࡰࡨࡶࠧ࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ弚"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡐࡩࡹࡧࡤࡢࡶࡤࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࡯ࡸࡰࡨࡶ࡚ࡸ࡬ࡴࠤ࠽ࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧ࠭弛"),html,re.DOTALL)
	if owner:
		l1l11lll11_l1_ = l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ弜")+owner[0][0]+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ弝")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ弞") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ弟") in url: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭张"),l1lllll_l1_+l1l11lll11_l1_,l1ll1ll_l1_,144)
	l111ll11111l_l1_ = [l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ弡"),l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ弢"),l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ弣"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ弤"),l1l111_l1_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ弥"),l1l111_l1_ (u"ࠬࡹࡳ࠾ࠩ弦"),l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ弧"),l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ弨"),l1l111_l1_ (u"ࠨࡤࡳࡁࠬ弩"),l1l111_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࡁࠬ弪")]
	l111l1lll1l1_l1_ = not any(value in url for value in l111ll11111l_l1_)
	if l111l1lll1l1_l1_ and l1l11lll11_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠪห้ฮอฬࠩ弫")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠫ็๎วว็ࠣห้ะิ฻์็ࠫ弬")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠬอไโ์า๎ํํวหࠩ弭")
		l111l1llll11_l1_ = l1l111_l1_ (u"࠭วๅไ้์ฬะࠧ弮")
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ弯"),l1lllll_l1_+l1l11lll11_l1_,url,9999)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥฬาัࠢࠨ弰") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弱"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠪࠫ弲"),l1l111_l1_ (u"ࠫࠬ弳"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ弴"))
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣไ๋หห๋ࠠศๆอุ฿๐ไࠣࠩ張") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弶"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ強"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠣࠩ弸") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弹"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ强"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ弻") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弼"),l1lllll_l1_+l111l1llll11_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ弽"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡗࡪࡧࡲࡤࡪࠥࠫ弾") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弿"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠪࠫ彀"),l1l111_l1_ (u"ࠫࠬ彁"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ彂"))
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶࡶࠦࠬ彃") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ彄"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ彅"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ彆") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彇"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ彈"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡄࡪࡤࡲࡳ࡫࡬ࡴࠤࠪ彉") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彊"),l1lllll_l1_+l111l1llll11_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ彋"),144)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭彌"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ彍"),l1l111_l1_ (u"ࠪࠫ彎"),9999)
	if l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ彏") in url:
		dd = l1lllll1l1_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ彐")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ彑")][l1l111_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ归")][l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ当")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ彔")]
		l111l1lll111_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ录") in list(dd[i].keys()):
				l111l1ll1lll_l1_ = dd[i][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彖")]
				length = len(str(l111l1ll1lll_l1_))
				if length>l111l1lll111_l1_:
					l111l1lll111_l1_ = length
					l111l1lll1ll_l1_ = l111l1ll1lll_l1_
		if l111l1lll111_l1_==0: return
	elif l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ彗") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ彘") in url or l1l111_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭彙") in url or l1l111_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ彚") in url or l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ彛") in url or url==l111l1_l1_:
		l111ll11llll_l1_ = []
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡈࡵ࡭࡮ࡣࡱࡨࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ彜"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ彝"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ彞"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡨࡴ࡬ࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ彟"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࠧ彠"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠰࠵ࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ彡"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ形"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡘࡣࡷࡧ࡭ࡔࡥࡹࡶࡕࡩࡸࡻ࡬ࡵࡵࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭࡝ࠣ彣"))
		l111ll111111_l1_,l111l1lll1ll_l1_ = l111l1ll1ll1_l1_(l1lllll1l1_l1_,l1l111_l1_ (u"ࠫࠬ彤"),l111ll11llll_l1_)
	if not l111l1lll1ll_l1_:
		try:
			dd = l1lllll1l1_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ彥")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ彦")][l1l111_l1_ (u"ࠧࡵࡣࡥࡷࠬ彧")]
			l1llll11ll1l_l1_ = l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ彨") in url or l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭彩") in url or l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭彪") in url
			l111ll11l11l_l1_ = l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ彫") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ彬") in html or l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๆ๋๎วหࠤࠪ彭") in html
			l111ll11l111_l1_ = l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ彮") in html or l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ彯") in html or l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ彰") in html
			if l1llll11ll1l_l1_ and (l111ll11l11l_l1_ or l111ll11l111_l1_):
				for l1l11l111l_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ影") not in list(dd[l1l11l111l_l1_].keys()): continue
					l111ll111l11_l1_ = dd[l1l11l111l_l1_][l1l111_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ彲")]
					try: l111l1llllll_l1_ = l111ll111l11_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭彳")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ彴")][l1l111_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ彵")][l1l111_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彶")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡗࡽࡵ࡫ࡓࡶࡤࡐࡩࡳࡻࡉࡵࡧࡰࡷࠬ彷")][l1l11l111l_l1_]
					except: l111l1llllll_l1_ = l111ll111l11_l1_
					try: l1ll1ll_l1_ = l111l1llllll_l1_[l1l111_l1_ (u"ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬ彸")][l1l111_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭役")][l1l111_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ彺")][l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ彻")]
					except: continue
					if   l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ彼")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ彽")		in url: l111ll111l11_l1_ = dd[l1l11l111l_l1_] ; break
					elif l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭彾")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ彿")	in url: l111ll111l11_l1_ = dd[l1l11l111l_l1_] ; break
					elif l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ往")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ征")		in url: l111ll111l11_l1_ = dd[l1l11l111l_l1_] ; break
					else: l111ll111l11_l1_ = dd[0]
			elif l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ徂") in url: l111ll111l11_l1_ = dd[index]
			else: l111ll111l11_l1_ = dd[0]
			l111l1lll1ll_l1_ = l111ll111l11_l1_[l1l111_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ徃")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ径")]
		except: pass
	if not l111l1lll1ll_l1_: return
	l111ll11llll_l1_ = []
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ待"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ徆"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ徇"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ很"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ徉"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ徊"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ律"))
	if l1l111_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ後") not in url: l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪࡡࡠ࠭ࡣࡩࡣࡱࡲࡪࡲࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ࡞ࠤ徍"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ徎"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ徏"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ徐"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ徑"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ徒"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ従"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ徔"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ徕"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦࠣ徖"))
	l11l11lll11_l1_ = l111ll1l11l_l1_(l1l111_l1_ (u"ࡻࠧไๆࠣๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ得"))
	l11l11lll1l_l1_ = l111ll1l11l_l1_(l1l111_l1_ (u"ࡵࠨๅ็ࠤฬ๊แ๋ัํ์์อสࠨ徘"))
	l111l1lllll1_l1_ = l111ll1l11l_l1_(l1l111_l1_ (u"ࡶࠩๆ่ࠥอไใ่๋หฯ࠭徙"))
	l1l11lllll11_l1_ = [l11l11lll11_l1_,l11l11lll1l_l1_,l111l1lllll1_l1_,l1l111_l1_ (u"ࠩࡄࡰࡱࠦࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ徚"),l1l111_l1_ (u"ࠪࡅࡱࡲࠠࡷ࡫ࡧࡩࡴࡹࠧ徛"),l1l111_l1_ (u"ࠫࡆࡲ࡬ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ徜")]
	l111ll1111l1_l1_,l111l1llllll_l1_ = l111l1ll1ll1_l1_(l111l1lll1ll_l1_,index,l111ll11llll_l1_)
	if l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ徝") in str(type(l111l1llllll_l1_)) and any(value in str(l111l1llllll_l1_[0]) for value in l1l11lllll11_l1_): del l111l1llllll_l1_[0]
	for index2 in range(len(l111l1llllll_l1_)):
		l111ll11llll_l1_ = []
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ從"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ徟"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ徠"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ御"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ徢"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ徣"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ徤"))
		l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟ࠥ徥"))
		l111ll111111_l1_,item = l111l1ll1ll1_l1_(l111l1llllll_l1_,index2,l111ll11llll_l1_)
		l111ll1l1111_l1_(item,url,str(index2))
		if l111ll111111_l1_==l1l111_l1_ (u"ࠧ࠵ࠩ徦"):
			try:
				hh = item[l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ徧")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ徨")][l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ復")][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ循")]
				for l111ll1ll111_l1_ in range(len(hh)):
					l1l1l111lll1_l1_ = hh[l111ll1ll111_l1_]
					l111ll1l1111_l1_(l1l1l111lll1_l1_)
			except: pass
	l111lllll1_l1_ = False
	if l1l111_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ徫") not in url and l111ll1111l1_l1_==l1l111_l1_ (u"࠭࠸ࠨ徬"): l111lllll1_l1_ = True
	if l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ徭") in l1l11llll_l1_: l111lll1l1l1_l1_,key,l111l1lll11l_l1_,l111lll11l1l_l1_,token,l111lll111l1_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ微"))
	else: l111lll1l1l1_l1_,key,l111l1lll11l_l1_,l111lll11l1l_l1_,token,l111lll111l1_l1_ = l1l111_l1_ (u"ࠩࠪ徯"),l1l111_l1_ (u"ࠪࠫ徰"),l1l111_l1_ (u"ࠫࠬ徱"),l1l111_l1_ (u"ࠬ࠭徲"),l1l111_l1_ (u"࠭ࠧ徳"),l1l111_l1_ (u"ࠧࠨ徴")
	l1lllll1_l1_,l111l1lll1_l1_ = l1l111_l1_ (u"ࠨࠩ徵"),l1l111_l1_ (u"ࠩࠪ徶")
	if menuItemsLIST:
		l111ll111lll_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠪࡇࡍࡔࡌࠨ德") in l111ll111lll_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭徸")
		elif l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪ徹") in l111ll111lll_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ徺")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠧࡍࡋࡖࡘࠬ徻") in l111ll111lll_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠨࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ徼")
	if l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠥࠫ徽") in html and l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ徾") not in url and not l111lllll1_l1_ and l1l111_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩ࠭徿") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡥࡡ࡫ࡣࡻࡃࡨࡺ࡯࡬ࡧࡱࡁࠬ忀")+l111l1lll11l_l1_
	elif l1l111_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨࠧ忁") in html and l1l111_l1_ (u"ࠧࡣࡲࡀࠫ忂") not in url and l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ心") in url or l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ忄") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ必")+key
	elif l1l111_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ忆") in html and l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ忇") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ忈")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ忉"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ忊"),l1lllll1_l1_,144,l111l1lll1_l1_,l1l111_l1_ (u"ࠩࠪ忋"),l1l11llll_l1_)
	return
def l111l1ll1ll1_l1_(l1l1l1l1l1l1_l1_,l1l1l1ll11l1_l1_,l111ll1l1l1l_l1_):
	l1lllll1l1_l1_ = l1l1l1l1l1l1_l1_
	l111l1lll1ll_l1_,index = l1l1l1l1l1l1_l1_,l1l1l1ll11l1_l1_
	l111l1llllll_l1_,index2 = l1l1l1l1l1l1_l1_,l1l1l1ll11l1_l1_
	item,l111ll111l1l_l1_ = l1l1l1l1l1l1_l1_,l1l1l1ll11l1_l1_
	count = len(l111ll1l1l1l_l1_)
	for l1l11l111l_l1_ in range(count):
		try:
			out = eval(l111ll1l1l1l_l1_[l1l11l111l_l1_])
			return str(l1l11l111l_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠪࠫ忌"),l1l111_l1_ (u"ࠫࠬ忍")
def l111llll1lll_l1_(item):
	try: l111lll111ll_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠬ࠭忎"),l1l111_l1_ (u"࠭ࠧ忏"),l1l111_l1_ (u"ࠧࠨ忐"),l1l111_l1_ (u"ࠨࠩ忑"),l1l111_l1_ (u"ࠩࠪ忒"),l1l111_l1_ (u"ࠪࠫ忓"),l1l111_l1_ (u"ࠫࠬ忔")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1ll11_l1_,l111lll1111l_l1_ = False,l1l111_l1_ (u"ࠬ࠭忕"),l1l111_l1_ (u"࠭ࠧ忖"),l1l111_l1_ (u"ࠧࠨ志"),l1l111_l1_ (u"ࠨࠩ忘"),l1l111_l1_ (u"ࠩࠪ忙"),l1l111_l1_ (u"ࠪࠫ忚"),l1l111_l1_ (u"ࠫࠬ忛")
	l111ll111l1l_l1_ = item[l111lll111ll_l1_]
	l111ll11llll_l1_ = []
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ応"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ忝"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ忞"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ忟"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ忠"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ忡"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ忢"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ忣"))
	l111ll111111_l1_,title = l111l1ll1ll1_l1_(item,l111ll111l1l_l1_,l111ll11llll_l1_)
	l111ll11llll_l1_ = []
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ忤"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ忥"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ忦"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ忧"))
	l111ll111111_l1_,l1ll1ll_l1_ = l111l1ll1ll1_l1_(item,l111ll111l1l_l1_,l111ll11llll_l1_)
	l111ll11llll_l1_ = []
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ忨"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ忩"))
	l111ll111111_l1_,l1ll1l_l1_ = l111l1ll1ll1_l1_(item,l111ll111l1l_l1_,l111ll11llll_l1_)
	l111ll11llll_l1_ = []
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࠪࡡࠧ忪"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࡘࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ快"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡂࡰࡶࡷࡳࡲࡖࡡ࡯ࡧ࡯ࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ忬"))
	l111ll111111_l1_,count = l111l1ll1ll1_l1_(item,l111ll111l1l_l1_,l111ll11llll_l1_)
	l111ll11llll_l1_ = []
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡯ࡩࡳ࡭ࡴࡩࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ忭"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ忮"))
	l111ll11llll_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ忯"))
	l111ll111111_l1_,l1l1lll1ll_l1_ = l111l1ll1ll1_l1_(item,l111ll111l1l_l1_,l111ll11llll_l1_)
	if l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ忰") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1ll11_l1_ = l1l111_l1_ (u"ࠬ࠭忱"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ忲")
	if l1l111_l1_ (u"ࠧๆสสุึ࠭忳") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1ll11_l1_ = l1l111_l1_ (u"ࠨࠩ忴"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ念")
	if l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ忶") in list(l111ll111l1l_l1_.keys()):
		l111llll1111_l1_ = str(l111ll111l1l_l1_[l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ忷")])
		if l1l111_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ忸") in l111llll1111_l1_: l111lll1111l_l1_ = l1l111_l1_ (u"࠭ࠤ࠻ࠩ忹")
		if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠥࡔࡏࡘࠩ忺") in l111llll1111_l1_: l111lll1ll11_l1_ = l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ忻")
		if l1l111_l1_ (u"ࠩࡅࡹࡾ࠭忼") in l111llll1111_l1_ or l1l111_l1_ (u"ࠪࡖࡪࡴࡴࠨ忽") in l111llll1111_l1_: l111lll1111l_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠨ忾")
		if l111ll1l11l_l1_(l1l111_l1_ (u"ࡺ࠭ๅษษืีࠬ忿")) in l111llll1111_l1_: l111lll1ll11_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ怀")
		if l111ll1l11l_l1_(l1l111_l1_ (u"ࡵࠨึิหฦ࠭态")) in l111llll1111_l1_: l111lll1111l_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠬ怂")
		if l111ll1l11l_l1_(l1l111_l1_ (u"ࡷࠪหุะฦอษิࠫ怃")) in l111llll1111_l1_: l111lll1111l_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠧ怄")
		if l111ll1l11l_l1_(l1l111_l1_ (u"ࡹࠬหูๅษ้หฯ࠭怅")) in l111llll1111_l1_: l111lll1111l_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠨ怆")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ怇") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠧࡀࠩ怈"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭怉") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ怊")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111lll1111l_l1_: title = l111lll1111l_l1_+l1l111_l1_ (u"ࠪࠤࠥ࠭怋")+title
	l1l1lll1ll_l1_ = l1l1lll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࠱࠭怌"),l1l111_l1_ (u"ࠬ࠭怍"))
	count = count.replace(l1l111_l1_ (u"࠭ࠬࠨ怎"),l1l111_l1_ (u"ࠧࠨ怏"))
	count = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧ࠯ࠬ怐"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠩࠪ怑")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1ll11_l1_,l111lll1111l_l1_
def l111ll1l1111_l1_(item,url=l1l111_l1_ (u"ࠪࠫ怒"),index=l1l111_l1_ (u"ࠫࠬ怓")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1ll11_l1_,l111lll1111l_l1_ = l111llll1lll_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ怔") in str(item): return
	elif l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡖࡹࡷࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怕") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭怖") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ怗") in url or l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ怘") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠪࡁࡂࡃࠠࠨ怙")+title+l1l111_l1_ (u"ࠫࠥࡃ࠽࠾ࠩ怚")
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ怛"),l1lllll_l1_+title,l1l111_l1_ (u"࠭ࠧ怜"),9999)
	elif title and l1l111_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ思") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭怞"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ怟"),9999)
	elif l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ怠") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ怡"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l111lll1ll11_l1_: addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ怢"),l1lllll_l1_+l111lll1ll11_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ怣") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ怤") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ急") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ怦") not in l1ll1ll_l1_:
			l111lll1l111_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ性"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭怨")+l111lll1l111_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怩"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ怪")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ怫")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ怬"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ怭"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll1ll_l1_)
	else:
		type = l1l111_l1_ (u"ࠪࠫ怮")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ怯"),l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ怰"),l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ怱"),l1l111_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ怲"),l1l111_l1_ (u"ࠨࡵࡶࡁࠬ怳"),l1l111_l1_ (u"ࠩࡥࡴࡂ࠭怴")]):
			if l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭怵")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡩ࠯ࠨ怶") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠬࡉࡈࡏࡎࠪ怷")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ怸")
			if l1l111_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ怹") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠨࡗࡖࡉࡗ࠭怺")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭总")
			index,l111ll1111ll_l1_ = l1l111_l1_ (u"ࠪࠫ怼"),l1l111_l1_ (u"ࠫࠬ怽")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怾"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l111lll11111_l1_(url,data=l1l111_l1_ (u"࠭ࠧ怿"),request=l1l111_l1_ (u"ࠧࠨ恀")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ恁"))
	if request==l1l111_l1_ (u"ࠩࠪ恂"): request = l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ恃")
	l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ恄"):l11ll1l1l1_l1_,l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ恅"):l1l111_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ恆")}
	if l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ恇") in data: l111lll1l1l1_l1_,key,l111l1lll11l_l1_,l111lll11l1l_l1_,token,l111lll111l1_l1_ = data.split(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ恈"))
	else: l111lll1l1l1_l1_,key,l111l1lll11l_l1_,l111lll11l1l_l1_,token,l111lll111l1_l1_ = l1l111_l1_ (u"ࠩࠪ恉"),l1l111_l1_ (u"ࠪࠫ恊"),l1l111_l1_ (u"ࠫࠬ恋"),l1l111_l1_ (u"ࠬ࠭恌"),l1l111_l1_ (u"࠭ࠧ恍"),l1l111_l1_ (u"ࠧࠨ恎")
	if l1l111_l1_ (u"ࠨࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ恏") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ恐")] = {l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ恑"):{l1l111_l1_ (u"ࠦ࡭ࡲࠢ恒"):l1l111_l1_ (u"ࠧࡧࡲࠣ恓"),l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ恔"):l1l111_l1_ (u"ࠢࡘࡇࡅࠦ恕"),l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ恖"):l111lll11l1l_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ恗"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ恘"))
	elif l1l111_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ恙") in url and l111lll1l1l1_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ恚"):token}
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ恛")] = {l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ恜"):{l1l111_l1_ (u"ࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ恝"):l111lll1l1l1_l1_,l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ恞"):l1l111_l1_ (u"࡛ࠥࡊࡈࠢ恟"),l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ恠"):l111lll11l1l_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ恡"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠳ࡰࡧࠫ恢"))
	elif l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ恣") in url and l111lll111l1_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ恤"):l1l111_l1_ (u"ࠩ࠴ࠫ恥"),l1l111_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ恦"):l111lll11l1l_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ恧"):l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ恨")+l111lll111l1_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ恩"),url,l1l111_l1_ (u"ࠧࠨ恪"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ恫"),l1l111_l1_ (u"ࠩࠪ恬"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠸ࡸࡤࠨ恭"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ恮"),url,l1l111_l1_ (u"ࠬ࠭息"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ恰"),l1l111_l1_ (u"ࠧࠨ恱"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠷ࡸ࡭࠭恲"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ恳"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ恴"),html,re.DOTALL|re.I)
	if tmp: l111lll11l1l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ恵"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ恶"),html,re.DOTALL|re.I)
	if tmp: l111lll1l1l1_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ恷"),html,re.DOTALL|re.I)
	if tmp: l111l1lll11l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ恸") in list(cookies.keys()): l111lll111l1_l1_ = cookies[l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭恹")]
	data = l111lll1l1l1_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭恺")+key+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ恻")+l111l1lll11l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ恼")+l111lll11l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ恽")+token+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ恾")+l111lll111l1_l1_
	if request==l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ恿") and l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ悀") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ悁"),html,re.DOTALL)
		if not l11ll11l1l_l1_: l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ悂"),html,re.DOTALL)
		l111lll1llll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ悃"),l11ll11l1l_l1_[0])
	elif request==l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ悄") and l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ悅") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭悆"),html,re.DOTALL)
		l111lll1llll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ悇"),l11ll11l1l_l1_[0])
	elif l1l111_l1_ (u"ࠩ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ悈") not in html: l111lll1llll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ悉"),html)
	else: l111lll1llll_l1_ = l1l111_l1_ (u"ࠫࠬ悊")
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ悋"),data)
	return html,l111lll1llll_l1_,data
def l111llll11ll_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ悌"),l1l111_l1_ (u"ࠧࠬࠩ悍"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ悎")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ悏"),l1l111_l1_ (u"ࠪ࠯ࠬ悐"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ࠭悑")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨ悒") in options: l111ll1ll1l1_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡓࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭悓")
		elif l1l111_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭悔") in options: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ悕")
		elif l1l111_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ悖") in options: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆ࡭ࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ悗")
		l1llllll_l1_ = l1lllll1_l1_+l111ll1ll1l1_l1_
	else:
		l111ll1ll11l_l1_,l111ll11ll11_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠫࠬ悘")
		l111ll11lll1_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ悙"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ悚"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ悛"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ悜"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭悝")]
		l111lll1lll1_l1_ = [l1l111_l1_ (u"ࠪࠫ悞"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ悟"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ悠"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ悡"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭悢")]
		l111llll111l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ患"),l111ll11lll1_l1_)
		if l111llll111l_l1_ == -1: return
		l111ll1l1lll_l1_ = l111lll1lll1_l1_[l111llll111l_l1_]
		html,c,data = l111lll11111_l1_(l1lllll1_l1_+l111ll1l1lll_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ悤")][l1l111_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭悥")][l1l111_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭悦")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ悧")][l1l111_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ您")][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悩")][l1l111_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ悪")]
			for l111ll11l1ll_l1_ in range(len(d)):
				group = d[l111ll11l1ll_l1_][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ悫")][l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ悬")]
				for l111llll1l11_l1_ in range(len(group)):
					l111ll111l1l_l1_ = group[l111llll1l11_l1_][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ悭")]
					if l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ悮") in list(l111ll111l1l_l1_.keys()):
						l1ll1ll_l1_ = l111ll111l1l_l1_[l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ悯")][l1l111_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ悰")][l1l111_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭悱")][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭悲")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ悳"),l1l111_l1_ (u"ࠫࠫ࠭悴"))
						title = l111ll111l1l_l1_[l1l111_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭悵")]
						title = title.replace(l1l111_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ悶"),l1l111_l1_ (u"ࠧࠨ悷"))
						if l1l111_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ悸") in title: continue
						if l1l111_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ悹") in title:
							title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ悺")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ悻") in title: continue
						title = title.replace(l1l111_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ悼"),l1l111_l1_ (u"࠭ࠧ悽"))
						if l1l111_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ悾") in title: continue
						if l1l111_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ悿") in title:
							title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ惀")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ惁") in title: continue
						l111ll1ll11l_l1_.append(escapeUNICODE(title))
						l111ll11ll11_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l111lll1ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ惂")
		else:
			l111ll1ll11l_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ惃"),l1lllllll_l1_]+l111ll1ll11l_l1_
			l111ll11ll11_l1_ = [l1l111_l1_ (u"࠭ࠧ惄"),l111lllll_l1_]+l111ll11ll11_l1_
			l111llll1ll1_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ情"),l111ll1ll11l_l1_)
			if l111llll1ll1_l1_ == -1: return
			l111lll1ll1l_l1_ = l111ll11ll11_l1_[l111llll1ll1_l1_]
		if l111lll1ll1l_l1_: l1llllll_l1_ = l111l1_l1_+l111lll1ll1l_l1_
		elif l111ll1l1lll_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1l1lll_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
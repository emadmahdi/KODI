# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l1l1l1_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡊࡐࡌࡘࠬ揜")
l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ揝"),l1l111_l1_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠧ揞"))
l1lll111lll_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = l1lll111lll_l1_
l1ll1ll1lll1_l1_ = int(mode)
l1lll1llllll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ揟"))
l1lll1llllll_l1_ = l1lll1llllll_l1_.replace(ltr,l1l111_l1_ (u"ࠫࠬ揠")).replace(rtl,l1l111_l1_ (u"ࠬ࠭握"))
if l1ll1ll1lll1_l1_==260: message = l1l111_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ揢")+l1l11ll1111_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ揣")+l1l1l1l1l11_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ揤")
else:
	l111l1ll11ll_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ揥"),l1l111_l1_ (u"ࠪࠫ揦")).replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ揧"),l1l111_l1_ (u"ࠬ࠭揨"))
	l111l1ll11ll_l1_ = l111l1ll11ll_l1_.replace(l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ揩"),l1l111_l1_ (u"ࠧࠨ揪")).strip(l1l111_l1_ (u"ࠨࠢࠪ揫"))
	l111l1ll11ll_l1_ = l111l1ll11ll_l1_.replace(l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ揬"),l1l111_l1_ (u"ࠪࠤࠬ揭")).replace(l1l111_l1_ (u"ࠫࠥࠦࠠࠨ揮"),l1l111_l1_ (u"ࠬࠦࠧ揯")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ揰"),l1l111_l1_ (u"ࠧࠡࠩ揱"))
	message = l1l111_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ揲")+l1lll1llllll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ揳")+mode+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ援")+l111l1ll11ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ揵")
l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ揶"),l11lllll11_l1_(l1ll1_l1_)+message)
l1ll1l1lll1l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ揷"))
l111l1l1111_l1_ = False if l1ll1l1lll1l_l1_==l1l11ll1111_l1_ else True
if not l111l1l1111_l1_ and l1ll1ll1lll1_l1_ in [235,715]:
	l1l1l1111l11_l1_ = str(l1llllll11l_l1_[l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揸")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭揹") if l1ll1ll1lll1_l1_==235 else l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠭揺")
	l11ll1l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࠧ揻")+l1ll1_l1_+l1l111_l1_ (u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ揼")+l1l1l1111l11_l1_)
	l11lll1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࠩ揽")+l1ll1_l1_+l1l111_l1_ (u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ揾")+l1l1l1111l11_l1_)
	if l11ll1l1l1_l1_ or l11lll1ll1_l1_:
		url += l1l111_l1_ (u"ࠧࡽࠩ揿")
		if l11ll1l1l1_l1_: url += l1l111_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ搀")+l11ll1l1l1_l1_
		if l11lll1ll1_l1_: url += l1l111_l1_ (u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ搁")+l11lll1ll1_l1_
		url = url.replace(l1l111_l1_ (u"ࠪࢀࠫ࠭搂"),l1l111_l1_ (u"ࠫࢁ࠭搃"))
	l11l11ll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࠩ搄")+l1ll1_l1_+l1l111_l1_ (u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ搅")+l1l1l1111l11_l1_)
	if l11l11ll11_l1_:
		l111l1ll1l11_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ搆"),url,re.DOTALL)
		url = url.replace(l111l1ll1l11_l1_[0],l11l11ll11_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll1lll11_l1_,l11111l111l_l1_,l1ll1lllll1l_l1_
	l1111llll1l_l1_ = l1l111_l1_ (u"ࠨࠩ搇")
	l11ll1lll11_l1_(l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ搈"))
	try: l11111l111l_l1_(l1lll111lll_l1_,l1lll1llllll_l1_)
	except Exception as error: l1111llll1l_l1_ = traceback.format_exc()
	l11ll1lll11_l1_(l1l111_l1_ (u"ࠪࡷࡹࡵࡰࠨ搉"))
	l1ll1lllll1l_l1_(l1111llll1l_l1_)
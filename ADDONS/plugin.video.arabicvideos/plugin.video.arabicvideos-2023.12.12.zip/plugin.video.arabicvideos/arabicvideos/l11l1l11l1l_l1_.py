# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ坪")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭坫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ坬"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l1111l1l1_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坭"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ坮"),l1l111_l1_ (u"ࠫࠬ坯"),319,l1l111_l1_ (u"ࠬ࠭坰"),l1l111_l1_ (u"࠭ࠧ坱"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ坲"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ坳"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ坴"),l1l111_l1_ (u"ࠪࠫ坵"),l1l111_l1_ (u"ࠫࠬ坶"),l1l111_l1_ (u"ࠬ࠭坷"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ坸"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶ࡮࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ坹"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭坺"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ坻"),l1l111_l1_ (u"ࠪࠫ坼"),9999)
	items = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠵࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠸ࡂࠬ坽"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠬࠦࠧ坾"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭坿"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ垀")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠨࠩ垁"),l1l111_l1_ (u"ࠩࠪ垂"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垃"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭垄")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬโศู฼ࠤูํัࠨ垅"),l111l1_l1_,314,l1l111_l1_ (u"࠭ࠧ垆"),l1l111_l1_ (u"ࠧࠨ垇"),l1l111_l1_ (u"ࠨ࠲ࠪ垈"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ垉"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ垊"),l1l111_l1_ (u"ࠫࠬ型"),9999)
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡃࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡅࡂࠬ垌"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ垍")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垎"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ垏")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭垐"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ垑"),l1l111_l1_ (u"ࠫࠬ垒"),l1l111_l1_ (u"ࠬ࠭垓"),l1l111_l1_ (u"࠭ࠧ垔"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡐࡆ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ垕"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠨ࠲ࠪ垖"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷࡥࡧ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ垗"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垘"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭垙")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ垚"))
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ垛"))
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垜")+name+l1l111_l1_ (u"ࠨࠫࠪ垝")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ垞"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠪ࠵ࠬ垟"),l1l111_l1_ (u"ࠫ࠷࠭垠"),l1l111_l1_ (u"ࠬ࠹ࠧ垡")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠽ࡪ࠸ࡂ࠳࠰࠿ࠪ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡰ࡬࠭垢"),html,re.DOTALL)
		l11l1111l1ll_l1_ = int(seq)-1
		block = l11llll_l1_[l11l1111l1ll_l1_]
		if seq==l1l111_l1_ (u"ࠧ࠲ࠩ垣"): items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ垤"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垥"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ垦")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭垧")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ垨"))
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ垩"))
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垪")+name+l1l111_l1_ (u"ࠨࠫࠪ垫")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垬"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠪ࠸ࠬ垭"),l1l111_l1_ (u"ࠫ࠺࠭垮"),l1l111_l1_ (u"ࠬ࠼ࠧ垯")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠽ࡪ࠸ࡂ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ垰"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂ࠱ࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垱"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11l11_l1_,title,l1lllllllll_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ垲")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ垳")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ垴"))
			l1ll1l11l11_l1_ = l1ll1l11l11_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭垵"))
			l1lllllllll_l1_ = l1lllllllll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ垶"))
			if l1ll1l11l11_l1_: name = l1ll1l11l11_l1_
			else: name = l1lllllllll_l1_
			title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ垷")+name+l1l111_l1_ (u"ࠧࠪࠩ垸")
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ垹"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭垺"),url,l1l111_l1_ (u"ࠪࠫ垻"),l1l111_l1_ (u"ࠫࠬ垼"),l1l111_l1_ (u"ࠬ࠭垽"),l1l111_l1_ (u"࠭ࠧ垾"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ垿"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡥࡳࡽ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡬ࡰࡣࡷ࠱ࡷ࡯ࡧࡩࡶࠪ埀"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠩࡦࡥࡹࡹࡵ࡮࠯ࡰࡳࡧ࡯࡬ࡦࠩ埁") in block:
		items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埂"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭埃")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ埄")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"࠭ࠠศๆุ์ฯ๐ษ࠻ࠢࠪ埅"),l1l111_l1_ (u"ࠧ࠻ࠩ埆"))
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ埇"))
				title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ埈")+count+l1l111_l1_ (u"ࠪ࠭ࠬ埉")
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ埊"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ埋"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l1111ll11_l1_,l1l1lll1ll_l1_ in items:
			if title==l1l111_l1_ (u"࠭ࠧ埌") or l11l1111ll11_l1_==l1l111_l1_ (u"ࠧࠨ埍"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ城")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ埏")+l1l1lll1ll_l1_+l1l111_l1_ (u"ࠪ࠭ࠬ埐")
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ埑"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭埒"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ埓"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll1ll_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ埔")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ埕"))
		name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ埖"))
		title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埗")+name+l1l111_l1_ (u"ࠫ࠮࠭埘")
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埙"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"࠭ࠧ埚"),l1l1lll1ll_l1_)
	return
def l11l1111l1l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ埛"),url,l1l111_l1_ (u"ࠨࠩ埜"),l1l111_l1_ (u"ࠩࠪ埝"),l1l111_l1_ (u"ࠪࠫ埞"),l1l111_l1_ (u"ࠫࠬ域"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈࡠࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ埠"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠥࡶ࠭࠲ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠧ埡"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埢"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埣")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ埤"))
		if l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠯ࠪ埥") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ埦"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埧"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ埨"),url,l1l111_l1_ (u"ࠧࠨ埩"),l1l111_l1_ (u"ࠨࠩ埪"),l1l111_l1_ (u"ࠩࠪ埫"),l1l111_l1_ (u"ࠪࠫ埬"),l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ埭"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡡࡶࡦ࡬ࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ埮"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭埯"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭埰"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ埱"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ埲"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ埳"),l1l111_l1_ (u"ࠫ࠰࠭埴"))
	l11l1111ll1l_l1_ = [l1l111_l1_ (u"ࠬࠬࡴ࠾ࡣࠪ埵"),l1l111_l1_ (u"࠭ࠦࡵ࠿ࡦࠫ埶"),l1l111_l1_ (u"ࠧࠧࡶࡀࡷࠬ執")]
	if l11_l1_:
		l11l1111l11l_l1_ = [l1l111_l1_ (u"ࠨไสีห࠭埸"),l1l111_l1_ (u"ࠩศูิอัࠡ࠱้ࠣั๊ฯࠨ培"),l1l111_l1_ (u"้ࠪ็฽ูࠡษ็ูํะ๊ࠨ基")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦ࠭ࠡลัฮึࠦวๅสะฯࠬ埻"), l11l1111l11l_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࡢࠫ埼") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࡢࠫ埽") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࡣࠬ埾") in options: l11l11l_l1_ = 2
	else: return
	type = l11l1111ll1l_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࡱ࠾ࠩ埿")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭堀"),url,l1l111_l1_ (u"ࠪࠫ堁"),l1l111_l1_ (u"ࠫࠬ堂"),l1l111_l1_ (u"ࠬ࠭堃"),l1l111_l1_ (u"࠭ࠧ堄"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ堅"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ堆"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ堇"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ堈"))
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭堉"))
				title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ堊")+name+l1l111_l1_ (u"࠭ࠩࠨ堋")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ堌"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯ࡵࡦࡁࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ堍"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ堎"))
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ堏"))
				title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ堐")+name+l1l111_l1_ (u"ࠬ࠯ࠧ堑")
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ堒"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
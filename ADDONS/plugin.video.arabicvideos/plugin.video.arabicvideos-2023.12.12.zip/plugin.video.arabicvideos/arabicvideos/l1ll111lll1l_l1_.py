# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ妋")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬ妌")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆืสี฾ฯࠧ妍"),l1l111_l1_ (u"ࠨสฮࠤ๊ฮวีำࠪ妎")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭妏"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ妐"),l1l111_l1_ (u"ࠫࠬ妑"),l1l111_l1_ (u"ࠬ࠭妒"),l1l111_l1_ (u"࠭ࠧ妓"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ妔"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ妕"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠩ࠲ࠫ妖"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ妗"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妘"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ妙"),l1l11ll_l1_,489,l1l111_l1_ (u"࠭ࠧ妚"),l1l111_l1_ (u"ࠧࠨ妛"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ妜"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ妝"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ妞"),l1l111_l1_ (u"ࠫࠬ妟"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妠"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ妡")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤฯาฯࠥอไๆ๊สฺ๏฿ࠧ妢"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࠧࡳࡹࡂࡥࡦࡳࡺࡴࡴࠣࠩ妣"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ妤"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ妥"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妦"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ妧")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l111llllll1l_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ妨"),url,l1l111_l1_ (u"ࠧࠨ妩"),l1l111_l1_ (u"ࠨࠩ妪"),l1l111_l1_ (u"ࠩࠪ妫"),l1l111_l1_ (u"ࠪࠫ妬"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ妭"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡰࡵࡷࠬ࠳࠰࠿ࠪࠤࡩࡳࡴࡺࡥࡳࠤࠪ妮"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ妯"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ妰"),l1l111_l1_ (u"ࠨใํ่๊࠭妱"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ妲"),l1l111_l1_ (u"ࠪว฿์๊สࠩ妳"),l1l111_l1_ (u"่๊๊ࠫษࠩ妴"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ妵"),l1l111_l1_ (u"࠭็ะษไࠫ妶"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ妷"),l1l111_l1_ (u"ࠨ฻ิฺࠬ妸"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ妹"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ妺"),l1l111_l1_ (u"ู๊ࠫัฮ์ฬࠫ妻")]
	l111lllllll1_l1_ = l1l111_l1_ (u"ࠬ࠵ࠧ妼").join(l111llllll1l_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ妽")).split(l1l111_l1_ (u"ࠧ࠰ࠩ妾"))[4:]).split(l1l111_l1_ (u"ࠨ࠯ࠪ妿"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ姀"),title,re.DOTALL)
		if l111llllll1l_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠪ࠳ࠬ姁").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭姂")).split(l1l111_l1_ (u"ࠬ࠵ࠧ姃"))[4:]).split(l1l111_l1_ (u"࠭࠭ࠨ姄"))
			l111llllllll_l1_ = len([x for x in l111lllllll1_l1_ if x in l111lllll_l1_])
			if l111llllllll_l1_>2 and l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ姅") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ姆"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ姇"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ุ้๊ࠪำๅࠩ姈") not in title:
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姉"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬำไใหࠪ姊") in title:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ始") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ姌"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ姍"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姎"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ姏"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠦࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ姐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ姑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧ姒"),l1l111_l1_ (u"ࠧࠨ姓"))
			if title!=l1l111_l1_ (u"ࠨࠩ委"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姕"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ姖")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠫࠬ姗"),l1l111_l1_ (u"ࠬ࠭姘"),l111llllll1l_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ姙"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ姚")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ姛"),url,l1l111_l1_ (u"ࠩࠪ姜"),headers,l1l111_l1_ (u"ࠪࠫ姝"),l1l111_l1_ (u"ࠫࠬ姞"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭姟"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ姠"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ姡"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ姢"))
	l111llllll11_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡰ࡮ࡹࡴࡔࡧࡤࡷࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ姣"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ姤") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠨ姥"))
		if count==0: count = block.count(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠫ姦"))
		if count>1:
			l111llllll11_l1_ = False
			if l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠥࠫ姧") in block:
				items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ姨"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠵࠲ࡵ࡮ࡰࡀࡵ࡯ࡹ࡬ࡃࠧ姩")+id
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姪"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭姫"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠴ࡰࡩࡲࡂࡷࡪࡸࡩࡦࡵࡌࡈࡂ࠭姬")+id
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ姭"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l111llllll11_l1_:
		block = l1l111_l1_ (u"࠭ࠧ姮")
		if l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ姯") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡴࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭姰"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ姱"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ姲"))
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姳"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧ姴"))+l1l111_l1_ (u"࠭࠯ࡀࡦࡲࡁࡼࡧࡴࡤࡪࠪ姵")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ姶"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ姷"),l1l111_l1_ (u"ࠩࠪ姸"),l1l111_l1_ (u"ࠪࠫ姹"),l1l111_l1_ (u"ࠫࠬ姺"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ姻"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ姼"))
	l11111lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡱࡢࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭姽"),html,re.DOTALL)
	if not l11111lll_l1_: l11111lll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࠫࡸ࡭࡯ࡳ࡝࠰࡬ࡨࡡ࠲࠰࡝࠮ࠫ࠲࠯ࡅࠩ࡝ࠫࠪ姾"),html,re.DOTALL)
	l11111lll_l1_ = l11111lll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ姿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ娀"),block,re.DOTALL)
		for l11111ll1_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭威"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡩࡧࡴࡤࡱࡪ࠸࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ娂")+l11111lll_l1_+l1l111_l1_ (u"࠭ࠦࡷ࡫ࡧࡩࡴࡃࠧ娃")+l11111ll1_l1_[2:]+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ娄")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ娅")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡫ࡪࡺࡅ࡮ࡤࡨࡨࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭娆"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠪࡹࡷࡲࠧ娇"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ娈")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭娉")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"࠭࠯ࠨ娊"))+l1l111_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ娋")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ娌"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ娍"),l1l111_l1_ (u"ࠪࠫ娎"),l1l111_l1_ (u"ࠫࠬ娏"),l1l111_l1_ (u"ࠬ࠭娐"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ娑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡶࡤࡦࡱ࡫࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ娒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ娓"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ娔"))
			if l1l111_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ娕") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠫࡤࡥฮศืࠪ娖")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠬ࠭娗")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ娘")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ娙")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ娚"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠩࠪ娛")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ娜"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ娝"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ娞"),l1l111_l1_ (u"࠭ࠫࠨ娟"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠧࠨ娠"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ娡")+search+l1l111_l1_ (u"ࠩ࠲ࠫ娢")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࠫ娣"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ僂")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ僃") : l1l111_l1_ (u"ࠬ࠭僄") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡈ࡚ࡣࠬ僅")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11ll1l1ll11_l1_(url)
	elif mode==215: l1lll_l1_ = l11ll1l1ll1l_l1_(url)
	elif mode==218: l1lll_l1_ = l1l1l1ll111l_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l1ll111l_l1_():
	message = l1l111_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ僆")
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ僇"),l1l111_l1_ (u"ࠩࠪ僈"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭僉"),l1l111_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠪ僊"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僋"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭僌"),l1l111_l1_ (u"ࠧࠨ働"),219,l1l111_l1_ (u"ࠨࠩ僎"),l1l111_l1_ (u"ࠩࠪ像"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ僐"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ僑")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僒"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ僓")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ僔"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩ僕"),headers,l1l111_l1_ (u"ࠩࠪ僖"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ僗"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ僘"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ僙"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ僚")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僛"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ僜")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ僝"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭僞"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ僟"),l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ僠")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ僡"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僢"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ僣")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ僤"),headers,l1l111_l1_ (u"ࠪࠫ僥"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ僦"))
	if l1l111_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧ僧") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ僨") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭僩"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭僪"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ僫"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ僬"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ僭"),l1l111_l1_ (u"้ࠬไ๋สࠪ僮"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ僯"),l1l111_l1_ (u"่ࠧัสๅࠬ僰"),l1l111_l1_ (u"ࠨ็หหึอษࠨ僱"),l1l111_l1_ (u"ࠩ฼ี฻࠭僲"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ僳"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ僴")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ僵") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ僶"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ僷"))
		if l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ僸") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ價"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭僺") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ僻") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ僼"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ僽") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ僾"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僿"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ儀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭儁"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ儂"),l1l111_l1_ (u"ࠬ࠭儃"))
			if title!=l1l111_l1_ (u"࠭ࠧ億"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儅"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ儆")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ儇"),headers,l1l111_l1_ (u"ࠪࠫ儈"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ儉"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ儊"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"࠭ࠧ儋").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭儌"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ儍"))
		title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ儎") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ儏"))[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭儐"),l1l111_l1_ (u"ࠬࠦࠧ儑"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬ儒"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ儓"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ儔")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ儕"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭儖"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭儗") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ儘") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭儙"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ儚") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ儛"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ儜"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ儝"),headers,l1l111_l1_ (u"ࠫࠬ儞"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭償"))
	if l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ儠") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭儡"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ儢"),headers,l1l111_l1_ (u"ࠩࠪ儣"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ儤"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ儥"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ儦"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ儧"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l11l11_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡳࡳࡸࡺࡩࡥ࠿ࠪ儨")+l1l1l11l11_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ儩")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ優")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ儫")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪࠥࢀࠫࡷࡵࡰࡶ࠾࠭ࠬ儬"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ儭") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ儮"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ儯"),headers,l1l111_l1_ (u"ࠨࠩ儰"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ儱"))
		id = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ儲"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l11l11_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ儳"):l1l111_l1_ (u"ࠬ࠭儴") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ儵"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ儶") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ儷")+l1l1l11l11_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ儸"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ儹"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ儺"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠴࠰࠭ࡃ࠭ࡢࡤࠬࠫࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ儻"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ儼"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ儽")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ儾")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ儿")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠼ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭兀"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠫࠬ允")
					items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ兂"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"࠭ࠦࠧࠩ元") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ兄"))[2].lower() + l1l111_l1_ (u"ࠨࠨࠩࠫ充")
						server = server.replace(l1l111_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ兆"),l1l111_l1_ (u"ࠪࠫ兇")).replace(l1l111_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ先"),l1l111_l1_ (u"ࠬ࠭光"))
						server = server.replace(l1l111_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭兊"),l1l111_l1_ (u"ࠧࠨ克")).replace(l1l111_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ兌"),l1l111_l1_ (u"ࠩࠪ免"))
						server = server.replace(l1l111_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ兎"),l1l111_l1_ (u"ࠫࠬ兏")).replace(l1l111_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ児"),l1l111_l1_ (u"࠭ࠧ兑"))
						server = server.replace(l1l111_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭兒"),l1l111_l1_ (u"ࠨࠩ兓")).replace(l1l111_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ兔"),l1l111_l1_ (u"ࠪࠫ兕"))
						server = server.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ兖"),l1l111_l1_ (u"ࠬ࠭兗"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ兘") + name + server + l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ兙")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ党"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ兛"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ兜"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭兝"),l1l111_l1_ (u"ࠬ࠱ࠧ兞"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ兟")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ⎃")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡉ࡙ࡣࠬ⎄")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==220: l1lll_l1_ = l1l1l11_l1_()
	elif mode==221: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==222: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==223: l1lll_l1_ = PLAY(url)
	elif mode==224: l1lll_l1_ = l1l1ll1l_l1_(url)
	elif mode==229: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎅"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⎆"),l1l111_l1_ (u"ࠩࠪ⎇"),229,l1l111_l1_ (u"ࠪࠫ⎈"),l1l111_l1_ (u"ࠫࠬ⎉"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⎊"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⎋"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⎌"),l1l111_l1_ (u"ࠨࠩ⎍"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⎎"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ⎏"),l1l111_l1_ (u"ࠫࠬ⎐"),l1l111_l1_ (u"ࠬ࠭⎑"),l1l111_l1_ (u"࠭ࠧ⎒"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⎓"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡮࡯࡮ࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⎔"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⎕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪࡀ࠴࡯࠾ࠨ⎖") in title: title = title.split(l1l111_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠩ⎗"))[1]
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎘"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎙")+l1lllll_l1_+title,l1ll1ll_l1_,222)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⎚"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎛"),l1l111_l1_ (u"ࠩࠪ⎜"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡦ࠮࠮ࠫࡁࠬࡀࡸࡩࡲࡪࡲࡷࠫ⎝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡵࡪࡡࠡࡤࡧࡦࠧࡄ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⎞"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎟"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎠")+l1lllll_l1_+title,l1ll1ll_l1_,221)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⎡"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎢"),l1l111_l1_ (u"ࠩࠪ⎣"),9999)
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⎤"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭ࠩ⎥") not in l1ll1ll_l1_: continue
			if not l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠬ࠵ࠧ⎦")): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎧"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎨")+l1lllll_l1_+title,l1ll1ll_l1_,221)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⎩"),url,l1l111_l1_ (u"ࠩࠪ⎪"),l1l111_l1_ (u"ࠪࠫ⎫"),l1l111_l1_ (u"ࠫࠬ⎬"),l1l111_l1_ (u"ࠬ࠭⎭"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⎮"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡵࡢࡷࡨࡸ࡯࡭࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⎯"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⎰"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎱"),l1lllll_l1_+title,l1ll1ll_l1_,224)
	return
def l1l1ll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎲"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ⎳"),url,221)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭⎴"),l1l111_l1_ (u"࠭ࠧ⎵"),l1l111_l1_ (u"ࠧࠨ⎶"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⎷"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡹࡧࡥ࡮ࡢࡸࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶࠫ⎸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⎹"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭⎺"): name = title
			else:
				title = title + l1l111_l1_ (u"ࠬࠦࠠ࠻ࠢࠣࠫ⎻") + l1l111_l1_ (u"࠭แๅฬิࠤࠬ⎼") + name
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎽"),l1lllll_l1_+title,l1ll1ll_l1_,221)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠨ࠳ࠪ⎾")):
	if l1llllll1_l1_==l1l111_l1_ (u"ࠩࠪ⎿"): l1llllll1_l1_ = l1l111_l1_ (u"ࠪ࠵ࠬ⏀")
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ⏁") in url or l1l111_l1_ (u"ࠬࡅࠧ⏂") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"࠭ࠦࠨ⏃")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠧࡀࠩ⏄")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧ⏅") + l1llllll1_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⏆"),l1l111_l1_ (u"ࠪࠫ⏇"),l1l111_l1_ (u"ࠫࠬ⏈"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⏉"))
	if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࠧ⏊") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡦࡤࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭⏋"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⏌") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡲࡻࡱ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠡࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ⏍"),html,re.DOTALL)
		block = l11llll_l1_[0]
	else:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⏎"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⏏"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠭⏐") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࠨ⏑") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⏒"),l1lllll_l1_+title,l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪ⏓")),223,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏔"),l1lllll_l1_+title,l1ll1ll_l1_,221,l1ll1l_l1_)
	if len(items)>=16:
		l11l1l1l11_l1_ = [l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ⏕"),l1l111_l1_ (u"ࠫ࠴ࡺࡶࠨ⏖"),l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭⏗"),l1l111_l1_ (u"࠭࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ⏘")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l11_l1_):
			for n in range(0,1000,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏙"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ⏚")+str(j),url,221,l1l111_l1_ (u"ࠩࠪ⏛"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏜"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⏝")+str(i),url,221,l1l111_l1_ (u"ࠬ࠭⏞"),str(i))
						else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏟"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭⏠")+str(1),url,221,l1l111_l1_ (u"ࠨࠩ⏡"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏢"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ⏣")+str(n),url,221,l1l111_l1_ (u"ࠫࠬ⏤"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏥"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ⏦")+str(1),url,221)
	return
def PLAY(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ⏧"),l1l111_l1_ (u"ࠨࠩ⏨"),l1l111_l1_ (u"ࠩࠪ⏩"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⏪"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡤ࠿ษ็ฮฺ์๊โ࠾࠲ࡸࡩࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⏫"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1l111ll1_l1_,l1l1l11ll_l1_ = l1l111_l1_ (u"ࠬ࠭⏬"),l1l111_l1_ (u"࠭ࠧ⏭")
	l111l1l111_l1_,l111l11l11_l1_ = html,html
	l111l11lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡤࡪ࡬ࠡࡣࡳ࡭ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⏮"),html,re.DOTALL)
	if l111l11lll_l1_:
		for l1ll1ll_l1_ in l111l11lll_l1_:
			if l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ⏯") in l1ll1ll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			elif l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭⏰") in l1ll1ll_l1_: l1l1l11ll_l1_ = l1ll1ll_l1_
		if l1l111ll1_l1_!=l1l111_l1_ (u"ࠪࠫ⏱"): l111l1l111_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l111ll1_l1_,l1l111_l1_ (u"ࠫࠬ⏲"),l1l111_l1_ (u"ࠬ࠭⏳"),l1l111_l1_ (u"࠭ࠧ⏴"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭⏵"))
		if l1l1l11ll_l1_!=l1l111_l1_ (u"ࠨࠩ⏶"): l111l11l11_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l1l11ll_l1_,l1l111_l1_ (u"ࠩࠪ⏷"),l1l111_l1_ (u"ࠪࠫ⏸"),l1l111_l1_ (u"ࠫࠬ⏹"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ⏺"))
	l111l1l11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⏻"),l111l1l111_l1_,re.DOTALL)
	if l111l1l11l_l1_:
		l1lllll1_l1_ = l111l1l11l_l1_[0]
		if l1lllll1_l1_!=l1l111_l1_ (u"ࠧࠨ⏼") and l1l111_l1_ (u"ࠨࡷࡳࡰࡴࡧࡤࡦࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⏽") in l1lllll1_l1_ and l1l111_l1_ (u"ࠩ࠲ࡃ࡮ࡪ࠽ࡠࠩ⏾") not in l1lllll1_l1_:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⏿"),l1l111_l1_ (u"ࠫࠬ␀"),l1l111_l1_ (u"ࠬ࠭␁"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ␂"))
			l111l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ␃"),l11l1ll1_l1_,re.DOTALL)
			if l111l11l1l_l1_:
				for l1ll1ll_l1_,l111l1ll_l1_ in l111l11l1l_l1_:
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡧࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪ࡯ࡠࡡࡺࡥࡹࡩࡨࡠࡡࡰࡴ࠹ࡥ࡟ࠨ␄")+l111l1ll_l1_)
			else:
				server = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ␅"))[2]
				l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ␆")+server+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ␇"))
		elif l1lllll1_l1_!=l1l111_l1_ (u"ࠬ࠭␈"):
			server = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ␉"))[2]
			l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ␊")+server+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ␋"))
	l111l1ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡦࡨ࡬ࡦࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡰࡸࡥࡴࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ␌"),l111l11l11_l1_,re.DOTALL)
	if l111l1ll11_l1_:
		l111l1ll11_l1_ = l111l1ll11_l1_[0]
		l111l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡹࡪ࠾࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ␍"),l111l1ll11_l1_,re.DOTALL)
		if l111l11ll1_l1_:
			for l111l1ll_l1_,l1ll1ll_l1_ in l111l11ll1_l1_:
				if l1l111_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭␎") not in l1ll1ll_l1_: continue
				if l1ll1ll_l1_.count(l1l111_l1_ (u"ࠬ࠵ࠧ␏"))>=2:
					server = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ␐"))[2]
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ␑")+server+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡭ࡱ࠶ࡢࡣࠬ␒")+l111l1ll_l1_)
	l111l1l1ll_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_:
		l111l1l1ll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l1l1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ␓"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ␔"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ␕"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ␖"),l1l111_l1_ (u"࠭ࠫࠨ␗"))
	html = l1l1llll_l1_(l111l11l_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ␘"),l1l111_l1_ (u"ࠨࠩ␙"),l1l111_l1_ (u"ࠩࠪ␚"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ␛"))
	token = re.findall(l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࡣࡹࡵ࡫ࡦࡰࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ␜"),html,re.DOTALL)
	if token:
		url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡟ࡵࡱ࡮ࡩࡳࡃࠧ␝")+token[0]+l1l111_l1_ (u"࠭ࠦࡲ࠿ࠪ␞")+l1lll1ll_l1_
		l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ⋉")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡉࡇ࠺࡟ࠨ⋊")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห๏า๊ࠡสึฮࠬ⋋"),l1l111_l1_ (u"ࠫฬะีๅࠢห๊ฬ࠭⋌"),l1l111_l1_ (u"ࠬอ๊อ์ࠣฬุะࠠศๆสู้๐ࠧ⋍"),l1l111_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็ะิ๐ฯࠨ⋎"),l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่อี๊ๅࠩ⋏"),l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ⋐"),l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮำหࠩ⋑")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==800: l1lll_l1_ = l1l1l11_l1_()
	elif mode==801: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==802: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==803: l1lll_l1_ = PLAY(url)
	elif mode==804: l1lll_l1_ = l111ll111l_l1_(url)
	elif mode==806: l1lll_l1_ = l111l1111_l1_(url,l1llllll1_l1_)
	elif mode==809: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋒"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⋓"),l1l111_l1_ (u"ࠬ࠭⋔"),809,l1l111_l1_ (u"࠭ࠧ⋕"),l1l111_l1_ (u"ࠧࠨ⋖"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⋗"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋘"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠨ⋙"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ⋚"),804,l1l111_l1_ (u"ࠬ࠭⋛"),l1l111_l1_ (u"࠭ࠧ⋜"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⋝"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⋞"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⋟"),l1l111_l1_ (u"ࠪࠫ⋠"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⋡"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭⋢"),l1l111_l1_ (u"࠭ࠧ⋣"),l1l111_l1_ (u"ࠧࠨ⋤"),l1l111_l1_ (u"ࠨࠩ⋥"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⋦"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡼ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⋧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⋨"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⋩"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ⋪") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋫"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⋬")+l1lllll_l1_+title,l1ll1ll_l1_,801)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⋭"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⋮"),l1l111_l1_ (u"ࠫࠬ⋯"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲ࠿ࠩ⋰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡘ࡮ࡺ࡬ࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋱"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ⋲"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭⋳") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋴"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⋵")+l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠫࠬ⋶"),l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡰࡩࡳࡻࠧ⋷"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⋸"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⋹"),l1l111_l1_ (u"ࠨࠩ⋺"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⋻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⋼"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⋽"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⋾") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋿"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⌀")+l1lllll_l1_+title,l1ll1ll_l1_,801)
	return html
def l111l1111_l1_(url,type=l1l111_l1_ (u"ࠨࠩ⌁")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⌂"),url,l1l111_l1_ (u"ࠪࠫ⌃"),l1l111_l1_ (u"ࠫࠬ⌄"),l1l111_l1_ (u"ࠬ࠭⌅"),l1l111_l1_ (u"࠭ࠧ⌆"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⌇"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠩ⌈"),html,re.DOTALL)
	if l11llll_l1_:
		l111llll1l_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠩࠪ⌉"),l1l111_l1_ (u"ࠪࠫ⌊"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠫา๊โศฬࠪ⌋") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๋่ࠬศี่ࠫ⌌") in name: l111llll1l_l1_ = block
		if l111llll1l_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⌍"),l111llll1l_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌎"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⌏"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⌐"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⌑"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⌒"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⌓"),l1lllll_l1_+title,l1ll1ll_l1_,803)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ⌔")):
	limit,start,l1l1l1ll1_l1_,select,l111ll1111_l1_ = 0,0,l1l111_l1_ (u"ࠧࠨ⌕"),l1l111_l1_ (u"ࠨࠩ⌖"),l1l111_l1_ (u"ࠩࠪ⌗")
	if l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ⌘") in type:
		l111ll11ll_l1_,l1l11llll_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡴࡥࡹࡶࡀࡴࡦ࡭ࡥࠧࠩ⌙"))
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⌚"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ⌛")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ⌜"),l111ll11ll_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ⌝"),l1l111_l1_ (u"ࠩࠪ⌞"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⌟"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠫࡸ࡫ࡣࡄࡱࡱࡸࡪࡴࡴࠨ⌠")+html+l1l111_l1_ (u"ࠬࡂࡦࡰࡱࡷࡩࡷࡄࠧ⌡")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⌢"),url,l1l111_l1_ (u"ࠧࠨ⌣"),l1l111_l1_ (u"ࠨࠩ⌤"),l1l111_l1_ (u"ࠩࠪ⌥"),l1l111_l1_ (u"ࠪࠫ⌦"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⌧"))
		html = response.content
		l11l1ll1_l1_ = html
	items,l111lllll1_l1_,filters = [],False,False
	if not type and l1l111_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶࠫ⌨") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ〈"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ〉"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⌫"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌬"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠪࠫ⌭"),l1l111_l1_ (u"ࠫࡸࡻࡢ࡮ࡧࡱࡹࠬ⌮"))
				l111lllll1_l1_ = True
	if not l111lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥࡤࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠫ⌯"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⌰"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠧ࡝ࡰࠪ⌱"))
				title = unescapeHTML(title)
				if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⌲") in l1ll1ll_l1_ and type==l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ⌳"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌴"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ⌵"))
				elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⌶") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⌷"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠱ࠪ⌸") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌹"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ⌺"))
				elif l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮ࡴࠩ⌻") in url: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌼"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠬࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࡵࠪ⌽"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⌾"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡭ࡱࡤࡨࡒࡵࡲࡦࡒࡤࡶࡦࡳࡳࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽ࠪ⌿"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			params = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭⍀"),block)
			l111ll1111_l1_ = params[l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾࡵࡳ࡮ࠪ⍁")]
			l111l1lll1_l1_ = int(params[l1l111_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡵࡧࡧࡦࠩ⍂")])+1
			l111l1llll_l1_ = int(params[l1l111_l1_ (u"ࠫࡲࡧࡸࡠࡲࡤ࡫ࡪ࠭⍃")])
			query = params[l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡶࠫ⍄")].replace(l1l111_l1_ (u"࠭ࡆࡢ࡮ࡶࡩࠬ⍅"),l1l111_l1_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭⍆")).replace(l1l111_l1_ (u"ࠨࡖࡵࡹࡪ࠭⍇"),l1l111_l1_ (u"ࠩࡷࡶࡺ࡫ࠧ⍈")).replace(l1l111_l1_ (u"ࠪࡒࡴࡴࡥࠨ⍉"),l1l111_l1_ (u"ࠫࡳࡻ࡬࡭ࠩ⍊"))
			if l111l1lll1_l1_<l111l1llll_l1_:
				l1l11llll_l1_ = l1l111_l1_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡂࡲ࡯ࡢࡦࡰࡳࡷ࡫ࠦࡲࡷࡨࡶࡾࡃࠧ⍋")+QUOTE(query,l1l111_l1_ (u"࠭ࠧ⍌"))+l1l111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ⍍")+str(l111l1lll1_l1_)
				l1lllll1_l1_ = l111ll1111_l1_+l1l111_l1_ (u"ࠨࡁࡱࡩࡽࡺ࠽ࡱࡣࡪࡩࠫ࠭⍎")+l1l11llll_l1_
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍏"),l1lllll_l1_+l1l111_l1_ (u"ࠪะ้ฮࠠศๆ่ึ๏ีࠧ⍐"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠫࠬ⍑"),l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡡࠪ⍒")+type)
		elif l1l111_l1_ (u"࠭࠿࡯ࡧࡻࡸࡂࡶࡡࡨࡧࠩࠫ⍓") in url:
			l1l11llll_l1_,l1lll1l1l_l1_ = l1l11llll_l1_.rsplit(l1l111_l1_ (u"ࠧ࠾ࠩ⍔"),1)
			l1lll1l1l_l1_ = int(l1lll1l1l_l1_)+1
			l1lllll1_l1_ = l111ll11ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡩࡽࡺ࠽ࡱࡣࡪࡩࠫ࠭⍕")+l1l11llll_l1_+l1l111_l1_ (u"ࠩࡀࠫ⍖")+str(l1lll1l1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍗"),l1lllll_l1_+l1l111_l1_ (u"ࠫั๊ศࠡษ็้ื๐ฯࠨ⍘"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠬ࠭⍙"),l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡢࠫ⍚")+type)
	return
def l111ll111l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⍛"),url,l1l111_l1_ (u"ࠨࠩ⍜"),l1l111_l1_ (u"ࠩࠪ⍝"),l1l111_l1_ (u"ࠪࠫ⍞"),l1l111_l1_ (u"ࠫࠬ⍟"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡇࡋࡏࡘࡊࡘࡓ࠮࠳ࡶࡸࠬ⍠"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡶࡤࡢࡲࡦࡼࠨ࠯ࠬࡂ࠭ࡸ࡫ࡣࡄࡱࡱࡸࡪࡴࡴࠡࠩ⍡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡸࡶࡷ࡫࡮ࡵࡡࡲࡴࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⍢"),block,re.DOTALL)
		for name,block in l1lll1l1_l1_:
			if l1l111_l1_ (u"ࠨษ็ฮฺ์๊โࠩ⍣") in name: continue
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ⍤"))
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⍥"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ⍦")+value
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⍧"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"࠭ࠧ⍨"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⍩"))
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⍪"),url,l1l111_l1_ (u"ࠩࠪ⍫"),l1l111_l1_ (u"ࠪࠫ⍬"),l1l111_l1_ (u"ࠫࠬ⍭"),l1l111_l1_ (u"ࠬ࠭⍮"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⍯"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶࡧࡂฬ๊สึ่ํๅࡁ࠵ࡴࡥࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⍰"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1ll11l1_l1_,l111l11l1_l1_ = [],[]
	l111ll1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹࡋ࡭ࡣࡧࡧ࠲࠯ࡅࡰࡰࡵࡷࡁ࠭࠴ࠪࡀࠫࠥࠫ⍱"),html,re.DOTALL)
	if l111ll1l1l_l1_:
		l1ll_l1_ = base64.b64decode(l111ll1l1l_l1_[0])
		if kodi_version>18.99: l1ll_l1_ = l1ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⍲"))
		l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ⍳"),l1ll_l1_)
		l1ll_l1_ = list(l1ll_l1_.values())
		for l1ll1ll_l1_ in l1ll_l1_:
			if l1ll1ll_l1_ not in l111l11l1_l1_:
				l111l11l1_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ⍴"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⍵")+server+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⍶"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸࡉࡵࡷ࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ⍷"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡶࡃ࠴ࠪࡀ࠾ࡷࡨࡃࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫࠪ࡟ࡨࢀ࠹ࠬ࠵ࡿࠬ࡟ࠥࡧ࠭ࡻࡃ࠰࡞ࡢ࠰࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⍸"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l111l11l1_l1_:
				if l1l111_l1_ (u"ࠩ࠲ࡃࡺࡸ࡬࠾ࠩ⍹") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ⍺"))[1]
				l111l11l1_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ⍻"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⍼")+server+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡤࡥࠧ⍽")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⍾"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⍿"),l1l111_l1_ (u"ࠩ࠮ࠫ⎀"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⎁")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ⎂"))
	return
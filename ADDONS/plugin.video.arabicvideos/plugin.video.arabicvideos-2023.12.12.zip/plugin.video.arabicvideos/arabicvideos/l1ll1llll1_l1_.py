# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬᨅ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡃࡍࡐࡢࠫᨆ")
l1lll11lll_l1_ = os.path.join(l1lllllll1_l1_,l1l111_l1_ (u"࠭ࡴࡦ࡯ࡳࠫᨇ"))
l1ll111ll1_l1_ = os.path.join(l1lllllll1_l1_,l1l111_l1_ (u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩᨈ"))
l1lll11l1l_l1_ = os.path.join(l1ll11llll_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪᨉ"),l1l111_l1_ (u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ᨊ"))
l1ll1l111l_l1_ = l1llll1l1l_l1_
l1ll111lll_l1_ = l1l111_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ᨋ")
l1ll11l111_l1_ = l1l111_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫᨌ")
l1lll11l11_l1_ = l1l111_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨᨍ")
l1lll1l111_l1_ = l1l111_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬᨎ")
l1ll11l1ll_l1_ = l1l111_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪᨏ")
l1ll11ll11_l1_ = l1l111_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫᨐ")
def l11l1ll_l1_(mode):
	if   mode==740: l1lll_l1_ = l1llllll1l_l1_()
	elif mode==741: l1lll_l1_ = l1lllll11l_l1_(l1lll11lll_l1_,True,True)
	elif mode==742: l1lll_l1_ = l1lllll11l_l1_(l1ll111ll1_l1_,True,True)
	elif mode==743: l1lll_l1_ = l1lllll11l_l1_(l1lll11l1l_l1_,False,True)
	elif mode==744: l1lll_l1_ = l1ll11lll1_l1_(l1ll1l111l_l1_,True)
	elif mode==745: l1lll_l1_ = l1ll111l11_l1_(True)
	elif mode==750: l1lll_l1_ = l1ll1lll1l_l1_()
	elif mode==751: l1lll_l1_ = l1lllll11l_l1_(l1ll111lll_l1_,False,True)
	elif mode==752: l1lll_l1_ = l1lllll11l_l1_(l1ll11l111_l1_,False,True)
	elif mode==753: l1lll_l1_ = l1lllll11l_l1_(l1lll11l11_l1_,False,True)
	elif mode==754: l1lll_l1_ = l1lllll11l_l1_(l1lll1l111_l1_,False,True)
	elif mode==755: l1lll_l1_ = l1lllll11l_l1_(l1ll11l1ll_l1_,False,True)
	elif mode==756: l1lll_l1_ = l1lllll11l_l1_(l1ll11ll11_l1_,False,True)
	elif mode==757: l1lll_l1_ = l1ll1lllll_l1_(True)
	elif mode==758: l1lll_l1_ = l1ll1ll1l1_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1llllll1l_l1_():
	l1lll1ll11_l1_,l1lllll111_l1_ = l1ll11l11l_l1_(l1lll11lll_l1_)
	l1lll1l1ll_l1_,l1ll1l1l11_l1_ = l1ll11l11l_l1_(l1ll111ll1_l1_)
	l1lll1l1l1_l1_,l1ll1l1l1l_l1_ = l1ll11l11l_l1_(l1lll11l1l_l1_)
	l1lll1llll_l1_,l1ll1l11l1_l1_ = l1ll1l1ll1_l1_(l1ll1l111l_l1_)
	l1lll1llll_l1_ -= 36864
	l1ll1l11l1_l1_ -= 1
	l1ll11l1l1_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᨑ")+l1lllll1ll_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨒ")+str(l1lllll111_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨓ")
	l1ll1lll11_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨔ")+l1lllll1ll_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᨕ")+str(l1ll1l1l11_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᨖ")
	l1ll1ll1ll_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᨗ")+l1lllll1ll_l1_(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ᨘࠥ࠭")+str(l1ll1l1l1l_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᨙ")
	l1llllll11_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᨚ")+l1lllll1ll_l1_(l1lll1llll_l1_)+l1l111_l1_ (u"ࠬ࠯ࠧᨛ")
	size = l1lll1ll11_l1_+l1lll1l1ll_l1_+l1lll1l1l1_l1_+l1lll1llll_l1_
	count = l1lllll111_l1_+l1ll1l1l11_l1_+l1ll1l1l1l_l1_+l1ll1l11l1_l1_
	text = l1l111_l1_ (u"࠭ࠠࠩࠩ᨜")+l1lllll1ll_l1_(size)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ᨝")+str(count)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ᨞")
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᨟"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠศๆฯ้๏฿ࠧᨠ")+text,l1l111_l1_ (u"ࠫࠬᨡ"),745)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨢ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᨣ"),l1l111_l1_ (u"ࠧࠨᨤ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᨥ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨᨦ")+l1ll11l1l1_l1_,l1l111_l1_ (u"ࠪࠫᨧ"),741)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨨ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬᨩ")+l1ll1lll11_l1_,l1l111_l1_ (u"࠭ࠧᨪ"),742)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨫ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬᨬ")+l1ll1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪᨭ"),743)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨮ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ᨯ")+l1llllll11_l1_,l1l111_l1_ (u"ࠬ࠭ᨰ"),744)
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᨱ"),l1l111_l1_ (u"ࠧࠨᨲ"))
	return
def l1ll1lll1l_l1_():
	l1llll1lll_l1_ = True if l1l111_l1_ (u"ࠨ࠱ࠪᨳ") in l1ll11llll_l1_ else False
	if not l1llll1lll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪᨴ"),l1l111_l1_ (u"ࠪࠫᨵ"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᨶ"),l1l111_l1_ (u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬᨷ"))
		return
	l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᨸ"))
	if not l1ll11ll1l_l1_: l1ll1ll1l1_l1_()
	l1lll1ll11_l1_,l1lllll111_l1_ = l1ll11l11l_l1_(l1ll111lll_l1_)
	l1lll1l1ll_l1_,l1ll1l1l11_l1_ = l1ll11l11l_l1_(l1ll11l111_l1_)
	l1lll1l1l1_l1_,l1ll1l1l1l_l1_ = l1ll11l11l_l1_(l1lll11l11_l1_)
	l1lll1llll_l1_,l1ll1l11l1_l1_ = l1ll11l11l_l1_(l1lll1l111_l1_)
	l1lll1lll1_l1_,l1ll1l11ll_l1_ = l1ll11l11l_l1_(l1ll11l1ll_l1_)
	l1lll1ll1l_l1_,l1lll1l11l_l1_ = l1ll11l11l_l1_(l1ll11ll11_l1_)
	l1ll11l1l1_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᨹ")+l1lllll1ll_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᨺ")+str(l1lllll111_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᨻ")
	l1ll1lll11_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨼ")+l1lllll1ll_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᨽ")+str(l1ll1l1l11_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᨾ")
	l1ll1ll1ll_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᨿ")+l1lllll1ll_l1_(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᩀ")+str(l1ll1l1l1l_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᩁ")
	l1llllll11_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᩂ")+l1lllll1ll_l1_(l1lll1llll_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᩃ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᩄ")
	l1ll1l1lll_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᩅ")+l1lllll1ll_l1_(l1lll1lll1_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᩆ")+str(l1ll1l11ll_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᩇ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᩈ")+l1lllll1ll_l1_(l1lll1ll1l_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᩉ")+str(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᩊ")
	size = l1lll1ll11_l1_+l1lll1l1ll_l1_+l1lll1l1l1_l1_+l1lll1llll_l1_+l1lll1lll1_l1_+l1lll1ll1l_l1_
	count = l1lllll111_l1_+l1ll1l1l11_l1_+l1ll1l1l1l_l1_+l1ll1l11l1_l1_+l1ll1l11ll_l1_+l1lll1l11l_l1_
	text = l1l111_l1_ (u"ࠫࠥ࠮ࠧᩋ")+l1lllll1ll_l1_(size)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᩌ")+str(count)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᩍ")
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩎ"),l1lllll_l1_+l1l111_l1_ (u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫᩏ"),l1l111_l1_ (u"ࠩࠪᩐ"),758)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩑ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡษ็ะ๊๐ูࠨᩒ")+text,l1l111_l1_ (u"ࠬ࠭ᩓ"),757)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩔ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᩕ"),l1l111_l1_ (u"ࠨࠩᩖ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩗ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪᩘ")+l1ll11l1l1_l1_,l1l111_l1_ (u"ࠫࠬᩙ"),751)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩚ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪᩛ")+l1ll1lll11_l1_,l1l111_l1_ (u"ࠧࠨᩜ"),752)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩝ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩᩞ")+l1ll1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ᩟"),753)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬᩠ࠩ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨᩡ")+l1llllll11_l1_,l1l111_l1_ (u"࠭ࠧᩢ"),754)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩣ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨᩤ")+l1ll1l1lll_l1_,l1l111_l1_ (u"ࠩࠪᩥ"),755)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩦ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫᩧ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ᩨ"),756)
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᩩ"),l1l111_l1_ (u"ࠧࠨᩪ"))
	return
def l1ll1ll1l1_l1_():
	l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠨࠩᩫ"),l1l111_l1_ (u"ࠩࠪᩬ"),l1l111_l1_ (u"ࠪࠫᩭ"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᩮ"),l1l111_l1_ (u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬᩯ"))
	if l1llll1l11_l1_==-1: return
	if l1llll1l11_l1_:
		l1llll1ll1_l1_ = True
		import subprocess
		try: subprocess.Popen(l1l111_l1_ (u"࠭ࡳࡶࠩᩰ"))
		except: l1llll1ll1_l1_ = False
		if l1llll1ll1_l1_:
			l1lll1111l_l1_ = l1ll111lll_l1_+l1l111_l1_ (u"ࠧࠡࠩᩱ")+l1ll11l111_l1_+l1l111_l1_ (u"ࠨࠢࠪᩲ")+l1lll11l11_l1_+l1l111_l1_ (u"ࠩࠣࠫᩳ")+l1lll1l111_l1_+l1l111_l1_ (u"ࠪࠤࠬᩴ")+l1ll11l1ll_l1_+l1l111_l1_ (u"ࠫࠥ࠭᩵")+l1ll11ll11_l1_
			proc = subprocess.Popen(l1l111_l1_ (u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭᩶")+l1lll1111l_l1_+l1l111_l1_ (u"࠭ࠢࠨ᩷"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ᩸"),l1l111_l1_ (u"ࠨࠩ᩹"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᩺"),l1l111_l1_ (u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭᩻"))
			settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ᩼"),l1l111_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ᩽"))
			xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ᩾"))
		else: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ᩿"),l1l111_l1_ (u"ࠨࠩ᪀"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪁"),l1l111_l1_ (u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪ᪂"))
	return
def l1lllll1ll_l1_(size):
	for x in [l1l111_l1_ (u"ࠫࡇ࠭᪃"),l1l111_l1_ (u"ࠬࡑࡂࠨ᪄"),l1l111_l1_ (u"࠭ࡍࡃࠩ᪅"),l1l111_l1_ (u"ࠧࡈࡄࠪ᪆"),l1l111_l1_ (u"ࠨࡖࡅࠫ᪇")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l111_l1_ (u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦ᪈")%(size,x)
	return text
def l1ll11l11l_l1_(l1llll11ll_l1_=l1l111_l1_ (u"ࠪ࠲ࠬ᪉")):
	global l1lll111ll_l1_,l1llll111l_l1_
	l1lll111ll_l1_,l1llll111l_l1_ = 0,0
	def l1lll11ll1_l1_(l1llll11ll_l1_):
		global l1lll111ll_l1_,l1llll111l_l1_
		if os.path.exists(l1llll11ll_l1_):
			if 0 and l1l111_l1_ (u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬ᪊") in dir(os):
				for l1ll111l1l_l1_ in os.scandir(l1llll11ll_l1_):
					if l1ll111l1l_l1_.l1llll11l1_l1_(follow_symlinks=False):
						l1lll11ll1_l1_(l1ll111l1l_l1_.path)
					elif l1ll111l1l_l1_.l1ll1ll111_l1_(follow_symlinks=False):
						l1lll111ll_l1_ += l1ll111l1l_l1_.stat().st_size
						l1llll111l_l1_ += 1
			else:
				for l1ll111l1l_l1_ in os.listdir(l1llll11ll_l1_):
					l1ll1111ll_l1_ = os.path.abspath(os.path.join(l1llll11ll_l1_,l1ll111l1l_l1_))
					if os.path.isdir(l1ll1111ll_l1_):
						l1lll11ll1_l1_(l1ll1111ll_l1_)
					elif os.path.isfile(l1ll1111ll_l1_):
						size,count = l1ll1l1ll1_l1_(l1ll1111ll_l1_)
						l1lll111ll_l1_ += size
						l1llll111l_l1_ += count
		return
	try: l1lll11ll1_l1_(l1llll11ll_l1_)
	except: pass
	return l1lll111ll_l1_,l1llll111l_l1_
def l1llll1111_l1_(l1lll111l1_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠬ࠭᪋"),l1l111_l1_ (u"࠭ࠧ᪌"),l1l111_l1_ (u"ࠧࠨ᪍"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪎"),l1lll111l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ᪏")+l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᪐"))
		if l1llll1l11_l1_!=1: return
	error = False
	if os.path.exists(l1lll111l1_l1_):
		try: os.remove(l1lll111l1_l1_)
		except Exception as err:
			if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ᪑"),l1l111_l1_ (u"ࠬ࠭᪒"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪓"),str(err))
			error = True
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ᪔"),l1l111_l1_ (u"ࠨࠩ᪕"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪖"),l1l111_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ᪗"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ᪘"),l1l111_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ᪙"))
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ᪚"))
	return
def l1ll111l11_l1_(l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠧࠨ᪛"),l1l111_l1_ (u"ࠨࠩ᪜"),l1l111_l1_ (u"ࠩࠪ᪝"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪞"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠫ᪟")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ᪠")+l1l111_l1_ (u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ᪡")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ᪢")+l1l111_l1_ (u"ࠨมࠤࠥࠬ᪣")+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᪤"))
		if l1llll1l11_l1_!=1: return
	l1lllll11l_l1_(l1lll11lll_l1_,True,False)
	l1lllll11l_l1_(l1ll111ll1_l1_,True,False)
	l1lllll11l_l1_(l1lll11l1l_l1_,False,False)
	l1ll11lll1_l1_(l1ll1l111l_l1_,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᪥"),l1l111_l1_ (u"ࠫࠬ᪦"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᪧ"),l1l111_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧ᪨"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ᪩"),l1l111_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫ᪪"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭᪫"))
	return
def l1ll1lllll_l1_(l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"ࠪࠫ᪬"),l1l111_l1_ (u"ࠫࠬ᪭"),l1l111_l1_ (u"ࠬ࠭᪮"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪯"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭᪰")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ᪱")+l1l111_l1_ (u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭᪲")+l1l111_l1_ (u"ࠪࡠࡳ࠭᪳")+l1l111_l1_ (u"ࠫࡄࠧࠡࠨ᪴")+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ᪵ࠧ"))
		if l1llll1l11_l1_!=1: return
	l1lllll11l_l1_(l1ll111lll_l1_,False,False)
	l1lllll11l_l1_(l1ll11l111_l1_,False,False)
	l1lllll11l_l1_(l1lll11l11_l1_,False,False)
	l1lllll11l_l1_(l1lll1l111_l1_,False,False)
	l1lllll11l_l1_(l1ll11l1ll_l1_,False,False)
	l1lllll11l_l1_(l1ll11ll11_l1_,False,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"᪶࠭ࠧ"),l1l111_l1_ (u"ࠧࠨ᪷"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯ᪸ࠫ"),l1l111_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯ᪹ࠪ"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹ᪺ࠧ"),l1l111_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᪻"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ᪼"))
	return
def l1ll11lll1_l1_(l1lll11111_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l11_l1_ = l1ll1l1111_l1_(l1l111_l1_ (u"᪽࠭ࠧ"),l1l111_l1_ (u"ࠧࠨ᪾"),l1l111_l1_ (u"ࠨᪿࠩ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะᫀࠬ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨ᫁")+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᫂"))
		if l1llll1l11_l1_!=1: return
	conn = sqlite3.connect(l1lll11111_l1_)
	conn.text_factory = str
	l1lllll1l1_l1_ = conn.cursor()
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼᫃ࠩ"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾᫄ࠫ"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧ᫅"))
	conn.commit()
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩ᫆"))
	conn.close()
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ᫇"),l1l111_l1_ (u"ࠪࠫ᫈"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᫉"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา᫊࠭"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ᫋"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᫌ"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᫍ"))
	return
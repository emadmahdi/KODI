# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ墵")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ墶")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1ll11_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l1111l111_l1_()
	elif mode==56: l1lll_l1_ = l11l111111ll_l1_()
	elif mode==57: l1lll_l1_ = l111ll111l_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll111l_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ墷"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ墸"),l1l111_l1_ (u"ࠬ࠭墹"),59,l1l111_l1_ (u"࠭ࠧ墺"),l1l111_l1_ (u"ࠧࠨ墻"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ墼"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ墽"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ墾"),l1l111_l1_ (u"ࠫࠬ墿"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壀"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ壁")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ壂"),l1l111_l1_ (u"ࠨࠩ壃"),56)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壄"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ壅")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊วโๆส้ࠬ壆"),l1l111_l1_ (u"ࠬ࠭壇"),55)
	return l1l111_l1_ (u"࠭ࠧ壈")
def l11l1111l111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壉"),l1lllll_l1_+l1l111_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ壊"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ壋"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壌"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ壍"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ壎"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壏"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ壐"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ壑"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壒"),l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ壓"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ壔"),51)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ壕"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭壖"),l1l111_l1_ (u"ࠧࠨ壗"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壘"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭壙"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ壚"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壛"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ壜"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ壝"),57)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壞"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ壟"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ壠"),57)
	return
def l11l111111ll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壡"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ壢"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ壣"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壤"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ壥"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ壦"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壧"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ壨"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ壩"),51)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壪"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ士"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ壬"),51)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭壭"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ壮"),l1l111_l1_ (u"ࠪࠫ壯"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ声"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ壱"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭売"),57)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壳"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ壴"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ壵"),57)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壶"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ壷"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ壸"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"࠭࠿ࠨ壹") in url:
		parts = url.split(l1l111_l1_ (u"ࠧࡀࠩ壺"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠨࡁࠪ壻") + QUOTE(parts[1],l1l111_l1_ (u"ࠩࡀࠪ࠿࠵ࠥࠨ壼"))
	else: filter = l1l111_l1_ (u"ࠪࠫ壽")
	parts = url.split(l1l111_l1_ (u"ࠫ࠴࠭壾"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"ࠬࡿ࡯ࡱࠩ壿"),l1l111_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼ࠭夀"),l1l111_l1_ (u"ࠧࡷ࡫ࡨࡻࡸ࠭夁")]:
		if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ夂"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠩไ๎้๋ࠧ夃")
		elif type==l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ处"): l1l1l1lll_l1_=l1l111_l1_ (u"ู๊ࠫไิๆࠪ夅")
		url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭夆") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"࠭࠯ࠨ备") + l1llllll1_l1_ + l1l111_l1_ (u"ࠧ࠰ࠩ夈") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ変"),l1l111_l1_ (u"ࠩࠪ夊"),l1l111_l1_ (u"ࠪࠫ夋"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ夌"))
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡱࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡶࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡳࡶࡪࡹࡢࡢࡵࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭复"),html,re.DOTALL)
		l1ll1l1111l_l1_=0
		for id,title,l11l111111l1_l1_,l1ll1l_l1_ in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1ll1l1ll11_l1_ + l1l111_l1_ (u"࠭࠯ࡷ࠴࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰࡯ࡤ࡭ࡳ࠵ࠧ夎") + l1ll1l_l1_ + l1l111_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ夏")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ夐") + id
			if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ夑"): addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ夒"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ夓"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ夔"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ࠥ࠭夕")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ外")+l11l111111l1_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ夗")+title+l1l111_l1_ (u"ࠩࡀࠫ夘")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ夙"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ多")
		elif type==l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ夛"): l1l1l1lll_l1_=l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭夜")
		url = l1l1l1ll1l_l1_ + l1l111_l1_ (u"ࠧ࠰࡬ࡶࡳࡳ࠵ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠰ࠩ夝") + sort + l1l111_l1_ (u"ࠨ࠯ࠪ夞") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠩ࠰࡛࡜࠴ࡪࡴࡱࡱࠫ够")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ夠"),l1l111_l1_ (u"ࠫࠬ夡"),l1l111_l1_ (u"ࠬ࠭夢"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ夣"))
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ夤"),html,re.DOTALL)
		l1ll1l1111l_l1_=0
		for id,l11l111111l1_l1_,l1ll1l_l1_,title in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1l1l1ll1l_l1_ + l1l111_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ夥") + l1ll1l_l1_ + l1l111_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ夦")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭大") + id
			if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ夨"): addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ天"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭太"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ夫"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊ࠠࠨ夬")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡩࡵࡃࠧ夭")+l11l111111l1_l1_+l1l111_l1_ (u"ࠪࡁࠬ央")+title+l1l111_l1_ (u"ࠫࡂ࠭夯")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ夰")
	if l1ll1l1111l_l1_==16:
		for l1ll1l1ll1l_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1ll1l_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ失")+type+l1l111_l1_ (u"ࠧ࠰ࠩ夲")+str(l1ll1l1ll1l_l1_)+l1l111_l1_ (u"ࠨ࠱ࠪ夳")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ头"),l1lllll_l1_+title+str(l1ll1l1ll1l_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠪࡁࠬ夵"))
	l11l111111l1_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ夶"),l1l111_l1_ (u"ࠬ࠭夷"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"࠭࠿ࠨ夸"))[0]
	if l11l111111l1_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ夹"),l1l111_l1_ (u"ࠨࠩ夺"),l1l111_l1_ (u"ࠩࠪ夻"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ夼"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬ夽"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ夾"),block,re.DOTALL)
		l11l111111l1_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l111111l1_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"࠭࠿ࡦࡲࡀࠫ夿") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ奀")+name+l1l111_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤࠬ奁")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ奂"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ奃"),l1l111_l1_ (u"ࠫࠬ奄"),l1l111_l1_ (u"ࠬ࠭奅"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ奆"))
	l11l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠧๆฬ๋ๅึูࠦๅุ๋ࠣํ็ࠠๆษๆืࠥฮูะ࠰࠭ࡃࡲࡵ࡭ࡦࡰࡷࡠ࠭ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奇"),html,re.DOTALL)
	if l11l11111l11_l1_:
		time = l11l11111l11_l1_[1].replace(l1l111_l1_ (u"ࠨࡖࠪ奈"),l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ奉"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ奊"),l1l111_l1_ (u"ࠫࠬ奋"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ奌"),l1l111_l1_ (u"࠭็ัษࠣห้็๊ะ์๋ࠤุ๐ใ้่้ࠣฯ๎แาࠢ฼่๎ࠦิ้ใ้ࠣฬ้ำࠡส฼ำࠥํะศࠢส่ํ่สࠨ奍")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ奎")+time)
		return
	l11l11111111_l1_,l11l11111ll1_l1_ = [],[]
	l11l11111lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奏"),html,re.DOTALL)[0]
	l11l11111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡢࡢࡥ࡮ࡹࡵࡥ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奐"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡱࡹ࠺ࠡࠪ࠱࠮ࡄ࠯࡟࡭࡫ࡱ࡯ࡡ࠱ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ契"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ奒") in server:
			server = l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ奓")
			url = l11l11111l1l_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ奔")
			url = l11l11111lll_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭奕") in url:
			l11l11111111_l1_.append(url)
			l11l11111ll1_l1_.append(l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠠࠨ奖")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁࡢࡰ࡮ࡴ࡫࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ套"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ奘"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭奙"))[-1]
		filename = filename.replace(l1l111_l1_ (u"ࠬ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠧ奚"),l1l111_l1_ (u"࠭ࠧ奛"))
		filename = filename.replace(l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ奜"),l1l111_l1_ (u"ࠨࠩ奝"))
		filename = filename.replace(l1l111_l1_ (u"ࠩ࠰ࠫ奞"),l1l111_l1_ (u"ࠪࠫ奟"))
		if l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ奠") in server:
			server = l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ奡")
			url = l11l11111l1l_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ奢")
			url = l11l11111lll_l1_ + l1ll1ll_l1_
		l11l11111111_l1_.append(url)
		l11l11111ll1_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࠤࠥ࠭奣")+server+l1l111_l1_ (u"ࠨࠢࠣࠫ奤")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡙ࠢ࡭ࡩ࡫࡯ࠡࡓࡸࡥࡱ࡯ࡴࡺ࠼ࠪ奥"), l11l11111ll1_l1_)
	if l11l11l_l1_ == -1 : return
	url = l11l11111111_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ奦"))
	return
def l111ll111l_l1_(url,type):
	if l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ奧") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴๋ำๅี็ࠫ奨")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵แ๋ๆ่ࠫ奩")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ奪"),l1l111_l1_ (u"ࠨࠩ奫"),l1l111_l1_ (u"ࠩࠪ奬"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡌࡉࡍࡖࡈࡖࡘ࠳࠱ࡴࡶࠪ奭"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡻࡢࡨࡧࡱࡶࡪ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ奮"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ奯"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡯ࡱࡶ࡬ࡳࡳ࠭奰"),block,re.DOTALL)
	if type==1:
		for l11l1111111l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奱"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠨࡁࡶࡹࡧ࡭ࡥ࡯ࡴࡨࡁࠬ奲")+l11l1111111l_l1_,58)
	elif type==2:
		url,l11l1111111l_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࠫ女"))
		for l1lll1l1ll11_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奴"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠫࡄࡩ࡯ࡶࡰࡷࡶࡾࡃࠧ奵")+l1lll1l1ll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ奶")+l11l1111111l_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"࠭ࠠࠨ奷"),l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ奸"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬ她")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭奺"),url,l1l111_l1_ (u"ࠪࠫ奻"),l1l111_l1_ (u"ࠫࠬ奼"),True,l1l111_l1_ (u"ࠬ࠭好"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠴ࡱࡨࠬ奾"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡨࡧࡱࡩࡷࡧ࡬࠮ࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡷࡪࡧࡲࡤࡪ࠰ࡦࡴࡺࡴࡰ࡯࠰ࡴࡦࡪࡤࡪࡰࡪࠫ奿"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ妀"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ妁") in url:
				if l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ如") in url:
					title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ妃")+title
					url = url.replace(l1l111_l1_ (u"ࠬࡅࡥࡱ࠿࠴ࠫ妄"),l1l111_l1_ (u"࠭࠿ࡦࡲࡀ࠴ࠬ妅"))
					url = url+l1l111_l1_ (u"ࠧ࠾ࠩ妆")+QUOTE(title)+l1l111_l1_ (u"ࠨ࠿ࠪ妇")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妈"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠใํ่๊ࠦࠧ妉")+title
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ妊"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
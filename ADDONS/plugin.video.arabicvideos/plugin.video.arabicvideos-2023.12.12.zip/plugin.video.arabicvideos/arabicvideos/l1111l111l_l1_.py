# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
import bs4
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ○")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡉࡑࡉ࡟ࠨ◌")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ◍"):l111l1_l1_}
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==510: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==511: l1lll_l1_ = l1llllll111_l1_(url)
	elif mode==512: l1lll_l1_ = l1111lll11_l1_(url)
	elif mode==513: l1lll_l1_ = l1111ll1ll_l1_(url)
	elif mode==514: l1lll_l1_ = l1llllll1l1_l1_(url,l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ◎")+text)
	elif mode==515: l1lll_l1_ = l1llllll1l1_l1_(url,l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ●")+text)
	elif mode==516: l1lll_l1_ = l11111l1ll_l1_(text)
	elif mode==517: l1lll_l1_ = l1111l1l11_l1_(url)
	elif mode==518: l1lll_l1_ = l1111l1l1l_l1_(url)
	elif mode==519: l1lll_l1_ = l1lll1_l1_(text)
	elif mode==520: l1lll_l1_ = l11111lll1_l1_(url)
	elif mode==521: l1lll_l1_ = l1lllll1lll_l1_(url)
	elif mode==522: l1lll_l1_ = PLAY(url)
	elif mode==523: l1lll_l1_ = l1lllllll1l_l1_(text)
	elif mode==524: l1lll_l1_ = l111111111_l1_()
	elif mode==525: l1lll_l1_ = l1111ll1l1_l1_()
	elif mode==526: l1lll_l1_ = l11111ll1l_l1_()
	elif mode==527: l1lll_l1_ = l11111111l_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_(l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧ◐")):
	if not l1l11l11_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◑"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ◒"),l1l111_l1_ (u"ࠩࠪ◓"),519)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ◔"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭◕"),l1l111_l1_ (u"ࠬ࠭◖"),9999)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◗"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆฦ฽๊อไࠨ◘"),l1l111_l1_ (u"ࠨࠩ◙"),525)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◚"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํฺู่หࠣห้ษิฯษุࠫ◛"),l1l111_l1_ (u"ࠫࠬ◜"),526)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◝"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅ็ุ๊ๆอสࠨ◞"),l1l111_l1_ (u"ࠧࠨ◟"),527)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◠"),l1lllll_l1_+l1l111_l1_ (u"่ࠩ์ุ๎ูสࠢส่๊์ฺ่ษอࠫ◡"),l1l111_l1_ (u"ࠪࠫ◢"),524)
	return
def l111111111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◣"),l1lllll_l1_+l1l111_l1_ (u"ࠬࠦแ๋ัํ์์อสࠡ࠯ࠣาฬ฻ษࠨ◤"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠭◥"),520)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◦"),l1lllll_l1_+l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษอะอࠪ◧"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱࡯ࡥࡹ࡫ࡳࡵࠩ◨"),521)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◩"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡลๅำ๊࠭◪"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡵ࡬ࡥࡧࡶࡸࠬ◫"),521)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◬"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢ࠰ࠤศ้หาุ่ࠢฬํฯสࠩ◭"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࡸ࡬ࡩࡼࡹࠧ◮"),521)
	return
def l1111ll1l1_l1_():
	l1llllll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠫ◯")
	l111111lll_l1_ = l1llllll1ll_l1_+l1l111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭◰")
	l1111ll11l_l1_ = l1llllll1ll_l1_+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡪࡦࡲࡳࡦࠨࡷࡥ࡬ࡃࠧ◱")
	l1111111l1_l1_ = l1llllll1ll_l1_+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠳ࠩࡪࡴࡸࡥࡪࡩࡱࡁࡹࡸࡵࡦࠨࡷࡥ࡬ࡃࠧ◲")
	l1111111ll_l1_ = l1llllll1ll_l1_+l1l111_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠸ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠶ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࡺࡲࡶࡧࠩࡸࡦ࡭࠽ࠨ◳")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◴"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡลไ่ฬฺ๋ࠠำห๎ࠬ◵"),l111111lll_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◶"),l1lllll_l1_+l1l111_l1_ (u"ฺ้ࠪ์แศฬุ้๊ࠣำๅษอࠤ฾ืศ๋ࠩ◷"),l1111ll11l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◸"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥษแๅษ่ࠤฬาๆษ์ࠪ◹"),l1111111l1_l1_,511)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◺"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆื้ๅฬะࠠๆี็ื้อสࠡษฯ๊อ๐ࠧ◻"),l1111111ll_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭◼"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ◽"),l1l111_l1_ (u"ࠪࠫ◾"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◿"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็็าีࠣว฾๋วๅࠢฦฬัี๊ࠨ☀"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡦࡲࡰࡩࡣࡥࡩࡹ࠭☁"),517)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☂"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦࠠษๆาࠤฬ๊ล็ฬสะࠬ☃"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡤࡱࡸࡲࡹࡸࡹࠨ☄"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ★"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิࠢส่้เษࠨ☆"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡰࡦࡴࡧࡶࡣࡪࡩࠬ☇"),517)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☈"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิื๋ࠥี็ใสฮࠥอไฺ็็ࠫ☉"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡧࡦࡰࡵࡩࠬ☊"),517)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☋"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡี้อࠥอไฦืาหึ࠭☌"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡵࡩࡱ࡫ࡡࡴࡧࡢࡽࡪࡧࡲࠨ☍"),517)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ☎"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠸࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ☏"),l1l111_l1_ (u"ࠧࠨ☐"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☑"),l1lllll_l1_+l1l111_l1_ (u"่ࠩ์ฬูๅࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭☒"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ☓"),515)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☔"),l1lllll_l1_+l1l111_l1_ (u"๋่ࠬศี่ࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩ☕"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪ☖"),514)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ☗"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠷ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠴࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ☘"),l1l111_l1_ (u"ࠩࠪ☙"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☚"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ๊ำฯะࠩ☛"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭☜"),515)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☝"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆื้ๅฬะࠠ࠮ࠢไ่ฯืࠠไษ่่ࠬ☞"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ☟"),514)
	return
def l11111111l_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭☠"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ☡"),l1l111_l1_ (u"ࠫࠬ☢"),headers,l1l111_l1_ (u"ࠬ࠭☣"),l1l111_l1_ (u"࠭ࠧ☤"),l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ☥"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭☦"),multi_valued_attributes=None)
	block = l1lllll1ll1_l1_.find(l1l111_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵࠩ☧"),attrs={l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ☨"):l1l111_l1_ (u"ࠫࡹࡧࡧࠨ☩")})
	options = block.find_all(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠬ☪"))
	for option in options:
		value = option.get(l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ☫"))
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ☬"))
			value = value.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭☭"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠪࡹࡿࡰࡦ࠿ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭☮")+value
		title = title.replace(l1l111_l1_ (u"ࠪๆฬฬๅสࠢࠪ☯"),l1l111_l1_ (u"ࠫࠬ☰"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☱"),l1lllll_l1_+title,l1ll1ll_l1_,511)
	return
def l11111ll1l_l1_():
	l1llllll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠨ☲")
	l111111ll1_l1_ = l1llllll1ll_l1_+l1l111_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫ☳")
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☴"),l1lllll_l1_+l1l111_l1_ (u"ู่๋ࠩ็วหࠢฦุำอีࠨ☵"),l111111ll1_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ☶"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭☷"),l1l111_l1_ (u"ࠬ࠭☸"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☹"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิืࠥษิฯษุࠤศฮฬะ์ࠪ☺"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡣ࡯ࡴ࡭ࡧࡢࡦࡶࠪ☻"),517)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☼"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡ็๋฻๋࠭☽"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡳࡧࡴࡪࡱࡱࡥࡱ࡯ࡴࡺࠩ☾"),517)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☿"),l1lllll_l1_+l1l111_l1_ (u"࠭แ่ำึࠤࠥะวา์ัࠤฬ๊ๅ๋ๆสำࠬ♀"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯ࡣ࡫ࡵࡸ࡭ࡥࡹࡦࡣࡵࠫ♁"),517)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♂"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๋ึูࠠࠡฬสี๏ิࠠศๆ๋ๅฬฯࠧ♃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡨࡪࡧࡴࡩࡡࡼࡩࡦࡸࠧ♄"),517)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ♅"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ♆"),l1l111_l1_ (u"࠭ࠧ♇"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ♈"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭♉"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ♊"),515)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ♋"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩ♌"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭♍"),514)
	return
def l1llllll111_l1_(url):
	if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪ♎") in url: index = 0
	elif l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ♏") in url: index = 1
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ♐"),url,l1l111_l1_ (u"ࠩࠪ♑"),headers,l1l111_l1_ (u"ࠪࠫ♒"),l1l111_l1_ (u"ࠫࠬ♓"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡍࡋࡖࡘࡘ࠳࠱ࡴࡶࠪ♔"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ♕"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1ll1_l1_.find_all(class_=l1l111_l1_ (u"ࠧ࡫ࡷࡰࡦࡴ࠳ࡴࡩࡧࡤࡸࡪࡸࠠࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠩ♖"))
	for block in l1lll1l1_l1_:
		title = block.find_all(l1l111_l1_ (u"ࠨࡣࠪ♗"))[index].text
		l1ll1ll_l1_ = l111l1_l1_+block.find_all(l1l111_l1_ (u"ࠩࡤࠫ♘"))[index].get(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ♙"))
		if kodi_version<19:
			title = title.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♚"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♛"))
		if not l1lll1l1_l1_:
			l1111lll11_l1_(l1ll1ll_l1_)
			return
		else:
			title = title.replace(l1l111_l1_ (u"࠭โศศ่อࠥ࠭♜"),l1l111_l1_ (u"ࠧࠨ♝"))
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♞"),l1lllll_l1_+title,l1ll1ll_l1_,512)
	PAGINATION(l1lllll1ll1_l1_,511)
	return
def PAGINATION(l1lllll1ll1_l1_,mode):
	block = l1lllll1ll1_l1_.find(class_=l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭♟"))
	if block:
		l1ll1l1ll_l1_ = block.find_all(l1l111_l1_ (u"ࠪࡥࠬ♠"))
		l1lllll1l1l_l1_ = block.find_all(l1l111_l1_ (u"ࠫࡱ࡯ࠧ♡"))
		l11111ll11_l1_ = list(zip(l1ll1l1ll_l1_,l1lllll1l1l_l1_))
		l1l11l111l_l1_ = -1
		length = len(l11111ll11_l1_)
		for l1lll1l1l_l1_,l1lllllll11_l1_ in l11111ll11_l1_:
			l1l11l111l_l1_ += 1
			l1lllllll11_l1_ = l1lllllll11_l1_[l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࠫ♢")]
			if l1l111_l1_ (u"࠭ࡵ࡯ࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠫ♣") in l1lllllll11_l1_ or l1l111_l1_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࠨ♤") in l1lllllll11_l1_: continue
			l1lllllllll_l1_ = l1lll1l1l_l1_.text
			l111lllll_l1_ = l111l1_l1_+l1lll1l1l_l1_.get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭♥"))
			if kodi_version<19:
				l1lllllllll_l1_ = l1lllllllll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♦"))
				l111lllll_l1_ = l111lllll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♧"))
			if   l1l11l111l_l1_==0: l1lllllllll_l1_ = l1l111_l1_ (u"ࠫศ๎ไ๊ࠩ♨")
			elif l1l11l111l_l1_==1: l1lllllllll_l1_ = l1l111_l1_ (u"ูࠬวษไฬࠫ♩")
			elif l1l11l111l_l1_==length-2: l1lllllllll_l1_ = l1l111_l1_ (u"࠭ไศฯๅอࠬ♪")
			elif l1l11l111l_l1_==length-1: l1lllllllll_l1_ = l1l111_l1_ (u"ࠧฤะํีฮ࠭♫")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♬"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ♭")+l1lllllllll_l1_,l111lllll_l1_,mode)
	return
def l1111lll11_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ♮"),url,l1l111_l1_ (u"ࠫࠬ♯"),headers,l1l111_l1_ (u"ࠬ࠭♰"),l1l111_l1_ (u"࠭ࠧ♱"),l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠳࠰࠵ࡸࡺࠧ♲"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭♳"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1ll1_l1_.find_all(class_=l1l111_l1_ (u"ࠩࡵࡳࡼ࠭♴"))
	items,first = [],True
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠳ࡷࡳࡣࡳࡴࡪࡸࠧ♵")): continue
		if first: first = False ; continue
		l111111l11_l1_ = []
		l1lllll1l11_l1_ = block.find_all(class_=[l1l111_l1_ (u"ࠫࡨ࡫࡮ࡴࡱࡵࡷ࡭࡯ࡰࠡࡴࡨࡨࠬ♶"),l1l111_l1_ (u"ࠬࡩࡥ࡯ࡵࡲࡶࡸ࡮ࡩࡱࠢࡳࡹࡷࡶ࡬ࡦࠩ♷")])
		for l1llllllll1_l1_ in l1lllll1l11_l1_:
			l1111lll1l_l1_ = l1llllllll1_l1_.find_all(l1l111_l1_ (u"࠭࡬ࡪࠩ♸"))[1].text
			if kodi_version<19:
				l1111lll1l_l1_ = l1111lll1l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♹"))
			l111111l11_l1_.append(l1111lll1l_l1_)
		if not l11111l_l1_(l1ll1_l1_,l1l111_l1_ (u"ࠨࠩ♺"),l111111l11_l1_,False):
			l11l_l1_ = block.find(l1l111_l1_ (u"ࠩ࡬ࡱ࡬࠭♻")).get(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ♼"))
			title = block.find(l1l111_l1_ (u"ࠫ࡭࠹ࠧ♽"))
			name = title.find(l1l111_l1_ (u"ࠬࡧࠧ♾")).text
			l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"࠭ࡡࠨ♿")).get(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬ⚀"))
			l1111l11ll_l1_ = block.find(class_=l1l111_l1_ (u"ࠨࡰࡲ࠱ࡲࡧࡲࡨ࡫ࡱࠫ⚁"))
			l111111l1l_l1_ = block.find(class_=l1l111_l1_ (u"ࠩ࡯ࡩ࡬࡫࡮ࡥࠩ⚂"))
			if l1111l11ll_l1_: l1111l11ll_l1_ = l1111l11ll_l1_.text
			if l111111l1l_l1_: l111111l1l_l1_ = l111111l1l_l1_.text
			if kodi_version<19:
				l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚃"))
				name = name.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚄"))
				l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚅"))
				if l1111l11ll_l1_: l1111l11ll_l1_ = l1111l11ll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚆"))
			l1llllll11l_l1_ = {}
			if l111111l1l_l1_: l1llllll11l_l1_[l1l111_l1_ (u"ࠧࡴࡶࡤࡶࡸ࠭⚇")] = l111111l1l_l1_
			if l1111l11ll_l1_:
				l1111l11ll_l1_ = l1111l11ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ⚈"),l1l111_l1_ (u"ࠩࠣ࠲࠳ࠦࠧ⚉"))
				l1llllll11l_l1_[l1l111_l1_ (u"ࠪࡴࡱࡵࡴࠨ⚊")] = l1111l11ll_l1_.replace(l1l111_l1_ (u"ࠫ࠳࠴࠮ศไิวࠥอไๆิํำࠬ⚋"),l1l111_l1_ (u"ࠬ࠭⚌"))
			if l1l111_l1_ (u"࠭࠯ࡸࡱࡵ࡯࠴࠭⚍") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚎"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠨࠩ⚏"),name,l1l111_l1_ (u"ࠩࠪ⚐"),l1llllll11l_l1_)
			elif l1l111_l1_ (u"ࠪ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⚑") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚒"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠬ࠭⚓"),name,l1l111_l1_ (u"࠭ࠧ⚔"),l1llllll11l_l1_)
	PAGINATION(l1lllll1ll1_l1_,512)
	return
def l1111ll1ll_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⚕"),url,l1l111_l1_ (u"ࠨࠩ⚖"),headers,l1l111_l1_ (u"ࠩࠪ⚗"),l1l111_l1_ (u"ࠪࠫ⚘"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠸࠭࠲ࡵࡷࠫ⚙"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⚚"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1ll1_l1_.find_all(l1l111_l1_ (u"࠭࡬ࡪࠩ⚛"))
	names,items = [],[]
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠰ࡻࡷࡧࡰࡱࡧࡵࠫ⚜")): continue
		if not block.find(class_=[l1l111_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠪ⚝"),l1l111_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠤࡹ࡫ࡸࡵ࠯ࡦࡩࡳࡺࡥࡳࠩ⚞")]): continue
		if block.find(class_=l1l111_l1_ (u"ࠪ࡬࡮ࡪࡥࠨ⚟")): continue
		title = block.find(class_=[l1l111_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩ࠭⚠"),l1l111_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠠࡵࡧࡻࡸ࠲ࡩࡥ࡯ࡶࡨࡶࠬ⚡")])
		name = title.find(l1l111_l1_ (u"࠭ࡡࠨ⚢")).text
		if name in names: continue
		names.append(name)
		l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠧࡢࠩ⚣")).get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭⚤"))
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡻࡴࡸ࡫࠰ࠩ⚥") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠧ⚦")).get(l1l111_l1_ (u"ࠫࡸࡸࡣࠨ⚧"))
		elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ⚨") in url: l11l_l1_ = block.find(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠪ⚩")).get(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ⚪"))
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ⚫") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠩ࡬ࡱ࡬࠭⚬")).get(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ⚭"))
		else: l11l_l1_ = block.find(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠨ⚮")).get(l1l111_l1_ (u"ࠬࡹࡲࡤࠩ⚯"))
		if kodi_version<19:
			name = name.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚰"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚱"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚲"))
		name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ⚳"))
		items.append((name,l1ll1ll_l1_,l11l_l1_))
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⚴") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1ll1ll_l1_,l11l_l1_ in items:
		if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡼࡩࡥࡧࡲ࠳ࠬ⚵") in url: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⚶"),l1lllll_l1_+name,l1ll1ll_l1_,522,l11l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ⚷") in url: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚸"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠨࠩ⚹"),name)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⚺"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠪࠫ⚻"),name)
	return
def l11111l1ll_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠫฬ๊ลฺๆส๊ࠬ⚼"),l1l111_l1_ (u"ࠬ࠭⚽")).replace(l1l111_l1_ (u"࠭ไโ์็้ࠬ⚾"),l1l111_l1_ (u"ࠧࠨ⚿")).replace(l1l111_l1_ (u"ࠨษ็ีุ๋๊ࠨ⛀"),l1l111_l1_ (u"ࠩࠪ⛁"))
	text = text.replace(l1l111_l1_ (u"ࠪษ฾๊ว็ࠩ⛂"),l1l111_l1_ (u"ࠫࠬ⛃")).replace(l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ⛄"),l1l111_l1_ (u"࠭ࠧ⛅")).replace(l1l111_l1_ (u"ࠧศๆหีํ๋่ࠨ⛆"),l1l111_l1_ (u"ࠨࠩ⛇"))
	text = text.replace(l1l111_l1_ (u"ࠩส่ฯฺ่๋ไํࠫ⛈"),l1l111_l1_ (u"ࠪࠫ⛉")).replace(l1l111_l1_ (u"้๋ࠫำๅี็ࠫ⛊"),l1l111_l1_ (u"ࠬ࠭⛋")).replace(l1l111_l1_ (u"࠭ๅิๆึ่ࠬ⛌"),l1l111_l1_ (u"ࠧࠨ⛍"))
	text = text.replace(l1l111_l1_ (u"ࠨ࠼ࠪ⛎"),l1l111_l1_ (u"ࠩࠪ⛏")).replace(l1l111_l1_ (u"ࠪ࠭ࠬ⛐"),l1l111_l1_ (u"ࠫࠬ⛑")).replace(l1l111_l1_ (u"ࠬ࠮ࠧ⛒"),l1l111_l1_ (u"࠭ࠧ⛓")).replace(l1l111_l1_ (u"ࠧ࠭ࠩ⛔"),l1l111_l1_ (u"ࠨࠩ⛕"))
	text = text.replace(l1l111_l1_ (u"ࠩࡢࠫ⛖"),l1l111_l1_ (u"ࠪࠫ⛗")).replace(l1l111_l1_ (u"ࠫࡀ࠭⛘"),l1l111_l1_ (u"ࠬ࠭⛙")).replace(l1l111_l1_ (u"࠭࠭ࠨ⛚"),l1l111_l1_ (u"ࠧࠨ⛛")).replace(l1l111_l1_ (u"ࠨ࠰ࠪ⛜"),l1l111_l1_ (u"ࠩࠪ⛝"))
	text = text.replace(l1l111_l1_ (u"ࠪࡠࠬ࠭⛞"),l1l111_l1_ (u"ࠫࠬ⛟")).replace(l1l111_l1_ (u"ࠬࡢࠢࠨ⛠"),l1l111_l1_ (u"࠭ࠧ⛡"))
	text = text.replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ⛢"),l1l111_l1_ (u"ࠨࠢࠪ⛣")).replace(l1l111_l1_ (u"ࠩࠣࠤࠥ࠭⛤"),l1l111_l1_ (u"ࠪࠤࠬ⛥")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ⛦"),l1l111_l1_ (u"ࠬࠦࠧ⛧"))
	text = text.strip(l1l111_l1_ (u"࠭ࠠࠨ⛨"))
	l1111l1ll1_l1_ = text.count(l1l111_l1_ (u"ࠧࠡࠩ⛩"))+1
	if l1111l1ll1_l1_==1:
		l1lllllll1l_l1_(text)
		return
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⛪"),l1lllll_l1_+l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾ࠢๆ่๊อสࠡๆ็ฬาัࠠ࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⛫"),l1l111_l1_ (u"ࠪࠫ⛬"),9999)
	l11111l11l_l1_ = text.split(l1l111_l1_ (u"ࠫࠥ࠭⛭"))
	l1111ll111_l1_ = pow(2,l1111l1ll1_l1_)
	l1111l1111_l1_ = []
	def l11111l111_l1_(a,b):
		if a==l1l111_l1_ (u"ࠬ࠷ࠧ⛮"): return b
		return l1l111_l1_ (u"࠭ࠧ⛯")
	for l1l11l111l_l1_ in range(l1111ll111_l1_,0,-1):
		l11111llll_l1_ = list(l1111l1ll1_l1_*l1l111_l1_ (u"ࠧ࠱ࠩ⛰")+bin(l1l11l111l_l1_)[2:])[-l1111l1ll1_l1_:]
		l11111llll_l1_ = reversed(l11111llll_l1_)
		result = map(l11111l111_l1_,l11111llll_l1_,l11111l11l_l1_)
		title = l1l111_l1_ (u"ࠨࠢࠪ⛱").join(filter(None,result))
		if kodi_version<19: l1lllllll_l1_ = title.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⛲"))
		else: l1lllllll_l1_ = title
		if len(l1lllllll_l1_)>2 and title not in l1111l1111_l1_:
			l1111l1111_l1_.append(title)
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛳"),l1lllll_l1_+title,l1l111_l1_ (u"ࠫࠬ⛴"),523,l1l111_l1_ (u"ࠬ࠭⛵"),l1l111_l1_ (u"࠭ࠧ⛶"),title)
	return
def l1lllllll1l_l1_(l1111l1lll_l1_):
	if kodi_version<19:
		l1111l1lll_l1_ = l1111l1lll_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⛷"))
		import arabic_reshaper
		l1111l1lll_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1111l1lll_l1_)
		l1111l1lll_l1_ = bidi.algorithm.get_display(l1111l1lll_l1_)
	import l1111l11l1_l1_
	l1111l1lll_l1_ = l1llll1_l1_(default=l1111l1lll_l1_)
	l1111l11l1_l1_.l1lll1_l1_(l1111l1lll_l1_)
	return
def l1111l1l11_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⛸"),url,l1l111_l1_ (u"ࠩࠪ⛹"),headers,l1l111_l1_ (u"ࠪࠫ⛺"),l1l111_l1_ (u"ࠫࠬ⛻"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡊࡐࡇࡉ࡝ࡋࡓࡠࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫ⛼"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ⛽"),multi_valued_attributes=None)
	block = l1lllll1ll1_l1_.find(class_=l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸ࠲ࡹࡥࡱࡣࡵࡥࡹࡵࡲࠡ࡮࡬ࡷࡹ࠳ࡴࡪࡶ࡯ࡩࠬ⛾"))
	l11l11_l1_ = block.find_all(l1l111_l1_ (u"ࠨࡣࠪ⛿"))
	items = []
	for title in l11l11_l1_:
		name = title.text
		l1ll1ll_l1_ = l111l1_l1_+title.get(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ✀"))
		if kodi_version<19:
			name = name.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✁"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✂"))
		if l1l111_l1_ (u"ࠬࠩࠧ✃") not in l1ll1ll_l1_: items.append((name,l1ll1ll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1ll1ll_l1_ = item
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✄"),l1lllll_l1_+name,l1ll1ll_l1_,518)
	return
def l1111l1l1l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ✅"),url,l1l111_l1_ (u"ࠨࠩ✆"),headers,l1l111_l1_ (u"ࠩࠪ✇"),l1l111_l1_ (u"ࠪࠫ✈"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ✉"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ✊"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1ll1_l1_.find(class_=l1l111_l1_ (u"࠭ࡥࡹࡲࡤࡲࡩ࠭✋")).find_all(l1l111_l1_ (u"ࠧࡵࡴࠪ✌"))
	for block in l1lll1l1_l1_:
		l11111l1l1_l1_ = block.find_all(l1l111_l1_ (u"ࠨࡣࠪ✍"))
		if not l11111l1l1_l1_: continue
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠩ࡬ࡱ࡬࠭✎")).get(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ✏"))
		name = l11111l1l1_l1_[1].text
		l1ll1ll_l1_ = l111l1_l1_+l11111l1l1_l1_[1].get(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ✐"))
		l111111l1l_l1_ = block.find(class_=l1l111_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬ✑"))
		if l111111l1l_l1_: l111111l1l_l1_ = l111111l1l_l1_.text
		if kodi_version<19:
			name = name.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ✒"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ✓"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭✔"))
		l1llllll11l_l1_ = {}
		if l111111l1l_l1_: l1llllll11l_l1_[l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡳࠨ✕")] = l111111l1l_l1_
		if l1l111_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪ✖") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✗"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠬ࠭✘"),name,l1l111_l1_ (u"࠭ࠧ✙"),l1llllll11l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ✚") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ✛"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠩࠪ✜"),name,l1l111_l1_ (u"ࠪࠫ✝"),l1llllll11l_l1_)
	PAGINATION(l1lllll1ll1_l1_,518)
	return
def l11111lll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ✞"),url,l1l111_l1_ (u"ࠬ࠭✟"),headers,l1l111_l1_ (u"࠭ࠧ✠"),l1l111_l1_ (u"ࠧࠨ✡"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰࡚ࡎࡊࡅࡐࡕࡢࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭✢"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ✣"),multi_valued_attributes=None)
	l11l11_l1_ = l1lllll1ll1_l1_.find_all(class_=l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱ࠱ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࡲࡩ࡯ࡧࠪ✤"))
	l1ll_l1_ = l1lllll1ll1_l1_.find_all(class_=l1l111_l1_ (u"ࠫࡧࡻࡴࡵࡱࡱࠤ࡬ࡸࡥࡦࡰࠣࡷࡲࡧ࡬࡭ࠢࡵ࡭࡬࡮ࡴࠨ✥"))
	items = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in items:
		title = title.text
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ✦"))
		if kodi_version<19:
			title = title.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ✧"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ✨"))
		title = title.replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭✩"),l1l111_l1_ (u"ࠩࠣࠫ✪")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ✫"),l1l111_l1_ (u"ࠫࠥ࠭✬")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ✭"),l1l111_l1_ (u"࠭ࠠࠨ✮"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✯"),l1lllll_l1_+title,l1ll1ll_l1_,521)
	return
def l1lllll1lll_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ✰"),url,l1l111_l1_ (u"ࠩࠪ✱"),headers,l1l111_l1_ (u"ࠪࠫ✲"),l1l111_l1_ (u"ࠫࠬ✳"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡗࡋࡇࡉࡔ࡙࡟ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ✴"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ✵"),multi_valued_attributes=None)
	l1111llll1_l1_ = l1lllll1ll1_l1_.find(class_=l1l111_l1_ (u"ࠧ࡭ࡣࡵ࡫ࡪ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠸ࠥࡳࡥࡥ࡫ࡸࡱ࠲ࡨ࡬ࡰࡥ࡮࠱࡬ࡸࡩࡥ࠯࠷ࠤࡸࡳࡡ࡭࡮࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠳ࠩ✶"))
	l1lll1l1_l1_ = l1111llll1_l1_.find_all(l1l111_l1_ (u"ࠨ࡮࡬ࠫ✷"))
	for block in l1lll1l1_l1_:
		title = block.find(class_=l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ✸")).text
		l1ll1ll_l1_ = l111l1_l1_+block.find(l1l111_l1_ (u"ࠪࡥࠬ✹")).get(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ✺"))
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠩ✻")).get(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ✼"))
		l1l1lll1ll_l1_ = block.find(class_=l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ✽")).text
		if kodi_version<19:
			title = title.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭✾"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ✿"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ❀"))
			l1l1lll1ll_l1_ = l1l1lll1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ❁"))
		l1l1lll1ll_l1_ = l1l1lll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ❂"),l1l111_l1_ (u"࠭ࠧ❃")).strip(l1l111_l1_ (u"ࠧࠡࠩ❄"))
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ❅"),l1lllll_l1_+title,l1ll1ll_l1_,522,l11l_l1_,l1l1lll1ll_l1_)
	PAGINATION(l1lllll1ll1_l1_,521)
	return
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭❆"),url,l1l111_l1_ (u"ࠪࠫ❇"),headers,l1l111_l1_ (u"ࠫࠬ❈"),l1l111_l1_ (u"ࠬ࠭❉"),l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ❊"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ❋"),multi_valued_attributes=None)
	l1ll1ll_l1_ = l1lllll1ll1_l1_.find(class_=l1l111_l1_ (u"ࠨࡨ࡯ࡩࡽ࠳ࡶࡪࡦࡨࡳࠬ❌")).find(l1l111_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠩ❍")).get(l1l111_l1_ (u"ࠪࡷࡷࡩࠧ❎"))
	if kodi_version<19: l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ❏"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ❐"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ❑"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ❒"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ❓"),l1l111_l1_ (u"ࠩࠨ࠶࠵࠭❔"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡄࡷ࠽ࠨ❕")+search
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ❖"),url,l1l111_l1_ (u"ࠬ࠭❗"),headers,l1l111_l1_ (u"࠭ࠧ❘"),l1l111_l1_ (u"ࠧࠨ❙"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ❚"))
	html = response.content
	l1lllll1ll1_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ❛"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1ll1_l1_.find_all(class_=l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱ࠱ࡹ࡯ࡴ࡭ࡧࠣࡰࡪ࡬ࡴࠨ❜"))
	for block in l1lll1l1_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ❝"))
		title = title.split(l1l111_l1_ (u"ࠬ࠮ࠧ❞"),1)[0].strip(l1l111_l1_ (u"࠭ࠠࠨ❟"))
		if   l1l111_l1_ (u"ࠧฤ฻่ห้࠭❠") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ❡"),l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡻࡴࡸ࡫࠰ࠩ❢"))
		elif l1l111_l1_ (u"ࠪวูิวึࠩ❣") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭❤"),l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ❥"))
		elif l1l111_l1_ (u"࠭แ๋ัํ์์อสࠨ❦") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ❧"),l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ❨"))
		else: continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❩"),l1lllll_l1_+title,l1ll1ll_l1_,513)
	return
def l1llllll1l1_l1_(url,text):
	global l1l11111_l1_,l1l11lll_l1_
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ❪") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭❫"),l1l111_l1_ (u"ࠬࡿࡥࡢࡴࠪ❬"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ❭")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ❮"),l1l111_l1_ (u"ࠨࡻࡨࡥࡷ࠭❯"),l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ❰")]
	elif l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ❱") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭❲"),l1l111_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭❳"),l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ❴")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ❵"),l1l111_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ❶"),l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ❷")]
	l1l1ll1l_l1_(url,text)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ❸"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ❹"),url,l1l111_l1_ (u"ࠬ࠭❺"),headers,l1l111_l1_ (u"࠭ࠧ❻"),l1l111_l1_ (u"ࠧࠨ❼"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ❽"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡩࡳࡷࡳࠠࡢࡥࡷ࡭ࡴࡴ࠽ࠣ࠱ࠫ࠲࠯ࡅࠩ࠽࠱ࡩࡳࡷࡳ࠾ࠨ❾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸ࡫࡬ࡦࡥࡷࠤࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ❿"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ➀"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ➁"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ➂"))
	url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ➃"),l1l111_l1_ (u"ࠨ࠱ࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠪࠬ➄"))
	return url
def l11l1l11l1_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ➅"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ➆")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠫࡄ࠭➇") in url: url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ➈"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ➉"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ➊"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ➋"),l1l111_l1_ (u"ࠩࠪ➌")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ➍"))
	if type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ➎"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠬࡃࠧ➏") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"࠭࠽ࠨ➐") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ➑")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ➒")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ➓")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭➔")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭➕"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ➖")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ➗"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ➘"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ➙")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ➚"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ➛"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬ➜"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ➝"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧ➞"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ➟")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➠"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ➡"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➢"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ➣")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ➤"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➥"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➦"),l1l111_l1_ (u"ࠨࠩ➧"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠩ࠰࠱ࠬ➨"),l1l111_l1_ (u"ࠪࠫ➩"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠫࡂ࠭➪") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ➫"):
			if l1l111ll_l1_ not in l1l11111_l1_: continue
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1111lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ➬")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➭"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ➮"),l1lllll1_l1_,511)
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➯"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ➰"),l1lllll1_l1_,515,l1l111_l1_ (u"ࠫࠬ➱"),l1l111_l1_ (u"ࠬ࠭➲"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ➳"):
			if l1l111ll_l1_ not in l1l11lll_l1_: continue
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ➴")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ➵")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ➶")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭➷")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ➸")+l1l1ll11_l1_
			if   name==l1l111_l1_ (u"ࠬࡺࡹࡱࡧࠪ➹"): name = l1l111_l1_ (u"࠭วๅ่๋฽ࠬ➺")
			elif name==l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ➻"): name = l1l111_l1_ (u"ࠨษ็฽๊๊ࠧ➼")
			elif name==l1l111_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ➽"): name = l1l111_l1_ (u"ࠪหฺ้๊สࠩ➾")
			elif name==l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ➿"): name = l1l111_l1_ (u"ࠬอไิ่ฬࠫ⟀")
			elif name==l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨ⟁"): name = l1l111_l1_ (u"ࠧศๆ่์ุ๋ࠧ⟂")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⟃"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊࠼ࠣࠫ⟄")+name,l1lllll1_l1_,514,l1l111_l1_ (u"ࠪࠫ⟅"),l1l111_l1_ (u"ࠫࠬ⟆"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"๋ࠬี็ใสฮࠥษฮา๋ࠪ⟇") in option: continue
			if l1l111_l1_ (u"࠭วๅๅ็ࠫ⟈") in option: continue
			if l1l111_l1_ (u"ࠧศๆ็฾ฮ࠭⟉") in option: continue
			option = option.replace(l1l111_l1_ (u"ࠨไสส๊ฯࠠࠨ⟊"),l1l111_l1_ (u"ࠩࠪ⟋"))
			if   name==l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ⟌"): name = l1l111_l1_ (u"ࠫฬ๊ๆ้฻ࠪ⟍")
			elif name==l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⟎"): name = l1l111_l1_ (u"࠭วๅ฻่่ࠬ⟏")
			elif name==l1l111_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ⟐"): name = l1l111_l1_ (u"ࠨษ็่฿ฯࠧ⟑")
			elif name==l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ⟒"): name = l1l111_l1_ (u"ࠪหู้ๆสࠩ⟓")
			elif name==l1l111_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⟔"): name = l1l111_l1_ (u"ࠬอไๆ๊ึ้ࠬ⟕")
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ⟖")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ⟗")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ⟘")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ⟙")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ⟚")+l1l1ll11_l1_
			if name: title = option+l1l111_l1_ (u"ࠫࠥࡀࠧ⟛")+name
			else: title = option
			if type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ⟜"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟝"),l1lllll_l1_+title,url,514,l1l111_l1_ (u"ࠧࠨ⟞"),l1l111_l1_ (u"ࠨࠩ⟟"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⟠") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬ⟡") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11l1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟢"),l1lllll_l1_+title,l1llllll_l1_,511)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟣"),l1lllll_l1_+title,url,515,l1l111_l1_ (u"࠭ࠧ⟤"),l1l111_l1_ (u"ࠧࠨ⟥"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫ⟦"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭⟧"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬ⟨"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭⟩") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧ⟪"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨ⟫"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨ⟬")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪ⟭")
		if l1l111_l1_ (u"ࠩࠨࠫ⟮") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⟯") and value!=l1l111_l1_ (u"ࠫ࠵࠭⟰"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩ⟱")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⟲") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ⟳"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ⟴")+key+l1l111_l1_ (u"ࠩࡀࠫ⟵")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⟶"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭⟷")+key+l1l111_l1_ (u"ࠬࡃࠧ⟸")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ⟹"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ⟺"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫ⟻"),l1l111_l1_ (u"ࠩࡀࠫ⟼"))
	return l1l1l111_l1_
l1l11111_l1_ = []
l1l11lll_l1_ = []
# -*- coding: utf-8 -*-
from IMPORTS import *

script_name = 'FAVOURITES'

def MAIN(mode,favourite):
	if   mode==270: results = MENU(favourite)
	#elif mode==271: results = DELETE_FAVOURITES(favourite)
	else: results = False
	return results

def FAVOURITES_DISPATCHER(context):
	if not context: return
	if '_' in context: favouriteID,context2 = context.split('_',1)
	else: favouriteID,context2 = context,''
	if   context2=='UP1'	: MOVE_FAVOURITES(favouriteID,True,1)
	elif context2=='DOWN1'	: MOVE_FAVOURITES(favouriteID,False,1)
	elif context2=='UP4'	: MOVE_FAVOURITES(favouriteID,True,4)
	elif context2=='DOWN4'	: MOVE_FAVOURITES(favouriteID,False,4)
	elif context2=='ADD1'	: ADD_TO_FAVOURITES(favouriteID)
	elif context2=='REMOVE1': REMOVE_FROM_FAVOURITES(favouriteID)
	elif context2=='DELETELIST': DELETE_FAVOURITES(favouriteID)
	return

def MENU(favouriteID):
	favouritesDICT = GET_ALL_FAVOURITES()
	if favouriteID in list(favouritesDICT.keys()):
		#addMenuItem('folder','مسح هذه القائمة','',271,'','','',favouriteID)
		#addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		try:
			menuLIST = favouritesDICT[favouriteID]
			for type,name,url,mode,image,page,text,context,infodict in menuLIST:
				addMenuItem(type,name,url,mode,image,page,text,context,infodict)
		except:
			favouritesDICT = FIX_AND_GET_FILE_CONTENTS(favouritesfile,False)
			menuLIST = favouritesDICT[favouriteID]
			for type,name,url,mode,image,page,text,context,infodict in menuLIST:
				addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return

def ADD_TO_FAVOURITES(favouriteID):
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	#name = RESTORE_PATH_NAME(name)
	menuItem = (type,name,url,mode,image,page,text,'','')
	favouritesDICT = GET_ALL_FAVOURITES()
	new_dict = {}
	for ID in list(favouritesDICT.keys()):
		if ID!=favouriteID: new_dict[ID] = favouritesDICT[ID]
		else:
			if name and name!='..':
				oldLIST = favouritesDICT[ID]
				if menuItem in oldLIST:
					index = oldLIST.index(menuItem)
					del oldLIST[index]
				newLIST = oldLIST+[menuItem]
				new_dict[ID] = newLIST
			else: new_dict[ID] = favouritesDICT[ID]
	if favouriteID not in list(new_dict.keys()): new_dict[favouriteID] = [menuItem]
	newFILE = str(new_dict)
	if kodi_version>18.99: newFILE = newFILE.encode('utf8')
	open(favouritesfile,'wb').write(newFILE)
	return

def REMOVE_FROM_FAVOURITES(favouriteID):
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	#name = RESTORE_PATH_NAME(name)
	menuItem = (type,name,url,mode,image,page,text,'','')
	favouritesDICT = GET_ALL_FAVOURITES()
	if favouriteID in list(favouritesDICT.keys()) and menuItem in favouritesDICT[favouriteID]:
		favouritesDICT[favouriteID].remove(menuItem)
		if len(favouritesDICT[favouriteID])==0: del favouritesDICT[favouriteID]
		newFILE = str(favouritesDICT)
		if kodi_version>18.99: newFILE = newFILE.encode('utf8')
		open(favouritesfile,'wb').write(newFILE)
	return

def MOVE_FAVOURITES(favouriteID,move_up,repeat):
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	#name = RESTORE_PATH_NAME(name)
	menuItem = (type,name,url,mode,image,page,text,'','')
	favouritesDICT = GET_ALL_FAVOURITES()
	if favouriteID in list(favouritesDICT.keys()):
		oldLIST = favouritesDICT[favouriteID]
		#WRITE_THIS(name+' +++++++++++ '+str(name)+' +++++++++++ '+str('')+' +++++++++++++++ '+str(oldLIST[0]))
		if menuItem not in oldLIST: return
		size = len(oldLIST)
		for i in range(0,repeat):
			old_index = oldLIST.index(menuItem)
			if move_up: new_index = old_index-1
			else: new_index = old_index+1
			if new_index>=size: new_index = new_index-size
			if new_index<0: new_index = new_index+size
			oldLIST.insert(new_index, oldLIST.pop(old_index))
		favouritesDICT[favouriteID] = oldLIST
		newFILE = str(favouritesDICT)
		if kodi_version>18.99: newFILE = newFILE.encode('utf8')
		open(favouritesfile,'wb').write(newFILE)
	return

def DELETE_FAVOURITES(favouriteID):
	yes = DIALOG_YESNO('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+favouriteID+' ؟!')
	if yes!=1: return
	favouritesDICT = GET_ALL_FAVOURITES()
	if favouriteID in list(favouritesDICT.keys()):
		del favouritesDICT[favouriteID]
		newFILE = str(favouritesDICT)
		if kodi_version>18.99: newFILE = newFILE.encode('utf8')
		open(favouritesfile,'wb').write(newFILE)
		DIALOG_OK('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+favouriteID)
	return

def GET_ALL_FAVOURITES(clean=False):
	if os.path.exists(favouritesfile):
		oldFILE = open(favouritesfile,'rb').read()
		if kodi_version>18.99: oldFILE = oldFILE.decode('utf8')
		favouritesDICT = EVAL('dict',oldFILE,favouritesfile)
		if favouritesDICT and clean:
			clean_dict = {}
			for favouriteID in favouritesDICT.keys():
				clean_dict[favouriteID] = []
				for menuItem in favouritesDICT[favouriteID]:
					type,name,url,mode,image,page,text,context,infodict = menuItem
					new_menuItem = type,name,url,mode,image,'',text,context,''
					clean_dict[favouriteID].append(new_menuItem)
			favouritesDICT = clean_dict
	else: favouritesDICT = {}
	return favouritesDICT

def GET_FAVOURITES_CONTEXT_MENU(menuItem,kodipath):
	type,name,url,mode,image,page,text,context,infodict = menuItem
	if not mode: type,mode = 'folder','260'
	contextMenu,favouriteID = [],''
	favouritesDICT = GET_ALL_FAVOURITES(True)
	if 'context=' in addon_path:
		tmp = re.findall('context=(\d+)',addon_path,re.DOTALL)
		if tmp: favouriteID = str(tmp[0])
	if mode=='270':
		favouriteID = context
		if favouriteID in list(favouritesDICT.keys()):
			contextMenu.append(('مسح قائمة مفضلة '+favouriteID,'RunPlugin('+kodipath+'&context='+favouriteID+'_DELETELIST'+')'))
	else:
		if favouriteID in list(favouritesDICT.keys()):
			count = len(favouritesDICT[favouriteID])
			if count>1: contextMenu.append(('تحريك 1 للأعلى','RunPlugin('+kodipath+'&context='+favouriteID+'_UP1)'))
			if count>4: contextMenu.append(('تحريك 4 للأعلى','RunPlugin('+kodipath+'&context='+favouriteID+'_UP4)'))
			if count>1: contextMenu.append(('تحريك 1 للأسفل','RunPlugin('+kodipath+'&context='+favouriteID+'_DOWN1)'))
			if count>4: contextMenu.append(('تحريك 4 للأسفل','RunPlugin('+kodipath+'&context='+favouriteID+'_DOWN4)'))
		for favouriteID in ['1','2','3','4','5']:
			if favouriteID in list(favouritesDICT.keys()) and menuItem in favouritesDICT[favouriteID]:
				contextMenu.append(('مسح من مفضلة '+favouriteID,'RunPlugin('+kodipath+'&context='+favouriteID+'_REMOVE1)'))
			else: contextMenu.append(('إضافة إلى مفضلة '+favouriteID,'RunPlugin('+kodipath+'&context='+favouriteID+'_ADD1)'))
	contextMenuNEW = []
	for i1,i2 in contextMenu:
		i1 = '[COLOR FFFFFF00]'+i1+'[/COLOR]'
		contextMenuNEW.append((i1,i2,))
	return contextMenuNEW

"""
def FIX_OLD_FAVOURITE_ITEMS():
	newDICT = {}
	favouritesDICT = GET_ALL_FAVOURITES()
	for favouriteID in list(favouritesDICT.keys()):
		newDICT[favouriteID] = []
		menuLIST = favouritesDICT[favouriteID]
		for type,name,url,mode,image,page,text,context,infodict in menuLIST:
			#name = RESTORE_PATH_NAME(name)
			menuItem = (type,name,url,mode,image,page,text,'','')
			newDICT[favouriteID].append(menuItem)
	newFILE = str(newDICT)
	if kodi_version>18.99: newFILE = newFILE.encode('utf8')
	open(favouritesfile,'wb').write(newFILE)
	return
"""







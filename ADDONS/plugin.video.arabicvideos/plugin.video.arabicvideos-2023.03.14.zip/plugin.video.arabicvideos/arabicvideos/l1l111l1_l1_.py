# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮࠱ࡹ࡭ࡪࡽ࠭࠲࠱สๅ้อๅ࠮฻ิฬ๏ฯࠧ஘")
#l11lll_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭ࠨங")
#l11lll_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡺ࠶࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪச")
#l11lll_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰ࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶࠧ஛")
script_name = l1l11l_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫஜ")
headers = {l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ஝"):l1l11l_l1_ (u"࠭ࠧஞ")}
menu_name = l1l11l_l1_ (u"ࠧࡠࡍࡏࡅࡤ࠭ட")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==10: results = MENU()
	elif mode==11: results = l111l1_l1_(url)
	elif mode==12: results = PLAY(url)
	elif mode==13: results = l111ll_l1_(url)
	elif mode==14: results = l11l1l1l_l1_()
	elif mode==15: results = l11ll11l_l1_()
	elif mode==16: results = l1l11111_l1_()
	elif mode==19: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஠"),menu_name+l1l11l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ஡"),l1l11l_l1_ (u"ࠪࠫ஢"),19,l1l11l_l1_ (u"ࠫࠬண"),l1l11l_l1_ (u"ࠬ࠭த"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ஥"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ஦"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ஧"),l1l11l_l1_ (u"ࠩࠪந"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪன"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨப")+menu_name+l1l11l_l1_ (u"ࠬศฮาࠢส่ส฼วโษอࠫ஫"),l1l11l_l1_ (u"࠭ࠧ஬"),14)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஭"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬம")+menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠩய"),l1l11l_l1_ (u"ࠪࠫர"),15)
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠫࠬற"),headers,l1l11l_l1_ (u"ࠬ࠭ல"),l1l11l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨள"))
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࡳࡧࡶ࠮ࡵ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ழ"),html,re.DOTALL)
	l1l11ll1_l1_ = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪவ"),l1l11ll1_l1_,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫஶ"))
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪஷ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨஸ")+menu_name+title,l1111l_l1_,11)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪஹ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭஺"),l1l11l_l1_ (u"ࠧࠨ஻"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡴࡡࡷࡤࡤࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ஼"),html,re.DOTALL)
	l1l11lll_l1_ = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ஽"),l1l11lll_l1_,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪா"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨி")+menu_name+title,l1111l_l1_,11)
	return html
def l11ll11l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬீ"),menu_name+l1l11l_l1_ (u"࠭ฬๆ์฼ࠤฬ๊ๅิๆึ่ฬะࠠศๆ฼ีอ๐ษࠨு"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠳࠸࠰็ึุ่๊วห࠯฼ีอ๐ษࠨூ"),11)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௃"),menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬࠣหู้ๆสࠢส่ศิ๊าหࠪ௄"),l1l11l_l1_ (u"ࠪࠫ௅"),16)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫெ"),menu_name+l1l11l_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥอไฤะํีฮࠦ࠱ࠨே"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡨࡻ࠲࠾࠯ๆี็ื้อส࠮ำฺ่ฬ์࠭࠳࠲࠵࠶ࠬை"),11)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ௉"),menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡษ็วำ๐ัสࠢ࠵ࠫொ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡺ࡮࡫ࡷ࠮࠺࠲ุ้๊ำๅษอ࠱ึ๋ึศ่࠰࠶࠵࠸࠳ࠨோ"),11)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪௌ"),menu_name+l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠲࠴்ࠩ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠴࠶࠳๊฻ั๋หࠪ௎"),11)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭௏"),menu_name+l1l11l_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠵࠶ࠬௐ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠷࠸࠯ๆืิ๎ฮ࠭௑"),11)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ௒"),menu_name+l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠸࠱ࠨ௓"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠳࠳࠲ฺ้ื๊สࠩ௔"),11)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ௕"),menu_name+l1l11l_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠴࠳ࠫ௖"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠶࠵࠵ๅึำํอࠬௗ"),11)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௘"),menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠶࠿ࠧ௙"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠱࠺࠱ู่ึ๐ษࠨ௚"),11)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ௛"),menu_name+l1l11l_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠲࠺ࠪ௜"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠴࠼࠴๋ีา์ฬࠫ௝"),11)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ௞"),menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠵࠼࠭௟"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠷࠷࠰็ุี๏ฯࠧ௠"),11)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ௡"),menu_name+l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠱࠷ࠩ௢"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠳࠹࠳๊฻ั๋หࠪ௣"),11)
	return
def l11l1l1l_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ௤"),headers,True,l1l11l_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡍࡃࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ௥"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ௦"),l1l11l_l1_ (u"ࠩࠪ௧"),l1l11l_l1_ (u"ࠪࠫ௨"),html)
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠫ࡭࡫ࡡࡥ࡫ࡱ࡫࠲ࡺ࡯ࡱࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠪ௩"),html,re.DOTALL)
	block = l1ll111_l1_[0]+l1ll111_l1_[1]
	items=re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ௪"),block,re.DOTALL)
	for l1111l_l1_,img,title in items:
		url = l11lll_l1_ + l1111l_l1_
		if l1l11l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭௫") in url: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ௬"),menu_name+title,url,11,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ௭"),menu_name+title,url,12,img)
	return
def l111l1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ௮"),l1l11l_l1_ (u"ࠪࠫ௯"),l1l11l_l1_ (u"࡙ࠫࡏࡔࡍࡇࡖࠫ௰"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ௱"),url,l1l11l_l1_ (u"࠭ࠧ௲"),headers,True,True,l1l11l_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ௳"))
	html = response.content
	#open(l1l11l_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ௴"),l1l11l_l1_ (u"ࠩࡺࠫ௵")).write(str(html))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼࠬ࠳࠰࠿ࠪࡴ࡬࡫࡭ࡺ࡟ࡤࡱࡱࡸࡪࡴࡴࠨ௶"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	l1111ll1_l1_ = False
	#items = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࡟࠺࠸࡝࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ௷"),block,re.DOTALL)
	items = re.findall(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ௸"),block,re.DOTALL)
	l1l1l11_l1_,l1l1111l_l1_ = [],[]
	for l1111l_l1_,img,title in items:
		if title==l1l11l_l1_ (u"࠭ࠧ௹"): title = l1111l_l1_.split(l1l11l_l1_ (u"ࠧ࠰ࠩ௺"))[-1].replace(l1l11l_l1_ (u"ࠨ࠯ࠪ௻"),l1l11l_l1_ (u"ࠩࠣࠫ௼"))
		l1l11l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬࡡࡪࠫࠪࠩ௽"),title,re.DOTALL)
		if l1l11l1l_l1_: l1l11l1l_l1_ = int(l1l11l1l_l1_[0])
		else: l1l11l1l_l1_ = 0
		l1l1111l_l1_.append([img,l1111l_l1_,title,l1l11l1l_l1_])
	l1l1111l_l1_ = sorted(l1l1111l_l1_, reverse=True, key=lambda key: key[3])
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ௾"),l1l11l_l1_ (u"ࠬ࠭௿"),l1l11l_l1_ (u"࠭࠲࠳࠴ࠪఀ"),url)
	for img,l1111l_l1_,title,l1l11l1l_l1_ in l1l1111l_l1_:
		l1111l_l1_ = l11lll_l1_ + l1111l_l1_
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨఁ"),l1l11l_l1_ (u"ࠨࠩం"),url,title)
		title = title.replace(l1l11l_l1_ (u"ุ่ࠩฬํฯส่ࠢืู้ไࠨః"),l1l11l_l1_ (u"ุ้๊ࠪำๅࠩఄ"))
		title = title.replace(l1l11l_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅิๆึ่ࠬఅ"),l1l11l_l1_ (u"ࠬอไๆี็ื้࠭ఆ"))
		title = title.replace(l1l11l_l1_ (u"࠭ๅีษ๊ำฮࠦแ๋ๆ่ࠫఇ"),l1l11l_l1_ (u"ࠧโ์็้ࠬఈ"))
		title = title.replace(l1l11l_l1_ (u"ࠨ็ืห์ีษࠡษ็ๅ๏๊ๅࠨఉ"),l1l11l_l1_ (u"ࠩส่ๆ๐ไๆࠩఊ"))
		title = title.replace(l1l11l_l1_ (u"้ࠪออิาหࠣ็ํอไ๋ฬํࠫఋ"),l1l11l_l1_ (u"ࠫࠬఌ"))
		title = title.replace(l1l11l_l1_ (u"ࠬ฿วๅ์ฬࠤ฾๊้ࠡษ็฽ึฮࠧ఍"),l1l11l_l1_ (u"࠭ࠧఎ"))
		title = title.replace(l1l11l_l1_ (u"ࠧๆึส๋ิฯࠠๆสสุึฯࠧఏ"),l1l11l_l1_ (u"ࠨࠩఐ"))
		title = title.replace(l1l11l_l1_ (u"ࠩส์๋ࠦไศ์้ࠫ఑"),l1l11l_l1_ (u"ࠪࠫఒ"))
		title = title.replace(l1l11l_l1_ (u"ࠫฬ๎ๆๅษํ๊ࠬఓ"),l1l11l_l1_ (u"ࠬ࠭ఔ"))
		title = title.replace(l1l11l_l1_ (u"࠭ศอ๊าอࠥ฿วๅ์ฬࠫక"),l1l11l_l1_ (u"ࠧࠨఖ"))
		title = title.replace(l1l11l_l1_ (u"ࠨฮ๋ำฮูࠦศๆํอࠬగ"),l1l11l_l1_ (u"ࠩࠪఘ"))
		title = title.replace(l1l11l_l1_ (u"ࠪฬิ๎ๆࠡฬะ้๏๊ࠧఙ"),l1l11l_l1_ (u"ࠫࠬచ"))
		title = title.replace(l1l11l_l1_ (u"ࠬ฿ไ๊ࠢส่฾ืศࠨఛ"),l1l11l_l1_ (u"࠭ࠧజ"))
		title = title.replace(l1l11l_l1_ (u"ࠧๆสสุึฯࠧఝ"),l1l11l_l1_ (u"ࠨࠩఞ"))
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫట")).replace(l1l11l_l1_ (u"ࠪࠤࠥ࠭ఠ"),l1l11l_l1_ (u"ࠫࠥ࠭డ")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨఢ"),l1l11l_l1_ (u"࠭ࠠࠨణ"))
		title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭త")+title
		title2 = title
		if l1l11l_l1_ (u"ࠨ࠱ࡴ࠳ࠬథ") in url and (l1l11l_l1_ (u"ࠩส่า๊โสࠩద") in title or l1l11l_l1_ (u"ࠪห้ำไใ้ࠪధ") in title):
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧన"),title,re.DOTALL)
			if l1ll1ll_l1_: title2 = l1ll1ll_l1_[0]
			#if l1l11l_l1_ (u"๋ࠬำๅี็ࠫ఩") not in title2: title2 = l1l11l_l1_ (u"࠭ๅิๆึ่ࠥ࠭ప")+title2
		if title2 not in l1l1l11_l1_:
			l1l1l11_l1_.append(title2)
			#xbmc.log(title2, level=xbmc.LOGNOTICE)
			if l1l11l_l1_ (u"ࠧ࠰ࡳ࠲ࠫఫ") in url and (l1l11l_l1_ (u"ࠨษ็ั้่ษࠨబ") in title or l1l11l_l1_ (u"ࠩส่า๊โ่ࠩభ") in title):
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪమ"),menu_name+title2,l1111l_l1_,13,img)
				l1111ll1_l1_ = True
			elif l1l11l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫయ") in l1111l_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬర"),menu_name+title,l1111l_l1_,11,img)
				l1111ll1_l1_ = True
			else:
				#if l1l11l_l1_ (u"࠭ๅิๆึ่ࠬఱ") not in title and l1l11l_l1_ (u"ࠧศๆะ่็ฯࠧల") in title: title = l1l11l_l1_ (u"ࠨ็ึุ่๊ࠠࠨళ")+title
				addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨఴ"),menu_name+title,l1111l_l1_,12,img)
				l1111ll1_l1_ = True
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫవ"),l1l11l_l1_ (u"ࠫࠬశ"),l1l11l_l1_ (u"ࠬ࠹࠳࠴ࠩష"),url)
	if l1111ll1_l1_:
		items = re.findall(l1l11l_l1_ (u"࠭ࡴࡴࡥࡢ࠷ࡩࡥࡢࡶࡶࡷࡳࡳࠦࡲࡦࡦ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫస"),block,re.DOTALL)
		for l1111l_l1_,page in items:
			url = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧహ"),menu_name+page,url,11)
	return
def l111ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠨࠩ఺"),headers,True,l1l11l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ఻"))
	l1l11l11_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡸ࡫ࡲࡪࡧࡶ࠲࠯ࡅ఼ࠩࠣࠩ"),html,re.DOTALL)
	url2 = l11lll_l1_+l1l11l11_l1_[0]
	results = l111l1_l1_(url2)
	return
l1l11l_l1_ (u"ࠦࠧࠨࠊࡥࡧࡩࠤࡊࡖࡉࡔࡑࡇࡉࡘࡥࡏࡍࡆࠫࡹࡷࡲࠩ࠻ࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࡚ࡲࡶࡧ࠯ࠫࡆࡒࡁࡓࡃࡅ࠱ࡊࡖࡉࡔࡑࡇࡉࡘࡥࡏࡍࡆ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡤࡤࡲࡳ࡫ࡲ࠮ࡴ࡬࡫࡭ࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵ࡬ࡧ࠲ࡩࡨࡢࡰࡱࡩࡱ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡵࡳ࡮࠯ࠫࡸࡺࡥࡱࠢ࠵ࠫ࠮ࠐࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡷࡹ࡫ࡰࠡ࠵ࠪ࠭ࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡴࡱࡵࡸࡪࡪࠨࡪࡶࡨࡱࡸ࠲ࠠࡳࡧࡹࡩࡷࡹࡥ࠾ࡖࡵࡹࡪ࠲ࠠ࡬ࡧࡼࡁࡱࡧ࡭ࡣࡦࡤࠤࡰ࡫ࡹ࠻ࠢ࡮ࡩࡾࡡ࠱࡞ࠫࠍࠍࠨࡴࡡ࡮ࡧࠣࡁࠥࡾࡢ࡮ࡥ࠱࡫ࡪࡺࡉ࡯ࡨࡲࡐࡦࡨࡥ࡭ࠪࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ࠮ࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡹࡷࡲࠬࠨࡵࡷࡩࡵࠦ࠴ࠨࠫࠍࠍࡦࡲ࡬ࡕ࡫ࡷࡰࡪࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡦࡰࡴࠣ࡭ࡲ࡭ࠬ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤࡳࡵࡴࠡ࡫ࡱࠤࡦࡲ࡬ࡕ࡫ࡷࡰࡪࡹ࠺ࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅิๆึ่ࠥ࠭ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠸ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠊࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡷࡵࡰ࠱࠭ࡳࡵࡧࡳࠤ࠺࠭ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧఽ")
def PLAY(url):
	l1ll1lll_l1_ = []
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠬ࠭ా"),headers,True,l1l11l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨి"))
	# l11l11l1_l1_ l111llll_l1_ server
	# https://l1l1l111_l1_.l11l1111_l1_.com/l111ll1l_l1_-_حلقة_1111lll_l1_حكايتي_11ll1l1_l1_رمضان_11lll1l_l1_
	# https://l1l111ll_l1_.l11l1111_l1_.com/numeric/110272.l11lllll_l1_/l11lll11_l1_.l11l11l1_l1_
	url2 = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡶࡴ࠲࡯ࡦࡳࡣࡰࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫీ"),html,re.DOTALL)
	if url2:
		url2 = url2[0]
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡠࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠤࠨు"),url2,re.DOTALL)
		if l1ll1111_l1_:
			first = l1ll1111_l1_[0][0]
			second,l111l1l1_l1_ = l1ll1111_l1_[0][1].rsplit(l1l11l_l1_ (u"ࠩ࠲ࠫూ"),1)
			url3 = second+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫృ")
			l1ll1lll_l1_.append(url3)
			l11ll111_l1_ = first+l111l1l1_l1_
		else:
			l1lll111_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠫࠬౄ"),headers,False,l1l11l_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ౅"))
			url2 = re.findall(l1l11l_l1_ (u"࠭ࠢࡴࡴࡦࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧె"),l1lll111_l1_,re.DOTALL)
			if url2:
				url2 = url2[0]+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࡠࡡࡰ࠷ࡺ࠾ࠧే")
				l1ll1lll_l1_.append(url2)
	# l1111l1l_l1_ server - l11ll1ll_l1_ - https://l1l1l111_l1_.l11l1111_l1_.com/l111lll1_l1_-_الذئب_حلقة_111ll11_l1_
	# l1111l1l_l1_ server - l111l111_l1_ - https://l1l1l111_l1_.l11l1111_l1_.com/l11llll1_l1_-_111l1ll_l1_فيلم_اكشن_11l1ll1_l1_
	# l1111l1l_l1_ server - l11l1l11_l1_ - https://l1l1l111_l1_.l11l1111_l1_.com/l11l11ll_l1_-_لحلقة_11l1lll_l1_السجين_مترجمة_11l111l_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡃࡱࡻࠬ࠳࠰࠿ࠪ࠾ࡶࡸࡾࡲࡥ࠿ࠩై"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		url2 = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ౉"),block,re.DOTALL)
		if url2:
			url2 = url2[0]+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫొ")
			l1ll1lll_l1_.append(url2)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪో"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫౌ"),url)
	return
def l1l11111_l1_():
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"్࠭ࠧ"),headers,True,l1l11l_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡓࡃࡐࡅࡉࡇࡎ࠮࠳ࡶࡸࠬ౎"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࡥࡳࡦࡥࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡲࡥࡧࡶࡢࡧࡴࡴࡴࡦࡰࡷࠦࠬ౏"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ౐"),block,re.DOTALL)
	year = re.findall(l1l11l_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠵ࠧ౑"),str(items),re.DOTALL)
	year = year[0]
	for l1111l_l1_,title in items:
		url = l11lll_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭౒"))+l1l11l_l1_ (u"ࠬࠦࠧ౓")+year
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౔"),menu_name+title,url,11)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠧࠨౕ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠨౖࠩ"): return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠩࠣࠫ౗"),l1l11l_l1_ (u"ࠪࠩ࠷࠶ࠧౘ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠦ࠴ࡷ࠯ࠣౙ") + l1l1ll_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ౚ"),l1l11l_l1_ (u"࠭ࠧ౛"),l1l11l_l1_ (u"ࠧ࠴࠵࠶ࠫ౜"),url)
	results = l111l1_l1_(url)
	return
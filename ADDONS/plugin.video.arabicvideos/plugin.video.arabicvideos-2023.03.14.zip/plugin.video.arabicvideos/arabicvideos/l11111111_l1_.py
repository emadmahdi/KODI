# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩᛖ")
menu_name = l1l11l_l1_ (u"ࠩࡢࡇࡒࡔ࡟ࠨᛗ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠪๆฬฬๅห์ࠪᛘ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l1lll11_l1_(url)
	elif mode==302: results = l111l1_l1_(url)
	elif mode==303: results = l111l1lll_l1_(url)
	elif mode==304: results = l111ll_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᛙ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᛚ"),l1l11l_l1_ (u"࠭ࠧᛛ"),309,l1l11l_l1_ (u"ࠧࠨᛜ"),l1l11l_l1_ (u"ࠨࠩᛝ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᛞ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᛟ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᛠ"),l1l11l_l1_ (u"ࠬ࠭ᛡ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᛢ"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨᛣ"),l1l11l_l1_ (u"ࠨࠩᛤ"),l1l11l_l1_ (u"ࠩࠪᛥ"),l1l11l_l1_ (u"ࠪࠫᛦ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᛧ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡵ࡭ࡀࠫ࠲࠯ࡅࠩ࠽ࡵࡳࡥࡳࡄࠧᛨ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᛩ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩᛪ"))
		if title==l1l11l_l1_ (u"ࠨำฺ่ฬ์ࠧ᛫"): l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴ืๅืษ้࠳ࠬ᛬")
		if not any(value in title for value in l1llll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᛭"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᛮ")+menu_name+title,l1111l_l1_,301)
	l1l1lll11_l1_(l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᛯ"))
	return html
def l1l1lll11_l1_(url):
	seq = 0
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᛰ"),url,l1l11l_l1_ (u"ࠧࠨᛱ"),l1l11l_l1_ (u"ࠨࠩᛲ"),l1l11l_l1_ (u"ࠩࠪᛳ"),l1l11l_l1_ (u"ࠪࠫᛴ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᛵ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠭ࡃࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠪࠩᛶ"),html,re.DOTALL)
	if l1ll111_l1_:
		for block in l1ll111_l1_:
			seq += 1
			items = re.findall(l1l11l_l1_ (u"࠭࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᛷ"),block,re.DOTALL)
			for title,test,l1111l_l1_ in items:
				title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩᛸ"))
				if title==l1l11l_l1_ (u"ࠨࠩ᛹"): title = l1l11l_l1_ (u"ࠩห์ํ๎่้ࠩ᛺")
				if l1l11l_l1_ (u"ࠪࡩࡲࡄ࠼ࡢࠩ᛻") not in test:
					if block.count(l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ᛼"))>0:
						l1llllll11_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᛽"),block,re.DOTALL)
						for l1111l_l1_ in l1llllll11_l1_:
							title = l1111l_l1_.split(l1l11l_l1_ (u"࠭࠯ࠨ᛾"))[-2]
							addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᛿"),menu_name+title,l1111l_l1_,301)
						continue
					else: l1111l_l1_ = url+l1l11l_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࠬᜀ")+str(seq)
				#l11llll1l_l1_ = [l1l11l_l1_ (u"่ࠩืู้ไศฬࠣࠫᜁ"),l1l11l_l1_ (u"ࠪหๆ๊วๆࠢࠪᜂ"),l1l11l_l1_ (u"ࠫอืวๆฮࠪᜃ"),l1l11l_l1_ (u"ࠬ฿ัุ้ࠪᜄ"),l1l11l_l1_ (u"࠭ใๅ์หหฯ࠭ᜅ"),l1l11l_l1_ (u"ࠧศ฼ส๊๎࠭ᜆ")]
				#if any(value in title for value in l11llll1l_l1_):
				if not any(value in title for value in l1llll1_l1_):
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜇ"),menu_name+title,l1111l_l1_,302)
	else: l111l1_l1_(url,html)
	return
def l111l1_l1_(url,html=l1l11l_l1_ (u"ࠩࠪᜈ")):
	if html==l1l11l_l1_ (u"ࠪࠫᜉ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᜊ"),url,l1l11l_l1_ (u"ࠬ࠭ᜋ"),l1l11l_l1_ (u"࠭ࠧᜌ"),l1l11l_l1_ (u"ࠧࠨᜍ"),l1l11l_l1_ (u"ࠨࠩᜎ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᜏ"))
		html = response.content
	if l1l11l_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᜐ") in url:
		url,seq = url.split(l1l11l_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨᜑ"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠭ࡃࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠪࠩᜒ"),html,re.DOTALL)
		block = l1ll111_l1_[int(seq)-1]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡱࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡰࡦࡼࡂࠬᜓ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡣ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ᜔ࠫࠥࠫ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for l1111l_l1_,data,img in items:
		title = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠳࠰࠿࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࡪࡳ࠾ࠨ᜕"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ᜖"),l1l11l_l1_ (u"ࠪࠫ᜗")).strip(l1l11l_l1_ (u"ࠫࠥ࠭᜘"))
		if not title or title==l1l11l_l1_ (u"ࠬ࠭᜙"):
			title = re.findall(l1l11l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠧࡄ࠮ࠫࡁ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᜚"),data,re.DOTALL)
			if title: title = title[0].replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ᜛"),l1l11l_l1_ (u"ࠨࠩ᜜")).strip(l1l11l_l1_ (u"ࠩࠣࠫ᜝"))
			if not title or title==l1l11l_l1_ (u"ࠪࠫ᜞"):
				title = re.findall(l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᜟ"),data,re.DOTALL)
				title = title[0].replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨᜠ"),l1l11l_l1_ (u"࠭ࠧᜡ")).strip(l1l11l_l1_ (u"ࠧࠡࠩᜢ"))
		title = unescapeHTML(title)
		#if title==l1l11l_l1_ (u"ࠨࠩᜣ"): continue
		if title not in l1l1l11_l1_:
			l1l1l11_l1_.append(title)
			l1l11lll_l1_ = l1111l_l1_+data+img
			if l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫᜤ") in l1l11lll_l1_ or l1l11l_l1_ (u"ุ้๊ࠪำๅࠩᜥ") in l1l11lll_l1_ or l1l11l_l1_ (u"ࠫࠧ࡫ࡰࡪࡵࡲࡨࡪࠨࠧᜦ") in l1l11lll_l1_:
				if l1l11l_l1_ (u"ࠬฮัศ็ฯࠫᜧ") in data: title = l1l11l_l1_ (u"࠭ศา่ส้ัࠦࠧᜨ")+title
				elif l1l11l_l1_ (u"ࠧๆี็ื้࠭ᜩ") in data or l1l11l_l1_ (u"ࠨ็๋ื๊࠭ᜪ") in data: title = l1l11l_l1_ (u"่ࠩืู้ไࠡࠩᜫ")+title
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᜬ"),menu_name+title,l1111l_l1_,303,img)
			else: addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᜭ"),menu_name+title,l1111l_l1_,305,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᜮ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᜯ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜰ"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧᜱ")+title,l1111l_l1_,302)
	return
def l111l1lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᜲ"),url,l1l11l_l1_ (u"ࠪࠫᜳ"),l1l11l_l1_ (u"᜴ࠫࠬ"),l1l11l_l1_ (u"ࠬ࠭᜵"),l1l11l_l1_ (u"࠭ࠧ᜶"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡕࡈࡅࡘࡕࡎࡔ࠯࠴ࡷࡹ࠭᜷"))
	html = response.content
	name = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾ࠨ᜸"),html,re.DOTALL)
	name = name[0].replace(l1l11l_l1_ (u"ࠩࡿࠤุ๐ๅศ้ࠢหํ࠭᜹"),l1l11l_l1_ (u"ࠪࠫ᜺")).replace(l1l11l_l1_ (u"ࠫࡈ࡯࡭ࡢࠢࡑࡳࡼ࠭᜻"),l1l11l_l1_ (u"ࠬ࠭᜼")).strip(l1l11l_l1_ (u"࠭ࠠࠨ᜽")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ᜾"),l1l11l_l1_ (u"ࠨࠢࠪ᜿"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠭ᝀ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᝁ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#title = name+l1l11l_l1_ (u"ࠫࠥ࠭ᝂ")+title.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨᝃ"),l1l11l_l1_ (u"࠭ࠧᝄ")).strip(l1l11l_l1_ (u"ࠧࠡࠩᝅ"))
			title = title.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫᝆ"),l1l11l_l1_ (u"ࠩࠪᝇ")).strip(l1l11l_l1_ (u"ࠪࠤࠬᝈ"))
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᝉ"),menu_name+title,l1111l_l1_,304)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᝊ"),url,l1l11l_l1_ (u"࠭ࠧᝋ"),l1l11l_l1_ (u"ࠧࠨᝌ"),l1l11l_l1_ (u"ࠨࠩᝍ"),l1l11l_l1_ (u"ࠩࠪᝎ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᝏ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡪࡥࡵࡣ࡬ࡰࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡸࡥ࡭ࡣࡷࡩࡩࠨࠧᝐ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᝑ"),block,re.DOTALL)
	for l1111l_l1_,img,title in items:
		title = title.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩᝒ"),l1l11l_l1_ (u"ࠧࠨᝓ")).strip(l1l11l_l1_ (u"ࠨࠢࠪ᝔"))
		addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᝕"),menu_name+title,l1111l_l1_,305,img)
	return
def PLAY(url):
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡭࡯࡮ࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡣࡰࡱ࡮࡭ࡪࡹࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡯࡬࡫ࡨࡷ࠳࡭ࡥࡵࡡࡧ࡭ࡨࡺࠨࠪࠌࠌࡔࡍࡖࡓࡆࡕࡖࡍࡉࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡔࡍࡖࡓࡆࡕࡖࡍࡉ࠭࡝ࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡩࡴࡨࡪࠥࡃࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ࠮ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣ࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯ࡠ࠶࡝ࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࠼ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠮ࠪࡇࡴࡵ࡫ࡪࡧࠪ࠾ࠬࡖࡈࡑࡕࡈࡗࡘࡏࡄ࠾ࠩ࠮ࡔࡍࡖࡓࡆࡕࡖࡍࡉࢃࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡼࡥࡳ࡫ࡩࡽࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ࠭ࠏࠏࡶࡦࡴ࡬ࡪࡾࡥࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࠧࡦࡪ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡤࡨࠧࠦࡴࡢࡴࡪࡩࡹࡃࠢࡠࡤ࡯ࡥࡳࡱࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡣࡧࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠣࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡦࡪ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧࠪࠌࠌࠧࡦࡪ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡧࡺ࡮ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡧ࡭ࡸࡶ࡬ࡢࡻ࠽ࠤࡳࡵ࡮ࡦ࠽ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡻ࡫ࡲࡪࡨࡼࡣ࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶ࡠ࠶࡝ࠬࠩ࠲ࠫࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡦ࠳ࡩࡩ࡮ࡣࡹ࡭ࡩࡹ࠮࡭࡫ࡹࡩ࠴࠭ࡽࠋࠋࠥࠦࠧ᝖")
	url2 = url+l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪ࡬ࡲ࡬࠵ࠧ᝗")
	#server = SERVER(url2,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ᝘"))
	#headers2 = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᝙"):None,l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ᝚"):server}
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ᝛"),url2,l1l11l_l1_ (u"ࠩࠪ᝜"),l1l11l_l1_ (u"ࠪࠫ᝝"),l1l11l_l1_ (u"ࠫࠬ᝞"),l1l11l_l1_ (u"ࠬ࠭᝟"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠻ࡴࡩࠩᝠ"))
	l1lll111_l1_ = response.content
	#url2 = l1llllllll_l1_(url2,l1l11l_l1_ (u"ࠧ࡭ࡱࡺࡩࡷ࠭ᝡ"))
	#l1lll111_l1_ = l1llllll1l_l1_(l111l11l_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᝢ"),url2,l1l11l_l1_ (u"ࠩࠪᝣ"),l1l11l_l1_ (u"ࠪࠫᝤ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧᝥ"))
	#if l1lll111_l1_ and kodi_version>18.99: l1lll111_l1_ = l1lll111_l1_.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᝦ"))
	l1ll1lll_l1_ = []
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᝧ"),l1lll111_l1_,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᝨ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫᝩ"),l1l11l_l1_ (u"ࠩࠪᝪ")).strip(l1l11l_l1_ (u"ࠪࠤࠬᝫ"))
			l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬᝬ"),title,re.DOTALL)
			if l1l1l1l1_l1_:
				l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ᝭")+l1l1l1l1_l1_[0]
				#title = l1l11l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧᝮ")
				title = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬᝯ"))
			else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࠩᝰ")
			l11l111l1_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᝱")+title+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᝲ")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l11l111l1_l1_)
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡽࡡࡵࡥ࡫ࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᝳ"),l1lll111_l1_,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		# l1l11ll1l_l1_ l1l1ll11l_l1_ l1ll1111_l1_
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠯࠰࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ᝴"),block,re.DOTALL)
		for l1111l_l1_ in l1ll1111_l1_:
			l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ᝵")+l1111l_l1_
			title = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ᝶"))
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ᝷")+title+l1l11l_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ᝸")
			l1ll1lll_l1_.append(l1111l_l1_)
		# l1lllllll1_l1_ l1l1ll11l_l1_ l1ll1111_l1_
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡥ࡯ࡧࡸ࡝ࠪࡾࡹࡷࡲ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ᝹"),l1lll111_l1_,re.DOTALL)
		if l1ll1111_l1_:
			items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡲࡩ࡫ࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭᝺"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ᝻"),l1l11l_l1_ (u"࠭ࠧ᝼")).strip(l1l11l_l1_ (u"ࠧࠡࠩ᝽"))
				title = title.replace(l1l11l_l1_ (u"ࠨࡅ࡬ࡱࡦࠦࡎࡰࡹࠪ᝾"),l1l11l_l1_ (u"ࠩࡆ࡭ࡲࡧࡎࡰࡹࠪ᝿"))
				l1111l_l1_ = l1ll1111_l1_[0]+l1l11l_l1_ (u"ࠪࡃࡦࡩࡴࡪࡱࡱࡁࡸࡽࡩࡵࡥ࡫ࠪ࡮ࡴࡤࡦࡺࡀࠫក")+index+l1l11l_l1_ (u"ࠫࠫ࡯ࡤ࠾ࠩខ")+id+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭គ")+title+l1l11l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧឃ")
				l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬង"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧច"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠩࠪឆ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠪࠫជ"): return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭ឈ"),l1l11l_l1_ (u"ࠬ࠱ࠧញ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"࠭࠯ࡀࡵࡀࠫដ")+search
	l111l1_l1_(url)
	return
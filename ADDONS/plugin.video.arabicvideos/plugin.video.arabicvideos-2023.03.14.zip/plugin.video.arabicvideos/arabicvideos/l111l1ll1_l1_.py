# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨᐘ")
menu_name = l1l11l_l1_ (u"ࠧࡠࡃࡅࡈࡤ࠭ᐙ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨษ็ีห๐ำ๋หࠪᐚ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l111l1_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l111ll_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᐛ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᐜ"),l1l11l_l1_ (u"ࠫࠬᐝ"),l1l11l_l1_ (u"ࠬ࠭ᐞ"),l1l11l_l1_ (u"࠭ࠧᐟ"),l1l11l_l1_ (u"ࠧࠨᐠ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᐡ"))
	html = response.content
	l111llll1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭ᐢ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐣ"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᐤ"),l1l11l_l1_ (u"ࠬ࠭ᐥ"),559,l1l11l_l1_ (u"࠭ࠧᐦ"),l1l11l_l1_ (u"ࠧࠨᐧ"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᐨ"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᐩ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᐪ"),l1l11l_l1_ (u"ࠫࠬᐫ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐬ"),menu_name+l1l11l_l1_ (u"࠭วฯฬิ๊ฬࠦไไࠩᐭ"),l111llll1_l1_,551,l1l11l_l1_ (u"ࠧࠨᐮ"),l1l11l_l1_ (u"ࠨࠩᐯ"),l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᐰ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᐱ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᐲ"),block,re.DOTALL)
	for l11l1ll11_l1_,title in items:
		l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࡄ࡯ࡴࡦ࡯ࡀࠫᐳ")+l11l1ll11_l1_+l1l11l_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧᐴ")
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐵ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᐶ")+menu_name+title,l1111l_l1_,551)
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᐷ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᐸ"),l1l11l_l1_ (u"ࠫࠬᐹ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨ࡮ࡢࡸ࠰ࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡺࡃ࠭ᐺ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᐻ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠧࠤࠩᐼ"): continue
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ࠨ็ึุ่๊ࠠࠨᐽ") in title: continue
		if l1l11l_l1_ (u"ࠩฦัิัࠧᐾ") in title: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐿ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᑀ")+menu_name+title,l1111l_l1_,551)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᑁ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑂ"),l1l11l_l1_ (u"ࠧࠨᑃ"),9999)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠨࠥࠪᑄ"): continue
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"่ࠩืู้ไࠡࠩᑅ") in title: continue
		if l1l11l_l1_ (u"ࠪวาีหࠨᑆ") not in title: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᑇ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᑈ")+menu_name+title,l1111l_l1_,551)
	return
def l111l1_l1_(url,l11l1ll11_l1_=l1l11l_l1_ (u"࠭ࠧᑉ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᑊ"),l1l11l_l1_ (u"ࠨࠩᑋ"),url)
	items = []
	# l111l1l11_l1_ l111l1l1l_l1_
	if l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩᑌ") in url or l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫᑍ") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᑎ"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᑏ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫᑐ"),url2,data2,headers2,l1l11l_l1_ (u"ࠧࠨᑑ"),l1l11l_l1_ (u"ࠨࠩᑒ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᑓ"))
		html = response.content
		l1ll111_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᑔ"),url,l1l11l_l1_ (u"ࠫࠬᑕ"),l1l11l_l1_ (u"ࠬ࠭ᑖ"),l1l11l_l1_ (u"࠭ࠧᑗ"),l1l11l_l1_ (u"ࠧࠨᑘ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧᑙ"))
		html = response.content
		# l11l1ll11_l1_ items
		if l11l1ll11_l1_==l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᑚ"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪᑛ"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᑜ"),block,re.DOTALL)
			#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ᑝ"),l1l11l_l1_ (u"࠭ࠧᑞ"),l1l11l_l1_ (u"ࠧࠨᑟ"))
		# l111ll11l_l1_ l1l11l11_l1_
		elif l1l11l_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠨᑠ") in html:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᑡ"),html,re.DOTALL)
		else:
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨᑢ"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	if not items:
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡳࡷ࡯ࡧࡪࡰࡤࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᑣ"),block,re.DOTALL)
		if not items: items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᑤ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"࠭ๅีษ๊ำฮ࠭ᑥ"),l1l11l_l1_ (u"ࠧโ์็้ࠬᑦ"),l1l11l_l1_ (u"ࠨษ฽๊๏ฯࠧᑧ"),l1l11l_l1_ (u"ࠩๆ่๏ฮࠧᑨ"),l1l11l_l1_ (u"ࠪห฾๊ว็ࠩᑩ"),l1l11l_l1_ (u"ࠫ์ีวโࠩᑪ"),l1l11l_l1_ (u"๋ࠬศศำสอࠬᑫ"),l1l11l_l1_ (u"ู࠭าุࠪᑬ"),l1l11l_l1_ (u"ࠧๆ้ิะฬ์ࠧᑭ"),l1l11l_l1_ (u"ࠨษ็ฬํ๋ࠧᑮ")]
	for l1111l_l1_,title,img in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠩ࠲ࠫᑯ"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᑰ"),title,re.DOTALL)
		if l1l11l_l1_ (u"ุ๊ࠫวิๆࠪᑱ") not in url and any(value in title for value in l111l11ll_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᑲ"),menu_name+title,l1111l_l1_,552,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"࠭วๅฯ็ๆฮ࠭ᑳ") in title:
			title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᑴ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᑵ"),menu_name+title,l1111l_l1_,553,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫᑶ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᑷ"),menu_name+title,l1111l_l1_,551,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᑸ"),menu_name+title,l1111l_l1_,553,img)
	if l11l1ll11_l1_==l1l11l_l1_ (u"ࠬ࠭ᑹ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࠪᑺ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᑻ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1111l_l1_==l1l11l_l1_ (u"ࠣࠤᑼ"): continue
				#title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"ࠩࠪᑽ"): addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᑾ"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪᑿ")+title,l1111l_l1_,551)
	if l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬᒀ") in url or l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧᒁ") in url:
		if l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧᒂ") in url:
			url = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨᒃ"),l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪᒄ"))+l1l11l_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁ࠷࠶ࠧᒅ")
		elif l1l11l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᒆ") in url:
			url,offset = url.split(l1l11l_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧᒇ"))
			offset = int(offset)+20
			url = url+l1l11l_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨᒈ")+str(offset)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᒉ"),menu_name+l1l11l_l1_ (u"ࠨ้้ห่ࠦวๅ็ี๎ิ࠭ᒊ"),url,551)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᒋ"),url,l1l11l_l1_ (u"ࠪࠫᒌ"),l1l11l_l1_ (u"ࠫࠬᒍ"),l1l11l_l1_ (u"ࠬ࠭ᒎ"),l1l11l_l1_ (u"࠭ࠧᒏ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᒐ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡪࡩࡹ࡙ࡥࡢࡵࡲࡲࡸࡈࡹࡔࡧࡵ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩᒑ"),html,re.DOTALL)
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡰ࡮ࡹࡴ࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ᒒ"),html,re.DOTALL)
	# l111lll1l_l1_
	if l111l11l1_l1_ and l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᒓ") not in url:
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᒔ"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒕ"),menu_name+title,l1111l_l1_,553,img)
	# l1l11l1_l1_
	elif l1ll1lll1_l1_:
		img = re.findall(l1l11l_l1_ (u"࠭ࠢࡪ࡯ࡤ࡫ࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᒖ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᒗ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#title = title.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫᒘ"),l1l11l_l1_ (u"ࠩࠪᒙ")).strip(l1l11l_l1_ (u"ࠪࠤࠬᒚ"))
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᒛ"),menu_name+title,l1111l_l1_,552,img)
	return
def PLAY(url):
	url2 = url.replace(l1l11l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧᒜ"),l1l11l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥ࡭ࡰࡸ࡬ࡩࡸ࠵ࠧᒝ"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫᒞ"),l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫᒟ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᒠ"),url2,l1l11l_l1_ (u"ࠪࠫᒡ"),l1l11l_l1_ (u"ࠫࠬᒢ"),l1l11l_l1_ (u"ࠬ࠭ᒣ"),l1l11l_l1_ (u"࠭ࠧᒤ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᒥ"))
	html = response.content
	l111llll1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᒦ"))
	l1ll1lll_l1_ = []
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᒧ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1lll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᒨ"),html,re.DOTALL)
		l1lll11l_l1_ = l1lll11l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠦ࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦᒩ"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨᒪ"),l1l11l_l1_ (u"࠭ࠧᒫ")).strip(l1l11l_l1_ (u"ࠧࠡࠩᒬ"))
			l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡔࡱࡧࡹࡦࡴࡂࡷࡪࡸࡶࡦࡴࡀࠫᒭ")+server+l1l11l_l1_ (u"ࠩࠩࡴࡴࡹࡴࡊࡆࡀࠫᒮ")+l1lll11l_l1_+l1l11l_l1_ (u"ࠪࠪࡆࡰࡡࡹ࠿࠴ࠫᒯ")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᒰ")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᒱ")
			l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡥࡱࡺࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᒲ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᒳ"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᒴ")+name+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᒵ")
			if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᒶ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᒷ")+l1111l_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᒸ"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᒹ"),url)
	return
l1l11l_l1_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡑࡎࡄ࡝ࡤࡕࡌࡅࠪࡸࡶࡱ࠯࠺ࠋࠋࡧࡥࡹࡧࠠ࠾ࠢࡾ࡛ࠫ࡯ࡥࡸࠩ࠽࠵ࢂࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ࠿࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬࢃࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࠩࡓࡓࡘ࡚ࠧ࠭ࡷࡵࡰ࠱ࡪࡡࡵࡣ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡡ࡝ࠋࠋࠦࠤࡼࡧࡴࡤࡪࠣࡰ࡮ࡴ࡫ࡴࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡺࡥࡹࡩࡨࡂࡴࡨࡥࡒࡧࡳࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧࠋࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠣࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡰ࡮ࡴ࡫ࡴࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡧࡳࡳࡽ࡬ࡰࡣࡧ࠱ࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡹࡥࡳ࠯ࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡪࡴࡸࠠࡵ࡫ࡷࡰࡪ࠲ࡱࡶࡣ࡯࡭ࡹࡿࠬ࡭࡫ࡱ࡯ࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ࠫࠨࡡࡢࡣࡤ࠭ࠫࡲࡷࡤࡰ࡮ࡺࡹࠋࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠣࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩࠋࠋ࡬ࡪࠥࡲࡥ࡯ࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠭ࡂࡃ࠰࠻ࠢࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠮ࠪห้ืวษู่ࠣ๏ูࠠโ์๊ࠤๆ๐ฯ๋๊ࠪ࠭ࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࡪ࡯ࡳࡳࡷࡺࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠍࠍࠎࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧᒺ")
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠨࠩᒻ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠩࠪᒼ"): return
	search = search.replace(l1l11l_l1_ (u"ࠪࠤࠬᒽ"),l1l11l_l1_ (u"ࠫ࠲࠭ᒾ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧᒿ")+search+l1l11l_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬᓀ")
	l111l1_l1_(url)
	return
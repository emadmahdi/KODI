# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ೦")
menu_name = l1l11l_l1_ (u"࠭࡟ࡌ࡙ࡗࡣࠬ೧")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==130: results = MENU()
	elif mode==131: results = l111l1_l1_(url)
	elif mode==132: results = CATEGORIES(url)
	elif mode==133: results = l111ll_l1_(url,page)
	elif mode==134: results = PLAY(url)
	elif mode==135: results = l1llll11l_l1_()
	elif mode==139: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ೨"),menu_name+l1l11l_l1_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣห้้่ฬำࠪ೩"),l1l11l_l1_ (u"ࠩࠪ೪"),135)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ೫"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ೬"),l1l11l_l1_ (u"ࠬ࠭೭"),139,l1l11l_l1_ (u"࠭ࠧ೮"),l1l11l_l1_ (u"ࠧࠨ೯"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ೰"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧೱ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪೲ"),l1l11l_l1_ (u"ࠫࠬೳ"),9999)
	html = OPENURL_CACHED(REGULAR_CACHE,l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭೴"),l1l11l_l1_ (u"࠭ࠧ೵"),True,l1l11l_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ೶"))
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡵࡱࡪ࡫ࡱ࡫ࠧ೷"),html,re.DOTALL)
	block = l1ll111_l1_[1]
	items=re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ೸"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠪ࠳ࡨࡵ࡮ࡥࡷࡦࡸࡴࡸࠧ೹") in l1111l_l1_: continue
		title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭೺"))
		#l1lllll11_l1_ = [l1l11l_l1_ (u"ࠬ࠵ࡲࡦ࡮࡬࡫࡮ࡵࡵࡴࠩ೻"),l1l11l_l1_ (u"࠭࠯ࡴࡱࡦ࡭ࡦࡲࠧ೼"),l1l11l_l1_ (u"ࠧ࠰ࡲࡲࡰ࡮ࡺࡩࡤࡣ࡯ࠫ೽")]
		#if any(value in l1111l_l1_ for value in l1lllll11_l1_):
		#	title = l1l11l_l1_ (u"ࠨษ็ฬึอๅอࠢࠪ೾")+title
		url = l11lll_l1_+l1111l_l1_
		if l1l11l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭೿") in url: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪഀ"),menu_name+title,url,132)
		else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഁ"),menu_name+title,url,131)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪം"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ഃ"),l1l11l_l1_ (u"ࠧࠨഄ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨഅ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ആ")+menu_name+l1l11l_l1_ (u"ࠪห้๋ำๅี็หฯ࠭ഇ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠶࠶࠶ࠫഈ"),132,l1l11l_l1_ (u"ࠬ࠭ഉ"),l1l11l_l1_ (u"࠭࠱ࠨഊ"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧഋ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬഌ")+menu_name+l1l11l_l1_ (u"ࠩส่ศ็ไศ็ࠪ഍"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠶࠳࠺ࠪഎ"),132,l1l11l_l1_ (u"ࠫࠬഏ"),l1l11l_l1_ (u"ࠬ࠷ࠧഐ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭഑"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫഒ")+menu_name+l1l11l_l1_ (u"ࠨสิห๊าࠠศๆุ฾ฬื้ࠠษ็ุออศࠨഓ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠱࠸ࠩഔ"),132,l1l11l_l1_ (u"ࠪࠫക"),l1l11l_l1_ (u"ࠫ࠶࠭ഖ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬഗ"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪഘ")+menu_name+l1l11l_l1_ (u"ࠧศสิึࠥอไษำส้ั࠭ങ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠶࠽࠶࠴ࠩച"),132,l1l11l_l1_ (u"ࠩࠪഛ"),l1l11l_l1_ (u"ࠪ࠵ࠬജ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഝ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩഞ")+menu_name+l1l11l_l1_ (u"࠭วๅ็ะห฻ืวหࠩട"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠽࠹࠹ࠧഠ"),132,l1l11l_l1_ (u"ࠨࠩഡ"),l1l11l_l1_ (u"ࠩ࠴ࠫഢ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪണ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨത")+menu_name+l1l11l_l1_ (u"ࠬ฿วี๊ิหฦ࠭ഥ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠴࠷࠺࠹ࠧദ"),132,l1l11l_l1_ (u"ࠧࠨധ"),l1l11l_l1_ (u"ࠨ࠳ࠪന"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩഩ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧപ")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ศาษ่ะࠥอไศฮอ้ฬ฿๊สࠩഫ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠷࠳࠵ࠬബ"),132,l1l11l_l1_ (u"࠭ࠧഭ"),l1l11l_l1_ (u"ࠧ࠲ࠩമ"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨയ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ര")+menu_name+l1l11l_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊ฯ๋่ํอࠬറ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠶࠲࠼ࠫല"),132,l1l11l_l1_ (u"ࠬ࠭ള"),l1l11l_l1_ (u"࠭࠱ࠨഴ"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧവ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬശ")+menu_name+l1l11l_l1_ (u"ࠩส่อืวๆฮࠣห้๎หศศๅ๎ฮ࠭ഷ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠶࠵ࠪസ"),132,l1l11l_l1_ (u"ࠫࠬഹ"),l1l11l_l1_ (u"ࠬ࠷ࠧഺ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ഻࠭"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢ഼ࠫ")+menu_name+l1l11l_l1_ (u"ࠨษ็ฬึอๅอࠢสุ่๐วิ์ฬࠫഽ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠴࠶ࠩാ"),132,l1l11l_l1_ (u"ࠪࠫി"),l1l11l_l1_ (u"ࠫ࠶࠭ീ"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬു"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪൂ")+menu_name+l1l11l_l1_ (u"ࠧไฬหࠫൃ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠷࠿࠱ࠨൄ"),132,l1l11l_l1_ (u"ࠩࠪ൅"),l1l11l_l1_ (u"ࠪ࠵ࠬെ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫേ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩൈ")+menu_name+l1l11l_l1_ (u"࠭สฺๆ่ࠤฬ๊แศำึ๎ฮ࠭൉"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠼࠽࠭ൊ"),132,l1l11l_l1_ (u"ࠨࠩോ"),l1l11l_l1_ (u"ࠩ࠴ࠫൌ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ്ࠪ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨൎ")+menu_name+l1l11l_l1_ (u"ࠬษัี์ไࠤฬ๊ศาษ่ะࠬ൏"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠴࠶࠼࠿ࠧ൐"),132,l1l11l_l1_ (u"ࠧࠨ൑"),l1l11l_l1_ (u"ࠨ࠳ࠪ൒"))
	return
def l111l1_l1_(url):
	l1lllll11_l1_ = [l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡲࡩࡨ࡫ࡲࡹࡸ࠭൓"),l1l11l_l1_ (u"ࠪ࠳ࡸࡵࡣࡪࡣ࡯ࠫൔ"),l1l11l_l1_ (u"ࠫ࠴ࡶ࡯࡭࡫ࡷ࡭ࡨࡧ࡬ࠨൕ"),l1l11l_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷࠬൖ"),l1l11l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹࠧൗ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨ൘"),l1l11l_l1_ (u"ࠨࠩ൙"),True,l1l11l_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ൚"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡤࡤࡶ࠭࠴ࠪࡀࠫࡷ࡭ࡹࡲࡥࡣࡣࡵࠫ൛"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	if any(value in url for value in l1lllll11_l1_):
		items = re.findall(l1l11l_l1_ (u"ࠦࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁࠨ൜"),block,re.DOTALL)
		for img,l1111l_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ൝"))
			l1111l_l1_ = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭൞"),menu_name+title,l1111l_l1_,133,img,l1l11l_l1_ (u"ࠧ࠲ࠩൟ"))
	elif l1l11l_l1_ (u"ࠨ࠱ࡧࡳࡨࡹࠧൠ") in url:
		items = re.findall(l1l11l_l1_ (u"ࠤࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࠦൡ"),block,re.DOTALL)
		for img,title,l1111l_l1_ in items:
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬൢ"))
			l1111l_l1_ = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫൣ"),menu_name+title,l1111l_l1_,133,img,l1l11l_l1_ (u"ࠬ࠷ࠧ൤"))
	return
def CATEGORIES(url):
	category = url.split(l1l11l_l1_ (u"࠭࠯ࠨ൥"))[-1]
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠧࠨ൦"),l1l11l_l1_ (u"ࠨࠩ൧"),True,l1l11l_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠴ࡷࡹ࠭൨"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡴࡦࡸࡥ࡯ࡶࡦࡥࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ൩"),html,re.DOTALL)
	if not l1ll111_l1_:
		l111ll_l1_(url,l1l11l_l1_ (u"ࠫ࠶࠭൪"))
		return
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ൫"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		#l1llll1ll_l1_ = url.split(l1l11l_l1_ (u"࠭࠯ࠨ൬"))[-1]
		#if category==l1llll1ll_l1_: continue
		title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩ൭"))
		l1111l_l1_ = l11lll_l1_ + l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ൮"),menu_name+title,l1111l_l1_,132,l1l11l_l1_ (u"ࠩࠪ൯"),l1l11l_l1_ (u"ࠪ࠵ࠬ൰"))
	return
def l111ll_l1_(url,page):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠫࠬ൱"),l1l11l_l1_ (u"ࠬ࠭൲"),True,l1l11l_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ൳"))
	items = re.findall(l1l11l_l1_ (u"ࠧࡵࡱࡷࡥࡱࡶࡡࡨࡧࡦࡳࡺࡴࡴ࠾࡝࡟ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠧࠣ࡟ࠪ൴"),html,re.DOTALL)
	if not items:
		url = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡻࡸ࠳ࡤࡦࡶࡤ࡭ࡱ࠳ࡢࡰࡦࡼࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭൵"),html,re.DOTALL)
		url = url[0]
		title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ൶") + l1l11l_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ൷")
		if url: addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ൸"),menu_name+title,url,134)
		else: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭൹"),l1l11l_l1_ (u"࠭ࠧൺ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪൻ"),l1l11l_l1_ (u"ࠨๆสࠤ๏๎ฬะࠢะห้๐วࠡ็็ๅฬะࠠโ์า๎ํࠦแ๋๊ࠢิฬࠦวๅใิ฽ࠬർ"))
		return
	l1lll1lll_l1_ = int(items[0])
	name = re.findall(l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀ࠾࠲ࡥࡃࠦ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧൽ"),html,re.DOTALL)
	if name: name = name[0].strip(l1l11l_l1_ (u"ࠪࠤࠬൾ"))
	else: name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬൿ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭඀"),l1l11l_l1_ (u"࠭ࠧඁ"),name, str(l1l11l_l1_ (u"ࠧࠨං")))
	if l1l11l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬඃ") in url or l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬ඄") in url:
		category = url.split(l1l11l_l1_ (u"ࠪ࠳ࠬඅ"))[-1]
		if page==l1l11l_l1_ (u"ࠫࠬආ"): url2 = url
		else: url2 = l11lll_l1_ + l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩඇ") + category + l1l11l_l1_ (u"࠭࠯ࠨඈ") + page
		l1lll111_l1_ = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠧࠨඉ"),l1l11l_l1_ (u"ࠨࠩඊ"),True,l1l11l_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫඋ"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡴࡦ࡭ࡥ࡯ࡷࡰࡦࡪࡸࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨඌ"),l1lll111_l1_,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡫ࡻ࡬࡭ࠪ࠱࠮ࡄ࠯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬඍ"),block,re.DOTALL)
		for img,type,l1111l_l1_,title in items:
			if l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫඎ") not in type: continue
			if l1l11l_l1_ (u"࠭ๅิๆึ่ࠬඏ") in title and l1l11l_l1_ (u"ࠧฮๆๅอࠬඐ") not in title: continue
			title = title.replace(l1l11l_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭එ"),l1l11l_l1_ (u"ࠩࠪඒ"))
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬඓ"))
			if l1l11l_l1_ (u"ู๊ࠫไิๆࠪඔ") in name and l1l11l_l1_ (u"ࠬำไใหࠪඕ") in title and l1l11l_l1_ (u"࠭ๅิๆึ่ࠬඖ") not in title:
				title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭඗") + name + l1l11l_l1_ (u"ࠨࠢ࠰ࠤࠬ඘") + title
			l1111l_l1_ = l11lll_l1_ + l1111l_l1_
			if category==l1l11l_l1_ (u"ࠩ࠹࠶࠽࠭඙"): addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪක"),menu_name+title,l1111l_l1_,133,img,l1l11l_l1_ (u"ࠫ࠶࠭ඛ"))
			else: addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫග"),menu_name+title,l1111l_l1_,134,img)
	elif l1l11l_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩඝ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯ࡣࡰ࡮࠰ࡱࡩ࠳࠱࠳ࠩඞ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠣࡸ࡬ࡨࡪࡵ࠭ࡵࡴࡤࡧࡰ࠳ࡴࡦࡺࡷ࠲࠯ࡅ࡬ࡰࡣࡧ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣඟ"),block,re.DOTALL)
			for l1111l_l1_,img,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫච"))
				addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩඡ"),menu_name+title,l1111l_l1_,134,img)
		elif l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠷࠴࠻ࠫජ") in html:
				title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫඣ") + l1l11l_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫඤ")
				addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ඥ"),menu_name+title,url,134)
		else:
			items = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡉࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬඦ"),html,re.DOTALL)
			category = items[0].split(l1l11l_l1_ (u"ࠩ࠲ࠫට"))[-1]
			url = l11lll_l1_ + l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧඨ") + category
			CATEGORIES(url)
			return
		l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࠋࡷࡳࡹࡧ࡬ࡱࡣࡪࡩࡸࠦ࠽ࠡ࠲ࠍࠍࠎࠏࡥࡱ࡫ࡶࡳࡩ࡫ࡉࡅࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠱ࠪ࠭ࡠ࠳࠱࡞ࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣࡅࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫ࡞࠱࠶ࡣࠊࠊࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡࠩ࠲ࡥ࡯ࡧࡸ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫࠥ࠱ࠠࡤࡣࡷࡩ࡬ࡵࡲࡺࠢ࠮ࠤࠬ࠵ࠧࠡ࠭ࠣࡴࡦ࡭ࡥࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠴࠯ࠫࠬ࠲ࠧࠨ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠳ࡳࡦࠪ࠭ࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠠ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪ࡯ࡪ࠰ࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤ࠰ࠦ࡬ࡪࡰ࡮ࠎࠎࠏࠉࠊࡧࡳ࡭ࡸࡵࡤࡦࡋࡇࡲࡪࡽࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬ࡟࠲࠷࡝ࠋࠋࠌࠍࠎ࡯ࡦࠡࡧࡳ࡭ࡸࡵࡤࡦࡋࡇࡲࡪࡽ࠽࠾ࡧࡳ࡭ࡸࡵࡤࡦࡋࡇ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠹࠴࠭࡫ࡰ࡫࠮ࠐࠉࠊࠤࠥࠦඩ")
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫ࠵࠱࠷ࠫࡵࡱࡷࡥࡱࡶࡡࡨࡧࡶ࠭࠿ࠐࠉࠊ࡫ࡩࠤࡵࡧࡧࡦࠣࡀࡷࡹࡸࠨࡪࠫ࠽ࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ฺࠫ็อสࠢࠪ࠯ࡸࡺࡲࠩ࡫ࠬ࠰ࡺࡸ࡬࠭࠳࠶࠷࠱࠭ࠧ࠭ࡵࡷࡶ࠭࡯ࠩࠪࠌࠌࠦࠧࠨඪ")
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧණ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		pages = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩඬ"),block,re.DOTALL)
		for l1111l_l1_,title in pages:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠨࠨࡤࡱࡵࡁࠧත"),l1l11l_l1_ (u"ࠩࠩࠫථ"))
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪද"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪධ")+title,l1111l_l1_,133)
	return
def PLAY(url):
	if l1l11l_l1_ (u"ࠬ࠵࡮ࡦࡹࡶ࠳ࠬන") in url or l1l11l_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ඲") in url:
		html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠧࠨඳ"),l1l11l_l1_ (u"ࠨࠩප"),True,l1l11l_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧඵ"))
		items = re.findall(l1l11l_l1_ (u"ࠥࡱࡴࡨࡩ࡭ࡧࡹ࡭ࡩ࡫࡯ࡱࡣࡷ࡬࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢබ"),html,re.DOTALL)
		if items: url = items[0]
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪභ"))
	return
def l1llll11l_l1_():
	#l1lllll1l_l1_(l1l11l_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫම"))
	#DIALOG_NOTIFICATION(l1l11l_l1_ (u"࠭ฬศำํࠤฯฺฺ๋ๆࠣห้่ๆศหࠪඹ"),l1l11l_l1_ (u"ࠧࠨය"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱࡯࡭ࡻ࡫ࠧර")
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠩࠪ඼"),l1l11l_l1_ (u"ࠪࠫල"),True,l1l11l_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ඾"))
	url2 = re.findall(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭඿"),html,re.DOTALL)
	url2 = url2[0]
	headers2 = {l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧව"):l11lll_l1_}
	response2 = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫශ"),url2,l1l11l_l1_ (u"ࠨࠩෂ"),headers2,l1l11l_l1_ (u"ࠩࠪස"),True,l1l11l_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠷ࡴࡤࠨහ"))
	l1lll111_l1_ = response2.content
	token = re.findall(l1l11l_l1_ (u"ࠫࡨࡹࡲࡧ࠯ࡷࡳࡰ࡫࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫළ"),l1lll111_l1_,re.DOTALL)
	token = token[0]
	l1llll1l1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩෆ"))
	url3 = re.findall(l1l11l_l1_ (u"ࠨࡰ࡭ࡣࡼ࡙ࡷࡲࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ෇"),l1lll111_l1_,re.DOTALL)
	url3 = l1llll1l1_l1_+url3[0]
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ෈"),url3)
	l1lll1ll1_l1_ = {l1l11l_l1_ (u"ࠨ࡚࠰ࡇࡘࡘࡆ࠮ࡖࡒࡏࡊࡔࠧ෉"):token}
	response3 = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ්࡚ࠧ"),url3,l1l11l_l1_ (u"ࠪࠫ෋"),l1lll1ll1_l1_,False,True,l1l11l_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡍࡋ࡙ࡉ࠲࠹ࡲࡥࠩ෌"))
	l1llll111_l1_ = response3.content
	l11ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭෍"),l1llll111_l1_,re.DOTALL)
	l11ll111_l1_ = l11ll111_l1_[0].replace(l1l11l_l1_ (u"࠭࡜࠰ࠩ෎"),l1l11l_l1_ (u"ࠧ࠰ࠩා"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩැ"),l1l11l_l1_ (u"ࠩࠪෑ"),url,html)
	#l1lllll1l_l1_(l1l11l_l1_ (u"ࠪࡷࡹࡵࡰࠨි"))
	PLAY_VIDEO(l11ll111_l1_,script_name,l1l11l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩී"))
	return
def SEARCH(search,url=l1l11l_l1_ (u"ࠬ࠭ු")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if url==l1l11l_l1_ (u"࠭ࠧ෕"):
		if search==l1l11l_l1_ (u"ࠧࠨූ"): search = OPEN_KEYBOARD()
		if search==l1l11l_l1_ (u"ࠨࠩ෗"): return
		#search = search.replace(l1l11l_l1_ (u"ࠩࠣࠫෘ"),l1l11l_l1_ (u"ࠪ࠯ࠬෙ"))
		#search = l1l11l_l1_ (u"ࠫ࠲ࡺࡡࡨࠢࡧࡳࡨࡹࠠࡐࡔࠣࡪ࡮ࡲ࡭ࡴࠢࡒࡖࠥࡹࡥࡳ࡫ࡨࡷࠥࡕࡒࠡࡧࡳ࡭ࡸࡵࡤࡦࠢࡒࡖࠥ࡫ࡰࡪࡵࡲࡨࡪࡹࠠࡐࡔࠣࡧࡦࡺࡥࡨࡱࡵࡽࠥࡕࡒࠡࡰࡨࡻࡸࠦ࡭ࡱ࠶ࠣࠫේ")+search
		#search = l1l11l_l1_ (u"ࠬࠨ࡭ࡱ࠶ࠥࠤࠬෛ")+search
		search = QUOTE(search)
		url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪො")+search
		l111ll_l1_(url,l1l11l_l1_ (u"ࠧࠨෝ"))
		return
	l1l11l_l1_ (u"ࠣࠤࠥࠎࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࡖࡵࡹࡪ࠲ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧࠪࠌࠌࠍࡨࡾࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡷࡣࡵࠤࡨࡾࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࡡ࠰࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠣࡩࡦࡷࡪ࠴ࡳࡳࡥࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪ࡝࠳ࡡࠏࠏࠉࡶࡴ࡯ࠤࡂࠦࡵࡳ࡮࠮ࡧࡽࠐࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࡘࡷࡻࡥ࠭ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩࠬࠎࠎࠏࡣࡴࡧࡢࡸࡴࡱࡥ࡯ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡷࡪࡥࡴࡰ࡭ࡨࡲࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬ࡟࠵ࡣࠊࠊࠋࡦࡷࡪࡲࡩࡣࡘࡨࡶࡸ࡯࡯࡯ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡷࡪࡲࡩࡣࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠࠎࠎࠏࡲࡢࡰࡧࡳࡲࡇࡐࡊࠢࡀࠤࡸࡺࡲࠩࡴࡤࡲࡩࡵ࡭࠯ࡴࡤࡲࡩ࡯࡮ࡵࠪ࠴࠵࠶࠷ࠬ࠺࠻࠼࠽࠮࠯ࠊࠊࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡸ࡫࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡨࡹࡥ࠰ࡧ࡯ࡩࡲ࡫࡮ࡵ࠱ࡹ࠵ࡄࡸࡳࡻ࠿ࡩ࡭ࡱࡺࡥࡳࡧࡧࡣࡨࡹࡥࠧࡰࡸࡱࡂ࠷࠰ࠧࡪ࡯ࡁࡦࡸࠦࡴࡱࡸࡶࡨ࡫࠽ࡨࡥࡶࡧࠫ࡭ࡳࡴ࠿࠱ࡧࡴࡳࠦࡤࡵࡨࡰ࡮ࡨࡶ࠾ࠩ࠮ࡧࡸ࡫࡬ࡪࡤ࡙ࡩࡷࡹࡩࡰࡰ࠮ࠫࠫࡩࡸ࠾ࠩ࠮ࡧࡽ࠱ࠧࠧࡳࡀࠫ࠰ࡹࡥࡢࡴࡦ࡬࠰࠭ࠦࡴࡣࡩࡩࡂࡵࡦࡧࠨࡦࡷࡪࡥࡴࡰ࡭ࡀࠫ࠰ࡩࡳࡦࡡࡷࡳࡰ࡫࡮ࠬࠩࠩࡷࡴࡸࡴ࠾ࠨࡨࡼࡵࡃࡣࡴࡳࡵ࠰ࡨࡩࠦࡤࡣ࡯ࡰࡧࡧࡣ࡬࠿ࡪࡳࡴ࡭࡬ࡦ࠰ࡶࡩࡦࡸࡣࡩ࠰ࡦࡷࡪ࠴ࡡࡱ࡫ࠪ࠯ࡷࡧ࡮ࡥࡱࡰࡅࡕࡏࠫࠨࠨࡶࡸࡦࡸࡴ࠾࠲ࠪࠎࠎࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࠡ࠿ࠣࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠮ࠩࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠿ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡾࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࡘࡷࡻࡥ࠭ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲࡙ࡅࡂࡔࡆࡌ࠲࠹ࡲࡥࠩࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡣࡩࡧࡘࡶࡱࠨ࠺࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡳࡥࡵࡣࡷࡥ࡬ࡹࠢ࠻ࠢࡾࠬ࠳࠰࠿ࠪࡿࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭ࡶࡤ࡫ࡸࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨࡸ࡬ࡨࡪࡵࠧࠡࡰࡲࡸࠥ࡯࡮ࠡࡶࡤ࡫ࡸࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡻ࡮ࡦࡵࡦࡥࡵ࡫ࡈࡕࡏࡏࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠹ࡣࠨ࠮ࠪࡀࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠳ࡦࠩ࠯ࠫࡃ࠭ࠩࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂࡢ࠿ࠩ࠯ࠫࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡧࡄࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠡࠢࠪ࠰ࠬࠦࠧࠪࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠊࠥࠣࡳࡷࠦࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠐࠉࠊࠋࡹࡥࡷࡹࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬࠎࠎࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡀࠤࡻࡧࡲࡴ࡝࠷ࡡࠏࠏࠉࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪࠤ࠰ࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࠋࠋࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡻࡧࡲࡴࠫࡁ࠹࠿ࠐࠉࠊࠋࠌࡴࡦ࡭ࡥ࠲ࠢࡀࠤࡻࡧࡲࡴ࡝࠸ࡡࠏࠏࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡺࡸ࡬࠭࠳࠶࠷࠱࠭ࠧ࠭ࡲࡤ࡫ࡪ࠷ࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡻࡲ࡭࠮࠴࠷࠷࠯ࠊࠊࠋࡨࡰ࡮࡬ࠠࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠲࠵࠶࠰ࠬ࠭ࠬࠨ࠳ࠪ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬࡼࡩࡥࡧࡲࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠷࠳࠵ࠫࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠥ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡵࡷࡥࡷࡺࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡩࡵࡳࡴࡨࡲࡹࡖࡡࡨࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦࡋࡱࡨࡪࡾࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠭ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡤࡷࡵࡶࡪࡴࡴࡑࡣࡪࡩࠥࡃࠠࡴࡶࡵࠬ࡮ࡴࡴࠩࡥࡸࡶࡷ࡫࡮ࡵࡒࡤ࡫ࡪࡡ࠰࡞ࠫ࠮࠵࠮ࠐࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨ࠰ࡸࡺࡡࡳࡶࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡁࡂࡩࡵࡳࡴࡨࡲࡹࡖࡡࡨࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࡸࡶࡱࠦ࠽ࠡࡷࡵࡰ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡹࡴࡢࡴࡷࡁࠬ࠯࡛࠱࡟࠮ࠫࡸࡺࡡࡳࡶࡀࠫ࠰ࡹࡴࡢࡴࡷࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ฺࠫ็อสࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡹࡷࡲࠬ࠲࠵࠼࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥෞ")
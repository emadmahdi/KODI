# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ⸄")
menu_name = l1l11l_l1_ (u"ࠧࡠࡎࡇࡒࡤ࠭⸅")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ⸆"),l1l11l_l1_ (u"ࠩสืฯ็ำศำอ็๊่ࠦࠡษ็฻้ฮวหࠩ⸇")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l111l1_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l111l1lll_l1_(url)
	elif mode==454: results = l111ll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⸈"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ⸉"),l1l11l_l1_ (u"ࠬ࠭⸊"),l1l11l_l1_ (u"࠭ࠧ⸋"),l1l11l_l1_ (u"ࠧࠨ⸌"),l1l11l_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⸍"))
	html = response.content
	l111llll1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭⸎"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸏"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⸐"),l1l11l_l1_ (u"ࠬ࠭⸑"),459,l1l11l_l1_ (u"࠭ࠧ⸒"),l1l11l_l1_ (u"ࠧࠨ⸓"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⸔"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸕"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ⸖")+menu_name+l1l11l_l1_ (u"๊ࠫัศหษอࠤ้๎ฯ๋้ࠢฮࠬ⸗"),l111llll1_l1_,451,l1l11l_l1_ (u"ࠬ࠭⸘"),l1l11l_l1_ (u"࠭ࠧ⸙"),l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⸚"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸛"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭⸜")+menu_name+l1l11l_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ⸝"),l111llll1_l1_,451,l1l11l_l1_ (u"ࠫࠬ⸞"),l1l11l_l1_ (u"ࠬ࠭⸟"),l1l11l_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭⸠"))
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸡"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ⸢")+menu_name+l1l11l_l1_ (u"่้ࠩะ๊๊็ࠩ⸣"),l111llll1_l1_,451,l1l11l_l1_ (u"ࠪࠫ⸤"),l1l11l_l1_ (u"ࠫࠬ⸥"),l1l11l_l1_ (u"ࠬࡧࡣࡵࡱࡵࡷࠬ⸦"))
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸧"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ⸨")+menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วห๊๊ࠢิ๐ษࠨ⸩"),l111llll1_l1_,451,l1l11l_l1_ (u"ࠩࠪ⸪"),l1l11l_l1_ (u"ࠪࠫ⸫"),l1l11l_l1_ (u"ࠫ࠵࠭⸬"))
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸭"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ⸮")+menu_name+l1l11l_l1_ (u"ࠧๆี็ื้อส้้ࠡำ๏ฯࠠๆัห่ัฯࠧⸯ"),l111llll1_l1_,451,l1l11l_l1_ (u"ࠨࠩ⸰"),l1l11l_l1_ (u"ࠩࠪ⸱"),l1l11l_l1_ (u"ࠪ࠵ࠬ⸲"))
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸳"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ⸴")+menu_name+l1l11l_l1_ (u"࠭วโๆส้ࠥํๆะ์ฬࠫ⸵"),l111llll1_l1_,451,l1l11l_l1_ (u"ࠧࠨ⸶"),l1l11l_l1_ (u"ࠨࠩ⸷"),l1l11l_l1_ (u"ࠩ࠵ࠫ⸸"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⸹"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⸺"),l1l11l_l1_ (u"ࠬ࠭⸻"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡎࡣ࡬ࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠭⸼"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⸽"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1111l_l1_==l1l11l_l1_ (u"ࠨࠥࠪ⸾"): continue
			if title in l1llll1_l1_: continue
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸿"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ⹀")+menu_name+title,l1111l_l1_,451)
	return
def l111l1_l1_(url,l11l1ll11_l1_=l1l11l_l1_ (u"ࠫࠬ⹁")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⹂"),l1l11l_l1_ (u"࠭ࠧ⹃"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ⹄"),url,l1l11l_l1_ (u"ࠨࠩ⹅"),l1l11l_l1_ (u"ࠩࠪ⹆"),l1l11l_l1_ (u"ࠪࠫ⹇"),l1l11l_l1_ (u"ࠫࠬ⹈"),l1l11l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⹉"))
	html = response.content
	if l11l1ll11_l1_==l1l11l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⹊"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡕ࡬ࡸࡪ࡙࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡼࡧࡶࡦࡵࠥࠫ⹋"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	elif l11l1ll11_l1_==l1l11l_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ⹌"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡖࡪࡩࡥ࡯ࡶࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⹍"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	elif l1l11l_l1_ (u"ࠪࠦࡆࡩࡴࡰࡴࡶࡐ࡮ࡹࡴࠣࠩ⹎") in html:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡇࡣࡵࡱࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ⹏"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࠤࡄࡧࡹࡵࡲࡏࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⹐"),block,re.DOTALL)
	elif l11l1ll11_l1_ in [l1l11l_l1_ (u"࠭࠰ࠨ⹑"),l1l11l_l1_ (u"ࠧ࠲ࠩ⹒"),l1l11l_l1_ (u"ࠨ࠴ࠪ⹓")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭⹔"),html,re.DOTALL)
		block = l1ll111_l1_[int(l11l1ll11_l1_)]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ⹕"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭⹖"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"๋ࠬิศ้าอࠬ⹗"),l1l11l_l1_ (u"࠭แ๋ๆ่ࠫ⹘"),l1l11l_l1_ (u"ࠧศ฼้๎ฮ࠭⹙"),l1l11l_l1_ (u"ࠨล฽๊๏ฯࠧ⹚"),l1l11l_l1_ (u"ࠩๆ่๏ฮࠧ⹛"),l1l11l_l1_ (u"ࠪห฾๊ว็ࠩ⹜"),l1l11l_l1_ (u"ࠫ์ีวโࠩ⹝"),l1l11l_l1_ (u"๋ࠬศศำสอࠬ⹞"),l1l11l_l1_ (u"ู࠭าุࠪ⹟"),l1l11l_l1_ (u"ࠧๆ้ิะฬ์ࠧ⹠"),l1l11l_l1_ (u"ࠨษ็ฬํ๋ࠧ⹡")]
	for l1111l_l1_,img,title in items:
		if l1l11l_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠨ⹢") in html and l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠨ⹣") in img:
			img = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⹤"),img,re.DOTALL)
			img = img[0]
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠬ࠵ࠧ⹥"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ⹦"),title,re.DOTALL)
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ⹧"),title,re.DOTALL)
		#if any(value in title for value in l111l11ll_l1_):
		if set(title.split()) & set(l111l11ll_l1_) and l1l11l_l1_ (u"ࠨ็ึุ่๊ࠧ⹨") not in title:
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⹩"),menu_name+title,l1111l_l1_,452,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠪั้่ษࠨ⹪") in title:
			title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ⹫") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹬"),menu_name+title,l1111l_l1_,453,img)
				l1l1l11_l1_.append(title)
		else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹭"),menu_name+title,l1111l_l1_,453,img)
	if l11l1ll11_l1_ in [l1l11l_l1_ (u"ࠧࠨ⹮"),l1l11l_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ⹯")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⹰"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⹱"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				#if l1111l_l1_==l1l11l_l1_ (u"ࠦࠧ⹲"): continue
				title = unescapeHTML(title)
				#if title!=l1l11l_l1_ (u"ࠬ࠭⹳"):
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹴"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥ࠭⹵")+title,l1111l_l1_,451)
	return
def l111l1lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ⹶"),url,l1l11l_l1_ (u"ࠩࠪ⹷"),l1l11l_l1_ (u"ࠪࠫ⹸"),l1l11l_l1_ (u"ࠫࠬ⹹"),l1l11l_l1_ (u"ࠬ࠭⹺"),l1l11l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⹻"))
	html = response.content
	# l111lll1l_l1_
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡖࡹࡧࡒࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⹼"),html,re.DOTALL)
	if l111l11l1_l1_ and l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠧ⹽") in str(l111l11l1_l1_):
		title = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠮ࠩ⹾"),html,re.DOTALL)
		title = title[0].strip(l1l11l_l1_ (u"ࠪࠤࠬ⹿"))
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺀"),menu_name+title,url,454)
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⺁"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺂"),menu_name+title,l1111l_l1_,454)
	else: l111ll_l1_(url)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ⺃"),url,l1l11l_l1_ (u"ࠨࠩ⺄"),l1l11l_l1_ (u"ࠩࠪ⺅"),l1l11l_l1_ (u"ࠪࠫ⺆"),l1l11l_l1_ (u"ࠫࠬ⺇"),l1l11l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⺈"))
	html = response.content
	# l1l11l1_l1_
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭⺉"),html,re.DOTALL)
	if l1ll1lll1_l1_:
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ⺊"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⺋"),menu_name+title,l1111l_l1_,452,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⺌"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⺍"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				#if l1111l_l1_==l1l11l_l1_ (u"ࠦࠧ⺎"): continue
				title = unescapeHTML(title)
				#if title!=l1l11l_l1_ (u"ࠬ࠭⺏"):
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺐"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥ࠭⺑")+title,l1111l_l1_,454)
	return
def PLAY(url):
	url2 = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ⺒"),l1l11l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ⺓"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ⺔"),l1l11l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ⺕"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⺖"),url2,l1l11l_l1_ (u"࠭ࠧ⺗"),l1l11l_l1_ (u"ࠧࠨ⺘"),l1l11l_l1_ (u"ࠨࠩ⺙"),l1l11l_l1_ (u"ࠩࠪ⺚"),l1l11l_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⺛"))
	html = response.content
	l111llll1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ⺜"))
	l1ll1lll_l1_ = []
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬࡙࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡸ࡯ࡤࡦࡀࠪ⺝"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ⺞"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⺟")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⺠")
			l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪࠤࡶࡩࡱࡧࡲࡺࠤࠪ⺡"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ⺢"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			name = unescapeHTML(name)
			l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ⺣"),name,re.DOTALL)
			if l1l1l1l1_l1_:
				l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ⺤")+l1l1l1l1_l1_[0]
				name = l1l11l_l1_ (u"࠭ࠧ⺥")
			else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠧࠨ⺦")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⺧")+name+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⺨")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ⺩"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⺪"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭⺫"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧ⺬"): return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩ⺭"),l1l11l_l1_ (u"ࠨ࠭ࠪ⺮"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⺯")+search
	l111l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪኔ")
headers = {l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨን"):l1l11l_l1_ (u"ࠬ࠭ኖ")}
menu_name = l1l11l_l1_ (u"࠭࡟ࡄ࠶ࡘࡣࠬኗ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫኘ"),l1l11l_l1_ (u"ࠨษัี๏࠭ኙ"),l1l11l_l1_ (u"ࠩสาึ๏ࠧኚ"),l1l11l_l1_ (u"ࠪห้ืฦ๋ีํอࠬኛ"),l1l11l_l1_ (u"ࠫอี่็ࠢศาฯ๐วาࠩኜ"),l1l11l_l1_ (u"ࠬอแๅษ่ࠫኝ"),l1l11l_l1_ (u"࠭ๅิๆึ่ฬะࠧኞ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l111l1_l1_(url,text)
	elif mode==422: results = l111l1lll_l1_(url)
	elif mode==423: results = l111ll_l1_(url)
	elif mode==424: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ኟ")+text)
	elif mode==425: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧአ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l11l11ll1_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ኡ"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫኢ"),l1l11l_l1_ (u"ࠫࠬኣ"),l1l11l_l1_ (u"ࠬ࠭ኤ"),l1l11l_l1_ (u"࠭ࠧእ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩኦ"))
	html = response.content
	l111llll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧኧ"),html,re.DOTALL)
	l111llll1_l1_ = l111llll1_l1_[0].strip(l1l11l_l1_ (u"ࠩ࠲ࠫከ"))
	l111llll1_l1_ = SERVER(l111llll1_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧኩ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫኪ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬካ"),l1l11l_l1_ (u"࠭ࠧኬ"),429,l1l11l_l1_ (u"ࠧࠨክ"),l1l11l_l1_ (u"ࠨࠩኮ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ኯ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪኰ"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ኱"),l111llll1_l1_,425)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኲ"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩኳ"),l111llll1_l1_,424)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬኴ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨኵ"),l1l11l_l1_ (u"ࠩࠪ኶"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ኷"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨኸ")+menu_name+l1l11l_l1_ (u"ࠬอไาศํื๏ฯࠧኹ"),l111llll1_l1_,421)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ኺ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫኻ")+menu_name+l1l11l_l1_ (u"ࠨลไ่ฬ๋ࠠศๆ้ะํ๋ࠧኼ"),l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࡵ࠲ࠫኽ"),421)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪኾ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ኿")+menu_name+l1l11l_l1_ (u"ࠬ์๊หใ็็ุ࠭ዀ"),l111llll1_l1_+l1l11l_l1_ (u"࠭࠯࡯ࡧࡷࡪࡱ࡯ࡸ࠰ࠩ዁"),421)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬዂ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯ࠢࠫࡀࠫ࠲࠯ࡅࠩ࠽ࠩዃ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࡵࠪዄ") in l1111l_l1_: title = l1l11l_l1_ (u"ࠪวๆ๊วๆࠢส่๋า่ๆࠩዅ")
		elif l1l11l_l1_ (u"ࠫ࠴ࡴࡥࡵࡨ࡯࡭ࡽ࠭዆") in l1111l_l1_: title = l1l11l_l1_ (u"ࠬษแๅษ่ࠤํ๋ำๅี็หฯࠦๆ๋ฬไู่่ࠧ዇")
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ወ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫዉ")+menu_name+title,l1111l_l1_,421)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨዊ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ዋ")+menu_name+l1l11l_l1_ (u"ࠪๆฬฬๅสࠢอๅฺ๐ไ๋หࠪዌ"),l111llll1_l1_,427)
	return
def l11l11ll1_l1_(website=l1l11l_l1_ (u"ࠫࠬው")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩዎ"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧዏ"),l1l11l_l1_ (u"ࠧࠨዐ"),l1l11l_l1_ (u"ࠨࠩዑ"),l1l11l_l1_ (u"ࠩࠪዒ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬዓ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡔࡪࡶ࡯ࡩ࠭࠴ࠪࡀࠫࡓࡥ࡬࡫ࡔࡪࡶ࡯ࡩࠬዔ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬࠣࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞ࠬ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠬ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁࠬ࠳࠰࠿ࠪ࠾ࠪዕ"),block,re.DOTALL)
	for category,id,l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"࠭࡮ࡦࡶࡩࡰ࡮ࡾ࠭࡮ࡱࡹ࡭ࡪࡹࠧዖ") in l1111l_l1_: title = l1l11l_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไู่่ࠧ዗")
		elif l1l11l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳ࠮ࡰࡨࡸ࡫ࡲࡩࡹࠩዘ") in l1111l_l1_: title = l1l11l_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫዙ")
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዚ"),website+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨዛ")+menu_name+title,l1111l_l1_,421,l1l11l_l1_ (u"ࠬ࠭ዜ"),l1l11l_l1_ (u"࠭ࠧዝ"),category+l1l11l_l1_ (u"ࠧࡽࠩዞ")+id)
	return
def l111l1_l1_(url,l11l1ll11_l1_=l1l11l_l1_ (u"ࠨࠩዟ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪዠ"),l1l11l_l1_ (u"ࠪࠫዡ"),l11l1ll11_l1_,url)
	if l1l11l_l1_ (u"ࠫ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࠧዢ") in url: url = url.strip(l1l11l_l1_ (u"ࠬ࠵ࠧዣ"))+l1l11l_l1_ (u"࠭࠯࡮ࡲࡤࡥ࠴࡬ࡡ࡮࡫࡯ࡽ࠴࠭ዤ")
	items = []
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫዥ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬዦ"),url,l1l11l_l1_ (u"ࠩࠪዧ"),headers,l1l11l_l1_ (u"ࠪࠫየ"),l1l11l_l1_ (u"ࠫࠬዩ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩዪ"))
	html = response.content
	if not l11l1ll11_l1_ or l1l11l_l1_ (u"࠭ࡼࠨያ") in l11l1ll11_l1_:
		#if l1l11l_l1_ (u"ࠧࡎࡷ࡯ࡸ࡮ࡌࡩ࡭ࡶࡨࡶࠬዬ") in html:
		#	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨይ"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬዮ"),url,425)
		#	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዯ"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧደ"),url,424)
		#	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪዱ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ዲ"),l1l11l_l1_ (u"ࠧࠨዳ"),9999)
		if l1l11l_l1_ (u"ࠨࡾࠪዴ") not in l11l1ll11_l1_: l11l11l1l_l1_ = l1l11l_l1_ (u"ࠩࠪድ")
		else: l11l11l1l_l1_ = l1l11l_l1_ (u"ࠪ࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠴࠭ዶ")+l11l1ll11_l1_
		l111ll111_l1_ = False
		if l1l11l_l1_ (u"ࠫࡕ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠧዷ") in html:
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዸ"),menu_name+l1l11l_l1_ (u"࠭วๅ็่๎ืฯࠧዹ"),url,421,l1l11l_l1_ (u"ࠧࠨዺ"),l1l11l_l1_ (u"ࠨࠩዻ"),l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫዼ"))
			l111ll111_l1_ = True
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠨዽ"),html,re.DOTALL)
		if l1ll111_l1_:
			l1l11lll_l1_ = l1ll111_l1_[0]
			l1l1l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡧࡃࠢࠫࠪ࠱࠮ࡄ࠯ࠢࠫ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪዾ"),l1l11lll_l1_,re.DOTALL)
			for l11l111ll_l1_,title2 in l1l1l1111_l1_:
				l11l111l1_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡧࡪࡴࡴࡦࡴ࠲ࡥࡨࡺࡩࡰࡰ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࡹࡧࡢ࠰ࠩዿ")+l11l111ll_l1_+l11l11l1l_l1_+l1l11l_l1_ (u"࠭࠯ࠨጀ")
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧጁ"),menu_name+title2,l11l111l1_l1_,421)
				l111ll111_l1_ = True
		if l111ll111_l1_: addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ጂ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩጃ"),l1l11l_l1_ (u"ࠪࠫጄ"),9999)
	if l11l1ll11_l1_==l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ጅ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡖࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡓࡵ࡭ࡶ࡬ࡊ࡮ࡲࡴࡦࡴࠪጆ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩጇ"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		else: block = l1l11l_l1_ (u"ࠧࠨገ")
	elif l1l11l_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫ࡰࡢࡩࡨࡐࡴࡧࡤࡦࡴ࠲ࠫጉ") in url or l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡦࡩࡳࡺࡥࡳ࠱ࠪጊ") in url:
		block = html
	elif l1l11l_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬጋ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠪࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠯࠭ጌ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	elif l1l11l_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࡸ࠭ግ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡐࡢࡩࡨࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠬࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠪࠨጎ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠮࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪጏ"),block,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡅ࡬ࡱࡦ࠺ࡵࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾ࠨጐ"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		else: block = l1l11l_l1_ (u"ࠩࠪ጑")
	if not items: items = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࠮ࡒࡵࡶࡪࡧࡅࡰࡴࡩ࡫ࠣࠬ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠬ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠱࠮ࡄࡈ࡯ࡹࡖ࡬ࡸࡱ࡫ࡉ࡯ࡨࡲ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿ࠫጒ"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒࡵࡶࡪࡧࡅࡰࡴࡩ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪጓ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for l1111l_l1_,img,title in items:
		if not title: continue
		if l1l11l_l1_ (u"ࠬࡅ࡮ࡦࡹࡶࡁࠬጔ") in l1111l_l1_: continue
		title = title.replace(l1l11l_l1_ (u"࠭ๅีษ๊ำฮࠦࠧጕ"),l1l11l_l1_ (u"ࠧࠨ጖"))
		title = unescapeHTML(title)
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠฮๆๅอࠥࡢࡤࠬࠩ጗"),title,re.DOTALL)
		if l1ll1ll_l1_ and l1l11l_l1_ (u"ࠩะ่็ฯࠧጘ") in title:
			title = l1l11l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩጙ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጚ"),menu_name+title,l1111l_l1_,422,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶ࠴࠭ጛ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ጜ"),menu_name+title,l1111l_l1_,421,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧጝ"),menu_name+title,l1111l_l1_,422,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨጞ"),html,re.DOTALL)
	if l1ll111_l1_ and l11l1ll11_l1_!=l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫጟ"):
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾࡝࡟ࠫࡡࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨ࡞ࠥࡡࡃ࠮࠮ࠫࡁࠬࡀࠬጠ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬጡ"),l1l11l_l1_ (u"ࠬ࠭ጢ"))
			if title!=l1l11l_l1_ (u"࠭ࠧጣ"): addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧጤ"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧጥ")+title,l1111l_l1_,421)
	l11l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿࠳ࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬጦ"),html,re.DOTALL)
	if l11l1l111_l1_:
		l1111l_l1_,title = l11l1l111_l1_[0]
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጧ"),menu_name+title,l1111l_l1_,421)
	return
def l111l1lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨጨ"),url,l1l11l_l1_ (u"ࠬ࠭ጩ"),l1l11l_l1_ (u"࠭ࠧጪ"),l1l11l_l1_ (u"ࠧࠨጫ"),l1l11l_l1_ (u"ࠨࠩጬ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧጭ"))
	html = response.content
	# l1l1ll11l_l1_/download main l1l1llll_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡐࡲࡻࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧጮ"),html,re.DOTALL)
	if l1ll111_l1_:
		url = l1ll111_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨጯ"),url,l1l11l_l1_ (u"ࠬ࠭ጰ"),l1l11l_l1_ (u"࠭ࠧጱ"),l1l11l_l1_ (u"ࠧࠨጲ"),l1l11l_l1_ (u"ࠨࠩጳ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠶ࡳࡪࠧጴ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨጵ"),l1l11l_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫጶ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࡙ࠬࡥࡢࡵࡲࡲࡸ࡙ࡥࡤࡶ࡬ࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩጷ"),html,re.DOTALL)
	# l111ll11l_l1_ l11l11l11_l1_
	if l1l11l_l1_ (u"࠭࠯ࡵࡣࡪ࠳ࠬጸ") in url or l1l11l_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࠧጹ") in url:
		l111l1_l1_(url)
	# l111lll1l_l1_
	elif l1ll111_l1_:
		img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩጺ"))
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠣጻ"),block,re.DOTALL)
		l111ll1ll_l1_ = [l1l11l_l1_ (u"ุ้๊ࠪำๅࠩጼ"),l1l11l_l1_ (u"๊ࠫ๎ำๆࠩጽ"),l1l11l_l1_ (u"ࠬฮั็ษ่ะࠬጾ"),l1l11l_l1_ (u"࠭อๅไฬࠫጿ")]
		for l1111l_l1_,title in items:
			if any(value in title for value in l111ll1ll_l1_):
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧፀ"),menu_name+title,l1111l_l1_,423,img)
			else: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧፁ"),menu_name+title,l1111l_l1_,426,img)
	else: l111ll_l1_(url)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ፂ"),url,l1l11l_l1_ (u"ࠪࠫፃ"),l1l11l_l1_ (u"ࠫࠬፄ"),l1l11l_l1_ (u"ࠬ࠭ፅ"),l1l11l_l1_ (u"࠭ࠧፆ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ፇ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ፈ"),l1l11l_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩፉ"))
	img = re.findall(l1l11l_l1_ (u"ࠪࠦࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ፊ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = l1l11l_l1_ (u"ࠫࠬፋ")
	# l1l11l1_l1_
	l1ll1ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡋࡰࡪࡵࡲࡨࡪࡹࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪፌ"),html,re.DOTALL)
	if l1ll1ll1l_l1_:
		block = l1ll1ll1l_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪፍ"),block,re.DOTALL)
		for l1111l_l1_,title,l1ll1ll_l1_ in items:
			title = title+l1l11l_l1_ (u"ࠧࠡࠩፎ")+l1ll1ll_l1_
			addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧፏ"),menu_name+title,l1111l_l1_,426,img)
	else: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨፐ"),menu_name+l1l11l_l1_ (u"ࠪีฬฮืࠡษ็ฮูเ๊ๅࠩፑ"),url,426,img)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨፒ"),url,l1l11l_l1_ (u"ࠬ࠭ፓ"),headers,l1l11l_l1_ (u"࠭ࠧፔ"),l1l11l_l1_ (u"ࠧࠨፕ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪፖ"))
	html = response.content
	#newurl = re.findall(l1l11l_l1_ (u"ࠩࠥࡷࡹࡿ࡬ࡦࡵ࡫ࡩࡪࡺࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩፗ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨፘ"))
	l111llll1_l1_ = SERVER(newurl,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨፙ"))
	l1ll1lll_l1_ = []
	# l1l1ll11l_l1_ l1ll1111_l1_
	#if kodi_version>18.99: html = html.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪፚ"),l1l11l_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭፛"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡘࡣࡷࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ፜"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧࠨࠠ࠰ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ፝"),block,re.DOTALL)
		for l1lll1ll_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ፞"))
			if l1l11l_l1_ (u"ࠪࡱࡾࡼࡩࡥࠩ፟") in title.lower(): title = l1l11l_l1_ (u"ࠫำอีࠡࠩ፠")+title
			l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡳࡵࡴࡸࡧࡹࡻࡲࡦ࠱ࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪ፡")+l1lll1ll_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ።")+title+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ፣")
			#l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡡ࠵ࡷ࠱࡭ࡨࡻࠧ፤"),l1l11l_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴ࡶ࠰ࡰࡼࠬ፥"))
			l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡘ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ፦"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ፧"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ፨"))
			if l1l11l_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬ፩") in title.lower(): title2 = l1l11l_l1_ (u"ࠧࡠࡡัหฺ࠭፪")
			else: title2 = l1l11l_l1_ (u"ࠨࠩ፫")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ፬")+title+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ፭")+title2
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ፮"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ፯"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ፰"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨ፱"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ፲"),l1l11l_l1_ (u"ࠩ࠮ࠫ፳"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ፴")+search+l1l11l_l1_ (u"ࠫ࠴࠭፵")
	l111l1_l1_(url,l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ፶"))
	return
# ===========================================
#     l11l1l1ll_l1_ l111lll11_l1_ l111ll1l1_l1_
# ===========================================
def l11l1l1l1_l1_(url):
	if l1l11l_l1_ (u"࠭ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࠨ፷") not in url: url = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ፸"))
	else: url = url.split(l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ፹"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭፺"),url,l1l11l_l1_ (u"ࠪࠫ፻"),l1l11l_l1_ (u"ࠫࠬ፼"),l1l11l_l1_ (u"ࠬ࠭፽"),l1l11l_l1_ (u"࠭ࠧ፾"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ፿"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᎀ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + options block + category
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡋࡳࡻ࡫ࡲࡢࡤ࡯ࡩ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿ࠣࡣ࡯ࡰࠧ࠴ࠪࡀࠪࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᎁ"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111lllll_l1_(block):
	# id + title
	items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᎂ"),block,re.DOTALL)
	return items
def l11l11lll_l1_(url):
	l11l1111l_l1_ = url.split(l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᎃ"))[0]
	l11l11111_l1_ = SERVER(url,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩᎄ"))
	url = url.replace(l11l1111l_l1_,l11l11111_l1_)
	url = url.replace(l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᎅ"),l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡩࡥ࡯ࡶࡨࡶ࠴ࡧࡣࡵ࡫ࡲࡲ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࠧᎆ"))
	url = url.replace(l1l11l_l1_ (u"ࠨ࠿ࠪᎇ"),l1l11l_l1_ (u"ࠩ࠲ࠫᎈ")).replace(l1l11l_l1_ (u"ࠪࠪࠬᎉ"),l1l11l_l1_ (u"ࠫ࠴࠭ᎊ"))
	url = url+l1l11l_l1_ (u"ࠬ࠵ࠧᎋ")
	return url
l1111l1_l1_ = [l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᎌ"),l1l11l_l1_ (u"ࠧࡵࡻࡳࡩࡸ࠭ᎍ"),l1l11l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᎎ")]
l11ll1l_l1_ = [l1l11l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᎏ"),l1l11l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ᎐"),l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࡵࠪ᎑"),l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ᎒")]
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᎓"),l1l11l_l1_ (u"ࠧࠨ᎔"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ᎕"),l1l11l_l1_ (u"ࠩࠪ᎖"),filter,url)
	if l1l11l_l1_ (u"ࠪࡃࠬ᎗") in url: url = url.split(l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ᎘"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ᎙"),1)
	if filter==l1l11l_l1_ (u"࠭ࠧ᎚"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"ࠧࠨ᎛"),l1l11l_l1_ (u"ࠨࠩ᎜")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭᎝"))
	if type==l1l11l_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭᎞"):
		if l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ᎟") in url:
			global l1111l1_l1_
			l1111l1_l1_ = l1111l1_l1_[1:]
		if l1111l1_l1_[0]+l1l11l_l1_ (u"ࠬࡃࠧᎠ") not in l111111_l1_: category = l1111l1_l1_[0]
		for i in range(len(l1111l1_l1_[0:-1])):
			if l1111l1_l1_[i]+l1l11l_l1_ (u"࠭࠽ࠨᎡ") in l111111_l1_: category = l1111l1_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠧࠧࠩᎢ")+category+l1l11l_l1_ (u"ࠨ࠿࠳ࠫᎣ")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠩࠩࠫᎤ")+category+l1l11l_l1_ (u"ࠪࡁ࠵࠭Ꭵ")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠫࠫ࠭Ꭶ"))+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᎧ")+l11l11l_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠨᎨ"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᎩ"))
		url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᎪ")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬᎫ"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᎬ"))
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠫࠬᎭ"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᎮ"))
		if l1llllll_l1_==l1l11l_l1_ (u"࠭ࠧᎯ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᎰ")+l1llllll_l1_
		url2 = l11l11lll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎱ"),menu_name+l1l11l_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬᎲ"),url2,421,l1l11l_l1_ (u"ࠪࠫᎳ"),l1l11l_l1_ (u"ࠫࠬᎴ"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᎵ"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮆ"),menu_name+l1l11l_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧᎷ")+l1ll1ll1_l1_+l1l11l_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧᎸ"),url2,421,l1l11l_l1_ (u"ࠩࠪᎹ"),l1l11l_l1_ (u"ࠪࠫᎺ"),l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᎻ"))
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᎼ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ꮍ"),l1l11l_l1_ (u"ࠧࠨᎾ"),9999)
	l1l1ll1_l1_ = l11l1l1l1_l1_(url)
	dict = {}
	for name,block,l1l111l_l1_ in l1l1ll1_l1_:
		if l1l11l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬᎿ") in url and l1l111l_l1_==l1l11l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᏀ"): continue
		name = name.replace(l1l11l_l1_ (u"ࠪ࠱࠲࠭Ꮑ"),l1l11l_l1_ (u"ࠫࠬᏂ"))
		items = l111lllll_l1_(block)
		if l1l11l_l1_ (u"ࠬࡃࠧᏃ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᏄ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l1111l1_l1_[-1]:
					url = l11l11lll_l1_(url)
					l111l1_l1_(url)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Ꮕ")+l111l11_l1_)
				return
			else:
				url2 = l11l11lll_l1_(url2)
				if l1l111l_l1_==l1111l1_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᏆ"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠩᏇ"),url2,421,l1l11l_l1_ (u"ࠪࠫᏈ"),l1l11l_l1_ (u"ࠫࠬᏉ"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᏊ"))
				else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮛ"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠧᏌ"),url2,425,l1l11l_l1_ (u"ࠨࠩᏍ"),l1l11l_l1_ (u"ࠩࠪᏎ"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭Ꮟ"):
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠫࠫ࠭Ꮠ")+l1l111l_l1_+l1l11l_l1_ (u"ࠬࡃ࠰ࠨᏑ")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"࠭ࠦࠨᏒ")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾࠲ࠪᏓ")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᏔ")+l11l11l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏕ"),menu_name+l1l11l_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬᏖ")+name,url2,424,l1l11l_l1_ (u"ࠫࠬᏗ"),l1l11l_l1_ (u"ࠬ࠭Ꮨ"),l111l11_l1_)		# +l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᏙ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if value==l1l11l_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧᏚ"): option = l1l11l_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨᏛ")
			elif value==l1l11l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩᏜ"): option = l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬᏝ")
			if option in l1llll1_l1_: continue
			#if l1l11l_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪᏞ") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ꮯ"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠨᏠ")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾ࠩᏡ")+option
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠪᏢ")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࠫᏣ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᏤ")+l11l11l_l1_
			title = option+l1l11l_l1_ (u"ࠫࠥࡀࠧᏥ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠬ࠶ࠧᏦ")]
			title = option+l1l11l_l1_ (u"࠭ࠠ࠻ࠩᏧ")+name
			if type==l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪᏨ"): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᏩ"),menu_name+title,url,424,l1l11l_l1_ (u"ࠩࠪᏪ"),l1l11l_l1_ (u"ࠪࠫᏫ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ꮼ"))
			elif type==l1l11l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᏭ") and l1111l1_l1_[-2]+l1l11l_l1_ (u"࠭࠽ࠨᏮ") in l111111_l1_:
				l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᏯ"))
				url3 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᏰ")+l1llll11_l1_
				url3 = l11l11lll_l1_(url3)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᏱ"),menu_name+title,url3,421,l1l11l_l1_ (u"ࠪࠫᏲ"),l1l11l_l1_ (u"ࠫࠬᏳ"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᏴ"))
			else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ᏽ"),menu_name+title,url,425,l1l11l_l1_ (u"ࠧࠨ᏶"),l1l11l_l1_ (u"ࠨࠩ᏷"),l1l1111_l1_)
	return
def l1llll1l_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᏸ"),l1l11l_l1_ (u"ࠪࠫᏹ"),filters,l1l11l_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬᏺ"))
	# mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᏻ")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᏼ")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"ࠧࡢ࡮࡯ࠫᏽ")					all l111lll_l1_ & l11l1l11l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠨ࠿ࠩࠫ᏾"),l1l11l_l1_ (u"ࠩࡀ࠴ࠫ࠭᏿"))
	filters = filters.strip(l1l11l_l1_ (u"ࠪࠪࠬ᐀"))
	l11111l_l1_ = {}
	if l1l11l_l1_ (u"ࠫࡂ࠭ᐁ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠬࠬࠧᐂ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"࠭࠽ࠨᐃ"))
			l11111l_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠧࠨᐄ")
	for key in l11ll1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠨ࠲ࠪᐅ")
		if l1l11l_l1_ (u"ࠩࠨࠫᐆ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᐇ") and value!=l1l11l_l1_ (u"ࠫ࠵࠭ᐈ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠦࠫࠡࠩᐉ")+value
		elif mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᐊ") and value!=l1l11l_l1_ (u"ࠧ࠱ࠩᐋ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠨࠨࠪᐌ")+key+l1l11l_l1_ (u"ࠩࡀࠫᐍ")+value
		elif mode==l1l11l_l1_ (u"ࠪࡥࡱࡲࠧᐎ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠫ࠭ᐏ")+key+l1l11l_l1_ (u"ࠬࡃࠧᐐ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"࠭ࠠࠬࠢࠪᐑ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠩᐒ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠨ࠿࠳ࠫᐓ"),l1l11l_l1_ (u"ࠩࡀࠫᐔ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᐕ"),l1l11l_l1_ (u"ࠫࠬᐖ"),filters,l1l11l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭ᐗ"))
	return l11llll_l1_
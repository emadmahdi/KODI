# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨ⇸")
menu_name = l1l11l_l1_ (u"ࠪࡣࡌࡒࡓࡠࠩ⇹")
def MAIN(mode,url,text,page):
	if   mode==540: results = MENU()
	elif mode==541: results = l1111111l1_l1_(text)
	elif mode==542: results = l1llllll111_l1_(text,url,page)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇺"),l1l11l_l1_ (u"ࠬฮอฬࠢฯำ๏ีࠧ⇻"),l1l11l_l1_ (u"࠭ࠧ⇼"),549)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⇽"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๆะี๊ฮࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⇾"),l1l11l_l1_ (u"ࠩࠪ⇿"),9999)
	l1llllllll1_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ∀"),l1l11l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ∁"))
	if l1llllllll1_l1_:
		l1llllllll1_l1_ = l1llllllll1_l1_[l1l11l_l1_ (u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭∂")]
		for search in reversed(l1llllllll1_l1_):
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭∃"),search,l1l11l_l1_ (u"ࠧࠨ∄"),549,l1l11l_l1_ (u"ࠨࠩ∅"),l1l11l_l1_ (u"ࠩࠪ∆"),search)
	return
def SEARCH(search):
	#search,options,showdialogs = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l11l111111_l1_ = search.replace(menu_name,l1l11l_l1_ (u"ࠪࠫ∇"))
	l1lllll11ll_l1_(l11l111111_l1_)
	#l1lllllll1l_l1_ = search+options+l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ∈")
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ∉"),l1l11l_l1_ (u"ู࠭ๆๆࠣฬาัࠠอ็ส฽๏ࠦ࠭ࠡࠩ∊")+l11l111111_l1_,l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭∋"),542,l1l11l_l1_ (u"ࠨࠩ∌"),l1l11l_l1_ (u"ࠩࠪ∍"),l11l111111_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ∎"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ∏"),l1l11l_l1_ (u"ࠬ࠭∐"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭∑"),l1l11l_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥแึๆฬࠤ࠲ࠦࠧ−")+l11l111111_l1_,l1l11l_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ∓"),542,l1l11l_l1_ (u"ࠩࠪ∔"),l1l11l_l1_ (u"ࠪࠫ∕"),l11l111111_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ∖"),l1l11l_l1_ (u"ࠬ์สศศฯࠤฬ๊ศฮอ้ࠣ็ูๅสࠢ࠰ࠤࠬ∗")+l11l111111_l1_,l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ∘"),542,l1l11l_l1_ (u"ࠧࠨ∙"),l1l11l_l1_ (u"ࠨࠩ√"),l11l111111_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ∛"),l1l11l_l1_ (u"ࠪฬาัࠠๆ่ไีิࠦ࠭ࠡࠩ∜")+l11l111111_l1_,l1l11l_l1_ (u"ࠫࠬ∝"),541,l1l11l_l1_ (u"ࠬ࠭∞"),l1l11l_l1_ (u"࠭ࠧ∟"),l11l111111_l1_)
	return
def l1lllll11ll_l1_(l111111lll_l1_):
	l11111l11l_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ∠"),l1l11l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭∡"),l111111lll_l1_)
	l11111l111_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ∢"),l1l11l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ∣"),menu_name+l111111lll_l1_)
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ∤"),l111111lll_l1_)
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ∥"),menu_name+l111111lll_l1_)
	old_value = l11111l11l_l1_+l11111l111_l1_
	if old_value: l111111lll_l1_ = menu_name+l111111lll_l1_
	WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ∦"),l111111lll_l1_,old_value,l1llllll1l1_l1_)
	return
def l1lllll1ll1_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࠨ∧"),l1l11l_l1_ (u"ࠨࠩ∨"),l1l11l_l1_ (u"ࠩࠪ∩"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭∪"),l1l11l_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠไๆ่หฯࠦวๅสะฯࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠡࠨ∫"))
	if yes!=1: return
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ∬"))
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ∭"))
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭∮"))
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ∯"),l1l11l_l1_ (u"ࠩࠪ∰"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭∱"),l1l11l_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ∲"))
	return
def l1llllll111_l1_(search_org,action,site=l1l11l_l1_ (u"ࠬ࠭∳")):
	l1llllll1ll_l1_,l1lllllll11_l1_,l1lllllllll_l1_,l1llll1ll1l_l1_,l1llll1llll_l1_,l1llll1lll1_l1_,threads = [],[],[],{},{},{},{}
	if action==l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ∴"): l1lllllllll_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ∵"),l1l11l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭∶"),menu_name+search_org)
	elif action==l1l11l_l1_ (u"ࠩࡲࡴࡪࡴࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ∷"): l1lllllllll_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ∸"),l1l11l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡓࡕࡋࡎࡆࡆࠪ∹"),search_org)
	elif action==l1l11l_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫ∺"): l1lllllllll_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫ∻"),l1l11l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭∼"),[site,search_org])
	if not l1lllllllll_l1_:
		l1111111ll_l1_ = l1l11l_l1_ (u"ࠨ้ำหࠥอไษฯฮࠤ฿๐ัࠡ็๋ะํีࠠโ์ࠣ็ฬฺࠠศๆหี๋อๅอࠢ࡟ࡲࡡࡴ࡜࡯ࠩ∽")
		l111111l11_l1_ = l1l11l_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ศๆࠡษ็ฬาัࠠโ์ࠣะ๊๐ูࠡษ็้ํอโฺࠢ฼๊ࠥࡢ࡮ࠡࠤ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥ࠭∾")+search_org+l1l11l_l1_ (u"ࠪࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠨࠠ࡝ࡰࠣ฽้๋วࠡล้ࠤ์ึวࠡษ็ฬาัࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠬ∿")
		if action==l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪ≀"): message = l111111l11_l1_
		else: message = l1111111ll_l1_+l111111l11_l1_
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬ࠭≁"),l1l11l_l1_ (u"࠭ࠧ≂"),l1l11l_l1_ (u"ࠧࠨ≃"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ≄"),message)
		if yes!=1: return
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ≅"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡓࡦࡣࡵࡧ࡭ࠦࡆࡰࡴ࠽ࠤࡠࠦࠧ≆")+search_org+l1l11l_l1_ (u"ࠫࠥࡣࠧ≇"))
		#global menuItemsLIST
		import threading
		#ALL_SEARCH_SITES = [l1l11l_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ≈"),l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ≉"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ≊")]
		l11111ll1l_l1_ = 1
		for site in ALL_SEARCH_SITES:
			l1llll1ll1l_l1_[site] = []
			options = l1l11l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭≋")
			if l1l11l_l1_ (u"ࠩ࠰ࠫ≌") in site: options = options+l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࠨ≍")+site+l1l11l_l1_ (u"ࠫࡤ࠭≎")
			l1lllll1l11_l1_,l1llllll11l_l1_,l11111ll11_l1_ = l1lllll1111_l1_(site)
			if l11111ll1l_l1_:
				threads[site] = threading.Thread(target=l1llllll11l_l1_,args=(search_org+options,))
				threads[site].start()
			else: l1llllll11l_l1_(search_org+options)
			DIALOG_NOTIFICATION(TRANSLATE(site),l1l11l_l1_ (u"ࠬ࠭≏"),time=1000)
		if l11111ll1l_l1_:
			for site in ALL_SEARCH_SITES:
				threads[site].join(10)
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ≐"),l1l11l_l1_ (u"ࠧࠨ≑"),l1l11l_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠠࡧࡱࡸࡲࡩ࡫ࡤ࠻ࠩ≒"),str(len(menuItemsLIST)))
		for site in ALL_SEARCH_SITES:
			l1lllll1l11_l1_,l1llllll11l_l1_,l11111ll11_l1_ = l1lllll1111_l1_(site)
			for menuItem in menuItemsLIST:
				type,name,url,mode,image,page,text,context,infodict = menuItem
				if l11111ll11_l1_ in name:
					if l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࠨ≓") in site and 239>=mode>=230:
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭≔")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ≕")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ≖")]: continue
						if l1l11l_l1_ (u"࠭ีโฯฬࠫ≗") not in name:
							if   type==l1l11l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ≘"): site = l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ≙")
							elif type==l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ≚"): site = l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ≛")
							elif type==l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≜"): site = l1l11l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ≝")
						else:
							if   l1l11l_l1_ (u"࠭ࡌࡊࡘࡈࠫ≞") in url: site = l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ≟")
							elif l1l11l_l1_ (u"ࠨࡏࡒ࡚ࡎࡋࡓࠨ≠") in url: site = l1l11l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ≡")
							elif l1l11l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ≢") in url: site = l1l11l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ≣")
					elif l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࠧ≤") in site and 149>=mode>=140:
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ≥")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ≦")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ≧")]: continue
						if l1l11l_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ≨") in name or l1l11l_l1_ (u"ࠪ࠾࠿ࠦࠧ≩") in name:
							continue
							#if   image==l1l11l_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭≪"): site = l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ≫")
							#elif image==l1l11l_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ≬"): site = l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ≭")
							#else: site = l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ≮")
						else:
							if   mode==144 and l1l11l_l1_ (u"ࠩࡘࡗࡊࡘࠧ≯") in name: site = l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭≰")
							elif mode==144 and l1l11l_l1_ (u"ࠫࡈࡎࡎࡍࠩ≱") in name: site = l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ≲")
							elif mode==144 and l1l11l_l1_ (u"࠭ࡌࡊࡕࡗࠫ≳") in name: site = l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ≴")
							elif mode==143: site = l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ≵")
							else: continue
					elif l1l11l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࠨ≶") in site and 419>=mode>=400:
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ≷")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ≸")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ≹")]: continue
						if   mode in [401,405]: site = l1l11l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ≺")
						elif mode in [402,406]: site = l1l11l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ≻")
						elif mode in [403,404]: site = l1l11l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭≼")
					elif l1l11l_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࠩ≽") in site and 39>=mode>=30:
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩ≾")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪ≿")]: continue
						if   mode in [32,39]: site = l1l11l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫ⊀")
						elif mode in [33,39]: site = l1l11l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ⊁")
					elif l1l11l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࠧ⊂") in site and 29>=mode>=20:
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ⊃")]: continue
						if menuItem in l1llll1ll1l_l1_[l1l11l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⊄")]: continue
						if   l1l11l_l1_ (u"ࠪ࠳ࡦࡸ࠮ࠨ⊅") in url: site = l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ⊆")
						elif l1l11l_l1_ (u"ࠬ࠵ࡥ࡯࠰ࠪ⊇") in url: site = l1l11l_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭⊈")
					#elif l1l11l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࠫ⊉") in site and 319>=mode>=310:
					#	if menuItem in l1llll1ll1l_l1_[site]: continue
					#	if mode==312: site = l1lllll1l1l_l1_+l1l11l_l1_ (u"ࠨ࠯ࡄ࡙ࡉࡏࡏࡔࠩ⊊")
					#	elif l1l11l_l1_ (u"ࠩ࠲ࡧࡦࡺ࠭ࠨ⊋") in url: site = l1lllll1l1l_l1_+l1l11l_l1_ (u"ࠪ࠱ࡆࡒࡂࡖࡏࡖࠫ⊌")
					#	else: site = l1lllll1l1l_l1_+l1l11l_l1_ (u"ࠫ࠲ࡖࡅࡓࡕࡒࡒࡘ࠭⊍")
					l1llll1ll1l_l1_[site].append(menuItem)
		menuItemsLIST[:] = []
		for site in list(l1llll1ll1l_l1_.keys()):
			l1llll1llll_l1_[site] = []
			l1llll1lll1_l1_[site] = []
			for type,name,url,mode,image,page,text,context,infodict in l1llll1ll1l_l1_[site]:
				menuItem = (type,name,url,mode,image,page,text,context,infodict)
				if l1l11l_l1_ (u"ࠬ฻แฮหࠪ⊎") in name and type==l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊏"): l1llll1lll1_l1_[site].append(menuItem)
				else: l1llll1llll_l1_[site].append(menuItem)
		l11111111l_l1_ = [(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⊐"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⊑"),l1l11l_l1_ (u"ࠩࠪ⊒"),157,l1l11l_l1_ (u"ࠪࠫ⊓"),l1l11l_l1_ (u"ࠫࠬ⊔"),l1l11l_l1_ (u"ࠬ࠭⊕"),l1l11l_l1_ (u"࠭ࠧ⊖"),l1l11l_l1_ (u"ࠧࠨ⊗"))]
		for site in SITES_SERVERS_SORTED:
			if site==SITES_SERVERS_MIXED[0]: l11111111l_l1_ = [(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⊘"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⊙"),l1l11l_l1_ (u"ࠪࠫ⊚"),157,l1l11l_l1_ (u"ࠫࠬ⊛"),l1l11l_l1_ (u"ࠬ࠭⊜"),l1l11l_l1_ (u"࠭ࠧ⊝"),l1l11l_l1_ (u"ࠧࠨ⊞"),l1l11l_l1_ (u"ࠨࠩ⊟"))]
			elif site==SITES_SERVERS_PUBLIC[0]: l11111111l_l1_ = [(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⊠"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⊡"),l1l11l_l1_ (u"ࠫࠬ⊢"),157,l1l11l_l1_ (u"ࠬ࠭⊣"),l1l11l_l1_ (u"࠭ࠧ⊤"),l1l11l_l1_ (u"ࠧࠨ⊥"),l1l11l_l1_ (u"ࠨࠩ⊦"),l1l11l_l1_ (u"ࠩࠪ⊧"))]
			elif site==SITES_SERVERS_PRIVATE_end[0]: l11111111l_l1_ = [(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⊨"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⊩"),l1l11l_l1_ (u"ࠬ࠭⊪"),157,l1l11l_l1_ (u"࠭ࠧ⊫"),l1l11l_l1_ (u"ࠧࠨ⊬"),l1l11l_l1_ (u"ࠨࠩ⊭"),l1l11l_l1_ (u"ࠩࠪ⊮"),l1l11l_l1_ (u"ࠪࠫ⊯"))]
			if site not in l1llll1llll_l1_.keys(): continue
			if l1llll1llll_l1_[site]:
				l1lllll11l1_l1_ = TRANSLATE(site)
				l1lllll1lll_l1_ = [(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⊰"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࠦࠧ⊱")+l1lllll11l1_l1_+l1l11l_l1_ (u"࠭ࠠ࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⊲"),l1l11l_l1_ (u"ࠧࠨ⊳"),9999,l1l11l_l1_ (u"ࠨࠩ⊴"),l1l11l_l1_ (u"ࠩࠪ⊵"),l1l11l_l1_ (u"ࠪࠫ⊶"),l1l11l_l1_ (u"ࠫࠬ⊷"),l1l11l_l1_ (u"ࠬ࠭⊸"))]
				l11111l1l1_l1_ = l1l11l_l1_ (u"࠭ศฮอࠪ⊹")+l1l11l_l1_ (u"ࠧࠡࠩ⊺")+l1lllll11l1_l1_+l1l11l_l1_ (u"ࠨࠢ࠰ࠤࠬ⊻")+search_org
				if len(l1llll1llll_l1_[site])<8: l111111111_l1_ = []
				else:
					l11111l1ll_l1_ = l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ⊼")+l11111l1l1_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⊽")
					l111111111_l1_ = [(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊾"),menu_name+l11111l1ll_l1_,l1l11l_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫ⊿"),542,l1l11l_l1_ (u"࠭ࠧ⋀"),site,search_org,l1l11l_l1_ (u"ࠧࠨ⋁"),l1l11l_l1_ (u"ࠨࠩ⋂"))]
				l111111l1l_l1_ = l1llll1llll_l1_[site]+l1llll1lll1_l1_[site]
				l1lllllll11_l1_ += l11111111l_l1_+l1lllll1lll_l1_+l111111l1l_l1_[:7]+l111111111_l1_
				l1lllll111l_l1_ = [(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋃"),menu_name+l11111l1l1_l1_,l1l11l_l1_ (u"ࠪࡧࡱࡵࡳࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⋄"),542,l1l11l_l1_ (u"ࠫࠬ⋅"),site,search_org,l1l11l_l1_ (u"ࠬ࠭⋆"),l1l11l_l1_ (u"࠭ࠧ⋇"))]
				l1llllll1ll_l1_ += l11111111l_l1_+l1lllll111l_l1_
				l11111111l_l1_ = []
				WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭⋈"),[site,search_org],l111111l1l_l1_,l1llllll1l1_l1_)
		WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⋉"),search_org,l1lllllll11_l1_,l1llllll1l1_l1_)
		DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⋊"),search_org)
		WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⋋"),menu_name+search_org,l1llllll1ll_l1_,l1llllll1l1_l1_)
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⋌"),l1l11l_l1_ (u"ࠬ࠭⋍"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⋎"),l1l11l_l1_ (u"ࠧศๆหัะࠦวๅฮ่ห฾๐ࠠศ่อ๋๎ࠦศ็ฮสัࠥࡢ࡮࡝ࡰࠣฮ๊ࠦสฯิํ๊ࠥอไ็ฬสสัࠦแ๋ࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡๆ่ำฮࠦหๅษฮ๎๋๊้ࠦ็่่ࠣ๐ࠠหีอ฻๏฿ࠠศๆ฼์ิฯࠠฦๆํ๋ฬࠦศะ๊้ࠤ฾๋ไࠡสะฯࠥาฯ๋ัࠪ⋏"))
		if action==l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⋐") and l1llllll1ll_l1_: l1lllllllll_l1_ = l1llllll1ll_l1_
		else: l1lllllllll_l1_ = l1lllllll11_l1_
	if action!=l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⋑"):
		for type,name,url,mode,image,page,text,context,infodict in l1lllllllll_l1_:
			if action in [l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⋒"),l1l11l_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⋓")] and l1l11l_l1_ (u"ࠬ฻แฮหࠪ⋔") in name and type==l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋕"): continue
			addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return
def l1111111l1_l1_(search_org=l1l11l_l1_ (u"ࠧࠨ⋖")):
	search,options,showdialogs = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⋗"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡙ࠥࡥࡢࡴࡦ࡬ࠥࡌ࡯ࡳ࠼ࠣ࡟ࠥ࠭⋘")+search+l1l11l_l1_ (u"ࠪࠤࡢ࠭⋙"))
	l1l1ll_l1_ = search+options
	l111111ll1_l1_,l11l111111_l1_ = l1l11l_l1_ (u"ࠫࠬ⋚"),l1l11l_l1_ (u"ࠬࠦ࠭ࠡࠩ⋛")+search
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⋜"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⋝"),l1l11l_l1_ (u"ࠨࠩ⋞"),157)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋟"),l1l11l_l1_ (u"ࠪࡣࡎࡖࡔࡠࠩ⋠")+l111111ll1_l1_+l1l11l_l1_ (u"ࠫอำหࠡࡋࡓࡘ࡛࠭⋡")+l11l111111_l1_,l1l11l_l1_ (u"ࠬ࠭⋢"),239,l1l11l_l1_ (u"࠭ࠧ⋣"),l1l11l_l1_ (u"ࠧࠨ⋤"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋥"),l1l11l_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨ⋦")+l111111ll1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥฮใาษࠪ⋧")+l11l111111_l1_,l1l11l_l1_ (u"ࠫࠬ⋨"),379,l1l11l_l1_ (u"ࠬ࠭⋩"),l1l11l_l1_ (u"࠭ࠧ⋪"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋫"),l1l11l_l1_ (u"ࠨࡡࡎࡐࡆࡥࠧ⋬")+l111111ll1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭⋭")+l11l111111_l1_,l1l11l_l1_ (u"ࠪࠫ⋮"),19,l1l11l_l1_ (u"ࠫࠬ⋯"),l1l11l_l1_ (u"ࠬ࠭⋰"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋱"),l1l11l_l1_ (u"ࠧࡠࡍࡕࡆࡤ࠭⋲")+l111111ll1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨ⋳")+l11l111111_l1_,l1l11l_l1_ (u"ࠩࠪ⋴"),329,l1l11l_l1_ (u"ࠪࠫ⋵"),l1l11l_l1_ (u"ࠫࠬ⋶"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⋷"),l1l11l_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬ⋸")+l111111ll1_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠬ⋹")+l11l111111_l1_,l1l11l_l1_ (u"ࠨࠩ⋺"),129,l1l11l_l1_ (u"ࠩࠪ⋻"),l1l11l_l1_ (u"ࠪࠫ⋼"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋽"),l1l11l_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ⋾")+l111111ll1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧ⋿")+l11l111111_l1_,l1l11l_l1_ (u"ࠧࠨ⌀"),29,l1l11l_l1_ (u"ࠨࠩ⌁"),l1l11l_l1_ (u"ࠩࠪ⌂"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌃"),l1l11l_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪ⌄")+l111111ll1_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭⌅")+l11l111111_l1_,l1l11l_l1_ (u"࠭ࠧ⌆"),249,l1l11l_l1_ (u"ࠧࠨ⌇"),l1l11l_l1_ (u"ࠨࠩ⌈"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌉"),l1l11l_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ⌊")+l111111ll1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨ⌋")+l11l111111_l1_,l1l11l_l1_ (u"ࠬ࠭⌌"),59,l1l11l_l1_ (u"࠭ࠧ⌍"),l1l11l_l1_ (u"ࠧࠨ⌎"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌏"),l1l11l_l1_ (u"ࠩࡢࡊ࡙ࡓ࡟ࠨ⌐")+l111111ll1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭⌑")+l11l111111_l1_,l1l11l_l1_ (u"ࠫࠬ⌒"),69,l1l11l_l1_ (u"ࠬ࠭⌓"),l1l11l_l1_ (u"࠭ࠧ⌔"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌕"),l1l11l_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ⌖")+l111111ll1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤออๆ๋ฬࠪ⌗")+l11l111111_l1_,l1l11l_l1_ (u"ࠪࠫ⌘"),39,l1l11l_l1_ (u"ࠫࠬ⌙"),l1l11l_l1_ (u"ࠬ࠭⌚"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⌛"),l1l11l_l1_ (u"ࠧࡠࡍ࡚ࡘࡤ࠭⌜")+l11l111111_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็็ํััࠨ⌝"),l1l11l_l1_ (u"ࠩࠪ⌞"),139,l1l11l_l1_ (u"ࠪࠫ⌟"),l1l11l_l1_ (u"ࠫࠬ⌠"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⌡"),l1l11l_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬ⌢")+l11l111111_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭⌣"),l1l11l_l1_ (u"ࠨࠩ⌤"),319,l1l11l_l1_ (u"ࠩࠪ⌥"),l1l11l_l1_ (u"ࠪࠫ⌦"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌧"),l1l11l_l1_ (u"ࠬࡥࡍࡓࡈࠪ⌨")+l11l111111_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧ〈"),l1l11l_l1_ (u"ࠧࠨ〉"),49,l1l11l_l1_ (u"ࠨࠩ⌫"),l1l11l_l1_ (u"ࠩࠪ⌬"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌭"),l1l11l_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪ⌮")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬ⌯"),l1l11l_l1_ (u"࠭ࠧ⌰"),39,l1l11l_l1_ (u"ࠧࠨ⌱"),l1l11l_l1_ (u"ࠨࠩ⌲"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧ⌳"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌴"),l1l11l_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪ⌵")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧ⌶"),l1l11l_l1_ (u"࠭ࠧ⌷"),39,l1l11l_l1_ (u"ࠧࠨ⌸"),l1l11l_l1_ (u"ࠨࠩ⌹"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘࡥࠧ⌺"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌻"),l1l11l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ⌼")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩ⌽"),l1l11l_l1_ (u"࠭ࠧ⌾"),149,l1l11l_l1_ (u"ࠧࠨ⌿"),l1l11l_l1_ (u"ࠨࠩ⍀"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ⍁"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍂"),l1l11l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ⍃")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭⍄"),l1l11l_l1_ (u"࠭ࠧ⍅"),149,l1l11l_l1_ (u"ࠧࠨ⍆"),l1l11l_l1_ (u"ࠨࠩ⍇"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ⍈"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍉"),l1l11l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ⍊")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭⍋"),l1l11l_l1_ (u"࠭ࠧ⍌"),149,l1l11l_l1_ (u"ࠧࠨ⍍"),l1l11l_l1_ (u"ࠨࠩ⍎"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫ⍏"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍐"),l1l11l_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ⍑")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠใ่สอࠥศ๊ࠡใํู่๊ࠦาสํࠫ⍒"),l1l11l_l1_ (u"࠭ࠧ⍓"),29,l1l11l_l1_ (u"ࠧࠨ⍔"),l1l11l_l1_ (u"ࠨࠩ⍕"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈࡥࠧ⍖"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍗"),l1l11l_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ⍘")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧ⍙"),l1l11l_l1_ (u"࠭ࠧ⍚"),29,l1l11l_l1_ (u"ࠧࠨ⍛"),l1l11l_l1_ (u"ࠨࠩ⍜"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎ࡟ࠨ⍝"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍞"),l1l11l_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪ⍟")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠣๅ๏ี๊้้สฮࠬ⍠"),l1l11l_l1_ (u"࠭ࠧ⍡"),409,l1l11l_l1_ (u"ࠧࠨ⍢"),l1l11l_l1_ (u"ࠨࠩ⍣"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࡤ࠭⍤"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍥"),l1l11l_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪ⍦")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆํอฦๆࠩ⍧"),l1l11l_l1_ (u"࠭ࠧ⍨"),409,l1l11l_l1_ (u"ࠧࠨ⍩"),l1l11l_l1_ (u"ࠨࠩ⍪"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ⍫"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍬"),l1l11l_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪ⍭")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆ๋๎วหࠩ⍮"),l1l11l_l1_ (u"࠭ࠧ⍯"),409,l1l11l_l1_ (u"ࠧࠨ⍰"),l1l11l_l1_ (u"ࠨࠩ⍱"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ⍲"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍳"),l1l11l_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪ⍴")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩ⍵"),l1l11l_l1_ (u"࠭ࠧ⍶"),319,l1l11l_l1_ (u"ࠧࠨ⍷"),l1l11l_l1_ (u"ࠨࠩ⍸"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࡣࠬ⍹"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍺"),l1l11l_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪ⍻")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ๊าไะࠩ⍼"),l1l11l_l1_ (u"࠭ࠧ⍽"),319,l1l11l_l1_ (u"ࠧࠨ⍾"),l1l11l_l1_ (u"ࠨࠩ⍿"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࡢࠫ⎀"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎁"),l1l11l_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪ⎂")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫ⎃"),l1l11l_l1_ (u"࠭ࠧ⎄"),319,l1l11l_l1_ (u"ࠧࠨ⎅"),l1l11l_l1_ (u"ࠨࠩ⎆"),l1l1ll_l1_+l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ⎇"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⎈"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤํ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⎉"),l1l11l_l1_ (u"ࠬ࠭⎊"),157)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎋"),l1l11l_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭⎌")+l111111ll1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅัืࠠี๊ࠪ⎍")+l11l111111_l1_,l1l11l_l1_ (u"ࠩࠪ⎎"),399,l1l11l_l1_ (u"ࠪࠫ⎏"),l1l11l_l1_ (u"ࠫࠬ⎐"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎑"),l1l11l_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ⎒")+l111111ll1_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫ⎓")+l11l111111_l1_,l1l11l_l1_ (u"ࠨࠩ⎔"),469,l1l11l_l1_ (u"ࠩࠪ⎕"),l1l11l_l1_ (u"ࠪࠫ⎖"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎗"),l1l11l_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫ⎘")+l111111ll1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๆ๋ำ๏ࠦๆหࠩ⎙")+l11l111111_l1_,l1l11l_l1_ (u"ࠧࠨ⎚"),459,l1l11l_l1_ (u"ࠨࠩ⎛"),l1l11l_l1_ (u"ࠩࠪ⎜"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎝"),l1l11l_l1_ (u"ࠫࡤࡉࡍࡏࡡࠪ⎞")+l111111ll1_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ์ว้ࠩ⎟")+l11l111111_l1_,l1l11l_l1_ (u"࠭ࠧ⎠"),309,l1l11l_l1_ (u"ࠧࠨ⎡"),l1l11l_l1_ (u"ࠨࠩ⎢"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎣"),l1l11l_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ⎤")+l111111ll1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾่๋ࠦࠢึ๎๊อࠧ⎥")+l11l111111_l1_,l1l11l_l1_ (u"ࠬ࠭⎦"),579,l1l11l_l1_ (u"࠭ࠧ⎧"),l1l11l_l1_ (u"ࠧࠨ⎨"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎩"),l1l11l_l1_ (u"ࠩࡢࡑࡈࡓ࡟ࠨ⎪")+l111111ll1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧ⎫")+l11l111111_l1_,l1l11l_l1_ (u"ࠫࠬ⎬"),369,l1l11l_l1_ (u"ࠬ࠭⎭"),l1l11l_l1_ (u"࠭ࠧ⎮"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎯"),l1l11l_l1_ (u"ࠨࡡࡖࡌࡕࡥࠧ⎰")+l111111ll1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แࠡสิ์ࠬ⎱")+l11l111111_l1_,l1l11l_l1_ (u"ࠪࠫ⎲"),489,l1l11l_l1_ (u"ࠫࠬ⎳"),l1l11l_l1_ (u"ࠬ࠭⎴"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎵"),l1l11l_l1_ (u"ࠧࡠࡃࡕࡗࡤ࠭⎶")+l111111ll1_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ฽ึฮࠠิ์ํำࠬ⎷")+l11l111111_l1_,l1l11l_l1_ (u"ࠩࠪ⎸"),259,l1l11l_l1_ (u"ࠪࠫ⎹"),l1l11l_l1_ (u"ࠫࠬ⎺"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎻"),l1l11l_l1_ (u"࠭࡟ࡄ࠶ࡘࡣࠬ⎼")+l111111ll1_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭⎽")+l11l111111_l1_,l1l11l_l1_ (u"ࠨࠩ⎾"),429,l1l11l_l1_ (u"ࠩࠪ⎿"),l1l11l_l1_ (u"ࠪࠫ⏀"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏁"),l1l11l_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫ⏂")+l111111ll1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦแ้ำํ์ࠬ⏃")+l11l111111_l1_,l1l11l_l1_ (u"ࠧࠨ⏄"),119,l1l11l_l1_ (u"ࠨࠩ⏅"),l1l11l_l1_ (u"ࠩࠪ⏆"),l1l1ll_l1_+l1l11l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ⏇"))
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏈"),l1l11l_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫ⏉")+l111111ll1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ⏊")+l11l111111_l1_,l1l11l_l1_ (u"ࠧࠨ⏋"),79,l1l11l_l1_ (u"ࠨࠩ⏌"),l1l11l_l1_ (u"ࠩࠪ⏍"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏎"),l1l11l_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ⏏")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ⏐"),l1l11l_l1_ (u"࠭ࠧ⏑"),389,l1l11l_l1_ (u"ࠧࠨ⏒"),l1l11l_l1_ (u"ࠨࠩ⏓"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏔"),l1l11l_l1_ (u"ࠪࡣࡊࡍࡖࡠࠩ⏕")+l11l111111_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦล๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭⏖"),l1l11l_l1_ (u"ࠬ࠭⏗"),229,l1l11l_l1_ (u"࠭ࠧ⏘"),l1l11l_l1_ (u"ࠧࠨ⏙"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⏚"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⏛"),l1l11l_l1_ (u"ࠪࠫ⏜"),157)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏝"),l1l11l_l1_ (u"ࠬࡥࡈࡍࡅࡢࠫ⏞")+l111111ll1_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่้ࠡ็หู๊ࠥๆษࠪ⏟")+l11l111111_l1_,l1l11l_l1_ (u"ࠧࠨ⏠"),89,l1l11l_l1_ (u"ࠨࠩ⏡"),l1l11l_l1_ (u"ࠩࠪ⏢"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏣"),l1l11l_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ⏤")+l111111ll1_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩ⏥")+l11l111111_l1_,l1l11l_l1_ (u"࠭ࠧ⏦"),439,l1l11l_l1_ (u"ࠧࠨ⏧"),l1l11l_l1_ (u"ࠨࠩ⏨"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏩"),l1l11l_l1_ (u"ࠪࡣࡈࡓࡆࡠࠩ⏪")+l111111ll1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ⏫")+l11l111111_l1_,l1l11l_l1_ (u"ࠬ࠭⏬"),99,l1l11l_l1_ (u"࠭ࠧ⏭"),l1l11l_l1_ (u"ࠧࠨ⏮"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏯"),l1l11l_l1_ (u"ࠩࡢࡇࡒࡒ࡟ࠨ⏰")+l111111ll1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨ⏱")+l11l111111_l1_,l1l11l_l1_ (u"ࠫࠬ⏲"),479,l1l11l_l1_ (u"ࠬ࠭⏳"),l1l11l_l1_ (u"࠭ࠧ⏴"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏵"),l1l11l_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧ⏶")+l111111ll1_l1_+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧ⏷")+l11l111111_l1_,l1l11l_l1_ (u"ࠪࠫ⏸"),559,l1l11l_l1_ (u"ࠫࠬ⏹"),l1l11l_l1_ (u"ࠬ࠭⏺"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏻"),l1l11l_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭⏼")+l11l111111_l1_+l1l11l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊ࠡัํำࠬ⏽"),l1l11l_l1_ (u"ࠩࠪ⏾"),449,l1l11l_l1_ (u"ࠪࠫ⏿"),l1l11l_l1_ (u"ࠫࠬ␀"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ␁"),l1l11l_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬ␂")+l11l111111_l1_+l1l11l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส็ํอๅࠡๅส้ࠬ␃"),l1l11l_l1_ (u"ࠨࠩ␄"),359,l1l11l_l1_ (u"ࠩࠪ␅"),l1l11l_l1_ (u"ࠪࠫ␆"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␇"),l1l11l_l1_ (u"ࠬࡥࡃࡎࡅࡢࠫ␈")+l11l111111_l1_+l1l11l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫ␉"),l1l11l_l1_ (u"ࠧࠨ␊"),499,l1l11l_l1_ (u"ࠨࠩ␋"),l1l11l_l1_ (u"ࠩࠪ␌"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␍"),l1l11l_l1_ (u"ࠫࡤࡇࡒࡍࡡࠪ␎")+l11l111111_l1_+l1l11l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ฺࠠำหࠤ้๐่็ิࠪ␏"),l1l11l_l1_ (u"࠭ࠧ␐"),209,l1l11l_l1_ (u"ࠧࠨ␑"),l1l11l_l1_ (u"ࠨࠩ␒"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␓"),l1l11l_l1_ (u"ࠪࡣࡍࡋࡌࡠࠩ␔")+l11l111111_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫ␕"),l1l11l_l1_ (u"ࠬ࠭␖"),99,l1l11l_l1_ (u"࠭ࠧ␗"),l1l11l_l1_ (u"ࠧࠨ␘"),l1l1ll_l1_)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␙"),l1l11l_l1_ (u"ࠩࡢࡗࡋ࡝࡟ࠨ␚")+search+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥา์ึࠤๆ๎ั๊ࠡอุࠬ␛"),l1l11l_l1_ (u"ࠫࠬ␜"),218,l1l11l_l1_ (u"ࠬ࠭␝"),l1l11l_l1_ (u"࠭ࠧ␞"),search) # 219
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␟"),l1l11l_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧ␠")+search+l1l11l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ␡"),l1l11l_l1_ (u"ࠪࠫ␢"),188,l1l11l_l1_ (u"ࠫࠬ␣"),l1l11l_l1_ (u"ࠬ࠭␤"),search)# 189
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ␥"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ␦"),l1l11l_l1_ (u"ࠨࠩ␧"),157)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␨"),l1l11l_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ␩")+l111111ll1_l1_+l1l11l_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อ࠭␪")+l11l111111_l1_,l1l11l_l1_ (u"ࠬ࠭␫"),149,l1l11l_l1_ (u"࠭ࠧ␬"),l1l11l_l1_ (u"ࠧࠨ␭"),l1l1ll_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␮"),l1l11l_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨ␯")+l111111ll1_l1_+l1l11l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠨ␰")+l11l111111_l1_,l1l11l_l1_ (u"ࠫࠬ␱"),409,l1l11l_l1_ (u"ࠬ࠭␲"),l1l11l_l1_ (u"࠭ࠧ␳"),l1l1ll_l1_)
	return
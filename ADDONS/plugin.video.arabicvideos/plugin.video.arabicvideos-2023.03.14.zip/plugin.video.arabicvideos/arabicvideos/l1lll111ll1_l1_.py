﻿# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
#import unicodedata,simplejson
def MAIN(mode,l1lll11ll1l_l1_):
	if l1lll11ll1l_l1_==l1l11l_l1_ (u"ࠫࠬ⚠"): return
	if mode==1:
		l1lll11ll11_l1_ = xbmcgui.l1lll11l1ll_l1_()
		l1lll11l1l1_l1_ = xbmcgui.l1lll1111l1_l1_(l1lll11ll11_l1_)
		l1lll11ll1l_l1_ = l1lll11lll1_l1_(l1lll11ll1l_l1_)
		l1lll11l1l1_l1_.getControl(311).l1lll11llll_l1_(l1lll11ll1l_l1_)
	if mode==0:
		#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭⚡"))
		#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ⚢"))
		#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚣"))
		l1lll111l11_l1_=l1l11l_l1_ (u"ࠨ࡚ࠪ⚤")
		if kodi_version>18.99: check = isinstance(l1lll11ll1l_l1_,str)
		else: check = isinstance(l1lll11ll1l_l1_,unicode)
		if check==True: l1lll111l11_l1_=l1l11l_l1_ (u"ࠩࡘࠫ⚥")
		l1lll1111ll_l1_=str(type(l1lll11ll1l_l1_))+l1l11l_l1_ (u"ࠪࠤࠬ⚦")+l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠫࠥ࠭⚧")+l1lll111l11_l1_+l1l11l_l1_ (u"ࠬࠦࠧ⚨")
		for i in range(0,len(l1lll11ll1l_l1_),1):
			l1lll1111ll_l1_ += hex(ord(l1lll11ll1l_l1_[i])).replace(l1l11l_l1_ (u"࠭࠰ࡹࠩ⚩"),l1l11l_l1_ (u"ࠧࠨ⚪"))+l1l11l_l1_ (u"ࠨࠢࠪ⚫")
		l1lll11ll1l_l1_ = l1lll11lll1_l1_(l1lll11ll1l_l1_)
		#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚬"))
		l1lll111l11_l1_=l1l11l_l1_ (u"ࠪ࡜ࠬ⚭")
		if kodi_version>18.99: check = isinstance(l1lll11ll1l_l1_, str)
		else: check = isinstance(l1lll11ll1l_l1_, unicode)
		if check==True: l1lll111l11_l1_=l1l11l_l1_ (u"࡚ࠫ࠭⚮")
		l1lll111l1l_l1_=str(type(l1lll11ll1l_l1_))+l1l11l_l1_ (u"ࠬࠦࠧ⚯")+l1lll11ll1l_l1_+l1l11l_l1_ (u"࠭ࠠࠨ⚰")+l1lll111l11_l1_+l1l11l_l1_ (u"ࠧࠡࠩ⚱")
		for i in range(0,len(l1lll11ll1l_l1_),1):
			l1lll111l1l_l1_ += hex(ord(l1lll11ll1l_l1_[i])).replace(l1l11l_l1_ (u"ࠨ࠲ࡻࠫ⚲"),l1l11l_l1_ (u"ࠩࠪ⚳"))+l1l11l_l1_ (u"ࠪࠤࠬ⚴")
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⚵"),l1l11l_l1_ (u"ࠬ࠭⚶"),l1lll1111ll_l1_,l1lll111l1l_l1_)
	return
	#for i in range(0,len(l1lll11ll1l_l1_)-2,3):
	#	string=hex(ord(l1lll11ll1l_l1_[i+0]))+l1l11l_l1_ (u"࠭ࠠࠡࠩ⚷")+hex(ord(l1lll11ll1l_l1_[i+1]))+l1l11l_l1_ (u"ࠧࠡࠢࠪ⚸")+hex(ord(l1lll11ll1l_l1_[i+2]))
	#	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⚹"),l1l11l_l1_ (u"ࠩࠪ⚺"),l1l11l_l1_ (u"ࠪࠫ⚻"),string)
	#return
	#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚼"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⚽"),l1l11l_l1_ (u"࠭ࠧ⚾"),l1l11l_l1_ (u"ࠧࠨ⚿"),l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1lll11lll1_l1_(l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⛀"))
	#l1lll11ll1l_l1_ = unicodedata.normalize(l1l11l_l1_ (u"ࠩࡑࡊࡐࡊࠧ⛁"),l1lll11ll1l_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⛂"),l1l11l_l1_ (u"ࠫࠬ⛃"),l1l11l_l1_ (u"ࠬ࠭⛄"),   hex(  unicodedata.combining(l1lll11ll1l_l1_[0])  )   )
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⛅"),l1l11l_l1_ (u"ࠧࠨ⛆"),l1lll11ll1l_l1_,   hex(ord(  l1lll11ll1l_l1_[0]  ))   )
	#new = l1l11l_l1_ (u"ࠨࠩ⛇")
	#for l1lll111lll_l1_ in l1lll11ll1l_l1_:
	#	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ⛈"),l1l11l_l1_ (u"ࠪࠫ⛉"),l1l11l_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ⛊"),unicodedata.decomposition(l1lll111lll_l1_) )
	#	new += l1l11l_l1_ (u"ࠬࡢࡵ࠱ࠩ⛋") + hex(ord(l1lll111lll_l1_)).replace(l1l11l_l1_ (u"࠭࠰ࡹࠩ⛌"),l1l11l_l1_ (u"ࠧࠨ⛍"))
	#l1lll11ll1l_l1_ = new
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⛎"),l1l11l_l1_ (u"ࠩࠪ⛏"),l1l11l_l1_ (u"ࠪࠫ⛐"),l1lll11ll1l_l1_)
	#new = l1l11l_l1_ (u"ࠫࠬ⛑")
	#for i in range(len(l1lll11ll1l_l1_)-6,-5,-6):
	#	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⛒"),l1l11l_l1_ (u"࠭ࠧ⛓"),l1l11l_l1_ (u"ࠧࠨ⛔"),str(i))
	#	new += l1lll11ll1l_l1_[i] + l1lll11ll1l_l1_[i+1] + l1lll11ll1l_l1_[i+2] + l1lll11ll1l_l1_[i+3] + l1lll11ll1l_l1_[i+4] + l1lll11ll1l_l1_[i+5]
	#l1lll11ll1l_l1_ = new
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⛕"),l1l11l_l1_ (u"ࠩࠪ⛖"),l1l11l_l1_ (u"ࠪࠫ⛗"),l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ⛘"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⛙"),l1l11l_l1_ (u"࠭ࠧ⛚"),l1l11l_l1_ (u"ࠧࠨ⛛"),l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⛜"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ⛝"),l1l11l_l1_ (u"ࠪࠫ⛞"),l1l11l_l1_ (u"ࠫࠬ⛟"),l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1l11l_l1_ (u"ࠬ࡫࡭ࡢࡦࠪ⛠")
	#l1lll11l111_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠬ⛡")+l1lll11ll1l_l1_+l1l11l_l1_ (u"ࠧࠣ࠮ࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪ⛢"))
	#simplejson.loads(l1lll11l111_l1_)
	#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⛣"))
	#new = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ⛤"))
	#l1lll11ll1l_l1_ = new
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⛥"),l1l11l_l1_ (u"ࠫࠬ⛦"),l1l11l_l1_ (u"ࠬ࠭⛧"),l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1lll11lll1_l1_(l1lll11ll1l_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⛨"),l1l11l_l1_ (u"ࠧࠨ⛩"),l1l11l_l1_ (u"ࠨࠩ⛪"),l1lll11ll1l_l1_)
	#new = l1l11l_l1_ (u"ࠩࠪ⛫")
	#for i in range(len(l1lll11ll1l_l1_)-2,-1,-2):
	#	new += l1lll11ll1l_l1_[i] + l1lll11ll1l_l1_[i+1]
	#l1lll11ll1l_l1_ = new
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⛬"),l1l11l_l1_ (u"ࠫࠬ⛭"),l1l11l_l1_ (u"ࠬ࠭⛮"),l1lll11ll1l_l1_)
	#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⛯"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ⛰"),l1l11l_l1_ (u"ࠨࠩ⛱"),l1l11l_l1_ (u"ࠩࠪ⛲"),l1lll11ll1l_l1_)
	#new = l1l11l_l1_ (u"ࠪࠫ⛳")
	#for i in range(len(l1lll11ll1l_l1_)-2,-1,-2):
	#	new += l1lll11ll1l_l1_[i] + l1lll11ll1l_l1_[i+1]
	#l1lll11ll1l_l1_ = new
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⛴"),l1l11l_l1_ (u"ࠬ࠭⛵"),l1l11l_l1_ (u"࠭ࠧ⛶"),l1lll11ll1l_l1_)
		#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.replace(l1l11l_l1_ (u"ࠧࠡࠩ⛷"),l1l11l_l1_ (u"ࠨࠩ⛸"))
		#new = l1l11l_l1_ (u"ࠩࠪ⛹")
		#for i in range(len(l1lll11ll1l_l1_)-3,-2,-3):
		#	new += l1lll11ll1l_l1_[i] + l1lll11ll1l_l1_[i+1] + l1lll11ll1l_l1_[i+2]
		#l1lll11ll1l_l1_ = new
		#new = l1l11l_l1_ (u"ࠪࠫ⛺")
		#for i in range(len(l1lll11ll1l_l1_)-2,-1,-2):
		#	new += l1lll11ll1l_l1_[i] + l1lll11ll1l_l1_[i+1]
		#l1lll11ll1l_l1_ = new
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⛻"),l1l11l_l1_ (u"ࠬ࠭⛼"),l1l11l_l1_ (u"࠭ࠧ⛽"),l1lll11ll1l_l1_)
		#l1lll11ll1l_l1_ = l1lll11ll1l_l1_.l1lll11l11l_l1_(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⛾"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⛿"),l1l11l_l1_ (u"ࠩࠪ✀"),str(ord(l1lll11ll1l_l1_[0]))+l1l11l_l1_ (u"ࠪࠤࠬ✁")+str(ord(l1lll11ll1l_l1_[1]))+l1l11l_l1_ (u"ࠫࠥ࠭✂")+str(ord(l1lll11ll1l_l1_[2])),str(len(l1lll11ll1l_l1_)))
		#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭✃"),l1l11l_l1_ (u"࠭ࠧ✄"),l1l11l_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠠࡍࡧࡷࡸࡪࡸࡳࠨ✅"),l1lll11ll1l_l1_)
		#new = l1l11l_l1_ (u"ࠨࠩ✆")
		#for i in range(len(l1lll11ll1l_l1_)-2,-1,-2):
		#	new += l1lll11ll1l_l1_[i] + l1lll11ll1l_l1_[i+1]
		#l1lll11ll1l_l1_ = new
		#new = l1lll11ll1l_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ✇"))
		#new = new.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✈"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ✉"),l1l11l_l1_ (u"ࠬ࠭✊"),l1l11l_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭✋"),new )
		#l1lll1111ll_l1_ = l1l11l_l1_ (u"ࠧࠨ✌")
		#for l1lll111lll_l1_ in new:
		#	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ✍"),l1l11l_l1_ (u"ࠩࠪ✎"),l1l11l_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ✏"),unicodedata.decomposition(l1lll111lll_l1_) )
		#	l1lll1111ll_l1_ += l1l11l_l1_ (u"ࠫࡡࡻࠧ✐") + hex(ord(l1lll111lll_l1_)).replace(l1l11l_l1_ (u"ࠬࡾࠧ✑"),l1l11l_l1_ (u"࠭ࠧ✒"))
		#l1lll1111ll_l1_ = l1lll1111ll_l1_.decode(l1l11l_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ✓"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ✔"),l1l11l_l1_ (u"ࠩࠪ✕"),l1l11l_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ✖"),l1lll1111ll_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1lll11lll1_l1_(new)
		#l1lll11ll1l_l1_ = new.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✗"))
		#new = new.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✘")) #.decode(l1l11l_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ✙"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ✚"),l1l11l_l1_ (u"ࠨࠩ✛"),l1l11l_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ✜"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✝")))   )
		#l1lll11ll1l_l1_ = l1lll11lll1_l1_(new)
		#l1lll11ll1l_l1_ = l1lll11lll1_l1_(l1lll11ll1l_l1_)
		#method=l1l11l_l1_ (u"ࠦࡎࡴࡰࡶࡶ࠱ࡗࡪࡴࡤࡕࡧࡻࡸࠧ✞")
		#params=l1l11l_l1_ (u"ࠬࢁࠢࡵࡧࡻࡸࠧࡀࠢࠦࡵࠥ࠰ࠥࠨࡤࡰࡰࡨࠦ࠿࡬ࡡ࡭ࡵࡨࢁࠬ✟") % l1lll11ll1l_l1_
		#l1lll11l111_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠤࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠠࠣࠧࡶࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࠢࠨࡷ࠱ࠦࠢࡪࡦࠥ࠾ࠥ࠷ࡽࠨ✠") % (method, params))
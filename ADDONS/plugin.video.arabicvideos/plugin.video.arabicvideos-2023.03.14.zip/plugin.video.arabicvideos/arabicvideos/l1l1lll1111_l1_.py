# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ䚒")
menu_name = l1l11l_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭䚓")
l11lll_l1_ = WEBSITES[script_name][0]
headers = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䚔"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l111l1_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l11ll1ll11ll_l1_(url)
	elif mode==314: results = l11l1l1l_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䚕"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䚖"),l1l11l_l1_ (u"ࠫࠬ䚗"),319,l1l11l_l1_ (u"ࠬ࠭䚘"),l1l11l_l1_ (u"࠭ࠧ䚙"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䚚"))
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䚛"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠧ䚜"),l1l11l_l1_ (u"ࠪࠫ䚝"),114,l11lll_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䚞"),l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭䚟"),l1l11l_l1_ (u"࠭ࠧ䚠"),l1l11l_l1_ (u"ࠧࠨ䚡"),l1l11l_l1_ (u"ࠨࠩ䚢"),l1l11l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䚣"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࡱ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䚤"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䚥"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䚦"),l1l11l_l1_ (u"࠭ࠧ䚧"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠻࠾ࠨ䚨"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l11l_l1_ (u"ࠨࠢࠪ䚩"))
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䚪"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䚫")+menu_name+title,l11lll_l1_,314,l1l11l_l1_ (u"ࠫࠬ䚬"),l1l11l_l1_ (u"ࠬ࠭䚭"),str(seq+1))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䚮"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䚯")+menu_name+l1l11l_l1_ (u"ࠨ็ๅห฼฿ࠠี้ิࠫ䚰"),l11lll_l1_,314,l1l11l_l1_ (u"ࠩࠪ䚱"),l1l11l_l1_ (u"ࠪࠫ䚲"),l1l11l_l1_ (u"ࠫ࠵࠭䚳"))
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䚴"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䚵"),l1l11l_l1_ (u"ࠧࠨ䚶"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡆࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡈ࠾ࠨ䚷"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ䚸")+l1111l_l1_
		#title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䚹"))
		#url = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡆ࡭ࡲࡧࡎࡰࡹ࠲ࡍࡳࡺࡥࡳࡨࡤࡧࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠴ࡰࡩࡲࠪ䚺")
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䚻"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ䚼")+menu_name+title,l1111l_l1_,311)
	return html
def l11l1l1l_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䚽"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ䚾"),l1l11l_l1_ (u"ࠩࠪ䚿"),l1l11l_l1_ (u"ࠪࠫ䛀"),l1l11l_l1_ (u"ࠫࠬ䛁"),l1l11l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ䛂"))
	html = response.content
	if seq==l1l11l_l1_ (u"࠭࠰ࠨ䛃"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ䛄"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䛅"),block,re.DOTALL)
		for l1111l_l1_,name,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ䛆")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䛇"))
			name = name.strip(l1l11l_l1_ (u"ࠫࠥ࠭䛈"))
			title = title+l1l11l_l1_ (u"ࠬࠦࠨࠨ䛉")+name+l1l11l_l1_ (u"࠭ࠩࠨ䛊")
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䛋"),menu_name+title,l1111l_l1_,312)
	elif seq in [l1l11l_l1_ (u"ࠨ࠳ࠪ䛌"),l1l11l_l1_ (u"ࠩ࠵ࠫ䛍"),l1l11l_l1_ (u"ࠪ࠷ࠬ䛎")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡮ࡪࠫ䛏"),html,re.DOTALL)
		l11ll1ll11l1_l1_ = int(seq)-1
		block = l1ll111_l1_[l11ll1ll11l1_l1_]
		if seq==l1l11l_l1_ (u"ࠬ࠷ࠧ䛐"): items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䛑"),block,re.DOTALL)
		else: items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䛒"),block,re.DOTALL)
		for l1111l_l1_,img,title,name in items:
			img = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࠪ䛓")+img
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ䛔")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䛕"))
			name = name.strip(l1l11l_l1_ (u"ࠫࠥ࠭䛖"))
			title = title+l1l11l_l1_ (u"ࠬࠦࠨࠨ䛗")+name+l1l11l_l1_ (u"࠭ࠩࠨ䛘")
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䛙"),menu_name+title,l1111l_l1_,311,img)
	elif seq in [l1l11l_l1_ (u"ࠨ࠶ࠪ䛚"),l1l11l_l1_ (u"ࠩ࠸ࠫ䛛"),l1l11l_l1_ (u"ࠪ࠺ࠬ䛜")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ䛝"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1ll111_l1_[seq]
		items = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀ࠯ࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䛞"),block,re.DOTALL)
		for img,l1111l_l1_,l1lll1l1ll1_l1_,title,name2 in items:
			img = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࠨ䛟")+img
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩ䛠")+l1111l_l1_
			title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ䛡"))
			l1lll1l1ll1_l1_ = l1lll1l1ll1_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫ䛢"))
			name2 = name2.strip(l1l11l_l1_ (u"ࠪࠤࠬ䛣"))
			if l1lll1l1ll1_l1_: name = l1lll1l1ll1_l1_
			else: name = name2
			title = title+l1l11l_l1_ (u"ࠫࠥ࠮ࠧ䛤")+name+l1l11l_l1_ (u"ࠬ࠯ࠧ䛥")
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䛦"),menu_name+title,l1111l_l1_,312,img)
	return
def l111l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䛧"),url,l1l11l_l1_ (u"ࠨࠩ䛨"),l1l11l_l1_ (u"ࠩࠪ䛩"),l1l11l_l1_ (u"ࠪࠫ䛪"),l1l11l_l1_ (u"ࠫࠬ䛫"),l1l11l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ䛬"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡣࡱࡻ࠱࡭࡫ࡡࡥ࡫ࡱ࡫ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡱࡵࡡࡵ࠯ࡵ࡭࡬࡮ࡴࠨ䛭"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	if l1l11l_l1_ (u"ࠧࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠧ䛮") in block:
		items = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䛯"),block,re.DOTALL)
		if items:
			for img,l1111l_l1_,title,count in items:
				img = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫ䛰")+img
				l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࠬ䛱")+l1111l_l1_
				count = count.replace(l1l11l_l1_ (u"ࠫࠥอไึ๊อ๎ฮࡀࠠࠨ䛲"),l1l11l_l1_ (u"ࠬࡀࠧ䛳"))
				title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨ䛴"))
				title = title+l1l11l_l1_ (u"ࠧࠡࠪࠪ䛵")+count+l1l11l_l1_ (u"ࠨࠫࠪ䛶")
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䛷"),menu_name+title,l1111l_l1_,311,img)
	else:
		items = re.findall(l1l11l_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䛸"),block,re.DOTALL)
		for l1111l_l1_,title,l11ll1ll1l11_l1_,duration in items:
			if title==l1l11l_l1_ (u"ࠫࠬ䛹") or l11ll1ll1l11_l1_==l1l11l_l1_ (u"ࠬ࠭䛺"): continue
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࠨ䛻")+l1111l_l1_
			title = title+l1l11l_l1_ (u"ࠧࠡࠪࠪ䛼")+duration+l1l11l_l1_ (u"ࠨࠫࠪ䛽")
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䛾"),menu_name+title,l1111l_l1_,312)
	if not items: l111ll_l1_(html)
	return
def l111ll_l1_(html):
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䛿"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䜀"),block,re.DOTALL)
	for l1111l_l1_,title,name,count,duration in items:
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࠧ䜁")+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨ䜂"))
		name = name.strip(l1l11l_l1_ (u"ࠧࠡࠩ䜃"))
		title = title+l1l11l_l1_ (u"ࠨࠢࠫࠫ䜄")+name+l1l11l_l1_ (u"ࠩࠬࠫ䜅")
		addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䜆"),menu_name+title,l1111l_l1_,312,l1l11l_l1_ (u"ࠫࠬ䜇"),duration)
	return
def l11ll1ll11ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䜈"),url,l1l11l_l1_ (u"࠭ࠧ䜉"),l1l11l_l1_ (u"ࠧࠨ䜊"),l1l11l_l1_ (u"ࠨࠩ䜋"),l1l11l_l1_ (u"ࠩࠪ䜌"),l1l11l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍࡥࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ䜍"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠣࡴ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ䜎"),html,re.DOTALL)
	if not l1ll111_l1_:
		l111l1_l1_(url)
		return
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䜏"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࠨ䜐")+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩ䜑"))
		if l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠭ࠨ䜒") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䜓"),menu_name+title,l1111l_l1_,312)
		else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䜔"),menu_name+title,l1111l_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䜕"),url,l1l11l_l1_ (u"ࠬ࠭䜖"),l1l11l_l1_ (u"࠭ࠧ䜗"),l1l11l_l1_ (u"ࠧࠨ䜘"),l1l11l_l1_ (u"ࠨࠩ䜙"),l1l11l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䜚"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡦࡻࡤࡪࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䜛"),html,re.DOTALL)
	if not l1111l_l1_: l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䜜"),html,re.DOTALL)
	l1111l_l1_ = l11lll_l1_+l1111l_l1_[0]
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䜝"))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ䜞"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨ䜟"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ䜠"),l1l11l_l1_ (u"ࠩ࠮ࠫ䜡"))
	typeList = [l1l11l_l1_ (u"ࠪࠪࡹࡃࡡࠨ䜢"),l1l11l_l1_ (u"ࠫࠫࡺ࠽ࡤࠩ䜣"),l1l11l_l1_ (u"ࠬࠬࡴ࠾ࡵࠪ䜤")]
	if showdialogs:
		searchTitle = [l1l11l_l1_ (u"࠭โศำษࠫ䜥"),l1l11l_l1_ (u"ࠧฦืาหึࠦ࠯ࠡ็ฯ่ิ࠭䜦"),l1l11l_l1_ (u"ࠨ็ๅ฻฾ࠦวๅื๋ฮ๏࠭䜧")]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ࠲ࠦรฯฬิࠤฬ๊ศฮอࠪ䜨"), searchTitle)
		if selection == -1: return
	elif l1l11l_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࡠࠩ䜩") in options: selection = 0
	elif l1l11l_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩ䜪") in options: selection = 1
	elif l1l11l_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ䜫") in options: selection = 2
	else: return
	type = typeList[selection]
	url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡶࡃࠧ䜬")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䜭"),url,l1l11l_l1_ (u"ࠨࠩ䜮"),l1l11l_l1_ (u"ࠩࠪ䜯"),l1l11l_l1_ (u"ࠪࠫ䜰"),l1l11l_l1_ (u"ࠫࠬ䜱"),l1l11l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䜲"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ䜳"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		if selection in [0,1]:
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䜴"),block,re.DOTALL)
			for l1111l_l1_,img,title,name in items:
				title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ䜵"))
				name = name.strip(l1l11l_l1_ (u"ࠩࠣࠫ䜶"))
				title = title+l1l11l_l1_ (u"ࠪࠤ࠭࠭䜷")+name+l1l11l_l1_ (u"ࠫ࠮࠭䜸")
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䜹"),menu_name+title,l1111l_l1_,313,img)
		elif selection==2:
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡺࡤ࠿࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀࠬ䜺"),block,re.DOTALL)
			for l1111l_l1_,title,name in items:
				title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩ䜻"))
				name = name.strip(l1l11l_l1_ (u"ࠨࠢࠪ䜼"))
				title = title+l1l11l_l1_ (u"ࠩࠣࠬࠬ䜽")+name+l1l11l_l1_ (u"ࠪ࠭ࠬ䜾")
				addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䜿"),menu_name+title,l1111l_l1_,312)
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪက")
headers = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ခ") : l1l11l_l1_ (u"ࠪࠫဂ") }
menu_name = l1l11l_l1_ (u"ࠫࡤࡇࡒࡍࡡࠪဃ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠬ฿ัุ้ࠣห้๋ีศำ฼อࠬင"),l1l11l_l1_ (u"࠭วๅๅ็ࠫစ"),l1l11l_l1_ (u"ࠧศๆิส๏ู๊สࠩဆ"),l1l11l_l1_ (u"ࠨษ็฽ฬฮࠧဇ"),l1l11l_l1_ (u"ࠩหีฬ๋ฬࠡๅ่ฬ๏๎สาࠩဈ"),l1l11l_l1_ (u"้ࠪํฮว๋ๆࠣ์ࠥา่ศๆࠪဉ"),l1l11l_l1_ (u"ࠫฬ๊โิ็ࠣห้อำๅษ่๎ࠬည")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l111l1_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l111ll_l1_(url)
	elif mode==204: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩဋ")+text)
	elif mode==205: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ဌ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧဍ"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨဎ"),l1l11l_l1_ (u"ࠩࠪဏ"),209,l1l11l_l1_ (u"ࠪࠫတ"),l1l11l_l1_ (u"ࠫࠬထ"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩဒ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ဓ"),menu_name+l1l11l_l1_ (u"ࠧโๆอี๋ࠥอะัࠪန"),l11lll_l1_,205)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨပ"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬဖ"),l11lll_l1_,204)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨဗ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫဘ"),l1l11l_l1_ (u"ࠬ࠭မ"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ယ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫရ")+menu_name+l1l11l_l1_ (u"ࠨ็่๎ืฯࠧလ"),l11lll_l1_+l1l11l_l1_ (u"ࠩࡂࡃࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭ဝ"),201)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪသ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨဟ")+menu_name+l1l11l_l1_ (u"ࠬษแๅษ่ࠤ๊๋๊ำหࠪဠ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡱࡴࡼࡩࡦࡵࠪအ"),201)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧဢ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬဣ")+menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩဤ"),l11lll_l1_+l1l11l_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟ࡴࡧࡵ࡭ࡪࡹࠧဥ"),201)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫဦ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩဧ")+menu_name+l1l11l_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨဨ"),l11lll_l1_+l1l11l_l1_ (u"ࠧࡀࡁࡰࡥ࡮ࡴࡰࡢࡩࡨࠫဩ"),201)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬဪ"),l11lll_l1_,l1l11l_l1_ (u"ࠩࠪါ"),headers,True,l1l11l_l1_ (u"ࠪࠫာ"),l1l11l_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨိ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯ࡷࡥࡧࡹࠨ࠯ࠬࡂ࠭ࡒࡧࡩ࡯ࡔࡲࡻࠬီ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨု"),block,re.DOTALL)
		for filter,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡨࡰ࡯ࡨ࠳ࡲࡵࡲࡦࡁࡩ࡭ࡱࡺࡥࡳ࠿ࠪူ")+filter
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨေ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ဲ")+menu_name+title,l1111l_l1_,201)
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨဳ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫဴ"),l1l11l_l1_ (u"ࠬ࠭ဵ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬံ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽့ࠩ"),block,re.DOTALL)
	#l11llll1l_l1_ = [l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠢࠪး"),l1l11l_l1_ (u"ࠩสๅ้อๅ္ࠡࠩ"),l1l11l_l1_ (u"ࠪฬึอๅอ်ࠩ"),l1l11l_l1_ (u"ࠫ฾ื่ืࠩျ"),l1l11l_l1_ (u"้ࠬไ๋สสฮࠬြ"),l1l11l_l1_ (u"࠭ว฻ษ้ํࠬွ")]
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬှ") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪဿ"))
		if not any(value in title for value in l1llll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ၀"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ၁")+menu_name+title,l1111l_l1_,201)
	return html
def l111l1_l1_(url):
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࠥࠣࡪࡴࡸࠠࡑࡑࡖࡘࠥ࡬ࡩ࡭ࡶࡨࡶ࠿ࠐࠉࡪࡨࠣࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨࠢ࡬ࡲࠥࡻࡲ࡭࠼ࠍࠍࠎࡻࡲ࡭࠴࠯ࡪ࡮ࡲࡴࡦࡴࡶ࠶ࠥࡃࠠࡶࡴ࡯࠲ࡸࡶ࡬ࡪࡶࠫࠫࡄ࠭ࠩࠋࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸ࠭ࠬࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡂ࡬ࡤࡼࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡄࡢࡶࡤࠪࡤࡩ࡯ࡶࡰࡷࡁ࠺࠶ࠧࠪࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠶࠱࡬ࡩ࡭ࡶࡨࡶࡸ࠸ࠩࠋࠋࠌࡨࡦࡺࡡ࠳ࠢࡀࠤࢀ࠭ࡦࡰࡴࡰࠫ࠿࡬ࡩ࡭ࡶࡨࡶࡸ࠸ࠬࠨࡈ࡬ࡰࡹ࡫ࡲࡘࡱࡵࡨࡂ࠭࠺ࠨࠩࢀࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲ࠡ࠿ࠣ࡬ࡪࡧࡤࡦࡴࡶࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ࡟ࠣࡁࠥ࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ࡟ࠣࡁࠥ࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡘ࠮ࡅࡖࡖࡋ࠳ࡔࡐࡍࡈࡒࠬࡣࠠ࠾ࠢࠪࡋ࡟࠺ࡏࡥ࠲ࡱ࡮࡙ࡉࡡࡈࡹࡦࡋࡶ࠺ࡉࡻࡉࡴࡌࡊࡸ࡙࠱ࡷ࡝ࡳࡦ࡛ࡘ࡛ࡅ࠹ࡌࡪ࡞ࡸࡹࠩࠍࠍࠎ࡮ࡥࡢࡦࡨࡶࡸ࠸࡛ࠨࡅࡲࡳࡰ࡯ࡥࠨ࡟ࠣࡁࠥ࠭ࡷࡢࡴࡥࡰ࡮ࡵ࡮ࡻࡶࡹࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࡫ࡹࡋࡲࡧ࡭ࡎ࠼ࡉ࡮ࡔ࠳ࡑ࡝ࡔࡊ࡚࡮ࡕࡐࡖࡰࡤࡢࡐࡇ࡯ࡽ࡜࡮ࡥࡉ࡝࠵ࡇ࠸࡙࡭ࡇ࠼ࡔࡘࡏࡳࡊࡰ࡝࡬ࡧࡎࡖ࡭ࡋ࡭ࡳ࡮ࡗࡔࡓࡔ࡙࡜ࡒ࠷ࡕ࡫࡮ࡊࡦࡋࡌࡲࡢࡗࡉ࡯ࡔࡋࡸࡆࡑࡘ࡚ࡖ࡟ࡕ࠵࠳ࡧ࠵ࡓ࡝ࡥࡉࡥࡺࡩࡳࡓࡹࡗ࡙ࡕࡊࡖࡳ࡬࠳ࡗ࡛ࡍ࠵ࡪ࡫ࡹ࡮࡝࠵ࡇࡴࡡ࠴ࡲ࡛ࡗ࠶ࡈࡗࡣࡖࡄ࠷ࡘࡳࡎ࡫ࡦࡉࡨ࠸࡝ࡃࡊࡵࡌࡱ࠶࡮࡙ࡺࡋ࠹ࡍ࡯࡛ࡸ࡛ࡖࡪࡽࡓࡳࡍࡺࡑࡊࡉࡾࡓࡪࡊ࠲ࡑࡈࡓࡲ࡚࡫ࡪ࡯ࡒ࠷ࡔ࡫࡛ࡖࡅࡱࡓࡰࡤ࡮࡛ࡽࡅ࠵ࡔࡪࡂࡹࡐࡘࡏࡱࡍࡻ࡜࡭ࡓࡉࡏࡺࡏࡖ࡜ࡽࡒࢀ࡫࠱ࡐࡇࡧ࠺ࡓࡔࡃ࡬ࡑ࡛ࡎࡿࡏࡕ࡮࡭ࡒ࡯࡭ࡩࡧࡓࡀࡁࠬࠐࠉࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࠩࡓࡓࡘ࡚ࠧ࠭ࡷࡵࡰ࠷࠲ࡤࡢࡶࡤ࠶࠱࡮ࡥࡢࡦࡨࡶࡸ࠸ࠬࡕࡴࡸࡩ࠱࠭ࠧ࠭ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨࠫࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠤ࠰ࡨࡲࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠧࠨࠢ၂")
	if l1l11l_l1_ (u"ࠬࡅ࠿ࠨ၃") in url: url,type = url.split(l1l11l_l1_ (u"࠭࠿ࡀࠩ၄"))
	else: type = l1l11l_l1_ (u"ࠧࠨ၅")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ၆"),l1l11l_l1_ (u"ࠩࠪ၇"),url,type)
	#if url==l11lll_l1_: url = url+l1l11l_l1_ (u"ࠪ࠳ࡦࡲࡺࠨ၈")
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ၉"),l1l11l_l1_ (u"ࠬ࠭၊"),url,l1l11l_l1_ (u"࠭ࡔࡊࡖࡏࡉࡘ࠭။"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ၌"),url,l1l11l_l1_ (u"ࠨࠩ၍"),headers,True,l1l11l_l1_ (u"ࠩࠪ၎"),l1l11l_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ၏"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩၐ"))
	#WRITE_THIS(html)
	if l1l11l_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧၑ") in url: l1ll111_l1_ = [html]
	elif type==l1l11l_l1_ (u"࠭ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨၒ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡎࡣࡶࡸࡪࡸࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃࡢ࡮ࠡࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩၓ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠨࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡱࡴࡼࡩࡦࡵࠪၔ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡡ࠴ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨၕ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࡤࡹࡥࡳ࡫ࡨࡷࠬၖ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡘࡲࡩࡥࡧࡵࡣ࠷࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪၗ"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠬ࠷࠱࠲࡯ࡤ࡭ࡳࡶࡡࡨࡧࠪၘ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠢࡳࡥ࡬࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡴࡢࡤࡶࠦࠬၙ"),html,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡱࡦ࡯࡮࠮ࡨࡲࡳࡹ࡫ࡲࠨၚ"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩၛ"),l1l11l_l1_ (u"ࠩࠪၜ"),l1l11l_l1_ (u"ࠪࠫၝ"),str(l1ll111_l1_))
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	#items = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡵࡸ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨၞ"),block,re.DOTALL)
	l1l11l11l_l1_ = [l1l11l_l1_ (u"๋ࠬิศ้าอࠬၟ"),l1l11l_l1_ (u"࠭แ๋ๆ่ࠫၠ"),l1l11l_l1_ (u"ࠧศ฼้๎ฮ࠭ၡ"),l1l11l_l1_ (u"ࠨๅ็๎อ࠭ၢ"),l1l11l_l1_ (u"ࠩส฽้อๆࠨၣ"),l1l11l_l1_ (u"๋ࠪิอแࠨၤ"),l1l11l_l1_ (u"๊ࠫฮวาษฬࠫၥ"),l1l11l_l1_ (u"ࠬ฿ัืࠩၦ"),l1l11l_l1_ (u"࠭ๅ่ำฯห๋࠭ၧ"),l1l11l_l1_ (u"ࠧศๆห์๊࠭ၨ")]
	#addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ၩ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၪ"),l1l11l_l1_ (u"ࠪࠫၫ"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡨ࡯ࡹࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪၬ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l11l_l1_ (u"࡙ࠬ࡬ࡪࡦࡨࡶࡎࡺࡥ࡮ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫၭ"),block,re.DOTALL)
		l1ll1111_l1_,l11llll11_l1_,titles = zip(*items)
		items = zip(l11llll11_l1_,l1ll1111_l1_,titles)
	l1l1l11_l1_ = []
	for img,l1111l_l1_,title in items:
		#l1111l_l1_ = escapeUNICODE(l1111l_l1_)
		#l1111l_l1_ = QUOTE(l1111l_l1_)
		if l1l11l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨၮ") in l1111l_l1_: continue
		l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠧ࠰ࠩၯ"))
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪၰ"))
		if l1l11l_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩၱ") in l1111l_l1_ or any(value in title for value in l1l11l11l_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩၲ"),menu_name+title,l1111l_l1_,202,img)
		elif l1l11l_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧၳ") in l1111l_l1_ and l1l11l_l1_ (u"ࠬอไฮๆๅอࠬၴ") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩၵ"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ၶ") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨၷ"),menu_name+title,l1111l_l1_,203,img)
					l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠩ࠲ࡴࡦࡩ࡫࠰ࠩၸ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪၹ"),menu_name+title,l1111l_l1_+l1l11l_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫၺ"),201,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬၻ"),menu_name+title,l1111l_l1_,203,img)
	if type in [l1l11l_l1_ (u"࠭ࠧၼ"),l1l11l_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡵࡧࡧࡦࠩၽ")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩၾ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩၿ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				l1111l_l1_ = unescapeHTML(l1111l_l1_)
				title = unescapeHTML(title)
				title = title.replace(l1l11l_l1_ (u"ࠪห้฻แฮหࠣࠫႀ"),l1l11l_l1_ (u"ࠫࠬႁ"))
				if l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨႂ") in url:
					l11lll1l1_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬႃ"))[1]
					l1l111l11_l1_ = url.split(l1l11l_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭ႄ"))[1]
					l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧႅ")+l1l111l11_l1_,l1l11l_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨႆ")+l11lll1l1_l1_)
				if title!=l1l11l_l1_ (u"ࠪࠫႇ"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫႈ"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫႉ")+title,l1111l_l1_,201)
	return
def l111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧႊ"),l1l11l_l1_ (u"ࠧࠨႋ"),url,l1l11l_l1_ (u"ࠨࠩႌ"))
	episodesCount,items,l1l1111l_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙ႍ࠭"),url,l1l11l_l1_ (u"ࠪࠫႎ"),headers,True,l1l11l_l1_ (u"ࠫࠬႏ"),l1l11l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭႐"))
	html = response.content#.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ႑"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡵ࡫࠰ࡰ࡮ࡹࡴ࠮ࡰࡸࡱࡧ࡫ࡲࡦࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ႒"),html,re.DOTALL)
	if l1ll111_l1_:
		l1l1111l_l1_ = []
		l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࠩ႓").join(l1ll111_l1_)
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ႔"),l1l1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ႕"))
	for l1111l_l1_ in items:
		l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠫ࠴࠭႖"))
		title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ႗") + l1111l_l1_.split(l1l11l_l1_ (u"࠭࠯ࠨ႘"))[-1].replace(l1l11l_l1_ (u"ࠧ࠮ࠩ႙"),l1l11l_l1_ (u"ࠨࠢࠪႚ"))
		l1l11l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩส่า๊โส࠯ࠫࡠࡩ࠱ࠩࠨႛ"),l1111l_l1_.split(l1l11l_l1_ (u"ࠪ࠳ࠬႜ"))[-1],re.DOTALL)
		if l1l11l1l_l1_: l1l11l1l_l1_ = l1l11l1l_l1_[0]
		else: l1l11l1l_l1_ = l1l11l_l1_ (u"ࠫ࠵࠭ႝ")
		l1l1111l_l1_.append([l1111l_l1_,title,l1l11l1l_l1_])
	items = sorted(l1l1111l_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11l1l1_l1_ = str(items).count(l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ႞"))
	episodesCount = str(items).count(l1l11l_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ႟"))
	if l1l11l1l1_l1_>1 and episodesCount>0 and l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩႠ") not in url:
		for l1111l_l1_,title,l1l11l1l_l1_ in items:
			if l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪႡ") in l1111l_l1_:
				#l1111l_l1_ = QUOTE(l1111l_l1_)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩႢ"),menu_name+title,l1111l_l1_,203)
	else:
		for l1111l_l1_,title,l1l11l1l_l1_ in items:
			if l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬႣ") not in l1111l_l1_:
				#if l1l11l_l1_ (u"ࠫࠪ࠭Ⴄ") not in l1111l_l1_: l1111l_l1_ = QUOTE(l1111l_l1_)
				#else: l1111l_l1_ = QUOTE(UNQUOTE(l1111l_l1_))
				#l1111l_l1_ = UNQUOTE(l1111l_l1_)
				title = UNQUOTE(title)
				addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫႥ"),menu_name+title,l1111l_l1_,202)
	return
def PLAY(url):
	#LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ⴆ"),l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࠥ࠷࠱࠲ࠩႧ"))
	l1ll1lll_l1_ = []
	parts = url.split(l1l11l_l1_ (u"ࠨ࠱ࠪႨ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪႩ"),l1l11l_l1_ (u"ࠪࠫႪ"),url,l1l11l_l1_ (u"ࠫࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭Ⴋ"))
	#url = UNQUOTE(QUOTE(url))
	hostname = l11lll_l1_
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩႬ"),url,l1l11l_l1_ (u"࠭ࠧႭ"),headers,True,True,l1l11l_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫႮ"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ⴏ"))
	id = re.findall(l1l11l_l1_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪႰ"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠥࠫႱ"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠫࡵࡵࡳࡵ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⴒ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭Ⴓ"),l1l11l_l1_ (u"࠭ࠧႴ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႵ"),l1l11l_l1_ (u"ࠨ์ิะ๎ࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬႶ"))
	#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩႷ"),l1l11l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡕࡗࡅࡗ࡚ࠠࡕࡋࡐࡍࡓࡍࠠ࠲࠳࠴ࠫႸ"))
	if l1l11l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬႹ") in html:
		#parts = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧႺ"))
		url2 = url.replace(parts[3],l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬႻ"))
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫႼ"),url2,l1l11l_l1_ (u"ࠨࠩႽ"),headers,True,True,l1l11l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭Ⴞ"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨႿ"))
		l11lll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪჀ"),l1lll111_l1_,re.DOTALL)
		l1l1l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࠦࢁࠬࡱࡶࡱࡷ࠿࠮࠭Ⴡ"),l1lll111_l1_,re.DOTALL)
		l11lll11l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠪࡶࡻ࡯ࡵ࠽ࠫ࠲࠯ࡅࠩࠧࡳࡸࡳࡹࡁ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪჂ"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࡜࡯ࠬ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨჃ"),l1lll111_l1_)
		l11ll1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠬࡱࡶࡱࡷ࠿࠭࠴ࠪࡀࠫࠩࡵࡺࡵࡴ࠼࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩჄ"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		l1l1111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫჅ"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		items = l11lll111_l1_+l1l1l1111_l1_+l11lll11l_l1_+l11ll1ll1_l1_+l11ll1l1l_l1_+l1l1111ll_l1_
		#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ჆"),l1l11l_l1_ (u"ࠫࡊࡓࡁࡅࠢࡖࡘࡆࡘࡔࠡࡖࡌࡑࡎࡔࡇࠡ࠶࠷࠸ࠬჇ"))
		if not items:
			items = re.findall(l1l11l_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ჈"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l11l_l1_ (u"࠭࠮ࡱࡰࡪࠫ჉") in server: continue
			if l1l11l_l1_ (u"ࠧ࠯࡬ࡳ࡫ࠬ჊") in server: continue
			if l1l11l_l1_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨ჋") in server: continue
			l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ჌"),title,re.DOTALL)
			if l1l1l1l1_l1_:
				l1l1l1l1_l1_ = l1l1l1l1_l1_[0]
				if l1l1l1l1_l1_ in title: title = title.replace(l1l1l1l1_l1_+l1l11l_l1_ (u"ࠪࡴࠬჍ"),l1l11l_l1_ (u"ࠫࠬ჎")).replace(l1l1l1l1_l1_,l1l11l_l1_ (u"ࠬ࠭჏")).strip(l1l11l_l1_ (u"࠭ࠠࠨა"))
				l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠧࡠࡡࡢࡣࠬბ")+l1l1l1l1_l1_
			else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࠩგ")
			#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩდ"),l1l11l_l1_ (u"ࠪ࡟ࠬე")+str(id)+l1l11l_l1_ (u"ࠫࡢࠦࠠ࡜ࠩვ")+str(hostname)+l1l11l_l1_ (u"ࠬࡣࠠࠡ࡝ࠪზ")+str(title)+l1l11l_l1_ (u"࠭࡝ࠡࠢ࡞ࠫთ")+str(l1l1l1l1_l1_)+l1l11l_l1_ (u"ࠧ࡞ࠩი"))
			if server.isdigit():
				l1111l_l1_ = hostname+l1l11l_l1_ (u"ࠨ࠱ࡂࡴࡴࡹࡴࡪࡦࡀࠫკ")+id+l1l11l_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭ლ")+server+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫმ")+title+l1l11l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬნ")+l1l1l1l1_l1_
			else:
				if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪო") not in server: server = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬპ")+server
				l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨჟ"),title,re.DOTALL)
				if l1l1l1l1_l1_: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭რ")+l1l1l1l1_l1_[0]
				else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠩࠪს")
				l1111l_l1_ = server+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫტ")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫუ"),l1l11l_l1_ (u"ࠬࡡࠧფ")+l1l1l1l1_l1_+l1l11l_l1_ (u"࠭࡝ࠡࠢࠣࠤࡠ࠭ქ")+title+l1l11l_l1_ (u"ࠧ࡞ࠩღ"))
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ყ"), l1ll1lll_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪშ"),l1l11l_l1_ (u"ࠪࠫჩ"),l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪࠣ࠵ࠬც"),	str(len(items)))
	if l1l11l_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡎࡰࡹࠪძ") in html:
		headers2 = { l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬწ"):l1l11l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧჭ") }
		url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠫხ")
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ჯ"),url2,l1l11l_l1_ (u"ࠪࠫჰ"),headers2,True,l1l11l_l1_ (u"ࠫࠬჱ"),l1l11l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩჲ"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫჳ"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨჴ"),l1l11l_l1_ (u"ࠨࠩჵ"),url2,l1lll111_l1_)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡹࡱࠦࡣ࡭ࡣࡶࡷࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠮࡫ࡷࡩࡲࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪჶ"),l1lll111_l1_,re.DOTALL)
		for block in l1ll111_l1_:
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀࠬჷ"),block,re.DOTALL)
			for l1111l_l1_,name,l1l1l1l1_l1_ in items:
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬჸ")+name+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩჹ")+l1l11l_l1_ (u"࠭࡟ࡠࡡࡢࠫჺ")+l1l1l1l1_l1_
				l1ll1lll_l1_.append(l1111l_l1_)
	elif l1l11l_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ჻") in html:
		headers2 = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬჼ"):l1l11l_l1_ (u"ࠩࠪჽ") , l1l11l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ჾ"):l1l11l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬჿ") }
		url2 = hostname + l1l11l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡥࡱࡺࡲࡱࡵࡡࡥ࡮࡬ࡲࡰࡹࠦࡱࡱࡶࡸࡎࡪ࠽ࠨᄀ")+id
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᄁ"),url2,l1l11l_l1_ (u"ࠧࠨᄂ"),headers2,True,True,l1l11l_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬᄃ"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᄄ"))
		if l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲ࡨࡴ࡯ࡵࠪᄅ") in l1lll111_l1_:
			l11lll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᄆ"),l1lll111_l1_,re.DOTALL)
			for url3 in l11lll11l_l1_:
				if l1l11l_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬᄇ") not in url3 and l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫᄈ") in url3:
					url3 = url3+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᄉ")
					l1ll1lll_l1_.append(url3)
				elif l1l11l_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨᄊ") in url3:
					l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠩࠪᄋ")
					response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᄌ"),url3,l1l11l_l1_ (u"ࠫࠬᄍ"),headers,True,True,l1l11l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠻ࡴࡩࠩᄎ"))
					l11lllll1_l1_ = response.content#.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᄏ"))
					l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠾ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄ࠯࠭࠮࠯࠰࠱ࠬᄐ"),l11lllll1_l1_,re.DOTALL)
					for l1l11l1ll_l1_ in l1l1l1_l1_:
						l1l111111_l1_ = l1l11l_l1_ (u"ࠨࠩᄑ")
						l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫᄒ"),l1l11l1ll_l1_,re.DOTALL)
						for l1l111l1l_l1_ in l11ll1ll1_l1_:
							item = re.findall(l1l11l_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫᄓ"),l1l111l1l_l1_,re.DOTALL)
							if item:
								l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩᄔ")+item[0]
								break
						for l1l111l1l_l1_ in reversed(l11ll1ll1_l1_):
							item = re.findall(l1l11l_l1_ (u"ࠬࡢࡷ࡝ࡹ࠮ࠫᄕ"),l1l111l1l_l1_,re.DOTALL)
							if item:
								l1l111111_l1_ = item[0]
								break
						l11ll1l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᄖ"),l1l11l1ll_l1_,re.DOTALL)
						for l1l1111l1_l1_ in l11ll1l1l_l1_:
							l1l1111l1_l1_ = l1l1111l1_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᄗ")+l1l111111_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᄘ")+l1l1l1l1_l1_
							l1ll1lll_l1_.append(l1l1111l1_l1_)
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᄙ"),l1l11l_l1_ (u"ࠪࠫᄚ"),l1l11l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࠱ࠨᄛ"),	str(len(l1ll1lll_l1_))	)
		elif l1l11l_l1_ (u"ࠬࡹ࡬ࡰࡹ࠰ࡱࡴࡺࡩࡰࡰࠪᄜ") in l1lll111_l1_:
			l1lll111_l1_ = l1lll111_l1_.replace(l1l11l_l1_ (u"࠭࠼ࡩ࠸ࠣࠫᄝ"),l1l11l_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫᄞ"))+l1l11l_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩᄟ")
			l1lll111_l1_ = l1lll111_l1_.replace(l1l11l_l1_ (u"ࠩ࠿࡬࠸ࠦࠧᄠ"),l1l11l_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠤࡂࡃࡓࡕࡃࡕࡘࡂࡃࠧᄡ"))+l1l11l_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠬᄢ")
			#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᄣ"),l1lll111_l1_)
			#open(l1l11l_l1_ (u"࠭ࡳ࠻࡞࡟ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭ᄤ"),l1l11l_l1_ (u"ࠧࡸࠩᄥ")).write(l1lll111_l1_)
			l11ll1lll_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠬ࠳࠰࠿ࠪ࠿ࡀࡉࡓࡊ࠽࠾ࠩᄦ"),l1lll111_l1_,re.DOTALL)
			if l11ll1lll_l1_:
				for l1l11l1ll_l1_ in l11ll1lll_l1_:
					if l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠨᄧ") not in l1l11l1ll_l1_: continue
					#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᄨ"),l1l11l_l1_ (u"ࠫࠬᄩ"),l1l11l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࠲࠳࠴ࠫᄪ"),	l1l11l1ll_l1_	)
					l1l111ll1_l1_ = l1l11l_l1_ (u"࠭ࠧᄫ")
					l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴ࡮ࡲࡻ࠲ࡳ࡯ࡵ࡫ࡲࡲࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᄬ"),l1l11l1ll_l1_,re.DOTALL)
					for l1l111l1l_l1_ in l11ll1ll1_l1_:
						item = re.findall(l1l11l_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩᄭ"),l1l111l1l_l1_,re.DOTALL)
						if item:
							l1l111ll1_l1_ = l1l11l_l1_ (u"ࠩࡢࡣࡤࡥࠧᄮ")+item[0]
							break
					l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᄯ"),l1l11l1ll_l1_,re.DOTALL)
					if l11ll1ll1_l1_:
						for l1l111111_l1_,l1l11111l_l1_ in l11ll1ll1_l1_:
							l1l11111l_l1_ = l1l11111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᄰ")+l1l111111_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᄱ")+l1l111ll1_l1_
							l1ll1lll_l1_.append(l1l11111l_l1_)
					else:
						l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᄲ"),l1l11l1ll_l1_,re.DOTALL)
						for l1l11111l_l1_,l1l111111_l1_ in l11ll1ll1_l1_:
							l1l11111l_l1_ = l1l11111l_l1_.strip(l1l11l_l1_ (u"ࠧࠡࠩᄳ"))+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᄴ")+l1l111111_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᄵ")+l1l111ll1_l1_
							l1ll1lll_l1_.append(l1l11111l_l1_)
			else:
				l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࡜ࡸ࠭ࠬࡀࠬᄶ"),l1lll111_l1_,re.DOTALL)
				for l1l11111l_l1_,l1l111111_l1_ in l11ll1ll1_l1_:
					l1l11111l_l1_ = l1l11111l_l1_.strip(l1l11l_l1_ (u"ࠫࠥ࠭ᄷ"))+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᄸ")+l1l111111_l1_+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᄹ")
					l1ll1lll_l1_.append(l1l11111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬᄺ"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᄻ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠩࠪᄼ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠪࠫᄽ"): return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭ᄾ"),l1l11l_l1_ (u"ࠬ࠱ࠧᄿ"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᅀ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬᅁ"),l1l11l_l1_ (u"ࠨࠩᅂ"),headers,True,l1l11l_l1_ (u"ࠩࠪᅃ"),l1l11l_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩᅄ"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᅅ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩࡨࡦࡸࡵࡳࡳ࠳ࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᅆ"),html,re.DOTALL)
	if showdialogs and l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᅇ"),block,re.DOTALL)
		l1l111lll_l1_,l11llllll_l1_ = [],[]
		for category,title in items:
			#if title in [l1l11l_l1_ (u"ࠧา์สฺฮ่ࠦࠡ็ุหึ฿็ࠨᅈ")]: continue
			l1l111lll_l1_.append(category)
			l11llllll_l1_.append(title)
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨᅉ"), l11llllll_l1_)
		if selection == -1 : return
		category = l1l111lll_l1_[selection]
	else: category = l1l11l_l1_ (u"ࠩࠪᅊ")
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧᅋ")+search+l1l11l_l1_ (u"ࠫࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨᅌ")+category+l1l11l_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁ࠶࠭ᅍ")
	l111l1_l1_(url)
	return
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᅎ"),l1l11l_l1_ (u"ࠧࠨᅏ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩᅐ"),l1l11l_l1_ (u"ࠩࠪᅑ"),filter,url)
	# for l11lll1ll_l1_ filter:		l1111l1_l1_ = [l1l11l_l1_ (u"ࠪࡇࡦࡺࡥࡨࡱࡵࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ᅒ"),l1l11l_l1_ (u"ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪᅓ"),l1l11l_l1_ (u"ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬᅔ"),l1l11l_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨᅕ")]
	l1111l1_l1_ = [l1l11l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᅖ"),l1l11l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᅗ"),l1l11l_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨᅘ"),l1l11l_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᅙ")]
	if l1l11l_l1_ (u"ࠫࡄ࠭ᅚ") in url: url = url.split(l1l11l_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩᅛ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"࠭࡟ࡠࡡࠪᅜ"),1)
	if filter==l1l11l_l1_ (u"ࠧࠨᅝ"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"ࠨࠩᅞ"),l1l11l_l1_ (u"ࠩࠪᅟ")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᅠ"))
	if type==l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨᅡ"):
		if l1111l1_l1_[0]+l1l11l_l1_ (u"ࠬࡃࠧᅢ") not in l111111_l1_: category = l1111l1_l1_[0]
		for i in range(len(l1111l1_l1_[0:-1])):
			if l1111l1_l1_[i]+l1l11l_l1_ (u"࠭࠽ࠨᅣ") in l111111_l1_: category = l1111l1_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠧࠧࠩᅤ")+category+l1l11l_l1_ (u"ࠨ࠿࠳ࠫᅥ")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠩࠩࠫᅦ")+category+l1l11l_l1_ (u"ࠪࡁ࠵࠭ᅧ")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠫࠫ࠭ᅨ"))+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᅩ")+l11l11l_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠨᅪ"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᅫ"))
		url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬᅬ")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪᅭ"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᅮ"))
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠫࠬᅯ"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᅰ"))
		if l1llllll_l1_==l1l11l_l1_ (u"࠭ࠧᅱ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫᅲ")+l1llllll_l1_
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅳ"),menu_name+l1l11l_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬᅴ"),url2,201)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅵ"),menu_name+l1l11l_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫᅶ")+l1ll1ll1_l1_+l1l11l_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫᅷ"),url2,201)
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᅸ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᅹ"),l1l11l_l1_ (u"ࠨࠩᅺ"),9999)
	html = OPENURL_CACHED(l1llll_l1_,url+l1l11l_l1_ (u"ࠩ࠲ࡥࡱࢀࠧᅻ"),l1l11l_l1_ (u"ࠪࠫᅼ"),headers,l1l11l_l1_ (u"ࠫࠬᅽ"),l1l11l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᅾ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡁ࡫ࡣࡻࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬ࡊࡡࡵࡣࠫ࠲࠯ࡅࠩࡇ࡫࡯ࡸࡪࡸࡗࡰࡴࡧࠫᅿ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# for l11lll1ll_l1_ filter:		l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࡬࠷࠭ᆀ"),block,re.DOTALL)
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡥࡣࡷࡥ࠲࡬࡯ࡳࡖࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࡭࠸ࠧᆁ"),block,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᆂ"),l1l11l_l1_ (u"ࠪࠫᆃ"),l1l11l_l1_ (u"ࠫࠬᆄ"),str(l1l1ll1_l1_))
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		#name = name.replace(l1l11l_l1_ (u"ࠬ࠳࠭ࠨᆅ"),l1l11l_l1_ (u"࠭ࠧᆆ"))
		name = name.replace(l1l11l_l1_ (u"ࠧศะอ๎ฬืࠠࠨᆇ"),l1l11l_l1_ (u"ࠨࠩᆈ"))
		name = name.replace(l1l11l_l1_ (u"ࠩึ๊ฮࠦวๅว้ฮฬาࠧᆉ"),l1l11l_l1_ (u"ࠪหู้ๆสࠩᆊ"))
		items = re.findall(l1l11l_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀࠬᆋ"),block,re.DOTALL)
		if l1l11l_l1_ (u"ࠬࡃࠧᆌ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪᆍ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l1111l1_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧᆎ")+l111l11_l1_)
				return
			else:
				if l1l111l_l1_==l1111l1_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆏ"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪᆐ"),url2,201)
				else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆑ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬᆒ"),url2,205,l1l11l_l1_ (u"ࠬ࠭ᆓ"),l1l11l_l1_ (u"࠭ࠧᆔ"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨᆕ"):
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠪᆖ")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀ࠴ࠬᆗ")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠬᆘ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠶ࠧᆙ")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᆚ")+l11l11l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆛ"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩᆜ")+name,url2,204,l1l11l_l1_ (u"ࠨࠩᆝ"),l1l11l_l1_ (u"ࠩࠪᆞ"),l111l11_l1_)		# +l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᆟ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			option = option.replace(l1l11l_l1_ (u"ࠫࡡࡴࠧᆠ"),l1l11l_l1_ (u"ࠬ࠭ᆡ"))
			if option in l1llll1_l1_: continue
			#if option==l1l11l_l1_ (u"࠭วๅๅ็ࠫᆢ"): continue
			#option = l1l11l_l1_ (u"ࠧ࡜ࠩᆣ")+option+l1l11l_l1_ (u"ࠨ࡟ࠪᆤ")
			#if l1l11l_l1_ (u"ࠩส่่๊ࠧᆥ") in option: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᆦ"),l1l11l_l1_ (u"ࠫࠬᆧ"),l1l11l_l1_ (u"ࠬ࠭ᆨ"),l1l11l_l1_ (u"࡛࠭ࠨᆩ")+str(option)+l1l11l_l1_ (u"ࠧ࡞ࠩᆪ"))
			#if l1l11l_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧᆫ") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪᆬ"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠪࠪࠬᆭ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠭ᆮ")+option
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠬࠬࠧᆯ")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽ࠨᆰ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᆱ")+l11l11l_l1_
			title = option+l1l11l_l1_ (u"ࠨࠢ࠽ࠫᆲ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠩ࠳ࠫᆳ")]
			title = option+l1l11l_l1_ (u"ࠪࠤ࠿࠭ᆴ")+name
			if type==l1l11l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬᆵ"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆶ"),menu_name+title,url,204,l1l11l_l1_ (u"࠭ࠧᆷ"),l1l11l_l1_ (u"ࠧࠨᆸ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᆹ"))
			elif type==l1l11l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ᆺ") and l1111l1_l1_[-2]+l1l11l_l1_ (u"ࠪࡁࠬᆻ") in l111111_l1_:
				l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᆼ"))
				url3 = url+l1l11l_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩᆽ")+l1llll11_l1_
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆾ"),menu_name+title,url3,201)
			else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆿ"),menu_name+title,url,205,l1l11l_l1_ (u"ࠨࠩᇀ"),l1l11l_l1_ (u"ࠩࠪᇁ"),l1l1111_l1_)
	return
def l1llll1l_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᇂ"),l1l11l_l1_ (u"ࠫࠬᇃ"),filters,l1l11l_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭ᇄ"))
	# mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᇅ")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᇆ")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"ࠨࡣ࡯ࡰࠬᇇ")					all filters (l1lll1l1_l1_ l111lll_l1_ filter)
	filters = filters.replace(l1l11l_l1_ (u"ࠩࡀࠪࠬᇈ"),l1l11l_l1_ (u"ࠪࡁ࠵ࠬࠧᇉ"))
	filters = filters.strip(l1l11l_l1_ (u"ࠫࠫ࠭ᇊ"))
	l11111l_l1_ = {}
	if l1l11l_l1_ (u"ࠬࡃࠧᇋ") in filters:
		items = filters.split(l1l11l_l1_ (u"࠭ࠦࠨᇌ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠧ࠾ࠩᇍ"))
			l11111l_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠨࠩᇎ")
	# for l11lll1ll_l1_ filter:		l11ll1l_l1_ = [l1l11l_l1_ (u"ࠩࡆࡥࡹ࡫ࡧࡰࡴࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬᇏ"),l1l11l_l1_ (u"ࠪ࡝ࡪࡧࡲࡄࡪࡨࡧࡰࡈ࡯ࡹࠩᇐ"),l1l11l_l1_ (u"ࠫࡌ࡫࡮ࡳࡧࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫᇑ"),l1l11l_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾࡉࡨࡦࡥ࡮ࡆࡴࡾࠧᇒ")]
	l11ll1l_l1_ = [l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᇓ"),l1l11l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ᇔ"),l1l11l_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧᇕ"),l1l11l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᇖ")]
	for key in l11ll1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠪ࠴ࠬᇗ")
		if l1l11l_l1_ (u"ࠫࠪ࠭ᇘ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᇙ") and value!=l1l11l_l1_ (u"࠭࠰ࠨᇚ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠧࠡ࠭ࠣࠫᇛ")+value
		elif mode==l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᇜ") and value!=l1l11l_l1_ (u"ࠩ࠳ࠫᇝ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠪࠪࠬᇞ")+key+l1l11l_l1_ (u"ࠫࡂ࠭ᇟ")+value
		elif mode==l1l11l_l1_ (u"ࠬࡧ࡬࡭ࠩᇠ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"࠭ࠦࠨᇡ")+key+l1l11l_l1_ (u"ࠧ࠾ࠩᇢ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠨࠢ࠮ࠤࠬᇣ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠩࠩࠫᇤ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠪࡁ࠵࠭ᇥ"),l1l11l_l1_ (u"ࠫࡂ࠭ᇦ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ᇧ"),l1l11l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧᇨ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᇩ"),l1l11l_l1_ (u"ࠨࠩᇪ"),filters,l1l11l_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠳࠴ࠪᇫ"))
	return l11llll_l1_
l1l11l_l1_ (u"ࠥࠦࠧࠐࡦࡪ࡮ࡷࡩࡷࡹ࠺ࠊ࠳ࡶࡸࠥࡳࡥࡵࡪࡲࡨࠎࠏࠨࡶࡵࡨࡨࠥࡴ࡯ࡸࠢ࡬ࡲࠥࡽࡥࡣࡵ࡬ࡸࡪ࠯ࠊࡢࡦࡧ࡭ࡳ࡭ࠠࡧ࡫࡯ࡸࡪࡸࠠࡵࡱࠣࡷࡪࡧࡲࡤࡪࠍࡔࡔ࡙ࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡂ࡬ࡤࡼࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡄࡢࡶࡤࠪࡤࡩ࡯ࡶࡰࡷࡁ࠺࠶ࠊࠊࡦࡤࡸࡦࡀࠉ࡜ࠩࡆࡥࡹ࡫ࡧࡰࡴࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ࠬࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨ࠮ࠪࡕࡺࡧ࡬ࡪࡶࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬࡣࠊࠊࡪࡨࡥࡩ࡫ࡲࡴ࠼ࠌࡇࡴࡵ࡫ࡪࡧࠣ࠯ࠥ࡞ࡒࡆࡈ࠰ࡘࡔࡑࡅࡏࠌࠍࠎ࡫࡯࡬ࡵࡧࡵࡷ࠿ࠏ࠲࡯ࡦࠣࡱࡪࡺࡨࡰࡦࠌࠍ࠭ࡵ࡬ࡥࠢࡰࡩࡹ࡮࡯ࡥࠢࡥࡹࡹࠦࡳࡵ࡫࡯ࡰࠥࡽ࡯ࡳ࡭࡬ࡲ࡬࠯ࠉࠊࠪࡸࡷࡪࡪࠠࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠫࠍࡋࡊ࡚࠺ࠊࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡧࡲࡩࡰࡰࡽ࠲ࡦࡸࡴ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡵࡺࡧ࡬ࡪࡶࡼࡁ࡜ࡋࡂ࠮ࡆࡏࠪࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࡀ࠶࠵࠸࠰ࠋࠌࠍࠎ࡫࡯࡬ࡵࡧࡵࡷ࠿ࠏ࠳ࡳࡦࠣࡱࡪࡺࡨࡰࡦࠌࠍ࠭ࡵ࡬ࡥࠢࡰࡩࡹ࡮࡯ࡥࠢࡥࡹࡹࠦࡳࡵ࡫࡯ࡰࠥࡽ࡯ࡳ࡭࡬ࡲ࡬࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴ࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵ࠳࠷࠶࠱࠺ࠌࡊࡉ࡙ࡀࠉࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡦࡱ࡯࡯࡯ࡼ࠱ࡥࡷࡺ࠯ࡲࡷࡤࡰ࡮ࡺࡹ࠰࠶ࡎࠩ࠷࠶ࡂ࡭ࡷࡕࡥࡾࠐࠢࠣࠤᇬ")
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭㽔")
headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㽕") : l1l11l_l1_ (u"ࠩࠪ㽖") }
menu_name = l1l11l_l1_ (u"ࠪࡣࡘࡌࡗࡠࠩ㽗")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l111l1_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l111ll_l1_(url)
	elif mode==214: results = l1l11lll1lll_l1_(url)
	elif mode==215: results = l1l11llll111_l1_(url)
	elif mode==218: results = l11111111ll_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11111111ll_l1_():
	message = l1l11l_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ㽘")
	DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㽙"),l1l11l_l1_ (u"࠭ࠧ㽚"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㽛"),l1l11l_l1_ (u"ࠨษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠧ㽜"),message)
	return
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㽝"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ㽞"),l1l11l_l1_ (u"ࠫࠬ㽟"),219,l1l11l_l1_ (u"ࠬ࠭㽠"),l1l11l_l1_ (u"࠭ࠧ㽡"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㽢"))
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㽣"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠧ㽤"),l1l11l_l1_ (u"ࠪࠫ㽥"),114,l11lll_l1_)
	url = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ㽦")
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㽧"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ㽨")+menu_name+l1l11l_l1_ (u"ࠧศๆ่้๏ุษࠨ㽩"),url,211)
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ㽪"),headers,l1l11l_l1_ (u"ࠩࠪ㽫"),l1l11l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㽬"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㽭"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㽮"),block,re.DOTALL)
	for l1111l_l1_,title in items:#[1:-1]:
		url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ㽯")+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㽰"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ㽱")+menu_name+title,url,211)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㽲"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㽳"),block,re.DOTALL)
	l1llll1_l1_ = [l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ㽴"),l1l11l_l1_ (u"ࠬอไาศํื๏ฯࠧ㽵")]
	#l11llll1l_l1_ = [l1l11l_l1_ (u"࠭ๅิๆึ่ฬะࠠࠨ㽶"),l1l11l_l1_ (u"ࠧศใ็ห๊ࠦࠧ㽷"),l1l11l_l1_ (u"ࠨสิห๊าࠧ㽸"),l1l11l_l1_ (u"ࠩ฼ีํ฼ࠧ㽹"),l1l11l_l1_ (u"ࠪ็้๐ศศฬࠪ㽺"),l1l11l_l1_ (u"ࠫฬเว็๋ࠪ㽻")]
	for l1111l_l1_,title in items:
		title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ㽼"))
		if not any(value in title for value in l1llll1_l1_):
		#	if any(value in title for value in l11llll1l_l1_):
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㽽"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ㽾")+menu_name+title,l1111l_l1_,211)
	return html
def l111l1_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠨࠩ㽿"),headers,l1l11l_l1_ (u"ࠩࠪ㾀"),l1l11l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭㾁"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㾂"),l1l11l_l1_ (u"ࠬ࠭㾃"),url,html)
	if l1l11l_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨ㾄") in url or l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ㾅") in url: block = html
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡏࡨࡨ࡮ࡧࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ㾆"),html,re.DOTALL)
		if l1ll111_l1_: block = l1ll111_l1_[0]
		else: return
	items = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㾇"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l1l11l11l_l1_ = [l1l11l_l1_ (u"ู้ࠪอ็ะหࠪ㾈"),l1l11l_l1_ (u"ࠫๆ๐ไๆࠩ㾉"),l1l11l_l1_ (u"ࠬอฺ็์ฬࠫ㾊"),l1l11l_l1_ (u"࠭ใๅ์หࠫ㾋"),l1l11l_l1_ (u"ࠧศ฻็ห๋࠭㾌"),l1l11l_l1_ (u"ࠨ้าหๆ࠭㾍"),l1l11l_l1_ (u"่ࠩฬฬืวสࠩ㾎"),l1l11l_l1_ (u"ࠪ฽ึ฼ࠧ㾏"),l1l11l_l1_ (u"๊ࠫํัอษ้ࠫ㾐"),l1l11l_l1_ (u"ࠬอไษ๊่ࠫ㾑")]
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ㾒") in l1111l_l1_: continue
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠧ࠰ࠩ㾓"))
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪ㾔"))
		if l1l11l_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ㾕") in l1111l_l1_ or any(value in title for value in l1l11l11l_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㾖"),menu_name+title,l1111l_l1_,212,img)
		elif l1l11l_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ㾗") in l1111l_l1_ and l1l11l_l1_ (u"ࠬอไฮๆๅอࠬ㾘") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ㾙"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㾚") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾛"),menu_name+title,l1111l_l1_,213,img)
					l1l1l11_l1_.append(title)
		else: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㾜"),menu_name+title,l1111l_l1_,213,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㾝"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㾞"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠬอไึใะอࠥ࠭㾟"),l1l11l_l1_ (u"࠭ࠧ㾠"))
			if title!=l1l11l_l1_ (u"ࠧࠨ㾡"): addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾢"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨ㾣")+title,l1111l_l1_,211)
	return
def l111ll_l1_(url):
	episodesCount,items,l1l1111l_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫ㾤"),headers,l1l11l_l1_ (u"ࠫࠬ㾥"),l1l11l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ㾦"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡴࡪ࠯࡯࡭ࡸࡺ࠭࡯ࡷࡰࡦࡪࡸࡥࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㾧"),html,re.DOTALL)
	if l1ll111_l1_:
		l1l1l1_l1_ = l1l11l_l1_ (u"ࠧࠨ㾨").join(l1ll111_l1_)
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㾩"),l1l1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ㾪"))
	for l1111l_l1_ in items:
		l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠪ࠳ࠬ㾫"))
		title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㾬") + l1111l_l1_.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㾭"))[-1].replace(l1l11l_l1_ (u"࠭࠭ࠨ㾮"),l1l11l_l1_ (u"ࠧࠡࠩ㾯"))
		l1l11l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨษ็ั้่ษ࠮ࠪ࡟ࡨ࠰࠯ࠧ㾰"),l1111l_l1_.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㾱"))[-1],re.DOTALL)
		if l1l11l1l_l1_: l1l11l1l_l1_ = l1l11l1l_l1_[0]
		else: l1l11l1l_l1_ = l1l11l_l1_ (u"ࠪ࠴ࠬ㾲")
		l1l1111l_l1_.append([l1111l_l1_,title,l1l11l1l_l1_])
	items = sorted(l1l1111l_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11l1l1_l1_ = str(items).count(l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭㾳"))
	episodesCount = str(items).count(l1l11l_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ㾴"))
	if l1l11l1l1_l1_>1 and episodesCount>0 and l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ㾵") not in url:
		for l1111l_l1_,title,l1l11l1l_l1_ in items:
			if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ㾶") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾷"),menu_name+title,l1111l_l1_,213)
	else:
		for l1111l_l1_,title,l1l11l1l_l1_ in items:
			if l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ㾸") not in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㾹"),menu_name+title,l1111l_l1_,212)
	return
def PLAY(url):
	l1ll1lll_l1_ = []
	parts = url.split(l1l11l_l1_ (u"ࠫ࠴࠭㾺"))
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠬ࠭㾻"),headers,l1l11l_l1_ (u"࠭ࠧ㾼"),l1l11l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㾽"))
	# l1l1ll11l_l1_ l1ll1111_l1_
	if l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ㾾") in html:
		url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ㾿"))
		l1lll111_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠪࠫ㿀"),headers,l1l11l_l1_ (u"ࠫࠬ㿁"),l1l11l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭㿂"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㿃"),l1lll111_l1_,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ㿄"),block,re.DOTALL)
			if items:
				id = re.findall(l1l11l_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ㿅"),l1lll111_l1_,re.DOTALL)
				if id:
					l1lll11l11_l1_ = id[0]
					for l1111l_l1_,title in items:
						l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ㿆")+l1lll11l11_l1_+l1l11l_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ㿇")+l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㿈")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㿉")
						l1ll1lll_l1_.append(l1111l_l1_)
			else:
				# https://l1l11llll11l_l1_.tv/l1l1ll11l_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ㿊"),block,re.DOTALL)
				for l1111l_l1_,dummy in items:
					l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	if l1l11l_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ㿋") in html:
		url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㿌"))
		l1lll111_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠩࠪ㿍"),headers,l1l11l_l1_ (u"ࠪࠫ㿎"),l1l11l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㿏"))
		id = re.findall(l1l11l_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㿐"),l1lll111_l1_,re.DOTALL)
		if id:
			l1lll11l11_l1_ = id[0]
			headers2 = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㿑"):l1l11l_l1_ (u"ࠧࠨ㿒") , l1l11l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ㿓"):l1l11l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ㿔") }
			url2 = l11lll_l1_ + l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭㿕")+l1lll11l11_l1_
			l1lll111_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠫࠬ㿖"),headers2,l1l11l_l1_ (u"ࠬ࠭㿗"),l1l11l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ㿘"))
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡪ࠶࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㿙"),l1lll111_l1_,re.DOTALL)
			if l1ll111_l1_:
				for resolution,block in l1ll111_l1_:
					items = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㿚"),block,re.DOTALL)
					for name,l1111l_l1_ in items:
						l1ll1lll_l1_.append(l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㿛")+name+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㿜")+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ㿝")+resolution)
			else:
				l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡨ࠷ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ㿞"),l1lll111_l1_,re.DOTALL)
				if not l1ll111_l1_: l1ll111_l1_ = [l1lll111_l1_]
				for block in l1ll111_l1_:
					l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹࡥࡳࡸࡨࡶࡸ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡴࡡ࡮ࡧ࠽ࠎࠎࠏࠉࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࡜࠯࠴ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧศๆาๆฮࠦࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠏࠉࡪࡨࠣࡲࡦࡳࡥࠢ࠿ࠪࠫ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨࠤ࠰ࠦࠧࠡโࠣࠫࠏࠏࠉࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡱࡥࡲ࡫ࠠ࠾ࠢࠪࠫࠏࠏࠉࠊࠋࠌࠦࠧࠨ㿟")
					name = l1l11l_l1_ (u"ࠧࠨ㿠")
					items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ㿡"),block,re.DOTALL)
					for l1111l_l1_ in items:
						server = l1l11l_l1_ (u"ࠩࠩࠪࠬ㿢") + l1111l_l1_.split(l1l11l_l1_ (u"ࠪ࠳ࠬ㿣"))[2].lower() + l1l11l_l1_ (u"ࠫࠫࠬࠧ㿤")
						server = server.replace(l1l11l_l1_ (u"ࠬ࠴ࡣࡰ࡯ࠩࠪࠬ㿥"),l1l11l_l1_ (u"࠭ࠧ㿦")).replace(l1l11l_l1_ (u"ࠧ࠯ࡥࡲࠪࠫ࠭㿧"),l1l11l_l1_ (u"ࠨࠩ㿨"))
						server = server.replace(l1l11l_l1_ (u"ࠩ࠱ࡲࡪࡺࠦࠧࠩ㿩"),l1l11l_l1_ (u"ࠪࠫ㿪")).replace(l1l11l_l1_ (u"ࠫ࠳ࡵࡲࡨࠨࠩࠫ㿫"),l1l11l_l1_ (u"ࠬ࠭㿬"))
						server = server.replace(l1l11l_l1_ (u"࠭࠮࡭࡫ࡹࡩࠫࠬࠧ㿭"),l1l11l_l1_ (u"ࠧࠨ㿮")).replace(l1l11l_l1_ (u"ࠨ࠰ࡲࡲࡱ࡯࡮ࡦࠨࠩࠫ㿯"),l1l11l_l1_ (u"ࠩࠪ㿰"))
						server = server.replace(l1l11l_l1_ (u"ࠪࠪࠫ࡮ࡤ࠯ࠩ㿱"),l1l11l_l1_ (u"ࠫࠬ㿲")).replace(l1l11l_l1_ (u"ࠬࠬࠦࡸࡹࡺ࠲ࠬ㿳"),l1l11l_l1_ (u"࠭ࠧ㿴"))
						server = server.replace(l1l11l_l1_ (u"ࠧࠧࠨࠪ㿵"),l1l11l_l1_ (u"ࠨࠩ㿶"))
						l1111l_l1_ = l1111l_l1_ + l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㿷") + name + server + l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㿸")
						l1ll1lll_l1_.append(l1111l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㿹"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭㿺"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧ㿻"): return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩ㿼"),l1l11l_l1_ (u"ࠨ࠭ࠪ㿽"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭㿾")+search
	l111l1_l1_(url)
	return
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠤࡸ࡫ࡣࡰࡰࡧࡥࡷࡿࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳ࡣࡢࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣࡩࡧࡦ࡯ࡲࡧࡲ࡬࠯ࡥࡳࡱࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡥࡤࡸࡪ࡭࡯ࡳࡻࠬࠎࠎࠏࠉࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ࠲ࠠࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵ࠥࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭ࠫࡴࡧࡤࡶࡨ࡮ࠫࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ࠱ࡣࡢࡶࡨ࡫ࡴࡸࡹࠋࠋࠌࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ㿿")
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭Ჴ")
menu_name = l1l11l_l1_ (u"࠭࡟ࡆࡉࡇࡣࠬᲵ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠧๆืสี฾ฯࠧᲶ"),l1l11l_l1_ (u"ࠨษะำะࠦวๅสิห๊าࠧᲷ"),l1l11l_l1_ (u"ࠩสัิัࠠศๆส่฾อศࠨᲸ"),l1l11l_l1_ (u"ࠪห้ืฦ๋ีํอࠬᲹ"),l1l11l_l1_ (u"ࠫฬำฯฬࠢส่ฬเว็๋ࠪᲺ")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l111l1_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l111ll_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ᲻"),l11lll_l1_,l1l11l_l1_ (u"࠭ࠧ᲼"),l1l11l_l1_ (u"ࠧࠨᲽ"),l1l11l_l1_ (u"ࠨࠩᲾ"),l1l11l_l1_ (u"ࠩࠪᲿ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᳀"))
	html = response.content
	l111llll1_l1_ = SERVER(l11lll_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ᳁"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᳂"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭᳃"),l1l11l_l1_ (u"ࠧࠨ᳄"),449,l1l11l_l1_ (u"ࠨࠩ᳅"),l1l11l_l1_ (u"ࠩࠪ᳆"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳇"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳈"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ᳉")+menu_name+l1l11l_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ᳊"),l11lll_l1_,441)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᳋"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᳌"),l1l11l_l1_ (u"ࠩࠪ᳍"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡡࡰࡩࡳࡻ࡟ࡳ࡫ࡪ࡬ࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᳎"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᳏"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1111l_l1_==l1l11l_l1_ (u"ࠬࠩࠧ᳐"): continue
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳑"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ᳒")+menu_name+title,l1111l_l1_,441)
	return
def l111l1_l1_(url,l1l11l1l_l1_=l1l11l_l1_ (u"ࠨࠩ᳓")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ᳔࡙࠭"),url,l1l11l_l1_ (u"᳕ࠪࠫ"),l1l11l_l1_ (u"᳖ࠫࠬ"),l1l11l_l1_ (u"᳗ࠬ࠭"),l1l11l_l1_ (u"᳘࠭ࠧ"),l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨ᳙ࠬ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ᳚"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠳ࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᳛"),block,re.DOTALL)
	for l1111l_l1_,title,img in items:
		if l1l11l_l1_ (u"ࠪ࠳ࡺࡸ࡬࠰᳜ࠩ") in l1111l_l1_: continue
		elif l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴᳝࠭") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ᳞ࠬ"),menu_name+title,l1111l_l1_,443,img)
		elif l1l11l_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰᳟ࠩ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳠"),menu_name+title,l1111l_l1_,443,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᳡"),menu_name+title,l1111l_l1_,442,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ᳢ࠫ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽᳣ࠩ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳤ࠫ"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮห᳥ࠣࠫ")+title,l1111l_l1_,441)
	return
l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࡥࡱࡲࡔࡪࡶ࡯ࡩࡸࠦ࠽ࠡ࡝ࡠࠎࠎࡼࡩࡥࡧࡲࡐࡎ࡙ࡔࠡ࠿ࠣ࡟๋ࠬิศ้าอࠬ࠲ࠧโ์็้ࠬ࠲ࠧศ฼้๎ฮ࠭ࠬࠨๅ็๎อ࠭ࠬࠨษ฼่ฬ์๊ࠧ࠭ࠩำฬ็่ࠧ࠭ࠩฬฬืวสࠩ࠯ࠫ฾ืึࠨ࠮้ࠪ์ืฬศ่ࠪ࠰ࠬอไษ๊่ࠫࡢࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥ࠭࡫ࡰ࡫ࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡺࡴࡥࡴࡥࡤࡴࡪࡎࡔࡎࡎࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡲࡩ࡯࡭ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮࡬ࡪࡰ࡮࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬ࠵ࠧࠪࠌࠌࠍࡪࡶࡩࡴࡱࡧࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ࠮ࡷ࡭ࡹࡲࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡥࡳࡿࠨࡷࡣ࡯ࡹࡪࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥࠡࡨࡲࡶࠥࡼࡡ࡭ࡷࡨࠤ࡮ࡴࠠࡷ࡫ࡧࡩࡴࡒࡉࡔࡖࠬ࠾ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡷ࡫ࡧࡩࡴ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠵࠶࠵࠰࡮ࡳࡧࠪࠌࠌࠍࡪࡲࡩࡧࠢࡨࡴ࡮ࡹ࡯ࡥࡧࠣࡥࡳࡪࠠࠨษ็ั้่ษࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪࡣࡒࡕࡄࡠࠩࠣ࠯ࠥ࡫ࡰࡪࡵࡲࡨࡪࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡦࠡࡶ࡬ࡸࡱ࡫ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡢ࡮࡯ࡘ࡮ࡺ࡬ࡦࡵ࠽ࠎࠎࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠷࠱࡯࡭ࡨࠫࠍࠍࠎࠏࠉࡢ࡮࡯ࡘ࡮ࡺ࡬ࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎ࡫࡬ࡪࡨࠣࠫ࠴ࡧࡳࡴࡧࡰࡦࡱࡿ࠯ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠵࠱࡯࡭ࡨࠫࠍࠍࠎ࡫࡬ࡪࡨࠣࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠴࠵࠵࠯࡭ࡲ࡭ࠩࠋࠋࠌࡩࡱࡹࡥ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠸࠲ࡩ࡮ࡩࠬࠎࠎ࡯ࡦࠡࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࡁࠬ࠭࠺ࠋࠋࡵࡩࡹࡻࡲ࡯ࠌ᳦ࠥࠦࠧ")
def l111ll_l1_(url):
	data = {l1l11l_l1_ (u"ࠧࡗ࡫ࡨࡻ᳧ࠬ"):1}
	headers = {l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫᳨ࠧ"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᳩ")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨᳪ"),url,data,headers,l1l11l_l1_ (u"ࠫࠬᳫ"),l1l11l_l1_ (u"ࠬ࠭ᳬ"),l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ᳭࠭"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡵࡨࡥࡸࡵ࡮ࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᳮ"),html,re.DOTALL)
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᳯ"),html,re.DOTALL)
	# l111lll1l_l1_
	if l111l11l1_l1_:
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᳰ"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),menu_name+title,l1111l_l1_,443,img)
	# l1l11l1_l1_
	elif l1ll1lll1_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠫࠧࡵࡧ࠻࡫ࡰࡥ࡬࡫ࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᳲ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᳳ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩ᳴"),l1l11l_l1_ (u"ࠧࠨᳵ")).strip(l1l11l_l1_ (u"ࠨࠢࠪᳶ"))
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᳷"),menu_name+title,l1111l_l1_,442,img)
	return
def PLAY(url):
	data = {l1l11l_l1_ (u"࡚ࠪ࡮࡫ࡷࠨ᳸"):1}
	headers = {l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ᳹"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫᳺ")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ᳻"),url,data,headers,l1l11l_l1_ (u"ࠧࠨ᳼"),l1l11l_l1_ (u"ࠨࠩ᳽"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ᳾"))
	html = response.content
	l1ll1lll_l1_ = []
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡼࡧࡴࡤࡪࡄࡶࡪࡧࡍࡢࡵࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᳿"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩᴀ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = title.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨᴁ"),l1l11l_l1_ (u"࠭ࠧᴂ")).strip(l1l11l_l1_ (u"ࠧࠡࠩᴃ"))
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᴄ")+title+l1l11l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᴅ")
			l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡩࡵ࡮ࡸ࡮ࡲࡥࡩ࠳ࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᴆ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡥࡳ࠯ࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᴇ"),block,re.DOTALL)
		for title,l1l1l1l1_l1_,l1111l_l1_ in items:
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨᴈ"),l1l11l_l1_ (u"࠭ࠧᴉ"))
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᴊ")+title+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᴋ")+l1l11l_l1_ (u"ࠩࡢࡣࡤࡥࠧᴌ")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᴍ"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᴎ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠬ࠭ᴏ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"࠭ࠧᴐ"): return
	search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩᴑ"),l1l11l_l1_ (u"ࠨ࠭ࠪᴒ"))
	#search = unescapeHTML(search)
	url = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡃࡸࡃࠧᴓ")+search
	l111l1_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ♗")
menu_name = l1l11l_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨ♘")
l11lll_l1_ = WEBSITES[script_name][0]
headers = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ♙"):l1l11l_l1_ (u"ࠫࠬ♚")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l111l1_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♛"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭♜"),l1l11l_l1_ (u"ࠧࠨ♝"),329,l1l11l_l1_ (u"ࠨࠩ♞"),l1l11l_l1_ (u"ࠩࠪ♟"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ♠"))
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ♡"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ♢"),l1l11l_l1_ (u"࠭ࠧ♣"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ♤"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ♥"),l1l11l_l1_ (u"ࠩࠪ♦"),headers,l1l11l_l1_ (u"ࠪࠫ♧"),l1l11l_l1_ (u"ࠫࠬ♨"),l1l11l_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ♩"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡤࡱࡱࡳ࠲ࡶ࡬ࡶࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ♪"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭♫"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title==l1l11l_l1_ (u"ࠨษ็้่ะศสࠢส่๊ืฦ๋หࠪ♬"): continue
		l1111l_l1_ = l11lll_l1_+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♭"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ♮")+menu_name+title,l1111l_l1_,321)
	return html
def l111l1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ♯"),l1l11l_l1_ (u"ࠬ࠭♰"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ♱"),url,l1l11l_l1_ (u"ࠧࠨ♲"),headers,l1l11l_l1_ (u"ࠨࠩ♳"),l1l11l_l1_ (u"ࠩࠪ♴"),l1l11l_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ♵"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡯ࡰࡶࡨࡶࠬ♶"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡱࡦ࠸ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ♷"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭♸"),block,re.DOTALL)
	for l1111l_l1_,img,count,title in items:
		count = count.replace(l1l11l_l1_ (u"ฺࠧัาࠤࠬ♹"),l1l11l_l1_ (u"ࠨࠩ♺")).replace(l1l11l_l1_ (u"ࠩࠣࠫ♻"),l1l11l_l1_ (u"ࠪࠫ♼"))
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠫ࠴࠭♽"),l1l11l_l1_ (u"ࠬ࠭♾"))
		img = img.replace(l1l11l_l1_ (u"ࠨࠧࠣ♿"),l1l11l_l1_ (u"ࠧࠨ⚀"))
		if l1l11l_l1_ (u"ࠨ࠰ࡳ࡬ࡵ࠭⚁") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ⚂")+l1111l_l1_
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࠬ⚃")+l1111l_l1_
		img = l11lll_l1_+img
		title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭⚄"))
		title = title+l1l11l_l1_ (u"ࠬࠦࠨࠨ⚅")+count+l1l11l_l1_ (u"࠭ࠩࠨ⚆")
		if l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪ⚇") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚈"),menu_name+title,l1111l_l1_,321,img)
		elif l1l11l_l1_ (u"ࠩࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬ⚉") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⚊"),menu_name+title,l1111l_l1_,322,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡯ࡰࡶࡨࡶࠬ⚋"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⚌"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪ⚍")+l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚎"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧ⚏")+title,l1111l_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⚐"),url,l1l11l_l1_ (u"ࠪࠫ⚑"),headers,l1l11l_l1_ (u"ࠫࠬ⚒"),l1l11l_l1_ (u"ࠬ࠭⚓"),l1l11l_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⚔"))
	html = response.content
	#l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡣࡸࡨ࡮ࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⚕"),html,re.DOTALL)
	#if not l1111l_l1_:
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡹ࡭ࡩ࡫࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⚖"),html,re.DOTALL)
	l1111l_l1_ = l11lll_l1_+l1111l_l1_[0]#+l1l11l_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ⚗")+l1ll11ll1_l1_()+l1l11l_l1_ (u"ࠪࠪࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡶࡵࡹࡪ࠭⚘")
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⚙"))
	return
def SEARCH(search):
	#search = l1l11l_l1_ (u"๋ࠬฮหษิࠫ⚚")
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧ⚛"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨ⚜"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ⚝"),l1l11l_l1_ (u"ࠩ࠮ࠫ⚞"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫ⚟")+search
	l111l1_l1_(url)
	return
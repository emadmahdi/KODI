# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭ㅗ")
headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨㅘ") : l1l11l_l1_ (u"ࠬ࠭ㅙ") }
menu_name = l1l11l_l1_ (u"࠭࡟ࡎࡘ࡝ࡣࠬㅚ")
l11lll_l1_ = WEBSITES[script_name][0]
l1lll1l1ll_l1_ = WEBSITES[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l111l1_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l111ll_l1_(url)
	elif mode==188: results = l11111111ll_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11111111ll_l1_():
	message = l1l11l_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬㅛ")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩㅜ"),l1l11l_l1_ (u"ࠩࠪㅝ"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ㅞ"),message)
	return
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅟ"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬㅠ"),l1l11l_l1_ (u"࠭ࠧㅡ"),189,l1l11l_l1_ (u"ࠧࠨㅢ"),l1l11l_l1_ (u"ࠨࠩㅣ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ㅤ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅥ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨㅦ")+menu_name+l1l11l_l1_ (u"ࠬฮ่ไีࠣหํ็๊ิ่ࠢ์ๆ๐าࠡๆส๊ิ࠭ㅧ"),l11lll_l1_,181,l1l11l_l1_ (u"࠭ࠧㅨ"),l1l11l_l1_ (u"ࠧࠨㅩ"),l1l11l_l1_ (u"ࠨࡤࡲࡼ࠲ࡵࡦࡧ࡫ࡦࡩࠬㅪ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㅫ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧㅬ")+menu_name+l1l11l_l1_ (u"ࠫศำฯฬࠢส่ฬ็ไศ็ࠪㅭ"),l11lll_l1_,181,l1l11l_l1_ (u"ࠬ࠭ㅮ"),l1l11l_l1_ (u"࠭ࠧㅯ"),l1l11l_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧㅰ"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㅱ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ㅲ")+menu_name+l1l11l_l1_ (u"ࠪฮ้๐แำ์๋๊๋่ࠥโ์ีࠤ้อๆะࠩㅳ"),l11lll_l1_,181,l1l11l_l1_ (u"ࠫࠬㅴ"),l1l11l_l1_ (u"ࠬ࠭ㅵ"),l1l11l_l1_ (u"࠭ࡴࡷࠩㅶ"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㅷ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬㅸ")+menu_name+l1l11l_l1_ (u"ࠩส่ฬ้หาุ่ࠢฬํฯสࠩㅹ"),l11lll_l1_,181,l1l11l_l1_ (u"ࠪࠫㅺ"),l1l11l_l1_ (u"ࠫࠬㅻ"),l1l11l_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨㅼ"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅽ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫㅾ")+menu_name+l1l11l_l1_ (u"ࠨลๅ์๎ࠦวๅษไ่ฬ๋ࠠศๆะห้๐ษࠨㅿ"),l11lll_l1_,181,l1l11l_l1_ (u"ࠩࠪㆀ"),l1l11l_l1_ (u"ࠪࠫㆁ"),l1l11l_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨㆂ"))
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭ㆃ"),headers,l1l11l_l1_ (u"࠭ࠧㆄ"),l1l11l_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬㆅ"))
	items = re.findall(l1l11l_l1_ (u"ࠨ࠾࡫࠶ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫㆆ"),html,re.DOTALL)
	for l1111l_l1_,title in items:
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆇ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧㆈ")+menu_name+title,l1111l_l1_,181)
	return html
def l111l1_l1_(url,type=l1l11l_l1_ (u"ࠫࠬㆉ")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠬ࠭ㆊ"),headers,l1l11l_l1_ (u"࠭ࠧㆋ"),l1l11l_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭ㆌ"))
	if type==l1l11l_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨㆍ"): block = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀฦัิัࠠศๆฦๅ้อๅ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࡭࠷ࠧㆎ"),html,re.DOTALL)[0]
	elif type==l1l11l_l1_ (u"ࠪࡦࡴࡾ࠭ࡰࡨࡩ࡭ࡨ࡫ࠧ㆏"): block = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࡪ࠴ࠫ㆐"),html,re.DOTALL)[0]
	elif type==l1l11l_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㆑"): block = re.findall(l1l11l_l1_ (u"࠭ࡢࡵࡰ࠰࠶࠲ࡵࡶࡦࡴ࡯ࡥࡾ࠮࠮ࠫࡁࠬࡀࡸࡺࡹ࡭ࡧࡁࠫ㆒"),html,re.DOTALL)[0]
	elif type==l1l11l_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ㆓"): block = re.findall(l1l11l_l1_ (u"ࠨࡤࡷࡲ࠲࠷ࠠࡣࡶࡱ࠱ࡦࡨࡳࡰ࡮ࡼࠬ࠳࠰࠿ࠪࡤࡷࡲ࠲࠸ࠠࡣࡶࡱ࠱ࡦࡨࡳࡰ࡮ࡼࠫ㆔"),html,re.DOTALL)[0]
	elif type==l1l11l_l1_ (u"ࠩࡷࡺࠬ㆕"): block = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฮ้๐แำ์๋๊๋่ࠥโ์ีࠤ้อๆะ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡪࠦࠬ㆖"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l11l_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ㆗"),l1l11l_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㆘")]:
		items = re.findall(l1l11l_l1_ (u"࠭ࡳࡵࡻ࡯ࡩࡂࠨࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡱࡷࡸࡴࡳ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㆙"),block,re.DOTALL)
	else: items = re.findall(l1l11l_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺ࠽ࠣ࠵࡞࠴࠲࠿࡝ࠬࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡺࡴࡰ࡯࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㆚"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l1l11l11l_l1_ = [l1l11l_l1_ (u"ࠨใํ่๊࠭㆛"),l1l11l_l1_ (u"ࠩส่า๊โสࠩ㆜"),l1l11l_l1_ (u"ࠪห้ำไใ้ࠪ㆝"),l1l11l_l1_ (u"ࠫ฾ืึࠨ㆞"),l1l11l_l1_ (u"ࠬࡘࡡࡸࠩ㆟"),l1l11l_l1_ (u"࠭ࡓ࡮ࡣࡦ࡯ࡉࡵࡷ࡯ࠩㆠ"),l1l11l_l1_ (u"ࠧศ฻็ห๋࠭ㆡ"),l1l11l_l1_ (u"ࠨษฯึฬวࠧㆢ")]
	for img,l1lllllll111_l1_,l1111111l11_l1_,l1111111l1l_l1_ in items:
		if type in [l1l11l_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬㆣ"),l1l11l_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧㆤ")]:
			img,l1111l_l1_,l11l111l1_l1_,title = img,l1lllllll111_l1_,l1111111l11_l1_,l1111111l1l_l1_
		else: img,title,l1111l_l1_,l11l111l1_l1_ = img,l1lllllll111_l1_,l1111111l11_l1_,l1111111l1l_l1_
		l1111l_l1_ = UNQUOTE(l1111l_l1_)
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠫࡄࡼࡩࡦࡹࡀࡸࡷࡻࡥࠨㆥ"),l1l11l_l1_ (u"ࠬ࠭ㆦ"))
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧㆧ"),l1l11l_l1_ (u"ࠧࠨㆨ"),l1111l_l1_,l11l111l1_l1_)
		title = unescapeHTML(title)
		#title2 = re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠨษฮ๋ำฮࢂศอ๊า๋࠮࠭ㆩ"),title,re.DOTALL)
		#if title2: title = title2[0][0]
		if l1l11l_l1_ (u"ࠩหะํีษࠡࠩㆪ") in title or l1l11l_l1_ (u"ࠪฬั๎ฯ่ࠢࠪㆫ") in title:
			title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪㆬ") + title.replace(l1l11l_l1_ (u"ࠬฮฬ้ัฬࠤࠬㆭ"),l1l11l_l1_ (u"࠭ࠧㆮ")).replace(l1l11l_l1_ (u"ࠧษฮ๋ำ์ࠦࠧㆯ"),l1l11l_l1_ (u"ࠨࠩㆰ"))
		title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫㆱ"))
		if l1l11l_l1_ (u"ࠪห้ำไใหࠪㆲ") in title or l1l11l_l1_ (u"ࠫฬ๊อๅไ๊ࠫㆳ") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁอไฮๆๅ๋࠮ࠦ࡜ࡥ࠭ࠪㆴ"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬㆵ") + l1ll1ll_l1_[0][0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆶ"),menu_name+title,l1111l_l1_,183,img)
					l1l1l11_l1_.append(title)
		elif any(value in title for value in l1l11l11l_l1_):
			l1111l_l1_ = l1111l_l1_ + l1l11l_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫㆷ") + l11l111l1_l1_
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㆸ"),menu_name+title,l1111l_l1_,182,img)
		else:
			l1111l_l1_ = l1111l_l1_ + l1l11l_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭ㆹ") + l11l111l1_l1_
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆺ"),menu_name+title,l1111l_l1_,183,img)
	if type==l1l11l_l1_ (u"ࠬ࠭ㆻ"):
		items = re.findall(l1l11l_l1_ (u"࠭࡜࡯࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪㆼ"),html,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠧศๆุๅาฯࠠࠨㆽ"),l1l11l_l1_ (u"ࠨࠩㆾ"))
			if title!=l1l11l_l1_ (u"ࠩࠪㆿ"):
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㇀"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪ㇁")+title,l1111l_l1_,181)
	return
def l111ll_l1_(url):
	url2 = url.split(l1l11l_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ㇂"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"࠭ࠧ㇃"),headers,l1l11l_l1_ (u"ࠧࠨ㇄"),l1l11l_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ㇅"))
	block = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷ࡭ࡹࡲࡥ࠿࠰࠭ࡃ࡭࡫ࡩࡨࡪࡷࡁࠧ࠮࡛࠱࠯࠼ࡡ࠰࠯ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㇆"),html,re.DOTALL)
	title,dummy,img = block[0]
	name = re.findall(l1l11l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡠ࠶࠭࠺࡟࠮ࠫ㇇"),title,re.DOTALL)
	if name: name = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㇈") + name[0][0]
	else: name = title
	items = []
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡰࡪࡵࡲࡨࡪࡹࡎࡶ࡯ࡥࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㇉"),html,re.DOTALL)
	if l1ll111_l1_:
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㇊"),l1l11l_l1_ (u"ࠧࠨ㇋"),url2,str(l1ll111_l1_))
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㇌"),block,re.DOTALL)
		for l1111l_l1_ in items:
			l1111l_l1_ = UNQUOTE(l1111l_l1_)
			title = re.findall(l1l11l_l1_ (u"ࠩࠫห้ำไใหࡿห้ำไใ้ࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭㇍"),l1111l_l1_.split(l1l11l_l1_ (u"ࠪ࠳ࠬ㇎"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l11l_l1_ (u"ࠫ࠭࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ㇏"),l1111l_l1_.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㇐"))[-2],re.DOTALL)
			if title: title = l1l11l_l1_ (u"࠭ࠠࠨ㇑") + title[0][1]
			else: title = l1l11l_l1_ (u"ࠧࠨ㇒")
			title = name + l1l11l_l1_ (u"ࠨࠢ࠰ࠤࠬ㇓") + l1l11l_l1_ (u"ࠩส่า๊โสࠩ㇔") + title
			title = unescapeHTML(title)
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㇕"),menu_name+title,l1111l_l1_,182,img)
	if not items:
		title = unescapeHTML(title)
		if l1l11l_l1_ (u"ࠫอา่ะหࠣࠫ㇖") in title or l1l11l_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ㇗") in title:
			title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ㇘") + title.replace(l1l11l_l1_ (u"ࠧษฮ๋ำฮࠦࠧ㇙"),l1l11l_l1_ (u"ࠨࠩ㇚")).replace(l1l11l_l1_ (u"ࠩหะํี็ࠡࠩ㇛"),l1l11l_l1_ (u"ࠪࠫ㇜"))
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㇝"),menu_name+title,url,182,img)
	return
def PLAY(url):
	l1111111ll1_l1_ = url.split(l1l11l_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ㇞"))
	url2 = l1111111ll1_l1_[0]
	del l1111111ll1_l1_[0]
	html = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"࠭ࠧ㇟"),headers,l1l11l_l1_ (u"ࠧࠨ㇠"),l1l11l_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㇡"))
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡩࡳࡳࡺ࠭ࡴ࡫ࡽࡩ࠿ࠦ࠲࠶ࡲࡻ࠿ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㇢"),html,re.DOTALL)[0]
	if l1111l_l1_ not in l1111111ll1_l1_: l1111111ll1_l1_.append(l1111l_l1_)
	l1ll1lll_l1_ = []
	# l1111111111_l1_
	for l1111l_l1_ in l1111111ll1_l1_:
		if l1l11l_l1_ (u"ࠪ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ㇣") in l1111l_l1_:
			l1111111111_l1_ = l1111l_l1_
			l1ll1lll_l1_.append(l1111111111_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡒࡧࡩ࡯ࠩ㇤"))
	# l1llllllllll_l1_
	for l1111l_l1_ in l1111111ll1_l1_:
		if l1l11l_l1_ (u"ࠬࡀ࠯࠰ࡸࡥ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠨ㇥") in l1111l_l1_:
			html = OPENURL_CACHED(l1llll_l1_,l1111l_l1_,l1l11l_l1_ (u"࠭ࠧ㇦"),headers,l1l11l_l1_ (u"ࠧࠨ㇧"),l1l11l_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭㇨"))
			html = html.decode(l1l11l_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵ࠰࠵࠷࠻࠶ࠨ㇩")).encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇪"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l1llllll1lll_l1_><l1lllllll1ll_l1_ /><l1llllll1lll_l1_ l11111111l1_l1_=l1l11l_l1_ (u"ࠦࡨ࡫࡮ࡵࡧࡵࠦ㇫")>(\*\*\*\*\*\*\*\*|13721411411.l1llllll1l1l_l1_|)
			html = html.replace(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡦࡳࡲ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ㇬"),l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ㇭"))
			html = html.replace(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ㇮"),l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ㇯"))
			html = html.replace(l1l11l_l1_ (u"ࠩ࠿࠳ࡦࡄ࠼࠰ࡦ࡬ࡺࡃࡂࡢࡳࠢ࠲ࡂࡁࡪࡩࡷࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࡁࠫㇰ"),l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭ㇱ"))
			html = html.replace(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹࡨ࡯ࡳࡦࡨࡶࠧࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨࠧㇲ"),l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨㇳ"))
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭ㇴ"),html,re.DOTALL)
			if l1ll111_l1_:
				#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨㇵ"),l1l11l_l1_ (u"ࠨࠩㇶ"),url,str(len(l1ll111_l1_)))
				l1llllll1ll1_l1_,l1lllllllll1_l1_ = [],[]
				if len(l1ll111_l1_)==1:
					title = l1l11l_l1_ (u"ࠩࠪㇷ")
					block = html
				else:
					for block in l1ll111_l1_:
						l1l11lll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠯ࠬࡂࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࡞࠭࠯࠭࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬㇸ"),block,re.DOTALL)
						if l1l11lll_l1_: block = l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭ㇹ") + l1l11lll_l1_[0][1]
						l1l11lll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳ࠣࠢ࠲ࡂ࠭࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩㇺ"),block,re.DOTALL)
						if l1l11lll_l1_: block = l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࠨㇻ") + l1l11lll_l1_[0]
						l1l11lll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂ࠭ࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴ࠤࠣ࠳ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫㇼ"),block,re.DOTALL)
						if l1l11lll_l1_: block = l1l11lll_l1_[0] + l1l11l_l1_ (u"ࠨࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪㇽ")
						l111111111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿ࠬ࠳࠰࠿ࠪࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯ࠨㇾ"),block,re.DOTALL)
						title = re.findall(l1l11l_l1_ (u"ࠪࡂࠥ࠰ࠨ࡜ࡠ࠿ࡂࡢ࠱ࠩࠡࠬ࠿ࠫㇿ"),l111111111l_l1_[0][0],re.DOTALL)
						title = l1l11l_l1_ (u"ࠫࠥ࠭㈀").join(title)
						title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ㈁"))
						title = title.replace(l1l11l_l1_ (u"࠭ࠠࠡࠩ㈂"),l1l11l_l1_ (u"ࠧࠡࠩ㈃")).replace(l1l11l_l1_ (u"ࠨࠢࠣࠫ㈄"),l1l11l_l1_ (u"ࠩࠣࠫ㈅")).replace(l1l11l_l1_ (u"ࠪࠤࠥ࠭㈆"),l1l11l_l1_ (u"ࠫࠥ࠭㈇")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ㈈"),l1l11l_l1_ (u"࠭ࠠࠨ㈉")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ㈊"),l1l11l_l1_ (u"ࠨࠢࠪ㈋"))
						l1llllll1ll1_l1_.append(title)
					selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษ࠼ࠪ㈌"), l1llllll1ll1_l1_)
					if selection == -1 : return
					title = l1llllll1ll1_l1_[selection]
					block = l1ll111_l1_[selection]
				l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰ࠮ࠨࠧ㈍"),block,re.DOTALL)
				l1llllllll11_l1_ = l1111l_l1_[0]
				l1ll1lll_l1_.append(l1llllllll11_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡋࡵࡲࡶ࡯ࠪ㈎"))
				block = block.replace(l1l11l_l1_ (u"ࠬๆࠧ㈏"),l1l11l_l1_ (u"࠭ࠧ㈐"))
				block = block.replace(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ㈑"),l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ㈒"))
				block = block.replace(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࡣࡰ࡯࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ㈓"),l1l11l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭㈔"))
				block = block.replace(l1l11l_l1_ (u"ุࠫ๐ัโำสฮࠥอไหฯ่๎้࠭㈕"),l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ㈖"))
				block = block.replace(l1l11l_l1_ (u"࠭ั้ษห฻ࠥอไหฯ่๎้࠭㈗"),l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ㈘"))
				block = block.replace(l1l11l_l1_ (u"ࠨีํีๆืวหࠢสฺ่๊ว่ัࠪ㈙"),l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭㈚"))
				block = block.replace(l1l11l_l1_ (u"ࠪีํอศุࠢสฺ่๊ว่ัࠪ㈛"),l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ㈜"))
				l1lllllll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯࡝ࡦ࠮ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ㈝"),block,re.DOTALL)
				for l1llllllll1l_l1_ in l1lllllll11l_l1_:
					#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㈞"),l1l11l_l1_ (u"ࠧࠨ㈟"),l1l11l_l1_ (u"ࠨࠩ㈠"),str(l1llllllll1l_l1_))
					type = re.findall(l1l11l_l1_ (u"ࠩࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࠧ㈡"),l1llllllll1l_l1_)
					if type:
						if type[0]!=l1l11l_l1_ (u"ࠪࡦࡴࡺࡨࠨ㈢"): type = l1l11l_l1_ (u"ࠫࡤࡥࠧ㈣")+type[0]
						else: type = l1l11l_l1_ (u"ࠬ࠭㈤")
					items = re.findall(l1l11l_l1_ (u"࠭ࠨࡀ࠾ࠤ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯ࠪࠪ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮ࡁ࠵ࡦࡰࡰࡷࡂ࠳࠰࠿ࡽ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀࡧࡸࠠ࠰ࡀ࠱࠮ࡄ࠯ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲࠲࠯ࡅࠩࠣࠩ㈥"),l1llllllll1l_l1_,re.DOTALL)
					for l1lllllll1l1_l1_,l1111l_l1_ in items:
						title = re.findall(l1l11l_l1_ (u"ࠧࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭࠭ࡁ࠭㈦"),l1lllllll1l1_l1_)
						title = title[-1]
						l1111l_l1_ = l1111l_l1_ + l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㈧") + title + type
						l1ll1lll_l1_.append(l1111l_l1_)
	# l1111111lll_l1_
	url3 = url2.replace(l11lll_l1_,l1lll1l1ll_l1_)
	html = OPENURL_CACHED(l1llll_l1_,url3,l1l11l_l1_ (u"ࠩࠪ㈨"),headers,l1l11l_l1_ (u"ࠪࠫ㈩"),l1l11l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ㈪"))
	items = re.findall(l1l11l_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㈫"),html,re.DOTALL)
	#l1lll11l11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰ࡧࡰࡦࡪࡪࡍ࠮ࠪ࡟ࡻ࠰࠯࠭࠯ࠬࡂ࠲࡭ࡺ࡭࡭ࠫࠪ㈬"),html,re.DOTALL)
	#if l1lll11l11_l1_:
	if items:
		#l1111111lll_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࠪ㈭") + l1lll11l11_l1_[-1] + l1l11l_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ㈮")
		l1111111lll_l1_ = items[-1]
		l1ll1lll_l1_.append(l1111111lll_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡐࡳࡧ࡯࡬ࡦࠩ㈯"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㈰"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬ㈱"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭㈲"): return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ㈳"),l1l11l_l1_ (u"ࠧࠬࠩ㈴"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ㈵"),headers,l1l11l_l1_ (u"ࠩࠪ㈶"),l1l11l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ㈷"))
	items = re.findall(l1l11l_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࡃ࠭㈸"),html,re.DOTALL)
	l1l111lll_l1_ = [ l1l11l_l1_ (u"ࠬ࠭㈹") ]
	l11llllll_l1_ = [ l1l11l_l1_ (u"࠭วๅๅ็ࠤํฮฯ้่ࠣๅ้ะัࠨ㈺") ]
	for category,title in items:
		l1l111lll_l1_.append(category)
		l11llllll_l1_.append(title)
	if category:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧศะอีࠥอไโๆอีࠥอไๆ่สือࡀࠧ㈻"), l11llllll_l1_)
		if selection == -1 : return
		category = l1l111lll_l1_[selection]
	else: category = l1l11l_l1_ (u"ࠨࠩ㈼")
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ㈽")+search+l1l11l_l1_ (u"ࠪࠪࡲࡩࡡࡵ࠿ࠪ㈾")+category
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㈿"),l1l11l_l1_ (u"ࠬ࠭㉀"),url,url)
	l111l1_l1_(url)
	return
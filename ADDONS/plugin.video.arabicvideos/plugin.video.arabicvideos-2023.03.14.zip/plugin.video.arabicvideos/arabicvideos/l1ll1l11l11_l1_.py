# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䬉")
menu_name = l1l11l_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ䬊")
l11lll_l1_ = WEBSITES[script_name][0]
#headers = l1l11l_l1_ (u"ࠪࠫ䬋")
#headers = {l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䬌"):l1l11l_l1_ (u"ࠬ࠭䬍")}
l11l1ll1ll1l_l1_ = 0
def MAIN(mode,url,text,type,page):
	if	 mode==140: results = MENU()
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l111l1_l1_(url,page,text)
	elif mode==145: results = l11ll11ll11l_l1_(url,page)
	elif mode==147: results = l11ll11111l1_l1_()
	elif mode==148: results = l11ll1111l11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䬎"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䬏")+menu_name+l1l11l_l1_ (u"ࠨไสส๊ฯࠧ䬐"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡇࡪ࠶ࡉࡶ࠼ࡋࡎ࠸࡛ࡰࡘࡦࡋ࠶ࡒࡗ࠯࠺ࡋ࠸ࡈ࡯ࡲࡋࡼ࡞ࡆ࠺ࡵࡔࡃࠪ䬑"),144)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䬒"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䬓")+menu_name+l1l11l_l1_ (u"ฺࠬฮึࠩ䬔"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ䬕"),144)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䬖"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ䬗")+menu_name+l1l11l_l1_ (u"่ࠩ์็฿ࠧ䬘"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࡛ࡃࡲ࠷࠼ࡥࡌࡔࡳࡲ࠻ࡥࡦ࡭ࡽࡖࡕࡳ࠴࡙ࡹࡼࡧࡸࠩ䬙"),144)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䬚"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䬛")+menu_name+l1l11l_l1_ (u"࠭อิษหࠫ䬜"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡂࡗ࡬ࡪ࡙࡯ࡤ࡫ࡤࡰࡈ࡚ࡖࠨ䬝"),144)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䬞"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䬟")+menu_name+l1l11l_l1_ (u"ࠪห้฿วษࠩ䬠"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ䬡"),144)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䬢"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ䬣")+menu_name+l1l11l_l1_ (u"ࠧศใ็ห๊࠭䬤"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡴࡶࡲࡶࡪ࡬ࡲࡰࡰࡷࠫ䬥"),144)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䬦"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䬧")+menu_name+l1l11l_l1_ (u"๊ࠫิสศำสฮࠬ䬨"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ䬩"),144)
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䬪"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䬫")+menu_name+l1l11l_l1_ (u"ࠨไุ๎ึฯࠧ䬬"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ䬭"),144,l1l11l_l1_ (u"ࠪࠫ䬮"),l1l11l_l1_ (u"ࠫࠬ䬯"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䬰"))
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䬱"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䬲")+menu_name+l1l11l_l1_ (u"ࠨฬุๅา࠭䬳"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ䬴"),144)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䬵"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䬶")+menu_name+l1l11l_l1_ (u"ࠬืฦ๋ีํอࠬ䬷"),l11lll_l1_+l1l11l_l1_ (u"࠭ࠧ䬸"),144)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䬹"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ䬺")+menu_name+l1l11l_l1_ (u"ࠩิหหาࠧ䬻"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࡃࡧࡶ࠽ࠨ䬼"),144)
		addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䬽"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䬾"),l1l11l_l1_ (u"࠭ࠧ䬿"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䭀"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䭁"),l1l11l_l1_ (u"ࠩࠪ䭂"),149,l1l11l_l1_ (u"ࠪࠫ䭃"),l1l11l_l1_ (u"ࠫࠬ䭄"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䭅"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭆"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䭇")+menu_name+l1l11l_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ䭈"),l11lll_l1_+l1l11l_l1_ (u"ࠩࠪ䭉"),144)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䭊"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䭋")+menu_name+l1l11l_l1_ (u"ࠬอไาษษะฮ࠭䭌"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ䭍"),144)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䭎"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ䭏")+menu_name+l1l11l_l1_ (u"ࠩส่ฯ฻แฮࠩ䭐"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭䭑"),144)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭒"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䭓")+menu_name+l1l11l_l1_ (u"࠭วๅไุ๎ึฯࠧ䭔"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ䭕"),144,l1l11l_l1_ (u"ࠨࠩ䭖"),l1l11l_l1_ (u"ࠩࠪ䭗"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䭘"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭙"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䭚")+menu_name+l1l11l_l1_ (u"࠭ๅฯฬสีฬะ๋๊ࠠอ๎ํฮࠧ䭛"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭䭜"),144)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䭝"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䭞")+l1l11l_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ䭟")+l1l11l_l1_ (u"๊ࠫิสศำสฮࠥอไษำ้ห๊าࠧ䭠"),l1l11l_l1_ (u"ࠬ࠭䭡"),290)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䭢"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䭣"),l1l11l_l1_ (u"ࠨࠩ䭤"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䭥"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䭦")+menu_name+l1l11l_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ䭧"),l1l11l_l1_ (u"ࠬ࠭䭨"),147)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䭩"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䭪")+menu_name+l1l11l_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ䭫"),l1l11l_l1_ (u"ࠩࠪ䭬"),148)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䭭"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䭮")+menu_name+l1l11l_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ䭯"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ䭰"),144)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䭱"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ䭲")+menu_name+l1l11l_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭䭳"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ䭴"),144)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䭵"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䭶")+menu_name+l1l11l_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ䭷"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ䭸"),144)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䭹"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䭺")+menu_name+l1l11l_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ䭻"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ䭼"),144)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䭽"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ䭾")+menu_name+l1l11l_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭䭿"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ䮀"),144)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䮁"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䮂")+menu_name+l1l11l_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ䮃"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ䮄"),144)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䮅"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䮆")+menu_name+l1l11l_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭䮇"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭䮈"),144)
	return
def l11ll11111l1_l1_():
	l111l1_l1_(l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭หฯࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ䮉"))
	return
def l11ll1111l11_l1_():
	l111l1_l1_(l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡺࡶࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭䮊"))
	return
def PLAY(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䮋"),l1l11l_l1_ (u"࠭ࠧ䮌"),l1l11l_l1_ (u"ࠧࠨ䮍"),url)
	#url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ䮎")
	#items = re.findall(l1l11l_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ䮏"),url,re.DOTALL)
	#id = items[0]
	#l1111l_l1_ = l1l11l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ䮐")+id
	#PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䮑"))
	#return
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࠱ࠫࠬ࠭࠮࠯ࠥࠦࠧࠬࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡶ࠭࠮ࠐࠉࡦࡴࡵࡳࡷࡹࠬࡵ࡫ࡷࡰࡪࡹࠬ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠫࡹࡷࡲࠩࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏࠩ࡮࡬ࡲࡰࡹ࡛࠱࡟࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࡶࡼࡴࡪ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ䮒")
	url = url.split(l1l11l_l1_ (u"࠭ࠦࠨ䮓"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l11l1llll1l1_l1_(cc,url,index):
	level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = index.split(l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䮔"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䮕"),l1l11l_l1_ (u"ࠩࠪ䮖"),index,l1l11l_l1_ (u"ࠪࡊࡎࡘࡓࡕࠩ䮗")+l1l11l_l1_ (u"ࠫࡡࡴࠧ䮘")+url)
	l11l1ll1l11l_l1_,l11l1ll1l1ll_l1_ = [],[]
	# l1ll1111l1ll_l1_ l11ll111lll1_l1_    should be the first item in the l11l1ll1l11l_l1_ list
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡁࡤࡶ࡬ࡳࡳࡹࠧ࡞ࠤ䮙"))
	# l1ll1111l1ll_l1_ search l11ll111l111_l1_      should be the first item in the l11l1ll1l11l_l1_ list
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠࠦ䮚"))
	# main page
	if level==l1l11l_l1_ (u"ࠧ࠲ࠩ䮛"): l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ䮜"))
	# search results
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ䮝"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠࠦ䮞"))
	# l11ll1111ll1_l1_ l11ll111111l_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡨࡩ࡛ࠨࡧࡱࡸࡷ࡯ࡥࡴࠩࡠࠦ䮟"))
	# l11l1llll1ll_l1_ l11111l1l_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡩࡣ࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟࡞࠷ࡢࡡࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䮠"))
	l11ll111l11l_l1_,dd,l11l1ll111ll_l1_ = l11l1ll11lll_l1_(cc,l1l11l_l1_ (u"࠭ࠧ䮡"),l11l1ll1l11l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ䮢"),str(dd))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䮣"),l1l11l_l1_ (u"ࠩࠪ䮤"),l1l11l_l1_ (u"ࠪࠫ䮥"),str(len(dd)))
	if level==l1l11l_l1_ (u"ࠫ࠶࠭䮦") and l11ll111l11l_l1_:
		if len(dd)>1 and l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ䮧") not in url:
			for zz in range(len(dd)):
				l11l1lll11l1_l1_ = str(zz)
				l11l1ll1l11l_l1_ = []
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡤࡥ࡝ࠥ䮨")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ䮩"))
				# l11ll1111ll1_l1_ l11ll111111l_l1_
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡦࡧ࡟ࠧ䮪")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠤࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩ࠭࡝ࠣ䮫"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡨࡩࡡࠢ䮬")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠦࡢࠨ䮭"))
				succeeded,item,l1l11l1l_l1_ = l11l1ll11lll_l1_(dd,l1l11l_l1_ (u"ࠬ࠭䮮"),l11l1ll1l11l_l1_)
				if succeeded: l11l1ll1l1ll_l1_.append([item,url,l1l11l_l1_ (u"࠭࠲࠻࠼ࠪ䮯")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ䮰")])
				#success = l11ll11l11ll_l1_(item,url,l1l11l_l1_ (u"ࠨ࠴࠽࠾ࠬ䮱")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ䮲"))
				#if success: l11l1lll1l1l_l1_ += 1
				#succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,token = l11ll11lll1l_l1_(item)
				#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䮳"),menu_name+title,l1111l_l1_,144,l1l11l_l1_ (u"ࠫࠬ䮴"),l1l11l_l1_ (u"ࠬ࠸࠺࠻ࠩ䮵")+l11l1lll11l1_l1_+l1l11l_l1_ (u"࠭࠺࠻࠲࠽࠾࠵࠭䮶"))
				#l11l1lll1l1l_l1_ += 1
	return dd,l11ll111l11l_l1_,l11l1ll1l1ll_l1_,l11l1ll111ll_l1_
def l11l1ll11l11_l1_(cc,dd,url,index):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䮷"),l1l11l_l1_ (u"ࠨࠩ䮸"),index,l1l11l_l1_ (u"ࠩࡖࡉࡈࡕࡎࡅࠩ䮹")+l1l11l_l1_ (u"ࠪࡠࡳ࠭䮺")+url)
	level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = index.split(l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䮻"))
	l11l1ll1l11l_l1_,l11l1lllll11_l1_ = [],[]
	# search results
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ䮼"))
	# main page
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡤࡥ࡝ࠥ䮽")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ䮾"))
	# l1ll1111l1ll_l1_ search & l11ll111lll1_l1_ & l11ll111l111_l1_
	if l1l11l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ䮿") in url: l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ䯀"))
	elif l1l11l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ䯁") in url: l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ䯂"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡪࡤ࡜ࠤ䯃")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ䯄"))
	# l1lllll1l1ll_l1_ l1ll1ll1l1_l1_ filter
	if l1l11l_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ䯅") in url: l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡦࡧ࡟ࠧ䯆")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䯇"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡨࡩࡡࠢ䯈")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ䯉"))
	# l11ll1111ll1_l1_ search
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡪࡤ࡜ࠤ䯊")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠨ࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ䯋"))
	# main page
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡥࡦ࡞ࠦ䯌")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ䯍"))
	# l1ll1111l1ll_l1_ l11ll111lll1_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡧࡨࡠࠨ䯎")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠥࡡࠧ䯏"))
	l11ll1111l1l_l1_,ee,l11l1lll1lll_l1_ = l11l1ll11lll_l1_(dd,l1l11l_l1_ (u"ࠫࠬ䯐"),l11l1ll1l11l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䯑"),str(ee))
	#DIALOG_OK()
	if level==l1l11l_l1_ (u"࠭࠲ࠨ䯒") and l11ll1111l1l_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l11l1ll1l11l_l1_ = []
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧ࡞ࠦ䯓")+index2+l1l11l_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ䯔"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡨࡩࡠࠨ䯕")+index2+l1l11l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ䯖"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡪ࡫࡛ࠣ䯗")+index2+l1l11l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ䯘"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡥࡦ࡝ࠥ䯙")+index2+l1l11l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ䯚"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡧࡨ࡟ࠧ䯛")+index2+l1l11l_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ䯜"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡩࡪࡡࠢ䯝")+index2+l1l11l_l1_ (u"ࠦࡢࠨ䯞"))
				succeeded,item,l1l11l1l_l1_ = l11l1ll11lll_l1_(ee,l1l11l_l1_ (u"ࠬ࠭䯟"),l11l1ll1l11l_l1_)
				if succeeded: l11l1lllll11_l1_.append([item,url,l1l11l_l1_ (u"࠭࠳࠻࠼ࠪ䯠")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䯡")+index2+l1l11l_l1_ (u"ࠨ࠼࠽࠴ࠬ䯢")])
				#success = l11ll11l11ll_l1_(item,url,l1l11l_l1_ (u"ࠩ࠶࠾࠿࠭䯣")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠪ࠾࠿࠭䯤")+index2+l1l11l_l1_ (u"ࠫ࠿ࡀ࠰ࠨ䯥"))
				#if success: l11ll1111lll_l1_ += 1
				#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䯦"),str(l1l11l1l_l1_)+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ䯧")+str(item))
				#l11ll1111lll_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,token = l11ll11lll1l_l1_(item)
				#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䯨"),menu_name+title,l1111l_l1_,144,img,l1l11l_l1_ (u"ࠨ࠵࠽࠾ࠬ䯩")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䯪")+index2+l1l11l_l1_ (u"ࠪ࠾࠿࠶ࠧ䯫"))
			# search l11ll111l111_l1_
			l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠳ࡠࠦ䯬"))
			# search l11ll111l111_l1_
			l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡪࡤ࡜࠳ࡠࠦ䯭"))
			succeeded,item,l1l11l1l_l1_ = l11l1ll11lll_l1_(dd,l1l11l_l1_ (u"࠭ࠧ䯮"),l11l1ll1l11l_l1_)
			if succeeded and l11l1lllll11_l1_ and l1l11l_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ䯯") in list(item.keys()):
				l11l1lllll11_l1_.append([item,url,l1l11l_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ䯰")])
			#success = l11ll11l11ll_l1_(item,url,l1l11l_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭䯱"))
			#if success: l11ll1111lll_l1_ += 1
			#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ䯲"),str(item))
			#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ䯳"),l1111l_l1_+l1l11l_l1_ (u"ࠬࠦࠠࠡࠩ䯴")+token)
	return ee,l11ll1111l1l_l1_,l11l1lllll11_l1_,l11l1lll1lll_l1_
def l11l1ll1ll11_l1_(cc,ee,url,index):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䯵"),l1l11l_l1_ (u"ࠧࠨ䯶"),index,l1l11l_l1_ (u"ࠨࡖࡋࡍࡗࡊࠧ䯷")+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䯸")+url)
	level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = index.split(l1l11l_l1_ (u"ࠪ࠾࠿࠭䯹"))
	l11l1ll1l11l_l1_,l11l1llll11l_l1_ = [],[]
	# search results
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡪ࡫࡛ࠣ䯺")+index2+l1l11l_l1_ (u"ࠧࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䯻"))
	# l1ll1111l1ll_l1_ l11ll111lll1_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡥࡦ࡝ࠥ䯼")+index2+l1l11l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ䯽"))
	# l11ll11l11l1_l1_ l11111l1l_l1_ l11ll111111l_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡧࡨ࡟ࠧ䯾")+index2+l1l11l_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ䯿"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡩࡪࡡࠢ䰀")+index2+l1l11l_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ䰁"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ䰂")+index2+l1l11l_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䰃"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧ࡞ࠦ䰄")+index2+l1l11l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ䰅"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡨࡩࡠࠨ䰆")+index2+l1l11l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ䰇"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡪ࡫࡛ࠣ䰈")+index2+l1l11l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ䰉"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䰊"))
	# l11ll1111ll1_l1_ l11ll11llll1_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ䰋"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ䰌"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡨࡩࡠࠨ䰍")+index2+l1l11l_l1_ (u"ࠥࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ䰎"))
	# main page
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡪ࡫࡛ࠣ䰏")+index2+l1l11l_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ䰐"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡥࡦࠤ䰑"))
	l11ll111l1ll_l1_,ff,l11ll11ll1ll_l1_ = l11l1ll11lll_l1_(ee,l1l11l_l1_ (u"ࠧࠨ䰒"),l11l1ll1l11l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ䰓"),str(ff))
	if level==l1l11l_l1_ (u"ࠩ࠶ࠫ䰔") and l11ll111l1ll_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l11ll1111111_l1_ = str(zz)
				#DIALOG_OK()
				l11l1ll1l11l_l1_ = []
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࡡࠢ䰕")+l11ll1111111_l1_+l1l11l_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ䰖"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡬ࡦ࡜ࠤ䰗")+l11ll1111111_l1_+l1l11l_l1_ (u"ࠨ࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ䰘"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡧࡨ࡞ࠦ䰙")+l11ll1111111_l1_+l1l11l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ䰚"))
				l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࡠࠨ䰛")+l11ll1111111_l1_+l1l11l_l1_ (u"ࠥࡡࠧ䰜"))
				succeeded,item,l1l11l1l_l1_ = l11l1ll11lll_l1_(ff,l1l11l_l1_ (u"ࠫࠬ䰝"),l11l1ll1l11l_l1_)
				#succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,token = l11ll11lll1l_l1_(item)
				#addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䰞"),menu_name+l1111l_l1_,l1111l_l1_,143,img)
				if succeeded: l11l1llll11l_l1_.append([item,url,l1l11l_l1_ (u"࠭࠴࠻࠼ࠪ䰟")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䰠")+index2+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䰡")+l11ll1111111_l1_])
				#success = l11ll11l11ll_l1_(item,url,l1l11l_l1_ (u"ࠩ࠷࠾࠿࠭䰢")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠪ࠾࠿࠭䰣")+index2+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䰤")+l11ll1111111_l1_)
				#if success: l11l1lll11ll_l1_ += 1
	return ff,l11ll111l1ll_l1_,l11l1llll11l_l1_,l11ll11ll1ll_l1_
def l11l1ll11lll_l1_(l1lllllll111_l1_,l1111111l11_l1_,l11l1lll111l_l1_):
	cc,l1111111l11_l1_ = l1lllllll111_l1_,l1111111l11_l1_
	dd,l1111111l11_l1_ = l1lllllll111_l1_,l1111111l11_l1_
	ee,l1111111l11_l1_ = l1lllllll111_l1_,l1111111l11_l1_
	ff,l1111111l11_l1_ = l1lllllll111_l1_,l1111111l11_l1_
	item,render = l1lllllll111_l1_,l1111111l11_l1_
	count = len(l11l1lll111l_l1_)
	for ii in range(count):
		try:
			out = eval(l11l1lll111l_l1_[ii])
			#if isinstance(out,dict): out = l1l11l_l1_ (u"ࠬ࠭䰥")
			return True,out,ii+1
		except: pass
	return False,l1l11l_l1_ (u"࠭ࠧ䰦"),0
def l111l1_l1_(url,index=l1l11l_l1_ (u"ࠧࠨ䰧"),data=l1l11l_l1_ (u"ࠨࠩ䰨")):
	l11l1ll1l1ll_l1_,l11l1lllll11_l1_,l11l1llll11l_l1_ = [],[],[]
	if l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䰩") not in index: index = l1l11l_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ䰪")
	level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = index.split(l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䰫"))
	if level==l1l11l_l1_ (u"ࠬ࠺ࠧ䰬"): level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = l1l11l_l1_ (u"࠭࠱ࠨ䰭"),l11l1lll11l1_l1_,index2,l11ll1111111_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䰮"),l1l11l_l1_ (u"ࠨࠩ䰯"),index,url)
	data = data.replace(l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䰰"),l1l11l_l1_ (u"ࠪࠫ䰱"))
	html,cc,data2 = l11l1ll1llll_l1_(url,data)
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡩࠤࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨࠢ࡬ࡲࠥࡻࡲ࡭ࠢࡲࡶࠥ࠭࠯ࡶࡵࡨࡶ࠴࠭ࠠࡪࡰࠣࡹࡷࡲ࠺ࠋࠋࠌࠧࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣࡲࡴࡺࠠࡰࡹࡱࡩࡷࡀࠠࠋࠋࠌࡳࡼࡴࡥࡳࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡑࡪࡺࡡࡥࡣࡷࡥࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡰࡹࡱࡩࡷ࡛ࡲ࡭ࡵࠥ࠾ࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠩࡩࡧࠢࡱࡳࡹࠦ࡯ࡸࡰࡨࡶ࠿ࠦ࡯ࡸࡰࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡶࡪࡦࡨࡳࡔࡽ࡮ࡦࡴࠥ࠲࠯ࡅࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡳࡼࡴࡥࡳ࠼ࠍࠍࠎࠏ࡯ࡸࡰࡨࡶࡓࡇࡍࡆࠢࡀࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠰࡞ࠫࠍࠍࠎࠏ࡯ࡸࡰࡨࡶࡓࡇࡍࡆࠢࡀࠤࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ࠭ࡲࡻࡳ࡫ࡲࡏࡃࡐࡉ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠲࡟ࠍࠍࠎࠏࡩࡧࠢࠪ࡬ࡹࡺࡰࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡ࡮࡬ࡲࡰࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯ࡱ࡯࡮࡬ࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡱࡺࡲࡪࡸࡎࡂࡏࡈ࠰ࡱ࡯࡮࡬࠮࠴࠸࠹࠯ࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩ࡯࡭ࡳࡱࠧ࠭ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯ࠫࠬ࠲࠹࠺࠻࠼࠭ࠏࠏࠢࠣࠤ䰲")
	index = level+l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䰳")+l11l1lll11l1_l1_+l1l11l_l1_ (u"࠭࠺࠻ࠩ䰴")+index2+l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䰵")+l11ll1111111_l1_
	if level in [l1l11l_l1_ (u"ࠨ࠳ࠪ䰶"),l1l11l_l1_ (u"ࠩ࠵ࠫ䰷"),l1l11l_l1_ (u"ࠪ࠷ࠬ䰸")]:
		dd,l11ll111l11l_l1_,l11l1ll1l1ll_l1_,l11l1ll111ll_l1_ = l11l1llll1l1_l1_(cc,url,index)
		if not l11ll111l11l_l1_: return
		l11l1lll1l1l_l1_ = len(l11l1ll1l1ll_l1_)
		if l11l1lll1l1l_l1_<2:
			if level==l1l11l_l1_ (u"ࠫ࠶࠭䰹"): level = l1l11l_l1_ (u"ࠬ࠸ࠧ䰺")
			l11l1ll1l1ll_l1_ = []
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䰻"),l1l11l_l1_ (u"ࠧࠨ䰼"),index,l1l11l_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠳࡟ࡲࠬ䰽")+l1l11l_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭䰾")+str(l11l1ll111ll_l1_)+l1l11l_l1_ (u"ࠪࡠࡳ࠭䰿")+l1l11l_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭䱀")+str(len(dd))+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䱁")+l1l11l_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ䱂")+str(l11l1lll1l1l_l1_)+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䱃")+url)
	index = level+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䱄")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䱅")+index2+l1l11l_l1_ (u"ࠪ࠾࠿࠭䱆")+l11ll1111111_l1_
	if level in [l1l11l_l1_ (u"ࠫ࠷࠭䱇"),l1l11l_l1_ (u"ࠬ࠹ࠧ䱈")]:
		ee,l11ll1111l1l_l1_,l11l1lllll11_l1_,l11l1lll1lll_l1_ = l11l1ll11l11_l1_(cc,dd,url,index)
		if not l11ll1111l1l_l1_: return
		l11ll1111lll_l1_ = len(l11l1lllll11_l1_)
		if l11ll1111lll_l1_<2:
			if level==l1l11l_l1_ (u"࠭࠲ࠨ䱉"): level = l1l11l_l1_ (u"ࠧ࠴ࠩ䱊")
			l11l1lllll11_l1_ = []
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䱋"),l1l11l_l1_ (u"ࠩࠪ䱌"),index,l1l11l_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠶ࡡࡴࠧ䱍")+l1l11l_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ䱎")+str(l11l1lll1lll_l1_)+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䱏")+l1l11l_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ䱐")+str(len(ee))+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䱑")+l1l11l_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ䱒")+str(l11ll1111lll_l1_)+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䱓")+url)
	index = level+l1l11l_l1_ (u"ࠪ࠾࠿࠭䱔")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䱕")+index2+l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䱖")+l11ll1111111_l1_
	if level in [l1l11l_l1_ (u"࠭࠳ࠨ䱗")]:
		ff,l11ll111l1ll_l1_,l11l1llll11l_l1_,l11ll11ll1ll_l1_ = l11l1ll1ll11_l1_(cc,ee,url,index)
		if not l11ll111l1ll_l1_: return
		l11l1lll11ll_l1_ = len(l11l1llll11l_l1_)
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䱘"),l1l11l_l1_ (u"ࠨࠩ䱙"),index,l1l11l_l1_ (u"ࠩ࡯ࡩࡻ࡫࡬࠻ࠢ࠶ࡠࡳ࠭䱚")+l1l11l_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩ࠿ࠦࠧ䱛")+str(l11ll11ll1ll_l1_)+l1l11l_l1_ (u"ࠫࡡࡴࠧ䱜")+l1l11l_l1_ (u"ࠬࡲࡥ࡯ࡩࡷ࡬࠿ࠦࠧ䱝")+str(len(ff))+l1l11l_l1_ (u"࠭࡜࡯ࠩ䱞")+l1l11l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡀࠠࠨ䱟")+str(l11l1lll11ll_l1_)+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䱠")+url)
	for item,url,index in l11l1ll1l1ll_l1_+l11l1lllll11_l1_+l11l1llll11l_l1_:
		success = l11ll11l11ll_l1_(item,url,index)
	return
def l11ll11l11ll_l1_(item,url=l1l11l_l1_ (u"ࠩࠪ䱡"),index=l1l11l_l1_ (u"ࠪࠫ䱢")):
	#DIALOG_OK()
	if l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䱣") in index: level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = index.split(l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䱤"))
	else: level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = l1l11l_l1_ (u"࠭࠱ࠨ䱥"),l1l11l_l1_ (u"ࠧ࠱ࠩ䱦"),l1l11l_l1_ (u"ࠨ࠲ࠪ䱧"),l1l11l_l1_ (u"ࠩ࠳ࠫ䱨")
	succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,l11ll11l1lll_l1_ = l11ll11lll1l_l1_(item)
	#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ䱩"),l1111l_l1_+l1l11l_l1_ (u"ࠫࠥࠦࠠࠨ䱪")+title)
	# needed for l11ll1111ll1_l1_ l11ll11llll1_l1_ next page
	# and needed for l11ll1111ll1_l1_ l11ll11llll1_l1_ sub-l11111l1l_l1_
	#if (l1l11l_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠹࠵࠭䱫") in l1111l_l1_ or l1l11l_l1_ (u"࠭ࡶࡪࡧࡺࡁ࠹࠿ࠧ䱬") in l1111l_l1_) and (l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ䱭") in l1111l_l1_ or l1l11l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ䱮") in l1111l_l1_): l1111l_l1_ = url
	cond1 = l1l11l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ䱯") in l1111l_l1_ or l1l11l_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭䱰") in l1111l_l1_ or l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ䱱") in l1111l_l1_
	cond2 = l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ䱲") in l1111l_l1_ or l1l11l_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ䱳") in l1111l_l1_
	if cond1 or cond2: l1111l_l1_ = url
	cond1 = l1l11l_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ䱴") not in l1111l_l1_ and l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ䱵") not in l1111l_l1_
	cond2 = l1l11l_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ䱶") not in l1111l_l1_  and l1l11l_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭䱷") not in l1111l_l1_
	if index[0:5]==l1l11l_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ䱸") and cond1 and cond2: l1111l_l1_ = url
	if l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ䱹") in url or l1l11l_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ䱺") in l1111l_l1_:
		level,l11l1lll11l1_l1_,index2,l11ll1111111_l1_ = l1l11l_l1_ (u"ࠧ࠲ࠩ䱻"),l1l11l_l1_ (u"ࠨ࠲ࠪ䱼"),l1l11l_l1_ (u"ࠩ࠳ࠫ䱽"),l1l11l_l1_ (u"ࠪ࠴ࠬ䱾")
		index = l1l11l_l1_ (u"ࠫࠬ䱿")
	data2 = l1l11l_l1_ (u"ࠬ࠭䲀")
	if l1l11l_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ䲁") in l1111l_l1_ or l1l11l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭䲂") in l1111l_l1_:
		data = settings.getSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ䲃"))
		if data.count(l1l11l_l1_ (u"ࠩ࠽࠾࠿࠭䲄"))==4:
			l11ll111l1l1_l1_,key,l11ll11111ll_l1_,l11l1lll1l11_l1_,token = data.split(l1l11l_l1_ (u"ࠪ࠾࠿ࡀࠧ䲅"))
			data2 = l11ll111l1l1_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ䲆")+key+l1l11l_l1_ (u"ࠬࡀ࠺࠻ࠩ䲇")+l11ll11111ll_l1_+l1l11l_l1_ (u"࠭࠺࠻࠼ࠪ䲈")+l11l1lll1l11_l1_+l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ䲉")+l11ll11l1lll_l1_
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨࡁ࡮ࡩࡾࡃࠧ䲊")+key
	#if url==l11lll_l1_: l11l1lll11l1_l1_ = l1l11l_l1_ (u"ࠩ࠳ࠫ䲋")
	if not title:
		global l11l1ll1ll1l_l1_
		l11l1ll1ll1l_l1_ += 1
		title = l1l11l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠭䲌")+str(l11l1ll1ll1l_l1_)
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䲍"),l1l11l_l1_ (u"ࠬ࠭䲎"),index,l1l11l_l1_ (u"࠭ࠧ䲏"))
		index = l1l11l_l1_ (u"ࠧ࠴ࠩ䲐")+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䲑")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䲒")+index2+l1l11l_l1_ (u"ࠪ࠾࠿࠭䲓")+l11ll1111111_l1_
	#if l1l11l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ䲔") in url: l1111l_l1_ = url
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䲕"),l1l11l_l1_ (u"࠭ࠧ䲖"),title,index+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䲗")+l1111l_l1_)
	#if not l1111l_l1_: l1111l_l1_ = url
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䲘"),l1l11l_l1_ (u"ࠩࠪ䲙"),str(succeeded),title+l1l11l_l1_ (u"ࠪࠤ࠿ࡀ࠺ࠡࠩ䲚")+l1111l_l1_)
	#if l1l11l_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ䲛") in url and index==l1l11l_l1_ (u"ࠬ࠶ࠧ䲜"):
	#	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䲝"),menu_name+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡐࡺࡸࡕࡩࡳࡪࡥࡳࡧࡵࠫ䲞") in str(item): return False			# l11ll11l1111_l1_ not items
	elif l1l11l_l1_ (u"ࠨ࠱ࡤࡦࡴࡻࡴࠨ䲟") in l1111l_l1_: return False
	elif l1l11l_l1_ (u"ࠩ࠲ࡧࡴࡳ࡭ࡶࡰ࡬ࡸࡾ࠭䲠") in l1111l_l1_: return False
	elif l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䲡") in list(item.keys()):
		level = str(int(level)-1)
		index = level+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䲢")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䲣")+index2+l1l11l_l1_ (u"࠭࠺࠻ࠩ䲤")+l11ll1111111_l1_
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䲥"),menu_name+l1l11l_l1_ (u"ࠨ࠼࠽ࠤࠬ䲦")+l1l11l_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ䲧"),l1111l_l1_,144,img,index,data2)
	elif l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ䲨") in l1111l_l1_:
		title = l1l11l_l1_ (u"ࠫ࠿ࡀࠠࠨ䲩")+title
		index = l1l11l_l1_ (u"ࠬ࠹ࠧ䲪")+l1l11l_l1_ (u"࠭࠺࠻ࠩ䲫")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䲬")+index2+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䲭")+l11ll1111111_l1_
		url = url.replace(l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ䲮"),l1l11l_l1_ (u"ࠪࠫ䲯"))
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䲰"),menu_name+title,url,145,l1l11l_l1_ (u"ࠬ࠭䲱"),index,l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䲲"))
	elif l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭䲳") in url and not l1111l_l1_:
		index = l1l11l_l1_ (u"ࠨ࠵ࠪ䲴")+l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䲵")+l11l1lll11l1_l1_+l1l11l_l1_ (u"ࠪ࠾࠿࠭䲶")+index2+l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䲷")+l11ll1111111_l1_
		title = l1l11l_l1_ (u"ࠬࡀ࠺ࠡࠩ䲸")+title
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䲹"),menu_name+title,url,144,img,index,data2)
	#elif l1l11l_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ䲺") in l1111l_l1_: return False
	elif l1l11l_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࠩ䲻") in l1111l_l1_ and url==l11lll_l1_:
		title = l1l11l_l1_ (u"ࠩ࠽࠾ࠥ࠭䲼")+title
		index = l1l11l_l1_ (u"ࠪ࠶࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ䲽")
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䲾"),menu_name+title,l1111l_l1_,144,img,index,data2)
	elif not l1111l_l1_ and l1l11l_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ䲿") in str(item):
		title = l1l11l_l1_ (u"࠭࠺࠻ࠢࠪ䳀")+title
		index = l1l11l_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ䳁")
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䳂"),menu_name+title,url,144,img,index)
	elif l1l11l_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠫ䳃") in str(item):
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䳄"),menu_name+title,l1l11l_l1_ (u"ࠫࠬ䳅"),9999)
	#elif l1l11l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭䳆") in l1111l_l1_ and l1l11l_l1_ (u"࠭ࡢࡱ࠿ࠪ䳇") not in l1111l_l1_:
	#	title = l1l11l_l1_ (u"ࠧ࠻࠼ࠣࠫ䳈")+title
	#	index = l1l11l_l1_ (u"ࠨ࠴࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ䳉")
	#	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳊"),menu_name+title,l1111l_l1_,144,img,index)
	elif l1ll111111l_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䳋"),menu_name+l1ll111111l_l1_+title,l1111l_l1_,143,img)
	elif l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭䳌") in l1111l_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䳍"),menu_name+l1l11l_l1_ (u"࠭ࡌࡊࡕࡗࠫ䳎")+count+l1l11l_l1_ (u"ࠧ࠻ࠢࠣࠫ䳏")+title,l1111l_l1_,144,img,index)
	#elif l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ䳐") in l1111l_l1_ and l1l11l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ䳑") not in l1111l_l1_ and l1l11l_l1_ (u"ࠪࡸࡂ࠶ࠧ䳒") not in l1111l_l1_:
	#	l11ll11l111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䳓"),l1111l_l1_,re.DOTALL)
	#	l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ䳔")+l11ll11l111l_l1_[0]
	#	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䳕"),menu_name+l1l11l_l1_ (u"ࠧࡍࡋࡖࡘࠬ䳖")+count+l1l11l_l1_ (u"ࠨ࠼ࠣࠤࠬ䳗")+title,l1111l_l1_,144,img,index)
	elif l1l11l_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵ࠲ࠫ䳘") in l1111l_l1_:
		l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ䳙"),1)[0]
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䳚"),menu_name+title,l1111l_l1_,143,img,duration)
	elif l1l11l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ䳛") in l1111l_l1_:
		if l1l11l_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭䳜") in l1111l_l1_ and count:
			l11ll11l111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ䳝"),1)[1]
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ䳞")+l11ll11l111l_l1_
			index = l1l11l_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭䳟")
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳠"),menu_name+l1l11l_l1_ (u"ࠫࡑࡏࡓࡕࠩ䳡")+count+l1l11l_l1_ (u"ࠬࡀࠠࠡࠩ䳢")+title,l1111l_l1_,144,img,index)
		else:
			l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭䳣"),1)[0]
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䳤"),menu_name+title,l1111l_l1_,143,img,duration)
	elif l1l11l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ䳥") in l1111l_l1_:
		title = l1l11l_l1_ (u"ࠩ࠽࠾ࠥ࠭䳦")+title
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳧"),menu_name+title,l1111l_l1_,144,img)
	elif l1l11l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ䳨") in l1111l_l1_ or l1l11l_l1_ (u"ࠬ࠵ࡣ࠰ࠩ䳩") in l1111l_l1_ or (l1l11l_l1_ (u"࠭࠯ࡁࠩ䳪") in l1111l_l1_ and l1111l_l1_.count(l1l11l_l1_ (u"ࠧ࠰ࠩ䳫"))==3):
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䳬"),menu_name+l1l11l_l1_ (u"ࠩࡆࡌࡓࡒࠧ䳭")+count+l1l11l_l1_ (u"ࠪ࠾ࠥࠦࠧ䳮")+title,l1111l_l1_,144,img,index,data2)
	elif l1l11l_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ䳯") in l1111l_l1_:
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䳰"),menu_name+l1l11l_l1_ (u"࠭ࡕࡔࡇࡕࠫ䳱")+count+l1l11l_l1_ (u"ࠧ࠻ࠢࠣࠫ䳲")+title,l1111l_l1_,144,img,index,data2)
	else:
		if not l1111l_l1_: l1111l_l1_ = url
		title = l1l11l_l1_ (u"ࠨ࠼࠽ࠤࠬ䳳")+title
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳴"),menu_name+title,l1111l_l1_,144,img,index,data2)
	return True
def l11ll11lll1l_l1_(item):
	succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,token = False,l1l11l_l1_ (u"ࠪࠫ䳵"),l1l11l_l1_ (u"ࠫࠬ䳶"),l1l11l_l1_ (u"ࠬ࠭䳷"),l1l11l_l1_ (u"࠭ࠧ䳸"),l1l11l_l1_ (u"ࠧࠨ䳹"),l1l11l_l1_ (u"ࠨࠩ䳺"),l1l11l_l1_ (u"ࠩࠪ䳻"),l1l11l_l1_ (u"ࠪࠫ䳼")
	try: l11l1lllllll_l1_ = list(item.keys())[0]
	except: return succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,token
	#WRITE_THIS(l1l11l_l1_ (u"ࠫࠬ䳽"),str(item))
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䳾"),str(item))
	render = item[l11l1lllllll_l1_]
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ䳿"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ䴀"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪ࡬ࡪࡰࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䴁"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡹࡳࡶ࡬ࡢࡻࡤࡦࡱ࡫ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䴂"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࡔࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ䴃"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䴄"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ䴅"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ䴆"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ䴇"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ䴈"))
	# required for l1lllll1l1ll_l1_ l11l1llll111_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ䴉"))
	# l11ll1111ll1_l1_ l11ll111111l_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡹ࡭ࡩ࡫࡯ࡊࡦࠪࡡࠧ䴊"))
	succeeded,title,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䴋"),l1l11l_l1_ (u"ࠬ࠭䴌"),l1l11l_l1_ (u"࠭ࠧ䴍"),str(l1l11l1l_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ䴎"),str(l1l11l1l_l1_)+l1l11l_l1_ (u"ࠨࠢࠣࠤࠬ䴏")+str(title))
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ䴐"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ䴑"))
	# l11ll111l111_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ䴒"))
	# header feed
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ䴓"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ䴔"))
	# required for l1lllll1l1ll_l1_ l11l1lll1111_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䴕"))
	# l11ll1111ll1_l1_ l11ll111111l_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ䴖"))
	succeeded,l1111l_l1_,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ䴗"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ䴘"))
	# l11ll1111ll1_l1_ l11ll111111l_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ䴙"))
	succeeded,img,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䴚"),str(l1l11l1l_l1_)+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ䴛")+img)
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸࠬࡣࠢ䴜"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ䴝"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡄࡲࡸࡹࡵ࡭ࡑࡣࡱࡩࡱࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ䴞"))
	succeeded,count,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	l11l1ll1l11l_l1_ = []
	# l11ll111ll1l_l1_ l11ll1111ll1_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡷࡹࡿ࡬ࡦࠩࡠࠦ䴟"))
	# l11ll111ll1l_l1_ l11ll1111ll1_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࠩࡠ࡟ࠬ࡯ࡣࡰࡰࡗࡽࡵ࡫ࠧ࡞ࠤ䴠"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ䴡"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ䴢"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ䴣"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ䴤"))
	succeeded,duration,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	#l11l1ll1l11l_l1_ = []
	# l11ll111l111_l1_
	#l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣ࡭࡫ࡦ࡯࡙ࡸࡡࡤ࡭࡬ࡲ࡬ࡖࡡࡳࡣࡰࡷࠬࡣࠢ䴥"))
	# l1ll1111l1ll_l1_ l11ll111lll1_l1_
	#l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡺࡲࡢࡥ࡮࡭ࡳ࡭ࡐࡢࡴࡤࡱࡸ࠭࡝ࠣ䴦"))
	#succeeded,l11l1ll1lll1_l1_,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	l11l1ll1l11l_l1_ = []
	# l1ll1111l1ll_l1_ l11ll111lll1_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡶࡲ࡯ࡪࡴࠧ࡞ࠤ䴧"))
	# l11ll111l111_l1_
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ䴨"))
	succeeded,token,l1l11l1l_l1_ = l11l1ll11lll_l1_(item,render,l11l1ll1l11l_l1_)
	if l1l11l_l1_ (u"࠭ࡌࡊࡘࡈࠫ䴩") in duration: duration,l1ll111111l_l1_ = l1l11l_l1_ (u"ࠧࠨ䴪"),l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ䴫")
	if l1l11l_l1_ (u"่ࠩฬฬฺัࠨ䴬") in duration: duration,l1ll111111l_l1_ = l1l11l_l1_ (u"ࠪࠫ䴭"),l1l11l_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ䴮")
	if l1l11l_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ䴯") in list(render.keys()):
		l11ll11l1l11_l1_ = str(render[l1l11l_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭䴰")])
		if l1l11l_l1_ (u"ࠧࡇࡴࡨࡩࠥࡽࡩࡵࡪࠣࡅࡩࡹࠧ䴱") in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠨࠦ࠽ࠤࠥ࠭䴲")
		if l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䴳") in l11ll11l1l11_l1_: l1ll111111l_l1_ = l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ䴴")
		if l1l11l_l1_ (u"ࠫࡇࡻࡹࠨ䴵") in l11ll11l1l11_l1_ or l1l11l_l1_ (u"ࠬࡘࡥ࡯ࡶࠪ䴶") in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ䴷")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡵࠨ็หหูืࠧ䴸")) in l11ll11l1l11_l1_: l1ll111111l_l1_ = l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ䴹")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡷุࠪึอมࠨ䴺")) in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ䴻")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡹࠬอำหศฯหึ࠭䴼")) in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ䴽")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡻࠧฦ฻็ห๋อสࠨ䴾")) in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠧࠥ࠼ࠣࠤࠬ䴿")
	l1111l_l1_ = escapeUNICODE(l1111l_l1_)
	if l1111l_l1_ and l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䵀") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
	img = img.split(l1l11l_l1_ (u"ࠩࡂࠫ䵁"))[0]
	if  img and l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䵂") not in img: img = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ䵃")+img
	title = escapeUNICODE(title)
	if l11l1llllll1_l1_: title = l11l1llllll1_l1_+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l11l_l1_ (u"ࠬ࠲ࠧ䵄"),l1l11l_l1_ (u"࠭ࠧ䵅"))
	count = count.replace(l1l11l_l1_ (u"ࠧ࠭ࠩ䵆"),l1l11l_l1_ (u"ࠨࠩ䵇"))
	count = re.findall(l1l11l_l1_ (u"ࠩ࡟ࡨ࠰࠭䵈"),count)
	if count: count = count[0]
	else: count = l1l11l_l1_ (u"ࠪࠫ䵉")
	return True,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_,token
def l11l1ll1llll_l1_(url,data=l1l11l_l1_ (u"ࠫࠬ䵊"),request=l1l11l_l1_ (u"ࠬ࠭䵋")):
	if request==l1l11l_l1_ (u"࠭ࠧ䵌"): request = l1l11l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ䵍")
	#if l1l11l_l1_ (u"ࠨࡡࡢࠫ䵎") in l11ll11lll11_l1_: l11ll11lll11_l1_ = l1l11l_l1_ (u"ࠩࠪ䵏")
	#if l1l11l_l1_ (u"ࠪࡷࡸࡃࠧ䵐") in url: url = url.split(l1l11l_l1_ (u"ࠫࡸࡹ࠽ࠨ䵑"))[0]
	#useragent = l1l11l_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠴࠴࠾࠴࠰࠯࠲࠱࠴࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠥࡋࡤࡨ࠱࠴࠴࠾࠴࠰࠯࠳࠸࠵࠽࠴࠷࠱ࠩ䵒")
	useragent = l1ll11ll1_l1_()
	headers2 = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䵓"):useragent,l1l11l_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ䵔"):l1l11l_l1_ (u"ࠨࡒࡕࡉࡋࡃࡨ࡭࠿ࡤࡶࠬ䵕")}
	#headers2 = headers.copy()
	global settings
	if not data: data = settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ䵖"))
	if data.count(l1l11l_l1_ (u"ࠪ࠾࠿ࡀࠧ䵗"))==4: l11ll111l1l1_l1_,key,l11ll11111ll_l1_,l11l1lll1l11_l1_,token = data.split(l1l11l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ䵘"))
	else: l11ll111l1l1_l1_,key,l11ll11111ll_l1_,l11l1lll1l11_l1_,token = l1l11l_l1_ (u"ࠬ࠭䵙"),l1l11l_l1_ (u"࠭ࠧ䵚"),l1l11l_l1_ (u"ࠧࠨ䵛"),l1l11l_l1_ (u"ࠨࠩ䵜"),l1l11l_l1_ (u"ࠩࠪ䵝")
	data2 = {l1l11l_l1_ (u"ࠥࡧࡴࡴࡴࡦࡺࡷࠦ䵞"):{l1l11l_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ䵟"):{l1l11l_l1_ (u"ࠧ࡮࡬ࠣ䵠"):l1l11l_l1_ (u"ࠨࡡࡳࠤ䵡"),l1l11l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ䵢"):l1l11l_l1_ (u"࡙ࠣࡈࡆࠧ䵣"),l1l11l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ䵤"):l11ll11111ll_l1_}}}
	if l1l11l_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ䵥") in url and l1l11l_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭䵦") not in url:
		url = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡷ࡫ࡥ࡭࠱ࡵࡩࡪࡲ࡟ࡸࡣࡷࡧ࡭ࡥࡳࡦࡳࡸࡩࡳࡩࡥࡀ࡭ࡨࡽࡂ࠭䵧")+key
		data2[l1l11l_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࡑࡣࡵࡥࡲࡹࠧ䵨")] = l11ll111l1l1_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䵩"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠴ࡷࡹ࠭䵪"))
	elif l1l11l_l1_ (u"ࠩ࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ䵫") in url:
		url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭䵬")+key
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䵭"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠲࡯ࡦࠪ䵮"))
	elif l1l11l_l1_ (u"࠭࡫ࡦࡻࡀࠫ䵯") in url and l11ll111l1l1_l1_:
		#url = url+key
		data2[l1l11l_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭䵰")] = token
		data2[l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ䵱")][l1l11l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࠩ䵲")][l1l11l_l1_ (u"ࠪࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠨ䵳")] = l11ll111l1l1_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䵴"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠳ࡳࡦࠪ䵵"))
	elif l1l11l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ䵶") in url and l11l1lll1l11_l1_:
		headers2.update({l1l11l_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ䵷"):l1l11l_l1_ (u"ࠨ࠳ࠪ䵸"),l1l11l_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭䵹"):l11ll11111ll_l1_})
		headers2.update({l1l11l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䵺"):l1l11l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ䵻")+l11l1lll1l11_l1_})
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䵼"),url,l1l11l_l1_ (u"࠭ࠧ䵽"),headers2,l1l11l_l1_ (u"ࠧࠨ䵾"),l1l11l_l1_ (u"ࠨࠩ䵿"),l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ䶀"))
	else:
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䶁"),url,l1l11l_l1_ (u"ࠫࠬ䶂"),headers2,l1l11l_l1_ (u"ࠬ࠭䶃"),l1l11l_l1_ (u"࠭ࠧ䶄"),l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠷ࡷ࡬ࠬ䶅"))
	html = response.content
	tmp = re.findall(l1l11l_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䶆"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䶇"),html,re.DOTALL|re.I)
	if tmp: l11ll11111ll_l1_ = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠪࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䶈"),html,re.DOTALL|re.I)
	if tmp: l11ll111l1l1_l1_ = tmp[0]
	#tmp = re.findall(l1l11l_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䶉"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䶊"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩࠨ࠺ࡼࠤࡷࡳࡰ࡫࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䶋"),html,re.DOTALL|re.I)
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䶌"),l1l11l_l1_ (u"ࠨࠩ䶍"),l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ䶎"),str(len(tmp)))
	#if tmp: l11ll111l111_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l11l_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ䶏") in list(cookies.keys()): l11l1lll1l11_l1_ = cookies[l1l11l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ䶐")]
	l1l1lll1l_l1_ = l11ll111l1l1_l1_+l1l11l_l1_ (u"ࠬࡀ࠺࠻ࠩ䶑")+key+l1l11l_l1_ (u"࠭࠺࠻࠼ࠪ䶒")+l11ll11111ll_l1_+l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ䶓")+l11l1lll1l11_l1_+l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ䶔")+token
	if request==l1l11l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ䶕") and l1l11l_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ䶖") in html:
		l1l1ll11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡠࡠࠨࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠨ࡜࡞ࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭䶗"),html,re.DOTALL)
		if not l1l1ll11l1_l1_: l1l1ll11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭䶘"),html,re.DOTALL)
		l11l1ll1l1l1_l1_ = EVAL(l1l11l_l1_ (u"࠭ࡳࡵࡴࠪ䶙"),l1l1ll11l1_l1_[0])
	elif request==l1l11l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ䶚") and l1l11l_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭䶛") in html:
		l1l1ll11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ䶜"),html,re.DOTALL)
		l11l1ll1l1l1_l1_ = EVAL(l1l11l_l1_ (u"ࠪࡷࡹࡸࠧ䶝"),l1l1ll11l1_l1_[0])
	elif l1l11l_l1_ (u"ࠫࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ䶞") not in html: l11l1ll1l1l1_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡹࡴࡳࠩ䶟"),html)
	else: l11l1ll1l1l1_l1_ = l1l11l_l1_ (u"࠭ࠧ䶠")
	#cc = str(l11l1ll1l1l1_l1_)
	#if kodi_version>18.99: cc = cc.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䶡"))
	#open(l1l11l_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮࡫ࡵࡲࡲࠬ䶢"),l1l11l_l1_ (u"ࠩࡺࡦࠬ䶣")).write(cc)
	#open(l1l11l_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ䶤"),l1l11l_l1_ (u"ࠫࡼ࠭䶥")).write(html)
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ䶦"),l1l1lll1l_l1_)
	return html,l11l1ll1l1l1_l1_,l1l1lll1l_l1_
def l11ll11ll11l_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ䶧"),l1l11l_l1_ (u"ࠧࠬࠩ䶨"))
	url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ䶩")+search
	l111l1_l1_(url2,index)
	return
def SEARCH(search):
	#search = l1l11l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䶪")+l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࠨ䶫")+l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ䶬")+l1l11l_l1_ (u"ࠬࡥࠧ䶭")+search
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䶮"),l1l11l_l1_ (u"ࠧࠨ䶯"),l1l11l_l1_ (u"ࠨࠩ䶰"),search)
	search,options,showdialogs = SEARCH_OPTIONS(search)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䶱"),l1l11l_l1_ (u"ࠪࠫ䶲"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭䶳"),l1l11l_l1_ (u"ࠬ࠱ࠧ䶴"))
	url2 = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࠨ䶵")+search
	if not showdialogs:
		if l1l11l_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࡡࠪ䶶") in options: l11l1lll1ll1_l1_ = l1l11l_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡕࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ䶷")
		elif l1l11l_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨ䶸") in options: l11l1lll1ll1_l1_ = l1l11l_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ䶹")
		elif l1l11l_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࠩ䶺") in options: l11l1lll1ll1_l1_ = l1l11l_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡨࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ䶻")
		url3 = url2+l11l1lll1ll1_l1_
	else:
		l11l1lllll1l_l1_,l11l1ll11ll1_l1_,title2 = [],[],l1l11l_l1_ (u"࠭ࠧ䶼")
		l11l1ll1l111_l1_ = [l1l11l_l1_ (u"ࠧษั๋๊ࠥะัห์หࠫ䶽"),l1l11l_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ๊ี้ࠡษ็ู้ฯࠧ䶾"),l1l11l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥะวา์ัࠤฬ๊สฮ็ํ่ࠬ䶿"),l1l11l_l1_ (u"ࠪฮึะ๊ษࠢะือูࠦะัࠣห้๋ิศ้าหฯ࠭䷀"),l1l11l_l1_ (u"ࠫฯืส๋สࠣัุฮࠠศๆอๆ๏๐ๅࠨ䷁")]
		l11ll111llll_l1_ = [l1l11l_l1_ (u"ࠬ࠭䷂"),l1l11l_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡇࠥ࠳࠷࠶ࡈࠬ䷃"),l1l11l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡉࠦ࠴࠸࠷ࡉ࠭䷄"),l1l11l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡎࠧ࠵࠹࠸ࡊࠧ䷅"),l1l11l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡇࠨ࠶࠺࠹ࡄࠨ䷆")]
		l11ll11l1ll1_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ฮึะ๊ษࠩ䷇"),l11l1ll1l111_l1_)
		if l11ll11l1ll1_l1_ == -1: return
		l11ll11l1l1l_l1_ = l11ll111llll_l1_[l11ll11l1ll1_l1_]
		html,c,data = l11l1ll1llll_l1_(url2+l11ll11l1l1l_l1_)
		if c:
			try:
				d = c[l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䷈")][l1l11l_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䷉")][l1l11l_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ䷊")][l1l11l_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䷋")][l1l11l_l1_ (u"ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩ䷌")][l1l11l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䷍")][l1l11l_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࡵࠪ䷎")]
				for l11l1ll11l1l_l1_ in range(len(d)):
					group = d[l11l1ll11l1l_l1_][l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡊࡶࡴࡻࡰࡓࡧࡱࡨࡪࡸࡥࡳࠩ䷏")][l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䷐")]
					for l11ll11ll1l1_l1_ in range(len(group)):
						render = group[l11ll11ll1l1_l1_][l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䷑")]
						if l1l11l_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ䷒") in list(render.keys()):
							l1111l_l1_ = render[l1l11l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭䷓")][l1l11l_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ䷔")][l1l11l_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ䷕")][l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ䷖")]
							l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠬࡢࡵ࠱࠲࠵࠺ࠬ䷗"),l1l11l_l1_ (u"࠭ࠦࠨ䷘"))
							title = render[l1l11l_l1_ (u"ࠧࡵࡱࡲࡰࡹ࡯ࡰࠨ䷙")]
							title = title.replace(l1l11l_l1_ (u"ࠨษ็ฬาัฺ่ࠠࠣࠫ䷚"),l1l11l_l1_ (u"ࠩࠪ䷛"))
							if l1l11l_l1_ (u"ࠪษือไสࠢส่ๆ๊สาࠩ䷜") in title: continue
							if l1l11l_l1_ (u"ࠫ็อฦๆหࠣฮูเ๊ๅࠩ䷝") in title:
								title = l1l11l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭䷞")+title
								title2 = title
								l11l111l1_l1_ = l1111l_l1_
							if l1l11l_l1_ (u"࠭สาฬํฬࠥำำษࠩ䷟") in title: continue
							title = title.replace(l1l11l_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠤࠬ䷠"),l1l11l_l1_ (u"ࠨࠩ䷡"))
							if l1l11l_l1_ (u"ࠩࡕࡩࡲࡵࡶࡦࠩ䷢") in title: continue
							if l1l11l_l1_ (u"ࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ䷣") in title:
								title = l1l11l_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ䷤")+title
								title2 = title
								l11l111l1_l1_ = l1111l_l1_
							if l1l11l_l1_ (u"࡙ࠬ࡯ࡳࡶࠣࡦࡾ࠭䷥") in title: continue
							l11l1lllll1l_l1_.append(escapeUNICODE(title))
							l11l1ll11ll1_l1_.append(l1111l_l1_)
			except: pass
		if not title2: l11ll111ll11_l1_ = l1l11l_l1_ (u"࠭ࠧ䷦")
		else:
			l11l1lllll1l_l1_ = [l1l11l_l1_ (u"ࠧษั๋๊ࠥ็ไหำࠪ䷧"),title2]+l11l1lllll1l_l1_
			l11l1ll11ll1_l1_ = [l1l11l_l1_ (u"ࠨࠩ䷨"),l11l111l1_l1_]+l11l1ll11ll1_l1_
			l11ll11ll111_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆไ่ฯืࠧ䷩"),l11l1lllll1l_l1_)
			if l11ll11ll111_l1_ == -1: return
			l11ll111ll11_l1_ = l11l1ll11ll1_l1_[l11ll11ll111_l1_]
		if l11ll111ll11_l1_: url3 = l11lll_l1_+l11ll111ll11_l1_
		elif l11ll11l1l1l_l1_: url3 = url2+l11ll11l1l1l_l1_
		else: url3 = url2
		l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡨ࡬ࡰࡹ࡫ࡲ࠮ࡦࡵࡳࡵࡪ࡯ࡸࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱ࠲ࡹࡥࡤࡶ࡬ࡳࡳ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡔࡨࡱࡴࡼࡥࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠪ࠰࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡰࡴࡷࠤࡧࡿࠧ࠭ࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ࠰ࡺࡩࡵ࡮ࡨࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡶ࡬ࡸࡱ࡫ࠩࠪࠌࠌࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠧࠨࠢ䷪")
	#DIALOG_OK()
	l111l1_l1_(url3)
	return
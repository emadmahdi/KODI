# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜ࠧ⳴")
l11lll_l1_ = WEBSITES[l1l11l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ⳵")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l1l11l_l1_ (u"ࠩ࠳ࠫ⳶"),True)
	elif mode==102: results = ITEMS(l1l11l_l1_ (u"ࠪ࠵ࠬ⳷"),True)
	elif mode==103: results = ITEMS(l1l11l_l1_ (u"ࠫ࠷࠭⳸"),True)
	elif mode==104: results = ITEMS(l1l11l_l1_ (u"ࠬ࠹ࠧ⳹"),True)
	elif mode==105: results = PLAY(url)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⳺"),l1l11l_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭⳻")+l1l11l_l1_ (u"ࠨๆ็ู้ะัไ์้ࠤอิฯๆหࠣࡍࡕ࡚ࡖࠨ⳼"),l1l11l_l1_ (u"ࠩࠪ⳽"),230)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳾"),l1l11l_l1_ (u"ࠫࡤ࡚ࡖ࠱ࡡࠪ⳿")+l1l11l_l1_ (u"่ࠬๆ้ษอࠤ๊์ࠠๆ๊สๆ฾ํวࠡษ็วฺ๊๊สࠩⴀ"),l1l11l_l1_ (u"࠭ࠧⴁ"),101)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴂ"),l1l11l_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧⴃ")+l1l11l_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪⴄ"),l1l11l_l1_ (u"ࠪࠫⴅ"),147)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴆ"),l1l11l_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⴇ")+l1l11l_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨⴈ"),l1l11l_l1_ (u"ࠧࠨⴉ"),148)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴊ"),l1l11l_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨⴋ")+l1l11l_l1_ (u"ࠪࠤ่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ๊์ࠠๆ๊ๅ฽์๋ࠠࠡࠩⴌ"),l1l11l_l1_ (u"ࠫࠬⴍ"),28)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪⴎ"),l1l11l_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬⴏ")+l1l11l_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩⴐ"),l1l11l_l1_ (u"ࠨࠩⴑ"),41)
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧⴒ"),l1l11l_l1_ (u"ࠪࡣࡐ࡝ࡔࡠࠩⴓ")+l1l11l_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬⴔ"),l1l11l_l1_ (u"ࠬ࠭ⴕ"),135)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫⴖ"),l1l11l_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭ⴗ")+l1l11l_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪⴘ"),l1l11l_l1_ (u"ࠩࠪⴙ"),38)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⴚ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⴛ"),l1l11l_l1_ (u"ࠬ࠭ⴜ"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴝ"),l1l11l_l1_ (u"ࠧࡠࡖ࡙࠵ࡤ࠭ⴞ")+l1l11l_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣ฽ฬ๋ษࠨⴟ"),l1l11l_l1_ (u"ࠩࠪⴠ"),102)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴡ"),l1l11l_l1_ (u"ࠫࡤ࡚ࡖ࠳ࡡࠪⴢ")+l1l11l_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠฯษุอࠬⴣ"),l1l11l_l1_ (u"࠭ࠧⴤ"),103)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴥ"),l1l11l_l1_ (u"ࠨࡡࡗ࡚࠸ࡥࠧ⴦")+l1l11l_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ้๊แฮืࠪⴧ"),l1l11l_l1_ (u"ࠪࠫ⴨"),104)
	return
def ITEMS(l11111l1l_l1_,show=True):
	menu_name = l1l11l_l1_ (u"ࠫࡤ࡚ࡖࠨ⴩")+l11111l1l_l1_+l1l11l_l1_ (u"ࠬࡥࠧ⴪")
	client = l1l11ll111l_l1_(32)
	payload = { l1l11l_l1_ (u"࠭ࡩࡥࠩ⴫") : l1l11l_l1_ (u"ࠧࠨ⴬") , l1l11l_l1_ (u"ࠨࡷࡶࡩࡷ࠭ⴭ") : client , l1l11l_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ⴮") : l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⴯") , l1l11l_l1_ (u"ࠫࡲ࡫࡮ࡶࠩⴰ") : l11111l1l_l1_ }
	#data = l1111l11_l1_(payload)
	#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬⴱ"),str(payload))
	#LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ⴲ"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬⴳ"), l11lll_l1_, payload, l1l11l_l1_ (u"ࠨࠩⴴ"), True,l1l11l_l1_ (u"ࠩࠪⴵ"),l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭ⴶ"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩⴷ"),l11lll_l1_,payload,l1l11l_l1_ (u"ࠬ࠭ⴸ"),l1l11l_l1_ (u"࠭ࠧⴹ"),l1l11l_l1_ (u"ࠧࠨⴺ"),l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫⴻ"))
	html = response.content
	#html = html.replace(l1l11l_l1_ (u"ࠩ࡟ࡶࠬⴼ"),l1l11l_l1_ (u"ࠪࠫⴽ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬⴾ"),l1l11l_l1_ (u"ࠬ࠭ⴿ"),html,html)
	#file = open(l1l11l_l1_ (u"࠭ࡳ࠻࠱ࡨࡱࡦࡪ࠮ࡩࡶࡰࡰࠬⵀ"), l1l11l_l1_ (u"ࠧࡸࠩⵁ"))
	#file.write(html)
	#file.close()
	items = re.findall(l1l11l_l1_ (u"ࠨࠪ࡞ࡢࡀࡢࡲ࡝ࡰࡠ࠯ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠩⵂ"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l11l_l1_ (u"ࠩࡤࡰࠬⵃ"),l1l11l_l1_ (u"ࠪࡅࡱ࠭ⵄ"))
			start = start.replace(l1l11l_l1_ (u"ࠫࡊࡲࠧⵅ"),l1l11l_l1_ (u"ࠬࡇ࡬ࠨⵆ"))
			start = start.replace(l1l11l_l1_ (u"࠭ࡁࡍࠩⵇ"),l1l11l_l1_ (u"ࠧࡂ࡮ࠪⵈ"))
			start = start.replace(l1l11l_l1_ (u"ࠨࡇࡏࠫⵉ"),l1l11l_l1_ (u"ࠩࡄࡰࠬⵊ"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l11l_l1_ (u"ࠪࡅࡱ࠳ࠧⵋ"),l1l11l_l1_ (u"ࠫࡆࡲࠧⵌ"))
			start = start.replace(l1l11l_l1_ (u"ࠬࡇ࡬ࠡࠩⵍ"),l1l11l_l1_ (u"࠭ࡁ࡭ࠩⵎ"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1lll11l11_l1_,name,img in items:
			if l1l11l_l1_ (u"ࠧࠤࠩⵏ") in source: continue
			#if source in [l1l11l_l1_ (u"ࠨࡐࡗࠫⵐ"),l1l11l_l1_ (u"ࠩ࡜࡙ࠬⵑ"),l1l11l_l1_ (u"࡛ࠪࡘ࠶ࠧⵒ"),l1l11l_l1_ (u"ࠫࡗࡒ࠱ࠨⵓ"),l1l11l_l1_ (u"ࠬࡘࡌ࠳ࠩⵔ")]: continue
			if source!=l1l11l_l1_ (u"࠭ࡕࡓࡎࠪⵕ"): name = name+l1l11l_l1_ (u"ࠧࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ⵖ")+source+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⵗ")
			url = source+l1l11l_l1_ (u"ࠩ࠾࠿ࠬⵘ")+server+l1l11l_l1_ (u"ࠪ࠿ࡀ࠭ⵙ")+l1lll11l11_l1_+l1l11l_l1_ (u"ࠫࡀࡁࠧⵚ")+l11111l1l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪⵛ"),menu_name+l1l11l_l1_ (u"࠭ࠧⵜ")+name,url,105,img)
	else:
		if show: addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⵝ"),menu_name+l1l11l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩⵞ"),l1l11l_l1_ (u"ࠩࠪⵟ"),9999)
		#if show: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫⵠ"),l1l11l_l1_ (u"ࠫࠬⵡ"),l1l11l_l1_ (u"ࠬ࠭ⵢ"),l1l11l_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧⵣ"))
		#addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⵤ"),menu_name+l1l11l_l1_ (u"ࠨๆ็วุ็ࠠๅษࠣฮําฯࠡไ้์ฬะࠠหๆไึํ์๊สࠢ็็ࠬⵥ"),l1l11l_l1_ (u"ࠩࠪⵦ"),9999)
		#addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⵧ"),menu_name+l1l11l_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆสๆึฮวย๋ࠢห้อีะไสลࠥ็โุࠩ⵨"),l1l11l_l1_ (u"ࠬ࠭⵩"),9999)
		#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⵪"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⵫"),l1l11l_l1_ (u"ࠨࠩ⵬"),9999)
		#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⵭"),menu_name+l1l11l_l1_ (u"࡙ࠪࡳ࡬࡯ࡳࡶࡸࡲࡦࡺࡥ࡭ࡻ࠯ࠤࡳࡵࠠࡕࡘࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠥ࡬࡯ࡳࠢࡼࡳࡺ࠭⵮"),l1l11l_l1_ (u"ࠫࠬⵯ"),9999)
		#addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⵰"),menu_name+l1l11l_l1_ (u"࠭ࡉࡵࠢ࡬ࡷࠥ࡬࡯ࡳࠢࡵࡩࡱࡧࡴࡪࡸࡨࡷࠥࠬࠠࡧࡴ࡬ࡩࡳࡪࡳࠡࡱࡱࡰࡾ࠭⵱"),l1l11l_l1_ (u"ࠧࠨ⵲"),9999)
	return
def PLAY(id):
	source,server,l1lll11l11_l1_,l11111l1l_l1_ = id.split(l1l11l_l1_ (u"ࠨ࠽࠾ࠫ⵳"))
	url = l1l11l_l1_ (u"ࠩࠪ⵴")
	if source==l1l11l_l1_ (u"࡙ࠪࡗࡒࠧ⵵"): url = l1lll11l11_l1_
	elif source==l1l11l_l1_ (u"ࠫࡌࡇࠧ⵶"):
		payload = { l1l11l_l1_ (u"ࠬ࡯ࡤࠨ⵷") : l1l11l_l1_ (u"࠭ࠧ⵸"), l1l11l_l1_ (u"ࠧࡶࡵࡨࡶࠬ⵹") : l1l11ll111l_l1_(32) , l1l11l_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ⵺") : l1l11l_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠳ࠪ⵻") , l1l11l_l1_ (u"ࠪࡱࡪࡴࡵࠨ⵼") : l1l11l_l1_ (u"ࠫࠬ⵽") }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⵾"),l11lll_l1_,payload,l1l11l_l1_ (u"⵿࠭ࠧ"),False,l1l11l_l1_ (u"ࠧࠨⶀ"),l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪⶁ"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠩࠪⶂ"),l1l11l_l1_ (u"ࠪࠫⶃ"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧⶄ"),l1l11l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭ⶅ"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l11111lll11_l1_ = cookies[l1l11l_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࠪⶆ")]
		url = response.headers[l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩⶇ")]
		payload = { l1l11l_l1_ (u"ࠨ࡫ࡧࠫⶈ") : l1lll11l11_l1_ , l1l11l_l1_ (u"ࠩࡸࡷࡪࡸࠧⶉ") : l1l11ll111l_l1_(32) , l1l11l_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬⶊ") : l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠶ࠬⶋ") , l1l11l_l1_ (u"ࠬࡳࡥ࡯ࡷࠪⶌ") : l1l11l_l1_ (u"࠭ࠧⶍ") }
		headers = { l1l11l_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧⶎ") : l1l11l_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࡂ࠭ⶏ")+l11111lll11_l1_ }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ⶐ"),l11lll_l1_,payload,headers,l1l11l_l1_ (u"ࠪࠫⶑ"),l1l11l_l1_ (u"ࠫࠬⶒ"),l1l11l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧⶓ"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"࠭ࠧⶔ"),l1l11l_l1_ (u"ࠧࠨⶕ"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⶖ"),l1l11l_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ⶗"))
			return
		html = response.content
		url = re.findall(l1l11l_l1_ (u"ࠪࡶࡪࡹࡰࠣ࠼ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃࡲ࠹ࡵ࠹ࠫࠫ࠲࠯ࡅࠩࠣࠩ⶘"),html,re.DOTALL)
		l1111l_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ⶙"),l1l11l_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭⶚")+l1111l_l1_)
		#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ⶛"),l1l11l_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠠࠨ⶜")+params)
		l11111ll1ll_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠵࠻࠲ࠬ⶝")+server+l1l11l_l1_ (u"ࠩ࠺࠻࠼࠵ࠧ⶞")+l1lll11l11_l1_+l1l11l_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ⶟")+params
		l11111ll1l1_l1_ = l11111ll1ll_l1_.replace(l1l11l_l1_ (u"ࠫ࠸࠼࠺࠸ࠩⶠ"),l1l11l_l1_ (u"ࠬ࠺࠰࠻࠹ࠪⶡ")).replace(l1l11l_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨⶢ"),l1l11l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ⶣ"))
		l11111lll1l_l1_ = l11111ll1ll_l1_.replace(l1l11l_l1_ (u"ࠨ࠵࠹࠾࠼࠭ⶤ"),l1l11l_l1_ (u"ࠩ࠷࠶࠿࠽ࠧⶥ")).replace(l1l11l_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬⶦ"),l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ⶧"))
		l1l1lll_l1_ = [l1l11l_l1_ (u"ࠬࡎࡄࠨⶨ"),l1l11l_l1_ (u"࠭ࡓࡅ࠳ࠪⶩ"),l1l11l_l1_ (u"ࠧࡔࡆ࠵ࠫⶪ")]
		l1ll1lll_l1_ = [l11111ll1ll_l1_,l11111ll1l1_l1_,l11111lll1l_l1_]
		selection = 0
		#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧⶫ"), l1l1lll_l1_)
		if selection == -1: return
		else: url = l1ll1lll_l1_[selection]
	elif source==l1l11l_l1_ (u"ࠩࡑࡘࠬⶬ"):
		headers = { l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩⶭ") : l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪⶮ") }
		payload = { l1l11l_l1_ (u"ࠬ࡯ࡤࠨ⶯") : l1lll11l11_l1_ , l1l11l_l1_ (u"࠭ࡵࡴࡧࡵࠫⶰ") : l1l11ll111l_l1_(32) , l1l11l_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩⶱ") : l1l11l_l1_ (u"ࠨࡲ࡯ࡥࡾࡔࡔࠨⶲ") , l1l11l_l1_ (u"ࠩࡰࡩࡳࡻࠧⶳ") : l11111l1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨⶴ"), l11lll_l1_, payload, headers, False,l1l11l_l1_ (u"ࠫࠬⶵ"),l1l11l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧⶶ"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⶷"),l1l11l_l1_ (u"ࠧࠨⶸ"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⶹ"),l1l11l_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪⶺ"))
			return
		html = response.content
		url = response.headers[l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬⶻ")]
		url = url.replace(l1l11l_l1_ (u"ࠫࠪ࠸࠰ࠨⶼ"),l1l11l_l1_ (u"ࠬࠦࠧⶽ"))
		url = url.replace(l1l11l_l1_ (u"࠭ࠥ࠴ࡆࠪⶾ"),l1l11l_l1_ (u"ࠧ࠾ࠩ⶿"))
		if l1l11l_l1_ (u"ࠨࡎࡨࡥࡷࡴࠧⷀ") in l1lll11l11_l1_:
			url = url.replace(l1l11l_l1_ (u"ࠩࡑࡘࡓࡔࡩ࡭ࡧࠪⷁ"),l1l11l_l1_ (u"ࠪࠫⷂ"))
			url = url.replace(l1l11l_l1_ (u"ࠫࡱ࡫ࡡࡳࡰ࡬ࡲ࡬࠷ࠧⷃ"),l1l11l_l1_ (u"ࠬࡒࡥࡢࡴࡱ࡭ࡳ࡭ࠧⷄ"))
	elif source==l1l11l_l1_ (u"࠭ࡐࡍࠩⷅ"):
		#headers = { l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ⷆ") : l1l11l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ⷇") }
		payload = { l1l11l_l1_ (u"ࠩ࡬ࡨࠬⷈ") : l1lll11l11_l1_ , l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࠨⷉ") : l1l11ll111l_l1_(32) , l1l11l_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭ⷊ") : l1l11l_l1_ (u"ࠬࡶ࡬ࡢࡻࡓࡐࠬⷋ") , l1l11l_l1_ (u"࠭࡭ࡦࡰࡸࠫⷌ") : l11111l1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬⷍ"), l11lll_l1_, payload, l1l11l_l1_ (u"ࠨࠩⷎ"),False,l1l11l_l1_ (u"ࠩࠪ⷏"),l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬⷐ"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠫࠬⷑ"),l1l11l_l1_ (u"ࠬ࠭ⷒ"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩⷓ"),l1l11l_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨⷔ"))
			return
		html = response.content
		url = response.headers[l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪⷕ")]
		headers = {l1l11l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪⷖ"):response.headers[l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ⷗")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩⷘ"),url, l1l11l_l1_ (u"ࠬ࠭ⷙ"),headers , l1l11l_l1_ (u"࠭ࠧⷚ"),l1l11l_l1_ (u"ࠧࠨⷛ"),l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪⷜ"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠩࠪⷝ"),l1l11l_l1_ (u"ࠪࠫⷞ"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⷟"),l1l11l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭ⷠ"))
			return
		html = response.content
		items = re.findall(l1l11l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⷡ"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l11l_l1_ (u"ࠧࡕࡃࠪⷢ"),l1l11l_l1_ (u"ࠨࡈࡐࠫⷣ"),l1l11l_l1_ (u"ࠩ࡜࡙ࠬⷤ"),l1l11l_l1_ (u"࡛ࠪࡘ࠷ࠧⷥ"),l1l11l_l1_ (u"ࠫ࡜࡙࠲ࠨⷦ"),l1l11l_l1_ (u"ࠬࡘࡌ࠲ࠩⷧ"),l1l11l_l1_ (u"࠭ࡒࡍ࠴ࠪⷨ")]:
		if source==l1l11l_l1_ (u"ࠧࡕࡃࠪⷩ"): l1lll11l11_l1_ = id
		headers = { l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧⷪ") : l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨⷫ") }
		payload = { l1l11l_l1_ (u"ࠪ࡭ࡩ࠭ⷬ") : l1lll11l11_l1_ , l1l11l_l1_ (u"ࠫࡺࡹࡥࡳࠩⷭ") : l1l11ll111l_l1_(32) , l1l11l_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧⷮ") : l1l11l_l1_ (u"࠭ࡰ࡭ࡣࡼࠫⷯ")+source , l1l11l_l1_ (u"ࠧ࡮ࡧࡱࡹࠬⷰ") : l11111l1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭ⷱ"),l11lll_l1_,payload,headers,l1l11l_l1_ (u"ࠩࠪⷲ"),l1l11l_l1_ (u"ࠪࠫⷳ"),l1l11l_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠹ࡸ࡭࠭ⷴ"))
		if not response.succeeded:
			DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ⷵ"),l1l11l_l1_ (u"࠭ࠧⷶ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪⷷ"),l1l11l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩⷸ"))
			return
		html = response.content
		url = response.headers[l1l11l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫⷹ")]
		if source==l1l11l_l1_ (u"ࠪࡊࡒ࠭ⷺ"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨⷻ"), url, l1l11l_l1_ (u"ࠬ࠭ⷼ"), l1l11l_l1_ (u"࠭ࠧⷽ"), False,l1l11l_l1_ (u"ࠧࠨⷾ"),l1l11l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠷ࡵࡪࠪⷿ"))
			url = response.headers[l1l11l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ⸀")]
			url = url.replace(l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ⸁"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⸂"))
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ⸃"))
	return
# -*- coding: utf-8 -*-

"""
# calculate the average time needed to import a main-module and how many sub-modules will be imported with it
import sys,time
totalelpased = 0
for i in range(20):
	t1 = time.time()
	before_import = list(sys.modules.keys())
	import traceback
	after_import = list(sys.modules.keys())
	import_list = list(set(after_import)-set(before_import))
	for modu in import_list:
		del(sys.modules[modu])
	after_delete = list(sys.modules.keys())
	t2 = time.time()
	elpased = t2-t1
	totalelpased += elpased
before_import_count = len(before_import)
after_import_count = len(after_import)
import_count = len(import_list)
after_delete_count = len(after_delete)
#print('import_count: '+str(import_count))
#print('average time ms: '+str(totalelpased*1000/20))
import xbmcgui
DIALOG_OK('','','number of modules imported: '+str(import_count),'average time ms: '+str(totalelpased*1000/20))
EXIT_using_ERROR
"""

"""
# to check if main-module will import what sub-modules
# example: importing "requests" will also import "urllib","urllib2" and "urllib3"
import sys
before_import = list(sys.modules.keys())
import urlresolver
after_import = list(sys.modules.keys())
import_list = list(set(after_import)-set(before_import))
list = ''
if 'urllib' in after_import: list += 'urllib '
if 'urllib2' in after_import: list += 'urllib2 '
if 'urllib3' in after_import: list += 'urllib3 '
if 'requests' in after_import: list += 'requests '
import xbmcgui
DIALOG_OK('','','yes exists: ',list)
"""

import xbmcplugin,xbmcgui,xbmcaddon,xbmc,sys,os,re,time,xbmcvfs
import random,base64,traceback,zlib,pickle,sqlite3

kodi_release = xbmc.getInfoLabel("System.BuildVersion")
kodi_version = re.findall('(\d\d\.\d)',kodi_release,re.DOTALL)
kodi_version = float(kodi_version[0])

contentsDICT = {}
menuItemsLIST = []

script_name = 'LIBRARY'

addon_handle = int(sys.argv[1])
addon_id = sys.argv[0].split('/')[2]	# plugin.video.arabicvideos
addon_name = addon_id.split('.')[2]		# arabicvideos
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
#addon_url = sys.argv[0]+addon_path		# plugin://plugin.video.arabicvideos/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel('ListItem.FolderPath')
addon_version = xbmc.getInfoLabel('System.AddonVersion('+addon_id+')')

settings = xbmcaddon.Addon(id=addon_id)

now = int(time.time())

EMPTY_SITES = ['ALMAAREF']
NOSEARCH_SITES = ['YTB_CHANNELS']
DEAD_SITES = ['ARBLIONZ','ALKAWTHAR','EGYBESTVIP','EGYDEAD','MOVIZLAND','MOVS4U','AKOAM','MYCIMA']
DEAD_SITES += ['HELAL','SERIES4WATCH','AKOAMCAM','EGYBEST','CIMACLUP','EGYNOW','SHOOFPRO']

SITES_SERVERS_PRIVATE_begin = ['IPTV','IPTV-LIVE','IPTV-MOVIES','IPTV-SERIES']
SITES_SERVERS_PRIVATE_begin += ['IFILM','IFILM-ARABIC','IFILM-ENGLISH']
SITES_SERVERS_PRIVATE_begin += ['ALFATIMI','ALARAB','AKWAM','ALMAAREF','BOKRA','KARBALATV','SHOOFMAX']		# 'EGYBEST',
#SITES_SERVERS_PRIVATE_begin += ['PANET','PANET-MOVIES','PANET-SERIES','ALKAWTHAR']
#SITES_SERVERS_PRIVATE_begin += ['SHIAVOICE','SHIAVOICE-AUDIOS','SHIAVOICE-PERSONS','SHIAVOICE-ALBUMS']

SITES_SERVERS_PRIVATE_end = ['YOUTUBE','YOUTUBE-VIDEOS','YOUTUBE-PLAYLISTS','YOUTUBE-CHANNELS']
SITES_SERVERS_PRIVATE_end += ['DAILYMOTION','DAILYMOTION-VIDEOS','DAILYMOTION-PLAYLISTS','DAILYMOTION-CHANNELS']

SITES_SERVERS_MIXED = ['FAJERSHOW','CIMANOW','LODYNET','ARABSEED']
SITES_SERVERS_MIXED += ['CIMA4U','SHAHID4U','TVFUN','WECIMA']   # 'AKOAM','MYCIMA'
#SITES_SERVERS_MIXED += ['EGYBESTVIP','MOVS4U']

SITES_SERVERS_PUBLIC = ['CIMAABDO','HALACIMA','CIMAFANS','CIMALIGHT']	# ,'EGYNOW'
#SITES_SERVERS_PUBLIC += ['ARBLIONZ','HELAL','SERIES4WATCH','MOVIZLAND','CIMACLUP','EGYDEAD','AKOAMCAM']

SEARCH_REGULAR_SITES  = ['AKWAM','ALARAB','ALFATIMI','ARABSEED','BOKRA']   # 'AKOAM'
SEARCH_REGULAR_SITES += ['CIMA4U','CIMAFANS','CIMALIGHT','CIMANOW','WECIMA']      #  'MYCIMA'
SEARCH_REGULAR_SITES += ['FAJERSHOW','HALACIMA','KARBALATV']		# 'EGYBEST','EGYNOW','SHOOFPRO'
SEARCH_REGULAR_SITES += ['LODYNET','SHAHID4U','SHOOFMAX','TVFUN','CIMAABDO']

SEARCH_MULTI_SITES  = ['DAILYMOTION-VIDEOS','DAILYMOTION-PLAYLISTS','DAILYMOTION-CHANNELS']
SEARCH_MULTI_SITES += ['IFILM-ARABIC','IFILM-ENGLISH']
SEARCH_MULTI_SITES += ['YOUTUBE-VIDEOS','YOUTUBE-PLAYLISTS','YOUTUBE-CHANNELS']
SEARCH_MULTI_SITES += ['IPTV-LIVE','IPTV-MOVIES','IPTV-SERIES']
#SEARCH_MULTI_SITES += ['PANET-MOVIES','PANET-SERIES']
#SEARCH_MULTI_SITES += ['SHIAVOICE-PERSONS','SHIAVOICE-ALBUMS','SHIAVOICE-AUDIOS']

SEARCH_UNIQUE_SITES = ['IPTV','DAILYMOTION','IFILM','YOUTUBE']		# ,'PANET']   # ,'SHIAVOICE'

ALL_SEARCH_SITES = SEARCH_REGULAR_SITES+SEARCH_MULTI_SITES
SEARCH_SITES_REGULAR = SEARCH_REGULAR_SITES+SEARCH_UNIQUE_SITES
SECTIONS_SITES = SEARCH_REGULAR_SITES+SEARCH_UNIQUE_SITES+EMPTY_SITES
SITES_SERVERS_SORTED = SITES_SERVERS_PRIVATE_begin+SITES_SERVERS_MIXED+SITES_SERVERS_PUBLIC+SITES_SERVERS_PRIVATE_end

NO_EXIT_LIST = [ 'LIBRARY-PROXY_TEST-1st'
				,'LIBRARY-OPENURL_HTTPSPROXIES-1st'
				,'LIBRARY-OPENURL_WEBPROXIES-1st'
				,'LIBRARY-OPENURL_WEBPROXIES-2nd'
				,'LIBRARY-OPENURL_WEBPROXYTO-1st'
				,'LIBRARY-OPENURL_WEBPROXYTO-2nd'
				,'LIBRARY-OPENURL_KPROXYCOM-1st'
				,'LIBRARY-OPENURL_KPROXYCOM-2nd'
				,'LIBRARY-OPENURL_KPROXYCOM-3rd'
				,'LIBRARY-CHECK_HTTPS_PROXIES-1st'
				,'LIBRARY-EXTRACT_M3U8-1st'
				,'LIBRARY-SEND_ANALYTICS_EVENT-1st'
				,'LIBRARY-GET_PROXIES_LIST-1st'
				,'LIBRARY-READ_ALL_ADDONS_XML-1st'
				,'SERVICES-HTTPS_TEST-1st'
				,'SERVICES-TEST_ALL_WEBSITES-1st'
				,'SERVICES-TEST_ALL_WEBSITES-2nd'
				,'SERVICES-USAGE_REPORT-1st'
				,'MENUS-SHOW_MESSAGES-1st'
				,'LIBRARY-RANDOM_USERAGENT-1st'
				,'IPTV-CHECK_ACCOUNT-1st'
				#,'CIMAFANS-ITEMS-1st'
				#,'DAILYMOTION-CHANNELS_SUBMENU-1st'
				#,'ALARAB-PLAY-2nd'
				#,'ALARAB-PLAY-3rd'
				#,'MYCIMA-MENU-2nd'
				#,'SERVICES-GET_LATEST_VERSION_NUMBERS-1st'
				#,'EGYBESTVIP-PLAY-2nd'
				#,'EGYBESTVIP-PLAY-3rd'
				#,'SHAHID4U-MENU-1st'
				]

UNIMPORTANT_REQUESTS = [ 'LIBRARY-SEND_ANALYTICS_EVENT-1st'
						]
DNS_SERVERS = ['8.8.8.8','1.1.1.1','1.0.0.1','8.8.4.4','208.67.222.222','208.67.220.220']

WEBSITES = { 
			#,'AKOAMCAM'	:['https://akoam.cam']
			#,'ARBLIONZ'	:['https://arblionz.net']    #  https://arblionz.com  https://arblionz.art  http://www.arblionz.org
			#,'EGY4BEST'	:['https://egybest.vip']
			#,'EGYBESTVIP'	:['https://egybest.vip']
			#,'HELAL'		:['https://4helal.me']    #  https://4helal.tv  https://4helal.cc
			#,'MOVIZLAND'	:['https://movizland.online','https://m.movizland.online']
			#,'MOVS4U'		:['https://www.movs4u.ws']    #  .ws  .life  .tv  .com
			#,'SERIES4WATCH':['https://series4watch.net']    #  https://s4w.tv
			#,'SHIAVOICE'	:['https://shiavoice.com']
			#'AKOAM'		:['https://akoam.net']
			 'AKWAM'		:['https://akwam.net']
			,'ALARAB'		:['https://vod.alarab.com']
			,'ALFATIMI'		:['http://alfatimi.tv']
			,'ALKAWTHAR'	:['https://www.alkawthartv.ir']    #  https://www.alkawthartv.com
			,'ALMAAREF'		:['https://almaaref.ch']    #  http://www.almaareftv.com/old  http://www.almaareftv.com
			,'ARABSEED'		:['https://arabseed.net']
			,'BOKRA'		:['https://shahidlive.co']    # http://shoofvod.com
			,'CIMA4U'		:['https://cima4u.com']  #  https://cima4u.rocks  https://cima4u.mx
			,'CIMAABDO'		:['https://cimaabdo.com']
			,'CIMACLUP'		:['https://cima-club.io']    #  cima-club.cc  cimaclub.com
			,'CIMAFANS'		:['https://www.cimafans.com']    #  https://4helal.me
			,'CIMALIGHT'	:['https://cimalight.com']
			,'CIMANOW'		:['https://cima-now.com']
			,'DAILYMOTION'	:['https://www.dailymotion.com','https://graphql.api.dailymotion.com']
			#,'EGYBEST'		:['http://egybest.net']    #  iegybest.co  egybest.org  egy.best  egybest.ltd  egybest.me
			,'EGYDEAD'		:['https://egydead.live']
			#,'EGYNOW'		:['https://www.egynow.live']
			,'ELCINEMA'		:['https://elcinema.com']
			,'FAJERSHOW'	:['https://fajer.show']    #  https://show.alfajertv.com
			,'HALACIMA'		:['https://halacima.us']    #   https://halacima.net    www.halacima.co
			,'IFILM'		:['https://ar.ifilmtv.ir','https://en.ifilmtv.ir','https://fa.ifilmtv.ir','https://fa2.ifilmtv.ir','http://93.190.24.122']
			,'IPTV'			:['https://nowhere.com']
			,'KARBALATV'	:['https://karbala-tv.iq']    #  http://ktv.iq  https://karbala-tv.net
			,'KODIEMAD_APP'	:['https://tiny.cc/kodiemad','https://bit.ly/kodiemad']
			,'LODYNET'		:['https://lodynet.cam']
			#,'MYCIMA'		:['https://mycima.co']   # https://mycima.cam
			,'WECIMA'		:['https://wecima.tube']
			,'PANET'		:['http://www.panet.co.il']
			#,'PYTHON'		:['http://127.0.0.1:5000/listplay','http://127.0.0.1:5000/usagereport','http://127.0.0.1:5000/sendemail','http://127.0.0.1:5000/getmessages','http://127.0.0.1:5000/getislamic','http://127.0.0.1:5000/getquestions','http://127.0.0.1:5000/getknownerrors']
			#,'PYTHON'		:['http://emadmahdi.herokuapp.com/listplay','http://emadmahdi.herokuapp.com/usagereport','http://emadmahdi.herokuapp.com/sendemail','http://emadmahdi.herokuapp.com/getmessages','http://emadmahdi.herokuapp.com/getislamic','http://emadmahdi.herokuapp.com/getquestions','http://emadmahdi.herokuapp.com/getknownerrors']
			#,'PYTHON'		:['http://emadmahdi.pythonanywhere.com/listplay','http://emadmahdi.pythonanywhere.com/usagereport','http://emadmahdi.pythonanywhere.com/sendemail','http://emadmahdi.pythonanywhere.com/getmessages','http://emadmahdi.pythonanywhere.com/getislamic','http://emadmahdi.pythonanywhere.com/getquestions','http://emadmahdi.pythonanywhere.com/getknownerrors']
			#,'PYTHON'		:['http://kodiemad2.appspot.com/listplay','http://kodiemad2.appspot.com/usagereport','http://kodiemad2.appspot.com/sendemail','http://kodiemad2.appspot.com/getmessages','http://kodiemad2.appspot.com/getislamic','http://kodiemad2.appspot.com/getquestions','http://kodiemad2.appspot.com/getknownerrors']
			#,'PYTHON'		:['https://emadmahdi.vercel.app/listplay','https://emadmahdi.vercel.app/usagereport','https://emadmahdi.vercel.app/sendemail','https://emadmahdi.vercel.app/getmessages','https://emadmahdi.vercel.app/getislamic','https://emadmahdi.vercel.app/getquestions','https://emadmahdi.vercel.app/getknownerrors']
			,'PYTHON'		:['http://kodiemad.uk.to/listplay','http://kodiemad.uk.to/usagereport','http://kodiemad.uk.to/sendemail','http://kodiemad.uk.to/getmessages','http://kodiemad.uk.to/getislamic','http://kodiemad.uk.to/getquestions','http://kodiemad.uk.to/getknownerrors']
			#,'REPOS'		:['http://127.0.0.1:5000','http://127.0.0.1:5000/KODIREPO/ADDONS/addons.xml','http://127.0.0.1:5000/KODIREPO/ADDONS18/addons18.xml','http://127.0.0.1:5000/KODIREPO/ADDONS19/addons19.xml']
			,'REPOS'		:['http://kodirepo.uk.to','http://kodirepo.uk.to/ADDONS/addons.xml','http://kodirepo.uk.to/ADDONS18/addons18.xml','http://kodirepo.uk.to/ADDONS19/addons19.xml']
			,'SHAHID4U'		:['https://shahed4u.fyi']  #	 https://shahed4u.mobi  https://shahed4u.rest  https://shahidforu.co  https://shahed4u.fun   https://shahid4u.com  https://shahid4u.onl  https://shahid4u.tv  https://shahid4u.net
			,'SHOOFMAX'		:['https://shoofmax.com','https://static.shoofmax.com','https://shoofmax.azureedge.net']
			#,'SHOOFPRO'	:['https://c.shoofpro.online']    #	'https://shoofpro.com'
			,'TVFUN'		:['https://tvfun.me']    #  https://tvksa.com
			,'YOUTUBE'		:['https://www.youtube.com']
			,'SOURCES'		:['https://emadmahdi.pythonanywhere.com/kodi','https://kodiemad.surge.sh/kodi']
			}

def TRANSLATE(text):
	dict = {
	 'old'			:'قديم'
	,'disabled'		:'متوقف'
	,'missing'		:'مفقود'
	,'good'			:'جيد'
	,'failed'		:'فشل'
	,'folder'		:'مجلد'
	,'video'		:'فيديو'
	,'live'			:'قناة'
	,'AKOAM'		:'موقع أكوام القديم'
	,'AKWAM'		:'موقع أكوام الجديد'
	,'AKOAMCAM'		:'موقع أكوام كام'
	,'ALARAB'		:'موقع كل العرب'
	,'ALFATIMI'		:'موقع المنبر الفاطمي'
	,'ALKAWTHAR'	:'موقع قناة الكوثر'
	,'ALMAAREF'		:'موقع قناة المعارف'
	,'ARBLIONZ'		:'موقع عرب ليونز'
	,'EGYBESTVIP'	:'موقع ايجي بيست vip'
	,'ELCINEMA'		:'موقع السينما'
	,'HELAL'		:'موقع هلال يوتيوب'
	,'CIMAFANS'		:'موقع سيما فانز'
	,'SHAHID4U'		:'موقع شاهد فوريو'
	,'SHOOFMAX'		:'موقع شوف ماكس'
	,'ARABSEED'		:'موقع عرب سييد'
	,'CIMANOW'		:'موقع سيما ناو'
	,'KARBALATV'	:'موقع قناة كربلاء'
	,'YTB_CHANNELS'	:'مواقع يوتيوب'
	,'MYCIMA'		:'موقع ماي سيما'
	,'WECIMA'		:'موقع وي سيما'
	,'BOKRA'		:'موقع بكرا'
	,'CIMAABDO'		:'موقع سيما عبدو'
	,'LIVETV'		:'ملف'
	,'LIBRARY'		:'ملف'
	,'MOVS4U'		:'موقع موفز فوريو'
	,'FAJERSHOW'	:'موقع فجر شو'
	,'EGYBEST'		:'موقع ايجي بيست'
	,'CIMA4U'		:'موقع سيما فوريو'
	,'EGYNOW'		:'موقع إيجي ناو'
	,'EGYDEAD'		:'موقع إيجي ديد'
	,'HALACIMA'		:'موقع هلا سيما'
	,'LODYNET'		:'موقع لودي نت'
	,'TVFUN'		:'موقع تيفي فان'
	,'CIMALIGHT'	:'موقع سيما لايت'
	,'SHOOFPRO'		:'موقع شوف برو'
	,'CIMACLUP'		:'موقع سيما كلوب'
	,'IFILM'				:'موقع قناة آي فيلم'
	,'IFILM-ARABIC'			:'موقع قناة آي فيلم عربي'
	,'IFILM-ENGLISH'		:'موقع قناة آي فيلم انجليزي'
	,'IPTV'					:'IPTV'
	,'IPTV-LIVE'			:'IPTV قنوات'
	,'IPTV-MOVIES'			:'IPTV أفلام'
	,'IPTV-SERIES'			:'IPTV مسلسلات'
	,'PANET'				:'موقع بانيت'
	,'PANET-MOVIES'			:'موقع بانيت افلام'
	,'PANET-SERIES'			:'موقع بانيت مسلسلات'
	,'YOUTUBE'				:'موقع يوتيوب'
	,'YOUTUBE-VIDEOS'		:'موقع يوتيوب فيديوهات'
	,'YOUTUBE-PLAYLISTS'	:'موقع يوتيوب قوائم'
	,'YOUTUBE-CHANNELS'		:'موقع يوتيوب قنوات'
	,'SHIAVOICE'			:'موقع صوت الشيعة'
	,'SHIAVOICE-PERSONS'	:'موقع صوت الشيعة قارئ'
	,'SHIAVOICE-ALBUMS'		:'موقع صوت الشيعة البوم'
	,'SHIAVOICE-AUDIOS'		:'موقع صوت الشيعة صوتيات'
	,'DAILYMOTION'			:'موقع ديلي موشن'
	,'DAILYMOTION-VIDEOS'	:'موقع ديلي موشن فيديوهات'
	,'DAILYMOTION-PLAYLISTS':'موقع ديلي موشن قوائم'
	,'DAILYMOTION-CHANNELS'	:'موقع ديلي موشن قنوات'
	}
	if text in list(dict.keys()): return dict[text]
	return ''

def GET_ALL_KODI_MENU_ITEMS(MENUS__LAST_VIDEOS_MENU):
	KodiMenuList = []
	HOUR_ = 60*60
	import FAVOURITES
	for menuItem in menuItemsLIST:
		type_,name,url,mode,image,text1,text2,context,infodict = menuItem
		mode = int(mode)
		datetime = re.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',name,re.DOTALL)
		if datetime:
			datetime,date,time = datetime[0]
			name = name.replace(datetime,'')
		name2 = name
		site = re.findall('^_(\w\w\w)_(.*?)$',name,re.DOTALL)
		if site:
			site,name = site[0]
			modified = '_MOD_' in name
			folder = type_=='folder'
			if modified and folder: start = ';'
			elif modified and not folder: start = half_triangular_colon
			elif not modified and folder: start = ','
			elif not modified and not folder: start = ' '
			name = name.replace('_MOD_','')
			site = start+'[COLOR FFC89008]'+site+' [/COLOR]'
		else: site = ''
		if datetime:
			if kodi_version<19:
				datetime = '[COLOR FFFFFF00]'+date+' '+time+'[/COLOR]'
				if site: name = datetime+' '+site+ltr+name
				else: name = datetime+rtl+name+' '
			elif kodi_version>18.99:
				if site:
					datetime = '[COLOR FFFFFF00]'+date+' '+time+'[/COLOR]'
					name = datetime+' '+site+name
				else:
					datetime = '[COLOR FFFFFF00]'+time+' '+date+'[/COLOR]'
					name = name+' '+rtl+datetime
		elif site:
			name = name.replace('بحث IPTV ',rtl+'بحث IPTV '+rtl)
			special_first_letter = re.findall('^[ -~]',name,re.DOTALL)
			if kodi_version<19:
				if special_first_letter: name = site+ltr+name
				else: name = site+name
			elif kodi_version>18.99:
				if special_first_letter: name = site+name
				else: name = site+rtl+name
		listitem = xbmcgui.ListItem(name)
		menuItem = (type_,name2,url,str(mode),image,'',text2,context,'')
		newpath_dict = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
		newpath_dict['name'] = QUOTE(name2)
		newpath_dict['type'] = type_.strip(' ')
		newpath_dict['mode'] = str(mode).strip(' ')
		if type_=='folder' and text1: newpath_dict['page'] = QUOTE(text1.strip(' '))
		if context: newpath_dict['context'] = context.strip(' ')
		if text2: newpath_dict['text'] = QUOTE(text2.strip(' '))
		if infodict:
			infodict = str(infodict)
			newpath_dict['infodict'] = QUOTE(infodict.strip(' '))
			infodict = eval(infodict)
		else: infodict = {}
		if 'plot' in list(infodict.keys()): listitem.setInfo('video',{'PlotOutline':infodict['plot'],'Plot':infodict['plot']})
		if 'stars' in list(infodict.keys()): listitem.setInfo('video',{'Rating':infodict['stars']})
		if image:
			listitem.setArt({'icon':image,'thumb':image,'fanart':image})
			newpath_dict['image'] = QUOTE(image.strip(' '))
		else:
			listitem.setInfo('video',{'Title':name})
			listitem.setArt({'icon':defaulticon,'thumb':defaultthumb,'fanart':defaultfanart})
		if url: newpath_dict['url'] = QUOTE(url.strip(' '))
		context_menu = []
		newpath = 'plugin://'+addon_id+'/?type='+newpath_dict['type']+'&mode='+newpath_dict['mode']
		if newpath_dict['page']: newpath += '&page='+newpath_dict['page']
		if newpath_dict['name']: newpath += '&name='+newpath_dict['name']
		if newpath_dict['text']: newpath += '&text='+newpath_dict['text']
		if newpath_dict['infodict']: newpath += '&infodict='+newpath_dict['infodict']
		if newpath_dict['image']: newpath += '&image='+newpath_dict['image']
		if newpath_dict['url']: newpath += '&url='+newpath_dict['url']
		if mode!=265: context_menu += FAVOURITES.GET_FAVOURITES_CONTEXT_MENU(menuItem,newpath)
		if newpath_dict['context']: newpath += '&context='+newpath_dict['context']
		if mode in [235,238] and type_=='live' and 'EPG' in context:
			run_path = 'plugin://'+addon_id+'?mode=238&text=SHORT_EPG&url='+url
			run_text = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		if mode==265:
			length = MENUS__LAST_VIDEOS_MENU(text2,True)
			if length>0:
				run_path = 'plugin://'+addon_id+'?mode=266&text='+text2
				run_text = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+TRANSLATE(text2)+'[/COLOR]'
				run_item = (run_text,'RunPlugin('+run_path+')')
				context_menu.append(run_item)
		if type_=='video' and mode!=331:
			run_path = newpath+'&context=6_DOWNLOAD'
			run_text = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		if mode==331:
			run_path = newpath+'&context=6_DELETE'
			run_text = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		if type_=='folder' and mode==540:
			all_words = READ_FROM_SQL3(cache_dbfile,'list','GLOBALSEARCH_SITES')
			if all_words:
				run_path = 'plugin://'+addon_id+'?context=7'
				run_text = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
				run_item = (run_text,'RunPlugin('+run_path+')')
				context_menu.append(run_item)
		MAIN_MENU_MODES = [9990,7,100,151,159,165,176,196,199,230,261,263,264,265,267,268,270,290,330,341,346,348,501,505,510,540]
		if mode not in MAIN_MENU_MODES:
			run_path = 'plugin://'+addon_id+'?context=8&mode=260'
			run_text = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
			run_item = (run_text,'RunPlugin('+run_path+')')
			context_menu.append(run_item)
		NON_SITES_MENUS = [0,150,160,170,190,260,280,330,340,410,500,520,530,560]
		if mode%10 and mode!=9990:
			site_mode = mode-mode%10
			if site_mode==280: site_mode = 230
			if site_mode==410: site_mode = 400
			if site_mode==520: site_mode = 510
			if site_mode not in NON_SITES_MENUS:
				run_path = 'plugin://'+addon_id+'?context=8&mode='+str(site_mode)
				run_text = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
				run_item = (run_text,'RunPlugin('+run_path+')')
				context_menu.append(run_item)
		run_path = newpath+'&context=9'
		run_text = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
		run_item = (run_text,'RunPlugin('+run_path+')')
		context_menu.append(run_item)
		listitem.addContextMenuItems(context_menu)
		if type_ in ['link','video','live']: isFolder = False
		elif type_=='folder': isFolder = True
		if type_=='video':
			listitem.setInfo('video',{'mediatype':'movie'})
			if text1:
				duration = re.findall('[\d:]+',text1,re.DOTALL)
				if duration:
					duration = '0:0:0:0:0:'+duration[0]
					dummy,days,hours,minutes,seconds = duration.rsplit(':',4)
					duration2 = int(days)*24*HOUR_+int(hours)*HOUR_+int(minutes)*60+int(seconds)
					listitem.setInfo('video',{'duration':duration2})
			listitem.setProperty('IsPlayable','true')
			xbmcplugin.setContent(addon_handle,'movies')
		KodiMenuList.append((newpath,listitem,isFolder))
	return KodiMenuList

def REMOVE_TAGS(word):
	if '[' in word and ']' in word:
		tags = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		colors1 = re.findall('\[COLOR .*?\]',word,re.DOTALL)
		colors2 = re.findall('\[COLOR###.*?\]',word,re.DOTALL)
		all_tags = tags+colors1+colors2
		for tag in all_tags: word = word.replace(tag,'')
	return word

def WRAP_THIS_TEXT(oldtext,fontsize,max_dialog_width,line_height):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	newtext,total_height,max_height = '',0,15000
	oldtext = oldtext.replace('[COLOR ','[COLOR###')
	textfont = PIL.ImageFont.truetype(fontfile,size=fontsize)
	txt = PIL.Image.new('RGBA',(max_dialog_width,99),(255,255,255,0))
	writing = PIL.ImageDraw.Draw(txt)
	max_dialog_width -= fontsize
	for oldline in oldtext.splitlines():
		total_height += line_height
		newline_width,newline = 0,''
		for word in oldline.split(' '):
			word_notags = REMOVE_TAGS(' '+word)
			word_width,word_height = writing.textsize(word_notags,font=textfont)
			if newline_width+word_width<max_dialog_width:
				if not newline: newline += word
				else: newline += ' '+word
				newline_width += word_width
			else:
				if word_width<max_dialog_width:
					newline += '\n '+word
					total_height += line_height
					newline_width = word_width
				else:
					while word_width>=max_dialog_width:
						for ii in range(1,len(' '+word),1):
							before = ' '+word[:ii]
							after = word[ii:]
							before_notags = REMOVE_TAGS(before)
							before_width,before_height = writing.textsize(before_notags,font=textfont)
							if newline_width+before_width>=max_dialog_width:
								after_width = word_width-before_width
								newline += before+'\n'
								total_height += line_height
								word_width = after_width
								if after_width>=max_dialog_width:
									newline_width = 0
									word = after
								else:
									newline_width = after_width
									newline += after
								break
				if total_height>max_height: break
		newtext += '\n'+newline
		if total_height>max_height: break
	newtext = newtext[1:]
	newtext = newtext.replace('[COLOR###','[COLOR ')
	return newtext

def FORMAT_IMAGE_TEXT(text):
	text = text.replace('\n','_sss__newline_')
	text = text.replace('[RTL]','_sss__linertl_')
	text = text.replace('[LEFT]','_sss__lineleft_')
	text = text.replace('[RIGHT]','_sss__lineright_')
	text = text.replace('[CENTER]','_sss__linecenter_')
	text = text.replace('[/COLOR]','_sss__endcolor_')
	colors = re.findall('\[COLOR (.*?)\]',text,re.DOTALL)
	for color in colors: text = text.replace('[COLOR '+color+']','_sss__newcolor'+color+'_')
	return text

def CREATE_IMAGE(button0,button1,button2,header,text,profile,text_direction,image_width,enable_progressbar):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper,bidi.algorithm
	if kodi_version<19:
		text = text.decode('utf8')
		header = header.decode('utf8')
		button0 = button0.decode('utf8')
		button1 = button1.decode('utf8')
		button2 = button2.decode('utf8')
	header_posx = 5
	header_upper_margin = 20
	header_sides_margin = 20
	header_lines_spacing = 0
	header_direction = 'center'
	text_posx = 0
	text_upper_margin = 19
	text_sides_margin = 30
	text_lines_spacing = 8
	text_wrap = True
	progressbar_posy = 375
	buttons_posy = 410
	buttons_height = 50
	buttons_width = 280
	buttons_text_posx = 28
	buttons_spacing = 5
	bottom_upper_margin = 0
	bottom_lower_margin = 31
	font_size = [36,32,28]
	if profile in ['notification','notification_twohalfs']:
		if profile=='notification_twohalfs':
			dialog_height = 'UPPER'
			header_direction = 'right'
			text_wrap = True
			header_lines_spacing = 10
		else:
			dialog_height = 97+20
			header_direction = 'left'
			text_wrap = False
		font_size = [33,33,33]
		header_sides_margin = 20
		header_upper_margin = 0
		text_sides_margin = 20
		text_upper_margin = 25+10
	elif profile=='confirm_bigfont': dialog_height = 500
	elif profile=='confirm_smallfont': font_size = [28,23,18] ; dialog_height = 500
	elif profile=='textview_bigfont': dialog_height = 740
	elif profile=='textview_bigfont_long': dialog_height = 'UPPER'
	elif profile=='textview_smallfont': font_size = [28,23,18] ; dialog_height = 740
	elif profile=='textview_smallfont_long': font_size = [28,23,18] ; dialog_height = 'UPPER'
	header_fontsize = font_size[0]
	text_fontsize = font_size[1]
	buttons_fontsize = font_size[2]
	header_font = PIL.ImageFont.truetype(fontfile,size=header_fontsize)
	text_font = PIL.ImageFont.truetype(fontfile,size=text_fontsize)
	buttons_font = PIL.ImageFont.truetype(fontfile,size=buttons_fontsize)
	txt = PIL.Image.new('RGBA',(100,100),(255,255,255,0))
	writing = PIL.ImageDraw.Draw(txt)
	text_line_width,text_line_height = writing.textsize('HHH BBB 888 000',font=text_font)
	header_line_width,header_line_height = writing.textsize('HHH BBB 888 000',font=header_font)
	header_lines_count = header.count('\n')+1
	header_total_height = header_upper_margin+header_lines_count*(header_line_height+header_lines_spacing)-header_lines_spacing
	arabic_config = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	reshaper = arabic_reshaper.ArabicReshaper(configuration=arabic_config)
	if text:
		text_max_width = image_width-text_sides_margin*2
		text_line_height_with_spacing = text_line_height+text_lines_spacing
		textreshaped = reshaper.reshape(text)
		if text_wrap:
			text_with_tags = WRAP_THIS_TEXT(textreshaped,text_fontsize,text_max_width,text_line_height_with_spacing)
			text_with_notags = REMOVE_TAGS(text_with_tags)
			text_lines_count = text_with_notags.count('\n')+1
			if text_lines_count<6:
				if text_lines_count<4: new_text_max_width = int(0.8*text_max_width)
				else: new_text_max_width = int(0.9*text_max_width)
				text_with_tags = WRAP_THIS_TEXT(textreshaped,text_fontsize,new_text_max_width,text_line_height_with_spacing)
				text_with_notags = REMOVE_TAGS(text_with_tags)
				text_lines_count = text_with_notags.count('\n')+1
			text_total_height = text_upper_margin+text_lines_count*text_line_height_with_spacing-text_lines_spacing
		else:
			text_total_height = text_upper_margin+text_line_height
			text_with_notags = textreshaped.split('\n')[0]
			text_with_tags = textreshaped.split('\n')[0]
	else: text_total_height = text_upper_margin
	bottom_total_height = bottom_upper_margin+bottom_lower_margin
	if enable_progressbar:
		progressbar_with_spacing_height = buttons_posy-progressbar_posy
		bottom_total_height += progressbar_with_spacing_height
	else: progressbar_with_spacing_height = 0
	if button0 or button1 or button2: bottom_total_height += buttons_height
	if dialog_height!='UPPER': image_height = dialog_height
	else: image_height = header_total_height+text_total_height+bottom_total_height
	text_available_height = image_height-header_total_height-bottom_total_height-text_upper_margin
	txt = PIL.Image.new('RGBA',(image_width,image_height),(255,255,255,0))
	writing = PIL.ImageDraw.Draw(txt)
	if not button1 and button0 and button2:
		buttons_text_posx += 105
		buttons_spacing -= 110
	if header:
		header_posy = header_upper_margin
		header = bidi.algorithm.get_display(reshaper.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,height = writing.textsize(line,font=header_font)
				if header_direction=='center': header_posx2 = header_posx+(image_width-width)/2
				elif header_direction=='right': header_posx2 = header_posx+image_width-width-header_sides_margin
				elif header_direction=='left': header_posx2 = header_posx+header_sides_margin
				writing.text((header_posx2,header_posy),line,font=header_font,fill='yellow')
			header_posy += header_fontsize+header_lines_spacing
	if button0 or button1 or button2:
		buttons_text_posy = header_total_height+text_available_height+text_upper_margin+progressbar_with_spacing_height+bottom_upper_margin
		if button0:
			button0 = bidi.algorithm.get_display(reshaper.reshape(button0))
			button0_width,button0_height = writing.textsize(button0,font=buttons_font)
			button0_text_posx = buttons_text_posx+0*(buttons_spacing+buttons_width)+(buttons_width-button0_width)/2
			writing.text((button0_text_posx,buttons_text_posy),button0,font=buttons_font,fill='yellow')
		if button1:
			button1 = bidi.algorithm.get_display(reshaper.reshape(button1))
			button1_width,button1_height = writing.textsize(button1,font=buttons_font)
			button1_text_posx = buttons_text_posx+1*(buttons_spacing+buttons_width)+(buttons_width-button1_width)/2
			writing.text((button1_text_posx,buttons_text_posy),button1,font=buttons_font,fill='yellow')
		if button2:
			button2 = bidi.algorithm.get_display(reshaper.reshape(button2))
			button2_width,button2_height = writing.textsize(button2,font=buttons_font)
			button2_text_posx = buttons_text_posx+2*(buttons_spacing+buttons_width)+(buttons_width-button2_width)/2
			writing.text((button2_text_posx,buttons_text_posy),button2,font=buttons_font,fill='yellow')
	if text:
		lines_posx,lines_width = [],[]
		text_with_tags = FORMAT_IMAGE_TEXT(text_with_tags)
		splitted_lines = text_with_tags.split('_sss__newline_')
		for line_and_styles in splitted_lines:
			line_direction = text_direction
			if   '_sss__lineleft_' in line_and_styles: line_direction = 'left'
			elif '_sss__lineright_' in line_and_styles: line_direction = 'right'
			elif '_sss__linecenter_' in line_and_styles: line_direction = 'center'
			line_no_styles = line_and_styles
			tags = re.findall('_sss__.*?_',line_and_styles,re.DOTALL)
			for tag in tags: line_no_styles = line_no_styles.replace(tag,'')
			if line_no_styles=='': width,height = 0,text_line_height_with_spacing
			else: width,height = writing.textsize(line_no_styles,font=text_font)
			if   line_direction=='left': text_posx2 = text_posx+text_sides_margin
			elif line_direction=='right': text_posx2 = text_posx+text_sides_margin+text_max_width-width
			elif line_direction=='center': text_posx2 = text_posx+text_sides_margin+(text_max_width-width)/2
			if text_posx2<text_sides_margin: text_posx2 = text_posx+text_sides_margin
			lines_posx.append(text_posx2)
			lines_width.append(width)
		text_posx2 = lines_posx[0]
		splitted_text = text_with_tags.split('_sss_')
		default_color = (255,255,255,255)
		color3 = default_color
		add_to_posx1,add_to_posy = 0,0
		text_rtl = False
		line_seq = 0
		text_posy = header_total_height+text_upper_margin/2
		if text_total_height<(text_available_height+text_upper_margin):
			text_half_height = (text_available_height+text_upper_margin-text_total_height)/2
			text_posy = header_total_height+text_upper_margin+text_half_height-text_line_height/2
		for line in splitted_text:
			if not line or (line and ord(line[0])==65279): continue
			style1 = line.split('_newline_',1)
			style2 = line.split('_newcolor',1)
			style3 = line.split('_endcolor_',1)
			style4 = line.split('_linertl_',1)
			style5 = line.split('_lineleft_',1)
			style6 = line.split('_lineright_',1)
			style7 = line.split('_linecenter_',1)
			if len(style1)>1:
				line_seq += 1
				line = style1[1]
				add_to_posx1 = 0
				text_posx2 = lines_posx[line_seq]
				add_to_posy += text_line_height_with_spacing
				text_rtl = False
			elif len(style2)>1:
				line = style2[1]
				color3 = line[0:8]
				color3 = '#'+color3[2:]
				line = line[9:]
			elif len(style3)>1:
				line = style3[1]
				color3 = default_color
			elif len(style4)>1:
				line = style4[1]
				text_rtl = True
				add_to_posx1 = lines_width[line_seq]
			elif len(style5)>1:
				line = style5[1]
			elif len(style6)>1:
				line = style6[1]
			elif len(style7)>1:
				line = style7[1]
			if line:
				text_posy2 = text_posy+add_to_posy
				line = bidi.algorithm.get_display(line)
				width,height = writing.textsize(line,font=text_font)
				if text_rtl: add_to_posx1 -= width
				text_posx3 = text_posx2+add_to_posx1
				writing.text((text_posx3,text_posy2),line,font=text_font,fill=color3)
				if not text_rtl: add_to_posx1 += width
				if text_posy2>text_available_height+text_line_height_with_spacing: break
	image_filename = dialogimagefile.replace('_0000_','_'+str(time.time())+'_')
	image_filename = image_filename.replace('\\','\\\\').replace('//','////')
	txt.save(image_filename)
	return image_filename,image_height

def SET_SQL3_CONNECTION(cc):
	cc.execute('PRAGMA automatic_index=no;')
	cc.execute('PRAGMA foreign_keys=no;')
	cc.execute('PRAGMA ignore_check_constraints=yes;')
	cc.execute('PRAGMA journal_mode=OFF;')
	cc.execute('PRAGMA temp_store=MEMORY;')
	cc.execute('PRAGMA synchronous=OFF;')
	return

def WRITE_TO_SQL3(dbfile,table,column,data,expiry,bulkinsert=False):
	if table in ['OPENURL_REQUESTS','OPENURL_URLLIB','SERVERS']:
		status = settings.getSetting('av.cache.status')
		if status=='SHORT' and expiry>LIMITED_CACHE: expiry = LIMITED_CACHE
	conn = sqlite3.connect(dbfile)
	cc = conn.cursor()
	SET_SQL3_CONNECTION(cc)
	conn.text_factory = str
	cc.execute('CREATE TABLE IF NOT EXISTS "'+table+'" (expiry,column,data) ;')
	if bulkinsert:
		tt1,tt2 = [],[]
		for ii in range(len(column)):
			text = pickle.dumps(data[ii])
			compressed_data = zlib.compress(text)
			tt1.append((expiry+now,str(column[ii]),compressed_data))
			tt2.append((column[ii],))
		cc.execute('BEGIN IMMEDIATE TRANSACTION ;')
		cc.executemany('DELETE FROM "'+table+'" WHERE column = ? ;',tt2)
		cc.executemany('INSERT INTO "'+table+'" VALUES (?,?,?) ;',tt1)
	else:
		text = pickle.dumps(data)
		compressed = zlib.compress(text)
		if expiry:
			tt = (str(column),)
			cc.execute('DELETE FROM "'+table+'" WHERE column = ? ;',tt)
			tt = (expiry+now,str(column),compressed)
			cc.execute('INSERT INTO "'+table+'" VALUES (?,?,?) ;',tt)
		else:
			tt = (compressed,str(column))
			cc.execute('UPDATE "'+table+'" SET data = ? WHERE column = ? ;',tt)
	conn.commit()
	conn.close()
	return

def READ_FROM_SQL3(dbfile,results_type,table,column=None):
	SHORT = 0
	data = GET_EMPTY_VALUE(results_type)
	if table in ['OPENURL_REQUESTS','OPENURL_URLLIB','SERVERS']:
		status = settings.getSetting('av.cache.status')
		if status=='STOP': return data
		elif status=='SHORT': SHORT = LIMITED_CACHE
	conn = sqlite3.connect(dbfile)
	cc = conn.cursor()
	SET_SQL3_CONNECTION(cc)
	conn.text_factory = str
	tableExist = True
	try: cc.execute('SELECT * FROM "'+table+'" LIMIT 1 ;')
	except: tableExist = False
	if tableExist:
		if SHORT: cc.execute('DELETE FROM "'+table+'" WHERE expiry>'+str(now+SHORT)+' ;')
		conn.commit()
		cc.execute('DELETE FROM "'+table+'" WHERE expiry<'+str(now)+' ;')
		conn.commit()
		if column:
			tt = (str(column),)
			cc.execute('SELECT data FROM "'+table+'" WHERE column = ? ;',tt)
			rows = cc.fetchall()
			if rows:
				try:
					text = zlib.decompress(rows[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute('SELECT column,data FROM "'+table+'" ;')
			rows = cc.fetchall()
			if rows:
				data,columns = {},[]
				for column2,data2 in rows:
					text2 = zlib.decompress(data2)
					data2 = pickle.loads(text2)
					data[column2] = data2
					columns.append(column2)
				if columns:
					data['__SEQUENCED_COLUMNS__'] = columns
					if results_type=='list': data = columns
	conn.close()
	return data

def DELETE_FROM_SQL3(dbfile,table,column=None):
	conn = sqlite3.connect(dbfile)
	cc = conn.cursor()
	SET_SQL3_CONNECTION(cc)
	conn.text_factory = str
	if column==None: cc.execute('DROP TABLE IF EXISTS "'+table+'" ;')
	else:
		tt = (str(column),)
		try: cc.execute('DELETE FROM "'+table+'" WHERE column = ? ;',tt)
		except: pass
	conn.commit()
	conn.close()
	return

def LOG_THIS(level,message):
	global loglevel
	message = message.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	message = message.replace('[/COLOR]','')
	lines = ['','']
	if not level: level = 'NOTICE'
	if level=='ERROR_LINES':
		loglevel = xbmc.LOGERROR
		lines = message.strip('.   ').split('   ')
	elif level=='NOTICE_LINES':
		lines = message.strip('.   ').split('   ')
	elif level=='NOTICE':
		lines = message.split('    ')
	tab = '    '
	tabs = tab+tab+tab
	shift = tabs+tab+'  '
	if kodi_version>17.99: shift = shift+'           '
	loglines = lines[0]
	for line in lines[1:]:
		if '\n' in line: line = line.replace('\n','\n'+tabs)
		tabs = tabs+tab
		loglines += '\r'+shift+tabs+line
	loglines += ' _'
	if '%' in loglines: loglines = UNQUOTE(loglines)
	xbmc.log(loglines,level=loglevel)
	return

def LOGGING(script_name):
	function_name = sys._getframe(1).f_code.co_name
	if script_name=='MAINMENU' and function_name=='MAINMENU':
		return '[ '+addon_name.upper()+'-'+addon_version+'-'+script_name+'-'+function_name+' ]'
	return '.   '+function_name

def addMenuItem(type_,name,url,mode='',image='',page='',text='',context='',infodict=''):
	name = name.replace('\r','').replace('\n','').replace('\t','')
	url = url.replace('\r','').replace('\n','').replace('\t','')
	if '___' in name: website,name = name.split('___',1)
	else: website,name = '',name
	if website:
		nameonly = name
		if not nameonly: nameonly = '....'
		elif nameonly.count('_')>1: nameonly = nameonly.split('_',2)[2]
		nameonly = nameonly.replace(' ','')
		nameonly = nameonly.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		nameonly = nameonly.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		nameonly = nameonly.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		nameonly = nameonly.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		nameonly = nameonly.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		nameonly = nameonly.replace('|','').replace('~','')
		nameonly = nameonly.replace('اون لاين','').replace('سيما لايت','')
		exceptionsLIST = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(value in nameonly for value in exceptionsLIST): nameonly = nameonly.replace('ال','')
		nameonly = nameonly.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		nameonly = nameonly.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		nameonly = nameonly.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		nameonly = nameonly.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		nameonly = nameonly.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		nameonly = nameonly.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		nameonly = nameonly.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		nameonly = nameonly.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		nameonly = nameonly.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		nameonly = nameonly.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		nameonly = nameonly.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		nameonly = nameonly.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		nameonly = nameonly.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		nameonly = nameonly.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		nameonly = nameonly.replace('  ',' ').strip(' ')
		website = TRANSLATE(website)
		if nameonly not in list(contentsDICT.keys()): contentsDICT[nameonly] = {}
		contentsDICT[nameonly][website] = [type_,name,url,mode,image,page,text,context,infodict]
	menuItemsLIST.append([type_,name,url,mode,image,page,text,context,infodict])
	return

def OPENURL_REQUESTS(method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix=True,allow_proxy_fix=True):
	# should stay ==''
	if allow_redirects=='': allow_redirects = True
	if showDialogs=='': showDialogs = True
	if allow_dns_fix=='': allow_dns_fix = True
	if allow_proxy_fix=='': allow_proxy_fix = True
	if not data: data = {}
	if not headers: headers = {}
	if 'User-Agent' not in list(headers.keys()): headers['User-Agent'] = '@@@SKIP_HEADER@@@'
	url2,proxyurl,dnsurl,sslurl = EXTRACT_URL(url)
	dns_server = settings.getSetting('av.dns.server')
	dns_status = settings.getSetting('av.dns.status')
	proxy_status = settings.getSetting('av.proxy.status')
	original_request = (proxyurl==None and dnsurl==None and sslurl==None)
	api_python = SERVER(url2,'url') in str(WEBSITES['PYTHON'])
	api_repos = SERVER(url2,'url') in str(WEBSITES['REPOS'])
	if dnsurl=='': dnsurl = dns_server
	elif dnsurl==None and dns_status in ['AUTO','ACCEPTED'] and allow_dns_fix: dnsurl = dns_server
	if api_python or api_repos: timeout = 10
	elif 'RANDOM_USERAGENT' in source: timeout = 15
	elif 'CIMA4U' in source: timeout = 25
	elif 'AKWAM' in source: timeout = 20
	elif source in UNIMPORTANT_REQUESTS: timeout = 5
	else: timeout = 10
	if 'SHAHID4U' in source and not data and '&' not in url2 and '?' not in url2: url2 = url2.rstrip('/')+'/'
	use_proxy = (proxyurl!=None)
	use_dns = (dnsurl!=None and dns_status!='STOP')
	if use_proxy: DIALOG_NOTIFICATION('تفعيل بروكسي رقم',proxyurl)
	elif use_dns: DIALOG_NOTIFICATION('تفعيل DNS رقم',dnsurl)
	if use_proxy:
		proxies = {"http":proxyurl,"https":proxyurl}
		proxy_server = proxyurl
	else: proxies,proxy_server = {},''
	if use_dns:
		import urllib3.util.connection as connection
		original_create_connection = USE_DNS_SERVER(connection,dns_server)
	verify = True
	allow_redirects2,source2,method2,leave = allow_redirects,source,method,False
	api_request = api_python or api_repos
	if api_request or (method=='POST' and allow_redirects): allow_redirects2 = False
	if api_python: method2 = 'POST'
	import requests
	for ii in range(7):
		succeeded = False
		try:
			if ii: source2 = 'LIBRARY-OPENURL_REQUESTS-1st'
			if not use_proxy: LOG_OPENURL(False,url2,data,headers,source2,method2)
			try: response.close()
			except: pass
			url3 = url2
			response = requests.request(method2,url2,data=data,headers=headers,verify=verify,allow_redirects=allow_redirects2,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not leave:
					if 'Location' in list(response.headers.keys()): url2 = response.headers['Location']
					elif 'location' in list(response.headers.keys()): url2 = response.headers['location']
					else: leave = True
					if api_request and response.status_code==307:
						allow_redirects2 = allow_redirects
						method2 = method
						leave = True
						continue
				if not leave or allow_redirects:
					if 'http' not in url2:
						server = SERVER(url3,'url')
						url2 = server+url2
				if not leave and allow_redirects:
					videofiletype = GET_VIDEOFILETYPE(url2)
					if videofiletype not in ['.avi','.ts','.mp4','.mkv','.flv','.mp3','.webm']: continue
			elif 550<=response.status_code<=599:
				response.reason = response.content
			url3 = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			code = -1
			if kodi_version<19: reason = str(err.message).split(': ')[1]
			else: reason = str(err).split(': ')[1]
		except requests.exceptions.ConnectionError as err:
			code = -1
			reason = 'Unknown Error'
			try:
				error = err.message[0]
				code = -1
				reason = error
				if 'Errno' in error: code,reason = re.findall("\[Errno (\d+)\] (.*?)'",error)[0]
				elif ', error(' in error: code,reason = re.findall(", error\((\d+), '(.*?)'",error)[0]
				elif error.count(':')>=2: reason,code = re.findall(': (.*?):.*?(\d+)',error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			code = -1
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			code = -1
			reason = 'Unknown Error'
		break
	if dnsurl!=None and dns_status!='STOP': connection.create_connection = original_create_connection
	if dns_status=='ALWAYS' and allow_dns_fix: dnsurl = None
	if not succeeded and proxyurl==None and 'google-analytics' not in url2:
		errortrace = traceback.format_exc()
		sys.stderr.write(errortrace)
	else: pass
	code = int(code)
	response2 = dummy_object()
	response2.code = code
	response2.reason = reason
	try: response2.content = response.content
	except: response2.content = ''
	if kodi_version>18.99:
		try: response2.content = response2.content.decode('utf8')
		except: pass
	htmlLower = ''
	if kodi_version<19 or isinstance(response2.content,str):
		htmlLower = response2.content.lower()
	if succeeded:
		response2.succeeded = True
		response2.headers 	= response.headers
		response2.cookies 	= response.cookies
		response2.url 	= url3
	else:
		response2.succeeded = False
		response2.headers 	= {}
		response2.cookies 	= {}
		response2.url     	= ''
	try: response.close()
	except: pass
	cond1 = ('cloudflare' in htmlLower and 'recaptcha' in htmlLower)
	if code==200 and cond1: response2.succeeded = False
	if not response2.succeeded and original_request and source not in UNIMPORTANT_REQUESTS:
		cond2 = ('cloudflare' in htmlLower and 'ray id: ' in htmlLower)
		cond3 = ('5 sec' in htmlLower and 'browser' in htmlLower)
		cond4 = (code in [403] and 'error code: 1020' in htmlLower)
		if   cond1: reason = 'Blocked by Google reCAPTCHA'
		elif cond2: reason = 'Blocked by cloudflare'
		elif cond3: reason = 'Blocked by 5 seconds browser check'
		elif cond4: reason = 'Blocked by cloudflare access denied'
		else: reason = str(reason)
		LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   Direct connection failed   Code: [ '+str(code)+' ]   Reason: [ '+reason+' ]   Source: [ '+source+' ]   URL: [ '+url2+' ]')
		urlshow = UNQUOTE(url2)
		if kodi_version<19 and isinstance(urlshow,unicode): urlshow = urlshow.encode('utf8')
		reason = str(reason)+'\n( '+urlshow+' )'
		if cond1 or cond2 or cond3 or cond4:
			code = -2
			response2.code = code
			response2.reason = reason
		yes = True
		if (dns_status=='ASK' or proxy_status=='ASK') and 'google-analytics' not in url2:
			yes = SHOW_NETWORK_ERRORS(code,reason,source,showDialogs)
			if yes and dns_status=='ASK': dns_status = 'ACCEPTED'
			else: dns_status = 'REJECTED'
			if yes and proxy_status=='ASK': proxy_status = 'ACCEPTED'
			else: proxy_status = 'REJECTED'
			settings.setSetting('av.dns.status',dns_status)
			settings.setSetting('av.proxy.status',proxy_status)
		if yes:
			allow_ssl_fix = True
			if code==8 and 'https' in url2 and allow_ssl_fix:
				if showDialogs: DIALOG_NOTIFICATION('تفعيل فحص شهادة التشفير SSL','لإصلاح مشكلة الإنترنيت',time=2000)
				url3 = url2+'||MySSLUrl='
				response3 = OPENURL_REQUESTS(method,url3,data,headers,allow_redirects,showDialogs,source)
				if response3.succeeded:
					response2 = response3
					LOG_THIS('NOTICE_LINES',LOGGING(script_name)+'   Succeeded using SSL:   Source: [ '+source+' ]   URL: [ '+url+' ]')
					if showDialogs: DIALOG_NOTIFICATION('نجاح باستخدام SSL','لإصلاح مشكلة الإنترنيت',time=2000)
				else:
					LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   Failed using SSL:   Source: [ '+source+' ]   URL: [ '+url+' ]')
					if showDialogs: DIALOG_NOTIFICATION('فشل باستخدام SSL','لإصلاح مشكلة الإنترنيت',time=2000)
			if not response2.succeeded and proxy_status in ['AUTO','ACCEPTED'] and allow_proxy_fix:
				if showDialogs: DIALOG_NOTIFICATION('تفعيل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',time=2000)
				response3 = OPENURL_REQUESTS_PROXIES(method,url2,data,headers,allow_redirects,showDialogs,source)
				if response3.succeeded:
					response2 = response3
					LOG_THIS('NOTICE_LINES',LOGGING(script_name)+'   Proxies succeeded:   Source: [ '+source+' ]   URL: [ '+url+' ]')
					if showDialogs: DIALOG_NOTIFICATION('نجاح سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',time=2000)
				else:
					LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   Proxies failed:   Source: [ '+source+' ]   URL: [ '+url+' ]')
					if showDialogs: DIALOG_NOTIFICATION('فشل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',time=2000)
			if not response2.succeeded and dns_status in ['AUTO','ACCEPTED'] and allow_dns_fix:
				if showDialogs: DIALOG_NOTIFICATION('تفعيل سيرفر DNS','لإصلاح مشكلة الإنترنيت',time=2000)
				url3 = url2+'||MyDNSUrl='
				response3 = OPENURL_REQUESTS(method,url3,data,headers,allow_redirects,showDialogs,source)
				if response3.succeeded:
					response2 = response3
					LOG_THIS('NOTICE_LINES',LOGGING(script_name)+'   DNS succeeded:   DNS: [ '+dns_server+' ]   Source: [ '+source+' ]   URL: [ '+url+' ]')
					if showDialogs: DIALOG_NOTIFICATION('نجاح سيرفر DNS','لإصلاح مشكلة الإنترنيت',time=2000)					
				else:
					LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   DNS failed:   DNS: [ '+dns_server+' ]   Source: [ '+source+' ]   URL: [ '+url+' ]')
					if showDialogs: DIALOG_NOTIFICATION('فشل سيرفر DNS','لإصلاح مشكلة الإنترنيت',time=2000)
		if proxy_status=='REJECTED' or dns_status=='REJECTED': showDialogs = False
		if not response2.succeeded:
			if showDialogs: trytofix = SHOW_NETWORK_ERRORS(code,reason,source,showDialogs)
			if code!=200 and source not in NO_EXIT_LIST and 'RESOLVERS-' not in source:
				raise SystemError('Forced exit due to network issues with: '+source)
	elif not response2.succeeded and original_request and source not in UNIMPORTANT_REQUESTS:
		LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   Failed sending analytics event   URL: [ '+url2+' ]')
	elif response2.succeeded and original_request:
		if api_python: response3 = SEND_ANALYTICS_EVENT('PYTHON',allow_dns_fix,allow_proxy_fix)
		if api_repos: response3 = SEND_ANALYTICS_EVENT('REPOS',allow_dns_fix,allow_proxy_fix)		
	return response2

def LOG_OPENURL(is_cached,url,data,headers,source,method):
	headers2 = str(headers)[0:250].replace('\n','\\n').replace('\r','\\r').replace('    ',' ').replace('   ',' ')
	if len(str(headers))>250: headers2 = headers2+' ...'
	data2 = str(data)[0:250].replace('\n','\\n').replace('\r','\\r').replace('    ',' ').replace('   ',' ')
	if len(str(data))>250: data2 = data2+' ...'
	if is_cached: LOG_THIS('NOTICE',LOGGING(script_name)+'   Reading CACHE: [ '+url+' ]   Source: [ '+source+' ]   Method: [ '+method+' ]   Headers: [ '+str(headers2)+' ]   Data: [ '+data2+' ]')
	else: LOG_THIS('NOTICE',LOGGING(script_name)+'   Opening URL: [ '+url+' ]   Source: [ '+source+' ]   Method: [ '+method+' ]   Headers: [ '+str(headers2)+' ]   Data: [ '+data2+' ]')
	return

def OPENURL_REQUESTS_CACHED(expiry,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix=True,allow_proxy_fix=True):
	if expiry>0:
		response = READ_FROM_SQL3(cache_dbfile,'response','OPENURL_REQUESTS',[method,url,data,headers,allow_redirects,showDialogs,source])
		if response:
			LOG_OPENURL(True,url,data,headers,source,method)
			return response
	else:
		DELETE_FROM_SQL3(cache_dbfile,'OPENURL_REQUESTS',[method,url,data,headers,allow_redirects,showDialogs,source])
		expiry = -expiry
	response = OPENURL_REQUESTS(method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix,allow_proxy_fix)
	if response.succeeded and expiry>0:
		WRITE_TO_SQL3(cache_dbfile,'OPENURL_REQUESTS',[method,url,data,headers,allow_redirects,showDialogs,source],response,expiry)
	return response

def QUOTE(url,exceptions=':/'):
	if kodi_version>18.99: from urllib.parse import quote as _quote
	else: from urllib import quote as _quote
	return _quote(url,exceptions)
	#return urllib2.quote(url,ignore)

def UNQUOTE(url):
	if kodi_version>18.99: from urllib.parse import unquote as _unquote
	else: from urllib import unquote as _unquote
	return _unquote(url)
	#return urllib2.unquote(url)

def unescapeHTML(string2):
	if '&' in string2 and ';' in string2:
		if kodi_version<19:
			string2 = string2.decode('utf8')
			import HTMLParser
			string2 = HTMLParser.HTMLParser().unescape(string2)
			string2 = string2.encode('utf8')
		else:
			import html
			string2 = html.unescape(string2)
	return string2

def escapeUNICODE(string2):
	#decode('raw_unicode_escape')
	if '\\u' in string2:
		if kodi_version<19: string2 = string2.decode('unicode_escape','ignore').encode('utf8')
		elif kodi_version>18.99: string2 = string2.encode('utf8').decode('unicode_escape','ignore')
	return string2

def GET_EMPTY_VALUE(type):
	if type=='dict': data = {}
	elif type=='list': data = []
	elif type=='str': data = ''
	elif type=='int': data = 0
	elif type=='response': data = None
	elif not type: data = None
	else: data = None
	return data

def GET_VIDEOFILETYPE(url,website=''):
	videofiletype = re.findall('(\.avi|\.ts|\.mp4|\.m3u|\.m3u8|\.mpd|\.mkv|\.flv|\.mp3|\.webm)(|\?.*?|/\?.*?|\|.*?)$',url.lower(),re.DOTALL|re.IGNORECASE)
	if videofiletype: videofiletype = videofiletype[0][0]
	else: videofiletype = ''
	return videofiletype
	#elif not videofiletype and 'EGYBEST' in website: videofiletype = '.mp4'
	#elif not videofiletype and 'FAJERSHOW' in website: videofiletype = '.mp4'

def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	success,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: success = False
	t2 = time.time()
	if success: resp = t2-t1
	return resp

def OPENURL_CACHED(expiry,url,data,headers,showDialogs,source):
	if not data or isinstance(data,dict): method = 'GET'
	else:
		method = 'POST'
		data = UNQUOTE(data)
		dummy,data = URLDECODE(data)
	response = OPENURL_REQUESTS_CACHED(expiry,method,url,data,headers,True,showDialogs,source)
	html = response.content
	#html = html.encode('utf8')
	html = str(html)
	return html

def SEARCH_OPTIONS(search):
	options,showdialogs = '',True
	if search.count('_')>=2:
		search,options = search.split('_',1)
		options = '_'+options
		if '_NODIALOGS_' in options: showdialogs = False
		else: showdialogs = True
	#DIALOG_OK('','',search,options)
	return search,options,showdialogs

def EXTRACT_URL(url):
	allitems = url.split('||')
	url2,proxyurl,dnsurl,sslurl = allitems[0],None,None,None
	for item in allitems:
		if 'MyProxyUrl=' in item: proxyurl = item.split('=')[1]
		elif 'MyDNSUrl=' in item: dnsurl = item.split('=')[1]
		elif 'MySSLUrl=' in item: sslurl = item.split('=')[1]
	return url2,proxyurl,dnsurl,sslurl

def FIX_OR_CREATE_ALL_DATABASES(showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO('','','','رسالة من المبرمج','سوف يقوم البرنامج الآن بإصلاح وتنظيف جميع قواعد البيانات والكاش المستخدمة في برنامج عماد .. هل تريد تشغيل هذه العملية الآن ؟!!')
	else: yes = True
	if yes==1:
		for dbfile in [cache_dbfile,iptv1_dbfile,iptv2_dbfile]:
			conn = sqlite3.connect(dbfile)
			cc = conn.cursor()
			SET_SQL3_CONNECTION(cc)
			cc.execute('PRAGMA integrity_check;')
			cc.execute('PRAGMA optimize;')
			cc.execute('VACUUM;')
			conn.commit()
			conn.close()
			if showDialogs:
				DIALOG_OK('','','رسالة من المبرمج','تمت بنجاح عملية إصلاح وتنظيف جميع قواعد البيانات والكاش المستخدمة برنامج عماد')
	return

def EVAL(results_type,text,file=''):
	#text = text.replace("u'","'")
	text = text.replace('null','None')
	text = text.replace('true','True')
	text = text.replace('false','False')
	try: text2 = eval(text)
	except:
		text2 = GET_EMPTY_VALUE(results_type)
		if file: CHECK_CACHED_FILES(True,file)
		else: pass
	return text2

def RESTORE_PATH_NAME(name):
	start,site,modified = '','',''
	name = name.replace(ltr,'').replace(rtl,'')
	tmp = re.findall('(.)\[COLOR FFC89008\](\w\w\w) +\[\/COLOR\](.*?)$',name,re.DOTALL)
	if tmp: start,site,name = tmp[0]
	if start not in [' ',',','']: modified = '_MOD_'
	if site: site = '_'+site+'_'
	#datetime = re.findall('(_\d\d\.\d\d_\d\d\:\d\d_)',name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],'')
	name = site+modified+name
	return name



from IMPORTS import *



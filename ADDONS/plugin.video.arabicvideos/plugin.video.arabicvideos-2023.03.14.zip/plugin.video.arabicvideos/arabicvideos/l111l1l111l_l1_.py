# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭䀀")
def MAIN(mode,text=l1l11l_l1_ (u"ࠬ࠭䀁")):
	if   mode==  0: l1l1111l1l11_l1_(text)
	elif mode==  2: l11lllll1111_l1_(text)
	elif mode==  3: l1l11l111111_l1_()
	elif mode==  4: l11llllll1l_l1_(text)
	elif mode==  5: l1l11111llll_l1_()
	elif mode==  6: l1l11l11ll11_l1_()
	elif mode==  7: l11ll1111ll_l1_()
	elif mode==  8: l1l11111l11l_l1_()
	elif mode==  9: l1l11111l1ll_l1_()
	elif mode==150: l1l11l11l1ll_l1_()
	elif mode==151: l11ll1llllll_l1_()
	elif mode==152: l1l111l11l1l_l1_()
	elif mode==153: l1l11lll111l_l1_()
	elif mode==154: l1l11l1l1lll_l1_()
	elif mode==155: l1l1111ll111_l1_()
	elif mode==156: l11ll1llll11_l1_()
	elif mode==157: l1l11l11ll1l_l1_()
	elif mode==158: l1l111l11ll1_l1_()
	elif mode==159: l1l111lll1ll_l1_(True)
	elif mode==170: l11lll11ll11_l1_()
	elif mode==171: l1l111ll11l1_l1_()
	elif mode==172: l1l11ll1l1l1_l1_()
	elif mode==173: l1ll11ll1l1_l1_(l1l11l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭䀂"),True)
	elif mode==174: l1ll11ll1l1_l1_(l1l11l_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ䀃"),True)
	elif mode==175: l1l1111llll1_l1_()
	elif mode==176: l11ll1lll1l1_l1_()
	elif mode==177: l1l11l1l11ll_l1_(l1l11l_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ䀄"))
	elif mode==178: l1l11l1l11ll_l1_(l1l11l_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭䀅"))
	elif mode==179: l1l11l1l11ll_l1_(l1l11l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ䀆"))
	elif mode==190: l1l1111l11ll_l1_()
	elif mode==191: l11lll1ll1ll_l1_()
	elif mode==192: l11llll1l1ll_l1_()
	elif mode==193: l1l111ll1l11_l1_()
	elif mode==194: l11llll11ll1_l1_()
	elif mode==195: l11lllllll1l_l1_()
	elif mode==196: l1l11111lll1_l1_()
	elif mode==197: l11lll1lllll_l1_()
	elif mode==198: l1l111ll111l_l1_()
	elif mode==199: l1l11111111l_l1_()
	elif mode==340: l11lll1l1l11_l1_(text)
	elif mode==341: l111ll1llll_l1_()
	elif mode==342: l1l1111ll1ll_l1_()
	elif mode==343: l1l111111l11_l1_()
	elif mode==344: l1l11l1l1l1l_l1_()
	elif mode==345: l1l111l1l1l1_l1_()
	elif mode==346: l1l1l11l1ll_l1_()
	elif mode==347: l111ll11lll_l1_(True)
	elif mode==348: l1l111ll11ll_l1_()
	elif mode==349: CHECK_CACHED_FILES(True)
	elif mode==500: l11lll1ll11l_l1_()
	elif mode==501: l11lll11l1l1_l1_()
	elif mode==502: l1l111l1llll_l1_(l1l11l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ䀇"),True)
	elif mode==503: l1l11l1ll11l_l1_()
	elif mode==504: l1l111ll1111_l1_()
	elif mode==505: l1l1111lll11_l1_()
	elif mode==506: FIX_OR_CREATE_ALL_DATABASES(True)
	elif mode==507: l1l11lllll1_l1_(text,l1l11l_l1_ (u"ࠬ࠭䀈"),True)
	return
def l1l11lllll1_l1_(addon_id,function,showDialogs):
	conn = sqlite3.connect(l111llll1ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l11llll1lll1_l1_ = l1l11l_l1_ (u"࠭ࡢ࡭ࡣࡦ࡯ࡱ࡯ࡳࡵࠩ䀉")
	else: l11llll1lll1_l1_ = l1l11l_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸ࠭䀊")
	cc.execute(l1l11l_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠩ䀋")+l11llll1lll1_l1_+l1l11l_l1_ (u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ䀌")+addon_id+l1l11l_l1_ (u"ࠪࠦࠥࡁࠧ䀍"))
	rows = cc.fetchall()
	if rows and function in [l1l11l_l1_ (u"ࠫࠬ䀎"),l1l11l_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ䀏")]:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࠧ䀐"),l1l11l_l1_ (u"ࠧࠨ䀑"),l1l11l_l1_ (u"ࠨࠩ䀒"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䀓"),l1l11l_l1_ (u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧ䀔")+addon_id+l1l11l_l1_ (u"ࠫࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦๅห๊ๅๅࠥ๎ไศࠢํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ็ู๋ๆ๊ࠤฬ๊ย็ࠢย࡛ࠥࠦࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦล๋ไสๅ์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ䀕"))
		if yes!=1: return
		cc.execute(l1l11l_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫ䀖")+l11llll1lll1_l1_+l1l11l_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ䀗")+addon_id+l1l11l_l1_ (u"ࠧࠣࠢ࠾ࠫ䀘"))
	elif function in [l1l11l_l1_ (u"ࠨࠩ䀙"),l1l11l_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪ䀚")]:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ䀛"),l1l11l_l1_ (u"ࠫࠬ䀜"),l1l11l_l1_ (u"ࠬ࠭䀝"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䀞"),l1l11l_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ䀟")+addon_id+l1l11l_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣๆ฿ไ๊ࠡํ฽๊๊ࠠ࠯࠰๋้ࠣࠦสา์าࠤส๐โศใ๊ࠤฬ๊ย็ࠢย࡛ࠥࠦࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦสโ฻ํ่์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ䀠"))
		if yes!=1: return
		if kodi_version<19: cc.execute(l1l11l_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ䀡")+addon_id+l1l11l_l1_ (u"ࠪࠦ࠮ࠦ࠻ࠨ䀢"))
		else: cc.execute(l1l11l_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫ䀣")+addon_id+l1l11l_l1_ (u"ࠬࠨࠬ࠲ࠫࠣ࠿ࠬ䀤"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ䀥"))
	time.sleep(1)
	if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䀦"),l1l11l_l1_ (u"ࠨࠩ䀧"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䀨"),l1l11l_l1_ (u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧ䀩"))
	if function in [l1l11l_l1_ (u"ࠫࠬ䀪"),l1l11l_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ䀫")]: l1l111lll1ll_l1_(showDialogs)
	return
def l1l1111lll11_l1_():
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ䀬"),l1l11l_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ䀭"))
	l111llllll1_l1_ = l1ll1l1l1ll_l1_()
	l11111l1l11_l1_ = l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䀮")
	l1l11lll11ll_l1_ = l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥ࠳࠭࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀯")
	l1l11lll11l1_l1_ = l1l11l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ䀰")
	for id,l1111l1ll11_l1_,l111l11ll11_l1_,answer,l1l1l1lllll_l1_,reason in reversed(l111llllll1_l1_):
		if id==l1l11l_l1_ (u"ࠫ࠵࠭䀱"):
			l1l111lll11_l1_,l1l111lll1l_l1_ = answer.split(l1l11l_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ䀲"))
			continue
		if l11111l1l11_l1_!=l1l11l_l1_ (u"࠭࡜࡯ࠩ䀳"): l11111l1l11_l1_ += l1l11lll11l1_l1_
		l1111111ll_l1_ = l1l11l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䀴")+id+l1l11l_l1_ (u"ࠨࠢ࠽ࠤࠬ䀵")+l1l11l_l1_ (u"ࠩสุ่สวๅࠢ࠽ࠤࠬ䀶")+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䀷")+l111l11ll11_l1_
		l111111l11_l1_ = l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅฮ๋หอࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䀸")+answer
		l1ll1l11l11l_l1_ = l1l11l_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䀹")+l1l1l1lllll_l1_
		l1ll1l11l1l1_l1_ = l1l11l_l1_ (u"࠭࡜࡯࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ือฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀺")+reason
		l11111l1l11_l1_ += l1111111ll_l1_+l111111l11_l1_+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䀻")+l1l11lll11ll_l1_+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䀼")+l1ll1l11l11l_l1_+l1ll1l11l1l1_l1_+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䀽")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ䀾"),l1l111lll1l_l1_,l11111l1l11_l1_,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ䀿"))
	return
def l1l111ll1111_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬ࠭䁀"),l1l11l_l1_ (u"࠭ࠧ䁁"),l1l11l_l1_ (u"ࠧࠨ䁂"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䁃"),l1l11l_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ศๆࠡวุ่ฬำࠠใ๊สส๊ࠦวๅ็ไฺ้ฯࠠภࠣࠪ䁄"))
	if yes==1: new_dict = FIX_AND_GET_FILE_CONTENTS(favouritesfile,True)
	return
def l1l11l1ll11l_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ䁅"),l1l11l_l1_ (u"ࠫࠬ䁆"),l1l11l_l1_ (u"ࠬ࠭䁇"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䁈"),l1l11l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦลึๆสั่่ࠥศศ่ࠤวิัࠡษ็ๅ๏ี๊้้สฮࠥลࠡࠨ䁉"))
	if yes==1: new_dict = FIX_AND_GET_FILE_CONTENTS(l11l1ll1lll_l1_,True)
	return
def l11lll11l1l1_l1_():
	if kodi_version<18:
		message = l1l11l_l1_ (u"ࠨๆ็วุ็ࠠฤ่อࠤฯูสฯั่ࠤส฻ฯศำࠣ็ํี๊ࠡไา๎๊ࠦัใ็ࠣࠫ䁊")+str(kodi_version)+l1l11l_l1_ (u"ࠩࠣ์้ํะศࠢส่็๎วว็ࠣห้๋ี้ำฬࠤ้อࠠห฻่่ࠥ฿ๆะๅࠣ࠲ࠥํะ่ࠢส่๊๐าสࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲๊ࠥลึๆสัࠥอไๆึๆ่ฮࠦโๆࠢหฮาี๊ฬࠢหี๋อๅอࠢๆ์ิ๐ࠠฦๆ์ࠤส๐ࠠฦืาหึࠦัใ็๊ࠤศ฿ไ๊่๊ࠢࠥ࠷࠸࠯࠲ࠪ䁋")
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䁌"),l1l11l_l1_ (u"ࠫࠬ䁍"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䁎"),message)
		return
	l11lll1l11ll_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ䁏"))
	l111l11111l_l1_ = l11lllll111_l1_([l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭䁐")])
	l1111l11111_l1_,l1l11l1111ll_l1_,l1l11l111l1l_l1_,l1l11l111l11_l1_,l1l11l11111l_l1_,l11lll1l11l1_l1_,l1l11l1111l1_l1_ = l111l11111l_l1_[l1l11l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ䁑")]
	if l1111l11111_l1_ or l1l11l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ䁒") not in str(l11lll1l11ll_l1_):
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䁓"),l1l11l_l1_ (u"ࠫࠬ䁔"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䁕"),l1l11l_l1_ (u"࠭วๅไ๋หห๋ࠠศๆู่ํืษࠡฬ฼้้ࠦแใู้ࠣ฾ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥํะ่ࠢส่็๎วว็ࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠫ䁖"))
		succeeded = l1l111l1llll_l1_(l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭䁗"),True)
		if not succeeded: return
	l1ll1l11111_l1_(True)
	return
	l1l11l_l1_ (u"ࠣࠤࠥࠎࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠩࠬࠎࠎ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠶࠷ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้้สศสฬࠫࠏࠏࡥ࡭࡫ࡩࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄ࠾࠿ࠪ࠹࠺࠻ࠧ࠻ࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠤࡂࠦࠧใ๊สส๊ࠦวๅื๋ีࠬࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็้ࠣัํ่ๅหࠪࠎࠎ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠳࠾ࠎࠏࠣࠡࡣࡱࡽࠥࡵࡴࡩࡧࡵࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࠊࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨࠩࠍࠍࠎࠩࡩ࡮ࡲࡲࡶࡹࠦࡳࡲ࡮࡬ࡸࡪ࠹ࠊࠊࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡻ࡯ࡥࡸࡵࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠵࠾࠽࠱࠲࠹ࠣ࠿ࠬ࠯ࠊࠊࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࡶࡪࡧࡺࠦࠥ࡝ࡈࡆࡔࡈࠤࡻ࡯ࡥࡸࡏࡲࡨࡪࠦ࠽ࠡ࠸࠹࠴࠽࠶ࠠ࠼ࠩࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠲࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠹࠺ࠧࠊࠥࠣࠦࡑ࡯ࡳࡵࠢࡈࡱࡦࡪࠢࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࡪࡲࡩࡧࠢࡦ࡬ࡴ࡯ࡣࡦ࠿ࡀ࠶࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥ࠭࠵࠶࠷ࠪࠍࠨࠦࠢࡈࡣ࡯ࡰࡪࡸࡹࡠࡇࡰࡥࡩࠨࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠨ࠮ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠯ࠊࠊࠤࠥࠦ䁘")
def l1ll1l11111_l1_(showDialogs=True):
	l11lll1l11ll_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ䁙"))
	if l1l11l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ䁚") not in str(l11lll1l11ll_l1_):
		if showDialogs:
			DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䁛"),l1l11l_l1_ (u"ࠬ࠭䁜"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䁝"),l1l11l_l1_ (u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ䁞"))
		return
	l1l11l11l11l_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ䁟"),l1l11l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ䁠"),l1l11l_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ䁡"),l1l11l_l1_ (u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬ䁢"))
	if not os.path.exists(l1l11l11l11l_l1_): return
	oldFILE = open(l1l11l11l11l_l1_,l1l11l_l1_ (u"ࠬࡸࡢࠨ䁣")).read()
	if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䁤"))
	l11lll111ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ䁥"),oldFILE,re.DOTALL)
	l11lll1l1ll1_l1_,l1l11lll1111_l1_ = l11lll111ll1_l1_[0]
	l1l11l1ll1ll_l1_ = l1l11l_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ䁦")+l11lll1l1ll1_l1_+l1l11l_l1_ (u"ࠩ࠯ࠫ䁧")+l1l11lll1111_l1_+l1l11l_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ䁨")
	if showDialogs:
		l1l11l1lll1l_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩ䁩"))
		if l1l11l1lll1l_l1_==l1l11l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ䁪"): l1l11l1ll111_l1_ = l1l11l_l1_ (u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭䁫")
		elif l1l11l1lll1l_l1_==l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭䁬"): l1l11l1ll111_l1_ = l1l11l_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭䁭")
		else: l1l11l1ll111_l1_ = l1l11l_l1_ (u"ࠩๅ์ฬฬๅࠡลัี๎࠭䁮")
		choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䁯"),l1l11l_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ䁰"),l1l11l_l1_ (u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ䁱"),l1l11l_l1_ (u"࠭โ้ษษ้ࠥอไึ๊ิࠫ䁲"),l1l11l_l1_ (u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫ䁳")+l1l11l1ll111_l1_,l1l11l_l1_ (u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䁴"))
		if choice==1: l1l1111lllll_l1_ = l1l11l_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ䁵")
		elif choice==2: l1l1111lllll_l1_ = l1l11l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ䁶")
		else: l1l1111lllll_l1_ = l1l11l_l1_ (u"ࠫࠬ䁷")
	else:
		l1l11l1lll1l_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ䁸"))
		if   l1l11l1lll1l_l1_==l1l11l_l1_ (u"࠭ࠧ䁹"): choice = 0
		elif l1l11l1lll1l_l1_==l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ䁺"): choice = 1
		elif l1l11l1lll1l_l1_==l1l11l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ䁻"): choice = 2
		l1l1111lllll_l1_ = l1l11l1lll1l_l1_
	if   choice==0: l1l1111l111l_l1_ = l1l11l_l1_ (u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭䁼")
	elif choice==1: l1l1111l111l_l1_ = l1l11l_l1_ (u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧ䁽")
	elif choice==2: l1l1111l111l_l1_ = l1l11l_l1_ (u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨ䁾")
	else: return
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ䁿"),l1l1111lllll_l1_)
	l11llll11111_l1_ = l1l11l_l1_ (u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ䂀")+l1l1111l111l_l1_+l1l11l_l1_ (u"ࠧ࠭ࠩ䂁")+l1l11lll1111_l1_+l1l11l_l1_ (u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ䂂")
	newFILE = oldFILE.replace(l1l11l1ll1ll_l1_,l11llll11111_l1_)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䂃"))
	open(l1l11l11l11l_l1_,l1l11l_l1_ (u"ࠪࡻࡧ࠭䂄")).write(newFILE)
	LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䂅"),l1l11l_l1_ (u"ࠬ࠴ࠠࠡࠢࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫ䂆")+l1l1111l111l_l1_+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ䂇"))
	#time.sleep(2)
	if showDialogs: xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭䂈"))
	return
def l11lll1ll11l_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࠩ䂉"),l1l11l_l1_ (u"ࠩๆ่ฬ࠭䂊"),l1l11l_l1_ (u"๊ࠪ฾๋ࠧ䂋"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䂌"),l1l11l_l1_ (u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪ䂍"))
	if yes==1: l11ll1111ll_l1_()
	return
def l1l11111l11l_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䂎"),l1l11l_l1_ (u"ࠧࠨ䂏"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䂐"),l1l11l_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬ䂑"))
	return
def l1l111ll11ll_l1_():
	l1111111ll_l1_ = l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䂒")
	l1111111ll_l1_ += l1l11l_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪ䂓")
	l1111111ll_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡸ࡮ࡩࡢࡥࡲࡹࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ䂔")
	l111111l11_l1_ = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞สิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䂕")
	l111111l11_l1_ += l1l11l_l1_ (u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫ䂖")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡮ࡷࡶࡰ࡮ࡳࡲࡶ࡮ࡨࡶࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䂗")
	message = l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ䂘")+l1111111ll_l1_+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨ䂙")+l111111l11_l1_
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ䂚"),l1l11l_l1_ (u"ࠬ࠭䂛"),message)
	return
def l1l1l11l1ll_l1_():
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ䂜"),l1l11l_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ䂝"))
	l111llllll1_l1_ = l1ll1l1l1ll_l1_()
	if not l111llllll1_l1_: return
	id,l1111l1ll11_l1_,l111l11ll11_l1_,answer,l1l1l1lllll_l1_,reason = l111llllll1_l1_[0]
	l1l111lll11_l1_,l1l111lll1l_l1_ = answer.split(l1l11l_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭䂞"))
	l111111l11_l1_,l1ll1l11l11l_l1_,l1ll1l11l1l1_l1_ = l1l1l1lllll_l1_.split(l1l11l_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ䂟"))
	l1l11ll1111l_l1_ = l11lllll11l_l1_
	stay = True
	while stay:
		l1l11111ll11_l1_ = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠪࠫ䂠"),l1l11l_l1_ (u"้๊ࠫวฺฬิห฻࠭䂡"),l1l11l_l1_ (u"๊ࠬไฤูไห้࠭䂢"),l1l11l_l1_ (u"࠭ฮา๊ฯࠫ䂣"),l1l11l_l1_ (u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣๆ๊ࠦศๆีะࠤอืๆศ็ฯࠤ฾๋วะ่๊ࠢࠥา็ศิๆࠫ䂤"),l111111l11_l1_)
		if l1l11111ll11_l1_==0:
			yes = DIALOG_OK(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䂥"),l1l11l_l1_ (u"ࠩ฼์ิฯࠧ䂦"),l1l11l_l1_ (u"ࠪห้อูหำสฺࠥ฿ไ๊่ࠢฬิษࠠศๆศ฽้อๆศฬࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬ䂧"),l1ll1l11l11l_l1_)
			#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䂨"),l1l11l_l1_ (u"ࠬ฿่ะหࠪ䂩"),l1l11l_l1_ (u"࠭สุ้ํัࠬ䂪"),l1l11l_l1_ (u"ࠧศๆส฽ฯืวืࠢ฼่๎ࠦๅษัฦࠤฬ๊ลฺๆส๊ฬะࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩ䂫"),l1ll1l11l11l_l1_)
			#if yes: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䂬"),l1l11l_l1_ (u"ࠩ฼์ิฯࠧ䂭"),l1l11l_l1_ (u"้้ࠪออูษอࠫ䂮"),l1ll1l11l1l1_l1_)
		if l1l11111ll11_l1_==1: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䂯"),l1l11ll1111l_l1_,l1l11ll1111l_l1_,l1l11l_l1_ (u"ࠬอำหะา้ࠥํะศࠢส่ืืࠠๅๆัีําࠠๆ่ࠣหู้ฤศๆࠣฬิ๎ๆࠡวฯหอฯࠠศๆึศฬ๊࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠวํࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ษึฮำีๅ่ࠢ็็๏ࠦสฺำไࠤฬ๊ฬ้ษหࠤฬ๊ีฮ์ะࡠࡳࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䂰")+l1l11ll1111l_l1_+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䂱"))
		if l1l11111ll11_l1_==2: stay = False
	return
def l1l11l1l1l1l_l1_():
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䂲"),l1l11l_l1_ (u"ࠨࠩ䂳"),l1l11l_l1_ (u"ࠩࠪ䂴"),l1l11l_l1_ (u"ࠪืษอไࠨ䂵"),l1l11l_l1_ (u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬ䂶"))
	if yes==1:
		succeeded = True
		if os.path.exists(l11l11l1l1l_l1_):
			try: os.remove(l11l11l1l1l_l1_)
			except: succeeded = False
		if succeeded: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䂷"),l1l11l_l1_ (u"࠭ࠧ䂸"),l1l11l_l1_ (u"ࠧࠨ䂹"),l1l11l_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ䂺"))
		else: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䂻"),l1l11l_l1_ (u"ࠪࠫ䂼"),l1l11l_l1_ (u"ࠫࠬ䂽"),l1l11l_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬ䂾"))
	return
def l1l111l1l1l1_l1_():
	l1l1111l11ll_l1_()
	l1l11ll11l11_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ䂿"))
	message = {}
	message[l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ䃀")] = l1l11l_l1_ (u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧ䃁")
	message[l1l11l_l1_ (u"ࠩࡖࡘࡔࡖࠧ䃂")] = l1l11l_l1_ (u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ䃃")
	message[l1l11l_l1_ (u"ࠫࡘࡎࡏࡓࡖࠪ䃄")] = l1l11l_l1_ (u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭䃅")+str(LIMITED_CACHE/60)+l1l11l_l1_ (u"࠭ࠠะไํๆฮࠦแใูࠪ䃆")
	l11lllll1ll1_l1_ = message[l1l11ll11l11_l1_]
	choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠧࠨ䃇"),l1l11l_l1_ (u"ࠨๅสุࠥ࠭䃈")+str(LIMITED_CACHE/60)+l1l11l_l1_ (u"ࠩࠣำ็๐โสࠩ䃉"),l1l11l_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ䃊"),l1l11l_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ䃋"),l11lllll1ll1_l1_,l1l11l_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨ䃌"))
	if choice==0: l11lllll11ll_l1_ = l1l11l_l1_ (u"࠭ࡓࡉࡑࡕࡘࠬ䃍")
	elif choice==1: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ䃎")
	elif choice==2: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠨࡕࡗࡓࡕ࠭䃏")
	else: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠩࠪ䃐")
	if l11lllll11ll_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ䃑"),l11lllll11ll_l1_)
		l11llll1l111_l1_ = message[l11lllll11ll_l1_]
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䃒"),l1l11l_l1_ (u"ࠬ࠭䃓"),l1l11l_l1_ (u"࠭ࠧ䃔"),l11llll1l111_l1_)
	return
def l1l111111l11_l1_():
	message = {}
	message[l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ䃕")] = l1l11l_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭䃖")
	message[l1l11l_l1_ (u"ࠩࡄࡗࡐ࠭䃗")] = l1l11l_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧ䃘")
	message[l1l11l_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䃙")] = l1l11l_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ䃚")
	l1l11l11llll_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭䃛"))
	l1l11ll11l11_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ䃜"))
	l11lllll1ll1_l1_ = message[l1l11ll11l11_l1_]+l1l11l11llll_l1_
	choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠨࠩ䃝"),l1l11l_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ䃞"),l1l11l_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ䃟"),l1l11l_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ䃠"),l11lllll1ll1_l1_,l1l11l_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩ䃡"))
	if choice==0: l11lllll11ll_l1_ = l1l11l_l1_ (u"࠭ࡁࡔࡍࠪ䃢")
	elif choice==1: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠧࡂࡗࡗࡓࠬ䃣")
	elif choice==2: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠨࡕࡗࡓࡕ࠭䃤")
	if choice in [0,1]:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䃥"),l1l11l_l1_ (u"ࠪื๏ืแา࠼ࠣࠫ䃦")+DNS_SERVERS[1],l1l11l_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ䃧")+DNS_SERVERS[0],l1l11l_l1_ (u"ࠬ࠭䃨"),l1l11l_l1_ (u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ䃩"))
		if yes==1: l11llll1l1l1_l1_ = DNS_SERVERS[0]
		else: l11llll1l1l1_l1_ = DNS_SERVERS[1]
	elif choice==2: l11llll1l1l1_l1_ = l1l11l_l1_ (u"ࠧࠨ䃪")
	else: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠨࠩ䃫")
	if l11lllll11ll_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ䃬"),l11lllll11ll_l1_)
		settings.setSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ䃭"),l11llll1l1l1_l1_)
		l11llll1l111_l1_ = message[l11lllll11ll_l1_]+l11llll1l1l1_l1_
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䃮"),l1l11l_l1_ (u"ࠬ࠭䃯"),l1l11l_l1_ (u"࠭ࠧ䃰"),l11llll1l111_l1_)
	return
def l1l1111ll1ll_l1_():
	l1l11ll11l11_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ䃱"))
	message = {}
	message[l1l11l_l1_ (u"ࠨࡃࡘࡘࡔ࠭䃲")] = l1l11l_l1_ (u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪ䃳")
	message[l1l11l_l1_ (u"ࠪࡅࡘࡑࠧ䃴")] = l1l11l_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ䃵")
	message[l1l11l_l1_ (u"࡙ࠬࡔࡐࡒࠪ䃶")] = l1l11l_l1_ (u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ䃷")
	l11lllll1ll1_l1_ = message[l1l11ll11l11_l1_]
	choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠧࠨ䃸"),l1l11l_l1_ (u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭䃹"),l1l11l_l1_ (u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ䃺"),l1l11l_l1_ (u"ࠪษ๏่วโࠢๆห๊๊ࠧ䃻"),l11lllll1ll1_l1_,l1l11l_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧ䃼"))
	if choice==0: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠬࡇࡓࡌࠩ䃽")
	elif choice==1: l11lllll11ll_l1_ = l1l11l_l1_ (u"࠭ࡁࡖࡖࡒࠫ䃾")
	elif choice==2: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠧࡔࡖࡒࡔࠬ䃿")
	else: l11lllll11ll_l1_ = l1l11l_l1_ (u"ࠨࠩ䄀")
	if l11lllll11ll_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䄁"),l11lllll11ll_l1_)
		l11llll1l111_l1_ = message[l11lllll11ll_l1_]
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䄂"),l1l11l_l1_ (u"ࠫࠬ䄃"),l1l11l_l1_ (u"ࠬ࠭䄄"),l11llll1l111_l1_)
	return
def l1l1111l1l11_l1_(text):
	if text!=l1l11l_l1_ (u"࠭ࠧ䄅"):
		text = l1lll11lll1_l1_(text)
		text = text.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䄆")).encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䄇"))
		l1lll11ll11_l1_ = 10103
		l1lll11l1l1_l1_ = xbmcgui.l1lll1111l1_l1_(l1lll11ll11_l1_)
		l1lll11l1l1_l1_.getControl(311).l1lll11llll_l1_(text)
		#l111l1ll111_l1_ = xbmcgui.WindowXMLDialog(l1l11l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡍࡨࡽࡧࡵࡡࡳࡦ࠵࠶࠳ࡾ࡭࡭ࠩ䄈"), xbmcaddon.Addon().getAddonInfo(l1l11l_l1_ (u"ࠪࡴࡦࡺࡨࠨ䄉")).decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䄊")),l1l11l_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭䄋"),l1l11l_l1_ (u"࠭࠷࠳࠲ࡳࠫ䄌"))
		#l111l1ll111_l1_.show()
		#l111l1ll111_l1_.getControl(99991).setPosition(0,0)
		#l111l1ll111_l1_.getControl(311).l1lll11llll_l1_(text)
		#l111l1ll111_l1_.getControl(5).l11llll11ll_l1_(l1l11l11l1l1_l1_)
		#width = xbmcgui.l1l111ll1ll1_l1_()
		#height = xbmcgui.l1l111l11l11_l1_()
		#resolution = (0.0+width)/height
		#l111l1ll111_l1_.getControl(5).l111l1l1111_l1_(width-180)
		#l111l1ll111_l1_.getControl(5).setHeight(height-180)
		#l111l1ll111_l1_.doModal()
		#del l111l1ll111_l1_
	return
l11lll1llll1_l1_ = [
			 l1l11l_l1_ (u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࠫࠬࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧ䄍")
			,l1l11l_l1_ (u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶࠫ䄎")
			,l1l11l_l1_ (u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫ䄏")
			,l1l11l_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽࠬ䄐")
			,l1l11l_l1_ (u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬ䄑")
			,l1l11l_l1_ (u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠧ䄒")
			,l1l11l_l1_ (u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠨࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫ䄓")
			,l1l11l_l1_ (u"ࠧࡊࡰࡶࡩࡨࡻࡲࡦࡔࡨࡵࡺ࡫ࡳࡵ࡙ࡤࡶࡳ࡯࡮ࡨ࠮ࠪ䄔")
			,l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࠱ࡂࡱࡴࡪࡥ࠾࠲ࠩࡸࡪࡾࡴ࠾ࠩ䄕")
			,l1l11l_l1_ (u"ࠩࡺࡥࡷࡴࡩ࡯ࡩࡶ࠲ࡼࡧࡲ࡯ࠪࠪ䄖")
			,l1l11l_l1_ (u"ࠪࡢࡣࡤ࡞࡟ࠩ䄗")
			]
def l1l11111l111_l1_(line):
	if l1l11l_l1_ (u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ䄘") in line and l1l11l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ䄙") in line: return True
	for text in l11lll1llll1_l1_:
		if text in line: return True
	return False
def l11lll1111l1_l1_(data):
	data = data.replace(l1l11l_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ䄚")+l1l11l_l1_ (u"ࠧࠡࠩ䄛")*51+l1l11l_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭䄜"),l1l11l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ䄝"))
	data = data.replace(l1l11l_l1_ (u"ࠪࡠࡳ࠭䄞")+l1l11l_l1_ (u"ࠫࠥ࠭䄟")*51+l1l11l_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ䄠"),l1l11l_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ䄡"))
	data = data.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䄢")+l1l11l_l1_ (u"ࠨࠢࠪ䄣")*51+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䄤"),l1l11l_l1_ (u"ࠪࡠࡳ࠭䄥"))
	data = data.replace(l1l11l_l1_ (u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣ࠱ࡶࡸࡴࡸࡡࡨࡧ࠲ࡩࡲࡻ࡬ࡢࡶࡨࡨ࠴࠶࠯ࡂࡰࡧࡶࡴ࡯ࡤ࠰ࡦࡤࡸࡦ࠵࡯ࡳࡩ࠱ࡼࡧࡳࡣ࠯࡭ࡲࡨ࡮࠵ࡦࡪ࡮ࡨࡷ࠴࠴࡫ࡰࡦ࡬࠳ࡦࡪࡤࡰࡰࡶ࠳ࠬ䄦"),l1l11l_l1_ (u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤࠪ䄧"))
	data = data.replace(l1l11l_l1_ (u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬ䄨"),l1l11l_l1_ (u"ࠧ࠻ࠢࠪ䄩"))
	return data
def l11lll1l1l11_l1_(l1l111l11111_l1_):
	if l1l11l_l1_ (u"ࠨࡑࡏࡈࠬ䄪") in l1l111l11111_l1_:
		l1l11l1l1111_l1_ = l11llllll11_l1_
		header = l1l11l_l1_ (u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠภࠩ䄫")
	else:
		l1l11l1l1111_l1_ = l11ll1lllll_l1_
		header = l1l11l_l1_ (u"ࠪๆึอมสࠢสุ่าไࠡษ็ัฬ๊๊ࠡมࠪ䄬")
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࠬ䄭"),l1l11l_l1_ (u"ࠬ࠭䄮"),l1l11l_l1_ (u"࠭ࠧ䄯"),header,l1l11l_l1_ (u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๐อห๊ํࠤศ๐ึศࠢ฼่๎ࠦำอๆࠣห้อำหะาห๊ࠦ࠮๊ࠡส่ฬัๆฺ๋่ࠣึ๎ั๋ห่๊ࠣ฿ัโหࠣ็๏็ࠠฮัฮฮࠥอไๆึๆ่ฮ่ࠦๆษ๋ࠣํࠦวๅ็ๆห๋ࠦวๅาํࠤุฮศࠡฯา์ะࠦวๅ็ื็้ฯࠠ࠯ࠢๆ์ิ๐๋ࠠฯอๅ฽ࠦศิฮ็๎๋ࠦ࠮ࠡษ็วํ๊่๊ࠠࠣหู้ฬๅࠢส่าอไ๋๋ࠢๅ๏ํࠠๆ฻็์๊อสࠡฬหำศࠦๅ็าࠣฬิอ๊สࠢส่ฯฺฺ๋ๆࠣห้ำวๅ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋ࠢห้๏ࠠศๆล๊ࠥ࠴ࠠฤ็สࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣๅ์๎ࠠศๆึะ้ࠦวๅีสฬ็ࠦวๅาํࠤฯ๋ࠠอ็฼๋๋ࠥๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦโษๆࠣฦำืࠠฦูไหฦࠦไ่ࠢ࠱ࠤ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ䄰"))
	if yes!=1: return
	l11lll11l111_l1_,counts = [],0
	size = os.path.getsize(l1l11l1l1111_l1_)
	file = open(l1l11l1l1111_l1_,l1l11l_l1_ (u"ࠨࡴࡥࠫ䄱"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䄲"))
	data = l11lll1111l1_l1_(data)
	lines = data.split(l1l11l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ䄳"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䄴"))
		#if line.strip(l1l11l_l1_ (u"ࠬࠦࠧ䄵"))==l1l11l_l1_ (u"࠭ࠧ䄶"): continue
		ignore = l1l11111l111_l1_(line)
		if ignore: continue
		line = line.replace(l1l11l_l1_ (u"ࠧ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡥࠧ䄷"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䄸"))
		line = line.replace(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒ࠻ࠩ䄹"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢࡋࡒࡓࡑࡕ࠾ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䄺"))
		l11lll1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰࠭࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ䄻"),line,re.DOTALL)
		l1l111l1111l_l1_ = l1l11l_l1_ (u"ࠬ࠭䄼")
		if l11lll1ll111_l1_:
			line = line.replace(l11lll1ll111_l1_[0][0],l1l11l_l1_ (u"࠭ࠧ䄽")).replace(l11lll1ll111_l1_[0][2],l1l11l_l1_ (u"ࠧࠨ䄾"))
			l1l111l1111l_l1_ = l11lll1ll111_l1_[0][1]
		else:
			l11lll1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ䄿"),line,re.DOTALL)
			if l11lll1ll111_l1_:
				line = line.replace(l11lll1ll111_l1_[0][1],l1l11l_l1_ (u"ࠩࠪ䅀"))
				l1l111l1111l_l1_ = l11lll1ll111_l1_[0][0]
		if l1l111l1111l_l1_: line = line.replace(l1l111l1111l_l1_,l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䅁")+l1l111l1111l_l1_+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䅂"))
		l11lll11l111_l1_.append(line)
		if len(str(l11lll11l111_l1_))>50100: break
	l11lll11l111_l1_ = reversed(l11lll11l111_l1_)
	l1l11l11l1l1_l1_ = l1l11l_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ䅃").join(l11lll11l111_l1_)
	l1ll1lll11_l1_(l1l11l_l1_ (u"࠭࡬ࡦࡨࡷࠫ䅄"),l1l11l_l1_ (u"ࠧระิࠤศูืาࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠫ䅅"),l1l11l11l1l1_l1_,l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ䅆"))
	return
def l1l11111111l_l1_():
	l1l11l1l111l_l1_ = open(l11l1lll1ll_l1_,l1l11l_l1_ (u"ࠩࡵࡦࠬ䅇")).read()
	if kodi_version>18.99: l1l11l1l111l_l1_ = l1l11l1l111l_l1_.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䅈"))
	l1l11l1l111l_l1_ = l1l11l1l111l_l1_.replace(l1l11l_l1_ (u"ࠫࡡࡺࠧ䅉"),l1l11l_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧ䅊"))
	l111l11111l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧ䅋"),l1l11l1l111l_l1_,re.DOTALL)
	for line in l111l11111l_l1_:
		l1l11l1l111l_l1_ = l1l11l1l111l_l1_.replace(line,l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䅌")+line+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䅍"))
	DIALOG_TEXTVIEWER(l1l11l_l1_ (u"ࠩส่ฯเ๊๋ำสฮࠥอไฤะํีฮࠦแ๋ࠢส่อืวๆฮࠪ䅎"),l1l11l1l111l_l1_)
	return
def l1l111ll111l_l1_():
	l1111111ll_l1_ = l1l11l_l1_ (u"ࠪฬ฾฼ࠠศๆฦึึอัࠡ฻็ํࠥอไา์่์ฯࠦใ้่อีํ๊ࠠห๊ไีࠥหๅไษ้๎ฮࠦสใัํ้ࠥ๎สฤะํีࠥอไโ์า๎ํ่่ࠦา๊ࠤฬ๊รำำสีࠥํ๊ࠡษ็วุํๅ๊ࠡส่ศืโศ็้ࠣ฾ࠦศฺุࠣ์่อไหษ็๎ࠬ䅏")
	l111111l11_l1_ = l1l11l_l1_ (u"้ࠫะโะ์่ࠤฬ๊แ๋ัํ์ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ๆ์้ࠤํ๊สฤะํี์ࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋ีสีࠥ࠴ࠠฤ็สࠤ฾ีษࠡษึ๋๊ࠦๅหฬส่๏ฯࠠโ้ำ๋ࠥะโ้็ࠣฬฯำั๋ๅࠣห้็๊ะ์๋ࠤอ๎โหࠢส็อืࠠๆ่ࠣ์็ะࠠศๆึ๋๊ࠦวๅ๊สัิࠦ࠮ࠡล่หࠥอไิ้่ࠤฬ๊รฺๆ์ࠤํอไฤีไ่ࠥ็็้ࠢํัึ้ࠠศๆไ๎ิ๐่ࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥ๎ไไ่ࠣฬ็็าสࠢๆฬ๏ืษࠨ䅐")
	l1ll1l11l11l_l1_ = l1l11l_l1_ (u"ࠬษๅศࠢส่ศืโศ็ࠣๅ์๐ࠠหีอาิ๋ࠠๅๆอๆิ๐ๅ๊ࠡส่ฯษฮ๋ำࠣ์้้ๆࠡส่ๆิอัࠡ฻าำࠥอไฬ๊ส๊๏่ࠦศๆาๆฬฬโࠡ࠰้ࠣะ๊วࠡำๅ้ࠥ࠻࠴࠵ࠢอ฽๋๐ࠠ࠶ࠢาๆฬฬโ๊ࠡࠣ࠸࠹ࠦหศ่ํอࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวยࠢหัุฮࠠศีอาิอๅไࠢ็ุ่ํๅࠡษ็๎๊๐ๆࠡล๋ࠤุํๅࠡษ็๎ุอัࠨ䅑")
	message = l1111111ll_l1_+l1l11l_l1_ (u"࠭࠺ࠡࠩ䅒")+l111111l11_l1_+l1l11l_l1_ (u"ࠧࠡ࠰ࠣࠫ䅓")+l1ll1l11l11l_l1_
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䅔"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䅕"),message,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭䅖"))
	return
def l11llll111ll_l1_(l11l11ll11l_l1_=l1l11l_l1_ (u"ࠫࠬ䅗")):
	# url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡱ࡮ࡲࡧࡦࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ䅘")
	url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࡯ࡳ࠯ࡣࡳࡴ࠴ࡰࡳࡰࡰ࠲ࠫ䅙")+l11l11ll11l_l1_
	response = OPENURL_REQUESTS(l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䅚"),url,l1l11l_l1_ (u"ࠨࠩ䅛"),l1l11l_l1_ (u"ࠩࠪ䅜"),l1l11l_l1_ (u"ࠪࠫ䅝"),False,l1l11l_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡇࡆࡖࡢࡍࡕࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ䅞"))
	html = response.content
	l11lll11llll_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ䅟"),html)
	l1l11ll11111_l1_ = l1l11l_l1_ (u"࠭ࠧ䅠")
	if l1l11l_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ䅡") in list(l11lll11llll_l1_.keys()): l1l11ll11111_l1_ += l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䅢")+l11lll11llll_l1_[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ䅣")]
	if l1l11l_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䅤") in list(l11lll11llll_l1_.keys()): l1l11ll11111_l1_ += l1l11l_l1_ (u"ࠫ࠿ࡀࠧ䅥")+l11lll11llll_l1_[l1l11l_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䅦")]
	if l1l11l_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭䅧") in list(l11lll11llll_l1_.keys()): l1l11ll11111_l1_ += l1l11l_l1_ (u"ࠧ࠻࠼ࠪ䅨")+l11lll11llll_l1_[l1l11l_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ䅩")]
	if l1l11l_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ䅪") in list(l11lll11llll_l1_.keys()): l1l11ll11111_l1_ += l1l11l_l1_ (u"ࠪ࠾࠿࠭䅫")+l11lll11llll_l1_[l1l11l_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ䅬")]
	if l1l11l_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫࡟ࡨ࡯ࡷࠫ䅭") in list(l11lll11llll_l1_.keys()):
		timezone = l11lll11llll_l1_[l1l11l_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࡠࡩࡰࡸࠬ䅮")]
		if l1l11l_l1_ (u"ࠧ࠮ࠩ䅯") not in timezone: timezone = l1l11l_l1_ (u"ࠨ࠭ࠪ䅰")+timezone
		l1l11ll11111_l1_ += l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䅱")+timezone
	l1l11ll11111_l1_ = l1l11ll11111_l1_.strip(l1l11l_l1_ (u"ࠪ࠾࠿࠭䅲")).replace(l1l11l_l1_ (u"ࠫ࠿ࡀ࠺࠻ࠩ䅳"),l1l11l_l1_ (u"ࠬࡀ࠺ࠨ䅴")).replace(l1l11l_l1_ (u"࠭࠺࠻ࠩ䅵"),l1l11l_l1_ (u"ࠧ࠭ࠢࠪ䅶"))
	if kodi_version>18.99: l1l11ll11111_l1_ = l1l11ll11111_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䅷")).decode(l1l11l_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ䅸"))
	return l1l11ll11111_l1_
def l1l1lll111l_l1_(l11ll11l1ll_l1_,message,showDialogs=True,url=l1l11l_l1_ (u"ࠪࠫ䅹"),source=l1l11l_l1_ (u"ࠫࠬ䅺"),text=l1l11l_l1_ (u"ࠬ࠭䅻"),l1l1l1l11l11_l1_=l1l11l_l1_ (u"࠭ࠧ䅼")):
	if l1l11l_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ䅽") in text: l1111llll11_l1_ = True
	else: l1111llll11_l1_ = False
	l11ll1llll1l_l1_ = True
	if not l11l1l11lll_l1_(l1l11l_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ䅾")):
		if showDialogs:
			#if message.count(l1l11l_l1_ (u"ࠩ࡟ࡠࡳ࠭䅿"))>1: l11l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ䆀")
			#else: l11l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䆁")
			l11llll111l1_l1_ = (l1l11l_l1_ (u"ࠬอไิูิ࠾ࠬ䆂") in message and l1l11l_l1_ (u"࠭วๅ็ๆห๋ࡀࠧ䆃") in message and l1l11l_l1_ (u"ࠧศๆ่่ๆࡀࠧ䆄") in message and l1l11l_l1_ (u"ࠨษ็า฼ษࠧ䆅") in message and l1l11l_l1_ (u"ࠩส่๊฻ฯา࠼ࠪ䆆") in message)
			if not l11llll111l1_l1_: l11ll1llll1l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䆇"),l1l11l_l1_ (u"ࠫࠬ䆈"),l1l11l_l1_ (u"ࠬ࠭䆉"),l1l11l_l1_ (u"࠭็ๅࠢอีุ๊่ࠠา๊ࠤฬ๊ัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ䆊"),message.replace(l1l11l_l1_ (u"ࠧ࡝࡞ࡱࠫ䆋"),l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䆌")))
	elif showDialogs:
		message = l1l11l_l1_ (u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩ䆍")
		l1l11ll11lll_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䆎"),l1l11l_l1_ (u"ࠫࠬ䆏"),l1l11l_l1_ (u"ࠬ࠭䆐"),l1l11l_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭䆑")+l1l11l_l1_ (u"ࠧࠡࠢ࠴࠳࠺࠭䆒"),l1l11l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭䆓"))
		l1l11ll11ll1_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䆔"),l1l11l_l1_ (u"ࠪࠫ䆕"),l1l11l_l1_ (u"ࠫࠬ䆖"),l1l11l_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ䆗")+l1l11l_l1_ (u"࠭ࠠࠡ࠴࠲࠹ࠬ䆘"),l1l11l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ䆙"))
		l1l11ll11l1l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䆚"),l1l11l_l1_ (u"ࠩࠪ䆛"),l1l11l_l1_ (u"ࠪࠫ䆜"),l1l11l_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ䆝")+l1l11l_l1_ (u"ࠬࠦࠠ࠴࠱࠸ࠫ䆞"),l1l11l_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ䆟"))
		l1l11ll1l1ll_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䆠"),l1l11l_l1_ (u"ࠨࠩ䆡"),l1l11l_l1_ (u"ࠩࠪ䆢"),l1l11l_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ䆣")+l1l11l_l1_ (u"ࠫࠥࠦ࠴࠰࠷ࠪ䆤"),l1l11l_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ䆥"))
		l11ll1llll1l_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䆦"),l1l11l_l1_ (u"ࠧࠨ䆧"),l1l11l_l1_ (u"ࠨࠩ䆨"),l1l11l_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ䆩")+l1l11l_l1_ (u"ࠪࠤࠥ࠻࠯࠶ࠩ䆪"),l1l11l_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ䆫"))
	if l11ll1llll1l_l1_!=1:
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䆬"),l1l11l_l1_ (u"࠭ࠧ䆭"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䆮"),l1l11l_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫ䆯"))
		return False
	l1l11ll1ll11_l1_ = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠣ䆰") )
	message += l1l11l_l1_ (u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ䆱")+addon_version+l1l11l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ䆲")
	message += l1l11l_l1_ (u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭䆳")+l1l11ll111l_l1_(32)+l1l11l_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬ䆴")+kodi_release+l1l11l_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࠭䆵")
	message += l1l11l_l1_ (u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭䆶")+l1l11ll1ll11_l1_
	#l1l11ll11111_l1_ = l11llll111ll_l1_(l1l11l_l1_ (u"ࠩ࠺࠺࠳࠼࠵࠯࠳࠶࠼࠳࠸࠳࠱ࠩ䆷"))
	l1l11ll11111_l1_ = l11llll111ll_l1_()
	l1l11ll11111_l1_ = QUOTE(l1l11ll11111_l1_)
	if l1l11ll11111_l1_: message += l1l11l_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬ䆸")+l1l11ll11111_l1_
	if url: message += l1l11l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨ䆹")+url
	if source: message += l1l11l_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬ䆺")+source
	message += l1l11l_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ䆻")
	if showDialogs: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧอษิ๎ࠥอไฦำึห้࠭䆼"),l1l11l_l1_ (u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪ䆽"))
	if l1l1l1l11l11_l1_:
		l1l11l11l1l1_l1_ = l1l1l1l11l11_l1_
		if kodi_version>18.99: l1l11l11l1l1_l1_ = l1l11l11l1l1_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䆾"))
		l1l11l11l1l1_l1_ = base64.b64encode(l1l11l11l1l1_l1_)
	elif l1111llll11_l1_:
		if l1l11l_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ䆿") in text: l1l11ll111ll_l1_ = l11llllll11_l1_
		else: l1l11ll111ll_l1_ = l11ll1lllll_l1_
		if not os.path.exists(l1l11ll111ll_l1_):
			DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䇀"),l1l11l_l1_ (u"ࠬ࠭䇁"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䇂"),l1l11l_l1_ (u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬ䇃"))
			return False
		l11lll11l111_l1_,counts = [],0
		size = os.path.getsize(l1l11ll111ll_l1_)
		file = open(l1l11ll111ll_l1_,l1l11l_l1_ (u"ࠨࡴࡥࠫ䇄"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䇅"))
		data = l11lll1111l1_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䇆"))
			ignore = l1l11111l111_l1_(line)
			if ignore: continue
			l11lll1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰࠭࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ䇇"),line,re.DOTALL)
			if l11lll1ll111_l1_:
				line = line.replace(l11lll1ll111_l1_[0][0],l1l11l_l1_ (u"ࠬ࠭䇈")).replace(l11lll1ll111_l1_[0][2],l1l11l_l1_ (u"࠭ࠧ䇉"))
			else:
				l11lll1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ䇊"),line,re.DOTALL)
				if l11lll1ll111_l1_: line = line.replace(l11lll1ll111_l1_[0][1],l1l11l_l1_ (u"ࠨࠩ䇋"))
			l11lll11l111_l1_.append(line)
			if len(str(l11lll11l111_l1_))>121000: break
		l11lll11l111_l1_ = reversed(l11lll11l111_l1_)
		l1l11l11l1l1_l1_ = l1l11l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ䇌").join(l11lll11l111_l1_)
		l1l11l11l1l1_l1_ = l1l11l11l1l1_l1_.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䇍"))
		l1l11l11l1l1_l1_ = base64.b64encode(l1l11l11l1l1_l1_)
	else: l1l11l11l1l1_l1_ = l1l11l_l1_ (u"ࠫࠬ䇎")
	url = WEBSITES[l1l11l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ䇏")][2]
	payload = {l1l11l_l1_ (u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ䇐"):l11ll11l1ll_l1_,l1l11l_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ䇑"):message,l1l11l_l1_ (u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ䇒"):l1l11l11l1l1_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䇓"),url,payload,l1l11l_l1_ (u"ࠪࠫ䇔"),l1l11l_l1_ (u"ࠫࠬ䇕"),l1l11l_l1_ (u"ࠬ࠭䇖"),l1l11l_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵࠩ䇗"))
	#succeeded = response.succeeded
	html = response.content
	if l1l11l_l1_ (u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩ䇘") in html: succeeded = True
	else: succeeded = False
	if showDialogs:
		if succeeded:
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠬ䇙"),l1l11l_l1_ (u"ࠩห๊ัออࠨ䇚"))
			DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䇛"),l1l11l_l1_ (u"ࠫࠬ䇜"),l1l11l_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫ䇝"),l1l11l_l1_ (u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨ䇞"))
		else:
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧๅๆฦืๆ࠭䇟"),l1l11l_l1_ (u"ࠨใื่ࠥ็๊ࠡษ็ษึูวๅࠩ䇠"))
			DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䇡"),l1l11l_l1_ (u"ࠪࠫ䇢"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䇣"),l1l11l_l1_ (u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ䇤"))
	return succeeded
def l11ll1llllll_l1_():
	l1111111ll_l1_ = l1l11l_l1_ (u"࠭࠱࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡࡶࡨࡼࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ䇥")
	l111111l11_l1_ = l1l11l_l1_ (u"ࠧ࠲࠰ࠣࠤࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢส่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ䇦")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䇧"),l1l11l_l1_ (u"ࠩࠪ䇨"),l1l11l_l1_ (u"ࠪࡅࡷࡧࡢࡪࡥࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ䇩"),l1111111ll_l1_+l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䇪")+l111111l11_l1_)
	l1111111ll_l1_ = l1l11l_l1_ (u"ࠬ࠸࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡢࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠫ䇫")
	l111111l11_l1_ = l1l11l_l1_ (u"࠭࠲࠯ࠢࠣࠤสึวࠡๆ่ࠤฯาฯࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠโไ่ࠤอะฺ๋์ิࠤฬ๊ฬๅัࠣฯ๊ࠦโๆࠢหฮ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡษ็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭䇬")
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䇭"),l1l11l_l1_ (u"ࠨࠩ䇮"),l1l11l_l1_ (u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ䇯"),l1111111ll_l1_+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䇰")+l111111l11_l1_)
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䇱"),l1l11l_l1_ (u"ࠬ࠭䇲"),l1l11l_l1_ (u"࠭ࠧ䇳"),l1l11l_l1_ (u"ࠧࡇࡱࡱࡸࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧ䇴"),l1l11l_l1_ (u"ࠨࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦ࡮ࡰࡹࠣࡃࠬ䇵")+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䇶")+l1l11l_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ะ่ษหࠤส๊้ࠡๆ๋ัฮࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤศ๊ย็มࠪ䇷"))
	if yes==1: l1l11l11ll11_l1_()
	return
def l1l11lll111l_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䇸"),l1l11l_l1_ (u"ࠬ࠭䇹"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䇺"),l1l11l_l1_ (u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭䇻"))
	return
def l1l11l1l1lll_l1_():
	message = l1l11l_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨ䇼")
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䇽"),l1l11l_l1_ (u"ࠪࠫ䇾"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䇿"),message)
	return
def l1l1111ll111_l1_():
	message = l1l11l_l1_ (u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ䈀")
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䈁"),l1l11l_l1_ (u"ࠧࠨ䈂"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䈃"),message)
	return
def l11ll1llll11_l1_():
	message = l1l11l_l1_ (u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭䈄")
	DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䈅"),l1l11l_l1_ (u"ࠫࠬ䈆"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䈇"),l1l11l_l1_ (u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨ䈈"),message)
	return
def l1l11l11ll1l_l1_():
	message = l1l11l_l1_ (u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬ䈉")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䈊"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䈋"),message,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭䈌"))
	return
def l1l111l11ll1_l1_():
	l1111111ll_l1_ = l1l11l_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬ䈍")
	l111111l11_l1_ = l1l11l_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧ䈎")
	l1ll1l11l11l_l1_ = l1l11l_l1_ (u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䈏")
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䈐"),l1l11l_l1_ (u"ࠨࠩ䈑"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䈒"),l1111111ll_l1_,l111111l11_l1_,l1ll1l11l11l_l1_)
	return
def l1l1111l11ll_l1_():
	l111111l11_l1_ = l1l11l_l1_ (u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫ䈓")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䈔") + l1l11l_l1_ (u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ䈕") + str(PERMANENT_CACHE/60/60/24/30) + l1l11l_l1_ (u"࠭ࠠี้ิࠫ䈖")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䈗") + l1l11l_l1_ (u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ䈘") + str(l1llllll1l1_l1_/60/60/24) + l1l11l_l1_ (u"ࠩࠣ๎ํ๋ࠧ䈙")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠪࡠࡳ࠭䈚") + l1l11l_l1_ (u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ䈛") + str(l1llll_l1_/60/60/24) + l1l11l_l1_ (u"๊้ࠬࠦ็ࠪ䈜")
	l111111l11_l1_ += l1l11l_l1_ (u"࠭࡜࡯ࠩ䈝") + l1l11l_l1_ (u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ䈞") + str(REGULAR_CACHE/60/60) + l1l11l_l1_ (u"ࠨࠢึห฾ฯࠧ䈟")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䈠") + l1l11l_l1_ (u"ࠪ࠹࠳ࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡัสส๊อ้ࠠ็าฮ์ࠦࠧ䈡") + str(l111l11l_l1_/60/60) + l1l11l_l1_ (u"ูࠫࠥวฺหࠪ䈢")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䈣") + l1l11l_l1_ (u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧ䈤") + str(l11l1ll111l_l1_/60) + l1l11l_l1_ (u"ࠧࠡัๅ๎็ฯࠧ䈥")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䈦") + l1l11l_l1_ (u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫ䈧") + str(NO_CACHE) + l1l11l_l1_ (u"ࠪࠤิ่๊ใหࠪ䈨")
	l111111l11_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䈩") + l1l11l_l1_ (u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩ䈪") + str(REGULAR_CACHE/60/60) + l1l11l_l1_ (u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧ䈫") + str(l1llll_l1_/60/60/24) + l1l11l_l1_ (u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭䈬") + str(l111l11l_l1_/60/60) + l1l11l_l1_ (u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬ䈭") + str(l11l1ll111l_l1_/60) + l1l11l_l1_ (u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫ䈮") + str(NO_CACHE) + l1l11l_l1_ (u"ࠪࠤิ่๊ใหࠪ䈯")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ䈰"),l1l11l_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ䈱"),l111111l11_l1_,l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ䈲"))
	return
def l11lll1ll1ll_l1_():
	message = l1l11l_l1_ (u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ䈳")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䈴"),l1l11l_l1_ (u"ࠩࠪ䈵"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䈶"),message)
	return
def l11llll1l1ll_l1_():
	message = l1l11l_l1_ (u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ䈷")
	DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䈸"),l1l11l_l1_ (u"࠭ࠧ䈹"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䈺"),message)
	return
def l1l111ll1l11_l1_():
	message = l1l11l_l1_ (u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬ䈻")
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䈼"),l1l11l_l1_ (u"ࠪࠫ䈽"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䈾"),message)
	return
def l11llll11ll1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䈿"),l1l11l_l1_ (u"࠭ࠧ䉀"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䉁"),l1l11l_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭䉂"))
	l1ll11ll1l1_l1_(l1l11l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ䉃"),True)
	return
def l11lllllll1l_l1_():
	message  = l1l11l_l1_ (u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ䉄")
	#message += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞๊๊ิฬࠦวๅ฻สส็ࠦ็้ࠢࡵࡩࡈࡇࡐࡕࡅࡋࡅࠥอไฯษุࠤอฺัไหࠣะําไ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ䉅")
	#message += l1l11l_l1_ (u"ࠬ๎วๅาํࠤฺ์ูหุ้ࠣึ้ษࠡฮ๋ะ้ࠦฮึ์ุห๊ࠥๅ็฻ࠣฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ๊์ࠠหืไัࠥอไฦ่อี๋ะࠧ䉆")
	message += l1l11l_l1_ (u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭䉇")
	message += l1l11l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิั࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ䉈")
	message += l1l11l_l1_ (u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨ䉉")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ䉊"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䉋"),message,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ䉌"))
	message = l1l11l_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ䉍")
	message += l1l11l_l1_ (u"࠭࡜࡯ࠩ䉎")+l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䉏")
	message += l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䉐")+l1l11l_l1_ (u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ䉑")
	message += l1l11l_l1_ (u"ࠪࡠࡳ࠭䉒")+l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䉓")
	message += l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䉔")+l1l11l_l1_ (u"࠭วๅ็หี๊า้ࠠฮาࠤ฼ื๊ให่ࠣฯาว้ิࠣห้฿ววไࠣ์้้ๆ่ษࠣฮาะวอࠢฯ๋ิࠦใษ์ิࠤํอไๆสิ้ัู๊่ࠦࠣห้๋ิไๆฬࠤฺเ๊าหࠣ์้อࠠหีอั็ࠦวๅฬ฼ฬࠥ็ลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠษษ็ำำ๎ไࠡๆห฽฻ࠦวๅ็๋ห็฿้ࠠลํฺฬࠦไไ์ࠣ๎ฯ฼อࠡฯฯ้ࠥอไๆึๆ่ฮࠦࠧ䉕")
	message += l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟สีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้ส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䉖")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ䉗"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䉘"),message,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭䉙"))
	#l11lllll1111_l1_(l1l11l_l1_ (u"ࠫࡎࡹࡐࡳࡱࡥࡰࡪࡳ࠽ࡇࡣ࡯ࡷࡪ࠭䉚"))
	#message = l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䉛")+l1l11l_l1_ (u"่࠭ๅไาࠤ้ออู่สࠤฬ๐ึศࠢฦ๊ࠥอไๆ๊สๆ฾ࠦวๅ็฼ห็ฯࠠหะอ่ๆࠦศศะอ่ฬ็ࠠศๆห่ิ่ࠦหะอ่ๆࠦศศะอ่ฬ็ࠠีำๆอࠥอไศ่อี๋๐สࠡใํࠤี๊ใࠡษ็ฬ้ี้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์็ࠡฯอํ๊่ࠥࠡฬ่ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥࡖࡲࡰࡺࡼࠤศ๎ࠠฤ์ࠣ์ุ๐ไสࠢสาึ๏ࠠโษ้ࠤฬ๊ๅ้ษๅ฽ࠥอไๆ฻สๆฮࠦำ้ใࠣฮำะไโ๋่่ࠢ์็ศࠢ็๊ࠥะูๆๆࠣะ๊๐ู่ษࠪ䉜")
	#message += l1l11l_l1_ (u"ࠧๅฯ็ࠤฬ๊ๅีๅ็อ่ࠥๅࠡส฼้้๐ๆ࠻ࠢࠣࠤࠥอไฤ๊็࠾ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า๊ࠩࠡส็ฯฮࠠๆ฻๊ࠤฬูๅࠡส็ำ่่ࠦศี่ࠤูืใสࠢส่ส์สา่ํฮࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠห฻่่ࠥ฿ๆะๅࠪ䉝")
	#message += l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䉞")+l1l11l_l1_ (u"๋ࠩห้ัว็์࠽ࠤัืศࠡษึฮำีวๆ࡙ࠢࡔࡓฺ่่ࠦาࠤฬ๊ศฺุࠣๆิࠦสฮฬสะࠥ็โุࠢอ฾๏๐ัࠡࡆࡑࡗࠥ๎วๅละื๋ࠦร็ࠢํ็ํ์ࠠโ์ࠣฬ้ีࠠศะิࠤ฾๊ๅศࠢส๊ࠥอำหะาห๊ࠦࡐࡳࡱࡻࡽ่ࠥฯࠡ์ะ่๋ࠥิไๆฬࠤอ฿ึࠡษ็้ํอโฺ๋่่ࠢ์ࠠๅ์ึࠤๆ๐ࠠอ็ํ฽ࠥอไะ๊็ࠫ䉟")
	#DIALOG_TEXTVIEWER(l1l11l_l1_ (u"ู้้ࠪไสࠢ฼๊ิࠦศฺุࠣห้์วิࠩ䉠"),message)
	#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䉡"),l1l11l_l1_ (u"ࠬ็อึࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠨ䉢"),l1l11l_l1_ (u"࠭็ัษࠣห้็อึ๊ࠢ์๊ࠥๅฺำไอࠥํไࠡษ็ู้้ไส่๊ࠢࠥ฿ๆะๅࠣห๊ࠦๅ็ࠢส่อืๆศ็ฯ࠲ู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ็อึ่ࠢ์ฬู่่่ࠢีฯ๐ๆࠡษ็วํ๊้ࠡสฺ๋฾้ࠠศๆฺฬ๏฿๊๊ࠡส่ะอๆ๋หࠣฬฬูสฯัส้ࠥฮั้ๅึ๎๋ࠥฬศ่ํࠤฬ์สࠡฬัฮฬื็ࠡ็้ࠤฬ๊โศศ่อࠥอไห์ࠣืฯ฾็าࠢ็หา่ว࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึลࠧ䉣"),l1l11l_l1_ (u"ࠧࠨ䉤"),l1l11l_l1_ (u"ࠨࠩ䉥"),l1l11l_l1_ (u"ࠩๆ่ฬ࠭䉦"),l1l11l_l1_ (u"๊ࠪ฾๋ࠧ䉧"))
	#if yes==1:
	#l1l1111llll1_l1_()
	return
def l1l11111lll1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䉨"),l1l11l_l1_ (u"ࠬ࠭䉩"),l1l11l_l1_ (u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭䉪"),l1l11l_l1_ (u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡะา้ฬะ่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥษัิๆࠣีุอไสࠢไ๎ุฮ่ไࠢส่๎ࠦࠢศๆะหัูࠦๆษาࠦࠥษ่ࠡษ็ํࠥࡢ࡮ࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࠰ࡰࡥ࡭ࡪࡩ࠲ࠢ࡟ࡲࡡࡴร้ࠢสๅฯำࠠ็ไสุࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ัศสฺࠤࡡࡴࠠࡩࡶࡷࡴ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴࡯ࡳࡴࡷࡨࡷࠬ䉫"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䉬"),l1l11l_l1_ (u"ࠩࠪ䉭"),l1l11l_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ䉮"),l1l11l_l1_ (u"ࠫ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹࡜࡯࡞ࡱ࠸࠹࠺࠴࠵ࠢ࠸࠹࠺࠻࠵ࠡ࠸࠹࠺࠻࠼࡟࠸࠹࠺࠻࠼ࠦ࠸࠹࠺࠻࠼ࠥ࠿࠹࠺࠻࠼ࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࡣࡏࡐࡊࡋࡌ࠴ࡣࡐࡑࡋࡌࡍ࠴ࡣࡑࡒࡌࡍࡎ࠴ࡣࡒࡓࡍࡎࡏ࠴ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦࡁࡂࡃࡄࡅ࠷ࡥࡂࡃࡄࡅࡆ࠷ࡥࡃࡄࡅࡆࡇ࠷ࡥࡄࡅࡆࡇࡈ࠷ࡥࡅࡆࡇࡈࡉ࠷ࡥࡆࡇࡈࡉࡊ࠷ࡥࡇࡈࡉࡊࡋ࠷ࡥࡈࡉࡊࡋࡌ࠷ࡥࡉࡊࡋࡌࡍ࠷ࡥࡊࡋࡌࡍࡎ࠷ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࠦ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂࠢࡅࡆࡇࡈࡂࠨ䉯"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䉰"),l1l11l_l1_ (u"࠭ࠧ䉱"),l1l11l_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ䉲"),l1l11l_l1_ (u"ࠨ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠳ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡ࠻ࠣࡅࡆࡇࡁࡂ࠳ࡢࡆࡇࡈࡂࡃ࠳ࡢࡇࡈࡉࡃࡄ࠳ࡢࡈࡉࡊࡄࡅ࠳ࡢࡉࡊࡋࡅࡆ࠳ࡢࡊࡋࡌࡆࡇ࠳ࡢࡋࡌࡍࡇࡈ࠳ࡢࡌࡍࡎࡈࡉ࠳ࡢࡍࡎࡏࡉࡊ࠳ࡢࡎࡏࡐࡊࡋ࠳ࡢࡏࡐࡑࡋࡌ࠳ࡢࡐࡑࡒࡌࡍ࠳ࡢࡑࡒࡓࡍࡎ࠳ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥࡇࡁࡂࡃࡄ࠶ࡤࡈࡂࡃࡄࡅ࠶ࡤࡉࡃࡄࡅࡆ࠶ࡤࡊࡄࡅࡆࡇ࠶ࡤࡋࡅࡆࡇࡈ࠶ࡤࡌࡆࡇࡈࡉ࠶ࡤࡍࡇࡈࡉࡊ࠶ࡤࡎࡈࡉࡊࡋ࠶ࡤࡏࡉࡊࡋࡌ࠶ࡤࡐࡊࡋࡌࡍ࠶ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࠥ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁࠡࡄࡅࡆࡇࡈࠧ䉳"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䉴"),l1l11l_l1_ (u"ࠪࠫ䉵"),l1l11l_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ䉶"),l1l11l_l1_ (u"ࠬ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠫ䉷"))
	#text = l1l11l_l1_ (u"࠭ࠨࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࠡࠫࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠩ䉸")
	#l1111lll1ll_l1_(l1l11l_l1_ (u"ࠧࠨ䉹"),l1l11l_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ䉺"),l1l11l_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ䉻"),l1l11l_l1_ (u"ࠪ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿࠰࠲࠴࠶࠸ࠬ䉼"),l1l11l_l1_ (u"ࠫ࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸࠲࠳࠴࠵࠶ࠬ䉽"),text,1)
	#l1111lll1ll_l1_(l1l11l_l1_ (u"ࠬ࠭䉾"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭䉿"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ䊀"),l1l11l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ䊁"),l1l11l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭䊂"),l1l11l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ䊃"))
	#l1111lll1ll_l1_(l1l11l_l1_ (u"ࠫࠬ䊄"),l1l11l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ䊅"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭䊆"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ䊇"),l1l11l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ䊈"),l1l11l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ䊉"))
	#l1111lll1ll_l1_(l1l11l_l1_ (u"ࠪࠫ䊊"),l1l11l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ䊋"),l1l11l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ䊌"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭䊍"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ䊎"),l1l11l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ䊏"))
	#l1111lll1ll_l1_(l1l11l_l1_ (u"ࠩࠪ䊐"),l1l11l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ䊑"),l1l11l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ䊒"),l1l11l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ䊓"),l1l11l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉ࡞ࡱࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭䊔"),l1l11l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ䊕"))
	return
def l1l11111l1ll_l1_():
	l1l1111l11ll_l1_()
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䊖"),l1l11l_l1_ (u"ࠩࠪ䊗"),l1l11l_l1_ (u"ࠪࠫ䊘"),l1l11l_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠศๆๆหูࠦฟࠨ䊙"),l1l11l_l1_ (u"ࠬอไไษืࠤ๏ูัฺࠢ฼้้ࠦวๅสิ๊ฬ๋ฬ๊่ࠡืาํ๋ࠠ฻ํำูࠥอษࠢสฺ่็อศฬ้๋ࠣࠦวๅว้ฮึ์สࠡ฻้ำࠥอไฮษฯอࠥหไ๋้สࠤํอไๆีะࠤ๏ะๅࠡฬ็ๆฬฬ๊ศࠢ฼๊ิࠦว็ฬ๊หฦูࠦๆำࠣห้฻แฮษอࠤํอไๆีะࠤ้อุ๋ࠠิࠤํ๋ๅไ่ࠣ๎า๊ࠠษ฻ูࠤฬ๊ๅีษๆ่ࠬ䊚"))
	if yes==1:
		l1ll111l1l1_l1_([iptv1_dbfile,iptv2_dbfile])
		DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䊛"),l1l11l_l1_ (u"ࠧࠨ䊜"),l1l11l_l1_ (u"ࠨฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠษษ็็ฬ๋ไࠨ䊝"),l1l11l_l1_ (u"ࠩศิฬࠦใศ่อࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬำฯࠡษ็้ํอโฺࠢไะึฮࠠศๆ่์็฿ࠠศๆล๊ࠥ࠴࠮࠯๋ࠢวีอࠠศๆุ่่๊ษࠡ็ึฮ๊ืษࠡใศิ๋ࠦวาี็ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ䊞"))
	return yes
def l11llllll1l_l1_(showDialogs=True):
	if not showDialogs: showDialogs = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䊟"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡸࡢ࡯ࡳࡰࡪ࠴ࡣࡰ࡯ࠪ䊠"),l1l11l_l1_ (u"ࠬ࠭䊡"),l1l11l_l1_ (u"࠭ࠧ䊢"),False,l1l11l_l1_ (u"ࠧࠨ䊣"),l1l11l_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ䊤"))
	#html = response.content
	if not response.succeeded:
		l11llllll11l_l1_ = False
		l1ll1l11ll_l1_ = l1ll11lll1_l1_()
		LOG_THIS(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䊥"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨ䊦")+l1ll1l11ll_l1_+l1l11l_l1_ (u"ࠫࡢ࠭䊧"))
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䊨"),l1l11l_l1_ (u"࠭ࠧ䊩"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䊪"),l1l11l_l1_ (u"ࠨใะูࠥอไศฬุห้ࠦวๅ็ืๅึࠦ࠮࠯࠰ู้้ࠣไสࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡๆสࠤ๏฿ๅๅࠢ฼๊ิฺ้ࠠๆ์ࠤ่๎ฯ๋ࠢ࠱࠲࠳ฺ่่ࠦา็้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬ䊫"))
	else:
		l11llllll11l_l1_ = True
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䊬"),l1l11l_l1_ (u"ࠪࠫ䊭"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䊮"),l1l11l_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ䊯"))
	if not l11llllll11l_l1_ and showDialogs: l1l111l11l1l_l1_()
	return l11llllll11l_l1_
def l1l111l11l1l_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䊰"),l1l11l_l1_ (u"ࠧࠨ䊱"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䊲"),l1l11l_l1_ (u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨ䊳"))
	#l111111l11_l1_ = l1l11l_l1_ (u"ุࠪ์อฯสࠢส่ฯฺแ๋ำ๋ࠣ๏ࠦๅๅใࠣ๎าะ่๋ࠢ฼่๎ࠦิโำฬࠤำอีสࠢฦ์ࠥะ่ศไํ฽ࠥิวึหู่ࠣืใศฬ้ࠣ฾ื่โหࠣ์้ํࠠหษิ๎ำࠦีๅษะ๎ฮ่ࠦ็ใสิࠥ๎วๅ฼ิฺ๋ࠥๆ่๊ࠢ์ࠥะศศั็ࠤฬ๊ๅฺๆ๋้ฬะࠠษูิ๎็ฯࠠๆึไีฮ๊ࠦึ฻หࠤฬิสาษๅ๋ฬ่ࠦโ้่๋ฬ࠭䊴")
	l1l111ll1l1l_l1_()
	return
def l11lllll1111_l1_(text=l1l11l_l1_ (u"ࠫࠬ䊵")):
	l1111llll11_l1_ = True
	if l1l11l_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ䊶") not in text:
		l1111llll11_l1_ = False
		yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䊷"),l1l11l_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠬ䊸"),l1l11l_l1_ (u"ࠨวิืฬ๊ࠠๆึๆ่ฮ࠭䊹"),l1l11l_l1_ (u"ࠩࠪ䊺"),l1l11l_l1_ (u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อࠥลࠧ䊻"))
		if yes==1:
			l1111llll11_l1_ = True
			text = l1l11l_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ䊼")
	if l1111llll11_l1_:
		#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䊽"),l1l11l_l1_ (u"࠭ࠧ䊾"),l1l11l_l1_ (u"ࠧࠨ䊿"),l1l11l_l1_ (u"ࠨวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ䋀"),l1l11l_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦิฬฺ๎฾ࠦวๅ็หี๊าࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠวุ่ฬำ็ศࠩ䋁"))
		#if not yes:
		#	DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䋂"),l1l11l_l1_ (u"ࠫࠬ䋃"),l1l11l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ䋄"),l1l11l_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ䋅"))
		#	return
		l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡯ࡳ࡬ࡹ࠽ࡺࡧࡶࠫࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸ๊่ࠧ࠭ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ࠮ࠪๆอ๊ࠠศำึห้ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัูࠦๅ์ๆࠤฬ์ࠠหไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦว้ࠢส่ึอศุࠢส่ี๐๋ࠠ฻ฺ๎่ࠦวๅ็ื็้ฯࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊࠴่ࠠๆࠣฮึ๐ฯࠡษ็หึูวๅࠢส่ฬ์ࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠶࠺ࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆ฽หฦࠦวๅษิืฬ๊ࠧࠪࠌࠌࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࠮ࠪหีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไห้ืฬศรࠣๆึอมสࠢๅื๊ࠦวๅ็ืห่๊้ࠠษ็หุฬไส๋ࠢหีอࠠๅ็ࠣฮัีࠠศๆะ่ࠥํๆศๅࠣๅาอ่ๅࠢๆฮฬฮษࠡฮ่๎฾ࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠯ࠊࠊࠋࠥࠦࠧ䋆")
		if l1l11l_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ䋇") not in text:
			yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䋈"),l1l11l_l1_ (u"ࠪࠫ䋉"),l1l11l_l1_ (u"ࠫࠬ䋊"),l1l11l_l1_ (u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ䋋"),l1l11l_l1_ (u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭䋌"))
			if yes!=1:
				DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䋍"),l1l11l_l1_ (u"ࠨࠩ䋎"),l1l11l_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ䋏"),l1l11l_l1_ (u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭䋐"))
				return
	DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䋑"),l1l11l_l1_ (u"ࠬ࠭䋒"),l1l11l_l1_ (u"࠭ใหษหอࠥ๎ิาฯࠣห้๋่ื๊฼ࠤ้๊ๅษำ่ะࠬ䋓"),l1l11l_l1_ (u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไศ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ䋔"))
	search = OPEN_KEYBOARD(l1l11l_l1_ (u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩ䋕"))
	if not search: return
	message = search
	if l1111llll11_l1_: type = l1l11l_l1_ (u"ࠩ࠰ࡔࡷࡵࡢ࡭ࡧࡰࠫ䋖")
	else: type = l1l11l_l1_ (u"ࠪ࠱ࡒ࡫ࡳࡴࡣࡪࡩࠬ䋗")
	l11ll11l1ll_l1_ = l1l11l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ䋘")+l1l11ll111l_l1_(32)+type
	succeeded = l1l1lll111l_l1_(l11ll11l1ll_l1_,message,True,l1l11l_l1_ (u"ࠬ࠭䋙"),l1l11l_l1_ (u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩ䋚"),text)
	#	url = l1l11l_l1_ (u"ࠧ࡮ࡻࠣࡅࡕࡏࠠࡢࡰࡧ࠳ࡴࡸࠠࡔࡏࡗࡔࠥࡹࡥࡳࡸࡨࡶࠬ䋛")
	#	payload = l1l11l_l1_ (u"ࠨࡽࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ࠿ࠨࡍ࡚ࠢࡄࡔࡎࠦࡋࡆ࡛ࠥ࠰ࠧࡺ࡯ࠣ࠼࡞ࠦࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠥࡡ࠱ࠨࡳࡦࡰࡧࡩࡷࠨ࠺ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࠭ࠤࡶࡹࡧࡰࡥࡤࡶࠥ࠾ࠧࡌࡲࡰ࡯ࠣࡅࡷࡧࡢࡪࡥ࡚ࠣ࡮ࡪࡥࡰࡵࠥ࠰ࠧࡺࡥࡹࡶࡢࡦࡴࡪࡹࠣ࠼ࠥࠫ䋜")+message+l1l11l_l1_ (u"ࠩࠥࢁࠬ䋝")
	#	#auth=(l1l11l_l1_ (u"ࠥࡥࡵ࡯ࠢ䋞"), l1l11l_l1_ (u"ࠦࡲࡿࠠࡱࡧࡵࡷࡴࡴࡡ࡭ࠢࡤࡴ࡮ࠦ࡫ࡦࡻࠥ䋟")),
	#	import requests
	#	response = requests.request(l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䋠"),url, data=payload, headers=l1l11l_l1_ (u"࠭ࠧ䋡"), auth=l1l11l_l1_ (u"ࠧࠨ䋢"))
	#	response = requests.l11l11l111_l1_(url, data=payload, headers=l1l11l_l1_ (u"ࠨࠩ䋣"), auth=l1l11l_l1_ (u"ࠩࠪ䋤"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䋥"),l1l11l_l1_ (u"ࠫࠬ䋦"),l1l11l_l1_ (u"ࠬ࠭䋧"),l1l11l_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ䋨"))
	#	else:
	#		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䋩"),l1l11l_l1_ (u"ࠨࠩ䋪"),l1l11l_l1_ (u"ࠩั฻ศࠦแ๋ࠢส่สืำศๆࠪ䋫"),l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡾࢁ࠿ࠦࡻࠢࡴࢀࠫ䋬").format(response.status_code, response.content))
	#	l11lllll1l11_l1_ = l1l11l_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ䋭")
	#	l11lllll1lll_l1_ = l1l11l_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ䋮")
	#	header = l1l11l_l1_ (u"࠭ࠧ䋯")
	#	#header += l1l11l_l1_ (u"ࠧࡇࡴࡲࡱ࠿ࠦࠧ䋰") + l11lllll1l11_l1_
	#	#header += l1l11l_l1_ (u"ࠨ࡞ࡱࡘࡴࡀࠠࠨ䋱") + l11ll1lll1ll_l1_
	#	#header += l1l11l_l1_ (u"ࠩ࡟ࡲࡈࡩ࠺ࠡࠩ䋲") + l11ll1lll1ll_l1_
	#	header += l1l11l_l1_ (u"ࠪࡠࡳ࡙ࡵࡣ࡬ࡨࡧࡹࡀࠠๆ่ࠣ็ํี๊ࠡษ็ๅ๏ี๊้ࠢส่฾ืศ๋ࠩ䋳")
	#	server = l1l11l1llll1_l1_.l11llllllll1_l1_(l1l11l_l1_ (u"ࠫࡸࡳࡴࡱ࠯ࡶࡩࡷࡼࡥࡳࠩ䋴"),25)
	#	#server.l1l1111ll1l1_l1_()
	#	server.l1l1111lll1l_l1_(l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ䋵"),l1l11l_l1_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ䋶"))
	#	response = server.l1l111lll111_l1_(l11lllll1l11_l1_,l11lllll1lll_l1_, header + l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䋷") + message)
	#	server.quit()
	return
def l1l11l111111_l1_():
	text = l1l11l_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ䋸")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ䋹"),l1l11l_l1_ (u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪ䋺"),text,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ䋻"))
	text = l1l11l_l1_ (u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨ䋼")
	l1ll1lll11_l1_(l1l11l_l1_ (u"࠭࡬ࡦࡨࡷࠫ䋽"),l1l11l_l1_ (u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬ䋾"),text,l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ䋿"))
	return
def l1l11111ll1l_l1_(addon_id):
	result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ䌀")+addon_id+l1l11l_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩ䌁"))
	l1l11llll1l_l1_ = True
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡰࡴࡴࡸࡴࠡࡵ࡫ࡹࡹ࡯࡬ࠋࠋࡻࡦࡲࡩࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡾࡢ࡮ࡥࡩࡳࡱࡪࡥࡳ࠮ࠪࡥࡩࡪ࡯࡯ࡵࠪ࠰ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠯ࠊࠊ࡫ࡩࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳࡫ࡸࡪࡵࡷࡷ࠭ࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠩ࠻ࠌࠌࠍࡸ࡮ࡵࡵ࡫࡯࠲ࡷࡳࡴࡳࡧࡨࠬࡽࡨ࡭ࡤࡨ࡬ࡰࡪ࠯ࠊࠊࠋࡵࡩ࡫ࡸࡥࡴࡪࠣࡁ࡚ࠥࡲࡶࡧࠍࠍࡺࡹࡥࡳࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡧࡤࡥࡱࡱࡷࠬ࠲ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪࠌࠌ࡭࡫ࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨࡶࡵࡨࡶ࡫࡯࡬ࡦࠫ࠽ࠎࠎࠏࡳࡩࡷࡷ࡭ࡱ࠴ࡲ࡮ࡶࡵࡩࡪ࠮ࡵࡴࡧࡵࡪ࡮ࡲࡥࠪࠌࠌࠍࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡃࠠࡕࡴࡸࡩࠏࠏࠣࡪ࡯ࡳࡳࡷࡺࠠࡴࡳ࡯࡭ࡹ࡫࠳ࠋࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡦࡪࡤࡰࡰࡶࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡧࡤࡥࡱࡱࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࠣࡤࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡶࡪࡶ࡯ࡴ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠧࠨࠢ䌂")
	if l1l11llll1l_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l1l11l_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ䌃"))
		time.sleep(1)
	return
def l11lll111l1l_l1_(l1l11lll1l1l_l1_):
	import os
	for root,dirs,files in os.walk(l1l11lll1l1l_l1_,topdown=False):
		for name in files: os.remove(os.path.join(root,name))
	for name in dirs: os.rmdir(os.path.join(root,name))
	return
def l1l111ll11l1_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䌄"),l1l11l_l1_ (u"ࠧࠨ䌅"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䌆"),l1l11l_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧ䌇"))
	l1l111ll1l11_l1_()
	return
def l1l111ll1l1l_l1_():
	#	https://l1ll1l1l11l_l1_.tv/download/849
	#   https://play.l1l11l11l111_l1_.com/l1l111111ll1_l1_/l1l1111ll11l_l1_/l1l1ll1l1l1l_l1_?id=l11l1l11l1_l1_.xbmc.l1ll1l1l11l_l1_
	#	http://l1l11l111ll1_l1_.l1l111l1lll1_l1_.l11lllll1l1l_l1_.l1l11ll1lll1_l1_/l1l111l1l11l_l1_/xbmc/l1l1111111l1_l1_/l11lll11111l_l1_/l1l111l1l1ll_l1_
	#	http://l11llll11lll_l1_.l11lll1l1111_l1_.l1l11ll1lll1_l1_/l1ll1l1l11l_l1_/l1l1111111l1_l1_/l11lll11111l_l1_/l1l111l1l1ll_l1_
	url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨ䌈")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䌉"),url,l1l11l_l1_ (u"ࠬ࠭䌊"),l1l11l_l1_ (u"࠭ࠧ䌋"),l1l11l_l1_ (u"ࠧࠨ䌌"),l1l11l_l1_ (u"ࠨࠩ䌍"),l1l11l_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬ䌎"))
	html = response.content
	l11lll11l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩ䌏"),html,re.DOTALL)
	l11lll11l1ll_l1_ = l11lll11l1ll_l1_[0].split(l1l11l_l1_ (u"ࠫ࠲࠭䌐"))[0]
	l1l11ll1l11l_l1_ = str(kodi_version)
	#l1ll1l11l1l1_l1_ = l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䌑")+l1l11l_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏฿ๅๅ่ࠢ฽้่ࠥะ์ࠣษฺีวาࠢ࠴࠽ࠥ๎ๅศࠢห฽ิํࠧ䌒")+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䌓")
	l1ll1l11l1l1_l1_ = l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪ䌔")+l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䌕")+l11lll11l1ll_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䌖")
	l1ll1l11l1l1_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䌗")+l1l11l_l1_ (u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้๋ࠣํࠦ࠺ࠡࠢࠣࠫ䌘")+l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䌙")+l1l11ll1l11l_l1_+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䌚")
	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䌛"),l1l11l_l1_ (u"ࠩࠪ䌜"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䌝"),l1ll1l11l1l1_l1_)
	return
def l11ll1lll1l1_l1_():
	# https://l1l11ll1llll_l1_-l11lllll111l_l1_-l1l1111l11l1_l1_.l1l111ll1lll_l1_.com/request-l1l1111l1l1l_l1_
	# https://l1l11ll1llll_l1_-l11lllll111l_l1_-l1l1111l11l1_l1_.l1l111ll1lll_l1_.com/query-l11lll11ll1l_l1_
	l1111111ll_l1_,l111111l11_l1_,l1ll1l11l11l_l1_,l1ll1l11l1l1_l1_,l1l111llll11_l1_,l11lll1l1lll_l1_,l11lllllllll_l1_ = l1l11l_l1_ (u"ࠫࠬ䌞"),l1l11l_l1_ (u"ࠬ࠭䌟"),l1l11l_l1_ (u"࠭ࠧ䌠"),l1l11l_l1_ (u"ࠧࠨ䌡"),l1l11l_l1_ (u"ࠨࠩ䌢"),l1l11l_l1_ (u"ࠩࠪ䌣"),l1l11l_l1_ (u"ࠪࠫ䌤")
	payload,l11lll11lll1_l1_,l1l111l1l111_l1_,l11lll1111ll_l1_ = {l1l11l_l1_ (u"ࠫࡦ࠭䌥"):l1l11l_l1_ (u"ࠬࡧࠧ䌦")},{},[],{}
	url = WEBSITES[l1l11l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭䌧")][1]
	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䌨"),url,payload,l1l11l_l1_ (u"ࠨࠩ䌩"),l1l11l_l1_ (u"ࠩࠪ䌪"),l1l11l_l1_ (u"ࠪࠫ䌫"),l1l11l_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩ䌬"))
	html = response.content
	html = html.replace(l1l11l_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬ䌭"),l1l11l_l1_ (u"࠭ࡕࡔࡃࠪ䌮"))
	html = html.replace(l1l11l_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨ䌯"),l1l11l_l1_ (u"ࠨࡗࡎࠫ䌰"))
	html = html.replace(l1l11l_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩ䌱"),l1l11l_l1_ (u"࡙ࠪࡆࡋࠧ䌲"))
	html = html.replace(l1l11l_l1_ (u"ࠫࡘࡧࡵࡥ࡫ࠣࡅࡷࡧࡢࡪࡣࠪ䌳"),l1l11l_l1_ (u"ࠬࡑࡓࡂࠩ䌴"))
	html = html.replace(l1l11l_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ䌵"),l1l11l_l1_ (u"ࠧࡏ࠰ࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ䌶"))
	html = html.replace(l1l11l_l1_ (u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩ䌷"),l1l11l_l1_ (u"࡚ࠩ࠲ࡘࡧࡨࡢࡴࡤࠫ䌸"))
	html = html.replace(l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䌹"),l1l11l_l1_ (u"ࠫࠥࠦࠧ䌺"))
	try: l1l111l11lll_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࠪ䌻"),html)
	except:
		DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䌼"),l1l11l_l1_ (u"ࠧࠨ䌽"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䌾"),l1l11l_l1_ (u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩ䌿"))
		return
	l1l11l1l1l11_l1_,l1l11ll1ll1l_l1_,l1l1111l1111_l1_ = l1l111l11lll_l1_
	l11lll1111ll_l1_ = {}
	for site,l1l11l1lllll_l1_,l1l11l1l11l1_l1_ in l1l11ll1ll1l_l1_:
		l1l11l1l11l1_l1_ = escapeUNICODE(l1l11l1l11l1_l1_)
		l1l11l1l11l1_l1_ = l1l11l1l11l1_l1_.strip(l1l11l_l1_ (u"ࠪࠤࠬ䍀")).strip(l1l11l_l1_ (u"ࠫࠥ࠴ࠧ䍁"))
		l1ll1l11l1l1_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䍂")+site+l1l11l_l1_ (u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䍃")+l1l11l1l11l1_l1_+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䍄")
		if l1l11l1lllll_l1_.isdigit():
			l11lll1111ll_l1_[site] = int(l1l11l1lllll_l1_)
			if int(l1l11l1lllll_l1_)>100: l1l11l1lllll_l1_ = l1l11l_l1_ (u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫ䍅")
			else: l1l11l1lllll_l1_ = l1l11l_l1_ (u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫ䍆")
		if site not in [l1l11l_l1_ (u"ࠪࡅࡑࡒࠧ䍇"),l1l11l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䍈"),l1l11l_l1_ (u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭䍉"),l1l11l_l1_ (u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ䍊"),l1l11l_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭䍋")]:
			if   l1l11l1lllll_l1_==l1l11l_l1_ (u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫ䍌"): l1111111ll_l1_ += l1l11l_l1_ (u"ࠩࠣࠤࠬ䍍")+site
			elif l1l11l1lllll_l1_==l1l11l_l1_ (u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ䍎"): l111111l11_l1_ += l1l11l_l1_ (u"ࠫࠥࠦࠧ䍏")+site
	l1l11lll1l11_l1_,l11llllll1l1_l1_,l1l111111111_l1_ = list(zip(*l1l11ll1ll1l_l1_))
	for site in sorted(SEARCH_SITES_REGULAR):
		if site not in l1l11lll1l11_l1_:
			l1ll1l11l1l1_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䍐")+site+l1l11l_l1_ (u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䍑")+l1l11l_l1_ (u"ࠧๅษࠣ๎ําฯࠨ䍒")+l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䍓")
			if site not in [l1l11l_l1_ (u"ࠩࡄࡐࡑ࠭䍔"),l1l11l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ䍕"),l1l11l_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ䍖"),l1l11l_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ䍗"),l1l11l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ䍘")]: l1ll1l11l11l_l1_ += l1l11l_l1_ (u"ࠧࠡࠢࠪ䍙")+site
	for l1l11l1l11l1_l1_,counts in l1l11l1l1l11_l1_:
		l1l11l1l11l1_l1_ = escapeUNICODE(l1l11l1l11l1_l1_)
		l1l111llll11_l1_ += l1l11l1l11l1_l1_+l1l11l_l1_ (u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䍚")+str(counts)+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧ䍛")
	l1111111ll_l1_ = l1111111ll_l1_.strip(l1l11l_l1_ (u"ࠪࠤࠬ䍜"))
	l111111l11_l1_ = l111111l11_l1_.strip(l1l11l_l1_ (u"ࠫࠥ࠭䍝"))
	l1ll1l11l11l_l1_ = l1ll1l11l11l_l1_.strip(l1l11l_l1_ (u"ࠬࠦࠧ䍞"))
	l1l111lll11l_l1_ = l1111111ll_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠩ䍟")+l111111l11_l1_
	#l1l111lll1l1_l1_  = l1l11l_l1_ (u"ࠧ࡝ࡰࡋ࡭࡬࡮ࡕࡴࡣࡪࡩ࠿࡛ࠦࠡࠩ䍠")+l1111111ll_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫ䍡")
	#l1l111lll1l1_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡑࡵࡷࡖࡵࡤ࡫ࡪࠦ࠺ࠡ࡝ࠣࠫ䍢")+l111111l11_l1_+l1l11l_l1_ (u"ࠪࠤࡢ࠭䍣")
	#l1l111lll1l1_l1_ += l1l11l_l1_ (u"ࠫࡡࡴࡎࡰࡗࡶࡥ࡬࡫ࠠࠡ࠼ࠣ࡟ࠥ࠭䍤")+l1ll1l11l11l_l1_+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ䍥")
	l1ll1l11l1ll_l1_  = l1l11l_l1_ (u"࠭ๅ้ษๅ฽ฺฺࠥๅ่๊ࠢ์อࠠศๆหี๋อๅอࠢํ์๊ࠦวๅสสีาฯࠠโ์า๎ํํวหࠢหำํ์ࠠๆึส็้࠭䍦")+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䍧")+l1l11l_l1_ (u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ่์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั࠭䍨")+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䍩")
	l1ll1l11l1ll_l1_ += l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䍪")+l1l111lll11l_l1_+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪ䍫")
	l1ll1l11l1ll_l1_ += l1l11l_l1_ (u"๋่ࠬศไ฼ࠤ้๋๋ࠠึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ๐่ๆࠢส่ออัฮหࠣว๏ࠦแ๋ัํ์์อสࠨ䍬")+l1l11l_l1_ (u"࠭࡜࡯ࠩ䍭")+l1l11l_l1_ (u"้้ࠧำหู๋ࠥ็ษ๊ࠤฬำสๆษ็ࠤ่ฮ๊า๋ࠢะํีࠠๆึๆ่ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ䍮")+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䍯")
	l1ll1l11l1ll_l1_ += l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䍰")+l1ll1l11l11l_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䍱")
	l1l1l111l1l_l1_,l11llll1ll11_l1_,l1l111l1ll1l_l1_,l11llll11l1l_l1_ = 0,0,0,0
	all = l11lll1111ll_l1_[l1l11l_l1_ (u"ࠫࡆࡒࡌࠨ䍲")]
	if l1l11l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ䍳") in list(l11lll1111ll_l1_.keys()): l1l1l111l1l_l1_ = l11lll1111ll_l1_[l1l11l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭䍴")]
	if l1l11l_l1_ (u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ䍵") in list(l11lll1111ll_l1_.keys()): l11llll1ll11_l1_ = l11lll1111ll_l1_[l1l11l_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ䍶")]
	if l1l11l_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭䍷") in list(l11lll1111ll_l1_.keys()): l1l111l1ll1l_l1_ = l11lll1111ll_l1_[l1l11l_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ䍸")]
	if l1l11l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ䍹") in list(l11lll1111ll_l1_.keys()): l11llll11l1l_l1_ = l11lll1111ll_l1_[l1l11l_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ䍺")]
	videos_count = all-l1l1l111l1l_l1_-l11llll1ll11_l1_-l1l111l1ll1l_l1_-l11llll11l1l_l1_
	dummy,l1l111l111ll_l1_ = l1l1111l1111_l1_[0]
	dummy,l11lll1ll1l1_l1_ = l1l1111l1111_l1_[1]
	l1l11l111lll_l1_ = l1l111l111ll_l1_-l11lll1ll1l1_l1_
	l11lllllllll_l1_ += l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䍻")+str(l11lll1ll1l1_l1_)+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䍼")+l1l11l_l1_ (u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬ䍽")
	l11lllllllll_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䍾")+str(l1l11l111lll_l1_)+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䍿")+l1l11l_l1_ (u"ࠫออำหะาห๊ࠦࡰࡳࡱࡻࡽࠥษ่ࠡࡸࡳࡲࠥࡀࠠࠨ䎀")
	l11lllllllll_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䎁")+str(l1l111l111ll_l1_)+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䎂")+l1l11l_l1_ (u"ࠧศๆ฼ำิࠦวๅๅ็๎๊ࠥฬๆ์฼ࠤฬ๊รอ้ีอࠥࡀࠠࠨ䎃")
	l11lllllllll_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䎄")+str(len(l1l1111l1111_l1_[2:]))+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䎅")+l1l11l_l1_ (u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨ䎆")
	for country,l1111l1ll11_l1_ in l1l1111l1111_l1_[2:]:
		country = escapeUNICODE(country)
		country = country.strip(l1l11l_l1_ (u"ࠫࠥ࠭䎇")).strip(l1l11l_l1_ (u"ࠬࠦ࠮ࠨ䎈"))
		l11lllllllll_l1_ += country+l1l11l_l1_ (u"࠭࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䎉")+str(l1111l1ll11_l1_)+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠬ䎊")
	#l11lllllllll_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱ࠲ࠬ䎋")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䎌")+str(videos_count)+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䎍")+l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩ䎎")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䎏")+str(l1l1l111l1l_l1_)+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䎐")+l1l11l_l1_ (u"ุࠧๆหหฯࠦำ๋ำไีࠥฮว๋อ๋๊ࠥࡀࠠࠨ䎑")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䎒")+str(l11llll11l1l_l1_)+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䎓")+l1l11l_l1_ (u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็้ำอา็ࠢ࠽ࠤࠬ䎔")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䎕")+str(l11llll1ll11_l1_)+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䎖")+l1l11l_l1_ (u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪ䎗")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䎘")+str(l1l111l1ll1l_l1_)+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䎙")+l1l11l_l1_ (u"ࠩอฯอ๐สࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥࡀࠠࠨ䎚")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䎛")+str(len(l1l11l1l1l11_l1_))+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䎜")+l1l11l_l1_ (u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬ䎝")
	#l11lll1l1lll_l1_ += l1l11l_l1_ (u"࠭࡜࡯࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䎞")+l1l11l_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠศๆ฼ห้๋๋๊่ࠠࠤศ๋ำࠡࠪส่ออัฮหࠬࠫ䎟")+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䎠")
	l11lll1l1lll_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䎡")+l1l111llll11_l1_
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䎢"),l1l11l_l1_ (u"ࠫ฾ีฯࠡษ็วัําสࠢส่ฯ๐ࠠศีอาิ๋ส้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣห้฿วๅ็ࠣ๎ํ๋ࠠฤ็ึࠤ࠭อไษษิัฮ࠯ࠧ䎣"),l11lllllllll_l1_,l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ䎤"))
	#l1ll1lll11_l1_(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䎥"),l1l11l_l1_ (u"ࠧอ็ํ฽ࠥํะ่ࠢส่ศืโศ็ࠣฮำ฻ࠠฤีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠࠡใๅ฻ࠥ๐่ๆࠢฦุ้ࠦࠨศๆหหึำษࠪࠩ䎦"),l11lll1l1lll_l1_,l1l11l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ䎧"))
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䎨"),l1l11l_l1_ (u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢื฾้ํว้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣห้฿วๅ็ࠣ๎ํ๋ࠠฤ็ึࠤ࠭อไษษิัฮ࠯ࠧ䎩"),l11lll1l1lll_l1_,l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ䎪"))
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䎫"),l1l11l_l1_ (u"࠭ๅ้ษๅ฽ࠥอิห฼็ฮࠥ๐่ๆࠢส่ออัฮหࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠨ䎬"),l1ll1l11l1ll_l1_,l1l11l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ䎭"))
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭䎮"),l1l11l_l1_ (u"ࠩฦ฽้๏ࠠศๆา์้ࠦวๅฬํࠤ๏๎ๅࠡษ็ฬฬือสࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬ䎯"),l1ll1l11l1l1_l1_,l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ䎰"))
	return
def l11lll1lllll_l1_():
	message = l1l11l_l1_ (u"ࠫ์ึวࠡษ็ฬึ์วๆฮࠣ๎฾๋ไࠡษไฺ้ࠦศศีอาิอๅࠡฮ็ำ้่ࠥะ์ࠣࠬࡐࡵࡤࡪࠢࡖ࡯࡮ࡴࠩࠡษ็ิ๏ࠦวิ็๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࡠࡳ่ࠦๆ็ๆ๊ࠥะหษ์อ๋ࠥฮวิฬัำฬ๋ࠠๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮้ࠡำ๋ࠥอไาีส่ฮ่ࠦ฻์ิ๋ฬࠦใฬ์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า้ࠠษ็้ื๐ฯࠡลํฺฬࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠฤฮ๋ฬฮࠦวๅสิ๊ฬ๋ฬࠨ䎱")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䎲"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䎳"),message,l1l11l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ䎴"))
	return
def l111ll1llll_l1_():
	message = l1l11l_l1_ (u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆะี๊ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫ䎵")+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䎶")+l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䎷")+WEBSITES[l1l11l_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ䎸")][0]+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠣࠤࠥษ่ࠡࠢࠣࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䎹")+WEBSITES[l1l11l_l1_ (u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ䎺")][1]+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䎻")
	message += l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳࡢ࡮ศๆิหอ฽๊็ࠢฦำ๋อ็้่ࠡหࠥอไิ๊ิืࠥอไั์ࠣ๎าะวอ้้ࠣิ๐ัࠡ็็ๅฬะࠠไ๊า๎๊ࠥสฬสํฮࠥฮั็ษ่ะࠥ฿ๅศัࠣฬฬ๊ืา์ๅอࠥอไหไ็๎ิ๐ษࠡษ็ๆิ๐ๅส࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䎼")+WEBSITES[l1l11l_l1_ (u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪ䎽")][0]+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠡࠢࠣวํࠦࠠࠡࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䎾")+WEBSITES[l1l11l_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ䎿")][1]+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䏀")
	message += l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩ䏁")+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䏂")+l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ䏃")+WEBSITES[l1l11l_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ䏄")][0]+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䏅")
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䏆"),l1l11l_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫ䏇"),message,l1l11l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ䏈"))
	return
def l1l11l1l11ll_l1_(l1l11l1l1ll1_l1_):
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭䏉")+l1l11l1l1ll1_l1_+l1l11l_l1_ (u"ࠨࠫࠪ䏊"), True)
	return
def l1l11l11ll11_l1_():
	l1lllll1l_l1_(l1l11l_l1_ (u"ࠩࡶࡸࡴࡶࠧ䏋"))
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤ䏌"))
	return
def l1l11111llll_l1_():
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪ䏍"), True)
	return
def l1l111lll1ll_l1_(showDialogs=True):
	if not showDialogs: yes = True
	else: yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䏎"),l1l11l_l1_ (u"࠭ࠧ䏏"),l1l11l_l1_ (u"ࠧࠨ䏐"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䏑"),l1l11l_l1_ (u"ࠩหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥฮูๆๆํอࠥะอะ์ฮࠤัฺ๋๊ࠢส่ส฼วโษอࠤฯ๊โศศํห้ࠥไࠡ࠴࠷ࠤุอูส๋่่ࠢ์ࠠๆ็ๆ๊ࠥหฬาษฤ๋ฬࠦวๅฤ้ࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢส่ว์ࠠภࠩ䏒"))
	if yes==1:
		xbmc.executebuiltin(l1l11l_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡄࡨࡩࡵ࡮ࡓࡧࡳࡳࡸ࠭䏓"))
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䏔"),l1l11l_l1_ (u"ࠬ࠭䏕"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䏖"),l1l11l_l1_ (u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ัึู๋ࠦๆษาࠤ࠳๊ࠦาฮ์ࠤส฿ืศรࠣ็ํี๊ࠡ࠷ࠣำ็อฦใࠢฦ์ࠥษใฬำ่่ࠣ๐๋่๊ࠠ๎ࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠬ䏗"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䏘"))
	l1111l11111_l1_ = (not yes)
	return l1111l11111_l1_
def l11lll11ll11_l1_():
	DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䏙"),l1l11l_l1_ (u"ࠪࠫ䏚"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䏛"),l1l11l_l1_ (u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠧ䏜"))
	return
def l1l11l11l1ll_l1_():
	DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䏝"),l1l11l_l1_ (u"ࠧࠨ䏞"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䏟"),l1l11l_l1_ (u"ࠩ็่ฯ฿วๆๆ้ࠣ฾ࠦวๅ็ไฺ้ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢอี๏ีࠠฦุสๅฯํࠠฤุ๊้ࠣำ็ࠡ็้ࠤ่ࠥวว็ฬࠤฬ๊ๅโุ็อࠥ๎ไไ่่ࠣฬࠦสื฼ฺࠤ฾๊๊่๋่ࠢฬࠦสี฼็๋ࠥ࠴้ࠠสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์ศ๋วࠡสสืฯิฯศ็ࠣࠦฬ๊ใ๋ส๋ีิࠨࠠโษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์๋็ำࠡษ็็้อๅ๊ࠡส่฼ื๊ใหࠣ฽๋ีࠠศๆอ฽ฬ๋ไࠡ็฼ࠤ๊ำส้์สฮ่่ࠥศศ่ࠤฬ๊ๅโุ็อࠬ䏠"))
	return
#l11lll111l11_l1_ 	  required	and l11lll111l11_l1_     installed	and		not l1111l11111_l1_		ignore
#l11lll111l11_l1_ not required	and	l11lll111l11_l1_ not installed 	and 	    l1111l11111_l1_		ignore
#l11lll111l11_l1_ not required	and	l11lll111l11_l1_ not installed 	and 	not l1111l11111_l1_		ignore
#l11lll111l11_l1_ not required	and	l11lll111l11_l1_     installed 	and 	not l1111l11111_l1_		ignore
#l11lll111l11_l1_     required	and	l11lll111l11_l1_ not installed 	and 	    l1111l11111_l1_		l11lllll11_l1_ l11llll1ll11_l1_	l1l111llll1l_l1_
#l11lll111l11_l1_     required	and	l11lll111l11_l1_ not installed 	and 	not l1111l11111_l1_		l11lllll11_l1_ l11llll1ll11_l1_	l1l111llll1l_l1_
#l11lll111l11_l1_     required 	and l11lll111l11_l1_     installed 	and 	    l1111l11111_l1_		l11lllll11_l1_ l1l11ll1l111_l1_	l1l111llll1l_l1_
#l11lll111l11_l1_ not required	and	l11lll111l11_l1_     installed 	and 	    l1111l11111_l1_		l11lllll11_l1_ l1l11ll1l111_l1_	l1l111llll1l_l1_
#cond1: required and not installed: l11lllll11_l1_ l11llll1ll11_l1_
#cond2: installed and l11lllll11_l1_ update: l11lllll11_l1_ l1l11ll1l111_l1_
def l111ll11lll_l1_(showDialogs=True):
	l11ll1lllll1_l1_ = False
	l111l11111l_l1_ = l11lllll111_l1_([l1l11l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ䏡")])
	for addon_id in [l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭䏢")]:
		if addon_id not in list(l111l11111l_l1_.keys()): continue
		l1111l11111_l1_,l11ll1l1l1l_l1_,l1l11l111l1l_l1_,l1l11l111l11_l1_,l1l11l11111l_l1_,l11lll1l11l1_l1_,l1l11l1111l1_l1_ = l111l11111l_l1_[addon_id]
		if not l11ll1l1l1l_l1_ or (l11ll1l1l1l_l1_ and l1111l11111_l1_):
			l11ll1lllll1_l1_ = True
			break
	#import sqlite3
	conn = sqlite3.connect(l111llll1ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1l11111l1l1_l1_ = False
	for addon_id in l1lll11111l_l1_:
		cc.execute(l1l11l_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࠦ࠶ࠨࠠࡢࡰࡧࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ䏣")+addon_id+l1l11l_l1_ (u"࠭ࠢࠡ࠽ࠪ䏤"))
		rows = cc.fetchall()
		if rows:
			l1l11111l1l1_l1_ = True
			break
	l11llll1llll_l1_ = False
	for addon_id in l1l11l1l1l1_l1_:
		cc.execute(l1l11l_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ䏥")+addon_id+l1l11l_l1_ (u"ࠨࠤࠣ࠿ࠬ䏦"))
		l1l11lll1ll1_l1_ = cc.fetchall()
		if l1l11lll1ll1_l1_ and l1l11l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ䏧") not in str(l1l11lll1ll1_l1_):
			l11llll1llll_l1_ = True
			break
	conn.commit()
	conn.close()
	#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ䏨"),l1l11l_l1_ (u"ࠫࡳ࡫ࡥࡥࡡࡩ࡭ࡽ࡯࡮ࡨࡡࡵࡩࡵࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯࠼ࠣࠤࠬ䏩")+str(l11ll1lllll1_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭䏪"),l1l11l_l1_ (u"࠭࡮ࡦࡧࡧࡣࡩ࡫࡬ࡦࡶ࡬ࡲ࡬ࡥ࡯࡭ࡦࡢࡥࡩࡪ࡯࡯ࡵ࠽ࠤࠥ࠭䏫")+str(l1l11111l1l1_l1_))
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ䏬"),l1l11l_l1_ (u"ࠨࡰࡨࡩࡩࡥࡦࡪࡺ࡬ࡲ࡬ࡥ࡯ࡳ࡫ࡪ࡭ࡳࡀࠠࠡࠩ䏭")+str(l11llll1llll_l1_))
	l1111l11111_l1_ = False
	if l11ll1lllll1_l1_ or l1l11111l1l1_l1_ or l11llll1llll_l1_:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䏮"),l1l11l_l1_ (u"ࠪࠫ䏯"),l1l11l_l1_ (u"ࠫࠬ䏰"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䏱"),l1l11l_l1_ (u"࠭วๅสิ๊ฬ๋ฬ๊ࠡฯำ๋ࠥิไๆฬࠤๆ๐ࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯࠰࠱ࠤ็ี๋ࠠๅูุ๋๊๋ࠥๆࠣวํࠦไศࠢํ฽๊๊ࠠษื๋ีฮࠦีฮ์ะอࠥࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋้ࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡษ็ฦ๋ࠦฟ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䏲"))
		if yes==1:
			l1l11ll111l1_l1_ = True
			if l11ll1lllll1_l1_:
				l1l11ll111l1_l1_ = l1l11ll1l1l1_l1_(False)
			l1l1111111ll_l1_ = True
			if l1l11111l1l1_l1_:
				for addon_id in l1lll11111l_l1_: l1l11111ll1l_l1_(addon_id)
				l1l1111111ll_l1_ = True
			l11llll11l11_l1_ = True
			if l11llll1llll_l1_ or l11ll1lllll1_l1_:
				conn = sqlite3.connect(l111llll1ll_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1l11l1l1l1_l1_:
					l1l11lll1ll1_l1_ = l1l11l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ䏳")
					if l1l11l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫ䏴") in addon_id: l1l11lll1ll1_l1_ = addon_id
					try: cc.execute(l1l11l_l1_ (u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭䏵")+l1l11lll1ll1_l1_+l1l11l_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ䏶")+addon_id+l1l11l_l1_ (u"ࠫࠧࠦ࠻ࠨ䏷"))
					except: l11llll11l11_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l1l11l_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ䏸"))
			time.sleep(1)
			if l1l11ll111l1_l1_ or l1l1111111ll_l1_ or l11llll11l11_l1_:
				l1111l11111_l1_ = False
				DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䏹"),l1l11l_l1_ (u"ࠧࠨ䏺"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䏻"),l1l11l_l1_ (u"ࠩอ้ฯࠦศ็ฮสัࠥ฿ๅๅ์ฬࠤฯ็ู๋ๆࠣ์ส฻ไศฯࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไอ็ํ฽ࠥหึศใสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ䏼"))
			else:
				l1111l11111_l1_ = True
				DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䏽"),l1l11l_l1_ (u"ࠫࠬ䏾"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䏿"),l1l11l_l1_ (u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ䐀"))
	elif showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䐁"),l1l11l_l1_ (u"ࠨࠩ䐂"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䐃"),l1l11l_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥิไๆฬࠤๆ๐ࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩ䐄"))
	return l1111l11111_l1_
def l11llll1ll1l_l1_():
	l1l111111lll_l1_,l1l111l1ll11_l1_,l1l111lllll1_l1_ = False,l1l11l_l1_ (u"ࠫࠬ䐅"),l1l11l_l1_ (u"ࠬ࠭䐆")
	l1l11l1ll1l1_l1_,l1l1111l1lll_l1_,l1l111l111l1_l1_ = False,l1l11l_l1_ (u"࠭ࠧ䐇"),l1l11l_l1_ (u"ࠧࠨ䐈")
	l111l11111l_l1_ = l11lllll111_l1_([l1l11l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭䐉"),l1l11l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ䐊"),l1l11l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ䐋")])
	for addon_id in [l1l11l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ䐌"),l1l11l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ䐍"),l1l11l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ䐎")]:
		if addon_id not in list(l111l11111l_l1_.keys()): continue
		l1111l11111_l1_,l11ll1l1l1l_l1_,l1l1l1ll1l1_l1_,l1ll1l1111l_l1_,l1ll1llll1l_l1_,l1ll11lllll_l1_,l11111llll1_l1_ = l111l11111l_l1_[addon_id]
		if addon_id==l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ䐏"):
			l1l11l1ll1l1_l1_ = l1111l11111_l1_
			l1l1111l1lll_l1_ = l1l11l_l1_ (u"ࠨࠪࠪ䐐")+l11ll1l1l1l_l1_+l1l11l_l1_ (u"ࠩࠣࠫ䐑")+TRANSLATE(l1ll11lllll_l1_)+l1l11l_l1_ (u"ࠪ࠭ࠬ䐒")
			l1l111l111l1_l1_ = l1ll1l1111l_l1_
		elif addon_id==l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭䐓"):
			l1l111111lll_l1_ = l1l111111lll_l1_ or l1111l11111_l1_
			l1l111l1ll11_l1_ += l1l11l_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠬࠬ䐔")+l11ll1l1l1l_l1_+l1l11l_l1_ (u"࠭ࠠࠨ䐕")+TRANSLATE(l1ll11lllll_l1_)+l1l11l_l1_ (u"ࠧࠪࠩ䐖")
			l1l111lllll1_l1_ += l1l11l_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ䐗")+l1ll1l1111l_l1_
		elif addon_id==l1l11l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ䐘"):
			l1l111111l1l_l1_ = l1111l11111_l1_
			l11lllllll11_l1_ = l1l11l_l1_ (u"ࠪࠬࠬ䐙")+l11ll1l1l1l_l1_+l1l11l_l1_ (u"ࠫࠥ࠭䐚")+TRANSLATE(l1ll11lllll_l1_)+l1l11l_l1_ (u"ࠬ࠯ࠧ䐛")
			l11lll111111_l1_ = l1ll1l1111l_l1_
	l1l111l1ll11_l1_ = l1l111l1ll11_l1_.strip(l1l11l_l1_ (u"࠭ࠠࠡ࠮ࠣࠤࠬ䐜"))
	l1l111lllll1_l1_ = l1l111lllll1_l1_.strip(l1l11l_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭䐝"))
	text1  = l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䐞")+l1l111l111l1_l1_+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐟")
	text1 += l1l11l_l1_ (u"ࠪࡠࡳ࠭䐠")+l1l11l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไษำ้ห๊าฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䐡")+l1l1111l1lll_l1_+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䐢")
	text1 += l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࠫ䐣")+l1l11l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆะี๊ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䐤")+l1l111lllll1_l1_+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䐥")
	text1 += l1l11l_l1_ (u"ࠩ࡟ࡲࠬ䐦")+l1l11l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥๅฯิ้ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䐧")+l1l111l1ll11_l1_+l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䐨")
	text1 += l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䐩")+l1l11l_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䐪")+l11lll111111_l1_+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䐫")
	text1 += l1l11l_l1_ (u"ࠨ࡞ࡱࠫ䐬")+l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䐭")+l11lllllll11_l1_+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䐮")
	l1111l11111_l1_ = (l1l11l1ll1l1_l1_ or l1l111111lll_l1_)
	if l1111l11111_l1_:
		header = l1l11l_l1_ (u"ࠫฬ๊ัอษฤࠤฯำฯ๋อࠣษ฻อแศฬࠣ็ํี๊ࠡๆะ่ࠥอไๆึส็้࠭䐯")
		text2 = l1l11l_l1_ (u"ࠬอๆหࠢหัฬาษࠡๆอัิ๐หࠡสิ๊ฬ๋ฬࠡ฻่หิࠦร้ࠢอัิ๐หࠡ็ัึู๋ࠦๆษาࠫ䐰")
	else:
		header = l1l11l_l1_ (u"࠭อศๆํห๊ࠥวࠡ์๋ะิࠦสฮัํฯฬะࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦร้่ࠢาื์ฺࠠ็สำࠬ䐱")
		text2 = l1l11l_l1_ (u"ࠧศๆิะฬวࠠฦส็ห฿ࠦวๅ็หี๊าฺ่ࠠࠣห้๋ิไๆฬࠤฬ๊ส๋ࠢอ์ฬา็ไࠩ䐲")
	text3 = l1l11l_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆࠣ฽๋ีใࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ๏าศࠡล้ࠤ๏้่็ࠢ็ำ๏้ࠠโ์ࠣ็ํี๊࡝ࡰ่าื์ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧ䐳")
	l11llllll1ll_l1_ = text1+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䐴")+text2+l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䐵")+text3
	l1ll1lll11_l1_(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ䐶"),header,l11llllll1ll_l1_,l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ䐷"))
	return
def l11ll1111ll_l1_(showDialogs=True,l11lllll11l1_l1_=True):
	#DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ䐸"),l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࡤࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭䐹"))
	DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭䐺"),l1l11l_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ䐻"))
	if showDialogs:
		l11llll1ll1l_l1_()
		l1l111ll1l1l_l1_()
	if l11lllll11l1_l1_:
		l11lll1lll1l_l1_ = l111ll11lll_l1_(False)
		l11lll1lll11_l1_ = l1l111lll1ll_l1_(showDialogs)
		if not (l11lll1lll1l_l1_ or l11lll1lll11_l1_): xbmc.executebuiltin(l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䐼"))
	return
def l1l11ll1l1l1_l1_(showDialogs=True):
	l111l11111l_l1_ = l11lllll111_l1_([l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭䐽")])
	yes,l1l11l1lll11_l1_,l11llll1111l_l1_ = True,True,True
	for addon_id in [l1l11l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ䐾")]:
		l1111l11111_l1_,l11ll1l1l1l_l1_,l1l1l1ll1l1_l1_,l1ll1l1111l_l1_,l1ll1llll1l_l1_,l1ll11lllll_l1_,l11111llll1_l1_ = l111l11111l_l1_[addon_id]
		if l1111l11111_l1_:
			l1l11l1lll11_l1_ = False
			break
	if l1l11l1lll11_l1_:
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䐿"),l1l11l_l1_ (u"ࠧࠨ䑀"),l1l11l_l1_ (u"ࠨใะู๋ࠥฮำ่ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ䑁"),l1l11l_l1_ (u"่ࠩาื์ฺࠠ็สำ๋่ࠥอ๊าࠤ฾์ฯไ๋้ࠢๆ฿ไ๊ࠡฯห์ุࠠๅๆสืฯิฯศ็ࠪ䑂"))
		return
	if showDialogs:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䑃"),l1l11l_l1_ (u"ࠫࠬ䑄"),l1l11l_l1_ (u"ࠬ࠭䑅"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䑆"),l1l11l_l1_ (u"ࠧๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࡡࡴࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢๅำ๏๋ࠠฤ๊้ࠣๆ่่ะࠢฦ์๋ࠥส้ไไࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢศู้ออࠡษ็ู้้ไสࠢส่ว์ࠠภࠩ䑇"))
		if yes!=1: return
	if yes==1:
		for addon_id in [l1l11l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ䑈")]:
			if addon_id not in list(l111l11111l_l1_.keys()): continue
			l1111l11111_l1_,l11ll1l1l1l_l1_,l1l1l1ll1l1_l1_,l1ll1l1111l_l1_,l1ll1llll1l_l1_,l1ll11lllll_l1_,l11111llll1_l1_ = l111l11111l_l1_[addon_id]
			succeeded = l11llllll111_l1_(addon_id,l11111llll1_l1_,showDialogs)
			l11llll1111l_l1_ = l11llll1111l_l1_ and succeeded
	if showDialogs:
		if l11llll1111l_l1_: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䑉"),l1l11l_l1_ (u"ࠪࠫ䑊"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䑋"),l1l11l_l1_ (u"ࠬะๅࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠ࡝ࡰ้ࠣำุๆࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨ䑌"))
		else: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䑍"),l1l11l_l1_ (u"ࠧࠨ䑎"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䑏"),l1l11l_l1_ (u"ࠩ็่ศูแࠡๆ่ࠤ๏ะๅไ่ࠣห้ฮั็ษ่ะ๋ࠥๆࠡวุ่ฬำࠠๆึๆ่ฮࡢ࡮ࠡ็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭䑐"))
	return l11llll1111l_l1_
	#xbmc.executebuiltin(l1l11l_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ䑑")+sys.argv[0]+l1l11l_l1_ (u"ࠫࡄࡳ࡯ࡥࡧࡀ࠶࠻࠶ࠧ䑒")+l1l11l_l1_ (u"ࠧ࠯ࠢ䑓"))
	#xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䑔"))
def l11llllll111_l1_(addon_id,l11111llll1_l1_,showDialogs=True):
	succeeded = False
	if showDialogs:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࠨ䑕"),l1l11l_l1_ (u"ࠨࠩ䑖"),l1l11l_l1_ (u"ࠩࠪ䑗"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䑘"),l1l11l_l1_ (u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ู฾ํ฽ࠠๅๆศฺฬ็ษࠡษ็้฼๊่ษห่่ࠣ๐๋ࠠฬ่ࠤฯัศ๋ฬ๊ࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮ࠡษ็้้็ࠠใัࠣ๎่๎ๆࠡๅห๎ึ่ࠦใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅฤ้ࠤฤࠧࠧ䑙"))
		if yes!=1: return False
	l11lll11l11l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11111llll1_l1_)
	if l11lll11l11l_l1_:
		import zipfile,io
		l1l1111l1ll1_l1_ = io.BytesIO(l11lll11l11l_l1_)
		zf = zipfile.ZipFile(l1l1111l1ll1_l1_)
		zf.extractall(l1l1111l1l1_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l1l11l_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ䑚"))
		time.sleep(1)
		result = xbmc.executeJSONRPC(l1l11l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ䑛")+addon_id+l1l11l_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ䑜"))
		if l1l11l_l1_ (u"ࠨࡑࡎࠫ䑝") in result: succeeded = True
		DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧ䑞"),l1l11l_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ䑟"))
	if showDialogs:
		if succeeded: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䑠"),l1l11l_l1_ (u"ࠬ࠭䑡"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䑢"),l1l11l_l1_ (u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ䑣"))
		else: DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䑤"),l1l11l_l1_ (u"ࠩࠪ䑥"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䑦"),l1l11l_l1_ (u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ䑧"))
	return succeeded
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࡩ࡯࡯ࡰࠣࡁࠥࡹࡱ࡭࡫ࡷࡩ࠸࠴ࡣࡰࡰࡱࡩࡨࡺࠨࡢࡦࡧࡳࡳࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࡦࡳࡳࡴ࠮ࡵࡧࡻࡸࡤ࡬ࡡࡤࡶࡲࡶࡾࠦ࠽ࠡࡵࡷࡶࠏࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦ࡙ࠪࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࡚ࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠬ࠯ࠊࠊࡥࡲࡲࡳ࠴ࡣࡰ࡯ࡰ࡭ࡹ࠮ࠩࠋࠋࡦࡳࡳࡴ࠮ࡤ࡮ࡲࡷࡪ࠮ࠩࠋࠋࠥࠦࠧ䑨")
def l1ll11ll1l1_l1_(addon_id,showDialogs=True):
	if showDialogs==l1l11l_l1_ (u"࠭ࠧ䑩"): showDialogs = True
	#l11lll11ll1_l1_ = xbmc.getCondVisibility(l1l11l_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠪ䑪")+addon_id+l1l11l_l1_ (u"ࠨࠫࠪ䑫"))
	l1ll1l11l1l_l1_ = l11l11ll1l1_l1_([addon_id])
	l1ll111ll11_l1_,l11lll11ll1_l1_ = l1ll1l11l1l_l1_[addon_id]
	if l11lll11ll1_l1_:
		succeeded = True
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䑬"),l1l11l_l1_ (u"ࠪࠫ䑭"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䑮"),l1l11l_l1_ (u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧ䑯")+addon_id+l1l11l_l1_ (u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩ䑰"))
	else:
		succeeded = False
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䑱"),l1l11l_l1_ (u"ࠨࠩ䑲"),l1l11l_l1_ (u"ࠩࠪ䑳"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䑴"),l1l11l_l1_ (u"ࠫࠬ䑵")+addon_id+l1l11l_l1_ (u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪ䑶"))
		if yes==1:
			xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭䑷")+addon_id+l1l11l_l1_ (u"ࠧࠪࠩ䑸"))
			time.sleep(1)
			xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ䑹"))
			time.sleep(1)
			while xbmc.getCondVisibility(l1l11l_l1_ (u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭䑺")): time.sleep(1)
			result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭䑻")+addon_id+l1l11l_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ䑼"))
			if l1l11l_l1_ (u"ࠬࡕࡋࠨ䑽") in result:
				succeeded = True
				if showDialogs: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䑾"),l1l11l_l1_ (u"ࠧࠨ䑿"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䒀"),l1l11l_l1_ (u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨ䒁"))
			elif showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䒂"),l1l11l_l1_ (u"ࠫࠬ䒃"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䒄"),l1l11l_l1_ (u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨ䒅"))
	return succeeded
def l11llll1l11l_l1_(addon_id,showDialogs=True):
	l111l11111l_l1_ = l11lllll111_l1_([addon_id])
	if addon_id not in list(l111l11111l_l1_.keys()): return False
	l1111l11111_l1_,l11ll1l1l1l_l1_,l1l1l1ll1l1_l1_,l1ll1l1111l_l1_,l1ll1llll1l_l1_,l1ll11lllll_l1_,l11111llll1_l1_ = l111l11111l_l1_[addon_id]
	succeeded,l1l111llllll_l1_ = False,l1l11l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䒆")
	if l1ll11lllll_l1_==l1l11l_l1_ (u"ࠨࡩࡲࡳࡩ࠭䒇"):
		succeeded = True
		l1l111llllll_l1_ = l1l11l_l1_ (u"ࠩࡪࡳࡴࡪࠧ䒈")
	elif l1ll11lllll_l1_==l1l11l_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ䒉"):
		succeeded = False
		result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ䒊")+addon_id+l1l11l_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ䒋"))
		if l1l11l_l1_ (u"࠭ࡏࡌࠩ䒌") in result: succeeded = True
		if succeeded: l1l111llllll_l1_ = l1l11l_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨ䒍")
	elif l1ll11lllll_l1_==l1l11l_l1_ (u"ࠨࡱ࡯ࡨࠬ䒎"):
		succeeded = l11llllll111_l1_(addon_id,l11111llll1_l1_,showDialogs)
		if succeeded: l1l111llllll_l1_ = l1l11l_l1_ (u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪ䒏")
	elif l1ll11lllll_l1_==l1l11l_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ䒐"):
		l11lll111lll_l1_ = l1l11ll1l1l1_l1_(showDialogs)
		if l11lll111lll_l1_:
			succeeded = l1ll11ll1l1_l1_(addon_id,showDialogs)
			if succeeded: l1l111llllll_l1_ = l1l11l_l1_ (u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧ䒑")
	l11lll1l1l1l_l1_ = l1ll1l1111l_l1_
	return succeeded,l1l111llllll_l1_,l11lll1l1l1l_l1_
def l1l111l1llll_l1_(l1l11l11lll1_l1_=l1l11l_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ䒒"),showDialogs=True):
	l11lll1l11ll_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ䒓"))
	import json
	data = json.loads(l11lll1l11ll_l1_)
	l11lll1l111l_l1_ = data[l1l11l_l1_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ䒔")][l1l11l_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ䒕")]
	if kodi_version<19: l11lll1l111l_l1_ = l11lll1l111l_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䒖"))
	if showDialogs:
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ䒗"),l1l11l_l1_ (u"ࠫࠬ䒘"),l1l11l_l1_ (u"ࠬ࠭䒙"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䒚"),l1l11l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠอๆาࠤࠬ䒛")+l11lll1l111l_l1_+l1l11l_l1_ (u"ࠨࠢส่ี๐ࠠๆีอาิ๋ࠠศๆล๊ࠥ็๊ࠡๅ๋ำ๏ࠦลๅ๋ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะࠢࠪ䒜")+l1l11l11lll1_l1_+l1l11l_l1_ (u"ࠩࠣรࠦ࠭䒝"))
		if yes!=1: return False
	succeeded,l1l111llllll_l1_,l11lll1l1l1l_l1_ = l11llll1l11l_l1_(l1l11l11lll1_l1_,False)
	if succeeded:
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䒞"),l1l11l_l1_ (u"ࠫࠬ䒟"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䒠"),l1l11l_l1_ (u"࠭สๆฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ะ้ีࠠศๆฯำ๏ี้้๋ࠠࠤัอ็ำࠢ็่ฬูสฯัส้ࠥ࠴ࠠิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦส฻์ํีࠥหูะษาหฯࠦใ้ัํࠤ้้๊ࠡ์ึฮ฾๋ไࠡษ็ะ้ีࠠศๆฯำ๏ีࠠษั็ห๋ࠥๆࠡษ็ๆิ๐ๅࠨ䒡"))
		result = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠥࠫ䒢")+l1l11l11lll1_l1_+l1l11l_l1_ (u"ࠨࠤࢀࢁࠬ䒣"))
		if l1l11l_l1_ (u"ࠩࡒࡏࠬ䒤") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ䒥"))
	elif showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ䒦"),l1l11l_l1_ (u"ࠬ࠭䒧"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䒨"),l1l11l_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩ䒩"))
	return succeeded
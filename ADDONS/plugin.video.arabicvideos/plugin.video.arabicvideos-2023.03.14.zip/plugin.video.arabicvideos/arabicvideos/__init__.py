# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
l1l11l1l111_l1_ = xbmcaddon.Addon().getAddonInfo(l1l11l_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ卬"))
l11l1l11l1l1_l1_ = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩ卭"))
sys.path.append(l11l1l11l1l1_l1_)
#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ卮"),str(sys.path))
LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ卯"),l1l11l_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠨ印"))
l1lllll1l_l1_(l1l11l_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ危"))
try: l1l11111lll_l1_()
except Exception as error: l1l1ll1llll_l1_(error)
l1lllll1l_l1_(l1l11l_l1_ (u"ࠬࡹࡴࡰࡲࠪ卲"))
l1l11l1ll111_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ即"))
l11lll1l11ll_l1_ = xbmc.executeJSONRPC(l1l11l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ却"))
if l1l11l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ卵") in str(l11lll1l11ll_l1_) and l1l11l1ll111_l1_ in [l1l11l_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ卶"),l1l11l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ卷")]:
	#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠫࠬ卸"),l1l11l1ll111_l1_)
	time.sleep(0.100)
	xbmc.executebuiltin(l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩ卹"))
#l11l1l11ll11_l1_ = sys.version_info[0]
#l11l1l11l11l_l1_ = sys.version_info[1]
#if l11l1l11ll11_l1_==2: python_version = l1l11l_l1_ (u"࠭࠲࠸ࠩ卺")
#else: python_version = str(l11l1l11ll11_l1_)+str(l11l1l11l11l_l1_)
#l11l1l11l1ll_l1_ = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ卻")+python_version)
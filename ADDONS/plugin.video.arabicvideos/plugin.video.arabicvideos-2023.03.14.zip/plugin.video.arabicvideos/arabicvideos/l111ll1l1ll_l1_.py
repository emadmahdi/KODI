# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗࠬ㔥")
menu_name = l1l11l_l1_ (u"ࠬࡥࡌࡔࡖࡢࠫ㔦")
l1lllll11l1l_l1_ = 5
l1llll1ll1ll_l1_ = 10
def MAIN(mode,url,text,page):
	if   mode==160: results = MENU()
	elif mode==161: results = l1llllll11l1_l1_(text)
	elif mode==162: results = l1llll11llll_l1_(text,162)
	elif mode==163: results = l1llll11llll_l1_(text,163)
	elif mode==164: results = l1lllll1l1l1_l1_(text)
	elif mode==165: results = l1lllll11l11_l1_(text,page)
	elif mode==166: results = l1llll111l11_l1_(url,text)
	elif mode==167: results = l1llll111ll1_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㔧"),l1l11l_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์ฺࠠึ๋หห๐ษࠨ㔨"),l1l11l_l1_ (u"ࠨࠩ㔩"),161,l1l11l_l1_ (u"ࠩࠪ㔪"),l1l11l_l1_ (u"ࠪࠫ㔫"),l1l11l_l1_ (u"ࠫࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㔬"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔭"),l1l11l_l1_ (u"࠭โิ็ࠣ฽ู๎วว์ࠪ㔮"),l1l11l_l1_ (u"ࠧࠨ㔯"),162,l1l11l_l1_ (u"ࠨࠩ㔰"),l1l11l_l1_ (u"ࠩࠪ㔱"),l1l11l_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㔲"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㔳"),l1l11l_l1_ (u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠨ㔴"),l1l11l_l1_ (u"࠭ࠧ㔵"),163,l1l11l_l1_ (u"ࠧࠨ㔶"),l1l11l_l1_ (u"ࠨࠩ㔷"),l1l11l_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㔸"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㔹"),l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์ࠪ㔺"),l1l11l_l1_ (u"ࠬ࠭㔻"),164,l1l11l_l1_ (u"࠭ࠧ㔼"),l1l11l_l1_ (u"ࠧࠨ㔽"),l1l11l_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㔾"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔿"),l1l11l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭㕀"),l1l11l_l1_ (u"ࠫࠬ㕁"),165,l1l11l_l1_ (u"ࠬ࠭㕂"),l1l11l_l1_ (u"࠭ࠧ㕃"),l1l11l_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩ㕄"))
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㕅"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㕆"),l1l11l_l1_ (u"ࠪࠫ㕇"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕈"),l1l11l_l1_ (u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ㕉"),l1l11l_l1_ (u"࠭ࠧ㕊"),163,l1l11l_l1_ (u"ࠧࠨ㕋"),l1l11l_l1_ (u"ࠨࠩ㕌"),l1l11l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㕍"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕎"),l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ㕏"),l1l11l_l1_ (u"ࠬ࠭㕐"),163,l1l11l_l1_ (u"࠭ࠧ㕑"),l1l11l_l1_ (u"ࠧࠨ㕒"),l1l11l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㕓"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕔"),l1l11l_l1_ (u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ㕕"),l1l11l_l1_ (u"ࠫࠬ㕖"),162,l1l11l_l1_ (u"ࠬ࠭㕗"),l1l11l_l1_ (u"࠭ࠧ㕘"),l1l11l_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㕙"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕚"),l1l11l_l1_ (u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪ㕛"),l1l11l_l1_ (u"ࠪࠫ㕜"),162,l1l11l_l1_ (u"ࠫࠬ㕝"),l1l11l_l1_ (u"ࠬ࠭㕞"),l1l11l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㕟"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕠"),l1l11l_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡสะฯࠥ฿ิ้ษษ๎ࠬ㕡"),l1l11l_l1_ (u"ࠩࠪ㕢"),164,l1l11l_l1_ (u"ࠪࠫ㕣"),l1l11l_l1_ (u"ࠫࠬ㕤"),l1l11l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㕥"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕦"),l1l11l_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ㕧"),l1l11l_l1_ (u"ࠨࠩ㕨"),165,l1l11l_l1_ (u"ࠩࠪ㕩"),l1l11l_l1_ (u"ࠪࠫ㕪"),l1l11l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㕫"))
	return
def l1llllll11l1_l1_(options):
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㕬"),l1l11l_l1_ (u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩ㕭"),l1l11l_l1_ (u"ࠧࠨ㕮"),161,l1l11l_l1_ (u"ࠨࠩ㕯"),l1l11l_l1_ (u"ࠩࠪ㕰"),l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ㕱"))
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㕲"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㕳"),l1l11l_l1_ (u"࠭ࠧ㕴"),9999)
	l111lllll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕵"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ࡞࡛ࡔࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㕶")+l1l11l_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ㕷"),l1l11l_l1_ (u"ࠪࠫ㕸"),147)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕹"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㕺")+l1l11l_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ㕻"),l1l11l_l1_ (u"ࠧࠨ㕼"),148)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕽"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡏࡆࡍࠢࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㕾")+l1l11l_l1_ (u"ࠪๆ๋อษࠡฤํࠤๆ๐ไๆ่๊๋่ࠢࠥใ฻๊้ࠬ㕿"),l1l11l_l1_ (u"ࠫࠬ㖀"),28)
	#addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩࡷࡧࠪ㖁"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡐࡖࡋࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㖂")+l1l11l_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ㖃"),l1l11l_l1_ (u"ࠨࠩ㖄"),41)
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㖅"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡋࡘࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㖆")+l1l11l_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ㖇"),l1l11l_l1_ (u"ࠬ࠭㖈"),135)
	import l11ll111lll_l1_
	l11ll111lll_l1_.ITEMS(l1l11l_l1_ (u"࠭࠰ࠨ㖉"),False)
	l11ll111lll_l1_.ITEMS(l1l11l_l1_ (u"ࠧ࠲ࠩ㖊"),False)
	l11ll111lll_l1_.ITEMS(l1l11l_l1_ (u"ࠨ࠴ࠪ㖋"),False)
	#l11ll111lll_l1_.ITEMS(l1l11l_l1_ (u"ࠩ࠶ࠫ㖌"),False)
	if l1l11l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ㖍") in options:
		menuItemsLIST[:] = l1llll1l11l1_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1lllll11l1l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1lllll11l1l_l1_)
	menuItemsLIST[:] = l111lllll1l_l1_+menuItemsLIST
	return
def l1lllll1l1l1_l1_(options):
	options = options.replace(l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㖎"),l1l11l_l1_ (u"ࠬ࠭㖏")).replace(l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㖐"),l1l11l_l1_ (u"ࠧࠨ㖑"))
	headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㖒") : l1l11l_l1_ (u"ࠩࠪ㖓") }
	url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩ㖔")
	payload = { l1l11l_l1_ (u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭㖕") : l1l11l_l1_ (u"ࠬ࠻࠰ࠨ㖖") }
	data = l1111l11_l1_(payload)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㖗"),l1l11l_l1_ (u"ࠧࠨ㖘"),l1l11l_l1_ (u"ࠨࠩ㖙"),str(data))
	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㖚"),url,data,headers,l1l11l_l1_ (u"ࠪࠫ㖛"),l1l11l_l1_ (u"ࠫࠬ㖜"),l1l11l_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡓࡆࡃࡕࡇࡍࡥࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘ࠳࠱ࡴࡶࠪ㖝"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨ㖞"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ㖟"),block,re.DOTALL)
	l1lll1lll1l1_l1_,l1llll111l1l_l1_ = list(zip(*items))
	l1lllll1ll11_l1_ = []
	l1llllll1111_l1_ = [l1l11l_l1_ (u"ࠨࠢࠪ㖠"),l1l11l_l1_ (u"ࠩࠥࠫ㖡"),l1l11l_l1_ (u"ࠪࡤࠬ㖢"),l1l11l_l1_ (u"ࠫ࠱࠭㖣"),l1l11l_l1_ (u"ࠬ࠴ࠧ㖤"),l1l11l_l1_ (u"࠭࠺ࠨ㖥"),l1l11l_l1_ (u"ࠧ࠼ࠩ㖦"),l1l11l_l1_ (u"ࠣࠩࠥ㖧"),l1l11l_l1_ (u"ࠩ࠰ࠫ㖨")]
	l1lllll111l1_l1_ = l1llll111l1l_l1_+l1lll1lll1l1_l1_
	for word in l1lllll111l1_l1_:
		if word in l1llll111l1l_l1_: l1llll1lll1l_l1_ = 2
		if word in l1lll1lll1l1_l1_: l1llll1lll1l_l1_ = 4
		l1lllll1ll1l_l1_ = [i in word for i in l1llllll1111_l1_]
		if any(l1lllll1ll1l_l1_):
			index = l1lllll1ll1l_l1_.index(True)
			l1llll11l111_l1_ = l1llllll1111_l1_[index]
			l1lllll11lll_l1_ = l1l11l_l1_ (u"ࠪࠫ㖩")
			if word.count(l1llll11l111_l1_)>1: l1lllll1l111_l1_,l1lllll11ll1_l1_,l1lllll11lll_l1_ = word.split(l1llll11l111_l1_,2)
			else: l1lllll1l111_l1_,l1lllll11ll1_l1_ = word.split(l1llll11l111_l1_,1)
			if len(l1lllll1l111_l1_)>l1llll1lll1l_l1_: l1lllll1ll11_l1_.append(l1lllll1l111_l1_.lower())
			if len(l1lllll11ll1_l1_)>l1llll1lll1l_l1_: l1lllll1ll11_l1_.append(l1lllll11ll1_l1_.lower())
			if len(l1lllll11lll_l1_)>l1llll1lll1l_l1_: l1lllll1ll11_l1_.append(l1lllll11lll_l1_.lower())
		elif len(word)>l1llll1lll1l_l1_: l1lllll1ll11_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1lllll1ll11_l1_)
	#selection = DIALOG_SELECT(str(len(l1lllll1ll11_l1_)),l1lllll1ll11_l1_)
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊ࡮࡬ࡷࡹࠦ࠽ࠡ࡝ࠪ็้๋วหࠢ฼ุํอฦ๋หࠣ฽ึฮ๊สࠩ࠯่๊ࠫๅศฬࠣ฽ู๎วว์ฬࠤส์ใๅ์ี๎ฮ࠭࡝ࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠵࠭ࠏࠏ࡬ࡪࡵࡷ࠵ࠥࡃࠠ࡜࡟ࠍࠍࡨࡵࡵ࡯ࡶࡶࠤࡂࠦ࡬ࡦࡰࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡩ࡯ࡶࡰࡷࡷ࠯࠻ࠩ࠻ࠢࡵࡥࡳࡪ࡯࡮࠰ࡶ࡬ࡺ࡬ࡦ࡭ࡧࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࡩࡷ࡬࠮ࡀࠠ࡭࡫ࡶࡸ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧไๆ่อࠥ฿ิ้ษษ๎ฮࠦัใ็ࠣࠫ࠰ࡹࡴࡳࠪ࡬࠭࠮ࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠏࠏࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไๅ฼ฬ࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࠧࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡂࡃ࠰࠻ࠢ࡯࡭ࡸࡺ࠲ࠡ࠿ࠣࡥࡷࡨࡌࡊࡕࡗࠎࠎࠏࠣࡦ࡮ࡶࡩ࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡦࡰࡪࡐࡎ࡙ࡔࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠴࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠡ࠾ࠢ࠰࠵࠿ࠦࡢࡳࡧࡤ࡯ࠏࠏࠉࡦ࡮࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࡶࡩࡦࡸࡣࡩࠢࡀࠤࡱ࡯ࡳࡵ࠴࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠤࠥࠦ㖪")
	if l1l11l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭㖫") in options:
		l1llll1l1ll1_l1_ = SEARCH_SITES_REGULAR
	elif l1l11l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭㖬") in options:
		l1llll1l1ll1_l1_ = [l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㖭")]
		import IPTV
		if not IPTV.isIPTVFiles(True): return
	count,l1lll1lll1ll_l1_ = 0,0
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㖮"),l1l11l_l1_ (u"ࠩส่อำหࠡ฻้ࠤ࠿࡛ࠦࠡࠢࡠࠫ㖯"),l1l11l_l1_ (u"ࠪࠫ㖰"),164,l1l11l_l1_ (u"ࠫࠬ㖱"),l1l11l_l1_ (u"ࠬ࠭㖲"),l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㖳")+options)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖴"),l1l11l_l1_ (u"ࠨว฼หิฯࠠศๆหัะࠦวๅ฻ื์ฬฬ๊ࠨ㖵"),l1l11l_l1_ (u"ࠩࠪ㖶"),164,l1l11l_l1_ (u"ࠪࠫ㖷"),l1l11l_l1_ (u"ࠫࠬ㖸"),l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㖹")+options)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖺"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㖻"),l1l11l_l1_ (u"ࠨࠩ㖼"),9999)
	l1lll1lll11l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lllll1llll_l1_ = []
	for word in l1lllll1ll11_l1_:
		l1lllll11ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡞ࠤࡡ࠲࡜࠼࡞࠽ࡠ࠲ࡢࠫ࡝࠿࡟ࠦࡡ࠭࡜࡜࡞ࡠࡠ࠭ࡢࠩ࡝ࡽ࡟ࢁࡡࠧ࡜ࡁ࡞ࠦࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧ㖽"),word,re.DOTALL)
		if l1lllll11ll1_l1_: word = word.split(l1lllll11ll1_l1_[0],1)[0]
		l1lllll1111l_l1_ = word.replace(l1l11l_l1_ (u"ࠪ๕ࠬ㖾"),l1l11l_l1_ (u"ࠫࠬ㖿")).replace(l1l11l_l1_ (u"ࠬ๔ࠧ㗀"),l1l11l_l1_ (u"࠭ࠧ㗁")).replace(l1l11l_l1_ (u"ࠧ์ࠩ㗂"),l1l11l_l1_ (u"ࠨࠩ㗃")).replace(l1l11l_l1_ (u"ࠩ๒ࠫ㗄"),l1l11l_l1_ (u"ࠪࠫ㗅")).replace(l1l11l_l1_ (u"ࠫ๑࠭㗆"),l1l11l_l1_ (u"ࠬ࠭㗇"))
		l1lllll1111l_l1_ = l1lllll1111l_l1_.replace(l1l11l_l1_ (u"࠭๐ࠨ㗈"),l1l11l_l1_ (u"ࠧࠨ㗉")).replace(l1l11l_l1_ (u"ࠨ๏ࠪ㗊"),l1l11l_l1_ (u"ࠩࠪ㗋")).replace(l1l11l_l1_ (u"ࠪ๖ࠬ㗌"),l1l11l_l1_ (u"ࠫࠬ㗍")).replace(l1l11l_l1_ (u"ࠬฒࠧ㗎"),l1l11l_l1_ (u"࠭ࠧ㗏")).replace(l1l11l_l1_ (u"ࠧแࠩ㗐"),l1l11l_l1_ (u"ࠨࠩ㗑"))
		l1lllll1llll_l1_.append(l1lllll1111l_l1_)
	for i in range(0,20):
		text = random.sample(l1lllll1llll_l1_,1)[0]
		site = random.sample(l1llll1l1ll1_l1_,1)[0]
		LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㗒"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡖࡪࡦࡨࡳ࡙ࠥࡥࡢࡴࡦ࡬ࠥࠦࠠࡴ࡫ࡷࡩ࠿࠭㗓")+str(site)+l1l11l_l1_ (u"ࠫࠥࠦࡴࡦࡺࡷ࠾ࠬ㗔")+text)
		#results = l111lllllll_l1_(l1l11l_l1_ (u"ࠬ࠭㗕"),l1l11l_l1_ (u"࠭ࠧ㗖"),l1l11l_l1_ (u"ࠧࠨ㗗"),site,l1l11l_l1_ (u"ࠨࠩ㗘"),l1l11l_l1_ (u"ࠩࠪ㗙"),text+l1l11l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ㗚"),l1l11l_l1_ (u"ࠫࠬ㗛"),l1l11l_l1_ (u"ࠬ࠭㗜"))
		l1lllll1l11_l1_,l1llllll11l_l1_,l11111ll11_l1_ = l1lllll1111_l1_(site)
		l1llllll11l_l1_(text+l1l11l_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ㗝"))
		if len(menuItemsLIST)>0: break
	#text = text.replace(l1l11l_l1_ (u"ࠧࡠࠩ㗞"),l1l11l_l1_ (u"ࠨࠩ㗟"))
	l1lll1lll11l_l1_[0][1] = l1l11l_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㗠")+text[:-2]+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไษฯฮࠤ฾์ࠠ࠻ࠢ࡞ࠤࠬ㗡")
	menuItemsLIST[:] = l1llll1l11l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1lllll11l1l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1lllll11l1l_l1_)
	menuItemsLIST[:] = l1lll1lll11l_l1_+menuItemsLIST
	#import l111lll1ll_l1_
	#l111lll1ll_l1_.SEARCH(search)
	return
def l1lllll1lll1_l1_(site):
	l1lllll1l11_l1_,l1llllll11l_l1_,l11111ll11_l1_ = l1lllll1111_l1_(site)
	try:
		if l1l11l_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㗢") in site: l1lllll1l11_l1_(site)
		else: l1lllll1l11_l1_()
		l1llll1ll1l1_l1_ = False
	except: l1llll1ll1l1_l1_ = True
	if l1llll1ll1l1_l1_: DIALOG_NOTIFICATION(site,l1l11l_l1_ (u"ࠬ็ิๅࠢห๋ีอࠠศๆ่์็฿ࠧ㗣"),time=2000)
	else: DIALOG_NOTIFICATION(site,l1l11l_l1_ (u"࠭สๆࠢฯ่อࠦวๅลๅืฬ๋ࠧ㗤"),time=2000)
	return l1llll1ll1l1_l1_
def l1lll1llllll_l1_(l1llll1lll11_l1_=True):
	if not l1llll1lll11_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㗥"),l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭㗦"),l1l11l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㗧"))
		if results:
			contentsDICT = results
			return
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㗨"),l1l11l_l1_ (u"ࠫࠬ㗩"),l1l11l_l1_ (u"ࠬ࠭㗪"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㗫"),l1l11l_l1_ (u"ࠧๅๅํࠤฯ๋ไว๊ࠢิ์ࠦวๅไสส๊ฯࠠ࠯ࠢส่อืๆศ็ฯࠤ๏ำสศฮࠣว๋๊ࠦโฯุࠤัฺ๋๊่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠโ์ࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํืฯิัอ่๊ࠢ์อࠠโไฺࠤฬ๊รใีส้ࠥอไาศํื๏ฯࠠ࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴ฺࠠ็็๎ฮࠦๅๅศࠣะ๊๐ูࠡษ็ว็ูวๆࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࠯๊่ࠢࠥะั๋ัࠣว๋ࠦสอ็฼ࠤ็อฦๆหࠣห้ษโิษ่ࠤฬ๊ย็ࠢยࠫ㗬"))
	if yes!=1: return
	l1llll11111l_l1_ = menuItemsLIST[:]
	l1llll1l1l1l_l1_,l1llll1l11ll_l1_ = 0,l1l11l_l1_ (u"ࠨࠩ㗭")
	for site in SECTIONS_SITES:
		l1llll1ll1l1_l1_ = l1lllll1lll1_l1_(site)
		if l1llll1ll1l1_l1_:
			l1llll1l1l1l_l1_ += 1
			l1llll1l11ll_l1_ += l1l11l_l1_ (u"ࠩࠣࠫ㗮")+site
			if l1llll1l1l1l_l1_>=l1llll1ll1ll_l1_: break
	menuItemsLIST[:] = l1llll11111l_l1_
	if l1llll1l1l1l_l1_>=l1llll1ll1ll_l1_: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㗯"),l1l11l_l1_ (u"ࠫࠬ㗰"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㗱"),l1l11l_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧ㗲")+str(l1llll1l1l1l_l1_)+l1l11l_l1_ (u"ࠧࠡ็๋ห็฿ࠠๆ่้ࠣํอโฺࠢส่อืๆศ็ฯࠤ࠳࠴࠮๊ࠡึฬอํวࠡไาࠤ๏้่็ࠢ฼ำ๊่ࠦอ๊าࠤส์สา่ํฮࠥ็๊ࠡฮ๊หื้้้ࠠํ࠾ࠬ㗳")+l1llll1l11ll_l1_)
	else:
		WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭㗴"),l1l11l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㗵"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㗶"),l1l11l_l1_ (u"ࠫࠬ㗷"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㗸"),l1l11l_l1_ (u"࠭สๆࠢฯ่อࠦฬๆ์฼ࠤฬ๊รใีส้ࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้ฮั็ษ่ะࠬ㗹"))
	return
def l1llll11ll1l_l1_(options):
	if l1l11l_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ㗺") not in options:
		results = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㗻"),l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧ㗼"),l1l11l_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ㗽"))
		if results: menuItemsLIST[:] = results ; return
	message = l1l11l_l1_ (u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ㗾")
	import IPTV
	if IPTV.isIPTVFiles(True):
		if l1l11l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㗿") in options and l1l11l_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭㘀") not in options:
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㘁"),l1l11l_l1_ (u"ࠨࠩ㘂"),l1l11l_l1_ (u"ࠩࠪ㘃"),options+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㘄"))
			except: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㘅"),l1l11l_l1_ (u"ࠬ࠭㘆"),l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ㘇"),message)
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㘈"),l1l11l_l1_ (u"ࠨࠩ㘉"),l1l11l_l1_ (u"ࠩࠪ㘊"),options+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㘋"))
			except: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㘌"),l1l11l_l1_ (u"ࠬ࠭㘍"),l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ㘎"),message)
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㘏"),l1l11l_l1_ (u"ࠨࠩ㘐"),l1l11l_l1_ (u"ࠩࠪ㘑"),options+l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㘒"))
			except: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㘓"),l1l11l_l1_ (u"ࠬ࠭㘔"),l1l11l_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ㘕"),message)
		if l1l11l_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ㘖") in options and l1l11l_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ㘗") not in options:
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㘘"),l1l11l_l1_ (u"ࠪࠫ㘙"),l1l11l_l1_ (u"ࠫࠬ㘚"),options+l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㘛"))
			except: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㘜"),l1l11l_l1_ (u"ࠧࠨ㘝"),l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭㘞"),message)
			try: IPTV.GROUPS(l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㘟"),l1l11l_l1_ (u"ࠪࠫ㘠"),l1l11l_l1_ (u"ࠫࠬ㘡"),options+l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㘢"))
			except: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㘣"),l1l11l_l1_ (u"ࠧࠨ㘤"),l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭㘥"),message)
	WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧ㘦"),l1l11l_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ㘧"),menuItemsLIST,PERMANENT_CACHE)
	return
def l1lllll11l11_l1_(options,l1llll1l1lll_l1_):
	if l1l11l_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ㘨") in options:
		if l1l11l_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ㘩") in options and l1llll1l1lll_l1_==l1l11l_l1_ (u"࠭ࠧ㘪"): l1lll1llllll_l1_(True)
		elif l1llll1l1lll_l1_: l1lll1llllll_l1_(False)
		#if contentsDICT=={}: return
	l1llll1ll11l_l1_ = options.replace(l1l11l_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ㘫"),l1l11l_l1_ (u"ࠨࠩ㘬")).replace(l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㘭"),l1l11l_l1_ (u"ࠪࠫ㘮")).replace(l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㘯"),l1l11l_l1_ (u"ࠬ࠭㘰"))
	if not l1llll1l1lll_l1_:
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㘱"),l1l11l_l1_ (u"ࠧหฯา๎ะࠦ็ั้ࠣห้่วว็ฬࠫ㘲"),l1l11l_l1_ (u"ࠨࠩ㘳"),165,l1l11l_l1_ (u"ࠩࠪ㘴"),l1l11l_l1_ (u"ࠪࠫ㘵"),l1l11l_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ㘶")+l1llll1ll11l_l1_)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㘷"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㘸"),l1l11l_l1_ (u"ࠧࠨ㘹"),9999)
	if l1l11l_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ㘺") in options:
		l1llllll11_l1_ = [l1l11l_l1_ (u"ࠩฦๅ้อๅࠨ㘻"),l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠫ㘼"),l1l11l_l1_ (u"ู๊ࠫัฮ์สฮࠬ㘽"),l1l11l_l1_ (u"ࠬฮัศ็ฯࠫ㘾"),l1l11l_l1_ (u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬ㘿"),l1l11l_l1_ (u"ࠧา็ูห๋࠭㙀"),l1l11l_l1_ (u"ࠨละำะ࠳รฯำࠪ㙁"),l1l11l_l1_ (u"ࠩึ่ฬูไࠨ㙂"),l1l11l_l1_ (u"้ࠪํู๊ใ๋ࠪ㙃"),l1l11l_l1_ (u"ࠫศฺ็า࠯ฦ็ะืࠧ㙄"),l1l11l_l1_ (u"ࠬอไร่ࠪ㙅"),l1l11l_l1_ (u"࠭ึฮๅࠪ㙆"),l1l11l_l1_ (u"ࠧา์สฺฮ࠭㙇"),l1l11l_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ㙈"),l1l11l_l1_ (u"่้ࠩะ๊๊็ࠩ㙉"),l1l11l_l1_ (u"ࠪฬะࠦอ๋ࠩ㙊"),l1l11l_l1_ (u"ࠫิ๐ๆ๋หࠪ㙋"),l1l11l_l1_ (u"ูࠬๆ้ษอࠫ㙌"),l1l11l_l1_ (u"࠭รฯำ์ࠫ㙍")]
		l1llll1111l1_l1_ = [l1l11l_l1_ (u"ࠧศใ็ห๊࠭㙎"),l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㙏"),l1l11l_l1_ (u"ࠩไ๎้๋ࠧ㙐"),l1l11l_l1_ (u"ࠪๅ้๋ࠧ㙑")]
		l1llll11l1l1_l1_ = [l1l11l_l1_ (u"ู๊ࠫไิๆࠪ㙒"),l1l11l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ㙓")]
		l1llllll111l_l1_ = [l1l11l_l1_ (u"࠭ๅิษิัࠬ㙔"),l1l11l_l1_ (u"ࠧๆีิั๏อสࠨ㙕")]
		l1llll11l11l_l1_ = [l1l11l_l1_ (u"ࠨสิห๊าࠧ㙖"),l1l11l_l1_ (u"ࠩࡶ࡬ࡴࡽࠧ㙗"),l1l11l_l1_ (u"ࠪฮ้็า๋๊้ࠫ㙘"),l1l11l_l1_ (u"ࠫฯ๊๊โิํ์๋࠭㙙")]
		l1lllll11111_l1_ = [l1l11l_l1_ (u"ࠬอๆๆ์ࠪ㙚"),l1l11l_l1_ (u"࠭ใาฬ๋๊ࠬ㙛"),l1l11l_l1_ (u"ࠧไษิฮํ์ࠧ㙜"),l1l11l_l1_ (u"ࠨ࡭࡬ࡨࡸ࠭㙝"),l1l11l_l1_ (u"ฺࠩๅ้࠭㙞"),l1l11l_l1_ (u"ࠪห฼็วๅࠩ㙟")]
		l1l11111_l1_ = [l1l11l_l1_ (u"ࠫึ๋ึศ่ࠪ㙠")]
		l11l1l1l_l1_ = [l1l11l_l1_ (u"ࠬออะอࠪ㙡"),l1l11l_l1_ (u"࠭วฯำࠪ㙢"),l1l11l_l1_ (u"ࠧๆ๊ัีࠬ㙣"),l1l11l_l1_ (u"ࠨฮา๎ิ࠭㙤"),l1l11l_l1_ (u"ฺ่ࠩฬ็ࠧ㙥"),l1l11l_l1_ (u"ࠪัิ๐หࠨ㙦")]
		l1llll11lll1_l1_ = [l1l11l_l1_ (u"ุ๊ࠫวิๆࠪ㙧"),l1l11l_l1_ (u"ูࠬไิๆ๊ࠫ㙨")]
		l1lll1llll11_l1_ = [l1l11l_l1_ (u"࠭ว฻ษ้๎ࠬ㙩"),l1l11l_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ㙪"),l1l11l_l1_ (u"ࠨๅ็๎อ࠭㙫"),l1l11l_l1_ (u"ࠩะๅ้࠭㙬"),l1l11l_l1_ (u"ࠪࡱࡺࡹࡩࡤࠩ㙭")]
		l1lllll1l11l_l1_ = [l1l11l_l1_ (u"ࠫฬ้หาࠩ㙮"),l1l11l_l1_ (u"ࠬอิ่ำࠪ㙯"),l1l11l_l1_ (u"࠭ๅๆ์ี๋ࠬ㙰"),l1l11l_l1_ (u"ࠧศ฻็ํࠬ㙱"),l1l11l_l1_ (u"ࠨ็ัฮฬื็ࠨ㙲"),l1l11l_l1_ (u"่ࠩาฯอัศฬࠪ㙳"),l1l11l_l1_ (u"ࠪห็๎้ࠨ㙴")]
		l1llll111lll_l1_ = [l1l11l_l1_ (u"ࠫฬ๊ว็ࠩ㙵"),l1l11l_l1_ (u"ࠬำวๅ์ࠪ㙶"),l1l11l_l1_ (u"࠭ๅฬสอࠫ㙷"),l1l11l_l1_ (u"ࠧาษษะࠬ㙸")]
		l1lll1lllll1_l1_ = [l1l11l_l1_ (u"ࠨุะ็ࠬ㙹"),l1l11l_l1_ (u"ࠩๆ์๊๐ฯ๋ࠩ㙺")]
		l1llll1111ll_l1_ = [l1l11l_l1_ (u"ࠪี๏อึ่ࠩ㙻"),l1l11l_l1_ (u"่ࠫ๎ั่ࠩ㙼"),l1l11l_l1_ (u"๋ࠬีศำ฼๋ࠬ㙽"),l1l11l_l1_ (u"࠭ิ้ฬࠪ㙾"),l1l11l_l1_ (u"ࠧา์สฺฮ࠭㙿")]
		l1llll1llll1_l1_ = [l1l11l_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ㚀"),l1l11l_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ㚁"),l1l11l_l1_ (u"๊ࠪ๏ะแๅ์ๆืࠬ㚂")]
		l1llll111111_l1_ = [l1l11l_l1_ (u"๊๋ࠫหๅ์้ࠫ㚃"),l1l11l_l1_ (u"ࠬอิฯษุࠫ㚄"),l1l11l_l1_ (u"࠭ๆอ๊่ࠫ㚅")]
		l1llll11l_l1_ = [l1l11l_l1_ (u"ࠧษอࠣั๏࠭㚆"),l1l11l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㚇"),l1l11l_l1_ (u"ࠩๅ๊ฬํࠧ㚈"),l1l11l_l1_ (u"ࠪๆ๋๎วหࠩ㚉")]
		l1llll1lllll_l1_ = [l1l11l_l1_ (u"ࠫิ๐ๆࠨ㚊"),l1l11l_l1_ (u"ࠬอฯฺ์๊ࠫ㚋"),l1l11l_l1_ (u"࠭า๋ษิหฯ࠭㚌"),l1l11l_l1_ (u"ࠧๅู่๎ฬะࠧ㚍"),l1l11l_l1_ (u"ࠨั฼หฦ࠭㚎"),l1l11l_l1_ (u"ࠩๅีฬ์ࠧ㚏"),l1l11l_l1_ (u"ࠪๆฺอฦะࠩ㚐"),l1l11l_l1_ (u"ࠫึัวยࠩ㚑"),l1l11l_l1_ (u"๋ࠬัอ฻ํ๋ࠬ㚒"),l1l11l_l1_ (u"࠭วัษ้ࠫ㚓"),l1l11l_l1_ (u"ࠧศี็ห๊࠭㚔"),l1l11l_l1_ (u"ࠨฬ๋หู๐อࠨ㚕"),l1l11l_l1_ (u"ࠩั฻อ࠭㚖"),l1l11l_l1_ (u"ࠪัํุ่๋ࠩ㚗"),l1l11l_l1_ (u"ࠫ฾ะศศฬࠪ㚘"),l1l11l_l1_ (u"๋่ࠬศๆํำࠬ㚙"),l1l11l_l1_ (u"࠭ๆ้ษ฼๎ࠬ㚚"),l1l11l_l1_ (u"ฺࠧไสสิ࠭㚛"),l1l11l_l1_ (u"ࠨษ้หู๐ฯࠨ㚜")]
		l1lllll111ll_l1_ = [l1l11l_l1_ (u"ࠩ࠴࠽ࠬ㚝"),l1l11l_l1_ (u"ࠪ࠶࠵࠭㚞")]
		if not l1llll1l1lll_l1_:
			l1llll1l1lll_l1_ = 0
			for l1llll1ll111_l1_ in l1llllll11_l1_:
				l1llll1l1lll_l1_ += 1
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㚟"),menu_name+l1llll1ll111_l1_,l1l11l_l1_ (u"ࠬ࠭㚠"),165,l1l11l_l1_ (u"࠭ࠧ㚡"),str(l1llll1l1lll_l1_),l1llll1ll11l_l1_)
		else:
			for name in sorted(list(contentsDICT.keys())):
				name2 = name.lower()
				category = []
				if any(value in name2 for value in l1llll1111l1_l1_): category.append(1)
				if any(value in name2 for value in l1llll11l1l1_l1_): category.append(2)
				if any(value in name2 for value in l1llllll111l_l1_): category.append(3)
				if any(value in name2 for value in l1llll11l11l_l1_): category.append(4)
				if any(value in name2 for value in l1lllll11111_l1_): category.append(5)
				if any(value in name2 for value in l1l11111_l1_): category.append(6)
				if any(value in name2 for value in l11l1l1l_l1_) and name2 not in [l1l11l_l1_ (u"ࠧศะิํࠬ㚢")]: category.append(7)
				if any(value in name2 for value in l1llll11lll1_l1_): category.append(8)
				if any(value in name2 for value in l1lll1llll11_l1_): category.append(9)
				if any(value in name2 for value in l1lllll1l11l_l1_): category.append(10)
				if any(value in name2 for value in l1llll111lll_l1_): category.append(11)
				if any(value in name2 for value in l1lll1lllll1_l1_): category.append(12)
				if any(value in name2 for value in l1llll1111ll_l1_): category.append(13)
				if any(value in name2 for value in l1llll1llll1_l1_): category.append(14)
				if any(value in name2 for value in l1llll111111_l1_): category.append(15)
				if any(value in name2 for value in l1llll11l_l1_): category.append(16)
				if any(value in name2 for value in l1llll1lllll_l1_): category.append(17)
				if any(value in name2 for value in l1lllll111ll_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l1llll1l1lll_l1_:
						addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㚣"),menu_name+name,name,166,l1l11l_l1_ (u"ࠩࠪ㚤"),l1l11l_l1_ (u"ࠪࠫ㚥"),l1llll1ll11l_l1_+l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㚦"))
	elif l1l11l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㚧") in options:
		if l1l11l_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ㚨") in options:
			import IPTV
			if not IPTV.isIPTVFiles(False): IPTV.CREATE_STREAMS()
		l1llll11ll1l_l1_(options)
	return
def l1llll111l11_l1_(nameonly,options):
	options = options.replace(l1l11l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㚩"),l1l11l_l1_ (u"ࠨࠩ㚪")).replace(l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㚫"),l1l11l_l1_ (u"ࠪࠫ㚬"))
	l1lll1llllll_l1_(False)
	if contentsDICT=={}: return
	if l1l11l_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭㚭") in options:
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㚮"),l1l11l_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㚯")+nameonly+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭㚰"),nameonly,166,l1l11l_l1_ (u"ࠨࠩ㚱"),l1l11l_l1_ (u"ࠩࠪ㚲"),l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㚳")+options)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㚴"),l1l11l_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ㚵"),nameonly,166,l1l11l_l1_ (u"࠭ࠧ㚶"),l1l11l_l1_ (u"ࠧࠨ㚷"),l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㚸")+options)
		addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㚹"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㚺"),l1l11l_l1_ (u"ࠫࠬ㚻"),9999)
	for website in sorted(list(contentsDICT[nameonly].keys())):
		type,name,url,l11l11l11l1_l1_,image,page,text,favourite,infodict = contentsDICT[nameonly][website]
		if l1l11l_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ㚼") in options or len(contentsDICT[nameonly])==1:
			l111lllllll_l1_(type,l1l11l_l1_ (u"࠭ࠧ㚽"),url,l11l11l11l1_l1_,l1l11l_l1_ (u"ࠧࠨ㚾"),page,text,l1l11l_l1_ (u"ࠨࠩ㚿"),l1l11l_l1_ (u"ࠩࠪ㛀"))
			menuItemsLIST[:] = l1llll1l11l1_l1_(menuItemsLIST)
			l1lll1llll1l_l1_,newLIST = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(newLIST)
			if l1l11l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ㛁") in options: menuItemsLIST[:] = l1lll1llll1l_l1_+newLIST[:l1lllll11l1l_l1_]
			else: menuItemsLIST[:] = l1lll1llll1l_l1_+newLIST
		elif l1l11l_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ㛂") in options: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㛃"),website,url,l11l11l11l1_l1_,image,page,text,favourite,infodict)
	return
def l1llll11llll_l1_(options,mode):
	options = options.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㛄"),l1l11l_l1_ (u"ࠧࠨ㛅")).replace(l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㛆"),l1l11l_l1_ (u"ࠩࠪ㛇"))
	name,l1llll11ll11_l1_ = l1l11l_l1_ (u"ࠪࠫ㛈"),[]
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㛉"),l1l11l_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㛊")+name+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ㛋"),l1l11l_l1_ (u"ࠧࠨ㛌"),mode,l1l11l_l1_ (u"ࠨࠩ㛍"),l1l11l_l1_ (u"ࠩࠪ㛎"),l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㛏")+options)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㛐"),l1l11l_l1_ (u"ࠬหูศัฬࠤ฼๊ศࠡไึ้ࠥ฿ิ้ษษ๎ࠬ㛑"),l1l11l_l1_ (u"࠭ࠧ㛒"),mode,l1l11l_l1_ (u"ࠧࠨ㛓"),l1l11l_l1_ (u"ࠨࠩ㛔"),l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㛕")+options)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㛖"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㛗"),l1l11l_l1_ (u"ࠬ࠭㛘"),9999)
	l1lll1llll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l1l11l_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ㛙") in options:
		l1lll1llllll_l1_(False)
		if contentsDICT=={}: return
		l1llll1l111l_l1_ = list(contentsDICT.keys())
		nameonly = random.sample(l1llll1l111l_l1_,1)[0]
		l1lllll1ll11_l1_ = list(contentsDICT[nameonly].keys())
		website = random.sample(l1lllll1ll11_l1_,1)[0]
		type,name,url,l11l11l11l1_l1_,image,page,text,favourite,infodict = contentsDICT[nameonly][website]
		LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㛚"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡹࡨࡦࡸ࡯ࡴࡦ࠼ࠣࠫ㛛")+website+l1l11l_l1_ (u"ࠩࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ㛜")+name+l1l11l_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ㛝")+url+l1l11l_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ㛞")+str(l11l11l11l1_l1_))
	elif l1l11l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㛟") in options:
		l1llll11ll1l_l1_(options)
		if not menuItemsLIST: return
		type,name,url,l11l11l11l1_l1_,image,page,text,favourite,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㛠"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ㛡")+name+l1l11l_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ㛢")+url+l1l11l_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ㛣")+str(l11l11l11l1_l1_))
	l1llll11l1ll_l1_ = name
	l1llll1l1l11_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㛤"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ㛥")+name+l1l11l_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ㛦")+url+l1l11l_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ㛧")+str(l11l11l11l1_l1_))
		menuItemsLIST[:] = []
		if l11l11l11l1_l1_==234 and l1l11l_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ㛨") in text: l11l11l11l1_l1_ = 233
		if l11l11l11l1_l1_==144: l11l11l11l1_l1_ = 291
		html = l111lllllll_l1_(type,name,url,l11l11l11l1_l1_,image,page,text,favourite,infodict)
		#if l1l11l_l1_ (u"ࠨࡡࡢࡣࡊࡸࡲࡰࡴࡢࡣࡤ࠭㛩") in html: l1llll11llll_l1_(options,mode)
		if l1l11l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ㛪") in options and l11l11l11l1_l1_==167: del menuItemsLIST[:3]
		l1llll11ll11_l1_[:] = l1llll1l11l1_l1_(menuItemsLIST)
		if l1llll1l1l11_l1_ and l1111lll111_l1_(l1l11l_l1_ (u"ࡸࠫา๊โสࠩ㛫")) in str(l1llll11ll11_l1_) or l1111lll111_l1_(l1l11l_l1_ (u"ࡹࠬำไใ้ࠪ㛬")) in str(l1llll11ll11_l1_):
			name = l1llll11l1ll_l1_
			l1llll11ll11_l1_[:] = l1llll1l1l11_l1_
			break
		l1llll11l1ll_l1_ = name
		l1llll1l1l11_l1_ = l1llll11ll11_l1_[:]
		if str(l1llll11ll11_l1_).count(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㛭"))>0: break
		if str(l1llll11ll11_l1_).count(l1l11l_l1_ (u"࠭࡬ࡪࡸࡨࠫ㛮"))>0: break
		if l11l11l11l1_l1_==233: break	# l1l11111l1_l1_ l1l11l11_l1_ names l1l1ll11l1l_l1_ of l1l11l1_l1_ name
		if l11l11l11l1_l1_==291: break	# l111l111_l1_ l1lllll1l1ll_l1_ names l1l1ll11l1l_l1_ of l111l111_l1_ l1lllll1l1ll_l1_ contents
		if l1llll11ll11_l1_: type,name,url,l11l11l11l1_l1_,image,page,text,favourite,infodict = random.sample(l1llll11ll11_l1_,1)[0]
	if name==l1l11l_l1_ (u"ࠧࠨ㛯"): name = l1l11l_l1_ (u"ࠨ࠰࠱࠲࠳࠭㛰")
	elif name.count(l1l11l_l1_ (u"ࠩࡢࠫ㛱"))>1: name = name.split(l1l11l_l1_ (u"ࠪࡣࠬ㛲"),2)[2]
	name = name.replace(l1l11l_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒ࠿ࠦࠧ㛳"),l1l11l_l1_ (u"ࠬ࠭㛴"))#.replace(l1l11l_l1_ (u"࠭ࠬࡎࡑ࡙ࡍࡊ࡙࠺ࠡࠩ㛵"),l1l11l_l1_ (u"ࠧࠨ㛶")).replace(l1l11l_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ㛷"),l1l11l_l1_ (u"ࠩࠪ㛸")).replace(l1l11l_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ㛹"),l1l11l_l1_ (u"ࠫࠬ㛺"))
	l1lll1llll1l_l1_[0][1] = l1l11l_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㛻")+name+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ㛼")
	for i in range(9): random.shuffle(l1llll11ll11_l1_)
	if l1l11l_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ㛽") in options: menuItemsLIST[:] = l1lll1llll1l_l1_+l1llll11ll11_l1_[:l1lllll11l1l_l1_]
	else: menuItemsLIST[:] = l1lll1llll1l_l1_+l1llll11ll11_l1_
	return
def l1llll111ll1_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㛾"),l1l11l_l1_ (u"ࠩࠪ㛿")).replace(l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㜀"),l1l11l_l1_ (u"ࠫࠬ㜁"))
	l1llll1l1111_l1_ = GROUP
	if l1l11l_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭㜂") in GROUP:
		l1llll1l1111_l1_ = GROUP.split(l1l11l_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ㜃"))[0]
		type = l1l11l_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ㜄")
	elif l1l11l_l1_ (u"ࠨࡘࡒࡈࠬ㜅") in TYPE: type = l1l11l_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ㜆")
	elif l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ㜇") in TYPE: type = l1l11l_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ㜈")
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㜉"),l1l11l_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㜊")+type+l1llll1l1111_l1_+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭㜋"),TYPE,167,l1l11l_l1_ (u"ࠨࠩ㜌"),l1l11l_l1_ (u"ࠩࠪ㜍"),l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㜎")+GROUP)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㜏"),l1l11l_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ㜐"),TYPE,167,l1l11l_l1_ (u"࠭ࠧ㜑"),l1l11l_l1_ (u"ࠧࠨ㜒"),l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㜓")+GROUP)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㜔"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㜕"),l1l11l_l1_ (u"ࠫࠬ㜖"),9999)
	import IPTV
	if l1l11l_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭㜗") in GROUP: IPTV.GROUPS(TYPE,GROUP,l1l11l_l1_ (u"࠭ࠧ㜘"))
	else: IPTV.ITEMS(TYPE,GROUP,l1l11l_l1_ (u"ࠧࠨ㜙"))
	menuItemsLIST[:] = l1llll1l11l1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1lllll11l1l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1lllll11l1l_l1_)
	return
def l1llll1l11l1_l1_(menuItemsLIST):
	l1llll11ll11_l1_ = []
	for type,name,url,mode,image,page,text,favourite,infodict in menuItemsLIST:
		if l1l11l_l1_ (u"ࠨืไัฮ࠭㜚") in name or l1l11l_l1_ (u"ุࠩๅาํࠧ㜛") in name or l1l11l_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ㜜") in name.lower(): continue
		l1llll11ll11_l1_.append([type,name,url,mode,image,page,text,favourite,infodict])
	return l1llll11ll11_l1_
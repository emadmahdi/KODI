# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ䷫")
menu_name = l1l11l_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ䷬")
l11lll_l1_ = WEBSITES[script_name][0]
#headers = l1l11l_l1_ (u"࠭ࠧ䷭")
#headers = {l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䷮"):l1l11l_l1_ (u"ࠨࠩ䷯")}
def MAIN(mode,url,text,type,page):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l11l1l1l1l11_l1_(url)
	#elif mode==142: results = l11l1l1ll1ll_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,page)
	elif mode==145: results = l11ll11ll11l_l1_(url)
	elif mode==146: results = l11l1l1ll111_l1_(url)
	elif mode==147: results = l11ll11111l1_l1_()
	elif mode==148: results = l11ll1111l11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌࡅ࠵࡛ࡧ࡝ࡑࡂࡖࡵࡽࡰࡇࡺࡍࡔࡹࡉࡪ࡟ࡠࡖࡕࡎࡓࡏࡿࢀࡰࡳࡺࡒࡗࠬ䷰")
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷱"),menu_name+l1l11l_l1_ (u"࡙ࠫࡋࡓࡕࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠪ䷲"),url,144)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷳"),menu_name+l1l11l_l1_ (u"࠭࡯࡭ࡦࡨࡶࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠠ࡯ࡱࡷࠤࡱ࡯ࡳࡵ࡫ࡱ࡫ࠥࡴࡥࡸࡧࡵࠤࡵࡲࡹࡢ࡮࡬ࡷࡹ࠭䷴"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡝ࡌࡰࡲࡧ࡜ࡾ࡝ࡠࡦ࡬ࠨ࡯࡭ࡸࡺ࠽ࡓࡆࡔࡑ࠻࠹ࡶࡉ࡬ࡓ࠴࡭࡫ࡔࡴࠩ䷵"),144)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䷶"),menu_name+l1l11l_l1_ (u"่ࠩ์็฿ࠠโษิ฾ࠬ䷷"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࡛ࡃࡵࡑࡹࡳࡳࡰ࠴ࡈࡻࡲࡴࡒ࡚ࡍࡃࡣ࠵࠷ࡶ࡛ࡣࡸࠩ䷸"),144)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䷹"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䷺"),l1l11l_l1_ (u"࠭ࠧ䷻"),149,l1l11l_l1_ (u"ࠧࠨ䷼"),l1l11l_l1_ (u"ࠨࠩ䷽"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䷾"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷿"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ一")+l1l11l_l1_ (u"ࠬࡥ࡙ࡕࡅࡢࠫ丁")+l1l11l_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬࠦวๅ็หี๊าࠧ丂"),l1l11l_l1_ (u"ࠧࠨ七"),290)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丄"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭丅")+menu_name+l1l11l_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣ๎ํะ๊้สࠪ丆"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ万"),144)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丈"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ三")+menu_name+l1l11l_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ上"),l11lll_l1_,144,l1l11l_l1_ (u"ࠨࠩ下"),l1l11l_l1_ (u"ࠩࠪ丌"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ不"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ与"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ丏")+menu_name+l1l11l_l1_ (u"࠭วๅ็ะฮํ๏ࠠศๆิหหาࠧ丐"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ丑"),146)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭丒"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ专"),l1l11l_l1_ (u"ࠪࠫ且"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ丕"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ世")+menu_name+l1l11l_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ丗"),l1l11l_l1_ (u"ࠧࠨ丘"),147)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丙"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭业")+menu_name+l1l11l_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ丛"),l1l11l_l1_ (u"ࠫࠬ东"),148)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丝"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ丞")+menu_name+l1l11l_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ丟"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ丠"),144)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ両"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ丢")+menu_name+l1l11l_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ丣"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ两"),144)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭严"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ並")+menu_name+l1l11l_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭丧"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ丨"),144)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ丩"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ个")+menu_name+l1l11l_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ丫"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ丬"),144)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ中"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ丮")+menu_name+l1l11l_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ丯"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ丰"),144)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ丱"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ串")+menu_name+l1l11l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ丳"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭临"),144)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ丵"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭丶")+menu_name+l1l11l_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ丷"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ丸"),144)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丹"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ为")+menu_name+l1l11l_l1_ (u"ࠧศๆ฼ีฬ่ࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ主"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐ࠹ࡰࡕࡲ࠸ࡳࡲࡌ࠹࠶ࡒ࡬ࡸ࡜ࡉ࡮ࡎ࡯ࡋ࡯ࡶ࡮ࡻࡺࡳࡱࡗࡊࡹࡳࡦࡳࠩ丼"),144)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ丽"),menu_name+l1l11l_l1_ (u"ࠪห฾ีวะษอࠤฬ฼วโหࠣ๎ํะ๊้สࠪ举"),l1l11l_l1_ (u"ࠫࠬ丿"),144)
	#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ乀"),l1l11l_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ乁"),l1l11l_l1_ (u"่ࠧาสࠤฬ๊วฯฬํหึࠦำ้ใࠣ๎ำืฬไ่๊ࠢࠥอไษำ้ห๊าࠧ乂"),l1l11l_l1_ (u"ࠨๆฦ๊์ࠦำ้ใࠣ๎็๎ๅࠡสอุ฿๐ไࠡสิ๊ฬ๋ฬࠡ์๋ฮ๏๎ศࠨ乃"))
	#if yes==1:
	#	url = l1l11l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ乄")
	#	xbmc.executebuiltin(l1l11l_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ久"))
	#	xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡗ࡫ࡰ࡭ࡣࡦࡩ࡜࡯࡮ࡥࡱࡺࠬࡻ࡯ࡤࡦࡱࡶ࠰ࠬ乆")+url+l1l11l_l1_ (u"ࠬ࠯ࠧ乇"))
	#	#xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡒࡶࡰࡄࡨࡩࡵ࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠪࠩ么"))
	return
l1l11l_l1_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡎࡃࡌࡒࡕࡇࡇࡆࠪࡸࡶࡱ࠯࠺ࠋࠋ࡫ࡸࡲࡲࠬࡤࡥ࠯ࡨࡦࡺࡡࠡ࠿ࠣࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃࠫࡹࡷࡲࠩࠋࠋ࡬ࡪࠥ࠭ࡒࡦࡨࡤࡥࡹࠦࡁ࡭࠯ࡊࡥࡲࡳࡡ࡭ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠥࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡿࡥࡴࠩࠬࠎࠎࡪࡤࠡ࠿ࠣࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠐࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡲࡦ࡭ࡥࠩ࡮ࡨࡲ࠭ࡪࡤࠪࠫ࠽ࠎࠎࠏࡩࡵࡧࡰࠤࡂࠦࡤࡥ࡝࡬ࡡࠏࠏࠉࡊࡐࡖࡉࡗ࡚࡟ࡊࡖࡈࡑࡤ࡚ࡏࡠࡏࡈࡒ࡚࠮ࡩࡵࡧࡰ࠭ࠏࠏࡉࡕࡇࡐࡗ࠭ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ义")
def l11ll11111l1_l1_():
	ITEMS(l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ乊"))
	return
def l11ll1111l11_l1_():
	ITEMS(l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ之"))
	return
def PLAY(url,type):
	#url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬ乌")
	#items = re.findall(l1l11l_l1_ (u"ࠫࡻࡃࠨ࠯ࠬࡂ࠭ࠩ࠭乍"),url,re.DOTALL)
	#id = items[0]
	#l1111l_l1_ = l1l11l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫࠯ࡱ࡮ࡤࡽ࠴ࡅࡶࡪࡦࡨࡳࡤ࡯ࡤ࠾ࠩ乎")+id
	#PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ乏"))
	#return
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠊࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪࠎࠎ࡫ࡲࡳࡱࡵࡷ࠱ࡺࡩࡵ࡮ࡨࡷ࠱ࡲࡩ࡯࡭ࡶࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠩࡷࡵࡰ࠮ࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏࠩ࡮࡬ࡲࡰࡹ࡛࠱࡟࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࡶࡼࡴࡪ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ乐")
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l11l1l1ll111_l1_(url):
	html,cc,data = l11l1ll1llll_l1_(url)
	dd = cc[l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ乑")][l1l11l_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ乒")][l1l11l_l1_ (u"ࠪࡸࡦࡨࡳࠨ乓")]
	for ii in range(len(dd)):
		item = dd[ii]
		l11ll11l11ll_l1_(item,url,str(ii))
	ee = dd[0][l1l11l_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ乔")][l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭乕")][l1l11l_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ乖")][l1l11l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ乗")]
	s = 0
	for ii in range(len(ee)):
		item = ee[ii][l1l11l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ乘")][l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ乙")][0]
		if list(item[l1l11l_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ乚")][l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ乛")].keys())[0]==l1l11l_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ乜"): continue
		succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_ = l11ll11lll1l_l1_(item)
		if not title:
			s += 1
			title = l1l11l_l1_ (u"࠭แ๋ัํ์์อสࠡำสสัฯࠠࠨ九")+str(s)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ乞"),menu_name+title,url,144,l1l11l_l1_ (u"ࠨࠩ也"),str(ii))
	key = re.findall(l1l11l_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ习"),html,re.DOTALL)
	url2 = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ乡")+key[0]
	html,cc,data2 = l11l1ll1llll_l1_(url2)
	for jj in range(3,4):
		dd = cc[l1l11l_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ乢")][jj][l1l11l_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ乣")][l1l11l_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ乤")]
		for ii in range(len(dd)):
			item = dd[ii]
			if l1l11l_l1_ (u"࡚ࠧࡱࡸࡘࡺࡨࡥࠡࡒࡵࡩࡲ࡯ࡵ࡮ࠩ乥") in str(item): continue
			l11ll11l11ll_l1_(item)
	return
def ITEMS(url,data=l1l11l_l1_ (u"ࠨࠩ书"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ乧"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ乨"),l1l11l_l1_ (u"ࠫࠬ乩"))
	html,cc,data2 = l11l1ll1llll_l1_(url,data)
	l1lll1lll1_l1_,ff = l1l11l_l1_ (u"ࠬ࠭乪"),l1l11l_l1_ (u"࠭ࠧ乫")
	#if l1l11l_l1_ (u"ࠧࡰࡹࡱࡩࡷ࠭乬") in html.lower(): DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ乭"),l1l11l_l1_ (u"ࠩࠪ乮"),l1l11l_l1_ (u"ࠪࡳࡼࡴࡥࡳࠢࡨࡼ࡮ࡹࡴࠨ乯"),l1l11l_l1_ (u"ࠫ࡮ࡴࠠࡩࡶࡰࡰࠬ买"))
	owner = re.findall(l1l11l_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ乱"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l11l_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ乲"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l11l_l1_ (u"ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ乳"),html,re.DOTALL)
	if owner:
		l1lll1lll1_l1_ = l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ乴")+owner[0][0]+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ乵")
		l1111l_l1_ = owner[0][1]
		if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ乶") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
		#if l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ乷") in url and l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ乸") not in url and l1l11l_l1_ (u"࠭࠯ࡤ࠱ࠪ乹") not in url and l1l11l_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ乺") not in url:
		if l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ乻") in url: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ乼"),menu_name+l1lll1lll1_l1_,l1111l_l1_,144)
	#if cc==l1l11l_l1_ (u"ࠪࠫ乽"): l11l1l1ll1l1_l1_(url,html) ; return
	l11l1l1l1ll1_l1_ = [l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ乾"),l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭乿"),l1l11l_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ亀"),l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ亁"),l1l11l_l1_ (u"ࠨ࠱ࡩࡩࡦࡺࡵࡳࡧࡧࠫ亂"),l1l11l_l1_ (u"ࠩࡶࡷࡂ࠭亃"),l1l11l_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ亄"),l1l11l_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ亅"),l1l11l_l1_ (u"ࠬࡨࡰ࠾ࠩ了"),l1l11l_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ亇")]
	l11l1l1l111l_l1_ = not any(value in url for value in l11l1l1l1ll1_l1_)
	if l11l1l1l111l_l1_ and l1lll1lll1_l1_:
		l1l1l1lll_l1_ = l1l11l_l1_ (u"ࠧศๆหัะ࠭予")
		title2 = l1l11l_l1_ (u"ࠨไ๋หห๋ࠠศๆอุ฿๐ไࠨ争")
		l11l1l1l11ll_l1_ = l1l11l_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯ࠭亊")
		l11l1l1l11l1_l1_ = l1l11l_l1_ (u"ࠪห้่ๆ้ษอࠫ事")
		addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ二"),menu_name+l1lll1lll1_l1_,url,9999)
		if l1l11l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢษฯฮࠦࠬ亍") in html: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭于"),menu_name+l1l1l1lll_l1_,url,145,l1l11l_l1_ (u"ࠧࠨ亏"),l1l11l_l1_ (u"ࠨࠩ亐"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭云"))
		if l1l11l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭互") in html: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ亓"),menu_name+title2,url+l1l11l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ五"),144)
		if l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭井") in html: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ亖"),menu_name+l11l1l1l11ll_l1_,url+l1l11l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ亗"),144)
		if l1l11l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊โ็๊สฮࠧ࠭亘") in html: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ亙"),menu_name+l11l1l1l11l1_l1_,url+l1l11l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ亚"),144)
		if l1l11l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡔࡧࡤࡶࡨ࡮ࠢࠨ些") in html: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭亜"),menu_name+l1l1l1lll_l1_,url,145,l1l11l_l1_ (u"ࠧࠨ亝"),l1l11l_l1_ (u"ࠨࠩ亞"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭亟"))
		if l1l11l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ亠") in html: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ亡"),menu_name+title2,url+l1l11l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ亢"),144)
		if l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ亣") in html: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ交"),menu_name+l11l1l1l11ll_l1_,url+l1l11l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ亥"),144)
		if l1l11l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ亦") in html: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ产"),menu_name+l11l1l1l11l1_l1_,url+l1l11l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ亨"),144)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ亩"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭亪"),l1l11l_l1_ (u"ࠧࠨ享"),9999)
	if l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ京") in url:
		dd = cc[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ亭")][l1l11l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭亮")][l1l11l_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭亯")][l1l11l_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ亰")][l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ亱")]
		l11l1l1l1111_l1_ = 0
		for i in range(len(dd)):
			if l1l11l_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭亲") in list(dd[i].keys()):
				l11l1l11llll_l1_ = dd[i][l1l11l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ亳")]
				length = len(str(l11l1l11llll_l1_))
				if length>l11l1l1l1111_l1_:
					l11l1l1l1111_l1_ = length
					ff = l11l1l11llll_l1_
		if l11l1l1l1111_l1_==0: return
	elif l1l11l_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ亴") in url or l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ亵") in url or l1l11l_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ亶") in url or l1l11l_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭亷") in url or l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ亸") in url or url==l11lll_l1_:
		l11l1ll1l11l_l1_ = []
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ亹"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ人"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ亻"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ亼"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ亽"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠭࠲࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ亾"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ亿"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲ࡜ࡧࡴࡤࡪࡑࡩࡽࡺࡒࡦࡵࡸࡰࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࠧ什"))
		l11l1l1l1lll_l1_,ff = l11l1l1llll1_l1_(cc,l1l11l_l1_ (u"ࠨࠩ仁"),l11l1ll1l11l_l1_)
	if not ff:
		try:
			dd = cc[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ仂")][l1l11l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭仃")][l1l11l_l1_ (u"ࠫࡹࡧࡢࡴࠩ仄")]
			cond1 = l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭仅") in url or l1l11l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ仆") in url or l1l11l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ仇") in url
			l11l1ll111l1_l1_ = l1l11l_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ仈") in html or l1l11l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ็๎วว็ࠣห้ะิ฻์็ࠦࠬ仉") in html or l1l11l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ今") in html
			l11l1ll1111l_l1_ = l1l11l_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ介") in html or l1l11l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ仌") in html or l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥࠫ仍") in html
			if cond1 and (l11l1ll111l1_l1_ or l11l1ll1111l_l1_):
				for ii in range(len(dd)):
					if l1l11l_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ从") not in list(dd[ii].keys()): continue
					ee = dd[ii][l1l11l_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭仏")]
					try: gg = ee[l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ仐")][l1l11l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ仑")][l1l11l_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ仒")][l1l11l_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ仓")][l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩ仔")][ii]
					except: gg = ee
					try: l1111l_l1_ = gg[l1l11l_l1_ (u"ࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩ仕")][l1l11l_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ他")][l1l11l_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ仗")][l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ付")]
					except: continue
					if   l1l11l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ仙")		in l1111l_l1_	and l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭仚")		in url: ee = dd[ii] ; break
					elif l1l11l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ仛")	in l1111l_l1_	and l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ仜")	in url: ee = dd[ii] ; break
					elif l1l11l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ仝")	in l1111l_l1_	and l1l11l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ仞")		in url: ee = dd[ii] ; break
					else: ee = dd[0]
			elif l1l11l_l1_ (u"ࠪࡦࡵࡃࠧ仟") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l1l11l_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ仠")][l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭仡")]
		except: pass
	if not ff: return
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ仢"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ代"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ令"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ以"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ仦"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ仧"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ仨"))
	if l1l11l_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ仩") not in url: l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡶࡤࡐࡩࡳࡻࠧ࡞࡝ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫࡢࠨ仪"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ仫"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ们"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ仭"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ仮"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ仯"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ仰"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡧࡨ࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ仱"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡨࡩ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ仲"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡩࡪࠧ仳"))
	l1l1ll1l1l1_l1_ = l1111lll111_l1_(l1l11l_l1_ (u"ࡸ่๊ࠫࠠใ๊สส๊ࠦวๅฬื฾๏๊ࠧ仴"))
	l1l1ll1l1ll_l1_ = l1111lll111_l1_(l1l11l_l1_ (u"ࡹ้ࠬไࠡษ็ๅ๏ี๊้้สฮࠬ仵"))
	l11l1l1l1l1l_l1_ = l1111lll111_l1_(l1l11l_l1_ (u"ࡺ࠭ใๅࠢส่็์่ศฬࠪ件"))
	l1llll1l111l_l1_ = [l1l1ll1l1l1_l1_,l1l1ll1l1ll_l1_,l11l1l1l1l1l_l1_,l1l11l_l1_ (u"࠭ࡁ࡭࡮ࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭价"),l1l11l_l1_ (u"ࠧࡂ࡮࡯ࠤࡻ࡯ࡤࡦࡱࡶࠫ仸"),l1l11l_l1_ (u"ࠨࡃ࡯ࡰࠥࡩࡨࡢࡰࡱࡩࡱࡹࠧ仹")]
	l11l1l1ll11l_l1_,gg = l11l1l1llll1_l1_(ff,index,l11l1ll1l11l_l1_)
	if l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ仺") in str(type(gg)) and any(value in str(gg[0]) for value in l1llll1l111l_l1_): del gg[0]
	for index2 in range(len(gg)):
		l11l1ll1l11l_l1_ = []
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ任"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ仼"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ份"))
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ仾"))		#4
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ仿"))		#7
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ伀"))		#6
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ企"))		#5
		l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣࠢ伂"))
		l11l1l1l1lll_l1_,item = l11l1l1llll1_l1_(gg,index2,l11l1ll1l11l_l1_)
		#if l11l1l1l1lll_l1_ not in [l1l11l_l1_ (u"ࠫ࠷࠭伃"),l1l11l_l1_ (u"ࠬ࠺ࠧ伄"),l1l11l_l1_ (u"࠭࠵ࠨ伅")]: l11ll11l11ll_l1_(item)		# 2,4,7
		#else: l11ll11l11ll_l1_(item,url,str(index2))
		l11ll11l11ll_l1_(item,url,str(index2))
		if l11l1l1l1lll_l1_==l1l11l_l1_ (u"ࠧ࠵ࠩ伆"):
			try:
				hh = item[l1l11l_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ伇")][l1l11l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ伈")][l1l11l_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ伉")][l1l11l_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ伊")]
				for l11ll1111111_l1_ in range(len(hh)):
					l11l1l1lll11_l1_ = hh[l11ll1111111_l1_]
					l11ll11l11ll_l1_(l11l1l1lll11_l1_)
			except: pass
	l11l1lll1111_l1_ = False
	if l1l11l_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ伋") not in url and l11l1l1ll11l_l1_==l1l11l_l1_ (u"࠭࠸ࠨ伌"): l11l1lll1111_l1_ = True
	if l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ伍") in data2: l11ll111l1l1_l1_,key,l11ll111l111_l1_,l11ll11111ll_l1_,token,l11l1lll1l11_l1_ = data2.split(l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ伎"))
	else: l11ll111l1l1_l1_,key,l11ll111l111_l1_,l11ll11111ll_l1_,token,l11l1lll1l11_l1_ = l1l11l_l1_ (u"ࠩࠪ伏"),l1l11l_l1_ (u"ࠪࠫ伐"),l1l11l_l1_ (u"ࠫࠬ休"),l1l11l_l1_ (u"ࠬ࠭伒"),l1l11l_l1_ (u"࠭ࠧ伓"),l1l11l_l1_ (u"ࠧࠨ伔")
	url2,l1llllll11ll_l1_ = l1l11l_l1_ (u"ࠨࠩ伕"),l1l11l_l1_ (u"ࠩࠪ伖")
	if menuItemsLIST:
		l11l1ll11111_l1_ = str(menuItemsLIST[-1][1])
		if   menu_name+l1l11l_l1_ (u"ࠪࡇࡍࡔࡌࠨ众") in l11l1ll11111_l1_: l1llllll11ll_l1_ = l1l11l_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭优")
		elif menu_name+l1l11l_l1_ (u"࡛ࠬࡓࡆࡔࠪ伙") in l11l1ll11111_l1_: l1llllll11ll_l1_ = l1l11l_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ会")
		elif menu_name+l1l11l_l1_ (u"ࠧࡍࡋࡖࡘࠬ伛") in l11l1ll11111_l1_: l1llllll11ll_l1_ = l1l11l_l1_ (u"ࠨࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ伜")
	if l1l11l_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠥࠫ伝") in html and l1l11l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ伞") not in url and not l11l1lll1111_l1_ and l1l11l_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩ࠭伟") not in url:	# and (index!=l1l11l_l1_ (u"ࠬ࠭传") or l1l11l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ伡") in url or l1l11l_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭伢") in url or l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ伣") in url or l1l11l_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ伤") in url):
		url2 = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ伥")+l11ll111l111_l1_
	elif l1l11l_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ伦") in html and l1l11l_l1_ (u"ࠬࡨࡰ࠾ࠩ伧") not in url and l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ伨") in url or l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ伩") in url:
		url2 = l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ伪")+key
	elif l1l11l_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ伫") in html and l1l11l_l1_ (u"ࠪࡦࡵࡃࠧ伬") not in url:
		url2 = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ伭")+key
	if url2: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ伮"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ伯"),url2,144,l1llllll11ll_l1_,l1l11l_l1_ (u"ࠧࠨ估"),data2)
	return
def l11l1l1llll1_l1_(l1lllllll111_l1_,l1111111l11_l1_,l11l1lll111l_l1_):
	cc = l1lllllll111_l1_
	ff,index = l1lllllll111_l1_,l1111111l11_l1_
	gg,index2 = l1lllllll111_l1_,l1111111l11_l1_
	item,render = l1lllllll111_l1_,l1111111l11_l1_
	count = len(l11l1lll111l_l1_)
	for ii in range(count):
		try:
			out = eval(l11l1lll111l_l1_[ii])
			#if isinstance(out,dict): out = l1l11l_l1_ (u"ࠨࠩ伱")
			return str(ii+1),out
		except: pass
	return l1l11l_l1_ (u"ࠩࠪ伲"),l1l11l_l1_ (u"ࠪࠫ伳")
def l11ll11lll1l_l1_(item):
	try: l11l1lllllll_l1_ = list(item.keys())[0]
	except: return False,l1l11l_l1_ (u"ࠫࠬ伴"),l1l11l_l1_ (u"ࠬ࠭伵"),l1l11l_l1_ (u"࠭ࠧ伶"),l1l11l_l1_ (u"ࠧࠨ伷"),l1l11l_l1_ (u"ࠨࠩ伸"),l1l11l_l1_ (u"ࠩࠪ伹"),l1l11l_l1_ (u"ࠪࠫ伺")
	succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_ = False,l1l11l_l1_ (u"ࠫࠬ伻"),l1l11l_l1_ (u"ࠬ࠭似"),l1l11l_l1_ (u"࠭ࠧ伽"),l1l11l_l1_ (u"ࠧࠨ伾"),l1l11l_l1_ (u"ࠨࠩ伿"),l1l11l_l1_ (u"ࠩࠪ佀"),l1l11l_l1_ (u"ࠪࠫ佁")
	#WRITE_THIS(l1l11l_l1_ (u"ࠫࠬ佂"),str(item))
	render = item[l11l1lllllll_l1_]
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ佃"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ佄"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ佅"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ但"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ佇"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ佈"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ佉"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ佊"))
	l11l1l1l1lll_l1_,title = l11l1l1llll1_l1_(item,render,l11l1ll1l11l_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ佋"),l1l11l_l1_ (u"ࠧࠨ佌"),l1l11l_l1_ (u"ࠨࠩ位"),title)
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ低"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ住"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ佐"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ佑")) # required for l1lllll1l1ll_l1_ l11l1lll1111_l1_
	l11l1l1l1lll_l1_,l1111l_l1_ = l11l1l1llll1_l1_(item,render,l11l1ll1l11l_l1_)
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ佒"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ体"))
	l11l1l1l1lll_l1_,img = l11l1l1llll1_l1_(item,render,l11l1ll1l11l_l1_)
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ佔"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ何"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ佖"))
	l11l1l1l1lll_l1_,count = l11l1l1llll1_l1_(item,render,l11l1ll1l11l_l1_)
	l11l1ll1l11l_l1_ = []
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ佗"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ佘"))
	l11l1ll1l11l_l1_.append(l1l11l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ余"))
	l11l1l1l1lll_l1_,duration = l11l1l1llll1_l1_(item,render,l11l1ll1l11l_l1_)
	if l1l11l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ佚") in duration: duration,l1ll111111l_l1_ = l1l11l_l1_ (u"ࠨࠩ佛"),l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ作")
	if l1l11l_l1_ (u"้ࠪออิาࠩ佝") in duration: duration,l1ll111111l_l1_ = l1l11l_l1_ (u"ࠫࠬ佞"),l1l11l_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭佟")
	if l1l11l_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭你") in list(render.keys()):
		l11ll11l1l11_l1_ = str(render[l1l11l_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ佡")])
		if l1l11l_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ佢") in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠩࠧ࠾ࠬ佣")
		if l1l11l_l1_ (u"ࠪࡐࡎ࡜ࡅࠡࡐࡒ࡛ࠬ佤") in l11ll11l1l11_l1_: l1ll111111l_l1_ = l1l11l_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ佥")
		if l1l11l_l1_ (u"ࠬࡈࡵࡺࠩ佦") in l11ll11l1l11_l1_ or l1l11l_l1_ (u"࠭ࡒࡦࡰࡷࠫ佧") in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠧࠥࠦ࠽ࠫ佨")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡶ่ࠩฬฬฺัࠨ佩")) in l11ll11l1l11_l1_: l1ll111111l_l1_ = l1l11l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ佪")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡸูࠫืวยࠩ佫")) in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠫࠩࠪ࠺ࠨ佬")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡺ࠭วิฬษะฬืࠧ佭")) in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"࠭ࠤࠥ࠼ࠪ佮")
		if l1111lll111_l1_(l1l11l_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ佯")) in l11ll11l1l11_l1_: l11l1llllll1_l1_ = l1l11l_l1_ (u"ࠨࠦ࠽ࠫ佰")
	l1111l_l1_ = escapeUNICODE(l1111l_l1_)
	if l1111l_l1_ and l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ佱") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
	img = img.split(l1l11l_l1_ (u"ࠪࡃࠬ佲"))[0]
	if  img and l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ佳") not in img: img = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ佴")+img
	title = escapeUNICODE(title)
	if l11l1llllll1_l1_: title = l11l1llllll1_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠩ併")+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l11l_l1_ (u"ࠧ࠭ࠩ佶"),l1l11l_l1_ (u"ࠨࠩ佷"))
	count = count.replace(l1l11l_l1_ (u"ࠩ࠯ࠫ佸"),l1l11l_l1_ (u"ࠪࠫ佹"))
	count = re.findall(l1l11l_l1_ (u"ࠫࡡࡪࠫࠨ佺"),count)
	if count: count = count[0]
	else: count = l1l11l_l1_ (u"ࠬ࠭佻")
	return True,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_
def l11ll11l11ll_l1_(item,url=l1l11l_l1_ (u"࠭ࠧ佼"),index=l1l11l_l1_ (u"ࠧࠨ佽")):
	succeeded,title,l1111l_l1_,img,count,duration,l1ll111111l_l1_,l11l1llllll1_l1_ = l11ll11lll1l_l1_(item)
	#if l1l11l_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ佾") in url and index==l1l11l_l1_ (u"ࠩ࠳ࠫ使"):
	#	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侀"),menu_name+title,url,144)
	#	return
	if not succeeded: return
	elif l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ侁") in str(item): return	# l11ll111l111_l1_ not items
	elif l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ侂") in str(item): return			# l11ll11l1111_l1_ not items
	elif not l1111l_l1_ and l1l11l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ侃") in url: return			# l111ll111_l1_ l11l1l11lll1_l1_ list not items
	elif title and not l1111l_l1_ and (l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭侄") in url or l1l11l_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ侅") in str(item) or url==l11lll_l1_):
		title = l1l11l_l1_ (u"ࠩࡀࡁࡂࠦࠧ來")+title+l1l11l_l1_ (u"ࠪࠤࡂࡃ࠽ࠨ侇")
		addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ侈"),menu_name+title,l1l11l_l1_ (u"ࠬ࠭侉"),9999)
	elif title and l1l11l_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ侊") in str(item):
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ例"),menu_name+title,l1l11l_l1_ (u"ࠨࠩ侌"),9999)
	elif l1l11l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ侍") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侎"),menu_name+title,l1111l_l1_,144,img,index)
	elif not title: return
	elif l1ll111111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ侏"),menu_name+l1ll111111l_l1_+title,l1111l_l1_,143,img)
	#elif l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ侐") in l1111l_l1_ and l1l11l_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭侑") not in l1111l_l1_ and l1l11l_l1_ (u"ࠧࡵ࠿࠳ࠫ侒") not in l1111l_l1_:
	#	l11ll11l111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠨ࠯ࠬࡂ࠭ࠩ࠭侓"),l1111l_l1_,re.DOTALL)
	#	l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ侔")+l11ll11l111l_l1_[0]
	#	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ侕"),menu_name+l1l11l_l1_ (u"ࠫࡑࡏࡓࡕࠩ侖")+count+l1l11l_l1_ (u"ࠬࡀࠠࠡࠩ侗")+title,l1111l_l1_,144,img)
	elif l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ侘") in l1111l_l1_ or l1l11l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ侙") in l1111l_l1_:
		if l1l11l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ侚") in l1111l_l1_ and l1l11l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ供") not in l1111l_l1_:
			l11ll11l111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ侜"),1)[1]
			l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭依")+l11ll11l111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侞"),menu_name+l1l11l_l1_ (u"࠭ࡌࡊࡕࡗࠫ侟")+count+l1l11l_l1_ (u"ࠧ࠻ࠢࠣࠫ侠")+title,l1111l_l1_,144,img)
		else:
			l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ価"),1)[0]
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ侢"),menu_name+title,l1111l_l1_,143,img,duration)
	else:
		type = l1l11l_l1_ (u"ࠪࠫ侣")
		if not l1111l_l1_: l1111l_l1_ = url
		#if l1l11l_l1_ (u"ࠫࡸࡹ࠽ࠨ侤") in l1111l_l1_: l1111l_l1_ = url
		#elif l1l11l_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪ࠽ࠨ侥") in l1111l_l1_: l1111l_l1_ = url		# not needed it will stop l11l1l1lll1l_l1_ l1lllll1l1ll_l1_ l11l1lll1111_l1_
		elif not any(value in l1111l_l1_ for value in [l1l11l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ侦"),l1l11l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ侧"),l1l11l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ侨"),l1l11l_l1_ (u"ࠩ࠲ࡪࡪࡧࡴࡶࡴࡨࡨࠬ侩"),l1l11l_l1_ (u"ࠪࡷࡸࡃࠧ侪"),l1l11l_l1_ (u"ࠫࡧࡶ࠽ࠨ侫")]):
			if l1l11l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ侬")	in l1111l_l1_ or l1l11l_l1_ (u"࠭࠯ࡤ࠱ࠪ侭") in l1111l_l1_: type = l1l11l_l1_ (u"ࠧࡄࡊࡑࡐࠬ侮")+count+l1l11l_l1_ (u"ࠨ࠼ࠣࠤࠬ侯")
			if l1l11l_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ侰") in l1111l_l1_: type = l1l11l_l1_ (u"࡙ࠪࡘࡋࡒࠨ侱")+count+l1l11l_l1_ (u"ࠫ࠿ࠦࠠࠨ侲")
			index,l11ll11lll11_l1_ = l1l11l_l1_ (u"ࠬ࠭侳"),l1l11l_l1_ (u"࠭ࠧ侴")
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ侵"),menu_name+type+title,l1111l_l1_,144,img,index)
	return
def l11l1ll1llll_l1_(url,data=l1l11l_l1_ (u"ࠨࠩ侶"),request=l1l11l_l1_ (u"ࠩࠪ侷")):
	global settings
	if not data: data = settings.getSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ侸"))
	#if l1l11l_l1_ (u"ࠫࡤࡥࠧ侹") in l11ll11lll11_l1_: l11ll11lll11_l1_ = l1l11l_l1_ (u"ࠬ࠭侺")
	#if l1l11l_l1_ (u"࠭ࡳࡴ࠿ࠪ侻") in url: url = url.split(l1l11l_l1_ (u"ࠧࡴࡵࡀࠫ侼"))[0]
	if request==l1l11l_l1_ (u"ࠨࠩ侽"): request = l1l11l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ侾")
	useragent = l1ll11ll1_l1_()
	headers2 = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ便"):useragent,l1l11l_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ俀"):l1l11l_l1_ (u"ࠬࡖࡒࡆࡈࡀ࡬ࡱࡃࡡࡳࠩ俁")}
	#headers2 = headers.copy()
	if l1l11l_l1_ (u"࠭࠺࠻࠼ࠪ係") in data: l11ll111l1l1_l1_,key,l11ll111l111_l1_,l11ll11111ll_l1_,token,l11l1lll1l11_l1_ = data.split(l1l11l_l1_ (u"ࠧ࠻࠼࠽ࠫ促"))
	else: l11ll111l1l1_l1_,key,l11ll111l111_l1_,l11ll11111ll_l1_,token,l11l1lll1l11_l1_ = l1l11l_l1_ (u"ࠨࠩ俄"),l1l11l_l1_ (u"ࠩࠪ俅"),l1l11l_l1_ (u"ࠪࠫ俆"),l1l11l_l1_ (u"ࠫࠬ俇"),l1l11l_l1_ (u"ࠬ࠭俈"),l1l11l_l1_ (u"࠭ࠧ俉")
	if l1l11l_l1_ (u"ࠧࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ俊") in url:
		data2 = {}
		data2[l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ俋")] = {l1l11l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ俌"):{l1l11l_l1_ (u"ࠥ࡬ࡱࠨ俍"):l1l11l_l1_ (u"ࠦࡦࡸࠢ俎"),l1l11l_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ俏"):l1l11l_l1_ (u"ࠨࡗࡆࡄࠥ俐"),l1l11l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ俑"):l11ll11111ll_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭俒"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ俓"))
	elif l1l11l_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ俔") in url and l11ll111l1l1_l1_:
		data2 = {l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ俕"):token}
		data2[l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭俖")] = {l1l11l_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ俗"):{l1l11l_l1_ (u"ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ俘"):l11ll111l1l1_l1_,l1l11l_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ俙"):l1l11l_l1_ (u"ࠤ࡚ࡉࡇࠨ俚"),l1l11l_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ俛"):l11ll11111ll_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ俜"),url,data2,headers2,True,True,l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠲࡯ࡦࠪ保"))
	elif l1l11l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ俞") in url and l11l1lll1l11_l1_:
		headers2.update({l1l11l_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ俟"):l1l11l_l1_ (u"ࠨ࠳ࠪ俠"),l1l11l_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭信"):l11ll11111ll_l1_})
		headers2.update({l1l11l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ俢"):l1l11l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ俣")+l11l1lll1l11_l1_})
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ俤"),url,l1l11l_l1_ (u"࠭ࠧ俥"),headers2,l1l11l_l1_ (u"ࠧࠨ俦"),l1l11l_l1_ (u"ࠨࠩ俧"),l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ俨"))
	else:
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ俩"),url,l1l11l_l1_ (u"ࠫࠬ俪"),headers2,l1l11l_l1_ (u"ࠬ࠭俫"),l1l11l_l1_ (u"࠭ࠧ俬"),l1l11l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ俭"))
	html = response.content
	tmp = re.findall(l1l11l_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ修"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ俯"),html,re.DOTALL|re.I)
	if tmp: l11ll11111ll_l1_ = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ俰"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ俱"),html,re.DOTALL|re.I)
	if tmp: l11ll111l1l1_l1_ = tmp[0]
	tmp = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ俲"),html,re.DOTALL|re.I)
	if tmp: l11ll111l111_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l11l_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ俳") in list(cookies.keys()): l11l1lll1l11_l1_ = cookies[l1l11l_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ俴")]
	data = l11ll111l1l1_l1_+l1l11l_l1_ (u"ࠨ࠼࠽࠾ࠬ俵")+key+l1l11l_l1_ (u"ࠩ࠽࠾࠿࠭俶")+l11ll111l111_l1_+l1l11l_l1_ (u"ࠪ࠾࠿ࡀࠧ俷")+l11ll11111ll_l1_+l1l11l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ俸")+token+l1l11l_l1_ (u"ࠬࡀ࠺࠻ࠩ俹")+l11l1lll1l11_l1_
	if request==l1l11l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭俺") and l1l11l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ俻") in html:
		l1l1ll11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ俼"),html,re.DOTALL)
		if not l1l1ll11l1_l1_: l1l1ll11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ俽"),html,re.DOTALL)
		l11l1ll1l1l1_l1_ = EVAL(l1l11l_l1_ (u"ࠪࡷࡹࡸࠧ俾"),l1l1ll11l1_l1_[0])
	elif request==l1l11l_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ俿") and l1l11l_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ倀") in html:
		l1l1ll11l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ倁"),html,re.DOTALL)
		l11l1ll1l1l1_l1_ = EVAL(l1l11l_l1_ (u"ࠧࡴࡶࡵࠫ倂"),l1l1ll11l1_l1_[0])
	elif l1l11l_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ倃") not in html: l11l1ll1l1l1_l1_ = EVAL(l1l11l_l1_ (u"ࠩࡶࡸࡷ࠭倄"),html)
	else: l11l1ll1l1l1_l1_ = l1l11l_l1_ (u"ࠪࠫ倅")
	#open(l1l11l_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡮ࡸࡵ࡮ࠨ倆"),l1l11l_l1_ (u"ࠬࡽࠧ倇")).write(str(l11l1ll1l1l1_l1_))
	#open(l1l11l_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ倈"),l1l11l_l1_ (u"ࠧࡸࠩ倉")).write(html)
	settings.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ倊"),data)
	return html,l11l1ll1l1l1_l1_,data
def l11ll11ll11l_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠩࠣࠫ個"),l1l11l_l1_ (u"ࠪ࠯ࠬ倌"))
	url2 = url+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ倍")+search
	ITEMS(url2)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧ倎"),l1l11l_l1_ (u"࠭ࠫࠨ倏"))
	url2 = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ倐")+search
	if not showdialogs:
		if l1l11l_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ們") in options: l11l1lll1ll1_l1_ = l1l11l_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ倒")
		elif l1l11l_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ倓") in options: l11l1lll1ll1_l1_ = l1l11l_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ倔")
		elif l1l11l_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ倕") in options: l11l1lll1ll1_l1_ = l1l11l_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭倖")
		url3 = url2+l11l1lll1ll1_l1_
	else:
		l11l1lllll1l_l1_,l11l1ll11ll1_l1_,title2 = [],[],l1l11l_l1_ (u"ࠧࠨ倗")
		l11l1ll1l111_l1_ = [l1l11l_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ倘"),l1l11l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ候"),l1l11l_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭倚"),l1l11l_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ倛"),l1l11l_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ倜")]
		l11ll111llll_l1_ = [l1l11l_l1_ (u"࠭ࠧ倝"),l1l11l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭倞"),l1l11l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ借"),l1l11l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ倠"),l1l11l_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ倡")]
		l11ll11l1ll1_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ倢"),l11l1ll1l111_l1_)
		if l11ll11l1ll1_l1_ == -1: return
		l11ll11l1l1l_l1_ = l11ll111llll_l1_[l11ll11l1ll1_l1_]
		html,c,data = l11l1ll1llll_l1_(url2+l11ll11l1l1l_l1_)
		if c:
			d = c[l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ倣")][l1l11l_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ値")][l1l11l_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ倥")][l1l11l_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ倦")][l1l11l_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ倧")][l1l11l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ倨")][l1l11l_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ倩")]
			for l11l1ll11l1l_l1_ in range(len(d)):
				group = d[l11l1ll11l1l_l1_][l1l11l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ倪")][l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ倫")]
				for l11ll11ll1l1_l1_ in range(len(group)):
					render = group[l11ll11ll1l1_l1_][l1l11l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ倬")]
					if l1l11l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭倭") in list(render.keys()):
						l1111l_l1_ = render[l1l11l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ倮")][l1l11l_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ倯")][l1l11l_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ倰")][l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ倱")]
						l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭倲"),l1l11l_l1_ (u"ࠧࠧࠩ倳"))
						title = render[l1l11l_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ倴")]
						title = title.replace(l1l11l_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ倵"),l1l11l_l1_ (u"ࠪࠫ倶"))
						if l1l11l_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ倷") in title: continue
						if l1l11l_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ倸") in title:
							title = l1l11l_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ倹")+title
							title2 = title
							l11l111l1_l1_ = l1111l_l1_
						if l1l11l_l1_ (u"ࠧหำอ๎อࠦอิสࠪ债") in title: continue
						title = title.replace(l1l11l_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭倻"),l1l11l_l1_ (u"ࠩࠪ值"))
						if l1l11l_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ倽") in title: continue
						if l1l11l_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭倾") in title:
							title = l1l11l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭倿")+title
							title2 = title
							l11l111l1_l1_ = l1111l_l1_
						if l1l11l_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ偀") in title: continue
						l11l1lllll1l_l1_.append(escapeUNICODE(title))
						l11l1ll11ll1_l1_.append(l1111l_l1_)
		if not title2: l11ll111ll11_l1_ = l1l11l_l1_ (u"ࠧࠨ偁")
		else:
			l11l1lllll1l_l1_ = [l1l11l_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ偂"),title2]+l11l1lllll1l_l1_
			l11l1ll11ll1_l1_ = [l1l11l_l1_ (u"ࠩࠪ偃"),l11l111l1_l1_]+l11l1ll11ll1_l1_
			l11ll11ll111_l1_ = DIALOG_SELECT(l1l11l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ偄"),l11l1lllll1l_l1_)
			if l11ll11ll111_l1_ == -1: return
			l11ll111ll11_l1_ = l11l1ll11ll1_l1_[l11ll11ll111_l1_]
		if l11ll111ll11_l1_: url3 = l11lll_l1_+l11ll111ll11_l1_
		elif l11ll11l1l1l_l1_: url3 = url2+l11ll11l1l1l_l1_
		else: url3 = url2
		l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩ࡭ࡱࡺࡥࡳ࠯ࡧࡶࡴࡶࡤࡰࡹࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡳࡦࡥࡷ࡭ࡴࡴࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡕࡩࡲࡵࡶࡦࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠫ࠱࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡱࡵࡸࠥࡨࡹࠨ࠮ࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ࠱ࡴࡪࡶ࡯ࡩࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠨࠢࠣ偅")
	ITEMS(url3)
	return
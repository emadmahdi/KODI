# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬᤲ")
def MAIN(mode,url):
	if   mode==330: results = l1ll1ll111_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l1ll111lll_l1_()
	elif mode==333: results = l1l1ll1ll1_l1_()
	elif mode==334: results = l1ll111l1l_l1_(url)
	else: results = False
	return results
def l1ll111l1l_l1_(l1l1llll11_l1_):
	try: os.remove(l1l1llll11_l1_.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᤳ")))
	except: os.remove(l1l1llll11_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᤴ"))
	return
def l1l1ll1ll1_l1_():
	message = l1l11l_l1_ (u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬᤵ")
	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᤶ"),l1l11l_l1_ (u"ࠨࠩᤷ"),l1l11l_l1_ (u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠศๆ่่ๆอสࠨᤸ"),message)
	return
def l1ll1ll111_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᤹"),l1l11l_l1_ (u"ࠫ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ᤺"),l1l11l_l1_ (u"᤻ࠬ࠭"),333)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᤼"),l1l11l_l1_ (u"ࠧห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧ᤽"),l1l11l_l1_ (u"ࠨࠩ᤾"),332)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᤿"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᥀"),l1l11l_l1_ (u"ࠫࠬ᥁"),9999)
	l1ll1l1111_l1_ = l1ll111l11_l1_()
	mtime = os.stat(l1ll1l1111_l1_).st_mtime
	files = []
	if kodi_version>18.99: l1ll11llll_l1_ = os.listdir(l1ll1l1111_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ᥂")))
	else: l1ll11llll_l1_ = os.listdir(l1ll1l1111_l1_.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ᥃")))
	for filename in l1ll11llll_l1_:
		if kodi_version>18.99: filename = filename.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ᥄"))
		if not filename.startswith(l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡪࡥࠧ᥅")): continue
		filepath = os.path.join(l1ll1l1111_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l1ll1l1l1l_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ᥆"))
			except: pass
			filename = filename.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ᥇"))
		filepath = os.path.join(l1ll1l1111_l1_,filename)
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᥈"),filename,filepath,331)
	return
def l1ll111l11_l1_():
	l1ll1l1111_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨ᥉"))
	if l1ll1l1111_l1_: return l1ll1l1111_l1_
	settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩ᥊"),l1l1ll1l11_l1_)
	return l1l1ll1l11_l1_
def l1ll111lll_l1_():
	l1ll1l1111_l1_ = l1ll111l11_l1_()
	l1ll11ll11_l1_ = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ᥋"),l1l11l_l1_ (u"ࠨࠩ᥌"),l1l11l_l1_ (u"ࠩࠪ᥍"),l1ll1l1111_l1_,l1l11l_l1_ (u"๋ࠪีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧ᥎"))
	if l1ll11ll11_l1_==1:
		newpath = l1ll11l11l_l1_(3,l1l11l_l1_ (u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨ᥏"),l1l11l_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯ࠫᥐ"),l1l11l_l1_ (u"࠭ࠧᥑ"),False,True,l1ll1l1111_l1_)
		yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧᥒ"),l1l11l_l1_ (u"ࠨࠩᥓ"),l1l11l_l1_ (u"ࠩࠪᥔ"),newpath,l1l11l_l1_ (u"๋ࠪีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧᥕ"))
		if yes==1:
			settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧᥖ"),newpath)
			DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ᥗ"),l1l11l_l1_ (u"࠭ࠧᥘ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᥙ"),l1l11l_l1_ (u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩᥚ"))
	#if not l1ll11ll11_l1_ or not yes: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᥛ"),l1l11l_l1_ (u"ࠪࠫᥜ"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᥝ"),l1l11l_l1_ (u"ࠬะๅࠡษ็฾ฬวࠠศๆ฼้้๐ษࠨᥞ"))
	return
def l1ll11l111_l1_(filename):
	l1ll1l1lll_l1_ = l1l11l_l1_ (u"࠭ࠧᥟ").join(ii for ii in filename if ii not in l1l11l_l1_ (u"ࠧ࡝࠱ࠥ࠾࠯ࡅ࠼࠿ࡾࠪᥠ")+half_triangular_colon)
	return l1ll1l1lll_l1_
def l1ll1111ll_l1_(url,videofiletype=l1l11l_l1_ (u"ࠨࠩᥡ"),website=l1l11l_l1_ (u"ࠩࠪᥢ")):
	#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪᥣ"),l1l11l_l1_ (u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫᥤ"))
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᥥ"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᥦ")+url+l1l11l_l1_ (u"ࠧࠡ࡟ࠪᥧ"))
	if not videofiletype: videofiletype = GET_VIDEOFILETYPE(url,website)
	#if not videofiletype:
	#	DIALOG_OK(l1l11l_l1_ (u"ࠨࠩᥨ"),l1l11l_l1_ (u"ࠩࠪᥩ"),l1l11l_l1_ (u"ࠪฮุ๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧᥪ"),l1l11l_l1_ (u"ࠫฬ๊ๅๅใ้๋ࠣࠦๆ้฻ࠣࠫᥫ")+videofiletype+l1l11l_l1_ (u"่ࠬࠦศๆหี๋อๅอࠢะห้๐วࠡ฼ํีࠥาว่ิ่ࠣฯำๅ๋ๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่๊๊แศฬࠪᥬ"))
	#	LOG_THIS(l1l11l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫᥭ"),LOGGING(script_name)+l1l11l_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡷࡽࡵ࡫࠯ࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ᥮")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ᥯"))
	#	return False
	l1ll1l1111_l1_ = l1ll111l11_l1_()
	l1ll1l11ll_l1_ = l1ll11lll1_l1_()
	filename = l1ll1l11ll_l1_.replace(l1l11l_l1_ (u"ࠩࠣࠫᥰ"),l1l11l_l1_ (u"ࠪࡣࠬᥱ"))
	filename = l1ll11l111_l1_(filename)
	#videofiletype = videofiletype.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᥲ"))
	filename = l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡢࠫᥳ")+str(int(now))[-4:]+l1l11l_l1_ (u"࠭࡟ࠨᥴ")+filename+videofiletype
	l1l1ll1lll_l1_ = os.path.join(l1ll1l1111_l1_,filename)
	headers = {}
	headers[l1l11l_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ᥵")] = l1l11l_l1_ (u"ࠨࠩ᥶")
	headers[l1l11l_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩ᥷")] = l1l11l_l1_ (u"ࠪ࠮࠴࠰ࠧ᥸")
	url = url.replace(l1l11l_l1_ (u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧ᥹"),l1l11l_l1_ (u"ࠬ࠭᥺"))
	if l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ᥻") in url:
		url2,useragent = url.rsplit(l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ᥼"),1)
		useragent = useragent.replace(l1l11l_l1_ (u"ࠨࡾࠪ᥽"),l1l11l_l1_ (u"ࠩࠪ᥾")).replace(l1l11l_l1_ (u"ࠪࠪࠬ᥿"),l1l11l_l1_ (u"ࠫࠬᦀ"))
	else: url2,useragent = url,None
	if not useragent: useragent = l1ll11ll1_l1_()
	if useragent: headers[l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᦁ")] = useragent
	if l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᦂ") in url2: url2,l1l1llllll_l1_ = url2.rsplit(l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᦃ"),1)
	else: url2,l1l1llllll_l1_ = url2,l1l11l_l1_ (u"ࠨࠩᦄ")
	url2 = url2.strip(l1l11l_l1_ (u"ࠩࡿࠫᦅ")).strip(l1l11l_l1_ (u"ࠪࠪࠬᦆ")).strip(l1l11l_l1_ (u"ࠫࢁ࠭ᦇ")).strip(l1l11l_l1_ (u"ࠬࠬࠧᦈ"))
	l1l1llllll_l1_ = l1l1llllll_l1_.replace(l1l11l_l1_ (u"࠭ࡼࠨᦉ"),l1l11l_l1_ (u"ࠧࠨᦊ")).replace(l1l11l_l1_ (u"ࠨࠨࠪᦋ"),l1l11l_l1_ (u"ࠩࠪᦌ"))
	if l1l1llllll_l1_:	headers[l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᦍ")] = l1l1llllll_l1_
	LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᦎ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᦏ")+url2+l1l11l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩᦐ")+str(headers)+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᦑ")+l1l1ll1lll_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫᦒ"))
	MegaByte = 1024*1024
	l1ll1l11l1_l1_ = 0
	try:
		l1ll1l111l_l1_ =	xbmc.getInfoLabel(l1l11l_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬᦓ"))
		l1ll1l111l_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡠࡩ࠱ࠧᦔ"),l1ll1l111l_l1_)
		l1ll1l11l1_l1_ = int(l1ll1l111l_l1_[0])
	except: pass
	if l1ll1l11l1_l1_==0:
		try:
			st = os.l1l1ll11ll_l1_(l1ll1l1111_l1_)
			l1ll1l11l1_l1_ = st.f_frsize*st.f_bavail//MegaByte
		except: pass
	if l1ll1l11l1_l1_==0:
		try:
			st = os.l1ll1l1ll1_l1_(l1ll1l1111_l1_)
			l1ll1l11l1_l1_ = st.f_frsize*st.f_bavail//MegaByte
		except: pass
	if l1ll1l11l1_l1_==0:
		try:
			import shutil
			total,l1ll111ll1_l1_,l1ll1111l1_l1_ = shutil.l1ll1ll1ll_l1_(l1ll1l1111_l1_)
			l1ll1l11l1_l1_ = l1ll1111l1_l1_//MegaByte
		except: pass
	if l1ll1l11l1_l1_==0:
		l1ll1lll11_l1_(l1l11l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪᦕ"),l1l11l_l1_ (u"๋ࠬำศฯฬࠤฬ๊สฯิํ๊๋ࠥฬ่๊็อࠬᦖ"),l1l11l_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐อะั้ࠣ็ีวา่ࠢืฬำษࠡษ็ฮำุ๊็ࠢส่ๆอั฻หࠣๅ๏ࠦฬ่ษี็ࠥ๎ูๅ์๊ࠤๆอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ้์๋ࠠ฻่่ࠥ฿ๆะๅࠣษ้๏ࠠฤ่ࠣ๎็๎ๅࠡ็หี๊า๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦศฮๆ๋ࠣีํࠠศๆุ่่๊ษࠡๆส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡไาࠤ๏ูศษࠢส้ฯ๊วยࠢฯ๋ฬุใࠡสส่๊๊แศฬࠣ์์ึวࠡใํ๋ࠥิื้ำฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอ฻่าหูࠣา๐อส๋่ࠢ์ึวࠡษ็ือฮࠠใษ่ࠤฬ๊ๅษำ่ะ๋ࠥฤใฬสࠤอ๋ๆฺࠢส่อืๆศ็ฯࠤ๊์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠪᦗ"),l1l11l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᦘ"))
		LOG_THIS(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᦙ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡹ࡮ࡥࠡࡦ࡬ࡷࡰࠦࡦࡳࡧࡨࠤࡸࡶࡡࡤࡧࠪᦚ"))
		return False
	import requests
	if videofiletype==l1l11l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᦛ"):
		l1l1lll_l1_,l1ll1lll_l1_ = l1ll1ll11l_l1_(url2,headers)
		#DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษࠩᦜ"), l1l1lll_l1_)
		#DIALOG_SELECT(l1l11l_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪᦝ"), l1ll1lll_l1_)
		if len(l1l1lll_l1_)==0:
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࠪᦞ"),l1l11l_l1_ (u"ࠧࠨᦟ"))
			return False
		elif len(l1l1lll_l1_)==1: selection = 0
		elif len(l1l1lll_l1_)>1:
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ᦠ"), l1l1lll_l1_)
			if selection == -1 :
				DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊สฮ็ํ่ࠬᦡ"),l1l11l_l1_ (u"ࠪࠫᦢ"))
				return False
		url2 = l1ll1lll_l1_[selection]
	filesize = 0
	if videofiletype==l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪᦣ"):
		l1l1ll1lll_l1_ = l1l1ll1lll_l1_.rsplit(l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫᦤ"))[0]+l1l11l_l1_ (u"࠭࠮࡮ࡲ࠷ࠫᦥ")
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᦦ"),url2,l1l11l_l1_ (u"ࠨࠩᦧ"),headers,l1l11l_l1_ (u"ࠩࠪᦨ"),l1l11l_l1_ (u"ࠪࠫᦩ"),l1l11l_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠳ࡄࡐ࡙ࡑࡐࡔࡇࡄࡠࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫᦪ"))
		l11l11l1_l1_ = response.content
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࠣࡆ࡚ࡗࡍࡓࡌ࠺࠯ࠬࡂ࡟ࡡࡴ࡜ࡳ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧᦫ"),l11l11l1_l1_+l1l11l_l1_ (u"࠭࡜࡯࡞ࡵࠫ᦬"),re.DOTALL)
		if not l1ll1111_l1_:
			LOG_THIS(l1l11l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ᦭"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤ࡙࡮ࡥࠡ࡯࠶ࡹ࠽ࠦࡦࡪ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡮ࡡࡷࡧࠣࡸ࡭࡫ࠠࡳࡧࡴࡹ࡮ࡸࡥࡥࠢ࡯࡭ࡳࡱࡳ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ᦮")+url2+l1l11l_l1_ (u"ࠩࠣࡡࠬ᦯"))
			return False
		l1111l_l1_ = l1ll1111_l1_[0]
		if not l1111l_l1_.startswith(l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᦰ")):
			if l1111l_l1_.startswith(l1l11l_l1_ (u"ࠫ࠴࠵ࠧᦱ")): l1111l_l1_ = url2.split(l1l11l_l1_ (u"ࠬࡀࠧᦲ"),1)[0]+l1l11l_l1_ (u"࠭࠺ࠨᦳ")+l1111l_l1_
			elif l1111l_l1_.startswith(l1l11l_l1_ (u"ࠧ࠰ࠩᦴ")): l1111l_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᦵ"))+l1111l_l1_
			else: l1111l_l1_ = url2.rsplit(l1l11l_l1_ (u"ࠩ࠲ࠫᦶ"),1)[0]+l1l11l_l1_ (u"ࠪ࠳ࠬᦷ")+l1111l_l1_
		response = requests.request(l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᦸ"),l1111l_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l1ll11111l_l1_ = len(l1ll1111_l1_)
		filesize = chunksize*l1ll11111l_l1_
	else:
		chunksize = 1*MegaByte
		response = requests.request(l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᦹ"),url2,headers=headers,verify=False,stream=True)
		if l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᦺ") in response.headers: filesize = int(response.headers[l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᦻ")])
		l1ll11111l_l1_ = int(filesize//chunksize)
	#l1ll1l1l11_l1_ = l1ll11111l_l1_+1
	l1ll1l1l11_l1_ = int(filesize//MegaByte)+1
	if filesize<21000:
		LOG_THIS(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᦼ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᦽ")+url2+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧᦾ")+str(l1ll1l1l11_l1_)+l1l11l_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᦿ")+str(l1ll1l11l1_l1_)+l1l11l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᧀ")+l1l1ll1lll_l1_+l1l11l_l1_ (u"࠭ࠠ࡞ࠩᧁ"))
		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᧂ"),l1l11l_l1_ (u"ࠨࠩᧃ"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᧄ"),l1l11l_l1_ (u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬᧅ"))
		return False
	l1l1lllll1_l1_ = 400
	l1l1lll11l_l1_ = l1ll1l11l1_l1_-l1ll1l1l11_l1_
	if l1l1lll11l_l1_<l1l1lllll1_l1_:
		LOG_THIS(l1l11l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩᧆ"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡐࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡩࡴ࡭ࠣࡷࡵࡧࡣࡦࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᧇ")+url2+l1l11l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᧈ")+str(l1ll1l1l11_l1_)+l1l11l_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᧉ")+str(l1ll1l11l1_l1_)+l1l11l_l1_ (u"ࠨࠢࡐࡆࠥ࠳ࠠࠨ᧊")+str(l1l1lllll1_l1_)+l1l11l_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ᧋")+l1l1ll1lll_l1_+l1l11l_l1_ (u"ࠪࠤࡢ࠭᧌"))
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ᧍"),l1l11l_l1_ (u"ࠬ࠭᧎"),l1l11l_l1_ (u"࠭ไศࠢํ์ัีࠠๆีสัฮࠦใศใํอ๊ࠥไหฯ่๎้࠭᧏"),l1l11l_l1_ (u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํࠠฮฮ่๋ࠥ࠭᧐")+str(l1ll1l1l11_l1_)+l1l11l_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦࠧ᧑")+str(l1ll1l11l1_l1_)+l1l11l_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ไๅ็ะหๆ฾ษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสา์๋ࠦๅีษๆ่ࠥ๐ฬษࠢศฬ็อมࠡࠩ᧒")+str(l1l1lllll1_l1_)+l1l11l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯࠦแศำ฽อࠥีวว็สࠤํํะศ่ࠢ฽๋อ็ࠡล้ࠤัํวำๅ่ࠣฬࠦส้ฮาࠤๆ๐็ࠡ็ึหาฯࠠไษไ๎ฮࠦไหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฬ๊ๅุๆ๋ฬࠬ᧓"))
		return False
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ᧔"),l1l11l_l1_ (u"ࠬ࠭᧕"),l1l11l_l1_ (u"࠭ࠧ᧖"),l1l11l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦฟࠨ᧗"),l1l11l_l1_ (u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฯฯ้์ࠦสใำํฬฬࠦࠧ᧘")+str(l1ll1l1l11_l1_)+l1l11l_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠหไิ๎ออࠠࠨ᧙")+str(l1ll1l11l1_l1_)+l1l11l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่่ࠦาสࠤฬ๊ๅๅใࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡๆ็ฮา๋๊ๅ่๊ࠢࠥอไฦ่อี๋ะࠠฦๆ์ࠤัํวำๅࠣ࠲ࠥํไࠡษ้ฮ๋ࠥสฤๅาࠤํะั๋ัࠣห้อำห็ิหึࠦศหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฤ࠭᧚"))
	if yes!=1:
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ᧛"),l1l11l_l1_ (u"ࠬ࠭᧜"),l1l11l_l1_ (u"࠭ࠧ᧝"),l1l11l_l1_ (u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬ᧞"))
		LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ᧟"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡶࡪ࡬ࡵࡴࡧࡧࠤࡹࡵࠠࡴࡶࡤࡶࡹࠦࡴࡩࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡵࡦࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ᧠")+url2+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ᧡")+l1l1ll1lll_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠧ᧢"))
		return False
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ᧣"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸࡺࡡࡳࡶࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠫ᧤"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l1ll1lll_l1_,l1l11l_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ᧥"))
	l1ll111111_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l1l1ll1lll_l1_,l1l11l_l1_ (u"ࠨࡹࡥࠫ᧦"))
	else: file = open(l1l1ll1lll_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ᧧")),l1l11l_l1_ (u"ࠪࡻࡧ࠭᧨"))
	if videofiletype==l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ᧩"): # l1ll111ll1_l1_ for l11l11l1_l1_ and l1l1lll1l1_l1_ chunks video files such as .l1ll11ll1l_l1_
		for ii in range(1,l1ll11111l_l1_+1):
			l1111l_l1_ = l1ll1111_l1_[ii-1]
			if not l1111l_l1_.startswith(l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᧪")):
				if l1111l_l1_.startswith(l1l11l_l1_ (u"࠭࠯࠰ࠩ᧫")): l1111l_l1_ = url2.split(l1l11l_l1_ (u"ࠧ࠻ࠩ᧬"),1)[0]+l1l11l_l1_ (u"ࠨ࠼ࠪ᧭")+l1111l_l1_
				elif l1111l_l1_.startswith(l1l11l_l1_ (u"ࠩ࠲ࠫ᧮")): l1111l_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ᧯"))+l1111l_l1_
				else: l1111l_l1_ = url2.rsplit(l1l11l_l1_ (u"ࠫ࠴࠭᧰"),1)[0]+l1l11l_l1_ (u"ࠬ࠵ࠧ᧱")+l1111l_l1_
			response = requests.request(l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ᧲"),l1111l_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			t2 = time.time()
			l1l1ll1l1l_l1_ = t2-t1
			l1l1lll111_l1_ = l1l1ll1l1l_l1_//ii
			l1ll11l1l1_l1_ = l1l1lll111_l1_*(l1ll11111l_l1_+1)
			l1l1lll1ll_l1_ = l1ll11l1l1_l1_-l1l1ll1l1l_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii//(l1ll11111l_l1_+1)),l1l11l_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ᧳"),l1l11l_l1_ (u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨ᧴"),str(ii*chunksize//MegaByte)+l1l11l_l1_ (u"ࠩ࠲ࠫ᧵")+str(l1ll1l1l11_l1_)+l1l11l_l1_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ᧶")+time.strftime(l1l11l_l1_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ᧷"),time.gmtime(l1l1lll1ll_l1_))+l1l11l_l1_ (u"ࠬࠦเࠨ᧸"))
			if pDialog.iscanceled():
				l1ll111111_l1_ = False
				break
	else: # l11lllll_l1_ and other l1ll11l1ll_l1_ file l1ll1ll1l1_l1_
		ii = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			ii = ii+1
			t2 = time.time()
			l1l1ll1l1l_l1_ = t2-t1
			l1l1lll111_l1_ = l1l1ll1l1l_l1_/ii
			l1ll11l1l1_l1_ = l1l1lll111_l1_*(l1ll11111l_l1_+1)
			l1l1lll1ll_l1_ = l1ll11l1l1_l1_-l1l1ll1l1l_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii/(l1ll11111l_l1_+1)),l1l11l_l1_ (u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧ᧹"),l1l11l_l1_ (u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧ᧺"),str(ii*chunksize//MegaByte)+l1l11l_l1_ (u"ࠨ࠱ࠪ᧻")+str(l1ll1l1l11_l1_)+l1l11l_l1_ (u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧ᧼")+time.strftime(l1l11l_l1_ (u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ᧽"),time.gmtime(l1l1lll1ll_l1_))+l1l11l_l1_ (u"ࠫࠥๆࠧ᧾"))
			if pDialog.iscanceled():
				l1ll111111_l1_ = False
				break
		response.close()
	file.close()
	pDialog.close()
	if not l1ll111111_l1_:
		LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ᧿"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᨀ")+url2+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᨁ")+l1l1ll1lll_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫᨂ"))
		DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᨃ"),l1l11l_l1_ (u"ࠪࠫᨄ"),l1l11l_l1_ (u"ࠫࠬᨅ"),l1l11l_l1_ (u"ࠬะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᨆ"))
		return True
	LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᨇ"),LOGGING(script_name)+l1l11l_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᨈ")+url2+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᨉ")+l1l1ll1lll_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠬᨊ"))
	DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᨋ"),l1l11l_l1_ (u"ࠫࠬᨌ"),l1l11l_l1_ (u"ࠬ࠭ᨍ"),l1l11l_l1_ (u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬᨎ"))
	return True
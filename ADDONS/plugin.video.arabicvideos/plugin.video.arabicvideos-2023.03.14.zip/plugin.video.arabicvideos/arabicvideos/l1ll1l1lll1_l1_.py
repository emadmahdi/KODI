# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ䝀")
menu_name = l1l11l_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬ䝁")
l11lll_l1_ = WEBSITES[script_name][0]
l1lll1l1ll_l1_ = WEBSITES[script_name][1]
l1lll1llll1_l1_ = WEBSITES[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l111l1_l1_(url)
	elif mode==52: results = l111ll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l11ll1ll111l_l1_()
	elif mode==56: results = l11ll1l1ll1l_l1_()
	elif mode==57: results = l11ll1l1lll1_l1_(url,1)
	elif mode==58: results = l11ll1l1lll1_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝂"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䝃"),l1l11l_l1_ (u"ࠩࠪ䝄"),59,l1l11l_l1_ (u"ࠪࠫ䝅"),l1l11l_l1_ (u"ࠫࠬ䝆"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䝇"))
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䝈"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䝉"),l1l11l_l1_ (u"ࠨࠩ䝊"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝋"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䝌")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ䝍"),l1l11l_l1_ (u"ࠬ࠭䝎"),56)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝏"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䝐")+menu_name+l1l11l_l1_ (u"ࠨษ็หๆ๊วๆࠩ䝑"),l1l11l_l1_ (u"ࠩࠪ䝒"),55)
	return l1l11l_l1_ (u"ࠪࠫ䝓")
def l11ll1ll111l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝔"),menu_name+l1l11l_l1_ (u"ࠬออะอࠣห้อแๅษ่ࠫ䝕"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ䝖"),51)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝗"),menu_name+l1l11l_l1_ (u"ࠨษไ่ฬ๋ࠠาษษะฮ࠭䝘"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ䝙"),51)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝚"),menu_name+l1l11l_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็หๆ๊วๆࠩ䝛"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ䝜"),51)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝝"),menu_name+l1l11l_l1_ (u"ࠧศใ็ห๊ࠦใๅษึ๎่๐ษࠨ䝞"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ䝟"),51)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䝠"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䝡"),l1l11l_l1_ (u"ࠫࠬ䝢"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䝣"),menu_name+l1l11l_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ䝤"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡼࡳࡵ࠭䝥"),57)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝦"),menu_name+l1l11l_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ䝧"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ䝨"),57)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝩"),menu_name+l1l11l_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ䝪"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ䝫"),57)
	return
def l11ll1l1ll1l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝬"),menu_name+l1l11l_l1_ (u"ࠨษะำะࠦวๅ็ึุ่๊วหࠩ䝭"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ䝮"),51)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝯"),menu_name+l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥืววฮฬࠫ䝰"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ䝱"),51)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝲"),menu_name+l1l11l_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊ๅิๆึ่ฬะࠧ䝳"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ䝴"),51)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝵"),menu_name+l1l11l_l1_ (u"ุ้๊ࠪำๅษอࠤ่๊วิ์ๆ๎ฮ࠭䝶"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ䝷"),51)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䝸"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䝹"),l1l11l_l1_ (u"ࠧࠨ䝺"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝻"),menu_name+l1l11l_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ䝼"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡹࡰࡲࠪ䝽"),57)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝾"),menu_name+l1l11l_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ䝿"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ䞀"),57)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䞁"),menu_name+l1l11l_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ䞂"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ䞃"),57)
	return
def l111l1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䞄"),l1l11l_l1_ (u"ࠫࠬ䞅"),url,url)
	if l1l11l_l1_ (u"ࠬࡅࠧ䞆") in url:
		parts = url.split(l1l11l_l1_ (u"࠭࠿ࠨ䞇"))
		url = parts[0]
		filter = l1l11l_l1_ (u"ࠧࡀࠩ䞈") + QUOTE(parts[1],l1l11l_l1_ (u"ࠨ࠿ࠩ࠾࠴ࠫࠧ䞉"))
	else: filter = l1l11l_l1_ (u"ࠩࠪ䞊")
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䞋"),l1l11l_l1_ (u"ࠫࠬ䞌"),filter,l1l11l_l1_ (u"ࠬ࠭䞍"))
	parts = url.split(l1l11l_l1_ (u"࠭࠯ࠨ䞎"))
	sort,page,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l11l_l1_ (u"ࠧࡺࡱࡳࠫ䞏"),l1l11l_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࠨ䞐"),l1l11l_l1_ (u"ࠩࡹ࡭ࡪࡽࡳࠨ䞑")]:
		if type==l1l11l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ䞒"): type1=l1l11l_l1_ (u"ࠫๆ๐ไๆࠩ䞓")
		elif type==l1l11l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䞔"): type1=l1l11l_l1_ (u"࠭ๅิๆึ่ࠬ䞕")
		#url = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠮ࡲࡵࡳ࡬ࡸࡡ࡮ࡵ࠲ࠫ䞖") + QUOTE(type1) + l1l11l_l1_ (u"ࠨ࠱ࠪ䞗") + page + l1l11l_l1_ (u"ࠩ࠲ࠫ䞘") + sort + filter
		url = l11lll_l1_ + l1l11l_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ䞙") + QUOTE(type1) + l1l11l_l1_ (u"ࠫ࠴࠭䞚") + page + l1l11l_l1_ (u"ࠬ࠵ࠧ䞛") + sort + filter
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䞜"),l1l11l_l1_ (u"ࠧࠨ䞝"),l1l11l_l1_ (u"ࠨࠩ䞞"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠩࠪ䞟"),l1l11l_l1_ (u"ࠪࠫ䞠"),l1l11l_l1_ (u"ࠫࠬ䞡"),l1l11l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䞢"))
		#items = re.findall(l1l11l_l1_ (u"࠭ࠢࡳࡧࡩࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡴࡵ࡮ࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡸࡥࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䞣"),html,re.DOTALL)
		items = re.findall(l1l11l_l1_ (u"ࠧࠣࡲ࡬ࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀࠤࡳࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠰ࡅࠢࡱࡧࡳ࡭ࡸࡵࡤࡦࡵࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡵࡸࡥࡴࡤࡤࡷࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䞤"),html,re.DOTALL)
		l1lll1l11ll_l1_=0
		for id,title,l11ll1l1l11l_l1_,img in items:
			l1lll1l11ll_l1_ += 1
			#img = l1lll1l1ll_l1_ + l1l11l_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ䞥") + img + l1l11l_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ䞦")
			img = l1lll1llll1_l1_ + l1l11l_l1_ (u"ࠪ࠳ࡻ࠸࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴ࡳࡡࡪࡰ࠲ࠫ䞧") + img + l1l11l_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ䞨")
			l1111l_l1_ = l11lll_l1_ + l1l11l_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ䞩") + id
			if type==l1l11l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ䞪"): addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䞫"),menu_name+title,l1111l_l1_,53,img)
			if type==l1l11l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䞬"): addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䞭"),menu_name+l1l11l_l1_ (u"ุ้๊ࠪำๅࠢࠪ䞮")+title,l1111l_l1_+l1l11l_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ䞯")+l11ll1l1l11l_l1_+l1l11l_l1_ (u"ࠬࡃࠧ䞰")+title+l1l11l_l1_ (u"࠭࠽ࠨ䞱")+img,52,img)
	else:
		if type==l1l11l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭䞲"): type1=l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ䞳")
		elif type==l1l11l_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ䞴"): type1=l1l11l_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䞵")
		url = l1lll1l1ll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡰࡳࡰࡰ࠲ࡷࡪࡲࡥࡤࡶࡨࡨ࠴࠭䞶") + sort + l1l11l_l1_ (u"ࠬ࠳ࠧ䞷") + type1 + l1l11l_l1_ (u"࠭࠭ࡘ࡙࠱࡮ࡸࡵ࡮ࠨ䞸")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨ䞹"),l1l11l_l1_ (u"ࠨࠩ䞺"),l1l11l_l1_ (u"ࠩࠪ䞻"),l1l11l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ䞼"))
		items = re.findall(l1l11l_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡩࡵࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䞽"),html,re.DOTALL)
		l1lll1l11ll_l1_=0
		for id,l11ll1l1l11l_l1_,img,title in items:
			l1lll1l11ll_l1_ += 1
			img = l1lll1l1ll_l1_ + l1l11l_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ䞾") + img + l1l11l_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭䞿")
			l1111l_l1_ = l11lll_l1_ + l1l11l_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ䟀") + id
			if type==l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ䟁"): addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䟂"),menu_name+title,l1111l_l1_,53,img)
			elif type==l1l11l_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䟃"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䟄"),menu_name+l1l11l_l1_ (u"๋ࠬำๅี็ࠤࠬ䟅")+title,l1111l_l1_+l1l11l_l1_ (u"࠭࠿ࡦࡲࡀࠫ䟆")+l11ll1l1l11l_l1_+l1l11l_l1_ (u"ࠧ࠾ࠩ䟇")+title+l1l11l_l1_ (u"ࠨ࠿ࠪ䟈")+img,52,img)
	title=l1l11l_l1_ (u"ุࠩๅาฯࠠࠨ䟉")
	if l1lll1l11ll_l1_==16:
		for l1lll1lllll_l1_ in range(1,13) :
			if not page==str(l1lll1lllll_l1_):
				#url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ䟊")+type+l1l11l_l1_ (u"ࠫ࠴࠭䟋")+str(l1lll1lllll_l1_)+l1l11l_l1_ (u"ࠬ࠵ࠧ䟌")+sort + filter
				url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ䟍")+type+l1l11l_l1_ (u"ࠧ࠰ࠩ䟎")+str(l1lll1lllll_l1_)+l1l11l_l1_ (u"ࠨ࠱ࠪ䟏")+sort + filter
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟐"),menu_name+title+str(l1lll1lllll_l1_),url,51)
	return
def l111ll_l1_(url):
	parts = url.split(l1l11l_l1_ (u"ࠪࡁࠬ䟑"))
	l11ll1l1l11l_l1_ = int(parts[1])
	name = UNQUOTE(parts[2])
	name = name.replace(l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ䟒"),l1l11l_l1_ (u"ࠬ࠭䟓"))
	img = parts[3]
	url = url.split(l1l11l_l1_ (u"࠭࠿ࠨ䟔"))[0]
	if l11ll1l1l11l_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠧࠨ䟕"),l1l11l_l1_ (u"ࠨࠩ䟖"),l1l11l_l1_ (u"ࠩࠪ䟗"),l1l11l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䟘"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬ䟙"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䟚"),block,re.DOTALL)
		l11ll1l1l11l_l1_ = int(items[-1])
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䟛"),l1l11l_l1_ (u"ࠧࠨ䟜"),l11ll1l1l11l_l1_,l1l11l_l1_ (u"ࠨࠩ䟝"))
	#name = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠤࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡯ࡴ࡭ࡧࠥ䟞") )
	#img = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠦ䟟") )
	for l1ll1ll_l1_ in range(l11ll1l1l11l_l1_,0,-1):
		l1111l_l1_ = url + l1l11l_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ䟠") + str(l1ll1ll_l1_)
		title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ䟡")+name+l1l11l_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ䟢")+str(l1ll1ll_l1_)
		addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䟣"),menu_name+title,l1111l_l1_,53,img)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠨࠩ䟤"),l1l11l_l1_ (u"ࠩࠪ䟥"),l1l11l_l1_ (u"ࠪࠫ䟦"),l1l11l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䟧"))
	l11ll1l1ll11_l1_ = re.findall(l1l11l_l1_ (u"๋ࠬส้ใิࠤ฾๊้ࠡึ๋ๅ๋ࠥวไีࠣฬ฾ี࠮ࠫࡁࡰࡳࡲ࡫࡮ࡵ࡞ࠫࠦ࠭࠴ࠪࡀࠫࠥࠫ䟨"),html,re.DOTALL)
	if l11ll1l1ll11_l1_:
		time = l11ll1l1ll11_l1_[1].replace(l1l11l_l1_ (u"࠭ࡔࠨ䟩"),l1l11l_l1_ (u"ࠧࠡࠢࠣࠤࠬ䟪"))
		DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䟫"),l1l11l_l1_ (u"ࠩࠪ䟬"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠬ䟭"),l1l11l_l1_ (u"ࠫ์ึวࠡษ็ๅ๏ี๊้ࠢึ๎่๎ๆࠡ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั๋ࠣีอࠠศๆ๋ๆฯ࠭䟮")+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ䟯")+time)
		return
	#if l1l11l_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ䟰") in html:
	#	DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䟱"),l1l11l_l1_ (u"ࠨࠩ䟲"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠫ䟳"),l1l11l_l1_ (u"๊ࠪ฾ะะาࠢ฼่๎่ࠦใ๊฼ࠤำ฽รࠨ䟴"))
	#	return
	l11ll1l11lll_l1_,l11ll1l1llll_l1_ = [],[]
	l11ll1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡻࡧࡲࠡࡱࡵ࡭࡬࡯࡮ࡠ࡮࡬ࡲࡰࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䟵"),html,re.DOTALL)[0]
	l11ll1l1l1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡼࡡࡳࠢࡥࡥࡨࡱࡵࡱࡡࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䟶"),html,re.DOTALL)[0]
	# l11l11l1_l1_ l1ll1111_l1_
	l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡨ࡭ࡵ࠽ࠤ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ䟷"),html,re.DOTALL)
	for server,l1111l_l1_ in l1ll1111_l1_:
		if l1l11l_l1_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠧ䟸") in server:
			server = l1l11l_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠡࡵࡨࡶࡻ࡫ࡲࠨ䟹")
			url = l11ll1l1l1ll_l1_ + l1111l_l1_
		else:
			server = l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴࠠࡴࡧࡵࡺࡪࡸࠧ䟺")
			url = l11ll1ll1111_l1_ + l1111l_l1_
		if l1l11l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䟻") in url:
			l11ll1l11lll_l1_.append(url)
			l11ll1l1llll_l1_.append(l1l11l_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠣࠫ䟼")+server)
		l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࠌ࡭࡫ࠦࠧ࠯࡯࠶ࡹ࠽࠭ࠠࡪࡰࠣࡹࡷࡲ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡹࡷࡲࠩࠋࠋࠌࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࠴ࡢࡃ࠽ࠨ࠯࠴ࠫ࠿ࠐࠉࠊࠋࠌ࡭ࡹ࡫࡭ࡴࡡࡸࡶࡱ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟࡯ࡣࡰࡩ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭࡭࠴ࡷ࠻ࠤࠥ࠭ࠫࡴࡧࡵࡺࡪࡸࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡥࡳ࡭ࡥࠩ࡮ࡨࡲ࠭ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࠪࠫ࠽ࠎࠎࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡷࡵࡰ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚࡛ࡪ࡟ࠬࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠤࡂࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࡝࡬ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠦࠧࠪ࡝࠳ࡡࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛ࡪ࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠣࠤࠥ࠭ࠬࠨࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࡨ࡬ࡰࡪࡺࡹࡱࡧ࠮ࠫࠥࠦࠧࠬࡵࡨࡶࡻ࡫ࡲࠬࠩࠣࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠤࠥࠦ䟽")
	# l11lllll_l1_ l1ll1111_l1_
	l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"࠭࡭ࡱ࠶࠽࠲࠯ࡅ࡟࡭࡫ࡱ࡯࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䟾"),html,re.DOTALL)
	l1ll1111_l1_ += re.findall(l1l11l_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䟿"),html,re.DOTALL)
	for server,l1111l_l1_ in l1ll1111_l1_:
		filename = l1111l_l1_.split(l1l11l_l1_ (u"ࠨ࠱ࠪ䠀"))[-1]
		filename = filename.replace(l1l11l_l1_ (u"ࠩࡩࡥࡱࡲࡢࡢࡥ࡮ࠫ䠁"),l1l11l_l1_ (u"ࠪࠫ䠂"))
		filename = filename.replace(l1l11l_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ䠃"),l1l11l_l1_ (u"ࠬ࠭䠄"))
		filename = filename.replace(l1l11l_l1_ (u"࠭࠭ࠨ䠅"),l1l11l_l1_ (u"ࠧࠨ䠆"))
		if l1l11l_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ䠇") in server:
			server = l1l11l_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ䠈")
			url = l11ll1l1l1ll_l1_ + l1111l_l1_
		else:
			server = l1l11l_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ䠉")
			url = l11ll1ll1111_l1_ + l1111l_l1_
		l11ll1l11lll_l1_.append(url)
		l11ll1l1llll_l1_.append(l1l11l_l1_ (u"ࠫࡲࡶ࠴ࠡࠢࠪ䠊")+server+l1l11l_l1_ (u"ࠬࠦࠠࠨ䠋")+filename)
	selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡖࡪࡦࡨࡳࠥࡗࡵࡢ࡮࡬ࡸࡾࡀࠧ䠌"), l11ll1l1llll_l1_)
	if selection == -1 : return
	url = l11ll1l11lll_l1_[selection]
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䠍"))
	return
def l11ll1l1lll1_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䠎"),l1l11l_l1_ (u"ࠩࠪ䠏"),url,url)
	if l1l11l_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䠐") in url: url2 = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳ู๊ไิๆࠪ䠑")
	else: url2 = l11lll_l1_ + l1l11l_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴็๊ๅ็ࠪ䠒")
	url2 = QUOTE(url2)
	html = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"࠭ࠧ䠓"),l1l11l_l1_ (u"ࠧࠨ䠔"),l1l11l_l1_ (u"ࠨࠩ䠕"),l1l11l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡋࡏࡌࡕࡇࡕࡗ࠲࠷ࡳࡵࠩ䠖"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䠗"),l1l11l_l1_ (u"ࠫࠬ䠘"),url,html)
	if type==1: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡵࡣࡩࡨࡲࡷ࡫ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䠙"),html,re.DOTALL)
	elif type==2: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䠚"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴࠧ䠛"),block,re.DOTALL)
	if type==1:
		for l11ll1l1l111_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠜"),menu_name+title,url+l1l11l_l1_ (u"ࠩࡂࡷࡺࡨࡧࡦࡰࡵࡩࡂ࠭䠝")+l11ll1l1l111_l1_,58)
	elif type==2:
		url,l11ll1l1l111_l1_ = url.split(l1l11l_l1_ (u"ࠪࡃࠬ䠞"))
		for country,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䠟"),menu_name+title,url+l1l11l_l1_ (u"ࠬࡅࡣࡰࡷࡱࡸࡷࡿ࠽ࠨ䠠")+country+l1l11l_l1_ (u"࠭ࠦࠨ䠡")+l11ll1l1l111_l1_,51)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ䠢"),l1l11l_l1_ (u"ࠨࠩ䠣"),search,search)
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠩࠣࠫ䠤"),l1l11l_l1_ (u"ࠪࠩ࠷࠶ࠧ䠥"))
	#response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䠦"), l11lll_l1_, l1l11l_l1_ (u"ࠬ࠭䠧"), l1l11l_l1_ (u"࠭ࠧ䠨"), True,l1l11l_l1_ (u"ࠧࠨ䠩"),l1l11l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䠪"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l1l1l1ll1_l1_ = cookies[l1l11l_l1_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࠪ䠫")]
	#l11ll1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࡢࡧࡸࡸࡦࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠪ䠬"),html,re.DOTALL)
	#l11ll1l1l1l1_l1_ = l11ll1l1l1l1_l1_[0]
	#payload = l1l11l_l1_ (u"ࠫࡤࡩࡳࡳࡨࡀࠫ䠭") + l11ll1l1l1l1_l1_ + l1l11l_l1_ (u"ࠬࠬࡱ࠾ࠩ䠮") + QUOTE(l1l1ll_l1_)
	#headers = { l1l11l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ䠯"):l1l11l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䠰") , l1l11l_l1_ (u"ࠨࡥࡲࡳࡰ࡯ࡥࠨ䠱"):l1l11l_l1_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡀࠫ䠲")+l1l1l1ll1_l1_ }
	#url = l11lll_l1_ + l1l11l_l1_ (u"ࠥ࠳ࡸ࡫ࡡࡳࡥ࡫ࠦ䠳")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䠴"), url, payload, headers, True,l1l11l_l1_ (u"ࠬ࠭䠵"),l1l11l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠴ࡱࡨࠬ䠶"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ䠷")+l1l1ll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䠸"),url,l1l11l_l1_ (u"ࠩࠪ䠹"),l1l11l_l1_ (u"ࠪࠫ䠺"),True,l1l11l_l1_ (u"ࠫࠬ䠻"),l1l11l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠳ࡰࡧࠫ䠼"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡧࡦࡰࡨࡶࡦࡲ࠭ࡣࡱࡧࡽ࠭࠴ࠪࡀࠫࡶࡩࡦࡸࡣࡩ࠯ࡥࡳࡹࡺ࡯࡮࠯ࡳࡥࡩࡪࡩ࡯ࡩࠪ䠽"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ䠾"),block,re.DOTALL)
	if items:
		for l1111l_l1_,img,title in items:
			#title = title.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䠿")).encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䡀"))
			url = l11lll_l1_ + l1111l_l1_
			if l1l11l_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭䡁") in url:
				if l1l11l_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ䡂") in url:
					title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ䡃")+title
					url = url.replace(l1l11l_l1_ (u"࠭࠿ࡦࡲࡀ࠵ࠬ䡄"),l1l11l_l1_ (u"ࠧࡀࡧࡳࡁ࠵࠭䡅"))
					url = url+l1l11l_l1_ (u"ࠨ࠿ࠪ䡆")+QUOTE(title)+l1l11l_l1_ (u"ࠩࡀࠫ䡇")+img
					addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䡈"),menu_name+title,url,52,img)
				else:
					title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡไ๎้๋ࠠࠨ䡉")+title
					addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䡊"),menu_name+title,url,53,img)
	#else: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䡋"),l1l11l_l1_ (u"ࠧࠨ䡌"),l1l11l_l1_ (u"ࠨࡰࡲࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬ䡍"),l1l11l_l1_ (u"ࠩ็หࠥะ่อั๊ࠣฯอฦอࠢ็่อำหࠨ䡎"))
	return
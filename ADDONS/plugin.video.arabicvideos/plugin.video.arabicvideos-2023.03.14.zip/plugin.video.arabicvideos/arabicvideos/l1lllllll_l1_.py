# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪౝ")
menu_name = l1l11l_l1_ (u"ࠩࡢࡊ࡙ࡓ࡟ࠨ౞")
l11lll_l1_ = WEBSITES[script_name][0]
l11111l1_l1_ = [l1l11l_l1_ (u"ࠪ࠵࠷࠹࠹ࠨ౟"),l1l11l_l1_ (u"ࠫ࠶࠸࠵࠱ࠩౠ"),l1l11l_l1_ (u"ࠬ࠷࠲࠵࠷ࠪౡ"),l1l11l_l1_ (u"࠭࠲࠱ࠩౢ"),l1l11l_l1_ (u"ࠧ࠲࠴࠸࠽ࠬౣ"),l1l11l_l1_ (u"ࠨ࠴࠴࠼ࠬ౤"),l1l11l_l1_ (u"ࠩ࠷࠼࠺࠭౥"),l1l11l_l1_ (u"ࠪ࠵࠷࠹࠸ࠨ౦"),l1l11l_l1_ (u"ࠫ࠶࠸࠵࠹ࠩ౧"),l1l11l_l1_ (u"ࠬ࠸࠹࠳ࠩ౨")]
l111111l_l1_ = [l1l11l_l1_ (u"࠭࠳࠱࠵࠳ࠫ౩"),l1l11l_l1_ (u"ࠧ࠷࠴࠻ࠫ౪")]
def MAIN(mode,url,text):
	if   mode==60: results = MENU()
	elif mode==61: results = l111l1_l1_(url,text)
	elif mode==62: results = l111ll_l1_(url)
	elif mode==63: results = PLAY(url)
	elif mode==64: results = l11111ll_l1_(text)
	elif mode==69: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ౫"),menu_name+l1l11l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ౬"),l1l11l_l1_ (u"ࠪࠫ౭"),69,l1l11l_l1_ (u"ࠫࠬ౮"),l1l11l_l1_ (u"ࠬ࠭౯"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ౰"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౱"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ౲")+menu_name+l1l11l_l1_ (u"่ࠩหࠥ๐สๆุ่ࠢฬํฯห้ࠣห้อๆࠨ౳"),l11lll_l1_,64,l1l11l_l1_ (u"ࠪࠫ౴"),l1l11l_l1_ (u"ࠫࠬ౵"),l1l11l_l1_ (u"ࠬࡸࡥࡤࡧࡱࡸࡤࡼࡩࡦࡹࡨࡨࡤࡼࡩࡥࡵࠪ౶"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౷"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ౸")+menu_name+l1l11l_l1_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨ౹"),l11lll_l1_,64,l1l11l_l1_ (u"ࠩࠪ౺"),l1l11l_l1_ (u"ࠪࠫ౻"),l1l11l_l1_ (u"ࠫࡲࡵࡳࡵࡡࡹ࡭ࡪࡽࡥࡥࡡࡹ࡭ࡩࡹࠧ౼"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ౽"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ౾")+menu_name+l1l11l_l1_ (u"ࠧศุํๅฯࠦๅละิหࠬ౿"),l11lll_l1_,64,l1l11l_l1_ (u"ࠨࠩಀ"),l1l11l_l1_ (u"ࠩࠪಁ"),l1l11l_l1_ (u"ࠪࡶࡪࡩࡥ࡯ࡶ࡯ࡽࡤࡧࡤࡥࡧࡧࡣࡻ࡯ࡤࡴࠩಂ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫಃ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ಄")+menu_name+l1l11l_l1_ (u"࠭แ๋ัํ์ࠥ฿ิ้ษษ๎ࠬಅ"),l11lll_l1_,64,l1l11l_l1_ (u"ࠧࠨಆ"),l1l11l_l1_ (u"ࠨࠩಇ"),l1l11l_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡡࡹ࡭ࡩࡹࠧಈ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಉ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨಊ")+menu_name+l1l11l_l1_ (u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭ಋ"),l11lll_l1_,61,l1l11l_l1_ (u"࠭ࠧಌ"),l1l11l_l1_ (u"ࠧࠨ಍"),l1l11l_l1_ (u"ࠨ࠯࠴ࠫಎ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಏ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧಐ")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ศาษ่ะࠥอไะ์้๎ฮ࠭಑"),l11lll_l1_,61,l1l11l_l1_ (u"ࠬ࠭ಒ"),l1l11l_l1_ (u"࠭ࠧಓ"),l1l11l_l1_ (u"ࠧ࠮࠴ࠪಔ"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨಕ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ಖ")+menu_name+l1l11l_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠤ࡛࡯ࡤࡦࡱࡶࠫಗ"),l11lll_l1_,61,l1l11l_l1_ (u"ࠫࠬಘ"),l1l11l_l1_ (u"ࠬ࠭ಙ"),l1l11l_l1_ (u"࠭࠭࠴ࠩಚ"))
	return l1l11l_l1_ (u"ࠧࠨಛ")
def l111l1_l1_(url,category):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩಜ"),l1l11l_l1_ (u"ࠩࠪಝ"),l1l11l_l1_ (u"ࠪࠫಞ"), category)
	cat = l1l11l_l1_ (u"ࠫࠬಟ")
	if category not in [l1l11l_l1_ (u"ࠬ࠳࠱ࠨಠ"),l1l11l_l1_ (u"࠭࠭࠳ࠩಡ"),l1l11l_l1_ (u"ࠧ࠮࠵ࠪಢ")]: cat = l1l11l_l1_ (u"ࠨࡁࡦࡥࡹࡃࠧಣ")+category
	url2 = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡱࡪࡴࡵࡠ࡮ࡨࡺࡪࡲ࠮ࡱࡪࡳࠫತ")+cat
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠪࠫಥ"),l1l11l_l1_ (u"ࠫࠬದ"),l1l11l_l1_ (u"ࠬ࠭ಧ"),l1l11l_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬನ"))
	items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭಩"),html,re.DOTALL)
	l1111111_l1_,l1111ll1_l1_ = False,False
	for l1111l_l1_,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪಪ"))
		if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧಫ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩಬ")+l1111l_l1_
		cat = re.findall(l1l11l_l1_ (u"ࠫࡨࡧࡴ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨಭ"),l1111l_l1_,re.DOTALL)[0]
		if category==cat: l1111111_l1_ = True
		elif l1111111_l1_ 	or (category==l1l11l_l1_ (u"ࠬ࠳࠱ࠨಮ") and cat in l11111l1_l1_) \
						or (category==l1l11l_l1_ (u"࠭࠭࠳ࠩಯ") and cat not in l111111l_l1_ and cat not in l11111l1_l1_) \
						or (category==l1l11l_l1_ (u"ࠧ࠮࠵ࠪರ") and cat in l111111l_l1_):
							if count==l1l11l_l1_ (u"ࠨ࠳ࠪಱ"): addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨಲ"),menu_name+title,l1111l_l1_,63)
							else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಳ"),menu_name+title,l1111l_l1_,61,l1l11l_l1_ (u"ࠫࠬ಴"),l1l11l_l1_ (u"ࠬ࠭ವ"),cat)
							l1111ll1_l1_ = True
	if not l1111ll1_l1_: l111ll_l1_(url)
	return
def l111ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"࠭ࠧಶ"),l1l11l_l1_ (u"ࠧࠨಷ"),True,l1l11l_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩಸ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪಹ"),l1l11l_l1_ (u"ࠪࠫ಺"),url , html)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ಻"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬ࡭ࡲࡪࡦࡢࡺ࡮࡫ࡷ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ಼ࠪ"),block,re.DOTALL)
	l1111l_l1_ = l1l11l_l1_ (u"࠭ࠧಽ")
	for img,title,l1111l_l1_ in items:
		title = title.replace(l1l11l_l1_ (u"ࠧࡂࡦࡧࠫಾ"),l1l11l_l1_ (u"ࠨࠩಿ")).replace(l1l11l_l1_ (u"ࠩࡷࡳࠥࡗࡵࡪࡥ࡮ࡰ࡮ࡹࡴࠨೀ"),l1l11l_l1_ (u"ࠪࠫು")).strip(l1l11l_l1_ (u"ࠫࠥ࠭ೂ"))
		if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪೃ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬೄ")+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭೅"),menu_name+title,l1111l_l1_,63,img)
	l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪೆ"),block,re.DOTALL)
	block=l1ll111_l1_[0]
	block=re.findall(l1l11l_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪೇ"),html,re.DOTALL)[0]
	items=re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬೈ"),block,re.DOTALL)
	url2 = url.split(l1l11l_l1_ (u"ࠫࡄ࠭೉"))[0]
	for l1111l_l1_,l1llllll1_l1_ in items:
		l1111l_l1_ = url2 + l1111l_l1_
		title = unescapeHTML(l1llllll1_l1_)
		title = l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫೊ") + title
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ೋ"),menu_name+title,l1111l_l1_,62)
	return l1111l_l1_
def PLAY(url):
	if l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫೌ") in url: url = l111ll_l1_(url)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠨ್ࠩ"),l1l11l_l1_ (u"ࠩࠪ೎"),True,l1l11l_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ೏"))
	items = re.findall(l1l11l_l1_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ೐"),html,re.DOTALL)
	url = items[0]
	if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ೑") not in url: url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ೒")+url
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭೓"))
	return
def l11111ll_l1_(category):
	payload = { l1l11l_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭೔") : category }
	url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼ࠯ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࠩೕ")
	headers = { l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩೖ") : l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ೗") }
	data = l1111l11_l1_(payload)
	html = OPENURL_CACHED(l111l11l_l1_,url,data,headers,True,l1l11l_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏ࠭ࡎࡑࡖࡘࡘ࠳࠱ࡴࡶࠪ೘"))
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬ࠧ೙"),html,re.DOTALL)
	for l1111l_l1_,title,img in items:
		title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩ೚"))
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭೛") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ೜")+l1111l_l1_
		addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩೝ"),menu_name+title,l1111l_l1_,63,img)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬೞ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭೟"): return
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧೠ"),l1l11l_l1_ (u"ࠧࠨೡ"),search, l11lll_l1_)
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠨࠢࠪೢ"),l1l11l_l1_ (u"ࠩ࠮ࠫೣ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡣࡷ࡫ࡳࡶ࡮ࡷ࠲ࡵ࡮ࡰࡀࡳࡸࡩࡷࡿ࠽ࠨ೤") + l1l1ll_l1_ # + l1l11l_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀ࠵ࠬ೥")
	l111ll_l1_(url)
	return
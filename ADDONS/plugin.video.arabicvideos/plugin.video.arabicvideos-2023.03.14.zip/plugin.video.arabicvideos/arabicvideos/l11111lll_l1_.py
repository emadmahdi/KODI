# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡨ࠳࠺ࡨࡦ࡮ࡤࡰ࠳ࡺࡶࠨᕸ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠸࡭࡫࡬ࡢ࡮࠱ࡸࡻ࠭ᕹ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯࠶࡫ࡩࡱࡧ࡬࠯ࡶࡹࠫᕺ")
script_name = l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ᕻ")
headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᕼ") : l1l11l_l1_ (u"࠭ࠧᕽ") }
menu_name = l1l11l_l1_ (u"ࠧࡠࡅࡐࡊࡤ࠭ᕾ")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l11l1l1l_l1_()
	elif mode==95: results = l111ll_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕿ"),menu_name+l1l11l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᖀ"),l1l11l_l1_ (u"ࠪࠫᖁ"),99,l1l11l_l1_ (u"ࠫࠬᖂ"),l1l11l_l1_ (u"ࠬ࠭ᖃ"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᖄ"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᖅ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᖆ"),l1l11l_l1_ (u"ࠩࠪᖇ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖈ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᖉ")+menu_name+l1l11l_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫᖊ"),l1l11l_l1_ (u"࠭ࠧᖋ"),94)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᖌ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᖍ")+menu_name+l1l11l_l1_ (u"ࠩส่ศำฯฬࠩᖎ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰࡦࡺࡥࡴࡶࠪᖏ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖐ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᖑ")+menu_name+l1l11l_l1_ (u"࠭วๅล฼่๎ࠦสใ์่ห๐࠭ᖒ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡪ࡯ࡧࡦࠬᖓ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖔ"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ᖕ")+menu_name+l1l11l_l1_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪᖖ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡻ࡯ࡥࡸࠩᖗ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖘ"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪᖙ")+menu_name+l1l11l_l1_ (u"ࠧศๆ่ฯอะࠧᖚ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡲ࡬ࡲࠬᖛ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖜ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᖝ")+menu_name+l1l11l_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪᖞ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡴࡥࡸࡏࡲࡺ࡮࡫ࡳࠨᖟ"),91)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖠ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᖡ")+menu_name+l1l11l_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᖢ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡱࡩࡼࡋࡰࡪࡵࡲࡨࡪࡹࠧᖣ"),91)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᖤ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᖥ"),l1l11l_l1_ (u"ࠬ࠭ᖦ"),9999)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖧ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᖨ")+menu_name+l1l11l_l1_ (u"ࠨฮา๎ิࠦวๅ็๋ๆ฾࠭ᖩ"),l11lll_l1_,91)
	html = OPENURL_CACHED(l1llll_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠩࠪᖪ"),headers,l1l11l_l1_ (u"ࠪࠫᖫ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᖬ"))
	#upper l11111l1l_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡡࡪࡰࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡳࡧࡶࠨᖭ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᖮ"),block,re.DOTALL)
	l1llll1_l1_ = [l1l11l_l1_ (u"ࠧศใ็ห๊ࠦไๅๅหหึࠦแใูࠪᖯ")]
	for l1111l_l1_,title in items:
		title = title.strip(l1l11l_l1_ (u"ࠨࠢࠪᖰ"))
		if not any(value in title for value in l1llll1_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖱ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᖲ")+menu_name+title,l1111l_l1_,91)
	return html
def ITEMS(url):
	if l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࠩᖳ") in url:
		url,search = url.split(l1l11l_l1_ (u"ࠬࡅࡴ࠾ࠩᖴ"))
		headers = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᖵ") : l1l11l_l1_ (u"ࠧࠨᖶ") , l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᖷ") : l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᖸ") }
		data = { l1l11l_l1_ (u"ࠪࡸࠬᖹ") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩᖺ"),url,data,headers,l1l11l_l1_ (u"ࠬ࠭ᖻ"),l1l11l_l1_ (u"࠭ࠧᖼ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬᖽ"))
		html = response.content
	else:
		headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᖾ") : l1l11l_l1_ (u"ࠩࠪᖿ") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫᗀ"),headers,l1l11l_l1_ (u"ࠫࠬᗁ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡊࡖࡈࡑࡘ࠳࠲࡯ࡦࠪᗂ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࡱࡴࡼࡩࡦࡵ࠰࡭ࡹ࡫࡭ࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷࡪࡴࡵࡴࠣࠩᗃ"),html,re.DOTALL)
	if l1ll111_l1_: block = l1ll111_l1_[0]
	else: block = l1l11l_l1_ (u"ࠧࠨᗄ")
	items = re.findall(l1l11l_l1_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡭ࡰࡸ࡬ࡩ࠲ࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᗅ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠩส่า๊โสࠩᗆ") in title and l1l11l_l1_ (u"ࠪ࠳ࡨ࠵ࠧᗇ") not in url and l1l11l_l1_ (u"ࠫ࠴ࡩࡡࡵ࠱ࠪᗈ") not in url:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡠ࠶࠭࠺࡟࠮ࠫᗉ"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᗊ")+l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗋ"),menu_name+title,l1111l_l1_,95,img)
					l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩᗌ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᗍ"),menu_name+title,l1111l_l1_,92,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗎ"),menu_name+title,l1111l_l1_,91,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩᗏ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᗐ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"࠭วๅืไัฮࠦࠧᗑ"),l1l11l_l1_ (u"ࠧࠨᗒ"))
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗓ"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨᗔ")+title,l1111l_l1_,91)
	return
def l111ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫᗕ"),headers,l1l11l_l1_ (u"ࠫࠬᗖ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᗗ"))
	img = re.findall(l1l11l_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᗘ"),html,re.DOTALL)
	img = img[0]
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸ࠳ࡰࡢࡰࡨࡰ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᗙ"),html,re.DOTALL)
	if l1ll111_l1_:
		name = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᗚ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪᗛ"))
			if l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᗜ") in name: name = name.split(l1l11l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᗝ"),1)[1]
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᗞ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᗟ"),menu_name+name+l1l11l_l1_ (u"ࠧࠡ࠯ࠣࠫᗠ")+title,l1111l_l1_,92,img)
	else:
		tmp = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡲࡺ࡮࡫ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗡ"),html,re.DOTALL)
		if tmp: l1111l_l1_,title = tmp[0]
		else: l1111l_l1_,title = url,name
		addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᗢ"),menu_name+title,l1111l_l1_,92,img)
	return
def PLAY(url):
	l1ll1lll_l1_,l11111ll1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫᗣ"),headers,l1l11l_l1_ (u"ࠫࠬᗤ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᗥ"))
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡴࡦࡺࡷ࠱ࡸ࡮ࡡࡥࡱࡺ࠾ࠥࡴ࡯࡯ࡧ࠾ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᗦ"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪᗧ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᗨ"),block,re.DOTALL)
		for l1111l_l1_ in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᗩ")
			l1ll1lll_l1_.append(l1111l_l1_)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡲࡦࡼ࠭ࡵࡣࡥࡷࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࠯ࡳࡥࡳ࡫࡬࠮࡯ࡲࡶࡪ࠭ᗪ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		# l1l1ll11l_l1_ l1ll1111_l1_
		items = re.findall(l1l11l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡩࡲࡨࡥࡥࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᗫ"),block,re.DOTALL)
		for id,l1111l_l1_ in items:
			title = l1l11l_l1_ (u"ู๊ࠬาใิࠤࠬᗬ")+id
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᗭ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᗮ")
			l1ll1lll_l1_.append(l1111l_l1_)
		# other l1ll1111_l1_
		items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᗯ"),block,re.DOTALL)
		for l1111l_l1_ in items:
			if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᗰ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩᗱ")+l1111l_l1_
			l1111l_l1_ = UNQUOTE(l1111l_l1_)
			l1ll1lll_l1_.append(l1111l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗲ"),url)
	return
def l11l1l1l_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭ᗳ"),headers,l1l11l_l1_ (u"࠭ࠧᗴ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ᗵ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧ࡯࡮ࡥࡧࡻ࠱ࡱࡧࡳࡵ࠯ࡰࡳࡻ࡯ࡥࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤ࡬ࡲࡩ࡫ࡸ࠮ࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࠧᗶ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᗷ"),block,re.DOTALL)
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࠫᗸ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗹ"),menu_name+title,l1111l_l1_,92,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗺ"),menu_name+title,l1111l_l1_,91,img)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"࠭ࠧᗻ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠧࠨᗼ"): return
	search = search.replace(l1l11l_l1_ (u"ࠨࠢࠪᗽ"),l1l11l_l1_ (u"ࠩ࠮ࠫᗾ"))
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡶࡀࠫᗿ")+search
	ITEMS(url)
	return
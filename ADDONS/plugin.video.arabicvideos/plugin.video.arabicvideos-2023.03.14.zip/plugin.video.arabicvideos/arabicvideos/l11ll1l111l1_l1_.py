# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
DIALOG_NOTIFICATION(l1l11l_l1_ (u"࡚ࠬࡅࡔࡖࠪ䣫"),l1l11l_l1_ (u"࠭ࡔࡆࡕࡗࠫ䣬"))
#url = l1l11l_l1_ (u"ࠧࡄ࠼࡟ࡠࡕࡵࡲࡵࡣࡥࡰࡪࠦࡐࡳࡱࡪࡶࡦࡳࡳ࡝࡞ࡎࡓࡉࡏ࡟ࡷ࠳࠻ࡣ࠻࠺ࡢࡪࡶ࡟ࡠࡐࡵࡤࡪ࡞࡟ࡴࡴࡸࡴࡢࡤ࡯ࡩࡤࡪࡡࡵࡣ࡟ࡠࡨࡧࡣࡩࡧ࡟ࡠࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࡞࡟ࡪ࡮ࡲࡥࡠ࠲࠻࠽࠻ࡥࡓࡉࡘࡢึ๏อัสࡡส่ึู่ๅࡡส่ศ฿ุๆࡡูࠫ࠮ࡥࠨฤสสิึࡥวๅฯ็์ฬา๊ࠪ࠰ࡰࡴ࠸࠭䣭")
#url = l1l11l_l1_ (u"ࠨࡥ࠽ࡠࡡࡧࡳࡥࡨ࠱ࡱࡵ࠹ࠧ䣮")
#url = l1l11l_l1_ (u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡹࡤࡧ࠰ࡰࡴ࠸࠭䣯")
#url = l1l11l_l1_ (u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡡࠡࡤࡥࡠࡡࡧࡳࡥࡨ࠱ࡱࡵ࠹ࠧ䣰")
url = l1l11l_l1_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢแฮื࠱ࡱࡵ࠹ࠧ䣱")
url = l1l11l_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡧ࡫࡯ࡩࡤ࠺࠸࠴࠶ࡢࡗࡍ࡜࡟ำ์สีฮࡥวๅำึ์้ࡥวๅล฼฼๊ࡥࠨึࠫࡢࠬศฮวัำࡢห้ำไ้ษฯ๎࠮࠴࡭ࡱ࠵ࠪ䣲")
#url = url.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䣳"))
xbmc.Player().play(url)
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪᴔ")
menu_name = l1l11l_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪᴕ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪᴖ"),l1l11l_l1_ (u"࠭วๅๅ็ࠫᴗ"),l1l11l_l1_ (u"ࠧ࡯࠱ࡄࠫᴘ"),l1l11l_l1_ (u"ࠨษ็้ื๐ฯࠨᴙ"),l1l11l_l1_ (u"ࠩๅูฮูࠦีไࠪᴚ")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l111l1_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l111ll_l1_(url)
	elif mode==434: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩᴛ")+text)
	elif mode==435: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᴜ")+text)
	elif mode==436: results = l1l1lll11_l1_(url)
	elif mode==437: results = l11l11ll1_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᴝ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭ᴞ"),l1l11l_l1_ (u"ࠧࠨᴟ"),l1l11l_l1_ (u"ࠨࠩᴠ"),l1l11l_l1_ (u"ࠩࠪᴡ"),l1l11l_l1_ (u"ࠪࠫᴢ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᴣ"))
	html = response.content
	l111llll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᴤ"),html,re.DOTALL)
	l111llll1_l1_ = l111llll1_l1_[0].strip(l1l11l_l1_ (u"࠭࠯ࠨᴥ"))
	l111llll1_l1_ = SERVER(l111llll1_l1_,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫᴦ"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴧ"),menu_name+l1l11l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᴨ"),l1l11l_l1_ (u"ࠪࠫᴩ"),439,l1l11l_l1_ (u"ࠫࠬᴪ"),l1l11l_l1_ (u"ࠬ࠭ᴫ"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴬ"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴭ"),menu_name+l1l11l_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫᴮ"),l111llll1_l1_,435)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᴯ"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭ᴰ"),l111llll1_l1_,434)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᴱ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᴲ"),l1l11l_l1_ (u"࠭ࠧᴳ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴴ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᴵ")+menu_name+l1l11l_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨᴶ"),l111llll1_l1_,431)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᴷ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᴸ")+menu_name+l1l11l_l1_ (u"ࠬอแๅษ่ࠤฬ๎ๆࠡๆส๎๋࠭ᴹ"),l111llll1_l1_+l1l11l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠷ࠧᴺ"),436)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴻ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᴼ")+menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬࠣหํ์ࠠๅษํ๊ࠬᴽ"),l111llll1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠱ࡦࡲ࡬࠲ࠩᴾ"),436)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴿ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᵀ")+menu_name+l1l11l_l1_ (u"࠭โศศ่อࠥะแึ์็๎ฮ࠭ᵁ"),l111llll1_l1_,437)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᵂ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᵃ"),l1l11l_l1_ (u"ࠩࠪᵄ"),9999)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᵅ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᵆ")+menu_name+l1l11l_l1_ (u"ࠬอไๆ็ํึฮ࠭ᵇ"),l111llll1_l1_,431,l1l11l_l1_ (u"࠭ࠧᵈ"),l1l11l_l1_ (u"ࠧࠨᵉ"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᵊ"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᵋ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᵌ")+menu_name+l1l11l_l1_ (u"ࠫศ็ไศ็ࠪᵍ"),l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷ࠴࠭ᵎ"),436)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᵏ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᵐ")+menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠩᵑ"),l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠰࠵࠴࠭ᵒ"),436)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫ࠦࠬᵓ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᵔ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		#if title==l1l11l_l1_ (u"ࠬอไาศํื๏ฯࠧᵕ"): title = l1l11l_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬᵖ")
		if title in l1llll1_l1_: continue
		if title==l1l11l_l1_ (u"ࠧศๆิส๏ู๊สࠩᵗ"): continue
		if l1l11l_l1_ (u"ࠨษ๋๊๊ࠥว๋่ࠪᵘ") in title: continue
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᵙ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᵚ")+menu_name+title,l1111l_l1_,431)
	return
def l11l11ll1_l1_(website=l1l11l_l1_ (u"ࠫࠬᵛ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᵜ"),website+l1l11l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭ᵝ"),l1l11l_l1_ (u"ࠧࠨᵞ"),l1l11l_l1_ (u"ࠨࠩᵟ"),l1l11l_l1_ (u"ࠩࠪᵠ"),l1l11l_l1_ (u"ࠪࠫᵡ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᵢ"))
	html = response.content
	l111llll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᵣ"),html,re.DOTALL)
	l111llll1_l1_ = l111llll1_l1_[0].strip(l1l11l_l1_ (u"࠭࠯ࠨᵤ"))
	l111llll1_l1_ = SERVER(l111llll1_l1_,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫᵥ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡏ࡭ࡸࡺࡄࡳࡱࡳࡩࡩࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬࡮ࡴࡧࡎࡣࡶࡸࡪࡸࠢࠨᵦ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᵧ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1llll1_l1_: continue
		l1111l_l1_ = website+l1l11l_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧᵨ")+category+l1l11l_l1_ (u"ࠫࡂ࠭ᵩ")+value
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵪ"),website+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪᵫ")+menu_name+title,l1111l_l1_,431)
	return
def	l1l1lll11_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨᵬ"),l1l11l_l1_ (u"ࠨࠩᵭ"),l1l11l_l1_ (u"ࠩࡖ࡙ࡇࡓࡅࡏࡗࠪᵮ"),url)
	#LOG_THIS(l1l11l_l1_ (u"ࠪࠫᵯ"),l1111l_l1_)
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨᵰ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᵱ"),url,l1l11l_l1_ (u"࠭ࠧᵲ"),l1l11l_l1_ (u"ࠧࠨᵳ"),l1l11l_l1_ (u"ࠨࠩᵴ"),l1l11l_l1_ (u"ࠩࠪᵵ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᵶ"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵷ"),menu_name+l1l11l_l1_ (u"ࠬอไอ็ํ฽ࠬᵸ"),url,431)
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ᵹ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭ᵺ"),block,re.DOTALL)
	for l11l1ll11_l1_,title in items:
		if title in l1llll1_l1_: continue
		url2 = l111llll1_l1_+l1l11l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡏࡲࡺ࡮࡫ࡳ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࡂ࡯ࡪࡿ࠽ࠨᵻ")+l11l1ll11_l1_
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᵼ"),menu_name+title,url2,431)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᵽ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᵾ"),l1l11l_l1_ (u"ࠬ࠭ᵿ"),9999)
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡊࡰࡱࡩࡷࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠭ᶀ"),html,re.DOTALL)
	#block = l1ll111_l1_[0]
	#items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧᶁ"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1llll1_l1_: continue
	#	if l1l11l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳ࠰ࠩᶂ") in url: url2 = l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡐࡳࡻ࡯ࡥࡴ࠱ࡗࡩࡷࡳࡳ࠯ࡲ࡫ࡴࡄ࠭ᶃ")+category+l1l11l_l1_ (u"ࠪࡁࠬᶄ")+value
	#	elif l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲࠭ᶅ") in url: url2 = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡥࡳ࡫ࡨࡷ࠴ࡍࡥࡵ࠰ࡳ࡬ࡵࡅࠧᶆ")+category+l1l11l_l1_ (u"࠭࠽ࠨᶇ")+value
	#	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶈ"),menu_name+title,url2,431)
	return
def l111l1_l1_(url,request=l1l11l_l1_ (u"ࠨࠩᶉ")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᶊ"),l1l11l_l1_ (u"ࠪࠫᶋ"),request,url)
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨᶌ"))
	items = []
	if l1l11l_l1_ (u"ࠬ࠵ࡔࡦࡴࡰࡷ࠳ࡶࡨࡱࠩᶍ") in url or l1l11l_l1_ (u"࠭࠯ࡈࡧࡷ࠲ࡵ࡮ࡰࠨᶎ") in url or l1l11l_l1_ (u"ࠧ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࠪᶏ") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫᶐ"):l1l11l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪᶑ"),l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᶒ"):l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫᶓ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪᶔ"),url2,data2,headers2,l1l11l_l1_ (u"࠭ࠧᶕ"),l1l11l_l1_ (u"ࠧࠨᶖ"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᶗ"))
		html = response.content
		block = html
	elif request==l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᶘ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᶙ"),url,l1l11l_l1_ (u"ࠫࠬᶚ"),l1l11l_l1_ (u"ࠬ࠭ᶛ"),l1l11l_l1_ (u"࠭ࠧᶜ"),l1l11l_l1_ (u"ࠧࠨᶝ"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬᶞ"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡍࡢࡶࡦ࡬ࡪࡹࡔࡢࡤ࡯ࡩࠧ࠭ᶟ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ᶠ"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᶡ"),url,l1l11l_l1_ (u"ࠬ࠭ᶢ"),l1l11l_l1_ (u"࠭ࠧᶣ"),l1l11l_l1_ (u"ࠧࠨᶤ"),l1l11l_l1_ (u"ࠨࠩᶥ"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᶦ"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠪᶧ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠫᶨ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᶩ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"࠭ๅีษ๊ำฮ࠭ᶪ"),l1l11l_l1_ (u"ࠧโ์็้ࠬᶫ"),l1l11l_l1_ (u"ࠨษ฽๊๏ฯࠧᶬ"),l1l11l_l1_ (u"ࠩๆ่๏ฮࠧᶭ"),l1l11l_l1_ (u"ࠪห฾๊ว็ࠩᶮ"),l1l11l_l1_ (u"ࠫ์ีวโࠩᶯ"),l1l11l_l1_ (u"๋ࠬศศำสอࠬᶰ"),l1l11l_l1_ (u"ู࠭าุࠪᶱ"),l1l11l_l1_ (u"ࠧๆ้ิะฬ์ࠧᶲ"),l1l11l_l1_ (u"ࠨษ็ฬํ๋ࠧᶳ")]
	for l1111l_l1_,title,img in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠩ࠲ࠫᶴ"))
		#l1111l_l1_ = unescapeHTML(l1111l_l1_)
		title = unescapeHTML(title)
		#title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬᶵ"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧᶶ"),title,re.DOTALL)
		if any(value in title for value in l111l11ll_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᶷ"),menu_name+title,l1111l_l1_,432,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"࠭วๅฯ็ๆฮ࠭ᶸ") in title:
			title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᶹ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᶺ"),menu_name+title,l1111l_l1_,433,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧᶻ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),menu_name+title,l1111l_l1_,431,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᶽ"),menu_name+title,l1111l_l1_,433,img)
	if request!=l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᶾ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᶿ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᷀"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭᷁") not in l1111l_l1_: l1111l_l1_ = l111llll1_l1_+l1111l_l1_
				l1111l_l1_ = unescapeHTML(l1111l_l1_)
				title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"᷂ࠩࠪ"): addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᷃"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪ᷄")+title,l1111l_l1_,431)
		l11l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᷅"),html,re.DOTALL)
		if l11l1l111_l1_:
			l1111l_l1_ = l11l1l111_l1_[0]
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᷆"),menu_name+l1l11l_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ᷇"),l1111l_l1_,431)
	return
def l111ll_l1_(url):
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ᷈"),l1l11l_l1_ (u"ࠩ࠴࠵࠶࠷ࠠࠡࠩ᷉")+url)
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠪࡹࡷࡲ᷊ࠧ"))
	l111l11l1_l1_,l1ll1lll1_l1_ = [],[]
	if l1l11l_l1_ (u"ࠫࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰࡩࡲࠪ᷋") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ᷌"):l1l11l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ᷍"),l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ᷎࠭"):l1l11l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ᷏")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ᷐࡚ࠧ"),url2,data2,headers2,l1l11l_l1_ (u"ࠪࠫ᷑"),l1l11l_l1_ (u"ࠫࠬ᷒"),l1l11l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᷓ"))
		html = response.content
		l1ll1lll1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᷔ"),url,l1l11l_l1_ (u"ࠧࠨᷕ"),l1l11l_l1_ (u"ࠨࠩᷖ"),l1l11l_l1_ (u"ࠩࠪᷗ"),l1l11l_l1_ (u"ࠪࠫᷘ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪᷙ"))
		html = response.content
		l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᷚ"),html,re.DOTALL)
		l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡆࡲ࡬ࡷࡴࡪࡥࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᷛ"),html,re.DOTALL)
	# l111lll1l_l1_
	if l111l11l1_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠧࠣࡱࡪ࠾࡮ࡳࡡࡨࡧࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᷜ"),html,re.DOTALL)
		img = img[0]
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᷝ"),block,re.DOTALL)
		for l11l11l111_l1_,l11l111lll_l1_,title in items:
			l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠲ࡵ࡮ࡰࡀࠩᷞ")+l1l11l_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡀࠫᷟ")+l11l111lll_l1_+l1l11l_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧᷠ")+l11l11l111_l1_
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷡ"),menu_name+title,l1111l_l1_,433,img)
	# l1l11l1_l1_
	elif l1ll1lll1_l1_:
		img = xbmc.getInfoLabel(l1l11l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᷢ"))
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫᷣ"),block,re.DOTALL)
		for l1111l_l1_,title,l1ll1ll_l1_ in items:
			title = title+l1l11l_l1_ (u"ࠨࠢࠪᷤ")+l1ll1ll_l1_
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᷥ"),menu_name+title,l1111l_l1_,432,img)
	return
def PLAY(url):
	url2 = url+l1l11l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫᷦ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᷧ"),url2,l1l11l_l1_ (u"ࠬ࠭ᷨ"),l1l11l_l1_ (u"࠭ࠧᷩ"),l1l11l_l1_ (u"ࠧࠨᷪ"),l1l11l_l1_ (u"ࠨࠩᷫ"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᷬ"))
	html = response.content
	l1ll1lll_l1_ = []
	l111llll1_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧᷭ"))
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠮ࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᷮ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1111l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᷯ"),block,re.DOTALL)
		if l1111l1l1_l1_:
			l1111l1l1_l1_ = l1111l1l1_l1_[0]
			#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧᷰ"),l1l11l_l1_ (u"ࠧࠨᷱ"),l1l11l_l1_ (u"ࠨࠩᷲ"),l1111l1l1_l1_)
			items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨᷳ"),block,re.DOTALL)
			for server,title in items:
				l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨᷴ")+server+l1l11l_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ᷵")+l1111l1l1_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᷶")+title+l1l11l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮᷷ࠧ")
				l1ll1lll_l1_.append(l1111l_l1_)
	# l1l11ll1l_l1_ l1111l_l1_
	l1l11ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡮࡬ࡲࡢ࡯ࡨࠦࡃࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ᷸ࠫࠥࠫ"),html,re.DOTALL)
	if l1l11ll1l_l1_:
		l1l11ll1l_l1_ = l1l11ll1l_l1_[0].replace(l1l11l_l1_ (u"ࠨ࡞ࡱ᷹ࠫ"),l1l11l_l1_ (u"᷺ࠩࠪ"))
		title = SERVER(l1l11ll1l_l1_,l1l11l_l1_ (u"ࠪࡲࡦࡳࡥࠨ᷻"))
		l1111l_l1_ = l1l11ll1l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᷼")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ᷽࠭")
		l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᷾"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿᷿ࠫ"),block,re.DOTALL)
		for l1111l_l1_,title,l1l1l1l1_l1_ in items:
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫḀ"),l1l11l_l1_ (u"ࠩࠪḁ"))
			if l1l1l1l1_l1_!=l1l11l_l1_ (u"ࠪࠫḂ"): l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩḃ")+l1l1l1l1_l1_
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ḅ")+title+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪḅ")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬḆ"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧḇ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠩࠪḈ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠪࠫḉ"): return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭Ḋ"),l1l11l_l1_ (u"ࠬࠫ࠲࠱ࠩḋ"))
	url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡀࡵࡀࠫḌ")+search
	l111l1_l1_(url)
	return
# ===========================================
#     l11l1l1ll_l1_ l111lll11_l1_ l111ll1l1_l1_
# ===========================================
def l11l1l1l1_l1_(url):
	url = url.split(l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫḍ"))[0]
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬḎ"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ḏ"),l111llll1_l1_,l1l11l_l1_ (u"ࠪࠫḐ"),l1l11l_l1_ (u"ࠫࠬḑ"),l1l11l_l1_ (u"ࠬ࠭Ḓ"),l1l11l_l1_ (u"࠭ࠧḓ"),l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩḔ"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࡓࡡࡴࡶࡨࡶࠧ࠭ḕ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + options block + category
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬࠫḖ"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111lllll_l1_(block):
	# value + name
	items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫḗ"),block,re.DOTALL)
	return items
def l11l11lll_l1_(url):
	#url = url.replace(l1l11l_l1_ (u"ࠫࡨࡧࡴ࠾ࠩḘ"),l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨḙ"))
	l11l1111l_l1_ = url.split(l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪḚ"))[0]
	l11l11111_l1_ = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫḛ"))
	url = url.replace(l11l1111l_l1_,l11l11111_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬḜ"),l1l11l_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄ࠭ḝ"))
	return url
def l11l11l11l_l1_(l11l11l_l1_,url):
	l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭Ḟ")) # l11ll1ll11_l1_ be l11lll111l_l1_
	url3 = url+l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨḟ")+l1llll11_l1_
	url3 = l11l11lll_l1_(url3)
	return url3
l1111l1_l1_ = [l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧḠ"),l1l11l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧḡ"),l1l11l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭Ḣ"),l1l11l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧḣ")]
l11ll1l_l1_ = [l1l11l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪḤ"),l1l11l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩḥ"),l1l11l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪḦ"),l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧḧ"),l1l11l_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨḨ"),l1l11l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨḩ")]
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪḪ"),l1l11l_l1_ (u"ࠩࠪḫ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫḬ"),l1l11l_l1_ (u"ࠫࠬḭ"),filter,url)
	if l1l11l_l1_ (u"ࠬࡅࠧḮ") in url: url = url.split(l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪḯ"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠧࡠࡡࡢࠫḰ"),1)
	if filter==l1l11l_l1_ (u"ࠨࠩḱ"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"ࠩࠪḲ"),l1l11l_l1_ (u"ࠪࠫḳ")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨḴ"))
	if type==l1l11l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨḵ"):
		if l1111l1_l1_[0]+l1l11l_l1_ (u"࠭࠽ࠨḶ") not in l111111_l1_: category = l1111l1_l1_[0]
		for i in range(len(l1111l1_l1_[0:-1])):
			if l1111l1_l1_[i]+l1l11l_l1_ (u"ࠧ࠾ࠩḷ") in l111111_l1_: category = l1111l1_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠪḸ")+category+l1l11l_l1_ (u"ࠩࡀ࠴ࠬḹ")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠬḺ")+category+l1l11l_l1_ (u"ࠫࡂ࠶ࠧḻ")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧḼ"))+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪḽ")+l11l11l_l1_.strip(l1l11l_l1_ (u"ࠧࠧࠩḾ"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫḿ")) # l11ll1l111_l1_ l1l111l1l1_l1_ not l1ll11ll11_l1_
		url2 = url+l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ṁ")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ṁ"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭Ṃ")) # l11ll1l111_l1_ l1l111l1l1_l1_ not l1ll11ll11_l1_
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠬ࠭ṃ"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩṄ")) # l11ll1l111_l1_ l1l111l1l1_l1_ not l1ll11ll11_l1_
		if l1llllll_l1_==l1l11l_l1_ (u"ࠧࠨṅ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬṆ")+l1llllll_l1_
		url2 = l11l11lll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩṇ"),menu_name+l1l11l_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭Ṉ"),url2,431)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṉ"),menu_name+l1l11l_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬṊ")+l1ll1ll1_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬṋ"),url2,431)
		addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬṌ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨṍ"),l1l11l_l1_ (u"ࠩࠪṎ"),9999)
	l1l1ll1_l1_ = l11l1l1l1_l1_(url)
	dict = {}
	for name,block,l1l111l_l1_ in l1l1ll1_l1_:
		name = name.replace(l1l11l_l1_ (u"ࠪ࠱࠲࠭ṏ"),l1l11l_l1_ (u"ࠫࠬṐ"))
		items = l111lllll_l1_(block)
		if l1l11l_l1_ (u"ࠬࡃࠧṑ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩṒ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l1111l1_l1_[-1]:
					url = l11l11lll_l1_(url)
					l111l1_l1_(url)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ṓ")+l111l11_l1_)
				return
			else:
				url2 = l11l11lll_l1_(url2)
				if l1l111l_l1_==l1111l1_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṔ"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪṕ"),url2,431)
				else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪṖ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬṗ"),url2,435,l1l11l_l1_ (u"ࠬ࠭Ṙ"),l1l11l_l1_ (u"࠭ࠧṙ"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪṚ"):
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠪṛ")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀ࠴ࠬṜ")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠬṝ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠶ࠧṞ")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩṟ")+l11l11l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ṡ"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩṡ")+name,url2,434,l1l11l_l1_ (u"ࠨࠩṢ"),l1l11l_l1_ (u"ࠩࠪṣ"),l111l11_l1_)		# +l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṤ"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if value==l1l11l_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫṥ"): option = l1l11l_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬṦ")
			elif value==l1l11l_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭ṧ"): option = l1l11l_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩṨ")
			if option in l1llll1_l1_: continue
			#if l1l11l_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧṩ") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪṪ"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠪࠪࠬṫ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠭Ṭ")+option
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠬࠬࠧṭ")+l1l111l_l1_+l1l11l_l1_ (u"࠭࠽ࠨṮ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫṯ")+l11l11l_l1_
			title = option+l1l11l_l1_ (u"ࠨࠢ࠽ࠫṰ")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠩ࠳ࠫṱ")]
			title = option+l1l11l_l1_ (u"ࠪࠤ࠿࠭Ṳ")+name
			if type==l1l11l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧṳ"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṴ"),menu_name+title,url,434,l1l11l_l1_ (u"࠭ࠧṵ"),l1l11l_l1_ (u"ࠧࠨṶ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṷ"))
			elif type==l1l11l_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬṸ") and l1111l1_l1_[-2]+l1l11l_l1_ (u"ࠪࡁࠬṹ") in l111111_l1_:
				url3 = l11l11l11l_l1_(l11l11l_l1_,url)
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṺ"),menu_name+title,url3,431)
			else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṻ"),menu_name+title,url,435,l1l11l_l1_ (u"࠭ࠧṼ"),l1l11l_l1_ (u"ࠧࠨṽ"),l1l1111_l1_)
	return
def l1llll1l_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩṾ"),l1l11l_l1_ (u"ࠩࠪṿ"),filters,l1l11l_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫẀ"))
	# mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ẁ")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨẂ")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫẃ")			all l111lll_l1_ & l11l1l11l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠧ࠾ࠨࠪẄ"),l1l11l_l1_ (u"ࠨ࠿࠳ࠪࠬẅ"))
	filters = filters.strip(l1l11l_l1_ (u"ࠩࠩࠫẆ"))
	l11111l_l1_ = {}
	if l1l11l_l1_ (u"ࠪࡁࠬẇ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠫࠫ࠭Ẉ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠬࡃࠧẉ"))
			l11111l_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"࠭ࠧẊ")
	for key in l11ll1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠧ࠱ࠩẋ")
		if l1l11l_l1_ (u"ࠨࠧࠪẌ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫẍ") and value!=l1l11l_l1_ (u"ࠪ࠴ࠬẎ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠥ࠱ࠠࠨẏ")+value
		elif mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨẐ") and value!=l1l11l_l1_ (u"࠭࠰ࠨẑ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠧࠧࠩẒ")+key+l1l11l_l1_ (u"ࠨ࠿ࠪẓ")+value
		elif mode==l1l11l_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧẔ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠪࠪࠬẕ")+key+l1l11l_l1_ (u"ࠫࡂ࠭ẖ")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠬࠦࠫࠡࠩẗ"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠨẘ"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠧ࠾࠲ࠪẙ"),l1l11l_l1_ (u"ࠨ࠿ࠪẚ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪẛ"),l1l11l_l1_ (u"ࠪࠫẜ"),filters,l1l11l_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠵࠶ࠬẝ"))
	return l11llll_l1_
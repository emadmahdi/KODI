# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠮ࡣࡧࡶࡸ᯦ࠬ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠲࠰ࡥࡩࡸࡺࠧᯧ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠫᯨ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫᯩ")
#l11lll_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠸ࡧ࡫ࡳࡵ࠰ࡦࡳࡲ࠭ᯪ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠯ࡹ࡭ࡵ࠴ࡳࡩࡱࡩࡨࡦ࠴ࡣࡰ࡯ࠪᯫ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡳࡲ࡫࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰ࡯ࠫᯬ")
#l11lll_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫᯭ")
script_name = l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧᯮ")
menu_name = l1l11l_l1_ (u"ࠫࡤࡋࡇࡗࡡࠪᯯ")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l111l1_l1_(url,page)
	elif mode==222: results = l1l1lll11_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1l1l1l_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯰ"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᯱ"),l1l11l_l1_ (u"ࠧࠨ᯲"),229,l1l11l_l1_ (u"ࠨ᯳ࠩ"),l1l11l_l1_ (u"ࠩࠪ᯴"),l1l11l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᯵"))
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᯶"),menu_name+l1l11l_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ᯷"),l11lll_l1_,226,l1l11l_l1_ (u"࠭ࠧ᯸"),l1l11l_l1_ (u"ࠧࠨ᯹"),l1l11l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ᯺"))
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᯻"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭᯼"),l11lll_l1_,226,l1l11l_l1_ (u"ࠫࠬ᯽"),l1l11l_l1_ (u"ࠬ࠭᯾"),l1l11l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ᯿"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰀ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᰁ"),l1l11l_l1_ (u"ࠩࠪᰂ"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᰃ"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬᰄ"),l1l11l_l1_ (u"ࠬ࠭ᰅ"),l1l11l_l1_ (u"࠭ࠧᰆ"),l1l11l_l1_ (u"ࠧࠨᰇ"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᰈ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࠤ࡮࠳ࡨࡰ࡯ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᰉ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᰊ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠩᰋ") in title: title = title.split(l1l11l_l1_ (u"ࠬࡂ࠯ࡪࡀࠪᰌ"))[1]
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰍ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᰎ")+menu_name+title,l1111l_l1_,222)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰏ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᰐ"),l1l11l_l1_ (u"ࠪࠫᰑ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࠬᰒ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠬࡶࡤࡢࠢࡥࡨࡧࠨ࠾࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᰓ"),html,re.DOTALL)
	for title,l1111l_l1_ in items:
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰔ"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫᰕ")+menu_name+title,l1111l_l1_,221)
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰖ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᰗ"),l1l11l_l1_ (u"ࠪࠫᰘ"),9999)
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᰙ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠬ࡮ࡴ࡮࡮ࠪᰚ") not in l1111l_l1_: continue
		if not l1111l_l1_.endswith(l1l11l_l1_ (u"࠭࠯ࠨᰛ")): addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᰜ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᰝ")+menu_name+title,l1111l_l1_,221)
	return html
	l1l11l_l1_ (u"ࠤࠥࠦࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฬ฼ฺุ๊๊ࠢฬࠦไศุสๅฮࠦวิ็ࠣำำ๎ไ๊ࠡๆ่๊ฯࠠศๆึีࠬ࠲ࠧࠨ࠮࠵࠶࠺࠯ࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭สฮาํีࠬ࠲ࠧࠨ࠮࠵࠶࠻࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠡࡪࡷࡱࡱ࠯ࠊࠊࠥ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰࡏࡳࡦࡪࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠥ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪࡀࠫ࠲࠯ࡅࠩ࡝ࡰࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠥࡩࡳࡷࠦࡵࡳ࡮࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠣࠊ࡫ࡩࠤࡺࡸ࡬ࠢ࠿ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭ࡷࡵࡰ࠱࠸࠲࠵ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ࠮ࠪࠫ࠱࠸࠲࠺࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡢࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้ษใฬำู้ࠣอ็ะหࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ࠱࠸࠲࠲ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡤࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอไศใ็ห๊࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠮ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ࠲࠲࠳࠶ࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠮ࠫࡤࡥ࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭วๅ็ึุ่๊วหࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡶࡹࠫ࠱࠸࠲࠵ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡰ࡮ࡴ࡫ࠨ࠮ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠰ࠬ࠭ࠬ࠺࠻࠼࠽࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡰࡦࡹࡳ࠾ࠤࡥࡥࠥࡳࡧࡣࠪ࠱࠮ࡄ࠯࠾ࡆࡩࡼࡆࡪࡹࡴ࠽࠱ࡤࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠱ࠧࡠࡡࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤ࡭ࡺ࡭࡭ࠌࠌࠧࠥ࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠥ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡠ࠷࠯࡞࡝࡬ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࠩࡷࡳࡷࡸࡥ࡯ࡶࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠶࠷࠷ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫࡹࡵࡲࡳࡧࡱࡸࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࠧࠨࠢᰞ")
def l1l1lll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᰟ"),url,l1l11l_l1_ (u"ࠫࠬᰠ"),l1l11l_l1_ (u"ࠬ࠭ᰡ"),l1l11l_l1_ (u"࠭ࠧᰢ"),l1l11l_l1_ (u"ࠧࠨᰣ"),l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᰤ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡷࡤࡹࡣࡳࡱ࡯ࡰࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᰥ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᰦ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰧ"),menu_name+title,l1111l_l1_,224)
	return
def l1l1l1l_l1_(url):
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰨ"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾࠭ᰩ"),url,221)
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠧࠨᰪ"),l1l11l_l1_ (u"ࠨࠩᰫ"),l1l11l_l1_ (u"ࠩࠪᰬ"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᰭ"))
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣ࡯ࡤ࡭ࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࠤࠥࠦᰮ")
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣࡡࡱࡥࡻ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹࠧᰯ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᰰ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1111l_l1_==l1l11l_l1_ (u"ࠧࠤࠩᰱ"): name = title
			else:
				title = title + l1l11l_l1_ (u"ࠨࠢࠣ࠾ࠥࠦࠧᰲ") + l1l11l_l1_ (u"ࠩไ่ฯืࠠࠨᰳ") + name
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᰴ"),menu_name+title,l1111l_l1_,221)
	else: l111l1_l1_(url)
	return
def l111l1_l1_(url,page=l1l11l_l1_ (u"ࠫ࠶࠭ᰵ")):
	if page==l1l11l_l1_ (u"ࠬ࠭ᰶ"): page = l1l11l_l1_ (u"࠭࠱ࠨ᰷")
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ᰸"),l1l11l_l1_ (u"ࠨࠩ᰹"),str(url), str(page))
	if l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ᰺") in url or l1l11l_l1_ (u"ࠪࡃࠬ᰻") in url: url2 = url + l1l11l_l1_ (u"ࠫࠫ࠭᰼")
	else: url2 = url + l1l11l_l1_ (u"ࠬࡅࠧ᰽")
	#url2 = url2 + l1l11l_l1_ (u"࠭࡯ࡶࡶࡳࡹࡹࡥࡦࡰࡴࡰࡥࡹࡃࡪࡴࡱࡱࠪࡴࡻࡴࡱࡷࡷࡣࡲࡵࡤࡦ࠿ࡰࡳࡻ࡯ࡥࡴࡡ࡯࡭ࡸࡺࠦࡱࡣࡪࡩࡂ࠭᰾")+page
	url2 = url2 + l1l11l_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭᰿") + page
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l11l_l1_ (u"ࠨࠩ᱀"),l1l11l_l1_ (u"ࠩࠪ᱁"),l1l11l_l1_ (u"ࠪࠫ᱂"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ᱃"))
	#name = l1l11l_l1_ (u"ࠬ࠭᱄")
	#if l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࠧ᱅") in url:
	#	name = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᱆"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l1l11l_l1_ (u"ࠨࠢࠪ᱇")) + l1l11l_l1_ (u"ࠩࠣ࠱ࠥ࠭᱈")
	#	else: name = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ᱉") ) + l1l11l_l1_ (u"ࠫࠥ࠳ࠠࠨ᱊")
	if l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠭᱋") in url:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡥࡣࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ᱌"),html,re.DOTALL)
		block = l1ll111_l1_[-1]
	# l11l11llll_l1_ l111lll1l_l1_
	elif l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩᱍ") in url:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠠࡰࡹ࡯࠱ࡨࡧࡲࡰࡷࡶࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧᱎ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
	else:
		l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᱏ"),html,re.DOTALL)
		block = l1ll111_l1_[-1]
	items = re.findall(l1l11l_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᱐"),block,re.DOTALL)
	for l1111l_l1_,img,title in items:
		l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴࡧࡵ࡭ࡪࡹࠧࠡ࡫ࡱࠤࡺࡸ࡬ࠡࡣࡱࡨࠥ࠭࠯ࡴࡧࡤࡷࡴࡴࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡥࡳࡪࠠࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡸ࡮ࡺ࡬ࡦ࠮ࠣࡷࡹࡸࠨ࡭࡫ࡱ࡯࠮࠯ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡲࡦࡳࡥࠡ࠭ࠣࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠥࠦࠧ᱑")
		title = unescapeHTML(title)
		l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࠎ࡯࡭ࡨࠢࡀࠤ࡮ࡳࡧ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪࡨࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣ࡭ࡲ࡭࠺ࠡ࡫ࡰ࡫ࠥࡃࠠࠨࡪࡷࡸࡵࡀࠧࠡ࠭ࠣ࡭ࡲ࡭ࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡒࡔ࡚ࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠪ࡬ࡱ࡬࠲ࠧࠨࠫࠍࠍࠎࡻࡲ࡭࠴ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠦࠧࠨ᱒")
		if l1l11l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵ࠧ᱓") in l1111l_l1_ or l1l11l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࠩ᱔") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᱕"),menu_name+title,l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠩ࠲ࠫ᱖")),223,img)
		else:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᱗"),menu_name+title,l1111l_l1_,221,img)
	if len(items)>=16:
		l1l11l11l1_l1_ = [l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ᱘"),l1l11l_l1_ (u"ࠬ࠵ࡴࡷࠩ᱙"),l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧᱚ"),l1l11l_l1_ (u"ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪᱛ")]
		page = int(page)
		if any(value in url for value in l1l11l11l1_l1_):
			for n in range(0,1000,100):
				if int(page/100)*100==n:
					for i in range(n,n+100,10):
						if int(page/10)*10==i:
							for j in range(i,i+10,1):
								if not page==j and j!=0:
									addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱜ"),menu_name+l1l11l_l1_ (u"ุࠩๅาฯࠠࠨᱝ")+str(j),url,221,l1l11l_l1_ (u"ࠪࠫᱞ"),str(j))
						elif i!=0: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᱟ"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫᱠ")+str(i),url,221,l1l11l_l1_ (u"࠭ࠧᱡ"),str(i))
						else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱢ"),menu_name+l1l11l_l1_ (u"ࠨืไัฮࠦࠧᱣ")+str(1),url,221,l1l11l_l1_ (u"ࠩࠪᱤ"),str(1))
				elif n!=0: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᱥ"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪᱦ")+str(n),url,221,l1l11l_l1_ (u"ࠬ࠭ᱧ"),str(n))
				else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱨ"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥ࠭ᱩ")+str(1),url,221)
	return
def PLAY(url):
	#global l1l11l_l1_ (u"ࠨࠩᱪ")
	l1l1lll_l1_,l1ll1lll_l1_ = [],[]
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᱫ"),l1l11l_l1_ (u"ࠪࠫᱬ"),url, url[-45:])
	# https://l11l1ll1l1_l1_.com/l11l1lllll_l1_/فيلم-the-l11ll111ll_l1_-l11l1l1111_l1_-2019-مترجم
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠫࠬᱭ"),l1l11l_l1_ (u"ࠬ࠭ᱮ"),l1l11l_l1_ (u"࠭ࠧᱯ"),l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᱰ"))
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᱱ"),html,re.DOTALL)
	if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# https://l1l1l111l1_l1_.l11l11lll1_l1_/l11l1lllll_l1_/فيلم-the-l11ll111ll_l1_-l11l1l1111_l1_-2019-مترجم
	l1l1l111l_l1_,l1l1lllll_l1_ = l1l11l_l1_ (u"ࠩࠪᱲ"),l1l11l_l1_ (u"ࠪࠫᱳ")
	l11ll11l11_l1_,l11l1l1lll_l1_ = html,html
	l11l1lll11_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡸ࡮࡯ࡸࡡࡧࡰࠥࡧࡰࡪࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᱴ"),html,re.DOTALL)
	if l11l1lll11_l1_:
		for l1111l_l1_ in l11l1lll11_l1_:
			if l1l11l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭ᱵ") in l1111l_l1_: l1l1l111l_l1_ = l1111l_l1_
			elif l1l11l_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪᱶ") in l1111l_l1_: l1l1lllll_l1_ = l1111l_l1_
		if l1l1l111l_l1_!=l1l11l_l1_ (u"ࠧࠨᱷ"): l11ll11l11_l1_ = OPENURL_CACHED(l1llll_l1_,l1l1l111l_l1_,l1l11l_l1_ (u"ࠨࠩᱸ"),l1l11l_l1_ (u"ࠩࠪᱹ"),l1l11l_l1_ (u"ࠪࠫᱺ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪᱻ"))
		if l1l1lllll_l1_!=l1l11l_l1_ (u"ࠬ࠭ᱼ"): l11l1l1lll_l1_ = OPENURL_CACHED(l1llll_l1_,l1l1lllll_l1_,l1l11l_l1_ (u"࠭ࠧᱽ"),l1l11l_l1_ (u"ࠧࠨ᱾"),l1l11l_l1_ (u"ࠨࠩ᱿"),l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨᲀ"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫᲁ"),l1l11l_l1_ (u"ࠫࠬᲂ"),l1l1lllll_l1_,l1l1l111l_l1_)
	# https://l11l1l1ll1_l1_.l1l1l111l1_l1_.download/?id=__11ll111l1_l1_
	l11l1lll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᲃ"),l11ll11l11_l1_,re.DOTALL)
	if l11l1lll1l_l1_:
		url2 = l11l1lll1l_l1_[0]#+l1l11l_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࡮ࡴࡵࡲ࠽࠳࠴࠽࠹࠯࠳࠹࠹࠳࠸࠴࠳࠰࠻࠸࠿࠺࠱࠵࠷ࠪᲄ")
		if url2!=l1l11l_l1_ (u"ࠧࠨᲅ") and l1l11l_l1_ (u"ࠨࡷࡳࡰࡴࡧࡤࡦࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᲆ") in url2 and l1l11l_l1_ (u"ࠩ࠲ࡃ࡮ࡪ࠽ࡠࠩᲇ") not in url2:
			l1lll111_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠪࠫᲈ"),l1l11l_l1_ (u"ࠫࠬᲉ"),l1l11l_l1_ (u"ࠬ࠭ᲊ"),l1l11l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ᲋"))
			l11l11ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᲌"),l1lll111_l1_,re.DOTALL)
			if l11l11ll11_l1_:
				for l1111l_l1_,l1l1l1l1_l1_ in l11l11ll11_l1_:
					l1ll1lll_l1_.append(l1111l_l1_+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡧࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪ࡯ࡠࡡࡺࡥࡹࡩࡨࡠࡡࡰࡴ࠹ࡥ࡟ࠨ᲍")+l1l1l1l1_l1_)
			else:
				server = url2.split(l1l11l_l1_ (u"ࠩ࠲ࠫ᲎"))[2]
				l1ll1lll_l1_.append(url2+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᲏")+server+l1l11l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᲐ"))
		elif url2!=l1l11l_l1_ (u"ࠬ࠭Ბ"):
			#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧᲒ"),l1l11l_l1_ (u"ࠧࠨᲓ"),url2,str(l11l1lll1l_l1_))
			server = url2.split(l1l11l_l1_ (u"ࠨ࠱ࠪᲔ"))[2]
			l1ll1lll_l1_.append(url2+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᲕ")+server+l1l11l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᲖ"))
	# https://l11l1l11ll_l1_.cc/l11ll1111l_l1_
	# https://l11l1llll1_l1_.l11l1l11l1_l1_/l11ll1111l_l1_
	l11l1l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁࡺࡡࡣ࡮ࡨࠤࡨࡲࡡࡴࡵࡀࠦࡩࡲࡳࡠࡶࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭Თ"),l11l1l1lll_l1_,re.DOTALL)
	if l11l1l1l1l_l1_:
		l11l1l1l1l_l1_ = l11l1l1l1l_l1_[0]
		l11l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡴࡥࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᲘ"),l11l1l1l1l_l1_,re.DOTALL)
		if l11l1ll1ll_l1_:
			for l1l1l1l1_l1_,l1111l_l1_ in l11l1ll1ll_l1_:
				if l1l11l_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨᲙ") not in l1111l_l1_: continue
				if l1111l_l1_.count(l1l11l_l1_ (u"ࠧ࠰ࠩᲚ"))>=2:
					server = l1111l_l1_.split(l1l11l_l1_ (u"ࠨ࠱ࠪᲛ"))[2]
					l1ll1lll_l1_.append(l1111l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᲜ")+server+l1l11l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠ࡯ࡳ࠸ࡤࡥࠧᲝ")+l1l1l1l1_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ๆศีห࠾ࠬᲞ"), l1ll1lll_l1_)
	#if selection == -1 : return
	newLIST = []
	for l1111l_l1_ in l1ll1lll_l1_:
		# l11l1l111l_l1_	https://l111ll11l_l1_.l1l1l111l1_l1_.l11l11lll1_l1_/l11l1lllll_l1_/l1l1ll11l_l1_/فيلم-the-l11ll11111_l1_-l11l1ll11l_l1_-l11l11ll1l_l1_-2017-مترجم/l11l1ll111_l1_
		#if l1l11l_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭Ჟ") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࡃࡳࡧ࡭ࡦࠩᲠ") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬᲡ") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪᲢ") not in l1111l_l1_: continue
		newLIST.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᲣ"), newLIST)
	import ll_l1_
	ll_l1_.l1l_l1_(newLIST,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᲤ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬᲥ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭Ღ"): return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"࠭ࠠࠨᲧ"),l1l11l_l1_ (u"ࠧࠬࠩᲨ"))
	html = OPENURL_CACHED(l111l11l_l1_,l11lll_l1_,l1l11l_l1_ (u"ࠨࠩᲩ"),l1l11l_l1_ (u"ࠩࠪᲪ"),l1l11l_l1_ (u"ࠪࠫᲫ"),l1l11l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬᲬ"))
	token = re.findall(l1l11l_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡤࡺ࡯࡬ࡧࡱࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᲭ"),html,re.DOTALL)
	if token:
		url = l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡠࡶࡲ࡯ࡪࡴ࠽ࠨᲮ")+token[0]+l1l11l_l1_ (u"ࠧࠧࡳࡀࠫᲯ")+l1l1ll_l1_
		l111l1_l1_(url)
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩᲰ"),l1l11l_l1_ (u"ࠩࠪᲱ"),l1l11l_l1_ (u"ࠪࠫᲲ"), l1l11l_l1_ (u"ࠫࠬᲳ"))
	return
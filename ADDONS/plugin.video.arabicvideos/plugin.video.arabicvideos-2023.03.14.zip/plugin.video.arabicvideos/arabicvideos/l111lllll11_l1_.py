# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ䥷")
headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䥸"):l1l11l_l1_ (u"ࠧࠨ䥹")}
menu_name = l1l11l_l1_ (u"ࠨࡡ࡚ࡇࡒࡥࠧ䥺")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭䥻"),l1l11l_l1_ (u"ࠪࡻࡼ࡫ࠧ䥼")]
def MAIN(mode,url,text):
	if   mode==570: results = MENU()
	elif mode==571: results = l111l1_l1_(url,text)
	elif mode==572: results = PLAY(url)
	elif mode==573: results = l111ll_l1_(url,text)
	elif mode==574: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ䥽")+text)
	elif mode==575: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ䥾")+text)
	elif mode==576: results = l1l1lll11_l1_(url)
	elif mode==579: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䥿"),l11lll_l1_,l1l11l_l1_ (u"ࠧࠨ䦀"),l1l11l_l1_ (u"ࠨࠩ䦁"),False,l1l11l_l1_ (u"ࠩࠪ䦂"),l1l11l_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䦃"))
	#hostname = response.headers[l1l11l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䦄")]
	#hostname = hostname.strip(l1l11l_l1_ (u"ࠬ࠵ࠧ䦅"))
	#l111llll1_l1_ = l11lll_l1_
	#url = l111llll1_l1_+l1l11l_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䦆")
	#url = l111llll1_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䦇"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩ䦈"),l1l11l_l1_ (u"ࠩࠪ䦉"),l1l11l_l1_ (u"ࠪࠫ䦊"),l1l11l_l1_ (u"ࠫࠬ䦋"),l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䦌"))
	#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䦍"),menu_name+l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊ิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䦎"),l1l11l_l1_ (u"ࠨࠩ䦏"),8)
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䦐"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䦑"),l1l11l_l1_ (u"ࠫࠬ䦒"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䦓"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䦔"),l11lll_l1_,579,l1l11l_l1_ (u"ࠧࠨ䦕"),l1l11l_l1_ (u"ࠨࠩ䦖"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䦗"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䦘"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䦙"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䦚"),574)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䦛"),menu_name+l1l11l_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ䦜"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䦝"),575)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䦞"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䦟"),l1l11l_l1_ (u"ࠫࠬ䦠"),9999)
	#headers2 = {l1l11l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䦡"):hostname,l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䦢"):l1l11l_l1_ (u"ࠧࠨ䦣")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l11l_l1_ (u"ࠨ࡞࠲ࠫ䦤"),l1l11l_l1_ (u"ࠩ࠲ࠫ䦥"))
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࡤࡤࡶ࠭࠴ࠪࡀࠫࡩ࡭ࡱࡺࡥࡳࠩ䦦"),html,re.DOTALL)
	#if l1ll111_l1_:
	#	block = l1ll111_l1_[0]
	#	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䦧"),block,re.DOTALL)
	#	for l1111l_l1_,title in items:
	#		if l1l11l_l1_ (u"ࠬࠫࡤ࠺ࠧ࠻࠹ࠪࡪ࠸ࠦࡤ࠸ࠩࡩ࠾ࠥࡢ࠹ࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡨ࠹ࠦࡦ࠻ࠩࡦ࠿࠭ࠦࡦ࠻ࠩࡦࡪࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡤ࠽ࠬ䦨") in l1111l_l1_: continue
	#		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䦩"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䦪")+menu_name+title,l1111l_l1_,576)
	#	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䦫"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䦬"),l1l11l_l1_ (u"ࠪࠫ䦭"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䦮"),l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭䦯"),l1l11l_l1_ (u"࠭ࠧ䦰"),l1l11l_l1_ (u"ࠧࠨ䦱"),l1l11l_l1_ (u"ࠨࠩ䦲"),l1l11l_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ䦳"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ䦴"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䦵"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䦶") not in l1111l_l1_:
			#	server = SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䦷"))
			#	l1111l_l1_ = l1111l_l1_.replace(server,l111llll1_l1_)
			if title==l1l11l_l1_ (u"ࠧࠨ䦸"): continue
			if any(value in title.lower() for value in l1llll1_l1_): continue
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䦹"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䦺")+menu_name+title,l1111l_l1_,576)
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䦻"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䦼"),l1l11l_l1_ (u"ࠬ࠭䦽"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ䦾"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䦿"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䧀"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䧁")+menu_name+title,l1111l_l1_,576,img)
	return html
def l1l1lll11_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䧂"),l1l11l_l1_ (u"ࠫࠬ䧃"),url,l1l11l_l1_ (u"ࠬ࠭䧄"))
	#headers2 = {l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䧅"):url,l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䧆"):l1l11l_l1_ (u"ࠨࠩ䧇")}
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䧈"),url,l1l11l_l1_ (u"ࠪࠫ䧉"),l1l11l_l1_ (u"ࠫࠬ䧊"),l1l11l_l1_ (u"ࠬ࠭䧋"),l1l11l_l1_ (u"࠭ࠧ䧌"),l1l11l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䧍"))
	html = response.content
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䧎"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ䧏"),url,574)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䧐"),menu_name+l1l11l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ䧑"),url,575)
	if l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦࠬ䧒") in html:
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䧓"),menu_name+l1l11l_l1_ (u"ࠧศๆ่้๏ุษࠨ䧔"),url,571,l1l11l_l1_ (u"ࠨࠩ䧕"),l1l11l_l1_ (u"ࠩࠪ䧖"),l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䧗"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ䧘"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䧙"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䧚"),menu_name+title,l1111l_l1_,571)
	return
def l111l1_l1_(l1llllll1l11_l1_,type=l1l11l_l1_ (u"ࠧࠨ䧛")):
	if l1l11l_l1_ (u"ࠨ࠼࠽ࠫ䧜") in l1llllll1l11_l1_:
		url3,url = l1llllll1l11_l1_.split(l1l11l_l1_ (u"ࠩ࠽࠾ࠬ䧝"))
		server = SERVER(url3,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ䧞"))
		url = server+url
	else: url,url3 = l1llllll1l11_l1_,l1llllll1l11_l1_
	#headers2 = {l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䧟"):url3,l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䧠"):l1l11l_l1_ (u"࠭ࠧ䧡")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䧢"),url,l1l11l_l1_ (u"ࠨࠩ䧣"),l1l11l_l1_ (u"ࠩࠪ䧤"),l1l11l_l1_ (u"ࠪࠫ䧥"),l1l11l_l1_ (u"ࠫࠬ䧦"),l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䧧"))
	html = response.content
	if type==l1l11l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䧨"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ䧩"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䧪"):
		l1ll111_l1_ = [html.replace(l1l11l_l1_ (u"ࠩ࡟ࡠ࠴࠭䧫"),l1l11l_l1_ (u"ࠪ࠳ࠬ䧬")).replace(l1l11l_l1_ (u"ࠫࡡࡢࠢࠨ䧭"),l1l11l_l1_ (u"ࠬࠨࠧ䧮"))]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲࡝ࡥࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ䧯"),html,re.DOTALL)
	l1l1l11_l1_ = []
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡈࡴ࡬ࡨࡎࡺࡥ࡮ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭䧰"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			if any(value in title.lower() for value in l1llll1_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l11l_l1_ (u"ࠨ็ืห์ีษࠡࠩ䧱"),l1l11l_l1_ (u"ࠩࠪ䧲"))
			if l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䧳") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䧴"),menu_name+title,l1111l_l1_,573,img)
			elif l1l11l_l1_ (u"ࠬำไใหࠪ䧵") in title:
				l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ䧶"),title,re.DOTALL)
				if l1ll1ll_l1_: title = l1l11l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䧷") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					l1l1l11_l1_.append(title)
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䧸"),menu_name+title,l1111l_l1_,573,img)
			else:
				addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䧹"),menu_name+title,l1111l_l1_,572,img)
		if type==l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䧺"):
			l1llllll11ll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ䧻"),block,re.DOTALL)
			if l1llllll11ll_l1_:
				count = l1llllll11ll_l1_[0]
				l1111l_l1_ = url+l1l11l_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ䧼")+count
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䧽"),menu_name+l1l11l_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ䧾"),l1111l_l1_,571,l1l11l_l1_ (u"ࠨࠩ䧿"),l1l11l_l1_ (u"ࠩࠪ䨀"),l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䨁"))
		elif type==l1l11l_l1_ (u"ࠫࠬ䨂"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䨃"),html,re.DOTALL)
			if l1ll111_l1_:
				block = l1ll111_l1_[0]
				items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䨄"),block,re.DOTALL)
				for l1111l_l1_,title in items:
					title = l1l11l_l1_ (u"ࠧึใะอࠥ࠭䨅")+unescapeHTML(title)
					addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䨆"),menu_name+title,l1111l_l1_,571)
	return
def l111ll_l1_(url,type=l1l11l_l1_ (u"ࠩࠪ䨇")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䨈"),url,l1l11l_l1_ (u"ࠫࠬ䨉"),l1l11l_l1_ (u"ࠬ࠭䨊"),l1l11l_l1_ (u"࠭ࠧ䨋"),l1l11l_l1_ (u"ࠧࠨ䨌"),l1l11l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䨍"))
	html = response.content
	html = UNQUOTE(html)
	name = re.findall(l1l11l_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ䨎"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l11l_l1_ (u"ࠪ࠱ࠬ䨏"),l1l11l_l1_ (u"ࠫࠥ࠭䨐")).strip(l1l11l_l1_ (u"ࠬ࠵ࠧ䨑"))
	if l1l11l_l1_ (u"࠭ๅ้ี่ࠫ䨒") in name and type==l1l11l_l1_ (u"ࠧࠨ䨓"):
		name = name.split(l1l11l_l1_ (u"ࠨ็๋ื๊࠭䨔"))[0]
		name = name.replace(l1l11l_l1_ (u"ุ่ࠩฬํฯสࠩ䨕"),l1l11l_l1_ (u"ࠪࠫ䨖")).strip(l1l11l_l1_ (u"ࠫࠥ࠭䨗"))
	elif l1l11l_l1_ (u"ࠬำไใหࠪ䨘") in name:
		name = name.split(l1l11l_l1_ (u"࠭อๅไฬࠫ䨙"))[0]
		name = name.replace(l1l11l_l1_ (u"ࠧๆึส๋ิฯࠧ䨚"),l1l11l_l1_ (u"ࠨࠩ䨛")).strip(l1l11l_l1_ (u"ࠩࠣࠫ䨜"))
	else: name = name
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࠧ䨝"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		if type==l1l11l_l1_ (u"ࠫࠬ䨞"):
			items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ䨟"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬ䨠") in title: continue
				if l1l11l_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨ䨡") in title: continue
				title = name+l1l11l_l1_ (u"ࠨࠢ࠰ࠤࠬ䨢")+title
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䨣"),menu_name+title,l1111l_l1_,573,l1l11l_l1_ (u"ࠪࠫ䨤"),l1l11l_l1_ (u"ࠫࠬ䨥"),l1l11l_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ䨦"))
		if len(menuItemsLIST)==0:
			l1l11lll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࠯ࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䨧"),block+l1l11l_l1_ (u"ࠧࠧࠨࠪ䨨"),re.DOTALL)
			if l1l11lll_l1_: block = l1l11lll_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䨩"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䨪"))
				title = name+l1l11l_l1_ (u"ࠪࠤ࠲ࠦࠧ䨫")+title
				addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䨬"),menu_name+title,l1111l_l1_,572)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l11l_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ䨭"),html,re.DOTALL)
		if title: title = title[0].replace(l1l11l_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ䨮"),l1l11l_l1_ (u"ࠧࠨ䨯")).replace(l1l11l_l1_ (u"ࠨ็ืห์ีษࠡࠩ䨰"),l1l11l_l1_ (u"ࠩࠪ䨱"))
		else: title = l1l11l_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ䨲")
		addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䨳"),menu_name+title,url,572)
	return
def PLAY(url):
	l1ll1lll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ䨴"),url,l1l11l_l1_ (u"࠭ࠧ䨵"),l1l11l_l1_ (u"ࠧࠨ䨶"),l1l11l_l1_ (u"ࠨࠩ䨷"),l1l11l_l1_ (u"ࠩࠪ䨸"),l1l11l_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䨹"))
	html = response.content
	l1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䨺"),html,re.DOTALL)
	if l1l1l_l1_:
		l1l1l_l1_ = [l1l1l_l1_[0][0],l1l1l_l1_[0][1]]
		if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_): return
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ䨻"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䨼"),block,re.DOTALL)
		for l1111l_l1_,name in items:
			if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ䨽") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if name==l1l11l_l1_ (u"ࠨีํีๆื้ࠠ์ࠣื๏๋วࠨ䨾"): name = l1l11l_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ䨿")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䩀")+name+l1l11l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䩁")
			l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䩂"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䩃"),block,re.DOTALL)
		for l1111l_l1_,l1l1l1l1_l1_ in items:
			if l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࠬ䩄") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䩅"),l1l1l1l1_l1_,re.DOTALL)
			if l1l1l1l1_l1_: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠩࡢࡣࡤࡥࠧ䩆")+l1l1l1l1_l1_[0]
			else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠪࠫ䩇")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡼ࡫ࡣࡪ࡯ࡤࠫ䩈")+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䩉")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䩊"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䩋"),url)
	return
def SEARCH(search,hostname=l1l11l_l1_ (u"ࠨࠩ䩌")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠩࠪ䩍"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠪࠫ䩎"): return
	search = search.replace(l1l11l_l1_ (u"ࠫࠥ࠭䩏"),l1l11l_l1_ (u"ࠬ࠱ࠧ䩐"))
	l1ll1lll_l1_ = [l1l11l_l1_ (u"࠭࠯ࠨ䩑"),l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡳࡦࡴ࡬ࡩࡸ࠭䩒"),l1l11l_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡢࡰ࡬ࡱࡪ࠭䩓"),l1l11l_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡶࡹࠫ䩔"),l1l11l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䩕")]
	l1llll1l1ll_l1_ = [l1l11l_l1_ (u"ࠫฬ๊รโๆส้ࠬ䩖"),l1l11l_l1_ (u"ࠬอไๆี็ื้อสࠨ䩗"),l1l11l_l1_ (u"࠭วๅษ้๎๊๐้ࠠࠢส่่ืส้่ࠪ䩘"),l1l11l_l1_ (u"ࠧศๆหีฬ๋ฬࠡฬ็๎ๆุ๊้่ํอࠬ䩙"),l1l11l_l1_ (u"ࠨ฼ํี๋ࠥอะัࠪ䩚")]
	if showdialogs:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩสาฯืࠠศๆ้์฾ࠦวๅ็ฺ่ํฮ࠺ࠨ䩛"), l1llll1l1ll_l1_)
		if selection==-1: return
	else: selection = 4
	if not hostname:
		hostname = l11lll_l1_
		#response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䩜"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ䩝"),l1l11l_l1_ (u"ࠬ࠭䩞"),False,l1l11l_l1_ (u"࠭ࠧ䩟"),l1l11l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䩠"))
		#hostname = response.headers[l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䩡")]
		#hostname = response.url
		#hostname = hostname.strip(l1l11l_l1_ (u"ࠩ࠲ࠫ䩢"))
	url2 = hostname+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ䩣")+search+l1ll1lll_l1_[selection]
	l111l1_l1_(url2)
	return
def l1l1l1l_l1_(l1llllll1l11_l1_,filter):
	if l1l11l_l1_ (u"ࠫࡄࡅࠧ䩤") in l1llllll1l11_l1_: url = l1llllll1l11_l1_.split(l1l11l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䩥"))[0]
	else: url = l1llllll1l11_l1_
	#headers2 = {l1l11l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䩦"):l1llllll1l11_l1_,l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䩧"):l1l11l_l1_ (u"ࠨࠩ䩨")}
	filter = filter.replace(l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䩩"),l1l11l_l1_ (u"ࠪࠫ䩪"))
	type,filter = filter.split(l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䩫"),1)
	if filter==l1l11l_l1_ (u"ࠬ࠭䩬"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"࠭ࠧ䩭"),l1l11l_l1_ (u"ࠧࠨ䩮")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ䩯"))
	if type==l1l11l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䩰"):
		if l1ll1l11l_l1_[0]+l1l11l_l1_ (u"ࠪࡁࡂ࠭䩱") not in l111111_l1_: category = l1ll1l11l_l1_[0]
		for i in range(len(l1ll1l11l_l1_[0:-1])):
			if l1ll1l11l_l1_[i]+l1l11l_l1_ (u"ࠫࡂࡃࠧ䩲") in l111111_l1_: category = l1ll1l11l_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨ䩳")+category+l1l11l_l1_ (u"࠭࠽࠾࠲ࠪ䩴")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪ䩵")+category+l1l11l_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䩶")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠩࠩࠪࠬ䩷"))+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䩸")+l11l11l_l1_.strip(l1l11l_l1_ (u"ࠫࠫࠬࠧ䩹"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䩺"))
		url2 = url+l1l11l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䩻")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ䩼"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ䩽"))
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠩࠪ䩾"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䩿"))
		if l1llllll_l1_==l1l11l_l1_ (u"ࠫࠬ䪀"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䪁")+l1llllll_l1_
		l11ll111_l1_ = l1l1ll1l1_l1_(url2,l1llllll1l11_l1_)
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䪂"),menu_name+l1l11l_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ䪃"),l11ll111_l1_,571,l1l11l_l1_ (u"ࠨࠩ䪄"),l1l11l_l1_ (u"ࠩࠪ䪅"),l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䪆"))
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䪇"),menu_name+l1l11l_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ䪈")+l1ll1ll1_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ䪉"),l11ll111_l1_,571,l1l11l_l1_ (u"ࠧࠨ䪊"),l1l11l_l1_ (u"ࠨࠩ䪋"),l1l11l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䪌"))
		addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䪍"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䪎"),l1l11l_l1_ (u"ࠬ࠭䪏"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䪐"),url,l1l11l_l1_ (u"ࠧࠨ䪑"),l1l11l_l1_ (u"ࠨࠩ䪒"),l1l11l_l1_ (u"ࠩࠪ䪓"),l1l11l_l1_ (u"ࠪࠫ䪔"),l1l11l_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䪕"))
	html = response.content
	html = html.replace(l1l11l_l1_ (u"ࠬࡢ࡜ࠣࠩ䪖"),l1l11l_l1_ (u"࠭ࠢࠨ䪗")).replace(l1l11l_l1_ (u"ࠧ࡝࡞࠲ࠫ䪘"),l1l11l_l1_ (u"ࠨ࠱ࠪ䪙"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡻࡪࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡻࡪࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࡂࠬ䪚"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡸࡦࡾ࡯࡯ࡱࡰࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䪛"),block+l1l11l_l1_ (u"ࠫࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ䪜"),re.DOTALL)
	dict = {}
	for l1l111l_l1_,name,block in l1l1ll1_l1_:
		name = escapeUNICODE(name)
		if l1l11l_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ䪝") in l1l111l_l1_: continue
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ䪞"),block,re.DOTALL)
		if l1l11l_l1_ (u"ࠧ࠾࠿ࠪ䪟") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ䪠"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l1ll1l11l_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ䪡")+l111l11_l1_)
				return
			else:
				l11ll111_l1_ = l1l1ll1l1_l1_(url2,l1llllll1l11_l1_)
				if l1l111l_l1_==l1ll1l11l_l1_[-1]:
					addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䪢"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ䪣"),l11ll111_l1_,571,l1l11l_l1_ (u"ࠬ࠭䪤"),l1l11l_l1_ (u"࠭ࠧ䪥"),l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䪦"))
				else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䪧"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠩ䪨"),url2,574,l1l11l_l1_ (u"ࠪࠫ䪩"),l1l11l_l1_ (u"ࠫࠬ䪪"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䪫"):
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠧࠩ䪬")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾࠿࠳ࠫ䪭")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫ䪮")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࡁ࠵࠭䪯")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䪰")+l11l11l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䪱"),menu_name+name+l1l11l_l1_ (u"ࠬࡀࠠศๆฯ้๏฿ࠧ䪲"),url2,575,l1l11l_l1_ (u"࠭ࠧ䪳"),l1l11l_l1_ (u"ࠧࠨ䪴"),l111l11_l1_+l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䪵"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l11l_l1_ (u"ࠩࡵࠫ䪶") or value==l1l11l_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ䪷"): continue
			if any(value in option.lower() for value in l1llll1_l1_): continue
			if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䪸") in option: continue
			if l1l11l_l1_ (u"ࠬอไไๆࠪ䪹") in option: continue
			if l1l11l_l1_ (u"࠭࡮࠮ࡣࠪ䪺") in value: continue
			#if value in [l1l11l_l1_ (u"ࠧࡳࠩ䪻"),l1l11l_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ䪼"),l1l11l_l1_ (u"ࠩࡷࡺ࠲ࡳࡡࠨ䪽")]: continue
			#if l1l111l_l1_==l1l11l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䪾"): option = value
			if option==l1l11l_l1_ (u"ࠫࠬ䪿"): option = value
			l1l1l1lll_l1_ = option
			l1lll1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ䫀"),option,re.DOTALL)
			if l1lll1l1ll1_l1_: l1l1l1lll_l1_ = l1lll1l1ll1_l1_[0]
			title2 = name+l1l11l_l1_ (u"࠭࠺ࠡࠩ䫁")+l1l1l1lll_l1_
			dict[l1l111l_l1_][value] = title2
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠧࠧࠨࠪ䫂")+l1l111l_l1_+l1l11l_l1_ (u"ࠨ࠿ࡀࠫ䫃")+l1l1l1lll_l1_
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬ䫄")+l1l111l_l1_+l1l11l_l1_ (u"ࠪࡁࡂ࠭䫅")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䫆")+l11l11l_l1_
			if type==l1l11l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䫇"):
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䫈"),menu_name+title2,url,575,l1l11l_l1_ (u"ࠧࠨ䫉"),l1l11l_l1_ (u"ࠨࠩ䫊"),l1l1111_l1_+l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䫋"))
			elif type==l1l11l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䫌") and l1ll1l11l_l1_[-2]+l1l11l_l1_ (u"ࠫࡂࡃࠧ䫍") in l111111_l1_:
				l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䫎"))
				#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䫏"),l1l11l_l1_ (u"ࠧࠨ䫐"),l1llll11_l1_,l11l11l_l1_)
				url3 = url+l1l11l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䫑")+l1llll11_l1_
				l11ll111_l1_ = l1l1ll1l1_l1_(url3,l1llllll1l11_l1_)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䫒"),menu_name+title2,l11ll111_l1_,571,l1l11l_l1_ (u"ࠪࠫ䫓"),l1l11l_l1_ (u"ࠫࠬ䫔"),l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䫕"))
			else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䫖"),menu_name+title2,url,574,l1l11l_l1_ (u"ࠧࠨ䫗"),l1l11l_l1_ (u"ࠨࠩ䫘"),l1l1111_l1_)
	return
l1ll1l11l_l1_ = [l1l11l_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ䫙"),l1l11l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䫚"),l1l11l_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ䫛")]
l1ll11l1l_l1_ = [l1l11l_l1_ (u"ࠬࡳࡰࡢࡣࠪ䫜"),l1l11l_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ䫝"),l1l11l_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭䫞"),l1l11l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ䫟"),l1l11l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪ䫠"),l1l11l_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ䫡"),l1l11l_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ䫢"),l1l11l_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ䫣")]
def l1l1ll1l1_l1_(url2,url3):
	if l1l11l_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䫤") in url2: url2 = url2.replace(l1l11l_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䫥"),l1l11l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࠩ䫦"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䫧"),l1l11l_l1_ (u"ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧ䫨"))
	url2 = url2.replace(l1l11l_l1_ (u"ࠫࡂࡃࠧ䫩"),l1l11l_l1_ (u"ࠬ࠵ࠧ䫪"))
	url2 = url2.replace(l1l11l_l1_ (u"࠭ࠦࠧࠩ䫫"),l1l11l_l1_ (u"ࠧ࠰ࠩ䫬"))
	return url2
def l1llll1l_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ䫭"),l1l11l_l1_ (u"ࠩࠪ䫮"),filters,l1l11l_l1_ (u"ࠪࡍࡓࠦࠠࠡࠢࠪ䫯")+mode)
	# mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䫰")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䫱")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"࠭ࡡ࡭࡮ࠪ䫲")					all filters (l1lll1l1_l1_ l111lll_l1_ filter)
	filters = filters.strip(l1l11l_l1_ (u"ࠧࠧࠨࠪ䫳"))
	l11111l_l1_,l11llll_l1_ = {},l1l11l_l1_ (u"ࠨࠩ䫴")
	if l1l11l_l1_ (u"ࠩࡀࡁࠬ䫵") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠪࠪࠫ࠭䫶"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠫࡂࡃࠧ䫷"))
			l11111l_l1_[var] = value
	for key in l1ll11l1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠬ࠶ࠧ䫸")
		if l1l11l_l1_ (u"࠭ࠥࠨ䫹") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䫺") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪ䫻"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠣ࠯ࠥ࠭䫼")+value
		elif mode==l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䫽") and value!=l1l11l_l1_ (u"ࠫ࠵࠭䫾"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨ䫿")+key+l1l11l_l1_ (u"࠭࠽࠾ࠩ䬀")+value
		elif mode==l1l11l_l1_ (u"ࠧࡢ࡮࡯ࠫ䬁"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫ䬂")+key+l1l11l_l1_ (u"ࠩࡀࡁࠬ䬃")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠪࠤ࠰ࠦࠧ䬄"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠫࠫࠬࠧ䬅"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭䬆"),l1l11l_l1_ (u"࠭ࠧ䬇"),l11llll_l1_,l1l11l_l1_ (u"ࠧࡐࡗࡗࠫ䬈"))
	return l11llll_l1_
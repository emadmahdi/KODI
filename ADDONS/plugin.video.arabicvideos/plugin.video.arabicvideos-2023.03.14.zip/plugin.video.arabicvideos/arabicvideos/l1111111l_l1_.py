# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧᘀ")
menu_name = l1l11l_l1_ (u"ࠬࡥࡃࡎࡎࡢࠫᘁ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"࠭โ็๊สฮࠥ็ึศศํอࠬᘂ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l111l1_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l111ll_l1_(url,text)
	elif mode==474: results = l1l1lll11_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫᘃ"),l11lll_l1_,l1l11l_l1_ (u"ࠨࠩᘄ"),l1l11l_l1_ (u"ࠩࠪᘅ"),l1l11l_l1_ (u"ࠪࠫᘆ"),l1l11l_l1_ (u"ࠫࠬᘇ"),l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᘈ"))
	html = response.content
	l111llll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧᘉ"),html,re.DOTALL)
	l111llll1_l1_ = l111llll1_l1_[0].strip(l1l11l_l1_ (u"ࠧ࠰ࠩᘊ"))
	l111llll1_l1_ = SERVER(l111llll1_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᘋ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᘌ"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᘍ"),l1l11l_l1_ (u"ࠫࠬᘎ"),479,l1l11l_l1_ (u"ࠬ࠭ᘏ"),l1l11l_l1_ (u"࠭ࠧᘐ"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᘑ"))
	addMenuItem(l1l11l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᘒ"),l1l11l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᘓ"),l1l11l_l1_ (u"ࠪࠫᘔ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘕ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᘖ")+menu_name+l1l11l_l1_ (u"࠭รโๆส้๋ࠥๅ๋ิฬࠫᘗ"),l111llll1_l1_,471,l1l11l_l1_ (u"ࠧࠨᘘ"),l1l11l_l1_ (u"ࠨࠩᘙ"),l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫᘚ"))
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᘛ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᘜ")+menu_name+l1l11l_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬᘝ"),l111llll1_l1_,471,l1l11l_l1_ (u"࠭ࠧᘞ"),l1l11l_l1_ (u"ࠧࠨᘟ"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᘠ"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᘡ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘢ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭ᘣ"))
		#if title in l1llll1_l1_: continue
		l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠬࡩࡡࡵ࠿ࡲࡲࡱ࡯࡮ࡦ࠯ࡰࡳࡻ࡯ࡥࡴ࠳ࠪᘤ"),l1l11l_l1_ (u"࠭ࡣࡢࡶࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡱࡴࡼࡩࡦࡵࠪᘥ"))
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘦ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᘧ")+menu_name+title,l1111l_l1_,474)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᘨ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᘩ"),l1l11l_l1_ (u"ࠫࠬᘪ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩᘫ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦᘬ"),html,re.DOTALL)
	for l1l11lll_l1_ in l1ll111_l1_:
		block = block.replace(l1l11lll_l1_,l1l11l_l1_ (u"ࠧࠨᘭ"))
	items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᘮ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		#l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄ࠭ᘯ")+category+l1l11l_l1_ (u"ࠪࡁࠬᘰ")+value
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘱ"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩᘲ")+menu_name+title,l1111l_l1_,474)
	return
def l1l1lll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᘳ"),url,l1l11l_l1_ (u"ࠧࠨᘴ"),l1l11l_l1_ (u"ࠨࠩᘵ"),l1l11l_l1_ (u"ࠩࠪᘶ"),l1l11l_l1_ (u"ࠪࠫᘷ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᘸ"))
	html = response.content
	if l1l11l_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࠬᘹ") in url: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠪᘺ"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᘻ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᘼ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if l1l11l_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࠩᘽ") in l1111l_l1_:
				if l1l11l_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࡂࡧࡂ࡫࡮ࡨ࡮࡬ࡷ࡭࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᘾ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃ࡯࡯࡮࡬ࡲࡪ࠳࡭ࡰࡸ࡬ࡩࡸ࠷ࠧᘿ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽࡮࡫ࡶࡧࠬᙀ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡶࡹ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࠬᙁ") in l1111l_l1_: continue
				if l1l11l_l1_ (u"ࠧๆ่ำࠤฬ๊ศะษํอࠬᙂ") in title and l1l11l_l1_ (u"ࠨࡦࡲࡁࡷࡧࡴࡪࡰࡪࠫᙃ") not in l1111l_l1_: continue
			else: title = l1l11l_l1_ (u"ࠩอีฯ๐ศࠡสสืฯิฯศ็࠽ࠤࠥ࠭ᙄ")+title
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙅ"),menu_name+title,l1111l_l1_,471)
	else: l111l1_l1_(url)
	return
def l111l1_l1_(url,request=l1l11l_l1_ (u"ࠫࠬᙆ")):
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩᙇ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᙈ"),url,l1l11l_l1_ (u"ࠧࠨᙉ"),l1l11l_l1_ (u"ࠨࠩᙊ"),l1l11l_l1_ (u"ࠩࠪᙋ"),l1l11l_l1_ (u"ࠪࠫᙌ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᙍ"))
	html = response.content
	items = []
	if request==l1l11l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧᙎ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡪࡱࡻࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙏ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠫᙐ"),block,re.DOTALL)
		l1ll1111_l1_,titles,l111111l1_l1_ = zip(*items)
		items = zip(l111111l1_l1_,l1ll1111_l1_,titles)
	elif request==l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᙑ"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠮࠮ࠫࡁࠬࡀࡸࡺࡹ࡭ࡧࡁࠫᙒ"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠨᙓ"),block,re.DOTALL)
		l1ll1111_l1_,titles,l111111l1_l1_ = zip(*items)
		items = zip(l111111l1_l1_,l1ll1111_l1_,titles)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᙔ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬᙕ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᙖ"),html,re.DOTALL)
		if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᙗ"),html,re.DOTALL)
		if not l1ll111_l1_: return
		block = l1ll111_l1_[0]
	if not items: items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙘ"),block,re.DOTALL)
	if not items: items = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᙙ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"ู้ࠪอ็ะหࠪᙚ"),l1l11l_l1_ (u"ࠫๆ๐ไๆࠩᙛ"),l1l11l_l1_ (u"ࠬอฺ็์ฬࠫᙜ"),l1l11l_l1_ (u"࠭ใๅ์หࠫᙝ"),l1l11l_l1_ (u"ࠧศ฻็ห๋࠭ᙞ"),l1l11l_l1_ (u"ࠨ้าหๆ࠭ᙟ"),l1l11l_l1_ (u"่ࠩฬฬืวสࠩᙠ"),l1l11l_l1_ (u"ࠪ฽ึ฼ࠧᙡ"),l1l11l_l1_ (u"๊ࠫํัอษ้ࠫᙢ"),l1l11l_l1_ (u"ࠬอไษ๊่ࠫᙣ"),l1l11l_l1_ (u"࠭ๅิำะ๎ฮ࠭ᙤ")]
	for img,l1111l_l1_,title in items:
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠧ࠰ࠩᙥ"))
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᙦ") not in l1111l_l1_: l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࠫᙧ")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠪ࠳ࠬᙨ"))
		if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᙩ") not in img: img = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࠧᙪ")+img.strip(l1l11l_l1_ (u"࠭࠯ࠨᙫ"))
		#l1111l_l1_ = unescapeHTML(l1111l_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l11l_l1_ (u"ࠧࠡࠩᙬ"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ᙭"),title,re.DOTALL)
		if any(value in title for value in l111l11ll_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᙮"),menu_name+title,l1111l_l1_,472,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠪห้ำไใหࠪᙯ") in title:
			title = l1l11l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᙰ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙱ"),menu_name+title,l1111l_l1_,473,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫᙲ") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙳ"),menu_name+title,l1111l_l1_,471,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙴ"),menu_name+title,l1111l_l1_,473,img)
	if request not in [l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫᙵ"),l1l11l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᙶ")]:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᙷ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᙸ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				if l1111l_l1_==l1l11l_l1_ (u"࠭ࠣࠨᙹ"): continue
				l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩᙺ")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠨ࠱ࠪᙻ"))
				title = unescapeHTML(title)
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙼ"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡࠩᙽ")+title,l1111l_l1_,471)
		l11l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᙾ"),html,re.DOTALL)
		if l11l1l111_l1_:
			l1111l_l1_ = l11l1l111_l1_[0]
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙿ"),menu_name+l1l11l_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭ "),l1111l_l1_,471)
	return
def l111ll_l1_(url,l11111l11_l1_):
	#LOG_THIS(l1l11l_l1_ (u"ࠧࠨᚁ"),l1l11l_l1_ (u"ࠨ࠳࠴࠵࠶ࠦࠠࠨᚂ")+url)
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭ᚃ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᚄ"),url,l1l11l_l1_ (u"ࠫࠬᚅ"),l1l11l_l1_ (u"ࠬ࠭ᚆ"),l1l11l_l1_ (u"࠭ࠧᚇ"),l1l11l_l1_ (u"ࠧࠨᚈ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪᚉ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᚊ"),html,re.DOTALL)
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᚋ")+l11111l11_l1_+l1l11l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᚌ"),html,re.DOTALL)
	items = []
	# l111lll1l_l1_
	if l111l11l1_l1_ and not l11111l11_l1_:
		img = re.findall(l1l11l_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚍ"),html,re.DOTALL)
		img = img[0]
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࡝࠮ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪᚎ"),block,re.DOTALL)
		for l11111l11_l1_,title in items: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚏ"),menu_name+title,url,473,img,l1l11l_l1_ (u"ࠨࠩᚐ"),l11111l11_l1_)
	# l1l11l1_l1_
	elif l1ll1lll1_l1_:
		#img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪᚑ"))
		img = re.findall(l1l11l_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᚒ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠦࡹ࡯ࡴ࡭ࡧࡀࠫ࠭࠴ࠪࡀࠫࠪࠤ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࠥᚓ"),block,re.DOTALL)
		if items:
			for title,l1111l_l1_ in items:
				l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࠧᚔ")+l1111l_l1_.strip(l1l11l_l1_ (u"࠭࠯ࠨᚕ"))
				addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᚖ"),menu_name+title,l1111l_l1_,472,img)
		else:
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᚗ"),block,re.DOTALL)
			for l1111l_l1_,title,img in items:
				if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᚘ") not in l1111l_l1_: l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠪ࠳ࠬᚙ")+l1111l_l1_.strip(l1l11l_l1_ (u"ࠫ࠴࠭ᚚ"))
				addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᚛"),menu_name+title,l1111l_l1_,472,img)
	if l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠢࠨ᚜") in html:
		if items: addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᚝"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᚞"),l1l11l_l1_ (u"ࠩࠪ᚟"),9999)
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᚠ"),menu_name+l1l11l_l1_ (u"๊ࠫ๎วื์฼ࠤีอสࠡื็อࠬᚡ"),url,471)
	#else: l111l1_l1_(url)
	return
def PLAY(url):
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩᚢ"))
	l1ll1lll_l1_ = []
	# l111111ll_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪᚣ"),url,l1l11l_l1_ (u"ࠧࠨᚤ"),l1l11l_l1_ (u"ࠨࠩᚥ"),l1l11l_l1_ (u"ࠩࠪᚦ"),l1l11l_l1_ (u"ࠪࠫᚧ"),l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᚨ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤ࡭ࡀࠪᚩ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1l1l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᚪ"),block,re.DOTALL)
		if l1l1l_l1_ and l1l11_l1_(script_name,url,l1l1l_l1_,True): return
	# default l1l1ll11l_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᚫ"),html,re.DOTALL)
	if l1111l_l1_:
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡻࡦࡺࡣࡩࠩᚬ")
		if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᚭ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩᚮ")+l1111l_l1_
		l1ll1lll_l1_.append(l1111l_l1_)
	# l1l11ll1l_l1_ l1l1ll11l_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧ࡙ࡗࡒࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚯ"),html,re.DOTALL)
	if l1111l_l1_:
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ᚰ")
		if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫᚱ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᚲ")+l1111l_l1_
		l1ll1lll_l1_.append(l1111l_l1_)
	# l1l1ll11l_l1_ l1ll1111_l1_
	url2 = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬᚳ"),l1l11l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠯ࡲ࡫ࡴࠬᚴ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᚵ"),url2,l1l11l_l1_ (u"ࠫࠬᚶ"),l1l11l_l1_ (u"ࠬ࠭ᚷ"),l1l11l_l1_ (u"࠭ࠧᚸ"),l1l11l_l1_ (u"ࠧࠨᚹ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ᚺ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᚻ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩᚼ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᚽ")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᚾ")
			if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫᚿ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᛀ")+l1111l_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	url2 = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬᛁ"),l1l11l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡨࡱࠩᛂ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᛃ"),url2,l1l11l_l1_ (u"ࠫࠬᛄ"),l1l11l_l1_ (u"ࠬ࠭ᛅ"),l1l11l_l1_ (u"࠭ࠧᛆ"),l1l11l_l1_ (u"ࠧࠨᛇ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ᛈ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᛉ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬᛊ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᛋ")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᛌ")
			if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫᛍ") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᛎ")+l1111l_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ᛏ"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᛐ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠪࠫᛑ"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠫࠬᛒ"): return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧᛓ"),l1l11l_l1_ (u"࠭ࠫࠨᛔ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨᛕ")+search
	l111l1_l1_(url)
	return
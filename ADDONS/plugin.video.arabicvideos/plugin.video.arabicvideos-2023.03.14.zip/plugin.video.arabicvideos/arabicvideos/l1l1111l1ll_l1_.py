# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭䣴")
menu_name = l1l11l_l1_ (u"ࠨࡡࡗ࡚ࡋࡥࠧ䣵")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ䣶")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l111l1_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l111ll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䣷"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬ䣸"),l1l11l_l1_ (u"ࠬ࠭䣹"),l1l11l_l1_ (u"࠭ࠧ䣺"),l1l11l_l1_ (u"ࠧࠨ䣻"),l1l11l_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䣼"))
	html = response.content
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䣽"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䣾"),l1l11l_l1_ (u"ࠫࠬ䣿"),469,l1l11l_l1_ (u"ࠬ࠭䤀"),l1l11l_l1_ (u"࠭ࠧ䤁"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䤂"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䤃"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䤄")+menu_name+l1l11l_l1_ (u"ࠪวำืࠠศๆะ่็อสࠨ䤅"),l11lll_l1_,461,l1l11l_l1_ (u"ࠫࠬ䤆"),l1l11l_l1_ (u"ࠬ࠭䤇"),l1l11l_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䤈"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䤉"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䤊"),l1l11l_l1_ (u"ࠩࠪ䤋"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡲ࡫࡮ࡶ࠯ࡥࡸࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ䤌"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ䤍"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			#if l1111l_l1_==l1l11l_l1_ (u"ࠬࠩࠧ䤎"): continue
			if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䤏") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			if title==l1l11l_l1_ (u"ࠧศๆิส๏ู๊สࠩ䤐"): title = l1l11l_l1_ (u"ࠨฮา๎ิࠦอๅไสฮࠥะ๊โ์ࠣๅฬ์ࠧ䤑")
			if title in l1llll1_l1_: continue
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䤒"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䤓")+menu_name+title,l1111l_l1_,461)
	#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡌ࡯ࡰࡶࡨࡶࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䤔"),html,re.DOTALL)
	#if l1ll111_l1_:
	#	block = l1ll111_l1_[0]
	#	items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䤕"),block,re.DOTALL)
	#	for l1111l_l1_,title in items:
	#		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䤖"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䤗")+menu_name+title,l1111l_l1_,461)
	return
def l111l1_l1_(url,l11l1ll11_l1_=l1l11l_l1_ (u"ࠨࠩ䤘")):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䤙"),l1l11l_l1_ (u"ࠪࠫ䤚"),l11l1ll11_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䤛"),url,l1l11l_l1_ (u"ࠬ࠭䤜"),l1l11l_l1_ (u"࠭ࠧ䤝"),l1l11l_l1_ (u"ࠧࠨ䤞"),l1l11l_l1_ (u"ࠨࠩ䤟"),l1l11l_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ䤠"))
	html = response.content
	if l11l1ll11_l1_!=l1l11l_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䤡"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࠭ࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡶ࡯ࡥࠦ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࠳ࡴࡪࡶ࡯ࡩࠧ࠭䤢"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬษฮาࠢส่า๊โศฬࠫ࠲࠯ࡅࠩࡪࡦࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠦࠬ䤣"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䤤"),block,re.DOTALL)
		l1l1l11_l1_ = []
		l111l11ll_l1_ = [l1l11l_l1_ (u"ࠧๆึส๋ิฯࠧ䤥"),l1l11l_l1_ (u"ࠨใํ่๊࠭䤦"),l1l11l_l1_ (u"ࠩส฾๋๐ษࠨ䤧"),l1l11l_l1_ (u"ࠪ็้๐ศࠨ䤨"),l1l11l_l1_ (u"ࠫฬ฿ไศ่ࠪ䤩"),l1l11l_l1_ (u"ࠬํฯศใࠪ䤪"),l1l11l_l1_ (u"࠭ๅษษิหฮ࠭䤫"),l1l11l_l1_ (u"ฺࠧำูࠫ䤬"),l1l11l_l1_ (u"ࠨ็๊ีัอๆࠨ䤭"),l1l11l_l1_ (u"ࠩส่อ๎ๅࠨ䤮")]
		for l1111l_l1_,title,img in items:
			if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䤯") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = UNQUOTE(l1111l_l1_)	#.strip(l1l11l_l1_ (u"ࠫ࠴࠭䤰"))
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ䤱"),title,re.DOTALL)
			if any(value in title for value in l111l11ll_l1_):
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䤲"),menu_name+title,l1111l_l1_,462,img)
			elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠧศๆะ่็ฯࠧ䤳") in title:
				title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䤴") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䤵"),menu_name+title,l1111l_l1_,463,img)
					l1l1l11_l1_.append(title)
			else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䤶"),menu_name+title,l1111l_l1_,463,img)
	if l11l1ll11_l1_!=l1l11l_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䤷"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䤸"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䤹"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠧࠡࠩ䤺"))
				if l1111l_l1_==l1l11l_l1_ (u"ࠣࠤ䤻"): continue
				if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䤼") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
				#title = unescapeHTML(title)
				if title!=l1l11l_l1_ (u"ࠪࠫ䤽"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䤾"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ䤿")+title,l1111l_l1_,461)
	return
def l111ll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ䥀"),l1l11l_l1_ (u"ࠧࠨ䥁"),l1l11l_l1_ (u"ࠨࡇࡓࡍࡘࡕࡄࡆࡕࠪ䥂"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䥃"),url,l1l11l_l1_ (u"ࠪࠫ䥄"),l1l11l_l1_ (u"ࠫࠬ䥅"),l1l11l_l1_ (u"ࠬ࠭䥆"),l1l11l_l1_ (u"࠭ࠧ䥇"),l1l11l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䥈"))
	html = response.content
	# l1l11l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠪࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡥࡢࡦ࠰ࡸ࡮ࡺ࡬ࡦࠤࠪ䥉"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䥊"),block,re.DOTALL)
		for l1111l_l1_,title,img in items:
			if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䥋") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䥌"),menu_name+title,l1111l_l1_,462,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ䥍"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䥎"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"ࠧࠡࠩ䥏"))
			if l1111l_l1_==l1l11l_l1_ (u"ࠣࠤ䥐"): continue
			if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䥑") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			#title = unescapeHTML(title)
			if title!=l1l11l_l1_ (u"ࠪࠫ䥒"): addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䥓"),menu_name+l1l11l_l1_ (u"ࠬ฻แฮหࠣࠫ䥔")+title,l1111l_l1_,463)
	return
def PLAY(url):
	l1ll1lll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䥕"),url,l1l11l_l1_ (u"ࠧࠨ䥖"),l1l11l_l1_ (u"ࠨࠩ䥗"),l1l11l_l1_ (u"ࠩࠪ䥘"),l1l11l_l1_ (u"ࠪࠫ䥙"),l1l11l_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䥚"))
	html = response.content
	# l1l11ll1l_l1_ l1111l_l1_
	l1l111l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨ࡚ࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䥛"),html,re.DOTALL)
	if l1l111l11l_l1_:
		l1l111l11l_l1_ = l1l111l11l_l1_[0]
		if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䥜") not in l1l111l11l_l1_:
			if l1l11l_l1_ (u"ࠧ࠰࠱ࠪ䥝") in l1l111l11l_l1_: l1l111l11l_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ䥞")+l1l111l11l_l1_
			else: l1l111l11l_l1_ = l11lll_l1_+l1l111l11l_l1_
		l1l111l11l_l1_ = l1l111l11l_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ䥟")
		l1ll1lll_l1_.append(l1l111l11l_l1_)
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡦ࠶࠻࠺ࡣࡧࡩࡳࡷ࡫ࠨ࠯ࠬࡂ࠭ࡸࡳࡡ࡭࡮࠱࠮ࡄࠨࡖࡪࡦࡨࡳࡘ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࠦࡕࡲࡡࡺࠤࠪ䥠"),html,re.DOTALL)
	if l1ll111_l1_:
		l11ll1l11111_l1_,l11ll1l1111l_l1_ = l1ll111_l1_[0]
		names = re.findall(l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䥡"),l11ll1l11111_l1_,re.DOTALL)
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡹࡥࡵࡘ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦ䥢"),l11ll1l1111l_l1_,re.DOTALL)
		l11ll11lllll_l1_ = zip(names,l1ll1111_l1_)
		for name,l1l1lll1l111_l1_ in l11ll11lllll_l1_:
			l1l1lll1l111_l1_ = l1l1lll1l111_l1_[2:]
			if kodi_version<19: l1l1lll1l111_l1_ = l1l1lll1l111_l1_.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䥣"))
			l1l1lll1l111_l1_ = base64.b64decode(l1l1lll1l111_l1_)
			if kodi_version>18.99: l1l1lll1l111_l1_ = l1l1lll1l111_l1_.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䥤"))
			l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䥥"),l1l1lll1l111_l1_,re.DOTALL)
			l1111l_l1_ = l1111l_l1_[0]
		if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䥦") not in l1111l_l1_:
			if l1l11l_l1_ (u"ࠪ࠳࠴࠭䥧") in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䥨")+l1111l_l1_
			else: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䥩")+name+l1l11l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䥪")
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䥫"),l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䥬"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l1l11l_l1_ (u"ࠩࠣࠫ䥭") in search:
		if showdialogs: DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ䥮"),l1l11l_l1_ (u"ࠫࠬ䥯"),l1l11l_l1_ (u"࡚ࠬࡖࡇࡗࡑࠤ๊๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫ䥰"),l1l11l_l1_ (u"࠭ไๅลึๅࠥอไษฯฮࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ้อ๋ࠠ฻่่ࠥ฿ๆะฺ่ࠢอࠦรไอิࠤ๊์ࠠไๆ่อࠥ๎วฮัฬࠤ࠳࠴࠮ࠡ์ิะ๎ࠦวๅสะฯࠥ฿ๆࠡๅ็้ฮ่ࠦศฯาอࠥ็โุࠩ䥱"))
		return
	#search = search.replace(l1l11l_l1_ (u"ࠧࠡࠩ䥲"),l1l11l_l1_ (u"ࠨ࠯ࠪ䥳"))
	#url = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ䥴")+search
	url = l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡶ࠵ࠧ䥵")+search+l1l11l_l1_ (u"ࠫ࠴࠭䥶")
	l111l1_l1_(url)
	return
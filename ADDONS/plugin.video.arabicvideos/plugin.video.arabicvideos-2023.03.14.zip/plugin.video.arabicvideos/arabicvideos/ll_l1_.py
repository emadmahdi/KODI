# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
#
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㜝")
#l1lll1l11l1l_l1_ = [ l1l11l_l1_ (u"ࠬࡳࡹࡴࡶࡵࡩࡦࡳࠧ㜞"),l1l11l_l1_ (u"࠭ࡶࡪ࡯ࡳࡰࡪ࠭㜟"),l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡳࠧ㜠"),l1l11l_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭㜡") ]
l1lll1l11l1l_l1_ = []
headers = {l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㜢"):l1l11l_l1_ (u"ࠪࠫ㜣")}
def l1l_l1_(l1lllll_l1_,script_name=l1l11l_l1_ (u"ࠫࠬ㜤"),type=l1l11l_l1_ (u"ࠬ࠭㜥"),url=l1l11l_l1_ (u"࠭ࠧ㜦")):
	#DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไาษห฻ࠥอไๆ่สือ࠭㜧"),l1lllll_l1_)
	if not l1lllll_l1_:
		LOG_THIS(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㜨"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ㜩")+script_name+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫ㜪")+type+l1l11l_l1_ (u"ࠫࠥࡣࠧ㜫"))
		l1l1l11llll1_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ㜬"),l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ㜭"),l1l11l_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭㜮"))
		datetime = time.strftime(l1l11l_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩ㜯"),time.gmtime(now))
		line = datetime,url
		key = script_name+l1l11l_l1_ (u"ࠩࠣࠤࠥࠦࠧ㜰")+addon_version+l1l11l_l1_ (u"ࠪࠤࠥࠦࠠࠨ㜱")+str(kodi_version)
		if key not in list(l1l1l11llll1_l1_.keys()): l1l1l11llll1_l1_[key] = [line]
		else: l1l1l11llll1_l1_[key].append(line)
		total = 0
		for key in list(l1l1l11llll1_l1_.keys()):
			l1l1l11llll1_l1_[key] = list(set(l1l1l11llll1_l1_[key]))
			total += len(l1l1l11llll1_l1_[key])
		DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㜲"),l1l11l_l1_ (u"ࠬ࠭㜳"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㜴"),l1l11l_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠻ࠥ็๊ะ์๋๋ฬะࠧ㜵")+l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㜶")+l1l11l_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ㜷")+str(total))
		if total>=7:
			yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࠫ㜸"),l1l11l_l1_ (u"ࠫࠬ㜹"),l1l11l_l1_ (u"ࠬ࠭㜺"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㜻"),l1l11l_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠻ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ㜼"))
			if yes==1:
				l1l1l1l11l11_l1_ = l1l11l_l1_ (u"ࠨࠩ㜽")
				for key in list(l1l1l11llll1_l1_.keys()):
					l1l1l1l11l11_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㜾")+key
					l1lll1ll11l1_l1_ = sorted(l1l1l11llll1_l1_[key],reverse=False,key=lambda l1l1l1111lll_l1_: l1l1l1111lll_l1_[0])
					for datetime,url in l1lll1ll11l1_l1_:
						l1l1l1l11l11_l1_ += l1l11l_l1_ (u"ࠪࡠࡳ࠭㜿")+datetime+l1l11l_l1_ (u"ࠫࠥࠦࠠࠡࠩ㝀")+UNQUOTE(url)
					l1l1l1l11l11_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㝁")
				import l111l1l111l_l1_
				l11ll11l1ll_l1_ = l1l11l_l1_ (u"࠭ࡁࡗ࠼ࠣࠫ㝂")+l1l11ll111l_l1_(32)+l1l11l_l1_ (u"ࠧ࠮ࡘ࡬ࡨࡪࡵࡳࠨ㝃")
				succeeded = l111l1l111l_l1_.l1l1lll111l_l1_(l11ll11l1ll_l1_,l1l11l_l1_ (u"ࠨࠩ㝄"),False,l1l11l_l1_ (u"ࠩࠪ㝅"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㝆"),l1l11l_l1_ (u"ࠫࠬ㝇"),l1l1l1l11l11_l1_)
				if succeeded: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㝈"),l1l11l_l1_ (u"࠭ࠧ㝉"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㝊"),l1l11l_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫ㝋"))
				else: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㝌"),l1l11l_l1_ (u"ࠪࠫ㝍"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㝎"),l1l11l_l1_ (u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢส่สืำศๆࠪ㝏"))
			if yes!=-1:
				l1l1l11llll1_l1_ = {}
				DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ㝐"),l1l11l_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭㝑"))
		if l1l1l11llll1_l1_: WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭㝒"),l1l11l_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ㝓"),l1l1l11llll1_l1_,PERMANENT_CACHE)
		return
	l1lllll_l1_ = list(set(l1lllll_l1_))
	l1l1lll_l1_,l1ll1lll_l1_ = l1l11llll1l1_l1_(l1lllll_l1_)
	l1ll1l1lll1l_l1_ = str(l1ll1lll_l1_).count(l1l11l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ㝔"))
	l1l1l1llll11_l1_ = str(l1ll1lll_l1_).count(l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㝕"))
	l1ll1l1lllll_l1_ = len(l1ll1lll_l1_)-l1ll1l1lll1l_l1_-l1l1l1llll11_l1_
	l1l1l1l1l111_l1_ = l1l11l_l1_ (u"๋ࠬิศ้าอ࠿࠭㝖")+str(l1ll1l1lll1l_l1_)+l1l11l_l1_ (u"࠭ࠠࠡࠢࠣฮา๋๊ๅ࠼ࠪ㝗")+str(l1l1l1llll11_l1_)+l1l11l_l1_ (u"ࠧࠡࠢࠣࠤศิั๊࠼ࠪ㝘")+str(l1ll1l1lllll_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㝙"),l1l11l_l1_ (u"ࠩࠪ㝚"),str(l1ll1l1lll1l_l1_),str(l1l1l1llll11_l1_))
	#selection = DIALOG_SELECT(l1l1l1l1l111_l1_, l1ll1lll_l1_)
	if not l1ll1lll_l1_:
		result = l1l11l_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ㝛")
		l1ll1llll111_l1_ = l1l11l_l1_ (u"ࠫࠬ㝜")
	else:
		while True:
			l1ll1llll111_l1_ = l1l11l_l1_ (u"ࠬ࠭㝝")
			if len(l1ll1lll_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1l1l1l1l111_l1_,l1l1lll_l1_)
			if selection==-1: result = l1l11l_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ㝞")
			else:
				title = l1l1lll_l1_[selection]
				l1111l_l1_ = l1ll1lll_l1_[selection]
				#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㝟"),l1l11l_l1_ (u"ࠨࠩ㝠"),title,l1111l_l1_)
				if l1l11l_l1_ (u"ࠩึ๎ึ็ัࠨ㝡") in title and l1l11l_l1_ (u"ࠪ࠶๊า็้ๆ࠵ࠫ㝢") in title:
					LOG_THIS(l1l11l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㝣"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࡘ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪ㝤")+title+l1l11l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭㝥")+l1111l_l1_+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ㝦"))
					import l111l1l111l_l1_
					l111l1l111l_l1_.MAIN(156)
					result = l1l11l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㝧")
				else:
					LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㝨"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ㝩")+title+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ㝪")+l1111l_l1_+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ㝫"))
					result,l1ll1llll111_l1_,l1lllllllll1_l1_ = l1l1llll11l1_l1_(l1111l_l1_,script_name,type)
					#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㝬"),l1l11l_l1_ (u"ࠧࠨ㝭"),result,l1ll1llll111_l1_)
			if l1l11l_l1_ (u"ࠨ࡞ࡱࠫ㝮") not in l1ll1llll111_l1_: l1l1lll1lll1_l1_,l1ll11l11ll_l1_ = l1ll1llll111_l1_,l1l11l_l1_ (u"ࠩࠪ㝯")
			else: l1l1lll1lll1_l1_,l1ll11l11ll_l1_ = l1ll1llll111_l1_.split(l1l11l_l1_ (u"ࠪࡠࡳ࠭㝰"),1)
			if result in [l1l11l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ㝱"),l1l11l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㝲"),l1l11l_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㝳"),l1l11l_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ㝴")] or len(l1ll1lll_l1_)==1: break
			elif result in [l1l11l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㝵"),l1l11l_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ㝶"),l1l11l_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ㝷")]: break
			elif result not in [l1l11l_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ㝸"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㝹")]: DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㝺"),l1l11l_l1_ (u"ࠧࠨ㝻"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㝼"),l1l11l_l1_ (u"ࠩสุ่๐ัโำฺ่๊๊ࠣࠦ็็ࠤัืศࠡีํีๆืࠠ฻์ิ๋ࠬ㝽")+l1l11l_l1_ (u"ࠪࡠࡳ࠭㝾")+l1l1lll1lll1_l1_+l1l11l_l1_ (u"ࠫࡡࡴࠧ㝿")+l1ll11l11ll_l1_)
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㞀"),l1l11l_l1_ (u"࠭ࠧ㞁"),l1l11l_l1_ (u"ࠧࠨ㞂"),str(l1lllllllll1_l1_))
	if result==l1l11l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㞃") and len(l1l1lll_l1_)>0: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㞄"),l1l11l_l1_ (u"ࠪࠫ㞅"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㞆"),l1l11l_l1_ (u"ู๊ࠬาใิࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠣะึฮࠠโ์า๎ํฺ๋ࠦำ๊ࠫ㞇")+l1l11l_l1_ (u"࠭࡜࡯ࠩ㞈")+l1ll1llll111_l1_)
	elif result in [l1l11l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㞉"),l1l11l_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ㞊")] and l1ll1llll111_l1_!=l1l11l_l1_ (u"ࠩࠪ㞋"): DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㞌"),l1l11l_l1_ (u"ࠫࠬ㞍"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㞎"),l1ll1llll111_l1_)
	#elif l1ll1llll111_l1_==l1l11l_l1_ (u"࠭ࡒࡆࡖࡘࡖࡓࡥࡔࡐࡡ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㞏"): result = l1lllllllll1_l1_
	l1l11l_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡩࡧࠢࡵࡩࡸࡻ࡬ࡵࠢ࡬ࡲࠥࡡࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ࠱࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪࡡ࠿ࠐࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡘࡪࡹࡴ࠻ࠢࠣࠤࠬ࠱ࡳࡺࡵ࠱ࡥࡷ࡭ࡶ࡜࠲ࡠ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠲࡞ࠫࠍࠍࠎࡾࡢ࡮ࡥࡳࡰࡺ࡭ࡩ࡯࠰ࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫࡥࡩࡪ࡯࡯ࡡ࡫ࡥࡳࡪ࡬ࡦ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠣࡼࡧࡳࡣࡨࡷ࡬࠲ࡑ࡯ࡳࡵࡋࡷࡩࡲ࠮ࠩࠪࠌࠌࠍࡵࡲࡡࡺࡡ࡬ࡸࡪࡳࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭ࡶࡡࡵࡪࡀࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡄࡳ࡯ࡥࡧࡀ࠵࠹࠹ࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࠫ࠳ࡇࡸࠨ࠷ࡉ࡭ࡷࡣ࠳ࡳࡼ࡛ࡺࡷ࠺ࡓࠪ࠭ࠏࠏࠉࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡱ࡮ࡤࡽ࠭࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࡮ࡹ࠵࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮࠱࡬ࡴ࡭ࡵ࡮ࡦ࠱࠴࠶࠸࠺࠴࠸࠰ࡰࡴ࠹࠭ࠬࡱ࡮ࡤࡽࡤ࡯ࡴࡦ࡯ࠬࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪฮ๊ࠦวๅษ็฾ฬวࠧ࠭ࠩࠪ࠭ࠏࠏࠢࠣࠤ㞐")
	return result
	#if script_name==l1l11l_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㞑"): menu_name = l1l11l_l1_ (u"ࠩࡋࡐࡆ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㞒")
	#elif script_name==l1l11l_l1_ (u"ࠪ࠸ࡍࡋࡌࡂࡎࠪ㞓"): menu_name = l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡈࡆࡎࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㞔")
	#elif script_name==l1l11l_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㞕"): menu_name = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡃࡎࡑࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㞖")
	#elif script_name==l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㞗"): menu_name = l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡗࡍ࠺ࠠࠨ㞘")
	#size = len(l11111ll1_l1_)
	#for i in range(0,size):
	#	title = l1ll1ll1ll1l_l1_[i]
	#	l1111l_l1_ = l11111ll1_l1_[i]
	#	addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㞙"),menu_name+title,l1111l_l1_,160,l1l11l_l1_ (u"ࠪࠫ㞚"),l1l11l_l1_ (u"ࠫࠬ㞛"),script_name)
def l1l1llll11l1_l1_(url,script_name,type=l1l11l_l1_ (u"ࠬ࠭㞜")):
	url = url.strip(l1l11l_l1_ (u"࠭ࠠࠨ㞝")).strip(l1l11l_l1_ (u"ࠧࠧࠩ㞞")).strip(l1l11l_l1_ (u"ࠨࡁࠪ㞟")).strip(l1l11l_l1_ (u"ࠩ࠲ࠫ㞠"))
	l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1l1lll11_l1_(url)
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㞡"),l1l11l_l1_ (u"ࠫࠬ㞢"),url,l1ll1llll111_l1_)
	if l1ll1llll111_l1_==l1l11l_l1_ (u"ࠬࡋࡘࡊࡖࠪ㞣"): return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	elif l1ll1lll_l1_:
		while True:
			if len(l1ll1lll_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ㞤"), l1l1lll_l1_)
			if selection==-1: result = l1l11l_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ㞥")
			else:
				l1lll1l11ll1_l1_ = l1ll1lll_l1_[selection]
				title = l1l1lll_l1_[selection]
				LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㞦"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡳࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡖࡩࡱ࡫ࡣࡵࡧࡧ࠾ࠥࡡࠠࠨ㞧")+title+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㞨")+str(l1lll1l11ll1_l1_)+l1l11l_l1_ (u"ࠫࠥࡣࠧ㞩"))
				if l1l11l_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ㞪") in l1lll1l11ll1_l1_ and l1l11l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭㞫") in l1lll1l11ll1_l1_:
					l1lll1l1llll_l1_,l1llllll1ll1_l1_,l1lllllllll1_l1_ = l1l1ll111l11_l1_(l1lll1l11ll1_l1_)
					if l1lllllllll1_l1_: l1lll1l11ll1_l1_ = l1lllllllll1_l1_[0]
					else: l1lll1l11ll1_l1_ = l1l11l_l1_ (u"ࠧࠨ㞬")
				if not l1lll1l11ll1_l1_: result = l1l11l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㞭")
				else: result = PLAY_VIDEO(l1lll1l11ll1_l1_,script_name,type)
			if result in [l1l11l_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㞮"),l1l11l_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ㞯")] or len(l1ll1lll_l1_)==1: break
			elif result in [l1l11l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㞰"),l1l11l_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭㞱"),l1l11l_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ㞲")]: break
			else: DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㞳"),l1l11l_l1_ (u"ࠨࠩ㞴"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㞵"),l1l11l_l1_ (u"ࠪห้๋ไโࠢ็้ࠥ๐ูๆๆࠣะึฮࠠๆๆไࠤ฿๐ั่ࠩ㞶"))
	else:
		result = l1l11l_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ㞷")
		videofiletype = GET_VIDEOFILETYPE(url)
		if videofiletype: result = PLAY_VIDEO(url,script_name,type)
	return result,l1ll1llll111_l1_,l1ll1lll_l1_
	#title = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱࠨ㞸") )
	#if l1l11l_l1_ (u"࠭ำ๋ำไีࠥ฿วๆ่ࠢะ์๎ไࠨ㞹") in title:
	#	import l111l1l111l_l1_
	#	l111l1l111l_l1_.MAIN(156)
	#	return l1l11l_l1_ (u"ࠧࠨ㞺")
def l1l1lll11l11_l1_(url):
	# url = url+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㞻")+name+l1l11l_l1_ (u"ࠩࡢࡣࠬ㞼")+type+l1l11l_l1_ (u"ࠪࡣࡤ࠭㞽")+l11_l1_+l1l11l_l1_ (u"ࠫࡤࡥࠧ㞾")+l1l1l1l1_l1_
	# url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡫ࡸࡣࡰ࠲ࡳ࡫ࡴࡀࡰࡤࡱࡪࡪ࠽ࡢ࡭ࡺࡥࡲࡥ࡟ࡸࡣࡷࡧ࡭ࡥ࡟࡮ࡲ࠷ࡣࡤ࠽࠲࠱ࠩ㞿")
	url2,l1ll11l1l111_l1_,server,l1l1l111l111_l1_,name,type,l11_l1_,l1l1l1l1_l1_,source = url,l1l11l_l1_ (u"࠭ࠧ㟀"),l1l11l_l1_ (u"ࠧࠨ㟁"),l1l11l_l1_ (u"ࠨࠩ㟂"),l1l11l_l1_ (u"ࠩࠪ㟃"),l1l11l_l1_ (u"ࠪࠫ㟄"),l1l11l_l1_ (u"ࠫࠬ㟅"),l1l11l_l1_ (u"ࠬ࠭㟆"),l1l11l_l1_ (u"࠭ࠧ㟇")
	if l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㟈") in url:
		url2,l1ll11l1l111_l1_ = url.split(l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㟉"),1)
		l1ll11l1l111_l1_ = l1ll11l1l111_l1_+l1l11l_l1_ (u"ࠩࡢࡣࠬ㟊")+l1l11l_l1_ (u"ࠪࡣࡤ࠭㟋")+l1l11l_l1_ (u"ࠫࡤࡥࠧ㟌")+l1l11l_l1_ (u"ࠬࡥ࡟ࠨ㟍")
		l1ll11l1l111_l1_ = l1ll11l1l111_l1_.lower()
		name,type,l11_l1_,l1l1l1l1_l1_,source = l1ll11l1l111_l1_.split(l1l11l_l1_ (u"࠭࡟ࡠࠩ㟎"))[:5]
	if l1l1l1l1_l1_==l1l11l_l1_ (u"ࠧࠨ㟏"): l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨ࠲ࠪ㟐")
	else: l1l1l1l1_l1_ = l1l1l1l1_l1_.replace(l1l11l_l1_ (u"ࠩࡳࠫ㟑"),l1l11l_l1_ (u"ࠪࠫ㟒")).replace(l1l11l_l1_ (u"ࠫࠥ࠭㟓"),l1l11l_l1_ (u"ࠬ࠭㟔"))
	url2 = url2.strip(l1l11l_l1_ (u"࠭࠿ࠨ㟕")).strip(l1l11l_l1_ (u"ࠧ࠰ࠩ㟖")).strip(l1l11l_l1_ (u"ࠨࠨࠪ㟗"))
	server = SERVER(url2,l1l11l_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ㟘"))
	if name: l1l1l111l111_l1_ = name
	elif source: l1l1l111l111_l1_ = source
	else: l1l1l111l111_l1_ = server
	l1l1l111l111_l1_ = SERVER(l1l1l111l111_l1_,l1l11l_l1_ (u"ࠪࡲࡦࡳࡥࠨ㟙"))
	name = name.replace(l1l11l_l1_ (u"๊ࠫฮวีำࠪ㟚"),l1l11l_l1_ (u"ࠬ࠭㟛")).replace(l1l11l_l1_ (u"࠭ำ๋ำไีࠬ㟜"),l1l11l_l1_ (u"ࠧࠨ㟝")).replace(l1l11l_l1_ (u"ࠨษ็ࠤࠬ㟞"),l1l11l_l1_ (u"ࠩࠣࠫ㟟")).replace(l1l11l_l1_ (u"ࠪࠤࠥ࠭㟠"),l1l11l_l1_ (u"ࠫࠥ࠭㟡"))
	l1ll11l1l111_l1_ = l1ll11l1l111_l1_.replace(l1l11l_l1_ (u"๋ࠬศศึิࠫ㟢"),l1l11l_l1_ (u"࠭ࠧ㟣")).replace(l1l11l_l1_ (u"ࠧิ์ิๅึ࠭㟤"),l1l11l_l1_ (u"ࠨࠩ㟥")).replace(l1l11l_l1_ (u"ࠩส่ࠥ࠭㟦"),l1l11l_l1_ (u"ࠪࠤࠬ㟧")).replace(l1l11l_l1_ (u"ࠫࠥࠦࠧ㟨"),l1l11l_l1_ (u"ࠬࠦࠧ㟩"))
	l1l1l111l111_l1_ = l1l1l111l111_l1_.replace(l1l11l_l1_ (u"࠭ๅษษืีࠬ㟪"),l1l11l_l1_ (u"ࠧࠨ㟫")).replace(l1l11l_l1_ (u"ࠨีํีๆืࠧ㟬"),l1l11l_l1_ (u"ࠩࠪ㟭")).replace(l1l11l_l1_ (u"ࠪห้ࠦࠧ㟮"),l1l11l_l1_ (u"ࠫࠥ࠭㟯")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ㟰"),l1l11l_l1_ (u"࠭ࠠࠨ㟱"))
	return url2,l1ll11l1l111_l1_,server,l1l1l111l111_l1_,name,type,l11_l1_,l1l1l1l1_l1_,source
def l1ll1l1llll1_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㟲"),l1l11l_l1_ (u"ࠨࠩ㟳"),url,l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡃࡅࡐࡊ࠭㟴"))
	# l111llll_l1_	: سيرفر خاص
	# l1ll111l1l1l_l1_		: سيرفر محدد
	# l1l1lll11l1l_l1_		: سيرفر عام معروف
	# l1111l1l_l1_	: سيرفر عام خارجي
	# l1lll1111l1l_l1_	: سيرفر عام خارجي
	l1l1llll1l1l_l1_,name,l111llll_l1_,l1l1lll11l1l_l1_,l1111l1l_l1_,l1ll111l1l1l_l1_,l1lll1111l1l_l1_ = l1l11l_l1_ (u"ࠪࠫ㟵"),l1l11l_l1_ (u"ࠫࠬ㟶"),None,None,None,None,None
	url2,l1ll11l1l111_l1_,server,l1l1l111l111_l1_,name,type,l11_l1_,l1l1l1l1_l1_,source = l1l1lll11l11_l1_(url)
	if l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㟷") in url:
		if   type==l1l11l_l1_ (u"࠭ࡥ࡮ࡤࡨࡨࠬ㟸"): type = l1l11l_l1_ (u"ࠧࠡࠩ㟹")+l1l11l_l1_ (u"ࠨ็ไฺ้࠭㟺")
		elif type==l1l11l_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ㟻"): type = l1l11l_l1_ (u"ࠪࠤࠬ㟼")+l1l11l_l1_ (u"๋ࠫࠪิศ้าอࠬ㟽")
		elif type==l1l11l_l1_ (u"ࠬࡨ࡯ࡵࡪࠪ㟾"): type = l1l11l_l1_ (u"࠭ࠠࠨ㟿")+l1l11l_l1_ (u"ุ่ࠧࠦࠧฬํฯส๋ࠢฮา๋๊ๅࠩ㠀")
		elif type==l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㠁"): type = l1l11l_l1_ (u"ࠩࠣࠫ㠂")+l1l11l_l1_ (u"ࠪࠩࠪࠫสฮ็ํ่ࠬ㠃")
		elif type==l1l11l_l1_ (u"ࠫࠬ㠄"): type = l1l11l_l1_ (u"ࠬࠦࠧ㠅")+l1l11l_l1_ (u"࠭ࠥࠦࠧࠨࠫ㠆")
		if l11_l1_!=l1l11l_l1_ (u"ࠧࠨ㠇"):
			if l1l11l_l1_ (u"ࠨ࡯ࡳ࠸ࠬ㠈") not in l11_l1_: l11_l1_ = l1l11l_l1_ (u"ࠩࠨࠫ㠉")+l11_l1_
			l11_l1_ = l1l11l_l1_ (u"ࠪࠤࠬ㠊")+l11_l1_
		if l1l1l1l1_l1_!=l1l11l_l1_ (u"ࠫࠬ㠋"):
			l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨ㠌")+l1l1l1l1_l1_
			l1l1l1l1_l1_ = l1l11l_l1_ (u"࠭ࠠࠨ㠍")+l1l1l1l1_l1_[-9:]
	#if any(value in server for value in l1lll1l11l1l_l1_): return l1l11l_l1_ (u"ࠧࠨ㠎")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㠏"),l1l11l_l1_ (u"ࠩࠪ㠐"),name,l1l1l111l111_l1_)
	if   l1l11l_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࠩ㠑")		in source: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࠪ㠒")		in source: l111llll_l1_	= l1l11l_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࠫ㠓")
	elif l1l11l_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㠔")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ㠕")		in server: l111llll_l1_	= l1l11l_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ㠖")
	elif l1l11l_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩ㠗") in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ㠘")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ㠙")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭㠚")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭㠛")		in name:   l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ㠜")		in name:   l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ㠝")		in name:   l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠩࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦࠬ㠞")	in name:   l111llll_l1_	= l1l11l_l1_ (u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡴࠬ㠟")
	elif l1l11l_l1_ (u"ࠫๆาัࠨ㠠")			in name:   l111llll_l1_	= l1l11l_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ㠡")
	elif l1l11l_l1_ (u"࠭แๅีฺ๎๋࠭㠢")		in name:   l111llll_l1_	= l1l11l_l1_ (u"ࠧࡱࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪ㠣")
	elif l1l11l_l1_ (u"ࠨࡩࡧࡶ࡮ࡼࡥࠨ㠤")		in url2:   l111llll_l1_	= l1l11l_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࠩ㠥")
	elif l1l11l_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ㠦")		in name:   l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ㠧")		in name:   l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭㠨")		in name:   l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ㠩")	in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭㠪")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠨࡶࡹࡪࡺࡴࠧ㠫")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠩࡷࡺࡰࡹࡡࠨ㠬")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ㠭")		in server: l111llll_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭㠮")		in server: l111llll_l1_	= l1l1l111l111_l1_
	#elif l1l11l_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠴࡮ࡦࡶࠪ㠯")	in url2:   l111llll_l1_	= l1l11l_l1_ (u"࠭ࠠࠨ㠰")
	elif l1l11l_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㠱")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ㠲")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩ㠳")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ㠴")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭㠵")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧ㠶")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"࠭ࡹࡰࡷࡷࡹࠬ㠷")	 	in server: l111llll_l1_	= l1l11l_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ㠸")
	elif l1l11l_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ㠹")	 	in server: l111llll_l1_	= l1l11l_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ㠺")
	elif l1l11l_l1_ (u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨ㠻")	in server: l111llll_l1_	= l1l11l_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨ㠼")
	elif l1l11l_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭㠽")		in server: l111llll_l1_	= l1l11l_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ㠾")
	elif l1l11l_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ㠿")		in server: l111llll_l1_	= l1l11l_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ㡀")
	elif l1l11l_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ㡁")	in server: l111llll_l1_	= l1l11l_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ㡂")
	elif l1l11l_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ㡃")	in server: l111llll_l1_	= l1l11l_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱࠬ㡄")
	elif l1l11l_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ㡅")		in server: l111llll_l1_	= l1l11l_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ㡆")
	elif l1l11l_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ㡇")	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ㡈")
	elif l1l11l_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ㡉")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ㡊")
	elif l1l11l_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ㡋")	 	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"࠭ࡣࡢࡶࡦ࡬ࠬ㡌")
	elif l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ㡍")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ㡎")
	elif l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ㡏")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ㡐")
	elif l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ㡑")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫ㡒")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"࠭࡭ࡺࡸ࡬࡭ࡩ࠭㡓")		in server: l1ll111l1l1l_l1_	= l1l1l111l111_l1_
	elif l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ㡔")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ㡕")
	elif l1l11l_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ㡖")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ㡗")
	elif l1l11l_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭㡘") 	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ㡙")
	elif l1l11l_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ㡚")	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ㡛")
	elif l1l11l_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭㡜")	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ㡝")
	elif l1l11l_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ㡞") 	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ㡟")
	elif l1l11l_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭㡠")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ㡡")
	elif l1l11l_l1_ (u"ࠧࡶࡲࡳࠫ㡢") 			in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ㡣")
	elif l1l11l_l1_ (u"ࠩࡸࡴࡧ࠭㡤") 			in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ㡥")
	elif l1l11l_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ㡦") 		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ㡧")
	elif l1l11l_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ㡨") 	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ㡩")
	elif l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ㡪")		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ㡫")
	elif l1l11l_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ㡬") 		in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ㡭")
	elif l1l11l_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ㡮") 	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ㡯")
	elif l1l11l_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ㡰")	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ㡱")
	elif l1l11l_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭㡲")	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ㡳")
	#elif l1l11l_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ㡴") 	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭㡵")
	#elif l1l11l_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ㡶")	in server: l1l1lll11l1l_l1_	= l1l11l_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ㡷")
	l1l11l_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡺࡸ࡬ࠬࠩࡀࡁࡂ࠭ࠫࡶࡴ࡯࠶࠮ࠐࠉࠊࡶࡵࡽ࠿ࠐࠉࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱࠐࠉࠊࠋࡵࡩࡸࡵ࡬ࡷࡧࡵࠤࡂࠦࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮࠱ࡌࡴࡹࡴࡦࡦࡐࡩࡩ࡯ࡡࡇ࡫࡯ࡩ࠭ࡻࡲ࡭࠴ࠬ࠲ࡻࡧ࡬ࡪࡦࡢࡹࡷࡲࠨࠪࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠋࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠵࠶࠷࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧࠪࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡉࡥࡱࡹࡥࠋࠋࠌࠍࠨࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦ࡯࠲ࡴࡸࡧࠋࠋࠌࠍࡱ࡯ࡳࡵࡡࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡹࡪ࡬࠮ࡱࡵ࡫࠳࡭ࡩࡵࡪࡸࡦ࠳࡯࡯࠰ࡻࡲࡹࡹࡻࡢࡦ࠯ࡧࡰ࠴ࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࡴ࡫ࡷࡩࡸ࠴ࡨࡵ࡯࡯ࠫࠏࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲࡬ࡪࡵࡷࡣࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈ࠱࠶ࡹࡴࠨࠫࠍࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡮࡬ࠠࡩࡶࡰࡰ࠿ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࡜࠲ࡠ࠲ࡱࡵࡷࡦࡴࠫ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿ࡰ࡮ࡄࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽ࡤࡁࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࠰࡮࡬ࡂࠬ࠲ࠧࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࠯ࡣࡀࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠷࠸࠲࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨࠫࠍࠍࠎࠏࠉࡱࡣࡵࡸࡸࠦ࠽ࠡࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠰ࠪ࠭ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡱࡣࡵࡸࡸࡀࠊࠊࠋࠌࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡶࡡࡳࡶࠬࡀ࠹ࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࠉࡦ࡮࡬ࡪࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࠊࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠎࠎࠨࠢࠣ㡸")
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㡹"),l1l11l_l1_ (u"ࠪࠫ㡺"),url,url2)
	if   l111llll_l1_:	l1l1llll1l1l_l1_,name = l1l11l_l1_ (u"ࠫำอีࠨ㡻"),l111llll_l1_
	elif l1ll111l1l1l_l1_:		l1l1llll1l1l_l1_,name = l1l11l_l1_ (u"ࠬࠫๅฮัาࠫ㡼"),l1ll111l1l1l_l1_
	elif l1l1lll11l1l_l1_:		l1l1llll1l1l_l1_,name = l1l11l_l1_ (u"࠭ࠥࠦ฻สู้๋ࠥา๊ไࠫ㡽"),l1l1lll11l1l_l1_
	elif l1111l1l_l1_:	l1l1llll1l1l_l1_,name = l1l11l_l1_ (u"ࠧࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭㡾"),l1111l1l_l1_
	elif l1lll1111l1l_l1_:	l1l1llll1l1l_l1_,name = l1l11l_l1_ (u"ࠨࠧࠨࠩࠪ฿วๆࠢัหึา๊ࠨ㡿"),l1l1l111l111_l1_
	else:			l1l1llll1l1l_l1_,name = l1l11l_l1_ (u"ࠩࠨฺࠩࠪࠫࠥษ่ࠤ๊า็้ๆࠪ㢀"),l1l1l111l111_l1_
	return l1l1llll1l1l_l1_,name,type,l11_l1_,l1l1l1l1_l1_
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡰ࡭ࡣࡼࡶ࠳࠺ࡨࡦ࡮ࡤࡰࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡵࡸࡩࡷࡣࡷࡩࠥࡃࠠࠨࡪࡨࡰࡦࡲࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡴࡩࡧࡹ࡭ࡩ࡫࡯ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹࡩࡻ࠴ࡩࡰࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡥࡷࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡢࡰ࡯ࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡤࡲࡱࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨ࡭ࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠋࠋࠥࠦࠧ㢁")
def l1lll111111l_l1_(url):
	url2,l1ll11l1l111_l1_,server,l1l1l111l111_l1_,name,type,l11_l1_,l1l1l1l1_l1_,source = l1l1lll11l11_l1_(url)
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㢂"),l1l11l_l1_ (u"ࠬ࠭㢃"),l1ll111l1l1l_l1_,server)
	#if l1l11l_l1_ (u"࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫ㢄")	in server: url2 = url2.replace(l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ㢅"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ㢆"))
	#if any(value in server for value in l1lll1l11l1l_l1_): l1l1lll_l1_,l1ll1lll_l1_ = [l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡉࡘࡕࡌࡗࡇࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࠦࡴࡩ࡫ࡶࠤࡸ࡫ࡲࡷࡧࡵࠫ㢇")],[]
	if   l1l11l_l1_ (u"ࠪࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭㢈")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1111ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࠪ㢉")		in source: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11l1_l1_(url2,name)
	elif l1l11l_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࠫ㢊")		in source: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11ll1_l1_(url2,type,l1l1l1l1_l1_)
	elif l1l11l_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭㢋")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll11lll111_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㢌")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l111lll1lll_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ㢍")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l111lll1lll_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩ㢎")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11l1ll1l_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮ࡥ࡯ࡹࡧ࠭㢏")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l111l111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ㢐")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11l11l1l1_l1_(url2)
	elif l1l11l_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ㢑")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1111l1ll_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡴࡷ࡭ࡶࡥࠬ㢒")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1111l1ll_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ㢓")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1llll1ll11_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ㢔")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l111l1ll1_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ㢕")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l111l1llll1_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ㢖")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1lll1ll1_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡻࡹ࠴ࡶࠩ㢗")			in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11l111ll11_l1_(url2)
	elif l1l11l_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ㢘")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1111lll11_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ㢙")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11111111_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡤ࡫ࡰࡥ࠲ࡲࡩࡨࡪࡷࠫ㢚")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1111111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ㢛")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1111111l_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ㢜")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11l1ll1l1l_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㢝")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l111lllll11_l1_(url2)
	elif l1l11l_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ㢞")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11ll1l11_l1_(url2)
	elif l1l11l_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㢟")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1lll11l1l_l1_(url2)
	elif l1l11l_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㢠")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1l11_l1_(url2)
	elif l1l11l_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ㢡")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1l11_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡵࡧࡦ࡬ࠬ㢢")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1l11_l1_(url2)
	elif l1l11l_l1_ (u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫ㢣")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l111_l1_(url2)
	elif l1l11l_l1_ (u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨ㢤")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠫࠬ㢥"),[l1l11l_l1_ (u"ࠬ࠭㢦")],[url2]
	elif l1l11l_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ㢧")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l111111l_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠭㢨")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1l1l1l_l1_(url2)
	elif l1l11l_l1_ (u"ࠨࡷࡳࡦࡦࡳࠧ㢩") 		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠩࠪ㢪"),[l1l11l_l1_ (u"ࠪࠫ㢫")],[url2]
	else: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㢬"),[l1l11l_l1_ (u"ࠬ࠭㢭")],[url2]
	return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
def l1l1ll1ll1ll_l1_(url):
	server = SERVER(url,l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㢮"))
	#if l1l11l_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ㢯")	in server: url2 = url2.replace(l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ㢰"),l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㢱"))
	#if any(value in server for value in l1lll1l11l1l_l1_): l1l1lll_l1_,l1ll1lll_l1_ = [l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡊ࡙ࡏࡍࡘࡈࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࠠࡵࡪ࡬ࡷࠥࡹࡥࡳࡸࡨࡶࠬ㢲")],[]
	l1ll1l1l111l_l1_ = False
	if   l1l11l_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ㢳")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1l11l11_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ㢴")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1l11l11_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㢵")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1l11_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㢶")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1lll11l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ㢷")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1ll111l11_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪ㢸")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l11111lll1_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭㢹")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1lll1l1_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ㢺")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1lll11ll_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭㢻")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll11lll11l_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡥ࠶ࡶࡶࡥࡷ࠭㢼")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11lllllll_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭㢽")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1111l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫ㢾")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1111l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ㢿")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ㣀")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ㣁")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡼࡩࡥࡪࡧࠫ㣂")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ㣃")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	elif l1l11l_l1_ (u"ࠧ࡭࡫࡬࡭ࡻ࡯ࡤࡦࡱࠪ㣄")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	elif l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡴࡨࡡࠨ㣅")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1ll1l1lll_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡹ࡭ࡩࡹࡰࡦࡧࡧࠫ㣆")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1ll1l1lll_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡹࡵࡨࡡ࡮ࠩ㣇") 		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠫࠬ㣈"),[l1l11l_l1_ (u"ࠬ࠭㣉")],[url]
	#elif l1l11l_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ㣊")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l11ll1ll_l1_(url)
	elif l1l11l_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ㣋") 	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1lll11l1_l1_(url)
	elif l1l11l_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ㣌")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll11l11lll_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࡨࡰࠩ㣍")in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1lll1ll11ll_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ㣎") 	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1l1ll11_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ㣏")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll11l1l1ll_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡻࡰࡣࠩ㣐") 			in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l11111ll_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡵࡱࡲࠪ㣑") 			in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l11111ll_l1_(url)
	#elif l1l11l_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ㣒") 	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1lll1lll_l1_(url)
	#elif l1l11l_l1_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ㣓")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1lll1lll_l1_(url)
	elif l1l11l_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ㣔") 		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1llllllll_l1_(url)
	elif l1l11l_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ㣕") 	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1lllll111_l1_(url)
	elif l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ㣖")		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll11l1l1l1_l1_(url)
	elif l1l11l_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ㣗") 		in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1llll1111_l1_(url)
	elif l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ㣘") 	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll11l11l1l_l1_(url)
	elif l1l11l_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ㣙")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11llllll1_l1_(url)
	elif l1l11l_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ㣚")	in server: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1ll1llll_l1_(url)
	else: l1ll1l1l111l_l1_ = True
	if l1ll1l1l111l_l1_ or l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠫ㣛") in l1ll1llll111_l1_:
		l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠢࡉࡥ࡮ࡲࡥࡥࠩ㣜"),[],[]
	return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	l1l11l_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡉࡘ࡚ࡒࡆࡃࡐࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡈࡑࡘࡒࡑࡏࡍࡊࡖࡈࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡋࡑࡘࡔ࡛ࡐࡍࡑࡄࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡔࡉࡇ࡙ࡍࡉࡋࡏࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡦࡸ࠱࡭ࡴ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡈ࡚ࡎࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡶ࡬ࡢࡻࡵ࠲࠹࡮ࡥ࡭ࡣ࡯ࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡍࡋࡌࡂࡎࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾࡙ࠢࡍࡉࡈࡏࡎࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠠࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡍࡊࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡘࡎࡁࡓࡇࠫࡹࡷࡲࠩࠋࠋࠥࠦࠧ㣝")
def	l1l1ll1l11l1_l1_(l1111111ll1_l1_):
	if l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࠪ㣞") in str(type(l1111111ll1_l1_)):
		l1ll1111_l1_ = []
		for l1111l_l1_ in l1111111ll1_l1_:
			if l1l11l_l1_ (u"࠭ࡳࡵࡴࠪ㣟") in str(type(l1111l_l1_)):
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠧ࡝ࡴࠪ㣠"),l1l11l_l1_ (u"ࠨࠩ㣡")).replace(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ㣢"),l1l11l_l1_ (u"ࠪࠫ㣣")).strip(l1l11l_l1_ (u"ࠫࠥ࠭㣤"))
			l1ll1111_l1_.append(l1111l_l1_)
	else: l1ll1111_l1_ = l1111111ll1_l1_.replace(l1l11l_l1_ (u"ࠬࡢࡲࠨ㣥"),l1l11l_l1_ (u"࠭ࠧ㣦")).replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㣧"),l1l11l_l1_ (u"ࠨࠩ㣨")).strip(l1l11l_l1_ (u"ࠩࠣࠫ㣩"))
	return l1ll1111_l1_
def l1ll1l1lll11_l1_(url):
	LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㣪"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ㣫")+url+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ㣬"))
	l1lll1111l1l_l1_,l1111l_l1_,l1l1ll1l11ll_l1_ = l1l11l_l1_ (u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ㣭"),l1l11l_l1_ (u"ࠧࠨ㣮"),l1l11l_l1_ (u"ࠨࠩ㣯")
	l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1lll111111l_l1_(url)
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㣰"),l1l11l_l1_ (u"ࠪࠫ㣱"),l1l11l_l1_ (u"ࠫࠬ㣲"),l1ll1llll111_l1_)
	l1ll1lll_l1_ = l1l1ll1l11l1_l1_(l1ll1lll_l1_)
	if l1ll1llll111_l1_==l1l11l_l1_ (u"ࠬࡋࡘࡊࡖࠪ㣳"): return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	elif l1ll1lll_l1_: l1111l_l1_ = l1ll1lll_l1_[0]
	if l1ll1llll111_l1_==l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㣴"):
		#l1ll1llll111_l1_ = l1ll1llll111_l1_.replace(l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㣵"),l1l11l_l1_ (u"ࠨࠩ㣶"))
		l1lll1111l1l_l1_ = l1l11l_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ㣷")
		l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1ll1ll1ll_l1_(l1111l_l1_)
		l1ll1lll_l1_ = l1l1ll1l11l1_l1_(l1ll1lll_l1_)
		if l1ll1llll111_l1_==l1l11l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ㣸"): return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
		elif l1l11l_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠳ࠪ㣹") in l1ll1llll111_l1_:
			l1l1ll1l11ll_l1_ += l1l11l_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥ࠭㣺")+l1ll1llll111_l1_
			l1lll1111l1l_l1_ = l1l11l_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ㣻")
			l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1ll1ll1l1_l1_(l1111l_l1_)
			l1ll1lll_l1_ = l1l1ll1l11l1_l1_(l1ll1lll_l1_)
			if l1ll1llll111_l1_==l1l11l_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ㣼"): return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
			elif l1l11l_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧ㣽") in l1ll1llll111_l1_:
				l1l1ll1l11ll_l1_ += l1l11l_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠪ㣾")+l1ll1llll111_l1_
				l1lll1111l1l_l1_ = l1l11l_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ㣿")
				l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1ll1ll11l_l1_(l1111l_l1_)
				l1ll1lll_l1_ = l1l1ll1l11l1_l1_(l1ll1lll_l1_)
				if l1ll1llll111_l1_==l1l11l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ㤀"): return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
				elif l1l11l_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠫ㤁") in l1ll1llll111_l1_:
					l1l1ll1l11ll_l1_ += l1l11l_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠷࠿ࠦࠧ㤂")+l1ll1llll111_l1_
					#LOG_THIS(l1l11l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㤃"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡆࡲ࡬ࠡࡇࡻࡸࡪࡸ࡮ࡢ࡮ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࡸࠦࡆࡢ࡫࡯ࡩࡩࠦࠠࠡࡏࡨࡷࡸࡧࡧࡦࡵ࠽ࠤࡠࠦࠧ㤄")+l1l1ll1l11ll_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭㤅")+url+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ㤆")+l1111l_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠧ㤇"))
	elif l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ㤈") in l1ll1llll111_l1_: l1l1ll1l11ll_l1_ = l1l11l_l1_ (u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠲࠽ࠤࠬ㤉")+l1ll1llll111_l1_
	l1l1ll1l11ll_l1_ = l1l1ll1l11ll_l1_.strip(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ㤊"))
	if l1ll1lll_l1_: LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㤋"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ㤌")+l1lll1111l1l_l1_+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ㤍")+l1111l_l1_+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡸࡻ࡬ࡵ࠼ࠣ࡟ࠥ࠭㤎")+str(l1ll1lll_l1_)+l1l11l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ㤏")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ㤐"))
	else: LOG_THIS(l1l11l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㤑"),LOGGING(script_name)+l1l11l_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ㤒")+l1111l_l1_+l1l11l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡧࡶࡷࡦ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭㤓")+l1l1ll1l11ll_l1_+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ㤔")+url+l1l11l_l1_ (u"ࠫࠥࡣࠧ㤕"))
	#l1l1ll1l11ll_l1_ = l1l1ll1l11ll_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ㤖"),l1l11l_l1_ (u"࠭ࠠ࠯࠰࠱ࠤࠬ㤗"))
	#if l1l11l_l1_ (u"ࠧࡦࡴࡵࡳࡷࡀࠠࠨ㤘") not in l1ll1llll111_l1_.lower(): return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	l1l1ll1l11ll_l1_ = UNQUOTE(l1l1ll1l11ll_l1_)
	return l1l1ll1l11ll_l1_,l1l1lll_l1_,l1ll1lll_l1_
def l1l11llll1l1_l1_(l1lllllllll1_l1_):
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭㤙"),l1lllllllll1_l1_)
	expiry = l1llll_l1_
	data = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㤚"),l1l11l_l1_ (u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ㤛"),l1lllllllll1_l1_)
	if data:
		l1l1lll_l1_,l1ll1lll_l1_ = list(zip(*data))
		return l1l1lll_l1_,l1ll1lll_l1_
	l1l1lll_l1_,l1ll1lll_l1_,l1ll1ll1ll1l_l1_ = [],[],[]
	for l1111l_l1_ in l1lllllllll1_l1_:
		if l1l11l_l1_ (u"ࠫ࠴࠵ࠧ㤜") not in l1111l_l1_: continue
		l1l1llll1l1l_l1_,name,type,l11_l1_,l1l1l1l1_l1_ = l1ll1l1llll1_l1_(l1111l_l1_)
		l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࡤࠬࠩ㤝"),l1l1l1l1_l1_,re.DOTALL)
		if l1l1l1l1_l1_: l1l1l1l1_l1_ = int(l1l1l1l1_l1_[0])
		else: l1l1l1l1_l1_ = 0
		#if l1l1l1l1_l1_:
		#	l1l1ll111111_l1_ = sorted(l1l1l1l1_l1_,reverse=True,key=lambda key: int(key))
		#	l1l1l1l1_l1_ = int(l1l1ll111111_l1_[0])
		#else: l1l1l1l1_l1_ = 0
		server = SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㤞"))
		l1ll1ll1ll1l_l1_.append([l1l1llll1l1l_l1_,name,type,l11_l1_,l1l1l1l1_l1_,l1111l_l1_,server])
	if l1ll1ll1ll1l_l1_:
		#l1l1llll1l1l_l1_,name,type,l11_l1_,l1l1l1l1_l1_,l1111l_l1_ = zip(*l1ll1ll1ll1l_l1_)
		#name = reversed(name)
		#l1ll1ll1ll1l_l1_ = zip(l1l1llll1l1l_l1_,name,type,l11_l1_,l1l1l1l1_l1_,l1111l_l1_)
		l1l1111lll1_l1_ = sorted(l1ll1ll1ll1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l1l1lll111ll_l1_ = []
		for line in l1l1111lll1_l1_:
			if line not in l1l1lll111ll_l1_:
				l1l1lll111ll_l1_.append(line)
				#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ㤟"),str(line))
		for l1l1llll1l1l_l1_,name,type,l11_l1_,l1l1l1l1_l1_,l1111l_l1_,server in l1l1lll111ll_l1_:
			if l1l1l1l1_l1_: l1l1l1l1_l1_ = str(l1l1l1l1_l1_)
			else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࠩ㤠")
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㤡"),l1l11l_l1_ (u"ࠪࠫ㤢"),name,l1111l_l1_)
			title = l1l11l_l1_ (u"ุࠫ๐ัโำࠪ㤣")+l1l11l_l1_ (u"ࠬࠦࠧ㤤")+type+l1l11l_l1_ (u"࠭ࠠࠨ㤥")+l1l1llll1l1l_l1_+l1l11l_l1_ (u"ࠧࠡࠩ㤦")+l1l1l1l1_l1_+l1l11l_l1_ (u"ࠨࠢࠪ㤧")+l11_l1_+l1l11l_l1_ (u"ࠩࠣࠫ㤨")+name
			if server not in title: title = title+l1l11l_l1_ (u"ࠪࠤࠬ㤩")+server
			title = title.replace(l1l11l_l1_ (u"ࠫࠪ࠭㤪"),l1l11l_l1_ (u"ࠬ࠭㤫")).strip(l1l11l_l1_ (u"࠭ࠠࠨ㤬")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ㤭"),l1l11l_l1_ (u"ࠨࠢࠪ㤮")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬ㤯"),l1l11l_l1_ (u"ࠪࠤࠬ㤰")).replace(l1l11l_l1_ (u"ࠫࠥࠦࠧ㤱"),l1l11l_l1_ (u"ࠬࠦࠧ㤲"))
			if l1111l_l1_ not in l1ll1lll_l1_:
				l1l1lll_l1_.append(title)
				l1ll1lll_l1_.append(l1111l_l1_)
		if l1ll1lll_l1_:
			#selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ㤳"),l1ll1lll_l1_)
			data = list(zip(l1l1lll_l1_,l1ll1lll_l1_))
			if data: WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ㤴"),l1lllllllll1_l1_,data,expiry)
	#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ㤵"),l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠺࠳࠼ࠣࠤࠥ࠭㤶")+str(data))
	return l1l1lll_l1_,l1ll1lll_l1_
l1l11l_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡗࡊࡘࡖࡆࡔࡖࡣࡈࡇࡃࡉࡇࡇࡣࡔࡒࡄࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠾ࠩࠪ࠭࠿ࠐࠉࠤࡶ࠴ࠤࡂࠦࡴࡪ࡯ࡨ࠲ࡹ࡯࡭ࡦࠪࠬࠎࠎࡩࡡࡤࡪࡨࡴࡪࡸࡩࡰࡦࠣࡁࠥࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆࠌࠌࡧࡴࡴ࡮ࠡ࠿ࠣࡷࡶࡲࡩࡵࡧ࠶࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࡩࡡࡤࡪࡨࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࡣࠡ࠿ࠣࡧࡴࡴ࡮࠯ࡥࡸࡶࡸࡵࡲࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡷࡩࡽࡺ࡟ࡧࡣࡦࡸࡴࡸࡹࠡ࠿ࠣࡷࡹࡸࠊࠊࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨ࡙ࠬࠬࡅࡍࡇࡆࡘࠥࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖ࠯ࡹࡷࡲࡌࡊࡕࡗࠤࡋࡘࡏࡎࠢࡶࡩࡷࡼࡥࡳࡵࡦࡥࡨ࡮ࡥ࡙ࠡࡋࡉࡗࡋࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠿ࠥࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠭࠰࠭ࠢࠨࠫࠍࠍࡷࡵࡷࡴࠢࡀࠤࡨ࠴ࡦࡦࡶࡦ࡬ࡦࡲ࡬ࠩࠫࠍࠍ࡮࡬ࠠࡳࡱࡺࡷ࠿ࠐࠉࠊࠥࡰࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭ࡦࡰࡷࡱࡨࠥ࡯࡮ࠡࡥࡤࡧ࡭࡫ࠧࠋࠋࠌࡷࡪࡸࡶࡦࡴࡶࡐࡎ࡙ࡔ࠭ࡷࡵࡰࡑࡏࡓࡕࠢࡀࠤࡊ࡜ࡁࡍࠪࠪࡷࡹࡸࠧ࠭ࡴࡲࡻࡸࡡ࠰࡞࡝࠳ࡡ࠮࠲ࡅࡗࡃࡏࠬࠬࡹࡴࡳࠩ࠯ࡶࡴࡽࡳ࡜࠲ࡠ࡟࠶ࡣࠩࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࡲ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡤࡣࡦ࡬ࡪ࠭ࠊࠊࠋࡶࡩࡷࡼࡥࡳࡵࡏࡍࡘ࡚ࠬࡶࡴ࡯ࡐࡎ࡙ࡔࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࡖࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠊࠊࠋࡷࠤࡂࠦࠨ࡯ࡱࡺ࠯ࡨࡧࡣࡩࡧࡳࡩࡷ࡯࡯ࡥ࠮ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪ࠮ࡶࡸࡷ࠮ࡳࡦࡴࡹࡩࡷࡹࡌࡊࡕࡗ࠭࠱ࡹࡴࡳࠪࡸࡶࡱࡒࡉࡔࡖࠬ࠭ࠏࠏࠉࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠦࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡶࡩࡷࡼࡥࡳࡵࡦࡥࡨ࡮ࡥࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿࠭ࡁࠬࠦ࠱ࡺࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠨࡺ࠲ࠡ࠿ࠣࡸ࡮ࡳࡥ࠯ࡶ࡬ࡱࡪ࠮ࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡒࡔ࡚ࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠪࡰࡩࡸࡹࡡࡨࡧ࠯ࡷࡹࡸࠨࡪࡰࡷࠬࡹ࠸࠭ࡵ࠳ࠬ࠭࠰࠭ࠠ࡮ࡵࠪ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠦࡳࡦࡴࡹࡩࡷࡹࡌࡊࡕࡗ࠰ࡺࡸ࡬ࡍࡋࡖࡘࠏࠐࡤࡦࡨࠣࡗࡊࡘࡖࡆࡔࡖࡣࡔࡒࡄࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠾ࠩࠪ࠭࠿ࠐࠉࡴࡧࡵࡺࡪࡸࡳࡍࡋࡖࡘ࠱ࡻࡲ࡭ࡎࡌࡗ࡙࠲ࡵ࡯࡭ࡱࡳࡼࡴࡌࡊࡕࡗ࠰ࡸ࡫ࡲࡷࡧࡵࡷࡉࡏࡃࡕࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢ࠲࡛࡞ࠌࠌࠧࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡮࡬ࡷࡹ࠮ࡳࡦࡶࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮࠯ࠊࠊࠥࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ࠮ࠣࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࠐࠉࠤ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࠣ࠱࠶ࠦ࠺ࠡࡴࡨࡸࡺࡸ࡮ࠡࠩࠪࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠠࡪࡰࠣࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠿ࠐࠉࠊ࡫ࡩࠤࡱ࡯࡮࡬࠿ࡀࠫࠬࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࡸ࡫ࡲࡷࡧࡵࡒࡆࡓࡅࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡄࡆࡑࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࡴࡆࡌࡇ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠠ࡜ࡵࡨࡶࡻ࡫ࡲࡏࡃࡐࡉ࠱ࡲࡩ࡯࡭ࡠࠤ࠮ࠐࠉࡴࡱࡵࡸࡪࡪࡄࡊࡅࡗࠤࡂࠦࡳࡰࡴࡷࡩࡩ࠮ࡳࡦࡴࡹࡩࡷࡹࡄࡊࡅࡗ࠰ࠥࡸࡥࡷࡧࡵࡷࡪࡃࡔࡳࡷࡨ࠰ࠥࡱࡥࡺ࠿࡯ࡥࡲࡨࡤࡢࠢ࡮ࡩࡾࡀࠠ࡬ࡧࡼ࡟࠵ࡣࠩࠋࠋࡩࡳࡷࠦࡳࡦࡴࡹࡩࡷ࠲࡬ࡪࡰ࡮ࠤ࡮ࡴࠠࡴࡱࡵࡸࡪࡪࡄࡊࡅࡗ࠾ࠏࠏࠉࡴࡧࡵࡺࡪࡸࠠ࠾ࠢࡶࡩࡷࡼࡥࡳ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠪ࠭ࠬࠨࠩࠬࠎࠎࠏࡳࡦࡴࡹࡩࡷࡹࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡸ࡫ࡲࡷࡧࡵ࠭ࠏࠏࠉࡶࡴ࡯ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥ࡯࡭ࡳ࡫ࡳࠡ࠿ࠣࡰࡪࡴࠨࡶࡰ࡮ࡲࡴࡽ࡮ࡍࡋࡖࡘ࠮ࠐࠉࠤ࡫ࡩࠤࡱ࡯࡮ࡦࡵࡁ࠴࠿ࠐࠉࠤࠋࡰࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭࡜࡝ࡰࠪࠎࠎࠩࠉࡧࡱࡵࠤࡱ࡯࡮࡬ࠢ࡬ࡲࠥࡻ࡮࡬ࡰࡲࡻࡳࡒࡉࡔࡖ࠽ࠎࠎࠩࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࠢ࠮ࡁࠥࡲࡩ࡯࡭ࠣ࠯ࠥ࠭࡜࡝ࡰࠪࠎࠎࠩࠉࡴࡷࡥ࡮ࡪࡩࡴࠡ࠿࡚ࠣࠫࡴ࡫࡯ࡱࡺࡲࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࡳࠡ࠿ࠣࠫࠥ࠱ࠠࡴࡶࡵࠬࡱ࡯࡮ࡦࡵࠬࠎࠎࠩࠉࡳࡧࡶࡹࡱࡺࠠ࠾ࠢࡖࡉࡓࡊ࡟ࡆࡏࡄࡍࡑ࠮ࡳࡶࡤ࡭ࡩࡨࡺࠬ࡮ࡧࡶࡷࡦ࡭ࡥ࠭ࡈࡤࡰࡸ࡫ࠬࠨࠩ࠯ࠫࡋࡘࡏࡎ࠯ࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭ࠫࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠠࡴࡧࡵࡺࡪࡸࡳࡍࡋࡖࡘ࠱ࡻࡲ࡭ࡎࡌࡗ࡙ࠐࠢࠣࠤ㤷")
def	l1l1ll1ll1l1_l1_(url):
	#url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡃࡣ࡚ࡣ࡯࡫࡮ࡰࡼࡎࡧࠬ㤸")
	errortrace = l1l11l_l1_ (u"ࠬ࠭㤹")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l1ll111ll11l_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: errortrace = str(error)
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㤺"),l1l11l_l1_ (u"ࠧࠨ㤻"),l1l11l_l1_ (u"ࠨࠩ㤼"),str(results))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㤽"),l1l11l_l1_ (u"ࠪࠫ㤾"),l1l11l_l1_ (u"ࠫࠬ㤿"),str(errortrace))
	# resolveurl l1l111lll1_l1_ fail l1l1l11lll1l_l1_ with l1l1l1ll1lll_l1_ error or l1l1llll1lll_l1_ value False
	if not results:
		if errortrace==l1l11l_l1_ (u"ࠬ࠭㥀"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㥁"),l1l11l_l1_ (u"ࠧࠨ㥂"),l1l11l_l1_ (u"ࠨࠩ㥃"),str(errortrace))
		l1ll1llll111_l1_ = l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㥄")
		l1ll1llll111_l1_ += l1l11l_l1_ (u"ࠪࠤࠬ㥅")+errortrace.splitlines()[-1]
		return l1ll1llll111_l1_,[],[]
	return l1l11l_l1_ (u"ࠫࠬ㥆"),[l1l11l_l1_ (u"ࠬ࠭㥇")],[results]
def	l1l1ll1ll11l_l1_(url):
	#url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡅࡥ࡜ࡥࡪࡦࡰࡲࡾࡐࡩࠧ㥈")
	#url = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳ࠯ࡷ࡫ࡧࡩࡴ࠵ࡸ࠸ࡻࡼ࠸࠶ࡹࠧ㥉")
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㥊"),l1l11l_l1_ (u"ࠩࠪ㥋"),url,l1l11l_l1_ (u"ࠪࠫ㥌"))
	#return l1l11l_l1_ (u"ࠫࠬ㥍"),[],[]
	errortrace = l1l11l_l1_ (u"ࠬ࠭㥎")
	results = False
	try:
		import youtube_dl
		l1ll11llll11_l1_ = youtube_dl.YoutubeDL({l1l11l_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ㥏"): True})
		results = l1ll11llll11_l1_.extract_info(url,download=False)
	except Exception as error: errortrace = str(error)
	# youtube_dl l1l111lll1_l1_ fail l1l1l11lll1l_l1_ with l1l1l1ll1lll_l1_ error or l1l1llll1lll_l1_ value False
	if not results or l1l11l_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ㥐") not in list(results.keys()):
		if errortrace==l1l11l_l1_ (u"ࠨࠩ㥑"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㥒"),l1l11l_l1_ (u"ࠪࠫ㥓"),l1l11l_l1_ (u"ࠫࠬ㥔"),errortrace)
		l1ll1llll111_l1_ = l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠤࡋࡧࡩ࡭ࡧࡧࠫ㥕")
		l1ll1llll111_l1_ += l1l11l_l1_ (u"࠭ࠠࠨ㥖")+errortrace.splitlines()[-1]
		return l1ll1llll111_l1_,[],[]
	else:
		l1l1lll_l1_,l1ll1lll_l1_ = [],[]
		for l1111l_l1_ in results[l1l11l_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ㥗")]:
			l1l1lll_l1_.append(l1111l_l1_[l1l11l_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࠨ㥘")])
			l1ll1lll_l1_.append(l1111l_l1_[l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㥙")])
		return l1l11l_l1_ (u"ࠪࠫ㥚"),l1l1lll_l1_,l1ll1lll_l1_
def l1ll11lll111_l1_(url):
	if l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㥛") in url:
		l1l1lll_l1_,l1ll1lll_l1_ = l1ll1ll11l_l1_(url)
		if l1ll1lll_l1_: return l1l11l_l1_ (u"ࠬ࠭㥜"),l1l1lll_l1_,l1ll1lll_l1_
		return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡅࡗࡇࡂࠨ㥝"),[],[]
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㥞"),[l1l11l_l1_ (u"ࠨࠩ㥟")],[url]
#=================================================================================
# l1l1l1111l_l1_ of the l11llll11l_l1_ l1111l1ll1_l1_ l1111l11l1_l1_ added from:
# https://l11lll1ll1_l1_.com/l11ll1l1ll_l1_/l11lllllll_l1_-l11lll1l11_l1_/l1l111l1ll_l1_/l1l11l1l11_l1_/plugin.video.l1l11lllll_l1_/l1l111ll11_l1_/l1111ll1ll_l1_/l11l1l111l_l1_.py
#=================================================================================
def l1ll1lll1l1l_l1_(l1l11l1lll_l1_):
	data,page,l1111ll11l_l1_ = l1l11l1lll_l1_,l1l11l_l1_ (u"ࠩࠪ㥠"),l1l11l_l1_ (u"ࠪࠫ㥡")
	l1111l1lll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁࡹࡣࡳ࡫ࡳࡸ࠳࠰࠿࠼࠰࠭ࡃࡡ࠭ࠨ࠯ࠬࡂ࠭ࡀ࠭㥢"), data, re.S)
	l1111l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠵ࡧ࠯࠰࠱࠲࠳࠮࠮ࠫࡁࠬࡠ࠮࠭㥣"), data, re.S)
	if l1111l1lll_l1_ and l1111l1111_l1_:
		l1l11l1lll_l1_ = l1111l1lll_l1_[0].replace(l1l11l_l1_ (u"ࠨࠧࠣ㥤"),l1l11l_l1_ (u"ࠧࠨ㥥"))
		l1l11l1lll_l1_ = l1l11l1lll_l1_.replace(l1l11l_l1_ (u"ࠣ࠭ࠥ㥦"),l1l11l_l1_ (u"ࠩࠪ㥧"))
		l1l11l1lll_l1_ = l1l11l1lll_l1_.replace(l1l11l_l1_ (u"ࠥࡠࡳࠨ㥨"),l1l11l_l1_ (u"ࠫࠬ㥩"))
		l1111l111l_l1_ = l1l11l1lll_l1_.split(l1l11l_l1_ (u"ࠬ࠴ࠧ㥪"))
		page = l1l11l_l1_ (u"࠭ࠧ㥫")
		for l1l1111l1l_l1_ in l1111l111l_l1_:
				try:
					l1111l11ll_l1_ = base64.b64decode(l1l1111l1l_l1_+l1l11l_l1_ (u"ࠧ࠾࠿ࠪ㥬"))
					l1111l1l11_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡞ࡧ࠯ࠬ㥭"), l1111l11ll_l1_, re.S)
					if l1111l1l11_l1_:
						l1111l1l1l_l1_ = int(l1111l1l11_l1_[0])+int(l1111l1111_l1_[0])
						page = page + chr(l1111l1l1l_l1_)
				except: return l1l11l_l1_ (u"ࠩࠪ㥮"),l1l11l_l1_ (u"ࠪࠫ㥯")
		l1111ll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㥰"), page, re.S)
	return page,l1111ll11l_l1_
def l11111lll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㥱"),url,l1l11l_l1_ (u"࠭ࠧ㥲"),l1l11l_l1_ (u"ࠧࠨ㥳"),l1l11l_l1_ (u"ࠨࠩ㥴"),l1l11l_l1_ (u"ࠩࠪ㥵"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠭࠲ࡵࡷࠫ㥶"))
	html = response.content
	page,url = l1ll1lll1l1l_l1_(html)
	if not url: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡕࡈࡐࡍࡊࠧ㥷"),[],[]
	return l1l11l_l1_ (u"ࠬ࠭㥸"),[l1l11l_l1_ (u"࠭ࠧ㥹")],[url]
def l11l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㥺"),url,l1l11l_l1_ (u"ࠨࠩ㥻"),l1l11l_l1_ (u"ࠩࠪ㥼"),l1l11l_l1_ (u"ࠪࠫ㥽"),l1l11l_l1_ (u"ࠫࠬ㥾"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆ࠺ࡕ࠮࠳ࡶࡸࠬ㥿"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㦀"),html,re.DOTALL)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇ࠴ࡖࠩ㦁"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㦂"),[l1l11l_l1_ (u"ࠩࠪ㦃")],[l1111l_l1_]
def l11l11l1l1_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l11l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭㦄"):l1l11l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ㦅"),l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㦆"):l1l11l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭㦇")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㦈"),url2,data2,headers2,l1l11l_l1_ (u"ࠨࠩ㦉"),l1l11l_l1_ (u"ࠩࠪ㦊"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪ㦋"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㦌"),html,re.DOTALL)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ㦍"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㦎"),[l1l11l_l1_ (u"ࠧࠨ㦏")],[l1111l_l1_]
def l111l1llll1_l1_(url):
	headers = {l1l11l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ㦐"):l1l11l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ㦑")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㦒"),url,l1l11l_l1_ (u"ࠫࠬ㦓"),headers,l1l11l_l1_ (u"ࠬ࠭㦔"),l1l11l_l1_ (u"࠭ࠧ㦕"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡏࡇࡒࡕࡓ࠲࠷ࡳࡵࠩ㦖"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㦗"),html,re.DOTALL|re.IGNORECASE)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡏࡐࡈࡓࡖࡔ࠭㦘"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㦙"),[l1l11l_l1_ (u"ࠫࠬ㦚")],[l1111l_l1_]
def l1llll1ll11_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㦛"):l1l11l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭㦜")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㦝"),url2,data2,headers2,l1l11l_l1_ (u"ࠨࠩ㦞"),l1l11l_l1_ (u"ࠩࠪ㦟"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ㦠"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ㦡"),html,re.DOTALL|re.IGNORECASE)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩ㦢"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫ㦣") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㦤")+l1111l_l1_
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㦥"),l1l11l_l1_ (u"ࠩࠪ㦦"),l1l11l_l1_ (u"ࠪࠫ㦧"),l1111l_l1_)
	return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㦨"),[l1l11l_l1_ (u"ࠬ࠭㦩")],[l1111l_l1_]
def l111l1ll1_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㦪"):l1l11l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ㦫")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭㦬"),url2,data2,headers2,l1l11l_l1_ (u"ࠩࠪ㦭"),l1l11l_l1_ (u"ࠪࠫ㦮"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡆࡈࡄࡐ࠯࠴ࡷࡹ࠭㦯"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ㦰"),html,re.DOTALL|re.IGNORECASE)
	if not l1111l_l1_: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡇࡂࡅࡑࠪ㦱"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㦲"),[l1l11l_l1_ (u"ࠨࠩ㦳")],[l1111l_l1_]
def l1l1111l1ll_l1_(url):
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ㦴"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㦵"),url,l1l11l_l1_ (u"ࠫࠬ㦶"),l1l11l_l1_ (u"ࠬ࠭㦷"),l1l11l_l1_ (u"࠭ࠧ㦸"),l1l11l_l1_ (u"ࠧࠨ㦹"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡙࡜ࡆࡖࡐ࠰࠵ࡸࡺࠧ㦺"))
	html = response.content
	l1l1lll1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠤࡹࡥࡷࠦࡦࡴࡧࡵࡺࠥࡃ࠮ࠫࡁࠪࠬ࠳࠰࠿ࠪࠩࠥ㦻"),html,re.DOTALL|re.IGNORECASE)
	if l1l1lll1l111_l1_:
		l1l1lll1l111_l1_ = l1l1lll1l111_l1_[0][2:]
		#l1l1lll1l111_l1_ = l1l1lll1l111_l1_.decode(l1l11l_l1_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ㦼"))
		l1l1lll1l111_l1_ = base64.b64decode(l1l1lll1l111_l1_)
		if kodi_version>18.99: l1l1lll1l111_l1_ = l1l1lll1l111_l1_.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㦽"))
		l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㦾"),l1l1lll1l111_l1_,re.DOTALL)
	else: l1111l_l1_ = l1l11l_l1_ (u"࠭ࠧ㦿")
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡗ࡚ࡋ࡛ࡎࠨ㧀"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭㧁") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㧂")+l1111l_l1_
	return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㧃"),[l1l11l_l1_ (u"ࠫࠬ㧄")],[l1111l_l1_]
def l1ll1lll1ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㧅"),url,l1l11l_l1_ (u"࠭ࠧ㧆"),l1l11l_l1_ (u"ࠧࠨ㧇"),l1l11l_l1_ (u"ࠨࠩ㧈"),l1l11l_l1_ (u"ࠩࠪ㧉"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡇࡊ࡝࡛ࡏࡐ࠮࠳ࡶࡸࠬ㧊"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡵࡰ࠱࠶࠸ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㧋"),html,re.DOTALL)
	if not l1111l_l1_: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡈࡋ࡞࡜ࡉࡑࠩ㧌"),[],[]
	l1111l_l1_ = l1111l_l1_[0]
	return l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㧍"),[l1l11l_l1_ (u"ࠧࠨ㧎")],[l1111l_l1_]
def l1lll11l1l_l1_(url):
	id = url.split(l1l11l_l1_ (u"ࠨ࠱ࠪ㧏"))[-1]
	if l1l11l_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥࠩ㧐") in url: url = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ㧑"),l1l11l_l1_ (u"ࠫࠬ㧒"))
	url = url.replace(l1l11l_l1_ (u"ࠬ࠴ࡣࡰ࡯࠲ࠫ㧓"),l1l11l_l1_ (u"࠭࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡲ࡫ࡴࡢࡦࡤࡸࡦ࠵ࠧ㧔"))
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㧕"),url,l1l11l_l1_ (u"ࠨࠩ㧖"),l1l11l_l1_ (u"ࠩࠪ㧗"),l1l11l_l1_ (u"ࠪࠫ㧘"),l1l11l_l1_ (u"ࠫࠬ㧙"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ㧚"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l1l11l_l1_ (u"࠭ࠧ㧛"),url)
	l1ll1llll111_l1_ = l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㧜")
	error = re.findall(l1l11l_l1_ (u"ࠨࠤࡨࡶࡷࡵࡲࠣ࠰࠭ࡃࠧࡳࡥࡴࡵࡤ࡫ࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㧝"),html,re.DOTALL)
	if error: l1ll1llll111_l1_ = error[0]
	url = re.findall(l1l11l_l1_ (u"ࠩࡻ࠱ࡲࡶࡥࡨࡗࡕࡐࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㧞"),html,re.DOTALL)
	if not url and l1ll1llll111_l1_:
		#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㧟"),l1l11l_l1_ (u"ࠫࠬ㧠"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠧ㧡"),l1ll1llll111_l1_)
		return l1ll1llll111_l1_,[],[]
	l1111l_l1_ = url[0].replace(l1l11l_l1_ (u"࠭࡜࡝ࠩ㧢"),l1l11l_l1_ (u"ࠧࠨ㧣"))
	l1llllll1ll1_l1_,l1lllllllll1_l1_ = l1ll1ll11l_l1_(l1111l_l1_)
	owner = re.findall(l1l11l_l1_ (u"ࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼ࡾࠦ࡮ࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡷࡨࡸࡥࡦࡰࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㧤"),html,re.DOTALL)
	if owner: l1l1lll1l1ll_l1_,l1ll11lll1ll_l1_,l1lll11ll111_l1_ = owner[0]
	else: l1l1lll1l1ll_l1_,l1ll11lll1ll_l1_,l1lll11ll111_l1_ = l1l11l_l1_ (u"ࠩࠪ㧥"),l1l11l_l1_ (u"ࠪࠫ㧦"),l1l11l_l1_ (u"ࠫࠬ㧧")
	l1lll11ll111_l1_ = l1lll11ll111_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࠯ࠨ㧨"),l1l11l_l1_ (u"࠭࠯ࠨ㧩"))
	l1ll11lll1ll_l1_ = escapeUNICODE(l1ll11lll1ll_l1_)
	l1l1lll_l1_ = [l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ㧪")+l1ll11lll1ll_l1_+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㧫")]+l1llllll1ll1_l1_
	l1ll1lll_l1_ = [l1lll11ll111_l1_]+l1lllllllll1_l1_
	selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪ㧬")+str(len(l1ll1lll_l1_)-1)+l1l11l_l1_ (u"ࠪࠤ๊๊แࠪࠩ㧭"),l1l1lll_l1_)
	if selection==-1: return l1l11l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ㧮"),[],[]
	elif selection==0:
		new_path = sys.argv[0]+l1l11l_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠷࠴࠷ࠬࡵࡳ࡮ࡀࠫ㧯")+l1lll11ll111_l1_+l1l11l_l1_ (u"࠭ࠦࡵࡧࡻࡸࡂ࠭㧰")+l1ll11lll1ll_l1_
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ㧱")+new_path+l1l11l_l1_ (u"ࠣࠫࠥ㧲"))
		return l1l11l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ㧳"),[],[]
	l1111l_l1_ =  l1ll1lll_l1_[selection]
	return l1l11l_l1_ (u"ࠪࠫ㧴"),[l1l11l_l1_ (u"ࠫࠬ㧵")],[l1111l_l1_]
def l11ll1l11_l1_(l1111l_l1_):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㧶"),l1111l_l1_,l1l11l_l1_ (u"࠭ࠧ㧷"),l1l11l_l1_ (u"ࠧࠨ㧸"),l1l11l_l1_ (u"ࠨࠩ㧹"),l1l11l_l1_ (u"ࠩࠪ㧺"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩ㧻"))
	html = response.content
	if l1l11l_l1_ (u"ࠫ࠳ࡰࡳࡰࡰࠪ㧼") in l1111l_l1_: url = re.findall(l1l11l_l1_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㧽"),html,re.DOTALL)
	else: url = re.findall(l1l11l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㧾"),html,re.DOTALL)
	if not url: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅࡓࡐࡘࡁࠨ㧿"),[],[]
	url = url[0]
	if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭㨀") not in url: url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㨁")+url
	return l1l11l_l1_ (u"ࠪࠫ㨂"),[l1l11l_l1_ (u"ࠫࠬ㨃")],[url]
def l1l1ll111l11_l1_(url):
	# http://l1lll11l1111_l1_.l1l1l1l111l1_l1_/l1ll1l1ll1ll_l1_.html?l1ll111l1l1l_l1_=l1l1l1ll1ll1_l1_
	# http://l1lll11l1111_l1_.l1l1l1l111l1_l1_/l1l1ll1111l1_l1_?op=l1ll11lll1l1_l1_&id=l1ll1l1ll1ll_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㨄") : l1l11l_l1_ (u"࠭ࠧ㨅") }
	if l1l11l_l1_ (u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ㨆") in url:
		html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠨࠩ㨇"),headers,l1l11l_l1_ (u"ࠩࠪ㨈"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬ㨉"))
		#xbmc.log(html)
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㨊"),l1l11l_l1_ (u"ࠬ࠭㨋"),url,html)
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㨌"),html,re.DOTALL)
		if items: return l1l11l_l1_ (u"ࠧࠨ㨍"),[l1l11l_l1_ (u"ࠨࠩ㨎")],[items[0]]
		else:
			message = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡶࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㨏"),html,re.DOTALL)
			if message:
				DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㨐"),l1l11l_l1_ (u"ࠫࠬ㨑"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧ㨒"),message[0])
				return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧ㨓")+message[0],[],[]
	else:
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㨔"),l1l11l_l1_ (u"ࠨࠩ㨕"),l1111l_l1_,l1l11l_l1_ (u"ࠩࠪ㨖"))
		#url,name2 = url.split(l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㨗"))
		#name2 = name2.lower()
		name2 = l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧ㨘")
		# l1l1ll11l_l1_ l1ll1111_l1_
		html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠬ࠭㨙"),headers,l1l11l_l1_ (u"࠭ࠧ㨚"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࠩ㨛"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ㨜"),html,re.DOTALL)
		if not l1ll111_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭㨝"),[],[]
		l11l111l1_l1_ = l1ll111_l1_[0][0]
		block = l1ll111_l1_[0][1]
		if l1l11l_l1_ (u"ࠪ࠲ࡷࡧࡲࠨ㨞") in block or l1l11l_l1_ (u"ࠫ࠳ࢀࡩࡱࠩ㨟") in block: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ㨠"),[],[]
		items = re.findall(l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㨡"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1111l11_l1_(payload)
		html = OPENURL_CACHED(l111l11l_l1_,l11l111l1_l1_,data,headers,l1l11l_l1_ (u"ࠧࠨ㨢"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪ㨣"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧ㨤"),html,re.DOTALL)
		if not l1ll111_l1_: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ㨥"),[],[]
		download = l1ll111_l1_[0][0]
		block = l1ll111_l1_[0][1]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫ㨦"),block,re.DOTALL)
		l1ll1lll111l_l1_,l1l1lll_l1_,l1l1lll1llll_l1_,l1ll1lll_l1_,l1l1lll11lll_l1_ = [],[],[],[],[]
		for l1111l_l1_,title in items:
			if l1l11l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㨧") in l1111l_l1_:
				l1ll1lll111l_l1_,l1l1lll1llll_l1_ = l1ll1ll11l_l1_(l1111l_l1_)
				l1ll1lll_l1_ = l1ll1lll_l1_ + l1l1lll1llll_l1_
				if l1ll1lll111l_l1_[0]==l1l11l_l1_ (u"࠭࠭࠲ࠩ㨨"): l1l1lll_l1_.append(l1l11l_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ㨩")+l1l11l_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ㨪")+name2)
				else:
					for title in l1ll1lll111l_l1_:
						l1l1lll_l1_.append(l1l11l_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ㨫")+l1l11l_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ㨬")+name2+l1l11l_l1_ (u"ࠫࠥ࠭㨭")+title)
			else:
				title = title.replace(l1l11l_l1_ (u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧ㨮"),l1l11l_l1_ (u"࠭ࠧ㨯"))
				title = title.strip(l1l11l_l1_ (u"ࠧࠣࠩ㨰"))
				#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㨱"),l1l11l_l1_ (u"ࠩࠪ㨲"),title,str(l1l1lll11lll_l1_))
				title = l1l11l_l1_ (u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩ㨳")+l1l11l_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ㨴")+name2+l1l11l_l1_ (u"ࠬࠦࠧ㨵")+title
				l1l1lll_l1_.append(title)
				l1ll1lll_l1_.append(l1111l_l1_)
		# download l1ll1111_l1_
		l1111l_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠨ㨶") + download
		html = OPENURL_CACHED(l111l11l_l1_,l1111l_l1_,l1l11l_l1_ (u"ࠧࠨ㨷"),headers,l1l11l_l1_ (u"ࠨࠩ㨸"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫ㨹"))
		items = re.findall(l1l11l_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢ㨺"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l11l_l1_ (u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨ㨻")+l1l11l_l1_ (u"ࠬࠦ࡭ࡱ࠶ࠣࠫ㨼")+name2+l1l11l_l1_ (u"࠭ࠠࠨ㨽")+resolution.split(l1l11l_l1_ (u"ࠧࡹࠩ㨾"))[1]
			l1111l_l1_ = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭㨿")+id+l1l11l_l1_ (u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ㩀")+mode+l1l11l_l1_ (u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ㩁")+hash
			l1l1lll11lll_l1_.append(resolution)
			l1l1lll_l1_.append(title)
			l1ll1lll_l1_.append(l1111l_l1_)
		l1l1lll11lll_l1_ = set(l1l1lll11lll_l1_)
		l1ll111ll1l1_l1_,l1lll1l11111_l1_ = [],[]
		for title in l1l1lll_l1_:
			#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㩂"),l1l11l_l1_ (u"ࠬ࠭㩃"),title,l1l11l_l1_ (u"࠭ࠧ㩄"))
			res = re.findall(l1l11l_l1_ (u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢ㩅"),title+l1l11l_l1_ (u"ࠨࠨࠩࠫ㩆"),re.DOTALL)
			for resolution in l1l1lll11lll_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l11l_l1_ (u"ࠩࡻࠫ㩇"))[1])
			l1ll111ll1l1_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1ll1lll_l1_)):
			items = re.findall(l1l11l_l1_ (u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦ㩈"),l1l11l_l1_ (u"ࠫࠫࠬࠧ㩉")+l1ll111ll1l1_l1_[i]+l1l11l_l1_ (u"ࠬࠬࠦࠨ㩊"),re.DOTALL)
			l1lll1l11111_l1_.append( [l1ll111ll1l1_l1_[i],l1ll1lll_l1_[i],items[0][0],items[0][1]] )
		l1lll1l11111_l1_ = sorted(l1lll1l11111_l1_, key=lambda x: x[3], reverse=True)
		l1lll1l11111_l1_ = sorted(l1lll1l11111_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll_l1_,l1ll1lll_l1_ = [],[]
		for i in range(len(l1lll1l11111_l1_)):
			l1l1lll_l1_.append(l1lll1l11111_l1_[i][0])
			l1ll1lll_l1_.append(l1lll1l11111_l1_[i][1])
	if len(l1ll1lll_l1_)==0: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ㩋"),[],[]
	return l1l11l_l1_ (u"ࠧࠨ㩌"),l1l1lll_l1_,l1ll1lll_l1_
def l1l11lllllll_l1_(url):
	# http://l1l1ll111lll_l1_.com/717254
	parts = url.split(l1l11l_l1_ (u"ࠨࡁࠪ㩍"))
	url2 = parts[0]
	headers = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㩎") : l1l11l_l1_ (u"ࠪࠫ㩏") }
	html = OPENURL_CACHED(l111l11l_l1_,url2,l1l11l_l1_ (u"ࠫࠬ㩐"),headers,l1l11l_l1_ (u"ࠬ࠭㩑"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭㩒"))
	items = re.findall(l1l11l_l1_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ㩓"),html,re.DOTALL)
	url = items[0]
	#l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1l111l1l_l1_(url)
	#return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㩔"),[l1l11l_l1_ (u"ࠩࠪ㩕")],[url]
def l1ll11lll11l_l1_(url):
	# https://l11l1llll1_l1_.l11l1l11l1_l1_/l11ll1111l_l1_
	# https://l11l1l11ll_l1_.cc/l11ll1111l_l1_
	l1l1lll_l1_,l1ll1lll_l1_ = [],[]
	headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㩖") : l1l11l_l1_ (u"ࠫࠬ㩗") }
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠬ࠭㩘"),headers,l1l11l_l1_ (u"࠭ࠧ㩙"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭㩚"))
	url2 = re.findall(l1l11l_l1_ (u"ࠨࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡹࡷࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㩛"),html,re.DOTALL)
	if url2: return l1l11l_l1_ (u"ࠩࠪ㩜"),[l1l11l_l1_ (u"ࠪࠫ㩝")],[url2[0]]
	else: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧ㩞"),[],[]
def l1l1l1111l1l_l1_(url):
	# https://l11l1llll1_l1_.l11l1l11l1_l1_/l11ll1111l_l1_
	# https://l11l1l11ll_l1_.cc/l11ll1111l_l1_
	l1l1lll_l1_,l1ll1lll_l1_ = [],[]
	headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㩟") : l1l11l_l1_ (u"࠭ࠧ㩠") }
	html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠧࠨ㩡"),headers,l1l11l_l1_ (u"ࠨࠩ㩢"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ㩣"))
	url2 = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭㩤"),html,re.DOTALL)
	if url2: return l1l11l_l1_ (u"ࠫࠬ㩥"),[l1l11l_l1_ (u"ࠬ࠭㩦")],[url2[0]]
	else: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙ࠧ㩧"),[],[]
def l1111lll11_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㩨"),l1l11l_l1_ (u"ࠨࠩ㩩"),url,str(0000))
	# l1l1ll11l_l1_    https://show.l1ll11111lll_l1_.com/l1ll11l1llll_l1_-l1ll11l111ll_l1_/l1ll11l111ll_l1_-l1ll11ll11l1_l1_.l1111l11l_l1_?action=l1l1lll1l11l_l1_&l11l11l111_l1_=32513&l1111lll1l_l1_=1&type=l11l1lllll_l1_
	# download https://show.l1ll11111lll_l1_.com/l1ll1111_l1_/l1ll1lllll11_l1_
	l1l1lll_l1_,l1ll1lll_l1_,errno = [],[],l1l11l_l1_ (u"ࠩࠪ㩪")
	# l1l1ll11l_l1_
	if l1l11l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࠧ㩫") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㩬"):l1l11l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ㩭")}
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㩮"),url2,data2,headers2,l1l11l_l1_ (u"ࠧࠨ㩯"),l1l11l_l1_ (u"ࠨࠩ㩰"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬ㩱"))
		l1lll111_l1_ = response.content
		url2 = re.findall(l1l11l_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫ㩲"),l1lll111_l1_,re.DOTALL)
		url2 = url2[0]
		#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㩳"),l1l11l_l1_ (u"ࠬ࠭㩴"),url2,str(1111))
	# download
	elif l1l11l_l1_ (u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࠧ㩵") in url:
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㩶"),url,l1l11l_l1_ (u"ࠨࠩ㩷"),l1l11l_l1_ (u"ࠩࠪ㩸"),True,l1l11l_l1_ (u"ࠪࠫ㩹"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧ㩺"))
		l1lll111_l1_ = response.content
		if l1l11l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㩻") in list(response.headers.keys()): url2 = response.headers[l1l11l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㩼")]
		else: url2 = re.findall(l1l11l_l1_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㩽"),l1lll111_l1_,re.DOTALL)[0]
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㩾"),l1l11l_l1_ (u"ࠩࠪ㩿"),url2,str(2222))
	if l1l11l_l1_ (u"ࠪ࠳ࡻ࠵ࠧ㪀") in url2 or l1l11l_l1_ (u"ࠫ࠴࡬࠯ࠨ㪁") in url2:
		url2 = url2.replace(l1l11l_l1_ (u"ࠬ࠵ࡦ࠰ࠩ㪂"),l1l11l_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ㪃"))
		url2 = url2.replace(l1l11l_l1_ (u"ࠧ࠰ࡸ࠲ࠫ㪄"),l1l11l_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ㪅"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㪆"),l1l11l_l1_ (u"ࠪࠫ㪇"),url2,str(3333))
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㪈"),url2,l1l11l_l1_ (u"ࠬ࠭㪉"),l1l11l_l1_ (u"࠭ࠧ㪊"),l1l11l_l1_ (u"ࠧࠨ㪋"),l1l11l_l1_ (u"ࠨࠩ㪌"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬ㪍"))
		l1lll111_l1_ = response.content
		items = re.findall(l1l11l_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㪎"),l1lll111_l1_,re.DOTALL)
		if items:
			for l1111l_l1_,title in items:
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠫࡡࡢࠧ㪏"),l1l11l_l1_ (u"ࠬ࠭㪐"))
				l1l1lll_l1_.append(title)
				l1ll1lll_l1_.append(l1111l_l1_)
		else:
			items = re.findall(l1l11l_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㪑"),l1lll111_l1_,re.DOTALL)
			if items:
				l1111l_l1_ = items[0]
				l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠧ࡝࡞ࠪ㪒"),l1l11l_l1_ (u"ࠨࠩ㪓"))
				l1l1lll_l1_.append(l1l11l_l1_ (u"ࠩࠪ㪔"))
				l1ll1lll_l1_.append(l1111l_l1_)
	else: return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㪕"),[l1l11l_l1_ (u"ࠫࠬ㪖")],[url2]
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㪗"),l1l11l_l1_ (u"࠭ࠧ㪘"),str(data2),url2)
	if len(l1ll1lll_l1_)==0: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㪙"),[],[]
	return l1l11l_l1_ (u"ࠨࠩ㪚"),l1l1lll_l1_,l1ll1lll_l1_
def l11l111ll11_l1_(url):
	# l1l1ll11l_l1_ l11lllll_l1_  https://l1ll1l11ll1l_l1_.l1l1lll1l1l1_l1_.l11l1l11l1_l1_/l11l11l1ll1_l1_/l1l1l1111l11_l1_.l1111l11l_l1_?s=07&id=l1l1l111ll11_l1_,&img=2wh9shmvcTypozADtS8EpvgrwWS.l1l1lll11ll1_l1_&l1l1l1lll111_l1_=l1l1lll111l1_l1_&l1ll1ll11lll_l1_=l1l1l1l11l1l_l1_
	# l1l1ll11l_l1_ l11l11l1_l1_ https://l1l1llll1l11_l1_.l1l1lll1l1l1_l1_.l11l1l11l1_l1_/l11l11l1ll1_l1_/l1ll11111l11_l1_.l1111l11l_l1_?l1l1l1l11111_l1_=l1l1lll1ll1l_l1_&l1l1lll11111_l1_=8a26a6cc61a884e89076504130c71626&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1l1lll11ll1_l1_&l1l1l1lll111_l1_=l1l1lll111l1_l1_&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1l1lll11ll1_l1_&l1l1l1lll111_l1_=l1l1lll111l1_l1_&l1ll1ll11lll_l1_=l1ll111l1l11_l1_
	# download https://l111ll1l11l_l1_.l1l1ll11111l_l1_.l1ll11ll1111_l1_/l1lll11ll1ll_l1_?server=l1l1lllll11l_l1_&id=l1l1l11l1111_l1_,,
	# l1l11ll1l_l1_ https://l1l1ll11111l_l1_.l1111ll1l_l1_/l1l11ll1l_l1_/l1ll1llllll1_l1_
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㪛"),url,l1l11l_l1_ (u"ࠪࠫ㪜"),l1l11l_l1_ (u"ࠫࠬ㪝"),l1l11l_l1_ (u"ࠬ࠭㪞"),l1l11l_l1_ (u"࠭ࠧ㪟"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠵ࡸࡺࠧ㪠"))
	html = response.content
	l1l1lll_l1_,l1ll1lll_l1_,errno = [],[],l1l11l_l1_ (u"ࠨࠩ㪡")
	if l1l11l_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ㪢") in url or l1l11l_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ㪣") in url:
		if l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ㪤") in url:
			url2 = re.findall(l1l11l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㪥"),html,re.DOTALL)
			url2 = url2[0]
		else: url2 = url
		if l1l11l_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭㪦") not in url2: return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㪧"),[l1l11l_l1_ (u"ࠨࠩ㪨")],[url2]
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㪩"),url2,l1l11l_l1_ (u"ࠪࠫ㪪"),l1l11l_l1_ (u"ࠫࠬ㪫"),l1l11l_l1_ (u"ࠬ࠭㪬"),l1l11l_l1_ (u"࠭ࠧ㪭"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠶ࡳࡪࠧ㪮"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࡬ࡶࠫ㪯"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㪰"),block,re.DOTALL)
		if items:
			for l1111l_l1_,l11ll11l111_l1_ in items:
				l1l1lll_l1_.append(l11ll11l111_l1_)
				l1ll1lll_l1_.append(l1111l_l1_)
	elif l1l11l_l1_ (u"ࠪࡱࡦ࡯࡮ࡠࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࠬ㪱") in url:
		url2 = re.findall(l1l11l_l1_ (u"ࠫࡺࡸ࡬࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ㪲"),html,re.DOTALL)
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㪳"),url2,l1l11l_l1_ (u"࠭ࠧ㪴"),l1l11l_l1_ (u"ࠧࠨ㪵"),l1l11l_l1_ (u"ࠨࠩ㪶"),l1l11l_l1_ (u"ࠩࠪ㪷"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠳ࡳࡦࠪ㪸"))
		html = response.content
		url3 = re.findall(l1l11l_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㪹"),html,re.DOTALL)
		url3 = url3[0]
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠬ࠭㪺"))
		l1ll1lll_l1_.append(url3)
	elif l1l11l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠ࡮࡬ࡲࡰ࠭㪻") in url:
		url2 = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡥࡨࡲࡹ࡫ࡲ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㪼"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㪽"),[l1l11l_l1_ (u"ࠩࠪ㪾")],[url2]
	if len(l1ll1lll_l1_)==0: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡗࡕ࠷࡙ࠬ㪿"),[],[]
	return l1l11l_l1_ (u"ࠫࠬ㫀"),l1l1lll_l1_,l1ll1lll_l1_
def l1l111111l_l1_(url):
	# https://l1l1l111l1l1_l1_.l1ll1l1l1l11_l1_/l1ll1111l1ll_l1_?call=l1lll11111ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l1ll111l1l1l_l1_=l1l1l11lll11_l1_
	# https://l1l1l111l1l1_l1_.l1ll1l1l1l11_l1_/l1ll1111l1ll_l1_?call=l1lll11111ll_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l1ll111l1l1l_l1_=l1ll11l1lll1_l1_
	url2 = url.split(l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㫁"),1)[0].strip(l1l11l_l1_ (u"࠭࠿ࠨ㫂")).strip(l1l11l_l1_ (u"ࠧ࠰ࠩ㫃")).strip(l1l11l_l1_ (u"ࠨࠨࠪ㫄"))
	l1l1lll_l1_,l1ll1lll_l1_,items,url3 = [],[],[],l1l11l_l1_ (u"ࠩࠪ㫅")
	headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㫆"):l1l11l_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫ㫇") }
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㫈"),url2,l1l11l_l1_ (u"࠭ࠧ㫉"),headers,True,l1l11l_l1_ (u"ࠧࠨ㫊"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩ㫋"))
	if l1l11l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㫌") in list(response.headers.keys()): url3 = response.headers[l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㫍")]
	#response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㫎"),url3,l1l11l_l1_ (u"ࠬ࠭㫏"),headers,False,l1l11l_l1_ (u"࠭ࠧ㫐"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠷ࡴࡤࠨ㫑"))
	#if l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㫒") in response.headers: url3 = response.headers[l1l11l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㫓")]
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㫔"),l1l11l_l1_ (u"ࠫࠬ㫕"),url3,response.content)
	if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㫖") in url3:
		# https://l1l111l111_l1_.top/f/l1ll1l111ll1_l1_/?l1l1l1l1ll_l1_=l1lll11ll1l1_l1_
		# https://l1l111l111_l1_.top/v/l1ll1l111ll1_l1_/?l1l1l1l1ll_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l1l11l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ㫗") in url: url3 = url3.replace(l1l11l_l1_ (u"ࠧ࠰ࡨ࠲ࠫ㫘"),l1l11l_l1_ (u"ࠨ࠱ࡹ࠳ࠬ㫙"))
		l1ll11l111l1_l1_ = url2.split(l1l11l_l1_ (u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ㫚"))[1]
		headers = { l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㫛"):headers[l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㫜")] , l1l11l_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ㫝"):l1l11l_l1_ (u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧ㫞")+l1ll11l111l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㫟"),url3,l1l11l_l1_ (u"ࠨࠩ㫠"),headers,False,l1l11l_l1_ (u"ࠩࠪ㫡"),l1l11l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭㫢"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l111l11l_l1_,url3,l1l11l_l1_ (u"ࠫࠬ㫣"),headers,l1l11l_l1_ (u"ࠬ࠭㫤"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠷ࡷࡪࠧ㫥"))
		if l1l11l_l1_ (u"ࠧ࠰ࡨ࠲ࠫ㫦") in url3: items = re.findall(l1l11l_l1_ (u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㫧"),html,re.DOTALL)
		elif l1l11l_l1_ (u"ࠩ࠲ࡺ࠴࠭㫨") in url3: items = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㫩"),html,re.DOTALL)
		if items: return [],[l1l11l_l1_ (u"ࠫࠬ㫪")],[ items[0] ]
		elif l1l11l_l1_ (u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫ㫫") in html:
			return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩ㫬"),[],[]
	else: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪ㫭"),[],[]
	#xbmc.log(html)
def l1l1l1l1l1l_l1_(l1111l_l1_):
	# https://l1lll1l11lll_l1_.net/?l1lll11l_l1_=147043&l1lll1ll_l1_=5
	parts = re.findall(l1l11l_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ㫮"),l1111l_l1_+l1l11l_l1_ (u"ࠩࠩࠪࠬ㫯"),re.DOTALL|re.IGNORECASE)
	l1lll11l_l1_,l1lll1ll_l1_ = parts[0]
	url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ㫰")+l1lll11l_l1_+l1l11l_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ㫱")+l1lll1ll_l1_
	headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㫲"):l1l11l_l1_ (u"࠭ࠧ㫳") , l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ㫴"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ㫵") }
	url2 = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠩࠪ㫶"),headers,l1l11l_l1_ (u"ࠪࠫ㫷"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪ㫸"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㫹"),l1l11l_l1_ (u"࠭ࠧ㫺"),url,url2)
	#l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1l111l1l_l1_(url2)
	#return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㫻"),[l1l11l_l1_ (u"ࠨࠩ㫼")],[url2]
def l11l1ll1l1l_l1_(url):
	# https://l1ll1l11llll_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1ll1l1111ll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l1l1l1l1l1ll_l1_=1608181746
	server = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㫽"))
	headers2 = {l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㫾"):server,l1l11l_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭㫿"):l1l11l_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ㬀")}
	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㬁"),url,l1l11l_l1_ (u"ࠧࠨ㬂"),headers2,l1l11l_l1_ (u"ࠨࠩ㬃"),l1l11l_l1_ (u"ࠩࠪ㬄"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ㬅"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ㬆"),html,re.DOTALL)
	url2 = l1l11l_l1_ (u"ࠬ࠭㬇")
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ㬈"),block,re.DOTALL)
		l1l1lll_l1_,l1ll1lll_l1_ = [],[]
		for title,l1111l_l1_ in items:
			l1l1lll_l1_.append(title)
			l1ll1lll_l1_.append(l1111l_l1_)
		if len(l1ll1lll_l1_)==1: url2 = l1ll1lll_l1_[0]
		elif len(l1ll1lll_l1_)>1:
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ㬉"), l1l1lll_l1_)
			if selection==-1: return l1l11l_l1_ (u"ࠨࠩ㬊"),[],[]
			url2 = l1ll1lll_l1_[selection]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㬋"),html,re.DOTALL)
		if l1ll111_l1_: url2 = l1ll111_l1_[0]
	if not url2: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡄࡋࡐࡅࠬ㬌"),[],[]
	return l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㬍"),[l1l11l_l1_ (u"ࠬ࠭㬎")],[url2]
def l111lllll11_l1_(url):
	# https://l1lll1l1l11l_l1_.l1ll1llll1l1_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1ll1l1111ll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l1l1l1l1l1ll_l1_=1608181746
	server = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㬏"))
	headers2 = {l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㬐"):server,l1l11l_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ㬑"):l1l11l_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ㬒")}
	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㬓"),url,l1l11l_l1_ (u"ࠫࠬ㬔"),headers2,l1l11l_l1_ (u"ࠬ࠭㬕"),l1l11l_l1_ (u"࠭ࠧ㬖"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ㬗"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ㬘"),html,re.DOTALL)
	url2 = l1l11l_l1_ (u"ࠩࠪ㬙")
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ㬚"),block,re.DOTALL)
		l1l1lll_l1_,l1ll1lll_l1_ = [],[]
		for title,l1111l_l1_ in items:
			l1l1lll_l1_.append(title)
			l1ll1lll_l1_.append(l1111l_l1_)
		if len(l1ll1lll_l1_)==1: url2 = l1ll1lll_l1_[0]
		elif len(l1ll1lll_l1_)>1:
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ㬛"), l1l1lll_l1_)
			if selection==-1: return l1l11l_l1_ (u"ࠬ࠭㬜"),[],[]
			url2 = l1ll1lll_l1_[selection]
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㬝"),html,re.DOTALL)
		if l1ll111_l1_: url2 = l1ll111_l1_[0]
	if not url2: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩ㬞"),[],[]
	return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㬟"),[l1l11l_l1_ (u"ࠩࠪ㬠")],[url2]
def l1111ll_l1_(l1111l_l1_):
	# https://w.l1ll1111111l_l1_.l1l1ll11llll_l1_/l1ll11l1llll_l1_-content/l1ll1lllll1l_l1_/l1l1lllllll1_l1_/l1l1ll11ll11_l1_/l1ll1ll11l11_l1_/l1l1l1l1l1l1_l1_/l1ll11ll1l11_l1_.l1111l11l_l1_?l1lll11l_l1_=42869&l1lll1ll_l1_=4
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㬡"),l1l11l_l1_ (u"ࠫࠬ㬢"),l1111l_l1_,html)
	parts = re.findall(l1l11l_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ㬣"),l1111l_l1_+l1l11l_l1_ (u"࠭ࠦࠧࠩ㬤"),re.DOTALL)
	url,l1lll11l_l1_,l1lll1ll_l1_ = parts[0]
	data = {l1l11l_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤࠨ㬥"):l1lll11l_l1_,l1l11l_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ㬦"):l1lll1ll_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㬧"),url,data,l1l11l_l1_ (u"ࠪࠫ㬨"),l1l11l_l1_ (u"ࠫࠬ㬩"),l1l11l_l1_ (u"ࠬ࠭㬪"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ㬫"))
	html = response.content
	url2 = re.findall(l1l11l_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㬬"),html,re.DOTALL)[0]
	return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㬭"),[l1l11l_l1_ (u"ࠩࠪ㬮")],[url2]
def l1111111l_l1_(url):
	# https://l1ll11l1111l_l1_.l1111ll11_l1_-l1l1l1111ll1_l1_.com/l1l11ll1l_l1_.l1111l11l_l1_?l1ll111l11ll_l1_=l1ll1ll1l1ll_l1_
	# https://l.l1ll11ll1ll1_l1_.l1ll11ll1111_l1_/l1l11ll1l_l1_.l1111l11l_l1_?l1ll111l11ll_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㬯"),url,l1l11l_l1_ (u"ࠫࠬ㬰"),l1l11l_l1_ (u"ࠬ࠭㬱"),l1l11l_l1_ (u"࠭ࠧ㬲"),l1l11l_l1_ (u"ࠧࠨ㬳"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫ㬴"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㬵"),html,re.DOTALL)
	if l1111l_l1_:
		l1111l_l1_ = l1111l_l1_[0]
		return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㬶"),[l1l11l_l1_ (u"ࠫࠬ㬷")],[l1111l_l1_]
	return l1l11l_l1_ (u"ࠬ࠭㬸"),[],[]
def l111l111l_l1_(url):
	# https://l1111l1ll_l1_.l1111ll11_l1_-l1111ll1l_l1_.l1111ll1l_l1_/l1ll11l1llll_l1_-content/l1ll1lllll1l_l1_/old/l1l1l1l111ll_l1_/server.l1111l11l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㬹"),url,l1l11l_l1_ (u"ࠧࠨ㬺"),l1l11l_l1_ (u"ࠨࠩ㬻"),l1l11l_l1_ (u"ࠩࠪ㬼"),l1l11l_l1_ (u"ࠪࠫ㬽"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡑ࠯࠴ࡷࡹ࠭㬾"))
	html = response.content
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡂࡉࡇࡔࡄࡑࡊࠦࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㬿"),html,re.DOTALL)[0]
	return l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㭀"),[l1l11l_l1_ (u"ࠧࠨ㭁")],[l1111l_l1_]
def l11111111_l1_(url):
	# https://l1ll1ll11ll1_l1_.l111l111l1l_l1_.cc/l1ll11l1llll_l1_-content/l1ll1lllll1l_l1_/l1ll111lll11_l1_%20Now%20New/l1ll1ll111l1_l1_.l1111l11l_l1_?action=l1l1l1111111_l1_&index=00&id=58504
	# https://l1l1l11l1ll1_l1_.l111l111l1l_l1_.net/l1lll111l111_l1_/2021/04/05/_1ll1ll1lll1_l1_-l1lll11l1lll_l1_.l1l1l111l11l_l1_ 200.l1l1l1l1111l_l1_.2020.l1l1l11l1l1l_l1_/[l1ll111lll11_l1_-l1lll11l1lll_l1_.l1l11lllll1l_l1_] 200.l1l1l1l1111l_l1_.2020.l1l1l11l1l1l_l1_-360p.l11lllll_l1_
	l11l1111l_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㭂"))
	if l1l11l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ㭃") in url:
		headers = {l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㭄"):l11l1111l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ㭅"),url,l1l11l_l1_ (u"ࠬ࠭㭆"),headers,l1l11l_l1_ (u"࠭ࠧ㭇"),l1l11l_l1_ (u"ࠧࠨ㭈"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ㭉"))
		html = response.content
		url2 = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㭊"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			if l1l11l_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ㭋") in url2:
				url2 = url2.replace(l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭㭌"),l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭㭍"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㭎"),url2,l1l11l_l1_ (u"ࠧࠨ㭏"),headers,l1l11l_l1_ (u"ࠨࠩ㭐"),l1l11l_l1_ (u"ࠩࠪ㭑"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ㭒"))
				l1lll111_l1_ = response.content
				items = re.findall(l1l11l_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㭓"),l1lll111_l1_,re.DOTALL)
				l1l1lll_l1_,l1ll1lll_l1_ = [],[]
				l11l11111_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㭔"))
				for l1111l_l1_,l1l1l1l1_l1_ in reversed(items):
					l1111l_l1_ = l11l11111_l1_+l1111l_l1_+l1l11l_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ㭕")+l11l11111_l1_
					l1l1lll_l1_.append(l1l1l1l1_l1_)
					l1ll1lll_l1_.append(l1111l_l1_)
				return l1l11l_l1_ (u"ࠧࠨ㭖"),l1l1lll_l1_,l1ll1lll_l1_
			else: return l1l11l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㭗"),[l1l11l_l1_ (u"ࠩࠪ㭘")],[url2]
	url2 = url+l1l11l_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭㭙")+l11l1111l_l1_
	return l1l11l_l1_ (u"ࠫࠬ㭚"),[l1l11l_l1_ (u"ࠬ࠭㭛")],[url2]
def l1l1ll1l111l_l1_(l1111l_l1_):
	# https://l111l111l1l_l1_.l1l1ll11llll_l1_/l1ll11l1llll_l1_-content/l1ll1lllll1l_l1_/l1lll1lll111_l1_/l1ll1l11111l_l1_/server.l1111l11l_l1_?l1lll11l_l1_=42869&l1lll1ll_l1_=4
	# https://l1l1lll1111l_l1_.l111l111l1l_l1_.net/l1lll111l111_l1_/2020/08/14/_1ll1ll1lll1_l1_-l1lll11l1lll_l1_.l1l1l111l11l_l1_ l1l1l111l1ll_l1_.l1l1l1l1llll_l1_.2020.l1l1ll111l1l_l1_-l1l1ll11l1l1_l1_/[l1ll111lll11_l1_-l1lll11l1lll_l1_.l1l11lllll1l_l1_] l1l1l111l1ll_l1_.l1l1l1l1llll_l1_.2020.l1l1ll111l1l_l1_-l1l1ll11l1l1_l1_-1080p.l11lllll_l1_
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㭜"),l1l11l_l1_ (u"ࠧࠨ㭝"),url,html)
	l11l1111l_l1_ = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㭞"))
	if l1l11l_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥࠩ㭟") in l1111l_l1_:
		parts = re.findall(l1l11l_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ㭠"),l1111l_l1_+l1l11l_l1_ (u"ࠫࠫࠬࠧ㭡"),re.DOTALL)
		url,l1lll11l_l1_,l1lll1ll_l1_ = parts[0]
		data = {l1l11l_l1_ (u"ࠬ࡯ࡤࠨ㭢"):l1lll11l_l1_,l1l11l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭㭣"):l1lll1ll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㭤"),url,data,l1l11l_l1_ (u"ࠨࠩ㭥"),l1l11l_l1_ (u"ࠩࠪ㭦"),l1l11l_l1_ (u"ࠪࠫ㭧"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ㭨"))
		html = response.content
		url2 = re.findall(l1l11l_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㭩"),html,re.DOTALL)[0]
		if l1l11l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ㭪") in url2:
			headers = {l1l11l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㭫"):l11l1111l_l1_,l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㭬"):l1l11l_l1_ (u"ࠩࠪ㭭")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㭮"),url2,l1l11l_l1_ (u"ࠫࠬ㭯"),headers,l1l11l_l1_ (u"ࠬ࠭㭰"),l1l11l_l1_ (u"࠭ࠧ㭱"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ㭲"))
			l1lll111_l1_ = response.content
			items = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㭳"),l1lll111_l1_,re.DOTALL)
			l1l1lll_l1_,l1ll1lll_l1_ = [],[]
			l11l11111_l1_ = SERVER(url2,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㭴"))
			for l1111l_l1_,l1l1l1l1_l1_ in reversed(items):
				l1111l_l1_ = l11l11111_l1_+l1111l_l1_+l1l11l_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭㭵")+l11l11111_l1_
				l1l1lll_l1_.append(l1l1l1l1_l1_)
				l1ll1lll_l1_.append(l1111l_l1_)
			return l1l11l_l1_ (u"ࠫࠬ㭶"),l1l1lll_l1_,l1ll1lll_l1_
		else: return l1l11l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㭷"),[l1l11l_l1_ (u"࠭ࠧ㭸")],[url2]
	else:
		l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ㭹")+l11l1111l_l1_
		return l1l11l_l1_ (u"ࠨࠩ㭺"),[l1l11l_l1_ (u"ࠩࠪ㭻")],[l1111l_l1_]
def l1l11l111_l1_(l1111l_l1_):
	# http://l1ll1l1ll11l_l1_.tv/?l1lll11l_l1_=159485&l1lll1ll_l1_=0
	if l1l11l_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࠪ㭼") in l1111l_l1_:
		parts = re.findall(l1l11l_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭㭽"),l1111l_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨ㭾"),re.DOTALL|re.IGNORECASE)
		l1lll11l_l1_,l1lll1ll_l1_ = parts[0]
		host = SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㭿"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ㮀"),l1l11l_l1_ (u"ࠨࠩ㮁"),l1111l_l1_,host)
		url = host+l1l11l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ㮂")+l1lll11l_l1_+l1l11l_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ㮃")+l1lll1ll_l1_
		headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㮄"):l1l11l_l1_ (u"ࠬ࠭㮅") , l1l11l_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ㮆"):l1l11l_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ㮇") }
		url2 = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠨࠩ㮈"),headers,l1l11l_l1_ (u"ࠩࠪ㮉"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬ㮊"))
		url2 = url2.replace(l1l11l_l1_ (u"ࠫࡡࡴࠧ㮋"),l1l11l_l1_ (u"ࠬ࠭㮌")).replace(l1l11l_l1_ (u"࠭࡜ࡳࠩ㮍"),l1l11l_l1_ (u"ࠧࠨ㮎"))
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㮏"),l1l11l_l1_ (u"ࠩࠪ㮐"),url,url2)
		#l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1ll1l111l1l_l1_(url2)
		#return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
		return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㮑"),[l1l11l_l1_ (u"ࠫࠬ㮒")],[url2]
	elif l1l11l_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ㮓") in l1111l_l1_:
		counts = 0
		while l1l11l_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ㮔") in l1111l_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㮕"),l1111l_l1_,l1l11l_l1_ (u"ࠨࠩ㮖"),l1l11l_l1_ (u"ࠩࠪ㮗"),l1l11l_l1_ (u"ࠪࠫ㮘"),l1l11l_l1_ (u"ࠫࠬ㮙"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠶ࡳࡪࠧ㮚"))
			if l1l11l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㮛") in list(response.headers.keys()): l1111l_l1_ = response.headers[l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㮜")]
			counts += 1
		return l1l11l_l1_ (u"ࠨࠩ㮝"),[l1l11l_l1_ (u"ࠩࠪ㮞")],[l1111l_l1_]
	else: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧ㮟"),[],[]
def l1l1l1l11_l1_(url):
	# https://l1ll1l1ll111_l1_.l1l1l1lll1ll_l1_.me/l/l1ll1ll1l1l1_l1_=
	server = SERVER(url,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㮠"))
	headers = {l1l11l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㮡"):server,l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㮢"):l1ll11ll1_l1_()}
	if l1l11l_l1_ (u"ࠧ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ㮣") in url:
		headers2 = {l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㮤"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㮥")}
		url2,data2 = URLDECODE(url)
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㮦"),url2,data2,headers2,True,l1l11l_l1_ (u"ࠫࠬ㮧"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠵ࡸࡺࠧ㮨"))
		html = response.content
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㮩"),html,re.DOTALL|re.IGNORECASE)
		if l1ll1111_l1_: return l1l11l_l1_ (u"ࠧࠨ㮪"),[l1l11l_l1_ (u"ࠨࠩ㮫")],[l1ll1111_l1_[0]]
	elif l1l11l_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ㮬") in url:
		html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠪࠫ㮭"),headers,l1l11l_l1_ (u"ࠫࠬ㮮"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧ㮯"))
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㮰"),html,re.DOTALL)
		if l1ll1111_l1_: return l1l11l_l1_ (u"ࠧࠨ㮱"),[l1l11l_l1_ (u"ࠨࠩ㮲")],[l1ll1111_l1_[0]]
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㮳"),url,l1l11l_l1_ (u"ࠪࠫ㮴"),headers,l1l11l_l1_ (u"ࠫࠬ㮵"),l1l11l_l1_ (u"ࠬ࠭㮶"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨ㮷"))
		if l1l11l_l1_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫ㮸") in list(response.headers.keys()):
			cookies = response.headers[l1l11l_l1_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ㮹")]
			l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡢࡰࡳࡱ࡟࠯ࠬࡂࡁ࠭࠴ࠪࡀࠫ࠾ࠫ㮺"),cookies,re.DOTALL)
			if l1ll1111_l1_:
				l1111l_l1_ = UNQUOTE(l1ll1111_l1_[0])
				return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㮻"),[l1l11l_l1_ (u"ࠫࠬ㮼")],[l1111l_l1_]
	return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩ㮽"),[],[]
	l1l11l_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠨࠦ࡮ࡰࡶࠣࡻࡴࡸ࡫ࡪࡰࡪࠎࠎࠏࠣࠡ࡫ࡷࠤࡳ࡫ࡥࡥࡵࠣࡧࡴࡵ࡫ࡪࡧࠣࡪࡷࡵ࡭ࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠏࠏࠉࠤࠢࡆࡳࡴࡱࡩࡦ࠼ࠣࡧ࡫ࡥࡣ࡭ࡧࡤࡶࡦࡴࡣࡦ࠿ࡆࡑࡪ࠴ࡈࡌࡉࡔ࡯ࡲࡽ࡮ࡔࡘࡸࡲࡿ࡜ࡉࡱࡳࡲࡻࡶ࡙ࡁ࡛ࡥࡳࡲࡋ࠽ࡪࡃࡒࡘࡓࡖࡨ࡙ࡃࡈ࠳࠱࠶࠼࠶࠴࠳࠴࠶࠵࠶࠶࠮࠲࠰࠶࠺࠶ࠊࠊࠋࡶࡩࡷࡼࡥࡳࠢࡀࠤࡘࡋࡒࡗࡇࡕࠬࡺࡸ࡬࠭ࠩࡸࡶࡱ࠭ࠩࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࡀࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕࠪࠬ࠰ࠬࡘࡥࡧࡧࡵࡩࡷ࠭࠺ࡴࡧࡵࡺࡪࡸࡽࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠸࡮ࡥࠩࠬࠎࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏࢀࡷ࡫࠮ࡊࡉࡑࡓࡗࡋࡃࡂࡕࡈ࠭ࠏࠏࠉࡪࡨࠣࡰ࡮ࡴ࡫ࡴ࠼ࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡧࡰࡦࡪࡪ࠭ࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡࡴࡨࡸࡺࡸ࡮ࠡࠩࠪ࠰ࡠ࠭ࠧ࡞࠮࡞ࡰ࡮ࡴ࡫࡞ࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡺࡸ࡬ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫ࠯࡬ࡹࡳ࡬ࠪࠌࠌࠍࠨࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࡞࠴ࡢࠐࠉࠊࠥ࡬ࡪࠥ࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠋࠋࠌࠧࠎ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠦࠍࡷ࡫ࡴࡶࡴࡱࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠎࠎࠏࠣࡦ࡮ࡶࡩ࠿ࠦࡵࡳ࡮ࠣࡁࠥࡲࡩ࡯࡭ࠍࠍࠧࠨࠢ㮾")
	#if l1l11l_l1_ (u"ࠧ࠯࡯ࡳ࠸࠳࡮ࡴ࡮࡮ࠪ㮿") in url:
	#	l11l1l1111l_l1_ = url.split(l1l11l_l1_ (u"ࠨ࠱ࠪ㯀"))
	#	url = l1l11l_l1_ (u"ࠩ࠲ࠫ㯁").join(l11l1l1111l_l1_[:4])
	#	tmp = re.findall(l1l11l_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠴࠵࠮ࠫࡁ࠲࠭࠭࠴ࠪࡀࠫࠧࠫ㯂"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l1l11l_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ㯃")+tmp[0][1]+l1l11l_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ㯄")
	#	#return l1l11l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㯅"),[l1l11l_l1_ (u"ࠧࠨ㯆")],[url]
	#	#l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l1l1ll1111_l1_(url)
	#	#return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
	# l1l11ll1l_l1_ l1111l_l1_
	#return l1l11l_l1_ (u"ࠨࠩ㯇"),[l1l11l_l1_ (u"ࠩࠪ㯈")],[l1111l_l1_]
def l111lll1lll_l1_(l1111l_l1_):
	# https://shahid4u.net/?l1lll11l_l1_=142302&l1lll1ll_l1_=4
	parts = re.findall(l1l11l_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ㯉"),l1111l_l1_,re.DOTALL|re.IGNORECASE)
	l1lll11l_l1_,l1lll1ll_l1_ = parts[0]
	server = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㯊"))
	url = server+l1l11l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡗ࡭ࡧࡨࡪࡦ࠷ࡹ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ㯋")
	#url = server+l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ㯌")+l1lll11l_l1_+l1l11l_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ㯍")+l1lll1ll_l1_
	#data = {l1l11l_l1_ (u"ࠨ࡫ࡧࠫ㯎"):l1lll11l_l1_,l1l11l_l1_ (u"ࠩ࡬ࠫ㯏"):l1lll1ll_l1_,l1l11l_l1_ (u"ࠪࡱࡪࡺࡡࠨ㯐"):l1l11l_l1_ (u"ࠫࡴࡲࡤࡠࡵࡨࡶࡻ࡫ࡲࡴࠩ㯑"),l1l11l_l1_ (u"ࠬࡺࡹࡱࡧࠪ㯒"):l1l11l_l1_ (u"࠭࡯࡭ࡦࠪ㯓")}
	data = {l1l11l_l1_ (u"ࠧࡪࡦࠪ㯔"):l1lll11l_l1_,l1l11l_l1_ (u"ࠨ࡫ࠪ㯕"):l1lll1ll_l1_}
	headers = {l1l11l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ㯖"):l1l11l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ㯗"),l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㯘"):l1111l_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡖࡏࡔࡖࠪ㯙"),url,data,headers,l1l11l_l1_ (u"࠭ࠧ㯚"),l1l11l_l1_ (u"ࠧࠨ㯛"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠱ࡴࡶࠪ㯜"))
	l1lll111_l1_ = response.content
	url2 = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㯝"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
	if url2:
		url2 = url2[0]
		return l1l11l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭㯞"),[l1l11l_l1_ (u"ࠫࠬ㯟")],[url2]
	return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㯠"),[],[]
def l11ll1_l1_(url2,type,l1l1l1l1_l1_):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㯡"),l1l11l_l1_ (u"ࠧࠨ㯢"),url2,type)
	# https://l1ll1l1l11l1_l1_-2o.com/l1l1ll11l_l1_/12899		?l1ll111l1l1l_l1_=		__1lll1ll1ll1_l1_
	# https://l1ll1l1l11l1_l1_-2o.com/l1111l_l1_/12899			?l1ll111l1l1l_l1_=		__1l1ll11l1ll_l1_
	# http://l1ll1l1111l1_l1_.l1ll111llll1_l1_.io/l1l1ll11l_l1_/85288
	# http://l1ll1l1111l1_l1_.l1ll111llll1_l1_.io/l1111l_l1_/12899
	l1lll111_l1_ = OPENURL_CACHED(l1llll_l1_,url2,l1l11l_l1_ (u"ࠨࠩ㯣"),l1l11l_l1_ (u"ࠩࠪ㯤"),True,l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠷ࡳࡵࠩ㯥"))
	url3 = re.findall(l1l11l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㯦"),l1lll111_l1_,re.DOTALL)
	if url3: url3 = UNQUOTE(url3[0])
	else: url3 = url2
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㯧"),l1l11l_l1_ (u"࠭ࠧ㯨"),l1l11l_l1_ (u"ࠧࠨ㯩"),url3)
	l1ll1lll_l1_,l1l1lll_l1_ = [],[]
	if type==l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㯪"):
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭㯫"),url3,l1l11l_l1_ (u"ࠪࠫ㯬"),l1l11l_l1_ (u"ࠫࠬ㯭"),l1l11l_l1_ (u"ࠬ࠭㯮"),True,l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍ࠮࠴ࡱࡨࠬ㯯"))
		l1llll111_l1_ = response.content
		l11ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡣࡶࡱ࠱ࡱࡵࡡࡥࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㯰"),l1llll111_l1_,re.DOTALL)
		if l11ll111_l1_:
			l1111l_l1_ = UNQUOTE(l11ll111_l1_[0])
			l1ll1lll_l1_.append(l1111l_l1_)
			l1l1lll_l1_.append(l1l1l1l1_l1_)
			#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㯱"),l1l11l_l1_ (u"ࠩࠪ㯲"),l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㯳"),l1111l_l1_)
	elif type==l1l11l_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ㯴"):
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ㯵"),url3,l1l11l_l1_ (u"࠭ࠧ㯶"),l1l11l_l1_ (u"ࠧࠨ㯷"),l1l11l_l1_ (u"ࠨࠩ㯸"),True,l1l11l_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㯹"))
		l1llll111_l1_ = response.content
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㯺"),l1llll111_l1_,re.DOTALL)
		for l1111l_l1_,size in l1ll1111_l1_:
			if l1l1l1l1_l1_ in size:
				l1l1lll_l1_.append(size)
				l1ll1lll_l1_.append(l1111l_l1_)
				#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ㯻"),l1l11l_l1_ (u"ࠬ࠭㯼"),l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ㯽"),l1111l_l1_)
				break
		if not l1ll1lll_l1_:
			for l1111l_l1_,size in l1ll1111_l1_:
				l1l1lll_l1_.append(size)
				l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧࡕࡇࡖࡘࠬ㯾"),l1ll1lll_l1_)
	if not l1ll1lll_l1_: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ㯿"),[],[]
	return l1l11l_l1_ (u"ࠩࠪ㰀"),l1l1lll_l1_,l1ll1lll_l1_
def l11l1_l1_(url,name):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㰁"),l1l11l_l1_ (u"ࠫࠬ㰂"),url,l1ll111l1l1l_l1_)
	# http://l1ll1lllll1_l1_.l1ll1111111l_l1_.net/5cf68c23e6e79			?l1ll111l1l1l_l1_=			__1lll111llll_l1_
	# http://w.l1ll1l11_l1_.l11l1l11l1_l1_/5e14fd0a2806e			?l1ll111l1l1l_l1_=			ok.l1l1ll11l111_l1_
	#l1ll111l1l1l_l1_ = l1ll111l1l1l_l1_.replace(l1l11l_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࡣࡤ࠭㰃"),l1l11l_l1_ (u"࠭ࠧ㰄")).split(l1l11l_l1_ (u"ࠧࡠࡡࠪ㰅"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ㰆"),url,l1l11l_l1_ (u"ࠩࠪ㰇"),l1l11l_l1_ (u"ࠪࠫ㰈"),True,l1l11l_l1_ (u"ࠫࠬ㰉"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫ㰊"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l1l11l_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭㰋") in list(cookies.keys()):
		l1l1l1ll1_l1_ = cookies[l1l11l_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ㰌")]
		l1l1l1ll1_l1_ = UNQUOTE(escapeUNICODE(l1l1l1ll1_l1_))
		items = re.findall(l1l11l_l1_ (u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㰍"),l1l1l1ll1_l1_,re.DOTALL)
		url2 = items[0].replace(l1l11l_l1_ (u"ࠩ࡟࠳ࠬ㰎"),l1l11l_l1_ (u"ࠪ࠳ࠬ㰏"))
		url2 = escapeUNICODE(url2)
	else: url2 = url
	if l1l11l_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭㰐") in url2:
		id = url2.split(l1l11l_l1_ (u"ࠬࠫ࠲ࡇࠩ㰑"))[-1]
		url2 = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩ㰒")+id
		return l1l11l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㰓"),[l1l11l_l1_ (u"ࠨࠩ㰔")],[url2]
	else:
		website = WEBSITES[l1l11l_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㰕")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ㰖"),website,l1l11l_l1_ (u"ࠫࠬ㰗"),l1l11l_l1_ (u"ࠬ࠭㰘"),True,l1l11l_l1_ (u"࠭ࠧ㰙"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭㰚"))
		l1ll111l11l1_l1_ = response.url
		#l1ll111l11l1_l1_ = response.headers[l1l11l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㰛")]
		#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㰜"),l1l11l_l1_ (u"ࠪࠫ㰝"),response.url,website)
		l1lll11l1ll1_l1_ = url2.split(l1l11l_l1_ (u"ࠫ࠴࠭㰞"))[2]#.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㰟"))
		l1lll1ll1111_l1_ = l1ll111l11l1_l1_.split(l1l11l_l1_ (u"࠭࠯ࠨ㰠"))[2]#.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㰡"))
		url3 = url2.replace(l1lll11l1ll1_l1_,l1lll1ll1111_l1_)
		headers = { l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㰢"):l1l11l_l1_ (u"ࠩࠪ㰣") , l1l11l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭㰤"):l1l11l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ㰥") , l1l11l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㰦"):url3 }
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㰧"), url3, l1l11l_l1_ (u"ࠧࠨ㰨"), headers, False,l1l11l_l1_ (u"ࠨࠩ㰩"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠸ࡸࡤࠨ㰪"))
		html = response.content
		#xbmc.log(str(url3), level=xbmc.LOGERROR)
		items = re.findall(l1l11l_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㰫"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l11l_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㰬"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l11l_l1_ (u"ࠬࡂࡥ࡮ࡤࡨࡨ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㰭"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㰮"),l1l11l_l1_ (u"ࠧࠨ㰯"),str(items),html)
		if items:
			l1111l_l1_ = items[0].replace(l1l11l_l1_ (u"ࠨ࡞࠲ࠫ㰰"),l1l11l_l1_ (u"ࠩ࠲ࠫ㰱"))
			l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠪ࠳ࠬ㰲"))
			if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㰳") not in l1111l_l1_: l1111l_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ㰴") + l1111l_l1_
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ㰵"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ㰶"))
			if name==l1l11l_l1_ (u"ࠨࠩ㰷"): l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠩࠪ㰸"),[l1l11l_l1_ (u"ࠪࠫ㰹")],[l1111l_l1_]
			else: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㰺"),[l1l11l_l1_ (u"ࠬ࠭㰻")],[l1111l_l1_]
		else: l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_ = l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧ㰼"),[],[]
		return l1ll1llll111_l1_,l1l1lll_l1_,l1ll1lll_l1_
def l1l1l1l1ll11_l1_(url):
	# https://l111ll1l11l_l1_.l1l1ll1ll111_l1_.com/e/l1lll11111l1_l1_
	headers = { l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㰽") : l1l11l_l1_ (u"ࠨࠩ㰾") }
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠩࠪ㰿"),headers,l1l11l_l1_ (u"ࠪࠫ㱀"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ㱁"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㱂"),l1l11l_l1_ (u"࠭ࠧ㱃"),url,html)
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㱄"),html,re.DOTALL)
	l1l1lll_l1_,l1ll1lll_l1_,errno = [],[],l1l11l_l1_ (u"ࠨࠩ㱅")
	if items:
		for l1111l_l1_,l11ll11l111_l1_ in items:
			l1l1lll_l1_.append(l11ll11l111_l1_)
			l1ll1lll_l1_.append(l1111l_l1_)
	if len(l1ll1lll_l1_)==0: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏࠨ㱆"),[],[]
	return l1l11l_l1_ (u"ࠪࠫ㱇"),l1l1lll_l1_,l1ll1lll_l1_
def l1l1llllllll_l1_(url):
	# https://l1ll111l1lll_l1_.com/l1l11ll1l_l1_-l1ll1ll1l11l_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ㱈"),l1l11l_l1_ (u"ࠬ࠭㱉"))
	headers = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㱊") : l1l11l_l1_ (u"ࠧࠨ㱋") }
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠨࠩ㱌"),headers,l1l11l_l1_ (u"ࠩࠪ㱍"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ㱎"))
	items = re.findall(l1l11l_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ㱏"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㱐"),l1l11l_l1_ (u"࠭ࠧ㱑"),url,items[0])
	if items:
		url = items[0]+l1l11l_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ㱒")+url
		return l1l11l_l1_ (u"ࠨࠩ㱓"),[l1l11l_l1_ (u"ࠩࠪ㱔")],[url]
	else: return l1l11l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡑࡍࡑࡄࡈࠬ㱕"),[],[]
def l1l1lllll111_l1_(url):
	# https://l1lll111l11l_l1_.to/l1l11ll1l_l1_/5c83f14297d62
	url = url.strip(l1l11l_l1_ (u"ࠫ࠴࠭㱖"))
	if l1l11l_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭㱗") in url: id = url.split(l1l11l_l1_ (u"࠭࠯ࠨ㱘"))[4]
	else: id = url.split(l1l11l_l1_ (u"ࠧ࠰ࠩ㱙"))[-1]
	url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡧࡸࡺࡲࡦࡣࡰ࠲ࡹࡵ࠯ࡱ࡮ࡤࡽࡪࡸ࠿ࡧ࡫ࡧࡁࠬ㱚") + id
	headers = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㱛") : l1l11l_l1_ (u"ࠪࠫ㱜") }
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠫࠬ㱝"),headers,l1l11l_l1_ (u"ࠬ࠭㱞"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ㱟"))
	html = html.replace(l1l11l_l1_ (u"ࠧ࡝࡞ࠪ㱠"),l1l11l_l1_ (u"ࠨࠩ㱡"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㱢"),l1l11l_l1_ (u"ࠪࠫ㱣"),url,html)
	items = re.findall(l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㱤"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"ࠬ࠭㱥"),[l1l11l_l1_ (u"࠭ࠧ㱦")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡇࡘ࡚ࡒࡆࡃࡐࠫ㱧"),[],[]
def l1l1llll1111_l1_(url):
	# https://l1ll1l11ll11_l1_.net/l1l11ll1l_l1_-l1lll1ll1l1l_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ㱨"),l1l11l_l1_ (u"ࠩࠪ㱩"))
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠪࠫ㱪"),l1l11l_l1_ (u"ࠫࠬ㱫"),l1l11l_l1_ (u"ࠬ࠭㱬"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡍࡉࡕ࡚ࡂ࠯࠴ࡷࡹ࠭㱭"))
	items = re.findall(l1l11l_l1_ (u"ࠧࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠢࡵࡩࡸࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㱮"),html,re.DOTALL)
	l1l1lll_l1_,l1ll1lll_l1_ = [],[]
	for l1111l_l1_,l11ll11l111_l1_,res in items:
		l1l1lll_l1_.append(l11ll11l111_l1_+l1l11l_l1_ (u"ࠨࠢࠪ㱯")+res)
		l1ll1lll_l1_.append(l1111l_l1_)
	if len(l1ll1lll_l1_)==0: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡐ࡜ࡄࠫ㱰"),[],[]
	return l1l11l_l1_ (u"ࠪࠫ㱱"),l1l1lll_l1_,l1ll1lll_l1_
def l1ll11l11l1l_l1_(url):
	# https://l1ll1llll11l_l1_.l11l11ll1l_l1_/l1l11ll1l_l1_-l1l1llllll11_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ㱲"),l1l11l_l1_ (u"ࠬ࠭㱳"))
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"࠭ࠧ㱴"),l1l11l_l1_ (u"ࠧࠨ㱵"),l1l11l_l1_ (u"ࠨࠩ㱶"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭㱷"))
	items = re.findall(l1l11l_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲࠮ࠫࡁ࠿࠳ࡹࡪ࠾ࠣ㱸"),html,re.DOTALL)
	items = set(items)
	l1l1lll_l1_,l1ll1lll_l1_ = [],[]
	for id,mode,hash,l11ll11l111_l1_,res in items:
		url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰ࠰ࡸࡷ࠴ࡪ࡬ࡀࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠪ࡮ࡪ࠽ࠨ㱹")+id+l1l11l_l1_ (u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ㱺")+mode+l1l11l_l1_ (u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭㱻")+hash
		html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠧࠨ㱼"),l1l11l_l1_ (u"ࠨࠩ㱽"),l1l11l_l1_ (u"ࠩࠪ㱾"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧ㱿"))
		items = re.findall(l1l11l_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㲀"),html,re.DOTALL)
		for l1111l_l1_ in items:
			l1l1lll_l1_.append(l11ll11l111_l1_+l1l11l_l1_ (u"ࠬࠦࠧ㲁")+res)
			l1ll1lll_l1_.append(l1111l_l1_)
	if len(l1ll1lll_l1_)==0: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬ㲂"),[],[]
	return l1l11l_l1_ (u"ࠧࠨ㲃"),l1l1lll_l1_,l1ll1lll_l1_
def l1l1l11111ll_l1_(url):
	# https://l1l1ll11lll1_l1_.com:2053/l1l1ll1l1ll1_l1_/l1l1llll1ll1_l1_.l1lll1111111_l1_.l1lll1l11l11_l1_.1080p.l1lll111ll11_l1_.l1lll1ll1lll_l1_.l1l1l11l1l11_l1_.l11lllll_l1_.html?l1ll1l1111ll_l1_=2jpqzvpT8BbNUifWZO4QLQ&l1l1l1l1l1ll_l1_=1624070560
	# http://l1ll11ll1l1l_l1_.l1ll111111l_l1_/l1ll1111l1l1_l1_/l1l1l11lllll_l1_.l1l1l111ll1l_l1_.l1l1l1l11ll1_l1_.2018.1080p.l1l1ll111l1l_l1_-l1l1ll11l1l1_l1_.l1ll111lllll_l1_.l11lllll_l1_.html
	l1111l_l1_ = l1l11l_l1_ (u"ࠨࠩ㲄")
	if l1l11l_l1_ (u"ࠩࡎࡩࡾࡃࠧ㲅") not in url:
		url2 = url.replace(l1l11l_l1_ (u"ࠪࡹࡵࡨ࡯࡮࠰࡯࡭ࡻ࡫ࠧ㲆"),l1l11l_l1_ (u"ࠫࡺࡶࡰࡰ࡯࠱ࡰ࡮ࡼࡥࠨ㲇"))
		url2 = url2.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㲈"))
		id = url2[3]
		url2 = l1l11l_l1_ (u"࠭࠯ࠨ㲉").join(url2[0:4])
		#headers = {l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㲊"):l1ll11ll1_l1_(),l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㲋"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㲌")}
		payload = {l1l11l_l1_ (u"ࠪ࡭ࡩ࠭㲍"):id,l1l11l_l1_ (u"ࠫࡴࡶࠧ㲎"):l1l11l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨ㲏"),l1l11l_l1_ (u"࠭࡭ࡦࡶ࡫ࡳࡩࡥࡦࡳࡧࡨࠫ㲐"):l1l11l_l1_ (u"ࠧࡇࡴࡨࡩ࠰ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠫࠦ࠵ࡈࠩ࠸ࡋࠧ㲑")}
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭㲒"),url2,payload,l1l11l_l1_ (u"ࠩࠪ㲓"),l1l11l_l1_ (u"ࠪࠫ㲔"),l1l11l_l1_ (u"ࠫࠬ㲕"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠲ࡵࡷࠫ㲖"))
		if l1l11l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㲗") in list(response.headers.keys()): l1111l_l1_ = response.headers[l1l11l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㲘")]
	else:
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ㲙"),url,l1l11l_l1_ (u"ࠩࠪ㲚"),l1l11l_l1_ (u"ࠪࠫ㲛"),l1l11l_l1_ (u"ࠫࠬ㲜"),l1l11l_l1_ (u"ࠬ࠭㲝"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬ㲞"))
		if l1l11l_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㲟") in list(response.headers.keys()): l1111l_l1_ = response.headers[l1l11l_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ㲠")]
	if l1111l_l1_: return l1l11l_l1_ (u"ࠩࠪ㲡"),[l1l11l_l1_ (u"ࠪࠫ㲢")],[l1111l_l1_]
	return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬ㲣"),[],[]
def l1ll1lll11l1_l1_(url):
	# https://l111ll1l11l_l1_.l1lll1l1ll1l_l1_.com/012ocyw9li6g.html
	headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㲤") : l1l11l_l1_ (u"࠭ࠧ㲥") }
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠧࠨ㲦"),headers,l1l11l_l1_ (u"ࠨࠩ㲧"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ㲨"))
	items = re.findall(l1l11l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩ㲩"),html,re.DOTALL)
	l1l1lll_l1_,l1ll1lll_l1_ = [],[]
	if items:
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠫࡲࡶ࠴ࠨ㲪"))
		l1ll1lll_l1_.append(items[0][1])
		l1l1lll_l1_.append(l1l11l_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ㲫"))
		l1ll1lll_l1_.append(items[0][0])
		return l1l11l_l1_ (u"࠭ࠧ㲬"),l1l1lll_l1_,l1ll1lll_l1_
	else: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫ㲭"),[],[]
def l1ll1l11l11_l1_(url):
	# l1ll1lllllll_l1_ l1l1ll11ll1l_l1_			url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ㲮")
	# l1l1llll111l_l1_ .l1lll11l111l_l1_ l1l1ll11ll1l_l1_		url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡘࡷ࡯ࡖࡒࡆࡿࡥࡺࡈࡌࠫ㲯")
	# l1ll1ll1111l_l1_ l1ll11ll1l_l1_ .l11l11l1_l1_ l1l1ll11ll1l_l1_		url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡈࡨ࠵࠱ࡓ࡙ࡴࡔࡵࡑࡻࠬ㲰")
	# l1ll111ll1ll_l1_ l1l1ll11ll1l_l1_			url = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭㲱")
	# l1l1l1111l_l1_ files have l1l1llllll1l_l1_ l1111llll11_l1_		url = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࠴ࡻࡉࡘࡕࡗࡥࡖࡽࡤࡗࠧ㲲")
	# url = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ㲳")
	# url = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺ࠴ࡸ࠲ࡧ࡫࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ㲴")
	# url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡢࡦࡦ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ㲵")
	# url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ㲶")
	# url = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡱࡈࡈࡰࡰ࡯࡟ࡋ࠳࡜࡯ࠫࡧࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭࠿ࡊࡳࡱࡪࡥ࡯ࡎ࡬ࡲࡪ࡬࡯ࡳࡖ࡙ࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡡ࡯ࡦࡇ࡭ࡸࡺࡲࡪࡤࡸࡸ࡮ࡵ࡮ࡀࡵࡼࡲࡩ࡯ࡣࡢࡶ࡬ࡳࡳࡃ࠲࠸࠹࠸࠻࠺࠭㲷")
	# l111l111_l1_ l1ll111ll111_l1_ l1l1ll1l1l1l_l1_   https://l1l1lllll1ll_l1_.me/l1l1ll1lllll_l1_/l1l1l11ll111_l1_-l1l1l1lllll1_l1_-l1lll1l111l1_l1_
	id = url.split(l1l11l_l1_ (u"ࠫ࠴࠭㲸"))[-1]
	id = id.split(l1l11l_l1_ (u"ࠬࠬࠧ㲹"))[0]
	id = id.replace(l1l11l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ㲺"),l1l11l_l1_ (u"ࠧࠨ㲻"))
	#url = l1l11l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲ࡴࡱࡧࡹ࠰ࡁࡹ࡭ࡩ࡫࡯ࡠ࡫ࡧࡁࠬ㲼")+id
	#return l1l11l_l1_ (u"ࠩࠪ㲽"),[l1l11l_l1_ (u"ࠪࠫ㲾")],[url]
	url = WEBSITES[l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㲿")][0]+l1l11l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ㳀")+id
	l1l1l11ll11l_l1_,l1l1ll1l1l11_l1_,l1ll11l1ll1l_l1_,l1ll111l1111_l1_ = l1l11l_l1_ (u"࠭ࠧ㳁"),l1l11l_l1_ (u"ࠧࠨ㳂"),l1l11l_l1_ (u"ࠨࠩ㳃"),l1l11l_l1_ (u"ࠩࠪ㳄")
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠪࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡠࠬ࠲ࠧࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠮࠮ࠫࡁࠬࡨࡪ࡬ࡡࡶ࡮ࡷࡅࡺࡪࡩࡰࡖࡵࡥࡨࡱࡉ࡯ࡦࡨࡼࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫࠬࠧࠪࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡿࠧࡲࡡ࡯ࡩࡸࡥ࡬࡫ࡃࡰࡦࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡡࠧษั๋๊ࠥะัอ็ฬࠤ๏๎ส๋๊หࠫࡢ࠲࡛ࠨࠩࡠࠎࠎࠏࠉࡧࡱࡵࠤࡱࡧ࡮ࡨ࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰࡦࡴࡧࠪࠌࠌࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ฯืฬๆหࠣห้๋ๆศีหอ࠿࠭ࠬࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠭ࠏࠏࠉࠊ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡜࠲࠯࠱࠶ࡣ࠺ࠋࠋࠌࠍࠎࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡦࡦࡹࡥࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࠉࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࡠ࠶࡝ࠬࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠪࡹࡿࡰࡦ࠿ࡷࡶࡦࡩ࡫ࠧࡶ࡯ࡥࡳ࡭࠽ࠨ࠭࡯࡭ࡳࡱࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝ࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࠩ࠲ࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࠵ࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠿ࠦࡤࡢࡵ࡫࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡩࡧࡳࡩࡗࡕࡐࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡸ࠵ࠧ࠭ࠩ࠲ࡷ࡮࡭࡮ࡢࡶࡸࡶࡪ࠵ࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡮࡬ࡴࡗࡕࡐࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠧ࡭ࡺ࡭࡭࠴ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰࡭ࡲࡳࡖࡔࡏ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨࠫࠍࠍࠎࠩࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡞࠭ࡎࡇࡇࡍࡆࡀࡕࡓࡋࡀࠦ࠭࠴ࠪࡀࠫࠥ࠰࡙࡟ࡐࡆ࠿ࡖ࡙ࡇ࡚ࡉࡕࡎࡈࡗ࠱ࡍࡒࡐࡗࡓ࠱ࡎࡊ࠽ࠣࡸࡷࡸࠬ࠲ࡨࡵ࡯࡯࠶࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡ࡫ࡷࡩࡲࡹ࠺ࠡࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࠦ࠽ࠡ࡫ࡷࡩࡲࡹ࡛࠱࡟ࠦ࠯ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠦࡵࡻࡳࡩࡂࡺࡲࡢࡥ࡮ࠪࡹࡲࡡ࡯ࡩࡀࠫࠏࠏࡢ࡭ࡱࡦ࡯ࡸ࠲ࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶࠲ࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬࡼࡿࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡸࡶࡱࡥࡥ࡯ࡥࡲࡨࡪࡪ࡟ࡧ࡯ࡷࡣࡸࡺࡲࡦࡣࡰࡣࡲࡧࡰࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡤ࡬࡭ࡵࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡪࡨࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡫ࡳࡴࡠ࡮࡬ࡷࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠࡢࡰࡧࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠣࡀ࡟ࠬ࠭࡝࠻ࠌࠌࠍࠎ࡬࡭ࡵࡡ࡯࡭ࡸࡺࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠏࡦ࡮ࡶࡢ࡭ࡹࡧࡧࡴࠢࡀࠤ࡫ࡳࡴࡠ࡮࡬ࡷࡹ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠬࠨࠫࠍࠍࠎࠏࡦࡰࡴࠣ࡭ࡹ࡫࡭ࠡ࡫ࡱࠤ࡫ࡳࡴࡠ࡫ࡷࡥ࡬ࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡴࡢࡩ࠯ࡷ࡮ࢀࡥࠡ࠿ࠣ࡭ࡹ࡫࡭࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠱ࠪ࠭ࠏࠏࠉࠊࠋࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵ࡝࡬ࡸࡦ࡭࡝ࠡ࠿ࠣࡷ࡮ࢀࡥࠋࠋࡩࡳࡷࠦࡢ࡭ࡱࡦ࡯ࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡮࡬ࠠ࡯ࡱࡷࠤࡧࡲ࡯ࡤ࡭࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊ࡮࡬ࡲࡪࡹࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠮ࠪ࠭ࠏࠏࠉࡧࡱࡵࠤࡱ࡯࡮ࡦࠢ࡬ࡲࠥࡲࡩ࡯ࡧࡶ࠾ࠏࠏࠉࠊࠥࡻࡦࡲࡩ࠮࡭ࡱࡪࠬࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧ࠭࡮ࡨࡺࡪࡲ࠽ࡹࡤࡰࡧ࠳ࡒࡏࡈࡐࡒࡘࡎࡉࡅࠪࠌࠌࠍࠎࠩࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩ࡮࡬ࡲࡪ࠲࡬ࡦࡸࡨࡰࡂࡾࡢ࡮ࡥ࠱ࡐࡔࡍࡎࡐࡖࡌࡇࡊ࠯ࠊࠊࠋࠌࡰ࡮ࡴࡥࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡱ࡯࡮ࡦࠫࠍࠍࠎࠏࡤࡪࡥࡷࠤࡂࠦࡻࡾࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦ࡬ࡪࡰࡨ࠲ࡸࡶ࡬ࡪࡶࠫࠫࠫࠬࠧࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉ࡬ࡧࡼ࠰ࡻࡧ࡬ࡶࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪࡁࠬ࠲࠱ࠪࠌࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࡰ࡫ࡹ࡞ࠢࡀࠤࡻࡧ࡬ࡶࡧࠍࠍࠎࠏࡩࡧࠢࠪࡷ࡮ࢀࡥࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࠦࡡ࡯ࡦࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞ࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠏࠏࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨࡵ࡬ࡾࡪ࠭࡝ࠡ࠿ࠣࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶ࡞ࡨ࡮ࡩࡴ࡜ࠩ࡬ࡸࡦ࡭ࠧ࡞࡟ࠍࠍࠎࠏࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࡤࡪࡥࡷ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࡸ࠲ࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡧࡱࡵࡱࡦࡺࡳࠣ࠼࡟࡟࠭࠴ࠪࡀࠫ࡟ࡡࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠣ࠼࡟࡟࠭࠴ࠪࡀࠫ࡟ࡡࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡧࡱࡵࠤࡧࡲ࡯ࡤ࡭ࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠫࠬࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡁࠧ࠭ࠬࠨ࠿ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠣࠤࠪ࠰ࠬࠨࠧࠪࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠺ࡵࡴࡸࡩࠬ࠲ࠧ࠻ࡖࡵࡹࡪ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠾࡫ࡧ࡬ࡴࡧࠪ࠰ࠬࡀࡆࡢ࡮ࡶࡩࠬ࠯ࠊࠊࠋ࡬ࡪ࡛ࠥ࠭ࠨࠢࡱࡳࡹࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫࠻ࠢࡥࡰࡴࡩ࡫ࠡ࠿ࠣࠫࡠ࠭ࠫࡣ࡮ࡲࡧࡰ࠱ࠧ࡞ࠩࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡅࡗࡃࡏࠬࠬࡲࡩࡴࡶࠪ࠰ࡧࡲ࡯ࡤ࡭ࠬࠎࠎࠏࡦࡰࡴࠣࡨ࡮ࡩࡴࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭࠽ࠎࠎࠏࠉࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠ࠭ࠏࠏࠉࠊࡦ࡬ࡧࡹࡡࠧࡵࡻࡳࡩࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠾ࠩ࠯ࠫࡂࠨࠧࠪ࠭ࠪࠦࠬࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡦࡱࡵࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫ࡫ࡶࡳࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡨࡳࡷࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫࡼ࡯ࡤࡵࡪࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡸ࡯ࡺࡦࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡺ࡭ࡩࡺࡨࠨ࡟ࠬ࠯ࠬࡾࠧࠬࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫ࡭࡫ࡩࡨࡪࡷࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡩࡵࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡸࡺࡡࡳࡶࠪࡡ࠰࠭࠭ࠨ࠭ࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡦࡰࡧࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡤࡦࡺࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡳࡵࡣࡵࡸࠬࡣࠫࠨ࠯ࠪ࠯ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡩࡳࡪࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࠦࡡ࡯ࡦࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࡃ࠷࠱࠲࠴࠵࠶࠸࠹࠳࠻ࠢࡧࡩࡱࠦࡤࡪࡥࡷ࡟ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠏࠏࠉࠊࠋࡦ࡭ࡵ࡮ࡥࡳࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬࡣ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠧࠩࠬࠎࠎࠏࠉࠊࡨࡲࡶࠥ࡯ࡴࡦ࡯ࠣ࡭ࡳࠦࡣࡪࡲ࡫ࡩࡷࡀࠊࠊࠋࠌࠍࠎࡱࡥࡺ࠮ࡹࡥࡱࡻࡥࠡ࠿ࠣ࡭ࡹ࡫࡭࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠿ࠪ࠰࠶࠯ࠊࠊࠋࠌࠍࠎࡪࡩࡤࡶ࡞࡯ࡪࡿ࡝ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡻࡧ࡬ࡶࡧࠬࠎࠎࠏࠉࠤ࡫ࡩࠤࠬࡻࡲ࡭ࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡹࡷࡲࠧ࡞ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࡞ࠫࡺࡸ࡬ࠨ࡟ࠬࠎࠎࠏࠉࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸࠮ࡢࡲࡳࡩࡳࡪࠨࡥ࡫ࡦࡸ࠮ࠐࠉࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠮ࡶࡸࡷ࡫ࡡ࡮ࡵ࠳࠰ࡸࡺࡲࡦࡣࡰࡷ࠶࠲ࡳࡵࡴࡨࡥࡲࡹ࠲ࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮࡞ࡡ࠱ࡡ࡝ࠋࠋ࡬ࡪࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵ࠥࡧ࡮ࡥࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠼ࠍࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺ࠱ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠾ࠏࠏࠉࠊࡷࡵࡰ࠶ࠦ࠽ࠡࡦ࡬ࡧࡹ࠷࡛ࠨࡷࡵࡰࠬࡣ࡛࠻࠵࠳࠴ࡢࠐࠉࠊࠋࠦࡹࡷࡲ࠱ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈ࡚ࠬࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࠴࡟ࠬࡻࡲ࡭ࠩࡠ࠭࠮ࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࡨࡲࡶࠥࡪࡩࡤࡶ࠵ࠤ࡮ࡴࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸࠺ࠋࠋࠌࠍࠎࡻࡲ࡭࠴ࠣࡁࠥࡪࡩࡤࡶ࠵࡟ࠬࡻࡲ࡭ࠩࡠ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠉࠤࡷࡵࡰ࠷ࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡘࡒࡖ࡛ࡏࡕࡇࠫࡨ࡮ࡩࡴ࠳࡝ࠪࡹࡷࡲࠧ࡞ࠫࠬ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠉࡪࡨࠣࡹࡷࡲ࠱࠾࠿ࡸࡶࡱ࠸ࠠࡢࡰࡧࠤࡺࡸ࡬࠲ࠢࡱࡳࡹࠦࡩ࡯ࠢࡸࡶࡱࡥ࡬ࡪࡵࡷ࠾ࠏࠏࠉࠊࠋࠌࡹࡷࡲ࡟࡭࡫ࡶࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡻࡲ࡭࠳ࠬࠎࠎࠏࠉࠊࠋࡧ࡭ࡨࡺ࠱࠯ࡷࡳࡨࡦࡺࡥࠩࡦ࡬ࡧࡹ࠸ࠩࠋࠋࠌࠍࠎࠏࡳࡵࡴࡨࡥࡲࡹ࠰࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠷ࠩࠋࠋࡨࡰࡸ࡫࠺ࠡࡵࡷࡶࡪࡧ࡭ࡴ࠲ࠣࡁࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠰ࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶ࠏࠏࠢࠣࠤ㳅")
	# l1ll11l11l11_l1_ json data
	url2 = WEBSITES[l1l11l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㳆")][0]+l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡵࡲࡡࡺࡧࡵࠫ㳇")
	data2 = {l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡎࡪࠧ㳈"):id,l1l11l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㳉"):{l1l11l_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࠣ㳊"):{l1l11l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ㳋"):l1l11l_l1_ (u"ࠥࡅࡓࡊࡒࡐࡋࡇࠦ㳌"),l1l11l_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ㳍"):l1l11l_l1_ (u"ࠧ࠷࠶࠯࠲࠸ࠦ㳎")}}}
	data2 = str(data2)
	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㳏"),url2,data2,l1l11l_l1_ (u"ࠧࠨ㳐"),l1l11l_l1_ (u"ࠨࠩ㳑"),l1l11l_l1_ (u"ࠩࠪ㳒"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ㳓"))
	html = response.content
	#WRITE_THIS(l1l11l_l1_ (u"ࠫࠬ㳔"),html)
	l1l1l11l11l1_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ㳕"),html)
	# l1ll11l11l11_l1_ l1lll1l1ll11_l1_ & l1lll111l1l1_l1_
	l1l1lll_l1_,l1ll1lll_l1_ = [l1l11l_l1_ (u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪ㳖")],[l1l11l_l1_ (u"ࠧࠨ㳗")]
	try:
		l1lll1l1ll11_l1_ = l1l1l11l11l1_l1_[l1l11l_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪ㳘")][l1l11l_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭㳙")][l1l11l_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪ㳚")]
		for l1l1l1l1lll1_l1_ in l1lll1l1ll11_l1_:
			l1111l_l1_ = l1l1l1l1lll1_l1_[l1l11l_l1_ (u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬ㳛")]
			title = l1l1l1l1lll1_l1_[l1l11l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㳜")][l1l11l_l1_ (u"࠭ࡲࡶࡰࡶࠫ㳝")][0][l1l11l_l1_ (u"ࠧࡵࡧࡻࡸࠬ㳞")]
			l1ll1lll_l1_.append(l1111l_l1_)
			l1l1lll_l1_.append(title)
	except: pass
	if len(l1l1lll_l1_)>1:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ㳟"), l1l1lll_l1_)
		if selection==-1: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ㳠"),[],[]
		elif selection!=0:
			l1111l_l1_ = l1ll1lll_l1_[selection]+l1l11l_l1_ (u"ࠪࠪࠬ㳡")
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠫࠫ࡬࡭ࡵ࠿ࡶࡶࡻ࠸ࠦࠨ㳢"),l1l11l_l1_ (u"ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠦࠨ㳣"))
			l1l1l11ll11l_l1_ = l1111l_l1_.strip(l1l11l_l1_ (u"࠭ࠦࠨ㳤"))
	formats,l1lll1111l11_l1_,l1l1l1ll11l1_l1_,l1l1l1ll11ll_l1_,l1l1l1ll111l_l1_ = [],[],[],[],[]
	# l1ll11l11l11_l1_ l1l1l1llllll_l1_ streams
	try: l1l1ll1l1l11_l1_ = l1l1l11l11l1_l1_[l1l11l_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ㳥")][l1l11l_l1_ (u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ㳦")]
	except: pass
	# l1ll11l11l11_l1_ l1ll1ll1111l_l1_ stream
	try: l1ll11l1ll1l_l1_ = l1l1l11l11l1_l1_[l1l11l_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ㳧")][l1l11l_l1_ (u"ࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ㳨")]
	except: pass
	# l1ll11l11l11_l1_ l1lllllll1_l1_ l11lllll_l1_ streams
	try: formats = l1l1l11l11l1_l1_[l1l11l_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ㳩")][l1l11l_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭㳪")]
	except: pass
	# l1ll11l11l11_l1_ l1lllllll1_l1_ l1lll11l111l_l1_ streams
	try: l1lll1111l11_l1_ = l1l1l11l11l1_l1_[l1l11l_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭㳫")][l1l11l_l1_ (u"ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠩ㳬")]
	except: pass
	l1ll1l1l11ll_l1_ = formats+l1lll1111l11_l1_
	for dict in l1ll1l1l11ll_l1_:
		if l1l11l_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭㳭") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ㳮")] = str(dict[l1l11l_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ㳯")])
		if l1l11l_l1_ (u"ࠫ࡫ࡶࡳࠨ㳰") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠬ࡬ࡰࡴࠩ㳱")] = str(dict[l1l11l_l1_ (u"࠭ࡦࡱࡵࠪ㳲")])
		if l1l11l_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ㳳") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠨࡶࡼࡴࡪ࠭㳴")] = dict[l1l11l_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ㳵")]		#.replace(l1l11l_l1_ (u"ࠪࡁࠬ㳶"),l1l11l_l1_ (u"ࠫࡂ࠭㳷"))+l1l11l_l1_ (u"ࠬࠨࠧ㳸")
		if l1l11l_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ㳹") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫ㳺")] = str(dict[l1l11l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ㳻")])
		if l1l11l_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ㳼") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㳽")] = str(dict[l1l11l_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㳾")])
		if l1l11l_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ㳿") in list(dict.keys()): dict[l1l11l_l1_ (u"࠭ࡳࡪࡼࡨࠫ㴀")] = str(dict[l1l11l_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭㴁")])+l1l11l_l1_ (u"ࠨࡺࠪ㴂")+str(dict[l1l11l_l1_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩ㴃")])
		if l1l11l_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭㴄") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ㴅")] = dict[l1l11l_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ㴆")][l1l11l_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㴇")]+l1l11l_l1_ (u"ࠧ࠮ࠩ㴈")+dict[l1l11l_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ㴉")][l1l11l_l1_ (u"ࠩࡨࡲࡩ࠭㴊")]
		if l1l11l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ㴋") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ㴌")] = dict[l1l11l_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ㴍")][l1l11l_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㴎")]+l1l11l_l1_ (u"ࠧ࠮ࠩ㴏")+dict[l1l11l_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ㴐")][l1l11l_l1_ (u"ࠩࡨࡲࡩ࠭㴑")]
		if l1l11l_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫ㴒") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㴓")] = dict[l1l11l_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭㴔")]
		if l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㴕") in list(dict.keys()) and int(dict[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㴖")])>111222333: del dict[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㴗")]
		if l1l11l_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫ㴘") in list(dict.keys()):
			cipher = dict[l1l11l_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬ㴙")].split(l1l11l_l1_ (u"ࠫࠫ࠭㴚"))
			for item in cipher:
				key,value = item.split(l1l11l_l1_ (u"ࠬࡃࠧ㴛"),1)
				dict[key] = UNQUOTE(value)
		if l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㴜") in list(dict.keys()): dict[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㴝")] = UNQUOTE(dict[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㴞")])
		#if l1l11l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴ࠿ࠪ㴟") in dict[l1l11l_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ㴠")]: dict[l1l11l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ㴡")] = dict[l1l11l_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ㴢")].split(l1l11l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸࡃ࡜ࠣࠩ㴣"))[1].strip(l1l11l_l1_ (u"ࠧ࡝ࠤࠪ㴤"))
		#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ㴥"),dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ㴦")]+l1l11l_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣࠫ㴧")+dict[l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࠩ㴨")])
		l1l1l1ll11l1_l1_.append(dict)
	l1l1l1lll11l_l1_ = l1l11l_l1_ (u"ࠬ࠭㴩")
	if l1l11l_l1_ (u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭㴪") in html:
		#l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡺࡶࡶ࠳࡯ࡹࡢࡪࡰ࠲ࡴࡱࡧࡹࡦࡴࡢ࠲࠯ࡅࠩࠣࠩ㴫"),html,re.DOTALL)
		# /s/l11l11l1ll1_l1_/6dde7fb4/l1ll11l11111_l1_.l1ll1llll1ll_l1_/l1ll1l1ll1l1_l1_/base.l1ll1l11l111_l1_
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠰ࡵ࠲ࡴࡱࡧࡹࡦࡴ࠲ࡠࡼ࠰࠿࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠ࠰࠱࠳ࡧࡧࡳࡦ࠰࡭ࡷ࠮ࠨࠧ㴬"),html,re.DOTALL)
		if l1ll111_l1_:
			l1ll1111l11l_l1_ = WEBSITES[l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㴭")][0]+l1ll111_l1_[0]
			l1l1l1lll11l_l1_ = OPENURL_CACHED(l111l11l_l1_,l1ll1111l11l_l1_,l1l11l_l1_ (u"ࠪࠫ㴮"),l1l11l_l1_ (u"ࠫࠬ㴯"),l1l11l_l1_ (u"ࠬ࠭㴰"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ㴱"))
			import youtube_signature.cipher
			import youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1ll1l1l1lll_l1_ = cipher._load_javascript(l1l1l1lll11l_l1_)
			l1ll111111l1_l1_ = str(l1ll1l1l1lll_l1_)
	for dict in l1l1l1ll11l1_l1_:
		url = dict[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㴲")]
		if l1l11l_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡁࠬ㴳") in url or url.count(l1l11l_l1_ (u"ࠩࡶ࡭࡬ࡃࠧ㴴"))>1: l1l1l1ll11ll_l1_.append(dict)
		elif not l1l1l1lll11l_l1_ and l1l11l_l1_ (u"ࠪࡷࠬ㴵") in list(dict.keys()) and l1l11l_l1_ (u"ࠫࡸࡶࠧ㴶") in list(dict.keys()):
			l1ll1l1l1lll_l1_ = EVAL(l1l11l_l1_ (u"ࠬࡹࡴࡳࠩ㴷"),l1ll111111l1_l1_)
			json_script_engine = youtube_signature.json_script_engine.JsonScriptEngine(l1ll1l1l1lll_l1_)
			l1ll111ll1ll_l1_ = json_script_engine.execute(dict[l1l11l_l1_ (u"࠭ࡳࠨ㴸")])
			if l1ll111ll1ll_l1_!=dict[l1l11l_l1_ (u"ࠧࡴࠩ㴹")]:
				dict[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㴺")] = url+l1l11l_l1_ (u"ࠩࠩࠫ㴻")+dict[l1l11l_l1_ (u"ࠪࡷࡵ࠭㴼")]+l1l11l_l1_ (u"ࠫࡂ࠭㴽")+l1ll111ll1ll_l1_
				l1l1l1ll11ll_l1_.append(dict)
	for dict in l1l1l1ll11ll_l1_:
		l11_l1_,l1l1l111llll_l1_,l1ll1ll1l111_l1_,l1l1l1ll1l11_l1_,codecs,l1ll11l1ll1_l1_ = l1l11l_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭㴾"),l1l11l_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ㴿"),l1l11l_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ㵀"),l1l11l_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ㵁"),l1l11l_l1_ (u"ࠩࠪ㵂"),l1l11l_l1_ (u"ࠪ࠴ࠬ㵃")
		try:
			l1l1l1ll1l1l_l1_ = dict[l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࠩ㵄")]
			l1l1l1ll1l1l_l1_ = l1l1l1ll1l1l_l1_.replace(l1l11l_l1_ (u"ࠬ࠱ࠧ㵅"),l1l11l_l1_ (u"࠭ࠧ㵆"))
			items = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ㵇"),l1l1l1ll1l1l_l1_,re.DOTALL)
			l1l1l1ll1l11_l1_,l11_l1_,codecs = items[0]
			l1ll1ll111ll_l1_ = codecs.split(l1l11l_l1_ (u"ࠨ࠮ࠪ㵈"))
			l1l1l111llll_l1_ = l1l11l_l1_ (u"ࠩࠪ㵉")
			for item in l1ll1ll111ll_l1_: l1l1l111llll_l1_ += item.split(l1l11l_l1_ (u"ࠪ࠲ࠬ㵊"))[0]+l1l11l_l1_ (u"ࠫ࠱࠭㵋")
			l1l1l111llll_l1_ = l1l1l111llll_l1_.strip(l1l11l_l1_ (u"ࠬ࠲ࠧ㵌"))
			if l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㵍") in list(dict.keys()): l1ll11l1ll1_l1_ = str(float(dict[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㵎")]*10)//1024/10)+l1l11l_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㵏")
			else: l1ll11l1ll1_l1_ = l1l11l_l1_ (u"ࠩࠪ㵐")
			if l1l1l1ll1l11_l1_==l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࠨ㵑"): continue
			elif l1l11l_l1_ (u"ࠫ࠱࠭㵒") in l1l1l1ll1l1l_l1_:
				l1l1l1ll1l11_l1_ = l1l11l_l1_ (u"ࠬࡇࠫࡗࠩ㵓")
				l1ll1ll1l111_l1_ = l11_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠩ㵔")+l1ll11l1ll1_l1_+dict[l1l11l_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ㵕")].split(l1l11l_l1_ (u"ࠨࡺࠪ㵖"))[1]
			elif l1l1l1ll1l11_l1_==l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㵗"):
				l1l1l1ll1l11_l1_ = l1l11l_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ㵘")
				l1ll1ll1l111_l1_ = l1ll11l1ll1_l1_+dict[l1l11l_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ㵙")].split(l1l11l_l1_ (u"ࠬࡾࠧ㵚"))[1]+l1l11l_l1_ (u"࠭ࠠࠡࠩ㵛")+dict[l1l11l_l1_ (u"ࠧࡧࡲࡶࠫ㵜")]+l1l11l_l1_ (u"ࠨࡨࡳࡷࠬ㵝")+l1l11l_l1_ (u"ࠩࠣࠤࠬ㵞")+l11_l1_
			elif l1l1l1ll1l11_l1_==l1l11l_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ㵟"):
				l1l1l1ll1l11_l1_ = l1l11l_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ㵠")
				l1ll1ll1l111_l1_ = l1ll11l1ll1_l1_+str(int(dict[l1l11l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ㵡")])/1000)+l1l11l_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ㵢")+dict[l1l11l_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ㵣")]+l1l11l_l1_ (u"ࠨࡥ࡫ࠫ㵤")+l1l11l_l1_ (u"ࠩࠣࠤࠬ㵥")+l11_l1_
		except:
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		if l1l11l_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ㵦") in dict[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㵧")]: duration = round(0.5+float(dict[l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ㵨")].split(l1l11l_l1_ (u"࠭ࡤࡶࡴࡀࠫ㵩"),1)[1].split(l1l11l_l1_ (u"ࠧࠧࠩ㵪"),1)[0]))
		elif l1l11l_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ㵫") in list(dict.keys()): duration = round(0.5+float(dict[l1l11l_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ㵬")])/1000)
		else: duration = l1l11l_l1_ (u"ࠪ࠴ࠬ㵭")
		if l1l11l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㵮") not in list(dict.keys()): l1ll11l1ll1_l1_ = dict[l1l11l_l1_ (u"ࠬࡹࡩࡻࡧࠪ㵯")].split(l1l11l_l1_ (u"࠭ࡸࠨ㵰"))[1]
		else: l1ll11l1ll1_l1_ = dict[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㵱")]
		if l1l11l_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭㵲") not in list(dict.keys()): dict[l1l11l_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ㵳")] = l1l11l_l1_ (u"ࠪ࠴࠲࠶ࠧ㵴")
		dict[l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㵵")] = l1l1l1ll1l11_l1_+l1l11l_l1_ (u"ࠬࡀࠠࠡࠩ㵶")+l1ll1ll1l111_l1_+l1l11l_l1_ (u"࠭ࠠࠡࠪࠪ㵷")+l1l1l111llll_l1_+l1l11l_l1_ (u"ࠧ࠭ࠩ㵸")+dict[l1l11l_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭㵹")]+l1l11l_l1_ (u"ࠩࠬࠫ㵺")
		dict[l1l11l_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ㵻")] = l1ll1ll1l111_l1_.split(l1l11l_l1_ (u"ࠫࠥࠦࠧ㵼"))[0].split(l1l11l_l1_ (u"ࠬࡱࡢࡱࡵࠪ㵽"))[0]
		dict[l1l11l_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ㵾")] = l1l1l1ll1l11_l1_
		dict[l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㵿")] = l11_l1_
		dict[l1l11l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ㶀")] = codecs
		dict[l1l11l_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ㶁")] = duration
		dict[l1l11l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㶂")] = l1ll11l1ll1_l1_
		l1l1l1ll111l_l1_.append(dict)
	l1ll1l11lll1_l1_,l1ll1111ll11_l1_,l1lll11l1l11_l1_,l1lll11lll11_l1_,l1l1l111111l_l1_ = [],[],[],[],[]
	l1ll1111l111_l1_,l1l1ll11l11l_l1_,l1l1ll1l1111_l1_,l1ll1ll11111_l1_,l1lll111l1ll_l1_ = [],[],[],[],[]
	if l1l1ll1l1l11_l1_:
		dict = {}
		dict[l1l11l_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ㶃")] = l1l11l_l1_ (u"ࠬࡇࠫࡗࠩ㶄")
		dict[l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ㶅")] = l1l11l_l1_ (u"ࠧ࡮ࡲࡧࠫ㶆")
		dict[l1l11l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ㶇")] = dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㶈")]+l1l11l_l1_ (u"ࠪ࠾ࠥࠦࠧ㶉")+dict[l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㶊")]+l1l11l_l1_ (u"ࠬࠦࠠࠨ㶋")+l1l11l_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ㶌")
		dict[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㶍")] = l1l1ll1l1l11_l1_
		dict[l1l11l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ㶎")] = l1l11l_l1_ (u"ࠩ࠳ࠫ㶏") # for l1ll11l1ll_l1_ l1l1ll1l1l11_l1_ any l1l1l1111ll_l1_ will l1lll1ll111l_l1_ l1l1l1l1l11l_l1_ sort l1lll1l11l1_l1_
		dict[l1l11l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㶐")] = l1l11l_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ㶑") # 20
		l1l1l1ll111l_l1_.append(dict)
	if l1ll11l1ll1l_l1_:
		l1ll1lll111l_l1_,l1l1lll1llll_l1_ = l1ll1ll11l_l1_(l1ll11l1ll1l_l1_)
		l1ll11l1l11l_l1_ = list(zip(l1ll1lll111l_l1_,l1l1lll1llll_l1_))
		for title,l1111l_l1_ in l1ll11l1l11l_l1_:
			dict = {}
			dict[l1l11l_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ㶒")] = l1l11l_l1_ (u"࠭ࡁࠬࡘࠪ㶓")
			dict[l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㶔")] = l1l11l_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭㶕")
			dict[l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㶖")] = l1111l_l1_
			#if l1l11l_l1_ (u"ࠪࡆ࡜ࡀࠠࠨ㶗") in title: dict[l1l11l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㶘")] = title.split(l1l11l_l1_ (u"ࠬࠦࠠࠨ㶙"))[1].split(l1l11l_l1_ (u"࠭࡫ࡣࡲࡶࠫ㶚"))[0]
			#if l1l11l_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭㶛") in title: dict[l1l11l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ㶜")] = title.split(l1l11l_l1_ (u"ࠩࡕࡩࡸࡀࠠࠨ㶝"))[1]
			# title = l1l11l_l1_ (u"ࠥ࠸࠷࠼࠷࡬ࡤࡳࡷࠥࠦ࠷࠳࠲ࠣࠤ࠳ࡳ࠳ࡶ࠺ࠥ㶞")
			if l1l11l_l1_ (u"ࠫࡰࡨࡰࡴࠩ㶟") in title: dict[l1l11l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭㶠")] = title.split(l1l11l_l1_ (u"࠭࡫ࡣࡲࡶࠫ㶡"))[0].rsplit(l1l11l_l1_ (u"ࠧࠡࠢࠪ㶢"))[-1]
			else: dict[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㶣")] = l1l11l_l1_ (u"ࠩ࠴࠴ࠬ㶤")
			l1l1l1l1_l1_ = title.rsplit(l1l11l_l1_ (u"ࠪࠤࠥ࠭㶥"))[-3]
			if l1l1l1l1_l1_.isdigit(): dict[l1l11l_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ㶦")] = l1l1l1l1_l1_
			else: dict[l1l11l_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭㶧")] = l1l11l_l1_ (u"࠭࠰࠱࠲࠳ࠫ㶨")
			#dict[l1l11l_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ㶩")] = title
			if title==l1l11l_l1_ (u"ࠨ࠯࠴ࠫ㶪"): dict[l1l11l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㶫")] = dict[l1l11l_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ㶬")]+l1l11l_l1_ (u"ࠫ࠿ࠦࠠࠨ㶭")+dict[l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ㶮")]+l1l11l_l1_ (u"࠭ࠠࠡࠩ㶯")+l1l11l_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ㶰")
			else: dict[l1l11l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ㶱")] = dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㶲")]+l1l11l_l1_ (u"ࠪ࠾ࠥࠦࠧ㶳")+dict[l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㶴")]+l1l11l_l1_ (u"ࠬࠦࠠࠨ㶵")+dict[l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㶶")]+l1l11l_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㶷")+dict[l1l11l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ㶸")]
			l1l1l1ll111l_l1_.append(dict)
	l1l1l1ll111l_l1_ = sorted(l1l1l1ll111l_l1_,reverse=True,key=lambda key: float(key[l1l11l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㶹")]))
	if not l1l1l1ll111l_l1_:
		l1111111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡹࡳࡢࡩࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㶺"),html,re.DOTALL)
		l111111l11_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࡢࡻࠣࡴࡸࡲࡸࠨ࠺࡝࡝࡟ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㶻"),html,re.DOTALL)
		l1ll1l11l11l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㶼"),html,re.DOTALL)
		l1ll1l11l1l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㶽"),html,re.DOTALL)
		try: l1ll1l11l1ll_l1_ = l1l1l11l11l1_l1_[l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ㶾")][l1l11l_l1_ (u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭㶿")][l1l11l_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ㷀")][l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㷁")][l1l11l_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ㷂")][0][l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࠪ㷃")]
		except:
			try: l1ll1l11l1ll_l1_ = l1l1l11l11l1_l1_[l1l11l_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ㷄")][l1l11l_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ㷅")][l1l11l_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ㷆")][l1l11l_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ㷇")][0][l1l11l_l1_ (u"ࠪࡶࡺࡴࡳࠨ㷈")][0][l1l11l_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ㷉")]
			except: l1ll1l11l1ll_l1_ = l1l11l_l1_ (u"ࠬ࠭㷊")
		if l1111111ll_l1_ or l111111l11_l1_ or l1ll1l11l11l_l1_ or l1ll1l11l1l1_l1_ or l1ll1l11l1ll_l1_:
			if l1111111ll_l1_: message = l1111111ll_l1_[0]
			elif l111111l11_l1_: message = l111111l11_l1_[0]
			elif l1ll1l11l11l_l1_: message = l1ll1l11l11l_l1_[0]
			elif l1ll1l11l1l1_l1_: message = l1ll1l11l1l1_l1_[0]
			elif l1ll1l11l1ll_l1_: message = l1ll1l11l1ll_l1_
			l1lll11lllll_l1_ = message.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩ㷋"),l1l11l_l1_ (u"ࠧࠨ㷌")).strip(l1l11l_l1_ (u"ࠨࠢࠪ㷍"))
			l1lll11lll1l_l1_ = l1l11l_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠣ์็ี๋ࠠๅ๋๊ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣวํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์ࠧ㷎")
			DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㷏"),l1l11l_l1_ (u"ࠫࠬ㷐"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿้ࠠษ็้อืๅอࠩ㷑"),l1lll11lllll_l1_+l1l11l_l1_ (u"࠭࡜࡯࡞ࡱࠫ㷒")+l1lll11lll1l_l1_)
			return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠩ㷓")+l1lll11lllll_l1_,[],[]
		else: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㷔"),[],[]
	l1lll1l1111l_l1_,l1l1l1l11lll_l1_,l1lll1l111ll_l1_ = [],[],[]
	for dict in l1l1l1ll111l_l1_:
		if dict[l1l11l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㷕")]==l1l11l_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ㷖"):
			l1ll1l11lll1_l1_.append(dict[l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㷗")])
			l1ll1111l111_l1_.append(dict)
		elif dict[l1l11l_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ㷘")]==l1l11l_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ㷙"):
			l1ll1111ll11_l1_.append(dict[l1l11l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㷚")])
			l1l1ll11l11l_l1_.append(dict)
		elif dict[l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ㷛")]==l1l11l_l1_ (u"ࠩࡰࡴࡩ࠭㷜"):
			title = dict[l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㷝")].replace(l1l11l_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ㷞"),l1l11l_l1_ (u"ࠬ࠭㷟"))
			if l1l11l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㷠") not in list(dict.keys()): l1ll11l1ll1_l1_ = l1l11l_l1_ (u"ࠧ࠱ࠩ㷡")
			else: l1ll11l1ll1_l1_ = dict[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㷢")]
			l1lll1l1111l_l1_.append([dict,{},title,l1ll11l1ll1_l1_])
		else:
			title = dict[l1l11l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㷣")].replace(l1l11l_l1_ (u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ㷤"),l1l11l_l1_ (u"ࠫࠬ㷥"))
			if l1l11l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭㷦") not in list(dict.keys()): l1ll11l1ll1_l1_ = l1l11l_l1_ (u"࠭࠰ࠨ㷧")
			else: l1ll11l1ll1_l1_ = dict[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㷨")]
			l1lll1l1111l_l1_.append([dict,{},title,l1ll11l1ll1_l1_])
			l1lll11l1l11_l1_.append(title)
			l1l1ll1l1111_l1_.append(dict)
		l1ll11ll1lll_l1_ = True
		if l1l11l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ㷩") in list(dict.keys()):
			if l1l11l_l1_ (u"ࠩࡤࡺ࠵࠭㷪") in dict[l1l11l_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ㷫")]: l1ll11ll1lll_l1_ = False
			elif kodi_version<18:
				if l1l11l_l1_ (u"ࠫࡦࡼࡣࠨ㷬") not in dict[l1l11l_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ㷭")] and l1l11l_l1_ (u"࠭࡭ࡱ࠶ࡤࠫ㷮") not in dict[l1l11l_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ㷯")]: l1ll11ll1lll_l1_ = False
		if dict[l1l11l_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ㷰")]==l1l11l_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ㷱") and dict[l1l11l_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ㷲")]!=l1l11l_l1_ (u"ࠫ࠵࠳࠰ࠨ㷳") and l1ll11ll1lll_l1_==True:
			l1l1l111111l_l1_.append(dict[l1l11l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㷴")])
			l1lll111l1ll_l1_.append(dict)
		elif dict[l1l11l_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ㷵")]==l1l11l_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭㷶") and dict[l1l11l_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭㷷")]!=l1l11l_l1_ (u"ࠩ࠳࠱࠵࠭㷸") and l1ll11ll1lll_l1_==True:
			l1lll11lll11_l1_.append(dict[l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㷹")])
			l1ll1ll11111_l1_.append(dict)
		#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ㷺"),l1l11l_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ㷻")+dict[l1l11l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭㷼")])
	for l1ll111lll1l_l1_ in l1ll1ll11111_l1_:
		l1lll1l1l111_l1_ = l1ll111lll1l_l1_[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㷽")]
		for l1ll1l111lll_l1_ in l1lll111l1ll_l1_:
			l1lll1ll1l11_l1_ = l1ll1l111lll_l1_[l1l11l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㷾")]
			l1ll11l1ll1_l1_ = l1lll1ll1l11_l1_+l1lll1l1l111_l1_
			title = l1ll1l111lll_l1_[l1l11l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㷿")].replace(l1l11l_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬ㸀"),l1l11l_l1_ (u"ࠫࡲࡶࡤࠡࠢࠪ㸁"))
			title = title.replace(l1ll1l111lll_l1_[l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ㸂")]+l1l11l_l1_ (u"࠭ࠠࠡࠩ㸃"),l1l11l_l1_ (u"ࠧࠨ㸄"))
			title = title.replace(str((float(l1lll1ll1l11_l1_*10)//1024/10))+l1l11l_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭㸅"),str((float(l1ll11l1ll1_l1_*10)//1024/10))+l1l11l_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ㸆"))
			title = title+l1l11l_l1_ (u"ࠪࠬࠬ㸇")+l1ll111lll1l_l1_[l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㸈")].split(l1l11l_l1_ (u"ࠬ࠮ࠧ㸉"),1)[1]
			l1lll1l1111l_l1_.append([l1ll1l111lll_l1_,l1ll111lll1l_l1_,title,l1ll11l1ll1_l1_])
	l1lll1l1111l_l1_ = sorted(l1lll1l1111l_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1ll1l111lll_l1_,l1ll111lll1l_l1_,title,l1ll11l1ll1_l1_ in l1lll1l1111l_l1_:
		l1ll1l1l1l1l_l1_ = l1ll1l111lll_l1_[l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ㸊")]
		if l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㸋") in list(l1ll111lll1l_l1_.keys()):
			l1ll1l1l1l1l_l1_ = l1l11l_l1_ (u"ࠨ࡯ࡳࡨࠬ㸌")
			#l1ll1l1l1l1l_l1_ = l1ll1l1l1l1l_l1_+l1ll111lll1l_l1_[l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ㸍")]
		if l1ll1l1l1l1l_l1_ not in l1lll1l111ll_l1_:
			l1lll1l111ll_l1_.append(l1ll1l1l1l1l_l1_)
			l1l1l1l11lll_l1_.append([l1ll1l111lll_l1_,l1ll111lll1l_l1_,title,l1ll11l1ll1_l1_])
			#LOG_THIS(l1l11l_l1_ (u"ࠪࠫ㸎"),str(l1ll11l1ll1_l1_)+l1l11l_l1_ (u"ࠫࠥࠦࠠࠨ㸏")+title)
	#l1l1l1l11lll_l1_ = sorted(l1l1l1l11lll_l1_, reverse=True, key=lambda key: int(key[3]))
	l1l1l11l11ll_l1_,l1ll1lll1l11_l1_,shift = [],[],0
	l1l11l_l1_ (u"ࠧࠨࠢࠋࠋࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࡷ࡭࡯ࡦࡵࠢ࠮ࡁࠥ࠷ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ࠭ࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠳ࡠࠎࠎࠏࡳࡦ࡮ࡨࡧࡹࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡩࡨࡰ࡫ࡦࡩࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ㸐")
	l1ll11111ll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㸑"),html,re.DOTALL)
	l1l1ll1111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡣࡸࡸ࡭ࡵࡲࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ㸒"),html,re.DOTALL)
	if l1l1ll1111ll_l1_:
		owner = l1l1ll1111ll_l1_[0]
		shift += 1
		title = l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ㸓")+owner+l1l11l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㸔")
		l1111l_l1_ = WEBSITES[l1l11l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㸕")][0]+l1l11l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ㸖")+l1ll11111ll1_l1_[0]
		l1l1l11l11ll_l1_.append(title)
		l1ll1lll1l11_l1_.append(l1111l_l1_)
	#if l1l1ll1l1l11_l1_:
	#	shift += 1
	#	l1l1l11l11ll_l1_.append(l1l11l_l1_ (u"ࠬࡳࡰࡥࠢฯ์ิฯࠠัๅํอࠬ㸗")) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ㸘"))
	for l1ll1l111lll_l1_,l1ll111lll1l_l1_,title,l1ll11l1ll1_l1_ in l1l1l1l11lll_l1_:
		l1l1l11l11ll_l1_.append(title) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ㸙"))
	if l1lll11l1l11_l1_: l1l1l11l11ll_l1_.append(l1l11l_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤ๊ำฯ้ัฬࠤฬ๊ฬ้ัฬࠫ㸚")) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ㸛"))
	if l1lll1l1111l_l1_: l1l1l11l11ll_l1_.append(l1l11l_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦฬๆ์฼ࠤฬ๊ๅห๊ไีࠬ㸜")) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"ࠫࡦࡲ࡬ࠨ㸝"))
	if l1l1l111111l_l1_: l1l1l11l11ll_l1_.append(l1l11l_l1_ (u"ࠬࡳࡰࡥࠢส๊ฯࠦสฯฬสีࠥา่ะหࠣห้฻่าหࠣ์ฬ๊ี้ฬࠪ㸞")) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"࠭࡭ࡱࡦࠪ㸟"))
	if l1ll1l11lll1_l1_: l1l1l11l11ll_l1_.append(l1l11l_l1_ (u"ࠧึ๊ิอࠥ็โุࠢหำํ์ࠠึ๊อࠫ㸠")) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㸡"))
	if l1ll1111ll11_l1_: l1l1l11l11ll_l1_.append(l1l11l_l1_ (u"ุࠩ์ฯࠦแใูࠣฬิ๎ๆࠡื๋ีฮ࠭㸢")) ; l1ll1lll1l11_l1_.append(l1l11l_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ㸣"))
	l1lll11ll11l_l1_ = False
	while True:
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้๋อำษ࠼ࠪ㸤"), l1l1l11l11ll_l1_)
		if selection==-1: return l1l11l_l1_ (u"ࠬ࠭㸥"),[],[]
		if selection==0:
			l1111l_l1_ = l1ll1lll1l11_l1_[selection]
			owner = QUOTE(l1l11l_l1_ (u"࠭ࠬࠨ㸦"))+l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡜࡙࡙ࠦࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ㸧")+owner+l1l11l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㸨")
			new_path = sys.argv[0]+l1l11l_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠶ࠩࡲࡦࡳࡥ࠾ࠩ㸩")+owner+l1l11l_l1_ (u"ࠪࠪࡺࡸ࡬࠾ࠩ㸪")+l1111l_l1_
			xbmc.executebuiltin(l1l11l_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ㸫")+new_path+l1l11l_l1_ (u"ࠧ࠯ࠢ㸬"))
			return l1l11l_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ㸭"),[],[]
		choice = l1ll1lll1l11_l1_[selection]
		l1ll1l1l1111_l1_ = l1l1l11l11ll_l1_[selection]
		if choice==l1l11l_l1_ (u"ࠧࡥࡣࡶ࡬ࠬ㸮"):
			l1ll111l1111_l1_ = l1l1ll1l1l11_l1_
			break
		elif choice in [l1l11l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ㸯"),l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㸰"),l1l11l_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ㸱")]:
			if choice==l1l11l_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ㸲"): l1l1lll_l1_,l1ll11ll11ll_l1_ = l1lll11l1l11_l1_,l1l1ll1l1111_l1_
			elif choice==l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㸳"): l1l1lll_l1_,l1ll11ll11ll_l1_ = l1ll1l11lll1_l1_,l1ll1111l111_l1_
			elif choice==l1l11l_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ㸴"): l1l1lll_l1_,l1ll11ll11ll_l1_ = l1ll1111ll11_l1_,l1l1ll11l11l_l1_
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭㸵"), l1l1lll_l1_)
			if selection!=-1:
				l1ll111l1111_l1_ = l1ll11ll11ll_l1_[selection][l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㸶")]
				l1ll1l1l1111_l1_ = l1l1lll_l1_[selection]
				break
		elif choice==l1l11l_l1_ (u"ࠩࡰࡴࡩ࠭㸷"):
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ีฮࡀࠧ㸸"), l1l1l111111l_l1_)
			if selection!=-1:
				l1ll1l1l1111_l1_ = l1l1l111111l_l1_[selection]
				l1l1l11l1lll_l1_ = l1lll111l1ll_l1_[selection]
				selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࡀࠧ㸹"), l1lll11lll11_l1_)
				if selection!=-1:
					l1ll1l1l1111_l1_ += l1l11l_l1_ (u"ࠬࠦࠫࠡࠩ㸺")+l1lll11lll11_l1_[selection]
					l1ll11ll111l_l1_ = l1ll1ll11111_l1_[selection]
					l1lll11ll11l_l1_ = True
					break
		elif choice==l1l11l_l1_ (u"࠭ࡡ࡭࡮ࠪ㸻"):
			l1l1ll1llll1_l1_,l1l11lllll11_l1_,l1l1l11111l1_l1_,l1lll11l1l1l_l1_ = list(zip(*l1lll1l1111l_l1_))
			selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭㸼"), l1l1l11111l1_l1_)
			if selection!=-1:
				l1ll1l1l1111_l1_ = l1l1l11111l1_l1_[selection]
				l1l1l11l1lll_l1_ = l1l1ll1llll1_l1_[selection]
				if l1l11l_l1_ (u"ࠨ࡯ࡳࡨࠬ㸽") in l1l1l11111l1_l1_[selection] and l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㸾")]!=l1l1ll1l1l11_l1_:
					l1ll11ll111l_l1_ = l1l11lllll11_l1_[selection]
					l1lll11ll11l_l1_ = True
				else: l1ll111l1111_l1_ = l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ㸿")]
				break
		elif choice==l1l11l_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ㹀"):
			#shift += 1
			l1l1ll1llll1_l1_,l1l11lllll11_l1_,l1l1l11111l1_l1_,l1lll11l1l1l_l1_ = list(zip(*l1l1l1l11lll_l1_))
			l1l1l11l1lll_l1_ = l1l1ll1llll1_l1_[selection-shift]
			if l1l11l_l1_ (u"ࠬࡳࡰࡥࠩ㹁") in l1l1l11111l1_l1_[selection-shift] and l1l1l11l1lll_l1_[l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ㹂")]!=l1l1ll1l1l11_l1_:
				l1ll11ll111l_l1_ = l1l11lllll11_l1_[selection-shift]
				l1lll11ll11l_l1_ = True
			else: l1ll111l1111_l1_ = l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ㹃")]
			l1ll1l1l1111_l1_ = l1l1l11111l1_l1_[selection-shift]
			break
	if not l1lll11ll11l_l1_: l1l1llll11ll_l1_ = l1ll111l1111_l1_
	else: l1l1llll11ll_l1_ = l1l11l_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠩ㹄")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭㹅")]+l1l11l_l1_ (u"ࠪࠤ࠰ࠦࡁࡶࡦ࡬ࡳ࠿ࠦࠧ㹆")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㹇")]
	if l1lll11ll11l_l1_:
		#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭㹈"),l1l11l_l1_ (u"࠭ࠫࠬ࠭࠮࠯࠰࠱ࠠࠡࠢࠪ㹉")+str(l1l1l11l1lll_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠧࠨ㹊"),l1l11l_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ㹋")+str(l1ll11ll111l_l1_))
		#if l1lll1111lll_l1_>l1ll111111ll_l1_: duration = str(l1lll1111lll_l1_)
		#else: duration = str(l1ll111111ll_l1_)
		#duration = str(l1lll1111lll_l1_) if l1lll1111lll_l1_>l1ll111111ll_l1_ else str(l1ll111111ll_l1_)
		l1lll1111lll_l1_ = int(l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ㹌")])
		l1ll111111ll_l1_ = int(l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ㹍")])
		duration = str(max(l1lll1111lll_l1_,l1ll111111ll_l1_))
		l1l1ll111ll1_l1_ = l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ㹎")].replace(l1l11l_l1_ (u"ࠬࠬࠧ㹏"),l1l11l_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ㹐"))		# +l1l11l_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠴࠵࠶࠰࠱࠲࠳ࠫ㹑")
		l1ll1111ll1l_l1_ = l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ㹒")].replace(l1l11l_l1_ (u"ࠩࠩࠫ㹓"),l1l11l_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ㹔"))		# +l1l11l_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ㹕")
		l1lll11l111l_l1_ = l1l11l_l1_ (u"ࠬࡂ࠿ࡹ࡯࡯ࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨ࠱࠯࠲ࠥࠤࡪࡴࡣࡰࡦ࡬ࡲ࡬ࡃࠢࡖࡖࡉ࠱࠽ࠨ࠿࠿࡞ࡱࠫ㹖")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"࠭࠼ࡎࡒࡇࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡸ࡯࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠸࠰࠱࠳࠲࡜ࡒࡒࡓࡤࡪࡨࡱࡦ࠳ࡩ࡯ࡵࡷࡥࡳࡩࡥࠣࠢࡻࡱࡱࡴࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠦࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡲࡩ࡯࡭ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠳࠼࠽࠾࠵ࡸ࡭࡫ࡱ࡯ࠧࠦࡸࡴ࡫࠽ࡷࡨ࡮ࡥ࡮ࡣࡏࡳࡨࡧࡴࡪࡱࡱࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠠࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡲࡩࡧࡲࡥࡵ࠱࡭ࡸࡵ࠮ࡰࡴࡪ࠳࡮ࡺࡴࡧ࠱ࡓࡹࡧࡲࡩࡤ࡮ࡼࡅࡻࡧࡩ࡭ࡣࡥࡰࡪ࡙ࡴࡢࡰࡧࡥࡷࡪࡳ࠰ࡏࡓࡉࡌ࠳ࡄࡂࡕࡋࡣࡸࡩࡨࡦ࡯ࡤࡣ࡫࡯࡬ࡦࡵ࠲ࡈࡆ࡙ࡈ࠮ࡏࡓࡈ࠳ࡾࡳࡥࠤࠣࡱ࡮ࡴࡂࡶࡨࡩࡩࡷ࡚ࡩ࡮ࡧࡀࠦࡕ࡚࠱࠯࠷ࡖࠦࠥࡳࡥࡥ࡫ࡤࡔࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡆࡸࡶࡦࡺࡩࡰࡰࡀࠦࡕ࡚ࠧ㹗")+duration+l1l11l_l1_ (u"ࠧࡔࠤࠣࡸࡾࡶࡥ࠾ࠤࡶࡸࡦࡺࡩࡤࠤࠣࡴࡷࡵࡦࡪ࡮ࡨࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡰࡳࡱࡩ࡭ࡱ࡫࠺ࡪࡵࡲࡪ࡫࠳࡭ࡢ࡫ࡱ࠾࠷࠶࠱࠲ࠤࡁࡠࡳ࠭㹘")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠨ࠾ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ㹙")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠱ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡶࡪࡦࡨࡳ࠴࠭㹚")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ㹛")]+l1l11l_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ㹜")		# l1ll111l1ll1_l1_=l1l11l_l1_ (u"ࠧ࠷ࠢ㹝") l1lll111lll1_l1_=l1l11l_l1_ (u"ࠨࡴࡳࡷࡨࠦ㹞") default=l1l11l_l1_ (u"ࠢࡵࡴࡸࡩࠧ㹟")>\n
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭㹠")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ㹡")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ㹢")]+l1l11l_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ㹣")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ㹤")]+l1l11l_l1_ (u"࠭ࠢࠡࡵࡷࡥࡷࡺࡗࡪࡶ࡫ࡗࡆࡖ࠽ࠣ࠳ࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣࠩ㹥")+str(l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㹦")])+l1l11l_l1_ (u"ࠨࠤࠣࡻ࡮ࡪࡴࡩ࠿ࠥࠫ㹧")+str(l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ㹨")])+l1l11l_l1_ (u"ࠪࠦࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠧ㹩")+str(l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ㹪")])+l1l11l_l1_ (u"ࠬࠨࠠࡧࡴࡤࡱࡪࡘࡡࡵࡧࡀࠦࠬ㹫")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"࠭ࡦࡱࡵࠪ㹬")]+l1l11l_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ㹭")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ㹮")+l1l1ll111ll1_l1_+l1l11l_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ㹯")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ㹰")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ㹱")]+l1l11l_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ㹲")	# l1lll1l1lll1_l1_=l1l11l_l1_ (u"ࠨࡴࡳࡷࡨࠦ㹳")>\n
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ㹴")+l1l1l11l1lll_l1_[l1l11l_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭㹵")]+l1l11l_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ㹶")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭㹷")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ㹸")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ㹹")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠶ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡥࡺࡪࡩࡰ࠱ࠪ㹺")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㹻")]+l1l11l_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ㹼")		# l1ll111l1ll1_l1_=l1l11l_l1_ (u"ࠤ࠴ࠦ㹽") l1lll111lll1_l1_=l1l11l_l1_ (u"ࠥࡸࡷࡻࡥࠣ㹾") default=l1l11l_l1_ (u"ࠦࡹࡸࡵࡦࠤ㹿")>\n
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ㺀")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭㺁")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ㺂")]+l1l11l_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ㺃")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ㺄")]+l1l11l_l1_ (u"ࠪࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤ࠴࠷࠵࠺࠷࠶ࠤࡁࡠࡳ࠭㺅")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠫࡁࡇࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡇࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼࠵࠷࠵࠶࠳࠻࠵࠽ࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢࡧࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠪ㺆")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭㺇")]+l1l11l_l1_ (u"࠭ࠢ࠰ࡀ࡟ࡲࠬ㺈")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ㺉")+l1ll1111ll1l_l1_+l1l11l_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ㺊")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ㺋")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ㺌")]+l1l11l_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ㺍")	# l1lll1l1lll1_l1_=l1l11l_l1_ (u"ࠧࡺࡲࡶࡧࠥ㺎")>\n
		l1lll11l111l_l1_ += l1l11l_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ㺏")+l1ll11ll111l_l1_[l1l11l_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ㺐")]+l1l11l_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ㺑")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ㺒")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ㺓")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ㺔")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"ࠬࡂ࠯ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪ㺕")
		l1lll11l111l_l1_ += l1l11l_l1_ (u"࠭࠼࠰ࡏࡓࡈࡃࡢ࡮ࠨ㺖")
		#open(l1l11l_l1_ (u"ࠧࡴ࠼࡟ࡠࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㺗"),l1l11l_l1_ (u"ࠨࡹࡥࠫ㺘")).write(l1lll11l111l_l1_)
		#LOG_THIS(l1l11l_l1_ (u"ࠩࠪ㺙"),l1lll11l111l_l1_)
		#l1lll11l111l_l1_ = OPENURL_CACHED(NO_CACHE,l1l1ll1l1l11_l1_,l1l11l_l1_ (u"ࠪࠫ㺚"),l1l11l_l1_ (u"ࠫࠬ㺛"),l1l11l_l1_ (u"ࠬ࠭㺜"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠽ࡹ࡮ࠧ㺝"))
		if kodi_version>18.99:
			import http.server as l1ll11lllll1_l1_
			import http.client as l1l1l111lll1_l1_
		else:
			import BaseHTTPServer as l1ll11lllll1_l1_
			import httplib as l1l1l111lll1_l1_
		class l1ll1l111l11_l1_(l1ll11lllll1_l1_.HTTPServer):
			#l1lll11l111l_l1_ = l1l11l_l1_ (u"ࠧ࠽ࡀࠪ㺞")
			def __init__(self,l11l11ll11l_l1_=l1l11l_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫ㺟"),port=55055,l1lll11l111l_l1_=l1l11l_l1_ (u"ࠩ࠿ࡂࠬ㺠")):
				self.l11l11ll11l_l1_ = l11l11ll11l_l1_
				self.port = port
				self.l1lll11l111l_l1_ = l1lll11l111l_l1_
				l1ll11lllll1_l1_.HTTPServer.__init__(self,(self.l11l11ll11l_l1_,self.port),l1l11llll1ll_l1_)
				self.l1ll11l1ll11_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ㺡")+l11l11ll11l_l1_+l1l11l_l1_ (u"ࠫ࠿࠭㺢")+str(port)+l1l11l_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ㺣")
				#print(l1l11l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡴࠥࡴ࡯ࡸࠢ࡯࡭ࡸࡺࡥ࡯࡫ࡱ࡫ࠥࡵ࡮ࠡࡲࡲࡶࡹࡀࠠࠨ㺤")+str(port))
			def start(self):
				self.threads = l1l1ll1l111_l1_(False)
				self.threads.start_new_thread(1,self.l1l1lll1ll11_l1_)
			def l1l1lll1ll11_l1_(self):
				#print(l1l11l_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡧࡲࡵࡧࡧࠫ㺥"))
				self.l1l1l11ll1l1_l1_ = True
				#l1lll1l1l11_l1_ = 0
				while self.l1l1l11ll1l1_l1_:
					#l1lll1l1l11_l1_ += 1
					#print(l1l11l_l1_ (u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠢࡤࠤࡸ࡯࡮ࡨ࡮ࡨࠤ࡭ࡧ࡮ࡥ࡮ࡨࡣࡷ࡫ࡱࡶࡧࡶࡸ࠭࠯ࠠ࡯ࡱࡺ࠾ࠥ࠭㺦")+str(l1lll1l1l11_l1_)+l1l11l_l1_ (u"ࠩࠪ㺧"))
					#settimeout l1l11l1l1l_l1_ not l1l1l11l11_l1_ l1l1lllll1l1_l1_ to error message if it l1lll111ll1l_l1_ l1l1l1ll1lll_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l1l1lll1ll11_l1_ l1ll1111lll1_l1_ request l1ll111l111l_l1_ 60 seconds)
					self.handle_request()
				#print(l1l11l_l1_ (u"ࠪࡷࡪࡸࡶࡪࡰࡪࠤࡷ࡫ࡱࡶࡧࡶࡸࡸࠦࡳࡵࡱࡳࡴࡪࡪ࡜࡯ࠩ㺨"))
			def stop(self):
				self.l1l1l11ll1l1_l1_ = False
				self.l1ll11llllll_l1_()	# needed to l1ll1ll11l1l_l1_ self.handle_request() to l1l1lll1ll11_l1_ l1l1l11ll11_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l1l11l_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠࡥࡱࡺࡲࠥࡴ࡯ࡸ࡞ࡱࠫ㺩"))
			def load(self,l1lll11l111l_l1_):
				self.l1lll11l111l_l1_ = l1lll11l111l_l1_
			def l1ll11llllll_l1_(self):
				conn = l1l1l111lll1_l1_.HTTPConnection(self.l11l11ll11l_l1_+l1l11l_l1_ (u"ࠬࡀࠧ㺪")+str(self.port))
				conn.request(l1l11l_l1_ (u"ࠨࡈࡆࡃࡇࠦ㺫"), l1l11l_l1_ (u"ࠢ࠰ࠤ㺬"))
		class l1l11llll1ll_l1_(l1ll11lllll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l1l11l_l1_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡈࡇࡗࠤࠥ࠭㺭")+self.path)
				self.send_response(200)
				self.send_header(l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ㺮"),l1l11l_l1_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ㺯"))
				self.end_headers()
				#self.wfile.write(self.path+l1l11l_l1_ (u"ࠫࡡࡴࠧ㺰"))
				self.wfile.write(self.server.l1lll11l111l_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㺱")))
				time.sleep(1)
				if self.path==l1l11l_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ㺲"): self.server.shutdown()
				if self.path==l1l11l_l1_ (u"ࠧ࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ㺳"): self.server.shutdown()
			def do_HEAD(self):
				#print(l1l11l_l1_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡉࡇࡄࡈࠥࠦࠧ㺴")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1ll1l111l11_l1_(l1l11l_l1_ (u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ㺵"),55055,l1lll11l111l_l1_)
		#httpd.load(l1lll11l111l_l1_)
		l1ll111l1111_l1_ = httpd.l1ll11l1ll11_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1ll111l1111_l1_ = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱ࡯ࡶࡦࡵ࡬ࡱ࠳ࡪࡡࡴࡪ࡬ࡪ࠳ࡵࡲࡨ࠱࡯࡭ࡻ࡫ࡳࡪ࡯࠲ࡧ࡭ࡻ࡮࡬ࡦࡸࡶࡤ࠷࠯ࡢࡶࡲࡣ࠼࠵ࡴࡦࡵࡷࡴ࡮ࡩ࠴ࡠ࠺ࡶ࠳ࡒࡧ࡮ࡪࡨࡨࡷࡹ࠴࡭ࡱࡦࠪ㺶")
		#l1ll111l1111_l1_ = l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡡࡴࡪ࠱ࡥࡰࡧ࡭ࡢ࡫ࡽࡩࡩ࠴࡮ࡦࡶ࠲ࡨࡦࡹࡨ࠳࠸࠷࠳࡙࡫ࡳࡵࡅࡤࡷࡪࡹ࠯࠳ࡥ࠲ࡵࡺࡧ࡬ࡤࡱࡰࡱ࠴࠷࠯ࡎࡷ࡯ࡸ࡮ࡘࡥࡴࡏࡓࡉࡌ࠸࠮࡮ࡲࡧࠫ㺷")
		#l1ll111l1111_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡵࡵ࡬࠲ࡹ࡫࡬ࡦࡥࡲࡱ࠲ࡶࡡࡳ࡫ࡶࡸࡪࡩࡨ࠯ࡨࡵ࠳࡬ࡶࡡࡤ࠱ࡇࡅࡘࡎ࡟ࡄࡑࡑࡊࡔࡘࡍࡂࡐࡆࡉ࠴࡚ࡥ࡭ࡧࡦࡳࡲࡖࡡࡳ࡫ࡶࡘࡪࡩࡨ࠰࡯ࡳ࠸࠲ࡲࡩࡷࡧ࠲ࡱࡵ࠺࠭࡭࡫ࡹࡩ࠲ࡳࡰࡥ࠯ࡄ࡚࠲ࡈࡓ࠯࡯ࡳࡨࠬ㺸")
		#l1ll111l1111_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡲࡥ࡯ࡨࡨ࡮ࡧ࠮ࡣࡤࡦ࠲ࡨࡵ࠮ࡶ࡭࠲ࡨࡦࡹࡨ࠰ࡱࡱࡨࡪࡳࡡ࡯ࡦ࠲ࡸࡪࡹࡴࡤࡣࡵࡨ࠴࠷࠯ࡤ࡮࡬ࡩࡳࡺ࡟࡮ࡣࡱ࡭࡫࡫ࡳࡵ࠯ࡨࡺࡪࡴࡴࡴ࠯ࡰࡹࡱࡺࡩ࡭ࡣࡱ࡫࠳ࡳࡰࡥࠩ㺹")
		#l1ll111l1111_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ㺺")
	else: httpd = l1l11l_l1_ (u"ࠨࠩ㺻")
	if not l1ll111l1111_l1_: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ㺼"),[],[]
	return l1l11l_l1_ (u"ࠪࠫ㺽"),[l1l11l_l1_ (u"ࠫࠬ㺾")],[[l1ll111l1111_l1_,l1l1l11ll11l_l1_,httpd]]
def l1ll11l1l1l1_l1_(url):
	# https://l1ll1l1l1ll1_l1_.com/l1ll11111111_l1_
	headers = { l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㺿") : l1l11l_l1_ (u"࠭ࠧ㻀") }
	#url = url.replace(l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㻁"),l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ㻂"))
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠩࠪ㻃"),headers,l1l11l_l1_ (u"ࠪࠫ㻄"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡆࡔࡈ࠭࠲ࡵࡷࠫ㻅"))
	items = re.findall(l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࢁ࠯࡜ࡾࠩ㻆"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1ll1lll111l_l1_,l1l1lll_l1_,l1l1lll1llll_l1_,l1ll1lll_l1_ = [],[],[],[]
	if items:
		for l1111l_l1_,dummy,l11ll11l111_l1_ in items:
			l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㻇"),l1l11l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㻈"))
			if l1l11l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㻉") in l1111l_l1_:
				l1ll1lll111l_l1_,l1l1lll1llll_l1_ = l1ll1ll11l_l1_(l1111l_l1_)
				#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㻊"),l1l11l_l1_ (u"ࠪࠫ㻋"),str(l1ll1lll_l1_),str(l1l1lll1llll_l1_))
				l1ll1lll_l1_ = l1ll1lll_l1_ + l1l1lll1llll_l1_
				if l1ll1lll111l_l1_[0]==l1l11l_l1_ (u"ࠫ࠲࠷ࠧ㻌"): l1l1lll_l1_.append(l1l11l_l1_ (u"ู๊ࠬาใิࠤำอีࠨ㻍")+l1l11l_l1_ (u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧ㻎"))
				else:
					for title in l1ll1lll111l_l1_:
						l1l1lll_l1_.append(l1l11l_l1_ (u"ࠧิ์ิๅึࠦฮศืࠪ㻏")+l1l11l_l1_ (u"ࠨࠢࠣࠤࠬ㻐")+title)
			else:
				title = l1l11l_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ㻑")+l1l11l_l1_ (u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭㻒")+l11ll11l111_l1_
				l1ll1lll_l1_.append(l1111l_l1_)
				l1l1lll_l1_.append(title)
		return l1l11l_l1_ (u"ࠫࠬ㻓"),l1l1lll_l1_,l1ll1lll_l1_
	else: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡆࡔࡈࠧ㻔"),[],[]
def	l1l1ll1l1lll_l1_(url):
	# https://l1ll1lll1111_l1_.cc/l1l11ll1l_l1_-1qrpoobdg7bu.html
	# https://l1ll1l111111_l1_.cc//l1l11ll1l_l1_-l1l1ll1lll1l_l1_.html
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㻕"),url,l1l11l_l1_ (u"ࠧࠨ㻖"),l1l11l_l1_ (u"ࠨࠩ㻗"),l1l11l_l1_ (u"ࠩࠪ㻘"),l1l11l_l1_ (u"ࠪࠫ㻙"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡘࡌࡈࡊࡕࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ㻚"))
	html = response.content
	l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㻛"),html,re.DOTALL)
	if l1ll1111_l1_:
		l1111l_l1_ = l1ll1111_l1_[0]
		return l1l11l_l1_ (u"࠭ࠧ㻜"),[l1l11l_l1_ (u"ࠧࠨ㻝")],[l1111l_l1_]
	return l1l11l_l1_ (u"ࠨࠩ㻞"),[],[]
def	l1l1l1ll1111_l1_(url):
	# https://l1l1l11l111l_l1_.in/l1lll11llll1_l1_
	# https://l1l1l11l111l_l1_.in/l1l11ll1l_l1_-l1lll11llll1_l1_.html
	# https://l1lll1111ll1_l1_.fun/l1ll1111llll_l1_
	# https://l1lll1111ll1_l1_.fun/l1l11ll1l_l1_-l1ll1111llll_l1_.html
	# https://l111ll1l11l_l1_.l1ll11llll1l_l1_.com/l1l11ll1l_l1_-l1lll1l1l1l1_l1_.html
	url = url.replace(l1l11l_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ㻟"),l1l11l_l1_ (u"ࠪࠫ㻠")).replace(l1l11l_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ㻡"),l1l11l_l1_ (u"ࠬ࠭㻢"))
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㻣"),url,l1l11l_l1_ (u"ࠧࠨ㻤"),l1l11l_l1_ (u"ࠨࠩ㻥"),l1l11l_l1_ (u"ࠩࠪ㻦"),l1l11l_l1_ (u"ࠪࠫ㻧"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ㻨"))
	html = response.content
	l11ll11ll11_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩ࡝ࠫࠬࠫ㻩"),html,re.DOTALL)
	if l11ll11ll11_l1_:
		l11ll11ll11_l1_ = l11ll11ll11_l1_[0]
		l11l1111l1l_l1_ = l11l11llll1_l1_(l11ll11ll11_l1_)
		l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㻪"),l11l1111l1l_l1_,re.DOTALL)
		if not l1ll1111_l1_: l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠩࡾࠩ㻫"),l11l1111l1l_l1_,re.DOTALL)
		l1l1lll_l1_,l1ll1lll_l1_ = [],[]
		for l1111l_l1_,title in l1ll1111_l1_:
			if not title: title = l1111l_l1_.rsplit(l1l11l_l1_ (u"ࠨ࠰ࠪ㻬"),1)[1]
			l1l1lll_l1_.append(title)
			l1ll1lll_l1_.append(l1111l_l1_)
		return l1l11l_l1_ (u"ࠩࠪ㻭"),l1l1lll_l1_,l1ll1lll_l1_
	id = url.split(l1l11l_l1_ (u"ࠪ࠳ࠬ㻮"))[3]
	headers = { l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㻯"):l1l11l_l1_ (u"ࠬ࠭㻰") , l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㻱"):l1l11l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㻲") }
	payload = { l1l11l_l1_ (u"ࠨ࡫ࡧࠫ㻳"):id , l1l11l_l1_ (u"ࠩࡲࡴࠬ㻴"):l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭㻵") }
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㻶"),url,payload,headers,l1l11l_l1_ (u"ࠬ࠭㻷"),l1l11l_l1_ (u"࠭ࠧ㻸"),l1l11l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭㻹"))
	html = response.content
	items = re.findall(l1l11l_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㻺"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"ࠩࠪ㻻"),[l1l11l_l1_ (u"ࠪࠫ㻼")],[ items[0] ]
	return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋࠬ㻽"),[],[]
l1l11l_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡍࡏࡗࡋࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࠨࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡹ࡭ࡩ࠴ࡣࡰ࠱ࡹ࡭ࡩ࡫࡯࠰ࡲ࡯ࡥࡾ࠵ࡁࡂࡘࡈࡒࡩࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠥ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࠤ࠿ࠦࠧࠨࠢࢀࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑ࡙ࡍࡉ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞ࠌࠌ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡫ࡷࡩࡲࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡦࠡࠩ࠱ࡱ࠸ࡻ࠸ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎ࡯ࡦࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࡜࠲ࡠࡁࡂ࠭࠭࠲ࠩ࠽ࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࠨีํีๆืࠠฯษุࠫ࠰࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧࠪࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶ࠺ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪื๏ืแาࠢัหฺ࠭ࠫࠨࠢࠣࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤู๊ࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭ࡱ࠶ࠪࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠢࠪࠫ࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡺࡵࡳࡰࠣࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡘࡌࡈࠬ࠲࡛࡞࠮࡞ࡡࠏࠏࠣࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠵ࡲ࠴ࡧࡰࡸ࡬ࡨ࠳ࡩ࡯࠰ࡵࡷࡶࡪࡧ࡭࠰࠴࠵࠽࠳ࡳ࠳ࡶ࠺ࠍࠦࠧࠨ㻾")
#####################################################
#    l1ll11111l1l_l1_ l1ll1ll1ll11_l1_ l1l1ll1lll11_l1_
#    16-06-2019
#####################################################
def l1l1l1lll1l1_l1_(url):
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"࠭ࠧ㻿"),l1l11l_l1_ (u"ࠧࠨ㼀"),l1l11l_l1_ (u"ࠨࠩ㼁"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ㼂"))
	items = re.findall(l1l11l_l1_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㼃"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"ࠫࠬ㼄"),[l1l11l_l1_ (u"ࠬ࠭㼅")],[ items[0] ]
	else: return l1l11l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫ㼆"),[],[]
def l1ll11l1l1ll_l1_(url):
	return l1l11l_l1_ (u"ࠧࠨ㼇"),[l1l11l_l1_ (u"ࠨࠩ㼈")],[ url ]
def l1ll1ll1llll_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ㼉"),l1l11l_l1_ (u"ࠪࠫ㼊"),url,l1l11l_l1_ (u"ࠫࠬ㼋"))
	server = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㼌"))
	basename = l1l11l_l1_ (u"࠭࠯ࠨ㼍").join(server[0:3])
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠧࠨ㼎"),l1l11l_l1_ (u"ࠨࠩ㼏"),l1l11l_l1_ (u"ࠩࠪ㼐"),l1l11l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧ㼑"))
	items = re.findall(l1l11l_l1_ (u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㼒"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㼓"),l1l11l_l1_ (u"࠭ࠧ㼔"),url,str(var))
	if items:
		l1lllllll111_l1_,l1111111l11_l1_,l1111111l1l_l1_,l1lll11l11l1_l1_,l1lll11l11ll_l1_,l1lll1l1l1ll_l1_ = items[0]
		var = int(l1111111l11_l1_) % int(l1111111l1l_l1_) + int(l1lll11l11l1_l1_) % int(l1lll11l11ll_l1_)
		url = basename + l1lllllll111_l1_ + str(var) + l1lll1l1l1ll_l1_
		return l1l11l_l1_ (u"ࠧࠨ㼕"),[l1l11l_l1_ (u"ࠨࠩ㼖")],[url]
	else: return l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅࠨ㼗"),[],[]
def l1ll11l11lll_l1_(url):
	url = url.replace(l1l11l_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ㼘"),l1l11l_l1_ (u"ࠫࠬ㼙"))
	url = url.replace(l1l11l_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ㼚"),l1l11l_l1_ (u"࠭ࠧ㼛"))
	id = url.split(l1l11l_l1_ (u"ࠧ࠰ࠩ㼜"))[-1]
	headers = { l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㼝") : l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㼞") }
	payload = { l1l11l_l1_ (u"ࠥ࡭ࡩࠨ㼟"):id , l1l11l_l1_ (u"ࠦࡴࡶࠢ㼠"):l1l11l_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠣ㼡") }
	request = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㼢"), url, payload, headers, l1l11l_l1_ (u"ࠧࠨ㼣"),l1l11l_l1_ (u"ࠨࠩ㼤"),l1l11l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡐ࠵ࡗࡓࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ㼥"))
	if l1l11l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㼦") in list(request.headers.keys()): l1111l_l1_ = request.headers[l1l11l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㼧")]
	else: l1111l_l1_ = url
	if l1111l_l1_: return l1l11l_l1_ (u"ࠬ࠭㼨"),[l1l11l_l1_ (u"࠭ࠧ㼩")],[l1111l_l1_]
	else: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬ㼪"),[],[]
def l1l11llllll1_l1_(url):
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠨࠩ㼫"),l1l11l_l1_ (u"ࠩࠪ㼬"),l1l11l_l1_ (u"ࠪࠫ㼭"),l1l11l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡋࡑࡘ࡛ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧ㼮"))
	items = re.findall(l1l11l_l1_ (u"ࠬࡳࡰ࠵࠼ࠣࡠࡠࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ㼯"),html,re.DOTALL)
	if items: return l1l11l_l1_ (u"࠭ࠧ㼰"),[l1l11l_l1_ (u"ࠧࠨ㼱")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡎࡔࡔࡗࡎࡌ࡚ࡊ࠭㼲"),[],[]
def l1ll1lll11ll_l1_(url):
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠩࠪ㼳"),l1l11l_l1_ (u"ࠪࠫ㼴"),l1l11l_l1_ (u"ࠫࠬ㼵"),l1l11l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡇࡍࡏࡖࡆ࠯࠴ࡷࡹ࠭㼶"))
	items = re.findall(l1l11l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㼷"),html,re.DOTALL)
	#l1ll11l11ll1_l1_.l1l1l1llll1l_l1_(l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭㼸") + items[0])
	if items:
		url = url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ㼹") + items[0]
		return l1l11l_l1_ (u"ࠩࠪ㼺"),[l1l11l_l1_ (u"ࠪࠫ㼻")],[ url ]
	else: return l1l11l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡅࡋࡍ࡛ࡋࠧ㼼"),[],[]
def l1lll1ll11ll_l1_(url):
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠬ࠭㼽"),l1l11l_l1_ (u"࠭ࠧ㼾"),l1l11l_l1_ (u"ࠧࠨ㼿"),l1l11l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕ࡛ࡂࡍࡋࡆ࡚ࡎࡊࡅࡐࡊࡒࡗ࡙࠳࠱ࡴࡶࠪ㽀"))
	items = re.findall(l1l11l_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ㽁"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ㽂"),l1l11l_l1_ (u"ࠫࠬ㽃"),str(items),html)
	if items: return l1l11l_l1_ (u"ࠬ࠭㽄"),[l1l11l_l1_ (u"࠭ࠧ㽅")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓ࡙ࡇࡒࡉࡄࡘࡌࡈࡊࡕࡈࡐࡕࡗࠫ㽆"),[],[]
def l1l1l1l1ll1l_l1_(url):
	#url = url.replace(l1l11l_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ㽇"),l1l11l_l1_ (u"ࠩࠪ㽈"))
	html = OPENURL_CACHED(l111l11l_l1_,url,l1l11l_l1_ (u"ࠪࠫ㽉"),l1l11l_l1_ (u"ࠫࠬ㽊"),l1l11l_l1_ (u"ࠬ࠭㽋"),l1l11l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ㽌"))
	items = re.findall(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㽍"),html,re.DOTALL)
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㽎"),l1l11l_l1_ (u"ࠩࠪ㽏"),items[0],items[0])
	if items: return l1l11l_l1_ (u"ࠪࠫ㽐"),[l1l11l_l1_ (u"ࠫࠬ㽑")],[ items[0] ]
	else: return l1l11l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ㽒"),[],[]
l1l11l_l1_ (u"ࠨࠢࠣࠌࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠊࠤࠢࠣࠤࠥࡔࡏࡕ࡚ࠢࡓࡗࡑࡉࡏࡉࠣࡅࡓ࡟ࡍࡐࡔࡈࠎࠨࠦࠠࠡࠢ࠳࠶࠲ࡌࡅࡃ࠯࠵࠴࠷࠷ࠊࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠏࠐࠊࠋࠌࠥࠦࠧ㽓")
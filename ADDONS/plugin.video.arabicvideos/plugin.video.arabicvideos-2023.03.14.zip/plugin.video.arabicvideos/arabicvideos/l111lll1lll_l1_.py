# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ䒪")
headers = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䒫") : l1l11l_l1_ (u"ࠪࠫ䒬") }
menu_name = l1l11l_l1_ (u"ࠫࡤ࡙ࡈ࠵ࡡࠪ䒭")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ䒮"),l1l11l_l1_ (u"࠭วๅๅ็ࠫ䒯"),l1l11l_l1_ (u"ࠧศใ็ห๊࠭䒰"),l1l11l_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ䒱")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l111l1_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l111ll_l1_(url)
	elif mode==114: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ䒲")+text)
	elif mode==115: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ䒳")+text)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䒴"),l11lll_l1_,l1l11l_l1_ (u"ࠬ࠭䒵"),headers,l1l11l_l1_ (u"࠭ࠧ䒶"),l1l11l_l1_ (u"ࠧࠨ䒷"),l1l11l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䒸"))
	#if not response.succeeded:
	#	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䒹"),menu_name+l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ䒺"),l1l11l_l1_ (u"ࠫࠬ䒻"),8)
	#	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䒼"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䒽"),l1l11l_l1_ (u"ࠧࠨ䒾"),9999)
	#	return
	html = response.content
	l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䒿"),html,re.DOTALL)
	if not l1l1lll1_l1_: l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡳࡲ࡫࠭ࡴ࡫ࡷࡩ࠲ࡨࡴ࡯࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䓀"),html,re.DOTALL)
	if not l1l1lll1_l1_: l1l1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡪࡨࡥࡩ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䓁"),html,re.DOTALL)
	l1l1lll1_l1_ = l1l1lll1_l1_[0].strip(l1l11l_l1_ (u"ࠫ࠴࠭䓂"))
	l111llll1_l1_ = SERVER(l1l1lll1_l1_,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ䓃"))
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓄"),menu_name+l1l11l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䓅"),l1l11l_l1_ (u"ࠨࠩ䓆"),119,l1l11l_l1_ (u"ࠩࠪ䓇"),l1l11l_l1_ (u"ࠪࠫ䓈"),l1l11l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䓉"))
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䓊"),menu_name+l1l11l_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ䓋"),l1l1lll1_l1_,115)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓌"),menu_name+l1l11l_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ䓍"),l1l1lll1_l1_,114)
	#addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓎"),menu_name+l1l11l_l1_ (u"ࠪๅ้ะัࠨ䓏"),l1l11l_l1_ (u"ࠫࠬ䓐"),114,l111llll1_l1_)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䓑"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䓒"),l1l11l_l1_ (u"ࠧࠨ䓓"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䓔"),l1l1lll1_l1_,l1l11l_l1_ (u"ࠩࠪ䓕"),headers,l1l11l_l1_ (u"ࠪࠫ䓖"),l1l11l_l1_ (u"ࠫࠬ䓗"),l1l11l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ䓘"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡴࡧࡤࡶࡨ࡮ࠧ䓙"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䓚"),block,re.DOTALL)
	for filter,title in items:
		url = l111llll1_l1_+l1l11l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡊࡲࡱࡪ࠴ࡰࡩࡲࠪ䓛")
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓜"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䓝")+menu_name+title,url,111,l1l11l_l1_ (u"ࠫࠬ䓞"),l1l11l_l1_ (u"ࠬ࠭䓟"),filter)
	addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䓠"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䓡"),l1l11l_l1_ (u"ࠨࠩ䓢"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䓣"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䓤"),block,re.DOTALL)
	#l11llll1l_l1_ = [l1l11l_l1_ (u"ู๊ࠫไิๆสฮࠥ࠭䓥"),l1l11l_l1_ (u"ࠬอแๅษ่ࠤࠬ䓦"),l1l11l_l1_ (u"࠭ศาษ่ะࠬ䓧"),l1l11l_l1_ (u"ฺࠧำฺ๋ࠬ䓨"),l1l11l_l1_ (u"ࠨๅ็๎ออสࠨ䓩"),l1l11l_l1_ (u"ࠩส฾ฬ์้ࠨ䓪")]
	#if l1l11l_l1_ (u"ࠪหๆ๊วๆࠢ฼ีอ๐ࠧ䓫") not in str(items):
	#	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓬"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䓭")+menu_name+l1l11l_l1_ (u"࠭วโๆส้ࠥ฿ัษ์ࠪ䓮"),l111llll1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หๆ๊วๆ࠯฼ีอ๐࠭࠲ࠩ䓯"),111)
	for l1111l_l1_,title in items:
		if title in l1llll1_l1_: continue
		if l1l11l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䓰") not in l1111l_l1_: l1111l_l1_ = l111llll1_l1_+l1111l_l1_
		l1l11l_l1_ (u"ࠤࠥࠦࠏࠏࠉࡪࡨࠣࠫࠪ࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ้ࠪ࠰ࠬฯࠧࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ๏ࠧ࠭ࠩํࠫ࠮ࠐࠉࠊࠤࠥࠦ䓱")
		title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䓲"))
		#if not any(value in title for value in l1llll1_l1_):
		#	if any(value in title for value in l11llll1l_l1_):
		if l1l11l_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬ䓳") in l1111l_l1_: title = l1l11l_l1_ (u"ࠬ์๊หใ็็ุ࠭䓴")
		addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓵"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ䓶")+menu_name+title,l1111l_l1_,111)
	return html
def l111l1_l1_(url,l11l1ll11_l1_=l1l11l_l1_ (u"ࠨࠩ䓷")):
	if l1l11l_l1_ (u"ࠩ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࡙ࡨࡰࡹࡶ࠲ࡵ࡮ࡰࡀࠩ䓸") in url:
		url,data = URLDECODE(url)
		headers2 = {l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䓹"):l1l11l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䓺"),l1l11l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䓻"):l1l11l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䓼")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䓽"),url,data,headers2,l1l11l_l1_ (u"ࠨࠩ䓾"),l1l11l_l1_ (u"ࠩࠪ䓿"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䔀"))
		html = response.content
		block = html
	elif l1l11l_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡈࡰ࡯ࡨ࠲ࡵ࡮ࡰࠨ䔁") in url:
		data = {l1l11l_l1_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࠬ䔂"):l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡣ࡮ࡲࡧࡰ࠭䔃"),l1l11l_l1_ (u"ࠧ࡬ࡧࡼࠫ䔄"):l11l1ll11_l1_}
		headers2 = {l1l11l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䔅"):l1l11l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䔆")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䔇"),url,data,headers2,l1l11l_l1_ (u"ࠫࠬ䔈"),l1l11l_l1_ (u"ࠬ࠭䔉"),l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ䔊"))
		html = response.content
		block = html
	else:
		headers2 = {l1l11l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䔋"):l1l11l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䔌")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䔍"),url,l1l11l_l1_ (u"ࠪࠫ䔎"),headers2,l1l11l_l1_ (u"ࠫࠬ䔏"),l1l11l_l1_ (u"ࠬ࠭䔐"),l1l11l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡖࡌࡘࡑࡋࡓ࠮࠵ࡵࡨࠬ䔑"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡸࡦ࡭ࡳ࠮ࡥ࡯ࡳࡺࡪࠧ䔒"),html,re.DOTALL)
		if not l1ll111_l1_: return
		block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡩ࡮ࡣࡪࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䔓"),block,re.DOTALL)
	#if not items: items = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䔔"),block,re.DOTALL)
	#if l1l11l_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ䔕") not in url: items = re.findall(l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡨ࡯ࡹ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䔖"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"๋ࠬิศ้าอࠬ䔗"),l1l11l_l1_ (u"࠭แ๋ๆ่ࠫ䔘"),l1l11l_l1_ (u"ࠧศ฼้๎ฮ࠭䔙"),l1l11l_l1_ (u"ࠨๅ็๎อ࠭䔚"),l1l11l_l1_ (u"ࠩส฽้อๆࠨ䔛"),l1l11l_l1_ (u"๋ࠪิอแࠨ䔜"),l1l11l_l1_ (u"๊ࠫฮวาษฬࠫ䔝"),l1l11l_l1_ (u"ࠬ฿ัืࠩ䔞"),l1l11l_l1_ (u"࠭ๅ่ำฯห๋࠭䔟"),l1l11l_l1_ (u"ࠧศๆห์๊࠭䔠")]
	for img,l1111l_l1_,title in items:
		if l1l11l_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ䔡") in l1111l_l1_: continue
		#if l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䔢") in l1111l_l1_: continue
		#l1111l_l1_ = l1111l_l1_.replace(l1l11l_l1_ (u"ࠪࠪࠨ࠶࠳࠹࠽ࠪ䔣"),l1l11l_l1_ (u"ࠫࠫ࠭䔤"))
		l1111l_l1_ = UNQUOTE(l1111l_l1_).strip(l1l11l_l1_ (u"ࠬ࠵ࠧ䔥"))
		title = unescapeHTML(title)
		title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨ䔦"))
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ䔧"),title,re.DOTALL)
		if l1l11l_l1_ (u"ࠨใํ่๊࠭䔨") in l1111l_l1_ or any(value in title for value in l111l11ll_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䔩"),menu_name+title,l1111l_l1_,112,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠪห้ำไใหࠪ䔪") in title and l1l11l_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ䔫") not in url:
			title = l1l11l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䔬") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔭"),menu_name+title,l1111l_l1_,113,img)
				l1l1l11_l1_.append(title)
		elif l1l11l_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸ࠯ࠨ䔮") in l1111l_l1_:
			addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔯"),menu_name+title,l1111l_l1_,111,img)
		elif l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䔰") in l1111l_l1_ and l1l11l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䔱") not in url:
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ䔲")
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔳"),menu_name+title,l1111l_l1_,111,img)
		elif l1l11l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ䔴") in url and l1l11l_l1_ (u"ࠧฮๆๅอࠬ䔵") in title:
			addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䔶"),menu_name+title,l1111l_l1_,112,img)
		else: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔷"),menu_name+title,l1111l_l1_,113,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䔸"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䔹"),block,re.DOTALL)
		if not items: items = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䔺"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"࠭วๅืไัฮࠦࠧ䔻"),l1l11l_l1_ (u"ࠧࠨ䔼"))
			if title!=l1l11l_l1_ (u"ࠨࠩ䔽"): addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔾"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡࠩ䔿")+title,l1111l_l1_,111)
	l11l1l111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䕀"),html,re.DOTALL)
	if l11l1l111_l1_:
		l1111l_l1_ = l11l1l111_l1_[0]
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕁"),menu_name+l1l11l_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭䕂"),l1111l_l1_,111)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䕃"),url,l1l11l_l1_ (u"ࠨࠩ䕄"),headers,l1l11l_l1_ (u"ࠩࠪ䕅"),l1l11l_l1_ (u"ࠪࠫ䕆"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䕇"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࠠࡪࡦࡀࠦࡸ࡫ࡡࡴࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡸࡦ࡭ࡳ࠮ࡥ࡯ࡳࡺࡪࠧ䕈"),html,re.DOTALL)
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䕉"),html,re.DOTALL)
	items = []
	# l111lll1l_l1_
	if l111l11l1_l1_ and l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䕊") not in url:
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕋"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䕌"))
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䕍"),menu_name+title,l1111l_l1_,113,img)
	# l1l11l1_l1_
	elif l1ll1lll1_l1_:
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡟ࡦ࠳ࡺ࡞࠭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䕎"),block,re.DOTALL)
		for l1111l_l1_,img,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䕏"))
			addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䕐"),menu_name+title,l1111l_l1_,112,img)
	# l1l11l1_l1_ l1l1llll_l1_
	if not items and l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭䕑") in html:
		l1ll1ll1l_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡵࡩࡦࡪࡣࡳࡷࡰࡦࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䕒"),html,re.DOTALL)
		if l1ll1ll1l_l1_:
			block = l1ll1ll1l_l1_[0]
			l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䕓"),block,re.DOTALL)
			if len(l1ll1111_l1_)>2:
				l1111l_l1_ = l1ll1111_l1_[2]+l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䕔")
				l111l1_l1_(l1111l_l1_)
	return
def PLAY(url):
	l1ll1lll_l1_ = []
	l11ll111_l1_ = url.strip(l1l11l_l1_ (u"ࠫ࠴࠭䕕"))
	hostname = SERVER(l11ll111_l1_,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ䕖"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䕗"),l11ll111_l1_,l1l11l_l1_ (u"ࠧࠨ䕘"),headers,l1l11l_l1_ (u"ࠨࠩ䕙"),l1l11l_l1_ (u"ࠩࠪ䕚"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䕛"))
	html = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䕜"))
	id = re.findall(l1l11l_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䕝"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ䕞"),html,re.DOTALL)
	if not id: id = re.findall(l1l11l_l1_ (u"ࠧࡱࡱࡶࡸ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䕟"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l1l11l_l1_ (u"ࠨࠩ䕠")
	#else: DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ䕡"),l1l11l_l1_ (u"ࠪࠫ䕢"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕣"),l1l11l_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ䕤"))
	if True or l1l11l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ䕥") in html:
		#parts = url.split(l1l11l_l1_ (u"ࠧ࠰ࠩ䕦"))
		#url2 = url.replace(parts[3],l1l11l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ䕧"))
		url2 = l11ll111_l1_+l1l11l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࠩ䕨")
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ䕩"),url2,l1l11l_l1_ (u"ࠫࠬ䕪"),headers,l1l11l_l1_ (u"ࠬ࠭䕫"),l1l11l_l1_ (u"࠭ࠧ䕬"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ䕭"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䕮"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䕯"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		if l1ll111_l1_: l1l11lll_l1_ = l1ll111_l1_[0]
		else: l1l11lll_l1_ = l1lll111_l1_
		if not id:
			id = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡀࠦ࠵ࠨࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䕰"),l1l11lll_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l1l11l_l1_ (u"ࠫࠬ䕱")
		l11lll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䕲"),l1lll111_l1_,re.DOTALL)
		l1l1l1111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ䕳"),l1lll111_l1_,re.DOTALL)
		l11lll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡴࡴࡦࡁࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕴"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࡝ࡰ࠭࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ䕵"),l1lll111_l1_)
		l11ll1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䕶"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		l1l1111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ䕷"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䕸"),l1l11lll_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1lll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ䕹"),l1l11lll_l1_,re.DOTALL|re.IGNORECASE)
		items = l11lll111_l1_+l1l1l1111_l1_+l11lll11l_l1_+l11ll1ll1_l1_+l11ll1l1l_l1_+l1l1111ll_l1_+l11ll1ll1ll1_l1_+l11ll1lll11l_l1_
		if not items:
			items = re.findall(l1l11l_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䕺"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ䕻")).strip(l1l11l_l1_ (u"ࠨࠢࠪ䕼"))
			if l1l11l_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧ䕽") in server: continue
			if l1l11l_l1_ (u"ࠪ࠲࡯ࡶࡧࠨ䕾") in server: continue
			if l1l11l_l1_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ䕿") in server: continue
			l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭䖀"),title,re.DOTALL)
			if l1l1l1l1_l1_:
				l1l1l1l1_l1_ = l1l1l1l1_l1_[0]
				if l1l1l1l1_l1_ in title: title = title.replace(l1l1l1l1_l1_+l1l11l_l1_ (u"࠭ࡰࠨ䖁"),l1l11l_l1_ (u"ࠧࠨ䖂")).replace(l1l1l1l1_l1_,l1l11l_l1_ (u"ࠨࠩ䖃")).strip(l1l11l_l1_ (u"ࠩࠣࠫ䖄"))
				l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䖅")+l1l1l1l1_l1_
			else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࠬ䖆")
			if server.isdigit(): l1111l_l1_ = hostname+l1l11l_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ䖇")+id+l1l11l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䖈")+server+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䖉")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䖊")+l1l1l1l1_l1_
			else:
				if l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䖋") not in server: server = l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䖌")+server
				l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䖍"),title,re.DOTALL)
				if l1l1l1l1_l1_: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䖎")+l1l1l1l1_l1_[0]
				else: l1l1l1l1_l1_ = l1l11l_l1_ (u"࠭ࠧ䖏")
				l1111l_l1_ = server+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨ䖐")+l1l1l1l1_l1_
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䖑"),l1ll1lll_l1_)
	#l1ll1lll_l1_ = []
	if l1l11l_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡈ࡮ࡼࠧ䖒") in html:
		url2 = l11ll111_l1_+l1l11l_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䖓")
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䖔"),url2,l1l11l_l1_ (u"ࠬ࠭䖕"),headers,l1l11l_l1_ (u"࠭ࠧ䖖"),l1l11l_l1_ (u"ࠧࠨ䖗"),l1l11l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䖘"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䖙"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡱࡪࡪࡩࡢ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࠬ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠩ࠯࠾࠲ࡨ࡮ࡼ࠾ࠨ䖚"),l1lll111_l1_,re.DOTALL|re.IGNORECASE)
		if l1ll111_l1_: l1l11lll_l1_ = l1ll111_l1_[0]
		else: l1l11lll_l1_ = l1lll111_l1_
		l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠫࡁ࡮࠳࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䖛"),l1l11lll_l1_,re.DOTALL)
		for title,block in l1l1l1_l1_:
			title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧ䖜"))
			items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䖝"),block,re.DOTALL)
			for l1111l_l1_,name,l1l1l1l1_l1_ in items:
				l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࡝ࡦ࠮ࠫ䖞"),l1l1l1l1_l1_,re.DOTALL)
				if l1l1l1l1_l1_: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࡡࡢࡣࡤ࠭䖟")+l1l1l1l1_l1_[0]
				else:
					l1l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡟ࡨ࠰࠭䖠"),title,re.DOTALL)
					if l1l1l1l1_l1_: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䖡")+l1l1l1l1_l1_[0]
					else: l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࠬ䖢")
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䖣")+name+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䖤")+l1l1l1l1_l1_
				l1ll1lll_l1_.append(l1111l_l1_)
		if not l1l1l1_l1_:
			url2 = hostname +l1l11l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴࡙ࡨࡢࡪ࡬ࡨ࠹ࡻ࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡅࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵ࠭䖥")
			headers2 = {l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䖦"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ䖧")}
			data2 = {l1l11l_l1_ (u"ࠪ࡭ࡩ࠭䖨"):id}
			response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䖩"),url2,data2,headers2,l1l11l_l1_ (u"ࠬ࠭䖪"),l1l11l_l1_ (u"࠭ࠧ䖫"),l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䖬"))
			l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭䖭"))
			items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䖮"),l1lll111_l1_,re.DOTALL)
			for l1111l_l1_,name,l1l1l1l1_l1_ in items:
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䖯")+name+l1l11l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䖰")+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䖱")+l1l1l1l1_l1_
				l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䖲"),l1ll1lll_l1_)
	elif l1l11l_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥࡐࡲࡻࠬ䖳") in html:
		headers2 = { l1l11l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䖴"):l1l11l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ䖵") }
		url2 = l11ll111_l1_.replace(parts[3],l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䖶"))
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ䖷"),url2,l1l11l_l1_ (u"ࠬ࠭䖸"),headers2,l1l11l_l1_ (u"࠭ࠧ䖹"),l1l11l_l1_ (u"ࠧࠨ䖺"),l1l11l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ䖻"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䖼"))
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠯࡬ࡸࡪࡳࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ䖽"),l1lll111_l1_,re.DOTALL)
		for block in l1ll111_l1_:
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䖾"),block,re.DOTALL)
			for l1111l_l1_,name,l1l1l1l1_l1_ in items:
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䖿")+name+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䗀")+l1l11l_l1_ (u"ࠧࡠࡡࡢࡣࠬ䗁")+l1l1l1l1_l1_
				l1ll1lll_l1_.append(l1111l_l1_)
	elif l1l11l_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ䗂") in html:
		headers2 = { l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䗃"):l1l11l_l1_ (u"ࠪࠫ䗄") , l1l11l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䗅"):l1l11l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䗆") }
		url2 = hostname + l1l11l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩ䗇")+id
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䗈"),url2,l1l11l_l1_ (u"ࠨࠩ䗉"),headers2,l1l11l_l1_ (u"ࠩࠪ䗊"),l1l11l_l1_ (u"ࠪࠫ䗋"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ䗌"))
		l1lll111_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䗍"))
		if l1l11l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤࡷࡲࡸ࠭䗎") in l1lll111_l1_:
			l11lll11l_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䗏"),l1lll111_l1_,re.DOTALL)
			for url3 in l11lll11l_l1_:
				if l1l11l_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ䗐") not in url3 and l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䗑") in url3:
					url3 = url3+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䗒")
					l1ll1lll_l1_.append(url3)
				elif l1l11l_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䗓") in url3:
					l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠬ࠭䗔")
					response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䗕"),url3,l1l11l_l1_ (u"ࠧࠨ䗖"),headers,l1l11l_l1_ (u"ࠨࠩ䗗"),l1l11l_l1_ (u"ࠩࠪ䗘"),l1l11l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ䗙"))
					l11lllll1_l1_ = response.content#.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䗚"))
					l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠼ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂ࠭࠲࠳࠭࠮࠯ࠪ䗛"),l11lllll1_l1_,re.DOTALL)
					for l1l11l1ll_l1_ in l1l1l1_l1_:
						l1l111111_l1_ = l1l11l_l1_ (u"࠭ࠧ䗜")
						l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩ䗝"),l1l11l1ll_l1_,re.DOTALL)
						for l1l111l1l_l1_ in l11ll1ll1_l1_:
							item = re.findall(l1l11l_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䗞"),l1l111l1l_l1_,re.DOTALL)
							if item:
								l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠩࡢࡣࡤࡥࠧ䗟")+item[0]
								break
						for l1l111l1l_l1_ in reversed(l11ll1ll1_l1_):
							item = re.findall(l1l11l_l1_ (u"ࠪࡠࡼࡢࡷࠬࠩ䗠"),l1l111l1l_l1_,re.DOTALL)
							if item:
								l1l111111_l1_ = item[0]
								break
						l11ll1l1l_l1_ = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䗡"),l1l11l1ll_l1_,re.DOTALL)
						for l1l1111l1_l1_ in l11ll1l1l_l1_:
							l1l1111l1_l1_ = l1l1111l1_l1_+l1l11l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䗢")+l1l111111_l1_+l1l11l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䗣")+l1l1l1l1_l1_
							l1ll1lll_l1_.append(l1l1111l1_l1_)
		elif l1l11l_l1_ (u"ࠧࡴ࡮ࡲࡻ࠲ࡳ࡯ࡵ࡫ࡲࡲࠬ䗤") in l1lll111_l1_:
			l1lll111_l1_ = l1lll111_l1_.replace(l1l11l_l1_ (u"ࠨ࠾࡫࠺ࠥ࠭䗥"),l1l11l_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠣࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠭䗦"))+l1l11l_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠫ䗧")
			l1lll111_l1_ = l1lll111_l1_.replace(l1l11l_l1_ (u"ࠫࡁ࡮࠳ࠡࠩ䗨"),l1l11l_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂࠦ࠽࠾ࡕࡗࡅࡗ࡚࠽࠾ࠩ䗩"))+l1l11l_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠧ䗪")
			l11ll1lll_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠾࠿ࡖࡘࡆࡘࡔ࠾࠿ࠫ࠲࠯ࡅࠩ࠾࠿ࡈࡒࡉࡃ࠽ࠨ䗫"),l1lll111_l1_,re.DOTALL)
			if l11ll1lll_l1_:
				for l1l11l1ll_l1_ in l11ll1lll_l1_:
					if l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠧ䗬") not in l1l11l1ll_l1_: continue
					l1l111ll1_l1_ = l1l11l_l1_ (u"ࠩࠪ䗭")
					l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䗮"),l1l11l1ll_l1_,re.DOTALL)
					for l1l111l1l_l1_ in l11ll1ll1_l1_:
						item = re.findall(l1l11l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ䗯"),l1l111l1l_l1_,re.DOTALL)
						if item:
							l1l111ll1_l1_ = l1l11l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䗰")+item[0]
							break
					l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ䗱"),l1l11l1ll_l1_,re.DOTALL)
					if l11ll1ll1_l1_:
						for l1l111111_l1_,l1l11111l_l1_ in l11ll1ll1_l1_:
							l1l11111l_l1_ = l1l11111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䗲")+l1l111111_l1_+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䗳")+l1l111ll1_l1_
							l1ll1lll_l1_.append(l1l11111l_l1_)
					else:
						l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䗴"),l1l11l1ll_l1_,re.DOTALL)
						for l1l11111l_l1_,l1l111111_l1_ in l11ll1ll1_l1_:
							l1l11111l_l1_ = l1l11111l_l1_.strip(l1l11l_l1_ (u"ࠪࠤࠬ䗵"))+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䗶")+l1l111111_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䗷")+l1l111ll1_l1_
							l1ll1lll_l1_.append(l1l11111l_l1_)
			else:
				l11ll1ll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࡟ࡻ࠰࠯࠼ࠨ䗸"),l1lll111_l1_,re.DOTALL)
				for l1l11111l_l1_,l1l111111_l1_ in l11ll1ll1_l1_:
					l1l11111l_l1_ = l1l11111l_l1_.strip(l1l11l_l1_ (u"ࠧࠡࠩ䗹"))+l1l11l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䗺")+l1l111111_l1_+l1l11l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䗻")
					l1ll1lll_l1_.append(l1l11111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䗼"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䗽"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧ䗾"),l1l11l_l1_ (u"࠭ࠫࠨ䗿"))
	if showdialogs:
		l11llllll_l1_ = [l1l11l_l1_ (u"ࠧศใ็ห๊࠭䘀"),l1l11l_l1_ (u"ࠨ็ึุ่๊วหࠩ䘁"),l1l11l_l1_ (u"่้ࠩะ๊๊็ࠩ䘂"),l1l11l_l1_ (u"ࠪห้้ไࠨ䘃")]
		l1lllll11_l1_ = [l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ䘄"),l1l11l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䘅"),l1l11l_l1_ (u"࠭ࡡࡤࡶࡲࡶࠬ䘆"),l1l11l_l1_ (u"ࠧࠨ䘇")]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠣ࠱ࠥอฮหำࠣห้็ไหำࠣห้๋ๆศีหࠫ䘈"), l11llllll_l1_)
		if selection == -1 : return
		type = l1lllll11_l1_[selection]
	else: type = l1l11l_l1_ (u"ࠩࠪ䘉")
	l1l11l_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡪࡲࡱࡪ࠭ࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡰࡤࡱࡪࡃࠢࡵࡻࡳࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡳࡵࡴࠫࡷ࡭ࡵࡷࡥ࡫ࡤࡰࡴ࡭ࡳࠪ࠮ࡶࡸࡷ࠮࡬ࡦࡰࠫ࡬ࡹࡳ࡬ࠪࠫࠬࠎࠎ࡯ࡦࠡࡵ࡫ࡳࡼࡪࡩࡢ࡮ࡲ࡫ࡸࠦࡡ࡯ࡦࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠ࡜ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ࡞࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࡨࡰࡸ࡫࠺ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠭ࠧࠋࠋࠦࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠤࠥࠦ䘊")
	url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ䘋")+search+l1l11l_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ䘌")+type
	l111l1_l1_(url)
	return
# ===========================================
#     l11l1l1ll_l1_ l111lll11_l1_ l111ll1l1_l1_
# ===========================================
def l11l1l1l1_l1_(url):
	url = url.split(l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ䘍"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䘎"),url,l1l11l_l1_ (u"ࠨࠩ䘏"),headers,l1l11l_l1_ (u"ࠩࠪ䘐"),l1l11l_l1_ (u"ࠪࠫ䘑"),l1l11l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ䘒"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ䘓"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + category + options block
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡰࡸ࠲࠯ࡅࡲࡰࡷࡱࡨࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡭ࡳࡶࡵࡵࠢࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ䘔"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111lllll_l1_(block):
	# id + title
	items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡩࡡࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩࡨࡦࡥ࡮ࡱࡦࡸ࡫࠮ࡤࡲࡰࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䘕"),block,re.DOTALL)
	return items
def l11ll1ll1lll_l1_(url):
	url = url.replace(l1l11l_l1_ (u"ࠨࡥࡤࡸࡂ࠭䘖"),l1l11l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ䘗"))
	if l1l11l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ䘘") not in url: url = url+l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ䘙")
	l11l1111l_l1_ = url.split(l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ䘚"))[0]
	l11l11111_l1_ = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䘛"))
	url = url.replace(l11l1111l_l1_,l11l11111_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ䘜"),l1l11l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡕ࡫ࡳࡼࡹ࠮ࡱࡪࡳࡃࠬ䘝"))
	return url
l11ll1ll1l1l_l1_ = [l1l11l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ䘞"),l1l11l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䘟"),l1l11l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䘠"),l1l11l_l1_ (u"ࠬࡩࡡࡵࠩ䘡")]
l11ll1lll111_l1_ = [l1l11l_l1_ (u"࠭ࡣࡢࡶࠪ䘢"),l1l11l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭䘣"),l1l11l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䘤")]
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘥"),l1l11l_l1_ (u"ࠪࠫ䘦"))
	url = url.split(l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ䘧"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䘨"),1)
	if filter==l1l11l_l1_ (u"࠭ࠧ䘩"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"ࠧࠨ䘪"),l1l11l_l1_ (u"ࠨࠩ䘫")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭䘬"))
	if type==l1l11l_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ䘭"):
		if l11ll1lll111_l1_[0]+l1l11l_l1_ (u"ࠫࡂ࠭䘮") not in l111111_l1_: category = l11ll1lll111_l1_[0]
		for i in range(len(l11ll1lll111_l1_[0:-1])):
			if l11ll1lll111_l1_[i]+l1l11l_l1_ (u"ࠬࡃࠧ䘯") in l111111_l1_: category = l11ll1lll111_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠨ䘰")+category+l1l11l_l1_ (u"ࠧ࠾࠲ࠪ䘱")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠪ䘲")+category+l1l11l_l1_ (u"ࠩࡀ࠴ࠬ䘳")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠬ䘴"))+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ䘵")+l11l11l_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧ䘶"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䘷"))
		url2 = url+l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ䘸")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭䘹"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䘺"))
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠪࠫ䘻"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ䘼"))
		if l1llllll_l1_==l1l11l_l1_ (u"ࠬ࠭䘽"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ䘾")+l1llllll_l1_
		url3 = l11ll1ll1lll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘿"),menu_name+l1l11l_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ䙀"),url3,111)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙁"),menu_name+l1l11l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ䙂")+l1ll1ll1_l1_+l1l11l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ䙃"),url3,111)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙄"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䙅"),l1l11l_l1_ (u"ࠧࠨ䙆"),9999)
	l1l1ll1_l1_ = l11l1l1l1_l1_(url)
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		name = name.replace(l1l11l_l1_ (u"ࠨ࠯࠰ࠫ䙇"),l1l11l_l1_ (u"ࠩࠪ䙈"))
		items = l111lllll_l1_(block)
		if l1l11l_l1_ (u"ࠪࡁࠬ䙉") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ䙊"):
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l11ll1lll111_l1_[-1]:
					url3 = l11ll1ll1lll_l1_(url2)
					l111l1_l1_(url3)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ䙋")+l111l11_l1_)
				return
			else:
				if l1l111l_l1_==l11ll1lll111_l1_[-1]:
					url3 = l11ll1ll1lll_l1_(url2)
					addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙌"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ䙍"),url3,111)
				else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙎"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ䙏"),url2,115,l1l11l_l1_ (u"ࠪࠫ䙐"),l1l11l_l1_ (u"ࠫࠬ䙑"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ䙒"):
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠨ䙓")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾࠲ࠪ䙔")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠪ䙕")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀ࠴ࠬ䙖")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ䙗")+l11l11l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙘"),menu_name+l1l11l_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ䙙")+name,url2,114,l1l11l_l1_ (u"࠭ࠧ䙚"),l1l11l_l1_ (u"ࠧࠨ䙛"),l111l11_l1_)		# +l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䙜"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if value==l1l11l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ䙝"): option = l1l11l_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ䙞")
			elif value==l1l11l_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ䙟"): option = l1l11l_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ䙠")
			if option in l1llll1_l1_: continue
			#if l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ䙡") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䙢"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠪ䙣")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࠫ䙤")+option
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠬ䙥")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠭䙦")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䙧")+l11l11l_l1_
			title = option+l1l11l_l1_ (u"࠭ࠠ࠻ࠩ䙨")#+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠧ࠱ࠩ䙩")]
			title = option+l1l11l_l1_ (u"ࠨࠢ࠽ࠫ䙪")+name
			if type==l1l11l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ䙫"): addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙬"),menu_name+title,url,114,l1l11l_l1_ (u"ࠫࠬ䙭"),l1l11l_l1_ (u"ࠬ࠭䙮"),l1l1111_l1_)		# +l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䙯"))
			elif type==l1l11l_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ䙰") and l11ll1lll111_l1_[-2]+l1l11l_l1_ (u"ࠨ࠿ࠪ䙱") in l111111_l1_:
				l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䙲"))
				url2 = url+l1l11l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ䙳")+l1llll11_l1_
				url3 = l11ll1ll1lll_l1_(url2)
				addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙴"),menu_name+title,url3,111)
			else: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䙵"),menu_name+title,url,115,l1l11l_l1_ (u"࠭ࠧ䙶"),l1l11l_l1_ (u"ࠧࠨ䙷"),l1l1111_l1_)
	return
def l1llll1l_l1_(filters,mode):
	# mode==l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ䙸")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䙹")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"ࠪࡥࡱࡲࠧ䙺")					all l111lll_l1_ & l11l1l11l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠫࡂࠬࠧ䙻"),l1l11l_l1_ (u"ࠬࡃ࠰ࠧࠩ䙼"))
	filters = filters.strip(l1l11l_l1_ (u"࠭ࠦࠨ䙽"))
	l11111l_l1_ = {}
	if l1l11l_l1_ (u"ࠧ࠾ࠩ䙾") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠨࠨࠪ䙿"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠩࡀࠫ䚀"))
			l11111l_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"ࠪࠫ䚁")
	for key in l11ll1ll1l1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠫ࠵࠭䚂")
		if l1l11l_l1_ (u"ࠬࠫࠧ䚃") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䚄") and value!=l1l11l_l1_ (u"ࠧ࠱ࠩ䚅"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠨࠢ࠮ࠤࠬ䚆")+value
		elif mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䚇") and value!=l1l11l_l1_ (u"ࠪ࠴ࠬ䚈"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠫ࠭䚉")+key+l1l11l_l1_ (u"ࠬࡃࠧ䚊")+value
		elif mode==l1l11l_l1_ (u"࠭ࡡ࡭࡮ࠪ䚋"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠧࠧࠩ䚌")+key+l1l11l_l1_ (u"ࠨ࠿ࠪ䚍")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠩࠣ࠯ࠥ࠭䚎"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠬ䚏"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠫࡂ࠶ࠧ䚐"),l1l11l_l1_ (u"ࠬࡃࠧ䚑"))
	return l11llll_l1_
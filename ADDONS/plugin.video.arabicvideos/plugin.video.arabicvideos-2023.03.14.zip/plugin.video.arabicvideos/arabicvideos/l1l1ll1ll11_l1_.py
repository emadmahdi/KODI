# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
#l11lll_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬ㑩")
headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㑪"):l1l11l_l1_ (u"ࠧࠨ㑫")}
script_name = l1l11l_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㑬")
menu_name = l1l11l_l1_ (u"ࠩࡢࡔࡓ࡚࡟ࠨ㑭")
l11lll_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l1l11l_l1_ (u"ࠪ࠷ࠬ㑮"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l1l11l_l1_ (u"ࠫ࠶࠭㑯"))
	elif mode==36: results = CATEGORIES(url,l1l11l_l1_ (u"ࠬ࠸ࠧ㑰"))
	elif mode==37: results = CATEGORIES(url,l1l11l_l1_ (u"࠭࠴ࠨ㑱"))
	elif mode==38: results = l1llll11l_l1_()
	elif mode==39: results = SEARCH(text,page)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㑲"),menu_name+l1l11l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㑳"),l1l11l_l1_ (u"ࠩࠪ㑴"),39,l1l11l_l1_ (u"ࠪࠫ㑵"),l1l11l_l1_ (u"ࠫࠬ㑶"),l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㑷"))
	#addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㑸"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㑹"),l1l11l_l1_ (u"ࠨࠩ㑺"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㑻"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ㑼")+menu_name+l1l11l_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭㑽"),l1l11l_l1_ (u"ࠬ࠭㑾"),38)
	#addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㑿"),script_name+l1l11l_l1_ (u"ࠧࡠࡡࡢࠫ㒀")+menu_name+l1l11l_l1_ (u"ࠨ็ึุ่๊วห๋ࠢฬึอๅอࠩ㒁"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ㒂"),31)
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㒃"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ㒄")+menu_name+l1l11l_l1_ (u"ࠬอไๆี็ื้อสࠡษ็ห่ััࠡ็ืห์ีษࠨ㒅"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ㒆"),37)
	#addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㒇"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬ㒈")+menu_name+l1l11l_l1_ (u"ࠩสๅ้อๅࠡฯึฬࠥอไ็๊฼ࠫ㒉"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ㒊"),35)
	#addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㒋"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ㒌")+menu_name+l1l11l_l1_ (u"࠭วโๆส้ࠥำำษࠢส่๊๋หๅࠩ㒍"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ㒎"),36)
	#addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㒏"),script_name+l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭㒐")+menu_name+l1l11l_l1_ (u"ࠪหาีหࠡษ็หๆ๊วๆࠩ㒑"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ㒒"),32)
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㒓"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ㒔")+menu_name+l1l11l_l1_ (u"ࠧๆีิั๏อสࠨ㒕"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡪࡩࡳࡸࡥ࠰࠶࠲࠵ࠬ㒖"),32)
	return l1l11l_l1_ (u"ࠩࠪ㒗")
def CATEGORIES(url,select=l1l11l_l1_ (u"ࠪࠫ㒘")):
	type = url.split(l1l11l_l1_ (u"ࠫ࠴࠭㒙"))[3]
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭㒚"),l1l11l_l1_ (u"࠭ࠧ㒛"),type, url)
	if type==l1l11l_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ㒜"):
		html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠨࠩ㒝"),headers,l1l11l_l1_ (u"ࠩࠪ㒞"),l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪ㒟"))
		if select==l1l11l_l1_ (u"ࠫ࠸࠭㒠"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡷࡪࡸࡩࡦࡵࡉࡳࡷࡳࠧ㒡"),html,re.DOTALL)
			block= l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㒢"),block,re.DOTALL)
			for l1111l_l1_,name in items:
				if l1l11l_l1_ (u"ࠧไๆํฬฬะࠠๆุะ็ฮ࠭㒣") in name: continue
				url = l11lll_l1_ + l1111l_l1_
				name = name.strip(l1l11l_l1_ (u"ࠨࠢࠪ㒤"))
				addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㒥"),menu_name+name,url,32)
		if select==l1l11l_l1_ (u"ࠪ࠸ࠬ㒦"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡨࡪࡺࡡࡪ࡮ࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡷࡀ࠿࠳ࡦࡄ࠼࠰ࡦ࡬ࡺࡃ࠭㒧"),html,re.DOTALL)
			block= l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㒨"),block,re.DOTALL)
			for l1111l_l1_,img,title in items:
				url = l11lll_l1_ + l1111l_l1_
				title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨ㒩"))
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㒪"),menu_name+title,url,32,img)
		#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ㒫"),l1l11l_l1_ (u"ࠩࠪ㒬"),url,l1l11l_l1_ (u"ࠪࠫ㒭"))
	if type==l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ㒮"):
		html = OPENURL_CACHED(l1llll_l1_,url,l1l11l_l1_ (u"ࠬ࠭㒯"),headers,l1l11l_l1_ (u"࠭ࠧ㒰"),l1l11l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠶ࡳࡪࠧ㒱"))
		if select==l1l11l_l1_ (u"ࠨ࠳ࠪ㒲"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡉࡨࡲࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡥ࡭ࡧࡦࡸࠬ㒳"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㒴"),block,re.DOTALL)
			for value,name in items:
				url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳ࠬ㒵") + value
				name = name.strip(l1l11l_l1_ (u"ࠬࠦࠧ㒶"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㒷"),menu_name+name,url,32)
		elif select==l1l11l_l1_ (u"ࠧ࠳ࠩ㒸"):
			l1ll111_l1_=re.findall(l1l11l_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡂࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡷࡪࡲࡥࡤࡶࠪ㒹"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items=re.findall(l1l11l_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㒺"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l11l_l1_ (u"ࠪࠤࠬ㒻"))
				url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴ࡧࡣࡵࡱࡵ࠳ࠬ㒼") + value
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㒽"),menu_name+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㒾"),l1l11l_l1_ (u"ࠧࠨ㒿"),url,l1l11l_l1_ (u"ࠨࠩ㓀"))
	type = url.split(l1l11l_l1_ (u"ࠩ࠲ࠫ㓁"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l11l_l1_ (u"ࠪࠫ㓂"),headers,l1l11l_l1_ (u"ࠫࠬ㓃"),l1l11l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㓄"))
	if l1l11l_l1_ (u"࠭ࡨࡰ࡯ࡨࠫ㓅") in url: type=l1l11l_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㓆")
	if type==l1l11l_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ㓇"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷ࠭࠴ࠪࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ㓈"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㓉"),block,re.DOTALL)
			for l1111l_l1_,img,name in items:
				url = l11lll_l1_ + l1111l_l1_
				name = name.strip(l1l11l_l1_ (u"ࠫࠥ࠭㓊"))
				addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㓋"),menu_name+name,url,32,img)
	if type==l1l11l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭㓌"):
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ㓍"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠬࡁࠬࠦࠬ㓎"),block,re.DOTALL)
		for l1111l_l1_,img,name in items:
			name = name.strip(l1l11l_l1_ (u"ࠩࠣࠫ㓏"))
			url = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㓐"),menu_name+name,url,33,img)
	if type==l1l11l_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭㓑"):
		page = url.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㓒"))[-1]
		#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ㓓"),l1l11l_l1_ (u"ࠧࠨ㓔"),url,l1l11l_l1_ (u"ࠨࠩ㓕"))
		if page==l1l11l_l1_ (u"ࠩ࠴ࠫ㓖"):
			l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠨ㓗"),html,re.DOTALL)
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࠬ㓘"),block,re.DOTALL)
			count = 0
			for l1111l_l1_,img,l1ll1ll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l11l_l1_ (u"ࠬࠦ࠭ࠡࠩ㓙") + l1ll1ll_l1_
				url = l11lll_l1_ + l1111l_l1_
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㓚"),menu_name+name,url,33,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶ࠲࠯ࡅࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ㓛"),html,re.DOTALL)
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࠩ㓜"),block,re.DOTALL)
		for l1111l_l1_,img,title,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l11l_l1_ (u"ࠩࠣࠫ㓝"))
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ㓞"))
			name = title + l1l11l_l1_ (u"ࠫࠥ࠳ࠠࠨ㓟") + l1ll1ll_l1_
			url = l11lll_l1_ + l1111l_l1_
			addMenuItem(l1l11l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㓠"),menu_name+name,url,33,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡧ࡭ࡻࡳ࡬࡮ࡩ࡯࡯࠯ࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡶ࡮࡭ࡨࡵࠪ࠱࠯ࡄ࠯ࡤࡢࡶࡤ࠱ࡷ࡫ࡶࡪࡸࡨ࠱ࡿࡵ࡮ࡦ࡫ࡧࡁࠧ࠺ࠢࠨ㓡"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㓢"),block,re.DOTALL)
	for l1111l_l1_,page in items:
		url = l11lll_l1_ + l1111l_l1_
		name = l1l11l_l1_ (u"ࠨืไัฮࠦࠧ㓣") + page
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㓤"),menu_name+name,url,32)
	return
def PLAY(url):
	if l1l11l_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ㓥") in url:
		url = l11lll_l1_ + l1l11l_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࡹ࠵࠴ࡹࡥࡳ࡫ࡨࡷࡑ࡯࡮࡬࠱ࠪ㓦") + url.split(l1l11l_l1_ (u"ࠬ࠵ࠧ㓧"))[-1]
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ㓨"),url,l1l11l_l1_ (u"ࠧࠨ㓩"),headers,l1l11l_l1_ (u"ࠨࠩ㓪"),l1l11l_l1_ (u"ࠩࠪ㓫"),l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㓬"))
		html = response.content
		items = re.findall(l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㓭"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l11l_l1_ (u"ࠬࡢ࠯ࠨ㓮"),l1l11l_l1_ (u"࠭࠯ࠨ㓯"))
	else:
		response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ㓰"),url,l1l11l_l1_ (u"ࠨࠩ㓱"),headers,l1l11l_l1_ (u"ࠩࠪ㓲"),l1l11l_l1_ (u"ࠪࠫ㓳"),l1l11l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㓴"))
		html = response.content
		items = re.findall(l1l11l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡛ࡒࡍࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㓵"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㓶"))
	return
def SEARCH(search,page=l1l11l_l1_ (u"ࠧࠨ㓷")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l1l1ll_l1_ = search.replace(l1l11l_l1_ (u"ࠨࠢࠪ㓸"),l1l11l_l1_ (u"ࠩࠨ࠶࠵࠭㓹"))
	l1lllll11_l1_ = [l1l11l_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ㓺"),l1l11l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ㓻")]
	if not page: page = l1l11l_l1_ (u"ࠬ࠷ࠧ㓼")
	else: page,type = page.split(l1l11l_l1_ (u"࠭࠯ࠨ㓽"))
	if showdialogs:
		l1llll1l1ll_l1_ = [ l1l11l_l1_ (u"ࠧษฯฮࠤ฾์ࠠศใ็ห๊࠭㓾") , l1l11l_l1_ (u"ࠨสะฯࠥ฿ๆࠡ็ึุ่๊วหࠩ㓿")]
		selection = DIALOG_SELECT(l1l11l_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦ࠭ࠡษัฮึࠦวๅสะฯࠬ㔀"), l1llll1l1ll_l1_)
		if selection == -1 : return
		type = l1lllll11_l1_[selection]
	else:
		if l1l11l_l1_ (u"ࠪࡣࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࡢࠫ㔁") in options: type = l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ㔂")
		elif l1l11l_l1_ (u"ࠬࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭㔃") in options: type = l1l11l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭㔄")
		else: return
	headers[l1l11l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㔅")] = l1l11l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ㔆")
	data = {l1l11l_l1_ (u"ࠩࡴࡹࡪࡸࡹࠨ㔇"):l1l1ll_l1_ , l1l11l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡇࡳࡲࡧࡩ࡯ࠩ㔈"):type}
	if page!=l1l11l_l1_ (u"ࠫ࠶࠭㔉"): data[l1l11l_l1_ (u"ࠬ࡬ࡲࡰ࡯ࠪ㔊")] = page
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡐࡐࡕࡗࠫ㔋"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ㔌"),data,headers,l1l11l_l1_ (u"ࠨࠩ㔍"),l1l11l_l1_ (u"ࠩࠪ㔎"),l1l11l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭㔏"))
	html = response.content
	items=re.findall(l1l11l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㔐"),html,re.DOTALL)
	if items:
		for title,l1111l_l1_ in items:
			url = l11lll_l1_ + l1111l_l1_.replace(l1l11l_l1_ (u"ࠬࡢ࠯ࠨ㔑"),l1l11l_l1_ (u"࠭࠯ࠨ㔒"))
			if l1l11l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ㔓") in url: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㔔"),menu_name+l1l11l_l1_ (u"ࠩไ๎้๋ࠠࠨ㔕")+title,url,33)
			elif l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㔖") in url:
				url = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭㔗"),l1l11l_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࠫ㔘"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㔙"),menu_name+l1l11l_l1_ (u"ࠧๆี็ื้ࠦࠧ㔚")+title,url+l1l11l_l1_ (u"ࠨ࠱࠴ࠫ㔛"),32)
	count=re.findall(l1l11l_l1_ (u"ࠩࠥࡸࡴࡺࡡ࡭ࠤ࠽ࠬ࠳࠰࠿ࠪࡿࠪ㔜"),html,re.DOTALL)
	if count:
		pages = int(  (int(count[0])+9)   /10 )+1
		for l1llllll1_l1_ in range(1,pages):
			l1llllll1_l1_ = str(l1llllll1_l1_)
			if l1llllll1_l1_!=page:
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㔝"),l1l11l_l1_ (u"ฺࠫ็อสࠢࠪ㔞")+l1llllll1_l1_,l1l11l_l1_ (u"ࠬ࠭㔟"),39,l1l11l_l1_ (u"࠭ࠧ㔠"),l1llllll1_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩ㔡")+type,search)
	return
def l1llll11l_l1_():
	l1111l_l1_ = l1l11l_l1_ (u"ࠨࡣࡋࡖ࠵ࡩࡄࡰࡸࡏ࠶ࡩࢀࡤࡉࡌ࡯࡝࡜࠶࠰ࡍࡰࡅ࡬ࡧࡳࡖ࠱ࡎࡰࡒࡻࡒ࡭࡭ࡵࡏ࠶࡛ࡱ࡚࠳ࡘࡩ࡝࡜ࡐࡹࡍ࠴࡫࡬ࡧࡍࡆࡖࡘ࡬࠽ࡼࡨࡇࡇ࠷ࡥࡋࡱࢀࡤࡄ࠷ࡷࡑ࠸࡛࠴ࠨ㔢")
	l1111l_l1_ = base64.b64decode(l1111l_l1_)
	l1111l_l1_ = l1111l_l1_.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㔣"))
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㔤"))
	return
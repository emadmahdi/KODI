﻿# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from EXCLUDES import *
if kodi_version>18.99:
	l1l1111ll11_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ✡"))
	l11l1l11111_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ✢"))
	l1l1lll11ll_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭✣"))
	l11l1l1llll_l1_ = xbmcvfs.translatePath(l1l11l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ✤"))
	loglevel = xbmc.LOGINFO
	l111llll1ll_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭✥"),l1l11l_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ✦"),l1l11l_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ✧"))
	ltr,rtl = l1l11l_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨ✨"),l1l11l_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩ✩")
	half_triangular_colon = l1l11l_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ✪")
else:
	l1l1111ll11_l1_ = xbmc.translatePath(l1l11l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ✫"))
	l11l1l11111_l1_ = xbmc.translatePath(l1l11l_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ✬"))
	l1l1lll11ll_l1_ = xbmc.translatePath(l1l11l_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ✭"))
	l11l1l1llll_l1_ = xbmc.translatePath(l1l11l_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ✮"))
	loglevel = xbmc.LOGNOTICE
	l111llll1ll_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ✯"),l1l11l_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ✰"),l1l11l_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠴࠺࠲ࡩࡨࠧ✱"))
	ltr,rtl = l1l11l_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ✲").encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✳")),l1l11l_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭✴").encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ✵"))
	half_triangular_colon = l1l11l_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ✶").encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭✷"))
l11lllll11l_l1_ = l1l11l_l1_ (u"ࠩ⸾ࠤ⼢ࠦ⸪ࠡ⸽ࠪ✸")
l11ll1lllll_l1_ = os.path.join(l1l1lll11ll_l1_,l1l11l_l1_ (u"ࠪ࡯ࡴࡪࡩ࠯࡮ࡲ࡫ࠬ✹"))
l11llllll11_l1_ = os.path.join(l1l1lll11ll_l1_,l1l11l_l1_ (u"ࠫࡰࡵࡤࡪ࠰ࡲࡰࡩ࠴࡬ࡰࡩࠪ✺"))
l1lll11111l_l1_ = [l1l11l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧ✻"),l1l11l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧ✼"),l1l11l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪ✽"),l1l11l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪ✾"),l1l11l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪ✿"),l1l11l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧ❀")]
l1l11l1l1l1_l1_ = l1lll11111l_l1_+[l1l11l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭❁"),l1l11l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ❂"),l1l11l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ❃"),l1l11l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡶࡨࡦࡰࡲࡱࡪࡴࡡ࡭ࡇࡐࡅࡉ࠭❄")]		# ,l1l11l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡩ࡯ࡵࡷࡥࡱࡲࡅࡎࡃࡇࠫ❅")
l1l1ll1l11_l1_ = os.path.join(l11l1l1llll_l1_,addon_id)
cache_dbfile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬ❆")+addon_version+l1l11l_l1_ (u"ࠪ࠲ࡩࡨࠧ❇"))
iptv1_dbfile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࠨ❈")+addon_version+l1l11l_l1_ (u"ࠬ࠴ࡤࡣࠩ❉"))
iptv2_dbfile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"࠭ࡩࡱࡶࡹ࠶ࡩࡧࡴࡢࡡࠪ❊")+addon_version+l1l11l_l1_ (u"ࠧ࠯ࡦࡥࠫ❋"))
l11l1ll1lll_l1_ = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩ❌"))
l11llll1l1l_l1_ = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠩ࡯ࡥࡸࡺ࡭ࡦࡰࡸ࠲ࡩࡧࡴࠨ❍"))
favouritesfile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠪࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࠮ࡥࡣࡷࠫ❎"))
dummyiptvfile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠫࡩࡻ࡭࡮ࡻ࡬ࡴࡹࡼ࠮ࡥࡣࡷࠫ❏"))
fulliptvfile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠬ࡬ࡵ࡭࡮࡬ࡴࡹࡼ࠮ࡥࡣࡷࠫ❐"))
l1111ll1111_l1_ = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡦࡤࡸࠬ❑"))
dialogimagefile = os.path.join(l1l1ll1l11_l1_,l1l11l_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭࡟࠱࠲࠳࠴ࡤ࠴ࡰ࡯ࡩࠪ❒"))
l1l11l1l111_l1_ = xbmcaddon.Addon().getAddonInfo(l1l11l_l1_ (u"ࠨࡲࡤࡸ࡭࠭❓"))
defaulticon = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ❔"))
defaultthumb = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣ࠰ࡳࡲ࡬࠭❕"))
defaultfanart = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲࡯ࡶࡧࠨ❖"))
l11l1lll1ll_l1_ = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬ❗"))
l11lll111l1_l1_ = os.path.join(l1l11l1l111_l1_,l1l11l_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ❘"),l1l11l_l1_ (u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨ❙"))
l1l1111l1l1_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ❚"))
l11l11l1l1l_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ❛"),l1l11l_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ❜"),addon_id,l1l11l_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ❝"))
l1ll111ll1l_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ❞"),l1l11l_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ❟"),l1l11l_l1_ (u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ❠"))
fontfile = os.path.join(l1l1111ll11_l1_,l1l11l_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧ❡"),l1l11l_l1_ (u"ࠩࡉࡳࡳࡺࡳࠨ❢"),l1l11l_l1_ (u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭❣"))
l1ll1l1ll11_l1_ = 60
l1l111lllll_l1_ = 60*l1ll1l1ll11_l1_
l1111l1ll1l_l1_ = 24*l1l111lllll_l1_
l1l11llll11_l1_ = 30*l1111l1ll1l_l1_
NO_CACHE = 0
l11l1ll111l_l1_ = 30*l1ll1l1ll11_l1_
l111l11l_l1_ = 2*l1l111lllll_l1_
REGULAR_CACHE = 16*l1l111lllll_l1_
l1llll_l1_ = 3*l1111l1ll1l_l1_
l1llllll1l1_l1_ = 30*l1111l1ll1l_l1_
PERMANENT_CACHE = 12*l1l11llll11_l1_
LIMITED_CACHE = 1*l1l111lllll_l1_
def l11l1l111ll_l1_():
	status = l1l11l_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ❤")
	if os.path.exists(cache_dbfile): status = l1l11l_l1_ (u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨ❥")
	elif not os.path.exists(l1l1ll1l11_l1_): os.makedirs(l1l1ll1l11_l1_)
	else:
		l1ll111l11l_l1_ = [l1l11l_l1_ (u"࠭࠸࠯࠷࠱࠴ࠬ❦"),l1l11l_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫ❧"),l1l11l_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭❨"),l1l11l_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭❩"),l1l11l_l1_ (u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧ❪"),l1l11l_l1_ (u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨ❫"),l1l11l_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩ❬")]
		l11lll1111l_l1_ = l1ll111l11l_l1_[-1]
		l1l11ll11ll_l1_ = l1111l1llll_l1_(l11lll1111l_l1_)
		l11ll11llll_l1_ = l1111l1llll_l1_(addon_version)
		if l11ll11llll_l1_>l1l11ll11ll_l1_:
			files = os.listdir(l1l1ll1l11_l1_)
			files = sorted(files,reverse=True)
			for file in files:
				l1111l1lll1_l1_ = re.findall(l1l11l_l1_ (u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡࡠࠪ࠱࠮ࡄ࠯࡜࠯ࡦࡥࠫ❭"),file,re.DOTALL)
				if l1111l1lll1_l1_:
					l1111l1lll1_l1_ = l1111l1lll1_l1_[0]
					l11ll1l111l_l1_ = l1111l1llll_l1_(l1111l1lll1_l1_)
					if l11ll1l111l_l1_>l1l11ll11ll_l1_:
						l1l11l1l11l_l1_ = os.path.join(l1l1ll1l11_l1_,file)
						try: os.rename(l1l11l1l11l_l1_,cache_dbfile)
						except: pass
						l11l1llll1l_l1_ = l1l11l1l11l_l1_.replace(l1l11l_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢࡡࠪ❮"),l1l11l_l1_ (u"ࠨ࡫ࡳࡸࡻ࠷ࡤࡢࡶࡤࡣࠬ❯"))
						try: os.rename(l11l1llll1l_l1_,iptv1_dbfile)
						except: pass
						l111l11lll1_l1_ = l1l11l1l11l_l1_.replace(l1l11l_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬ❰"),l1l11l_l1_ (u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥࠧ❱"))
						try: os.rename(l111l11lll1_l1_,iptv2_dbfile)
						except: pass
						status = l1l11l_l1_ (u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ❲")
					elif l11ll1l111l_l1_==l1l11ll11ll_l1_: status = l1l11l_l1_ (u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨ❳")
					break
	return status
def l1l11111lll_l1_():
	global REGULAR_CACHE,l1llll_l1_,l111l11l_l1_,l1llllll1l1_l1_,l11l1ll111l_l1_,PERMANENT_CACHE,LIMITED_CACHE
	script_name = l1l11l_l1_ (u"࠭ࡍࡂࡋࡑࡑࡊࡔࡕࠨ❴")
	type,l1l1llllll1_l1_,l11l1lllll1_l1_,mode,l111ll11111_l1_,l11llll1111_l1_,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	l11l11l111l_l1_ = int(mode)
	l1l1l1ll111_l1_ = int(l11l11l111l_l1_%10)
	l11l11l11l1_l1_ = int(l11l11l111l_l1_/10)
	#l1ll1l11ll_l1_ = l1ll11lll1_l1_()
	l11ll11l111_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ❵"))
	l11ll11l111_l1_ = l11ll11l111_l1_.replace(ltr,l1l11l_l1_ (u"ࠨࠩ❶")).replace(rtl,l1l11l_l1_ (u"ࠩࠪ❷"))
	if l11l11l111l_l1_==260: message = l1l11l_l1_ (u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ❸")+addon_version+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ❹")+kodi_release+l1l11l_l1_ (u"ࠬࠦ࡝ࠨ❺")
	else:
		l1ll1l1l111_l1_ = UNQUOTE(addon_path).replace(l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ❻"),l1l11l_l1_ (u"ࠧࠨ❼")).replace(l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ❽"),l1l11l_l1_ (u"ࠩࠪ❾"))
		l1ll1l1l111_l1_ = l1ll1l1l111_l1_.replace(l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ❿"),l1l11l_l1_ (u"ࠫࠬ➀")).strip(l1l11l_l1_ (u"ࠬࠦࠧ➁"))
		l1ll1l1l111_l1_ = l1ll1l1l111_l1_.replace(l1l11l_l1_ (u"࠭ࠠࠡࠢࠣࠫ➂"),l1l11l_l1_ (u"ࠧࠡࠩ➃")).replace(l1l11l_l1_ (u"ࠨࠢࠣࠤࠬ➄"),l1l11l_l1_ (u"ࠩࠣࠫ➅")).replace(l1l11l_l1_ (u"ࠪࠤࠥ࠭➆"),l1l11l_l1_ (u"ࠫࠥ࠭➇"))
		message = l1l11l_l1_ (u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ➈")+l11ll11l111_l1_+l1l11l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭➉")+mode+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ➊")+l1ll1l1l111_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫ➋")
	LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ➌"),LOGGING(script_name)+message)
	if settings.getSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ➍")) not in [l1l11l_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ➎"),l1l11l_l1_ (u"࡙ࠬࡔࡐࡒࠪ➏"),l1l11l_l1_ (u"࠭ࡁࡔࡍࠪ➐")]: settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ➑"),l1l11l_l1_ (u"ࠨࡃࡖࡏࠬ➒"))
	if settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ➓")) not in [l1l11l_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ➔"),l1l11l_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ➕"),l1l11l_l1_ (u"ࠬࡇࡓࡌࠩ➖")]: settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ➗"),l1l11l_l1_ (u"ࠧࡂࡕࡎࠫ➘"))
	if settings.getSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ➙")) not in [l1l11l_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ➚"),l1l11l_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ➛"),l1l11l_l1_ (u"ࠫࡘࡎࡏࡓࡖࠪ➜")]: settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ➝"),l1l11l_l1_ (u"࠭ࡁࡖࡖࡒࠫ➞"))
	if not settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ➟")): settings.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ➠"),DNS_SERVERS[0])
	l11l111111l_l1_ = l11l1l111ll_l1_()
	l1l11l1ll11_l1_ = (l11l111111l_l1_ in [l1l11l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ➡"),l1l11l_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ➢")])
	l11l111l1ll_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮࡯ࡧࡺࡣࡷ࡫࡬ࡦࡣࡶࡩࠬ➣"))
	if l1l11l1ll11_l1_ or l11l111l1ll_l1_:
		settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡰࡨࡻࡤࡸࡥ࡭ࡧࡤࡷࡪ࠭➤"),l1l11l_l1_ (u"࠭࡮ࡰࡶࡢࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ➥"))
		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ➦"),l1l11l_l1_ (u"ࠨࠩ➧"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ➨"),l1l11l_l1_ (u"ࠪฮ๊ࠦสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣห้ึ๊ࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫ➩")+addon_version)
		#l1ll111l1l1_l1_([cache_dbfile])
		if l11l111111l_l1_==l1l11l_l1_ (u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ➪"):
			LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ➫"),l1l11l_l1_ (u"࠭࠮ࠡࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭➬")+addon_path+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ➭"))
			DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭➮"),l1l11l_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ➯"))
			DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࠨ➰"),l1l11l_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ➱"))
		else:
			LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ➲"),l1l11l_l1_ (u"࠭࠮ࠡࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ➳")+addon_path+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ➴"))
			DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ➵"),l1l11l_l1_ (u"ࠩࠪ➶"),l1l11l_l1_ (u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭➷"),l1l11l_l1_ (u"ࠫฯ๋ࠠหอห๎ฯࠦร้ࠢอัิ๐หࠡษ็ษฺีวาࠢส่ัี๊ะࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣ࠲ู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ➸"))
			l1ll111l1l1_l1_()
			FIX_OR_CREATE_ALL_DATABASES(False)
			l1l1ll11l11_l1_ = l1l11ll111l_l1_(32)
			import l111l1l111l_l1_
			l111l1l111l_l1_.l1l1l11l1ll_l1_()
			l111l1l111l_l1_.l111ll1llll_l1_()
			l111l1l111l_l1_.l1ll11ll1l1_l1_(l1l11l_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ➹"),False)
			l111l1l111l_l1_.l1ll11ll1l1_l1_(l1l11l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ➺"),False)
			l111l1l111l_l1_.l11llllll1l_l1_(False)
			l111l1l111l_l1_.l111ll11lll_l1_(False)
			l111l1l111l_l1_.l1l11lllll1_l1_(l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ➻"),l1l11l_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ➼"),False)
			CHECK_CACHED_FILES(False)
			l1l11l_l1_ (u"ࠤࠥࠦࠒࠐࠉࠊࠋࡷࡶࡾࡀࠍࠋࠋࠌࠍࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹࡦࡪ࡮ࡨ࠶ࠥࡃࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯࡬ࡲ࡭ࡳ࠮ࡵࡴࡧࡵࡪࡴࡲࡤࡦࡴ࠯ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ࠬࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ࠲ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧ࠭ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨࠫࠐࠎࠎࠏࠉࠊࡵࡨࡸࡹ࡯࡮ࡨࡵ࠵ࠤࡂࠦࡸࡣ࡯ࡦࡥࡩࡪ࡯࡯࠰ࡄࡨࡩࡵ࡮ࠩ࡫ࡧࡁࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ࠯ࠍࠋࠋࠌࠍࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠲࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭࡫ࡰࡦ࡬ࡳࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡷࡵࡢ࡮࡬ࡸࡾ࠴ࡡࡴ࡭ࠪ࠰ࠬࡺࡲࡶࡧࠪ࠭ࠒࠐࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠎࠌࠌࠍࠎࠨࠢࠣ➽")
			try:
				l1ll1111111_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ➾"),l1l11l_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ➿"),l1l11l_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ⟀"),l1l11l_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ⟁"))
				l111l11l111_l1_ = xbmcaddon.Addon(id=l1l11l_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ⟂"))
				l111l11l111_l1_.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧ⟃"),l1l11l_l1_ (u"ࠩࡩࡥࡱࡹࡥࠨ⟄"))
			except: pass
			try:
				l1ll1111111_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ⟅"),l1l11l_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ⟆"),l1l11l_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ⟇"),l1l11l_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ⟈"))
				l111l11l111_l1_ = xbmcaddon.Addon(id=l1l11l_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ⟉"))
				l111l11l111_l1_.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫ⟊"),l1l11l_l1_ (u"ࠩ࠶ࠫ⟋"))
			except: pass
			try:
				l1ll1111111_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ⟌"),l1l11l_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ⟍"),l1l11l_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ⟎"),l1l11l_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ⟏"))
				l111l11l111_l1_ = xbmcaddon.Addon(id=l1l11l_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ⟐"))
				l111l11l111_l1_.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭⟑"),l1l11l_l1_ (u"ࠩ࠵ࠫ⟒"))
			except: pass
			if os.path.exists(dummyiptvfile):
				#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⟓"),l1l11l_l1_ (u"ࠫࠬ⟔"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⟕"),l1l11l_l1_ (u"࠭ลัษࠣ็๋ะࠠหีอาิ๋ࠠฯั่อࠥๆࡉࡑࡖ࡙ࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤฯ๊โศศํหࠥฮฬๅส้้ࠣ็วหࠢใࡍࡕ࡚ࡖࠡฮา๎ิฯࠧ⟖"))
				import IPTV
				IPTV.CREATE_STREAMS()
		l1111l11ll1_l1_ = FIX_AND_GET_FILE_CONTENTS(l11l1ll1lll_l1_,False)
		favouritesDICT = FIX_AND_GET_FILE_CONTENTS(favouritesfile,False)
		settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡲࡪࡽ࡟ࡳࡧ࡯ࡩࡦࡹࡥࠨ⟗"),l1l11l_l1_ (u"ࠨࠩ⟘"))
		return
	l111l1l1ll1_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ⟙"))
	if l111l1l1ll1_l1_==l1l11l_l1_ (u"ࠪࠫ⟚") or now-int(l111l1l1ll1_l1_)>REGULAR_CACHE:
		#l1ll111l1l1_l1_([cache_dbfile,iptv1_dbfile,iptv2_dbfile])
		settings.setSetting(l1l11l_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ⟛"),l1l11l_l1_ (u"ࠬ࠭⟜"))
	l11l1ll1l11_l1_ = 0
	l1l1l1lll11_l1_ = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ⟝"))
	if len(l1l1l1lll11_l1_)==15:
		first,second,l111l1l1_l1_ = l1l1l1lll11_l1_[0:4],l1l1l1lll11_l1_[4:9],l1l1l1lll11_l1_[9:]
		first = int(first)^l111l11l_l1_
		second = int(second)^REGULAR_CACHE
		l111l1l1_l1_ = int(l111l1l1_l1_)^l1llll_l1_
		if first==second==l111l1l1_l1_:
			l11l1ll1l11_l1_ = first*60
			if l11l1l11lll_l1_(l1l11l_l1_ (u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭⟞")): l11l1ll1l11_l1_ = l11l1ll1l11_l1_*2
	l1l1lll11l1_l1_ = l1l11l_l1_ (u"ࠨ࠳࠹ࠫ⟟")+settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ⟠"))
	if l1l1lll11l1_l1_: l1l1lll11l1_l1_ = int(l1l1lll11l1_l1_)^l1llllll1l1_l1_
	if (not l1l1lll11l1_l1_ or not l11l1ll1l11_l1_ or now-int(l1l1lll11l1_l1_)<=0 or now-int(l1l1lll11l1_l1_)>l11l1ll1l11_l1_):
		if not l11l1l11lll_l1_(l1l11l_l1_ (u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ⟡")):
			# https://l111ll1l11l_l1_.l11ll1l11ll_l1_.com/l111lll111l_l1_/l11llll1lll_l1_
			# unescapeHTML(l1l11l_l1_ (u"ࠫࠥࠬࠣࡹ࠴࠹࠷ࡇࡁࠠࠧࠥࡻ࠶࠼࠷ࡄ࠼ࠢࠩࠧࡽ࠸࠶࠳ࡃ࠾ࠤࠫࠩࡸ࠳࠸࠶ࡆࡀ࠭⟢"))
			#l11ll11ll1l_l1_ = l1l11l_l1_ (u"ࠬ⹁ࠠ⼞ࠢࠣ⾎ࠥࠦ⸪ࠡ⸽ࠪ⟣")
			#l11llllllll_l1_ = l1l11l_l1_ (u"࠭⸻ࠡ⼟ࠣࠤ⾐ࠦࠠ⸫ࠢ⸾ࠫ⟤")
			l111llllll1_l1_ = l1ll1l1l1ll_l1_()
			if l111llllll1_l1_:
				LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ⟥"),l1l11l_l1_ (u"ࠨ࠰ࠣࠤ࡙ࠥࡨࡰࡹ࡬ࡲ࡬ࠦࡑࡶࡧࡶࡸ࡮ࡵ࡮ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ⟦")+addon_path+l1l11l_l1_ (u"ࠩࠣࡡࠬ⟧"))
				id,l1111l1ll11_l1_,l111l11ll11_l1_,answer,l1l1l1lllll_l1_,reason = l111llllll1_l1_[0]
				l1l111lll11_l1_,l1l111lll1l_l1_ = answer.split(l1l11l_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ⟨"))
				del l111llllll1_l1_[0]
				l11l11l11ll_l1_ = random.sample(l111llllll1_l1_,1)
				id,l1111l1ll11_l1_,l111l11ll11_l1_,answer,l1l1l1lllll_l1_,reason = l11l11l11ll_l1_[0]
				l111l11ll11_l1_ = l1l11l_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥࡀࠠࠨ⟩")+id+l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⟪")+l111l11ll11_l1_
				button0,button1,l1l11ll1l11_l1_ = answer,l1l1l1lllll_l1_,reason
				l1l1ll1l_l1_ = [button0,button1,l11lllll11l_l1_]
				choice = -9
				while choice<0:
					l1l1llll111_l1_ = random.sample(l1l1ll1l_l1_,3)
					choice = l1111lll1ll_l1_(l1l11l_l1_ (u"࠭ࠧ⟫"),l1l1llll111_l1_[0],l1l1llll111_l1_[1],l1l1llll111_l1_[2],l1l111lll11_l1_,l111l11ll11_l1_,5,60)
					if choice==10: break
					if choice>=0 and l1l1llll111_l1_[choice]==l1l1ll1l_l1_[1]:
						choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠧࠨ⟬"),l1l11l_l1_ (u"ࠨࠩ⟭"),l1l11l_l1_ (u"ࠩ฼์ิฯࠧ⟮"),l1l11l_l1_ (u"ࠪࠫ⟯"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⟰"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆฯ์ฬฮࠠฯูฦ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠧ⟱")+l1l11ll1l11_l1_,10)
						if choice>=0: choice = -9
					elif choice>=0 and l1l1llll111_l1_[choice]==l1l1ll1l_l1_[2]:
						choice = l1111lll1ll_l1_(l1l11l_l1_ (u"࠭ࠧ⟲"),l1l11l_l1_ (u"ࠧࠨ⟳"),l11lllll11l_l1_,l1l11l_l1_ (u"ࠨࠩ⟴"),l1l111lll11_l1_,l111l11ll11_l1_+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ⟵")+l1l1ll1l_l1_[0]+l1l11l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⟶"),30)
					if choice==-1: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⟷"),l1l11l_l1_ (u"ࠬ࠭⟸"),l1l11l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⟹"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ัีําࠠฯูฦ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨ⟺"))
				settings.setSetting(l1l11l_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ⟻"),str(now^l1llllll1l1_l1_)[2:])
				WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧ⟼"),l1l11l_l1_ (u"ࠪࡅ࡚࡚ࡈࠨ⟽"),1,PERMANENT_CACHE)
			else: WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࠩ⟾"),l1l11l_l1_ (u"ࠬࡇࡕࡕࡊࠪ⟿"),0,PERMANENT_CACHE)
		else:
			settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ⠀"),str(now^l1llllll1l1_l1_)[2:])
			WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧࡎࡋࡖࡇࠬ⠁"),l1l11l_l1_ (u"ࠨࡃࡘࡘࡍ࠭⠂"),1,PERMANENT_CACHE)
	if l1l11l1ll11_l1_: l111l1l111l_l1_.l1ll1l11111_l1_(False)
	if l1l11l_l1_ (u"ࠩࡢࠫ⠃") in context: l11l1l1ll11_l1_,context2 = context.split(l1l11l_l1_ (u"ࠪࡣࠬ⠄"),1)
	else: l11l1l1ll11_l1_,context2 = context,l1l11l_l1_ (u"ࠫࠬ⠅")
	if l11l1l1ll11_l1_ in [l1l11l_l1_ (u"ࠬ࠷ࠧ⠆"),l1l11l_l1_ (u"࠭࠲ࠨ⠇"),l1l11l_l1_ (u"ࠧ࠴ࠩ⠈"),l1l11l_l1_ (u"ࠨ࠶ࠪ⠉"),l1l11l_l1_ (u"ࠩ࠸ࠫ⠊")] and context2:
		import FAVOURITES
		FAVOURITES.FAVOURITES_DISPATCHER(context)
		#l1l11l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ⠋") l1ll111ll1_l1_ l111ll1l111_l1_ l111l11ll1l_l1_ is no addon_handle l1l1l1111ll_l1_ to l1ll1111ll1_l1_ for l11lll1ll11_l1_ directory
		#l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠧ⠌") l1ll111ll1_l1_ to open a l11111l1l_l1_ list l111lll11l1_l1_ l111ll1ll1l_l1_ addon_path
		#xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ⠍")+sys.argv[0]+addon_path.split(l1l11l_l1_ (u"࠭ࠦࡤࡱࡱࡸࡪࡾࡴ࠾ࠩ⠎"))[0]+l1l11l_l1_ (u"ࠧࠧࡥࡲࡲࡹ࡫ࡸࡵ࠿࠳ࠫ⠏")+l1l11l_l1_ (u"ࠣࠫࠥ⠐"))
		#xbmc.executebuiltin(l1l11l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ⠑")+addon_id+l1l11l_l1_ (u"ࠪ࠳ࡄࡺࡥࡹࡶࡀࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣ࠮࠭⠒"))
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ⠓"))
		#l1ll111l111_l1_(l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡍࡂࡋࡑࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ⠔"))
		return
	elif l11l1l1ll11_l1_==l1l11l_l1_ (u"࠭࠶ࠨ⠕"):
		if context2==l1l11l_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ⠖"): DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨ⠗"),l1l11l_l1_ (u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩ⠘"))
		elif context2==l1l11l_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠪ⠙"): mode = 334
		results = l111lllllll_l1_(type,l1l1llllll1_l1_,l11l1lllll1_l1_,mode,l111ll11111_l1_,l11llll1111_l1_,text,context,infodict)
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ⠚"))
		return
	elif context==l1l11l_l1_ (u"ࠬ࠽ࠧ⠛"):
		import l111lll1ll_l1_
		l111lll1ll_l1_.l1lllll1ll1_l1_()
		xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ⠜"))
		return
	elif context==l1l11l_l1_ (u"ࠧ࠹ࠩ⠝"):
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ⠞")+addon_id+l1l11l_l1_ (u"ࠩࡂࡱࡴࡪࡥ࠾ࠩ⠟")+str(mode)+l1l11l_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠫࠪ⠠"))
		return
	elif context==l1l11l_l1_ (u"ࠫ࠾࠭⠡"):
		REGULAR_CACHE 	= -REGULAR_CACHE
		l1llll_l1_ 		= -l1llll_l1_
		l111l11l_l1_ 	= -l111l11l_l1_
		l1llllll1l1_l1_ 	= -l1llllll1l1_l1_
		l11l1ll111l_l1_ = -l11l1ll111l_l1_
		PERMANENT_CACHE = -PERMANENT_CACHE
		LIMITED_CACHE 	= -LIMITED_CACHE
		# l1111ll1ll1_l1_ update the l111l111111_l1_ l11111l1l_l1_
		#results = l111lllllll_l1_(type,l1l1llllll1_l1_,l11l1lllll1_l1_,mode,l111ll11111_l1_,l11llll1111_l1_,text,context,infodict)
		# l1111ll1ll1_l1_ update the l11lll1l11l_l1_ l11111l1l_l1_
		xbmc.executebuiltin(l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ⠢"))
		return
	if l11l11l111l_l1_==266:
		import l111l1lll11_l1_
		l111l1lll11_l1_.l111ll111l1_l1_(text)
		xbmc.executebuiltin(l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ⠣"))
		#l1ll111l111_l1_(l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡏࡄࡍࡓࡓࡅࡏࡗ࠰࠷ࡷࡪࠧ⠤"))
		return
	# l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⠥")	l1ll1111ll1_l1_ file to read/write the l111lllll1l_l1_ l11111l1l_l1_ list
	# l1l11l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⠦")		no l1ll1lllll1_l1_ l111ll11ll1_l1_ to the l111lllll1l_l1_ l11111l1l_l1_ list
	l1l111l11ll_l1_ = [0,15,17,19,26,34,50,53]
	l1ll11l111l_l1_ = l11l11l11l1_l1_ not in l1l111l11ll_l1_
	l1l1l111111_l1_ = l1ll11l111l_l1_ and l1l1l1ll111_l1_==9
	l1l11lll1l1_l1_ = l11l11l111l_l1_ in [145,516,523]
	l1ll1l1l1l1_l1_ = l1l1l111111_l1_ or l1l11lll1l1_l1_
	l1l111111l1_l1_ = l11l11l11l1_l1_==16 and l11l11l111l_l1_!=160
	l1l1ll111l1_l1_ = l11l11l111l_l1_ in [144]
	l1l111ll1ll_l1_ = l11l11l11l1_l1_==23 and text
	l1l1llll11l_l1_ = l11l11l111l_l1_ not in [265,270]
	#l1l1llllll1_l1_ = l1ll11lll1_l1_(l1l1llllll1_l1_)
	l1l1llllll1_l1_ = RESTORE_PATH_NAME(l1l1llllll1_l1_)
	l1ll1l11ll_l1_ = RESTORE_PATH_NAME(l11ll11l111_l1_)
	l1111ll11l1_l1_ = l1ll1l1l1l1_l1_ or l1l111111l1_l1_ or l1l1ll111l1_l1_
	if l1111ll11l1_l1_:
		#if l1l111111l1_l1_: cond1 = (l1ll1l11ll_l1_ in [l1l11l_l1_ (u"ࠪ࠲࠳࠭⠧"),l1l11l_l1_ (u"ࠫࡒࡧࡩ࡯ࠢࡐࡩࡳࡻࠧ⠨")])
		#elif l1ll1l1l1l1_l1_: cond1 = (l1ll1l11ll_l1_!=l1l1llllll1_l1_)
		if l1l11l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⠩") in text and l1ll1l11ll_l1_!=l1l1llllll1_l1_ and os.path.exists(l11llll1l1l_l1_):
			LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⠪"),l1l11l_l1_ (u"ࠧ࠯ࠢࠣࠤࡗ࡫ࡡࡥ࡫ࡱ࡫ࠥࡲࡡࡴࡶࠣࡱࡪࡴࡵࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ⠫")+addon_path+l1l11l_l1_ (u"ࠨࠢࡠࠫ⠬"))
			oldFILE = open(l11llll1l1l_l1_,l1l11l_l1_ (u"ࠩࡵࡦࠬ⠭")).read()
			if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⠮"))
			menuItemsLIST[:] = EVAL(l1l11l_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⠯"),oldFILE)
		else:
			LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⠰"),l1l11l_l1_ (u"࠭࠮࡛ࠡࠢࠣࡷ࡯ࡴࡪࡰࡪࠤࡱࡧࡳࡵࠢࡰࡩࡳࡻࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ⠱")+addon_path+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ⠲"))
			results = l111lllllll_l1_(type,l1l1llllll1_l1_,l11l1lllll1_l1_,mode,l111ll11111_l1_,l11llll1111_l1_,text,context,infodict)
			newFILE = str(menuItemsLIST)
			if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⠳"))
			open(l11llll1l1l_l1_,l1l11l_l1_ (u"ࠩࡺࡦࠬ⠴")).write(newFILE)
	else: results = l111lllllll_l1_(type,l1l1llllll1_l1_,l11l1lllll1_l1_,mode,l111ll11111_l1_,l11llll1111_l1_,text,context,infodict)
	# l1ll1l1l11l_l1_ l1ll1l11lll_l1_: succeeded,l1l11l111l1_l1_,l1ll11ll1ll_l1_ = True,False,True
	# l1l11l111l1_l1_ = True => l11lll11l1l_l1_ this list is l11l111l11l_l1_ and will exit to main l11111l1l_l1_
	# l1l11l111l1_l1_ = False => l11lll11l1l_l1_ this list is l1l1l11l11l_l1_ and will exit to l111lllll1l_l1_ l11111l1l_l1_
	# l1ll11ll1ll_l1_ = True => will cause the l1111ll1l1l_l1_ status to l11llll11l1_l1_ l11l11l1l11_l1_
	# l1ll11ll1ll_l1_ = False => will l11l111lll1_l1_ the l1111ll1l1l_l1_ status to l1l11llllll_l1_ l1l11ll11l1_l1_
	succeeded,l1l11l111l1_l1_,l1ll11ll1ll_l1_ = True,False,True
	#if not l1ll1l1l1l1_l1_: l1ll11ll1ll_l1_ = False
	if l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⠵") in text: l1l11l111l1_l1_ = True
	if type==l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⠶") and l1ll1l11ll_l1_!=l1l11l_l1_ (u"ࠬ࠴࠮ࠨ⠷") and (l1ll11l111l_l1_ or l1l111ll1ll_l1_) and l1l1llll11l_l1_: l1l11l1l1ll_l1_()
	if type==l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⠸") and addon_handle>-1:
		if (READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠧࡪࡰࡷࠫ⠹"),l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭⠺"),l1l11l_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ⠻")) or l11l11l111l_l1_ not in l1l111l11ll_l1_) and not l11l1l11lll_l1_(l1l11l_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ⠼")):
			KodiMenuList = []
			import l111l1lll11_l1_
			KodiMenuList = GET_ALL_KODI_MENU_ITEMS(l111l1lll11_l1_.l11lll11l11_l1_)
			l1l1lllll11_l1_ = xbmcplugin.addDirectoryItems(addon_handle,KodiMenuList)
			xbmcplugin.setContent(addon_handle,l1l11l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ⠽"))
			#succeeded,l1l11l111l1_l1_,l1ll11ll1ll_l1_ = True,False,True
		else:
			xbmcplugin.l1ll111llll_l1_(addon_handle,l1l11l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ⠾")+addon_id+l1l11l_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭⠿"),xbmcgui.ListItem(l1l11l_l1_ (u"ࠧๅัํ็๋ࠥิไๆฬࠤ๊์ࠠอ้สึ่࠭⡀")))
			xbmcplugin.l1ll111llll_l1_(addon_handle,l1l11l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ⡁")+addon_id+l1l11l_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ⡂"),xbmcgui.ListItem(l1l11l_l1_ (u"ࠪวๆะอࠡๆอๆึษࠠศๆอๅฬ฻๊ๅࠩ⡃")))
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1l11l111l1_l1_,l1ll11ll1ll_l1_)
	return
def l111lllllll_l1_(type,name,url,mode,image,page,text,context,infodict):
	l11l11l111l_l1_ = int(mode)
	l11l11l11l1_l1_ = int(l11l11l111l_l1_//10)
	if   l11l11l11l1_l1_==0:  import l111l1l111l_l1_ 	; results = l111l1l111l_l1_.MAIN(l11l11l111l_l1_,text)
	elif l11l11l11l1_l1_==1:  import l1l111l1_l1_ 		; results = l1l111l1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==2:  import l1llll1l1l1_l1_ 		; results = l1llll1l1l1_l1_.MAIN(l11l11l111l_l1_,url,page,text)
	elif l11l11l11l1_l1_==3:  import l1l1ll1ll11_l1_ 		; results = l1l1ll1ll11_l1_.MAIN(l11l11l111l_l1_,url,page,text)
	elif l11l11l11l1_l1_==4:  import l1lll1l11_l1_ 	; results = l1lll1l11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==5:  import l1ll1l1lll1_l1_ 	; results = l1ll1l1lll1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==6:  import l1lllllll_l1_ 	; results = l1lllllll_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==7:  import l11l1_l1_ 		; results = l11l1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==8:  import l1llll1ll11_l1_ 	; results = l1llll1ll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==9:  import l11111lll_l1_		; results = l11111lll_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==10: import l11ll111lll_l1_ 		; results = l11ll111lll_l1_.MAIN(l11l11l111l_l1_,url)
	elif l11l11l11l1_l1_==11: import l111lll1lll_l1_ 	; results = l111lll1lll_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==12: import l1l111111l_l1_ 		; results = l1l111111l_l1_.MAIN(l11l11l111l_l1_,url,page,text)
	elif l11l11l11l1_l1_==13: import l1lll1l1l_l1_	; results = l1lll1l1l_l1_.MAIN(l11l11l111l_l1_,url,page,text)
	elif l11l11l11l1_l1_==14: import l1ll1l11l11_l1_ 		; results = l1ll1l11l11_l1_.MAIN(l11l11l111l_l1_,url,text,type,page)
	elif l11l11l11l1_l1_==15: import l111l1l111l_l1_ 	; results = l111l1l111l_l1_.MAIN(l11l11l111l_l1_,text)
	elif l11l11l11l1_l1_==16: import l111ll1l1ll_l1_	 	; results = l111ll1l1ll_l1_.MAIN(l11l11l111l_l1_,url,text,page)
	elif l11l11l11l1_l1_==17: import l111l1l111l_l1_ 	; results = l111l1l111l_l1_.MAIN(l11l11l111l_l1_,text)
	elif l11l11l11l1_l1_==18: import l1111lllll1_l1_	; results = l1111lllll1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==19: import l111l1l111l_l1_ 	; results = l111l1l111l_l1_.MAIN(l11l11l111l_l1_,text)
	elif l11l11l11l1_l1_==20: import l1l11l111_l1_		; results = l1l11l111_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==21: import l1l1l1l1l1l_l1_ ; results = l1l1l1l1l1l_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==22: import l11l1l1l11_l1_ 	; results = l11l1l1l11_l1_.MAIN(l11l11l111l_l1_,url,page,text)
	elif l11l11l11l1_l1_==23: import IPTV 		; results = IPTV.MAIN(l11l11l111l_l1_,url,text,type,page)
	elif l11l11l11l1_l1_==24: import l11ll1_l1_ 		; results = l11ll1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==25: import l1l1l1l11_l1_ 	; results = l1l1l1l11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==26: import l111l1lll11_l1_ 		; results = l111l1lll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==27: import FAVOURITES 	; results = FAVOURITES.MAIN(l11l11l111l_l1_,context)
	elif l11l11l11l1_l1_==28: import IPTV 		; results = IPTV.MAIN(l11l11l111l_l1_,url,text,type,page)
	elif l11l11l11l1_l1_==29: import l1ll11l1l1l_l1_	; results = l1ll11l1l1l_l1_.MAIN(l11l11l111l_l1_,url,page,text)
	elif l11l11l11l1_l1_==30: import l11111111_l1_		; results = l11111111_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==31: import l1l1lll1111_l1_	; results = l1l1lll1111_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==32: import l1lll1l1111_l1_	; results = l1lll1l1111_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==33: import l1l1llll1l_l1_		; results = l1l1llll1l_l1_.MAIN(l11l11l111l_l1_,url)
	elif l11l11l11l1_l1_==34: import l111l1l111l_l1_ 	; results = l111l1l111l_l1_.MAIN(l11l11l111l_l1_,text)
	elif l11l11l11l1_l1_==35: import l1111ll_l1_		; results = l1111ll_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==36: import l11l1ll1l1l_l1_		; results = l11l1ll1l1l_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==37: import l11ll1l11_l1_		; results = l11ll1l11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==38: import l11l111ll11_l1_ 		; results = l11l111ll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==39: import l1111lll11_l1_	; results = l1111lll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==40: import l1lll11l1l_l1_	; results = l1lll11l1l_l1_.MAIN(l11l11l111l_l1_,url,text,type,page)
	elif l11l11l11l1_l1_==41: import l1lll11l1l_l1_	; results = l1lll11l1l_l1_.MAIN(l11l11l111l_l1_,url,text,type,page)
	elif l11l11l11l1_l1_==42: import l11l1ll1l_l1_		; results = l11l1ll1l_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==43: import l11l11l1l1_l1_		; results = l11l11l1l1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==44: import l11l11l1ll_l1_		; results = l11l11l1ll_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==45: import l1ll1lll11l_l1_		; results = l1ll1lll11l_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==46: import l1l1111l1ll_l1_		; results = l1l1111l1ll_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==47: import l1111111l_l1_	; results = l1111111l_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==48: import l111l1llll1_l1_		; results = l111l1llll1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==49: import l111l111l_l1_		; results = l111l111l_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==50: import l111l1l111l_l1_ 	; results = l111l1l111l_l1_.MAIN(l11l11l111l_l1_,text)
	elif l11l11l11l1_l1_==51: import l111lll1l1_l1_ 	; results = l111lll1l1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==52: import l111lll1l1_l1_ 	; results = l111lll1l1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==53: import l111l1lll11_l1_ 		; results = l111l1lll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==54: import l111lll1ll_l1_	; results = l111lll1ll_l1_.MAIN(l11l11l111l_l1_,url,text,page)
	elif l11l11l11l1_l1_==55: import l111l1ll1_l1_ 	; results = l111l1ll1_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==56: import l111l1lll11_l1_ 		; results = l111l1lll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	elif l11l11l11l1_l1_==57: import l111lllll11_l1_		; results = l111lllll11_l1_.MAIN(l11l11l111l_l1_,url,text)
	else: results = None
	return results
def l1ll11lll1_l1_(name=l1l11l_l1_ (u"ࠫࠬ⡄")):
	if not name: name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭⡅"))
	name = name.replace(l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ⡆"),l1l11l_l1_ (u"ࠧࠨ⡇"))
	name = name.replace(l1l11l_l1_ (u"ࠨࠢࠣࠤࠥ࠭⡈"),l1l11l_l1_ (u"ࠩࠣࠫ⡉")).replace(l1l11l_l1_ (u"ࠪࠤࠥࠦࠧ⡊"),l1l11l_l1_ (u"ࠫࠥ࠭⡋")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ⡌"),l1l11l_l1_ (u"࠭ࠠࠨ⡍")).strip(l1l11l_l1_ (u"ࠧࠡࠩ⡎"))
	name = name.replace(l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ⡏"),l1l11l_l1_ (u"ࠩࠪ⡐")).replace(l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭⡑"),l1l11l_l1_ (u"ࠫࠬ⡒"))
	tmp = re.findall(l1l11l_l1_ (u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡࠩ⡓"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l11l_l1_ (u"࠭ࡍࡢ࡫ࡱࠤࡒ࡫࡮ࡶࠩ⡔")
	return name
class l11l1lll1l1_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l1l11l_l1_ (u"ࠧࠨ⡕")
	def onPlayBackStopped(self):
		self.status=l1l11l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ⡖")
	def onPlayBackStarted(self):
		if l11l1l11lll_l1_(l1l11l_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ⡗")):
			self.stop()
			self.status=l1l11l_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ⡘")
		else: self.status=l1l11l_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ⡙")
		time.sleep(1)
	def onPlayBackError(self):
		self.status=l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ⡚")
	def onPlayBackEnded(self):
		self.status=l1l11l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭⡛")
class l1l1ll1l111_l1_():
	def __init__(self,showDialogs=False,l11l11lll11_l1_=True):
		self.showDialogs = showDialogs
		self.l11l11lll11_l1_ = l11l11lll11_l1_
		self.l1l1lll1l11_l1_,self.l1lll111111_l1_ = [],[]
		self.l1l111ll1l1_l1_,self.l1l111l11l1_l1_ = {},{}
		self.l1l1l1111l1_l1_ = []
		self.l1l111l1lll_l1_,self.l111l1l11ll_l1_,self.l1ll1l1llll_l1_ = {},{},{}
	def l1l1l1llll1_l1_(self,id,func,*args):
		id = str(id)
		self.l1l111ll1l1_l1_[id] = l1l11l_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ⡜")
		if self.showDialogs: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠨࠩ⡝"),id)
		# l1l1l111l1l_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1l1l111l1l_l1_ 2 & 3
		import threading
		l1ll1lll111_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1l1l1111l1_l1_.append(l1ll1lll111_l1_)
		#l1ll1lll111_l1_.start()
		return l1ll1lll111_l1_
	def start_new_thread(self,id,func,*args):
		l1ll1lll111_l1_ = self.l1l1l1llll1_l1_(id,func,*args)
		l1ll1lll111_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l111l1lll_l1_[id] = time.time()
		#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⡞"),l1l11l_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡷࡹࡧࡲࡵࡧࡧࠤ࡮ࡪ࠺ࠡࠩ⡟")+id)
		try:
			#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ⡠"),l1l11l_l1_ (u"ࠬࡋࡍࡂࡆ࠽࠾ࠥ࠭⡡")+str(func))
			self.l1l111l11l1_l1_[id] = func(*args)
			if l1l11l_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧ⡢") in str(func) and not self.l1l111l11l1_l1_[id].succeeded:
				raise SystemError(l1l11l_l1_ (u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡺࡨࡳࡧࡤࡨࡪࡪࠠࡐࡒࡈࡒ࡚ࡘࡌࠡࡨࡤ࡭ࡱ࠭⡣"))
			self.l1l1lll1l11_l1_.append(id)
			self.l1l111ll1l1_l1_[id] = l1l11l_l1_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠪ⡤")
			#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⡥"),l1l11l_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡪ࡮ࡴࡩࡴࡪࡨࡨࠥ࡯ࡤ࠻ࠢࠪ⡦")+id)
		except Exception as err:
			#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⡧"),l1l11l_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥ࡯ࡤ࠻ࠢࠪ⡨")+id)
			if self.l11l11lll11_l1_:
				errortrace = traceback.format_exc()
				sys.stderr.write(errortrace)
				#traceback.print_exc(file=sys.stderr)
			self.l1lll111111_l1_.append(id)
			self.l1l111ll1l1_l1_[id] = l1l11l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭⡩")
		self.l111l1l11ll_l1_[id] = time.time()
		self.l1ll1l1llll_l1_[id] = self.l111l1l11ll_l1_[id] - self.l1l111l1lll_l1_[id]
	def l11l11ll1ll_l1_(self):
		for proc in self.l1l1l1111l1_l1_:
			proc.start()
	def l11l1l1l1ll_l1_(self):
		while l1l11l_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ⡪") in list(self.l1l111ll1l1_l1_.values()): time.sleep(1.000)
def SHOW_NETWORK_ERRORS(code,reason,source,showDialogs):
	if l1l11l_l1_ (u"ࠨ࠯ࠪ⡫") in source: site = source.split(l1l11l_l1_ (u"ࠩ࠰ࠫ⡬"),1)[0]
	else: site = source
	l1l1lllllll_l1_ = (code in [7,11001,11002,10054])
	l1111lll11l_l1_ = reason.lower()
	l11ll1ll1ll_l1_ = (code in [0,104,10061,111])
	l11ll1ll1l1_l1_ = (l1l11l_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ⡭") in l1111lll11l_l1_)
	l11ll1ll11l_l1_ = (l1l11l_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ⡮") in l1111lll11l_l1_)
	l11ll1ll111_l1_ = (l1l11l_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡪࡳࡴ࡭࡬ࡦࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ⡯") in l1111lll11l_l1_)
	proxy_status = settings.getSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ⡰"))
	dns_status = settings.getSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ⡱"))
	l1l111l1111_l1_ = l1l11l_l1_ (u"ࠨใื่ࠥฮำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ⡲")
	l1l11111ll1_l1_ = l1l11l_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠩ⡳")+str(code)+l1l11l_l1_ (u"ࠪ࠾ࠥ࠭⡴")+reason
	if l11ll1ll1ll_l1_ or l11ll1ll1l1_l1_ or l11ll1ll11l_l1_ or l11ll1ll111_l1_:
		l1l111l1111_l1_ += l1l11l_l1_ (u"ࠫࠥ࠴ࠠศๆ่์็฿ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯู๋่ࠢิื็ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡสส่๊๎โฺ࡞ࡱࠫ⡵")
	if l1l1lllllll_l1_: l1l111l1111_l1_ += l1l11l_l1_ (u"ࠬࠦ࠮ࠡๆา๎่ࠦฮุลࠣࡈࡓ้࡙ࠠ็฼๊ฬํࠠห฻ำีࠥะัอ็ฬࠤฬูๅࠡษ็้ํู่ࠡว็ํࠥืโๆ้࡟ࡲࠬ⡶")
	l1l11111ll1_l1_ = l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ⡷")+l1l11111ll1_l1_+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⡸")
	if proxy_status==l1l11l_l1_ (u"ࠨࡃࡖࡏࠬ⡹") or dns_status==l1l11l_l1_ (u"ࠩࡄࡗࡐ࠭⡺"):
		l1l111l1111_l1_ += l1l11l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่ๆࠣฮึ๐ฯࠡล้ࠤ๏ำว้ๆࠣห้ฮั็ษ่ะࠥหีๅษะࠤฬ๊ๅีๅ็อࠥษฯ็ษ๊ࠤฤࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⡻")
	trytofix = False
	if showDialogs:
		if proxy_status==l1l11l_l1_ (u"ࠫࡆ࡙ࡋࠨ⡼") or dns_status==l1l11l_l1_ (u"ࠬࡇࡓࡌࠩ⡽"):
			#if kodi_version<19: l1l11111ll1_l1_ = l1l11111ll1_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⡾"))
			trytofix = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ⡿"),l1l11l_l1_ (u"ࠨࠩ⢀"),l1l11l_l1_ (u"ࠩࠪ⢁"),site+l1l11l_l1_ (u"ࠪࠤࠥࠦࠧ⢂")+TRANSLATE(site),l1l111l1111_l1_,l1l11111ll1_l1_)
		else: DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⢃"),l1l11l_l1_ (u"ࠬ࠭⢄"),site+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ⢅")+TRANSLATE(site),l1l111l1111_l1_,l1l11111ll1_l1_)
	if reason.endswith(l1l11l_l1_ (u"ࠧࠡࠫࠪ⢆")): reason = reason.rsplit(l1l11l_l1_ (u"ࠨ࡞ࡱࠫ⢇"))[0]
	#if trytofix: LOG_THIS(l1l11l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ⢈"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ⢉")+str(code)+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭⢊")+reason+l1l11l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ⢋")+source+l1l11l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡆࡘࡁࡃࡋࡆ࠾ࠥࡡࠠࠨ⢌")+l1l111l1111_l1_+l1l11l_l1_ (u"ࠧࠡ࡟ࡠࠤࠥࠦࡅࡏࡉࡏࡍࡘࡎ࠺ࠡ࡝ࠣࠫ⢍")+l1l11111ll1_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫ⢎"))
	return trytofix
	l1l11l_l1_ (u"ࠤࠥࠦࠒࠐࠉࡪࡨࠣࡨࡳࡹࠠࡰࡴࠣࡦࡱࡵࡣ࡬ࡧࡧ࠵ࠥࡵࡲࠡࡤ࡯ࡳࡨࡱࡥࡥ࠴ࠣࡳࡷࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠳࠻ࠏࠍࠍࠎࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠦ࠽้ࠡࠩ์฾ࠦๅ็ࠢส่าาศุࠡาࠤ่๎ฯู๋่ࠢิื็ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็࠳࠭ࠍࠋࠋࠌ࡭࡫ࠦࡳࡩࡱࡺࡈ࡮ࡧ࡬ࡰࡩࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠦࠫ࠾ࠢࠪࠤ์๊ࠠหำํำࠥะแศืํ่ࠥอใฬำࠣรࠬࠓࠊࠊࠋ࡬ࡪࠥࡪ࡮ࡴ࠼ࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠠ࠾่ࠢࠪิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅࠣ࠯ࡂ๊ࠦࠧࠡสุ่ฮศࠡไาࠤ๏้่็ࠢࠪ࠯ࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠠ࠾๋ࠢࠪีอࠠศๆ่์็฿ࠠโ์๊ࠤࠬ࠱ࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠍࠋࠋࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ࠱ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭ࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ࠫࡴࡱࡸࡶࡨ࡫ࠫࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ࠭ࡶࡸࡷ࠮ࡣࡰࡦࡨ࠭࠰࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ࠭ࡵࡩࡦࡹ࡯࡯࠭ࠪࠤࡢࠦࠠࠡ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠻ࠢ࡞ࠤࠬ࠱࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠱ࠧࠡ࡟ࡠࠤࠥࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡅࡏࡉࡏࡍࡘࡎ࠺ࠡ࡝ࠣࠫ࠰ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠱ࠧࠡ࡟ࠪ࠭ࠒࠐࠉࠊ࡫ࡩࠤࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠼ࠐࠎࠎࠏࠉࡺࡧࡶࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥ࡙ࡆࡕࡑࡓ࠭࠭ࡣࡦࡰࡷࡩࡷ࠭ࠬࡴ࡫ࡷࡩ࠰࠭ࠠࠡࠢࠪ࠯࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋࠨࡴ࡫ࡷࡩ࠮࠲࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠲࡭ࡦࡵࡶࡥ࡬࡫ࡅࡏࡉࡏࡍࡘࡎࠬࠨࠩ࠯่๊ࠫวࠨ࠮๊ࠪ฾๋ࠧࠪࠏࠍࠍࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠲࠼ࠣ࡭ࡲࡶ࡯ࡳࡶࠣࡗࡊࡘࡖࡊࡅࡈࡗࠥࡁࠠࡔࡇࡕ࡚ࡎࡉࡅࡔ࠰ࡐࡅࡎࡔࠨ࠲࠻࠸࠭ࠒࠐࠉࡦ࡮࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠑࠏࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠲ࠡ࠿ࠣࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠮ࠫࠥ࠴่ࠠๆࠣฮึ๐ฯࠡ็฼ีๆฯࠠศๆฦืออศ๊ࠡส่า๊่ๅࠢยࠫࠒࠐࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸࠧ࠭ࡵ࡬ࡸࡪ࠱ࠧࠡࠢࠣࠫ࠰࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅࠩࡵ࡬ࡸࡪ࠯ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠲࠭࡯ࡨࡷࡸࡧࡧࡦࡇࡑࡋࡑࡏࡓࡉ࠮ࠪࠫ࠱࠭ใๅษࠪ࠰ࠬ์ูๆࠩࠬࠑࠏࠏࠉࡪࡨࠣࡽࡪࡹ࠽࠾࠳࠽ࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢࡀࠤ่ࠬฯࠡ์ๆ์๋ࠦ็็ษๆࠤ๋๎ูࠡ็้ࠤฬ๊ออสࠣ฽๋ีใࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไฦ่อี๋ะฺ่ࠠา็๋ࠥแึ๊็อࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢส่ึฮืࠡษ็ู้็ัࠡๆสࠤ๏฿ๅๅࠢ฼๊ิ้ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢ฽๎ึࠦ็ั้ࠣห้฻แฮหࠣ์ฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࡡࡴࠧࠬࠩฯีอࠦๅิฯࠣห้้วี้๋ࠢࠫࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠯ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤศืำๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอ้๋ࠢࠫࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠯ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤัืศูࠡิๆࠥืแฺࠢส่าาศ่ࠡࠪฯ้อࠠࡗࡒࡑࠤ࠱ࠦࡐࡳࡱࡻࡽࠥ࠲ࠠࡅࡐࡖ࠭ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢฯีอࠦืๅส๋ࠣีอࠠศๆ่์็฿ࠠๅษะๆฬ࠭ࠍࠋࠋࠌࠍࡉࡏࡁࡍࡑࡊࡣ࡙ࡋࡘࡕࡘࡌࡉ࡜ࡋࡒࠩࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫ࠱ࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘ࠯ࠍࠋࠋࠥࠦࠧ⢏")
def l1ll111l1l1_l1_(l1111l11l11_l1_=[]):
	l1111l11l1l_l1_ = [l11l1ll1lll_l1_,favouritesfile,dummyiptvfile,fulliptvfile,l1111ll1111_l1_]
	l1l111l1l1l_l1_ = l1111l11l11_l1_+l1111l11l1l_l1_
	for filename in os.listdir(l1l1ll1l11_l1_):
		if filename.startswith(l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩ⢐")): continue
		l11lll1l111_l1_ = os.path.join(l1l1ll1l11_l1_,filename)
		if l11lll1l111_l1_ not in l1l111l1l1l_l1_:
			try: os.remove(l11lll1l111_l1_)
			except: pass
	time.sleep(1)
	return
def EXTRACT_KODI_PATH(kodipath=addon_path):
	l1l1l11lll1_l1_ = {l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࠩ⢑"):l1l11l_l1_ (u"ࠬ࠭⢒"),l1l11l_l1_ (u"࠭࡭ࡰࡦࡨࠫ⢓"):l1l11l_l1_ (u"ࠧࠨ⢔"),l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ⢕"):l1l11l_l1_ (u"ࠩࠪ⢖"),l1l11l_l1_ (u"ࠪࡸࡪࡾࡴࠨ⢗"):l1l11l_l1_ (u"ࠫࠬ⢘"),l1l11l_l1_ (u"ࠬࡶࡡࡨࡧࠪ⢙"):l1l11l_l1_ (u"࠭ࠧ⢚"),l1l11l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ⢛"):l1l11l_l1_ (u"ࠨࠩ⢜"),l1l11l_l1_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨ⢝"):l1l11l_l1_ (u"ࠪࠫ⢞"),l1l11l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ⢟"):l1l11l_l1_ (u"ࠬ࠭⢠"),l1l11l_l1_ (u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨ⢡"):l1l11l_l1_ (u"ࠧࠨ⢢")}
	if l1l11l_l1_ (u"ࠨࡁࠪ⢣") in kodipath: kodipath = kodipath.split(l1l11l_l1_ (u"ࠩࡂࠫ⢤"),1)[1]
	url2,l1l1l11ll1l_l1_ = URLDECODE(kodipath)
	args = dict(list(l1l1l11lll1_l1_.items())+list(l1l1l11ll1l_l1_.items()))
	l11l111l111_l1_ = args[l1l11l_l1_ (u"ࠪࡱࡴࡪࡥࠨ⢥")]
	l11l1lllll1_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ⢦")])
	l1l1lllll1l_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࠪ⢧")])
	l11llll1111_l1_ = UNQUOTE(args[l1l11l_l1_ (u"࠭ࡰࡢࡩࡨࠫ⢨")])
	type_ = UNQUOTE(args[l1l11l_l1_ (u"ࠧࡵࡻࡳࡩࠬ⢩")])
	l1l1llllll1_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠨࡰࡤࡱࡪ࠭⢪")])
	l111ll11111_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨ⢫")])
	l11llll1l11_l1_ = args[l1l11l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ⢬")]
	l11l1lll111_l1_ = UNQUOTE(args[l1l11l_l1_ (u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭⢭")])
	#name = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭⢮"))
	#image = xbmc.getInfoLabel(l1l11l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡋࡦࡳࡳ࠭⢯"))
	if not l11l111l111_l1_: type_ = l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢰") ; l11l111l111_l1_ = l1l11l_l1_ (u"ࠨ࠴࠹࠴ࠬ⢱")
	return type_,l1l1llllll1_l1_,l11l1lllll1_l1_,l11l111l111_l1_,l111ll11111_l1_,l11llll1111_l1_,l1l1lllll1l_l1_,l11llll1l11_l1_,l11l1lll111_l1_
def l11l1llllll_l1_(proxy,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix=True,allow_proxy_fix=True):
	l111llll111_l1_,l11ll11111l_l1_ = proxy.split(l1l11l_l1_ (u"ࠩ࠽ࠫ⢲"))
	#DIALOG_NOTIFICATION(l1l11l_l1_ (u"ู้้ࠪไสࠢศ๊ฯืๆ๋ฬࠣ࠲ูࠥรฮษ๋่ࠥหีๅษะ๋ฬ࠭⢳"),l1l11l_l1_ (u"ุࠫษฬาสࠣࠫ⢴")+name,time=2000)
	#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⢵"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࠪ⢶")+name+l1l11l_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭⢷")+proxy+l1l11l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⢸")+url+l1l11l_l1_ (u"ࠩࠣࡡࠬ⢹"))
	url = url+l1l11l_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ⢺")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix,allow_proxy_fix)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⢻"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠩ⢼")+name+l1l11l_l1_ (u"࠭ࠠࡴࡧࡵࡺࡪࡸࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ⢽")+proxy+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭⢾")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ⢿"))
		raise SystemError(l1l11l_l1_ (u"ࠩࡋࡘ࡙ࡖࠠࡓࡧࡴࡹࡪࡹࡴࠡࡈࡤ࡭ࡱࡻࡲࡦࠩ⣀"))
	#else: LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⣁"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ⣂")+proxy+l1l11l_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ⣃")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ⣄"))
	return response
def l111l1lll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ⣅"),url,l1l11l_l1_ (u"ࠨࠩ⣆"),l1l11l_l1_ (u"ࠩࠪ⣇"),True,False,l1l11l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ⣈"),True,False)
	l1ll1llllll_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l1ll1l1_l1_
		l11l11lllll_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧ⣉"),html)
		#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭⣊"),str(l11l11lllll_l1_))
		if l11l11lllll_l1_: html = l1l11l_l1_ (u"࠭࡜࡯ࠩ⣋").join(l11l11lllll_l1_)
		proxies = html.replace(l1l11l_l1_ (u"ࠧ࡝ࡴࠪ⣌"),l1l11l_l1_ (u"ࠨࠩ⣍")).strip(l1l11l_l1_ (u"ࠩ࡟ࡲࠬ⣎")).split(l1l11l_l1_ (u"ࠪࡠࡳ࠭⣏"))
		l1ll1llllll_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l11l_l1_ (u"ࠫ࠳࠭⣐"))==3: l1ll1llllll_l1_.append(proxy)
	return l1ll1llllll_l1_
def OPENURL_REQUESTS_PROXIES(*args):
	#l11l1l1l11l_l1_ = l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠺࠵࠯࠵࠶࠲࠶࠽࠮࠲࠴࠺࠳ࡦࡶࡩ࠰ࡲࡵࡳࡽࡿ࠿ࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡷࡵ࡫ࡥࡥ࠿࠴࠴ࠫࡲࡡࡴࡶࡢࡧ࡭࡫ࡣ࡬࠿࠴࠴ࠫ࡮ࡴࡵࡲࡶࡁࡹࡸࡵࡦࠨࡳࡳࡸࡺ࠽ࡵࡴࡸࡩࠫ࡬࡯ࡳ࡯ࡤࡸࡂࡺࡸࡵࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ⣑")
	l1ll1ll1111_l1_ = l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡵࡸ࡯ࡹࡻࡶࡧࡷࡧࡰࡦ࠰ࡦࡳࡲ࠵ࡶ࠳࠱ࡂࡶࡪࡷࡵࡦࡵࡷࡁࡩ࡯ࡳࡱ࡮ࡤࡽࡵࡸ࡯ࡹ࡫ࡨࡷࠫࡶࡲࡰࡺࡼࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡴࡪ࡯ࡨࡳࡺࡺ࠽࠲࠲࠳࠴࠵ࠬࡳࡴ࡮ࡀࡽࡪࡹࠦ࡭࡫ࡰ࡭ࡹࡃ࠱࠱ࠨࡦࡳࡺࡴࡴࡳࡻࡀࡒࡑ࠲ࡂࡆ࠮ࡇࡉ࠱ࡌࡒ࠭ࡉࡅ࠰࡙ࡘࠧ⣒")
	l11ll1llll1_l1_ = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡰࡱࡶࡸࡪࡸ࡫ࡪࡦ࠲ࡳࡵ࡫࡮ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡱࡦ࡯࡮࠰ࡊࡗࡘࡕ࡙࠮ࡵࡺࡷࠫ⣓")
	#l1l11ll1111_l1_ = l111l1lll1l_l1_(l11l1l1l11l_l1_)
	l1l11ll1111_l1_ = l111l1lll1l_l1_(l11ll1llll1_l1_)
	l1ll1llllll_l1_ = l111l1lll1l_l1_(l1ll1ll1111_l1_)
	l1ll1lll1l1_l1_ = l1l11ll1111_l1_+l1ll1llllll_l1_
	LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ⣔"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡳࡶࡴࡾࡩࡦࡵࠣࡰ࡮ࡹࡴࠡࠢࠣ࠵ࡸࡺࠫ࠳ࡰࡧ࠾ࠥࡡࠠࠨ⣕")+str(len(l1l11ll1111_l1_))+l1l11l_l1_ (u"ࠪ࠯ࠬ⣖")+str(len(l1ll1llllll_l1_))+l1l11l_l1_ (u"ࠫࠥࡣࠧ⣗"))
	proxy = settings.getSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ⣘"))
	response = dummy_object()
	response.succeeded = False
	settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭⣙"),l1l11l_l1_ (u"ࠧࠨ⣚"))
	if proxy or l1ll1lll1l1_l1_:
		id,timeout = 0,10
		l1ll11llll1_l1_ = len(l1ll1lll1l1_l1_)
		l1l1l1l11l1_l1_ = timeout
		if l1ll11llll1_l1_>l1l1l1l11l1_l1_: counts = l1l1l1l11l1_l1_
		else: counts = l1ll11llll1_l1_
		l1l1lll1lll_l1_ = random.sample(l1ll1lll1l1_l1_,counts)
		if proxy: l1l1lll1lll_l1_ = [proxy]+l1l1lll1lll_l1_
		#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ⣛"),str(l1l1lll1lll_l1_))
		threads = l1l1ll1l111_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l1l1lll1l11_l1_:
			if id<counts:
				proxy = l1l1lll1lll_l1_[id]
				threads.start_new_thread(id,l11l1llllll_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⣜"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ⣝")+proxy+l1l11l_l1_ (u"ࠫࠥࡣࠧ⣞"))
		l1l1lll1l11_l1_ = threads.l1l1lll1l11_l1_
		if l1l1lll1l11_l1_:
			l1l111l11l1_l1_ = threads.l1l111l11l1_l1_
			l1l11111l1l_l1_ = l1l1lll1l11_l1_[0]
			response = l1l111l11l1_l1_[l1l11111l1l_l1_]
			proxy = l1l1lll1lll_l1_[int(l1l11111l1l_l1_)]
			settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ⣟"),proxy)
			if l1l11111l1l_l1_!=0: LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ⣠"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ⣡")+proxy+l1l11l_l1_ (u"ࠨࠢࡠࠫ⣢"))
			else: LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ⣣"),LOGGING(script_name)+l1l11l_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡗࡦࡼࡥࡥࠢࡳࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ⣤")+proxy+l1l11l_l1_ (u"ࠫࠥࡣࠧ⣥"))
		#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⣦"),l1l11l_l1_ (u"࠭ࡰࡳࡱࡻ࡭ࡪࡹࡌࡊࡕࡗ࠶ࠥࡀ࠺ࠡࠩ⣧")+str(l1l1lll1lll_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ⣨"),l1l11l_l1_ (u"ࠨࡲࡵࡳࡽ࡯ࡥࡴࡎࡌࡗ࡙ࠦ࠺࠻ࠢࠪ⣩")+str(l1ll1lll1l1_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⣪"),l1l11l_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭⣫")+str(threads.l1l1lll1l11_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⣬"),l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭⣭")+str(threads.l1lll111111_l1_))
		#LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⣮"),l1l11l_l1_ (u"ࠧࡳࡧࡶࡹࡱࡺࡳࡅࡋࡆࡘࠥࡀ࠺ࠡࠩ⣯")+str(threads.l1l111l11l1_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⣰"),l1l11l_l1_ (u"ࠩࡨࡰࡵࡧࡳࡦࡦࡷ࡭ࡲ࡫ࡄࡊࡅࡗࠤ࠿ࡀࠠࠨ⣱")+str(threads.l1ll1l1llll_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⣲"),l1l11l_l1_ (u"ࠫࡸࡵࡲࡵࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ⣳")+str(l1l1111lll1_l1_))
		#LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⣴"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ⣵")+l111ll111ll_l1_+l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ⣶")+str(l1l1111lll1_l1_))
	return response
class dummy_object(): pass
def USE_DNS_SERVER(connection,dns_server):
	original_create_connection = connection.create_connection
	def l11lll1l1l1_l1_(address,*args,**kwargs):
		host,port = address
		l11l11ll11l_l1_ = DNS_RESOLVER(host,dns_server)
		if l11l11ll11l_l1_: host = l11l11ll11l_l1_[0]
		else:
			if dns_server in DNS_SERVERS: DNS_SERVERS.remove(dns_server)
			if DNS_SERVERS:
				l1l1l111lll_l1_ = DNS_SERVERS[0]
				#LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⣷"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤ࡜࡯࡬࡭ࠢࡷࡶࡾࠦࡴࡩࡧࠣࡳࡹ࡮ࡥࡳࠢࡇࡒࡘࡀ࡛ࠡࠩ⣸")+l1l1l111lll_l1_+l1l11l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡲࡷࡹࡀ࡛ࠡࠩ⣹")+str(host)+l1l11l_l1_ (u"ࠫࠥࡣࠧ⣺"))
				l11l11ll11l_l1_ = DNS_RESOLVER(host,l1l1l111lll_l1_)
				if l11l11ll11l_l1_: host = l11l11ll11l_l1_[0]
		address = (host,port)
		return original_create_connection(address,*args,**kwargs)
	connection.create_connection = l11lll1l1l1_l1_
	return original_create_connection
def l1llllll1l_l1_(expiry,method,url,data,headers,source):
	if expiry>0:
		html = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠬࡹࡴࡳࠩ⣻"),l1l11l_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ⣼"),[method,url,data,headers,source])
		if html:
			LOG_OPENURL(True,url,data,headers,source,l1l11l_l1_ (u"ࠧࠨ⣽"))
			return html
	else:
		DELETE_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ⣾"),[method,url,data,headers,source])
		expiry = -expiry
	html = l1111l1111l_l1_(method,url,data,headers,source)
	if expiry>0: WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ⣿"),[method,url,data,headers,source],html,expiry)
	return html
def l1111l1111l_l1_(method,url,data=l1l11l_l1_ (u"ࠪࠫ⤀"),headers=l1l11l_l1_ (u"ࠫࠬ⤁"),source=l1l11l_l1_ (u"ࠬ࠭⤂")):
	LOG_OPENURL(False,url,data,headers,source,l1l11l_l1_ (u"࠭ࠧ⤃"))
	if kodi_version>18.99: import urllib.request as l111ll1ll11_l1_
	else: import urllib2 as l111ll1ll11_l1_
	if not headers: headers = {l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⤄"):l1l11l_l1_ (u"ࠨࠩ⤅")}
	if not data: data = {}
	if method==l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⤆"):
		url = url+l1l11l_l1_ (u"ࠪࡃࠬ⤇")+l1111l11_l1_(data)
		data = None
	try:
		req = l111ll1ll11_l1_.Request(url,headers=headers,data=data)
		http_response = l111ll1ll11_l1_.urlopen(req)
		html = http_response.read()
	except: html = l1l11l_l1_ (u"ࠫࠬ⤈")
	#try:
	#	req = l111ll1ll11_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l111ll1ll11_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l1l11l_l1_ (u"ࠬ࠭⤉")
	return html
def l1111llll1l_l1_(url):
	l1ll1111lll_l1_,l1l11l11lll_l1_ = url.split(l1l11l_l1_ (u"࠭࠯ࠨ⤊"))[2],80
	if l1l11l_l1_ (u"ࠧ࠻ࠩ⤋") in l1ll1111lll_l1_: l1ll1111lll_l1_,l1l11l11lll_l1_ = l1ll1111lll_l1_.split(l1l11l_l1_ (u"ࠨ࠼ࠪ⤌"))
	l11ll11l1l1_l1_ = l1l11l_l1_ (u"ࠩ࠲ࠫ⤍")+l1l11l_l1_ (u"ࠪ࠳ࠬ⤎").join(url.split(l1l11l_l1_ (u"ࠫ࠴࠭⤏"))[3:])
	request = l1l11l_l1_ (u"ࠬࡍࡅࡕࠢࠪ⤐")+l11ll11l1l1_l1_+l1l11l_l1_ (u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭⤑")
	#request += l1l11l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷ࠾ࠥࡢࡲ࡝ࡰࠪ⤒")
	request += l1l11l_l1_ (u"ࠨࡊࡲࡷࡹࡀࠠࠨ⤓")+l1ll1111lll_l1_+l1l11l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ⤔")
	request += l1l11l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ⤕")
	import socket
	try:
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect((l1ll1111lll_l1_,l1l11l11lll_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l11l_l1_ (u"ࠫࠬ⤖")
	return html
def SERVER(l1111l_l1_,type):
	# url:	http://l111ll1l11l_l1_.l1l11ll1ll1_l1_.com
	# host:	l111ll1l11l_l1_.l1l11ll1ll1_l1_.com
	# name:	l1l11ll1ll1_l1_
	#server = l1l11l_l1_ (u"ࠬ࠵ࠧ⤗").join(l1111l_l1_.split(l1l11l_l1_ (u"࠭࠯ࠨ⤘"))[:3])
	if l1l11l_l1_ (u"ࠧ࠯ࠩ⤙") not in l1111l_l1_: return l1111l_l1_
	l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠨ࠱ࠪ⤚")
	part1,part2 = l1111l_l1_.split(l1l11l_l1_ (u"ࠩ࠱ࠫ⤛"),1)
	l11l1111l11_l1_,l11l11111ll_l1_ = part2.split(l1l11l_l1_ (u"ࠪ࠳ࠬ⤜"),1)
	server = part1+l1l11l_l1_ (u"ࠫ࠳࠭⤝")+l11l1111l11_l1_
	if type in [l1l11l_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ⤞"),l1l11l_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ⤟")] and l1l11l_l1_ (u"ࠧ࠰ࠩ⤠") in server: server = server.rsplit(l1l11l_l1_ (u"ࠨ࠱ࠪ⤡"),1)[1]
	if type==l1l11l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ⤢") and l1l11l_l1_ (u"ࠪ࠲ࠬ⤣") in server:
		l111lll1ll1_l1_ = server.split(l1l11l_l1_ (u"ࠫ࠳࠭⤤"))
		length = len(l111lll1ll1_l1_)
		if length<=2 or l1l11l_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ⤥") in server: l111lll1ll1_l1_ = l111lll1ll1_l1_[0]
		elif length>=3: l111lll1ll1_l1_ = l111lll1ll1_l1_[1]
		if len(l111lll1ll1_l1_)>1: server = l111lll1ll1_l1_
	return server
	l1l11l_l1_ (u"ࠨࠢࠣࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࠬ࠵ࠧࠬࡷࡵࡰ࠷࠱ࠧ࠰ࠩࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡮ࡦࡶ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣࡰ࡯࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡯ࡳࡩ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡸࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡵࡸ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡷࡴ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡺ࡯࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡲ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡴ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡵࡹ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡤࡱ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡶࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩ࡬ࡶࡤ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡨࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡮ࡺ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡩ࡯࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡽࡷࡸ࠰ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡳ࠮ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡩࡲࡨࡥࡥ࠰ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࠧࠨࠢ⤦")
def l1111lll111_l1_(l1l1ll1l1l1_l1_):
	l1l1ll1l1ll_l1_ = repr(l1l1ll1l1l1_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⤧"))).replace(l1l11l_l1_ (u"ࠣࠩࠥ⤨"),l1l11l_l1_ (u"ࠩࠪ⤩"))
	return l1l1ll1l1ll_l1_
def l1lll11lll1_l1_(string):
	#if l1l11l_l1_ (u"ࠪࡠࡺ࠭⤪") in string:
	#	string = string.decode(l1l11l_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ⤫"))
	#	l11lll1llll_l1_=re.findall(l1l11l_l1_ (u"ࡷ࠭࡜ࡶ࡝࠳࠱࠾ࡇ࠭ࡇ࡟ࠪ⤬"),string)
	#	for unicode in l11lll1llll_l1_
	#		char = l1111l1l111_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⤭"))
	l1l11ll1l1l_l1_ = l1l11l_l1_ (u"ࠧࠨ⤮")
	if kodi_version<19: string = string.decode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⤯"))
	import unicodedata
	for l1lll111lll_l1_ in string:
		if   l1lll111lll_l1_==l1l11l_l1_ (u"ࡷࠪฦࠬ⤰"): l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫ⤱")
		elif l1lll111lll_l1_==l1l11l_l1_ (u"ࡹࠬษࠧ⤲"): l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭⤳")
		elif l1lll111lll_l1_==l1l11l_l1_ (u"ࡻࠧลࠩ⤴"): l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨ⤵")
		elif l1lll111lll_l1_==l1l11l_l1_ (u"ࡶࠩศࠫ⤶"): l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪ⤷")
		elif l1lll111lll_l1_==l1l11l_l1_ (u"ࡸࠫห࠭⤸"): l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬ⤹")
		else:
			l1111l111l1_l1_ = unicodedata.decomposition(l1lll111lll_l1_)
			if l1l11l_l1_ (u"ࠬࠦࠧ⤺") in l1111l111l1_l1_: l1l1l1ll11l_l1_ = l1l11l_l1_ (u"࠭࡜࡝ࡷࠪ⤻")+l1111l111l1_l1_.split(l1l11l_l1_ (u"ࠧࠡࠩ⤼"),1)[1]
			else:
				l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠨ࠲࠳࠴࠵࠭⤽")+hex(ord(l1lll111lll_l1_)).replace(l1l11l_l1_ (u"ࠩ࠳ࡼࠬ⤾"),l1l11l_l1_ (u"ࠪࠫ⤿"))
				l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠫࡡࡢࡵࠨ⥀")+l1l1l1ll11l_l1_[-4:]
			#if ord(l1lll111lll_l1_)<256: l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳ࠫ⥁")+l111lll1l11_l1_
			#elif ord(l1lll111lll_l1_)<4096: l1l1l1ll11l_l1_ = l1l11l_l1_ (u"࠭࡜࡝ࡷ࠳ࠫ⥂")+l111lll1l11_l1_
			#elif l1l11l_l1_ (u"ࠧࠡࠩ⥃") in l1111l111l1_l1_: l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠨ࡞࡟ࡹࠬ⥄")+l1111l111l1_l1_.split(l1l11l_l1_ (u"ࠩࠣࠫ⥅"),1)[1]
			#else: l1l1l1ll11l_l1_ = l1l11l_l1_ (u"ࠪࡠࡡࡻࠧ⥆")+l111lll1l11_l1_
		l1l11ll1l1l_l1_ += l1l1l1ll11l_l1_
	l1l11ll1l1l_l1_ = l1l11ll1l1l_l1_.replace(l1l11l_l1_ (u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬ⥇"),l1l11l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭⥈"))
	if kodi_version<19: l1l11ll1l1l_l1_ = l1l11ll1l1l_l1_.decode(l1l11l_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ⥉")).encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⥊"))
	else: l1l11ll1l1l_l1_ = l1l11ll1l1l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⥋")).decode(l1l11l_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ⥌"))
	return l1l11ll1l1l_l1_
def OPEN_KEYBOARD(header=l1l11l_l1_ (u"่ࠪํำษࠡษ็้ๆอส๋ฯࠪ⥍"),default=l1l11l_l1_ (u"ࠫࠬ⥎"),l1l1l1l1111_l1_=False):
	text = l11l11lll1l_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ⥏"),l1l11l_l1_ (u"࠭ࠠࠨ⥐")).replace(l1l11l_l1_ (u"ࠧࠡࠢࠪ⥑"),l1l11l_l1_ (u"ࠨࠢࠪ⥒")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬ⥓"),l1l11l_l1_ (u"ࠪࠤࠬ⥔"))
	if not text and not l1l1l1l1111_l1_:
		LOG_THIS(l1l11l_l1_ (u"ࠫࠬ⥕"),l1l11l_l1_ (u"ࠬ࠴ࠠࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪ⥖")+text+l1l11l_l1_ (u"࠭ࠢࠨ⥗"))
		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ⥘"),l1l11l_l1_ (u"ࠨࠩ⥙"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⥚"),l1l11l_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦััห้࠭⥛"))
		return l1l11l_l1_ (u"ࠫࠬ⥜")
	if text not in [l1l11l_l1_ (u"ࠬ࠭⥝"),l1l11l_l1_ (u"࠭ࠠࠨ⥞")]:
		text = text.strip(l1l11l_l1_ (u"ࠧࠡࠩ⥟"))
		text = l1lll11lll1_l1_(text)
	if l1l11_l1_(l1l11l_l1_ (u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪ⥠"),l1l11l_l1_ (u"ࠩࠪ⥡"),[text],False):
		LOG_THIS(l1l11l_l1_ (u"ࠪࠫ⥢"),l1l11l_l1_ (u"ࠫ࠳ࠦࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨ⥣")+text+l1l11l_l1_ (u"ࠬࠨࠧ⥤"))
		DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⥥"),l1l11l_l1_ (u"ࠧࠨ⥦"),l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⥧"),l1l11l_l1_ (u"ࠩหัะฺ๋ࠦำุ้๋่ࠣฮࠢห๋ࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠧ⥨"))
		return l1l11l_l1_ (u"ࠪࠫ⥩")
	LOG_THIS(l1l11l_l1_ (u"ࠫࠬ⥪"),l1l11l_l1_ (u"ࠬ࠴ࠠࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩ⥫")+text+l1l11l_l1_ (u"࠭ࠢࠨ⥬"))
	return text
def l1l11l1l1ll_l1_():
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l11l_l1_ (u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧ⥭"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l11l_l1_ (u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨ⥮"),time.localtime(now))
	name = name+datetime
	menuItem = (type,name,url,mode,image,page,text,context,l1l11l_l1_ (u"ࠩࠪ⥯"))
	if os.path.exists(l11l1ll1lll_l1_):
		oldFILE = open(l11l1ll1lll_l1_,l1l11l_l1_ (u"ࠪࡶࡧ࠭⥰")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⥱"))
		oldFILE = EVAL(l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ⥲"),oldFILE,l11l1ll1lll_l1_)
	else: oldFILE = {}
	newFILE = {}
	for l111lll1111_l1_ in list(oldFILE.keys()):
		if l111lll1111_l1_!=type: newFILE[l111lll1111_l1_] = oldFILE[l111lll1111_l1_]
		else:
			if name and name!=l1l11l_l1_ (u"࠭࠮࠯ࠩ⥳"):
				oldLIST = oldFILE[l111lll1111_l1_]
				if menuItem in oldLIST:
					index = oldLIST.index(menuItem)
					del oldLIST[index]
				newLIST = [menuItem]+oldLIST
				newLIST = newLIST[:50]
				newFILE[l111lll1111_l1_] = newLIST
			else: newFILE[l111lll1111_l1_] = oldFILE[l111lll1111_l1_]
	if type not in list(newFILE.keys()): newFILE[type] = [menuItem]
	newFILE = str(newFILE)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⥴"))
	open(l11l1ll1lll_l1_,l1l11l_l1_ (u"ࠨࡹࡥࠫ⥵")).write(newFILE)
	return
def l1ll1ll11l_l1_(url2,headers={}):
	#if headers[l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⥶")]==l1l11l_l1_ (u"ࠪࠫ⥷"): headers[l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⥸")] = l1l11l_l1_ (u"ࠬࠦࠧ⥹")
	#l11llll1ll1_l1_ = { l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⥺") : l1l11l_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠼࠻࠮࠱࠰࠶࠻࠼࠶࠮࠲࠶࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ⥻") }
	#url = l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡨ࠽࠺࠮࡮ࡻࡦࡨࡳ࠴࡭ࡦ࠱ࡹ࡭ࡩ࡫࡯࠯࡯࠶ࡹ࠽࠭⥼")
	#open(l1l11l_l1_ (u"ࠩࡖ࠾ࡡࡢࡴࡦࡵࡷ࠶࠳ࡳ࠳ࡶ࠺ࠪ⥽"), l1l11l_l1_ (u"ࠪࡶࠬ⥾")).read()
	url,params = url2,l1l11l_l1_ (u"ࠫࠬ⥿")
	if l1l11l_l1_ (u"ࠬࢂࠧ⦀") in url2:
		url,params = url2.split(l1l11l_l1_ (u"࠭ࡼࠨ⦁"),1)
		if l1l11l_l1_ (u"ࠧ࠾ࠩ⦂") not in params: url,params = url2,l1l11l_l1_ (u"ࠨࠩ⦃")
	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⦄"),url,l1l11l_l1_ (u"ࠪࠫ⦅"),headers,l1l11l_l1_ (u"ࠫࠬ⦆"),True,l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ⦇"),False,False)
	html = response.content
	if l1l11l_l1_ (u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ⦈") not in html: return [l1l11l_l1_ (u"ࠧ࠮࠳ࠪ⦉")],[url2]
	#	if l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ⦊") in list(headers.keys()): del headers[l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⦋")]
	#	else: headers[l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⦌")] = l1l11l_l1_ (u"ࠫࠬ⦍")
	#	response = OPENURL_REQUESTS_CACHED(l11l1ll111l_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩ⦎"),url,l1l11l_l1_ (u"࠭ࠧ⦏"),headers,l1l11l_l1_ (u"ࠧࠨ⦐"),False,l1l11l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠴ࡱࡨࠬ⦑"),False,False)
	#	html = response.content
	if l1l11l_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭⦒") in html: return [l1l11l_l1_ (u"ࠪ࠱࠶࠭⦓")],[url2]
	if l1l11l_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ⦔") in html: return [l1l11l_l1_ (u"ࠬ࠳࠱ࠨ⦕")],[url2]
	#if l1l11l_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡘ࡛ࡂࡕࡋࡗࡐࡊ࡙ࠧ⦖") in html: return [l1l11l_l1_ (u"ࠧ࠮࠳ࠪ⦗")],[url2]
	l1l1lll_l1_,l1ll1lll_l1_,l1l11lll11l_l1_,l11l1l1l111_l1_ = [],[],[],[]
	lines = re.findall(l1l11l_l1_ (u"ࠨ࡞ࠦࡉ࡝࡚࡙࠭࠯ࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋࡀࠨ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ⦘"),html+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡸࠧ⦙"),re.DOTALL)
	if not lines: return [l1l11l_l1_ (u"ࠪ࠱࠶࠭⦚")],[url2]
	for line,l1111l_l1_ in lines:
		l111l11l11l_l1_,l1ll11l1ll1_l1_,l1l1l1l1_l1_ = {},-1,-1
		title = l1l11l_l1_ (u"ࠫࠬ⦛")
		#hostname = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⦜"))
		#title = title+l1l11l_l1_ (u"࠭ࠠࠡࠩ⦝")+hostname+l1l11l_l1_ (u"ࠧࠡࠢࠪ⦞")
		#line = line.lower()
		items = line.split(l1l11l_l1_ (u"ࠨ࠮ࠪ⦟"))
		for item in items:
			#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ⦠"),l1l11l_l1_ (u"ࠪࠫ⦡"),item,l1l11l_l1_ (u"ࠫࠬ⦢"))
			#if l1l11l_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ⦣") in item: l111l11l11l_l1_[key] = value
			if l1l11l_l1_ (u"࠭࠽ࠨ⦤") in item:
				key,value = item.split(l1l11l_l1_ (u"ࠧ࠾ࠩ⦥"),1)
				l111l11l11l_l1_[key.lower()] = value
		if l1l11l_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ⦦") in line.lower():
			l1ll11l1ll1_l1_ = int(l111l11l11l_l1_[l1l11l_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭⦧")])//1024
			#title += l1l11l_l1_ (u"ࠪࡅࡻ࡭ࡂࡘ࠼ࠣࠫ⦨")+str(l1ll11l1ll1_l1_)+l1l11l_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ⦩")
			title += str(l1ll11l1ll1_l1_)+l1l11l_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ⦪")
		elif l1l11l_l1_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ⦫") in line.lower():
			l1ll11l1ll1_l1_ = int(l111l11l11l_l1_[l1l11l_l1_ (u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ⦬")])//1024
			#title += l1l11l_l1_ (u"ࠨࡄ࡚࠾ࠥ࠭⦭")+str(l1ll11l1ll1_l1_)+l1l11l_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ⦮")
			title += str(l1ll11l1ll1_l1_)+l1l11l_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ⦯")
		if l1l11l_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ⦰") in line.lower():
			l1l1l1l1_l1_ = int(l111l11l11l_l1_[l1l11l_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ⦱")].split(l1l11l_l1_ (u"࠭ࡸࠨ⦲"))[1])
			#title += l1l11l_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭⦳")+str(l1l1l1l1_l1_)+l1l11l_l1_ (u"ࠨࠢࠣࠫ⦴")
			title += str(l1l1l1l1_l1_)+l1l11l_l1_ (u"ࠩࠣࠤࠬ⦵")
		title = title.strip(l1l11l_l1_ (u"ࠪࠤࠥ࠭⦶"))
		if not title: title = l1l11l_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ⦷")
		if not l1111l_l1_.startswith(l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⦸")):
			if l1111l_l1_.startswith(l1l11l_l1_ (u"࠭࠯࠰ࠩ⦹")): l1111l_l1_ = url.split(l1l11l_l1_ (u"ࠧ࠻ࠩ⦺"),1)[0]+l1l11l_l1_ (u"ࠨ࠼ࠪ⦻")+l1111l_l1_
			elif l1111l_l1_.startswith(l1l11l_l1_ (u"ࠩ࠲ࠫ⦼")): l1111l_l1_ = SERVER(url,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ⦽"))+l1111l_l1_
			else: l1111l_l1_ = url.rsplit(l1l11l_l1_ (u"ࠫ࠴࠭⦾"),1)[0]+l1l11l_l1_ (u"ࠬ࠵ࠧ⦿")+l1111l_l1_
		if params!=l1l11l_l1_ (u"࠭ࠧ⧀"): l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡽࠩ⧁")+params
		if l1l11l_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ⧂") in list(l111l11l11l_l1_.keys()):
			l11l111l1_l1_ = l111l11l11l_l1_[l1l11l_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ⧃")]
			l11l111l1_l1_ = l11l111l1_l1_.replace(l1l11l_l1_ (u"ࠪࠦࠬ⧄"),l1l11l_l1_ (u"ࠫࠬ⧅")).replace(l1l11l_l1_ (u"ࠧ࠭ࠢ⧆"),l1l11l_l1_ (u"࠭ࠧ⧇")).split(l1l11l_l1_ (u"ࠧࠤࠩ⧈"),1)[0]
			videofiletype = GET_VIDEOFILETYPE(l11l111l1_l1_)
			if videofiletype: title2 = title+l1l11l_l1_ (u"ࠨࠢࠣࠫ⧉")+videofiletype
			else: title2 = title
			title2 = title2+l1l11l_l1_ (u"ࠩࠣࠤࡕࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦࠩ⧊")
			title2 = title2+l1l11l_l1_ (u"ࠪࠤࠥ࠭⧋")+SERVER(l11l111l1_l1_,l1l11l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ⧌"))
			l1l1lll_l1_.append(title2)
			l1ll1lll_l1_.append(l11l111l1_l1_)
			l1l11lll11l_l1_.append(l1l1l1l1_l1_)
			l11l1l1l111_l1_.append(l1ll11l1ll1_l1_)
		l1111l_l1_ = l1111l_l1_.split(l1l11l_l1_ (u"ࠬࠩࠧ⧍"),1)[0]
		videofiletype = GET_VIDEOFILETYPE(l1111l_l1_)
		if videofiletype: title = title+l1l11l_l1_ (u"࠭ࠠࠡࠩ⧎")+videofiletype
		title = title+l1l11l_l1_ (u"ࠧࠡࠢࠪ⧏")+SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠨࡰࡤࡱࡪ࠭⧐"))
		l1l1lll_l1_.append(title)
		l1ll1lll_l1_.append(l1111l_l1_)
		l1l11lll11l_l1_.append(l1l1l1l1_l1_)
		l11l1l1l111_l1_.append(l1ll11l1ll1_l1_)
	zz = list(zip(l1l1lll_l1_,l1ll1lll_l1_,l1l11lll11l_l1_,l11l1l1l111_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll_l1_,l1ll1lll_l1_,l1l11lll11l_l1_,l11l1l1l111_l1_ = list(zip(*zz))
	l1l1lll_l1_,l1ll1lll_l1_ = list(l1l1lll_l1_),list(l1ll1lll_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩࠪ⧑"), l1l1lll_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠪࠫ⧒"), l1ll1lll_l1_)
	return l1l1lll_l1_,l1ll1lll_l1_
mac = l1l11l_l1_ (u"ࠫࠬ⧓")
def l1l11l1111l_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l11ll111l_l1_(length=32):
	l1lll1l111_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠬࡹࡴࡳࠩ⧔"),l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ⧕"),l1l11l_l1_ (u"ࠧࡄࡎࡌࡉࡓ࡚ࡉࡅࠩ⧖"))
	if l1lll1l111_l1_: return l1lll1l111_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l1l1l1l111l_l1_ = threading.Thread(target=l1l11l1111l_l1_,args=())
	l1l1l1l111l_l1_.start()
	for ii in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l1l11l_l1_ (u"ࠨ࠲࠳࠵࠶࠸࠲࠴࠵࠷࠸࠺࠻࠶࠷࠹࠺ࠫ⧗")
	else:
		mac = mac.replace(l1l11l_l1_ (u"ࠩ࠽ࠫ⧘"),l1l11l_l1_ (u"ࠪࠫ⧙"))
		node = str(int(mac,16))
	node = re.findall(l1l11l_l1_ (u"ࠫࡠ࠶࠭࠺࡟࠮ࠫ⧚"),node,re.DOTALL)
	node = length*l1l11l_l1_ (u"ࠬ࠶ࠧ⧛")+node[0]
	node = node[-length:]
	mm,ss = l1l11l_l1_ (u"࠭ࠧ⧜"),l1l11l_l1_ (u"ࠧࠨ⧝")
	l111l1l1lll_l1_ = str(int(l1l11l_l1_ (u"ࠨ࠻ࠪ⧞")*(length+1))-int(node))[-length:]
	for ii in list(range(0,length,4)):
		l1111ll11ll_l1_ = l111l1l1lll_l1_[ii:ii+4]
		mm += l1111ll11ll_l1_+l1l11l_l1_ (u"ࠩ࠰ࠫ⧟")
		ss += str(sum(map(int,node[ii:ii+4]))%10)
	l1lll1l111_l1_ = mm+ss
	WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡑࡎ࡙ࡃࠨ⧠"),l1l11l_l1_ (u"ࠫࡈࡒࡉࡆࡐࡗࡍࡉ࠭⧡"),l1lll1l111_l1_,PERMANENT_CACHE)
	return l1lll1l111_l1_
def DNS_RESOLVER(host,dns_server=DNS_SERVERS[0]):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⧢"),l1l11l_l1_ (u"࠭ࠧ⧣"),str(dns_server),str(host))
	if host.replace(l1l11l_l1_ (u"ࠧ࠯ࠩ⧤"),l1l11l_l1_ (u"ࠨࠩ⧥")).isdigit(): return [host]
	import struct,socket
	try:
		l1l111l1l11_l1_ = struct.pack(l1l11l_l1_ (u"ࠤࡁࡌࠧ⧦"), 12049)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠥࡂࡍࠨ⧧"), 256)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠦࡃࡎࠢ⧨"), 1)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠧࡄࡈࠣ⧩"), 0)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠨ࠾ࡉࠤ⧪"), 0)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠢ࠿ࡊࠥ⧫"), 0)
		if kodi_version>18.99: l11lll111ll_l1_ = host.split(l1l11l_l1_ (u"ࠨ࠰ࠪ⧬"))
		else: l11lll111ll_l1_ = host.decode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⧭")).split(l1l11l_l1_ (u"ࠪ࠲ࠬ⧮"))
		for part in l11lll111ll_l1_:
			parts = part.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⧯"))
			l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠧࡈࠢ⧰"), len(part))
			for l1l11l11l1l_l1_ in part:
				l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠨࡣࠣ⧱"), l1l11l11l1l_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⧲")))
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠣࡄࠥ⧳"), 0)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠤࡁࡌࠧ⧴"), 1)
		l1l111l1l11_l1_ += struct.pack(l1l11l_l1_ (u"ࠥࡂࡍࠨ⧵"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l1l111l1l11_l1_), (dns_server, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l1l1llll1ll_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧ⧶"), data, 0)
		l1l1l11111l_l1_ = l1l1llll1ll_l1_[3]
		offset = len(host)+18
		answer = []
		for _ in range(l1l1l11111l_l1_):
			l1l11ll1lll_l1_ = offset
			l11ll111ll1_l1_ = 1
			l1ll1l111ll_l1_ = False
			while True:
				l1l11l11l1l_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠧࡄࡂࠣ⧷"), data, l1l11ll1lll_l1_)[0]
				if l1l11l11l1l_l1_ == 0:
					l1l11ll1lll_l1_ += 1
					break
				# l11l11111l1_l1_ the field l111lll1l1l_l1_ the first l1ll11111ll_l1_ bits l11l11l1lll_l1_ to 1, l1l1l11ll11_l1_ a pointer
				if l1l11l11l1l_l1_ >= 192:
					l1l11l111ll_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠨ࠾ࡃࠤ⧸"), data, l1l11ll1lll_l1_ + 1)[0]
					# l111l111l11_l1_ the pointer
					l1l11ll1lll_l1_ = ((l1l11l11l1l_l1_ << 8) + l1l11l111ll_l1_ - 0xc000) - 1
					l1ll1l111ll_l1_ = True
				l1l11ll1lll_l1_ += 1
				if l1ll1l111ll_l1_ == False: l11ll111ll1_l1_ += 1
			if l1ll1l111ll_l1_ == True: l11ll111ll1_l1_ += 1
			offset = offset + l11ll111ll1_l1_
			l1ll1ll1ll1_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠢ࠿ࡊࡋࡍࡍࠨ⧹"), data, offset)
			offset = offset + 10
			l1ll1111l11_l1_ = l1ll1ll1ll1_l1_[0]
			l1l111l111l_l1_ = l1ll1ll1ll1_l1_[3]
			if l1ll1111l11_l1_ == 1: # l1l1ll111ll_l1_ type
				l1l11l11ll1_l1_ = struct.unpack_from(l1l11l_l1_ (u"ࠣࡀࠥ⧺")+l1l11l_l1_ (u"ࠤࡅࠦ⧻")*l1l111l111l_l1_, data, offset)
				l11l11ll11l_l1_ = l1l11l_l1_ (u"ࠪࠫ⧼")
				for l1l11l11l1l_l1_ in l1l11l11ll1_l1_: l11l11ll11l_l1_ += str(l1l11l11l1l_l1_) + l1l11l_l1_ (u"ࠫ࠳࠭⧽")
				l11l11ll11l_l1_ = l11l11ll11l_l1_[0:-1]
				answer.append(l11l11ll11l_l1_)
			if l1ll1111l11_l1_ in [1,2,5,6,15,28]: offset = offset + l1l111l111l_l1_
	except: answer = []
	if not answer: LOG_THIS(l1l11l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ⧾"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬ⧿")+host+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ⨀"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⨁"),l1l11l_l1_ (u"ࠩࠪ⨂"),str(host),str(answer))
	return answer
def l1l11_l1_(script_name,url,l1l1l_l1_,showDialog=True):
	if l1l1l_l1_:
		l1l1llll1l1_l1_ = [l1l11l_l1_ (u"ࠪ็ออัࠨ⨃"),l1l11l_l1_ (u"ࠫออไ฻ࠩ⨄"),l1l11l_l1_ (u"ࠬࡧࡤࡶ࡮ࡷࠫ⨅"),l1l11l_l1_ (u"࠭ࡸࡹࠩ⨆"),l1l11l_l1_ (u"ࠧࡴࡧࡻࠫ⨇")]
		if script_name!=l1l11l_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ⨈"):
			l1l1llll1l1_l1_ += [l1l11l_l1_ (u"ࠩࡵ࠾ࠬ⨉"),l1l11l_l1_ (u"ࠪࡶ࠲࠭⨊"),l1l11l_l1_ (u"ࠫ࠲ࡳࡡࠨ⨋")]
			l1l1llll1l1_l1_ += [l1l11l_l1_ (u"ࠬࡀࡲࠨ⨌"),l1l11l_l1_ (u"࠭࠭ࡳࠩ⨍"),l1l11l_l1_ (u"ࠧ࡮ࡣ࠰ࠫ⨎")]
		for l111111ll_l1_ in l1l1l_l1_:
			if l1l11l_l1_ (u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ⨏") in l111111ll_l1_: continue
			if l1l11l_l1_ (u"ࠩะ่็ฯࠧ⨐") in l111111ll_l1_: continue
			l111111ll_l1_ = l111111ll_l1_.lower()
			if kodi_version<19: l111111ll_l1_ = l111111ll_l1_.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⨑")).encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⨒"))
			#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⨓"),l1l11l_l1_ (u"࠭ࠧ⨔"),l1l11l_l1_ (u"ࠧࠨ⨕"),str(l111111ll_l1_))
			#l1111ll1l11_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡠࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ⨖"),l111111ll_l1_,re.DOTALL)
			#l111l1111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡡࡠ࠰࠮࠱࡜࠸࠰࠽ࡢࢂ࠲࡜࠲࠰࠽ࡢ࠯ࠤࠨ⨗"),l111111ll_l1_,re.DOTALL)
			#l111ll1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡢ࠭࠷࡛࠷࠯࠼ࡡࢁ࠸࡛࠱࠯࠼ࡡ࠮ࡢࠫࠥࠩ⨘"),l111111ll_l1_,re.DOTALL)
			#l1l1ll11111_l1_ = any(l1111ll1l11_l1_,l111l1111ll_l1_,l111ll1l1l1_l1_,l111ll11l11_l1_)
			l111111ll_l1_ = l111111ll_l1_.replace(l1l11l_l1_ (u"ࠫ࠿࠭⨙"),l1l11l_l1_ (u"ࠬ࠭⨚"))
			l1l1ll11111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠲࡝࠸࠱࠾ࡣࠫࡽ࠴࡞࠴࠲࠹࡝ࠬࠫࠪ⨛"),l111111ll_l1_,re.DOTALL)
			l1l1111l111_l1_ = False
			for digits in l1l1ll11111_l1_:
				if len(digits)==2:
					l1l1111l111_l1_ = True
					break
			if l1l11l_l1_ (u"ࠧ࡯ࡱࡷࠤࡷࡧࡴࡦࡦࠪ⨜") in l111111ll_l1_: continue
			elif l1l11l_l1_ (u"ࠨࡷࡱࡶࡦࡺࡥࡥࠩ⨝") in l111111ll_l1_: continue
			elif l1l11l_l1_ (u"ࠩ฽๎ึࠦๅึ่ไࠫ⨞") in l111111ll_l1_: continue
			elif l11l1l11lll_l1_(l1l11l_l1_ (u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘࡰ࡛ࡊࡖࡆࡘࡈ࡜ࠬ⨟")): continue
			elif l111111ll_l1_ in [l1l11l_l1_ (u"ࠫࡷ࠭⨠")] or l1l1111l111_l1_ or any(value in l111111ll_l1_ for value in l1l1llll1l1_l1_):
				LOG_THIS(l1l11l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ⨡"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⨢")+url+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ⨣"))
				if showDialog: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⨤"),l1l11l_l1_ (u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫ⨥"))
				return True
	return False
def l1111l11_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1ll1ll1lll_l1_
	else: import urllib as l1ll1ll1lll_l1_
	l1l1l1l11ll_l1_ = l1ll1ll1lll_l1_.urlencode(data)
	return l1l1l1l11ll_l1_
def URLDECODE(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠪࠫ⨦"),l1l11l_l1_ (u"ࠫࠬ⨧"),url,l1l11l_l1_ (u"࡛ࠬࡒࡍࡆࡈࡇࡔࡊࡅࠨ⨨"))
	if l1l11l_l1_ (u"࠭࠽ࠨ⨩") in url:
		if l1l11l_l1_ (u"ࠧࡀࠩ⨪") in url: url2,filters = url.split(l1l11l_l1_ (u"ࠨࡁࠪ⨫"))
		else: url2,filters = l1l11l_l1_ (u"ࠩࠪ⨬"),url
		filters = filters.split(l1l11l_l1_ (u"ࠪࠪࠬ⨭"))
		data2 = {}
		for filter in filters:
			#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ⨮"),l1l11l_l1_ (u"ࠬ࠭⨯"),filter,str(filters))
			key,value = filter.split(l1l11l_l1_ (u"࠭࠽ࠨ⨰"))
			data2[key] = value
	else: url2,data2 = url,{}
	return url2,data2
def PLAY_VIDEO(url3,website=l1l11l_l1_ (u"ࠧࠨ⨱"),type_=l1l11l_l1_ (u"ࠨࠩ⨲")):
	if not type_: type_ = l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⨳")
	result,l1ll11111l1_l1_,httpd = l1l11l_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨ࠵࠭⨴"),l1l11l_l1_ (u"ࠫࠬ⨵"),l1l11l_l1_ (u"ࠬ࠭⨶")
	if len(url3)==3:
		url,l11l1ll1ll1_l1_,httpd = url3
		if l11l1ll1ll1_l1_!=l1l11l_l1_ (u"࠭ࠧ⨷"): l1ll11111l1_l1_ = l1l11l_l1_ (u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ⨸")+l11l1ll1ll1_l1_+l1l11l_l1_ (u"ࠨࠢࡠࠫ⨹")
	else: url,l11l1ll1ll1_l1_,httpd = url3,l1l11l_l1_ (u"ࠩࠪ⨺"),l1l11l_l1_ (u"ࠪࠫ⨻")
	#url = UNQUOTE(url)		# cause l1111l1l1l1_l1_ for l111l111_l1_ l11l11l1_l1_ l1ll111111l_l1_ streams
	url = url.replace(l1l11l_l1_ (u"ࠫࠪ࠸࠰ࠨ⨼"),l1l11l_l1_ (u"ࠬࠦࠧ⨽"))	# needed for l111l111l1l_l1_
	videofiletype = GET_VIDEOFILETYPE(url,website)
	if website not in [l1l11l_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ⨾"),l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ⨿")]:
		if website!=l1l11l_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ⩀"): url = url.replace(l1l11l_l1_ (u"ࠩࠣࠫ⩁"),l1l11l_l1_ (u"ࠪࠩ࠷࠶ࠧ⩂"))
		LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⩃"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡱ࡮ࡤࡽ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⩄")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ⩅")+l1ll11111l1_l1_)
		if videofiletype==l1l11l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭⩆") and website not in [l1l11l_l1_ (u"ࠨࡋࡓࡘ࡛࠭⩇"),l1l11l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ⩈")]:
			headers = {l1l11l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⩉"):l1l11l_l1_ (u"ࠫࠬ⩊")}
			l1l1lll_l1_,l1ll1lll_l1_ = l1ll1ll11l_l1_(url,headers)
			count = len(l1ll1lll_l1_)
			if count>1:
				selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭⩋")+str(count)+l1l11l_l1_ (u"࠭ࠠๆๆไ࠭ࠬ⩌"), l1l1lll_l1_)
				if selection == -1:
					DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠪ⩍"),l1l11l_l1_ (u"ࠨࠩ⩎"))
					return result
			else: selection = 0
			url = l1ll1lll_l1_[selection]
			if l1l1lll_l1_[0]!=l1l11l_l1_ (u"ࠩ࠰࠵ࠬ⩏"):
				LOG_THIS(l1l11l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⩐"),LOGGING(script_name)+l1l11l_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡀࠠ࡜ࠢࠪ⩑")+l1l1lll_l1_[selection]+l1l11l_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ⩒")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ⩓"))
		#url = url+l1l11l_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠵࠽࠼࠰࠱࠲࠳ࠫ⩔")
		#url = url+l1l11l_l1_ (u"ࠨࡾࡇࡒ࡙ࡃ࠱ࠧࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࡀࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠸ࠪࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬ࡃࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪࠬࡁࡤࡥࡨࡴࡹࡃࠪ࠰࡙ࠬࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡌࡪࡰࡸࡼࡀࠦࡁ࡯ࡦࡵࡳ࡮ࡪࠠ࠸࠰࠳࠿࡙ࠥࡍ࠮ࡉ࠻࠽࠷ࡇࠠࡃࡷ࡬ࡰࡩ࠵ࡎࡓࡆ࠼࠴ࡒࡁࠠࡸࡸࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡘࡨࡶࡸ࡯࡯࡯࠱࠷࠲࠵ࠦࡃࡩࡴࡲࡱࡪ࠵࠶࠸࠰࠳࠲࠸࠹࠹࠷࠰࠻࠻ࠥࡓ࡯ࡣ࡫࡯ࡩ࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ⩕")
		if l1l11l_l1_ (u"ࠩ࠲࡭࡫࡯࡬࡮࠱ࠪ⩖") in url: url = url+l1l11l_l1_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ⩗")
		elif l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⩘") in url.lower() and l1l11l_l1_ (u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ⩙") not in url and l1l11l_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ⩚") not in url:
			if l1l11l_l1_ (u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࠬ⩛") not in url and l1l11l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ⩜") in url.lower():
				if l1l11l_l1_ (u"ࠩࡿࠫ⩝") not in url: url = url+l1l11l_l1_ (u"ࠪࢀࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧ⩞")
				else: url = url+l1l11l_l1_ (u"ࠫࠫࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨ⩟")
			if l1l11l_l1_ (u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࠩ⩠") not in url.lower() and website not in [l1l11l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ⩡")]:
				if l1l11l_l1_ (u"ࠧࡽࠩ⩢") not in url: url = url+l1l11l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ⩣")
				else: url = url+l1l11l_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ⩤")
		#url = url.replace(l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ⩥"),l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ⩦"))
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ⩧"),LOGGING(script_name)+l1l11l_l1_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⩨")+url+l1l11l_l1_ (u"ࠧࠡ࡟ࠪ⩩"))
	l1111l11lll_l1_ = xbmcgui.ListItem()
	#l1111l11lll_l1_ = xbmcgui.ListItem(l1l11l_l1_ (u"ࠨࡶࡨࡷࡹ࠭⩪"))
	type_,l1l1llllll1_l1_,l11l1lllll1_l1_,l11l111l111_l1_,l111ll11111_l1_,l11llll1111_l1_,l1l1lllll1l_l1_,l11llll1l11_l1_,l11l1lll111_l1_ = EXTRACT_KODI_PATH(addon_path)
	if website not in [l1l11l_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ⩫"),l1l11l_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ⩬")]:
		if kodi_version<19: l1111l1l11l_l1_ = l1l11l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧ⩭")
		else: l1111l1l11l_l1_ = l1l11l_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࠪ⩮")
		#l1111l11lll_l1_ = xbmcgui.ListItem(path=url)
		l1111l11lll_l1_.setProperty(l1111l1l11l_l1_, l1l11l_l1_ (u"࠭ࠧ⩯"))
		l1111l11lll_l1_.setMimeType(l1l11l_l1_ (u"ࠧ࡮࡫ࡰࡩ࠴ࡾ࠭ࡵࡻࡳࡩࠬ⩰"))
		l1111l11lll_l1_.setInfo(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⩱"),{l1l11l_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ⩲"):l1l11l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ⩳")})
		#img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡩࡤࡱࡱࠫ⩴"))
		#LOG_THIS(l1l11l_l1_ (u"ࠬ࠭⩵"),l1l11l_l1_ (u"࠭ࡅࡎࡃࡇ࠾࠿ࡀ࠺࠻ࠢࠪ⩶")+image)
		#l1111l11lll_l1_.setArt({l1l11l_l1_ (u"ࠧࡪࡥࡲࡲࠬ⩷"):image,l1l11l_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ⩸"):image,l1l11l_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ⩹"):image})
		l1111l11lll_l1_.setArt({l1l11l_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ⩺"):l111ll11111_l1_,l1l11l_l1_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫ⩻"):l111ll11111_l1_,l1l11l_l1_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ⩼"):l111ll11111_l1_,l1l11l_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭⩽"):l111ll11111_l1_,l1l11l_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ⩾"):l111ll11111_l1_,l1l11l_l1_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ⩿"):l111ll11111_l1_,l1l11l_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ⪀"):l111ll11111_l1_,l1l11l_l1_ (u"ࠪ࡭ࡨࡵ࡮ࠨ⪁"):l111ll11111_l1_})
		#l1111l11lll_l1_.setInfo(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⪂"),{l1l11l_l1_ (u"࡚ࠬࡩࡵ࡮ࡨࠫ⪃"):name})
		#name = xbmc.getInfoLabel(l1l11l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ⪄"))
		#name = name.strip(l1l11l_l1_ (u"ࠧࠡࠩ⪅"))
		# when set to l1l11l_l1_ (u"ࠣࡈࡤࡰࡸ࡫ࠢ⪆") it l1ll11l1111_l1_ l11l11l1111_l1_ l11ll11l11l_l1_ and l11l111lll1_l1_ l1l1l1ll1ll_l1_ l111l111ll1_l1_ l111l11l1l1_l1_
		if videofiletype in [l1l11l_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ⪇"),l1l11l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ⪈")]: l1111l11lll_l1_.setContentLookup(True)
		else: l1111l11lll_l1_.setContentLookup(False)
		#if videofiletype in [l1l11l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ⪉")]: l1111l11lll_l1_.setContentLookup(False)
		if l1l11l_l1_ (u"ࠬࡸࡴ࡮ࡲࠪ⪊") in url:
			import l111l1l111l_l1_
			l111l1l111l_l1_.l1ll11ll1l1_l1_(l1l11l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ⪋"),False)
		elif videofiletype==l1l11l_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ⪌") or l1l11l_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ⪍") in url:
			import l111l1l111l_l1_
			l111l1l111l_l1_.l1ll11ll1l1_l1_(l1l11l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ⪎"),False)
			l1111l11lll_l1_.setProperty(l1111l1l11l_l1_,l1l11l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ⪏"))
			l1111l11lll_l1_.setProperty(l1l11l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠲ࡲࡧ࡮ࡪࡨࡨࡷࡹࡥࡴࡺࡲࡨࠫ⪐"),l1l11l_l1_ (u"ࠬࡳࡰࡥࠩ⪑"))
			#l1111l11lll_l1_.setMimeType(l1l11l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡩࡧࡳࡩ࠭ࡻࡱࡱ࠭⪒"))
			#l1111l11lll_l1_.setContentLookup(False)
		if l11l1ll1ll1_l1_:
			l1111l11lll_l1_.setSubtitles([l11l1ll1ll1_l1_])
			#xbmc.log(LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࠤࠥࠦࡁࡥࡦࡨࡨࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࠠࡵࡱࠣࡺ࡮ࡪࡥࡰࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀ࡛ࠨ⪓")+l11l1ll1ll1_l1_+l1l11l_l1_ (u"ࠨ࡟ࠪ⪔"), level=xbmc.LOGNOTICE)
	if type_==l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⪕") and website==l1l11l_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ⪖"):
		result = l1l11l_l1_ (u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⪗")
		website = l1l11l_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡈࡑࡥࡆࡊࡎࡈࡗࠬ⪘")
	elif type_==l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⪙") and l11llll1l11_l1_.startswith(l1l11l_l1_ (u"ࠧ࠷ࠩ⪚")):
		result = l1l11l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⪛")
		website = website+l1l11l_l1_ (u"ࠩࡢࡈࡑ࠭⪜")
	# l11lllll1ll_l1_ l11lll11lll_l1_
	#	l11l1l1ll1l_l1_ = l11l1lll1l1_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l1ll111ll1_l1_ with xbmc.sleep(step*1000)
	if result!=l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⪝"): l1l11l1l1ll_l1_()
	l11l1l1ll1l_l1_ = l11l1lll1l1_l1_()
	if type_==l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⪞") and not l11llll1l11_l1_.startswith(l1l11l_l1_ (u"ࠬ࠼ࠧ⪟")):
		#title = xbmc.getInfoLabel(l1l11l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡬ࡸࡱ࡫ࠧ⪠"))
		#l1111l11lll_l1_.setInfo(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⪡"),{l1l11l_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ⪢"): 3600})
		#xbmcplugin.setContent(addon_handle,l1l11l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ⪣"))
		#l1111l11lll_l1_.setInfo(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⪤"),{l1l11l_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࡷࡽࡵ࡫ࠧ⪥"):l1l11l_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ⪦")})
		#l1111l11lll_l1_.setProperty(l1l11l_l1_ (u"࠭ࡉࡴࡒ࡯ࡥࡾࡧࡢ࡭ࡧࠪ⪧"),l1l11l_l1_ (u"ࠧࡵࡴࡸࡩࠬ⪨"))
		#l1111l11lll_l1_.setInfo(type=l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⪩"),l111l1l1l11_l1_={l1l11l_l1_ (u"ࠤࡗ࡭ࡹࡲࡥࠣ⪪"):l1l11l_l1_ (u"ࠪ࡬ࡪࡲ࡬ࡰࠢࡺࡳࡷࡲࡤࠨ⪫")})
		l1111l11lll_l1_.setPath(url)
		LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⪬"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡒ࡯ࡥࡾ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡙ࠩࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ⪭")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ⪮"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1111l11lll_l1_)
	elif type_==l1l11l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⪯"):
		LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⪰"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⪱")+url+l1l11l_l1_ (u"ࠪࠤࡢ࠭⪲"))
		l11l1l1ll1l_l1_.play(url,l1111l11lll_l1_)
		#xbmc.Player().play(url,l1111l11lll_l1_)
	if result!=l1l11l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⪳"):
		timeout,result = 60,l1l11l_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ⪴")
		l1lllll1l_l1_(l1l11l_l1_ (u"࠭ࡳࡵࡱࡳࠫ⪵"))
		for ii in range(timeout*2):
			# l11lllll1ll_l1_ l11lll11lll_l1_
			#	if l111lll11l1_l1_ time.sleep() l1l1ll11l1l_l1_ of xbmc.sleep() l1l1l11l111_l1_ the l11l11l1ll1_l1_ status
			#	l1l11l_l1_ (u"ࠢ࡮ࡻࡳࡰࡦࡿࡥࡳ࠰ࡶࡸࡦࡺࡵࡴࠤ⪶") will stop l1ll1111l1l_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(500)
			result = l11l1l1ll1l_l1_.status
			if result==l1l11l_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ⪷"):
				DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣ๎฾๋ไࠨ⪸"),l1l11l_l1_ (u"ࠪࠫ⪹"),time=500)
				LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ⪺"),LOGGING(script_name)+l1l11l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࡺ࡮ࡪࡥࡰࠢ࡬ࡷࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⪻")+url+l1l11l_l1_ (u"࠭ࠠ࡞ࠩ⪼")+l1ll11111l1_l1_)
				break
			elif result==l1l11l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ⪽"):
				LOG_THIS(l1l11l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭⪾"),LOGGING(script_name)+l1l11l_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ⪿")+url+l1l11l_l1_ (u"ࠪࠤࡢ࠭⫀")+l1ll11111l1_l1_)
				DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭⫁"),l1l11l_l1_ (u"ࠬ࠭⫂"),time=500)
				break
			#if l1l11l_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ⫃") in url: break
			if ii%2==0: DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠧอษิ๎ࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ⫄"),l1l11l_l1_ (u"ࠨสสๆ๏ࠦࠧ⫅")+str(timeout-ii//2)+l1l11l_l1_ (u"ࠩࠣฯฬ์๊สࠩ⫆"))
		else:
			result = l1l11l_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ⫇")
			l11l1l1ll1l_l1_.stop()
			DIALOG_NOTIFICATION(l1l11l_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭⫈"),l1l11l_l1_ (u"ࠬ࠭⫉"),time=500)
			LOG_THIS(l1l11l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ⫊"),LOGGING(script_name)+l1l11l_l1_ (u"ࠧࠡࠢࠣࡘ࡮ࡳࡥࡰࡷࡷࠤࡺࡴ࡫࡯ࡱࡺࡲࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⫋")+url+l1l11l_l1_ (u"ࠨࠢࡠࠫ⫌")+l1ll11111l1_l1_)
		l1lllll1l_l1_(l1l11l_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ⫍"))
	l1l11l_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤ࡭ࡺࡴࡱࡦ࠽ࠑࠏࠏࠉࠤࠢ࡫ࡸࡹࡶ࠺࠰࠱࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸ࠿࠻࠵࠱࠷࠸࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠏࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡩ࡬ࡪࡥ࡮ࠤࡴࡱࠠࡵࡱࠣࡷ࡭ࡻࡴࡥࡱࡺࡲࠥࡺࡨࡦࠢ࡫ࡸࡹࡶࠠࡴࡧࡵࡺࡪࡸࠧࠪࠏࠍࠍࠎࠩࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡏࡑࡢࡇࡆࡉࡈࡆ࠮ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡴࡩࡡ࡭ࡪࡲࡷࡹࡀ࠵࠶࠲࠸࠹࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࡇࡣ࡯ࡷࡪ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠺ࡺࡨࠨࠫࠐࠎࠎࠏࡴࡪ࡯ࡨ࠲ࡸࡲࡥࡦࡲࠫ࠵࠮ࠓࠊࠊࠋ࡫ࡸࡹࡶࡤ࠯ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠫ࠭ࠒࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬ࡮ࡴࡵࡲࠣࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡤࡰࡹࡱࠫ࠱࠭ࠧࠪࠏࠍࠍࠧࠨࠢ⫎")
	if result==l1l11l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⫏") and not l11l1l11lll_l1_(l1l11l_l1_ (u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭⫐")):
		import l1l1llll1l_l1_
		succeeded = l1l1llll1l_l1_.l1ll1111ll_l1_(url,videofiletype,website)
		if succeeded: l1l11l1l1ll_l1_()
	else: succeeded = False
	if result in [l1l11l_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ⫑"),l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⫒")] or succeeded:
		#addon_version = xbmc.getInfoLabel( l1l11l_l1_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡖࡦࡴࡶ࡭ࡴࡴࠨࠣ⫓")+addon_id+l1l11l_l1_ (u"ࠤࠬࠦ⫔") )
		response = SEND_ANALYTICS_EVENT(website)
		#html = response.content
	#if result in [l1l11l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⫕"),l1l11l_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ⫖"),l1l11l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ⫗"),l1l11l_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ⫘"),l1l11l_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ⫙")]: l1ll111l111_l1_(l1l11l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪ⫚"),False)
	#l1ll111l111_l1_(l1l11l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕ࠭࠴ࡴࡧࠫ⫛"))
	#if l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ⫝̸") in url and result in [l1l11l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ⫝"),l1l11l_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭⫞")]:
	#	l1ll1111l1l_l1_ = HTTPS(False)
	#	if not l1ll1111l1l_l1_:
	#		DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⫟"),l1l11l_l1_ (u"ࠧࠨ⫠"),l1l11l_l1_ (u"ࠨษ็หฯ฻วๅุ่ࠢๆืࠧ⫡"),l1l11l_l1_ (u"ุ่่๊ࠩษࠡ࠰࠱࠲ࠥํะศࠢส่ๆ๐ฯ๋๊ࠣ๎าะวอࠢส่๎ࠦวหืส่๋ࠥิโำࠣࠬึฮืࠡ็ืๅึ࠯้ࠠๆๆ๊๊ࠥไฤีไࠤฬ๊วหืส่ࠥอไๆึไี๊ࠥวࠡ์฼ู้้ࠦๅ๋ࠣะ์อาไࠩ⫢"))
	#		return l1l11l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ⫣")
	#sys.exit()
	return result
def DIALOG_OK(*args,**kwargs):
	if args:
		l11l1l1l1l1_l1_ = args[0]
		l1l1llll_l1_ = args[1]
		if not l11l1l1l1l1_l1_: l11l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ⫤")
		if not l1l1llll_l1_: l1l1llll_l1_ = l1l11l_l1_ (u"ࠬอำห็ิหึ࠭⫥")
		header = args[2]
		text = l1l11l_l1_ (u"࠭࡜࡯ࠩ⫦").join(args[3:])
	else: l11l1l1l1l1_l1_,l1l1llll_l1_,header,text = l1l11l_l1_ (u"ࠧࠨ⫧"),l1l11l_l1_ (u"ࠨࡑࡎࠫ⫨"),l1l11l_l1_ (u"ࠩࠪ⫩"),l1l11l_l1_ (u"ࠪࠫ⫪")
	l1111lll1ll_l1_(l11l1l1l1l1_l1_,l1l11l_l1_ (u"ࠫࠬ⫫"),l1l1llll_l1_,l1l11l_l1_ (u"ࠬ࠭⫬"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l11l1l1l1l1_l1_ = args[0]
	l11ll1l1l11_l1_ = args[1]
	l11ll111l11_l1_ = args[2]
	if l11ll111l11_l1_ or l11ll1l1l11_l1_: l11ll1l1111_l1_ = True
	else: l11ll1l1111_l1_ = False
	header = args[3]
	text = args[4]
	if not l11l1l1l1l1_l1_: l11l1l1l1l1_l1_ = l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭⫭")
	if not l11ll1l1l11_l1_: l11ll1l1l11_l1_ = l1l11l_l1_ (u"ࠧไๆสࠫ⫮")
	if not l11ll111l11_l1_: l11ll111l11_l1_ = l1l11l_l1_ (u"ࠨ่฼้ࠬ⫯")
	if len(args)>=6: text += l1l11l_l1_ (u"ࠩ࡟ࡲࠬ⫰")+args[5]
	if len(args)>=7: text += l1l11l_l1_ (u"ࠪࡠࡳ࠭⫱")+args[6]
	choice = l1111lll1ll_l1_(l11l1l1l1l1_l1_,l11ll1l1l11_l1_,l1l11l_l1_ (u"ࠫࠬ⫲"),l11ll111l11_l1_,header,text)
	if choice==-1 and l11ll1l1111_l1_: choice = -1
	elif choice==-1 and not l11ll1l1111_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1l1111l11l_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l11l_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ⫳") in list(kwargs.keys()): l1l11l1llll_l1_ = kwargs[l1l11l_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ⫴")]
	else: l1l11l1llll_l1_ = 1000
	if len(args)>2 and l1l11l_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ⫵") not in args[2]: profile = args[2]
	else: profile = l1l11l_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ⫶")
	l111l1ll111_l1_ = xbmcgui.WindowXMLDialog(l1l11l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࡉ࡮ࡣࡪࡩ࠳ࡾ࡭࡭ࠩ⫷"),l1l11l1l111_l1_,l1l11l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ⫸"),l1l11l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ⫹"))
	image_filename,image_height = CREATE_IMAGE(l1l11l_l1_ (u"ࠬ࠭⫺"),l1l11l_l1_ (u"࠭ࠧ⫻"),l1l11l_l1_ (u"ࠧࠨ⫼"),header,text,profile,l1l11l_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭⫽"),720,False)
	#time.sleep(0.200)
	l111l1ll111_l1_.show()
	if profile==l1l11l_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ⫾"):
		l111l1ll111_l1_.getControl(9040).setHeight(215)
		l111l1ll111_l1_.getControl(9040).setPosition(55,-80)
		l111l1ll111_l1_.getControl(9050).setPosition(120,-60)
		l111l1ll111_l1_.getControl(400).setPosition(90,-35)
	l111l1ll111_l1_.getControl(401).setVisible(False)
	l111l1ll111_l1_.getControl(402).setVisible(False)
	l111l1ll111_l1_.getControl(9050).setImage(image_filename)
	l111l1ll111_l1_.getControl(9050).setHeight(image_height)
	import threading
	l1ll1lll111_l1_ = threading.Thread(target=l111l1l11l1_l1_,args=(l111l1ll111_l1_,image_filename,l1l11l1llll_l1_))
	l1ll1lll111_l1_.start()
	#l1ll1lll111_l1_.join()
	return
	#return xbmcgui.Dialog().l111ll1111l_l1_(l1l11111111_l1_=False,*args,**kwargs)
def l111l1l11l1_l1_(l111l1ll111_l1_,image_filename,l1l11l1llll_l1_):
	time.sleep(l1l11l1llll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(image_filename):
		try: os.remove(image_filename)
		except: pass
	#del l111l1ll111_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l11l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠪࠫ⫿"),l1l11l_l1_ (u"ࠫࠬ⬀"),l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭⬁"),l1l11l_l1_ (u"࠭࡬ࡦࡨࡷࠫ⬂")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l11l1l1l1l1_l1_ = args[3]
	return l1ll1lll11_l1_(l11l1l1l1l1_l1_,header,text,profile)
	#return xbmcgui.Dialog().l11ll1lll11_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l11l1111ll1_l1_(*args,**kwargs)
def l1ll11l11l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l11l11lll1l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#button0,button1,button2,header,text,profile,l11l1l1l1l1_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l111l1ll111_l1_ = l1l1ll1lll1_l1_(l1l11l_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ⬃"),l1l11l1l111_l1_,l1l11l_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ⬄"),l1l11l_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ⬅"))
	#l111l1ll111_l1_.l1l1l1l1ll1_l1_(button0,button1,button2,header,text,profile,l11l1l1l1l1_l1_,855)
	#return l111l1ll111_l1_
	l1l11l_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤࡹ࡯࡭ࡦࡱࡸࡸࡃ࠶࠺ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡵࡷࡥࡷࡺࡂࡶࡶࡷࡳࡳࡹࡔࡪ࡯ࡨࡳࡺࡺࠨࡵ࡫ࡰࡩࡴࡻࡴࠪࠏࠍࠍࡪࡲࡳࡦ࠼ࠣࡨ࡮ࡧ࡬ࡰࡩ࠱ࡩࡳࡧࡢ࡭ࡧࡅࡹࡹࡺ࡯࡯ࡵࠫ࠭ࠒࠐࠉࠤࡦ࡬ࡥࡱࡵࡧ࠯ࡷࡳࡨࡦࡺࡥࡑࡴࡲ࡫ࡷ࡫ࡳࡴࡄࡤࡶ࠭࠽࠰ࠪࠋࠦࠤ࠼࠶ࠥࠎࠌࠌࡨ࡮ࡧ࡬ࡰࡩ࠱ࡨࡴࡓ࡯ࡥࡣ࡯ࠬ࠮ࠓࠊࠊࡥ࡫ࡳ࡮ࡩࡥࠡ࠿ࠣࡨ࡮ࡧ࡬ࡰࡩ࠱ࡧ࡭ࡵࡩࡤࡧࡌࡈࠒࠐࠉࡪࡨࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲ࡪࡾࡩࡴࡶࡶࠬࡩ࡯ࡡ࡭ࡱࡪ࠲࡮ࡳࡡࡨࡧࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࡀࠠࡰࡵ࠱ࡶࡪࡳ࡯ࡷࡧࠫࡨ࡮ࡧ࡬ࡰࡩ࠱࡭ࡲࡧࡧࡦࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠒࠐࠉࠤࡦࡨࡰࠥࡪࡩࡢ࡮ࡲ࡫ࠒࠐࠉࡳࡧࡷࡹࡷࡴࠠࡤࡪࡲ࡭ࡨ࡫ࠍࠋࠋࠥࠦࠧ⬆")
def l1lllll1l_l1_(l11ll111111_l1_):
	if kodi_version>17.99: l111l1ll111_l1_ = l1l11l_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩ⬇")
	else: l111l1ll111_l1_ = l1l11l_l1_ (u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩ⬈")
	l11ll111111_l1_ = l11ll111111_l1_.lower()
	if l11ll111111_l1_==l1l11l_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ⬉"): xbmc.executebuiltin(l1l11l_l1_ (u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩ⬊")+l111l1ll111_l1_+l1l11l_l1_ (u"ࠨࠫࠪ⬋"))
	elif l11ll111111_l1_==l1l11l_l1_ (u"ࠩࡶࡸࡴࡶࠧ⬌"): xbmc.executebuiltin(l1l11l_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪ⬍")+l111l1ll111_l1_+l1l11l_l1_ (u"ࠫ࠮࠭⬎"))
	return
class l1l1ll1lll1_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l1ll1ll1l1l_l1_ = -1
	def onClick(self,l1l111ll11l_l1_):
		if l1l111ll11l_l1_>=9010: self.l1ll1ll1l1l_l1_ = l1l111ll11l_l1_-9010
		self.delete()
	def l1l1l1l1ll1_l1_(self,*args):
		#self.getControl(9001).l1lll11llll_l1_(header)
		#self.getControl(9009).l11llll11ll_l1_(text)
		#self.getControl(9010).l1lll11llll_l1_(button0)
		#self.getControl(9011).l1lll11llll_l1_(button1)
		#self.getControl(9012).l1lll11llll_l1_(button2)
		self.button0,self.button1,self.button2 = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l11l1l1l1l1_l1_ = args[5],args[6]
		self.image_width,self.l1111l1l1ll_l1_,self.l111l1ll11l_l1_ = args[7],args[8],args[9]
		if self.l1111l1l1ll_l1_>0 or self.l111l1ll11l_l1_>0: self.enable_progressbar = True
		else: self.enable_progressbar = False
		self.image_filename,self.image_height = CREATE_IMAGE(self.button0,self.button1,self.button2,self.header,self.text,self.profile,self.l11l1l1l1l1_l1_,self.image_width,self.enable_progressbar)
		self.show()
		self.getControl(9050).setImage(self.image_filename)
		self.getControl(9050).setHeight(self.image_height)
		if not self.button1 and self.button0 and self.button2: self.getControl(9012).setPosition(-220,0)
		return self.image_filename,self.image_height
	def l1ll1ll11l1_l1_(self):
		if self.l1111l1l1ll_l1_:
			import threading
			self.l1l1l1l111l_l1_ = threading.Thread(target=self.l11l1lll11l_l1_,args=())
			self.l1l1l1l111l_l1_.start()
			#self.l1l1l1l111l_l1_.join()
		else: self.enableButtons()
	def l11l1lll11l_l1_(self):
		self.getControl(9020).setEnabled(True)
		for ii in range(1,self.l1111l1l1ll_l1_+1):
			time.sleep(1)
			l1111ll111l_l1_ = int(100*ii/self.l1111l1l1ll_l1_)
			self.l11lll11111_l1_(l1111ll111l_l1_)
			if self.l1ll1ll1l1l_l1_>0: break
		self.enableButtons()
	def l1l1111llll_l1_(self):
		if self.l111l1ll11l_l1_:
			import threading
			self.l11l111ll1l_l1_ = threading.Thread(target=self.l1l1111111l_l1_,args=())
			self.l11l111ll1l_l1_.start()
			#self.l11l111ll1l_l1_.join()
		else: self.enableButtons()
	def l1l1111111l_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1111l1l1ll_l1_)
		for ii in range(self.l111l1ll11l_l1_-1,-1,-1):
			time.sleep(1)
			l1111ll111l_l1_ = int(100*ii/self.l111l1ll11l_l1_)
			self.l11lll11111_l1_(l1111ll111l_l1_)
			if self.l1ll1ll1l1l_l1_>0: break
		if self.l111l1ll11l_l1_>0: self.l1ll1ll1l1l_l1_ = 10
		self.delete()
	def l11lll11111_l1_(self,l1111ll111l_l1_):
		self.l11lllll1l1_l1_ = l1111ll111l_l1_
		self.getControl(9020).setPercent(self.l11lllll1l1_l1_)
	def enableButtons(self):
		if self.button0!=l1l11l_l1_ (u"ࠬ࠭⬏"): self.getControl(9010).setEnabled(True)
		if self.button1!=l1l11l_l1_ (u"࠭ࠧ⬐"): self.getControl(9011).setEnabled(True)
		if self.button2!=l1l11l_l1_ (u"ࠧࠨ⬑"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		if os.path.exists(self.image_filename): os.remove(self.image_filename)
		#del self
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡤࡦࡨࠣࡹࡵࡪࡡࡵࡧࠫࡷࡪࡲࡦ࠭ࡲࡨࡶࡨ࡫࡮ࡵ࠮࠭ࡥࡷ࡭ࡳࠪ࠼ࠐࠎࠎࠏࡴࡦࡺࡷࠤࡂࠦࡡࡳࡩࡶ࡟࠵ࡣࠍࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡥࡷ࡭ࡳࠪࡀ࠴࠾ࠥࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࡦࡸࡧࡴ࡝࠴ࡡࠒࠐࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡣࡵ࡫ࡸ࠯࠾࠳࠼ࠣࡸࡪࡾࡴࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࡤࡶ࡬ࡹ࡛࠳࡟ࠐࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡵ࡫ࡲࡤࡧࡱࡸ࠱ࡹࡥ࡭ࡨ࠱ࡸࡪࡾࡴࠡ࠿ࠣࡴࡪࡸࡣࡦࡰࡷ࠰ࡹ࡫ࡸࡵࠏࠍࠍࠎࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠰ࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡪࡨ࡭࡬࡮ࡴࠡ࠿ࠣࡷࡪࡲࡦ࠯ࡥࡵࡩࡦࡺࡥࡔࡪࡲࡻࡎࡳࡡࡨࡧࠫࡷࡪࡲࡦ࠯ࡤࡸࡸࡹࡵ࡮࠱࠮ࡶࡩࡱ࡬࠮ࡣࡷࡷࡸࡴࡴ࠱࠭ࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳ࠸ࠬࡴࡧ࡯ࡪ࠳࡮ࡥࡢࡦࡨࡶ࠱ࡹࡥ࡭ࡨ࠱ࡸࡪࡾࡴ࠭ࡵࡨࡰ࡫࠴ࡰࡳࡱࡩ࡭ࡱ࡫ࠬࡴࡧ࡯ࡪ࠳ࡪࡩࡳࡧࡦࡸ࡮ࡵ࡮࠭ࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤࡽࡩࡥࡶ࡫࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯ࡵࡷ࡭ࡲ࡫࡯ࡶࡶ࠯ࡷࡪࡲࡦ࠯ࡥ࡯ࡳࡸ࡫ࡴࡪ࡯ࡨࡳࡺࡺࠩࠎࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡸࡴࡩࡧࡴࡦࡒࡵࡳ࡬ࡸࡥࡴࡵࡅࡥࡷ࠮ࡰࡦࡴࡦࡩࡳࡺࠩࠎࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠯ࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡩࡧ࡬࡫࡭ࡺࠍࠋࠋࠥࠦࠧ⬒")
def l1111lll1ll_l1_(l11l1l1l1l1_l1_,button0=l1l11l_l1_ (u"ࠩࠪ⬓"),button1=l1l11l_l1_ (u"ࠪࠫ⬔"),button2=l1l11l_l1_ (u"ࠫࠬ⬕"),header=l1l11l_l1_ (u"ࠬ࠭⬖"),text=l1l11l_l1_ (u"࠭ࠧ⬗"),l11ll11lll1_l1_=0,l11l111llll_l1_=0,profile=l1l11l_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ⬘")):
	if not l11l1l1l1l1_l1_: l11l1l1l1l1_l1_ = l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ⬙")
	l111l1ll111_l1_ = l1l1ll1lll1_l1_(l1l11l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ⬚"),l1l11l1l111_l1_,l1l11l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ⬛"),l1l11l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ⬜"))
	l111l1ll111_l1_.l1l1l1l1ll1_l1_(button0,button1,button2,header,text,profile,l11l1l1l1l1_l1_,900,l11ll11lll1_l1_,l11l111llll_l1_)
	if l11ll11lll1_l1_>0: l111l1ll111_l1_.l1ll1ll11l1_l1_()
	if l11l111llll_l1_>0: l111l1ll111_l1_.l1l1111llll_l1_()
	if l11ll11lll1_l1_==0 and l11l111llll_l1_==0: l111l1ll111_l1_.enableButtons()
	l111l1ll111_l1_.doModal()
	choice = l111l1ll111_l1_.l1ll1ll1l1l_l1_
	return choice
def l1ll1lll11_l1_(l11l1l1l1l1_l1_,header,text,profile=l1l11l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭⬝")):
	if not l11l1l1l1l1_l1_: l11l1l1l1l1_l1_ = l1l11l_l1_ (u"࠭࡬ࡦࡨࡷࠫ⬞")
	#text = l1l11l_l1_ (u"ࠧ࡝ࡰࠪ⬟").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l1l11l_l1_ (u"ࠨࠩ⬠")
	l111l1ll111_l1_ = xbmcgui.WindowXMLDialog(l1l11l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬ⬡"),l1l11l1l111_l1_,l1l11l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ⬢"),l1l11l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ⬣"))
	image_filename,image_height = CREATE_IMAGE(l1l11l_l1_ (u"ࠬ࠭⬤"),l1l11l_l1_ (u"࠭ࠧ⬥"),l1l11l_l1_ (u"ࠧࠨ⬦"),header,text,profile,l11l1l1l1l1_l1_,1270,False)
	l111l1ll111_l1_.show()
	#time.sleep(1)
	#l111l1ll111_l1_.getControl(9050).l111l1l1111_l1_(1270-60)
	l111l1ll111_l1_.getControl(9050).setHeight(image_height)
	l111l1ll111_l1_.getControl(9050).setImage(image_filename)
	result = l111l1ll111_l1_.doModal()
	#del l111l1ll111_l1_
	if os.path.exists(image_filename): os.remove(image_filename)
	return result
def l1ll11ll1_l1_():
	useragent = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡵࡷࡶࠬ⬧"),l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧ⬨"),l1l11l_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭⬩"))
	if useragent: return useragent
	#LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⬪"),l1l11l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡻࡳࡦࡴࡤ࡫ࡪࡴࡴ࠻ࠢࠪ⬫")+results)
	# l1l1lll1l1l_l1_ and l1l1111111_l1_ common user l11l1ll1111_l1_ (l1l11llllll_l1_ l1ll1ll11ll_l1_)
	text = l1l11l_l1_ (u"࠭ࠧ⬬")
	url = l1l11l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡨࡧ࡭ࡨ࡬ࡰࡩ࠱ࡻ࡮ࡲ࡬ࡴࡪࡲࡹࡸ࡫࠮ࡤࡱࡰ࠳࠷࠶࠱࠳࠱࠳࠵࠴࠶࠳࠰࡯ࡲࡷࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡶ࠳ࠬ⬭")
	headers = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ⬮"):url}
	response = OPENURL_REQUESTS_CACHED(l1llllll1l1_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭⬯"),url,l1l11l_l1_ (u"ࠪࠫ⬰"),headers,l1l11l_l1_ (u"ࠫࠬ⬱"),False,l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭⬲"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l11l_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧ⬳"))
		if count>80:
			text = re.findall(l1l11l_l1_ (u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⬴"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⬵"),l1l11l_l1_ (u"ࠩࠪ⬶"),l1l11l_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠭⬷"),l1l11l_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡘࡗࡊࡘ࠭ࡂࡉࡈࡒ࡙࡙ࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࠫ⬸"))
	if not text:
		text = open(l11lll111l1_l1_,l1l11l_l1_ (u"ࠬࡸࡢࠨ⬹")).read()
		if kodi_version>18.99: text = text.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⬺"))
		text = text.replace(l1l11l_l1_ (u"ࠧ࡝ࡴࠪ⬻"),l1l11l_l1_ (u"ࠨࠩ⬼"))
	l11llll111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫࡑࡴࢀࡩ࡭࡮ࡤ࠲࠯ࡅࠩ࡝ࡰࠪ⬽"),text,re.DOTALL)
	l1ll11ll11l_l1_ = []
	for line in l11llll111l_l1_:
		l111llll11l_l1_ = line.lower()
		if l1l11l_l1_ (u"ࠪࡥࡳࡪࡲࡰ࡫ࡧࠫ⬾") in l111llll11l_l1_: continue
		if l1l11l_l1_ (u"ࠫࡺࡨࡵ࡯ࡶࡸࠫ⬿") in l111llll11l_l1_: continue
		#if l1l11l_l1_ (u"ࠬ࡮ࡴ࡮࡮ࠪ⭀") in l111llll11l_l1_: continue
		l1ll11ll11l_l1_.append(line)
	useragent = random.sample(l1ll11ll11l_l1_,1)
	useragent = useragent[0]
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⭁"),l1l11l_l1_ (u"ࠧࠨ⭂"),str(len(l11llll111l_l1_)),useragent)
	WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭⭃"),l1l11l_l1_ (u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ⭄"),useragent,l111l11l_l1_)
	return useragent
def l1l1ll1llll_l1_(error):
	if l1l11l_l1_ (u"ࠪࡪࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠨ⭅") in str(error).lower(): return
	errortrace = traceback.format_exc()
	sys.stderr.write(errortrace)
	lines = errortrace.splitlines()
	error = lines[-1]
	l1l11lll111_l1_ = open(l11ll1lllll_l1_,l1l11l_l1_ (u"ࠫࡷࡨࠧ⭆")).read()
	if kodi_version>18.99: l1l11lll111_l1_ = l1l11lll111_l1_.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⭇"))
	l1l11lll111_l1_ = l1l11lll111_l1_[-8000:]
	sep = l1l11l_l1_ (u"࠭࠽ࠨ⭈")*100
	if sep in l1l11lll111_l1_: l1l11lll111_l1_ = l1l11lll111_l1_.rsplit(sep,1)[1]
	if error in l1l11lll111_l1_: l1l11lll111_l1_ = l1l11lll111_l1_.rsplit(error,1)[0]
	#l1ll1lll11_l1_(l1l11l_l1_ (u"ࠧࠨ⭉"),error,l1l11lll111_l1_)
	#loglines = l1l11lll111_l1_.splitlines()
	#for line in reversed(loglines):
	#	if l1l11l_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶࠫ⭊") in line: continue
	#	if l1l11l_l1_ (u"ࠩࡐࡳࡩ࡫࠺ࠡ࡝ࠪ⭋") not in line: continue
	l11l1111111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠬࡘࡵࡵࡳࡥࡨࢀࡒࡵࡤࡦࠫ࠽ࠤࡡࡡࠠࠩ࠰࠭ࡃ࠮ࠦ࡜࡞ࠩ⭌"),l1l11lll111_l1_,re.DOTALL)
	for typ,source in reversed(l11l1111111_l1_):
		#if l1l11l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࠭⭍") in source: continue
		#if l1l11l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࠨ⭎") in source: continue
		if source: break
	else: source = l1l11l_l1_ (u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭⭏")
	#l1ll1lll11_l1_(l1l11l_l1_ (u"ࠧࠨ⭐"),source,str(l11l1111111_l1_))
	file,line,func = l1l11l_l1_ (u"ࠨࠩ⭑"),l1l11l_l1_ (u"ࠩࠪ⭒"),l1l11l_l1_ (u"ࠪࠫ⭓")
	l1ll11l11ll_l1_ = l1l11l_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุล࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⭔")+error
	source2 = l1l11l_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆืาี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭕")+source
	for l11ll1l11l1_l1_ in reversed(lines):
		if l1l11l_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭⭖") in l11ll1l11l1_l1_ and l1l11l_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭⭗") in l11ll1l11l1_l1_: break
	l11ll1l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫ⭘"),l11ll1l11l1_l1_,re.DOTALL)
	if l11ll1l11l1_l1_:
		file,line,func = l11ll1l11l1_l1_[0]
		if l1l11l_l1_ (u"ࠩ࠲ࠫ⭙") in file: file = file.rsplit(l1l11l_l1_ (u"ࠪ࠳ࠬ⭚"),1)[1]
		else: file = file.rsplit(l1l11l_l1_ (u"ࠫࡡࡢࠧ⭛"),1)[1]
		l111l1l1l1l_l1_ = l1l11l_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๆไ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⭜")+file
		line2 = l1l11l_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีฺี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭝")+line
		l1ll1ll1l11_l1_ = l1l11l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่็ฬ์࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⭞")+func
		l1l11lll1ll_l1_ = l111l1l1l1l_l1_+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ⭟")+line2+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ⭠")+l1ll1ll1l11_l1_+l1l11l_l1_ (u"ࠪࡠࡳ࠭⭡")+source2+l1l11l_l1_ (u"ࠫࡡࡴࠧ⭢")+l1ll11l11ll_l1_
		l11l1ll11ll_l1_ = line2+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ⭣")+source2+l1l11l_l1_ (u"࠭࡜࡯ࠩ⭤")+l1ll11l11ll_l1_+l1l11l_l1_ (u"ࠧ࡝ࡰࠪ⭥")+l111l1l1l1l_l1_+l1l11l_l1_ (u"ࠨ࡞ࡱࠫ⭦")+l1ll1ll1l11_l1_
		l11lllllll1_l1_ = line2+l1l11l_l1_ (u"ࠩ࡟ࡲࠬ⭧")+l1ll11l11ll_l1_+l1l11l_l1_ (u"ࠪࡠࡳ࠭⭨")+l111l1l1l1l_l1_+l1l11l_l1_ (u"ࠫࡡࡴࠧ⭩")+l1ll1ll1l11_l1_
	else:
		l111l1l1l1l_l1_,line2,l1ll1ll1l11_l1_ = l1l11l_l1_ (u"ࠬ࠭⭪"),l1l11l_l1_ (u"࠭ࠧ⭫"),l1l11l_l1_ (u"ࠧࠨ⭬")
		l1l11lll1ll_l1_ = source2+l1l11l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭⭭")+l1ll11l11ll_l1_
		l11l1ll11ll_l1_ = source2+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ⭮")+l1ll11l11ll_l1_
		l11lllllll1_l1_ = l1ll11l11ll_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l1l11l_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ⭯"),time=2000)
	l1l1ll1ll1l_l1_ = l1l11l_l1_ (u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨ⭰")+l1l11l_l1_ (u"ࠬࡢ࡮ࠨ⭱")
	l11lll1l11_l1_ = l1l1l11llll_l1_()
	l11ll1lll1l_l1_ = []
	results = l11lll1l11_l1_[l1l11l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ⭲")]
	l11ll11llll_l1_ = l1111l1llll_l1_(addon_version)
	if l1l11l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ⭳") in list(l11lll1l11_l1_.keys()):
		for l11l1111lll_l1_,l1l11l11111_l1_,l1ll11l1l11_l1_ in results: l11ll1lll1l_l1_ = max(l11ll1lll1l_l1_,l1l11l11111_l1_)
		if l11ll11llll_l1_<l11ll1lll1l_l1_:
			header = l1l11l_l1_ (u"ࠨไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢๅฬ้ࠦลาีส่ࠥอไฤะฺหฦࠦไๅ็หี๊าࠧ⭴")
			choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ⭵"),l1l11l_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ⭶"),l1l11l_l1_ (u"ࠫฯำฯ๋อࠪ⭷"),l1l11l_l1_ (u"ࠬิั้ฮࠪ⭸"),l1l1ll1ll1l_l1_+header,l1l11lll1ll_l1_)
			if choice==0:
				yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭⭹"),l1l11l_l1_ (u"ࠧฯำ๋ะࠬ⭺"),l1l11l_l1_ (u"ࠨฬะำ๏ัࠧ⭻"),l1l11l_l1_ (u"ࠩࠪ⭼"),header)
				if yes==1: choice = 1
			if choice==1:
				import l111l1l111l_l1_
				l111l1l111l_l1_.l11ll1111ll_l1_()
			return
	l1111l111ll_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⭽"),l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࠩ⭾"),l1l11l_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ⭿"))
	if not l1111l111ll_l1_: l1111l111ll_l1_ = []
	l11l1ll11ll_l1_ = l11l1ll11ll_l1_.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩ⮀"),l1l11l_l1_ (u"ࠧ࡝࡞ࡱࠫ⮁")).replace(l1l11l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ⮂"),l1l11l_l1_ (u"ࠩࠪ⮃")).replace(l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭⮄"),l1l11l_l1_ (u"ࠫࠬ⮅")).replace(l1l11l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⮆"),l1l11l_l1_ (u"࠭ࠧ⮇"))
	l11lllllll1_l1_ = l11lllllll1_l1_.replace(l1l11l_l1_ (u"ࠧ࡝ࡰࠪ⮈"),l1l11l_l1_ (u"ࠨ࡞࡟ࡲࠬ⮉")).replace(l1l11l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ⮊"),l1l11l_l1_ (u"ࠪࠫ⮋")).replace(l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ⮌"),l1l11l_l1_ (u"ࠬ࠭⮍")).replace(l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ⮎"),l1l11l_l1_ (u"ࠧࠨ⮏"))
	l1111ll1lll_l1_ = addon_version+l1l11l_l1_ (u"ࠨ࠼࠽ࠫ⮐")+l11lllllll1_l1_
	if l1111ll1lll_l1_ in l1111l111ll_l1_:
		header = l1l11l_l1_ (u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ⮑")
		#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ⮒"),l1l11l_l1_ (u"ࠫำื่อࠩ⮓"),l1l11l_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ⮔"),l1l1ll1ll1l_l1_+header,l1l11lll1ll_l1_)
		#if yes==1: DIALOG_OK(l1l11l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭⮕"),l1l11l_l1_ (u"ࠧฯำ๋ะࠬ⮖"),l1l11l_l1_ (u"ࠨࠩ⮗"),header)
		DIALOG_OK(l1l11l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ⮘"),l1l11l_l1_ (u"ࠪࠫ⮙"),l1l1ll1ll1l_l1_+header,l1l11lll1ll_l1_)
		return
	l111l1111l1_l1_ = str(kodi_version).split(l1l11l_l1_ (u"ࠫ࠳࠭⮚"))[0]
	#l1ll1l111l1_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠬࡲࡩࡴࡶࠪ⮛"),l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫ⮜"),l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡐࡔࡏࡘࡐࡢࡉࡗࡘࡏࡓࡕࠪ⮝"))
	url = WEBSITES[l1l11l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ⮞")][6]
	response = OPENURL_REQUESTS_CACHED(l111l11l_l1_,l1l11l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⮟"),url,l1l11l_l1_ (u"ࠪࠫ⮠"),l1l11l_l1_ (u"ࠫࠬ⮡"),l1l11l_l1_ (u"ࠬ࠭⮢"),l1l11l_l1_ (u"࠭ࠧ⮣"),l1l11l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪ⮤"),False,False)
	html = response.content
	l1ll1l111l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡕࡗࡅࡗ࡚࠺࠻ࡕࡗࡅࡗ࡚࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࡅࡏࡆ࠽࠾ࡊࡔࡄࠨ⮥"),html,re.DOTALL)
	#WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧ⮦"),l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡌࡐࡒ࡛ࡓࡥࡅࡓࡔࡒࡖࡘ࠭⮧"),l1ll1l111l1_l1_,REGULAR_CACHE)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࠬ⮨"),line+l1l11l_l1_ (u"ࠬࠦࠠࠡࠩ⮩")+error+l1l11l_l1_ (u"࠭ࠠࠡࠢࠪ⮪")+addon_version+l1l11l_l1_ (u"ࠧࠡࠢࠣࠫ⮫")+l111l1111l1_l1_)
	for l1l1ll1l11l_l1_,l1ll11l11l1_l1_,l1l111111ll_l1_,l11l1ll11l1_l1_ in l1ll1l111l1_l1_:
		#LOG_THIS(l1l11l_l1_ (u"ࠨࠩ⮬"),l1l1ll1l11l_l1_+l1l11l_l1_ (u"ࠩࠣࠤࠥ࠭⮭")+l1ll11l11l1_l1_+l1l11l_l1_ (u"ࠪࠤࠥࠦࠧ⮮")+l1l111111ll_l1_+l1l11l_l1_ (u"ࠫࠥࠦࠠࠨ⮯")+l11l1ll11l1_l1_)
		if line==l1l1ll1l11l_l1_ and error==l1ll11l11l1_l1_ and addon_version in l1l111111ll_l1_ and l111l1111l1_l1_ in l11l1ll11l1_l1_:
			header = l1l11l_l1_ (u"ࠬํะศࠢส่ำ฽รࠡ็฼ีํ็้ࠠีํ฽ฬ๊ฬࠡสส่ส฻ฯศำࠣห้่วะ็ࠪ⮰")
			yes = DIALOG_YESNO(l1l11l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ⮱"),l1l11l_l1_ (u"ࠧฯำ๋ะࠬ⮲"),l1l11l_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ⮳"),l1l1ll1ll1l_l1_+header,l1l11lll1ll_l1_)
			if yes==1: DIALOG_OK(l1l11l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ⮴"),l1l11l_l1_ (u"ࠪࠫ⮵"),l1l11l_l1_ (u"ࠫࠬ⮶"),header)
			return
	header = l1l11l_l1_ (u"ࠬอไาฮสลࠥหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ⮷")
	DIALOG_OK(l1l11l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ⮸"),l1l11l_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ⮹"),l1l1ll1ll1l_l1_+header,l1l11lll1ll_l1_)
	yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ⮺"),l1l11l_l1_ (u"ࠩๆ่ฬ࠭⮻"),l1l11l_l1_ (u"๊ࠪ฾๋ࠧ⮼"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⮽"),l1l11l_l1_ (u"ู่ࠬโࠢํฮ๊ࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํ฽ึ็ࠠศๆ่ฬึ๋ฬࠡลํ๊ࠥ๎ๅห๋ࠣ์่๐แ๊ࠡ็้ฬึวࠡฯุ่ฯࠦ็ั้ࠣห้๋ิไๆฬࠤ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦวึๆสั๋ࠥิไๆฬࠤํํ่ࠡๆสࠤ๏฿ัโࠢๆ๎ๆุ่ࠦำอࠤํ๊ๅศาสࠤ฽ํัห๋้ࠢฯ๏ู้ࠠิฮࠥํะ่ࠢสฺ่๊ใๅหࠣ࠲ࠥํไࠡฬิ๎ิࠦราีส่ࠥอไิฮ็ࠤฤ࠭⮾"))
	if yes==1: l1111llll11_l1_ = l1l11l_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ⮿")
	else:
		DIALOG_OK(l1l11l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ⯀"),l1l11l_l1_ (u"ࠨࠩ⯁"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⯂"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢศู้ออࠡษ็า฼ษࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣห้ึ๊ࠡ็ๆฮํฮࠠโ์๊ࠤัฺ๋๊ࠢอๅฬ฻๊ๅ๊ࠢิฬࠦวๅะฺวࠥ๎ฺ๋ำ๊ࠤ๊์ࠠศๆฦา฼อมࠨ⯃"))
		return
	message = l11l1ll11ll_l1_
	l11ll11l1ll_l1_ = l1l11l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ⯄")+l1l11ll111l_l1_(32)+l1l11l_l1_ (u"ࠬ࠳ࡅࡳࡴࡲࡶࡸ࠭⯅")
	import l111l1l111l_l1_
	succeeded = l111l1l111l_l1_.l1l1lll111l_l1_(l11ll11l1ll_l1_,message,True,l1l11l_l1_ (u"࠭ࠧ⯆"),l1l11l_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ⯇"),l1111llll11_l1_)
	if succeeded and l1111llll11_l1_:
		l1111l111ll_l1_.append(l1111ll1lll_l1_)
		WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡏࡌࡗࡈ࠭⯈"),l1l11l_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ⯉"),l1111l111ll_l1_,PERMANENT_CACHE)
	return
def l11l1l11lll_l1_(l11lll1l1ll_l1_):
	l111ll1lll1_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ⯊"))
	#l11lll1l1ll_l1_ = l11lll1l1ll_l1_.encode(l1l11l_l1_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ⯋")).replace(l1l11l_l1_ (u"ࠬࡢ࡮ࠨ⯌"),l1l11l_l1_ (u"࠭ࠧ⯍"))
	user = l1l11ll111l_l1_(32)
	import hashlib
	md5 = hashlib.md5((l1l11l_l1_ (u"࡙ࠧ࠳࠼ࠫ⯎")+l11lll1l1ll_l1_+l1l11l_l1_ (u"ࠨ࠳࠻ࡁࠬ⯏")+user).encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⯐"))).hexdigest()[0:32]
	if md5 in l111ll1lll1_l1_: return True
	return False
def WRITE_THIS(l1l1lll1l1_l1_,data):
	if kodi_version>18.99: data = data.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⯑"))
	if l1l1lll1l1_l1_==l1l11l_l1_ (u"ࠫࠬ⯒"): filename = l1l11l_l1_ (u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ⯓")
	else: filename = l1l11l_l1_ (u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭⯔")+str(now)+l1l11l_l1_ (u"ࠧ࠯ࡦࡤࡸࠬ⯕")
	open(filename,l1l11l_l1_ (u"ࠨࡹࡥࠫ⯖")).write(data)
	return
def l1ll1l1l1ll_l1_():
	l1l1l1lll11_l1_ = settings.getSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ⯗"))
	if l1l1l1lll11_l1_:
		l111llllll1_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯘"),l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࠩ⯙"),l1l11l_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ⯚"))
		if l111llllll1_l1_: return l111llllll1_l1_
	l111l1lllll_l1_ = l1l11ll111l_l1_(32)
	payload = {l1l11l_l1_ (u"࠭ࡵࡴࡧࡵࠫ⯛"):l111l1lllll_l1_}
	url = WEBSITES[l1l11l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ⯜")][5]
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭⯝"),url,payload,l1l11l_l1_ (u"ࠩࠪ⯞"),l1l11l_l1_ (u"ࠪࠫ⯟"),l1l11l_l1_ (u"ࠫࠬ⯠"),l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠳࠱ࡴࡶࠪ⯡"))
	if not response.succeeded: return []
	l1ll1lll1ll_l1_ = response.content
	l1ll1lll1ll_l1_ = l1ll1lll1ll_l1_.replace(l1l11l_l1_ (u"࠭࡜࡝ࡴࠪ⯢"),l1l11l_l1_ (u"ࠧ࡝ࡰࠪ⯣")).replace(l1l11l_l1_ (u"ࠨ࡞࡟ࡲࠬ⯤"),l1l11l_l1_ (u"ࠩ࡟ࡲࠬ⯥")).replace(l1l11l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ⯦"),l1l11l_l1_ (u"ࠫࡡࡴࠧ⯧")).replace(l1l11l_l1_ (u"ࠬࡢࡲࠨ⯨"),l1l11l_l1_ (u"࠭࡜࡯ࠩ⯩")).replace(l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ⯪"),l1l11l_l1_ (u"ࠨ࡞ࡱࠫ⯫"))
	l1ll1lll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ⯬"),l1ll1lll1ll_l1_,re.DOTALL)
	if not l1ll1lll1ll_l1_: return []
	l1ll1lll1ll_l1_ = sorted(l1ll1lll1ll_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1111l1ll11_l1_,l111l11ll11_l1_,answer,l1l1l1lllll_l1_,reason = l1ll1lll1ll_l1_[0]
	if l1l11l_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ⯭") not in reason: l11l1l11l11_l1_,l11l1l11l1l_l1_,l11l1l11ll1_l1_ = reason,reason,reason
	else: l11l1l11l11_l1_,l11l1l11l1l_l1_,l11l1l11ll1_l1_ = reason.split(l1l11l_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ⯮"),2)
	settings.setSetting(l1l11l_l1_ (u"ࠬࡧࡶ࠯࡫ࡱࡪࡴࡹ࠮ࡱࡧࡵ࡭ࡴࡪࠧ⯯"),l111l11ll11_l1_)
	#settings.setSetting(l1l11l_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡮ࡲࡲ࡬࠭⯰"),l11l1l11l11_l1_)
	settings.setSetting(l1l11l_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡯ࡳࡳ࡭ࠧ⯱"),l1l11l_l1_ (u"ࠨࠩ⯲"))
	settings.setSetting(l1l11l_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ⯳"),l1l11l_l1_ (u"ࠪࠫ⯴"))
	WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠫࡒࡏࡓࡄࠩ⯵"),l1l11l_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ⯶"),l1ll1lll1ll_l1_,REGULAR_CACHE)
	return l1ll1lll1ll_l1_
def SPLIT_BIGLIST(l1ll111l1ll_l1_,splits_count):
	length = len(l1ll111l1ll_l1_)
	l1ll1l11ll1_l1_ = []
	for ii in range(1,splits_count+1):
		if ii!=splits_count:
			l1l1ll1111l_l1_ = l1ll111l1ll_l1_[0:int(length/splits_count)]
			del l1ll111l1ll_l1_[0:int(length/splits_count)]
		else:
			l1l1ll1111l_l1_ = l1ll111l1ll_l1_
			del l1ll111l1ll_l1_
		l1ll1l11ll1_l1_.append(l1l1ll1111l_l1_)
		del l1l1ll1111l_l1_
	return l1ll1l11ll1_l1_
def l1l1l11l1l1_l1_(filename,data):
	filepath = os.path.join(l1l1ll1l11_l1_,filename)
	#setattr(dummy,l1l11l_l1_ (u"࠭ࡤࡶ࡯ࡰࡽࡳࡧ࡭ࡦࠩ⯷"),data)
	#text = pickle.dumps(dummy)
	if 1 or l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚ࡤ࠭⯸") not in filename: text = str(data)
	else:
		l11l1l1111l_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l11l_l1_ (u"ࠨࠩ⯹")
		for split in l11l1l1111l_l1_:
			text += str(split)+l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ⯺")
		text = text.strip(l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ⯻"))
	compressed = zlib.compress(text)
	open(filepath,l1l11l_l1_ (u"ࠫࡼࡨࠧ⯼")).write(compressed)
	return
def l1ll11ll111_l1_(results_type,filename):
	if results_type==l1l11l_l1_ (u"ࠬࡪࡩࡤࡶࠪ⯽"): data = {}
	elif results_type==l1l11l_l1_ (u"࠭࡬ࡪࡵࡷࠫ⯾"): data = []
	elif results_type==l1l11l_l1_ (u"ࠧࡴࡶࡵࠫ⯿"): data = l1l11l_l1_ (u"ࠨࠩⰀ")
	elif results_type==l1l11l_l1_ (u"ࠩ࡬ࡲࡹ࠭Ⰱ"): data = 0
	else: data = None
	filepath = os.path.join(l1l1ll1l11_l1_,filename)
	compressed = open(filepath,l1l11l_l1_ (u"ࠪࡶࡧ࠭Ⰲ")).read()
	text = zlib.decompress(compressed)
	#open(l1l11l_l1_ (u"ࠫࡸࡀ࡜࡝ࡋࡓࡘ࡛࠷࠮ࡵࡺࡷࠫⰃ"),l1l11l_l1_ (u"ࠬࡽࡢࠨⰄ")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l1l11l_l1_ (u"࠭ࡤࡶ࡯ࡰࡽࡳࡧ࡭ࡦࠩⰅ"))
	#if l1l11l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭Ⰶ") not in text: data = EVAL(l1l11l_l1_ (u"ࠨࡵࡷࡶࠬⰇ"),text)
	if l1l11l_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨⰈ") not in text: data = eval(text)
	else:
		l11l1l1111l_l1_ = text.split(l1l11l_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩⰉ"))
		del text
		data = []
		l1l1lll1ll1_l1_ = l1l1ll1l111_l1_()
		id = 0
		for split in l11l1l1111l_l1_:
			#data += EVAL(l1l11l_l1_ (u"ࠫࡸࡺࡲࠨⰊ"),split)
			l1l1lll1ll1_l1_.l1l1l1llll1_l1_(str(id),eval,split)
			id += 1
		del l11l1l1111l_l1_
		l1l1lll1ll1_l1_.l11l11ll1ll_l1_()
		l1l1lll1ll1_l1_.l11l1l1l1ll_l1_()
		l111l11l1ll_l1_ = list(l1l1lll1ll1_l1_.l1l111l11l1_l1_.keys())
		l111ll11l1l_l1_ = sorted(l111l11l1ll_l1_,reverse=False,key=lambda key: int(key))
		for id in l111ll11l1l_l1_:
			data += l1l1lll1ll1_l1_.l1l111l11l1_l1_[id]
	return data
def l111llll1l1_l1_(addon_id):
	l1ll111lll1_l1_ = os.path.join(l11l1l11111_l1_,l1l11l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬⰋ"),addon_id,l1l11l_l1_ (u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩⰌ"))
	try: l11lll1lll1_l1_ = open(l1ll111lll1_l1_,l1l11l_l1_ (u"ࠧࡳࡤࠪⰍ")).read()
	except:
		l11l1llll11_l1_ = os.path.join(l1l1111ll11_l1_,l1l11l_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨⰎ"),addon_id,l1l11l_l1_ (u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬⰏ"))
		try: l11lll1lll1_l1_ = open(l11l1llll11_l1_,l1l11l_l1_ (u"ࠪࡶࡧ࠭Ⱀ")).read()
		except: return l1l11l_l1_ (u"ࠫࠬⰑ"),[]
	if kodi_version>18.99: l11lll1lll1_l1_ = l11lll1lll1_l1_.decode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪⰒ"))
	version = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃ࡛࡝ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡࠨ࡜ࠨ࡟ࠪⰓ"),l11lll1lll1_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l11l_l1_ (u"ࠧࠨⰔ"),[]
	l1ll1llll11_l1_,l1l111llll1_l1_ = version[0],l1111l1llll_l1_(version[0])
	return l1ll1llll11_l1_,l1l111llll1_l1_
def l1l1l11llll_l1_():
	l1l11l1ll1l_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭Ⱅ"),l1l11l_l1_ (u"ࠩࡐࡍࡘࡉࠧⰖ"),l1l11l_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫⰗ"))
	if l1l11l1ll1l_l1_: return l1l11l1ll1l_l1_
	l11lll1l11_l1_,l1l11l1ll1l_l1_ = {},{}
	l11l1111111_l1_ = [WEBSITES[l1l11l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪⰘ")][1]]
	if kodi_version>17.99: l11l1111111_l1_.append(WEBSITES[l1l11l_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫⰙ")][2])
	if kodi_version>18.99: l11l1111111_l1_.append(WEBSITES[l1l11l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬⰚ")][3])
	for l111lll11ll_l1_ in l11l1111111_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫⰛ"),l111lll11ll_l1_,l1l11l_l1_ (u"ࠨࠩⰜ"),l1l11l_l1_ (u"ࠩࠪⰝ"),l1l11l_l1_ (u"ࠪࠫⰞ"),False,l1l11l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨⰟ"))
		if response.succeeded:
			html = response.content
			l1111llllll_l1_ = l111lll11ll_l1_.rsplit(l1l11l_l1_ (u"ࠬ࠵ࠧⰠ"),1)[0]
			l1l11l1lll1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⰡ"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1l1l111ll1_l1_ in l1l11l1lll1_l1_:
				l1l1l1lll1l_l1_ = l1111llllll_l1_+l1l11l_l1_ (u"ࠧ࠰ࠩⰢ")+addon_id+l1l11l_l1_ (u"ࠨ࠱ࠪⰣ")+addon_id+l1l11l_l1_ (u"ࠩ࠰ࠫⰤ")+l1l1l111ll1_l1_+l1l11l_l1_ (u"ࠪ࠲ࡿ࡯ࡰࠨⰥ")
				if addon_id not in list(l11lll1l11_l1_.keys()):
					l11lll1l11_l1_[addon_id] = []
					l1l11l1ll1l_l1_[addon_id] = []
				l11ll111l1l_l1_ = l1111l1llll_l1_(l1l1l111ll1_l1_)
				l11lll1l11_l1_[addon_id].append((l1l1l111ll1_l1_,l11ll111l1l_l1_,l1l1l1lll1l_l1_))
	for addon_id in list(l11lll1l11_l1_.keys()):
		#LOG_THIS(l1l11l_l1_ (u"ࠫࠬⰦ"),str(addon_id)+l1l11l_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫⰧ")+str(l11lll1l11_l1_[addon_id]))
		l1l11l1ll1l_l1_[addon_id] = sorted(l11lll1l11_l1_[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫⰨ"),l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨⰩ"),l1l11l1ll1l_l1_,REGULAR_CACHE)
	return l1l11l1ll1l_l1_
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ࠯ࠍࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡥࡨࡱ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡰࡦࡨࡦࡪࡸࡧ࠯ࡱࡵ࡫࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡦࡷࡧ࡮ࡤࡪ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡧࡤ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵ࡢࡳࡣࡱࡧ࡭࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸࡪ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠷࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࠨࠢࠣⰪ")
def l1111l1llll_l1_(l1l1l111ll1_l1_):
	l11ll111l1l_l1_ = []
	l111l111lll_l1_ = l1l1l111ll1_l1_.split(l1l11l_l1_ (u"ࠩ࠱ࠫⰫ"))
	for l1ll11lll1l_l1_ in l111l111lll_l1_:
		parts = re.findall(l1l11l_l1_ (u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧⰬ"),l1ll11lll1l_l1_,re.DOTALL)
		l111l11llll_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l111l11llll_l1_.append(part)
		l11ll111l1l_l1_.append(l111l11llll_l1_)
	#LOG_THIS(l1l11l_l1_ (u"ࠫࠬⰭ"),str(l1l1l111ll1_l1_)+l1l11l_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫⰮ")+str(l11ll111l1l_l1_))
	return l11ll111l1l_l1_
def l11l1l1lll1_l1_(l11ll111l1l_l1_):
	l1l1l111ll1_l1_ = l1l11l_l1_ (u"࠭ࠧⰯ")
	for l1ll11lll1l_l1_ in l11ll111l1l_l1_:
		for part in l1ll11lll1l_l1_: l1l1l111ll1_l1_ += str(part)
		l1l1l111ll1_l1_ += l1l11l_l1_ (u"ࠧ࠯ࠩⰰ")
	l1l1l111ll1_l1_ = l1l1l111ll1_l1_.strip(l1l11l_l1_ (u"ࠨ࠰ࠪⰱ"))
	#LOG_THIS(l1l11l_l1_ (u"ࠩࠪⰲ"),str(l11ll111l1l_l1_)+l1l11l_l1_ (u"ࠪࠤࠥ࠴ࠠࠡࠩⰳ")+str(l1l1l111ll1_l1_))
	return l1l1l111ll1_l1_
def l11lllll111_l1_(l1ll11l1lll_l1_=l1l11l1l1l1_l1_):
	# l11ll1111l1_l1_ not l1ll1111ll1_l1_ l11l11ll111_l1_ l111ll1l111_l1_ l11lll1l11_l1_ status l11ll1ll11_l1_ l1ll11ll11_l1_ l1l1l1l111_l1_ l1l1l1l1lll_l1_
	#l111l11111l_l1_ = READ_FROM_SQL3(cache_dbfile,l1l11l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩⰴ"),l1l11l_l1_ (u"ࠬࡓࡉࡔࡅࠪⰵ"),l1l11l_l1_ (u"࠭ࡅࡎࡃࡇࡣࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬⰶ"))
	#if l111l11111l_l1_: return l111l11111l_l1_
	l111l11111l_l1_ = {}
	l11lll1l11_l1_ = l1l1l11llll_l1_()
	l1ll1l11l1l_l1_ = l11l11ll1l1_l1_(l1ll11l1lll_l1_)
	for addon_id in l1ll11l1lll_l1_:
		if addon_id not in list(l11lll1l11_l1_.keys()): continue
		#if not l11lll1l11_l1_[addon_id]: continue
		l1l11l1ll1l_l1_ = l11lll1l11_l1_[addon_id]
		l1ll1l1111l_l1_,l1ll1llll1l_l1_,l11111llll1_l1_ = l1l11l1ll1l_l1_[0]
		#l11ll1l1l1l_l1_ = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧⰷ")+addon_id+l1l11l_l1_ (u"ࠨࠫࠪⰸ"))
		l11ll1l1l1l_l1_,l1l1l1ll1l1_l1_ = l111llll1l1_l1_(addon_id)
		l1ll111ll11_l1_,l11lll11ll1_l1_ = l1ll1l11l1l_l1_[addon_id]
		l1ll1l1ll1l_l1_ = l1ll1llll1l_l1_>l1l1l1ll1l1_l1_ and l1ll111ll11_l1_
		l1111l11111_l1_ = True
		if not l1ll111ll11_l1_: l1ll11lllll_l1_ = l1l11l_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪⰹ")
		elif not l11lll11ll1_l1_: l1ll11lllll_l1_ = l1l11l_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬⰺ")
		elif l1ll1l1ll1l_l1_: l1ll11lllll_l1_ = l1l11l_l1_ (u"ࠫࡴࡲࡤࠨⰻ")
		else:
			l1ll11lllll_l1_ = l1l11l_l1_ (u"ࠬ࡭࡯ࡰࡦࠪⰼ")
			l1111l11111_l1_ = False
		l111l11111l_l1_[addon_id] = (l1111l11111_l1_,l11ll1l1l1l_l1_,l1l1l1ll1l1_l1_,l1ll1l1111l_l1_,l1ll1llll1l_l1_,l1ll11lllll_l1_,l11111llll1_l1_)
	#WRITE_TO_SQL3(cache_dbfile,l1l11l_l1_ (u"࠭ࡍࡊࡕࡆࠫⰽ"),l1l11l_l1_ (u"ࠧࡆࡏࡄࡈࡤࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭ⰾ"),l111l11111l_l1_,REGULAR_CACHE)
	return l111l11111l_l1_
	l1l11l_l1_ (u"ࠣࠤࠥࠑࠏࠏࠣࡪࡨࠣࡺࡪࡸࡳࡪࡱࡱ࠾ࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠱࡯ࡳࡠࡧࡻ࡭ࡸࡺࠬࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡࡸࡨࡶࡸ࡯࡯࡯࠮ࡗࡶࡺ࡫ࠬࡕࡴࡸࡩࠒࠐࠉࠤࡧ࡯ࡷࡪࡀࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠬࡪࡵࡢࡩࡽ࡯ࡳࡵ࠮࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣࠫࠬ࠲ࡆࡢ࡮ࡶࡩ࠱ࡌࡡ࡭ࡵࡨࠑࠏࠏࠣࡪࡵࡢࡩࡽ࡯ࡳࡵࠢࡀࠤ࠭ࡾࡢ࡮ࡥ࠱࡫ࡪࡺࡃࡰࡰࡧ࡚࡮ࡹࡩࡣ࡫࡯࡭ࡹࡿࠨࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠫࠪ࠭ࡂࡃ࠱ࠪࠏࠍࠍࠨ࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡂࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷࡄࠧࠨࠏࠍࠍࠨ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦࠨࡹࡤࡰࡧ࠳࡭ࡥࡵࡅࡲࡲࡩ࡜ࡩࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠪࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡋࡶࡉࡳࡧࡢ࡭ࡧࡧࠬࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠬࠫ࠮ࡃ࠽࠲ࠫࠐࠎࠎࠩࡥ࡭ࡵࡨ࠾ࠥ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤࡳࡵࡴࠡࠪ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡣࡱࡨࠥࡴ࡯ࡵࠢ࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡫࡭࡬࡮ࡥࡴࡶࡢࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨࠍࠎ࠭ࠫࡴࡶࡵࠬ࡭࡯ࡧࡩࡧࡶࡸࡤࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨࠎࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡵ࡬ࡥࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡰ࡮ࡧ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧ࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩࠎࠏࠧࠬࡵࡷࡶ࠭ࡴࡥࡦࡦࡢࡹࡵࡪࡡࡵࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡶࡸࡦࡺࡵࡴࠋࠌࠫ࠰ࡹࡴࡳࠪ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡹࡴࡢࡶࡸࡷ࠮࠯ࠍࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡹࡩࡷࡹࡩࡰࡰࡶ࠾ࠥࠦࠧࠬࡵࡷࡶ࠭ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࠬ࠯ࠬࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡼ࡮ࡹࡴࠪ࠭ࠪࠤࠥ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠪࠫࠐࠎࠎࠨࠢࠣⰿ")
def PROGRESS_UPDATE(pDialog,l1l111ll111_l1_,l1l1ll11lll_l1_=l1l11l_l1_ (u"ࠩࠪⱀ"),line2=l1l11l_l1_ (u"ࠪࠫⱁ"),l1l1ll1l11l_l1_=l1l11l_l1_ (u"ࠫࠬⱂ")):
	if kodi_version<19: pDialog.update(l1l111ll111_l1_,l1l1ll11lll_l1_,line2,l1l1ll1l11l_l1_)
	else: pDialog.update(l1l111ll111_l1_,l1l1ll11lll_l1_+l1l11l_l1_ (u"ࠬࡢ࡮ࠨⱃ")+line2+l1l11l_l1_ (u"࠭࡜࡯ࠩⱄ")+l1l1ll1l11l_l1_)
	return
def l11l11llll1_l1_(l11ll11ll11_l1_):
	# l1ll1111ll1_l1_ it for this:  function(p,a,c,k,e,d)
	def l11lll1ll1l_l1_(num,b,l11l111l1l1_l1_=l1l11l_l1_ (u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࠤⱅ")):
		return ((num == 0) and l11l111l1l1_l1_[0]) or (l11lll1ll1l_l1_(num // b, b, l11l111l1l1_l1_).lstrip(l11l111l1l1_l1_[0]) + l11l111l1l1_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l11l_l1_ (u"ࠣ࡞࡟ࡦࠧⱆ") + l11lll1ll1l_l1_(c, a) + l1l11l_l1_ (u"ࠤ࡟ࡠࡧࠨⱇ"),  k[c], p)
		return p
	l11ll11ll11_l1_ = l11ll11ll11_l1_.split(l1l11l_l1_ (u"ࠪࢁ࠭࠭ⱈ"))[1][:-1]
	l11l1111l1l_l1_ = eval(l1l11l_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬⱉ")+l11ll11ll11_l1_,{l1l11l_l1_ (u"ࠬࡨࡡࡴࡧࡑࠫⱊ"):l11lll1ll1l_l1_,l1l11l_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭ⱋ"):unpack})   #,locals())
	return l11l1111l1l_l1_
def l1llllllll_l1_(url,l11l1l111l1_l1_=l1l11l_l1_ (u"ࠧࠨⱌ")):
	if l11l1l111l1_l1_==l1l11l_l1_ (u"ࠨ࡮ࡲࡻࡪࡸࠧⱍ"): url = re.sub(l1l11l_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩⱎ"),lambda l1ll1ll111l_l1_: l1ll1ll111l_l1_.group(0).lower(),url)
	elif l11l1l111l1_l1_==l1l11l_l1_ (u"ࠪࡹࡵࡶࡥࡳࠩⱏ"): url = re.sub(l1l11l_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫⱐ"),lambda l1ll1ll111l_l1_: l1ll1ll111l_l1_.group(0).upper(),url)
	return url
def l11l11ll1l1_l1_(l1ll11l1lll_l1_):
	installed,l1l1111ll1l_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l111llll1ll_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l1ll11l1lll_l1_)==1: l1l1l1l1l11_l1_ = l1l11l_l1_ (u"ࠬ࠮ࠢࠨⱑ")+l1ll11l1lll_l1_[0]+l1l11l_l1_ (u"࠭ࠢࠪࠩⱒ")
	else: l1l1l1l1l11_l1_ = str(tuple(l1ll11l1lll_l1_))
	cc.execute(l1l11l_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧⱓ")+l1l1l1l1l11_l1_+l1l11l_l1_ (u"ࠨࠢ࠾ࠫⱔ"))
	rows = cc.fetchall()
	l1ll1l11l1l_l1_ = {}
	for addon_id in l1ll11l1lll_l1_: l1ll1l11l1l_l1_[addon_id] = (False,False)
	for addon_id,l1l1111ll1l_l1_ in rows:
		installed = True
		l1l1111ll1l_l1_ = l1l1111ll1l_l1_==1
		l1ll1l11l1l_l1_[addon_id] = (installed,l1l1111ll1l_l1_)
	conn.close()
	return l1ll1l11l1l_l1_
def FIX_AND_GET_FILE_CONTENTS(file,showDialogs):
	new_dict = {}
	if os.path.exists(file):
		oldFILE = open(file,l1l11l_l1_ (u"ࠩࡵࡦࠬⱕ")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨⱖ"))
		l1l11l11l11_l1_ = EVAL(l1l11l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩⱗ"),oldFILE,file)
		for key in l1l11l11l11_l1_.keys():
			new_dict[key] = []
			for l11ll1l1lll_l1_ in l1l11l11l11_l1_[key]:
				type,name,url,mode,image,page,text,context,infodict = l1l11l_l1_ (u"ࠬ࠭ⱘ"),l1l11l_l1_ (u"࠭ࠧⱙ"),l1l11l_l1_ (u"ࠧࠨⱚ"),l1l11l_l1_ (u"ࠨࠩⱛ"),l1l11l_l1_ (u"ࠩࠪⱜ"),l1l11l_l1_ (u"ࠪࠫⱝ"),l1l11l_l1_ (u"ࠫࠬⱞ"),l1l11l_l1_ (u"ࠬ࠭ⱟ"),l1l11l_l1_ (u"࠭ࠧⱠ")
				type = l11ll1l1lll_l1_[0]
				name = l11ll1l1lll_l1_[1]
				url = l11ll1l1lll_l1_[2]
				mode = l11ll1l1lll_l1_[3]
				image = l11ll1l1lll_l1_[4]
				page = l11ll1l1lll_l1_[5]
				if len(l11ll1l1lll_l1_)>6: text = l11ll1l1lll_l1_[6]
				if len(l11ll1l1lll_l1_)>7: context = l11ll1l1lll_l1_[7]
				if len(l11ll1l1lll_l1_)>8: infodict = l11ll1l1lll_l1_[8]
				if file==favouritesfile:
					name = RESTORE_PATH_NAME(name)
					context,infodict = l1l11l_l1_ (u"ࠧࠨⱡ"),l1l11l_l1_ (u"ࠨࠩⱢ")
				new_dict[key].append((type,name,url,mode,image,page,text,context,infodict))
		newFILE = str(new_dict)
		if kodi_version>18.99: newFILE = newFILE.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧⱣ"))
		open(file,l1l11l_l1_ (u"ࠪࡻࡧ࠭Ɽ")).write(newFILE)
		# l1l11llll1l_l1_ will cause extra l111l11ll11_l1_ for main l11111l1l_l1_
		#xbmc.executebuiltin(l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨⱥ"))
		if showDialogs: DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭ⱦ"),l1l11l_l1_ (u"࠭ࠧⱧ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪⱨ"),l1l11l_l1_ (u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤส฻ไศฯࠣห้๋ไโࠩⱩ"))
	return new_dict
def l1lllll1111_l1_(site):
	l1lllll1l1l_l1_ = site.split(l1l11l_l1_ (u"ࠩ࠰ࠫⱪ"),1)[0]
	l1lllll1l11_l1_,l1llllll11l_l1_,l11111ll11_l1_ = l1l11l_l1_ (u"ࠪࠫⱫ"),l1l11l_l1_ (u"ࠫࠬⱬ"),l1l11l_l1_ (u"ࠬ࠭Ɑ")
	if   l1lllll1l1l_l1_==l1l11l_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬⱮ")		:	from l11l1_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩⱯ")	:	from l1111ll_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧⱰ")		:	from l11ll1_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩⱱ")	:	from l1l111l1_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬⱲ")	:	from l1lllllll_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧⱳ")	: 	from l1lll1l1l_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧⱴ")	:	from l1lll1l11_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨⱵ")	:	from l1l1l1l11_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭ⱶ")		:	from l11ll1l11_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨⱷ")	:	from l11l1ll1l_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫⱸ")	:	from l111l111l_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬⱹ")	:	from l11111lll_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧⱺ")	:	from l1111111l_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ⱻ")	:	from l11111111_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫⱼ"):	from l1lll11l1l_l1_	import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨⱽ")	:	from l1l111111l_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩⱾ")	:	from l11l11l1ll_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩⱿ")	:	from l11l11l1l1_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭Ⲁ")	:	from l1111lll11_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ⲁ")	:	from l1llll1ll11_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧⲂ")	:	from l111l1ll1_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬⲃ")		:	from l1llll1l1l1_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬⲄ")		:	from IPTV			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫⲅ")	:	from l1lll1l1111_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪⲆ")	:	from l1ll1lll11l_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪⲇ")	:	from l11l111ll11_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫⲈ")	:	from l11l1ll1l1l_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬⲉ")	:	from l111lllll11_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬⲊ")		:	from l1l1ll1ll11_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩⲋ")	:	from l111lll1lll_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫⲌ")	:	from l1l1lll1111_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫⲍ")	:	from l1ll1l1lll1_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬⲎ")	:	from l111l1llll1_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪⲏ")		:	from l1l1111l1ll_l1_			import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭Ⲑ")	:	from l1ll1l11l11_l1_		import MENU as l1lllll1l11_l1_,SEARCH as l1llllll11l_l1_,menu_name as l11111ll11_l1_
	elif l1lllll1l1l_l1_==l1l11l_l1_ (u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬⲑ"):	from l1ll11l1l1l_l1_	import MENU as l1lllll1l11_l1_
	return l1lllll1l11_l1_,l1llllll11l_l1_,l11111ll11_l1_
def DOWNLOAD_USING_PROGRESSBAR(l11111lllll_l1_,headers={}):
	#yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠧࠨⲒ"),l1l11l_l1_ (u"ࠨࠩⲓ"),l1l11l_l1_ (u"ࠩࠪⲔ"),l1l11l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ⲕ"),l1l11l_l1_ (u"ุࠫ๎แࠡ์อ้ࠥอไร่ࠣะ้ฮࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠๆ่ࠣห้หๆหำ้ฮࠥ๎โะࠢํ็ํ์ࠠไสํีࠥ๎โะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠦ࠭Ⲗ"))
	#if yes!=1: return
	LOG_THIS(l1l11l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬⲗ"),l1l11l_l1_ (u"࠭࠮ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧ࠻ࠢ࡞ࠤࠬⲘ")+l11111lllll_l1_+l1l11l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪⲙ")+str(headers)+l1l11l_l1_ (u"ࠨࠢࡠࠫⲚ"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⲛ"),l1l11l_l1_ (u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬⲜ"))
	MegaByte = 1024*1024
	l111l1ll1ll_l1_ = bytes()
	chunk_size = 1*MegaByte
	import requests
	headers2 = headers
	headers2[l1l11l_l1_ (u"ࠫࡗࡧ࡮ࡨࡧࠪⲝ")] = l1l11l_l1_ (u"ࠬࡨࡹࡵࡧࡶࡁ࠵࠳ࠧⲞ")
	response = requests.get(l11111lllll_l1_,stream=True,headers=headers2,timeout=120)
	if l1l11l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧⲟ") not in list(response.headers.keys()):
		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨⲠ"),l1l11l_l1_ (u"ࠨࠩⲡ"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⲢ"),l1l11l_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭ⲣ"))
		return
	filesize = int(response.headers[l1l11l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬⲤ")])
	l1ll1l1l11_l1_ = str(int(1000*filesize/MegaByte)/1000.0)
	l1ll11111l_l1_ = int(filesize/chunk_size)+1
	if l1l11l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡒࡢࡰࡪࡩࠬⲥ") in list(response.headers.keys()) and filesize>MegaByte:
		l11ll1l1ll1_l1_ = True
		l111l111lll_l1_ = []
		l1l1l111l11_l1_ = 10
		l111l111lll_l1_.append(str(0*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"࠭࠭ࠨⲦ")+str(1*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(1*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠧ࠮ࠩⲧ")+str(2*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(2*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠨ࠯ࠪⲨ")+str(3*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(3*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠩ࠰ࠫⲩ")+str(4*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(4*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠪ࠱ࠬⲪ")+str(5*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(5*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠫ࠲࠭ⲫ")+str(6*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(6*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠬ࠳ࠧⲬ")+str(7*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(7*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"࠭࠭ࠨⲭ")+str(8*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(8*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠧ࠮ࠩⲮ")+str(9*filesize//l1l1l111l11_l1_-1))
		l111l111lll_l1_.append(str(9*filesize//l1l1l111l11_l1_)+l1l11l_l1_ (u"ࠨ࠯ࠪⲯ"))
		l1ll11lll11_l1_ = float(l1ll11111l_l1_)/l1l1l111l11_l1_
		l1l11111l11_l1_ = l1ll11lll11_l1_/int(1+l1ll11lll11_l1_)
	else:
		l11ll1l1ll1_l1_ = False
		l1l1l111l11_l1_ = 1
		l1l11111l11_l1_ = 1
	response.close()
	LOG_THIS(l1l11l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩⲰ"),l1l11l_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡧࡹ࡯࡯࡯ࡵ࠽ࠤࡠࠦࠧⲱ")+str(l11ll1l1ll1_l1_)+l1l11l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭Ⲳ")+str(filesize)+l1l11l_l1_ (u"ࠬࠦ࡝ࠨⲳ"))
	ii = 0
	#t1 = time.time()-30
	for jj in range(l1l1l111l11_l1_):
		headers2 = headers
		if l11ll1l1ll1_l1_: headers2[l1l11l_l1_ (u"࠭ࡒࡢࡰࡪࡩࠬⲴ")] = l1l11l_l1_ (u"ࠧࡣࡻࡷࡩࡸࡃࠧⲵ")+l111l111lll_l1_[jj]
		response = requests.get(l11111lllll_l1_,stream=True,headers=headers2,timeout=120)
		for chunk in response.iter_content(chunk_size=chunk_size):
			if pDialog.iscanceled():
				response.close()
				LOG_THIS(l1l11l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨⲶ"),l1l11l_l1_ (u"ࠩ࠱ࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠪⲷ"))
				break
			ii += l1l11111l11_l1_
			PROGRESS_UPDATE(pDialog,0+int(100*ii/l1ll11111l_l1_),l1l11l_l1_ (u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠡษ็ะืวࠠาไ่ࠫⲸ"),str(int(ii*chunk_size//MegaByte))+l1l11l_l1_ (u"ࠫࠥ࠵ࠠࠨⲹ")+l1ll1l1l11_l1_+l1l11l_l1_ (u"ࠬࠦࡍࡃࠩⲺ"))
			l111l1ll1ll_l1_ += chunk
			#PROGRESS_UPDATE(pDialog,0+int(35*ii/l1ll11111l_l1_),l1l11l_l1_ (u"࠭ฬๅสࠣห้๋ไโࠢส่ึฬ๊ิ์࠽࠱ࠥอไอิฤࠤึ่ๅࠨⲻ")+l1l11l_l1_ (u"ࠧ࡝ࡰࠪⲼ")+str(ii*chunksize/MegaByte)+l1l11l_l1_ (u"ࠨࠢ࠲ࠤࠬⲽ")+l1ll1l1l11_l1_+l1l11l_l1_ (u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧⲾ")+time.strftime(l1l11l_l1_ (u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧⲿ")+l1l11l_l1_ (u"ࠫࡡࡴࠧⳀ")+time.gmtime(l1l1lll1ll_l1_))+l1l11l_l1_ (u"ࠬࠦเࠨⳁ"))
			#t2 = time.time()
			#l1l1ll1l1l_l1_ = t2-t1
			#l1l1lll111_l1_ = l1l1ll1l1l_l1_/ii
			#l1ll11l1l1_l1_ = l1l1lll111_l1_*(l1ll11111l_l1_+1)
			#l1l1lll1ll_l1_ = l1ll11l1l1_l1_-l1l1ll1l1l_l1_
		response.close()
	pDialog.close()
	if len(l111l1ll1ll_l1_)<filesize:
		LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ⳃ"),l1l11l_l1_ (u"ࠧ࠯ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡦࡢ࡫࡯ࡩࡩࠦ࡯ࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡦࡺ࠺ࠡ࡝ࠣࠫⳃ")+str(len(l111l1ll1ll_l1_)//MegaByte)+l1l11l_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉࡶࡴࡳࠠࡵࡱࡷࡥࡱࠦ࡯ࡧ࠼ࠣ࡟ࠥ࠭Ⳅ")+l1ll1l1l11_l1_+l1l11l_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠨⳅ"))
		choice = l1111lll1ll_l1_(l1l11l_l1_ (u"ࠪࠫⳆ"),l1l11l_l1_ (u"ࠫสฺ๊ศรࠣ์ำื่อࠩⳇ"),l1l11l_l1_ (u"ࠬอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠬⳈ"),l1l11l_l1_ (u"࠭ลฺษาอࠥาไษࠢส่๊๊แࠨⳉ"),l1l11l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪⳊ"),l1l11l_l1_ (u"ࠨใื่ࠥ็๊ࠡฮ็ฬࠥอไๆๆไࠤࡡࡴࠠๅๆฦืๆࠦอะอࠣา฼ษࠠโ์ࠣฮา๋๊ๅࠢส่๊๊แࠡ࡞ࡱࠤฯ๋ࠠอๆหࠤࠬⳋ")+str(len(l111l1ll1ll_l1_)//MegaByte)+l1l11l_l1_ (u"้ࠩࠣ๏เวษษํฮ๋ࠥๆࠡ็ฯ้ํ฿ࠠࠨⳌ")+l1ll1l1l11_l1_+l1l11l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯࠦ࡜࡯ࠢฯีอࠦฬๅสࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠤࡡࡴ่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠡมࠤࠥࠬⳍ"))
		if choice==2: l111l1ll1ll_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11111lllll_l1_,headers)
		elif choice==1: LOG_THIS(l1l11l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⳎ"),l1l11l_l1_ (u"ࠬ࠴ࠠࠡࠢࡑࡳࡹࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡢࡥࡦࡩࡵࡺࡥࡥࠢࡤࡲࡩࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡶࡵࡨࡨࠬⳏ"))
		else: return
		if not l111l1ll1ll_l1_: return
	else: LOG_THIS(l1l11l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ⳑ"),l1l11l_l1_ (u"ࠧ࠯ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬⳑ")+l1ll1l1l11_l1_+l1l11l_l1_ (u"ࠨࠢࡐࡆࠥࡣࠧⳒ"))
	return l111l1ll1ll_l1_
def SEND_ANALYTICS_EVENT(script_name,allow_dns_fix=True,allow_proxy_fix=True):
	l1111lll1l1_l1_ = str(random.randrange(111111111111,999999999999))
	url = l1l11l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠴ࠪࡹ࡯ࡤ࠾ࡗࡄ࠱࠶࠸࠷࠱࠶࠸࠵࠵࠺࠭࠶ࠨࡦ࡭ࡩࡃࠧⳓ")+l1l11ll111l_l1_(32)+l1l11l_l1_ (u"ࠪࠪࡹࡃࡥࡷࡧࡱࡸࠫࡹࡣ࠾ࡧࡱࡨࠫ࡫ࡣ࠾ࠩⳔ")+addon_version+l1l11l_l1_ (u"ࠫࠫࡧࡶ࠾ࠩⳕ")+addon_version+l1l11l_l1_ (u"ࠬࠬࡡ࡯࠿ࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࡡࡑࡉ࡜ࡉࡌࡊࡇࡑࡘࡎࡊࠦࡦࡣࡀࠫⳖ")+script_name+l1l11l_l1_ (u"࠭ࠦࡦ࡮ࡀࠫⳗ")+str(kodi_version)+l1l11l_l1_ (u"ࠧࠧࡼࡀࠫⳘ")+l1111lll1l1_l1_
	response = OPENURL_REQUESTS(l1l11l_l1_ (u"ࠨࡉࡈࡘࠬⳙ"),url,l1l11l_l1_ (u"ࠩࠪⳚ"),l1l11l_l1_ (u"ࠪࠫⳛ"),l1l11l_l1_ (u"ࠫࠬⳜ"),False,l1l11l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪⳝ"))
	return response
def CHECK_CACHED_FILES(showDialogs,file=l1l11l_l1_ (u"࠭ࠧⳞ")):
	l1l1ll11ll1_l1_ = [l11l1ll1lll_l1_,l11llll1l1l_l1_,favouritesfile,l1111ll1111_l1_]
	l1l111l1ll1_l1_ = [l1l11l_l1_ (u"ࠧระิࠤฬ๊แ๋ัํ์์อสࠨⳟ"),l1l11l_l1_ (u"ࠨฤัี่ࠥวว็ฬࠫⳠ"),l1l11l_l1_ (u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩⳡ"),l1l11l_l1_ (u"ࠪห้ืำศศ็ࠫⳢ")]
	if file:
		try:
			index = l1l1ll11ll1_l1_.index(file)
			l1l1ll11ll1_l1_ = [l1l1ll11ll1_l1_[index]]
			l1l111l1ll1_l1_ = [l1l111l1ll1_l1_[index]]
		except: return
	files = l1l11l_l1_ (u"ࠫࠬⳣ")
	for ii in range(len(l1l1ll11ll1_l1_)):
		files += l1l111l1ll1_l1_[ii]+l1l11l_l1_ (u"ࠬࡢ࡮ࠨⳤ")
		file = l1l1ll11ll1_l1_[ii]
		if not os.path.exists(file): continue
		data = open(file,l1l11l_l1_ (u"࠭ࡲࡣࠩ⳥")).read()
		if kodi_version>18.99: data = data.decode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⳦"))
		data = EVAL(l1l11l_l1_ (u"ࠨࠩ⳧"),data)
		if data==None:
			yes = DIALOG_YESNO(l1l11l_l1_ (u"ࠩࠪ⳨"),l1l11l_l1_ (u"ࠪࠫ⳩"),l1l11l_l1_ (u"ࠫࠬ⳪"),l1l11l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨⳫ"),l1l11l_l1_ (u"࠭โศ็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสไัฺࠦๅๅใสฮ์่ࠦหสํ๊ࠥ๎ฬ้ัู้้ࠣไสࠢไ๎๋ࠥไโ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ⳬ")+l1l111l1ll1_l1_[ii]+l1l11l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ์้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ๊ࠦอสุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษะ็ๆ๋ࠥไโࠢฯำ๏ีࠠโษิ฾ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊๊แࠡษ็ฦ๋ࠦฟࠨⳭ"))
			if yes==1:
				try: os.remove(file)
				except: pass
	if showDialogs:
		files = files.strip(l1l11l_l1_ (u"ࠨ࡞ࡱࠫⳮ"))
		DIALOG_OK(l1l11l_l1_ (u"ࠩࠪ⳯"),l1l11l_l1_ (u"ࠪࠫ⳰"),l1l11l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⳱"),l1l11l_l1_ (u"ࠬะๅࠡใะูࠥํะ่ࠢส่๊๊แศฬ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧⳲ")+files+l1l11l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨⳳ"))
	return
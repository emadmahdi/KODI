# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
import bs4
script_name = l1l11l_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧẞ")
menu_name = l1l11l_l1_ (u"࠭࡟ࡆࡎࡆࡣࠬẟ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l111l111l1_l1_(url)
	elif mode==512: results = l11l111l1l_l1_(url)
	elif mode==513: results = l11l111l11_l1_(url)
	elif mode==514: results = l111l111ll_l1_(url,l1l11l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Ạ")+text)
	elif mode==515: results = l111l111ll_l1_(url,l1l11l_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧạ")+text)
	elif mode==516: results = l111ll1l11_l1_(text)
	elif mode==517: results = l111llll1l_l1_(url)
	elif mode==518: results = l111lllll1_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l111ll1lll_l1_(url)
	elif mode==521: results = l111l1111l_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l111l11lll_l1_(text)
	elif mode==524: results = l111l1l11l_l1_()
	elif mode==525: results = l11l1111ll_l1_()
	elif mode==526: results = l111ll1ll1_l1_()
	elif mode==527: results = l111l1l1l1_l1_()
	else: results = False
	return results
def MENU(website=l1l11l_l1_ (u"ࠩࠪẢ")):
	if not website:
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪả"),menu_name+l1l11l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫẤ"),l1l11l_l1_ (u"ࠬ࠭ấ"),519)
		addMenuItem(l1l11l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫẦ"),l1l11l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠱࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩầ"),l1l11l_l1_ (u"ࠨࠩẨ"),9999)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩẩ"),menu_name+l1l11l_l1_ (u"้ࠪํฺู่หࠣห้ษูๆษ็ࠫẪ"),l1l11l_l1_ (u"ࠫࠬẫ"),525)
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẬ"),menu_name+l1l11l_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅลืาฬ฻ࠧậ"),l1l11l_l1_ (u"ࠧࠨẮ"),526)
		addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨắ"),menu_name+l1l11l_l1_ (u"่ࠩ์ุ๎ูสࠢส่๊฻ๆโษอࠫẰ"),l1l11l_l1_ (u"ࠪࠫằ"),527)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẲ"),menu_name+l1l11l_l1_ (u"๋่ࠬิ๊฼อࠥอไๆ่๋฽ฬะࠧẳ"),l1l11l_l1_ (u"࠭ࠧẴ"),524)
	return
def l111l1l11l_l1_():
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẵ"),menu_name+l1l11l_l1_ (u"ࠨࠢไ๎ิ๐่่ษอࠤ࠲ࠦฮศืฬࠫẶ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࠩặ"),520)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẸ"),menu_name+l1l11l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡละำะ࠭ẹ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡲࡡࡵࡧࡶࡸࠬẺ"),521)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẻ"),menu_name+l1l11l_l1_ (u"ࠧโ์า๎ํํวหࠢ࠰ࠤศ่ฯๆࠩẼ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࡱ࡯ࡨࡪࡹࡴࠨẽ"),521)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩẾ"),menu_name+l1l11l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠳ࠠฤๅฮี๋ࠥิศ้าอࠬế"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࡻ࡯ࡥࡸࡵࠪỀ"),521)
	return
def l11l1111ll_l1_():
	l1l11l_l1_ (u"ࠧࠨࠢࠎࠌࠌࡸࡾࡶࡥࠡ࠿ࠣ࠵ࠥࠩࠠࡢࡥࡷࡳࡷࡹࠍࠋࠋࡷࡽࡵ࡫ࠠ࠾ࠢ࠵ࠤࠨࠦࡶࡪࡦࡨࡳࡸࠓࠊࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠷ࠠࠤࠢࡰࡳࡻ࡯ࡥࡴࠏࠍࠍࡨࡧࡴࡦࡩࡲࡶࡾࠦ࠽ࠡ࠵ࠣࠧࠥࡹࡥࡳ࡫ࡨࡷࠒࠐࠉࡧࡱࡵࡩ࡮࡭࡮ࠡ࠿ࠣࡪࡦࡲࡳࡦࠢࠦࠤࡦࡸࡡࡣ࡫ࡦࠑࠏࠏࡦࡰࡴࡨ࡭࡬ࡴࠠ࠾ࠢࡷࡶࡺ࡫ࠠࠤࠢࡨࡲ࡬ࡲࡩࡴࡪࠐࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ้๊࠭ࠪัไ๋่ࠣวๆ๊วๆࠢ฼ีอ๐ࠧ࠭࡮࡬ࡲࡰ࠸ࠬ࠶࠳࠴࠭ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊๋ࠥำๅี็หฯูࠦาสํࠫ࠱ࡲࡩ࡯࡭࠶࠰࠺࠷࠱ࠪࠏࠍࠍࠨࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥ่้ࠬࠩะ๊๊็ࠢฦๅ้อๅࠡษฯ๊อ๐ࠧ࠭࡮࡬ࡲࡰ࠺ࠬ࠶࠳࠴࠭ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊๋ࠥำๅี็หฯࠦวอ่ห๎ࠬ࠲࡬ࡪࡰ࡮࠹࠱࠻࠱࠲ࠫࠐࠎࠎࡲࡩ࡯࡭࠴ࠤࡂࠦ࡬ࡪࡰ࡮࠴࠰࠭ࠦࡵࡻࡳࡩࡂ࠷ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠩࡪࡴࡸࡥࡪࡩࡱࡁࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠶ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠷ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠸ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩࠐࠎࠎࡲࡩ࡯࡭࠸ࠤࡂࠦ࡬ࡪࡰ࡮࠴࠰࠭ࠦࡵࡻࡳࡩࡂ࠷ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠶ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࡺࡲࡶࡧࠩࡸࡦ࡭࠽ࠨࠏࠍࠍࠧࠨࠢề")
	l111l11l11_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠨỂ")
	l111ll1111_l1_ = l111l11l11_l1_+l1l11l_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠵ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪể")
	l11l1111l1_l1_ = l111l11l11_l1_+l1l11l_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫỄ")
	l111l1l1ll_l1_ = l111l11l11_l1_+l1l11l_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫễ")
	l111l1ll11_l1_ = l111l11l11_l1_+l1l11l_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬỆ")
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫệ"),menu_name+l1l11l_l1_ (u"๋ࠬี็ใสฮࠥษแๅษ่ࠤ฾ืศ๋ࠩỈ"),l111ll1111_l1_,511)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ỉ"),menu_name+l1l11l_l1_ (u"ࠧๆื้ๅฬะࠠๆี็ื้อสࠡ฻ิฬ๏࠭Ị"),l11l1111l1_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨị"),menu_name+l1l11l_l1_ (u"ู่๋ࠩ็วหࠢฦๅ้อๅࠡษฯ๊อ๐ࠧỌ"),l111l1l1ll_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪọ"),menu_name+l1l11l_l1_ (u"๊ࠫ฻ๆโษอࠤู๊ไิๆสฮࠥอฬ็สํࠫỎ"),l111l1ll11_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪỏ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨỐ"),l1l11l_l1_ (u"ࠧࠨố"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨỒ"),menu_name+l1l11l_l1_ (u"ࠩไ๋ึูࠠฤ฻่ห้ࠦรษฮา๎ࠬồ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡣ࡯ࡴ࡭ࡧࡢࡦࡶࠪỔ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫổ"),menu_name+l1l11l_l1_ (u"ࠬ็็าีࠣࠤอ๊ฯࠡษ็ษ๋ะวอࠩỖ"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡨࡵࡵ࡯ࡶࡵࡽࠬỗ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỘ"),menu_name+l1l11l_l1_ (u"ࠨใ๊ีุࠦวๅๆ฽อࠬộ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩỚ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪớ"),menu_name+l1l11l_l1_ (u"ࠫๆํัิู่๋ࠢ็วหࠢส่฾๋ไࠨỜ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲࡫ࡪࡴࡲࡦࠩờ"),517)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ở"),menu_name+l1l11l_l1_ (u"ࠧโ้ิืูࠥๆสࠢส่ส฻ฯศำࠪở"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡲࡦ࡮ࡨࡥࡸ࡫࡟ࡺࡧࡤࡶࠬỠ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧỡ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠸ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠵࡟࠴ࡉࡏࡍࡑࡕࡡࠬỢ"),l1l11l_l1_ (u"ࠫࠬợ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỤ"),menu_name+l1l11l_l1_ (u"࠭ๅ้ษึ้ࠥ࠳ࠠโๆอี๋ࠥอะัࠪụ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫỦ"),515)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨủ"),menu_name+l1l11l_l1_ (u"่ࠩ์ฬูๅࠡ࠯ࠣๅ้ะัࠡๅส้้࠭Ứ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧứ"),514)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩỪ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠴ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠸ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧừ"),l1l11l_l1_ (u"࠭ࠧỬ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧử"),menu_name+l1l11l_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭Ữ"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪữ"),515)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪỰ"),menu_name+l1l11l_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩự"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭Ỳ"),514)
	return
def l111l1l1l1_l1_():
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪỳ"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨỴ"),l1l11l_l1_ (u"ࠨࠩỵ"),l1l11l_l1_ (u"ࠩࠪỶ"),l1l11l_l1_ (u"ࠪࠫỷ"),l1l11l_l1_ (u"ࠫࠬỸ"),l1l11l_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩỹ"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫỺ"),multi_valued_attributes=None)
	block = l111l11111_l1_.find(l1l11l_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺࠧỻ"),attrs={l1l11l_l1_ (u"ࠨࡰࡤࡱࡪ࠭Ỽ"):l1l11l_l1_ (u"ࠩࡷࡥ࡬࠭ỽ")})	# <select name=l1l11l_l1_ (u"ࠪࡸࡦ࡭ࠧỾ")>
	options = block.find_all(l1l11l_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࠫỿ"))
	for option in options:
		value = option.get(l1l11l_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫἀ"))		# or option[l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬἁ")] l1l11111ll_l1_ it will fail if not l1ll1llll_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬἂ"))
			value = value.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ἃ"))
		l1111l_l1_ = l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠪࡹࡿࡰࡦ࠿ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭ἄ")+value
		title = title.replace(l1l11l_l1_ (u"ࠪๆฬฬๅสࠢࠪἅ"),l1l11l_l1_ (u"ࠫࠬἆ"))
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἇ"),menu_name+title,l1111l_l1_,511)
	return
def l111ll1ll1_l1_():
	l111l11l11_l1_ = l11lll_l1_+l1l11l_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠨἈ")
	l111l1llll_l1_ = l111l11l11_l1_+l1l11l_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫἉ")
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨἊ"),menu_name+l1l11l_l1_ (u"ู่๋ࠩ็วหࠢฦุำอีࠨἋ"),l111l1llll_l1_,511)
	addMenuItem(l1l11l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨἌ"),l1l11l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ἅ"),l1l11l_l1_ (u"ࠬ࠭Ἆ"),9999)
	addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ἇ"),menu_name+l1l11l_l1_ (u"ࠧโ้ิืࠥษิฯษุࠤศฮฬะ์ࠪἐ"),l11lll_l1_+l1l11l_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡣ࡯ࡴ࡭ࡧࡢࡦࡶࠪἑ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩἒ"),menu_name+l1l11l_l1_ (u"ࠪๅ์ืำࠡ็๋฻๋࠭ἓ"),l11lll_l1_+l1l11l_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡳࡧࡴࡪࡱࡱࡥࡱ࡯ࡴࡺࠩἔ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἕ"),menu_name+l1l11l_l1_ (u"࠭แ่ำึࠤࠥะวา์ัࠤฬ๊ๅ๋ๆสำࠬ἖"),l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯ࡣ࡫ࡵࡸ࡭ࡥࡹࡦࡣࡵࠫ἗"),517)
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨἘ"),menu_name+l1l11l_l1_ (u"ࠩไ๋ึูࠠࠡฬสี๏ิࠠศๆ๋ๅฬฯࠧἙ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡨࡪࡧࡴࡩࡡࡼࡩࡦࡸࠧἚ"),517)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩἛ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧἜ"),l1l11l_l1_ (u"࠭ࠧἝ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ἞"),menu_name+l1l11l_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡ็ะำิ࠭἟"),l11lll_l1_+l1l11l_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪἠ"),515)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪἡ"),menu_name+l1l11l_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ่อๅๅࠩἢ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭ἣ"),514)
	return
def l111l111l1_l1_(url):
	if l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪἤ") in url: index = 0
	elif l1l11l_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨἥ") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬἦ"),url,l1l11l_l1_ (u"ࠩࠪἧ"),l1l11l_l1_ (u"ࠪࠫἨ"),l1l11l_l1_ (u"ࠫࠬἩ"),l1l11l_l1_ (u"ࠬ࠭Ἢ"),l1l11l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫἫ"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬἬ"),multi_valued_attributes=None)
	l1l1l1_l1_ = l111l11111_l1_.find_all(class_=l1l11l_l1_ (u"ࠨ࡬ࡸࡱࡧࡵ࠭ࡵࡪࡨࡥࡹ࡫ࡲࠡࡥ࡯ࡩࡦࡸࡦࡪࡺࠪἭ"))
	for block in l1l1l1_l1_:
		title = block.find_all(l1l11l_l1_ (u"ࠩࡤࠫἮ"))[index].text
		l1111l_l1_ = l11lll_l1_+block.find_all(l1l11l_l1_ (u"ࠪࡥࠬἯ"))[index].get(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧࠩἰ"))
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪἱ"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫἲ"))
		if not l1l1l1_l1_:
			l11l111l1l_l1_(l1111l_l1_)
			return
		else:
			title = title.replace(l1l11l_l1_ (u"ࠧใษษ้ฮࠦࠧἳ"),l1l11l_l1_ (u"ࠨࠩἴ"))
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩἵ"),menu_name+title,l1111l_l1_,512)
	l111l11ll1_l1_(l111l11111_l1_,511)
	return
def l111l11ll1_l1_(l111l11111_l1_,mode):
	block = l111l11111_l1_.find(class_=l1l11l_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧἶ"))
	if block:
		pages = block.find_all(l1l11l_l1_ (u"ࠫࡦ࠭ἷ"))
		l1111lllll_l1_ = block.find_all(l1l11l_l1_ (u"ࠬࡲࡩࠨἸ"))
		l111ll1l1l_l1_ = list(zip(pages,l1111lllll_l1_))
		ii = -1
		length = len(l111ll1l1l_l1_)
		for l1llllll1_l1_,l111l11l1l_l1_ in l111ll1l1l_l1_:
			ii += 1
			l111l11l1l_l1_ = l111l11l1l_l1_[l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬἹ")]
			if l1l11l_l1_ (u"ࠧࡶࡰࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠬἺ") in l111l11l1l_l1_ or l1l11l_l1_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࠩἻ") in l111l11l1l_l1_: continue
			name2 = l1llllll1_l1_.text
			l11l111l1_l1_ = l11lll_l1_+l1llllll1_l1_.get(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧἼ"))
			if kodi_version<19:
				name2 = name2.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨἽ"))
				l11l111l1_l1_ = l11l111l1_l1_.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩἾ"))
			if   ii==0: name2 = l1l11l_l1_ (u"ࠬษ่ๅ๋ࠪἿ")
			elif ii==1: name2 = l1l11l_l1_ (u"࠭ำศสๅอࠬὀ")
			elif ii==length-2: name2 = l1l11l_l1_ (u"ࠧๅษะๆฮ࠭ὁ")
			elif ii==length-1: name2 = l1l11l_l1_ (u"ࠨลั๎ึฯࠧὂ")
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩὃ"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡࠩὄ")+name2,l11l111l1_l1_,mode)
	return
def l11l111l1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨὅ"),url,l1l11l_l1_ (u"ࠬ࠭὆"),l1l11l_l1_ (u"࠭ࠧ὇"),l1l11l_l1_ (u"ࠧࠨὈ"),l1l11l_l1_ (u"ࠨࠩὉ"),l1l11l_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠵࠲࠷ࡳࡵࠩὊ"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨὋ"),multi_valued_attributes=None)
	l1l1l1_l1_ = l111l11111_l1_.find_all(class_=l1l11l_l1_ (u"ࠫࡷࡵࡷࠨὌ"))
	items,first = [],True
	for block in l1l1l1_l1_:
		if not block.find(class_=l1l11l_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠮ࡹࡵࡥࡵࡶࡥࡳࠩὍ")): continue
		if first: first = False ; continue
		l111llll11_l1_ = []
		l1111llll1_l1_ = block.find_all(class_=[l1l11l_l1_ (u"࠭ࡣࡦࡰࡶࡳࡷࡹࡨࡪࡲࠣࡶࡪࡪࠧ὎"),l1l11l_l1_ (u"ࠧࡤࡧࡱࡷࡴࡸࡳࡩ࡫ࡳࠤࡵࡻࡲࡱ࡮ࡨࠫ὏")])
		for l111l1l111_l1_ in l1111llll1_l1_:
			l111111ll_l1_ = l111l1l111_l1_.find_all(l1l11l_l1_ (u"ࠨ࡮࡬ࠫὐ"))[1].text
			if kodi_version<19:
				l111111ll_l1_ = l111111ll_l1_.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧὑ"))
			l111llll11_l1_.append(l111111ll_l1_)
		if not l1l11_l1_(script_name,l1l11l_l1_ (u"ࠪࠫὒ"),l111llll11_l1_,False):
			image = block.find(l1l11l_l1_ (u"ࠫ࡮ࡳࡧࠨὓ")).get(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧὔ"))
			title = block.find(l1l11l_l1_ (u"࠭ࡨ࠴ࠩὕ"))
			name = title.find(l1l11l_l1_ (u"ࠧࡢࠩὖ")).text
			l1111l_l1_ = l11lll_l1_+title.find(l1l11l_l1_ (u"ࠨࡣࠪὗ")).get(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ὘"))
			l111l1ll1l_l1_ = block.find(class_=l1l11l_l1_ (u"ࠪࡲࡴ࠳࡭ࡢࡴࡪ࡭ࡳ࠭Ὑ"))
			l111l1lll1_l1_ = block.find(class_=l1l11l_l1_ (u"ࠫࡱ࡫ࡧࡦࡰࡧࠫ὚"))
			if l111l1ll1l_l1_: l111l1ll1l_l1_ = l111l1ll1l_l1_.text
			if l111l1lll1_l1_: l111l1lll1_l1_ = l111l1lll1_l1_.text
			if kodi_version<19:
				image = image.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪὛ"))
				name = name.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ὜"))
				l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬὝ"))
				if l111l1ll1l_l1_: l111l1ll1l_l1_ = l111l1ll1l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭὞"))
			infodict = {}
			if l111l1lll1_l1_: infodict[l1l11l_l1_ (u"ࠩࡶࡸࡦࡸࡳࠨὟ")] = l111l1lll1_l1_
			if l111l1ll1l_l1_:
				l111l1ll1l_l1_ = l111l1ll1l_l1_.replace(l1l11l_l1_ (u"ࠪࡠࡳ࠭ὠ"),l1l11l_l1_ (u"ࠫࠥ࠴࠮ࠡࠩὡ"))
				infodict[l1l11l_l1_ (u"ࠬࡶ࡬ࡰࡶࠪὢ")] = l111l1ll1l_l1_.replace(l1l11l_l1_ (u"࠭࠮࠯࠰สๆึษࠠศๆ่ึ๏ีࠧὣ"),l1l11l_l1_ (u"ࠧࠨὤ"))
			if l1l11l_l1_ (u"ࠨ࠱ࡺࡳࡷࡱ࠯ࠨὥ") in l1111l_l1_:
				#name = l1l11l_l1_ (u"ࠩหัะูࠦ็ࠢࠪὦ")+name
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪὧ"),menu_name+name,l1111l_l1_,516,image,l1l11l_l1_ (u"ࠫࠬὨ"),name,l1l11l_l1_ (u"ࠬ࠭Ὡ"),infodict)
			elif l1l11l_l1_ (u"࠭࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨὪ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧὫ"),menu_name+name,l1111l_l1_,513,image,l1l11l_l1_ (u"ࠨࠩὬ"),name,l1l11l_l1_ (u"ࠩࠪὭ"),infodict)
	l111l11ll1_l1_(l111l11111_l1_,512)
	return
def l11l111l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧὮ"),url,l1l11l_l1_ (u"ࠫࠬὯ"),l1l11l_l1_ (u"ࠬ࠭ὰ"),l1l11l_l1_ (u"࠭ࠧά"),l1l11l_l1_ (u"ࠧࠨὲ"),l1l11l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠵࠱࠶ࡹࡴࠨέ"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧὴ"),multi_valued_attributes=None)
	l1l1l1_l1_ = l111l11111_l1_.find_all(l1l11l_l1_ (u"ࠪࡰ࡮࠭ή"))
	names,items = [],[]
	for block in l1l1l1_l1_:
		if not block.find(class_=l1l11l_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠭ࡸࡴࡤࡴࡵ࡫ࡲࠨὶ")): continue
		if not block.find(class_=[l1l11l_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠧί"),l1l11l_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠡࡶࡨࡼࡹ࠳ࡣࡦࡰࡷࡩࡷ࠭ὸ")]): continue
		if block.find(class_=l1l11l_l1_ (u"ࠧࡩ࡫ࡧࡩࠬό")): continue
		title = block.find(class_=[l1l11l_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠪὺ"),l1l11l_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠤࡹ࡫ࡸࡵ࠯ࡦࡩࡳࡺࡥࡳࠩύ")])
		name = title.find(l1l11l_l1_ (u"ࠪࡥࠬὼ")).text
		if name in names: continue
		names.append(name)
		l1111l_l1_ = l11lll_l1_+title.find(l1l11l_l1_ (u"ࠫࡦ࠭ώ")).get(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ὾"))
		if l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡸࡱࡵ࡯࠴࠭὿") in url: image = block.find(l1l11l_l1_ (u"ࠧࡪ࡯ࡪࠫᾀ")).get(l1l11l_l1_ (u"ࠨࡵࡵࡧࠬᾁ"))
		elif l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫᾂ") in url: image = block.find(l1l11l_l1_ (u"ࠪ࡭ࡲ࡭ࠧᾃ")).get(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭ᾄ"))
		elif l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭ᾅ") in url: image = block.find(l1l11l_l1_ (u"࠭ࡩ࡮ࡩࠪᾆ")).get(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩᾇ"))
		else: image = block.find(l1l11l_l1_ (u"ࠨ࡫ࡰ࡫ࠬᾈ")).get(l1l11l_l1_ (u"ࠩࡶࡶࡨ࠭ᾉ"))
		if kodi_version<19:
			name = name.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᾊ"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᾋ"))
			image = image.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᾌ"))
		name = name.strip(l1l11l_l1_ (u"࠭ࠠࠨᾍ"))
		items.append((name,l1111l_l1_,image))
	if l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩᾎ") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1111l_l1_,image in items:
		if l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩᾏ") in url: addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᾐ"),menu_name+name,l1111l_l1_,522,image)
		elif l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬᾑ") in url: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᾒ"),menu_name+name,l1111l_l1_,513,image,l1l11l_l1_ (u"ࠬ࠭ᾓ"),name)
		else: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾔ"),menu_name+name,l1111l_l1_,516,image,l1l11l_l1_ (u"ࠧࠨᾕ"),name)
	return
def l111ll1l11_l1_(text):
	text = text.replace(l1l11l_l1_ (u"ࠨษ็ษ฾๊ว็ࠩᾖ"),l1l11l_l1_ (u"ࠩࠪᾗ")).replace(l1l11l_l1_ (u"่ࠪๆ๐ไๆࠩᾘ"),l1l11l_l1_ (u"ࠫࠬᾙ")).replace(l1l11l_l1_ (u"ࠬอไาี่๎ࠬᾚ"),l1l11l_l1_ (u"࠭ࠧᾛ"))
	text = text.replace(l1l11l_l1_ (u"ࠧฦ฻็ห๋࠭ᾜ"),l1l11l_l1_ (u"ࠨࠩᾝ")).replace(l1l11l_l1_ (u"ࠩไ๎้๋ࠧᾞ"),l1l11l_l1_ (u"ࠪࠫᾟ")).replace(l1l11l_l1_ (u"ࠫฬ๊ศา๊่์ࠬᾠ"),l1l11l_l1_ (u"ࠬ࠭ᾡ"))
	text = text.replace(l1l11l_l1_ (u"࠭วๅฬื์๏่๊ࠨᾢ"),l1l11l_l1_ (u"ࠧࠨᾣ")).replace(l1l11l_l1_ (u"ࠨๆ่ืู้ไࠨᾤ"),l1l11l_l1_ (u"ࠩࠪᾥ")).replace(l1l11l_l1_ (u"ุ้๊ࠪำๅࠩᾦ"),l1l11l_l1_ (u"ࠫࠬᾧ"))
	text = text.replace(l1l11l_l1_ (u"ࠬࡀࠧᾨ"),l1l11l_l1_ (u"࠭ࠧᾩ")).replace(l1l11l_l1_ (u"ࠧࠪࠩᾪ"),l1l11l_l1_ (u"ࠨࠩᾫ")).replace(l1l11l_l1_ (u"ࠩࠫࠫᾬ"),l1l11l_l1_ (u"ࠪࠫᾭ")).replace(l1l11l_l1_ (u"ࠫ࠱࠭ᾮ"),l1l11l_l1_ (u"ࠬ࠭ᾯ"))
	text = text.replace(l1l11l_l1_ (u"࠭࡟ࠨᾰ"),l1l11l_l1_ (u"ࠧࠨᾱ")).replace(l1l11l_l1_ (u"ࠨ࠽ࠪᾲ"),l1l11l_l1_ (u"ࠩࠪᾳ")).replace(l1l11l_l1_ (u"ࠪ࠱ࠬᾴ"),l1l11l_l1_ (u"ࠫࠬ᾵")).replace(l1l11l_l1_ (u"ࠬ࠴ࠧᾶ"),l1l11l_l1_ (u"࠭ࠧᾷ"))
	text = text.replace(l1l11l_l1_ (u"ࠧ࡝ࠩࠪᾸ"),l1l11l_l1_ (u"ࠨࠩᾹ")).replace(l1l11l_l1_ (u"ࠩ࡟ࠦࠬᾺ"),l1l11l_l1_ (u"ࠪࠫΆ"))
	text = text.replace(l1l11l_l1_ (u"ࠫࠥࠦࠠࠡࠩᾼ"),l1l11l_l1_ (u"ࠬࠦࠧ᾽")).replace(l1l11l_l1_ (u"࠭ࠠࠡࠢࠪι"),l1l11l_l1_ (u"ࠧࠡࠩ᾿")).replace(l1l11l_l1_ (u"ࠨࠢࠣࠫ῀"),l1l11l_l1_ (u"ࠩࠣࠫ῁"))
	text = text.strip(l1l11l_l1_ (u"ࠪࠤࠬῂ"))
	l111llllll_l1_ = text.count(l1l11l_l1_ (u"ࠫࠥ࠭ῃ"))+1
	if l111llllll_l1_==1:
		l111l11lll_l1_(text)
		return
	addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪῄ"),menu_name+l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࠦใๅ็สฮ๊ࠥไษฯฮࠤࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ῅"),l1l11l_l1_ (u"ࠧࠨῆ"),9999)
	l111ll11l1_l1_ = text.split(l1l11l_l1_ (u"ࠨࠢࠪῇ"))
	l11l11111l_l1_ = pow(2,l111llllll_l1_)
	l111lll11l_l1_ = []
	def l111ll111l_l1_(a,b):
		if a==l1l11l_l1_ (u"ࠩ࠴ࠫῈ"): return b
		return l1l11l_l1_ (u"ࠪࠫΈ")
	for ii in range(l11l11111l_l1_,0,-1):
		l111lll111_l1_ = list(l111llllll_l1_*l1l11l_l1_ (u"ࠫ࠵࠭Ὴ")+bin(ii)[2:])[-l111llllll_l1_:]
		l111lll111_l1_ = reversed(l111lll111_l1_)
		result = map(l111ll111l_l1_,l111lll111_l1_,l111ll11l1_l1_)
		title = l1l11l_l1_ (u"ࠬࠦࠧΉ").join(filter(None,result))
		if kodi_version<19: title2 = title.decode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫῌ"))
		else: title2 = title
		if len(title2)>2 and title not in l111lll11l_l1_:
			l111lll11l_l1_.append(title)
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ῍"),menu_name+title,l1l11l_l1_ (u"ࠨࠩ῎"),523,l1l11l_l1_ (u"ࠩࠪ῏"),l1l11l_l1_ (u"ࠪࠫῐ"),title)
	return
def l111l11lll_l1_(l11l111111_l1_):
	import l111lll1ll_l1_
	l11l111111_l1_ = OPEN_KEYBOARD(default=l11l111111_l1_)
	l111lll1ll_l1_.SEARCH(l11l111111_l1_)
	return
def l111llll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨῑ"),url,l1l11l_l1_ (u"ࠬ࠭ῒ"),l1l11l_l1_ (u"࠭ࠧΐ"),l1l11l_l1_ (u"ࠧࠨ῔"),l1l11l_l1_ (u"ࠨࠩ῕"),l1l11l_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡎࡔࡄࡆ࡚ࡈࡗࡤࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨῖ"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨῗ"),multi_valued_attributes=None)
	block = l111l11111_l1_.find(class_=l1l11l_l1_ (u"ࠫࡱ࡯ࡳࡵ࠯ࡶࡩࡵࡧࡲࡢࡶࡲࡶࠥࡲࡩࡴࡶ࠰ࡸ࡮ࡺ࡬ࡦࠩῘ"))
	titles = block.find_all(l1l11l_l1_ (u"ࠬࡧࠧῙ"))
	items = []
	for title in titles:
		name = title.text
		l1111l_l1_ = l11lll_l1_+title.get(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࠫῚ"))
		if kodi_version<19:
			name = name.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬΊ"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠨࡷࡷࡪ࠽࠭῜"))
		if l1l11l_l1_ (u"ࠩࠦࠫ῝") not in l1111l_l1_: items.append((name,l1111l_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1111l_l1_ = item
		addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ῞"),menu_name+name,l1111l_l1_,518)
	return
def l111lllll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ῟"),url,l1l11l_l1_ (u"ࠬ࠭ῠ"),l1l11l_l1_ (u"࠭ࠧῡ"),l1l11l_l1_ (u"ࠧࠨῢ"),l1l11l_l1_ (u"ࠨࠩΰ"),l1l11l_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡎࡔࡄࡆ࡚ࡈࡗࡤ࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩῤ"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨῥ"),multi_valued_attributes=None)
	l1l1l1_l1_ = l111l11111_l1_.find(class_=l1l11l_l1_ (u"ࠫࡪࡾࡰࡢࡰࡧࠫῦ")).find_all(l1l11l_l1_ (u"ࠬࡺࡲࠨῧ"))
	for block in l1l1l1_l1_:
		l111ll11ll_l1_ = block.find_all(l1l11l_l1_ (u"࠭ࡡࠨῨ"))
		if not l111ll11ll_l1_: continue
		image = block.find(l1l11l_l1_ (u"ࠧࡪ࡯ࡪࠫῩ")).get(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪῪ"))
		name = l111ll11ll_l1_[1].text
		l1111l_l1_ = l11lll_l1_+l111ll11ll_l1_[1].get(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧΎ"))
		l111l1lll1_l1_ = block.find(class_=l1l11l_l1_ (u"ࠪࡰࡪ࡭ࡥ࡯ࡦࠪῬ"))
		if l111l1lll1_l1_: l111l1lll1_l1_ = l111l1lll1_l1_.text
		if kodi_version<19:
			name = name.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ῭"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ΅"))
			image = image.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ`"))
		infodict = {}
		if l111l1lll1_l1_: infodict[l1l11l_l1_ (u"ࠧࡴࡶࡤࡶࡸ࠭῰")] = l111l1lll1_l1_
		if l1l11l_l1_ (u"ࠨ࠱ࡺࡳࡷࡱ࠯ࠨ῱") in l1111l_l1_:
			#name = l1l11l_l1_ (u"ࠩหัะูࠦ็ࠢࠪῲ")+name
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῳ"),menu_name+name,l1111l_l1_,516,image,l1l11l_l1_ (u"ࠫࠬῴ"),name,l1l11l_l1_ (u"ࠬ࠭῵"),infodict)
		elif l1l11l_l1_ (u"࠭࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨῶ") in l1111l_l1_: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧῷ"),menu_name+name,l1111l_l1_,513,image,l1l11l_l1_ (u"ࠨࠩῸ"),name,l1l11l_l1_ (u"ࠩࠪΌ"),infodict)
	l111l11ll1_l1_(l111l11111_l1_,518)
	return
def l111ll1lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧῺ"),url,l1l11l_l1_ (u"ࠫࠬΏ"),l1l11l_l1_ (u"ࠬ࠭ῼ"),l1l11l_l1_ (u"࠭ࠧ´"),l1l11l_l1_ (u"ࠧࠨ῾"),l1l11l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰࡚ࡎࡊࡅࡐࡕࡢࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭῿"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ "),multi_valued_attributes=None)
	titles = l111l11111_l1_.find_all(class_=l1l11l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱ࠱ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࡲࡩ࡯ࡧࠪ "))
	l1ll1111_l1_ = l111l11111_l1_.find_all(class_=l1l11l_l1_ (u"ࠫࡧࡻࡴࡵࡱࡱࠤ࡬ࡸࡥࡦࡰࠣࡷࡲࡧ࡬࡭ࠢࡵ࡭࡬࡮ࡴࠨ "))
	items = zip(titles,l1ll1111_l1_)
	for title,l1111l_l1_ in items:
		title = title.text
		l1111l_l1_ = l11lll_l1_+l1111l_l1_.get(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ "))
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ "))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ "))
		title = title.replace(l1l11l_l1_ (u"ࠨࠢࠣࠤࠥ࠭ "),l1l11l_l1_ (u"ࠩࠣࠫ ")).replace(l1l11l_l1_ (u"ࠪࠤࠥࠦࠧ "),l1l11l_l1_ (u"ࠫࠥ࠭ ")).replace(l1l11l_l1_ (u"ࠬࠦࠠࠨ "),l1l11l_l1_ (u"࠭ࠠࠨ​"))
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ‌"),menu_name+title,l1111l_l1_,521)
	return
def l111l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ‍"),url,l1l11l_l1_ (u"ࠩࠪ‎"),l1l11l_l1_ (u"ࠪࠫ‏"),l1l11l_l1_ (u"ࠫࠬ‐"),l1l11l_l1_ (u"ࠬ࠭‑"),l1l11l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡘࡌࡈࡊࡕࡓࡠࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ‒"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ–"),multi_valued_attributes=None)
	l11l111ll1_l1_ = l111l11111_l1_.find(class_=l1l11l_l1_ (u"ࠨ࡮ࡤࡶ࡬࡫࠭ࡣ࡮ࡲࡧࡰ࠳ࡧࡳ࡫ࡧ࠱࠹ࠦ࡭ࡦࡦ࡬ࡹࡲ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠸ࠥࡹ࡭ࡢ࡮࡯࠱ࡧࡲ࡯ࡤ࡭࠰࡫ࡷ࡯ࡤ࠮࠴ࠪ—"))
	l1l1l1_l1_ = l11l111ll1_l1_.find_all(l1l11l_l1_ (u"ࠩ࡯࡭ࠬ―"))
	for block in l1l1l1_l1_:
		title = block.find(class_=l1l11l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ‖")).text
		l1111l_l1_ = l11lll_l1_+block.find(l1l11l_l1_ (u"ࠫࡦ࠭‗")).get(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ‘"))
		image = block.find(l1l11l_l1_ (u"࠭ࡩ࡮ࡩࠪ’")).get(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ‚"))
		duration = block.find(class_=l1l11l_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ‛")).text
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ“"))
			l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ”"))
			image = image.encode(l1l11l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ„"))
			duration = duration.encode(l1l11l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ‟"))
		duration = duration.replace(l1l11l_l1_ (u"࠭࡜࡯ࠩ†"),l1l11l_l1_ (u"ࠧࠨ‡")).strip(l1l11l_l1_ (u"ࠨࠢࠪ•"))
		addMenuItem(l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ‣"),menu_name+title,l1111l_l1_,522,image,duration)
	l111l11ll1_l1_(l111l11111_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ․"),url,l1l11l_l1_ (u"ࠫࠬ‥"),l1l11l_l1_ (u"ࠬ࠭…"),l1l11l_l1_ (u"࠭ࠧ‧"),l1l11l_l1_ (u"ࠧࠨ "),l1l11l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ "))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ‪"),multi_valued_attributes=None)
	l1111l_l1_ = l111l11111_l1_.find(class_=l1l11l_l1_ (u"ࠪࡪࡱ࡫ࡸ࠮ࡸ࡬ࡨࡪࡵࠧ‫")).find(l1l11l_l1_ (u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠫ‬")).get(l1l11l_l1_ (u"ࠬࡹࡲࡤࠩ‭"))
	if kodi_version<19: l1111l_l1_ = l1111l_l1_.encode(l1l11l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ‮"))
	PLAY_VIDEO(l1111l_l1_,script_name,l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ "))
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠨࠩ‰"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠩࠪ‱"): return
	search = search.replace(l1l11l_l1_ (u"ࠪࠤࠬ′"),l1l11l_l1_ (u"ࠫࠪ࠸࠰ࠨ″"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵࠿ࡲ࠿ࠪ‴")+search
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ‵"),url,l1l11l_l1_ (u"ࠧࠨ‶"),l1l11l_l1_ (u"ࠨࠩ‷"),l1l11l_l1_ (u"ࠩࠪ‸"),l1l11l_l1_ (u"ࠪࠫ‹"),l1l11l_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ›"))
	html = response.content
	l111l11111_l1_ = bs4.BeautifulSoup(html,l1l11l_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ※"),multi_valued_attributes=None)
	l1l1l1_l1_ = l111l11111_l1_.find_all(class_=l1l11l_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡵ࡫ࡷࡰࡪࠦ࡬ࡦࡨࡷࠫ‼"))
	for block in l1l1l1_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l1l11l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ‽"))
		title = title.split(l1l11l_l1_ (u"ࠨࠪࠪ‾"),1)[0].strip(l1l11l_l1_ (u"ࠩࠣࠫ‿"))
		if   l1l11l_l1_ (u"ࠪว฾๋วๅࠩ⁀") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⁁"),l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡷࡰࡴ࡮࠳ࠬ⁂"))
		elif l1l11l_l1_ (u"࠭รีะสูࠬ⁃") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⁄"),l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⁅"))
		#elif l1l11l_l1_ (u"ࠩฦัิอหࠨ⁆") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⁇"),l1l11l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࡫ࡶࡦࡰࡷ࠳ࠬ⁈"))
		#elif l1l11l_l1_ (u"๋ࠬ็าฮส๊ฬะࠧ⁉") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⁊"),l1l11l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡨࡨࡷࡹ࡯ࡶࡢ࡮࠲ࠫ⁋"))
		elif l1l11l_l1_ (u"ࠨใํำ๏๎็ศฬࠪ⁌") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⁍"),l1l11l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡻ࡯ࡤࡦࡱ࠲ࠫ⁎"))
		#elif l1l11l_l1_ (u"ࠫศิศศำࠪ⁏") in title: l1111l_l1_ = url.replace(l1l11l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⁐"),l1l11l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡵࡱࡳ࡭ࡨ࠵ࠧ⁑"))
		else: continue
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⁒"),menu_name+title,l1111l_l1_,513)
	return
# ===========================================
#     l11l1l1ll_l1_ l111lll11_l1_ l111ll1l1_l1_
# ===========================================
def l111l111ll_l1_(url,text):
	global l1111l1_l1_,l11ll1l_l1_
	if l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ⁓") in url:
		l1111l1_l1_ = [l1l11l_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࡣ࡯ࠫ⁔"),l1l11l_l1_ (u"ࠪࡽࡪࡧࡲࠨ⁕"),l1l11l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⁖")]
		l11ll1l_l1_ = [l1l11l_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ⁗"),l1l11l_l1_ (u"࠭ࡹࡦࡣࡵࠫ⁘"),l1l11l_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⁙")]
	elif l1l11l_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ⁚") in url:
		l1111l1_l1_ = [l1l11l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⁛"),l1l11l_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ⁜"),l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࠩ⁝")]
		l11ll1l_l1_ = [l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⁞"),l1l11l_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ "),l1l11l_l1_ (u"ࠧࡵࡻࡳࡩࠬ⁠")]
	l1l1l1l_l1_(url,text)
	return
def l11l1l1l1_l1_(url):
	url = url.split(l1l11l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⁡"))[0]
	#l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠩࡸࡶࡱ࠭⁢"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧ⁣"),url,l1l11l_l1_ (u"ࠫࠬ⁤"),l1l11l_l1_ (u"ࠬ࠭⁥"),l1l11l_l1_ (u"࠭ࠧ⁦"),l1l11l_l1_ (u"ࠧࠨ⁧"),l1l11l_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ⁨"))
	html = response.content
	# all l1l1l1_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡩࡳࡷࡳࠠࡢࡥࡷ࡭ࡴࡴ࠽ࠣ࠱ࠫ࠲࠯ࡅࠩ࠽࠱ࡩࡳࡷࡳ࠾ࠨ⁩"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	# name + category + options block
	l1l1ll1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡀࡸ࡫࡬ࡦࡥࡷࠤࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⁪"),block,re.DOTALL)
	return l1l1ll1_l1_
def l111lllll_l1_(block):
	# value + name
	items = re.findall(l1l11l_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⁫"),block,re.DOTALL)
	return items
def l11l11lll_l1_(url):
	#url = url.replace(l1l11l_l1_ (u"ࠬࡩࡡࡵ࠿ࠪ⁬"),l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ⁭"))
	l11l1111l_l1_ = url.split(l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⁮"))[0]
	l11l11111_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬ⁯"))
	#url = url.replace(l11l1111l_l1_,l11l11111_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⁰"),l1l11l_l1_ (u"ࠪ࠳ࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸ࠬࠧⁱ"))
	return url
def l1l1111l11_l1_(l11l11l_l1_,url):
	l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⁲")) # l11ll1ll11_l1_ be l11lll111l_l1_
	url3 = url+l1l11l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⁳")+l1llll11_l1_
	url3 = l11l11lll_l1_(url3)
	return url3
def l1l1l1l_l1_(url,filter):
	#filter = filter.replace(l1l11l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⁴"),l1l11l_l1_ (u"ࠧࠨ⁵"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ⁶"),l1l11l_l1_ (u"ࠩࠪ⁷"),filter,url)
	if l1l11l_l1_ (u"ࠪࡃࠬ⁸") in url: url = url.split(l1l11l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⁹"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ⁺"),1)
	if filter==l1l11l_l1_ (u"࠭ࠧ⁻"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"ࠧࠨ⁼"),l1l11l_l1_ (u"ࠨࠩ⁽")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭⁾"))
	if type==l1l11l_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ⁿ"):
		if l1111l1_l1_[0]+l1l11l_l1_ (u"ࠫࡂ࠭₀") not in l111111_l1_: category = l1111l1_l1_[0]
		for i in range(len(l1111l1_l1_[0:-1])):
			if l1111l1_l1_[i]+l1l11l_l1_ (u"ࠬࡃࠧ₁") in l111111_l1_: category = l1111l1_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠨ₂")+category+l1l11l_l1_ (u"ࠧ࠾࠲ࠪ₃")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠪ₄")+category+l1l11l_l1_ (u"ࠩࡀ࠴ࠬ₅")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠬ₆"))+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ₇")+l11l11l_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠧ₈"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ₉")) # l11ll1l111_l1_ l1l111l1l1_l1_ not l1ll11ll11_l1_
		url2 = url+l1l11l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ₊")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ₋"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ₌")) # l11ll1l111_l1_ l1l111l1l1_l1_ not l1ll11ll11_l1_
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠪࠫ₍"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ₎")) # l11ll1l111_l1_ l1l111l1l1_l1_ not l1ll11ll11_l1_
		if l1llllll_l1_==l1l11l_l1_ (u"ࠬ࠭₏"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪₐ")+l1llllll_l1_
		url2 = l11l11lll_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧₑ"),menu_name+l1l11l_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫₒ"),url2,511)
		addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩₓ"),menu_name+l1l11l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪₔ")+l1ll1ll1_l1_+l1l11l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪₕ"),url2,511)
		addMenuItem(l1l11l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪₖ"),l1l11l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ₗ"),l1l11l_l1_ (u"ࠧࠨₘ"),9999)
	l1l1ll1_l1_ = l11l1l1l1_l1_(url)
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		name = name.replace(l1l11l_l1_ (u"ࠨ࠯࠰ࠫₙ"),l1l11l_l1_ (u"ࠩࠪₚ"))
		items = l111lllll_l1_(block)
		if l1l11l_l1_ (u"ࠪࡁࠬₛ") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧₜ"):
			if l1l111l_l1_ not in l1111l1_l1_: continue
			if category!=l1l111l_l1_: continue
			elif len(items)<2:
				if l1l111l_l1_==l1111l1_l1_[-1]:
					url = l11l11lll_l1_(url)
					l11l111l1l_l1_(url)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ₝")+l111l11_l1_)
				return
			else:
				url2 = l11l11lll_l1_(url2)
				if l1l111l_l1_==l1111l1_l1_[-1]: addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭₞"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠧ₟"),url2,511)
				else: addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ₠"),menu_name+l1l11l_l1_ (u"ࠩส่ัฺ๋๊ࠩ₡"),url2,515,l1l11l_l1_ (u"ࠪࠫ₢"),l1l11l_l1_ (u"ࠫࠬ₣"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ₤"):
			if l1l111l_l1_ not in l11ll1l_l1_: continue
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠨ₥")+l1l111l_l1_+l1l11l_l1_ (u"ࠧ࠾࠲ࠪ₦")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠪ₧")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀ࠴ࠬ₨")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ₩")+l11l11l_l1_
			if   name==l1l11l_l1_ (u"ࠫࡹࡿࡰࡦࠩ₪"): name = l1l11l_l1_ (u"ࠬอไ็๊฼ࠫ₫")
			elif name==l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ€"): name = l1l11l_l1_ (u"ࠧศๆ฼้้࠭₭")
			elif name==l1l11l_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ₮"): name = l1l11l_l1_ (u"ࠩส่้เษࠨ₯")
			elif name==l1l11l_l1_ (u"ࠪࡽࡪࡧࡲࠨ₰"): name = l1l11l_l1_ (u"ࠫฬ๊ำ็หࠪ₱")
			elif name==l1l11l_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ₲"): name = l1l11l_l1_ (u"࠭วๅ็๋ื๊࠭₳")
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ₴"),menu_name+l1l11l_l1_ (u"ࠨษ็ะ๊๐ู࠻ࠢࠪ₵")+name,url2,514,l1l11l_l1_ (u"ࠩࠪ₶"),l1l11l_l1_ (u"ࠪࠫ₷"),l111l11_l1_)		# +l1l11l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭₸"))
		dict[l1l111l_l1_] = {}
		for value,option in items:
			if option in l1llll1_l1_: continue
			if l1l11l_l1_ (u"๋ࠬี็ใสฮࠥษฮา๋ࠪ₹") in option: continue
			if l1l11l_l1_ (u"࠭วๅๅ็ࠫ₺") in option: continue
			if l1l11l_l1_ (u"ࠧศๆ็฾ฮ࠭₻") in option: continue
			option = option.replace(l1l11l_l1_ (u"ࠨไสส๊ฯࠠࠨ₼"),l1l11l_l1_ (u"ࠩࠪ₽"))
			if   name==l1l11l_l1_ (u"ࠪࡸࡾࡶࡥࠨ₾"): name = l1l11l_l1_ (u"ࠫฬ๊ๆ้฻ࠪ₿")
			elif name==l1l11l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⃀"): name = l1l11l_l1_ (u"࠭วๅ฻่่ࠬ⃁")
			elif name==l1l11l_l1_ (u"ࠧࡧࡱࡵࡩ࡮࡭࡮ࠨ⃂"): name = l1l11l_l1_ (u"ࠨษ็่฿ฯࠧ⃃")
			elif name==l1l11l_l1_ (u"ࠩࡼࡩࡦࡸࠧ⃄"): name = l1l11l_l1_ (u"ࠪหู้ๆสࠩ⃅")
			elif name==l1l11l_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⃆"): name = l1l11l_l1_ (u"ࠬอไๆ๊ึ้ࠬ⃇")
			#if l1l11l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ⃈") not in value: value = option
			#else: value = re.findall(l1l11l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⃉"),value,re.DOTALL)[0]
			dict[l1l111l_l1_][value] = option
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠪ⃊")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࠫ⃋")+option
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠬ⃌")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂ࠭⃍")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ⃎")+l11l11l_l1_
			if name: title = option+l1l11l_l1_ (u"࠭ࠠ࠻ࠩ⃏")+name
			else: title = option   #+dict[l1l111l_l1_][l1l11l_l1_ (u"ࠧ࠱ࠩ⃐")]
			if type==l1l11l_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ⃑"): addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ⃒ࠩ"),menu_name+title,url,514,l1l11l_l1_ (u"⃓ࠪࠫ"),l1l11l_l1_ (u"ࠫࠬ⃔"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ⃕"))
			elif type==l1l11l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⃖") and l1111l1_l1_[-2]+l1l11l_l1_ (u"ࠧ࠾ࠩ⃗") in l111111_l1_:
				url3 = l1l1111l11_l1_(l11l11l_l1_,url)
				addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃘"),menu_name+title,url3,511)
			else: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ⃙ࠩ"),menu_name+title,url,515,l1l11l_l1_ (u"⃚ࠪࠫ"),l1l11l_l1_ (u"ࠫࠬ⃛"),l1l1111_l1_)
	return
def l1llll1l_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭⃜"),l1l11l_l1_ (u"࠭ࠧ⃝"),filters,l1l11l_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠷࠱ࠨ⃞"))
	# mode==l1l11l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⃟")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⃠")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⃡")			all l111lll_l1_ & l11l1l11l_l1_ filters
	filters = filters.replace(l1l11l_l1_ (u"ࠫࡂࠬࠧ⃢"),l1l11l_l1_ (u"ࠬࡃ࠰ࠧࠩ⃣"))
	filters = filters.strip(l1l11l_l1_ (u"࠭ࠦࠨ⃤"))
	l11111l_l1_ = {}
	if l1l11l_l1_ (u"ࠧ࠾⃥ࠩ") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠨࠨ⃦ࠪ"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠩࡀࠫ⃧"))
			l11111l_l1_[var] = value
	l11llll_l1_ = l1l11l_l1_ (u"⃨ࠪࠫ")
	for key in l11ll1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠫ࠵࠭⃩")
		if l1l11l_l1_ (u"⃪ࠬࠫࠧ") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ⃫") and value!=l1l11l_l1_ (u"ࠧ࠱⃬ࠩ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠨࠢ࠮ࠤ⃭ࠬ")+value
		elif mode==l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷ⃮ࠬ") and value!=l1l11l_l1_ (u"ࠪ࠴⃯ࠬ"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠫࠫ࠭⃰")+key+l1l11l_l1_ (u"ࠬࡃࠧ⃱")+value
		elif mode==l1l11l_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⃲"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠧࠧࠩ⃳")+key+l1l11l_l1_ (u"ࠨ࠿ࠪ⃴")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠩࠣ࠯ࠥ࠭⃵"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠬ⃶"))
	l11llll_l1_ = l11llll_l1_.replace(l1l11l_l1_ (u"ࠫࡂ࠶ࠧ⃷"),l1l11l_l1_ (u"ࠬࡃࠧ⃸"))
	#DIALOG_OK(l1l11l_l1_ (u"࠭ࠧ⃹"),l1l11l_l1_ (u"ࠧࠨ⃺"),filters,l1l11l_l1_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠲࠳ࠩ⃻"))
	return l11llll_l1_
l1111l1_l1_ = []
l11ll1l_l1_ = []
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ๒")
headers = {l1l11l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ๓"):l1l11l_l1_ (u"ࠧࠨ๔")}
menu_name = l1l11l_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧ๕")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ๖"),l1l11l_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪ๗"),l1l11l_l1_ (u"๊ࠫ฻วา฻๊ࠫ๘"),l1l11l_l1_ (u"ࠬอูๅ่้ࠣ฾์วࠡ⠕ࠣࡊࡴࡸࠠࡢࡦࡶࠫ๙"),l1l11l_l1_ (u"࠭ๅ้สส๎้อสࠨ๚"),l1l11l_l1_ (u"ࠧษำส้ัࠦใๆสํ์ฯืࠧ๛"),l1l11l_l1_ (u"ࠨษ็฽ฬฮࠠไ็ห๎ํะัࠨ๜"),l1l11l_l1_ (u"ࠩสื้อๅ๋ษอࠫ๝"),l1l11l_l1_ (u"ࠪหำื้ࠨ๞"),l1l11l_l1_ (u"ࠫฬ่ำศ็ࠣหำื๊ࠨ๟"),l1l11l_l1_ (u"ࠬอิหำส็ฬะࠧ๠")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l111l1_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l111ll_l1_(url)
	elif mode==254: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭๡")+text)
	elif mode==255: results = l1l1l1l_l1_(url,l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ๢")+text)
	elif mode==256: results = l1l1lll11_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
headers = {l1l11l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ๣"):l1ll11ll1_l1_()}
def MENU():
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ๤"),menu_name+l1l11l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ๥"),l1l11l_l1_ (u"ࠫࠬ๦"),259,l1l11l_l1_ (u"ࠬ࠭๧"),l1l11l_l1_ (u"࠭ࠧ๨"),l1l11l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ๩"))
	addMenuItem(l1l11l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ๪"),menu_name+l1l11l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ๫"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵วฯำ์ࠫ๬"),254)
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ๭"),menu_name+l1l11l_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ๮"),l11lll_l1_+l1l11l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱สาึ๏ࠧ๯"),255)
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ๰"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ๱"),l1l11l_l1_ (u"ࠩࠪ๲"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๳"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ๴"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡭ࡢ࡫ࡱࠫ๵"),251,l1l11l_l1_ (u"࠭ࠧ๶"),l1l11l_l1_ (u"ࠧࠨ๷"),l1l11l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡦ࡯࡮ࠨ๸"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ๹"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧ๺")+menu_name+l1l11l_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪ๻"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡭ࡢ࡫ࡱࠫ๼"),251,l1l11l_l1_ (u"࠭ࠧ๽"),l1l11l_l1_ (u"ࠧࠨ๾"),l1l11l_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ๿"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ຀"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧກ")+menu_name+l1l11l_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪຂ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡭ࡢ࡫ࡱࠫ຃"),251,l1l11l_l1_ (u"࠭ࠧຄ"),l1l11l_l1_ (u"ࠧࠨ຅"),l1l11l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧຆ"))
	addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩງ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧຈ")+menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษ๎ࠫຉ"),l11lll_l1_+l1l11l_l1_ (u"ࠬ࠵࡬ࡢࡵࡷࡩࡸࡺࠧຊ"),251,l1l11l_l1_ (u"࠭ࠧ຋"),l1l11l_l1_ (u"ࠧࠨຌ"),l1l11l_l1_ (u"ࠨ࡮ࡤࡷࡹ࡫ࡳࡵࠩຍ"))
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ຎ"),l11lll_l1_+l1l11l_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩຏ"),l1l11l_l1_ (u"ࠫࠬຐ"),headers,l1l11l_l1_ (u"ࠬ࠭ຑ"),l1l11l_l1_ (u"࠭ࠧຒ"),l1l11l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫຓ"))
	html = response.content
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡏࡨࡲࡺࡎࡥࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪດ"),html,re.DOTALL)
	l1l11lll_l1_ = l1ll1lll1_l1_[0]
	l1l1l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫຕ"),l1l11lll_l1_,re.DOTALL)
	for l1111l_l1_,title in l1l1l1111_l1_:
		title = unescapeHTML(title)
		if title not in l1llll1_l1_ and title!=l1l11l_l1_ (u"ࠪࠫຖ"):
			if l1l11l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩທ") not in l1111l_l1_: l1111l_l1_ = l11lll_l1_+l1111l_l1_
			#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠬ࠵ࠧຘ")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪນ")),l11lll_l1_)
			addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧບ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬປ")+menu_name+title,l1111l_l1_,256)
	return html
def l1l1lll11_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪຜ"),l1l11l_l1_ (u"ࠪࠫຝ"),l1l11l_l1_ (u"ࠫࡘ࡛ࡂࡎࡇࡑ࡙ࠥࠦࠠࠡࠢࠪພ")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩຟ"),url,l1l11l_l1_ (u"࠭ࠧຠ"),headers,l1l11l_l1_ (u"ࠧࠨມ"),l1l11l_l1_ (u"ࠨࠩຢ"),l1l11l_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩຣ"))
	html = response.content
	if l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴࡌࡲࡘ࡫ࡣࡵ࡫ࡲࡲࠬ຤") in html: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫລ"),menu_name+l1l11l_l1_ (u"ࠬอไฤๅฮี๋ࠥิศ้าอࠬ຦"),url,251,l1l11l_l1_ (u"࠭ࠧວ"),l1l11l_l1_ (u"ࠧࠨຨ"),l1l11l_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭ຩ"))
	if l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡸ࠭ສ") in html: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪຫ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬຬ"),url,251,l1l11l_l1_ (u"ࠬ࠭ອ"),l1l11l_l1_ (u"࠭ࠧຮ"),l1l11l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩຯ"))
	if l1l11l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠫະ") in html:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡳࡱࡳࡍ࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨັ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			if len(l1ll111_l1_)>1 and type==l1l11l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩາ"): block = l1ll111_l1_[1]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬຳ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title2 = re.findall(l1l11l_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ິ"),title,re.DOTALL)
				try: tt1 = title2[0][0]
				except: tt1 = l1l11l_l1_ (u"࠭ࠧີ")
				try: tt2 = title2[0][1]
				except: tt2 = l1l11l_l1_ (u"ࠧࠨຶ")
				title2 = tt1+tt2
				title2 = title2.replace(l1l11l_l1_ (u"ࠨ࡞ࡱࠫື"),l1l11l_l1_ (u"ຸࠩࠪ"))
				#LOG_THIS(l1l11l_l1_ (u"ູࠪࠫ"),str(title2))
				if l1l11l_l1_ (u"ࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ຺࠭") in title:
					title2 = re.findall(l1l11l_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩົ"),title,re.DOTALL)
					title2 = title2[0]
				if not title2:
					title2 = re.findall(l1l11l_l1_ (u"࠭ࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫຼ"),title,re.DOTALL)
					title2 = title2[0]
				else:
					if l1l11l_l1_ (u"ࠧ࡬ࡧࡼࡁࠬຽ") in l1111l_l1_: type = l1111l_l1_.split(l1l11l_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭຾"))[1]
					else: type = l1l11l_l1_ (u"ࠩࡱࡩࡼ࡫ࡳࡵࠩ຿")
					#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠪ࠳ࠬເ")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨແ")),l11lll_l1_)
					addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬໂ"),menu_name+title2,l1111l_l1_,251,l1l11l_l1_ (u"࠭ࠧໃ"),l1l11l_l1_ (u"ࠧࠨໄ"),type)
	return
def l111l1_l1_(url,type):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ໅"),l1l11l_l1_ (u"ࠩࠪໆ"),l1l11l_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠣࠤࠥࠦࠠࠨ໇")+type,url)
	method,data,items = l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ່"),l1l11l_l1_ (u"້ࠬ࠭"),[]
	if type==l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹ໊ࠧ"):
		if l1l11l_l1_ (u"ࠧࡀ໋ࠩ") in url:
			method2,data2 = l1l11l_l1_ (u"ࠨࡒࡒࡗ࡙࠭໌"),{}
			url2,l1l1lll1l_l1_ = url.split(l1l11l_l1_ (u"ࠩࡂࠫໍ"))
			lines = l1l1lll1l_l1_.split(l1l11l_l1_ (u"ࠪࠪࠬ໎"))
			for line in lines:
				key,value = line.split(l1l11l_l1_ (u"ࠫࡂ࠭໏"))
				data2[key] = value
			if lines: method,url,data = method2,url2,data2
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l1l11l_l1_ (u"ࠬ࠭໐"),l1l11l_l1_ (u"࠭ࠧ໑"),l1l11l_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭໒"))
	html = response.content
	if type==l1l11l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ໓"): l1ll111_l1_ = [html]
	elif l1l11l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ໔") in type: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠧ໕"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ໖"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬาฯ๋ัࠣห้อแๅษ่࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷࡏ࡮ࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ໗"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ໘"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ໙"),html,re.DOTALL)
	elif type==l1l11l_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭໚"): l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠫ໛"),html,re.DOTALL)
	else: l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡆࡱࡵࡣ࡬ࡵ࠰࡙ࡑࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡆࡨ࡯ࡆ࡮ࡖࡩࡪࡪࠢࠨໜ"),html,re.DOTALL)
	if l1l11l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ໝ") in type:
		block = l1ll111_l1_[0]
		zz = re.findall(l1l11l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠨࡴࡴࡦࢀࡩࡧࡴࡢ࠯࡬ࡱࡦ࡭ࡥࠪ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪໞ"),block,re.DOTALL)
		if zz:
			l1ll1lll_l1_,l1l1lll_l1_,l1ll11111_l1_,l1ll11lll_l1_ = zip(*zz)
			items = zip(l1ll1lll_l1_,l1ll11lll_l1_,l1l1lll_l1_)
	else:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨໟ"),block,re.DOTALL)
		#if not items: items = re.findall(l1l11l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡩ࡮ࡣࡪࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ໠"),block,re.DOTALL)
		#if not items: items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ໡"),block,re.DOTALL)
	l1l1l11_l1_ = []
	for l1111l_l1_,img,title in items:
		#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠩ࠲ࠫ໢")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ໣")),l11lll_l1_)
		#img = img.rstrip(l1l11l_l1_ (u"ࠫ࠴࠭໤")).replace(SERVER(img,l1l11l_l1_ (u"ࠬࡻࡲ࡭ࠩ໥")),l11lll_l1_)
		title = unescapeHTML(title)
		if l1l11l_l1_ (u"࠭วๅฯ็ๆฮ࠭໦") in title:
			l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ໧"),title,re.DOTALL)
			if l1ll1ll_l1_:
				title = l1l11l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ໨") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					l1l1l11_l1_.append(title)
					addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ໩"),menu_name+title,l1111l_l1_,253,img)
			else: addMenuItem(l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ໪"),menu_name+title,l1111l_l1_,252,img)
		elif l1l11l_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭໫") in l1111l_l1_ or l1l11l_l1_ (u"๋ࠬำๅี็ࠫ໬") in title:
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭໭"),menu_name+title,l1111l_l1_,253,img)
		else:
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭໮"),menu_name+title,l1111l_l1_,252,img)
	if type in [l1l11l_l1_ (u"ࠨࡰࡨࡻࡪࡹࡴࠨ໯"),l1l11l_l1_ (u"ࠩࡥࡩࡸࡺࠧ໰"),l1l11l_l1_ (u"ࠪࡱࡴࡹࡴࠨ໱")]:
		items = re.findall(l1l11l_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡱࡹࡲࡨࡥࡳࡵࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ໲"),html,re.DOTALL)
		for l1111l_l1_,title in items:
			l1111l_l1_ = l11lll_l1_+l1111l_l1_
			l1111l_l1_ = unescapeHTML(l1111l_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ໳"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬ໴")+title,l1111l_l1_,251,l1l11l_l1_ (u"ࠧࠨ໵"),l1l11l_l1_ (u"ࠨࠩ໶"),type)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭໷"),url,l1l11l_l1_ (u"ࠪࠫ໸"),headers,l1l11l_l1_ (u"ࠫࠬ໹"),l1l11l_l1_ (u"ࠬ࠭໺"),l1l11l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ໻"))
	html = response.content
	items = re.findall(l1l11l_l1_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁ࡚ࠧࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ໼"),html,re.DOTALL)
	if not items: return
	img,name = items[0]
	if l1l11l_l1_ (u"ࠨษ็ั้่ษࠨ໽") in name: name = name.split(l1l11l_l1_ (u"ࠩส่า๊โสࠩ໾"))[0].strip(l1l11l_l1_ (u"ࠪࠤࠬ໿"))
	elif l1l11l_l1_ (u"ࠫา๊โสࠩༀ") in name: name = name.split(l1l11l_l1_ (u"ࠬำไใหࠪ༁"))[0].strip(l1l11l_l1_ (u"࠭ࠠࠨ༂"))
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࡸࡺࡹ࡭ࡧࡀࠦࡨࡲࡥࡢࡴ࠽ࠤࡧࡵࡴࡩ࠽ࠥࠫ༃"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠭༄"),block,re.DOTALL)
		for l1111l_l1_,l1ll1ll_l1_ in reversed(items):
			title = name+l1l11l_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥืโๆࠢࠪ༅")+l1ll1ll_l1_
			#l1111l_l1_ = l1111l_l1_.rstrip(l1l11l_l1_ (u"ࠪ࠳ࠬ༆")).replace(SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨ༇")),l11lll_l1_)
			#img = img.rstrip(l1l11l_l1_ (u"ࠬ࠵ࠧ༈")).replace(SERVER(img,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ༉")),l11lll_l1_)
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭༊"),menu_name+title,l1111l_l1_,252,img)
	else: addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ་"),menu_name+l1l11l_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ༌"),url,252,img)
	return
def l1l1l11ll_l1_(title,l1111l_l1_):
	title2 = re.findall(l1l11l_l1_ (u"ࠪ࡟ࡦ࠳ࡺࡂ࠯࡝࠱ࡢ࠱ࠧ།"),title,re.DOTALL)
	if title2: title = title2[0]
	else: title = title+l1l11l_l1_ (u"ࠫࠥ࠭༎")+SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ༏"))
	title = title.replace(l1l11l_l1_ (u"ู࠭าสࠣื๏ีࠧ༐"),l1l11l_l1_ (u"ࠧࠨ༑")).replace(l1l11l_l1_ (u"ࠨ็หหูืࠧ༒"),l1l11l_l1_ (u"ࠩࠪ༓")).replace(l1l11l_l1_ (u"ู้ࠪอ็ะหࠪ༔"),l1l11l_l1_ (u"ࠫࠬ༕"))
	title = title.replace(l1l11l_l1_ (u"ࠬ๓ࠧ༖"),l1l11l_l1_ (u"࠭ࠧ༗"))
	title = title.replace(l1l11l_l1_ (u"༘ࠧࠡࠢࠪ"),l1l11l_l1_ (u"ࠨ༙ࠢࠪ")).replace(l1l11l_l1_ (u"ࠩࠣࠤࠬ༚"),l1l11l_l1_ (u"ࠪࠤࠬ༛"))
	return title
def PLAY(url):
	# https://l1ll1111l_l1_.l1l1ll1ll_l1_/فيلم-l1l1ll111_l1_-for-l1l1l11l1_l1_-l1l11lll1_l1_-2022-مترجم/
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ༜"),url,l1l11l_l1_ (u"ࠬ࠭༝"),headers,l1l11l_l1_ (u"࠭ࠧ༞"),l1l11l_l1_ (u"ࠧࠨ༟"),l1l11l_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ༠"))
	html = response.content
	l1ll1lll_l1_ = []
	# l1l11ll1l_l1_ l1l1ll11l_l1_ l1111l_l1_
	l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࡎ࡬ࡲࡢ࡯ࡨࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ༡"),html,re.DOTALL)
	if l1ll1111_l1_:
		l1111l_l1_,l1l1l1l1_l1_ = l1ll1111_l1_[0]
		name = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠪࡲࡦࡳࡥࠨ༢"))
		l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ༣")+name+l1l11l_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࡠࡡࠪ༤")+l1l1l1l1_l1_
		l1ll1lll_l1_.append(l1111l_l1_)
	# l1l1ll11l_l1_ & download l1ll1111_l1_
	l1ll1111_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡇࡻࡴࡵࡱࡱࡷࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ༥"),html,re.DOTALL)
	if l1ll1111_l1_:
		server = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫ༦"))
		#headers = {l1l11l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ༧"):server,l1l11l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭༨"):l1ll11ll1_l1_()}
		headers[l1l11l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ༩")] = server
		# l1l1ll11l_l1_ l1ll1111_l1_
		l1l1l111l_l1_ = l1ll1111_l1_[0][0]
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨ༪"),l1l1l111l_l1_,l1l11l_l1_ (u"ࠬ࠭༫"),headers,l1l11l_l1_ (u"࠭ࠧ༬"),l1l11l_l1_ (u"ࠧࠨ༭"),l1l11l_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ༮"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡦࡴࡄࡶࡪࡧࠢࠩ࠰࠭ࡃࡁ࠵ࡵ࡭ࡀࠬࠫ༯"),html,re.DOTALL)
		if l1ll111_l1_:
			l1l11ll11_l1_ = l1ll111_l1_[0]
			l1l11ll11_l1_ = l1l11ll11_l1_.replace(l1l11l_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩ༰"),l1l11l_l1_ (u"ࠫࡁ࡮࠳࠿ࠩ༱"))
			l1l11ll11_l1_ = l1l11ll11_l1_.replace(l1l11l_l1_ (u"ࠬࡂࡨ࠴ࡀࠪ༲"),l1l11l_l1_ (u"࠭࠼ࡩ࠵ࡁࡀ࡭࠹࠾ࠨ༳"))
			l1l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧ࠽ࡪ࠶ࡂ࠳࠰࠿ࠩ࡞ࡧ࠯࠮࠮࠮ࠫࡁࠬࡀ࡭࠹࠾ࠨ༴"),l1l11ll11_l1_,re.DOTALL)
			for l1l1l1l1_l1_,block in l1l1l1_l1_:
				items = re.findall(l1l11l_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ༵ࠬ"),block,re.DOTALL)
				for l1111l_l1_,name in items:
					name = SERVER(l1111l_l1_,l1l11l_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ༶"))
					l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀ༷ࠫ")+name+l1l11l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡟ࡠࠩ༸")+l1l1l1l1_l1_
					l1ll1lll_l1_.append(l1111l_l1_)
		# download l1ll1111_l1_
		l1l1lllll_l1_ = l1ll1111_l1_[0][1]
		response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠬࡍࡅࡕ༹ࠩ"),l1l1lllll_l1_,l1l11l_l1_ (u"࠭ࠧ༺"),headers,l1l11l_l1_ (u"ࠧࠨ༻"),l1l11l_l1_ (u"ࠨࠩ༼"),l1l11l_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭༽"))
		html = response.content
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ༾"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩ༿"),block,re.DOTALL)
			for l1111l_l1_,title,l1l1l1l1_l1_ in items:
				if not l1111l_l1_: continue
				# it l1ll111l1_l1_ a l1l1l1ll1_l1_ from l1l1llll1_l1_
				# l1ll1l111_l1_
				if l1l11l_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡸࡺࡡࡵ࡫ࡲࡲࠬཀ") in l1111l_l1_: continue
				l1111l_l1_ = UNQUOTE(l1111l_l1_)
				title = l1l1l11ll_l1_(title,l1111l_l1_)
				l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧཁ")+title+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨག")+l1l1l1l1_l1_
				l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭གྷ"), l1ll1lll_l1_)
	l1l1l1l1l_l1_ = str(l1ll1lll_l1_)
	l1lll1_l1_ = [l1l11l_l1_ (u"ࠩ࠱ࡾ࡮ࡶ࠿ࠨང"),l1l11l_l1_ (u"ࠪ࠲ࡷࡧࡲࡀࠩཅ"),l1l11l_l1_ (u"ࠫ࠳ࡺࡸࡵࡁࠪཆ"),l1l11l_l1_ (u"ࠬ࠴ࡰࡥࡨࡂࠫཇ"),l1l11l_l1_ (u"࠭࠮ࡵࡣࡵࡃࠬ཈"),l1l11l_l1_ (u"ࠧ࠯࡫ࡶࡳࡄ࠭ཉ"),l1l11l_l1_ (u"ࠨ࠰ࡽ࡭ࡵ࠴ࠧཊ"),l1l11l_l1_ (u"ࠩ࠱ࡶࡦࡸ࠮ࠨཋ"),l1l11l_l1_ (u"ࠪ࠲ࡹࡾࡴ࠯ࠩཌ"),l1l11l_l1_ (u"ࠫ࠳ࡶࡤࡧ࠰ࠪཌྷ"),l1l11l_l1_ (u"ࠬ࠴ࡴࡢࡴ࠱ࠫཎ"),l1l11l_l1_ (u"࠭࠮ࡪࡵࡲ࠲ࠬཏ")]
	if any(value in l1l1l1l1l_l1_ for value in l1lll1_l1_):
		DIALOG_OK(l1l11l_l1_ (u"ࠧࠨཐ"),l1l11l_l1_ (u"ࠨࠩད"),l1l11l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬདྷ"),l1l11l_l1_ (u"ࠪะึฮࠠาษห฻๋ࠥฮหๆไࠤ้ษๆ้ࠡำหࠥอไาษห฻๊๊ࠥิ่๊ࠢࠥ์ฺ่ࠢส่ึ๎วษูࠣห้ะ๊ࠡใํ๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠๅล้ࠤ์ึวࠡษ็้ํู่ࠡใํ๋ࠥิฯๆษอࠤศิั๊ࠢ฽๎ึࠦๅๅใสฮࠥอไโ์า๎ํ࠭ན"))
		return
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪཔ"),url)
	return
def SEARCH(search):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧཕ"),l1l11l_l1_ (u"࠭ࠫࠨབ"))
	url = l11lll_l1_+l1l11l_l1_ (u"ࠧ࠰ࡨ࡬ࡲࡩ࠵࠿ࡧ࡫ࡱࡨࡂ࠭བྷ")+search
	l111l1_l1_(url,l1l11l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨམ"))
	return
def l1l1l1l_l1_(url,filter):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪཙ"),l1l11l_l1_ (u"ࠪࠫཚ"),filter,url)
	#headers2 = {l1l11l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬཛ"):url,l1l11l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩཛྷ"):l1l11l_l1_ (u"࠭ࠧཝ")}
	#headers2 = l1l11l_l1_ (u"ࠧࠨཞ")
	#filter = filter.replace(l1l11l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪཟ"),l1l11l_l1_ (u"ࠩࠪའ"))
	if l1l11l_l1_ (u"ࠪࡃࡄ࠭ཡ") in url: url = url.split(l1l11l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪར"))[0]
	type,filter = filter.split(l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩལ"),1)
	if filter==l1l11l_l1_ (u"࠭ࠧཤ"): l111111_l1_,l1llllll_l1_ = l1l11l_l1_ (u"ࠧࠨཥ"),l1l11l_l1_ (u"ࠨࠩས")
	else: l111111_l1_,l1llllll_l1_ = filter.split(l1l11l_l1_ (u"ࠩࡢࡣࡤ࠭ཧ"))
	if type==l1l11l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧཨ"):
		if l1ll1l11l_l1_[0]+l1l11l_l1_ (u"ࠫࡂࡃࠧཀྵ") not in l111111_l1_: category = l1ll1l11l_l1_[0]
		for i in range(len(l1ll1l11l_l1_[0:-1])):
			if l1ll1l11l_l1_[i]+l1l11l_l1_ (u"ࠬࡃ࠽ࠨཪ") in l111111_l1_: category = l1ll1l11l_l1_[i+1]
		l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"࠭ࠦࠧࠩཫ")+category+l1l11l_l1_ (u"ࠧ࠾࠿࠳ࠫཬ")
		l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫ཭")+category+l1l11l_l1_ (u"ࠩࡀࡁ࠵࠭཮")
		l111l11_l1_ = l11ll11_l1_.strip(l1l11l_l1_ (u"ࠪࠪࠫ࠭཯"))+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨ཰")+l11l11l_l1_.strip(l1l11l_l1_ (u"ࠬࠬࠦࠨཱ"))
		l1llll11_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴིࠩ"))
		url2 = url+l1l11l_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄཱི࠭")+l1llll11_l1_
	elif type==l1l11l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔུࠩ"):
		l1ll1ll1_l1_ = l1llll1l_l1_(l111111_l1_,l1l11l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶཱུࠫ"))
		l1ll1ll1_l1_ = UNQUOTE(l1ll1ll1_l1_)
		if l1llllll_l1_!=l1l11l_l1_ (u"ࠪࠫྲྀ"): l1llllll_l1_ = l1llll1l_l1_(l1llllll_l1_,l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧཷ"))
		if l1llllll_l1_==l1l11l_l1_ (u"ࠬ࠭ླྀ"): url2 = url
		else: url2 = url+l1l11l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬཹ")+l1llllll_l1_
		l11ll111_l1_ = l1l1ll1l1_l1_(url2)
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸེࠧ"),menu_name+l1l11l_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษཻࠣࠫ"),l11ll111_l1_,251,l1l11l_l1_ (u"ོࠩࠪ"),l1l11l_l1_ (u"ཽࠪࠫ"),l1l11l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬཾ"))
		addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬཿ"),menu_name+l1l11l_l1_ (u"࠭ࠠ࡜࡝ࠣࠤྀࠥ࠭")+l1ll1ll1_l1_+l1l11l_l1_ (u"ࠧࠡࠢࠣࡡࡢཱྀ࠭"),l11ll111_l1_,251,l1l11l_l1_ (u"ࠨࠩྂ"),l1l11l_l1_ (u"ࠩࠪྃ"),l1l11l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶ྄ࠫ"))
		addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ྅"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ྆"),l1l11l_l1_ (u"࠭ࠧ྇"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll_l1_,l1l11l_l1_ (u"ࠧࡑࡑࡖࡘࠬྈ"),url,l1l11l_l1_ (u"ࠨࠩྉ"),headers,l1l11l_l1_ (u"ࠩࠪྊ"),l1l11l_l1_ (u"ࠪࠫྋ"),l1l11l_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩྌ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡚ࠧࡡࡹࡒࡤ࡫ࡪࡌࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡘࡪࡸ࡭ࡃࡖࡑࡷࠧ࠭ྍ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	l1ll11l11_l1_ = re.findall(l1l11l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡔࡢࡺࡓࡥ࡬࡫ࡆࡪ࡮ࡷࡩࡷࡏࡴࡦ࡯ࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨྎ"),block,re.DOTALL)
	l1ll111ll_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡓࡣࡷ࡭ࡳ࡭ࡆࡪ࡮ࡷࡩࡷࠨ࠮ࠫࡁ࠿࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀ࠱࠮ࡄ࠮࠼ࡶ࡮ࡁ࠭࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨྏ"),block,re.DOTALL)
	l1l1ll1_l1_ = l1ll11l11_l1_+l1ll111ll_l1_
	dict = {}
	for name,l1l111l_l1_,block in l1l1ll1_l1_:
		#if l1l11l_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪྐ") in l1l111l_l1_: continue
		items = re.findall(l1l11l_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪྑ"),block,re.DOTALL)
		if name==l1l11l_l1_ (u"ࠪหำื้ࠨྒ"): name = l1l11l_l1_ (u"ࠫฬ๊วใีส้ࠬྒྷ")
		if not items:
			l1l1l1111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡶࡦࡺࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬྔ"),block,re.DOTALL)
			items = []
			for option,value in l1l1l1111_l1_: items.append([option,l1l11l_l1_ (u"࠭ࠧྕ"),value])
			l1l111l_l1_ = l1l11l_l1_ (u"ࠧࡳࡣࡷࡩࠬྖ")
			name = l1l11l_l1_ (u"ࠨษ็ฮ็๐๊ๆࠩྗ")
		else: l1l111l_l1_ = items[0][1]
		if l1l11l_l1_ (u"ࠩࡀࡁࠬ྘") not in url2: url2 = url
		if type==l1l11l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧྙ"):
			if category!=l1l111l_l1_: continue
			elif len(items)<=1:
				if l1l111l_l1_==l1ll1l11l_l1_[-1]: l111l1_l1_(url2)
				else: l1l1l1l_l1_(url2,l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫྚ")+l111l11_l1_)
				return
			else:
				l11ll111_l1_ = l1l1ll1l1_l1_(url2)
				if l1l111l_l1_==l1ll1l11l_l1_[-1]: addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬྛ"),menu_name+l1l11l_l1_ (u"࠭วๅฮ่๎฾ࠦࠧྜ"),l11ll111_l1_,251,l1l11l_l1_ (u"ࠧࠨྜྷ"),l1l11l_l1_ (u"ࠨࠩྞ"),l1l11l_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪྟ"))
				else: addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྠ"),menu_name+l1l11l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬྡ"),url2,254,l1l11l_l1_ (u"ࠬ࠭ྡྷ"),l1l11l_l1_ (u"࠭ࠧྣ"),l111l11_l1_)
		elif type==l1l11l_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨྤ"):
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫྥ")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࡁ࠵࠭ྦ")
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭ྦྷ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂࡃ࠰ࠨྨ")
			l111l11_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩྩ")+l11l11l_l1_
			addMenuItem(l1l11l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ྪ"),menu_name+l1l11l_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩྫ")+name,url2,255,l1l11l_l1_ (u"ࠨࠩྫྷ"),l1l11l_l1_ (u"ࠩࠪྭ"),l111l11_l1_)		# +l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬྮ"))
		dict[l1l111l_l1_] = {}
		for option,dummy,value in items:
			if option in l1llll1_l1_: continue
			if l1l11l_l1_ (u"ࠫฬ๊ใๅࠩྯ") in option: continue
			option = unescapeHTML(option)
			#if l1l11l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪྰ") in option: continue
			#if l1l11l_l1_ (u"࠭࡮࠮ࡣࠪྱ") in value: continue
			l1l1l1lll_l1_,title2 = option,option
			title2 = name+l1l11l_l1_ (u"ࠧ࠻ࠢࠪྲ")+l1l1l1lll_l1_
			dict[l1l111l_l1_][value] = title2
			l11ll11_l1_ = l111111_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫླ")+l1l111l_l1_+l1l11l_l1_ (u"ࠩࡀࡁࠬྴ")+l1l1l1lll_l1_
			l11l11l_l1_ = l1llllll_l1_+l1l11l_l1_ (u"ࠪࠪࠫ࠭ྵ")+l1l111l_l1_+l1l11l_l1_ (u"ࠫࡂࡃࠧྶ")+value
			l1l1111_l1_ = l11ll11_l1_+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩྷ")+l11l11l_l1_
			if type==l1l11l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧྸ"):
				addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧྐྵ"),menu_name+title2,url,255,l1l11l_l1_ (u"ࠨࠩྺ"),l1l11l_l1_ (u"ࠩࠪྻ"),l1l1111_l1_)		# +l1l11l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬྼ"))
			elif type==l1l11l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ྽") and l1ll1l11l_l1_[-2]+l1l11l_l1_ (u"ࠬࡃ࠽ࠨ྾") in l111111_l1_:
				l1llll11_l1_ = l1llll1l_l1_(l11l11l_l1_,l1l11l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ྿"))
				#DIALOG_OK(l1l11l_l1_ (u"ࠧࠨ࿀"),l1l11l_l1_ (u"ࠨࠩ࿁"),l1llll11_l1_,l11l11l_l1_)
				url3 = url+l1l11l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ࿂")+l1llll11_l1_
				l11ll111_l1_ = l1l1ll1l1_l1_(url3)
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿃"),menu_name+title2,l11ll111_l1_,251,l1l11l_l1_ (u"ࠫࠬ࿄"),l1l11l_l1_ (u"ࠬ࠭࿅"),l1l11l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹ࿆ࠧ"))
			else: addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿇"),menu_name+title2,url,254,l1l11l_l1_ (u"ࠨࠩ࿈"),l1l11l_l1_ (u"ࠩࠪ࿉"),l1l1111_l1_)
	return
l1ll1l11l_l1_ = [l1l11l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ࿊"),l1l11l_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ࿋"),l1l11l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ࿌")]
l1ll11l1l_l1_ = [l1l11l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ࿍"),l1l11l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ࿎"),l1l11l_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ࿏"),l1l11l_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ࿐"),l1l11l_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ࿑"),l1l11l_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ࿒"),l1l11l_l1_ (u"ࠬࡸࡡࡵࡧࠪ࿓")]
def l1l1ll1l1_l1_(url):
	l1l11llll_l1_ = l1l11l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊࡲࡳࡩࡣ࡬࡯࡭࠸࠰࠳࠳࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡌࡴࡳࡥ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡌࡴࡳࡥ࠯ࡲ࡫ࡴࠬ࿔")
	url = url.replace(l1l11l_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࠫ࿕"),l1l11llll_l1_)
	url = url.replace(l1l11l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ฬิั๊ࠩ࿖"),l1l11l_l1_ (u"ࠩࠪ࿗"))
	if l1l11llll_l1_ not in url: url = url+l1l11llll_l1_
	url = url.replace(l1l11l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ࿘"),l1l11l_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ࿙"))
	url = url.replace(l1l11l_l1_ (u"ࠬࡅ࠿ࠨ࿚"),l1l11l_l1_ (u"࠭࠿ࠨ࿛"))
	url = url.replace(l1l11l_l1_ (u"ࠧࠧࠨࠪ࿜"),l1l11l_l1_ (u"ࠨࠨࠪ࿝"))
	url = url.replace(l1l11l_l1_ (u"ࠩࡀࡁࠬ࿞"),l1l11l_l1_ (u"ࠪࡁࠬ࿟"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠫࠬ࿠"),l1l11l_l1_ (u"ࠬ࠭࿡"),l1l11l_l1_ (u"࠭ࠧ࿢"),l1l11l_l1_ (u"ࠧࡑࡔࡈࡔࡆࡘࡅࡠࡈࡌࡐ࡙ࡋࡒࡠࡈࡌࡒࡆࡒ࡟ࡖࡔࡏࠫ࿣"))
	return url
def l1llll1l_l1_(filters,mode):
	#DIALOG_OK(l1l11l_l1_ (u"ࠨࠩ࿤"),l1l11l_l1_ (u"ࠩࠪ࿥"),filters,l1l11l_l1_ (u"ࠪࡍࡓࠦࠠࠡࠢࠪ࿦")+mode)
	# mode==l1l11l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭࿧")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ values
	# mode==l1l11l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ࿨")		l11l1l1_l1_ l111ll1_l1_ l111lll_l1_ filters
	# mode==l1l11l_l1_ (u"࠭ࡡ࡭࡮ࠪ࿩")					all filters (l1lll1l1_l1_ l111lll_l1_ filter)
	filters = filters.strip(l1l11l_l1_ (u"ࠧࠧࠨࠪ࿪"))
	l11111l_l1_,l11llll_l1_ = {},l1l11l_l1_ (u"ࠨࠩ࿫")
	if l1l11l_l1_ (u"ࠩࡀࡁࠬ࿬") in filters:
		items = filters.split(l1l11l_l1_ (u"ࠪࠪࠫ࠭࿭"))
		for item in items:
			var,value = item.split(l1l11l_l1_ (u"ࠫࡂࡃࠧ࿮"))
			l11111l_l1_[var] = value
	for key in l1ll11l1l_l1_:
		if key in list(l11111l_l1_.keys()): value = l11111l_l1_[key]
		else: value = l1l11l_l1_ (u"ࠬ࠶ࠧ࿯")
		if l1l11l_l1_ (u"࠭ࠥࠨ࿰") not in value: value = QUOTE(value)
		if mode==l1l11l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ࿱") and value!=l1l11l_l1_ (u"ࠨ࠲ࠪ࿲"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠩࠣ࠯ࠥ࠭࿳")+value
		elif mode==l1l11l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭࿴") and value!=l1l11l_l1_ (u"ࠫ࠵࠭࿵"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠬࠬࠦࠨ࿶")+key+l1l11l_l1_ (u"࠭࠽࠾ࠩ࿷")+value
		elif mode==l1l11l_l1_ (u"ࠧࡢ࡮࡯ࠫ࿸"): l11llll_l1_ = l11llll_l1_+l1l11l_l1_ (u"ࠨࠨࠩࠫ࿹")+key+l1l11l_l1_ (u"ࠩࡀࡁࠬ࿺")+value
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠪࠤ࠰ࠦࠧ࿻"))
	l11llll_l1_ = l11llll_l1_.strip(l1l11l_l1_ (u"ࠫࠫࠬࠧ࿼"))
	#DIALOG_OK(l1l11l_l1_ (u"ࠬ࠭࿽"),l1l11l_l1_ (u"࠭ࠧ࿾"),l11llll_l1_,l1l11l_l1_ (u"ࠧࡐࡗࡗࠫ࿿"))
	return l11llll_l1_
# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ䡏")
#headers = {l1l11l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䡐"):l1l11l_l1_ (u"ࠬ࠭䡑")}
menu_name = l1l11l_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬ䡒")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"ࠧๆืสี฾ฯࠧ䡓"),l1l11l_l1_ (u"ࠨสฮࠤ๊ฮวีำࠪ䡔")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l111l1_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l111ll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭䡕"),l11lll_l1_,l1l11l_l1_ (u"ࠪࠫ䡖"),l1l11l_l1_ (u"ࠫࠬ䡗"),l1l11l_l1_ (u"ࠬ࠭䡘"),l1l11l_l1_ (u"࠭ࠧ䡙"),l1l11l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䡚"))
	html = response.content
	l111llll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䡛"),html,re.DOTALL)
	l111llll1_l1_ = l111llll1_l1_[0].strip(l1l11l_l1_ (u"ࠩ࠲ࠫ䡜"))
	l111llll1_l1_ = SERVER(l111llll1_l1_,l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ䡝"))
	addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䡞"),menu_name+l1l11l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䡟"),l111llll1_l1_,489,l1l11l_l1_ (u"࠭ࠧ䡠"),l1l11l_l1_ (u"ࠧࠨ䡡"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡢"))
	addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䡣"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䡤"),l1l11l_l1_ (u"ࠫࠬ䡥"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䡦"),script_name+l1l11l_l1_ (u"࠭࡟ࡠࡡࠪ䡧")+menu_name+l1l11l_l1_ (u"ࠧฤฯาฯࠥอไๆ๊สฺ๏฿ࠧ䡨"),l111llll1_l1_,481)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࠧࡳࡹࡂࡥࡦࡳࡺࡴࡴࠣࠩ䡩"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䡪"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠪࠧࠬ䡫"): continue
		if title in l1llll1_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䡬"),script_name+l1l11l_l1_ (u"ࠬࡥ࡟ࡠࠩ䡭")+menu_name+title,l1111l_l1_,481)
	return html
def l111l1_l1_(url,l11ll1l11l11_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"࠭ࡇࡆࡖࠪ䡮"),url,l1l11l_l1_ (u"ࠧࠨ䡯"),l1l11l_l1_ (u"ࠨࠩ䡰"),l1l11l_l1_ (u"ࠩࠪ䡱"),l1l11l_l1_ (u"ࠪࠫ䡲"),l1l11l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ䡳"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰࡰࡵࡷࠬ࠳࠰࠿ࠪࠤࡩࡳࡴࡺࡥࡳࠤࠪ䡴"),html,re.DOTALL)
	if not l1ll111_l1_: return
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ䡵"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"ࠧๆึส๋ิฯࠧ䡶"),l1l11l_l1_ (u"ࠨใํ่๊࠭䡷"),l1l11l_l1_ (u"ࠩส฾๋๐ษࠨ䡸"),l1l11l_l1_ (u"ࠪว฿์๊สࠩ䡹"),l1l11l_l1_ (u"่๊๊ࠫษࠩ䡺"),l1l11l_l1_ (u"ࠬอูๅษ้ࠫ䡻"),l1l11l_l1_ (u"࠭็ะษไࠫ䡼"),l1l11l_l1_ (u"ࠧๆสสีฬฯࠧ䡽"),l1l11l_l1_ (u"ࠨ฻ิฺࠬ䡾"),l1l11l_l1_ (u"่๋ࠩึาว็ࠩ䡿"),l1l11l_l1_ (u"ࠪห้ฮ่ๆࠩ䢀"),l1l11l_l1_ (u"ู๊ࠫัฮ์ฬࠫ䢁")]
	l11ll1l11l1l_l1_ = l1l11l_l1_ (u"ࠬ࠵ࠧ䢂").join(l11ll1l11l11_l1_.strip(l1l11l_l1_ (u"࠭࠯ࠨ䢃")).split(l1l11l_l1_ (u"ࠧ࠰ࠩ䢄"))[4:]).split(l1l11l_l1_ (u"ࠨ࠯ࠪ䢅"))
	for l1111l_l1_,title,img in items:
		title = unescapeHTML(title)
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ䢆"),title,re.DOTALL)
		if l11ll1l11l11_l1_:
			l11l111l1_l1_ = l1l11l_l1_ (u"ࠪ࠳ࠬ䢇").join(l1111l_l1_.strip(l1l11l_l1_ (u"ࠫ࠴࠭䢈")).split(l1l11l_l1_ (u"ࠬ࠵ࠧ䢉"))[4:]).split(l1l11l_l1_ (u"࠭࠭ࠨ䢊"))
			l11ll1l11ll1_l1_ = len([x for x in l11ll1l11l1l_l1_ if x in l11l111l1_l1_])
			if l11ll1l11ll1_l1_>2 and l1l11l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䢋") in l1111l_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䢌"),menu_name+title,l1111l_l1_,482,img)
		else:
			if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ䢍"),title,re.DOTALL)
			#if any(value in title for value in l111l11ll_l1_):
			if set(title.split()) & set(l111l11ll_l1_) and l1l11l_l1_ (u"ุ้๊ࠪำๅࠩ䢎") not in title:
				addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䢏"),menu_name+title,l1111l_l1_,482,img)
			elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠬำไใหࠪ䢐") in title:
				title = l1l11l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䢑") + l1ll1ll_l1_[0]
				if title not in l1l1l11_l1_:
					addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䢒"),menu_name+title,l1111l_l1_,483,img,l1l11l_l1_ (u"ࠨࠩ䢓"),url)
					l1l1l11_l1_.append(title)
			else: addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢔"),menu_name+title,l1111l_l1_,483,img,l1l11l_l1_ (u"ࠪࠫ䢕"),url)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠦࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ䢖"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ䢗"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"࠭วๅืไัฮࠦࠧ䢘"),l1l11l_l1_ (u"ࠧࠨ䢙"))
			if title!=l1l11l_l1_ (u"ࠨࠩ䢚"): addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢛"),menu_name+l1l11l_l1_ (u"ูࠪๆำษࠡࠩ䢜")+title,l1111l_l1_,481,l1l11l_l1_ (u"ࠫࠬ䢝"),l1l11l_l1_ (u"ࠬ࠭䢞"),l11ll1l11l11_l1_)
	return
def l111ll_l1_(url,url2):
	headers = {l1l11l_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䢟"):l1l11l_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䢠")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䢡"),url,l1l11l_l1_ (u"ࠩࠪ䢢"),headers,l1l11l_l1_ (u"ࠪࠫ䢣"),l1l11l_l1_ (u"ࠫࠬ䢤"),l1l11l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䢥"))
	html = response.content
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䢦"))
	img = re.findall(l1l11l_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䢧"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ䢨"))
	l11ll1l111ll_l1_ = True
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡰ࡮ࡹࡴࡔࡧࡤࡷࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ䢩"),html,re.DOTALL)
	# l111lll1l_l1_
	if l111l11l1_l1_ and l1l11l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ䢪") not in url:
		block = l111l11l1_l1_[0]
		count = block.count(l1l11l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠨ䢫"))
		if count==0: count = block.count(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠫ䢬"))
		if count>1:
			l11ll1l111ll_l1_ = False
			if l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠥࠫ䢭") in block:
				items = re.findall(l1l11l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ䢮"),block,re.DOTALL)
				for id,title in items:
					l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠵࠲ࡵ࡮ࡰࡀࡵ࡯ࡹ࡬ࡃࠧ䢯")+id
					addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢰"),menu_name+title,l1111l_l1_,483,img)
			else:
				items = re.findall(l1l11l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭䢱"),block,re.DOTALL)
				for id,title in items:
					l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠴ࡰࡩࡲࡂࡷࡪࡸࡩࡦࡵࡌࡈࡂ࠭䢲")+id
					addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䢳"),menu_name+title,l1111l_l1_,483,img)
	# l1l11l1_l1_
	if l11ll1l111ll_l1_:
		block = l1l11l_l1_ (u"࠭ࠧ䢴")
		if l1l11l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ䢵") in url: block = html
		else:
			l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡨࡴࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭䢶"),html,re.DOTALL)
			if l1ll1lll1_l1_: block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䢷"),block,re.DOTALL)
		if items:
			for l1111l_l1_,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬ䢸"))
				addMenuItem(l1l11l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䢹"),menu_name+title,l1111l_l1_,482,img)
	if not menuItemsLIST: l111l1_l1_(url2,url)
	return
def PLAY(url):
	url2 = url.strip(l1l11l_l1_ (u"ࠬ࠵ࠧ䢺"))+l1l11l_l1_ (u"࠭࠯ࡀࡦࡲࡁࡼࡧࡴࡤࡪࠪ䢻")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠧࡈࡇࡗࠫ䢼"),url2,l1l11l_l1_ (u"ࠨࠩ䢽"),l1l11l_l1_ (u"ࠩࠪ䢾"),l1l11l_l1_ (u"ࠪࠫ䢿"),l1l11l_l1_ (u"ࠫࠬ䣀"),l1l11l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䣁"))
	html = response.content
	l1ll1lll_l1_ = []
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"࠭ࡵࡳ࡮ࠪ䣂"))
	l1111l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࡷࡱࡢࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣃"),html,re.DOTALL)
	if not l1111l1l1_l1_: l1111l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠨ࡞ࠫࡸ࡭࡯ࡳ࡝࠰࡬ࡨࡡ࠲࠰࡝࠮ࠫ࠲࠯ࡅࠩ࡝ࠫࠪ䣄"),html,re.DOTALL)
	l1111l1l1_l1_ = l1111l1l1_l1_[0]
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ䣅"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ䣆"),block,re.DOTALL)
		for l111l1111_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"ࠫࠥ࠭䣇"))
			l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡩࡧࡴࡤࡱࡪ࠸࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ䣈")+l1111l1l1_l1_+l1l11l_l1_ (u"࠭ࠦࡷ࡫ࡧࡩࡴࡃࠧ䣉")+l111l1111_l1_[2:]+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䣊")+title+l1l11l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䣋")
			l1ll1lll_l1_.append(l1111l_l1_)
	# l1l11ll1l_l1_ l1l1ll11l_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠩࠥ࡫ࡪࡺࡅ࡮ࡤࡨࡨࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣌"),html,re.DOTALL)
	if l1111l_l1_:
		title = SERVER(l1111l_l1_[0],l1l11l_l1_ (u"ࠪࡹࡷࡲࠧ䣍"))
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䣎")+title+l1l11l_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭䣏")
		l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	url2 = url.strip(l1l11l_l1_ (u"࠭࠯ࠨ䣐"))+l1l11l_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䣑")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬ䣒"),url2,l1l11l_l1_ (u"ࠩࠪ䣓"),l1l11l_l1_ (u"ࠪࠫ䣔"),l1l11l_l1_ (u"ࠫࠬ䣕"),l1l11l_l1_ (u"ࠬ࠭䣖"),l1l11l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ䣗"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡶࡤࡦࡱ࡫࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ䣘"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䣙"),block,re.DOTALL)
		for title,l1111l_l1_ in items:
			title = title.strip(l1l11l_l1_ (u"ࠩࠣࠫ䣚"))
			if l1l11l_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ䣛") in l1111l_l1_: title2 = l1l11l_l1_ (u"ࠫࡤࡥฮศืࠪ䣜")
			else: title2 = l1l11l_l1_ (u"ࠬ࠭䣝")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䣞")+title+l1l11l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䣟")+title2
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䣠"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䣡"),url)
	return
def SEARCH(search,l111llll1_l1_=l1l11l_l1_ (u"ࠪࠫ䣢")):
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if search==l1l11l_l1_ (u"ࠫࠬ䣣"): search = OPEN_KEYBOARD()
	if search==l1l11l_l1_ (u"ࠬ࠭䣤"): return
	search = search.replace(l1l11l_l1_ (u"࠭ࠠࠨ䣥"),l1l11l_l1_ (u"ࠧࠬࠩ䣦"))
	if l111llll1_l1_==l1l11l_l1_ (u"ࠨࠩ䣧"): l111llll1_l1_ = l11lll_l1_
	url = l111llll1_l1_+l1l11l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ䣨")+search+l1l11l_l1_ (u"ࠪ࠳ࠬ䣩")
	l111l1_l1_(url,l1l11l_l1_ (u"ࠫࠬ䣪"))
	return
# -*- coding: utf-8 -*-
from IMPORTS import *

script_name = 'IPTV'
menu_name = '_IPT_'

ALL_TYPES = [
		 'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]

def MAIN(mode,url,text,type,page):
	if   mode==230: results = MENU()
	elif mode==231: results = ADD_ACCOUNT()
	elif mode==232: results = CREATE_STREAMS()
	elif mode==233: results = GROUPS(url,text,page)
	elif mode==234: results = ITEMS(url,text,page)
	elif mode==235: results = PLAY(url,type)
	elif mode==236: results = CHECK_ACCOUNT(True)
	elif mode==237: results = DELETE_IPTV_FILES(True)
	elif mode==238: results = EPG_ITEMS(url,text)
	elif mode==239: results = SEARCH(text,url,page)
	elif mode==280: results = ADD_USERAGENT()
	elif mode==281: results = COUNTS()
	elif mode==282: results = USE_FASTER_SERVER()
	else: results = False
	return results

def MENU():
	addMenuItem('folder',menu_name+'بحث في ملفات IPTV','',239,'','','_REMEMBERRESULTS_')
	addMenuItem('folder',menu_name+'قائمة أقسام IPTV','',165,'','','_IPTV_')
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('folder',menu_name+'قنوات مصنفة','LIVE_GROUPED',233)
	addMenuItem('folder',menu_name+'أفلام مصنفة','VOD_MOVIES_GROUPED',233)
	addMenuItem('folder',menu_name+'مسلسلات مصنفة','VOD_SERIES_GROUPED',233)
	addMenuItem('folder',menu_name+'فيديوهات مجهولة','VOD_UNKNOWN_GROUPED',233)
	addMenuItem('folder',menu_name+'قنوات مجهولة','LIVE_UNKNOWN_GROUPED',233)
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('folder',menu_name+'قنوات مصنفة ومرتبة','LIVE_GROUPED_SORTED',233)
	addMenuItem('folder',menu_name+'أفلام مصنفة ومرتبة','VOD_MOVIES_GROUPED_SORTED',233)
	addMenuItem('folder',menu_name+'مسلسلات مصنفة ومرتبة','VOD_SERIES_GROUPED_SORTED',233)
	addMenuItem('folder',menu_name+'فيديوهات مجهولة ومرتبة','VOD_UNKNOWN_GROUPED_SORTED',233)
	addMenuItem('folder',menu_name+'قنوات مجهولة ومرتبة','LIVE_UNKNOWN_GROUPED_SORTED',233)
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('folder',menu_name+'القنوات الأصلية بدون تغيير','LIVE_ORIGINAL_GROUPED',233)
	addMenuItem('folder',menu_name+'الفيديوهات الأصلية بدون تغيير','VOD_ORIGINAL_GROUPED',233)
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('folder',menu_name+'قنوات مصنفة من أسمائها ومرتبة','LIVE_FROM_NAME_SORTED',233)
	addMenuItem('folder',menu_name+'فيديوهات مصنفة من أسمائها ومرتبة','VOD_FROM_NAME_SORTED',233)
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('folder',menu_name+'قنوات مصنفة من أقسامها ومرتبة','LIVE_FROM_GROUP_SORTED',233)
	addMenuItem('folder',menu_name+'فيديوهات مصنفة من أقسامها ومرتبة','VOD_FROM_GROUP_SORTED',233)
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('folder',menu_name+'برامج القنوات (جدول فقط)','LIVE_EPG_GROUPED_SORTED',233)
	addMenuItem('folder',menu_name+'أرشيف القنوات للأيام الماضية','LIVE_TIMESHIFT_GROUPED_SORTED',233)
	addMenuItem('folder',menu_name+'أرشيف برامج القنوات للأيام الماضية','LIVE_ARCHIVED_GROUPED_SORTED',233)
	addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
	addMenuItem('link',menu_name+'إضافة أو تغيير اشتراك IPTV','',231)
	addMenuItem('link',menu_name+'عدد فيديوهات IPTV','',281)
	addMenuItem('link',menu_name+'فحص اشتراك IPTV','',236)
	addMenuItem('link',menu_name+'جلب ملفات IPTV','',232)
	addMenuItem('link',menu_name+'مسح ملفات IPTV','',237)
	addMenuItem('link',menu_name+'استخدام السيرفر الأسرع','',282)
	addMenuItem('link',menu_name+'تغيير IPTV User-Agent','',280)
	return

def CHECK_ACCOUNT(showDialog=True):
	ok,status = False,''
	new_host,new_port = '',''
	iptvURL_player,iptvURL_get,server,username,password = GET_IPTV_URL()
	if username=='': return
	useragent = settings.getSetting('av.iptv.useragent')
	headers = {'User-Agent':useragent}
	if iptvURL_player:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,'GET',iptvURL_player,'',headers,False,False,'IPTV-CHECK_ACCOUNT-1st')
		html = response.content
		if response.succeeded:
			timestamp,timediff,time_now,created_at,exp_date = 0,0,'','',''
			try:
				dict = EVAL('dict',html)
				status = dict['user_info']['status']
				ok = True
				time_now = dict['server_info']['time_now']
			except: pass
			if time_now:
				try:
					struct = time.strptime(time_now,'%Y.%m.%d %H:%M:%S')
					timestamp = int(time.mktime(struct))
					timediff = int(now-timestamp)
					timediff = int((timediff+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict['user_info']['created_at']))
					created_at = time.strftime('%Y.%m.%d %H:%M:%S',struct)
				except: pass
				try:
					struct = time.localtime(int(dict['user_info']['exp_date']))
					exp_date = time.strftime('%Y.%m.%d %H:%M:%S',struct)
				except: pass
			settings.setSetting('av.iptv.timestamp',str(now))
			settings.setSetting('av.iptv.timediff',str(timediff))
			server_info = '"server_info":'+html.split('"server_info":')[1]
			server_info = server_info.replace(':',': ').replace(',',', ').replace('}}','}')
			new = re.findall('"url": "(.*?)", "port": "(.*?)"',server_info,re.DOTALL)
			new_host,new_port = new[0]
			if ok and showDialog:
				max = dict['user_info']['max_connections']
				active = dict['user_info']['active_cons']
				is_trial = dict['user_info']['is_trial']
				parts = iptvURL_player.split('?',1)
				message = 'URL:  [COLOR FFC89008]'+iptvURL_player+'[/COLOR]'
				message += '\n\nStatus:  '+'[COLOR FFC89008]'+status+'[/COLOR]'
				message += '\nTrial:    '+'[COLOR FFC89008]'+str(is_trial=='1')+'[/COLOR]'
				message += '\nCreated  At:  '+'[COLOR FFC89008]'+created_at+'[/COLOR]'
				message += '\nExpiry Date:  '+'[COLOR FFC89008]'+exp_date+'[/COLOR]'
				message += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+active+' / '+max+'[/COLOR]'
				message += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(dict['user_info']['allowed_output_formats'])+'[/COLOR]'
				message += '\n\n'+server_info
				if status=='Active': DIALOG_TEXTVIEWER('الاشتراك يعمل بدون مشاكل',message)
				else: DIALOG_TEXTVIEWER('يبدو أن هناك مشكلة في الاشتراك',message)
	if iptvURL_player and ok and status=='Active':
		LOG_THIS('NOTICE','.   Checking IPTV URL   [ IPTV account is OK ]   [ '+iptvURL_player+' ]')
		succeeded = True
	else:
		LOG_THIS('ERROR_LINES','Checking IPTV URL   [ Does not work ]   [ '+iptvURL_player+' ]')
		if showDialog: DIALOG_OK('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		succeeded = False
	return succeeded,new_host,new_port

def ITEMS(TYPE,GROUP,PAGE):
	if PAGE=='': PAGE = '1'
	total = IPTV_ITEMS(TYPE,GROUP,PAGE,isIPTVFiles,menuItemsLIST)
	IPTV_PAGINATION(PAGE,TYPE,234,total,GROUP)
	return

def showIPTVempty(menu_name2):
	addMenuItem('link',menu_name2+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	addMenuItem('link',menu_name2+'أو الخدمة غير موجودة في اشتراكك','',9999)
	addMenuItem('link',menu_name2+'أو رابط IPTVـ الذي أنت أضفته غير صحيح','',9999)
	return

def GROUPS(TYPE,GROUP,PAGE,website=''):
	if PAGE=='': PAGE = '1'
	menu_name2 = menu_name
	if website=='': showDialogs = True
	else: showDialogs = False
	if not isIPTVFiles(showDialogs):
		showIPTVempty(menu_name2)
		return
	if '__SERIES__' in GROUP: MAINGROUP,SUBGROUP = GROUP.split('__SERIES__')
	else: MAINGROUP,SUBGROUP = GROUP,''
	iptv_dbfile = GET_DBFILE_NAME(TYPE)
	uniquegroups = READ_FROM_SQL3(iptv_dbfile,'list','IPTV_'+TYPE,'__GROUPS__')
	if uniquegroups:
		unique = []
		for group,img in uniquegroups:
			if website:
				if '__SERIES__' in group: menu_name2 = 'SERIES'
				elif '!!__UNKNOWN__!!' in group: menu_name2 = 'UNKNOWN'
				elif 'LIVE' in TYPE: menu_name2 = 'LIVE'
				else: menu_name2 = 'VIDEOS'
				menu_name2 = ',[COLOR FFC89008]'+menu_name2+': [/COLOR]'
			if '__SERIES__' in group: maingroup,subgroup = group.split('__SERIES__')
			else: maingroup,subgroup = group,''
			if not GROUP:
				if maingroup in unique: continue
				unique.append(maingroup)
				if 'RANDOM' in website: addMenuItem('folder',menu_name2+maingroup,TYPE,167,'','1',group)
				elif '__SERIES__' in group: addMenuItem('folder',menu_name2+maingroup,TYPE,233,'','1',group)
				else: addMenuItem('folder',menu_name2+maingroup,TYPE,234,'','1',group)
			elif '__SERIES__' in group and maingroup==MAINGROUP:
				if subgroup in unique: continue
				unique.append(subgroup)
				if 'RANDOM' in website: addMenuItem('folder',menu_name2+subgroup,TYPE,167,'','1',group)
				else: addMenuItem('folder',menu_name2+subgroup,TYPE,234,img,'1',group)
		if not website:
			end = int(PAGE)*100
			start = end-100
			total = len(menuItemsLIST)
			menuItemsLIST[:] = menuItemsLIST[start:end]
			IPTV_PAGINATION(PAGE,TYPE,233,total,GROUP)
	else: showIPTVempty(menu_name2)
	return

def EPG_ITEMS(url,function):
	HOUR_ = 60*60
	useragent = settings.getSetting('av.iptv.useragent')
	headers = {'User-Agent':useragent}
	if not isIPTVFiles(True): return
	timestamp = settings.getSetting('av.iptv.timestamp')
	if timestamp=='' or now-int(timestamp)>24*HOUR_:
		ok,new_host,new_port = CHECK_ACCOUNT(False)
		if not ok: return
	timediff = int(settings.getSetting('av.iptv.timediff'))
	server = settings.getSetting('av.iptv.server')
	username = settings.getSetting('av.iptv.username')
	password = settings.getSetting('av.iptv.password')
	url_parts = url.split('/')
	stream_id = url_parts[-1].replace('.ts','').replace('.m3u8','')
	if function=='SHORT_EPG': url_action = 'get_short_epg'
	else: url_action = 'get_simple_data_table'
	iptvURL_player,iptvURL_get,server,username,password = GET_IPTV_URL()
	if username=='': return
	epg_url = iptvURL_player+'&action='+url_action+'&stream_id='+stream_id
	html = OPENURL_CACHED(NO_CACHE,epg_url,'',headers,'','IPTV-EPG_ITEMS-2nd')
	archive_files = EVAL('dict',html)
	all_epg = archive_files['epg_listings']
	epg_items = []
	if function in ['ARCHIVED','TIMESHIFT']:
		for dict in all_epg:
			if dict['has_archive']==1:
				epg_items.append(dict)
				if function in ['TIMESHIFT']: break
		if not epg_items: return
		addMenuItem('link',menu_name+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if function in ['TIMESHIFT']:
			length_hours = 2
			length_secs = length_hours*HOUR_
			epg_items = []
			initial_timestamp = int(int(dict['start_timestamp'])/length_secs)*length_secs
			finish_timestamp = now+length_secs
			videos_count = int((finish_timestamp-initial_timestamp)/HOUR_)
			for count in range(videos_count):
				if count>=6:
					if count%length_hours!=0: continue
					duration = length_secs
				else: duration = length_secs//2
				start_timestamp = initial_timestamp+count*HOUR_
				dict = {}
				dict['title'] = ''
				struct = time.localtime(start_timestamp-timediff-HOUR_)
				dict['start'] = time.strftime('%Y.%m.%d %H:%M:%S',struct)
				dict['start_timestamp'] = str(start_timestamp)
				dict['stop_timestamp'] = str(start_timestamp+duration)
				epg_items.append(dict)
	elif function in ['SHORT_EPG','FULL_EPG']: epg_items = all_epg
	if function=='FULL_EPG' and len(epg_items)>0:
		addMenuItem('link',menu_name+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	epg_list = []
	img = xbmc.getInfoLabel('ListItem.Icon')
	for dict in epg_items:
		title = base64.b64decode(dict['title'])
		if kodi_version>18.99: title = title.decode('utf8')
		start_timestamp = int(dict['start_timestamp'])
		stop_timestamp = int(dict['stop_timestamp'])
		duration_minutes = str(int((stop_timestamp-start_timestamp+59)/60))
		start_string = dict['start'].replace(' ',':')
		struct = time.localtime(start_timestamp-HOUR_)
		time_string = time.strftime('%H:%M',struct)
		english_dayname = time.strftime('%a',struct)
		if function=='SHORT_EPG': title = '[COLOR FFFFFF00]'+time_string+' ـ '+title+'[/COLOR]'
		elif function=='TIMESHIFT': title = english_dayname+' '+time_string+' ('+duration_minutes+'min)'
		else: title = english_dayname+' '+time_string+' ('+duration_minutes+'min)   '+title+' ـ'
		if function in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			timeshift_url = server+'/timeshift/'+username+'/'+password+'/'+duration_minutes+'/'+start_string+'/'+stream_id+'.m3u8'
			if function=='FULL_EPG': addMenuItem('link',menu_name+title,timeshift_url,9999,img)
			else: addMenuItem('video',menu_name+title,timeshift_url,235,img)
		epg_list.append(title)
	if function=='SHORT_EPG' and epg_list: selection = DIALOG_CONTEXTMENU(epg_list)
	return epg_list

def USE_FASTER_SERVER():
	if not isIPTVFiles(True): return
	server,pingTime_newserver,pingTime_orgserver = '',0,0
	succeeded,new_host,new_port = CHECK_ACCOUNT(False)
	if succeeded:
		new_host_ip = DNS_RESOLVER(new_host)
		pingTime_newserver = PING(new_host_ip[0],int(new_port))
		iptv_dbfile = GET_DBFILE_NAME('LIVE_GROUPED')
		groups = READ_FROM_SQL3(iptv_dbfile,'list','IPTV_LIVE_GROUPED')
		streams = READ_FROM_SQL3(iptv_dbfile,'list','IPTV_LIVE_GROUPED',groups[1])
		url = streams[0][2]
		org_server = re.findall('://(.*?)/',url,re.DOTALL)
		org_server = org_server[0]
		if ':' in org_server: org_host,org_port = org_server.split(':')
		else: org_host,org_port = org_server,'80'
		org_host_ip = DNS_RESOLVER(org_host)
		pingTime_orgserver = PING(org_host_ip[0],int(org_port))
	if pingTime_newserver and pingTime_orgserver:
		message = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		message += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(pingTime_orgserver*1000))+' ملي ثانية'
		message += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(pingTime_newserver*1000))+' ملي ثانية'
		yes = DIALOG_YESNO('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',message)
		if yes==1 and pingTime_newserver<pingTime_orgserver: server = new_host+':'+new_port
	else: DIALOG_OK('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	settings.setSetting('av.iptv.server',server)
	return

def PLAY(url,type):
	useragent = settings.getSetting('av.iptv.useragent')
	if useragent!='': url = url+'|User-Agent='+useragent
	new_server = settings.getSetting('av.iptv.server')
	if new_server:
		old_server = re.findall('://(.*?)/',url,re.DOTALL)
		url2 = url.replace(old_server[0],new_server)
		results = PLAY_VIDEO(url2,script_name,type)
	else: PLAY_VIDEO(url,script_name,type)
	return

def ADD_USERAGENT():
	DIALOG_OK('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	useragent = settings.getSetting('av.iptv.useragent')
	answer = DIALOG_YESNO('center','استخدام الأصلي','تعديل القديم',useragent,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if answer==1: useragent = OPEN_KEYBOARD('أكتب ـIPTV User-Agent جديد',useragent,True)
	else: useragent = 'Unknown'
	if useragent==' ':
		DIALOG_OK('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	answer = DIALOG_YESNO('center','','',useragent,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if answer!=1:
		DIALOG_OK('','','رسالة من المبرمج','تم الإلغاء')
		return
	settings.setSetting('av.iptv.useragent',useragent)
	CREATE_STREAMS()
	return

def GET_IPTV_URL(iptvURL=''):
	if iptvURL=='': iptvURL = settings.getSetting('av.iptv.url')
	server = SERVER(iptvURL,'url')
	username = re.findall('username=(.*?)&',iptvURL+'&',re.DOTALL)
	password = re.findall('password=(.*?)&',iptvURL+'&',re.DOTALL)
	if not username or not password:
		DIALOG_OK('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	username = username[0]
	password = password[0]
	iptvURL_player = server+'/player_api.php?username='+username+'&password='+password
	iptvURL_get = server+'/get.php?username='+username+'&password='+password+'&type=m3u_plus'
	return iptvURL_player,iptvURL_get,server,username,password

def ADD_ACCOUNT():
	answer = DIALOG_YESNO('center','','','رسالة من المبرمج','هذا البرنامج يحتاج اشتراك ـIPTV من أي شركة ـIPTV ونوع رابط التحميل المطلوب هو \n[COLOR FFFFFF00]m3u[/COLOR]\n  \n هل تريد تغيير الرابط الآن ؟')
	if answer!=1: return
	old_iptvURL = settings.getSetting('av.iptv.url')
	if old_iptvURL!='':
		answer = DIALOG_YESNO('center','كتابة جديد','تعديل القديم','الرابط الحالي هو:','[COLOR FFC89008]'+old_iptvURL+'[/COLOR]'+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if answer!=1: old_iptvURL = ''
	new_iptvURL = OPEN_KEYBOARD('اكتب رابط ـIPTV كاملا',old_iptvURL)
	if new_iptvURL=='': return
	else:
		iptvURL_player,iptvURL_get,server,username,password = GET_IPTV_URL(new_iptvURL)
		if username=='': return
		message = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		message += '\n[COLOR FFFFFF00]'+server+'[/COLOR]عنوان السيرفر: '
		message += '\n[COLOR FFFFFF00]'+username+'[/COLOR]اسم المستخدم: '
		message += '\n[COLOR FFFFFF00]'+password+'[/COLOR]كلمة السر: '
		answer = DIALOG_YESNO('right','','','الرابط الجديد هو:','[COLOR FFC89008]'+new_iptvURL+'[/COLOR]'+'\n'+message)
		if answer!=1:
			DIALOG_OK('','','رسالة من المبرمج','تم الإلغاء')
			return
	settings.setSetting('av.iptv.url',new_iptvURL)
	settings.setSetting('av.iptv.timestamp','')
	settings.setSetting('av.iptv.timediff','')
	useragent = settings.getSetting('av.iptv.useragent')
	if useragent=='': settings.setSetting('av.iptv.useragent','Unknown')
	yes = DIALOG_YESNO('center','','',new_iptvURL,'تم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if yes==1: ok,new_host,new_port = CHECK_ACCOUNT(True)
	CREATE_STREAMS()
	return

def READ_ALL_IPTV_LINES(lines,live_epg_channels,live_archived_channels,pDialog,length,jj):
	streams,ignored_streams = [],[]
	vod_types = ['.avi','.mp4','.mkv','.flv','.mp3','.webm']
	for line in lines:
		if jj%473==0:
			PROGRESS_UPDATE(pDialog,40+int(10*jj/length),'قراءة الفيديوهات','الفيديو رقم:-',str(jj)+' / '+str(length))
			if pDialog.iscanceled(): return None,None,None
		if 'http:' in line:
			line,url = line.rsplit('http:',1)
			url = 'http:'+url
		elif 'https:' in line:
			line,url = line.rsplit('https:',1)
			url = 'https:'+url
		elif 'rtmp:' in line:
			line,url = line.rsplit('rtmp:',1)
			url = 'rtmp:'+url
		else:
			ignored_streams.append({'line':line})
			continue
		dict1,context,group,title,type,is_vod_url = {},'','','','',False
		try:
			line,title = line.rsplit('",',1)
			line = line+'"'
		except:
			try: line,title = line.rsplit('1,',1)
			except: title = ''
		dict1['url'] = url
		params = re.findall(' (.*?)="(.*?)"',line,re.DOTALL)
		for key,value in params:
			key = key.replace('"','').strip(' ')
			dict1[key] = value.strip(' ')
		if not title:
			if 'name' in list(dict1.keys()) and dict1['name']: title = dict1['name']
		dict1['title'] = title.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in list(dict1.keys()):
			dict1['img'] = dict1['logo']
			del dict1['logo']
		else: dict1['img'] = ''
		if 'group' in list(dict1.keys()) and dict1['group']: group = dict1['group']
		if any(value in url.lower() for value in vod_types): is_vod_url = True
		if is_vod_url or '__SERIES__' in group or '__MOVIES__' in group:
			type = 'VOD'
			if '__SERIES__' in group: type = type+'_SERIES'
			elif '__MOVIES__' in group: type = type+'_MOVIES'
			else: type = type+'_UNKNOWN'
			group = group.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			type = 'LIVE'
			if title in live_epg_channels: context = context+'_EPG'
			if title in live_archived_channels: context = context+'_ARCHIVED'
			if not group: type = type+'_UNKNOWN'
			else: type = type+context
		group = group.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in type: group = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in type: group = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in type:
			series_title = re.findall('(.*?) [Ss]\d+ +[Ee]\d+',dict1['title'],re.DOTALL)
			if series_title: series_title = series_title[0]
			else: series_title = '!!__UNKNOWN_SERIES__!!'
			group = group+'__SERIES__'+series_title
		if 'id' in list(dict1.keys()): del dict1['id']
		if 'ID' in list(dict1.keys()): del dict1['ID']
		if 'name' in list(dict1.keys()): del dict1['name']
		title = dict1['title']
		title = escapeUNICODE(title)
		title = CLEAN_IPTV_NAME(title)
		language,group = SPLIT_IPTV_NAME(group)
		country,title = SPLIT_IPTV_NAME(title)
		dict1['type'] = type
		dict1['context'] = context
		dict1['group'] = group.upper()
		dict1['title'] = title.upper()
		dict1['country'] = country.upper()
		dict1['language'] = language.upper()
		streams.append(dict1)
		jj += 1
	return streams,jj,ignored_streams

def CLEAN_IPTV_NAME(title):
	title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	title = title.replace('||','|').replace('___',':').replace('--','-')
	title = title.replace('[[','[').replace(']]',']')
	title = title.replace('((','(').replace('))',')')
	title = title.replace('<<','<').replace('>>','>')
	title = title.strip(' ')
	return title

def CREATE_IPTV_GROUPED_STREAMS(streams_not_sorted,pDialog,ALL_TYPES):
	grouped_streams = {}
	for type1 in ALL_TYPES: grouped_streams[type1] = []
	length = len(streams_not_sorted)
	text3 = str(length)
	jj = 0
	ignored_streams = []
	for dict1 in streams_not_sorted:
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,50+int(5*jj/length),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(jj)+' / '+text3)
			if pDialog.iscanceled(): return None,None
		group,context,title,url,img = dict1['group'],dict1['context'],dict1['title'],dict1['url'],dict1['img']
		country,language,type1 = dict1['country'],dict1['language'],dict1['type']
		tuple2 = (group,context,title,url,img)
		fail = False
		if 'LIVE' in type1:
			if 'UNKNOWN' in type1: grouped_streams['LIVE_UNKNOWN_GROUPED'].append(tuple2)
			elif 'LIVE' in type1: grouped_streams['LIVE_GROUPED'].append(tuple2)
			else: fail = True
			grouped_streams['LIVE_ORIGINAL_GROUPED'].append(tuple2)
		elif 'VOD' in type1:
			if 'UNKNOWN' in type1: grouped_streams['VOD_UNKNOWN_GROUPED'].append(tuple2)
			elif 'MOVIES' in type1: grouped_streams['VOD_MOVIES_GROUPED'].append(tuple2)
			elif 'SERIES' in type1: grouped_streams['VOD_SERIES_GROUPED'].append(tuple2)
			else: fail = True
			grouped_streams['VOD_ORIGINAL_GROUPED'].append(tuple2)
		else: fail = True
		if fail: ignored_streams.append(dict1)
		jj += 1
	streams_sorted = sorted(streams_not_sorted,reverse=False,key=lambda key: key['title'].lower())
	del streams_not_sorted
	text3 = str(length)
	jj = 0
	for dict1 in streams_sorted:
		jj += 1
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,55+int(5*jj/length),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(jj)+' / '+text3)
			if pDialog.iscanceled(): return None,None
		type1 = dict1['type']
		group,context,title,url,img = dict1['group'],dict1['context'],dict1['title'],dict1['url'],dict1['img']
		country,language = dict1['country'],dict1['language']
		tuple1 = (group,context+'_TIMESHIFT',title,url,img)
		tuple2 = (group,context,title,url,img)
		tuple3 = (country,context,title,url,img)
		tuple4 = (language,context,title,url,img)
		if 'LIVE' in type1:
			if 'UNKNOWN' in type1: grouped_streams['LIVE_UNKNOWN_GROUPED_SORTED'].append(tuple2)
			else: grouped_streams['LIVE_GROUPED_SORTED'].append(tuple2)
			if 'EPG'		in type1: grouped_streams['LIVE_EPG_GROUPED_SORTED'].append(tuple2)
			if 'ARCHIVED'	in type1: grouped_streams['LIVE_ARCHIVED_GROUPED_SORTED'].append(tuple2)
			if 'ARCHIVED'	in type1: grouped_streams['LIVE_TIMESHIFT_GROUPED_SORTED'].append(tuple1)
			grouped_streams['LIVE_FROM_NAME_SORTED'].append(tuple3)
			grouped_streams['LIVE_FROM_GROUP_SORTED'].append(tuple4)
		elif 'VOD' in type1:
			if   'UNKNOWN'	in type1: grouped_streams['VOD_UNKNOWN_GROUPED_SORTED'].append(tuple2)
			elif 'MOVIES'	in type1: grouped_streams['VOD_MOVIES_GROUPED_SORTED'].append(tuple2)
			elif 'SERIES'	in type1: grouped_streams['VOD_SERIES_GROUPED_SORTED'].append(tuple2)
			grouped_streams['VOD_FROM_NAME_SORTED'].append(tuple3)
			grouped_streams['VOD_FROM_GROUP_SORTED'].append(tuple4)
	return grouped_streams,ignored_streams

def SPLIT_IPTV_NAME(title):
	if len(title)<3: return title,title
	lang,sep = '',''
	title2 = title
	first = title[:1]
	rest = title[1:]
	if   first=='(': sep = ')'
	elif first=='[': sep = ']'
	elif first=='<': sep = '>'
	elif first=='|': sep = '|'
	if sep and (sep in rest):
		part1,part2 = rest.split(sep,1)
		lang = part1
		title2 = first+part1+sep+' '+part2
	elif title.count('|')>=2:
		part1,part2 = title.split('|',1)
		lang = part1
		title2 = part1+' |'+part2
	else:
		sep = re.findall('^\w{2}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',title,re.DOTALL)
		if not sep: sep = re.findall('^\w{3}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',title,re.DOTALL)
		if not sep: sep = re.findall('^\w{4}( |\:|\-|\||\]|\)|\#|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',title,re.DOTALL)
		if sep:
			part1,part2 = title.split(sep[0],1)
			lang = part1
			title2 = part1+' '+sep[0]+' '+part2
	title2 = title2.replace('   ',' ').replace('  ',' ')
	lang = lang.replace('  ',' ')
	if lang=='': lang = '!!__UNKNOWN__!!'
	lang = lang.strip(' ')
	title2 = title2.strip(' ')
	return lang,title2

def IPTV_ITEMS(TYPE,GROUP,PAGE,isIPTVFiles,menuItemsLIST):
	if PAGE=='': PAGE = '1'
	menu_name = '_IPT_'
	if not isIPTVFiles(True): return None
	iptv_dbfile = GET_DBFILE_NAME(TYPE)
	streams = READ_FROM_SQL3(iptv_dbfile,'list','IPTV_'+TYPE,GROUP)
	end = int(PAGE)*100
	start = end-100
	for context,title,url,img in streams[start:end]:
		cond1 = ('GROUPED' in TYPE or TYPE=='ALL')
		cond2 = ('GROUPED' not in TYPE and TYPE!='ALL')
		if cond1 or cond2:
			if   'ARCHIVED'  in TYPE: menuItemsLIST.append(['folder',menu_name+title,url,238,img,'','ARCHIVED','',''])
			elif 'EPG' 		 in TYPE: menuItemsLIST.append(['folder',menu_name+title,url,238,img,'','FULL_EPG','',''])
			elif 'TIMESHIFT' in TYPE: menuItemsLIST.append(['folder',menu_name+title,url,238,img,'','TIMESHIFT','',''])
			elif 'LIVE' 	 in TYPE: menuItemsLIST.append(['live',menu_name+title,url,235,img,'','',context,''])
			else: menuItemsLIST.append(['video',menu_name+title,url,235,img,'','','',''])
	return len(streams)

def CREATE_STREAMS():
	global pDialog,total_saved,finalstreams,menus_counts,all_menus,total_menus_count
	iptvURL_player,iptvURL_get,server,username,password = GET_IPTV_URL()
	if username=='': return
	useragent = settings.getSetting('av.iptv.useragent')
	headers = {'User-Agent':useragent}
	yes = DIALOG_YESNO('center','','','رسالة من المبرمج','عملية جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if yes!=1: return
	if 1:
		ok,new_host,new_port = CHECK_ACCOUNT(False)
		if not ok:
			DIALOG_OK('','','رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو انت لم تستخدم سابقا خدمة ـIPTV الموجودة بالبرنامج .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not iptvURL_get: LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   No IPTV URL found to download IPTV files')
			else: LOG_THIS('ERROR_LINES',LOGGING(script_name)+'   Failed to download IPTV files')
			return
		m3u_text = DOWNLOAD_USING_PROGRESSBAR(iptvURL_get,headers)
		if not m3u_text: return
		open(fulliptvfile,'wb').write(m3u_text)
	else: m3u_text = open(fulliptvfile,'rb').read()
	if kodi_version>18.99: m3u_text = m3u_text.decode('utf8')
	pDialog = DIALOG_PROGRESS()
	pDialog.create('جلب ملفات ـIPTV جديدة','')
	m3u_text = m3u_text.replace('"tvg-','" tvg-')
	m3u_text = m3u_text.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	m3u_text = m3u_text.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	m3u_text = m3u_text.replace('group-title=','group=')
	m3u_text = m3u_text.replace('tvg-','').replace('\r','').replace('\n','')
	live_archived_channels,live_epg_channels = [],[]
	PROGRESS_UPDATE(pDialog,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if pDialog.iscanceled(): return
	url = iptvURL_player+'&action=get_series_categories'
	html = OPENURL_CACHED(REGULAR_CACHE,url,'',headers,'','IPTV-CREATE_STREAMS-1st')
	html = escapeUNICODE(html)
	series_groups = re.findall('category_name":"(.*?)"',html,re.DOTALL)
	del html
	for group in series_groups:
		group = group.replace('\/','/')
		if kodi_version<19: group = group.decode('utf8').encode('utf8')
		m3u_text = m3u_text.replace('group="'+group+'"','group="__SERIES__'+group+'"')
	del series_groups
	PROGRESS_UPDATE(pDialog,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if pDialog.iscanceled(): return
	url = iptvURL_player+'&action=get_vod_categories'
	html = OPENURL_CACHED(REGULAR_CACHE,url,'',headers,'','IPTV-CREATE_STREAMS-2nd')
	html = escapeUNICODE(html)
	vod_groups = re.findall('category_name":"(.*?)"',html,re.DOTALL)
	del html
	for group in vod_groups:
		group = group.replace('\/','/')
		if kodi_version<19: group = group.decode('utf8').encode('utf8')
		m3u_text = m3u_text.replace('group="'+group+'"','group="__MOVIES__'+group+'"')
	del vod_groups
	PROGRESS_UPDATE(pDialog,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if pDialog.iscanceled(): return
	url = iptvURL_player+'&action=get_live_streams'
	html = OPENURL_CACHED(REGULAR_CACHE,url,'',headers,'','IPTV-CREATE_STREAMS-3rd')
	html = escapeUNICODE(html)
	live_archived = re.findall('"name":"(.*?)".*?"tv_archive":(.*?),',html,re.DOTALL)
	for name,archived in live_archived:
		if archived=='1': live_archived_channels.append(name)
	del live_archived
	live_epg = re.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',html,re.DOTALL)
	del html
	for name,epg in live_epg:
		if epg!='null': live_epg_channels.append(name)
	del live_epg
	lines = re.findall('INF(.*?)#EXT',m3u_text+'\n#EXT',re.DOTALL)
	MegaByte = 1024*1024
	splits_count = 1+len(m3u_text)//MegaByte//10
	del m3u_text
	m3u_streams_count = len(lines)
	lines2 = SPLIT_BIGLIST(lines,splits_count)
	del lines
	for ii in range(splits_count):
		PROGRESS_UPDATE(pDialog,35+int(5*ii/splits_count),'تقطيع الملف الرئيسي','الجزء رقم:-',str(ii+1)+' / '+str(splits_count))
		if pDialog.iscanceled(): return
		lines_text = str(lines2[ii])
		if kodi_version>18.99: lines_text = lines_text.encode('utf8')
		open(fulliptvfile+'.00'+str(ii),'wb').write(lines_text)
	del lines2,lines_text
	all_ignored_streams,streams_not_sorted,jj = [],[],0
	for ii in range(splits_count):
		if pDialog.iscanceled(): return
		lines_text = open(fulliptvfile+'.00'+str(ii),'rb').read()
		if kodi_version>18.99: lines_text = lines_text.decode('utf8')
		lines = EVAL('list',lines_text)
		del lines_text
		streams,jj,ignored_streams = READ_ALL_IPTV_LINES(lines,live_epg_channels,live_archived_channels,pDialog,m3u_streams_count,jj)
		if pDialog.iscanceled(): return
		if not streams: return
		streams_not_sorted += streams
		os.remove(fulliptvfile+'.00'+str(ii))
		all_ignored_streams += ignored_streams
	del lines,streams
	grouped_streams,ignored_streams = CREATE_IPTV_GROUPED_STREAMS(streams_not_sorted,pDialog,ALL_TYPES)
	if pDialog.iscanceled(): return
	all_ignored_streams += ignored_streams
	del streams_not_sorted,ignored_streams
	types_count = len(ALL_TYPES)
	finalstreams,all_menus,menus_counts,total_menus_count,ii = {},{},{},0,0
	for TYPE in list(grouped_streams.keys()):
		all_groups,streamsbygroup,new_streams = [],{},[]
		grouped_streams_type = grouped_streams[TYPE]
		del grouped_streams[TYPE]
		streams_type_count = len(grouped_streams_type)
		streamsbygroup['__COUNT__'] = [streams_type_count]
		if streams_type_count>0:
			grouplist,contextlist,titlelist,urllist,imglist = zip(*grouped_streams_type)
			new_streams = zip(grouplist,imglist)
			del grouplist,contextlist,titlelist,urllist,imglist
			new_streams = set(new_streams)
			new_streams = list(new_streams)
			new_streams_count = len(new_streams)
			for jj in range(new_streams_count):
				if jj%173==0:
					PROGRESS_UPDATE(pDialog,60+int(15*ii//types_count),'تصنيع الملفات:- الملف رقم',str(ii)+' / '+str(types_count),str(jj+1)+' / '+str(new_streams_count))
					if pDialog.iscanceled(): return
				all_groups.append(new_streams[jj])
				group,img = new_streams[jj]
				streamsbygroup[group] = []
			del new_streams
			all_groups = sorted(all_groups)
		streamsbygroup['__GROUPS__'] = all_groups
		del all_groups
		for group,context,title,url,img in grouped_streams_type:
			streamsbygroup[group].append((context,title,url,img))
		del grouped_streams_type
		finalstreams[TYPE] = streamsbygroup
		del streamsbygroup
		all_menus[TYPE] = list(finalstreams[TYPE].keys())
		menus_counts[TYPE] = len(all_menus[TYPE])
		total_menus_count += menus_counts[TYPE]
		ii += 1
	total_saved = 0
	DELETE_IPTV_FILES(False)
	for TYPE in list(finalstreams.keys()):
		CREATE_IPTV_MENUS(TYPE)
		if pDialog.iscanceled(): return
	ignoredCount = len(all_ignored_streams)
	ii = 0
	for stream in all_ignored_streams:
		PROGRESS_UPDATE(pDialog,95+int(5*ii//ignoredCount),'تخزين المهملة','الفيديو رقم:-',str(ii)+' / '+str(ignoredCount))
		if pDialog.iscanceled(): return
		WRITE_TO_SQL3(iptv1_dbfile,'IPTV_IGNORED',[str(stream)],[''],PERMANENT_CACHE,True)
		ii += 1
	WRITE_TO_SQL3(iptv1_dbfile,'IPTV_IGNORED',['__COUNT__'],[str(ignoredCount)],PERMANENT_CACHE,True)
	WRITE_TO_SQL3(iptv1_dbfile,'IPTV_DUMMY',['__COUNT__'],['0'],PERMANENT_CACHE,True)
	open(dummyiptvfile,'w').write('')
	pDialog.close()
	time.sleep(1)
	countsMessage = COUNTS(False)
	DIALOG_OK('','','رسالة من المبرمج','[COLOR FFFFFF00]'+'تم جلب ملفات ـIPTV جديدة'+'[/COLOR]'+'\n\n'+countsMessage)
	return

def CREATE_IPTV_MENUS(TYPE):
	global pDialog,total_saved,finalstreams,menus_counts,all_menus,total_menus_count
	for jj in range(1+menus_counts[TYPE]//173):
		groups_chunk = all_menus[TYPE][0:173]
		del all_menus[TYPE][0:173]
		columns_list,data_list = [],[]
		for group in groups_chunk:
			columns_list.append(group)
			data_list.append(finalstreams[TYPE][group])
		total_saved += len(data_list)
		PROGRESS_UPDATE(pDialog,75+int(20*total_saved//total_menus_count),'تخزين القوائم','القائمة رقم:-',str(total_saved)+' / '+str(total_menus_count))
		if pDialog.iscanceled(): return
		iptv_dbfile = GET_DBFILE_NAME(TYPE)
		WRITE_TO_SQL3(iptv_dbfile,'IPTV_'+TYPE,columns_list,data_list,PERMANENT_CACHE,True)
	del finalstreams[TYPE],all_menus[TYPE],menus_counts[TYPE]
	return

def COUNTS(showDialogs=True):
	if not isIPTVFiles(showDialogs): return ''
	ignoredCount = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_IGNORED','__COUNT__')[0]
	originalLIVECount = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_LIVE_ORIGINAL_GROUPED','__COUNT__')[0]
	originalVODCount = READ_FROM_SQL3(iptv2_dbfile,'list','IPTV_VOD_ORIGINAL_GROUPED','__COUNT__')[0]
	knownLIVECount = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_LIVE_GROUPED','__COUNT__')[0]
	unknownLIVECount = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_LIVE_UNKNOWN_GROUPED','__COUNT__')[0]
	moviesCount = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_VOD_MOVIES_GROUPED','__COUNT__')[0]
	episodesCount = READ_FROM_SQL3(iptv2_dbfile,'list','IPTV_VOD_SERIES_GROUPED','__COUNT__')[0]
	unknownVODCount = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_VOD_UNKNOWN_GROUPED','__COUNT__')[0]
	groups = READ_FROM_SQL3(iptv2_dbfile,'list','IPTV_VOD_SERIES_GROUPED','__GROUPS__')
	seriesLIST = []
	for group,img in groups:
		seriesName = group.split('__SERIES__')[1]
		seriesLIST.append(seriesName)
	seriesCount = len(seriesLIST)
	total = moviesCount+episodesCount+unknownVODCount+unknownLIVECount+knownLIVECount
	countsMessage = 'قنوات: '+str(knownLIVECount)
	countsMessage += '   .   أفلام: '+str(moviesCount)
	countsMessage += '\nمسلسلات: '+str(seriesCount)
	countsMessage += '   .   حلقات: '+str(episodesCount)
	countsMessage += '\nقنوات مجهولة: '+str(unknownLIVECount)
	countsMessage += '   .   فيدوهات مجهولة: '+str(unknownVODCount)
	countsMessage += '\nمجموع القنوات: '+str(originalLIVECount)
	countsMessage += '   .   مجموع الفيديوهات: '+str(originalVODCount)
	countsMessage += '\n\nمجموع المضافة: '+str(total)
	countsMessage += '   .   مجموع المهملة: '+str(ignoredCount)
	if showDialogs: DIALOG_OK('center','','رسالة من المبرمج',countsMessage)
	logMssage = countsMessage.replace('\n\n','\n')
	LOG_THIS('NOTICE','.   Counts of IPTV videos:-\n'+logMssage)
	return countsMessage

def DELETE_IPTV_FILES(showDialogs=True):
	if showDialogs:
		yes = DIALOG_YESNO('center','','','مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if yes!=1: return
		try: os.remove(fulliptvfile)
		except: pass
	try: os.remove(dummyiptvfile)
	except: pass
	DELETE_FROM_SQL3(iptv1_dbfile,'IPTV_DUMMY')
	DELETE_FROM_SQL3(iptv1_dbfile,'IPTV_IGNORED')
	DELETE_FROM_SQL3(iptv1_dbfile,'IPTV_GROUPS')
	DELETE_FROM_SQL3(iptv1_dbfile,'IPTV_ITEMS')
	DELETE_FROM_SQL3(iptv1_dbfile,'IPTV_SEARCH')
	DELETE_FROM_SQL3(cache_dbfile,'MISC','SECTIONS_IPTV')
	for TYPE in ALL_TYPES:
		iptv_dbfile = GET_DBFILE_NAME(TYPE)
		DELETE_FROM_SQL3(iptv_dbfile,'IPTV_'+TYPE)
	FIX_OR_CREATE_ALL_DATABASES(False)
	if showDialogs: DIALOG_OK('','','رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
	return

def isIPTVFiles(showDialogs=True):
	dummyIPTV = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_DUMMY','__COUNT__')
	if dummyIPTV: return True
	if showDialogs: DIALOG_OK('','','رسالة من المبرمج','انت بحاجة إلى الذهاب إلى قائمة ـIPTV ثم تضغط على "إضافة اشتراك ـIPTV" (وهذا يمكن شراءه من أي شركة ـIPTV) .. أو أنت بحاجة لجلب ملفات ـIPTV جديدة وذلك بالذهاب إلى قائمة ـIPTV ثم تضغط على جلب ملفات ـIPTV')
	return False

def SEARCH(search_org,TYPE='',PAGE=''):
	if not PAGE: PAGE = '1'
	search,options,showdialogs = SEARCH_OPTIONS(search_org)
	if not isIPTVFiles(showdialogs): return
	typeList = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not showdialogs:
		if   '_IPTV-LIVE_' in options: TYPE = typeList[1]
		elif '_IPTV-MOVIES' in options: TYPE = typeList[2]
		elif '_IPTV-SERIES' in options: TYPE = typeList[3]
	else:
		if not search:
			search = OPEN_KEYBOARD()
			if not search: return
		searchTitle = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
		choice = DIALOG_SELECT('أختر البحث المناسب', searchTitle)
		if choice == -1: return
		TYPE = typeList[choice]
	searchLower = search.lower()
	results = READ_FROM_SQL3(iptv1_dbfile,'list','IPTV_SEARCH',[TYPE,searchLower])
	if not results:
		allgroups,alltitles = [],[]
		if not TYPE: choices = [1,2,3,4,5]
		else: choices = [typeList.index(TYPE)]
		for ii in choices:
			iptv_dbfile = GET_DBFILE_NAME(typeList[ii])
			if ii!=3:
				streams = READ_FROM_SQL3(iptv_dbfile,'dict','IPTV_'+typeList[ii])
				del streams['__COUNT__']
				del streams['__GROUPS__']
				del streams['__SEQUENCED_COLUMNS__']
				groups = list(streams.keys())
				for group in groups:
					for context,title,url,img in streams[group]:
						if searchLower in title.lower(): alltitles.append((title,url,img))
					del streams[group]
				del streams
			else: groups = READ_FROM_SQL3(iptv_dbfile,'list','IPTV_'+typeList[ii],'__GROUPS__')
			for group in groups:
				try: group,img = group
				except: img = ''
				if searchLower in group.lower():
					if ii!=3: group2 = group
					else:
						maingroup,subgroup = group.split('__SERIES__')
						if searchLower in maingroup.lower(): group2 = maingroup
						else: group2 = subgroup
					allgroups.append((group,group2,typeList[ii],img))
			del groups
		allgroups = set(allgroups)
		alltitles = set(alltitles)
		allgroups = sorted(allgroups,reverse=False,key=lambda key: key[1])
		alltitles = sorted(alltitles,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(iptv1_dbfile,'IPTV_SEARCH',[TYPE,searchLower],[allgroups,alltitles],PERMANENT_CACHE)
	else: allgroups,alltitles = results
	groups = len(allgroups)
	titles = len(alltitles)
	page = int(PAGE) 
	s1 = max(0,(page-1)*100)
	e1 = max(0,page*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,group2,TYPE2,img in allgroups[s1:e1]:
		addMenuItem('folder',menu_name+group2,TYPE2,234,img,'1',group)
	del allgroups
	for title,url,img in alltitles[s2:e2]:
		videofile = url.split('/')[-1]
		if '.' in videofile and '.m3u8' not in videofile: addMenuItem('video',menu_name+title,url,235,img)
		else: addMenuItem('live',menu_name+title,url,235,img)
	del alltitles
	IPTV_PAGINATION(PAGE,TYPE,239,groups+titles,search+'_NODIALOGS_')
	return

def IPTV_PAGINATION(PAGE,TYPE,mode,total,text):
	if PAGE!='1': addMenuItem('folder',menu_name+'صفحة '+str(1),TYPE,mode,'',str(1),text)
	if not total: total = 0
	pages = int(total/100)+1
	for page in range(2,pages):
		cond1 = (page%10==0 or int(PAGE)-4<page<int(PAGE)+4)
		cond2 = (cond1 and int(PAGE)-40<page<int(PAGE)+40)
		if str(page)!=PAGE and (page%100==0 or cond2):
			addMenuItem('folder',menu_name+'صفحة '+str(page),TYPE,mode,'',str(page),text)
	if str(pages)!=PAGE: addMenuItem('folder',menu_name+'أخر صفحة '+str(pages),TYPE,mode,'',str(pages),text)
	return

def GET_DBFILE_NAME(TYPE):
	if 'SERIES' in TYPE or 'VOD_ORIGINAL' in TYPE: dbfile = iptv2_dbfile
	else: dbfile = iptv1_dbfile
	return dbfile



# -*- coding: utf-8 -*-
import sys
l11111_l1_ = sys.version_info [0] == 2
l1ll_l1_ = 2048
l111_l1_ = 7
def l1l11l_l1_ (l1_l1_):
    global l11l11_l1_
    l1ll11l_l1_ = ord (l1_l1_ [-1])
    l1111_l1_ = l1_l1_ [:-1]
    l1l1_l1_ = l1ll11l_l1_ % len (l1111_l1_)
    l11l_l1_ = l1111_l1_ [:l1l1_l1_] + l1111_l1_ [l1l1_l1_:]
    if l11111_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l1ll_l1_ - (l11ll_l1_ + l1ll11l_l1_) % l111_l1_) for l11ll_l1_, char in enumerate (l11l_l1_)])
    return eval (l11l1l_l1_)
from IMPORTS import *
script_name = l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩᓁ")
menu_name = l1l11l_l1_ (u"ࠨࡡࡆࡑࡈࡥࠧᓂ")
l11lll_l1_ = WEBSITES[script_name][0]
l1llll1_l1_ = [l1l11l_l1_ (u"่ࠩ์็฿ࠠ็ฬไ่๏้ำࠨᓃ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l111l1_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l111ll_l1_(url)
	elif mode==494: results = l1l1lll11_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠪࡋࡊ࡚ࠧᓄ"),l11lll_l1_,l1l11l_l1_ (u"ࠫࠬᓅ"),l1l11l_l1_ (u"ࠬ࠭ᓆ"),l1l11l_l1_ (u"࠭ࠧᓇ"),l1l11l_l1_ (u"ࠧࠨᓈ"),l1l11l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᓉ"))
	html = response.content
	l111llll1_l1_ = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᓊ"),html,re.DOTALL)
	l111llll1_l1_ = l111llll1_l1_[0].strip(l1l11l_l1_ (u"ࠪ࠳ࠬᓋ"))
	l111llll1_l1_ = SERVER(l111llll1_l1_,l1l11l_l1_ (u"ࠫࡺࡸ࡬ࠨᓌ"))
	#addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓍ"),menu_name+l1l11l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᓎ"),l111llll1_l1_,499,l1l11l_l1_ (u"ࠧࠨᓏ"),l1l11l_l1_ (u"ࠨࠩᓐ"),l1l11l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᓑ"))
	#addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᓒ"),script_name+l1l11l_l1_ (u"ࠫࡤࡥ࡟ࠨᓓ")+menu_name+l1l11l_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫᓔ"),l111llll1_l1_,491,l1l11l_l1_ (u"࠭ࠧᓕ"),l1l11l_l1_ (u"ࠧࠨᓖ"),l1l11l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᓗ"))
	#addMenuItem(l1l11l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᓘ"),l1l11l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᓙ"),l1l11l_l1_ (u"ࠫࠬᓚ"),9999)
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡦࡪ࡮ࡷࡩࡷࠦࡁ࡫ࡣࡻ࡭࡫ࡿࡆࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᓛ"),html,re.DOTALL)
	if l1ll1lll1_l1_:
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡫࡯࡬ࡵࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᓜ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title in l1llll1_l1_: continue
			l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡵ࡬ࡥ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪᓝ")+l1111l_l1_+l1l11l_l1_ (u"ࠨ࠰ࡳ࡬ࡵ࠭ᓞ")
			addMenuItem(l1l11l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓟ"),script_name+l1l11l_l1_ (u"ࠪࡣࡤࡥࠧᓠ")+menu_name+title,l1111l_l1_,491)
	addMenuItem(l1l11l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᓡ"),l1l11l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓢ"),l1l11l_l1_ (u"࠭ࠧᓣ"),9999)
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓤ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᓥ")+menu_name+l1l11l_l1_ (u"ࠩฦๅ้อๅࠨᓦ"),l111llll1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵วโๆส้࠲ࡳ࡯ࡷ࡫ࡨࡷ࠲࡬ࡩ࡭࡯ࡨ࠳࡫ࡵࡲࡦ࡫ࡪࡲ࠲࡮ࡤ࠮ษไ่ฬ๋࠭ศฮ้ฬ๎࠳࠲ࠨᓧ"),494,l1l11l_l1_ (u"ࠫࠬᓨ"),l1l11l_l1_ (u"ࠬ࠭ᓩ"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᓪ"))
	addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓫ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᓬ")+menu_name+l1l11l_l1_ (u"่ࠩืู้ไศฬࠪᓭ"),l111llll1_l1_+l1l11l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ๅิๆึ่ฬะ࠯ๆี็ื้อส࠮ษฯ๊อ๏ࠧᓮ"),494,l1l11l_l1_ (u"ࠫࠬᓯ"),l1l11l_l1_ (u"ࠬ࠭ᓰ"),l1l11l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᓱ"))
	addMenuItem(l1l11l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᓲ"),l1l11l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᓳ"),l1l11l_l1_ (u"ࠩࠪᓴ"),9999)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᓵ"),html,re.DOTALL)
	block = l1ll111_l1_[0]
	items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᓶ"),block,re.DOTALL)
	for l1111l_l1_,title in items:
		if l1111l_l1_==l1l11l_l1_ (u"ࠬ࠵ࠧᓷ"): continue
		if l1l11l_l1_ (u"࠭ࡨࡵࡶࡳࠫᓸ") not in l1111l_l1_: l1111l_l1_ = l111llll1_l1_+l1111l_l1_
		if title in l1llll1_l1_: continue
		addMenuItem(l1l11l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓹ"),script_name+l1l11l_l1_ (u"ࠨࡡࡢࡣࠬᓺ")+menu_name+title,l1111l_l1_,491)
	return html
def l1l1lll11_l1_(url):
	#DIALOG_OK(l1l11l_l1_ (u"ࠩࠪᓻ"),l1l11l_l1_ (u"ࠪࠫᓼ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠫࡌࡋࡔࠨᓽ"),url,l1l11l_l1_ (u"ࠬ࠭ᓾ"),l1l11l_l1_ (u"࠭ࠧᓿ"),l1l11l_l1_ (u"ࠧࠨᔀ"),l1l11l_l1_ (u"ࠨࠩᔁ"),l1l11l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᔂ"))
	html = response.content
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦ࡫࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᔃ"),html,re.DOTALL)
	if l111l11l1_l1_:
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᔄ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			if title in l1llll1_l1_: continue
			addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔅ"),menu_name+title,l1111l_l1_,491)
	return
def l111l1_l1_(url,l11l1ll11_l1_=l1l11l_l1_ (u"࠭ࠧᔆ")):
	items = []
	#l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠧࡶࡴ࡯ࠫᔇ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠨࡉࡈࡘࠬᔈ"),url,l1l11l_l1_ (u"ࠩࠪᔉ"),l1l11l_l1_ (u"ࠪࠫᔊ"),l1l11l_l1_ (u"ࠫࠬᔋ"),l1l11l_l1_ (u"ࠬ࠭ᔌ"),l1l11l_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᔍ"))
	html = response.content
	block = l1l11l_l1_ (u"ࠧࠨᔎ")
	if l1l11l_l1_ (u"ࠨ࠰ࡳ࡬ࡵ࠭ᔏ") in url: block = html
	elif l1l11l_l1_ (u"ࠩࡂࡷࡂ࠭ᔐ") in url:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠪࠦࡧࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࠤࡰࡥࡳ࡯ࡦࡦࡵࡷࠦࠬᔑ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᔒ"),block,re.DOTALL)
	else:
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࠦࡲࡧ࡮ࡪࡨࡨࡷࡹࠨࠧᔓ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
	if not block: return
	#if not items: items = re.findall(l1l11l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡢ࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࠤࡥࡳࡽࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᔔ"),block,re.DOTALL)
	l1l1l11_l1_ = []
	l111l11ll_l1_ = [l1l11l_l1_ (u"ࠧๆึส๋ิฯࠧᔕ"),l1l11l_l1_ (u"ࠨใํ่๊࠭ᔖ"),l1l11l_l1_ (u"ࠩส฾๋๐ษࠨᔗ"),l1l11l_l1_ (u"ࠪว฿์๊สࠩᔘ"),l1l11l_l1_ (u"่๊๊ࠫษࠩᔙ"),l1l11l_l1_ (u"ࠬอูๅษ้ࠫᔚ"),l1l11l_l1_ (u"࠭็ะษไࠫᔛ"),l1l11l_l1_ (u"ࠧๆสสีฬฯࠧᔜ"),l1l11l_l1_ (u"ࠨ฻ิฺࠬᔝ"),l1l11l_l1_ (u"่๋ࠩึาว็ࠩᔞ"),l1l11l_l1_ (u"ࠪห้ฮ่ๆࠩᔟ"),l1l11l_l1_ (u"ู๊ࠫัฮ์ฬࠫᔠ")]
	for l1111l_l1_,img,title in items:
		title = unescapeHTML(title)
		l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭ᔡ"),title,re.DOTALL)
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩᔢ"),title,re.DOTALL)
		if not l1ll1ll_l1_ or any(value in title for value in l111l11ll_l1_):
			addMenuItem(l1l11l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᔣ"),menu_name+title,l1111l_l1_,492,img)
		elif l1ll1ll_l1_ and l1l11l_l1_ (u"ࠨฯ็ๆฮ࠭ᔤ") in title:
			title = l1l11l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᔥ") + l1ll1ll_l1_[0]
			if title not in l1l1l11_l1_:
				addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔦ"),menu_name+title,l1111l_l1_,493,img)
				l1l1l11_l1_.append(title)
		else: addMenuItem(l1l11l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔧ"),menu_name+title,l1111l_l1_,493,img)
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᔨ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᔩ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l11l_l1_ (u"ࠧศๆุๅาฯࠠࠨᔪ"),l1l11l_l1_ (u"ࠨࠩᔫ"))
			if title!=l1l11l_l1_ (u"ࠩࠪᔬ"): addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔭ"),menu_name+l1l11l_l1_ (u"ฺࠫ็อสࠢࠪᔮ")+title,l1111l_l1_,491)
	return
def l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᔯ"),url,l1l11l_l1_ (u"࠭ࠧᔰ"),l1l11l_l1_ (u"ࠧࠨᔱ"),l1l11l_l1_ (u"ࠨࠩᔲ"),l1l11l_l1_ (u"ࠩࠪᔳ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᔴ"))
	html = response.content
	url2 = re.findall(l1l11l_l1_ (u"ࠫࠧࡈࡵࡵࡶࡲࡲࡸࡈࡡࡳࡅࡲࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᔵ"),html,re.DOTALL)
	if url2:
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠬࡍࡅࡕࠩᔶ"),url2,l1l11l_l1_ (u"࠭ࠧᔷ"),l1l11l_l1_ (u"ࠧࠨᔸ"),l1l11l_l1_ (u"ࠨࠩᔹ"),l1l11l_l1_ (u"ࠩࠪᔺ"),l1l11l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫᔻ"))
		html = response.content
	img = re.findall(l1l11l_l1_ (u"ࠫࠧ࡯࡭ࡨ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᔼ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l11l_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭ᔽ"))
	l111l11l1_l1_ = re.findall(l1l11l_l1_ (u"࠭ࠢࡧ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᔾ"),html,re.DOTALL)
	l1ll1lll1_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪᔿ"),html,re.DOTALL)
	# l111lll1l_l1_
	if l111l11l1_l1_ and l1l11l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪᕀ") not in url:
		block = l111l11l1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᕁ"),block,re.DOTALL)
		for l1111l_l1_,title in items:
			addMenuItem(l1l11l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕂ"),menu_name+title,l1111l_l1_,493,img)
	# l1l11l1_l1_
	elif l1ll1lll1_l1_:
		block = l1ll1lll1_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨࡠ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࠢࡣࡱࡻࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᕃ"),block,re.DOTALL)
		if items:
			for l1111l_l1_,img,title in items:
				title = title.strip(l1l11l_l1_ (u"ࠬࠦࠧᕄ"))
				addMenuItem(l1l11l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᕅ"),menu_name+title,l1111l_l1_,492,img)
		l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᕆ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items = re.findall(l1l11l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᕇ"),block,re.DOTALL)
			for l1111l_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l11l_l1_ (u"ࠩสฺ่็อสࠢࠪᕈ"),l1l11l_l1_ (u"ࠪࠫᕉ"))
				if title!=l1l11l_l1_ (u"ࠫࠬᕊ"): addMenuItem(l1l11l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕋ"),menu_name+l1l11l_l1_ (u"࠭ีโฯฬࠤࠬᕌ")+title,l1111l_l1_,491)
	return
def PLAY(url):
	url2 = url.strip(l1l11l_l1_ (u"ࠧ࠰ࠩᕍ"))+l1l11l_l1_ (u"ࠨ࠱ࡂࡺ࡮࡫ࡷ࠾࠳ࠪᕎ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᕏ"),url2,l1l11l_l1_ (u"ࠪࠫᕐ"),l1l11l_l1_ (u"ࠫࠬᕑ"),l1l11l_l1_ (u"ࠬ࠭ᕒ"),l1l11l_l1_ (u"࠭ࠧᕓ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᕔ"))
	html = response.content
	l1ll1lll_l1_ = []
	l111llll1_l1_ = SERVER(url,l1l11l_l1_ (u"ࠨࡷࡵࡰࠬᕕ"))
	l1111l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠤࡧࡥࡹࡧ࠺ࠡࠩࡴࡁ࠭࠴ࠪࡀࠫࠩࠦᕖ"),html,re.DOTALL)
	#if not l1111l1l1_l1_: l1111l1l1_l1_ = re.findall(l1l11l_l1_ (u"ࠪࡠ࠭ࡺࡨࡪࡵ࡟࠲࡮ࡪ࡜࠭࠲࡟࠰࠭࠴ࠪࡀࠫ࡟࠭ࠬᕗ"),html,re.DOTALL)
	l1111l1l1_l1_ = l1111l1l1_l1_[0]
	# l1l1ll11l_l1_ l1ll1111_l1_
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕘ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨᕙ"),block,re.DOTALL)
		for l111l1111_l1_,title in items:
			title = title.strip(l1l11l_l1_ (u"࠭ࠠࠨᕚ"))
			l1111l_l1_ = l111llll1_l1_+l1l11l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡵ࡬ࡥ࠱ࡶࡩࡷࡼࡥࡳࡵ࠲ࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪᕛ")+l1111l1l1_l1_+l1l11l_l1_ (u"ࠨࠨ࡬ࡁࠬᕜ")+l111l1111_l1_+l1l11l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᕝ")+title+l1l11l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᕞ")
			l1ll1lll_l1_.append(l1111l_l1_)
	# l1l11ll1l_l1_ l1l1ll11l_l1_ l1111l_l1_
	l1111l_l1_ = re.findall(l1l11l_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧࡗࡪࡸࡶࡦࡴࠥ࠲࠯ࡅࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᕟ"),html,re.DOTALL)
	if l1111l_l1_:
		title = l1l11l_l1_ (u"๋ࠬแืๆࠪᕠ")
		l1111l_l1_ = l1111l_l1_[0]+l1l11l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩᕡ")+title
		l1ll1lll_l1_.append(l1111l_l1_)
	# download l1ll1111_l1_
	#url2 = url.strip(l1l11l_l1_ (u"ࠧ࠰ࠩᕢ"))+l1l11l_l1_ (u"ࠨ࠱ࡂࡨࡴࡽ࡮࡭ࡱࡤࡨࡂ࠷ࠧᕣ")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l11l_l1_ (u"ࠩࡊࡉ࡙࠭ᕤ"),url2,l1l11l_l1_ (u"ࠪࠫᕥ"),l1l11l_l1_ (u"ࠫࠬᕦ"),l1l11l_l1_ (u"ࠬ࠭ᕧ"),l1l11l_l1_ (u"࠭ࠧᕨ"),l1l11l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫᕩ"))
	#html = response.content
	l1ll111_l1_ = re.findall(l1l11l_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᕪ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l11l_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᕫ"),block,re.DOTALL)
		for title,l1111l_l1_ in items:
			title = title.strip(l1l11l_l1_ (u"ࠪࠤࠬᕬ"))
			if l1l11l_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬᕭ") in l1111l_l1_: title2 = l1l11l_l1_ (u"ࠬࡥ࡟ฯษุࠫᕮ")
			else: title2 = l1l11l_l1_ (u"࠭ࠧᕯ")
			l1111l_l1_ = l1111l_l1_+l1l11l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᕰ")+title+l1l11l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᕱ")+title2
			l1ll1lll_l1_.append(l1111l_l1_)
	#selection = DIALOG_SELECT(l1l11l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᕲ"), l1ll1lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll_l1_,script_name,l1l11l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᕳ"),url)
	return
def SEARCH(search,l111llll1_l1_=l1l11l_l1_ (u"ࠫࠬᕴ")):
	if not l111llll1_l1_: l111llll1_l1_ = l11lll_l1_
	search,options,showdialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l11l_l1_ (u"ࠬࠦࠧᕵ"),l1l11l_l1_ (u"࠭ࠫࠨᕶ"))
	url = l111llll1_l1_+l1l11l_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠮ࡱࡪࡳࡃࡸࡃࠧᕷ")+search
	l111l1_l1_(url)
	return
#   search is l1111lll1_l1_ l1111llll_l1_ in l111l1_l1_()
#   https://l1111l1ll_l1_.l1111ll11_l1_-l1111ll1l_l1_.l1111ll1l_l1_/?s=the+l1111l111_l1_
#   https://l1111l1ll_l1_.l1111ll11_l1_-l1111ll1l_l1_.l1111ll1l_l1_/search/the+l1111l111_l1_/
#   https://l1111l1ll_l1_.l1111ll11_l1_-l1111ll1l_l1_.l1111ll1l_l1_/index.l1111l11l_l1_?s=the+l1111l111_l1_
#	https://l1111ll11_l1_-l1111ll1l_l1_.io/index.l1111l11l_l1_?s=the+l1111l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ⣯")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡉࡎࡘࡥࠧ⣰")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส่ฯ฻ๆ๋ใสฮࠬ⣱"),l1l111_l1_ (u"ࠪหฺ๋วยࠢะืฬฮࠧ⣲"),l1l111_l1_ (u"ࠫ฼๊ศศฬࠣหุ้่๒ษิࠫ⣳")]
def l11l1ll_l1_(mode,url,text):
	if   mode==390: l1lll_l1_ = l1l1l11_l1_()
	elif mode==391: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==392: l1lll_l1_ = PLAY(url)
	elif mode==393: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==399: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣴"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⣵"),l1l111_l1_ (u"ࠧࠨ⣶"),399,l1l111_l1_ (u"ࠨࠩ⣷"),l1l111_l1_ (u"ࠩࠪ⣸"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⣹"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⣺"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⣻"),l1l111_l1_ (u"࠭ࠧ⣼"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⣽"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ⣾"),l1l111_l1_ (u"ࠩࠪ⣿"),l1l111_l1_ (u"ࠪࠫ⤀"),l1l111_l1_ (u"ࠫࠬ⤁"),l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⤂"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⤃"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤄"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⤅")+l1lllll_l1_+title,l111l1_l1_,391,l1l111_l1_ (u"ࠩࠪ⤆"),l1l111_l1_ (u"ࠪࠫ⤇"),l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ⤈")+str(seq))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤉"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⤊")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆะอหึอสࠡ฻ื์ฬฬ๊สࠩ⤋"),l111l1_l1_,391,l1l111_l1_ (u"ࠨࠩ⤌"),l1l111_l1_ (u"ࠩࠪ⤍"),l1l111_l1_ (u"ࠪࡶࡦࡴࡤࡰ࡯ࡶࠫ⤎"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⤏"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⤐")+l1lllll_l1_+l1l111_l1_ (u"࠭รฺๆ์ࠤฬ๊รโๆส้ࠥะโ๋์่ห๐࠭⤑"),l111l1_l1_,391,l1l111_l1_ (u"ࠧࠨ⤒"),l1l111_l1_ (u"ࠨࠩ⤓"),l1l111_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡲࡵࡶࡪࡧࡶࠫ⤔"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⤕"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⤖")+l1lllll_l1_+l1l111_l1_ (u"ࠬษูๅ๋ࠣห้๋ำๅี็หฯࠦสใ์ํ้ฬ๑ࠧ⤗"),l111l1_l1_,391,l1l111_l1_ (u"࠭ࠧ⤘"),l1l111_l1_ (u"ࠧࠨ⤙"),l1l111_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡷࡪࡸࡩࡦࡵࠪ⤚"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⤛"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⤜")+l1lllll_l1_+l1l111_l1_ (u"ࠫศ็ไศ็้๊ࠣ๐าสࠩ⤝"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭⤞"),391,l1l111_l1_ (u"࠭ࠧ⤟"),l1l111_l1_ (u"ࠧࠨ⤠"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ⤡"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⤢"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⤣")+l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥๅ๋ิฬࠫ⤤"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹࠧ⤥"),391,l1l111_l1_ (u"࠭ࠧ⤦"),l1l111_l1_ (u"ࠧࠨ⤧"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⤨"))
	block = l1l111_l1_ (u"ࠩࠪ⤩")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡨࡨࡴࡸࠢࠨ⤪"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⤫"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭⤬"),l1l111_l1_ (u"࠭ࠧ⤭"),l1l111_l1_ (u"ࠧࠨ⤮"),l1l111_l1_ (u"ࠨࠩ⤯"),l1l111_l1_ (u"ࠩࠪ⤰"),l1l111_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ⤱"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷ࡫࡬ࡦࡣࡶࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡦࡹࡩࡥࡧࠪ⤲"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⤳"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⤴"),l1l111_l1_ (u"ࠧࠨ⤵"),9999)
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⤶"),block,re.DOTALL)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠩส่ศ฿ไุ๊่ࠢฬํฯสࠩ⤷"):
			if first:
				title = l1l111_l1_ (u"ࠪห้อแๅษ่ࠤࠬ⤸")+title
				first = False
			else: title = l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠࠨ⤹")+title
		if title not in l11lll_l1_:
			if title==l1l111_l1_ (u"ࠬษแๅษ่ࠫ⤺"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤻"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⤼")+l1lllll_l1_+title,l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ⤽"),391,l1l111_l1_ (u"ࠩࠪ⤾"),l1l111_l1_ (u"ࠪࠫ⤿"),l1l111_l1_ (u"ࠫࡦࡲ࡬ࡠ࡯ࡲࡺ࡮࡫ࡳࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ⥀"))
			elif title==l1l111_l1_ (u"๋ࠬำๅี็หฯ࠭⥁"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⥂"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⥃")+l1lllll_l1_+title,l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵࠪ⥄"),391,l1l111_l1_ (u"ࠩࠪ⥅"),l1l111_l1_ (u"ࠪࠫ⥆"),l1l111_l1_ (u"ࠫࡦࡲ࡬ࡠ࡯ࡲࡺ࡮࡫ࡳࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ⥇"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⥈"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⥉")+l1lllll_l1_+title,l1ll1ll_l1_,391)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⥊"),url,l1l111_l1_ (u"ࠨࠩ⥋"),l1l111_l1_ (u"ࠩࠪ⥌"),l1l111_l1_ (u"ࠪࠫ⥍"),l1l111_l1_ (u"ࠫࠬ⥎"),l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⥏"))
	html = response.content
	if type in [l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨ⥐"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡷࡺࡸ࡮࡯ࡸࡵࠪ⥑")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡦࡸࡣࡩ࡫ࡹࡩ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠧ⥒"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif type==l1l111_l1_ (u"ࠩࡤࡰࡱࡥ࡭ࡰࡸ࡬ࡩࡸࡥࡴࡷࡵ࡫ࡳࡼࡹࠧ⥓"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⥔"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif type==l1l111_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⥕"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡺ࡯ࡱ࠯࡬ࡱࡩࡨ࠭࡭࡫ࡶࡸࠥࡺ࡬ࡦࡨࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠣ⥖"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⥗"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡵࡱࡳࡣ࡮ࡳࡤࡣࡡࡶࡩࡷ࡯ࡥࡴࠩ⥘"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠩ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶࠧ⥙"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠤ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ⥚"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ⥛"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ⥜"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⥝"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ⥞"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ⥟"),html,re.DOTALL)
		block = l11llll_l1_[0]
		l1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⥠"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*l1lll1l_l1_)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡵࠪ⥡"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ⥢"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⥣"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ⥤") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ⥥"),l1l111_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭⥦"))
		html = html.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭⥧"),l1l111_l1_ (u"ࠩ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡦࡰࡧࡂࠬ⥨"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ⥩"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==6:
			l1lll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⥪"),block,re.DOTALL)
			l1l1ll1ll_l1_,l1l1lll1_l1_,l1llll_l1_ = zip(*l1lll1l_l1_)
			items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ⥫"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ⥬") in url:
				items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⥭"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ⥮") in url:
				items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⥯"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⥰"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠩ⥱") in title: continue
		if l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࠫ⥲") in title:
			title = re.findall(l1l111_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡩࡷ࡯ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⥳"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⥴")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽ࠩ⥵"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ⥶") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⥷"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⥸") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⥹"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ⥺") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⥻"),l1lllll_l1_+title,l1ll1ll_l1_,393,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ⥼") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⥽"),l1lllll_l1_+title,l1ll1ll_l1_,391,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⥾"),l1lllll_l1_+title,l1ll1ll_l1_,392,l1ll1l_l1_)
	if type not in [l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⥿"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⦀")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⦁"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⦂"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⦃"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ⦄")+title,l1ll1ll_l1_,391,l1l111_l1_ (u"ࠪࠫ⦅"),l1l111_l1_ (u"ࠫࠬ⦆"),type)
	return
def l1ll1l11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ⦇"))
	url = url.replace(server,l111l1_l1_)
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⦈"),url,l1l111_l1_ (u"ࠧࠨ⦉"),l1l111_l1_ (u"ࠨࠩ⦊"),l1l111_l1_ (u"ࠩࠪ⦋"),l1l111_l1_ (u"ࠪࠫ⦌"),l1l111_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⦍"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⦎"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ⦏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⦐"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⦑"),l1lllll_l1_+title,l1ll1ll_l1_,392,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1lllll1111_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⦒"),url,l1l111_l1_ (u"ࠪࠫ⦓"),l1l111_l1_ (u"ࠫࠬ⦔"),l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⦕"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⦖"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵ࠱ࡴࡶࡴࡪࡱࡱ࠱࠶ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡟ࠧࢂ࡜ࠨ࡟ࠫࡷ࡭࡫ࡡࡥࡧࡵࢀࡵࡧࡧࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠬ࡟ࠧࢂ࡜ࠨ࡟ࠪ⦗"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡴࡴࡹࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡷࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡸ࡬ࡨࡤࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⦘"),block,re.DOTALL)
		for type,l1ll11l_l1_,l1lllll111l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵࡅࡡࡤࡶ࡬ࡳࡳࡃࡤࡰࡱࡢࡴࡱࡧࡹࡦࡴࡢࡥ࡯ࡧࡸࠧࡲࡲࡷࡹࡃࠧ⦙")+l1ll11l_l1_+l1l111_l1_ (u"ࠪࠪࡳࡻ࡭ࡦ࠿ࠪ⦚")+l1lllll111l_l1_+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࠫ⦛")+type
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⦜")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⦝")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠨࠩ࡬ࡨࡂࡡࠢࠨ࡟ࡧࡳࡼࡴ࡬ࡰࡣࡧ࡟ࠧ࠭࡝ࠡࡥ࡯ࡥࡸࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀ࡟ࠧ࠭࡝ࡴࡤࡲࡼࡠࠨࠧ࡞ࠩࠪࠫ⦞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࠩࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠ࠲࠯ࡅࡨࡳࡧࡩࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠ࠲࠯ࡅ࡛ࠣࠩࡠࡵࡺࡧ࡬ࡪࡶࡼ࡟ࠧ࠭࡝࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ⦟"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l111l1ll_l1_,l1lllll11l1_l1_ in items:
			if l1l111_l1_ (u"ࠩࡀࠫ⦠") in l1ll1l_l1_:
				host = l1ll1l_l1_.split(l1l111_l1_ (u"ࠪࡁࠬ⦡"))[1]
				title = l1l111l_l1_(host,l1l111_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ⦢"))
			else: title = l1l111_l1_ (u"ࠬ࠭⦣")
			title = l1lllll11l1_l1_+l1l111_l1_ (u"࠭ࠠࠨ⦤")+title
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⦥")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ⦦")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⦧"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ⦨"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ⦩"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⦪"),l1l111_l1_ (u"࠭ࠫࠨ⦫"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⦬")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⦭"))
	return
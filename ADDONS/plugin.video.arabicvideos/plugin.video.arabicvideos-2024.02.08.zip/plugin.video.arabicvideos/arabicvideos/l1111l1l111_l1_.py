# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭嫲")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡗ࡚ࡋࡥࠧ嫳")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ嫴")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嫵"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ嫶"),l1l111_l1_ (u"ࠬ࠭嫷"),l1l111_l1_ (u"࠭ࠧ嫸"),l1l111_l1_ (u"ࠧࠨ嫹"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ嫺"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嫻"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ嫼"),l1l111_l1_ (u"ࠫࠬ嫽"),469,l1l111_l1_ (u"ࠬ࠭嫾"),l1l111_l1_ (u"࠭ࠧ嫿"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ嬀"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭嬁"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嬂"),l1l111_l1_ (u"ࠪࠫ嬃"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳࡥ࡯ࡷ࠰ࡦࡹࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ嬄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ嬅"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ嬆") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩ嬇"): title = l1l111_l1_ (u"ࠨฮา๎ิࠦอๅไสฮࠥะ๊โ์ࠣๅฬ์ࠧ嬈")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬉"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嬊")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬ嬋")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嬌"),url,l1l111_l1_ (u"࠭ࠧ嬍"),l1l111_l1_ (u"ࠧࠨ嬎"),l1l111_l1_ (u"ࠨࠩ嬏"),l1l111_l1_ (u"ࠩࠪ嬐"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭嬑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥ࠯ࡷ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡪࡴࡵࡴࡦࡴࠥࠫ嬒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡶ࡯ࡥࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嬓"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭嬔"),l1l111_l1_ (u"ࠧโ์็้ࠬ嬕"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ嬖"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ嬗"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ嬘"),l1l111_l1_ (u"ࠫ์ีวโࠩ嬙"),l1l111_l1_ (u"๋ࠬศศำสอࠬ嬚"),l1l111_l1_ (u"ู࠭าุࠪ嬛"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ嬜"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ嬝")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ嬞") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭嬟"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嬠"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬ嬡") in title:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ嬢") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嬣"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嬤"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ嬥"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ嬦"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嬧"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ嬨"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠢ嬩"): continue
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嬪") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠨࠩ嬫"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬬"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ嬭")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嬮"),url,l1l111_l1_ (u"ࠬ࠭嬯"),l1l111_l1_ (u"࠭ࠧ嬰"),l1l111_l1_ (u"ࠧࠨ嬱"),l1l111_l1_ (u"ࠨࠩ嬲"),l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ嬳"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ嬴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嬵"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ嬶") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嬷"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嬸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嬹"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ嬺"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠥࠦ嬻"): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嬼") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠬ࠭嬽"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嬾"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭嬿")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ孀"),url,l1l111_l1_ (u"ࠩࠪ孁"),l1l111_l1_ (u"ࠪࠫ孂"),l1l111_l1_ (u"ࠫࠬ孃"),l1l111_l1_ (u"ࠬ࠭孄"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ孅"))
	html = response.content
	l11l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡕࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭孆"),html,re.DOTALL)
	if l11l1l111l_l1_:
		l11l1l111l_l1_ = l11l1l111l_l1_[0]
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭孇") not in l11l1l111l_l1_:
			if l1l111_l1_ (u"ࠩ࠲࠳ࠬ孈") in l11l1l111l_l1_: l11l1l111l_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ孉")+l11l1l111l_l1_
			else: l11l1l111l_l1_ = l111l1_l1_+l11l1l111l_l1_
		l11l1l111l_l1_ = l11l1l111l_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ孊")
		l1llll_l1_.append(l11l1l111l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡨ࠱࠶࠼ࡥࡩ࡫ࡵࡲࡦࠪ࠱࠮ࡄ࠯ࡳ࡮ࡣ࡯ࡰ࠳࠰࠿ࠣࡘ࡬ࡨࡪࡵࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡐ࡭ࡣࡼࠦࠬ孋"),html,re.DOTALL)
	if l11llll_l1_:
		l11l11l11111_l1_,l11l11l1111l_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ孌"),l11l11l11111_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡴࡧࡷ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ孍"),l11l11l1111l_l1_,re.DOTALL)
		l11l111lllll_l1_ = zip(names,l1ll_l1_)
		for name,l11llll11l11_l1_ in l11l111lllll_l1_:
			l11llll11l11_l1_ = l11llll11l11_l1_[2:]
			if PY2: l11llll11l11_l1_ = l11llll11l11_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭孎"))
			l11llll11l11_l1_ = base64.b64decode(l11llll11l11_l1_)
			if PY3: l11llll11l11_l1_ = l11llll11l11_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ孏"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ子"),l11llll11l11_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ孑") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠬ࠵࠯ࠨ孒") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ孓")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ孔")+name+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ孕")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ孖"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"ࠪࠤࠬ字") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ存"),l1l111_l1_ (u"ࠬ࠭孙"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬ孚"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦวๅสะฯࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽๊ࠥวࠡ์฼ู้้ࠦ็ัࠣ฻้ฮࠠฤๅฮี๋ࠥๆࠡๅ็้ฮ่ࠦศฯาอࠥ࠴࠮࠯ࠢํีั๏ࠠศๆหัะูࠦ็ࠢๆ่๊ฯ้ࠠษะำฮࠦแใูࠪ孛"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡴ࠳ࠬ孜")+search+l1l111_l1_ (u"ࠩ࠲ࠫ孝")
	l1lll11_l1_(url)
	return
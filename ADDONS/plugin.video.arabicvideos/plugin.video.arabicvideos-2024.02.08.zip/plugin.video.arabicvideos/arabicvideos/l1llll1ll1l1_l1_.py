# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜ࠧ㯆")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㯇")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠩ࠳ࠫ㯈"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠪ࠵ࠬ㯉"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠫ࠷࠭㯊"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠬ࠹ࠧ㯋"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠴ࠨ㯌"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯍"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ㯎")+l1l111_l1_ (u"ࠩๅ์ฬฬๅࠡใํำ๏๎็ศฬࠣࡑ࠸࡛ࠧ㯏"),l1l111_l1_ (u"ࠪࠫ㯐"),762)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯑"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖࡢࠫ㯒")+l1l111_l1_ (u"࠭โ้ษษ้ࠥ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠬ㯓"),l1l111_l1_ (u"ࠧࠨ㯔"),761)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯕"),l1l111_l1_ (u"ࠩࡢࡘ࡛࠶࡟ࠨ㯖")+l1l111_l1_ (u"ࠪๆ๋๎วห่๊๋่ࠢࠥศไ฼๋ฬࠦวๅลุ่๏ฯࠧ㯗"),l1l111_l1_ (u"ࠫࠬ㯘"),101)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯙"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠷ࡣࠬ㯚")+l1l111_l1_ (u"ࠧใ่๋หฯࠦๅฯฬสีฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㯛"),l1l111_l1_ (u"ࠨࠩ㯜"),106)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㯝"),l1l111_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ㯞")+l1l111_l1_ (u"ࠫ็์่ศฬࠣ฽ึฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ㯟"),l1l111_l1_ (u"ࠬ࠭㯠"),147)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㯡"),l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭㯢")+l1l111_l1_ (u"ࠨไ้์ฬะࠠฤฮ้ฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ㯣"),l1l111_l1_ (u"ࠩࠪ㯤"),148)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㯥"),l1l111_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ㯦")+l1l111_l1_ (u"ࠬࠦࠠใ่สอࠥศ๊ࠡใํ่๊ࠦๅ็่ࠢ์็฿็ๆࠢࠣࠫ㯧"),l1l111_l1_ (u"࠭ࠧ㯨"),28)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㯩"),l1l111_l1_ (u"ࠨࡡࡐࡖࡋࡥࠧ㯪")+l1l111_l1_ (u"ࠩๅ๊ฬฯࠠศๆ่฽ฬืแࠡ็้ࠤ๊๎โฺ้่ࠫ㯫"),l1l111_l1_ (u"ࠪࠫ㯬"),41)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㯭"),l1l111_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ㯮")+l1l111_l1_ (u"࠭โ็ษฬࠤ์๊วࠡ็้ࠤ๊๎โฺࠢหห๋๐สࠨ㯯"),l1l111_l1_ (u"ࠧࠨ㯰"),38)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㯱"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㯲"),l1l111_l1_ (u"ࠪࠫ㯳"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯴"),l1l111_l1_ (u"ࠬࡥࡔࡗ࠳ࡢࠫ㯵")+l1l111_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡ฻ส้ฮ࠭㯶"),l1l111_l1_ (u"ࠧࠨ㯷"),102)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯸"),l1l111_l1_ (u"ࠩࡢࡘ࡛࠸࡟ࠨ㯹")+l1l111_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอࠥิวึหࠪ㯺"),l1l111_l1_ (u"ࠫࠬ㯻"),103)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯼"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠶ࡣࠬ㯽")+l1l111_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ็่ๆำีࠨ㯾"),l1l111_l1_ (u"ࠨࠩ㯿"),104)
	return
def ITEMS(l1llll1lll1_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡘ࡛࠭㰀")+l1llll1lll1_l1_+l1l111_l1_ (u"ࠪࡣࠬ㰁")
	l1ll111llll1_l1_ = l1l11l1l111_l1_(32)
	payload = {l1l111_l1_ (u"ࠫ࡮ࡪࠧ㰂"):l1l111_l1_ (u"ࠬ࠭㰃"),l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㰄"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㰅"):l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㰆"),l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㰇"):l1llll1lll1_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㰈"),l111l1_l1_,payload,l1l111_l1_ (u"ࠫࠬ㰉"),l1l111_l1_ (u"ࠬ࠭㰊"),l1l111_l1_ (u"࠭ࠧ㰋"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ㰌"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨࠪ࡞ࡢࡀࡢࡲ࡝ࡰࡠ࠯ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠩ㰍"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"ࠩࡤࡰࠬ㰎"),l1l111_l1_ (u"ࠪࡅࡱ࠭㰏"))
			start = start.replace(l1l111_l1_ (u"ࠫࡊࡲࠧ㰐"),l1l111_l1_ (u"ࠬࡇ࡬ࠨ㰑"))
			start = start.replace(l1l111_l1_ (u"࠭ࡁࡍࠩ㰒"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㰓"))
			start = start.replace(l1l111_l1_ (u"ࠨࡇࡏࠫ㰔"),l1l111_l1_ (u"ࠩࡄࡰࠬ㰕"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠪࡅࡱ࠳ࠧ㰖"),l1l111_l1_ (u"ࠫࡆࡲࠧ㰗"))
			start = start.replace(l1l111_l1_ (u"ࠬࡇ࡬ࠡࠩ㰘"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㰙"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l11111_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠧࠤࠩ㰚") in source: continue
			if source!=l1l111_l1_ (u"ࠨࡗࡕࡐࠬ㰛"): name = name+l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࠦࠠࠨ㰜")+source+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㰝")
			url = source+l1l111_l1_ (u"ࠫࡀࡁࠧ㰞")+server+l1l111_l1_ (u"ࠬࡁ࠻ࠨ㰟")+l1l1l11111_l1_+l1l111_l1_ (u"࠭࠻࠼ࠩ㰠")+l1llll1lll1_l1_
			addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㰡"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠩ㰢")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㰣"),l1lllll_l1_+l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㰤"),l1l111_l1_ (u"ࠫࠬ㰥"),9999)
	return
def PLAY(id):
	source,server,l1l1l11111_l1_,l1llll1lll1_l1_ = id.split(l1l111_l1_ (u"ࠬࡁ࠻ࠨ㰦"))
	url = l1l111_l1_ (u"࠭ࠧ㰧")
	l1ll111llll1_l1_ = l1l11l1l111_l1_(32)
	if source==l1l111_l1_ (u"ࠧࡖࡔࡏࠫ㰨"): url = l1l1l11111_l1_
	elif source==l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㰩"):
		url = l1l11l1_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㰪")][0]+l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭㰫")+l1l1l11111_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㰬"),url)
		return
	elif source==l1l111_l1_ (u"ࠬࡍࡁࠨ㰭"):
		payload = { l1l111_l1_ (u"࠭ࡩࡥࠩ㰮") : l1l111_l1_ (u"ࠧࠨ㰯"), l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㰰") : l1ll111llll1_l1_ , l1l111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㰱") : l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡈࡃ࠴ࠫ㰲") , l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㰳") : l1l111_l1_ (u"ࠬ࠭㰴") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㰵"),l111l1_l1_,payload,l1l111_l1_ (u"ࠧࠨ㰶"),False,l1l111_l1_ (u"ࠨࠩ㰷"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㰸"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㰹"),l1l111_l1_ (u"ࠫࠬ㰺"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㰻"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㰼"))
			return
		html = response.content
		cookies = response.cookies
		l1ll111l1l11_l1_ = cookies[l1l111_l1_ (u"ࠧࡂࡕࡓ࠲ࡓࡋࡔࡠࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࠫ㰽")]
		url = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㰾")]
		payload = { l1l111_l1_ (u"ࠩ࡬ࡨࠬ㰿") : l1l1l11111_l1_ , l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㱀") : l1ll111llll1_l1_ , l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㱁") : l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠷࠭㱂") , l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㱃") : l1l111_l1_ (u"ࠧࠨ㱄") }
		headers = { l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ㱅") : l1l111_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩࡃࠧ㱆")+l1ll111l1l11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㱇"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠫࠬ㱈"),l1l111_l1_ (u"ࠬ࠭㱉"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ㱊"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㱋"),l1l111_l1_ (u"ࠨࠩ㱌"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㱍"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㱎"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"ࠫࡷ࡫ࡳࡱࠤ࠽ࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄࡳ࠳ࡶ࠺ࠬࠬ࠳࠰࠿ࠪࠤࠪ㱏"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1ll111l11ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠸࠯ࠩ㱐")+server+l1l111_l1_ (u"࠭࠷࠸࠹࠲ࠫ㱑")+l1l1l11111_l1_+l1l111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㱒")+params
		l1ll111l11l1_l1_ = l1ll111l11ll_l1_.replace(l1l111_l1_ (u"ࠨ࠵࠹࠾࠼࠭㱓"),l1l111_l1_ (u"ࠩ࠷࠴࠿࠽ࠧ㱔")).replace(l1l111_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㱕"),l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㱖"))
		l1ll111l1l1l_l1_ = l1ll111l11ll_l1_.replace(l1l111_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ㱗"),l1l111_l1_ (u"࠭࠴࠳࠼࠺ࠫ㱘")).replace(l1l111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㱙"),l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㱚"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"ࠩࡋࡈࠬ㱛"),l1l111_l1_ (u"ࠪࡗࡉ࠷ࠧ㱜"),l1l111_l1_ (u"ࠫࡘࡊ࠲ࠨ㱝")]
		l1llll_l1_ = [l1ll111l11ll_l1_,l1ll111l11l1_l1_,l1ll111l1l1l_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"ࠬࡔࡔࠨ㱞"):
		headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㱟") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㱠") }
		payload = { l1l111_l1_ (u"ࠨ࡫ࡧࠫ㱡") : l1l1l11111_l1_ , l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㱢") : l1ll111llll1_l1_ , l1l111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㱣") : l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡐࡗࠫ㱤") , l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㱥") : l1llll1lll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㱦"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠧࠨ㱧"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㱨"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㱩"),l1l111_l1_ (u"ࠪࠫ㱪"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㱫"),l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㱬"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㱭")]
		url = url.replace(l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ㱮"),l1l111_l1_ (u"ࠨࠢࠪ㱯"))
		url = url.replace(l1l111_l1_ (u"ࠩࠨ࠷ࡉ࠭㱰"),l1l111_l1_ (u"ࠪࡁࠬ㱱"))
		if l1l111_l1_ (u"ࠫࡑ࡫ࡡࡳࡰࠪ㱲") in l1l1l11111_l1_:
			url = url.replace(l1l111_l1_ (u"ࠬࡔࡔࡏࡐ࡬ࡰࡪ࠭㱳"),l1l111_l1_ (u"࠭ࠧ㱴"))
			url = url.replace(l1l111_l1_ (u"ࠧ࡭ࡧࡤࡶࡳ࡯࡮ࡨ࠳ࠪ㱵"),l1l111_l1_ (u"ࠨࡎࡨࡥࡷࡴࡩ࡯ࡩࠪ㱶"))
	elif source==l1l111_l1_ (u"ࠩࡓࡐࠬ㱷"):
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㱸") : l1l1l11111_l1_ , l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㱹") : l1ll111llll1_l1_ , l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㱺") : l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡔࡑ࠭㱻") , l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㱼") : l1llll1lll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㱽"), l111l1_l1_, payload, l1l111_l1_ (u"ࠩࠪ㱾"),False,l1l111_l1_ (u"ࠪࠫ㱿"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭㲀"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㲁"),l1l111_l1_ (u"࠭ࠧ㲂"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㲃"),l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㲄"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㲅")]
		headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㲆"):response.headers[l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㲇")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㲈"),url, l1l111_l1_ (u"࠭ࠧ㲉"),headers , l1l111_l1_ (u"ࠧࠨ㲊"),l1l111_l1_ (u"ࠨࠩ㲋"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫ㲌"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㲍"),l1l111_l1_ (u"ࠫࠬ㲎"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㲏"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㲐"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㲑"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"ࠨࡖࡄࠫ㲒"),l1l111_l1_ (u"ࠩࡉࡑࠬ㲓"),l1l111_l1_ (u"ࠪ࡝࡚࠭㲔"),l1l111_l1_ (u"ࠫ࡜࡙࠱ࠨ㲕"),l1l111_l1_ (u"ࠬ࡝ࡓ࠳ࠩ㲖"),l1l111_l1_ (u"࠭ࡒࡍ࠳ࠪ㲗"),l1l111_l1_ (u"ࠧࡓࡎ࠵ࠫ㲘")]:
		if source==l1l111_l1_ (u"ࠨࡖࡄࠫ㲙"): l1l1l11111_l1_ = id
		headers = { l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㲚") : l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㲛") }
		payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ㲜") : l1l1l11111_l1_ , l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㲝") : l1ll111llll1_l1_ , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㲞") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࠬ㲟")+source , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㲠") : l1llll1lll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㲡"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠪࠫ㲢"),l1l111_l1_ (u"ࠫࠬ㲣"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ㲤"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㲥"),l1l111_l1_ (u"ࠧࠨ㲦"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㲧"),l1l111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㲨"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㲩")]
		if source==l1l111_l1_ (u"ࠫࡋࡓࠧ㲪"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㲫"), url, l1l111_l1_ (u"࠭ࠧ㲬"), l1l111_l1_ (u"ࠧࠨ㲭"), False,l1l111_l1_ (u"ࠨࠩ㲮"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠸ࡶ࡫ࠫ㲯"))
			url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㲰")]
			url = url.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ㲱"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㲲"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㲳"))
	return
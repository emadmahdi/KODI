# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࠪ⯄")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡇࡍࡕࡢࠫ⯅")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll1l1ll1_l1_(text)
	elif mode==542: l1lll_l1_ = l1lll11l111_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯆"),l1l111_l1_ (u"ࠧษฯฮࠤัี๊ะࠩ⯇"),l1l111_l1_ (u"ࠨࠩ⯈"),549)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⯉"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࠣ็้๋วห่ࠢาื์ษࠡ࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⯊"),l1l111_l1_ (u"ࠫࠬ⯋"),9999)
	l1lll1l111l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ⯌"),l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⯍"))
	if l1lll1l111l_l1_:
		l1lll1l111l_l1_ = l1lll1l111l_l1_[l1l111_l1_ (u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨ⯎")]
		for search in reversed(l1lll1l111l_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯏"),search,l1l111_l1_ (u"ࠩࠪ⯐"),549,l1l111_l1_ (u"ࠪࠫ⯑"),l1l111_l1_ (u"ࠫࠬ⯒"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111ll111_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"ࠬ࠭⯓"))
	l1lll111111_l1_(l1111ll111_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⯔"),l1l111_l1_ (u"ฺࠧ็็ࠤอำหࠡฮ่ห฾๐ࠠ࠮ࠢࠪ⯕")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⯖"),542,l1l111_l1_ (u"ࠩࠪ⯗"),l1l111_l1_ (u"ࠪࠫ⯘"),l1111ll111_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⯙"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⯚"),l1l111_l1_ (u"࠭ࠧ⯛"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯜"),l1l111_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅโื็อࠥ࠳ࠠࠨ⯝")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࡲࡴࡪࡴࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⯞"),542,l1l111_l1_ (u"ࠪࠫ⯟"),l1l111_l1_ (u"ࠫࠬ⯠"),l1111ll111_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯡"),l1l111_l1_ (u"࠭ๆหษษะࠥอไษฯฮࠤ๊่ำๆหࠣ࠱ࠥ࠭⯢")+l1111ll111_l1_,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⯣"),542,l1l111_l1_ (u"ࠨࠩ⯤"),l1l111_l1_ (u"ࠩࠪ⯥"),l1111ll111_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯦"),l1l111_l1_ (u"ࠫอำหࠡ็้ๅึีࠠ࠮ࠢࠪ⯧")+l1111ll111_l1_,l1l111_l1_ (u"ࠬ࠭⯨"),541,l1l111_l1_ (u"࠭ࠧ⯩"),l1l111_l1_ (u"ࠧࠨ⯪"),l1111ll111_l1_)
	return
def l1lll111111_l1_(l1lll1lll11_l1_):
	l1lll1llll1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⯫"),l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⯬"),l1lll1lll11_l1_)
	l1lll1lll1l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯭"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⯮"),l1lllll_l1_+l1lll1lll11_l1_)
	l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⯯"),l1lll1lll11_l1_)
	l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⯰"),l1lllll_l1_+l1lll1lll11_l1_)
	old_value = l1lll1llll1_l1_+l1lll1lll1l_l1_
	if old_value: l1lll1lll11_l1_ = l1lllll_l1_+l1lll1lll11_l1_
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⯱"),l1lll1lll11_l1_,old_value,l1lll11ll11_l1_)
	return
def l1lll111l11_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࠩ⯲"),l1l111_l1_ (u"ࠩࠪ⯳"),l1l111_l1_ (u"ࠪࠫ⯴"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⯵"),l1l111_l1_ (u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠡࠢࠩ⯶"))
	if l1llll111l_l1_!=1: return
	l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⯷"))
	l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭⯸"))
	l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧ⯹"))
	l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ⯺"),l1l111_l1_ (u"ࠪࠫ⯻"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⯼"),l1l111_l1_ (u"ࠬะๅࠡส้ะฬำࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ั࠭⯽"))
	return
def l1lll11l111_l1_(l1lll111l1l_l1_,action,l1lll11l1ll_l1_=l1l111_l1_ (u"࠭ࠧ⯾")):
	l1lll11ll1l_l1_,l1lll11lll1_l1_,l1lll1l11l1_l1_,l1ll1lll11l_l1_,l1ll1llll11_l1_,l1ll1lll1ll_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⯿"):
		if action==l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⰀ"): l1lll1l11l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧⰁ"),l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨⰂ"),l1lllll_l1_+l1lll111l1l_l1_)
		elif action==l1l111_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⰃ"): l1lll1l11l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪⰄ"),l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬⰅ"),l1lll111l1l_l1_)
		elif action==l1l111_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ⰶ"): l1lll1l11l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭Ⰷ"),l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨⰈ"),(l1lll11l1ll_l1_,l1lll111l1l_l1_))
	if not l1lll1l11l1_l1_:
		l1lll1l1lll_l1_ = l1l111_l1_ (u"๋ࠪีอࠠศๆหัะฺ๋ࠦำ้ࠣํา่ะࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤࡡࡴ࡜࡯࡞ࡱࠫⰉ")
		l1lll1ll111_l1_ = l1l111_l1_ (u"ࠫ์๊ࠠหำํำࠥอไร่ࠣห้ฮอฬࠢไ๎ࠥาๅ๋฻ࠣห้๋่ศไ฼ࠤ฾์ࠠ࡝ࡰࠣࠦࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠࠨⰊ")+l1lll111l1l_l1_+l1l111_l1_ (u"࡛ࠬࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠣࠢ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้ฮอฬࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠧⰋ")
		if action==l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬⰌ"): message = l1lll1ll111_l1_
		else: message = l1lll1l1lll_l1_+l1lll1ll111_l1_
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨⰍ"),l1l111_l1_ (u"ࠨࠩⰎ"),l1l111_l1_ (u"ࠩࠪⰏ"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ⱀ"),message)
		if l1llll111l_l1_!=1: return
		l1lll1l1l1l_l1_(False,False,False)
		l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⰑ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩⰒ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩⰓ"))
		l1llll111ll_l1_ = 1
		for l1lll11l1ll_l1_ in l1lll1l1111_l1_:
			l1ll1lll11l_l1_[l1lll11l1ll_l1_] = []
			options = l1l111_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬⰔ")
			if l1l111_l1_ (u"ࠨ࠯ࠪⰕ") in l1lll11l1ll_l1_: options = options+l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࠧⰖ")+l1lll11l1ll_l1_+l1l111_l1_ (u"ࠪࡣࠬⰗ")
			l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll111l1_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
			if l1llll111ll_l1_:
				time.sleep(1)
				threads[l1lll11l1ll_l1_] = threading.Thread(target=l1lll11l1l1_l1_,args=(l1lll111l1l_l1_+options,))
				threads[l1lll11l1ll_l1_].start()
			else: l1lll11l1l1_l1_(l1lll111l1l_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1lll11l1ll_l1_),l1l111_l1_ (u"ࠫࠬⰘ"),time=1000)
		if l1llll111ll_l1_:
			time.sleep(2)
			for l1lll11l1ll_l1_ in l1lll1l1111_l1_:
				threads[l1lll11l1ll_l1_].join(10)
			time.sleep(2)
		for l1lll11l1ll_l1_ in l1lll1l1111_l1_:
			l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll111l1_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
			for l1lll111lll_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = l1lll111lll_l1_
				if l1llll111l1_l1_ in name:
					if l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࠫⰙ") in l1lll11l1ll_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩⰚ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬⰛ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭Ⱌ")]: continue
						if l1l111_l1_ (u"ุࠩๅาฯࠧⰝ") not in name:
							if   type==l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨⰞ"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧⰟ")
							elif type==l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⰠ"): l1lll11l1ll_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫⰡ")
							elif type==l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⰢ"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭Ⱓ")
						else:
							if   l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࠧⰤ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭Ⱕ")
							elif l1l111_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫⰦ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪⰧ")
							elif l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭Ⱘ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬⰩ")
					elif l1l111_l1_ (u"ࠨࡏ࠶࡙࠲࠭Ⱚ") in l1lll11l1ll_l1_ and 729>=mode>=710:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫⰫ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰬ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨⰭ")]: continue
						if l1l111_l1_ (u"ࠬ฻แฮหࠪⰮ") not in name:
							if   type==l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫⰯ"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩⰰ")
							elif type==l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⰱ"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭ⰲ")
							elif type==l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰳ"): l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨⰴ")
						else:
							if   l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪⰵ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨⰶ")
							elif l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧⰷ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬⰸ")
							elif l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩⰹ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧⰺ")
					elif l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࠭ⰻ") in l1lll11l1ll_l1_ and 149>=mode>=140:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨⰼ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪⰽ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨⰾ")]: continue
						if l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫⰿ") in name or l1l111_l1_ (u"ࠩ࠽࠾ࠥ࠭ⱀ") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"࡙ࠪࡘࡋࡒࠨⱁ") in name: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧⱂ")
							elif mode==144 and l1l111_l1_ (u"ࠬࡉࡈࡏࡎࠪⱃ") in name: l1lll11l1ll_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩⱄ")
							elif mode==144 and l1l111_l1_ (u"ࠧࡍࡋࡖࡘࠬⱅ") in name: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬⱆ")
							elif mode==143: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪⱇ")
							else: continue
					elif l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࠩⱈ") in l1lll11l1ll_l1_ and 419>=mode>=400:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬⱉ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬⱊ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫⱋ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬⱌ")]: continue
						if   mode in [401,405]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩⱍ")
						elif mode in [402,406]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩⱎ")
						elif mode in [404]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨⱏ")
						elif mode in [415]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨⱐ")
						elif mode in [412,413]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪⱑ")
					elif l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࠭ⱒ") in l1lll11l1ll_l1_ and 39>=mode>=30:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭ⱓ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⱔ")]: continue
						if   mode in [32,39]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨⱕ")
						elif mode in [33,39]: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࠩⱖ")
					elif l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࠫⱗ") in l1lll11l1ll_l1_ and 29>=mode>=20:
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫⱘ")]: continue
						if l1lll111lll_l1_ in l1ll1lll11l_l1_[l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ⱙ")]: continue
						if   l1l111_l1_ (u"ࠧ࠰ࡣࡵ࠲ࠬⱚ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧⱛ")
						elif l1l111_l1_ (u"ࠩ࠲ࡩࡳ࠴ࠧⱜ") in url: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪⱝ")
					l1ll1lll11l_l1_[l1lll11l1ll_l1_].append(l1lll111lll_l1_)
		menuItemsLIST[:] = []
		for l1lll11l1ll_l1_ in list(l1ll1lll11l_l1_.keys()):
			l1ll1llll11_l1_[l1lll11l1ll_l1_] = []
			l1ll1lll1ll_l1_[l1lll11l1ll_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in l1ll1lll11l_l1_[l1lll11l1ll_l1_]:
				l1lll111lll_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_)
				if l1l111_l1_ (u"ฺࠫ็อสࠩⱞ") in name and type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱟ"): l1ll1lll1ll_l1_[l1lll11l1ll_l1_].append(l1lll111lll_l1_)
				else: l1ll1llll11_l1_[l1lll11l1ll_l1_].append(l1lll111lll_l1_)
		l1lll1l1l11_l1_ = [(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⱠ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⱡ"),l1l111_l1_ (u"ࠨࠩⱢ"),157,l1l111_l1_ (u"ࠩࠪⱣ"),l1l111_l1_ (u"ࠪࠫⱤ"),l1l111_l1_ (u"ࠫࠬⱥ"),l1l111_l1_ (u"ࠬ࠭ⱦ"),l1l111_l1_ (u"࠭ࠧⱧ"))]
		for l1lll11l1ll_l1_ in l1lll11llll_l1_:
			if l1lll11l1ll_l1_==l1lll1111ll_l1_[0]: l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⱨ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⱩ"),l1l111_l1_ (u"ࠩࠪⱪ"),157,l1l111_l1_ (u"ࠪࠫⱫ"),l1l111_l1_ (u"ࠫࠬⱬ"),l1l111_l1_ (u"ࠬ࠭Ɑ"),l1l111_l1_ (u"࠭ࠧⱮ"),l1l111_l1_ (u"ࠧࠨⱯ"))]
			elif l1lll11l1ll_l1_==l1lll1lllll_l1_[0]: l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ɒ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⱱ"),l1l111_l1_ (u"ࠪࠫⱲ"),157,l1l111_l1_ (u"ࠫࠬⱳ"),l1l111_l1_ (u"ࠬ࠭ⱴ"),l1l111_l1_ (u"࠭ࠧⱵ"),l1l111_l1_ (u"ࠧࠨⱶ"),l1l111_l1_ (u"ࠨࠩⱷ"))]
			elif l1lll11l1ll_l1_==l1ll1lll1l1_l1_[0]: l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⱸ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⱹ"),l1l111_l1_ (u"ࠫࠬⱺ"),157,l1l111_l1_ (u"ࠬ࠭ⱻ"),l1l111_l1_ (u"࠭ࠧⱼ"),l1l111_l1_ (u"ࠧࠨⱽ"),l1l111_l1_ (u"ࠨࠩⱾ"),l1l111_l1_ (u"ࠩࠪⱿ"))]
			if l1lll11l1ll_l1_ not in l1ll1llll11_l1_.keys(): continue
			if l1ll1llll11_l1_[l1lll11l1ll_l1_]:
				l1ll1llllll_l1_ = TRANSLATE(l1lll11l1ll_l1_)
				l1lll111ll1_l1_ = [(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⲀ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࠥ࠭ⲁ")+l1ll1llllll_l1_+l1l111_l1_ (u"ࠬࠦ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⲃ"),l1l111_l1_ (u"࠭ࠧⲃ"),9999,l1l111_l1_ (u"ࠧࠨⲄ"),l1l111_l1_ (u"ࠨࠩⲅ"),l1l111_l1_ (u"ࠩࠪⲆ"),l1l111_l1_ (u"ࠪࠫⲇ"),l1l111_l1_ (u"ࠫࠬⲈ"))]
				if 0: l1llll11111_l1_ = l1lll111l1l_l1_+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩⲉ")+l1l111_l1_ (u"࠭ศฮอࠪⲊ")+l1l111_l1_ (u"ࠧࠡࠩⲋ")+l1ll1llllll_l1_
				else: l1llll11111_l1_ = l1l111_l1_ (u"ࠨสะฯࠬⲌ")+l1l111_l1_ (u"ࠩࠣࠫⲍ")+l1ll1llllll_l1_+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⲎ")+l1lll111l1l_l1_
				if len(l1ll1llll11_l1_[l1lll11l1ll_l1_])<8: l1lll1l11ll_l1_ = []
				else:
					l1llll1111l_l1_ = l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧⲏ")+l1llll11111_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⲐ")
					l1lll1l11ll_l1_ = [(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲑ"),l1lllll_l1_+l1llll1111l_l1_,l1l111_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭Ⲓ"),542,l1l111_l1_ (u"ࠨࠩⲓ"),l1lll11l1ll_l1_,l1lll111l1l_l1_,l1l111_l1_ (u"ࠩࠪⲔ"),l1l111_l1_ (u"ࠪࠫⲕ"))]
				l1lll1ll1l1_l1_ = l1ll1llll11_l1_[l1lll11l1ll_l1_]+l1ll1lll1ll_l1_[l1lll11l1ll_l1_]
				l1lll11lll1_l1_ += l1lll1l1l11_l1_+l1lll111ll1_l1_+l1lll1ll1l1_l1_[:7]+l1lll1l11ll_l1_
				l1ll1lllll1_l1_ = [(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲖ"),l1lllll_l1_+l1llll11111_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫⲗ"),542,l1l111_l1_ (u"࠭ࠧⲘ"),l1lll11l1ll_l1_,l1lll111l1l_l1_,l1l111_l1_ (u"ࠧࠨⲙ"),l1l111_l1_ (u"ࠨࠩⲚ"))]
				l1lll11ll1l_l1_ += l1lll1l1l11_l1_+l1ll1lllll1_l1_
				l1lll1l1l11_l1_ = []
				l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨⲛ"),(l1lll11l1ll_l1_,l1lll111l1l_l1_),l1lll1ll1l1_l1_,l1lll11ll11_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩⲜ"),l1lll111l1l_l1_,l1lll11lll1_l1_,l1lll11ll11_l1_)
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩⲝ"),l1lll111l1l_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⲞ"),l1lllll_l1_+l1lll111l1l_l1_,l1lll11ll1l_l1_,l1lll11ll11_l1_)
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧⲟ"),l1l111_l1_ (u"ࠧࠨⲠ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⲡ"),l1l111_l1_ (u"ࠩส่อำหࠡษ็ะ๊อู๋ࠢส๊ฯํ้ࠡส้ะฬำࠠ࡝ࡰ࡟ࡲࠥะๅࠡฬัึ๏์ࠠศๆ้ฮฬฬฬࠡใํࠤ่อิࠡษ็ฬึ์วๆฮ่๊ࠣีษࠡอ็หะ๐ๆࠡ์๋้๊ࠥใ๋ࠢอืฯ฽ฺ๊ࠢส่฾๎ฯสࠢศ่๏ํวࠡสา์ู๋ࠦๆๆࠣฬาัࠠอัํำࠬⲢ"))
		if action==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⲣ") and l1lll11ll1l_l1_: l1lll1l11l1_l1_ = l1lll11ll1l_l1_
		else: l1lll1l11l1_l1_ = l1lll11lll1_l1_
	if action!=l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪⲤ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in l1lll1l11l1_l1_:
			if action in [l1l111_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⲥ"),l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬⲦ")] and l1l111_l1_ (u"ࠧึใะอࠬⲧ") in name and type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲨ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_)
	l1lll1l1l1l_l1_(l1l111_l1_ (u"ࠩࠪⲩ"),l1l111_l1_ (u"ࠪࠫⲪ"),l1l111_l1_ (u"ࠫࠬⲫ"))
	return
def l1lll1l1ll1_l1_(l1lll111l1l_l1_=l1l111_l1_ (u"ࠬ࠭Ⲭ")):
	search,options,l11_l1_ = l111ll_l1_(l1lll111l1l_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ⲭ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡪࡧࡲࡤࡪࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫⲮ")+search+l1l111_l1_ (u"ࠨࠢࡠࠫⲯ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll1ll1ll_l1_,l1111ll111_l1_ = search+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭Ⲱ"),l1l111_l1_ (u"ࠪࠫⲱ")
	else: l1lll1ll1ll_l1_,l1111ll111_l1_ = l1l111_l1_ (u"ࠫࠬⲲ"),l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩⲳ")+search
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⲴ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⲵ"),l1l111_l1_ (u"ࠨࠩⲶ"),157)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲷ"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩⲸ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠫอำหࠡࡏ࠶࡙ࠬⲹ")+l1111ll111_l1_,l1l111_l1_ (u"ࠬ࠭Ⲻ"),719,l1l111_l1_ (u"࠭ࠧⲻ"),l1l111_l1_ (u"ࠧࠨⲼ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲽ"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨⲾ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠪฬาัࠠࡊࡒࡗ࡚ࠬⲿ")+l1111ll111_l1_,l1l111_l1_ (u"ࠫࠬⳀ"),239,l1l111_l1_ (u"ࠬ࠭ⳁ"),l1l111_l1_ (u"࠭ࠧⳂ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳃ"),l1l111_l1_ (u"ࠨࡡࡅࡏࡗࡥࠧⳄ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤอ้ัศࠩⳅ")+l1111ll111_l1_,l1l111_l1_ (u"ࠪࠫⳆ"),379,l1l111_l1_ (u"ࠫࠬⳇ"),l1l111_l1_ (u"ࠬ࠭Ⳉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳉ"),l1l111_l1_ (u"ࠧࡠࡍࡏࡅࡤ࠭Ⳋ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ็้ࠦวๅ฻ิฬࠬⳋ")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࠪⳌ"),19,l1l111_l1_ (u"ࠪࠫⳍ"),l1l111_l1_ (u"ࠫࠬⳎ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳏ"),l1l111_l1_ (u"࠭࡟ࡂࡔࡗࡣࠬⳐ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ⳑ")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࠩⳒ"),739,l1l111_l1_ (u"ࠩࠪⳓ"),l1l111_l1_ (u"ࠪࠫⳔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳕ"),l1l111_l1_ (u"ࠬࡥࡋࡓࡄࡢࠫⳖ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦใาส็หฦ࠭ⳗ")+l1111ll111_l1_,l1l111_l1_ (u"ࠧࠨⳘ"),329,l1l111_l1_ (u"ࠨࠩⳙ"),l1l111_l1_ (u"ࠩࠪⳚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳛ"),l1l111_l1_ (u"ࠫࡤࡌࡈ࠲ࡡࠪⳜ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫⳝ")+l1111ll111_l1_,l1l111_l1_ (u"࠭ࠧⳞ"),579,l1l111_l1_ (u"ࠧࠨⳟ"),l1l111_l1_ (u"ࠨࠩⳠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳡ"),l1l111_l1_ (u"ࠪࡣࡐ࡚ࡖࡠࠩⳢ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦใหๅ๋ฮࠥะ๊โ์ࠪⳣ")+l1111ll111_l1_,l1l111_l1_ (u"ࠬ࠭ⳤ"),819,l1l111_l1_ (u"࠭ࠧ⳥"),l1l111_l1_ (u"ࠧࠨ⳦"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⳧"),l1l111_l1_ (u"ࠩࡢࡉࡇ࠷࡟ࠨ⳨")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪ⳩")+l1111ll111_l1_,l1l111_l1_ (u"ࠫࠬ⳪"),779,l1l111_l1_ (u"ࠬ࠭Ⳬ"),l1l111_l1_ (u"࠭ࠧⳬ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳭ"),l1l111_l1_ (u"ࠨࡡࡈࡆ࠷ࡥࠧⳮ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠳ࠩ⳯")+l1111ll111_l1_,l1l111_l1_ (u"ࠪࠫ⳰"),789,l1l111_l1_ (u"ࠫࠬ⳱"),l1l111_l1_ (u"ࠬ࠭Ⳳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳳ"),l1l111_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭⳴")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࠣฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫ⳵")+l1111ll111_l1_+l1l111_l1_ (u"ࠩࠣࠤࠬ⳶"),l1l111_l1_ (u"ࠪࠫ⳷"),29,l1l111_l1_ (u"ࠫࠬ⳸"),l1l111_l1_ (u"ࠬ࠭⳹"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⳺"),l1l111_l1_ (u"ࠧࡠࡃࡎࡓࡤ࠭⳻")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩ⳼")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࠪ⳽"),79,l1l111_l1_ (u"ࠪࠫ⳾"),l1l111_l1_ (u"ࠫࠬ⳿"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴀ"),l1l111_l1_ (u"࠭࡟ࡂࡍ࡚ࡣࠬⴁ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨⴂ")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࠩⴃ"),249,l1l111_l1_ (u"ࠩࠪⴄ"),l1l111_l1_ (u"ࠪࠫⴅ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴆ"),l1l111_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫⴇ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧⴈ")+l1111ll111_l1_,l1l111_l1_ (u"ࠧࠨⴉ"),49,l1l111_l1_ (u"ࠨࠩⴊ"),l1l111_l1_ (u"ࠩࠪⴋ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴌ"),l1l111_l1_ (u"ࠫࡤ࡙ࡈࡎࡡࠪⴍ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไࠤ๊อใิࠩⴎ")+l1111ll111_l1_,l1l111_l1_ (u"࠭ࠧⴏ"),59,l1l111_l1_ (u"ࠧࠨⴐ"),l1l111_l1_ (u"ࠨࠩⴑ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⴒ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⴓ"),l1l111_l1_ (u"ࠫࠬⴔ"),157)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴕ"),l1l111_l1_ (u"࠭࡟ࡇࡌࡖࡣࠬⴖ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡสะฯ๋่ࠥใ฻ࠣๅัืࠠี๊ࠪⴗ")+l1111ll111_l1_+l1l111_l1_ (u"ࠨࠢࠪⴘ"),l1l111_l1_ (u"ࠩࠪⴙ"),399,l1l111_l1_ (u"ࠪࠫⴚ"),l1l111_l1_ (u"ࠫࠬⴛ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴜ"),l1l111_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬⴝ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫⴞ")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࠩⴟ"),469,l1l111_l1_ (u"ࠩࠪⴠ"),l1l111_l1_ (u"ࠪࠫⴡ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴢ"),l1l111_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫⴣ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๆ๋ำ๏ࠦๆหࠩⴤ")+l1111ll111_l1_,l1l111_l1_ (u"ࠧࠨⴥ"),459,l1l111_l1_ (u"ࠨࠩ⴦"),l1l111_l1_ (u"ࠩࠪⴧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l1l111_l1_ (u"ࠫࡤࡉࡍࡏࡡࠪ⴩")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ์ว้ࠩ⴪")+l1111ll111_l1_,l1l111_l1_ (u"࠭ࠧ⴫"),309,l1l111_l1_ (u"ࠧࠨ⴬"),l1l111_l1_ (u"ࠨࠩⴭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⴮"),l1l111_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ⴯")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾่๋ࠦࠢึ๎๊อࠧⴰ")+l1111ll111_l1_,l1l111_l1_ (u"ࠬ࠭ⴱ"),569,l1l111_l1_ (u"࠭ࠧⴲ"),l1l111_l1_ (u"ࠧࠨⴳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴴ"),l1l111_l1_ (u"ࠩࡢࡗࡍࡔ࡟ࠨⴵ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨⴶ")+l1111ll111_l1_,l1l111_l1_ (u"ࠫࠬⴷ"),589,l1l111_l1_ (u"ࠬ࠭ⴸ"),l1l111_l1_ (u"࠭ࠧⴹ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬⴺ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴻ"),l1l111_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨⴼ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧⴽ")+l1111ll111_l1_,l1l111_l1_ (u"ࠫࠬⴾ"),259,l1l111_l1_ (u"ࠬ࠭ⴿ"),l1l111_l1_ (u"࠭ࠧⵀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵁ"),l1l111_l1_ (u"ࠨࡡࡆࡇࡇࡥࠧⵂ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧⵃ")+l1111ll111_l1_,l1l111_l1_ (u"ࠪࠫⵄ"),829,l1l111_l1_ (u"ࠫࠬⵅ"),l1l111_l1_ (u"ࠬ࠭ⵆ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵇ"),l1l111_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭ⵈ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧⵉ")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࠪⵊ"),119,l1l111_l1_ (u"ࠪࠫⵋ"),l1l111_l1_ (u"ࠫࠬⵌ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪⵍ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵎ"),l1l111_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭ⵏ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧⵐ")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࠪⵑ"),649,l1l111_l1_ (u"ࠪࠫⵒ"),l1l111_l1_ (u"ࠫࠬⵓ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵔ"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠶ࡣࠬⵕ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧⵖ")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࠩⵗ"),799,l1l111_l1_ (u"ࠩࠪⵘ"),l1l111_l1_ (u"ࠪࠫⵙ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⵚ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะฺࠠษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⵛ"),l1l111_l1_ (u"࠭ࠧⵜ"),157)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵝ"),l1l111_l1_ (u"ࠨࡡࡉࡗ࡙ࡥࠧⵞ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆ๎ำหษࠪⵟ")+l1111ll111_l1_,l1l111_l1_ (u"ࠪࠫⵠ"),609,l1l111_l1_ (u"ࠫࠬⵡ"),l1l111_l1_ (u"ࠬ࠭ⵢ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵣ"),l1l111_l1_ (u"ࠧࡠࡈࡅࡏࡤ࠭ⵤ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅอืใสࠩⵥ")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࠪⵦ"),629,l1l111_l1_ (u"ࠪࠫⵧ"),l1l111_l1_ (u"ࠫࠬ⵨"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵩"),l1l111_l1_ (u"࠭࡟࡚ࡓࡗࡣࠬ⵪")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํห็๎สࠨ⵫")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࠩ⵬"),669,l1l111_l1_ (u"ࠩࠪ⵭"),l1l111_l1_ (u"ࠪࠫ⵮"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵯ"),l1l111_l1_ (u"ࠬࡥࡂࡓࡕࡢࠫ⵰")+l1lll1ll1ll_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสิืฯ๐ฬࠨ⵱")+l1111ll111_l1_,l1l111_l1_ (u"ࠧࠨ⵲"),659,l1l111_l1_ (u"ࠨࠩ⵳"),l1l111_l1_ (u"ࠩࠪ⵴"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⵵"),l1l111_l1_ (u"ࠫࡤࡎࡌࡄࡡࠪ⵶")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿่ࠠๆสࠤุ๐ๅศࠩ⵷")+l1111ll111_l1_,l1l111_l1_ (u"࠭ࠧ⵸"),89,l1l111_l1_ (u"ࠧࠨ⵹"),l1l111_l1_ (u"ࠨࠩ⵺"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵻"),l1l111_l1_ (u"ࠪࡣࡉࡘ࠷ࡠࠩ⵼")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨ⵽")+l1111ll111_l1_,l1l111_l1_ (u"ࠬ࠭⵾"),689,l1l111_l1_ (u"⵿࠭ࠧ"),l1l111_l1_ (u"ࠧࠨⶀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶁ"),l1l111_l1_ (u"ࠩࡢࡇࡒࡌ࡟ࠨⶂ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨⶃ")+l1111ll111_l1_,l1l111_l1_ (u"ࠫࠬⶄ"),99,l1l111_l1_ (u"ࠬ࠭ⶅ"),l1l111_l1_ (u"࠭ࠧⶆ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶇ"),l1l111_l1_ (u"ࠨࡡࡆࡑࡑࡥࠧⶈ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧⶉ")+l1111ll111_l1_,l1l111_l1_ (u"ࠪࠫⶊ"),479,l1l111_l1_ (u"ࠫࠬⶋ"),l1l111_l1_ (u"ࠬ࠭ⶌ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶍ"),l1l111_l1_ (u"ࠧࡠࡃࡅࡈࡤ࠭ⶎ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡ฻หำํ࠭ⶏ")+l1111ll111_l1_,l1l111_l1_ (u"ࠩࠪⶐ"),559,l1l111_l1_ (u"ࠪࠫⶑ"),l1l111_l1_ (u"ࠫࠬⶒ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶓ"),l1l111_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬⶔ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫⶕ")+l1111ll111_l1_,l1l111_l1_ (u"ࠨࠩⶖ"),699,l1l111_l1_ (u"ࠩࠪ⶗"),l1l111_l1_ (u"ࠪࠫ⶘"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⶙"),l1l111_l1_ (u"ࠬࡥࡁࡉࡍࡢࠫ⶚")+l1lll1ll1ll_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬ⶛")+l1111ll111_l1_,l1l111_l1_ (u"ࠧࠨ⶜"),619,l1l111_l1_ (u"ࠨࠩ⶝"),l1l111_l1_ (u"ࠩࠪ⶞"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⶟"),l1l111_l1_ (u"ࠫࡤࡋࡂ࠵ࡡࠪⶠ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬⶡ")+l1111ll111_l1_,l1l111_l1_ (u"࠭ࠧⶢ"),809,l1l111_l1_ (u"ࠧࠨⶣ"),l1l111_l1_ (u"ࠨࠩⶤ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶥ"),l1l111_l1_ (u"ࠪࡣࡈࡉࡗࡠࠩⶦ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠢ฼้้࠭⶧")+l1111ll111_l1_,l1l111_l1_ (u"ࠬ࠭ⶨ"),639,l1l111_l1_ (u"࠭ࠧⶩ"),l1l111_l1_ (u"ࠧࠨⶪ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⶫ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⶬ"),l1l111_l1_ (u"ࠪࠫⶭ"),157)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶮ"),l1l111_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ⶯")+l1lll1ll1ll_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠨⶰ")+l1111ll111_l1_,l1l111_l1_ (u"ࠧࠨⶱ"),149,l1l111_l1_ (u"ࠨࠩⶲ"),l1l111_l1_ (u"ࠩࠪⶳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⶴ"),l1l111_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪⶵ")+l1lll1ll1ll_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠪⶶ")+l1111ll111_l1_,l1l111_l1_ (u"࠭ࠧ⶷"),409,l1l111_l1_ (u"ࠧࠨⶸ"),l1l111_l1_ (u"ࠨࠩⶹ"),l1lll1ll_l1_)
	return
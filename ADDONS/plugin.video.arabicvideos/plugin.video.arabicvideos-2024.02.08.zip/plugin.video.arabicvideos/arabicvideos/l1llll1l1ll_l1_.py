# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ⦮")
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⦯"):l1l111_l1_ (u"ࠫࠬ⦰")}
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡆࡉ࠳ࡢࠫ⦱")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ฬ้ษษึࠥอไฤ๊ึ็ฬืࠧ⦲"),l1l111_l1_ (u"ࠧศๆ่ีฬาูศฬࠪ⦳"),l1l111_l1_ (u"ࠨࡹࡺࡩࠬ⦴")]
def l11l1ll_l1_(mode,url,text):
	if   mode==570: l1lll_l1_ = l1l1l11_l1_()
	elif mode==571: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==572: l1lll_l1_ = PLAY(url)
	elif mode==573: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==576: l1lll_l1_ = l1llllll1l_l1_()
	elif mode==579: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⦵"),l1lllll_l1_+l1l111_l1_ (u"่๊ࠪอะศࠢส่๊๎โฺࠢห฻๏วࠧ⦶"),l1l111_l1_ (u"ࠫࠬ⦷"),576)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⦸"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⦹"),l1l111_l1_ (u"ࠧࠨ⦺"),9999)
	l1l11ll_l1_,url,response = l1lllll1l11_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⦻"),l111l1_l1_,l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ⦼"),l1l111_l1_ (u"ࠪๅฬ฻ไࠡว฼่ฬ์๊ࠨ⦽"),l1l111_l1_ (u"ࠫࡩࡻࡢࡣࡧࡧ࠱ࡲࡵࡶࡪࡧࡶࠫ⦾"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⦿"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⧀"),l1l11ll_l1_,579,l1l111_l1_ (u"ࠧࠨ⧁"),l1l111_l1_ (u"ࠨࠩ⧂"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⧃"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⧄"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⧅"),l1l111_l1_ (u"ࠬ࠭⧆"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧇"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ⧈"),l1l11ll_l1_,571,l1l111_l1_ (u"ࠨࠩ⧉"),l1l111_l1_ (u"ࠩࠪ⧊"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⧋"))
	items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࠹ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⧌"),html,re.DOTALL)
	if not items:
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭⧍"),l1l111_l1_ (u"࠭ࠧ⧎"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩ⧏"),l1l111_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦล๋ฮสำࠥ฿ๆ้ษ้ࠤฬ๊ๅ้ไ฼ࠤศ๎ࠠหื่๎๊ࠦวๅ็๋ๆ฾ࠦส฻์ิࠫ⧐"))
		return
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⧑"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⧒")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠫࠬ⧓"),l1l111_l1_ (u"ࠬ࠭⧔"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠱ࠨ⧕"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡨࡲࡺ࠳ࡰࡳ࡫ࡰࡥࡷࡿࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⧖"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࠥ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ⧗"),block,re.DOTALL)
		l1llll1l111_l1_ = [l1l111_l1_ (u"ࠩࠪ⧘"),l1l111_l1_ (u"ࠪวๆ๊วๆ࠼ࠣࠫ⧙"),l1l111_l1_ (u"ู๊ࠫไิๆสฮ࠿ࠦࠧ⧚"),l1l111_l1_ (u"ࠬฮัศ็ฯ࠾ࠥ࠭⧛"),l1l111_l1_ (u"࠭ยิ์๋๎࠿ࠦࠧ⧜"),l1l111_l1_ (u"ࠧฤ่่๎࠿ࠦࠧ⧝")]
		l1l111lll1_l1_ = 0
		for l1llll1lll1_l1_ in l1llll1ll11_l1_:
			if l1l111lll1_l1_>0: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⧞"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⧟"),l1l111_l1_ (u"ࠪࠫ⧠"),9999)
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⧡"),l1llll1lll1_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ⧢"): continue
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ⧣") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				if title==l1l111_l1_ (u"ࠧࠨ⧤"): continue
				if any(value in title.lower() for value in l11lll_l1_): continue
				title = l1llll1l111_l1_[l1l111lll1_l1_]+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⧥"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⧦")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠪࠫ⧧"),l1l111_l1_ (u"ࠫࠬ⧨"),l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠸ࠧ⧩"))
			l1l111lll1_l1_ += 1
	return
def l1llllll1l_l1_():
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ⧪"),l1l111_l1_ (u"ࠧࠨ⧫"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⧬"),l1l111_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอไฤ๊็ࠤอ฽๊ย่๊ࠢࠥอไๆืาีࠥ࠴࠮ࠡสึฬอࠦโ๋ษ่ࠤศ฻อศสࠣห้๋่ใ฻ࠣฬส฼วโหࠣๅา฻้ࠠฬะๆ็ࠦรๆ่ํࠤ฻ี่ࠠฮ๋้ࠥอไษำส้ั่่ࠦฮ๋้ࠥอไใำสู๋ฯฺࠠๆ์ࠤฺ็อศฬࠣห้๋่ใ฻ࠣ࠲࠳่ࠦศๆ๋ๆฯࠦวๅุสส฾๊ࠦั้หࠤๆ๐ࠠๆฯส์้ฯࠠหฮส์ืࠦ็ัษࠣห้็อึ๋ࠢหะฮวหࠢฦ๊ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠๆฮิำ๋ࠥสึใะࠤ้๊ๅ้ษๅ฽ࠥ๎ไศࠢํๆํ๋ࠠษษ็๋ั๎ๅࠡ฻็ํࠥอไๆ๊สๆ฾࠭⧭"))
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠪࠫ⧮")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⧯"),url,l1l111_l1_ (u"ࠬ࠭⧰"),l1l111_l1_ (u"࠭ࠧ⧱"),l1l111_l1_ (u"ࠧࠨ⧲"),l1l111_l1_ (u"ࠨࠩ⧳"),l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⧴"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬࠹ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⧵"),html,re.DOTALL)
	if not l11ll11_l1_: return
	if type==l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⧶"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ⧷"),l1l111_l1_ (u"࠭࠯ࠨ⧸")).replace(l1l111_l1_ (u"ࠧ࡝࡞ࠥࠫ⧹"),l1l111_l1_ (u"ࠨࠤࠪ⧺"))]
	elif type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠵ࠬ⧻"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦࡕ࡯࡭ࡩ࡫ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⧼"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⧽"),block,re.DOTALL)
		l11ll1l11_l1_,l1ll_l1_,l11l11_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠲ࠨ⧾"):
		title,block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⧿"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩ⨀") and len(l11ll11_l1_)>1:
		title = l11ll11_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨁"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠩࠪ⨂"),l1l111_l1_ (u"ࠪࠫ⨃"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠸ࠧ⨄"))
		title = l11ll11_l1_[1][0]
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨅"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"࠭ࠧ⨆"),l1l111_l1_ (u"ࠧࠨ⨇"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠵ࠪ⨈"))
		return
	else:
		title,block = l11ll11_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥ࡬࠶ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⨉"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
		l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠪࡃࡷ࡫ࡳࡪࡼࡨࡁࠬ⨊"))[0]
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧ⨋"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶ࠳ࠬ⨌") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⨍"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠧࠨ⨎"):
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⨏")+l1l1lll_l1_[0][0]
			title = title.strip(l1l111_l1_ (u"ࠩࠣ⠗ࠬ⨐"))
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⨑"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ⨒") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷ࠴࠭⨓") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭ࡨࡪࡰࡧ࡭࠴࠭⨔") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⨕"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨖"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⨗"):
		l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ⨘"),block,re.DOTALL)
		if l111l1lll1_l1_:
			count = l111l1lll1_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭⨙")+count
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨚"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ⨛"),l1ll1ll_l1_,571,l1l111_l1_ (u"ࠧࠨ⨜"),l1l111_l1_ (u"ࠨࠩ⨝"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⨞"))
	elif l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶࠫ⨟") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠦࡨࡲࡡࡴࡵࡀࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠧ⨠"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ⨡"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"࠭ีโฯฬࠤࠬ⨢")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⨣"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠨࠩ⨤"),l1l111_l1_ (u"ࠩࠪ⨥"),l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠸ࠬ⨦"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠫࠬ⨧")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⨨"),url,l1l111_l1_ (u"࠭ࠧ⨩"),l1l111_l1_ (u"ࠧࠨ⨪"),l1l111_l1_ (u"ࠨࠩ⨫"),l1l111_l1_ (u"ࠩࠪ⨬"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࡙ࡅࡂࡕࡒࡒࡘࡥࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⨭"))
	html = response.content
	l111llll1l_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡢࡵࡲࡲࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⨮"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠣࡁࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࠤࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⨯"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ⨰"))
				l111llll1l_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,name,title in items:
					name = unescapeHTML(name)
					if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ⨱") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
					title = name+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ⨲")+title
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⨳"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ⨴"),l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⨵"))
	if type==l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⨶") or not l111llll1l_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡱࡶࡸࡪࡸࡉ࡮ࡩࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⨷"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ⨸")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡴࡆࡲ࡬ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⨹"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⨺"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⨻"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⨼"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l1l1_l1_,l1llll1ll1l_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⨽"),url,l1l111_l1_ (u"࠭ࠧ⨾"),l1l111_l1_ (u"ࠧࠨ⨿"),l1l111_l1_ (u"ࠨࠩ⩀"),l1l111_l1_ (u"ࠩࠪ⩁"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⩂"))
	html = response.content
	l1llll11lll_l1_ = re.findall(l1l111_l1_ (u"ู๊ࠫส้๋ࠣห้๋ิศ้าอ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ⩃"),html,re.DOTALL)
	if l1llll11lll_l1_:
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡢࡩࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⩄"),html,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡘ࡯ࡸࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⩅"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⩆"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡬ࡱ࡬ࡃࠧ⩇"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ⩈"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡹࡸࡥࡢ࡯ࡋࡩࡦࡪࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⩉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠦ࡭ࡸࡥࡧࠢࡀࠤࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ⩊"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬࡩ࡮ࡩࡀࠫ⩋"))[0]
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ⩌"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⩍")+name+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⩎"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡐ࡮ࡴ࡫ࡴࠪ࠱࠮ࡄ࠯ࡢ࡭ࡣࡦ࡯ࡼ࡯࡮ࡥࡱࡺࠫ⩏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⩐"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫ࡯࡭ࡨ࠿ࠪ⩑"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⩒")+name+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⩓"))
	for l1llll1l11l_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll1l11l_l1_.split(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪࠧ⩔"))
		if l1ll1ll_l1_ not in l1llll1l1l1_l1_:
			l1llll1l1l1_l1_.append(l1ll1ll_l1_)
			l1llll1ll1l_l1_.append(l1llll1l11l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1ll1l_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⩕"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ⩖"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ⩗"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭⩘"),l1l111_l1_ (u"ࠬ࠱ࠧ⩙"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡵࡀࠫ⩚")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l11_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⩛"),url,l1l111_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ⩜"),l1l111_l1_ (u"ࠩไหฺ๊ࠠฦ฻็ห๋๐ࠧ⩝"),l1l111_l1_ (u"ࠪࡨࡺࡨࡢࡦࡦ࠰ࡱࡴࡼࡩࡦࡵࠪ⩞"))
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠺࠭⩟"))
	return
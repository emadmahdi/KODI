# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੨") : l1l111_l1_ (u"ࠬ࠭੩") }
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ੪")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡃࡎ࡛ࡤ࠭੫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
proxy = l1l111_l1_ (u"ࠨࠩ੬")
l11lll_l1_ = [l1l111_l1_ (u"ࠩฦ่฾อศࠨ੭"),l1l111_l1_ (u"ࠪห้๋ีศำ฼อࠥอไฮำฬࠫ੮"),l1l111_l1_ (u"ࠫฬ๊โาษ้ࠤฬ๊ใา์่ࠫ੯"),l1l111_l1_ (u"ࠬอไไฬหࠤํࠦวๅษหัฬัࠧੰ"),l1l111_l1_ (u"࠭วๅื๋ีࠥ๎ࠠศๆั่ๆ๐วหࠩੱ"),l1l111_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้อะศ฻ํอࠬੲ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==240: l1lll_l1_ = l1l1l11_l1_()
	elif mode==241: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==242: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==243: l1lll_l1_ = PLAY(url)
	elif mode==244: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬੳ")+text)
	elif mode==245: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩੴ")+text)
	elif mode==246: l1lll_l1_ = l11llll1_l1_(url)
	elif mode==247: l1lll_l1_ = l11l11ll_l1_(url)
	elif mode==248: l1lll_l1_ = l111lll1_l1_()
	elif mode==249: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l111lll1_l1_():
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫੵ"),l1l111_l1_ (u"ࠫࠬ੶"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ੷"),l1l111_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣࠦศ้่ศ็ࠣห้าฯ๋ัࠥࠤๆ๐ࠠษ฻ูࠤฬ๊รฮ์ส๊ࠥ็๊่้ࠢ์฾ࠦๅ็ࠢส่าาศุࠡาࠤฬ๊ศาษ่ะࠥ࠴้้ࠠำหࠥ๐ำษสู้้ࠣไสࠢไ๎ࠥะิ฻์็ࠤฬ๊แ๋ัํ์์อสࠡ࠰๋ࠣีํࠠศๆุ่่๊ษࠡีหฬ์อࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์์๐ࠠหฺ๊ีࠥ๎สฯฬไ๎ࠥฮี้ำฬࠤ฾ฺ่ศศํอࠬ੸"))
	return
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ੹"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ੺"),headers,l1l111_l1_ (u"ࠩࠪ੻"),l1l111_l1_ (u"ࠪࠫ੼"),l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ੽"))
	html = response.content
	l11l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮࡯࡮ࡧ࠰ࡷ࡮ࡺࡥ࠮ࡤࡷࡲ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੾"),html,re.DOTALL)
	if l11l1111_l1_: l11l1111_l1_ = l11l1111_l1_[0]
	else: l11l1111_l1_ = l111l1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ੿"),l11l1111_l1_,l1l111_l1_ (u"ࠧࠨ઀"),headers,l1l111_l1_ (u"ࠨࠩઁ"),l1l111_l1_ (u"ࠩࠪં"),l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫઃ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ઄"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬઅ"),l1l111_l1_ (u"࠭ࠧઆ"),249,l1l111_l1_ (u"ࠧࠨઇ"),l1l111_l1_ (u"ࠨࠩઈ"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ઉ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪઊ"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧઋ"),l111l1_l1_,246)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬઌ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩઍ"),l111l1_l1_,247)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ઎"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪએ"),l1l111_l1_ (u"ࠩࠪઐ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪઑ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭઒")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭ઓ"),l11l1111_l1_,241,l1l111_l1_ (u"࠭ࠧઔ"),l1l111_l1_ (u"ࠧࠨક"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪખ"))
	l111l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵ࡮ࡼ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨગ"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1l1_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪઘ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ઙ")+l1lllll_l1_+l1l111_l1_ (u"ࠬษึ๋ใࠣัิ๐หศࠩચ"),l1ll1ll_l1_,241)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫછ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩજ"),l1l111_l1_ (u"ࠨࠩઝ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡦ࠲࠺ࠠࡥ࠯ࡩࡰࡪࡾࠠࡢ࡮࡬࡫ࡳ࠳ࡩࡵࡧࡰࡷ࠲ࡩࡥ࡯ࡶࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࡫ࡲ࠮࡮࡬ࡲࡰࠦࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩઞ"),html,re.DOTALL)
	for l1ll1ll_l1_,name,block in l11llll_l1_:
		if name in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪટ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ઠ")+l1lllll_l1_+name,l1ll1ll_l1_,241)
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫડ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			title = name+l1l111_l1_ (u"࠭ࠠࠨઢ")+title
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧણ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪત")+l1lllll_l1_+title,l1ll1ll_l1_,241)
	return
def l11llll1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠩࠪથ")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠪࠫદ"),headers,l1l111_l1_ (u"ࠫࠬધ"),l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ન"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾ࡱࡥࡻ࠭઩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧપ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"ࠨู่๋ࠢ็ษࠨફ")
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩબ"),l1lllll_l1_+title,l1ll1ll_l1_,245)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠪࠫભ"): addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩમ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧય"),l1l111_l1_ (u"࠭ࠧર"),9999)
	return html
def l11l11ll_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠧࠨ઱")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩલ"),headers,l1l111_l1_ (u"ࠩࠪળ"),l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ઴"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࡯ࡣࡹࠫવ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬશ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"࠭ࠠๆใ็ฮึฯࠧષ")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧસ"),l1lllll_l1_+title,l1ll1ll_l1_,244)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠨࠩહ"): addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ઺"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ઻"),l1l111_l1_ (u"઼ࠫࠬ"),9999)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭ઽ")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧા"),headers,True,l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪિ"))
	if type==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪી"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡻ࡮ࡶࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡶࡻ࡮ࡶࡥࡳ࠯ࡥࡹࡹࡺ࡯࡯࠯ࡳࡶࡪࡼࠧુ"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡦࡰࡱࡷࡩࡷ࠭ૂ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸࡪࡾࡴ࠮ࡹ࡫࡭ࡹ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨૃ"),block,re.DOTALL)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫૄ"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨૅ") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡼࡹ࠯ࠨ૆") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨે"),l1lllll_l1_+title,l1ll1ll_l1_,242,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫૈ") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩૉ"),l1lllll_l1_+title,l1ll1ll_l1_,243,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠫ࠴࡭ࡡ࡮ࡧࡶ࠳ࠬ૊") not in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫો"),l1lllll_l1_+title,l1ll1ll_l1_,243,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧૌ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽્ࠩ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠨࠨ࡯ࡷࡦࡷࡵࡰ࠽ࠪ૎"): title = l1l111_l1_ (u"ࠩึหอ่ษࠨ૏")
			if title==l1l111_l1_ (u"ࠪࠪࡷࡹࡡࡲࡷࡲ࠿ࠬૐ"): title = l1l111_l1_ (u"้ࠫออใหࠪ૑")
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ૒"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ૓")+title,l1ll1ll_l1_,241)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ૔"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ૕"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ૖"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ૗"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨ૘")+l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭૙"),headers,True,l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ૚"))
	if l1l111_l1_ (u"ࠧ࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࡂࠬ૛") not in html:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡍࡨࡵ࡮ࠨ૜"))
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ૝"),l1lllll_l1_+l1l111_l1_ (u"ࠪีฬฮืࠡษ็ฮูเ๊ๅࠩ૞"),url,243,l1ll1l_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷ࠱࠹࠭૟"),html,re.DOTALL)
		block = l11llll_l1_[0]
		l1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫૠ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in l1l1l1l1_l1_:
			title = title.replace(l1l111_l1_ (u"࠭ࠠࠡࠩૡ"),l1l111_l1_ (u"ࠧࠡࠩૢ"))
			if l1l111_l1_ (u"ࠨษ็ั้่วหࠩૣ") in title or l1l111_l1_ (u"่ࠩ์ฬูๅࠡษัี๎࠭૤") in title: continue
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ૥") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ૦"),l1lllll_l1_+title,l1ll1ll_l1_,242,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ૧"),l1lllll_l1_+title,l1ll1ll_l1_,243,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ૨"),headers,True,l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ૩"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡤࡤࡨ࡬࡫࠭ࡥࡣࡱ࡫ࡪࡸ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ૪"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l111llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ૫"),html,re.DOTALL)
	l1llll_l1_,l1l1lll1_l1_,l1lll1l1_l1_,l11l11l1_l1_ = [],[],[],[]
	if l111llll_l1_:
		l111lll_l1_ = l1l111_l1_ (u"ࠪࡱࡵ࠺ࠧ૬")
		for l11l111l_l1_,l111l1ll_l1_ in l111llll_l1_:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠢࡴࡹࡦࡲࡩࡵࡻࠥࠤ࡮ࡪ࠽ࠣࠩ૭")+l11l111l_l1_+l1l111_l1_ (u"ࠬࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿࠰࡟ࡷ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ૮"),html,re.DOTALL)
			block = l11llll_l1_[0]
			l1lll1l1_l1_.append(block)
			l11l11l1_l1_.append(l111l1ll_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡱࡶࡣ࡯࡭ࡹ࡯ࡥࡴࠪ࠱࠮ࡄ࠯࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭૯"),html,re.DOTALL)
		if not l11llll_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ૰"),l1l111_l1_ (u"ࠨࠩ૱"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૲"),l1l111_l1_ (u"่ࠪฬ๊้ࠦฮาࠤ๊๊แࠡใํำ๏๎ࠠโ์๋ࠣีอࠠศๆิหอ฽ࠧ૳"))
			return
		else:
			block,filename = l11llll_l1_[0]
			l111ll1l_l1_ = [l1l111_l1_ (u"ࠫࡿ࡯ࡰࠨ૴"),l1l111_l1_ (u"ࠬࡸࡡࡳࠩ૵"),l1l111_l1_ (u"࠭ࡴࡹࡶࠪ૶"),l1l111_l1_ (u"ࠧࡱࡦࡩࠫ૷"),l1l111_l1_ (u"ࠨࡪࡷࡱࠬ૸"),l1l111_l1_ (u"ࠩࡷࡥࡷ࠭ૹ"),l1l111_l1_ (u"ࠪ࡭ࡸࡵࠧૺ"),l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭ࠩૻ")]
			l111lll_l1_ = filename.rsplit(l1l111_l1_ (u"ࠬ࠴ࠧૼ"),1)[1].strip(l1l111_l1_ (u"࠭ࠠࠨ૽"))
			if l111lll_l1_ in l111ll1l_l1_:
				l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ૾"),l1l111_l1_ (u"ࠨࠩ૿"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ଀"),l1l111_l1_ (u"ࠪห้๋ไโࠢ็๎ุࠦแ๋ัํ์ࠥ๎ไศุࠢ์ฯ࠭ଁ"))
				return
		l1lll1l1_l1_.append(block)
		l11l11l1_l1_.append(l1l111_l1_ (u"ࠫࠬଂ"))
	for i in range(len(l1lll1l1_l1_)):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩࡤࡱࡱ࠱࠭࠴ࠪࡀࠫࠥࠫଃ"),l1lll1l1_l1_[i],re.DOTALL)
		for l1ll1ll_l1_,l111ll11_l1_ in l1ll_l1_:
			if l1l111_l1_ (u"࠭ࡴࡰࡴࡵࡩࡳࡺࠧ଄") in l111ll11_l1_: continue
			elif l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩଅ") in l111ll11_l1_: type = l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪଆ")
			elif l1l111_l1_ (u"ࠩࡳࡰࡦࡿࠧଇ") in l111ll11_l1_: type = l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩଈ")
			else: type = l1l111_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬଉ")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࠨଊ")+type+l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫଋ")+l11l11l1_l1_[i]+l1l111_l1_ (u"ࠧࡠࡡࡤ࡯ࡼࡧ࡭ࠨଌ")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ଍"),url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࠪ଎"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬଏ"),l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩଐ"),l1l111_l1_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬ଑")]
	if l1l111_l1_ (u"࠭࠿ࠨ଒") in url: url = url.split(l1l111_l1_ (u"ࠧࡀࠩଓ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬଔ"),1)
	if filter==l1l111_l1_ (u"ࠩࠪକ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫଖ"),l1l111_l1_ (u"ࠫࠬଗ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩଘ"))
	if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪଙ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩଚ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪଛ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫଜ")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭ଝ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ଞ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨଟ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨଠ"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫଡ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪଢ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡤࡰࡱ࠭ଣ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪࡃࠬତ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬଥ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧଦ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧଧ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫନ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ଩"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩࡂࠫପ")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪଫ"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬ࠭ବ"),l1lllll1_l1_,241,l1l111_l1_ (u"ࠬ࠭ଭ"),l1l111_l1_ (u"࠭࠱ࠨମ"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧଯ"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨର")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ଱"),l1lllll1_l1_,241,l1l111_l1_ (u"ࠪࠫଲ"),l1l111_l1_ (u"ࠫ࠶࠭ଳ"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ଴"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨଵ"),l1l111_l1_ (u"ࠧࠨଶ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩଷ"),headers,True,l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫସ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡫ࡵࡲ࡮ࠢ࡬ࡨ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪହ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪ଺"),block,re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡂ࠭࠴ࠪࡀࠫ࠿ࠫ଻"),block,re.DOTALL)
		if l1l111_l1_ (u"࠭࠽ࠨ଼") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫଽ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨା")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩି"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪୀ"),l1lllll1_l1_,241,l1l111_l1_ (u"ࠫࠬୁ"),l1l111_l1_ (u"ࠬ࠷ࠧୂ"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ୃ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧୄ"),l1lllll1_l1_,245,l1l111_l1_ (u"ࠨࠩ୅"),l1l111_l1_ (u"ࠩࠪ୆"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫେ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ୈ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ୉")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ୊")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪୋ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬୌ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ୍ࠩ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠥ࠭୎")+name,l1lllll1_l1_,244,l1l111_l1_ (u"ࠫࠬ୏"),l1l111_l1_ (u"ࠬ࠭୐"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ୑") not in value: value = option
			else: value = re.findall(l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୒"),value,re.DOTALL)[0]
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ୓")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ୔")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ୕")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭ୖ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩୗ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠢࠪ୘")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩ୙")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠤࠬ୚")+name
			if type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ୛"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪଡ଼"),l1lllll_l1_+title,url,244,l1l111_l1_ (u"ࠫࠬଢ଼"),l1l111_l1_ (u"ࠬ࠭୞"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪୟ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩୠ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬୡ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠩࡂࠫୢ")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪୣ"),l1lllll_l1_+title,l1llllll_l1_,241,l1l111_l1_ (u"ࠫࠬ୤"),l1l111_l1_ (u"ࠬ࠷ࠧ୥"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭୦"),l1lllll_l1_+title,url,245,l1l111_l1_ (u"ࠧࠨ୧"),l1l111_l1_ (u"ࠨࠩ୨"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫ୩"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬ୪") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭୫"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ୬"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧ୭")
	l1l11lll_l1_ = [l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࠨ୮"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ୯"),l1l111_l1_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩ୰"),l1l111_l1_ (u"ࠪࡽࡪࡧࡲࠨୱ"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭୲"),l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭୳"),l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ୴")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ୵")
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ୶") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ୷"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ୸")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ୹") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ୺"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ୻")+key+l1l111_l1_ (u"ࠧ࠾ࠩ୼")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ୽"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ୾")+key+l1l111_l1_ (u"ࠪࡁࠬ୿")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ஀"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ஁"))
	return l1l1l111_l1_
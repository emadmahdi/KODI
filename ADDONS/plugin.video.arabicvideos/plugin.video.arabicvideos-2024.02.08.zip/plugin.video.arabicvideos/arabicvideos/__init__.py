# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111l1l1l_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡍࡓࡏࡔࠨ撣")
l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ撤"),l1l111_l1_ (u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠬ撥"))
l1lll111lll_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = l1lll111lll_l1_
l1lll11ll1l1_l1_ = int(mode)
l1llll1ll1ll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ撦"))
l1llll1ll1ll_l1_ = l1llll1ll1ll_l1_.replace(ltr,l1l111_l1_ (u"ࠧࠨ撧")).replace(rtl,l1l111_l1_ (u"ࠨࠩ撨"))
if l1lll11ll1l1_l1_==260: message = l1l111_l1_ (u"ࠩࠣࠤࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠ࡜ࠢࠪ撩")+l1l111lll1l_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡍࡲࡨ࡮ࡀࠠ࡜ࠢࠪ撪")+l1l1l111l1l_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ撫")
else:
	l111ll1ll1ll_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ撬"),l1l111_l1_ (u"࠭ࠧ播")).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ撮"),l1l111_l1_ (u"ࠨࠩ撯"))
	l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ撰"),l1l111_l1_ (u"ࠪࠫ撱")).strip(l1l111_l1_ (u"ࠫࠥ࠭撲"))
	l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ撳"),l1l111_l1_ (u"࠭ࠠࠨ撴")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ撵"),l1l111_l1_ (u"ࠨࠢࠪ撶")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ撷"),l1l111_l1_ (u"ࠪࠤࠬ撸"))
	message = l1l111_l1_ (u"ࠫࠥࠦࠠࡍࡣࡥࡩࡱࡀࠠ࡜ࠢࠪ撹")+l1llll1ll1ll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡑࡴࡪࡥ࠻ࠢ࡞ࠤࠬ撺")+mode+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭撻")+l111ll1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ撼")
l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ撽"),l11lllll11_l1_(l1ll1_l1_)+message)
l1lll111l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭撾"))
l111l1l1l1l_l1_ = False if l1lll111l1ll_l1_==l1l111lll1l_l1_ else True
if not l111l1l1l1l_l1_ and l1lll11ll1l1_l1_ in [235,715]:
	l1l1ll11ll11_l1_ = str(l1llllll1l1_l1_[l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撿")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷࠩ擀") if l1lll11ll1l1_l1_==235 else l1l111_l1_ (u"ࠬࡳ࠳ࡶࠩ擁")
	l11ll1l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࠪ擂")+l1ll1_l1_+l1l111_l1_ (u"ࠧ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ擃")+l1l1ll11ll11_l1_)
	l11lll1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࠬ擄")+l1ll1_l1_+l1l111_l1_ (u"ࠩ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬ擅")+l1l1ll11ll11_l1_)
	if l11ll1l1l1_l1_ or l11lll1ll1_l1_:
		url += l1l111_l1_ (u"ࠪࢀࠬ擆")
		if l11ll1l1l1_l1_: url += l1l111_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ擇")+l11ll1l1l1_l1_
		if l11lll1ll1_l1_: url += l1l111_l1_ (u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ擈")+l11lll1ll1_l1_
		url = url.replace(l1l111_l1_ (u"࠭ࡼࠧࠩ擉"),l1l111_l1_ (u"ࠧࡽࠩ擊"))
	l11l11ll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࠬ擋")+l1ll1_l1_+l1l111_l1_ (u"ࠩ࠱ࡷࡪࡸࡶࡦࡴࡢࠫ擌")+l1l1ll11ll11_l1_)
	if l11l11ll11_l1_:
		l111ll1lll11_l1_ = re.findall(l1l111_l1_ (u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭操"),url,re.DOTALL)
		url = url.replace(l111ll1lll11_l1_[0],l11l11ll11_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l1l1l1l1ll1_l1_,l1111l11ll1_l1_,l1lll1l1l111_l1_
	l111l111lll_l1_ = l1l111_l1_ (u"ࠫࠬ擎")
	l1l1l1l1ll1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ擏"))
	try: l1111l11ll1_l1_(l1lll111lll_l1_,l1llll1ll1ll_l1_)
	except Exception as error: l111l111lll_l1_ = traceback.format_exc()
	l1lll1l1l111_l1_(l111l111lll_l1_)
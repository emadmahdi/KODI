# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ䐩")
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䐪"):l1l111_l1_ (u"ࠧࠨ䐫")}
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧ䐬")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭䐭"),l1l111_l1_ (u"ࠪࡻࡼ࡫ࠧ䐮")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ䐯")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ䐰")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐱"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䐲"),l111l1_l1_,369,l1l111_l1_ (u"ࠨࠩ䐳"),l1l111_l1_ (u"ࠩࠪ䐴"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䐵"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐶"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ䐷"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䐸"),364)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐹"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ䐺"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䐻"),365)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䐼"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䐽"),l1l111_l1_ (u"ࠬ࠭䐾"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䐿"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䑀"),l1l111_l1_ (u"ࠨࠩ䑁"),l1l111_l1_ (u"ࠩࠪ䑂"),l1l111_l1_ (u"ࠪࠫ䑃"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䑄"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭䑅"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䑆"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠧࠨ䑇"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑈"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䑉")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䑊"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䑋"),l1l111_l1_ (u"ࠬ࠭䑌"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ䑍"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䑎"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䑐")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䑑"),url,l1l111_l1_ (u"ࠫࠬ䑒"),l1l111_l1_ (u"ࠬ࠭䑓"),l1l111_l1_ (u"࠭ࠧ䑔"),l1l111_l1_ (u"ࠧࠨ䑕"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䑖"))
	html = response.content
	if l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ䑗") in html:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑘"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䑙"),url,361,l1l111_l1_ (u"ࠬ࠭䑚"),l1l111_l1_ (u"࠭ࠧ䑛"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䑜"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ䑝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ䑞"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑟"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1llll1ll111_l1_,type=l1l111_l1_ (u"ࠫࠬ䑠")):
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ䑡") in l1llll1ll111_l1_:
		l1llllll_l1_,url = l1llll1ll111_l1_.split(l1l111_l1_ (u"࠭࠺࠻ࠩ䑢"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䑣"))
		url = server+url
	else: url,l1llllll_l1_ = l1llll1ll111_l1_,l1llll1ll111_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䑤"),url,l1l111_l1_ (u"ࠩࠪ䑥"),l1l111_l1_ (u"ࠪࠫ䑦"),l1l111_l1_ (u"ࠫࠬ䑧"),l1l111_l1_ (u"ࠬ࠭䑨"),l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ䑩"))
	html = response.content
	if type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䑪"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦࠬ䑫"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ䑬"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ䑭"),l1l111_l1_ (u"ࠫ࠴࠭䑮")).replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ䑯"),l1l111_l1_ (u"࠭ࠢࠨ䑰"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡈࡴ࡬ࡨ࠲࠳ࡍࡺࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ䑱"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ䑲"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ䑳"),l1l111_l1_ (u"ࠪࠫ䑴"))
			if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䑵") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑶"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"࠭อๅไฬࠫ䑷") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠫฮๆๅอࠥ࠱࡜ࡥ࠭ࠪ䑸"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䑹") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑺"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䑻"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䑼"):
			l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ䑽"),block,re.DOTALL)
			if l111l1lll1_l1_:
				count = l111l1lll1_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ䑾")+count
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑿"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ䒀"),l1ll1ll_l1_,361,l1l111_l1_ (u"ࠩࠪ䒁"),l1l111_l1_ (u"ࠪࠫ䒂"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䒃"))
		elif type==l1l111_l1_ (u"ࠬ࠭䒄"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䒅"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䒆"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠨืไัฮࠦࠧ䒇")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䒈"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠪࠫ䒉")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䒊"),url,l1l111_l1_ (u"ࠬ࠭䒋"),l1l111_l1_ (u"࠭ࠧ䒌"),l1l111_l1_ (u"ࠧࠨ䒍"),l1l111_l1_ (u"ࠨࠩ䒎"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䒏"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡩࡵࡧࡰࠦࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠪ࠱࠮ࡄ࠯ࠢࠨ䒐"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭䒑"),l1l111_l1_ (u"ࠬࠦࠧ䒒")).strip(l1l111_l1_ (u"࠭࠯ࠨ䒓"))
	if l1l111_l1_ (u"ࠧๆ๊ึ้ࠬ䒔") in name and type==l1l111_l1_ (u"ࠨࠩ䒕"):
		name = name.split(l1l111_l1_ (u"่ࠩ์ุ๋ࠧ䒖"))[0]
		name = name.replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠪ䒗"),l1l111_l1_ (u"ࠫࠬ䒘")).strip(l1l111_l1_ (u"ࠬࠦࠧ䒙"))
	elif l1l111_l1_ (u"࠭อๅไฬࠫ䒚") in name:
		name = name.split(l1l111_l1_ (u"ࠧฮๆๅอࠬ䒛"))[0]
		name = name.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠨ䒜"),l1l111_l1_ (u"ࠩࠪ䒝")).strip(l1l111_l1_ (u"ࠪࠤࠬ䒞"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵ࡬ࡲ࡬ࡲࡥࡴࡧࡦࡸ࡮ࡵ࡮ࠨ䒟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠬ࠭䒠"):
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ䒡"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭䒢") in title: continue
				if l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩ䒣") in title: continue
				title = name+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䒤")+title
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䒥"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"ࠫࠬ䒦"),l1l111_l1_ (u"ࠬ࠭䒧"),l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ䒨"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䒩"),block+l1l111_l1_ (u"ࠨࠨࠩࠫ䒪"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䒫"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ䒬"))
				title = name+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ䒭")+title
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䒮"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䒯"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠧࠡ࠯้ࠣฬ๐ࠠิ์่หࠬ䒰"),l1l111_l1_ (u"ࠨࠩ䒱")).replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠢࠪ䒲"),l1l111_l1_ (u"ࠪࠫ䒳"))
		else: title = l1l111_l1_ (u"๊๊ࠫแࠡษ็ฮูเ๊ๅࠩ䒴")
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䒵"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䒶"),url,l1l111_l1_ (u"ࠧࠨ䒷"),l1l111_l1_ (u"ࠨࠩ䒸"),l1l111_l1_ (u"ࠩࠪ䒹"),l1l111_l1_ (u"ࠪࠫ䒺"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭䒻"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂฬ๊สึ่ํๅࡁ࠴ࠪࡀ࠾ࡤ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䒼"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡋ࡭ࡣࡧࡧࠦࠬ䒽"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ䒾"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䒿") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠩึ๎ึ็ัࠡ็ส๎ู๊ࠥๆษࠪ䓀"): name = l1l111_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ䓁")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䓂")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䓃")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡵࡷ࠱࠲ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䓄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ䓅"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䓆") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ䓇"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䓈")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠬ䓉")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡳࡹࡤ࡫ࡰࡥࠬ䓊")+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䓋")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䓌"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠨࠩ䓍")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ䓎"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ䓏"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭䓐"),l1l111_l1_ (u"ࠬ࠱ࠧ䓑"))
	l1llll_l1_ = [l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ䓒"),l1l111_l1_ (u"ࠧ࠰ࠩ䓓"),l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡴࡧࡵ࡭ࡪࡹࠧ䓔"),l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡣࡱ࡭ࡲ࡫ࠧ䓕"),l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡷࡺࠬ䓖")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠫฬ๊ใๅࠩ䓗"),l1l111_l1_ (u"ࠬอไฤใ็ห๊࠭䓘"),l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠩ䓙"),l1l111_l1_ (u"ࠧศๆส๊๏๋๊๊ࠡࠣห้้ัห๊้ࠫ䓚"),l1l111_l1_ (u"ࠨษ็ฬึอๅอࠢอ่๏็า๋๊้๎ฮ࠭䓛")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ้์฾ࠦวๅ็ฺ่ํฮ࠺ࠨ䓜"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"ࠪࠫ䓝"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䓞"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭䓟"),l1l111_l1_ (u"࠭ࠧ䓠"),False,l1l111_l1_ (u"ࠧࠨ䓡"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䓢"))
		hostname = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䓣")]
		hostname = hostname.strip(l1l111_l1_ (u"ࠪ࠳ࠬ䓤"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭䓥")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1llll1ll111_l1_,filter):
	if l1l111_l1_ (u"ࠬࡅ࠿ࠨ䓦") in l1llll1ll111_l1_: url = l1llll1ll111_l1_.split(l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䓧"))[0]
	else: url = l1llll1ll111_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䓨"),l1l111_l1_ (u"ࠨࠩ䓩"))
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭䓪"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ䓫"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ䓬"),l1l111_l1_ (u"ࠬ࠭䓭")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ䓮"))
	if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ䓯"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䓰") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠩࡀࡁࠬ䓱") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䓲")+category+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ䓳")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䓴")+category+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ䓵")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ䓶"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䓷")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ䓸"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䓹"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䓺")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䓻"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䓼"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨ䓽"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䓾"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪ䓿"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䔀")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1ll111_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔁"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ䔂"),l1111111_l1_,361,l1l111_l1_ (u"࠭ࠧ䔃"),l1l111_l1_ (u"ࠧࠨ䔄"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䔅"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔆"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ䔇")+l11l1l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ䔈"),l1111111_l1_,361,l1l111_l1_ (u"ࠬ࠭䔉"),l1l111_l1_ (u"࠭ࠧ䔊"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䔋"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䔌"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䔍"),l1l111_l1_ (u"ࠪࠫ䔎"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䔏"),url,l1l111_l1_ (u"ࠬ࠭䔐"),l1l111_l1_ (u"࠭ࠧ䔑"),l1l111_l1_ (u"ࠧࠨ䔒"),l1l111_l1_ (u"ࠨࠩ䔓"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䔔"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠪࡠࡡࠨࠧ䔕"),l1l111_l1_ (u"ࠫࠧ࠭䔖")).replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ䔗"),l1l111_l1_ (u"࠭࠯ࠨ䔘"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ䔙"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䔚"),block+l1l111_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䔛"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ䔜") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭䔝"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠬࡃ࠽ࠨ䔞") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䔟"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ䔠")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1ll111_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔡"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩ䔢"),l1111111_l1_,361,l1l111_l1_ (u"ࠪࠫ䔣"),l1l111_l1_ (u"ࠫࠬ䔤"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䔥"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔦"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ䔧"),l1lllll1_l1_,364,l1l111_l1_ (u"ࠨࠩ䔨"),l1l111_l1_ (u"ࠩࠪ䔩"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䔪"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䔫")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ䔬")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䔭")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ䔮")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䔯")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔰"),l1lllll_l1_+name+l1l111_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ䔱"),l1lllll1_l1_,365,l1l111_l1_ (u"ࠫࠬ䔲"),l1l111_l1_ (u"ࠬ࠭䔳"),l1l111l1_l1_+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䔴"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠧࡳࠩ䔵") or value==l1l111_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ䔶"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䔷") in option: continue
			if l1l111_l1_ (u"ࠪห้้ไࠨ䔸") in option: continue
			if l1l111_l1_ (u"ࠫࡳ࠳ࡡࠨ䔹") in value: continue
			if option==l1l111_l1_ (u"ࠬ࠭䔺"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11l11_l1_ = re.findall(l1l111_l1_ (u"࠭࠼࡯ࡣࡰࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡ࡮ࡧࡁࠫ䔻"),option,re.DOTALL)
			if l1ll1l11l11_l1_: l1l11l1ll_l1_ = l1ll1l11l11_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠧ࠻ࠢࠪ䔼")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䔽")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁࠬ䔾")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䔿")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃࠧ䕀")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ䕁")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ䕂"):
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䕃"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"ࠨࠩ䕄"),l1l111_l1_ (u"ࠩࠪ䕅"),l1l1l11l_l1_+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䕆"))
			elif type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䕇") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䕈") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䕉"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䕊")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1llll1ll111_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕋"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"ࠩࠪ䕌"),l1l111_l1_ (u"ࠪࠫ䕍"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䕎"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕏"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"࠭ࠧ䕐"),l1l111_l1_ (u"ࠧࠨ䕑"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ䕒"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ䕓"),l1l111_l1_ (u"ࠪࡲࡦࡺࡩࡰࡰࠪ䕔")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠫࡲࡶࡡࡢࠩ䕕"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ䕖"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ䕗"),l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ䕘"),l1l111_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩ䕙"),l1l111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ䕚"),l1l111_l1_ (u"ࠪࡲࡦࡺࡩࡰࡰࠪ䕛"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭䕜")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䕝") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭䕞"),l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࠨ䕟"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䕠"),l1l111_l1_ (u"ࠩ࠽࠾࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫࠴࠭䕡"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪࡁࡂ࠭䕢"),l1l111_l1_ (u"ࠫ࠴࠭䕣"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬࠬࠦࠨ䕤"),l1l111_l1_ (u"࠭࠯ࠨ䕥"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ䕦"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠨࠩ䕧")
	if l1l111_l1_ (u"ࠩࡀࡁࠬ䕨") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠫ࠭䕩"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂࡃࠧ䕪"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ䕫")
		if l1l111_l1_ (u"࠭ࠥࠨ䕬") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䕭") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ䕮"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭䕯")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䕰") and value!=l1l111_l1_ (u"ࠫ࠵࠭䕱"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䕲")+key+l1l111_l1_ (u"࠭࠽࠾ࠩ䕳")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ䕴"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䕵")+key+l1l111_l1_ (u"ࠩࡀࡁࠬ䕶")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ䕷"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ䕸"))
	return l1l1l111_l1_
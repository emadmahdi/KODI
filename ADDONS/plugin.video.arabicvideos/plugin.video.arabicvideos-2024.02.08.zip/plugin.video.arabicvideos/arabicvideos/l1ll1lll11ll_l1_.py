# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ噘")
headers = l1l111_l1_ (u"࠭ࠧ噙")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭噚")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭噛"),l1l111_l1_ (u"ࠩส่่๊ࠧ噜"),l1l111_l1_ (u"ࠪหๆ๊วๆࠩ噝"),l1l111_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ噞"),l1l111_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ噟")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ噠")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ噡")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll1l11_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ噢"),l111l1_l1_,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ噣"),l1l111_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ噤"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵࠩ噥"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ噦"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭噧"),l1l111_l1_ (u"ࠧࠨ器"),119,l1l111_l1_ (u"ࠨࠩ噩"),l1l111_l1_ (u"ࠩࠪ噪"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ噫"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ噬"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ噭"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭噮"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ噯"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭噰"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ噱"),l1l111_l1_ (u"ࠪࠫ噲"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ噳"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭噴"),l1l11ll_l1_,111,l1l111_l1_ (u"࠭ࠧ噵"),l1l111_l1_ (u"ࠧࠨ噶"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ噷"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠪ噸"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ噹"),l1l111_l1_ (u"ࠫࠬ噺"),l1l111_l1_ (u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧ噻"),l1l111_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส๐ฬศัࠣ฽๋๎ว็ࠢส่๊๎โฺࠢฦ์ࠥะีๆ์่ࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠩ噼"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭噽"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噾"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ噿")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ嚀"),filter)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ嚁"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嚂"),l1l111_l1_ (u"࠭ࠧ嚃"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡴࡲࡴࡩࡵࡷ࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ嚄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嚅"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ嚆"),l1l111_l1_ (u"ࠪࠫ嚇")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ嚈"),l1l111_l1_ (u"ࠬ࠭嚉")).strip(l1l111_l1_ (u"࠭ࠠࠨ嚊"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嚋") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ嚌") in l1ll1ll_l1_: title = l1l111_l1_ (u"้ࠩ๎ฯ็ไไีࠪ嚍")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚎"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嚏")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠬ࠭嚐"),response=l1l111_l1_ (u"࠭ࠧ嚑")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嚒"),url,l1l111_l1_ (u"ࠨࠩ嚓"),headers,l1l111_l1_ (u"ࠩࠪ嚔"),l1l111_l1_ (u"ࠪࠫ嚕"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ嚖"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ嚗"): l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡧ࡭࡫ࡧࡩࡤࡥࡳ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嚘"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ嚙"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ嚚"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ嚛"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ嚜"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ嚝"),l1l111_l1_ (u"้ࠬไ๋สࠪ嚞"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ嚟"),l1l111_l1_ (u"่ࠧัสๅࠬ嚠"),l1l111_l1_ (u"ࠨ็หหึอษࠨ嚡"),l1l111_l1_ (u"ࠩ฼ี฻࠭嚢"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ嚣"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ嚤")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ嚥") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ嚦"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ嚧"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ嚨"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ嚩") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ嚪") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嚫"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬ嚬") in title and l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ嚭") not in url:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭嚮") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嚯"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ嚰") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚱"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭嚲") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嚳") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ嚴")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嚵"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ嚶") in url and l1l111_l1_ (u"ࠩะ่็ฯࠧ嚷") in title:
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嚸"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚹"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ嚺"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭嚻"): items = re.findall(l1l111_l1_ (u"ࠧࠩࡷࡳࡨࡦࡺࡥࡒࡷࡨࡶࡾ࠯࠮ࠫࡁࡁࠬ࠳࠱࠿ࠪ࠾ࠪ嚼"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嚽"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ嚾"):
				title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭嚿"),l1l111_l1_ (u"ࠫࠬ囀")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ囁"),l1l111_l1_ (u"࠭ࠧ囂"))
				if l1l111_l1_ (u"ࠧࡀࠩ囃") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ囄")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩ囅")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囆"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ囇")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠬ࠭囈"),l1l111_l1_ (u"࠭ࠧ囉"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l11ll1lll_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ囊"),url,l1l111_l1_ (u"ࠨࠩ囋"),headers,l1l111_l1_ (u"ࠩࠪ囌"),l1l111_l1_ (u"ࠪࠫ囍"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ囎"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠤࡩ࠳ࡦ࡭ࡧࡻࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ囏"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ囐") in l11llll_l1_[0]: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l111lll1_l1_ in range(2):
		if l11l11ll1lll_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囑"),l111llll1l_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ囒"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ囓"),block,re.DOTALL)
		if l11l11ll1lll_l1_ and len(items)<2:
			l11l11ll1lll_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠪࠤࠬ囔")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹࠧ囕") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡲࡦࡣࡧࡧࡷࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ囖"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ囗"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ囘")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ囙"),url,l1l111_l1_ (u"ࠩࠪ囚"),headers,l1l111_l1_ (u"ࠪࠫ四"),l1l111_l1_ (u"ࠫࠬ囜"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ囝"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡡࡤࡶ࡬ࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ回"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭囟"),block,re.DOTALL)
	l11l11lll111_l1_ = l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ因") in block
	download = l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭囡") in block
	if   l11l11lll111_l1_ and not download: l11l11lll11l_l1_,l11l11ll1ll1_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠪࠫ团")
	elif not l11l11lll111_l1_ and download: l11l11lll11l_l1_,l11l11ll1ll1_l1_ = l1l111_l1_ (u"ࠫࠬ団"),l1ll_l1_[0]
	elif l11l11lll111_l1_ and download: l11l11lll11l_l1_,l11l11ll1ll1_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l11lll11l_l1_,l11l11ll1ll1_l1_ = l1l111_l1_ (u"ࠬ࠭囤"),l1l111_l1_ (u"࠭ࠧ囥")
	if l11l11lll111_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ囦"),l11l11lll11l_l1_,l1l111_l1_ (u"ࠨࠩ囧"),headers,l1l111_l1_ (u"ࠩࠪ囨"),l1l111_l1_ (u"ࠪࠫ囩"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ囪"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲࡥࡵࠢࡶࡩࡷࡼࡥࡳࡵࠫ࠲࠯ࡅࠩࡱ࡮ࡤࡽࡪࡸࠧ囫"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ囬"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞࠲ࠫ园"),l1l111_l1_ (u"ࠨ࠱ࠪ囮"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ囯")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ困")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ囱"),l11l11ll1ll1_l1_,l1l111_l1_ (u"ࠬ࠭囲"),headers,l1l111_l1_ (u"࠭ࠧ図"),l1l111_l1_ (u"ࠧࠨ围"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ囵"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࡬ࡲ࡫ࡵ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠪ囶"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ囷"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ囸")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ囹")+l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ固")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭囻"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ囼"),l1l111_l1_ (u"ࠩ࠮ࠫ国"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧ图")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l11_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ囿"),url,l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ圀"),l1l111_l1_ (u"࠭ิศ้าࠤๆ๎ั๋๊ࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨࠥ࠺ࡵࠨ圁"),l1l111_l1_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠯ࡰࡨࡸࠬ圂"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ圃"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭圄"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ圅"),url,l1l111_l1_ (u"ࠫࠬ圆"),headers,l1l111_l1_ (u"ࠬ࠭圇"),l1l111_l1_ (u"࠭ࠧ圈"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ圉"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣࡧࡺ࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡶ࡬ࡴࡽࡳ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠫ圊"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡸࡴࡩࡧࡴࡦࡓࡸࡩࡷࡿ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺࠧ國"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄ࡜ࡴࠬࠫ࠲࠯ࡅࠩ࡝ࡵ࠭ࡀࠬ圌"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ圍") not in url: url = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ圎")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ圏"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ圐"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ圑"),l1l111_l1_ (u"ࠩ࠲ࡃࠬ園"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ圓"),l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ圔"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ圕"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ圖")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ圗"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ團"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ圙")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ圚"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ圛"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭圜"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧ圝"),l1l111_l1_ (u"ࠧࠨ圞")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ土"))
	if type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ圠"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬ圡") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭圢") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ圣")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ圤")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ圥")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ圦")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ圧"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ在")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭圩"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ圪"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ圫")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ圬"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ圭"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠩࠪ圮"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭圯"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠫࠬ地"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ圱")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭圲"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ圳"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圴"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ圵")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ圶"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ圷"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ圸"),l1l111_l1_ (u"࠭ࠧ圹"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠧไๆࠣࠫ场"),l1l111_l1_ (u"ࠨࠩ圻"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫ圼") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ圽"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ圾")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圿"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ址"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坁"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ坂"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠩࠪ坃"),l1l111_l1_ (u"ࠪࠫ坄"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ坅"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ坆")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ均")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ坈")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ坉")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭坊")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坋"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭坌")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠬ࠭坍"),l1l111_l1_ (u"࠭ࠧ坎"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧ坏"): option = l1l111_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ坐")
			elif value==l1l111_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ坑"): option = l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ坒")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭坓")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ坔")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ坕")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ坖")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ块")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ坘")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠪ࠴ࠬ坙")]
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧ坚")+name
			if type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ坛"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭坜"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠧࠨ坝"),l1l111_l1_ (u"ࠨࠩ坞"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ坟") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬ坠") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ坡"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ坢")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭坣"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坤"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠨࠩ坥"),l1l111_l1_ (u"ࠩࠪ坦"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁࠫ࠭坧"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨ坨"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ坩"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ坪") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ坫"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ坬"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ坭")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ坮")
		if l1l111_l1_ (u"ࠫࠪ࠭坯") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ坰") and value!=l1l111_l1_ (u"࠭࠰ࠨ坱"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ坲")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ坳") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ坴"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ坵")+key+l1l111_l1_ (u"ࠫࡂ࠭坶")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ坷"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ坸")+key+l1l111_l1_ (u"ࠧ࠾ࠩ坹")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ坺"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ坻"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭坼"),l1l111_l1_ (u"ࠫࡂ࠭坽"))
	return l1l1l111_l1_
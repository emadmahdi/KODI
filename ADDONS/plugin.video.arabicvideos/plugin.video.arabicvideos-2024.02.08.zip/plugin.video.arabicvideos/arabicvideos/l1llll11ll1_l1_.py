# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ⩠")
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⩡"):l1l111_l1_ (u"ࠧࠨ⩢")}
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡉࡌ࠷ࡥࠧ⩣")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩࡺࡻࡪ࠭⩤")]
def l11l1ll_l1_(mode,url,text):
	if   mode==590: l1lll_l1_ = l1l1l11_l1_()
	elif mode==591: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==592: l1lll_l1_ = PLAY(url)
	elif mode==593: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==599: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⩥"),l1l11ll_l1_,l1l111_l1_ (u"ࠫࠬ⩦"),l1l111_l1_ (u"ࠬ࠭⩧"),l1l111_l1_ (u"࠭ࠧ⩨"),l1l111_l1_ (u"ࠧࠨ⩩"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⩪"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩫"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⩬"),l1l11ll_l1_,599,l1l111_l1_ (u"ࠫࠬ⩭"),l1l111_l1_ (u"ࠬ࠭⩮"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⩯"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⩰"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⩱"),l1l111_l1_ (u"ࠩࠪ⩲"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⩳"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ⩴"),l1l11ll_l1_,591,l1l111_l1_ (u"ࠬ࠭⩵"),l1l111_l1_ (u"࠭ࠧ⩶"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠳ࠪ⩷"))
	items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⩸"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩹"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⩺")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠫࠬ⩻"),l1l111_l1_ (u"ࠬ࠭⩼"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠱ࠨ⩽"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⩾"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⩿"),l1l111_l1_ (u"ࠩࠪ⪀"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭࡭࡫ࡡࡥࡧࡵ࠱ࡸࡵࡣࡪࡣ࡯ࠫ⪁"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩࠡࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ⪂"),block,re.DOTALL)
		for l1llll1lll1_l1_ in l1llll1ll11_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⪃"),l1llll1lll1_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ⪄") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⪅"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⪆")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠩࠪ⪇"),l1l111_l1_ (u"ࠪࠫ⪈"),l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠷࠭⪉"))
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭⪊")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⪋"),url,l1l111_l1_ (u"ࠧࠨ⪌"),l1l111_l1_ (u"ࠨࠩ⪍"),l1l111_l1_ (u"ࠩࠪ⪎"),l1l111_l1_ (u"ࠪࠫ⪏"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⪐"))
	html = response.content
	l1llll11l1l_l1_ = 0
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡴ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࡮࠴࠿ࠩ⪑"),html,re.DOTALL)
	if l11ll11_l1_: l1l1l1l_l1_ = l11ll11_l1_[0]
	else: l1l1l1l_l1_ = l1l111_l1_ (u"࠭ࠧ⪒")
	if type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠳ࠪ⪓"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡦࡥࡷࡵࡵࡴࡧ࡯ࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠾ࠨ⪔"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡸࡲࡩࡥࡧࡵ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⪕"),block,re.DOTALL)
		l11ll1l11_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠷࠭⪖"):
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩ⪗"),l1l1l1l_l1_,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⪘"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ⪙"),l1l111_l1_ (u"ࠧ࠰ࠩ⪚")).replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ⪛"),l1l111_l1_ (u"ࠩࠥࠫ⪜"))]
	elif type==l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠶ࠬ⪝") and l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⪞") in l1l1l1l_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠿ࠩ⪟"),html,re.DOTALL)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⪠"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ็ํึฮ࠭⪡"),url,591,l1l111_l1_ (u"ࠨࠩ⪢"),l1l111_l1_ (u"ࠩࠪ⪣"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠷࠭⪤"))
		title = l11llll_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪥"),l1lllll_l1_+title,url,591,l1l111_l1_ (u"ࠬ࠭⪦"),l1l111_l1_ (u"࠭ࠧ⪧"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠴ࠩ⪨"))
		return
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡂࠬ⪩"),html,re.DOTALL)
		title,block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀ࡭࠹࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ⪪"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ⪫"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ⪬"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ⪭"),l1l111_l1_ (u"࠭ใๅ์หࠫ⪮"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭⪯"),l1l111_l1_ (u"ࠨ้าหๆ࠭⪰"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ⪱"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ⪲"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ⪳"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ⪴"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭⪵"),l1l111_l1_ (u"ࠧฮๆๅอࠬ⪶")]
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⪷"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ⪸"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⪹") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪺"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠬ࠭⪻"):
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⪼")+l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⪽"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⪾"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⪿"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ⫀"):
		l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ⫁"),block,re.DOTALL)
		if l111l1lll1_l1_:
			count = l111l1lll1_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ⫂")+count
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⫃"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ⫄"),l1ll1ll_l1_,591,l1l111_l1_ (u"ࠨࠩ⫅"),l1l111_l1_ (u"ࠩࠪ⫆"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ⫇"))
	elif l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷࠬ⫈") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⫉"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⫊"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ࠧึใะอࠥ࠭⫋")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⫌"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠩࠪ⫍"),l1l111_l1_ (u"ࠪࠫ⫎"),l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠹࠭⫏"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠬ࠭⫐")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⫑"),url,l1l111_l1_ (u"ࠧࠨ⫒"),l1l111_l1_ (u"ࠨࠩ⫓"),l1l111_l1_ (u"ࠩࠪ⫔"),l1l111_l1_ (u"ࠪࠫ⫕"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⫖"))
	html = response.content
	l111llll1l_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡦࡣࡶࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡣࡶࡳࡳࡹ࠾ࠨ⫗"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ⫘"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ⫙"))
				l111llll1l_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⫚"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ⫛"),l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⫝̸"))
	if type==l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⫝") or not l111llll1l_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡢ࡬ิ࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠤࡁࡀ࠴ࡨ࡫࠿ࠩ⫞"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࠧ⫟")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣ࡯ࡰ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࡭࡮࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࡃ࠭⫠"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⫡"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ⫢"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⫣"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l1l1_l1_,l1llll1ll1l_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⫤"),url,l1l111_l1_ (u"ࠬ࠭⫥"),l1l111_l1_ (u"࠭ࠧ⫦"),l1l111_l1_ (u"ࠧࠨ⫧"),l1l111_l1_ (u"ࠨࠩ⫨"),l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⫩"))
	html = response.content
	l1llll11lll_l1_ = re.findall(l1l111_l1_ (u"ࠪห้฿ๅาࠢ࠽࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩ⫪"),html,re.DOTALL)
	if l1llll11lll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1llll11lll_l1_): return
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⫫"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭⫬"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡴ࡮࡬ࡧࡪ࠳ࡴࡪࡶ࡯ࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⫭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭⫮"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ⫯"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⫰")+name+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⫱"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥࡱࡺࡲࡱࡵࡡࡥࡵࡁࠫ⫲"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⫳"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⫴")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⫵"))
	for l1llll1l11l_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll1l11l_l1_.split(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤࠨ⫶"))
		if l1ll1ll_l1_ not in l1llll1l1l1_l1_:
			l1llll1l1l1_l1_.append(l1ll1ll_l1_)
			l1llll1ll1l_l1_.append(l1llll1l11l_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1ll1l_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⫷"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ⫸"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ⫹"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⫺"),l1l111_l1_ (u"࠭ࠫࠨ⫻"))
	l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⫼")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠷ࠪ⫽"))
	return
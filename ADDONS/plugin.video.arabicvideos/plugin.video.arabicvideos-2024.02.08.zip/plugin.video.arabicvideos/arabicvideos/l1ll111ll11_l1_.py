# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪㄑ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡒࡒ࡛ࡡࠪㄒ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧㄓ"),l1l111_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧㄔ"),l1l111_l1_ (u"ࠧศๆสๆุอๅࠨㄕ"),l1l111_l1_ (u"ࠨ฻ิฺࠥอไๆิํำࠬㄖ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==700: l1lll_l1_ = l1l1l11_l1_()
	elif mode==701: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==702: l1lll_l1_ = PLAY(url)
	elif mode==703: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==704: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==709: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡾ࡮ࡱࡡ࠯࠻ࠪㄗ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧㄘ"),l1l11ll_l1_,l1l111_l1_ (u"ࠫࠬㄙ"),l1l111_l1_ (u"ࠬ࠭ㄚ"),l1l111_l1_ (u"࠭ࠧㄛ"),l1l111_l1_ (u"ࠧࠨㄜ"),l1l111_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪㄝ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄞ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪㄟ"),l1l111_l1_ (u"ࠫࠬㄠ"),709,l1l111_l1_ (u"ࠬ࠭ㄡ"),l1l111_l1_ (u"࠭ࠧㄢ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫㄣ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ㄤ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㄥ"),l1l111_l1_ (u"ࠪࠫㄦ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㄧ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧㄨ")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅๆ์ีࠫㄩ"),l1l11ll_l1_,701,l1l111_l1_ (u"ࠧࠨㄪ"),l1l111_l1_ (u"ࠨࠩㄫ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫㄬ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡲ࠳ࡴࡰࡲ࠰ࡲࡦࡼࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡩࡥࡦࡨࡲࠬㄭ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫㄮ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠬࡂࡢ࠿ࠩㄯ"),l1l111_l1_ (u"࠭ࠧ㄰")).strip(l1l111_l1_ (u"ࠧࠡࠩㄱ"))
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠧㄲ")): continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄳ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬㄴ")+l1lllll_l1_+title,l1ll1ll_l1_,704)
	return
def l11ll1_l1_(url):
	found = False
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨㄵ"),url,l1l111_l1_ (u"ࠬ࠭ㄶ"),l1l111_l1_ (u"࠭ࠧㄷ"),l1l111_l1_ (u"ࠧࠨㄸ"),l1l111_l1_ (u"ࠨࠩㄹ"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧㄺ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡶࡴࡲࡥ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㄻ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬㄼ"),l1l111_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫㄽ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㄾ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠧࠨㄿ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ㅀ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧㅁ"),l1l111_l1_ (u"ࠪࠫㅂ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩㅃ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠬࡀࠠࠨㅄ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅅ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㅆ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㅇ"),block,re.DOTALL)
		if len(items)<30:
			if found: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧㅈ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬㅉ"),l1l111_l1_ (u"ࠫࠬㅊ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅋ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡶࡩࡳࡴࡺࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ㅌ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㅍ"),block,re.DOTALL)
		if 1:
			if found: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ㅎ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㅏ"),l1l111_l1_ (u"ࠪࠫㅐ"),9999)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ㅑ"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅒ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	if not found: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"࠭ࠧㅓ")):
	if request==l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬㅔ"):
		url,search = url.split(l1l111_l1_ (u"ࠨࡁࠪㅕ"),1)
		data = l1l111_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨㅖ")+search
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩㅗ"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫㅘ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪㅙ"),url,data,headers,l1l111_l1_ (u"࠭ࠧㅚ"),l1l111_l1_ (u"ࠧࠨㅛ"),l1l111_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬㅜ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ㅝ"),url,l1l111_l1_ (u"ࠪࠫㅞ"),l1l111_l1_ (u"ࠫࠬㅟ"),l1l111_l1_ (u"ࠬ࠭ㅠ"),l1l111_l1_ (u"࠭ࠧㅡ"),l1l111_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫㅢ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠨࠩㅣ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ㅤ"))
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨㅥ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㅦ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠬ࠭ㅧ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨㅨ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩㅩ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧㅪ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩㅫ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧㅬ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㅭ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧㅮ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡣࡣࠣࡱ࡬ࡨࠠࡵࡣࡥࡰࡪࠦࡦࡶ࡮࡯ࠦ࠭࠴ࠪࡀࠫࠥࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧ࠭ㅯ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ㅰ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩㅱ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㅲ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫㅳ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫㅴ"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪㅵ"),l1l111_l1_ (u"࠭ว฻่ํอࠬㅶ"),l1l111_l1_ (u"ࠧไๆํฬࠬㅷ"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧㅸ"),l1l111_l1_ (u"๊ࠩำฬ็ࠧㅹ"),l1l111_l1_ (u"้ࠪออัศหࠪㅺ"),l1l111_l1_ (u"ࠫ฾ืึࠨㅻ"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬㅼ"),l1l111_l1_ (u"࠭วๅส๋้ࠬㅽ"),l1l111_l1_ (u"ࠧๆีิั๏ฯࠧㅾ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ㅿ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫㆀ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬㆁ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧㆂ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㆃ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬㆄ"):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㆅ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧㆆ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆇ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㆈ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㆉ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㆊ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨㆋ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩㆌ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪㆍ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆎ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ㆏")+title,l1ll1ll_l1_,701)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㆐"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㆑"),url,l1l111_l1_ (u"࠭ࠧ㆒"),l1l111_l1_ (u"ࠧࠨ㆓"),l1l111_l1_ (u"ࠨࠩ㆔"),l1l111_l1_ (u"ࠩࠪ㆕"),l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㆖"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ㆗"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㆘"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࠧ㆙")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࠨࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ㆚"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫ㆛"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠩࠦࠫ㆜"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㆝"),l1lllll_l1_+title,url,703,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ㆞"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠭࠴ࠪࡀࠫ࠿ࡷࡨࡸࡩࡱࡶࡁࠫ㆟"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࠫㆠ")+l1l11_l1_+l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㆡ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠧㆢ")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨㆣ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡔࡧࡤࡷࡴࡴࠧㆤ")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩㆥ"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂࡁࡲࡩ࠿࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠦㆦ"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪㆧ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ㆨ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠰࠲ࠫㆩ"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫㆪ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬㆫ"))
			title = title.replace(l1l111_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩㆬ"),l1l111_l1_ (u"ࠬࠦࠧㆭ"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬㆮ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫㆯ"),l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫㆰ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ㆱ"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫㆲ"),l1l111_l1_ (u"ࠫࠬㆳ"),l1l111_l1_ (u"ࠬ࠭ㆴ"),l1l111_l1_ (u"࠭ࠧㆵ"),l1l111_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩㆶ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ㆷ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡔࡱࡧࡹࡦࡴ࡫ࡳࡱࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪㆸ"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫㆹ"))
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬㆺ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧㆻ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧㆼ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨㆽ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨㆾ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㆿ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				title = title.strip(l1l111_l1_ (u"ࠪࡠࡳ࠭㇀"))
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㇁")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㇂"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㇃"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ㇄"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ㇅"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ㇆"),l1l111_l1_ (u"ࠪ࠯ࠬ㇇"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ㇈")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ㇉"))
	return
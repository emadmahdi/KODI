# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫこ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡐ࡚ࡋࡠࠩご")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭さ"),l1l111_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭ざ"),l1l111_l1_ (u"࠭วๅลๅืฬ๋ࠧし")]
def l11l1ll_l1_(mode,url,text):
	if   mode==670: l1lll_l1_ = l1l1l11_l1_()
	elif mode==671: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==672: l1lll_l1_ = PLAY(url)
	elif mode==673: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==674: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==679: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫじ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩす"),l1l111_l1_ (u"ࠩࠪず"),l1l111_l1_ (u"ࠪࠫせ"),l1l111_l1_ (u"ࠫࠬぜ"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩそ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ぞ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧた"),l1l111_l1_ (u"ࠨࠩだ"),679,l1l111_l1_ (u"ࠩࠪち"),l1l111_l1_ (u"ࠪࠫぢ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨっ"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪつ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨづ"),l1l111_l1_ (u"ࠧࠨて"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩで"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫと"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			if title==l1l111_l1_ (u"ࠪห้ษโิษ่ࠫど"): mode = 675
			else: mode = 674
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫな"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧに")+l1lllll_l1_+title,l1ll1ll_l1_,mode)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫぬ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩね"),l1l111_l1_ (u"ࠨࠩの"),9999)
	items = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࡥࡶࡴࡽࡳࡦ࠰࡫ࡸࡲࡲࠧは"))
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪば"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ぱ")+l1lllll_l1_+title,l1ll1ll_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l1llllll11_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪひ"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨび"),l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫぴ"))
	if l1llllll11_l1_: return l1llllll11_l1_
	l1llllll11_l1_ = []
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬふ"),url,l1l111_l1_ (u"ࠩࠪぶ"),l1l111_l1_ (u"ࠪࠫぷ"),l1l111_l1_ (u"ࠫࠬへ"),l1l111_l1_ (u"ࠬ࠭べ"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩぺ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰࡬ࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࡀࠪほ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llllll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬぼ"),block,re.DOTALL)
		if l1llllll11_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫぽ"),l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧま"),l1llllll11_l1_,l1ll1ll1_l1_)
	return l1llllll11_l1_
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨみ"),url,l1l111_l1_ (u"ࠬ࠭む"),l1l111_l1_ (u"࠭ࠧめ"),l1l111_l1_ (u"ࠧࠨも"),l1l111_l1_ (u"ࠨࠩゃ"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩや"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧゅ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬゆ"),l1l111_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫょ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪよ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠧࠨら"),block)]
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭り"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧる"),l1l111_l1_ (u"ࠪࠫれ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩろ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠬࡀࠠࠨゎ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭わ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫゐ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪゑ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧを"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬん"),l1l111_l1_ (u"ࠫࠬゔ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬゕ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"࠭ࠧゖ")):
	if request==l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ゗"):
		url,search = url.split(l1l111_l1_ (u"ࠨࡁࠪ゘"),1)
		data = l1l111_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ゙")+search
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦ゚ࠩ"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ゛")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ゜"),url,data,headers,l1l111_l1_ (u"࠭ࠧゝ"),l1l111_l1_ (u"ࠧࠨゞ"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧゟ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭゠"),url,l1l111_l1_ (u"ࠪࠫァ"),l1l111_l1_ (u"ࠫࠬア"),l1l111_l1_ (u"ࠬ࠭ィ"),l1l111_l1_ (u"࠭ࠧイ"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ゥ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠨࠩウ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ェ"))
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨエ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ォ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠬ࠭オ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨカ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨガ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧキ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩギ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧク"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫグ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧケ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨゲ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩコ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩゴ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪサ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫザ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫシ"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪジ"),l1l111_l1_ (u"࠭ว฻่ํอࠬス"),l1l111_l1_ (u"ࠧไๆํฬࠬズ"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧセ"),l1l111_l1_ (u"๊ࠩำฬ็ࠧゼ"),l1l111_l1_ (u"้ࠪออัศหࠪソ"),l1l111_l1_ (u"ࠫ฾ืึࠨゾ"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬタ"),l1l111_l1_ (u"࠭วๅส๋้ࠬダ"),l1l111_l1_ (u"ࠧๆีิั๏ฯࠧチ"),l1l111_l1_ (u"ࠨใ็้ࠬヂ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬッ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩツ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪヅ"):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫテ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬデ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧト"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ド") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩナ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪニ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬヌ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪネ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨノ"): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬハ") not in l1ll1ll_l1_:
				l1lllll1_l1_ = url.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪバ"),1)[0]
				l1ll1ll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫパ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬヒ"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫビ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫピ")+title,l1ll1ll_l1_,671,l1l111_l1_ (u"࠭ࠧフ"),l1l111_l1_ (u"ࠧࠨブ"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧプ"),l1lllll_l1_+l1l111_l1_ (u"ࠩอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩヘ"),url,672)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨベ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ペ"),l1l111_l1_ (u"ࠬ࠭ホ"),9999)
	l1llllll11_l1_ = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࡢࡳࡱࡺࡷࡪ࠴ࡨࡵ࡯࡯ࠫボ"))
	l1ll11ll111_l1_,l1ll11ll1l1_l1_,l1ll11ll11l_l1_ = zip(*l1llllll11_l1_)
	l1ll11lll11_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫポ"),url,l1l111_l1_ (u"ࠨࠩマ"),l1l111_l1_ (u"ࠩࠪミ"),l1l111_l1_ (u"ࠪࠫム"),l1l111_l1_ (u"ࠫࠬメ"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭モ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠪャ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡻࡅࡹࡹࡺ࡯࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡣࡀࠫ࠲࠯ࡅࠩ࠽ࠩヤ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1ll11ll111_l1_:
				item = (l1ll1ll_l1_,title)
				l1ll11lll11_l1_.append(item)
		if len(l1ll11lll11_l1_)==1:
			l1ll1ll_l1_,title = l1ll11lll11_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧュ"))
			return
		else:
			for l1ll1ll_l1_,title in l1ll11lll11_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩユ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠪࠫョ"),l1l111_l1_ (u"ࠫࠬヨ"),l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫラ"))
	if not l1ll11lll11_l1_: l1lll11_l1_(url,l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬリ"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫル"),url,l1l111_l1_ (u"ࠨࠩレ"),l1l111_l1_ (u"ࠩࠪロ"),l1l111_l1_ (u"ࠪࠫヮ"),l1l111_l1_ (u"ࠫࠬワ"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩヰ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡬࡬ࡢࡵ࡫ࡴࡱࡧࡹࡦࡴࠪヱ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪヲ"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡻࡦࡺࡣࡩࡡࡢࠫン")+l111l1ll_l1_
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡦࡨࡨ࠲ࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬヴ"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡪ࡮ࡲࡥ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥヵ"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩヶ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫヷ")+l1ll1ll_l1_
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧヸ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ヹ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩヺ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ・"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬー"),l1l111_l1_ (u"ࠫ࠰࠭ヽ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬヾ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ヿ"))
	return
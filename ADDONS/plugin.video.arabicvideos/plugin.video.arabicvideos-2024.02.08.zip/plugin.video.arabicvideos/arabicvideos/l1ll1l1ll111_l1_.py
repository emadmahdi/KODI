# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ婓")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡐࡠࠩ婔")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠫ婕"),l1l111_l1_ (u"ࠬฮหࠡ็หหูืࠧ婖")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ婗"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ婘"),l1l111_l1_ (u"ࠨࠩ婙"),l1l111_l1_ (u"ࠩࠪ婚"),l1l111_l1_ (u"ࠪࠫ婛"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ婜"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ婝"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"࠭࠯ࠨ婞"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ婟"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ婠"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ婡"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠪࠫ婢"),l1l111_l1_ (u"ࠫࠬ婣"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ婤"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ婥"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ婦"),l1l111_l1_ (u"ࠨࠩ婧"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婨"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ婩")+l1lllll_l1_+l1l111_l1_ (u"ࠫศำฯฬࠢส่๊๎วื์฼ࠫ婪"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪࠤࡰࡽࡆࡩࡣࡰࡷࡱࡸࠧ࠭婫"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ婬"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ婭"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ婮"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ婯")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l11l11l11l11_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ婰"),url,l1l111_l1_ (u"ࠫࠬ婱"),l1l111_l1_ (u"ࠬ࠭婲"),l1l111_l1_ (u"࠭ࠧ婳"),l1l111_l1_ (u"ࠧࠨ婴"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ婵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡴࡹࡴࠩ࠰࠭ࡃ࠮ࠨࡦࡰࡱࡷࡩࡷࠨࠧ婶"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ婷"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ婸"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ婹"),l1l111_l1_ (u"࠭ว฻่ํอࠬ婺"),l1l111_l1_ (u"ࠧฤ฼้๎ฮ࠭婻"),l1l111_l1_ (u"ࠨๅ็๎อ࠭婼"),l1l111_l1_ (u"ࠩส฽้อๆࠨ婽"),l1l111_l1_ (u"๋ࠪิอแࠨ婾"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ婿"),l1l111_l1_ (u"ࠬ฿ัืࠩ媀"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭媁"),l1l111_l1_ (u"ࠧศๆห์๊࠭媂"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨ媃")]
	l11l11l11l1l_l1_ = l1l111_l1_ (u"ࠩ࠲ࠫ媄").join(l11l11l11l11_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ媅")).split(l1l111_l1_ (u"ࠫ࠴࠭媆"))[4:]).split(l1l111_l1_ (u"ࠬ࠳ࠧ媇"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ媈"),title,re.DOTALL)
		if l11l11l11l11_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ媉").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ媊")).split(l1l111_l1_ (u"ࠩ࠲ࠫ媋"))[4:]).split(l1l111_l1_ (u"ࠪ࠱ࠬ媌"))
			l11l11l11ll1_l1_ = len([x for x in l11l11l11l1l_l1_ if x in l111lllll_l1_])
			if l11l11l11ll1_l1_>2 and l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ媍") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ媎"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ媏"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ࠧๆี็ื้࠭媐") not in title:
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ媑"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧ媒") in title:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ媓") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ媔"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭媕"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媖"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ媗"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠦ媘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ媙"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫ媚"),l1l111_l1_ (u"ࠫࠬ媛"))
			if title!=l1l111_l1_ (u"ࠬ࠭媜"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媝"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭媞")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠨࠩ媟"),l1l111_l1_ (u"ࠩࠪ媠"),l11l11l11l11_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭媡"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ媢")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ媣"),url,l1l111_l1_ (u"࠭ࠧ媤"),headers,l1l111_l1_ (u"ࠧࠨ媥"),l1l111_l1_ (u"ࠨࠩ媦"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ媧"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ媨"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡭ࡨ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ媩"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭媪"))
	l11l11l111ll_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡭࡫ࡶࡸࡘ࡫ࡡࡴࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ媫"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ媬") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠬ媭"))
		if count==0: count = block.count(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠨ媮"))
		if count>1:
			l11l11l111ll_l1_ = False
			if l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠨ媯") in block:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ媰"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠲࠯ࡲ࡫ࡴࡄࡹ࡬ࡶࡩࡀࠫ媱")+id
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媲"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ媳"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵ࡭ࡪࡹࡉࡅ࠿ࠪ媴")+id
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媵"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l11l11l111ll_l1_:
		block = l1l111_l1_ (u"ࠪࠫ媶")
		if l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ媷") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡥࡱ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ媸"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ媹"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ媺"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ媻"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠩ࠲ࠫ媼"))+l1l111_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡹࡤࡸࡨ࡮ࠧ媽")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ媾"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭媿"),l1l111_l1_ (u"࠭ࠧ嫀"),l1l111_l1_ (u"ࠧࠨ嫁"),l1l111_l1_ (u"ࠨࠩ嫂"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭嫃"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ嫄"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡵ࡟ࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ嫅"),html,re.DOTALL)
	if not l11111l11_l1_: l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࠨࡵࡪ࡬ࡷࡡ࠴ࡩࡥ࡞࠯࠴ࡡ࠲ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ嫆"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嫇"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ嫈"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ嫉"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲࡭࡫ࡸࡡ࡮ࡧ࠵࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ嫊")+l11111l11_l1_+l1l111_l1_ (u"ࠪࠪࡻ࡯ࡤࡦࡱࡀࠫ嫋")+l111111ll_l1_[2:]+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嫌")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嫍")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡨࡧࡷࡉࡲࡨࡥࡥࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嫎"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ嫏"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ嫐")+title+l1l111_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ嫑")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠪ࠳ࠬ嫒"))+l1l111_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ嫓")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嫔"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ嫕"),l1l111_l1_ (u"ࠧࠨ嫖"),l1l111_l1_ (u"ࠨࠩ嫗"),l1l111_l1_ (u"ࠩࠪ嫘"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ嫙"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡺࡡࡣ࡮ࡨ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ嫚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嫛"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ嫜"))
			if l1l111_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ嫝") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠨࡡࡢาฬ฻ࠧ嫞")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠩࠪ嫟")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ嫠")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ嫡")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嫢"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"࠭ࠧ嫣")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ嫤"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ嫥"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ嫦"),l1l111_l1_ (u"ࠪ࠯ࠬ嫧"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠫࠬ嫨"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ嫩")+search+l1l111_l1_ (u"࠭࠯ࠨ嫪")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࠨ嫫"))
	return
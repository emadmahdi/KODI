# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
import bs4
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ◲")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡎࡆࡣࠬ◳")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ◴"):l111l1_l1_}
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==510: l1lll_l1_ = l1l1l11_l1_()
	elif mode==511: l1lll_l1_ = l1llllll11l_l1_(url)
	elif mode==512: l1lll_l1_ = l1111lll1l_l1_(url)
	elif mode==513: l1lll_l1_ = l1111lll11_l1_(url)
	elif mode==514: l1lll_l1_ = l1llllll1ll_l1_(url,l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ◵")+text)
	elif mode==515: l1lll_l1_ = l1llllll1ll_l1_(url,l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ◶")+text)
	elif mode==516: l1lll_l1_ = l11111ll1l_l1_(text)
	elif mode==517: l1lll_l1_ = l1111l1l1l_l1_(url)
	elif mode==518: l1lll_l1_ = l1111l1ll1_l1_(url)
	elif mode==519: l1lll_l1_ = l1lll1_l1_(text)
	elif mode==520: l1lll_l1_ = l1111l1111_l1_(url)
	elif mode==521: l1lll_l1_ = l1llllll111_l1_(url)
	elif mode==522: l1lll_l1_ = PLAY(url)
	elif mode==523: l1lll_l1_ = l1llllllll1_l1_(text)
	elif mode==524: l1lll_l1_ = l11111111l_l1_()
	elif mode==525: l1lll_l1_ = l1111ll1ll_l1_()
	elif mode==526: l1lll_l1_ = l11111llll_l1_()
	elif mode==527: l1lll_l1_ = l1111111l1_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◷"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡส่์ุ๎ูสࠢสุ่๐ๆๆษࠪ◸"),l1l111_l1_ (u"ࠬ࠭◹"),519)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ◺"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ◻"),l1l111_l1_ (u"ࠨࠩ◼"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◽"),l1lllll_l1_+l1l111_l1_ (u"้ࠪํฺู่หࠣห้ษูๆษ็ࠫ◾"),l1l111_l1_ (u"ࠫࠬ◿"),525)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☀"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅลืาฬ฻ࠧ☁"),l1l111_l1_ (u"ࠧࠨ☂"),526)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☃"),l1lllll_l1_+l1l111_l1_ (u"่ࠩ์ุ๎ูสࠢส่๊฻ๆโษอࠫ☄"),l1l111_l1_ (u"ࠪࠫ★"),527)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☆"),l1lllll_l1_+l1l111_l1_ (u"๋่ࠬิ๊฼อࠥอไๆ่๋฽ฬะࠧ☇"),l1l111_l1_ (u"࠭ࠧ☈"),524)
	return
def l11111111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☉"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢไ๎ิ๐่่ษอࠤ࠲ࠦฮศืฬࠫ☊"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࠩ☋"),520)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☌"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡละำะ࠭☍"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡲࡡࡵࡧࡶࡸࠬ☎"),521)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☏"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢ࠰ࠤศ่ฯๆࠩ☐"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࡱ࡯ࡨࡪࡹࡴࠨ☑"),521)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☒"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠳ࠠฤๅฮี๋ࠥิศ้าอࠬ☓"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࡻ࡯ࡥࡸࡵࠪ☔"),521)
	return
def l1111ll1ll_l1_():
	l1lllllll11_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵࡅࡵࡵࡨ࠻ࡁࠪࡋ࠲ࠦ࠻ࡆࠩ࠾࠹ࠧ☕")
	l11111l11l_l1_ = l1lllllll11_l1_+l1l111_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠸ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠴ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂ࡬ࡡ࡭ࡵࡨࠪࡹࡧࡧ࠾ࠩ☖")
	l1111ll1l1_l1_ = l1lllllll11_l1_+l1l111_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡦࡢ࡮ࡶࡩࠫࡺࡡࡨ࠿ࠪ☗")
	l1111111ll_l1_ = l1lllllll11_l1_+l1l111_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪ☘")
	l111111l11_l1_ = l1lllllll11_l1_+l1l111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫ☙")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☚"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤศ็ไศ็ࠣ฽ึฮ๊ࠨ☛"),l11111l11l_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☜"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅึ่ไหฯࠦๅิๆึ่ฬะฺࠠำห๎ࠬ☝"),l1111ll1l1_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☞"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ุ๊ๆอสࠡลไ่ฬ๋ࠠศฮ้ฬ๏࠭☟"),l1111111ll_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☠"),l1lllll_l1_+l1l111_l1_ (u"ฺ้ࠪ์แศฬุ้๊ࠣำๅษอࠤฬาๆษ์ࠪ☡"),l111111l11_l1_,511)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ☢"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ☣"),l1l111_l1_ (u"࠭ࠧ☤"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☥"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ๊ีุࠦรฺ็ส่ࠥษศอัํࠫ☦"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡢ࡮ࡳ࡬ࡦࡨࡥࡵࠩ☧"),517)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☨"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆํัิࠢࠣฬ้ีࠠศๆศ๊ฯอฬࠨ☩"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡧࡴࡻ࡮ࡵࡴࡼࠫ☪"),517)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☫"),l1lllll_l1_+l1l111_l1_ (u"ࠧโ้ิืࠥอไๅ฼ฬࠫ☬"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ☭"),517)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☮"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡ็ุ๊ๆอสࠡษ็฽๊๊ࠧ☯"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡪࡩࡳࡸࡥࠨ☰"),517)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ☱"),l1lllll_l1_+l1l111_l1_ (u"࠭แ่ำึࠤุ์ษࠡษ็ษฺีวาࠩ☲"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡸࡥ࡭ࡧࡤࡷࡪࡥࡹࡦࡣࡵࠫ☳"),517)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭☴"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ☵"),l1l111_l1_ (u"ࠪࠫ☶"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☷"),l1lllll_l1_+l1l111_l1_ (u"๋่ࠬศี่ࠤ࠲ࠦแๅฬิࠤ๊ำฯะࠩ☸"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪ☹"),515)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☺"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋หุ๋ࠠ࠮ࠢไ่ฯืࠠไษ่่ࠬ☻"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭☼"),514)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ☽"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭☾"),l1l111_l1_ (u"ࠬ࠭☿"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♀"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆื้ๅฬะࠠ࠮ࠢไ่ฯืࠠๆฯาำࠬ♁"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ♂"),515)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♃"),l1lllll_l1_+l1l111_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำࠣ็ฬ๋ไࠨ♄"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ♅"),514)
	return
def l1111111l1_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ♆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ♇"),l1l111_l1_ (u"ࠧࠨ♈"),headers,l1l111_l1_ (u"ࠨࠩ♉"),l1l111_l1_ (u"ࠩࠪ♊"),l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ♋"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ♌"),multi_valued_attributes=None)
	block = l1lllll1lll_l1_.find(l1l111_l1_ (u"ࠬࡹࡥ࡭ࡧࡦࡸࠬ♍"),attrs={l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ♎"):l1l111_l1_ (u"ࠧࡵࡣࡪࠫ♏")})
	options = block.find_all(l1l111_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠨ♐"))
	for option in options:
		value = option.get(l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ♑"))
		if not value: continue
		title = option.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♒"))
			value = value.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♓"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵࡅࡵࡵࡨ࠻ࡁࠪࡋ࠲ࠦ࠻ࡆࠩ࠾࠹ࠦࡵࡻࡳࡩࡂࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࠪࡹࡧࡧ࠾ࠩ♔")+value
		title = title.replace(l1l111_l1_ (u"࠭โศศ่อࠥ࠭♕"),l1l111_l1_ (u"ࠧࠨ♖"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♗"),l1lllll_l1_+title,l1ll1ll_l1_,511)
	return
def l11111llll_l1_():
	l1lllllll11_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠫ♘")
	l11111l111_l1_ = l1lllllll11_l1_+l1l111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࠨࡷࡥ࡬ࡃࠧ♙")
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♚"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬี็ใสฮࠥษิฯษุࠫ♛"),l11111l111_l1_,511)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ♜"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ♝"),l1l111_l1_ (u"ࠨࠩ♞"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♟"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ์ืำࠡลืาฬ฻ࠠฤสฯำ๏࠭♠"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡦࡲࡰࡩࡣࡥࡩࡹ࠭♡"),517)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♢"),l1lllll_l1_+l1l111_l1_ (u"࠭แ่ำึࠤ๊๎ื็ࠩ♣"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯࡯ࡣࡷ࡭ࡴࡴࡡ࡭࡫ࡷࡽࠬ♤"),517)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♥"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๋ึูࠠࠡฬสี๏ิࠠศๆ่๎้อฯࠨ♦"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡦ࡮ࡸࡴࡩࡡࡼࡩࡦࡸࠧ♧"),517)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ♨"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็็าีࠣࠤฯอั๋ะࠣห้๎แศหࠪ♩"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵ࡤࡦࡣࡷ࡬ࡤࡿࡥࡢࡴࠪ♪"),517)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ♫"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ♬"),l1l111_l1_ (u"ࠩࠪ♭"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ♮"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ฻ๆโษอࠤ࠲ࠦแๅฬิࠤ๊ำฯะࠩ♯"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡰࡨࡹࡵ࠭♰"),515)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♱"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆื้ๅฬะࠠ࠮ࠢไ่ฯืࠠไษ่่ࠬ♲"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ♳"),514)
	return
def l1llllll11l_l1_(url):
	if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭♴") in url: index = 0
	elif l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ♵") in url: index = 1
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ♶"),url,l1l111_l1_ (u"ࠬ࠭♷"),headers,l1l111_l1_ (u"࠭ࠧ♸"),l1l111_l1_ (u"ࠧࠨ♹"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭♺"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ♻"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1lll_l1_.find_all(class_=l1l111_l1_ (u"ࠪ࡮ࡺࡳࡢࡰ࠯ࡷ࡬ࡪࡧࡴࡦࡴࠣࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠬ♼"))
	for block in l1lll1l1_l1_:
		title = block.find_all(l1l111_l1_ (u"ࠫࡦ࠭♽"))[index].text
		l1ll1ll_l1_ = l111l1_l1_+block.find_all(l1l111_l1_ (u"ࠬࡧࠧ♾"))[index].get(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠫ♿"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚀"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚁"))
		if not l1lll1l1_l1_:
			l1111lll1l_l1_(l1ll1ll_l1_)
			return
		else:
			title = title.replace(l1l111_l1_ (u"ࠩๅหห๋ษࠡࠩ⚂"),l1l111_l1_ (u"ࠪࠫ⚃"))
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚄"),l1lllll_l1_+title,l1ll1ll_l1_,512)
	PAGINATION(l1lllll1lll_l1_,511)
	return
def PAGINATION(l1lllll1lll_l1_,mode):
	block = l1lllll1lll_l1_.find(class_=l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ⚅"))
	if block:
		l1ll1l1ll_l1_ = block.find_all(l1l111_l1_ (u"࠭ࡡࠨ⚆"))
		l1lllll1ll1_l1_ = block.find_all(l1l111_l1_ (u"ࠧ࡭࡫ࠪ⚇"))
		l11111lll1_l1_ = list(zip(l1ll1l1ll_l1_,l1lllll1ll1_l1_))
		l1l111lll1_l1_ = -1
		length = len(l11111lll1_l1_)
		for l1lll1l1l_l1_,l1lllllll1l_l1_ in l11111lll1_l1_:
			l1l111lll1_l1_ += 1
			l1lllllll1l_l1_ = l1lllllll1l_l1_[l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ⚈")]
			if l1l111_l1_ (u"ࠩࡸࡲࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠧ⚉") in l1lllllll1l_l1_ or l1l111_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࠫ⚊") in l1lllllll1l_l1_: continue
			l111111111_l1_ = l1lll1l1l_l1_.text
			l111lllll_l1_ = l111l1_l1_+l1lll1l1l_l1_.get(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⚋"))
			if PY2:
				l111111111_l1_ = l111111111_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚌"))
				l111lllll_l1_ = l111lllll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚍"))
			if   l1l111lll1_l1_==0: l111111111_l1_ = l1l111_l1_ (u"ࠧฤ๊็ํࠬ⚎")
			elif l1l111lll1_l1_==1: l111111111_l1_ = l1l111_l1_ (u"ࠨีสฬ็ฯࠧ⚏")
			elif l1l111lll1_l1_==length-2: l111111111_l1_ = l1l111_l1_ (u"ࠩ็หา่ษࠨ⚐")
			elif l1l111lll1_l1_==length-1: l111111111_l1_ = l1l111_l1_ (u"ࠪวำ๐ัสࠩ⚑")
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚒"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⚓")+l111111111_l1_,l111lllll_l1_,mode)
	return
def l1111lll1l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⚔"),url,l1l111_l1_ (u"ࠧࠨ⚕"),headers,l1l111_l1_ (u"ࠨࠩ⚖"),l1l111_l1_ (u"ࠩࠪ⚗"),l1l111_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠶࠳࠱ࡴࡶࠪ⚘"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⚙"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1lll_l1_.find_all(class_=l1l111_l1_ (u"ࠬࡸ࡯ࡸࠩ⚚"))
	items,first = [],True
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯ࡺࡶࡦࡶࡰࡦࡴࠪ⚛")): continue
		if first: first = False ; continue
		l111111l1l_l1_ = []
		l1lllll1l1l_l1_ = block.find_all(class_=[l1l111_l1_ (u"ࠧࡤࡧࡱࡷࡴࡸࡳࡩ࡫ࡳࠤࡷ࡫ࡤࠨ⚜"),l1l111_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡶࡵࡳࡲ࡯ࡩࠬ⚝")])
		for l1lllllllll_l1_ in l1lllll1l1l_l1_:
			l1111llll1_l1_ = l1lllllllll_l1_.find_all(l1l111_l1_ (u"ࠩ࡯࡭ࠬ⚞"))[1].text
			if PY2:
				l1111llll1_l1_ = l1111llll1_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⚟"))
			l111111l1l_l1_.append(l1111llll1_l1_)
		if not l11111l_l1_(l1ll1_l1_,l1l111_l1_ (u"ࠫࠬ⚠"),l111111l1l_l1_,False):
			l11l_l1_ = block.find(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠩ⚡")).get(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ⚢"))
			title = block.find(l1l111_l1_ (u"ࠧࡩ࠵ࠪ⚣"))
			name = title.find(l1l111_l1_ (u"ࠨࡣࠪ⚤")).text
			l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠩࡤࠫ⚥")).get(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ⚦"))
			l1111l1l11_l1_ = block.find(class_=l1l111_l1_ (u"ࠫࡳࡵ࠭࡮ࡣࡵ࡫࡮ࡴࠧ⚧"))
			l111111lll_l1_ = block.find(class_=l1l111_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬ⚨"))
			if l1111l1l11_l1_: l1111l1l11_l1_ = l1111l1l11_l1_.text
			if l111111lll_l1_: l111111lll_l1_ = l111111lll_l1_.text
			if PY2:
				l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⚩"))
				name = name.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⚪"))
				l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⚫"))
				if l1111l1l11_l1_: l1111l1l11_l1_ = l1111l1l11_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⚬"))
			l1llllll1l1_l1_ = {}
			if l111111lll_l1_: l1llllll1l1_l1_[l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡴࠩ⚭")] = l111111lll_l1_
			if l1111l1l11_l1_:
				l1111l1l11_l1_ = l1111l1l11_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ⚮"),l1l111_l1_ (u"ࠬࠦ࠮࠯ࠢࠪ⚯"))
				l1llllll1l1_l1_[l1l111_l1_ (u"࠭ࡰ࡭ࡱࡷࠫ⚰")] = l1111l1l11_l1_.replace(l1l111_l1_ (u"ࠧ࠯࠰࠱ห็ืรࠡษ็้ื๐ฯࠨ⚱"),l1l111_l1_ (u"ࠨࠩ⚲"))
			if l1l111_l1_ (u"ࠩ࠲ࡻࡴࡸ࡫࠰ࠩ⚳") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚴"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠫࠬ⚵"),name,l1l111_l1_ (u"ࠬ࠭⚶"),l1llllll1l1_l1_)
			elif l1l111_l1_ (u"࠭࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ⚷") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚸"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠨࠩ⚹"),name,l1l111_l1_ (u"ࠩࠪ⚺"),l1llllll1l1_l1_)
	PAGINATION(l1lllll1lll_l1_,512)
	return
def l1111lll11_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⚻"),url,l1l111_l1_ (u"ࠫࠬ⚼"),headers,l1l111_l1_ (u"ࠬ࠭⚽"),l1l111_l1_ (u"࠭ࠧ⚾"),l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠴࠰࠵ࡸࡺࠧ⚿"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭⛀"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1lll_l1_.find_all(l1l111_l1_ (u"ࠩ࡯࡭ࠬ⛁"))
	names,items = [],[]
	for block in l1lll1l1_l1_:
		if not block.find(class_=l1l111_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠳ࡷࡳࡣࡳࡴࡪࡸࠧ⛂")): continue
		if not block.find(class_=[l1l111_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩ࠭⛃"),l1l111_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠠࡵࡧࡻࡸ࠲ࡩࡥ࡯ࡶࡨࡶࠬ⛄")]): continue
		if block.find(class_=l1l111_l1_ (u"࠭ࡨࡪࡦࡨࠫ⛅")): continue
		title = block.find(class_=[l1l111_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠩ⛆"),l1l111_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠣࡸࡪࡾࡴ࠮ࡥࡨࡲࡹ࡫ࡲࠨ⛇")])
		name = title.find(l1l111_l1_ (u"ࠩࡤࠫ⛈")).text
		if name in names: continue
		names.append(name)
		l1ll1ll_l1_ = l111l1_l1_+title.find(l1l111_l1_ (u"ࠪࡥࠬ⛉")).get(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⛊"))
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡷࡰࡴ࡮࠳ࠬ⛋") in url: l11l_l1_ = block.find(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠪ⛌")).get(l1l111_l1_ (u"ࠧࡴࡴࡦࠫ⛍"))
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⛎") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠩ࡬ࡱ࡬࠭⛏")).get(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ⛐"))
		elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡼࡩࡥࡧࡲ࠳ࠬ⛑") in url: l11l_l1_ = block.find(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠩ⛒")).get(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ⛓"))
		else: l11l_l1_ = block.find(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠫ⛔")).get(l1l111_l1_ (u"ࠨࡵࡵࡧࠬ⛕"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⛖"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⛗"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⛘"))
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ⛙"))
		items.append((name,l1ll1ll_l1_,l11l_l1_))
	if l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ⛚") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l1ll1ll_l1_,l11l_l1_ in items:
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ⛛") in url: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⛜"),l1lllll_l1_+name,l1ll1ll_l1_,522,l11l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ⛝") in url: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛞"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠫࠬ⛟"),name)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛠"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"࠭ࠧ⛡"),name)
	return
def l11111ll1l_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠧศๆศ฽้อๆࠨ⛢"),l1l111_l1_ (u"ࠨࠩ⛣")).replace(l1l111_l1_ (u"ࠩ็ๅ๏๊ๅࠨ⛤"),l1l111_l1_ (u"ࠪࠫ⛥")).replace(l1l111_l1_ (u"ࠫฬ๊ัิ็ํࠫ⛦"),l1l111_l1_ (u"ࠬ࠭⛧"))
	text = text.replace(l1l111_l1_ (u"࠭ลฺๆส๊ࠬ⛨"),l1l111_l1_ (u"ࠧࠨ⛩")).replace(l1l111_l1_ (u"ࠨใํ่๊࠭⛪"),l1l111_l1_ (u"ࠩࠪ⛫")).replace(l1l111_l1_ (u"ࠪห้ฮั้็๋ࠫ⛬"),l1l111_l1_ (u"ࠫࠬ⛭"))
	text = text.replace(l1l111_l1_ (u"ࠬอไหึ๋๎็๐ࠧ⛮"),l1l111_l1_ (u"࠭ࠧ⛯")).replace(l1l111_l1_ (u"ࠧๅ็ึุ่๊ࠧ⛰"),l1l111_l1_ (u"ࠨࠩ⛱")).replace(l1l111_l1_ (u"่ࠩืู้ไࠨ⛲"),l1l111_l1_ (u"ࠪࠫ⛳"))
	text = text.replace(l1l111_l1_ (u"ࠫ࠿࠭⛴"),l1l111_l1_ (u"ࠬ࠭⛵")).replace(l1l111_l1_ (u"࠭ࠩࠨ⛶"),l1l111_l1_ (u"ࠧࠨ⛷")).replace(l1l111_l1_ (u"ࠨࠪࠪ⛸"),l1l111_l1_ (u"ࠩࠪ⛹")).replace(l1l111_l1_ (u"ࠪ࠰ࠬ⛺"),l1l111_l1_ (u"ࠫࠬ⛻"))
	text = text.replace(l1l111_l1_ (u"ࠬࡥࠧ⛼"),l1l111_l1_ (u"࠭ࠧ⛽")).replace(l1l111_l1_ (u"ࠧ࠼ࠩ⛾"),l1l111_l1_ (u"ࠨࠩ⛿")).replace(l1l111_l1_ (u"ࠩ࠰ࠫ✀"),l1l111_l1_ (u"ࠪࠫ✁")).replace(l1l111_l1_ (u"ࠫ࠳࠭✂"),l1l111_l1_ (u"ࠬ࠭✃"))
	text = text.replace(l1l111_l1_ (u"࠭࡜ࠨࠩ✄"),l1l111_l1_ (u"ࠧࠨ✅")).replace(l1l111_l1_ (u"ࠨ࡞ࠥࠫ✆"),l1l111_l1_ (u"ࠩࠪ✇"))
	text = text.replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ✈"),l1l111_l1_ (u"ࠫࠥ࠭✉")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠩ✊"),l1l111_l1_ (u"࠭ࠠࠨ✋")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ✌"),l1l111_l1_ (u"ࠨࠢࠪ✍"))
	text = text.strip(l1l111_l1_ (u"ࠩࠣࠫ✎"))
	l1111l1lll_l1_ = text.count(l1l111_l1_ (u"ࠪࠤࠬ✏"))+1
	if l1111l1lll_l1_==1:
		l1llllllll1_l1_(text)
		return
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ✐"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁ้ࠥไๆษอࠤ้๊ศฮอࠣࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ✑"),l1l111_l1_ (u"࠭ࠧ✒"),9999)
	l11111l1ll_l1_ = text.split(l1l111_l1_ (u"ࠧࠡࠩ✓"))
	l1111ll11l_l1_ = pow(2,l1111l1lll_l1_)
	l111l1111_l1_ = []
	def l11111l1l1_l1_(a,b):
		if a==l1l111_l1_ (u"ࠨ࠳ࠪ✔"): return b
		return l1l111_l1_ (u"ࠩࠪ✕")
	for l1l111lll1_l1_ in range(l1111ll11l_l1_,0,-1):
		l1111l111l_l1_ = list(l1111l1lll_l1_*l1l111_l1_ (u"ࠪ࠴ࠬ✖")+bin(l1l111lll1_l1_)[2:])[-l1111l1lll_l1_:]
		l1111l111l_l1_ = reversed(l1111l111l_l1_)
		result = map(l11111l1l1_l1_,l1111l111l_l1_,l11111l1ll_l1_)
		title = l1l111_l1_ (u"ࠫࠥ࠭✗").join(filter(None,result))
		if PY2: l1lllllll_l1_ = title.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✘"))
		else: l1lllllll_l1_ = title
		if len(l1lllllll_l1_)>2 and title not in l111l1111_l1_:
			l111l1111_l1_.append(title)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✙"),l1lllll_l1_+title,l1l111_l1_ (u"ࠧࠨ✚"),523,l1l111_l1_ (u"ࠨࠩ✛"),l1l111_l1_ (u"ࠩࠪ✜"),title)
	return
def l1llllllll1_l1_(l1111ll111_l1_):
	if PY2:
		l1111ll111_l1_ = l1111ll111_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✝"))
		import arabic_reshaper
		l1111ll111_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1111ll111_l1_)
		l1111ll111_l1_ = bidi.algorithm.get_display(l1111ll111_l1_)
	import l1111l11ll_l1_
	l1111ll111_l1_ = l1llll1_l1_(default=l1111ll111_l1_)
	l1111l11ll_l1_.l1lll1_l1_(l1111ll111_l1_)
	return
def l1111l1l1l_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ✞"),url,l1l111_l1_ (u"ࠬ࠭✟"),headers,l1l111_l1_ (u"࠭ࠧ✠"),l1l111_l1_ (u"ࠧࠨ✡"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡍࡓࡊࡅ࡙ࡇࡖࡣࡑࡏࡓࡕࡕ࠰࠵ࡸࡺࠧ✢"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ✣"),multi_valued_attributes=None)
	block = l1lllll1lll_l1_.find(class_=l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴ࠮ࡵࡨࡴࡦࡸࡡࡵࡱࡵࠤࡱ࡯ࡳࡵ࠯ࡷ࡭ࡹࡲࡥࠨ✤"))
	l11l11_l1_ = block.find_all(l1l111_l1_ (u"ࠫࡦ࠭✥"))
	items = []
	for title in l11l11_l1_:
		name = title.text
		l1ll1ll_l1_ = l111l1_l1_+title.get(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ✦"))
		if PY2:
			name = name.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ✧"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ✨"))
		if l1l111_l1_ (u"ࠨࠥࠪ✩") not in l1ll1ll_l1_: items.append((name,l1ll1ll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l1ll1ll_l1_ = item
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ✪"),l1lllll_l1_+name,l1ll1ll_l1_,518)
	return
def l1111l1ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ✫"),url,l1l111_l1_ (u"ࠫࠬ✬"),headers,l1l111_l1_ (u"ࠬ࠭✭"),l1l111_l1_ (u"࠭ࠧ✮"),l1l111_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡌࡒࡉࡋࡘࡆࡕࡢࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ✯"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭✰"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1lll_l1_.find(class_=l1l111_l1_ (u"ࠩࡨࡼࡵࡧ࡮ࡥࠩ✱")).find_all(l1l111_l1_ (u"ࠪࡸࡷ࠭✲"))
	for block in l1lll1l1_l1_:
		l11111ll11_l1_ = block.find_all(l1l111_l1_ (u"ࠫࡦ࠭✳"))
		if not l11111ll11_l1_: continue
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠩ✴")).get(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ✵"))
		name = l11111ll11_l1_[1].text
		l1ll1ll_l1_ = l111l1_l1_+l11111ll11_l1_[1].get(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬ✶"))
		l111111lll_l1_ = block.find(class_=l1l111_l1_ (u"ࠨ࡮ࡨ࡫ࡪࡴࡤࠨ✷"))
		if l111111lll_l1_: l111111lll_l1_ = l111111lll_l1_.text
		if PY2:
			name = name.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ✸"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ✹"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✺"))
		l1llllll1l1_l1_ = {}
		if l111111lll_l1_: l1llllll1l1_l1_[l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡶࠫ✻")] = l111111lll_l1_
		if l1l111_l1_ (u"࠭࠯ࡸࡱࡵ࡯࠴࠭✼") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✽"),l1lllll_l1_+name,l1ll1ll_l1_,516,l11l_l1_,l1l111_l1_ (u"ࠨࠩ✾"),name,l1l111_l1_ (u"ࠩࠪ✿"),l1llllll1l1_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ❀") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ❁"),l1lllll_l1_+name,l1ll1ll_l1_,513,l11l_l1_,l1l111_l1_ (u"ࠬ࠭❂"),name,l1l111_l1_ (u"࠭ࠧ❃"),l1llllll1l1_l1_)
	PAGINATION(l1lllll1lll_l1_,518)
	return
def l1111l1111_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ❄"),url,l1l111_l1_ (u"ࠨࠩ❅"),headers,l1l111_l1_ (u"ࠩࠪ❆"),l1l111_l1_ (u"ࠪࠫ❇"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡖࡊࡆࡈࡓࡘࡥࡌࡊࡕࡗࡗ࠲࠷ࡳࡵࠩ❈"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ❉"),multi_valued_attributes=None)
	l11l11_l1_ = l1lllll1lll_l1_.find_all(class_=l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡵ࡫ࡷࡰࡪࠦࡩ࡯࡮࡬ࡲࡪ࠭❊"))
	l1ll_l1_ = l1lllll1lll_l1_.find_all(class_=l1l111_l1_ (u"ࠧࡣࡷࡷࡸࡴࡴࠠࡨࡴࡨࡩࡳࠦࡳ࡮ࡣ࡯ࡰࠥࡸࡩࡨࡪࡷࠫ❋"))
	items = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in items:
		title = title.text
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.get(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭❌"))
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ❍"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ❎"))
		title = title.replace(l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠩ❏"),l1l111_l1_ (u"ࠬࠦࠧ❐")).replace(l1l111_l1_ (u"࠭ࠠࠡࠢࠪ❑"),l1l111_l1_ (u"ࠧࠡࠩ❒")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ❓"),l1l111_l1_ (u"ࠩࠣࠫ❔"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❕"),l1lllll_l1_+title,l1ll1ll_l1_,521)
	return
def l1llllll111_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ❖"),url,l1l111_l1_ (u"ࠬ࠭❗"),headers,l1l111_l1_ (u"࠭ࠧ❘"),l1l111_l1_ (u"ࠧࠨ❙"),l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰࡚ࡎࡊࡅࡐࡕࡢࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ❚"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ❛"),multi_valued_attributes=None)
	l1111lllll_l1_ = l1lllll1lll_l1_.find(class_=l1l111_l1_ (u"ࠪࡰࡦࡸࡧࡦ࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡ࡯ࡨࡨ࡮ࡻ࡭࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠺ࠠࡴ࡯ࡤࡰࡱ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠶ࠬ❜"))
	l1lll1l1_l1_ = l1111lllll_l1_.find_all(l1l111_l1_ (u"ࠫࡱ࡯ࠧ❝"))
	for block in l1lll1l1_l1_:
		title = block.find(class_=l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ❞")).text
		l1ll1ll_l1_ = l111l1_l1_+block.find(l1l111_l1_ (u"࠭ࡡࠨ❟")).get(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠬ❠"))
		l11l_l1_ = block.find(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠬ❡")).get(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ❢"))
		l1l1lll111_l1_ = block.find(class_=l1l111_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ❣")).text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ❤"))
			l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ❥"))
			l11l_l1_ = l11l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ❦"))
			l1l1lll111_l1_ = l1l1lll111_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ❧"))
		l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ❨"),l1l111_l1_ (u"ࠩࠪ❩")).strip(l1l111_l1_ (u"ࠪࠤࠬ❪"))
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ❫"),l1lllll_l1_+title,l1ll1ll_l1_,522,l11l_l1_,l1l1lll111_l1_)
	PAGINATION(l1lllll1lll_l1_,521)
	return
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ❬"),url,l1l111_l1_ (u"࠭ࠧ❭"),headers,l1l111_l1_ (u"ࠧࠨ❮"),l1l111_l1_ (u"ࠨࠩ❯"),l1l111_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭❰"))
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ❱"),multi_valued_attributes=None)
	l1ll1ll_l1_ = l1lllll1lll_l1_.find(class_=l1l111_l1_ (u"ࠫ࡫ࡲࡥࡹ࠯ࡹ࡭ࡩ࡫࡯ࠨ❲")).find(l1l111_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠬ❳")).get(l1l111_l1_ (u"࠭ࡳࡳࡥࠪ❴"))
	if PY2: l1ll1ll_l1_ = l1ll1ll_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ❵"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ❶"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ❷"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ❸"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭❹"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ❺"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡀࡳࡀࠫ❻")+search
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ❼"),url,l1l111_l1_ (u"ࠨࠩ❽"),headers,l1l111_l1_ (u"ࠩࠪ❾"),l1l111_l1_ (u"ࠪࠫ❿"),l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ➀"))
	if not response.succeeded:
		l11111l111_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡥࡥ࡯ࡶ࡬ࡸࡾ࠵࠿ࡲ࠿ࠪ➁")+search+l1l111_l1_ (u"࠭ࠦࡦࡰࡷ࡭ࡹࡿ࠽ࡸࡱࡵ࡯ࠬ➂")
		l111lllll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡠࡧࡱࡸ࡮ࡺࡹ࠰ࡁࡴࡁࠬ➃")+search+l1l111_l1_ (u"ࠨࠨࡨࡲࡹ࡯ࡴࡺ࠿ࡳࡩࡷࡹ࡯࡯ࠩ➄")
		l111111ll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡢࡩࡳࡺࡩࡵࡻ࠲ࡃࡶࡃࠧ➅")+search+l1l111_l1_ (u"ࠪࠪࡪࡴࡴࡪࡶࡼࡁࡻ࡯ࡤࡦࡱࠪ➆")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➇"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢ฼๊ࠥษูๆษ็ࠫ➈"),l11111l111_l1_,513,l1l111_l1_ (u"࠭ࠧ➉"),search)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➊"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ฿ๆࠡลืาฬ฻ࠧ➋"),l111lllll_l1_,513,l1l111_l1_ (u"ࠩࠪ➌"),search)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➍"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡ฻้ࠤๆ๐ฯ๋๊๊หฯ࠭➎"),l111111ll1_l1_,513,l1l111_l1_ (u"ࠬ࠭➏"),search)
		return
	html = response.content
	l1lllll1lll_l1_ = bs4.BeautifulSoup(html,l1l111_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ➐"),multi_valued_attributes=None)
	l1lll1l1_l1_ = l1lllll1lll_l1_.find_all(class_=l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡶ࡬ࡸࡱ࡫ࠠ࡭ࡧࡩࡸࠬ➑"))
	for block in l1lll1l1_l1_:
		title = block.text
		if PY2:
			title = title.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭➒"))
		title = title.split(l1l111_l1_ (u"ࠩࠫࠫ➓"),1)[0].strip(l1l111_l1_ (u"ࠪࠤࠬ➔"))
		if   l1l111_l1_ (u"ࠫศ฿ๅศๆࠪ➕") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ➖"),l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡸࡱࡵ࡯࠴࠭➗"))
		elif l1l111_l1_ (u"ࠧฤึัหฺ࠭➘") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ➙"),l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ➚"))
		elif l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠬ➛") in title: l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭➜"),l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭➝"))
		else: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➞"),l1lllll_l1_+title,l1ll1ll_l1_,513)
	return
def l1llllll1ll_l1_(url,text):
	global l1l11111_l1_,l1l11lll_l1_
	if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ➟") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ➠"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ➡"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ➢")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭➣"),l1l111_l1_ (u"ࠬࡿࡥࡢࡴࠪ➤"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ➥")]
	elif l1l111_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ➦") in url:
		l1l11111_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ➧"),l1l111_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ➨"),l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ➩")]
		l1l11lll_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭➪"),l1l111_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭➫"),l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ➬")]
	l1l1ll1l_l1_(url,text)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ➭"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ➮"),url,l1l111_l1_ (u"ࠩࠪ➯"),headers,l1l111_l1_ (u"ࠪࠫ➰"),l1l111_l1_ (u"ࠫࠬ➱"),l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ➲"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡦࡰࡴࡰࠤࡦࡩࡴࡪࡱࡱࡁࠧ࠵ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡦࡰࡴࡰࡂࠬ➳"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴࠡࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ➴"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ➵"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭➶"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ➷"))
	url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ➸"),l1l111_l1_ (u"ࠬ࠵࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠧࠩ➹"))
	return url
def l11l1l11l1_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ➺"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ➻")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠨࡁࠪ➼") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭➽"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ➾"),1)
	if filter==l1l111_l1_ (u"ࠫࠬ➿"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭⟀"),l1l111_l1_ (u"࠭ࠧ⟁")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ⟂"))
	if type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⟃"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫ⟄") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬ⟅") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭⟆")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨ⟇")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ⟈")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪ⟉")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ⟊"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭⟋")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬ⟌"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⟍"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⟎")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ⟏"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⟐"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠨࠩ⟑"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⟒"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠪࠫ⟓"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⟔")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟕"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ⟖"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⟗"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ⟘")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ⟙"),l1lllll1_l1_,511)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⟚"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⟛"),l1l111_l1_ (u"ࠬ࠭⟜"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"࠭࠭࠮ࠩ⟝"),l1l111_l1_ (u"ࠧࠨ⟞"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪ⟟") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⟠"):
			if l1l111ll_l1_ not in l1l11111_l1_: continue
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1111lll1l_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⟡")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟢"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ⟣"),l1lllll1_l1_,511)
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟤"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ⟥"),l1lllll1_l1_,515,l1l111_l1_ (u"ࠨࠩ⟦"),l1l111_l1_ (u"ࠩࠪ⟧"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⟨"):
			if l1l111ll_l1_ not in l1l11lll_l1_: continue
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭⟩")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ⟪")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ⟫")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪ⟬")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ⟭")+l1l1ll11_l1_
			if   name==l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ⟮"): name = l1l111_l1_ (u"ࠪห้์ฺ่ࠩ⟯")
			elif name==l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⟰"): name = l1l111_l1_ (u"ࠬอไฺ็็ࠫ⟱")
			elif name==l1l111_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ⟲"): name = l1l111_l1_ (u"ࠧศๆ็฾ฮ࠭⟳")
			elif name==l1l111_l1_ (u"ࠨࡻࡨࡥࡷ࠭⟴"): name = l1l111_l1_ (u"ࠩสุ่์ษࠨ⟵")
			elif name==l1l111_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ⟶"): name = l1l111_l1_ (u"ࠫฬ๊ๅ้ี่ࠫ⟷")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟸"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࡀࠠࠨ⟹")+name,l1lllll1_l1_,514,l1l111_l1_ (u"ࠧࠨ⟺"),l1l111_l1_ (u"ࠨࠩ⟻"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ู่๋ࠩ็วหࠢฦาึ๏ࠧ⟼") in option: continue
			if l1l111_l1_ (u"ࠪห้้ไࠨ⟽") in option: continue
			if l1l111_l1_ (u"ࠫฬ๊ไ฻หࠪ⟾") in option: continue
			option = option.replace(l1l111_l1_ (u"่ࠬวว็ฬࠤࠬ⟿"),l1l111_l1_ (u"࠭ࠧ⠀"))
			if   name==l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ⠁"): name = l1l111_l1_ (u"ࠨษ็๊ํ฿ࠧ⠂")
			elif name==l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⠃"): name = l1l111_l1_ (u"ࠪห้฿ๅๅࠩ⠄")
			elif name==l1l111_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ⠅"): name = l1l111_l1_ (u"ࠬอไๅ฼ฬࠫ⠆")
			elif name==l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ⠇"): name = l1l111_l1_ (u"ࠧศๆึ๊ฮ࠭⠈")
			elif name==l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ⠉"): name = l1l111_l1_ (u"ࠩส่๊๎ำๆࠩ⠊")
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ⠋")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭⠌")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ⠍")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨ⠎")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ⠏")+l1l1ll11_l1_
			if name: title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ⠐")+name
			else: title = option
			if type==l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ⠑"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⠒"),l1lllll_l1_+title,url,514,l1l111_l1_ (u"ࠫࠬ⠓"),l1l111_l1_ (u"ࠬ࠭⠔"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⠕") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩ⠖") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11l1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⠗"),l1lllll_l1_+title,l1llllll_l1_,511)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⠘"),l1lllll_l1_+title,url,515,l1l111_l1_ (u"ࠪࠫ⠙"),l1l111_l1_ (u"ࠫࠬ⠚"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠬࡃࠦࠨ⠛"),l1l111_l1_ (u"࠭࠽࠱ࠨࠪ⠜"))
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠩ⠝"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠨ࠿ࠪ⠞") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠫ⠟"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ⠠"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠫࠬ⠡")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ⠢")
		if l1l111_l1_ (u"࠭ࠥࠨ⠣") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⠤") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ⠥"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭⠦")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⠧") and value!=l1l111_l1_ (u"ࠫ࠵࠭⠨"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ⠩")+key+l1l111_l1_ (u"࠭࠽ࠨ⠪")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⠫"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ⠬")+key+l1l111_l1_ (u"ࠩࡀࠫ⠭")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ⠮"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭⠯"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠬࡃ࠰ࠨ⠰"),l1l111_l1_ (u"࠭࠽ࠨ⠱"))
	return l1l1l111_l1_
l1l11111_l1_ = []
l1l11lll_l1_ = []
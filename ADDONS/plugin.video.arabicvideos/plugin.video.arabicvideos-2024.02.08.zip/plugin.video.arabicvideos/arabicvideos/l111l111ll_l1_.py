# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ⑆")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡅࡈࡆࡢࠫ⑇")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ๅึษิ฽ฮ࠭⑈"),l1l111_l1_ (u"ࠧศฯาฯࠥอไษำส้ั࠭⑉"),l1l111_l1_ (u"ࠨษะำะࠦวๅษ็฽ฬฮࠧ⑊"),l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ⑋"),l1l111_l1_ (u"ࠪหาีหࠡษ็ห฿อๆ๊ࠩ⑌")]
def l11l1ll_l1_(mode,url,text):
	if   mode==440: l1lll_l1_ = l1l1l11_l1_()
	elif mode==441: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==442: l1lll_l1_ = PLAY(url)
	elif mode==443: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==449: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⑍"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭⑎"),l1l111_l1_ (u"࠭ࠧ⑏"),l1l111_l1_ (u"ࠧࠨ⑐"),l1l111_l1_ (u"ࠨࠩ⑑"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⑒"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ⑓"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⑔"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⑕"),l1l111_l1_ (u"࠭ࠧ⑖"),449,l1l111_l1_ (u"ࠧࠨ⑗"),l1l111_l1_ (u"ࠨࠩ⑘"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⑙"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⑚"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⑛")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ⑜"),l111l1_l1_,441)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⑝"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⑞"),l1l111_l1_ (u"ࠨࠩ⑟"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡠ࡯ࡨࡲࡺࡥࡲࡪࡩ࡫ࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ①"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ②"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭③"): continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ④"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⑤")+l1lllll_l1_+title,l1ll1ll_l1_,441)
	return
def l1lll11_l1_(url,l1111ll1_l1_=l1l111_l1_ (u"ࠧࠨ⑥")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⑦"),url,l1l111_l1_ (u"ࠩࠪ⑧"),l1l111_l1_ (u"ࠪࠫ⑨"),l1l111_l1_ (u"ࠫࠬ⑩"),l1l111_l1_ (u"ࠬ࠭⑪"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⑫"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ⑬"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠲ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⑭"),block,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		if l1l111_l1_ (u"ࠩ࠲ࡹࡷࡲ࠯ࠨ⑮") in l1ll1ll_l1_: continue
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ⑯") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⑰"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ⑱") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⑲"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⑳"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⑴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⑵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⑶"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⑷")+title,l1ll1ll_l1_,441)
	return
def l1ll1l11_l1_(url):
	data = {l1l111_l1_ (u"ࠬ࡜ࡩࡦࡹࠪ⑸"):1}
	headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⑹"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⑺")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭⑻"),url,data,headers,l1l111_l1_ (u"ࠩࠪ⑼"),l1l111_l1_ (u"ࠪࠫ⑽"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⑾"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡣࡶࡳࡳࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪ⑿"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ⒀"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⒁"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒂"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡳ࡬ࡀࡩ࡮ࡣࡪࡩࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⒃"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⒄"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ⒅"),l1l111_l1_ (u"ࠬ࠭⒆")).strip(l1l111_l1_ (u"࠭ࠠࠨ⒇"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⒈"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	return
def PLAY(url):
	data = {l1l111_l1_ (u"ࠨࡘ࡬ࡩࡼ࠭⒉"):1}
	headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⒊"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⒋")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ⒌"),url,data,headers,l1l111_l1_ (u"ࠬ࠭⒍"),l1l111_l1_ (u"࠭ࠧ⒎"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⒏"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡺࡥࡹࡩࡨࡂࡴࡨࡥࡒࡧࡳࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⒐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ⒑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭⒒"),l1l111_l1_ (u"ࠫࠬ⒓")).strip(l1l111_l1_ (u"ࠬࠦࠧ⒔"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⒕")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⒖")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡳࡳࡽ࡬ࡰࡣࡧ࠱ࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⒗"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸ࠭࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⒘"),block,re.DOTALL)
		for title,l111l1ll_l1_,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭⒙"),l1l111_l1_ (u"ࠫࠬ⒚"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⒛")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⒜")+l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬ⒝")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⒞"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ⒟"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ⒠"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭⒡"),l1l111_l1_ (u"ࠬ࠱ࠧ⒢"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡵࡀࠫ⒣")+search
	l1lll11_l1_(url)
	return
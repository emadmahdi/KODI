# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ䊶")
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䊷") : l1l111_l1_ (u"ࠧࠨ䊸") }
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧ䊹")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1l1llll1lll_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1llll1lll_l1_():
	message = l1l111_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠥ࠴࠮࠯๋ࠢฬาอฬสࠢส่๎ࠦวฺษาอࠥฮัๆฮฬࠤ๊์ࠠศๆุๅึࠦ࠮࠯࠰ࠣ์ฬ๊ๅษำ่ะࠥำวๅ์สࠤฺฺ๊้ๆࠣ์๏฿ว็์ฺ้๋่ࠣࠦๅฬࠤฺำ๊สࠢ࠱࠲࠳่ࠦๅ้ำหู่ࠥโࠢํฬ็๏ࠠศๆ่์็฿ࠠๆ฼็ๆࠥอไ๊่ࠢหฺࠥวยࠢส่้ํࠧ䊺")
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䊻"),l1l111_l1_ (u"ࠫࠬ䊼"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䊽"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊾"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䊿"),l1l111_l1_ (u"ࠨࠩ䋀"),189,l1l111_l1_ (u"ࠩࠪ䋁"),l1l111_l1_ (u"ࠪࠫ䋂"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䋃"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䋄"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䋅")+l1lllll_l1_+l1l111_l1_ (u"ࠧษ๊ๆืࠥอ่โ์ึࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ䋆"),l111l1_l1_,181,l1l111_l1_ (u"ࠨࠩ䋇"),l1l111_l1_ (u"ࠩࠪ䋈"),l1l111_l1_ (u"ࠪࡦࡴࡾ࠭ࡰࡨࡩ࡭ࡨ࡫ࠧ䋉"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋊"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䋋")+l1lllll_l1_+l1l111_l1_ (u"࠭รฮัฮࠤฬ๊วโๆส้ࠬ䋌"),l111l1_l1_,181,l1l111_l1_ (u"ࠧࠨ䋍"),l1l111_l1_ (u"ࠨࠩ䋎"),l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䋏"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋐"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䋑")+l1lllll_l1_+l1l111_l1_ (u"ࠬะไ๋ใี๎ํ์ࠠๆ๊ไ๎ืࠦไศ่าࠫ䋒"),l111l1_l1_,181,l1l111_l1_ (u"࠭ࠧ䋓"),l1l111_l1_ (u"ࠧࠨ䋔"),l1l111_l1_ (u"ࠨࡶࡹࠫ䋕"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋖"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䋗")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊วไอิࠤฺ๊ว่ัฬࠫ䋘"),l111l1_l1_,181,l1l111_l1_ (u"ࠬ࠭䋙"),l1l111_l1_ (u"࠭ࠧ䋚"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䋛"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䋜"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䋝")+l1lllll_l1_+l1l111_l1_ (u"ࠪว็๎้ࠡษ็หๆ๊วๆࠢส่าอไ๋หࠪ䋞"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䋟"),l1l111_l1_ (u"ࠬ࠭䋠"),l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䋡"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䋢"),headers,l1l111_l1_ (u"ࠨࠩ䋣"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䋤"))
	items = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠸࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䋥"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋦"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䋧")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ䋨")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ䋩"),headers,l1l111_l1_ (u"ࠨࠩ䋪"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ䋫"))
	if type==l1l111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ䋬"): block = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂศำฯฬࠢส่ศ็ไศ็࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࡨ࠲ࠩ䋭"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠬࡨ࡯ࡹ࠯ࡲࡪ࡫࡯ࡣࡦࠩ䋮"): block = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄศ้ๅึࠤฬ๎แ๋ี้ࠣํ็๊ำࠢ็ห๋ี࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭䋯"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䋰"): block = re.findall(l1l111_l1_ (u"ࠨࡤࡷࡲ࠲࠸࠭ࡰࡸࡨࡶࡱࡧࡹࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭䋱"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䋲"): block = re.findall(l1l111_l1_ (u"ࠪࡦࡹࡴ࠭࠲ࠢࡥࡸࡳ࠳ࡡࡣࡵࡲࡰࡾ࠮࠮ࠫࡁࠬࡦࡹࡴ࠭࠳ࠢࡥࡸࡳ࠳ࡡࡣࡵࡲࡰࡾ࠭䋳"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠫࡹࡼࠧ䋴"): block = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃะไ๋ใี๎ํ์ࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲ࡬ࠨࠧ䋵"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䋶"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䋷")]:
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡷࡽࡱ࡫࠽ࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䋸"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥ࠷ࡠ࠶࠭࠺࡟࠮ࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨ࡯ࡵࡶࡲࡱ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅࡨࡳࡧࡩࡁ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䋹"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ䋺"),l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ䋻"),l1l111_l1_ (u"ࠬอไฮๆๅ๋ࠬ䋼"),l1l111_l1_ (u"ู࠭าุࠪ䋽"),l1l111_l1_ (u"ࠧࡓࡣࡺࠫ䋾"),l1l111_l1_ (u"ࠨࡕࡰࡥࡨࡱࡄࡰࡹࡱࠫ䋿"),l1l111_l1_ (u"ࠩส฽้อๆࠨ䌀"),l1l111_l1_ (u"ࠪหัุวยࠩ䌁")]
	for l1ll1l_l1_,l1l1llll111l_l1_,l1l1lllll111_l1_,l1l1lllll11l_l1_ in items:
		if type in [l1l111_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䌂"),l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䌃")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1llll111l_l1_,l1l1lllll111_l1_,l1l1lllll11l_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1llll111l_l1_,l1l1lllll111_l1_,l1l1lllll11l_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࠿ࡷ࡫ࡨࡻࡂࡺࡲࡶࡧࠪ䌄"),l1l111_l1_ (u"ࠧࠨ䌅"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䌆") in title or l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䌇") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䌈") + title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䌉"),l1l111_l1_ (u"ࠬ࠭䌊")).replace(l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䌋"),l1l111_l1_ (u"ࠧࠨ䌌"))
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ䌍"))
		if l1l111_l1_ (u"ࠩส่า๊โสࠩ䌎") in title or l1l111_l1_ (u"ࠪห้ำไใ้ࠪ䌏") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩ䌐"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䌑") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䌒"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䌓") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䌔"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䌕") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䌖"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࠬ䌗"):
		items = re.findall(l1l111_l1_ (u"ࠬࡢ࡮࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䌘"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧ䌙"),l1l111_l1_ (u"ࠧࠨ䌚"))
			if title!=l1l111_l1_ (u"ࠨࠩ䌛"):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䌜"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ䌝")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䌞"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䌟"),headers,l1l111_l1_ (u"࠭ࠧ䌠"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䌡"))
	block = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾࠯ࠬࡂ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠭ࡡ࠰࠮࠻ࡠ࠯࠮ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䌢"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣ࡟࠵࠳࠹࡞࠭ࠪ䌣"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䌤") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸࡔࡵ࡮ࡤࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䌥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䌦"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"࠭ࠨศๆะ่็ฯࡼศๆะ่็ํࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ䌧"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䌨"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠨࠪࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭䌩"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䌪"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠪࠤࠬ䌫") + title[0][1]
			else: title = l1l111_l1_ (u"ࠫࠬ䌬")
			title = name + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ䌭") + l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭䌮") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䌯"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䌰") in title or l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䌱") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䌲") + title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䌳"),l1l111_l1_ (u"ࠬ࠭䌴")).replace(l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䌵"),l1l111_l1_ (u"ࠧࠨ䌶"))
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䌷"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1llll1l11_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䌸"))
	l1lllll1_l1_ = l1l1llll1l11_l1_[0]
	del l1l1llll1l11_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䌹"),headers,l1l111_l1_ (u"ࠫࠬ䌺"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䌻"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡦࡰࡰࡷ࠱ࡸ࡯ࡺࡦ࠼ࠣ࠶࠺ࡶࡸ࠼ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䌼"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1llll1l11_l1_: l1l1llll1l11_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1llll1l11_l1_:
		if l1l111_l1_ (u"ࠧ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭䌽") in l1ll1ll_l1_:
			l1l1lll1llll_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1lll1llll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡤ࡭ࡳ࠭䌾"))
	for l1ll1ll_l1_ in l1l1llll1l11_l1_:
		if l1l111_l1_ (u"ࠩ࠽࠳࠴ࡼࡢ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࠬ䌿") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䍀"),headers,l1l111_l1_ (u"ࠫࠬ䍁"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ䍂"))
			html = html.decode(l1l111_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡹ࠭࠲࠴࠸࠺ࠬ䍃")).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䍄"))
			html = html.replace(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䍅"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䍆"))
			html = html.replace(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䍇"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䍈"))
			html = html.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡥࡶࠥ࠵࠾࠽ࡦ࡬ࡺࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࡄࠧ䍉"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䍊"))
			html = html.replace(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡤࡲࡶࡩ࡫ࡲࠣࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠪ䍋"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䍌"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䍍"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1llll1111_l1_,l1ll111lll11_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠪࠫ䍎")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠰࠭ࡃࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮࠰࠮࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䍏"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ䍐") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠪ䍑")+l1l111_l1_ (u"ࠧࠤࠩ䍒")+l1l111_l1_ (u"ࠨ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠪ䍓")+l1l111_l1_ (u"ࠩࠦࠫ䍔")+l1l111_l1_ (u"ࠪ࠷࠸࠹ࠢࠡ࠱ࡁࠬ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䍕"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭䍖") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࠫ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠨ䍗")+l1l111_l1_ (u"࠭ࠣࠨ䍘")+l1l111_l1_ (u"ࠧ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠩ䍙")+l1l111_l1_ (u"ࠨࠥࠪ䍚")+l1l111_l1_ (u"ࠩ࠶࠷࠸ࠨࠠ࠰ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䍛"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠪࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䍜")
						l1l1llll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࠮࠮ࠫࡁࠬ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࠫࡳࡳࡲࡩ࡯ࡧࡿࡧࡴࡳࠩ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱ࠪ䍝"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠬࡄࠠࠫࠪ࡞ࡢࡁࡄ࡝ࠬࠫࠣ࠮ࡁ࠭䍞"),l1l1llll1ll1_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"࠭ࠠࠨ䍟").join(title)
						title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䍠"))
						title = title.replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䍡"),l1l111_l1_ (u"ࠩࠣࠫ䍢")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䍣"),l1l111_l1_ (u"ࠫࠥ࠭䍤")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䍥"),l1l111_l1_ (u"࠭ࠠࠨ䍦")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䍧"),l1l111_l1_ (u"ࠨࠢࠪ䍨")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䍩"),l1l111_l1_ (u"ࠪࠤࠬ䍪"))
						l1l1llll1111_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫศิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ืๅ๊ห࠾ࠬ䍫"), l1l1llll1111_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1llll1111_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠩࠣࠩ䍬"),block,re.DOTALL)
				l1l1lll1lll1_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1lll1lll1_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡆࡰࡴࡸࡱࠬ䍭"))
				block = block.replace(l1l111_l1_ (u"ࠧแࠩ䍮"),l1l111_l1_ (u"ࠨࠩ䍯"))
				block = block.replace(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠷࠴࠻࠹࠷࠲࠲࠹࠸࠶࠾࠼࠮ࡱࡰࡪࠦࠬ䍰"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䍱"))
				block = block.replace(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠶࠳࠺࠸࠶࠸࠱࠸࠷࠵࠽࠻࠴ࡰ࡯ࡩࠥࠫ䍲"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡦࡴࡺࡨࠣࠢࠣࡠࡳࠦࠠࠨ䍳"))
				block = block.replace(l1l111_l1_ (u"࠭ำ๋ำไีฬะࠠศๆอั๊๐ไࠨ䍴"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ䍵"))
				block = block.replace(l1l111_l1_ (u"ࠨำ๋หอ฽ࠠศๆอั๊๐ไࠨ䍶"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠣࠤࡡࡴࠠࠡࠩ䍷"))
				block = block.replace(l1l111_l1_ (u"ࠪื๏ืแาษอࠤฬ๊ๅีษ๊ำࠬ䍸"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ䍹"))
				block = block.replace(l1l111_l1_ (u"ࠬื่ศสฺࠤฬ๊ๅีษ๊ำࠬ䍺"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡼࡧࡴࡤࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䍻"))
				l1l1llll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࡟ࡨ࠰ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䍼"),block,re.DOTALL)
				for l1l1llll1l1l_l1_ in l1l1llll11l1_l1_:
					type = re.findall(l1l111_l1_ (u"ࠨࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭䍽"),l1l1llll1l1l_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䍾"): type = l1l111_l1_ (u"ࠪࡣࡤ࠭䍿")+type[0]
						else: type = l1l111_l1_ (u"ࠫࠬ䎀")
					items = re.findall(l1l111_l1_ (u"ࠬ࠮࠿࠽ࠣ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵ࠩࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀ࠴࡬࡯࡯ࡶࡁ࠲࠯ࡅࡼ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿ࡦࡷࠦ࠯࠿࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢࠨ䎁"),l1l1llll1l1l_l1_,re.DOTALL)
					for l1l1llll11ll_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"࠭ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬࠬࡀࠬ䎂"),l1l1llll11ll_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䎃") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1l1l1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ䎄"),headers,l1l111_l1_ (u"ࠩࠪ䎅"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䎆"))
	items = re.findall(l1l111_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䎇"),html,re.DOTALL)
	if items:
		l1l1lllll1l1_l1_ = items[-1]
		l1llll_l1_.append(l1l1lllll1l1_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓ࡯ࡣ࡫࡯ࡩࠬ䎈"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䎉"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ䎊"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ䎋"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ䎌"),l1l111_l1_ (u"ࠪ࠯ࠬ䎍"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䎎"),headers,l1l111_l1_ (u"ࠬ࠭䎏"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭䎐"))
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮࠿ࠩ䎑"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠨࠩ䎒") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠩส่่๊้ࠠสา์๋ࠦแๅฬิࠫ䎓") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ䎔"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠫࠬ䎕")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䎖")+search+l1l111_l1_ (u"࠭ࠦ࡮ࡥࡤࡸࡂ࠭䎗")+category
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫⶺ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩⶻ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠫⶼ"),l1l111_l1_ (u"ࠬออะอࠣห้ฮัศ็ฯࠫⶽ"),l1l111_l1_ (u"࠭วฮัฮࠤฬ๊วๅ฻สฬࠬⶾ"),l1l111_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭⶿")]
def l11l1ll_l1_(mode,url,text):
	if   mode==80: l1lll_l1_ = l1l1l11_l1_()
	elif mode==81: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==82: l1lll_l1_ = PLAY(url)
	elif mode==83: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==89: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬⷀ"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪⷁ"),l1l111_l1_ (u"ࠪࠫⷂ"),l1l111_l1_ (u"ࠫࠬⷃ"),l1l111_l1_ (u"ࠬ࠭ⷄ"),l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪⷅ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫⷆ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⷇"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩⷈ"),l1l111_l1_ (u"ࠪࠫⷉ"),89,l1l111_l1_ (u"ࠫࠬⷊ"),l1l111_l1_ (u"ࠬ࠭ⷋ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪⷌ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⷍ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⷎ"),l1l111_l1_ (u"ࠩࠪ⷏"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬⷐ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⷑ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࡄ࡯ࡴࡦ࡯ࡀࠫⷒ")+l111l1l1l_l1_+l1l111_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧⷓ")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷔ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⷕ")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⷖ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⷗"),l1l111_l1_ (u"ࠫࠬⷘ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢࡸ࠰ࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡺࡃ࠭ⷙ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⷚ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩⷛ"): continue
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷜ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⷝ")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠪࠫⷞ")):
	items = []
	if l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ⷟") in url or l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ⷠ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬⷡ"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧⷢ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ⷣ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪⷤ"),l1l111_l1_ (u"ࠪࠫⷥ"),l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪⷦ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩⷧ"),url,l1l111_l1_ (u"࠭ࠧⷨ"),l1l111_l1_ (u"ࠧࠨⷩ"),l1l111_l1_ (u"ࠨࠩⷪ"),l1l111_l1_ (u"ࠩࠪⷫ"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩⷬ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ⷭ"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬⷮ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⷯ"),block,re.DOTALL)
		elif l1l111_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠧⷰ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪⷱ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧⷲ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⷳ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪⷴ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬⷵ"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫⷶ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭ⷷ"),l1l111_l1_ (u"ࠨๅ็๎อ࠭ⷸ"),l1l111_l1_ (u"ࠩส฽้อๆࠨⷹ"),l1l111_l1_ (u"๋ࠪิอแࠨⷺ"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫⷻ"),l1l111_l1_ (u"ࠬ฿ัืࠩⷼ"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭ⷽ"),l1l111_l1_ (u"ࠧศๆห์๊࠭ⷾ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪⷿ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ⸀"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⸁") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸂"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
		elif l1l111_l1_ (u"ูࠬไศี็ࠫ⸃") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⸄"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ⸅") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⸆") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸇"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ⸈") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸉"),l1lllll_l1_+title,l1ll1ll_l1_,81,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸊"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"࠭ࠧ⸋"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫ⸌"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⸍"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠤࠥ⸎"): continue
				if title!=l1l111_l1_ (u"ࠪࠫ⸏"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸐"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⸑")+title,l1ll1ll_l1_,81)
	if l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭⸒") in url or l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ⸓") in url:
		if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ⸔") in url:
			url = url.replace(l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩ⸕"),l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫ⸖"))+l1l111_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠸࠰ࠨ⸗")
		elif l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭⸘") in url:
			url,offset = url.split(l1l111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨ⸙"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩ⸚")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸛"),l1lllll_l1_+l1l111_l1_ (u"๊๊ࠩฬ้ࠠศๆ่ึ๏ีࠧ⸜"),url,81)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⸝"),url,l1l111_l1_ (u"ࠫࠬ⸞"),l1l111_l1_ (u"ࠬ࠭⸟"),l1l111_l1_ (u"࠭ࠧ⸠"),l1l111_l1_ (u"ࠧࠨ⸡"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⸢"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࡂࡺࡕࡨࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⸣"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡱ࡯ࡳࡵ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⸤"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭⸥") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⸦"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸧"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡰࡥ࡬࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⸨"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⸩"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⸪"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ⸫"),l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡲࡵࡶࡪࡧࡶ࠳ࠬ⸬"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⸭"),l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⸮"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⸯ"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⸰"),l1l111_l1_ (u"ࠩࠪ⸱"),l1l111_l1_ (u"ࠪࠫ⸲"),l1l111_l1_ (u"ࠫࠬ⸳"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⸴"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ⸵"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⸶"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ⸷"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠤࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ⸸"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭⸹"),l1l111_l1_ (u"ࠫࠬ⸺")).strip(l1l111_l1_ (u"ࠬࠦࠧ⸻"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩ⸼")+server+l1l111_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩ⸽")+l11l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ⸾")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⸿")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⹀")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⹁"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⹂"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⹃")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⹄")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⹅"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ⹆"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ⹇"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭⹈"),l1l111_l1_ (u"ࠬ࠳ࠧ⹉"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⹊")+search+l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭⹋")
	l1lll11_l1_(url)
	return
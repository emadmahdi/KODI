# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ᳼")
def l11l1ll_l1_(mode,url):
	if   mode==330: l1lll_l1_ = l1l11l1111_l1_()
	elif mode==331: l1lll_l1_ = PLAY(url)
	elif mode==332: l1lll_l1_ = l11llllll1_l1_()
	elif mode==333: l1lll_l1_ = l11ll1ll11_l1_()
	elif mode==334: l1lll_l1_ = l1lll1ll1l_l1_(url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lll1ll1l_l1_(l11lll11ll_l1_):
	try: os.remove(l11lll11ll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭᳽")))
	except: os.remove(l11lll11ll_l1_)
	return
def PLAY(url):
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᳾"))
	return
def l11ll1ll11_l1_():
	message = l1l111_l1_ (u"ࠪวีํศࠡว็ํࠥืวษูࠣห้็๊ะ์๋ࠤศ๎ࠠศๆุ์ฯࠦแ๋ࠢส่๊๎โฺࠢส่๊฽ไ้สࠣฯ๊ࠦรื฼ฺࠤ฾๊้ࠡิิࠤฬ๊โศศ่อࠥอไ๋็ํ๊ࠥัๅࠡลัฮฬืࠠࠣฬะ้๏๊ࠠๆๆไหฯࠦแ๋ัํ์ࠧࠦหๆࠢสาฯอัࠡัๅอࠥอไึ๊ิอࠥ๎วฯฬสีࠥ์ฺ่่่ࠢๆࠦวๅื๋ีฮ่ࠦษ฻า๋ฬࠦำ้ใࠣ๎อีรࠡษ็ฮา๋๊ๅࠩ᳿")
	l1111l1_l1_(l1l111_l1_ (u"ࠫࠬᴀ"),l1l111_l1_ (u"ࠬ࠭ᴁ"),l1l111_l1_ (u"࠭ืา์ๅอࠥะอๆ์็ࠤฬ๊ๅๅใสฮࠬᴂ"),message)
	return
def l1l11l1111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᴃ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ฻ึ๐โสࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᴄ"),l1l111_l1_ (u"ࠩࠪᴅ"),333)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᴆ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣส฻์ํี๋ࠥใศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᴇ"),l1l111_l1_ (u"ࠬ࠭ᴈ"),332)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᴉ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᴊ"),l1l111_l1_ (u"ࠨࠩᴋ"),9999)
	l1l111l111_l1_ = l11llll1l1_l1_()
	mtime = os.stat(l1l111l111_l1_).st_mtime
	l11lllllll_l1_ = []
	if PY3: l1l1111lll_l1_ = os.listdir(l1l111l111_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᴌ")))
	else: l1l1111lll_l1_ = os.listdir(l1l111l111_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᴍ")))
	for filename in l1l1111lll_l1_:
		if PY3: filename = filename.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᴎ"))
		if not filename.startswith(l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡢࠫᴏ")): continue
		filepath = os.path.join(l1l111l111_l1_,filename)
		mtime = os.path.getmtime(filepath)
		l11lllllll_l1_.append([filename,mtime])
	l11lllllll_l1_ = sorted(l11lllllll_l1_,reverse=True,key=lambda key: key[1])
	for filename,mtime in l11lllllll_l1_:
		if PY2:
			try: filename = filename.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᴐ"))
			except: pass
			filename = filename.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᴑ"))
		filepath = os.path.join(l1l111l111_l1_,filename)
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᴒ"),filename,filepath,331)
	return
def l11llll1l1_l1_():
	l1l111l111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬᴓ"))
	if l1l111l111_l1_: return l1l111l111_l1_
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ᴔ"),addoncachefolder)
	return addoncachefolder
def l11llllll1_l1_():
	l1l111l111_l1_ = l11llll1l1_l1_()
	l1l1111l11_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᴕ"),l1l111_l1_ (u"ࠬ࠭ᴖ"),l1l111_l1_ (u"࠭ࠧᴗ"),l1l111_l1_ (u"ࠧๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠫᴘ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᴙ")+l1l111l111_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮่าสࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣฮ฿๐๊าࠢส่๊้ว็ࠢยࠫᴚ"))
	if l1l1111l11_l1_==1:
		newpath = l1l111111l_l1_(3,l1l111_l1_ (u"้่ࠪอๆࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧᴛ"),l1l111_l1_ (u"ࠫࡱࡵࡣࡢ࡮ࠪᴜ"),l1l111_l1_ (u"ࠬ࠭ᴝ"),False,True,l1l111l111_l1_)
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᴞ"),l1l111_l1_ (u"ࠧࠨᴟ"),l1l111_l1_ (u"ࠨࠩᴠ"),l1l111_l1_ (u"่ࠩ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไหฯ่๎้࠭ᴡ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᴢ")+l1l111l111_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ๊ิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭ᴣ"))
		if l1llll111l_l1_==1:
			settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨᴤ"),newpath)
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧᴥ"),l1l111_l1_ (u"ࠧࠨᴦ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᴧ"),l1l111_l1_ (u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪᴨ"))
	return
def l11lll111l_l1_(url,l11ll1l11l_l1_=l1l111_l1_ (u"ࠪࠫᴩ"),l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬᴪ")):
	l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᴫ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᴬ")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪᴭ"))
	if not l11ll1l11l_l1_: l11ll1l11l_l1_ = GET_VIDEOFILETYPE(url)
	l1l111l111_l1_ = l11llll1l1_l1_()
	l1l111l1ll_l1_ = CLEAN_MENU_LABEL()
	filename = l1l111l1ll_l1_.replace(l1l111_l1_ (u"ࠨࠢࠪᴮ"),l1l111_l1_ (u"ࠩࡢࠫᴯ"))
	filename = WINDOWS_FILENAME(filename)
	filename = l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩᴰ")+str(int(now))[-4:]+l1l111_l1_ (u"ࠫࡤ࠭ᴱ")+filename+l11ll1l11l_l1_
	l11ll1ll1l_l1_ = os.path.join(l1l111l111_l1_,filename)
	headers = {}
	headers[l1l111_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧᴲ")] = l1l111_l1_ (u"࠭ࠧᴳ")
	headers[l1l111_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧᴴ")] = l1l111_l1_ (u"ࠨࠬ࠲࠮ࠬᴵ")
	url = url.replace(l1l111_l1_ (u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬᴶ"),l1l111_l1_ (u"ࠪࠫᴷ"))
	if l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩᴸ") in url:
		l1lllll1_l1_,l11ll1l1l1_l1_ = url.rsplit(l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᴹ"),1)
		l11ll1l1l1_l1_ = l11ll1l1l1_l1_.replace(l1l111_l1_ (u"࠭ࡼࠨᴺ"),l1l111_l1_ (u"ࠧࠨᴻ")).replace(l1l111_l1_ (u"ࠨࠨࠪᴼ"),l1l111_l1_ (u"ࠩࠪᴽ"))
	else: l1lllll1_l1_,l11ll1l1l1_l1_ = url,None
	if not l11ll1l1l1_l1_: l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	if l11ll1l1l1_l1_: headers[l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᴾ")] = l11ll1l1l1_l1_
	if l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᴿ") in l1lllll1_l1_: l1lllll1_l1_,l11lll1ll1_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧᵀ"),1)
	else: l1lllll1_l1_,l11lll1ll1_l1_ = l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧᵁ")
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠧࡽࠩᵂ")).strip(l1l111_l1_ (u"ࠨࠨࠪᵃ")).strip(l1l111_l1_ (u"ࠩࡿࠫᵄ")).strip(l1l111_l1_ (u"ࠪࠪࠬᵅ"))
	l11lll1ll1_l1_ = l11lll1ll1_l1_.replace(l1l111_l1_ (u"ࠫࢁ࠭ᵆ"),l1l111_l1_ (u"ࠬ࠭ᵇ")).replace(l1l111_l1_ (u"࠭ࠦࠨᵈ"),l1l111_l1_ (u"ࠧࠨᵉ"))
	if l11lll1ll1_l1_:	headers[l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᵊ")] = l11lll1ll1_l1_
	l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᵋ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᵌ")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧᵍ")+str(headers)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᵎ")+l11ll1ll1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᵏ"))
	l1l11l111l_l1_ = 1024*1024
	l1l111l1l1_l1_ = 0
	try:
		l1l111l11l_l1_ =	xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪᵐ"))
		l1l111l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧ࠯ࠬᵑ"),l1l111l11l_l1_)
		l1l111l1l1_l1_ = int(l1l111l11l_l1_[0])
	except: pass
	if not l1l111l1l1_l1_:
		try:
			l1l1111l1l_l1_ = os.l11ll1l111_l1_(l1l111l111_l1_)
			l1l111l1l1_l1_ = l1l1111l1l_l1_.f_frsize*l1l1111l1l_l1_.f_bavail//l1l11l111l_l1_
		except: pass
	if not l1l111l1l1_l1_:
		try:
			l1l1111l1l_l1_ = os.l1l111llll_l1_(l1l111l111_l1_)
			l1l111l1l1_l1_ = l1l1111l1l_l1_.f_frsize*l1l1111l1l_l1_.f_bavail//l1l11l111l_l1_
		except: pass
	if not l1l111l1l1_l1_:
		try:
			import shutil
			total,l11lllll1l_l1_,l11llll11l_l1_ = shutil.l1l11l11ll_l1_(l1l111l111_l1_)
			l1l111l1l1_l1_ = l11llll11l_l1_//l1l11l111l_l1_
		except: pass
	if not l1l111l1l1_l1_:
		l1l11l1l11_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨᵒ"),l1l111_l1_ (u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪᵓ"),l1l111_l1_ (u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨᵔ"),l1l111_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᵕ"))
		l1l1111111_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫᵖ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡙ࠧࠡࠢࠣࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡷ࡬ࡪࠦࡤࡪࡵ࡮ࠤ࡫ࡸࡥࡦࠢࡶࡴࡦࡩࡥࠨᵗ"))
		return False
	if l11ll1l11l_l1_==l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧᵘ"):
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11l1_l1_(l1lllll1_l1_,headers)
		if len(l1l1lll1_l1_)==0:
			l1ll1lll_l1_(l1l111_l1_ (u"ࠩไุ้ࠦแ๋ࠢศ๎ัอฯࠡ็็ๅࠥอไหฯ่๎้࠭ᵙ"),l1l111_l1_ (u"ࠪࠫᵚ"))
			return False
		elif len(l1l1lll1_l1_)==1: l11l11l_l1_ = 0
		elif len(l1l1lll1_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษࠩᵛ"), l1l1lll1_l1_)
			if l11l11l_l1_ == -1 :
				l1ll1lll_l1_(l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอั๊๐ไࠨᵜ"),l1l111_l1_ (u"࠭ࠧᵝ"))
				return False
		l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	filesize = 0
	if l11ll1l11l_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ᵞ"):
		l11ll1ll1l_l1_ = l11ll1ll1l_l1_.rsplit(l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧᵟ"))[0]+l1l111_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧᵠ")
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᵡ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬᵢ"),headers,l1l111_l1_ (u"ࠬ࠭ᵣ"),l1l111_l1_ (u"࠭ࠧᵤ"),l1l111_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧᵥ"))
		l11llll1ll_l1_ = response.content
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩᵦ"),l11llll1ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡸࠧᵧ"),re.DOTALL)
		if not l1ll_l1_:
			l1l1111111_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨᵨ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᵩ")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨᵪ"))
			return False
		l1ll1ll_l1_ = l1ll_l1_[0]
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᵫ")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧ࠰࠱ࠪᵬ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨ࠼ࠪᵭ"),1)[0]+l1l111_l1_ (u"ࠩ࠽ࠫᵮ")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࠳ࠬᵯ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᵰ"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧᵱ"),1)[0]+l1l111_l1_ (u"࠭࠯ࠨᵲ")+l1ll1ll_l1_
		response = requests.request(l1l111_l1_ (u"ࠧࡈࡇࡗࠫᵳ"),l1ll1ll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11llll111_l1_ = len(l1ll_l1_)
		filesize = chunksize*l11llll111_l1_
	else:
		chunksize = 1*l1l11l111l_l1_
		response = requests.request(l1l111_l1_ (u"ࠨࡉࡈࡘࠬᵴ"),l1lllll1_l1_,headers=headers,verify=False,stream=True)
		if l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪᵵ") in response.headers: filesize = int(response.headers[l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫᵶ")])
		l11llll111_l1_ = int(filesize//chunksize)
	l1l111ll11_l1_ = int(filesize//l1l11l111l_l1_)+1
	if filesize<21000:
		l1l1111111_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩᵷ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡶࡲࡳࠥࡹ࡭ࡢ࡮࡯ࠤࡴࡸࠠࡪࡶࠣ࡭ࡸࠦ࡭࠴ࡷ࠻ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᵸ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᵹ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᵺ")+str(l1l111l1l1_l1_)+l1l111_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫᵻ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬᵼ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫᵽ"),l1l111_l1_ (u"ࠫࠬᵾ"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᵿ"),l1l111_l1_ (u"࠭แีๆࠣๅ๏ࠦๅฺำไอࠥำฬๆ่่ࠢๆࠦวๅใํำ๏๎ࠠฤ๊ࠣห้๋ไโุࠢ฾๏ืࠠอัสࠤํ๊็ัษ่ࠣฬ๊ࠦๆๅ้ࠤ้๊ศา่ส้ัࠦสฮ็ํ่ࠥํะศࠢส่๊๊แࠨᶀ"))
		return False
	l11lll1l1l_l1_ = 400
	l11lll1111_l1_ = l1l111l1l1_l1_-l1l111ll11_l1_
	if l11lll1111_l1_<l11lll1l1l_l1_:
		l1l1111111_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬᶁ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᶂ")+l1lllll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᶃ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩᶄ")+str(l1l111l1l1_l1_)+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࠯ࠣࠫᶅ")+str(l11lll1l1l_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᶆ")+l11ll1ll1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᶇ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᶈ"),l1l111_l1_ (u"ࠨࠩᶉ"),l1l111_l1_ (u"ࠩ็หࠥ๐่อัุ้ࠣออสࠢๆหๆ๐ษࠡๆ็ฮา๋๊ๅࠩᶊ"),l1l111_l1_ (u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣัั๋็ࠡࠩᶋ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢࠪᶌ")+str(l1l111l1l1_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡ็่๊ำวโฺฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอี่็ุ่ࠢฬ้ไࠡ์ฯฬࠥหศใษฤࠤࠬᶍ")+str(l11lll1l1l_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢไหึเษࠡัสส๊อ้้ࠠำหู๋ࠥ็ษ๊ࠤศ์ࠠอ้สึ่ࠦไศࠢอ์ัีࠠโ์๊ࠤู๊วฮหࠣ็ฬ็๊สࠢ็ฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศࠨᶎ"))
		return False
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧᶏ"),l1l111_l1_ (u"ࠨࠩᶐ"),l1l111_l1_ (u"ࠩࠪᶑ"),l1l111_l1_ (u"๋้ࠪࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢยࠫᶒ"),l1l111_l1_ (u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤาาๅ่ࠢอๆึ๐ศศࠢࠪᶓ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣฮ็ื๊ษษࠣࠫᶔ")+str(l1l111l1l1_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋๋ࠢีอࠠศๆ่่ๆࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ้๊สฮ็ํ่๋ࠥๆࠡษ็ษ๋ะั็ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩᶕ"))
	if l1llll111l_l1_!=1:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᶖ"),l1l111_l1_ (u"ࠨࠩᶗ"),l1l111_l1_ (u"ࠩࠪᶘ"),l1l111_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᶙ"))
		l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᶚ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡲࡦࡨࡸࡷࡪࡪࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡱࡩࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᶛ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᶜ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪᶝ"))
		return False
	l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᶞ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠧᶟ"))
	l1l1111ll1_l1_ = l1l111ll1l_l1_()
	l1l1111ll1_l1_.create(l11ll1ll1l_l1_,l1l111_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫᶠ"))
	l11lll1lll_l1_ = True
	t1 = time.time()
	if PY3: file = open(l11ll1ll1l_l1_,l1l111_l1_ (u"ࠫࡼࡨࠧᶡ"))
	else: file = open(l11ll1ll1l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᶢ")),l1l111_l1_ (u"࠭ࡷࡣࠩᶣ"))
	if l11ll1l11l_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ᶤ"):
		for l1l111lll1_l1_ in range(1,l11llll111_l1_+1):
			l1ll1ll_l1_ = l1ll_l1_[l1l111lll1_l1_-1]
			if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᶥ")):
				if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠩ࠲࠳ࠬᶦ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠾ࠬᶧ"),1)[0]+l1l111_l1_ (u"ࠫ࠿࠭ᶨ")+l1ll1ll_l1_
				elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࠵ࠧᶩ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᶪ"))+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩᶫ"),1)[0]+l1l111_l1_ (u"ࠨ࠱ࠪᶬ")+l1ll1ll_l1_
			response = requests.request(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᶭ"),l1ll1ll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11ll1llll_l1_ = time.time()
			l11ll1l1ll_l1_ = l11ll1llll_l1_-t1
			l11ll1lll1_l1_ = l11ll1l1ll_l1_//l1l111lll1_l1_
			l1l11111l1_l1_ = l11ll1lll1_l1_*(l11llll111_l1_+1)
			l11lll11l1_l1_ = l1l11111l1_l1_-l11ll1l1ll_l1_
			l1l11111ll_l1_(l1l1111ll1_l1_,int(100*l1l111lll1_l1_//(l11llll111_l1_+1)),l1l111_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫᶮ"),l1l111_l1_ (u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫᶯ"),str(l1l111lll1_l1_*chunksize//l1l11l111l_l1_)+l1l111_l1_ (u"ࠬ࠵ࠧᶰ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫᶱ")+time.strftime(l1l111_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤᶲ"),time.gmtime(l11lll11l1_l1_))+l1l111_l1_ (u"ࠨࠢใࠫᶳ"))
			if l1l1111ll1_l1_.iscanceled():
				l11lll1lll_l1_ = False
				break
	else:
		l1l111lll1_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l1l111lll1_l1_ = l1l111lll1_l1_+1
			l11ll1llll_l1_ = time.time()
			l11ll1l1ll_l1_ = l11ll1llll_l1_-t1
			l11ll1lll1_l1_ = l11ll1l1ll_l1_/l1l111lll1_l1_
			l1l11111l1_l1_ = l11ll1lll1_l1_*(l11llll111_l1_+1)
			l11lll11l1_l1_ = l1l11111l1_l1_-l11ll1l1ll_l1_
			l1l11111ll_l1_(l1l1111ll1_l1_,int(100*l1l111lll1_l1_/(l11llll111_l1_+1)),l1l111_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᶴ"),l1l111_l1_ (u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪᶵ"),str(l1l111lll1_l1_*chunksize//l1l11l111l_l1_)+l1l111_l1_ (u"ࠫ࠴࠭ᶶ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪᶷ")+time.strftime(l1l111_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᶸ"),time.gmtime(l11lll11l1_l1_))+l1l111_l1_ (u"ࠧࠡโࠪᶹ"))
			if l1l1111ll1_l1_.iscanceled():
				l11lll1lll_l1_ = False
				break
		response.close()
	file.close()
	l1l1111ll1_l1_.close()
	if not l11lll1lll_l1_:
		l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᶺ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠴࡯࡮ࡵࡧࡵࡶࡺࡶࡴࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡶࡴࡩࡥࡴࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᶻ")+l1lllll1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᶼ")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧᶽ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭ᶾ"),l1l111_l1_ (u"࠭ࠧᶿ"),l1l111_l1_ (u"ࠧࠨ᷀"),l1l111_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭᷁"))
		return True
	l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆ᷂ࠩ"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ᷃")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ᷄")+l11ll1ll1l_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ᷅"))
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ᷆"),l1l111_l1_ (u"ࠧࠨ᷇"),l1l111_l1_ (u"ࠨࠩ᷈"),l1l111_l1_ (u"ࠩอ้ࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢห๊ัออࠨ᷉"))
	return True
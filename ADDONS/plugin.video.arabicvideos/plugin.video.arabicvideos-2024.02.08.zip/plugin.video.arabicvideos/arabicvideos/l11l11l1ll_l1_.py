# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪṸ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡍࡂࡠࠩṹ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨṺ"):l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠪṻ")}
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==120: l1lll_l1_ = l1l1l11_l1_()
	elif mode==121: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==122: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==123: l1lll_l1_ = PLAY(url)
	elif mode==124: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬṼ")+text)
	elif mode==125: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ṽ")+text)
	elif mode==129: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṾ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩṿ"),l1l111_l1_ (u"ࠪࠫẀ"),129,l1l111_l1_ (u"ࠫࠬẁ"),l1l111_l1_ (u"ࠬ࠭Ẃ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẃ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬẄ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪẅ"),l1l111_l1_ (u"ࠩࠪẆ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧẇ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬẈ"),headers,l1l111_l1_ (u"ࠬ࠭ẉ"),l1l111_l1_ (u"࠭ࠧẊ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪẋ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡮࡯࡮ࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡬࡯࡭ࡦࡨࡶࠧ࠭Ẍ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫẍ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪห้๋ีศำ฼อࠬẎ") in title: continue
			title = title.rsplit(l1l111_l1_ (u"ࠫࡃ࠭ẏ"),1)[1]
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧẐ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨẑ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẒ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪẓ")+l1lllll_l1_+title,l1ll1ll_l1_,122)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧẔ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬẕ"),l1l111_l1_ (u"ࠫࠬẖ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡥ࡮ࡴࡌࡰࡣࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡹࡩࡷࡺࡩࡤࡣ࡯ࡈࡾࡴࡡ࡮࡫ࡦࠦࠬẗ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡰࡥࡣࠣࡦࡩࡨࠢ࠿࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪẘ"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩẙ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪẚ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠩส่๊฻วา฻ฬࠫẛ") in title: continue
			if l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬẜ") in l1ll1ll_l1_: continue
			if not title and l1l111_l1_ (u"ࠫ࠴ࡺࡶ࠰ࡣࡵࡥࡧ࡯ࡣࠨẝ") in l1ll1ll_l1_: title = l1l111_l1_ (u"๋ࠬำๅี็หฯูࠦาสํอࠬẞ")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẟ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩẠ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ạ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫẢ"),l1l111_l1_ (u"ࠪࠫả"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠨ࠯ࠬࡂ࠭ࡃࡋࡧࡺࡄࡨࡷࡹࡂ࠯ࡢࡀࠪẤ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧấ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨẦ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧầ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪẨ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ẩ"),url,l1l111_l1_ (u"ࠪࠫẪ"),headers,l1l111_l1_ (u"ࠫࠬẫ"),l1l111_l1_ (u"ࠬ࠭Ậ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬậ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡵࡢࡷࡨࡸ࡯࡭࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨẮ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩắ"),block,re.DOTALL)
	if l1l111_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࠫẰ") not in url:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪằ"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧẲ"),url,125)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẳ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩẴ"),url,124)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬẵ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪẶ"),l1l111_l1_ (u"ࠩࠪặ"),9999)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẸ"),l1lllll_l1_+title,l1ll1ll_l1_,121)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠫ࠶࠭ẹ")):
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠬ࠷ࠧẺ")
	if l1l111_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࠩẻ") in url or l1l111_l1_ (u"ࠧࡀࠩẼ") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠨࠨࠪẽ")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠩࡂࠫẾ")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠪࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡀ࡮ࡸࡵ࡮ࠧࡱࡸࡸࡵࡻࡴࡠ࡯ࡲࡨࡪࡃ࡭ࡰࡸ࡬ࡩࡸࡥ࡬ࡪࡵࡷࠪࡵࡧࡧࡦ࠿ࠪế")+l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨỀ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ề"),headers,l1l111_l1_ (u"࠭ࠧỂ"),l1l111_l1_ (u"ࠧࠨể"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭Ễ"))
	html = response.content
	name,items = l1l111_l1_ (u"ࠩࠪễ"),[]
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬỆ") in url:
		name = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࠨệ"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l1l111_l1_ (u"ࠬࠦࠧỈ")) + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪỉ")
		else: name = xbmc.getInfoLabel( l1l111_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠣỊ") ) + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬị")
	if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࠪỌ") not in url: items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡡࡢ࡜࡝ࠤࠫࡠࡡࡢ࡜࡝࠱ࡶࡩࡦࡹ࡯࡯࠰࠭ࡃ࠮ࡢ࡜࡝࡞ࠥ࠲࠯ࡅࡳࡳࡥࡀࡠࡡࡢ࡜ࠣࠪ࠱࠮ࡄ࠯࡜࡝࡞࡟ࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫࡜࡝࡞࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬọ"),html,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡢ࡜࡝࡞ࠥࠬ࠳࠰࠿ࠪ࡞࡟ࡠࡡࠨ࠮ࠫࡁࡶࡶࡨࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࡞࡟ࡠࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧỎ"),html,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧỏ") in url and l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࡜࠰ࠩỐ") not in l1ll1ll_l1_: continue
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩố") in url and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࡟࠳ࠬỒ") not in l1ll1ll_l1_: continue
		title = name+escapeUNICODE(title).strip(l1l111_l1_ (u"ࠩࠣࠫồ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭Ổ"),l1l111_l1_ (u"ࠫ࠴࠭ổ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨỖ"),l1l111_l1_ (u"࠭࠯ࠨỗ"))
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬỘ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧộ")+l1ll1l_l1_
		l1lllll1_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱ࠪỚ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ớ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠫ࠴ࡳࡡࡴࡴࡤ࡬࡮ࡿࡡࡵ࠱ࠪỜ") in url:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫờ"),l1lllll_l1_+title,l1lllll1_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨỞ")),123,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧở"),l1lllll_l1_+title,l1lllll1_l1_,121,l1ll1l_l1_)
	if len(items)>=12:
		l11l1l1l11_l1_ = [l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪỠ"),l1l111_l1_ (u"ࠩ࠲ࡸࡻ࠵ࠧỡ"),l1l111_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴࠭Ợ"),l1l111_l1_ (u"ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠯ࠨợ"),l1l111_l1_ (u"ࠬ࠵࡭ࡢࡵࡵࡥ࡭࡯ࡹࡢࡶ࠲ࠫỤ")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l11_l1_):
			for n in range(0,1100,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ụ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭Ủ")+str(j),url,121,l1l111_l1_ (u"ࠨࠩủ"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩỨ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩứ")+str(i),url,121,l1l111_l1_ (u"ࠫࠬỪ"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬừ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬỬ")+str(1),url,121,l1l111_l1_ (u"ࠧࠨử"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨỮ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨữ")+str(n),url,121,l1l111_l1_ (u"ࠪࠫỰ"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫự"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫỲ")+str(1),url,121)
	return
def PLAY(url):
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪỳ"):l1l111_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠬỴ")}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬỵ"),url,l1l111_l1_ (u"ࠩࠪỶ"),headers,l1l111_l1_ (u"ࠪࠫỷ"),l1l111_l1_ (u"ࠫࠬỸ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨỹ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁห้ะี็์ไࡀ࠴ࡺࡤ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭Ỻ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡱࡪ࠾ࡺࡸ࡬ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫỻ"),html,re.DOTALL)
	if l11l11ll11_l1_: server = l1l111l_l1_(l11l11ll11_l1_[0],l1l111_l1_ (u"ࠨࡷࡵࡰࠬỼ"))
	else: server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ỽ"))
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	l11l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡺࡺ࡯࠮ࡵ࡬ࡾࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬỾ"),html,re.DOTALL)
	if l11l1l111l_l1_:
		l11l1l111l_l1_ = server+l11l1l111l_l1_[0]
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨỿ"),l11l1l111l_l1_,l1l111_l1_ (u"ࠬ࠭ἀ"),headers,l1l111_l1_ (u"࠭ࠧἁ"),l1l111_l1_ (u"ࠧࠨἂ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫἃ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠩࡧࡳࡸࡺࡲࡦࡣࡰࠫἄ") not in l11l1ll1_l1_:
			l11l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡩࡲࡪࡲࡷ࠲࠯ࡅ࠾ࡧࡷࡱࡧࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩἅ"),l11l1ll1_l1_,re.DOTALL)
			l11l1111ll_l1_ = l11l1111ll_l1_[0]
			result = l11l11ll1l_l1_(l11l1111ll_l1_)
			try: l11l11l1l1_l1_,l11l11111l_l1_,l11ll111ll_l1_ = result
			except:
				l1111l1_l1_(l1l111_l1_ (u"ࠫࠬἆ"),l1l111_l1_ (u"ࠬ࠭ἇ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩἈ"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡ࠰ࠣๆิ๊ࠦไ๊้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ็อๅࠡสอัิ๐หࠡืไัฬะ็๊ࠡส่อืๆศ็ฯࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣๆึอมสࠢสฺ่็อศฬࠣห้าฯ๋ัฬࠫἉ"))
				return
			l11l11111l_l1_ = server+l11l11111l_l1_
			l11l11l1l1_l1_ = server+l11l11l1l1_l1_
			cookies = response.cookies
			if l1l111_l1_ (u"ࠨࡒࡖࡗࡎࡊࠧἊ") in cookies.keys():
				l11l111111_l1_ = cookies[l1l111_l1_ (u"ࠩࡓࡗࡘࡏࡄࠨἋ")]
				headers[l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪἌ")] = l1l111_l1_ (u"ࠫࡕ࡙ࡓࡊࡆࡀࠫἍ")+l11l111111_l1_
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩἎ"),l11l11l1l1_l1_,l1l111_l1_ (u"࠭ࠧἏ"),headers,l1l111_l1_ (u"ࠧࠨἐ"),l1l111_l1_ (u"ࠨࠩἑ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬἒ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨἓ"),l11l11111l_l1_,l11ll111ll_l1_,headers,l1l111_l1_ (u"ࠫࠬἔ"),l1l111_l1_ (u"ࠬ࠭ἕ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ἖"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ἗"),l11l1l111l_l1_,l1l111_l1_ (u"ࠨࠩἘ"),headers,l1l111_l1_ (u"ࠩࠪἙ"),l1l111_l1_ (u"ࠪࠫἚ"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧἛ"))
				l11l1ll1_l1_ = response.content
		l11llll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪἜ"),l11l1ll1_l1_,re.DOTALL)
		if l11llll1ll_l1_:
			l11llll1ll_l1_ = server+l11llll1ll_l1_[0]
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11l1_l1_(l11llll1ll_l1_,headers)
			zz = zip(l1l1lll1_l1_,l1llll_l1_)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			for title,l1ll1ll_l1_ in zz:
				l111l1ll_l1_ = title.split(l1l111_l1_ (u"࠭ࠠࠡࠩἝ"))[1]
				l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲ࠹ࡵ࠹ࡡࡢࠫ἞")+l111l1ll_l1_)
				l11ll111l1_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡸࡷ࡫ࡡ࡮࠱ࠪ἟"),l1l111_l1_ (u"ࠩ࠲ࡨࡱ࠵ࠧἠ")).replace(l1l111_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰ࠲ࡲ࠹ࡵ࠹ࠩἡ"),l1l111_l1_ (u"ࠫࠬἢ"))
				l1llll_l1_.append(l11ll111l1_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡼࡩࡥࡵࡷࡶࡪࡧ࡭ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡳࡰ࠵ࡡࡢࠫἣ")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬἤ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨἥ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩἦ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫἧ"),l1l111_l1_ (u"ࠪ࠯ࠬἨ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࡲ࠿ࠪἩ") + l1lll1ll_l1_
	l1lll11_l1_(url)
	return
l1l11111_l1_ = [l1l111_l1_ (u"ࠬอไ็๊฼ࠫἪ"),l1l111_l1_ (u"࠭วๅี้อࠬἫ"),l1l111_l1_ (u"ࠧศๆห่ิ࠭Ἤ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ื๋ฯࠧἭ"),l1l111_l1_ (u"ࠩส่้เษࠨἮ"),l1l111_l1_ (u"ࠪห้ฮไะࠩἯ"),l1l111_l1_ (u"ࠫฬ๊ฯใหࠪἰ"),l1l111_l1_ (u"ࠬอไอ๊าอࠬἱ"),l1l111_l1_ (u"࠭วๅฬิะ๊ฯࠧἲ"),l1l111_l1_ (u"ࠧศๆ้์฾࠭ἳ"),l1l111_l1_ (u"ࠨษ็ฮฺ์๊โࠩἴ")]
l11lll_l1_ = []
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ἵ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧἶ"),url,l1l111_l1_ (u"ࠫࠬἷ"),headers,l1l111_l1_ (u"ࠬ࠭Ἰ"),l1l111_l1_ (u"࠭ࠧἹ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪἺ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷࠧ࠭Ἳ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	zz = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡹࡷࡸࡥ࡯ࡶࡢࡳࡵࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫἼ"),block,re.DOTALL)
	l11l1l1lll_l1_,l11l1lll11_l1_ = zip(*zz)
	l1l11l1l_l1_ = zip(l11l1l1lll_l1_,l11l1lll11_l1_,l11l1l1lll_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩἽ"),block,re.DOTALL)
	l111llllll_l1_ = []
	for l1ll1ll_l1_,name in items:
		name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭Ἶ"))
		value = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧἿ"),1)[1]
		if name in l11lll_l1_: continue
		if l1l111_l1_ (u"࠭ไๅๅหหึ࠭ὀ") in name: continue
		if l1l111_l1_ (u"ࠧࡕࡘ࠰ࡑࡆ࠭ὁ") in name: continue
		if l1l111_l1_ (u"ࠨࡖ࡙࠱࠶࠺ࠧὂ") in name: continue
		l111llllll_l1_.append((value,name))
	return l111llllll_l1_
def l11l1l11l1_l1_(l1l1ll11_l1_,url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ὃ"),1)[0]
	url = url.strip(l1l111_l1_ (u"ࠪ࠳ࠬὄ"))
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ὅ"))
	l11ll111_l1_ = l11ll111_l1_.replace(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ὆"),l1l111_l1_ (u"࠭࠭ࠨ὇"))
	url = url+l1l111_l1_ (u"ࠧ࠰ࠩὈ")+l11ll111_l1_
	return url
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠨࡁࠪὉ") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ὂ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧὋ"),1)
	if filter==l1l111_l1_ (u"ࠫࠬὌ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭Ὅ"),l1l111_l1_ (u"࠭ࠧ὎")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ὏"))
	if type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫὐ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫὑ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬὒ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ὓ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨὔ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨὕ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪὖ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪὗ"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭὘")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬὙ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ὚"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩὛ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ὜"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩὝ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ὞"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ὗ")+l11lll11_l1_
		l1llllll_l1_ = l11l1l11l1_l1_(l11lll11_l1_,l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪὠ"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧὡ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὢ"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ὣ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ὤ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ὥ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫὦ"),l1l111_l1_ (u"ࠪࠫὧ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		l1l111ll_l1_ = l1l111ll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭Ὠ"))
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧὩ"))
		name = name.replace(l1l111_l1_ (u"࠭࠭࠮ࠩὪ"),l1l111_l1_ (u"ࠧࠨὫ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪὬ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬὭ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					l1llllll_l1_ = l11l1l11l1_l1_(l11lll11_l1_,url)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩὮ")+l1l111l1_l1_)
				return
			else:
				l1llllll_l1_ = l11l1l11l1_l1_(l11lll11_l1_,l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫὯ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ὰ"),l1llllll_l1_,121)
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ά"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨὲ"),l1lllll1_l1_,125,l1l111_l1_ (u"ࠨࠩέ"),l1l111_l1_ (u"ࠩࠪὴ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ή"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ὶ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨί")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨὸ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪό")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬὺ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩύ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬὼ")+name,l1lllll1_l1_,124,l1l111_l1_ (u"ࠫࠬώ"),l1l111_l1_ (u"ࠬ࠭὾"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ὿")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩᾀ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪᾁ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫᾂ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧᾃ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧᾄ")+name
			if type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨᾅ"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾆ"),l1lllll_l1_+title,url,124,l1l111_l1_ (u"ࠧࠨᾇ"),l1l111_l1_ (u"ࠨࠩᾈ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬᾉ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬᾊ") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11l1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᾋ"),l1lllll_l1_+title,l1llllll_l1_,121)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᾌ"),l1lllll_l1_+title,url,125,l1l111_l1_ (u"࠭ࠧᾍ"),l1l111_l1_ (u"ࠧࠨᾎ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫᾏ"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭ᾐ"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬᾑ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭ᾒ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧᾓ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨᾔ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨᾕ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪᾖ")
		if l1l111_l1_ (u"ࠩࠨࠫᾗ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᾘ") and value!=l1l111_l1_ (u"ࠫ࠵࠭ᾙ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩᾚ")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᾛ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩᾜ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪᾝ")+key+l1l111_l1_ (u"ࠩࡀࠫᾞ")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᾟ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᾠ")+key+l1l111_l1_ (u"ࠬࡃࠧᾡ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪᾢ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩᾣ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫᾤ"),l1l111_l1_ (u"ࠩࡀࠫᾥ"))
	return l1l1l111_l1_
def l11l1lllll_l1_(l11l1111l1_l1_):
	m = re.search(l1l111_l1_ (u"ࡵࠫࡣ࠮࡜ࡥ࠭ࠬ࡟࠳࠲࡝ࡀ࡞ࡧ࠮ࡄ࠭ᾦ"), str(l11l1111l1_l1_))
	return int(m.groups()[-1]) if m and not callable(l11l1111l1_l1_) else 0
def l11l11l111_l1_(l11l1lll1l_l1_):
	try:
		l11l1ll11l_l1_ = base64.b64decode(l11l1lll1l_l1_)
	except:
		try:
			l11l1ll11l_l1_ = base64.b64decode(l11l1lll1l_l1_+l1l111_l1_ (u"ࠫࡂ࠭ᾧ"))
		except:
			try:
				l11l1ll11l_l1_ = base64.b64decode(l11l1lll1l_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨᾨ"))
			except:
				l11l1ll11l_l1_ = l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡧࡧࡳࡦ࠸࠷ࠤࡩ࡫ࡣࡰࡦࡨࠤࡪࡸࡲࡰࡴࠪᾩ")
	if PY3: l11l1ll11l_l1_ = l11l1ll11l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᾪ"))
	return l11l1ll11l_l1_
def l11l111ll1_l1_(l11l1ll111_l1_,l11l1l1l1l_l1_,a):
	a = a - l11l1l1l1l_l1_
	if a<0:
		c = l1l111_l1_ (u"ࠨࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠫᾫ")
	else:
		c = l11l1ll111_l1_[a]
	return c
def x(l11l1ll111_l1_,l11l1l1l1l_l1_,a):
	return(l11l111ll1_l1_(l11l1ll111_l1_,l11l1l1l1l_l1_,a))
def l11l1ll1l1_l1_(l11ll11111_l1_,step,l11l1l1l1l_l1_,l11l11lll1_l1_):
	l11l11lll1_l1_ = l11l11lll1_l1_.replace(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࠧᾬ"),l1l111_l1_ (u"ࠪ࡫ࡱࡵࡢࡢ࡮ࠣࡨࡀࠦࠧᾭ"))
	l11l11lll1_l1_ = l11l11lll1_l1_.replace(l1l111_l1_ (u"ࠫࡽ࠮ࠧᾮ"),l1l111_l1_ (u"ࠬࡾࠨࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠫᾯ"))
	l11l11lll1_l1_ = l11l11lll1_l1_.replace(l1l111_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡤ࠼ࠢࡧࡁࠬᾰ"),l1l111_l1_ (u"ࠧࠨᾱ"))
	d = eval(l11l11lll1_l1_,{l1l111_l1_ (u"ࠨࡲࡤࡶࡸ࡫ࡉ࡯ࡶࠪᾲ"):l11l1lllll_l1_,l1l111_l1_ (u"ࠩࡻࠫᾳ"):x,l1l111_l1_ (u"ࠪࡸࡦࡨࠧᾴ"):l11ll11111_l1_,l1l111_l1_ (u"ࠫࡸࡺࡥࡱ࠴ࠪ᾵"):l11l1l1l1l_l1_})
	l11ll11l1l_l1_=0
	while True:
		l11ll11l1l_l1_=l11ll11l1l_l1_+1
		l11ll11111_l1_.append(l11ll11111_l1_[0])
		del l11ll11111_l1_[0]
		d = eval(l11l11lll1_l1_,{l1l111_l1_ (u"ࠬࡶࡡࡳࡵࡨࡍࡳࡺࠧᾶ"):l11l1lllll_l1_,l1l111_l1_ (u"࠭ࡸࠨᾷ"):x,l1l111_l1_ (u"ࠧࡵࡣࡥࠫᾸ"):l11ll11111_l1_,l1l111_l1_ (u"ࠨࡵࡷࡩࡵ࠸ࠧᾹ"):l11l1l1l1l_l1_})
		if ((d == step) or (l11ll11l1l_l1_>10000)): break
	return
def l11l11ll1l_l1_(l11l1111ll_l1_):
	tmp = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷ࠴ࠪࡀ࠿ࠫ࠲ࢀ࠸ࠬ࠵ࡿࠬࡠ࠭ࡢࠩࠨᾺ"), l11l1111ll_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠪࡉࡗࡘ࠺ࡗࡣࡵࡧࡴࡴࡳࡵࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬΆ")
	l11l111l11_l1_ = tmp[0].strip()
	_print(l1l111_l1_ (u"࡛ࠫࡧࡲࡤࡱࡱࡷࡹࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨᾼ") % l11l111l11_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࢃ࡜ࠩࠩ᾽")+l11l111l11_l1_+l1l111_l1_ (u"࠭࠿࠭ࠪ࠳ࡼࡠ࠶࠭࠺ࡣ࠰ࡪࡢࢁ࠱࠭࠳࠳ࢁ࠮ࡢࠩ࡝ࠫ࠾ࠫι"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾࡙ࠥࡴࡦࡲ࠴ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧ᾿")
	step = eval(tmp[0])
	_print(l1l111_l1_ (u"ࠨࡕࡷࡩࡵ࠷ࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢ࠳ࡼࠪࡹࠧ῀") % l1l111_l1_ (u"ࠩࡾ࠾࠵࠸ࡘࡾࠩ῁").format(step).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠪࡨࡂࡪ࠭ࠩ࠲ࡻ࡟࠵࠳࠹ࡢ࠯ࡩࡡࢀ࠷ࠬ࠲࠲ࢀ࠭ࡀ࠭ῂ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡕࡷࡩࡵ࠸ࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪῃ")
	l11l1l1l1l_l1_ = eval(tmp[0])
	_print(l1l111_l1_ (u"࡙ࠬࡴࡦࡲ࠵ࠤࠥࠦࠠࠡࠢࠣࠤࡂࠦ࠰ࡹࠧࡶࠫῄ") % l1l111_l1_ (u"࠭ࡻ࠻࠲࠵࡜ࢂ࠭῅").format(l11l1l1l1l_l1_).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠢࡵࡴࡼࡿ࠭ࡼࡡࡳ࠰࠭ࡃ࠮ࡁࠢῆ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࡪࡥࡤࡣ࡯ࡣ࡫ࡴࡣࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫῇ")
	l11l11lll1_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠩࡇࡩࡨࡧ࡬ࠡࡨࡸࡲࡨࠦࠠࠡ࠿ࠣࠦࠥࠫࡳ࠯࠰࠱ࠦࠬῈ") % l11l11lll1_l1_[0:135])
	tmp = re.findall(l1l111_l1_ (u"ࠥࠫࡩࡧࡴࡢࠩ࠽ࡿࠬ࠮࡟࡜࠲࠰࠽ࡦ࠳ࡺࡂ࠯࡝ࡡࢀ࠷࠰࠭࠴࠳ࢁ࠮࠭࠺ࠨࡱ࡮ࠫࠧΈ"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡒࡲࡷࡹࡑࡥࡺࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬῊ")
	l11l1llll1_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠬࡖ࡯ࡴࡶࡎࡩࡾࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩΉ") % l11l1llll1_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࠤῌ")+l11l111l11_l1_+l1l111_l1_ (u"ࠢ࠯ࠬࡂࡺࡦࡸ࠮ࠫࡁࡀࠬࡡࡡ࠮ࠫࡁࡠ࠭ࠧ῍"), l11l1111ll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿࡚ࡡࡣࡎ࡬ࡷࡹࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ῎")
	l11l1l11ll_l1_ = tmp[0]
	l11l1l11ll_l1_ = l11l111l11_l1_ + l1l111_l1_ (u"ࠤࡀࠦ῏") + l11l1l11ll_l1_
	exec(l11l1l11ll_l1_) in globals(), locals()
	l11l1ll111_l1_ = locals()[l11l111l11_l1_]
	_print(l11l111l11_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧ࠱࠽࠵ࡹ࠮࠯࠰ࠪῐ")%str(l11l1ll111_l1_))
	l11l1ll1l1_l1_(l11l1ll111_l1_,step,l11l1l1l1l_l1_,l11l11lll1_l1_)
	_print(l11l111l11_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨ࠲࠾࠶ࡳ࠯࠰࠱ࠫῑ")%str(l11l1ll111_l1_))
	tmp = re.findall(l1l111_l1_ (u"ࠧࡢࠨ࡝ࠫ࠾ࠬࡻࡧࡲࠡ࠰࠭ࡃ࠮ࡢࠤ࡝ࠪࠪࡠ࠯࠭࡜ࠪࠤῒ"), l11l1111ll_l1_, re.S)
	if not tmp:
		tmp = re.findall(l1l111_l1_ (u"ࠨࡡ࠱ࡣ࡟ࠬࡡ࠯࠻ࠩ࠰࠭ࡃ࠮ࡢࠤ࡝ࠪࠪࡠ࠯࠭࡜ࠪࠤΐ"), l11l1111ll_l1_, re.S)
		if not tmp:
			return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾ࡑ࡯ࡳࡵࡡ࡙ࡥࡷࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ῔")
	l11ll11l11_l1_ = tmp[0]
	l11ll11l11_l1_ = re.sub(l1l111_l1_ (u"ࠣࠪࡩࡹࡳࡩࡴࡪࡱࡱࠤ࠳࠰࠿ࡾ࠰࠭ࡃࢂ࠯ࠢ῕"), l1l111_l1_ (u"ࠤࠥῖ"), l11ll11l11_l1_)
	_print(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡠࡘࡤࡶࠥࠦࠠࠡࠢࡀࠤࠪ࠴࠹࠱ࡵ࠱࠲࠳࠭ῗ") % l11ll11l11_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠦ࠭ࡥ࡛ࡢ࠯ࡽࡅ࠲ࢀ࠰࠮࠻ࡠࡿ࠹࠲࠸ࡾࠫࡀࡠࡠࡢ࡝ࠣῘ") , l11ll11l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠬࡋࡒࡓ࠼࠶࡚ࡦࡸࡳࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫῙ")
	_11l1l1ll1_l1_ = tmp
	_print(l1l111_l1_ (u"࠭࠳ࡗࡣࡵࡷࠥࠦࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪῚ")%str(_11l1l1ll1_l1_))
	l11l1l1111_l1_ = _11l1l1ll1_l1_[1]
	_print(l1l111_l1_ (u"ࠧࡣ࡫ࡪࡣࡸࡺࡲࡠࡸࡤࡶࠥࠦ࠽ࠡࠧࡶࠫΊ")%l11l1l1111_l1_)
	l11ll11l11_l1_ = l11ll11l11_l1_.replace(l1l111_l1_ (u"ࠨ࠮ࠪ῜"),l1l111_l1_ (u"ࠩ࠾ࠫ῝")).split(l1l111_l1_ (u"ࠪ࠿ࠬ῞"))
	for l11l1lll1l_l1_ in l11ll11l11_l1_:
		l11l1lll1l_l1_ = l11l1lll1l_l1_.strip()
		if l1l111_l1_ (u"ࠫ࡮ࡹ࡭ࡰࡤࠪ῟") in l11l1lll1l_l1_: l11l1lll1l_l1_=l1l111_l1_ (u"ࠬ࠭ῠ")
		if l1l111_l1_ (u"࠭࠽࡜࡟ࠪῡ")   in l11l1lll1l_l1_: l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠧ࠾࡝ࡠࠫῢ"),l1l111_l1_ (u"ࠨ࠿ࡾࢁࠬΰ"))
		l11l1lll1l_l1_ = re.sub(l1l111_l1_ (u"ࠤࠫࡥ࠵࠴࡜ࠩࠫࠥῤ"), l1l111_l1_ (u"ࠥࡥ࠵ࡪࠨ࡮ࡣ࡬ࡲࡤࡺࡡࡣ࠮ࡶࡸࡪࡶ࠲࠭ࠤῥ"), l11l1lll1l_l1_)
		if l11l1lll1l_l1_!=l1l111_l1_ (u"ࠫࠬῦ"):
			l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠬࠧࠡ࡜࡟ࠪῧ"),l1l111_l1_ (u"࠭ࡔࡳࡷࡨࠫῨ"));
			l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠧࠢ࡝ࡠࠫῩ"),l1l111_l1_ (u"ࠨࡈࡤࡰࡸ࡫ࠧῪ"));
			l11l1lll1l_l1_ = l11l1lll1l_l1_.replace(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࠧΎ"),l1l111_l1_ (u"ࠪࠫῬ"));
			try:
				exec(l11l1lll1l_l1_,{l1l111_l1_ (u"ࠫࡵࡧࡲࡴࡧࡌࡲࡹ࠭῭"):l11l1lllll_l1_,l1l111_l1_ (u"ࠬࡧࡴࡰࡤࠪ΅"):l11l11l111_l1_,l1l111_l1_ (u"࠭ࡡ࠱ࡦࠪ`"):l11l111ll1_l1_,l1l111_l1_ (u"ࠧࡹࠩ῰"):x,l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡴࡢࡤࠪ῱"):l11l1ll111_l1_,l1l111_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨῲ"):l11l1l1l1l_l1_},locals())
			except:
				pass
	l11ll1111l_l1_ = l1l111_l1_ (u"ࠪࠫῳ")
	for i in range(0,len(locals()[_11l1l1ll1_l1_[2]])):
		if locals()[_11l1l1ll1_l1_[2]][i] in locals()[_11l1l1ll1_l1_[1]]:
			l11ll1111l_l1_ = l11ll1111l_l1_ + locals()[_11l1l1ll1_l1_[1]][locals()[_11l1l1ll1_l1_[2]][i]]
	_print(l1l111_l1_ (u"ࠫࡧ࡯ࡧࡔࡶࡵ࡭ࡳ࡭ࠠࠡࠢࠣࡁࠥࠫ࠮࠺࠲ࡶ࠲࠳࠴ࠧῴ")%l11ll1111l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡥࡁࡡ࠭࠯࡝ࠩ࡟࠯࠭࠴ࠪࡀࠫࠫࡃ࠿࠲ࡼ࠼ࠫࠪ῵"), l11l1111ll_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡌ࡫ࡴࡖࡴ࡯ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧῶ")
	l11l111l1l_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡈࡧࡷ࡙ࡷࡲࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫῷ") % l11l111l1l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࠪࡢ࠲࠯ࡅࠩ࡝࡝ࠪῸ"), l11l111l1l_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࠠࡈࡧࡷ࡚ࡦࡸࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪΌ")
	l11l111lll_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠪࡋࡪࡺࡖࡢࡴࠣࠤࠥࠦࠠࠡࠢࡀࠤࠪࡹࠧῺ") % l11l111lll_l1_)
	l11l1ll1ll_l1_ = locals()[l11l111lll_l1_][0]
	l11l1ll1ll_l1_ = l11l11l111_l1_(l11l1ll1ll_l1_)
	_print(l1l111_l1_ (u"ࠫࡌ࡫ࡴࡗࡣ࡯ࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨΏ") % l11l1ll1ll_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࢃࡶࡢࡴࠣࠬ࡫ࡃ࠮ࠫࡁࠬ࠿ࠬῼ"), l11l1111ll_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡕࡵࡳࡵࡗࡵࡰࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨ´")
	l11l11l11l_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡑࡱࡶࡸ࡚ࡸ࡬ࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫ῾") % l11l11l11l_l1_)
	l11l11l11l_l1_ = re.sub(l1l111_l1_ (u"ࠣࠪࡺ࡭ࡳࡪ࡯ࡸ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠥ῿"), l1l111_l1_ (u"ࠤࡤࡸࡴࡨࠢ "), l11l11l11l_l1_)
	l11l11l11l_l1_ = re.sub(l1l111_l1_ (u"ࠥࠬࡠࡇ࡛࠭࡟ࡾ࠵࠱࠸ࡽ࡝ࠪࠬࠦ "), l1l111_l1_ (u"ࠦࡦ࠶ࡤࠩ࡯ࡤ࡭ࡳࡥࡴࡢࡤ࠯ࡷࡹ࡫ࡰ࠳࠮ࠥ "), l11l11l11l_l1_)
	l11l11l11l_l1_ = l1l111_l1_ (u"ࠬ࡭࡬ࡰࡤࡤࡰࠥ࡬࠻ࠡࠩ ")+l11l11l11l_l1_
	verify = re.findall(l1l111_l1_ (u"࠭࡜ࠬࠪࡢ࠲࠯ࡅࠩࠥࠩ "),l11l11l11l_l1_,re.DOTALL)[0]
	l11l11llll_l1_ = eval(verify)
	l11l11l11l_l1_ = l11l11l11l_l1_.replace(l1l111_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡧ࠽ࠣࡪࡂ࠭ "),l1l111_l1_ (u"ࠨࠩ "))
	f = eval(l11l11l11l_l1_,{l1l111_l1_ (u"ࠩࡤࡸࡴࡨࠧ "):l11l11l111_l1_,l1l111_l1_ (u"ࠪࡥ࠵ࡪࠧ "):l11l111ll1_l1_,l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡷࡥࡧ࠭ "):l11l1ll111_l1_,l1l111_l1_ (u"ࠬࡹࡴࡦࡲ࠵ࠫ "):l11l1l1l1l_l1_,verify:l11l11llll_l1_})
	_print(l1l111_l1_ (u"࠭࠯ࠨ​")+l11l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ‌")+f+l11ll1111l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭‍")+l11l1llll1_l1_)
	return([l1l111_l1_ (u"ࠩ࠲ࠫ‎")+l11l1ll1ll_l1_,f+l11ll1111l_l1_,{ l11l1llll1_l1_ : l1l111_l1_ (u"ࠪࡳࡰ࠭‏")}])
def _print(text):
	return
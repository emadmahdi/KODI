# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭న")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡆࡕࡏࡢࠫ఩")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1llll1l1_l1_ = [l1l111_l1_ (u"࠭࠱࠳࠵࠼ࠫప"),l1l111_l1_ (u"ࠧ࠲࠴࠸࠴ࠬఫ"),l1l111_l1_ (u"ࠨ࠳࠵࠸࠺࠭బ"),l1l111_l1_ (u"ࠩ࠵࠴ࠬభ"),l1l111_l1_ (u"ࠪ࠵࠷࠻࠹ࠨమ"),l1l111_l1_ (u"ࠫ࠷࠷࠸ࠨయ"),l1l111_l1_ (u"ࠬ࠺࠸࠶ࠩర"),l1l111_l1_ (u"࠭࠱࠳࠵࠻ࠫఱ"),l1l111_l1_ (u"ࠧ࠲࠴࠸࠼ࠬల"),l1l111_l1_ (u"ࠨ࠴࠼࠶ࠬళ")]
l1llll11l_l1_ = [l1l111_l1_ (u"ࠩ࠶࠴࠸࠶ࠧఴ"),l1l111_l1_ (u"ࠪ࠺࠷࠾ࠧవ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==60: l1lll_l1_ = l1l1l11_l1_()
	elif mode==61: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==62: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==63: l1lll_l1_ = PLAY(url)
	elif mode==64: l1lll_l1_ = l1llll1ll_l1_(text)
	elif mode==69: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫశ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬష"),l1l111_l1_ (u"࠭ࠧస"),69,l1l111_l1_ (u"ࠧࠨహ"),l1l111_l1_ (u"ࠨࠩ఺"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭఻"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ఼ࠪ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ఽ")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬวࠡ์อ้๋ࠥิศ้าฮ์ࠦวๅษ้ࠫా"),l111l1_l1_,64,l1l111_l1_ (u"࠭ࠧి"),l1l111_l1_ (u"ࠧࠨీ"),l1l111_l1_ (u"ࠨࡴࡨࡧࡪࡴࡴࡠࡸ࡬ࡩࡼ࡫ࡤࡠࡸ࡬ࡨࡸ࠭ు"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩూ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬృ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊วไอิࠤฺ๊ว่ัฬࠫౄ"),l111l1_l1_,64,l1l111_l1_ (u"ࠬ࠭౅"),l1l111_l1_ (u"࠭ࠧె"),l1l111_l1_ (u"ࠧ࡮ࡱࡶࡸࡤࡼࡩࡦࡹࡨࡨࡤࡼࡩࡥࡵࠪే"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨై"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ౉")+l1lllll_l1_+l1l111_l1_ (u"ࠪห฻๐แห่ࠢศำืวࠨొ"),l111l1_l1_,64,l1l111_l1_ (u"ࠫࠬో"),l1l111_l1_ (u"ࠬ࠭ౌ"),l1l111_l1_ (u"࠭ࡲࡦࡥࡨࡲࡹࡲࡹࡠࡣࡧࡨࡪࡪ࡟ࡷ࡫ࡧࡷ్ࠬ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౎"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ౏")+l1lllll_l1_+l1l111_l1_ (u"ࠩไ๎ิ๐่ࠡ฻ื์ฬฬ๊ࠨ౐"),l111l1_l1_,64,l1l111_l1_ (u"ࠪࠫ౑"),l1l111_l1_ (u"ࠫࠬ౒"),l1l111_l1_ (u"ࠬࡸࡡ࡯ࡦࡲࡱࡤࡼࡩࡥࡵࠪ౓"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౔"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠౕࠩ")+l1lllll_l1_+l1l111_l1_ (u"ࠨษไ่ฬ๋้ࠠ็ึุ่๊วหౖࠩ"),l111l1_l1_,61,l1l111_l1_ (u"ࠩࠪ౗"),l1l111_l1_ (u"ࠪࠫౘ"),l1l111_l1_ (u"ࠫ࠲࠷ࠧౙ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬౚ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ౛")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆหีฬ๋ฬࠡษ็ำ๏์๊สࠩ౜"),l111l1_l1_,61,l1l111_l1_ (u"ࠨࠩౝ"),l1l111_l1_ (u"ࠩࠪ౞"),l1l111_l1_ (u"ࠪ࠱࠷࠭౟"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫౠ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧౡ")+l1lllll_l1_+l1l111_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠠࡗ࡫ࡧࡩࡴࡹࠧౢ"),l111l1_l1_,61,l1l111_l1_ (u"ࠧࠨౣ"),l1l111_l1_ (u"ࠨࠩ౤"),l1l111_l1_ (u"ࠩ࠰࠷ࠬ౥"))
	return l1l111_l1_ (u"ࠪࠫ౦")
def l1lll11_l1_(url,category):
	cat = l1l111_l1_ (u"ࠫࠬ౧")
	if category not in [l1l111_l1_ (u"ࠬ࠳࠱ࠨ౨"),l1l111_l1_ (u"࠭࠭࠳ࠩ౩"),l1l111_l1_ (u"ࠧ࠮࠵ࠪ౪")]: cat = l1l111_l1_ (u"ࠨࡁࡦࡥࡹࡃࠧ౫")+category
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡪࡴࡵࡠ࡮ࡨࡺࡪࡲ࠮ࡱࡪࡳࠫ౬")+cat
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ౭"),l1l111_l1_ (u"ࠫࠬ౮"),l1l111_l1_ (u"ࠬ࠭౯"),l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ౰"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭౱"),html,re.DOTALL)
	l1lll1lll_l1_,found = False,False
	for l1ll1ll_l1_,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ౲"))
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ౳") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ౴")+l1ll1ll_l1_
		cat = re.findall(l1l111_l1_ (u"ࠫࡨࡧࡴ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨ౵"),l1ll1ll_l1_,re.DOTALL)[0]
		if category==cat: l1lll1lll_l1_ = True
		elif l1lll1lll_l1_ 	or (category==l1l111_l1_ (u"ࠬ࠳࠱ࠨ౶") and cat in l1llll1l1_l1_) \
						or (category==l1l111_l1_ (u"࠭࠭࠳ࠩ౷") and cat not in l1llll11l_l1_ and cat not in l1llll1l1_l1_) \
						or (category==l1l111_l1_ (u"ࠧ࠮࠵ࠪ౸") and cat in l1llll11l_l1_):
							if count==l1l111_l1_ (u"ࠨ࠳ࠪ౹"): addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ౺"),l1lllll_l1_+title,l1ll1ll_l1_,63)
							else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ౻"),l1lllll_l1_+title,l1ll1ll_l1_,61,l1l111_l1_ (u"ࠫࠬ౼"),l1l111_l1_ (u"ࠬ࠭౽"),cat)
							found = True
	if not found: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ౾"),l1l111_l1_ (u"ࠧࠨ౿"),True,l1l111_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩಀ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡧࡱࡲࡸࡪࡸࠧಁ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡫ࡷ࡯ࡤࡠࡸ࡬ࡩࡼ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨಂ"),block,re.DOTALL)
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠫࠬಃ")
	for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
		title = title.replace(l1l111_l1_ (u"ࠬࡇࡤࡥࠩ಄"),l1l111_l1_ (u"࠭ࠧಅ")).replace(l1l111_l1_ (u"ࠧࡵࡱࠣࡕࡺ࡯ࡣ࡬࡮࡬ࡷࡹ࠭ಆ"),l1l111_l1_ (u"ࠨࠩಇ")).strip(l1l111_l1_ (u"ࠩࠣࠫಈ"))
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨಉ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪಊ")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫಋ"),l1lllll_l1_+title,l1ll1ll_l1_,63,l1ll1l_l1_)
	l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨಌ"),block,re.DOTALL)
	block=l11llll_l1_[0]
	block=re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ಍"),html,re.DOTALL)[0]
	items=re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪಎ"),block,re.DOTALL)
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࠫಏ"))[0]
	for l1ll1ll_l1_,l1lll1l1l_l1_ in items:
		l1ll1ll_l1_ = l1lllll1_l1_ + l1ll1ll_l1_
		title = unescapeHTML(l1lll1l1l_l1_)
		title = l1l111_l1_ (u"ูࠪๆำษࠡࠩಐ") + title
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ಑"),l1lllll_l1_+title,l1ll1ll_l1_,62)
	return l1ll1ll_l1_
def PLAY(url):
	if l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࠩಒ") in url: url = l1ll1l11_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧಓ"),l1l111_l1_ (u"ࠧࠨಔ"),True,l1l111_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬಕ"))
	items = re.findall(l1l111_l1_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩಖ"),html,re.DOTALL)
	url = items[0]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨಗ") not in url: url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪಘ")+url
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫಙ"))
	return
def l1llll1ll_l1_(category):
	payload = { l1l111_l1_ (u"࠭࡭ࡰࡦࡨࠫಚ") : category }
	url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮ࡩࡥࡹ࡯࡭ࡪ࠰ࡷࡺ࠴ࡧࡪࡢࡺ࠱ࡴ࡭ࡶࠧಛ")
	headers = { l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧಜ") : l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨಝ") }
	data = l1lllll11_l1_(payload)
	html = l1l1llll_l1_(l111l11l_l1_,url,data,headers,True,l1l111_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ࠲ࡓࡏࡔࡖࡖ࠱࠶ࡹࡴࠨಞ"))
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࠬಟ"),html,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧಠ"))
		if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫಡ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ಢ")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧಣ"),l1lllll_l1_+title,l1ll1ll_l1_,63,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪತ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫಥ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ದ"),l1l111_l1_ (u"ࠬ࠱ࠧಧ"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࡟ࡳࡧࡶࡹࡱࡺ࠮ࡱࡪࡳࡃࡶࡻࡥࡳࡻࡀࠫನ") + l1lll1ll_l1_
	l1ll1l11_l1_(url)
	return
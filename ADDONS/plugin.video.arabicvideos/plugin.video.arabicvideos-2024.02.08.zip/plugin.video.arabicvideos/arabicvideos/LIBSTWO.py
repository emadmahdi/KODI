# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111l1l1l_l1_ import *
import bidi.algorithm,base64,requests
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡃࡕࡗ࡛ࡔ࠭㎐")
contentsDICT = {}
menuItemsLIST = []
if PY3:
	l111ll11l1l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ㎑"))
	l1ll11ll11_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ㎒"))
	l11l1l11l1l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬ㎓"))
	l111ll1111l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㎔"),l1l111_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㎕"),l1l111_l1_ (u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩ㎖"))
	l11l1lll11l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㎗"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㎘"),l1l111_l1_ (u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ㎙"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㎚"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㎛"),l1l111_l1_ (u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪ㎜"))
	half_triangular_colon = l1l111_l1_ (u"ࡹࠬࡢࡵ࠱࠴ࡧ࠵ࠬ㎝")
	from urllib.parse import quote as _1llllll1ll1_l1_
else:
	l111ll11l1l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡺࡥࡱࡨ࠭㎞"))
	l1ll11ll11_l1_ = xbmc.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ㎟"))
	l11l1l11l1l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫ㎠"))
	l111ll1111l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㎡"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㎢"),l1l111_l1_ (u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ㎣"))
	l11l1lll11l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㎤"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㎥"),l1l111_l1_ (u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭㎦"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㎧"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㎨"),l1l111_l1_ (u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩ㎩"))
	half_triangular_colon = l1l111_l1_ (u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫ㎪").encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㎫"))
	from urllib import quote as _1llllll1ll1_l1_
l111lll1ll1_l1_ = os.path.join(l11l1l11l1l_l1_,l1l111_l1_ (u"ࠬࡱ࡯ࡥ࡫࠱ࡰࡴ࡭ࠧ㎬"))
l11111l1l1l_l1_ = os.path.join(l11l1l11l1l_l1_,l1l111_l1_ (u"࠭࡫ࡰࡦ࡬࠲ࡴࡲࡤ࠯࡮ࡲ࡫ࠬ㎭"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠶ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㎮"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠸ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ㎯"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰ࠷ࡺࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㎰"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡹ࠮ࡥࡣࡷࠫ㎱"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭㎲"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳ࠳ࡶࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭㎳"))
l1ll11l1111l_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡦࡤࡸࠬ㎴"))
addonimagesfolder = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪࡹࠧ㎵"))
l1ll1ll1ll1l_l1_ = os.path.join(addonimagesfolder,l1l111_l1_ (u"ࠨࡦ࡬ࡥࡱࡵࡧࡴࠩ㎶"))
l1ll11lll111_l1_ = os.path.join(l1ll1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬ㎷"))
l1l1l1l1111_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠪࡴࡦࡺࡨࠨ㎸"))
defaulticon = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭㎹"))
defaultthumb = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ㎺"))
defaultfanart = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㎻"))
defaultbanner = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫ㎼"))
defaultlandscape = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨ㎽"))
defaultposter = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭㎾"))
defaultclearlogo = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪ㎿"))
defaultclearart = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㏀"))
defaultmenu = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷ࠱ࡴࡳ࡭ࠧ㏁"))
l1lll1l11lll_l1_ = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭㏂"))
l1lllll1ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㏃"))
l1lll11lll1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㏄"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㏅"),addon_id,l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㏆"))
fontfile = os.path.join(l111ll11l1l_l1_,l1l111_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࠪ㏇"),l1l111_l1_ (u"ࠬࡌ࡯࡯ࡶࡶࠫ㏈"),l1l111_l1_ (u"࠭ࡡࡳ࡫ࡤࡰ࠳ࡺࡴࡧࠩ㏉"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ࠧึใิࠫ㏊"),l1l111_l1_ (u"ࠨล๋่ࠬ㏋"),l1l111_l1_ (u"ࠩฮห๋๐ࠧ㏌"),l1l111_l1_ (u"ࠪฯฬ๊หࠨ㏍"),l1l111_l1_ (u"ࠫึอศฺࠩ㏎"),l1l111_l1_ (u"ࠬิวๆีࠪ㏏"),l1l111_l1_ (u"࠭ำศัึࠫ㏐"),l1l111_l1_ (u"ࠧิษห฽ࠬ㏑"),l1l111_l1_ (u"ࠨอส้๋࠭㏒"),l1l111_l1_ (u"ࠩอหุ฿ࠧ㏓"),l1l111_l1_ (u"ࠪ฽ฬฺัࠨ㏔")]
l11111l11ll_l1_ = l1l111_l1_ (u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬ㏕")
l11ll11l_l1_ = 0
l1llll1111ll_l1_ = 30*l1l1ll1l1ll_l1_
l111l11l_l1_ = 2*l1l11lll111_l1_
l1lll11ll11_l1_ = 30*l1l11ll1l1l_l1_
l1l111lll11_l1_ = 1*l1l11lll111_l1_
l1ll1l111lll_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㏖")]
l1111l1l1ll_l1_ = [l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㏗"),l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㏘"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ㏙"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㏚"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭㏛"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㏜"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ㏝"),l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㏞"),l1l111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ㏟")]
l1111l1l1ll_l1_ += [l1l111_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ㏠"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ㏡"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㏢"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㏣"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ㏤"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭㏥"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㏦"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㏧"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㏨")]
l1ll11l11l11_l1_ = [l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㏩"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ㏪"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㏫"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ㏬")]
l1ll11l11l11_l1_ += [l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ㏭"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ㏮"),l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭㏯"),l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ㏰")]
l1ll11l11l11_l1_ += [l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㏱"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ㏲"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㏳")]
l1ll11l11l11_l1_ += [l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㏴"),l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㏵"),l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㏶"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㏷"),l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㏸"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㏹")]
l1ll11l11l11_l1_ += [l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㏺"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㏻"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㏼"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㏽"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㏾"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㏿")]
l1ll1lll1l1_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㐀"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㐁"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㐂"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㐃")]
l1ll1lll1l1_l1_ += [l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㐄"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ㐅"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㐆"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㐇"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ㐈"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫ㐉")]
l1lll1111ll_l1_ = [l1l111_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ㐊"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㐋"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㐌"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㐍"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㐎"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㐏")]
l1lll1111ll_l1_ += [l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㐐"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㐑"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㐒"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㐓"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭㐔")]
l1lll1lllll_l1_ = [l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㐕"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㐖"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㐗"),l1l111_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㐘"),l1l111_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㐙"),l1l111_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㐚")]
l1lll1lllll_l1_ += [l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㐛"),l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㐜"),l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㐝"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㐞"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㐟"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㐠"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㐡")]
l1lll1l1ll1l_l1_  = [l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㐢"),l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㐣"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㐤"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㐥"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㐦"),l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㐧"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㐨"),l1l111_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ㐩")]
l1lll1l1ll1l_l1_ += [l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㐪"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㐫"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㐬"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㐭"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭㐮"),l1l111_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ㐯"),l1l111_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ㐰")]
l1lll1l1ll1l_l1_ += [l1l111_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㐱"),l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㐲"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ㐳"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ㐴"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㐵"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㐶"),l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭㐷")]
l1lll1l1ll1l_l1_ += [l1l111_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㐸"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㐹"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㐺"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㐻"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ㐼"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ㐽"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㐾")]
l1lll1l1ll1l_l1_ += [l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㐿"),l1l111_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㑀"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㑁"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㑂"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㑃"),l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ㑄"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㑅")]
l1ll1l1lll1l_l1_  = [l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ㑆"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ㑇"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㑈"),l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭㑉"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭㑊")]
l1ll1l1lll1l_l1_ += [l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ㑋"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ㑌")]
l1ll1l1lll1l_l1_ += [l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭㑍"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㑎"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㑏")]
l1ll1l1lll1l_l1_ += [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ㑐"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㑑"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ㑒")]
l1ll1l1lll1l_l1_ += [l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭㑓"),l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㑔"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ㑕")]
l1ll1lll1ll1_l1_ = [l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ㑖"),l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㑗"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㑘"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㑙"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㑚")]
l1lll1l1111_l1_ = l1lll1l1ll1l_l1_+l1ll1l1lll1l_l1_
l1lll11l1ll1_l1_ = l1lll1l1ll1l_l1_+l1ll1lll1ll1_l1_
l11llllll11_l1_ = l1lll1l1ll1l_l1_+l1ll1l1lll1l_l1_
l1lll11llll_l1_ = l1ll11l11l11_l1_+l1lll1111ll_l1_+l1lll1lllll_l1_+l1ll1lll1l1_l1_
l1lll1111ll1_l1_ = [
						l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ㑛")
						,l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨ㑜")
						,l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡚ࡒࡔࡊࡡ࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ㑝")
						]
l111111l1l1_l1_ = [
						l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭㑞")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭㑟")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫ㑠")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ㑡")
						,l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧ㑢")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㑣")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫ㑤")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬ㑥")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭㑦")
						,l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ㑧")
						,l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫ㑨")
						,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ㑩")
						,l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ㑪")
						]
l11l1l1ll11_l1_ = l111111l1l1_l1_+[
				 l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡕࡓ࡝࡟࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ㑫")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡌ࡙࡚ࡐࡔࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭㑬")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ㑭")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠵ࡲࡩ࠭㑮")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠵ࡸࡺࠧ㑯")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠷ࡴࡤࠨ㑰")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠶ࡹࡴࠨ㑱")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩ㑲")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠳ࡳࡦࠪ㑳")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡇࡍࡋࡃࡌࡡࡋࡘ࡙ࡖࡓࡠࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭㑴")
				,l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭㑵")
				,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧ㑶")
				,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠷ࡴࡤࠨ㑷")
				,l1l111_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫ㑸")
				,l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘ࠳ࡓࡉࡑ࡚ࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪ㑹")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㑺")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ㑻")
				]
l1111ll1lll_l1_ = [l1l111_l1_ (u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ㑼"),l1l111_l1_ (u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ㑽"),l1l111_l1_ (u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭㑾"),l1l111_l1_ (u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧ㑿"),l1l111_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨ㒀"),l1l111_l1_ (u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩ㒁")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㒂")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࡯ࡢ࡯࠱ࡲࡪࡺࠧ㒃")]
			,l1l111_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ㒄")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧ㒅")]
			,l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㒆")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮ࡻࡦࡳ࠮࡯ࡧࡷࠫ㒇")]
			,l1l111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ㒈")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰࠫ㒉")]
			,l1l111_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㒊")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲࡦࡢࡶ࡬ࡱ࡮࠴ࡴࡷࠩ㒋")]
			,l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㒌")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡦ࡬ࠬ㒍")]
			,l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ㒎")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡲࡢࡤ࡬ࡧ࠲ࡺ࡯ࡰࡰࡶ࠲ࡨࡵ࡭ࠨ㒏")]
			,l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㒐")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡡࡣࡵࡨࡩࡩ࠴࡮ࡦࡶࠪ㒑")]
			,l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㒒")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡨࡰࡱࡩࡺࡴࡪ࠮ࡤࡱࡰࠫ㒓")]
			,l1l111_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭㒔")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬ㒕")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㒖")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨ㒗")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ㒘")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪ㒙")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㒚")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭㒛")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ㒜")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡸࡱࡩ࡯ࠩ㒝")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ㒞")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡳࡩࡱࡳࠫ㒟")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭㒠")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯࡮ࠩ㒡")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㒢")	:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠺࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪ㒣")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㒤")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧ㒥")]
			,l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ㒦")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ㒧"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡳࡣࡳ࡬ࡶࡲ࠮ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭㒨")]
			,l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ㒩")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡦ࠲ࡩࡸࡡ࡮ࡣࡶ࠻࠳ࡩ࡯࡮ࠩ㒪")]
			,l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ㒫")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡲ࠲࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ㒬")]
			,l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㒭")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡣࡧࡶࡸ࠳ࡹࡴࡰࡴࡨࠫ㒮")]
			,l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㒯")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭㒰")]
			,l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ㒱")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨ㒲")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㒳")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪ㒴")]
			,l1l111_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭㒵")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬ㒶")]
			,l1l111_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㒷")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬ㒸")]
			,l1l111_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ㒹")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧ㒺")]
			,l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㒻")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡰ࡮ࡴ࡫ࠨ㒼")]
			,l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ㒽")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬ㒾")]
			,l1l111_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭㒿")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬ㓀")]
			,l1l111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ㓁")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬ㓂")]
			,l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㓃")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭㓄"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㓅"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㓆"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㓇"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩ㓈")]
			,l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㓉")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬ㓊")]
			,l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㓋")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡲ࠲ࡰ࡯ࡴ࡬ࡱࡷ࠲ࡹࡼࠧ㓌")]
			,l1l111_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭㓍")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ㓎"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨ㓏")]
			,l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㓐")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴ࡣࡢ࡯ࠪ㓑")]
			,l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㓒")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨ㓓")]
			,l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㓔")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡦࡧ࠮ࡤࡣࡰࠫ㓕")]
			,l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭㓖")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࠴ࡳࡩ࠶ࡸ࠲ࡳ࡫ࡷࡴࠩ㓗")]
			,l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㓘")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭㓙")]
			,l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㓚")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ㓛"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡸࡦࡺࡩࡤ࠰ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ㓜"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸࠬ㓝")]
			,l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㓞")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩ㓟")]
			,l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ㓠")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡹࡰ࠰࠱࠲࠳࠭࠮ࡰࡽࡩࡧࡩࡡ࠶ࡩࡧ࠻ࡴࡪࡥ࠱ࡤ࡬࡫ࡱ࡮࠮࡮ࡻࡦ࡭࡮ࡳࡡ࠮ࡹࡨࡧ࡮࡯࡭ࡢ࠰ࡶ࡬ࡴࡶࠧ㓡")]
			,l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㓢")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭㓣")]
			,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㓤")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭㓥")]
			,l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㓦")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ㓧"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ㓨"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ㓩")]
			,l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ㓪")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㓫"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ㓬"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭㓭")]
			,l1l111_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭㓮")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭㓯"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬ㓰"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫ㓱")]
			}
if 1:
	l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㓲")] = [l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㓳"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㓴"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㓵"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㓶"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㓷"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㓸"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㓹"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㓺"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ㓻")]
	l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ㓼")] = [l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㓽"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㓾"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㓿"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㔀"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㔁"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㔂"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㔃"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ㔄"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ㔅")]
else:
	l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㔆")] = [l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㔇"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㔈"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㔉"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㔊"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㔋"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㔌"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㔍"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㔎"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ㔏")]
	l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㔐")] = [l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㔑"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㔒"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㔓"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㔔"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㔕"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㔖"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㔗"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㔘"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ㔙")]
l111l11l1l1_l1_ = [l1l111_l1_ (u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩ㔚"),l1l111_l1_ (u"ࠨࡔࡈࡔࡔࡘࡔࡔࠩ㔛"),l1l111_l1_ (u"ࠩࡈࡑࡆࡏࡌࡔࠩ㔜"),l1l111_l1_ (u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ㔝"),l1l111_l1_ (u"ࠫࡎ࡙ࡌࡂࡏࡌࡇࡘ࠭㔞"),l1l111_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㔟"),l1l111_l1_ (u"࠭ࡋࡏࡑ࡚ࡒࡊࡘࡒࡐࡔࡖࠫ㔠"),l1l111_l1_ (u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨ㔡"),l1l111_l1_ (u"ࠨࡖࡈࡗ࡙ࡏࡎࡈࠩ㔢")]
l11l11ll1l1_l1_ = [l1l111_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔࠩ㔣"),l1l111_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬ㔤"),l1l111_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭㔥")]
class l1ll1llll111_l1_(l1l1l1lll11_l1_):
	def __init__(self,*args,**kwargs):
		self.l11llll111l_l1_ = -1
	def onClick(self,l1111lll1l1_l1_):
		if l1111lll1l1_l1_>=9010: self.l11llll111l_l1_ = l1111lll1l1_l1_-9010
		self.delete()
	def l11l11l1lll_l1_(self,*args):
		self.l111l1ll111_l1_,self.l1ll1ll1ll11_l1_,self.l1llllll11ll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1lll1ll1ll1_l1_ = args[5],args[6]
		self.l1ll111lll1l_l1_,self.l1ll1l11llll_l1_ = args[7],args[8]
		if self.l1ll111lll1l_l1_>0 or self.l1ll1l11llll_l1_>0: self.l1lll1l11111_l1_ = True
		else: self.l1lll1l11111_l1_ = False
		self.l11111ll111_l1_ = l1ll11lll111_l1_.replace(l1l111_l1_ (u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ㔦"),l1l111_l1_ (u"࠭࡟ࠨ㔧")+str(time.time())+l1l111_l1_ (u"ࠧࡠࠩ㔨"))
		self.l11111ll111_l1_ = self.l11111ll111_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ㔩"),l1l111_l1_ (u"ࠩ࡟ࡠࡡࡢࠧ㔪")).replace(l1l111_l1_ (u"ࠪ࠳࠴࠭㔫"),l1l111_l1_ (u"ࠫ࠴࠵࠯࠰ࠩ㔬"))
		self.l11l1111l11_l1_ = CREATE_IMAGE(self.l111l1ll111_l1_,self.l1ll1ll1ll11_l1_,self.l1llllll11ll_l1_,self.header,self.text,self.profile,self.l1lll1ll1ll1_l1_,self.l1lll1l11111_l1_,self.l11111ll111_l1_)
		self.show()
		self.getControl(9050).setImage(self.l11111ll111_l1_)
		self.getControl(9050).setHeight(self.l11l1111l11_l1_)
		if not self.l1ll1ll1ll11_l1_ and self.l111l1ll111_l1_ and self.l1llllll11ll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l11111ll111_l1_,self.l11l1111l11_l1_
	def l11lll1lll1_l1_(self):
		if self.l1ll111lll1l_l1_:
			self.l1lll11l1l11_l1_ = threading.Thread(target=self.l1llll11l1l1_l1_,args=())
			self.l1lll11l1l11_l1_.start()
		else: self.l11l11l11l1_l1_()
	def l1llll11l1l1_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l111lll1_l1_ in range(1,self.l1ll111lll1l_l1_+1):
			time.sleep(1)
			l1ll11l111l1_l1_ = int(100*l1l111lll1_l1_/self.l1ll111lll1l_l1_)
			self.l1ll11llll1l_l1_(l1ll11l111l1_l1_)
			if self.l11llll111l_l1_>0: break
		self.l11l11l11l1_l1_()
	def l11ll1ll11l_l1_(self):
		if self.l1ll1l11llll_l1_:
			self.l1lll11l1l1l_l1_ = threading.Thread(target=self.l11111ll1ll_l1_,args=())
			self.l1lll11l1l1l_l1_.start()
		else: self.l11l11l11l1_l1_()
	def l11111ll1ll_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1ll111lll1l_l1_)
		for l1l111lll1_l1_ in range(self.l1ll1l11llll_l1_-1,-1,-1):
			time.sleep(1)
			l1ll11l111l1_l1_ = int(100*l1l111lll1_l1_/self.l1ll1l11llll_l1_)
			self.l1ll11llll1l_l1_(l1ll11l111l1_l1_)
			if self.l11llll111l_l1_>0: break
		if self.l1ll1l11llll_l1_>0: self.l11llll111l_l1_ = 10
		self.delete()
	def l1ll11llll1l_l1_(self,l1ll11l111l1_l1_):
		self.l11111l1l11_l1_ = l1ll11l111l1_l1_
		self.getControl(9020).setPercent(self.l11111l1l11_l1_)
	def l11l11l11l1_l1_(self):
		if self.l111l1ll111_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll1ll1ll11_l1_: self.getControl(9011).setEnabled(True)
		if self.l1llllll11ll_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l11111ll111_l1_)
		except: pass
class l11l11l1l11_l1_():
	def __init__(self,l11_l1_=False,l1lll1l111ll_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1lll1l111ll_l1_ = l1lll1l111ll_l1_
		self.l11l1l11ll1_l1_,self.l11lllll1ll_l1_ = [],[]
		self.l1111lll1ll_l1_,self.l1111ll11l1_l1_ = {},{}
		self.l111lll111l_l1_ = []
		self.l1ll11lllll1_l1_,self.l111111llll_l1_,self.l11lll1l111_l1_ = {},{},{}
	def l11l111l1ll_l1_(self,id,func,*args):
		id = str(id)
		self.l1111lll1ll_l1_[id] = l1l111_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㔭")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ࠧ㔮"),id)
		l11llll11ll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l111lll111l_l1_.append(l11llll11ll_l1_)
		return l11llll11ll_l1_
	def start_new_thread(self,id,func,*args):
		l11llll11ll_l1_ = self.l11l111l1ll_l1_(id,func,*args)
		l11llll11ll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1ll11lllll1_l1_[id] = time.time()
		try:
			self.l1111ll11l1_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨ㔯") in str(func) and not self.l1111ll11l1_l1_[id].succeeded:
				l1111l11lll_l1_(l1l111_l1_ (u"ࠨࡈࡲࡶࡨ࡫ࡤࠡࡧࡻ࡭ࡹࠦࡤࡶࡧࠣࡸࡴࠦࡴࡩࡴࡨࡥࡩ࡫ࡤࠡࡑࡓࡉࡓ࡛ࡒࡍࠢࡩࡥ࡮ࡲࠧ㔰"))
			self.l11l1l11ll1_l1_.append(id)
			self.l1111lll1ll_l1_[id] = l1l111_l1_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࠫ㔱")
		except Exception as err:
			if self.l1lll1l111ll_l1_:
				l111l111lll_l1_ = traceback.format_exc()
				if l111l111lll_l1_!=l1l111_l1_ (u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭㔲"): sys.stderr.write(l111l111lll_l1_)
			self.l11lllll1ll_l1_.append(id)
			self.l1111lll1ll_l1_[id] = l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㔳")
		self.l111111llll_l1_[id] = time.time()
		self.l11lll1l111_l1_[id] = self.l111111llll_l1_[id] - self.l1ll11lllll1_l1_[id]
	def l1lll1l111l1_l1_(self):
		for proc in self.l111lll111l_l1_:
			proc.start()
	def l1ll11l11ll1_l1_(self):
		while l1l111_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㔴") in list(self.l1111lll1ll_l1_.values()): time.sleep(1.000)
def l1lll1ll11l1_l1_():
	l1lll111l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㔵"))
	if l1lll111l1ll_l1_==l1l111lll1l_l1_:
		status,l111l1l1l1l_l1_ = l1l111_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ㔶"),False
		return status,l111l1l1l1l_l1_
	try: os.makedirs(addoncachefolder)
	except: pass
	status,l111l1l1l1l_l1_ = l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭㔷"),True
	l11l1ll1ll1_l1_ = [l1l111_l1_ (u"ࠩ࠻࠲࠺࠴࠰ࠨ㔸"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠱࠯࠳࠳࠲࠶࠿ࠧ㔹"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠵࠳࠸࠴ࡢࠩ㔺"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠷࠴࠳࠱ࠩ㔻"),l1l111_l1_ (u"࠭࠲࠱࠴࠵࠲࠵࠸࠮࠱࠴ࠪ㔼"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠶࠳࠷࠰࠯࠴࠵ࠫ㔽"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠸࠴࠰࠴࠰࠳࠺ࠬ㔾"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠷࠱࠵࠻࠭㔿"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠹࠲࠵࠼ࠧ㕀"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠴࠴࠳࠸࠸ࠨ㕁"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠶࠱࠴࠶࠴࠱࠵ࠩ㕂")]
	l1lllllll1ll_l1_ = l11l1ll1ll1_l1_[-1]
	l111ll11111_l1_ = l1ll11l11111_l1_(l1lllllll1ll_l1_)
	l1lllll11111_l1_ = l1ll11l11111_l1_(l1l111lll1l_l1_)
	if l1lllll11111_l1_>l111ll11111_l1_:
		status = l1l111_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㕃")
	return status,l111l1l1l1l_l1_
def l111111l1ll_l1_():
	l11ll111ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡩ࡮ࡣࡪࡩࡸ࠭㕄"))
	if not l11ll111ll1_l1_: l1lll1lll1_l1_ = 5001
	else:
		l1lll1lll1_l1_ = 0
		for root,dirs,l11lllllll_l1_ in os.walk(addonimagesfolder,topdown=False):
			l1lll1lll1_l1_ += len(l11lllllll_l1_)
	if l1lll1lll1_l1_>5000: l1llll1ll1_l1_(addonimagesfolder,True,False)
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡪ࡯ࡤ࡫ࡪࡹࠧ㕅"),str(now))
	return
def l1111l11ll1_l1_(l1lll111lll_l1_,l1llll1ll1ll_l1_):
	succeeded,l111l111l1l_l1_,l11ll11l1ll_l1_ = True,False,False
	type,name,l1l1l11l1ll_l1_,mode,l1l1l1llll1_l1_,l1l11111l1l_l1_,text,context,l1llllll1l1_l1_ = l1lll111lll_l1_
	l1ll1l111ll1_l1_ = type,name,l1l1l11l1ll_l1_,mode,l1l1l1llll1_l1_,l1l11111l1l_l1_,text,l1l111_l1_ (u"ࠩࠪ㕆"),l1llllll1l1_l1_
	l1lll11ll1l1_l1_ = int(mode)
	l1lll11ll11l_l1_ = int(l1lll11ll1l1_l1_%10)
	l1lll11ll1ll_l1_ = int(l1lll11ll1l1_l1_/10)
	l1ll11l11l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ㕇"))
	if not l1ll11l11l1l_l1_: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫ㕈"),l1l111_l1_ (u"ࠬࡇࡕࡕࡑࠪ㕉"))
	l11l111ll1l_l1_,l111l1l1l1l_l1_ = l1lll1ll11l1_l1_()
	if l111l1l1l1l_l1_:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㕊"),l1l111_l1_ (u"ࠧࠨ㕋"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㕌"),l1l111_l1_ (u"ࠩอ้ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦแ๋ࠢฯ๋ฬุใ࡝ࡰศ่๎ࠦวๅวุำฬืࠠาไ่࠾ࡡࡴ࡜࡯ࠩ㕍")+l1l111lll1l_l1_)
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㕎"),l1l111_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㕏"))
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㕐"),l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㕑"))
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㕒"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭㕓"))
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㕔"),l1l111_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨ㕕"))
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㕖"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫ㕗"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭㕘"),l1l111_l1_ (u"ࠧࠨ㕙"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡧࡸࡡ࡬ࡣࠪ㕚"),l1l111_l1_ (u"ࠩࠪ㕛"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭㕜"),l1l111_l1_ (u"ࠫࠬ㕝"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠱ࠨ㕞"),l1l111_l1_ (u"࠭ࠧ㕟"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡲࡲࡷࠬ㕠"),l1l111_l1_ (u"ࠨࠩ㕡"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡫ࡰࡥ࡬࡫ࡳࠨ㕢"),l1l111_l1_ (u"ࠪࠫ㕣"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬ㕤"),l1l111_l1_ (u"ࠬ࠭㕥"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㕦"),l1l111_l1_ (u"ࠧࠨ㕧"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵࠪ㕨"),l1l111_l1_ (u"ࠩࠪ㕩"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬ㕪"),l1l111_l1_ (u"ࠫࠬ㕫"))
		import l1l11lll1ll_l1_
		if l11l111ll1l_l1_==l1l111_l1_ (u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬ㕬"):
			l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㕭"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡖࡍࡒࡖࡌࡆࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㕮")+addon_path+l1l111_l1_ (u"ࠨࠢࡠࠫ㕯"))
			l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ㕰"))
			l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ㕱"))
			l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ㕲"))
			l11l1ll1lll_l1_(True,[main_dbfile])
		else:
			l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㕳"),l1l111_l1_ (u"࠭࠮ࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㕴")+addon_path+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㕵"))
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㕶"),l1l111_l1_ (u"ࠩࠪ㕷"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㕸"),l1l111_l1_ (u"ࠫฯ๋ࠠหอห๎ฯࠦร้ࠢอัิ๐หࠡษ็ษฺีวาࠢส่ัี๊ะࠢ็ฬึ์วๆฮࠣห้็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣวํࠦสๆ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰࠣื๏่่ๆࠢส่ว์ࠠศๆหี๋อๅอࠢหฬ฾฼ࠠศๆไัํ฻วหࠢ็ฺ๊อๆࠡ฻่่ࠥอไษำ้ห๊าࠠษื๋ีฮࠦีฮ์ะอࠥ๎ๅหๅส้้ฯࠧ㕹"))
			l11l1ll1lll_l1_()
			FIX_ALL_DATABASES(False)
			l1l11lll1ll_l1_.l1ll1ll1l11l_l1_()
			l1l11lll1ll_l1_.l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㕺"),False)
			l1l11lll1ll_l1_.l1l1l1ll1ll_l1_(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ㕻"),False)
			l1l11lll1ll_l1_.l11111l1lll_l1_(False)
			l1l11lll1ll_l1_.l1ll1ll1111l_l1_(False)
			l1l11lll1ll_l1_.l111ll1l1ll_l1_(l1l111_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㕼"),l1l111_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ㕽"),False)
			try:
				l11l1ll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㕾"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㕿"),l1l111_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ㖀"),l1l111_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㖁"))
				l1111ll1ll1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㖂"))
				l1111ll1ll1_l1_.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡥࡺࡺ࡯ࡠࡲ࡬ࡧࡰ࠭㖃"),l1l111_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ㖄"))
			except: pass
			try:
				l11l1ll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㖅"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㖆"),l1l111_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ㖇"),l1l111_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㖈"))
				l1111ll1ll1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㖉"))
				l1111ll1ll1_l1_.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡺ࡮ࡪࡥࡰࡡࡴࡹࡦࡲࡩࡵࡻࠪ㖊"),l1l111_l1_ (u"ࠨ࠵ࠪ㖋"))
			except: pass
			try:
				l11l1ll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㖌"),l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ㖍"),l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㖎"),l1l111_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ㖏"))
				l1111ll1ll1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㖐"))
				l1111ll1ll1_l1_.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡗ࡙ࡘࡅࡂࡏࡖࡉࡑࡋࡃࡕࡋࡒࡒࠬ㖑"),l1l111_l1_ (u"ࠨ࠴ࠪ㖒"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l11llllll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll11l1111l_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭㖓"),l1l111lll1l_l1_)
		l1l11lll1ll_l1_.l11ll1l11ll_l1_(False)
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㖔"))
	l1l111l1ll_l1_ = l11ll1lll1l_l1_(l1llll1ll1ll_l1_)
	l1l11ll11ll_l1_ = l11ll1lll1l_l1_(name)
	l1111lll111_l1_ = [0,15,17,19,26,34,50,53]
	l1lll1lll111_l1_ = [0,15,17,19,26,34,50,53]
	l11lll1ll11_l1_ = l1lll11ll1ll_l1_ not in l1lll1lll111_l1_
	l1ll11l1l111_l1_ = l1lll11ll1ll_l1_ in [23,28,71,72]
	l1llll1l1lll_l1_ = l1lll11ll1l1_l1_ in [265,270]
	l1111111ll1_l1_ = (l11lll1ll11_l1_ or l1ll11l1l111_l1_) and not l1llll1l1lll_l1_
	l11l1ll1l11_l1_ = l1ll11l1l1_l1_!=l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㖕") and (l1ll11l1l1_l1_!=l1l111_l1_ (u"ࠬ࠭㖖") or context==l1l111_l1_ (u"࠭ࠧ㖗"))
	l1lll11llll1_l1_ = l1l111_l1_ (u"ࠧࡵࡻࡳࡩࡂ࠭㖘") in l1ll11l1l1_l1_
	l1ll1ll11l11_l1_ = l1lll11ll1l1_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1lll11ll11l_l1_==9 or l1lll11ll1l1_l1_ in [145,516,523,45]
	l11ll1lll11_l1_ = not l1ll1ll11l11_l1_
	l11l1l111ll_l1_ = not l1lll1_l1_
	l1llll1llll1_l1_ = l1l111l1ll_l1_ in [l1l111_l1_ (u"ࠨࠩ㖙"),l1l111_l1_ (u"ࠩ࠱࠲ࠬ㖚")]
	l111l1lll11_l1_ = l1llll1llll1_l1_ or l11ll1lll11_l1_
	l1111l1l11l_l1_ = l1llll1llll1_l1_ or l11l1l111ll_l1_ or l1lll11llll1_l1_
	l1ll1l11l11l_l1_ = l1lll11ll1l1_l1_ not in [260,261,265,270,330,540]
	if l1ll11l11l1l_l1_==l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㖛"): l111l1ll11l_l1_ = l1lll1_l1_ or l1ll1ll11l11_l1_
	else: l111l1ll11l_l1_ = True
	l1ll1ll1ll_l1_ = l1lll11ll1ll_l1_ in [74,75]
	l11111lll1l_l1_ = l1lll11ll1l1_l1_ in [280,720]
	l111ll1l11l_l1_ = not l1ll1ll1ll_l1_ and not l11111lll1l_l1_
	l1ll11l1l1ll_l1_ = l111l1lll11_l1_ and l1111l1l11l_l1_ and l1ll1l11l11l_l1_ and l111l1ll11l_l1_ and l111ll1l11l_l1_
	l11l11lll1l_l1_ = l1ll1l11l11l_l1_ and l111l1ll11l_l1_ and l111ll1l11l_l1_
	l11l11lllll_l1_ = l11l11lll1l_l1_
	l11lllllll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡳࡶࡴࡼࡩࡥࡧࡵࠫ㖜"))
	l111llll11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡧࡴࡪࡥࠨ㖝"))
	if 1 and l11l1ll1l11_l1_ and l1ll11l1l1ll_l1_:
		l11111111l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ㖞"),l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㖟")+l11lllllll1_l1_+l1l111_l1_ (u"ࠨࡡࠪ㖠")+l111llll11l_l1_,l1ll1l111ll1_l1_)
		if l11111111l1_l1_:
			l1l1111111_l1_(l1l111_l1_ (u"ࠩࠪ㖡"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㖢")+l11lllllll1_l1_+l1l111_l1_ (u"ࠫࡤ࠭㖣")+l111llll11l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࡎࡲࡥࡩ࡯࡮ࡨࠢࡰࡩࡳࡻࠠࡧࡴࡲࡱࠥࡩࡡࡤࡪࡨࠫ㖤"))
			if 1 and l1lll11llll1_l1_:
				l11ll1l1ll1_l1_ = []
				from l1ll1l1l11ll_l1_ import l1lllllllll1_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1llll1lll11_l1_ = l1lllllllll1_l1_
				l11ll1l1111_l1_ = GET_ALL_FAVORITES()
				l1111lllll1_l1_ = l1ll11l1l1_l1_
				l11l11ll1ll_l1_,l11l1l11lll_l1_,l1llll1ll111_l1_,l1lll11l11ll_l1_,l11l1llll1l_l1_,l1111l111l1_l1_,l11l1l1l111_l1_,l1llll111111_l1_,l1111l1l1l1_l1_ = EXTRACT_KODI_PATH(l1111lllll1_l1_)
				l1llll1lll1l_l1_ = l11l11ll1ll_l1_,l11l1l11lll_l1_,l1llll1ll111_l1_,l1lll11l11ll_l1_,l11l1llll1l_l1_,l1111l111l1_l1_,l11l1l1l111_l1_,l1l111_l1_ (u"࠭ࠧ㖥"),l1111l1l1l1_l1_
				for l11llllllll_l1_ in l11111111l1_l1_:
					l1ll1lllll11_l1_ = l11llllllll_l1_[l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࡎࡺࡥ࡮ࠩ㖦")]
					if l1ll1lllll11_l1_==l1llll1lll1l_l1_ or l11llllllll_l1_[l1l111_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭㖧")] in [265,270]:
						l11llllllll_l1_ = GET_LIST_ITEM(l1ll1lllll11_l1_,l1llll1lll11_l1_,l11ll1l1111_l1_)
						if l11llllllll_l1_[l1l111_l1_ (u"ࠩࡩࡥࡻࡵࡲࡪࡶࡨࡷࠬ㖨")]:
							l1lll111ll11_l1_ = GET_FAVORITES_CONTEXT_MENU(l11ll1l1111_l1_,l1ll1lllll11_l1_,l11llllllll_l1_[l1l111_l1_ (u"ࠪࡲࡪࡽࡰࡢࡶ࡫ࠫ㖩")])
							l11llllllll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪ㖪")] = l1lll111ll11_l1_+l11llllllll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㖫")]
					l11ll1l1ll1_l1_.append(l11llllllll_l1_)
				settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㖬"),l1l111_l1_ (u"ࠧࠨ㖭"))
				if type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㖮"): l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㖯")+l11lllllll1_l1_+l1l111_l1_ (u"ࠪࡣࠬ㖰")+l111llll11l_l1_,l1ll1l111ll1_l1_,l11ll1l1ll1_l1_,l11l1l1_l1_)
			else: l11ll1l1ll1_l1_ = l11111111l1_l1_
			if type==l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㖱") and l1l111l1ll_l1_!=l1l111_l1_ (u"ࠬ࠴࠮ࠨ㖲") and l1111111ll1_l1_: l1l1l1ll11l_l1_()
			l11l1ll1111_l1_ = CREATE_KODI_MENU(l1ll1l111ll1_l1_,l11ll1l1ll1_l1_,succeeded,l111l111l1l_l1_,l11ll11l1ll_l1_)
			return
	elif type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㖳") and l1ll11l1l1_l1_==l1l111_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㖴") and l11l11lll1l_l1_:
		l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㖵")+l11lllllll1_l1_+l1l111_l1_ (u"ࠩࡢࠫ㖶")+l111llll11l_l1_,l1ll1l111ll1_l1_)
	if l1l111_l1_ (u"ࠪࡣࠬ㖷") in context: l1lll1lll1ll_l1_,l1lll1llll11_l1_ = context.split(l1l111_l1_ (u"ࠫࡤ࠭㖸"),1)
	else: l1lll1lll1ll_l1_,l1lll1llll11_l1_ = context,l1l111_l1_ (u"ࠬ࠭㖹")
	if l1lll1lll1ll_l1_ in [l1l111_l1_ (u"࠭࠱ࠨ㖺"),l1l111_l1_ (u"ࠧ࠳ࠩ㖻"),l1l111_l1_ (u"ࠨ࠵ࠪ㖼"),l1l111_l1_ (u"ࠩ࠷ࠫ㖽"),l1l111_l1_ (u"ࠪ࠹ࠬ㖾")] and l1lll1llll11_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㖿"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㗀"))
		return
	elif l1lll1lll1ll_l1_==l1l111_l1_ (u"࠭࠶ࠨ㗁"):
		if l1lll1llll11_l1_==l1l111_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㗂"): l1ll1lll_l1_(l1l111_l1_ (u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨ㗃"),l1l111_l1_ (u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩ㗄"))
		elif l1lll1llll11_l1_==l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠪ㗅"): l1lll11ll1l1_l1_ = 334
		l1lll_l1_ = l1ll1llllll1_l1_(type,l1l11ll11ll_l1_,l1l1l11l1ll_l1_,l1lll11ll1l1_l1_,l1l1l1llll1_l1_,l1l11111l1l_l1_,text,context,l1llllll1l1_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㗆"))
		return
	elif context==l1l111_l1_ (u"ࠬ࠽ࠧ㗇"):
		from l1111l11ll_l1_ import l1lll111l11_l1_
		l1lll111l11_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㗈"))
		return
	elif context==l1l111_l1_ (u"ࠧ࠹ࠩ㗉"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ㗊")+addon_id+l1l111_l1_ (u"ࠩࡂࡱࡴࡪࡥ࠾ࠩ㗋")+str(mode)+l1l111_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠫࠪ㗌"))
		return
	elif context==l1l111_l1_ (u"ࠫ࠾࠭㗍"):
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㗎"),l1l111_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ㗏"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㗐"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ㗑")) not in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㗒"),l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㗓"),l1l111_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㗔")]: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ㗕"),l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㗖"))
	if not settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹࠧ㗗")): settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳࠨ㗘"),l1111ll1lll_l1_[0])
	l11ll111ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡫ࡰࡥ࡬࡫ࡳࠨ㗙"))
	l11ll111ll1_l1_ = 0 if not l11ll111ll1_l1_ else int(l11ll111ll1_l1_)
	if not l11ll111ll1_l1_ or now-l11ll111ll1_l1_<=0 or now-l11ll111ll1_l1_>l11l1l1_l1_:
		l11llll11ll_l1_ = threading.Thread(target=l111111l1ll_l1_)
		l11llll11ll_l1_.start()
	l1ll11ll1l1l_l1_ = False if l1l111ll1ll_l1_(l1l111_l1_ (u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ㗚")) else True
	l11llll1111_l1_ = l111l11l_l1_ if l1ll11ll1l1l_l1_ else l11l1l1_l1_
	l11ll1lllll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㗛"))
	l1ll1l11l1l1_l1_ = l1111l11l1l_l1_(settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㗜")))
	l1ll1l11l1l1_l1_ = 0 if not l1ll1l11l1l1_l1_ else int(l1ll1l11l1l1_l1_)
	if l11ll1lllll_l1_ in [l1l111_l1_ (u"࠭ࠧ㗝"),l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㗞")] or not l11llll1111_l1_ or not l1ll1l11l1l1_l1_ or now-l1ll1l11l1l1_l1_<0 or now-l1ll1l11l1l1_l1_>l11llll1111_l1_:
		l11ll1lllll_l1_ = l1ll1l11ll1l_l1_(True,False)
	l11lll1l11l_l1_ = l1111l11l1l_l1_(settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪ㗟")))
	l11lll1l11l_l1_ = 0 if not l11lll1l11l_l1_ else int(l11lll1l11l_l1_)
	l11l1l11l11_l1_ = l1111l11l1l_l1_(settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㗠")))
	l11l1l11l11_l1_ = 0 if not l11l1l11l11_l1_ else int(l11l1l11l11_l1_)
	if not l11lll1l11l_l1_ or not l11l1l11l11_l1_ or now-l11l1l11l11_l1_<0 or now-l11l1l11l11_l1_>l11lll1l11l_l1_:
		l1lll111l111_l1_ = 1
		if l1ll11ll1l1l_l1_:
			l1ll1lllll1l_l1_ = l11lll11l1l_l1_(True)
			if len(l1ll1lllll1l_l1_)>1:
				l1l1111111_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㗡"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡔࡪࡲࡻ࡮ࡴࡧࠡࡓࡸࡩࡸࡺࡩࡰࡰࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ㗢")+addon_path+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㗣"))
				id,l1ll111llll1_l1_,l111l1111l1_l1_,l11l11l1111_l1_,l11l111ll11_l1_,reason = l1ll1lllll1l_l1_[0]
				l1111llll11_l1_,l1111llll1l_l1_ = l11l11l1111_l1_.split(l1l111_l1_ (u"࠭࡜࡯࠽࠾ࠫ㗤"))
				del l1ll1lllll1l_l1_[0]
				l1lll11lll11_l1_ = random.sample(l1ll1lllll1l_l1_,1)
				id,l1ll111llll1_l1_,l111l1111l1_l1_,l11l11l1111_l1_,l11l111ll11_l1_,reason = l1lll11lll11_l1_[0]
				l111l1111l1_l1_ = l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠼ࠣࠫ㗥")+id+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㗦")+l111l1111l1_l1_
				l11l111ll11_l1_ = l1l111_l1_ (u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨ㗧")
				l11111l11ll_l1_ = l1l111_l1_ (u"ࠪห้ะศา฻สฮࠬ㗨")
				l111l1ll111_l1_,l1ll1ll1ll11_l1_ = l11l11l1111_l1_,l11l111ll11_l1_
				l111llll_l1_ = [l111l1ll111_l1_,l1ll1ll1ll11_l1_,l11111l11ll_l1_]
				l11l111111l_l1_ = 1 if l1l111ll1ll_l1_(l1l111_l1_ (u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ㗩")) else 10
				l11l11111l1_l1_ = -9
				while l11l11111l1_l1_<0:
					l11l1l1l1ll_l1_ = random.sample(l111llll_l1_,3)
					l11l11111l1_l1_ = l1ll11l1ll11_l1_(l1l111_l1_ (u"ࠬ࠭㗪"),l11l1l1l1ll_l1_[0],l11l1l1l1ll_l1_[1],l11l1l1l1ll_l1_[2],l1111llll11_l1_,l111l1111l1_l1_,l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㗫"),l11l111111l_l1_,60)
					if l11l11111l1_l1_==10: break
					from l1l11lll1ll_l1_ import l1lll1l1l11l_l1_,l1l1l11lll1_l1_
					if l11l11111l1_l1_>=0 and l11l1l1l1ll_l1_[l11l11111l1_l1_]==l111llll_l1_[1]:
						l1lll1l1l11l_l1_()
						if l11l11111l1_l1_>=0: l11l11111l1_l1_ = -9
					elif l11l11111l1_l1_>=0 and l11l1l1l1ll_l1_[l11l11111l1_l1_]==l111llll_l1_[2]:
						l1l1l11lll1_l1_(False)
					if l11l11111l1_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㗬"),l1l111_l1_ (u"ࠨࠩ㗭"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㗮"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ㗯"))
				l1lll111l111_l1_ = 1
			else: l1lll111l111_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㗰"),l1lll1l1ll11_l1_(now))
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㗱"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ㗲"),l1lll111l111_l1_,l1ll111l1l1_l1_)
	l1lll_l1_ = l1ll1llllll1_l1_(type,l1l11ll11ll_l1_,l1l1l11l1ll_l1_,mode,l1l1l1llll1_l1_,l1l11111l1l_l1_,text,context,l1llllll1l1_l1_)
	if l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㗳") in text: l111l111l1l_l1_ = True
	if type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㗴"):
		if l1l111l1ll_l1_!=l1l111_l1_ (u"ࠩ࠱࠲ࠬ㗵") and l1111111ll1_l1_: l1l1l1ll11l_l1_()
		if addon_handle>-1:
			if (l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪ࡭ࡳࡺࠧ㗶"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㗷"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ㗸")) or l1lll11ll1l1_l1_ not in l1111lll111_l1_) and not l1l111ll1ll_l1_(l1l111_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ㗹")):
				from l1ll1l1l11ll_l1_ import l1lllllllll1_l1_
				l11111111l1_l1_ = GET_ALL_LIST_ITEMS(l1lllllllll1_l1_)
				l11l1ll1111_l1_ = CREATE_KODI_MENU(l1ll1l111ll1_l1_,l11111111l1_l1_,succeeded,l111l111l1l_l1_,l11ll11l1ll_l1_)
				if 1 and l11111111l1_l1_ and l11l11lllll_l1_:
					l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㗺")+l11lllllll1_l1_+l1l111_l1_ (u"ࠨࡡࠪ㗻")+l111llll11l_l1_,l1ll1l111ll1_l1_,l11111111l1_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㗼")+addon_id+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ㗽"),xbmcgui.ListItem(l1l111_l1_ (u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪ㗾")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㗿")+addon_id+l1l111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭㘀"),xbmcgui.ListItem(l1l111_l1_ (u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭㘁")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l111l1l_l1_,l11ll11l1ll_l1_)
	return
def l1ll1llllll1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_):
	l1lll11ll1l1_l1_ = int(mode)
	l1lll11ll1ll_l1_ = int(l1lll11ll1l1_l1_//10)
	if   l1lll11ll1ll_l1_==0:  from l1l11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,text)
	elif l1lll11ll1ll_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==2:  from l1ll1ll1lll_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==3:  from l11l11ll111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,l1llllll1_l1_)
	elif l1lll11ll1ll_l1_==5:  from l11lll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==8:  from l1ll1lll111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==9:  from l111111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==10: from l1llll1ll1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url)
	elif l1lll11ll1ll_l1_==11: from l1ll1lll11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==12: from l11l11l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==14: from l11ll1ll1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1lll11ll1ll_l1_==15: from l1l11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,text)
	elif l1lll11ll1ll_l1_==16: from l1ll1ll11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,l1llllll1_l1_,l1llllll1l1_l1_)
	elif l1lll11ll1ll_l1_==17: from l1l11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,text)
	elif l1lll11ll1ll_l1_==18: from l1ll11ll1111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==19: from l1l11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,text)
	elif l1lll11ll1ll_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==21: from l11l1111111_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==22: from l111l1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_,l1llllll1l1_l1_)
	elif l1lll11ll1ll_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==26: from l1ll1l1l11ll_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1lll11ll1l1_l1_,context)
	elif l1lll11ll1ll_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_,l1llllll1l1_l1_)
	elif l1lll11ll1ll_l1_==29: from l11ll1111ll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==30: from l1lllllll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==31: from l11l11llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==32: from l1ll11lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==33: from l11lll1l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url)
	elif l1lll11ll1ll_l1_==34: from l1l11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,text)
	elif l1lll11ll1ll_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==36: from l1llll11l111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==38: from l11l1l1111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==39: from l1llll1llll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==40: from l1l1l1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll11ll1ll_l1_==41: from l1l1l1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll11ll1ll_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==43: from l111l111l1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==44: from l111l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==45: from l11llll1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==46: from l1111l1l111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==47: from l11111111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==48: from l1ll1l1ll111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==49: from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==50: from l1l11lll1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,text)
	elif l1lll11ll1ll_l1_==51: from l1111l11l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==52: from l1111l11l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==53: from l1ll1l1l11ll_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==54: from l1111l11ll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,l1llllll1_l1_)
	elif l1lll11ll1ll_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==56: from l1ll1llll11l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==57: from l1llll1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==58: from l11ll11lll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==59: from l1llll11ll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==60: from l1llll11l11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==62: from l1lllll11ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==63: from l11111ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==64: from l111l111l11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==66: from l11ll1llll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==67: from l1ll11ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==68: from l11ll11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==70: from l1ll111ll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_,l1llllll1l1_l1_)
	elif l1lll11ll1ll_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll11ll1l1_l1_,url,text,type,l1llllll1_l1_,l1llllll1l1_l1_)
	elif l1lll11ll1ll_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==74: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_)
	elif l1lll11ll1ll_l1_==75: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_)
	elif l1lll11ll1ll_l1_==76: from l1ll1ll11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text,l1llllll1_l1_,l1llllll1l1_l1_)
	elif l1lll11ll1ll_l1_==77: from l111llll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==78: from l111ll1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==79: from l111ll11l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==80: from l111l1ll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	elif l1lll11ll1ll_l1_==81: from l1ll11llll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,text)
	elif l1lll11ll1ll_l1_==82: from l1111ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11ll1l1_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l1llllllllll_l1_(code,reason,source,l11_l1_):
	l11111lll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ㘂"))
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㘃"),l1l111_l1_ (u"ࠪࠫ㘄"))
	if l1l111_l1_ (u"ࠫ࠲࠭㘅") in source: l1lll11l1ll_l1_ = source.split(l1l111_l1_ (u"ࠬ࠳ࠧ㘆"),1)[0]
	else: l1lll11l1ll_l1_ = source
	l11l1ll111l_l1_ = code in [7,11001,11002,10054]
	l1ll11l1l1l1_l1_ = reason.lower()
	l111l1lll1l_l1_ = code in [0,104,10061,111]
	l1llllll11l1_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ㘇") in l1ll11l1l1l1_l1_
	l1llllll111l_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ㘈") in l1ll11l1l1l1_l1_
	l1llllll1111_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ㘉") in l1ll11l1l1l1_l1_
	l1lllll1llll_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ㘊") in l1ll11l1l1l1_l1_
	l1ll1ll11lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ㘋"))
	l1ll1l1l1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ㘌"))
	l1111ll1111_l1_ = l1l111_l1_ (u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ㘍")
	l1111l111ll_l1_ = l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥ࠭㘎")+str(code)+l1l111_l1_ (u"ࠧ࠻ࠢࠪ㘏")+reason
	l1111l111ll_l1_ = l111l11_l1_(l1111l111ll_l1_)
	if l111l1lll1l_l1_ or l1llllll11l1_l1_ or l1llllll111l_l1_ or l1llllll1111_l1_ or l1lllll1llll_l1_:
		l1111ll1111_l1_ += l1l111_l1_ (u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨ㘐")
	if l11l1ll111l_l1_: l1111ll1111_l1_ += l1l111_l1_ (u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩ㘑")
	l1111l111ll_l1_ = l1l111_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㘒")+l1111l111ll_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㘓")
	if l1ll1ll11lll_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㘔") or l1ll1l1l1ll1_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㘕"):
		l1111ll1111_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㘖")
	l11lll1111l_l1_ = False
	if l11_l1_ and source not in l111111l1l1_l1_:
		if l1ll1ll11lll_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㘗") or l1ll1l1l1ll1_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㘘"):
			l11l11111l1_l1_ = l1ll11l1ll11_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㘙"),l1l111_l1_ (u"ࠫำื่อࠩ㘚"),l1l111_l1_ (u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫ㘛"),l1l111_l1_ (u"࠭ลึๆสัࠥอไๆึๆ่ฮ࠭㘜"),l1lll11l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㘝")+TRANSLATE(l1lll11l1ll_l1_),l1111ll1111_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㘞")+l1111l111ll_l1_)
			if l11l11111l1_l1_==1:
				from l1l11lll1ll_l1_ import l1lll1l1l11l_l1_
				l1lll1l1l11l_l1_()
			elif l11l11111l1_l1_==2: l11lll1111l_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㘟"),l1l111_l1_ (u"ࠪࠫ㘠"),l1lll11l1ll_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠨ㘡")+TRANSLATE(l1lll11l1ll_l1_),l1111ll1111_l1_,l1111l111ll_l1_)
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㘢"),l11111lll11_l1_)
	return l11lll1111l_l1_
def l11l1ll1lll_l1_(l1ll1l1l111l_l1_=False,l1ll1ll111ll_l1_=[]):
	l1111ll11ll_l1_ = [l1l11llllll_l1_,favoritesfile,l1ll11l1111l_l1_]+l1ll1ll111ll_l1_
	for filename in os.listdir(addoncachefolder):
		if l1ll1l1l111l_l1_ and (filename.startswith(l1l111_l1_ (u"࠭ࡩࡱࡶࡹࠫ㘣")) or filename.startswith(l1l111_l1_ (u"ࠧ࡮࠵ࡸࠫ㘤"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡥࠧ㘥")): continue
		l1111111l1l_l1_ = os.path.join(addoncachefolder,filename)
		if l1111111l1l_l1_ in l1111ll11ll_l1_: continue
		try: os.remove(l1111111l1l_l1_)
		except: pass
	if addonimagesfolder not in l1111ll11ll_l1_: l1llll1ll1_l1_(addonimagesfolder,True,False)
	time.sleep(1)
	return
def l1llll1l111l_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l11l_l1_=True,l1lll1ll1111_l1_=True):
	url = url+l1l111_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ㘦")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l11l_l1_,l1lll1ll1111_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l1111l11lll_l1_(l1l111_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ㘧"))
	return response
def l1ll1l1l1l11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㘨"),url,l1l111_l1_ (u"ࠬ࠭㘩"),l1l111_l1_ (u"࠭ࠧ㘪"),True,l1l111_l1_ (u"ࠧࠨ㘫"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ㘬"),True,False)
	l11lllll1l1_l1_ = []
	if response.succeeded:
		html = response.content
		l1lll1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡨࢀ࠷ࠬ࠴ࡿࡰࡷࠬ㘭"),html)
		if l1lll1l1l1l1_l1_: html = l1l111_l1_ (u"ࠪࡠࡳ࠭㘮").join(l1lll1l1l1l1_l1_)
		proxies = html.replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㘯"),l1l111_l1_ (u"ࠬ࠭㘰")).strip(l1l111_l1_ (u"࠭࡜࡯ࠩ㘱")).split(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㘲"))
		l11lllll1l1_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠨ࠰ࠪ㘳"))==3: l11lllll1l1_l1_.append(proxy)
	return l11lllll1l1_l1_
def l11ll11l1l1_l1_(*args):
	l11lll1l1l1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ㘴")
	l1llllll1lll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ㘵")
	l111l1ll1ll_l1_ = l1ll1l1l1l11_l1_(l1llllll1lll_l1_)
	l11lllll1l1_l1_ = l1ll1l1l1l11_l1_(l11lll1l1l1_l1_)
	l11llll1ll1_l1_ = l111l1ll1ll_l1_+l11lllll1l1_l1_
	l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㘶"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫ㘷")+str(len(l111l1ll1ll_l1_))+l1l111_l1_ (u"࠭ࠫࠨ㘸")+str(len(l11lllll1l1_l1_))+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㘹"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㘺"))
	response = l1l1llll1l1_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㘻"),l1l111_l1_ (u"ࠪࠫ㘼"))
	if proxy or l11llll1ll1_l1_:
		id,l1l111111ll_l1_ = 0,10
		l111ll1ll11_l1_ = len(l11llll1ll1_l1_)
		l111lllll1l_l1_ = l1l111111ll_l1_
		if l111ll1ll11_l1_>l111lllll1l_l1_: counts = l111lllll1l_l1_
		else: counts = l111ll1ll11_l1_
		l11l1l1l1l1_l1_ = random.sample(l11llll1ll1_l1_,counts)
		if proxy: l11l1l1l1l1_l1_ = [proxy]+l11l1l1l1l1_l1_
		threads = l11l11l1l11_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l111111ll_l1_ and not threads.l11l1l11ll1_l1_:
			if id<counts:
				proxy = l11l1l1l1l1_l1_[id]
				threads.start_new_thread(id,l1llll1l111l_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㘽"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㘾")+proxy+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㘿"))
		l11l1l11ll1_l1_ = threads.l11l1l11ll1_l1_
		if l11l1l11ll1_l1_:
			l1111ll11l1_l1_ = threads.l1111ll11l1_l1_
			l1111l1111l_l1_ = l11l1l11ll1_l1_[0]
			response = l1111ll11l1_l1_[l1111l1111l_l1_]
			proxy = l11l1l1l1l1_l1_[int(l1111l1111l_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㙀"),proxy)
			if l1111l1111l_l1_!=0: l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㙁"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ㙂")+proxy+l1l111_l1_ (u"ࠪࠤࡢ࠭㙃"))
			else: l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㙄"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㙅")+proxy+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㙆"))
	return response
def l1ll1l111l11_l1_(connection,l1ll11ll1l11_l1_):
	l111l1llll1_l1_ = connection.create_connection
	def l1lll111111l_l1_(address,*args,**kwargs):
		host,port = address
		l1lll11lllll_l1_ = DNS_RESOLVER(host,l1ll11ll1l11_l1_)
		if l1lll11lllll_l1_: host = l1lll11lllll_l1_[0]
		else:
			if l1ll11ll1l11_l1_ in l1111ll1lll_l1_: l1111ll1lll_l1_.remove(l1ll11ll1l11_l1_)
			if l1111ll1lll_l1_:
				l111lll11ll_l1_ = l1111ll1lll_l1_[0]
				l1lll11lllll_l1_ = DNS_RESOLVER(host,l111lll11ll_l1_)
				if l1lll11lllll_l1_: host = l1lll11lllll_l1_[0]
		address = (host,port)
		return l111l1llll1_l1_(address,*args,**kwargs)
	connection.create_connection = l1lll111111l_l1_
	return l111l1llll1_l1_
def l1ll11l1lll1_l1_(url):
	l11l1ll1l1l_l1_,l111l1l1111_l1_ = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ㙇"))[2],80
	if l1l111_l1_ (u"ࠨ࠼ࠪ㙈") in l11l1ll1l1l_l1_: l11l1ll1l1l_l1_,l111l1l1111_l1_ = l11l1ll1l1l_l1_.split(l1l111_l1_ (u"ࠩ࠽ࠫ㙉"))
	l1111l1ll11_l1_ = l1l111_l1_ (u"ࠪ࠳ࠬ㙊")+l1l111_l1_ (u"ࠫ࠴࠭㙋").join(url.split(l1l111_l1_ (u"ࠬ࠵ࠧ㙌"))[3:])
	request = l1l111_l1_ (u"࠭ࡇࡆࡖࠣࠫ㙍")+l1111l1ll11_l1_+l1l111_l1_ (u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧ㙎")
	request += l1l111_l1_ (u"ࠨࡊࡲࡷࡹࡀࠠࠨ㙏")+l11l1ll1l1l_l1_+l1l111_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㙐")
	request += l1l111_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ㙑")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1ll1l1l_l1_,l111l1l1111_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"ࠫࠬ㙒")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"ࠬ࠴ࠧ㙓") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ㙔")
	l11111llll1_l1_,l1lll1111l1l_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠯ࠩ㙕"),1)
	l1lll1111l11_l1_,l1lll11111ll_l1_ = l1lll1111l1l_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ㙖"),1)
	server = l11111llll1_l1_+l1l111_l1_ (u"ࠩ࠱ࠫ㙗")+l1lll1111l11_l1_
	if type in [l1l111_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ㙘"),l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㙙")] and l1l111_l1_ (u"ࠬ࠵ࠧ㙚") in server: server = server.rsplit(l1l111_l1_ (u"࠭࠯ࠨ㙛"),1)[1]
	if type==l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㙜") and l1l111_l1_ (u"ࠨ࠰ࠪ㙝") in server:
		l1ll1lll11l1_l1_ = server.split(l1l111_l1_ (u"ࠩ࠱ࠫ㙞"))
		l1l1l11l11l_l1_ = len(l1ll1lll11l1_l1_)
		if l1l1l11l11l_l1_<=2 or l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㙟") in server: l1ll1lll11l1_l1_ = l1ll1lll11l1_l1_[0]
		elif l1l1l11l11l_l1_>=3: l1ll1lll11l1_l1_ = l1ll1lll11l1_l1_[1]
		if len(l1ll1lll11l1_l1_)>1: server = l1ll1lll11l1_l1_
	return server
def l111ll1ll1l_l1_(l11l11l1ll1_l1_):
	l11l11111ll_l1_ = repr(l11l11l1ll1_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㙠"))).replace(l1l111_l1_ (u"ࠧ࠭ࠢ㙡"),l1l111_l1_ (u"࠭ࠧ㙢"))
	return l11l11111ll_l1_
def l1ll11l111l_l1_(string):
	l1ll1l111l1l_l1_ = l1l111_l1_ (u"ࠧࠨ㙣")
	if PY2: string = string.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㙤"))
	from unicodedata import decomposition
	for l11111l1111_l1_ in string:
		if   l11111l1111_l1_==l1l111_l1_ (u"ࡷࠪฦࠬ㙥"): l11l1111ll1_l1_ = l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫ㙦")
		elif l11111l1111_l1_==l1l111_l1_ (u"ࡹࠬษࠧ㙧"): l11l1111ll1_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭㙨")
		elif l11111l1111_l1_==l1l111_l1_ (u"ࡻࠧลࠩ㙩"): l11l1111ll1_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨ㙪")
		elif l11111l1111_l1_==l1l111_l1_ (u"ࡶࠩศࠫ㙫"): l11l1111ll1_l1_ = l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪ㙬")
		elif l11111l1111_l1_==l1l111_l1_ (u"ࡸࠫห࠭㙭"): l11l1111ll1_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬ㙮")
		else:
			l1ll111ll11l_l1_ = decomposition(l11111l1111_l1_)
			if l1l111_l1_ (u"ࠬࠦࠧ㙯") in l1ll111ll11l_l1_: l11l1111ll1_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷࠪ㙰")+l1ll111ll11l_l1_.split(l1l111_l1_ (u"ࠧࠡࠩ㙱"),1)[1]
			else:
				l11l1111ll1_l1_ = l1l111_l1_ (u"ࠨ࠲࠳࠴࠵࠭㙲")+hex(ord(l11111l1111_l1_)).replace(l1l111_l1_ (u"ࠩ࠳ࡼࠬ㙳"),l1l111_l1_ (u"ࠪࠫ㙴"))
				l11l1111ll1_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵࠨ㙵")+l11l1111ll1_l1_[-4:]
		l1ll1l111l1l_l1_ += l11l1111ll1_l1_
	l1ll1l111l1l_l1_ = l1ll1l111l1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭㙶"),l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧ㙷"))
	if PY2: l1ll1l111l1l_l1_ = l1ll1l111l1l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㙸")).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㙹"))
	else: l1ll1l111l1l_l1_ = l1ll1l111l1l_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㙺")).decode(l1l111_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㙻"))
	return l1ll1l111l1l_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"้ࠫ๎อสࠢส่๊็วห์ะࠫ㙼"),default=l1l111_l1_ (u"ࠬ࠭㙽"),l111llll1ll_l1_=False,source=l1l111_l1_ (u"࠭ࠧ㙾")):
	text = l1lll1l11l11_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠧࠡࠢࠪ㙿"),l1l111_l1_ (u"ࠨࠢࠪ㚀")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ㚁"),l1l111_l1_ (u"ࠪࠤࠬ㚂")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ㚃"),l1l111_l1_ (u"ࠬࠦࠧ㚄"))
	if not text and not l111llll1ll_l1_:
		l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㚅"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫ㚆")+text+l1l111_l1_ (u"ࠨࠤࠪ㚇"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㚈"),l1l111_l1_ (u"ࠪࠫ㚉"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㚊"),l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨ㚋"))
		return l1l111_l1_ (u"࠭ࠧ㚌")
	if text not in [l1l111_l1_ (u"ࠧࠨ㚍"),l1l111_l1_ (u"ࠨࠢࠪ㚎")]:
		text = text.strip(l1l111_l1_ (u"ࠩࠣࠫ㚏"))
		text = l1ll11l111l_l1_(text)
	if source!=l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ㚐") and l11111l_l1_(l1l111_l1_ (u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭㚑"),l1l111_l1_ (u"ࠬ࠭㚒"),[text],False):
		l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㚓"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤࠪ㚔")+text+l1l111_l1_ (u"ࠨࠤࠪ㚕"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㚖"),l1l111_l1_ (u"ࠪࠫ㚗"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㚘"),l1l111_l1_ (u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧ㚙"))
		return l1l111_l1_ (u"࠭ࠧ㚚")
	l1l1111111_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㚛"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫ㚜")+text+l1l111_l1_ (u"ࠩࠥࠫ㚝"))
	return text
def l1l11l11l1_l1_(l1lllll1_l1_,l1ll1ll1l_l1_={}):
	url,l111111lll1_l1_,l1ll1ll11_l1_,l111lll1l11_l1_ = l1lllll1_l1_,{},{},l1l111_l1_ (u"ࠪࠫ㚞")
	if l1l111_l1_ (u"ࠫࢁ࠭㚟") in l1lllll1_l1_: url,l111111lll1_l1_ = l1ll11ll1_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࢂࠧ㚠"))
	l1lll11ll111_l1_ = list(set(list(l1ll1ll1l_l1_.keys())+list(l111111lll1_l1_.keys())))
	for key in l1lll11ll111_l1_:
		if key in list(l111111lll1_l1_.keys()): l1ll1ll11_l1_[key] = l111111lll1_l1_[key]
		else: l1ll1ll11_l1_[key] = l1ll1ll1l_l1_[key]
	if l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㚡") not in l1lll11ll111_l1_: l1ll1ll11_l1_[l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㚢")] = l1l1ll11l_l1_()
	if l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㚣") not in l1lll11ll111_l1_: l1ll1ll11_l1_[l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㚤")] = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㚥"))
	for key in list(l1ll1ll11_l1_.keys()): l111lll1l11_l1_ += l1l111_l1_ (u"ࠫࠫ࠭㚦")+key+l1l111_l1_ (u"ࠬࡃࠧ㚧")+l1ll1ll11_l1_[key]
	if l111lll1l11_l1_: l111lll1l11_l1_ = l1l111_l1_ (u"࠭ࡼࠨ㚨")+l111lll1l11_l1_[1:]
	response = l11l1l_l1_(l1llll1111ll_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㚩"),url,l1l111_l1_ (u"ࠨࠩ㚪"),l1ll1ll11_l1_,l1l111_l1_ (u"ࠩࠪ㚫"),l1l111_l1_ (u"ࠪࠫ㚬"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ㚭"),False,False)
	html = response.content
	if l1l111_l1_ (u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩ㚮") not in html: return [l1l111_l1_ (u"࠭࠭࠲ࠩ㚯")],[url+l111lll1l11_l1_]
	if l1l111_l1_ (u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫ㚰") in html: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㚱")],[url+l111lll1l11_l1_]
	if l1l111_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭㚲") in html: return [l1l111_l1_ (u"ࠪ࠱࠶࠭㚳")],[url+l111lll1l11_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111ll11l11_l1_,l1lll1ll1l1l_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬ㚴"),html+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㚵"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"࠭࠭࠲ࠩ㚶")],[url+l111lll1l11_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1ll11llllll_l1_,l11ll111l11_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠧࠨ㚷")
		items = line.split(l1l111_l1_ (u"ࠨ࠮ࠪ㚸"))
		for item in items:
			if l1l111_l1_ (u"ࠩࡀࠫ㚹") in item:
				key,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ㚺"),1)
				l1ll11llllll_l1_[key.lower()] = value
		if l1l111_l1_ (u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ㚻") in line.lower():
			l11ll111l11_l1_ = int(l1ll11llllll_l1_[l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㚼")])//1024
			title += str(l11ll111l11_l1_)+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭㚽")
		elif l1l111_l1_ (u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㚾") in line.lower():
			l11ll111l11_l1_ = int(l1ll11llllll_l1_[l1l111_l1_ (u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㚿")])//1024
			title += str(l11ll111l11_l1_)+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㛀")
		if l1l111_l1_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ㛁") in line.lower():
			l111l1ll_l1_ = int(l1ll11llllll_l1_[l1l111_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ㛂")].split(l1l111_l1_ (u"ࠬࡾࠧ㛃"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠩ㛄")
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠢࠪ㛅"))
		if not title: title = l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ㛆")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㛇")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࠳࠴࠭㛈")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠫ࠿࠭㛉"),1)[0]+l1l111_l1_ (u"ࠬࡀࠧ㛊")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"࠭࠯ࠨ㛋")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㛌"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪ㛍"),1)[0]+l1l111_l1_ (u"ࠩ࠲ࠫ㛎")+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ㛏") in list(l1ll11llllll_l1_.keys()):
			l111lllll_l1_ = l1ll11llllll_l1_[l1l111_l1_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭㛐")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠬࠨࠧ㛑"),l1l111_l1_ (u"࠭ࠧ㛒")).replace(l1l111_l1_ (u"ࠢࠨࠤ㛓"),l1l111_l1_ (u"ࠨࠩ㛔")).split(l1l111_l1_ (u"ࠩࠦࠫ㛕"),1)[0]
			l11ll1l11l_l1_ = GET_VIDEOFILETYPE(l111lllll_l1_)
			if l11ll1l11l_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠪࠤࠥ࠭㛖")+l11ll1l11l_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫ㛗")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠬࠦࠠࠨ㛘")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㛙"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111ll11l11_l1_.append(l111l1ll_l1_)
			l1lll1ll1l1l_l1_.append(l11ll111l11_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠤࠩ㛚"),1)[0]
		l11ll1l11l_l1_ = GET_VIDEOFILETYPE(l1ll1ll_l1_)
		if l11ll1l11l_l1_: title = title+l1l111_l1_ (u"ࠨࠢࠣࠫ㛛")+l11ll1l11l_l1_
		title = title+l1l111_l1_ (u"ࠩࠣࠤࠬ㛜")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ㛝"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111ll11l11_l1_.append(l111l1ll_l1_)
		l1lll1ll1l1l_l1_.append(l11ll111l11_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111ll11l11_l1_,l1lll1ll1l1l_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111ll11l11_l1_,l1lll1ll1l1l_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	l1ll111lll11_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_: l1ll111lll11_l1_.append(l1ll1ll_l1_+l111lll1l11_l1_)
	return l1l1lll1_l1_,l1ll111lll11_l1_
def DNS_RESOLVER(host,l1ll11ll1l11_l1_=l1l111_l1_ (u"ࠫࠬ㛞")):
	if not l1ll11ll1l11_l1_: l1ll11ll1l11_l1_ = l1111ll1lll_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠬ࠴ࠧ㛟"),l1l111_l1_ (u"࠭ࠧ㛠")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l1lllll11l11_l1_ = pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㛡"), 12049)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㛢"), 256)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㛣"), 1)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㛤"), 0)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㛥"), 0)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㛦"), 0)
		if PY3: l1llllllll1l_l1_ = host.split(l1l111_l1_ (u"࠭࠮ࠨ㛧"))
		else: l1llllllll1l_l1_ = host.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㛨")).split(l1l111_l1_ (u"ࠨ࠰ࠪ㛩"))
		for part in l1llllllll1l_l1_:
			parts = part.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㛪"))
			l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠥࡆࠧ㛫"), len(part))
			for l111l11ll1l_l1_ in part:
				l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠦࡨࠨ㛬"), l111l11ll1l_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㛭")))
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠨࡂࠣ㛮"), 0)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㛯"), 1)
		l1lllll11l11_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㛰"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l1lllll11l11_l1_), (l1ll11ll1l11_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1l1llll_l1_ = unpack_from(l1l111_l1_ (u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ㛱"), data, 0)
		l111lll1111_l1_ = l11l1l1llll_l1_[3]
		offset = len(host)+18
		l11l11l1111_l1_ = []
		for _ in range(l111lll1111_l1_):
			l111ll111l1_l1_ = offset
			l1llll1ll11l_l1_ = 1
			l1111l1llll_l1_ = False
			while True:
				l111l11ll1l_l1_ = unpack_from(l1l111_l1_ (u"ࠥࡂࡇࠨ㛲"), data, l111ll111l1_l1_)[0]
				if l111l11ll1l_l1_ == 0:
					l111ll111l1_l1_ += 1
					break
				if l111l11ll1l_l1_ >= 192:
					l111l111ll1_l1_ = unpack_from(l1l111_l1_ (u"ࠦࡃࡈࠢ㛳"), data, l111ll111l1_l1_ + 1)[0]
					l111ll111l1_l1_ = ((l111l11ll1l_l1_ << 8) + l111l111ll1_l1_ - 0xc000) - 1
					l1111l1llll_l1_ = True
				l111ll111l1_l1_ += 1
				if l1111l1llll_l1_ == False: l1llll1ll11l_l1_ += 1
			if l1111l1llll_l1_ == True: l1llll1ll11l_l1_ += 1
			offset = offset + l1llll1ll11l_l1_
			l11llll11l1_l1_ = unpack_from(l1l111_l1_ (u"ࠧࡄࡈࡉࡋࡋࠦ㛴"), data, offset)
			offset = offset + 10
			l11l1ll11ll_l1_ = l11llll11l1_l1_[0]
			l1111ll111l_l1_ = l11llll11l1_l1_[3]
			if l11l1ll11ll_l1_ == 1:
				l111l11llll_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࠣ㛵")+l1l111_l1_ (u"ࠢࡃࠤ㛶")*l1111ll111l_l1_, data, offset)
				l1lll11lllll_l1_ = l1l111_l1_ (u"ࠨࠩ㛷")
				for l111l11ll1l_l1_ in l111l11llll_l1_: l1lll11lllll_l1_ += str(l111l11ll1l_l1_) + l1l111_l1_ (u"ࠩ࠱ࠫ㛸")
				l1lll11lllll_l1_ = l1lll11lllll_l1_[0:-1]
				l11l11l1111_l1_.append(l1lll11lllll_l1_)
			if l11l1ll11ll_l1_ in [1,2,5,6,15,28]: offset = offset + l1111ll111l_l1_
	except: l11l11l1111_l1_ = []
	if not l11l11l1111_l1_: l1l1111111_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㛹"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ㛺")+host+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㛻"))
	return l11l11l1111_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1l1lll1_l1_ = [l1l111_l1_ (u"࠭ใษษิࠫ㛼"),l1l111_l1_ (u"ࠧษษ็฾ࠬ㛽"),l1l111_l1_ (u"ࠨࡣࡧࡹࡱࡺࠧ㛾"),l1l111_l1_ (u"ࠩࡻࡼࠬ㛿"),l1l111_l1_ (u"ࠪࡷࡪࡾࠧ㜀")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㜁"):
			l11l1l1lll1_l1_ += [l1l111_l1_ (u"ࠬࡸ࠺ࠨ㜂"),l1l111_l1_ (u"࠭ࡲ࠮ࠩ㜃"),l1l111_l1_ (u"ࠧ࠮࡯ࡤࠫ㜄")]
			l11l1l1lll1_l1_ += [l1l111_l1_ (u"ࠨ࠼ࡵࠫ㜅"),l1l111_l1_ (u"ࠩ࠰ࡶࠬ㜆"),l1l111_l1_ (u"ࠪࡱࡦ࠳ࠧ㜇")]
		for l1111llll1_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭㜈") in l1111llll1_l1_: continue
			if l1l111_l1_ (u"ࠬำไใหࠪ㜉") in l1111llll1_l1_: continue
			l1111llll1_l1_ = l1111llll1_l1_.lower()
			if PY2: l1111llll1_l1_ = l1111llll1_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㜊")).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㜋"))
			l1111llll1_l1_ = l1111llll1_l1_.replace(l1l111_l1_ (u"ࠨ࠼ࠪ㜌"),l1l111_l1_ (u"ࠩࠪ㜍"))
			l111l11l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ㜎"),l1111llll1_l1_,re.DOTALL)
			l1lll1ll1lll_l1_ = False
			for digits in l111l11l1ll_l1_:
				if len(digits)==2:
					l1lll1ll1lll_l1_ = True
					break
			if l1l111_l1_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ㜏") in l1111llll1_l1_: continue
			elif l1l111_l1_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭㜐") in l1111llll1_l1_: continue
			elif l1l111_l1_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ㜑") in l1111llll1_l1_: continue
			elif l1l111ll1ll_l1_(l1l111_l1_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ㜒")): continue
			elif l1111llll1_l1_ in [l1l111_l1_ (u"ࠨࡴࠪ㜓")] or l1lll1ll1lll_l1_ or any(value in l1111llll1_l1_ for value in l11l1l1lll1_l1_):
				l1l1111111_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㜔"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㜕")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㜖"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㜗"),l1l111_l1_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ㜘"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1lll1ll1ll1_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1lll1ll1ll1_l1_: l1lll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㜙")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠨษึฮ๊ืวาࠩ㜚")
		header = args[2]
		text = l1l111_l1_ (u"ࠩ࡟ࡲࠬ㜛").join(args[3:])
	else: l1lll1ll1ll1_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠪࠫ㜜"),l1l111_l1_ (u"ࠫࡔࡑࠧ㜝"),l1l111_l1_ (u"ࠬ࠭㜞"),l1l111_l1_ (u"࠭ࠧ㜟")
	l1ll11l1ll11_l1_(l1lll1ll1ll1_l1_,l1l111_l1_ (u"ࠧࠨ㜠"),l11l111l_l1_,l1l111_l1_ (u"ࠨࠩ㜡"),header,text,**kwargs)
	return
def l1ll11ll1l_l1_(*args,**kwargs):
	l1lll1ll1ll1_l1_ = args[0]
	l1lllll11l1l_l1_ = args[1]
	l1llll1l1l1l_l1_ = args[2]
	if l1llll1l1l1l_l1_ or l1lllll11l1l_l1_: l1lllll1111l_l1_ = True
	else: l1lllll1111l_l1_ = False
	header = args[3]
	text = args[4]
	if not l1lll1ll1ll1_l1_: l1lll1ll1ll1_l1_ = l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㜢")
	if not l1lllll11l1l_l1_: l1lllll11l1l_l1_ = l1l111_l1_ (u"ࠪ็้อࠠࠡࡐࡲࠫ㜣")
	if not l1llll1l1l1l_l1_: l1llll1l1l1l_l1_ = l1l111_l1_ (u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭㜤")
	if len(args)>=6: text += l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜥")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"࠭࡜࡯ࠩ㜦")+args[6]
	l11l11111l1_l1_ = l1ll11l1ll11_l1_(l1lll1ll1ll1_l1_,l1lllll11l1l_l1_,l1l111_l1_ (u"ࠧࠨ㜧"),l1llll1l1l1l_l1_,header,text,**kwargs)
	if l11l11111l1_l1_==-1 and l1lllll1111l_l1_: l11l11111l1_l1_ = -1
	elif l11l11111l1_l1_==-1 and not l1lllll1111l_l1_: l11l11111l1_l1_ = False
	elif l11l11111l1_l1_==0: l11l11111l1_l1_ = False
	elif l11l11111l1_l1_==2: l11l11111l1_l1_ = True
	return l11l11111l1_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪ࠭㜨") in list(kwargs.keys()): l111l1ll1l1_l1_ = kwargs[l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㜩")]
	else: l111l1ll1l1_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㜪") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㜫")
	l1ll1l11lll1_l1_ = l1l1l1lll11_l1_(l1l111_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬ㜬"),l1l1l1l1111_l1_,l1l111_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㜭"),l1l111_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㜮"))
	l11111ll111_l1_ = l1ll11lll111_l1_.replace(l1l111_l1_ (u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ㜯"),l1l111_l1_ (u"ࠩࡢࠫ㜰")+str(time.time())+l1l111_l1_ (u"ࠪࡣࠬ㜱"))
	l11111ll111_l1_ = l11111ll111_l1_.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ㜲"),l1l111_l1_ (u"ࠬࡢ࡜࡝࡞ࠪ㜳")).replace(l1l111_l1_ (u"࠭࠯࠰ࠩ㜴"),l1l111_l1_ (u"ࠧ࠰࠱࠲࠳ࠬ㜵"))
	l11l1111l11_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠨࠩ㜶"),l1l111_l1_ (u"ࠩࠪ㜷"),l1l111_l1_ (u"ࠪࠫ㜸"),header,text,profile,l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㜹"),False,l11111ll111_l1_)
	l1ll1l11lll1_l1_.show()
	if profile==l1l111_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㜺"):
		l1ll1l11lll1_l1_.getControl(9040).setHeight(215)
		l1ll1l11lll1_l1_.getControl(9040).setPosition(55,-80)
		l1ll1l11lll1_l1_.getControl(9050).setPosition(120,-60)
		l1ll1l11lll1_l1_.getControl(400).setPosition(90,-35)
	l1ll1l11lll1_l1_.getControl(401).setVisible(False)
	l1ll1l11lll1_l1_.getControl(402).setVisible(False)
	l1ll1l11lll1_l1_.getControl(9050).setImage(l11111ll111_l1_)
	l1ll1l11lll1_l1_.getControl(9050).setHeight(l11l1111l11_l1_)
	l11llll11ll_l1_ = threading.Thread(target=l1ll111ll1ll_l1_,args=(l1ll1l11lll1_l1_,l11111ll111_l1_,l111l1ll1l1_l1_))
	l11llll11ll_l1_.start()
	return
def l1ll111ll1ll_l1_(l1ll1l11lll1_l1_,l11111ll111_l1_,l111l1ll1l1_l1_):
	time.sleep(l111l1ll1l1_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l11111ll111_l1_):
		try: os.remove(l11111ll111_l1_)
		except: pass
	return
def l1ll1l1llll1_l1_(*args,**kwargs):
	header,text,profile,l1lll1ll1ll1_l1_ = l1l111_l1_ (u"࠭ࠧ㜻"),l1l111_l1_ (u"ࠧࠨ㜼"),l1l111_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㜽"),l1l111_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㜾")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1lll1ll1ll1_l1_ = args[3]
	return l1l11l1l11_l1_(l1lll1ll1ll1_l1_,header,text,profile)
def l11l1lllll1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1lll111l11l_l1_(*args,**kwargs)
def l1l111111l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1lll1l11l11_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l111ll1l_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l1l1l1l1ll1_l1_(l1llll1l11l1_l1_):
	if kodi_version>17.99: l1ll1l11lll1_l1_ = l1l111_l1_ (u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨ㜿")
	else: l1ll1l11lll1_l1_ = l1l111_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨ㝀")
	l1llll1l11l1_l1_ = l1llll1l11l1_l1_.lower()
	if l1llll1l11l1_l1_==l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ㝁"): xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨ㝂")+l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠧࠪࠩ㝃"))
	elif l1llll1l11l1_l1_==l1l111_l1_ (u"ࠨࡵࡷࡳࡵ࠭㝄"): xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩ㝅")+l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠪ࠭ࠬ㝆"))
	return
def l1ll11l1ll11_l1_(l1lll1ll1ll1_l1_,l111l1ll111_l1_=l1l111_l1_ (u"ࠫࠬ㝇"),l1ll1ll1ll11_l1_=l1l111_l1_ (u"ࠬ࠭㝈"),l1llllll11ll_l1_=l1l111_l1_ (u"࠭ࠧ㝉"),header=l1l111_l1_ (u"ࠧࠨ㝊"),text=l1l111_l1_ (u"ࠨࠩ㝋"),profile=l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ㝌"),l1llll1lllll_l1_=0,l1lll11l1lll_l1_=0):
	if not l1lll1ll1ll1_l1_: l1lll1ll1ll1_l1_ = l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㝍")
	l1ll1l11lll1_l1_ = l1ll1llll111_l1_(l1l111_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㝎"),l1l1l1l1111_l1_,l1l111_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭㝏"),l1l111_l1_ (u"࠭࠷࠳࠲ࡳࠫ㝐"))
	l1ll1l11lll1_l1_.l11l11l1lll_l1_(l111l1ll111_l1_,l1ll1ll1ll11_l1_,l1llllll11ll_l1_,header,text,profile,l1lll1ll1ll1_l1_,l1llll1lllll_l1_,l1lll11l1lll_l1_)
	if l1llll1lllll_l1_>0: l1ll1l11lll1_l1_.l11lll1lll1_l1_()
	if l1lll11l1lll_l1_>0: l1ll1l11lll1_l1_.l11ll1ll11l_l1_()
	if l1llll1lllll_l1_==0 and l1lll11l1lll_l1_==0: l1ll1l11lll1_l1_.l11l11l11l1_l1_()
	l1ll1l11lll1_l1_.doModal()
	l11l11111l1_l1_ = l1ll1l11lll1_l1_.l11llll111l_l1_
	return l11l11111l1_l1_
def l1l11l1l11_l1_(l1lll1ll1ll1_l1_,header,text,profile=l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㝑")):
	if not l1lll1ll1ll1_l1_: l1lll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㝒")
	l1ll1l11lll1_l1_ = l1l1l1lll11_l1_(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬ㝓"),l1l1l1l1111_l1_,l1l111_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㝔"),l1l111_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㝕"))
	l11111ll111_l1_ = l1ll11lll111_l1_.replace(l1l111_l1_ (u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ㝖"),l1l111_l1_ (u"࠭࡟ࠨ㝗")+str(time.time())+l1l111_l1_ (u"ࠧࡠࠩ㝘"))
	l11111ll111_l1_ = l11111ll111_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ㝙"),l1l111_l1_ (u"ࠩ࡟ࡠࡡࡢࠧ㝚")).replace(l1l111_l1_ (u"ࠪ࠳࠴࠭㝛"),l1l111_l1_ (u"ࠫ࠴࠵࠯࠰ࠩ㝜"))
	l11l1111l11_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠬ࠭㝝"),l1l111_l1_ (u"࠭ࠧ㝞"),l1l111_l1_ (u"ࠧࠨ㝟"),header,text,profile,l1lll1ll1ll1_l1_,False,l11111ll111_l1_)
	l1ll1l11lll1_l1_.show()
	l1ll1l11lll1_l1_.getControl(9050).setHeight(l11l1111l11_l1_)
	l1ll1l11lll1_l1_.getControl(9050).setImage(l11111ll111_l1_)
	result = l1ll1l11lll1_l1_.doModal()
	try: os.remove(l11111ll111_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1lll111ll1l_l1_=True):
	if l1lll111ll1l_l1_:
		l11ll1l1l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡵࡷࡶࠬ㝠"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㝡"),l1l111_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭㝢"))
		if l11ll1l1l1_l1_: return l11ll1l1l1_l1_
	text = l1l111_l1_ (u"ࠫࠬ㝣")
	if 0 and response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭㝤"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㝥"),html,re.DOTALL)
			text = text[0]
	if not text:
		l1llllllll11_l1_ = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㝦"),l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩ㝧"))
		text = open(l1llllllll11_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㝨")).read()
		if PY3: text = text.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㝩"))
		text = text.replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㝪"),l1l111_l1_ (u"ࠬ࠭㝫"))
	l111111ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧ㝬"),text,re.DOTALL)
	l11ll11l111_l1_ = []
	for line in l111111ll11_l1_:
		l1llll11llll_l1_ = line.lower()
		if l1l111_l1_ (u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨ㝭") in l1llll11llll_l1_: continue
		if l1l111_l1_ (u"ࠨࡷࡥࡹࡳࡺࡵࠨ㝮") in l1llll11llll_l1_: continue
		if l1l111_l1_ (u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩ㝯") in l1llll11llll_l1_: continue
		if l1l111_l1_ (u"ࠪࡧࡷࡵࡳࠨ㝰") in l1llll11llll_l1_: continue
		l11ll11l111_l1_.append(line)
	l11ll1l1l1_l1_ = random.sample(l11ll11l111_l1_,1)
	l11ll1l1l1_l1_ = l11ll1l1l1_l1_[0]
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㝱"),l1l111_l1_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ㝲"),l11ll1l1l1_l1_,l11l1l1_l1_)
	return l11ll1l1l1_l1_
def l11l1llll11_l1_(l111l111lll_l1_=l1l111_l1_ (u"࠭ࠧ㝳")):
	if not l111l111lll_l1_: l111l111lll_l1_ = traceback.format_exc()
	if l111l111lll_l1_!=l1l111_l1_ (u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪ㝴"): sys.stderr.write(l111l111lll_l1_)
	lines = l111l111lll_l1_.splitlines()
	error = lines[-1]
	l111ll111ll_l1_ = open(l111lll1ll1_l1_,l1l111_l1_ (u"ࠨࡴࡥࠫ㝵")).read()
	if PY3: l111ll111ll_l1_ = l111ll111ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㝶"))
	l111ll111ll_l1_ = l111ll111ll_l1_[-8000:]
	sep = l1l111_l1_ (u"ࠪࡁࠬ㝷")*100
	if sep in l111ll111ll_l1_: l111ll111ll_l1_ = l111ll111ll_l1_.rsplit(sep,1)[1]
	if error in l111ll111ll_l1_: l111ll111ll_l1_ = l111ll111ll_l1_.rsplit(error,1)[0]
	l1ll1lllllll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪ㝸"),l111ll111ll_l1_,re.DOTALL)
	for typ,source in reversed(l1ll1lllllll_l1_):
		if source: break
	else: source = l1l111_l1_ (u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬ㝹")
	file,line,func = l1l111_l1_ (u"࠭ࠧ㝺"),l1l111_l1_ (u"ࠧࠨ㝻"),l1l111_l1_ (u"ࠨࠩ㝼")
	l11ll111111_l1_ = l1l111_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽ร࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㝽")+error
	l1lll111l1l1_l1_ = l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ีะำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㝾")+source
	for l1lllll111ll_l1_ in reversed(lines):
		if l1l111_l1_ (u"ࠫࡋ࡯࡬ࡦࠢࠥࠫ㝿") in l1lllll111ll_l1_ and l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㞀") in l1lllll111ll_l1_: break
	l1lllll111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩ㞁"),l1lllll111ll_l1_,re.DOTALL)
	if l1lllll111ll_l1_:
		file,line,func = l1lllll111ll_l1_[0]
		if l1l111_l1_ (u"ࠧ࠰ࠩ㞂") in file: file = file.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪ㞃"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠩ࡟ࡠࠬ㞄"),1)[1]
		l1ll1l11l111_l1_ = l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ไโ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㞅")+file
		line2 = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำุำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㞆")+line
		l11lll1llll_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๅส๊࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㞇")+func
		l1lllll111l1_l1_ = l1ll1l11l111_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ㞈")+line2+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㞉")+l11lll1llll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㞊")+l1lll111l1l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㞋")+l11ll111111_l1_
		l1llll111l1l_l1_ = line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㞌")+l1lll111l1l1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㞍")+l11ll111111_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㞎")+l1ll1l11l111_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ㞏")+l11lll1llll_l1_
		l11111111ll_l1_ = line2+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㞐")+l11ll111111_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㞑")+l1ll1l11l111_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㞒")+l11lll1llll_l1_
	else:
		l1ll1l11l111_l1_,line2,l11lll1llll_l1_ = l1l111_l1_ (u"ࠪࠫ㞓"),l1l111_l1_ (u"ࠫࠬ㞔"),l1l111_l1_ (u"ࠬ࠭㞕")
		l1lllll111l1_l1_ = l1lll111l1l1_l1_+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ㞖")+l11ll111111_l1_
		l1llll111l1l_l1_ = l1lll111l1l1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㞗")+l11ll111111_l1_
		l11111111ll_l1_ = l11ll111111_l1_
	l11l11ll11l_l1_ = l1l111_l1_ (u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬ㞘")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㞙")
	l1ll1l11ll11_l1_ = l111llll1l1_l1_()
	l1llllll1l1l_l1_ = []
	l1lll_l1_ = l1ll1l11ll11_l1_[l1l111_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㞚")]
	l1lllll11111_l1_ = l1ll11l11111_l1_(l1l111lll1l_l1_)
	if l1l111_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㞛") in list(l1ll1l11ll11_l1_.keys()):
		for l1lll111l1ll_l1_,l111l11111l_l1_,l11ll1111l1_l1_ in l1lll_l1_: l1llllll1l1l_l1_ = max(l1llllll1l1l_l1_,l111l11111l_l1_)
		if l1lllll11111_l1_<l1llllll1l1l_l1_:
			header = l1l111_l1_ (u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨ㞜")
			l11l11111l1_l1_ = l1ll11l1ll11_l1_(l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㞝"),l1l111_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ㞞"),l1l111_l1_ (u"ࠨฬะำ๏ัࠧ㞟"),l1l111_l1_ (u"ࠩัีําࠧ㞠"),l11l11ll11l_l1_+header,l1lllll111l1_l1_)
			if l11l11111l1_l1_==0:
				l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㞡"),l1l111_l1_ (u"ࠫำื่อࠩ㞢"),l1l111_l1_ (u"ࠬะอะ์ฮࠫ㞣"),l1l111_l1_ (u"࠭ࠧ㞤"),header)
				if l1llll111l_l1_==1: l11l11111l1_l1_ = 1
			if l11l11111l1_l1_==1:
				from l1l11lll1ll_l1_ import l1llll1l1l11_l1_
				l1llll1l1l11_l1_()
			return
	l1ll111ll1l1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㞥"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㞦"),l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ㞧"))
	if not l1ll111ll1l1_l1_: l1ll111ll1l1_l1_ = []
	l1llll111l1l_l1_ = l1llll111l1l_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㞨"),l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㞩")).replace(l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ㞪"),l1l111_l1_ (u"࠭ࠧ㞫")).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㞬"),l1l111_l1_ (u"ࠨࠩ㞭")).replace(l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㞮"),l1l111_l1_ (u"ࠪࠫ㞯"))
	l11111111ll_l1_ = l11111111ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㞰"),l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㞱")).replace(l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ㞲"),l1l111_l1_ (u"ࠧࠨ㞳")).replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㞴"),l1l111_l1_ (u"ࠩࠪ㞵")).replace(l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㞶"),l1l111_l1_ (u"ࠫࠬ㞷"))
	l1ll11l1l11l_l1_ = l1l111lll1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ㞸")+l11111111ll_l1_
	if l1ll11l1l11l_l1_ in l1ll111ll1l1_l1_:
		header = l1l111_l1_ (u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ㞹")
		l1111l1_l1_(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㞺"),l1l111_l1_ (u"ࠨࠩ㞻"),l11l11ll11l_l1_+header,l1lllll111l1_l1_)
		return
	l1ll11ll11ll_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠩ࠱ࠫ㞼"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㞽")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㞾"),url,l1l111_l1_ (u"ࠬ࠭㞿"),l1l111_l1_ (u"࠭ࠧ㟀"),l1l111_l1_ (u"ࠧࠨ㟁"),l1l111_l1_ (u"ࠨࠩ㟂"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪ㟃"),False,False)
	html = response.content
	l11ll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪ㟄"),html,re.DOTALL)
	for l11l11l1l1l_l1_,l11l1llllll_l1_,l11111lllll_l1_,l1llll111l11_l1_ in l11ll1ll111_l1_:
		l11l11l1l1l_l1_ = l11l11l1l1l_l1_.split(l1l111_l1_ (u"ࠫ࠰࠭㟅"))
		l11111lllll_l1_ = l11111lllll_l1_.split(l1l111_l1_ (u"ࠬ࠱ࠧ㟆"))
		l1llll111l11_l1_ = l1llll111l11_l1_.split(l1l111_l1_ (u"࠭ࠫࠨ㟇"))
		if line in l11l11l1l1l_l1_ and error==l11l1llllll_l1_ and l1l111lll1l_l1_ in l11111lllll_l1_ and l1ll11ll11ll_l1_ in l1llll111l11_l1_:
			header = l1l111_l1_ (u"่ࠧาสࠤฬ๊ฮุล้ࠣ฾ื่โ๋ࠢื๏฿วๅฮࠣฬฬ๊ลึัสีࠥอไใษา้ࠬ㟈")
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㟉"),l1l111_l1_ (u"ࠩัีําࠧ㟊"),l1l111_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㟋"),l11l11ll11l_l1_+header,l1lllll111l1_l1_)
			if l1llll111l_l1_==1: l1111l1_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㟌"),l1l111_l1_ (u"ࠬ࠭㟍"),l1l111_l1_ (u"࠭ࠧ㟎"),header)
			return
	header = l1l111_l1_ (u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ㟏")
	l1111l1_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㟐"),l1l111_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㟑"),l11l11ll11l_l1_+header,l1lllll111l1_l1_)
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㟒"),l1l111_l1_ (u"ࠫࠬ㟓"),l1l111_l1_ (u"ࠬ࠭㟔"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㟕"),l1l111_l1_ (u"ࠧิ๊ไࠤ๏ะๅࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏฿ัโࠢส่๊ฮัๆฮࠣว๏์้ࠠ็อํࠥ๎ใ๋ใࠣ์้๋วัษࠣัฺ๊ส้ࠡำ๋ࠥอไๆึๆ่ฮࠦไฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠤํ๊วࠡ์ึฮ฼๐ูࠡษุ่ฬำࠠๆึๆ่ฮ่่๊่ࠦࠣฬฺ๊ࠦำไࠤ่๐แฺ๊ࠡีฯ่ࠦๅ็สิฬุ่ࠦำอࠤํ๋ส๊ࠢ฻๋ึะ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ࠴่ࠠๆࠣฮึ๐ฯࠡลิืฬ๊ࠠศๆึะ้ࠦฟࠨ㟖"))
	if l1llll111l_l1_==1: l1ll11l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ㟗")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㟘"),l1l111_l1_ (u"ࠪࠫ㟙"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㟚"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤส฻ไศฯࠣห้ิืฤࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥอไั์้่ࠣะ่ษࠢไ๎์ࠦฬๆ์฼ࠤฯ็วึ์็ࠤ์ึวࠡษ็า฼ษ้ࠠ฼ํี์ࠦๅ็ࠢส่ศิืศรࠪ㟛"))
		return
	message = l1llll111l1l_l1_
	from l1l11lll1ll_l1_ import l11l1l111l1_l1_
	succeeded = l11l1l111l1_l1_(l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶࡸ࠭㟜"),message,True,l1l111_l1_ (u"ࠧࠨ㟝"),l1l111_l1_ (u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨ㟞"),l1ll11l1ll1l_l1_)
	if succeeded and l1ll11l1ll1l_l1_:
		l1ll111ll1l1_l1_.append(l1ll11l1l11l_l1_)
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㟟"),l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ㟠"),l1ll111ll1l1_l1_,l1ll111l1l1_l1_)
	return
def l1lll111lll1_l1_(data):
	if PY3: data = data.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㟡"))
	filename = l1l111_l1_ (u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬ㟢")+str(time.time())+l1l111_l1_ (u"࠭࠮ࡥࡣࡷࠫ㟣")
	open(filename,l1l111_l1_ (u"ࠧࡸࡤࠪ㟤")).write(data)
	return
def l11lll11l1l_l1_(l111ll1lll1_l1_):
	if l111ll1lll1_l1_:
		l1ll1lllll1l_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㟥"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㟦"),l1l111_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㟧"))
		if l1ll1lllll1l_l1_: return l1ll1lllll1l_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㟨")][5]
	l1ll111llll1_l1_ = l1l11l1l111_l1_(32,l111ll1lll1_l1_)
	l1ll1l11111l_l1_ = l1111ll1l1l_l1_()
	l1llll11ll1l_l1_ = l1ll1l11111l_l1_.split(l1l111_l1_ (u"ࠬ࠲ࠧ㟩"))[2]
	l1ll1lll111l_l1_ = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㟪"))
	l111111l111_l1_ = l1ll1l1111ll_l1_()
	payload = {l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㟫"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ㟬"):l1l111lll1l_l1_,l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㟭"):l1llll11ll1l_l1_,l1l111_l1_ (u"ࠪ࡭ࡩࡹࠧ㟮"):l1lll1l1ll11_l1_(l111111l111_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㟯"),url,payload,l1l111_l1_ (u"ࠬ࠭㟰"),l1l111_l1_ (u"࠭ࠧ㟱"),l1l111_l1_ (u"ࠧࠨ㟲"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭㟳"))
	if not response.succeeded: return []
	html = response.content
	l1ll1lllll1l_l1_ = html.replace(l1l111_l1_ (u"ࠩ࡟ࡠࡷ࠭㟴"),l1l111_l1_ (u"ࠪࡠࡳ࠭㟵")).replace(l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㟶"),l1l111_l1_ (u"ࠬࡢ࡮ࠨ㟷")).replace(l1l111_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ㟸"),l1l111_l1_ (u"ࠧ࡝ࡰࠪ㟹")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㟺"),l1l111_l1_ (u"ࠩ࡟ࡲࠬ㟻"))
	l1ll1lllll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭㟼"),l1ll1lllll1l_l1_,re.DOTALL)
	if not l1ll1lllll1l_l1_: return []
	l1ll1lllll1l_l1_ = sorted(l1ll1lllll1l_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1ll111llll1_l1_,l111l1111l1_l1_,l11l11l1111_l1_,l11l111ll11_l1_,reason = l1ll1lllll1l_l1_[0]
	l1llll111lll_l1_ = reason if l1l111ll1ll_l1_(l1l111_l1_ (u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪ㟽")) else l111l1111l1_l1_
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ㟾"),l1llll111lll_l1_)
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㟿"),l1l111_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㠀"),l1ll1lllll1l_l1_,l11l1l1_l1_)
	return l1ll1lllll1l_l1_
def SPLIT_BIGLIST(items,l1ll11l11lll_l1_=0,l1111111l11_l1_=0):
	if l1ll11l11lll_l1_ and not l1111111l11_l1_: l1111111l11_l1_ = len(items)//l1ll11l11lll_l1_
	l1lll1l1lll1_l1_,l1l111lll1_l1_,l1llll1l1111_l1_ = [],-1,0
	for item in items:
		if l1llll1l1111_l1_%l1111111l11_l1_==0:
			l1l111lll1_l1_ += 1
			l1lll1l1lll1_l1_.append([])
		l1lll1l1lll1_l1_[l1l111lll1_l1_].append(item)
		l1llll1l1111_l1_ += 1
	return l1lll1l1lll1_l1_
def l111lll1l1l_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࠧ㠁") not in filename or l1l111_l1_ (u"ࠩࡐ࠷࡚ࡥࠧ㠂") not in filename: text = str(data)
	else:
		l1lll1l1lll1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"ࠪࠫ㠃")
		for split in l1lll1l1lll1_l1_:
			text += str(split)+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ㠄")
		text = text.strip(l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㠅"))
	l1l1l11ll1l_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"࠭ࡷࡣࠩ㠆")).write(l1l1l11ll1l_l1_)
	return
def l11ll111lll_l1_(l1l1l1l1l1l_l1_,filename):
	if l1l1l1l1l1l_l1_==l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㠇"): data = {}
	elif l1l1l1l1l1l_l1_==l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㠈"): data = []
	elif l1l1l1l1l1l_l1_==l1l111_l1_ (u"ࠩࡶࡸࡷ࠭㠉"): data = l1l111_l1_ (u"ࠪࠫ㠊")
	elif l1l1l1l1l1l_l1_==l1l111_l1_ (u"ࠫ࡮ࡴࡴࠨ㠋"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l11ll1l_l1_ = open(filepath,l1l111_l1_ (u"ࠬࡸࡢࠨ㠌")).read()
	text = zlib.decompress(l1l1l11ll1l_l1_)
	if l1l111_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㠍") not in text: data = eval(text)
	else:
		l1lll1l1lll1_l1_ = text.split(l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㠎"))
		del text
		data = []
		l11l1l1l11l_l1_ = l11l11l1l11_l1_()
		id = 0
		for split in l1lll1l1lll1_l1_:
			l11l1l1l11l_l1_.l11l111l1ll_l1_(str(id),eval,split)
			id += 1
		del l1lll1l1lll1_l1_
		l11l1l1l11l_l1_.l1lll1l111l1_l1_()
		l11l1l1l11l_l1_.l1ll11l11ll1_l1_()
		l1ll1l111111_l1_ = list(l11l1l1l11l_l1_.l1111ll11l1_l1_.keys())
		l1ll1ll11111_l1_ = sorted(l1ll1l111111_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll1ll11111_l1_:
			data += l11l1l1l11l_l1_.l1111ll11l1_l1_[id]
	return data
def l1ll1lll1lll_l1_(addon_id):
	l11l1lll1ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ㠏"),addon_id,l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬ㠐"))
	try: l11llllll1l_l1_ = open(l11l1lll1ll_l1_,l1l111_l1_ (u"ࠪࡶࡧ࠭㠑")).read()
	except:
		l1llll11lll1_l1_ = os.path.join(l111ll11l1l_l1_,l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ㠒"),addon_id,l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ㠓"))
		try: l11llllll1l_l1_ = open(l1llll11lll1_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㠔")).read()
		except: return l1l111_l1_ (u"ࠧࠨ㠕"),[]
	if PY3: l11llllll1l_l1_ = l11llllll1l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㠖"))
	version = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭㠗"),l11llllll1l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"ࠪࠫ㠘"),[]
	l11llll1lll_l1_,l11l111l11l_l1_ = version[0],l1ll11l11111_l1_(version[0])
	return l11llll1lll_l1_,l11l111l11l_l1_
def l111llll1l1_l1_():
	l111l1l1ll1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㠙"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㠚"),l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㠛"))
	if l111l1l1ll1_l1_: return l111l1l1ll1_l1_
	l1ll1l11ll11_l1_,l111l1l1ll1_l1_ = {},{}
	l1ll1lllllll_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㠜")][0]]
	if kodi_version>17.99: l1ll1lllllll_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㠝")][1])
	if PY3: l1ll1lllllll_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㠞")][2])
	for l1ll1ll1l1l1_l1_ in l1ll1lllllll_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㠟"),l1ll1ll1l1l1_l1_,l1l111_l1_ (u"ࠫࠬ㠠"),l1l111_l1_ (u"ࠬ࠭㠡"),l1l111_l1_ (u"࠭ࠧ㠢"),l1l111_l1_ (u"ࠧࠨ㠣"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ㠤"))
		if response.succeeded:
			html = response.content
			l1ll11ll111l_l1_ = l1ll1ll1l1l1_l1_.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫ㠥"),1)[0]
			l111l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㠦"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111lll11l1_l1_ in l111l1l1lll_l1_:
				l11l111l1l1_l1_ = l1ll11ll111l_l1_+l1l111_l1_ (u"ࠫ࠴࠭㠧")+addon_id+l1l111_l1_ (u"ࠬ࠵ࠧ㠨")+addon_id+l1l111_l1_ (u"࠭࠭ࠨ㠩")+l111lll11l1_l1_+l1l111_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ㠪")
				if addon_id not in list(l1ll1l11ll11_l1_.keys()):
					l1ll1l11ll11_l1_[addon_id] = []
					l111l1l1ll1_l1_[addon_id] = []
				l1llll1l1ll1_l1_ = l1ll11l11111_l1_(l111lll11l1_l1_)
				l1ll1l11ll11_l1_[addon_id].append((l111lll11l1_l1_,l1llll1l1ll1_l1_,l11l111l1l1_l1_))
	for addon_id in list(l1ll1l11ll11_l1_.keys()):
		l111l1l1ll1_l1_[addon_id] = sorted(l1ll1l11ll11_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㠫"),l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ㠬"),l111l1l1ll1_l1_,l11l1l1_l1_)
	return l111l1l1ll1_l1_
def l1ll11l11111_l1_(l111lll11l1_l1_):
	l1llll1l1ll1_l1_ = []
	l1llll1l111_l1_ = l111lll11l1_l1_.split(l1l111_l1_ (u"ࠪ࠲ࠬ㠭"))
	for l1l1ll11l1_l1_ in l1llll1l111_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠫࡡࡪࠫࡽ࡝࡟࠯ࡡ࠳ࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠨ㠮"),l1l1ll11l1_l1_,re.DOTALL)
		l1ll1l1111l1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1ll1l1111l1_l1_.append(part)
		l1llll1l1ll1_l1_.append(l1ll1l1111l1_l1_)
	return l1llll1l1ll1_l1_
def l1lll1llll1l_l1_(l1llll1l1ll1_l1_):
	l111lll11l1_l1_ = l1l111_l1_ (u"ࠬ࠭㠯")
	for l1l1ll11l1_l1_ in l1llll1l1ll1_l1_:
		for part in l1l1ll11l1_l1_: l111lll11l1_l1_ += str(part)
		l111lll11l1_l1_ += l1l111_l1_ (u"࠭࠮ࠨ㠰")
	l111lll11l1_l1_ = l111lll11l1_l1_.strip(l1l111_l1_ (u"ࠧ࠯ࠩ㠱"))
	return l111lll11l1_l1_
def l11111l111l_l1_(l11ll111l1l_l1_):
	l1ll11ll11l1_l1_ = {}
	l1ll1l11ll11_l1_ = l111llll1l1_l1_()
	l11ll1ll1ll_l1_ = l1lll1l1111l_l1_(l11ll111l1l_l1_)
	for addon_id in l11ll111l1l_l1_:
		if addon_id not in list(l1ll1l11ll11_l1_.keys()): continue
		l111l1l1ll1_l1_ = l1ll1l11ll11_l1_[addon_id]
		l11ll1l1l11_l1_,l11ll1l11l1_l1_,l1ll111l1ll1_l1_ = l111l1l1ll1_l1_[0]
		l1lllll1ll1l_l1_,l11l1111lll_l1_ = l1ll1lll1lll_l1_(addon_id)
		l11l1lll111_l1_,l111111111l_l1_ = l11ll1ll1ll_l1_[addon_id]
		l11lll11ll1_l1_ = l11ll1l11l1_l1_>l11l1111lll_l1_ and l11l1lll111_l1_
		l1ll111ll111_l1_ = True
		if not l11l1lll111_l1_: l11lllll111_l1_ = l1l111_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ㠲")
		elif not l111111111l_l1_: l11lllll111_l1_ = l1l111_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ㠳")
		elif l11lll11ll1_l1_: l11lllll111_l1_ = l1l111_l1_ (u"ࠪࡳࡱࡪࠧ㠴")
		else:
			l11lllll111_l1_ = l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ㠵")
			l1ll111ll111_l1_ = False
		l1ll11ll11l1_l1_[addon_id] = (l1ll111ll111_l1_,l1lllll1ll1l_l1_,l11l1111lll_l1_,l11ll1l1l11_l1_,l11ll1l11l1_l1_,l11lllll111_l1_,l1ll111l1ll1_l1_)
	return l1ll11ll11l1_l1_
def l1l11111ll_l1_(l1l1111ll1_l1_,l1111lll11l_l1_,l11l11l11ll_l1_=l1l111_l1_ (u"ࠬ࠭㠶"),line2=l1l111_l1_ (u"࠭ࠧ㠷"),l11l11l1l1l_l1_=l1l111_l1_ (u"ࠧࠨ㠸")):
	if PY2: l1l1111ll1_l1_.update(l1111lll11l_l1_,l11l11l11ll_l1_,line2,l11l11l1l1l_l1_)
	else: l1l1111ll1_l1_.update(l1111lll11l_l1_,l11l11l11ll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㠹")+line2+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㠺")+l11l11l1l1l_l1_)
	return
def l1lll1l11l1l_l1_(l11111ll1l1_l1_):
	def l1111111lll_l1_(num,b,l1lll11l1111_l1_=l1l111_l1_ (u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥ㠻")):
		return ((num == 0) and l1lll11l1111_l1_[0]) or (l1111111lll_l1_(num // b, b, l1lll11l1111_l1_).lstrip(l1lll11l1111_l1_[0]) + l1lll11l1111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None, r=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠦࡡࡢࡢࠣ㠼") + l1111111lll_l1_(c, a) + l1l111_l1_ (u"ࠧࡢ࡜ࡣࠤ㠽"),  k[c], p)
		return p
	l11111ll1l1_l1_ = l11111ll1l1_l1_.split(l1l111_l1_ (u"࠭ࡽࠩࠩ㠾"))[1]
	l11111ll1l1_l1_ = l11111ll1l1_l1_.rsplit(l1l111_l1_ (u"ࠧࡴࡲ࡯࡭ࡹ࠭㠿"))[0]+l1l111_l1_ (u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨ㡀")
	l1lll1111lll_l1_ = eval(l1l111_l1_ (u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ㡁")+l11111ll1l1_l1_,{l1l111_l1_ (u"ࠪࡦࡦࡹࡥࡏࠩ㡂"):l1111111lll_l1_,l1l111_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠫ㡃"):unpack})
	return l1lll1111lll_l1_
def l111lll1lll_l1_(url,l1lll1l1llll_l1_=l1l111_l1_ (u"ࠬ࠭㡄")):
	if l1lll1l1llll_l1_==l1l111_l1_ (u"࠭࡬ࡰࡹࡨࡶࠬ㡅"): url = re.sub(l1l111_l1_ (u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧ㡆"),lambda l11lll1ll1l_l1_: l11lll1ll1l_l1_.group(0).lower(),url)
	elif l1lll1l1llll_l1_==l1l111_l1_ (u"ࠨࡷࡳࡴࡪࡸࠧ㡇"): url = re.sub(l1l111_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩ㡈"),lambda l11lll1ll1l_l1_: l11lll1ll1l_l1_.group(0).upper(),url)
	return url
def l1lll1l1111l_l1_(l11ll111l1l_l1_):
	l1lllllll111_l1_,l1111l1ll1l_l1_ = False,False
	conn = sqlite3.connect(l111ll1111l_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	if len(l11ll111l1l_l1_)==1: l111llllll1_l1_ = l1l111_l1_ (u"ࠪࠬࠧ࠭㡉")+l11ll111l1l_l1_[0]+l1l111_l1_ (u"ࠫࠧ࠯ࠧ㡊")
	else: l111llllll1_l1_ = str(tuple(l11ll111l1l_l1_))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬ㡋")+l111llllll1_l1_+l1l111_l1_ (u"࠭ࠠ࠼ࠩ㡌"))
	l1l11lll11l_l1_ = l1llll1lll_l1_.fetchall()
	l11ll1ll1ll_l1_ = {}
	for addon_id in l11ll111l1l_l1_: l11ll1ll1ll_l1_[addon_id] = (False,False)
	for addon_id,l1111l1ll1l_l1_ in l1l11lll11l_l1_:
		l1lllllll111_l1_ = True
		l1111l1ll1l_l1_ = l1111l1ll1l_l1_==1
		l11ll1ll1ll_l1_[addon_id] = (l1lllllll111_l1_,l1111l1ll1l_l1_)
	conn.close()
	return l11ll1ll1ll_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"ࠧࠨ㡍")
	if file==l1ll11l1111l_l1_: status = l1ll1l11ll1l_l1_(True,False)
	if os.path.exists(file):
		l1l11l1ll1l_l1_ = open(file,l1l111_l1_ (u"ࠨࡴࡥࠫ㡎")).read()
		if PY3: l1l11l1ll1l_l1_ = l1l11l1ll1l_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㡏"))
		if file==l1ll11l1111l_l1_: l1lll_l1_ = l1l11l1ll1l_l1_
		else:
			l111l11ll11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㡐"),l1l11l1ll1l_l1_)
			if l111l11ll11_l1_:
				l1lll_l1_ = {}
				for key in l111l11ll11_l1_.keys():
					l1lll_l1_[key] = []
					for l11111l11l1_l1_ in l111l11ll11_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = l1l111_l1_ (u"ࠫࠬ㡑"),l1l111_l1_ (u"ࠬ࠭㡒"),l1l111_l1_ (u"࠭ࠧ㡓"),l1l111_l1_ (u"ࠧࠨ㡔"),l1l111_l1_ (u"ࠨࠩ㡕"),l1l111_l1_ (u"ࠩࠪ㡖"),l1l111_l1_ (u"ࠪࠫ㡗"),l1l111_l1_ (u"ࠫࠬ㡘"),l1l111_l1_ (u"ࠬ࠭㡙")
						type = l11111l11l1_l1_[0]
						name = l11111l11l1_l1_[1]
						name = l11ll1lll1l_l1_(name)
						url = l11111l11l1_l1_[2]
						mode = l11111l11l1_l1_[3]
						l11l_l1_ = l11111l11l1_l1_[4]
						l1llllll1_l1_ = l11111l11l1_l1_[5]
						if len(l11111l11l1_l1_)>6: text = l11111l11l1_l1_[6]
						if len(l11111l11l1_l1_)>7: context = l11111l11l1_l1_[7]
						if len(l11111l11l1_l1_)>8: l1llllll1l1_l1_ = l11111l11l1_l1_[8]
						if file==favoritesfile: l1ll11lll1ll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"࠭ࠧ㡚"),l1llllll1l1_l1_
						else: l1ll11lll1ll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_
						l1lll_l1_[key].append(l1ll11lll1ll_l1_)
			l1l111llll1_l1_ = str(l1lll_l1_)
			if PY3: l1l111llll1_l1_ = l1l111llll1_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㡛"))
			open(file,l1l111_l1_ (u"ࠨࡹࡥࠫ㡜")).write(l1l111llll1_l1_)
	return l1lll_l1_
def l1ll1llll1l_l1_(l1lll11l1ll_l1_):
	l1llll11l1ll_l1_ = l1lll11l1ll_l1_.split(l1l111_l1_ (u"ࠩ࠰ࠫ㡝"),1)[0]
	l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll111l1_l1_ = l1l111_l1_ (u"ࠪࠫ㡞"),l1l111_l1_ (u"ࠫࠬ㡟"),l1l111_l1_ (u"ࠬ࠭㡠")
	if   l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㡡")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㡢")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ㡣")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㡤")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ㡥")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭㡦")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ㡧")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㡨")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ㡩"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㡪")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㡫")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㡬")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㡭")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㡮")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㡯")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㡰"):	from l11111ll1_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㡱"):		from l1111ll11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫ㡲")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㡳")	:	from l111111l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㡴")	:	from l11111111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㡵")	:	from l1lllllll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ㡶"):	from l1l1l1111l_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㡷")	:	from l11ll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ㡸")	:	from l11l11l1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㡹")	:	from l111llll11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㡺")	:	from l111ll1l11_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭㡻")	:	from l111ll11l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㡼")	:	from l111l1ll1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㡽")	:	from l111l111ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ㡾")	:	from l111l111l1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㡿")	:	from l1lllll11ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㢀")	:	from l1llll1llll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㢁")	:	from l1llll1l1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㢂")	:	from l1llll11ll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㢃")		:	from l1llll11l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㢄")	:	from l1ll1lll111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭㢅")		:	from l1ll1ll1lll_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㢆")		:	from IPTV			import MENUu as l1lll1111l1_l1_,SEARCHh as l1lll11l1l1_l1_,menu_namee as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㢇")	:	from l1ll11lllll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ㢈")	:	from l1ll11llll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭㢉")	:	from l1ll11ll1ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ㢊")	:	from l1ll111ll11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㢋")	:	from l11llll1l1l_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ㢌")		:	from M3U			import MENUu as l1lll1111l1_l1_,SEARCHh as l1lll11l1l1_l1_,menu_namee as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ㢍")	:	from l11l1l1111l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ㢎")	:	from l1llll11l111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ㢏")		:	from l11l11ll111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㢐")	:	from l1ll1lll11ll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㢑"):	from l11ll11lll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ㢒")	:	from l11l11llll1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㢓")	:	from l111l111l11_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㢔")	:	from l11lll11lll_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㢕")	:	from l1ll1l1ll111_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㢖")		:	from l1111l1l111_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㢗")	:	from l1ll1llll11l_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"ࠬ࡟ࡁࡒࡑࡗࠫ㢘")		:	from l11ll1llll1_l1_			import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㢙")	:	from l11ll1ll1l1_l1_		import l1l1l11_l1_ as l1lll1111l1_l1_,l1lll1_l1_ as l1lll11l1l1_l1_,l1lllll_l1_ as l1llll111l1_l1_
	elif l1llll11l1ll_l1_==l1l111_l1_ (u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭㢚"):	from l11ll1111ll_l1_	import l1l1l11_l1_ as l1lll1111l1_l1_
	return l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll111l1_l1_
def l1lllll1ll11_l1_(l1ll111l1lll_l1_,headers,l11_l1_):
	l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㢛"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧ㢜")+l1ll111l1lll_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭㢝")+str(headers)+l1l111_l1_ (u"ࠫࠥࡣࠧ㢞"))
	l1l1111ll1_l1_ = l1l111ll1l_l1_()
	l1l1111ll1_l1_.create(l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㢟"),l1l111_l1_ (u"๊࠭อำํࠤฬ๊ย็ࠢไัฺࠦวๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์่ࠦษ฻า๋ฬࠦำ้ใࠣฮอีรࠡ฻่่๏ฯࠠอๆหࠤฬ๊ๅๅใ้๋ࠣࠦวๅว้ฮึ์สࠨ㢠"))
	l1l11l111l_l1_ = 1024*1024
	chunksize = 1*l1l11l111l_l1_
	response = requests.get(l1ll111l1lll_l1_,stream=True,headers=headers)
	l1ll1l1l1lll_l1_ = response.headers
	response.close()
	l1ll1l1l11l1_l1_ = bytes()
	if not l1ll1l1l1lll_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㢡"),l1l111_l1_ (u"ࠨࠩ㢢"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㢣"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭㢤"))
		l1l1111ll1_l1_.close()
	else:
		if l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬ㢥") not in list(l1ll1l1l1lll_l1_.keys()): filesize = 0
		else: filesize = int(l1ll1l1l1lll_l1_[l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭㢦")])
		l1l111ll11_l1_ = str(int(1000*filesize/l1l11l111l_l1_)/1000.0)
		l11llll111_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡓࡣࡱ࡫ࡪ࠭㢧") in list(l1ll1l1l1lll_l1_.keys()) and filesize>l1l11l111l_l1_:
			l1ll1ll1l1ll_l1_ = True
			ranges = []
			l1ll11lll11l_l1_ = 10
			ranges.append(str(0*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㢨")+str(1*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(1*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㢩")+str(2*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(2*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㢪")+str(3*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(3*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㢫")+str(4*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(4*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㢬")+str(5*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(5*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㢭")+str(6*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(6*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㢮")+str(7*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(7*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㢯")+str(8*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(8*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㢰")+str(9*filesize//l1ll11lll11l_l1_-1))
			ranges.append(str(9*filesize//l1ll11lll11l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㢱"))
			l11ll11ll11_l1_ = float(l11llll111_l1_)/l1ll11lll11l_l1_
			l1111l11111_l1_ = l11ll11ll11_l1_/int(1+l11ll11ll11_l1_)
		else:
			l1ll1ll1l1ll_l1_ = False
			l1ll11lll11l_l1_ = 1
			l1111l11111_l1_ = 1
		l1l1111111_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㢲"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡸࡷ࡮ࡴࡧࠡࡴࡤࡲ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬ㢳")+str(l1ll1ll1l1ll_l1_)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ㢴")+str(filesize)+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㢵"))
		l1l111lll1_l1_,l1ll1lll1l11_l1_ = 0,0
		for l1llll1l1111_l1_ in range(l1ll11lll11l_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll1ll1l1ll_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠧࡓࡣࡱ࡫ࡪ࠭㢶")] = l1l111_l1_ (u"ࠨࡤࡼࡸࡪࡹ࠽ࠨ㢷")+ranges[l1llll1l1111_l1_]
			response = requests.get(l1ll111l1lll_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l1111ll1_l1_.iscanceled():
					l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㢸"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠪ㢹"))
					break
				l1l111lll1_l1_ += l1111l11111_l1_
				l1ll1l1l11l1_l1_ += chunk
				if not l1ll1lll1l11_l1_: l1ll1lll1l11_l1_ = len(chunk)
				if filesize: l1l11111ll_l1_(l1l1111ll1_l1_,100*l1l111lll1_l1_//l11llll111_l1_,l1l111_l1_ (u"ࠫั๊ศࠡษ็้้็࠺࠮ࠢส่ัุมࠡำๅ้ࠬ㢺"),str(100.0*l1ll1lll1l11_l1_*l1l111lll1_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠬࠦ࠯ࠡࠩ㢻")+l1l111ll11_l1_+l1l111_l1_ (u"࠭ࠠࡎࡄࠪ㢼"))
				else: l1l11111ll_l1_(l1l1111ll1_l1_,l1ll1lll1l11_l1_*l1l111lll1_l1_//chunksize,l1l111_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠬ㢽"),str(100.0*l1ll1lll1l11_l1_*l1l111lll1_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠨࠢࡐࡆࠬ㢾"))
			response.close()
		l1l1111ll1_l1_.close()
		if len(l1ll1l1l11l1_l1_)<filesize and filesize>0:
			l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㢿"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭㣀")+str(len(l1ll1l1l11l1_l1_)//l1l11l111l_l1_)+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩ㣁")+l1l111ll11_l1_+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ㣂"))
			l11l11111l1_l1_ = l1ll11l1ll11_l1_(l1l111_l1_ (u"࠭ࠧ㣃"),l1l111_l1_ (u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬ㣄"),l1l111_l1_ (u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨ㣅"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫ㣆"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㣇"),l1l111_l1_ (u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨ㣈")+str(len(l1ll1l1l11l1_l1_)//l1l11l111l_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫ㣉")+l1l111ll11_l1_+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨ㣊"))
			if l11l11111l1_l1_==2: l1ll1l1l11l1_l1_ = l1lllll1ll11_l1_(l1ll111l1lll_l1_,headers,l11_l1_)
			elif l11l11111l1_l1_==1: l1l1111111_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㣋"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡓࡵࡴࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡤࡧࡨ࡫ࡰࡵࡧࡧࠤࡦࡴࡤࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡸࡷࡪࡪࠧ㣌"))
			else: return l1l111_l1_ (u"ࠩࠪ㣍")
			if not l1ll1l1l11l1_l1_: return l1l111_l1_ (u"ࠪࠫ㣎")
		else: l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㣏"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩ࠴ࠠࠡࠢࡉ࡭ࡱ࡫ࠠࡔ࡫ࡽࡩ࠿࡛ࠦࠡࠩ㣐")+l1l111ll11_l1_+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ㣑"))
	return l1ll1l1l11l1_l1_
def l1111l11l11_l1_(l1ll1_l1_):
	return response
def l1111ll1l1l_l1_(l1lll11lllll_l1_=l1l111_l1_ (u"ࠧࠨ㣒")):
	l1ll1llll1l1_l1_,l1llll11ll1l_l1_,l11lllll11l_l1_,l1llll11ll11_l1_,l111l111111_l1_,timezone = l1l111_l1_ (u"ࠨࠩ㣓"),l1l111_l1_ (u"ࠩࠪ㣔"),l1l111_l1_ (u"ࠪࠫ㣕"),l1l111_l1_ (u"ࠫࠬ㣖"),l1l111_l1_ (u"ࠬ࠭㣗"),l1l111_l1_ (u"࠭ࠧ㣘")
	url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࠴ࡩࡴ࠱ࠪ㣙")+l1lll11lllll_l1_+l1l111_l1_ (u"ࠨࡁࡲࡹࡹࡶࡵࡵ࠿࡭ࡷࡴࡴࠦࡧ࡫ࡨࡰࡩࡹ࠽ࡪࡲ࠯ࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭㣚")
	headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㣛"):l1l111_l1_ (u"ࠪࠫ㣜")}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㣝"),url,l1l111_l1_ (u"ࠬ࠭㣞"),headers,l1l111_l1_ (u"࠭ࠧ㣟"),l1l111_l1_ (u"ࠧࠨ㣠"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ㣡"))
	if not response.succeeded: l1ll1l11111l_l1_ = l1lll11lllll_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㣢")+l1ll1llll1l1_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㣣")+l1llll11ll1l_l1_+l1l111_l1_ (u"ࠫ࠱࠭㣤")+l1llll11ll11_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㣥")+l111l111111_l1_+l1l111_l1_ (u"࠭ࠬࠨ㣦")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠧ࡝ࡽ࠱࠮ࡄࡢࡽ࡝ࡿࠪ㣧"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l111llll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㣨"),html)
			keys = list(l11l111llll_l1_.keys())
			if l1l111_l1_ (u"ࠩ࡬ࡴࠬ㣩") in keys: l1lll11lllll_l1_ = l11l111llll_l1_[l1l111_l1_ (u"ࠪ࡭ࡵ࠭㣪")]
			if l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧ㣫") in keys: l1ll1llll1l1_l1_ = l11l111llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨ㣬")]
			if l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㣭") in keys: l1llll11ll1l_l1_ = l11l111llll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ㣮")]
			if l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧ㣯") in keys: l11lllll11l_l1_ = l11l111llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨ㣰")]
			if l1l111_l1_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࠪ㣱") in keys: l1llll11ll11_l1_ = l11l111llll_l1_[l1l111_l1_ (u"ࠫࡷ࡫ࡧࡪࡱࡱࠫ㣲")]
			if l1l111_l1_ (u"ࠬࡩࡩࡵࡻࠪ㣳") in keys: l111l111111_l1_ = l11l111llll_l1_[l1l111_l1_ (u"࠭ࡣࡪࡶࡼࠫ㣴")]
			if l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ㣵") in keys:
				timezone = l11l111llll_l1_[l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ㣶")][l1l111_l1_ (u"ࠩࡸࡸࡨ࠭㣷")]
				if timezone[0] not in [l1l111_l1_ (u"ࠪ࠱ࠬ㣸"),l1l111_l1_ (u"ࠫ࠰࠭㣹")]: timezone = l1l111_l1_ (u"ࠬ࠱ࠧ㣺")+timezone
			l1ll1l11111l_l1_ = l1lll11lllll_l1_+l1l111_l1_ (u"࠭ࠬࠨ㣻")+l1ll1llll1l1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㣼")+l1llll11ll1l_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㣽")+l1llll11ll11_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㣾")+l111l111111_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㣿")+timezone
			if PY3: l1ll1l11111l_l1_ = l1ll1l11111l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㤀")).decode(l1l111_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㤁"))
	l1ll1l11111l_l1_ = escapeUNICODE(l1ll1l11111l_l1_)
	return l1ll1l11111l_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"࠭ࠧ㤂"),True
	if search.count(l1l111_l1_ (u"ࠧࡠࠩ㤃"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠨࡡࠪ㤄"),1)
		options = l1l111_l1_ (u"ࠩࡢࠫ㤅")+options
		if l1l111_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ㤆") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1ll1l1111ll_l1_():
	l1ll1lll111l_l1_ = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㤇"))
	l111111l111_l1_ = 0
	if os.path.exists(l1ll1lll111l_l1_):
		for filename in os.listdir(l1ll1lll111l_l1_):
			if l1l111_l1_ (u"ࠬ࠴ࡰࡺࡱࠪ㤈") in filename: continue
			if l1l111_l1_ (u"࠭࡟ࡠࡲࡼࡧࡦࡩࡨࡦࡡࡢࠫ㤉") in filename: continue
			l1ll111111_l1_ = os.path.join(l1ll1lll111l_l1_,filename)
			size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
			l111111l111_l1_ += size
	return l111111l111_l1_
def l1ll1l11ll1l_l1_(l111ll1lll1_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㤊")][3]
	l1ll111llll1_l1_ = l1l11l1l111_l1_(32,l111ll1lll1_l1_)
	l1ll1l11111l_l1_ = l1111ll1l1l_l1_()
	l1llll11ll1l_l1_ = l1ll1l11111l_l1_.split(l1l111_l1_ (u"ࠨ࠮ࠪ㤋"))[2]
	l111111l111_l1_ = l1ll1l1111ll_l1_()
	payload = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㤌"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ㤍"):l1l111lll1l_l1_,l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㤎"):l1llll11ll1l_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㤏"):l1lll1l1ll11_l1_(l111111l111_l1_)}
	if not l111ll1lll1_l1_: l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ㤐"),(l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㤑"),url,payload,l1l111_l1_ (u"ࠨࠩ㤒"),l1l111_l1_ (u"ࠩࠪ㤓")))
	l1111l1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷࠬ㤔"))
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭㤕"),l1l111_l1_ (u"ࠬ࠭㤖"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㤗"),url,payload,l1l111_l1_ (u"ࠧࠨ㤘"),l1l111_l1_ (u"ࠨࠩ㤙"),l1l111_l1_ (u"ࠩࠪ㤚"),l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔ࠯ࡖࡌࡔ࡝࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭㤛"))
	l11lll11l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㤜"))
	if not l11lll11l11_l1_: l11lll11l11_l1_ = l1l111_l1_ (u"ࠬࡔࡅࡘࠩ㤝")
	l1llll11111l_l1_ = l11lll11l11_l1_
	l11ll1l1lll_l1_ = l1l111_l1_ (u"࠭ࠧ㤞")
	if not response.succeeded: l1llll11111l_l1_ = l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㤟")
	else:
		l111l11l111_l1_,l111l1l11l1_l1_,l111l11l11l_l1_ = l1l111_l1_ (u"ࠨࠩ㤠"),l1l111_l1_ (u"ࠩࠪ㤡"),[]
		newfile = response.content
		if newfile:
			l111l11l11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㤢"),newfile)
			for l1lllllll1l1_l1_,l1lll1111111_l1_,message in l111l11l11l_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㤣")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤤"))
				if l1lllllll1l1_l1_==l1l111_l1_ (u"࠭࠰ࠨ㤥"): l11ll1l1lll_l1_ += message+l1l111_l1_ (u"ࠧ࠻࠼ࠪ㤦")
				else: l111l11l111_l1_ += message+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤧")
			l111l11l111_l1_ = l111l11l111_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㤨"))
			l11ll1l1lll_l1_ = l11ll1l1lll_l1_.strip(l1l111_l1_ (u"ࠪ࠾࠿࠭㤩"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭㤪"),l11ll1l1lll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㤫"),l1lll1l1ll11_l1_(now))
		if os.path.exists(l1ll11l1111l_l1_): l111l1l11l1_l1_ = open(l1ll11l1111l_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㤬")).read()
		if PY3: l111l11l111_l1_ = l111l11l111_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㤭"))
		if l111l11l111_l1_!=l111l1l11l1_l1_:
			l1llll11111l_l1_ = l1l111_l1_ (u"ࠨࡐࡈ࡛ࠬ㤮")
			try: open(l1ll11l1111l_l1_,l1l111_l1_ (u"ࠩࡺࡦࠬ㤯")).write(l111l11l111_l1_)
			except: pass
		if l11_l1_:
			l111l11l11l_l1_ = sorted(l111l11l11l_l1_,reverse=True,key=lambda key: int(key[0]))
			l111l1l111l_l1_ = l1l111_l1_ (u"ࠪࠫ㤰")
			for l1lllllll1l1_l1_,l1lll1111111_l1_,message in l111l11l11l_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㤱")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤲"))
				if l111l1l111l_l1_: l111l1l111l_l1_ += l1l111_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ㤳")
				if l1lllllll1l1_l1_==l1l111_l1_ (u"ࠧ࠱ࠩ㤴"): continue
				date = message.split(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤵"))[0]
				l11l1lll1l1_l1_ = l1l111_l1_ (u"ࠩࠪ㤶")
				if l1lll1111111_l1_:
					l11l1lll1l1_l1_ = l1l111_l1_ (u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧ㤷")
					if PY3: l11l1lll1l1_l1_ = l11l1lll1l1_l1_.encode(l1l111_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㤸")).decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤹"))
				l111l1l111l_l1_ += message.replace(date,l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㤺")+date+l11l1lll1l1_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㤻"))+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤼")
			l111l1l111l_l1_ = escapeUNICODE(l111l1l111l_l1_)
			l1l11l1l11_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㤽"),l1l111_l1_ (u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭㤾"),l111l1l111l_l1_,l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㤿"))
			l1llll11111l_l1_ = l1l111_l1_ (u"ࠬࡕࡌࡅࠩ㥀")
		if l1llll11111l_l1_!=l11lll11l11_l1_:
			settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ㥁"),l1llll11111l_l1_)
	if l11_l1_: xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㥂"))
	if l1111l1lll1_l1_!=l11ll1l1lll_l1_:
		if not l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨฮิฬ๋ࠥัสࠢฦาึ๏ࠧ㥃"),l1l111_l1_ (u"ࠩࡗࡶࡾࠦࡡࡨࡣ࡬ࡲࠬ㥄"),time=2000)
		l1111l11lll_l1_(l1l111_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡶࡲࠤࡦࡶࡰ࡭ࡻࠣࡲࡪࡽࠠࡱࡴ࡬ࡺ࡮ࡲࡥࡨࡧࡶࠫ㥅"))
	return l1llll11111l_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll1ll11ll1_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll1ll11ll1_l1_ = False
	l11ll1llll_l1_ = time.time()
	if l1ll1ll11ll1_l1_: resp = l11ll1llll_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࠬ㥆"),l1l111_l1_ (u"ࠬ࠭㥇"),l1l111_l1_ (u"࠭ࠧ㥈"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㥉"),l1l111_l1_ (u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧ㥊"))
	else: l1llll111l_l1_ = True
	if l1llll111l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠩ࠱ࡨࡧ࠭㥋")) and l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ㥌") in filename:
				l1ll1lll1l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1llll1lll_l1_ = l1l1lll1lll_l1_(l1ll1lll1l_l1_)
				except: return
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧ㥍"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨ㥎"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧ㥏"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㥐"),l1l111_l1_ (u"ࠨࠩ㥑"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㥒"),l1l111_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ㥓"))
	return
def l1lll1l1l1l_l1_(l1lll1lll1l1_l1_,l1ll1ll1l111_l1_,l11_l1_):
	if l1lll1lll1l1_l1_!=None:
		global l1ll1l1l1111_l1_
		l1ll1l1l1111_l1_ = l1lll1lll1l1_l1_
	if l1ll1ll1l111_l1_!=None:
		global l1ll11l1llll_l1_
		l1ll11l1llll_l1_ = l1ll1ll1l111_l1_
	if l11_l1_!=None:
		global l11l111lll1_l1_
		l11l111lll1_l1_ = l11_l1_
	return
l1ll1l1l1111_l1_,l1ll11l1llll_l1_,l11l111lll1_l1_ = l1l111_l1_ (u"ࠫࠬ㥔"),l1l111_l1_ (u"ࠬ࠭㥕"),l1l111_l1_ (u"࠭ࠧ㥖")
def l11l11lll11_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l11l_l1_=l1l111_l1_ (u"ࠧࠨ㥗"),l1lll1ll1111_l1_=l1l111_l1_ (u"ࠨࠩ㥘")):
	if l11_l1_==l1l111_l1_ (u"ࠩࠪ㥙"): l11_l1_ = True if l11l111lll1_l1_==l1l111_l1_ (u"ࠪࠫ㥚") else l11l111lll1_l1_
	if l1lll1ll1111_l1_==l1l111_l1_ (u"ࠫࠬ㥛"): l1lll1ll1111_l1_ = True if l1ll11l1llll_l1_==l1l111_l1_ (u"ࠬ࠭㥜") else l1ll11l1llll_l1_
	if l11ll11l11l_l1_==l1l111_l1_ (u"࠭ࠧ㥝"): l11ll11l11l_l1_ = True if l1ll1l1l1111_l1_==l1l111_l1_ (u"ࠧࠨ㥞") else l1ll1l1l1111_l1_
	if allow_redirects==l1l111_l1_ (u"ࠨࠩ㥟"): l1ll1ll1lll1_l1_ = True
	else: l1ll1ll1lll1_l1_ = allow_redirects
	if data==None: l1l11llll_l1_ = None
	elif data==l1l111_l1_ (u"ࠩࠪ㥠"): l1l11llll_l1_ = {}
	else: l1l11llll_l1_ = data
	if headers==None: l1ll1ll1l_l1_ = None
	elif headers==l1l111_l1_ (u"ࠪࠫ㥡"): l1ll1ll1l_l1_ = {}
	else: l1ll1ll1l_l1_ = headers
	l1llll11l11l_l1_ = list(l1ll1ll1l_l1_.keys())
	if l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㥢") not in l1llll11l11l_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㥣")] = l1l111_l1_ (u"࠭ࡀࡁࡂࡖࡏࡎࡖ࡟ࡉࡇࡄࡈࡊࡘࡀࡁࡂࠪ㥤")
	l1lllll1_l1_,l1ll1l1lllll_l1_,l1lll1ll11ll_l1_,l1lll1lllll1_l1_ = l1ll1l11l1ll_l1_(url)
	l1ll11ll1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹࠧ㥥"))
	l1ll1l1l1ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ㥦"))
	l1ll1ll11lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ㥧"))
	l1ll1lll1111_l1_ = (l1ll1l1lllll_l1_==None and l1lll1ll11ll_l1_==None)
	l111ll1llll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㥨")]
	l1ll1l1l1l1l_l1_ = l1lllll1_l1_ in l111ll1llll_l1_
	l111llll111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㥩")]
	l11ll11ll1l_l1_ = l1lllll1_l1_ in l111llll111_l1_
	l111lllll11_l1_ = l1ll1l1l1l1l_l1_ or l11ll11ll1l_l1_
	if l1ll1lll1111_l1_ and l111lllll11_l1_:
		if l1ll1l1l1l1l_l1_:
			l111111ll1l_l1_ = l111ll1llll_l1_.index(l1lllll1_l1_)
			l111l1111ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ㥪")][l111111ll1l_l1_]
			l111l1lllll_l1_ = l111l11l1l1_l1_[l111111ll1l_l1_]
		elif l11ll11ll1l_l1_:
			l111111ll1l_l1_ = l111llll111_l1_.index(l1lllll1_l1_)
			l111l1111ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩ㥫")][l111111ll1l_l1_]
			l111l1lllll_l1_ = l11l11ll1l1_l1_[l111111ll1l_l1_]
	if l1lll1ll11ll_l1_==l1l111_l1_ (u"ࠧࠨ㥬"): l1lll1ll11ll_l1_ = l1ll11ll1l11_l1_
	elif l1lll1ll11ll_l1_==None and l1ll1l1l1ll1_l1_ in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㥭"),l1l111_l1_ (u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫ㥮")] and l11ll11l11l_l1_: l1lll1ll11ll_l1_ = l1ll11ll1l11_l1_
	l1lll1ll111l_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㥯")][7]
	l1ll1lll1l1l_l1_ = l1ll1l1lllll_l1_ and l1l111_l1_ (u"ࠫࡸࡩࡲࡢࡲࡨࠫ㥰") in l1ll1l1lllll_l1_
	if l1ll1lll1l1l_l1_: l1l111111ll_l1_ = 60
	elif l1ll1l1l1l1l_l1_ or l11ll11ll1l_l1_: l1l111111ll_l1_ = 15
	elif source in l111111l1l1_l1_: l1l111111ll_l1_ = 10
	elif source==l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬ㥱"): l1l111111ll_l1_ = 120
	elif source==l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㥲"): l1l111111ll_l1_ = 20
	elif source==l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㥳"): l1l111111ll_l1_ = 20
	elif l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏࠪ㥴") in source: l1l111111ll_l1_ = 70
	elif l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㥵") in source: l1l111111ll_l1_ = 75
	elif l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ㥶") in source: l1l111111ll_l1_ = 25
	elif l1l111_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ㥷") in source: l1l111111ll_l1_ = 20
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ㥸") in source: l1l111111ll_l1_ = 20
	elif l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㥹") in source: l1l111111ll_l1_ = 30
	elif l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㥺") in source: l1l111111ll_l1_ = 25
	elif l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㥻") in source: l1l111111ll_l1_ = 30
	elif l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㥼") in source: l1l111111ll_l1_ = 20
	elif l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㥽") in source: l1l111111ll_l1_ = 60
	else: l1l111111ll_l1_ = 15
	if l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㥾") in source and not l1l11llll_l1_ and l1l111_l1_ (u"ࠬࠬࠧ㥿") not in l1lllll1_l1_ and l1l111_l1_ (u"࠭࠿ࠨ㦀") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠧ࠰ࠩ㦁"))+l1l111_l1_ (u"ࠨ࠱ࠪ㦂")
	l11ll1l111l_l1_ = (l1ll1l1lllll_l1_!=None)
	l1lll1l1l1ll_l1_ = (l1lll1ll11ll_l1_!=None and l1ll1l1l1ll1_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㦃"))
	if l11ll1l111l_l1_ and not l1ll1lll1l1l_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮๆ฿๊ๅࠢหีํ้ำ๋ࠢิๆ๊࠭㦄"),l1ll1l1lllll_l1_)
	elif l1lll1l1l1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣࡈࡓ࡙ࠠาไ่ࠫ㦅"),l1lll1ll11ll_l1_)
	if l11ll1l111l_l1_:
		proxies = {l1l111_l1_ (u"ࠧ࡮ࡴࡵࡲࠥ㦆"):l1ll1l1lllll_l1_,l1l111_l1_ (u"ࠨࡨࡵࡶࡳࡷࠧ㦇"):l1ll1l1lllll_l1_}
		l11111l1ll1_l1_ = l1ll1l1lllll_l1_
	else: proxies,l11111l1ll1_l1_ = {},l1l111_l1_ (u"ࠧࠨ㦈")
	if l1lll1l1l1ll_l1_:
		import urllib3.util.connection as connection
		l111l1llll1_l1_ = l1ll1l111l11_l1_(connection,l1ll11ll1l11_l1_)
	l1ll1ll1llll_l1_,l1lll111l1l1_l1_,l1l11lll1_l1_,l11lll11111_l1_,l11ll11llll_l1_,verify = l1ll1ll1lll1_l1_,source,method,False,False,l1lll1lllll1_l1_
	if l1lll1ll111l_l1_: l11ll11llll_l1_ = True
	if l111lllll11_l1_ or l1ll1ll1lll1_l1_: l1ll1ll1llll_l1_ = False
	if l1ll1l1l1l1l_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㦉")
	code,reason = -1,l1l111_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡉࡷࡸ࡯ࡳࠩ㦊")
	for l1l111lll1_l1_ in range(9):
		l1lllllll11l_l1_ = True
		succeeded = False
		try:
			if l1l111lll1_l1_: l1lll111l1l1_l1_ = l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠲ࡵࡷࠫ㦋")
			if l1ll1lll1l1l_l1_ or not l11ll1l111l_l1_: l1l1l1l1lll_l1_(l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩ㦌"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1lll111l1l1_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=l1l11llll_l1_,headers=l1ll1ll1l_l1_,verify=verify,allow_redirects=l1ll1ll1llll_l1_,timeout=l1l111111ll_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11lll11111_l1_:
					l11111ll11l_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㦍") in l11111ll11l_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㦎")]
					elif l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㦏") in l11111ll11l_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ㦐")]
					else: l11lll11111_l1_ = True
					if not l11lll11111_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪ㦑"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㦒")).decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㦓"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㦔"))
					if l111lllll11_l1_ and response.status_code==307:
						l1ll1ll1llll_l1_ = l1ll1ll1lll1_l1_
						l1l11lll1_l1_ = method
						l11lll11111_l1_ = True
						l1llll111ll1_l1_
				if not l11lll11111_l1_ or l1ll1ll1lll1_l1_:
					if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㦕") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㦖"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠨ࠱ࠪ㦗")+l1lllll1_l1_.lstrip(l1l111_l1_ (u"ࠩ࠲ࠫ㦘"))
				if not l11lll11111_l1_ and l1ll1ll1lll1_l1_:
					l11ll1l11l_l1_ = GET_VIDEOFILETYPE(l1lllll1_l1_)
					if l11ll1l11l_l1_ not in [l1l111_l1_ (u"ࠪ࠲ࡦࡼࡩࠨ㦙"),l1l111_l1_ (u"ࠫ࠳ࡺࡳࠨ㦚"),l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ㦛"),l1l111_l1_ (u"࠭࠮ࡢࡣࡦࠫ㦜"),l1l111_l1_ (u"ࠧ࠯࡯࡮ࡺࠬ㦝"),l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠸࠭㦞"),l1l111_l1_ (u"ࠩ࠱ࡻࡪࡨ࡭ࠨ㦟")]: l1llll111ll1_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11ll11llll_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if PY2: reason = str(err.message).split(l1l111_l1_ (u"ࠪ࠾ࠥ࠭㦠"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠫ࠿ࠦࠧ㦡"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠬࡋࡲࡳࡰࡲࠫ㦢") in error: code,reason = re.findall(l1l111_l1_ (u"ࠨ࡜࡜ࡇࡵࡶࡳࡵࠠࠩ࡞ࡧ࠯࠮ࡢ࡝ࠡࠪ࠱࠮ࡄ࠯ࠧࠣ㦣"),error)[0]
				elif l1l111_l1_ (u"ࠧ࠭ࠢࡨࡶࡷࡵࡲࠩࠩ㦤") in error: code,reason = re.findall(l1l111_l1_ (u"ࠣ࠮ࠣࡩࡷࡸ࡯ࡳ࡞ࠫࠬࡡࡪࠫࠪ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ㦥"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠩ࠽ࠫ㦦"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠪ࠾ࠥ࠮࠮ࠫࡁࠬ࠾࠳࠰࠿ࠩ࡞ࡧ࠯࠮࠭㦧"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if PY2: reason = err.message
			else: reason = str(err)
		except:
			l1lllllll11l_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㦨"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡔࡒࡒࡒࡘࡋࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ㦩")+str(code)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ㦪")+reason+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㦫")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㦬")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㦭"))
		if l1ll1lll1111_l1_ and l111lllll11_l1_ and l1lllllll11l_l1_ and not l11ll11llll_l1_ and code!=200:
			l1lllll1_l1_ = l111l1111ll_l1_
			l11ll11llll_l1_ = True
			continue
		if l1lllllll11l_l1_: break
	if l1lll1ll11ll_l1_!=None and l1ll1l1l1ll1_l1_!=l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㦮"): connection.create_connection = l111l1llll1_l1_
	if l1ll1l1l1ll1_l1_==l1l111_l1_ (u"ࠫࡆࡒࡗࡂ࡛ࡖࠫ㦯") and l11ll11l11l_l1_: l1lll1ll11ll_l1_ = None
	if not succeeded and l1ll1l1lllll_l1_==None and source not in l111111l1l1_l1_:
		l111l111lll_l1_ = traceback.format_exc()
		if l111l111lll_l1_!=l1l111_l1_ (u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨ㦰"): sys.stderr.write(l111l111lll_l1_)
	l1lll1l11_l1_ = l1l1llll1l1_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"࠭ࠧ㦱")
	try: l1ll1ll11_l1_ = response.headers
	except: l1ll1ll11_l1_ = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if PY3:
		try: content = content.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㦲"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = l1ll1ll11_l1_
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if PY2 or isinstance(l1lll1l11_l1_.content,str): l111ll1l111_l1_ = l1lll1l11_l1_.content.lower()
	else: l111ll1l111_l1_ = l1l111_l1_ (u"ࠨࠩ㦳")
	l1lllll1l111_l1_ = (l1l111_l1_ (u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㦴") in l111ll1l111_l1_ or l1l111_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪ㦵") in l111ll1l111_l1_) and l111ll1l111_l1_.count(l1l111_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ㦶"))>2 and l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㦷") not in source and l1l111_l1_ (u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨ㦸") not in l111ll1l111_l1_ and not l1ll1lll1l1l_l1_
	if code==200 and l1lllll1l111_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1ll1lll1111_l1_ and l111lllll11_l1_:
		if l1lll1ll111l_l1_: l111l1lllll_l1_ = l1l111_l1_ (u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨ㦹")+l1l11llll_l1_[l1l111_l1_ (u"ࠨ࡬ࡲࡦࠬ㦺")].upper().replace(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㦻"),l1l111_l1_ (u"ࠪࠫ㦼"))
		l1lll11ll_l1_ = l1l1lllll11_l1_(l111l1lllll_l1_)
	if not l1lll1l11_l1_.succeeded and l1ll1lll1111_l1_:
		l1lllll11ll1_l1_ = (l1l111_l1_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㦽") in l111ll1l111_l1_ and l1l111_l1_ (u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧ㦾") in l111ll1l111_l1_)
		l1lllll11lll_l1_ = (l1l111_l1_ (u"࠭࠵ࠡࡵࡨࡧࠬ㦿") in l111ll1l111_l1_ and l1l111_l1_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨ㧀") in l111ll1l111_l1_)
		l1lllll1l1l1_l1_ = (code in [403] and l1l111_l1_ (u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫ㧁") in l111ll1l111_l1_)
		l1lllll1l1ll_l1_ = (l1l111_l1_ (u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫ㧂") in l111ll1l111_l1_ and l1l111_l1_ (u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧ㧃") in l111ll1l111_l1_)
		if   l1lllll1l111_l1_: reason = l1l111_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ㧄")
		elif l1lllll11ll1_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㧅")
		elif l1lllll11lll_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭㧆")
		elif l1lllll1l1l1_l1_: reason = l1l111_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨ㧇")
		elif l1lllll1l1ll_l1_: reason = l1l111_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ㧈")
		else: reason = str(reason)
		if source in l1lll1111ll1_l1_: pass
		elif source in l111111l1l1_l1_:
			l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㧉"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㧊")+str(code)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ㧋")+reason+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㧌")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㧍")+l1lllll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㧎"))
		else: l1l1111111_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㧏"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㧐")+str(code)+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㧑")+reason+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㧒")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㧓")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㧔"))
		l1111ll1l11_l1_ = l111l11_l1_(l1lllll1_l1_)
		if PY2 and isinstance(l1111ll1l11_l1_,unicode): l1111ll1l11_l1_ = l1111ll1l11_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㧕"))
		if l111lllll11_l1_: l1111ll1l11_l1_ = l1111ll1l11_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ㧖"))[-1]
		l1lll1ll1l11_l1_ = reason
		reason = str(reason)+l1l111_l1_ (u"ࠩ࡟ࡲ࠭ࠦࠧ㧗")+l1111ll1l11_l1_+l1l111_l1_ (u"ࠪࠤ࠮࠭㧘")
		if l1lllll1l111_l1_ or l1lllll11ll1_l1_ or l1lllll11lll_l1_ or l1lllll1l1l1_l1_ or l1lllll1l1ll_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
			if l1lll1ll1111_l1_:
				l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㧙"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࡥࡽࡵࡧࡳࡴࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ㧚")+str(code)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㧛")+l1lll1ll1l11_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㧜")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧝")+l1lllll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㧞"))
				l1ll1lll_l1_(l1l111_l1_ (u"้ࠪาอ่ๅหࠣฮัอ่ำࠩ㧟"),l1l111_l1_ (u"ࠫฬ๊แฮืࠣห้ษๅ็์ࠪ㧠"),time=1500)
				l1ll1l1ll1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠳ࠪ㧡"))
				l1ll1l1ll1ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠵ࠫ㧢"))
				l1ll1l1ll1l1_l1_ = 9999 if not l1ll1l1ll1l1_l1_ else int(l1ll1l1ll1l1_l1_)
				l1ll1l1ll1ll_l1_ = 9999 if not l1ll1l1ll1ll_l1_ else int(l1ll1l1ll1ll_l1_)
				l11lll111l1_l1_ = []
				if l1ll1l1ll1l1_l1_>10: l11lll111l1_l1_.append(1)
				if l1ll1l1ll1ll_l1_>10: l11lll111l1_l1_.append(2)
				l11lll111l1_l1_.append(3)
				l11ll1l1l1l_l1_ = random.sample(l11lll111l1_l1_,1)[0]
				if l11ll1l1l1l_l1_==1:
					l1111111111_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠿࠾࠰࠹࠲ࠪ㧣")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㧤")+l1111111111_l1_+l1l111_l1_ (u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ㧥")
					l1lllll1l11l_l1_ = l11l11lll11_l1_(method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠳ࡰࡧࠫ㧦"),False,False)
				elif l11ll1l1l1l_l1_==2:
					l1111111111_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧ㧧")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ㧨")+l1111111111_l1_+l1l111_l1_ (u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭㧩")
					l1lllll1l11l_l1_ = l11l11lll11_l1_(method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠸ࡸࡤࠨ㧪"),False,False)
				elif l11ll1l1l1l_l1_==3:
					l1111111111_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠿࠽࠶ࡣ࠶ࡩࡧ࠸࠺ࡦࡤࡦ࠴࠽ࡩ࠿ࡣ࠶࠷ࡤ࠵࠺࡬࠳࠷࠲࠷ࡧࡩ࠿࠱࠵ࡥࡃࡴࡷࡵࡸࡺ࠯ࡶࡩࡷࡼࡥࡳ࠰ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠴ࡣࡰ࡯࠽࠼࠵࠶࠱ࠨ㧫")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ㧬")+l1111111111_l1_+l1l111_l1_ (u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ㧭")
					l1lllll1l11l_l1_ = l11l11lll11_l1_(method,l1111111_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠶ࡷ࡬ࠬ㧮"),False,False)
				else: l1lllll1l11l_l1_ = l1lll1l11_l1_
				code,reason = l1lllll1l11l_l1_.code,l1lllll1l11l_l1_.reason
				if not l1lllll1l11l_l1_.succeeded:
					l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㧯"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ㧰")+str(code)+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ㧱")+reason+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㧲")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧳")+l1111111_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㧴"))
					l1ll1lll_l1_(l1l111_l1_ (u"้๊ࠫริใࠣๅู๊ࠠศๆไัฺࠦวๅล่๊๏࠭㧵"),l1l111_l1_ (u"ࠬาัษ่ࠢีฮࠦรฯำ์ࠫ㧶"),time=2000)
				else:
					l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㧷"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧸")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㧹")+l1111111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㧺"))
					if l11ll1l1l1l_l1_ in [1,2]:
						l1ll11ll1ll1_l1_ = l1lllll1l11l_l1_.headers[l1l111_l1_ (u"ࠪࡗࡨࡸࡡࡱࡧ࠱ࡨࡴ࠳ࡒࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨ࠯ࡆࡶࡪࡪࡩࡵࡵࠪ㧻")]
						if l11ll1l1l1l_l1_==1: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡪ࡯࠲ࠩ㧼"),l1ll11ll1ll1_l1_)
						if l11ll1l1l1l_l1_==2: settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠴ࠪ㧽"),l1ll11ll1ll1_l1_)
					l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอฯࠣห้็อึࠢส่ศ๋ๆ๋ࠩ㧾"),l1l111_l1_ (u"ࠧࡔࡷࡦࡧࡪࡹࡳࠨ㧿"),time=2000)
					return l1lllll1l11l_l1_
		l1llll111l_l1_ = True
		if (l1ll1l1l1ll1_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㨀") or l1ll1ll11lll_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㨁")) and (l11ll11l11l_l1_ or l1lll1ll1111_l1_):
			l1llll111l_l1_ = l1llllllllll_l1_(code,reason,source,l11_l1_)
			if l1llll111l_l1_ and l1ll1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㨂"): l1ll1l1l1ll1_l1_ = l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㨃")
			else: l1ll1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ㨄")
			if l1llll111l_l1_ and l1ll1ll11lll_l1_==l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㨅"): l1ll1ll11lll_l1_ = l1l111_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ㨆")
			else: l1ll1ll11lll_l1_ = l1l111_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ㨇")
			settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ㨈"),l1ll1l1l1ll1_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ㨉"),l1ll1ll11lll_l1_)
		if l1llll111l_l1_:
			l1ll11lll1l1_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ㨊") in l1lllll1_l1_ and l1ll11lll1l1_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬะแฺ์็ࠤๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡࡕࡖࡐࠬ㨋"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㨌"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧ㨍")
				l1lll11ll_l1_ = l11l11lll11_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠻ࡴࡩࠩ㨎"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㨏"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㨐")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㨑")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㨒"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอษะࠤออำหะาห๊ࠦࡓࡔࡎࠪ㨓"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㨔"),time=2000)
				else:
					l1l1111111_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㨕"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㨖")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㨗")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㨘"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨ㨙"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㨚"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1ll11lll_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㨛"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㨜")] and l1lll1ll1111_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩ㨝"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㨞"),time=2000)
				l1lll11ll_l1_ = l11ll11l1l1_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࠮࠸ࡷ࡬ࠬ㨟"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㨠"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㨡")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㨢")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㨣"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"้ࠩะฬำࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ㨤"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㨥"),time=2000)
				else:
					l1l1111111_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㨦"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㨧")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㨨")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㨩"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨใืู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭㨪"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㨫"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1l1l1ll1_l1_ in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㨬"),l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㨭")] and l11ll11l11l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬะแฺ์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧ㨮"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㨯"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬ㨰")
				l1lll11ll_l1_ = l11l11lll11_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠽ࡴࡩࠩ㨱"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㨲"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪ㨳")+l1ll11ll1l11_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㨴")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㨵")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㨶"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨ㨷"),l1l111_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㨸"),time=2000)
				else:
					l1l1111111_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㨹"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧ㨺")+l1ll11ll1l11_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㨻")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㨼")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㨽"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧโึ็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧ㨾"),l1l111_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㨿"),time=2000)
		if l1ll1ll11lll_l1_==l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㩀") or l1ll1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ㩁"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11lll1111l_l1_ = l1llllllllll_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1l1ll11_l1_ and l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨ㩂") not in source:
				l1111l11lll_l1_(l1l111_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡲࡪࡺࡷࡰࡴ࡮ࠤ࡮ࡹࡳࡶࡧࡶࠤࡼ࡯ࡴࡩ࠼ࠣࠫ㩃")+source)
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ㩄")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㩅"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㩆"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㩇")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭㩈"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㩉"))
	if settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ㩊")) not in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㩋"),l1l111_l1_ (u"ࠧࡔࡖࡒࡔࠬ㩌"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㩍")]: settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ㩎"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㩏"))
	return l1lll1l11_l1_
def l11l1l_l1_(cache,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l11l_l1_=l1l111_l1_ (u"ࠫࠬ㩐"),l1lll1ll1111_l1_=l1l111_l1_ (u"ࠬ࠭㩑")):
	l1lllll1_l1_,l1ll1l1lllll_l1_,l1lll1ll11ll_l1_,l1lll1lllll1_l1_ = l1ll1l11l1ll_l1_(url)
	item = method,l1lllll1_l1_,data,headers,allow_redirects
	if cache:
		response = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ㩒"),l1l111_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ㩓"),item)
		if response.succeeded:
			l1l1l1l1lll_l1_(l1l111_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨ㩔"),l1lllll1_l1_,data,headers,source,method)
			return response
	response = l11l11lll11_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l11l_l1_,l1lll1ll1111_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㩕") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if cache: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㩖"),item,response,cache)
	return response
def l1l1llll_l1_(cache,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㩗")
	else:
		method = l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㩘")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(cache,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll1l11l1ll_l1_(url):
	l1ll1ll11l1l_l1_ = url.split(l1l111_l1_ (u"࠭ࡼࡽࠩ㩙"))
	l1lllll1_l1_,l1ll1l1lllll_l1_,l1lll1ll11ll_l1_,l1lll1lllll1_l1_ = l1ll1ll11l1l_l1_[0],None,None,True
	for item in l1ll1ll11l1l_l1_:
		if l1l111_l1_ (u"ࠧࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ㩚") in item: l1ll1l1lllll_l1_ = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ㩛"))[1]
		elif l1l111_l1_ (u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬ㩜") in item: l1lll1ll11ll_l1_ = item.split(l1l111_l1_ (u"ࠪࡁࠬ㩝"))[1]
		elif l1l111_l1_ (u"ࠫࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ㩞") in item: l1lll1lllll1_l1_ = False
	return l1lllll1_l1_,l1ll1l1lllll_l1_,l1lll1ll11ll_l1_,l1lll1lllll1_l1_
def l11ll1lll1l_l1_(name):
	start,l1lll11l1ll_l1_,modified = l1l111_l1_ (u"ࠬ࠭㩟"),l1l111_l1_ (u"࠭ࠧ㩠"),l1l111_l1_ (u"ࠧࠨ㩡")
	name = name.replace(ltr,l1l111_l1_ (u"ࠨࠩ㩢")).replace(rtl,l1l111_l1_ (u"ࠩࠪ㩣"))
	tmp = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠯࡜࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡞ࡠࠬࡡࡽ࡜ࡸ࡞ࡺ࠭ࠥ࠱࡜࡜࡞࠲ࡇࡔࡒࡏࡓ࡞ࡠࠬ࠳࠰࠿ࠪࠦࠪ㩤"),name,re.DOTALL)
	if tmp: start,l1lll11l1ll_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"ࠫࠥ࠭㩥"),l1l111_l1_ (u"ࠬ࠲ࠧ㩦"),l1l111_l1_ (u"࠭ࠧ㩧")]: modified = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㩨")
	if l1lll11l1ll_l1_: l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࠪ㩩")+l1lll11l1ll_l1_+l1l111_l1_ (u"ࠩࡢࠫ㩪")
	name = l1lll11l1ll_l1_+modified+name
	return name
def l1lllll1l11_l1_(cache,method,url,l11l1111l1l_l1_,l1lll1l11ll1_l1_,l111111l11l_l1_,headers=l1l111_l1_ (u"ࠪࠫ㩫")):
	l1ll11l111ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㩬"))
	l11l1l11111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ㩭")+l11l1111l1l_l1_)
	if l1ll11l111ll_l1_==l11l1l11111_l1_: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ㩮")+l11l1111l1l_l1_,l1l111_l1_ (u"ࠧࠨ㩯"))
	if l11l1l11111_l1_: l1llllll_l1_ = url.replace(l1ll11l111ll_l1_,l11l1l11111_l1_)
	else:
		l1llllll_l1_ = url
		l11l1l11111_l1_ = l1ll11l111ll_l1_
	l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ㩰"),headers,l1l111_l1_ (u"ࠩࠪ㩱"),l1l111_l1_ (u"ࠪࠫ㩲"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨ㩳"))
	html = l1lll11ll_l1_.content
	if PY3:
		try: html = html.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㩴"),l1l111_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭㩵"))
		except: pass
	code = l1lll11ll_l1_.code
	if code!=-2 and (not l1lll11ll_l1_.succeeded or l111111l11l_l1_ not in html):
		l1lll1l11ll1_l1_ = l1lll1l11ll1_l1_.replace(l1l111_l1_ (u"ࠧࠡࠩ㩶"),l1l111_l1_ (u"ࠨ࠭ࠪ㩷"))
		l1lllll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ㩸")+l1lll1l11ll1_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㩹"):l1l111_l1_ (u"ࠫࠬ㩺")}
		l1lll1l11_l1_ = l11l1l_l1_(cache,method,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭㩻"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ㩼"),l1l111_l1_ (u"ࠧࠨ㩽"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬ㩾"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if PY3:
				try: html = html.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㩿"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㪀"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ㪁"),html,re.DOTALL)
			l1111llllll_l1_ = [l11l1l11111_l1_]
			l111l1l1l11_l1_ = [l1l111_l1_ (u"ࠬࡧࡰ࡬ࠩ㪂"),l1l111_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠭㪃"),l1l111_l1_ (u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨ㪄"),l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ㪅"),l1l111_l1_ (u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫ㪆"),l1l111_l1_ (u"ࠪࡴ࡭ࡶࠧ㪇"),l1l111_l1_ (u"ࠫࡦࡺ࡬ࡢࡳࠪ㪈"),l1l111_l1_ (u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪ㪉"),l1l111_l1_ (u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭㪊"),l1l111_l1_ (u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩ㪋"),l1l111_l1_ (u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪ㪌"),l1l111_l1_ (u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫ㪍"),l1l111_l1_ (u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭㪎"),l1l111_l1_ (u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭㪏"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩ㪐"),l1l111_l1_ (u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩ㪑")]
			for l1ll1ll_l1_ in l1ll_l1_:
				if any(value in l1ll1ll_l1_ for value in l111l1l1l11_l1_): continue
				l11l1l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㪒"))
				if l11l1l11111_l1_ in l1111llllll_l1_: continue
				if len(l1111llllll_l1_)==9:
					l1l1111111_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㪓"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ㪔")+l11l1111l1l_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨ㪕")+l1ll11l111ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ㪖"))
					settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ㪗")+l11l1111l1l_l1_,l1l111_l1_ (u"࠭ࠧ㪘"))
					break
				l1111llllll_l1_.append(l11l1l11111_l1_)
				l1llllll_l1_ = url.replace(l1ll11l111ll_l1_,l11l1l11111_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠧࠨ㪙"),headers,l1l111_l1_ (u"ࠨࠩ㪚"),l1l111_l1_ (u"ࠩࠪ㪛"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧ㪜"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l111111l11l_l1_ in html:
					l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㪝"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ㪞")+l11l1111l1l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬ㪟")+l11l1l11111_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬ㪠")+l1ll11l111ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㪡"))
					settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ㪢")+l11l1111l1l_l1_,l11l1l11111_l1_)
					break
	return l11l1l11111_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠪࡳࡱࡪࠧ㪣")			:l1l111_l1_ (u"ࠫ็ี๊ๆࠩ㪤")
	,l1l111_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ㪥")		:l1l111_l1_ (u"࠭ๅห๊ๅๅࠬ㪦")
	,l1l111_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ㪧")		:l1l111_l1_ (u"ࠨ็ไๆํีࠧ㪨")
	,l1l111_l1_ (u"ࠩࡪࡳࡴࡪࠧ㪩")			:l1l111_l1_ (u"ࠪะ๏ีࠧ㪪")
	,l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㪫")		:l1l111_l1_ (u"ࠬ็ิๅࠩ㪬")
	,l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㪭")		:l1l111_l1_ (u"ࠧๆฮ็ำࠬ㪮")
	,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㪯")		:l1l111_l1_ (u"ࠩไ๎ิ๐่ࠨ㪰")
	,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㪱")			:l1l111_l1_ (u"ࠫ็์วสࠩ㪲")
	,l1l111_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࠫ㪳")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ㪴")
	,l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲ࠭㪵")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬ㪶")
	,l1l111_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭ࡤࡣࡰࠫ㪷")		:l1l111_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠไษ่ࠫ㪸")
	,l1l111_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ㪹")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬ㪺")
	,l1l111_l1_ (u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨ㪻")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭㪼")
	,l1l111_l1_ (u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫ㪽")	:l1l111_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬ㪾")
	,l1l111_l1_ (u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬ㪿")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨ㫀")
	,l1l111_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ㫁")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧ㫂")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ㫃")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭㫄")
	,l1l111_l1_ (u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫ㫅")		:l1l111_l1_ (u"้ࠪํู่ࠡษ็ื๏์ๅศࠩ㫆")
	,l1l111_l1_ (u"ࠫ࡭࡫࡬ࡢ࡮ࠪ㫇")		:l1l111_l1_ (u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨ㫈")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨ㫉")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨ㫊")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ㫋")		:l1l111_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫ㫌")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬ㫍")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫ㫎")
	,l1l111_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ㫏")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭㫐")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ㫑")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨ㫒")
	,l1l111_l1_ (u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬ㫓")	:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭㫔")
	,l1l111_l1_ (u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ㫕")	:l1l111_l1_ (u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫ㫖")
	,l1l111_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭㫗")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧ㫘")
	,l1l111_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ㫙")		:l1l111_l1_ (u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠨ㫚")
	,l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ㫛")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭㫜")
	,l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧ㫝")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩ㫞")
	,l1l111_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭㫟")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦศไำสࠫ㫠")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ㫡")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫ㫢")
	,l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࡶࡹࠫ㫣")		:l1l111_l1_ (u"๋ࠬไโࠩ㫤")
	,l1l111_l1_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧ㫥")		:l1l111_l1_ (u"ࠧๆๆไࠫ㫦")
	,l1l111_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ㫧")		:l1l111_l1_ (u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ㫨")
	,l1l111_l1_ (u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭㫩")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩ㫪")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭㫫")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧ㫬")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ㫭")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫ㫮")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫ㫯")		:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭㫰")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭㫱")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨ㫲")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨ㫳")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪ㫴")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨ㫵")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็่า์๋ࠫ㫶")
	,l1l111_l1_ (u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪ㫷")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫ㫸")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡦࡨࡥࡩ࠭㫹")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭㫺")
	,l1l111_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ㫻")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ㫼")
	,l1l111_l1_ (u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪ㫽")		:l1l111_l1_ (u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩ㫾")
	,l1l111_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ㫿")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬ㬀")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ㬁")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨ㬂")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬ㬃")	:l1l111_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪ㬄")
	,l1l111_l1_ (u"ࠪࡪࡴࡹࡴࡢࠩ㬅")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢไ์ุะวࠨ㬆")
	,l1l111_l1_ (u"ࠬࡧࡨࡸࡣ࡮ࠫ㬇")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨ㬈")
	,l1l111_l1_ (u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨ㬉")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแษำๆอࠬ㬊")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࡻࡴࡸ࡫ࠨ㬋")	:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠤ฾๋ไࠨ㬌")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭㬍")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭㬎")
	,l1l111_l1_ (u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭㬏")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩ㬐")
	,l1l111_l1_ (u"ࠨࡤࡵࡷࡹ࡫ࡪࠨ㬑")		:l1l111_l1_ (u"่ࠩ์็฿ࠠษำึฮ๏าࠧ㬒")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫ㬓")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫ㬔")
	,l1l111_l1_ (u"ࠬࡲࡡࡳࡱࡽࡥࠬ㬕")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫ㬖")
	,l1l111_l1_ (u"ࠧࡺࡣࡴࡳࡹ࠭㬗")		:l1l111_l1_ (u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬ㬘")
	,l1l111_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ㬙")		:l1l111_l1_ (u"้ࠪํู่ࠡๅอ็ํะࠧ㬚")
	,l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭㬛")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧ㬜")
	,l1l111_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡺ࡯ࡰࡰࡶࠫ㬝")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩ㬞")
	,l1l111_l1_ (u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩ㬟")		:l1l111_l1_ (u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩ㬠")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ㬡")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪ㬢")
	,l1l111_l1_ (u"ࠬ࡯ࡦࡪ࡮ࡰࠫ㬣")				:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠪ㬤")
	,l1l111_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡡࡳࡣࡥ࡭ࡨ࠭㬥")			:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪ㬦")
	,l1l111_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡧࡱ࡫ࡱ࡯ࡳࡩࠩ㬧")		:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨ㬨")
	,l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶࠪ㬩")				:l1l111_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠩ㬪")
	,l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬫")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪ㬬")
	,l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬭")			:l1l111_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧ㬮")
	,l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ㬯")				:l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩ㬰")
	,l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭㬱")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭㬲")
	,l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ㬳")	:l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬ㬴")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㬵")		:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧ㬶")
	,l1l111_l1_ (u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧ㬷")			:l1l111_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧ㬸")
	,l1l111_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡳࡩࡷࡹ࡯࡯ࡵࠪ㬹")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧ㬺")
	,l1l111_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡲࡢࡶ࡯ࡶࠫ㬻")		:l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฬ๊ศ้็ࠪ㬼")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡࡶࡦ࡬ࡳࡸ࠭㬽")		:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭㬾")
	,l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㬿")			:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧ㭀")
	,l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡼࡩࡥࡧࡲࡷࠬ㭁")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫ㭂")
	,l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ㭃"):l1l111_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪ㭄")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㭅")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ็๊สฮࠬ㭆")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫ㭇")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡ็๋ห฻๐ูࠨ㭈")
	,l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭㭉")					:l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㭊")
	,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭㭋")			:l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨ㭌")
	,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪ㭍")			:l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪ㭎")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬ㭏")			:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧ㭐")
	,l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠭㭑")					:l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ㭒")
	,l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠮࡮࡬ࡺࡪ࠭㭓")				:l1l111_l1_ (u"ࠬࡓ࠳ࡖࠢๅ๊ํอสࠨ㭔")
	,l1l111_l1_ (u"࠭࡭࠴ࡷ࠰ࡱࡴࡼࡩࡦࡵࠪ㭕")			:l1l111_l1_ (u"ࠧࡎ࠵ࡘࠤศ็ไศ็ࠪ㭖")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡹࡥࡳ࡫ࡨࡷࠬ㭗")			:l1l111_l1_ (u"ࠩࡐ࠷࡚ࠦๅิๆึ่ฬะࠧ㭘")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠪࠫ㭙")
	return result
def l1111l11lll_l1_(message=l1l111_l1_ (u"ࠫࠬ㭚")):
	l1lll1l1l111_l1_()
	if not message: message = l1l111_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥࡋࡸࡪࡶࠪ㭛")
	l1l1111111_l1_(l1l111_l1_ (u"࠭ࠧ㭜"),l1l111_l1_ (u"ࠧ࡝ࡰࠪ㭝")+message+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㭞"))
	try: sys.exit()
	except: pass
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠩ࠽࠳ࠬ㭟")):
	return _1llllll1ll1_l1_(urll,exceptions)
def l11l111l111_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠪࠫ㭠"),l1l111_l1_ (u"ࠫ࠵࠭㭡"),0]: return l1l111_l1_ (u"ࠬ࠭㭢")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1l1ll1l_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll1l1l1_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1l1ll1l_l1_)+str(l111ll1l1l1_l1_)+str(l111l111_l1_)
	return result
def l1ll1ll111l1_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"࠭ࠧ㭣"),l1l111_l1_ (u"ࠧ࠱ࠩ㭤"),0]: return l1l111_l1_ (u"ࠨࠩ㭥")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠩࠪ㭦")
	if len(l1l1llll1_l1_)==15:
		l11l1l1ll1l_l1_,l111ll1l1l1_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1l1ll1l_l1_ = int(l11l1l1ll1l_l1_)^l111l11l_l1_
		l111ll1l1l1_l1_ = int(l111ll1l1l1_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1l1ll1l_l1_==l111ll1l1l1_l1_==l111l111_l1_: result = str(l11l1l1ll1l_l1_*60)
	return result
def l1lll1l1ll11_l1_(l1l1llll1_l1_,l1lll1lll11l_l1_=l1l111_l1_ (u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬ㭧")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠫࠬ㭨"): return l1l111_l1_ (u"ࠬ࠭㭩")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1lll1lll11l_l1_)
	l11l1l1ll1l_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll1l1l1_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1l1ll1l_l1_)+str(l111ll1l1l1_l1_)+str(l111l111_l1_)
	return result
def l1111l11l1l_l1_(l1l1llll1_l1_,l1lll1lll11l_l1_=l1l111_l1_ (u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨ㭪")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠧࠨ㭫"): return l1l111_l1_ (u"ࠨࠩ㭬")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l11l11l_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1l1ll1l_l1_ = int(l1l1llll1_l1_[0:l1l1l11l11l_l1_])^l1ll1ll1_l1_
	l111ll1l1l1_l1_ = int(l1l1llll1_l1_[l1l1l11l11l_l1_:2*l1l1l11l11l_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l11l11l_l1_:3*l1l1l11l11l_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠩࠪ㭭")
	if l11l1l1ll1l_l1_==l111ll1l1l1_l1_==l111l111_l1_: result = str(int(l11l1l1ll1l_l1_)-int(l1lll1lll11l_l1_))
	return result
def l1l1l1lllll_l1_(l1l11l11l1l_l1_):
	l1lllll1lll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㭮")][8]
	l1lll111llll_l1_ = l1l11l1l111_l1_(32)
	l1lll11l11l1_l1_ = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ㭯"),l1l111_l1_ (u"ࠬࡹ࡫ࡪࡰࡶࠫ㭰"),l1l111_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㭱"),l1l111_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㭲"),l1l111_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㭳"))
	l11ll11111l_l1_,l111lllllll_l1_ = l1ll1l11ll_l1_(l1lll11l11l1_l1_)
	l11ll11111l_l1_ = l1lll1l1ll11_l1_(l11ll11111l_l1_,l1l111_l1_ (u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬ㭴"))
	l111ll11ll1_l1_ = {l1l111_l1_ (u"ࠪ࡭ࡩࡹࠧ㭵"):l1l111_l1_ (u"ࠫࡉࡏࡁࡍࡑࡊࠫ㭶"),l1l111_l1_ (u"ࠬࡻࡳࡳࠩ㭷"):l1lll111llll_l1_,l1l111_l1_ (u"࠭ࡶࡦࡴࠪ㭸"):l1l111lll1l_l1_,l1l111_l1_ (u"ࠧࡴࡥࡵࠫ㭹"):l1l11l11l1l_l1_,l1l111_l1_ (u"ࠨࡵ࡬ࡾࠬ㭺"):l11ll11111l_l1_}
	l1llll1111l1_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㭻"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㭼")}
	l1llllll1l11_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㭽"),l1lllll1lll1_l1_,l111ll11ll1_l1_,l1llll1111l1_l1_,l1l111_l1_ (u"ࠬ࠭㭾"),l1l111_l1_ (u"࠭ࠧ㭿"),l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡐࡍࡃ࡜ࡣࡉࡏࡁࡍࡑࡊ࠱࠶ࡹࡴࠨ㮀"))
	l1ll11llll11_l1_ = l1llllll1l11_l1_.content
	try:
		if not l1ll11llll11_l1_: l1ll1l1ll11l_l1_
		l1lll1llllll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㮁"),l1ll11llll11_l1_)
		l1ll11ll1lll_l1_ = l1lll1llllll_l1_[l1l111_l1_ (u"ࠩࡰࡷ࡬࠭㮂")]
		l1ll1l1lll11_l1_ = l1lll1llllll_l1_[l1l111_l1_ (u"ࠪࡷࡪࡩࠧ㮃")]
		l1llll1l11ll_l1_ = l1lll1llllll_l1_[l1l111_l1_ (u"ࠫࡸࡺࡰࠨ㮄")]
		l1ll1l1lll11_l1_ = int(l1111l11l1l_l1_(l1ll1l1lll11_l1_,l1l111_l1_ (u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨ㮅")))
		l1llll1l11ll_l1_ = int(l1111l11l1l_l1_(l1llll1l11ll_l1_,l1l111_l1_ (u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩ㮆")))
		for l111l11lll1_l1_ in range(l1ll1l1lll11_l1_,0,-l1llll1l11ll_l1_):
			if not eval(l1l111_l1_ (u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪ㮇")): l1ll1l1ll11l_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠨสสๆ๏ࠦไๅฬฯีอฯ้ࠠษ็ๅา฻ࠧ㮈"),str(l111l11lll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤะอๆ๋หࠪ㮉"),time=300*l1llll1l11ll_l1_)
			xbmc.sleep(1000*l1llll1l11ll_l1_)
		if eval(l1l111_l1_ (u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࡜ࡩࡥࡧࡲࠬ࠮࠭㮊")):
			l111ll11lll_l1_ = l1l111_l1_ (u"ࠦࡉࡏࡁࡍࡑࡊ࡫ࡤࡕࡋࠩࠩࠪ࠰ࠬิั้ฮࠪ࠰ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠮ࠪࠦ㮋")+l1ll11ll1lll_l1_+l1l111_l1_ (u"ࠧ࠭ࠩࠣ㮌")
			l111ll11lll_l1_ = l111ll11lll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㮍"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㮎")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㮏"),l1l111_l1_ (u"ࠩ࡟ࡠࡷ࠭㮐"))
			exec(l111ll11lll_l1_)
		l1ll1l1ll11l_l1_
	except: exec(l1l111_l1_ (u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ㮑"))
	return
def l1l11l111l1_l1_():
	exec(l1l111_l1_ (u"ࠫࠬ࠭ࠍࠋࡶࡵࡽ࠿ࠓࠊࠊࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶ࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡘ࡫ࡱࡨࡴࡽࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࡺ࡬࡮ࡲࡥࠡࡖࡵࡹࡪࡀࠍࠋࠋࠌࡼࡧࡳࡣ࠯ࡵ࡯ࡩࡪࡶࠨ࠲࠲࠳࠴࠮ࠓࠊࠊࠋࡷࡶࡾࡀࠠࡸ࡫ࡱࡨࡴࡽ࠱࠳࠵࠱࡫ࡪࡺࡆࡰࡥࡸࡷ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡥࡶࡪࡧ࡫ࠎࠌࠌࡾࡨࡸࡥࡢࡶࡨࡣࡪࡸ࡯ࡳࡴࠐࠎࡪࡾࡣࡦࡲࡷ࠾ࠥࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠒࠐࠧࠨࠩ㮒"))
	return
def l1ll1l11ll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1llll1ll1_l1_(l1lll11111l1_l1_,l1ll1llll1ll_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬ࠭㮓"),l1l111_l1_ (u"࠭ࠧ㮔"),l1l111_l1_ (u"ࠧࠨ㮕"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㮖"),l1lll11111l1_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㮗")+l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㮘"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1lll11111l1_l1_):
		for root,dirs,l11lllllll_l1_ in os.walk(l1lll11111l1_l1_,topdown=False):
			for file in l11lllllll_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㮙"),l1l111_l1_ (u"ࠬ࠭㮚"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㮛"),str(err))
					error = True
			if l1ll1llll1ll_l1_:
				for dir in dirs:
					l1ll111lllll_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1ll111lllll_l1_)
					except: pass
		if l1ll1llll1ll_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㮜"),l1l111_l1_ (u"ࠨࠩ㮝"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㮞"),l1l111_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ㮟"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㮠"),l1l111_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ㮡"))
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㮢"))
	return
def l1lll1l1l111_l1_(l111l111lll_l1_=l1l111_l1_ (u"ࠧࠨ㮣")):
	l1l1l1l1ll1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡳࡵ࠭㮤"))
	if l111l111lll_l1_:
		l11111lll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㮥"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㮦"),l1l111_l1_ (u"ࠫࠬ㮧"))
		l11l1llll11_l1_(l111l111lll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㮨"),l11111lll11_l1_)
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㮩"))
	if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㮪"): settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㮫"),l1l111_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㮬"))
	elif l1ll11l1l1_l1_==l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㮭"): settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㮮"),l1l111_l1_ (u"ࠬ࠭㮯"))
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ㮰")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㮱"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㮲"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㮳")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭㮴"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㮵"))
	if settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ㮶")) not in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㮷"),l1l111_l1_ (u"ࠧࡔࡖࡒࡔࠬ㮸"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㮹")]: settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ㮺"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㮻"))
	l11lll1l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ㮼"))
	l11l11l111l_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ㮽"))
	if l1l111_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ㮾") in str(l11l11l111l_l1_) and l11lll1l1ll_l1_ in [l1l111_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ㮿"),l1l111_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ㯀")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡙ࡥࡵࡘ࡬ࡩࡼࡓ࡯ࡥࡧࠫ࠴࠮࠭㯁"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l111l111l1l_l1_,l11ll11l1ll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l111l1l_l1_,l11ll11l1ll_l1_)
	return
def l1lllll1111_l1_(cache,method,url,data,headers,source):
	l1lllll1_l1_,l1ll1l1lllll_l1_,l1lll1ll11ll_l1_,l1lll1lllll1_l1_ = l1ll1l11l1ll_l1_(url)
	item = method,l1lllll1_l1_,data,headers
	if cache:
		html = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㯂"),l1l111_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬ㯃"),item)
		if html:
			l1l1l1l1lll_l1_(l1l111_l1_ (u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪ㯄"),url,data,headers,source,method)
			return html
	html = l1l11111lll_l1_(method,url,data,headers,source)
	if html and cache: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ㯅"),item,html,cache)
	return html
DIALOGg_OK = l1111l1_l1_
l11llll1l11_l1_ = l1l1l1l1ll1_l1_
l11lll111ll_l1_ = l1lll1l11l11_l1_
DIALOGg_YESNO = l1ll11ll1l_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l111ll1l_l1_
DIALOGg_TEXTVIEWER = l1ll1l1llll1_l1_
DIALOGg_CONTEXTMENU = l11l1lllll1_l1_
l111l1l11ll_l1_ = l1l111111l_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1ll11l1ll11_l1_
l1lll11l111l_l1_ = l1l11l1l11_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l11111ll_l1_
DOWNLOADd_USING_PROGRESSBAR = l1lllll1ll11_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l11lll111_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11ll11_l1_
PERMANENT_CACHEe = l1ll111l1l1_l1_
from EXCLUDES import *
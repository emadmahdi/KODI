# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭ᆇ")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡅࡏࡗࡥࠧᆈ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᆉ"):l1l111_l1_ (u"ࠪࠫᆊ")}
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ็ไศ็่้้ࠣศศำࠪᆋ"),l1l111_l1_ (u"ࠬฮใาษࠣࡘ࡛࠭ᆌ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==370: l1lll_l1_ = l1l1l11_l1_()
	elif mode==371: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==372: l1lll_l1_ = PLAY(url)
	elif mode==374: l1lll_l1_ = l11l1ll11_l1_(url)
	elif mode==375: l1lll_l1_ = l11l1l111_l1_(url)
	elif mode==376: l1lll_l1_ = l11l1l11l_l1_(0,url)
	elif mode==377: l1lll_l1_ = l11l1l11l_l1_(1,url)
	elif mode==379: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᆍ"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨᆎ"),l1l111_l1_ (u"ࠨࠩᆏ"),l1l111_l1_ (u"ࠩࠪᆐ"),l1l111_l1_ (u"ࠪࠫᆑ"),l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᆒ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆓ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᆔ"),l1l111_l1_ (u"ࠧࠨᆕ"),379,l1l111_l1_ (u"ࠨࠩᆖ"),l1l111_l1_ (u"ࠩࠪᆗ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᆘ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᆙ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᆚ"),l1l111_l1_ (u"࠭ࠧᆛ"),9999)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠳ࡳࡪࡦࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᆜ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᆝ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᆞ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᆟ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆠ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᆡ")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧᆢ"),l111l1_l1_,375)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆣ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᆤ")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ศำฯฬࠩᆥ"),l111l1_l1_,376)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆦ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᆧ")+l1lllll_l1_+l1l111_l1_ (u"่ࠬวว็ฬࠤฬ๊ๅๆอ็๎๋࠭ᆨ"),l111l1_l1_,374)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᆩ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᆪ"),l1l111_l1_ (u"ࠨࠩᆫ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡸࡴࡶ࠭࡮ࡧࡱࡹࠬᆬ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᆭ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items[7:]:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ᆮ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆯ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆰ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
		for l1ll1ll_l1_,title in items[0:7]:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩᆱ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆲ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᆳ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	return
def l11l1ll11_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠪࠫᆴ")):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᆵ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ᆶ"),l1l111_l1_ (u"࠭ࠧᆷ"),l1l111_l1_ (u"ࠧࠨᆸ"),l1l111_l1_ (u"ࠨࠩᆹ"),l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡃࡆࡘࡔࡘࡓࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᆺ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡴࡽࠠࡤࡣࡷࠤ࡙ࡧࡧࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᆻ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᆼ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᆽ") in l1ll1ll_l1_: continue
			else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆾ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆿ")+l1lllll_l1_+title,l1ll1ll_l1_,371)
	return
def l11l1l111_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠨࠩᇀ")):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᇁ"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫᇂ"),l1l111_l1_ (u"ࠫࠬᇃ"),l1l111_l1_ (u"ࠬ࠭ᇄ"),l1l111_l1_ (u"࠭ࠧᇅ"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡆࡆࡃࡗ࡙ࡗࡋࡄ࠮࠳ࡶࡸࠬᇆ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡐࡥ࡮ࡴࡃࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡸ࡮ࡺ࡬ࡦ࠴ࠪᇇ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡺ࡮ࡪࡰࡢࡩࡨࡣ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧᇈ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠪ࠾࠴࠵ࠧᇉ"),l1l111_l1_ (u"ࠫ࠿࠵࠯࠰ࠩᇊ")).replace(l1l111_l1_ (u"ࠬ࠵࠯ࠨᇋ"),l1l111_l1_ (u"࠭࠯ࠨᇌ")).replace(l1l111_l1_ (u"ࠧࠡࠩᇍ"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬᇎ"))
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᇏ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᇐ")+l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
	return
def l11l1l11l_l1_(id,l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬᇑ")):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᇒ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧᇓ"),l1l111_l1_ (u"ࠧࠨᇔ"),l1l111_l1_ (u"ࠨࠩᇕ"),l1l111_l1_ (u"ࠩࠪᇖ"),l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯࡚ࡅ࡙ࡉࡈࡊࡐࡊࡒࡔ࡝࠭࠲ࡵࡷࠫᇗ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡷ࡭ࡹࡲࡥ࠳ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡰࡹࠪᇘ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[id]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨᇙ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if not any(value in title for value in l11lll_l1_):
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"࠭࠺࠰࠱ࠪᇚ"),l1l111_l1_ (u"ࠧ࠻࠱࠲࠳ࠬᇛ")).replace(l1l111_l1_ (u"ࠨ࠱࠲ࠫᇜ"),l1l111_l1_ (u"ࠩ࠲ࠫᇝ")).replace(l1l111_l1_ (u"ࠪࠤࠬᇞ"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨᇟ"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᇠ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᇡ")+l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
	return
def l1lll11_l1_(url,l1l1l1lll_l1_=l1l111_l1_ (u"ࠧࠨᇢ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᇣ"),url,l1l111_l1_ (u"ࠩࠪᇤ"),l1l111_l1_ (u"ࠪࠫᇥ"),l1l111_l1_ (u"ࠫࠬᇦ"),l1l111_l1_ (u"ࠬ࠭ᇧ"),l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᇨ"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡷ࡫ࡧࡴࡦ࡭ࡥࡠࠩᇩ") in url:
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡄࡰࡧࡻ࡭࠮࠰࠭ࡃ࠮ࠨࠧᇪ"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࠣࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡭ࡥ࠯࠶ࠫᇫ"),html,re.DOTALL)
	if l1l1l1lll_l1_==l1l111_l1_ (u"ࠪࠫᇬ") and l11llll_l1_ and l11llll_l1_[0].count(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧࠩᇭ"))>1:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᇮ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭ᇯ"),url,371,l1l111_l1_ (u"ࠧࠨᇰ"),l1l111_l1_ (u"ࠨࠩᇱ"),l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࡴࠩᇲ"))
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᇳ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭ᇴ")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᇵ"))
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇶ"),l1lllll_l1_+title,l1ll1ll_l1_,371)
	else:
		l1l1_l1_ = []
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡲࡪ࠭࠴ࠪ࠱࠮ࡄ࠯ࡣࡰ࡮࠰ࡼࡸ࠳࠱࠳ࠩᇷ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠺ࠥࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡾࡳ࠮࠳࠵ࠫᇸ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫᇹ"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬᇺ"))
				l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠫ࠿࠵࠯ࠨᇻ"),l1l111_l1_ (u"ࠬࡀ࠯࠰࠱ࠪᇼ")).replace(l1l111_l1_ (u"࠭࠯࠰ࠩᇽ"),l1l111_l1_ (u"ࠧ࠰ࠩᇾ")).replace(l1l111_l1_ (u"ࠨࠢࠪᇿ"),l1l111_l1_ (u"ࠩࠨ࠶࠵࠭ሀ"))
				if l1l111_l1_ (u"ࠪ࠳ࡦࡲ࡟ࠨሁ") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሂ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠬอไฮๆๅอࠬሃ") in title and (l1l111_l1_ (u"࠭࠯ࡄࡣࡷ࠱ࠬሄ") in url or l1l111_l1_ (u"ࠧ࠰ࡕࡨࡥࡷࡩࡨ࠰ࠩህ") in url):
					l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠ࠮ࠢ࠮ห้ำไใหࠣ࠯ࡡࡪࠫࠨሆ"),title,re.DOTALL)
					if l1l1lll_l1_: title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧሇ")+l1l1lll_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪለ"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪሉ"),l1lllll_l1_+title,l1ll1ll_l1_,372,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ሊ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩላ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				title = l1l111_l1_ (u"ࠧึใะอࠥ࠭ሌ")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨል"),l1lllll_l1_+title,l1ll1ll_l1_,371,l1l111_l1_ (u"ࠩࠪሎ"),l1l111_l1_ (u"ࠪࠫሏ"),l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡶࠫሐ"))
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩሑ"),url,l1l111_l1_ (u"࠭ࠧሒ"),l1l111_l1_ (u"ࠧࠨሓ"),l1l111_l1_ (u"ࠨࠩሔ"),l1l111_l1_ (u"ࠩࠪሕ"),l1l111_l1_ (u"ࠪࡆࡔࡑࡒࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫሖ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡱࡧࡢࡦ࡮࠰ࡷࡺࡩࡣࡦࡵࡶࠤࡲࡸࡧ࠮ࡤࡷࡱ࠲࠻ࠠࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩሗ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llllll_l1_ = l1l111_l1_ (u"ࠬ࠭መ")
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡹࡷࡲࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪሙ"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡵࡧࡧࡦࡡࠪሚ"),l1l111_l1_ (u"ࠨ࠱ࡓࡰࡦࡿ࠯ࠨማ"))
	if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧሜ") not in l1lllll1_l1_: l1lllll1_l1_ = l111l1_l1_+l1lllll1_l1_
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠪ࠱ࠬም"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨሞ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ሟ"),l1l111_l1_ (u"࠭ࠧሠ"),l1l111_l1_ (u"ࠧࠨሡ"),l1l111_l1_ (u"ࠨࠩሢ"),l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪሣ"))
	l11l1ll1_l1_ = response.content
	l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨሤ"),l11l1ll1_l1_,re.DOTALL)
	if l1llllll_l1_:
		l1llllll_l1_ = l1llllll_l1_[-1]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩሥ") not in l1llllll_l1_: l1llllll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫሦ")+l1llllll_l1_
		if l1l111_l1_ (u"࠭࠯ࡑࡎࡄ࡝࠴࠭ሧ") not in l1lllll1_l1_:
			if l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠴࡭ࡪࡰ࠱࡮ࡸ࠭ረ") in l1llllll_l1_:
				l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡻ࡯ࡤࡦࡱ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሩ"),l11l1ll1_l1_,re.DOTALL)
				if l11l1l1l1_l1_:
					l11l11lll_l1_, l11l1l1ll_l1_ = l11l1l1l1_l1_[0]
					l1llllll_l1_ = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ሪ"))+l1l111_l1_ (u"ࠪ࠳ࡻ࠸࠯ࠨራ")+l11l11lll_l1_+l1l111_l1_ (u"ࠫ࠴ࡩ࡯࡯ࡨ࡬࡫࠴࠭ሬ")+l11l1l1ll_l1_+l1l111_l1_ (u"ࠬ࠴ࡪࡴࡱࡱࠫር")
		import ll_l1_
		ll_l1_.l1l_l1_([l1llllll_l1_],l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬሮ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨሯ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩሰ"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫሱ"),l1l111_l1_ (u"ࠪ࠯ࠬሲ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬࠴࠭ሳ")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ१") : l1l111_l1_ (u"ࠧࠨ२") }
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ३")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡅࡐࡉ࡟ࠨ४")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺ้ࠪอัฺหࠪ५")]
def l11l1ll_l1_(mode,url,text):
	if   mode==350: l1lll_l1_ = l1l1l11_l1_()
	elif mode==351: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==352: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==353: l1lll_l1_ = PLAY(url)
	elif mode==354: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ६")+text)
	elif mode==355: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ७")+text)
	elif mode==356: l1lll_l1_ = l11llll1_l1_(url)
	elif mode==357: l1lll_l1_ = l11l11ll_l1_(url)
	elif mode==359: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ८"),l1lllll_l1_+l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊ิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ९"),l1l111_l1_ (u"ࠨࠩ॰"),8)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧॱ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬॲ"),l1l111_l1_ (u"ࠫࠬॳ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬॴ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ॵ"),l1l111_l1_ (u"ࠧࠨॶ"),359,l1l111_l1_ (u"ࠨࠩॷ"),l1l111_l1_ (u"ࠩࠪॸ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧॹ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫॺ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨॻ"),l111l1_l1_,356)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ॼ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪॽ"),l111l1_l1_,357)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ॾ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫॿ"),l1l111_l1_ (u"ࠪࠫঀ"),9999)
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬঁ"),headers,l1l111_l1_ (u"ࠬ࠭ং"),l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪঃ"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡳࡧࡦࡩࡳࡺ࡬ࡺ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭঄"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = l111l1_l1_
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨঅ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫআ")+l1lllll_l1_+l1l111_l1_ (u"ࠪห฻๐แࠡฯา๎ะอࠧই"),l1lllll1_l1_,351)
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡅ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪঈ"),html,re.DOTALL)
	if l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_[0]
	else: l1lllll1_l1_ = l111l1_l1_
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬউ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨঊ")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨঋ"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠨࠩঌ"),l1l111_l1_ (u"ࠩࠪ঍"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ঎"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠨএ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡦࡰࡰࡷ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧঐ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭঑"),l1lllll_l1_+title,l1ll1ll_l1_,351)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ঒"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪও"),l1l111_l1_ (u"ࠩࠪঔ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࠭ࡣࡱࡻࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࠩক"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧখ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			if title not in l11lll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬগ"),l1lllll_l1_+title,l1ll1ll_l1_,351)
	return html
def l11llll1_l1_(l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧঘ")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨঙ"),headers,l1l111_l1_ (u"ࠨࠩচ"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ছ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࡮ࡢࡸࠪজ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫঝ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"ࠬࠦๅึ่ไอࠬঞ")
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ট"),l1lllll_l1_+title,l1ll1ll_l1_,355)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠧࠨঠ"): addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ড"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫঢ"),l1l111_l1_ (u"ࠪࠫণ"),9999)
	return html
def l11l11ll_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠫࠬত")):
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠬ࠭থ"),headers,l1l111_l1_ (u"࠭ࠧদ"),l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫধ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀࡳࡧࡶࠨন"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸࡪࡾࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ঩"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title not in l11lll_l1_:
				title = title+l1l111_l1_ (u"ࠪࠤ๊็ไหำฬࠫপ")
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫফ"),l1lllll_l1_+title,l1ll1ll_l1_,354)
		if l1l11l11_l1_==l1l111_l1_ (u"ࠬ࠭ব"): addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫভ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩম"),l1l111_l1_ (u"ࠨࠩয"),9999)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠩࠪর")):
	html = l1l1llll_l1_(l11ll11l_l1_,url,l1l111_l1_ (u"ࠪࠫ঱"),headers,True,l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪল"))
	if type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ঳"): l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡸ࡫ࡳࡩࡷ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡸ࡫ࡳࡩࡷ࠳ࡢࡶࡶࡷࡳࡳ࠳ࡰࡳࡧࡹࠫ঴"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡦࡰࡱࡷࡩࡷ࠭঵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡺ࡯࡭ࡳࡱ࠺ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺ࠭ࡸࡪ࡬ࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧশ"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			if l1l111_l1_ (u"ࠩส่า๊โสࠩষ") in title or l1l111_l1_ (u"ࠪห้ำไใ้ࠪস") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩহ"),title,re.DOTALL)
				if l1l1lll_l1_:
					title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ঺") + l1l1lll_l1_[0][0]
					if title not in l1l1_l1_:
						addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭঻"),l1lllll_l1_+title,l1ll1ll_l1_,352,l1ll1l_l1_)
						l1l1_l1_.append(title)
			elif l1l111_l1_ (u"ࠧๆี็ื়้࠭") in title:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨঽ"),l1lllll_l1_+title,l1ll1ll_l1_,352,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨা"),l1lllll_l1_+title,l1ll1ll_l1_,353,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫি"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧী"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬু"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬূ")+title,l1ll1ll_l1_,351)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨৃ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩৄ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ৅"),l1l111_l1_ (u"ࠪ࠯ࠬ৆"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩে")+l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭ৈ"),headers,True,l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ৉"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃอไฮๆๅหฯ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࠫ৊"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫো"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in l1l1l1l1_l1_:
			if l1l111_l1_ (u"ࠩส่า๊โสࠩৌ") in title or l1l111_l1_ (u"ࠪห้ำไใ্้ࠪ") in title: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪৎ"),l1lllll_l1_+title,l1ll1ll_l1_,353,l1ll1l_l1_)
	else:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬ৏"))
		if html.count(l1l111_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠧ৐"))>1: title = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ৑"),html,re.DOTALL)[1]
		else: title = l1l111_l1_ (u"ࠨำสฬ฼ࠦวๅฬื฾๏๊ࠧ৒")
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ৓"),l1lllll_l1_+title,url,353,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	l1l1l1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ৔"),url,l1l111_l1_ (u"ࠫࠬ৕"),l1l111_l1_ (u"ࠬ࠭৖"),l1l111_l1_ (u"࠭ࠧৗ"),l1l111_l1_ (u"ࠧࠨ৘"),l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ৙"))
	html = l1l1l1ll_l1_.content
	l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠤࠪ৚"),html,re.DOTALL)
	if l11l1l11_l1_:
		l11l1l11_l1_ = l11l1l11_l1_[0]
		headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৛"):l1l111_l1_ (u"ࠫࠬড়"),l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫঢ়"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ৞")}
		data = {l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤࠨয়"):l11l1l11_l1_}
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳࡜ࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧৠ")
		l11ll1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧৡ"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"ࠪࠫৢ"),l1l111_l1_ (u"ࠫࠬৣ"),l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ৤"))
		l11l1ll1_l1_ = l11ll1ll_l1_.content
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭৥"),l11l1ll1_l1_,re.DOTALL)
		for l11l1lll_l1_,name in items:
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠱ࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡥ࡫ࡲࡡ࡮࠺࡮࡯ࡰ࠵ࡉ࡯ࡥ࠲ࡅ࡯ࡧࡸ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ০")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡳࡳࡸࡺࡩࡥ࠿ࠪ১")+l11l1l11_l1_+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭২")+l11l1lll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ৩")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ৪")
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(name)
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡥ࡫ࡲࡡ࡮࠺࡮࡯ࡰ࠵ࡉ࡯ࡥ࠲ࡅ࡯ࡧࡸ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡆࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴ࡭ࡶࠧ৫")
		l11ll1ll_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ৬"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"ࠧࠨ৭"),l1l111_l1_ (u"ࠨࠩ৮"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭৯"))
		l11l1ll1_l1_ = l11ll1ll_l1_.content
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪৰ"),l11l1ll1_l1_,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭ৱ"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭৲")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ৳")
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭৴"),url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࠬ৵"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ৶"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ৷"),l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ৸"),l1l111_l1_ (u"ࠬࡵࡲࡥࡧࡵࡦࡾ࠭৹")]
	if l1l111_l1_ (u"࠭࠿ࠨ৺") in url: url = url.split(l1l111_l1_ (u"ࠧࡀࠩ৻"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬৼ"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ৽"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ৾"),l1l111_l1_ (u"ࠫࠬ৿")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ਀"))
	if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪਁ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩਂ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪਃ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ਄")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭ਅ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ਆ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨਇ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨਈ"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫਉ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪਊ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡤࡰࡱ࠭਋"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪࡃࠬ਌")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ਍"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ਎"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧਏ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫਐ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ਑"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩࡂࠫ਒")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪਓ"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬ࠭ਔ"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠬ࠭ਕ"),l1l111_l1_ (u"࠭࠱ࠨਖ"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧਗ"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨਘ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨਙ"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠪࠫਚ"),l1l111_l1_ (u"ࠫ࠶࠭ਛ"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪਜ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨਝ"),l1l111_l1_ (u"ࠧࠨਞ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩਟ"),headers,True,l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧਠ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡫ࡵࡲ࡮ࠢ࡬ࡨ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪਡ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪਢ"),block,re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡂ࠭࠴ࠪࡀࠫ࠿ࠫਣ"),block,re.DOTALL)
		if l1l111_l1_ (u"࠭࠽ࠨਤ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫਥ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨਦ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩਧ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪਨ"),l1lllll1_l1_,351,l1l111_l1_ (u"ࠫࠬ਩"),l1l111_l1_ (u"ࠬ࠷ࠧਪ"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ਫ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧਬ"),l1lllll1_l1_,355,l1l111_l1_ (u"ࠨࠩਭ"),l1l111_l1_ (u"ࠩࠪਮ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫਯ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ਰ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ਱")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨਲ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪਲ਼")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ਴")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩਵ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠥ࠭ਸ਼")+name,l1lllll1_l1_,354,l1l111_l1_ (u"ࠫࠬ਷"),l1l111_l1_ (u"ࠬ࠭ਸ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬਹ") not in value: value = option
			else: value = re.findall(l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਺"),value,re.DOTALL)[0]
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ਻")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ਼ࠫ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ਽")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭ਾ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩਿ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠢࠪੀ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩੁ")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠤࠬੂ")+name
			if type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ੃"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ੄"),l1lllll_l1_+title,url,354,l1l111_l1_ (u"ࠫࠬ੅"),l1l111_l1_ (u"ࠬ࠭੆"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪੇ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩੈ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ੉"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠩࡂࠫ੊")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪੋ"),l1lllll_l1_+title,l1llllll_l1_,351,l1l111_l1_ (u"ࠫࠬੌ"),l1l111_l1_ (u"ࠬ࠷੍ࠧ"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੎"),l1lllll_l1_+title,url,355,l1l111_l1_ (u"ࠧࠨ੏"),l1l111_l1_ (u"ࠨࠩ੐"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫੑ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬ੒") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭੓"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ੔"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧ੕")
	l1l11lll_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࠫ੖"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ੗"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ੘"),l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫਖ਼"),l1l111_l1_ (u"ࠫࡴࡸࡤࡦࡴࡥࡽࠬਗ਼")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧਜ਼")
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨੜ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ੝"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬਫ਼")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ੟") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ੠"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭੡")+key+l1l111_l1_ (u"ࠬࡃࠧ੢")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ੣"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ੤")+key+l1l111_l1_ (u"ࠨ࠿ࠪ੥")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭੦"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬ੧"))
	return l1l1l111_l1_
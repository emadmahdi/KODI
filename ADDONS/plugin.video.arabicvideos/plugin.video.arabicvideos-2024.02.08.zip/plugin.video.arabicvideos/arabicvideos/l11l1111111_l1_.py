# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ六")
headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ兮") : l1l111_l1_ (u"ࠨࠩ兯") }
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡋ࡝࡟ࠨ兰")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11lll1l11ll_l1_(url)
	elif mode==215: l1lll_l1_ = l11lll1l1l11_l1_(url)
	elif mode==218: l1lll_l1_ = l1l1llll1lll_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1llll1lll_l1_():
	message = l1l111_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้ࠦ࠮࠯࠰ࠣ์อำวอหࠣห้๏ࠠศ฻สำฮࠦศา็ฯอ๋ࠥๆࠡษ็ูๆืࠠ࠯࠰࠱ࠤํอไๆสิ้ัࠦอศๆํห๋ࠥิ฻๊็ࠤํ๐ูศ่ํࠤ๊์้ࠠ฻ๆอࠥ฻อ๋หࠣ࠲࠳࠴้ࠠๆ๊ิฬࠦำ้ใࠣ๎อ่้ࠡษ็้ํู่ࠡ็฽่็ࠦวๅ๋้ࠣฬࠦิศรࠣห้๊็ࠨ共")
	l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ兲"),l1l111_l1_ (u"ࠬ࠭关"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ兴"),l1l111_l1_ (u"ࠧศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้࠭兵"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ其"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ具"),l1l111_l1_ (u"ࠪࠫ典"),219,l1l111_l1_ (u"ࠫࠬ兹"),l1l111_l1_ (u"ࠬ࠭兺"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ养"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡓ࡭ࡳࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࡰࡪࡰࠩࡰ࡮ࡳࡩࡵ࠿࠵࠹ࠬ兼")
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ兽"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ兾")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ兿"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬ冀"),headers,l1l111_l1_ (u"ࠬ࠭冁"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ冂"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡇ࡫࡯ࡸࡪࡸࡳࡃࡷࡷࡸࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ冃"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ冄"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂ࠭内")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ円"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭冇")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ冈"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ冉"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ࠧๆี็ื้อสࠡษ้้๏࠭冊"),l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ冋")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ册"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ再"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭冎")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭冏"),headers,l1l111_l1_ (u"࠭ࠧ冐"),l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ冑"))
	if l1l111_l1_ (u"ࠨࡩࡨࡸࡵࡵࡳࡵࡵࠪ冒") in url or l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭冓") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡑࡪࡪࡩࡢࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ冔"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ冕"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ冖"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ冗"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭冘"),l1l111_l1_ (u"ࠨๅ็๎อ࠭写"),l1l111_l1_ (u"ࠩส฽้อๆࠨ冚"),l1l111_l1_ (u"๋ࠪิอแࠨ军"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ农"),l1l111_l1_ (u"ࠬ฿ัืࠩ冝"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭冞"),l1l111_l1_ (u"ࠧศๆห์๊࠭冟")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ冠") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫ冡"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ冢"))
		if l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯࠲ࠫ冣") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ冤"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ冥") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ冦") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ冧"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ冨") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ冩"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ冪"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭冫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ冬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠧศๆุๅาฯࠠࠨ冭"),l1l111_l1_ (u"ࠨࠩ冮"))
			if title!=l1l111_l1_ (u"ࠩࠪ冯"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ冰"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ冱")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭冲"),headers,l1l111_l1_ (u"࠭ࠧ决"),l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ冴"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡶ࡬࠱ࡱ࡯ࡳࡵ࠯ࡱࡹࡲࡨࡥࡳࡧࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ况"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠩࠪ冶").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ冷"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭冸"))
		title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ冹") + l1ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ冺"))[-1].replace(l1l111_l1_ (u"ࠧ࠮ࠩ冻"),l1l111_l1_ (u"ࠨࠢࠪ冼"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩส่า๊โส࠯ࠫࡠࡩ࠱ࠩࠨ冽"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ冾"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠫ࠵࠭冿")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ净"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ凁"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ凂") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ凃") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ凄"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ凅") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ准"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ凇"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ凈"),headers,l1l111_l1_ (u"ࠧࠨ凉"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ凊"))
	if l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ凋") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ凌"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ凍"),headers,l1l111_l1_ (u"ࠬ࠭凎"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ减"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ凐"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ凑"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠤࠪ凒"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l11111_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠭凓")+l1l1l11111_l1_+l1l111_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ凔")+l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭凕")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ凖")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠭ࠨࡼࠧࡳࡸࡳࡹࡁࠩࠨ凗"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ凘") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ凙"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ凚"),headers,l1l111_l1_ (u"ࠫࠬ凛"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭凜"))
		id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ凝"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l11111_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ凞"):l1l111_l1_ (u"ࠨࠩ凟") , l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ几"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ凡") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡤࡰࡹࡱࡰࡴࡧࡤ࡭࡫ࡱ࡯ࡸࠬࡰࡰࡵࡷࡍࡩࡃࠧ凢")+l1l1l11111_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭凣"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ凤"),l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ凥"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡫࠷࠳࠰࠿ࠩ࡞ࡧ࠯࠮࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ処"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ凧"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ凨")+name+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ凩")+l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ凪")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡩ࠸ࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ凫"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠧࠨ凬")
					items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ凭"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"ࠩࠩࠪࠬ凮") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ凯"))[2].lower() + l1l111_l1_ (u"ࠫࠫࠬࠧ凰")
						server = server.replace(l1l111_l1_ (u"ࠬ࠴ࡣࡰ࡯ࠩࠪࠬ凱"),l1l111_l1_ (u"࠭ࠧ凲")).replace(l1l111_l1_ (u"ࠧ࠯ࡥࡲࠪࠫ࠭凳"),l1l111_l1_ (u"ࠨࠩ凴"))
						server = server.replace(l1l111_l1_ (u"ࠩ࠱ࡲࡪࡺࠦࠧࠩ凵"),l1l111_l1_ (u"ࠪࠫ凶")).replace(l1l111_l1_ (u"ࠫ࠳ࡵࡲࡨࠨࠩࠫ凷"),l1l111_l1_ (u"ࠬ࠭凸"))
						server = server.replace(l1l111_l1_ (u"࠭࠮࡭࡫ࡹࡩࠫࠬࠧ凹"),l1l111_l1_ (u"ࠧࠨ出")).replace(l1l111_l1_ (u"ࠨ࠰ࡲࡲࡱ࡯࡮ࡦࠨࠩࠫ击"),l1l111_l1_ (u"ࠩࠪ凼"))
						server = server.replace(l1l111_l1_ (u"ࠪࠪࠫ࡮ࡤ࠯ࠩ函"),l1l111_l1_ (u"ࠫࠬ凾")).replace(l1l111_l1_ (u"ࠬࠬࠦࡸࡹࡺ࠲ࠬ凿"),l1l111_l1_ (u"࠭ࠧ刀"))
						server = server.replace(l1l111_l1_ (u"ࠧࠧࠨࠪ刁"),l1l111_l1_ (u"ࠨࠩ刂"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ刃") + name + server + l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ刄")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ刅"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭分"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ切"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ刈"),l1l111_l1_ (u"ࠨ࠭ࠪ刉"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭刊")+search
	l1lll11_l1_(url)
	return
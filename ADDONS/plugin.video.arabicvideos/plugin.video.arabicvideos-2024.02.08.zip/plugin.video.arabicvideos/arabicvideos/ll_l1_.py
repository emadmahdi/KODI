# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䣌")
l1l111ll1lll_l1_ = []
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䣍"):l1l111_l1_ (u"ࠫࠬ䣎")}
l1l1111ll111_l1_ = [l1l111_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ䣏"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ䣐"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭䣑"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䣒"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ䣓"),l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭䣔"),l1l111_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭䣕"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ䣖"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ䣗"),l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ䣘")]
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l1l1111111_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䣙"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ䣚")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫ䣛")+type+l1l111_l1_ (u"ࠫࠥࡣࠧ䣜"))
		l11lllll1111_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ䣝"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䣞"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䣟"))
		datetime = time.strftime(l1l111_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩ䣠"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ䣡")+l1l111lll1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ䣢")+str(kodi_version)
		message = l1l111_l1_ (u"ࠫࠬ䣣")
		if key not in list(l11lllll1111_l1_.keys()): l11lllll1111_l1_[key] = [line]
		else:
			if url not in str(l11lllll1111_l1_[key]): l11lllll1111_l1_[key].append(line)
			else: message = l1l111_l1_ (u"ࠬࡢ࡮้ࠡำหࠥอไโ์า๎ํࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥะูๆๆࠪ䣤")
		total = 0
		for key in list(l11lllll1111_l1_.keys()):
			l11lllll1111_l1_[key] = list(set(l11lllll1111_l1_[key]))
			total += len(l11lllll1111_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䣥"),l1l111_l1_ (u"ࠧࠨ䣦"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䣧"),l1l111_l1_ (u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪ䣨")+message+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠡๆ็฽้๋ࠠศๆหี๋อๅอࠢํๆํ๋ࠠษฮ่฽่ࠥวว็ฬࠤออไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣ๎ัีࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้๋ࠢืํ็๋ࠠ฻ิฺࠥ฿ไ๋ๅࠣห้ฮั็ษ่ะࠥษๆࠡฬิื้ࠦ็ั้ࠣห้่วว็ฬࠤส๊้ࠡษ็้อืๅอࠢ฼๊ิ๋วࠡ์ุฬาูࠦะั๊หࠥ࠻ࠠโ์า๎ํํวหࠩ䣩")+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䣪")+l1l111_l1_ (u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨ䣫")+str(total))
		if total>=5:
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࠧ䣬"),l1l111_l1_ (u"ࠧࠨ䣭"),l1l111_l1_ (u"ࠨࠩ䣮"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣯"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะࠥาๅฺࠢๅหห๋ษࠡใํ๋ฬࠦ࠵ࠡใํำ๏๎็ศฬ่๊๊ࠣࠦอัࠣห้ฮั็ษ่ะ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰ࠣืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮๅิฯ๋ࠣีํࠠศๆๅหห๋ษࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠฦำึห้ࠦ็ั้ࠣห้่วว็ฬࠤ็ฮไࠡ็ึั์อࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆ่ฬึ๋ฬࠡสไัฺࠦ็ั้ࠣห้็๊ะ์๋๋ฬะࠠภࠣࠤࠫ䣰"))
			if l1llll111l_l1_==1:
				l11lllll11l1_l1_ = l1l111_l1_ (u"ࠫࠬ䣱")
				for key in list(l11lllll1111_l1_.keys()):
					l11lllll11l1_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࠨ䣲")+key
					l1l11l1l1l1l_l1_ = sorted(l11lllll1111_l1_[key],reverse=False,key=lambda l11llll11111_l1_: l11llll11111_l1_[0])
					for datetime,url in l1l11l1l1l1l_l1_:
						l11lllll11l1_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠩ䣳")+datetime+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ䣴")+l111l11_l1_(url)
					l11lllll11l1_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䣵")
				import l1l11lll1ll_l1_
				succeeded = l1l11lll1ll_l1_.l11l1l111l1_l1_(l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࡴࠩ䣶"),l1l111_l1_ (u"ࠪࠫ䣷"),False,l1l111_l1_ (u"ࠫࠬ䣸"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䣹"),l1l111_l1_ (u"࠭ࠧ䣺"),l11lllll11l1_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䣻"),l1l111_l1_ (u"ࠨࠩ䣼"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣽"),l1l111_l1_ (u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭䣾"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䣿"),l1l111_l1_ (u"ࠬ࠭䤀"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䤁"),l1l111_l1_ (u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ลาีส่ࠬ䤂"))
			if l1llll111l_l1_!=-1:
				l11lllll1111_l1_ = {}
				l1lll1ll11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䤃"),l1l111_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ䤄"))
		if l11lllll1111_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䤅"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ䤆"),l11lllll1111_l1_,l1ll111l1l1_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11lll1l1l1l_l1_(l1ll11l1_l1_,source)
	l1l11lll1111_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䤇"))
	l11lll1lll1l_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䤈"))
	l1l11llllll1_l1_ = len(l1llll_l1_)-l1l11lll1111_l1_-l11lll1lll1l_l1_
	l11lllll1lll_l1_ = l1l111_l1_ (u"ࠧๆึส๋ิฯ࠺ࠨ䤉")+str(l1l11lll1111_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࠥะอๆ์็࠾ࠬ䤊")+str(l11lll1lll1l_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࠦรฯำ์࠾ࠬ䤋")+str(l1l11llllll1_l1_)
	if not l1llll_l1_: result,l1l1l1111111_l1_ = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䤌"),l1l111_l1_ (u"ࠫࠬ䤍")
	else:
		add = 0
		if not any(value in source for value in l1l1111ll111_l1_):
			add = 1
			l1llll_l1_ = [l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡥࡁࡍࡎࡢࡐࡎࡔࡋࡔࠩ䤎")]+list(l1llll_l1_)
			l1l1lll1_l1_ = [l1l111_l1_ (u"࠭แฮืࠣะ๊๐ูࠡษ็ื๏ืแาษอࠫ䤏")]+list(l1l1lll1_l1_)
		while True:
			l1l1l1111111_l1_,result = l1l111_l1_ (u"ࠧࠨ䤐"),l1l111_l1_ (u"ࠨࠩ䤑")
			l11l11l_l1_ = l1ll11ll_l1_(l11lllll1lll_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠶ࡹࡴࡠ࡯ࡨࡲࡺ࠭䤒")
			elif add and l11l11l_l1_==0:
				result = l1l111_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ䤓")
				l1lll_l1_ = l1l111l1l11l_l1_(l1l1lll1_l1_[add:],l1llll_l1_[add:],source)
				if l1lll_l1_:
					l1l11ll11ll1_l1_ = []
					for l1l11l1l1_l1_,l111111ll1_l1_,l1l11ll1l111_l1_,l1l11l1l11l1_l1_,l1l11111l1ll_l1_ in l1lll_l1_:
						if l1l11111l1ll_l1_: l1l11ll11ll1_l1_.append((l1l11l1l1_l1_,l111111ll1_l1_,l1l11ll1l111_l1_,l1l11l1l11l1_l1_,l1l11111l1ll_l1_))
					if l1l11ll11ll1_l1_: l1l1lll1_l1_,l1llll_l1_,errors,l11l11_l1_,l1ll_l1_ = zip(*l1l11ll11ll1_l1_)
					else:
						l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䤔"),l1l111_l1_ (u"ࠬ࠭䤕"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䤖"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦไๆࠢํฮ๊ࠦล๋ฮสำู๊ࠥาใิหฯࠦฬ๋ัฬࠤๆ๐่ࠠาสࠤฬ๊แ๋ัํ์ࠥ࠴࠮ࠡฯส์้ࠦร็ࠢอฬาัฺ่๋ࠠࠣีอࠠศๆไ๎ิ๐่ࠡใํࠤ๊๎วใ฻ࠣวำื้ࠨ䤗"))
						result = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ䤘")
						break
					l11lllll1lll_l1_ = l1l111_l1_ (u"ࠩสุ่๐ัโำสฮࠥอไอ์าอࠥ࠮ࠠࠨ䤙")+str(len(l1llll_l1_))+l1l111_l1_ (u"ࠪࠤ࠮࠭䤚")
					add = 0
					continue
			else:
				l1lll_l1_ = l1l111l1l11l_l1_([l1l1lll1_l1_[l11l11l_l1_]],[l1llll_l1_[l11l11l_l1_]],source)
				if l1lll_l1_:
					title,l1ll1ll_l1_,errors,l11l11_l1_,l1ll_l1_ = l1lll_l1_[0]
					if l1l111_l1_ (u"ุࠫ๐ัโำࠪ䤛") in title and l1l111_l1_ (u"ࠬ࠸ๅอ้๋่࠷࠭䤜") in title:
						l1l1111111_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䤝"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡙ࠧࠡࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࡓࡦࡴࡹࡩࡷࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ䤞")+title+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䤟")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ䤠"))
						import l1l11lll1ll_l1_
						l1l11lll1ll_l1_.l11lll1l1lll_l1_()
						result = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䤡")
					else:
						l1l1111111_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䤢"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒ࡯ࡥࡾ࡯࡮ࡨࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࡘ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪ䤣")+title+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䤤")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪ䤥"))
						result,l1l1l1111111_l1_,l1ll111lll11_l1_ = l1l111l111l1_l1_(title,l1ll1ll_l1_,errors,l11l11_l1_,l1ll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨ䤦"),l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䤧"),l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ䤨"),l1l111_l1_ (u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ䤩"),l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ䤪")] or len(l1llll_l1_)==1+add: break
			elif result in [l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䤫"),l1l111_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䤬"),l1l111_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ䤭")]: break
			elif result not in [l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭䤮"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ䤯")]:
				if l1l111_l1_ (u"ࠫࡡࡴࠧ䤰") in l1l1l1111111_l1_: l1l1l1111111_l1_ = l1l111_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠥࠦࠧ䤱")+l1l1l1111111_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ䤲"),l1l111_l1_ (u"ࠧ࡝ࡰ࡞ࡐࡊࡌࡔ࡞ࠢࠣࠫ䤳"))
				l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䤴"),l1l111_l1_ (u"ࠩࠪ䤵"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䤶"),l1l111_l1_ (u"ࠫฬ๊ำ๋ำไี๊ࠥๅࠡ์฼้้ࠦฬาสࠣื๏ืแาࠢ฽๎ึํࠧ䤷")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ䤸")+l1l1l1111111_l1_,profile=l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ䤹"))
	if result==l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䤺") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䤻"),l1l111_l1_ (u"ࠩࠪ䤼"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䤽"),l1l111_l1_ (u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪ䤾")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ䤿")+l1l1l1111111_l1_,profile=l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ䥀"))
	elif result in [l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䥁"),l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ䥂")] and l1l1l1111111_l1_!=l1l111_l1_ (u"ࠩࠪ䥃"): l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䥄"),l1l111_l1_ (u"ࠫࠬ䥅"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䥆"),l1l1l1111111_l1_,profile=l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ䥇"))
	return result
def l1l111l1l11l_l1_(l111lll1ll_l1_,l1ll11l1_l1_,source):
	global l1l111l11l11_l1_
	l1l111l11l11_l1_,l1lll_l1_,l1l111lll111_l1_,new = [],[],[],[]
	l1lll1l1l1l_l1_(False,False,False)
	count = len(l1ll11l1_l1_)
	for l1l11l1l1l1_l1_ in range(count):
		l1l111l11l11_l1_.append(None)
		title = l111lll1ll_l1_[l1l11l1l1l1_l1_]
		l1ll1ll_l1_ = l1ll11l1_l1_[l1l11l1l1l1_l1_].strip(l1l111_l1_ (u"ࠧࠡࠩ䥈")).strip(l1l111_l1_ (u"ࠨࠨࠪ䥉")).strip(l1l111_l1_ (u"ࠩࡂࠫ䥊")).strip(l1l111_l1_ (u"ࠪ࠳ࠬ䥋"))
		if count>1: l1ll1lll_l1_(l1l111_l1_ (u"ࠫๆำีࠡีํีๆืࠠาไ่ࠤࠥ࠭䥌")+str(l1l11l1l1l1_l1_+1),title)
		l1l111l1l1l1_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䥍"),1)[0]
		l1l11ll11lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䥎"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࠩ䥏"),l1l111l1l1l1_l1_)
		if l1l11ll11lll_l1_: l1l111l11l11_l1_[l1l11l1l1l1_l1_] = l1l11ll11lll_l1_
		else:
			l1l11ll1lll1_l1_ = threading.Thread(target=l11llll111ll_l1_,args=(l1ll1ll_l1_,source,l1l11l1l1l1_l1_))
			l1l11ll1lll1_l1_.start()
			time.sleep(1)
			l1l111lll111_l1_.append(l1l11ll1lll1_l1_)
			new.append(l1l11l1l1l1_l1_)
	timeout = 20
	for l1l11ll1lll1_l1_ in l1l111lll111_l1_: l1l11ll1lll1_l1_.join(timeout)
	for l1l11l1l1l1_l1_ in range(count):
		title = l111lll1ll_l1_[l1l11l1l1l1_l1_]
		l1ll1ll_l1_ = l1ll11l1_l1_[l1l11l1l1l1_l1_].strip(l1l111_l1_ (u"ࠨࠢࠪ䥐")).strip(l1l111_l1_ (u"ࠩࠩࠫ䥑")).strip(l1l111_l1_ (u"ࠪࡃࠬ䥒")).strip(l1l111_l1_ (u"ࠫ࠴࠭䥓"))
		if l1l111l11l11_l1_[l1l11l1l1l1_l1_]: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11l11_l1_[l1l11l1l1l1_l1_]
		else: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬࡢ࡮ࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡗ࡭ࡲ࡫࡯ࡶࡶࠣࠬࠬ䥔")+str(timeout)+l1l111_l1_ (u"࠭ࠠࡴࡧࡦࡳࡳࡪࡳࠪࠩ䥕"),[],[]
		l1lll_l1_.append([title,l1ll1ll_l1_,l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_])
		if l1l11l1l1l1_l1_ in new:
			l1l111l1l1l1_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䥖"),1)[0]
			l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࠪ䥗"),l1l111l1l1l1_l1_,[l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_],l11l1l1_l1_)
	l1lll1l1l1l_l1_(l1l111_l1_ (u"ࠩࠪ䥘"),l1l111_l1_ (u"ࠪࠫ䥙"),l1l111_l1_ (u"ࠫࠬ䥚"))
	return l1lll_l1_
def l11llll111ll_l1_(url,source,seq=0):
	global l1l111l11l11_l1_
	l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䥛"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ䥜")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ䥝"))
	l1ll1ll_l1_,l1l11111llll_l1_ = url,l1l111_l1_ (u"ࠨࠩ䥞")
	l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠩࡌࡒ࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠭䥟")
	l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1lll1_l1_(url,source)
	if l1l1l1111111_l1_==l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ䥠"):
		l1l11111llll_l1_ = l1l111_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠥࡋࡸࡪࡶࠪ䥡")
		l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
		return l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䥢") in l1l1l1111111_l1_:
		l1l11111llll_l1_ = l1l111_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠵࠿ࠦࠠࡏࡧࡨࡨࠥࡋࡸࡵࡧࡵࡲࡦࡲࠠࡓࡧࡶࡳࡱࡼࡥࡳࠩ䥣")
		l1ll1ll_l1_ = l1l11111lll1_l1_(l1llll_l1_)[0]
		l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
		l1l1l1111l1l_l1_,l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111lll1l_l1_(l1l11111llll_l1_,l1ll1ll_l1_,source,seq)
	elif l1l1l1111111_l1_: l1l11111llll_l1_ = l1l111_l1_ (u"ࠧࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥࠦࠧ䥤")+l1l1l1111111_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ䥥"),l1l111_l1_ (u"ࠩࠪ䥦")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭䥧"),l1l111_l1_ (u"ࠫࠬ䥨"))[:80]
	if l1llll_l1_:
		l1llll_l1_ = l1l11111lll1_l1_(l1llll_l1_)
		l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䥩"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩ䥪")+l1l1l1111l1l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䥫")+url+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䥬")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡶࡹࡱࡺࡳ࠻ࠢ࡞ࠤࠬ䥭")+str(l1llll_l1_)+l1l111_l1_ (u"ࠪࠤࡢ࠭䥮"))
	else: l1l1111111_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䥯"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䥰")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䥱")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡋࡲࡳࡱࡵࡷ࠿࡛ࠦࠡࠩ䥲")+l1l11111llll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ䥳"))
	l1l11111llll_l1_ = l111l11_l1_(l1l11111llll_l1_)
	l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l1111lll1l_l1_(l1l11111llll_l1_,url,source,seq):
	global l1l111l11l11_l1_
	l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠨ䥴")
	l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l11ll_l1_(url,source)
	l1llll_l1_ = l1l11111lll1_l1_(l1llll_l1_)
	l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
	if l1l1l1111111_l1_==l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ䥵"): return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l111_l1_ (u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠬ䥶") in l1l1l1111111_l1_:
		l1l11111llll_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥࠦࠧ䥷")+l1l1l1111111_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ䥸"),l1l111_l1_ (u"ࠧࠨ䥹")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ䥺"),l1l111_l1_ (u"ࠩࠪ䥻"))[:80]
		l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䥼")
		l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l11l1_l1_(url,source)
		l1llll_l1_ = l1l11111lll1_l1_(l1llll_l1_)
		l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
		if l1l1l1111111_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࡡࡕࡉࡘࡕࡌࡗࡇࡕࠫ䥽"): return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿࠭䥾") in l1l1l1111111_l1_:
			l1l11111llll_l1_ += l1l111_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠷࠿ࠦࠠࠨ䥿")+l1l1l1111111_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ䦀"),l1l111_l1_ (u"ࠨࠩ䦁")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ䦂"),l1l111_l1_ (u"ࠪࠫ䦃"))[:80]
			l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪ䦄")
			l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1lll_l1_(url,source)
			l1llll_l1_ = l1l11111lll1_l1_(l1llll_l1_)
			l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
			if l1l1l1111111_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ䦅"): return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠧ䦆") in l1l1l1111111_l1_:
				l1l11111llll_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠹ࡀࠠࠡࠩ䦇")+l1l1l1111111_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ䦈"),l1l111_l1_ (u"ࠩࠪ䦉")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭䦊"),l1l111_l1_ (u"ࠫࠬ䦋"))[:80]
				l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫ䦌")
				l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1ll1_l1_(url,source)
				l1llll_l1_ = l1l11111lll1_l1_(l1llll_l1_)
				l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
				if l1l1l1111111_l1_==l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠭䦍"): return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠨ䦎") in l1l1l1111111_l1_:
					l1l11111llll_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠻࠺ࠡࠢࠪ䦏")+l1l1l1111111_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ䦐"),l1l111_l1_ (u"ࠪࠫ䦑")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ䦒"),l1l111_l1_ (u"ࠬ࠭䦓"))[:80]
	l1l111l11l11_l1_[seq] = l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l1l1111l1l_l1_,l1l11111llll_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111l111l1_l1_(title,l1ll1ll_l1_,l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_,source,type=l1l111_l1_ (u"࠭ࠧ䦔")):
	if l1l1l1111111_l1_==l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠧ䦕"): return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ䦖"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ䦗")
			else:
				l1l1l11lll11_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1l1111111_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䦘"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡵࡨࡰࡪࡩࡴࡦࡦࠣࡺ࡮ࡪࡥࡰࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪ䦙")+title+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䦚")+str(l1l1l11lll11_l1_)+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䦛"))
				if l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࠪ䦜") in l1l1l11lll11_l1_ and l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ䦝") in l1l1l11lll11_l1_:
					l1l1l1l11111_l1_,l1l1llll1111_l1_,l1ll111lll11_l1_ = l1l111111l11_l1_(l1l1l11lll11_l1_)
					if l1ll111lll11_l1_: l1l1l11lll11_l1_ = l1ll111lll11_l1_[0]
					else: l1l1l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ䦞")
				if not l1l1l11lll11_l1_: result = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䦟")
				else: result = l1llll111_l1_(l1l1l11lll11_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ䦠"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭䦡"),l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ䦢")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䦣"),l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ䦤"),l1l111_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ䦥")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䦦"),l1l111_l1_ (u"ࠫࠬ䦧"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䦨"),l1l111_l1_ (u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬ䦩"))
	else:
		result = l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䦪")
		l11ll1l11l_l1_ = GET_VIDEOFILETYPE(l1ll1ll_l1_)
		if l11ll1l11l_l1_: result = l1llll111_l1_(l1ll1ll_l1_,source,type)
	return result,l1l1l1111111_l1_,l1llll_l1_
def l1l1111ll11l_l1_(url,source):
	l1lllll1_l1_,l1l11l11l11l_l1_,server,l11llll1111l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠨࠩ䦫"),l1l111_l1_ (u"ࠩࠪ䦬"),l1l111_l1_ (u"ࠪࠫ䦭"),l1l111_l1_ (u"ࠫࠬ䦮"),l1l111_l1_ (u"ࠬ࠭䦯"),l1l111_l1_ (u"࠭ࠧ䦰"),l1l111_l1_ (u"ࠧࠨ䦱")
	if l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䦲") in url:
		l1lllll1_l1_,l1l11l11l11l_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䦳"),1)
		l1l11l11l11l_l1_ = l1l11l11l11l_l1_+l1l111_l1_ (u"ࠪࡣࡤ࠭䦴")+l1l111_l1_ (u"ࠫࡤࡥࠧ䦵")+l1l111_l1_ (u"ࠬࡥ࡟ࠨ䦶")+l1l111_l1_ (u"࠭࡟ࡠࠩ䦷")
		l1l11l11l11l_l1_ = l1l11l11l11l_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1lll111l1l1_l1_ = l1l11l11l11l_l1_.split(l1l111_l1_ (u"ࠧࡠࡡࠪ䦸"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠨࠩ䦹"): l111l1ll_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ䦺")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠪࡴࠬ䦻"),l1l111_l1_ (u"ࠫࠬ䦼")).replace(l1l111_l1_ (u"ࠬࠦࠧ䦽"),l1l111_l1_ (u"࠭ࠧ䦾"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠧࡀࠩ䦿")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䧀")).strip(l1l111_l1_ (u"ࠩࠩࠫ䧁"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ䧂"))
	if name: l11llll1111l_l1_ = name
	else: l11llll1111l_l1_ = server
	l11llll1111l_l1_ = l1l111l_l1_(l11llll1111l_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䧃"))
	name = name.replace(l1l111_l1_ (u"๋ࠬศศึิࠫ䧄"),l1l111_l1_ (u"࠭ࠧ䧅")).replace(l1l111_l1_ (u"ࠧิ์ิๅึ࠭䧆"),l1l111_l1_ (u"ࠨࠩ䧇")).replace(l1l111_l1_ (u"ࠩส่ࠥ࠭䧈"),l1l111_l1_ (u"ࠪࠤࠬ䧉")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䧊"),l1l111_l1_ (u"ࠬࠦࠧ䧋"))
	l1l11l11l11l_l1_ = l1l11l11l11l_l1_.replace(l1l111_l1_ (u"࠭ๅษษืีࠬ䧌"),l1l111_l1_ (u"ࠧࠨ䧍")).replace(l1l111_l1_ (u"ࠨีํีๆืࠧ䧎"),l1l111_l1_ (u"ࠩࠪ䧏")).replace(l1l111_l1_ (u"ࠪห้ࠦࠧ䧐"),l1l111_l1_ (u"ࠫࠥ࠭䧑")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䧒"),l1l111_l1_ (u"࠭ࠠࠨ䧓"))
	l11llll1111l_l1_ = l11llll1111l_l1_.replace(l1l111_l1_ (u"ࠧๆสสุึ࠭䧔"),l1l111_l1_ (u"ࠨࠩ䧕")).replace(l1l111_l1_ (u"ࠩึ๎ึ็ัࠨ䧖"),l1l111_l1_ (u"ࠪࠫ䧗")).replace(l1l111_l1_ (u"ࠫฬ๊ࠠࠨ䧘"),l1l111_l1_ (u"ࠬࠦࠧ䧙")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䧚"),l1l111_l1_ (u"ࠧࠡࠩ䧛"))
	return l1lllll1_l1_,l1l11l11l11l_l1_,server,l11llll1111l_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l11lll111l_l1_(url,source):
	l1l1l111l1l1_l1_,name,l11l1lll1l1_l1_,l1l1111ll1l1_l1_,l1l1111ll1ll_l1_,l1l111lll11l_l1_,l1l1l1111l1l_l1_ = l1l111_l1_ (u"ࠨࠩ䧜"),l1l111_l1_ (u"ࠩࠪ䧝"),None,None,None,None,None
	l1lllll1_l1_,l1l11l11l11l_l1_,server,l11llll1111l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l1111ll11l_l1_(url,source)
	if l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䧞") in url:
		if   type==l1l111_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ䧟"): type = l1l111_l1_ (u"ࠬࠦࠧ䧠")+l1l111_l1_ (u"࠭ๅโุ็ࠫ䧡")
		elif type==l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭䧢"): type = l1l111_l1_ (u"ࠨࠢࠪ䧣")+l1l111_l1_ (u"ࠩࠨู้อ็ะหࠪ䧤")
		elif type==l1l111_l1_ (u"ࠪࡦࡴࡺࡨࠨ䧥"): type = l1l111_l1_ (u"ࠫࠥ࠭䧦")+l1l111_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ䧧")
		elif type==l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䧨"): type = l1l111_l1_ (u"ࠧࠡࠩ䧩")+l1l111_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ䧪")
		elif type==l1l111_l1_ (u"ࠩࠪ䧫"): type = l1l111_l1_ (u"ࠪࠤࠬ䧬")+l1l111_l1_ (u"ࠫࠪࠫࠥࠦࠩ䧭")
		if l111lll_l1_!=l1l111_l1_ (u"ࠬ࠭䧮"):
			if l1l111_l1_ (u"࠭࡭ࡱ࠶ࠪ䧯") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"ࠧࠦࠩ䧰")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠨࠢࠪ䧱")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠩࠪ䧲"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭䧳")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠥ࠭䧴")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䧵")		in source: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䧶")		in source: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲ࠭䧷")
	elif l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ䧸")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨ䧹")	in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ䧺")		in source: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䧻")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯ࠫ䧼")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭䧽")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ䧾")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䧿")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ䨀")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠪๅัืࠧ䨁")			in name:   l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䨂")
	elif l1l111_l1_ (u"ࠬ็ไิูํ๊ࠬ䨃")		in name:   l11l1lll1l1_l1_	= l1l111_l1_ (u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ䨄")
	elif l1l111_l1_ (u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧ䨅")		in l1lllll1_l1_:   l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ䨆")
	elif l1l111_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ䨇")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ䨈")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䨉")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭䨊")		in name:   l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䨋")	in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭䨌")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠨࡶࡹࡪࡺࡴࠧ䨍")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠩࡷࡺࡰࡹࡡࠨ䨎")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ䨏")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭䨐")		in server: l11l1lll1l1_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ䨑")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨ䨒")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ䨓")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ䨔")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ䨕")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ䨖")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ䨗")	 	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭䨘")
	elif l1l111_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭䨙")	 	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ䨚")
	elif l1l111_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭䨛")	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭䨜")
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ䨝")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭䨞")
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䨟")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ䨠")
	elif l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䨡")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ䨢")
	elif l1l111_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ䨣")	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ䨤")
	elif l1l111_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ䨥")	in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱࠬ䨦")
	elif l1l111_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ䨧")		in server: l11l1lll1l1_l1_	= l1l111_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ䨨")
	elif l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䨩")	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ䨪")
	elif l1l111_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䨫")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ䨬")
	elif l1l111_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䨭")	 	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"࠭ࡣࡢࡶࡦ࡬ࠬ䨮")
	elif l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ䨯")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ䨰")
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䨱")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ䨲")
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ䨳")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫ䨴")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"࠭࡭ࡺࡸ࡬࡭ࡩ࠭䨵")		in server: l1l111lll11l_l1_	= l11llll1111l_l1_
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ䨶")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ䨷")
	elif l1l111_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ䨸")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ䨹")
	elif l1l111_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭䨺") 	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䨻")
	elif l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䨼")	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ䨽")
	elif l1l111_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭䨾")	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ䨿")
	elif l1l111_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䩀") 	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ䩁")
	elif l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䩂")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ䩃")
	elif l1l111_l1_ (u"ࠧࡶࡲࡳࠫ䩄") 			in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ䩅")
	elif l1l111_l1_ (u"ࠩࡸࡴࡧ࠭䩆") 			in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ䩇")
	elif l1l111_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ䩈") 		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ䩉")
	elif l1l111_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䩊") 	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ䩋")
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ䩌")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ䩍")
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䩎") 		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ䩏")
	elif l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䩐") 	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ䩑")
	elif l1l111_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䩒")	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ䩓")
	elif l1l111_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭䩔")	in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ䩕")
	elif l1l111_l1_ (u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫ䩖")		in server: l1l1111ll1l1_l1_	= l1l111_l1_ (u"ࠬ࡮ࡤ࠮ࡥࡧࡲࠬ䩗")
	if   l11l1lll1l1_l1_:	l1l1l111l1l1_l1_,name = l1l111_l1_ (u"࠭ฮศืࠪ䩘"),l11l1lll1l1_l1_
	elif l1l111lll11l_l1_:		l1l1l111l1l1_l1_,name = l1l111_l1_ (u"ࠧࠦ็ะำิ࠭䩙"),l1l111lll11l_l1_
	elif l1l1111ll1l1_l1_:		l1l1l111l1l1_l1_,name = l1l111_l1_ (u"ࠨࠧࠨ฽ฬ๋ࠠๆ฻ิ์ๆ࠭䩚"),l1l1111ll1l1_l1_
	elif l1l1111ll1ll_l1_:	l1l1l111l1l1_l1_,name = l1l111_l1_ (u"ࠩࠨࠩࠪ฿วๆࠢัหึา๊ࠨ䩛"),l1l1111ll1ll_l1_
	elif l1l1l1111l1l_l1_:	l1l1l111l1l1_l1_,name = l1l111_l1_ (u"ฺࠪࠩࠪࠫࠥษ่ࠤำอัอ์ࠪ䩜"),l11llll1111l_l1_
	else:			l1l1l111l1l1_l1_,name = l1l111_l1_ (u"ࠫࠪࠫࠥࠦࠧ฼ห๊ࠦๅอ้๋่ࠬ䩝"),l11llll1111l_l1_
	return l1l1l111l1l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l111l1lll1_l1_(url,source):
	l1lllll1_l1_,l1l111lll11l_l1_,server,l11llll1111l_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l1111ll11l_l1_(url,source)
	if   l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䩞")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䩟")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ䩠")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ䩡")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ䩢")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ䩣")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭䩤")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ䩥")		in source: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ䩦")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11ll1ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ䩧")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ䩨")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ䩩")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll11ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬ䩪")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll11ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ䩫")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ䩬")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡴࡷ࡭ࡶࡥࠬ䩭")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡵࡸ࠰ࡪ࠳ࡩ࡯࡮ࠩ䩮")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ䩯")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ䩰")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1ll111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ䩱")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lllllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡻࡹ࠴ࡶࠩ䩲")			in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ䩳")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1llll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䩴")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨ䩵")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳࡬ࡪࡩ࡫ࡸࠬ䩶")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬ䩷")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ䩸")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ䩹")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1llll11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ䩺")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䩻")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ䩼")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭䩽")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ䩾"),[l1l111_l1_ (u"ࠪࠫ䩿")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭䪀")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111llll11_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䪁")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll11l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠬ䪂")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡶࡲࡥࡥࡲ࠭䪃") 		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ䪄"),[l1l111_l1_ (u"ࠩࠪ䪅")],[l1lllll1_l1_]
	else: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪆"),[l1l111_l1_ (u"ࠫࠬ䪇")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ䪈")+l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l1111l11ll_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䪉"))
	l1llll_l1_ = []
	if   l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭䪊")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ䪋")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨ䪌") in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll1llll_l1_(url)
	elif l1l111_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ䪍")	in url   : l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111llll11_l1_(url)
	elif l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ䪎")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111l_l1_(url)
	elif l1l111_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ䪏")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111l11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ䪐")		in url   : l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ䪑")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111111_l1_(url)
	elif l1l111_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ䪒")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll111l_l1_(url)
	elif l1l111_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ䪓")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11llll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡩ࠺ࡺࡳࡢࡴࠪ䪔")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1ll11l_l1_(url)
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ䪕")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1lllll_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ䪖")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1lllll_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䪗") 		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䪘"),[l1l111_l1_ (u"ࠨࠩ䪙")],[url]
	elif l1l111_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ䪚") 	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1111_l1_(url)
	elif l1l111_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䪛")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11llll111_l1_(url)
	elif l1l111_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ䪜") 	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll11l_l1_(url)
	elif l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䪝")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࠪ䪞") 			in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111111l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡶࡲࡳࠫ䪟") 			in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111111l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䪠") 		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111lll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䪡") 	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1l111_l1_(url)
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ䪢")		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ䪣") 		in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l111l_l1_(url)
	elif l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䪤") 	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll11l11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䪥")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1ll111_l1_(url)
	elif l1l111_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ䪦")	in server: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll11ll_l1_(url)
	if l1llll_l1_: return l1l111_l1_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠪ䪧")+l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111_l1_ (u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬ䪨"),[],[]
def l1l1111l11l1_l1_(url,source):
	l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1ll1_l1_(url)
	if l1llll_l1_: return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
	if l1l1l1111111_l1_==l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ䪩"): l1l1l1111111_l1_ = l1l111_l1_ (u"ࠫࠬ䪪")
	return l1l111_l1_ (u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ䪫")+l1l1l1111111_l1_,[],[]
def l1l11111lll1_l1_(l1l1llll1l11_l1_):
	if l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䪬") in str(type(l1l1llll1l11_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1llll1l11_l1_:
			if l1l111_l1_ (u"ࠧࡴࡶࡵࠫ䪭") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ䪮"),l1l111_l1_ (u"ࠩࠪ䪯")).replace(l1l111_l1_ (u"ࠪࡠࡳ࠭䪰"),l1l111_l1_ (u"ࠫࠬ䪱")).strip(l1l111_l1_ (u"ࠬࠦࠧ䪲"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1llll1l11_l1_.replace(l1l111_l1_ (u"࠭࡜ࡳࠩ䪳"),l1l111_l1_ (u"ࠧࠨ䪴")).replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ䪵"),l1l111_l1_ (u"ࠩࠪ䪶")).strip(l1l111_l1_ (u"ࠪࠤࠬ䪷"))
	return l1ll_l1_
def l11lll1l1l1l_l1_(l1ll111lll11_l1_,source):
	l1l1l1l11l1_l1_ = l1ll1ll1_l1_
	data = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䪸"),l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭䪹"),l1ll111lll11_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l11l11l111_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1ll111lll11_l1_:
		if l1l111_l1_ (u"࠭࠯࠰ࠩ䪺") not in l1ll1ll_l1_: continue
		l1l1l111l1l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l11lll111l_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࠫ䪻"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䪼"))
		l1l11l11l111_l1_.append([l1l1l111l1l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l11l11l111_l1_:
		l1l11llll11l_l1_ = sorted(l1l11l11l111_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll11ll1_l1_ = []
		for line in l1l11llll11l_l1_:
			if line not in l11ll11ll1_l1_:
				l11ll11ll1_l1_.append(line)
		for l1l1l111l1l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll11ll1_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ䪽")
			title = l1l111_l1_ (u"ࠪื๏ืแาࠩ䪾")+l1l111_l1_ (u"ࠫࠥ࠭䪿")+type+l1l111_l1_ (u"ࠬࠦࠧ䫀")+l1l1l111l1l1_l1_+l1l111_l1_ (u"࠭ࠠࠨ䫁")+l111l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䫂")+l111lll_l1_+l1l111_l1_ (u"ࠨࠢࠪ䫃")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠩࠣࠫ䫄")+server
			title = title.replace(l1l111_l1_ (u"ࠪࠩࠬ䫅"),l1l111_l1_ (u"ࠫࠬ䫆")).strip(l1l111_l1_ (u"ࠬࠦࠧ䫇")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䫈"),l1l111_l1_ (u"ࠧࠡࠩ䫉")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䫊"),l1l111_l1_ (u"ࠩࠣࠫ䫋")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䫌"),l1l111_l1_ (u"ࠫࠥ࠭䫍"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭䫎"),l1ll111lll11_l1_,data,l1l1l1l11l1_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l1l1111l1lll_l1_(url,source):
	l111l111lll_l1_ = l1l111_l1_ (u"࠭ࠧ䫏")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l111l111lll_l1_ = str(error)
	if not l1lll_l1_:
		if l111l111lll_l1_==l1l111_l1_ (u"ࠧࠨ䫐"):
			l111l111lll_l1_ = traceback.format_exc()
			if l111l111lll_l1_!=l1l111_l1_ (u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫ䫑"): sys.stderr.write(l111l111lll_l1_)
		l1l1l1111111_l1_ = l111l111lll_l1_.splitlines()[-1]
		return l1l111_l1_ (u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬ䫒")+l1l1l1111111_l1_,[],[]
	return l1l111_l1_ (u"ࠪࠫ䫓"),[l1l111_l1_ (u"ࠫࠬ䫔")],[l1lll_l1_]
def l1l1111l1ll1_l1_(url,source):
	l111l111lll_l1_ = l1l111_l1_ (u"ࠬ࠭䫕")
	l1lll_l1_ = False
	try:
		import youtube_dl as l1l111111l1l_l1_
		l1l11l1ll111_l1_ = l1l111111l1l_l1_.YoutubeDL({l1l111_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ䫖"): True})
		l1lll_l1_ = l1l11l1ll111_l1_.extract_info(url,download=False)
	except Exception as error: l111l111lll_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ䫗") not in list(l1lll_l1_.keys()):
		if l111l111lll_l1_==l1l111_l1_ (u"ࠨࠩ䫘"):
			l111l111lll_l1_ = traceback.format_exc()
			if l111l111lll_l1_!=l1l111_l1_ (u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ䫙"): sys.stderr.write(l111l111lll_l1_)
		l1l1l1111111_l1_ = l111l111lll_l1_.splitlines()[-1]
		return l1l111_l1_ (u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭䫚")+l1l1l1111111_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ䫛")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬ䫜")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䫝")])
		return l1l111_l1_ (u"ࠧࠨ䫞"),l1l1lll1_l1_,l1llll_l1_
def l1l11l1l1l11_l1_(url):
	if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䫟") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11l1_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠩࠪ䫠"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࠳ࡖ࠺ࠪ䫡"),[],[]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䫢"),[l1l111_l1_ (u"ࠬ࠭䫣")],[url]
def l1ll11ll1ll_l1_(url):
	l1ll11l1_l1_,l111lll1ll_l1_ = [],[]
	if l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠮࡮ࡲ࠷ࡃࡻ࡯ࡤ࠾ࠩ䫤") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䫥"),url,l1l111_l1_ (u"ࠨࠩ䫦"),l1l111_l1_ (u"ࠩࠪ䫧"),False,l1l111_l1_ (u"ࠪࠫ䫨"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭䫩"))
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䫪") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䫫")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䫬"))
			l111lll1ll_l1_.append(server)
	elif l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ䫭") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䫮"),url,l1l111_l1_ (u"ࠪࠫ䫯"),l1l111_l1_ (u"ࠫࠬ䫰"),l1l111_l1_ (u"ࠬ࠭䫱"),l1l111_l1_ (u"࠭ࠧ䫲"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠸࡮ࡥࠩ䫳"))
		html = response.content
		l11111ll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬ࠭࠳ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ䫴"),html,re.DOTALL)
		if l11111ll1l1_l1_:
			l11111ll1l1_l1_ = l11111ll1l1_l1_[0]
			l1lll1111lll_l1_ = l1lll1l11l1l_l1_(l11111ll1l1_l1_)
			l1ll1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠲ࠧ䫵"),l1lll1111lll_l1_,re.DOTALL)
			if l1ll1lllllll_l1_:
				l1ll1lllllll_l1_ = l1ll1lllllll_l1_[0]
				l1ll1lllllll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䫶"),l1ll1lllllll_l1_)
				for dict in l1ll1lllllll_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࠩ䫷")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ䫸")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䫹"))
					l111lll1ll_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠩ䫺")+server)
		elif l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䫻") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䫼")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ䫽"))
			l111lll1ll_l1_.append(server)
		if l1l111_l1_ (u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫ䫾") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠬࡅࡵࡳ࡮ࡀࠫ䫿"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦࠨ䬀"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111lll1ll_l1_.append(l1l111_l1_ (u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧ䬁"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䬂"))
		l111lll1ll_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭䬃"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ䬄"),l111lll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࡡࡕࡉࡘࡕࡌࡗࡇࡕࠫ䬅"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䬆"),[l1l111_l1_ (u"࠭ࠧ䬇")],[l1ll1ll_l1_]
def l11llll1llll_l1_(url):
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䬈"):l1l111_l1_ (u"ࠨࡍࡲࡨ࡮࠵ࠧ䬉")+str(kodi_version)}
	for l1l111lll1_l1_ in range(50):
		time.sleep(0.100)
		response = l11l11lll11_l1_(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䬊"),url,l1l111_l1_ (u"ࠪࠫ䬋"),headers,False,l1l111_l1_ (u"ࠫࠬ䬌"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ䬍"))
		if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䬎") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䬏")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ䬐")+headers[l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䬑")]
			return l1l111_l1_ (u"ࠪࠫ䬒"),[l1l111_l1_ (u"ࠫࠬ䬓")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗࠫ䬔"),[],[]
def l1l111llll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䬕"),url,l1l111_l1_ (u"ࠧࠨ䬖"),l1l111_l1_ (u"ࠨࠩ䬗"),l1l111_l1_ (u"ࠩࠪ䬘"),l1l111_l1_ (u"ࠪࠫ䬙"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠳࠱ࡴࡶࠪ䬚"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱࠮ࡄ࠯ࠢ࠭࠰࠭ࡃ࠱࠴ࠪࡀ࠮ࠫ࠲࠯ࡅࠩ࠭ࠩ䬛"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"࠭ࠧ䬜"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨ䬝"),[],[]
def l1llll1l1ll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䬞"),url,l1l111_l1_ (u"ࠩࠪ䬟"),l1l111_l1_ (u"ࠪࠫ䬠"),l1l111_l1_ (u"ࠫࠬ䬡"),l1l111_l1_ (u"ࠬ࠭䬢"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠶ࡹࡴࠨ䬣"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䬤"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࠩ䬥"),[l1l111_l1_ (u"ࠩࠪ䬦")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ䬧"),[],[]
def l111l111l11_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࠱ࡴ࡭ࡶࠧ䬨") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䬩"),url,l1l111_l1_ (u"࠭ࠧ䬪"),l1l111_l1_ (u"ࠧࠨ䬫"),l1l111_l1_ (u"ࠨࠩ䬬"),l1l111_l1_ (u"ࠩࠪ䬭"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡉࡌࡆ࠳࠱ࡴࡶࠪ䬮"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡻࡷࡧࡰࡱࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䬯"),html,re.DOTALL)
		url = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䬰"),[l1l111_l1_ (u"࠭ࠧ䬱")],[url]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ䬲") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䬳"),url,l1l111_l1_ (u"ࠩࠪ䬴"),l1l111_l1_ (u"ࠪࠫ䬵"),l1l111_l1_ (u"ࠫࠬ䬶"),l1l111_l1_ (u"ࠬ࠭䬷"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭䬸"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䬹"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䬺") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䬻"),[l1l111_l1_ (u"ࠪࠫ䬼")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭䬽"),[],[]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䬾"),[l1l111_l1_ (u"࠭ࠧ䬿")],[url]
def l111l111l1_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䭀"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䭁"),l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䭂"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䭃")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䭄"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䭅"),l1l111_l1_ (u"࠭ࠧ䭆"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡎࡐ࡙࠰࠵ࡸࡺࠧ䭇"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䭈"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡏࡑ࡚ࠫ䭉"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䭊"),[l1l111_l1_ (u"ࠫࠬ䭋")],[l1ll1ll_l1_]
def l1ll1l1ll111_l1_(url):
	headers = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䭌"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䭍")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䭎"),url,l1l111_l1_ (u"ࠨࠩ䭏"),headers,l1l111_l1_ (u"ࠩࠪ䭐"),l1l111_l1_ (u"ࠪࠫ䭑"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭䭒"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䭓"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪ䭔"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䭕"),[l1l111_l1_ (u"ࠨࠩ䭖")],[l1ll1ll_l1_]
def l1ll1lll111_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䭗"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䭘")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䭙"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䭚"),l1l111_l1_ (u"࠭ࠧ䭛"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡌࡆࡒࡁࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ䭜"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠩࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾࡝ࠥࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧ࠭࡝ࠨࠩࠪ䭝"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡍࡇࡌࡂࡅࡌࡑࡆ࠭䭞"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䭟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䭠")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䭡"),[l1l111_l1_ (u"࠭ࠧ䭢")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䭣"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䭤")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䭥"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䭦"),l1l111_l1_ (u"ࠫࠬ䭧"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧ䭨"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠧࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠭ࠧࠨ䭩"),html,re.DOTALL|re.IGNORECASE)
	if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else: l1ll1ll_l1_ = url
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䭪"),[l1l111_l1_ (u"ࠨࠩ䭫")],[l1ll1ll_l1_]
def l1111l1l111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䭬"),url,l1l111_l1_ (u"ࠪࠫ䭭"),l1l111_l1_ (u"ࠫࠬ䭮"),l1l111_l1_ (u"ࠬ࠭䭯"),l1l111_l1_ (u"࠭ࠧ䭰"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡘ࡛ࡌࡕࡏ࠯࠴ࡷࡹ࠭䭱"))
	html = response.content
	l11llll11l11_l1_ = re.findall(l1l111_l1_ (u"ࠣࡸࡤࡶࠥ࡬ࡳࡦࡴࡹࠤࡂ࠴ࠪࡀࠩࠫ࠲࠯ࡅࠩࠨࠤ䭲"),html,re.DOTALL|re.IGNORECASE)
	if l11llll11l11_l1_:
		l11llll11l11_l1_ = l11llll11l11_l1_[0][2:]
		l11llll11l11_l1_ = base64.b64decode(l11llll11l11_l1_)
		if PY3: l11llll11l11_l1_ = l11llll11l11_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䭳"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䭴"),l11llll11l11_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫࠬ䭵")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡕࡘࡉ࡙ࡓ࠭䭶"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䭷") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䭸")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䭹"),[l1l111_l1_ (u"ࠩࠪ䭺")],[l1ll1ll_l1_]
def l1l11lllllll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䭻"),url,l1l111_l1_ (u"ࠫࠬ䭼"),l1l111_l1_ (u"ࠬ࠭䭽"),l1l111_l1_ (u"࠭ࠧ䭾"),l1l111_l1_ (u"ࠧࠨ䭿"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠳࠱ࡴࡶࠪ䮀"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠴࠶ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䮁"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡆࡉ࡜࡚ࡎࡖࠧ䮂"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䮃"),[l1l111_l1_ (u"ࠬ࠭䮄")],[l1ll1ll_l1_]
def l1l1l1111l_l1_(url):
	id = url.split(l1l111_l1_ (u"࠭࠯ࠨ䮅"))[-1]
	if l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ䮆") in url: url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ䮇"),l1l111_l1_ (u"ࠩࠪ䮈"))
	url = url.replace(l1l111_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࠩ䮉"),l1l111_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿࡥࡳ࠱ࡰࡩࡹࡧࡤࡢࡶࡤ࠳ࠬ䮊"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䮋"),url,l1l111_l1_ (u"࠭ࠧ䮌"),l1l111_l1_ (u"ࠧࠨ䮍"),l1l111_l1_ (u"ࠨࠩ䮎"),l1l111_l1_ (u"ࠩࠪ䮏"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ䮐"))
	html = response.content
	l1l1l1111111_l1_ = l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ䮑")
	error = re.findall(l1l111_l1_ (u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䮒"),html,re.DOTALL)
	if error: l1l1l1111111_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䮓"),html,re.DOTALL)
	if not url and l1l1l1111111_l1_:
		return l1l1l1111111_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ䮔"),l1l111_l1_ (u"ࠨࠩ䮕"))
	l1l1llll1111_l1_,l1ll111lll11_l1_ = l1l11l11l1_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"ࠩࠥࡳࡼࡴࡥࡳࠤ࠽ࡿࠧ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡸࡩࡲࡦࡧࡱࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䮖"),html,re.DOTALL)
	if owner: l1l11l1ll11l_l1_,l1l11l1l1lll_l1_,l1l1l11l11ll_l1_ = owner[0]
	else: l1l11l1ll11l_l1_,l1l11l1l1lll_l1_,l1l1l11l11ll_l1_ = l1l111_l1_ (u"ࠪࠫ䮗"),l1l111_l1_ (u"ࠫࠬ䮘"),l1l111_l1_ (u"ࠬ࠭䮙")
	l1l1l11l11ll_l1_ = l1l1l11l11ll_l1_.replace(l1l111_l1_ (u"࠭࡜࠰ࠩ䮚"),l1l111_l1_ (u"ࠧ࠰ࠩ䮛"))
	l1l11l1l1lll_l1_ = escapeUNICODE(l1l11l1l1lll_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ䮜")+l1l11l1l1lll_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䮝")]+l1l1llll1111_l1_
	l1llll_l1_ = [l1l1l11l11ll_l1_]+l1ll111lll11_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ䮞")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"๋ࠫࠥไโࠫࠪ䮟"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠬࡋࡘࡊࡖࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ䮠"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠸࠵࠸ࠦࡶࡴ࡯ࡁࠬ䮡")+l1l1l11l11ll_l1_+l1l111_l1_ (u"ࠧࠧࡶࡨࡼࡹࡃࠧ䮢")+l1l11l1l1lll_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ䮣")+new_path+l1l111_l1_ (u"ࠤࠬࠦ䮤"))
		return l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ䮥"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠫࠬ䮦"),[l1l111_l1_ (u"ࠬ࠭䮧")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䮨"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䮩"),l1l111_l1_ (u"ࠨࠩ䮪"),l1l111_l1_ (u"ࠩࠪ䮫"),l1l111_l1_ (u"ࠪࠫ䮬"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃࡑࡎࡖࡆ࠳࠱ࡴࡶࠪ䮭"))
	html = response.content
	if l1l111_l1_ (u"ࠬ࠴ࡪࡴࡱࡱࠫ䮮") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡴࡦࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䮯"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䮰"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆࡔࡑࡒࡂࠩ䮱"),[],[]
	url = url[0]
	if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䮲") not in url: url = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䮳")+url
	return l1l111_l1_ (u"ࠫࠬ䮴"),[l1l111_l1_ (u"ࠬ࠭䮵")],[url]
def l1l111111l11_l1_(url):
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䮶") : l1l111_l1_ (u"ࠧࠨ䮷") }
	if l1l111_l1_ (u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ䮸") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ䮹"),headers,l1l111_l1_ (u"ࠪࠫ䮺"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠴ࡷࡹ࠭䮻"))
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䮼"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"࠭ࠧ䮽"),[l1l111_l1_ (u"ࠧࠨ䮾")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䮿"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䯀"),l1l111_l1_ (u"ࠪࠫ䯁"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭䯂"),message[0])
				return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭䯃")+message[0],[],[]
	else:
		l111111111_l1_ = l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠩ䯄")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ䯅"),headers,l1l111_l1_ (u"ࠨࠩ䯆"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫ䯇"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ䯈"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ䯉"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠬ࠴ࡲࡢࡴࠪ䯊") in block or l1l111_l1_ (u"࠭࠮ࡻ࡫ࡳࠫ䯋") in block: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬ䯌"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䯍"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"ࠩࠪ䯎"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨࠬ䯏"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩ䯐"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ䯑"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭䯒"),block,re.DOTALL)
		l1l11llll1ll_l1_,l1l1lll1_l1_,l1l111l1111l_l1_,l1llll_l1_,l1l1111lll11_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭䯓") in l1ll1ll_l1_:
				l1l11llll1ll_l1_,l1l111l1111l_l1_ = l1l11l11l1_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l1l111l1111l_l1_
				if l1l11llll1ll_l1_[0]==l1l111_l1_ (u"ࠨ࠯࠴ࠫ䯔"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ䯕")+l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ䯖")+l111111111_l1_)
				else:
					for title in l1l11llll1ll_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ู๊ࠫࠥาใิࠤำอีࠡࠩ䯗")+l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠫ䯘")+l111111111_l1_+l1l111_l1_ (u"࠭ࠠࠨ䯙")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠧ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠩ䯚"),l1l111_l1_ (u"ࠨࠩ䯛"))
				title = title.strip(l1l111_l1_ (u"ࠩࠥࠫ䯜"))
				title = l1l111_l1_ (u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩ䯝")+l1l111_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ䯞")+l111111111_l1_+l1l111_l1_ (u"ࠬࠦࠧ䯟")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠨ䯠") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䯡"),headers,l1l111_l1_ (u"ࠨࠩ䯢"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫ䯣"))
		items = re.findall(l1l111_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢ䯤"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨ䯥")+l1l111_l1_ (u"ࠬࠦ࡭ࡱ࠶ࠣࠫ䯦")+l111111111_l1_+l1l111_l1_ (u"࠭ࠠࠨ䯧")+resolution.split(l1l111_l1_ (u"ࠧࡹࠩ䯨"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭䯩")+id+l1l111_l1_ (u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ䯪")+mode+l1l111_l1_ (u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ䯫")+hash
			l1l1111lll11_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l1l1111lll11_l1_ = set(l1l1111lll11_l1_)
		l1l111llllll_l1_,l1l1l11ll11l_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦ䯬"),title+l1l111_l1_ (u"ࠬࠬࠦࠨ䯭"),re.DOTALL)
			for resolution in l1l1111lll11_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"࠭ࡸࠨ䯮"))[1])
			l1l111llllll_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣ䯯"),l1l111_l1_ (u"ࠨࠨࠩࠫ䯰")+l1l111llllll_l1_[i]+l1l111_l1_ (u"ࠩࠩࠪࠬ䯱"),re.DOTALL)
			l1l1l11ll11l_l1_.append( [l1l111llllll_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l1l11ll11l_l1_ = sorted(l1l1l11ll11l_l1_, key=lambda x: x[3], reverse=True)
		l1l1l11ll11l_l1_ = sorted(l1l1l11ll11l_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l1l11ll11l_l1_)):
			l1l1lll1_l1_.append(l1l1l11ll11l_l1_[i][0])
			l1llll_l1_.append(l1l1l11ll11l_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ䯲"),[],[]
	return l1l111_l1_ (u"ࠫࠬ䯳"),l1l1lll1_l1_,l1llll_l1_
def l11lll1ll11l_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠬࡅࠧ䯴"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䯵") : l1l111_l1_ (u"ࠧࠨ䯶") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䯷"),headers,l1l111_l1_ (u"ࠩࠪ䯸"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࠶ࡖࡖࡅࡗ࠳࠱ࡴࡶࠪ䯹"))
	items = re.findall(l1l111_l1_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡼࡧࡩࡵ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ䯺"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䯻"),[l1l111_l1_ (u"࠭ࠧ䯼")],[url]
def l1l11llll1l1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䯽") : l1l111_l1_ (u"ࠨࠩ䯾") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ䯿"),headers,l1l111_l1_ (u"ࠪࠫ䰀"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪ䰁"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰂"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"࠭ࠧ䰃"),[l1l111_l1_ (u"ࠧࠨ䰄")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆ࡚ࡠ࡚ࡗࡔࡏࠫ䰅"),[],[]
def l11lll1lllll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䰆") : l1l111_l1_ (u"ࠪࠫ䰇") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ䰈"),headers,l1l111_l1_ (u"ࠬ࠭䰉"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ䰊"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪ䰋"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠨࠩ䰌"),[l1l111_l1_ (u"ࠩࠪ䰍")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖࠫ䰎"),[],[]
def l1llll1llll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠫࠬ䰏")
	if l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࠩ䰐") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䰑"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ䰒")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䰓"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ䰔"),l1l111_l1_ (u"ࠪࠫ䰕"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠶ࡳࡪࠧ䰖"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䰗")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠧࠨࡵࡵࡧࡂࡡࠧࠣ࡟ࠫ࠲࠯ࡅࠩ࡜ࠩࠥࡡࠬ࠭ࠧ䰘"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫࠽ࠩ࠰࠭ࡃ࠮ࡡࠦࠥ࡟ࠪ䰙"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠨࠩ䰚"),[l1l111_l1_ (u"ࠩࠪ䰛")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠪ࠳ࡱ࡯࡮࡬ࡵ࠲ࠫ䰜") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䰝"),url,l1l111_l1_ (u"ࠬ࠭䰞"),l1l111_l1_ (u"࠭ࠧ䰟"),True,l1l111_l1_ (u"ࠧࠨ䰠"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠲ࡵࡷࠫ䰡"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䰢") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䰣")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䰤"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䰥") in l1lllll1_l1_ or l1l111_l1_ (u"࠭࠯ࡧ࠱ࠪ䰦") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䰧"),l1l111_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ䰨"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡺ࠴࠭䰩"),l1l111_l1_ (u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩ䰪"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䰫"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䰬"),l1l111_l1_ (u"࠭ࠧ䰭"),l1l111_l1_ (u"ࠧࠨ䰮"),l1l111_l1_ (u"ࠨࠩ䰯"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬ䰰"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰱"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ䰲"),l1l111_l1_ (u"ࠬ࠭䰳"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰴"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ䰵"),l1l111_l1_ (u"ࠨࠩ䰶"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࠪ䰷"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䰸"),[l1l111_l1_ (u"ࠫࠬ䰹")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ䰺"),[],[]
	return l1l111_l1_ (u"࠭ࠧ䰻"),l1l1lll1_l1_,l1llll_l1_
def l11l1l1111l_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䰼"),url,l1l111_l1_ (u"ࠨࠩ䰽"),l1l111_l1_ (u"ࠩࠪ䰾"),l1l111_l1_ (u"ࠪࠫ䰿"),l1l111_l1_ (u"ࠫࠬ䱀"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬ䱁"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"࠭ࠧ䱂")
	if l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ䱃") in url or l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ䱄") in url:
		if l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ䱅") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱆"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ䱇") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䱈"),[l1l111_l1_ (u"࠭ࠧ䱉")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱊"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䱋"),l1l111_l1_ (u"ࠩࠪ䱌"),l1l111_l1_ (u"ࠪࠫ䱍"),l1l111_l1_ (u"ࠫࠬ䱎"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ䱏"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ䱐"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱑"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1llll1ll1ll_l1_ in items:
				l1l1lll1_l1_.append(l1llll1ll1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ䱒") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭䱓"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䱔"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䱕"),l1l111_l1_ (u"ࠬ࠭䱖"),l1l111_l1_ (u"࠭ࠧ䱗"),l1l111_l1_ (u"ࠧࠨ䱘"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠸ࡸࡤࠨ䱙"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䱚"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࠫ䱛"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ䱜") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱝"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䱞"),[l1l111_l1_ (u"ࠧࠨ䱟")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪ䱠"),[],[]
	return l1l111_l1_ (u"ࠩࠪ䱡"),l1l1lll1_l1_,l1llll_l1_
def l1111ll11_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ䱢")][0]
	headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䱣"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䱤"),url,l1l111_l1_ (u"࠭ࠧ䱥"),headers,l1l111_l1_ (u"ࠧࠨ䱦"),l1l111_l1_ (u"ࠨࠩ䱧"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭࠳ࡰࡧࠫ䱨"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䱩"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱪"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠪࠬ࠳࠰࠿ࠪࠩࠥ䱫"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡪ࡮ࡨ࠾ࠬ࠮࠮ࠫࡁࠬࠫࠧ䱬"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䱭")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠨࠩ䱮"),[l1l111_l1_ (u"ࠩࠪ䱯")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠪ䱰") in html:
		l1l11l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱱"),html,re.DOTALL)
		if l1l11l1l111l_l1_:
			l1ll1ll_l1_ = l1l11l1l111l_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䱲"),l1l111_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭䱳"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࠯ࠫ䱴"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䱵")+l1l11l11_l1_
				return l1l111_l1_ (u"ࠩࠪ䱶"),[l1l111_l1_ (u"ࠪࠫ䱷")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䱸"),[l1l111_l1_ (u"ࠬ࠭䱹")],[url]
def l111llll11_l1_(url):
	l111lll1ll_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"࠭࠯࠲࠱ࠪ䱺") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰࠳࠲ࠫ䱻"),l1l111_l1_ (u"ࠨ࠱࠷࠳ࠬ䱼"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䱽"),l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䱾"),l1l111_l1_ (u"ࠫࠬ䱿"),False,l1l111_l1_ (u"ࠬ࠭䲀"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠶ࡹࡴࠨ䲁"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡦࡨࡳࡃ࠭䲂"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䲃"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䲄"))
					l111lll1ll_l1_.append(server+l1l111_l1_ (u"ࠪࠤࠥ࠭䲅")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠫࠬ䲆"),l111lll1ll_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬ࠵ࡤ࠰ࠩ䲇") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲈"),url,l1l111_l1_ (u"ࠧࠨ䲉"),l1l111_l1_ (u"ࠨࠩ䲊"),l1l111_l1_ (u"ࠩࠪ䲋"),l1l111_l1_ (u"ࠪࠫ䲌"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠵ࡲࡩ࠭䲍"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲎"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"࠭࠯࠲࠱ࠪ䲏"),l1l111_l1_ (u"ࠧ࠰࠶࠲ࠫ䲐"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䲑"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䲒"),l1l111_l1_ (u"ࠪࠫ䲓"),False,l1l111_l1_ (u"ࠫࠬ䲔"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠷ࡷࡪࠧ䲕"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲖"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䲗"),[l1l111_l1_ (u"ࠨࠩ䲘")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭䲙"),[],[]
def l111ll11l1_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䲚"),url,l1l111_l1_ (u"ࠫࠬ䲛"),l1l111_l1_ (u"ࠬ࠭䲜"),l1l111_l1_ (u"࠭ࠧ䲝"),l1l111_l1_ (u"ࠧࠨ䲞"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳࠱ࡴࡶࠪ䲟"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"ࠩࠥࡥࡨࡺࡩࡰࡰࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲠"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"ࠪࡳࡵࡃࠧ䲡")+op+l1l111_l1_ (u"ࠫࠫ࡯ࡤ࠾ࠩ䲢")+id+l1l111_l1_ (u"ࠬࠬࡦ࡯ࡣࡰࡩࡂ࠭䲣")+fname
		headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䲤"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䲥")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䲦"),url,data,headers,l1l111_l1_ (u"ࠩࠪ䲧"),l1l111_l1_ (u"ࠪࠫ䲨"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠵ࡲࡩ࠭䲩"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡦࡨࡨࡶࡪࡸࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䲪"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䲫"),[l1l111_l1_ (u"ࠧࠨ䲬")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ䲭"),[],[]
def l11l11l1ll_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䲮"),1)[0].strip(l1l111_l1_ (u"ࠪࡃࠬ䲯")).strip(l1l111_l1_ (u"ࠫ࠴࠭䲰")).strip(l1l111_l1_ (u"ࠬࠬࠧ䲱"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"࠭ࠧ䲲")
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䲳"):l1l111_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠨ䲴") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䲵"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䲶"),headers,True,l1l111_l1_ (u"ࠫࠬ䲷"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠴ࡷࡹ࠭䲸"))
	if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䲹") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䲺")]
	if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䲻") in l1llllll_l1_:
		if l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䲼") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䲽"),l1l111_l1_ (u"ࠫ࠴ࡼ࠯ࠨ䲾"))
		l1l11l111l11_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠬࡅࡐࡉࡒࡖࡍࡉࡃࠧ䲿"))[1]
		headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䳀"):headers[l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䳁")] , l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䳂"):l1l111_l1_ (u"ࠩࡓࡌࡕ࡙ࡉࡅ࠿ࠪ䳃")+l1l11l111l11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䳄"),l1llllll_l1_,l1l111_l1_ (u"ࠫࠬ䳅"),headers,False,l1l111_l1_ (u"ࠬ࠭䳆"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ䳇"))
		html = response.content
		if l1l111_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䳈") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳉"),html,re.DOTALL)
		elif l1l111_l1_ (u"ࠩ࠲ࡺ࠴࠭䳊") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳋"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠫࠬ䳌")],[ items[0] ]
		elif l1l111_l1_ (u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫ䳍") in html:
			return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩ䳎"),[],[]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪ䳏"),[],[]
def l11l1111111_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䳐"),l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䳑"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ䳒")+l11l1l11_l1_+l1l111_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ䳓")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䳔"):l1l111_l1_ (u"࠭ࠧ䳕") , l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䳖"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䳗") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ䳘"),headers,l1l111_l1_ (u"ࠪࠫ䳙"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪ䳚"))
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䳛"),[l1l111_l1_ (u"࠭ࠧ䳜")],[l1lllll1_l1_]
def l1llll11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䳝"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䳞"):server,l1l111_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ䳟"):l1l111_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ䳠")}
	response = l11l1l_l1_(l1llll1111ll_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䳡"),url,l1l111_l1_ (u"ࠬ࠭䳢"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䳣"),l1l111_l1_ (u"ࠧࠨ䳤"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ䳥"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ䳦"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠪࠫ䳧")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䳨"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ䳩"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࠧ䳪"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䳫"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪ䳬"),[],[]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䳭"),[l1l111_l1_ (u"ࠪࠫ䳮")],[l1lllll1_l1_]
def l1ll1llll11l_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䳯"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䳰"):server,l1l111_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䳱"):l1l111_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䳲")}
	response = l11l1l_l1_(l1llll1111ll_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䳳"),url,l1l111_l1_ (u"ࠩࠪ䳴"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䳵"),l1l111_l1_ (u"ࠫࠬ䳶"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䳷"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ䳸"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠧࠨ䳹")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳺"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䳻"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࠫ䳼"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䳽"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ䳾"),[],[]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䳿"),[l1l111_l1_ (u"ࠧࠨ䴀")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䴁"),l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䴂"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫ䴃"):l11l1l11_l1_,l1l111_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ䴄"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䴅"),url,data,l1l111_l1_ (u"࠭ࠧ䴆"),l1l111_l1_ (u"ࠧࠨ䴇"),l1l111_l1_ (u"ࠨࠩ䴈"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐࡇࡆࡓ࠭࠲ࡵࡷࠫ䴉"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴊"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䴋"),[l1l111_l1_ (u"ࠬ࠭䴌")],[l1lllll1_l1_]
def l11111111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䴍"),url,l1l111_l1_ (u"ࠧࠨ䴎"),l1l111_l1_ (u"ࠨࠩ䴏"),l1l111_l1_ (u"ࠩࠪ䴐"),l1l111_l1_ (u"ࠪࠫ䴑"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧ䴒"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䴓"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䴔"),[l1l111_l1_ (u"ࠧࠨ䴕")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭䴖"),[],[]
def l11111l1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䴗"),url,l1l111_l1_ (u"ࠪࠫ䴘"),l1l111_l1_ (u"ࠫࠬ䴙"),l1l111_l1_ (u"ࠬ࠭䴚"),l1l111_l1_ (u"࠭ࠧ䴛"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡔ࠲࠷ࡳࡵࠩ䴜"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡌࡊࡗࡇࡍࡆࠢࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䴝"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䴞"),[l1l111_l1_ (u"ࠪࠫ䴟")],[l1ll1ll_l1_]
def l1lllllll1_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䴠"))
	if l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ䴡") in url:
		headers = {l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䴢"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䴣"),url,l1l111_l1_ (u"ࠨࠩ䴤"),headers,l1l111_l1_ (u"ࠩࠪ䴥"),l1l111_l1_ (u"ࠪࠫ䴦"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ䴧"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䴨"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䴩") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ䴪"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ䴫"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䴬"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䴭"),headers,l1l111_l1_ (u"ࠫࠬ䴮"),l1l111_l1_ (u"ࠬ࠭䴯"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠶ࡳࡪࠧ䴰"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䴱"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䴲"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䴳")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"ࠪࠫ䴴"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䴵"),[l1l111_l1_ (u"ࠬ࠭䴶")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䴷")+l11l11111_l1_
	return l1l111_l1_ (u"ࠧࠨ䴸"),[l1l111_l1_ (u"ࠨࠩ䴹")],[l1lllll1_l1_]
def l1l11111ll1l_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䴺"))
	if l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࠪ䴻") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䴼"),l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䴽"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"࠭ࡩࡥࠩ䴾"):l11l1l11_l1_,l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ䴿"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䵀"),url,data,l1l111_l1_ (u"ࠩࠪ䵁"),l1l111_l1_ (u"ࠪࠫ䵂"),l1l111_l1_ (u"ࠫࠬ䵃"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭䵄"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䵅"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ䵆") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䵇"):l11l11111_l1_,l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䵈"):l1l111_l1_ (u"ࠪࠫ䵉")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䵊"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䵋"),headers,l1l111_l1_ (u"࠭ࠧ䵌"),l1l111_l1_ (u"ࠧࠨ䵍"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ䵎"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䵏"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䵐"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䵑")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠬ࠭䵒"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䵓"),[l1l111_l1_ (u"ࠧࠨ䵔")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䵕")+l11l11111_l1_
		return l1l111_l1_ (u"ࠩࠪ䵖"),[l1l111_l1_ (u"ࠪࠫ䵗")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ䵘") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䵙"),l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䵚"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵛"))
		url = host+l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭䵜")+l11l1l11_l1_+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭䵝")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䵞"):l1l111_l1_ (u"ࠫࠬ䵟") , l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䵠"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䵡") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ䵢"),headers,l1l111_l1_ (u"ࠨࠩ䵣"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠲ࡵࡷࠫ䵤"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭䵥"),l1l111_l1_ (u"ࠫࠬ䵦")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ䵧"),l1l111_l1_ (u"࠭ࠧ䵨"))
		return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䵩"),[l1l111_l1_ (u"ࠨࠩ䵪")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭䵫") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ䵬") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䵭"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䵮"),l1l111_l1_ (u"࠭ࠧ䵯"),l1l111_l1_ (u"ࠧࠨ䵰"),l1l111_l1_ (u"ࠨࠩ䵱"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠳ࡰࡧࠫ䵲"))
			if l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䵳") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䵴")]
			counts += 1
		return l1l111_l1_ (u"ࠬ࠭䵵"),[l1l111_l1_ (u"࠭ࠧ䵶")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ䵷"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵸"))
	headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䵹"):server,l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䵺"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ䵻") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䵼"),headers,l1l111_l1_ (u"࠭ࠧ䵽"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠸࡮ࡥࠩ䵾"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䵿"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ䶀"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䶁"))
			return l1l111_l1_ (u"ࠫࠬ䶂"),[l1l111_l1_ (u"ࠬ࠭䶃")],[l1ll1ll_l1_]
	else:
		l1l111l11ll1_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䶄"),url,l1l111_l1_ (u"ࠧࠨ䶅"),headers,l1l111_l1_ (u"ࠨࠩ䶆"),l1l111_l1_ (u"ࠩࠪ䶇"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠵ࡵࡨࠬ䶈"))
		html = l1l111l11ll1_l1_.content
		l1ll1ll1l_l1_ = headers.copy()
		if l1l111_l1_ (u"ࠫࡤࡲ࡮࡬ࡡࠪ䶉") in str(l1l111l11ll1_l1_.cookies):
			cookies = l1l111l11ll1_l1_.cookies
			l1ll1ll1l_l1_[l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䶊")] = l111l11_l1_(l1lllll11_l1_(cookies))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ䶋"),html,re.DOTALL)
		if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䶌"),[l1l111_l1_ (u"ࠨࠩ䶍")],[url]
		else:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠩࠩࡨࡂ࠷ࠧ䶎")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䶏"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䶐"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䶑"),l1l111_l1_ (u"࠭ࠧ䶒"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩ䶓"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䶔"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				if l1l111_l1_ (u"ࠩࡰࡴ࠹࠭䶕") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࠳ࡩ࠵ࠧ䶖") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࠬ䶗"),[l1l111_l1_ (u"ࠬ࠭䶘")],[l1ll1ll_l1_]
				else: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䶙"),[l1l111_l1_ (u"ࠧࠨ䶚")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡔࡇࡈࡈࠬ䶛"),[],[]
def l1ll1lll11ll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠩࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷ࠭䶜") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䶝"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䶞")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䶟"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䶠"),headers,l1l111_l1_ (u"ࠧࠨ䶡"),l1l111_l1_ (u"ࠨࠩ䶢"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ䶣"))
		url = response.content
		if url: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䶤"),[l1l111_l1_ (u"ࠫࠬ䶥")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭䶦"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䶧"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䶨"))
		url = server+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ䶩")
		data = {l1l111_l1_ (u"ࠩ࡬ࡨࠬ䶪"):l11l1l11_l1_,l1l111_l1_ (u"ࠪ࡭ࠬ䶫"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䶬"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䶭"),l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䶮"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䶯"),url,data,headers,l1l111_l1_ (u"ࠨࠩ䶰"),l1l111_l1_ (u"ࠩࠪ䶱"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬ䶲"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䶳"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䶴"),[l1l111_l1_ (u"࠭ࠧ䶵")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ䶶"),[],[]
def l1l111l1ll1l_l1_(l11llll11lll_l1_):
	l1l11l11llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡦࡱࡷࡢ࡯࠱ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ䶷"))
	headers = {l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ䶸"):l1l11l11llll_l1_} if l1l11l11llll_l1_ else l1l111_l1_ (u"ࠪࠫ䶹")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䶺"),l11llll11lll_l1_,l1l111_l1_ (u"ࠬ࠭䶻"),headers,l1l111_l1_ (u"࠭ࠧ䶼"),l1l111_l1_ (u"ࠧࠨ䶽"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨ䶾"))
	l1l11l1l1ll1_l1_ = response.content
	l1l1l1111l11_l1_ = str(response.headers)
	l11lll1ll1l1_l1_ = l1l1l1111l11_l1_+l1l11l1l1ll1_l1_
	if l1l111_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ䶿") in l11lll1ll1l1_l1_: found = True
	else:
		l1l11111ll11_l1_,token,l11lll1llll1_l1_,l1l111l11111_l1_,found = l1l111_l1_ (u"ࠪࠫ䷀"),l1l111_l1_ (u"ࠫࠬ䷁"),l1l111_l1_ (u"ࠬ࠭䷂"),l1l111_l1_ (u"࠭ࠧ䷃"),False
		l1l1111111l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䷄"),l1l11l1l1ll1_l1_,re.DOTALL)
		if l1l1111111l1_l1_: l11lll1llll1_l1_,l1l111l11111_l1_ = l1l1111111l1_l1_[0]
		l1l1111111ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ䷅")][7]
		l1ll111llll1_l1_ = l1l11l1l111_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ䷆"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ䷇"):l1l111lll1l_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䷈"):l11llll11lll_l1_,l1l111_l1_ (u"ࠬࡱࡥࡺࠩ䷉"):l1l111l11111_l1_,l1l111_l1_ (u"࠭ࡩࡥࠩ䷊"):l1l111_l1_ (u"ࠧࠨ䷋"),l1l111_l1_ (u"ࠨ࡬ࡲࡦࠬ䷌"):l1l111_l1_ (u"ࠩࡪࡩࡹࡻࡲ࡭ࡵࠪ䷍")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䷎"),l1l1111111ll_l1_,data,l1l111_l1_ (u"ࠫࠬ䷏"),l1l111_l1_ (u"ࠬ࠭䷐"),l1l111_l1_ (u"࠭ࠧ䷑"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠶ࡳࡪࠧ䷒"))
			html = response.content
		html = l1l111_l1_ (u"ࠨࠩ䷓")
		if html.startswith(l1l111_l1_ (u"ࠩࡘࡖࡑ࡙࠽ࠨ䷔")):
			l1l1llll1l11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䷕"),html.split(l1l111_l1_ (u"࡚ࠫࡘࡌࡔ࠿ࠪ䷖"),1)[1])
			for request in l1l1llll1l11_l1_:
				url = request[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䷗")]
				method = request[l1l111_l1_ (u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭䷘")]
				data = request[l1l111_l1_ (u"ࠧࡥࡣࡷࡥࠬ䷙")]
				headers = request[l1l111_l1_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩ䷚")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠩࠪ䷛"),l1l111_l1_ (u"ࠪࠫ䷜"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫ䷝"))
				l1l11l1l1ll1_l1_ = response.content
				if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䷞") in l1l11l1l1ll1_l1_:
					found = True
					break
				l1l1l1111l11_l1_ = str(response.headers)
				l11lll1ll1l1_l1_ = l1l1l1111l11_l1_+l1l11l1l1ll1_l1_
				l1l11111ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡠࡼ࠱ࠩ࠯ࠬࡂࠦ࠭࡫ࡹࡋ࠰࠭ࡃ࠮ࠨࠧ䷟"),l11lll1ll1l1_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯࠰࠭ࡃࠧ࠮࠰࠴ࡃ࠱࠮ࡄ࠯ࠢࠨ䷠"),l11lll1ll1l1_l1_,re.DOTALL)
				if token: token = token[0]
				if l1l11111ll11_l1_ or token: break
		if not found:
			if not l1l11111ll11_l1_:
				if not token and l1l1111111l1_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠨࡋࡇࡁࠬ䷡")):
						data = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ䷢"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ䷣"):l1l111lll1l_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䷤"):l11llll11lll_l1_,l1l111_l1_ (u"ࠬࡱࡥࡺࠩ䷥"):l1l111l11111_l1_,l1l111_l1_ (u"࠭ࡩࡥࠩ䷦"):l1l111_l1_ (u"ࠧࠨ䷧"),l1l111_l1_ (u"ࠨ࡬ࡲࡦࠬ䷨"):l1l111_l1_ (u"ࠩࡪࡩࡹ࡯ࡤࠨ䷩")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䷪"),l1l1111111ll_l1_,data,l1l111_l1_ (u"ࠫࠬ䷫"),l1l111_l1_ (u"ࠬ࠭䷬"),l1l111_l1_ (u"࠭ࠧ䷭"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮ࠧ䷮"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩ䷯")
					if html.startswith(l1l111_l1_ (u"ࠩࡌࡈࡂ࠭䷰")):
						l1l1111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䷱"),html,re.DOTALL)
						l1l1l11l1l1l_l1_,l1l111111ll_l1_ = l1l1111llll1_l1_[0]
						message = l1l111_l1_ (u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩ䷲")+l1l111111ll_l1_+l1l111_l1_ (u"ࠬࠦหศ่ํอࠬ䷳")
						l1l1111ll1_l1_ = l1l111ll1l_l1_()
						l1l1111ll1_l1_.create(l1l111_l1_ (u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬ䷴"),message)
						t1 = time.time()
						l1l111l1llll_l1_,l1l1l11lll1l_l1_ = 0,0
						while l1l111l1llll_l1_<int(l1l111111ll_l1_):
							l1l11111ll_l1_(l1l1111ll1_l1_,int(l1l111l1llll_l1_/int(l1l111111ll_l1_)*100),message,l1l111_l1_ (u"ࠧࠨ䷵"),l1l111111ll_l1_+l1l111_l1_ (u"ࠨࠢ࠲ࠤࠬ䷶")+str(int(l1l111l1llll_l1_))+l1l111_l1_ (u"ࠩࠣࠤะอๆ๋หࠪ䷷"))
							if l1l111l1llll_l1_>l1l1l11lll1l_l1_+10:
								data = {l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ䷸"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ䷹"):l1l111lll1l_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䷺"):l11llll11lll_l1_,l1l111_l1_ (u"࠭࡫ࡦࡻࠪ䷻"):l1l111l11111_l1_,l1l111_l1_ (u"ࠧࡪࡦࠪ䷼"):l1l1l11l1l1l_l1_,l1l111_l1_ (u"ࠨ࡬ࡲࡦࠬ䷽"):l1l111_l1_ (u"ࠩࡪࡩࡹࡺ࡯࡬ࡧࡱࠫ䷾")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䷿"),l1l1111111ll_l1_,data,l1l111_l1_ (u"ࠫࠬ一"),l1l111_l1_ (u"ࠬ࠭丁"),l1l111_l1_ (u"࠭ࠧ丂"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧ七"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"ࠨࡖࡒࡏࡊࡔ࠽ࠨ丄")):
									token = html.split(l1l111_l1_ (u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ丅"),1)[1]
									break
								l1l1l11lll1l_l1_ = l1l111l1llll_l1_
							else: time.sleep(1)
							l1l111l1llll_l1_ = time.time()-t1
						l1l1111ll1_l1_.close()
				if token:
					l11llll11l1l_l1_ = response.cookies
					l1ll111l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠬ࠳࠰࠿ࠪ࠽ࠪ丆"),l11lll1ll1l1_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࠫ万") in list(l11llll11l1l_l1_.keys()): l1ll111l1l11_l1_ = l11llll11l1l_l1_[l1l111_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ丈")]
					elif l1ll111l1l11_l1_: l1ll111l1l11_l1_ = l1ll111l1l11_l1_[0]
					l1l1111111l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠴ࠪࡀࡣࡦࡸ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶ࡭ࡹ࡫࡫ࡦࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ三"),l1l11l1l1ll1_l1_,re.DOTALL)
					if l1l1111111l1_l1_: l11lll1llll1_l1_,l1l111l11111_l1_ = l1l1111111l1_l1_[0]
					if l1ll111l1l11_l1_ and l1l1111111l1_l1_:
						headers = {l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ上"):l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠩ下")+l1ll111l1l11_l1_,l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ丌"):l11llll11lll_l1_,l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ不"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ与")}
						data = l1l111_l1_ (u"ࠬ࡭࠭ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡶࡪࡹࡰࡰࡰࡶࡩࡂ࠭丏")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ丐"),l11lll1llll1_l1_,data,headers,False,l1l111_l1_ (u"ࠧࠨ丑"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠻ࡺࡨࠨ丒"))
						l1l11l1l1ll1_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l1l11111ll11_l1_ = re.findall(l1l111_l1_ (u"ࠤࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࠯ࠬࡂ࠭ࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ专"),str(cookies),re.DOTALL)
			if l1l11111ll11_l1_:
				name,l1l11111ll11_l1_ = l1l11111ll11_l1_[0]
				l1l11l11llll_l1_ = name+l1l111_l1_ (u"ࠪࡁࠬ且")+l1l11111ll11_l1_
				settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬ丕"),l1l11l11llll_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭世"),l1l111_l1_ (u"࠭ࠧ丗"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ丘"),l1l111_l1_ (u"ࠨ่ฯัฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦๆหษษะࠥํะศࠢส่ๆำีࠡๆๆ๎ࠥ๐ำหะา้์อࠠๅษะๆฬࠦ࠮࠯๋่ࠢฬࠦส้ฮาࠤาอฬสࠢ็ษ฾อฯส๊ࠢิฬࠦวๅใะูู๊ࠥะหࠣวูํัࠡ࡞ࡱࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊แฮืࠣืํ็๋ࠠฬๆีึࠦแ๋ࠢะห้ฯࠠห฼ํีࠥืศุࠢส่ัํวำࠢหห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฽แศรࠣีฬ๎สาࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣๅฺ๊ࠠิๆๆࠤฬ๊ัศ๊อีࠥ࠴࠮ࠡล๋ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥฮั้ๅึ๎ࠬ丙"))
				if l1l111_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ业") not in l1l11l1l1ll1_l1_:
					headers = {l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ丛"):l1l11l11llll_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ东"),l11llll11lll_l1_,l1l111_l1_ (u"ࠬ࠭丝"),headers,l1l111_l1_ (u"࠭ࠧ丞"),l1l111_l1_ (u"ࠧࠨ丟"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠼ࡺࡨࠨ丠"))
					l1l11l1l1ll1_l1_ = response.content
	if not found and not l1l11l11llll_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ両"),l1l111_l1_ (u"ࠪࠫ丢"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ丣"),l1l111_l1_ (u"ࠬ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤๆฺไหࠢ࠱࠲ࠥำว้ๆࠣษ฾อฯสࠢส่฾๋ไ๋ห้ࠣึฯࠠฤะิํࠥฮวิฬัำฬ๋ࠠ็ใึࠤฬ๊แ๋ัํ์ࠥษ่ࠡใํำ๏๎ࠠ฻์ิ๋๋ࠥๆ่ࠡไืࠥอไๆ๊ๅ฽ࠬ两"))
	return l1l11l1l1ll1_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111lll1ll_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ严"),url,l1l111_l1_ (u"ࠧࠨ並"),l1l111_l1_ (u"ࠨࠩ丧"),l1l111_l1_ (u"ࠩࠪ丨"),l1l111_l1_ (u"ࠪࠫ丩"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠱ࡴࡶࠪ个"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࡀ࠴ࡧ࠾ࠨ丫"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ丬"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ中") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ丮") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪ丯"),l1l111_l1_ (u"ࠪࠫ丰")).replace(l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ丱"),l1l111_l1_ (u"ࠬ࠭串")).strip(l1l111_l1_ (u"࠭ࠠࠨ丳")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ临"),l1l111_l1_ (u"ࠨࠢࠪ丵"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111lll1ll_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩห฽฻ํวࠡ์ะฮฬาࠠ࠷࠲ࠣฯฬ์๊สࠩ丶"),l111lll1ll_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭丷"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ丸"),[],[]
	l11llll11lll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l1l11l1l1ll1_l1_ = l1l111l1ll1l_l1_(l11llll11lll_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ丹"):
		l1l11l1lll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡢࡵࡰ࠰ࡰࡴࡧࡤࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ为"),l1l11l1l1ll1_l1_,re.DOTALL)
		if l1l11l1lll1l_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l11l1lll1l_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭主"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ丼"),l1l11l1l1ll1_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ丽"),[],[]
	return l1l111_l1_ (u"ࠪࠫ举"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ丿"),url,l1l111_l1_ (u"ࠬ࠭乀"),l1l111_l1_ (u"࠭ࠧ乁"),True,l1l111_l1_ (u"ࠧࠨ乂"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠵ࡸࡺࠧ乃"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ乄") in list(cookies.keys()):
		l1l11l11llll_l1_ = cookies[l1l111_l1_ (u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪ久")]
		l1l11l11llll_l1_ = l111l11_l1_(escapeUNICODE(l1l11l11llll_l1_))
		items = re.findall(l1l111_l1_ (u"ࠫࡷࡵࡵࡵࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ乆"),l1l11l11llll_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨ乇"),l1l111_l1_ (u"࠭࠯ࠨ么"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ义") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨࠧ࠵ࡊࠬ乊"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡥࡹࡩࡨ࠯࡫ࡶ࠳ࠬ之")+id
		return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭乌"),[l1l111_l1_ (u"ࠫࠬ乍")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ乎")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ乏"),l1l11l11_l1_,l1l111_l1_ (u"ࠧࠨ乐"),l1l111_l1_ (u"ࠨࠩ乑"),True,l1l111_l1_ (u"ࠩࠪ乒"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠸࡮ࡥࠩ乓"))
		l1l1l111111l_l1_ = response.url
		l1l1l11l11l1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭乔"))[2]
		l1l1l1l1111l_l1_ = l1l1l111111l_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ乕"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l1l11l11l1_l1_,l1l1l1l1111l_l1_)
		headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ乖"):l1l111_l1_ (u"ࠧࠨ乗") , l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ乘"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ乙") , l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ乚"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ乛"), l1llllll_l1_, l1l111_l1_ (u"ࠬ࠭乜"), headers, False,l1l111_l1_ (u"࠭ࠧ九"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ࠭乞"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ也"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ习"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ乡"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧ乢"),l1l111_l1_ (u"ࠬ࠵ࠧ乣"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨ乤"))
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ乥") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ书") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ乧"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ乨"))
			if name==l1l111_l1_ (u"ࠫࠬ乩"): l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬ࠭乪"),[l1l111_l1_ (u"࠭ࠧ乫")],[l1ll1ll_l1_]
			else: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ乬"),[l1l111_l1_ (u"ࠨࠩ乭")],[l1ll1ll_l1_]
		else: l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡏࡂࡏࠪ乮"),[],[]
		return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
def l11llllll11l_l1_(url):
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ乯") : l1l111_l1_ (u"ࠫࠬ买") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭乱"),headers,l1l111_l1_ (u"࠭ࠧ乲"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ乳"))
	items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ乴"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠩࠪ乵")
	if items:
		for l1ll1ll_l1_,l1llll1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1llll1ll1ll_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐࠩ乶"),[],[]
	return l1l111_l1_ (u"ࠫࠬ乷"),l1l1lll1_l1_,l1llll_l1_
def l1l111lll1ll_l1_(url):
	headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ乸"):l1l111_l1_ (u"࠭ࠧ乹")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ乺"),headers,l1l111_l1_ (u"ࠨࠩ乻"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ乼"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ乽"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ乾")+url
		return l1l111_l1_ (u"ࠬ࠭乿"),[l1l111_l1_ (u"࠭ࠧ亀")],[url]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡕࡑࡕࡁࡅࠩ亁"),[],[]
def l1l111l1l111_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠨ࠱ࠪ亂"))
	if l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ亃") in url: id = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ亄"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠫ࠴࠭亅"))[-1]
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩ了") + id
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ亇") : l1l111_l1_ (u"ࠧࠨ予") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ争"),headers,l1l111_l1_ (u"ࠩࠪ亊"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡄࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬ事"))
	html = html.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ二"),l1l111_l1_ (u"ࠬ࠭亍"))
	items = re.findall(l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭于"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ亏"),[l1l111_l1_ (u"ࠨࠩ亐")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭云"),[],[]
def l1l1111l111l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ互"),l1l111_l1_ (u"ࠫࠬ亓"),l1l111_l1_ (u"ࠬ࠭五"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡍࡉࡕ࡚ࡂ࠯࠴ࡷࡹ࠭井"))
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠢࡵࡩࡸࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ亖"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1llll1ll1ll_l1_,res in items:
		l1l1lll1_l1_.append(l1llll1ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࠪ亗")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡐ࡜ࡄࠫ亘"),[],[]
	return l1l111_l1_ (u"ࠪࠫ亙"),l1l1lll1_l1_,l1llll_l1_
def l1l11ll11l11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ亚"),l1l111_l1_ (u"ࠬ࠭些"),l1l111_l1_ (u"࠭ࠧ亜"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ亝"))
	items = re.findall(l1l111_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨ亞"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1llll1ll1ll_l1_,res in items:
		url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭亟")+id+l1l111_l1_ (u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ亠")+mode+l1l111_l1_ (u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ亡")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭亢"),l1l111_l1_ (u"࠭ࠧ亣"),l1l111_l1_ (u"ࠧࠨ交"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠴ࡱࡨࠬ亥"))
		items = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ亦"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1llll1ll1ll_l1_+l1l111_l1_ (u"ࠪࠤࠬ产")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑࠪ亨"),[],[]
	return l1l111_l1_ (u"ࠬ࠭亩"),l1l1lll1_l1_,l1llll_l1_
def l1l11111111l_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࠧ亪")
	if 1 or l1l111_l1_ (u"ࠧࡌࡧࡼࡁࠬ享") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ京"),l1l111_l1_ (u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭亭"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ亮"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠫ࠴࠭亯").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ亰"):id,l1l111_l1_ (u"࠭࡯ࡱࠩ亱"):l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ亲"),l1l111_l1_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭亳"):l1l111_l1_ (u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ亴")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ亵"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠫࠬ亶"),l1l111_l1_ (u"ࠬ࠭亷"),l1l111_l1_ (u"࠭ࠧ亸"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡙ࡕࡈࡏࡎ࠯࠴ࡷࡹ࠭亹"))
		if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ人") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ亻")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ亼"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ亽"),url,l1l111_l1_ (u"ࠬ࠭亾"),l1l111_l1_ (u"࠭ࠧ亿"),l1l111_l1_ (u"ࠧࠨ什"),l1l111_l1_ (u"ࠨࠩ仁"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ仂"))
		if l1l111_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ仃") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭仄")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠬ࠭仅"),[l1l111_l1_ (u"࠭ࠧ仆")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡔࡇࡕࡍࠨ仇"),[],[]
def l1l111ll1111_l1_(url):
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ仈") : l1l111_l1_ (u"ࠩࠪ仉") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ今"),headers,l1l111_l1_ (u"ࠫࠬ介"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡌࡍ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ仌"))
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧ࠮࠮ࠫࡁࠬࠦࠬ仍"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࠫ从"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭仏"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠩࠪ仐"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡉࡊࡘࡌࡈࡊࡕࠧ仑"),[],[]
def l11ll1ll1l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠫ࠴࠭仒"))[-1]
	id = id.split(l1l111_l1_ (u"ࠬࠬࠧ仓"))[0]
	id = id.replace(l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ仔"),l1l111_l1_ (u"ࠧࠨ仕"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ他")][0]+l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ仗")+id
	l1l11111l1l1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭付")+id
	l1l11ll1ll11_l1_,l1l11ll1l11l_l1_,l1l11l11lll1_l1_,l1l111ll1l11_l1_ = l1l111_l1_ (u"ࠫࠬ仙"),l1l111_l1_ (u"ࠬ࠭仚"),l1l111_l1_ (u"࠭ࠧ仛"),l1l111_l1_ (u"ࠧࠨ仜")
	for l1l111lll1_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ仝"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ仞"),l1l111_l1_ (u"ࠪࠫ仟"),l1l111_l1_ (u"ࠫࠬ仠"),l1l111_l1_ (u"ࠬ࠭仡"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ仢"))
		html = response.content
		if l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ代") in html: break
		time.sleep(2)
	l1l11llll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ令"),html,re.DOTALL)
	if l1l11llll1_l1_: l1l11llll1_l1_ = l1l11llll1_l1_[0]
	else: l1l11llll1_l1_ = html
	l1l11llll1_l1_ = l1l11llll1_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ以"),l1l111_l1_ (u"ࠪࠪࠬ仦"))
	l1l1l11111l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ仧"),l1l11llll1_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣฮึาๅสࠢํ์ฯ๐่ษࠩ仨")],[l1l111_l1_ (u"࠭ࠧ仩")]
	try:
		l1l1l11llll1_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩ仪")][l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ仫")][l1l111_l1_ (u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩ们")]
		for l1l11l1111ll_l1_ in l1l1l11llll1_l1_:
			l1ll1ll_l1_ = l1l11l1111ll_l1_[l1l111_l1_ (u"ࠪࡦࡦࡹࡥࡖࡴ࡯ࠫ仭")]
			try: title = l1l11l1111ll_l1_[l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ仮")][l1l111_l1_ (u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩ仯")]
			except: title = l1l11l1111ll_l1_[l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ仰")][l1l111_l1_ (u"ࠧࡳࡷࡱࡷࠬ仱")][0][l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠭仲")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆอีั๋ษࠡษ็้๋อำษห࠽ࠫ仳"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ仴"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠫࠫ࠭仵")
			l1l111ll11ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠬࠨࡧ࡯ࡷࡁ࠳࠰࠿ࠪࠨࠪ件"),l1ll1ll_l1_)
			if l1l111ll11ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111ll11ll_l1_[0],l1l111_l1_ (u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ价"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ仸")
			l1l11ll1ll11_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ仹"))
	formats,l1l1l11111ll_l1_,l11lllllll11_l1_,l11lllllll1l_l1_,l11llllll1ll_l1_ = [],[],[],[],[]
	try: l1l11ll1l11l_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ仺")][l1l111_l1_ (u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ任")]
	except: pass
	try: l1l11l11lll1_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ仼")][l1l111_l1_ (u"ࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭份")]
	except: pass
	try: formats = l1l1l11111l1_l1_[l1l111_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭仾")][l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ仿")]
	except: pass
	try: l1l1l11111ll_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ伀")][l1l111_l1_ (u"ࠩࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠫ企")]
	except: pass
	l1l11ll1l1l1_l1_ = formats+l1l1l11111ll_l1_
	for dict in l1l11ll1l1l1_l1_:
		if l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ伂") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ伃")] = str(dict[l1l111_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ伄")])
		if l1l111_l1_ (u"࠭ࡦࡱࡵࠪ伅") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡧࡲࡶࠫ伆")] = str(dict[l1l111_l1_ (u"ࠨࡨࡳࡷࠬ伇")])
		if l1l111_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ伈") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ伉")] = dict[l1l111_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭伊")]
		if l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ伋") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ伌")] = str(dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ伍")])
		if l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ伎") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ伏")] = str(dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ伐")])
		if l1l111_l1_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ休") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡹࡩࡻࡧࠪ伒")] = str(dict[l1l111_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ伓")])+l1l111_l1_ (u"ࠧࡹࠩ伔")+str(dict[l1l111_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ伕")])
		if l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ伖") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ众")] = dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ优")][l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ伙")]+l1l111_l1_ (u"࠭࠭ࠨ会")+dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ伛")][l1l111_l1_ (u"ࠨࡧࡱࡨࠬ伜")]
		if l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭伝") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ伞")] = dict[l1l111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ伟")][l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ传")]+l1l111_l1_ (u"࠭࠭ࠨ伡")+dict[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ伢")][l1l111_l1_ (u"ࠨࡧࡱࡨࠬ伣")]
		if l1l111_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ伤") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ伥")] = dict[l1l111_l1_ (u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬ伦")]
		if l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭伧") in list(dict.keys()) and int(dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ伨")])>111222333: del dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ伩")]
		if l1l111_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪ伪") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫ伫")].split(l1l111_l1_ (u"ࠪࠪࠬ伬"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭伭"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ伮") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ伯")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ估")])
		l11lllllll11_l1_.append(dict)
	l1l11ll1llll_l1_ = l1l111_l1_ (u"ࠨࠩ伱")
	if l1l111_l1_ (u"ࠩࡶࡴࡂࡹࡩࡨࠩ伲") in l1l11llll1_l1_:
		l1l11111l111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩ伳"),html,re.DOTALL)
		if l1l11111l111_l1_:
			l1l11111l111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ伴")][0]+l1l11111l111_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ伵"),l1l11111l111_l1_,l1l111_l1_ (u"࠭ࠧ伶"),l1l111_l1_ (u"ࠧࠨ伷"),l1l111_l1_ (u"ࠨࠩ伸"),l1l111_l1_ (u"ࠩࠪ伹"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠳ࡰࡧࠫ伺"))
			l1l11ll1llll_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11llll1l1l1_l1_ = cipher._load_javascript(l1l11ll1llll_l1_)
			l1l111llll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ伻"),str(l11llll1l1l1_l1_))
			l11llll1ll1l_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1l111llll1l_l1_)
	for dict in l11lllllll11_l1_:
		url = dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ似")]
		if l1l111_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠿ࠪ伽") in url or url.count(l1l111_l1_ (u"ࠧࡴ࡫ࡪࡁࠬ伾"))>1:
			l11lllllll1l_l1_.append(dict)
		elif l1l11ll1llll_l1_ and l1l111_l1_ (u"ࠨࡵࠪ伿") in list(dict.keys()) and l1l111_l1_ (u"ࠩࡶࡴࠬ佀") in list(dict.keys()):
			l1l11l111111_l1_ = l11llll1ll1l_l1_.execute(dict[l1l111_l1_ (u"ࠪࡷࠬ佁")])
			if l1l11l111111_l1_!=dict[l1l111_l1_ (u"ࠫࡸ࠭佂")]:
				dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ佃")] = url+l1l111_l1_ (u"࠭ࠦࠨ佄")+dict[l1l111_l1_ (u"ࠧࡴࡲࠪ佅")]+l1l111_l1_ (u"ࠨ࠿ࠪ但")+l1l11l111111_l1_
				l11lllllll1l_l1_.append(dict)
	for dict in l11lllllll1l_l1_:
		l111lll_l1_,l11lllll11ll_l1_,l1l1l11ll1l1_l1_,l1l1l1ll1_l1_,codecs,l11ll111l11_l1_ = l1l111_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ佇"),l1l111_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ佈"),l1l111_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ佉"),l1l111_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭佊"),l1l111_l1_ (u"࠭ࠧ佋"),l1l111_l1_ (u"ࠧ࠱ࠩ佌")
		try:
			l11llllllll1_l1_ = dict[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠭位")]
			l11llllllll1_l1_ = l11llllllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠮ࠫ低"),l1l111_l1_ (u"ࠪࠫ住"))
			items = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭佐"),l11llllllll1_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l11lll1l11_l1_ = codecs.split(l1l111_l1_ (u"ࠬ࠲ࠧ佑"))
			l11lllll11ll_l1_ = l1l111_l1_ (u"࠭ࠧ佒")
			for item in l1l11lll1l11_l1_: l11lllll11ll_l1_ += item.split(l1l111_l1_ (u"ࠧ࠯ࠩ体"))[0]+l1l111_l1_ (u"ࠨ࠮ࠪ佔")
			l11lllll11ll_l1_ = l11lllll11ll_l1_.strip(l1l111_l1_ (u"ࠩ࠯ࠫ何"))
			if l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ佖") in list(dict.keys()): l11ll111l11_l1_ = str(float(dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ佗")]*10)//1024/10)+l1l111_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ佘")
			else: l11ll111l11_l1_ = l1l111_l1_ (u"࠭ࠧ余")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠧࡵࡧࡻࡸࠬ佚"): continue
			elif l1l111_l1_ (u"ࠨ࠮ࠪ佛") in l11llllllll1_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠩࡄ࠯࡛࠭作")
				l1l1l11ll1l1_l1_ = l111lll_l1_+l1l111_l1_ (u"ࠪࠤࠥ࠭佝")+l11ll111l11_l1_+dict[l1l111_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ佞")].split(l1l111_l1_ (u"ࠬࡾࠧ佟"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ你"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭佡")
				l1l1l11ll1l1_l1_ = l11ll111l11_l1_+dict[l1l111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭佢")].split(l1l111_l1_ (u"ࠩࡻࠫ佣"))[1]+l1l111_l1_ (u"ࠪࠤࠥ࠭佤")+dict[l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ佥")]+l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ佦")+l1l111_l1_ (u"࠭ࠠࠡࠩ佧")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭佨"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ佩")
				l1l1l11ll1l1_l1_ = l11ll111l11_l1_+str(int(dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭佪")])/1000)+l1l111_l1_ (u"ࠪ࡯࡭ࢀࠠࠡࠩ佫")+dict[l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ佬")]+l1l111_l1_ (u"ࠬࡩࡨࠨ佭")+l1l111_l1_ (u"࠭ࠠࠡࠩ佮")+l111lll_l1_
		except:
			l111l111lll_l1_ = traceback.format_exc()
			if l111l111lll_l1_!=l1l111_l1_ (u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪ佯"): sys.stderr.write(l111l111lll_l1_)
		if l1l111_l1_ (u"ࠨࡦࡸࡶࡂ࠭佰") in dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭佱")]: l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ佲")].split(l1l111_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ佳"),1)[1].split(l1l111_l1_ (u"ࠬࠬࠧ佴"),1)[0]))
		elif l1l111_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ併") in list(dict.keys()): l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ佶")])/1000)
		else: l1l1lll111_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ佷")
		if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ佸") not in list(dict.keys()): l11ll111l11_l1_ = dict[l1l111_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ佹")].split(l1l111_l1_ (u"ࠫࡽ࠭佺"))[1]
		else: l11ll111l11_l1_ = dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佻")]
		if l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ佼") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ佽")] = l1l111_l1_ (u"ࠨ࠲࠰࠴ࠬ佾")
		dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ使")] = l1l1l1ll1_l1_+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ侀")+l1l1l11ll1l1_l1_+l1l111_l1_ (u"ࠫࠥࠦࠨࠨ侁")+l11lllll11ll_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ侂")+dict[l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ侃")]+l1l111_l1_ (u"ࠧࠪࠩ侄")
		dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ侅")] = l1l1l11ll1l1_l1_.split(l1l111_l1_ (u"ࠩࠣࠤࠬ來"))[0].split(l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ侇"))[0]
		dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ侈")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ侉")] = l111lll_l1_
		dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭侊")] = codecs
		dict[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ例")] = l1l1lll111_l1_
		dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ侌")] = l11ll111l11_l1_
		l11llllll1ll_l1_.append(dict)
	l1l11ll11l1l_l1_,l1l111ll111l_l1_,l1l1l11l1111_l1_,l1l1l11l1ll1_l1_,l11lll1ll1ll_l1_ = [],[],[],[],[]
	l1l11lll1l1l_l1_,l1l11111l11l_l1_,l1l111l11lll_l1_,l1l11lll11l1_l1_,l1l1l111l11l_l1_ = [],[],[],[],[]
	if l1l11ll1l11l_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ侍")] = l1l111_l1_ (u"ࠪࡅ࠰࡜ࠧ侎")
		dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭侏")] = l1l111_l1_ (u"ࠬࡳࡰࡥࠩ侐")
		dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侑")] = dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭侒")]+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ侓")+dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ侔")]+l1l111_l1_ (u"ࠪࠤࠥ࠭侕")+l1l111_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ侖")
		dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ侗")] = l1l11ll1l11l_l1_
		dict[l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ侘")] = l1l111_l1_ (u"ࠧ࠱ࠩ侙")
		dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ侚")] = l1l111_l1_ (u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭供")
		l11llllll1ll_l1_.append(dict)
	if l1l11l11lll1_l1_:
		l1l11llll1ll_l1_,l1l111l1111l_l1_ = l1l11l11l1_l1_(l1l11l11lll1_l1_)
		l1l11l11l1l1_l1_ = list(zip(l1l11llll1ll_l1_,l1l111l1111l_l1_))
		for title,l1ll1ll_l1_ in l1l11l11l1l1_l1_:
			dict = {}
			dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ侜")] = l1l111_l1_ (u"ࠫࡆ࠱ࡖࠨ依")
			dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ侞")] = l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ侟")
			dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ侠")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭価") in title: dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ侢")] = title.split(l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ侣"))[0].rsplit(l1l111_l1_ (u"ࠫࠥࠦࠧ侤"))[-1]
			else: dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭侥")] = l1l111_l1_ (u"࠭࠱࠱ࠩ侦")
			if title.count(l1l111_l1_ (u"ࠧࠡࠢࠪ侧"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠨࠢࠣࠫ侨"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ侩")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ侪")] = l1l111_l1_ (u"ࠫ࠵࠶࠰࠱ࠩ侫")
			if title==l1l111_l1_ (u"ࠬ࠳࠱ࠨ侬"): dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ侭")] = dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭侮")]+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ侯")+dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ侰")]+l1l111_l1_ (u"ࠪࠤࠥ࠭侱")+l1l111_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ侲")
			else: dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ侳")] = dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ侴")]+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ侵")+dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ侶")]+l1l111_l1_ (u"ࠩࠣࠤࠬ侷")+dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ侸")]+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ侹")+dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭侺")]
			l11llllll1ll_l1_.append(dict)
	l11llllll1ll_l1_ = sorted(l11llllll1ll_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ侻")]))
	if not l11llllll1ll_l1_:
		l1lll1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ侼"),html,re.DOTALL)
		l1lll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ侽"),html,re.DOTALL)
		l1l11ll11111_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ侾"),html,re.DOTALL)
		l1l11ll1111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ便"),html,re.DOTALL)
		try: l1l11ll111l1_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ俀")][l1l111_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ俁")][l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ係")][l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭促")][l1l111_l1_ (u"ࠨࡴࡸࡲࡸ࠭俄")][0][l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ俅")]
		except: l1l11ll111l1_l1_ = l1l111_l1_ (u"ࠪࠫ俆")
		try: l1l11ll111ll_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ俇")][l1l111_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ俈")][l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ俉")][l1l111_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨ俊")][0][l1l111_l1_ (u"ࠨࡴࡸࡲࡸ࠭俋")][0][l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ俌")]
		except: l1l11ll111ll_l1_ = l1l111_l1_ (u"ࠪࠫ俍")
		try: l11llll1l1ll_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ俎")][l1l111_l1_ (u"ࠬࡸࡥࡢࡵࡲࡲࠬ俏")]
		except: l11llll1l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ俐")
		if l1lll1l1lll_l1_ or l1lll1ll111_l1_ or l1l11ll11111_l1_ or l1l11ll1111l_l1_ or l1l11ll111l1_l1_ or l1l11ll111ll_l1_ or l11llll1l1ll_l1_:
			if   l1lll1l1lll_l1_: message = l1lll1l1lll_l1_[0]
			elif l1lll1ll111_l1_: message = l1lll1ll111_l1_[0]
			elif l1l11ll11111_l1_: message = l1l11ll11111_l1_[0]
			elif l1l11ll1111l_l1_: message = l1l11ll1111l_l1_[0]
			elif l1l11ll111l1_l1_: message = l1l11ll111l1_l1_
			elif l1l11ll111ll_l1_: message = l1l11ll111ll_l1_
			elif l11llll1l1ll_l1_: message = l11llll1l1ll_l1_
			l1l1l11ll111_l1_ = message.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ俑"),l1l111_l1_ (u"ࠨࠩ俒")).strip(l1l111_l1_ (u"ࠩࠣࠫ俓"))
			l1l1l11l1lll_l1_ = l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ่ࠦใัࠣ๎่๎ๆࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่࡞࠳ࡈࡕࡌࡐࡔࡠࠫ俔")
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ俕"),l1l111_l1_ (u"ࠬ࠭俖"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่๊ࠡส่๊ฮัๆฮࠪ俗"),l1l1l11l1lll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ俘")+l1l1l11ll111_l1_)
			return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠪ俙")+l1l1l11ll111_l1_,[],[]
		else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ俚"),[],[]
	l11lllll1l11_l1_,l11lllll1l1l_l1_,l1l111ll1ll1_l1_ = [],[],[]
	for dict in l11llllll1ll_l1_:
		if dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ俛")]==l1l111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ俜"):
			l1l11ll11l1l_l1_.append(dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ保")])
			l1l11lll1l1l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ俞")]==l1l111_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭俟"):
			l1l111ll111l_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ俠")])
			l1l11111l11l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ信")]==l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俢"):
			title = dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ俣")].replace(l1l111_l1_ (u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ俤"),l1l111_l1_ (u"࠭ࠧ俥"))
			if l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ俦") not in list(dict.keys()): l11ll111l11_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ俧")
			else: l11ll111l11_l1_ = dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ俨")]
			l11lllll1l11_l1_.append([dict,{},title,l11ll111l11_l1_])
		else:
			title = dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ俩")].replace(l1l111_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ俪"),l1l111_l1_ (u"ࠬ࠭俫"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ俬") not in list(dict.keys()): l11ll111l11_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ俭")
			else: l11ll111l11_l1_ = dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ修")]
			l11lllll1l11_l1_.append([dict,{},title,l11ll111l11_l1_])
			l1l1l11l1111_l1_.append(title)
			l1l111l11lll_l1_.append(dict)
		l1l11l1l11ll_l1_ = True
		if l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ俯") in list(dict.keys()):
			if l1l111_l1_ (u"ࠪࡥࡻ࠶ࠧ俰") in dict[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ俱")]: l1l11l1l11ll_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠬࡧࡶࡤࠩ俲") not in dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭俳")] and l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࡥࠬ俴") not in dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ俵")]: l1l11l1l11ll_l1_ = False
		if dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ俶")]==l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ俷") and dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ俸")]!=l1l111_l1_ (u"ࠬ࠶࠭࠱ࠩ俹") and l1l11l1l11ll_l1_==True:
			l11lll1ll1ll_l1_.append(dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ俺")])
			l1l1l111l11l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭俻")]==l1l111_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ俼") and dict[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ俽")]!=l1l111_l1_ (u"ࠪ࠴࠲࠶ࠧ俾") and l1l11l1l11ll_l1_==True:
			l1l1l11l1ll1_l1_.append(dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ俿")])
			l1l11lll11l1_l1_.append(dict)
	for l1l11l1l1111_l1_ in l1l11lll11l1_l1_:
		l1l111111lll_l1_ = l1l11l1l1111_l1_[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭倀")]
		for l1l11l1llll1_l1_ in l1l1l111l11l_l1_:
			l1l1l1l111l1_l1_ = l1l11l1llll1_l1_[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ倁")]
			l11ll111l11_l1_ = l1l1l1l111l1_l1_+l1l111111lll_l1_
			title = l1l11l1llll1_l1_[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭倂")].replace(l1l111_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪ倃"),l1l111_l1_ (u"ࠩࡰࡴࡩࠦࠠࠨ倄"))
			title = title.replace(l1l11l1llll1_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ倅")]+l1l111_l1_ (u"ࠫࠥࠦࠧ倆"),l1l111_l1_ (u"ࠬ࠭倇"))
			title = title.replace(str((float(l1l1l1l111l1_l1_*10)//1024/10))+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ倈"),str((float(l11ll111l11_l1_*10)//1024/10))+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ倉"))
			title = title+l1l111_l1_ (u"ࠨࠪࠪ倊")+l1l11l1l1111_l1_[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ個")].split(l1l111_l1_ (u"ࠪࠬࠬ倌"),1)[1]
			l11lllll1l11_l1_.append([l1l11l1llll1_l1_,l1l11l1l1111_l1_,title,l11ll111l11_l1_])
	l11lllll1l11_l1_ = sorted(l11lllll1l11_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l11l1llll1_l1_,l1l11l1l1111_l1_,title,l11ll111l11_l1_ in l11lllll1l11_l1_:
		l11llllll111_l1_ = l1l11l1llll1_l1_[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭倍")]
		if l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ倎") in list(l1l11l1l1111_l1_.keys()):
			l11llllll111_l1_ = l1l111_l1_ (u"࠭࡭ࡱࡦࠪ倏")
		if l11llllll111_l1_ not in l1l111ll1ll1_l1_:
			l1l111ll1ll1_l1_.append(l11llllll111_l1_)
			l11lllll1l1l_l1_.append([l1l11l1llll1_l1_,l1l11l1l1111_l1_,title,l11ll111l11_l1_])
	l1l11l11111l_l1_,l1l11lllll1l_l1_,shift = [],[],0
	l1l11l1l1lll_l1_,l1l1l111l111_l1_ = l1l111_l1_ (u"ࠧࠨ倐"),l1l111_l1_ (u"ࠨࠩ們")
	try: l1l11l1l1lll_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ倒")][l1l111_l1_ (u"ࠪࡥࡺࡺࡨࡰࡴࠪ倓")]
	except: l1l11l1l1lll_l1_ = l1l111_l1_ (u"ࠫࠬ倔")
	try: l1l111l1ll11_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ倕")][l1l111_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ倖")]
	except: l1l111l1ll11_l1_ = l1l111_l1_ (u"ࠧࠨ倗")
	if l1l11l1l1lll_l1_ and l1l111l1ll11_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ倘")+l1l11l1l1lll_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ候")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ倚")][0]+l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ倛")+l1l111l1ll11_l1_
		l1l11l11111l_l1_.append(title)
		l1l11lllll1l_l1_.append(l1ll1ll_l1_)
		try: l1l1l111l111_l1_ = l1l1l11111l1_l1_[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ倜")][l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ倝")][l1l111_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫ倞")][-1][l1l111_l1_ (u"ࠨࡷࡵࡰࠬ借")]
		except: pass
	for l1l11l1llll1_l1_,l1l11l1l1111_l1_,title,l11ll111l11_l1_ in l11lllll1l1l_l1_:
		l1l11l11111l_l1_.append(title) ; l1l11lllll1l_l1_.append(l1l111_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ倠"))
	if l1l1l11l1111_l1_: l1l11l11111l_l1_.append(l1l111_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬ倡")) ; l1l11lllll1l_l1_.append(l1l111_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ倢"))
	if l11lllll1l11_l1_: l1l11l11111l_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩ倣")) ; l1l11lllll1l_l1_.append(l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ値"))
	if l11lll1ll1ll_l1_: l1l11l11111l_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲࡧࠤฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ倥")) ; l1l11lllll1l_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ倦"))
	if l1l11ll11l1l_l1_: l1l11l11111l_l1_.append(l1l111_l1_ (u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩ倧")) ; l1l11lllll1l_l1_.append(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ倨"))
	if l1l111ll111l_l1_: l1l11l11111l_l1_.append(l1l111_l1_ (u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫ倩")) ; l1l11lllll1l_l1_.append(l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ倪"))
	l1l1l11l1l11_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l1l11111l1l1_l1_, l1l11l11111l_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠭倫"),[],[]
		elif l11l11l_l1_==0 and l1l11l1l1lll_l1_:
			l1ll1ll_l1_ = l1l11lllll1l_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ倬")+QUOTE(l1l11l1l1lll_l1_)+l1l111_l1_ (u"ࠨࠨࡸࡶࡱࡃࠧ倭")+l1ll1ll_l1_
			if l1l1l111l111_l1_: new_path = new_path+l1l111_l1_ (u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪ倮")+QUOTE(l1l1l111l111_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ倯")+new_path+l1l111_l1_ (u"ࠦ࠮ࠨ倰"))
			return l1l111_l1_ (u"ࠬࡋࡘࡊࡖࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ倱"),[],[]
		choice = l1l11lllll1l_l1_[l11l11l_l1_]
		l11llll11ll1_l1_ = l1l11l11111l_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ倲"):
			l1l111ll1l11_l1_ = l1l11ll1l11l_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭倳"),l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ倴"),l1l111_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ倵")]:
			if choice==l1l111_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ倶"): l1l1lll1_l1_,l1l11l1ll1ll_l1_ = l1l1l11l1111_l1_,l1l111l11lll_l1_
			elif choice==l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ倷"): l1l1lll1_l1_,l1l11l1ll1ll_l1_ = l1l11ll11l1l_l1_,l1l11lll1l1l_l1_
			elif choice==l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ倸"): l1l1lll1_l1_,l1l11l1ll1ll_l1_ = l1l111ll111l_l1_,l1l11111l11l_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ倹"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l1l111ll1l11_l1_ = l1l11l1ll1ll_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ债")]
				l11llll11ll1_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ倻"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอ࠿࠭值"), l11lll1ll1ll_l1_)
			if l11l11l_l1_!=-1:
				l11llll11ll1_l1_ = l11lll1ll1ll_l1_[l11l11l_l1_]
				l11llll1ll11_l1_ = l1l1l111l11l_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ฮ࠿࠭倽"), l1l1l11l1ll1_l1_)
				if l11l11l_l1_!=-1:
					l11llll11ll1_l1_ += l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ倾")+l1l1l11l1ll1_l1_[l11l11l_l1_]
					l1l11l1111l1_l1_ = l1l11lll11l1_l1_[l11l11l_l1_]
					l1l1l11l1l11_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ倿"):
			l1l1111l1l1l_l1_,l11lll1l1ll1_l1_,l11lllllllll_l1_,l1l1l11l111l_l1_ = list(zip(*l11lllll1l11_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ偀"), l11lllllllll_l1_)
			if l11l11l_l1_!=-1:
				l11llll11ll1_l1_ = l11lllllllll_l1_[l11l11l_l1_]
				l11llll1ll11_l1_ = l1l1111l1l1l_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ偁") in l11lllllllll_l1_[l11l11l_l1_] and l11llll1ll11_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ偂")]!=l1l11ll1l11l_l1_:
					l1l11l1111l1_l1_ = l11lll1l1ll1_l1_[l11l11l_l1_]
					l1l1l11l1l11_l1_ = True
				else: l1l111ll1l11_l1_ = l11llll1ll11_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭偃")]
				break
		elif choice==l1l111_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ偄"):
			l1l1111l1l1l_l1_,l11lll1l1ll1_l1_,l11lllllllll_l1_,l1l1l11l111l_l1_ = list(zip(*l11lllll1l1l_l1_))
			l11llll1ll11_l1_ = l1l1111l1l1l_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"ࠫࡲࡶࡤࠨ偅") in l11lllllllll_l1_[l11l11l_l1_-shift] and l11llll1ll11_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ偆")]!=l1l11ll1l11l_l1_:
				l1l11l1111l1_l1_ = l11lll1l1ll1_l1_[l11l11l_l1_-shift]
				l1l1l11l1l11_l1_ = True
			else: l1l111ll1l11_l1_ = l11llll1ll11_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ假")]
			l11llll11ll1_l1_ = l11lllllllll_l1_[l11l11l_l1_-shift]
			break
	if not l1l1l11l1l11_l1_: l1l111l111ll_l1_ = l1l111ll1l11_l1_
	else: l1l111l111ll_l1_ = l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠨ偈")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ偉")]+l1l111_l1_ (u"ࠩࠣ࠯ࠥࡇࡵࡥ࡫ࡲ࠾ࠥ࠭偊")+l1l11l1111l1_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ偋")]
	if l1l1l11l1l11_l1_:
		l1l1l1111lll_l1_ = int(l11llll1ll11_l1_[l1l111_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭偌")])
		l1l111l1l1ll_l1_ = int(l1l11l1111l1_l1_[l1l111_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ偍")])
		l1l1lll111_l1_ = str(max(l1l1l1111lll_l1_,l1l111l1l1ll_l1_))
		l1l111111ll1_l1_ = l11llll1ll11_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ偎")].replace(l1l111_l1_ (u"ࠧࠧࠩ偏"),l1l111_l1_ (u"ࠨࠨࡤࡱࡵࡁࠧ偐"))
		l1l111ll11l1_l1_ = l1l11l1111l1_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭偑")].replace(l1l111_l1_ (u"ࠪࠪࠬ偒"),l1l111_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ偓"))
		l1l1l111ll1l_l1_ = l1l111_l1_ (u"ࠬࡂ࠿ࡹ࡯࡯ࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨ࠱࠯࠲ࠥࠤࡪࡴࡣࡰࡦ࡬ࡲ࡬ࡃࠢࡖࡖࡉ࠱࠽ࠨ࠿࠿࡞ࡱࠫ偔")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"࠭࠼ࡎࡒࡇࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡸ࡯࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠸࠰࠱࠳࠲࡜ࡒࡒࡓࡤࡪࡨࡱࡦ࠳ࡩ࡯ࡵࡷࡥࡳࡩࡥࠣࠢࡻࡱࡱࡴࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠦࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡲࡩ࡯࡭ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠳࠼࠽࠾࠵ࡸ࡭࡫ࡱ࡯ࠧࠦࡸࡴ࡫࠽ࡷࡨ࡮ࡥ࡮ࡣࡏࡳࡨࡧࡴࡪࡱࡱࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠠࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡲࡩࡧࡲࡥࡵ࠱࡭ࡸࡵ࠮ࡰࡴࡪ࠳࡮ࡺࡴࡧ࠱ࡓࡹࡧࡲࡩࡤ࡮ࡼࡅࡻࡧࡩ࡭ࡣࡥࡰࡪ࡙ࡴࡢࡰࡧࡥࡷࡪࡳ࠰ࡏࡓࡉࡌ࠳ࡄࡂࡕࡋࡣࡸࡩࡨࡦ࡯ࡤࡣ࡫࡯࡬ࡦࡵ࠲ࡈࡆ࡙ࡈ࠮ࡏࡓࡈ࠳ࡾࡳࡥࠤࠣࡱ࡮ࡴࡂࡶࡨࡩࡩࡷ࡚ࡩ࡮ࡧࡀࠦࡕ࡚࠱࠯࠷ࡖࠦࠥࡳࡥࡥ࡫ࡤࡔࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡆࡸࡶࡦࡺࡩࡰࡰࡀࠦࡕ࡚ࠧ偕")+l1l1lll111_l1_+l1l111_l1_ (u"ࠧࡔࠤࠣࡸࡾࡶࡥ࠾ࠤࡶࡸࡦࡺࡩࡤࠤࠣࡴࡷࡵࡦࡪ࡮ࡨࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡰࡳࡱࡩ࡭ࡱ࡫࠺ࡪࡵࡲࡪ࡫࠳࡭ࡢ࡫ࡱ࠾࠷࠶࠱࠲ࠤࡁࡠࡳ࠭偖")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ偗")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠱ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡶࡪࡦࡨࡳ࠴࠭偘")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ偙")]+l1l111_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ做")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ偛")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭停")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ偝")]+l1l111_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ偞")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ偟")]+l1l111_l1_ (u"ࠪࠦࠥࡹࡴࡢࡴࡷ࡛࡮ࡺࡨࡔࡃࡓࡁࠧ࠷ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠭偠")+str(l11llll1ll11_l1_[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ偡")])+l1l111_l1_ (u"ࠬࠨࠠࡸ࡫ࡧࡸ࡭ࡃࠢࠨ偢")+str(l11llll1ll11_l1_[l1l111_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ偣")])+l1l111_l1_ (u"ࠧࠣࠢ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠫ偤")+str(l11llll1ll11_l1_[l1l111_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ健")])+l1l111_l1_ (u"ࠩࠥࠤ࡫ࡸࡡ࡮ࡧࡕࡥࡹ࡫࠽ࠣࠩ偦")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ偧")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ偨")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ偩")+l1l111111ll1_l1_+l1l111_l1_ (u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ偪")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ偫")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ偬")]+l1l111_l1_ (u"ࠩࠥࡂࡡࡴࠧ偭")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭偮")+l11llll1ll11_l1_[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ偯")]+l1l111_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ偰")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ偱")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭偲")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭偳")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠲ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡡࡶࡦ࡬ࡳ࠴࠭側")+l1l11l1111l1_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ偵")]+l1l111_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ偶")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ偷")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭偸")+l1l11l1111l1_l1_[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ偹")]+l1l111_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ偺")+l1l11l1111l1_l1_[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ偻")]+l1l111_l1_ (u"ࠪࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤ࠴࠷࠵࠺࠷࠶ࠤࡁࡠࡳ࠭偼")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡇࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼࠵࠷࠵࠶࠳࠻࠵࠽ࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢࡧࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠪ偽")+l1l11l1111l1_l1_[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭偾")]+l1l111_l1_ (u"࠭ࠢ࠰ࡀ࡟ࡲࠬ偿")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ傀")+l1l111ll11l1_l1_+l1l111_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ傁")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ傂")+l1l11l1111l1_l1_[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ傃")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ傄")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ傅")+l1l11l1111l1_l1_[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ傆")]+l1l111_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ傇")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ傈")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ傉")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ傊")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ傋")
		l1l1l111ll1l_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡎࡒࡇࡂࡡࡴࠧ傌")
		if PY3:
			import http.server as l1l111ll1l1l_l1_
			import http.client as l1l111lllll1_l1_
		else:
			import BaseHTTPServer as l1l111ll1l1l_l1_
			import httplib as l1l111lllll1_l1_
		class l1l11l1lll11_l1_(l1l111ll1l1l_l1_.HTTPServer):
			def __init__(self,l1lll11lllll_l1_=l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵࠩ傍"),port=55055,l1l1l111ll1l_l1_=l1l111_l1_ (u"ࠧ࠽ࡀࠪ傎")):
				self.l1lll11lllll_l1_ = l1lll11lllll_l1_
				self.port = port
				self.l1l1l111ll1l_l1_ = l1l1l111ll1l_l1_
				l1l111ll1l1l_l1_.HTTPServer.__init__(self,(self.l1lll11lllll_l1_,self.port),l1l1l111l1ll_l1_)
				self.l1l11l11ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ傏")+l1lll11lllll_l1_+l1l111_l1_ (u"ࠩ࠽ࠫ傐")+str(port)+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ傑")
			def start(self):
				self.threads = l11l11l1l11_l1_(False)
				self.threads.start_new_thread(1,self.l1l1111lllll_l1_)
			def l1l1111lllll_l1_(self):
				self.l11llll1lll1_l1_ = True
				while self.l11llll1lll1_l1_:
					self.handle_request()
			def stop(self):
				self.l11llll1lll1_l1_ = False
				self.l1l11l1ll1l1_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l1l111ll1l_l1_):
				self.l1l1l111ll1l_l1_ = l1l1l111ll1l_l1_
			def l1l11l1ll1l1_l1_(self):
				conn = l1l111lllll1_l1_.HTTPConnection(self.l1lll11lllll_l1_+l1l111_l1_ (u"ࠫ࠿࠭傒")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠧࡎࡅࡂࡆࠥ傓"), l1l111_l1_ (u"ࠨ࠯ࠣ傔"))
		class l1l1l111l1ll_l1_(l1l111ll1l1l_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭傕"),l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬ傖"))
				self.end_headers()
				self.wfile.write(self.server.l1l1l111ll1l_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ傗")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ傘"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ備"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l11l1lll11_l1_(l1l111_l1_ (u"ࠬ࠷࠲࠸࠰࠳࠲࠵࠴࠱ࠨ傚"),55055,l1l1l111ll1l_l1_)
		l1l111ll1l11_l1_ = httpd.l1l11l11ll1l_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"࠭ࠧ傛")
	if not l1l111ll1l11_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧ傜"),[],[]
	return l1l111_l1_ (u"ࠨࠩ傝"),[l1l111_l1_ (u"ࠩࠪ傞")],[[l1l111ll1l11_l1_,l1l11ll1ll11_l1_,httpd]]
def l1l11l11l1ll_l1_(url):
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ傟") : l1l111_l1_ (u"ࠫࠬ傠") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭傡"),headers,l1l111_l1_ (u"࠭ࠧ傢"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ傣"))
	items = re.findall(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ傤"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l11llll1ll_l1_,l1l1lll1_l1_,l1l111l1111l_l1_,l1llll_l1_ = [],[],[],[]
	if not items: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ傥"),[],[]
	for l1ll1ll_l1_,dummy,l1llll1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ傦"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ傧"))
		if l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ储") in l1ll1ll_l1_:
			l1l11llll1ll_l1_,l1l111l1111l_l1_ = l1l11l11l1_l1_(l1ll1ll_l1_)
			l1llll_l1_ = l1llll_l1_ + l1l111l1111l_l1_
			if l1l11llll1ll_l1_[0]==l1l111_l1_ (u"࠭࠭࠲ࠩ傩"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧิ์ิๅึࠦฮศืࠪ傪")+l1l111_l1_ (u"ࠨࠢࠣࠤࡲ࠹ࡵ࠹ࠩ傫"))
			else:
				for title in l1l11llll1ll_l1_:
					l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ催")+l1l111_l1_ (u"ࠪࠤࠥࠦࠧ傭")+title)
		else:
			title = l1l111_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ傮")+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡳ࠸ࠥࠦࠠࠨ傯")+l1llll1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	return l1l111_l1_ (u"࠭ࠧ傰"),l1l1lll1_l1_,l1llll_l1_
def l1l111l11l1l_l1_(url,html):
	l111lll1ll_l1_,l1ll11l1_l1_,l11llll1l11l_l1_,l1llll1ll1l_l1_,l1ll_l1_ = [],[],[],[],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ傱"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ傲"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ傳"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠪ࠲ࠬ傴"),1)[1]
		l111lll1ll_l1_.append(title)
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	else:
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦࠪࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠪ債"),html,re.DOTALL)
		if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡶࡳࡺࡸࡣࡦࡵࠣࡁࠥ࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩࠨ傶"),html,re.DOTALL)
		if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣ࡮ࡼࠦ࠽ࠡࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࠫ傷"),html,re.DOTALL)
		if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡵࡲࡡࡺࡧࡵࠤࡂࠦ࠮ࠫࡁ࡟ࠬ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯࡜ࠪࠩ傸"),html,re.DOTALL)
		if l1lll1l1_l1_:
			l1lll1l1_l1_ = l1lll1l1_l1_[0]
			l1l11ll1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡝࠯ࡠࢀࡣࠠࠫࠪ࡟ࡻ࠰࠯࠺ࠨ傹"),l1lll1l1_l1_,re.DOTALL)
			for key in list(set(l1l11ll1ll1l_l1_)): l1lll1l1_l1_ = l1lll1l1_l1_.replace(key+l1l111_l1_ (u"ࠩ࠽ࠫ傺"),l1l111_l1_ (u"ࠪࠦࠬ傻")+key+l1l111_l1_ (u"ࠫࠧࡀࠧ傼"))
			l1lll1l1_l1_ = eval(l1lll1l1_l1_)
			if isinstance(l1lll1l1_l1_,dict): l1lll1l1_l1_ = [l1lll1l1_l1_]
			for block in l1lll1l1_l1_:
				if isinstance(block,dict):
					keys = list(block.keys())
					if l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠪ傽") in keys: l1ll1ll_l1_ = block[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࠫ傾")]
					elif l1l111_l1_ (u"ࠧࡩ࡮ࡶࠫ傿") in keys: l1ll1ll_l1_ = block[l1l111_l1_ (u"ࠨࡪ࡯ࡷࠬ僀")]
					if l1l111_l1_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ僁") in keys: title = str(block[l1l111_l1_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ僂")])
					elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡢ࡬ࡪ࡯ࡧࡩࡶࠪ僃") in keys: title = str(block[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡣ࡭࡫ࡩࡨࡪࡷࠫ僄")])
					else: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"࠭࠮ࠨ僅"),1)[1]
				elif isinstance(block,str):
					l1ll1ll_l1_ = block
					title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠧ࠯ࠩ僆"),1)[1]
				l111lll1ll_l1_.append(title)
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	for l1ll1ll_l1_,title in zip(l1ll11l1_l1_,l111lll1ll_l1_):
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟࠳ࠬ僇"),l1l111_l1_ (u"ࠩ࠲ࠫ僈"))
		l11lll1ll1_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ僉"))
		l11ll1l1l1_l1_ = l1l1ll11l_l1_()
		if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ僊") in l1ll1ll_l1_:
			headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ僋"):l11ll1l1l1_l1_,l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ僌"):l11lll1ll1_l1_}
			l11llll1l111_l1_,l1l11l111l1l_l1_ = l1l11l11l1_l1_(l1ll1ll_l1_,headers)
			l1llll1ll1l_l1_ += l1l11l111l1l_l1_
			l11llll1l11l_l1_ += l11llll1l111_l1_
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭働")+l11ll1l1l1_l1_+l1l111_l1_ (u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ僎")+l11lll1ll1_l1_
			l1llll1ll1l_l1_.append(l1ll1ll_l1_)
			l11llll1l11l_l1_.append(title)
	l1l1l1111111_l1_,l111lll1ll_l1_,l1ll11l1_l1_ = l1l111_l1_ (u"ࠩࠪ像"),[],[]
	if l1llll1ll1l_l1_: l1l1l1111111_l1_,l111lll1ll_l1_,l1ll11l1_l1_ = l1l111_l1_ (u"ࠪࠫ僐"),l11llll1l11l_l1_,l1llll1ll1l_l1_
	else:
		if l1l111_l1_ (u"ࠫࡁ࠭僑") not in html and len(html)<100 and html: l1l1l1111111_l1_ = html
		else:
			msg = re.findall(l1l111_l1_ (u"ࠬࡂࡤࡪࡸࠣࡷࡹࡿ࡬ࡦ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪࡉ࡭ࡱ࡫࠮ࠫࡁࠬࡀࠬ僒"),html,re.DOTALL)
			if not msg: msg = re.findall(l1l111_l1_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡻࡶ࡟ࡷ࡫ࡧࡩࡴࡥࡳࡵࡷࡥࡣࡹࡾࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ僓"),html,re.DOTALL)
			if not msg: msg = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠵ࡂ࡙࠭࡯ࡳࡴࡼ࠲࠯ࡅࠩ࠽ࠩ僔"),html,re.DOTALL)
			if msg: l1l1l1111111_l1_ = msg[0]
	return l1l1l1111111_l1_,l111lll1ll_l1_,l1ll11l1_l1_
def l1l1l1l111ll_l1_(l1l11lll1lll_l1_,url):
	global l1l1l1111ll1_l1_
	url = url.strip(l1l111_l1_ (u"ࠨ࠱ࠪ僕"))
	l1lll1111lll_l1_,payload = l1l111_l1_ (u"ࠩࠪ僖"),{}
	headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ僗"):l1l1ll11l_l1_(),l1l111_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭僘"):l1l111_l1_ (u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠾࠭僙")}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ僚"),url,l1l111_l1_ (u"ࠧࠨ僛"),headers,l1l111_l1_ (u"ࠨࠩ僜"),False,l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ僝"))
	html = response.content
	l11lll1lll11_l1_ = response.code
	if not isinstance(html,str): html = html.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ僞"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ僟"))
	if l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࠫ僠") in html:
		l11111ll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡡࡤࡳ࡟࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ僡"),html,re.DOTALL)
		if l11111ll1l1_l1_:
			try: l1lll1111lll_l1_ = l1lll1l11l1l_l1_(l11111ll1l1_l1_[0])
			except: l1lll1111lll_l1_ = l1l111_l1_ (u"ࠧࠨ僢")
	l11l1ll1_l1_ = html+l1lll1111lll_l1_
	if l1l111_l1_ (u"ࠨࠤ࡬ࡨ࠷ࠨࠧ僣") in l11l1ll1_l1_ or l1l111_l1_ (u"ࠩࠥ࡭ࡩࠨࠧ僤") in l11l1ll1_l1_:
		l1l1l11lllll_l1_ = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ僥"))[3].replace(l1l111_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ僦"),l1l111_l1_ (u"ࠬ࠭僧")).replace(l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ僨"),l1l111_l1_ (u"ࠧࠨ僩"))
		if l1l111_l1_ (u"ࠨࠤ࡬ࡨ࠷ࠨࠧ僪") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠩ࡬ࡨ࠷࠭僫"):l1l1l11lllll_l1_,l1l111_l1_ (u"ࠪࡳࡵ࠭僬"):l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ僭")}
		elif l1l111_l1_ (u"ࠬࠨࡩࡥࠤࠪ僮") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"࠭ࡩࡥࠩ僯"):l1l1l11lllll_l1_,l1l111_l1_ (u"ࠧࡰࡲࠪ僰"):l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫ僱")}
		l1ll1ll1l_l1_ = headers.copy()
		l1ll1ll1l_l1_[l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ僲")] = l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ僳")
		l1lll1l11_l1_ = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ僴"),url,payload,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭僵"),False,l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨ僶"))
		l11l1ll1_l1_ = l1lll1l11_l1_.content
	l1l1111l1l11_l1_,bbb,ccc = l1l111l11l1l_l1_(url,l11l1ll1_l1_)
	l1l1l1111ll1_l1_[l1l11lll1lll_l1_] = l1l1111l1l11_l1_,bbb,ccc,l11lll1lll11_l1_
	return
l1l1l1111ll1_l1_,l1l11l111ll1_l1_ = {},0
def l11lllll1ll1_l1_(url):
	global l1l1l1111ll1_l1_,l1l11l111ll1_l1_
	l1ll_l1_,threads = [],[]
	l1l11l111ll1_l1_ += 100
	l1l11lllll11_l1_ = l1l11l111ll1_l1_
	l1ll_l1_.append([1,url])
	l1l1l1111ll1_l1_[l1l11lllll11_l1_+1] = [None,None,None,None]
	thread = threading.Thread(target=l1l1l1l111ll_l1_,args=(l1l11lllll11_l1_+1,url))
	thread.start()
	thread.join(10)
	if not l1l1l1111ll1_l1_[l1l11lllll11_l1_+1][2]:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ僷"),l1l111_l1_ (u"ࠨ࠱ࠪ僸"))
		parts = re.findall(l1l111_l1_ (u"ࠩࡡࠬ࠳࠰࠿࠻࠱࠲࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࠪࠧ價"),l1lllll1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ僺"),re.DOTALL)
		start,l1l1111l1111_l1_,end = parts[0]
		end = end.strip(l1l111_l1_ (u"ࠫ࠴࠭僻"))
		l1l111lll1l1_l1_ = len(l1l1111l1111_l1_)<4 or l1l1111l1111_l1_ in [l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠪ僼"),l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ僽"),l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࡫࡭ࡣࡧࡧࠫ僾")]
		if not l1l111lll1l1_l1_: l1ll_l1_.append([2,start+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ僿")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ儀")+end])
		if end: l1ll_l1_.append([3,start+l1l111_l1_ (u"ࠪ࠳ࠬ儁")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ儂")+end])
		if l1l111_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ儃") in l1l1111l1111_l1_:
			l1l11l1lllll_l1_ = l1l1111l1111_l1_.replace(l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ億"),l1l111_l1_ (u"ࠧࠨ儅"))
			l1ll_l1_.append([4,start+l1l111_l1_ (u"ࠨ࠱ࠪ儆")+l1l11l1lllll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ儇")+end])
			l1ll_l1_.append([5,start+l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ儈")+l1l11l1lllll_l1_+l1l111_l1_ (u"ࠫ࠴࠭儉")+end])
			if end: l1ll_l1_.append([6,start+l1l111_l1_ (u"ࠬ࠵ࠧ儊")+l1l11l1lllll_l1_+l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ儋")+end])
		elif l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭儌") in end:
			l1l11lll1ll1_l1_ = end.replace(l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ儍"),l1l111_l1_ (u"ࠩࠪ儎"))
			l1ll_l1_.append([7,start+l1l111_l1_ (u"ࠪ࠳ࠬ儏")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠫ࠴࠭儐")+l1l11lll1ll1_l1_])
			if not l1l111lll1l1_l1_: l1ll_l1_.append([8,start+l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭儑")+l1l1111l1111_l1_+l1l111_l1_ (u"࠭࠯ࠨ儒")+l1l11lll1ll1_l1_])
			l1ll_l1_.append([9,start+l1l111_l1_ (u"ࠧ࠰ࠩ儓")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ儔")+l1l11lll1ll1_l1_])
		else:
			if not l1l111lll1l1_l1_: l1ll_l1_.append([10,start+l1l111_l1_ (u"ࠩ࠲ࠫ儕")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ儖")])
			if not l1l111lll1l1_l1_: l1ll_l1_.append([11,start+l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ儗")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ儘")])
			if end: l1ll_l1_.append([12,start+l1l111_l1_ (u"࠭࠯ࠨ儙")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ儚")+end+l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ儛")])
			if end: l1ll_l1_.append([13,start+l1l111_l1_ (u"ࠩ࠲ࠫ儜")+l1l1111l1111_l1_+l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ儝")+end+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ儞")])
		if l1l111lll1l1_l1_ and end:
			end = end.replace(l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭償"),l1l111_l1_ (u"࠭࠯ࠨ儠"))
			l1ll_l1_.append([14,start+l1l111_l1_ (u"ࠧ࠰ࠩ儡")+end])
			l1ll_l1_.append([15,start+l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ儢")+end])
			if l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ儣") in end:
				l1l11lll1ll1_l1_ = end.replace(l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ儤"),l1l111_l1_ (u"ࠫࠬ儥"))
				l1ll_l1_.append([16,start+l1l111_l1_ (u"ࠬ࠵ࠧ儦")+l1l11lll1ll1_l1_])
				l1ll_l1_.append([17,start+l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ儧")+l1l11lll1ll1_l1_])
			else:
				l1ll_l1_.append([18,start+l1l111_l1_ (u"ࠧ࠰ࠩ儨")+end+l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ儩")])
				l1ll_l1_.append([19,start+l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ優")+end+l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ儫")])
		for l1l1l11111_l1_,l1ll1ll_l1_ in l1ll_l1_[1:]:
			l1l1l1111ll1_l1_[l1l11lllll11_l1_+l1l1l11111_l1_] = [None,None,None,None]
			thread = threading.Thread(target=l1l1l1l111ll_l1_,args=(l1l11lllll11_l1_+l1l1l11111_l1_,l1ll1ll_l1_))
			thread.start()
			time.sleep(1)
			threads.append(thread)
		for thread in threads: thread.join(10)
	l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࠬ儬"),[],[]
	l1l11ll1l1ll_l1_ = []
	for l1l1l11111_l1_,l1ll1ll_l1_ in l1ll_l1_:
		l1l11l111lll_l1_,l1l1l11ll1ll_l1_,l11lll111_l1_,l11llll111l1_l1_ = l1l1l1111ll1_l1_[l1l11lllll11_l1_+l1l1l11111_l1_]
		if not l1llll_l1_ and l11lll111_l1_: l1l1lll1_l1_,l1llll_l1_ = l1l1l11ll1ll_l1_,l11lll111_l1_
		if not l1l1l1111111_l1_ and l1l11l111lll_l1_: l1l1l1111111_l1_ = l1l11l111lll_l1_
		if l11llll111l1_l1_: l1l11ll1l1ll_l1_.append(l11llll111l1_l1_)
	l1l11ll1l1ll_l1_ = list(set(l1l11ll1l1ll_l1_))
	if not l1l1l1111111_l1_ and len(l1l11ll1l1ll_l1_)==1:
		l11lll1lll11_l1_ = l1l11ll1l1ll_l1_[0]
		if l11lll1lll11_l1_!=200:
			if l11lll1lll11_l1_<0: l1l1l1111111_l1_ = l1l111_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡧࡧࡦ࠱ࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥࡰࡪ࠭儭")
			else:
				l1l1l1111111_l1_ = l1l111_l1_ (u"࠭ࡈࡕࡖࡓࠤࡊࡸࡲࡰࡴ࠽ࠤࠬ儮")+str(l11lll1lll11_l1_)
				if PY3: import http.client as l1l111lllll1_l1_
				else: import httplib as l1l111lllll1_l1_
				l1l1l1111111_l1_ += l1l111_l1_ (u"ࠧࠡࠪࠣࠫ儯")+l1l111lllll1_l1_.responses[l11lll1lll11_l1_]+l1l111_l1_ (u"ࠨࠢࠬࠫ儰")
	time.sleep(1)
	return l1l1l1111111_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111111111_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ儱"),l1l111_l1_ (u"ࠪࠫ儲"),l1l111_l1_ (u"ࠫࠬ儳"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ儴"))
	items = re.findall(l1l111_l1_ (u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ儵"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ儶"),[l1l111_l1_ (u"ࠨࠩ儷")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉ࡙ࠧ儸"),[],[]
def l1l11l11ll11_l1_(url):
	return l1l111_l1_ (u"ࠪࠫ儹"),[l1l111_l1_ (u"ࠫࠬ儺")],[ url ]
def l1l11lll11ll_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ儻"))
	basename = l1l111_l1_ (u"࠭࠯ࠨ儼").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ儽"),l1l111_l1_ (u"ࠨࠩ儾"),l1l111_l1_ (u"ࠩࠪ儿"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧ兀"))
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭允"),html,re.DOTALL)
	if items:
		l1l1llll111l_l1_,l1l1lllll111_l1_,l1l1lllll11l_l1_,l1l1l111lll1_l1_,l1l1l111llll_l1_,l1l1l111ll11_l1_ = items[0]
		var = int(l1l1lllll111_l1_) % int(l1l1lllll11l_l1_) + int(l1l1l111lll1_l1_) % int(l1l1l111llll_l1_)
		url = basename + l1l1llll111l_l1_ + str(var) + l1l1l111ll11_l1_
		return l1l111_l1_ (u"ࠬ࠭兂"),[l1l111_l1_ (u"࠭ࠧ元")],[url]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢ࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠭兄"),[],[]
def l1l11llll111_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ充"))[-1]
	headers = { l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ兆") : l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ兇") }
	payload = { l1l111_l1_ (u"ࠦ࡮ࡪࠢ先"):id , l1l111_l1_ (u"ࠧࡵࡰࠣ光"):l1l111_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠤ兊") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ克"), url, payload, headers, l1l111_l1_ (u"ࠨࠩ兌"),l1l111_l1_ (u"ࠩࠪ免"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭兎"))
	if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭兏") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ児")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࠧ兑"),[l1l111_l1_ (u"ࠧࠨ兒")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭兓"),[],[]
def l11lll1ll111_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ兔"),l1l111_l1_ (u"ࠪࠫ兕"),l1l111_l1_ (u"ࠫࠬ兖"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡌࡒ࡙࡜ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ兗"))
	items = re.findall(l1l111_l1_ (u"࠭࡭ࡱ࠶࠽ࠤࡡࡡ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ兘"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ兙"),[l1l111_l1_ (u"ࠨࠩ党")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧ兛"),[],[]
def l11lllll111l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ兜"),l1l111_l1_ (u"ࠫࠬ兝"),l1l111_l1_ (u"ࠬ࠭兞"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧ兟"))
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ兠"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ兡") + items[0]
		return l1l111_l1_ (u"ࠩࠪ兢"),[l1l111_l1_ (u"ࠪࠫ兣")],[ url ]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡅࡋࡍ࡛ࡋࠧ兤"),[],[]
def l11llllll1l1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭入"),l1l111_l1_ (u"࠭ࠧ兦"),l1l111_l1_ (u"ࠧࠨ內"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ全"))
	items = re.findall(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ兩"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ兪"),[l1l111_l1_ (u"ࠫࠬ八")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ公"),[],[]
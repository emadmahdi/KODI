# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ堜")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ堝")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ堞"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l11ll11l1_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堟"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭堠"),l1l111_l1_ (u"ࠧࠨ堡"),319,l1l111_l1_ (u"ࠨࠩ堢"),l1l111_l1_ (u"ࠩࠪ堣"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ堤"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ堥"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭堦"),l1l111_l1_ (u"࠭ࠧ堧"),l1l111_l1_ (u"ࠧࠨ堨"),l1l111_l1_ (u"ࠨࠩ堩"),l1l111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ堪"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࡱ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ堫"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ堬"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ堭"),l1l111_l1_ (u"࠭ࠧ堮"),9999)
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠻࠾ࠨ堯"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠨࠢࠪ堰"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ報"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ堲")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠫࠬ堳"),l1l111_l1_ (u"ࠬ࠭場"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭堵"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ堶")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ๅห฼฿ࠠี้ิࠫ堷"),l111l1_l1_,314,l1l111_l1_ (u"ࠩࠪ堸"),l1l111_l1_ (u"ࠪࠫ堹"),l1l111_l1_ (u"ࠫ࠵࠭堺"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ堻"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ堼"),l1l111_l1_ (u"ࠧࠨ堽"),9999)
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡆࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡈ࠾ࠨ堾"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ堿")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ塀"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭塁")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ塂"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ塃"),l1l111_l1_ (u"ࠧࠨ塄"),l1l111_l1_ (u"ࠨࠩ塅"),l1l111_l1_ (u"ࠩࠪ塆"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ塇"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠫ࠵࠭塈"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡡࡣ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ塉"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭塊"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ塋")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ塌"))
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ塍"))
			title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭塎")+name+l1l111_l1_ (u"ࠫ࠮࠭塏")
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ塐"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"࠭࠱ࠨ塑"),l1l111_l1_ (u"ࠧ࠳ࠩ塒"),l1l111_l1_ (u"ࠨ࠵ࠪ塓")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡀ࡭࠻࠾࠯ࠬࡂ࠭ࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡬ࡨࠩ塔"),html,re.DOTALL)
		l11l11ll11ll_l1_ = int(seq)-1
		block = l11llll_l1_[l11l11ll11ll_l1_]
		if seq==l1l111_l1_ (u"ࠪ࠵ࠬ塕"): items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ塖"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭塗"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ塘")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ塙")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ塚"))
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ塛"))
			title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭塜")+name+l1l111_l1_ (u"ࠫ࠮࠭塝")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ塞"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"࠭࠴ࠨ塟"),l1l111_l1_ (u"ࠧ࠶ࠩ塠"),l1l111_l1_ (u"ࠨ࠸ࠪ塡")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡀ࡭࠻࠾࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭塢"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅ࠭ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭塣"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11l11_l1_,title,l111111111_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭塤")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ塥")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ塦"))
			l1ll1l11l11_l1_ = l1ll1l11l11_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ塧"))
			l111111111_l1_ = l111111111_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪ塨"))
			if l1ll1l11l11_l1_: name = l1ll1l11l11_l1_
			else: name = l111111111_l1_
			title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ塩")+name+l1l111_l1_ (u"ࠪ࠭ࠬ塪")
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ填"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ塬"),url,l1l111_l1_ (u"࠭ࠧ塭"),l1l111_l1_ (u"ࠧࠨ塮"),l1l111_l1_ (u"ࠨࠩ塯"),l1l111_l1_ (u"ࠩࠪ塰"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ塱"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡨ࡯ࡹ࠯࡫ࡩࡦࡪࡩ࡯ࡩࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡯ࡳࡦࡺ࠭ࡳ࡫ࡪ࡬ࡹ࠭塲"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠬࡩࡡࡵࡵࡸࡱ࠲ࡳ࡯ࡣ࡫࡯ࡩࠬ塳") in block:
		items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃࡨࡧࡴࡴࡷࡰ࠱ࡲࡵࡢࡪ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ塴"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ塵")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ塶")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠩࠣห้฻่ห์ฬ࠾ࠥ࠭塷"),l1l111_l1_ (u"ࠪ࠾ࠬ塸"))
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭塹"))
				title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ塺")+count+l1l111_l1_ (u"࠭ࠩࠨ塻")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ塼"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ塽"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l11ll1l11_l1_,l1l1lll111_l1_ in items:
			if title==l1l111_l1_ (u"ࠩࠪ塾") or l11l11ll1l11_l1_==l1l111_l1_ (u"ࠪࠫ塿"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭墀")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ墁")+l1l1lll111_l1_+l1l111_l1_ (u"࠭ࠩࠨ墂")
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭境"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ墄"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ墅"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll111_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ墆")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭墇"))
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ墈"))
		title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ墉")+name+l1l111_l1_ (u"ࠧࠪࠩ墊")
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ墋"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠩࠪ墌"),l1l1lll111_l1_)
	return
def l11l11ll11l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ墍"),url,l1l111_l1_ (u"ࠫࠬ墎"),l1l111_l1_ (u"ࠬ࠭墏"),l1l111_l1_ (u"࠭ࠧ墐"),l1l111_l1_ (u"ࠧࠨ墑"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡘࡋࡁࡓࡅࡋࡣࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ墒"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠡࡲ࠰࠵ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ墓"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ墔"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭墕")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ墖"))
		if l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠲࠭増") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭墘"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墙"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭墚"),url,l1l111_l1_ (u"ࠪࠫ墛"),l1l111_l1_ (u"ࠫࠬ墜"),l1l111_l1_ (u"ࠬ࠭墝"),l1l111_l1_ (u"࠭ࠧ增"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ墟"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࡹࡩ࡯࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ墠"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡺ࡮ࡪࡥࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ墡"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ墢"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ墣"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭墤"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ墥"),l1l111_l1_ (u"ࠧࠬࠩ墦"))
	l11l11ll1l1l_l1_ = [l1l111_l1_ (u"ࠨࠨࡷࡁࡦ࠭墧"),l1l111_l1_ (u"ࠩࠩࡸࡂࡩࠧ墨"),l1l111_l1_ (u"ࠪࠪࡹࡃࡳࠨ墩")]
	if l11_l1_:
		l11l11ll111l_l1_ = [l1l111_l1_ (u"ࠫ็อัวࠩ墪"),l1l111_l1_ (u"ࠬหีะษิࠤ࠴ࠦๅอๆาࠫ墫"),l1l111_l1_ (u"࠭ๅใู฼ࠤฬ๊ี้ฬํࠫ墬")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢ࠰ࠤศิสาࠢส่อำหࠨ墭"), l11l11ll111l_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘࡥࠧ墮") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘࡥࠧ墯") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡗࡇࡍࡔ࡙࡟ࠨ墰") in options: l11l11l_l1_ = 2
	else: return
	type = l11l11ll1l1l_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ墱")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ墲"),url,l1l111_l1_ (u"࠭ࠧ墳"),l1l111_l1_ (u"ࠧࠨ墴"),l1l111_l1_ (u"ࠨࠩ墵"),l1l111_l1_ (u"ࠩࠪ墶"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ墷"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ墸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ墹"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ墺"))
				name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ墻"))
				title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ墼")+name+l1l111_l1_ (u"ࠩࠬࠫ墽")
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ墾"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡸࡩࡄ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠪ墿"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ壀"))
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ壁"))
				title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ壂")+name+l1l111_l1_ (u"ࠨࠫࠪ壃")
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ壄"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
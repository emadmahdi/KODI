# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧฐ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡆࡘࡔࡠࠩฑ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==730: l1lll_l1_ = l1l1l11_l1_()
	elif mode==731: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==732: l1lll_l1_ = PLAY(url)
	elif mode==733: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==734: l1lll_l1_ = l1l1lll1l_l1_(url)
	elif mode==735: l1lll_l1_ = l1l1lllll_l1_(url)
	elif mode==739: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫฒ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬณ"),l1l111_l1_ (u"࠭ࠧด"),739,l1l111_l1_ (u"ࠧࠨต"),l1l111_l1_ (u"ࠨࠩถ"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ท"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨธ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭น"),l1l111_l1_ (u"ࠬ࠭บ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ป"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩผ")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨฝ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡸࡴࡶ࠮ࡱࡪࡳࠫพ"),735)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪฟ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ภ")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯ࠭ม"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡵࡸࡴࡵ࡮࠯ࡲ࡫ࡴࠬย"),734)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧร"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪฤ")+l1lllll_l1_+l1l111_l1_ (u"ࠩสๅ้อๅࠨล"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠲ࡵ࡮ࡰࠨฦ"),731)
	return
def l1l1lll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫว"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไไๆࠪศ"),url,731)
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪษ"),url,l1l111_l1_ (u"ࠧࠨส"),l1l111_l1_ (u"ࠨࠩห"),l1l111_l1_ (u"ࠩࠪฬ"),l1l111_l1_ (u"ࠪࠫอ"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔ࠯ࡖࡉࡗࡏࡅࡔࡡࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧฮ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲࡡࡣࡧ࡯ࡁࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ฯ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣะ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩั")+l1ll1ll_l1_
			title = l1l111_l1_ (u"ࠨฯิๅࠥ࠭า")+title
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩำ"),l1lllll_l1_+title,l1ll1ll_l1_,731)
	return
def l1l1lllll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧิ"),url,l1l111_l1_ (u"ࠫࠬี"),l1l111_l1_ (u"ࠬ࠭ึ"),l1l111_l1_ (u"࠭ࠧื"),l1l111_l1_ (u"ࠧࠨุ"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠳ࡓࡆࡔࡌࡉࡘࡥࡆࡆࡃࡗ࡙ࡗࡋࡄ࠮࠴ࡱࡨูࠬ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃฺ࠭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ฻"),block,re.DOTALL)
		for title,l1ll1ll_l1_,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭฼")+l1ll1ll_l1_
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ฽")+l1ll1l_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ฾"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ฿"),l1lllll_l1_+title,l1ll1ll_l1_,733,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬเ"),url,l1l111_l1_ (u"ࠩࠪแ"),l1l111_l1_ (u"ࠪࠫโ"),l1l111_l1_ (u"ࠫࠬใ"),l1l111_l1_ (u"ࠬ࠭ไ"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨๅ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧ࡮ࡱࡹ࡭ࡪࡹࡂ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢๆ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡲࡺ࡮࡫ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡀࠪ็"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲่ࠫ")+l1ll1ll_l1_
		l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳้ࠬ")+l1ll1l_l1_
		title = title.strip(l1l111_l1_ (u"๊ࠫࠥ࠭"))
		if l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷ࠳ࡶࡨࡱ๋ࠩ") in url: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ์"),l1lllll_l1_+title,l1ll1ll_l1_,732,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧํ"),l1lllll_l1_+title,l1ll1ll_l1_,733,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ๎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ๏"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ๐")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭๑"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ๒"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ๓")+title,l1ll1ll_l1_,731)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ๔"),url,l1l111_l1_ (u"ࠨࠩ๕"),l1l111_l1_ (u"ࠩࠪ๖"),l1l111_l1_ (u"ࠪࠫ๗"),l1l111_l1_ (u"ࠫࠬ๘"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ๙"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭࡭ࡰࡸ࡬ࡩࡸࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫࡶࡧࡷ࡯ࡰࡵࠤ๚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡱࡹ࡭ࡪࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡁࠫ๛"),block,re.DOTALL)
		for title,l1ll1ll_l1_,l1ll1l_l1_,l1l1llll1_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ๜")+l1ll1ll_l1_
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ๝")+l1ll1l_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ๞"))
			title = title+l1l111_l1_ (u"ࠫࠥ࠭๟")+l1l1llll1_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ๠"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ๡"),l1lllll_l1_+title,l1ll1ll_l1_,732,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ๢"),url,l1l111_l1_ (u"ࠨࠩ๣"),l1l111_l1_ (u"ࠩࠪ๤"),l1l111_l1_ (u"ࠪࠫ๥"),l1l111_l1_ (u"ࠫࠬ๦"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ๧"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ๨"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ๩") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫ๪")
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ๫"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ๬"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ๭"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭๮"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ๯"),l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ๰"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠨࠩ๱"),l1l111_l1_ (u"ࠩࡰࠫ๲")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ุ้๊ࠪำๅษอࠫ๳"),l1l111_l1_ (u"ࠫฬ็ไศ็ࠪ๴")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ๵"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	type = l1llll_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯࡭࡫ࡹࡩࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ๶")+type+l1l111_l1_ (u"ࠧࠧࡳࡀࠫ๷")+search
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ๸"),url,l1l111_l1_ (u"ࠩࠪ๹"),l1l111_l1_ (u"ࠪࠫ๺"),l1l111_l1_ (u"ࠫࠬ๻"),l1l111_l1_ (u"ࠬ࠭๼"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ๽"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭๾"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ๿")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ຀"))
		if type==l1l111_l1_ (u"ࠪࡱࠬກ"): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪຂ"),l1lllll_l1_+title,l1ll1ll_l1_,732)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ຃"),l1lllll_l1_+title,l1ll1ll_l1_,733)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ坾")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊࡑࡣࠬ坿")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧใ่๋หฯࠦแืษษ๎ฮ࠭垀"),l1l111_l1_ (u"ࠨใสีุ้่ࠨ垁"),l1l111_l1_ (u"ࠩࡖ࡬ࡴࡽࠠ࡮ࡱࡵࡩࠬ垂")]
def l11l1ll_l1_(mode,url,text):
	if   mode==580: l1lll_l1_ = l1l1l11_l1_()
	elif mode==581: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==582: l1lll_l1_ = PLAY(url)
	elif mode==583: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==584: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==589: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ垃"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ垄"),l1l111_l1_ (u"ࠬ࠭垅"),l1l111_l1_ (u"࠭ࠧ垆"),l1l111_l1_ (u"ࠧࠨ垇"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ垈"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垉"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ垊"),l1l111_l1_ (u"ࠫࠬ型"),589,l1l111_l1_ (u"ࠬ࠭垌"),l1l111_l1_ (u"࠭ࠧ垍"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ垎"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭垏"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ垐"),l1l111_l1_ (u"ࠪࠫ垑"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ垒"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ垓"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"࠭ࠧ垔"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ垕"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垖"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ垗")+l1lllll_l1_+title,l1ll1ll_l1_,584)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ垘"),url,l1l111_l1_ (u"ࠫࠬ垙"),l1l111_l1_ (u"ࠬ࠭垚"),l1l111_l1_ (u"࠭ࠧ垛"),l1l111_l1_ (u"ࠧࠨ垜"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ垝"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭垞"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ垟"),l1l111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ垠"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ垡"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"࠭ࠧ垢"),block)]
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ垣"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭垤"),l1l111_l1_ (u"ࠩࠪ垥"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ垦"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠫ࠿ࠦࠧ垧")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垨"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ垩"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ垪"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭垫"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ垬"),l1l111_l1_ (u"ࠪࠫ垭"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垮"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭垯")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ垰"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ垱"),url,l1l111_l1_ (u"ࠨࠩ垲"),l1l111_l1_ (u"ࠩࠪ垳"),l1l111_l1_ (u"ࠪࠫ垴"),l1l111_l1_ (u"ࠫࠬ垵"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭垶"))
	html = response.content
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ垷"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧ垸"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ垹"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ垺"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ垻"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭垼"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ垽"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ垾"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭垿"),l1l111_l1_ (u"ࠨๅ็๎อ࠭埀"),l1l111_l1_ (u"ࠩส฽้อๆࠨ埁"),l1l111_l1_ (u"๋ࠪิอแࠨ埂"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ埃"),l1l111_l1_ (u"ࠬ฿ัืࠩ埄"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭埅"),l1l111_l1_ (u"ࠧศๆห์๊࠭埆"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨ埇")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫ埈"))
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ埉") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭埊")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ埋"))
		if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ埌") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ埍")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ城"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ埏"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ埐"),l1lllll_l1_+title,l1ll1ll_l1_,582,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ埑") in title:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ埒") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭埓"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ埔") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ埕"),l1lllll_l1_+title,l1ll1ll_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ埖"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬ埗"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭埘")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭埙"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ埚"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ埛"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埜")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ埝"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ埞"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ域")+title,l1ll1ll_l1_,581)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埠"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭埡"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ埢"),l1ll1ll_l1_,581)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ埣"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭埤"),url,l1l111_l1_ (u"ࠪࠫ埥"),l1l111_l1_ (u"ࠫࠬ埦"),l1l111_l1_ (u"ࠬ࠭埧"),l1l111_l1_ (u"࠭ࠧ埨"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ埩"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡺ࠲ࡹࡥࡢࡵࡲࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ埪"),html,re.DOTALL)
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ埫"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠪࠧࠬ埬"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ埭"),l1lllll_l1_+title,url,583,l1l111_l1_ (u"ࠬ࠭埮"),l1l111_l1_ (u"࠭ࠧ埯"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࠬ埰")+l1l11_l1_+l1l111_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ埱"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ埲"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ埳")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭埴"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埵"),l1lllll_l1_+title,l1ll1ll_l1_,582)
		else:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ埶"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ執") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埸")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ培"))
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ基"),l1lllll_l1_+title,l1ll1ll_l1_,582)
	return
def PLAY(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ埻"))
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ埼"),url,l1l111_l1_ (u"࠭ࠧ埽"),l1l111_l1_ (u"ࠧࠨ埾"),l1l111_l1_ (u"ࠨࠩ埿"),l1l111_l1_ (u"ࠩࠪ堀"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ堁"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堂"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ堃") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ堄")+l1ll1ll_l1_
	hash = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࡩࡣࡶ࡬ࡂ࠭堅"))[1]
	parts = hash.split(l1l111_l1_ (u"ࠨࡡࡢࠫ堆"))
	l1ll1l1111l1_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l111_l1_ (u"ࠩࡀࠫ堇"))
			if PY3: part = part.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ堈"))
			l1ll1l1111l1_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l111_l1_ (u"ࠫࡃ࠭堉").join(l1ll1l1111l1_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	if l1l111_l1_ (u"ࠬ࡬ࡡࡳࡵࡲࡰࠬ堊") not in str(l1ll_l1_):
		for l1ll1ll_l1_ in l1ll_l1_:
			title,l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠠ࠾ࡀࠣࠫ堋"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ堌")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ堍")
			l1llll_l1_.append(l1ll1ll_l1_)
		import ll_l1_
		ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ堎"),url)
	else:
		title,l1ll1ll_l1_ = l1ll_l1_[0].split(l1l111_l1_ (u"ࠪࠤࡂࡄࠠࠨ堏"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ堐"),l1l111_l1_ (u"ࠬ࠭堑"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ堒"),l1l111_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋࠭堓")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ堔")+l1l111_l1_ (u"ࠩํีั๏ࠠศๆ่ัฬ๎ไสࠢ็หา่วࠨ堕")+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ堖")+title)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ堗"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭堘"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ堙"),l1l111_l1_ (u"ࠧࠬࠩ堚"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ堛")+search
	l1lll11_l1_(url)
	return
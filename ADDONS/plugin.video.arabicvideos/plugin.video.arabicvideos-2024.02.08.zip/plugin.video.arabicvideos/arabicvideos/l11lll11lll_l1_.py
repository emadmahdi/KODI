# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ好")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬ奾")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1ll11_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l11l1llll_l1_()
	elif mode==56: l1lll_l1_ = l11l11l1l1l1_l1_()
	elif mode==57: l1lll_l1_ = l111ll111l_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll111l_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奿"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ妀"),l1l111_l1_ (u"ࠩࠪ妁"),59,l1l111_l1_ (u"ࠪࠫ如"),l1l111_l1_ (u"ࠫࠬ妃"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ妄"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ妅"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ妆"),l1l111_l1_ (u"ࠨࠩ妇"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妈"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ妉")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ妊"),l1l111_l1_ (u"ࠬ࠭妋"),56)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妌"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ妍")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็หๆ๊วๆࠩ妎"),l1l111_l1_ (u"ࠩࠪ妏"),55)
	return l1l111_l1_ (u"ࠪࠫ妐")
def l11l11l1llll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妑"),l1lllll_l1_+l1l111_l1_ (u"ࠬออะอࠣห้อแๅษ่ࠫ妒"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ妓"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妔"),l1lllll_l1_+l1l111_l1_ (u"ࠨษไ่ฬ๋ࠠาษษะฮ࠭妕"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ妖"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妗"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็หๆ๊วๆࠩ妘"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ妙"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妚"),l1lllll_l1_+l1l111_l1_ (u"ࠧศใ็ห๊ࠦใๅษึ๎่๐ษࠨ妛"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ妜"),51)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ妝"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ妞"),l1l111_l1_ (u"ࠫࠬ妟"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妠"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ妡"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡼࡳࡵ࠭妢"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妣"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ妤"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ妥"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妦"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ妧"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ妨"),57)
	return
def l11l11l1l1l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妩"),l1lllll_l1_+l1l111_l1_ (u"ࠨษะำะࠦวๅ็ึุ่๊วหࠩ妪"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ妫"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妬"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืววฮฬࠫ妭"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ妮"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妯"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊ๅิๆึ่ฬะࠧ妰"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ妱"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妲"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤ่๊วิ์ๆ๎ฮ࠭妳"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ妴"),51)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ妵"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ妶"),l1l111_l1_ (u"ࠧࠨ妷"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妸"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ妹"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡹࡰࡲࠪ妺"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妻"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ妼"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ妽"),57)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妾"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ妿"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ姀"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠪࡃࠬ姁") in url:
		parts = url.split(l1l111_l1_ (u"ࠫࡄ࠭姂"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠬࡅࠧ姃") + QUOTE(parts[1],l1l111_l1_ (u"࠭࠽ࠧ࠼࠲ࠩࠬ姄"))
	else: filter = l1l111_l1_ (u"ࠧࠨ姅")
	parts = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ姆"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"ࠩࡼࡳࡵ࠭姇"),l1l111_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࠪ姈"),l1l111_l1_ (u"ࠫࡻ࡯ࡥࡸࡵࠪ姉")]:
		if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ姊"): l1l1l1lll_l1_=l1l111_l1_ (u"࠭แ๋ๆ่ࠫ始")
		elif type==l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ姌"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ姍")
		url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪ姎") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠪ࠳ࠬ姏") + l1llllll1_l1_ + l1l111_l1_ (u"ࠫ࠴࠭姐") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭姑"),l1l111_l1_ (u"࠭ࠧ姒"),l1l111_l1_ (u"ࠧࠨ姓"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ委"))
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡴ࡮ࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡵࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࠤࡳࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡰࡳࡧࡶࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ姕"),html,re.DOTALL)
		l1ll1l1111l_l1_=0
		for id,title,l11l11l1l11l_l1_,l1ll1l_l1_ in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1ll1l1ll11_l1_ + l1l111_l1_ (u"ࠪ࠳ࡻ࠸࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴ࡳࡡࡪࡰ࠲ࠫ姖") + l1ll1l_l1_ + l1l111_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ姗")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ姘") + id
			if type==l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ姙"): addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭姚"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ姛"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姜"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅࠢࠪ姝")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ姞")+l11l11l1l11l_l1_+l1l111_l1_ (u"ࠬࡃࠧ姟")+title+l1l111_l1_ (u"࠭࠽ࠨ姠")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭姡"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ姢")
		elif type==l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ姣"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ姤")
		url = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡰࡳࡰࡰ࠲ࡷࡪࡲࡥࡤࡶࡨࡨ࠴࠭姥") + sort + l1l111_l1_ (u"ࠬ࠳ࠧ姦") + l1l1l1lll_l1_ + l1l111_l1_ (u"࠭࠭ࡘ࡙࠱࡮ࡸࡵ࡮ࠨ姧")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ姨"),l1l111_l1_ (u"ࠨࠩ姩"),l1l111_l1_ (u"ࠩࠪ姪"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ姫"))
		items = re.findall(l1l111_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡩࡵࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ姬"),html,re.DOTALL)
		l1ll1l1111l_l1_=0
		for id,l11l11l1l11l_l1_,l1ll1l_l1_,title in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ姭") + l1ll1l_l1_ + l1l111_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭姮")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ姯") + id
			if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ姰"): addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ姱"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ姲"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姳"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็ࠤࠬ姴")+title,l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿ࡦࡲࡀࠫ姵")+l11l11l1l11l_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ姶")+title+l1l111_l1_ (u"ࠨ࠿ࠪ姷")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"ุࠩๅาฯࠠࠨ姸")
	if l1ll1l1111l_l1_==16:
		for l1ll1l1ll1l_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1ll1l_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ姹")+type+l1l111_l1_ (u"ࠫ࠴࠭姺")+str(l1ll1l1ll1l_l1_)+l1l111_l1_ (u"ࠬ࠵ࠧ姻")+sort + filter
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姼"),l1lllll_l1_+title+str(l1ll1l1ll1l_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠧ࠾ࠩ姽"))
	l11l11l1l11l_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭姾"),l1l111_l1_ (u"ࠩࠪ姿"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠪࡃࠬ娀"))[0]
	if l11l11l1l11l_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ威"),l1l111_l1_ (u"ࠬ࠭娂"),l1l111_l1_ (u"࠭ࠧ娃"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ娄"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡰࡪࡩࡴ࠿ࠩ娅"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ娆"),block,re.DOTALL)
		l11l11l1l11l_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l11l1l11l_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ娇") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ娈")+name+l1l111_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩ娉")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ娊"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ娋"),l1l111_l1_ (u"ࠨࠩ娌"),l1l111_l1_ (u"ࠩࠪ娍"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ娎"))
	l11l11l1l1ll_l1_ = re.findall(l1l111_l1_ (u"๊ࠫะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิ࠴ࠪࡀ࡯ࡲࡱࡪࡴࡴ࡝ࠪࠥࠬ࠳࠰࠿ࠪࠤࠪ娏"),html,re.DOTALL)
	if l11l11l1l1ll_l1_:
		time = l11l11l1l1ll_l1_[1].replace(l1l111_l1_ (u"࡚ࠬࠧ娐"),l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ娑"))
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ娒"),l1l111_l1_ (u"ࠨࠩ娓"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠫ娔"),l1l111_l1_ (u"๋ࠪีอࠠศๆไ๎ิ๐่ࠡีํ็ํ์ࠠๆฬ๋ๅึูࠦๅุ๋ࠣํ็ࠠๆษๆืࠥฮูะ๊ࠢิฬࠦวๅ๊ๅฮࠬ娕")+l1l111_l1_ (u"ࠫࡡࡴࠧ娖")+time)
		return
	l11l11l11lll_l1_,l11l11l1ll1l_l1_ = [],[]
	l11l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ娗"),html,re.DOTALL)[0]
	l11l11l1ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡦࡦࡩ࡫ࡶࡲࡢࡳࡷ࡯ࡧࡪࡰࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ娘"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩ࡮ࡶ࠾ࠥ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ娙"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ娚") in server:
			server = l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ娛")
			url = l11l11l1ll11_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ娜")
			url = l11l11l1lll1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ娝") in url:
			l11l11l11lll_l1_.append(url)
			l11l11l1ll1l_l1_.append(l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠤࠬ娞")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡱ࠶࠽࠲࠯ࡅ࡟࡭࡫ࡱ࡯࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ娟"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ娠"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ娡"))[-1]
		filename = filename.replace(l1l111_l1_ (u"ࠩࡩࡥࡱࡲࡢࡢࡥ࡮ࠫ娢"),l1l111_l1_ (u"ࠪࠫ娣"))
		filename = filename.replace(l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ娤"),l1l111_l1_ (u"ࠬ࠭娥"))
		filename = filename.replace(l1l111_l1_ (u"࠭࠭ࠨ娦"),l1l111_l1_ (u"ࠧࠨ娧"))
		if l1l111_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ娨") in server:
			server = l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ娩")
			url = l11l11l1ll11_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ娪")
			url = l11l11l1lll1_l1_ + l1ll1ll_l1_
		l11l11l11lll_l1_.append(url)
		l11l11l1ll1l_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠴ࠡࠢࠪ娫")+server+l1l111_l1_ (u"ࠬࠦࠠࠨ娬")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡖࡪࡦࡨࡳࠥࡗࡵࡢ࡮࡬ࡸࡾࡀࠧ娭"), l11l11l1ll1l_l1_)
	if l11l11l_l1_ == -1 : return
	url = l11l11l11lll_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭娮"))
	return
def l111ll111l_l1_(url,type):
	if l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ娯") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱่ืู้ไࠨ娰")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ๅ๏๊ๅࠨ娱")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ娲"),l1l111_l1_ (u"ࠬ࠭娳"),l1l111_l1_ (u"࠭ࠧ娴"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ娵"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ娶"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ娷"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ娸"),block,re.DOTALL)
	if type==1:
		for l11l11l1l111_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娹"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ娺")+l11l11l1l111_l1_,58)
	elif type==2:
		url,l11l11l1l111_l1_ = url.split(l1l111_l1_ (u"࠭࠿ࠨ娻"))
		for l1llll11ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ娼"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ娽")+l1llll11ll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ娾")+l11l11l1l111_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬ娿"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ婀"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ婁")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ婂"),url,l1l111_l1_ (u"ࠧࠨ婃"),l1l111_l1_ (u"ࠨࠩ婄"),True,l1l111_l1_ (u"ࠩࠪ婅"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ婆"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡬࡫࡮ࡦࡴࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡴࡧࡤࡶࡨ࡮࠭ࡣࡱࡷࡸࡴࡳ࠭ࡱࡣࡧࡨ࡮ࡴࡧࠨ婇"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ婈"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ婉") in url:
				if l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ婊") in url:
					title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭婋")+title
					url = url.replace(l1l111_l1_ (u"ࠩࡂࡩࡵࡃ࠱ࠨ婌"),l1l111_l1_ (u"ࠪࡃࡪࡶ࠽࠱ࠩ婍"))
					url = url+l1l111_l1_ (u"ࠫࡂ࠭婎")+QUOTE(title)+l1l111_l1_ (u"ࠬࡃࠧ婏")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婐"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ็๊ๅ็ࠣࠫ婑")+title
					addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ婒"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩဍ")
headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬဎ") : l1l111_l1_ (u"ࠩࠪဏ") }
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡆࡘࡌࡠࠩတ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫ฾ื่ืࠢส่๊฻วา฻ฬࠫထ"),l1l111_l1_ (u"ࠬอไไๆࠪဒ"),l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨဓ"),l1l111_l1_ (u"ࠧศๆ฼หอ࠭န"),l1l111_l1_ (u"ࠨสิห๊าࠠไ็ห๎ํะัࠨပ"),l1l111_l1_ (u"่ࠩ์ออ๊ๅ๋ࠢࠤั๎วๅࠩဖ"),l1l111_l1_ (u"ࠪห้่ำๆࠢส่ฬูไศ็ํࠫဗ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==200: l1lll_l1_ = l1l1l11_l1_()
	elif mode==201: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==202: l1lll_l1_ = PLAY(url)
	elif mode==203: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==204: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨဘ")+text)
	elif mode==205: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬမ")+text)
	elif mode==209: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ယ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧရ"),l1l111_l1_ (u"ࠨࠩလ"),209,l1l111_l1_ (u"ࠩࠪဝ"),l1l111_l1_ (u"ࠪࠫသ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨဟ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဠ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩအ"),l111l1_l1_,205)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧဢ"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫဣ"),l111l1_l1_,204)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧဤ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬဥ"),l1l111_l1_ (u"ࠫࠬဦ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဧ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨဨ")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆ็ํึฮ࠭ဩ"),l111l1_l1_+l1l111_l1_ (u"ࠨࡁࡂࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬဪ"),201)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩါ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬာ")+l1lllll_l1_+l1l111_l1_ (u"ࠫศ็ไศ็้๊ࠣ๐าสࠩိ"),l111l1_l1_+l1l111_l1_ (u"ࠬࡅ࠿ࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡰࡳࡻ࡯ࡥࡴࠩီ"),201)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ု"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩူ")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨေ"),l111l1_l1_+l1l111_l1_ (u"ࠩࡂࡃࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥࡳࡦࡴ࡬ࡩࡸ࠭ဲ"),201)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪဳ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ဴ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧဵ"),l111l1_l1_+l1l111_l1_ (u"࠭࠿ࡀ࡯ࡤ࡭ࡳࡶࡡࡨࡧࠪံ"),201)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗ့ࠫ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩး"),headers,True,l1l111_l1_ (u"္ࠩࠪ"),l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺ်ࠧ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳ࠮ࡶࡤࡦࡸ࠮࠮ࠫࡁࠬࡑࡦ࡯࡮ࡓࡱࡺࠫျ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧြ"),block,re.DOTALL)
		for filter,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡮࡯࡮ࡧ࠲ࡱࡴࡸࡥࡀࡨ࡬ࡰࡹ࡫ࡲ࠾ࠩွ")+filter
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧှ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪဿ")+l1lllll_l1_+title,l1ll1ll_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ၀"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ၁"),l1l111_l1_ (u"ࠫࠬ၂"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ၃"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၄"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ၅") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ၆"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ၇"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ၈")+l1lllll_l1_+title,l1ll1ll_l1_,201)
	return html
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠫࡄࡅࠧ၉") in url: url,type = url.split(l1l111_l1_ (u"ࠬࡅ࠿ࠨ၊"))
	else: type = l1l111_l1_ (u"࠭ࠧ။")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ၌"),url,l1l111_l1_ (u"ࠨࠩ၍"),headers,True,l1l111_l1_ (u"ࠩࠪ၎"),l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ၏"))
	html = response.content
	if l1l111_l1_ (u"ࠫ࡬࡫ࡴࡱࡱࡶࡸࡸ࠭ၐ") in url: l11llll_l1_ = [html]
	elif type==l1l111_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧၑ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡍࡢࡵࡷࡩࡷ࡙࡬ࡪࡦࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡞ࡱࠤ࠯ࡂ࠯ࡥ࡫ࡹࡂࡡࡴࠠࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨၒ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡰࡳࡻ࡯ࡥࡴࠩၓ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠳ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧၔ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࡣࡸ࡫ࡲࡪࡧࡶࠫၕ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡗࡱ࡯ࡤࡦࡴࡢ࠶࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩၖ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫ࠶࠷࠱࡮ࡣ࡬ࡲࡵࡧࡧࡦࠩၗ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠡࡲࡤ࡫ࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡺࡡࡣࡵࠥࠫၘ"),html,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡧࡱࡲࡸࡪࡸࠧၙ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l111111_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧၚ"),l1l111_l1_ (u"ࠨใํ่๊࠭ၛ"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨၜ"),l1l111_l1_ (u"ࠪ็้๐ศࠨၝ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪၞ"),l1l111_l1_ (u"ࠬํฯศใࠪၟ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭ၠ"),l1l111_l1_ (u"ฺࠧำูࠫၡ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨၢ"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨၣ")]
	items = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡧࡵࡸࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩၤ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠫࡘࡲࡩࡥࡧࡵࡍࡹ࡫࡭ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪၥ"),block,re.DOTALL)
		l1ll_l1_,l11ll1l11_l1_,l11l11_l1_ = zip(*items)
		items = zip(l11ll1l11_l1_,l1ll_l1_,l11l11_l1_)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧၦ") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨၧ"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩၨ"))
		if l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨၩ") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨၪ"),l1lllll_l1_+title,l1ll1ll_l1_,202,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ၫ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫၬ") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨၭ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬၮ") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧၯ"),l1lllll_l1_+title,l1ll1ll_l1_,203,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡳࡥࡨࡱ࠯ࠨၰ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩၱ"),l1lllll_l1_+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵࠪၲ"),201,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫၳ"),l1lllll_l1_+title,l1ll1ll_l1_,203,l1ll1l_l1_)
	if type in [l1l111_l1_ (u"ࠬ࠭ၴ"),l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡴࡦ࡭ࡥࠨၵ")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨၶ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨၷ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠩสฺ่็อสࠢࠪၸ"),l1l111_l1_ (u"ࠪࠫၹ"))
				if l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧၺ") in url:
					l11ll11ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫၻ"))[1]
					l11lll1ll_l1_ = url.split(l1l111_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬၼ"))[1]
					l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭ၽ")+l11lll1ll_l1_,l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧၾ")+l11ll11ll_l1_)
				if title!=l1l111_l1_ (u"ࠩࠪၿ"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪႀ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪႁ")+title,l1ll1ll_l1_,201)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩႂ"),url,l1l111_l1_ (u"࠭ࠧႃ"),headers,True,l1l111_l1_ (u"ࠧࠨႄ"),l1l111_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩႅ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡷ࡭࠲ࡲࡩࡴࡶ࠰ࡲࡺࡳࡢࡦࡴࡨࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩႆ"),html,re.DOTALL)
	if l11llll_l1_:
		l11111ll_l1_ = []
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠪࠫႇ").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႈ"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧႉ"))
		title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬႊ") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩႋ"))[-1].replace(l1l111_l1_ (u"ࠨ࠯ࠪႌ"),l1l111_l1_ (u"ႍࠩࠣࠫ"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪห้ำไให࠰ࠬࡡࡪࠫࠪࠩႎ"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭ႏ"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠬ࠶ࠧ႐")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ႑"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ႒"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ႓") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ႔") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ႕"),l1lllll_l1_+title,l1ll1ll_l1_,203)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭႖") not in l1ll1ll_l1_:
				title = l111l11_l1_(title)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ႗"),l1lllll_l1_+title,l1ll1ll_l1_,202)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"࠭࠯ࠨ႘"))
	hostname = l111l1_l1_
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ႙"),url,l1l111_l1_ (u"ࠨࠩႚ"),headers,True,True,l1l111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ႛ"))
	html = response.content
	id = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫႜ"),html,re.DOTALL)
	if not id: id = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬႝ"),html,re.DOTALL)
	if not id: id = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ႞"),html,re.DOTALL)
	if id: id = id[0]
	if l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ႟") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭Ⴀ"))
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬႡ"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪႢ"),headers,True,True,l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧႣ"))
		l11l1ll1_l1_ = response.content
		l11ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႤ"),l11l1ll1_l1_,re.DOTALL)
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࠦࢁࠬࡱࡶࡱࡷ࠿࠮࠭Ⴅ"),l11l1ll1_l1_,re.DOTALL)
		l11ll11l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠪࡶࡻ࡯ࡵ࠽ࠫ࠲࠯ࡅࠩࠧࡳࡸࡳࡹࡁ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪႦ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࡜࡯ࠬ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨႧ"),l11l1ll1_l1_)
		l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠬࡱࡶࡱࡷ࠿࠭࠴ࠪࡀࠫࠩࡵࡺࡵࡴ࠼࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႨ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫႩ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		items = l11ll111l_l1_+l1l1111_l1_+l11ll11l1_l1_+l11l1llll_l1_+l11l1lll1_l1_+l11ll1111_l1_
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨႪ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l111_l1_ (u"ࠫ࠳ࡶ࡮ࡨࠩႫ") in server: continue
			if l1l111_l1_ (u"ࠬ࠴ࡪࡱࡩࠪႬ") in server: continue
			if l1l111_l1_ (u"࠭ࠦࡲࡷࡲࡸࡀ࠭Ⴍ") in server: continue
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨႮ"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l111l1ll_l1_[0]
				if l111l1ll_l1_ in title: title = title.replace(l111l1ll_l1_+l1l111_l1_ (u"ࠨࡲࠪႯ"),l1l111_l1_ (u"ࠩࠪႰ")).replace(l111l1ll_l1_,l1l111_l1_ (u"ࠪࠫႱ")).strip(l1l111_l1_ (u"ࠫࠥ࠭Ⴒ"))
				l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪႳ")+l111l1ll_l1_
			else: l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧႴ")
			if server.isdigit():
				l1ll1ll_l1_ = hostname+l1l111_l1_ (u"ࠧ࠰ࡁࡳࡳࡸࡺࡩࡥ࠿ࠪႵ")+id+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬႶ")+server+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪႷ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫႸ")+l111l1ll_l1_
			else:
				if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩႹ") not in server: server = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫႺ")+server
				l111l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧႻ"),title,re.DOTALL)
				if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬႼ")+l111l1ll_l1_[0]
				else: l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠩႽ")
				l1ll1ll_l1_ = server+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࠪႾ")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡓࡵࡷࠨႿ") in html:
		l1ll1ll1l_l1_ = { l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪჀ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬჁ") }
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥࠩჂ")
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫჃ"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩჄ"),l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠩࠪჅ"),l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ჆"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡻ࡬ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠰࡭ࡹ࡫࡭ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬჇ"),l11l1ll1_l1_,re.DOTALL)
		for block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ჈"),block,re.DOTALL)
			for l1ll1ll_l1_,name,l111l1ll_l1_ in items:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ჉")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ჊")+l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭჋")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭჌") in html:
		l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧჍ"):l1l111_l1_ (u"ࠫࠬ჎") , l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ჏"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧა") }
		l1lllll1_l1_ = hostname + l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡴ࡫ࡴࠨࡳࡳࡸࡺࡉࡥ࠿ࠪბ")+id
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬგ"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪდ"),l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧე"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠳ࡢࡵࡰࡶࠫვ") in l11l1ll1_l1_:
			l11ll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫზ"),l11l1ll1_l1_,re.DOTALL)
			for l1llllll_l1_ in l11ll11l1_l1_:
				if l1l111_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭თ") not in l1llllll_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬი") in l1llllll_l1_:
					l1llllll_l1_ = l1llllll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬკ")
					l1llll_l1_.append(l1llllll_l1_)
				elif l1l111_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩლ") in l1llllll_l1_:
					l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠫმ")
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨნ"),l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭ო"),headers,True,True,l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪპ"))
					l11ll1l1l_l1_ = response.content
					l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠾ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄ࠯࠭࠮࠯࠰࠱ࠬჟ"),l11ll1l1l_l1_,re.DOTALL)
					for l1l1111l1_l1_ in l1lll1l1_l1_:
						l11ll1lll_l1_ = l1l111_l1_ (u"ࠨࠩრ")
						l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫს"),l1l1111l1_l1_,re.DOTALL)
						for l11llll11_l1_ in l11l1llll_l1_:
							item = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫტ"),l11llll11_l1_,re.DOTALL)
							if item:
								l111l1ll_l1_ = l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩუ")+item[0]
								break
						for l11llll11_l1_ in reversed(l11l1llll_l1_):
							item = re.findall(l1l111_l1_ (u"ࠬࡢࡷ࡝ࡹ࠮ࠫფ"),l11llll11_l1_,re.DOTALL)
							if item:
								l11ll1lll_l1_ = item[0]
								break
						l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬქ"),l1l1111l1_l1_,re.DOTALL)
						for l11lll11l_l1_ in l11l1lll1_l1_:
							l11lll11l_l1_ = l11lll11l_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨღ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬყ")+l111l1ll_l1_
							l1llll_l1_.append(l11lll11l_l1_)
		elif l1l111_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧშ") in l11l1ll1_l1_:
			l11l1ll1_l1_ = l11l1ll1_l1_.replace(l1l111_l1_ (u"ࠪࡀ࡭࠼ࠠࠨჩ"),l1l111_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨც"))+l1l111_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ძ")
			l11l1ll1_l1_ = l11l1ll1_l1_.replace(l1l111_l1_ (u"࠭࠼ࡩ࠵ࠣࠫწ"),l1l111_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫჭ"))+l1l111_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩხ")
			l11lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡀࡁࡘ࡚ࡁࡓࡖࡀࡁ࠭࠴ࠪࡀࠫࡀࡁࡊࡔࡄ࠾࠿ࠪჯ"),l11l1ll1_l1_,re.DOTALL)
			if l11lll1l1_l1_:
				for l1l1111l1_l1_ in l11lll1l1_l1_:
					if l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩჰ") not in l1l1111l1_l1_: continue
					l11llll1l_l1_ = l1l111_l1_ (u"ࠫࠬჱ")
					l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡬ࡰࡹ࠰ࡱࡴࡺࡩࡰࡰࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫჲ"),l1l1111l1_l1_,re.DOTALL)
					for l11llll11_l1_ in l11l1llll_l1_:
						item = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧჳ"),l11llll11_l1_,re.DOTALL)
						if item:
							l11llll1l_l1_ = l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬჴ")+item[0]
							break
					l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧჵ"),l1l1111l1_l1_,re.DOTALL)
					if l11l1llll_l1_:
						for l11ll1lll_l1_,l11lll111_l1_ in l11l1llll_l1_:
							l11lll111_l1_ = l11lll111_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪჶ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧჷ")+l11llll1l_l1_
							l1llll_l1_.append(l11lll111_l1_)
					else:
						l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫჸ"),l1l1111l1_l1_,re.DOTALL)
						for l11lll111_l1_,l11ll1lll_l1_ in l11l1llll_l1_:
							l11lll111_l1_ = l11lll111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧჹ"))+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧჺ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ჻")+l11llll1l_l1_
							l1llll_l1_.append(l11lll111_l1_)
			else:
				l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬࡡࡽࠫࠪ࠾ࠪჼ"),l11l1ll1_l1_,re.DOTALL)
				for l11lll111_l1_,l11ll1lll_l1_ in l11l1llll_l1_:
					l11lll111_l1_ = l11lll111_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫჽ"))+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫჾ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨჿ")
					l1llll_l1_.append(l11lll111_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᄀ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧᄁ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨᄂ"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪᄃ"),l1l111_l1_ (u"ࠩ࠮ࠫᄄ"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᄅ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩᄆ"),l1l111_l1_ (u"ࠬ࠭ᄇ"),headers,True,l1l111_l1_ (u"࠭ࠧᄈ"),l1l111_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ᄉ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᄊ"),html,re.DOTALL)
	if l11_l1_ and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᄋ"),block,re.DOTALL)
		l11lllll1_l1_,l11ll1ll1_l1_ = [],[]
		for category,title in items:
			l11lllll1_l1_.append(category)
			l11ll1ll1_l1_.append(title)
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪᄌ"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠫࠬᄍ")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩᄎ")+search+l1l111_l1_ (u"࠭ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪᄏ")+category+l1l111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃ࠱ࠨᄐ")
	l1lll11_l1_(url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᄑ"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᄒ"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩᄓ"),l1l111_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬᄔ")]
	if l1l111_l1_ (u"ࠬࡅࠧᄕ") in url: url = url.split(l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪᄖ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫᄗ"),1)
	if filter==l1l111_l1_ (u"ࠨࠩᄘ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪᄙ"),l1l111_l1_ (u"ࠪࠫᄚ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᄛ"))
	if type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩᄜ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"࠭࠽ࠨᄝ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠧ࠾ࠩᄞ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪᄟ")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬᄠ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬᄡ")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧᄢ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧᄣ"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪᄤ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩᄥ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᄦ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᄧ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᄨ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᄩ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠬ࠭ᄪ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᄫ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠧࠨᄬ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬᄭ")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᄮ"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ᄯ"),l1lllll1_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄰ"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬᄱ")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬᄲ"),l1lllll1_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᄳ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᄴ"),l1l111_l1_ (u"ࠩࠪᄵ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡦࡲࡺࠨᄶ"),l1l111_l1_ (u"ࠫࠬᄷ"),headers,l1l111_l1_ (u"ࠬ࠭ᄸ"),l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᄹ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡂ࡬ࡤࡼࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡄࡢࡶࡤࠬ࠳࠰࠿ࠪࡈ࡬ࡰࡹ࡫ࡲࡘࡱࡵࡨࠬᄺ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡥࡣࡷࡥ࠲࡬࡯ࡳࡖࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࡭࠸ࠧᄻ"),block,re.DOTALL)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠩสาฯ๐วาࠢࠪᄼ"),l1l111_l1_ (u"ࠪࠫᄽ"))
		name = name.replace(l1l111_l1_ (u"ุࠫ์ษࠡษ็ษ๋ะวอࠩᄾ"),l1l111_l1_ (u"ࠬอไิ่ฬࠫᄿ"))
		items = re.findall(l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᅀ"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠧ࠾ࠩᅁ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬᅂ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩᅃ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅄ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬᅅ"),l1lllll1_l1_,201)
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅆ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧᅇ"),l1lllll1_l1_,205,l1l111_l1_ (u"ࠧࠨᅈ"),l1l111_l1_ (u"ࠨࠩᅉ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪᅊ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᅋ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧᅌ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᅍ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩᅎ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᅏ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅐ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫᅑ")+name,l1lllll1_l1_,204,l1l111_l1_ (u"ࠪࠫᅒ"),l1l111_l1_ (u"ࠫࠬᅓ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			option = option.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨᅔ"),l1l111_l1_ (u"࠭ࠧᅕ"))
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩᅖ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪᅗ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫᅘ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬᅙ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᅚ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨᅛ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨᅜ")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪᅝ")+name
			if type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩᅞ"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅟ"),l1lllll_l1_+title,url,204,l1l111_l1_ (u"ࠪࠫᅠ"),l1l111_l1_ (u"ࠫࠬᅡ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩᅢ") and l1l11111_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨᅣ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᅤ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬᅥ")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅦ"),l1lllll_l1_+title,l1llllll_l1_,201)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅧ"),l1lllll_l1_+title,url,205,l1l111_l1_ (u"ࠫࠬᅨ"),l1l111_l1_ (u"ࠬ࠭ᅩ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"࠭࠽ࠧࠩᅪ"),l1l111_l1_ (u"ࠧ࠾࠲ࠩࠫᅫ"))
	filters = filters.strip(l1l111_l1_ (u"ࠨࠨࠪᅬ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠩࡀࠫᅭ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠬᅮ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭ᅯ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭ᅰ")
	l1l11lll_l1_ = [l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᅱ"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ᅲ"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧᅳ"),l1l111_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᅴ")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬᅵ")
		if l1l111_l1_ (u"ࠫࠪ࠭ᅶ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᅷ") and value!=l1l111_l1_ (u"࠭࠰ࠨᅸ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫᅹ")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᅺ") and value!=l1l111_l1_ (u"ࠩ࠳ࠫᅻ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬᅼ")+key+l1l111_l1_ (u"ࠫࡂ࠭ᅽ")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩᅾ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨᅿ")+key+l1l111_l1_ (u"ࠧ࠾ࠩᆀ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬᆁ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫᆂ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭ᆃ"),l1l111_l1_ (u"ࠫࡂ࠭ᆄ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ᆅ"),l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧᆆ"))
	return l1l1l111_l1_
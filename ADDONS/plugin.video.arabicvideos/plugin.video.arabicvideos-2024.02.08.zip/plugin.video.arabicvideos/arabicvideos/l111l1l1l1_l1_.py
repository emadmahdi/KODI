# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭⎪")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡍࡖࡠࠩ⎫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==220: l1lll_l1_ = l1l1l11_l1_()
	elif mode==221: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==222: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==223: l1lll_l1_ = PLAY(url)
	elif mode==224: l1lll_l1_ = l1l1ll1l_l1_(url)
	elif mode==229: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎬"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⎭"),l1l111_l1_ (u"࠭ࠧ⎮"),229,l1l111_l1_ (u"ࠧࠨ⎯"),l1l111_l1_ (u"ࠨࠩ⎰"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⎱"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⎲"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⎳"),l1l111_l1_ (u"ࠬ࠭⎴"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⎵"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ⎶"),l1l111_l1_ (u"ࠨࠩ⎷"),l1l111_l1_ (u"ࠩࠪ⎸"),l1l111_l1_ (u"ࠪࠫ⎹"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⎺"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࠠࡪ࠯࡫ࡳࡲ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⎻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⎼"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠧ࠽࠱࡬ࡂࠬ⎽") in title: title = title.split(l1l111_l1_ (u"ࠨ࠾࠲࡭ࡃ࠭⎾"))[1]
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎿"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⏀")+l1lllll_l1_+title,l1ll1ll_l1_,222)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⏁"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⏂"),l1l111_l1_ (u"࠭ࠧ⏃"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡣࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴࠨ⏄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡲࡧࡥࠥࡨࡤࡣࠤࡁࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⏅"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏆"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⏇")+l1lllll_l1_+title,l1ll1ll_l1_,221)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⏈"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⏉"),l1l111_l1_ (u"࠭ࠧ⏊"),9999)
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⏋"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡱࡱ࠭⏌") not in l1ll1ll_l1_: continue
			if not l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠩ࠲ࠫ⏍")): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏎"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⏏")+l1lllll_l1_+title,l1ll1ll_l1_,221)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⏐"),url,l1l111_l1_ (u"࠭ࠧ⏑"),l1l111_l1_ (u"ࠧࠨ⏒"),l1l111_l1_ (u"ࠨࠩ⏓"),l1l111_l1_ (u"ࠩࠪ⏔"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⏕"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡹ࡟ࡴࡥࡵࡳࡱࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⏖"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⏗"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏘"),l1lllll_l1_+title,l1ll1ll_l1_,224)
	return
def l1l1ll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏙"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ⏚"),url,221)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ⏛"),l1l111_l1_ (u"ࠪࠫ⏜"),l1l111_l1_ (u"ࠫࠬ⏝"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⏞"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡶࡤࡢࡲࡦࡼࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳࠨ⏟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⏠"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ⏡"): name = title
			else:
				title = title + l1l111_l1_ (u"ࠩࠣࠤ࠿ࠦࠠࠨ⏢") + l1l111_l1_ (u"ࠪๅ้ะัࠡࠩ⏣") + name
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏤"),l1lllll_l1_+title,l1ll1ll_l1_,221)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠬ࠷ࠧ⏥")):
	if l1llllll1_l1_==l1l111_l1_ (u"࠭ࠧ⏦"): l1llllll1_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ⏧")
	if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ⏨") in url or l1l111_l1_ (u"ࠩࡂࠫ⏩") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠪࠪࠬ⏪")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠫࡄ࠭⏫")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫ⏬") + l1llllll1_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⏭"),l1l111_l1_ (u"ࠧࠨ⏮"),l1l111_l1_ (u"ࠨࠩ⏯"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⏰"))
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫ⏱") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡪࡡࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ⏲"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⏳") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡯ࡸ࡮࠰ࡧࡦࡸ࡯ࡶࡵࡨࡰࠥࡵࡷ࡭࠯ࡦࡥࡷࡵࡵࡴࡧ࡯ࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ⏴"),html,re.DOTALL)
		block = l11llll_l1_[0]
	else:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⏵"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⏶"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱ࠪ⏷") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࠬ⏸") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⏹"),l1lllll_l1_+title,l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠬ࠵ࠧ⏺")),223,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏻"),l1lllll_l1_+title,l1ll1ll_l1_,221,l1ll1l_l1_)
	if len(items)>=16:
		l11l1l1l11_l1_ = [l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ⏼"),l1l111_l1_ (u"ࠨ࠱ࡷࡺࠬ⏽"),l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ⏾"),l1l111_l1_ (u"ࠪ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭⏿")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l11_l1_):
			for n in range(0,1000,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␀"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ␁")+str(j),url,221,l1l111_l1_ (u"࠭ࠧ␂"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␃"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ␄")+str(i),url,221,l1l111_l1_ (u"ࠩࠪ␅"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␆"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ␇")+str(1),url,221,l1l111_l1_ (u"ࠬ࠭␈"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␉"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭␊")+str(n),url,221,l1l111_l1_ (u"ࠨࠩ␋"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␌"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ␍")+str(1),url,221)
	return
def PLAY(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ␎"),l1l111_l1_ (u"ࠬ࠭␏"),l1l111_l1_ (u"࠭ࠧ␐"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭␑"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ␒"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1l111ll1_l1_,l1l1l11ll_l1_ = l1l111_l1_ (u"ࠩࠪ␓"),l1l111_l1_ (u"ࠪࠫ␔")
	l111l1l111_l1_,l111l11l11_l1_ = html,html
	l111l11lll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡮࡯ࡸࡡࡧࡰࠥࡧࡰࡪࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ␕"),html,re.DOTALL)
	if l111l11lll_l1_:
		for l1ll1ll_l1_ in l111l11lll_l1_:
			if l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭␖") in l1ll1ll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			elif l1l111_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ␗") in l1ll1ll_l1_: l1l1l11ll_l1_ = l1ll1ll_l1_
		if l1l111ll1_l1_!=l1l111_l1_ (u"ࠧࠨ␘"): l111l1l111_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l111ll1_l1_,l1l111_l1_ (u"ࠨࠩ␙"),l1l111_l1_ (u"ࠩࠪ␚"),l1l111_l1_ (u"ࠪࠫ␛"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ␜"))
		if l1l1l11ll_l1_!=l1l111_l1_ (u"ࠬ࠭␝"): l111l11l11_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l1l11ll_l1_,l1l111_l1_ (u"࠭ࠧ␞"),l1l111_l1_ (u"ࠧࠨ␟"),l1l111_l1_ (u"ࠨࠩ␠"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ␡"))
	l111l1l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ␢"),l111l1l111_l1_,re.DOTALL)
	if l111l1l11l_l1_:
		l1lllll1_l1_ = l111l1l11l_l1_[0]
		if l1lllll1_l1_!=l1l111_l1_ (u"ࠫࠬ␣") and l1l111_l1_ (u"ࠬࡻࡰ࡭ࡱࡤࡨࡪࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ␤") in l1lllll1_l1_ and l1l111_l1_ (u"࠭࠯ࡀ࡫ࡧࡁࡤ࠭␥") not in l1lllll1_l1_:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ␦"),l1l111_l1_ (u"ࠨࠩ␧"),l1l111_l1_ (u"ࠩࠪ␨"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ␩"))
			l111l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ␪"),l11l1ll1_l1_,re.DOTALL)
			if l111l11l1l_l1_:
				for l1ll1ll_l1_,l111l1ll_l1_ in l111l11l1l_l1_:
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࡫ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࡳࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣࠬ␫")+l111l1ll_l1_)
			else:
				server = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ␬"))[2]
				l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ␭")+server+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ␮"))
		elif l1lllll1_l1_!=l1l111_l1_ (u"ࠩࠪ␯"):
			server = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ␰"))[2]
			l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ␱")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭␲"))
	l111l1ll11_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡣࡥࡰࡪࠦࡣ࡭ࡣࡶࡷࡂࠨࡤ࡭ࡵࡢࡸࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ␳"),l111l11l11_l1_,re.DOTALL)
	if l111l1ll11_l1_:
		l111l1ll11_l1_ = l111l1ll11_l1_[0]
		l111l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶࡧࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ␴"),l111l1ll11_l1_,re.DOTALL)
		if l111l11ll1_l1_:
			for l111l1ll_l1_,l1ll1ll_l1_ in l111l11ll1_l1_:
				if l1l111_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ␵") not in l1ll1ll_l1_: continue
				if l1ll1ll_l1_.count(l1l111_l1_ (u"ࠩ࠲ࠫ␶"))>=2:
					server = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ␷"))[2]
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ␸")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡢࡱࡵ࠺࡟ࡠࠩ␹")+l111l1ll_l1_)
	l111l1l1ll_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_:
		l111l1l1ll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l1l1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ␺"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ␻"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ␼"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ␽"),l1l111_l1_ (u"ࠪ࠯ࠬ␾"))
	html = l1l1llll_l1_(l111l11l_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬ␿"),l1l111_l1_ (u"ࠬ࠭⑀"),l1l111_l1_ (u"࠭ࠧ⑁"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ⑂"))
	token = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡶࡲ࡯ࡪࡴࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⑃"),html,re.DOTALL)
	if token:
		url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡣࡹࡵ࡫ࡦࡰࡀࠫ⑄")+token[0]+l1l111_l1_ (u"ࠪࠪࡶࡃࠧ⑅")+l1lll1ll_l1_
		l1lll11_l1_(url)
	return
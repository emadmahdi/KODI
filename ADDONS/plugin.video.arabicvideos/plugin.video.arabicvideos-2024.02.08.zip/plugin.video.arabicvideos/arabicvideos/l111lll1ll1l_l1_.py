# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭征")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ徂")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l11l111ll1l1_l1_(url)
	elif mode==146: l1lll_l1_ = l111lll11l11_l1_(url)
	elif mode==147: l1lll_l1_ = l11l1111l1ll_l1_()
	elif mode==148: l1lll_l1_ = l11l1111ll1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徃"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ径"),l1l111_l1_ (u"ࠩࠪ待"),149,l1l111_l1_ (u"ࠪࠫ徆"),l1l111_l1_ (u"ࠫࠬ徇"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ很"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徉"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ徊")+l1l111_l1_ (u"ࠨࡡ࡜ࡘࡈࡥࠧ律")+l1l111_l1_ (u"่ࠩ์ฬู่ࠡษัฮฬื็ศࠢส่๊ฮัๆฮࠪ後"),l1l111_l1_ (u"ࠪࠫ徍"),290)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徎"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ徏")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬ๊้ࠦฬํ์อ࠭徐"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭徑"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ徒"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ従")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ徔"),l111l1_l1_,144,l1l111_l1_ (u"ࠫࠬ徕"),l1l111_l1_ (u"ࠬ࠭徖"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ得"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徘"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ徙")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊ำส้๋ࠣห้ืววฮࠪ徚"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ徛"),146)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ徜"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ徝"),l1l111_l1_ (u"࠭ࠧ從"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徟"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ徠")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠใ่๋หฯูࠦาสํอࠬ御"),l1l111_l1_ (u"ࠪࠫ徢"),147)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徣"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ徤")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣวั์ศ๋หࠪ徥"),l1l111_l1_ (u"ࠧࠨ徦"),148)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ徧"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ徨")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭復"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ循"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ徫"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ徬")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤฬาๆษ์ฬࠫ徭"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡰࡳࡻ࡯ࡥࠨ微"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ徯"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ徰")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืึำ๊ศฬࠣ฽ึฮ๊สࠩ徱"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิำะ๎ฮ࠭徲"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徳"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ徴")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะฺࠠำห๎ฮ࠭徵"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้๊ำๅࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ徶"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ德"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭徸")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ徹"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ徺"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徻"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ徼")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡๅสีฯ๎ๆࠨ徽"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ่อัห๊้ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ徾"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徿"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ忀")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤำ฽ศสࠢส่๊ืฬฺ์ฬࠫ忁"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ใาส็หฦ࠱วๅใูหห๐ษࠬะฺฬฮ࠱วๅฮ่฽ฮࠬࡳࡱ࠿ࡆࡅࡎ࡙ࡁࡩࡃࡅࠫ忂"),144)
	return
def l11l1111l1ll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ心"))
	return
def l11l1111ll1l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ忄"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111lll11l11_l1_(url):
	html,l1llll1lll_l1_,data = l11l11111lll_l1_(url)
	dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ必")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忆")][l1l111_l1_ (u"ࠬࡺࡡࡣࡵࠪ忇")]
	for l1l111lll1_l1_ in range(len(dd)):
		item = dd[l1l111lll1_l1_]
		l111llll1lll_l1_(item,url,str(l1l111lll1_l1_))
	l111lll1l1ll_l1_ = dd[0][l1l111_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ忈")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ忉")][l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忊")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ忋")]
	s = 0
	for l1l111lll1_l1_ in range(len(l111lll1l1ll_l1_)):
		item = l111lll1l1ll_l1_[l1l111lll1_l1_][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ忌")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭忍")][0]
		if list(item[l1l111_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ忎")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ忏")].keys())[0]==l1l111_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ忐"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_ = l11l111llll1_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣีฬฬฬสࠢࠪ忑")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ忒"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠪࠫ忓"),str(l1l111lll1_l1_))
	key = re.findall(l1l111_l1_ (u"ࠫࠧ࡯࡮࡯ࡧࡵࡸࡺࡨࡥࡂࡲ࡬ࡏࡪࡿࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ忔"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ忕")+key[0]
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11111lll_l1_(l1lllll1_l1_)
	for l1llll1l1111_l1_ in range(3,4):
		dd = l1llll1lll_l1_[l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ忖")][l1llll1l1111_l1_][l1l111_l1_ (u"ࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ志")][l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ忘")]
		for l1l111lll1_l1_ in range(len(dd)):
			item = dd[l1l111lll1_l1_]
			if l1l111_l1_ (u"ࠩ࡜ࡳࡺ࡚ࡵࡣࡧࠣࡔࡷ࡫࡭ࡪࡷࡰࠫ忙") in str(item): continue
			l111llll1lll_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠪࠫ忚"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭忛"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ応"),l1l111_l1_ (u"࠭ࠧ忝"))
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11111lll_l1_(url,data)
	l1l11ll111_l1_,l111lll111ll_l1_ = l1l111_l1_ (u"ࠧࠨ忞"),l1l111_l1_ (u"ࠨࠩ忟")
	owner = re.findall(l1l111_l1_ (u"ࠩࠥࡳࡼࡴࡥࡳࡐࡤࡱࡪࠨ࠮ࠫࡁࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ忠"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ忡"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡨࡢࡰࡱࡩࡱࡓࡥࡵࡣࡧࡥࡹࡧࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡲࡻࡳ࡫ࡲࡖࡴ࡯ࡷࠧࡀ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ忢"),html,re.DOTALL)
	if owner:
		l1l11ll111_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ忣")+owner[0][0]+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ忤")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ忥") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ忦") in url: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ忧"),l1lllll_l1_+l1l11ll111_l1_,l1ll1ll_l1_,144)
	l111lll1l111_l1_ = [l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ忨"),l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ忩"),l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ忪"),l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ快"),l1l111_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ忬"),l1l111_l1_ (u"ࠨࡵࡶࡁࠬ忭"),l1l111_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ忮"),l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ忯"),l1l111_l1_ (u"ࠫࡧࡶ࠽ࠨ忰"),l1l111_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪ࠽ࠨ忱")]
	l111lll111l1_l1_ = not any(value in url for value in l111lll1l111_l1_)
	if l111lll111l1_l1_ and l1l11ll111_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"࠭วๅสะฯࠬ忲")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠧใ๊สส๊ࠦวๅฬื฾๏๊ࠧ忳")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠨษ็ๅ๏ี๊้้สฮࠬ忴")
		l1l1l11ll1ll_l1_ = l1l111_l1_ (u"ࠩส่็์่ศฬࠪ念")
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ忶"),l1lllll_l1_+l1l11ll111_l1_,url,9999)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨศฮอࠥࠫ忷") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ忸"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"࠭ࠧ忹"),l1l111_l1_ (u"ࠧࠨ忺"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ忻"))
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ็๎วว็ࠣห้ะิ฻์็ࠦࠬ忼") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ忽"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ忾"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆไ๎ิ๐่่ษอࠦࠬ忿") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怀"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ态"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ怂") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ怃"),l1lllll_l1_+l1l1l11ll1ll_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭怄"),144)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡓࡦࡣࡵࡧ࡭ࠨࠧ怅") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怆"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"࠭ࠧ怇"),l1l111_l1_ (u"ࠧࠨ怈"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ怉"))
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹࡹࠢࠨ怊") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ怋"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ怌"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡗ࡫ࡧࡩࡴࡹࠢࠨ怍") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怎"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ怏"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭怐") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ怑"),l1lllll_l1_+l1l1l11ll1ll_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭怒"),144)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ怓"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ怔"),l1l111_l1_ (u"࠭ࠧ怕"),9999)
	if l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭怖") in url:
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ怗")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ怘")][l1l111_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ怙")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怚")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ怛")]
		l111lll11111_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ怜") in list(dd[i].keys()):
				l111ll1lllll_l1_ = dd[i][l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭思")]
				length = len(str(l111ll1lllll_l1_))
				if length>l111lll11111_l1_:
					l111lll11111_l1_ = length
					l111lll111ll_l1_ = l111ll1lllll_l1_
		if l111lll11111_l1_==0: return
	elif l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ怞") in url or l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂ࡯ࡪࡿ࠽ࠨ怟") in url or l1l111_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡃࡰ࡫ࡹ࠾ࠩ怠") in url or l1l111_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ怡") in url or l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭怢") in url or url==l111l1_l1_:
		l111llll1ll1_l1_ = []
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ怣"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ怤"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ急"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ怦"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ性"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠳࠱࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡤࡦࡱ࡫ࡔࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ怨"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ怩"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱ࡛ࡦࡺࡣࡩࡐࡨࡼࡹࡘࡥࡴࡷ࡯ࡸࡸ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠩࡠࠦ怪"))
		l111lll11lll_l1_,l111lll111ll_l1_ = l111ll1llll1_l1_(l1llll1lll_l1_,l1l111_l1_ (u"ࠧࠨ怫"),l111llll1ll1_l1_)
	if not l111lll111ll_l1_:
		try:
			dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ怬")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ怭")][l1l111_l1_ (u"ࠪࡸࡦࡨࡳࠨ怮")]
			l1lllll1l111_l1_ = l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ怯") in url or l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ怰") in url or l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ怱") in url
			l111llll1111_l1_ = l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่ๆ๐ฯ๋๊๊หฯࠨࠧ怲") in html or l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ怳") in html or l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊โ็๊สฮࠧ࠭怴") in html
			l111lll1llll_l1_ = l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࡜ࡩࡥࡧࡲࡷࠧ࠭怵") in html or l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠤࠪ怶") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡄࡪࡤࡲࡳ࡫࡬ࡴࠤࠪ怷") in html
			if l1lllll1l111_l1_ and (l111llll1111_l1_ or l111lll1llll_l1_):
				for l1l111lll1_l1_ in range(len(dd)):
					if l1l111_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ怸") not in list(dd[l1l111lll1_l1_].keys()): continue
					l111lll1l1ll_l1_ = dd[l1l111lll1_l1_][l1l111_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ怹")]
					try: l111lll11ll1_l1_ = l111lll1l1ll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ怺")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ总")][l1l111_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ怼")][l1l111_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怽")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡚ࡹࡱࡧࡖࡹࡧࡓࡥ࡯ࡷࡌࡸࡪࡳࡳࠨ怾")][l1l111lll1_l1_]
					except: l111lll11ll1_l1_ = l111lll1l1ll_l1_
					try: l1ll1ll_l1_ = l111lll11ll1_l1_[l1l111_l1_ (u"࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ怿")][l1l111_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ恀")][l1l111_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭恁")][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭恂")]
					except: continue
					if   l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ恃")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ恄")		in url: l111lll1l1ll_l1_ = dd[l1l111lll1_l1_] ; break
					elif l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ恅")	in l1ll1ll_l1_	and l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ恆")	in url: l111lll1l1ll_l1_ = dd[l1l111lll1_l1_] ; break
					elif l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ恇")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ恈")		in url: l111lll1l1ll_l1_ = dd[l1l111lll1_l1_] ; break
					else: l111lll1l1ll_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠩࡥࡴࡂ࠭恉") in url: l111lll1l1ll_l1_ = dd[index]
			else: l111lll1l1ll_l1_ = dd[0]
			l111lll111ll_l1_ = l111lll1l1ll_l1_[l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ恊")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ恋")]
		except: pass
	if not l111lll111ll_l1_: return
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ恌"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ恍"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ恎"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ恏"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ恐"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ恑"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ恒"))
	if l1l111_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ恓") not in url: l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡹࡵࡣࡏࡨࡲࡺ࠭࡝࡜ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡕࡻࡳࡩࡘࡻࡢࡎࡧࡱࡹࡎࡺࡥ࡮ࡵࠪࡡࠧ恔"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ恕"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ恖"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ恗"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ恘"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ恙"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ恚"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ恛"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ恜"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩࠦ恝"))
	l11l11l1ll1_l1_ = l111ll1ll1l_l1_(l1l111_l1_ (u"ࡷࠪ็้ࠦโ้ษษ้ࠥอไหึ฽๎้࠭恞"))
	l11l11111ll_l1_ = l111ll1ll1l_l1_(l1l111_l1_ (u"ࡸ่๊ࠫࠠศๆไ๎ิ๐่่ษอࠫ恟"))
	l111lll11l1l_l1_ = l111ll1ll1l_l1_(l1l111_l1_ (u"ࡹ้ࠬไࠡษ็ๆ๋๎วหࠩ恠"))
	l1l1ll111l11_l1_ = [l11l11l1ll1_l1_,l11l11111ll_l1_,l111lll11l1l_l1_,l1l111_l1_ (u"ࠬࡇ࡬࡭ࠢࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ恡"),l1l111_l1_ (u"࠭ࡁ࡭࡮ࠣࡺ࡮ࡪࡥࡰࡵࠪ恢"),l1l111_l1_ (u"ࠧࡂ࡮࡯ࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭恣")]
	l111lll1l11l_l1_,l111lll11ll1_l1_ = l111ll1llll1_l1_(l111lll111ll_l1_,index,l111llll1ll1_l1_)
	if l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭恤") in str(type(l111lll11ll1_l1_)) and any(value in str(l111lll11ll1_l1_[0]) for value in l1l1ll111l11_l1_): del l111lll11ll1_l1_[0]
	for index2 in range(len(l111lll11ll1_l1_)):
		l111llll1ll1_l1_ = []
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ恥"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ恦"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ恧"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ恨"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ恩"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ恪"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡧࡢ࡯ࡨࡇࡦࡸࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡭ࡡ࡮ࡧࠪࡡࠧ恫"))
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࠨ恬"))
		l111lll11lll_l1_,item = l111ll1llll1_l1_(l111lll11ll1_l1_,index2,l111llll1ll1_l1_)
		l111llll1lll_l1_(item,url,str(index2))
		if l111lll11lll_l1_==l1l111_l1_ (u"ࠪ࠸ࠬ恭"):
			try:
				hh = item[l1l111_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫ恮")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭息")][l1l111_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭恰")][l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭恱")]
				for l111llllllll_l1_ in range(len(hh)):
					l1l1ll1l1l1l_l1_ = hh[l111llllllll_l1_]
					l111llll1lll_l1_(l1l1ll1l1l1l_l1_)
			except: pass
	l111lllll1_l1_ = False
	if l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ恲") not in url and l111lll1l11l_l1_==l1l111_l1_ (u"ࠩ࠻ࠫ恳"): l111lllll1_l1_ = True
	if l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ恴") in l1l11llll_l1_: l11l111l111l_l1_,key,l111lll1111l_l1_,l11l1111ll11_l1_,token,l11l1111l11l_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ恵"))
	else: l11l111l111l_l1_,key,l111lll1111l_l1_,l11l1111ll11_l1_,token,l11l1111l11l_l1_ = l1l111_l1_ (u"ࠬ࠭恶"),l1l111_l1_ (u"࠭ࠧ恷"),l1l111_l1_ (u"ࠧࠨ恸"),l1l111_l1_ (u"ࠨࠩ恹"),l1l111_l1_ (u"ࠩࠪ恺"),l1l111_l1_ (u"ࠪࠫ恻")
	l1lllll1_l1_,l111l1lll1_l1_ = l1l111_l1_ (u"ࠫࠬ恼"),l1l111_l1_ (u"ࠬ࠭恽")
	if menuItemsLIST:
		l111lll1lll1_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"࠭ࡃࡉࡐࡏࠫ恾") in l111lll1lll1_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠧࡄࡊࡄࡒࡓࡋࡌࡔࠩ恿")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠨࡗࡖࡉࡗ࠭悀") in l111lll1lll1_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ悁")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ悂") in l111lll1lll1_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠫࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ悃")
	if l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡸࠨࠧ悄") in html and l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭悅") not in url and not l111lllll1_l1_ and l1l111_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥࠩ悆") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ悇")+l111lll1111l_l1_
	elif l1l111_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ悈") in html and l1l111_l1_ (u"ࠪࡦࡵࡃࠧ悉") not in url and l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ悊") in url or l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ悋") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ悌")+key
	elif l1l111_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ悍") in html and l1l111_l1_ (u"ࠨࡤࡳࡁࠬ悎") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭悏")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悐"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ悑"),l1lllll1_l1_,144,l111l1lll1_l1_,l1l111_l1_ (u"ࠬ࠭悒"),l1l11llll_l1_)
	return
def l111ll1llll1_l1_(l1l1llll111l_l1_,l1l1lllll111_l1_,l111llllll11_l1_):
	l1llll1lll_l1_ = l1l1llll111l_l1_
	l111lll111ll_l1_,index = l1l1llll111l_l1_,l1l1lllll111_l1_
	l111lll11ll1_l1_,index2 = l1l1llll111l_l1_,l1l1lllll111_l1_
	item,l111lll1ll11_l1_ = l1l1llll111l_l1_,l1l1lllll111_l1_
	count = len(l111llllll11_l1_)
	for l1l111lll1_l1_ in range(count):
		try:
			out = eval(l111llllll11_l1_[l1l111lll1_l1_])
			return str(l1l111lll1_l1_+1),out
		except: pass
	return l1l111_l1_ (u"࠭ࠧ悓"),l1l111_l1_ (u"ࠧࠨ悔")
def l11l111llll1_l1_(item):
	try: l11l1111l1l1_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠨࠩ悕"),l1l111_l1_ (u"ࠩࠪ悖"),l1l111_l1_ (u"ࠪࠫ悗"),l1l111_l1_ (u"ࠫࠬ悘"),l1l111_l1_ (u"ࠬ࠭悙"),l1l111_l1_ (u"࠭ࠧ悚"),l1l111_l1_ (u"ࠧࠨ悛")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_ = False,l1l111_l1_ (u"ࠨࠩ悜"),l1l111_l1_ (u"ࠩࠪ悝"),l1l111_l1_ (u"ࠪࠫ悞"),l1l111_l1_ (u"ࠫࠬ悟"),l1l111_l1_ (u"ࠬ࠭悠"),l1l111_l1_ (u"࠭ࠧ悡"),l1l111_l1_ (u"ࠧࠨ悢")
	l111lll1ll11_l1_ = item[l11l1111l1l1_l1_]
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡸࡲࡵࡲࡡࡺࡣࡥࡰࡪ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ患"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡪࡴࡸ࡭ࡢࡶࡷࡩࡩ࡚ࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ悤"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ悥"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ悦"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ悧"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ您"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ悩"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ悪"))
	l111lll11lll_l1_,title = l111ll1llll1_l1_(item,l111lll1ll11_l1_,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ悫"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ悬"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ悭"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ悮"))
	l111lll11lll_l1_,l1ll1ll_l1_ = l111ll1llll1_l1_(item,l111lll1ll11_l1_,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ悯"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ悰"))
	l111lll11lll_l1_,l1ll1l_l1_ = l111ll1llll1_l1_(item,l111lll1ll11_l1_,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ悱"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ悲"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ悳"))
	l111lll11lll_l1_,count = l111ll1llll1_l1_(item,l111lll1ll11_l1_,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ悴"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ悵"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ悶"))
	l111lll11lll_l1_,l1l1lll111_l1_ = l111ll1llll1_l1_(item,l111lll1ll11_l1_,l111llll1ll1_l1_)
	if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ悷") in l1l1lll111_l1_: l1l1lll111_l1_,l11l111l11ll_l1_ = l1l111_l1_ (u"ࠨࠩ悸"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ悹")
	if l1l111_l1_ (u"้ࠪออิาࠩ悺") in l1l1lll111_l1_: l1l1lll111_l1_,l11l111l11ll_l1_ = l1l111_l1_ (u"ࠫࠬ悻"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭悼")
	if l1l111_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭悽") in list(l111lll1ll11_l1_.keys()):
		l11l111l1lll_l1_ = str(l111lll1ll11_l1_[l1l111_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ悾")])
		if l1l111_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ悿") in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠩࠧ࠾ࠬ惀")
		if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠡࡐࡒ࡛ࠬ惁") in l11l111l1lll_l1_: l11l111l11ll_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ惂")
		if l1l111_l1_ (u"ࠬࡈࡵࡺࠩ惃") in l11l111l1lll_l1_ or l1l111_l1_ (u"࠭ࡒࡦࡰࡷࠫ惄") in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠫ情")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡶ่ࠩฬฬฺัࠨ惆")) in l11l111l1lll_l1_: l11l111l11ll_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ惇")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡸูࠫืวยࠩ惈")) in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠨ惉")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡺ࠭วิฬษะฬืࠧ惊")) in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"࠭ࠤࠥ࠼ࠪ惋")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ惌")) in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠨࠦ࠽ࠫ惍")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ惎") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠪࡃࠬ惏"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ惐") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ惑")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1111l111_l1_: title = l11l1111l111_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ惒")+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠧ࠭ࠩ惓"),l1l111_l1_ (u"ࠨࠩ惔"))
	count = count.replace(l1l111_l1_ (u"ࠩ࠯ࠫ惕"),l1l111_l1_ (u"ࠪࠫ惖"))
	count = re.findall(l1l111_l1_ (u"ࠫࡡࡪࠫࠨ惗"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠬ࠭惘")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_
def l111llll1lll_l1_(item,url=l1l111_l1_ (u"࠭ࠧ惙"),index=l1l111_l1_ (u"ࠧࠨ惚")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_ = l11l111llll1_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ惛") in str(item): return
	elif l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭惜") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ惝") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ惞") in url or l1l111_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ惟") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"࠭࠽࠾࠿ࠣࠫ惠")+title+l1l111_l1_ (u"ࠧࠡ࠿ࡀࡁࠬ惡")
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭惢"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ惣"),9999)
	elif title and l1l111_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ惤") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ惥"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭惦"),9999)
	elif l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ惧") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ惨"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l11l111l11ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭惩"),l1lllll_l1_+l11l111l11ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ惪") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ惫") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ惬") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ惭") not in l1ll1ll_l1_:
			l11l1111llll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭惮"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ惯")+l11l1111llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ惰"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ惱")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ惲")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ想"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ惴"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	else:
		type = l1l111_l1_ (u"࠭ࠧ惵")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ惶"),l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ惷"),l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ惸"),l1l111_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭惹"),l1l111_l1_ (u"ࠫࡸࡹ࠽ࠨ惺"),l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ惻")]):
			if l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ惼")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡥ࠲ࠫ惽") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠨࡅࡋࡒࡑ࠭惾")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭惿")
			if l1l111_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ愀") in l1ll1ll_l1_: type = l1l111_l1_ (u"࡚࡙ࠫࡅࡓࠩ愁")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ愂")
			index,l111lll1l1l1_l1_ = l1l111_l1_ (u"࠭ࠧ愃"),l1l111_l1_ (u"ࠧࠨ愄")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ愅"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l11l11111lll_l1_(url,data=l1l111_l1_ (u"ࠩࠪ愆"),request=l1l111_l1_ (u"ࠪࠫ愇")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭愈"))
	if request==l1l111_l1_ (u"ࠬ࠭愉"): request = l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭愊")
	l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ愋"):l11ll1l1l1_l1_,l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ愌"):l1l111_l1_ (u"ࠩࡓࡖࡊࡌ࠽ࡩ࡮ࡀࡥࡷ࠭愍")}
	if l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ愎") in data: l11l111l111l_l1_,key,l111lll1111l_l1_,l11l1111ll11_l1_,token,l11l1111l11l_l1_ = data.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ意"))
	else: l11l111l111l_l1_,key,l111lll1111l_l1_,l11l1111ll11_l1_,token,l11l1111l11l_l1_ = l1l111_l1_ (u"ࠬ࠭愐"),l1l111_l1_ (u"࠭ࠧ愑"),l1l111_l1_ (u"ࠧࠨ愒"),l1l111_l1_ (u"ࠨࠩ愓"),l1l111_l1_ (u"ࠩࠪ愔"),l1l111_l1_ (u"ࠪࠫ愕")
	if l1l111_l1_ (u"ࠫ࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ愖") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭愗")] = {l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ愘"):{l1l111_l1_ (u"ࠢࡩ࡮ࠥ愙"):l1l111_l1_ (u"ࠣࡣࡵࠦ愚"),l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ愛"):l1l111_l1_ (u"࡛ࠥࡊࡈࠢ愜"),l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ愝"):l11l1111ll11_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ愞"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠲ࡵࡷࠫ感"))
	elif l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ愠") in url and l11l111l111l_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ愡"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ愢")] = {l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ愣"):{l1l111_l1_ (u"ࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ愤"):l11l111l111l_l1_,l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ愥"):l1l111_l1_ (u"ࠨࡗࡆࡄࠥ愦"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ愧"):l11l1111ll11_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭愨"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠶ࡳࡪࠧ愩"))
	elif l1l111_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ愪") in url and l11l1111l11l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ愫"):l1l111_l1_ (u"ࠬ࠷ࠧ愬"),l1l111_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ愭"):l11l1111ll11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ愮"):l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ愯")+l11l1111l11l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭愰"),url,l1l111_l1_ (u"ࠪࠫ愱"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ愲"),l1l111_l1_ (u"ࠬ࠭愳"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ愴"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ愵"),url,l1l111_l1_ (u"ࠨࠩ愶"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ愷"),l1l111_l1_ (u"ࠪࠫ愸"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠺ࡴࡩࠩ愹"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ愺"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ愻"),html,re.DOTALL|re.I)
	if tmp: l11l1111ll11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ愼"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ愽"),html,re.DOTALL|re.I)
	if tmp: l11l111l111l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭愾"),html,re.DOTALL|re.I)
	if tmp: l111lll1111l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ愿") in list(cookies.keys()): l11l1111l11l_l1_ = cookies[l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ慀")]
	data = l11l111l111l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ慁")+key+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ慂")+l111lll1111l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ慃")+l11l1111ll11_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ慄")+token+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭慅")+l11l1111l11l_l1_
	if request==l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ慆") and l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ慇") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ慈"),html,re.DOTALL)
		if not l11ll11l1l_l1_: l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ慉"),html,re.DOTALL)
		l11l111l1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ慊"),l11ll11l1l_l1_[0])
	elif request==l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭態") and l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ慌") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ慍"),html,re.DOTALL)
		l11l111l1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ慎"),l11ll11l1l_l1_[0])
	elif l1l111_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ慏") not in html: l11l111l1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ慐"),html)
	else: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ慑")
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ慒"),data)
	return html,l11l111l1ll1_l1_,data
def l11l111ll1l1_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ慓"),l1l111_l1_ (u"ࠪ࠯ࠬ慔"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ慕")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ慖"),l1l111_l1_ (u"࠭ࠫࠨ慗"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ慘")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ慙") in options: l11l1111111l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ慚")
		elif l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ慛") in options: l11l1111111l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ慜")
		elif l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ慝") in options: l11l1111111l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭慞")
		l1llllll_l1_ = l1lllll1_l1_+l11l1111111l_l1_
	else:
		l11l11111111_l1_,l111llll11ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠧࠨ慟")
		l111llll1l1l_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ慠"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ慡"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭慢"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ慣"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ慤")]
		l11l111l1l1l_l1_ = [l1l111_l1_ (u"࠭ࠧ慥"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭慦"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ慧"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ慨"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ慩")]
		l11l111ll111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ慪"),l111llll1l1l_l1_)
		if l11l111ll111_l1_ == -1: return
		l111lllllll1_l1_ = l11l111l1l1l_l1_[l11l111ll111_l1_]
		html,c,data = l11l11111lll_l1_(l1lllll1_l1_+l111lllllll1_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ慫")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ慬")][l1l111_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ慭")][l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ慮")][l1l111_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ慯")][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ慰")][l1l111_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ慱")]
			for l111llll11l1_l1_ in range(len(d)):
				group = d[l111llll11l1_l1_][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ慲")][l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ慳")]
				for l11l111ll1ll_l1_ in range(len(group)):
					l111lll1ll11_l1_ = group[l11l111ll1ll_l1_][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ慴")]
					if l1l111_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭慵") in list(l111lll1ll11_l1_.keys()):
						l1ll1ll_l1_ = l111lll1ll11_l1_[l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ慶")][l1l111_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ慷")][l1l111_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ慸")][l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ慹")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭慺"),l1l111_l1_ (u"ࠧࠧࠩ慻"))
						title = l111lll1ll11_l1_[l1l111_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ慼")]
						title = title.replace(l1l111_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ慽"),l1l111_l1_ (u"ࠪࠫ慾"))
						if l1l111_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ慿") in title: continue
						if l1l111_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ憀") in title:
							title = l1l111_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ憁")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠪ憂") in title: continue
						title = title.replace(l1l111_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭憃"),l1l111_l1_ (u"ࠩࠪ憄"))
						if l1l111_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ憅") in title: continue
						if l1l111_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭憆") in title:
							title = l1l111_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭憇")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ憈") in title: continue
						l11l11111111_l1_.append(escapeUNICODE(title))
						l111llll11ll_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l11l111l1l11_l1_ = l1l111_l1_ (u"ࠧࠨ憉")
		else:
			l11l11111111_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ憊"),l1lllllll_l1_]+l11l11111111_l1_
			l111llll11ll_l1_ = [l1l111_l1_ (u"ࠩࠪ憋"),l111lllll_l1_]+l111llll11ll_l1_
			l11l111lll1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ憌"),l11l11111111_l1_)
			if l11l111lll1l_l1_ == -1: return
			l11l111l1l11_l1_ = l111llll11ll_l1_[l11l111lll1l_l1_]
		if l11l111l1l11_l1_: l1llllll_l1_ = l111l1_l1_+l11l111l1l11_l1_
		elif l111lllllll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111lllllll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
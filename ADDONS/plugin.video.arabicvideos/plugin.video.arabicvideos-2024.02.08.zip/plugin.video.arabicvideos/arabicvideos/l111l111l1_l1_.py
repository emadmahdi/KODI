# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ⒤")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡈࡋࡓࡥࠧ⒥")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ⒦"),l1l111_l1_ (u"ࠪห้้ไࠨ⒧"),l1l111_l1_ (u"ࠫࡳ࠵ࡁࠨ⒨"),l1l111_l1_ (u"ࠬอไๆิํำࠬ⒩"),l1l111_l1_ (u"࠭โึหࠣ฽ู่ࠧ⒪")]
def l11l1ll_l1_(mode,url,text):
	if   mode==430: l1lll_l1_ = l1l1l11_l1_()
	elif mode==431: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==432: l1lll_l1_ = PLAY(url)
	elif mode==433: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==434: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⒫")+text)
	elif mode==435: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⒬")+text)
	elif mode==436: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==437: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==439: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⒭"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵࠪ⒮"),l1l111_l1_ (u"ࠫࠬ⒯"),l1l111_l1_ (u"ࠬ࠭⒰"),l1l111_l1_ (u"࠭ࠧ⒱"),l1l111_l1_ (u"ࠧࠨ⒲"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⒳"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡴ࡯࡯࡫ࡦࡥࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⒴"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬ⒵"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨⒶ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⒷ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭Ⓒ"),l1l111_l1_ (u"ࠧࠨⒹ"),439,l1l111_l1_ (u"ࠨࠩⒺ"),l1l111_l1_ (u"ࠩࠪⒻ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧⒼ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⒽ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨⒾ"),l1l11ll_l1_,435)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓙ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪⓀ"),l1l11ll_l1_,434)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⓛ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⓂ"),l1l111_l1_ (u"ࠪࠫⓃ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓄ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⓅ")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬⓆ"),l1l11ll_l1_,431)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⓇ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⓈ")+l1lllll_l1_+l1l111_l1_ (u"ࠩสๅ้อๅࠡษ๋๊๊ࠥว๋่ࠪⓉ"),l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵ࠴ࠫⓊ"),436)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓋ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⓌ")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠศ๊้ࠤ้อ๊็ࠩⓍ"),l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠮ࡣ࡯ࡰ࠶࠭Ⓨ"),436)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓏ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⓐ")+l1lllll_l1_+l1l111_l1_ (u"ࠪๆฬฬๅสࠢอๅฺ๐ไ๋หࠪⓑ"),l1l11ll_l1_,437)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⓒ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⓓ"),l1l111_l1_ (u"࠭ࠧⓔ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕ࡬ࡸࡪࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡷࡩࡨࠣࠩⓕ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪⓖ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫⓗ"): continue
		if l1l111_l1_ (u"ࠪหํ์ࠠๅษํ๊ࠬⓘ") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓙ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⓚ")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧⓛ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⓜ"),l1l11l11_l1_+l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨⓝ"),l1l111_l1_ (u"ࠩࠪⓞ"),l1l111_l1_ (u"ࠪࠫⓟ"),l1l111_l1_ (u"ࠫࠬⓠ"),l1l111_l1_ (u"ࠬ࠭ⓡ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨⓢ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡲࡴࡴࡩࡤࡣ࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⓣ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠨ࠱ࠪⓤ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ⓥ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡑ࡯ࡳࡵࡆࡵࡳࡵ࡫ࡤࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡶࡨ࡮ࡩ࡯ࡩࡐࡥࡸࡺࡥࡳࠤࠪⓦ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⓧ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l11lll_l1_: continue
		l1ll1ll_l1_ = l1l11l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࠩⓨ")+category+l1l111_l1_ (u"࠭࠽ࠨⓩ")+value
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⓪"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⓫")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l11ll1_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭⓬"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⓭"),url,l1l111_l1_ (u"ࠫࠬ⓮"),l1l111_l1_ (u"ࠬ࠭⓯"),l1l111_l1_ (u"࠭ࠧ⓰"),l1l111_l1_ (u"ࠧࠨ⓱"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⓲"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⓳"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ⓴"),url,431)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࡇࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ⓵"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫ⓶"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		if title in l11lll_l1_: continue
		l1lllll1_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡍࡰࡸ࡬ࡩࡸ࠵ࡋࡦࡻࡶ࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡂ࠭⓷")+l111l1l1l_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⓸"),l1lllll_l1_+title,l1lllll1_l1_,431)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩ⓹")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭⓺"))
	items = []
	if l1l111_l1_ (u"ࠪ࠳࡙࡫ࡲ࡮ࡵ࠱ࡴ࡭ࡶࠧ⓻") in url or l1l111_l1_ (u"ࠫ࠴ࡍࡥࡵ࠰ࡳ࡬ࡵ࠭⓼") in url or l1l111_l1_ (u"ࠬ࠵ࡋࡦࡻࡶ࠲ࡵ࡮ࡰࠨ⓽") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ⓾"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ⓿"),l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ─"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ━")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ│"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ┃"),l1l111_l1_ (u"ࠬ࠭┄"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ┅"))
		html = response.content
		block = html
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ┆"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ┇"),url,l1l111_l1_ (u"ࠩࠪ┈"),l1l111_l1_ (u"ࠪࠫ┉"),l1l111_l1_ (u"ࠫࠬ┊"),l1l111_l1_ (u"ࠬ࠭┋"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ┌"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡏࡤ࡭ࡳ࡙࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡒࡧࡴࡤࡪࡨࡷ࡙ࡧࡢ࡭ࡧࠥࠫ┍"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ┎"),block,re.DOTALL)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭┏"),url,l1l111_l1_ (u"ࠪࠫ┐"),l1l111_l1_ (u"ࠫࠬ┑"),l1l111_l1_ (u"ࠬ࠭┒"),l1l111_l1_ (u"࠭ࠧ┓"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ└"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡖࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠨ┕"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠩ┖"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲࡯࡭ࡢࡩࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┗"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ┘"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ┙"),l1l111_l1_ (u"࠭ว฻่ํอࠬ┚"),l1l111_l1_ (u"ࠧไๆํฬࠬ┛"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ├"),l1l111_l1_ (u"๊ࠩำฬ็ࠧ┝"),l1l111_l1_ (u"้ࠪออัศหࠪ┞"),l1l111_l1_ (u"ࠫ฾ืึࠨ┟"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬ┠"),l1l111_l1_ (u"࠭วๅส๋้ࠬ┡")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠧ࠰ࠩ┢"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ┣"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ┤"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪห้ำไใหࠪ┥") in title:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ┦") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┧"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ┨") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┩"),l1lllll_l1_+title,l1ll1ll_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┪"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	if request!=l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ┫"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡕࡧࡧࡪࡰࡤࡸࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ┬"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ┭"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ┮") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				if title!=l1l111_l1_ (u"࠭ࠧ┯"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┰"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ┱")+title,l1ll1ll_l1_,431)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶ࡬ࡴࡽ࡭ࡰࡴࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ┲"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┳"),l1lllll_l1_+l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅำ์าࠫ┴"),l1ll1ll_l1_,431)
	return
def l1ll1l11_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ┵"))
	l11ll1l_l1_,l11ll11_l1_ = [],[]
	if l1l111_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠯ࡲ࡫ࡴࠬ┶") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ┷"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ┸"),l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ┹"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ┺")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ┻"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭┼"),l1l111_l1_ (u"࠭ࠧ┽"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭┾"))
		html = response.content
		l11ll11_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ┿"),url,l1l111_l1_ (u"ࠩࠪ╀"),l1l111_l1_ (u"ࠪࠫ╁"),l1l111_l1_ (u"ࠫࠬ╂"),l1l111_l1_ (u"ࠬ࠭╃"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ╄"))
		html = response.content
		l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ╅"),html,re.DOTALL)
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ╆"),html,re.DOTALL)
	if l11ll1l_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡳ࡬ࡀࡩ࡮ࡣࡪࡩࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ╇"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭╈"),block,re.DOTALL)
		for l1ll11l_l1_,l111l11l1_l1_,title in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰࡩࡲࡂࠫ╉")+l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡂ࠭╊")+l111l11l1_l1_+l1l111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ╋")+l1ll11l_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╌"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ╍"))
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭╎"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"ࠪࠤࠬ╏")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ═"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭║")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ╒"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ╓"),l1l111_l1_ (u"ࠨࠩ╔"),l1l111_l1_ (u"ࠩࠪ╕"),l1l111_l1_ (u"ࠪࠫ╖"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭╗"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ╘"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ╙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ╚"),block,re.DOTALL)
		if l11111l11_l1_:
			l11111l11_l1_ = l11111l11_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ╛"),block,re.DOTALL)
			for server,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵࡅࡳࡦࡴࡹࡩࡷࡃࠧ╜")+server+l1l111_l1_ (u"ࠪࠪࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭╝")+l11111l11_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ╞")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭╟")
				l1llll_l1_.append(l1ll1ll_l1_)
	l111l11111_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰࡭࡫ࡸࡡ࡮ࡧࠥࡂࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ╠"),html,re.DOTALL)
	if l111l11111_l1_:
		l111l11111_l1_ = l111l11111_l1_[0].replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ╡"),l1l111_l1_ (u"ࠨࠩ╢"))
		title = l1l111l_l1_(l111l11111_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ╣"))
		l1ll1ll_l1_ = l111l11111_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ╤")+title+l1l111_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬ╥")
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ╦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ╧"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ╨"),l1l111_l1_ (u"ࠨࠩ╩"))
			if l111l1ll_l1_!=l1l111_l1_ (u"ࠩࠪ╪"): l111l1ll_l1_ = l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ╫")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ╬")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ╭")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ╮"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ╯"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ╰"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ╱"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ╲"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ╳")+search
	l1lll11_l1_(url)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ╴"))[0]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ╵"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ╶"),l1l11ll_l1_,l1l111_l1_ (u"ࠨࠩ╷"),l1l111_l1_ (u"ࠩࠪ╸"),l1l111_l1_ (u"ࠪࠫ╹"),l1l111_l1_ (u"ࠫࠬ╺"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ╻"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡦࡺࡺࡴࡰࡰࠥ࠲࠯ࡅࠩࠣࡕࡨࡥࡷࡩࡨࡪࡰࡪࡑࡦࡹࡴࡦࡴࠥࠫ╼"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡦࡺࡺࡴࡰࡰࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠪࠩ╽"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࡜ࡥ࠭ࠬࠦࠥࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ╾"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭╿"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ▀"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ▁"),l1l111_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࠩ▂"))
	return url
def l111l1111l_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ▃"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ▄")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
l1l11111_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ▅"),l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ▆"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ▇"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ█")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭▉"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ▊"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭▋"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ▌"),l1l111_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ▍"),l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ▎")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠫࡄ࠭▏") in url: url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ▐"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ░"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ▒"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ▓"),l1l111_l1_ (u"ࠩࠪ▔")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ▕"))
	if type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ▖"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠬࡃࠧ▗") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"࠭࠽ࠨ▘") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ▙")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ▚")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ▛")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭▜")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭▝"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ▞")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ▟"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ■"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ□")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ▢"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ▣"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬ▤"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ▥"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧ▦"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ▧")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▨"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ▩"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▪"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ▫")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ▬"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ▭"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ▮"),l1l111_l1_ (u"ࠨࠩ▯"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠩ࠰࠱ࠬ▰"),l1l111_l1_ (u"ࠪࠫ▱"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠫࡂ࠭▲") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ△"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ▴")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▵"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ▶"),l1lllll1_l1_,431)
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▷"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ▸"),l1lllll1_l1_,435,l1l111_l1_ (u"ࠫࠬ▹"),l1l111_l1_ (u"ࠬ࠭►"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ▻"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ▼")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ▽")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ▾")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭▿")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ◀")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◁"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨ◂")+name,l1lllll1_l1_,434,l1l111_l1_ (u"ࠧࠨ◃"),l1l111_l1_ (u"ࠨࠩ◄"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ◅"): option = l1l111_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ◆")
			elif value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ◇"): option = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ◈")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ◉")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ◊")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ○")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ◌")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ◍")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧ◎")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠬ࠶ࠧ●")]
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ◐")+name
			if type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ◑"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◒"),l1lllll_l1_+title,url,434,l1l111_l1_ (u"ࠩࠪ◓"),l1l111_l1_ (u"ࠪࠫ◔"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ◕") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠬࡃࠧ◖") in l11lll1l_l1_:
				l1llllll_l1_ = l111l1111l_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭◗"),l1lllll_l1_+title,l1llllll_l1_,431)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◘"),l1lllll_l1_+title,url,435,l1l111_l1_ (u"ࠨࠩ◙"),l1l111_l1_ (u"ࠩࠪ◚"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁࠫ࠭◛"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨ◜"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ◝"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ◞") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ◟"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ◠"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ◡")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ◢")
		if l1l111_l1_ (u"ࠫࠪ࠭◣") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ◤") and value!=l1l111_l1_ (u"࠭࠰ࠨ◥"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ◦")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ◧") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ◨"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ◩")+key+l1l111_l1_ (u"ࠫࡂ࠭◪")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ◫"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ◬")+key+l1l111_l1_ (u"ࠧ࠾ࠩ◭")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ◮"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ◯"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭◰"),l1l111_l1_ (u"ࠫࡂ࠭◱"))
	return l1l1l111_l1_
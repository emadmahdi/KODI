# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㲴")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧ㲵")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ㲶"),l1l111_l1_ (u"ࠪหุะแิษิฮ่๋้ࠠࠢส่฼๊ศศฬࠪ㲷")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㲸"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭㲹"),l1l111_l1_ (u"࠭ࠧ㲺"),l1l111_l1_ (u"ࠧࠨ㲻"),l1l111_l1_ (u"ࠨࠩ㲼"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㲽"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㲾"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲿"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ㳀"),l1l111_l1_ (u"࠭ࠧ㳁"),459,l1l111_l1_ (u"ࠧࠨ㳂"),l1l111_l1_ (u"ࠨࠩ㳃"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㳄"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㳅"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㳆")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬหษฬสฮ๊่ࠥะ์๊ࠣฯ࠭㳇"),l1l11ll_l1_,451,l1l111_l1_ (u"࠭ࠧ㳈"),l1l111_l1_ (u"ࠧࠨ㳉"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ㳊"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳋"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㳌")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ㳍"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠬ࠭㳎"),l1l111_l1_ (u"࠭ࠧ㳏"),l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ㳐"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㳑"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㳒"),l1l111_l1_ (u"ࠪࠫ㳓"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡓࡡࡪࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠫ㳔"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㳕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨ㳖"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳗"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㳘")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪ㳙")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㳚"),url,l1l111_l1_ (u"ࠫࠬ㳛"),l1l111_l1_ (u"ࠬ࠭㳜"),l1l111_l1_ (u"࠭ࠧ㳝"),l1l111_l1_ (u"ࠧࠨ㳞"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭㳟"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㳠"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡸࡣࡹࡩࡸࠨࠧ㳡"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㳢"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡒࡦࡥࡨࡲࡹࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ㳣"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ㳤") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㳥"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࠧࡇࡣࡵࡱࡵࡒࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㳦"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"ࠩ࠳ࠫ㳧"),l1l111_l1_ (u"ࠪ࠵ࠬ㳨"),l1l111_l1_ (u"ࠫ࠷࠭㳩")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩ㳪"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡁࡳࡧࡤࠦ࠭࠴ࠪࡀࠫࠥࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠧ࠭㳫"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠩ㳬"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ㳭"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ㳮"),l1l111_l1_ (u"ࠪห฿์๊สࠩ㳯"),l1l111_l1_ (u"ࠫศเๆ๋หࠪ㳰"),l1l111_l1_ (u"้ࠬไ๋สࠪ㳱"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ㳲"),l1l111_l1_ (u"่ࠧัสๅࠬ㳳"),l1l111_l1_ (u"ࠨ็หหึอษࠨ㳴"),l1l111_l1_ (u"ࠩ฼ี฻࠭㳵"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ㳶"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ㳷")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬࠨࡁࡤࡶࡲࡶࡸࡒࡩࡴࡶࠥࠫ㳸") in html and l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠫ㳹") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㳺"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪ㳻"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ㳼"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭㳽"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ู๊ࠫไิๆࠪ㳾") not in title:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㳿"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ㴀") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㴁") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㴂"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㴃"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠪࠫ㴄"),l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㴅")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㴆"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㴇"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㴈"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ㴉")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㴊"),url,l1l111_l1_ (u"ࠪࠫ㴋"),l1l111_l1_ (u"ࠫࠬ㴌"),l1l111_l1_ (u"ࠬ࠭㴍"),l1l111_l1_ (u"࠭ࠧ㴎"),l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡕࡈࡅࡘࡕࡎࡔ࠯࠴ࡷࡹ࠭㴏"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡆࡥࡹ࡫ࡧࡰࡴࡼࡗࡺࡨࡌࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㴐"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠨ㴑") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠯ࠪ㴒"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"ࠫࠥ࠭㴓"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㴔"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㴕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㴖"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㴗"),url,l1l111_l1_ (u"ࠩࠪ㴘"),l1l111_l1_ (u"ࠪࠫ㴙"),l1l111_l1_ (u"ࠫࠬ㴚"),l1l111_l1_ (u"ࠬ࠭㴛"),l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㴜"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㴝"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ㴞"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㴟"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㴠"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㴡"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㴢"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ㴣")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ㴤"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ㴥"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭㴦"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭㴧"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㴨"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭㴩"),l1l111_l1_ (u"࠭ࠧ㴪"),l1l111_l1_ (u"ࠧࠨ㴫"),l1l111_l1_ (u"ࠨࠩ㴬"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㴭"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ㴮"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡘ࡮ࡺ࡬ࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡷ࡮ࡪࡥ࠿ࠩ㴯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ㴰"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㴱")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ㴲")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡐ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩࠣࡵࡨࡰࡦࡸࡹࠣࠩ㴳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ㴴"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ㴵"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ㴶")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"ࠬ࠭㴷")
			else: l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ㴸")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㴹")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㴺")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㴻"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ㴼"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ㴽"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ㴾"),l1l111_l1_ (u"࠭ࠫࠨ㴿"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ㵀")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback,threading
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧ㇊")
l1l1l1l1111_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠧࡱࡣࡷ࡬ࠬ㇋"))
l1l1111ll1l_l1_ = os.path.join(l1l1l1l1111_l1_,l1l111_l1_ (u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪ㇌"))
sys.path.append(l1l1111ll1l_l1_)
l1l1l111l1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣ㇍"))
kodi_version = re.findall(l1l111_l1_ (u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧ㇎"),l1l1l111l1l_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1ll111l1_l1_ = xbmc.Player
l1l1l1lll11_l1_ = xbmcgui.WindowXMLDialog
PY2 = kodi_version<19
PY3 = kodi_version>18.99
if PY3:
	l1l11l11lll_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡥࠬ㇏"),l1l111_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭㇐")
	l1l11lll1l1_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ㇑"))
	from urllib.parse import unquote as _1l1l1111ll_l1_
else:
	l1l11l11lll_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨ㇒").encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㇓")),l1l111_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡤࠪ㇔").encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇕"))
	l1l11lll1l1_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ㇖"))
	from urllib import unquote as _1l1l1111ll_l1_
l1l1ll1l1ll_l1_ = 60
l1l11lll111_l1_ = 60*l1l1ll1l1ll_l1_
l1l11ll1l1l_l1_ = 24*l1l11lll111_l1_
l1l1ll11lll_l1_ = 30*l1l11ll1l1l_l1_
l11l1l1_l1_ = 16*l1l11lll111_l1_
l1ll1ll1_l1_ = 3*l1l11ll1l1l_l1_
l1ll111l1l1_l1_ = 12*l1l1ll11lll_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"ࠬ࠵ࠧ㇗"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1lll1l11_l1_ = addon_id.split(l1l111_l1_ (u"࠭࠮ࠨ㇘"))[2]
l1l111lll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧ㇙")+addon_id+l1l111_l1_ (u"ࠨࠫࠪ㇚"))
addoncachefolder = os.path.join(l1l11lll1l1_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤ࠲ࡩࡨࠧ㇛"))
l1l11llllll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡰࡦࡹࡴࡷ࡫ࡧࡩࡴࡹ࠮ࡥࡣࡷࠫ㇜"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url,l111ll11l_l1_=l1l111_l1_ (u"ࠫࡄ࠭㇝")):
	if l1l111_l1_ (u"ࠬࡃࠧ㇞") in url:
		if l111ll11l_l1_ in url: l1lllll1_l1_,filters = url.split(l111ll11l_l1_,1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"࠭ࠧ㇟"),url
		filters = filters.split(l1l111_l1_ (u"ࠧࠧࠩ㇠"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠨ࠿ࠪ㇡"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l1111ll_l1_(urll)
def EXTRACT_KODI_PATH(l1l111l11ll_l1_):
	l1ll1111111_l1_ = {l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ㇢"):l1l111_l1_ (u"ࠪࠫ㇣"),l1l111_l1_ (u"ࠫࡲࡵࡤࡦࠩ㇤"):l1l111_l1_ (u"ࠬ࠭㇥"),l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㇦"):l1l111_l1_ (u"ࠧࠨ㇧"),l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠭㇨"):l1l111_l1_ (u"ࠩࠪ㇩"),l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ㇪"):l1l111_l1_ (u"ࠫࠬ㇫"),l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㇬"):l1l111_l1_ (u"࠭ࠧ㇭"),l1l111_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭㇮"):l1l111_l1_ (u"ࠨࠩ㇯"),l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪㇰ"):l1l111_l1_ (u"ࠪࠫㇱ"),l1l111_l1_ (u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ㇲ"):l1l111_l1_ (u"ࠬ࠭ㇳ")}
	if l1l111_l1_ (u"࠭࠿ࠨㇴ") in l1l111l11ll_l1_: l1l111l11ll_l1_ = l1l111l11ll_l1_.split(l1l111_l1_ (u"ࠧࡀࠩㇵ"),1)[1]
	l1lllll1_l1_,l1l1lllllll_l1_ = l1ll11ll1_l1_(l1l111l11ll_l1_)
	args = dict(list(l1ll1111111_l1_.items())+list(l1l1lllllll_l1_.items()))
	l1l1111lll1_l1_ = args[l1l111_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭ㇶ")]
	l1l1l11l1ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ㇷ")])
	l1l11ll11l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨㇸ")])
	l1l11111l1l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫࡵࡧࡧࡦࠩㇹ")])
	l1l11111l11_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬࡺࡹࡱࡧࠪㇺ")])
	l1l11ll11ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫㇻ")])
	l1l1l1llll1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ㇼ")])
	l1l11ll1111_l1_ = args[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩㇽ")]
	l1l1l111111_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫㇾ")])
	if l1l1l111111_l1_: l1l1l111111_l1_ = eval(l1l1l111111_l1_)
	else: l1l1l111111_l1_ = {}
	if not l1l1111lll1_l1_: l1l11111l11_l1_ = l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㇿ") ; l1l1111lll1_l1_ = l1l111_l1_ (u"ࠫ࠷࠼࠰ࠨ㈀")
	return l1l11111l11_l1_,l1l11ll11ll_l1_,l1l1l11l1ll_l1_,l1l1111lll1_l1_,l1l1l1llll1_l1_,l1l11111l1l_l1_,l1l11ll11l1_l1_,l1l11ll1111_l1_,l1l1l111111_l1_
def l11lllll11_l1_(l1ll1_l1_):
	l1l11ll111l_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l11ll111l_l1_ or l1l11ll111l_l1_==l1l111_l1_ (u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧ㈁"):
		return l1l111_l1_ (u"࡛࠭ࠡࠩ㈂")+l1l1lll1l11_l1_.upper()+l1l111_l1_ (u"ࠧ࠮ࠩ㈃")+l1l111lll1l_l1_+l1l111_l1_ (u"ࠨ࠯ࠪ㈄")+str(kodi_version)+l1l111_l1_ (u"ࠩࠣࡡࠬ㈅")
	return l1l111_l1_ (u"ࠪ࠲ࠥࠦࠧ㈆")+l1l11ll111l_l1_
def l1l1111111_l1_(level,message):
	if PY2: message = message.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㈇")).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㈈"))
	l1l111lllll_l1_ = l1l11l11lll_l1_
	lines = [l1l111_l1_ (u"࠭ࠧ㈉"),l1l111_l1_ (u"ࠧࠨ㈊")]
	if level: message = message.replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㈋"),l1l111_l1_ (u"ࠩࠪ㈌")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭㈍"),l1l111_l1_ (u"ࠫࠬ㈎")).replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㈏"),l1l111_l1_ (u"࠭ࠧ㈐"))
	else: level = l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㈑")
	l11ll11111_l1_,sep,shift = l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭㈒"),l1l111_l1_ (u"ࠩࠣࠤࠥ࠭㈓"),l1l111_l1_ (u"ࠪࠫ㈔")
	if l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㈕") in level: l1l111lllll_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㈖"):
		message = message+sep
		lines = message.split(sep)
		shift = l11ll11111_l1_
	elif level==l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㈗"):
		message = message.replace(l1l111_l1_ (u"ࠧ࠯ࠩ㈘")+sep,l1l111_l1_ (u"ࠨ࠰ࠣࠤࠬ㈙"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"ࠩ࠱ࠫ㈚")+lines[0][1:]
		shift = l11ll11111_l1_+sep
	elif level in [l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㈛"),l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㈜")]: lines = message.split(l11ll11111_l1_)
	shift += 6*l11ll11111_l1_
	l1l11l1111l_l1_ = 3*l11ll11111_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"ࠬࠦࠧ㈝")
	l1l1ll11l1l_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"࠭࡜࡯ࠩ㈞") in line: line = line.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㈟"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㈠")+l11ll11111_l1_+l11ll11111_l1_)
		l1l11l1111l_l1_ += l11ll11111_l1_
		l1l1ll11l1l_l1_ += l1l111_l1_ (u"ࠩ࡟ࡶࠬ㈡")+shift+l1l11l1111l_l1_+line
	l1l1ll11l1l_l1_ += l1l111_l1_ (u"ࠪࠤࡤ࠭㈢")
	if l1l111_l1_ (u"ࠫࠪ࠭㈣") in l1l1ll11l1l_l1_: l1l1ll11l1l_l1_ = l111l11_l1_(l1l1ll11l1l_l1_)
	xbmc.log(l1l1ll11l1l_l1_,level=l1l111lllll_l1_)
	return
def l1l1lll1lll_l1_(l1ll1lll1l_l1_):
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱ࠾ࠫ㈤"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡦࡰࡴࡨ࡭࡬ࡴ࡟࡬ࡧࡼࡷࡂࡴ࡯࠼ࠩ㈥"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡩࡱࡳࡷ࡫࡟ࡤࡪࡨࡧࡰࡥࡣࡰࡰࡶࡸࡷࡧࡩ࡯ࡶࡶࡁࡾ࡫ࡳ࠼ࠩ㈦"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫࠽ࡐࡈࡉ࠿ࠬ㈧"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧ㈨"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡷࡾࡴࡣࡩࡴࡲࡲࡴࡻࡳ࠾ࡑࡉࡊࡀ࠭㈩"))
	conn.text_factory = str
	return conn,l1llll1lll_l1_
def l1lll1ll11l_l1_(l1ll1lll1l_l1_,table,l1l1l111lll_l1_=None):
	try: conn,l1llll1lll_l1_ = l1l1lll1lll_l1_(l1ll1lll1l_l1_)
	except: return
	if l1l1l111lll_l1_==None: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡘࡏࡑࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㈪")+table+l1l111_l1_ (u"ࠬࠨࠠ࠼ࠩ㈫"))
	else:
		tt = (str(l1l1l111lll_l1_),)
		try:
			if l1l111_l1_ (u"࠭ࠥࠨ㈬") in l1l1l111lll_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㈭")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫ㈮"),tt)
			else: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㈯")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㈰"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1ll1l111_l1_(): pass
class l1l1llll1l1_l1_(l1l1ll1l111_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"ࠫࠬ㈱")
		self.code = -99
		self.reason = l1l111_l1_ (u"ࠬ࠭㈲")
		self.content = l1l111_l1_ (u"࠭ࠧ㈳")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l111ll1_l1_(type):
	if type==l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㈴"): data = {}
	elif type==l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㈵"): data = []
	elif type==l1l111_l1_ (u"ࠩࡶࡸࡷ࠭㈶"): data = l1l111_l1_ (u"ࠪࠫ㈷")
	elif type==l1l111_l1_ (u"ࠫ࡮ࡴࡴࠨ㈸"): data = 0
	elif type==l1l111_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ㈹"): data = l1l1llll1l1_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1l111ll1ll_l1_(l1l1111l111_l1_):
	from hashlib import md5
	l1l1llll11l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳࠨ㈺"))
	l1l1ll11ll1_l1_ = l1l11l1l111_l1_(32).splitlines()
	l1l111l1ll1_l1_ = str(now/4.32)[0:4]
	for l1l111ll111_l1_ in l1l1ll11ll1_l1_:
		l1l11l1llll_l1_ = l1l111_l1_ (u"࡙ࠧ࠳࠼ࠫ㈻")+l1l1111l111_l1_+l1l111_l1_ (u"ࠨ࠳࠻ࡁࠬ㈼")+l1l111ll111_l1_[-24:]+l1l111lll1l_l1_+l1l111l1ll1_l1_
		l1l11l1llll_l1_ = md5(l1l11l1llll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㈽"))).hexdigest()[:32]
		if l1l11l1llll_l1_ in l1l1llll11l_l1_: return True
	return False
def l1lll11l11l_l1_(l1ll1lll1l_l1_,l1l1l1l1l1l_l1_,table,l1l1l111lll_l1_=None):
	data = l1l1l111ll1_l1_(l1l1l1l1l1l_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ㈾"))
	if table!=l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㈿") and l1ll1lll1l_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㉀"): return data
		l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㉁"))
		if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㉂"):
			l1lll1ll11l_l1_(l1ll1lll1l_l1_,table,l1l1l111lll_l1_)
			return data
	l1ll111l1ll_l1_ = 0
	if cache==l1l111_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ㉃"): l1ll111l1ll_l1_ = l1l111lll11_l1_
	try: conn,l1llll1lll_l1_ = l1l1lll1lll_l1_(l1ll1lll1l_l1_)
	except: return data
	l1l11lllll1_l1_ = True
	try: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠥࠫ㉄")+table+l1l111_l1_ (u"ࠪࠦࠥࡒࡉࡎࡋࡗࠤ࠶ࠦ࠻ࠨ㉅"))
	except: l1l11lllll1_l1_ = False
	if l1l11lllll1_l1_:
		if l1ll111l1ll_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㉆")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡄࠧ㉇")+str(now+l1ll111l1ll_l1_)+l1l111_l1_ (u"࠭ࠠ࠼ࠩ㉈"))
		conn.commit()
		l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㉉")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺ࠾ࠪ㉊")+str(now)+l1l111_l1_ (u"ࠩࠣ࠿ࠬ㉋"))
		conn.commit()
		if l1l1l111lll_l1_:
			tt = (str(l1l1l111lll_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ㉌")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ㉍"),tt)
			l1l11lll11l_l1_ = l1llll1lll_l1_.fetchall()
			if l1l11lll11l_l1_:
				try:
					text = zlib.decompress(l1l11lll11l_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠣࡊࡗࡕࡍࠡࠤࠪ㉎")+table+l1l111_l1_ (u"࠭ࠢࠡ࠽ࠪ㉏"))
			l1l11lll11l_l1_ = l1llll1lll_l1_.fetchall()
			if l1l11lll11l_l1_:
				data,l1l1lll1ll1_l1_ = {},[]
				for l1l1ll11l11_l1_,l1l11llll_l1_ in l1l11lll11l_l1_:
					l1ll1ll11l_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1ll11l_l1_)
					data[l1l1ll11l11_l1_] = l1l11llll_l1_
					l1l1lll1ll1_l1_.append(l1l1ll11l11_l1_)
				if l1l1lll1ll1_l1_:
					data[l1l111_l1_ (u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨ㉐")] = l1l1lll1ll1_l1_
					if l1l1l1l1l1l_l1_==l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㉑"): data = l1l1lll1ll1_l1_
	conn.close()
	return data
class l1l1l11llll_l1_(l1l1ll111l1_l1_):
	def __init__(self): self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪ㉒")
	def init(self,l1l11l11l1l_l1_):
		self.l1l11l11l1l_l1_ = l1l11l11l1l_l1_
		self.l1ll111l111_l1_ = l1l111ll1ll_l1_(l1l111_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㉓"))
		self.l1l1l1lll1l_l1_ = l1l111ll1ll_l1_(l1l111_l1_ (u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ㉔"))
		self.l1l1l11l111_l1_ = l1l111ll1ll_l1_(l1l111_l1_ (u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪ㉕"))
		if self.l1ll111l111_l1_: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㉖")
		elif self.l1l1l1lll1l_l1_: return
		elif self.l1l1l11l111_l1_:
			from l1l11lll1ll_l1_ import l1l1l11lll1_l1_
			l1l1l11lll1_l1_(False)
		else:
			self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㉗")
			from l1l11lll1ll_l1_ import l1l1l11lll1_l1_
			l1l1l11lll1_l1_(False)
	def onPlayBackStopped(self): self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㉘")
	def onPlayBackError(self): self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㉙")
	def onPlayBackEnded(self): self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㉚")
	def onPlayBackStarted(self):
		self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㉛")
		l1l111l111l_l1_ = threading.Thread(target=self.l1l111l1lll_l1_,args=())
		l1l111l111l_l1_.start()
	def l1l1lll11l1_l1_(self):
		if self.l1ll111l111_l1_: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㉜")
		elif self.l1l1l1lll1l_l1_: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㉝")
		elif self.l1l1l11l111_l1_: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㉞")
		else: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㉟")
	def l1l111l1lll_l1_(self):
		from LIBSTWO import l1l1l1lllll_l1_,l1l11l111l1_l1_,l1l1l1l1ll1_l1_
		l1l1l1l1ll1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡴࡶࠧ㉠"))
		l1l1l11l1l1_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࡜ࡩࡥࡧࡲࠬ࠮࠭㉡")) and self.l1l1ll1ll1l_l1_==l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㉢"):
			xbmc.sleep(1000)
			l1l1l11l1l1_l1_ += 1
			if l1l1l11l1l1_l1_>60: return
		if self.l1ll111l111_l1_: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㉣")
		elif self.l1l1l1lll1l_l1_: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㉤")
		elif self.l1l1l11l111_l1_:
			self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㉥")
			l1l111l1111_l1_ = threading.Thread(target=l1l1l1lllll_l1_,args=(self.l1l11l11l1l_l1_,))
			l1l111l1111_l1_.start()
			l1l111l11l1_l1_ = threading.Thread(target=l1l11l111l1_l1_,args=())
			l1l111l11l1_l1_.start()
		else: self.l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㉦")
def l1l1lll1l1l_l1_():
	l1l11l1l1ll_l1_,l1l1111l1l1_l1_ = l1l111_l1_ (u"ࠩࠪ㉧"),l1l111_l1_ (u"ࠪࠫ㉨")
	l1l1llllll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪ㉩"))
	try:
		l1l11l1ll11_l1_ = open(l1l111_l1_ (u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬ㉪"),l1l111_l1_ (u"࠭ࡲࡣࠩ㉫")).read()
		if PY3: l1l11l1ll11_l1_ = l1l11l1ll11_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㉬"))
		l1l1111llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡕࡨࡶ࡮ࡧ࡬࠯ࠬࡂ࠾ࠥ࠮࠮ࠫࡁࠬࠨࠬ㉭"),l1l11l1ll11_l1_,re.IGNORECASE)
		if l1l1111llll_l1_: l1l11l1l1ll_l1_ = l1l1111llll_l1_[0]
	except: pass
	try:
		import subprocess
		l1l111ll11l_l1_ = subprocess.Popen(l1l111_l1_ (u"ࠩࡶࡸࡦࡺࠠ࠮ࡥࠣࠦࠥࠫࡘࠡࠤࠣ࠳ࡸࡺ࡯ࡳࡣࡪࡩ࠴࡫࡭ࡶ࡮ࡤࡸࡪࡪ࠯࠱ࠢ࠾ࠤࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡙ࠠࠦࠣࠦࠥ࠵ࡶࡢࡴ࠲ࡰࡴ࡭ࠧ㉮"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
		l1l11l1lll1_l1_ = l1l111ll11l_l1_.stdout.read()
		if l1l11l1lll1_l1_:
			if PY3:
				l1l11l1lll1_l1_ = l1l11l1lll1_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㉯"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ㉰"))
			l1l1l11111l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠦࠨ࡝ࡦࡾ࠵࠵ࢃࠩࠡࠩ㉱"),l1l11l1lll1_l1_,re.IGNORECASE)
			if l1l1l11111l_l1_: l1l1111l1l1_l1_ = min(l1l1l11111l_l1_)
	except: pass
	return l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_
def l1l11l1l111_l1_(l1l1l11l11l_l1_,l1l11l1l11l_l1_=True):
	l1l11ll1ll1_l1_ = True
	if l1l11l1l11l_l1_:
		l1l11ll1l11_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ㉲"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㉳"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭㉴"))
		if l1l11ll1l11_l1_:
			l1l1ll11ll1_l1_,l1ll111l11l_l1_,l1l1l1l1l11_l1_,l1l1l1l11ll_l1_ = l1l11ll1l11_l1_
			l1l11ll1ll1_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㉵"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㉶"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪ㉷"))
			if l1l11ll1ll1_l1_: l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_ = l1l11ll1ll1_l1_
			else: l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_ = l1l1lll1l1l_l1_()
			if (l1ll111l11l_l1_,l1l1l1l1l11_l1_,l1l1l1l11ll_l1_)==(l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_): return l1l111_l1_ (u"ࠬࡢ࡮ࠨ㉸").join(l1l1ll11ll1_l1_)
	if l1l11ll1ll1_l1_: l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_ = l1l1lll1l1l_l1_()
	global l1l1lll1111_l1_,l1l1ll1llll_l1_
	l1l1lll1111_l1_,l1l1ll1llll_l1_,l1l1ll1lll1_l1_ = l1l111_l1_ (u"࠭ࠧ㉹"),l1l111_l1_ (u"ࠧࠨ㉺"),l1l111_l1_ (u"ࠨࠩ㉻")
	l1l1l11l11l_l1_ = l1l1l11l11l_l1_//2
	threading.Thread(target=l1l1lll11ll_l1_).start()
	threading.Thread(target=l1l1ll111ll_l1_).start()
	for l1l111lll1_l1_ in range(10):
		time.sleep(0.5)
		if not l1l1ll1lll1_l1_:
			try:
				l1ll1111l1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡑࡩࡹࡽ࡯ࡳ࡭࠱ࡑࡦࡩࡁࡥࡦࡵࡩࡸࡹࠧ㉼"))
				if l1ll1111l1l_l1_.count(l1l111_l1_ (u"ࠪ࠾ࠬ㉽"))==5 and l1ll1111l1l_l1_.count(l1l111_l1_ (u"ࠫ࠵࠭㉾"))<9:
					l1ll1111l1l_l1_ = l1ll1111l1l_l1_.lower().replace(l1l111_l1_ (u"ࠬࡀࠧ㉿"),l1l111_l1_ (u"࠭ࠧ㊀"))
					l1l1ll1lll1_l1_ = str(int(l1ll1111l1l_l1_,16))
			except: pass
		if l1l1lll1111_l1_ and l1l1ll1llll_l1_ and l1l1ll1lll1_l1_: break
	l1ll111111l_l1_ = [l1l1lll1111_l1_,l1l1ll1llll_l1_,l1l1ll1lll1_l1_,l1l111_l1_ (u"ࠧࠨ㊁"),l1l111_l1_ (u"ࠨࠩ㊂"),l1l111_l1_ (u"ࠩ࠳࠴࠶࠷࠲࠳࠵࠶࠸࠹࠻࠵࠷࠸࠺࠻ࠬ㊃")]
	if l1l11l1l1ll_l1_ or l1l1111l1l1_l1_:
		from hashlib import md5
		l1l1ll1111l_l1_ = [(4,l1l11l1l1ll_l1_),(5,l1l1111l1l1_l1_)]
		for l1ll1111lll_l1_,l1l1l111l11_l1_ in l1l1ll1111l_l1_:
			l1l1l111l11_l1_ = l1l1l111l11_l1_.strip(l1l111_l1_ (u"ࠪ࠴ࠬ㊄"))
			if l1l1l111l11_l1_:
				if PY3: l1l1l111l11_l1_ = l1l1l111l11_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㊅"))
				l1l1l111l11_l1_ = str(int(md5(l1l1l111l11_l1_).hexdigest(),36))
				l1l1ll11111_l1_ = [int(l1l1l111l11_l1_[l1ll1111ll1_l1_:l1ll1111ll1_l1_+15]) for l1ll1111ll1_l1_ in range(len(l1l1l111l11_l1_)) if l1ll1111ll1_l1_%15==0]
				l1ll111111l_l1_[l1ll1111lll_l1_-1] = str(sum(l1l1ll11111_l1_))
	l1l1ll11ll1_l1_,l1l1l1ll1l1_l1_ = [],False
	for l1l1l11ll11_l1_ in range(len(l1ll111111l_l1_)):
		l1l1ll11111_l1_ = l1ll111111l_l1_[l1l1l11ll11_l1_]
		if not l1l1ll11111_l1_: continue
		if l1l1l1ll1l1_l1_ and l1l1ll11111_l1_==l1ll111111l_l1_[-1]: continue
		l1l1l1ll1l1_l1_ = True
		l1l1ll11111_l1_ = l1l1l11l11l_l1_*l1l111_l1_ (u"ࠬ࠶ࠧ㊆")+l1l1ll11111_l1_
		l1l1ll11111_l1_ = l1l1ll11111_l1_[-l1l1l11l11l_l1_:]
		l1l1l1l111l_l1_,l1l1lll111l_l1_ = l1l111_l1_ (u"࠭ࠧ㊇"),l1l111_l1_ (u"ࠧࠨ㊈")
		l1l1111111l_l1_ = str(int(l1l111_l1_ (u"ࠨ࠻ࠪ㊉")*(l1l1l11l11l_l1_+1))-int(l1l1ll11111_l1_))[-l1l1l11l11l_l1_:]
		for l1l11l1l1l1_l1_ in list(range(0,l1l1l11l11l_l1_,4)):
			l1l11l111ll_l1_ = l1l1111111l_l1_[l1l11l1l1l1_l1_:l1l11l1l1l1_l1_+4]
			l1l1l1l111l_l1_ += l1l11l111ll_l1_+l1l111_l1_ (u"ࠩ࠰ࠫ㊊")
			l1l1lll111l_l1_ += str(sum(map(int,l1l1ll11111_l1_[l1l11l1l1l1_l1_:l1l11l1l1l1_l1_+4]))%10)
		l1l111ll111_l1_ = str(l1l1l11ll11_l1_)+l1l1l1l111l_l1_+l1l1lll111l_l1_
		l1l1ll11ll1_l1_.append(l1l111ll111_l1_)
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㊋"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪ㊌"),[l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_],l11l1l1_l1_)
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㊍"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫ㊎"),[l1l1ll11ll1_l1_,l1l1llllll1_l1_,l1l11l1l1ll_l1_,l1l1111l1l1_l1_],l1ll1ll1_l1_)
	return l1l111_l1_ (u"ࠧ࡝ࡰࠪ㊏").join(l1l1ll11ll1_l1_)
def l1l1l1l1lll_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㊐"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㊑")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㊒"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㊓")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ㊔"),l1l111_l1_ (u"࠭ࠠࠨ㊕")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㊖"),l1l111_l1_ (u"ࠨࠢࠪ㊗"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠩࠣ࠲࠳࠴ࠧ㊘")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㊙"),l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㊚")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㊛"),l1l111_l1_ (u"࠭࡜࡝ࡴࠪ㊜")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ㊝"),l1l111_l1_ (u"ࠨࠢࠪ㊞")).replace(l1l111_l1_ (u"ࠩࠣࠤࠥ࠭㊟"),l1l111_l1_ (u"ࠪࠤࠬ㊠"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠫࠥ࠴࠮࠯ࠩ㊡")
	l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㊢"),l1l111_l1_ (u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࠫ㊣")+type+l1l111_l1_ (u"ࠧࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㊤")+url+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㊥")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡧࡷ࡬ࡴࡪ࠺ࠡ࡝ࠣࠫ㊦")+method+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭㊧")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡇࡥࡹࡧ࠺ࠡ࡝ࠣࠫ㊨")+l1l11llll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㊩"))
	return
def l1l1lll11ll_l1_():
	global l1l1lll1111_l1_
	import getmac82
	try:
		l1ll11111ll_l1_ = getmac82.get_mac_address()
		if l1ll11111ll_l1_.count(l1l111_l1_ (u"࠭࠺ࠨ㊪"))==5 and l1ll11111ll_l1_.count(l1l111_l1_ (u"ࠧ࠱ࠩ㊫"))<9:
			l1ll11111ll_l1_ = l1ll11111ll_l1_.lower().replace(l1l111_l1_ (u"ࠨ࠼ࠪ㊬"),l1l111_l1_ (u"ࠩࠪ㊭"))
			l1l1lll1111_l1_ = str(int(l1ll11111ll_l1_,16))
	except: pass
	return
def l1l1ll111ll_l1_():
	global l1l1ll1llll_l1_
	import getmac94
	try:
		l1ll1111l11_l1_ = getmac94.get_mac_address()
		if l1ll1111l11_l1_.count(l1l111_l1_ (u"ࠪ࠾ࠬ㊮"))==5 and l1ll1111l11_l1_.count(l1l111_l1_ (u"ࠫ࠵࠭㊯"))<9:
			l1ll1111l11_l1_ = l1ll1111l11_l1_.lower().replace(l1l111_l1_ (u"ࠬࡀࠧ㊰"),l1l111_l1_ (u"࠭ࠧ㊱"))
			l1l1ll1llll_l1_ = str(int(l1ll1111l11_l1_,16))
	except: pass
	return
def l1l11111lll_l1_(method,url,data=l1l111_l1_ (u"ࠧࠨ㊲"),headers=l1l111_l1_ (u"ࠨࠩ㊳"),source=l1l111_l1_ (u"ࠩࠪ㊴")):
	l1l1l1l1lll_l1_(l1l111_l1_ (u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡔࡖࡅࡏࡡࡘࡖࡑ࠭㊵"),url,data,headers,source,method)
	if PY3: import urllib.request as l1l1ll1l1l1_l1_
	else: import urllib2 as l1l1ll1l1l1_l1_
	if not headers: headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㊶"):l1l111_l1_ (u"ࠬ࠭㊷")}
	if not data: data = {}
	if method==l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㊸"):
		url = url+l1l111_l1_ (u"ࠧࡀࠩ㊹")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㊺") and l1l111_l1_ (u"ࠩ࡭ࡷࡴࡴࠧ㊻") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㊼"))
	elif method==l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㊽"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㊾"))
	try:
		req = l1l1ll1l1l1_l1_.Request(url,headers=headers,data=data)
		response = l1l1ll1l1l1_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"࠭ࡏࡌࠩ㊿")
	except:
		html = l1l111_l1_ (u"ࠧࠨ㋀")
		code,reason = -1,l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ㋁")
	l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㋂"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㋃")+str(code)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㋄")+reason+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㋅")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㋆")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㋇"))
	if html and PY3: html = html.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㋈"))
	return html
def l1l1lllll11_l1_(l1l11l11ll1_l1_,l1l1111l11l_l1_=l1l111_l1_ (u"ࠩࠪ㋉")):
	l1l11l11l11_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㋊"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧ㋋")}
	l1l11111111_l1_ = {	l1l111_l1_ (u"ࠧࡻࡳࡦࡴࡢ࡭ࡩࠨ㋌"):l1l11l1l111_l1_(32).splitlines()[0][-24:],
				l1l111_l1_ (u"ࠨ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠥ㋍"):str(kodi_version),
				l1l111_l1_ (u"ࠢࡢࡲࡳࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ㋎"):l1l111lll1l_l1_,
				l1l111_l1_ (u"ࠣࡦࡨࡺ࡮ࡩࡥࡠࡨࡤࡱ࡮ࡲࡹࠣ㋏"):l1l111lll1l_l1_,
				l1l111_l1_ (u"ࠤࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪࠨ㋐"):l1l11l11ll1_l1_,
				l1l111_l1_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࠧ㋑"): l1l111lll1l_l1_,
				l1l111_l1_ (u"ࠦࡨࡧࡲࡳ࡫ࡨࡶࠧ㋒"):l1l111_l1_ (u"ࠧࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࠧ㋓"),
				l1l111_l1_ (u"ࠨࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤ㋔"):{l1l111_l1_ (u"ࠢࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ㋕"):l1l11l11ll1_l1_},
				l1l111_l1_ (u"ࠣࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ㋖"): {l1l111_l1_ (u"ࠤࡘࡷࡪࡸ࡟ࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ㋗"):l1l11l11ll1_l1_},
				l1l111_l1_ (u"ࠥࠨࡸࡱࡩࡱࡡࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࡣࡸࡿ࡮ࡤࠤ㋘"):False,
				l1l111_l1_ (u"ࠦ࡮ࡶࠢ㋙"): l1l111_l1_ (u"ࠧࠪࡲࡦ࡯ࡲࡸࡪࠨ㋚")
			}
	if not l1l1111l11l_l1_: l1l111l1l11_l1_ = [l1l11111111_l1_]
	else:
		l1l111111l1_l1_ = l1l11111111_l1_.copy()
		l1l111111l1_l1_[l1l111_l1_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ㋛")] = l1l1111l11l_l1_
		l1l111111l1_l1_[l1l111_l1_ (u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ㋜")] = {l1l111_l1_ (u"ࠣࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ㋝"):l1l1111l11l_l1_}
		l1l111111l1_l1_[l1l111_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫ㋞")] = {l1l111_l1_ (u"࡙ࠥࡸ࡫ࡲࡠࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ㋟"):l1l1111l11l_l1_}
		l1l111l1l11_l1_ = [l1l11111111_l1_,l1l111111l1_l1_]
	data = {l1l111_l1_ (u"ࠦࡦࡶࡩࡠ࡭ࡨࡽࠧ㋠"):l1l111_l1_ (u"ࠬ࠸࠵࠵ࡦࡧ࠷ࡦ࠺࠰࠺ࡦ࠻ࡦ࠻࠾࠱ࡥ࠶ࡨ࠵࠶࠽ࡥࡦ࠹࠻ࡧࡪࡨࡦ࠳࠻ࠪ㋡"),
			l1l111_l1_ (u"ࠨࡩ࡯ࡵࡨࡶࡹࡥࡩࡥࠤ㋢"):l1l11l11l11_l1_,
			l1l111_l1_ (u"ࠢࡦࡸࡨࡲࡹࡹࠢ㋣"): l1l111l1l11_l1_
		}
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠸࠮ࡢ࡯ࡳࡰ࡮ࡺࡵࡥࡧ࠱ࡧࡴࡳ࠯࠳࠱࡫ࡸࡹࡶࡡࡱ࡫ࠪ㋤")
	html = l1l11111lll_l1_(l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㋥"),url,data,headers,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㋦"))
	return html
def l1ll1l1_l1_(l1l1l1l1l1l_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠫࡳࡻ࡬࡭ࠩ㋧"),l1l111_l1_ (u"ࠬࡔ࡯࡯ࡧࠪ㋨"))
	text = text.replace(l1l111_l1_ (u"࠭ࡴࡳࡷࡨࠫ㋩"),l1l111_l1_ (u"ࠧࡕࡴࡸࡩࠬ㋪"))
	text = text.replace(l1l111_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ㋫"),l1l111_l1_ (u"ࠩࡉࡥࡱࡹࡥࠨ㋬"))
	text = text.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭㋭"),l1l111_l1_ (u"ࠫ࠴࠭㋮"))
	try: l1ll1ll11l_l1_ = eval(text)
	except: l1ll1ll11l_l1_ = l1l1l111ll1_l1_(l1l1l1l1l1l_l1_)
	return l1ll1ll11l_l1_
def l1l1l1ll11l_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡ࡞࡞࠳ࡈࡕࡌࡐࡔ࡟ࡡࠬ㋯"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"࠭࡟ࠦ࡯࠱ࠩࡩࡥࠥࡉ࠼ࠨࡑࡤ࠭㋰"),time.localtime(now))
	name = name+datetime
	l1lll111lll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_
	if os.path.exists(l1l11llllll_l1_):
		l1l11l1ll1l_l1_ = open(l1l11llllll_l1_,l1l111_l1_ (u"ࠧࡳࡤࠪ㋱")).read()
		if PY3: l1l11l1ll1l_l1_ = l1l11l1ll1l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㋲"))
		l1l11l1ll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㋳"),l1l11l1ll1l_l1_)
	else: l1l11l1ll1l_l1_ = {}
	l1l111llll1_l1_ = {}
	for l1l1ll1ll11_l1_ in list(l1l11l1ll1l_l1_.keys()):
		if l1l1ll1ll11_l1_!=type: l1l111llll1_l1_[l1l1ll1ll11_l1_] = l1l11l1ll1l_l1_[l1l1ll1ll11_l1_]
		else:
			if name and name!=l1l111_l1_ (u"ࠪ࠲࠳࠭㋴"):
				l1l111ll1l1_l1_ = l1l11l1ll1l_l1_[l1l1ll1ll11_l1_]
				if l1lll111lll_l1_ in l1l111ll1l1_l1_:
					index = l1l111ll1l1_l1_.index(l1lll111lll_l1_)
					del l1l111ll1l1_l1_[index]
				l111l1l1ll_l1_ = [l1lll111lll_l1_]+l1l111ll1l1_l1_
				l111l1l1ll_l1_ = l111l1l1ll_l1_[:50]
				l1l111llll1_l1_[l1l1ll1ll11_l1_] = l111l1l1ll_l1_
			else: l1l111llll1_l1_[l1l1ll1ll11_l1_] = l1l11l1ll1l_l1_[l1l1ll1ll11_l1_]
	if type not in list(l1l111llll1_l1_.keys()): l1l111llll1_l1_[type] = [l1lll111lll_l1_]
	l1l111llll1_l1_ = str(l1l111llll1_l1_)
	if PY3: l1l111llll1_l1_ = l1l111llll1_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㋵"))
	open(l1l11llllll_l1_,l1l111_l1_ (u"ࠬࡽࡢࠨ㋶")).write(l1l111llll1_l1_)
	return
def l1lll11111l_l1_(l1ll1lll1l_l1_,table,l1l1l111lll_l1_,data,l1l1l1l11l1_l1_,l1l1ll1l11l_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ㋷"))
	if cache==l1l111_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ㋸") and l1l1l1l11l1_l1_>l1l111lll11_l1_: l1l1l1l11l1_l1_ = l1l111lll11_l1_
	if l1l1ll1l11l_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l111lll1_l1_ in range(len(l1l1l111lll_l1_)):
			text = pickle.dumps(data[l1l111lll1_l1_])
			l1l11l11111_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l111lll_l1_[l1l111lll1_l1_],))
			l1l11ll1l_l1_.append((l1l1l1l11l1_l1_+now,str(l1l1l111lll_l1_[l1l111lll1_l1_]),l1l11l11111_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l11ll1l_l1_ = zlib.compress(text)
	try: conn,l1llll1lll_l1_ = l1l1lll1lll_l1_(l1ll1lll1l_l1_)
	except: return
	while True:
		try:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡄࡈࡋࡎࡔࠠࡊࡏࡐࡉࡉࡏࡁࡕࡇࠣࡘࡗࡇࡎࡔࡃࡆࡘࡎࡕࡎࠡ࠽ࠪ㋹"))
			break
		except: time.sleep(0.5)
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡆࡖࡊࡇࡔࡆࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡓࡕࡔࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ㋺")+table+l1l111_l1_ (u"ࠪࠦࠥ࠮ࡥࡹࡲ࡬ࡶࡾ࠲ࡣࡰ࡮ࡸࡱࡳ࠲ࡤࡢࡶࡤ࠭ࠥࡁࠧ㋻"))
	if l1l1ll1l11l_l1_:
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㋼")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㋽"),l1l11ll11_l1_)
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭㋾")+table+l1l111_l1_ (u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ㋿"),l1l11ll1l_l1_)
	else:
		if l1l1l1l11l1_l1_:
			tt = (str(l1l1l111lll_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㌀")+table+l1l111_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ㌁"),tt)
			tt = (l1l1l1l11l1_l1_+now,str(l1l1l111lll_l1_),l1l1l11ll1l_l1_)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠤࠪ㌂")+table+l1l111_l1_ (u"ࠫࠧࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠯ࠠ࠼ࠩ㌃"),tt)
		else:
			tt = (l1l1l11ll1l_l1_,str(l1l1l111lll_l1_))
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࡛ࠬࡐࡅࡃࡗࡉࠥࠨࠧ㌄")+table+l1l111_l1_ (u"࠭ࠢࠡࡕࡈࡘࠥࡪࡡࡵࡣࠣࡁࠥࡅࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㌅"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if PY3: import urllib.parse as l1l1llll111_l1_
	else: import urllib as l1l1llll111_l1_
	l1ll11111l1_l1_ = l1l1llll111_l1_.urlencode(data)
	return l1ll11111l1_l1_
l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ㌆")
def l1llll111_l1_(l1llllll_l1_,l1ll1ll11ll_l1_=l1l111_l1_ (u"ࠨࠩ㌇"),l1l11111l11_l1_=l1l111_l1_ (u"ࠩࠪ㌈")):
	l1l1l1ll111_l1_ = l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ㌉"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㌊")]
	global l1l1ll1ll1l_l1_
	if not l1l11111l11_l1_: l1l11111l11_l1_ = l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㌋")
	l1l1ll1ll1l_l1_,l1l11llll11_l1_,httpd = l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤ࠱ࠩ㌌"),l1l111_l1_ (u"ࠧࠨ㌍"),l1l111_l1_ (u"ࠨࠩ㌎")
	if len(l1llllll_l1_)==3:
		url,l1l11llll1l_l1_,httpd = l1llllll_l1_
		if l1l11llll1l_l1_: l1l11llll11_l1_ = l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫ㌏")+l1l11llll1l_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㌐")
	else: url,l1l11llll1l_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠫࠬ㌑"),l1l111_l1_ (u"ࠬ࠭㌒")
	url = url.replace(l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ㌓"),l1l111_l1_ (u"ࠧࠡࠩ㌔"))
	l11ll1l11l_l1_ = GET_VIDEOFILETYPE(url)
	if l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㌕"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㌖")]:
		if l1ll1ll11ll_l1_!=l1l111_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㌗"): url = url.replace(l1l111_l1_ (u"ࠫࠥ࠭㌘"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ㌙"))
		l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌚"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡳࡰࡦࡿ࠯ࡥࡱࡺࡲࡱࡵࡡࡥࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㌛")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㌜")+l1l11llll11_l1_)
		if l11ll1l11l_l1_==l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㌝") and l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㌞"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㌟")]:
			from LIBSTWO import l1l11l11l1_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11l1_l1_(url)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭㌠")+str(count)+l1l111_l1_ (u"࠭ࠠๆๆไ࠭ࠬ㌡"), l1l1lll1_l1_)
				if l11l11l_l1_==-1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠪ㌢"),l1l111_l1_ (u"ࠨࠩ㌣"))
					return l1l1ll1ll1l_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠩ࠰࠵ࠬ㌤"):
				l1l1111111_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㌥"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡀࠠ࡜ࠢࠪ㌦")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㌧")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㌨"))
		if l1l111_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ㌩") in url: url = url+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㌪")
		elif l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㌫") in url.lower() and l1l111_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ㌬") not in url and l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㌭") not in url:
			if l1l111_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ㌮") not in url and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ㌯") in url.lower():
				if l1l111_l1_ (u"ࠧࡽࠩ㌰") not in url: url = url+l1l111_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ㌱")
				else: url = url+l1l111_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭㌲")
			if l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ㌳") not in url.lower() and l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㌴"),l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㌵")]:
				if l1l111_l1_ (u"࠭ࡼࠨ㌶") not in url: url = url+l1l111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㌷")
				else: url = url+l1l111_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㌸")
	l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㌹"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡇࡰࡶࠣࡪ࡮ࡴࡡ࡭ࠢࡸࡶࡱࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㌺")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㌻"))
	l1l1111l1ll_l1_ = xbmcgui.ListItem()
	l1l11111l11_l1_,l1l11ll11ll_l1_,l1l1l11l1ll_l1_,l1l1111lll1_l1_,l1l1l1llll1_l1_,l1l11111l1l_l1_,l1l11ll11l1_l1_,l1l11ll1111_l1_,l1l1l111111_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㌼"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㌽")]:
		if PY2: l1l1111ll11_l1_ = l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࡦࡪࡤࡰࡰࠪ㌾")
		else: l1l1111ll11_l1_ = l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠭㌿")
		l1l1111l1ll_l1_.setProperty(l1l1111ll11_l1_, l1l111_l1_ (u"ࠩࠪ㍀"))
		l1l1111l1ll_l1_.setMimeType(l1l111_l1_ (u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨ㍁"))
		if kodi_version<20: l1l1111l1ll_l1_.setInfo(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㍂"),{l1l111_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨ㍃"):l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㍄")})
		else:
			l1l1l1111l1_l1_ = l1l1111l1ll_l1_.getVideoInfoTag()
			l1l1l1111l1_l1_.setMediaType(l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭㍅"))
		l1l1111l1ll_l1_.setArt({l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ㍆"):l1l1l1llll1_l1_,l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩ㍇"):l1l1l1llll1_l1_,l1l111_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪ㍈"):l1l1l1llll1_l1_,l1l111_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ㍉"):l1l1l1llll1_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧ㍊"):l1l1l1llll1_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩ㍋"):l1l1l1llll1_l1_,l1l111_l1_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ㍌"):l1l1l1llll1_l1_,l1l111_l1_ (u"ࠨ࡫ࡦࡳࡳ࠭㍍"):l1l1l1llll1_l1_})
		if l11ll1l11l_l1_ in [l1l111_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ㍎"),l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㍏")]: l1l1111l1ll_l1_.setContentLookup(True)
		else: l1l1111l1ll_l1_.setContentLookup(False)
		from l1l11lll1ll_l1_ import l1l1l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫࡷࡺ࡭ࡱࠩ㍐") in url:
			l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㍑"),False)
		elif l11ll1l11l_l1_==l1l111_l1_ (u"࠭࠮࡮ࡲࡧࠫ㍒") or l1l111_l1_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ㍓") in url:
			l1l1l1ll1ll_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㍔"),False)
			l1l1111l1ll_l1_.setProperty(l1l1111ll11_l1_,l1l111_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㍕"))
			l1l1111l1ll_l1_.setProperty(l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ㍖"),l1l111_l1_ (u"ࠫࡲࡶࡤࠨ㍗"))
		if l1l11llll1l_l1_:
			l1l1111l1ll_l1_.setSubtitles([l1l11llll1l_l1_])
	if l1l11111l11_l1_==l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㍘") and l1ll1ll11ll_l1_==l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㍙"):
		l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㍚")
		l1ll1ll11ll_l1_ = l1l111_l1_ (u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ㍛")
	elif l1l11111l11_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㍜") and l1l11ll1111_l1_.startswith(l1l111_l1_ (u"ࠪ࠺ࠬ㍝")):
		l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㍞")
		l1ll1ll11ll_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠬࡥࡄࡍࠩ㍟")
	if l1l1ll1ll1l_l1_!=l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㍠"): l1l1l1ll11l_l1_()
	l1l11ll1lll_l1_ = l1l1l11llll_l1_()
	l1l11ll1lll_l1_.init(l1ll1ll11ll_l1_)
	if l1l11ll1lll_l1_.l1l1ll1ll1l_l1_: l1l1ll1ll1l_l1_ == l1l111_l1_ (u"ࠧࠨ㍡")
	elif l1l11111l11_l1_==l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㍢") and not l1l11ll1111_l1_.startswith(l1l111_l1_ (u"ࠩ࠹ࠫ㍣")):
		l1l1111l1ll_l1_.setPath(url)
		l1l1111111_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㍤"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㍥")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㍦"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l1111l1ll_l1_)
	elif l1l11111l11_l1_==l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㍧"):
		l1l1111111_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㍨"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡑ࡯ࡶࡦࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡰ࡭ࡣࡼࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㍩")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㍪"))
		l1l11ll1lll_l1_.play(url,l1l1111l1ll_l1_)
	succeeded = False
	if l1l1ll1ll1l_l1_==l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㍫"):
		from l11lll1l11_l1_ import l11lll111l_l1_
		succeeded = l11lll111l_l1_(url,l11ll1l11l_l1_,l1ll1ll11ll_l1_)
		if succeeded: l1l1l1ll11l_l1_()
	else:
		l1l111111ll_l1_,l1l1ll1ll1l_l1_,l1l1llll1ll_l1_,l1l11111ll1_l1_,l1l1lllll1l_l1_ = 0,l1l111_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㍬"),False,1000,30000
		if l1l1l1ll111_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l111111ll_l1_<l1l1lllll1l_l1_:
			xbmc.sleep(l1l11111ll1_l1_)
			l1l111111ll_l1_ += l1l11111ll1_l1_
			l1l1ll1ll1l_l1_ = l1l11ll1lll_l1_.l1l1ll1ll1l_l1_
			if l1l1ll1ll1l_l1_==l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭㍭") and not l1l1llll1ll_l1_:
				if l1l1l1ll111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอฯࠣษ๏าวะ่่ࠢๆࠦวๅใํำ๏๎ࠧ㍮"),l1l111_l1_ (u"ࠧࠨ㍯"),time=500)
				l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㍰"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡴࡶࡤࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㍱")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㍲")+l1l11llll11_l1_)
				l1l1llll1ll_l1_ = True
			elif l1l1ll1ll1l_l1_ in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㍳"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㍴")]:
				l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㍵"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㍶")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㍷")+l1l11llll11_l1_)
				break
			elif l1l1ll1ll1l_l1_==l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㍸"):
				l1l1111111_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㍹"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㍺")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㍻")+l1l11llll11_l1_)
				if l1l1l1ll111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอฯࠣษ๏าวะ่่ࠢๆࠦวๅใํำ๏๎ࠧ㍼"),l1l111_l1_ (u"ࠧࠨ㍽"),time=1000)
				break
			elif l1l1ll1ll1l_l1_==l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㍾"):
				l1l1111111_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㍿"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡥࡰࡴࡩ࡫ࡦࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㎀")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㎁"))
				break
		else:
			if l1l1l1ll111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢอุ฿๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭㎂"),l1l111_l1_ (u"࠭ࠧ㎃"),time=1000)
			l1l1111111_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㎄"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤ࡙࡯࡭ࡦࡱࡸࡸ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㎅")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㎆")+l1l11llll11_l1_)
			l1l1ll1ll1l_l1_ = l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㎇")
	if l1l1ll1ll1l_l1_ in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㎈"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㎉"),l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㎊")] or succeeded:
		if l1l1ll1ll1l_l1_==l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㎋"): l1ll1ll11ll_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠨࡡࡗࡗࠬ㎌")
		response = l1l1lllll11_l1_(l1ll1ll11ll_l1_)
	else: exec(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩ㎍"))
	return l1l1ll1ll1l_l1_
def GET_VIDEOFILETYPE(url):
	l11ll1l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡡ࠴ࡡࡷ࡫ࡿࡠ࠳ࡺࡳࡽ࡞࠱ࡥࡦࡩࡼ࡝࠰ࡰࡴ࠹ࢂ࡜࠯࡯࠶ࡹࢁࡢ࠮࡮࠵ࡸ࠼ࢁࡢ࠮࡮ࡲࡧࢀࡡ࠴࡭࡬ࡸࡿࡠ࠳࡬࡬ࡷࡾ࡟࠲ࡲࡶ࠳ࡽ࡞࠱ࡻࡪࡨ࡭ࠪࠪࡿࡠࡄ࠴ࠪࡀࡾ࠲ࡠࡄ࠴ࠪࡀࡾ࡟ࢀ࠳࠰࠿ࠪࠦࠪ㎎"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11ll1l11l_l1_: l11ll1l11l_l1_ = l11ll1l11l_l1_[0][0]
	else: l11ll1l11l_l1_ = l1l111_l1_ (u"ࠫࠬ㎏")
	return l11ll1l11l_l1_
WRITE_TO_sSQL3 = l1lll11111l_l1_
READ_FROM_sSQL3 = l1lll11l11l_l1_
DELETE_FROM_sSQL3 = l1lll1ll11l_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11lllll11_l1_
LOGg_THIS = l1l1111111_l1_
PLAY_VIDEOo = l1llll111_l1_
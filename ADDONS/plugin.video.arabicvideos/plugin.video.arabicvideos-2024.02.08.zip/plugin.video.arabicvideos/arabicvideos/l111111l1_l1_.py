# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ᠁")
headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᠂") : l1l111_l1_ (u"ࠨࠩ᠃") }
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡇࡒࡌ࡟ࠨ᠄")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==90: l1lll_l1_ = l1l1l11_l1_()
	elif mode==91: l1lll_l1_ = ITEMS(url)
	elif mode==92: l1lll_l1_ = PLAY(url)
	elif mode==94: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==95: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==99: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠅"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ᠆"),l1l111_l1_ (u"ࠬ࠭᠇"),99,l1l111_l1_ (u"࠭ࠧ᠈"),l1l111_l1_ (u"ࠧࠨ᠉"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᠊"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᠋"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᠌"),l1l111_l1_ (u"ࠫࠬ᠍"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᠎"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᠏")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭᠐"),l1l111_l1_ (u"ࠨࠩ᠑"),94)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᠒"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᠓")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊รฮัฮࠫ᠔"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡡࡵࡧࡶࡸࠬ᠕"),91)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᠖"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᠗")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ว฾๊้ࠡฬๅ๎๊อ๋ࠨ᠘"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡬ࡱࡩࡨࠧ᠙"),91)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠚"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᠛")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไฤๅฮี๋ࠥิศ้าอࠬ᠜"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࡶࡪࡧࡺࠫ᠝"),91)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠞"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᠟")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊ัศหࠩᠠ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡴ࡮ࡴࠧᠡ"),91)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᠢ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᠣ")+l1lllll_l1_+l1l111_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬᠤ"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡯ࡧࡺࡑࡴࡼࡩࡦࡵࠪᠥ"),91)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᠦ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᠧ")+l1lllll_l1_+l1l111_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩᠨ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡳ࡫ࡷࡆࡲ࡬ࡷࡴࡪࡥࡴࠩᠩ"),91)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᠪ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᠫ"),l1l111_l1_ (u"ࠧࠨᠬ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩᠭ"),headers,l1l111_l1_ (u"ࠩࠪᠮ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᠯ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡧࡩ࡯࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡲࡦࡼࠧᠰ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᠱ"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"࠭วโๆส้๊ࠥไไสสีࠥ็โุࠩᠲ")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩᠳ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᠴ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᠵ")+l1lllll_l1_+title,l1ll1ll_l1_,91)
	return html
def ITEMS(url):
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࠨᠶ") in url:
		url,search = url.split(l1l111_l1_ (u"ࠫࡄࡺ࠽ࠨᠷ"))
		headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᠸ") : l1l111_l1_ (u"࠭ࠧᠹ") , l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᠺ") : l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧᠻ") }
		data = { l1l111_l1_ (u"ࠩࡷࠫᠼ") : search }
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨᠽ"),url,data,headers,l1l111_l1_ (u"ࠫࠬᠾ"),l1l111_l1_ (u"ࠬ࠭ᠿ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫᡀ"))
		html = response.content
	else:
		headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᡁ") : l1l111_l1_ (u"ࠨࠩᡂ") }
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪᡃ"),headers,l1l111_l1_ (u"ࠪࠫᡄ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠸࡮ࡥࠩᡅ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡳࡻ࡯ࡥࡴ࠯࡬ࡸࡪࡳࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶࡩࡳࡴࡺࠢࠨᡆ"),html,re.DOTALL)
	if l11llll_l1_: block = l11llll_l1_[0]
	else: block = l1l111_l1_ (u"࠭ࠧᡇ")
	items = re.findall(l1l111_l1_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡳ࡯ࡷ࡫ࡨ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᡈ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠨษ็ั้่ษࠨᡉ") in title and l1l111_l1_ (u"ࠩ࠲ࡧ࠴࠭ᡊ") not in url and l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴ࠰ࠩᡋ") not in url:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣ࡟࠵࠳࠹࡞࠭ࠪᡌ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᡍ")+l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᡎ"),l1lllll_l1_+title,l1ll1ll_l1_,95,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨᡏ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᡐ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᡑ"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨᡒ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᡓ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭ᡔ"),l1l111_l1_ (u"࠭ࠧᡕ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡖ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧᡗ")+title,l1ll1ll_l1_,91)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪᡘ"),headers,l1l111_l1_ (u"ࠪࠫᡙ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᡚ"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᡛ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᡜ"),html,re.DOTALL)
	if l11llll_l1_:
		name = re.findall(l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡵࡸ࡯ࡱ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᡝ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩᡞ"))
			if l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᡟ") in name: name = name.split(l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᡠ"),1)[1]
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᡡ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᡢ"),l1lllll_l1_+name+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᡣ")+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	else:
		tmp = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡱࡹ࡭ࡪࡺࡩࡵ࡮ࡨࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᡤ"),html,re.DOTALL)
		if tmp: l1ll1ll_l1_,title = tmp[0]
		else: l1ll1ll_l1_,title = url,name
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᡥ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1111111l_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪᡦ"),headers,l1l111_l1_ (u"ࠪࠫᡧ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᡨ"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡥࡹࡶ࠰ࡷ࡭ࡧࡤࡰࡹ࠽ࠤࡳࡵ࡮ࡦ࠽ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᡩ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡰ࡮ࡴ࡫ࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩᡪ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᡫ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᡬ")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡻ࠳ࡴࡢࡤࡶࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࠮ࡲࡤࡲࡪࡲ࠭࡮ࡱࡵࡩࠬᡭ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡨࡱࡧ࡫ࡤࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᡮ"),block,re.DOTALL)
		for id,l1ll1ll_l1_ in items:
			title = l1l111_l1_ (u"ุࠫ๐ัโำࠣࠫᡯ")+id
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᡰ")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᡱ")
			l1llll_l1_.append(l1ll1ll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᡲ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᡳ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᡴ")+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᡵ"),url)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬᡶ"),headers,l1l111_l1_ (u"ࠬ࠭ᡷ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬᡸ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦ࡮ࡴࡤࡦࡺ࠰ࡰࡦࡹࡴ࠮࡯ࡲࡺ࡮࡫ࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣ࡫ࡱࡨࡪࡾ࠭ࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪ࠭᡹"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᡺"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ᡻") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᡼"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᡽"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭᡾"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ᡿"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩᢀ"),l1l111_l1_ (u"ࠨ࠭ࠪᢁ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡵ࠿ࠪᢂ")+search
	ITEMS(url)
	return
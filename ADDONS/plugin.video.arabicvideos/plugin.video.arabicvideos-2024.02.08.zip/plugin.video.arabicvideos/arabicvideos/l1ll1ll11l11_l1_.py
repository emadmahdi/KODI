# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ䘈")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡐࡘ࡚࡟ࠨ䘉")
l1l1ll1llll1_l1_ = 4
l1l1ll1ll1l1_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll1l1_l1_):
	try: l1l1ll11ll11_l1_ = str(l1llllll1l1_l1_[l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘊")])
	except: l1l1ll11ll11_l1_ = l1l111_l1_ (u"ࠫࠬ䘋")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1lll1ll1l_l1_(text)
	elif mode==162: l1lll_l1_ = l1l1ll11111l_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l1ll11111l_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1lll1l1ll_l1_(text)
	elif mode==165: l1lll_l1_ = l1l1l1ll1l1l_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1lll111ll_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l1l1ll1l11_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l1l1l1l11l_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1lll1l111_l1_()
	elif mode==762: l1lll_l1_ = l1l1ll1l1111_l1_()
	elif mode==763: l1lll_l1_ = l1l1ll1ll11l_l1_(l1l1ll11ll11_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1ll1lll11_l1_(l1l1ll11ll11_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1lll11ll1_l1_(l1l1ll11ll11_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘌"),l1l111_l1_ (u"࠭โ็๊สฮࠥะไโิํ์ู๋ࠦี๊สส๏ฯࠧ䘍"),l1l111_l1_ (u"ࠧࠨ䘎"),161,l1l111_l1_ (u"ࠨࠩ䘏"),l1l111_l1_ (u"ࠩࠪ䘐"),l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘑"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘒"),l1l111_l1_ (u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ䘓"),l1l111_l1_ (u"࠭ࠧ䘔"),162,l1l111_l1_ (u"ࠧࠨ䘕"),l1l111_l1_ (u"ࠨࠩ䘖"),l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘗"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘘"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ䘙"),l1l111_l1_ (u"ࠬ࠭䘚"),163,l1l111_l1_ (u"࠭ࠧ䘛"),l1l111_l1_ (u"ࠧࠨ䘜"),l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘝"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘞"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥฮอฬࠢ฼ุํอฦ๋ࠩ䘟"),l1l111_l1_ (u"ࠫࠬ䘠"),164,l1l111_l1_ (u"ࠬ࠭䘡"),l1l111_l1_ (u"࠭ࠧ䘢"),l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘣"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘤"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ䘥"),l1l111_l1_ (u"ࠪࠫ䘦"),763,l1l111_l1_ (u"ࠫࠬ䘧"),l1l111_l1_ (u"ࠬ࠭䘨"),l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䘩"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䘪"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䘫"),l1l111_l1_ (u"ࠩࠪ䘬"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘭"),l1l111_l1_ (u"ࠫ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ䘮"),l1l111_l1_ (u"ࠬ࠭䘯"),163,l1l111_l1_ (u"࠭ࠧ䘰"),l1l111_l1_ (u"ࠧࠨ䘱"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘲"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘳"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ䘴"),l1l111_l1_ (u"ࠫࠬ䘵"),163,l1l111_l1_ (u"ࠬ࠭䘶"),l1l111_l1_ (u"࠭ࠧ䘷"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘸"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘹"),l1l111_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ䘺"),l1l111_l1_ (u"ࠪࠫ䘻"),162,l1l111_l1_ (u"ࠫࠬ䘼"),l1l111_l1_ (u"ࠬ࠭䘽"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘾"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘿"),l1l111_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ䙀"),l1l111_l1_ (u"ࠩࠪ䙁"),162,l1l111_l1_ (u"ࠪࠫ䙂"),l1l111_l1_ (u"ࠫࠬ䙃"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙄"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙅"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷࡚ࠦศฮอࠣ฽ู๎วว์ࠪ䙆"),l1l111_l1_ (u"ࠨࠩ䙇"),164,l1l111_l1_ (u"ࠩࠪ䙈"),l1l111_l1_ (u"ࠪࠫ䙉"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䙊"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䙋"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭䙌"),l1l111_l1_ (u"ࠧࠨ䙍"),765,l1l111_l1_ (u"ࠨࠩ䙎"),l1l111_l1_ (u"ࠩࠪ䙏"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䙐"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䙑"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䙒"),l1l111_l1_ (u"࠭ࠧ䙓"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䙔"),l1l111_l1_ (u"ࠨไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭䙕"),l1l111_l1_ (u"ࠩࠪ䙖"),163,l1l111_l1_ (u"ࠪࠫ䙗"),l1l111_l1_ (u"ࠫࠬ䙘"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䙙"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙚"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ䙛"),l1l111_l1_ (u"ࠨࠩ䙜"),163,l1l111_l1_ (u"ࠩࠪ䙝"),l1l111_l1_ (u"ࠪࠫ䙞"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䙟"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䙠"),l1l111_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ䙡"),l1l111_l1_ (u"ࠧࠨ䙢"),162,l1l111_l1_ (u"ࠨࠩ䙣"),l1l111_l1_ (u"ࠩࠪ䙤"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙥"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙦"),l1l111_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭䙧"),l1l111_l1_ (u"࠭ࠧ䙨"),162,l1l111_l1_ (u"ࠧࠨ䙩"),l1l111_l1_ (u"ࠨࠩ䙪"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䙫"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙬"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨ䙭"),l1l111_l1_ (u"ࠬ࠭䙮"),164,l1l111_l1_ (u"࠭ࠧ䙯"),l1l111_l1_ (u"ࠧࠨ䙰"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙱"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙲"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䙳"),l1l111_l1_ (u"ࠫࠬ䙴"),764,l1l111_l1_ (u"ࠬ࠭䙵"),l1l111_l1_ (u"࠭ࠧ䙶"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䙷"))
	return
def l1l1lll1l111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙸"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ䙹")+l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨ䙺"),l1l111_l1_ (u"ࠫࠬ䙻"),764)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙼"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䙽"),l1l111_l1_ (u"ࠧࠨ䙾"),9999)
	for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡌࡔࠬ䙿")+str(l1l1ll11ll11_l1_)+l1l111_l1_ (u"ࠩࡢࠫ䚀")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䚁"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭䚂")+NUMBERS_SEQ_NAME[l1l1ll11ll11_l1_],l1l111_l1_ (u"ࠬ࠭䚃"),764,l1l111_l1_ (u"࠭ࠧ䚄"),l1l111_l1_ (u"ࠧࠨ䚅"),l1l111_l1_ (u"ࠨࠩ䚆"),l1l111_l1_ (u"ࠩࠪ䚇"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䚈"):l1l1ll11ll11_l1_})
	return
def l1l1ll1l1111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䚉"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䚊")+l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪ䚋"),l1l111_l1_ (u"ࠧࠨ䚌"),765)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䚍"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䚎"),l1l111_l1_ (u"ࠪࠫ䚏"),9999)
	for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓࡕࠨ䚐")+str(l1l1ll11ll11_l1_)+l1l111_l1_ (u"ࠬࡥࠧ䚑")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䚒"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ䚓")+NUMBERS_SEQ_NAME[l1l1ll11ll11_l1_],l1l111_l1_ (u"ࠨࠩ䚔"),765,l1l111_l1_ (u"ࠩࠪ䚕"),l1l111_l1_ (u"ࠪࠫ䚖"),l1l111_l1_ (u"ࠫࠬ䚗"),l1l111_l1_ (u"ࠬ࠭䚘"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䚙"):l1l1ll11ll11_l1_})
	return
def l1l1lll11lll_l1_(l1lll11l1ll_l1_):
	global l1l1ll11l111_l1_,l1l1ll111ll1_l1_
	l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll111l1_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
	try:
		if l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭䚚") in l1lll11l1ll_l1_: l1lll1111l1_l1_(l1lll11l1ll_l1_)
		else: l1lll1111l1_l1_()
		l1l1ll11llll_l1_ = False
	except:
		l11l1llll11_l1_()
		l1l1ll11llll_l1_ = True
	l1lll11l1ll_l1_ = TRANSLATE(l1lll11l1ll_l1_)
	if l1l1ll11llll_l1_:
		l1ll1lll_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"ࠨใื่๊ࠥไฤีไࠫ䚛"),time=2000)
		l1l1ll11l111_l1_ += 1
		l1l1ll111ll1_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䚜")+l1lll11l1ll_l1_
	else: l1ll1lll_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"ࠪࠫ䚝"),time=1000)
	return
def l1l1ll11l1l1_l1_(l1l1ll1l111l_l1_=True):
	global l1l1ll11l111_l1_,l1l1ll111ll1_l1_
	if not l1l1ll1l111l_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䚞"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭䚟"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫ䚠"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䚡"),l1l111_l1_ (u"ࠨࠩ䚢"),l1l111_l1_ (u"ࠩࠪ䚣"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䚤"),l1l111_l1_ (u"้้๊ࠫࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠฤ่ࠣ๎ๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢ็็๏๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳ࠦหๆࠢํๆํ๋ࠠศๆหี๋อๅอࠢหาื์่ࠠา๊ࠤฬ๊รใีส้ࠥำส๊ࠢ็หࠥะอหษฯࠤศ์ࠠห็็ส์อࠠๆำฬࠤศิั๊ࠢ࠱ࠤ฾๋ไ๋ห้้ࠣฬࠠอ็ํ฽ࠥอไฤไึห๊ࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ䚥"))
	if l1llll111l_l1_!=1: return
	l1lll1l1l1l_l1_(False,False,False)
	l1l1l1l1lll1_l1_ = menuItemsLIST
	l1l1ll11l111_l1_,l1l1ll111ll1_l1_,threads = 0,l1l111_l1_ (u"ࠬ࠭䚦"),{}
	for l1lll11l1ll_l1_ in l11llllll11_l1_:
		time.sleep(1)
		threads[l1lll11l1ll_l1_] = threading.Thread(target=l1l1lll11lll_l1_,args=(l1lll11l1ll_l1_,))
		threads[l1lll11l1ll_l1_].start()
		if l1l1ll11l111_l1_>=l1l1ll1ll1l1_l1_: break
	else:
		for l1lll11l1ll_l1_ in list(threads.keys()):
			threads[l1lll11l1ll_l1_].join()
	menuItemsLIST[:] = l1l1l1l1lll1_l1_
	if l1l1ll11l111_l1_>=l1l1ll1ll1l1_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚧"),l1l111_l1_ (u"ࠧࠨ䚨"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䚩"),l1l111_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ䚪")+str(l1l1ll11l111_l1_)+l1l111_l1_ (u"ࠪࠤ๊๎วใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํูศษ้สࠤ็ี๋ࠠๅ๋๊ࠥ฿ฯๆ๋ࠢะํีࠠฦ่อี๋๐สࠡใํࠤัํวำๅࠣ์์๐࠺ࠨ䚫")+l1l1ll111ll1_l1_)
	else:
		l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ䚬"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪ䚭"),contentsDICT,l1ll111l1l1_l1_)
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚮"),l1l111_l1_ (u"ࠧࠨ䚯"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䚰"),l1l111_l1_ (u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ䚱"))
	l1lll1l1l1l_l1_(l1l111_l1_ (u"ࠪࠫ䚲"),l1l111_l1_ (u"ࠫࠬ䚳"),l1l111_l1_ (u"ࠬ࠭䚴"))
	return
def l1l1l1lllll1_l1_(l1l1ll11ll11_l1_,options):
	l111ll1lll1_l1_ = False
	l1l1l1l1l1l1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l111ll1lll1_l1_ and l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䚵") not in options:
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䚶"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䚷"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䚸")+l1l1ll11ll11_l1_)
	elif l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䚹") not in options or l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䚺") not in options:
		import IPTV
		message = l1l111_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ䚻")
		if l1l111_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭䚼") not in options:
			try: IPTV.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚽"),l1l111_l1_ (u"ࠨࠩ䚾"),l1l111_l1_ (u"ࠩࠪ䚿"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛀"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䛁"),l1l111_l1_ (u"ࠬ࠭䛂"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ䛃"),message)
			try: IPTV.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䛄"),l1l111_l1_ (u"ࠨࠩ䛅"),l1l111_l1_ (u"ࠩࠪ䛆"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛇"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䛈"),l1l111_l1_ (u"ࠬ࠭䛉"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ䛊"),message)
			try: IPTV.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䛋"),l1l111_l1_ (u"ࠨࠩ䛌"),l1l111_l1_ (u"ࠩࠪ䛍"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛎"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䛏"),l1l111_l1_ (u"ࠬ࠭䛐"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ䛑"),message)
		if l1l111_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䛒") not in options:
			try: IPTV.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䛓"),l1l111_l1_ (u"ࠩࠪ䛔"),l1l111_l1_ (u"ࠪࠫ䛕"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䛖"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䛗"),l1l111_l1_ (u"࠭ࠧ䛘"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䛙"),message)
			try: IPTV.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䛚"),l1l111_l1_ (u"ࠩࠪ䛛"),l1l111_l1_ (u"ࠪࠫ䛜"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䛝"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䛞"),l1l111_l1_ (u"࠭ࠧ䛟"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䛠"),message)
		l1lll_l1_ = menuItemsLIST
		if l111ll1lll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䛡"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䛢")+l1l1ll11ll11_l1_,l1lll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l1l1l1l1l1_l1_
	return l1lll_l1_
def l1l1ll11lll1_l1_(l1l1ll11ll11_l1_,options):
	l111ll1lll1_l1_ = False
	l1l1l1l1l1l1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l111ll1lll1_l1_ and l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䛣") not in options:
		l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䛤"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ䛥"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䛦")+l1l1ll11ll11_l1_)
	elif l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䛧") not in options or l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䛨") not in options:
		import M3U
		message = l1l111_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ䛩")
		if l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䛪") not in options:
			try: M3U.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䛫"),l1l111_l1_ (u"ࠬ࠭䛬"),l1l111_l1_ (u"࠭ࠧ䛭"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛮"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䛯"),l1l111_l1_ (u"ࠩࠪ䛰"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ䛱"),message)
			try: M3U.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䛲"),l1l111_l1_ (u"ࠬ࠭䛳"),l1l111_l1_ (u"࠭ࠧ䛴"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛵"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䛶"),l1l111_l1_ (u"ࠩࠪ䛷"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ䛸"),message)
			try: M3U.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䛹"),l1l111_l1_ (u"ࠬ࠭䛺"),l1l111_l1_ (u"࠭ࠧ䛻"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛼"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䛽"),l1l111_l1_ (u"ࠩࠪ䛾"),l1l111_l1_ (u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪ䛿"),message)
		if l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䜀") not in options:
			try: M3U.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䜁"),l1l111_l1_ (u"࠭ࠧ䜂"),l1l111_l1_ (u"ࠧࠨ䜃"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䜄"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䜅"),l1l111_l1_ (u"ࠪࠫ䜆"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䜇"),message)
			try: M3U.GROUPS(l1l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䜈"),l1l111_l1_ (u"࠭ࠧ䜉"),l1l111_l1_ (u"ࠧࠨ䜊"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䜋"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䜌"),l1l111_l1_ (u"ࠪࠫ䜍"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䜎"),message)
		l1lll_l1_ = menuItemsLIST
		if l111ll1lll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ䜏"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䜐")+l1l1ll11ll11_l1_,l1lll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l1l1l1l1l1_l1_
	return l1lll_l1_
def l1l1ll1ll11l_l1_(l1l1ll11ll11_l1_,options,l1l1l1ll1lll_l1_):
	if l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䜑") in options and l1l1l1ll1lll_l1_==l1l111_l1_ (u"ࠨࠩ䜒"): l1l1ll11l1l1_l1_(True)
	elif l1l1l1ll1lll_l1_: l1l1ll11l1l1_l1_(False)
	l1l1l1lll1l1_l1_ = options.replace(l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䜓"),l1l111_l1_ (u"ࠪࠫ䜔")).replace(l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䜕"),l1l111_l1_ (u"ࠬ࠭䜖")).replace(l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䜗"),l1l111_l1_ (u"ࠧࠨ䜘"))
	if not l1l1l1ll1lll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䜙"),l1l111_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭䜚"),l1l111_l1_ (u"ࠪࠫ䜛"),763,l1l111_l1_ (u"ࠫࠬ䜜"),l1l111_l1_ (u"ࠬ࠭䜝"),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䜞")+l1l1l1lll1l1_l1_,l1l111_l1_ (u"ࠧࠨ䜟"),{l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䜠"):l1l1ll11ll11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䜡"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䜢"),l1l111_l1_ (u"ࠫࠬ䜣"),9999)
	l1llllll11_l1_ = [l1l111_l1_ (u"ࠬษแๅษ่ࠫ䜤"),l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠧ䜥"),l1l111_l1_ (u"ࠧๆีิั๏อสࠨ䜦"),l1l111_l1_ (u"ࠨสิห๊าࠧ䜧"),l1l111_l1_ (u"ࠩฦ฻ๆอไ๊ࠡๆีฯ๎ๆࠨ䜨"),l1l111_l1_ (u"ࠪี๊฼ว็ࠩ䜩"),l1l111_l1_ (u"ࠫศำฯฬ࠯ฦาึ࠭䜪"),l1l111_l1_ (u"ูࠬไศี็ࠫ䜫"),l1l111_l1_ (u"࠭ๅ้ีํๆ๎࠭䜬"),l1l111_l1_ (u"ࠧฤึ๊ี࠲ษใฬำࠪ䜭"),l1l111_l1_ (u"ࠨษ็ฦ๋࠭䜮"),l1l111_l1_ (u"ูࠩั่࠭䜯"),l1l111_l1_ (u"ࠪี๏อึสࠩ䜰"),l1l111_l1_ (u"๋ࠫ๐สโๆๆืࠬ䜱"),l1l111_l1_ (u"๋ࠬๅฬๆํ๊ࠬ䜲"),l1l111_l1_ (u"࠭ศฬࠢะ๎ࠬ䜳"),l1l111_l1_ (u"ࠧะ์้๎ฮ࠭䜴"),l1l111_l1_ (u"ࠨี้์ฬะࠧ䜵"),l1l111_l1_ (u"ࠩฦาึ๏ࠧ䜶")]
	l1l1l1l1llll_l1_ = [l1l111_l1_ (u"ࠪหๆ๊วๆࠩ䜷"),l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ䜸"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ䜹"),l1l111_l1_ (u"࠭แๅ็ࠪ䜺")]
	l1ll11lll1l_l1_ = [l1l111_l1_ (u"ࠧๆี็ื้࠭䜻"),l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䜼")]
	l1l1lll1ll11_l1_ = [l1l111_l1_ (u"่ࠩืฬือࠨ䜽"),l1l111_l1_ (u"ุ้ࠪือ๋ษอࠫ䜾")]
	l1l1l1lll11l_l1_ = [l1l111_l1_ (u"ࠫอืวๆฮࠪ䜿"),l1l111_l1_ (u"ࠬࡹࡨࡰࡹࠪ䝀"),l1l111_l1_ (u"࠭สๅใี๎ํ์ࠧ䝁"),l1l111_l1_ (u"ࠧหๆํๅื๐่็ࠩ䝂")]
	l1l1ll1ll111_l1_ = [l1l111_l1_ (u"ࠨษ้้๏࠭䝃"),l1l111_l1_ (u"ࠩๆีฯ๎ๆࠨ䝄"),l1l111_l1_ (u"ࠪ็ฬืส้่ࠪ䝅"),l1l111_l1_ (u"ࠫࡰ࡯ࡤࡴࠩ䝆"),l1l111_l1_ (u"ࠬ฽แๅࠩ䝇"),l1l111_l1_ (u"࠭วุใส่ࠬ䝈")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠧา็ูห๋࠭䝉")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠨษะำะ࠭䝊"),l1l111_l1_ (u"ࠩสาึ࠭䝋"),l1l111_l1_ (u"้ࠪํิัࠨ䝌"),l1l111_l1_ (u"ࠫัี๊ะࠩ䝍"),l1l111_l1_ (u"๋ࠬึศใࠪ䝎"),l1l111_l1_ (u"࠭อะ์ฮࠫ䝏")]
	l1l1l1llllll_l1_ = [l1l111_l1_ (u"ࠧิๆสื้࠭䝐"),l1l111_l1_ (u"ࠨี็ื้ํࠧ䝑")]
	l1l1l1l1l111_l1_ = [l1l111_l1_ (u"ࠩส฾ฬ์๊ࠨ䝒"),l1l111_l1_ (u"้ࠪํู๊ใ๋ࠪ䝓"),l1l111_l1_ (u"่๊๊ࠫษࠩ䝔"),l1l111_l1_ (u"ࠬำแๅࠩ䝕"),l1l111_l1_ (u"࠭࡭ࡶࡵ࡬ࡧࠬ䝖")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠧศๅฮีࠬ䝗"),l1l111_l1_ (u"ࠨษื๋ึ࠭䝘"),l1l111_l1_ (u"่้ࠩ๏ุ็ࠨ䝙"),l1l111_l1_ (u"ࠪห฾๊้ࠨ䝚"),l1l111_l1_ (u"๊ࠫิสศำ๊ࠫ䝛"),l1l111_l1_ (u"๋ࠬฮหษิหฯ࠭䝜"),l1l111_l1_ (u"࠭วใ๊์ࠫ䝝")]
	l1l1l1l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆส๊ࠬ䝞"),l1l111_l1_ (u"ࠨฯส่๏࠭䝟"),l1l111_l1_ (u"่ࠩฯอะࠧ䝠"),l1l111_l1_ (u"ࠪีฬฬฬࠨ䝡")]
	l1l1l1l1l1ll_l1_ = [l1l111_l1_ (u"ࠫ฻ำใࠨ䝢"),l1l111_l1_ (u"้่ࠬๆ์า๎ࠬ䝣")]
	l1l1lll111l1_l1_ = [l1l111_l1_ (u"࠭ั๋ษู๋ࠬ䝤"),l1l111_l1_ (u"ࠧไ๊ิ๋ࠬ䝥"),l1l111_l1_ (u"ࠨ็ุหึ฿็ࠨ䝦"),l1l111_l1_ (u"ࠩื์ฯ࠭䝧"),l1l111_l1_ (u"ࠪี๏อึสࠩ䝨")]
	l1l1ll1l11ll_l1_ = [l1l111_l1_ (u"๋ࠫ๐สโๆๆืࠬ䝩"),l1l111_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭䝪"),l1l111_l1_ (u"࠭ๆ๋ฬไ่๏้ำࠨ䝫")]
	l1l1l1l1ll1l_l1_ = [l1l111_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䝬"),l1l111_l1_ (u"ࠨษืาฬ฻ࠧ䝭"),l1l111_l1_ (u"้ࠩะํ๋ࠧ䝮")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠪฬะࠦอ๋ࠩ䝯"),l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䝰"),l1l111_l1_ (u"่ࠬๆศ้ࠪ䝱"),l1l111_l1_ (u"࠭โ็๊สฮࠬ䝲")]
	l1l1ll1l1ll1_l1_ = [l1l111_l1_ (u"ࠧะ์้ࠫ䝳"),l1l111_l1_ (u"ࠨษา฽๏ํࠧ䝴"),l1l111_l1_ (u"ࠩี๎ฬืวหࠩ䝵"),l1l111_l1_ (u"่ࠪ฼๋๊ศฬࠪ䝶"),l1l111_l1_ (u"ࠫิ฿วยࠩ䝷"),l1l111_l1_ (u"่ࠬัศ่ࠪ䝸"),l1l111_l1_ (u"࠭โึษษำࠬ䝹"),l1l111_l1_ (u"ࠧาอสลࠬ䝺"),l1l111_l1_ (u"ࠨ็ิะ฾๐็ࠨ䝻"),l1l111_l1_ (u"ࠩสิฬ์ࠧ䝼"),l1l111_l1_ (u"ࠪหุ๊วๆࠩ䝽"),l1l111_l1_ (u"ࠫฯ๎วี์ะࠫ䝾"),l1l111_l1_ (u"ࠬิืษࠩ䝿"),l1l111_l1_ (u"࠭อ้ิ๋๎ࠬ䞀"),l1l111_l1_ (u"ฺࠧฬหหฯ࠭䞁"),l1l111_l1_ (u"ࠨ็๋ห้๐ฯࠨ䞂"),l1l111_l1_ (u"้ࠩ์ฬ฿๊ࠨ䞃"),l1l111_l1_ (u"ࠪ฽็อฦะࠩ䞄"),l1l111_l1_ (u"ࠫฬ์วี์าࠫ䞅")]
	l1l1l1ll1111_l1_ = [l1l111_l1_ (u"ࠬ࠷࠹ࠨ䞆"),l1l111_l1_ (u"࠭࠲࠱ࠩ䞇"),l1l111_l1_ (u"ࠧ࠳࠳ࠪ䞈"),l1l111_l1_ (u"ࠨ࠴࠵ࠫ䞉"),l1l111_l1_ (u"ࠩ࠵࠷ࠬ䞊"),l1l111_l1_ (u"ࠪ࠶࠹࠭䞋"),l1l111_l1_ (u"ࠫ࠷࠻ࠧ䞌"),l1l111_l1_ (u"ࠬ࠸࠶ࠨ䞍")]
	if not l1l1l1ll1lll_l1_:
		l1l1l1ll1lll_l1_ = 0
		for l1l1ll11l1ll_l1_ in l1llllll11_l1_:
			l1l1l1ll1lll_l1_ += 1
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䞎"),l1lllll_l1_+l1l1ll11l1ll_l1_,l1l111_l1_ (u"ࠧࠨ䞏"),763,l1l111_l1_ (u"ࠨࠩ䞐"),str(l1l1l1ll1lll_l1_),l1l1l1lll1l1_l1_,l1l111_l1_ (u"ࠩࠪ䞑"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䞒"):l1l1ll11ll11_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l111111111_l1_ = name.lower()
			category = []
			if any(value in l111111111_l1_ for value in l1l1l1l1llll_l1_): category.append(1)
			if any(value in l111111111_l1_ for value in l1ll11lll1l_l1_): category.append(2)
			if any(value in l111111111_l1_ for value in l1l1lll1ll11_l1_): category.append(3)
			if any(value in l111111111_l1_ for value in l1l1l1lll11l_l1_): category.append(4)
			if any(value in l111111111_l1_ for value in l1l1ll1ll111_l1_): category.append(5)
			if any(value in l111111111_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l111111111_l1_ for value in l1lllll1l_l1_) and l111111111_l1_ not in [l1l111_l1_ (u"ࠫฬิั๊ࠩ䞓")]: category.append(7)
			if any(value in l111111111_l1_ for value in l1l1l1llllll_l1_): category.append(8)
			if any(value in l111111111_l1_ for value in l1l1l1l1l111_l1_): category.append(9)
			if any(value in l111111111_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l111111111_l1_ for value in l1l1l1l11lll_l1_): category.append(11)
			if any(value in l111111111_l1_ for value in l1l1l1l1l1ll_l1_): category.append(12)
			if any(value in l111111111_l1_ for value in l1l1lll111l1_l1_): category.append(13)
			if any(value in l111111111_l1_ for value in l1l1ll1l11ll_l1_): category.append(14)
			if any(value in l111111111_l1_ for value in l1l1l1l1ll1l_l1_): category.append(15)
			if any(value in l111111111_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l111111111_l1_ for value in l1l1ll1l1ll1_l1_): category.append(17)
			if any(value in l111111111_l1_ for value in l1l1l1ll1111_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l1l1ll1lll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䞔"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"࠭ࠧ䞕"),l1l111_l1_ (u"ࠧࠨ䞖"),l1l1l1lll1l1_l1_+l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞗"))
	return
def l1l1ll1lll11_l1_(l1l1ll11ll11_l1_,options):
	l111ll1lll1_l1_ = False
	if l111ll1lll1_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䞘"),l1l111_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ䞙"),l1l111_l1_ (u"ࠫࠬ䞚"),764,l1l111_l1_ (u"ࠬ࠭䞛"),l1l111_l1_ (u"࠭ࠧ䞜"),l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䞝"),l1l111_l1_ (u"ࠨࠩ䞞"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䞟"):l1l1ll11ll11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䞠"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䞡"),l1l111_l1_ (u"ࠬ࠭䞢"),9999)
	l1l1l1l1l1l1_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l1ll11ll11_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l1ll11ll11_l1_,True): return
		l1l1ll111111_l1_ = l1l1l1lllll1_l1_(l1l1ll11ll11_l1_,options)
		l111l1l1ll_l1_ = sorted(l1l1ll111111_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䞣"),True): return
		if l111ll1lll1_l1_ and l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䞤") not in options:
			l111l1l1ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䞥"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩ䞦"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࡅࡑࡒࠧ䞧"))
		else:
			l1l1l1ll111l_l1_,l111l1l1ll_l1_,l1l1ll111111_l1_ = [],[],[]
			for l1l1ll11l11l_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l1ll_l1_ += l1l1l1lllll1_l1_(str(l1l1ll11l11l_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in l111l1l1ll_l1_:
				if text not in l1l1l1ll111l_l1_:
					l1l1l1ll111l_l1_.append(text)
					l1l1lll11l11_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1l1_l1_
					l1l1ll111111_l1_.append(l1l1lll11l11_l1_)
			l111l1l1ll_l1_ = sorted(l1l1ll111111_l1_,reverse=False,key=lambda key: key[1].lower())
			if l111ll1lll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ䞨"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤࡇࡌࡍࠩ䞩"),l111l1l1ll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l1l1l1l1l1_l1_+l111l1l1ll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䞪"))
	return
def l1l1lll11ll1_l1_(l1l1ll11ll11_l1_,options):
	l111ll1lll1_l1_ = False
	if l111ll1lll1_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䞫"),l1l111_l1_ (u"ࠨฬะำ๏ั่ࠠา๊ࠤฬ๊โศศ่อࠬ䞬"),l1l111_l1_ (u"ࠩࠪ䞭"),765,l1l111_l1_ (u"ࠪࠫ䞮"),l1l111_l1_ (u"ࠫࠬ䞯"),l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䞰"),l1l111_l1_ (u"࠭ࠧ䞱"),{l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䞲"):l1l1ll11ll11_l1_})
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䞳"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䞴"),l1l111_l1_ (u"ࠪࠫ䞵"),9999)
	l1l1l1l1l1l1_l1_ = menuItemsLIST[:]
	import M3U
	if l1l1ll11ll11_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l1ll11ll11_l1_,True): return
		l1l1ll111111_l1_ = l1l1ll11lll1_l1_(l1l1ll11ll11_l1_,options)
		l111l1l1ll_l1_ = sorted(l1l1ll111111_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠫࠬ䞶"),True): return
		if l111ll1lll1_l1_ and l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䞷") not in options:
			l111l1l1ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䞸"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭䞹"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࡂࡎࡏࠫ䞺"))
		else:
			l1l1l1ll111l_l1_,l111l1l1ll_l1_,l1l1ll111111_l1_ = [],[],[]
			for l1l1ll11l11l_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1l1ll_l1_ += l1l1ll11lll1_l1_(str(l1l1ll11l11l_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in l111l1l1ll_l1_:
				if text not in l1l1l1ll111l_l1_:
					l1l1l1ll111l_l1_.append(text)
					l1l1lll11l11_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1l1_l1_
					l1l1ll111111_l1_.append(l1l1lll11l11_l1_)
			l111l1l1ll_l1_ = sorted(l1l1ll111111_l1_,reverse=False,key=lambda key: key[1].lower())
			if l111ll1lll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䞻"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࡄࡐࡑ࠭䞼"),l111l1l1ll_l1_,l1ll111l1l1_l1_)
	menuItemsLIST[:] = l1l1l1l1l1l1_l1_+l111l1l1ll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䞽"))
	return
def l1l1l1ll1l1l_l1_(group,options):
	l111ll1lll1_l1_ = False
	l1lll_l1_ = []
	l1l1ll11ll1l_l1_ = l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䞾") if l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ䞿") in options else l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䟀")
	if l111ll1lll1_l1_: l1lll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䟁"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫ䟂")+l1l1ll11ll1l_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
			if l111ll1lll1_l1_: l1lll_l1_ += l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䟃"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭䟄")+l1l1ll11ll1l_l1_[:-1],l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ䟅")+l1l1ll11ll1l_l1_+str(l1l1ll11ll11_l1_))
			elif l1l1ll11ll1l_l1_==l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䟆"): l1lll_l1_ += l1l1l1lllll1_l1_(str(l1l1ll11ll11_l1_),l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䟇"))
			elif l1l1ll11ll1l_l1_==l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䟈"): l1lll_l1_ += l1l1ll11lll1_l1_(str(l1l1ll11ll11_l1_),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䟉"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in l1lll_l1_:
			if text==group: l1ll1llllll1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in menuItemsLIST:
			l1l1ll1l1l1l_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠪࠫ䟊")
			if l1l1ll1l1l1l_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1ll1l1l1l_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l111ll1lll1_l1_: l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭䟋")+l1l1ll11ll1l_l1_[:-1],group,l1lll_l1_,l1ll111l1l1_l1_)
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䟌") in options and len(l1lll_l1_)>l1l1ll1llll1_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䟍"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䟎")+group+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䟏"),group,165,l1l111_l1_ (u"ࠩࠪ䟐"),l1l111_l1_ (u"ࠪࠫ䟑"),l1l1ll11ll1l_l1_+l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䟒"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䟓"),l1l111_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䟔"),group,165,l1l111_l1_ (u"ࠧࠨ䟕"),l1l111_l1_ (u"ࠨࠩ䟖"),l1l1ll11ll1l_l1_+l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䟗"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䟘"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䟙"),l1l111_l1_ (u"ࠬ࠭䟚"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1ll1llll1_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䟛"))
	return
def l1l1lll1ll1l_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䟜"),l1l111_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫ䟝"),l1l111_l1_ (u"ࠩࠪ䟞"),161,l1l111_l1_ (u"ࠪࠫ䟟"),l1l111_l1_ (u"ࠫࠬ䟠"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ䟡"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䟢"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䟣"),l1l111_l1_ (u"ࠨࠩ䟤"),9999)
	l1l1ll1ll1ll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1llll1ll1l1_l1_
	l1llll1ll1l1_l1_.ITEMS(l1l111_l1_ (u"ࠩ࠳ࠫ䟥"),False)
	l1llll1ll1l1_l1_.ITEMS(l1l111_l1_ (u"ࠪ࠵ࠬ䟦"),False)
	l1llll1ll1l1_l1_.ITEMS(l1l111_l1_ (u"ࠫ࠷࠭䟧"),False)
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䟨") in options:
		menuItemsLIST[:] = l1l1ll111l1l_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1ll1llll1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1ll1llll1_l1_)
	menuItemsLIST[:] = l1l1ll1ll1ll_l1_+menuItemsLIST
	return
def l1l1lll1l1ll_l1_(options):
	options = options.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䟩"),l1l111_l1_ (u"ࠧࠨ䟪")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟫"),l1l111_l1_ (u"ࠩࠪ䟬"))
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䟭") : l1l111_l1_ (u"ࠫࠬ䟮") }
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫ䟯")
	data = {l1l111_l1_ (u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨ䟰"):l1l111_l1_ (u"ࠧ࠶࠲ࠪ䟱")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1llll1111ll_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䟲"),url,data,headers,l1l111_l1_ (u"ࠩࠪ䟳"),l1l111_l1_ (u"ࠪࠫ䟴"),l1l111_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭䟵"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧ䟶"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ䟷"),block,re.DOTALL)
	l1l1l1l11l1l_l1_,l1l1l1ll11l1_l1_ = list(zip(*items))
	l1l1lll11l1l_l1_ = []
	l1l1lll1l1l1_l1_ = [l1l111_l1_ (u"ࠧࠡࠩ䟸"),l1l111_l1_ (u"ࠨࠤࠪ䟹"),l1l111_l1_ (u"ࠩࡣࠫ䟺"),l1l111_l1_ (u"ࠪ࠰ࠬ䟻"),l1l111_l1_ (u"ࠫ࠳࠭䟼"),l1l111_l1_ (u"ࠬࡀࠧ䟽"),l1l111_l1_ (u"࠭࠻ࠨ䟾"),l1l111_l1_ (u"ࠢࠨࠤ䟿"),l1l111_l1_ (u"ࠨ࠯ࠪ䠀")]
	l1l1l1lll1ll_l1_ = l1l1l1ll11l1_l1_+l1l1l1l11l1l_l1_
	for word in l1l1l1lll1ll_l1_:
		if word in l1l1l1ll11l1_l1_: l1l1ll1l11l1_l1_ = 2
		if word in l1l1l1l11l1l_l1_: l1l1ll1l11l1_l1_ = 4
		l1l1l1llll1l_l1_ = [i in word for i in l1l1lll1l1l1_l1_]
		if any(l1l1l1llll1l_l1_):
			index = l1l1l1llll1l_l1_.index(True)
			l1l1l1lll111_l1_ = l1l1lll1l1l1_l1_[index]
			l1l1lll11111_l1_ = l1l111_l1_ (u"ࠩࠪ䠁")
			if word.count(l1l1l1lll111_l1_)>1: l1l1lll1111l_l1_,l1l1ll1lllll_l1_,l1l1lll11111_l1_ = word.split(l1l1l1lll111_l1_,2)
			else: l1l1lll1111l_l1_,l1l1ll1lllll_l1_ = word.split(l1l1l1lll111_l1_,1)
			if len(l1l1lll1111l_l1_)>l1l1ll1l11l1_l1_: l1l1lll11l1l_l1_.append(l1l1lll1111l_l1_.lower())
			if len(l1l1ll1lllll_l1_)>l1l1ll1l11l1_l1_: l1l1lll11l1l_l1_.append(l1l1ll1lllll_l1_.lower())
			if len(l1l1lll11111_l1_)>l1l1ll1l11l1_l1_: l1l1lll11l1l_l1_.append(l1l1lll11111_l1_.lower())
		elif len(word)>l1l1ll1l11l1_l1_: l1l1lll11l1l_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1lll11l1l_l1_)
	if l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䠂") in options:
		l1l1l1l1ll11_l1_ = l1lll11l1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䠃") in options:
		l1l1l1l1ll11_l1_ = [l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ䠄")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䠅"),True): return
	elif l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䠆") in options:
		l1l1l1l1ll11_l1_ = [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ䠇")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠩࠪ䠈"),True): return
	count,l1l1l1ll11ll_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䠉"),l1l111_l1_ (u"ࠫࡠࠦࠠ࡞ࠢ࠽ห้ฮอฬࠢ฼๊ࠬ䠊"),l1l111_l1_ (u"ࠬ࠭䠋"),164,l1l111_l1_ (u"࠭ࠧ䠌"),l1l111_l1_ (u"ࠧࠨ䠍"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䠎")+options)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䠏"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪ䠐"),l1l111_l1_ (u"ࠫࠬ䠑"),164,l1l111_l1_ (u"ࠬ࠭䠒"),l1l111_l1_ (u"࠭ࠧ䠓"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䠔")+options)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䠕"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䠖"),l1l111_l1_ (u"ࠪࠫ䠗"),9999)
	l1l1l1l11l11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1lll1l11l_l1_ = []
	for word in l1l1lll11l1l_l1_:
		l1l1ll1lllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡠࠦ࡜࠭࡞࠾ࡠ࠿ࡢ࠭࡝࠭࡟ࡁࡡࠨ࡜ࠨ࡞࡞ࡠࡢࡢࠨ࡝ࠫ࡟ࡿࡡࢃ࡜ࠢ࡞ࡃࠫ䠘")+l1l111_l1_ (u"ࠬࠩࠧ䠙")+l1l111_l1_ (u"࠭࡜ࠥ࡞ࠨࡠࡣࡢࠦ࡝ࠬ࡟ࡣࡡࡂ࡜࠿࡟ࠪ䠚"),word,re.DOTALL)
		if l1l1ll1lllll_l1_: word = word.split(l1l1ll1lllll_l1_[0],1)[0]
		l1l1ll1111l1_l1_ = word.replace(l1l111_l1_ (u"ࠧ๒ࠩ䠛"),l1l111_l1_ (u"ࠨࠩ䠜")).replace(l1l111_l1_ (u"ࠩ๑ࠫ䠝"),l1l111_l1_ (u"ࠪࠫ䠞")).replace(l1l111_l1_ (u"ࠫ๐࠭䠟"),l1l111_l1_ (u"ࠬ࠭䠠")).replace(l1l111_l1_ (u"࠭๏ࠨ䠡"),l1l111_l1_ (u"ࠧࠨ䠢")).replace(l1l111_l1_ (u"ࠨ๎ࠪ䠣"),l1l111_l1_ (u"ࠩࠪ䠤"))
		l1l1ll1111l1_l1_ = l1l1ll1111l1_l1_.replace(l1l111_l1_ (u"ࠪ๔ࠬ䠥"),l1l111_l1_ (u"ࠫࠬ䠦")).replace(l1l111_l1_ (u"ࠬ๓ࠧ䠧"),l1l111_l1_ (u"࠭ࠧ䠨")).replace(l1l111_l1_ (u"ࠧ๓ࠩ䠩"),l1l111_l1_ (u"ࠨࠩ䠪")).replace(l1l111_l1_ (u"ࠩฏࠫ䠫"),l1l111_l1_ (u"ࠪࠫ䠬")).replace(l1l111_l1_ (u"ࠫๅ࠭䠭"),l1l111_l1_ (u"ࠬ࠭䠮"))
		if l1l1ll1111l1_l1_: l1l1lll1l11l_l1_.append(l1l1ll1111l1_l1_)
	l1l1ll1l1lll_l1_ = []
	for l1l111lll1_l1_ in range(0,20):
		search = random.sample(l1l1lll1l11l_l1_,1)[0]
		if search in l1l1ll1l1lll_l1_: continue
		l1l1ll1l1lll_l1_.append(search)
		l1lll11l1ll_l1_ = random.sample(l1l1l1l1ll11_l1_,1)[0]
		l1l1111111_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䠯"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪ䠰")+str(l1lll11l1ll_l1_)+l1l111_l1_ (u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫ䠱")+search)
		l1lll1111l1_l1_,l1lll11l1l1_l1_,l1llll111l1_l1_ = l1ll1llll1l_l1_(l1lll11l1ll_l1_)
		l1lll11l1l1_l1_(search+l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䠲"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䠳"),l1l111_l1_ (u"ࠫࠬ䠴"))
	l1l1l1l11l11_l1_[0][1] = l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䠵")+search+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼หัะูࠦ็࡟ࠪ䠶")
	menuItemsLIST[:] = l1l1ll111l1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1ll1llll1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1ll1llll1_l1_)
	menuItemsLIST[:] = l1l1l1l11l11_l1_+menuItemsLIST
	return
def l1l1lll111ll_l1_(l1l1l1ll1ll1_l1_,options):
	l1l1l1ll1ll1_l1_ = l1l1l1ll1ll1_l1_.replace(l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䠷"),l1l111_l1_ (u"ࠨࠩ䠸"))
	options = options.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠹"),l1l111_l1_ (u"ࠪࠫ䠺")).replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠻"),l1l111_l1_ (u"ࠬ࠭䠼"))
	l1l1ll11l1l1_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䠽") in options:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䠾"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䠿")+l1l1l1ll1ll1_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䡀"),l1l1l1ll1ll1_l1_,166,l1l111_l1_ (u"ࠪࠫ䡁"),l1l111_l1_ (u"ࠫࠬ䡂"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡃")+options)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡄"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䡅"),l1l1l1ll1ll1_l1_,166,l1l111_l1_ (u"ࠨࠩ䡆"),l1l111_l1_ (u"ࠩࠪ䡇"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡈")+options)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䡉"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䡊"),l1l111_l1_ (u"࠭ࠧ䡋"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l1l1ll1ll1_l1_].keys())):
		type,name,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = contentsDICT[l1l1l1ll1ll1_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䡌") in options or len(contentsDICT[l1l1l1ll1ll1_l1_])==1:
			l1ll1llllll1_l1_(type,l1l111_l1_ (u"ࠨࠩ䡍"),url,l1lll11ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䡎"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠪࠫ䡏"),l1l111_l1_ (u"ࠫࠬ䡐"))
			menuItemsLIST[:] = l1l1ll111l1l_l1_(menuItemsLIST)
			l1l1l1l1l1l1_l1_,l111l1l1ll_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1l1ll_l1_)
			if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䡑") in options: menuItemsLIST[:] = l1l1l1l1l1l1_l1_+l111l1l1ll_l1_[:l1l1ll1llll1_l1_]
			else: menuItemsLIST[:] = l1l1l1l1l1l1_l1_+l111l1l1ll_l1_
		elif l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䡒") in options: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䡓"),l1l11l11_l1_,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_)
	return
def l1l1ll11111l_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡔"),l1l111_l1_ (u"ࠩࠪ䡕")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡖"),l1l111_l1_ (u"ࠫࠬ䡗"))
	name,l1l1l1llll11_l1_ = l1l111_l1_ (u"ࠬ࠭䡘"),[]
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡙"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䡚")+name+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䡛"),l1l111_l1_ (u"ࠩࠪ䡜"),mode,l1l111_l1_ (u"ࠪࠫ䡝"),l1l111_l1_ (u"ࠫࠬ䡞"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡟")+options)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡠"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦืๅสࠣๆฺุ๋ࠠึ๋หห๐ࠧ䡡"),l1l111_l1_ (u"ࠨࠩ䡢"),mode,l1l111_l1_ (u"ࠩࠪ䡣"),l1l111_l1_ (u"ࠪࠫ䡤"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡥")+options)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䡦"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䡧"),l1l111_l1_ (u"ࠧࠨ䡨"),9999)
	l1l1l1l1l1l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ䡩") in options:
		l1l1ll11l1l1_l1_(False)
		if contentsDICT=={}: return
		l1l1ll111l11_l1_ = list(contentsDICT.keys())
		l1l1l1ll1ll1_l1_ = random.sample(l1l1ll111l11_l1_,1)[0]
		l1l1lll11l1l_l1_ = list(contentsDICT[l1l1l1ll1ll1_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1lll11l1l_l1_,1)[0]
		type,name,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = contentsDICT[l1l1l1ll1ll1_l1_][l1l11l11_l1_]
		l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䡪"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡻࡪࡨࡳࡪࡶࡨ࠾ࠥ࠭䡫")+l1l11l11_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䡬")+name+l1l111_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䡭")+url+l1l111_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䡮")+str(l1lll11ll1ll_l1_))
	elif l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䡯") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䡰"),True): return
		for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1l1lllll1_l1_(str(l1l1ll11ll11_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l1111111_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䡱"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䡲")+name+l1l111_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䡳")+url+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䡴")+str(l1lll11ll1ll_l1_))
	elif l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䡵") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠧࠨ䡶"),True): return
		for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1ll11lll1_l1_(str(l1l1ll11ll11_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l1111111_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䡷"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ䡸")+name+l1l111_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䡹")+url+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䡺")+str(l1lll11ll1ll_l1_))
	l1l1ll1l1l11_l1_ = name
	l1l1ll111lll_l1_ = []
	for i in range(0,10):
		if i>0: l1l1111111_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䡻"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䡼")+name+l1l111_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䡽")+url+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䡾")+str(l1lll11ll1ll_l1_))
		menuItemsLIST[:] = []
		if l1lll11ll1ll_l1_==234 and l1l111_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䡿") in text: l1lll11ll1ll_l1_ = 233
		if l1lll11ll1ll_l1_==714 and l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䢀") in text: l1lll11ll1ll_l1_ = 713
		if l1lll11ll1ll_l1_==144: l1lll11ll1ll_l1_ = 291
		dummy = l1ll1llllll1_l1_(type,name,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_)
		if l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䢁") in options and l1lll11ll1ll_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䢂") in options and l1lll11ll1ll_l1_==168: del menuItemsLIST[:3]
		l1l1l1llll11_l1_[:] = l1l1ll111l1l_l1_(menuItemsLIST)
		if l1l1ll111lll_l1_ and l111ll1ll1l_l1_(l1l111_l1_ (u"ࡻࠧฮๆๅอࠬ䢃")) in str(l1l1l1llll11_l1_) or l111ll1ll1l_l1_(l1l111_l1_ (u"ࡵࠨฯ็ๆ์࠭䢄")) in str(l1l1l1llll11_l1_):
			name = l1l1ll1l1l11_l1_
			l1l1l1llll11_l1_[:] = l1l1ll111lll_l1_
			break
		l1l1ll1l1l11_l1_ = name
		l1l1ll111lll_l1_ = l1l1l1llll11_l1_
		if str(l1l1l1llll11_l1_).count(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䢅"))>0: break
		if str(l1l1l1llll11_l1_).count(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䢆"))>0: break
		if l1lll11ll1ll_l1_==233: break
		if l1lll11ll1ll_l1_==713: break
		if l1lll11ll1ll_l1_==291: break
		if l1l1l1llll11_l1_: type,name,url,l1lll11ll1ll_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ = random.sample(l1l1l1llll11_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠪ࠲࠳࠴࠮ࠨ䢇")
	elif name.count(l1l111_l1_ (u"ࠫࡤ࠭䢈"))>1: name = name.split(l1l111_l1_ (u"ࠬࡥࠧ䢉"),2)[2]
	name = name.replace(l1l111_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔ࠺ࠡࠩ䢊"),l1l111_l1_ (u"ࠧࠨ䢋"))
	name = name.replace(l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䢌"),l1l111_l1_ (u"ࠩࠪ䢍"))
	l1l1l1l1l1l1_l1_[0][1] = l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䢎")+name+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䢏")
	for i in range(9): random.shuffle(l1l1l1llll11_l1_)
	if l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䢐") in options: menuItemsLIST[:] = l1l1l1l1l1l1_l1_+l1l1l1llll11_l1_[:l1l1ll1llll1_l1_]
	else: menuItemsLIST[:] = l1l1l1l1l1l1_l1_+l1l1l1llll11_l1_
	return
def l1l1l1ll1l11_l1_(l1l1l1l11ll1_l1_,l1l1ll1lll1l_l1_):
	l1l1ll1lll1l_l1_ = l1l1ll1lll1l_l1_.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䢑"),l1l111_l1_ (u"ࠧࠨ䢒")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䢓"),l1l111_l1_ (u"ࠩࠪ䢔"))
	l1l1ll1111ll_l1_ = l1l1ll1lll1l_l1_
	if l1l111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䢕") in l1l1ll1lll1l_l1_:
		l1l1ll1111ll_l1_ = l1l1ll1lll1l_l1_.split(l1l111_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䢖"))[0]
		type = l1l111_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ䢗")
	elif l1l111_l1_ (u"࠭ࡖࡐࡆࠪ䢘") in l1l1l1l11ll1_l1_: type = l1l111_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ䢙")
	elif l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䢚") in l1l1l1l11ll1_l1_: type = l1l111_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ䢛")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䢜"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䢝")+type+l1l1ll1111ll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䢞"),l1l1l1l11ll1_l1_,167,l1l111_l1_ (u"࠭ࠧ䢟"),l1l111_l1_ (u"ࠧࠨ䢠"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䢡")+l1l1ll1lll1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢢"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䢣"),l1l1l1l11ll1_l1_,167,l1l111_l1_ (u"ࠫࠬ䢤"),l1l111_l1_ (u"ࠬ࠭䢥"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䢦")+l1l1ll1lll1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䢧"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䢨"),l1l111_l1_ (u"ࠩࠪ䢩"),9999)
	import IPTV
	for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䢪") in l1l1ll1lll1l_l1_: IPTV.GROUPS(str(l1l1ll11ll11_l1_),l1l1l1l11ll1_l1_,l1l1ll1lll1l_l1_,l1l111_l1_ (u"ࠫࠬ䢫"),False)
		else: IPTV.ITEMS(str(l1l1ll11ll11_l1_),l1l1l1l11ll1_l1_,l1l1ll1lll1l_l1_,l1l111_l1_ (u"ࠬ࠭䢬"),False)
	menuItemsLIST[:] = l1l1ll111l1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1ll1llll1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1ll1llll1_l1_)
	return
def l1l1l1l1l11l_l1_(l1l1l1l11ll1_l1_,l1l1ll1lll1l_l1_):
	l1l1ll1lll1l_l1_ = l1l1ll1lll1l_l1_.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䢭"),l1l111_l1_ (u"ࠧࠨ䢮")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䢯"),l1l111_l1_ (u"ࠩࠪ䢰"))
	l1l1ll1111ll_l1_ = l1l1ll1lll1l_l1_
	if l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䢱") in l1l1ll1lll1l_l1_:
		l1l1ll1111ll_l1_ = l1l1ll1lll1l_l1_.split(l1l111_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䢲"))[0]
		type = l1l111_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ䢳")
	elif l1l111_l1_ (u"࠭ࡖࡐࡆࠪ䢴") in l1l1l1l11ll1_l1_: type = l1l111_l1_ (u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ䢵")
	elif l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䢶") in l1l1l1l11ll1_l1_: type = l1l111_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ䢷")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䢸"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䢹")+type+l1l1ll1111ll_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䢺"),l1l1l1l11ll1_l1_,168,l1l111_l1_ (u"࠭ࠧ䢻"),l1l111_l1_ (u"ࠧࠨ䢼"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䢽")+l1l1ll1lll1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䢾"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䢿"),l1l1l1l11ll1_l1_,168,l1l111_l1_ (u"ࠫࠬ䣀"),l1l111_l1_ (u"ࠬ࠭䣁"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䣂")+l1l1ll1lll1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䣃"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䣄"),l1l111_l1_ (u"ࠩࠪ䣅"),9999)
	import M3U
	for l1l1ll11ll11_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䣆") in l1l1ll1lll1l_l1_: M3U.GROUPS(str(l1l1ll11ll11_l1_),l1l1l1l11ll1_l1_,l1l1ll1lll1l_l1_,l1l111_l1_ (u"ࠫࠬ䣇"),False)
		else: M3U.ITEMS(str(l1l1ll11ll11_l1_),l1l1l1l11ll1_l1_,l1l1ll1lll1l_l1_,l1l111_l1_ (u"ࠬ࠭䣈"),False)
	menuItemsLIST[:] = l1l1ll111l1l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1ll1llll1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1ll1llll1_l1_)
	return
def l1l1ll111l1l_l1_(menuItemsLIST):
	l1l1l1llll11_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"࠭ีโฯฬࠫ䣉") in name or l1l111_l1_ (u"ࠧึใะ๋ࠬ䣊") in name or l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭䣋") in name.lower(): continue
		l1l1l1llll11_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1l1_l1_])
	return l1l1l1llll11_l1_
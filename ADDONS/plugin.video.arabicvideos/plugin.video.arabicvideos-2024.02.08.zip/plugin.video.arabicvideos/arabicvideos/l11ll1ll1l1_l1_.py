# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ嵁")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ嵂")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l111lllll1l1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l111lllll111_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l11l111ll1l1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l11l1111l1ll_l1_()
	elif mode==148: l1lll_l1_ = l11l1111ll1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嵃"),l1lllll_l1_+l1l111_l1_ (u"࠭โศศ่อࠬ嵄"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࡒࡏࡅ࡯࠻ࡇࡴ࠺ࡉࡌ࠽ࡠ࡮ࡖࡤࡉ࠴ࡗ࡜࠭࠸ࡉ࠶ࡆࡴࡷࡉࡺ࡜ࡄ࠸ࡺ࡙ࡁࠨ嵅"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嵆"),l1lllll_l1_+l1l111_l1_ (u"ࠩืาฺ࠭嵇"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࡗࡇࡓࡵࡦࡧ࡫ࡦ࡭ࡦࡲࠧ嵈"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵉"),l1lllll_l1_+l1l111_l1_ (u"๋่ࠬใ฻ࠪ嵊"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࡗࡆࡵ࠺࠿ࡡࡈࡐࡶࡵ࠾ࡨࡢࡩࡹ࡙ࡘࡶ࠷ࡕࡵࡸࡪࡻࠬ嵋"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵌"),l1lllll_l1_+l1l111_l1_ (u"ࠨฯึหอ࠭嵍"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡄ࡙࡮ࡥࡔࡱࡦ࡭ࡦࡲࡃࡕࡘࠪ嵎"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵏"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬู๊ศสࠪ嵐"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭嵑"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嵒"),l1lllll_l1_+l1l111_l1_ (u"ࠧศใ็ห๊࠭嵓"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡴࡶࡲࡶࡪ࡬ࡲࡰࡰࡷࠫ嵔"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嵕"),l1lllll_l1_+l1l111_l1_ (u"้ࠪำะวาษอࠫ嵖"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ嵗"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嵘"),l1lllll_l1_+l1l111_l1_ (u"࠭โึ์ิอࠬ嵙"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ嵚"),144,l1l111_l1_ (u"ࠨࠩ嵛"),l1l111_l1_ (u"ࠩࠪ嵜"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嵝"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵞"),l1lllll_l1_+l1l111_l1_ (u"ࠬะีโฯࠪ嵟"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ嵠"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵡"),l1lllll_l1_+l1l111_l1_ (u"ࠨำษ๎ุ๐ษࠨ嵢"),l111l1_l1_+l1l111_l1_ (u"ࠩࠪ嵣"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵤"),l1lllll_l1_+l1l111_l1_ (u"ࠫึอฦอࠩ嵥"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡅࡢࡱ࠿ࠪ嵦"),144)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嵧"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嵨"),l1l111_l1_ (u"ࠨࠩ嵩"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嵪"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ嵫"),l1l111_l1_ (u"ࠫࠬ嵬"),149,l1l111_l1_ (u"ࠬ࠭嵭"),l1l111_l1_ (u"࠭ࠧ嵮"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ嵯"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭嵰"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嵱"),l1l111_l1_ (u"ࠪࠫ嵲"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵳"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ嵴"),l111l1_l1_+l1l111_l1_ (u"࠭ࠧ嵵"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵶"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ีฬฬฬสࠩ嵷"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ嵸"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵹"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊สึใะࠫ嵺"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ嵻"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嵼"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆๅู๏ืษࠨ嵽"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ嵾"),144,l1l111_l1_ (u"ࠩࠪ嵿"),l1l111_l1_ (u"ࠪࠫ嶀"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ嶁"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嶂"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅฯฬสีฬะ๋๊ࠠอ๎ํฮࠧ嶃"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭嶄"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嶅"),l1lllll_l1_+l1l111_l1_ (u"่ࠩาฯอัศฬࠣห้ฮั็ษ่ะࠬ嶆"),l1l111_l1_ (u"ࠪࠫ嶇"),290)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ嶈"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嶉"),l1l111_l1_ (u"࠭ࠧ嶊"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶋"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥ฿ัษ์ฬࠫ嶌"),l1l111_l1_ (u"ࠩࠪ嶍"),147)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶎"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ嶏"),l1l111_l1_ (u"ࠬ࠭嶐"),148)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶑"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ嶒"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ嶓"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶔"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬ๋ࠠศฮ้ฬ๏ฯࠧ嶕"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡳ࡯ࡷ࡫ࡨࠫ嶖"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嶗"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ嶘"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ嶙"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嶚"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ嶛"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ嶜"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嶝"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ嶞"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ嶟"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶠"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠไษิฮํ์ࠧ嶡"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀ็ฬืส้่ࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ嶢"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶣"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ嶤"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ嶥"),144)
	return
def l111lllll111_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶦"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡄࡊࡑࡐ࠿ࠦࠠࠨ嶧")+name,url,144,l11l_l1_)
	return
def l11l1111l1ll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ嶨"))
	return
def l11l1111ll1l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ嶩"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠪࠪࠬ嶪"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l11111l11_l1_(yccc,url,index):
	level,l111llllll1l_l1_,index2,l111llllllll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶫"))
	l111llll1ll1_l1_,l11l11111l1l_l1_ = [],[]
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ嶬") in url: l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࠧ嶭"))
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭嶮") in url: l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡈࡵ࡭࡮ࡣࡱࡨࡸ࠭࡝ࠣ嶯"))
	if level==l1l111_l1_ (u"ࠩ࠴ࠫ嶰"): l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嶱"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ嶲"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝ࠣ嶳"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬ࡫࡮ࡵࡴ࡬ࡩࡸ࠭࡝ࠣ嶴"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡩࡵࡧࡰࡷࠬࡣ࡛࠴࡟࡞ࠫ࡬ࡻࡩࡥࡧࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ嶵"))
	l11l111l1111_l1_,yddd,l11l111111ll_l1_ = l111llll1l11_l1_(yccc,l1l111_l1_ (u"ࠨࠩ嶶"),l111llll1ll1_l1_)
	if level==l1l111_l1_ (u"ࠩ࠴ࠫ嶷") and l11l111l1111_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ嶸") not in url:
			for zz in range(len(yddd)):
				l111llllll1l_l1_ = str(zz)
				l111llll1ll1_l1_ = []
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ嶹")+l111llllll1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ嶺"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ嶻")+l111llllll1l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࠫࡢࠨ嶼"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ嶽")+l111llllll1l_l1_+l1l111_l1_ (u"ࠤࡠࠦ嶾"))
				succeeded,item,l1111ll1_l1_ = l111llll1l11_l1_(yddd,l1l111_l1_ (u"ࠪࠫ嶿"),l111llll1ll1_l1_)
				if succeeded: l11l11111l1l_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠷ࡀ࠺ࠨ巀")+l111llllll1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ巁")])
			l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣࠢ巂"))
			succeeded,item,l1111ll1_l1_ = l111llll1l11_l1_(yccc,l1l111_l1_ (u"ࠧࠨ巃"),l111llll1ll1_l1_)
			if succeeded and l11l11111l1l_l1_ and l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ巄") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ巅")
				l11l11111l1l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ巆")])
	return yddd,l11l111l1111_l1_,l11l11111l1l_l1_,l11l111111ll_l1_
def l111llll111l_l1_(yccc,yddd,url,index):
	level,l111llllll1l_l1_,index2,l111llllllll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ巇"))
	l111llll1ll1_l1_,l11l11111ll1_l1_ = [],[]
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ巈"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ巉")+l111llllll1l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ巊"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ巋"))
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ巌") in url: l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ巍"))
	elif l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ巎") in url: l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ巏"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ巐")+l111llllll1l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ巑"))
	if l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ巒") in url or (l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ巓") in url and l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ巔") not in url):
		l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ巕")+l111llllll1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ巖"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ巗")+l111llllll1l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ巘"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ巙")+l111llllll1l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡦࡨ࡬ࡦࡖࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ巚"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ巛")+l111llllll1l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ巜"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ川")+l111llllll1l_l1_+l1l111_l1_ (u"ࠨ࡝ࠣ州"))
	l11l1111lll1_l1_,yeee,l11l111111l1_l1_ = l111llll1l11_l1_(yddd,l1l111_l1_ (u"ࠧࠨ巟"),l111llll1ll1_l1_)
	if level==l1l111_l1_ (u"ࠨ࠴ࠪ巠") and l11l1111lll1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l111llll1ll1_l1_ = []
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ巡")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ巢"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ巣")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ巤"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ工")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ左"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ巧")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ巨"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ巩")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ巪"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ巫")+index2+l1l111_l1_ (u"ࠨ࡝ࠣ巬"))
				succeeded,item,l1111ll1_l1_ = l111llll1l11_l1_(yeee,l1l111_l1_ (u"ࠧࠨ巭"),l111llll1ll1_l1_)
				if succeeded: l11l11111ll1_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠵࠽࠾ࠬ差")+l111llllll1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ巯")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠶ࠧ巰")])
			l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠵ࡢࠨ己"))
			l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠵ࡢࠨ已"))
			succeeded,item,l1111ll1_l1_ = l111llll1l11_l1_(yddd,l1l111_l1_ (u"࠭ࠧ巳"),l111llll1ll1_l1_)
			if succeeded and l11l11111ll1_l1_ and l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ巴") in list(item.keys()):
				l11l11111ll1_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ巵")])
	return yeee,l11l1111lll1_l1_,l11l11111ll1_l1_,l11l111111l1_l1_
def l111lllll11l_l1_(yccc,yeee,url,index):
	level,l111llllll1l_l1_,index2,l111llllllll_l1_ = index.split(l1l111_l1_ (u"ࠩ࠽࠾ࠬ巶"))
	l111llll1ll1_l1_,l111lllll1ll_l1_ = [],[]
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ巷")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡷࡧࡵࡸ࡮ࡩࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ巸"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ巹")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ巺"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ巻")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡳࡧࡨࡰࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ巼"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ巽")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ巾"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ巿")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ帀"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ币")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ市"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ布")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ帄"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ帅")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ帆"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ帇"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ师"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ帉"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ帊")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡥࡦ࡮ࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ帋"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ希")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ帍"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧࠥ帎"))
	l11l111l11l1_l1_,yfff,l11l111lll11_l1_ = l111llll1l11_l1_(yeee,l1l111_l1_ (u"࠭ࠧ帏"),l111llll1ll1_l1_)
	if level==l1l111_l1_ (u"ࠧ࠴ࠩ帐") and l11l111l11l1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l111llllllll_l1_ = str(zz)
				l111llll1ll1_l1_ = []
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡩࡪ࡫ࡡࠢ帑")+l111llllllll_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ帒"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽ࡫࡬ࡦ࡜ࠤ帓")+l111llllllll_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ帔"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡦࡧࡨ࡞ࠦ帕")+l111llllllll_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ帖"))
				l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡨࡩࡪࡠࠨ帗")+l111llllllll_l1_+l1l111_l1_ (u"ࠣ࡟ࠥ帘"))
				succeeded,item,l1111ll1_l1_ = l111llll1l11_l1_(yfff,l1l111_l1_ (u"ࠩࠪ帙"),l111llll1ll1_l1_)
				if succeeded: l111lllll1ll_l1_.append([item,url,l1l111_l1_ (u"ࠪ࠸࠿ࡀࠧ帚")+l111llllll1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帛")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ帜")+l111llllllll_l1_])
	return yfff,l11l111l11l1_l1_,l111lllll1ll_l1_,l11l111lll11_l1_
def l111llll1l11_l1_(l1l1llll111l_l1_,l1l1lllll111_l1_,l111llllll11_l1_):
	yccc,l1l1lllll111_l1_ = l1l1llll111l_l1_,l1l1lllll111_l1_
	yddd,l1l1lllll111_l1_ = l1l1llll111l_l1_,l1l1lllll111_l1_
	yeee,l1l1lllll111_l1_ = l1l1llll111l_l1_,l1l1lllll111_l1_
	yfff,l1l1lllll111_l1_ = l1l1llll111l_l1_,l1l1lllll111_l1_
	item,yrender = l1l1llll111l_l1_,l1l1lllll111_l1_
	count = len(l111llllll11_l1_)
	for l1l111lll1_l1_ in range(count):
		try:
			out = eval(l111llllll11_l1_[l1l111lll1_l1_])
			return True,out,l1l111lll1_l1_+1
		except: pass
	return False,l1l111_l1_ (u"࠭ࠧ帝"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠧࠨ帞"),data=l1l111_l1_ (u"ࠨࠩ帟")):
	l11l11111l1l_l1_,l11l11111ll1_l1_,l111lllll1ll_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠩ࠽࠾ࠬ帠") not in index: index = l1l111_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ帡")
	level,l111llllll1l_l1_,index2,l111llllllll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ帢"))
	if level==l1l111_l1_ (u"ࠬ࠺ࠧ帣"): level,l111llllll1l_l1_,index2,l111llllllll_l1_ = l1l111_l1_ (u"࠭࠱ࠨ帤"),l111llllll1l_l1_,index2,l111llllllll_l1_
	data = data.replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ帥"),l1l111_l1_ (u"ࠨࠩ带"))
	html,yccc,l1l11llll_l1_ = l11l11111lll_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠩ࠽࠾ࠬ帧")+l111llllll1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭帨")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帩")+l111llllllll_l1_
	if level in [l1l111_l1_ (u"ࠬ࠷ࠧ帪"),l1l111_l1_ (u"࠭࠲ࠨ師"),l1l111_l1_ (u"ࠧ࠴ࠩ帬")]:
		yddd,l11l111l1111_l1_,l11l11111l1l_l1_,l11l111111ll_l1_ = l11l11111l11_l1_(yccc,url,index)
		if not l11l111l1111_l1_: return
		l1llll1l1l_l1_ = len(l11l11111l1l_l1_)
		if l1llll1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠨ࠳ࠪ席"): level = l1l111_l1_ (u"ࠩ࠵ࠫ帮")
			l11l11111l1l_l1_ = []
	index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭帯")+l111llllll1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帰")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ帱")+l111llllllll_l1_
	if level in [l1l111_l1_ (u"࠭࠲ࠨ帲"),l1l111_l1_ (u"ࠧ࠴ࠩ帳")]:
		yeee,l11l1111lll1_l1_,l11l11111ll1_l1_,l11l111111l1_l1_ = l111llll111l_l1_(yccc,yddd,url,index)
		if not l11l1111lll1_l1_: return
		l1ll1l111l_l1_ = len(l11l11111ll1_l1_)
		if l1ll1l111l_l1_<2:
			if level==l1l111_l1_ (u"ࠨ࠴ࠪ帴"): level = l1l111_l1_ (u"ࠩ࠶ࠫ帵")
			l11l11111ll1_l1_ = []
	index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭帶")+l111llllll1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帷")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ常")+l111llllllll_l1_
	if level in [l1l111_l1_ (u"࠭࠳ࠨ帹")]:
		yfff,l11l111l11l1_l1_,l111lllll1ll_l1_,l11l111lll11_l1_ = l111lllll11l_l1_(yccc,yeee,url,index)
		if not l11l111l11l1_l1_: return
		l1ll1l11l1_l1_ = len(l111lllll1ll_l1_)
	for item,url,index in l11l11111l1l_l1_+l11l11111ll1_l1_+l111lllll1ll_l1_:
		l1ll1ll11ll1_l1_ = l111llll1lll_l1_(item,url,index)
	return
def l111llll1lll_l1_(item,url=l1l111_l1_ (u"ࠧࠨ帺"),index=l1l111_l1_ (u"ࠨࠩ帻")):
	if l1l111_l1_ (u"ࠩ࠽࠾ࠬ帼") in index: level,l111llllll1l_l1_,index2,l111llllllll_l1_ = index.split(l1l111_l1_ (u"ࠪ࠾࠿࠭帽"))
	else: level,l111llllll1l_l1_,index2,l111llllllll_l1_ = l1l111_l1_ (u"ࠫ࠶࠭帾"),l1l111_l1_ (u"ࠬ࠶ࠧ帿"),l1l111_l1_ (u"࠭࠰ࠨ幀"),l1l111_l1_ (u"ࠧ࠱ࠩ幁")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_,l11l111ll11l_l1_ = l11l111llll1_l1_(item)
	l1lllll1l111_l1_ = l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࡁࠪ幂") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡷࡹࡸࡥࡢ࡯ࡶࡃࠬ幃") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹ࠿ࠨ幄") in l1ll1ll_l1_
	l1lllll11ll1_l1_ = l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹ࠿ࠨ幅") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸࡅࠧ幆") in l1ll1ll_l1_
	if l1lllll1l111_l1_ or l1lllll11ll1_l1_: l1ll1ll_l1_ = url
	l1lllll1l111_l1_ = l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ幇") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ幈") not in l1ll1ll_l1_
	l1lllll11ll1_l1_ = l1l111_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ幉") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ幊") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼ࠪ幋") and l1lllll1l111_l1_ and l1lllll11ll1_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ幌") in url or l1l111_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭幍") in l1ll1ll_l1_:
		level,l111llllll1l_l1_,index2,l111llllllll_l1_ = l1l111_l1_ (u"࠭࠱ࠨ幎"),l1l111_l1_ (u"ࠧ࠱ࠩ幏"),l1l111_l1_ (u"ࠨ࠲ࠪ幐"),l1l111_l1_ (u"ࠩ࠳ࠫ幑")
		index = l1l111_l1_ (u"ࠪࠫ幒")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠫࠬ幓")
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ幔") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ幕") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ幖") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ幗"))
		if data.count(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭幘"))==4:
			l11l111l111l_l1_,key,l11l1111ll11_l1_,l11l1111l11l_l1_,token = data.split(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ幙"))
			l1l11llll_l1_ = l11l111l111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ幚")+key+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ幛")+l11l1111ll11_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ幜")+l11l1111l11l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ幝")+l11l111ll11l_l1_
			if l1l111_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭幞") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ幟")+key
	if not title:
		global l111lllll1l1_l1_
		l111lllll1l1_l1_ += 1
		title = l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠭幠")+str(l111lllll1l1_l1_)
		index = l1l111_l1_ (u"ࠫ࠸࠭幡")+l1l111_l1_ (u"ࠬࡀ࠺ࠨ幢")+l111llllll1l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ幣")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ幤")+l111llllllll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡑࡻࡹࡖࡪࡴࡤࡦࡴࡨࡶࠬ幥") in str(item): return False
	elif l1l111_l1_ (u"ࠩ࠲ࡥࡧࡵࡵࡵࠩ幦") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡭࡮ࡷࡱ࡭ࡹࡿࠧ幧") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ幨") in list(item.keys()) or l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ幩") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ幪")+l111llllll1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ幫")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ幬")+l111llllllll_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ幭"),l1lllll_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ幮")+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ幯"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭幰") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"࠭࠺࠻ࠢࠪ幱")+title
		index = l1l111_l1_ (u"ࠧ࠴ࠩ干")+l1l111_l1_ (u"ࠨ࠼࠽ࠫ平")+l111llllll1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ年")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭幵")+l111llllllll_l1_
		url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ并"),l1l111_l1_ (u"ࠬ࠭幷"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭幸"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠧࠨ幹"),index,l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ幺"))
	elif l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ幻") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠪ࠷ࠬ幼")+l1l111_l1_ (u"ࠫ࠿ࡀࠧ幽")+l111llllll1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ幾")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ广")+l111llllllll_l1_
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ庀")+title
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ庁"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࠪ庂") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ広")+title
		index = l1l111_l1_ (u"ࠫ࠷ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ庄")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ庅"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭庆") in str(item):
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ庇")+title
		index = l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ庈")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ庉"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ床") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ庋"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭庌"),9999)
	elif l11l111l11ll_l1_:
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ庍"),l1lllll_l1_+l11l111l11ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ庎") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ序"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ庐")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ庑")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭庒") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ库"),1)[0]
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ应"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ底") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ庖") in l1ll1ll_l1_ and count:
			l11l1111llll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ店"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ庘")+l11l1111llll_l1_
			index = l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ庙")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ庚"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ庛")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ府")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ庝"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ庞"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭废") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡩ࠯ࠨ庠") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠬ࠵ࡀࠨ庡") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"࠭࠯ࠨ庢"))==3):
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ庣"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡅࡋࡒࡑ࠭庤")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭庥")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࠪ度") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ座"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪ庨")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ庩")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ庪")+title
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ庫"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l11l111llll1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_,token = False,l1l111_l1_ (u"ࠩࠪ庬"),l1l111_l1_ (u"ࠪࠫ庭"),l1l111_l1_ (u"ࠫࠬ庮"),l1l111_l1_ (u"ࠬ࠭庯"),l1l111_l1_ (u"࠭ࠧ庰"),l1l111_l1_ (u"ࠧࠨ庱"),l1l111_l1_ (u"ࠨࠩ庲"),l1l111_l1_ (u"ࠩࠪ庳")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_,token
	for l11l1111l1l1_l1_ in list(item.keys()):
		yrender = item[l11l1111l1l1_l1_]
		if isinstance(yrender,dict): break
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ庴"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡌࡪࡵࡷࡌࡪࡧࡤࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ庵"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡱ࡯࡮ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ庶"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡷࡱࡴࡱࡧࡹࡢࡤ࡯ࡩ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ康"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡩࡳࡷࡳࡡࡵࡶࡨࡨ࡙࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ庸"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ庹"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ庺"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ庻"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ庼"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ庽"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ庾"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ庿"))
	succeeded,title,l1111ll1_l1_ = l111llll1l11_l1_(item,yrender,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ廀"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ廁"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ廂"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ廃"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ廄"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ廅"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ廆"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l111llll1l11_l1_(item,yrender,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ廇"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ廈"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ廉"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l111llll1l11_l1_(item,yrender,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࠪࡡࠧ廊"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࡘࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ廋"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡂࡰࡶࡷࡳࡲࡖࡡ࡯ࡧ࡯ࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ廌"))
	succeeded,count,l1111ll1_l1_ = l111llll1l11_l1_(item,yrender,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ廍"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ廎"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡱ࡫࡮ࡨࡶ࡫ࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ廏"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࠩࡠ࡟ࠬ࡯ࡣࡰࡰࡗࡽࡵ࡫ࠧ࡞ࠤ廐"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡹࡴࡺ࡮ࡨࠫࡢࠨ廑"))
	succeeded,l1l1lll111_l1_,l1111ll1_l1_ = l111llll1l11_l1_(item,yrender,l111llll1ll1_l1_)
	l111llll1ll1_l1_ = []
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ廒"))
	l111llll1ll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ廓"))
	succeeded,token,l1111ll1_l1_ = l111llll1l11_l1_(item,yrender,l111llll1ll1_l1_)
	if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ廔") in l1l1lll111_l1_: l1l1lll111_l1_,l11l111l11ll_l1_ = l1l111_l1_ (u"ࠨࠩ廕"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ廖")
	if l1l111_l1_ (u"้ࠪออิาࠩ廗") in l1l1lll111_l1_: l1l1lll111_l1_,l11l111l11ll_l1_ = l1l111_l1_ (u"ࠫࠬ廘"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭廙")
	if l1l111_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭廚") in list(yrender.keys()):
		l11l111l1lll_l1_ = str(yrender[l1l111_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ廛")])
		if l1l111_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ廜") in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠩࠧ࠾ࠥࠦࠧ廝")
		if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ廞") in l11l111l1lll_l1_: l11l111l11ll_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ廟")
		if l1l111_l1_ (u"ࠬࡈࡵࡺࠩ廠") in l11l111l1lll_l1_ or l1l111_l1_ (u"࠭ࡒࡦࡰࡷࠫ廡") in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭廢")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡶ่ࠩฬฬฺัࠨ廣")) in l11l111l1lll_l1_: l11l111l11ll_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ廤")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡸูࠫืวยࠩ廥")) in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ廦")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡺ࠭วิฬษะฬืࠧ廧")) in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ廨")
		if l111ll1ll1l_l1_(l1l111_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ廩")) in l11l111l1lll_l1_: l11l1111l111_l1_ = l1l111_l1_ (u"ࠨࠦ࠽ࠤࠥ࠭廪")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ廫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠪࡃࠬ廬"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ廭") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ廮")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1111l111_l1_: title = l11l1111l111_l1_+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"࠭ࠬࠨ廯"),l1l111_l1_ (u"ࠧࠨ廰"))
	count = count.replace(l1l111_l1_ (u"ࠨ࠮ࠪ廱"),l1l111_l1_ (u"ࠩࠪ廲"))
	count = re.findall(l1l111_l1_ (u"ࠪࡠࡩ࠱ࠧ廳"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠫࠬ廴")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l111l11ll_l1_,l11l1111l111_l1_,token
def l11l11111lll_l1_(url,data=l1l111_l1_ (u"ࠬ࠭廵"),request=l1l111_l1_ (u"࠭ࠧ延")):
	if request==l1l111_l1_ (u"ࠧࠨ廷"): request = l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ廸")
	l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭廹"):l11ll1l1l1_l1_,l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ建"):l1l111_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ廻")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ廼"))
	if data.count(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ廽"))==4: l11l111l111l_l1_,key,l11l1111ll11_l1_,l11l1111l11l_l1_,token = data.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ廾"))
	else: l11l111l111l_l1_,key,l11l1111ll11_l1_,l11l1111l11l_l1_,token = l1l111_l1_ (u"ࠨࠩ廿"),l1l111_l1_ (u"ࠩࠪ开"),l1l111_l1_ (u"ࠪࠫ弁"),l1l111_l1_ (u"ࠫࠬ异"),l1l111_l1_ (u"ࠬ࠭弃")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ弄"):{l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ弅"):{l1l111_l1_ (u"ࠣࡪ࡯ࠦ弆"):l1l111_l1_ (u"ࠤࡤࡶࠧ弇"),l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ弈"):l1l111_l1_ (u"ࠦ࡜ࡋࡂࠣ弉"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ弊"):l11l1111ll11_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ弋") or l1l111_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ弌") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ弍")+l1l111_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ弎")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ式")] = l11l111l111l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ弐"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ弑"))
	elif l1l111_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ弒") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ弓")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭弔"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ引"))
	elif l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ弖") in url and l11l111l111l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ弗")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭弘")][l1l111_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭弙")][l1l111_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ弚")] = l11l111l111l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭弛"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ弜"))
	elif l1l111_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ弝") in url and l11l1111l11l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ弞"):l1l111_l1_ (u"ࠬ࠷ࠧ弟"),l1l111_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ张"):l11l1111ll11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ弡"):l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ弢")+l11l1111l11l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭弣"),url,l1l111_l1_ (u"ࠪࠫ弤"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ弥"),l1l111_l1_ (u"ࠬ࠭弦"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ弧"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ弨"),url,l1l111_l1_ (u"ࠨࠩ弩"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ弪"),l1l111_l1_ (u"ࠪࠫ弫"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ弬"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ弭"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ弮"),html,re.DOTALL|re.I)
	if tmp: l11l1111ll11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ弯"),html,re.DOTALL|re.I)
	if tmp: l11l111l111l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭弰") in list(cookies.keys()): l11l1111l11l_l1_ = cookies[l1l111_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ弱")]
	l1l1l1111_l1_ = l11l111l111l_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ弲")+key+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ弳")+l11l1111ll11_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ弴")+l11l1111l11l_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ張")+token
	if request==l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ弶") and l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ強") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ弸"),html,re.DOTALL)
		if not l11ll11l1l_l1_: l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ弹"),html,re.DOTALL)
		l11l111l1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ强"),l11ll11l1l_l1_[0])
	elif request==l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ弻") and l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ弼") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭弽"),html,re.DOTALL)
		l11l111l1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ弾"),l11ll11l1l_l1_[0])
	elif l1l111_l1_ (u"ࠩ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ弿") not in html: l11l111l1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ彀"),html)
	else: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠫࠬ彁")
	if 0:
		yccc = str(l11l111l1ll1_l1_)
		if PY3: yccc = yccc.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ彂"))
		open(l1l111_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳ࡪࡡࡵࠩ彃"),l1l111_l1_ (u"ࠧࡸࡤࠪ彄")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ彅"),l1l1l1111_l1_)
	return html,l11l111l1ll1_l1_,l1l1l1111_l1_
def l11l111ll1l1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ彆"),l1l111_l1_ (u"ࠪ࠯ࠬ彇"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ彈")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ彉"),l1l111_l1_ (u"࠭ࠫࠨ彊"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ彋")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ彌") in options: l11l1111111l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ彍")
		elif l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ彎") in options: l11l1111111l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ彏")
		elif l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ彐") in options: l11l1111111l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭彑")
		else: l11l1111111l_l1_ = l1l111_l1_ (u"ࠧࠨ归")
		l1llllll_l1_ = l1lllll1_l1_+l11l1111111l_l1_
	else:
		l11l11111111_l1_,l111llll11ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠨࠩ当")
		l111llll1l1l_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭彔"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ录"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ彖"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ彗"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ彘")]
		l11l111l1l1l_l1_ = [l1l111_l1_ (u"ࠧࠨ彙"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ彚"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ彛"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ彜"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ彝")]
		l11l111ll111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ彞"),l111llll1l1l_l1_)
		if l11l111ll111_l1_ == -1: return
		l111lllllll1_l1_ = l11l111l1l1l_l1_[l11l111ll111_l1_]
		html,c,data = l11l11111lll_l1_(l1lllll1_l1_+l111lllllll1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ彟")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彠")][l1l111_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ彡")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ形")][l1l111_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ彣")][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ彤")][l1l111_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ彥")]
				for l111llll11l1_l1_ in range(len(d)):
					group = d[l111llll11l1_l1_][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ彦")][l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ彧")]
					for l11l111ll1ll_l1_ in range(len(group)):
						yrender = group[l11l111ll1ll_l1_][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彨")]
						if l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ彩") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ彪")][l1l111_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭彫")][l1l111_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ彬")][l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ彭")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ彮"),l1l111_l1_ (u"ࠨࠨࠪ彯"))
							title = yrender[l1l111_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ彰")]
							title = title.replace(l1l111_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭影"),l1l111_l1_ (u"ࠫࠬ彲"))
							if l1l111_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ彳") in title: continue
							if l1l111_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ彴") in title:
								title = l1l111_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ彵")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ彶") in title: continue
							title = title.replace(l1l111_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ彷"),l1l111_l1_ (u"ࠪࠫ彸"))
							if l1l111_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ役") in title: continue
							if l1l111_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ彺") in title:
								title = l1l111_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ彻")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ彼") in title: continue
							l11l11111111_l1_.append(escapeUNICODE(title))
							l111llll11ll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l11l111l1l11_l1_ = l1l111_l1_ (u"ࠨࠩ彽")
		else:
			l11l11111111_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ彾"),l1lllllll_l1_]+l11l11111111_l1_
			l111llll11ll_l1_ = [l1l111_l1_ (u"ࠪࠫ彿"),l111lllll_l1_]+l111llll11ll_l1_
			l11l111lll1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ往"),l11l11111111_l1_)
			if l11l111lll1l_l1_ == -1: return
			l11l111l1l11_l1_ = l111llll11ll_l1_[l11l111lll1l_l1_]
		if l11l111l1l11_l1_: l1llllll_l1_ = l111l1_l1_+l11l111l1l11_l1_
		elif l111lllllll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111lllllll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ∿")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡋࡂ࠴ࡡࠪ≀")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭≁"),l1l111_l1_ (u"࠭ว๋ฮํࠤอูสࠨ≂"),l1l111_l1_ (u"ࠧศๆอู๊๐ๅࠡษ็ะิ๐ฯࠨ≃"),l1l111_l1_ (u"ࠨ฻ิ์฻ࠦวๅ็ุหึ฿ษࠨ≄"),l1l111_l1_ (u"่ࠩ็ฯฮส๋ࠩ≅"),l1l111_l1_ (u"ࠪห๏า๊ࠡสึฮࠥอไอัํำࠬ≆"),l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯࠦวๅสา๎้࠭≇"),l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭≈"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢหืฯ࠭≉"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ์สโๆํ็ุ࠭≊")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==790: l1lll_l1_ = l1l1l11_l1_()
	elif mode==791: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==792: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==793: l1lll_l1_ = PLAY(url)
	elif mode==796: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==799: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ≋"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ≌"),l1l111_l1_ (u"ࠪࠫ≍"),l1l111_l1_ (u"ࠫࠬ≎"),l1l111_l1_ (u"ࠬ࠭≏"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ≐"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸ࠲ࡶࡡࡨࡧࡶࠬ࠳࠰࠿ࠪࡨࡤ࠱࡫ࡵ࡬ࡥࡧࡵࠫ≑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ≒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ≓"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ≔") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≕"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ≖")+l1lllll_l1_+title,l1ll1ll_l1_,791)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ≗"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ≘"),l1l111_l1_ (u"ࠨࠩ≙"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࡹ࡯ࡤ࡫ࡤࡰ࠲ࡨ࡯ࡹࠩ≚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ≛"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭≜"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ≝") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭≞"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ≟")+l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠨࠩ≠"),l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࡭ࡦࡰࡸࠫ≡"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ≢"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭≣"),l1l111_l1_ (u"ࠬ࠭≤"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ≥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭≦"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ≧"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ≨") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ≩"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭≪")+l1lllll_l1_+title,l1ll1ll_l1_,791)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠬ࠭≫")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ≬"),url,l1l111_l1_ (u"ࠧࠨ≭"),l1l111_l1_ (u"ࠨࠩ≮"),l1l111_l1_ (u"ࠩࠪ≯"),l1l111_l1_ (u"ࠪࠫ≰"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭≱"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ≲"),html,re.DOTALL)
	if l11llll_l1_:
		l111llll1l_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"࠭ࠧ≳"),l1l111_l1_ (u"ࠧࠨ≴"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠨฯ็ๆฬะࠧ≵") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"่ࠩ์ฬูๅࠨ≶") in name: l111llll1l_l1_ = block
		if l111llll1l_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ≷"),l111llll1l_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≸"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ≹"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ≺"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭≻"),l1lllll_l1_+title,l1ll1ll_l1_,793,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ≼"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ≽"),l1lllll_l1_+title,l1ll1ll_l1_,793)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠪࠫ≾")):
	limit,start,l1l1l1ll1_l1_,select,l111ll1111_l1_ = 0,0,l1l111_l1_ (u"ࠫࠬ≿"),l1l111_l1_ (u"ࠬ࠭⊀"),l1l111_l1_ (u"࠭ࠧ⊁")
	if l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ⊂") in type:
		l111ll11ll_l1_,data = l1ll11ll1_l1_(url)
		limit = int(data[l1l111_l1_ (u"ࠨ࡮࡬ࡱ࡮ࡺࠧ⊃")])
		start = int(data[l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ⊄")])
		l1l1l1ll1_l1_ = data[l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ⊅")]
		select = data[l1l111_l1_ (u"ࠫࡸ࡫࡬ࡦࡥࡷࠫ⊆")]
		l1l11llll_l1_ = l1l111_l1_ (u"ࠬࡲࡩ࡮࡫ࡷࡁࠬ⊇")+str(limit)+l1l111_l1_ (u"࠭ࠦࡴࡶࡤࡶࡹࡃࠧ⊈")+str(start)+l1l111_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧ⊉")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡱ࡫ࡣࡵ࠿ࠪ⊊")+select
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⊋"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⊌")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ⊍"),l111ll11ll_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭⊎"),l1l111_l1_ (u"࠭ࠧ⊏"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⊐"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠨ⊑")+html+l1l111_l1_ (u"ࠩࡤࡶࡹ࡯ࡣ࡭ࡧࠪ⊒")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⊓"),url,l1l111_l1_ (u"ࠫࠬ⊔"),l1l111_l1_ (u"ࠬ࠭⊕"),l1l111_l1_ (u"࠭ࠧ⊖"),l1l111_l1_ (u"ࠧࠨ⊗"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⊘"))
		html = response.content
		l11l1ll1_l1_ = html
		code = re.findall(l1l111_l1_ (u"ࠤ࠿ࡷࡨࡸࡩࡱࡶࡁࠬࡻࡧࡲ࠯ࠬࡂࡁ࠳࠰࠿࠼ࡸࡤࡶ࠳࠰࠿࠾࠰࠭ࡃࡀࡼࡡࡳ࠰࠭ࡃࡂ࠴ࠪࡀ࠽ࡹࡥࡷ࠴ࠪࡀ࠿࠱࠮ࡄࡁࡶࡢࡴ࠱࠮ࡄࡃ࠮ࠫࡁࠬ࠿ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠢ⊙"),html,re.DOTALL)
		if code:
			code = code[0].replace(l1l111_l1_ (u"ࠪࡺࡦࡸࠧ⊚"),l1l111_l1_ (u"ࠫࠬ⊛")).replace(l1l111_l1_ (u"ࠬࠦࠧ⊜"),l1l111_l1_ (u"࠭ࠧ⊝")).replace(l1l111_l1_ (u"ࠢࠨࠤ⊞"),l1l111_l1_ (u"ࠨࠩ⊟")).replace(l1l111_l1_ (u"ࠩ࠾ࠫ⊠"),l1l111_l1_ (u"ࠪࠪࠬ⊡"))
			dummy,data = l1ll11ll1_l1_(l1l111_l1_ (u"ࠫࡄ࠭⊢")+code)
			limit = int(data[l1l111_l1_ (u"ࠬࡲࡩ࡮࡫ࡷࠫ⊣")])
			start = int(data[l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ⊤")])
			l1l1l1ll1_l1_ = data[l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬ⊥")]
			select = data[l1l111_l1_ (u"ࠨࡵࡨࡰࡪࡩࡴࠨ⊦")]
			l111ll1111_l1_ = data[l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾࡵࡳ࡮ࠪ⊧")]
			l1l11llll_l1_ = l1l111_l1_ (u"ࠪࡰ࡮ࡳࡩࡵ࠿ࠪ⊨")+str(limit)+l1l111_l1_ (u"ࠫࠫࡹࡴࡢࡴࡷࡁࠬ⊩")+str(start)+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ⊪")+l1l1l1ll1_l1_+l1l111_l1_ (u"࠭ࠦࡴࡧ࡯ࡩࡨࡺ࠽ࠨ⊫")+select
			l111ll11ll_l1_ = l111l1_l1_+l111ll1111_l1_
			l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⊬"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ⊭")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⊮"),l111ll11ll_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ⊯"),l1l111_l1_ (u"ࠫࠬ⊰"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭ࡕࡋࡗࡐࡊ࡙࠭࠴ࡴࡧࠫ⊱"))
			l11l1ll1_l1_ = response.content
			l11l1ll1_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡸ࠭⊲")+l11l1ll1_l1_+l1l111_l1_ (u"ࠧࡢࡴࡷ࡭ࡨࡲࡥࠨ⊳")
	items,l111lllll1_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⊴"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⊵"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⊶"))
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊷"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠬ࠭⊸"),l1l111_l1_ (u"࠭ࡳࡶࡤࡰࡩࡳࡻࠧ⊹"))
				l111lllll1_l1_ = True
	if not type:
		filters = l111ll111l_l1_(html)
	if not l111lllll1_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡦࡸࡴࡪࡥ࡯ࡩࠬ⊺"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⊻"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ⊼"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ⊽") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊾"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1ll1l_l1_)
				elif l1l111_l1_ (u"๋ࠬำๅี็ࠫ⊿") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ⋀") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋁"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠨ็๋ื๊࠭⋂") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧ⋃") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋄"),l1lllll_l1_+title,l1ll1ll_l1_,796,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⋅"),l1lllll_l1_+title,l1ll1ll_l1_,793,l1ll1l_l1_)
		length = 12
		data = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࠮࡬ࡰࡣࡧ࠱ࡲࡵࡲࡦ࠰࠭ࡃ࠮ࡂࠧ⋆"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ⋇") in type):
			l1l11llll_l1_ = l1l111_l1_ (u"ࠧ࡭࡫ࡰ࡭ࡹࡃࠧ⋈")+str(length)+l1l111_l1_ (u"ࠨࠨࡶࡸࡦࡸࡴ࠾ࠩ⋉")+str(start+length)+l1l111_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࠩ⋊")+l1l1l1ll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡫࡬ࡦࡥࡷࡁࠬ⋋")+select
			l1lllll1_l1_ = l111ll11ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡥࡹࡶࡀࡴࡦ࡭ࡥࠧࠩ⋌")+l1l11llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⋍"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ี๎ิ࠭⋎"),l1lllll1_l1_,791,l1l111_l1_ (u"ࠧࠨ⋏"),l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࡤ࠭⋐")+type)
	return
def l111ll111l_l1_(html):
	filters = False
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭⋑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⋒"),block,re.DOTALL)
		if l1lll1l1_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⋓"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⋔"),l1l111_l1_ (u"࠭ࠧ⋕"),9999)
		for category,name,block in l1lll1l1_l1_:
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ⋖"))
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⋗"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭⋘")+value
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋙"),l1lllll_l1_+title,l1ll1ll_l1_,791,l1l111_l1_ (u"ࠫࠬ⋚"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⋛"))
				filters = True
	return filters
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⋜"),url,l1l111_l1_ (u"ࠧࠨ⋝"),l1l111_l1_ (u"ࠨࠩ⋞"),l1l111_l1_ (u"ࠩࠪ⋟"),l1l111_l1_ (u"ࠪࠫ⋠"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⋡"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶ࠲࡯ࡴࡦ࡯࠱࠮ࡄࡪࡡࡵࡣ࠰ࡧࡴࡪࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⋢"),html,re.DOTALL)
	for l111ll1l1l_l1_ in items:
		l111ll1lll_l1_ = base64.b64decode(l111ll1l1l_l1_)
		if PY3: l111ll1lll_l1_ = l111ll1lll_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⋣"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋤"),l111ll1lll_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭⋥"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⋦")+server+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⋧"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨ⋨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡳࠢࡩࡰࡪࡾ࠭ࡴࡶࡤࡶࡹࠨ࠮ࠫࡁ࠿ࡨ࡮ࡼ࠾࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࠬࡡࡪࡻ࠴࠮࠷ࢁ࠮ࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⋩"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				if l1l111_l1_ (u"࠭࠯ࡀࡷࡵࡰࡂ࠭⋪") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࡁࡸࡶࡱࡃࠧ⋫"))[1]
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭⋬"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⋭")+server+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ⋮")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⋯"),url)
	return
def l1lll1_l1_(text):
	return
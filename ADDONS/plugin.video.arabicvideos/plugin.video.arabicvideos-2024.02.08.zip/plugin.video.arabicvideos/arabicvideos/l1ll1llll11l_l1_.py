# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ孞")
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ孟"):l1l111_l1_ (u"ࠬ࠭孠")}
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬ孡")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ孢"),l1l111_l1_ (u"ࠨࡹࡺࡩࠬ季")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ孤")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ孥")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ学"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ孧"),l111l1_l1_,569,l1l111_l1_ (u"࠭ࠧ孨"),l1l111_l1_ (u"ࠧࠨ孩"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ孪"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ孫"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭孬"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ孭"),564)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孮"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ孯"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ孰"),565)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭孱"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ孲"),l1l111_l1_ (u"ࠪࠫ孳"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ孴"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭孵"),l1l111_l1_ (u"࠭ࠧ孶"),l1l111_l1_ (u"ࠧࠨ孷"),l1l111_l1_ (u"ࠨࠩ學"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ孹"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ孺"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ孻"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠬ࠭孼"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭孽"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ孾")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭孿"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ宀"),l1l111_l1_ (u"ࠪࠫ宁"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭宂"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ它"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宄"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ宅")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ宆"),url,l1l111_l1_ (u"ࠩࠪ宇"),l1l111_l1_ (u"ࠪࠫ守"),l1l111_l1_ (u"ࠫࠬ安"),l1l111_l1_ (u"ࠬ࠭宊"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ宋"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ完") in html:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宍"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ宎"),url,561,l1l111_l1_ (u"ࠪࠫ宏"),l1l111_l1_ (u"ࠫࠬ宐"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ宑"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ宒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ宓"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宔"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1llll1ll111_l1_,type=l1l111_l1_ (u"ࠩࠪ宕")):
	if l1l111_l1_ (u"ࠪ࠾࠿࠭宖") in l1llll1ll111_l1_:
		l1llllll_l1_,url = l1llll1ll111_l1_.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ宗"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ官"))
		url = server+url
	else: url,l1llllll_l1_ = l1llll1ll111_l1_,l1llll1ll111_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ宙"),url,l1l111_l1_ (u"ࠧࠨ定"),l1l111_l1_ (u"ࠨࠩ宛"),l1l111_l1_ (u"ࠩࠪ宜"),l1l111_l1_ (u"ࠪࠫ宝"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ实"))
	html = response.content
	if type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ実"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠪ宠"),html,re.DOTALL)
	elif type in [l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ审"),l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ客")]:
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭宣"),l1l111_l1_ (u"ࠪ࠳ࠬ室")).replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ宥"),l1l111_l1_ (u"ࠬࠨࠧ宦"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡈࡴ࡬ࡨ࠲࠳ࡗࡦࡥ࡬ࡱࡦࡖ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫࠥࡖ࡮࡭ࡨࡵࡗࡌࠦࠬ宧"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡖ࡫ࡹࡲࡨ࠭࠮ࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭宨"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ宩"),l1l111_l1_ (u"ࠩࠪ宪"))
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ宫") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ宬"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠬำไใหࠪ宭") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ宮"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭宯") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宰"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ宱"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ宲"):
			l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ害"),block,re.DOTALL)
			if l111l1lll1_l1_:
				count = l111l1lll1_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ宴")+count
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宵"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ家"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠨࠩ宷"),l1l111_l1_ (u"ࠩࠪ宸"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ容"))
		elif type==l1l111_l1_ (u"ࠫࠬ宺"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭宻"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ宼"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠧึใะอࠥ࠭宽")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宾"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ宿")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ寀"),url,l1l111_l1_ (u"ࠫࠬ寁"),l1l111_l1_ (u"ࠬ࠭寂"),l1l111_l1_ (u"࠭ࠧ寃"),l1l111_l1_ (u"ࠧࠨ寄"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ寅"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ密"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ寇"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寈"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠬ࠭寉"),l1l111_l1_ (u"࠭ࠧ寊"),l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ寋"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࡳ࠿ࠩ富"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠪ寍"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ寎"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ寏"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ寐"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ寑"),l1l111_l1_ (u"ࠧࠨ寒")).replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ寓"),l1l111_l1_ (u"ࠩࠪ寔"))
		else: title = l1l111_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ寕")
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ寖"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ寗"),url,l1l111_l1_ (u"࠭ࠧ寘"),l1l111_l1_ (u"ࠧࠨ寙"),l1l111_l1_ (u"ࠨࠩ寚"),l1l111_l1_ (u"ࠩࠪ寛"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ寜"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ寝"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ寞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ察"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ寠") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠨีํีๆื้ࠠ์ࠣื๏๋วࠨ寡"): name = l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ寢")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ寣")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ寤")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ寥"),l1l111_l1_ (u"࠭ࠧ實")).replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ寧"),l1l111_l1_ (u"ࠨࠩ寨"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ審"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ寪"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ寫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭寬"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ寭")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ寮")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡹࡨࡧ࡮ࡳࡡࠨ寯")+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭寰")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭寱"),l1l111_l1_ (u"ࠫࠬ寲")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ寳"),l1l111_l1_ (u"࠭ࠧ寴"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭寵"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠨࠩ寶")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ寷"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ寸"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭对"),l1l111_l1_ (u"ࠬ࠱ࠧ寺"))
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪ寻")+search
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ导"))
	return
def l1l1ll1l_l1_(l1llll1ll111_l1_,filter):
	if l1l111_l1_ (u"ࠨࡁࡂࠫ寽") in l1llll1ll111_l1_: url = l1llll1ll111_l1_.split(l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ対"))[0]
	else: url = l1llll1ll111_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ寿"),l1l111_l1_ (u"ࠫࠬ尀"))
	type,filter = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ封"),1)
	if filter==l1l111_l1_ (u"࠭ࠧ専"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠧࠨ尃"),l1l111_l1_ (u"ࠨࠩ射")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭尅"))
	if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ将"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠫࡂࡃࠧ將") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ專") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ尉")+category+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ尊")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ尋")+category+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭尌")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭對"))+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ導")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ小"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ尐"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭少")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ尒"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ尓"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠪࠫ尔"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ尕"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠬ࠭尖"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ尗")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1ll111_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ尘"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ尙"),l1111111_l1_,561,l1l111_l1_ (u"ࠩࠪ尚"),l1l111_l1_ (u"ࠪࠫ尛"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ尜"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ尝"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭尞")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭尟"),l1111111_l1_,561,l1l111_l1_ (u"ࠨࠩ尠"),l1l111_l1_ (u"ࠩࠪ尡"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ尢"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ尣"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ尤"),l1l111_l1_ (u"࠭ࠧ尥"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ尦"),url,l1l111_l1_ (u"ࠨࠩ尧"),l1l111_l1_ (u"ࠩࠪ尨"),l1l111_l1_ (u"ࠪࠫ尩"),l1l111_l1_ (u"ࠫࠬ尪"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ尫"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"࠭࡜࡝ࠤࠪ尬"),l1l111_l1_ (u"ࠧࠣࠩ尭")).replace(l1l111_l1_ (u"ࠨ࡞࡟࠳ࠬ尮"),l1l111_l1_ (u"ࠩ࠲ࠫ尯"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡼ࡫ࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡼ࡫ࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭尰"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ就"),block+l1l111_l1_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ尲"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ尳") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩ尴"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠨ࠿ࡀࠫ尵") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭尶"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ尷")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1ll111_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ尸"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ尹"),l1111111_l1_,561,l1l111_l1_ (u"࠭ࠧ尺"),l1l111_l1_ (u"ࠧࠨ尻"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ尼"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ尽"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ尾"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠫࠬ尿"),l1l111_l1_ (u"ࠬ࠭局"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ屁"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ层")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ屃")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ屄")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ居")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ屆")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屇"),l1lllll_l1_+name+l1l111_l1_ (u"࠭࠺ࠡษ็ะ๊๐ูࠨ屈"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠧࠨ屉"),l1l111_l1_ (u"ࠨࠩ届"),l1l111l1_l1_+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ屋"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠪࡶࠬ屌") or value==l1l111_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ屍"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ屎") in option: continue
			if l1l111_l1_ (u"࠭วๅๅ็ࠫ屏") in option: continue
			if l1l111_l1_ (u"ࠧ࡯࠯ࡤࠫ屐") in value: continue
			if option==l1l111_l1_ (u"ࠨࠩ屑"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧ屒"),option,re.DOTALL)
			if l1ll1l11l11_l1_: l1l11l1ll_l1_ = l1ll1l11l11_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠪ࠾ࠥ࠭屓")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ屔")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨ展")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ屖")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿ࠪ屗")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ屘")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ屙"):
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屚"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠫࠬ屛"),l1l111_l1_ (u"ࠬ࠭屜"),l1l1l11l_l1_+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ屝"))
			elif type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ属") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ屟") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ屠"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ屡")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1llll1ll111_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屢"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠬ࠭屣"),l1l111_l1_ (u"࠭ࠧ層"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ履"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屦"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠩࠪ屧"),l1l111_l1_ (u"ࠪࠫ屨"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ屩"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ屪"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭屫")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ屬"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ屭"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ屮"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ屯"),l1l111_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ屰"),l1l111_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ山"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭屲"),l1l111_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ屳")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ屴") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ屵"),l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ屶"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ屷"),l1l111_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ屸"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠽࠾ࠩ屹"),l1l111_l1_ (u"ࠧ࠰ࠩ屺"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨࠨࠩࠫ屻"),l1l111_l1_ (u"ࠩ࠲ࠫ屼"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭屽"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠫࠬ屾")
	if l1l111_l1_ (u"ࠬࡃ࠽ࠨ屿") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠧࠩ岀"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾࠿ࠪ岁"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪ岂")
		if l1l111_l1_ (u"ࠩࠨࠫ岃") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ岄") and value!=l1l111_l1_ (u"ࠫ࠵࠭岅"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩ岆")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ岇") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ岈"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ岉")+key+l1l111_l1_ (u"ࠩࡀࡁࠬ岊")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧ岋"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ岌")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨ岍")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ岎"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ岏"))
	return l1l1l111_l1_
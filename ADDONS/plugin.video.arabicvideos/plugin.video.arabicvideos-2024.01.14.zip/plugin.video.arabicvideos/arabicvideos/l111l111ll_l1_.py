# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ⒂")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡉࡌࡔ࡟ࠨ⒃")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ⒄"),l1l111_l1_ (u"ࠫฬ๊ใๅࠩ⒅"),l1l111_l1_ (u"ࠬࡴ࠯ࡂࠩ⒆"),l1l111_l1_ (u"࠭วๅ็ี๎ิ࠭⒇"),l1l111_l1_ (u"ࠧใืฬࠤ฾ฺโࠨ⒈")]
def l11l1ll_l1_(mode,url,text):
	if   mode==430: l1lll_l1_ = l1l1l11_l1_()
	elif mode==431: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==432: l1lll_l1_ = PLAY(url)
	elif mode==433: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==434: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⒉")+text)
	elif mode==435: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⒊")+text)
	elif mode==436: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==437: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==439: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⒋"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫ⒌"),l1l111_l1_ (u"ࠬ࠭⒍"),l1l111_l1_ (u"࠭ࠧ⒎"),l1l111_l1_ (u"ࠧࠨ⒏"),l1l111_l1_ (u"ࠨࠩ⒐"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⒑"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧ࡮ࡰࡰ࡬ࡧࡦࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⒒"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠫ࠴࠭⒓"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ⒔"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒕"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⒖"),l1l111_l1_ (u"ࠨࠩ⒗"),439,l1l111_l1_ (u"ࠩࠪ⒘"),l1l111_l1_ (u"ࠪࠫ⒙"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⒚"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⒛"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ⒜"),l1l11ll_l1_,435)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒝"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ⒞"),l1l11ll_l1_,434)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⒟"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⒠"),l1l111_l1_ (u"ࠫࠬ⒡"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⒢"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⒣")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭⒤"),l1l11ll_l1_,431)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒥"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⒦")+l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠢส์๋ࠦไศ์้ࠫ⒧"),l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶ࠵ࠬ⒨"),436)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⒩"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⒪")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡษ๋๊๊ࠥว๋่ࠪ⒫"),l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠯ࡤࡰࡱ࠷ࠧ⒬"),436)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⒭"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⒮")+l1lllll_l1_+l1l111_l1_ (u"ࠫ็อฦๆหࠣฮๆ฻๊ๅ์ฬࠫ⒯"),l1l11ll_l1_,437)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⒰"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⒱"),l1l111_l1_ (u"ࠧࠨ⒲"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖ࡭ࡹ࡫ࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡸࡣࡩࠤࠪ⒳"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⒴"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ⒵"): continue
		if l1l111_l1_ (u"ࠫฬ๎ๆࠡๆส๎๋࠭Ⓐ") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⒷ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⒸ")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠧࠨⒹ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬⒺ"),l1l11l11_l1_+l1l111_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴࠩⒻ"),l1l111_l1_ (u"ࠪࠫⒼ"),l1l111_l1_ (u"ࠫࠬⒽ"),l1l111_l1_ (u"ࠬ࠭Ⓘ"),l1l111_l1_ (u"࠭ࠧⒿ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩⓀ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡥࡳࡵ࡮ࡪࡥࡤࡰࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⓁ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠩ࠲ࠫⓂ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧⓃ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡒࡩࡴࡶࡇࡶࡴࡶࡥࡥࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡷࡩࡨࡪࡰࡪࡑࡦࡹࡴࡦࡴࠥࠫⓄ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⓅ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l11lll_l1_: continue
		l1ll1ll_l1_ = l1l11l11_l1_+l1l111_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࡁࠪⓆ")+category+l1l111_l1_ (u"ࠧ࠾ࠩⓇ")+value
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓈ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⓉ")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l11ll1_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧⓊ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨⓋ"),url,l1l111_l1_ (u"ࠬ࠭Ⓦ"),l1l111_l1_ (u"࠭ࠧⓍ"),l1l111_l1_ (u"ࠧࠨⓎ"),l1l111_l1_ (u"ࠨࠩⓏ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧⓐ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓑ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫⓒ"),url,431)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬⓓ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬⓔ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		if title in l11lll_l1_: continue
		l1lllll1_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡎࡱࡹ࡭ࡪࡹ࠯ࡌࡧࡼࡷ࠳ࡶࡨࡱࡁ࡮ࡩࡾࡃࠧⓕ")+l111l1l1l_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓖ"),l1lllll_l1_+title,l1lllll1_l1_,431)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠩࠪⓗ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧⓘ"))
	items = []
	if l1l111_l1_ (u"ࠫ࠴࡚ࡥࡳ࡯ࡶ࠲ࡵ࡮ࡰࠨⓙ") in url or l1l111_l1_ (u"ࠬ࠵ࡇࡦࡶ࠱ࡴ࡭ࡶࠧⓚ") in url or l1l111_l1_ (u"࠭࠯ࡌࡧࡼࡷ࠳ࡶࡨࡱࠩⓛ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪⓜ"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩⓝ"),l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨⓞ"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪⓟ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩⓠ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭ⓡ"),l1l111_l1_ (u"࠭ࠧⓢ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫⓣ"))
		html = response.content
		block = html
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪⓤ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ⓥ"),url,l1l111_l1_ (u"ࠪࠫⓦ"),l1l111_l1_ (u"ࠫࠬⓧ"),l1l111_l1_ (u"ࠬ࠭ⓨ"),l1l111_l1_ (u"࠭ࠧⓩ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⓪"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡓࡡࡵࡥ࡫ࡩࡸ࡚ࡡࡣ࡮ࡨࠦࠬ⓫"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ⓬"),block,re.DOTALL)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⓭"),url,l1l111_l1_ (u"ࠫࠬ⓮"),l1l111_l1_ (u"ࠬ࠭⓯"),l1l111_l1_ (u"࠭ࠧ⓰"),l1l111_l1_ (u"ࠧࠨ⓱"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⓲"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡐࡢࡩ࡬ࡲࡦࡺࡥࠣࠩ⓳"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠪ⓴"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡩ࡮ࡣࡪࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⓵"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ⓶"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ⓷"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭⓸"),l1l111_l1_ (u"ࠨๅ็๎อ࠭⓹"),l1l111_l1_ (u"ࠩส฽้อๆࠨ⓺"),l1l111_l1_ (u"๋ࠪิอแࠨ⓻"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ⓼"),l1l111_l1_ (u"ࠬ฿ัืࠩ⓽"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭⓾"),l1l111_l1_ (u"ࠧศๆห์๊࠭⓿")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪ─"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ━"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ│"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ┃") in title:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ┄") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┅"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ┆") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┇"),l1lllll_l1_+title,l1ll1ll_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┈"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	if request!=l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ┉"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡖࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ┊"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ┋"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ┌") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				if title!=l1l111_l1_ (u"ࠧࠨ┍"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┎"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ┏")+title,l1ll1ll_l1_,431)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷ࡭ࡵࡷ࡮ࡱࡵࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┐"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┑"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬิศ้าอࠥอไๆิํำࠬ┒"),l1ll1ll_l1_,431)
	return
def l1ll1l11_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ┓"))
	l11ll1l_l1_,l11ll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠧࡆࡲ࡬ࡷࡴࡪࡥࡴ࠰ࡳ࡬ࡵ࠭└") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ┕"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ┖"),l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ┗"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ┘")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ┙"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ┚"),l1l111_l1_ (u"ࠧࠨ┛"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ├"))
		html = response.content
		l11ll11_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭┝"),url,l1l111_l1_ (u"ࠪࠫ┞"),l1l111_l1_ (u"ࠫࠬ┟"),l1l111_l1_ (u"ࠬ࠭┠"),l1l111_l1_ (u"࠭ࠧ┡"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭┢"))
		html = response.content
		l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ┣"),html,re.DOTALL)
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡉࡵ࡯ࡳࡰࡦࡨࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭┤"),html,re.DOTALL)
	if l11ll1l_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡴ࡭࠺ࡪ࡯ࡤ࡫ࡪࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ┥"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ┦"),block,re.DOTALL)
		for l1ll11l_l1_,l111l11l1_l1_,title in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴ࡋࡰࡪࡵࡲࡨࡪࡹ࠮ࡱࡪࡳࡃࠬ┧")+l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡃࠧ┨")+l111l11l1_l1_+l1l111_l1_ (u"ࠧࠧࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ┩")+l1ll11l_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┪"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪ┫"))
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ┬"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"ࠫࠥ࠭┭")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ┮"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ┯")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ┰"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ┱"),l1l111_l1_ (u"ࠩࠪ┲"),l1l111_l1_ (u"ࠪࠫ┳"),l1l111_l1_ (u"ࠫࠬ┴"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ┵"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ┶"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱ࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ┷"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ┸"),block,re.DOTALL)
		if l11111l11_l1_:
			l11111l11_l1_ = l11111l11_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ┹"),block,re.DOTALL)
			for server,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨ┺")+server+l1l111_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ┻")+l11111l11_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭┼")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ┽")
				l1llll_l1_.append(l1ll1ll_l1_)
	l111l1111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡮࡬ࡲࡢ࡯ࡨࠦࡃࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ┾"),html,re.DOTALL)
	if l111l1111l_l1_:
		l111l1111l_l1_ = l111l1111l_l1_[0].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ┿"),l1l111_l1_ (u"ࠩࠪ╀"))
		title = l1l111l_l1_(l111l1111l_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ╁"))
		l1ll1ll_l1_ = l111l1111l_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ╂")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭╃")
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ╄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࠫ╅"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ╆"),l1l111_l1_ (u"ࠩࠪ╇"))
			if l111l1ll_l1_!=l1l111_l1_ (u"ࠪࠫ╈"): l111l1ll_l1_ = l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ╉")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭╊")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ╋")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭╌"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ╍"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ╎"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ╏"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ═"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ║")+search
	l1lll11_l1_(url)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ╒"))[0]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ╓"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ╔"),l1l11ll_l1_,l1l111_l1_ (u"ࠩࠪ╕"),l1l111_l1_ (u"ࠪࠫ╖"),l1l111_l1_ (u"ࠫࠬ╗"),l1l111_l1_ (u"ࠬ࠭╘"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ╙"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡧࡻࡴࡵࡱࡱࠦ࠳࠰࠿ࠪࠤࡖࡩࡦࡸࡣࡩ࡫ࡱ࡫ࡒࡧࡳࡵࡧࡵࠦࠬ╚"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡧࡻࡴࡵࡱࡱࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠫࠪ╛"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࡝ࡦ࠮࠭ࠧࠦࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ╜"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ╝"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ╞"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ╟"),l1l111_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࡁࠪ╠"))
	return url
def l111l111l1_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ╡"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ╢")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
l1l11111_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ╣"),l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ╤"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ╥"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ╦")]
l1l11lll_l1_ = [l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ╧"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭╨"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ╩"),l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ╪"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ╫"),l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ╬")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠬࡅࠧ╭") in url: url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ╮"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ╯"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ╰"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ╱"),l1l111_l1_ (u"ࠪࠫ╲")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ╳"))
	if type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ╴"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"࠭࠽ࠨ╵") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠧ࠾ࠩ╶") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ╷")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬ╸")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ╹")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ╺")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ╻"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ╼")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ╽"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ╾"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭╿")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭▀"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭▁"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠬ࠭▂"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ▃"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠧࠨ▄"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ▅")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▆"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭▇"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ█"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ▉")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ▊"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ▋"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ▌"),l1l111_l1_ (u"ࠩࠪ▍"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠪ࠱࠲࠭▎"),l1l111_l1_ (u"ࠫࠬ▏"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠬࡃࠧ▐") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ░"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭▒")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▓"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ▔"),l1lllll1_l1_,431)
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▕"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ▖"),l1lllll1_l1_,435,l1l111_l1_ (u"ࠬ࠭▗"),l1l111_l1_ (u"࠭ࠧ▘"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ▙"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ▚")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ▛")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ▜")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ▝")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ▞")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭▟"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ■")+name,l1lllll1_l1_,434,l1l111_l1_ (u"ࠨࠩ□"),l1l111_l1_ (u"ࠩࠪ▢"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠵ࠪ▣"): option = l1l111_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫ▤")
			elif value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠵ࠬ▥"): option = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨ▦")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ▧")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ▨")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ▩")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ▪")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ▫")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨ▬")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨ▭")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ▮")+name
			if type==l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ▯"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▰"),l1lllll_l1_+title,url,434,l1l111_l1_ (u"ࠪࠫ▱"),l1l111_l1_ (u"ࠫࠬ▲"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ△") and l1l11111_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨ▴") in l11lll1l_l1_:
				l1llllll_l1_ = l111l111l1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▵"),l1lllll_l1_+title,l1llllll_l1_,431)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▶"),l1lllll_l1_+title,url,435,l1l111_l1_ (u"ࠩࠪ▷"),l1l111_l1_ (u"ࠪࠫ▸"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠫࡂࠬࠧ▹"),l1l111_l1_ (u"ࠬࡃ࠰ࠧࠩ►"))
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠨ▻"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠧ࠾ࠩ▼") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠪ▽"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࠫ▾"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠪࠫ▿")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭◀")
		if l1l111_l1_ (u"ࠬࠫࠧ◁") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ◂") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ◃"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ◄")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ◅") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ◆"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭◇")+key+l1l111_l1_ (u"ࠬࡃࠧ◈")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ◉"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ◊")+key+l1l111_l1_ (u"ࠨ࠿ࠪ○")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭◌"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬ◍"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠫࡂ࠶ࠧ◎"),l1l111_l1_ (u"ࠬࡃࠧ●"))
	return l1l1l111_l1_
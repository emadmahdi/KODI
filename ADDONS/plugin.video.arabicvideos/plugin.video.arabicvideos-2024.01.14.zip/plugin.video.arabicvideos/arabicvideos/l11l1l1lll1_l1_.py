# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ圾")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ圿")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ址"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l1ll1l1l1_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坁"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ坂"),l1l111_l1_ (u"ࠩࠪ坃"),319,l1l111_l1_ (u"ࠪࠫ坄"),l1l111_l1_ (u"ࠫࠬ坅"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ坆"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ均"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ坈"),l1l111_l1_ (u"ࠨࠩ坉"),l1l111_l1_ (u"ࠩࠪ坊"),l1l111_l1_ (u"ࠪࠫ坋"),l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ坌"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻ࡬ࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ坍"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ坎"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ坏"),l1l111_l1_ (u"ࠨࠩ坐"),9999)
	items = re.findall(l1l111_l1_ (u"ࠩ࠿࡬࠺ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠶ࡀࠪ坑"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠪࠤࠬ坒"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坓"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ坔")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"࠭ࠧ坕"),l1l111_l1_ (u"ࠧࠨ坖"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ块"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ坘")+l1lllll_l1_+l1l111_l1_ (u"้ࠪ็อืฺࠢื๋ึ࠭坙"),l111l1_l1_,314,l1l111_l1_ (u"ࠫࠬ坚"),l1l111_l1_ (u"ࠬ࠭坛"),l1l111_l1_ (u"࠭࠰ࠨ坜"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ坝"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ坞"),l1l111_l1_ (u"ࠩࠪ坟"),9999)
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡈ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡃࡀࠪ坠"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭坡")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ坢"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ坣")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ坤"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ坥"),l1l111_l1_ (u"ࠩࠪ坦"),l1l111_l1_ (u"ࠪࠫ坧"),l1l111_l1_ (u"ࠫࠬ坨"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ坩"))
	html = response.content
	if seq==l1l111_l1_ (u"࠭࠰ࠨ坪"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ坫"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ坬"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ坭")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ坮"))
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭坯"))
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ坰")+name+l1l111_l1_ (u"࠭ࠩࠨ坱")
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭坲"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠨ࠳ࠪ坳"),l1l111_l1_ (u"ࠩ࠵ࠫ坴"),l1l111_l1_ (u"ࠪ࠷ࠬ坵")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡮ࡪࠫ坶"),html,re.DOTALL)
		l11l1ll1l1ll_l1_ = int(seq)-1
		block = l11llll_l1_[l11l1ll1l1ll_l1_]
		if seq==l1l111_l1_ (u"ࠬ࠷ࠧ坷"): items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ坸"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ坹"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ坺")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ坻")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ坼"))
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭坽"))
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ坾")+name+l1l111_l1_ (u"࠭ࠩࠨ坿")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垀"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠨ࠶ࠪ垁"),l1l111_l1_ (u"ࠩ࠸ࠫ垂"),l1l111_l1_ (u"ࠪ࠺ࠬ垃")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ垄"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀ࠯ࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ垅"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11ll1_l1_,title,l11111111l_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ垆")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ垇")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ垈"))
			l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ垉"))
			l11111111l_l1_ = l11111111l_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬ垊"))
			if l1ll1l11ll1_l1_: name = l1ll1l11ll1_l1_
			else: name = l11111111l_l1_
			title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ型")+name+l1l111_l1_ (u"ࠬ࠯ࠧ垌")
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ垍"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ垎"),url,l1l111_l1_ (u"ࠨࠩ垏"),l1l111_l1_ (u"ࠩࠪ垐"),l1l111_l1_ (u"ࠪࠫ垑"),l1l111_l1_ (u"ࠫࠬ垒"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ垓"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡣࡱࡻ࠱࡭࡫ࡡࡥ࡫ࡱ࡫ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡱࡵࡡࡵ࠯ࡵ࡭࡬࡮ࡴࠨ垔"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠧࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠧ垕") in block:
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ垖"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ垗")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ垘")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠫࠥอไึ๊อ๎ฮࡀࠠࠨ垙"),l1l111_l1_ (u"ࠬࡀࠧ垚"))
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垛"))
				title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垜")+count+l1l111_l1_ (u"ࠨࠫࠪ垝")
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垞"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垟"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l1ll1ll11_l1_,l1l1lll111_l1_ in items:
			if title==l1l111_l1_ (u"ࠫࠬ垠") or l11l1ll1ll11_l1_==l1l111_l1_ (u"ࠬ࠭垡"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ垢")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垣")+l1l1lll111_l1_+l1l111_l1_ (u"ࠨࠫࠪ垤")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ垥"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ垦"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ垧"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll111_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垨")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垩"))
		name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ垪"))
		title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ垫")+name+l1l111_l1_ (u"ࠩࠬࠫ垬")
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ垭"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠫࠬ垮"),l1l1lll111_l1_)
	return
def l11l1ll1l1l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ垯"),url,l1l111_l1_ (u"࠭ࠧ垰"),l1l111_l1_ (u"ࠧࠨ垱"),l1l111_l1_ (u"ࠨࠩ垲"),l1l111_l1_ (u"ࠩࠪ垳"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍࡥࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ垴"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠣࡴ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ垵"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ垶"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ垷")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ垸"))
		if l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠭ࠨ垹") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ垺"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垻"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ垼"),url,l1l111_l1_ (u"ࠬ࠭垽"),l1l111_l1_ (u"࠭ࠧ垾"),l1l111_l1_ (u"ࠧࠨ垿"),l1l111_l1_ (u"ࠨࠩ埀"),l1l111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ埁"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡦࡻࡤࡪࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ埂"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ埃"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埄"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ埅"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ埆"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ埇"),l1l111_l1_ (u"ࠩ࠮ࠫ埈"))
	l11l1ll1ll1l_l1_ = [l1l111_l1_ (u"ࠪࠪࡹࡃࡡࠨ埉"),l1l111_l1_ (u"ࠫࠫࡺ࠽ࡤࠩ埊"),l1l111_l1_ (u"ࠬࠬࡴ࠾ࡵࠪ埋")]
	if l11_l1_:
		l11l1ll1l11l_l1_ = [l1l111_l1_ (u"࠭โศำษࠫ埌"),l1l111_l1_ (u"ࠧฦืาหึࠦ࠯ࠡ็ฯ่ิ࠭埍"),l1l111_l1_ (u"ࠨ็ๅ฻฾ࠦวๅื๋ฮ๏࠭城")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ࠲ࠦรฯฬิࠤฬ๊ศฮอࠪ埏"), l11l1ll1l11l_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࡠࠩ埐") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩ埑") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ埒") in options: l11l11l_l1_ = 2
	else: return
	type = l11l1ll1ll1l_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡶࡃࠧ埓")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ埔"),url,l1l111_l1_ (u"ࠨࠩ埕"),l1l111_l1_ (u"ࠩࠪ埖"),l1l111_l1_ (u"ࠪࠫ埗"),l1l111_l1_ (u"ࠫࠬ埘"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ埙"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ埚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埛"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ埜"))
				name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ埝"))
				title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埞")+name+l1l111_l1_ (u"ࠫ࠮࠭域")
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埠"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡺࡤ࠿࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀࠬ埡"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ埢"))
				name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ埣"))
				title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ埤")+name+l1l111_l1_ (u"ࠪ࠭ࠬ埥")
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ埦"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
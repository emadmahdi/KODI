# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ嚠")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌࡓࡥࠧ嚡")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩๅ๊ํอสࠡใูหห๐ษࠨ嚢"),l1l111_l1_ (u"ࠪๅฬืำไ๊ࠪ嚣"),l1l111_l1_ (u"ࠫࡘ࡮࡯ࡸࠢࡰࡳࡷ࡫ࠧ嚤")]
def l11l1ll_l1_(mode,url,text):
	if   mode==580: l1lll_l1_ = l1l1l11_l1_()
	elif mode==581: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==582: l1lll_l1_ = PLAY(url)
	elif mode==583: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==584: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==589: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嚥"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ嚦"),l1l111_l1_ (u"ࠧࠨ嚧"),l1l111_l1_ (u"ࠨࠩ嚨"),l1l111_l1_ (u"ࠩࠪ嚩"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ嚪"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚫"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ嚬"),l1l111_l1_ (u"࠭ࠧ嚭"),589,l1l111_l1_ (u"ࠧࠨ嚮"),l1l111_l1_ (u"ࠨࠩ嚯"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嚰"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ嚱"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嚲"),l1l111_l1_ (u"ࠬ࠭嚳"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ嚴"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ嚵"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ嚶"))
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ嚷"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚸"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嚹")+l1lllll_l1_+title,l1ll1ll_l1_,584)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嚺"),url,l1l111_l1_ (u"࠭ࠧ嚻"),l1l111_l1_ (u"ࠧࠨ嚼"),l1l111_l1_ (u"ࠨࠩ嚽"),l1l111_l1_ (u"ࠩࠪ嚾"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ嚿"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ囀"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭囁"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ囂"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ囃"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩ囄"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ囅"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ囆"),l1l111_l1_ (u"ࠫࠬ囇"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ囈"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩ囉")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囊"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ囋"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ囌"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ囍"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭囎"),l1l111_l1_ (u"ࠬ࠭囏"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囐"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨ囑")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ囒"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭囓"),url,l1l111_l1_ (u"ࠪࠫ囔"),l1l111_l1_ (u"ࠫࠬ囕"),l1l111_l1_ (u"ࠬ࠭囖"),l1l111_l1_ (u"࠭ࠧ囗"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ囘"))
	html = response.content
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囙"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠩ囚"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰࡫ࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ四"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡷ࡫࡬ࡢࡶࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囜"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭囝"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ回"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ囟"),l1l111_l1_ (u"ࠨใํ่๊࠭因"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ囡"),l1l111_l1_ (u"ࠪ็้๐ศࠨ团"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ団"),l1l111_l1_ (u"ࠬํฯศใࠪ囤"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭囥"),l1l111_l1_ (u"ฺࠧำูࠫ囦"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ囧"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ囨"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪ囩")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠫ࠴࠭囪"))
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ囫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ囬")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ园"))
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭囮") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ囯")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ困"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ囱"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ囲"),l1lllll_l1_+title,l1ll1ll_l1_,582,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭図") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭围") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ囵"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ囶") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囷"),l1lllll_l1_+title,l1ll1ll_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囸"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧ囹"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ固")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ囻"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭囼"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫ国"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ图")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭囿"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圀"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ圁")+title,l1ll1ll_l1_,581)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ圂"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圃"),l1lllll_l1_+l1l111_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะࠩ圄"),l1ll1ll_l1_,581)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ圅"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ圆"),url,l1l111_l1_ (u"ࠬ࠭圇"),l1l111_l1_ (u"࠭ࠧ圈"),l1l111_l1_ (u"ࠧࠨ圉"),l1l111_l1_ (u"ࠨࠩ圊"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ國"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡼ࠭ࡴࡧࡤࡷࡴࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ圌"),html,re.DOTALL)
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭圍"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧ圎"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭圏"),l1lllll_l1_+title,url,583,l1l111_l1_ (u"ࠧࠨ圐"),l1l111_l1_ (u"ࠨࠩ圑"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ園")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ圓"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ圔"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ圕")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ圖"))
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭圗"),l1lllll_l1_+title,l1ll1ll_l1_,582)
		else:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ團"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ圙") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ圚")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭圛"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ圜"),l1lllll_l1_+title,l1ll1ll_l1_,582)
	return
def PLAY(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ圝"))
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ圞"),url,l1l111_l1_ (u"ࠨࠩ土"),l1l111_l1_ (u"ࠩࠪ圠"),l1l111_l1_ (u"ࠪࠫ圡"),l1l111_l1_ (u"ࠫࠬ圢"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ圣"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡑ࡮ࡤࡽࡪࡸࡨࡰ࡮ࡧࡩࡷࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ圤"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ圥") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ圦")+l1ll1ll_l1_
	hash = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࡫ࡥࡸ࡮࠽ࠨ圧"))[1]
	parts = hash.split(l1l111_l1_ (u"ࠪࡣࡤ࠭在"))
	l1ll1l1lll11_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l111_l1_ (u"ࠫࡂ࠭圩"))
			if PY3: part = part.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ圪"))
			l1ll1l1lll11_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l111_l1_ (u"࠭࠾ࠨ圫").join(l1ll1l1lll11_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	if l1l111_l1_ (u"ࠧࡧࡣࡵࡷࡴࡲࠧ圬") not in str(l1ll_l1_):
		for l1ll1ll_l1_ in l1ll_l1_:
			title,l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠢࡀࡂࠥ࠭圭"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ圮")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ圯")
			l1llll_l1_.append(l1ll1ll_l1_)
		import ll_l1_
		ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ地"),url)
	else:
		title,l1ll1ll_l1_ = l1ll_l1_[0].split(l1l111_l1_ (u"ࠬࠦ࠽࠿ࠢࠪ圱"))
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ圲"),l1l111_l1_ (u"ࠧࠨ圳"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ圴"),l1l111_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆࠨ圵")+l1l111_l1_ (u"ࠪࡠࡳ࠭圶")+l1l111_l1_ (u"ࠫ๏ืฬ๊ࠢส่๊ำว้ๆฬࠤ้ออใษࠪ圷")+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ圸")+title)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ圹"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ场"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ圻"),l1l111_l1_ (u"ࠩ࠮ࠫ圼"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ圽")+search
	l1lll11_l1_(url)
	return
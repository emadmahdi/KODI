# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ埧")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡊࡗࡣࠬ埨")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ埩"),l1l111_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩ埪"),l1l111_l1_ (u"ࠩฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠬ埫")]
def l11l1ll_l1_(mode,url,text):
	if   mode==640: l1lll_l1_ = l1l1l11_l1_()
	elif mode==641: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==642: l1lll_l1_ = PLAY(url)
	elif mode==643: l1lll_l1_ = l11l1ll11lll_l1_(url,text)
	elif mode==644: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==645: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==649: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ埬"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ埭"),l1l111_l1_ (u"ࠬ࠭埮"),l1l111_l1_ (u"࠭ࠧ埯"),l1l111_l1_ (u"ࠧࠨ埰"),l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ埱"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ埲"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ埳"),l1l111_l1_ (u"ࠫࠬ埴"),649,l1l111_l1_ (u"ࠬ࠭埵"),l1l111_l1_ (u"࠭ࠧ埶"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ執"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭埸"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ培"),l1l111_l1_ (u"ࠪࠫ基"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ埻"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ埼"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"࠭ࠧ埽"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ埾"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ埿"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ堀")+l1lllll_l1_+title,l1ll1ll_l1_,644)
	return
def l11ll1_l1_(url):
	l11ll111l_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ堁"),url,l1l111_l1_ (u"ࠫࠬ堂"),l1l111_l1_ (u"ࠬ࠭堃"),l1l111_l1_ (u"࠭ࠧ堄"),l1l111_l1_ (u"ࠧࠨ堅"),l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭堆"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭堇"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ堈"),l1l111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ堉"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ堊"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"࠭ࠧ堋"),block)]
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ堌"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭堍"),l1l111_l1_ (u"ࠩࠪ堎"),9999)
		for l11111_l1_,block in l11llll_l1_:
			l11ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ堏"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠫ࠿ࠦࠧ堐")
			for l1ll1ll_l1_,title in l11ll111l_l1_:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堑"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ堒"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ堓"),block,re.DOTALL)
		if len(l1l1111_l1_)<30:
			if l11ll111l_l1_: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭堔"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ堕"),l1l111_l1_ (u"ࠪࠫ堖"),9999)
			for l1ll1ll_l1_,title in l1l1111_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堗"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭堘")):
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ堙"):
		url,search = url.split(l1l111_l1_ (u"ࠧࡀࠩ堚"),1)
		data = l1l111_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ堛")+search
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ堜"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ堝")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ堞"),url,data,headers,l1l111_l1_ (u"ࠬ࠭堟"),l1l111_l1_ (u"࠭ࠧ堠"),l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ堡"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ堢"),url,l1l111_l1_ (u"ࠩࠪ堣"),l1l111_l1_ (u"ࠪࠫ堤"),l1l111_l1_ (u"ࠫࠬ堥"),l1l111_l1_ (u"ࠬ࠭堦"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ堧"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠧࠨ堨"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ堩"))
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ堪"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ堫"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬ堬"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ堭"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ堮"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭堯"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ堰"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭報"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ堲"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭堳"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ場"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ堵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨ堶"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ堷"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ堸"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ堹"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ堺"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ堻"),l1l111_l1_ (u"࠭ใๅ์หࠫ堼"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭堽"),l1l111_l1_ (u"ࠨ้าหๆ࠭堾"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ堿"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ塀"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ塁"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ塂"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭塃")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ塄"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ塅"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ塆"):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ塇"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ塈") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ塉"),l1lllll_l1_+title,l1ll1ll_l1_,645,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭塊"),l1lllll_l1_+title,l1ll1ll_l1_,645,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ塋"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭塌"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫ塍"): continue
				if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ塎") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭塏")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ塐"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭塑"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭塒")+title,l1ll1ll_l1_,641)
	return
def l11l1ll11lll_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ塓"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭塔"),url,l1l111_l1_ (u"ࠪࠫ塕"),l1l111_l1_ (u"ࠫࠬ塖"),l1l111_l1_ (u"ࠬ࠭塗"),l1l111_l1_ (u"࠭ࠧ塘"),l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭塙"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ塚"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ塛"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ塜")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭塝"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧ塞"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭塟"),l1lllll_l1_+title,url,645,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ塠"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩ塡")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ塢"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ塣"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ塤") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ塥")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ塦"))
			title = title.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾࠽ࡧࡰࡂࠬ塧"),l1l111_l1_ (u"ࠨࠢࠪ塨"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ塩"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ塪"),url,l1l111_l1_ (u"ࠫࠬ填"),l1l111_l1_ (u"ࠬ࠭塬"),l1l111_l1_ (u"࠭ࠧ塭"),l1l111_l1_ (u"ࠧࠨ塮"),l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ塯"))
	html = response.content
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡳ࡬ࡀࡩ࡮ࡣࡪࡩࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ塰"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ塱")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡓࡻ࡭ࡣࡧࡵ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ塲"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡰ࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ塳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫ塴"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭塵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿࠾ࡨࡱࡃ࠭塶"),l1l111_l1_ (u"ࠩࠣࠫ塷"))
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ塸"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ塹"),url,l1l111_l1_ (u"ࠬ࠭塺"),l1l111_l1_ (u"࠭ࠧ塻"),l1l111_l1_ (u"ࠧࠨ塼"),l1l111_l1_ (u"ࠨࠩ塽"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ塾"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࠱ࡰࡴࡩࡡࡵ࡫ࡲࡲ࠳ࡸࡥࡱ࡮ࡤࡧࡪࡢࠨࠣࠪ࠱࠮ࡄ࠯ࠢࠨ塿"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ墀"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭墁"),l1l111_l1_ (u"࠭ࠧ墂"),l1l111_l1_ (u"ࠧࠨ境"),l1l111_l1_ (u"ࠨࠩ墄"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ墅"))
	html = response.content
	l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭墆"),html,re.DOTALL)
	l11l1l11_l1_ = l11l1l11_l1_[0]
	l1l11ll_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ墇"))
	l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡹ࡭ࡩ࡫࡯ࡠ࡫ࡱࡪࡴࠬࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ墈")+l11l1l11_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ墉"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ墊"),l1l111_l1_ (u"ࠨࠩ墋"),l1l111_l1_ (u"ࠩࠪ墌"),l1l111_l1_ (u"ࠪࠫ墍"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭墎"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡴࡴࡦࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭墏"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		title = escapeUNICODE(title)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࠩ墐"),l1l111_l1_ (u"ࠧࠨ墑"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ墒")+title+l1l111_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ墓"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ墔"),url)
	return
def l11l1ll1l111_l1_(url):
	l1ll11l1_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ墕"),l1l111_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠲ࡵ࡮ࡰࠨ墖"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ増"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ墘"),l1l111_l1_ (u"ࠨࠩ墙"),l1l111_l1_ (u"ࠩࠪ墚"),l1l111_l1_ (u"ࠪࠫ墛"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭墜"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ墝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ增"),block,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_ = l1ll_l1_[0]
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ墟"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ墠"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩ墡"),block,re.DOTALL)
		block = block.replace(l1l111_l1_ (u"ࠪࡠࡡࠨࠧ墢"),l1l111_l1_ (u"ࠫࠧ࠭墣")).replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨ墤"),l1l111_l1_ (u"࠭࠯ࠨ墥"))
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࠾࡬ࡪࡷࡧ࡭ࡦ࠰ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ墦"),block,re.DOTALL)
		if len(l11l1l1l1_l1_)==len(l1ll_l1_):
			for id,title in l11l1l1l1_l1_:
				l1ll1ll_l1_ = l1ll_l1_[int(id)]
				if l1ll1ll_l1_ not in l1llll_l1_:
					l1ll11111_l1_.append(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ墧")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ墨"))
					l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ墩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ墪"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭墫")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ墬"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭墭"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ墮"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ墯"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ墰"),l1l111_l1_ (u"ࠫ࠰࠭墱"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭墲")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭墳"))
	return
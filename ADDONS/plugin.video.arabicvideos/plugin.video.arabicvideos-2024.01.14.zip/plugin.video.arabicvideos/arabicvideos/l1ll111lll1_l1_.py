# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ヸ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡎࡕ࡞ࡤ࠭ヹ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪヺ"),l1l111_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ・"),l1l111_l1_ (u"ࠪห้อโิษ่ࠫー"),l1l111_l1_ (u"ࠫ฾ืึࠡษ็้ื๐ฯࠨヽ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==700: l1lll_l1_ = l1l1l11_l1_()
	elif mode==701: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==702: l1lll_l1_ = PLAY(url)
	elif mode==703: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==704: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==709: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡺࡪ࡭ࡤ࠲࠾࠭ヾ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪヿ"),l1l11ll_l1_,l1l111_l1_ (u"ࠧࠨ㄀"),l1l111_l1_ (u"ࠨࠩ㄁"),l1l111_l1_ (u"ࠩࠪ㄂"),l1l111_l1_ (u"ࠪࠫ㄃"),l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㄄"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄅ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ㄆ"),l1l111_l1_ (u"ࠧࠨㄇ"),709,l1l111_l1_ (u"ࠨࠩㄈ"),l1l111_l1_ (u"ࠩࠪㄉ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧㄊ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㄋ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧㄌ"),l1l111_l1_ (u"࠭ࠧㄍ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄎ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪㄏ")+l1lllll_l1_+l1l111_l1_ (u"่้ࠩ๏ุࠧㄐ"),l1l11ll_l1_,701,l1l111_l1_ (u"ࠪࠫㄑ"),l1l111_l1_ (u"ࠫࠬㄒ"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧㄓ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰ࡮࠯ࡷࡳࡵ࠳࡮ࡢࡸࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡪ࡬ࡨࡩ࡫࡮ࠨㄔ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧㄕ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠨ࠾ࡥࡂࠬㄖ"),l1l111_l1_ (u"ࠩࠪㄗ")).strip(l1l111_l1_ (u"ࠪࠤࠬㄘ"))
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠪㄙ")): continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄚ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨㄛ")+l1lllll_l1_+title,l1ll1ll_l1_,704)
	return
def l11ll1_l1_(url):
	found = False
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫㄜ"),url,l1l111_l1_ (u"ࠨࠩㄝ"),l1l111_l1_ (u"ࠩࠪㄞ"),l1l111_l1_ (u"ࠪࠫㄟ"),l1l111_l1_ (u"ࠫࠬㄠ"),l1l111_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪㄡ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡲࡰ࡮ࡨࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㄢ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨㄣ"),l1l111_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧㄤ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㄥ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠪࠫㄦ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㄧ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪㄨ"),l1l111_l1_ (u"࠭ࠧㄩ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㄪ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠨ࠼ࠣࠫㄫ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄬ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㄭ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㄮ"),block,re.DOTALL)
		if len(items)<30:
			if found: addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪㄯ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㄰"),l1l111_l1_ (u"ࠧࠨㄱ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄲ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡹ࡬࡯ࡰࡶࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩㄳ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨㄴ"),block,re.DOTALL)
		if 1:
			if found: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㄵ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧㄶ"),l1l111_l1_ (u"࠭ࠧㄷ"),9999)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩㄸ"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄹ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	if not found: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠩࠪㄺ")):
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨㄻ"):
		url,search = url.split(l1l111_l1_ (u"ࠫࡄ࠭ㄼ"),1)
		data = l1l111_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫㄽ")+search
		headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬㄾ"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧㄿ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ㅀ"),url,data,headers,l1l111_l1_ (u"ࠩࠪㅁ"),l1l111_l1_ (u"ࠪࠫㅂ"),l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨㅃ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩㅄ"),url,l1l111_l1_ (u"࠭ࠧㅅ"),l1l111_l1_ (u"ࠧࠨㅆ"),l1l111_l1_ (u"ࠨࠩㅇ"),l1l111_l1_ (u"ࠩࠪㅈ"),l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧㅉ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠫࠬㅊ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩㅋ"))
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫㅌ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩㅍ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩㅎ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫㅏ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㅐ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪㅑ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㅒ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪㅓ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㅔ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪㅕ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡦࡦࠦ࡭ࡨࡤࠣࡸࡦࡨ࡬ࡦࠢࡩࡹࡱࡲࠢࠩ࠰࠭ࡃ࠮ࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩㅖ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩㅗ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬㅘ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㅙ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧㅚ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧㅛ"),l1l111_l1_ (u"ࠨใํ่๊࠭ㅜ"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨㅝ"),l1l111_l1_ (u"ࠪ็้๐ศࠨㅞ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪㅟ"),l1l111_l1_ (u"ࠬํฯศใࠪㅠ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭ㅡ"),l1l111_l1_ (u"ฺࠧำูࠫㅢ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨㅣ"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨㅤ"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪㅥ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩㅦ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧㅧ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨㅨ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪㅩ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㅪ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㅫ"):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㅬ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪㅭ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅮ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅯ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨㅰ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㅱ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫㅲ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬㅳ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ㅴ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅵ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬㅶ")+title,l1ll1ll_l1_,701)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫㅷ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬㅸ"),url,l1l111_l1_ (u"ࠩࠪㅹ"),l1l111_l1_ (u"ࠪࠫㅺ"),l1l111_l1_ (u"ࠫࠬㅻ"),l1l111_l1_ (u"ࠬ࠭ㅼ"),l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬㅽ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪㅾ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪㅿ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪㆀ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫㆁ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧㆂ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧㆃ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㆄ"),l1lllll_l1_+title,url,703,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨㆅ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃ࠮ࡂࡳࡤࡴ࡬ࡴࡹࡄࠧㆆ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠧㆇ")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨㆈ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪㆉ")+l1l11_l1_+l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫㆊ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪㆋ")+l1l11_l1_+l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㆌ"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢㆍ"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ㆎ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㆏"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠳࠵ࠧ㆐"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ㆑")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ㆒"))
			title = title.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ㆓"),l1l111_l1_ (u"ࠨࠢࠪ㆔"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㆕"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㆖"),l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ㆗"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㆘"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ㆙"),l1l111_l1_ (u"ࠧࠨ㆚"),l1l111_l1_ (u"ࠨࠩ㆛"),l1l111_l1_ (u"ࠩࠪ㆜"),l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㆝"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ㆞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡐ࡭ࡣࡼࡩࡷ࡮࡯࡭ࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㆟"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧㆠ"))
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨㆡ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪㆢ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪㆣ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫㆤ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡓࡦࡴࡹࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫㆥ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㆦ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				title = title.strip(l1l111_l1_ (u"࠭࡜࡯ࠩㆧ"))
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨㆨ")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬㆩ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㆪ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫㆫ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬㆬ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧㆭ"),l1l111_l1_ (u"࠭ࠫࠨㆮ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨㆯ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨㆰ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭⦍")
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⦎"):l1l111_l1_ (u"࠭ࠧ⦏")}
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡈࡋ࠵ࡤ࠭⦐")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨฮ๋หหุࠠศๆฦ์ุ้วาࠩ⦑"),l1l111_l1_ (u"ࠩส่๊ืวอ฻สฮࠬ⦒"),l1l111_l1_ (u"ࠪࡻࡼ࡫ࠧ⦓")]
def l11l1ll_l1_(mode,url,text):
	if   mode==570: l1lll_l1_ = l1l1l11_l1_()
	elif mode==571: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==572: l1lll_l1_ = PLAY(url)
	elif mode==573: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==576: l1lll_l1_ = l1llllll1l_l1_()
	elif mode==579: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⦔"),l1lllll_l1_+l1l111_l1_ (u"๊ࠬๅศาสࠤฬ๊ๅ้ไ฼ࠤอ฽๊ยࠩ⦕"),l1l111_l1_ (u"࠭ࠧ⦖"),576)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⦗"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⦘"),l1l111_l1_ (u"ࠩࠪ⦙"),9999)
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⦚"),l111l1_l1_,l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭⦛"),l1l111_l1_ (u"ࠬ็วึๆࠣษ฾๊ว็์ࠪ⦜"),l1l111_l1_ (u"࠭ࡤࡶࡤࡥࡩࡩ࠳࡭ࡰࡸ࡬ࡩࡸ࠭⦝"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦞"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⦟"),l1l11ll_l1_,579,l1l111_l1_ (u"ࠩࠪ⦠"),l1l111_l1_ (u"ࠪࠫ⦡"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⦢"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⦣"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⦤"),l1l111_l1_ (u"ࠧࠨ⦥"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⦦"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ⦧"),l1l11ll_l1_,571,l1l111_l1_ (u"ࠪࠫ⦨"),l1l111_l1_ (u"ࠫࠬ⦩"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠱ࠨ⦪"))
	items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨ࠴ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⦫"),html,re.DOTALL)
	if not items:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ⦬"),l1l111_l1_ (u"ࠨࠩ⦭"),l1l111_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอฬࠡัํࠤํออะࠩ⦮"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭⦯"))
		return
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⦰"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⦱")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"࠭ࠧ⦲"),l1l111_l1_ (u"ࠧࠨ⦳"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠳ࠪ⦴"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡱࡪࡴࡵ࠮ࡲࡵ࡭ࡲࡧࡲࡺࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⦵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯ࠠࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ⦶"),block,re.DOTALL)
		l1llll1l11l_l1_ = [l1l111_l1_ (u"ࠫࠬ⦷"),l1l111_l1_ (u"ࠬษแๅษ่࠾ࠥ࠭⦸"),l1l111_l1_ (u"࠭ๅิๆึ่ฬะ࠺ࠡࠩ⦹"),l1l111_l1_ (u"ࠧษำส้ัࡀࠠࠨ⦺"),l1l111_l1_ (u"ࠨฤึ๎ํ๐࠺ࠡࠩ⦻"),l1l111_l1_ (u"ࠩฦ๊๊๐࠺ࠡࠩ⦼")]
		l1l111llll_l1_ = 0
		for l1llll1llll_l1_ in l1llll1ll1l_l1_:
			if l1l111llll_l1_>0: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⦽"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⦾"),l1l111_l1_ (u"ࠬ࠭⦿"),9999)
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⧀"),l1llll1llll_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ⧁"): continue
				if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭⧂") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				if title==l1l111_l1_ (u"ࠩࠪ⧃"): continue
				if any(value in title.lower() for value in l11lll_l1_): continue
				title = l1llll1l11l_l1_[l1l111llll_l1_]+title
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧄"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⧅")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠬ࠭⧆"),l1l111_l1_ (u"࠭ࠧ⧇"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩ⧈"))
			l1l111llll_l1_ += 1
	return
def l1llllll1l_l1_():
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ⧉"),l1l111_l1_ (u"ࠩࠪ⧊"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⧋"),l1l111_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้ࠦศุ์ฤࠤ๊์ࠠศๆู่ิืࠠ࠯࠰ࠣฬุฮศࠡไํห๊ࠦรึฯสฬࠥอไๆ๊ๅ฽ࠥฮลืษไอࠥ็อึ๋ࠢฮา่โࠡล่๊๏ࠦึะ๊ࠢะํ๋ࠠศๆหีฬ๋ฬ๊๊ࠡะํ๋ࠠศๆๅีฬ฻ๆสࠢ฼่๎ࠦีโฯสฮࠥอไๆ๊ๅ฽ࠥ࠴࠮๊ࠡส่ํ่สࠡษ็ฺฬฬูࠡ์ำ๋อࠦแ๋่ࠢัฬ๎ไสࠢอะฬ๎า้ࠡำหࠥอไโฯุࠤํอหษษอࠤศ์่ࠠาสࠤฬ๊ศา่ส้ัࠦ็้่ࠢะึีࠠๆฬุๅาࠦไๅ็๋ห็฿้ࠠๆสࠤ๏่่ๆࠢหห้ํฬ้็ࠣ฽้๏ࠠศๆ่์ฬู่ࠨ⧌"))
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭⧍")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⧎"),url,l1l111_l1_ (u"ࠧࠨ⧏"),l1l111_l1_ (u"ࠨࠩ⧐"),l1l111_l1_ (u"ࠩࠪ⧑"),l1l111_l1_ (u"ࠪࠫ⧒"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⧓"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮࠴ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ⧔"),html,re.DOTALL)
	if not l11ll11_l1_: return
	if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⧕"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠧ࡝࡞࠲ࠫ⧖"),l1l111_l1_ (u"ࠨ࠱ࠪ⧗")).replace(l1l111_l1_ (u"ࠩ࡟ࡠࠧ࠭⧘"),l1l111_l1_ (u"ࠪࠦࠬ⧙"))]
	elif type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⧚"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡨࡰ࡯ࡨࡗࡱ࡯ࡤࡦࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⧛"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⧜"),block,re.DOTALL)
		l11ll1l11_l1_,l1ll_l1_,l11l11_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠴ࠪ⧝"):
		title,block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⧞"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠵ࠫ⧟") and len(l11ll11_l1_)>1:
		title = l11ll11_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧠"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠫࠬ⧡"),l1l111_l1_ (u"ࠬ࠭⧢"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠳ࠩ⧣"))
		title = l11ll11_l1_[1][0]
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧤"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠨࠩ⧥"),l1l111_l1_ (u"ࠩࠪ⧦"),l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠷ࠬ⧧"))
		return
	else:
		title,block = l11ll11_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧ࡮࠱ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⧨"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
		l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠬࡅࡲࡦࡵ࡬ࡾࡪࡃࠧ⧩"))[0]
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ⧪"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲࡸ࠵ࠧ⧫") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⧬"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠩࠪ⧭"):
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⧮")+l1l1lll_l1_[0][0]
			title = title.strip(l1l111_l1_ (u"ࠫࠥ⠙ࠧ⧯"))
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⧰"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⧱") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ⧲") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨࡪ࡬ࡲࡩ࡯࠯ࠨ⧳") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⧴"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧵"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⧶"):
		l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ⧷"),block,re.DOTALL)
		if l111l1llll_l1_:
			count = l111l1llll_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ⧸")+count
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧹"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ⧺"),l1ll1ll_l1_,571,l1l111_l1_ (u"ࠩࠪ⧻"),l1l111_l1_ (u"ࠪࠫ⧼"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⧽"))
	elif l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠭⧾") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ⧿"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⨀"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ࠨืไัฮࠦࠧ⨁")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⨂"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠪࠫ⨃"),l1l111_l1_ (u"ࠫࠬ⨄"),l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠺ࠧ⨅"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"࠭ࠧ⨆")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⨇"),url,l1l111_l1_ (u"ࠨࠩ⨈"),l1l111_l1_ (u"ࠩࠪ⨉"),l1l111_l1_ (u"ࠪࠫ⨊"),l1l111_l1_ (u"ࠫࠬ⨋"),l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⨌"))
	html = response.content
	l111lllll1_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡤࡷࡴࡴࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⨍"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࠥࡃࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࠦࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⨎"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ⨏"))
				l111lllll1_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,name,title in items:
					name = unescapeHTML(name)
					if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⨐") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
					title = name+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ⨑")+title
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⨒"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭⨓"),l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⨔"))
	if type==l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⨕") or not l111lllll1_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡳࡸࡺࡥࡳࡋࡰ࡫ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⨖"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪ⨗")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡶࡁ࡭࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⨘"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⨙"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⨚"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⨛"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l1ll_l1_,l1llll1lll1_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⨜"),url,l1l111_l1_ (u"ࠨࠩ⨝"),l1l111_l1_ (u"ࠩࠪ⨞"),l1l111_l1_ (u"ࠪࠫ⨟"),l1l111_l1_ (u"ࠫࠬ⨠"),l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⨡"))
	html = response.content
	l1llll1l111_l1_ = re.findall(l1l111_l1_ (u"࠭ๅิฬ๋ํࠥอไๆึส๋ิฯ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ⨢"),html,re.DOTALL)
	if l1llll1l111_l1_:
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡶࡤ࡫ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⨣"),html,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡹ࡭ࡩ࡫࡯ࡓࡱࡺࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⨤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⨥"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪ࡮ࡳࡧ࠾ࠩ⨦"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ⨧"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡴࡳࡧࡤࡱࡍ࡫ࡡࡥࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⨨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࠤࡂࠦࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ⨩"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧ࡫ࡰ࡫ࡂ࠭⨪"))[0]
			name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ⨫"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⨬")+name+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⨭"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡒࡩ࡯࡭ࡶࠬ࠳࠰࠿ࠪࡤ࡯ࡥࡨࡱࡷࡪࡰࡧࡳࡼ࠭⨮"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⨯"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦࡪ࡯ࡪࡁࠬ⨰"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⨱")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⨲"))
	for l1llll1l1l1_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll1l1l1_l1_.split(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥࠩ⨳"))
		if l1ll1ll_l1_ not in l1llll1l1ll_l1_:
			l1llll1l1ll_l1_.append(l1ll1ll_l1_)
			l1llll1lll1_l1_.append(l1llll1l1l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1lll1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⨴"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ⨵"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭⨶"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ⨷"),l1l111_l1_ (u"ࠧࠬࠩ⨸"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⨹")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⨺"),url,l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ⨻"),l1l111_l1_ (u"ࠫๆอีๅࠢศ฽้อๆ๋ࠩ⨼"),l1l111_l1_ (u"ࠬࡪࡵࡣࡤࡨࡨ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ⨽"))
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠵ࠨ⨾"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ傓")
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ傔") : l1l111_l1_ (u"ࠧࠨ傕") }
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡊ࡜ࡥࠧ傖")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l1l11111ll11_l1_(url)
	elif mode==215: l1lll_l1_ = l1l11111ll1l_l1_(url)
	elif mode==218: l1lll_l1_ = l1ll111l11l1_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll111l11l1_l1_():
	message = l1l111_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠥ࠴࠮࠯๋ࠢฬาอฬสࠢส่๎ࠦวฺษาอࠥฮัๆฮฬࠤ๊์ࠠศๆุๅึࠦ࠮࠯࠰ࠣ์ฬ๊ๅษำ่ะࠥำวๅ์สࠤฺฺ๊้ๆࠣ์๏฿ว็์ฺ้๋่ࠣࠦๅฬࠤฺำ๊สࠢ࠱࠲࠳่ࠦๅ้ำหู่ࠥโࠢํฬ็๏ࠠศๆ่์็฿ࠠๆ฼็ๆࠥอไ๊่ࠢหฺࠥวยࠢส่้ํࠧ傗")
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ傘"),l1l111_l1_ (u"ࠫࠬ備"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ傚"),l1l111_l1_ (u"࠭วๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠬ傛"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ傜"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ傝"),l1l111_l1_ (u"ࠩࠪ傞"),219,l1l111_l1_ (u"ࠪࠫ傟"),l1l111_l1_ (u"ࠫࠬ傠"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ傡"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡒ࡬ࡲࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂࡶࡩ࡯ࠨ࡯࡭ࡲ࡯ࡴ࠾࠴࠸ࠫ傢")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ傣"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ傤")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ傥"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠪࠫ傦"),headers,l1l111_l1_ (u"ࠫࠬ傧"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭储"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡆࡪ࡮ࡷࡩࡷࡹࡂࡶࡶࡷࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ傩"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ傪"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡹࡿࡰࡦ࠿ࡲࡲࡪࠬࡤࡢࡶࡤࡁࠬ傫")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ催"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ傭")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ傮"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ傯"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠศ่่๎ࠬ傰"),l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩ傱")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ傲"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ傳"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ傴")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ債"),headers,l1l111_l1_ (u"ࠬ࠭傶"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ傷"))
	if l1l111_l1_ (u"ࠧࡨࡧࡷࡴࡴࡹࡴࡴࠩ傸") in url or l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ傹") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡐࡩࡩ࡯ࡡࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ傺"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ傻"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ傼"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ傽"),l1l111_l1_ (u"࠭ว฻่ํอࠬ傾"),l1l111_l1_ (u"ࠧไๆํฬࠬ傿"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ僀"),l1l111_l1_ (u"๊ࠩำฬ็ࠧ僁"),l1l111_l1_ (u"้ࠪออัศหࠪ僂"),l1l111_l1_ (u"ࠫ฾ืึࠨ僃"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬ僄"),l1l111_l1_ (u"࠭วๅส๋้ࠬ僅")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ僆") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪ僇"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ僈"))
		if l1l111_l1_ (u"ࠪ࠳࡫࡯࡬࡮࠱ࠪ僉") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ僊"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ僋") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭僌") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ働"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ僎") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ像"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ僐"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ僑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ僒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧ僓"),l1l111_l1_ (u"ࠧࠨ僔"))
			if title!=l1l111_l1_ (u"ࠨࠩ僕"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ僖"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ僗")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ僘"),headers,l1l111_l1_ (u"ࠬ࠭僙"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ僚"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡵ࡫࠰ࡰ࡮ࡹࡴ࠮ࡰࡸࡱࡧ࡫ࡲࡦࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ僛"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠨࠩ僜").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ僝"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ僞"))
		title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ僟") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ僠"))[-1].replace(l1l111_l1_ (u"࠭࠭ࠨ僡"),l1l111_l1_ (u"ࠧࠡࠩ僢"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠨษ็ั้่ษ࠮ࠪ࡟ࡨ࠰࠯ࠧ僣"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ僤"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ僥")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭僦"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ僧"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ僨") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ僩") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ僪"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ僫") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ僬"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠫ࠴࠭僭"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭僮"),headers,l1l111_l1_ (u"࠭ࠧ僯"),l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ僰"))
	if l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ僱") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ僲"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ僳"),headers,l1l111_l1_ (u"ࠫࠬ僴"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭僵"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ僶"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ僷"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ僸"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l1111l_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ價")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ僺")+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ僻")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭僼")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ僽"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ僾") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ僿"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ儀"),headers,l1l111_l1_ (u"ࠪࠫ儁"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ儂"))
		id = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭儃"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l1111l_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ億"):l1l111_l1_ (u"ࠧࠨ儅") , l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ儆"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ儇") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭儈")+l1l1l1111l_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ儉"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭儊"),l1l111_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ儋"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠶࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ儌"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭儍"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ儎")+name+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ儏")+l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ儐")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠷ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ儑"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"࠭ࠧ儒")
					items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ儓"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"ࠨࠨࠩࠫ儔") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ儕"))[2].lower() + l1l111_l1_ (u"ࠪࠪࠫ࠭儖")
						server = server.replace(l1l111_l1_ (u"ࠫ࠳ࡩ࡯࡮ࠨࠩࠫ儗"),l1l111_l1_ (u"ࠬ࠭儘")).replace(l1l111_l1_ (u"࠭࠮ࡤࡱࠩࠪࠬ儙"),l1l111_l1_ (u"ࠧࠨ儚"))
						server = server.replace(l1l111_l1_ (u"ࠨ࠰ࡱࡩࡹࠬࠦࠨ儛"),l1l111_l1_ (u"ࠩࠪ儜")).replace(l1l111_l1_ (u"ࠪ࠲ࡴࡸࡧࠧࠨࠪ儝"),l1l111_l1_ (u"ࠫࠬ儞"))
						server = server.replace(l1l111_l1_ (u"ࠬ࠴࡬ࡪࡸࡨࠪࠫ࠭償"),l1l111_l1_ (u"࠭ࠧ儠")).replace(l1l111_l1_ (u"ࠧ࠯ࡱࡱࡰ࡮ࡴࡥࠧࠨࠪ儡"),l1l111_l1_ (u"ࠨࠩ儢"))
						server = server.replace(l1l111_l1_ (u"ࠩࠩࠪ࡭ࡪ࠮ࠨ儣"),l1l111_l1_ (u"ࠪࠫ儤")).replace(l1l111_l1_ (u"ࠫࠫࠬࡷࡸࡹ࠱ࠫ儥"),l1l111_l1_ (u"ࠬ࠭儦"))
						server = server.replace(l1l111_l1_ (u"࠭ࠦࠧࠩ儧"),l1l111_l1_ (u"ࠧࠨ儨"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ儩") + name + server + l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭優")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ儫"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ儬"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭儭"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ儮"),l1l111_l1_ (u"ࠧࠬࠩ儯"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ儰")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ娩")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩ娪")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫอัࠠๆสสุึ࠭娫")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ娬"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ娭"),l1l111_l1_ (u"ࠧࠨ娮"),l1l111_l1_ (u"ࠨࠩ娯"),l1l111_l1_ (u"ࠩࠪ娰"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ娱"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娲"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ娳"),l1l111_l1_ (u"࠭ࠧ娴"),469,l1l111_l1_ (u"ࠧࠨ娵"),l1l111_l1_ (u"ࠨࠩ娶"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭娷"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ娸"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭娹"),l1l111_l1_ (u"ࠬ࠭娺"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡮ࡧࡱࡹ࠲ࡨࡴ࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭娻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭娼"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭娽") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ娾"): title = l1l111_l1_ (u"ࠪะิ๐ฯࠡฯ็ๆฬะࠠห์ไ๎ࠥ็ว็ࠩ娿")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婀"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ婁")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"࠭ࠧ婂")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ婃"),url,l1l111_l1_ (u"ࠨࠩ婄"),l1l111_l1_ (u"ࠩࠪ婅"),l1l111_l1_ (u"ࠪࠫ婆"),l1l111_l1_ (u"ࠫࠬ婇"),l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ婈"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭婉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ婊"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ婋"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ婌"),l1l111_l1_ (u"ࠪห฿์๊สࠩ婍"),l1l111_l1_ (u"่๊๊ࠫษࠩ婎"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ婏"),l1l111_l1_ (u"࠭็ะษไࠫ婐"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ婑"),l1l111_l1_ (u"ࠨ฻ิฺࠬ婒"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ婓"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ婔")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ婕") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ婖"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ婗"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ婘") in title:
				title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ婙") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婚"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ婛"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ婜"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ婝"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ婞"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ婟"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠣࠤ婠"): continue
				if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ婡") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠪࠫ婢"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婣"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ婤")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ婥"),url,l1l111_l1_ (u"ࠧࠨ婦"),l1l111_l1_ (u"ࠨࠩ婧"),l1l111_l1_ (u"ࠩࠪ婨"),l1l111_l1_ (u"ࠪࠫ婩"),l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ婪"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡥࡢࡦ࠰ࡸ࡮ࡺ࡬ࡦࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠦࠬ婫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ婬"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ婭") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ婮"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ婯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ婰"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭婱"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠨ婲"): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ婳") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠧࠨ婴"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ婵"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ婶")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ婷"),url,l1l111_l1_ (u"ࠫࠬ婸"),l1l111_l1_ (u"ࠬ࠭婹"),l1l111_l1_ (u"࠭ࠧ婺"),l1l111_l1_ (u"ࠧࠨ婻"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ婼"))
	html = response.content
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡗࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ婽"),html,re.DOTALL)
	if l11l1l11l1_l1_:
		l11l1l11l1_l1_ = l11l1l11l1_l1_[0]
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ婾") not in l11l1l11l1_l1_:
			if l1l111_l1_ (u"ࠫ࠴࠵ࠧ婿") in l11l1l11l1_l1_: l11l1l11l1_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ媀")+l11l1l11l1_l1_
			else: l11l1l11l1_l1_ = l111l1_l1_+l11l1l11l1_l1_
		l11l1l11l1_l1_ = l11l1l11l1_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ媁")
		l1llll_l1_.append(l11l1l11l1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡣ࠳࠸࠾ࡧ࡫ࡦࡰࡴࡨࠬ࠳࠰࠿ࠪࡵࡰࡥࡱࡲ࠮ࠫࡁ࡚ࠥ࡮ࡪࡥࡰࡕࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩࠣࡒ࡯ࡥࡾࠨࠧ媂"),html,re.DOTALL)
	if l11llll_l1_:
		l11l1l1l1lll_l1_,l11l1l1ll111_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ媃"),l11l1l1l1lll_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡶࡩࡹ࡜ࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠣ媄"),l11l1l1ll111_l1_,re.DOTALL)
		l1l111lll1ll_l1_ = zip(names,l1ll_l1_)
		for name,l1l1111ll1ll_l1_ in l1l111lll1ll_l1_:
			l1l1111ll1ll_l1_ = l1l1111ll1ll_l1_[2:]
			if PY2: l1l1111ll1ll_l1_ = l1l1111ll1ll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ媅"))
			l1l1111ll1ll_l1_ = base64.b64decode(l1l1111ll1ll_l1_)
			if PY3: l1l1111ll1ll_l1_ = l1l1111ll1ll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ媆"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ媇"),l1l1111ll1ll_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ媈") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠧ࠰࠱ࠪ媉") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ媊")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ媋")+name+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ媌")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ媍"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"ࠬࠦࠧ媎") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ媏"),l1l111_l1_ (u"ࠧࠨ媐"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠠๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ媑"),l1l111_l1_ (u"ࠩ็่ศูแࠡษ็ฬาัࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠๅษࠣ๎฾๋ไࠡ฻้ำࠥ฽ไษࠢฦ็ะืࠠๆ่ࠣ็้๋ษ๊ࠡสัิฯࠠ࠯࠰࠱ࠤ๏ืฬ๊ࠢส่อำหࠡ฻้ࠤ่๊ๅส๋ࠢหาีษࠡใๅ฻ࠬ媒"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡶ࠵ࠧ媓")+search+l1l111_l1_ (u"ࠫ࠴࠭媔")
	l1lll11_l1_(url)
	return
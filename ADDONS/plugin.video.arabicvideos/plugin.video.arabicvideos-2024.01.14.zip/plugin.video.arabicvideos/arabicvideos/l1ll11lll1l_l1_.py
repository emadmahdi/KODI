# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ〺")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡌࡖࡎࡣࠬ〻")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ〼"),l1l111_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩ〽"),l1l111_l1_ (u"ࠩส่ศ่ำศ็ࠪ〾")]
def l11l1ll_l1_(mode,url,text):
	if   mode==670: l1lll_l1_ = l1l1l11_l1_()
	elif mode==671: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==672: l1lll_l1_ = PLAY(url)
	elif mode==673: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==674: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==679: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ〿"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ぀"),l1l111_l1_ (u"ࠬ࠭ぁ"),l1l111_l1_ (u"࠭ࠧあ"),l1l111_l1_ (u"ࠧࠨぃ"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬい"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩぅ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪう"),l1l111_l1_ (u"ࠫࠬぇ"),679,l1l111_l1_ (u"ࠬ࠭え"),l1l111_l1_ (u"࠭ࠧぉ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫお"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭か"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫが"),l1l111_l1_ (u"ࠪࠫき"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬぎ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧく"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			if title==l1l111_l1_ (u"࠭วๅลๅืฬ๋ࠧぐ"): mode = 675
			else: mode = 674
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧけ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪげ")+l1lllll_l1_+title,l1ll1ll_l1_,mode)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧこ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬご"),l1l111_l1_ (u"ࠫࠬさ"),9999)
	items = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡨࡲࡰࡹࡶࡩ࠳࡮ࡴ࡮࡮ࠪざ"))
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭し"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩじ")+l1lllll_l1_+title,l1ll1ll_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l1llllll11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭す"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫず"),l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧせ"))
	if l1llllll11_l1_: return l1llllll11_l1_
	l1llllll11_l1_ = []
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨぜ"),url,l1l111_l1_ (u"ࠬ࠭そ"),l1l111_l1_ (u"࠭ࠧぞ"),l1l111_l1_ (u"ࠧࠨた"),l1l111_l1_ (u"ࠨࠩだ"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠳ࡶࡸࠬち"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡨࡦࡣࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࡃ࠭ぢ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llllll11_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨっ"),block,re.DOTALL)
		if l1llllll11_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧつ"),l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪづ"),l1llllll11_l1_,l1ll1ll1_l1_)
	return l1llllll11_l1_
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫて"),url,l1l111_l1_ (u"ࠨࠩで"),l1l111_l1_ (u"ࠩࠪと"),l1l111_l1_ (u"ࠪࠫど"),l1l111_l1_ (u"ࠫࠬな"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬに"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪぬ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨね"),l1l111_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧの"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭は"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠪࠫば"),block)]
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩぱ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪひ"),l1l111_l1_ (u"࠭ࠧび"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬぴ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠨ࠼ࠣࠫふ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩぶ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧぷ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭へ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪべ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨぺ"),l1l111_l1_ (u"ࠧࠨほ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨぼ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠩࠪぽ")):
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨま"):
		url,search = url.split(l1l111_l1_ (u"ࠫࡄ࠭み"),1)
		data = l1l111_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫむ")+search
		headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬめ"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧも")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ゃ"),url,data,headers,l1l111_l1_ (u"ࠩࠪや"),l1l111_l1_ (u"ࠪࠫゅ"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪゆ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩょ"),url,l1l111_l1_ (u"࠭ࠧよ"),l1l111_l1_ (u"ࠧࠨら"),l1l111_l1_ (u"ࠨࠩり"),l1l111_l1_ (u"ࠩࠪる"),l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩれ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠫࠬろ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩゎ"))
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫわ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩゐ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩゑ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫを"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫん"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪゔ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬゕ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪゖ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ゗"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ゘"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁ゙ࠫ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ゚ࠬ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬ゛"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭゜"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧゝ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧゞ"),l1l111_l1_ (u"ࠨใํ่๊࠭ゟ"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ゠"),l1l111_l1_ (u"ࠪ็้๐ศࠨァ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪア"),l1l111_l1_ (u"ࠬํฯศใࠪィ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭イ"),l1l111_l1_ (u"ฺࠧำูࠫゥ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨウ"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨェ"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪエ"),l1l111_l1_ (u"ࠫๆ๊ๅࠨォ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨオ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬカ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ガ"):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧキ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨギ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪク"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩグ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬケ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ゲ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨコ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ゴ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫサ"): continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨザ") not in l1ll1ll_l1_:
				l1lllll1_l1_ = url.rsplit(l1l111_l1_ (u"ࠫ࠴࠭シ"),1)[0]
				l1ll1ll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧジ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨス"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧズ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧセ")+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠩࠪゼ"),l1l111_l1_ (u"ࠪࠫソ"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪゾ"),l1lllll_l1_+l1l111_l1_ (u"ࠬะิ฻์็ࠤฬ๊แ๋ัํ์ࠬタ"),url,672)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫダ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩチ"),l1l111_l1_ (u"ࠨࠩヂ"),9999)
	l1llllll11_l1_ = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࡥࡶࡴࡽࡳࡦ࠰࡫ࡸࡲࡲࠧッ"))
	l1ll11ll1l1_l1_,l1ll11lll11_l1_,l1ll11ll1ll_l1_ = zip(*l1llllll11_l1_)
	l1ll11llll1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧツ"),url,l1l111_l1_ (u"ࠫࠬヅ"),l1l111_l1_ (u"ࠬ࠭テ"),l1l111_l1_ (u"࠭ࠧデ"),l1l111_l1_ (u"ࠧࠨト"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩド"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯࡫ࡩࡦࡪࡩ࡯ࡩࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠭ナ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡾࡈࡵࡵࡶࡲࡲࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡦࡃ࠮࠮ࠫࡁࠬࡀࠬニ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1ll11ll1l1_l1_:
				item = (l1ll1ll_l1_,title)
				l1ll11llll1_l1_.append(item)
		if len(l1ll11llll1_l1_)==1:
			l1ll1ll_l1_,title = l1ll11llll1_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪヌ"))
			return
		else:
			for l1ll1ll_l1_,title in l1ll11llll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬネ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1l111_l1_ (u"࠭ࠧノ"),l1l111_l1_ (u"ࠧࠨハ"),l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧバ"))
	if not l1ll11llll1_l1_: l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨパ"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧヒ"),url,l1l111_l1_ (u"ࠫࠬビ"),l1l111_l1_ (u"ࠬ࠭ピ"),l1l111_l1_ (u"࠭ࠧフ"),l1l111_l1_ (u"ࠧࠨブ"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬプ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪࡨ࡯ࡥࡸ࡮ࡰ࡭ࡣࡼࡩࡷ࠭ヘ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ベ"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࡤࡥࠧペ")+l111l1ll_l1_
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨホ"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡪ࡮ࡨ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨボ"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬポ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧマ")+l1ll1ll_l1_
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪミ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩム"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬメ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭モ"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨャ"),l1l111_l1_ (u"ࠧࠬࠩヤ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨュ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩユ"))
	return
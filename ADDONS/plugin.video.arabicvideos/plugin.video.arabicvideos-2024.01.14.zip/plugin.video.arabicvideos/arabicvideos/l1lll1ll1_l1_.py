# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩఫ")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧబ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1llll1l1_l1_ = [l1l111_l1_ (u"ࠩ࠴࠶࠸࠿ࠧభ"),l1l111_l1_ (u"ࠪ࠵࠷࠻࠰ࠨమ"),l1l111_l1_ (u"ࠫ࠶࠸࠴࠶ࠩయ"),l1l111_l1_ (u"ࠬ࠸࠰ࠨర"),l1l111_l1_ (u"࠭࠱࠳࠷࠼ࠫఱ"),l1l111_l1_ (u"ࠧ࠳࠳࠻ࠫల"),l1l111_l1_ (u"ࠨ࠶࠻࠹ࠬళ"),l1l111_l1_ (u"ࠩ࠴࠶࠸࠾ࠧఴ"),l1l111_l1_ (u"ࠪ࠵࠷࠻࠸ࠨవ"),l1l111_l1_ (u"ࠫ࠷࠿࠲ࠨశ")]
l1llll11l_l1_ = [l1l111_l1_ (u"ࠬ࠹࠰࠴࠲ࠪష"),l1l111_l1_ (u"࠭࠶࠳࠺ࠪస")]
def l11l1ll_l1_(mode,url,text):
	if   mode==60: l1lll_l1_ = l1l1l11_l1_()
	elif mode==61: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==62: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==63: l1lll_l1_ = PLAY(url)
	elif mode==64: l1lll_l1_ = l1llll1ll_l1_(text)
	elif mode==69: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧహ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ఺"),l1l111_l1_ (u"ࠩࠪ఻"),69,l1l111_l1_ (u"఼ࠪࠫ"),l1l111_l1_ (u"ࠫࠬఽ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩా"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ి"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩీ")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็สࠤ๏ะๅࠡ็ืห์ีส่ࠢส่ฬ์ࠧు"),l111l1_l1_,64,l1l111_l1_ (u"ࠩࠪూ"),l1l111_l1_ (u"ࠪࠫృ"),l1l111_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡣࡻ࡯ࡥࡸࡧࡧࡣࡻ࡯ࡤࡴࠩౄ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ౅"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨె")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆส็ะืࠠๆึส๋ิฯࠧే"),l111l1_l1_,64,l1l111_l1_ (u"ࠨࠩై"),l1l111_l1_ (u"ࠩࠪ౉"),l1l111_l1_ (u"ࠪࡱࡴࡹࡴࡠࡸ࡬ࡩࡼ࡫ࡤࡠࡸ࡬ࡨࡸ࠭ొ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫో"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧౌ")+l1lllll_l1_+l1l111_l1_ (u"࠭วื์ไฮ๋ࠥฤฯำส్ࠫ"),l111l1_l1_,64,l1l111_l1_ (u"ࠧࠨ౎"),l1l111_l1_ (u"ࠨࠩ౏"),l1l111_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵ࡮ࡼࡣࡦࡪࡤࡦࡦࡢࡺ࡮ࡪࡳࠨ౐"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ౑"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭౒")+l1lllll_l1_+l1l111_l1_ (u"ࠬ็๊ะ์๋ࠤ฾ฺ่ศศํࠫ౓"),l111l1_l1_,64,l1l111_l1_ (u"࠭ࠧ౔"),l1l111_l1_ (u"ࠧࠨౕ"),l1l111_l1_ (u"ࠨࡴࡤࡲࡩࡵ࡭ࡠࡸ࡬ࡨࡸౖ࠭"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ౗"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬౘ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣ์ู๊ไิๆสฮࠬౙ"),l111l1_l1_,61,l1l111_l1_ (u"ࠬ࠭ౚ"),l1l111_l1_ (u"࠭ࠧ౛"),l1l111_l1_ (u"ࠧ࠮࠳ࠪ౜"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨౝ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ౞")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊ฯ๋่ํอࠬ౟"),l111l1_l1_,61,l1l111_l1_ (u"ࠫࠬౠ"),l1l111_l1_ (u"ࠬ࠭ౡ"),l1l111_l1_ (u"࠭࠭࠳ࠩౢ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧౣ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ౤")+l1lllll_l1_+l1l111_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪ࡚ࠣ࡮ࡪࡥࡰࡵࠪ౥"),l111l1_l1_,61,l1l111_l1_ (u"ࠪࠫ౦"),l1l111_l1_ (u"ࠫࠬ౧"),l1l111_l1_ (u"ࠬ࠳࠳ࠨ౨"))
	return l1l111_l1_ (u"࠭ࠧ౩")
def l1lll11_l1_(url,category):
	cat = l1l111_l1_ (u"ࠧࠨ౪")
	if category not in [l1l111_l1_ (u"ࠨ࠯࠴ࠫ౫"),l1l111_l1_ (u"ࠩ࠰࠶ࠬ౬"),l1l111_l1_ (u"ࠪ࠱࠸࠭౭")]: cat = l1l111_l1_ (u"ࠫࡄࡩࡡࡵ࠿ࠪ౮")+category
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡦࡰࡸࡣࡱ࡫ࡶࡦ࡮࠱ࡴ࡭ࡶࠧ౯")+cat
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ౰"),l1l111_l1_ (u"ࠧࠨ౱"),l1l111_l1_ (u"ࠨࠩ౲"),l1l111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ౳"))
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ౴"),html,re.DOTALL)
	l1lll1lll_l1_,found = False,False
	for l1ll1ll_l1_,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭౵"))
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ౶") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ౷")+l1ll1ll_l1_
		cat = re.findall(l1l111_l1_ (u"ࠧࡤࡣࡷࡁ࠭࠴ࠪࡀࠫࠩࠫ౸"),l1ll1ll_l1_,re.DOTALL)[0]
		if category==cat: l1lll1lll_l1_ = True
		elif l1lll1lll_l1_ 	or (category==l1l111_l1_ (u"ࠨ࠯࠴ࠫ౹") and cat in l1llll1l1_l1_) \
						or (category==l1l111_l1_ (u"ࠩ࠰࠶ࠬ౺") and cat not in l1llll11l_l1_ and cat not in l1llll1l1_l1_) \
						or (category==l1l111_l1_ (u"ࠪ࠱࠸࠭౻") and cat in l1llll11l_l1_):
							if count==l1l111_l1_ (u"ࠫ࠶࠭౼"): addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ౽"),l1lllll_l1_+title,l1ll1ll_l1_,63)
							else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౾"),l1lllll_l1_+title,l1ll1ll_l1_,61,l1l111_l1_ (u"ࠧࠨ౿"),l1l111_l1_ (u"ࠨࠩಀ"),cat)
							found = True
	if not found: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪಁ"),l1l111_l1_ (u"ࠪࠫಂ"),True,l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬಃ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡪࡴࡵࡴࡦࡴࠪ಄"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡧࡳ࡫ࡧࡣࡻ࡯ࡥࡸ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫಅ"),block,re.DOTALL)
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࠨಆ")
	for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
		title = title.replace(l1l111_l1_ (u"ࠨࡃࡧࡨࠬಇ"),l1l111_l1_ (u"ࠩࠪಈ")).replace(l1l111_l1_ (u"ࠪࡸࡴࠦࡑࡶ࡫ࡦ࡯ࡱ࡯ࡳࡵࠩಉ"),l1l111_l1_ (u"ࠫࠬಊ")).strip(l1l111_l1_ (u"ࠬࠦࠧಋ"))
		if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫಌ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭಍")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧಎ"),l1lllll_l1_+title,l1ll1ll_l1_,63,l1ll1l_l1_)
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫಏ"),block,re.DOTALL)
	block=l11llll_l1_[0]
	block=re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫಐ"),html,re.DOTALL)[0]
	items=re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭಑"),block,re.DOTALL)
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠬࡅࠧಒ"))[0]
	for l1ll1ll_l1_,l1lll1l1l_l1_ in items:
		l1ll1ll_l1_ = l1lllll1_l1_ + l1ll1ll_l1_
		title = unescapeHTML(l1lll1l1l_l1_)
		title = l1l111_l1_ (u"࠭ีโฯฬࠤࠬಓ") + title
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧಔ"),l1lllll_l1_+title,l1ll1ll_l1_,62)
	return l1ll1ll_l1_
def PLAY(url):
	if l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࠬಕ") in url: url = l1ll1l11_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪಖ"),l1l111_l1_ (u"ࠪࠫಗ"),True,l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨಘ"))
	items = re.findall(l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬಙ"),html,re.DOTALL)
	url = items[0]
	if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫಚ") not in url: url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ಛ")+url
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧಜ"))
	return
def l1llll1ll_l1_(category):
	payload = { l1l111_l1_ (u"ࠩࡰࡳࡩ࡫ࠧಝ") : category }
	url = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶ࠰ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࠪಞ")
	headers = { l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪಟ") : l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫಠ") }
	data = l1lllll11_l1_(payload)
	html = l1l1llll_l1_(l111l11l_l1_,url,data,headers,True,l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉ࠮ࡏࡒࡗ࡙࡙࠭࠲ࡵࡷࠫಡ"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦࠨಢ"),html,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪಣ"))
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧತ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩಥ")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪದ"),l1lllll_l1_+title,l1ll1ll_l1_,63,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭ಧ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧನ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ಩"),l1l111_l1_ (u"ࠨ࠭ࠪಪ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡢࡶࡪࡹࡵ࡭ࡶ࠱ࡴ࡭ࡶ࠿ࡲࡷࡨࡶࡾࡃࠧಫ") + l1lll1ll_l1_
	l1ll1l11_l1_(url)
	return
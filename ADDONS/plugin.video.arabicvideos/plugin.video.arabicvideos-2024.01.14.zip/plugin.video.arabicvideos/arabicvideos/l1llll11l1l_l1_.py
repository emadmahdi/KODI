# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ⫝")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡆࡔࡖࡢࠫ⫞")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨ⫟"),l1l111_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨ⫠"),l1l111_l1_ (u"ࠨฬฯ๋๏ุࠠศๆะ่็อสࠡษ็ๆฬีๅสࠩ⫡")]
def l11l1ll_l1_(mode,url,text):
	if   mode==600: l1lll_l1_ = l1l1l11_l1_()
	elif mode==601: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==602: l1lll_l1_ = PLAY(url)
	elif mode==603: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==604: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==609: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⫢"),l111l1_l1_,l1l111_l1_ (u"ࠪࡪࡴࡹࡴࡢࠩ⫣"),l1l111_l1_ (u"ࠫๆ๎ำหษࠣࡪࡴࡹࡴࡢࠩ⫤"),l1l111_l1_ (u"ࠬ࡬࡯ࡴࡶࡤ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ⫥"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⫦"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⫧"),l1l111_l1_ (u"ࠨࠩ⫨"),609,l1l111_l1_ (u"ࠩࠪ⫩"),l1l111_l1_ (u"ࠪࠫ⫪"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⫫"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⫬"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⫭"),l1l111_l1_ (u"ࠧࠨ⫮"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⫯"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⫰")+l1lllll_l1_+l1l111_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ⫱"),l1l11ll_l1_,601,l1l111_l1_ (u"ࠫࠬ⫲"),l1l111_l1_ (u"ࠬ࠭⫳"),l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⫴"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⫵"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⫶")+l1lllll_l1_+l1l111_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ⫷"),l1l11ll_l1_,601,l1l111_l1_ (u"ࠪࠫ⫸"),l1l111_l1_ (u"ࠫࠬ⫹"),l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ⫺"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⫻"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⫼")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ⫽"),l1l11ll_l1_,601,l1l111_l1_ (u"ࠩࠪ⫾"),l1l111_l1_ (u"ࠪࠫ⫿"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⬀"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⬁"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⬂"),l1l111_l1_ (u"ࠧࠨ⬃"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⬄"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ⬅"),l1l111_l1_ (u"ࠪࠫ⬆"),l1l111_l1_ (u"๊ࠫ๎โฺࠢไ์ุะวࠨ⬇"),l1l111_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ๏าวะࠢ฼๊ํอๆࠡษ็้ํู่ࠡล๋ࠤฯ฻ๅ๋็ࠣห้๋่ใ฻ࠣฮ฿๐ัࠨ⬈"))
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⬉"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⬊"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⬋")+l1lllll_l1_+title,l1ll1ll_l1_,604)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭⬌"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ⬍"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠫࠬ⬎"))
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⬏"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⬐"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⬑")+l1lllll_l1_+title,l1ll1ll_l1_,604)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⬒"),url,l1l111_l1_ (u"ࠩࠪ⬓"),l1l111_l1_ (u"ࠪࠫ⬔"),l1l111_l1_ (u"ࠫࠬ⬕"),l1l111_l1_ (u"ࠬ࠭⬖"),l1l111_l1_ (u"࠭ࡆࡐࡕࡗࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⬗"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⬘"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ⬙"),l1l111_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ⬚"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⬛"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠫࠬ⬜"),block)]
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⬝"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⬞"),l1l111_l1_ (u"ࠧࠨ⬟"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⬠"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠩ࠽ࠤࠬ⬡")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⬢"),l1lllll_l1_+title,l1ll1ll_l1_,601)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⬣"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⬤"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⬥"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⬦"),l1l111_l1_ (u"ࠨࠩ⬧"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⬨"),l1lllll_l1_+title,l1ll1ll_l1_,601)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠪࠫ⬩")):
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ⬪"):
		url,search = url.split(l1l111_l1_ (u"ࠬࡅࠧ⬫"),1)
		data = l1l111_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ⬬")+search
		headers = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⬭"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ⬮")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⬯"),url,data,headers,l1l111_l1_ (u"ࠪࠫ⬰"),l1l111_l1_ (u"ࠫࠬ⬱"),l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⬲"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⬳"),url,l1l111_l1_ (u"ࠧࠨ⬴"),l1l111_l1_ (u"ࠨࠩ⬵"),l1l111_l1_ (u"ࠩࠪ⬶"),l1l111_l1_ (u"ࠪࠫ⬷"),l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⬸"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠬ࠭⬹"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ⬺"))
	if request==l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ⬻"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⬼"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠩࠪ⬽"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ⬾"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⬿"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⭀"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⭁"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ⭂"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⭃"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ⭄"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ⭅"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⭆"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠬ࠭⭇"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⭈"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⭉"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ⭊"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ⭋"),l1l111_l1_ (u"ࠪห฿์๊สࠩ⭌"),l1l111_l1_ (u"่๊๊ࠫษࠩ⭍"),l1l111_l1_ (u"ࠬอูๅษ้ࠫ⭎"),l1l111_l1_ (u"࠭็ะษไࠫ⭏"),l1l111_l1_ (u"ࠧๆสสีฬฯࠧ⭐"),l1l111_l1_ (u"ࠨ฻ิฺࠬ⭑"),l1l111_l1_ (u"่๋ࠩึาว็ࠩ⭒"),l1l111_l1_ (u"ࠪห้ฮ่ๆࠩ⭓"),l1l111_l1_ (u"ู๊ࠫัฮ์ฬࠫ⭔")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ⭕"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⭖"),l1lllll_l1_+title,l1ll1ll_l1_,602,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭⭗"):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⭘"),l1lllll_l1_+title,l1ll1ll_l1_,602,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⭙") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭚"),l1lllll_l1_+title,l1ll1ll_l1_,603,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭛"),l1lllll_l1_+title,l1ll1ll_l1_,603,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⭜"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⭝"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ⭞"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ⭟")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ⭠"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭡"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⭢")+title,l1ll1ll_l1_,601)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ⭣"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⭤"),url,l1l111_l1_ (u"ࠧࠨ⭥"),l1l111_l1_ (u"ࠨࠩ⭦"),l1l111_l1_ (u"ࠩࠪ⭧"),l1l111_l1_ (u"ࠪࠫ⭨"),l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ⭩"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ⭪"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⭫"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ⭬")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࠩࠪࡳࡳࡩ࡬ࡪࡥ࡮ࡁࠧࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ⭭"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠩࠦࠫ⭮"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭯"),l1lllll_l1_+title,url,603,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ⭰"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ⭱")+l1l11_l1_+l1l111_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⭲"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄ࠼࡭࡫ࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨ⭳"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⭴"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ⭵")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ⭶"))
			title = title.replace(l1l111_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ⭷"),l1l111_l1_ (u"ࠬࠦࠧ⭸"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⭹"),l1lllll_l1_+title,l1ll1ll_l1_,602,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l11ll11lll_l1_ = [],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ⭺"),l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪ⭻"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⭼"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⭽"),l1l111_l1_ (u"ࠫࠬ⭾"),l1l111_l1_ (u"ࠬ࠭⭿"),l1l111_l1_ (u"࠭ࠧ⮀"),l1l111_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⮁"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⮂"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ⮃"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ⮄"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⮅")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⮆")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⮇"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l11ll11lll_l1_:
			l11ll11lll_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ⮈"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⮉")+server+l1l111_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ⮊")
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭⮋"),l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪ⮌"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⮍"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⮎"),l1l111_l1_ (u"ࠧࠨ⮏"),l1l111_l1_ (u"ࠨࠩ⮐"),l1l111_l1_ (u"ࠩࠪ⮑"),l1l111_l1_ (u"ࠪࡊࡔ࡙ࡔࡂ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ⮒"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⮓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ⮔"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ⮕"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⮖")+server+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⮗")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⮘"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ⮙"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ⮚"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⮛"),l1l111_l1_ (u"࠭ࠫࠨ⮜"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ⮝")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⮞"),url,l1l111_l1_ (u"ࠩࡩࡳࡸࡺࡡࠨ⮟"),l1l111_l1_ (u"ࠪๅํูสศࠢࡩࡳࡸࡺࡡࠨ⮠"),l1l111_l1_ (u"ࠫ࡫ࡵࡳࡵࡣ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪ⮡"))
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⮢"))
	return
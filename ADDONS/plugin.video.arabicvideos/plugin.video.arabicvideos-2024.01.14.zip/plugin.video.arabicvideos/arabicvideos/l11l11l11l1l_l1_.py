# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ庰")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭庱")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l11l1l1l11l1_l1_(url)
	elif mode==146: l1lll_l1_ = l11l111lll11_l1_(url)
	elif mode==147: l1lll_l1_ = l11l1l1111ll_l1_()
	elif mode==148: l1lll_l1_ = l11l1l111l1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ庲"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ庳"),l1l111_l1_ (u"ࠪࠫ庴"),149,l1l111_l1_ (u"ࠫࠬ庵"),l1l111_l1_ (u"ࠬ࠭庶"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ康"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ庸"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ庹")+l1l111_l1_ (u"ࠩࡢ࡝࡙ࡉ࡟ࠨ庺")+l1l111_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣห้๋ศา็ฯࠫ庻"),l1l111_l1_ (u"ࠫࠬ庼"),290)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ庽"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ庾")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊สๆ฾ࠦวฯฬสี์อ๋๊ࠠอ๎ํฮࠧ庿"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ廀"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廁"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廂")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭廃"),l111l1_l1_,144,l1l111_l1_ (u"ࠬ࠭廄"),l1l111_l1_ (u"࠭ࠧ廅"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ廆"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廇"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廈")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋อห๊์ࠤฬ๊ัศศฯࠫ廉"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ廊"),146)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ廋"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ廌"),l1l111_l1_ (u"ࠧࠨ廍"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廎"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廏")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะฺࠠำห๎ฮ࠭廐"),l1l111_l1_ (u"ࠫࠬ廑"),147)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廒"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廓")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ廔"),l1l111_l1_ (u"ࠨࠩ廕"),148)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廖"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廗")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡ฻ิฬ๏ฯࠧ廘"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃแ๋ๆ่ࠫ廙"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廚"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廛")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥอฬ็สํอࠬ廜"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡱࡴࡼࡩࡦࠩ廝"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廞"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廟")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้ࠣือ๋ษอࠤ฾ืศ๋หࠪ廠"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆีิั๏ฯࠧ廡"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廢"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廣")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ廤"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ廥"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廦"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廧")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥอฬ็สํอࠬ廨"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡵࡨࡶ࡮࡫ࡳࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭廩"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廪"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廫")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢๆหึะ่็ࠩ廬"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ้วาฬ๋๊ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ廭"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廮"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廯")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ廰"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ廱"),144)
	return
def l11l1l1111ll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬสฮࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ廲"))
	return
def l11l1l111l1l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡹࡼࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ廳"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l111lll11_l1_(url):
	html,l1llll1lll_l1_,data = l11l11llllll_l1_(url)
	dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭廴")][l1l111_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ廵")][l1l111_l1_ (u"࠭ࡴࡢࡤࡶࠫ延")]
	for l1l111llll_l1_ in range(len(dd)):
		item = dd[l1l111llll_l1_]
		l11l11l1llll_l1_(item,url,str(l1l111llll_l1_))
	l11l11l111ll_l1_ = dd[0][l1l111_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ廷")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ廸")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ廹")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ建")]
	s = 0
	for l1l111llll_l1_ in range(len(l11l11l111ll_l1_)):
		item = l11l11l111ll_l1_[l1l111llll_l1_][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ廻")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ廼")][0]
		if list(item[l1l111_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廽")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ廾")].keys())[0]==l1l111_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ廿"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_ = l11l1l1l1ll1_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤึอฦอหࠣࠫ开")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弁"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠫࠬ异"),str(l1l111llll_l1_))
	key = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ弃"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ弄")+key[0]
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11llllll_l1_(l1lllll1_l1_)
	for l1lllll11ll1_l1_ in range(3,4):
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡸ࠭弅")][l1lllll11ll1_l1_][l1l111_l1_ (u"ࠨࡩࡸ࡭ࡩ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ弆")][l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ弇")]
		for l1l111llll_l1_ in range(len(dd)):
			item = dd[l1l111llll_l1_]
			if l1l111_l1_ (u"ࠪ࡝ࡴࡻࡔࡶࡤࡨࠤࡕࡸࡥ࡮࡫ࡸࡱࠬ弈") in str(item): continue
			l11l11l1llll_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠫࠬ弉"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ弊"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ弋"),l1l111_l1_ (u"ࠧࠨ弌"))
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l11llllll_l1_(url,data)
	l1l11ll11l_l1_,l11l111ll1l1_l1_ = l1l111_l1_ (u"ࠨࠩ弍"),l1l111_l1_ (u"ࠩࠪ弎")
	owner = re.findall(l1l111_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ式"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡓࡼࡴࡥࡳࠤ࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ弐"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ弑"),html,re.DOTALL)
	if owner:
		l1l11ll11l_l1_ = l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ弒")+owner[0][0]+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ弓")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭弔") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ引") in url: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弖"),l1lllll_l1_+l1l11ll11l_l1_,l1ll1ll_l1_,144)
	l11l11l11111_l1_ = [l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ弗"),l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭弘"),l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ弙"),l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ弚"),l1l111_l1_ (u"ࠨ࠱ࡩࡩࡦࡺࡵࡳࡧࡧࠫ弛"),l1l111_l1_ (u"ࠩࡶࡷࡂ࠭弜"),l1l111_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ弝"),l1l111_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ弞"),l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ弟"),l1l111_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ张")]
	l11l111ll11l_l1_ = not any(value in url for value in l11l11l11111_l1_)
	if l11l111ll11l_l1_ and l1l11ll11l_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠧศๆหัะ࠭弡")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠨไ๋หห๋ࠠศๆอุ฿๐ไࠨ弢")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯ࠭弣")
		l11l111ll1ll_l1_ = l1l111_l1_ (u"ࠪห้่ๆ้ษอࠫ弤")
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ弥"),l1lllll_l1_+l1l11ll11l_l1_,url,9999)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢษฯฮࠦࠬ弦") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弧"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠧࠨ弨"),l1l111_l1_ (u"ࠨࠩ弩"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭弪"))
		if l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭弫") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弬"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ弭"),144)
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭弮") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弯"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ弰"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊โ็๊สฮࠧ࠭弱") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弲"),l1lllll_l1_+l11l111ll1ll_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ弳"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡔࡧࡤࡶࡨ࡮ࠢࠨ弴") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭張"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠧࠨ弶"),l1l111_l1_ (u"ࠨࠩ強"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭弸"))
		if l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ弹") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ强"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ弻"),144)
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ弼") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弽"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ弾"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ弿") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彀"),l1lllll_l1_+l11l111ll1ll_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ彁"),144)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ彂"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ彃"),l1l111_l1_ (u"ࠧࠨ彄"),9999)
	if l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ彅") in url:
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ彆")][l1l111_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彇")][l1l111_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭彈")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ彉")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ彊")]
		l11l111l1lll_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彋") in list(dd[i].keys()):
				l11l111l1ll1_l1_ = dd[i][l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彌")]
				length = len(str(l11l111l1ll1_l1_))
				if length>l11l111l1lll_l1_:
					l11l111l1lll_l1_ = length
					l11l111ll1l1_l1_ = l11l111l1ll1_l1_
		if l11l111l1lll_l1_==0: return
	elif l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ彍") in url or l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ彎") in url or l1l111_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ彏") in url or l1l111_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭彐") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ彑") in url or url==l111l1_l1_:
		l11l11l1lll1_l1_ = []
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ归"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ当"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ彔"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ录"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ彖"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠭࠲࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ彗"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ彘"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲ࡜ࡧࡴࡤࡪࡑࡩࡽࡺࡒࡦࡵࡸࡰࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࠧ彙"))
		l11l111lllll_l1_,l11l111ll1l1_l1_ = l11l111l1l1l_l1_(l1llll1lll_l1_,l1l111_l1_ (u"ࠨࠩ彚"),l11l11l1lll1_l1_)
	if not l11l111ll1l1_l1_:
		try:
			dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ彛")][l1l111_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彜")][l1l111_l1_ (u"ࠫࡹࡧࡢࡴࠩ彝")]
			l1lllllllll1_l1_ = l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭彞") in url or l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ彟") in url or l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ彠") in url
			l11l11l1l111_l1_ = l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ彡") in html or l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ็๎วว็ࠣห้ะิ฻์็ࠦࠬ形") in html or l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ彣") in html
			l11l11l11lll_l1_ = l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ彤") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ彥") in html or l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥࠫ彦") in html
			if l1lllllllll1_l1_ and (l11l11l1l111_l1_ or l11l11l11lll_l1_):
				for l1l111llll_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ彧") not in list(dd[l1l111llll_l1_].keys()): continue
					l11l11l111ll_l1_ = dd[l1l111llll_l1_][l1l111_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彨")]
					try: l11l111llll1_l1_ = l11l11l111ll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ彩")][l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ彪")][l1l111_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ彫")][l1l111_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彬")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩ彭")][l1l111llll_l1_]
					except: l11l111llll1_l1_ = l11l11l111ll_l1_
					try: l1ll1ll_l1_ = l11l111llll1_l1_[l1l111_l1_ (u"ࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩ彮")][l1l111_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ彯")][l1l111_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ彰")][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ影")]
					except: continue
					if   l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ彲")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭彳")		in url: l11l11l111ll_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ彴")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ彵")	in url: l11l11l111ll_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ彶")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ彷")		in url: l11l11l111ll_l1_ = dd[l1l111llll_l1_] ; break
					else: l11l11l111ll_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠪࡦࡵࡃࠧ彸") in url: l11l11l111ll_l1_ = dd[index]
			else: l11l11l111ll_l1_ = dd[0]
			l11l111ll1l1_l1_ = l11l11l111ll_l1_[l1l111_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ役")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭彺")]
		except: pass
	if not l11l111ll1l1_l1_: return
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ彻"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ彼"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ彽"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ彾"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ彿"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ往"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ征"))
	if l1l111_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ徂") not in url: l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡶࡤࡐࡩࡳࡻࠧ࡞࡝ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫࡢࠨ徃"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ径"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ待"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ徆"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ徇"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ很"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ徉"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ徊"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ律"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࠧ後"))
	l11l1l11ll1_l1_ = l111lllllll_l1_(l1l111_l1_ (u"ࡸ่๊ࠫࠠใ๊สส๊ࠦวๅฬื฾๏๊ࠧ徍"))
	l11l11l11ll_l1_ = l111lllllll_l1_(l1l111_l1_ (u"ࡹ้ࠬไࠡษ็ๅ๏ี๊้้สฮࠬ徎"))
	l11l111lll1l_l1_ = l111lllllll_l1_(l1l111_l1_ (u"ࡺ࠭ใๅࠢส่็์่ศฬࠪ徏"))
	l1l1ll1lll1l_l1_ = [l11l1l11ll1_l1_,l11l11l11ll_l1_,l11l111lll1l_l1_,l1l111_l1_ (u"࠭ࡁ࡭࡮ࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭徐"),l1l111_l1_ (u"ࠧࡂ࡮࡯ࠤࡻ࡯ࡤࡦࡱࡶࠫ徑"),l1l111_l1_ (u"ࠨࡃ࡯ࡰࠥࡩࡨࡢࡰࡱࡩࡱࡹࠧ徒")]
	l11l11l1111l_l1_,l11l111llll1_l1_ = l11l111l1l1l_l1_(l11l111ll1l1_l1_,index,l11l11l1lll1_l1_)
	if l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ従") in str(type(l11l111llll1_l1_)) and any(value in str(l11l111llll1_l1_[0]) for value in l1l1ll1lll1l_l1_): del l11l111llll1_l1_[0]
	for index2 in range(len(l11l111llll1_l1_)):
		l11l11l1lll1_l1_ = []
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ徔"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ徕"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ徖"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ得"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ徘"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ徙"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ徚"))
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣࠢ徛"))
		l11l111lllll_l1_,item = l11l111l1l1l_l1_(l11l111llll1_l1_,index2,l11l11l1lll1_l1_)
		l11l11l1llll_l1_(item,url,str(index2))
		if l11l111lllll_l1_==l1l111_l1_ (u"ࠫ࠹࠭徜"):
			try:
				hh = item[l1l111_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ徝")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ從")][l1l111_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ徟")][l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ徠")]
				for l11l11ll1lll_l1_ in range(len(hh)):
					l1l1lll1llll_l1_ = hh[l11l11ll1lll_l1_]
					l11l11l1llll_l1_(l1l1lll1llll_l1_)
			except: pass
	l111llllll_l1_ = False
	if l1l111_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ御") not in url and l11l11l1111l_l1_==l1l111_l1_ (u"ࠪ࠼ࠬ徢"): l111llllll_l1_ = True
	if l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ徣") in l1l11llll_l1_: l11l1l11l11l_l1_,key,l11l111ll111_l1_,l11l1l111l11_l1_,token,l11l1l11111l_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ徤"))
	else: l11l1l11l11l_l1_,key,l11l111ll111_l1_,l11l1l111l11_l1_,token,l11l1l11111l_l1_ = l1l111_l1_ (u"࠭ࠧ徥"),l1l111_l1_ (u"ࠧࠨ徦"),l1l111_l1_ (u"ࠨࠩ徧"),l1l111_l1_ (u"ࠩࠪ徨"),l1l111_l1_ (u"ࠪࠫ復"),l1l111_l1_ (u"ࠫࠬ循")
	l1lllll1_l1_,l111l1llll_l1_ = l1l111_l1_ (u"ࠬ࠭徫"),l1l111_l1_ (u"࠭ࠧ徬")
	if menuItemsLIST:
		l11l11l11ll1_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠧࡄࡊࡑࡐࠬ徭") in l11l11l11ll1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ微")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠩࡘࡗࡊࡘࠧ徯") in l11l11l11ll1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ徰")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠫࡑࡏࡓࡕࠩ徱") in l11l11l11ll1_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠬࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ徲")
	if l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡹࠢࠨ徳") in html and l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ徴") not in url and not l111llllll_l1_ and l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࠪ徵") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࡢࡥ࡯ࡧࡸࡀࡥࡷࡳࡰ࡫࡮࠾ࠩ徶")+l11l111ll111_l1_
	elif l1l111_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥࠫ德") in html and l1l111_l1_ (u"ࠫࡧࡶ࠽ࠨ徸") not in url and l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ徹") in url or l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ徺") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ徻")+key
	elif l1l111_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣࠩ徼") in html and l1l111_l1_ (u"ࠩࡥࡴࡂ࠭徽") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࡁ࡮ࡩࡾࡃࠧ徾")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徿"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ忀"),l1lllll1_l1_,144,l111l1llll_l1_,l1l111_l1_ (u"࠭ࠧ忁"),l1l11llll_l1_)
	return
def l11l111l1l1l_l1_(l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l11l11ll1l11_l1_):
	l1llll1lll_l1_ = l1ll1111l1ll_l1_
	l11l111ll1l1_l1_,index = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	l11l111llll1_l1_,index2 = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	item,l11l11l11l11_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	count = len(l11l11ll1l11_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l11ll1l11_l1_[l1l111llll_l1_])
			return str(l1l111llll_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠧࠨ忂"),l1l111_l1_ (u"ࠨࠩ心")
def l11l1l1l1ll1_l1_(item):
	try: l11l1l1111l1_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠩࠪ忄"),l1l111_l1_ (u"ࠪࠫ必"),l1l111_l1_ (u"ࠫࠬ忆"),l1l111_l1_ (u"ࠬ࠭忇"),l1l111_l1_ (u"࠭ࠧ忈"),l1l111_l1_ (u"ࠧࠨ忉"),l1l111_l1_ (u"ࠨࠩ忊")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_ = False,l1l111_l1_ (u"ࠩࠪ忋"),l1l111_l1_ (u"ࠪࠫ忌"),l1l111_l1_ (u"ࠫࠬ忍"),l1l111_l1_ (u"ࠬ࠭忎"),l1l111_l1_ (u"࠭ࠧ忏"),l1l111_l1_ (u"ࠧࠨ忐"),l1l111_l1_ (u"ࠨࠩ忑")
	l11l11l11l11_l1_ = item[l11l1l1111l1_l1_]
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡹࡳࡶ࡬ࡢࡻࡤࡦࡱ࡫ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ忒"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࡔࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ忓"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ忔"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ忕"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ忖"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ志"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ忘"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ忙"))
	l11l111lllll_l1_,title = l11l111l1l1l_l1_(item,l11l11l11l11_l1_,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ忚"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ忛"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ応"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ忝"))
	l11l111lllll_l1_,l1ll1ll_l1_ = l11l111l1l1l_l1_(item,l11l11l11l11_l1_,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ忞"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ忟"))
	l11l111lllll_l1_,l1ll1l_l1_ = l11l111l1l1l_l1_(item,l11l11l11l11_l1_,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࠧ࡞ࠤ忠"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࡕࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ忡"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡆࡴࡺࡴࡰ࡯ࡓࡥࡳ࡫࡬ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ忢"))
	l11l111lllll_l1_,count = l11l111l1l1l_l1_(item,l11l11l11l11_l1_,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ忣"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ忤"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ忥"))
	l11l111lllll_l1_,l1l1lll111_l1_ = l11l111l1l1l_l1_(item,l11l11l11l11_l1_,l11l11l1lll1_l1_)
	if l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭忦") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ忧"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ忨")
	if l1l111_l1_ (u"๊ࠫฮวีำࠪ忩") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭忪"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ快")
	if l1l111_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ忬") in list(l11l11l11l11_l1_.keys()):
		l11l1l11llll_l1_ = str(l11l11l11l11_l1_[l1l111_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ忭")])
		if l1l111_l1_ (u"ࠩࡉࡶࡪ࡫ࠠࡸ࡫ࡷ࡬ࠥࡇࡤࡴࠩ忮") in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠪࠨ࠿࠭忯")
		if l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠢࡑࡓ࡜࠭忰") in l11l1l11llll_l1_: l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭忱")
		if l1l111_l1_ (u"࠭ࡂࡶࡻࠪ忲") in l11l1l11llll_l1_ or l1l111_l1_ (u"ࠧࡓࡧࡱࡸࠬ忳") in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠬ忴")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡷ้ࠪออิาࠩ念")) in l11l1l11llll_l1_: l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ忶")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡹฺࠬัศรࠪ忷")) in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠬࠪࠤ࠻ࠩ忸")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡻࠧศีอสัอัࠨ忹")) in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠫ忺")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡶࠩศ฽้อๆศฬࠪ忻")) in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠩࠧ࠾ࠬ忼")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ忽") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠫࡄ࠭忾"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ忿") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭怀")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1l111111_l1_: title = l11l1l111111_l1_+l1l111_l1_ (u"ࠧࠡࠢࠪ态")+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠨ࠮ࠪ怂"),l1l111_l1_ (u"ࠩࠪ怃"))
	count = count.replace(l1l111_l1_ (u"ࠪ࠰ࠬ怄"),l1l111_l1_ (u"ࠫࠬ怅"))
	count = re.findall(l1l111_l1_ (u"ࠬࡢࡤࠬࠩ怆"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"࠭ࠧ怇")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_
def l11l11l1llll_l1_(item,url=l1l111_l1_ (u"ࠧࠨ怈"),index=l1l111_l1_ (u"ࠨࠩ怉")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_ = l11l1l1l1ll1_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怊") in str(item): return
	elif l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ怋") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ怌") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ怍") in url or l1l111_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怎") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠧ࠾࠿ࡀࠤࠬ怏")+title+l1l111_l1_ (u"ࠨࠢࡀࡁࡂ࠭怐")
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ怑"),l1lllll_l1_+title,l1l111_l1_ (u"ࠪࠫ怒"),9999)
	elif title and l1l111_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怓") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ怔"),l1lllll_l1_+title,l1l111_l1_ (u"࠭ࠧ怕"),9999)
	elif l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ怖") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ怗"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l11l1l11l1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ怘"),l1lllll_l1_+l11l1l11l1ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ怙") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭怚") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ怛") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭怜") not in l1ll1ll_l1_:
			l11l1l111lll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ思"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ怞")+l11l1l111lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ怟"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ怠")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ怡")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ怢"),1)[0]
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ怣"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	else:
		type = l1l111_l1_ (u"ࠧࠨ怤")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ急"),l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭怦"),l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭性"),l1l111_l1_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ怨"),l1l111_l1_ (u"ࠬࡹࡳ࠾ࠩ怩"),l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ怪")]):
			if l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ怫")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡦ࠳ࠬ怬") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠩࡆࡌࡓࡒࠧ怭")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ怮")
			if l1l111_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ怯") in l1ll1ll_l1_: type = l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪ怰")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ怱")
			index,l11l11l111l1_l1_ = l1l111_l1_ (u"ࠧࠨ怲"),l1l111_l1_ (u"ࠨࠩ怳")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ怴"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l11l11llllll_l1_(url,data=l1l111_l1_ (u"ࠪࠫ怵"),request=l1l111_l1_ (u"ࠫࠬ怶")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ怷"))
	if request==l1l111_l1_ (u"࠭ࠧ怸"): request = l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ怹")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ怺"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ总"):l1l111_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ怼")}
	if l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ怽") in data: l11l1l11l11l_l1_,key,l11l111ll111_l1_,l11l1l111l11_l1_,token,l11l1l11111l_l1_ = data.split(l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ怾"))
	else: l11l1l11l11l_l1_,key,l11l111ll111_l1_,l11l1l111l11_l1_,token,l11l1l11111l_l1_ = l1l111_l1_ (u"࠭ࠧ怿"),l1l111_l1_ (u"ࠧࠨ恀"),l1l111_l1_ (u"ࠨࠩ恁"),l1l111_l1_ (u"ࠩࠪ恂"),l1l111_l1_ (u"ࠪࠫ恃"),l1l111_l1_ (u"ࠫࠬ恄")
	if l1l111_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ恅") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ恆")] = {l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ恇"):{l1l111_l1_ (u"ࠣࡪ࡯ࠦ恈"):l1l111_l1_ (u"ࠤࡤࡶࠧ恉"),l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ恊"):l1l111_l1_ (u"ࠦ࡜ࡋࡂࠣ恋"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ恌"):l11l1l111l11_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ恍"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ恎"))
	elif l1l111_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭恏") in url and l11l1l11l11l_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ恐"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ恑")] = {l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ恒"):{l1l111_l1_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ恓"):l11l1l11l11l_l1_,l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ恔"):l1l111_l1_ (u"ࠢࡘࡇࡅࠦ恕"),l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ恖"):l11l1l111l11_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ恗"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠷ࡴࡤࠨ恘"))
	elif l1l111_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ恙") in url and l11l1l11111l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭恚"):l1l111_l1_ (u"࠭࠱ࠨ恛"),l1l111_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ恜"):l11l1l111l11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ恝"):l1l111_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ恞")+l11l1l11111l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ恟"),url,l1l111_l1_ (u"ࠫࠬ恠"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭恡"),l1l111_l1_ (u"࠭ࠧ恢"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ恣"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ恤"),url,l1l111_l1_ (u"ࠩࠪ恥"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ恦"),l1l111_l1_ (u"ࠫࠬ恧"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ恨"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭恩"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭恪"),html,re.DOTALL|re.I)
	if tmp: l11l1l111l11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ恫"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ恬"),html,re.DOTALL|re.I)
	if tmp: l11l1l11l11l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ恭"),html,re.DOTALL|re.I)
	if tmp: l11l111ll111_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ恮") in list(cookies.keys()): l11l1l11111l_l1_ = cookies[l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ息")]
	data = l11l1l11l11l_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ恰")+key+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ恱")+l11l111ll111_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ恲")+l11l1l111l11_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭恳")+token+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ恴")+l11l1l11111l_l1_
	if request==l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ恵") and l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ恶") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ恷"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ恸"),html,re.DOTALL)
		l11l1l11lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ恹"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ恺") and l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ恻") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ恼"),html,re.DOTALL)
		l11l1l11lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ恽"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ恾") not in html: l11l1l11lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ恿"),html)
	else: l11l1l11lll1_l1_ = l1l111_l1_ (u"ࠨࠩ悀")
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ悁"),data)
	return html,l11l1l11lll1_l1_,data
def l11l1l1l11l1_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ悂"),l1l111_l1_ (u"ࠫ࠰࠭悃"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭悄")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ悅"),l1l111_l1_ (u"ࠧࠬࠩ悆"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࠪ悇")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࡣࠬ悈") in options: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡗࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ悉")
		elif l1l111_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪ悊") in options: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ悋")
		elif l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫ悌") in options: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡪࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ悍")
		l1llllll_l1_ = l1lllll1_l1_+l11l11lll11l_l1_
	else:
		l11l11lll111_l1_,l11l11l1l1ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠨࠩ悎")
		l11l11l1ll1l_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭悏"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ悐"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ悑"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ悒"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ悓")]
		l11l1l11ll1l_l1_ = [l1l111_l1_ (u"ࠧࠨ悔"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ悕"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ悖"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ悗"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ悘")]
		l11l1l1l1111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ悙"),l11l11l1ll1l_l1_)
		if l11l1l1l1111_l1_ == -1: return
		l11l11ll1ll1_l1_ = l11l1l11ll1l_l1_[l11l1l1l1111_l1_]
		html,c,data = l11l11llllll_l1_(l1lllll1_l1_+l11l11ll1ll1_l1_)
		if c:
			d = c[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ悚")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ悛")][l1l111_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ悜")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悝")][l1l111_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ悞")][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ悟")][l1l111_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ悠")]
			for l11l11l1l1l1_l1_ in range(len(d)):
				group = d[l11l11l1l1l1_l1_][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ悡")][l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ悢")]
				for l11l1l1l11ll_l1_ in range(len(group)):
					l11l11l11l11_l1_ = group[l11l1l1l11ll_l1_][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ患")]
					if l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ悤") in list(l11l11l11l11_l1_.keys()):
						l1ll1ll_l1_ = l11l11l11l11_l1_[l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ悥")][l1l111_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭悦")][l1l111_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ悧")][l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ您")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ悩"),l1l111_l1_ (u"ࠨࠨࠪ悪"))
						title = l11l11l11l11_l1_[l1l111_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ悫")]
						title = title.replace(l1l111_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭悬"),l1l111_l1_ (u"ࠫࠬ悭"))
						if l1l111_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ悮") in title: continue
						if l1l111_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ悯") in title:
							title = l1l111_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ悰")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ悱") in title: continue
						title = title.replace(l1l111_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ悲"),l1l111_l1_ (u"ࠪࠫ悳"))
						if l1l111_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ悴") in title: continue
						if l1l111_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ悵") in title:
							title = l1l111_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ悶")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ悷") in title: continue
						l11l11lll111_l1_.append(escapeUNICODE(title))
						l11l11l1l1ll_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l11l1l11ll11_l1_ = l1l111_l1_ (u"ࠨࠩ悸")
		else:
			l11l11lll111_l1_ = [l1l111_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ悹"),l1lllllll_l1_]+l11l11lll111_l1_
			l11l11l1l1ll_l1_ = [l1l111_l1_ (u"ࠪࠫ悺"),l111lllll_l1_]+l11l11l1l1ll_l1_
			l11l1l1l1l1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ悻"),l11l11lll111_l1_)
			if l11l1l1l1l1l_l1_ == -1: return
			l11l1l11ll11_l1_ = l11l11l1l1ll_l1_[l11l1l1l1l1l_l1_]
		if l11l1l11ll11_l1_: l1llllll_l1_ = l111l1_l1_+l11l1l11ll11_l1_
		elif l11l11ll1ll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l11ll1ll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
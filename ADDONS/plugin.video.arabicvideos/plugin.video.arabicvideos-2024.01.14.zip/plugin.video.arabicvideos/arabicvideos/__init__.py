# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l111l1_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡎࡔࡉࡕࠩ插")
l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ揓"),l1l111_l1_ (u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࠭揔"))
l1lll11l11l_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l11l_l1_
l1lll1ll111l_l1_ = int(mode)
l1llllll111l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ揕"))
l1llllll111l_l1_ = l1llllll111l_l1_.replace(ltr,l1l111_l1_ (u"ࠨࠩ揖")).replace(rtl,l1l111_l1_ (u"ࠩࠪ揗"))
if l1lll1ll111l_l1_==260: message = l1l111_l1_ (u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ揘")+l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ揙")+l1l1l11ll11_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ揚")
else:
	l11l111l11l1_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ換"),l1l111_l1_ (u"ࠧࠨ揜")).replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ揝"),l1l111_l1_ (u"ࠩࠪ揞"))
	l11l111l11l1_l1_ = l11l111l11l1_l1_.replace(l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ揟"),l1l111_l1_ (u"ࠫࠬ揠")).strip(l1l111_l1_ (u"ࠬࠦࠧ握"))
	l11l111l11l1_l1_ = l11l111l11l1_l1_.replace(l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ揢"),l1l111_l1_ (u"ࠧࠡࠩ揣")).replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠬ揤"),l1l111_l1_ (u"ࠩࠣࠫ揥")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭揦"),l1l111_l1_ (u"ࠫࠥ࠭揧"))
	message = l1l111_l1_ (u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ揨")+l1llllll111l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭揩")+mode+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ揪")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ揫")
l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ揬"),l11lllll1l_l1_(l1ll1_l1_)+message)
l1lll1l111ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ揭"))
l111ll1l11l_l1_ = False if l1lll1l111ll_l1_==l1l11l1l1l1_l1_ else True
if not l111ll1l11l_l1_ and l1lll1ll111l_l1_ in [235,715]:
	l1l1lll11l1l_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ揮")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ揯") if l1lll1ll111l_l1_==235 else l1l111_l1_ (u"࠭࡭࠴ࡷࠪ揰")
	l11ll1l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࠫ揱")+l1ll1_l1_+l1l111_l1_ (u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭揲")+l1l1lll11l1l_l1_)
	l11lll1lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࠭揳")+l1ll1_l1_+l1l111_l1_ (u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭援")+l1l1lll11l1l_l1_)
	if l11ll1l1ll_l1_ or l11lll1lll_l1_:
		url += l1l111_l1_ (u"ࠫࢁ࠭揵")
		if l11ll1l1ll_l1_: url += l1l111_l1_ (u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ揶")+l11ll1l1ll_l1_
		if l11lll1lll_l1_: url += l1l111_l1_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ揷")+l11lll1lll_l1_
		url = url.replace(l1l111_l1_ (u"ࠧࡽࠨࠪ揸"),l1l111_l1_ (u"ࠨࡾࠪ揹"))
	l11l11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࠭揺")+l1ll1_l1_+l1l111_l1_ (u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ揻")+l1l1lll11l1l_l1_)
	if l11l11ll1l_l1_:
		l11l111l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ揼"),url,re.DOTALL)
		url = url.replace(l11l111l11ll_l1_[0],l11l11ll1l_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll1ll11l_l1_,l1111lll1l1_l1_,l1lll1llllll_l1_
	l111l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࠭揽")
	l11ll1ll11l_l1_(l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ揾"))
	try: l1111lll1l1_l1_(l1lll11l11l_l1_,l1llllll111l_l1_)
	except Exception as error: l111l1ll1ll_l1_ = traceback.format_exc()
	l1lll1llllll_l1_(l111l1ll1ll_l1_)
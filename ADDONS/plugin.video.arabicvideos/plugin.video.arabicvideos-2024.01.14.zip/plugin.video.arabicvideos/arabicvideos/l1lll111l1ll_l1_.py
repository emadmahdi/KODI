# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ啺")
headers = l1l111_l1_ (u"ࠨࠩ啻")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡍ࠺࡟ࠨ啼")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ啽"),l1l111_l1_ (u"ࠫฬ๊ใๅࠩ啾"),l1l111_l1_ (u"ࠬอแๅษ่ࠫ啿"),l1l111_l1_ (u"࠭ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪ喀"),l1l111_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ喁")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ喂")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭喃")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ善"),l111l1_l1_,l1l111_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭喅"),l1l111_l1_ (u"ฺࠬว่ัࠣๅํื๊้ࠢ࠰ࠤࡘ࡮ࡡࡩ࡫ࡧࠤ࠹ࡻࠧ喆"),l1l111_l1_ (u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫࠯ࡥࡲࡱ࠴ࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠮࡯ࡧࡷࠫ喇"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ喈"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ喉"),l1l111_l1_ (u"ࠩࠪ喊"),119,l1l111_l1_ (u"ࠪࠫ喋"),l1l111_l1_ (u"ࠫࠬ喌"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ喍"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喎"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ喏"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喐"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ喑"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ喒"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭喓"),l1l111_l1_ (u"ࠬ࠭喔"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喕"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ喖"),l1l11ll_l1_,111,l1l111_l1_ (u"ࠨࠩ喗"),l1l111_l1_ (u"ࠩࠪ喘"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ喙"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡯࡭ࡱ࡮ࡨ࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪࡣࡧࡺ࠲࡬ࡩ࡭ࡶࡨࡶࠬ喚"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭喛"),l1l111_l1_ (u"࠭ࠧ喜"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ฺࠥว่ัࠣๅํื๊้ࠩ喝"),l1l111_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦล๋ฮสำࠥ฿ๆ้ษ้ࠤฬ๊ๅ้ไ฼ࠤศ๎ࠠหื่๎๊ࠦวๅ็๋ๆ฾ࠦส฻์ิࠫ喞"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠤࡂࠦ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ喟"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喠"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭喡")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭喢"),filter)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ喣"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ喤"),l1l111_l1_ (u"ࠨࠩ喥"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡶࡴࡶࡤࡰࡹࡱࠦ࠭࠴ࠪࡀࠫ࠿ࡷࡨࡸࡩࡱࡶࡁࠫ喦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ喧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ喨"),l1l111_l1_ (u"ࠬ࠭喩")).replace(l1l111_l1_ (u"࠭࡜ࡳࠩ喪"),l1l111_l1_ (u"ࠧࠨ喫")).strip(l1l111_l1_ (u"ࠨࠢࠪ喬"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ喭") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫ單") in l1ll1ll_l1_: title = l1l111_l1_ (u"๋ࠫ๐สโๆๆืࠬ喯")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喰"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ喱")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠧࠨ喲"),response=l1l111_l1_ (u"ࠨࠩ喳")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭喴"),url,l1l111_l1_ (u"ࠪࠫ喵"),headers,l1l111_l1_ (u"ࠫࠬ営"),l1l111_l1_ (u"ࠬ࠭喷"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ喸"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ喹"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡩ࡯࡭ࡩ࡫࡟ࡠࡵ࡯࡭ࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ喺"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶ࡬ࡴࡽࡳ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠬ࠳࠰࠿ࠪࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ喻"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠪ喼"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ喽"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ喾"),l1l111_l1_ (u"࠭ว฻่ํอࠬ喿"),l1l111_l1_ (u"ࠧไๆํฬࠬ嗀"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ嗁"),l1l111_l1_ (u"๊ࠩำฬ็ࠧ嗂"),l1l111_l1_ (u"้ࠪออัศหࠪ嗃"),l1l111_l1_ (u"ࠫ฾ืึࠨ嗄"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬ嗅"),l1l111_l1_ (u"࠭วๅส๋้ࠬ嗆")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠧ࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠫ嗇") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪ嗈"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ嗉"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭嗊"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯࠲ࠫ嗋") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ็๊ๅ็ࠪ嗌") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嗍"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ嗎") in title and l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ嗏") not in url:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ嗐") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗑"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵ࠳ࠬ嗒") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嗓"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ嗔") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭嗕") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ嗖")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗗"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ嗘") in url and l1l111_l1_ (u"ࠫา๊โสࠩ嗙") in title:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嗚"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嗛"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嗜"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ嗝"): items = re.findall(l1l111_l1_ (u"ࠩࠫࡹࡵࡪࡡࡵࡧࡔࡹࡪࡸࡹࠪ࠰࠭ࡃࡃ࠮࠮ࠬࡁࠬࡀࠬ嗞"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嗟"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ嗠"):
				title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ嗡"),l1l111_l1_ (u"࠭ࠧ嗢")).replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ嗣"),l1l111_l1_ (u"ࠨࠩ嗤"))
				if l1l111_l1_ (u"ࠩࡂࠫ嗥") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ嗦")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫ嗧")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嗨"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ嗩")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠧࠨ嗪"),l1l111_l1_ (u"ࠨࠩ嗫"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1ll1llll_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭嗬"),url,l1l111_l1_ (u"ࠪࠫ嗭"),headers,l1l111_l1_ (u"ࠫࠬ嗮"),l1l111_l1_ (u"ࠬ࠭嗯"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ嗰"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡸࠦࡤ࠮ࡨ࡯ࡩࡽ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嗱"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ嗲") in l11llll_l1_[0]: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l111llll_l1_ in range(2):
		if l11l1ll1llll_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗳"),l111lllll1_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嗴"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嗵"),block,re.DOTALL)
		if l11l1ll1llll_l1_ and len(items)<2:
			l11l1ll1llll_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠬࠦࠧ嗶")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ嗷") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡴࡨࡥࡩࡩࡲࡶ࡯ࡥࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ嗸"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嗹"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ嗺")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嗻"),url,l1l111_l1_ (u"ࠫࠬ嗼"),headers,l1l111_l1_ (u"ࠬ࠭嗽"),l1l111_l1_ (u"࠭ࠧ嗾"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ嗿"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡦࡸ࡮ࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嘀"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嘁"),block,re.DOTALL)
	l11l1lll1111_l1_ = l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ嘂") in block
	download = l1l111_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ嘃") in block
	if   l11l1lll1111_l1_ and not download: l11l1lll111l_l1_,l11l1ll1lll1_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠬ࠭嘄")
	elif not l11l1lll1111_l1_ and download: l11l1lll111l_l1_,l11l1ll1lll1_l1_ = l1l111_l1_ (u"࠭ࠧ嘅"),l1ll_l1_[0]
	elif l11l1lll1111_l1_ and download: l11l1lll111l_l1_,l11l1ll1lll1_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l1lll111l_l1_,l11l1ll1lll1_l1_ = l1l111_l1_ (u"ࠧࠨ嘆"),l1l111_l1_ (u"ࠨࠩ嘇")
	if l11l1lll1111_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭嘈"),l11l1lll111l_l1_,l1l111_l1_ (u"ࠪࠫ嘉"),headers,l1l111_l1_ (u"ࠫࠬ嘊"),l1l111_l1_ (u"ࠬ࠭嘋"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ嘌"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡭ࡧࡷࠤࡸ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫࡳࡰࡦࡿࡥࡳࠩ嘍"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嘎"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭嘏"),l1l111_l1_ (u"ࠪ࠳ࠬ嘐"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嘑")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嘒")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嘓"),l11l1ll1lll1_l1_,l1l111_l1_ (u"ࠧࠨ嘔"),headers,l1l111_l1_ (u"ࠨࠩ嘕"),l1l111_l1_ (u"ࠩࠪ嘖"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ嘗"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭࡮ࡴࡦࡰ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶࠬ嘘"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽࠱࡬ࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嘙"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ嘚")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ嘛")+l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭嘜")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嘝"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ嘞"),l1l111_l1_ (u"ࠫ࠰࠭嘟"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ嘠")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嘡"),url,l1l111_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ嘢"),l1l111_l1_ (u"ࠨึส๋ิࠦแ้ำํ์ࠥ࠳ࠠࡔࡪࡤ࡬࡮ࡪࠠ࠵ࡷࠪ嘣"),l1l111_l1_ (u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠱ࡲࡪࡺࠧ嘤"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ嘥"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ嘦"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嘧"),url,l1l111_l1_ (u"࠭ࠧ嘨"),headers,l1l111_l1_ (u"ࠧࠨ嘩"),l1l111_l1_ (u"ࠨࠩ嘪"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭嘫"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭嘬"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࠩ嘭"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿࡞ࡶ࠮࠭࠴ࠪࡀࠫ࡟ࡷ࠯ࡂࠧ嘮"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ嘯") not in url: url = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ嘰")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ嘱"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭嘲"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嘳"),l1l111_l1_ (u"ࠫ࠴ࡅࠧ嘴"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭嘵"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ嘶"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭嘷"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ嘸")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ嘹"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ嘺"),l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ嘻")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ嘼"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嘽"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ嘾"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ嘿"),l1l111_l1_ (u"ࠩࠪ噀")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ噁"))
	if type==l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ噂"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠬࡃࠧ噃") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"࠭࠽ࠨ噄") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ噅")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ噆")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ噇")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭噈")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭噉"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ噊")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ噋"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ噌"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ噍")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ噎"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ噏"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬ噐"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ噑"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧ噒"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ噓")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噔"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ噕"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噖"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ噗")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ噘"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ噙"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ噚"),l1l111_l1_ (u"ࠨࠩ噛"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠩๆ่ࠥ࠭噜"),l1l111_l1_ (u"ࠪࠫ噝"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠫࡂ࠭噞") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭噟"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ噠")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ噡"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ噢"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ噣"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ噤"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠫࠬ噥"),l1l111_l1_ (u"ࠬ࠭噦"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ噧"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ器")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ噩")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ噪")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭噫")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ噬")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ噭"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨ噮")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠧࠨ噯"),l1l111_l1_ (u"ࠨࠩ噰"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ噱"): option = l1l111_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ噲")
			elif value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ噳"): option = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ噴")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ噵")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ噶")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ噷")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ噸")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ噹")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧ噺")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠬ࠶ࠧ噻")]
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ噼")+name
			if type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ噽"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噾"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠩࠪ噿"),l1l111_l1_ (u"ࠪࠫ嚀"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ嚁") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠬࡃࠧ嚂") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嚃"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ嚄")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嚅"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嚆"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠪࠫ嚇"),l1l111_l1_ (u"ࠫࠬ嚈"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠬࡃࠦࠨ嚉"),l1l111_l1_ (u"࠭࠽࠱ࠨࠪ嚊"))
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠩ嚋"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠨ࠿ࠪ嚌") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠫ嚍"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ嚎"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠫࠬ嚏")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ嚐")
		if l1l111_l1_ (u"࠭ࠥࠨ嚑") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ嚒") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ嚓"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭嚔")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嚕") and value!=l1l111_l1_ (u"ࠫ࠵࠭嚖"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ嚗")+key+l1l111_l1_ (u"࠭࠽ࠨ嚘")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ嚙"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ嚚")+key+l1l111_l1_ (u"ࠩࡀࠫ嚛")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ嚜"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭嚝"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠬࡃ࠰ࠨ嚞"),l1l111_l1_ (u"࠭࠽ࠨ嚟"))
	return l1l1l111_l1_
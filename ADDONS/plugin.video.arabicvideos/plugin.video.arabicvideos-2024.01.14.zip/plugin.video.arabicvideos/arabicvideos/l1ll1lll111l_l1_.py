# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭妊")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡓࡉࡒࡢࠫ妋")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ๅึษิ฽ฮ࠭妌"),l1l111_l1_ (u"ࠧษอ้ࠣออิาࠩ妍")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ妎"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ妏"),l1l111_l1_ (u"ࠪࠫ妐"),l1l111_l1_ (u"ࠫࠬ妑"),l1l111_l1_ (u"ࠬ࠭妒"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ妓"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妔"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠨ࠱ࠪ妕"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭妖"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妗"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ妘"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠬ࠭妙"),l1l111_l1_ (u"࠭ࠧ妚"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ妛"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭妜"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ妝"),l1l111_l1_ (u"ࠪࠫ妞"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妟"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ妠")+l1lllll_l1_+l1l111_l1_ (u"࠭รฮัฮࠤฬ๊ๅ้ษู๎฾࠭妡"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࠦࡲࡿࡁࡤࡥࡲࡹࡳࡺࠢࠨ妢"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ妣"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫ妤"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妥"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭妦")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l11l1l1ll1ll_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ妧"),url,l1l111_l1_ (u"࠭ࠧ妨"),l1l111_l1_ (u"ࠧࠨ妩"),l1l111_l1_ (u"ࠨࠩ妪"),l1l111_l1_ (u"ࠩࠪ妫"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ妬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡯ࡴࡶࠫ࠲࠯ࡅࠩࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ妭"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ妮"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭妯"),l1l111_l1_ (u"ࠧโ์็้ࠬ妰"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ妱"),l1l111_l1_ (u"ࠩฦ฾๋๐ษࠨ妲"),l1l111_l1_ (u"ࠪ็้๐ศࠨ妳"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ妴"),l1l111_l1_ (u"ࠬํฯศใࠪ妵"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭妶"),l1l111_l1_ (u"ฺࠧำูࠫ妷"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ妸"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ妹"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪ妺")]
	l11l1l1lll11_l1_ = l1l111_l1_ (u"ࠫ࠴࠭妻").join(l11l1l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ妼")).split(l1l111_l1_ (u"࠭࠯ࠨ妽"))[4:]).split(l1l111_l1_ (u"ࠧ࠮ࠩ妾"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠฮๆๅอࠥࡢࡤࠬࠩ妿"),title,re.DOTALL)
		if l11l1l1ll1ll_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠩ࠲ࠫ姀").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ姁")).split(l1l111_l1_ (u"ࠫ࠴࠭姂"))[4:]).split(l1l111_l1_ (u"ࠬ࠳ࠧ姃"))
			l11l1l1lll1l_l1_ = len([x for x in l11l1l1lll11_l1_ if x in l111lllll_l1_])
			if l11l1l1lll1l_l1_>2 and l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ姄") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭姅"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ姆"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"่ࠩืู้ไࠨ姇") not in title:
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ姈"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫา๊โสࠩ姉") in title:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ姊") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭始"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ姌"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姍"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ姎"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠥࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࠨ姏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ姐"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭姑"),l1l111_l1_ (u"࠭ࠧ姒"))
			if title!=l1l111_l1_ (u"ࠧࠨ姓"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ委"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ姕")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠪࠫ姖"),l1l111_l1_ (u"ࠫࠬ姗"),l11l1l1ll1ll_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ姘"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ姙")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ姚"),url,l1l111_l1_ (u"ࠨࠩ姛"),headers,l1l111_l1_ (u"ࠩࠪ姜"),l1l111_l1_ (u"ࠪࠫ姝"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ姞"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ姟"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡪ࡯ࡪ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姠"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨ姡"))
	l11l1l1ll1l1_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡯࡭ࡸࡺࡓࡦࡣࡶࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ姢"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴࠩ姣") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠧ姤"))
		if count==0: count = block.count(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡦࡹ࡯࡯࠿ࠪ姥"))
		if count>1:
			l11l1l1ll1l1_l1_ = False
			if l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠤࠪ姦") in block:
				items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ姧"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡼ࡯࠳࠲࠵࠵࠴ࡺࡥ࡮ࡲ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠴࠱ࡴ࡭ࡶ࠿ࡴ࡮ࡸ࡫ࡂ࠭姨")+id
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姩"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ姪"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠳ࡶࡨࡱࡁࡶࡩࡷ࡯ࡥࡴࡋࡇࡁࠬ姫")+id
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姬"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l11l1l1ll1l1_l1_:
		block = l1l111_l1_ (u"ࠬ࠭姭")
		if l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠭姮") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡳࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ姯"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姰"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ姱"))
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ姲"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠫ࠴࠭姳"))+l1l111_l1_ (u"ࠬ࠵࠿ࡥࡱࡀࡻࡦࡺࡣࡩࠩ姴")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ姵"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ姶"),l1l111_l1_ (u"ࠨࠩ姷"),l1l111_l1_ (u"ࠩࠪ姸"),l1l111_l1_ (u"ࠪࠫ姹"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ姺"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ姻"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡰࡡࡳࡳࡸࡺࡉࡅࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ姼"),html,re.DOTALL)
	if not l11111l11_l1_: l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࠪࡷ࡬࡮ࡹ࡜࠯࡫ࡧࡠ࠱࠶࡜࠭ࠪ࠱࠮ࡄ࠯࡜ࠪࠩ姽"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ姾"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ姿"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ娀"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴࡯ࡦࡳࡣࡰࡩ࠷࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧ威")+l11111l11_l1_+l1l111_l1_ (u"ࠬࠬࡶࡪࡦࡨࡳࡂ࠭娂")+l111111ll_l1_[2:]+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ娃")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ娄")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡪࡩࡹࡋ࡭ࡣࡧࡧࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ娅"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠩࡸࡶࡱ࠭娆"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ娇")+title+l1l111_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬ娈")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧ娉"))+l1l111_l1_ (u"࠭࠯ࡀࡦࡲࡁࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭娊")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ娋"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ娌"),l1l111_l1_ (u"ࠩࠪ娍"),l1l111_l1_ (u"ࠪࠫ娎"),l1l111_l1_ (u"ࠫࠬ娏"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ娐"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡵࡣࡥࡰࡪ࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ娑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ娒"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ娓"))
			if l1l111_l1_ (u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪ娔") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠪࡣࡤิวึࠩ娕")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠫࠬ娖")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭娗")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ娘")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭娙"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠨࠩ娚")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ娛"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ娜"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭娝"),l1l111_l1_ (u"ࠬ࠱ࠧ娞"))
	if l1l11ll_l1_==l1l111_l1_ (u"࠭ࠧ娟"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ娠")+search+l1l111_l1_ (u"ࠨ࠱ࠪ娡")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࠪ娢"))
	return
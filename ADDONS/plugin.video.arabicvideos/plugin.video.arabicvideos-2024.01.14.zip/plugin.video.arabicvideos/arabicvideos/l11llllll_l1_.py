# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬတ")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨထ") : l1l111_l1_ (u"ࠬ࠭ဒ") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡂࡔࡏࡣࠬဓ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺࠧำฺ๋ࠥอไๆืสี฾ฯࠧန"),l1l111_l1_ (u"ࠨษ็็้࠭ပ"),l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫဖ"),l1l111_l1_ (u"ࠪห้฿วษࠩဗ"),l1l111_l1_ (u"ࠫอืวๆฮࠣ็๊ฮ๊้ฬิࠫဘ"),l1l111_l1_ (u"๋่ࠬษษํ่ࠥ๎ࠠอ๊ส่ࠬမ"),l1l111_l1_ (u"࠭วๅไึ้ࠥอไศี็ห๊๐ࠧယ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==200: l1lll_l1_ = l1l1l11_l1_()
	elif mode==201: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==202: l1lll_l1_ = PLAY(url)
	elif mode==203: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==204: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫရ")+text)
	elif mode==205: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨလ")+text)
	elif mode==209: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩဝ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪသ"),l1l111_l1_ (u"ࠫࠬဟ"),209,l1l111_l1_ (u"ࠬ࠭ဠ"),l1l111_l1_ (u"࠭ࠧအ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫဢ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨဣ"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬဤ"),l111l1_l1_,205)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪဥ"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧဦ"),l111l1_l1_,204)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪဧ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨဨ"),l1l111_l1_ (u"ࠧࠨဩ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨဪ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫါ")+l1lllll_l1_+l1l111_l1_ (u"้๊ࠪ๐าสࠩာ"),l111l1_l1_+l1l111_l1_ (u"ࠫࡄࡅࡴࡳࡧࡱࡨ࡮ࡴࡧࠨိ"),201)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬီ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨု")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤใ็ห๊ࠦๅๆ์ีอࠬူ"),l111l1_l1_+l1l111_l1_ (u"ࠨࡁࡂࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࡤࡳ࡯ࡷ࡫ࡨࡷࠬေ"),201)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩဲ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬဳ")+l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥๅ๋ิฬࠫဴ"),l111l1_l1_+l1l111_l1_ (u"ࠬࡅ࠿ࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩဵ"),201)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ံ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠ့ࠩ")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪး"),l111l1_l1_+l1l111_l1_ (u"ࠩࡂࡃࡲࡧࡩ࡯ࡲࡤ࡫ࡪ္࠭"),201)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ်࡚ࠧ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬျ"),headers,True,l1l111_l1_ (u"ࠬ࠭ြ"),l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪွ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠱ࡹࡧࡢࡴࠪ࠱࠮ࡄ࠯ࡍࡢ࡫ࡱࡖࡴࡽࠧှ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪဿ"),block,re.DOTALL)
		for filter,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡪࡲࡱࡪ࠵࡭ࡰࡴࡨࡃ࡫࡯࡬ࡵࡧࡵࡁࠬ၀")+filter
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ၁"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭၂")+l1lllll_l1_+title,l1ll1ll_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ၃"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ၄"),l1l111_l1_ (u"ࠧࠨ၅"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ၆"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ၇"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ၈") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭၉"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ၊"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ။")+l1lllll_l1_+title,l1ll1ll_l1_,201)
	return html
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠧࡀࡁࠪ၌") in url: url,type = url.split(l1l111_l1_ (u"ࠨࡁࡂࠫ၍"))
	else: type = l1l111_l1_ (u"ࠩࠪ၎")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ၏"),url,l1l111_l1_ (u"ࠫࠬၐ"),headers,True,l1l111_l1_ (u"ࠬ࠭ၑ"),l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬၒ"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡨࡧࡷࡴࡴࡹࡴࡴࠩၓ") in url: l11llll_l1_ = [html]
	elif type==l1l111_l1_ (u"ࠨࡶࡵࡩࡳࡪࡩ࡯ࡩࠪၔ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡐࡥࡸࡺࡥࡳࡕ࡯࡭ࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡡࡴࠠࠫ࠾࠲ࡨ࡮ࡼ࠾࡝ࡰࠣ࠮ࡁ࠵ࡤࡪࡸࡁࠫၕ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࡤࡳ࡯ࡷ࡫ࡨࡷࠬၖ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘࡲࡩࡥࡧࡵࡣ࠶࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪၗ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟ࡴࡧࡵ࡭ࡪࡹࠧၘ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠲ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬၙ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧ࠲࠳࠴ࡱࡦ࡯࡮ࡱࡣࡪࡩࠬၚ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠤࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦࡸࠨࠧၛ"),html,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡪࡴࡵࡴࡦࡴࠪၜ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l111111_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪၝ"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩၞ"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫၟ"),l1l111_l1_ (u"࠭ใๅ์หࠫၠ"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ၡ"),l1l111_l1_ (u"ࠨ้าหๆ࠭ၢ"),l1l111_l1_ (u"่ࠩฬฬืวสࠩၣ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧၤ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫၥ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫၦ")]
	items = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡣࡱࡻࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬၧ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠧࡔ࡮࡬ࡨࡪࡸࡉࡵࡧࡰࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ၨ"),block,re.DOTALL)
		l1ll_l1_,l11ll1l11_l1_,l11l11_l1_ = zip(*items)
		items = zip(l11ll1l11_l1_,l1ll_l1_,l11l11_l1_)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪၩ") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫၪ"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬၫ"))
		if l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯࠲ࠫၬ") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫၭ"),l1lllll_l1_+title,l1ll1ll_l1_,202,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩၮ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧၯ") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫၰ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨၱ") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪၲ"),l1lllll_l1_+title,l1ll1ll_l1_,203,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠫ࠴ࡶࡡࡤ࡭࠲ࠫၳ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬၴ"),l1lllll_l1_+title,l1ll1ll_l1_+l1l111_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭ၵ"),201,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧၶ"),l1lllll_l1_+title,l1ll1ll_l1_,203,l1ll1l_l1_)
	if type in [l1l111_l1_ (u"ࠨࠩၷ"),l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴࡰࡢࡩࡨࠫၸ")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫၹ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫၺ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭ၻ"),l1l111_l1_ (u"࠭ࠧၼ"))
				if l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪၽ") in url:
					l11ll11ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧၾ"))[1]
					l11lll1ll_l1_ = url.split(l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨၿ"))[1]
					l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩႀ")+l11lll1ll_l1_,l1l111_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪႁ")+l11ll11ll_l1_)
				if title!=l1l111_l1_ (u"ࠬ࠭ႂ"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ႃ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ႄ")+title,l1ll1ll_l1_,201)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬႅ"),url,l1l111_l1_ (u"ࠩࠪႆ"),headers,True,l1l111_l1_ (u"ࠪࠫႇ"),l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬႈ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬႉ"),html,re.DOTALL)
	if l11llll_l1_:
		l11111ll_l1_ = []
		l1lll1l1_l1_ = l1l111_l1_ (u"࠭ࠧႊ").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ႋ"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪႌ"))
		title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨႍ") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬႎ"))[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭ႏ"),l1l111_l1_ (u"ࠬࠦࠧ႐"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬ႑"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ႒"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ႓")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ႔"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭႕"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭႖") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ႗") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭႘"),l1lllll_l1_+title,l1ll1ll_l1_,203)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ႙") not in l1ll1ll_l1_:
				title = l111l11_l1_(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧႚ"),l1lllll_l1_+title,l1ll1ll_l1_,202)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫႛ"))
	hostname = l111l1_l1_
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧႜ"),url,l1l111_l1_ (u"ࠫࠬႝ"),headers,True,True,l1l111_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ႞"))
	html = response.content
	id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ႟"),html,re.DOTALL)
	if not id: id = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨႠ"),html,re.DOTALL)
	if not id: id = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႡ"),html,re.DOTALL)
	if id: id = id[0]
	if l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪႢ") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩႣ"))
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨႤ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭Ⴅ"),headers,True,True,l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪႦ"))
		l11l1ll1_l1_ = response.content
		l11ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⴇ"),l11l1ll1_l1_,re.DOTALL)
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࠢࡽࠨࡴࡹࡴࡺ࠻ࠪࠩႨ"),l11l1ll1_l1_,re.DOTALL)
		l11ll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭Ⴉ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࡟ࡲ࠯࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫႪ"),l11l1ll1_l1_)
		l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬႫ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧႬ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		items = l11ll111l_l1_+l1l1111_l1_+l11ll11l1_l1_+l11l1llll_l1_+l11l1lll1_l1_+l11ll1111_l1_
		if not items:
			items = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫႭ"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l111_l1_ (u"ࠧ࠯ࡲࡱ࡫ࠬႮ") in server: continue
			if l1l111_l1_ (u"ࠨ࠰࡭ࡴ࡬࠭Ⴏ") in server: continue
			if l1l111_l1_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩႰ") in server: continue
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫႱ"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l111l1ll_l1_[0]
				if l111l1ll_l1_ in title: title = title.replace(l111l1ll_l1_+l1l111_l1_ (u"ࠫࡵ࠭Ⴒ"),l1l111_l1_ (u"ࠬ࠭Ⴓ")).replace(l111l1ll_l1_,l1l111_l1_ (u"࠭ࠧႴ")).strip(l1l111_l1_ (u"ࠧࠡࠩႵ"))
				l111l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭Ⴖ")+l111l1ll_l1_
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠪႷ")
			if server.isdigit():
				l1ll1ll_l1_ = hostname+l1l111_l1_ (u"ࠪ࠳ࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠭Ⴘ")+id+l1l111_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨႹ")+server+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ⴚ")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧႻ")+l111l1ll_l1_
			else:
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬႼ") not in server: server = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧႽ")+server
				l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪႾ"),title,re.DOTALL)
				if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨႿ")+l111l1ll_l1_[0]
				else: l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠬჀ")
				l1ll1ll_l1_ = server+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡸࡣࡷࡧ࡭࠭Ⴡ")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡏࡱࡺࠫჂ") in html:
		l1ll1ll1l_l1_ = { l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭Ⴣ"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨჄ") }
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠬჅ")
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ჆"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬჇ"),l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠬ࠭჈"),l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ჉"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠳ࡩࡵࡧࡰࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ჊"),l11l1ll1_l1_,re.DOTALL)
		for block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾ࠪ჋"),block,re.DOTALL)
			for l1ll1ll_l1_,name,l111l1ll_l1_ in items:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ჌")+name+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧჍ")+l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ჎")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ჏") in html:
		l1ll1ll1l_l1_ = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪა"):l1l111_l1_ (u"ࠧࠨბ") , l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫგ"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪდ") }
		l1lllll1_l1_ = hostname + l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭ე")+id
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨვ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ზ"),l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪთ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡸࡳࡹࠧი") in l11l1ll1_l1_:
			l11ll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧკ"),l11l1ll1_l1_,re.DOTALL)
			for l1llllll_l1_ in l11ll11l1_l1_:
				if l1l111_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩლ") not in l1llllll_l1_ and l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨმ") in l1llllll_l1_:
					l1llllll_l1_ = l1llllll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨნ")
					l1llll_l1_.append(l1llllll_l1_)
				elif l1l111_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬო") in l1llllll_l1_:
					l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧპ")
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫჟ"),l1llllll_l1_,l1l111_l1_ (u"ࠨࠩრ"),headers,True,True,l1l111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭ს"))
					l11ll1l1l_l1_ = response.content
					l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡁࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࠫ࠰࠱࠲࠳࠭ࠨტ"),l11ll1l1l_l1_,re.DOTALL)
					for l1l1111l1_l1_ in l1lll1l1_l1_:
						l11ll1lll_l1_ = l1l111_l1_ (u"ࠫࠬუ")
						l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧფ"),l1l1111l1_l1_,re.DOTALL)
						for l11llll11_l1_ in l11l1llll_l1_:
							item = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧქ"),l11llll11_l1_,re.DOTALL)
							if item:
								l111l1ll_l1_ = l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬღ")+item[0]
								break
						for l11llll11_l1_ in reversed(l11l1llll_l1_):
							item = re.findall(l1l111_l1_ (u"ࠨ࡞ࡺࡠࡼ࠱ࠧყ"),l11llll11_l1_,re.DOTALL)
							if item:
								l11ll1lll_l1_ = item[0]
								break
						l11l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨშ"),l1l1111l1_l1_,re.DOTALL)
						for l11lll11l_l1_ in l11l1lll1_l1_:
							l11lll11l_l1_ = l11lll11l_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫჩ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨც")+l111l1ll_l1_
							l1llll_l1_.append(l11lll11l_l1_)
		elif l1l111_l1_ (u"ࠬࡹ࡬ࡰࡹ࠰ࡱࡴࡺࡩࡰࡰࠪძ") in l11l1ll1_l1_:
			l11l1ll1_l1_ = l11l1ll1_l1_.replace(l1l111_l1_ (u"࠭࠼ࡩ࠸ࠣࠫწ"),l1l111_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫჭ"))+l1l111_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩხ")
			l11l1ll1_l1_ = l11l1ll1_l1_.replace(l1l111_l1_ (u"ࠩ࠿࡬࠸ࠦࠧჯ"),l1l111_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠤࡂࡃࡓࡕࡃࡕࡘࡂࡃࠧჰ"))+l1l111_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠬჱ")
			l11lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ჲ"),l11l1ll1_l1_,re.DOTALL)
			if l11lll1l1_l1_:
				for l1l1111l1_l1_ in l11lll1l1_l1_:
					if l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬჳ") not in l1l1111l1_l1_: continue
					l11llll1l_l1_ = l1l111_l1_ (u"ࠧࠨჴ")
					l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵ࡯ࡳࡼ࠳࡭ࡰࡶ࡬ࡳࡳࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧჵ"),l1l1111l1_l1_,re.DOTALL)
					for l11llll11_l1_ in l11l1llll_l1_:
						item = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪჶ"),l11llll11_l1_,re.DOTALL)
						if item:
							l11llll1l_l1_ = l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨჷ")+item[0]
							break
					l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪჸ"),l1l1111l1_l1_,re.DOTALL)
					if l11l1llll_l1_:
						for l11ll1lll_l1_,l11lll111_l1_ in l11l1llll_l1_:
							l11lll111_l1_ = l11lll111_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ჹ")+l11ll1lll_l1_+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪჺ")+l11llll1l_l1_
							l1llll_l1_.append(l11lll111_l1_)
					else:
						l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ჻"),l1l1111l1_l1_,re.DOTALL)
						for l11lll111_l1_,l11ll1lll_l1_ in l11l1llll_l1_:
							l11lll111_l1_ = l11lll111_l1_.strip(l1l111_l1_ (u"ࠨࠢࠪჼ"))+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪჽ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧჾ")+l11llll1l_l1_
							l1llll_l1_.append(l11lll111_l1_)
			else:
				l11l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࡝ࡹ࠮࠭ࡁ࠭ჿ"),l11l1ll1_l1_,re.DOTALL)
				for l11lll111_l1_,l11ll1lll_l1_ in l11l1llll_l1_:
					l11lll111_l1_ = l11lll111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧᄀ"))+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᄁ")+l11ll1lll_l1_+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᄂ")
					l1llll_l1_.append(l11lll111_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᄃ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪᄄ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫᄅ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ᄆ"),l1l111_l1_ (u"ࠬ࠱ࠧᄇ"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᄈ"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬᄉ"),l1l111_l1_ (u"ࠨࠩᄊ"),headers,True,l1l111_l1_ (u"ࠩࠪᄋ"),l1l111_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩᄌ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨ࡮ࡥࡷࡴࡲࡲ࠲ࡹࡥ࡭ࡧࡦࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᄍ"),html,re.DOTALL)
	if l11_l1_ and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᄎ"),block,re.DOTALL)
		l11lllll1_l1_,l11ll1ll1_l1_ = [],[]
		for category,title in items:
			l11lllll1_l1_.append(category)
			l11ll1ll1_l1_.append(title)
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭ᄏ"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠧࠨᄐ")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᄑ")+search+l1l111_l1_ (u"ࠩࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭ᄒ")+category+l1l111_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿࠴ࠫᄓ")
	l1lll11_l1_(url)
	return
def l1l1ll1l_l1_(url,filter):
	l1l11111_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᄔ"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫᄕ"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬᄖ"),l1l111_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨᄗ")]
	if l1l111_l1_ (u"ࠨࡁࠪᄘ") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ᄙ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧᄚ"),1)
	if filter==l1l111_l1_ (u"ࠫࠬᄛ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭ᄜ"),l1l111_l1_ (u"࠭ࠧᄝ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫᄞ"))
	if type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬᄟ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫᄠ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬᄡ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᄢ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨᄣ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨᄤ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪᄥ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪᄦ"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ᄧ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬᄨ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᄩ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩᄪ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧᄫ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᄬ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠨࠩᄭ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᄮ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠪࠫᄯ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨᄰ")+l11lll11_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᄱ"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩᄲ"),l1lllll1_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᄳ"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨᄴ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨᄵ"),l1lllll1_l1_,201)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᄶ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᄷ"),l1l111_l1_ (u"ࠬ࠭ᄸ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url+l1l111_l1_ (u"࠭࠯ࡢ࡮ࡽࠫᄹ"),l1l111_l1_ (u"ࠧࠨᄺ"),headers,l1l111_l1_ (u"ࠨࠩᄻ"),l1l111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᄼ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠨ࠯ࠬࡂ࠭ࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤࠨᄽ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡨࡦࡺࡡ࠮ࡨࡲࡶ࡙ࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪᄾ"),block,re.DOTALL)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠬอฮห์สีࠥ࠭ᄿ"),l1l111_l1_ (u"࠭ࠧᅀ"))
		name = name.replace(l1l111_l1_ (u"ࠧิ่ฬࠤฬ๊ล็ฬสะࠬᅁ"),l1l111_l1_ (u"ࠨษ็ื๋ฯࠧᅂ"))
		items = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁࠬ࠳࠰࠿ࠪ࠾ࠪᅃ"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠪࡁࠬᅄ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨᅅ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l11111_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬᅆ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅇ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨᅈ"),l1lllll1_l1_,201)
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅉ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪᅊ"),l1lllll1_l1_,205,l1l111_l1_ (u"ࠪࠫᅋ"),l1l111_l1_ (u"ࠫࠬᅌ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ᅍ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨᅎ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪᅏ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪᅐ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬᅑ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧᅒ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅓ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧᅔ")+name,l1lllll1_l1_,204,l1l111_l1_ (u"࠭ࠧᅕ"),l1l111_l1_ (u"ࠧࠨᅖ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			option = option.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫᅗ"),l1l111_l1_ (u"ࠩࠪᅘ"))
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᅙ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭ᅚ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᅛ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨᅜ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᅝ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫᅞ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠩ࠳ࠫᅟ")]
			title = option+l1l111_l1_ (u"ࠪࠤ࠿࠭ᅠ")+name
			if type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬᅡ"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅢ"),l1lllll_l1_+title,url,204,l1l111_l1_ (u"࠭ࠧᅣ"),l1l111_l1_ (u"ࠧࠨᅤ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬᅥ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠩࡀࠫᅦ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᅧ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨᅨ")+l11ll111_l1_
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅩ"),l1lllll_l1_+title,l1llllll_l1_,201)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅪ"),l1lllll_l1_+title,url,205,l1l111_l1_ (u"ࠧࠨᅫ"),l1l111_l1_ (u"ࠨࠩᅬ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠩࡀࠪࠬᅭ"),l1l111_l1_ (u"ࠪࡁ࠵ࠬࠧᅮ"))
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫ࠭ᅯ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠬࡃࠧᅰ") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠨᅱ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩᅲ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠨࠩᅳ")
	l1l11lll_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᅴ"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᅵ"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪᅶ"),l1l111_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ᅷ")]
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"࠭࠰ࠨᅸ")
		if l1l111_l1_ (u"ࠧࠦࠩᅹ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᅺ") and value!=l1l111_l1_ (u"ࠩ࠳ࠫᅻ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧᅼ")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᅽ") and value!=l1l111_l1_ (u"ࠬ࠶ࠧᅾ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨᅿ")+key+l1l111_l1_ (u"ࠧ࠾ࠩᆀ")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬᆁ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫᆂ")+key+l1l111_l1_ (u"ࠪࡁࠬᆃ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨᆄ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧᆅ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"࠭࠽࠱ࠩᆆ"),l1l111_l1_ (u"ࠧ࠾ࠩᆇ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩᆈ"),l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪᆉ"))
	return l1l1l111_l1_
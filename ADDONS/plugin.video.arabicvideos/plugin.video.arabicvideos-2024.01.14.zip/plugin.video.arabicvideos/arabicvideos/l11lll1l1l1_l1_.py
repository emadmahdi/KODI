# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ屰")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ山")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11l11ll11l1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l11l11ll1111_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l11l1l1l11l1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l11l1l1111ll_l1_()
	elif mode==148: l1lll_l1_ = l11l1l111l1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屲"),l1lllll_l1_+l1l111_l1_ (u"ࠧใษษ้ฮ࠭屳"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡆࡰ࠵ࡈࡵ࠻ࡊࡍ࠾࡚࡯ࡗࡥࡊ࠵ࡘࡖ࠮࠹ࡊ࠷ࡇࡵࡱࡊࡻ࡝ࡅ࠹ࡻࡓࡂࠩ屴"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屵"),l1lllll_l1_+l1l111_l1_ (u"ุࠪำ฻ࠧ屶"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࡘࡈࡔ࡯ࡧࡨ࡬ࡧ࡮ࡧ࡬ࠨ屷"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屸"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅ้ไ฼ࠫ屹"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࡘࡇࡶ࠻࠹ࡢࡉࡑࡷࡶ࠿ࡢࡣࡪࡺ࡚࡙ࡷ࠱ࡖࡶࡹ࡫ࡼ࠭屺"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屻"),l1lllll_l1_+l1l111_l1_ (u"ࠩะืฬฮࠧ屼"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡅ࡚ࡨࡦࡕࡲࡧ࡮ࡧ࡬ࡄࡖ࡙ࠫ屽"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屾"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไฺษหࠫ屿"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ岀"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岁"),l1lllll_l1_+l1l111_l1_ (u"ࠨษไ่ฬ๋ࠧ岂"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ岃"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岄"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫิสศำสฮࠬ岅"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ岆"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岇"),l1lllll_l1_+l1l111_l1_ (u"ࠧใืํีฮ࠭岈"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ岉"),144,l1l111_l1_ (u"ࠩࠪ岊"),l1l111_l1_ (u"ࠪࠫ岋"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ岌"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岍"),l1lllll_l1_+l1l111_l1_ (u"࠭สึใะࠫ岎"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ岏"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岐"),l1lllll_l1_+l1l111_l1_ (u"ࠩิส๏ู๊สࠩ岑"),l111l1_l1_+l1l111_l1_ (u"ࠪࠫ岒"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岓"),l1lllll_l1_+l1l111_l1_ (u"ࠬืววฮࠪ岔"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠿ࡣࡲࡀࠫ岕"),144)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ岖"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ岗"),l1l111_l1_ (u"ࠩࠪ岘"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岙"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ岚"),l1l111_l1_ (u"ࠬ࠭岛"),149,l1l111_l1_ (u"࠭ࠧ岜"),l1l111_l1_ (u"ࠧࠨ岝"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ岞"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ岟"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ岠"),l1l111_l1_ (u"ࠫࠬ岡"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岢"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ岣"),l111l1_l1_+l1l111_l1_ (u"ࠧࠨ岤"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岥"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ึอฦอหࠪ岦"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ岧"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岨"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไหืไัࠬ岩"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ岪"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岫"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ๆฺ๐ัสࠩ岬"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ岭"),144,l1l111_l1_ (u"ࠪࠫ岮"),l1l111_l1_ (u"ࠫࠬ岯"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ岰"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岱"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆะอหึอสࠡ์๋ฮ๏๎ศࠨ岲"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ岳"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岴"),l1lllll_l1_+l1l111_l1_ (u"้ࠪำะวาษอࠤฬ๊ศา่ส้ั࠭岵"),l1l111_l1_ (u"ࠫࠬ岶"),290)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ岷"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ岸"),l1l111_l1_ (u"ࠧࠨ岹"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岺"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠใ่๋หฯูࠦาสํอࠬ岻"),l1l111_l1_ (u"ࠪࠫ岼"),147)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岽"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢฦะ๋ฮ๊สࠩ岾"),l1l111_l1_ (u"࠭ࠧ岿"),148)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峀"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥ฿ัษ์ฬࠫ峁"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๅ๏๊ๅࠨ峂"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峃"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ峄"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ峅"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峆"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำาฯํหฯูࠦาสํอࠬ峇"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืึำ๊สࠩ峈"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峉"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ峊"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ峋"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峌"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥอฬ็สํอࠬ峍"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡵࡨࡶ࡮࡫ࡳࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭峎"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峏"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡๅสีฯ๎ๆࠨ峐"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ่อัห๊้ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ峑"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峒"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣา฼ฮษࠡษ็้ึาู๋หࠪ峓"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰้ัษๆสล࠰อไโุสส๏ฯࠫฯูหอ࠰อไอ็฼อࠫࡹࡰ࠾ࡅࡄࡍࡘࡇࡨࡂࡄࠪ峔"),144)
	return
def l11l11ll1111_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峕"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡅࡋࡒࡑࡀࠠࠡࠩ峖")+name,url,144,l11l_l1_)
	return
def l11l1l1111ll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬสฮࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ峗"))
	return
def l11l1l111l1l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡹࡼࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ峘"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠫࠫ࠭峙"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l11llll11_l1_(yccc,url,index):
	level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = index.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ峚"))
	l11l11l1lll1_l1_,l11l11llll1l_l1_ = [],[]
	if l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ峛") in url: l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫࡢࠨ峜"))
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ峝") in url: l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡉ࡯࡮࡯ࡤࡲࡩࡹࠧ࡞ࠤ峞"))
	if level==l1l111_l1_ (u"ࠪ࠵ࠬ峟"): l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峠"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ峡"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞ࠤ峢"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡥ࡯ࡶࡵ࡭ࡪࡹࠧ࡞ࠤ峣"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡪࡶࡨࡱࡸ࠭࡝࡜࠵ࡠ࡟ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ峤"))
	l11l1l11l111_l1_,yddd,l11l11lll1ll_l1_ = l11l11l1ll11_l1_(yccc,l1l111_l1_ (u"ࠩࠪ峥"),l11l11l1lll1_l1_)
	if level==l1l111_l1_ (u"ࠪ࠵ࠬ峦") and l11l1l11l111_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ峧") not in url:
			for zz in range(len(yddd)):
				l11l11ll1l1l_l1_ = str(zz)
				l11l11l1lll1_l1_ = []
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ峨")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡱࡵࡡࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ峩"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ峪")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࠬࡣࠢ峫"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ峬")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠥࡡࠧ峭"))
				succeeded,item,l1111ll1_l1_ = l11l11l1ll11_l1_(yddd,l1l111_l1_ (u"ࠫࠬ峮"),l11l11l1lll1_l1_)
				if succeeded: l11l11llll1l_l1_.append([item,url,l1l111_l1_ (u"ࠬ࠸࠺࠻ࠩ峯")+l11l11ll1l1l_l1_+l1l111_l1_ (u"࠭࠺࠻࠲࠽࠾࠵࠭峰")])
			l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝ࠣ峱"))
			succeeded,item,l1111ll1_l1_ = l11l11l1ll11_l1_(yccc,l1l111_l1_ (u"ࠨࠩ峲"),l11l11l1lll1_l1_)
			if succeeded and l11l11llll1l_l1_ and l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ峳") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ峴")
				l11l11llll1l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠫ࠶ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ峵")])
	return yddd,l11l1l11l111_l1_,l11l11llll1l_l1_,l11l11lll1ll_l1_
def l11l11l1l11l_l1_(yccc,yddd,url,index):
	level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = index.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ島"))
	l11l11l1lll1_l1_,l11l11lllll1_l1_ = [],[]
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ峷"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ峸")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫࡬ࡰࡣࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ峹"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠲࡟࡞ࠫࡷ࡫࡬ࡰࡣࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ峺"))
	if l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ峻") in url: l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ峼"))
	elif l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ峽") in url: l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峾"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ峿")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ崀"))
	if l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ崁") in url or (l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ崂") in url and l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭崃") not in url):
		l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ崄")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ崅"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ崆")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ崇"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ崈")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡥࡹࡲࡤࡲࡩࡧࡢ࡭ࡧࡗࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ崉"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡪࡤࡥ࡝ࠥ崊")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崋"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ崌")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠢ࡞ࠤ崍"))
	l11l1l111ll1_l1_,yeee,l11l11lll1l1_l1_ = l11l11l1ll11_l1_(yddd,l1l111_l1_ (u"ࠨࠩ崎"),l11l11l1lll1_l1_)
	if level==l1l111_l1_ (u"ࠩ࠵ࠫ崏") and l11l1l111ll1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l11l11l1lll1_l1_ = []
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崐")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ崑"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崒")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ崓"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崔")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ崕"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崖")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ崗"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崘")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ崙"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崚")+index2+l1l111_l1_ (u"ࠢ࡞ࠤ崛"))
				succeeded,item,l1111ll1_l1_ = l11l11l1ll11_l1_(yeee,l1l111_l1_ (u"ࠨࠩ崜"),l11l11l1lll1_l1_)
				if succeeded: l11l11lllll1_l1_.append([item,url,l1l111_l1_ (u"ࠩ࠶࠾࠿࠭崝")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭崞")+index2+l1l111_l1_ (u"ࠫ࠿ࡀ࠰ࠨ崟")])
			l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠶ࡣࠢ崠"))
			l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠶ࡣࠢ崡"))
			succeeded,item,l1111ll1_l1_ = l11l11l1ll11_l1_(yddd,l1l111_l1_ (u"ࠧࠨ崢"),l11l11l1lll1_l1_)
			if succeeded and l11l11lllll1_l1_ and l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ崣") in list(item.keys()):
				l11l11lllll1_l1_.append([item,url,l1l111_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭崤")])
	return yeee,l11l1l111ll1_l1_,l11l11lllll1_l1_,l11l11lll1l1_l1_
def l11l11ll111l_l1_(yccc,yeee,url,index):
	level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = index.split(l1l111_l1_ (u"ࠪ࠾࠿࠭崥"))
	l11l11l1lll1_l1_,l11l11ll11ll_l1_ = [],[]
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崦")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崧"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崨")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崩"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崪")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崫"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崬")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崭"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崮")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ崯"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ崰")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崱"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崲")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ崳"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崴")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崵"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崶"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崷"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崸"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崹")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崺"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崻")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崼"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨࠦ崽"))
	l11l1l11l1l1_l1_,yfff,l11l1l1l1l11_l1_ = l11l11l1ll11_l1_(yeee,l1l111_l1_ (u"ࠧࠨ崾"),l11l11l1lll1_l1_)
	if level==l1l111_l1_ (u"ࠨ࠵ࠪ崿") and l11l1l11l1l1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l11l11ll1lll_l1_ = str(zz)
				l11l11l1lll1_l1_ = []
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡪ࡫࡬࡛ࠣ嵀")+l11l11ll1lll_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ嵁"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡬ࡦࡧ࡝ࠥ嵂")+l11l11ll1lll_l1_+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡩࡤࡱࡪࡉࡡࡳࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡨࡣࡰࡩࠬࡣࠢ嵃"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡧࡨࡩ࡟ࠧ嵄")+l11l11ll1lll_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ嵅"))
				l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡩࡪ࡫ࡡࠢ嵆")+l11l11ll1lll_l1_+l1l111_l1_ (u"ࠤࡠࠦ嵇"))
				succeeded,item,l1111ll1_l1_ = l11l11l1ll11_l1_(yfff,l1l111_l1_ (u"ࠪࠫ嵈"),l11l11l1lll1_l1_)
				if succeeded: l11l11ll11ll_l1_.append([item,url,l1l111_l1_ (u"ࠫ࠹ࡀ࠺ࠨ嵉")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵊")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ嵋")+l11l11ll1lll_l1_])
	return yfff,l11l1l11l1l1_l1_,l11l11ll11ll_l1_,l11l1l1l1l11_l1_
def l11l11l1ll11_l1_(l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l11l11ll1l11_l1_):
	yccc,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	yddd,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	yeee,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	yfff,l1ll111l11ll_l1_ = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	item,yrender = l1ll1111l1ll_l1_,l1ll111l11ll_l1_
	count = len(l11l11ll1l11_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l11ll1l11_l1_[l1l111llll_l1_])
			return True,out,l1l111llll_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠧࠨ嵌"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠨࠩ嵍"),data=l1l111_l1_ (u"ࠩࠪ嵎")):
	l11l11llll1l_l1_,l11l11lllll1_l1_,l11l11ll11ll_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠪ࠾࠿࠭嵏") not in index: index = l1l111_l1_ (u"ࠫ࠶ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ嵐")
	level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = index.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵑"))
	if level==l1l111_l1_ (u"࠭࠴ࠨ嵒"): level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ嵓"),l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_
	data = data.replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嵔"),l1l111_l1_ (u"ࠩࠪ嵕"))
	html,yccc,l1l11llll_l1_ = l11l11llllll_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭嵖")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵗")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵘")+l11l11ll1lll_l1_
	if level in [l1l111_l1_ (u"࠭࠱ࠨ嵙"),l1l111_l1_ (u"ࠧ࠳ࠩ嵚"),l1l111_l1_ (u"ࠨ࠵ࠪ嵛")]:
		yddd,l11l1l11l111_l1_,l11l11llll1l_l1_,l11l11lll1ll_l1_ = l11l11llll11_l1_(yccc,url,index)
		if not l11l1l11l111_l1_: return
		l1llll1l1l_l1_ = len(l11l11llll1l_l1_)
		if l1llll1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠩ࠴ࠫ嵜"): level = l1l111_l1_ (u"ࠪ࠶ࠬ嵝")
			l11l11llll1l_l1_ = []
	index = level+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵞")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵟")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ嵠")+l11l11ll1lll_l1_
	if level in [l1l111_l1_ (u"ࠧ࠳ࠩ嵡"),l1l111_l1_ (u"ࠨ࠵ࠪ嵢")]:
		yeee,l11l1l111ll1_l1_,l11l11lllll1_l1_,l11l11lll1l1_l1_ = l11l11l1l11l_l1_(yccc,yddd,url,index)
		if not l11l1l111ll1_l1_: return
		l1ll1l111l_l1_ = len(l11l11lllll1_l1_)
		if l1ll1l111l_l1_<2:
			if level==l1l111_l1_ (u"ࠩ࠵ࠫ嵣"): level = l1l111_l1_ (u"ࠪ࠷ࠬ嵤")
			l11l11lllll1_l1_ = []
	index = level+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵥")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵦")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ嵧")+l11l11ll1lll_l1_
	if level in [l1l111_l1_ (u"ࠧ࠴ࠩ嵨")]:
		yfff,l11l1l11l1l1_l1_,l11l11ll11ll_l1_,l11l1l1l1l11_l1_ = l11l11ll111l_l1_(yccc,yeee,url,index)
		if not l11l1l11l1l1_l1_: return
		l1ll1l11l1_l1_ = len(l11l11ll11ll_l1_)
	for item,url,index in l11l11llll1l_l1_+l11l11lllll1_l1_+l11l11ll11ll_l1_:
		l1ll1lllllll_l1_ = l11l11l1llll_l1_(item,url,index)
	return
def l11l11l1llll_l1_(item,url=l1l111_l1_ (u"ࠨࠩ嵩"),index=l1l111_l1_ (u"ࠩࠪ嵪")):
	if l1l111_l1_ (u"ࠪ࠾࠿࠭嵫") in index: level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵬"))
	else: level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = l1l111_l1_ (u"ࠬ࠷ࠧ嵭"),l1l111_l1_ (u"࠭࠰ࠨ嵮"),l1l111_l1_ (u"ࠧ࠱ࠩ嵯"),l1l111_l1_ (u"ࠨ࠲ࠪ嵰")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_,l11l1l1l111l_l1_ = l11l1l1l1ll1_l1_(item)
	l1lllllllll1_l1_ = l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ嵱") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭嵲") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ嵳") in l1ll1ll_l1_
	l1llllllll11_l1_ = l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ嵴") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ嵵") in l1ll1ll_l1_
	if l1lllllllll1_l1_ or l1llllllll11_l1_: l1ll1ll_l1_ = url
	l1lllllllll1_l1_ = l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ嵶") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ嵷") not in l1ll1ll_l1_
	l1llllllll11_l1_ = l1l111_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ嵸") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭嵹") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ嵺") and l1lllllllll1_l1_ and l1llllllll11_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ嵻") in url or l1l111_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ嵼") in l1ll1ll_l1_:
		level,l11l11ll1l1l_l1_,index2,l11l11ll1lll_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ嵽"),l1l111_l1_ (u"ࠨ࠲ࠪ嵾"),l1l111_l1_ (u"ࠩ࠳ࠫ嵿"),l1l111_l1_ (u"ࠪ࠴ࠬ嶀")
		index = l1l111_l1_ (u"ࠫࠬ嶁")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠬ࠭嶂")
	if l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ嶃") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭嶄") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭嶅") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ嶆"))
		if data.count(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ嶇"))==4:
			l11l1l11l11l_l1_,key,l11l1l111l11_l1_,l11l1l11111l_l1_,token = data.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ嶈"))
			l1l11llll_l1_ = l11l1l11l11l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ嶉")+key+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ嶊")+l11l1l111l11_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ嶋")+l11l1l11111l_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ嶌")+l11l1l1l111l_l1_
			if l1l111_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ嶍") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ嶎")+key
	if not title:
		global l11l11ll11l1_l1_
		l11l11ll11l1_l1_ += 1
		title = l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࠧ嶏")+str(l11l11ll11l1_l1_)
		index = l1l111_l1_ (u"ࠬ࠹ࠧ嶐")+l1l111_l1_ (u"࠭࠺࠻ࠩ嶑")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶒")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶓")+l11l11ll1lll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭嶔") in str(item): return False
	elif l1l111_l1_ (u"ࠪ࠳ࡦࡨ࡯ࡶࡶࠪ嶕") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠫ࠴ࡩ࡯࡮࡯ࡸࡲ࡮ࡺࡹࠨ嶖") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ嶗") in list(item.keys()) or l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ嶘") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶙")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶚")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶛")+l11l11ll1lll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶜"),l1lllll_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ嶝")+l1l111_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ嶞"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ嶟") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ嶠")+title
		index = l1l111_l1_ (u"ࠨ࠵ࠪ嶡")+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嶢")+l11l11ll1l1l_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭嶣")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嶤")+l11l11ll1lll_l1_
		url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭嶥"),l1l111_l1_ (u"࠭ࠧ嶦"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶧"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠨࠩ嶨"),index,l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嶩"))
	elif l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ嶪") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠫ࠸࠭嶫")+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嶬")+l11l11ll1l1l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ嶭")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶮")+l11l11ll1lll_l1_
		title = l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ嶯")+title
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶰"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࠫ嶱") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ嶲")+title
		index = l1l111_l1_ (u"ࠬ࠸࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ嶳")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶴"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嶵") in str(item):
		title = l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ嶶")+title
		index = l1l111_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭嶷")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶸"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭嶹") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嶺"),l1lllll_l1_+title,l1l111_l1_ (u"࠭ࠧ嶻"),9999)
	elif l11l1l11l1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ嶼"),l1lllll_l1_+l11l1l11l1ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ嶽") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶾"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ嶿")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ巀")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ巁") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭巂"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭巃"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ巄") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ巅") in l1ll1ll_l1_ and count:
			l11l1l111lll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ巆"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭巇")+l11l1l111lll_l1_
			index = l1l111_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ巈")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭巉"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡍࡋࡖࡘࠬ巊")+count+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ巋")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ巌"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ巍"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ巎") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡣ࠰ࠩ巏") in l1ll1ll_l1_ or (l1l111_l1_ (u"࠭࠯ࡁࠩ巐") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠧ࠰ࠩ巑"))==3):
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巒"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡆࡌࡓࡒࠧ巓")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ巔")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ巕") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巖"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡕࡔࡇࡕࠫ巗")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ巘")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ巙")+title
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巚"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l11l1l1l1ll1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_,token = False,l1l111_l1_ (u"ࠪࠫ巛"),l1l111_l1_ (u"ࠫࠬ巜"),l1l111_l1_ (u"ࠬ࠭川"),l1l111_l1_ (u"࠭ࠧ州"),l1l111_l1_ (u"ࠧࠨ巟"),l1l111_l1_ (u"ࠨࠩ巠"),l1l111_l1_ (u"ࠩࠪ巡"),l1l111_l1_ (u"ࠪࠫ巢")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_,token
	for l11l1l1111l1_l1_ in list(item.keys()):
		yrender = item[l11l1l1111l1_l1_]
		if isinstance(yrender,dict): break
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡌࡪࡵࡷࡌࡪࡧࡤࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ巣"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ巤"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩࡲࡩ࡯ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ工"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡸࡲࡵࡲࡡࡺࡣࡥࡰࡪ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ左"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡪࡴࡸ࡭ࡢࡶࡷࡩࡩ࡚ࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ巧"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ巨"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ巩"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ巪"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ巫"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ巬"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ巭"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡷ࡫ࡧࡩࡴࡏࡤࠨ࡟ࠥ差"))
	succeeded,title,l1111ll1_l1_ = l11l11l1ll11_l1_(item,yrender,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ巯"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ巰"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡣࡳ࡭࡚ࡸ࡬ࠨ࡟ࠥ己"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ已"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ巳"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ巴"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巵"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l11l11l1ll11_l1_(item,yrender,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巶"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ巷"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ巸"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l11l11l1ll11_l1_(item,yrender,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ巹"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ巺"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ巻"))
	succeeded,count,l1111ll1_l1_ = l11l11l1ll11_l1_(item,yrender,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ巼"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ巽"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ巾"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡣࡰࡰࠪࡡࡠ࠭ࡩࡤࡱࡱࡘࡾࡶࡥࠨ࡟ࠥ巿"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡵࡻ࡯ࡩࠬࡣࠢ帀"))
	succeeded,l1l1lll111_l1_,l1111ll1_l1_ = l11l11l1ll11_l1_(item,yrender,l11l11l1lll1_l1_)
	l11l11l1lll1_l1_ = []
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ币"))
	l11l11l1lll1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ市"))
	succeeded,token,l1111ll1_l1_ = l11l11l1ll11_l1_(item,yrender,l11l11l1lll1_l1_)
	if l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭布") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ帄"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ帅")
	if l1l111_l1_ (u"๊ࠫฮวีำࠪ帆") in l1l1lll111_l1_: l1l1lll111_l1_,l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭帇"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ师")
	if l1l111_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ帉") in list(yrender.keys()):
		l11l1l11llll_l1_ = str(yrender[l1l111_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ帊")])
		if l1l111_l1_ (u"ࠩࡉࡶࡪ࡫ࠠࡸ࡫ࡷ࡬ࠥࡇࡤࡴࠩ帋") in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ希")
		if l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ帍") in l11l1l11llll_l1_: l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭帎")
		if l1l111_l1_ (u"࠭ࡂࡶࡻࠪ帏") in l11l1l11llll_l1_ or l1l111_l1_ (u"ࠧࡓࡧࡱࡸࠬ帐") in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ帑")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡷ้ࠪออิาࠩ帒")) in l11l1l11llll_l1_: l11l1l11l1ll_l1_ = l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ帓")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡹฺࠬัศรࠪ帔")) in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ帕")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡻࠧศีอสัอัࠨ帖")) in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭帗")
		if l111lllllll_l1_(l1l111_l1_ (u"ࡶࠩศ฽้อๆศฬࠪ帘")) in l11l1l11llll_l1_: l11l1l111111_l1_ = l1l111_l1_ (u"ࠩࠧ࠾ࠥࠦࠧ帙")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ帚") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠫࡄ࠭帛"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ帜") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭帝")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1l111111_l1_: title = l11l1l111111_l1_+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠧ࠭ࠩ帞"),l1l111_l1_ (u"ࠨࠩ帟"))
	count = count.replace(l1l111_l1_ (u"ࠩ࠯ࠫ帠"),l1l111_l1_ (u"ࠪࠫ帡"))
	count = re.findall(l1l111_l1_ (u"ࠫࡡࡪࠫࠨ帢"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠬ࠭帣")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l1l11l1ll_l1_,l11l1l111111_l1_,token
def l11l11llllll_l1_(url,data=l1l111_l1_ (u"࠭ࠧ帤"),request=l1l111_l1_ (u"ࠧࠨ帥")):
	if request==l1l111_l1_ (u"ࠨࠩ带"): request = l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ帧")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ帨"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ帩"):l1l111_l1_ (u"ࠬࡖࡒࡆࡈࡀ࡬ࡱࡃࡡࡳࠩ帪")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ師"))
	if data.count(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ帬"))==4: l11l1l11l11l_l1_,key,l11l1l111l11_l1_,l11l1l11111l_l1_,token = data.split(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ席"))
	else: l11l1l11l11l_l1_,key,l11l1l111l11_l1_,l11l1l11111l_l1_,token = l1l111_l1_ (u"ࠩࠪ帮"),l1l111_l1_ (u"ࠪࠫ帯"),l1l111_l1_ (u"ࠫࠬ帰"),l1l111_l1_ (u"ࠬ࠭帱"),l1l111_l1_ (u"࠭ࠧ帲")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠢࡤࡱࡱࡸࡪࡾࡴࠣ帳"):{l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࠣ帴"):{l1l111_l1_ (u"ࠤ࡫ࡰࠧ帵"):l1l111_l1_ (u"ࠥࡥࡷࠨ帶"),l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ帷"):l1l111_l1_ (u"ࠧ࡝ࡅࡃࠤ常"),l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ帹"):l11l1l111l11_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ帺") or l1l111_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭帻") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡴࡨࡩࡱ࠵ࡲࡦࡧ࡯ࡣࡼࡧࡴࡤࡪࡢࡷࡪࡷࡵࡦࡰࡦࡩࠬ帼")+l1l111_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ帽")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡖࡡࡳࡣࡰࡷࠬ帾")] = l11l1l11l11l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ帿"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠲ࡵࡷࠫ幀"))
	elif l1l111_l1_ (u"ࠧ࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ幁") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ幂")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ幃"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠸ࡸࡤࠨ幄"))
	elif l1l111_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ幅") in url and l11l1l11l11l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ幆")] = token
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ幇")][l1l111_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࠧ幈")][l1l111_l1_ (u"ࠨࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦ࠭幉")] = l11l1l11l11l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ幊"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠹ࡺࡨࠨ幋"))
	elif l1l111_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ幌") in url and l11l1l11111l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭幍"):l1l111_l1_ (u"࠭࠱ࠨ幎"),l1l111_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ幏"):l11l1l111l11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ幐"):l1l111_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ幑")+l11l1l11111l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ幒"),url,l1l111_l1_ (u"ࠫࠬ幓"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭幔"),l1l111_l1_ (u"࠭ࠧ幕"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠷ࡷ࡬ࠬ幖"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ幗"),url,l1l111_l1_ (u"ࠩࠪ幘"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ幙"),l1l111_l1_ (u"ࠫࠬ幚"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠶ࡵࡪࠪ幛"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭幜"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭幝"),html,re.DOTALL|re.I)
	if tmp: l11l1l111l11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ幞"),html,re.DOTALL|re.I)
	if tmp: l11l1l11l11l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ幟") in list(cookies.keys()): l11l1l11111l_l1_ = cookies[l1l111_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ幠")]
	l1l1l1111_l1_ = l11l1l11l11l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ幡")+key+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ幢")+l11l1l111l11_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ幣")+l11l1l11111l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ幤")+token
	if request==l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ幥") and l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ幦") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࡟࡟ࠧࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠧࡢ࡝ࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ幧"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ幨"),html,re.DOTALL)
		l11l1l11lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ幩"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ幪") and l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ幫") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ幬"),html,re.DOTALL)
		l11l1l11lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡷ࠭幭"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"ࠪࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭幮") not in html: l11l1l11lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ幯"),html)
	else: l11l1l11lll1_l1_ = l1l111_l1_ (u"ࠬ࠭幰")
	if 0:
		yccc = str(l11l1l11lll1_l1_)
		if PY3: yccc = yccc.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ幱"))
		open(l1l111_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡤࡢࡶࠪ干"),l1l111_l1_ (u"ࠨࡹࡥࠫ平")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ年"),l1l1l1111_l1_)
	return html,l11l1l11lll1_l1_,l1l1l1111_l1_
def l11l1l1l11l1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ幵"),l1l111_l1_ (u"ࠫ࠰࠭并"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭幷")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ幸"),l1l111_l1_ (u"ࠧࠬࠩ幹"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࠪ幺")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࡣࠬ幻") in options: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡗࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ幼")
		elif l1l111_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࡡࠪ幽") in options: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ幾")
		elif l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫ广") in options: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡪࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ庀")
		else: l11l11lll11l_l1_ = l1l111_l1_ (u"ࠨࠩ庁")
		l1llllll_l1_ = l1lllll1_l1_+l11l11lll11l_l1_
	else:
		l11l11lll111_l1_,l11l11l1l1ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠩࠪ庂")
		l11l11l1ll1l_l1_ = [l1l111_l1_ (u"ࠪฬิ๎ๆࠡฬิฮ๏ฮࠧ広"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠠๆั์ࠤฬ๊ีๅหࠪ庄"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡฬสี๏ิࠠศๆอั๊๐ไࠨ庅"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢ฼ำิࠦวๅ็ืห์ีวหࠩ庆"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣห้ะโ๋์่ࠫ庇")]
		l11l1l11ll1l_l1_ = [l1l111_l1_ (u"ࠨࠩ庈"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡃࠨ࠶࠺࠹ࡄࠨ庉"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡌࠩ࠷࠻࠳ࡅࠩ床"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡑࠪ࠸࠵࠴ࡆࠪ庋"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡊࠫ࠲࠶࠵ࡇࠫ庌")]
		l11l1l1l1111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊สาฬํฬࠬ庍"),l11l11l1ll1l_l1_)
		if l11l1l1l1111_l1_ == -1: return
		l11l11ll1ll1_l1_ = l11l1l11ll1l_l1_[l11l1l1l1111_l1_]
		html,c,data = l11l11llllll_l1_(l1lllll1_l1_+l11l11ll1ll1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ庎")][l1l111_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ序")][l1l111_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ庐")][l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ庑")][l1l111_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ庒")][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭库")][l1l111_l1_ (u"࠭ࡧࡳࡱࡸࡴࡸ࠭应")]
				for l11l11l1l1l1_l1_ in range(len(d)):
					group = d[l11l11l1l1l1_l1_][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡍࡲࡰࡷࡳࡖࡪࡴࡤࡦࡴࡨࡶࠬ底")][l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ庖")]
					for l11l1l1l11ll_l1_ in range(len(group)):
						yrender = group[l11l1l1l11ll_l1_][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩ店")]
						if l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ庘") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ庙")][l1l111_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ庚")][l1l111_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ庛")][l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ府")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡸ࠴࠵࠸࠶ࠨ庝"),l1l111_l1_ (u"ࠩࠩࠫ庞"))
							title = yrender[l1l111_l1_ (u"ࠪࡸࡴࡵ࡬ࡵ࡫ࡳࠫ废")]
							title = title.replace(l1l111_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦࠧ庠"),l1l111_l1_ (u"ࠬ࠭庡"))
							if l1l111_l1_ (u"࠭ลำษ็อࠥอไโๆอีࠬ庢") in title: continue
							if l1l111_l1_ (u"ࠧใษษ้ฮࠦสี฼ํ่ࠬ庣") in title:
								title = l1l111_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ庤")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠬ庥") in title: continue
							title = title.replace(l1l111_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠠࠨ度"),l1l111_l1_ (u"ࠫࠬ座"))
							if l1l111_l1_ (u"ࠬࡘࡥ࡮ࡱࡹࡩࠬ庨") in title: continue
							if l1l111_l1_ (u"࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨ庩") in title:
								title = l1l111_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ庪")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠨࡕࡲࡶࡹࠦࡢࡺࠩ庫") in title: continue
							l11l11lll111_l1_.append(escapeUNICODE(title))
							l11l11l1l1ll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l11l1l11ll11_l1_ = l1l111_l1_ (u"ࠩࠪ庬")
		else:
			l11l11lll111_l1_ = [l1l111_l1_ (u"ࠪฬิ๎ๆࠡใ็ฮึ࠭庭"),l1lllllll_l1_]+l11l11lll111_l1_
			l11l11l1l1ll_l1_ = [l1l111_l1_ (u"ࠫࠬ庮"),l111lllll_l1_]+l11l11l1l1ll_l1_
			l11l1l1l1l1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้็ไหำࠪ庯"),l11l11lll111_l1_)
			if l11l1l1l1l1l_l1_ == -1: return
			l11l1l11ll11_l1_ = l11l11l1l1ll_l1_[l11l1l1l1l1l_l1_]
		if l11l1l11ll11_l1_: l1llllll_l1_ = l111l1_l1_+l11l1l11ll11_l1_
		elif l11l11ll1ll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l11ll1ll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
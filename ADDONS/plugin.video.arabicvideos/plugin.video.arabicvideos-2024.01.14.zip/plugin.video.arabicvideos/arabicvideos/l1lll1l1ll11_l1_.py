# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ䍗")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡎ࠶ࡘࡣࠬ䍘")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศ่๋ห฾ࠦวโๆส้ࠬ䍙"),l1l111_l1_ (u"ࠨฮ๋ำฬะࠠศใ็ห๊࠭䍚")]
def l11l1ll_l1_(mode,url,text):
	if   mode==380: l1lll_l1_ = l1l1l11_l1_()
	elif mode==381: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==382: l1lll_l1_ = PLAY(url)
	elif mode==383: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==389: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䍛"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䍜"),l1l111_l1_ (u"ࠫࠬ䍝"),389,l1l111_l1_ (u"ࠬ࠭䍞"),l1l111_l1_ (u"࠭ࠧ䍟"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䍠"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䍡"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䍢"),l1l111_l1_ (u"ࠪࠫ䍣"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䍤"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䍥")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ䍦"),l111l1_l1_,381,l1l111_l1_ (u"ࠧࠨ䍧"),l1l111_l1_ (u"ࠨࠩ䍨"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䍩"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䍪"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䍫")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไอษ้ฬ๏ฯࠧ䍬"),l111l1_l1_,381,l1l111_l1_ (u"࠭ࠧ䍭"),l1l111_l1_ (u"ࠧࠨ䍮"),l1l111_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ䍯"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䍰"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ䍱"),l1l111_l1_ (u"ࠫࠬ䍲"),l1l111_l1_ (u"ࠬ࠭䍳"),l1l111_l1_ (u"࠭ࠧ䍴"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䍵"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䍶"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䍷"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䍸")+l1lllll_l1_+title,l111l1_l1_,381,l1l111_l1_ (u"ࠫࠬ䍹"),l1l111_l1_ (u"ࠬ࠭䍺"),l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䍻")+str(seq))
	block = l1l111_l1_ (u"ࠧࠨ䍼")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡦࡦࡲࡶࠧ࠭䍽"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭䍾"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䍿"),block,re.DOTALL)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䎀"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䎁"),l1l111_l1_ (u"࠭ࠧ䎂"),9999)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠧศๆฦ฽้๏ࠠๆึส๋ิฯࠧ䎃"):
			if first:
				title = l1l111_l1_ (u"ࠨษ็หๆ๊วๆࠢࠪ䎄")+title
				first = False
			else: title = l1l111_l1_ (u"ࠩสู่๊ไิๆสฮࠥ࠭䎅")+title
		if title not in l11lll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎆"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䎇")+l1lllll_l1_+title,l1ll1ll_l1_,381)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䎈"),url,l1l111_l1_ (u"࠭ࠧ䎉"),l1l111_l1_ (u"ࠧࠨ䎊"),l1l111_l1_ (u"ࠨࠩ䎋"),l1l111_l1_ (u"ࠩࠪ䎌"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䎍"))
	html = response.content
	if type==l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ䎎"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡢࡴࡦ࡬࠲ࡶࡡࡨࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䎏"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䎐"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭䎑"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸࠬ䎒"),html,re.DOTALL)
		block = l11llll_l1_[0]
		z = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䎓"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*z)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䎔"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡶࡹࡷ࡭ࡵࡷࡴࠤࠫ࠲࠯ࡅࠩ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ䎕"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䎖"),block,re.DOTALL)
	elif l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䎗") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ䎘"),l1l111_l1_ (u"ࠨ࠾ࡨࡲࡩࡄ࠼ࡴࡶࡤࡶࡹࡄࠧ䎙"))
		html = html.replace(l1l111_l1_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ䎚"),l1l111_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ䎛"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡴࡢࡴࡷࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡳࡪ࠾ࠨ䎜"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==2: items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䎝"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡿࡷ࡮ࡪࡥࡣࡣࡵ࠭ࠬ䎞"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭䎟") in url:
				items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䎠"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠩ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳ࠬ䎡") in url:
				items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䎢"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䎣"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࠫ䎤") in title:
			title = re.findall(l1l111_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡩࡷ࡯ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䎥"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䎦")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽ࠩ䎧"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ䎨") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎩"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ䎪") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎫"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ䎬") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎭"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ䎮") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎯"),l1lllll_l1_+title,l1ll1ll_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䎰"),l1lllll_l1_+title,l1ll1ll_l1_,382,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡕࡧࡧࡦࠢࠫ࠲࠯ࡅࠩࠡࡱࡩࠤ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䎱"),html,re.DOTALL)
	if l11llll_l1_:
		current = l11llll_l1_[0][0]
		last = l11llll_l1_[0][1]
		block = l11llll_l1_[0][2]
		items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ䎲"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"࠭ࠧ䎳") or title==last: continue
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎴"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ䎵")+title,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠩࠪ䎶"),l1l111_l1_ (u"ࠪࠫ䎷"),type)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䎸")+title+l1l111_l1_ (u"ࠬ࠵ࠧ䎹"),l1l111_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭䎺")+last+l1l111_l1_ (u"ࠧ࠰ࠩ䎻"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎼"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาึࠦีโฯฬࠤࠬ䎽")+last,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠪࠫ䎾"),l1l111_l1_ (u"ࠫࠬ䎿"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䏀"),url,l1l111_l1_ (u"࠭ࠧ䏁"),l1l111_l1_ (u"ࠧࠨ䏂"),l1l111_l1_ (u"ࠨࠩ䏃"),l1l111_l1_ (u"ࠩࠪ䏄"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䏅"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䏆"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,False):
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䏇"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ึุ่๊ࠠๅๆๆฬฬื้ࠠษ็้อืๅอ่๊ࠢ฾ํࠧ䏈"),l1l111_l1_ (u"ࠧࠨ䏉"),9999)
		return
	if l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䏊") in url or l1l111_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ䏋") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡩ࡬ࡢࡵࡶࡁࠬ࡯ࡴࡦ࡯ࠪࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ䏌"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[1]
			l1ll1l11_l1_(l1lllll1_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡥࡱ࡫ࡶࡳࡩ࡯࡯ࡴࠩࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡧࡳࡵࠤࠪࠫࠬ䏍"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠧ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠬ࠭ࠧ䏎"),block,re.DOTALL)
		for l1ll1l_l1_,l1l1lll_l1_,l1ll1ll_l1_,name in items:
			title = l1l1lll_l1_+l1l111_l1_ (u"࠭ࠠ࠻ࠢࠪ䏏")+name+l1l111_l1_ (u"ࠧࠡษ็ั้่ษࠨ䏐")
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䏑"),l1lllll_l1_+title,l1ll1ll_l1_,382)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䏒"),url,l1l111_l1_ (u"ࠪࠫ䏓"),l1l111_l1_ (u"ࠫࠬ䏔"),l1l111_l1_ (u"ࠬ࠭䏕"),l1l111_l1_ (u"࠭ࠧ䏖"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䏗"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䏘"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫ࡮ࡪ࠽ࠨࡲ࡯ࡥࡾ࡫ࡲ࠮ࡱࡳࡸ࡮ࡵ࡮࠮࠳ࠪࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠩࠤࡶ࡬ࡪࡧࡤࡦࡴࠥࢀࠬࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࠮࠭ࠧࠨ䏙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠥࡨࡦࡺࡡ࠮ࡷࡵࡰࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡵࡨࡶࡻ࡫ࡲࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ䏚"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䏛")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䏜")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡮ࡱࡧࡥࡱ࠳ࡣ࡭ࡱࡶࡩࠧ࠭䏝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡠࡡࡢࡨࡱࡥࡧࡥࡴ࡬ࡺࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䏞"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䏟")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䏠")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䏡"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ䏢"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭䏣"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ䏤"),l1l111_l1_ (u"ࠧࠬࠩ䏥"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭䏦")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ䏧"))
	return
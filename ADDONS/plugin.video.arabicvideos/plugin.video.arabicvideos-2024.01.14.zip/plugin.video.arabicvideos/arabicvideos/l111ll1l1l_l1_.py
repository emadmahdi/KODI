# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ⃱")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡄ࠵ࡣࠬ⃲")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆู่ฬืูสࠢส่าืษࠨ⃳"),l1l111_l1_ (u"ࠨษํะ๏ࠦศ๋ีอࠫ⃴"),l1l111_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩ⃵"),l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ⃶"),l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯࠦวๅสา๎้࠭⃷"),l1l111_l1_ (u"ࠬอ๊อ๋ࠣฬุะࠠศๆฯำ๏ีࠧ⃸")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==780: l1lll_l1_ = l1l1l11_l1_()
	elif mode==781: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==782: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==783: l1lll_l1_ = PLAY(url)
	elif mode==784: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⃹")+text)
	elif mode==785: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⃺")+text)
	elif mode==786: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==789: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃻"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⃼"),l1l111_l1_ (u"ࠪࠫ⃽"),789,l1l111_l1_ (u"ࠫࠬ⃾"),l1l111_l1_ (u"ࠬ࠭⃿"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ℀"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ℁"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪℂ"),l1l111_l1_ (u"ࠩࠪ℃"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ℄"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ℅"),l1l111_l1_ (u"ࠬ࠭℆"),l1l111_l1_ (u"࠭ࠧℇ"),l1l111_l1_ (u"ࠧࠨ℈"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ℉"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺ࠭ࡱࡣࡪࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩℊ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩℋ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ℌ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪℍ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℎ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩℏ")+l1lllll_l1_+title,l1ll1ll_l1_,781)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ℐ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫℑ"),l1l111_l1_ (u"ࠪࠫℒ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩࡴࡱࡦ࡭ࡦࡲ࠭ࡣࡱࡻࠫℓ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ℔"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨℕ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ№") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ℗"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ℘")+l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"ࠪࠫℙ"),l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࡯ࡨࡲࡺ࠭ℚ"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪℛ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨℜ"),l1l111_l1_ (u"ࠧࠨℝ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ℞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ℟"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ℠"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ℡") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ™"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ℣")+l1lllll_l1_+title,l1ll1ll_l1_,781)
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠧࠨℤ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ℥"),url,l1l111_l1_ (u"ࠩࠪΩ"),l1l111_l1_ (u"ࠪࠫ℧"),l1l111_l1_ (u"ࠫࠬℨ"),l1l111_l1_ (u"ࠬ࠭℩"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨK"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩÅ"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠨࠩℬ"),l1l111_l1_ (u"ࠩࠪℭ"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠪั้่วหࠩ℮") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๊ࠫ๎วิ็ࠪℯ") in name: l111lllll1_l1_ = block
		if l111lllll1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬℰ"),l111lllll1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℱ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧℲ"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧℳ"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨℴ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩℵ"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪℶ"),l1lllll_l1_+title,l1ll1ll_l1_,783)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭ℷ")):
	if l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪℸ") in type or l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧℹ") in type:
		l1lllll1_l1_,data = url.split(l1l111_l1_ (u"ࠨࡁࡶࡩࡵࡧࡲࡢࡶࡲࡶࠫ࠭℺"))
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ℻"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩℼ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩℽ"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"ࠬ࠭ℾ"),l1l111_l1_ (u"࠭ࠧℿ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⅀"))
		html = response.content
		html = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠨ⅁")+html+l1l111_l1_ (u"ࠩࡤࡶࡹ࡯ࡣ࡭ࡧࠪ⅂")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⅃"),url,l1l111_l1_ (u"ࠫࠬ⅄"),l1l111_l1_ (u"ࠬ࠭ⅅ"),l1l111_l1_ (u"࠭ࠧⅆ"),l1l111_l1_ (u"ࠧࠨⅇ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧⅈ"))
		html = response.content
	items,l111llllll_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬⅉ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⅊"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⅋"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅌"),l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"࠭ࠧ⅍"),l1l111_l1_ (u"ࠧࡴࡷࡥࡱࡪࡴࡵࠨⅎ"))
				l111llllll_l1_ = True
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡯ࡰ࠲ࡺࡡࡹࡧࡶࠬ࠳࠰࠿ࠪࠤ࡯ࡳࡦࡪࠢࠨ⅏"),html,re.DOTALL)
		if l11llll_l1_ and type!=l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⅐"):
			if l111llllll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⅑"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⅒"),l1l111_l1_ (u"ࠬ࠭⅓"),9999)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⅔"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ⅕"),url,785,l1l111_l1_ (u"ࠨࠩ⅖"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⅗"))
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⅘"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ⅙"),url,784,l1l111_l1_ (u"ࠬ࠭⅚"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⅛"))
			filters = True
	if not l111llllll_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡦࡸࡴࡪࡥ࡯ࡩࠬ⅜"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⅝"),block,re.DOTALL)
			l1l1_l1_ = []
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ⅞"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ⅟") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅠ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠬำไใหࠪⅡ") in title:
					l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩⅢ"),title,re.DOTALL)
					if l1l1lll_l1_:
						title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭Ⅳ") + l1l1lll_l1_[0][0]
						if title not in l1l1_l1_:
							addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⅤ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
							l1l1_l1_.append(title)
				elif l1l111_l1_ (u"่ࠩืู้ไࠨⅥ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪั้่ษࠨⅦ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅧ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				elif l1l111_l1_ (u"๋่ࠬิ็ࠪⅨ") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫⅩ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⅪ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⅫ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
		length = 12 if l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩⅬ") in type else 16
		data = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࠬࡱࡵࡡࡥ࠯ࡰࡳࡷ࡫࠮ࠫࡁࠬࠤ࠳࠰࠿ࡥࡣࡷࡥ࠲࠮࠮ࠫࡁࠬࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⅭ"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨⅮ") in type):
			if data:
				offset = length
				action,name,value = data[0]
				action = action.replace(l1l111_l1_ (u"ࠬࡲ࡯ࡢࡦࠪⅯ"),l1l111_l1_ (u"࠭ࡧࡦࡶࠪⅰ")).replace(l1l111_l1_ (u"ࠧ࠮ࠩⅱ"),l1l111_l1_ (u"ࠨࡡࠪⅲ")).replace(l1l111_l1_ (u"ࠩࠥࠫⅳ"),l1l111_l1_ (u"ࠪࠫⅴ"))
			else:
				data = re.findall(l1l111_l1_ (u"ࠫࡦࡩࡴࡪࡱࡱࡁ࠭࠴ࠪࡀࠫࠩࡳ࡫࡬ࡳࡦࡶࡀࠬ࠳࠰࠿ࠪࠨࠫ࠲࠯ࡅࠩ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨⅵ"),url,re.DOTALL)
				if data: action,offset,name,value = data[0]
				offset = int(offset)+length
			data = l1l111_l1_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡂ࠭ⅶ")+action+l1l111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨⅷ")+str(offset)+l1l111_l1_ (u"ࠧࠧࠩⅸ")+name+l1l111_l1_ (u"ࠨ࠿ࠪⅹ")+value
			url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵࡅࡳࡦࡲࡤࡶࡦࡺ࡯ࡳࠨࠪⅺ")+data
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⅻ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅำ์าࠫⅼ"),url,781,l1l111_l1_ (u"ࠬ࠭ⅽ"),l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡢࠫⅾ")+type)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⅿ"),url,l1l111_l1_ (u"ࠨࠩↀ"),l1l111_l1_ (u"ࠩࠪↁ"),l1l111_l1_ (u"ࠪࠫↂ"),l1l111_l1_ (u"ࠫࠬↃ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩↄ"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡨࡵࡤࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪↅ"),html,re.DOTALL)
	for l111ll1ll1_l1_ in items:
		l111lll111_l1_ = base64.b64decode(l111ll1ll1_l1_)
		if PY3: l111lll111_l1_ = l111lll111_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬↆ"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ↇ"),l111lll111_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧↈ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ↉")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ↊"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭↋")+server+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ↌"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫ↍"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡧ࡭ࡻࡄ࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬࠫࡠࡩࢁ࠳࠭࠶ࢀ࠭ࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪ࠽࠱ࡧ࡭ࡻࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࡩࡵࡷ࡯࡮ࡲࡥࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭↎"),block,re.DOTALL)
		for l111l1ll_l1_,l111lll1ll_l1_ in items:
			l1ll1ll_l1_ = base64.b64decode(l111lll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ↏"))
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ←") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ↑")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ→"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ↓")+server+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ↔")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ↕"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫ↖"),l1l111_l1_ (u"ࠪ࠱ࠬ↗"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡯ࡦ࠲ࡃࡶࡃࠧ↘")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ↙"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ↚"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ↛"),url,l1l111_l1_ (u"ࠨࠩ↜"),l1l111_l1_ (u"ࠩࠪ↝"),l1l111_l1_ (u"ࠪࠫ↞"),l1l111_l1_ (u"ࠫࠬ↟"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ↠"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࡤࡶࡹ࡯ࡣ࡭ࡧࠪ↡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ↢"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ↣"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࠬ↤") not in url: l1lllll1_l1_,l111lll11l_l1_ = url,l1l111_l1_ (u"ࠪࠫ↥")
	else: l1lllll1_l1_,l111lll11l_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸࠧ↦"))
	l1llllll_l1_,l111lll1l1_l1_ = l1ll11ll1_l1_(l111lll11l_l1_)
	l111ll1lll_l1_ = l1l111_l1_ (u"ࠬ࠭↧")
	for key in list(l111lll1l1_l1_.keys()):
		l111ll1lll_l1_ += l1l111_l1_ (u"࠭ࠦࡢࡴࡪࡷࠪ࠻ࡂࠨ↨")+key+l1l111_l1_ (u"ࠧࠦ࠷ࡇࡁࠬ↩")+l111lll1l1_l1_[key]
	l1111111_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࡦࡪ࡭ࡪࡰ࠰ࡥ࡯ࡧࡸ࠯ࡲ࡫ࡴࡄࡹࡥࡱࡣࡵࡥࡹࡵࡲࠧࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡤ࡬ࡩ࡭ࡶࡨࡶࡩࡥࡢ࡭ࡱࡦ࡯ࡸ࠭↪")+l111ll1lll_l1_
	return l1111111_l1_
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ↫"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ↬"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ↭"),l1l111_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ↮"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ↯"),l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ↰"),l1l111_l1_ (u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ↱")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ↲"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ↳"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ↴")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ↵"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ↶"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ↷"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ↸"),l1l111_l1_ (u"ࠩࠪ↹")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ↺"))
	if type==l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ↻"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠬࡃࠧ↼") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"࠭࠽ࠨ↽") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ↾")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ↿")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ⇀")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭⇁")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭⇂"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ⇃")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ⇄"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⇅"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⇆")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ⇇"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⇈"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⇉"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⇊")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇋"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ⇌"),l1llllll_l1_,781,l1l111_l1_ (u"ࠨࠩ⇍"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⇎"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⇏"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ⇐")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ⇑"),l1llllll_l1_,781,l1l111_l1_ (u"࠭ࠧ⇒"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⇓"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⇔"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⇕"),l1l111_l1_ (u"ࠪࠫ⇖"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"่๊ࠫࠠࠨ⇗"),l1l111_l1_ (u"ࠬ࠭⇘"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"࠭࠽ࠨ⇙") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⇚"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⇛"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⇜")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⇝"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ⇞"),l1llllll_l1_,781,l1l111_l1_ (u"ࠬ࠭⇟"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⇠"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⇡"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ⇢"),l1lllll1_l1_,785,l1l111_l1_ (u"ࠩࠪ⇣"),l1l111_l1_ (u"ࠪࠫ⇤"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ⇥"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ⇦")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ⇧")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ⇨")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ⇩")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭⇪")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⇫"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭⇬")+name,l1lllll1_l1_,784,l1l111_l1_ (u"ࠬ࠭⇭"),l1l111_l1_ (u"࠭ࠧ⇮"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ⇯")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ⇰")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ⇱")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ⇲")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ⇳")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨ⇴")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨ⇵")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ⇶")+name
			if type==l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭⇷"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇸"),l1lllll_l1_+title,url,784,l1l111_l1_ (u"ࠪࠫ⇹"),l1l111_l1_ (u"ࠫࠬ⇺"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⇻") and l111l111l_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨ⇼") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⇽"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⇾")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇿"),l1lllll_l1_+title,l1llllll_l1_,781,l1l111_l1_ (u"ࠪࠫ∀"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ∁"))
			elif type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭∂"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭∃"),l1lllll_l1_+title,url,785,l1l111_l1_ (u"ࠧࠨ∄"),l1l111_l1_ (u"ࠨࠩ∅"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠩࡀࠪࠬ∆"),l1l111_l1_ (u"ࠪࡁ࠵ࠬࠧ∇"))
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫ࠭∈"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠬࡃࠧ∉") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠨ∊"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ∋"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠨࠩ∌")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳ࠫ∍")
		if l1l111_l1_ (u"ࠪࠩࠬ∎") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭∏") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ∐"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪ∑")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ−") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ∓"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ∔")+key+l1l111_l1_ (u"ࠪࡁࠬ∕")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ∖"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ∗")+key+l1l111_l1_ (u"࠭࠽ࠨ∘")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ∙"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ√"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠩࡀ࠴ࠬ∛"),l1l111_l1_ (u"ࠪࡁࠬ∜"))
	return l1l1l111_l1_
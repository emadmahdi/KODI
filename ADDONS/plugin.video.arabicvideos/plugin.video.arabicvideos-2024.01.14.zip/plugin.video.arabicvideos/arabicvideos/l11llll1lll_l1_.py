# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ墴")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌࡒࡥࠧ墵")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l1ll11ll1_l1_()
	elif mode==56: l1lll_l1_ = l11l1ll1111l_l1_()
	elif mode==57: l1lll_l1_ = l111ll11l1_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll11l1_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墶"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ墷"),l1l111_l1_ (u"ࠫࠬ墸"),59,l1l111_l1_ (u"ࠬ࠭墹"),l1l111_l1_ (u"࠭ࠧ墺"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ墻"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭墼"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ墽"),l1l111_l1_ (u"ࠪࠫ墾"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ墿"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ壀")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠩ壁"),l1l111_l1_ (u"ࠧࠨ壂"),56)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壃"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ壄")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้อแๅษ่ࠫ壅"),l1l111_l1_ (u"ࠫࠬ壆"),55)
	return l1l111_l1_ (u"ࠬ࠭壇")
def l11l1ll11ll1_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壈"),l1lllll_l1_+l1l111_l1_ (u"ࠧศฯาฯࠥอไศใ็ห๊࠭壉"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡲࡪࡽࡥࡴࡶࠪ壊"),51)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壋"),l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠢิหหาษࠨ壌"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡰࡰࡲࡸࡰࡦࡸࠧ壍"),51)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壎"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯำࠣห฻อแศฬࠣห้อแๅษ่ࠫ壏"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱࡯ࡥࡹ࡫ࡳࡵࠩ壐"),51)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壑"),l1lllll_l1_+l1l111_l1_ (u"ࠩสๅ้อๅࠡๅ็หุ๐ใ๋หࠪ壒"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡩ࡬ࡢࡵࡶ࡭ࡨ࠭壓"),51)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ壔"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ壕"),l1l111_l1_ (u"࠭ࠧ壖"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壗"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ壘"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡾࡵࡰࠨ壙"),57)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壚"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิส๋ษิࠤฬ็ไศ็้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ壛"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡳࡧࡹ࡭ࡪࡽࠧ壜"),57)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壝"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭壞"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡺ࡮࡫ࡷࡴࠩ壟"),57)
	return
def l11l1ll1111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壠"),l1lllll_l1_+l1l111_l1_ (u"ࠪหาีหࠡษ็ุ้๊ำๅษอࠫ壡"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡯ࡧࡺࡩࡸࡺࠧ壢"),51)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壣"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠาษษะฮ࠭壤"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡴࡴࡶࡵ࡭ࡣࡵࠫ壥"),51)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壦"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาึࠦวืษไหฯࠦวๅ็ึุ่๊วหࠩ壧"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵࡬ࡢࡶࡨࡷࡹ࠭壨"),51)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壩"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦใๅษึ๎่๐ษࠨ壪"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡦࡰࡦࡹࡳࡪࡥࠪ士"),51)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ壬"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ壭"),l1l111_l1_ (u"ࠩࠪ壮"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壯"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ声"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡻࡲࡴࠬ壱"),57)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭売"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะอ๎ฬืࠠๆี็ื้อสࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ壳"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡷ࡫ࡶࡪࡧࡺࠫ壴"),57)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壵"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ壶"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡷ࡫ࡨࡻࡸ࠭壷"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠬࡅࠧ壸") in url:
		parts = url.split(l1l111_l1_ (u"࠭࠿ࠨ壹"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠧࡀࠩ壺") + QUOTE(parts[1],l1l111_l1_ (u"ࠨ࠿ࠩ࠾࠴ࠫࠧ壻"))
	else: filter = l1l111_l1_ (u"ࠩࠪ壼")
	parts = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ壽"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"ࠫࡾࡵࡰࠨ壾"),l1l111_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࠬ壿"),l1l111_l1_ (u"࠭ࡶࡪࡧࡺࡷࠬ夀")]:
		if type==l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭夁"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠨใํ่๊࠭夂")
		elif type==l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ夃"): l1l1l1lll_l1_=l1l111_l1_ (u"ุ้๊ࠪำๅࠩ处")
		url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ夅") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠬ࠵ࠧ夆") + l1llllll1_l1_ + l1l111_l1_ (u"࠭࠯ࠨ备") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ夈"),l1l111_l1_ (u"ࠨࠩ変"),l1l111_l1_ (u"ࠩࠪ夊"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ夋"))
		items = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡩࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࠨࡰࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯࠭ࡂࠦࡵ࡫ࡰࡪࡵࡲࡨࡪࡹࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡲࡵࡩࡸࡨࡡࡴࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ夌"),html,re.DOTALL)
		l1ll1l111ll_l1_=0
		for id,title,l11l1ll11111_l1_,l1ll1l_l1_ in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1ll1l1lll1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡶ࠳࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯࡮ࡣ࡬ࡲ࠴࠭复") + l1ll1l_l1_ + l1l111_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭夎")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ夏") + id
			if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ夐"): addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ夑"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ夒"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夓"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็ࠤࠬ夔")+title,l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿ࡦࡲࡀࠫ夕")+l11l1ll11111_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ外")+title+l1l111_l1_ (u"ࠨ࠿ࠪ夗")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ夘"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ夙")
		elif type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ多"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ夛")
		url = l1l1l1l1l1_l1_ + l1l111_l1_ (u"࠭࠯࡫ࡵࡲࡲ࠴ࡹࡥ࡭ࡧࡦࡸࡪࡪ࠯ࠨ夜") + sort + l1l111_l1_ (u"ࠧ࠮ࠩ夝") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠨ࠯࡚࡛࠳ࡰࡳࡰࡰࠪ夞")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ够"),l1l111_l1_ (u"ࠪࠫ夠"),l1l111_l1_ (u"ࠫࠬ夡"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ夢"))
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡧࡩࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧ࡫ࡰࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡥࡥࡸ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ夣"),html,re.DOTALL)
		l1ll1l111ll_l1_=0
		for id,l11l1ll11111_l1_,l1ll1l_l1_,title in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡫ࡰ࡫࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ夤") + l1ll1l_l1_ + l1l111_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ夥")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ夦") + id
			if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ大"): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ夨"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ天"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭太"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧ夫")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡨࡴࡂ࠭夬")+l11l1ll11111_l1_+l1l111_l1_ (u"ࠩࡀࠫ夭")+title+l1l111_l1_ (u"ࠪࡁࠬ央")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"ฺࠫ็อสࠢࠪ夯")
	if l1ll1l111ll_l1_==16:
		for l1ll1l1llll_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭夰")+type+l1l111_l1_ (u"࠭࠯ࠨ失")+str(l1ll1l1llll_l1_)+l1l111_l1_ (u"ࠧ࠰ࠩ夲")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夳"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠩࡀࠫ头"))
	l11l1ll11111_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ夵"),l1l111_l1_ (u"ࠫࠬ夶"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠬࡅࠧ夷"))[0]
	if l11l1ll11111_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ夸"),l1l111_l1_ (u"ࠧࠨ夹"),l1l111_l1_ (u"ࠨࠩ夺"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ夻"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸ࡫࡬ࡦࡥࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡲࡥࡤࡶࡁࠫ夼"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ夽"),block,re.DOTALL)
		l11l1ll11111_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l1ll11111_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠬࡅࡥࡱ࠿ࠪ夾") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣู๊ไิๆࠣࠫ夿")+name+l1l111_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ奀")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ奁"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ奂"),l1l111_l1_ (u"ࠪࠫ奃"),l1l111_l1_ (u"ࠫࠬ奄"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ奅"))
	l11l1ll111l1_l1_ = re.findall(l1l111_l1_ (u"࠭ๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯ࠯ࠬࡂࡱࡴࡳࡥ࡯ࡶ࡟ࠬࠧ࠮࠮ࠫࡁࠬࠦࠬ奆"),html,re.DOTALL)
	if l11l1ll111l1_l1_:
		time = l11l1ll111l1_l1_[1].replace(l1l111_l1_ (u"ࠧࡕࠩ奇"),l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭奈"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ奉"),l1l111_l1_ (u"ࠪࠫ奊"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏࠭奋"),l1l111_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣื๏้่็่ࠢฮํ็ัࠡ฻็ํฺ่ࠥโ่ࠢหู่ࠠษ฻าࠤ์ึวࠡษ็์็ะࠧ奌")+l1l111_l1_ (u"࠭࡜࡯ࠩ奍")+time)
		return
	l11l1l1llll1_l1_,l11l1ll11l11_l1_ = [],[]
	l11l1ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ奎"),html,re.DOTALL)[0]
	l11l1ll111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡨࡡࡤ࡭ࡸࡴࡤࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奏"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡰࡸࡀࠠࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奐"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ契") in server:
			server = l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ奒")
			url = l11l1ll111ll_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ奓")
			url = l11l1ll11l1l_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ奔") in url:
			l11l1l1llll1_l1_.append(url)
			l11l1ll11l11_l1_.append(l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥࠦࠧ奕")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡳ࠸࠿࠴ࠪࡀࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡟ࡸ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ奖"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁ࡟ࡸ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ套"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ奘"))[-1]
		filename = filename.replace(l1l111_l1_ (u"ࠫ࡫ࡧ࡬࡭ࡤࡤࡧࡰ࠭奙"),l1l111_l1_ (u"ࠬ࠭奚"))
		filename = filename.replace(l1l111_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ奛"),l1l111_l1_ (u"ࠧࠨ奜"))
		filename = filename.replace(l1l111_l1_ (u"ࠨ࠯ࠪ奝"),l1l111_l1_ (u"ࠩࠪ奞"))
		if l1l111_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ奟") in server:
			server = l1l111_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ奠")
			url = l11l1ll111ll_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ奡")
			url = l11l1ll11l1l_l1_ + l1ll1ll_l1_
		l11l1l1llll1_l1_.append(url)
		l11l1ll11l11_l1_.append(l1l111_l1_ (u"࠭࡭ࡱ࠶ࠣࠤࠬ奢")+server+l1l111_l1_ (u"ࠧࠡࠢࠪ奣")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡘ࡬ࡨࡪࡵࠠࡒࡷࡤࡰ࡮ࡺࡹ࠻ࠩ奤"), l11l1ll11l11_l1_)
	if l11l11l_l1_ == -1 : return
	url = l11l1l1llll1_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ奥"))
	return
def l111ll11l1_l1_(url,type):
	if l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ奦") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳ู๊ไิๆࠪ奧")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴็๊ๅ็ࠪ奨")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ奩"),l1l111_l1_ (u"ࠧࠨ奪"),l1l111_l1_ (u"ࠨࠩ奫"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡋࡏࡌࡕࡇࡕࡗ࠲࠷ࡳࡵࠩ奬"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡺࡨࡧࡦࡰࡵࡩ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭奭"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭奮"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࠬ奯"),block,re.DOTALL)
	if type==1:
		for l11l1l1lllll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭奰"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠧࡀࡵࡸࡦ࡬࡫࡮ࡳࡧࡀࠫ奱")+l11l1l1lllll_l1_,58)
	elif type==2:
		url,l11l1l1lllll_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࠪ奲"))
		for l1lllll111ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ女"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠪࡃࡨࡵࡵ࡯ࡶࡵࡽࡂ࠭奴")+l1lllll111ll_l1_+l1l111_l1_ (u"ࠫࠫ࠭奵")+l11l1l1lllll_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ奶"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ奷"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ奸")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ她"),url,l1l111_l1_ (u"ࠩࠪ奺"),l1l111_l1_ (u"ࠪࠫ奻"),True,l1l111_l1_ (u"ࠫࠬ奼"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠳ࡰࡧࠫ好"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡧࡦࡰࡨࡶࡦࡲ࠭ࡣࡱࡧࡽ࠭࠴ࠪࡀࠫࡶࡩࡦࡸࡣࡩ࠯ࡥࡳࡹࡺ࡯࡮࠯ࡳࡥࡩࡪࡩ࡯ࡩࠪ奾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ奿"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ妀") in url:
				if l1l111_l1_ (u"ࠩࡂࡩࡵࡃࠧ妁") in url:
					title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ如")+title
					url = url.replace(l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾࠳ࠪ妃"),l1l111_l1_ (u"ࠬࡅࡥࡱ࠿࠳ࠫ妄"))
					url = url+l1l111_l1_ (u"࠭࠽ࠨ妅")+QUOTE(title)+l1l111_l1_ (u"ࠧ࠾ࠩ妆")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妇"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟โ์็้ࠥ࠭妈")+title
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ妉"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ媕")
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ媖"):l1l111_l1_ (u"ࠧࠨ媗")}
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡ࡚ࡇࡒࡥࠧ媘")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭媙"),l1l111_l1_ (u"ࠪࡻࡼ࡫ࠧ媚")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ媛")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ媜")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媝"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ媞"),l111l1_l1_,569,l1l111_l1_ (u"ࠨࠩ媟"),l1l111_l1_ (u"ࠩࠪ媠"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ媡"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ媢"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ媣"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭媤"),564)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媥"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ媦"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ媧"),565)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ媨"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媩"),l1l111_l1_ (u"ࠬ࠭媪"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ媫"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ媬"),l1l111_l1_ (u"ࠨࠩ媭"),l1l111_l1_ (u"ࠩࠪ媮"),l1l111_l1_ (u"ࠪࠫ媯"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭媰"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭媱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ媲"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠧࠨ媳"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媴"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ媵")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ媶"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媷"),l1l111_l1_ (u"ࠬ࠭媸"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ媹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ媺"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媻"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ媼")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ媽"),url,l1l111_l1_ (u"ࠫࠬ媾"),l1l111_l1_ (u"ࠬ࠭媿"),l1l111_l1_ (u"࠭ࠧ嫀"),l1l111_l1_ (u"ࠧࠨ嫁"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭嫂"))
	html = response.content
	if l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ嫃") in html:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫄"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ嫅"),url,561,l1l111_l1_ (u"ࠬ࠭嫆"),l1l111_l1_ (u"࠭ࠧ嫇"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ嫈"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ嫉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ嫊"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫋"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1lllll1lll1_l1_,type=l1l111_l1_ (u"ࠫࠬ嫌")):
	if l1l111_l1_ (u"ࠬࡀ࠺ࠨ嫍") in l1lllll1lll1_l1_:
		l1llllll_l1_,url = l1lllll1lll1_l1_.split(l1l111_l1_ (u"࠭࠺࠻ࠩ嫎"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ嫏"))
		url = server+url
	else: url,l1llllll_l1_ = l1lllll1lll1_l1_,l1lllll1lll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嫐"),url,l1l111_l1_ (u"ࠩࠪ嫑"),l1l111_l1_ (u"ࠪࠫ嫒"),l1l111_l1_ (u"ࠫࠬ嫓"),l1l111_l1_ (u"ࠬ࠭嫔"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ嫕"))
	html = response.content
	if type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ嫖"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࠱࡙ࡧࡢࡴࡷ࡬ࠦࠬ嫗"),html,re.DOTALL)
	elif type in [l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ嫘"),l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ嫙")]:
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠫࡡࡢ࠯ࠨ嫚"),l1l111_l1_ (u"ࠬ࠵ࠧ嫛")).replace(l1l111_l1_ (u"࠭࡜࡝ࠤࠪ嫜"),l1l111_l1_ (u"ࠧࠣࠩ嫝"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡊࡶ࡮ࡪ࠭࠮࡙ࡨࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡘࡩࡨࡪࡷ࡙ࡎࠨࠧ嫞"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠥࡘ࡭ࡻ࡭ࡣ࠯࠰ࡋࡷ࡯ࡤࡊࡶࡨࡱࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ嫟"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠣࠫ嫠"),l1l111_l1_ (u"ࠫࠬ嫡"))
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ嫢") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫣"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠧฮๆๅอࠬ嫤") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ嫥"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ嫦") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫧"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嫨"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嫩"):
			l111l1llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ嫪"),block,re.DOTALL)
			if l111l1llll_l1_:
				count = l111l1llll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ嫫")+count
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫬"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ嫭"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠪࠫ嫮"),l1l111_l1_ (u"ࠫࠬ嫯"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嫰"))
		elif type==l1l111_l1_ (u"࠭ࠧ嫱"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ嫲"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嫳"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ุࠩๅาฯࠠࠨ嫴")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫵"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠫࠬ嫶")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嫷"),url,l1l111_l1_ (u"࠭ࠧ嫸"),l1l111_l1_ (u"ࠧࠨ嫹"),l1l111_l1_ (u"ࠨࠩ嫺"),l1l111_l1_ (u"ࠩࠪ嫻"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ嫼"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嫽"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ嫾"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫿"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠧࠨ嬀"),l1l111_l1_ (u"ࠨࠩ嬁"),l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ嬂"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࡵࡁࠫ嬃"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂࠬ嬄"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ嬅"))
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嬆"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嬇"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭嬈"),l1l111_l1_ (u"ࠩࠪ嬉")).replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠣࠫ嬊"),l1l111_l1_ (u"ࠫࠬ嬋"))
		else: title = l1l111_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ嬌")
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嬍"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嬎"),url,l1l111_l1_ (u"ࠨࠩ嬏"),l1l111_l1_ (u"ࠩࠪ嬐"),l1l111_l1_ (u"ࠪࠫ嬑"),l1l111_l1_ (u"ࠫࠬ嬒"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ嬓"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嬔"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭嬕"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嬖"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ嬗") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠪื๏ืแา๋ࠢ๎ู๊ࠥๆษࠪ嬘"): name = l1l111_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ嬙")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭嬚")+name+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ嬛")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ嬜"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嬝"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ嬞") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ嬟"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ嬠")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭嬡")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡷࡦࡥ࡬ࡱࡦ࠭嬢")+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ嬣")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嬤"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠩࠪ嬥")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ嬦"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ嬧"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ嬨"),l1l111_l1_ (u"࠭ࠫࠨ嬩"))
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ嬪")+search
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ嬫"))
	return
def l1l1ll1l_l1_(l1lllll1lll1_l1_,filter):
	if l1l111_l1_ (u"ࠩࡂࡃࠬ嬬") in l1lllll1lll1_l1_: url = l1lllll1lll1_l1_.split(l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ嬭"))[0]
	else: url = l1lllll1lll1_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭嬮"),l1l111_l1_ (u"ࠬ࠭嬯"))
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嬰"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ嬱"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ嬲"),l1l111_l1_ (u"ࠩࠪ嬳")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ嬴"))
	if type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ嬵"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ嬶") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"࠭࠽࠾ࠩ嬷") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ嬸")+category+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ嬹")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ嬺")+category+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ嬻")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ嬼"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ嬽")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ嬾"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ嬿"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ孀")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ孁"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ孂"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬ孃"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ孄"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧ孅"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭孆")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lllll1lll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ孇"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ孈"),l1111111_l1_,561,l1l111_l1_ (u"ࠪࠫ孉"),l1l111_l1_ (u"ࠫࠬ孊"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭孋"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭孌"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ孍")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ孎"),l1111111_l1_,561,l1l111_l1_ (u"ࠩࠪ孏"),l1l111_l1_ (u"ࠪࠫ子"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ孑"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ孒"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ孓"),l1l111_l1_ (u"ࠧࠨ孔"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ孕"),url,l1l111_l1_ (u"ࠩࠪ孖"),l1l111_l1_ (u"ࠪࠫ字"),l1l111_l1_ (u"ࠫࠬ存"),l1l111_l1_ (u"ࠬ࠭孙"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ孚"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠥࠫ孛"),l1l111_l1_ (u"ࠨࠤࠪ孜")).replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭孝"),l1l111_l1_ (u"ࠪ࠳ࠬ孞"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ孟"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ孠"),block+l1l111_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ孡"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ孢") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ季"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠩࡀࡁࠬ孤") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ孥"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ学")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lllll1lll1_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孧"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭孨"),l1111111_l1_,561,l1l111_l1_ (u"ࠧࠨ孩"),l1l111_l1_ (u"ࠨࠩ孪"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ孫"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ孬"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ孭"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠬ࠭孮"),l1l111_l1_ (u"࠭ࠧ孯"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ孰"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ孱")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭孲")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭孳")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ孴")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ孵")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭孶"),l1lllll_l1_+name+l1l111_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ孷"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠨࠩ學"),l1l111_l1_ (u"ࠩࠪ孹"),l1l111l1_l1_+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ孺"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠫࡷ࠭孻") or value==l1l111_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ孼"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ孽") in option: continue
			if l1l111_l1_ (u"ࠧศๆๆ่ࠬ孾") in option: continue
			if l1l111_l1_ (u"ࠨࡰ࠰ࡥࠬ孿") in value: continue
			if option==l1l111_l1_ (u"ࠩࠪ宀"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ宁"),option,re.DOTALL)
			if l1ll1l11ll1_l1_: l1l11l1ll_l1_ = l1ll1l11ll1_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠫ࠿ࠦࠧ宂")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ它")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾ࠩ宄")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ宅")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀࠫ宆")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭宇")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ守"):
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ安"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠬ࠭宊"),l1l111_l1_ (u"࠭ࠧ宋"),l1l1l11l_l1_+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ完"))
			elif type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ宍") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠩࡀࡁࠬ宎") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭宏"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ宐")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lllll1lll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ宑"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"࠭ࠧ宒"),l1l111_l1_ (u"ࠧࠨ宓"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ宔"))
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宕"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠪࠫ宖"),l1l111_l1_ (u"ࠫࠬ宗"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ官"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ宙"),l1l111_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ定")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭宛"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ宜"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ宝"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭实"),l1l111_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭実"),l1l111_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ宠"),l1l111_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ审"),l1l111_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ客")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ宣") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ室"),l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ宥"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ宦"),l1l111_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ宧"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠾࠿ࠪ宨"),l1l111_l1_ (u"ࠨ࠱ࠪ宩"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩࠩࠪࠬ宪"),l1l111_l1_ (u"ࠪ࠳ࠬ宫"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ宬"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠬ࠭宭")
	if l1l111_l1_ (u"࠭࠽࠾ࠩ宮") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠨࠪ宯"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࡀࠫ宰"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳ࠫ宱")
		if l1l111_l1_ (u"ࠪࠩࠬ宲") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭害") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ宴"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪ宵")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ家") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ宷"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ宸")+key+l1l111_l1_ (u"ࠪࡁࡂ࠭容")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ宺"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ宻")+key+l1l111_l1_ (u"࠭࠽࠾ࠩ宼")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ宽"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ宾"))
	return l1l1l111_l1_
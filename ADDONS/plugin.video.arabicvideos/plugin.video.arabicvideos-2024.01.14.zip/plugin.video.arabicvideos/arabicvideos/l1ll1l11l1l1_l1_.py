# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭䉵")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䉶") : l1l111_l1_ (u"ࠬ࠭䉷") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡎࡘ࡝ࡣࠬ䉸")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1ll111l11l1_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll111l11l1_l1_():
	message = l1l111_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ䉹")
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䉺"),l1l111_l1_ (u"ࠩࠪ䉻"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䉼"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䉽"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䉾"),l1l111_l1_ (u"࠭ࠧ䉿"),189,l1l111_l1_ (u"ࠧࠨ䊀"),l1l111_l1_ (u"ࠨࠩ䊁"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䊂"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊃"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䊄")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮ่ไีࠣหํ็๊ิ่ࠢ์ๆ๐าࠡๆส๊ิ࠭䊅"),l111l1_l1_,181,l1l111_l1_ (u"࠭ࠧ䊆"),l1l111_l1_ (u"ࠧࠨ䊇"),l1l111_l1_ (u"ࠨࡤࡲࡼ࠲ࡵࡦࡧ࡫ࡦࡩࠬ䊈"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊉"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䊊")+l1lllll_l1_+l1l111_l1_ (u"ࠫศำฯฬࠢส่ฬ็ไศ็ࠪ䊋"),l111l1_l1_,181,l1l111_l1_ (u"ࠬ࠭䊌"),l1l111_l1_ (u"࠭ࠧ䊍"),l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䊎"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䊐")+l1lllll_l1_+l1l111_l1_ (u"ࠪฮ้๐แำ์๋๊๋่ࠥโ์ีࠤ้อๆะࠩ䊑"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䊒"),l1l111_l1_ (u"ࠬ࠭䊓"),l1l111_l1_ (u"࠭ࡴࡷࠩ䊔"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊕"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䊖")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ฬ้หาุ่ࠢฬํฯสࠩ䊗"),l111l1_l1_,181,l1l111_l1_ (u"ࠪࠫ䊘"),l1l111_l1_ (u"ࠫࠬ䊙"),l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䊚"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊛"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䊜")+l1lllll_l1_+l1l111_l1_ (u"ࠨลๅ์๎ࠦวๅษไ่ฬ๋ࠠศๆะห้๐ษࠨ䊝"),l111l1_l1_,181,l1l111_l1_ (u"ࠩࠪ䊞"),l1l111_l1_ (u"ࠪࠫ䊟"),l1l111_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䊠"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠬ࠭䊡"),headers,l1l111_l1_ (u"࠭ࠧ䊢"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䊣"))
	items = re.findall(l1l111_l1_ (u"ࠨ࠾࡫࠶ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䊤"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊥"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䊦")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠫࠬ䊧")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭䊨"),headers,l1l111_l1_ (u"࠭ࠧ䊩"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭䊪"))
	if type==l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䊫"): block = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀฦัิัࠠศๆฦๅ้อๅ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࡭࠷ࠧ䊬"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠪࡦࡴࡾ࠭ࡰࡨࡩ࡭ࡨ࡫ࠧ䊭"): block = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࡪ࠴ࠫ䊮"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䊯"): block = re.findall(l1l111_l1_ (u"࠭ࡢࡵࡰ࠰࠶࠲ࡵࡶࡦࡴ࡯ࡥࡾ࠮࠮ࠫࡁࠬࡀࡸࡺࡹ࡭ࡧࡁࠫ䊰"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䊱"): block = re.findall(l1l111_l1_ (u"ࠨࡤࡷࡲ࠲࠷ࠠࡣࡶࡱ࠱ࡦࡨࡳࡰ࡮ࡼࠬ࠳࠰࠿ࠪࡤࡷࡲ࠲࠸ࠠࡣࡶࡱ࠱ࡦࡨࡳࡰ࡮ࡼࠫ䊲"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠩࡷࡺࠬ䊳"): block = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฮ้๐แำ์๋๊๋่ࠥโ์ีࠤ้อๆะ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡪࠦࠬ䊴"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䊵"),l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䊶")]:
		items = re.findall(l1l111_l1_ (u"࠭ࡳࡵࡻ࡯ࡩࡂࠨࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡱࡷࡸࡴࡳ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䊷"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺ࠽ࠣ࠵࡞࠴࠲࠿࡝ࠬࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡺࡴࡰ࡯࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䊸"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠨใํ่๊࠭䊹"),l1l111_l1_ (u"ࠩส่า๊โสࠩ䊺"),l1l111_l1_ (u"ࠪห้ำไใ้ࠪ䊻"),l1l111_l1_ (u"ࠫ฾ืึࠨ䊼"),l1l111_l1_ (u"ࠬࡘࡡࡸࠩ䊽"),l1l111_l1_ (u"࠭ࡓ࡮ࡣࡦ࡯ࡉࡵࡷ࡯ࠩ䊾"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭䊿"),l1l111_l1_ (u"ࠨษฯึฬวࠧ䋀")]
	for l1ll1l_l1_,l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l1ll111l1l11_l1_ in items:
		if type in [l1l111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䋁"),l1l111_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䋂")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l1ll111l1l11_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1ll1111l1ll_l1_,l1ll111l11ll_l1_,l1ll111l1l11_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡄࡼࡩࡦࡹࡀࡸࡷࡻࡥࠨ䋃"),l1l111_l1_ (u"ࠬ࠭䋄"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"࠭ศอ๊าอࠥ࠭䋅") in title or l1l111_l1_ (u"ࠧษฮ๋ำ์ࠦࠧ䋆") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䋇") + title.replace(l1l111_l1_ (u"ࠩหะํีษࠡࠩ䋈"),l1l111_l1_ (u"ࠪࠫ䋉")).replace(l1l111_l1_ (u"ࠫอา่ะ้ࠣࠫ䋊"),l1l111_l1_ (u"ࠬ࠭䋋"))
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ䋌"))
		if l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ䋍") in title or l1l111_l1_ (u"ࠨษ็ั้่็ࠨ䋎") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣࡠࡩ࠱ࠧ䋏"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋐") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋑"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ䋒") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䋓"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䋔") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䋕"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠩࠪ䋖"):
		items = re.findall(l1l111_l1_ (u"ࠪࡠࡳࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䋗"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ䋘"),l1l111_l1_ (u"ࠬ࠭䋙"))
			if title!=l1l111_l1_ (u"࠭ࠧ䋚"):
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䋛"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ䋜")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䋝"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䋞"),headers,l1l111_l1_ (u"ࠫࠬ䋟"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䋠"))
	block = re.findall(l1l111_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡪࡶ࡯ࡩࡃ࠴ࠪࡀࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࡟࠵࠳࠹࡞࠭ࠬࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䋡"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼศๆะ่็ํࠩࠡ࡝࠳࠱࠾ࡣࠫࠨ䋢"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䋣") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶࡒࡺࡳࡢࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䋤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䋥"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"ࠫ࠭อไฮๆๅอࢁอไฮๆๅ๋࠮࠳ࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠨ䋦"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ䋧"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"࠭ࠨࠪ࠯ࠫ࡟࠵࠳࠹࡞࠭ࠬࠫ䋨"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䋩"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠨࠢࠪ䋪") + title[0][1]
			else: title = l1l111_l1_ (u"ࠩࠪ䋫")
			title = name + l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ䋬") + l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ䋭") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䋮"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"࠭ศอ๊าอࠥ࠭䋯") in title or l1l111_l1_ (u"ࠧษฮ๋ำ์ࠦࠧ䋰") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䋱") + title.replace(l1l111_l1_ (u"ࠩหะํีษࠡࠩ䋲"),l1l111_l1_ (u"ࠪࠫ䋳")).replace(l1l111_l1_ (u"ࠫอา่ะ้ࠣࠫ䋴"),l1l111_l1_ (u"ࠬ࠭䋵"))
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䋶"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll1111lll1_l1_ = url.split(l1l111_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䋷"))
	l1lllll1_l1_ = l1ll1111lll1_l1_[0]
	del l1ll1111lll1_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䋸"),headers,l1l111_l1_ (u"ࠩࠪ䋹"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䋺"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡫ࡵ࡮ࡵ࠯ࡶ࡭ࡿ࡫࠺ࠡ࠴࠸ࡴࡽࡁࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䋻"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1ll1111lll1_l1_: l1ll1111lll1_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1ll1111lll1_l1_:
		if l1l111_l1_ (u"ࠬࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࠫ䋼") in l1ll1ll_l1_:
			l1ll1111l11l_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1ll1111l11l_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡍࡢ࡫ࡱࠫ䋽"))
	for l1ll1ll_l1_ in l1ll1111lll1_l1_:
		if l1l111_l1_ (u"ࠧ࠻࠱࠲ࡺࡧ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࠪ䋾") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䋿"),headers,l1l111_l1_ (u"ࠩࠪ䌀"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ䌁"))
			html = html.decode(l1l111_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡷ࠲࠷࠲࠶࠸ࠪ䌂")).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䌃"))
			html = html.replace(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡧࡴࡳ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌄"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌅"))
			html = html.replace(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌆"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌇"))
			html = html.replace(l1l111_l1_ (u"ࠪࡀ࠴ࡧ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡣࡴࠣ࠳ࡃࡂࡤࡪࡸࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࡂࠬ䌈"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䌉"))
			html = html.replace(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡢࡰࡴࡧࡩࡷࠨࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠨ䌊"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌋"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ䌌"),html,re.DOTALL)
			if l11llll_l1_:
				l1ll1111l1l1_l1_,l1ll111l1111_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠨࠩ䌍")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠮ࠫࡁ࡟࠮ࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࠮ࠬ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䌎"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࠬ䌏") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠨ䌐")+l1l111_l1_ (u"ࠬࠩࠧ䌑")+l1l111_l1_ (u"࠭࠳࠴࠵࠾ࠤࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮ࡥࡲࡰࡴࡸ࠺ࠨ䌒")+l1l111_l1_ (u"ࠧࠤࠩ䌓")+l1l111_l1_ (u"ࠨ࠵࠶࠷ࠧࠦ࠯࠿ࠪ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䌔"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ䌕") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࠩ࠽ࡪࡵࠤࡸ࡯ࡺࡦ࠿ࠥ࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿࠭䌖")+l1l111_l1_ (u"ࠫࠨ࠭䌗")+l1l111_l1_ (u"ࠬ࠹࠳࠴࠽ࠣࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡤࡱ࡯ࡳࡷࡀࠧ䌘")+l1l111_l1_ (u"࠭ࠣࠨ䌙")+l1l111_l1_ (u"ࠧ࠴࠵࠶ࠦࠥ࠵࠾࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌚"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠨࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䌛")
						l1ll111l111l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࠬ࠳࠰࠿ࠪࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯ࠨ䌜"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠪࡂࠥ࠰ࠨ࡜ࡠ࠿ࡂࡢ࠱ࠩࠡࠬ࠿ࠫ䌝"),l1ll111l111l_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"ࠫࠥ࠭䌞").join(title)
						title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ䌟"))
						title = title.replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䌠"),l1l111_l1_ (u"ࠧࠡࠩ䌡")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䌢"),l1l111_l1_ (u"ࠩࠣࠫ䌣")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䌤"),l1l111_l1_ (u"ࠫࠥ࠭䌥")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䌦"),l1l111_l1_ (u"࠭ࠠࠨ䌧")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䌨"),l1l111_l1_ (u"ࠨࠢࠪ䌩"))
						l1ll1111l1l1_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩฦาฯืࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษ࠼ࠪ䌪"), l1ll1111l1l1_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1ll1111l1l1_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰ࠮ࠨࠧ䌫"),block,re.DOTALL)
				l1ll1111l111_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1ll1111l111_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡋࡵࡲࡶ࡯ࠪ䌬"))
				block = block.replace(l1l111_l1_ (u"ࠬๆࠧ䌭"),l1l111_l1_ (u"࠭ࠧ䌮"))
				block = block.replace(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ䌯"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ䌰"))
				block = block.replace(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࡣࡰ࡯࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ䌱"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䌲"))
				block = block.replace(l1l111_l1_ (u"ุࠫ๐ัโำสฮࠥอไหฯ่๎้࠭䌳"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ䌴"))
				block = block.replace(l1l111_l1_ (u"࠭ั้ษห฻ࠥอไหฯ่๎้࠭䌵"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ䌶"))
				block = block.replace(l1l111_l1_ (u"ࠨีํีๆืวหࠢสฺ่๊ว่ัࠪ䌷"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䌸"))
				block = block.replace(l1l111_l1_ (u"ࠪีํอศุࠢสฺ่๊ว่ัࠪ䌹"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ䌺"))
				l1ll1111ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯࡝ࡦ࠮ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䌻"),block,re.DOTALL)
				for l1ll1111llll_l1_ in l1ll1111ll11_l1_:
					type = re.findall(l1l111_l1_ (u"࠭ࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࠫ䌼"),l1ll1111llll_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠧࡣࡱࡷ࡬ࠬ䌽"): type = l1l111_l1_ (u"ࠨࡡࡢࠫ䌾")+type[0]
						else: type = l1l111_l1_ (u"ࠩࠪ䌿")
					items = re.findall(l1l111_l1_ (u"ࠪࠬࡄࡂࠡࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳࠮࠮࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫ࠾࠲ࡪࡴࡴࡴ࠿࠰࠭ࡃࢁࡢࡷࠬ࡝ࠣࡠࡼࡣࠪ࠽ࡤࡵࠤ࠴ࡄ࠮ࠫࡁࠬ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯࠯ࠬࡂ࠭ࠧ࠭䍀"),l1ll1111llll_l1_,re.DOTALL)
					for l1ll1111ll1l_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"ࠫ࠭ࡢࡷࠬ࡝ࠣࡠࡼࡣࠪࠪ࠾ࠪ䍁"),l1ll1111ll1l_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䍂") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1l1l1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"࠭ࠧ䍃"),headers,l1l111_l1_ (u"ࠧࠨ䍄"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭䍅"))
	items = re.findall(l1l111_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䍆"),html,re.DOTALL)
	if items:
		l1ll111l1l1l_l1_ = items[-1]
		l1llll_l1_.append(l1ll111l1l1l_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡴࡨࡩ࡭ࡧࠪ䍇"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䍈"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭䍉"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ䍊"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ䍋"),l1l111_l1_ (u"ࠨ࠭ࠪ䍌"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪ䍍"),headers,l1l111_l1_ (u"ࠪࠫ䍎"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䍏"))
	items = re.findall(l1l111_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡯ࡱࡶ࡬ࡳࡳࡄࠧ䍐"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"࠭ࠧ䍑") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠧศๆๆ่ࠥ๎ศะ๊้ࠤๆ๊สาࠩ䍒") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ䍓"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠩࠪ䍔")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ䍕")+search+l1l111_l1_ (u"ࠫࠫࡳࡣࡢࡶࡀࠫ䍖")+category
	l1lll11_l1_(url)
	return
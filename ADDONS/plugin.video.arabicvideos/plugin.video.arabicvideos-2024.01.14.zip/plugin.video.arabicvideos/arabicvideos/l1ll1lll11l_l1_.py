# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ⸳")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ⸴")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
l1ll1ll1111_l1_ = l1l11l1_l1_[l1ll1_l1_][3]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==20: l1lll_l1_ = l1ll1ll111l_l1_()
	elif mode==21: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==22: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==23: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==24: l1lll_l1_ = PLAY(url,text)
	elif mode==25: l1lll_l1_ = l1ll1l11l1l_l1_(url)
	elif mode==27: l1lll_l1_ = l1ll1llll_l1_(url)
	elif mode==28: l1lll_l1_ = l1ll1ll11ll_l1_()
	elif mode==29: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll1ll111l_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸵"),l1lllll_l1_+l1l111_l1_ (u"ฺࠧำห๎ࠬ⸶"),l111l1_l1_,21,l1l111_l1_ (u"ࠨࠩ⸷"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⸸"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸹"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⸺"),l1l1l1l1l1_l1_,21,l1l111_l1_ (u"ࠬ࠭⸻"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⸼"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸽"),l1lllll_l1_+l1l111_l1_ (u"ࠨใสีุ๏ࠧ⸾"),l1ll1l1lll1_l1_,21,l1l111_l1_ (u"ࠩࠪ⸿"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⹀"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹁"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็วาี์ࠤ࠷࠭⹂"),l1ll1ll1111_l1_,21,l1l111_l1_ (u"࠭ࠧ⹃"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⹄"))
	return
def l1ll1ll11ll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⹅"),l1lllll_l1_+l1l111_l1_ (u"ࠩ฼ีอ๐ࠧ⹆"),l111l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⹇"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⹈"),l1l1l1l1l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⹉"),l1lllll_l1_+l1l111_l1_ (u"࠭แศำึํࠬ⹊"),l1ll1l1lll1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⹋"),l1lllll_l1_+l1l111_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ⹌"),l1ll1ll1111_l1_,27)
	return
def l1l1l11_l1_(l1ll1ll1l11_l1_):
	l1ll1_l1_ = l1ll1ll1l11_l1_
	if l1ll1ll1l11_l1_==l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ⹍"): l1ll1ll1l11_l1_ = l111l1_l1_
	elif l1ll1ll1l11_l1_==l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ⹎"): l1ll1ll1l11_l1_ = l1l1l1l1l1_l1_
	else: l1ll1_l1_ = l1l111_l1_ (u"ࠫࠬ⹏")
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(l1ll1ll1l11_l1_)
	if l1lllll11ll_l1_==l1l111_l1_ (u"ࠬࡧࡲࠨ⹐") or l1ll1_l1_==l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ⹑"):
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⹒")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤาอไ๋หࠪ⹓")
		l11111111l_l1_ = l1l111_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥษอะอࠪ⹔")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤ࠲ࠦรษฮา๎ࠬ⹕")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠫอัࠠฮ์ࠣฦ๏ࠦแ๋ๆ่ࠫ⹖")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠬษแๅษ่ࠫ⹗")
		l1ll1l1ll11_l1_ = l1l111_l1_ (u"࠭ๅ้ีํๆ๎࠭⹘")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠧษำส้ั࠭⹙")
	elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⹚") or l1ll1_l1_==l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⹛"):
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣ࡭ࡳࠦࡳࡪࡶࡨࠫ⹜")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡃࡶࡴࡵࡩࡳࡺࠧ⹝")
		l11111111l_l1_ = l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡍࡣࡷࡩࡸࡺࠧ⹞")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠭ࠡࡃ࡯ࡴ࡭ࡧࡢࡦࡶࠪ⹟")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠧࡍ࡫ࡹࡩࠥ࡯ࡆࡪ࡮ࡰࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠬ⹠")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠨࡏࡲࡺ࡮࡫ࡳࠨ⹡")
		l1ll1l1ll11_l1_ = l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⹢")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠪࡗ࡭ࡵࡷࡴࠩ⹣")
	elif l1lllll11ll_l1_ in [l1l111_l1_ (u"ࠫ࡫ࡧࠧ⹤"),l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⹥")]:
		l1ll1l11lll_l1_ = l1l111_l1_ (u"࠭ฬิฬฯ์ࠥีัࠡีส໐ฯ࠭⹦")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠧิำํห้ࠦ࠭ࠡฮสี໑࠭⹧")
		l11111111l_l1_ = l1l111_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢลาึ໒ๆࠨ⹨")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠩึี๏อไࠡ࠯ࠣห้็ศศࠩ⹩")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠪຂำฺࠠำ่า๋ࠥอ๊ࠡใํ่๊࠭⹪")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠫๆ๐ไๆࠩ⹫")
		l1ll1l1ll11_l1_ = l1l111_l1_ (u"๋่ࠬิ์ๅํࠬ⹬")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"࠭ศา่ส้์ࠦ็ศࠩ⹭")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹮"),l1lllll_l1_+l1ll1l11lll_l1_,l1ll1ll1l11_l1_,29,l1l111_l1_ (u"ࠨࠩ⹯"),l1l111_l1_ (u"ࠩࠪ⹰"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⹱"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⹲"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⹳")+l1lllll_l1_+l1ll1l1l1l1_l1_,l1ll1ll1l11_l1_,27)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⹴"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⹵"),l1l111_l1_ (u"ࠨࠩ⹶"),9999)
	l1llll1llll_l1_ = [l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⹷"),l1l111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⹸"),l1l111_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⹹")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫ⹺"),l1l111_l1_ (u"࠭ࠧ⹻"),l1l111_l1_ (u"ࠧࠨ⹼"),l1l111_l1_ (u"ࠨࠩ⹽"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⹾"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡦࡺࡺࡴࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮࠵ࡃࡰࡰࡷࡥࡨࡺࠧ⹿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⺀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if any(value in l1ll1ll_l1_ for value in l1llll1llll_l1_):
				url = l1ll1ll1l11_l1_+l1ll1ll_l1_
				if l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⺁") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺂"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⺃")+l1lllll_l1_+l1ll1l11ll1_l1_,url,22,l1l111_l1_ (u"ࠨࠩ⺄"),l1l111_l1_ (u"ࠩ࠴࠴࠵࠭⺅"))
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺆"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⺇")+l1lllll_l1_+l11111111l_l1_,url,22,l1l111_l1_ (u"ࠬ࠭⺈"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⺉"))
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⺊"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⺋")+l1lllll_l1_+l1ll1l1l111_l1_,url,22,l1l111_l1_ (u"ࠩࠪ⺌"),l1l111_l1_ (u"ࠪ࠶࠵࠷ࠧ⺍"))
				elif l1l111_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⺎") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺏"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⺐")+l1lllll_l1_+l1ll1l1l11l_l1_,url,22,l1l111_l1_ (u"ࠧࠨ⺑"),l1l111_l1_ (u"ࠨ࠳࠳࠴ࠬ⺒"))
				elif l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⺓") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺔"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⺕")+l1lllll_l1_+l1ll1l1ll11_l1_,url,25,l1l111_l1_ (u"ࠬ࠭⺖"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⺗"))
				elif l1l111_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⺘") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⺙"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⺚")+l1lllll_l1_+l1ll1l1l1ll_l1_,url,22,l1l111_l1_ (u"ࠪࠫ⺛"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⺜"))
	return html
def l1ll1l11l1l_l1_(url):
	l1ll1ll1l11_l1_ = l1ll1l1ll1l_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭⺝"),l1l111_l1_ (u"࠭ࠧ⺞"),l1l111_l1_ (u"ࠧࠨ⺟"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡎࡗࡖࡍࡈࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⺠"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣ࠮ࡶࡲࡳࡱࡹ࠭ࡩࡧࡤࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡒࡻࡳࡪࡥ࠰ࡦࡴࡪࡹࠨ⺡"),html,re.DOTALL)
	block = l11llll_l1_[0]
	title = re.findall(l1l111_l1_ (u"ࠪࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩ⺢"),block,re.DOTALL)[0]
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺣"),l1lllll_l1_+title,url,22,l1l111_l1_ (u"ࠬ࠭⺤"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⺥"))
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⺦"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⺧"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1l111_l1_ (u"ࠩࠪ⺨"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⺩"))
	return
def l1lll11_l1_(url,l1llllll1_l1_):
	l1ll1ll1l11_l1_ = l1ll1l1ll1l_l1_(url)
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
	type = url.split(l1l111_l1_ (u"ࠫ࠴࠭⺪"))[-1]
	l1ll1l111l1_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	if type==l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⺫") and l1llllll1_l1_==l1l111_l1_ (u"࠭࠰ࠨ⺬"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ⺭"),l1l111_l1_ (u"ࠨࠩ⺮"),l1l111_l1_ (u"ࠩࠪ⺯"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⺰"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯࠱ࡧࡵࡤࡺࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡰࡹࠪ⺱"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠬ࠳࠰࠿ࠪࡀ࠱࠮ࡄ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⺲"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1ll1ll_l1_
			l1ll1l_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺳"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l111l1_l1_+l1l111_l1_ (u"ࠧ࠱࠳ࠪ⺴"))
	l1ll1l111ll_l1_=0
	if type==l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⺵"): category=l1l111_l1_ (u"ࠩ࠶ࠫ⺶")
	if type==l1l111_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⺷"): category=l1l111_l1_ (u"ࠫ࠺࠭⺸")
	if type==l1l111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⺹"): category=l1l111_l1_ (u"࠭࠷ࠨ⺺")
	if type in [l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⺻"),l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⺼"),l1l111_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⺽")] and l1llllll1_l1_!=l1l111_l1_ (u"ࠪ࠴ࠬ⺾"):
		l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠫ࠴ࡎ࡯࡮ࡧ࠲ࡔࡦ࡭ࡥࡪࡰࡪࡍࡹ࡫࡭ࡀࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ⺿")+category+l1l111_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ⻀")+l1llllll1_l1_+l1l111_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡱࡵࡨࡪࡸࡢࡺ࠿ࠪ⻁")+l1ll1l111l1_l1_
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⻂"),l1l111_l1_ (u"ࠨࠩ⻃"),l1l111_l1_ (u"ࠩࠪ⻄"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⻅"))
		items = re.findall(l1l111_l1_ (u"ࠫࠧࡏࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡗ࡭ࡹࡲࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠮ࡃࠧࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⻆"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ⻇"),l1l111_l1_ (u"࠭ࠧ⻈"))
			title = title.replace(l1l111_l1_ (u"ࠧࠣࠩ⻉"),l1l111_l1_ (u"ࠨࠩ⻊"))
			l1ll1l111ll_l1_ += 1
			l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1l111_l1_ (u"ࠩ࠲ࠫ⻋") + type + l1l111_l1_ (u"ࠪ࠳ࡈࡵ࡮ࡵࡧࡱࡸ࠴࠭⻌") + id
			l1ll1l_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⻍"): addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⻎"),l1lllll_l1_+title,l1ll1ll_l1_,24,l1ll1l_l1_,l1ll1l111l1_l1_+l1l111_l1_ (u"࠭࠰࠲ࠩ⻏"))
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻐"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l111l1_l1_+l1l111_l1_ (u"ࠨ࠲࠴ࠫ⻑"))
	if type==l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⻒"):
		html = l1l1llll_l1_(l11l1l1_l1_,l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡍࡳࡪࡥࡹࡁࡳࡥ࡬࡫࠽ࠨ⻓")+l1llllll1_l1_,l1l111_l1_ (u"ࠫࠬ⻔"),l1l111_l1_ (u"ࠬ࠭⻕"),l1l111_l1_ (u"࠭ࠧ⻖"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠳ࡳࡦࠪ⻗"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠲ࡪࡥ࡮ࡱࠫ࠲࠯ࡅࠩࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱ࠱ࡩ࡫࡭ࡰࠩ⻘"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ⻙"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1l111ll_l1_ += 1
			l1ll1l_l1_ = l1ll1ll1l11_l1_ + l1ll1l_l1_
			l1ll1ll_l1_ = l1ll1ll1l11_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⻚"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⻛"))
	if l1ll1l111ll_l1_>20:
		title=l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⻜")
		if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⻝"): title = l1l111_l1_ (u"ࠧࡑࡣࡪࡩࠥ࠭⻞")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⻟"): title = l1l111_l1_ (u"ุࠩๅาํࠠࠨ⻠")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⻡"): title = l1l111_l1_ (u"ฺࠫ็อ่ࠢࠪ⻢")
		for l1ll1l1llll_l1_ in range(1,11) :
			if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
				l1ll1l11l11_l1_ = l1l111_l1_ (u"ࠬ࠶ࠧ⻣")+str(l1ll1l1llll_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻤"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,22,l1l111_l1_ (u"ࠧࠨ⻥"),l1ll1l111l1_l1_+l1ll1l11l11_l1_[-2:])
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	if not l1llllll1_l1_: l1llllll1_l1_ = 0
	l1ll1ll1l11_l1_ = l1ll1l1ll1l_l1_(url)
	l1ll1ll1l1l_l1_ = l1ll1l1ll1l_l1_(url)
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
	parts = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ⻦"))
	id,type = parts[-1],parts[3]
	l1ll1l111l1_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	l1ll1l111ll_l1_ = 0
	if type==l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⻧"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ⻨"),l1l111_l1_ (u"ࠫࠬ⻩"),l1l111_l1_ (u"ࠬ࠭⻪"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⻫"))
		items = re.findall(l1l111_l1_ (u"ࠧࡄࡱࡰࡱࡪࡴࡴࡠࡲࡤࡲࡪࡲ࡟ࡊࡶࡨࡱ࠳࠰࠿ࡱࡀࠫ࠲࠯ࡅࠩ࠽࡫࠱࠯ࡄࡼࡡࡳࠢ࡬ࡲࡹ࡫ࡲࡠࠢࡀࠤ࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪ࡞ࠪࠫ⻬"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤࠬ⻭")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⻮"): title = l1l111_l1_ (u"ࠪࠤ࠲ࠦࡅࡱ࡫ࡶࡳࡩ࡫ࠠࠨ⻯")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⻰"): title = l1l111_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ⻱")
		if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⻲"): title = l1l111_l1_ (u"ࠧࠡ࠯ࠣๆุ๋สࠡࠩ⻳")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⻴"): l1ll1ll11l1_l1_ = l1l111_l1_ (u"ࠩࠪ⻵")
		else: l1ll1ll11l1_l1_ = l1lllll11ll_l1_
		l1ll1lll111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠨ࡝ࠩ࠱࠮ࡄࡢࠧࡠࠫࠫ࠲࠯ࡅࠩࠣࡀࠪ⻶"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1ll1ll_l1_ in items:
			for l1l1lll_l1_ in range(int(count),0,-1):
				l1ll1ll1lll_l1_ = l1ll1l_l1_ + l1ll1ll11l1_l1_ + id + l1l111_l1_ (u"ࠫ࠴࠭⻷") + str(l1l1lll_l1_) + l1l111_l1_ (u"ࠬ࠴ࡰ࡯ࡩࠪ⻸")
				l1ll1l11ll1_l1_ = name + title + str(l1l1lll_l1_)
				l1ll1l11ll1_l1_ = unescapeHTML(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⻹"),l1lllll_l1_+l1ll1l11ll1_l1_,url,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠧࠨ⻺"),str(l1l1lll_l1_))
	elif type==l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⻻"):
		l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡒࡤ࡫ࡪ࡯࡮ࡨࡃࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡎࡺࡥ࡮ࡁ࡬ࡨࡂ࠭⻼")+str(id)+l1l111_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⻽")+l1llllll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬ࡯ࡳࡦࡨࡶࡧࡿ࠽࠲ࠩ⻾")
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⻿"),l1l111_l1_ (u"࠭ࠧ⼀"),l1l111_l1_ (u"ࠧࠨ⼁"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭⼂"))
		items = re.findall(l1l111_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡛࡯ࡤࡦࡱࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡅ࡫ࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⼃"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦࠧ⼄")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫࡪࡴࠧ⼅"): title = l1l111_l1_ (u"ࠬࠦ࠭ࠡࡇࡳ࡭ࡸࡵࡤࡦࠢࠪ⼆")
		if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡦࡢࠩ⼇"): title = l1l111_l1_ (u"ࠧࠡ࠯ࠣๆุ๋สࠡࠩ⼈")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⼉"): title = l1l111_l1_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫ⼊")
		for l1l1lll_l1_,l1ll1l_l1_,l1ll1ll_l1_,desc,name in items:
			l1ll1l111ll_l1_ += 1
			l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
			name = escapeUNICODE(name)
			l1ll1l11ll1_l1_ = name + title + str(l1l1lll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⼋"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠫࠬ⼌"),str(l1ll1l111ll_l1_))
	elif type==l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⼍"):
		if l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺࠧ⼎") in url and l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⼏") not in url:
			l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿ࠪ⼐")+str(id)+l1l111_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ⼑")+l1llllll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠴ࠬ⼒")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⼓"),l1l111_l1_ (u"ࠬ࠭⼔"),l1l111_l1_ (u"࠭ࠧ⼕"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠵ࡵࡨࠬ⼖"))
			items = re.findall(l1l111_l1_ (u"ࠨࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⼗"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l111ll_l1_ += 1
				l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11ll1_l1_ = name + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭⼘") + title
				l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬ⼙"))
				l1ll1l11ll1_l1_ = escapeUNICODE(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⼚"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠬ࠭⼛"),str(l1ll1l111ll_l1_))
		elif l1l111_l1_ (u"࠭ࡃ࡭࡫ࡳࡷࠬ⼜") in url:
			l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾࠲ࠩࡴࡦ࡭ࡥ࠾ࠩ⼝")+l1llllll1_l1_+l1l111_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠳࠸ࠫ⼞")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⼟"),l1l111_l1_ (u"ࠪࠫ⼠"),l1l111_l1_ (u"ࠫࠬ⼡"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠴ࡵࡪࠪ⼢"))
			items = re.findall(l1l111_l1_ (u"࠭ࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⼣"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
				l1ll1l111ll_l1_ += 1
				l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11ll1_l1_ = title.strip(l1l111_l1_ (u"ࠧࠡࠩ⼤"))
				l1ll1l11ll1_l1_ = escapeUNICODE(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⼥"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠩࠪ⼦"),str(l1ll1l111ll_l1_))
		elif l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⼧") in url:
			if l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠶ࠨ⼨") in url:
				l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃ࠰ࠧࡲࡤ࡫ࡪࡃࠧ⼩")+l1llllll1_l1_+l1l111_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠶ࠨ⼪")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⼫"),l1l111_l1_ (u"ࠨࠩ⼬"),l1l111_l1_ (u"ࠩࠪ⼭"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠺ࡺࡨࠨ⼮"))
			elif l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠴ࠨ⼯") in url:
				l1lllll1_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃ࠰ࠧࡲࡤ࡫ࡪࡃࠧ⼰")+l1llllll1_l1_+l1l111_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠴ࠨ⼱")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⼲"),l1l111_l1_ (u"ࠨࠩ⼳"),l1l111_l1_ (u"ࠩࠪ⼴"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠻ࡺࡨࠨ⼵"))
			items = re.findall(l1l111_l1_ (u"ࠫࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙ࡳ࡮ࡩࡥࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡗ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⼶"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l111ll_l1_ += 1
				l1ll1ll1lll_l1_ = l1ll1ll1l1l_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11ll1_l1_ = name + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ⼷") + title
				l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ⼸"))
				l1ll1l11ll1_l1_ = escapeUNICODE(l1ll1l11ll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⼹"),l1lllll_l1_+l1ll1l11ll1_l1_,l1lllll1_l1_,24,l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠨࠩ⼺"),str(l1ll1l111ll_l1_))
	if type==l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⼻") or type==l1l111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⼼"):
		if l1ll1l111ll_l1_>25:
			title=l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⼽")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⼾"): title = l1l111_l1_ (u"࠭ࠠࡑࡣࡪࡩࠥ࠭⼿")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⽀"): title = l1l111_l1_ (u"ࠨุࠢๅาํࠠࠨ⽁")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⽂"): title = l1l111_l1_ (u"ࠪࠤฺ็อ่ࠢࠪ⽃")
			for l1ll1l1llll_l1_ in range(1,11):
				if not l1llllll1_l1_==str(l1ll1l1llll_l1_):
					l1ll1l11l11_l1_ = l1l111_l1_ (u"ࠫ࠵࠭⽄")+str(l1ll1l1llll_l1_)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⽅"),l1lllll_l1_+title+str(l1ll1l1llll_l1_),url,23,l1l111_l1_ (u"࠭ࠧ⽆"),l1ll1l111l1_l1_+l1ll1l11l11_l1_[-2:])
	return
def PLAY(url,l1l1lll_l1_):
	l1ll1ll1l1l_l1_ = l1ll1l1ll1l_l1_(url)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ⽇"),l1l111_l1_ (u"ࠨࠩ⽈"),l1l111_l1_ (u"ࠩࠪ⽉"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⽊"))
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹ࡭ࡩ࡫࡯࠾ࠤࠫ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࡡࠬࠬ࠳࠰࠿ࠪࠤࡁࠫ⽋"),html,re.DOTALL)
	if items:
		l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ⽌"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll11ll_l1_+id+l1l111_l1_ (u"࠭࠯࠭ࠩ⽍")+l1l1lll_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ⽎")+l1l1lll_l1_+l1l111_l1_ (u"ࠨࡡࠪ⽏")+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ⽐"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࠬࠬࡡ࠴࠮ࠫࡁࠬࠦࠬ⽑"),html,re.DOTALL)
	if items:
		l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠫ࠴࠭⽒"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll11ll_l1_+id+l1l111_l1_ (u"ࠬ࠵ࠧ⽓")+l1l1lll_l1_+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭࡭ࡱ࠶ࠣࡹࡷࡲࠧ⽔"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⽕"),html,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠱࠲ࠫ⽖"),l1l111_l1_ (u"ࠩ࠲ࠫ⽗"))
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠠࡴࡴࡦࠫ⽘"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⽙"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll1l1l_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࡳࡰ࠵ࠢࡤࡨࡩࡸࡥࡴࡵࠪ⽚"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࠭ࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⽛"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll1l1l_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲ࠶ࠤࡦࡪࡤࡳࡧࡶࡷࠬ⽜"))
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==1: l1ll1ll_l1_ = l1llll_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ⽝"), l1l1lll1_l1_)
		if l11l11l_l1_ == -1 : return
		l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⽞"))
	return
def l1ll1l1ll1l_l1_(url):
	if l111l1_l1_ in url: l1lll11ll1l_l1_ = l111l1_l1_
	elif l1l1l1l1l1_l1_ in url: l1lll11ll1l_l1_ = l1l1l1l1l1_l1_
	elif l1ll1l1lll1_l1_ in url: l1lll11ll1l_l1_ = l1ll1l1lll1_l1_
	elif l1ll1ll1111_l1_ in url: l1lll11ll1l_l1_ = l1ll1ll1111_l1_
	else: l1lll11ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ⽟")
	return l1lll11ll1l_l1_
def l1ll1ll1ll1_l1_(url):
	if   l111l1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠫࡦࡸࠧ⽠")
	elif l1l1l1l1l1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠬ࡫࡮ࠨ⽡")
	elif l1ll1l1lll1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"࠭ࡦࡢࠩ⽢")
	elif l1ll1ll1111_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⽣")
	else: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠨࠩ⽤")
	return l1lllll11ll_l1_
def l1ll1llll_l1_(url):
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(url)
	l1lllll1_l1_ = url + l1l111_l1_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡎ࡬ࡺࡪ࠭⽥")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⽦"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⽧"),l1l111_l1_ (u"ࠬ࠭⽨"),l1l111_l1_ (u"࠭ࠧ⽩"),l1l111_l1_ (u"ࠧࠨ⽪"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ⽫"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⽬"),html,re.DOTALL)
	l1llllll_l1_ = items[0]
	l1llll111_l1_(l1llllll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⽭"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭⽮"),l1l111_l1_ (u"ࠬ࠱ࠧ⽯"))
	if l11_l1_:
		l1111111l_l1_ = [ l111l1_l1_ , l1l1l1l1l1_l1_ , l1ll1l1lll1_l1_ , l1ll1ll1111_l1_ ]
		l1ll11111_l1_ = [ l1l111_l1_ (u"ู࠭าสํࠫ⽰") , l1l111_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨ⽱") , l1l111_l1_ (u"ࠨใสีุ๏ࠧ⽲") , l1l111_l1_ (u"ࠩไหึู้ࠡ࠴ࠪ⽳") ]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็่฿ฯࠠศๆ่๊ฬูศส࠼ࠪ⽴"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		l1l11l11_l1_ = l1111111l_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠫࡤࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࡣࠬ⽵") in options: l1l11l11_l1_ = l111l1_l1_
		elif l1l111_l1_ (u"ࠬࡥࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍࡥࠧ⽶") in options: l1l11l11_l1_ = l1l1l1l1l1_l1_
		else: l1l11l11_l1_ = l1l111_l1_ (u"࠭ࠧ⽷")
	if not l1l11l11_l1_: return
	l1lllll11ll_l1_ = l1ll1ll1ll1_l1_(l1l11l11_l1_)
	l1lllll1_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠢ࠰ࡊࡲࡱࡪ࠵ࡓࡦࡣࡵࡧ࡭ࡅࡳࡦࡣࡵࡧ࡭ࡹࡴࡳ࡫ࡱ࡫ࡂࠨ⽸") + l1lll1ll_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⽹"),l1l111_l1_ (u"ࠩࠪ⽺"),l1l111_l1_ (u"ࠪࠫ⽻"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ⽼"))
	items = re.findall(l1l111_l1_ (u"ࠬࠨࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡉࡡࡵࡧࡪࡳࡷࡿࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡍࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠩ⽽"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			if category in [l1l111_l1_ (u"࠭࠳ࠨ⽾"),l1l111_l1_ (u"ࠧ࠸ࠩ⽿")]:
				title = title.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ⾀"),l1l111_l1_ (u"ࠩࠪ⾁"))
				title = title.replace(l1l111_l1_ (u"ࠪࠦࠬ⾂"),l1l111_l1_ (u"ࠫࠬ⾃"))
				if category==l1l111_l1_ (u"ࠬ࠹ࠧ⾄"):
					type = l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⾅")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡢࡴࠪ⾆"): name = l1l111_l1_ (u"ࠨ็ึุ่๊ࠠ࠻ࠢࠪ⾇")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⾈"): name = l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠾ࠥ࠭⾉")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⾊"): name = l1l111_l1_ (u"ูࠬั๋ษ็ࠤ์อࠠ࠻ࠢࠪ⾋")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⾌"): name = l1l111_l1_ (u"ࠧิำํห้ࠦ็ศࠢ࠽ࠤࠬ⾍")
				elif category==l1l111_l1_ (u"ࠨ࠷ࠪ⾎"):
					type = l1l111_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⾏")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡥࡷ࠭⾐"): name = l1l111_l1_ (u"ࠫๆ๐ไๆࠢ࠽ࠤࠬ⾑")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⾒"): name = l1l111_l1_ (u"࠭ࡍࡰࡸ࡬ࡩࠥࡀࠠࠨ⾓")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⾔"): name = l1l111_l1_ (u"ࠨใํ่๊ࠦ࠺ࠡࠩ⾕")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⾖"): name = l1l111_l1_ (u"ࠪๅ้๋่ࠠษࠣ࠾ࠥ࠭⾗")
				elif category==l1l111_l1_ (u"ࠫ࠼࠭⾘"):
					type = l1l111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⾙")
					if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡡࡳࠩ⾚"): name = l1l111_l1_ (u"ࠧษำ้ห๊าࠠ࠻ࠢࠪ⾛")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⾜"): name = l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠣ࠾ࠥ࠭⾝")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠭⾞"): name = l1l111_l1_ (u"ࠫอืๆศ็๊ࠤ์อࠠ࠻ࠢࠪ⾟")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⾠"): name = l1l111_l1_ (u"࠭ศา่ส้์ࠦ็ศࠢ࠽ࠤࠬ⾡")
				title = name + title
				l1ll1ll_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠧ࠰ࠩ⾢") + type + l1l111_l1_ (u"ࠨ࠱ࡆࡳࡳࡺࡥ࡯ࡶ࠲ࠫ⾣") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11l11_l1_+l1ll1l_l1_
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⾤"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⾥"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗࠩ㮂")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㮃")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠫ࠵࠭㮄"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠬ࠷ࠧ㮅"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠲ࠨ㮆"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠧ࠴ࠩ㮇"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠨ࠶ࠪ㮈"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮉"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ㮊")+l1l111_l1_ (u"ࠫ็๎วว็ࠣๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠩ㮋"),l1l111_l1_ (u"ࠬ࠭㮌"),762)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮍"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭㮎")+l1l111_l1_ (u"ࠨไ๋หห๋ࠠโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠧ㮏"),l1l111_l1_ (u"ࠩࠪ㮐"),761)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮑"),l1l111_l1_ (u"ࠫࡤ࡚ࡖ࠱ࡡࠪ㮒")+l1l111_l1_ (u"่ࠬๆ้ษอࠤ๊์ࠠๆ๊สๆ฾ํวࠡษ็วฺ๊๊สࠩ㮓"),l1l111_l1_ (u"࠭ࠧ㮔"),101)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮕"),l1l111_l1_ (u"ࠨࡡࡗ࡚࠹ࡥࠧ㮖")+l1l111_l1_ (u"ࠩๅ๊ํอสࠡ็ัฮฬืษࠡ็้ࠤ๏๎ส๋๊หࠫ㮗"),l1l111_l1_ (u"ࠪࠫ㮘"),106)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮙"),l1l111_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ㮚")+l1l111_l1_ (u"࠭โ็๊สฮࠥ฿ัษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㮛"),l1l111_l1_ (u"ࠧࠨ㮜"),147)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮝"),l1l111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ㮞")+l1l111_l1_ (u"ࠪๆ๋๎วหࠢฦะ๋ฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ㮟"),l1l111_l1_ (u"ࠫࠬ㮠"),148)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮡"),l1l111_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬ㮢")+l1l111_l1_ (u"ࠧࠡࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ็้ࠤ๊๎โฺ้่ࠤࠥ࠭㮣"),l1l111_l1_ (u"ࠨࠩ㮤"),28)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㮥"),l1l111_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩ㮦")+l1l111_l1_ (u"ࠫ็์วสࠢส่๊฿วาใ้๋ࠣࠦๅ้ไ฼๋๊࠭㮧"),l1l111_l1_ (u"ࠬ࠭㮨"),41)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㮩"),l1l111_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭㮪")+l1l111_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ㮫"),l1l111_l1_ (u"ࠩࠪ㮬"),38)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㮭"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮮"),l1l111_l1_ (u"ࠬ࠭㮯"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮰"),l1l111_l1_ (u"ࠧࡠࡖ࡙࠵ࡤ࠭㮱")+l1l111_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣ฽ฬ๋ษࠨ㮲"),l1l111_l1_ (u"ࠩࠪ㮳"),102)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮴"),l1l111_l1_ (u"ࠫࡤ࡚ࡖ࠳ࡡࠪ㮵")+l1l111_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠฯษุอࠬ㮶"),l1l111_l1_ (u"࠭ࠧ㮷"),103)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮸"),l1l111_l1_ (u"ࠨࡡࡗ࡚࠸ࡥࠧ㮹")+l1l111_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ้๊แฮืࠪ㮺"),l1l111_l1_ (u"ࠪࠫ㮻"),104)
	return
def ITEMS(l1llll1llll_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡚ࡖࠨ㮼")+l1llll1llll_l1_+l1l111_l1_ (u"ࠬࡥࠧ㮽")
	l1l111llll1_l1_ = l1l1ll11l11_l1_(32)
	payload = {l1l111_l1_ (u"࠭ࡩࡥࠩ㮾"):l1l111_l1_ (u"ࠧࠨ㮿"),l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㯀"):l1l111llll1_l1_,l1l111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㯁"):l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㯂"),l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㯃"):l1llll1llll_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㯄"),l111l1_l1_,payload,l1l111_l1_ (u"࠭ࠧ㯅"),l1l111_l1_ (u"ࠧࠨ㯆"),l1l111_l1_ (u"ࠨࠩ㯇"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㯈"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠪࠬࡠࡤ࠻࡝ࡴ࡟ࡲࡢ࠱࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠬ࠳࠰࠿ࠪ࠽࠾ࠫ㯉"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"ࠫࡦࡲࠧ㯊"),l1l111_l1_ (u"ࠬࡇ࡬ࠨ㯋"))
			start = start.replace(l1l111_l1_ (u"࠭ࡅ࡭ࠩ㯌"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㯍"))
			start = start.replace(l1l111_l1_ (u"ࠨࡃࡏࠫ㯎"),l1l111_l1_ (u"ࠩࡄࡰࠬ㯏"))
			start = start.replace(l1l111_l1_ (u"ࠪࡉࡑ࠭㯐"),l1l111_l1_ (u"ࠫࡆࡲࠧ㯑"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠬࡇ࡬࠮ࠩ㯒"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㯓"))
			start = start.replace(l1l111_l1_ (u"ࠧࡂ࡮ࠣࠫ㯔"),l1l111_l1_ (u"ࠨࡃ࡯ࠫ㯕"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l1111l_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠩࠦࠫ㯖") in source: continue
			if source!=l1l111_l1_ (u"࡙ࠪࡗࡒࠧ㯗"): name = name+l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࠡࠢࠪ㯘")+source+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㯙")
			url = source+l1l111_l1_ (u"࠭࠻࠼ࠩ㯚")+server+l1l111_l1_ (u"ࠧ࠼࠽ࠪ㯛")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠨ࠽࠾ࠫ㯜")+l1llll1llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㯝"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠫ㯞")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㯟"),l1lllll_l1_+l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㯠"),l1l111_l1_ (u"࠭ࠧ㯡"),9999)
	return
def PLAY(id):
	source,server,l1l1l1111l_l1_,l1llll1llll_l1_ = id.split(l1l111_l1_ (u"ࠧ࠼࠽ࠪ㯢"))
	url = l1l111_l1_ (u"ࠨࠩ㯣")
	l1l111llll1_l1_ = l1l1ll11l11_l1_(32)
	if source==l1l111_l1_ (u"ࠩࡘࡖࡑ࠭㯤"): url = l1l1l1111l_l1_
	elif source==l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㯥"):
		url = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㯦")][0]+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ㯧")+l1l1l1111l_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㯨"),url)
		return
	elif source==l1l111_l1_ (u"ࠧࡈࡃࠪ㯩"):
		payload = { l1l111_l1_ (u"ࠨ࡫ࡧࠫ㯪") : l1l111_l1_ (u"ࠩࠪ㯫"), l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㯬") : l1l111llll1_l1_ , l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㯭") : l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠶࠭㯮") , l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㯯") : l1l111_l1_ (u"ࠧࠨ㯰") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㯱"),l111l1_l1_,payload,l1l111_l1_ (u"ࠩࠪ㯲"),False,l1l111_l1_ (u"ࠪࠫ㯳"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㯴"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㯵"),l1l111_l1_ (u"࠭ࠧ㯶"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㯷"),l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㯸"))
			return
		html = response.content
		cookies = response.cookies
		l1ll11ll1111_l1_ = cookies[l1l111_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩ࠭㯹")]
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㯺")]
		payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ㯻") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㯼") : l1l111llll1_l1_ , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㯽") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠲ࠨ㯾") , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㯿") : l1l111_l1_ (u"ࠩࠪ㰀") }
		headers = { l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ㰁") : l1l111_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤ࠾ࠩ㰂")+l1ll11ll1111_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㰃"),l111l1_l1_,payload,headers,l1l111_l1_ (u"࠭ࠧ㰄"),l1l111_l1_ (u"ࠧࠨ㰅"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㰆"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㰇"),l1l111_l1_ (u"ࠪࠫ㰈"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㰉"),l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㰊"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"࠭ࡲࡦࡵࡳࠦ࠿ࠨࠨࡩࡶࡷࡴ࠳࠰࠿࡮࠵ࡸ࠼࠮࠮࠮ࠫࡁࠬࠦࠬ㰋"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1ll11l1llll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠴࠺࠱ࠫ㰌")+server+l1l111_l1_ (u"ࠨ࠹࠺࠻࠴࠭㰍")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠩࡢࡌࡉ࠴࡭࠴ࡷ࠻ࠫ㰎")+params
		l1ll11l1lll1_l1_ = l1ll11l1llll_l1_.replace(l1l111_l1_ (u"ࠪ࠷࠻ࡀ࠷ࠨ㰏"),l1l111_l1_ (u"ࠫ࠹࠶࠺࠸ࠩ㰐")).replace(l1l111_l1_ (u"ࠬࡥࡈࡅ࠰ࡰ࠷ࡺ࠾ࠧ㰑"),l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㰒"))
		l1ll11ll111l_l1_ = l1ll11l1llll_l1_.replace(l1l111_l1_ (u"ࠧ࠴࠸࠽࠻ࠬ㰓"),l1l111_l1_ (u"ࠨ࠶࠵࠾࠼࠭㰔")).replace(l1l111_l1_ (u"ࠩࡢࡌࡉ࠴࡭࠴ࡷ࠻ࠫ㰕"),l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㰖"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"ࠫࡍࡊࠧ㰗"),l1l111_l1_ (u"࡙ࠬࡄ࠲ࠩ㰘"),l1l111_l1_ (u"࠭ࡓࡅ࠴ࠪ㰙")]
		l1llll_l1_ = [l1ll11l1llll_l1_,l1ll11l1lll1_l1_,l1ll11ll111l_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"ࠧࡏࡖࠪ㰚"):
		headers = { l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㰛") : l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㰜") }
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㰝") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㰞") : l1l111llll1_l1_ , l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㰟") : l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡒ࡙࠭㰠") , l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㰡") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㰢"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠩࠪ㰣"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㰤"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㰥"),l1l111_l1_ (u"ࠬ࠭㰦"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㰧"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㰨"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㰩")]
		url = url.replace(l1l111_l1_ (u"ࠩࠨ࠶࠵࠭㰪"),l1l111_l1_ (u"ࠪࠤࠬ㰫"))
		url = url.replace(l1l111_l1_ (u"ࠫࠪ࠹ࡄࠨ㰬"),l1l111_l1_ (u"ࠬࡃࠧ㰭"))
		if l1l111_l1_ (u"࠭ࡌࡦࡣࡵࡲࠬ㰮") in l1l1l1111l_l1_:
			url = url.replace(l1l111_l1_ (u"ࠧࡏࡖࡑࡒ࡮ࡲࡥࠨ㰯"),l1l111_l1_ (u"ࠨࠩ㰰"))
			url = url.replace(l1l111_l1_ (u"ࠩ࡯ࡩࡦࡸ࡮ࡪࡰࡪ࠵ࠬ㰱"),l1l111_l1_ (u"ࠪࡐࡪࡧࡲ࡯࡫ࡱ࡫ࠬ㰲"))
	elif source==l1l111_l1_ (u"ࠫࡕࡒࠧ㰳"):
		payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ㰴") : l1l1l1111l_l1_ , l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㰵") : l1l111llll1_l1_ , l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㰶") : l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡖࡌࠨ㰷") , l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㰸") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㰹"), l111l1_l1_, payload, l1l111_l1_ (u"ࠫࠬ㰺"),False,l1l111_l1_ (u"ࠬ࠭㰻"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ㰼"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㰽"),l1l111_l1_ (u"ࠨࠩ㰾"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㰿"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㱀"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㱁")]
		headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㱂"):response.headers[l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㱃")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㱄"),url, l1l111_l1_ (u"ࠨࠩ㱅"),headers , l1l111_l1_ (u"ࠩࠪ㱆"),l1l111_l1_ (u"ࠪࠫ㱇"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭㱈"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㱉"),l1l111_l1_ (u"࠭ࠧ㱊"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㱋"),l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㱌"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㱍"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"ࠪࡘࡆ࠭㱎"),l1l111_l1_ (u"ࠫࡋࡓࠧ㱏"),l1l111_l1_ (u"ࠬ࡟ࡕࠨ㱐"),l1l111_l1_ (u"࠭ࡗࡔ࠳ࠪ㱑"),l1l111_l1_ (u"ࠧࡘࡕ࠵ࠫ㱒"),l1l111_l1_ (u"ࠨࡔࡏ࠵ࠬ㱓"),l1l111_l1_ (u"ࠩࡕࡐ࠷࠭㱔")]:
		if source==l1l111_l1_ (u"ࠪࡘࡆ࠭㱕"): l1l1l1111l_l1_ = id
		headers = { l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㱖") : l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㱗") }
		payload = { l1l111_l1_ (u"࠭ࡩࡥࠩ㱘") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㱙") : l1l111llll1_l1_ , l1l111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㱚") : l1l111_l1_ (u"ࠩࡳࡰࡦࡿࠧ㱛")+source , l1l111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㱜") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㱝"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠬ࠭㱞"),l1l111_l1_ (u"࠭ࠧ㱟"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩ㱠"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㱡"),l1l111_l1_ (u"ࠩࠪ㱢"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㱣"),l1l111_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㱤"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㱥")]
		if source==l1l111_l1_ (u"࠭ࡆࡎࠩ㱦"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㱧"), url, l1l111_l1_ (u"ࠨࠩ㱨"), l1l111_l1_ (u"ࠩࠪ㱩"), False,l1l111_l1_ (u"ࠪࠫ㱪"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠺ࡸ࡭࠭㱫"))
			url = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㱬")]
			url = url.replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ㱭"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ㱮"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㱯"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧᝦ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡄࡏࡆࡣࠬᝧ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ์สโๆํ็ุ࠭ᝨ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==490: l1lll_l1_ = l1l1l11_l1_()
	elif mode==491: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==492: l1lll_l1_ = PLAY(url)
	elif mode==493: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==494: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==499: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᝩ"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪᝪ"),l1l111_l1_ (u"ࠪࠫᝫ"),l1l111_l1_ (u"ࠫࠬᝬ"),l1l111_l1_ (u"ࠬ࠭᝭"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᝮ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᝯ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠨ࠱ࠪᝰ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭᝱"))
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡵࡧࡵࠤࡆࡰࡡࡹ࡫ࡩࡽࡋ࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᝲ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡩ࡭ࡱࡺࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᝳ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡳࡱࡪ࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ᝴")+l1ll1ll_l1_+l1l111_l1_ (u"࠭࠮ࡱࡪࡳࠫ᝵")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᝶"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᝷")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᝸"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᝹"),l1l111_l1_ (u"ࠫࠬ᝺"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᝻"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᝼")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤใ็ห๊࠭᝽"),l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ฬ็ไศ็࠰ࡱࡴࡼࡩࡦࡵ࠰ࡪ࡮ࡲ࡭ࡦ࠱ࡩࡳࡷ࡫ࡩࡨࡰ࠰࡬ࡩ࠳วโๆส้࠲อฬ็ส์࠱࠷࠭᝾"),494,l1l111_l1_ (u"ࠩࠪ᝿"),l1l111_l1_ (u"ࠪࠫក"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨខ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬគ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨឃ")+l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠨង"),l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ู๊ไิๆสฮ࠴๋ำๅี็หฯ࠳วอ่หํࠬច"),494,l1l111_l1_ (u"ࠩࠪឆ"),l1l111_l1_ (u"ࠪࠫជ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨឈ"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪញ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨដ"),l1l111_l1_ (u"ࠧࠨឋ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧឌ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧឍ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠪ࠳ࠬណ"): continue
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩត") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬថ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨទ")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫធ"),url,l1l111_l1_ (u"ࠨࠩន"),l1l111_l1_ (u"ࠩࠪប"),l1l111_l1_ (u"ࠪࠫផ"),l1l111_l1_ (u"ࠫࠬព"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬភ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬម"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬយ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨរ"),l1lllll_l1_+title,l1ll1ll_l1_,491)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪល")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧវ"),url,l1l111_l1_ (u"ࠫࠬឝ"),l1l111_l1_ (u"ࠬ࠭ឞ"),l1l111_l1_ (u"࠭ࠧស"),l1l111_l1_ (u"ࠧࠨហ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧឡ"))
	html = response.content
	block = l1l111_l1_ (u"ࠩࠪអ")
	if l1l111_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨឣ") in url: block = html
	elif l1l111_l1_ (u"ࠫࡄࡹ࠽ࠨឤ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡢ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࠦࡲࡧ࡮ࡪࡨࡨࡷࡹࠨࠧឥ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬឦ"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࠨ࡭ࡢࡰ࡬ࡪࡪࡹࡴࠣࠩឧ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
	if not block: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨឨ"),l1l111_l1_ (u"ࠩไ๎้๋ࠧឩ"),l1l111_l1_ (u"ࠪห฿์๊สࠩឪ"),l1l111_l1_ (u"ࠫศเๆ๋หࠪឫ"),l1l111_l1_ (u"้ࠬไ๋สࠪឬ"),l1l111_l1_ (u"࠭วฺๆส๊ࠬឭ"),l1l111_l1_ (u"่ࠧัสๅࠬឮ"),l1l111_l1_ (u"ࠨ็หหึอษࠨឯ"),l1l111_l1_ (u"ࠩ฼ี฻࠭ឰ"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪឱ"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪឲ"),l1l111_l1_ (u"๋ࠬำาฯํอࠬឳ")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧ឴"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ឵"),title,re.DOTALL)
		if not l1l1lll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧា"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧិ") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩី") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫឹ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឺ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨុ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬូ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠨษ็ูๆำษࠡࠩួ"),l1l111_l1_ (u"ࠩࠪើ"))
			if title!=l1l111_l1_ (u"ࠪࠫឿ"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫៀ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫេ")+title,l1ll1ll_l1_,491)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪែ"),url,l1l111_l1_ (u"ࠧࠨៃ"),l1l111_l1_ (u"ࠨࠩោ"),l1l111_l1_ (u"ࠩࠪៅ"),l1l111_l1_ (u"ࠪࠫំ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬះ"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂࡶࡶࡷࡳࡳࡹࡂࡢࡴࡆࡳࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧៈ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ៉"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ៊"),l1l111_l1_ (u"ࠨࠩ់"),l1l111_l1_ (u"ࠩࠪ៌"),l1l111_l1_ (u"ࠪࠫ៍"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ៎"))
		html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭៏"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ័"))
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭៑"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ្ࠥࠫ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ៓") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ។"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ៕"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	elif l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩࡡࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࠣࡤࡲࡼࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ៖"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨៗ"))
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭៘"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ៙"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ៚"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫ៛"),l1l111_l1_ (u"ࠫࠬៜ"))
				if title!=l1l111_l1_ (u"ࠬ࠭៝"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭៞"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭៟")+title,l1ll1ll_l1_,491)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠨ࠱ࠪ០"))+l1l111_l1_ (u"ࠩ࠲ࡃࡻ࡯ࡥࡸ࠿࠴ࠫ១")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ២"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ៣"),l1l111_l1_ (u"ࠬ࠭៤"),l1l111_l1_ (u"࠭ࠧ៥"),l1l111_l1_ (u"ࠧࠨ៦"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ៧"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭៨"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠥࡨࡦࡺࡡ࠻ࠢࠪࡵࡂ࠮࠮ࠫࡁࠬࠪࠧ៩"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ៪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ៫"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ៬"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡵ࡬ࡥ࠱ࡶࡩࡷࡼࡥࡳࡵ࠲ࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ៭")+l11111l11_l1_+l1l111_l1_ (u"ࠨࠨ࡬ࡁࠬ៮")+l111111ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ៯")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ៰")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧࡗࡪࡸࡶࡦࡴࠥ࠲࠯ࡅࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៱"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111_l1_ (u"๋ࠬแืๆࠪ៲")
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩ៳")+title
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭៴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ៵"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ៶"))
			if l1l111_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ៷") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠫࡤࡥฮศืࠪ៸")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠬ࠭៹")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៺")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ៻")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ៼"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠩࠪ៽")):
	if not l1l11ll_l1_: l1l11ll_l1_ = l111l1_l1_
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ៾"),l1l111_l1_ (u"ࠫ࠰࠭៿"))
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠳ࡶࡨࡱࡁࡶࡁࠬ᠀")+search
	l1lll11_l1_(url)
	return
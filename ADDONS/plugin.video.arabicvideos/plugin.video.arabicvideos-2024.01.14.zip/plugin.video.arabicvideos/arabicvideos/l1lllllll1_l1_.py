# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨᥒ")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡆࡑࡓࡥࠧᥓ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩๅหห๋ส๋ࠩᥔ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==300: l1lll_l1_ = l1l1l11_l1_()
	elif mode==301: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==302: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==303: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==304: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==305: l1lll_l1_ = PLAY(url)
	elif mode==306: l1lll_l1_ = l1llllll1l_l1_()
	elif mode==309: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᥕ"),l1lllll_l1_+l1l111_l1_ (u"้๋ࠫวัษࠣห้๋่ใ฻ࠣฬ฼๐มࠨᥖ"),l1l111_l1_ (u"ࠬ࠭ᥗ"),306)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᥘ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᥙ"),l1l111_l1_ (u"ࠨࠩᥚ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᥛ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᥜ"),l1l111_l1_ (u"ࠫࠬᥝ"),309,l1l111_l1_ (u"ࠬ࠭ᥞ"),l1l111_l1_ (u"࠭ࠧᥟ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᥠ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᥡ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᥢ"),l1l111_l1_ (u"ࠪࠫᥣ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᥤ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᥥ"),l1l111_l1_ (u"࠭ࠧᥦ"),l1l111_l1_ (u"ࠧࠨᥧ"),l1l111_l1_ (u"ࠨࠩᥨ"),l1l111_l1_ (u"ࠩࠪᥩ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᥪ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࡮ࡥࡢࡦࡨࡶࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮ࡥࡢࡦࡨࡶࡃ࠭ᥫ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᥬ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨᥭ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᥮"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᥯")+l1lllll_l1_+title,l1ll1ll_l1_,301)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᥰ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᥱ"),l1l111_l1_ (u"ࠫࠬᥲ"),9999)
	l11ll1_l1_(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫᥳ"),html)
	return html
def l1llllll1l_l1_():
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧᥴ"),l1l111_l1_ (u"ࠧࠨ᥵"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᥶"),l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠢห฻๏วࠠๆ่ࠣห้๋ีะำࠣ࠲࠳ࠦศิสหࠤ็๐วๆࠢฦูาอศࠡษ็้ํู่ࠡสอุๆ๐ัࠡ็ะฮํ๐วหࠢฯ้๏฿ࠠึใะหฯࠦวๅ็๋ๆ฾ࠦ࠮࠯๋ࠢห้๎โหࠢส่฻อฦฺࠢํิ์ฮࠠโ์้ࠣ฾อไอหࠣฮู็๊าࠢสฺ่็อศฬࠣห้๋ิโำฬࠤ็ฮไࠡ฻ิฺ๋ࠥอห๊ํหฯํวࠡใํࠤ็๎วว็๋ࠣีอࠠศๆหี๋อๅอࠩ᥷"))
	return
def l11ll1_l1_(url,html=l1l111_l1_ (u"ࠪࠫ᥸")):
	if not html:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ᥹"),url,l1l111_l1_ (u"ࠬ࠭᥺"),l1l111_l1_ (u"࠭ࠧ᥻"),l1l111_l1_ (u"ࠧࠨ᥼"),l1l111_l1_ (u"ࠨࠩ᥽"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ᥾"))
		html = response.content
	seq = 0
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮ࠫࡁ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠯ࠧ᥿"),html,re.DOTALL)
	if l11llll_l1_:
		for block in l11llll_l1_:
			seq += 1
			items = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᦀ"),block,re.DOTALL)
			for title,test,l1ll1ll_l1_ in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᦁ"))
				if title==l1l111_l1_ (u"࠭ࠧᦂ"): title = l1l111_l1_ (u"ࠧษ๊๋์ํ๎ࠧᦃ")
				if l1l111_l1_ (u"ࠨࡧࡰࡂࡁࡧࠧᦄ") not in test:
					if block.count(l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ᦅ"))>0:
						l1llllll11_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᦆ"),block,re.DOTALL)
						for l1ll1ll_l1_ in l1llllll11_l1_:
							title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭ᦇ"))[-2]
							addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦈ"),l1lllll_l1_+title,l1ll1ll_l1_,301)
						continue
					else: l1ll1ll_l1_ = url+l1l111_l1_ (u"࠭࠿ࡴࡧࡴࡹࡪࡴࡣࡦ࠿ࠪᦉ")+str(seq)
				if not any(value in title for value in l11lll_l1_):
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᦊ"),l1lllll_l1_+title,l1ll1ll_l1_,302)
	else: l1lll11_l1_(url,html)
	return
def l1lll11_l1_(url,html=l1l111_l1_ (u"ࠨࠩᦋ")):
	if html==l1l111_l1_ (u"ࠩࠪᦌ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᦍ"),url,l1l111_l1_ (u"ࠫࠬᦎ"),l1l111_l1_ (u"ࠬ࠭ᦏ"),l1l111_l1_ (u"࠭ࠧᦐ"),l1l111_l1_ (u"ࠧࠨᦑ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᦒ"))
		html = response.content
	if l1l111_l1_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭ᦓ") in url:
		url,seq = url.split(l1l111_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᦔ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡂࡳࡦࡥࡷ࡭ࡴࡴ࠾࠯ࠬࡂࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠩࠨᦕ"),html,re.DOTALL)
		block = l11llll_l1_[int(seq)-1]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡨ࡯ࡥࡻࡁࠫᦖ"),html,re.DOTALL)
		block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡢ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᦗ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,data,l1ll1l_l1_ in items:
		title = re.findall(l1l111_l1_ (u"ࠧ࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁ࠲࠯ࡅ࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡲࡄࠧᦘ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫᦙ"),l1l111_l1_ (u"ࠩࠪᦚ")).strip(l1l111_l1_ (u"ࠪࠤࠬᦛ"))
		if not title or title==l1l111_l1_ (u"ࠫࠬᦜ"):
			title = re.findall(l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦࡃ࠴ࠪࡀ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᦝ"),data,re.DOTALL)
			if title: title = title[0].replace(l1l111_l1_ (u"࠭࡜࡯ࠩᦞ"),l1l111_l1_ (u"ࠧࠨᦟ")).strip(l1l111_l1_ (u"ࠨࠢࠪᦠ"))
			if not title or title==l1l111_l1_ (u"ࠩࠪᦡ"):
				title = re.findall(l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᦢ"),data,re.DOTALL)
				title = title[0].replace(l1l111_l1_ (u"ࠫࡡࡴࠧᦣ"),l1l111_l1_ (u"ࠬ࠭ᦤ")).strip(l1l111_l1_ (u"࠭ࠠࠨᦥ"))
		title = unescapeHTML(title)
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l1l1l1l_l1_ = l1ll1ll_l1_+data+l1ll1l_l1_
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰ࠩᦦ") in l1l1l1l_l1_ or l1l111_l1_ (u"ࠨ็ึุ่๊ࠧᦧ") in l1l1l1l_l1_ or l1l111_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࠦࠬᦨ") in l1l1l1l_l1_:
				if l1l111_l1_ (u"ࠪฬึอๅอࠩᦩ") in data: title = l1l111_l1_ (u"ࠫอืๆศ็ฯࠤࠬᦪ")+title
				elif l1l111_l1_ (u"๋ࠬำๅี็ࠫᦫ") in data or l1l111_l1_ (u"࠭ๅ้ี่ࠫ᦬") in data: title = l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧ᦭")+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᦮"),l1lllll_l1_+title,l1ll1ll_l1_,303,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᦯"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᦰ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᦱ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦲ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬᦳ")+title,l1ll1ll_l1_,302)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᦴ"),url,l1l111_l1_ (u"ࠨࠩᦵ"),l1l111_l1_ (u"ࠩࠪᦶ"),l1l111_l1_ (u"ࠪࠫᦷ"),l1l111_l1_ (u"ࠫࠬᦸ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠲ࡵࡷࠫᦹ"))
	html = response.content
	name = re.findall(l1l111_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡪࡶ࡯ࡩࡃ࠭ᦺ"),html,re.DOTALL)
	name = name[0].replace(l1l111_l1_ (u"ࠧࡽࠢึ๎๊อࠠ็ษ๋ࠫᦻ"),l1l111_l1_ (u"ࠨࠩᦼ")).replace(l1l111_l1_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫᦽ"),l1l111_l1_ (u"ࠪࠫᦾ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᦿ")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨᧀ"),l1l111_l1_ (u"࠭ࠠࠨᧁ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫᧂ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᧃ"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬᧄ"),l1l111_l1_ (u"ࠪࠫᧅ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᧆ"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᧇ"),l1lllll_l1_+title,l1ll1ll_l1_,304)
		else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	if l1l111_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨᧈ") not in url: url = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩᧉ"))+l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡪࡰࡪࠫ᧊")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭᧋"),url,l1l111_l1_ (u"ࠪࠫ᧌"),l1l111_l1_ (u"ࠫࠬ᧍"),l1l111_l1_ (u"ࠬ࠭᧎"),l1l111_l1_ (u"࠭ࠧ᧏"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ᧐"))
	html = response.content
	if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡱࡧࡲࡺ࠱ࠪ᧑") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧒"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᧓"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ᧔"),l1l111_l1_ (u"ࠬ࠭᧕")).strip(l1l111_l1_ (u"࠭ࠠࠨ᧖"))
			title = l1l111_l1_ (u"ࠧศๆะ่็ฯࠠࠨ᧗")+title
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᧘"),l1lllll_l1_+title,l1ll1ll_l1_,305)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡪࡺࡡࡪ࡮ࡶࠦ࠭࠴ࠪࡀࠫࠥࡶࡪࡲࡡࡵࡧࡧࠦࠬ᧙"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᧚"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ᧛"),l1l111_l1_ (u"ࠬ࠭᧜")).strip(l1l111_l1_ (u"࠭ࠠࠨ᧝"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᧞"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡩ࡯ࡩ࠲ࠫ᧟")
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭᧠"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ᧡"),l1l111_l1_ (u"ࠫࠬ᧢"),l1l111_l1_ (u"ࠬ࠭᧣"),l1l111_l1_ (u"࠭ࠧ᧤"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ᧥"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᧦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᧧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭᧨"),l1l111_l1_ (u"ࠫࠬ᧩")).strip(l1l111_l1_ (u"ࠬࠦࠧ᧪"))
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ᧫"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬ᧬")+l111l1ll_l1_[0]
				title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭᧭"))
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ᧮")
			l111lllll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᧯")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ᧰")+l111l1ll_l1_
			l1llll_l1_.append(l111lllll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠰࠱࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ᧲"),block,re.DOTALL)
		for l1ll1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭᧳")+l1ll1ll_l1_
			title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭᧴"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᧵")+title+l1l111_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ᧶")
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࡞ࠫࡿࡺࡸ࡬࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ᧷"),html,re.DOTALL)
		if l1ll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡳࡪࡥࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ᧸"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ᧹"),l1l111_l1_ (u"ࠧࠨ᧺")).strip(l1l111_l1_ (u"ࠨࠢࠪ᧻"))
				title = title.replace(l1l111_l1_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫ᧼"),l1l111_l1_ (u"ࠪࡇ࡮ࡳࡡࡏࡱࡺࠫ᧽"))
				l1ll1ll_l1_ = l1ll_l1_[0]+l1l111_l1_ (u"ࠫࡄࡧࡣࡵ࡫ࡲࡲࡂࡹࡷࡪࡶࡦ࡬ࠫ࡯࡮ࡥࡧࡻࡁࠬ᧾")+index+l1l111_l1_ (u"ࠬࠬࡩࡥ࠿ࠪ᧿")+id+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᨀ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᨁ")
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᨂ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪᨃ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫᨄ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ᨅ"),l1l111_l1_ (u"ࠬ࠱ࠧᨆ"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡀࡵࡀࠫᨇ")+search
	l1lll11_l1_(url)
	return
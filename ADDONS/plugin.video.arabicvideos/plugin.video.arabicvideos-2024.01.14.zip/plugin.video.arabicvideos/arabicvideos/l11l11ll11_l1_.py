# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫṖ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡋࡇࡃࡡࠪṗ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩṘ"):l1l111_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠫṙ")}
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==120: l1lll_l1_ = l1l1l11_l1_()
	elif mode==121: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==122: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==123: l1lll_l1_ = PLAY(url)
	elif mode==124: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Ṛ")+text)
	elif mode==125: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧṛ")+text)
	elif mode==129: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩṜ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪṝ"),l1l111_l1_ (u"ࠫࠬṞ"),129,l1l111_l1_ (u"ࠬ࠭ṟ"),l1l111_l1_ (u"࠭ࠧṠ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫṡ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ṣ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫṣ"),l1l111_l1_ (u"ࠪࠫṤ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨṥ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭Ṧ"),headers,l1l111_l1_ (u"࠭ࠧṧ"),l1l111_l1_ (u"ࠧࠨṨ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫṩ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࠤ࡮࠳ࡨࡰ࡯ࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࠤ࡮࠳ࡦࡰ࡮ࡧࡩࡷࠨࠧṪ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬṫ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫฬ๊ๅึษิ฽ฮ࠭Ṭ") in title: continue
			title = title.rsplit(l1l111_l1_ (u"ࠬࡄࠧṭ"),1)[1]
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨṮ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠧ࠰ࠩṯ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṰ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫṱ")+l1lllll_l1_+title,l1ll1ll_l1_,122)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨṲ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ṳ"),l1l111_l1_ (u"ࠬ࠭Ṵ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡱࡦ࡯࡮ࡍࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡺࡪࡸࡴࡪࡥࡤࡰࡉࡿ࡮ࡢ࡯࡬ࡧࠧ࠭ṵ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡱࡦࡤࠤࡧࡪࡢࠣࡀ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫṶ"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪṷ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠩ࠲ࠫṸ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪห้๋ีศำ฼อࠬṹ") in title: continue
			if l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭Ṻ") in l1ll1ll_l1_: continue
			if not title and l1l111_l1_ (u"ࠬ࠵ࡴࡷ࠱ࡤࡶࡦࡨࡩࡤࠩṻ") in l1ll1ll_l1_: title = l1l111_l1_ (u"࠭ๅิๆึ่ฬะฺࠠำห๎ฮ࠭Ṽ")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṽ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪṾ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧṿ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬẀ"),l1l111_l1_ (u"ࠫࠬẁ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࠩ࠰࠭ࡃ࠮ࡄࡅࡨࡻࡅࡩࡸࡺ࠼࠰ࡣࡁࠫẂ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨẃ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩẄ"))
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẅ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫẆ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧẇ"),url,l1l111_l1_ (u"ࠫࠬẈ"),headers,l1l111_l1_ (u"ࠬ࠭ẉ"),l1l111_l1_ (u"࠭ࠧẊ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ẋ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡶࡣࡸࡩࡲࡰ࡮࡯ࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩẌ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪẍ"),block,re.DOTALL)
	if l1l111_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬẎ") not in url:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẏ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨẐ"),url,125)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẑ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪẒ"),url,124)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ẓ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫẔ"),l1l111_l1_ (u"ࠪࠫẕ"),9999)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẖ"),l1lllll_l1_+title,l1ll1ll_l1_,121)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠬ࠷ࠧẗ")):
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"࠭࠱ࠨẘ")
	if l1l111_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࠪẙ") in url or l1l111_l1_ (u"ࠨࡁࠪẚ") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠩࠩࠫẛ")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠪࡃࠬẜ")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠫࡴࡻࡴࡱࡷࡷࡣ࡫ࡵࡲ࡮ࡣࡷࡁ࡯ࡹ࡯࡯ࠨࡲࡹࡹࡶࡵࡵࡡࡰࡳࡩ࡫࠽࡮ࡱࡹ࡭ࡪࡹ࡟࡭࡫ࡶࡸࠫࡶࡡࡨࡧࡀࠫẝ")+l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩẞ"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧẟ"),headers,l1l111_l1_ (u"ࠧࠨẠ"),l1l111_l1_ (u"ࠨࠩạ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧẢ"))
	html = response.content
	name,items = l1l111_l1_ (u"ࠪࠫả"),[]
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭Ấ") in url:
		name = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽ࠩấ"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l1l111_l1_ (u"࠭ࠠࠨẦ")) + l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫầ")
		else: name = xbmc.getInfoLabel( l1l111_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠤẨ") ) + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ẩ")
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫẪ") not in url: items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡢ࡜࡝࡞ࠥࠬࡡࡢ࡜࡝࡞࠲ࡷࡪࡧࡳࡰࡰ࠱࠮ࡄ࠯࡜࡝࡞࡟ࠦ࠳࠰࠿ࡴࡴࡦࡁࡡࡢ࡜࡝ࠤࠫ࠲࠯ࡅࠩ࡝࡞࡟ࡠࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥ࡝࡞࡟ࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ẫ"),html,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࡷࡷࡩ࠽࡝࡞࡟ࡠࠧ࠮࠮ࠫࡁࠬࡠࡡࡢ࡜ࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧ࡟ࡠࡡࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨẬ"),html,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨậ") in url and l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࡝࠱ࠪẮ") not in l1ll1ll_l1_: continue
		if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪắ") in url and l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡠ࠴࠭Ằ") not in l1ll1ll_l1_: continue
		title = name+escapeUNICODE(title).strip(l1l111_l1_ (u"ࠪࠤࠬằ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧẲ"),l1l111_l1_ (u"ࠬ࠵ࠧẳ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"࠭࡜࠰ࠩẴ"),l1l111_l1_ (u"ࠧ࠰ࠩẵ"))
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭Ặ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨặ")+l1ll1l_l1_
		l1lllll1_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲ࠫẸ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧẹ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠬ࠵࡭ࡢࡵࡵࡥ࡭࡯ࡹࡢࡶ࠲ࠫẺ") in url:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬẻ"),l1lllll_l1_+title,l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠧ࠰ࠩẼ")),123,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẽ"),l1lllll_l1_+title,l1lllll1_l1_,121,l1ll1l_l1_)
	if len(items)>=12:
		l11l1l1l1l_l1_ = [l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫẾ"),l1l111_l1_ (u"ࠪ࠳ࡹࡼ࠯ࠨế"),l1l111_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵ࠧỀ"),l1l111_l1_ (u"ࠬ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧ࠰ࠩề"),l1l111_l1_ (u"࠭࠯࡮ࡣࡶࡶࡦ࡮ࡩࡺࡣࡷ࠳ࠬỂ")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l1l_l1_):
			for n in range(0,1100,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧể"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧỄ")+str(j),url,121,l1l111_l1_ (u"ࠩࠪễ"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪỆ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪệ")+str(i),url,121,l1l111_l1_ (u"ࠬ࠭Ỉ"),str(i))
						else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ỉ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭Ị")+str(1),url,121,l1l111_l1_ (u"ࠨࠩị"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩỌ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩọ")+str(n),url,121,l1l111_l1_ (u"ࠫࠬỎ"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỏ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬỐ")+str(1),url,121)
	return
def PLAY(url):
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫố"):l1l111_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵࠭Ồ")}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ồ"),url,l1l111_l1_ (u"ࠪࠫỔ"),headers,l1l111_l1_ (u"ࠫࠬổ"),l1l111_l1_ (u"ࠬ࠭Ỗ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩỗ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶࡧࡂฬ๊สึ่ํๅࡁ࠵ࡴࡥࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧỘ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡲ࡫࠿ࡻࡲ࡭ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬộ"),html,re.DOTALL)
	if l11l11ll1l_l1_: server = l1l111l_l1_(l11l11ll1l_l1_[0],l1l111_l1_ (u"ࠩࡸࡶࡱ࠭Ớ"))
	else: server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧớ"))
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡦࡻࡴࡰ࠯ࡶ࡭ࡿ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ờ"),html,re.DOTALL)
	if l11l1l11l1_l1_:
		l11l1l11l1_l1_ = server+l11l1l11l1_l1_[0]
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩờ"),l11l1l11l1_l1_,l1l111_l1_ (u"࠭ࠧỞ"),headers,l1l111_l1_ (u"ࠧࠨở"),l1l111_l1_ (u"ࠨࠩỠ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬỡ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠪࡨࡴࡹࡴࡳࡧࡤࡱࠬỢ") not in l11l1ll1_l1_:
			l11l111l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡣࡳ࡫ࡳࡸ࠳࠰࠿࠿ࡨࡸࡲࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪợ"),l11l1ll1_l1_,re.DOTALL)
			l11l111l11_l1_ = l11l111l11_l1_[0]
			result = l11l11lll1_l1_(l11l111l11_l1_)
			try: l11l11l1ll_l1_,l11l1111l1_l1_,l11ll11l11_l1_ = result
			except:
				l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭Ụ"),l1l111_l1_ (u"࠭ࠧụ"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪỦ"),l1l111_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢ࠱ࠤ็ี๋ࠠๅ๋๊ࠥอไๆ๊ๅ฽ࠥอไฤื็๎่ࠥวๆࠢหฮาี๊ฬุࠢๅาอส่๋ࠢห้ฮั็ษ่ะࠥเ๊าࠢๅหิืฺࠠๆ์ࠤ็ืวยหࠣห้฻แฮษอࠤฬ๊ฬะ์าอࠬủ"))
				return
			l11l1111l1_l1_ = server+l11l1111l1_l1_
			l11l11l1ll_l1_ = server+l11l11l1ll_l1_
			cookies = response.cookies
			if l1l111_l1_ (u"ࠩࡓࡗࡘࡏࡄࠨỨ") in cookies.keys():
				l11l11111l_l1_ = cookies[l1l111_l1_ (u"ࠪࡔࡘ࡙ࡉࡅࠩứ")]
				headers[l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫỪ")] = l1l111_l1_ (u"ࠬࡖࡓࡔࡋࡇࡁࠬừ")+l11l11111l_l1_
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪỬ"),l11l11l1ll_l1_,l1l111_l1_ (u"ࠧࠨử"),headers,l1l111_l1_ (u"ࠨࠩỮ"),l1l111_l1_ (u"ࠩࠪữ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭Ự"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩự"),l11l1111l1_l1_,l11ll11l11_l1_,headers,l1l111_l1_ (u"ࠬ࠭Ỳ"),l1l111_l1_ (u"࠭ࠧỳ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪỴ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬỵ"),l11l1l11l1_l1_,l1l111_l1_ (u"ࠩࠪỶ"),headers,l1l111_l1_ (u"ࠪࠫỷ"),l1l111_l1_ (u"ࠫࠬỸ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨỹ"))
				l11l1ll1_l1_ = response.content
		l11lllll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫỺ"),l11l1ll1_l1_,re.DOTALL)
		if l11lllll11_l1_:
			l11lllll11_l1_ = server+l11lllll11_l1_[0]
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(l11lllll11_l1_,headers)
			zz = zip(l1l1lll1_l1_,l1llll_l1_)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			for title,l1ll1ll_l1_ in zz:
				l111l1ll_l1_ = title.split(l1l111_l1_ (u"ࠧࠡࠢࠪỻ"))[1]
				l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡸ࡬ࡨࡸࡺࡲࡦࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳ࠳ࡶ࠺ࡢࡣࠬỼ")+l111l1ll_l1_)
				l11ll111ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡷࡹࡸࡥࡢ࡯࠲ࠫỽ"),l1l111_l1_ (u"ࠪ࠳ࡩࡲ࠯ࠨỾ")).replace(l1l111_l1_ (u"ࠫ࠴ࡹࡴࡳࡧࡤࡱ࠳ࡳ࠳ࡶ࠺ࠪỿ"),l1l111_l1_ (u"ࠬ࠭ἀ"))
				l1llll_l1_.append(l11ll111ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡶࡪࡦࡶࡸࡷ࡫ࡡ࡮ࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡭ࡱ࠶ࡢࡣࠬἁ")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ἂ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩἃ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪἄ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬἅ"),l1l111_l1_ (u"ࠫ࠰࠭ἆ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࡳࡀࠫἇ") + l1lll1ll_l1_
	l1lll11_l1_(url)
	return
l1l11111_l1_ = [l1l111_l1_ (u"࠭วๅ่๋฽ࠬἈ"),l1l111_l1_ (u"ࠧศๆึ๊ฮ࠭Ἁ"),l1l111_l1_ (u"ࠨษ็ฬ้ีࠧἊ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠩสุ่์ษࠨἋ"),l1l111_l1_ (u"ࠪหฺ้๊สࠩἌ"),l1l111_l1_ (u"ࠫฬ๊ศๅัࠪἍ"),l1l111_l1_ (u"ࠬอไะไฬࠫἎ"),l1l111_l1_ (u"࠭วๅฮ๋ำฮ࠭Ἇ"),l1l111_l1_ (u"ࠧศๆอีั๋ษࠨἐ"),l1l111_l1_ (u"ࠨษ็๊ํ฿ࠧἑ"),l1l111_l1_ (u"ࠩส่ฯ฻ๆ๋ใࠪἒ")]
l11lll_l1_ = []
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧἓ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨἔ"),url,l1l111_l1_ (u"ࠬ࠭ἕ"),headers,l1l111_l1_ (u"࠭ࠧ἖"),l1l111_l1_ (u"ࠧࠨ἗"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫἘ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡶࡴࡶࡤࡰࡹࡱࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸࠨࠧἙ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	zz = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡺࡸࡲࡦࡰࡷࡣࡴࡶࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬἚ"),block,re.DOTALL)
	l11l1ll111_l1_,l11l1lll1l_l1_ = zip(*zz)
	l1l11l1l_l1_ = zip(l11l1ll111_l1_,l11l1lll1l_l1_,l11l1ll111_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪἛ"),block,re.DOTALL)
	l11l111111_l1_ = []
	for l1ll1ll_l1_,name in items:
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧἜ"))
		value = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"࠭࠯ࠨἝ"),1)[1]
		if name in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠧๅๆๆฬฬืࠧ἞") in name: continue
		if l1l111_l1_ (u"ࠨࡖ࡙࠱ࡒࡇࠧ἟") in name: continue
		if l1l111_l1_ (u"ࠩࡗ࡚࠲࠷࠴ࠨἠ") in name: continue
		l11l111111_l1_.append((value,name))
	return l11l111111_l1_
def l11l1l11ll_l1_(l1l1ll11_l1_,url):
	url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧἡ"),1)[0]
	url = url.strip(l1l111_l1_ (u"ࠫ࠴࠭ἢ"))
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧἣ"))
	l11ll111_l1_ = l11ll111_l1_.replace(l1l111_l1_ (u"࠭ࠠࠬࠢࠪἤ"),l1l111_l1_ (u"ࠧ࠮ࠩἥ"))
	url = url+l1l111_l1_ (u"ࠨ࠱ࠪἦ")+l11ll111_l1_
	return url
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠩࡂࠫἧ") in url: url = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧἨ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨἩ"),1)
	if filter==l1l111_l1_ (u"ࠬ࠭Ἢ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"࠭ࠧἫ"),l1l111_l1_ (u"ࠧࠨἬ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬἭ"))
	if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬἮ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠪࡁࠬἯ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠫࡂ࠭ἰ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧἱ")+category+l1l111_l1_ (u"࠭࠽࠱ࠩἲ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩἳ")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫἴ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫἵ"))+l1l111_l1_ (u"ࠪࡣࡤࡥࠧἶ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭ἷ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨἸ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪἹ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪἺ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪἻ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬἼ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧἽ")+l11lll11_l1_
		l1llllll_l1_ = l11l1l11ll_l1_(l11lll11_l1_,l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἾ"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨἿ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ὀ"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧὁ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧὂ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧὃ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬὄ"),l1l111_l1_ (u"ࠫࠬὅ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		l1l111ll_l1_ = l1l111ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ὆"))
		name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ὇"))
		name = name.replace(l1l111_l1_ (u"ࠧ࠮࠯ࠪὈ"),l1l111_l1_ (u"ࠨࠩὉ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫὊ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭Ὃ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					l1llllll_l1_ = l11l1l11ll_l1_(l11lll11_l1_,url)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪὌ")+l1l111l1_l1_)
				return
			else:
				l1llllll_l1_ = l11l1l11ll_l1_(l11lll11_l1_,l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὍ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ὎"),l1llllll_l1_,121)
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ὏"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩὐ"),l1lllll1_l1_,125,l1l111_l1_ (u"ࠩࠪὑ"),l1l111_l1_ (u"ࠪࠫὒ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧὓ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧὔ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩὕ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩὖ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫὗ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭὘")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪὙ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭὚")+name,l1lllll1_l1_,124,l1l111_l1_ (u"ࠬ࠭Ὓ"),l1l111_l1_ (u"࠭ࠧ὜"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩὝ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ὞")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫὟ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬὠ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨὡ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨὢ")+name
			if type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩὣ"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧὤ"),l1lllll_l1_+title,url,124,l1l111_l1_ (u"ࠨࠩὥ"),l1l111_l1_ (u"ࠩࠪὦ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ὧ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠫࡂ࠭Ὠ") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11ll_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὩ"),l1lllll_l1_+title,l1llllll_l1_,121)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ὢ"),l1lllll_l1_+title,url,125,l1l111_l1_ (u"ࠧࠨὫ"),l1l111_l1_ (u"ࠨࠩὬ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠩࡀࠪࠬὭ"),l1l111_l1_ (u"ࠪࡁ࠵ࠬࠧὮ"))
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫ࠭Ὧ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠬࡃࠧὰ") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠨά"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩὲ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠨࠩέ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳ࠫὴ")
		if l1l111_l1_ (u"ࠪࠩࠬή") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ὶ") and value!=l1l111_l1_ (u"ࠬ࠶ࠧί"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪὸ")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪό") and value!=l1l111_l1_ (u"ࠨ࠲ࠪὺ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫύ")+key+l1l111_l1_ (u"ࠪࡁࠬὼ")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩώ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ὾")+key+l1l111_l1_ (u"࠭࠽ࠨ὿")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫᾀ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪᾁ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠩࡀ࠴ࠬᾂ"),l1l111_l1_ (u"ࠪࡁࠬᾃ"))
	return l1l1l111_l1_
def l11ll11111_l1_(l11l1111ll_l1_):
	m = re.search(l1l111_l1_ (u"ࡶࠬࡤࠨ࡝ࡦ࠮࠭ࡠ࠴ࠬ࡞ࡁ࡟ࡨ࠯ࡅࠧᾄ"), str(l11l1111ll_l1_))
	return int(m.groups()[-1]) if m and not callable(l11l1111ll_l1_) else 0
def l11l11l11l_l1_(l11l1llll1_l1_):
	try:
		l11l1ll1l1_l1_ = base64.b64decode(l11l1llll1_l1_)
	except:
		try:
			l11l1ll1l1_l1_ = base64.b64decode(l11l1llll1_l1_+l1l111_l1_ (u"ࠬࡃࠧᾅ"))
		except:
			try:
				l11l1ll1l1_l1_ = base64.b64decode(l11l1llll1_l1_+l1l111_l1_ (u"࠭࠽࠾ࠩᾆ"))
			except:
				l11l1ll1l1_l1_ = l1l111_l1_ (u"ࠧࡆࡔࡕ࠾ࠥࡨࡡࡴࡧ࠹࠸ࠥࡪࡥࡤࡱࡧࡩࠥ࡫ࡲࡳࡱࡵࠫᾇ")
	if PY3: l11l1ll1l1_l1_ = l11l1ll1l1_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᾈ"))
	return l11l1ll1l1_l1_
def l11l111lll_l1_(l11l1ll11l_l1_,l11l1l1ll1_l1_,a):
	a = a - l11l1l1ll1_l1_
	if a<0:
		c = l1l111_l1_ (u"ࠩࡸࡲࡩ࡫ࡦࡪࡰࡨࡨࠬᾉ")
	else:
		c = l11l1ll11l_l1_[a]
	return c
def x(l11l1ll11l_l1_,l11l1l1ll1_l1_,a):
	return(l11l111lll_l1_(l11l1ll11l_l1_,l11l1l1ll1_l1_,a))
def l11l1ll1ll_l1_(l11ll1111l_l1_,step,l11l1l1ll1_l1_,l11l11llll_l1_):
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࠨᾊ"),l1l111_l1_ (u"ࠫ࡬ࡲ࡯ࡣࡣ࡯ࠤࡩࡁࠠࠨᾋ"))
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"ࠬࡾࠨࠨᾌ"),l1l111_l1_ (u"࠭ࡸࠩࡶࡤࡦ࠱ࡹࡴࡦࡲ࠵࠰ࠬᾍ"))
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡥ࠽ࠣࡨࡂ࠭ᾎ"),l1l111_l1_ (u"ࠨࠩᾏ"))
	d = eval(l11l11llll_l1_,{l1l111_l1_ (u"ࠩࡳࡥࡷࡹࡥࡊࡰࡷࠫᾐ"):l11ll11111_l1_,l1l111_l1_ (u"ࠪࡼࠬᾑ"):x,l1l111_l1_ (u"ࠫࡹࡧࡢࠨᾒ"):l11ll1111l_l1_,l1l111_l1_ (u"ࠬࡹࡴࡦࡲ࠵ࠫᾓ"):l11l1l1ll1_l1_})
	l11ll11ll1_l1_=0
	while True:
		l11ll11ll1_l1_=l11ll11ll1_l1_+1
		l11ll1111l_l1_.append(l11ll1111l_l1_[0])
		del l11ll1111l_l1_[0]
		d = eval(l11l11llll_l1_,{l1l111_l1_ (u"࠭ࡰࡢࡴࡶࡩࡎࡴࡴࠨᾔ"):l11ll11111_l1_,l1l111_l1_ (u"ࠧࡹࠩᾕ"):x,l1l111_l1_ (u"ࠨࡶࡤࡦࠬᾖ"):l11ll1111l_l1_,l1l111_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨᾗ"):l11l1l1ll1_l1_})
		if ((d == step) or (l11ll11ll1_l1_>10000)): break
	return
def l11l11lll1_l1_(l11l111l11_l1_):
	tmp = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸ࠮ࠫࡁࡀࠬ࠳ࢁ࠲࠭࠶ࢀ࠭ࡡ࠮࡜ࠪࠩᾘ"), l11l111l11_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡘࡤࡶࡨࡵ࡮ࡴࡶࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭ᾙ")
	l11l111l1l_l1_ = tmp[0].strip()
	_print(l1l111_l1_ (u"ࠬ࡜ࡡࡳࡥࡲࡲࡸࡺࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩᾚ") % l11l111l1l_l1_)
	tmp = re.findall(l1l111_l1_ (u"࠭ࡽ࡝ࠪࠪᾛ")+l11l111l1l_l1_+l1l111_l1_ (u"ࠧࡀ࠮ࠫ࠴ࡽࡡ࠰࠮࠻ࡤ࠱࡫ࡣࡻ࠲࠮࠴࠴ࢂ࠯࡜ࠪ࡞ࠬ࠿ࠬᾜ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡓࡵࡧࡳ࠵ࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨᾝ")
	step = eval(tmp[0])
	_print(l1l111_l1_ (u"ࠩࡖࡸࡪࡶ࠱ࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣ࠴ࡽࠫࡳࠨᾞ") % l1l111_l1_ (u"ࠪࡿ࠿࠶࠲࡙ࡿࠪᾟ").format(step).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠫࡩࡃࡤ࠮ࠪ࠳ࡼࡠ࠶࠭࠺ࡣ࠰ࡪࡢࢁ࠱࠭࠳࠳ࢁ࠮ࡁࠧᾠ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠬࡋࡒࡓ࠼ࡖࡸࡪࡶ࠲ࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾡ")
	l11l1l1ll1_l1_ = eval(tmp[0])
	_print(l1l111_l1_ (u"࠭ࡓࡵࡧࡳ࠶ࠥࠦࠠࠡࠢࠣࠤࠥࡃࠠ࠱ࡺࠨࡷࠬᾢ") % l1l111_l1_ (u"ࠧࡼ࠼࠳࠶࡝ࢃࠧᾣ").format(l11l1l1ll1_l1_).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠣࡶࡵࡽࢀ࠮ࡶࡢࡴ࠱࠮ࡄ࠯࠻ࠣᾤ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࡤࡦࡥࡤࡰࡤ࡬࡮ࡤࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾥ")
	l11l11llll_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠪࡈࡪࡩࡡ࡭ࠢࡩࡹࡳࡩࠠࠡࠢࡀࠤࠧࠦࠥࡴ࠰࠱࠲ࠧ࠭ᾦ") % l11l11llll_l1_[0:135])
	tmp = re.findall(l1l111_l1_ (u"ࠦࠬࡪࡡࡵࡣࠪ࠾ࢀ࠭ࠨࡠ࡝࠳࠱࠾ࡧ࠭ࡻࡃ࠰࡞ࡢࢁ࠱࠱࠮࠵࠴ࢂ࠯ࠧ࠻ࠩࡲ࡯ࠬࠨᾧ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠬࡋࡒࡓ࠼ࡓࡳࡸࡺࡋࡦࡻࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭ᾨ")
	l11l1lllll_l1_ = tmp[0]
	_print(l1l111_l1_ (u"࠭ࡐࡰࡵࡷࡏࡪࡿࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪᾩ") % l11l1lllll_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠢࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࠥᾪ")+l11l111l1l_l1_+l1l111_l1_ (u"ࠣ࠰࠭ࡃࡻࡧࡲ࠯ࠬࡂࡁ࠭ࡢ࡛࠯ࠬࡂࡡ࠮ࠨᾫ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࡔࡢࡤࡏ࡭ࡸࡺࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪᾬ")
	l11l1l1l11_l1_ = tmp[0]
	l11l1l1l11_l1_ = l11l111l1l_l1_ + l1l111_l1_ (u"ࠥࡁࠧᾭ") + l11l1l1l11_l1_
	exec(l11l1l1l11_l1_) in globals(), locals()
	l11l1ll11l_l1_ = locals()[l11l111l1l_l1_]
	_print(l11l111l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨ࠲࠾࠶ࡳ࠯࠰࠱ࠫᾮ")%str(l11l1ll11l_l1_))
	l11l1ll1ll_l1_(l11l1ll11l_l1_,step,l11l1l1ll1_l1_,l11l11llll_l1_)
	_print(l11l111l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣࠩ࠳࠿࠰ࡴ࠰࠱࠲ࠬᾯ")%str(l11l1ll11l_l1_))
	tmp = re.findall(l1l111_l1_ (u"ࠨ࡜ࠩ࡞ࠬ࠿࠭ࡼࡡࡳࠢ࠱࠮ࡄ࠯࡜ࠥ࡞ࠫࠫࡡ࠰ࠧ࡝ࠫࠥᾰ"), l11l111l11_l1_, re.S)
	if not tmp:
		tmp = re.findall(l1l111_l1_ (u"ࠢࡢ࠲ࡤࡠ࠭ࡢࠩ࠼ࠪ࠱࠮ࡄ࠯࡜ࠥ࡞ࠫࠫࡡ࠰ࠧ࡝ࠫࠥᾱ"), l11l111l11_l1_, re.S)
		if not tmp:
			return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࡒࡩࡴࡶࡢ࡚ࡦࡸࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪᾲ")
	l11ll11l1l_l1_ = tmp[0]
	l11ll11l1l_l1_ = re.sub(l1l111_l1_ (u"ࠤࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࠴ࠪࡀࡿ࠱࠮ࡄࢃࠩࠣᾳ"), l1l111_l1_ (u"ࠥࠦᾴ"), l11ll11l1l_l1_)
	_print(l1l111_l1_ (u"ࠫࡑ࡯ࡳࡵࡡ࡙ࡥࡷࠦࠠࠡࠢࠣࡁࠥࠫ࠮࠺࠲ࡶ࠲࠳࠴ࠧ᾵") % l11ll11l1l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠧ࠮࡟࡜ࡣ࠰ࡾࡆ࠳ࡺ࠱࠯࠼ࡡࢀ࠺ࠬ࠹ࡿࠬࡁࡡࡡ࡜࡞ࠤᾶ") , l11ll11l1l_l1_)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽࠷࡛ࡧࡲࡴࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾷ")
	_11l1l1lll_l1_ = tmp
	_print(l1l111_l1_ (u"ࠧ࠴ࡘࡤࡶࡸࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫᾸ")%str(_11l1l1lll_l1_))
	l11l1l111l_l1_ = _11l1l1lll_l1_[1]
	_print(l1l111_l1_ (u"ࠨࡤ࡬࡫ࡤࡹࡴࡳࡡࡹࡥࡷࠦࠠ࠾ࠢࠨࡷࠬᾹ")%l11l1l111l_l1_)
	l11ll11l1l_l1_ = l11ll11l1l_l1_.replace(l1l111_l1_ (u"ࠩ࠯ࠫᾺ"),l1l111_l1_ (u"ࠪ࠿ࠬΆ")).split(l1l111_l1_ (u"ࠫࡀ࠭ᾼ"))
	for l11l1llll1_l1_ in l11ll11l1l_l1_:
		l11l1llll1_l1_ = l11l1llll1_l1_.strip()
		if l1l111_l1_ (u"ࠬ࡯ࡳ࡮ࡱࡥࠫ᾽") in l11l1llll1_l1_: l11l1llll1_l1_=l1l111_l1_ (u"࠭ࠧι")
		if l1l111_l1_ (u"ࠧ࠾࡝ࡠࠫ᾿")   in l11l1llll1_l1_: l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠨ࠿࡞ࡡࠬ῀"),l1l111_l1_ (u"ࠩࡀࡿࢂ࠭῁"))
		l11l1llll1_l1_ = re.sub(l1l111_l1_ (u"ࠥࠬࡦ࠶࠮࡝ࠪࠬࠦῂ"), l1l111_l1_ (u"ࠦࡦ࠶ࡤࠩ࡯ࡤ࡭ࡳࡥࡴࡢࡤ࠯ࡷࡹ࡫ࡰ࠳࠮ࠥῃ"), l11l1llll1_l1_)
		if l11l1llll1_l1_!=l1l111_l1_ (u"ࠬ࠭ῄ"):
			l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"࠭ࠡࠢ࡝ࡠࠫ῅"),l1l111_l1_ (u"ࠧࡕࡴࡸࡩࠬῆ"));
			l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠨࠣ࡞ࡡࠬῇ"),l1l111_l1_ (u"ࠩࡉࡥࡱࡹࡥࠨῈ"));
			l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࠨΈ"),l1l111_l1_ (u"ࠫࠬῊ"));
			try:
				exec(l11l1llll1_l1_,{l1l111_l1_ (u"ࠬࡶࡡࡳࡵࡨࡍࡳࡺࠧΉ"):l11ll11111_l1_,l1l111_l1_ (u"࠭ࡡࡵࡱࡥࠫῌ"):l11l11l11l_l1_,l1l111_l1_ (u"ࠧࡢ࠲ࡧࠫ῍"):l11l111lll_l1_,l1l111_l1_ (u"ࠨࡺࠪ῎"):x,l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࡟ࡵࡣࡥࠫ῏"):l11l1ll11l_l1_,l1l111_l1_ (u"ࠪࡷࡹ࡫ࡰ࠳ࠩῐ"):l11l1l1ll1_l1_},locals())
			except:
				pass
	l11ll111l1_l1_ = l1l111_l1_ (u"ࠫࠬῑ")
	for i in range(0,len(locals()[_11l1l1lll_l1_[2]])):
		if locals()[_11l1l1lll_l1_[2]][i] in locals()[_11l1l1lll_l1_[1]]:
			l11ll111l1_l1_ = l11ll111l1_l1_ + locals()[_11l1l1lll_l1_[1]][locals()[_11l1l1lll_l1_[2]][i]]
	_print(l1l111_l1_ (u"ࠬࡨࡩࡨࡕࡷࡶ࡮ࡴࡧࠡࠢࠣࠤࡂࠦࠥ࠯࠻࠳ࡷ࠳࠴࠮ࠨῒ")%l11ll111l1_l1_)
	tmp = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡦࡂࡢࠧ࠰࡞ࠪࡠ࠰࠮࠮ࠫࡁࠬࠬࡄࡀࠬࡽ࠽ࠬࠫΐ"), l11l111l11_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾ࠥࡍࡥࡵࡗࡵࡰࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨ῔")
	l11l111ll1_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠨࡉࡨࡸ࡚ࡸ࡬ࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ῕") % l11l111ll1_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠩࠫࡣ࠳࠰࠿ࠪ࡞࡞ࠫῖ"), l11l111ll1_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠪࡉࡗࡘ࠺ࠡࡉࡨࡸ࡛ࡧࡲࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫῗ")
	l11l11l111_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠫࡌ࡫ࡴࡗࡣࡵࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨῘ") % l11l11l111_l1_)
	l11l1lll11_l1_ = locals()[l11l11l111_l1_][0]
	l11l1lll11_l1_ = l11l11l11l_l1_(l11l1lll11_l1_)
	_print(l1l111_l1_ (u"ࠬࡍࡥࡵࡘࡤࡰࠥࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩῙ") % l11l1lll11_l1_)
	tmp = re.findall(l1l111_l1_ (u"࠭ࡽࡷࡣࡵࠤ࠭࡬࠽࠯ࠬࡂ࠭ࡀ࠭Ὶ"), l11l111l11_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾ࠥࡖ࡯ࡴࡶࡘࡶࡱࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩΊ")
	l11l11l1l1_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠨࡒࡲࡷࡹ࡛ࡲ࡭ࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ῜") % l11l11l1l1_l1_)
	l11l11l1l1_l1_ = re.sub(l1l111_l1_ (u"ࠤࠫࡻ࡮ࡴࡤࡰࡹ࡟࡟࠳࠰࠿࡝࡟ࠬࠦ῝"), l1l111_l1_ (u"ࠥࡥࡹࡵࡢࠣ῞"), l11l11l1l1_l1_)
	l11l11l1l1_l1_ = re.sub(l1l111_l1_ (u"ࠦ࠭ࡡࡁ࠮࡜ࡠࡿ࠶࠲࠲ࡾ࡞ࠫ࠭ࠧ῟"), l1l111_l1_ (u"ࠧࡧ࠰ࡥࠪࡰࡥ࡮ࡴ࡟ࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠦῠ"), l11l11l1l1_l1_)
	l11l11l1l1_l1_ = l1l111_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡦ࠼ࠢࠪῡ")+l11l11l1l1_l1_
	verify = re.findall(l1l111_l1_ (u"ࠧ࡝࠭ࠫࡣ࠳࠰࠿ࠪࠦࠪῢ"),l11l11l1l1_l1_,re.DOTALL)[0]
	l11l1l1111_l1_ = eval(verify)
	l11l11l1l1_l1_ = l11l11l1l1_l1_.replace(l1l111_l1_ (u"ࠨࡩ࡯ࡳࡧࡧ࡬ࠡࡨ࠾ࠤ࡫ࡃࠧΰ"),l1l111_l1_ (u"ࠩࠪῤ"))
	f = eval(l11l11l1l1_l1_,{l1l111_l1_ (u"ࠪࡥࡹࡵࡢࠨῥ"):l11l11l11l_l1_,l1l111_l1_ (u"ࠫࡦ࠶ࡤࠨῦ"):l11l111lll_l1_,l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡢࡸࡦࡨࠧῧ"):l11l1ll11l_l1_,l1l111_l1_ (u"࠭ࡳࡵࡧࡳ࠶ࠬῨ"):l11l1l1ll1_l1_,verify:l11l1l1111_l1_})
	_print(l1l111_l1_ (u"ࠧ࠰ࠩῩ")+l11l1lll11_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭Ὺ")+f+l11ll111l1_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧΎ")+l11l1lllll_l1_)
	return([l1l111_l1_ (u"ࠪ࠳ࠬῬ")+l11l1lll11_l1_,f+l11ll111l1_l1_,{ l11l1lllll_l1_ : l1l111_l1_ (u"ࠫࡴࡱࠧ῭")}])
def _print(text):
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࡙ࠧ䗇")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡎࡖࡘࡤ࠭䗈")
l1l1lllll111_l1_ = 4
l1l1llll1l11_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll1ll_l1_):
	try: l1l1lll11l1l_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗉")])
	except: l1l1lll11l1l_l1_ = l1l111_l1_ (u"ࠩࠪ䗊")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1ll11111lll_l1_(text)
	elif mode==162: l1lll_l1_ = l1l1ll1ll1ll_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l1ll1ll1ll_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1ll11111l1l_l1_(text)
	elif mode==165: l1lll_l1_ = l1l1ll11llll_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1llllll1l_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l1ll11lll1_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l1ll1111ll_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1ll111111l1_l1_()
	elif mode==762: l1lll_l1_ = l1l1lll1l1l1_l1_()
	elif mode==763: l1lll_l1_ = l1l1lll1l111_l1_(l1l1lll11l1l_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1llll1ll1_l1_(l1l1lll11l1l_l1_,text)
	elif mode==765: l1lll_l1_ = l1ll11111111_l1_(l1l1lll11l1l_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗋"),l1l111_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้ࠤ฾ฺ่ศศํอࠬ䗌"),l1l111_l1_ (u"ࠬ࠭䗍"),161,l1l111_l1_ (u"࠭ࠧ䗎"),l1l111_l1_ (u"ࠧࠨ䗏"),l1l111_l1_ (u"ࠨࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䗐"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗑"),l1l111_l1_ (u"ࠪๆฺุ๋ࠠึ๋หห๐ࠧ䗒"),l1l111_l1_ (u"ࠫࠬ䗓"),162,l1l111_l1_ (u"ࠬ࠭䗔"),l1l111_l1_ (u"࠭ࠧ䗕"),l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䗖"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗗"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอࠬ䗘"),l1l111_l1_ (u"ࠪࠫ䗙"),163,l1l111_l1_ (u"ࠫࠬ䗚"),l1l111_l1_ (u"ࠬ࠭䗛"),l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䗜"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗝"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣฬาัฺࠠึ๋หห๐ࠧ䗞"),l1l111_l1_ (u"ࠩࠪ䗟"),164,l1l111_l1_ (u"ࠪࠫ䗠"),l1l111_l1_ (u"ࠫࠬ䗡"),l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䗢"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗣"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ䗤"),l1l111_l1_ (u"ࠨࠩ䗥"),763,l1l111_l1_ (u"ࠩࠪ䗦"),l1l111_l1_ (u"ࠪࠫ䗧"),l1l111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭䗨"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䗩"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䗪"),l1l111_l1_ (u"ࠧࠨ䗫"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗬"),l1l111_l1_ (u"ࠩๅ๊ํอสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮ࠭䗭"),l1l111_l1_ (u"ࠪࠫ䗮"),163,l1l111_l1_ (u"ࠫࠬ䗯"),l1l111_l1_ (u"ࠬ࠭䗰"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䗱"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗲"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ䗳"),l1l111_l1_ (u"ࠩࠪ䗴"),163,l1l111_l1_ (u"ࠪࠫ䗵"),l1l111_l1_ (u"ࠫࠬ䗶"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗷"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗸"),l1l111_l1_ (u"ࠧใี่ࠤ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ䗹"),l1l111_l1_ (u"ࠨࠩ䗺"),162,l1l111_l1_ (u"ࠩࠪ䗻"),l1l111_l1_ (u"ࠪࠫ䗼"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗽"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗾"),l1l111_l1_ (u"࠭โิ็ࠣๅ๏ี๊้ࠢࡐ࠷ู࡚ࠦี๊สส๏࠭䗿"),l1l111_l1_ (u"ࠧࠨ䘀"),162,l1l111_l1_ (u"ࠨࠩ䘁"),l1l111_l1_ (u"ࠩࠪ䘂"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘃"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘄"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤอำหࠡ฻ื์ฬฬ๊ࠨ䘅"),l1l111_l1_ (u"࠭ࠧ䘆"),164,l1l111_l1_ (u"ࠧࠨ䘇"),l1l111_l1_ (u"ࠨࠩ䘈"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘉"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘊"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䘋"),l1l111_l1_ (u"ࠬ࠭䘌"),765,l1l111_l1_ (u"࠭ࠧ䘍"),l1l111_l1_ (u"ࠧࠨ䘎"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘏"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䘐"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䘑"),l1l111_l1_ (u"ࠫࠬ䘒"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘓"),l1l111_l1_ (u"࠭โ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫ䘔"),l1l111_l1_ (u"ࠧࠨ䘕"),163,l1l111_l1_ (u"ࠨࠩ䘖"),l1l111_l1_ (u"ࠩࠪ䘗"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘘"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘙"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭䘚"),l1l111_l1_ (u"࠭ࠧ䘛"),163,l1l111_l1_ (u"ࠧࠨ䘜"),l1l111_l1_ (u"ࠨࠩ䘝"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘞"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘟"),l1l111_l1_ (u"ࠫ็ูๅࠡไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ䘠"),l1l111_l1_ (u"ࠬ࠭䘡"),162,l1l111_l1_ (u"࠭ࠧ䘢"),l1l111_l1_ (u"ࠧࠨ䘣"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘤"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘥"),l1l111_l1_ (u"ࠪๆุ๋ࠠโ์า๎ํࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ䘦"),l1l111_l1_ (u"ࠫࠬ䘧"),162,l1l111_l1_ (u"ࠬ࠭䘨"),l1l111_l1_ (u"࠭ࠧ䘩"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘪"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘫"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢหัะูࠦี๊สส๏࠭䘬"),l1l111_l1_ (u"ࠪࠫ䘭"),164,l1l111_l1_ (u"ࠫࠬ䘮"),l1l111_l1_ (u"ࠬ࠭䘯"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘰"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘱"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ䘲"),l1l111_l1_ (u"ࠩࠪ䘳"),764,l1l111_l1_ (u"ࠪࠫ䘴"),l1l111_l1_ (u"ࠫࠬ䘵"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘶"))
	return
def l1ll111111l1_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘷"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭䘸")+l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡋࡓࡘ࡛࠭䘹"),l1l111_l1_ (u"ࠩࠪ䘺"),764)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䘻"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䘼"),l1l111_l1_ (u"ࠬ࠭䘽"),9999)
	for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡊࡒࠪ䘾")+str(l1l1lll11l1l_l1_)+l1l111_l1_ (u"ࠧࡠࠩ䘿")
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙀"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫ䙁")+NUMBERS_SEQ_NAME[l1l1lll11l1l_l1_],l1l111_l1_ (u"ࠪࠫ䙂"),764,l1l111_l1_ (u"ࠫࠬ䙃"),l1l111_l1_ (u"ࠬ࠭䙄"),l1l111_l1_ (u"࠭ࠧ䙅"),l1l111_l1_ (u"ࠧࠨ䙆"),{l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䙇"):l1l1lll11l1l_l1_})
	return
def l1l1lll1l1l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙈"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䙉")+l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦฬๆ์฼ࠤࡒ࠹ࡕࠨ䙊"),l1l111_l1_ (u"ࠬ࠭䙋"),765)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䙌"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䙍"),l1l111_l1_ (u"ࠨࠩ䙎"),9999)
	for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡑ࡚࠭䙏")+str(l1l1lll11l1l_l1_)+l1l111_l1_ (u"ࠪࡣࠬ䙐")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙑"),l1lllll_l1_+l1l111_l1_ (u"ࠬࠦแ๋ัํ์์อสࠡ็ฯ่ิࠦࠧ䙒")+NUMBERS_SEQ_NAME[l1l1lll11l1l_l1_],l1l111_l1_ (u"࠭ࠧ䙓"),765,l1l111_l1_ (u"ࠧࠨ䙔"),l1l111_l1_ (u"ࠨࠩ䙕"),l1l111_l1_ (u"ࠩࠪ䙖"),l1l111_l1_ (u"ࠪࠫ䙗"),{l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙘"):l1l1lll11l1l_l1_})
	return
def l1ll1111111l_l1_(l1lll11ll1l_l1_):
	global l1l1lll1111l_l1_,l1l1ll1lllll_l1_
	l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
	try:
		if l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ䙙") in l1lll11ll1l_l1_: l1lll111l11_l1_(l1lll11ll1l_l1_)
		else: l1lll111l11_l1_()
		l1l1lll1l11l_l1_ = False
	except:
		l11ll11l1ll_l1_()
		l1l1lll1l11l_l1_ = True
	l1lll11ll1l_l1_ = TRANSLATE(l1lll11ll1l_l1_)
	if l1l1lll1l11l_l1_:
		l1ll1lll_l1_(l1lll11ll1l_l1_,l1l111_l1_ (u"࠭แีๆ่้ࠣษำโࠩ䙚"),time=2000)
		l1l1lll1111l_l1_ += 1
		l1l1ll1lllll_l1_ += l1l111_l1_ (u"ࠧࠡࠩ䙛")+l1lll11ll1l_l1_
	else: l1ll1lll_l1_(l1lll11ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䙜"),time=1000)
	return
def l1l1lll111ll_l1_(l1l1lll1l1ll_l1_=True):
	global l1l1lll1111l_l1_,l1l1ll1lllll_l1_
	if not l1l1lll1l1ll_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䙝"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ䙞"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩ䙟"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䙠"),l1l111_l1_ (u"࠭ࠧ䙡"),l1l111_l1_ (u"ࠧࠨ䙢"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䙣"),l1l111_l1_ (u"ࠩ็็๏ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱ࠤฬ๊ศา่ส้ั๊ࠦฮฬสะࠥษๆࠡ์ไัฺࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠๅๅํࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱ࠤะ๋๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษะี๊ࠥํะ่ࠢส่ศ่ำศ็ࠣัฯ๏ࠠๅษࠣฮาะวอࠢฦ๊ࠥะๅๅศ๊ห๋ࠥัสࠢฦาึ๏ࠠ࠯ࠢ฼้้๐ษࠡ็็สࠥาๅ๋฻ࠣห้ษโิษ่ࠤฯำสศฮࠣ฽ฬีษࠡลๅ่๋ࠥๆࠡ࠵ࠣำ็อฦใࠢ࠱ࠤ์๊ࠠหำํำࠥษๆࠡฬฯ้฾ࠦโศศ่อࠥอไฤไึห๊ࠦวๅฤ้ࠤฤ࠭䙤"))
	if l1llll111l_l1_!=1: return
	l1l1ll11l111_l1_ = menuItemsLIST
	l1l1lll1111l_l1_,l1l1ll1lllll_l1_,threads = 0,l1l111_l1_ (u"ࠪࠫ䙥"),{}
	for l1lll11ll1l_l1_ in l1l1111ll11_l1_:
		time.sleep(0.5)
		threads[l1lll11ll1l_l1_] = threading.Thread(target=l1ll1111111l_l1_,args=(l1lll11ll1l_l1_,))
		threads[l1lll11ll1l_l1_].start()
		if l1l1lll1111l_l1_>=l1l1llll1l11_l1_: break
	else:
		for l1lll11ll1l_l1_ in list(threads.keys()):
			threads[l1lll11ll1l_l1_].join()
	menuItemsLIST[:] = l1l1ll11l111_l1_
	if l1l1lll1111l_l1_>=l1l1llll1l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䙦"),l1l111_l1_ (u"ࠬ࠭䙧"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䙨"),l1l111_l1_ (u"ࠧๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠࠨ䙩")+str(l1l1lll1111l_l1_)+l1l111_l1_ (u"ࠨ่ࠢ์ฬู่ࠡ็้ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥ࠴࠮࠯๋ࠢือฮ็ศࠢๅำࠥ๐ใ้่ࠣ฽ิ๋้ࠠฮ๋ำࠥหๆหำ้๎ฯࠦแ๋ࠢฯ๋ฬุใ๊๊ࠡ๎࠿࠭䙪")+l1l1ll1lllll_l1_)
	else:
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ䙫"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࡣࡆࡒࡌࠨ䙬"),contentsDICT,l1ll111ll11_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䙭"),l1l111_l1_ (u"ࠬ࠭䙮"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䙯"),l1l111_l1_ (u"ࠧห็ࠣะ้ฮࠠอ็ํ฽ࠥอไฤไึห๊ࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ศา่ส้ั࠭䙰"))
	return
def l1l1ll1ll111_l1_(l1l1lll11l1l_l1_,options):
	l1l1lll111l_l1_ = False
	l1l1ll111l11_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1lll111l_l1_ and l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䙱") not in options:
		l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䙲"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ䙳"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬ䙴")+l1l1lll11l1l_l1_)
	elif l1l111_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ䙵") not in options or l1l111_l1_ (u"࠭࡟ࡗࡑࡇࡣࠬ䙶") not in options:
		import IPTV
		message = l1l111_l1_ (u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ䙷")
		if l1l111_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ䙸") not in options:
			try: IPTV.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䙹"),l1l111_l1_ (u"ࠪࠫ䙺"),l1l111_l1_ (u"ࠫࠬ䙻"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䙼"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䙽"),l1l111_l1_ (u"ࠧࠨ䙾"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ䙿"),message)
			try: IPTV.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚀"),l1l111_l1_ (u"ࠪࠫ䚁"),l1l111_l1_ (u"ࠫࠬ䚂"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䚃"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚄"),l1l111_l1_ (u"ࠧࠨ䚅"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ䚆"),message)
			try: IPTV.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚇"),l1l111_l1_ (u"ࠪࠫ䚈"),l1l111_l1_ (u"ࠫࠬ䚉"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䚊"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚋"),l1l111_l1_ (u"ࠧࠨ䚌"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ䚍"),message)
		if l1l111_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ䚎") not in options:
			try: IPTV.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䚏"),l1l111_l1_ (u"ࠫࠬ䚐"),l1l111_l1_ (u"ࠬ࠭䚑"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䚒"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䚓"),l1l111_l1_ (u"ࠨࠩ䚔"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ䚕"),message)
			try: IPTV.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚖"),l1l111_l1_ (u"ࠫࠬ䚗"),l1l111_l1_ (u"ࠬ࠭䚘"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䚙"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䚚"),l1l111_l1_ (u"ࠨࠩ䚛"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ䚜"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1lll111l_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ䚝"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬ䚞")+l1l1lll11l1l_l1_,l1lll_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1ll111l11_l1_
	return l1lll_l1_
def l1l1lll11lll_l1_(l1l1lll11l1l_l1_,options):
	l1l1lll111l_l1_ = False
	l1l1ll111l11_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1lll111l_l1_ and l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䚟") not in options:
		l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䚠"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭䚡"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ䚢")+l1l1lll11l1l_l1_)
	elif l1l111_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ䚣") not in options or l1l111_l1_ (u"ࠪࡣ࡛ࡕࡄࡠࠩ䚤") not in options:
		import M3U
		message = l1l111_l1_ (u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ䚥")
		if l1l111_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ䚦") not in options:
			try: M3U.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚧"),l1l111_l1_ (u"ࠧࠨ䚨"),l1l111_l1_ (u"ࠨࠩ䚩"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚪"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䚫"),l1l111_l1_ (u"ࠫࠬ䚬"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ䚭"),message)
			try: M3U.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚮"),l1l111_l1_ (u"ࠧࠨ䚯"),l1l111_l1_ (u"ࠨࠩ䚰"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚱"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䚲"),l1l111_l1_ (u"ࠫࠬ䚳"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ䚴"),message)
			try: M3U.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚵"),l1l111_l1_ (u"ࠧࠨ䚶"),l1l111_l1_ (u"ࠨࠩ䚷"),options+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䚸"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䚹"),l1l111_l1_ (u"ࠫࠬ䚺"),l1l111_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ䚻"),message)
		if l1l111_l1_ (u"࠭࡟ࡗࡑࡇࡣࠬ䚼") not in options:
			try: M3U.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚽"),l1l111_l1_ (u"ࠨࠩ䚾"),l1l111_l1_ (u"ࠩࠪ䚿"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛀"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䛁"),l1l111_l1_ (u"ࠬ࠭䛂"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪ䛃"),message)
			try: M3U.GROUPS(l1l1lll11l1l_l1_,l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䛄"),l1l111_l1_ (u"ࠨࠩ䛅"),l1l111_l1_ (u"ࠩࠪ䛆"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛇"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䛈"),l1l111_l1_ (u"ࠬ࠭䛉"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪ䛊"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1lll111l_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭䛋"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ䛌")+l1l1lll11l1l_l1_,l1lll_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1ll111l11_l1_
	return l1lll_l1_
def l1l1lll1l111_l1_(l1l1lll11l1l_l1_,options,l1l1ll1l111l_l1_):
	if l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䛍") in options and l1l1ll1l111l_l1_==l1l111_l1_ (u"ࠪࠫ䛎"): l1l1lll111ll_l1_(True)
	elif l1l1ll1l111l_l1_: l1l1lll111ll_l1_(False)
	l1l1ll1l1l11_l1_ = options.replace(l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䛏"),l1l111_l1_ (u"ࠬ࠭䛐")).replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䛑"),l1l111_l1_ (u"ࠧࠨ䛒")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䛓"),l1l111_l1_ (u"ࠩࠪ䛔"))
	if not l1l1ll1l111l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䛕"),l1l111_l1_ (u"ࠫฯำฯ๋อ๋ࠣีํࠠศๆๅหห๋ษࠨ䛖"),l1l111_l1_ (u"ࠬ࠭䛗"),763,l1l111_l1_ (u"࠭ࠧ䛘"),l1l111_l1_ (u"ࠧࠨ䛙"),l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䛚")+l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠩࠪ䛛"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䛜"):l1l1lll11l1l_l1_})
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䛝"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䛞"),l1l111_l1_ (u"࠭ࠧ䛟"),9999)
	l1llllll11_l1_ = [l1l111_l1_ (u"ࠧฤใ็ห๊࠭䛠"),l1l111_l1_ (u"ࠨ็ึุ่๊วหࠩ䛡"),l1l111_l1_ (u"่ࠩืึำ๊ศฬࠪ䛢"),l1l111_l1_ (u"ࠪฬึอๅอࠩ䛣"),l1l111_l1_ (u"ࠫศ฽แศๆࠣ์่ืส้่ࠪ䛤"),l1l111_l1_ (u"ࠬืๅืษ้ࠫ䛥"),l1l111_l1_ (u"࠭รฮัฮ࠱ศิัࠨ䛦"),l1l111_l1_ (u"ࠧิๆสื้࠭䛧"),l1l111_l1_ (u"ࠨ็๋ื๏่้ࠨ䛨"),l1l111_l1_ (u"ࠩฦุ์ื࠭ฤๅฮีࠬ䛩"),l1l111_l1_ (u"ࠪห้ศๆࠨ䛪"),l1l111_l1_ (u"ࠫ฻ำใࠨ䛫"),l1l111_l1_ (u"ࠬื๊ศุฬࠫ䛬"),l1l111_l1_ (u"࠭ๆ๋ฬไู่่ࠧ䛭"),l1l111_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䛮"),l1l111_l1_ (u"ࠨสฮࠤา๐ࠧ䛯"),l1l111_l1_ (u"ࠩา๎๋๐ษࠨ䛰"),l1l111_l1_ (u"ࠪื๋๎วหࠩ䛱"),l1l111_l1_ (u"ࠫศิั๊ࠩ䛲")]
	l1l1ll11l11l_l1_ = [l1l111_l1_ (u"ࠬอแๅษ่ࠫ䛳"),l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ䛴"),l1l111_l1_ (u"ࠧโ์็้ࠬ䛵"),l1l111_l1_ (u"ࠨใ็้ࠬ䛶")]
	l1ll11lllll_l1_ = [l1l111_l1_ (u"่ࠩืู้ไࠨ䛷"),l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䛸")]
	l1ll11111ll1_l1_ = [l1l111_l1_ (u"ู๊ࠫวาฯࠪ䛹"),l1l111_l1_ (u"๋ࠬำาฯํหฯ࠭䛺")]
	l1l1ll1l11ll_l1_ = [l1l111_l1_ (u"࠭ศาษ่ะࠬ䛻"),l1l111_l1_ (u"ࠧࡴࡪࡲࡻࠬ䛼"),l1l111_l1_ (u"ࠨฬ็ๅื๐่็ࠩ䛽"),l1l111_l1_ (u"ࠩอ่๏็า๋๊้ࠫ䛾")]
	l1l1llll11l1_l1_ = [l1l111_l1_ (u"ࠪห๋๋๊ࠨ䛿"),l1l111_l1_ (u"่ࠫืส้่ࠪ䜀"),l1l111_l1_ (u"้ࠬวาฬ๋๊ࠬ䜁"),l1l111_l1_ (u"࠭࡫ࡪࡦࡶࠫ䜂"),l1l111_l1_ (u"ุࠧใ็ࠫ䜃"),l1l111_l1_ (u"ࠨษฺๅฬ๊ࠧ䜄")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠩิ้฻อๆࠨ䜅")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠪหาีหࠨ䜆"),l1l111_l1_ (u"ࠫฬิัࠨ䜇"),l1l111_l1_ (u"๋่ࠬฯำࠪ䜈"),l1l111_l1_ (u"࠭ฬะ์าࠫ䜉"),l1l111_l1_ (u"ࠧๆุสๅࠬ䜊"),l1l111_l1_ (u"ࠨฯา๎ะ࠭䜋")]
	l1l1ll1ll11l_l1_ = [l1l111_l1_ (u"ࠩึ่ฬูไࠨ䜌"),l1l111_l1_ (u"ࠪืู้ไ่ࠩ䜍")]
	l1l1ll1111l1_l1_ = [l1l111_l1_ (u"ࠫฬเว็์ࠪ䜎"),l1l111_l1_ (u"๋่ࠬิ์ๅํࠬ䜏"),l1l111_l1_ (u"࠭ใๅ์หࠫ䜐"),l1l111_l1_ (u"ࠧฮใ็ࠫ䜑"),l1l111_l1_ (u"ࠨ࡯ࡸࡷ࡮ࡩࠧ䜒")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠩส็ะืࠧ䜓"),l1l111_l1_ (u"ࠪหูํัࠨ䜔"),l1l111_l1_ (u"๊๋๊ࠫำ้ࠪ䜕"),l1l111_l1_ (u"ࠬอูๅ๋ࠪ䜖"),l1l111_l1_ (u"࠭ๅฯฬสี์࠭䜗"),l1l111_l1_ (u"ࠧๆะอหึอสࠨ䜘"),l1l111_l1_ (u"ࠨษๅ์๎࠭䜙")]
	l1l1ll11111l_l1_ = [l1l111_l1_ (u"ࠩส่ฬ์ࠧ䜚"),l1l111_l1_ (u"ࠪัฬ๊๊ࠨ䜛"),l1l111_l1_ (u"๊ࠫัศหࠩ䜜"),l1l111_l1_ (u"ࠬืววฮࠪ䜝")]
	l1l1ll111l1l_l1_ = [l1l111_l1_ (u"࠭ึฮๅࠪ䜞"),l1l111_l1_ (u"ࠧไ๊่๎ิ๐ࠧ䜟")]
	l1l1llllll11_l1_ = [l1l111_l1_ (u"ࠨำํห฻ํࠧ䜠"),l1l111_l1_ (u"ࠩๆ์ึํࠧ䜡"),l1l111_l1_ (u"ฺ้ࠪอัฺ้ࠪ䜢"),l1l111_l1_ (u"ูࠫ๎สࠨ䜣"),l1l111_l1_ (u"ࠬื๊ศุฬࠫ䜤")]
	l1l1lll1ll1l_l1_ = [l1l111_l1_ (u"࠭ๆ๋ฬไู่่ࠧ䜥"),l1l111_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ䜦"),l1l111_l1_ (u"ࠨ่ํฮๆ๊๊ไีࠪ䜧")]
	l1l1ll111lll_l1_ = [l1l111_l1_ (u"่้ࠩะ๊๊็ࠩ䜨"),l1l111_l1_ (u"ࠪหูิวึࠩ䜩"),l1l111_l1_ (u"๋ࠫา่ๆࠩ䜪")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠬฮหࠡฯํࠫ䜫"),l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ䜬"),l1l111_l1_ (u"ࠧใ่ส๋ࠬ䜭"),l1l111_l1_ (u"ࠨไ้์ฬะࠧ䜮")]
	l1l1llll1111_l1_ = [l1l111_l1_ (u"ࠩา๎๋࠭䜯"),l1l111_l1_ (u"ࠪหิ฿๊่ࠩ䜰"),l1l111_l1_ (u"ࠫื๐วาษอࠫ䜱"),l1l111_l1_ (u"๊ࠬืๆ์สฮࠬ䜲"),l1l111_l1_ (u"࠭ฯฺษฤࠫ䜳"),l1l111_l1_ (u"ࠧใำส๊ࠬ䜴"),l1l111_l1_ (u"ࠨไุหหีࠧ䜵"),l1l111_l1_ (u"ࠩิฯฬวࠧ䜶"),l1l111_l1_ (u"้ࠪึาู๋้ࠪ䜷"),l1l111_l1_ (u"ࠫฬึว็ࠩ䜸"),l1l111_l1_ (u"ࠬอำๅษ่ࠫ䜹"),l1l111_l1_ (u"࠭ส้ษื๎า࠭䜺"),l1l111_l1_ (u"ࠧฯูหࠫ䜻"),l1l111_l1_ (u"ࠨฯ๋ึํ๐ࠧ䜼"),l1l111_l1_ (u"ࠩ฼ฮออสࠨ䜽"),l1l111_l1_ (u"้ࠪํอไ๋ัࠪ䜾"),l1l111_l1_ (u"๋ࠫ๎วฺ์ࠪ䜿"),l1l111_l1_ (u"ࠬ฿โศศาࠫ䝀"),l1l111_l1_ (u"࠭ว็ษื๎ิ࠭䝁")]
	l1l1ll11l1l1_l1_ = [l1l111_l1_ (u"ࠧ࠲࠻ࠪ䝂"),l1l111_l1_ (u"ࠨ࠴࠳ࠫ䝃"),l1l111_l1_ (u"ࠩ࠵࠵ࠬ䝄"),l1l111_l1_ (u"ࠪ࠶࠷࠭䝅"),l1l111_l1_ (u"ࠫ࠷࠹ࠧ䝆"),l1l111_l1_ (u"ࠬ࠸࠴ࠨ䝇"),l1l111_l1_ (u"࠭࠲࠶ࠩ䝈"),l1l111_l1_ (u"ࠧ࠳࠸ࠪ䝉")]
	if not l1l1ll1l111l_l1_:
		l1l1ll1l111l_l1_ = 0
		for l1l1lll11l11_l1_ in l1llllll11_l1_:
			l1l1ll1l111l_l1_ += 1
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝊"),l1lllll_l1_+l1l1lll11l11_l1_,l1l111_l1_ (u"ࠩࠪ䝋"),763,l1l111_l1_ (u"ࠪࠫ䝌"),str(l1l1ll1l111l_l1_),l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠫࠬ䝍"),{l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䝎"):l1l1lll11l1l_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l11111111l_l1_ = name.lower()
			category = []
			if any(value in l11111111l_l1_ for value in l1l1ll11l11l_l1_): category.append(1)
			if any(value in l11111111l_l1_ for value in l1ll11lllll_l1_): category.append(2)
			if any(value in l11111111l_l1_ for value in l1ll11111ll1_l1_): category.append(3)
			if any(value in l11111111l_l1_ for value in l1l1ll1l11ll_l1_): category.append(4)
			if any(value in l11111111l_l1_ for value in l1l1llll11l1_l1_): category.append(5)
			if any(value in l11111111l_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l11111111l_l1_ for value in l1lllll1l_l1_) and l11111111l_l1_ not in [l1l111_l1_ (u"࠭วฯำ์ࠫ䝏")]: category.append(7)
			if any(value in l11111111l_l1_ for value in l1l1ll1ll11l_l1_): category.append(8)
			if any(value in l11111111l_l1_ for value in l1l1ll1111l1_l1_): category.append(9)
			if any(value in l11111111l_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l11111111l_l1_ for value in l1l1ll11111l_l1_): category.append(11)
			if any(value in l11111111l_l1_ for value in l1l1ll111l1l_l1_): category.append(12)
			if any(value in l11111111l_l1_ for value in l1l1llllll11_l1_): category.append(13)
			if any(value in l11111111l_l1_ for value in l1l1lll1ll1l_l1_): category.append(14)
			if any(value in l11111111l_l1_ for value in l1l1ll111lll_l1_): category.append(15)
			if any(value in l11111111l_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l11111111l_l1_ for value in l1l1llll1111_l1_): category.append(17)
			if any(value in l11111111l_l1_ for value in l1l1ll11l1l1_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l1ll1l111l_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝐"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"ࠨࠩ䝑"),l1l111_l1_ (u"ࠩࠪ䝒"),l1l1ll1l1l11_l1_+l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䝓"))
	return
def l1l1llll1ll1_l1_(l1l1lll11l1l_l1_,options):
	l1l1lll111l_l1_ = False
	if l1l1lll111l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䝔"),l1l111_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ䝕"),l1l111_l1_ (u"࠭ࠧ䝖"),764,l1l111_l1_ (u"ࠧࠨ䝗"),l1l111_l1_ (u"ࠨࠩ䝘"),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䝙"),l1l111_l1_ (u"ࠪࠫ䝚"),{l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝛"):l1l1lll11l1l_l1_})
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䝜"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䝝"),l1l111_l1_ (u"ࠧࠨ䝞"),9999)
	l1l1ll111l11_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l1lll11l1l_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l1lll11l1l_l1_,True): return
		l1l1ll1ll1l1_l1_ = l1l1ll1ll111_l1_(l1l1lll11l1l_l1_,options)
		l111l1ll11_l1_ = sorted(l1l1ll1ll1l1_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䝟"),True): return
		if l1l1lll111l_l1_ and l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䝠") not in options:
			l111l1ll11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䝡"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ䝢"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤࡇࡌࡍࠩ䝣"))
		else:
			l1l1ll11l1ll_l1_,l111l1ll11_l1_,l1l1ll1ll1l1_l1_ = [],[],[]
			for l1l1lll111l1_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1ll11_l1_ += l1l1ll1ll111_l1_(str(l1l1lll111l1_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l111l1ll11_l1_:
				if text not in l1l1ll11l1ll_l1_:
					l1l1ll11l1ll_l1_.append(text)
					l1l1lllllll1_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1ll_l1_
					l1l1ll1ll1l1_l1_.append(l1l1lllllll1_l1_)
			l111l1ll11_l1_ = sorted(l1l1ll1ll1l1_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1lll111l_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭䝤"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࡂࡎࡏࠫ䝥"),l111l1ll11_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1ll111l11_l1_+l111l1ll11_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䝦"))
	return
def l1ll11111111_l1_(l1l1lll11l1l_l1_,options):
	l1l1lll111l_l1_ = False
	if l1l1lll111l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䝧"),l1l111_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ䝨"),l1l111_l1_ (u"ࠫࠬ䝩"),765,l1l111_l1_ (u"ࠬ࠭䝪"),l1l111_l1_ (u"࠭ࠧ䝫"),l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䝬"),l1l111_l1_ (u"ࠨࠩ䝭"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝮"):l1l1lll11l1l_l1_})
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䝯"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䝰"),l1l111_l1_ (u"ࠬ࠭䝱"),9999)
	l1l1ll111l11_l1_ = menuItemsLIST[:]
	import M3U
	if l1l1lll11l1l_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l1lll11l1l_l1_,True): return
		l1l1ll1ll1l1_l1_ = l1l1lll11lll_l1_(l1l1lll11l1l_l1_,options)
		l111l1ll11_l1_ = sorted(l1l1ll1ll1l1_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䝲"),True): return
		if l1l1lll111l_l1_ and l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䝳") not in options:
			l111l1ll11_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䝴"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䝵"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࡄࡐࡑ࠭䝶"))
		else:
			l1l1ll11l1ll_l1_,l111l1ll11_l1_,l1l1ll1ll1l1_l1_ = [],[],[]
			for l1l1lll111l1_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1ll11_l1_ += l1l1lll11lll_l1_(str(l1l1lll111l1_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l111l1ll11_l1_:
				if text not in l1l1ll11l1ll_l1_:
					l1l1ll11l1ll_l1_.append(text)
					l1l1lllllll1_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1ll_l1_
					l1l1ll1ll1l1_l1_.append(l1l1lllllll1_l1_)
			l111l1ll11_l1_ = sorted(l1l1ll1ll1l1_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1lll111l_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ䝷"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࡆࡒࡌࠨ䝸"),l111l1ll11_l1_,l1ll111ll11_l1_)
	menuItemsLIST[:] = l1l1ll111l11_l1_+l111l1ll11_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䝹"))
	return
def l1l1ll11llll_l1_(group,options):
	l1l1lll111l_l1_ = False
	l1lll_l1_ = []
	l1l1lll11ll1_l1_ = l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䝺") if l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭䝻") in options else l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䝼")
	if l1l1lll111l_l1_: l1lll_l1_ = l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䝽"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭䝾")+l1l1lll11ll1_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
			if l1l1lll111l_l1_: l1lll_l1_ += l1lll11l1ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䝿"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ䞀")+l1l1lll11ll1_l1_[:-1],l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ䞁")+l1l1lll11ll1_l1_+str(l1l1lll11l1l_l1_))
			elif l1l1lll11ll1_l1_==l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䞂"): l1lll_l1_ += l1l1ll1ll111_l1_(str(l1l1lll11l1l_l1_),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䞃"))
			elif l1l1lll11ll1_l1_==l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䞄"): l1lll_l1_ += l1l1lll11lll_l1_(str(l1l1lll11l1l_l1_),l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䞅"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1lll_l1_:
			if text==group: l1lll11l1ll1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in menuItemsLIST:
			l1l1lll1llll_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠬ࠭䞆")
			if l1l1lll1llll_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1lll1llll_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l1l1lll111l_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ䞇")+l1l1lll11ll1_l1_[:-1],group,l1lll_l1_,l1ll111ll11_l1_)
	if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䞈") in options and len(l1lll_l1_)>l1l1lllll111_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䞉"),l1l111_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䞊")+group+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭䞋"),group,165,l1l111_l1_ (u"ࠫࠬ䞌"),l1l111_l1_ (u"ࠬ࠭䞍"),l1l1lll11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞎"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䞏"),l1l111_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䞐"),group,165,l1l111_l1_ (u"ࠩࠪ䞑"),l1l111_l1_ (u"ࠪࠫ䞒"),l1l1lll11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䞓"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䞔"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䞕"),l1l111_l1_ (u"ࠧࠨ䞖"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1lllll111_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䞗"))
	return
def l1ll11111lll_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䞘"),l1l111_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭䞙"),l1l111_l1_ (u"ࠫࠬ䞚"),161,l1l111_l1_ (u"ࠬ࠭䞛"),l1l111_l1_ (u"࠭ࠧ䞜"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ䞝"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䞞"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䞟"),l1l111_l1_ (u"ࠪࠫ䞠"),9999)
	l1l1llll1l1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1llllll1111_l1_
	l1llllll1111_l1_.ITEMS(l1l111_l1_ (u"ࠫ࠵࠭䞡"),False)
	l1llllll1111_l1_.ITEMS(l1l111_l1_ (u"ࠬ࠷ࠧ䞢"),False)
	l1llllll1111_l1_.ITEMS(l1l111_l1_ (u"࠭࠲ࠨ䞣"),False)
	if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䞤") in options:
		menuItemsLIST[:] = l1l1ll1llll1_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1lllll111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1lllll111_l1_)
	menuItemsLIST[:] = l1l1llll1l1l_l1_+menuItemsLIST
	return
def l1ll11111l1l_l1_(options):
	options = options.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䞥"),l1l111_l1_ (u"ࠩࠪ䞦")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䞧"),l1l111_l1_ (u"ࠫࠬ䞨"))
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䞩") : l1l111_l1_ (u"࠭ࠧ䞪") }
	url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭䞫")
	data = {l1l111_l1_ (u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪ䞬"):l1l111_l1_ (u"ࠩ࠸࠴ࠬ䞭")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1llll1ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䞮"),url,data,headers,l1l111_l1_ (u"ࠫࠬ䞯"),l1l111_l1_ (u"ࠬ࠭䞰"),l1l111_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࡙࠭ࡓࡃࡑࡈࡔࡓ࡟ࡗࡋࡇࡉࡔ࡙࡟ࡇࡔࡒࡑࡤ࡝ࡏࡓࡆࡖ࠱࠶ࡹࡴࠨ䞱"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩ䞲"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭䞳"),block,re.DOTALL)
	l1l1l1llllll_l1_,l1l1ll11ll11_l1_ = list(zip(*items))
	l1l1llllllll_l1_ = []
	l1ll11111l11_l1_ = [l1l111_l1_ (u"ࠩࠣࠫ䞴"),l1l111_l1_ (u"ࠪࠦࠬ䞵"),l1l111_l1_ (u"ࠫࡥ࠭䞶"),l1l111_l1_ (u"ࠬ࠲ࠧ䞷"),l1l111_l1_ (u"࠭࠮ࠨ䞸"),l1l111_l1_ (u"ࠧ࠻ࠩ䞹"),l1l111_l1_ (u"ࠨ࠽ࠪ䞺"),l1l111_l1_ (u"ࠤࠪࠦ䞻"),l1l111_l1_ (u"ࠪ࠱ࠬ䞼")]
	l1l1ll1l1l1l_l1_ = l1l1ll11ll11_l1_+l1l1l1llllll_l1_
	for word in l1l1ll1l1l1l_l1_:
		if word in l1l1ll11ll11_l1_: l1l1lll1ll11_l1_ = 2
		if word in l1l1l1llllll_l1_: l1l1lll1ll11_l1_ = 4
		l1l1ll1l1lll_l1_ = [i in word for i in l1ll11111l11_l1_]
		if any(l1l1ll1l1lll_l1_):
			index = l1l1ll1l1lll_l1_.index(True)
			l1l1ll1l11l1_l1_ = l1ll11111l11_l1_[index]
			l1l1lllll1l1_l1_ = l1l111_l1_ (u"ࠫࠬ䞽")
			if word.count(l1l1ll1l11l1_l1_)>1: l1l1lllll1ll_l1_,l1l1lllll11l_l1_,l1l1lllll1l1_l1_ = word.split(l1l1ll1l11l1_l1_,2)
			else: l1l1lllll1ll_l1_,l1l1lllll11l_l1_ = word.split(l1l1ll1l11l1_l1_,1)
			if len(l1l1lllll1ll_l1_)>l1l1lll1ll11_l1_: l1l1llllllll_l1_.append(l1l1lllll1ll_l1_.lower())
			if len(l1l1lllll11l_l1_)>l1l1lll1ll11_l1_: l1l1llllllll_l1_.append(l1l1lllll11l_l1_.lower())
			if len(l1l1lllll1l1_l1_)>l1l1lll1ll11_l1_: l1l1llllllll_l1_.append(l1l1lllll1l1_l1_.lower())
		elif len(word)>l1l1lll1ll11_l1_: l1l1llllllll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1llllllll_l1_)
	if l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䞾") in options:
		l1l1ll111ll1_l1_ = l1lll1l1ll1l_l1_
	elif l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䞿") in options:
		l1l1ll111ll1_l1_ = [l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ䟀")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䟁"),True): return
	elif l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䟂") in options:
		l1l1ll111ll1_l1_ = [l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ䟃")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠫࠬ䟄"),True): return
	count,l1l1ll11ll1l_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䟅"),l1l111_l1_ (u"࡛࠭ࠡࠢࡠࠤ࠿อไษฯฮࠤ฾์ࠧ䟆"),l1l111_l1_ (u"ࠧࠨ䟇"),164,l1l111_l1_ (u"ࠨࠩ䟈"),l1l111_l1_ (u"ࠩࠪ䟉"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䟊")+options)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䟋"),l1l111_l1_ (u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬ䟌"),l1l111_l1_ (u"࠭ࠧ䟍"),164,l1l111_l1_ (u"ࠧࠨ䟎"),l1l111_l1_ (u"ࠨࠩ䟏"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䟐")+options)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䟑"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䟒"),l1l111_l1_ (u"ࠬ࠭䟓"),9999)
	l1l1l1lllll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1ll111111ll_l1_ = []
	for word in l1l1llllllll_l1_:
		l1l1lllll11l_l1_ = re.findall(l1l111_l1_ (u"࡛࠭ࠡ࡞࠯ࡠࡀࡢ࠺࡝࠯࡟࠯ࡡࡃ࡜ࠣ࡞ࠪࡠࡠࡢ࡝࡝ࠪ࡟࠭ࡡࢁ࡜ࡾ࡞ࠤࡠࡅ࠭䟔")+l1l111_l1_ (u"ࠧࠤࠩ䟕")+l1l111_l1_ (u"ࠨ࡞ࠧࡠࠪࡢ࡞࡝ࠨ࡟࠮ࡡࡥ࡜࠽࡞ࡁࡡࠬ䟖"),word,re.DOTALL)
		if l1l1lllll11l_l1_: word = word.split(l1l1lllll11l_l1_[0],1)[0]
		l1l1llll11ll_l1_ = word.replace(l1l111_l1_ (u"ࠩ๔ࠫ䟗"),l1l111_l1_ (u"ࠪࠫ䟘")).replace(l1l111_l1_ (u"ࠫ๓࠭䟙"),l1l111_l1_ (u"ࠬ࠭䟚")).replace(l1l111_l1_ (u"๋࠭ࠨ䟛"),l1l111_l1_ (u"ࠧࠨ䟜")).replace(l1l111_l1_ (u"ࠨ๑ࠪ䟝"),l1l111_l1_ (u"ࠩࠪ䟞")).replace(l1l111_l1_ (u"ࠪ๐ࠬ䟟"),l1l111_l1_ (u"ࠫࠬ䟠"))
		l1l1llll11ll_l1_ = l1l1llll11ll_l1_.replace(l1l111_l1_ (u"ࠬ๖ࠧ䟡"),l1l111_l1_ (u"࠭ࠧ䟢")).replace(l1l111_l1_ (u"ࠧ๎ࠩ䟣"),l1l111_l1_ (u"ࠨࠩ䟤")).replace(l1l111_l1_ (u"ࠩ๕ࠫ䟥"),l1l111_l1_ (u"ࠪࠫ䟦")).replace(l1l111_l1_ (u"ࠫฑ࠭䟧"),l1l111_l1_ (u"ࠬ࠭䟨")).replace(l1l111_l1_ (u"࠭เࠨ䟩"),l1l111_l1_ (u"ࠧࠨ䟪"))
		if l1l1llll11ll_l1_: l1ll111111ll_l1_.append(l1l1llll11ll_l1_)
	l1l1llll111l_l1_ = []
	for l1l111llll_l1_ in range(0,20):
		search = random.sample(l1ll111111ll_l1_,1)[0]
		if search in l1l1llll111l_l1_: continue
		l1l1llll111l_l1_.append(search)
		l1lll11ll1l_l1_ = random.sample(l1l1ll111ll1_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䟫"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬ䟬")+str(l1lll11ll1l_l1_)+l1l111_l1_ (u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭䟭")+search)
		l1lll111l11_l1_,l1lll11ll11_l1_,l1llll111ll_l1_ = l1ll1llllll_l1_(l1lll11ll1l_l1_)
		l1lll11ll11_l1_(search+l1l111_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ䟮"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䟯"),l1l111_l1_ (u"࠭ࠧ䟰"))
	l1l1l1lllll1_l1_[0][1] = l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䟱")+search+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾อำหࠡ฻้ࡡࠬ䟲")
	menuItemsLIST[:] = l1l1ll1llll1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1lllll111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1lllll111_l1_)
	menuItemsLIST[:] = l1l1l1lllll1_l1_+menuItemsLIST
	return
def l1l1llllll1l_l1_(l1l1ll1l1111_l1_,options):
	l1l1ll1l1111_l1_ = l1l1ll1l1111_l1_.replace(l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䟳"),l1l111_l1_ (u"ࠪࠫ䟴"))
	options = options.replace(l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䟵"),l1l111_l1_ (u"ࠬ࠭䟶")).replace(l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䟷"),l1l111_l1_ (u"ࠧࠨ䟸"))
	l1l1lll111ll_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䟹") in options:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟺"),l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䟻")+l1l1ll1l1111_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䟼"),l1l1ll1l1111_l1_,166,l1l111_l1_ (u"ࠬ࠭䟽"),l1l111_l1_ (u"࠭ࠧ䟾"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟿")+options)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠀"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ䠁"),l1l1ll1l1111_l1_,166,l1l111_l1_ (u"ࠪࠫ䠂"),l1l111_l1_ (u"ࠫࠬ䠃"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䠄")+options)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䠅"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䠆"),l1l111_l1_ (u"ࠨࠩ䠇"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l1ll1l1111_l1_].keys())):
		type,name,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = contentsDICT[l1l1ll1l1111_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䠈") in options or len(contentsDICT[l1l1ll1l1111_l1_])==1:
			l1lll11l1ll1_l1_(type,l1l111_l1_ (u"ࠪࠫ䠉"),url,l1lll1ll11l1_l1_,l1l111_l1_ (u"ࠫࠬ䠊"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠬ࠭䠋"),l1l111_l1_ (u"࠭ࠧ䠌"))
			menuItemsLIST[:] = l1l1ll1llll1_l1_(menuItemsLIST)
			l1l1ll111l11_l1_,l111l1ll11_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1ll11_l1_)
			if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䠍") in options: menuItemsLIST[:] = l1l1ll111l11_l1_+l111l1ll11_l1_[:l1l1lllll111_l1_]
			else: menuItemsLIST[:] = l1l1ll111l11_l1_+l111l1ll11_l1_
		elif l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ䠎") in options: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䠏"),l1l11l11_l1_,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
	return
def l1l1ll1ll1ll_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䠐"),l1l111_l1_ (u"ࠫࠬ䠑")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠒"),l1l111_l1_ (u"࠭ࠧ䠓"))
	name,l1l1ll1l1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ䠔"),[]
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠕"),l1l111_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䠖")+name+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭䠗"),l1l111_l1_ (u"ࠫࠬ䠘"),mode,l1l111_l1_ (u"ࠬ࠭䠙"),l1l111_l1_ (u"࠭ࠧ䠚"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䠛")+options)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䠜"),l1l111_l1_ (u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩ䠝"),l1l111_l1_ (u"ࠪࠫ䠞"),mode,l1l111_l1_ (u"ࠫࠬ䠟"),l1l111_l1_ (u"ࠬ࠭䠠"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠡")+options)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䠢"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䠣"),l1l111_l1_ (u"ࠩࠪ䠤"),9999)
	l1l1ll111l11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䠥") in options:
		l1l1lll111ll_l1_(False)
		if contentsDICT=={}: return
		l1l1ll1lll1l_l1_ = list(contentsDICT.keys())
		l1l1ll1l1111_l1_ = random.sample(l1l1ll1lll1l_l1_,1)[0]
		l1l1llllllll_l1_ = list(contentsDICT[l1l1ll1l1111_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1llllllll_l1_,1)[0]
		type,name,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = contentsDICT[l1l1ll1l1111_l1_][l1l11l11_l1_]
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䠦"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡽࡥࡣࡵ࡬ࡸࡪࡀࠠࠨ䠧")+l1l11l11_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ䠨")+name+l1l111_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䠩")+url+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䠪")+str(l1lll1ll11l1_l1_))
	elif l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䠫") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䠬"),True): return
		for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1ll1ll111_l1_(str(l1l1lll11l1l_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䠭"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ䠮")+name+l1l111_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ䠯")+url+l1l111_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ䠰")+str(l1lll1ll11l1_l1_))
	elif l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䠱") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠩࠪ䠲"),True): return
		for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1lll11lll_l1_(str(l1l1lll11l1l_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䠳"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䠴")+name+l1l111_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䠵")+url+l1l111_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䠶")+str(l1lll1ll11l1_l1_))
	l1l1lll1lll1_l1_ = name
	l1l1lll11111_l1_ = []
	for i in range(0,10):
		if i>0: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䠷"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ䠸")+name+l1l111_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ䠹")+url+l1l111_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭䠺")+str(l1lll1ll11l1_l1_))
		menuItemsLIST[:] = []
		if l1lll1ll11l1_l1_==234 and l1l111_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䠻") in text: l1lll1ll11l1_l1_ = 233
		if l1lll1ll11l1_l1_==714 and l1l111_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ䠼") in text: l1lll1ll11l1_l1_ = 713
		if l1lll1ll11l1_l1_==144: l1lll1ll11l1_l1_ = 291
		dummy = l1lll11l1ll1_l1_(type,name,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
		if l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䠽") in options and l1lll1ll11l1_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䠾") in options and l1lll1ll11l1_l1_==168: del menuItemsLIST[:3]
		l1l1ll1l1ll1_l1_[:] = l1l1ll1llll1_l1_(menuItemsLIST)
		if l1l1lll11111_l1_ and l111lllllll_l1_(l1l111_l1_ (u"ࡶࠩะ่็ฯࠧ䠿")) in str(l1l1ll1l1ll1_l1_) or l111lllllll_l1_(l1l111_l1_ (u"ࡷࠪั้่็ࠨ䡀")) in str(l1l1ll1l1ll1_l1_):
			name = l1l1lll1lll1_l1_
			l1l1ll1l1ll1_l1_[:] = l1l1lll11111_l1_
			break
		l1l1lll1lll1_l1_ = name
		l1l1lll11111_l1_ = l1l1ll1l1ll1_l1_
		if str(l1l1ll1l1ll1_l1_).count(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䡁"))>0: break
		if str(l1l1ll1l1ll1_l1_).count(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䡂"))>0: break
		if l1lll1ll11l1_l1_==233: break
		if l1lll1ll11l1_l1_==713: break
		if l1lll1ll11l1_l1_==291: break
		if l1l1ll1l1ll1_l1_: type,name,url,l1lll1ll11l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1l1ll1l1ll1_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠬ࠴࠮࠯࠰ࠪ䡃")
	elif name.count(l1l111_l1_ (u"࠭࡟ࠨ䡄"))>1: name = name.split(l1l111_l1_ (u"ࠧࡠࠩ䡅"),2)[2]
	name = name.replace(l1l111_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫ䡆"),l1l111_l1_ (u"ࠩࠪ䡇"))
	name = name.replace(l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䡈"),l1l111_l1_ (u"ࠫࠬ䡉"))
	l1l1ll111l11_l1_[0][1] = l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䡊")+name+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ䡋")
	for i in range(9): random.shuffle(l1l1ll1l1ll1_l1_)
	if l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䡌") in options: menuItemsLIST[:] = l1l1ll111l11_l1_+l1l1ll1l1ll1_l1_[:l1l1lllll111_l1_]
	else: menuItemsLIST[:] = l1l1ll111l11_l1_+l1l1ll1l1ll1_l1_
	return
def l1l1ll11lll1_l1_(l1l1ll111111_l1_,l1l1llll1lll_l1_):
	l1l1llll1lll_l1_ = l1l1llll1lll_l1_.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡍"),l1l111_l1_ (u"ࠩࠪ䡎")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡏"),l1l111_l1_ (u"ࠫࠬ䡐"))
	l1l1ll1lll11_l1_ = l1l1llll1lll_l1_
	if l1l111_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䡑") in l1l1llll1lll_l1_:
		l1l1ll1lll11_l1_ = l1l1llll1lll_l1_.split(l1l111_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䡒"))[0]
		type = l1l111_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ䡓")
	elif l1l111_l1_ (u"ࠨࡘࡒࡈࠬ䡔") in l1l1ll111111_l1_: type = l1l111_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ䡕")
	elif l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䡖") in l1l1ll111111_l1_: type = l1l111_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ䡗")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䡘"),l1l111_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䡙")+type+l1l1ll1lll11_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ䡚"),l1l1ll111111_l1_,167,l1l111_l1_ (u"ࠨࠩ䡛"),l1l111_l1_ (u"ࠩࠪ䡜"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡝")+l1l1llll1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䡞"),l1l111_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ䡟"),l1l1ll111111_l1_,167,l1l111_l1_ (u"࠭ࠧ䡠"),l1l111_l1_ (u"ࠧࠨ䡡"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䡢")+l1l1llll1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䡣"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䡤"),l1l111_l1_ (u"ࠫࠬ䡥"),9999)
	import IPTV
	for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䡦") in l1l1llll1lll_l1_: IPTV.GROUPS(str(l1l1lll11l1l_l1_),l1l1ll111111_l1_,l1l1llll1lll_l1_,l1l111_l1_ (u"࠭ࠧ䡧"),False)
		else: IPTV.ITEMS(str(l1l1lll11l1l_l1_),l1l1ll111111_l1_,l1l1llll1lll_l1_,l1l111_l1_ (u"ࠧࠨ䡨"),False)
	menuItemsLIST[:] = l1l1ll1llll1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1lllll111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1lllll111_l1_)
	return
def l1l1ll1111ll_l1_(l1l1ll111111_l1_,l1l1llll1lll_l1_):
	l1l1llll1lll_l1_ = l1l1llll1lll_l1_.replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡩"),l1l111_l1_ (u"ࠩࠪ䡪")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡫"),l1l111_l1_ (u"ࠫࠬ䡬"))
	l1l1ll1lll11_l1_ = l1l1llll1lll_l1_
	if l1l111_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ䡭") in l1l1llll1lll_l1_:
		l1l1ll1lll11_l1_ = l1l1llll1lll_l1_.split(l1l111_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䡮"))[0]
		type = l1l111_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ䡯")
	elif l1l111_l1_ (u"ࠨࡘࡒࡈࠬ䡰") in l1l1ll111111_l1_: type = l1l111_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ䡱")
	elif l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ䡲") in l1l1ll111111_l1_: type = l1l111_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ䡳")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䡴"),l1l111_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䡵")+type+l1l1ll1lll11_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ䡶"),l1l1ll111111_l1_,168,l1l111_l1_ (u"ࠨࠩ䡷"),l1l111_l1_ (u"ࠩࠪ䡸"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡹")+l1l1llll1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䡺"),l1l111_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ䡻"),l1l1ll111111_l1_,168,l1l111_l1_ (u"࠭ࠧ䡼"),l1l111_l1_ (u"ࠧࠨ䡽"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䡾")+l1l1llll1lll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䡿"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䢀"),l1l111_l1_ (u"ࠫࠬ䢁"),9999)
	import M3U
	for l1l1lll11l1l_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ䢂") in l1l1llll1lll_l1_: M3U.GROUPS(str(l1l1lll11l1l_l1_),l1l1ll111111_l1_,l1l1llll1lll_l1_,l1l111_l1_ (u"࠭ࠧ䢃"),False)
		else: M3U.ITEMS(str(l1l1lll11l1l_l1_),l1l1ll111111_l1_,l1l1llll1lll_l1_,l1l111_l1_ (u"ࠧࠨ䢄"),False)
	menuItemsLIST[:] = l1l1ll1llll1_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1lllll111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1lllll111_l1_)
	return
def l1l1ll1llll1_l1_(menuItemsLIST):
	l1l1ll1l1ll1_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"ࠨืไัฮ࠭䢅") in name or l1l111_l1_ (u"ุࠩๅาํࠧ䢆") in name or l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ䢇") in name.lower(): continue
		l1l1ll1l1ll1_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_])
	return l1l1ll1l1ll1_l1_
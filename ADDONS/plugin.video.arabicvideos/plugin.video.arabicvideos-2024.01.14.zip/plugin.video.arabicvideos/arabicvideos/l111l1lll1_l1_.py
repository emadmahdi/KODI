# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ⋎")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡅ࠸ࡤ࠭⋏")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษํะ๏ࠦศิฬࠪ⋐"),l1l111_l1_ (u"ࠩสฮฺ๊ࠠษ่สࠫ⋑"),l1l111_l1_ (u"ࠪห๏า๊ࠡสึฮࠥอไศื็๎ࠬ⋒"),l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯࠦวๅฮา๎ิ࠭⋓"),l1l111_l1_ (u"ࠬอ๊อ์ࠣฬุะࠠศๆหำ๏๊ࠧ⋔"),l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ⋕"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬุะࠧ⋖")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==800: l1lll_l1_ = l1l1l11_l1_()
	elif mode==801: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==802: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==803: l1lll_l1_ = PLAY(url)
	elif mode==804: l1lll_l1_ = l111ll11l1_l1_(url)
	elif mode==806: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==809: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋗"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⋘"),l1l111_l1_ (u"ࠪࠫ⋙"),809,l1l111_l1_ (u"ࠫࠬ⋚"),l1l111_l1_ (u"ࠬ࠭⋛"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⋜"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋝"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึ࠭⋞"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ⋟"),804,l1l111_l1_ (u"ࠪࠫ⋠"),l1l111_l1_ (u"ࠫࠬ⋡"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⋢"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⋣"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⋤"),l1l111_l1_ (u"ࠨࠩ⋥"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⋦"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ⋧"),l1l111_l1_ (u"ࠫࠬ⋨"),l1l111_l1_ (u"ࠬ࠭⋩"),l1l111_l1_ (u"࠭ࠧ⋪"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⋫"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡺ࠲ࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⋬"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⋭"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⋮"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⋯") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⋰"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⋱")+l1lllll_l1_+title,l1ll1ll_l1_,801)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⋲"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⋳"),l1l111_l1_ (u"ࠩࠪ⋴"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࡄࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂࡦࡰࡱࡷࡩࡷࡄࠧ⋵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡖ࡬ࡸࡱ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⋶"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⋷"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ⋸") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋹"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⋺")+l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠩࠪ⋻"),l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࡮ࡧࡱࡹࠬ⋼"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⋽"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⋾"),l1l111_l1_ (u"࠭ࠧ⋿"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⌀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⌁"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ⌂"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⌃") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌄"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⌅")+l1lllll_l1_+title,l1ll1ll_l1_,801)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"࠭ࠧ⌆")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⌇"),url,l1l111_l1_ (u"ࠨࠩ⌈"),l1l111_l1_ (u"ࠩࠪ⌉"),l1l111_l1_ (u"ࠪࠫ⌊"),l1l111_l1_ (u"ࠫࠬ⌋"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⌌"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡘ࡮ࡺ࡬ࡦ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫࡳࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࠧ⌍"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠧࠨ⌎"),l1l111_l1_ (u"ࠨࠩ⌏"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠩะ่็อสࠨ⌐") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"้ࠪํอำๆࠩ⌑") in name: l111lllll1_l1_ = block
		if l111lllll1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⌒"),l111lllll1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⌓"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭⌔"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⌕"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⌖"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⌗"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⌘"),l1lllll_l1_+title,l1ll1ll_l1_,803)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠫࠬ⌙")):
	limit,start,l1l1l1ll1_l1_,select,l111ll111l_l1_ = 0,0,l1l111_l1_ (u"ࠬ࠭⌚"),l1l111_l1_ (u"࠭ࠧ⌛"),l1l111_l1_ (u"ࠧࠨ⌜")
	if l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ⌝") in type:
		l111ll1l11_l1_,l1l11llll_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡲࡪࡾࡴ࠾ࡲࡤ࡫ࡪࠬࠧ⌞"))
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⌟"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⌠")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ⌡"),l111ll1l11_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ⌢"),l1l111_l1_ (u"ࠧࠨ⌣"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⌤"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠩࡶࡩࡨࡉ࡯࡯ࡶࡨࡲࡹ࠭⌥")+html+l1l111_l1_ (u"ࠪࡀ࡫ࡵ࡯ࡵࡧࡵࡂࠬ⌦")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⌧"),url,l1l111_l1_ (u"ࠬ࠭⌨"),l1l111_l1_ (u"࠭ࠧ〈"),l1l111_l1_ (u"ࠧࠨ〉"),l1l111_l1_ (u"ࠨࠩ⌫"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⌬"))
		html = response.content
		l11l1ll1_l1_ = html
	items,l111llllll_l1_,filters = [],False,False
	if not type and l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮ࡴࠩ⌭") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⌮"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⌯"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ⌰"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌱"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠨࠩ⌲"),l1l111_l1_ (u"ࠩࡶࡹࡧࡳࡥ࡯ࡷࠪ⌳"))
				l111llllll_l1_ = True
	if not l111llllll_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡪࡩࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯ࡅࡲࡲࡹ࡫࡮ࡵࠩ⌴"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⌵"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠬࡢ࡮ࠨ⌶"))
				title = unescapeHTML(title)
				if l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⌷") in l1ll1ll_l1_ and type==l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⌸"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌹"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ⌺"))
				elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⌻") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌼"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡹ࠯ࠨ⌽") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⌾"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⌿"))
				elif l1l111_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡹࠧ⍀") in url: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍁"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠪࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳࠨ⍂"))
				else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⍃"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡲ࡯ࡢࡦࡐࡳࡷ࡫ࡐࡢࡴࡤࡱࡸࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻ࠨ⍄"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			params = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ⍅"),block)
			l111ll111l_l1_ = params[l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼࡺࡸ࡬ࠨ⍆")]
			l111l1llll_l1_ = int(params[l1l111_l1_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡳࡥ࡬࡫ࠧ⍇")])+1
			l111ll1111_l1_ = int(params[l1l111_l1_ (u"ࠩࡰࡥࡽࡥࡰࡢࡩࡨࠫ⍈")])
			query = params[l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡴࠩ⍉")].replace(l1l111_l1_ (u"ࠫࡋࡧ࡬ࡴࡧࠪ⍊"),l1l111_l1_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ⍋")).replace(l1l111_l1_ (u"࠭ࡔࡳࡷࡨࠫ⍌"),l1l111_l1_ (u"ࠧࡵࡴࡸࡩࠬ⍍")).replace(l1l111_l1_ (u"ࠨࡐࡲࡲࡪ࠭⍎"),l1l111_l1_ (u"ࠩࡱࡹࡱࡲࠧ⍏"))
			if l111l1llll_l1_<l111ll1111_l1_:
				l1l11llll_l1_ = l1l111_l1_ (u"ࠪࡥࡨࡺࡩࡰࡰࡀࡰࡴࡧࡤ࡮ࡱࡵࡩࠫࡷࡵࡦࡴࡼࡁࠬ⍐")+QUOTE(query,l1l111_l1_ (u"ࠫࠬ⍑"))+l1l111_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ⍒")+str(l111l1llll_l1_)
				l1lllll1_l1_ = l111ll111l_l1_+l1l111_l1_ (u"࠭࠿࡯ࡧࡻࡸࡂࡶࡡࡨࡧࠩࠫ⍓")+l1l11llll_l1_
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⍔"),l1lllll_l1_+l1l111_l1_ (u"ࠨฮ็ฬࠥอไๆิํำࠬ⍕"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠩࠪ⍖"),l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࡟ࠨ⍗")+type)
		elif l1l111_l1_ (u"ࠫࡄࡴࡥࡹࡶࡀࡴࡦ࡭ࡥࠧࠩ⍘") in url:
			l1l11llll_l1_,l1lll1l1l_l1_ = l1l11llll_l1_.rsplit(l1l111_l1_ (u"ࠬࡃࠧ⍙"),1)
			l1lll1l1l_l1_ = int(l1lll1l1l_l1_)+1
			l1lllll1_l1_ = l111ll1l11_l1_+l1l111_l1_ (u"࠭࠿࡯ࡧࡻࡸࡂࡶࡡࡨࡧࠩࠫ⍚")+l1l11llll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ⍛")+str(l1lll1l1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⍜"),l1lllll_l1_+l1l111_l1_ (u"ࠩฯ่อࠦวๅ็ี๎ิ࠭⍝"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠪࠫ⍞"),l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡠࠩ⍟")+type)
	return
def l111ll11l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⍠"),url,l1l111_l1_ (u"࠭ࠧ⍡"),l1l111_l1_ (u"ࠧࠨ⍢"),l1l111_l1_ (u"ࠨࠩ⍣"),l1l111_l1_ (u"ࠩࠪ⍤"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲ࡌࡉࡍࡖࡈࡖࡘ࠳࠱ࡴࡶࠪ⍥"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡻࡢࡠࡰࡤࡺ࠭࠴ࠪࡀࠫࡶࡩࡨࡉ࡯࡯ࡶࡨࡲࡹࠦࠧ⍦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡶࡴࡵࡩࡳࡺ࡟ࡰࡲࡷࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⍧"),block,re.DOTALL)
		for name,block in l1lll1l1_l1_:
			if l1l111_l1_ (u"࠭วๅฬุ๊๏็ࠧ⍨") in name: continue
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ⍩"))
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⍪"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭⍫")+value
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⍬"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠫࠬ⍭"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⍮"))
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⍯"),url,l1l111_l1_ (u"ࠧࠨ⍰"),l1l111_l1_ (u"ࠨࠩ⍱"),l1l111_l1_ (u"ࠩࠪ⍲"),l1l111_l1_ (u"ࠪࠫ⍳"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⍴"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡥࡀส่ฯ฻ๆ๋ใ࠿࠳ࡹࡪ࠾࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⍵"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l111ll1ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡉࡲࡨࡥࡥ࠰࠭ࡃࡵࡵࡳࡵ࠿ࠫ࠲࠯ࡅࠩࠣࠩ⍶"),html,re.DOTALL)
	if l111ll1ll1_l1_:
		l1ll_l1_ = base64.b64decode(l111ll1ll1_l1_[0])
		if PY3: l1ll_l1_ = l1ll_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⍷"))
		l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭⍸"),l1ll_l1_)
		l1ll_l1_ = list(l1ll_l1_.values())
		for l1ll1ll_l1_ in l1ll_l1_:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ⍹"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⍺")+server+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⍻"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࡇࡳࡼࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭⍼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡴࡁ࠲࠯ࡅ࠼ࡵࡦࡁ࡟ࠥࡧ࠭ࡻࡃ࠰࡞ࡢ࠰ࠨ࡝ࡦࡾ࠷࠱࠺ࡽࠪ࡝ࠣࡥ࠲ࢀࡁ࠮࡜ࡠ࠮ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⍽"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				if l1l111_l1_ (u"ࠧ࠰ࡁࡸࡶࡱࡃࠧ⍾") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࡂࡹࡷࡲ࠽ࠨ⍿"))[1]
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ⎀"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⎁")+server+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬ⎂")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⎃"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"࠭ࠠࠨ⎄"),l1l111_l1_ (u"ࠧࠬࠩ⎅"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⎆")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ⎇"))
	return
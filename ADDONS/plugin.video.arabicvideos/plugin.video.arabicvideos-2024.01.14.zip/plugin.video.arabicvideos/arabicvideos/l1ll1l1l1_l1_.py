# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭ಬ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪಭ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==130: l1lll_l1_ = l1l1l11_l1_()
	elif mode==131: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==132: l1lll_l1_ = CATEGORIES(url)
	elif mode==133: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==134: l1lll_l1_ = PLAY(url)
	elif mode==135: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==139: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಮ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ಯ"),l1l111_l1_ (u"ࠧࠨರ"),139,l1l111_l1_ (u"ࠨࠩಱ"),l1l111_l1_ (u"ࠩࠪಲ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧಳ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ಴"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧವ"),l1l111_l1_ (u"࠭ࠧಶ"),9999)
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨಷ"),l1l111_l1_ (u"ࠨࠩಸ"),True,l1l111_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧಹ"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡷࡳ࡬࡭࡬ࡦࠩ಺"),html,re.DOTALL)
	block = l11llll_l1_[1]
	items=re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ಻"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡣࡰࡰࡧࡹࡨࡺ࡯ࡳ಼ࠩ") in l1ll1ll_l1_: continue
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨಽ"))
		url = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫಾ") in url: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨಿ"),l1lllll_l1_+title,url,132)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩೀ"),l1lllll_l1_+title,url,131)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨು"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ೂ"),l1l111_l1_ (u"ࠬ࠭ೃ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ೄ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ೅")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫೆ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠴࠴ࠩೇ"),132,l1l111_l1_ (u"ࠪࠫೈ"),l1l111_l1_ (u"ࠫ࠶࠭೉"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬೊ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨೋ")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฦๅ้อๅࠨೌ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠻࠸࠸ࠨ್"),132,l1l111_l1_ (u"ࠩࠪ೎"),l1l111_l1_ (u"ࠪ࠵ࠬ೏"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ೐"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ೑")+l1lllll_l1_+l1l111_l1_ (u"࠭ศาษ่ะࠥอไึ฼สีࠥ๎วๅึหหอ࠭೒"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠶࠽ࠧ೓"),132,l1l111_l1_ (u"ࠨࠩ೔"),l1l111_l1_ (u"ࠩ࠴ࠫೕ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪೖ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭೗")+l1lllll_l1_+l1l111_l1_ (u"ࠬอศาิࠣห้ฮัศ็ฯࠫ೘"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠴࠻࠻࠹ࠧ೙"),132,l1l111_l1_ (u"ࠧࠨ೚"),l1l111_l1_ (u"ࠨ࠳ࠪ೛"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೜"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬೝ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅฮษูีฬะࠧೞ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠻࠷࠷ࠬ೟"),132,l1l111_l1_ (u"࠭ࠧೠ"),l1l111_l1_ (u"ࠧ࠲ࠩೡ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨೢ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫೣ")+l1lllll_l1_+l1l111_l1_ (u"ࠪ฽ฬฺ่าษฤࠫ೤"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠲࠵࠸࠷ࠬ೥"),132,l1l111_l1_ (u"ࠬ࠭೦"),l1l111_l1_ (u"࠭࠱ࠨ೧"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ೨"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ೩")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่อืวๆฮࠣห้อฬห็ส฽๏ฯࠧ೪"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠱࠳ࠪ೫"),132,l1l111_l1_ (u"ࠫࠬ೬"),l1l111_l1_ (u"ࠬ࠷ࠧ೭"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭೮"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ೯")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ฬึอๅอࠢส่ิ๐ๆ๋หࠪ೰"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠰࠺ࠩೱ"),132,l1l111_l1_ (u"ࠪࠫೲ"),l1l111_l1_ (u"ࠫ࠶࠭ೳ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ೴"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ೵")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆหีฬ๋ฬࠡษ็์ะอฦใ์ฬࠫ೶"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠻࠳ࠨ೷"),132,l1l111_l1_ (u"ࠩࠪ೸"),l1l111_l1_ (u"ࠪ࠵ࠬ೹"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ೺"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ೻")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅสิห๊าࠠศๆึ๎ฬู๊สࠩ೼"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠹࠻ࠧ೽"),132,l1l111_l1_ (u"ࠨࠩ೾"),l1l111_l1_ (u"ࠩ࠴ࠫ೿"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪഀ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ഁ")+l1lllll_l1_+l1l111_l1_ (u"้ࠬสษࠩം"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠵࠽࠶࠭ഃ"),132,l1l111_l1_ (u"ࠧࠨഄ"),l1l111_l1_ (u"ࠨ࠳ࠪഅ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩആ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬഇ")+l1lllll_l1_+l1l111_l1_ (u"ࠫฯ฿ไๆࠢส่ๆอัิ์ฬࠫഈ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠺࠻ࠫഉ"),132,l1l111_l1_ (u"࠭ࠧഊ"),l1l111_l1_ (u"ࠧ࠲ࠩഋ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨഌ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ഍")+l1lllll_l1_+l1l111_l1_ (u"ࠪวึฺ๊โࠢส่อืวๆฮࠪഎ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠲࠴࠺࠽ࠬഏ"),132,l1l111_l1_ (u"ࠬ࠭ഐ"),l1l111_l1_ (u"࠭࠱ࠨ഑"))
	return
def l1lll11_l1_(url):
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠧ࠰ࡴࡨࡰ࡮࡭ࡩࡰࡷࡶࠫഒ"),l1l111_l1_ (u"ࠨ࠱ࡶࡳࡨ࡯ࡡ࡭ࠩഓ"),l1l111_l1_ (u"ࠩ࠲ࡴࡴࡲࡩࡵ࡫ࡦࡥࡱ࠭ഔ"),l1l111_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵࠪക"),l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷࠬഖ")]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭ഗ"),l1l111_l1_ (u"࠭ࠧഘ"),True,l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧങ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࡢࡢࡴࠫ࠲࠯ࡅࠩࡵ࡫ࡷࡰࡪࡨࡡࡳࠩച"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if any(value in url for value in l1lll11l1_l1_):
		items = re.findall(l1l111_l1_ (u"ࠤࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦഛ"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬജ"))
			l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഝ"),l1lllll_l1_+title,l1ll1ll_l1_,133,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠷ࠧഞ"))
	elif l1l111_l1_ (u"࠭࠯ࡥࡱࡦࡷࠬട") in url:
		items = re.findall(l1l111_l1_ (u"ࠢࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࠤഠ"),block,re.DOTALL)
		for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪഡ"))
			l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩഢ"),l1lllll_l1_+title,l1ll1ll_l1_,133,l1ll1l_l1_,l1l111_l1_ (u"ࠪ࠵ࠬണ"))
	return
def CATEGORIES(url):
	category = url.split(l1l111_l1_ (u"ࠫ࠴࠭ത"))[-1]
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭ഥ"),l1l111_l1_ (u"࠭ࠧദ"),True,l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫധ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡶࡪࡴࡴࡤࡣࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨന"),html,re.DOTALL)
	if not l11llll_l1_:
		l1ll1l11_l1_(url,l1l111_l1_ (u"ࠩ࠴ࠫഩ"))
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧപ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ഫ"))
		l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬബ"),l1lllll_l1_+title,l1ll1ll_l1_,132,l1l111_l1_ (u"࠭ࠧഭ"),l1l111_l1_ (u"ࠧ࠲ࠩമ"))
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩയ"),l1l111_l1_ (u"ࠩࠪര"),True,l1l111_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬറ"))
	items = re.findall(l1l111_l1_ (u"ࠫࡹࡵࡴࡢ࡮ࡳࡥ࡬࡫ࡣࡰࡷࡱࡸࡂࡡ࡜ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠫࠧࡣࠧല"),html,re.DOTALL)
	if not items:
		url = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡴࡥࡸࡵ࠰ࡨࡪࡺࡡࡪ࡮࠰ࡦࡴࡪࡹࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪള"),html,re.DOTALL)
		url = url[0]
		title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬഴ") + l1l111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬവ")
		if url: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧശ"),l1lllll_l1_+title,url,134)
		else: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪഷ"),l1l111_l1_ (u"ࠪࠫസ"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧഹ"),l1l111_l1_ (u"๊ࠬวࠡ์๋ะิࠦอศๆํห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣๅ๏ࠦ็ัษࠣห้็ัฺࠩഺ"))
		return
	l1lll1111_l1_ = int(items[0])
	name = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࡂ࠯ࡢࡀࠣࡂ࠭࠴ࠪࡀࠫ࠿഻ࠫ"),html,re.DOTALL)
	if name: name = name[0].strip(l1l111_l1_ (u"഼ࠧࠡࠩ"))
	else: name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩഽ"))
	if l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ാ") in url or l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭ി") in url:
		category = url.split(l1l111_l1_ (u"ࠫ࠴࠭ീ"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠬ࠭ു"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪൂ") + category + l1l111_l1_ (u"ࠧ࠰ࠩൃ") + l1llllll1_l1_
		l11l1ll1_l1_ = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩൄ"),l1l111_l1_ (u"ࠩࠪ൅"),True,l1l111_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬെ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡵࡧࡧࡦࡰࡸࡱࡧ࡫ࡲࠩ࠰࠭ࡃ࠮ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩേ"),l11l1ll1_l1_,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡬ࡵ࡭࡮ࠫ࠲࠯ࡅࠩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ൈ"),block,re.DOTALL)
		for l1ll1l_l1_,type,l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ൉") not in type: continue
			if l1l111_l1_ (u"ࠧๆี็ื้࠭ൊ") in title and l1l111_l1_ (u"ࠨฯ็ๆฮ࠭ോ") not in title: continue
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡶࡡࡴࠧൌ"),l1l111_l1_ (u"്ࠪࠫ"))
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ൎ"))
			if l1l111_l1_ (u"๋ࠬำๅี็ࠫ൏") in name and l1l111_l1_ (u"࠭อๅไฬࠫ൐") in title and l1l111_l1_ (u"ࠧๆี็ื้࠭൑") not in title:
				title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ൒") + name + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭൓") + title
			l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
			if category==l1l111_l1_ (u"ࠪ࠺࠷࠾ࠧൔ"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫൕ"),l1lllll_l1_+title,l1ll1ll_l1_,133,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠷ࠧൖ"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬൗ"),l1lllll_l1_+title,l1ll1ll_l1_,134,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ൘") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠫ࠲࠯ࡅࠩࡤࡱ࡯࠱ࡲࡪ࠭࠲࠴ࠪ൙"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠤࡹ࡭ࡩ࡫࡯࠮ࡶࡵࡥࡨࡱ࠭ࡵࡧࡻࡸ࠳࠰࠿࡭ࡱࡤࡨ࡛࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ൚"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ൛"))
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ൜"),l1lllll_l1_+title,l1ll1ll_l1_,134,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠸࠵࠼ࠬ൝") in html:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ൞") + l1l111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬൟ")
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧൠ"),l1lllll_l1_+title,url,134)
		else:
			items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡃࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭ൡ"),html,re.DOTALL)
			category = items[0].split(l1l111_l1_ (u"ࠪ࠳ࠬൢ"))[-1]
			url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨൣ") + category
			CATEGORIES(url)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭൤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ൥"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll1l1ll_l1_:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭൦"),l1l111_l1_ (u"ࠨࠨࠪ൧"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ൨"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ൩")+title,l1ll1ll_l1_,133)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠫ࠴ࡴࡥࡸࡵ࠲ࠫ൪") in url or l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ൫") in url:
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ൬"),l1l111_l1_ (u"ࠧࠨ൭"),True,l1l111_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭൮"))
		items = re.findall(l1l111_l1_ (u"ࠤࡰࡳࡧ࡯࡬ࡦࡸ࡬ࡨࡪࡵࡰࡢࡶ࡫࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ൯"),html,re.DOTALL)
		if items: url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ൰"))
	return
def l1ll1llll_l1_():
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡲࡩࡷࡧࠪ൱")
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭൲"),l1l111_l1_ (u"࠭ࠧ൳"),True,l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬ൴"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ൵"),html,re.DOTALL)
	l1lllll1_l1_ = l1lllll1_l1_[0]
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ൶"):l111l1_l1_}
	l1lll1l11_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ൷"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ൸"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭൹"),True,l1l111_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡏࡍ࡛ࡋ࠭࠳ࡰࡧࠫൺ"))
	l11l1ll1_l1_ = l1lll1l11_l1_.content
	token = re.findall(l1l111_l1_ (u"ࠧࡤࡵࡵࡪ࠲ࡺ࡯࡬ࡧࡱࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧൻ"),l11l1ll1_l1_,re.DOTALL)
	token = token[0]
	l1lll111l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬർ"))
	l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡳࡰࡦࡿࡕࡳ࡮ࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨൽ"),l11l1ll1_l1_,re.DOTALL)
	l1llllll_l1_ = l1lll111l_l1_+l1llllll_l1_[0]
	l1ll1ll11_l1_ = {l1l111_l1_ (u"ࠪ࡜࠲ࡉࡓࡓࡈ࠰ࡘࡔࡑࡅࡏࠩൾ"):token}
	l1lll11ll_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩൿ"),l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭඀"),l1ll1ll11_l1_,False,True,l1l111_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡏࡍ࡛ࡋ࠭࠴ࡴࡧࠫඁ"))
	l1ll1lll1_l1_ = l1lll11ll_l1_.content
	l1111111_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨං"),l1ll1lll1_l1_,re.DOTALL)
	l1111111_l1_ = l1111111_l1_[0].replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫඃ"),l1l111_l1_ (u"ࠩ࠲ࠫ඄"))
	l1llll111_l1_(l1111111_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨඅ"))
	return
def l1lll1_l1_(search,url=l1l111_l1_ (u"ࠫࠬආ")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if url==l1l111_l1_ (u"ࠬ࠭ඇ"):
		if search==l1l111_l1_ (u"࠭ࠧඈ"): search = l1llll1_l1_()
		if search==l1l111_l1_ (u"ࠧࠨඉ"): return
		search = QUOTE(search)
		url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬඊ")+search
		l1ll1l11_l1_(url,l1l111_l1_ (u"ࠩࠪඋ"))
		return
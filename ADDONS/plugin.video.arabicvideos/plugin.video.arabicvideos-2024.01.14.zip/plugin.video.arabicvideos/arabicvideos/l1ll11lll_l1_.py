﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬඌ")
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨඍ"):l1l111_l1_ (u"ࠬ࠭ඎ")}
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬඏ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆอ์ฬ฻ไࠡษ็หัะๅศ฻ํࠫඐ"),l1l111_l1_ (u"ࠨื๋ีࠥอไห๊สู้ࠦวๅษฯฮ๊อู๋ࠩඑ"),l1l111_l1_ (u"ࠩฦีู๐แࠡฮ่๎฾ࠦวๅสิห๊าࠧඒ")]
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==40: l1lll_l1_ = l1l1l11_l1_()
	elif mode==41: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==42: l1lll_l1_ = l1ll11l11_l1_(text,l1llllll1_l1_)
	elif mode==43: l1lll_l1_ = PLAY(url)
	elif mode==44: l1lll_l1_ = l1lll11_l1_(text,l1llllll1_l1_)
	elif mode==49: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨඓ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ศฬࠢส่า๐ࠠๅไ้หฮࠦวๅ็฼หึ็ࠧඔ"),l1l111_l1_ (u"ࠬ࠭ඕ"),41)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ඖ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ඗"),l1l111_l1_ (u"ࠨࠩ඘"),49)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ඙"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬක"),l1l111_l1_ (u"ࠫࠬඛ"),9999)
	l1ll11l11_l1_(l1l111_l1_ (u"ࠬ࠭ග"),l1l111_l1_ (u"࠭࠱ࠨඝ"))
	return
def l1ll111l1_l1_(options,l1ll11l1l_l1_):
	search,sort,l1111l1l_l1_,category,l1ll1l11l_l1_ = l1l111_l1_ (u"ࠧࠨඞ"),[],[],[],[]
	dummy,l1ll111ll_l1_ = l1ll11ll1_l1_(options)
	for option in list(l1ll111ll_l1_.keys()):
		value = l1ll111ll_l1_[option]
		if not value: continue
		if   option==l1l111_l1_ (u"ࠨࡵࡲࡶࡹ࠭ඟ"): sort = [value]
		elif option==l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩච"): l1111l1l_l1_ = [value]
		elif option==l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪඡ"): search = value
		elif option==l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ජ"): category = [value]
		elif option==l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱ࡯ࡳࡵࠩඣ"): l1ll1l11l_l1_ = [value]
	payload = {l1l111_l1_ (u"ࠨࡡࡤࡶ࡬ࡳࡳࠨඤ"):l1l111_l1_ (u"ࠢࡧࡣࡦࡩࡹࡽࡰࡠࡴࡨࡪࡷ࡫ࡳࡩࠤඥ"),l1l111_l1_ (u"ࠣࡦࡤࡸࡦࠨඦ"):{l1l111_l1_ (u"ࠤࡩࡥࡨ࡫ࡴࡴࠤට"):{l1l111_l1_ (u"ࠥࡷࡪࡧࡲࡤࡪࠥඨ"):search,l1l111_l1_ (u"ࠦࡻ࡯ࡤࡦࡱࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠢඩ"):category,l1l111_l1_ (u"ࠧࡹࡰࡦࡥ࡬ࡥࡱ࡯ࡳࡵࠤඪ"):l1ll1l11l_l1_,l1l111_l1_ (u"ࠨࡳࡦࡴ࡬ࡩࡸࠨණ"):l1111l1l_l1_,l1l111_l1_ (u"ࠢ࡯ࡷࡰࡦࡪࡸࠢඬ"):[],l1l111_l1_ (u"ࠣࡵࡲࡶࡹࡥࡶࡪࡦࡨࡳࠧත"):sort,l1l111_l1_ (u"ࠤࡦࡳࡺࡴࡴࠣථ"):[],l1l111_l1_ (u"ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢද"):[]},l1l111_l1_ (u"ࠦ࡫ࡸ࡯ࡻࡧࡱࡣ࡫ࡧࡣࡦࡶࡶࠦධ"):{},l1l111_l1_ (u"ࠧࡺࡥ࡮ࡲ࡯ࡥࡹ࡫ࠢන"):l1l111_l1_ (u"ࠨࡶࡪࡦࡨࡳࡤࡪࡥࡴ࡭ࡷࡳࡵࡥࡰࡰࡵࡷࡷࠧ඲"),l1l111_l1_ (u"ࠢࡦࡺࡷࡶࡦࡹࠢඳ"):{l1l111_l1_ (u"ࠣࡵࡲࡶࡹࠨප"):l1l111_l1_ (u"ࠤࡧࡩ࡫ࡧࡵ࡭ࡶࠥඵ")},l1l111_l1_ (u"ࠥࡷࡴ࡬ࡴࡠࡴࡨࡪࡷ࡫ࡳࡩࠤබ"):0,l1l111_l1_ (u"ࠦ࡮ࡹ࡟ࡣࡨࡦࡥࡨ࡮ࡥࠣභ"):1,l1l111_l1_ (u"ࠧ࡬ࡩࡳࡵࡷࡣࡱࡵࡡࡥࠤම"):0,l1l111_l1_ (u"ࠨࡰࡢࡩࡨࡨࠧඹ"):int(l1ll11l1l_l1_)}}
	import json
	payload = json.dumps(payload)
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠵ࡷࡱ࠯࡭ࡷࡴࡴ࠯ࡧࡣࡦࡩࡹࡽࡰ࠰ࡸ࠴࠳ࡷ࡫ࡦࡳࡧࡶ࡬ࠬය")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ර"),l1ll1ll_l1_,payload,l1l111_l1_ (u"ࠩࠪ඼"),l1l111_l1_ (u"ࠪࠫල"),l1l111_l1_ (u"ࠫࠬ඾"),l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡆࡄࡘࡆࡥࡐࡂࡉࡈ࠱࠶ࡹࡴࠨ඿"))
	html = response.content
	data = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫව"),html)
	return data
def l1ll11l11_l1_(options,level):
	l1lll1l1_l1_ = l1ll111l1_l1_(options,l1l111_l1_ (u"ࠧ࠲ࠩශ"))
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠨࡨࡤࡧࡪࡺࡳࠨෂ")]
	if level==l1l111_l1_ (u"ࠩ࠴ࠫස"):
		block = block[l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡡࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠭හ")]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡪࡩࡷࠪ࠱࠮ࡄ࠯࠯ࡥ࡫ࡹࡂࠬළ"),block,re.DOTALL)
		for item in items:
			tmp = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺࡦࡲࡵࡦ࠿࡟ࡠࠧ࠮࠮ࠫࡁࠬࡠࡡࠨ࠮ࠫࡁࡧ࡭ࡸࡶ࡬ࡢࡻ࠰ࡺࡦࡲࡵࡦ࡞࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬෆ"),item+l1l111_l1_ (u"࠭࠼ࠨ෇"),re.DOTALL)
			if not tmp: tmp = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡼࡡ࡭ࡷࡨࡁࡡࡢࠢࠩ࠰࠭ࡃ࠮ࡢ࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ෈"),item+l1l111_l1_ (u"ࠨ࠾ࠪ෉"),re.DOTALL)
			category,title = tmp[0]
			if not options: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ්ࠩ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ෋")+l1lllll_l1_+title,l1l111_l1_ (u"ࠫࠬ෌"),42,l1l111_l1_ (u"ࠬ࠭෍"),l1l111_l1_ (u"࠭࠲ࠨ෎"),l1l111_l1_ (u"ࠧࡀࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫා")+category)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨැ"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪෑ"),42,l1l111_l1_ (u"ࠪࠫි"),l1l111_l1_ (u"ࠫ࠷࠭ී"),options+l1l111_l1_ (u"ࠬࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩු")+category)
	if level==l1l111_l1_ (u"࠭࠲ࠨ෕"):
		block = block[l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬ࡪࡵࡷࠫූ")]
		items = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ෗"),block,re.DOTALL)
		for l1ll1l11l_l1_,title in items:
			if not l1ll1l11l_l1_: title = title = l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩෘ")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪෙ"),l1lllll_l1_+title,l1l111_l1_ (u"ࠫࠬේ"),42,l1l111_l1_ (u"ࠬ࠭ෛ"),l1l111_l1_ (u"࠭࠳ࠨො"),options+l1l111_l1_ (u"ࠧࠧࡵࡳࡩࡨ࡯ࡡ࡭࡫ࡶࡸࡂ࠭ෝ")+l1ll1l11l_l1_)
	elif level==l1l111_l1_ (u"ࠨ࠵ࠪෞ"):
		block = block[l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩෟ")]
		items = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭෠"),block,re.DOTALL)
		for l1111l1l_l1_,title in items:
			if not l1111l1l_l1_: title = title = l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ෡")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ෢"),l1lllll_l1_+title,l1l111_l1_ (u"࠭ࠧ෣"),42,l1l111_l1_ (u"ࠧࠨ෤"),l1l111_l1_ (u"ࠨ࠶ࠪ෥"),options+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡩࡦࡵࡀࠫ෦")+l1111l1l_l1_)
	elif level==l1l111_l1_ (u"ࠪ࠸ࠬ෧"):
		block = block[l1l111_l1_ (u"ࠫࡸࡵࡲࡵࡡࡹ࡭ࡩ࡫࡯ࠨ෨")]
		items = re.findall(l1l111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ෩"),block,re.DOTALL)
		for sort,title in items:
			if not sort: continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෪"),l1lllll_l1_+title,l1l111_l1_ (u"ࠧࠨ෫"),44,l1l111_l1_ (u"ࠨࠩ෬"),l1l111_l1_ (u"ࠩ࠴ࠫ෭"),options+l1l111_l1_ (u"ࠪࠪࡸࡵࡲࡵ࠿ࠪ෮")+sort)
	return
def l1lll11_l1_(options,l1ll11l1l_l1_):
	l1lll1l1_l1_ = l1ll111l1_l1_(options,l1ll11l1l_l1_)
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠫࡹ࡫࡭ࡱ࡮ࡤࡸࡪ࠭෯")]
	items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ෰"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ෱"),l1lllll_l1_+title,l1ll1ll_l1_,43,l1ll1l_l1_)
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠧࡧࡣࡦࡩࡹࡹࠧෲ")][l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬෳ")]
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡱࡣࡪࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭෴"),block,re.DOTALL)
	for l1llllll1_l1_,title in items:
		if l1ll11l1l_l1_==l1llllll1_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෵"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ෶")+title,l1l111_l1_ (u"ࠬ࠭෷"),44,l1l111_l1_ (u"࠭ࠧ෸"),l1llllll1_l1_,options)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ෹"),url,l1l111_l1_ (u"ࠨࠩ෺"),l1l111_l1_ (u"ࠩࠪ෻"),l1l111_l1_ (u"ࠪࠫ෼"),l1l111_l1_ (u"ࠫࠬ෽"),l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ෾"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ෿"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࡠࡷࡵࡰ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠩࠫ฀"),html,re.DOTALL)
	l1ll11l1_l1_ = []
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫก"),l1l111_l1_ (u"ࠩ࠲ࠫข"))
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩฃ"),url)
	return
def l1ll1llll_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨค"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ศฬ࠯่ฬฬฺัࠨฅ"),l1l111_l1_ (u"࠭ࠧฆ"),l1l111_l1_ (u"ࠧࠨง"),l1l111_l1_ (u"ࠨࠩจ"),l1l111_l1_ (u"ࠩࠪฉ"),l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊ࠲ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧช"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩซ"),html,re.DOTALL)
	url = l111l11_l1_(items[0])
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪฌ"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	l1ll1l111_l1_ = False
	if search==l1l111_l1_ (u"࠭ࠧญ"):
		search = l1llll1_l1_()
		l1ll1l111_l1_ = True
	if search==l1l111_l1_ (u"ࠧࠨฎ"): return
	if not l1ll1l111_l1_: l1lll11_l1_(l1l111_l1_ (u"ࠨࡁࡶࡩࡦࡸࡣࡩ࠿ࠪฏ")+search,l1l111_l1_ (u"ࠩ࠴ࠫฐ"))
	else: l1ll11l11_l1_(l1l111_l1_ (u"ࠪࡃࡸ࡫ࡡࡳࡥ࡫ࡁࠬฑ")+search,l1l111_l1_ (u"ࠫ࠶࠭ฒ"))
	return
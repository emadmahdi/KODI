# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ⃛")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠴࠲ࡧ࡫ࡳࡵࠩ⃜")
#l1l11l_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠲࠰ࡦࡳࡲ࠭⃝")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭⃞")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠺ࡢࡦࡵࡷ࠲ࡨࡵ࡭ࠨ⃟")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠱ࡻ࡯ࡰ࠯ࡵ࡫ࡳ࡫ࡪࡡ࠯ࡥࡲࡱࠬ⃠")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡵ࡭ࡦ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡲࡱ࠭⃡")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭⃢")
script_name = l1l1l1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ⃣")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡆࡉ࡙ࡣࠬ⃤")
l1l11l_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l11l11_l1_(url,page)
	elif mode==222: results = l1ll11_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1111l1_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ⃥ࠧ"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⃦"),l1l1l1_l1_ (u"ࠩࠪ⃧"),229,l1l1l1_l1_ (u"⃨ࠪࠫ"),l1l1l1_l1_ (u"ࠫࠬ⃩"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠ⃪ࠩ"))
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ⃫࠭"),menu_name+l1l1l1_l1_ (u"ࠧโๆอี๋ࠥอะั⃬ࠪ"),l1l11l_l1_,226,l1l1l1_l1_ (u"ࠨ⃭ࠩ"),l1l1l1_l1_ (u"⃮ࠩࠪ"),l1l1l1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡ⃯ࠪ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃰"),menu_name+l1l1l1_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ⃱"),l1l11l_l1_,226,l1l1l1_l1_ (u"࠭ࠧ⃲"),l1l1l1_l1_ (u"ࠧࠨ⃳"),l1l1l1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ⃴"))
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⃵"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⃶"),l1l1l1_l1_ (u"ࠫࠬ⃷"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ⃸"),l1l11l_l1_,l1l1l1_l1_ (u"࠭ࠧ⃹"),l1l1l1_l1_ (u"ࠧࠨ⃺"),l1l1l1_l1_ (u"ࠨࠩ⃻"),l1l1l1_l1_ (u"ࠩࠪ⃼"),l1l1l1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⃽"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࠦࡩ࠮ࡪࡲࡱࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⃾"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⃿"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"࠭࠼࠰࡫ࡁࠫ℀") in title: title = title.split(l1l1l1_l1_ (u"ࠧ࠽࠱࡬ࡂࠬ℁"))[1]
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨℂ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ℃")+menu_name+title,l111ll_l1_,222)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ℄"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ℅"),l1l1l1_l1_ (u"ࠬ࠭℆"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡢࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺࠧℇ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠧࡱࡦࡤࠤࡧࡪࡢࠣࡀ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ℈"),html,re.DOTALL)
	for title,l111ll_l1_ in items:
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ℉"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫℊ")+menu_name+title,l111ll_l1_,221)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨℋ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫℌ"),l1l1l1_l1_ (u"ࠬ࠭ℍ"),9999)
	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨℎ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠧࡩࡶࡰࡰࠬℏ") not in l111ll_l1_: continue
		if not l111ll_l1_.endswith(l1l1l1_l1_ (u"ࠨ࠱ࠪℐ")): addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩℑ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬℒ")+menu_name+title,l111ll_l1_,221)
	return html
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭วื฼ฺࠤ์์วࠡๆสฺฬ็ษࠡษึ้ࠥีฮ้ๆࠣ์่๊ๅสࠢสุ่ืࠧ࠭ࠩࠪ࠰࠷࠸࠵ࠪࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨฬะิ๏ืࠧ࠭ࠩࠪ࠰࠷࠸࠶ࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮ࠣ࡬ࡹࡳ࡬ࠪࠌࠌࠧ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲࡑࡵࡡࡥࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠣࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠧ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࡟ࡲࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧ࡫ࡵࡲࠡࡷࡵࡰ࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠥࠌ࡭࡫ࠦࡵࡳ࡮ࠤࡁࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧ࠺ࠡࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡹࡷࡲࠬ࠳࠴࠷࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ࠰ࠬ࠭ࠬ࠳࠴࠼࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้ษใฬำู้ࠣอ็ะหࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ࠱࠸࠲࠲ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้อแๅษ่ࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ࠰࠷࠸࠴ࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩสู่๊ไิๆสฮࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭ࠪ࠳ࡹࡼࠧ࠭࠴࠵࠸࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭࡬ࡪࡰ࡮ࠫ࠱࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬࠨࠩ࠯࠽࠾࠿࠹ࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࠡ࡯ࡪࡦ࠭࠴ࠪࡀࠫࡁࡉ࡬ࡿࡂࡦࡵࡷࡀ࠴ࡧ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊ࡫ࡷࡩࡲࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠲࠳࠳ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠥ࡮ࡴ࡮࡮ࠍࠍࠨࠦࡥࡨࡻࡥࡩࡸࡺ࠱࠯ࡥࡲࡱࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡨࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠦ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡡ࠱࠰࡟࡞࡭ࠧࡣ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡩࡧࠢࠪࡸࡴࡸࡲࡦࡰࡷࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡴࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊ࡫ࡷࡩࡲࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡫ࡩࠤࠬࡺ࡯ࡳࡴࡨࡲࡹ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠲࠳࠳ࠬࠎࠎࠨࠢࠣℓ")
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ℔"),url,l1l1l1_l1_ (u"࠭ࠧℕ"),l1l1l1_l1_ (u"ࠧࠨ№"),l1l1l1_l1_ (u"ࠨࠩ℗"),l1l1l1_l1_ (u"ࠩࠪ℘"),l1l1l1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬℙ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡹ࡟ࡴࡥࡵࡳࡱࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬℚ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ℛ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℜ"),menu_name+title,l111ll_l1_,224)
	return
def l1111l1_l1_(url):
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧℝ"),menu_name+l1l1l1_l1_ (u"ࠨษ็ะ๊๐ูࠨ℞"),url,221)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠩࠪ℟"),l1l1l1_l1_ (u"ࠪࠫ℠"),l1l1l1_l1_ (u"ࠫࠬ℡"),l1l1l1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ™"))
	l1l1l1_l1_ (u"ࠨࠢࠣࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌࠦࠧࠨ℣")
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡷࡥࡣࡳࡧࡶࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡰࡳࡻ࡯ࡥࡴࠩℤ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ℥"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if l111ll_l1_==l1l1l1_l1_ (u"ࠩࠦࠫΩ"): name = title
			else:
				title = title + l1l1l1_l1_ (u"ࠪࠤࠥࡀࠠࠡࠩ℧") + l1l1l1_l1_ (u"ࠫๆ๊สาࠢࠪℨ") + name
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ℩"),menu_name+title,l111ll_l1_,221)
	else: l11l11_l1_(url)
	return
def l11l11_l1_(url,page=l1l1l1_l1_ (u"࠭࠱ࠨK")):
	if page==l1l1l1_l1_ (u"ࠧࠨÅ"): page = l1l1l1_l1_ (u"ࠨ࠳ࠪℬ")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪℭ"),l1l1l1_l1_ (u"ࠪࠫ℮"),str(url), str(page))
	if l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬℯ") in url or l1l1l1_l1_ (u"ࠬࡅࠧℰ") in url: url2 = url + l1l1l1_l1_ (u"࠭ࠦࠨℱ")
	else: url2 = url + l1l1l1_l1_ (u"ࠧࡀࠩℲ")
	#url2 = url2 + l1l1l1_l1_ (u"ࠨࡱࡸࡸࡵࡻࡴࡠࡨࡲࡶࡲࡧࡴ࠾࡬ࡶࡳࡳࠬ࡯ࡶࡶࡳࡹࡹࡥ࡭ࡰࡦࡨࡁࡲࡵࡶࡪࡧࡶࡣࡱ࡯ࡳࡵࠨࡳࡥ࡬࡫࠽ࠨℳ")+page
	url2 = url2 + l1l1l1_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨℴ") + page
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠪࠫℵ"),l1l1l1_l1_ (u"ࠫࠬℶ"),l1l1l1_l1_ (u"ࠬ࠭ℷ"),l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧℸ"))
	#name = l1l1l1_l1_ (u"ࠧࠨℹ")
	#if l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩ℺") in url:
	#	name = re.findall(l1l1l1_l1_ (u"ࠩ࠿࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭℻"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l1l1l1_l1_ (u"ࠪࠤࠬℼ")) + l1l1l1_l1_ (u"ࠫࠥ࠳ࠠࠨℽ")
	#	else: name = xbmc.getInfoLabel( l1l1l1_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱࠨℾ") ) + l1l1l1_l1_ (u"࠭ࠠ࠮ࠢࠪℿ")
	if l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨ⅀") in url:
		l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡧࡥࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ⅁"),html,re.DOTALL)
		block = l1ll1l1_l1_[-1]
	# l111l1l1l1_l1_ l111l1_l1_
	elif l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ⅂") in url:
		l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡳࡼࡲ࠭ࡤࡣࡵࡳࡺࡹࡥ࡭ࠢࡲࡻࡱ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ⅃"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
	else:
		l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⅄"),html,re.DOTALL)
		block = l1ll1l1_l1_[-1]
	items = re.findall(l1l1l1_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩⅅ"),block,re.DOTALL)
	for l111ll_l1_,img,title in items:
		l1l1l1_l1_ (u"ࠨࠢࠣࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶࡩࡷ࡯ࡥࡴࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡥࡳࡪࠠࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࡩࡧࠢࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫࠥ࡯࡮ࠡࡷࡵࡰࠥࡧ࡮ࡥࠢࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࠥࡹࡴࡳࠪ࡯࡭ࡳࡱࠩࠪࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡴࡡ࡮ࡧࠣ࠯ࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠧࠨࠢⅆ")
		title = unescapeHTML(title)
		l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪ࡯ࡪࠤࡂࠦࡩ࡮ࡩ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡪࠥ࠭ࡨࡵࡶࡳࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥ࡯࡭ࡨ࠼ࠣ࡭ࡲ࡭ࠠ࠾ࠢࠪ࡬ࡹࡺࡰ࠻ࠩࠣ࠯ࠥ࡯࡭ࡨࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡔࡏࡕࡋࡉࡍࡈࡇࡔࡊࡑࡑࠬ࡮ࡳࡧ࠭ࠩࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠨࠢࠣⅇ")
		if l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰ࠩⅈ") in l111ll_l1_ or l1l1l1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࠫⅉ") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⅊"),menu_name+title,l111ll_l1_.rstrip(l1l1l1_l1_ (u"ࠫ࠴࠭⅋")),223,img)
		else:
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅌"),menu_name+title,l111ll_l1_,221,img)
	if len(items)>=16:
		l11ll1lll1_l1_ = [l1l1l1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ⅍"),l1l1l1_l1_ (u"ࠧ࠰ࡶࡹࠫⅎ"),l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ⅏"),l1l1l1_l1_ (u"ࠩ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ⅐")]
		page = int(page)
		if any(value in url for value in l11ll1lll1_l1_):
			for n in range(0,1000,100):
				if int(page/100)*100==n:
					for i in range(n,n+100,10):
						if int(page/10)*10==i:
							for j in range(i,i+10,1):
								if not page==j and j!=0:
									addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⅑"),menu_name+l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪ⅒")+str(j),url,221,l1l1l1_l1_ (u"ࠬ࠭⅓"),str(j))
						elif i!=0: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⅔"),menu_name+l1l1l1_l1_ (u"ࠧึใะอࠥ࠭⅕")+str(i),url,221,l1l1l1_l1_ (u"ࠨࠩ⅖"),str(i))
						else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⅗"),menu_name+l1l1l1_l1_ (u"ูࠪๆำษࠡࠩ⅘")+str(1),url,221,l1l1l1_l1_ (u"ࠫࠬ⅙"),str(1))
				elif n!=0: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅚"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬ⅛")+str(n),url,221,l1l1l1_l1_ (u"ࠧࠨ⅜"),str(n))
				else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⅝"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨ⅞")+str(1),url,221)
	return
def PLAY(url):
	#global l1l1l1_l1_ (u"ࠪࠫ⅟")
	l1111ll_l1_,l11l1_l1_ = [],[]
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬⅠ"),l1l1l1_l1_ (u"ࠬ࠭Ⅱ"),url, url[-45:])
	# l1ll1lll_l1_://l111ll1l1l_l1_.l1lll1l11_l1_/l111lll1l1_l1_/فيلم-the-l111lllll1_l1_-l111l1l1ll_l1_-2019-مترجم
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"࠭ࠧⅢ"),l1l1l1_l1_ (u"ࠧࠨⅣ"),l1l1l1_l1_ (u"ࠨࠩⅤ"),l1l1l1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨⅥ"))
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡹࡪ࠾ศๆอู๋๐แ࠽࠱ࡷࡨࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⅦ"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	# l1ll1lll_l1_://l11llllll1_l1_.l111l1l11l_l1_/l111lll1l1_l1_/فيلم-the-l111lllll1_l1_-l111l1l1ll_l1_-2019-مترجم
	l11lll11l_l1_,l1l11l1ll_l1_ = l1l1l1_l1_ (u"ࠫࠬⅧ"),l1l1l1_l1_ (u"ࠬ࠭Ⅸ")
	l111llllll_l1_,l111ll11l1_l1_ = html,html
	l111ll1lll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡳࡩࡱࡺࡣࡩࡲࠠࡢࡲ࡬ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⅩ"),html,re.DOTALL)
	if l111ll1lll_l1_:
		for l111ll_l1_ in l111ll1lll_l1_:
			if l1l1l1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨⅪ") in l111ll_l1_: l11lll11l_l1_ = l111ll_l1_
			elif l1l1l1_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬⅫ") in l111ll_l1_: l1l11l1ll_l1_ = l111ll_l1_
		if l11lll11l_l1_!=l1l1l1_l1_ (u"ࠩࠪⅬ"): l111llllll_l1_ = OPENURL_CACHED(l11l11l_l1_,l11lll11l_l1_,l1l1l1_l1_ (u"ࠪࠫⅭ"),l1l1l1_l1_ (u"ࠫࠬⅮ"),l1l1l1_l1_ (u"ࠬ࠭Ⅿ"),l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬⅰ"))
		if l1l11l1ll_l1_!=l1l1l1_l1_ (u"ࠧࠨⅱ"): l111ll11l1_l1_ = OPENURL_CACHED(l11l11l_l1_,l1l11l1ll_l1_,l1l1l1_l1_ (u"ࠨࠩⅲ"),l1l1l1_l1_ (u"ࠩࠪⅳ"),l1l1l1_l1_ (u"ࠪࠫⅴ"),l1l1l1_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪⅵ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ⅶ"),l1l1l1_l1_ (u"࠭ࠧⅷ"),l1l11l1ll_l1_,l11lll11l_l1_)
	# l1ll1lll_l1_://l111ll111l_l1_.l11llllll1_l1_.download/?id=__111llll1l_l1_
	l111lll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⅸ"),l111llllll_l1_,re.DOTALL)
	if l111lll111_l1_:
		url2 = l111lll111_l1_[0]#+l1l1l1_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࡩࡶࡷࡴ࠿࠵࠯࠸࠻࠱࠵࠻࠻࠮࠳࠶࠵࠲࠽࠺࠺࠵࠳࠷࠹ࠬⅹ")
		if url2!=l1l1l1_l1_ (u"ࠩࠪⅺ") and l1l1l1_l1_ (u"ࠪࡹࡵࡲ࡯ࡢࡦࡨࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࡰࡹࡱࡰࡴࡧࡤࠨⅻ") in url2 and l1l1l1_l1_ (u"ࠫ࠴ࡅࡩࡥ࠿ࡢࠫⅼ") not in url2:
			l1l11l11_l1_ = OPENURL_CACHED(l11l11l_l1_,url2,l1l1l1_l1_ (u"ࠬ࠭ⅽ"),l1l1l1_l1_ (u"࠭ࠧⅾ"),l1l1l1_l1_ (u"ࠧࠨⅿ"),l1l1l1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧↀ"))
			l111l11lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧↁ"),l1l11l11_l1_,re.DOTALL)
			if l111l11lll_l1_:
				for l111ll_l1_,l11ll111_l1_ in l111l11lll_l1_:
					l11l1_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡩࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࡱࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲࡶ࠴ࡠࡡࠪↂ")+l11ll111_l1_)
			else:
				server = url2.split(l1l1l1_l1_ (u"ࠫ࠴࠭Ↄ"))[2]
				l11l1_l1_.append(url2+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ↄ")+server+l1l1l1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧↅ"))
		elif url2!=l1l1l1_l1_ (u"ࠧࠨↆ"):
			#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩↇ"),l1l1l1_l1_ (u"ࠩࠪↈ"),url2,str(l111lll111_l1_))
			server = url2.split(l1l1l1_l1_ (u"ࠪ࠳ࠬ↉"))[2]
			l11l1_l1_.append(url2+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ↊")+server+l1l1l1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭↋"))
	# l1ll1lll_l1_://l111l1lll1_l1_.cc/l111llll11_l1_
	# l1ll1lll_l1_://l111lll11l_l1_.l111l1ll1l_l1_/l111llll11_l1_
	l111ll1111_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡵࡣࡥࡰࡪࠦࡣ࡭ࡣࡶࡷࡂࠨࡤ࡭ࡵࡢࡸࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ↌"),l111ll11l1_l1_,re.DOTALL)
	if l111ll1111_l1_:
		l111ll1111_l1_ = l111ll1111_l1_[0]
		l111ll1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡶࡧࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ↍"),l111ll1111_l1_,re.DOTALL)
		if l111ll1ll1_l1_:
			for l11ll111_l1_,l111ll_l1_ in l111ll1ll1_l1_:
				if l1l1l1_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ↎") not in l111ll_l1_: continue
				if l111ll_l1_.count(l1l1l1_l1_ (u"ࠩ࠲ࠫ↏"))>=2:
					server = l111ll_l1_.split(l1l1l1_l1_ (u"ࠪ࠳ࠬ←"))[2]
					l11l1_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ↑")+server+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡢࡱࡵ࠺࡟ࡠࠩ→")+l11ll111_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ↓"), l11l1_l1_)
	#if selection == -1 : return
	newLIST = []
	for l111ll_l1_ in l11l1_l1_:
		# l111l1ll11_l1_	l1ll1lll_l1_://l1lllllll1_l1_.l11llllll1_l1_.l111l1l11l_l1_/l111lll1l1_l1_/l1l1111ll_l1_/فيلم-the-l111lll1ll_l1_-l111ll1l11_l1_-l111l1l111_l1_-2017-مترجم/l111ll11ll_l1_
		#if l1l1l1_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ↔") in l111ll_l1_: continue
		#if l1l1l1_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵࡅ࡮ࡢ࡯ࡨࠫ↕") in l111ll_l1_: continue
		#if l1l1l1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ↖") in l111ll_l1_: continue
		#if l1l1l1_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ↗") not in l111ll_l1_: continue
		newLIST.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ↘"), newLIST)
	import ll_l1_
	ll_l1_.l1l_l1_(newLIST,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ↙"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ↚"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ↛"): return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ↜"),l1l1l1_l1_ (u"ࠩ࠮ࠫ↝"))
	html = OPENURL_CACHED(l1llll111_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠪࠫ↞"),l1l1l1_l1_ (u"ࠫࠬ↟"),l1l1l1_l1_ (u"ࠬ࠭↠"),l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ↡"))
	token = re.findall(l1l1l1_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨ࡟ࡵࡱ࡮ࡩࡳࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ↢"),html,re.DOTALL)
	if token:
		url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡢࡸࡴࡱࡥ࡯࠿ࠪ↣")+token[0]+l1l1l1_l1_ (u"ࠩࠩࡵࡂ࠭↤")+l11ll11_l1_
		l11l11_l1_(url)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ↥"),l1l1l1_l1_ (u"ࠫࠬ↦"),l1l1l1_l1_ (u"ࠬ࠭↧"), l1l1l1_l1_ (u"࠭ࠧ↨"))
	return
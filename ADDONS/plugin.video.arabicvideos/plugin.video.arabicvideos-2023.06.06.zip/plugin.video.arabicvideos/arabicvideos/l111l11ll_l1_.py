# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ፳")
menu_name = l1l1l1_l1_ (u"ࠪࡣࡇࡘࡓࡠࠩ፴")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭፵"),l1l1l1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭፶"),l1l1l1_l1_ (u"࠭วๅษๅืฬ๋ࠧ፷"),l1l1l1_l1_ (u"ฺࠧำูࠤฬ๊ๅำ์าࠫ፸")]
def MAIN(mode,url,text):
	if   mode==650: results = MENU()
	elif mode==651: results = l11l11_l1_(url,text)
	elif mode==652: results = PLAY(url)
	elif mode==653: results = l11_l1_(url,text)
	elif mode==654: results = l1ll11_l1_(url)
	elif mode==659: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ፹"),l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪ፺"),l1l1l1_l1_ (u"ࠪࠫ፻"),l1l1l1_l1_ (u"ࠫࠬ፼"),l1l1l1_l1_ (u"ࠬ࠭፽"),l1l1l1_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ፾"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፿"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᎀ"),l1l1l1_l1_ (u"ࠩࠪᎁ"),659,l1l1l1_l1_ (u"ࠪࠫᎂ"),l1l1l1_l1_ (u"ࠫࠬᎃ"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᎄ"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᎅ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᎆ"),l1l1l1_l1_ (u"ࠨࠩᎇ"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎈ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᎉ")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬᎊ"),l1l11l_l1_,651,l1l1l1_l1_ (u"ࠬ࠭ᎋ"),l1l1l1_l1_ (u"࠭ࠧᎌ"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᎍ"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎎ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᎏ")+menu_name+l1l1l1_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ᎐"),l1l11l_l1_,651,l1l1l1_l1_ (u"ࠫࠬ᎑"),l1l1l1_l1_ (u"ࠬ࠭᎒"),l1l1l1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ᎓"))
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᎔"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᎕")+menu_name+l1l1l1_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ᎖"),l1l11l_l1_,651,l1l1l1_l1_ (u"ࠪࠫ᎗"),l1l1l1_l1_ (u"ࠫࠬ᎘"),l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ᎙"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᎚"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᎛")+menu_name+l1l1l1_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ᎜"),l1l11l_l1_,651,l1l1l1_l1_ (u"ࠩࠪ᎝"),l1l1l1_l1_ (u"ࠪࠫ᎞"),l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭᎟"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᎠ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ꭱ"),l1l1l1_l1_ (u"ࠧࠨᎢ"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭Ꭳ"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᎤ"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎥ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭Ꭶ")+menu_name+title,l111ll_l1_,654)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᎧ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ꭸ"),l1l1l1_l1_ (u"ࠧࠨᎩ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨᎪ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢᎫ"),html,re.DOTALL)
	#for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠪࠫᎬ"))
	#block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᎭ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		title = title.replace(l1l1l1_l1_ (u"ࠬࡂࡢ࠿ࠩᎮ"),l1l1l1_l1_ (u"࠭ࠧᎯ")).strip(l1l1l1_l1_ (u"ࠧࠡࠩᎰ"))
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎱ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᎲ")+menu_name+title,l111ll_l1_,654)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᎳ"),url,l1l1l1_l1_ (u"ࠫࠬᎴ"),l1l1l1_l1_ (u"ࠬ࠭Ꮅ"),l1l1l1_l1_ (u"࠭ࠧᎶ"),l1l1l1_l1_ (u"ࠧࠨᎷ"),l1l1l1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭Ꮈ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭Ꮉ"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫᎺ"),l1l1l1_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪᎻ"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᎼ"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"࠭ࠧᎽ"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᎾ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ꮏ"),l1l1l1_l1_ (u"ࠩࠪᏀ"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᏁ"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠫ࠿ࠦࠧᏂ")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏃ"),menu_name+title,l111ll_l1_,651)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᏄ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᏅ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ꮖ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᏇ"),l1l1l1_l1_ (u"ࠪࠫᏈ"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᏉ"),menu_name+title,l111ll_l1_,651)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠬ࠭Ꮚ")):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᏋ"),l1l1l1_l1_ (u"ࠧࠨᏌ"),request,url)
	if request==l1l1l1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭Ꮝ"):
		url,search = url.split(l1l1l1_l1_ (u"ࠩࡂࠫᏎ"),1)
		data = l1l1l1_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩᏏ")+search
		headers = {l1l1l1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᏐ"):l1l1l1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᏑ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫᏒ"),url,data,headers,l1l1l1_l1_ (u"ࠧࠨᏓ"),l1l1l1_l1_ (u"ࠨࠩᏔ"),l1l1l1_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭Ꮥ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᏖ"),url,l1l1l1_l1_ (u"ࠫࠬᏗ"),l1l1l1_l1_ (u"ࠬ࠭Ꮨ"),l1l1l1_l1_ (u"࠭ࠧᏙ"),l1l1l1_l1_ (u"ࠧࠨᏚ"),l1l1l1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬᏛ"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠩࠪᏜ"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧᏝ"))
	if request==l1l1l1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᏞ"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᏟ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"࠭ࠧᏠ"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᏡ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᏢ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᏣ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᏤ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨᏥ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᏦ"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᏧ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡤࡤࠤࡲ࡭ࡢࠡࡶࡤࡦࡱ࡫ࠠࡧࡷ࡯ࡰࠧ࠮࠮ࠫࡁࠬࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧᏨ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᏩ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠩࠪᏪ"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᏫ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᏬ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"๋ࠬิศ้าอࠬᏭ"),l1l1l1_l1_ (u"࠭แ๋ๆ่ࠫᏮ"),l1l1l1_l1_ (u"ࠧศ฼้๎ฮ࠭Ꮿ"),l1l1l1_l1_ (u"ࠨๅ็๎อ࠭Ᏸ"),l1l1l1_l1_ (u"ࠩส฽้อๆࠨᏱ"),l1l1l1_l1_ (u"๋ࠪิอแࠨᏲ"),l1l1l1_l1_ (u"๊ࠫฮวาษฬࠫᏳ"),l1l1l1_l1_ (u"ࠬ฿ัืࠩᏴ"),l1l1l1_l1_ (u"࠭ๅ่ำฯห๋࠭Ᏽ"),l1l1l1_l1_ (u"ࠧศๆห์๊࠭᏶"),l1l1l1_l1_ (u"ࠨ็ึีา๐ษࠨ᏷")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠩ࠲ࠫᏸ"))
		#if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᏹ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭ᏺ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧᏻ"))
		#if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫᏼ") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩᏽ")+img.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ᏾"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ᏿"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭᐀"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᐁ"),menu_name+title,l111ll_l1_,652,img)
		elif request==l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᐂ"):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᐃ"),menu_name+title,l111ll_l1_,652,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᐄ") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐅ"),menu_name+title,l111ll_l1_,653,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧᐆ") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐇ"),menu_name+title,l111ll_l1_,651,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐈ"),menu_name+title,l111ll_l1_,653,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᐉ"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᐊ")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᐋ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᐌ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠩࠦࠫᐍ"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬᐎ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭ᐏ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐐ"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬᐑ")+title,l111ll_l1_,651)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨᐒ"),l1l1l1_l1_ (u"ࠨࠩᐓ"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭ᐔ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᐕ"),url,l1l1l1_l1_ (u"ࠫࠬᐖ"),l1l1l1_l1_ (u"ࠬ࠭ᐗ"),l1l1l1_l1_ (u"࠭ࠧᐘ"),l1l1l1_l1_ (u"ࠧࠨᐙ"),l1l1l1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᐚ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬᐛ"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᐜ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"ࠫࠬᐝ")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࠭ࠧࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭ᐞ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩᐟ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠧࠤࠩᐠ"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐡ"),menu_name+title,url,653,img,l1l1l1_l1_ (u"ࠩࠪᐢ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠫ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠯࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᐣ"),html,re.DOTALL)
	#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬᐤ"),str(l1ll1l1_l1_))
	block = l1ll1l1_l1_[0]
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪᐥ")+l1lll_l1_+l1l1l1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐦ"),block,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠭ᐧ")+l1lll_l1_+l1l1l1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᐨ"),block,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡨࡂࠨࡓࡦࡣࡶࡳࡳ࠭ᐩ")+l1lll_l1_+l1l1l1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᐪ"),block,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠥᐫ"),block,re.DOTALL)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ᐬ"),l1l1l1_l1_ (u"࠭ࠧᐭ"),l1l1l1_l1_ (u"ࠧࠨᐮ"),l1l1l1_l1_ (u"ࠨ࠴࠵࠶࠷࠸ࠧᐯ"))
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ᐰ"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᐱ"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠳࠵ࠧᐲ"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧᐳ")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨᐴ"))
			title = title.replace(l1l1l1_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬᐵ"),l1l1l1_l1_ (u"ࠨࠢࠪᐶ"))
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᐷ"),menu_name+title,l111ll_l1_,652,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᐸ"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᐹ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧᐺ")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨᐻ"))
		#		addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᐼ"),menu_name+title,l111ll_l1_,652,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l11_l1_,l111l11_l1_ = [],[],[]
	url2 = url.replace(l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬᐽ"),l1l1l1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠯ࡲ࡫ࡴࠬᐾ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᐿ"),url2,l1l1l1_l1_ (u"ࠫࠬᑀ"),l1l1l1_l1_ (u"ࠬ࠭ᑁ"),l1l1l1_l1_ (u"࠭ࠧᑂ"),l1l1l1_l1_ (u"ࠧࠨᑃ"),l1l1l1_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᑄ"))
	html = response.content
	# l11ll1l1l_l1_ l111ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡨࡂࠨࡐ࡭ࡣࡼࡩࡷ࡮࡯࡭ࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᑅ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᑆ"),block,re.DOTALL)
		if l111ll_l1_:
			l111ll_l1_ = l111ll_l1_[0]
			l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬᑇ"))
			l11l1_l1_.append(l111ll_l1_)
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᑈ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦ࠰ࡹࡷࡲ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠦᑉ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩᑊ"))
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᑋ")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᑌ"))
				l11l1_l1_.append(l111ll_l1_)
	l1l1l1_l1_ (u"ࠥࠦࠧࠐࠉࠤࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡱ࡯࡮࡬ࡵࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ࠭ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪ࠭ࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠴࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡅࡖࡘ࡚ࡅࡋ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏ࡬ࡪࡰ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡱ࡯࡮࡬ࡵ࠽ࠎࠎࠏࠉࡪࡨࠣࡰ࡮ࡴ࡫ࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡒࡉࡔࡖ࠽ࠎࠎࠏࠉࠊࡰࡤࡱࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ࠭ࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠧࠨࠢᑍ")
	zzz = zip(l11l1_l1_,l111l1l11_l1_)
	for l111ll_l1_,name in zzz: l111l11_l1_.append(l111ll_l1_+name)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᑎ"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᑏ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧᑐ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨᑑ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪᑒ"),l1l1l1_l1_ (u"ࠩ࠮ࠫᑓ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫᑔ")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫᑕ"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩᑖ")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᑗ"))
	return
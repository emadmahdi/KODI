# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠪࡑ࠸࡛ࠧ㌳")
menu_name = l1l1l1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ㌴")
UNIQUE_TYPES = [
		 l1l1l1_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉ࠭㌵")
		,l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭㌶"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㌷")
		,l1l1l1_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ㌸"),l1l1l1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㌹")
		#,l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡃࡕࡇࡍࡏࡖࡆࡆࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㌺"),l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㌻"),l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙ࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㌼")
		,l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ㌽"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㌾")
		,l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㌿"),l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫ㍀"),l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ㍁")
		,l1l1l1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㍂"),l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㍃")
		,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ㍄"),l1l1l1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㍅")
		,l1l1l1_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㍆"),l1l1l1_l1_ (u"࡙ࠩࡓࡉࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ㍇"),l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ㍈")
		]
l1ll111l1ll_l1_ = 4
def MAIN(mode,url,text,type,page,infodict):
	try: folder = str(infodict[l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㍉")])
	except: folder = l1l1l1_l1_ (u"ࠬ࠭㍊")
	try: l11l1l11_l1_ = str(infodict[l1l1l1_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥࠨ㍋")])
	except: l11l1l11_l1_ = l1l1l1_l1_ (u"ࠧࠨ㍌")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(folder,l11l1l11_l1_)
	elif mode==712: results = l1ll111ll1l_l1_(folder)
	elif mode==713: results = GROUPS(folder,url,text,page)
	elif mode==714: results = ITEMS(folder,url,text,page)
	elif mode==715: results = PLAY(folder,url,type)
	elif mode==716: results = CHECK_ACCOUNT(folder,True)
	elif mode==717: results = l1ll1111l1l_l1_(folder,True)
	elif mode==718: results = EPG_ITEMS(folder,url,text)
	elif mode==719: results = SEARCH(text,folder,url,page)
	elif mode==720: results = MENU(folder)
	elif mode==721: results = l1ll11l111l_l1_(folder)
	elif mode==722: results = USE_FASTER_SERVER(folder)
	elif mode==723: results = ADD_USERAGENT(folder)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==729: results = SEARCH_ONE_FOLDER(text,folder,url,page)
	else: results = False
	return results
def FOLDERS_MENU():
	for folder in range(FOLDERS_COUNT):
		folder2 = l1l1l1_l1_ (u"ࠨࠢࡐ࠷࡚࠭㍍")+str(int(folder)+1)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㍎"),menu_name+l1l1l1_l1_ (u"้ࠪั๊ฯࠡࠩ㍏")+text_numbers[folder]+folder2,l1l1l1_l1_ (u"ࠫࠬ㍐"),720,l1l1l1_l1_ (u"ࠬ࠭㍑"),l1l1l1_l1_ (u"࠭ࠧ㍒"),l1l1l1_l1_ (u"ࠧࠨ㍓"),l1l1l1_l1_ (u"ࠨࠩ㍔"),{l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㍕"):folder})
	return
def SECTIONS_MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㍖"),menu_name+l1l1l1_l1_ (u"ࠫัฺ๋๊ࠢฦๆุอๅࠡࡏ࠶࡙ࠬ㍗"),l1l1l1_l1_ (u"ࠬ࠭㍘"),165,l1l1l1_l1_ (u"࠭ࠧ㍙"),l1l1l1_l1_ (u"ࠧࠨ㍚"),l1l1l1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ㍛"))
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㍜"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㍝"),l1l1l1_l1_ (u"ࠫࠬ㍞"),9999)
	for folder in range(FOLDERS_COUNT):
		folder2 = l1l1l1_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ㍟")+str(int(folder)+1)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㍠"),menu_name+l1l1l1_l1_ (u"ࠧฤไึห๊ࠦๅอๆาࠤࠬ㍡")+text_numbers[folder]+folder2,l1l1l1_l1_ (u"ࠨࠩ㍢"),165,l1l1l1_l1_ (u"ࠩࠪ㍣"),l1l1l1_l1_ (u"ࠪࠫ㍤"),l1l1l1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ㍥"),l1l1l1_l1_ (u"ࠬ࠭㍦"),{l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㍧"):folder})
	return
def MENU(folder=l1l1l1_l1_ (u"ࠧࠨ㍨")):
	if folder:
		folder1 = {l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㍩"):folder}
		folder2 = l1l1l1_l1_ (u"ࠩࠣࡑ࠸࡛ࠧ㍪")+str(int(folder)+1)
	else:
		folder1 = l1l1l1_l1_ (u"ࠪࠫ㍫")
		folder2 = l1l1l1_l1_ (u"ࠫࠬ㍬")
	if CHECK_TABLES_EXIST(folder,True):
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㍭"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦๅๅใสฮࠬ㍮")+folder2,l1l1l1_l1_ (u"ࠧࠨ㍯"),729,l1l1l1_l1_ (u"ࠨࠩ㍰"),l1l1l1_l1_ (u"ࠩࠪ㍱"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㍲"),l1l1l1_l1_ (u"ࠫࠬ㍳"),folder1)
		#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㍴"),menu_name+l1l1l1_l1_ (u"࠭โศศ่อࠥษโิษ่ࠫ㍵")+folder2,l1l1l1_l1_ (u"ࠧࠨ㍶"),165,l1l1l1_l1_ (u"ࠨࠩ㍷"),l1l1l1_l1_ (u"ࠩࠪ㍸"),l1l1l1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ㍹"),l1l1l1_l1_ (u"ࠫࠬ㍺"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㍻"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㍼"),l1l1l1_l1_ (u"ࠧࠨ㍽"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㍾"),menu_name+l1l1l1_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠧ㍿")+folder2,l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㎀"),713,l1l1l1_l1_ (u"ࠫࠬ㎁"),l1l1l1_l1_ (u"ࠬ࠭㎂"),l1l1l1_l1_ (u"࠭ࠧ㎃"),l1l1l1_l1_ (u"ࠧࠨ㎄"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㎅"),menu_name+l1l1l1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโหࠪ㎆")+folder2,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㎇"),713,l1l1l1_l1_ (u"ࠫࠬ㎈"),l1l1l1_l1_ (u"ࠬ࠭㎉"),l1l1l1_l1_ (u"࠭ࠧ㎊"),l1l1l1_l1_ (u"ࠧࠨ㎋"),folder1)
		#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㎌"),menu_name+l1l1l1_l1_ (u"ࠩฦๅ้อๅࠡ็ุ๊ๆฯࠧ㎍")+folder2,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㎎"),713,l1l1l1_l1_ (u"ࠫࠬ㎏"),l1l1l1_l1_ (u"ࠬ࠭㎐"),l1l1l1_l1_ (u"࠭ࠧ㎑"),l1l1l1_l1_ (u"ࠧࠨ㎒"),folder1)
		#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㎓"),menu_name+l1l1l1_l1_ (u"่ࠩืู้ไศฬฺ้ࠣ์แสࠩ㎔")+folder2,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㎕"),713,l1l1l1_l1_ (u"ࠫࠬ㎖"),l1l1l1_l1_ (u"ࠬ࠭㎗"),l1l1l1_l1_ (u"࠭ࠧ㎘"),l1l1l1_l1_ (u"ࠧࠨ㎙"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㎚"),menu_name+l1l1l1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊า็้ๆฬࠫ㎛")+folder2,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㎜"),713,l1l1l1_l1_ (u"ࠫࠬ㎝"),l1l1l1_l1_ (u"ࠬ࠭㎞"),l1l1l1_l1_ (u"࠭ࠧ㎟"),l1l1l1_l1_ (u"ࠧࠨ㎠"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㎡"),menu_name+l1l1l1_l1_ (u"ࠩๅ๊ํอสࠡ็ฯ๋ํ๊ษࠨ㎢")+folder2,l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㎣"),713,l1l1l1_l1_ (u"ࠫࠬ㎤"),l1l1l1_l1_ (u"ࠬ࠭㎥"),l1l1l1_l1_ (u"࠭ࠧ㎦"),l1l1l1_l1_ (u"ࠧࠨ㎧"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㎨"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㎩"),l1l1l1_l1_ (u"ࠪࠫ㎪"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㎫"),menu_name+l1l1l1_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโหࠣ์๊ืสษหࠪ㎬")+folder2,l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㎭"),713,l1l1l1_l1_ (u"ࠧࠨ㎮"),l1l1l1_l1_ (u"ࠨࠩ㎯"),l1l1l1_l1_ (u"ࠩࠪ㎰"),l1l1l1_l1_ (u"ࠪࠫ㎱"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㎲"),menu_name+l1l1l1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮ่ࠦๆำอฬฮ࠭㎳")+folder2,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㎴"),713,l1l1l1_l1_ (u"ࠧࠨ㎵"),l1l1l1_l1_ (u"ࠨࠩ㎶"),l1l1l1_l1_ (u"ࠩࠪ㎷"),l1l1l1_l1_ (u"ࠪࠫ㎸"),folder1)
		#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㎹"),menu_name+l1l1l1_l1_ (u"ࠬษแๅษ่ࠤ๊฻ๆโหࠣ์๊ืสษหࠪ㎺")+folder2,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㎻"),713,l1l1l1_l1_ (u"ࠧࠨ㎼"),l1l1l1_l1_ (u"ࠨࠩ㎽"),l1l1l1_l1_ (u"ࠩࠪ㎾"),l1l1l1_l1_ (u"ࠪࠫ㎿"),folder1)
		#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㏀"),menu_name+l1l1l1_l1_ (u"๋ࠬำๅี็หฯࠦๅึ่ไอࠥ๎ๅาฬหอࠬ㏁")+folder2,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㏂"),713,l1l1l1_l1_ (u"ࠧࠨ㏃"),l1l1l1_l1_ (u"ࠨࠩ㏄"),l1l1l1_l1_ (u"ࠩࠪ㏅"),l1l1l1_l1_ (u"ࠪࠫ㏆"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㏇"),menu_name+l1l1l1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯ้ࠠ็ิฮอฯࠧ㏈")+folder2,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㏉"),713,l1l1l1_l1_ (u"ࠧࠨ㏊"),l1l1l1_l1_ (u"ࠨࠩ㏋"),l1l1l1_l1_ (u"ࠩࠪ㏌"),l1l1l1_l1_ (u"ࠪࠫ㏍"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㏎"),menu_name+l1l1l1_l1_ (u"่ࠬๆ้ษอࠤ๊า็้ๆฬࠤํ๋ัหสฬࠫ㏏")+folder2,l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㏐"),713,l1l1l1_l1_ (u"ࠧࠨ㏑"),l1l1l1_l1_ (u"ࠨࠩ㏒"),l1l1l1_l1_ (u"ࠩࠪ㏓"),l1l1l1_l1_ (u"ࠪࠫ㏔"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㏕"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㏖"),l1l1l1_l1_ (u"࠭ࠧ㏗"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㏘"),menu_name+l1l1l1_l1_ (u"ࠨษ็ๆ๋๎วหࠢส่ศ฻ไ๋หࠣฬิ๎ๆࠡฬ฽๎๏ืࠧ㏙")+folder2,l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㏚"),713,l1l1l1_l1_ (u"ࠪࠫ㏛"),l1l1l1_l1_ (u"ࠫࠬ㏜"),l1l1l1_l1_ (u"ࠬ࠭㏝"),l1l1l1_l1_ (u"࠭ࠧ㏞"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㏟"),menu_name+l1l1l1_l1_ (u"ࠨษ็ๅ๏ี๊้้สฮࠥอไฤื็๎ฮࠦศะ๊้ࠤฯเ๊๋ำࠪ㏠")+folder2,l1l1l1_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㏡"),713,l1l1l1_l1_ (u"ࠪࠫ㏢"),l1l1l1_l1_ (u"ࠫࠬ㏣"),l1l1l1_l1_ (u"ࠬ࠭㏤"),l1l1l1_l1_ (u"࠭ࠧ㏥"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㏦"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㏧"),l1l1l1_l1_ (u"ࠩࠪ㏨"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㏩"),menu_name+l1l1l1_l1_ (u"ࠫ็์่ศฬฺ้ࠣ์แส่๊ࠢࠥษำๆษษ๋ฬ่ࠦๆำอฬฮ࠭㏪")+folder2,l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭㏫"),713,l1l1l1_l1_ (u"࠭ࠧ㏬"),l1l1l1_l1_ (u"ࠧࠨ㏭"),l1l1l1_l1_ (u"ࠨࠩ㏮"),l1l1l1_l1_ (u"ࠩࠪ㏯"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㏰"),menu_name+l1l1l1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅึ่ไอ๋ࠥๆࠡลึ้ฬฬ็ศ๋้ࠢึะศสࠩ㏱")+folder2,l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࠬ㏲"),713,l1l1l1_l1_ (u"࠭ࠧ㏳"),l1l1l1_l1_ (u"ࠧࠨ㏴"),l1l1l1_l1_ (u"ࠨࠩ㏵"),l1l1l1_l1_ (u"ࠩࠪ㏶"),folder1)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㏷"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㏸"),l1l1l1_l1_ (u"ࠬ࠭㏹"),9999)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㏺"),menu_name+l1l1l1_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอ๋ࠥๆࠡลๅืฬ๋็ศ๋้ࠢึะศสࠩ㏻")+folder2,l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪ㏼"),713,l1l1l1_l1_ (u"ࠩࠪ㏽"),l1l1l1_l1_ (u"ࠪࠫ㏾"),l1l1l1_l1_ (u"ࠫࠬ㏿"),l1l1l1_l1_ (u"ࠬ࠭㐀"),folder1)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㐁"),menu_name+l1l1l1_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠡ็้ࠤศ่ำศ็๊หࠥ๎ๅาฬหอࠬ㐂")+folder2,l1l1l1_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡋࡗࡕࡕࡑࡡࡖࡓࡗ࡚ࡅࡅࠩ㐃"),713,l1l1l1_l1_ (u"ࠩࠪ㐄"),l1l1l1_l1_ (u"ࠪࠫ㐅"),l1l1l1_l1_ (u"ࠫࠬ㐆"),l1l1l1_l1_ (u"ࠬ࠭㐇"),folder1)
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㐈"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㐉"),l1l1l1_l1_ (u"ࠨࠩ㐊"),9999)
	for seq in range(l1ll111l1ll_l1_):
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㐋"),menu_name+l1l1l1_l1_ (u"ࠪษ฻อแส๋ࠢฮ฿๐๊าࠢิหอ฽ࠧ㐌")+folder2+l1l1l1_l1_ (u"ࠫࠥ࠭㐍")+text_numbers[seq],l1l1l1_l1_ (u"ࠬ࠭㐎"),711,l1l1l1_l1_ (u"࠭ࠧ㐏"),l1l1l1_l1_ (u"ࠧࠨ㐐"),l1l1l1_l1_ (u"ࠨࠩ㐑"),l1l1l1_l1_ (u"ࠩࠪ㐒"),{l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㐓"):folder,l1l1l1_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭㐔"):seq})
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐕"),menu_name+l1l1l1_l1_ (u"࠭ศาษ่ะࠥอไใ่๋หฯࠦࠨอั๋่ࠥ็โุࠫࠪ㐖")+folder2,l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㐗"),713,l1l1l1_l1_ (u"ࠨࠩ㐘"),l1l1l1_l1_ (u"ࠩࠪ㐙"),l1l1l1_l1_ (u"ࠪࠫ㐚"),l1l1l1_l1_ (u"ࠫࠬ㐛"),folder1)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐜"),menu_name+l1l1l1_l1_ (u"࠭ราึํๅࠥอไใ่๋หฯࠦไๅลํห๊ࠦวๅ็สฺ๏ฯࠧ㐝")+folder2,l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡚ࡉࡎࡇࡖࡌࡎࡌࡔࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㐞"),713,l1l1l1_l1_ (u"ࠨࠩ㐟"),l1l1l1_l1_ (u"ࠩࠪ㐠"),l1l1l1_l1_ (u"ࠪࠫ㐡"),l1l1l1_l1_ (u"ࠫࠬ㐢"),folder1)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐣"),menu_name+l1l1l1_l1_ (u"࠭ราึํๅࠥฮัศ็ฯࠤฬ๊โ็๊สฮ๊ࠥไฤ์ส้ࠥอไๆษู๎ฮ࠭㐤")+folder2,l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡇࡒࡄࡊࡌ࡚ࡊࡊ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㐥"),713,l1l1l1_l1_ (u"ࠨࠩ㐦"),l1l1l1_l1_ (u"ࠩࠪ㐧"),l1l1l1_l1_ (u"ࠪࠫ㐨"),l1l1l1_l1_ (u"ࠫࠬ㐩"),folder1)
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㐪"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㐫"),l1l1l1_l1_ (u"ࠧࠨ㐬"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㐭"),menu_name+l1l1l1_l1_ (u"ࠩศฺฬ็ษࠡล๋ࠤฯเ๊๋ำࠣหูะัศๅࠪ㐮")+folder2,l1l1l1_l1_ (u"ࠪࠫ㐯"),711,l1l1l1_l1_ (u"ࠫࠬ㐰"),l1l1l1_l1_ (u"ࠬ࠭㐱"),l1l1l1_l1_ (u"࠭ࠧ㐲"),l1l1l1_l1_ (u"ࠧࠨ㐳"),folder1)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㐴"),menu_name+l1l1l1_l1_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠨ㐵")+folder2,l1l1l1_l1_ (u"ࠪࠫ㐶"),721,l1l1l1_l1_ (u"ࠫࠬ㐷"),l1l1l1_l1_ (u"ࠬ࠭㐸"),l1l1l1_l1_ (u"࠭ࠧ㐹"),l1l1l1_l1_ (u"ࠧࠨ㐺"),folder1)
	#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㐻"),menu_name+l1l1l1_l1_ (u"ࠩไัฺࠦวีฬิห่࠭㐼")+folder2,l1l1l1_l1_ (u"ࠪࠫ㐽"),716,l1l1l1_l1_ (u"ࠫࠬ㐾"),l1l1l1_l1_ (u"ࠬ࠭㐿"),l1l1l1_l1_ (u"࠭ࠧ㑀"),l1l1l1_l1_ (u"ࠧࠨ㑁"),folder1)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㑂"),menu_name+l1l1l1_l1_ (u"ࠩฯ่อࠦๅๅใสฮࠬ㑃")+folder2,l1l1l1_l1_ (u"ࠪࠫ㑄"),712,l1l1l1_l1_ (u"ࠫࠬ㑅"),l1l1l1_l1_ (u"ࠬ࠭㑆"),l1l1l1_l1_ (u"࠭ࠧ㑇"),l1l1l1_l1_ (u"ࠧࠨ㑈"),folder1)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㑉"),menu_name+l1l1l1_l1_ (u"่ࠩืาࠦๅๅใสฮࠬ㑊")+folder2,l1l1l1_l1_ (u"ࠪࠫ㑋"),717,l1l1l1_l1_ (u"ࠫࠬ㑌"),l1l1l1_l1_ (u"ࠬ࠭㑍"),l1l1l1_l1_ (u"࠭ࠧ㑎"),l1l1l1_l1_ (u"ࠧࠨ㑏"),folder1)
	#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㑐"),menu_name+l1l1l1_l1_ (u"ࠩสืฯิฯศ็ࠣหู้๊าใิࠤฬ๊ริำ฼ࠫ㑑")+folder2,l1l1l1_l1_ (u"ࠪࠫ㑒"),722,l1l1l1_l1_ (u"ࠫࠬ㑓"),l1l1l1_l1_ (u"ࠬ࠭㑔"),l1l1l1_l1_ (u"࠭ࠧ㑕"),l1l1l1_l1_ (u"ࠧࠨ㑖"),folder1)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㑗"),menu_name+l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦส฻์ํีࠬ㑘")+folder2,l1l1l1_l1_ (u"ࠪࠫ㑙"),723,l1l1l1_l1_ (u"ࠫࠬ㑚"),l1l1l1_l1_ (u"ࠬ࠭㑛"),l1l1l1_l1_ (u"࠭ࠧ㑜"),l1l1l1_l1_ (u"ࠧࠨ㑝"),folder1)
	return
def CHECK_ACCOUNT(folder,showDialogs=True):
	ok,status = False,l1l1l1_l1_ (u"ࠨࠩ㑞")
	new_host,new_port = l1l1l1_l1_ (u"ࠩࠪ㑟"),l1l1l1_l1_ (u"ࠪࠫ㑠")
	URL_player,URL_get,server,username,password = GET_URL(folder)
	if username==l1l1l1_l1_ (u"ࠫࠬ㑡"): return
	useragent = settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ㑢")+folder)
	headers = {l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㑣"):useragent}
	if URL_player:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ㑤"),URL_player,l1l1l1_l1_ (u"ࠨࠩ㑥"),headers,False,False,l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡄࡊࡈࡇࡐࡥࡁࡄࡅࡒ࡙ࡓ࡚࠭࠲ࡵࡷࠫ㑦"))
		html = response.content
		if response.succeeded:
			timestamp,timediff,time_now,created_at,exp_date = 0,0,l1l1l1_l1_ (u"ࠪࠫ㑧"),l1l1l1_l1_ (u"ࠫࠬ㑨"),l1l1l1_l1_ (u"ࠬ࠭㑩")
			try:
				dict = EVAL(l1l1l1_l1_ (u"࠭ࡤࡪࡥࡷࠫ㑪"),html)
				status = dict[l1l1l1_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ㑫")][l1l1l1_l1_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ㑬")]
				ok = True
				time_now = dict[l1l1l1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡡ࡬ࡲ࡫ࡵࠧ㑭")][l1l1l1_l1_ (u"ࠪࡸ࡮ࡳࡥࡠࡰࡲࡻࠬ㑮")]
			except: pass
			if time_now:
				try:
					struct = time.strptime(time_now,l1l1l1_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨ㑯"))
					timestamp = int(time.mktime(struct))
					timediff = int(now-timestamp)
					timediff = int((timediff+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l1l1l1_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ㑰")][l1l1l1_l1_ (u"࠭ࡣࡳࡧࡤࡸࡪࡪ࡟ࡢࡶࠪ㑱")]))
					created_at = time.strftime(l1l1l1_l1_ (u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ㑲"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l1l1l1_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ㑳")][l1l1l1_l1_ (u"ࠩࡨࡼࡵࡥࡤࡢࡶࡨࠫ㑴")]))
					exp_date = time.strftime(l1l1l1_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ㑵"),struct)
				except: pass
			settings.setSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ㑶")+folder,str(now))
			settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡴࡪ࡯ࡨࡨ࡮࡬ࡦࡠࠩ㑷")+folder,str(timediff))
			server_info = l1l1l1_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸ࡟ࡪࡰࡩࡳࠧࡀࠧ㑸")+html.split(l1l1l1_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡱࡪࡴࠨ࠺ࠨ㑹"))[1]
			server_info = server_info.replace(l1l1l1_l1_ (u"ࠨ࠼ࠪ㑺"),l1l1l1_l1_ (u"ࠩ࠽ࠤࠬ㑻")).replace(l1l1l1_l1_ (u"ࠪ࠰ࠬ㑼"),l1l1l1_l1_ (u"ࠫ࠱ࠦࠧ㑽")).replace(l1l1l1_l1_ (u"ࠬࢃࡽࠨ㑾"),l1l1l1_l1_ (u"࠭ࡽࠨ㑿"))
			new = re.findall(l1l1l1_l1_ (u"ࠧࠣࡷࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠢࠥࡴࡴࡸࡴࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ㒀"),server_info,re.DOTALL)
			new_host,new_port = new[0]
			if ok and showDialogs:
				max = dict[l1l1l1_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ㒁")][l1l1l1_l1_ (u"ࠩࡰࡥࡽࡥࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࡶࠫ㒂")]
				active = dict[l1l1l1_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭㒃")][l1l1l1_l1_ (u"ࠫࡦࡩࡴࡪࡸࡨࡣࡨࡵ࡮ࡴࠩ㒄")]
				is_trial = dict[l1l1l1_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ㒅")][l1l1l1_l1_ (u"࠭ࡩࡴࡡࡷࡶ࡮ࡧ࡬ࠨ㒆")]
				parts = URL_player.split(l1l1l1_l1_ (u"ࠧࡀࠩ㒇"),1)
				message = l1l1l1_l1_ (u"ࠨࡗࡕࡐ࠿ࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㒈")+URL_player+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㒉")
				message += l1l1l1_l1_ (u"ࠪࡠࡳࡢ࡮ࡔࡶࡤࡸࡺࡹ࠺ࠡࠢࠪ㒊")+l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㒋")+status+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㒌")
				message += l1l1l1_l1_ (u"࠭࡜࡯ࡖࡵ࡭ࡦࡲ࠺ࠡࠢࠣࠤࠬ㒍")+l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㒎")+str(is_trial==l1l1l1_l1_ (u"ࠨ࠳ࠪ㒏"))+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㒐")
				message += l1l1l1_l1_ (u"ࠪࡠࡳࡉࡲࡦࡣࡷࡩࡩࠦࠠࡂࡶ࠽ࠤࠥ࠭㒑")+l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㒒")+created_at+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㒓")
				message += l1l1l1_l1_ (u"࠭࡜࡯ࡇࡻࡴ࡮ࡸࡹࠡࡆࡤࡸࡪࡀࠠࠡࠩ㒔")+l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㒕")+exp_date+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㒖")
				message += l1l1l1_l1_ (u"ࠩ࡟ࡲࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࡴࠢࠣࠤ࠭ࠦࡁࡤࡶ࡬ࡺࡪࠦ࠯ࠡࡏࡤࡼ࡮ࡳࡵ࡮ࠢࠬࠤ࠿ࠦࠠࠨ㒗")+l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭㒘")+active+l1l1l1_l1_ (u"ࠫࠥ࠵ࠠࠨ㒙")+max+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㒚")
				message += l1l1l1_l1_ (u"࠭࡜࡯ࡃ࡯ࡰࡴࡽࡥࡥࠢࡒࡹࡹࡶࡵࡵࡵ࠽ࠤࠥࠦࠧ㒛")+l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㒜")+l1l1l1_l1_ (u"ࠣࠢ࠯ࠤࠧ㒝").join(dict[l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ㒞")][l1l1l1_l1_ (u"ࠪࡥࡱࡲ࡯ࡸࡧࡧࡣࡴࡻࡴࡱࡷࡷࡣ࡫ࡵࡲ࡮ࡣࡷࡷࠬ㒟")])+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㒠")
				message += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㒡")+server_info
				if status==l1l1l1_l1_ (u"࠭ࡁࡤࡶ࡬ࡺࡪ࠭㒢"): DIALOG_TEXTVIEWER(l1l1l1_l1_ (u"ࠧศๆสุฯืวไࠢํ฽๊๊ࠠษั๋๊๋ࠥิศๅ็ࠫ㒣"),message)
				else: DIALOG_TEXTVIEWER(l1l1l1_l1_ (u"ࠨ์หำํࠦร็๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ฬฺสาษๆࠫ㒤"),message)
	if URL_player and ok and status==l1l1l1_l1_ (u"ࠩࡄࡧࡹ࡯ࡶࡦࠩ㒥"):
		LOG_THIS(l1l1l1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㒦"),l1l1l1_l1_ (u"ࠫ࠳ࠦࠠࠡࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡍࡕ࡚ࡖࠡࡗࡕࡐࠥࠦࠠ࡜ࠢࡌࡔ࡙࡜ࠠࡢࡥࡦࡳࡺࡴࡴࠡ࡫ࡶࠤࡔࡑࠠ࡞ࠢࠣࠤࡠࠦࠧ㒧")+URL_player+l1l1l1_l1_ (u"ࠬࠦ࡝ࠨ㒨"))
		succeeded = True
	else:
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㒩"),l1l1l1_l1_ (u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡌࡔ࡙࡜ࠠࡖࡔࡏࠤ࡛ࠥࠦࠡࡆࡲࡩࡸࠦ࡮ࡰࡶࠣࡻࡴࡸ࡫ࠡ࡟ࠣࠤࠥࡡࠠࠨ㒪")+URL_player+l1l1l1_l1_ (u"ࠨࠢࡠࠫ㒫"))
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㒬"),l1l1l1_l1_ (u"ࠪࠫ㒭"),l1l1l1_l1_ (u"ࠫๆำีࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠧ㒮"),l1l1l1_l1_ (u"ࠬืวษูࠣหูะัศๅࠣไࡎࡖࡔࡗࠢส่ี๐ࠠใ็อࠤฬ์สࠡสศฺฬ็ส่ࠢศ่๎ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏฿ๅๅࠢฦ์ࠥอไาษห฻ࠥเ๊า่ࠢ์ั๎ฯࠡใํࠤฬ๊ศา่ส้ัࠦ࠮ࠡลำ๋อࠦลๅ๋ࠣๆฬฬๅสࠢสุฯืวไࠢใࡍࡕ࡚ࡖ๊ࠡๅ้ࠥฮลืษไอࠥืวษูࠣไࡎࡖࡔࡗࠢฯำ๏ีࠠฤ๊ࠣๆ๊ࠦศฦื็หาࠦวๅำสฬ฼ࠦวๅไา๎๊࠭㒯"))
		succeeded = False
	return succeeded,new_host,new_port
def ITEMS(folder,TYPE,GROUP,PAGE,showDialogs=True):
	if not PAGE: PAGE = l1l1l1_l1_ (u"࠭࠱ࠨ㒰")
	#menu_name = l1l1l1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㒱")
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	dbfile = GET_DBFILE_NAME(folder,TYPE)
	streams = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㒲"),TYPE,GROUP)
	end = int(PAGE)*100
	start = end-100
	for context,title,url,img in streams[start:end]:
		cond1 = (l1l1l1_l1_ (u"ࠩࡊࡖࡔ࡛ࡐࡆࡆࠪ㒳") in TYPE or TYPE==l1l1l1_l1_ (u"ࠪࡅࡑࡒࠧ㒴"))
		cond2 = (l1l1l1_l1_ (u"ࠫࡌࡘࡏࡖࡒࡈࡈࠬ㒵") not in TYPE and TYPE!=l1l1l1_l1_ (u"ࠬࡇࡌࡍࠩ㒶"))
		if cond1 or cond2:
			if   l1l1l1_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ㒷")  in TYPE: menuItemsLIST.append([l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㒸"),menu_name+title,url,718,img,l1l1l1_l1_ (u"ࠨࠩ㒹"),l1l1l1_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ㒺"),l1l1l1_l1_ (u"ࠪࠫ㒻"),{l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㒼"):folder}])
			elif l1l1l1_l1_ (u"ࠬࡋࡐࡈࠩ㒽") 		 in TYPE: menuItemsLIST.append([l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㒾"),menu_name+title,url,718,img,l1l1l1_l1_ (u"ࠧࠨ㒿"),l1l1l1_l1_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪ㓀"),l1l1l1_l1_ (u"ࠩࠪ㓁"),{l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓂"):folder}])
			elif l1l1l1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㓃") in TYPE: menuItemsLIST.append([l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㓄"),menu_name+title,url,718,img,l1l1l1_l1_ (u"࠭ࠧ㓅"),l1l1l1_l1_ (u"ࠧࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ㓆"),l1l1l1_l1_ (u"ࠨࠩ㓇"),{l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㓈"):folder}])
			elif l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ㓉") 	 in TYPE: menuItemsLIST.append([l1l1l1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㓊"),menu_name+title,url,715,img,l1l1l1_l1_ (u"ࠬ࠭㓋"),l1l1l1_l1_ (u"࠭ࠧ㓌"),context,{l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㓍"):folder}])
			else: menuItemsLIST.append([l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㓎"),menu_name+title,url,715,img,l1l1l1_l1_ (u"ࠩࠪ㓏"),l1l1l1_l1_ (u"ࠪࠫ㓐"),l1l1l1_l1_ (u"ࠫࠬ㓑"),{l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㓒"):folder}])
	total = len(streams)
	PAGINATION(folder,PAGE,TYPE,714,total,GROUP)
	return
def SHOW_EMPTY(menu_name2):
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㓓"),menu_name2+l1l1l1_l1_ (u"่ࠧา๊ࠤฬ๊โศศ่อࠥหๅศࠢไหึเษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠨ㓔"),l1l1l1_l1_ (u"ࠨࠩ㓕"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㓖"),menu_name2+l1l1l1_l1_ (u"ࠪวํࠦวๅะา้ฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦวีฬิห่้ࠧ㓗"),l1l1l1_l1_ (u"ࠫࠬ㓘"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㓙"),menu_name2+l1l1l1_l1_ (u"࠭ร้ࠢิหอ฽ࠠࡎ࠵ࡘไࠥอไั์ࠣว๋ะࠠฤุไฮ์ฺ๋ࠦำูࠣา๐อࠨ㓚"),l1l1l1_l1_ (u"ࠧࠨ㓛"),9999)
	return
def GROUPS(folder,TYPE,GROUP,PAGE,website=l1l1l1_l1_ (u"ࠨࠩ㓜"),showDialogs=True):
	if not PAGE: PAGE = l1l1l1_l1_ (u"ࠩ࠴ࠫ㓝")
	menu_name2 = menu_name
	if not CHECK_TABLES_EXIST(folder,showDialogs): return False
	if l1l1l1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㓞") in GROUP: MAINGROUP,SUBGROUP = GROUP.split(l1l1l1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㓟"))
	else: MAINGROUP,SUBGROUP = GROUP,l1l1l1_l1_ (u"ࠬ࠭㓠")
	dbfile = GET_DBFILE_NAME(folder,TYPE)
	uniquegroups = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㓡"),TYPE,l1l1l1_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ㓢"))
	if not uniquegroups: return False
	unique = []
	for group,img in uniquegroups:
		if website:
			if l1l1l1_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㓣") in group: menu_name2 = l1l1l1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ㓤")
			elif l1l1l1_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡡࠤࠥࠬ㓥") in group: menu_name2 = l1l1l1_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒࠬ㓦")
			elif l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࠪ㓧") in TYPE: menu_name2 = l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࠫ㓨")
			else: menu_name2 = l1l1l1_l1_ (u"ࠧࡗࡋࡇࡉࡔ࡙ࠧ㓩")
			menu_name2 = l1l1l1_l1_ (u"ࠨ࠮࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㓪")+menu_name2+l1l1l1_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㓫")
		if l1l1l1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㓬") in group: maingroup,subgroup = group.split(l1l1l1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㓭"))
		else: maingroup,subgroup = group,l1l1l1_l1_ (u"ࠬ࠭㓮")
		if not GROUP:
			if maingroup in unique: continue
			unique.append(maingroup)
			if l1l1l1_l1_ (u"࠭ࡒࡂࡐࡇࡓࡒ࠭㓯") in website: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㓰"),menu_name2+maingroup,TYPE,168,l1l1l1_l1_ (u"ࠨࠩ㓱"),l1l1l1_l1_ (u"ࠩ࠴ࠫ㓲"),group,l1l1l1_l1_ (u"ࠪࠫ㓳"),{l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓴"):folder})
			elif l1l1l1_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ㓵") in group: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓶"),menu_name2+maingroup,TYPE,713,l1l1l1_l1_ (u"ࠧࠨ㓷"),l1l1l1_l1_ (u"ࠨ࠳ࠪ㓸"),group,l1l1l1_l1_ (u"ࠩࠪ㓹"),{l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓺"):folder})
			else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓻"),menu_name2+maingroup,TYPE,714,l1l1l1_l1_ (u"ࠬ࠭㓼"),l1l1l1_l1_ (u"࠭࠱ࠨ㓽"),group,l1l1l1_l1_ (u"ࠧࠨ㓾"),{l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㓿"):folder})
		elif l1l1l1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㔀") in group and maingroup==MAINGROUP:
			if subgroup in unique: continue
			unique.append(subgroup)
			if l1l1l1_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࠪ㔁") in website: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㔂"),menu_name2+subgroup,TYPE,168,l1l1l1_l1_ (u"ࠬ࠭㔃"),l1l1l1_l1_ (u"࠭࠱ࠨ㔄"),group,l1l1l1_l1_ (u"ࠧࠨ㔅"),{l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔆"):folder})
			else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔇"),menu_name2+subgroup,TYPE,714,img,l1l1l1_l1_ (u"ࠪ࠵ࠬ㔈"),group,l1l1l1_l1_ (u"ࠫࠬ㔉"),{l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔊"):folder})
	#if l1l1l1_l1_ (u"࠭ࡓࡐࡔࡗࡉࡉ࠭㔋") in TYPE:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not website:
		end = int(PAGE)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(folder,PAGE,TYPE,713,total,GROUP)
	return True
def EPG_ITEMS(folder,url,function):
	HOUR_ = 60*60
	useragent = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ㔌")+folder)
	headers = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㔍"):useragent}
	if not CHECK_TABLES_EXIST(folder,True): return
	timestamp = settings.getSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡥࠧ㔎")+folder)
	if timestamp==l1l1l1_l1_ (u"ࠪࠫ㔏") or now-int(timestamp)>24*HOUR_:
		ok,new_host,new_port = CHECK_ACCOUNT(folder,False)
		if not ok: return
	timediff = int(settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡺࡩ࡮ࡧࡧ࡭࡫࡬࡟ࠨ㔐")+folder))
	server = settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ㔑")+folder)
	username = settings.getSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡶࡵࡨࡶࡳࡧ࡭ࡦࡡࠪ㔒")+folder)
	password = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡲࡤࡷࡸࡽ࡯ࡳࡦࡢࠫ㔓")+folder)
	url_parts = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ㔔"))
	stream_id = url_parts[-1].replace(l1l1l1_l1_ (u"ࠩ࠱ࡸࡸ࠭㔕"),l1l1l1_l1_ (u"ࠪࠫ㔖")).replace(l1l1l1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㔗"),l1l1l1_l1_ (u"ࠬ࠭㔘"))
	if function==l1l1l1_l1_ (u"࠭ࡓࡉࡑࡕࡘࡤࡋࡐࡈࠩ㔙"): url_action = l1l1l1_l1_ (u"ࠧࡨࡧࡷࡣࡸ࡮࡯ࡳࡶࡢࡩࡵ࡭ࠧ㔚")
	else: url_action = l1l1l1_l1_ (u"ࠨࡩࡨࡸࡤࡹࡩ࡮ࡲ࡯ࡩࡤࡪࡡࡵࡣࡢࡸࡦࡨ࡬ࡦࠩ㔛")
	URL_player,URL_get,server,username,password = GET_URL(folder)
	if username==l1l1l1_l1_ (u"ࠩࠪ㔜"): return
	epg_url = URL_player+l1l1l1_l1_ (u"ࠪࠪࡦࡩࡴࡪࡱࡱࡁࠬ㔝")+url_action+l1l1l1_l1_ (u"ࠫࠫࡹࡴࡳࡧࡤࡱࡤ࡯ࡤ࠾ࠩ㔞")+stream_id
	html = OPENURL_CACHED(NO_CACHE,epg_url,l1l1l1_l1_ (u"ࠬ࠭㔟"),headers,l1l1l1_l1_ (u"࠭ࠧ㔠"),l1l1l1_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡋࡐࡈࡡࡌࡘࡊࡓࡓ࠮࠴ࡱࡨࠬ㔡"))
	archive_files = EVAL(l1l1l1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㔢"),html)
	all_epg = archive_files[l1l1l1_l1_ (u"ࠩࡨࡴ࡬ࡥ࡬ࡪࡵࡷ࡭ࡳ࡭ࡳࠨ㔣")]
	epg_items = []
	if function in [l1l1l1_l1_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬ㔤"),l1l1l1_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㔥")]:
		for dict in all_epg:
			if dict[l1l1l1_l1_ (u"ࠬ࡮ࡡࡴࡡࡤࡶࡨ࡮ࡩࡷࡧࠪ㔦")]==1:
				epg_items.append(dict)
				if function in [l1l1l1_l1_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ㔧")]: break
		if not epg_items: return
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㔨"),menu_name+l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠห้๋ไโษอࠤฬ๊ร้ๆํࠤอํะ่ࠢส่็อฦๆหࠣๆิࠦไศࠢอ฽๊๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ㔩"),l1l1l1_l1_ (u"ࠩࠪ㔪"),9999)
		if function in [l1l1l1_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭㔫")]:
			length_hours = 2
			length_secs = length_hours*HOUR_
			epg_items = []
			initial_timestamp = int(int(dict[l1l1l1_l1_ (u"ࠫࡸࡺࡡࡳࡶࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭㔬")])/length_secs)*length_secs
			finish_timestamp = now+length_secs
			videos_count = int((finish_timestamp-initial_timestamp)/HOUR_)
			for count in range(videos_count):
				if count>=6:
					if count%length_hours!=0: continue
					duration = length_secs
				else: duration = length_secs//2
				start_timestamp = initial_timestamp+count*HOUR_
				dict = {}
				dict[l1l1l1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㔭")] = l1l1l1_l1_ (u"࠭ࠧ㔮")
				struct = time.localtime(start_timestamp-timediff-HOUR_)
				dict[l1l1l1_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭㔯")] = time.strftime(l1l1l1_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬ㔰"),struct)
				dict[l1l1l1_l1_ (u"ࠩࡶࡸࡦࡸࡴࡠࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ㔱")] = str(start_timestamp)
				dict[l1l1l1_l1_ (u"ࠪࡷࡹࡵࡰࡠࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ㔲")] = str(start_timestamp+duration)
				epg_items.append(dict)
	elif function in [l1l1l1_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ㔳"),l1l1l1_l1_ (u"ࠬࡌࡕࡍࡎࡢࡉࡕࡍࠧ㔴")]: epg_items = all_epg
	if function==l1l1l1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ㔵") and len(epg_items)>0:
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㔶"),menu_name+l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋ีํࠠใษษ้ฮࠦศาษ่ะࠥอไใ่๋หฯࠦࠨอั๋่ࠥ็โุࠫใ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㔷"),l1l1l1_l1_ (u"ࠩࠪ㔸"),9999)
	epg_list = []
	img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡏࡣࡰࡰࠪ㔹"))
	for dict in epg_items:
		title = base64.b64decode(dict[l1l1l1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㔺")])
		if kodi_version>18.99: title = title.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㔻"))
		start_timestamp = int(dict[l1l1l1_l1_ (u"࠭ࡳࡵࡣࡵࡸࡤࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ㔼")])
		stop_timestamp = int(dict[l1l1l1_l1_ (u"ࠧࡴࡶࡲࡴࡤࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ㔽")])
		duration_minutes = str(int((stop_timestamp-start_timestamp+59)/60))
		start_string = dict[l1l1l1_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ㔾")].replace(l1l1l1_l1_ (u"ࠩࠣࠫ㔿"),l1l1l1_l1_ (u"ࠪ࠾ࠬ㕀"))
		struct = time.localtime(start_timestamp-HOUR_)
		time_string = time.strftime(l1l1l1_l1_ (u"ࠫࠪࡎ࠺ࠦࡏࠪ㕁"),struct)
		english_dayname = time.strftime(l1l1l1_l1_ (u"ࠬࠫࡡࠨ㕂"),struct)
		if function==l1l1l1_l1_ (u"࠭ࡓࡉࡑࡕࡘࡤࡋࡐࡈࠩ㕃"): title = l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㕄")+time_string+l1l1l1_l1_ (u"ࠨࠢใࠤࠬ㕅")+title+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㕆")
		elif function==l1l1l1_l1_ (u"ࠪࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭㕇"): title = english_dayname+l1l1l1_l1_ (u"ࠫࠥ࠭㕈")+time_string+l1l1l1_l1_ (u"ࠬࠦࠨࠨ㕉")+duration_minutes+l1l1l1_l1_ (u"࠭࡭ࡪࡰࠬࠫ㕊")
		else: title = english_dayname+l1l1l1_l1_ (u"ࠧࠡࠩ㕋")+time_string+l1l1l1_l1_ (u"ࠨࠢࠫࠫ㕌")+duration_minutes+l1l1l1_l1_ (u"ࠩࡰ࡭ࡳ࠯ࠠࠡࠢࠪ㕍")+title+l1l1l1_l1_ (u"ࠪࠤๅ࠭㕎")
		if function in [l1l1l1_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭㕏"),l1l1l1_l1_ (u"ࠬࡌࡕࡍࡎࡢࡉࡕࡍࠧ㕐"),l1l1l1_l1_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ㕑")]:
			timeshift_url = server+l1l1l1_l1_ (u"ࠧ࠰ࡶ࡬ࡱࡪࡹࡨࡪࡨࡷ࠳ࠬ㕒")+username+l1l1l1_l1_ (u"ࠨ࠱ࠪ㕓")+password+l1l1l1_l1_ (u"ࠩ࠲ࠫ㕔")+duration_minutes+l1l1l1_l1_ (u"ࠪ࠳ࠬ㕕")+start_string+l1l1l1_l1_ (u"ࠫ࠴࠭㕖")+stream_id+l1l1l1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㕗")
			if function==l1l1l1_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ㕘"): addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㕙"),menu_name+title,timeshift_url,9999,img,l1l1l1_l1_ (u"ࠨࠩ㕚"),l1l1l1_l1_ (u"ࠩࠪ㕛"),l1l1l1_l1_ (u"ࠪࠫ㕜"),{l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕝"):folder})
			else: addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㕞"),menu_name+title,timeshift_url,235,img,l1l1l1_l1_ (u"࠭ࠧ㕟"),l1l1l1_l1_ (u"ࠧࠨ㕠"),l1l1l1_l1_ (u"ࠨࠩ㕡"),{l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕢"):folder})
		epg_list.append(title)
	if function==l1l1l1_l1_ (u"ࠪࡗࡍࡕࡒࡕࡡࡈࡔࡌ࠭㕣") and epg_list: selection = DIALOG_CONTEXTMENU(epg_list)
	return epg_list
def USE_FASTER_SERVER(folder):
	if not CHECK_TABLES_EXIST(folder,True): return
	server,pingTime_newserver,pingTime_orgserver = l1l1l1_l1_ (u"ࠫࠬ㕤"),0,0
	succeeded,new_host,new_port = CHECK_ACCOUNT(folder,False)
	if succeeded:
		new_host_ip = DNS_RESOLVER(new_host)
		pingTime_newserver = PING(new_host_ip[0],int(new_port))
		dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ㕥"))
		groups = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㕦"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭㕧"))
		streams = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㕨"),l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㕩"),groups[1])
		url = streams[0][2]
		org_server = re.findall(l1l1l1_l1_ (u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭㕪"),url,re.DOTALL)
		org_server = org_server[0]
		if l1l1l1_l1_ (u"ࠫ࠿࠭㕫") in org_server: org_host,org_port = org_server.split(l1l1l1_l1_ (u"ࠬࡀࠧ㕬"))
		else: org_host,org_port = org_server,l1l1l1_l1_ (u"࠭࠸࠱ࠩ㕭")
		org_host_ip = DNS_RESOLVER(org_host)
		pingTime_orgserver = PING(org_host_ip[0],int(org_port))
	if pingTime_newserver and pingTime_orgserver:
		message = l1l1l1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢสุ่๐ัโำࠣห้ษีๅ์ࠣว๊ࠦวๅีํีๆืࠠศๆฦืึ฿ࠠภࠣࠤࠫ㕮")
		message += l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㕯")+l1l1l1_l1_ (u"๋ࠩๆฯࠦึศศ฼ࠤๆ๐ࠠศๆึ๎ึ็ัࠡษ็วฺ๊๊ࠨ㕰")+l1l1l1_l1_ (u"ࠪࡠࡳ࠭㕱")+str(int(pingTime_orgserver*1000))+l1l1l1_l1_ (u"๋ࠫࠥไ๋ࠢฮห๋๐ษࠨ㕲")
		message += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㕳")+l1l1l1_l1_ (u"่࠭ใฬฺࠣฬฬูࠡใํࠤฬ๊ำ๋ำไีࠥอไษัํ่ࠬ㕴")+l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ㕵")+str(int(pingTime_newserver*1000))+l1l1l1_l1_ (u"ࠨ่่ࠢ๏ࠦหศ่ํอࠬ㕶")
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㕷"),l1l1l1_l1_ (u"ࠪหู้๊าใิࠤฬ๊รึๆํࠫ㕸"),l1l1l1_l1_ (u"ࠫฬ๊ำ๋ำไีࠥอไฤีิ฽ࠬ㕹"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㕺"),message)
		if yes==1 and pingTime_newserver<pingTime_orgserver: server = new_host+l1l1l1_l1_ (u"࠭࠺ࠨ㕻")+new_port
	else: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ㕼"),l1l1l1_l1_ (u"ࠨࠩ㕽"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㕾"),l1l1l1_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำࠥอไิ์ิๅึࠦวๅสา๎้࠭㕿"))
	settings.setSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭㖀")+folder,server)
	return
def PLAY(folder,url,type):
	useragent = settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ㖁")+folder)
	if useragent!=l1l1l1_l1_ (u"࠭ࠧ㖂"): url = url+l1l1l1_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭㖃")+useragent
	#new_server = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩ㖄")+folder)
	#if new_server:
	#	old_server = re.findall(l1l1l1_l1_ (u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬ㖅"),url,re.DOTALL)
	#	url = url.replace(old_server[0],new_server)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(folder):
	DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ㖆"),l1l1l1_l1_ (u"ࠫࠬ㖇"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㖈"),l1l1l1_l1_ (u"࠭สฮาํี๋ࠥ็ๆ๋๋ࠢฬ๋ࠠอัสࠤ࠳๊ࠦาฮ์ࠤ฾ีๅࠡฬ฽๎๏ื็ࠡวำห้ࠥๆหࠢ็หࠥะูาใ้ࠣฬࠦ็้ࠢ࠱ࠤࠥ๎ูะ็ࠣฮ฿๐๊า้ࠣษ้อฺ่ࠠาࠤฬ๊ึา๊ิอࠥอไใื๋ํࠥ࠴ࠠศๆะหัฯࠠๅ้ำหࠥอไห฼ํ๎ึࠦ็๋ࠢไๆ฼ࠦลัษࠣ฻้ฮสࠡ็้็ฺࠥัไหࠣไࡒ࠹ࡕࠡล้ࠤฯ฿ๅๅ๊ࠢิฬࠦวๅฬ฽๎๏ืࠠ࠯๋ࠢๅ็฽ฺ่ࠠา้ฬࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡓ࠳ࡖࠢอัฯอฬࠡโࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦฮศืࠪ㖉"))
	useragent = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㖊")+folder)
	answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㖋"),l1l1l1_l1_ (u"ࠩสืฯิฯศ็ࠣห้ษีๅ์ࠪ㖌"),l1l1l1_l1_ (u"ࠪฮ฾ี๊ๅࠢส่็ี๊ๆࠩ㖍"),useragent,l1l1l1_l1_ (u"ࠫ์ึว้๋ࠡࠤๅ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠢสู่๊สฯั่ࠤาอไ๋ษ้ࠣ฾ࠦเࡎ࠵ࡘࠤฬ๊ะ๋ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฻า๎้ํࠠฤ็ࠣฮึ๐ฯࠡว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤฬ๊สฬสํฮࠥอไฤื็๎ࠥ๎วๅฬํࠤฯ่ั๋สสࠤฯ์วิสࠣะ๊๐ูࠡึิ็ฬะࠠแࡏ࠶࡙ࠥลࠡࠨ㖎"))
	if answer==1: useragent = OPEN_KEYBOARD(l1l1l1_l1_ (u"ࠬษใหสࠣไࡒ࠹ࡕࠡࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠥาฯ๋ัࠪ㖏"),useragent,True)
	else: useragent = l1l1l1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ㖐")
	if useragent==l1l1l1_l1_ (u"ࠧࠡࠩ㖑"):
		DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ㖒"),l1l1l1_l1_ (u"ࠩࠪ㖓"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㖔"),l1l1l1_l1_ (u"ࠫ฿๐ัࠡ็ึ้ํำࠠฤีอาิอๅࠡใิห฿ࠦไ้ฯา๋ࠥษ่ࠡ฻าอࠥ็ัศ฼สฮ๊่ࠥฮั๊หࠥ࠴࠮࠯ࠢํะอࠦลๆษࠣฮึ้็ࠡใสี฿ࠦสๆษ่หࠥษ่ࠡวูหๆฯࠠฮำไࠤศ๎ࠠฤ์ุࠣ๏ࠦยฯำ้ࠣ฾ํวࠨ㖕"))
		return
	answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㖖"),l1l1l1_l1_ (u"࠭ࠧ㖗"),l1l1l1_l1_ (u"ࠧࠨ㖘"),useragent,l1l1l1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็๋ࠣีอࠠแࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠥฮฯๅษ้๋ࠣࠦࠠศๆๅำ๏๋ࠠภࠩ㖙"))
	if answer!=1:
		DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㖚"),l1l1l1_l1_ (u"ࠪࠫ㖛"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㖜"),l1l1l1_l1_ (u"ࠬะๅࠡษ็ษ้เวยࠩ㖝"))
		return
	settings.setSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ㖞")+folder,useragent)
	l1ll111ll1l_l1_(folder)
	return
def GET_URL(folder,iptvURL=l1l1l1_l1_ (u"ࠧࠨ㖟")):
	if not iptvURL: iptvURL = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡸࡶࡱࡥࠧ㖠")+folder)
	server = SERVER(iptvURL,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭㖡"))
	username = re.findall(l1l1l1_l1_ (u"ࠪࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠮࠮ࠫࡁࠬࠪࠬ㖢"),iptvURL+l1l1l1_l1_ (u"ࠫࠫ࠭㖣"),re.DOTALL)
	password = re.findall(l1l1l1_l1_ (u"ࠬࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ㖤"),iptvURL+l1l1l1_l1_ (u"࠭ࠦࠨ㖥"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ㖦"),l1l1l1_l1_ (u"ࠨࠩ㖧"),l1l1l1_l1_ (u"ࠩไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠬ㖨"),l1l1l1_l1_ (u"ࠪีฬฮืࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠศๆำ๎่ࠥๅหࠢส๊ฯࠦศฦุสๅฯํࠠฦๆ์ࠤฬ๊ศา่ส้ัࠦไศࠢํ฽๊๊ࠠฤ๊ࠣห้ืวษูࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦรั้หࠤส๊้ࠡไสส๊ฯࠠศึอีฬ้ࠠแࡋࡓࡘ่࡛ࠦใ็ࠣฬส฼วโหࠣีฬฮืࠡโࡌࡔ࡙࡜ࠠอัํำࠥษ่ࠡไ่ࠤอหีๅษะࠤฬ๊ัศสฺࠤฬ๊โะ์่ࠫ㖩"))
		return l1l1l1_l1_ (u"ࠫࠬ㖪"),l1l1l1_l1_ (u"ࠬ࠭㖫"),l1l1l1_l1_ (u"࠭ࠧ㖬"),l1l1l1_l1_ (u"ࠧࠨ㖭"),l1l1l1_l1_ (u"ࠨࠩ㖮")
	username = username[0]
	password = password[0]
	URL_player = server+l1l1l1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹࡦࡴࡢࡥࡵ࡯࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧ㖯")+username+l1l1l1_l1_ (u"ࠪࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠧ㖰")+password
	URL_get = server+l1l1l1_l1_ (u"ࠫ࠴࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩ㖱")+username+l1l1l1_l1_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩ㖲")+password+l1l1l1_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂࡳ࠳ࡶࡡࡳࡰࡺࡹࠧ㖳")
	return URL_player,URL_get,server,username,password
def GET_FILENAME(folder,URL=l1l1l1_l1_ (u"ࠧࠨ㖴")):
	fullfile = URL.replace(l1l1l1_l1_ (u"ࠨ࠱ࠪ㖵"),l1l1l1_l1_ (u"ࠩࡢࠫ㖶")).replace(l1l1l1_l1_ (u"ࠪ࠾ࠬ㖷"),l1l1l1_l1_ (u"ࠫࡤ࠭㖸")).replace(l1l1l1_l1_ (u"ࠬ࠴ࠧ㖹"),l1l1l1_l1_ (u"࠭࡟ࠨ㖺"))
	fullfile = fullfile.replace(l1l1l1_l1_ (u"ࠧࡀࠩ㖻"),l1l1l1_l1_ (u"ࠨࡡࠪ㖼")).replace(l1l1l1_l1_ (u"ࠩࡀࠫ㖽"),l1l1l1_l1_ (u"ࠪࡣࠬ㖾")).replace(l1l1l1_l1_ (u"ࠫࠫ࠭㖿"),l1l1l1_l1_ (u"ࠬࡥࠧ㗀"))
	fullfile = os.path.join(addoncachefolder,fullfile).strip(l1l1l1_l1_ (u"࠭࠮࡮࠵ࡸࠫ㗁"))+l1l1l1_l1_ (u"ࠧ࠯࡯࠶ࡹࠬ㗂")
	return fullfile
def ADD_ACCOUNT(folder,l11l1l11_l1_):
	header_message = l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㗃")
	if l11l1l11_l1_: header_message = l1l1l1_l1_ (u"ࠩศฺฬ็ษ๊ࠡอ฾๏๐ัࠡำสฬ฼ࠦࠧ㗄")+text_numbers[int(l11l1l11_l1_)]
	answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㗅"),l1l1l1_l1_ (u"ࠫࠬ㗆"),l1l1l1_l1_ (u"ࠬ࠭㗇"),header_message,l1l1l1_l1_ (u"࠭็ัษࠣห้าาย่๊ࠢࠥอไษำ้ห๊า๋ࠠฯอหัࠦัศสฺࠤๆ๐ฯ๋๊๊หฯࠦๅ็ࠢส่ส์สา่อࠤศ๎ࠠฤึอีฬ้ࠠๆัไ์฾ࠦๅ็ࠢสู่ืใศฬࠣห้ะ๊ࠡฬห๎฾ํ้ࠠษ็ีฬฮืࠡ็้ࠤ๋๎ูࠡ࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࡭࠴ࡷ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡡࡴ࡜࡯๋๋ࠢีอࠠๆอส่๊ࠥสุ้ํัฺࠥใๅ๊ࠢิฬࠦวๅำสฬ฼ࠦ࡜࡯ࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡵࡺࡶ࠮ࡱࡵ࡫࠳࡭ࡩࡵࡪࡸࡦ࠳࡯࡯࠰࡫ࡳࡸࡻ࠵࡬ࡢࡰࡪࡹࡦ࡭ࡥࡴ࠱ࡤࡶࡦ࠴࡭࠴ࡷࠣࡠࡳࠦ็ๅࠢอี๏ีࠠฦุสๅฮࠦร้ࠢอ฾๏๐ัࠡล๋ࠤู๊อࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠨ㗈"))
	if answer!=1: return
	old_URL = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ㗉")+folder+l1l1l1_l1_ (u"ࠨࡡࠪ㗊")+l11l1l11_l1_)
	getnew = True
	if old_URL:
		answer = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㗋"),l1l1l1_l1_ (u"ࠪ็ฯอศสࠢฯำ๏ีࠧ㗌"),l1l1l1_l1_ (u"ࠫฯ฿ฯ๋ๆࠣห้่ฯ๋็ࠪ㗍"),l1l1l1_l1_ (u"๋ࠬำฮࠢส่็ี๊ๆࠩ㗎"),l1l1l1_l1_ (u"࠭วๅำสฬ฼ࠦวๅฯส่๏ࠦ็้࠼ࠪ㗏"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㗐")+old_URL+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㗑")+l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴ่ࠠาสࠤ์๎ࠠาษห฻ࠥๆࡍ࠴ࡗࠣห้๋ำอๆࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦสฺัํ่์ࠦรๆࠢอี๏ีࠠไฬสฬฮࠦัศสฺࠤัี๊ะࠢยࠥࠬ㗒"))
		if answer==-1: return
		elif answer==0: old_URL = l1l1l1_l1_ (u"ࠪࠫ㗓")
		elif answer==2:
			answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㗔"),l1l1l1_l1_ (u"ࠬ࠭㗕"),l1l1l1_l1_ (u"࠭ࠧ㗖"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㗗"),l1l1l1_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦวๅำสฬ฼ࠦวๅ็ึะ้ࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧ㗘"))
			if answer in [-1,0]: return
			DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㗙"),l1l1l1_l1_ (u"ࠪࠫ㗚"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㗛"),l1l1l1_l1_ (u"ࠬะๅࠡ็ึัࠥอไาษห฻ࠬ㗜"))
			getnew = False
			new_URL = l1l1l1_l1_ (u"࠭ࠧ㗝")
	if getnew:
		new_URL = OPEN_KEYBOARD(l1l1l1_l1_ (u"ࠧศๅอฬࠥืวษูࠣไࡒ࠹ࡕࠡๅส้้อࠧ㗞"),old_URL)
		new_URL = new_URL.strip(l1l1l1_l1_ (u"ࠨࠢࠪ㗟"))
		if not new_URL:
			answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㗠"),l1l1l1_l1_ (u"ࠪࠫ㗡"),l1l1l1_l1_ (u"ࠫࠬ㗢"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㗣"),l1l1l1_l1_ (u"࠭ไใัࠣๆ๊ะࠠษวาาฬ๊ࠠาษห฻ࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฬ๊ัศสฺࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢยࠥࠬ㗤"))
			if answer in [-1,0]: return
			DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ㗥"),l1l1l1_l1_ (u"ࠨࠩ㗦"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㗧"),l1l1l1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣห้ืวษูࠪ㗨"))
		else:
			#URL_player,URL_get,server,username,password = GET_URL(folder)
			#if not username: return
			message = l1l1l1_l1_ (u"ࠫ์ึ็ࠡษ็้฾๊่ๆษอࠤฯ๋ࠠฤะำ๋ฬࠦๅ็ࠢิหอ฽ࠠแࡏ࠶࡙ࠥอไั์ࠣห๋ะࠠไฬหฮ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊หࠥลࠡ࡝ࡰࠪ㗩")
			#message += l1l1l1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㗪")+server+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ฺ่๋ห๋ࠦวๅีํีๆื࠺ࠡࠩ㗫")
			#message += l1l1l1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㗬")+username+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟สื๊ࠦวๅ็ึฮำีๅ࠻ࠢࠪ㗭")
			#message += l1l1l1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㗮")+password+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ่๊ๅสࠢสุ่ื࠺ࠡࠩ㗯")
			answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࠬ㗰"),l1l1l1_l1_ (u"ࠬ࠭㗱"),l1l1l1_l1_ (u"࠭ࠧ㗲"),l1l1l1_l1_ (u"ࠧศๆิหอ฽ࠠศๆฯำ๏ี่๊ࠠ࠽ࠫ㗳"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㗴")+new_URL+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㗵")+l1l1l1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㗶")+message)
			if answer!=1:
				DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ㗷"),l1l1l1_l1_ (u"ࠬ࠭㗸"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㗹"),l1l1l1_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ㗺"))
				return
	settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭㗻")+folder+l1l1l1_l1_ (u"ࠩࡢࠫ㗼")+l11l1l11_l1_,new_URL)
	#settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࡟ࠨ㗽")+folder,l1l1l1_l1_ (u"ࠫࠬ㗾"))
	#settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡴࡪ࡯ࡨࡨ࡮࡬ࡦࡠࠩ㗿")+folder,l1l1l1_l1_ (u"࠭ࠧ㘀"))
	useragent = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㘁")+folder)
	if not useragent: settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ㘂")+folder,l1l1l1_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ㘃"))
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㘄"),l1l1l1_l1_ (u"ࠫࠬ㘅"),l1l1l1_l1_ (u"ࠬ࠭㘆"),l1l1l1_l1_ (u"࠭ࠧ㘇"),new_URL+l1l1l1_l1_ (u"ࠧ࡝ࡰ࡟ࡲฯ๋ࠠห฼ํีࠥืวษูࠣหูะัศๅࠣไࡒ࠹ࡕࠡว็ํࠥํะศࠢส่ึอศุࠢส่ัี๊ะࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤ์ึวࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠨ㘈"))
	if yes==1: ok,new_host,new_port = CHECK_ACCOUNT(folder,True)
	l1ll111ll1l_l1_(folder)
	return
def READ_ALL_LINES(lines,live_epg_channels,live_archived_channels,pDialog,length,jj,URL_get):
	streams,ignored_streams = [],[]
	vod_types = [l1l1l1_l1_ (u"ࠨ࠰ࡤࡺ࡮࠭㘉"),l1l1l1_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ㘊"),l1l1l1_l1_ (u"ࠪ࠲ࡲࡱࡶࠨ㘋"),l1l1l1_l1_ (u"ࠫ࠳࡬࡬ࡷࠩ㘌"),l1l1l1_l1_ (u"ࠬ࠴࡭ࡱ࠵ࠪ㘍"),l1l1l1_l1_ (u"࠭࠮ࡸࡧࡥࡱࠬ㘎")]
	for line in lines:
		if jj%473==0:
			PROGRESS_UPDATE(pDialog,40+int(10*jj/length),l1l1l1_l1_ (u"ࠧใำสลฮࠦวๅใํำ๏๎็ศฬࠪ㘏"),l1l1l1_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢิๆ๊ࡀ࠭ࠨ㘐"),str(jj)+l1l1l1_l1_ (u"ࠩࠣ࠳ࠥ࠭㘑")+str(length))
			if pDialog.iscanceled(): return None,None,None
		if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ㘒") in line:
			line,url = line.rsplit(l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ㘓"),1)
			url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ㘔")+url
		elif l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㘕") in line:
			line,url = line.rsplit(l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ㘖"),1)
			url = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ㘗")+url
		elif l1l1l1_l1_ (u"ࠩࡵࡸࡲࡶ࠺ࠨ㘘") in line:
			line,url = line.rsplit(l1l1l1_l1_ (u"ࠪࡶࡹࡳࡰ࠻ࠩ㘙"),1)
			url = l1l1l1_l1_ (u"ࠫࡷࡺ࡭ࡱ࠼ࠪ㘚")+url
		else:
			ignored_streams.append({l1l1l1_l1_ (u"ࠬࡲࡩ࡯ࡧࠪ㘛"):line})
			continue
		dict1,context,group,title,type,is_vod_url = {},l1l1l1_l1_ (u"࠭ࠧ㘜"),l1l1l1_l1_ (u"ࠧࠨ㘝"),l1l1l1_l1_ (u"ࠨࠩ㘞"),l1l1l1_l1_ (u"ࠩࠪ㘟"),False
		try:
			line,title = line.rsplit(l1l1l1_l1_ (u"ࠪࠦ࠱࠭㘠"),1)
			line = line+l1l1l1_l1_ (u"ࠫࠧ࠭㘡")
		except:
			try: line,title = line.rsplit(l1l1l1_l1_ (u"ࠬ࠷ࠬࠨ㘢"),1)
			except: title = l1l1l1_l1_ (u"࠭ࠧ㘣")
		dict1[l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ㘤")] = url
		params = re.findall(l1l1l1_l1_ (u"ࠨࠢࠫ࠲࠯ࡅࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㘥"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l1l1l1_l1_ (u"ࠩࠥࠫ㘦"),l1l1l1_l1_ (u"ࠪࠫ㘧")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭㘨"))
			dict1[key] = value.strip(l1l1l1_l1_ (u"ࠬࠦࠧ㘩"))
		keys = list(dict1.keys())
		if not title:
			if l1l1l1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㘪") in keys and dict1[l1l1l1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㘫")]: title = dict1[l1l1l1_l1_ (u"ࠨࡰࡤࡱࡪ࠭㘬")]
		dict1[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㘭")] = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬ㘮")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠧ㘯"),l1l1l1_l1_ (u"ࠬࠦࠧ㘰")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ㘱"),l1l1l1_l1_ (u"ࠧࠡࠩ㘲"))
		if l1l1l1_l1_ (u"ࠨ࡮ࡲ࡫ࡴ࠭㘳") in keys:
			dict1[l1l1l1_l1_ (u"ࠩ࡬ࡱ࡬࠭㘴")] = dict1[l1l1l1_l1_ (u"ࠪࡰࡴ࡭࡯ࠨ㘵")]
			del dict1[l1l1l1_l1_ (u"ࠫࡱࡵࡧࡰࠩ㘶")]
		else: dict1[l1l1l1_l1_ (u"ࠬ࡯࡭ࡨࠩ㘷")] = l1l1l1_l1_ (u"࠭ࠧ㘸")
		if l1l1l1_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭㘹") in keys and dict1[l1l1l1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㘺")]: group = dict1[l1l1l1_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ㘻")]
		if any(value in url.lower() for value in vod_types): is_vod_url = True
		if is_vod_url or l1l1l1_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㘼") in group or l1l1l1_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ㘽") in group:
			type = l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࠩ㘾")
			if l1l1l1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㘿") in group: type = type+l1l1l1_l1_ (u"ࠧࡠࡕࡈࡖࡎࡋࡓࠨ㙀")
			elif l1l1l1_l1_ (u"ࠨࡡࡢࡑࡔ࡜ࡉࡆࡕࡢࡣࠬ㙁") in group: type = type+l1l1l1_l1_ (u"ࠩࡢࡑࡔ࡜ࡉࡆࡕࠪ㙂")
			else: type = type+l1l1l1_l1_ (u"ࠪࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬ㙃")
			group = group.replace(l1l1l1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㙄"),l1l1l1_l1_ (u"ࠬ࠭㙅")).replace(l1l1l1_l1_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ㙆"),l1l1l1_l1_ (u"ࠧࠨ㙇"))
		else:
			type = l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㙈")
			if title in live_epg_channels: context = context+l1l1l1_l1_ (u"ࠩࡢࡉࡕࡍࠧ㙉")
			if title in live_archived_channels: context = context+l1l1l1_l1_ (u"ࠪࡣࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭㙊")
			if not group: type = type+l1l1l1_l1_ (u"ࠫࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭㙋")
			else: type = type+context
		group = group.strip(l1l1l1_l1_ (u"ࠬࠦࠧ㙌")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ㙍"),l1l1l1_l1_ (u"ࠧࠡࠩ㙎")).replace(l1l1l1_l1_ (u"ࠨࠢࠣࠫ㙏"),l1l1l1_l1_ (u"ࠩࠣࠫ㙐"))
		if l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࠩ㙑") in type: group = l1l1l1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡏࡍ࡛ࡋ࡟ࡠࠣࠤࠫ㙒")
		elif l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪ㙓") in type: group = l1l1l1_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣ࡛ࡕࡄࡠࡡࠤࠥࠬ㙔")
		elif l1l1l1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࠫ㙕") in type:
			series_title = re.findall(l1l1l1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠ࡜ࡕࡶࡡࡡࡪࠫࠡ࠭࡞ࡉࡪࡣ࡜ࡥ࠭ࠪ㙖"),dict1[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㙗")],re.DOTALL)
			if series_title: series_title = series_title[0]
			else: series_title = l1l1l1_l1_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡕࡈࡖࡎࡋࡓࡠࡡࠤࠥࠬ㙘")
			group = group+l1l1l1_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㙙")+series_title
		id2 = l1l1l1_l1_ (u"ࠬ࠭㙚")
		if l1l1l1_l1_ (u"࠭ࡩࡥࠩ㙛") in keys:
			id2 = dict1[l1l1l1_l1_ (u"ࠧࡪࡦࠪ㙜")]
			del dict1[l1l1l1_l1_ (u"ࠨ࡫ࡧࠫ㙝")]
		if l1l1l1_l1_ (u"ࠩࡌࡈࠬ㙞") in keys:
			id2 = dict1[l1l1l1_l1_ (u"ࠪࡍࡉ࠭㙟")]
			del dict1[l1l1l1_l1_ (u"ࠫࡎࡊࠧ㙠")]
		if l1l1l1_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡳࡷ࡭ࠧ㙡") in URL_get and l1l1l1_l1_ (u"࠭࠮ࠨ㙢") in id2:
			id2 = id2.rsplit(l1l1l1_l1_ (u"ࠧ࠯ࠩ㙣"),1)[1]
			id2 = l1l1l1_l1_ (u"ࠨࡾࠪ㙤")+id2.upper()+l1l1l1_l1_ (u"ࠩࡿࠤࠬ㙥")
		if l1l1l1_l1_ (u"ࠪࡲࡦࡳࡥࠨ㙦") in keys: del dict1[l1l1l1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㙧")]
		title = id2+dict1[l1l1l1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㙨")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		country,title = SPLIT_NAME(title)
		dict1[l1l1l1_l1_ (u"࠭ࡴࡺࡲࡨࠫ㙩")] = type
		dict1[l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㙪")] = context
		dict1[l1l1l1_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㙫")] = group.upper()
		dict1[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㙬")] = title.upper()
		try: dict1[l1l1l1_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㙭")] = COUNTRY_NAME[country.upper()]
		except: dict1[l1l1l1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㙮")] = country.upper()
		dict1[l1l1l1_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ㙯")] = language.upper()
		streams.append(dict1)
		jj += 1
	return streams,jj,ignored_streams
def CLEAN_NAME(title):
	title = title.replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ㙰"),l1l1l1_l1_ (u"ࠧࠡࠩ㙱")).replace(l1l1l1_l1_ (u"ࠨࠢࠣࠫ㙲"),l1l1l1_l1_ (u"ࠩࠣࠫ㙳")).replace(l1l1l1_l1_ (u"ࠪࠤࠥ࠭㙴"),l1l1l1_l1_ (u"ࠫࠥ࠭㙵"))
	title = title.replace(l1l1l1_l1_ (u"ࠬࢂࡼࠨ㙶"),l1l1l1_l1_ (u"࠭ࡼࠨ㙷")).replace(l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫ㙸"),l1l1l1_l1_ (u"ࠨ࠼ࠪ㙹")).replace(l1l1l1_l1_ (u"ࠩ࠰࠱ࠬ㙺"),l1l1l1_l1_ (u"ࠪ࠱ࠬ㙻"))
	title = title.replace(l1l1l1_l1_ (u"ࠫࡠࡡࠧ㙼"),l1l1l1_l1_ (u"ࠬࡡࠧ㙽")).replace(l1l1l1_l1_ (u"࠭࡝࡞ࠩ㙾"),l1l1l1_l1_ (u"ࠧ࡞ࠩ㙿"))
	title = title.replace(l1l1l1_l1_ (u"ࠨࠪࠫࠫ㚀"),l1l1l1_l1_ (u"ࠩࠫࠫ㚁")).replace(l1l1l1_l1_ (u"ࠪ࠭࠮࠭㚂"),l1l1l1_l1_ (u"ࠫ࠮࠭㚃"))
	title = title.replace(l1l1l1_l1_ (u"ࠬࡂ࠼ࠨ㚄"),l1l1l1_l1_ (u"࠭࠼ࠨ㚅")).replace(l1l1l1_l1_ (u"ࠧ࠿ࡀࠪ㚆"),l1l1l1_l1_ (u"ࠨࡀࠪ㚇"))
	title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ㚈"))
	return title
def CREATE_GROUPED_STREAMS(streams_not_sorted,pDialog,l11l1l11_l1_):
	grouped_streams = {}
	for type1 in UNIQUE_TYPES: grouped_streams[type1+l1l1l1_l1_ (u"ࠪࡣࠬ㚉")+l11l1l11_l1_] = []
	length = len(streams_not_sorted)
	text3 = str(length)
	jj = 0
	ignored_streams = []
	for dict1 in streams_not_sorted:
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,50+int(5*jj/length),l1l1l1_l1_ (u"ࠫฯ฻ๆ๋ใࠣห้็๊ะ์๋๋ฬะࠠศๆ฽๎ึࠦๅาฬหอࠬ㚊"),l1l1l1_l1_ (u"ࠬอไโ์า๎ํࠦัใ็࠽࠱ࠬ㚋"),str(jj)+l1l1l1_l1_ (u"࠭ࠠ࠰ࠢࠪ㚌")+text3)
			if pDialog.iscanceled(): return None,None
		group,context,title,url,img = dict1[l1l1l1_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭㚍")],dict1[l1l1l1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ㚎")],dict1[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㚏")],dict1[l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ㚐")],dict1[l1l1l1_l1_ (u"ࠫ࡮ࡳࡧࠨ㚑")]
		country,language,type1 = dict1[l1l1l1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㚒")],dict1[l1l1l1_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ㚓")],dict1[l1l1l1_l1_ (u"ࠧࡵࡻࡳࡩࠬ㚔")]
		tuple2 = (group,context,title,url,img)
		fail = False
		if l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㚕") in type1:
			if l1l1l1_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ㚖") in type1: grouped_streams[l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ㚗")+l11l1l11_l1_].append(tuple2)
			elif l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆࠩ㚘") in type1: grouped_streams[l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ㚙")+l11l1l11_l1_].append(tuple2)
			else: fail = True
			grouped_streams[l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࠨ㚚")+l11l1l11_l1_].append(tuple2)
		elif l1l1l1_l1_ (u"ࠧࡗࡑࡇࠫ㚛") in type1:
			if l1l1l1_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ㚜") in type1: grouped_streams[l1l1l1_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ㚝")+l11l1l11_l1_].append(tuple2)
			elif l1l1l1_l1_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪ㚞") in type1: grouped_streams[l1l1l1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ㚟")+l11l1l11_l1_].append(tuple2)
			elif l1l1l1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ㚠") in type1: grouped_streams[l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ㚡")+l11l1l11_l1_].append(tuple2)
			else: fail = True
			grouped_streams[l1l1l1_l1_ (u"ࠧࡗࡑࡇࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࠨ㚢")+l11l1l11_l1_].append(tuple2)
		else: fail = True
		if fail: ignored_streams.append(dict1)
		jj += 1
	streams_sorted = sorted(streams_not_sorted,reverse=False,key=lambda key: key[l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ㚣")].lower())
	del streams_not_sorted
	text3 = str(length)
	jj = 0
	for dict1 in streams_sorted:
		jj += 1
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,55+int(5*jj/length),l1l1l1_l1_ (u"ࠩอู๋๐แࠡษ็ๅ๏ี๊้้สฮࠥอไๆำอฬฮ࠭㚤"),l1l1l1_l1_ (u"ࠪห้็๊ะ์๋ࠤึ่ๅ࠻࠯ࠪ㚥"),str(jj)+l1l1l1_l1_ (u"ࠫࠥ࠵ࠠࠨ㚦")+text3)
			if pDialog.iscanceled(): return None,None
		type1 = dict1[l1l1l1_l1_ (u"ࠬࡺࡹࡱࡧࠪ㚧")]
		group,context,title,url,img = dict1[l1l1l1_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ㚨")],dict1[l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㚩")],dict1[l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ㚪")],dict1[l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭㚫")],dict1[l1l1l1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ㚬")]
		country,language = dict1[l1l1l1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㚭")],dict1[l1l1l1_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ㚮")]
		tuple1 = (group,context+l1l1l1_l1_ (u"࠭࡟ࡕࡋࡐࡉࡘࡎࡉࡇࡖࠪ㚯"),title,url,img)
		tuple2 = (group,context,title,url,img)
		tuple3 = (country,context,title,url,img)
		tuple4 = (language,context,title,url,img)
		if l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ㚰") in type1:
			if l1l1l1_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ㚱") in type1: grouped_streams[l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㚲")+l11l1l11_l1_].append(tuple2)
			else: grouped_streams[l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㚳")+l11l1l11_l1_].append(tuple2)
			if l1l1l1_l1_ (u"ࠫࡊࡖࡇࠨ㚴")		in type1: grouped_streams[l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡉࡕࡍ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ㚵")+l11l1l11_l1_].append(tuple2)
			if l1l1l1_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ㚶")	in type1: grouped_streams[l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡇࡒࡄࡊࡌ࡚ࡊࡊ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ㚷")+l11l1l11_l1_].append(tuple2)
			if l1l1l1_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ㚸")	in type1: grouped_streams[l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡕࡋࡐࡉࡘࡎࡉࡇࡖࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ㚹")+l11l1l11_l1_].append(tuple1)
			grouped_streams[l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࡣࠬ㚺")+l11l1l11_l1_].append(tuple3)
			grouped_streams[l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉࡥࠧ㚻")+l11l1l11_l1_].append(tuple4)
		elif l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࠩ㚼") in type1:
			if   l1l1l1_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔࠧ㚽")	in type1: grouped_streams[l1l1l1_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ㚾")+l11l1l11_l1_].append(tuple2)
			elif l1l1l1_l1_ (u"ࠨࡏࡒ࡚ࡎࡋࡓࠨ㚿")	in type1: grouped_streams[l1l1l1_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㛀")+l11l1l11_l1_].append(tuple2)
			elif l1l1l1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ㛁")	in type1: grouped_streams[l1l1l1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㛂")+l11l1l11_l1_].append(tuple2)
			grouped_streams[l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭㛃")+l11l1l11_l1_].append(tuple3)
			grouped_streams[l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㛄")+l11l1l11_l1_].append(tuple4)
	return grouped_streams,ignored_streams
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	lang,sep = l1l1l1_l1_ (u"ࠧࠨ㛅"),l1l1l1_l1_ (u"ࠨࠩ㛆")
	title2 = title
	first = title[:1]
	rest = title[1:]
	if   first==l1l1l1_l1_ (u"ࠩࠫࠫ㛇"): sep = l1l1l1_l1_ (u"ࠪ࠭ࠬ㛈")
	elif first==l1l1l1_l1_ (u"ࠫࡠ࠭㛉"): sep = l1l1l1_l1_ (u"ࠬࡣࠧ㛊")
	elif first==l1l1l1_l1_ (u"࠭࠼ࠨ㛋"): sep = l1l1l1_l1_ (u"ࠧ࠿ࠩ㛌")
	elif first==l1l1l1_l1_ (u"ࠨࡾࠪ㛍"): sep = l1l1l1_l1_ (u"ࠩࡿࠫ㛎")
	if sep and (sep in rest):
		part1,part2 = rest.split(sep,1)
		lang = part1
		title2 = first+part1+sep+l1l1l1_l1_ (u"ࠪࠤࠬ㛏")+part2
	elif title.count(l1l1l1_l1_ (u"ࠫࢁ࠭㛐"))>=2:
		part1,part2 = title.split(l1l1l1_l1_ (u"ࠬࢂࠧ㛑"),1)
		lang = part1
		title2 = part1+l1l1l1_l1_ (u"࠭ࠠࡽࠩ㛒")+part2
	else:
		sep = re.findall(l1l1l1_l1_ (u"ࠧ࡟࡞ࡺࡿ࠷ࢃࠨࠡࡾ࡟࠾ࢁࡢ࠭ࡽ࡞ࡿࢀࡡࡣࡼ࡝ࠫࡿࡠࠨࢂ࡜࠯ࡾ࡟࠰ࢁࡢࠤࡽ࡞ࠪࢀࡡࠧࡼ࡝ࡂࡿࡠࠪࢂ࡜ࠧࡾ࡟࠮ࢁࡢ࡞ࠪࠩ㛓"),title,re.DOTALL)
		if not sep: sep = re.findall(l1l1l1_l1_ (u"ࠨࡠ࡟ࡻࢀ࠹ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ㛔"),title,re.DOTALL)
		if not sep: sep = re.findall(l1l1l1_l1_ (u"ࠩࡡࡠࡼࢁ࠴ࡾࠪࠣࢀࡡࡀࡼ࡝࠯ࡿࡠࢁࢂ࡜࡞ࡾ࡟࠭ࢁࡢࠣࡽ࡞࠱ࢀࡡ࠲ࡼ࡝ࠦࡿࡠࠬࢂ࡜ࠢࡾ࡟ࡄࢁࡢࠥࡽ࡞ࠩࢀࡡ࠰ࡼ࡝ࡠࠬࠫ㛕"),title,re.DOTALL)
		if sep:
			part1,part2 = title.split(sep[0],1)
			lang = part1
			title2 = part1+l1l1l1_l1_ (u"ࠪࠤࠬ㛖")+sep[0]+l1l1l1_l1_ (u"ࠫࠥ࠭㛗")+part2
	title2 = title2.replace(l1l1l1_l1_ (u"ࠬࠦࠠࠡࠩ㛘"),l1l1l1_l1_ (u"࠭ࠠࠨ㛙")).replace(l1l1l1_l1_ (u"ࠧࠡࠢࠪ㛚"),l1l1l1_l1_ (u"ࠨࠢࠪ㛛"))
	lang = lang.replace(l1l1l1_l1_ (u"ࠩࠣࠤࠬ㛜"),l1l1l1_l1_ (u"ࠪࠤࠬ㛝"))
	if not lang: lang = l1l1l1_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡢࠥࠦ࠭㛞")
	lang = lang.strip(l1l1l1_l1_ (u"ࠬࠦࠧ㛟"))
	title2 = title2.strip(l1l1l1_l1_ (u"࠭ࠠࠨ㛠"))
	return lang,title2
def CREATE_STREAMS(folder,l11l1l11_l1_):
	global pDialog,total_saved,finalstreams,menus_counts,all_menus,total_menus_count
	URL_get = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ㛡")+folder+l1l1l1_l1_ (u"ࠨࡡࠪ㛢")+l11l1l11_l1_)
	#URL_player,URL_get,server,username,password = GET_URL(folder)
	#if not username: return
	useragent = settings.getSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭㛣")+folder)
	headers = {l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㛤"):useragent}
	#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㛥"),l1l1l1_l1_ (u"ࠬ࠭㛦"),l1l1l1_l1_ (u"࠭ࠧ㛧"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㛨"),l1l1l1_l1_ (u"ࠨ฻่่๏ฯࠠอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠠใัࠣฮาะวอࠢ฼ำฮࠦฯใษษๆࠥ࠴่ࠠๆࠣฮึ๐ฯࠡล้ࠤฯาไษࠢส่๊๊แศฬࠣห้ศๆࠡมࠪ㛩"))
	#if yes!=1: return
	fullfile = l1ll111l1l1_l1_.replace(l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭㛪"),l1l1l1_l1_ (u"ࠪࡣࠬ㛫")+folder+l1l1l1_l1_ (u"ࠫࡤ࠭㛬")+l11l1l11_l1_)
	if 1:
		ok,new_host,new_port = True,l1l1l1_l1_ (u"ࠬ࠭㛭"),l1l1l1_l1_ (u"࠭ࠧ㛮")
		if not ok:
			DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ㛯"),l1l1l1_l1_ (u"ࠨࠩ㛰"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㛱"),l1l1l1_l1_ (u"ࠪๅู๊ࠠษีะฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢ࠱ࠤศำสๆษ็ࠤึอศุࠢใࡑ࠸࡛ࠠ฻์ิࠤฺำ๊ฮࠢฦ์ࠥอๆหࠢ็้ࠥะำหะาู้ࠥวษไสࠤำีๅสࠢใࡑ࠸࡛ࠠศๆ่์ั๎ฯสࠢหห้ฮั็ษ่ะࠥ࠴࠮ࠡ฻็้ฬࠦร็๊ࠢิ์ࠦวๅะา้ฮࠦสฮฬสะࠥอิหำส็๋ࠥฯโ๊฼ࠤํ฻อ๋ฯࠣ์๏าศࠡล้ࠤฯ฼๊โࠢิหอ฽ࠠศๆสุฯืวไࠢห๊ๆูใࠡๆ็ฬึ์วๆฮࠣฬฬูสฯัส้่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢส่๊๎ฬ้ัฬࠤอํะศࠢส่อืๆศ็ฯࠫ㛲"))
			if not URL_get: LOG_THIS(l1l1l1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㛳"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠬࠦࠠࠡࡐࡲࠤࡒ࠹ࡕࠡࡗࡕࡐࠥ࡬࡯ࡶࡰࡧࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡐ࠷࡚ࠦࡦࡪ࡮ࡨࡷࠬ㛴"))
			else: LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㛵"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡏ࠶࡙ࠥ࡬ࡩ࡭ࡧࡶࠫ㛶"))
			return
		m3u_text = DOWNLOAD_USING_PROGRESSBAR(URL_get,headers)
		if not m3u_text: return
		open(fullfile,l1l1l1_l1_ (u"ࠨࡹࡥࠫ㛷")).write(m3u_text)
	else: m3u_text = open(fullfile,l1l1l1_l1_ (u"ࠩࡵࡦࠬ㛸")).read()
	if kodi_version>18.99: m3u_text = m3u_text.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㛹"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l1l1_l1_ (u"ࠫั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ㛺"),l1l1l1_l1_ (u"ࠬ࠭㛻"))
	m3u_text = m3u_text.replace(l1l1l1_l1_ (u"࠭ࠢࡵࡸࡪ࠱ࠬ㛼"),l1l1l1_l1_ (u"ࠧࠣࠢࡷࡺ࡬࠳ࠧ㛽"))
	m3u_text = m3u_text.replace(l1l1l1_l1_ (u"ࠨ๐ࠪ㛾"),l1l1l1_l1_ (u"ࠩࠪ㛿")).replace(l1l1l1_l1_ (u"ࠪ๏ࠬ㜀"),l1l1l1_l1_ (u"ࠫࠬ㜁")).replace(l1l1l1_l1_ (u"ࠬ๕ࠧ㜂"),l1l1l1_l1_ (u"࠭ࠧ㜃")).replace(l1l1l1_l1_ (u"ࠧํࠩ㜄"),l1l1l1_l1_ (u"ࠨࠩ㜅"))
	m3u_text = m3u_text.replace(l1l1l1_l1_ (u"ࠩ๔ࠫ㜆"),l1l1l1_l1_ (u"ࠪࠫ㜇")).replace(l1l1l1_l1_ (u"ࠫ๕࠭㜈"),l1l1l1_l1_ (u"ࠬ࠭㜉")).replace(l1l1l1_l1_ (u"࠭ํࠨ㜊"),l1l1l1_l1_ (u"ࠧࠨ㜋")).replace(l1l1l1_l1_ (u"ࠨ๔ࠪ㜌"),l1l1l1_l1_ (u"ࠩࠪ㜍"))
	m3u_text = m3u_text.replace(l1l1l1_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠯ࡷ࡭ࡹࡲࡥ࠾ࠩ㜎"),l1l1l1_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡀࠫ㜏"))
	m3u_text = m3u_text.replace(l1l1l1_l1_ (u"ࠬࡺࡶࡨ࠯ࠪ㜐"),l1l1l1_l1_ (u"࠭ࠧ㜑")).replace(l1l1l1_l1_ (u"ࠧ࡝ࡴࠪ㜒"),l1l1l1_l1_ (u"ࠨࠩ㜓")).replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ㜔"),l1l1l1_l1_ (u"ࠪࠫ㜕"))
	live_archived_channels,live_epg_channels = [],[]
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࡒࡕࡓࡌࡘࡅࡔࡕࡢ࡙ࡕࡊࡁࡕࡇࠫࡴࡉ࡯ࡡ࡭ࡱࡪ࠰࠷࠶ࠬࠨฮ็ฬࠥอไๆๆไหฯࠦวๅอส๊ํ๐ษࠨ࠮ࠪห้๋ไโࠢิๆ๊ࡀ࠭ࠨ࠮ࠪ࠵ࠥ࠵ࠠ࠴ࠩࠬࠎࠎ࡯ࡦࠡࡲࡇ࡭ࡦࡲ࡯ࡨ࠰࡬ࡷࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠮ࠩ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࡹࡷࡲࠠ࠾ࠢࡘࡖࡑࡥࡰ࡭ࡣࡼࡩࡷ࠱ࠧࠧࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡤࡹࡥࡳ࡫ࡨࡷࡤࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠩࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࡍࡕ࡚ࡖ࠮ࡅࡕࡉࡆ࡚ࡅࡠࡕࡗࡖࡊࡇࡍࡔ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪ࡫ࡸࡲࡲࠩࠋࠋࡶࡩࡷ࡯ࡥࡴࡡࡪࡶࡴࡻࡰࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡣࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡦࡨࡰࠥ࡮ࡴ࡮࡮ࠍࠍ࡫ࡵࡲࠡࡩࡵࡳࡺࡶࠠࡪࡰࠣࡷࡪࡸࡩࡦࡵࡢ࡫ࡷࡵࡵࡱࡵ࠽ࠎࠎࠏࡧࡳࡱࡸࡴࠥࡃࠠࡨࡴࡲࡹࡵ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠼࠲࠻࠽ࠤ࡬ࡸ࡯ࡶࡲࠣࡁࠥ࡭ࡲࡰࡷࡳ࠲ࡩ࡫ࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭࠳࡫࡮ࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࠊ࡯࠶ࡹࡤࡺࡥࡹࡶࠣࡁࠥࡳ࠳ࡶࡡࡷࡩࡽࡺ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡪࡶࡴࡻࡰ࠾ࠤࠪ࠯࡬ࡸ࡯ࡶࡲ࠮ࠫࠧ࠭ࠬࠨࡩࡵࡳࡺࡶ࠽ࠣࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ࠱ࡧࡳࡱࡸࡴ࠰࠭ࠢࠨࠫࠍࠍࡩ࡫࡬ࠡࡵࡨࡶ࡮࡫ࡳࡠࡩࡵࡳࡺࡶࡳࠋࠋࡓࡖࡔࡍࡒࡆࡕࡖࡣ࡚ࡖࡄࡂࡖࡈࠬࡵࡊࡩࡢ࡮ࡲ࡫࠱࠸࠵࠭ࠩฯ่อࠦวๅ็็ๅฬะࠠศๆฮห๋๎๊สࠩ࠯ࠫฬ๊ๅๅใࠣี็๋࠺࠮ࠩ࠯ࠫ࠷ࠦ࠯ࠡ࠵ࠪ࠭ࠏࠏࡩࡧࠢࡳࡈ࡮ࡧ࡬ࡰࡩ࠱࡭ࡸࡩࡡ࡯ࡥࡨࡰࡪࡪࠨࠪ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࡺࡸ࡬ࠡ࠿࡙ࠣࡗࡒ࡟ࡱ࡮ࡤࡽࡪࡸࠫࠨࠨࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡥࡶࡰࡦࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡋࡓࡘ࡛࠳ࡃࡓࡇࡄࡘࡊࡥࡓࡕࡔࡈࡅࡒ࡙࠭࠳ࡰࡧࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡩࡶࡰࡰ࠮ࠐࠉࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡴࡦࡩࡲࡶࡾࡥ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣ࡫ࡷࡵࡵࡱࠢ࡬ࡲࠥࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴ࠼ࠍࠍࠎ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡂ࠱࠺࠼ࠣ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࠉ࡮࠵ࡸࡣࡹ࡫ࡸࡵࠢࡀࠤࡲ࠹ࡵࡠࡶࡨࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡩࡵࡳࡺࡶ࠽ࠣࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠲ࠧࡨࡴࡲࡹࡵࡃࠢࡠࡡࡐࡓ࡛ࡏࡅࡔࡡࡢࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧࠪࠌࠌࡨࡪࡲࠠࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶࠎࠎࡖࡒࡐࡉࡕࡉࡘ࡙࡟ࡖࡒࡇࡅ࡙ࡋࠨࡱࡆ࡬ࡥࡱࡵࡧ࠭࠵࠳࠰ࠬาไษࠢส่๊๊แศฬࠣห้ัว็๊ํอࠬ࠲ࠧศๆ่่ๆࠦัใ็࠽࠱ࠬ࠲ࠧ࠴ࠢ࠲ࠤ࠸࠭ࠩࠋࠋ࡬ࡪࠥࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡩࡴࡥࡤࡲࡨ࡫࡬ࡦࡦࠫ࠭࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡶࡴ࡯ࠤࡂࠦࡕࡓࡎࡢࡴࡱࡧࡹࡦࡴ࠮ࠫࠫࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡡ࡯࡭ࡻ࡫࡟ࡴࡶࡵࡩࡦࡳࡳࠨࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࡌࡔ࡙࡜࠭ࡄࡔࡈࡅ࡙ࡋ࡟ࡔࡖࡕࡉࡆࡓࡓ࠮࠵ࡵࡨࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡪࡷࡱࡱ࠯ࠊࠊ࡮࡬ࡺࡪࡥࡡࡳࡥ࡫࡭ࡻ࡫ࡤࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡶࡠࡣࡵࡧ࡭࡯ࡶࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡳࡧ࡭ࡦ࠮ࡤࡶࡨ࡮ࡩࡷࡧࡧࠤ࡮ࡴࠠ࡭࡫ࡹࡩࡤࡧࡲࡤࡪ࡬ࡺࡪࡪ࠺ࠋࠋࠌ࡭࡫ࠦࡡࡳࡥ࡫࡭ࡻ࡫ࡤ࠾࠿ࠪ࠵ࠬࡀࠠ࡭࡫ࡹࡩࡤࡧࡲࡤࡪ࡬ࡺࡪࡪ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡱࡥࡲ࡫ࠩࠋࠋࡧࡩࡱࠦ࡬ࡪࡸࡨࡣࡦࡸࡣࡩ࡫ࡹࡩࡩࠐࠉ࡭࡫ࡹࡩࡤ࡫ࡰࡨࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡥࡱࡩࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣ࡮ࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡪࡥ࡭ࠢ࡫ࡸࡲࡲࠊࠊࡨࡲࡶࠥࡴࡡ࡮ࡧ࠯ࡩࡵ࡭ࠠࡪࡰࠣࡰ࡮ࡼࡥࡠࡧࡳ࡫࠿ࠐࠉࠊ࡫ࡩࠤࡪࡶࡧࠢ࠿ࠪࡲࡺࡲ࡬ࠨ࠼ࠣࡰ࡮ࡼࡥࡠࡧࡳ࡫ࡤࡩࡨࡢࡰࡱࡩࡱࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡯ࡣࡰࡩ࠮ࠐࠉࡥࡧ࡯ࠤࡱ࡯ࡶࡦࡡࡨࡴ࡬ࠐࠉࠣࠤࠥ㜖")
	lines = re.findall(l1l1l1_l1_ (u"ࠬࡔࡆ࠻ࠪ࠱࠯ࡄ࠯ࠣࡆ࡚ࡗࡍࠬ㜗"),m3u_text+l1l1l1_l1_ (u"࠭࡜࡯ࠥࡈ࡜࡙ࡏࡎࡇ࠼ࠪ㜘"),re.DOTALL)
	MegaByte = 1024*1024
	splits_count = 1+len(m3u_text)//MegaByte//10
	del m3u_text
	m3u_streams_count = len(lines)
	lines2 = SPLIT_BIGLIST(lines,splits_count)
	del lines
	for ii in range(splits_count):
		PROGRESS_UPDATE(pDialog,35+int(5*ii/splits_count),l1l1l1_l1_ (u"ࠧหไฺ๎฾ࠦวๅ็็ๅࠥอไาศํื๏࠭㜙"),l1l1l1_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭㜚"),str(ii+1)+l1l1l1_l1_ (u"ࠩࠣ࠳ࠥ࠭㜛")+str(splits_count))
		if pDialog.iscanceled(): return
		lines_text = str(lines2[ii])
		if kodi_version>18.99: lines_text = lines_text.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㜜"))
		open(fullfile+l1l1l1_l1_ (u"ࠫ࠳࠶࠰ࠨ㜝")+str(ii),l1l1l1_l1_ (u"ࠬࡽࡢࠨ㜞")).write(lines_text)
	del lines2,lines_text
	all_ignored_streams,streams_not_sorted,jj = [],[],0
	for ii in range(splits_count):
		if pDialog.iscanceled(): return
		lines_text = open(fullfile+l1l1l1_l1_ (u"࠭࠮࠱࠲ࠪ㜟")+str(ii),l1l1l1_l1_ (u"ࠧࡳࡤࠪ㜠")).read()
		try: os.remove(fullfile+l1l1l1_l1_ (u"ࠨ࠰࠳࠴ࠬ㜡")+str(ii))
		except: pass
		if kodi_version>18.99: lines_text = lines_text.decode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㜢"))
		lines = EVAL(l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㜣"),lines_text)
		del lines_text
		streams,jj,ignored_streams = READ_ALL_LINES(lines,live_epg_channels,live_archived_channels,pDialog,m3u_streams_count,jj,URL_get)
		if pDialog.iscanceled(): return
		if not streams: return
		streams_not_sorted += streams
		all_ignored_streams += ignored_streams
	del lines,streams
	grouped_streams,ignored_streams = CREATE_GROUPED_STREAMS(streams_not_sorted,pDialog,l11l1l11_l1_)
	if pDialog.iscanceled(): return
	all_ignored_streams += ignored_streams
	del streams_not_sorted,ignored_streams
	types_count = len(UNIQUE_TYPES)
	finalstreams,all_menus,menus_counts,total_menus_count,ii = {},{},{},0,0
	for TYPE in list(grouped_streams.keys()):
		all_groups,streamsbygroup,new_streams = [],{},[]
		grouped_streams_type = grouped_streams[TYPE]
		del grouped_streams[TYPE]
		streams_type_count = len(grouped_streams_type)
		streamsbygroup[l1l1l1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㜤")] = streams_type_count
		if streams_type_count>0:
			grouplist,contextlist,titlelist,urllist,imglist = zip(*grouped_streams_type)
			new_streams = zip(grouplist,imglist)
			del grouplist,contextlist,titlelist,urllist,imglist
			new_streams = set(new_streams)
			new_streams = list(new_streams)
			new_streams_count = len(new_streams)
			for jj in range(new_streams_count):
				if jj%173==0:
					PROGRESS_UPDATE(pDialog,60+int(15*ii//types_count),l1l1l1_l1_ (u"ࠬะี็์฼ࠤฬ๊ๅๅใสฮ࠿࠳ࠠศๆ่่ๆࠦัใ็ࠪ㜥"),str(ii)+l1l1l1_l1_ (u"࠭ࠠ࠰ࠢࠪ㜦")+str(types_count),str(jj+1)+l1l1l1_l1_ (u"ࠧࠡ࠱ࠣࠫ㜧")+str(new_streams_count))
					if pDialog.iscanceled(): return
				all_groups.append(new_streams[jj])
				group,img = new_streams[jj]
				streamsbygroup[group] = []
			del new_streams
			all_groups = sorted(all_groups)
		streamsbygroup[l1l1l1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ㜨")] = all_groups
		del all_groups
		for group,context,title,url,img in grouped_streams_type:
			streamsbygroup[group].append((context,title,url,img))
		del grouped_streams_type
		finalstreams[TYPE] = streamsbygroup
		del streamsbygroup
		all_menus[TYPE] = list(finalstreams[TYPE].keys())
		menus_counts[TYPE] = len(all_menus[TYPE])
		total_menus_count += menus_counts[TYPE]
		ii += 1
	total_saved = 0
	DELETE_FILES(folder,l11l1l11_l1_,False)
	for TYPE in list(finalstreams.keys()):
		CREATE_MENUS(folder,TYPE)
		if pDialog.iscanceled(): return
	ignoredCount = len(all_ignored_streams)
	ii = 0
	dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࠪ㜩"))
	for stream in all_ignored_streams:
		PROGRESS_UPDATE(pDialog,95+int(5*ii//ignoredCount),l1l1l1_l1_ (u"ࠪฮำุ๊็ࠢส่๊ํๅๅหࠪ㜪"),l1l1l1_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ㜫"),str(ii)+l1l1l1_l1_ (u"ࠬࠦ࠯ࠡࠩ㜬")+str(ignoredCount))
		if pDialog.iscanceled(): return
		WRITE_TO_SQL3(dbfile,l1l1l1_l1_ (u"࠭ࡉࡈࡐࡒࡖࡊࡊ࡟ࠨ㜭")+l11l1l11_l1_,str(stream),l1l1l1_l1_ (u"ࠧࠨ㜮"),PERMANENT_CACHE)
		ii += 1
	WRITE_TO_SQL3(dbfile,l1l1l1_l1_ (u"ࠨࡋࡊࡒࡔࡘࡅࡅࡡࠪ㜯")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㜰"),str(ignoredCount),PERMANENT_CACHE)
	#WRITE_TO_SQL3(dbfile,l1l1l1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࡡࠪ㜱")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ㜲"),l1l1l1_l1_ (u"ࠬ࠷ࠧ㜳"),PERMANENT_CACHE)
	#open(l1ll111lll1_l1_,l1l1l1_l1_ (u"࠭ࡷࠨ㜴")).write(l1l1l1_l1_ (u"ࠧࠨ㜵"))
	pDialog.close()
	time.sleep(1)
	#countsMessage = COUNTS(folder,l11l1l11_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ㜶"),l1l1l1_l1_ (u"ࠩࠪ㜷"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㜸"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㜹")+l1l1l1_l1_ (u"ࠬะๅࠡฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠨ㜺")+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㜻")+l1l1l1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㜼")+countsMessage)
	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㜽"))
	return
def CREATE_MENUS(folder,TYPE):
	dbfile = GET_DBFILE_NAME(folder,TYPE)
	global pDialog,total_saved,finalstreams,menus_counts,all_menus,total_menus_count
	for jj in range(1+menus_counts[TYPE]//173):
		groups_chunk = all_menus[TYPE][0:173]
		del all_menus[TYPE][0:173]
		columns_list,data_list = [],[]
		for group in groups_chunk:
			columns_list.append(group)
			data_list.append(finalstreams[TYPE][group])
		total_saved += len(data_list)
		PROGRESS_UPDATE(pDialog,75+int(20*total_saved//total_menus_count),l1l1l1_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆࠩ㜾"),l1l1l1_l1_ (u"ࠪห้่วว็ฬࠤึ่ๅ࠻࠯ࠪ㜿"),str(total_saved)+l1l1l1_l1_ (u"ࠫࠥ࠵ࠠࠨ㝀")+str(total_menus_count))
		if pDialog.iscanceled(): return
		WRITE_TO_SQL3(dbfile,TYPE,columns_list,data_list,PERMANENT_CACHE,True)
	del finalstreams[TYPE],all_menus[TYPE],menus_counts[TYPE]
	return
def COUNTS(folder,l11l1l11_l1_,showDialogs=True):
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	header_message = l1l1l1_l1_ (u"ࠬ฿ฯะࠢไ๎ิ๐่่ษอࠤัฺ๋๊ࠢส่ึ๎วษูࠪ㝁")
	dbfile1 = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ㝂"))
	dbfile2 = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠧࡗࡑࡇࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ㝃"))
	if l11l1l11_l1_:
		header_message = l1l1l1_l1_ (u"ࠨ฻าำࠥ็๊ะ์๋๋ฬะࠠาษห฻ࠥ࠭㝄")+text_numbers[int(l11l1l11_l1_)]
		l11l1l11_l1_ = l1l1l1_l1_ (u"ࠩࡢࠫ㝅")+l11l1l11_l1_
	ignoredCount = READ_FROM_SQL3(dbfile1,l1l1l1_l1_ (u"ࠪ࡭ࡳࡺࠧ㝆"),l1l1l1_l1_ (u"ࠫࡎࡍࡎࡐࡔࡈࡈࠬ㝇")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㝈"))
	originalLIVEcount = READ_FROM_SQL3(dbfile1,l1l1l1_l1_ (u"࠭ࡩ࡯ࡶࠪ㝉"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㝊")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ㝋"))
	originalVODcount = READ_FROM_SQL3(dbfile2,l1l1l1_l1_ (u"ࠩ࡬ࡲࡹ࠭㝌"),l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㝍")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㝎"))
	knownLIVEcount = READ_FROM_SQL3(dbfile1,l1l1l1_l1_ (u"ࠬ࡯࡮ࡵࠩ㝏"),l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ㝐")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㝑"))
	unknownLIVEcount = READ_FROM_SQL3(dbfile1,l1l1l1_l1_ (u"ࠨ࡫ࡱࡸࠬ㝒"),l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㝓")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㝔"))
	moviesVODcount = READ_FROM_SQL3(dbfile1,l1l1l1_l1_ (u"ࠫ࡮ࡴࡴࠨ㝕"),l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㝖")+l11l1l11_l1_,l1l1l1_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㝗"))
	episodesVODcount = READ_FROM_SQL3(dbfile2,l1l1l1_l1_ (u"ࠧࡪࡰࡷࠫ㝘"),l1l1l1_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭㝙")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㝚"))
	unknownVODcount = READ_FROM_SQL3(dbfile1,l1l1l1_l1_ (u"ࠪ࡭ࡳࡺࠧ㝛"),l1l1l1_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㝜")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㝝"))
	groups = READ_FROM_SQL3(dbfile2,l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࠫ㝞"),l1l1l1_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㝟")+l11l1l11_l1_,l1l1l1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ㝠"))
	seriesLIST = []
	for group,img in groups:
		seriesName = group.split(l1l1l1_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㝡"))[1]
		seriesLIST.append(seriesName)
	seriesVODcount = len(seriesLIST)
	total = int(moviesVODcount)+int(episodesVODcount)+int(unknownVODcount)+int(unknownLIVEcount)+int(knownLIVEcount)
	countsMessage = l1l1l1_l1_ (u"ࠪࠫ㝢")
	countsMessage += l1l1l1_l1_ (u"ࠫ็์่ศฬ࠽ࠤࠬ㝣")+str(knownLIVEcount)
	countsMessage += l1l1l1_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥษแๅษ่࠾ࠥ࠭㝤")+str(moviesVODcount)
	countsMessage += l1l1l1_l1_ (u"࠭࡜࡯็ึุ่๊วห࠼ࠣࠫ㝥")+str(seriesVODcount)
	countsMessage += l1l1l1_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠฮๆๅหฯࡀࠠࠨ㝦")+str(episodesVODcount)
	countsMessage += l1l1l1_l1_ (u"ࠨ࡞ࡱๆ๋๎วห่ࠢะ์๎ไส࠼ࠣࠫ㝧")+str(unknownLIVEcount)
	countsMessage += l1l1l1_l1_ (u"ࠩࠣࠤࠥ࠴ࠠࠡࠢไ๎ิ๎็ศฬ้ࠣัํ่ๅห࠽ࠤࠬ㝨")+str(unknownVODcount)
	countsMessage += l1l1l1_l1_ (u"ࠪࡠࡳ๋ฬๆ๊฼ࠤฬ๊โ็๊สฮ࠿ࠦࠧ㝩")+str(originalLIVEcount)
	countsMessage += l1l1l1_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤ๊าๅ้฻ࠣห้็๊ะ์๋๋ฬะ࠺ࠡࠩ㝪")+str(originalVODcount)
	countsMessage += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰ่ะ๊๎ูࠡษ็้฻อแส࠼ࠣࠫ㝫")+str(total)
	countsMessage += l1l1l1_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦๅอ็๋฽ࠥอไๆ้่่ฮࡀࠠࠨ㝬")+str(ignoredCount)
	if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㝭"),l1l1l1_l1_ (u"ࠨࠩ㝮"),header_message,countsMessage)
	logMssage = countsMessage.replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㝯"),l1l1l1_l1_ (u"ࠪࡠࡳ࠭㝰"))
	LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㝱"),l1l1l1_l1_ (u"ࠬ࠴ࠠࠡࠢࡆࡳࡺࡴࡴࡴࠢࡲࡪࠥࡓ࠳ࡖࠢࡹ࡭ࡩ࡫࡯ࡴ࠼࠰ࡠࡳ࠭㝲")+logMssage)
	return countsMessage
def DELETE_FILES(folder,l11l1l11_l1_,showDialogs=True):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㝳"),l1l1l1_l1_ (u"ࠧࠨ㝴"),l1l1l1_l1_ (u"ࠨࠩ㝵"),l1l1l1_l1_ (u"่ࠩืาࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ㝶"),l1l1l1_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็่ࠢืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠣ࠲࠳ูࠦๅ็สࠤฬ์ใࠡฬึฮ฼๐ูࠡใํࠤศ๐้ࠠไอࠤฬ๊ฯฯ๊็ࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥ๎ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭㝷"))
		if yes!=1: return
		file = l1ll111l1l1_l1_.replace(l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨ㝸"),l1l1l1_l1_ (u"ࠬࡥࠧ㝹")+folder+l1l1l1_l1_ (u"࠭࡟ࠨ㝺")+l11l1l11_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1ll1111l11_l1_)
	#except: pass
	dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠧࠨ㝻"))
	if l11l1l11_l1_:
		l1ll111llll_l1_ = []
		for l1l11l1l1_l1_ in UNIQUE_TYPES:
			l1ll111llll_l1_.append(l1l11l1l1_l1_+l1l1l1_l1_ (u"ࠨࡡࠪ㝼")+l11l1l11_l1_)
		DELETE_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠩࡏࡍࡓࡑ࡟ࠨ㝽")+l11l1l11_l1_)
	else:
		l1ll111llll_l1_ = UNIQUE_TYPES
		DELETE_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ㝾"))
		DELETE_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠫࡌࡘࡏࡖࡒࡖࠫ㝿"))
		DELETE_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠬࡏࡔࡆࡏࡖࠫ㞀"))
		DELETE_FROM_SQL3(dbfile,l1l1l1_l1_ (u"࠭ࡓࡆࡃࡕࡇࡍ࠭㞁"))
		DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㞂"),l1l1l1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ㞃")+folder)
	for TYPE in l1ll111llll_l1_:
		DELETE_FROM_SQL3(dbfile,TYPE)
	FIX_ALL_DATABASES(False)
	if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㞄"),l1l1l1_l1_ (u"ࠪࠫ㞅"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㞆"),l1l1l1_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ㞇"))
	return
def CHECK_TABLES_EXIST(folder=l1l1l1_l1_ (u"࠭ࠧ㞈"),showDialogs=True):
	if folder:
		dbfile = GET_DBFILE_NAME(str(folder),l1l1l1_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭㞉"))
		dummy = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠨࡵࡷࡶࠬ㞊"),l1l1l1_l1_ (u"ࠩࡇ࡙ࡒࡓ࡙ࠨ㞋"),l1l1l1_l1_ (u"ࠪࡣࡤࡊࡕࡎࡏ࡜ࡣࡤ࠭㞌"))
		if dummy: return True
	else:
		for folder in range(FOLDERS_COUNT):
			dbfile = GET_DBFILE_NAME(str(folder),l1l1l1_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ㞍"))
			dummy = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠬࡹࡴࡳࠩ㞎"),l1l1l1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ㞏"),l1l1l1_l1_ (u"ࠧࡠࡡࡇ࡙ࡒࡓ࡙ࡠࡡࠪ㞐"))
			if dummy: return True
	if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ㞑"),l1l1l1_l1_ (u"ࠩࠪ㞒"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㞓"),l1l1l1_l1_ (u"ࠫฬ์สࠡสะหัฯࠠฦๆ์ࠤฬ๊ะ่ษหࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥัๅࠡฬู฾฼ูࠦๅ๋ࠣࠦส฼วโหࠣีฬฮืࠡล๋ࠤฬฺสาษๆࠤๅࡓ࠳ࡖࠤࠣ࠲࠳ࠦ็ั้ࠣห้ื่ศสฺࠤฬำสๆษ็ࠤฯาฯ่ษࠣๅ๏ࠦวๅว้ฮึ์สࠡล๋ࠤฯฺสา์๊ห๋ࠥๆࠡึิ็ฮࠦแ๋ัํ์์อสࠡ࡞ࡱࡠࡳࠦรๆษࠣษีอࠠใ็อࠤๆ฿ไศࠢหษ฻อแสࠢส่ึอศุࠢไษี์ࠠฤ่อࠤอำวอห่ࠣั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥ๎ะๅๅࠣฬฬ๊ะ่ษหࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥัๅࠡฬู฾฼ูࠦๅ๋ࠣࠦั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠧ࠴ࠧ㞔"))
	#SHOW_EMPTY(menu_name)
	return False
def SEARCH(search_org,folder=l1l1l1_l1_ (u"ࠬ࠭㞕"),TYPE=l1l1l1_l1_ (u"࠭ࠧ㞖"),PAGE=l1l1l1_l1_ (u"ࠧࠨ㞗")):
	if not PAGE: PAGE = l1l1l1_l1_ (u"ࠨ࠳ࠪ㞘")
	search,options,showDialogs = SEARCH_OPTIONS(search_org)
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	typeList = [l1l1l1_l1_ (u"ࠩࠪ㞙"),l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㞚"),l1l1l1_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㞛"),l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㞜"),l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㞝"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㞞")]
	if not TYPE:
		if not showDialogs:
			if   l1l1l1_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡌࡊࡘࡈࡣࠬ㞟") in options: TYPE = typeList[1]
			elif l1l1l1_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㞠") in options: TYPE = typeList[2]
			elif l1l1l1_l1_ (u"ࠪࡣࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ㞡") in options: TYPE = typeList[3]
			else: TYPE = typeList[0]
		else:
			searchTitle = [l1l1l1_l1_ (u"ࠫฬ๊ใๅࠩ㞢"),l1l1l1_l1_ (u"่ࠬๆ้ษอࠫ㞣"),l1l1l1_l1_ (u"࠭รโๆส้ࠬ㞤"),l1l1l1_l1_ (u"ࠧๆี็ื้อสࠨ㞥"),l1l1l1_l1_ (u"ࠨใํำ๏๎็ศฬ้ࠣัํ่ๅหࠪ㞦"),l1l1l1_l1_ (u"ࠩๅ๊ํอสࠡ็ฯ๋ํ๊ษࠨ㞧")]
			choice = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ㞨"), searchTitle)
			if choice==-1: return
			TYPE = typeList[choice]
	search = search+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ㞩")
	if folder: SEARCH_ONE_FOLDER(search,folder,TYPE,PAGE)
	else:
		for folder in range(FOLDERS_COUNT):
			SEARCH_ONE_FOLDER(search,str(folder),TYPE,PAGE)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(search_org,folder,TYPE=l1l1l1_l1_ (u"ࠬ࠭㞪"),PAGE=l1l1l1_l1_ (u"࠭ࠧ㞫")):
	if not PAGE: PAGE = l1l1l1_l1_ (u"ࠧ࠲ࠩ㞬")
	search,options,showDialogs = SEARCH_OPTIONS(search_org)
	if not folder: return
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	typeList = [l1l1l1_l1_ (u"ࠨࠩ㞭"),l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㞮"),l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㞯"),l1l1l1_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㞰"),l1l1l1_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㞱"),l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㞲")]
	if not TYPE:
		if not showDialogs:
			if   l1l1l1_l1_ (u"ࠧࡠࡏ࠶࡙࠲ࡒࡉࡗࡇࡢࠫ㞳") in options: TYPE = typeList[1]
			elif l1l1l1_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭㞴") in options: TYPE = typeList[2]
			elif l1l1l1_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ㞵") in options: TYPE = typeList[3]
			else: TYPE = typeList[0]
		else:
			searchTitle = [l1l1l1_l1_ (u"ࠪห้้ไࠨ㞶"),l1l1l1_l1_ (u"ࠫ็์่ศฬࠪ㞷"),l1l1l1_l1_ (u"ࠬษแๅษ่ࠫ㞸"),l1l1l1_l1_ (u"࠭ๅิๆึ่ฬะࠧ㞹"),l1l1l1_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩ㞺"),l1l1l1_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯࠧ㞻")]
			choice = DIALOG_SELECT(l1l1l1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㞼"), searchTitle)
			if choice==-1: return
			TYPE = typeList[choice]
	searchLower = search.lower()
	dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࠪ㞽"))
	results = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㞾"),l1l1l1_l1_ (u"࡙ࠬࡅࡂࡔࡆࡌࠬ㞿"),[TYPE,searchLower])
	if not results:
		allgroups,alltitles = [],[]
		if not TYPE: choices = [1,2,3,4,5]
		else: choices = [typeList.index(TYPE)]
		for ii in choices:
			#dbfile = GET_DBFILE_NAME(folder,typeList[ii])
			if ii!=3:
				streams = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"࠭ࡤࡪࡥࡷࠫ㟀"),typeList[ii])
				del streams[l1l1l1_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㟁")]
				del streams[l1l1l1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ㟂")]
				del streams[l1l1l1_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ㟃")]
				groups = list(streams.keys())
				for group in groups:
					for context,title,url,img in streams[group]:
						if searchLower in title.lower(): alltitles.append((title,url,img))
					del streams[group]
				del streams
			else: groups = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㟄"),typeList[ii],l1l1l1_l1_ (u"ࠫࡤࡥࡇࡓࡑࡘࡔࡘࡥ࡟ࠨ㟅"))
			for group in groups:
				try: group,img = group
				except: img = l1l1l1_l1_ (u"ࠬ࠭㟆")
				if searchLower in group.lower():
					if ii!=3: group2 = group
					else:
						maingroup,subgroup = group.split(l1l1l1_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㟇"))
						if searchLower in maingroup.lower(): group2 = maingroup
						else: group2 = subgroup
					allgroups.append((group,group2,typeList[ii],img))
			del groups
		allgroups = set(allgroups)
		alltitles = set(alltitles)
		allgroups = sorted(allgroups,reverse=False,key=lambda key: key[1])
		alltitles = sorted(alltitles,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(dbfile,l1l1l1_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ㟈"),[TYPE,searchLower],[allgroups,alltitles],PERMANENT_CACHE)
	else: allgroups,alltitles = results
	groups = len(allgroups)
	titles = len(alltitles)
	page = int(PAGE)
	s1 = max(0,(page-1)*100)
	e1 = max(0,page*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,group2,TYPE2,img in allgroups[s1:e1]:
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㟉"),menu_name+group2,TYPE2,714,img,l1l1l1_l1_ (u"ࠩ࠴ࠫ㟊"),group,l1l1l1_l1_ (u"ࠪࠫ㟋"),{l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㟌"):folder})
	del allgroups
	for title,url,img in alltitles[s2:e2]:
		videofile = url.split(l1l1l1_l1_ (u"ࠬ࠵ࠧ㟍"))[-1]
		if l1l1l1_l1_ (u"࠭࠮ࠨ㟎") in videofile and l1l1l1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㟏") not in videofile: addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㟐"),menu_name+title,url,715,img,l1l1l1_l1_ (u"ࠩࠪ㟑"),l1l1l1_l1_ (u"ࠪࠫ㟒"),l1l1l1_l1_ (u"ࠫࠬ㟓"),{l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㟔"):folder})
		else: addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡸࡨࠫ㟕"),menu_name+title,url,715,img,l1l1l1_l1_ (u"ࠧࠨ㟖"),l1l1l1_l1_ (u"ࠨࠩ㟗"),l1l1l1_l1_ (u"ࠩࠪ㟘"),{l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㟙"):folder})
	del alltitles
	PAGINATION(folder,PAGE,TYPE,719,groups+titles,search+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ㟚"))
	return
def PAGINATION(folder,PAGE,TYPE,mode,total,text):
	if not PAGE: PAGE = l1l1l1_l1_ (u"ࠬ࠷ࠧ㟛")
	if PAGE!=l1l1l1_l1_ (u"࠭࠱ࠨ㟜"): addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㟝"),menu_name+l1l1l1_l1_ (u"ࠨืไัฮࠦࠧ㟞")+str(1),TYPE,mode,l1l1l1_l1_ (u"ࠩࠪ㟟"),str(1),text,l1l1l1_l1_ (u"ࠪࠫ㟠"),{l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㟡"):folder})
	if not total: total = 0
	pages = int(total/100)+1
	for page in range(2,pages):
		cond1 = (page%10==0 or int(PAGE)-4<page<int(PAGE)+4)
		cond2 = (cond1 and int(PAGE)-40<page<int(PAGE)+40)
		if str(page)!=PAGE and (page%100==0 or cond2):
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㟢"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬ㟣")+str(page),TYPE,mode,l1l1l1_l1_ (u"ࠧࠨ㟤"),str(page),text,l1l1l1_l1_ (u"ࠨࠩ㟥"),{l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㟦"):folder})
	if str(pages)!=PAGE: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㟧"),menu_name+l1l1l1_l1_ (u"ࠫศิัࠡืไัฮࠦࠧ㟨")+str(pages),TYPE,mode,l1l1l1_l1_ (u"ࠬ࠭㟩"),str(pages),text,l1l1l1_l1_ (u"࠭ࠧ㟪"),{l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㟫"):folder})
	return
def GET_DBFILE_NAME(folder,TYPE):
	#if l1l1l1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨ㟬") in TYPE or l1l1l1_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࠨ㟭") in TYPE: dbfile = iptv2_dbfile
	#else: dbfile = iptv1_dbfile
	dbfile = l1ll111l111_l1_.replace(l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧ㟮"),l1l1l1_l1_ (u"ࠫࡤ࠭㟯")+folder)
	return dbfile
def l1ll111ll1l_l1_(folder):
	dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠬ࠭㟰"))
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㟱"),l1l1l1_l1_ (u"ࠧࠨ㟲"),l1l1l1_l1_ (u"ࠨࠩ㟳"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㟴"),l1l1l1_l1_ (u"ࠪ฽๊๊๊สࠢฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠢๅำࠥะอหษฯࠤ฾ีษࠡัๅหห่ࠠ࠯๊่ࠢࠥะั๋ัࠣว๋ࠦสอๆหࠤฬ๊ๅๅใสฮࠥอไร่ࠣรࠬ㟵"))
	if yes!=1: return
	l1ll1111l1l_l1_(folder,False)
	counts = []
	for seq in range(l1ll111l1ll_l1_):
		URL = settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡸ࡬ࡠࠩ㟶")+folder+l1l1l1_l1_ (u"ࠬࡥࠧ㟷")+str(seq))
		if URL: CREATE_STREAMS(folder,str(seq))
		counts.append(0)
	for TYPE in UNIQUE_TYPES:
		l1ll11111ll_l1_,l1ll1111ll1_l1_,l1ll11111l1_l1_,l1ll11l1111_l1_,l1ll11l11l1_l1_ = 0,{},[],[],[]
		for seq in range(l1ll111l1ll_l1_):
			TYPE2 = TYPE+l1l1l1_l1_ (u"࠭࡟ࠨ㟸")+str(seq)
			grouped_streams = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㟹"),TYPE2)
			try:
				l1ll1111lll_l1_ = grouped_streams[l1l1l1_l1_ (u"ࠨࡡࡢࡋࡗࡕࡕࡑࡕࡢࡣࠬ㟺")]
				count = grouped_streams[l1l1l1_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㟻")]
			except:
				l1ll1111lll_l1_ = []
				count = l1l1l1_l1_ (u"ࠪ࠴ࠬ㟼")
			for tuple in l1ll1111lll_l1_:
				group,image = tuple
				streams = grouped_streams[group]
				if group not in l1ll11l1111_l1_:
					l1ll11l1111_l1_.append(group)
					l1ll11l11l1_l1_.append(tuple)
					l1ll1111ll1_l1_[group] = []
				l1ll1111ll1_l1_[group] += streams
			DELETE_FROM_SQL3(dbfile,TYPE2)
			WRITE_TO_SQL3(dbfile,TYPE2,l1l1l1_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㟽"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l1ll11l1111_l1_:
			streams = list(set(l1ll1111ll1_l1_[group]))
			l1ll11111ll_l1_ += len(streams)
			l1ll11111l1_l1_.append(streams)
		WRITE_TO_SQL3(dbfile,TYPE,l1l1l1_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㟾"),str(l1ll11111ll_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(dbfile,TYPE,l1l1l1_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ㟿"),l1ll11l11l1_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(dbfile,TYPE,l1ll11l1111_l1_,l1ll11111l1_l1_,PERMANENT_CACHE,True)
	for seq in range(l1ll111l1ll_l1_):
		if int(counts[seq])>0:
			URL = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ㠀")+folder+l1l1l1_l1_ (u"ࠨࡡࠪ㠁")+str(seq))
			WRITE_TO_SQL3(dbfile,l1l1l1_l1_ (u"ࠩࡏࡍࡓࡑ࡟ࠨ㠂")+str(seq),l1l1l1_l1_ (u"ࠪࡣࡤࡒࡉࡏࡍࡢࡣࠬ㠃"),URL,PERMANENT_CACHE)
	WRITE_TO_SQL3(dbfile,l1l1l1_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ㠄"),l1l1l1_l1_ (u"ࠬࡥ࡟ࡅࡗࡐࡑ࡞ࡥ࡟ࠨ㠅"),l1l1l1_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ㠆"),PERMANENT_CACHE)
	DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ㠇"),l1l1l1_l1_ (u"ࠨࠩ㠈"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㠉"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㠊")+l1l1l1_l1_ (u"ࠫฯ๋ࠠอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ㠋")+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㠌"))
	l1ll11l111l_l1_(folder)
	xbmc.executebuiltin(l1l1l1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㠍"))
	return
def l1ll11l111l_l1_(folder):
	dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠧࠨ㠎"))
	if not CHECK_TABLES_EXIST(folder,True): return
	for seq in range(l1ll111l1ll_l1_):
		URL = READ_FROM_SQL3(dbfile,l1l1l1_l1_ (u"ࠨࡵࡷࡶࠬ㠏"),l1l1l1_l1_ (u"ࠩࡏࡍࡓࡑ࡟ࠨ㠐")+str(seq),l1l1l1_l1_ (u"ࠪࡣࡤࡒࡉࡏࡍࡢࡣࠬ㠑"))
		if URL: countsMessage = COUNTS(folder,str(seq))
	COUNTS(folder,l1l1l1_l1_ (u"ࠫࠬ㠒"))
	return
def l1ll1111l1l_l1_(folder,showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㠓"),l1l1l1_l1_ (u"࠭ࠧ㠔"),l1l1l1_l1_ (u"ࠧࠨ㠕"),l1l1l1_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤๅࡓ࠳ࡖࠩ㠖"),l1l1l1_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ศๆࠡ็ึัࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠢࠢ࠱࠲ࠥ฿ไๆษࠣห๋้ࠠหีอ฻๏฿ࠠโ์ࠣว๏่ࠦใฬࠣห้ีฮ้ๆࠣษ้๏ࠠใษษ้ฮࠦเࡎ࠵ࡘࠤําไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอࠬ㠗"))
		if yes!=1: return
	#for seq in range(l1ll111l1ll_l1_):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l1l1l1_l1_ (u"ࠪࠫ㠘"),False)
	dbfile = GET_DBFILE_NAME(folder,l1l1l1_l1_ (u"ࠫࠬ㠙"))
	try: os.remove(dbfile)
	except: pass
	for seq in range(l1ll111l1ll_l1_):
		filename = l1ll111l1l1_l1_.replace(l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࠩ㠚"),l1l1l1_l1_ (u"࠭࡟ࠨ㠛")+folder+l1l1l1_l1_ (u"ࠧࡠࠩ㠜")+str(seq))
		l1ll111l11l_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1ll111l11l_l1_)
		except: pass
	if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ㠝"),l1l1l1_l1_ (u"ࠩࠪ㠞"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㠟"),l1l1l1_l1_ (u"ࠫฯ๋ࠠๆีะࠤัฺ๋๊่่ࠢๆอสࠡโࡐ࠷࡚࠭㠠"))
	return
COUNTRY_NAME = {
 l1l1l1_l1_ (u"ࠬࡇࡆࠨ㠡"):l1l1l1_l1_ (u"࠭ࡁࡧࡩ࡫ࡥࡳ࡯ࡳࡵࡣࡱࠫ㠢")
,l1l1l1_l1_ (u"ࠧࡂࡎࠪ㠣"):l1l1l1_l1_ (u"ࠨࡃ࡯ࡦࡦࡴࡩࡢࠩ㠤")
,l1l1l1_l1_ (u"ࠩࡇ࡞ࠬ㠥"):l1l1l1_l1_ (u"ࠪࡅࡱ࡭ࡥࡳ࡫ࡤࠫ㠦")
,l1l1l1_l1_ (u"ࠫࡆ࡙ࠧ㠧"):l1l1l1_l1_ (u"ࠬࡇ࡭ࡦࡴ࡬ࡧࡦࡴࠠࡔࡣࡰࡳࡦ࠭㠨")
,l1l1l1_l1_ (u"࠭ࡁࡅࠩ㠩"):l1l1l1_l1_ (u"ࠧࡂࡰࡧࡳࡷࡸࡡࠨ㠪")
,l1l1l1_l1_ (u"ࠨࡃࡒࠫ㠫"):l1l1l1_l1_ (u"ࠩࡄࡲ࡬ࡵ࡬ࡢࠩ㠬")
,l1l1l1_l1_ (u"ࠪࡅࡎ࠭㠭"):l1l1l1_l1_ (u"ࠫࡆࡴࡧࡶ࡫࡯ࡰࡦ࠭㠮")
,l1l1l1_l1_ (u"ࠬࡇࡑࠨ㠯"):l1l1l1_l1_ (u"࠭ࡁ࡯ࡶࡤࡶࡨࡺࡩࡤࡣࠪ㠰")
,l1l1l1_l1_ (u"ࠧࡂࡉࠪ㠱"):l1l1l1_l1_ (u"ࠨࡃࡱࡸ࡮࡭ࡵࡢࠢࡤࡲࡩࠦࡂࡢࡴࡥࡹࡩࡧࠧ㠲")
,l1l1l1_l1_ (u"ࠩࡄࡖࠬ㠳"):l1l1l1_l1_ (u"ࠪࡅࡷ࡭ࡥ࡯ࡶ࡬ࡲࡦ࠭㠴")
,l1l1l1_l1_ (u"ࠫࡆࡓࠧ㠵"):l1l1l1_l1_ (u"ࠬࡇࡲ࡮ࡧࡱ࡭ࡦ࠭㠶")
,l1l1l1_l1_ (u"࠭ࡁࡘࠩ㠷"):l1l1l1_l1_ (u"ࠧࡂࡴࡸࡦࡦ࠭㠸")
,l1l1l1_l1_ (u"ࠨࡃࡘࠫ㠹"):l1l1l1_l1_ (u"ࠩࡄࡹࡸࡺࡲࡢ࡮࡬ࡥࠬ㠺")
,l1l1l1_l1_ (u"ࠪࡅ࡙࠭㠻"):l1l1l1_l1_ (u"ࠫࡆࡻࡳࡵࡴ࡬ࡥࠬ㠼")
,l1l1l1_l1_ (u"ࠬࡇ࡚ࠨ㠽"):l1l1l1_l1_ (u"࠭ࡁࡻࡧࡵࡦࡦ࡯ࡪࡢࡰࠪ㠾")
,l1l1l1_l1_ (u"ࠧࡃࡕࠪ㠿"):l1l1l1_l1_ (u"ࠨࡄࡤ࡬ࡦࡳࡡࡴࠩ㡀")
,l1l1l1_l1_ (u"ࠩࡅࡌࠬ㡁"):l1l1l1_l1_ (u"ࠪࡆࡦ࡮ࡲࡢ࡫ࡱࠫ㡂")
,l1l1l1_l1_ (u"ࠫࡇࡊࠧ㡃"):l1l1l1_l1_ (u"ࠬࡈࡡ࡯ࡩ࡯ࡥࡩ࡫ࡳࡩࠩ㡄")
,l1l1l1_l1_ (u"࠭ࡂࡃࠩ㡅"):l1l1l1_l1_ (u"ࠧࡃࡣࡵࡦࡦࡪ࡯ࡴࠩ㡆")
,l1l1l1_l1_ (u"ࠨࡄ࡜ࠫ㡇"):l1l1l1_l1_ (u"ࠩࡅࡩࡱࡧࡲࡶࡵࠪ㡈")
,l1l1l1_l1_ (u"ࠪࡆࡊ࠭㡉"):l1l1l1_l1_ (u"ࠫࡇ࡫࡬ࡨ࡫ࡸࡱࠬ㡊")
,l1l1l1_l1_ (u"ࠬࡈ࡚ࠨ㡋"):l1l1l1_l1_ (u"࠭ࡂࡦ࡮࡬ࡾࡪ࠭㡌")
,l1l1l1_l1_ (u"ࠧࡃࡌࠪ㡍"):l1l1l1_l1_ (u"ࠨࡄࡨࡲ࡮ࡴࠧ㡎")
,l1l1l1_l1_ (u"ࠩࡅࡑࠬ㡏"):l1l1l1_l1_ (u"ࠪࡆࡪࡸ࡭ࡶࡦࡤࠫ㡐")
,l1l1l1_l1_ (u"ࠫࡇ࡚ࠧ㡑"):l1l1l1_l1_ (u"ࠬࡈࡨࡶࡶࡤࡲࠬ㡒")
,l1l1l1_l1_ (u"࠭ࡂࡐࠩ㡓"):l1l1l1_l1_ (u"ࠧࡃࡱ࡯࡭ࡻ࡯ࡡࠨ㡔")
,l1l1l1_l1_ (u"ࠨࡄࡔࠫ㡕"):l1l1l1_l1_ (u"ࠩࡅࡳࡳࡧࡩࡳࡧࠪ㡖")
,l1l1l1_l1_ (u"ࠪࡆࡆ࠭㡗"):l1l1l1_l1_ (u"ࠫࡇࡵࡳ࡯࡫ࡤࠤࡦࡴࡤࠡࡊࡨࡶࡿ࡫ࡧࡰࡸ࡬ࡲࡦ࠭㡘")
,l1l1l1_l1_ (u"ࠬࡈࡗࠨ㡙"):l1l1l1_l1_ (u"࠭ࡂࡰࡶࡶࡻࡦࡴࡡࠨ㡚")
,l1l1l1_l1_ (u"ࠧࡃࡘࠪ㡛"):l1l1l1_l1_ (u"ࠨࡄࡲࡹࡻ࡫ࡴࠡࡋࡶࡰࡦࡴࡤࠨ㡜")
,l1l1l1_l1_ (u"ࠩࡅࡖࠬ㡝"):l1l1l1_l1_ (u"ࠪࡆࡷࡧࡺࡪ࡮ࠪ㡞")
,l1l1l1_l1_ (u"ࠫࡎࡕࠧ㡟"):l1l1l1_l1_ (u"ࠬࡈࡲࡪࡶ࡬ࡷ࡭ࠦࡉ࡯ࡦ࡬ࡥࡳࠦࡏࡤࡧࡤࡲ࡚ࠥࡥࡳࡴ࡬ࡸࡴࡸࡹࠨ㡠")
,l1l1l1_l1_ (u"࠭ࡖࡈࠩ㡡"):l1l1l1_l1_ (u"ࠧࡃࡴ࡬ࡸ࡮ࡹࡨࠡࡘ࡬ࡶ࡬࡯࡮ࠡࡋࡶࡰࡦࡴࡤࡴࠩ㡢")
,l1l1l1_l1_ (u"ࠨࡄࡑࠫ㡣"):l1l1l1_l1_ (u"ࠩࡅࡶࡺࡴࡥࡪࠩ㡤")
,l1l1l1_l1_ (u"ࠪࡆࡌ࠭㡥"):l1l1l1_l1_ (u"ࠫࡇࡻ࡬ࡨࡣࡵ࡭ࡦ࠭㡦")
,l1l1l1_l1_ (u"ࠬࡈࡆࠨ㡧"):l1l1l1_l1_ (u"࠭ࡂࡶࡴ࡮࡭ࡳࡧࠠࡇࡣࡶࡳࠬ㡨")
,l1l1l1_l1_ (u"ࠧࡃࡋࠪ㡩"):l1l1l1_l1_ (u"ࠨࡄࡸࡶࡺࡴࡤࡪࠩ㡪")
,l1l1l1_l1_ (u"ࠩࡎࡌࠬ㡫"):l1l1l1_l1_ (u"ࠪࡇࡦࡳࡢࡰࡦ࡬ࡥࠬ㡬")
,l1l1l1_l1_ (u"ࠫࡈࡓࠧ㡭"):l1l1l1_l1_ (u"ࠬࡉࡡ࡮ࡧࡵࡳࡴࡴࠧ㡮")
,l1l1l1_l1_ (u"࠭ࡃࡂࠩ㡯"):l1l1l1_l1_ (u"ࠧࡄࡣࡱࡥࡩࡧࠧ㡰")
,l1l1l1_l1_ (u"ࠨࡅ࡙ࠫ㡱"):l1l1l1_l1_ (u"ࠩࡆࡥࡵ࡫ࠠࡗࡧࡵࡨࡪ࠭㡲")
,l1l1l1_l1_ (u"ࠪࡏ࡞࠭㡳"):l1l1l1_l1_ (u"ࠫࡈࡧࡹ࡮ࡣࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ㡴")
,l1l1l1_l1_ (u"ࠬࡉࡆࠨ㡵"):l1l1l1_l1_ (u"࠭ࡃࡦࡰࡷࡶࡦࡲࠠࡂࡨࡵ࡭ࡨࡧ࡮ࠡࡔࡨࡴࡺࡨ࡬ࡪࡥࠪ㡶")
,l1l1l1_l1_ (u"ࠧࡕࡆࠪ㡷"):l1l1l1_l1_ (u"ࠨࡅ࡫ࡥࡩ࠭㡸")
,l1l1l1_l1_ (u"ࠩࡆࡐࠬ㡹"):l1l1l1_l1_ (u"ࠪࡇ࡭࡯࡬ࡦࠩ㡺")
,l1l1l1_l1_ (u"ࠫࡈࡔࠧ㡻"):l1l1l1_l1_ (u"ࠬࡉࡨࡪࡰࡤࠫ㡼")
,l1l1l1_l1_ (u"࠭ࡃ࡙ࠩ㡽"):l1l1l1_l1_ (u"ࠧࡄࡪࡵ࡭ࡸࡺ࡭ࡢࡵࠣࡍࡸࡲࡡ࡯ࡦࠪ㡾")
,l1l1l1_l1_ (u"ࠨࡅࡆࠫ㡿"):l1l1l1_l1_ (u"ࠩࡆࡳࡨࡵࡳࠡࠪࡎࡩࡪࡲࡩ࡯ࡩࠬࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ㢀")
,l1l1l1_l1_ (u"ࠪࡇࡔ࠭㢁"):l1l1l1_l1_ (u"ࠫࡈࡵ࡬ࡰ࡯ࡥ࡭ࡦ࠭㢂")
,l1l1l1_l1_ (u"ࠬࡑࡍࠨ㢃"):l1l1l1_l1_ (u"࠭ࡃࡰ࡯ࡲࡶࡴࡹࠧ㢄")
,l1l1l1_l1_ (u"ࠧࡄࡍࠪ㢅"):l1l1l1_l1_ (u"ࠨࡅࡲࡳࡰࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㢆")
,l1l1l1_l1_ (u"ࠩࡆࡖࠬ㢇"):l1l1l1_l1_ (u"ࠪࡇࡴࡹࡴࡢࠢࡕ࡭ࡨࡧࠧ㢈")
,l1l1l1_l1_ (u"ࠫࡍࡘࠧ㢉"):l1l1l1_l1_ (u"ࠬࡉࡲࡰࡣࡷ࡭ࡦ࠭㢊")
,l1l1l1_l1_ (u"࠭ࡃࡖࠩ㢋"):l1l1l1_l1_ (u"ࠧࡄࡷࡥࡥࠬ㢌")
,l1l1l1_l1_ (u"ࠨࡅ࡚ࠫ㢍"):l1l1l1_l1_ (u"ࠩࡆࡹࡷࡧࡣࡢࡱࠪ㢎")
,l1l1l1_l1_ (u"ࠪࡇ࡞࠭㢏"):l1l1l1_l1_ (u"ࠫࡈࡿࡰࡳࡷࡶࠫ㢐")
,l1l1l1_l1_ (u"ࠬࡉ࡚ࠨ㢑"):l1l1l1_l1_ (u"࠭ࡃࡻࡧࡦ࡬ࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ㢒")
,l1l1l1_l1_ (u"ࠧࡄࡆࠪ㢓"):l1l1l1_l1_ (u"ࠨࡆࡨࡱࡴࡩࡲࡢࡶ࡬ࡧࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠠࡰࡨࠣࡸ࡭࡫ࠠࡄࡱࡱ࡫ࡴ࠭㢔")
,l1l1l1_l1_ (u"ࠩࡇࡏࠬ㢕"):l1l1l1_l1_ (u"ࠪࡈࡪࡴ࡭ࡢࡴ࡮ࠫ㢖")
,l1l1l1_l1_ (u"ࠫࡉࡐࠧ㢗"):l1l1l1_l1_ (u"ࠬࡊࡪࡪࡤࡲࡹࡹ࡯ࠧ㢘")
,l1l1l1_l1_ (u"࠭ࡄࡎࠩ㢙"):l1l1l1_l1_ (u"ࠧࡅࡱࡰ࡭ࡳ࡯ࡣࡢࠩ㢚")
,l1l1l1_l1_ (u"ࠨࡆࡒࠫ㢛"):l1l1l1_l1_ (u"ࠩࡇࡳࡲ࡯࡮ࡪࡥࡤࡲࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ㢜")
,l1l1l1_l1_ (u"ࠪࡘࡑ࠭㢝"):l1l1l1_l1_ (u"ࠫࡊࡧࡳࡵࠢࡗ࡭ࡲࡵࡲࠨ㢞")
,l1l1l1_l1_ (u"ࠬࡋࡃࠨ㢟"):l1l1l1_l1_ (u"࠭ࡅࡤࡷࡤࡨࡴࡸࠧ㢠")
,l1l1l1_l1_ (u"ࠧࡆࡉࠪ㢡"):l1l1l1_l1_ (u"ࠨࡇࡪࡽࡵࡺࠧ㢢")
,l1l1l1_l1_ (u"ࠩࡖ࡚ࠬ㢣"):l1l1l1_l1_ (u"ࠪࡉࡱࠦࡓࡢ࡮ࡹࡥࡩࡵࡲࠨ㢤")
,l1l1l1_l1_ (u"ࠫࡌࡗࠧ㢥"):l1l1l1_l1_ (u"ࠬࡋࡱࡶࡣࡷࡳࡷ࡯ࡡ࡭ࠢࡊࡹ࡮ࡴࡥࡢࠩ㢦")
,l1l1l1_l1_ (u"࠭ࡅࡓࠩ㢧"):l1l1l1_l1_ (u"ࠧࡆࡴ࡬ࡸࡷ࡫ࡡࠨ㢨")
,l1l1l1_l1_ (u"ࠨࡇࡈࠫ㢩"):l1l1l1_l1_ (u"ࠩࡈࡷࡹࡵ࡮ࡪࡣࠪ㢪")
,l1l1l1_l1_ (u"ࠪࡉ࡙࠭㢫"):l1l1l1_l1_ (u"ࠫࡊࡺࡨࡪࡱࡳ࡭ࡦ࠭㢬")
,l1l1l1_l1_ (u"ࠬࡌࡋࠨ㢭"):l1l1l1_l1_ (u"࠭ࡆࡢ࡮࡮ࡰࡦࡴࡤࠡࡋࡶࡰࡦࡴࡤࡴࠩ㢮")
,l1l1l1_l1_ (u"ࠧࡇࡑࠪ㢯"):l1l1l1_l1_ (u"ࠨࡈࡤࡶࡴ࡫ࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㢰")
,l1l1l1_l1_ (u"ࠩࡉࡎࠬ㢱"):l1l1l1_l1_ (u"ࠪࡊ࡮ࡰࡩࠨ㢲")
,l1l1l1_l1_ (u"ࠫࡋࡏࠧ㢳"):l1l1l1_l1_ (u"ࠬࡌࡩ࡯࡮ࡤࡲࡩ࠭㢴")
,l1l1l1_l1_ (u"࠭ࡆࡓࠩ㢵"):l1l1l1_l1_ (u"ࠧࡇࡴࡤࡲࡨ࡫ࠧ㢶")
,l1l1l1_l1_ (u"ࠨࡉࡉࠫ㢷"):l1l1l1_l1_ (u"ࠩࡉࡶࡪࡴࡣࡩࠢࡊࡹ࡮ࡧ࡮ࡢࠩ㢸")
,l1l1l1_l1_ (u"ࠪࡔࡋ࠭㢹"):l1l1l1_l1_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠤࡕࡵ࡬ࡺࡰࡨࡷ࡮ࡧࠧ㢺")
,l1l1l1_l1_ (u"࡚ࠬࡆࠨ㢻"):l1l1l1_l1_ (u"࠭ࡆࡳࡧࡱࡧ࡭ࠦࡓࡰࡷࡷ࡬ࡪࡸ࡮ࠡࡖࡨࡶࡷ࡯ࡴࡰࡴ࡬ࡩࡸ࠭㢼")
,l1l1l1_l1_ (u"ࠧࡈࡃࠪ㢽"):l1l1l1_l1_ (u"ࠨࡉࡤࡦࡴࡴࠧ㢾")
,l1l1l1_l1_ (u"ࠩࡊࡑࠬ㢿"):l1l1l1_l1_ (u"ࠪࡋࡦࡳࡢࡪࡣࠪ㣀")
,l1l1l1_l1_ (u"ࠫࡌࡋࠧ㣁"):l1l1l1_l1_ (u"ࠬࡍࡥࡰࡴࡪ࡭ࡦ࠭㣂")
,l1l1l1_l1_ (u"࠭ࡄࡆࠩ㣃"):l1l1l1_l1_ (u"ࠧࡈࡧࡵࡱࡦࡴࡹࠨ㣄")
,l1l1l1_l1_ (u"ࠨࡉࡋࠫ㣅"):l1l1l1_l1_ (u"ࠩࡊ࡬ࡦࡴࡡࠨ㣆")
,l1l1l1_l1_ (u"ࠪࡋࡎ࠭㣇"):l1l1l1_l1_ (u"ࠫࡌ࡯ࡢࡳࡣ࡯ࡸࡦࡸࠧ㣈")
,l1l1l1_l1_ (u"ࠬࡍࡒࠨ㣉"):l1l1l1_l1_ (u"࠭ࡇࡳࡧࡨࡧࡪ࠭㣊")
,l1l1l1_l1_ (u"ࠧࡈࡎࠪ㣋"):l1l1l1_l1_ (u"ࠨࡉࡵࡩࡪࡴ࡬ࡢࡰࡧࠫ㣌")
,l1l1l1_l1_ (u"ࠩࡊࡈࠬ㣍"):l1l1l1_l1_ (u"ࠪࡋࡷ࡫࡮ࡢࡦࡤࠫ㣎")
,l1l1l1_l1_ (u"ࠫࡌࡖࠧ㣏"):l1l1l1_l1_ (u"ࠬࡍࡵࡢࡦࡨࡰࡴࡻࡰࡦࠩ㣐")
,l1l1l1_l1_ (u"࠭ࡇࡖࠩ㣑"):l1l1l1_l1_ (u"ࠧࡈࡷࡤࡱࠬ㣒")
,l1l1l1_l1_ (u"ࠨࡉࡗࠫ㣓"):l1l1l1_l1_ (u"ࠩࡊࡹࡦࡺࡥ࡮ࡣ࡯ࡥࠬ㣔")
,l1l1l1_l1_ (u"ࠪࡋࡌ࠭㣕"):l1l1l1_l1_ (u"ࠫࡌࡻࡥࡳࡰࡶࡩࡾ࠭㣖")
,l1l1l1_l1_ (u"ࠬࡍࡎࠨ㣗"):l1l1l1_l1_ (u"࠭ࡇࡶ࡫ࡱࡩࡦ࠭㣘")
,l1l1l1_l1_ (u"ࠧࡈ࡙ࠪ㣙"):l1l1l1_l1_ (u"ࠨࡉࡸ࡭ࡳ࡫ࡡ࠮ࡄ࡬ࡷࡸࡧࡵࠨ㣚")
,l1l1l1_l1_ (u"ࠩࡊ࡝ࠬ㣛"):l1l1l1_l1_ (u"ࠪࡋࡺࡿࡡ࡯ࡣࠪ㣜")
,l1l1l1_l1_ (u"ࠫࡍ࡚ࠧ㣝"):l1l1l1_l1_ (u"ࠬࡎࡡࡪࡶ࡬ࠫ㣞")
,l1l1l1_l1_ (u"࠭ࡈࡎࠩ㣟"):l1l1l1_l1_ (u"ࠧࡉࡧࡤࡶࡩࠦࡉࡴ࡮ࡤࡲࡩࠦࡡ࡯ࡦࠣࡑࡨࡊ࡯࡯ࡣ࡯ࡨࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㣠")
,l1l1l1_l1_ (u"ࠨࡊࡑࠫ㣡"):l1l1l1_l1_ (u"ࠩࡋࡳࡳࡪࡵࡳࡣࡶࠫ㣢")
,l1l1l1_l1_ (u"ࠪࡌࡐ࠭㣣"):l1l1l1_l1_ (u"ࠫࡍࡵ࡮ࡨࠢࡎࡳࡳ࡭ࠧ㣤")
,l1l1l1_l1_ (u"ࠬࡎࡕࠨ㣥"):l1l1l1_l1_ (u"࠭ࡈࡶࡰࡪࡥࡷࡿࠧ㣦")
,l1l1l1_l1_ (u"ࠧࡊࡕࠪ㣧"):l1l1l1_l1_ (u"ࠨࡋࡦࡩࡱࡧ࡮ࡥࠩ㣨")
,l1l1l1_l1_ (u"ࠩࡌࡒࠬ㣩"):l1l1l1_l1_ (u"ࠪࡍࡳࡪࡩࡢࠩ㣪")
,l1l1l1_l1_ (u"ࠫࡎࡊࠧ㣫"):l1l1l1_l1_ (u"ࠬࡏ࡮ࡥࡱࡱࡩࡸ࡯ࡡࠨ㣬")
,l1l1l1_l1_ (u"࠭ࡉࡓࠩ㣭"):l1l1l1_l1_ (u"ࠧࡊࡴࡤࡲࠬ㣮")
,l1l1l1_l1_ (u"ࠨࡋࡔࠫ㣯"):l1l1l1_l1_ (u"ࠩࡌࡶࡦࡷࠧ㣰")
,l1l1l1_l1_ (u"ࠪࡍࡊ࠭㣱"):l1l1l1_l1_ (u"ࠫࡎࡸࡥ࡭ࡣࡱࡨࠬ㣲")
,l1l1l1_l1_ (u"ࠬࡏࡍࠨ㣳"):l1l1l1_l1_ (u"࠭ࡉࡴ࡮ࡨࠤࡴ࡬ࠠࡎࡣࡱࠫ㣴")
,l1l1l1_l1_ (u"ࠧࡊࡎࠪ㣵"):l1l1l1_l1_ (u"ࠨࡋࡶࡶࡦ࡫࡬ࠨ㣶")
,l1l1l1_l1_ (u"ࠩࡌࡘࠬ㣷"):l1l1l1_l1_ (u"ࠪࡍࡹࡧ࡬ࡺࠩ㣸")
,l1l1l1_l1_ (u"ࠫࡈࡏࠧ㣹"):l1l1l1_l1_ (u"ࠬࡏࡶࡰࡴࡼࠤࡈࡵࡡࡴࡶࠪ㣺")
,l1l1l1_l1_ (u"࠭ࡊࡎࠩ㣻"):l1l1l1_l1_ (u"ࠧࡋࡣࡰࡥ࡮ࡩࡡࠨ㣼")
,l1l1l1_l1_ (u"ࠨࡌࡓࠫ㣽"):l1l1l1_l1_ (u"ࠩࡍࡥࡵࡧ࡮ࠨ㣾")
,l1l1l1_l1_ (u"ࠪࡎࡊ࠭㣿"):l1l1l1_l1_ (u"ࠫࡏ࡫ࡲࡴࡧࡼࠫ㤀")
,l1l1l1_l1_ (u"ࠬࡐࡏࠨ㤁"):l1l1l1_l1_ (u"࠭ࡊࡰࡴࡧࡥࡳ࠭㤂")
,l1l1l1_l1_ (u"ࠧࡌ࡜ࠪ㤃"):l1l1l1_l1_ (u"ࠨࡍࡤࡾࡦࡱࡨࡴࡶࡤࡲࠬ㤄")
,l1l1l1_l1_ (u"ࠩࡎࡉࠬ㤅"):l1l1l1_l1_ (u"ࠪࡏࡪࡴࡹࡢࠩ㤆")
,l1l1l1_l1_ (u"ࠫࡐࡏࠧ㤇"):l1l1l1_l1_ (u"ࠬࡑࡩࡳ࡫ࡥࡥࡹ࡯ࠧ㤈")
,l1l1l1_l1_ (u"࠭ࡘࡌࠩ㤉"):l1l1l1_l1_ (u"ࠧࡌࡱࡶࡳࡻࡵࠧ㤊")
,l1l1l1_l1_ (u"ࠨࡍ࡚ࠫ㤋"):l1l1l1_l1_ (u"ࠩࡎࡹࡼࡧࡩࡵࠩ㤌")
,l1l1l1_l1_ (u"ࠪࡏࡌ࠭㤍"):l1l1l1_l1_ (u"ࠫࡐࡿࡲࡨࡻࡽࡷࡹࡧ࡮ࠨ㤎")
,l1l1l1_l1_ (u"ࠬࡒࡁࠨ㤏"):l1l1l1_l1_ (u"࠭ࡌࡢࡱࡶࠫ㤐")
,l1l1l1_l1_ (u"ࠧࡍࡘࠪ㤑"):l1l1l1_l1_ (u"ࠨࡎࡤࡸࡻ࡯ࡡࠨ㤒")
,l1l1l1_l1_ (u"ࠩࡏࡆࠬ㤓"):l1l1l1_l1_ (u"ࠪࡐࡪࡨࡡ࡯ࡱࡱࠫ㤔")
,l1l1l1_l1_ (u"ࠫࡑ࡙ࠧ㤕"):l1l1l1_l1_ (u"ࠬࡒࡥࡴࡱࡷ࡬ࡴ࠭㤖")
,l1l1l1_l1_ (u"࠭ࡌࡓࠩ㤗"):l1l1l1_l1_ (u"ࠧࡍ࡫ࡥࡩࡷ࡯ࡡࠨ㤘")
,l1l1l1_l1_ (u"ࠨࡎ࡜ࠫ㤙"):l1l1l1_l1_ (u"ࠩࡏ࡭ࡧࡿࡡࠨ㤚")
,l1l1l1_l1_ (u"ࠪࡐࡎ࠭㤛"):l1l1l1_l1_ (u"ࠫࡑ࡯ࡥࡤࡪࡷࡩࡳࡹࡴࡦ࡫ࡱࠫ㤜")
,l1l1l1_l1_ (u"ࠬࡒࡔࠨ㤝"):l1l1l1_l1_ (u"࠭ࡌࡪࡶ࡫ࡹࡦࡴࡩࡢࠩ㤞")
,l1l1l1_l1_ (u"ࠧࡍࡗࠪ㤟"):l1l1l1_l1_ (u"ࠨࡎࡸࡼࡪࡳࡢࡰࡷࡵ࡫ࠬ㤠")
,l1l1l1_l1_ (u"ࠩࡐࡓࠬ㤡"):l1l1l1_l1_ (u"ࠪࡑࡦࡩࡡࡰࠩ㤢")
,l1l1l1_l1_ (u"ࠫࡒࡍࠧ㤣"):l1l1l1_l1_ (u"ࠬࡓࡡࡥࡣࡪࡥࡸࡩࡡࡳࠩ㤤")
,l1l1l1_l1_ (u"࠭ࡍࡘࠩ㤥"):l1l1l1_l1_ (u"ࠧࡎࡣ࡯ࡥࡼ࡯ࠧ㤦")
,l1l1l1_l1_ (u"ࠨࡏ࡜ࠫ㤧"):l1l1l1_l1_ (u"ࠩࡐࡥࡱࡧࡹࡴ࡫ࡤࠫ㤨")
,l1l1l1_l1_ (u"ࠪࡑ࡛࠭㤩"):l1l1l1_l1_ (u"ࠫࡒࡧ࡬ࡥ࡫ࡹࡩࡸ࠭㤪")
,l1l1l1_l1_ (u"ࠬࡓࡌࠨ㤫"):l1l1l1_l1_ (u"࠭ࡍࡢ࡮࡬ࠫ㤬")
,l1l1l1_l1_ (u"ࠧࡎࡖࠪ㤭"):l1l1l1_l1_ (u"ࠨࡏࡤࡰࡹࡧࠧ㤮")
,l1l1l1_l1_ (u"ࠩࡐࡌࠬ㤯"):l1l1l1_l1_ (u"ࠪࡑࡦࡸࡳࡩࡣ࡯ࡰࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㤰")
,l1l1l1_l1_ (u"ࠫࡒࡗࠧ㤱"):l1l1l1_l1_ (u"ࠬࡓࡡࡳࡶ࡬ࡲ࡮ࡷࡵࡦࠩ㤲")
,l1l1l1_l1_ (u"࠭ࡍࡓࠩ㤳"):l1l1l1_l1_ (u"ࠧࡎࡣࡸࡶ࡮ࡺࡡ࡯࡫ࡤࠫ㤴")
,l1l1l1_l1_ (u"ࠨࡏࡘࠫ㤵"):l1l1l1_l1_ (u"ࠩࡐࡥࡺࡸࡩࡵ࡫ࡸࡷࠬ㤶")
,l1l1l1_l1_ (u"ࠪ࡝࡙࠭㤷"):l1l1l1_l1_ (u"ࠫࡒࡧࡹࡰࡶࡷࡩࠬ㤸")
,l1l1l1_l1_ (u"ࠬࡓࡘࠨ㤹"):l1l1l1_l1_ (u"࠭ࡍࡦࡺ࡬ࡧࡴ࠭㤺")
,l1l1l1_l1_ (u"ࠧࡇࡏࠪ㤻"):l1l1l1_l1_ (u"ࠨࡏ࡬ࡧࡷࡵ࡮ࡦࡵ࡬ࡥࠬ㤼")
,l1l1l1_l1_ (u"ࠩࡐࡈࠬ㤽"):l1l1l1_l1_ (u"ࠪࡑࡴࡲࡤࡰࡸࡤࠫ㤾")
,l1l1l1_l1_ (u"ࠫࡒࡉࠧ㤿"):l1l1l1_l1_ (u"ࠬࡓ࡯࡯ࡣࡦࡳࠬ㥀")
,l1l1l1_l1_ (u"࠭ࡍࡏࠩ㥁"):l1l1l1_l1_ (u"ࠧࡎࡱࡱ࡫ࡴࡲࡩࡢࠩ㥂")
,l1l1l1_l1_ (u"ࠨࡏࡈࠫ㥃"):l1l1l1_l1_ (u"ࠩࡐࡳࡳࡺࡥ࡯ࡧࡪࡶࡴ࠭㥄")
,l1l1l1_l1_ (u"ࠪࡑࡘ࠭㥅"):l1l1l1_l1_ (u"ࠫࡒࡵ࡮ࡵࡵࡨࡶࡷࡧࡴࠨ㥆")
,l1l1l1_l1_ (u"ࠬࡓࡁࠨ㥇"):l1l1l1_l1_ (u"࠭ࡍࡰࡴࡲࡧࡨࡵࠧ㥈")
,l1l1l1_l1_ (u"ࠧࡎ࡜ࠪ㥉"):l1l1l1_l1_ (u"ࠨࡏࡲࡾࡦࡳࡢࡪࡳࡸࡩࠬ㥊")
,l1l1l1_l1_ (u"ࠩࡐࡑࠬ㥋"):l1l1l1_l1_ (u"ࠪࡑࡾࡧ࡮࡮ࡣࡵࠤ࠭ࡈࡵࡳ࡯ࡤ࠭ࠬ㥌")
,l1l1l1_l1_ (u"ࠫࡓࡇࠧ㥍"):l1l1l1_l1_ (u"ࠬࡔࡡ࡮࡫ࡥ࡭ࡦ࠭㥎")
,l1l1l1_l1_ (u"࠭ࡎࡓࠩ㥏"):l1l1l1_l1_ (u"ࠧࡏࡣࡸࡶࡺ࠭㥐")
,l1l1l1_l1_ (u"ࠨࡐࡓࠫ㥑"):l1l1l1_l1_ (u"ࠩࡑࡩࡵࡧ࡬ࠨ㥒")
,l1l1l1_l1_ (u"ࠪࡒࡑ࠭㥓"):l1l1l1_l1_ (u"ࠫࡓ࡫ࡴࡩࡧࡵࡰࡦࡴࡤࡴࠩ㥔")
,l1l1l1_l1_ (u"ࠬࡔࡃࠨ㥕"):l1l1l1_l1_ (u"࠭ࡎࡦࡹࠣࡇࡦࡲࡥࡥࡱࡱ࡭ࡦ࠭㥖")
,l1l1l1_l1_ (u"ࠧࡏ࡜ࠪ㥗"):l1l1l1_l1_ (u"ࠨࡐࡨࡻࠥࡠࡥࡢ࡮ࡤࡲࡩ࠭㥘")
,l1l1l1_l1_ (u"ࠩࡑࡍࠬ㥙"):l1l1l1_l1_ (u"ࠪࡒ࡮ࡩࡡࡳࡣࡪࡹࡦ࠭㥚")
,l1l1l1_l1_ (u"ࠫࡓࡋࠧ㥛"):l1l1l1_l1_ (u"ࠬࡔࡩࡨࡧࡵࠫ㥜")
,l1l1l1_l1_ (u"࠭ࡎࡈࠩ㥝"):l1l1l1_l1_ (u"ࠧࡏ࡫ࡪࡩࡷ࡯ࡡࠨ㥞")
,l1l1l1_l1_ (u"ࠨࡐࡘࠫ㥟"):l1l1l1_l1_ (u"ࠩࡑ࡭ࡺ࡫ࠧ㥠")
,l1l1l1_l1_ (u"ࠪࡒࡋ࠭㥡"):l1l1l1_l1_ (u"ࠫࡓࡵࡲࡧࡱ࡯࡯ࠥࡏࡳ࡭ࡣࡱࡨࠬ㥢")
,l1l1l1_l1_ (u"ࠬࡑࡐࠨ㥣"):l1l1l1_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡑ࡯ࡳࡧࡤࠫ㥤")
,l1l1l1_l1_ (u"ࠧࡎࡍࠪ㥥"):l1l1l1_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ㥦")
,l1l1l1_l1_ (u"ࠩࡐࡔࠬ㥧"):l1l1l1_l1_ (u"ࠪࡒࡴࡸࡴࡩࡧࡵࡲࠥࡓࡡࡳ࡫ࡤࡲࡦࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㥨")
,l1l1l1_l1_ (u"ࠫࡓࡕࠧ㥩"):l1l1l1_l1_ (u"ࠬࡔ࡯ࡳࡹࡤࡽࠬ㥪")
,l1l1l1_l1_ (u"࠭ࡏࡎࠩ㥫"):l1l1l1_l1_ (u"ࠧࡐ࡯ࡤࡲࠬ㥬")
,l1l1l1_l1_ (u"ࠨࡒࡎࠫ㥭"):l1l1l1_l1_ (u"ࠩࡓࡥࡰ࡯ࡳࡵࡣࡱࠫ㥮")
,l1l1l1_l1_ (u"ࠪࡔ࡜࠭㥯"):l1l1l1_l1_ (u"ࠫࡕࡧ࡬ࡢࡷࠪ㥰")
,l1l1l1_l1_ (u"ࠬࡖࡓࠨ㥱"):l1l1l1_l1_ (u"࠭ࡐࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ㥲")
,l1l1l1_l1_ (u"ࠧࡑࡃࠪ㥳"):l1l1l1_l1_ (u"ࠨࡒࡤࡲࡦࡳࡡࠨ㥴")
,l1l1l1_l1_ (u"ࠩࡓࡋࠬ㥵"):l1l1l1_l1_ (u"ࠪࡔࡦࡶࡵࡢࠢࡑࡩࡼࠦࡇࡶ࡫ࡱࡩࡦ࠭㥶")
,l1l1l1_l1_ (u"ࠫࡕ࡟ࠧ㥷"):l1l1l1_l1_ (u"ࠬࡖࡡࡳࡣࡪࡹࡦࡿࠧ㥸")
,l1l1l1_l1_ (u"࠭ࡐࡆࠩ㥹"):l1l1l1_l1_ (u"ࠧࡑࡧࡵࡹࠬ㥺")
,l1l1l1_l1_ (u"ࠨࡒࡋࠫ㥻"):l1l1l1_l1_ (u"ࠩࡓ࡬࡮ࡲࡩࡱࡲ࡬ࡲࡪࡹࠧ㥼")
,l1l1l1_l1_ (u"ࠪࡔࡓ࠭㥽"):l1l1l1_l1_ (u"ࠫࡕ࡯ࡴࡤࡣ࡬ࡶࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㥾")
,l1l1l1_l1_ (u"ࠬࡖࡌࠨ㥿"):l1l1l1_l1_ (u"࠭ࡐࡰ࡮ࡤࡲࡩ࠭㦀")
,l1l1l1_l1_ (u"ࠧࡑࡖࠪ㦁"):l1l1l1_l1_ (u"ࠨࡒࡲࡶࡹࡻࡧࡢ࡮ࠪ㦂")
,l1l1l1_l1_ (u"ࠩࡓࡖࠬ㦃"):l1l1l1_l1_ (u"ࠪࡔࡺ࡫ࡲࡵࡱࠣࡖ࡮ࡩ࡯ࠨ㦄")
,l1l1l1_l1_ (u"ࠫࡖࡇࠧ㦅"):l1l1l1_l1_ (u"ࠬࡗࡡࡵࡣࡵࠫ㦆")
,l1l1l1_l1_ (u"࠭ࡃࡈࠩ㦇"):l1l1l1_l1_ (u"ࠧࡓࡧࡳࡹࡧࡲࡩࡤࠢࡲࡪࠥࡺࡨࡦࠢࡆࡳࡳ࡭࡯ࠨ㦈")
,l1l1l1_l1_ (u"ࠨࡔࡒࠫ㦉"):l1l1l1_l1_ (u"ࠩࡕࡳࡲࡧ࡮ࡪࡣࠪ㦊")
,l1l1l1_l1_ (u"ࠪࡖ࡚࠭㦋"):l1l1l1_l1_ (u"ࠫࡗࡻࡳࡴ࡫ࡤࠫ㦌")
,l1l1l1_l1_ (u"ࠬࡘࡗࠨ㦍"):l1l1l1_l1_ (u"࠭ࡒࡸࡣࡱࡨࡦ࠭㦎")
,l1l1l1_l1_ (u"ࠧࡓࡇࠪ㦏"):l1l1l1_l1_ (u"ࠨࡔ࣬ࡹࡳ࡯࡯࡯ࠩ㦐")
,l1l1l1_l1_ (u"ࠩࡅࡐࠬ㦑"):l1l1l1_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡅࡥࡷࡺࡨ࣪࡮ࡨࡱࡾ࠭㦒")
,l1l1l1_l1_ (u"ࠫࡘࡎࠧ㦓"):l1l1l1_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡍ࡫࡬ࡦࡰࡤࠫ㦔")
,l1l1l1_l1_ (u"࠭ࡋࡏࠩ㦕"):l1l1l1_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡋࡪࡶࡷࡷࠥࡧ࡮ࡥࠢࡑࡩࡻ࡯ࡳࠨ㦖")
,l1l1l1_l1_ (u"ࠨࡎࡆࠫ㦗"):l1l1l1_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡎࡸࡧ࡮ࡧࠧ㦘")
,l1l1l1_l1_ (u"ࠪࡑࡋ࠭㦙"):l1l1l1_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡑࡦࡸࡴࡪࡰࠪ㦚")
,l1l1l1_l1_ (u"ࠬࡖࡍࠨ㦛"):l1l1l1_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡖࡩࡦࡴࡵࡩࠥࡧ࡮ࡥࠢࡐ࡭ࡶࡻࡥ࡭ࡱࡱࠫ㦜")
,l1l1l1_l1_ (u"ࠧࡗࡅࠪ㦝"):l1l1l1_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡗ࡫ࡱࡧࡪࡴࡴࠡࡣࡱࡨࠥࡺࡨࡦࠢࡊࡶࡪࡴࡡࡥ࡫ࡱࡩࡸ࠭㦞")
,l1l1l1_l1_ (u"࡚ࠩࡗࠬ㦟"):l1l1l1_l1_ (u"ࠪࡗࡦࡳ࡯ࡢࠩ㦠")
,l1l1l1_l1_ (u"ࠫࡘࡓࠧ㦡"):l1l1l1_l1_ (u"࡙ࠬࡡ࡯ࠢࡐࡥࡷ࡯࡮ࡰࠩ㦢")
,l1l1l1_l1_ (u"࠭ࡓࡂࠩ㦣"):l1l1l1_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭㦤")
,l1l1l1_l1_ (u"ࠨࡕࡑࠫ㦥"):l1l1l1_l1_ (u"ࠩࡖࡩࡳ࡫ࡧࡢ࡮ࠪ㦦")
,l1l1l1_l1_ (u"ࠪࡖࡘ࠭㦧"):l1l1l1_l1_ (u"ࠫࡘ࡫ࡲࡣ࡫ࡤࠫ㦨")
,l1l1l1_l1_ (u"࡙ࠬࡃࠨ㦩"):l1l1l1_l1_ (u"࠭ࡓࡦࡻࡦ࡬ࡪࡲ࡬ࡦࡵࠪ㦪")
,l1l1l1_l1_ (u"ࠧࡔࡎࠪ㦫"):l1l1l1_l1_ (u"ࠨࡕ࡬ࡩࡷࡸࡡࠡࡎࡨࡳࡳ࡫ࠧ㦬")
,l1l1l1_l1_ (u"ࠩࡖࡋࠬ㦭"):l1l1l1_l1_ (u"ࠪࡗ࡮ࡴࡧࡢࡲࡲࡶࡪ࠭㦮")
,l1l1l1_l1_ (u"ࠫࡘ࡞ࠧ㦯"):l1l1l1_l1_ (u"࡙ࠬࡩ࡯ࡶࠣࡑࡦࡧࡲࡵࡧࡱࠫ㦰")
,l1l1l1_l1_ (u"࠭ࡓࡌࠩ㦱"):l1l1l1_l1_ (u"ࠧࡔ࡮ࡲࡺࡦࡱࡩࡢࠩ㦲")
,l1l1l1_l1_ (u"ࠨࡕࡌࠫ㦳"):l1l1l1_l1_ (u"ࠩࡖࡰࡴࡼࡥ࡯࡫ࡤࠫ㦴")
,l1l1l1_l1_ (u"ࠪࡗࡇ࠭㦵"):l1l1l1_l1_ (u"ࠫࡘࡵ࡬ࡰ࡯ࡲࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㦶")
,l1l1l1_l1_ (u"࡙ࠬࡏࠨ㦷"):l1l1l1_l1_ (u"࠭ࡓࡰ࡯ࡤࡰ࡮ࡧࠧ㦸")
,l1l1l1_l1_ (u"࡛ࠧࡃࠪ㦹"):l1l1l1_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡂࡨࡵ࡭ࡨࡧࠧ㦺")
,l1l1l1_l1_ (u"ࠩࡊࡗࠬ㦻"):l1l1l1_l1_ (u"ࠪࡗࡴࡻࡴࡩࠢࡊࡩࡴࡸࡧࡪࡣࠣࡥࡳࡪࠠࡵࡪࡨࠤࡘࡵࡵࡵࡪࠣࡗࡦࡴࡤࡸ࡫ࡦ࡬ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㦼")
,l1l1l1_l1_ (u"ࠫࡐࡘࠧ㦽"):l1l1l1_l1_ (u"࡙ࠬ࡯ࡶࡶ࡫ࠤࡐࡵࡲࡦࡣࠪ㦾")
,l1l1l1_l1_ (u"࠭ࡓࡔࠩ㦿"):l1l1l1_l1_ (u"ࠧࡔࡱࡸࡸ࡭ࠦࡓࡶࡦࡤࡲࠬ㧀")
,l1l1l1_l1_ (u"ࠨࡇࡖࠫ㧁"):l1l1l1_l1_ (u"ࠩࡖࡴࡦ࡯࡮ࠨ㧂")
,l1l1l1_l1_ (u"ࠪࡐࡐ࠭㧃"):l1l1l1_l1_ (u"ࠫࡘࡸࡩࠡࡎࡤࡲࡰࡧࠧ㧄")
,l1l1l1_l1_ (u"࡙ࠬࡄࠨ㧅"):l1l1l1_l1_ (u"࠭ࡓࡶࡦࡤࡲࠬ㧆")
,l1l1l1_l1_ (u"ࠧࡔࡔࠪ㧇"):l1l1l1_l1_ (u"ࠨࡕࡸࡶ࡮ࡴࡡ࡮ࡧࠪ㧈")
,l1l1l1_l1_ (u"ࠩࡖࡎࠬ㧉"):l1l1l1_l1_ (u"ࠪࡗࡻࡧ࡬ࡣࡣࡵࡨࠥࡧ࡮ࡥࠢࡍࡥࡳࠦࡍࡢࡻࡨࡲࠬ㧊")
,l1l1l1_l1_ (u"ࠫࡘࡠࠧ㧋"):l1l1l1_l1_ (u"࡙ࠬࡷࡢࡼ࡬ࡰࡦࡴࡤࠨ㧌")
,l1l1l1_l1_ (u"࠭ࡓࡆࠩ㧍"):l1l1l1_l1_ (u"ࠧࡔࡹࡨࡨࡪࡴࠧ㧎")
,l1l1l1_l1_ (u"ࠨࡅࡋࠫ㧏"):l1l1l1_l1_ (u"ࠩࡖࡻ࡮ࡺࡺࡦࡴ࡯ࡥࡳࡪࠧ㧐")
,l1l1l1_l1_ (u"ࠪࡗ࡞࠭㧑"):l1l1l1_l1_ (u"ࠫࡘࡿࡲࡪࡣࠪ㧒")
,l1l1l1_l1_ (u"࡙ࠬࡔࠨ㧓"):l1l1l1_l1_ (u"࠭ࡓࣤࡱࠣࡘࡴࡳࣩࠡࡣࡱࡨࠥࡖࡲ࣮ࡰࡦ࡭ࡵ࡫ࠧ㧔")
,l1l1l1_l1_ (u"ࠧࡕ࡙ࠪ㧕"):l1l1l1_l1_ (u"ࠨࡖࡤ࡭ࡼࡧ࡮ࠨ㧖")
,l1l1l1_l1_ (u"ࠩࡗࡎࠬ㧗"):l1l1l1_l1_ (u"ࠪࡘࡦࡰࡩ࡬࡫ࡶࡸࡦࡴࠧ㧘")
,l1l1l1_l1_ (u"࡙ࠫࡠࠧ㧙"):l1l1l1_l1_ (u"࡚ࠬࡡ࡯ࡼࡤࡲ࡮ࡧࠧ㧚")
,l1l1l1_l1_ (u"࠭ࡔࡉࠩ㧛"):l1l1l1_l1_ (u"ࠧࡕࡪࡤ࡭ࡱࡧ࡮ࡥࠩ㧜")
,l1l1l1_l1_ (u"ࠨࡖࡊࠫ㧝"):l1l1l1_l1_ (u"ࠩࡗࡳ࡬ࡵࠧ㧞")
,l1l1l1_l1_ (u"ࠪࡘࡐ࠭㧟"):l1l1l1_l1_ (u"࡙ࠫࡵ࡫ࡦ࡮ࡤࡹࠬ㧠")
,l1l1l1_l1_ (u"࡚ࠬࡏࠨ㧡"):l1l1l1_l1_ (u"࠭ࡔࡰࡰࡪࡥࠬ㧢")
,l1l1l1_l1_ (u"ࠧࡕࡖࠪ㧣"):l1l1l1_l1_ (u"ࠨࡖࡵ࡭ࡳ࡯ࡤࡢࡦࠣࡥࡳࡪࠠࡕࡱࡥࡥ࡬ࡵࠧ㧤")
,l1l1l1_l1_ (u"ࠩࡗࡒࠬ㧥"):l1l1l1_l1_ (u"ࠪࡘࡺࡴࡩࡴ࡫ࡤࠫ㧦")
,l1l1l1_l1_ (u"࡙ࠫࡘࠧ㧧"):l1l1l1_l1_ (u"࡚ࠬࡵࡳ࡭ࡨࡽࠬ㧨")
,l1l1l1_l1_ (u"࠭ࡔࡎࠩ㧩"):l1l1l1_l1_ (u"ࠧࡕࡷࡵ࡯ࡲ࡫࡮ࡪࡵࡷࡥࡳ࠭㧪")
,l1l1l1_l1_ (u"ࠨࡖࡆࠫ㧫"):l1l1l1_l1_ (u"ࠩࡗࡹࡷࡱࡳࠡࡣࡱࡨࠥࡉࡡࡪࡥࡲࡷࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㧬")
,l1l1l1_l1_ (u"ࠪࡘ࡛࠭㧭"):l1l1l1_l1_ (u"࡙ࠫࡻࡶࡢ࡮ࡸࠫ㧮")
,l1l1l1_l1_ (u"࡛ࠬࡍࠨ㧯"):l1l1l1_l1_ (u"࠭ࡕ࠯ࡕ࠱ࠤࡒ࡯࡮ࡰࡴࠣࡓࡺࡺ࡬ࡺ࡫ࡱ࡫ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㧰")
,l1l1l1_l1_ (u"ࠧࡗࡋࠪ㧱"):l1l1l1_l1_ (u"ࠨࡗ࠱ࡗ࠳ࠦࡖࡪࡴࡪ࡭ࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㧲")
,l1l1l1_l1_ (u"ࠩࡘࡋࠬ㧳"):l1l1l1_l1_ (u"࡙ࠪ࡬ࡧ࡮ࡥࡣࠪ㧴")
,l1l1l1_l1_ (u"࡚ࠫࡇࠧ㧵"):l1l1l1_l1_ (u"࡛ࠬ࡫ࡳࡣ࡬ࡲࡪ࠭㧶")
,l1l1l1_l1_ (u"࠭ࡁࡆࠩ㧷"):l1l1l1_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧ㧸")
,l1l1l1_l1_ (u"ࠨࡗࡎࠫ㧹"):l1l1l1_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪ㧺")
,l1l1l1_l1_ (u"࡙ࠪࡘ࠭㧻"):l1l1l1_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫ㧼")
,l1l1l1_l1_ (u"࡛࡙ࠬࠨ㧽"):l1l1l1_l1_ (u"࠭ࡕࡳࡷࡪࡹࡦࡿࠧ㧾")
,l1l1l1_l1_ (u"ࠧࡖ࡜ࠪ㧿"):l1l1l1_l1_ (u"ࠨࡗࡽࡦࡪࡱࡩࡴࡶࡤࡲࠬ㨀")
,l1l1l1_l1_ (u"࡙࡙ࠩࠬ㨁"):l1l1l1_l1_ (u"࡚ࠪࡦࡴࡵࡢࡶࡸࠫ㨂")
,l1l1l1_l1_ (u"࡛ࠫࡇࠧ㨃"):l1l1l1_l1_ (u"ࠬ࡜ࡡࡵ࡫ࡦࡥࡳࠦࡃࡪࡶࡼࠫ㨄")
,l1l1l1_l1_ (u"࠭ࡖࡆࠩ㨅"):l1l1l1_l1_ (u"ࠧࡗࡧࡱࡩࡿࡻࡥ࡭ࡣࠪ㨆")
,l1l1l1_l1_ (u"ࠨࡘࡑࠫ㨇"):l1l1l1_l1_ (u"࡙ࠩ࡭ࡪࡺ࡮ࡢ࡯ࠪ㨈")
,l1l1l1_l1_ (u"࡛ࠪࡋ࠭㨉"):l1l1l1_l1_ (u"ࠫ࡜ࡧ࡬࡭࡫ࡶࠤࡦࡴࡤࠡࡈࡸࡸࡺࡴࡡࠨ㨊")
,l1l1l1_l1_ (u"ࠬࡋࡈࠨ㨋"):l1l1l1_l1_ (u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧ㨌")
,l1l1l1_l1_ (u"࡚ࠧࡇࠪ㨍"):l1l1l1_l1_ (u"ࠨ࡛ࡨࡱࡪࡴࠧ㨎")
,l1l1l1_l1_ (u"ࠩ࡝ࡑࠬ㨏"):l1l1l1_l1_ (u"ࠪ࡞ࡦࡳࡢࡪࡣࠪ㨐")
,l1l1l1_l1_ (u"ࠫ࡟࡝ࠧ㨑"):l1l1l1_l1_ (u"ࠬࡠࡩ࡮ࡤࡤࡦࡼ࡫ࠧ㨒")
,l1l1l1_l1_ (u"࠭ࡁ࡙ࠩ㨓"):l1l1l1_l1_ (u"ࠧࣆ࡮ࡤࡲࡩ࠭㨔")
}
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ⛄")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡇࡌࡖࡣࠬ⛅")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠧศๆอู๋๐แศฬࠪ⛆"),l1l1l1_l1_ (u"ࠨษุ้ฬวࠠฮีสฬࠬ⛇"),l1l1l1_l1_ (u"ฺ่ࠩออสࠡษ็ึํ๗วาࠩ⛈")]
#headers = {l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⛉"):l1l1l1_l1_ (u"ࠫࠬ⛊")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l11l11_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l11l1ll_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛋"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⛌"),l1l1l1_l1_ (u"ࠧࠨ⛍"),399,l1l1l1_l1_ (u"ࠨࠩ⛎"),l1l1l1_l1_ (u"ࠩࠪ⛏"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⛐"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⛑"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⛒"),l1l1l1_l1_ (u"࠭ࠧ⛓"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ⛔"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩ⛕"),l1l1l1_l1_ (u"ࠩࠪ⛖"),l1l1l1_l1_ (u"ࠪࠫ⛗"),l1l1l1_l1_ (u"ࠫࠬ⛘"),l1l1l1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⛙"))
	html = response.content
	items = re.findall(l1l1l1_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⛚"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⛛"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⛜")+menu_name+title,l1l11l_l1_,391,l1l1l1_l1_ (u"ࠩࠪ⛝"),l1l1l1_l1_ (u"ࠪࠫ⛞"),l1l1l1_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ⛟")+str(seq))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛠"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⛡")+menu_name+l1l1l1_l1_ (u"ࠧๆะอหึอสࠡ฻ื์ฬฬ๊สࠩ⛢"),l1l11l_l1_,391,l1l1l1_l1_ (u"ࠨࠩ⛣"),l1l1l1_l1_ (u"ࠩࠪ⛤"),l1l1l1_l1_ (u"ࠪࡶࡦࡴࡤࡰ࡯ࡶࠫ⛥"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛦"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⛧")+menu_name+l1l1l1_l1_ (u"࠭รฺๆ์ࠤฬ๊รโๆส้ࠥะโ๋์่ห๐࠭⛨"),l1l11l_l1_,391,l1l1l1_l1_ (u"ࠧࠨ⛩"),l1l1l1_l1_ (u"ࠨࠩ⛪"),l1l1l1_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡲࡵࡶࡪࡧࡶࠫ⛫"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛬"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⛭")+menu_name+l1l1l1_l1_ (u"ࠬษูๅ๋ࠣห้๋ำๅี็หฯࠦสใ์ํ้ฬ๑ࠧ⛮"),l1l11l_l1_,391,l1l1l1_l1_ (u"࠭ࠧ⛯"),l1l1l1_l1_ (u"ࠧࠨ⛰"),l1l1l1_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡷࡪࡸࡩࡦࡵࠪ⛱"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⛲"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⛳")+menu_name+l1l1l1_l1_ (u"ࠫศ็ไศ็้๊ࠣ๐าสࠩ⛴"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭⛵"),391,l1l1l1_l1_ (u"࠭ࠧ⛶"),l1l1l1_l1_ (u"ࠧࠨ⛷"),l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ⛸"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⛹"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⛺")+menu_name+l1l1l1_l1_ (u"ู๊ࠫไิๆสฮ๋ࠥๅ๋ิฬࠫ⛻"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹࠧ⛼"),391,l1l1l1_l1_ (u"࠭ࠧ⛽"),l1l1l1_l1_ (u"ࠧࠨ⛾"),l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸࡻࡹࡨࡰࡹࡶࠫ⛿"))
	block = l1l1l1_l1_ (u"ࠩࠪ✀")
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡨࡨࡴࡸࠢࠨ✁"),html,re.DOTALL)
	if l1ll1l1_l1_: block += l1ll1l1_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ✂"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭✃"),l1l1l1_l1_ (u"࠭ࠧ✄"),l1l1l1_l1_ (u"ࠧࠨ✅"),l1l1l1_l1_ (u"ࠨࠩ✆"),l1l1l1_l1_ (u"ࠩࠪ✇"),l1l1l1_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ✈"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷ࡫࡬ࡦࡣࡶࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡦࡹࡩࡥࡧࠪ✉"),html,re.DOTALL)
	if l1ll1l1_l1_: block += l1ll1l1_l1_[0]
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ✊"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭✋"),l1l1l1_l1_ (u"ࠧࠨ✌"),9999)
	items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ✍"),block,re.DOTALL)
	first = True
	for l111ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l1l1_l1_ (u"ࠩส่ศ฿ไุ๊่ࠢฬํฯสࠩ✎"):
			if first:
				title = l1l1l1_l1_ (u"ࠪห้อแๅษ่ࠤࠬ✏")+title
				first = False
			else: title = l1l1l1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠࠨ✐")+title
		if title not in l1l1ll_l1_:
			if title==l1l1l1_l1_ (u"ࠬษแๅษ่ࠫ✑"): addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✒"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ✓")+menu_name+title,l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ✔"),391,l1l1l1_l1_ (u"ࠩࠪ✕"),l1l1l1_l1_ (u"ࠪࠫ✖"),l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࡠ࡯ࡲࡺ࡮࡫ࡳࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ✗"))
			elif title==l1l1l1_l1_ (u"๋ࠬำๅี็หฯ࠭✘"): addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✙"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ✚")+menu_name+title,l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵࠪ✛"),391,l1l1l1_l1_ (u"ࠩࠪ✜"),l1l1l1_l1_ (u"ࠪࠫ✝"),l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࡠ࡯ࡲࡺ࡮࡫ࡳࡠࡶࡹࡷ࡭ࡵࡷࡴࠩ✞"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✟"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ✠")+menu_name+title,l111ll_l1_,391)
	return html
def l11l11_l1_(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ✡"),l1l1l1_l1_ (u"ࠨࠩ✢"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭✣"),url,l1l1l1_l1_ (u"ࠪࠫ✤"),l1l1l1_l1_ (u"ࠫࠬ✥"),l1l1l1_l1_ (u"ࠬ࠭✦"),l1l1l1_l1_ (u"࠭ࠧ✧"),l1l1l1_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ✨"))
	html = response.content
	if type in [l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ✩"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬ✪")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ✫"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ✬"),l1l1l1_l1_ (u"ࠬ࠭✭"),url,block)
	elif type==l1l1l1_l1_ (u"࠭ࡡ࡭࡮ࡢࡱࡴࡼࡩࡦࡵࡢࡸࡻࡹࡨࡰࡹࡶࠫ✮"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࡦࡸࡣࡩ࡫ࡹࡩ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ✯"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif type==l1l1l1_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡱࡴࡼࡩࡦࡵࠪ✰"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡷࡳࡵ࠳ࡩ࡮ࡦࡥ࠱ࡱ࡯ࡳࡵࠢࡷࡰࡪ࡬ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠬࡺ࡯ࡱ࠯࡬ࡱࡩࡨ࠭࡭࡫ࡶࡸࠥࡺࡲࡪࡩ࡫ࡸࠧ✱"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ✲"),l1l1l1_l1_ (u"ࠫࠬ✳"),str(len(block)),type)
			items = re.findall(l1l1l1_l1_ (u"ࠧ࡯࡭ࡨࠢࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ✴"),block,re.DOTALL)
	elif type==l1l1l1_l1_ (u"࠭ࡴࡰࡲࡢ࡭ࡲࡪࡢࡠࡵࡨࡶ࡮࡫ࡳࠨ✵"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧࡵࡱࡳ࠱࡮ࡳࡤࡣ࠯࡯࡭ࡸࡺࠠࡵࡴ࡬࡫࡭ࡺࠨ࠯ࠬࡂ࠭࡫ࡵ࡯ࡵࡧࡵࠦ✶"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ✷"),l1l1l1_l1_ (u"ࠩࠪ✸"),str(len(block)),type)
			items = re.findall(l1l1l1_l1_ (u"ࠥ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨ✹"),block,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ✺"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡢࡴࡦ࡬࠲ࡶࡡࡨࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ✻"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ✼"),block,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭✽"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸࠬ✾"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		zzz = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ✿"),block,re.DOTALL)
		l11l1_l1_,l1l1l1ll1_l1_,l1111ll_l1_ = zip(*zzz)
		items = zip(l1l1l1ll1_l1_,l11l1_l1_,l1111ll_l1_)
	elif type==l1l1l1_l1_ (u"ࠪࡶࡦࡴࡤࡰ࡯ࡶࠫ❀"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡶࡹࡷ࡭ࡵࡷࡴࠤࠫ࠲࠯ࡅࠩ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ❁"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ❂"),block,re.DOTALL)
	elif l1l1l1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭❃") in type:
		seq = int(type[-1:])
		html = html.replace(l1l1l1_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ❄"),l1l1l1_l1_ (u"ࠨ࠾ࡨࡲࡩࡄ࠼ࡴࡶࡤࡶࡹࡄࠧ❅"))
		html = html.replace(l1l1l1_l1_ (u"ࠩ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ❆"),l1l1l1_l1_ (u"ࠪࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽ࡧࡱࡨࡃ࠭❇"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁࡹࡴࡢࡴࡷࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡳࡪ࠾ࠨ❈"),html,re.DOTALL)
		block = l1ll1l1_l1_[seq]
		if seq==6:
			zzz = re.findall(l1l1l1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭❉"),block,re.DOTALL)
			l1l1l1ll1_l1_,l1111ll_l1_,l11l1_l1_ = zip(*zzz)
			items = zip(l1l1l1ll1_l1_,l11l1_l1_,l1111ll_l1_)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡿࡷ࡮ࡪࡥࡣࡣࡵ࠭ࠬ❊"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0][0]
			if l1l1l1_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭❋") in url:
				items = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ❌"),block,re.DOTALL)
			elif l1l1l1_l1_ (u"ࠩ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳ࠬ❍") in url:
				items = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ❎"),block,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ❏"),l1l1l1_l1_ (u"ࠬ࠭❐"),str(len(items)),type)
	if not items and block:
		items = re.findall(l1l1l1_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ❑"),block,re.DOTALL)
	l1l1_l1_ = []
	for img,l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠬ❒") in title: continue
		if l1l1l1_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࠧ❓") in title:
			title = re.findall(l1l1l1_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡥࡳ࡫ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ❔"),title,re.DOTALL)
			title = title[0][1]#+l1l1l1_l1_ (u"ࠪࠤ࠲ࠦࠧ❕")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l1l1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ❖")+title
		title2 = re.findall(l1l1l1_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠭❗"),title,re.DOTALL)
		if title2: title = title2[0]
		title = unescapeHTML(title)
		if l1l1l1_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ❘") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❙"),menu_name+title,l111ll_l1_,393,img)
		elif l1l1l1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ❚") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❛"),menu_name+title,l111ll_l1_,393,img)
		elif l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠴࠭❜") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ❝"),menu_name+title,l111ll_l1_,393,img)
		elif l1l1l1_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫ❞") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❟"),menu_name+title,l111ll_l1_,391,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭❠"),menu_name+title,l111ll_l1_,392,img)
	if type not in [l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ❡"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬ❢")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭❣"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭❤"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❥"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬ❦")+title,l111ll_l1_,391,l1l1l1_l1_ (u"ࠧࠨ❧"),l1l1l1_l1_ (u"ࠨࠩ❨"),type)
	return
def l11l1ll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ❩"),l1l1l1_l1_ (u"ࠪࠫ❪"),l1l1l1_l1_ (u"ࠫࠬ❫"),url)
	server = SERVER(url,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ❬"))
	url = url.replace(server,l1l11l_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ❭"),url,l1l1l1_l1_ (u"ࠧࠨ❮"),l1l1l1_l1_ (u"ࠨࠩ❯"),l1l1l1_l1_ (u"ࠩࠪ❰"),l1l1l1_l1_ (u"ࠪࠫ❱"),l1l1l1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭❲"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ❳"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ❴"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ❵"),block,re.DOTALL)
		for img,l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ❶"),menu_name+title,l111ll_l1_,392,img)
	return
def PLAY(url):
	html = l1lll11l1l_l1_(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭❷"),url,l1l1l1_l1_ (u"ࠪࠫ❸"),l1l1l1_l1_ (u"ࠫࠬ❹"),l1l1l1_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ❺"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ❻"),url,l1l1l1_l1_ (u"ࠧࠨ❼"),l1l1l1_l1_ (u"ࠨࠩ❽"),l1l1l1_l1_ (u"ࠩࠪ❾"),l1l1l1_l1_ (u"ࠪࠫ❿"),l1l1l1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ➀"))
	#html = response.content
	if kodi_version>18.99: html = html.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ➁"),l1l1l1_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭➂"))
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ➃"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	l11l1_l1_ = []
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶ࠲ࡵࡰࡵ࡫ࡲࡲ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࡠࠨࡼ࡝ࠩࡠࠬࡸ࡮ࡥࡢࡦࡨࡶࢁࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠭ࡠࠨࡼ࡝ࠩࡠࠫ➄"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0][0]
		items = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡻࡳࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡵࡵࡳࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡰࡸࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡹ࡭ࡩࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭➅"),block,re.DOTALL)
		for type,l1111l_l1_,l1llllll1ll_l1_,title in items:
			#l111ll_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡸ࠰ࡤࡰ࡫ࡧࡪࡦࡴࡷࡺ࠳ࡩ࡯࡮࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࡦࡪ࡭ࡪࡰ࠰ࡥ࡯ࡧࡸ࠯ࡲ࡫ࡴࠬ➆")
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࡢࡦࡰ࡭ࡳ࠳ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡦࡲࡳࡤࡶ࡬ࡢࡻࡨࡶࡤࡧࡪࡢࡺࠩࡴࡴࡹࡴ࠾ࠩ➇")+l1111l_l1_+l1l1l1_l1_ (u"ࠬࠬ࡮ࡶ࡯ࡨࡁࠬ➈")+l1llllll1ll_l1_+l1l1l1_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠭➉")+type
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ➊")+title+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ➋")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	#WRITE_THIS(html)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠤ࡬ࡨࡂ࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨࠢࡦࡰࡦࡹࡳࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࡠࡢࠢࡽࠩࡠࡷࡧࡵࡸ࡜࡞ࠥࢀࠬࡣࠢ➌"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠥ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࠩࡴࡹࡦࡲࡩࡵࡻࠪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠥ➍"),block,re.DOTALL)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ➎"),l1l1l1_l1_ (u"ࠬ࠭➏"),str(items),str(block))
		for img,l111ll_l1_,l11ll111_l1_,lang in items:
			if l1l1l1_l1_ (u"࠭࠽ࠨ➐") in img:
				host = img.split(l1l1l1_l1_ (u"ࠧ࠾ࠩ➑"))[1]
				title = SERVER(host,l1l1l1_l1_ (u"ࠨࡪࡲࡷࡹ࠭➒"))
			else: title = l1l1l1_l1_ (u"ࠩࠪ➓")
			title = lang+l1l1l1_l1_ (u"ࠪࠤࠬ➔")+title
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ➕")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡢࡣࡤ࠭➖")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ➗"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭➘"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠨࠩ➙"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠩࠪ➚"): return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬ➛"),l1l1l1_l1_ (u"ࠫ࠰࠭➜"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ➝")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭➞"))
	return
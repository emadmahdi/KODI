# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ娼")
menu_name = l1l1l1_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ娽")
l1l11l_l1_ = WEBSITES[script_name][0]
#headers = l1l1l1_l1_ (u"ࠩࠪ娾")
#headers = {l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ娿"):l1l1l1_l1_ (u"ࠫࠬ婀")}
l1l111l1l11l_l1_ = 0
def MAIN(mode,url,text,type,page,name,image):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1l111l11lll_l1_(url,name,image)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l11l11_l1_(url,page,text)
	elif mode==145: results = l1l11l1l1l1l_l1_(url,page)
	elif mode==147: results = l1l111lllll1_l1_()
	elif mode==148: results = l1l11l111111_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婁"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ婂")+menu_name+l1l1l1_l1_ (u"ࠧใษษ้ฮ࠭婃"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡆࡰ࠵ࡈࡵ࠻ࡊࡍ࠾࡚࡯ࡗࡥࡊ࠵ࡘࡖ࠮࠹ࡊ࠷ࡇࡵࡱࡊࡻ࡝ࡅ࠹ࡻࡓࡂࠩ婄"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婅"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ婆")+menu_name+l1l1l1_l1_ (u"ูࠫิีࠨ婇"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳࡙ࡉࡎࡰࡨࡩ࡭ࡨ࡯ࡡ࡭ࠩ婈"),144)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婉"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ婊")+menu_name+l1l1l1_l1_ (u"ࠨ็๋ๆ฾࠭婋"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ婌"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ婍"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭婎")+menu_name+l1l1l1_l1_ (u"ࠬำำศสࠪ婏"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡁࡖ࡫ࡩࡘࡵࡣࡪࡣ࡯ࡇ࡙࡜ࠧ婐"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ婑"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ婒")+menu_name+l1l1l1_l1_ (u"ࠩส่฾อศࠨ婓"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ婔"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婕"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ婖")+menu_name+l1l1l1_l1_ (u"࠭วโๆส้ࠬ婗"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡳࡵࡱࡵࡩ࡫ࡸ࡯࡯ࡶࠪ婘"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ婙"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ婚")+menu_name+l1l1l1_l1_ (u"้ࠪำะวาษอࠫ婛"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ婜"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婝"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ婞")+menu_name+l1l1l1_l1_ (u"ࠧใืํีฮ࠭婟"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ婠"),144,l1l1l1_l1_ (u"ࠩࠪ婡"),l1l1l1_l1_ (u"ࠪࠫ婢"),l1l1l1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ婣"))
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婤"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ婥")+menu_name+l1l1l1_l1_ (u"ࠧหืไัࠬ婦"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ婧"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婨"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ婩")+menu_name+l1l1l1_l1_ (u"ࠫึฬ๊ิ์ฬࠫ婪"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠭婫"),144)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婬"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ婭")+menu_name+l1l1l1_l1_ (u"ࠨำสสั࠭婮"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࡂࡦࡵࡃࠧ婯"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ婰"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ婱"),l1l1l1_l1_ (u"ࠬ࠭婲"),9999)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婳"),menu_name+l1l1l1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ婴"),l1l1l1_l1_ (u"ࠨࠩ婵"),149,l1l1l1_l1_ (u"ࠩࠪ婶"),l1l1l1_l1_ (u"ࠪࠫ婷"),l1l1l1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ婸"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婹"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ婺")+menu_name+l1l1l1_l1_ (u"ࠧศๆิส๏ู๊สࠩ婻"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨࠩ婼"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婽"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ婾")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ัศศฯอࠬ婿"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭媀"),144)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媁"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ媂")+menu_name+l1l1l1_l1_ (u"ࠨษ็ฮฺ็อࠨ媃"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ媄"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媅"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭媆")+menu_name+l1l1l1_l1_ (u"ࠬอไใืํีฮ࠭媇"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ媈"),144,l1l1l1_l1_ (u"ࠧࠨ媉"),l1l1l1_l1_ (u"ࠨࠩ媊"),l1l1l1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭媋"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媌"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭媍")+menu_name+l1l1l1_l1_ (u"๋ࠬฮหษิหฯ๊้ࠦฬํ์อ࠭媎"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ媏"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媐"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ媑")+l1l1l1_l1_ (u"ࠩࡢ࡝࡙ࡉ࡟ࠨ媒")+l1l1l1_l1_ (u"้ࠪำะวาษอࠤฬ๊ศา่ส้ั࠭媓"),l1l1l1_l1_ (u"ࠫࠬ媔"),290)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ媕"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媖"),l1l1l1_l1_ (u"ࠧࠨ媗"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媘"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ媙")+menu_name+l1l1l1_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะฺࠠำห๎ฮ࠭媚"),l1l1l1_l1_ (u"ࠫࠬ媛"),147)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媜"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ媝")+menu_name+l1l1l1_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ媞"),l1l1l1_l1_ (u"ࠨࠩ媟"),148)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媠"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ媡")+menu_name+l1l1l1_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡ฻ิฬ๏ฯࠧ媢"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃแ๋ๆ่ࠫ媣"),144)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媤"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ媥")+menu_name+l1l1l1_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥอฬ็สํอࠬ媦"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡱࡴࡼࡩࡦࠩ媧"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媨"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭媩")+menu_name+l1l1l1_l1_ (u"ࠬฮอฬ࠼ุ้ࠣือ๋ษอࠤ฾ืศ๋หࠪ媪"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆีิั๏ฯࠧ媫"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媬"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ媭")+menu_name+l1l1l1_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ媮"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ媯"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ媰"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ媱")+menu_name+l1l1l1_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥอฬ็สํอࠬ媲"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡵࡨࡶ࡮࡫ࡳࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭媳"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媴"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ媵")+menu_name+l1l1l1_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢๆหึะ่็ࠩ媶"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ้วาฬ๋๊ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ媷"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ媸"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ媹")+menu_name+l1l1l1_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ媺"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ媻"),144)
	return
def l1l111l11lll_l1_(url,name,image):
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媼"),menu_name+l1l1l1_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ媽")+name,url,144,image)
	return
def l1l111lllll1_l1_():
	l11l11_l1_(l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ媾"))
	return
def l1l11l111111_l1_():
	l11l11_l1_(l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ媿"))
	return
def PLAY(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ嫀"),l1l1l1_l1_ (u"ࠧࠨ嫁"),l1l1l1_l1_ (u"ࠨࠩ嫂"),url)
	#url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ嫃")
	#items = re.findall(l1l1l1_l1_ (u"ࠪࡺࡂ࠮࠮ࠫࡁࠬࠨࠬ嫄"),url,re.DOTALL)
	#id = items[0]
	#l111ll_l1_ = l1l1l1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ嫅")+id
	#PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嫆"))
	#return
	l1l1l1_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ嫇")
	url = url.split(l1l1l1_l1_ (u"ࠧࠧࠩ嫈"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l1l111ll1ll1_l1_(cc,url,index):
	level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = index.split(l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ嫉"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ嫊"),l1l1l1_l1_ (u"ࠪࠫ嫋"),index,l1l1l1_l1_ (u"ࠫࡋࡏࡒࡔࡖࠪ嫌")+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ嫍")+url)
	l1l111l11l11_l1_,l1l111l11ll1_l1_ = [],[]
	# l11ll1111l1_l1_ l1l11l11l1l1_l1_    should be the first item in the l1l111l11l11_l1_ list
	if l1l1l1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ嫎") in url: l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠࠦ嫏"))
	# l11ll1111l1_l1_ search l1l11l111l11_l1_      should be the first item in the l1l111l11l11_l1_ list
	if l1l1l1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ嫐") in url: l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣࠢ嫑"))
	# main page
	if level==l1l1l1_l1_ (u"ࠪ࠵ࠬ嫒"): l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嫓"))
	# search results
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嫔"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣࠢ嫕"))
	# l1l11l1111l1_l1_ l1l111llll1l_l1_ & main page l1l111llll1l_l1_ l1l11l111l11_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡤࡥ࡞ࠫࡪࡴࡴࡳ࡫ࡨࡷࠬࡣࠢ嫖"))
	# l1l111ll1lll_l1_ l1lll1lll1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡥࡦ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࡡ࠳࡞࡝ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ嫗"))
	l1l11l111l1l_l1_,dd,l1l1111llll1_l1_ = l1l111l111l1_l1_(cc,l1l1l1_l1_ (u"ࠩࠪ嫘"),l1l111l11l11_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ嫙"),str(dd))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ嫚"),l1l1l1_l1_ (u"ࠬ࠭嫛"),l1l1l1_l1_ (u"࠭ࠧ嫜"),str(len(dd)))
	if level==l1l1l1_l1_ (u"ࠧ࠲ࠩ嫝") and l1l11l111l1l_l1_:
		if len(dd)>1 and l1l1l1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ嫞") not in url:
			for zz in range(len(dd)):
				l1l111l1llll_l1_ = str(zz)
				l1l111l11l11_l1_ = []
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡧࡨࡠࠨ嫟")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ嫠"))
				# l1l11l1111l1_l1_ l1l111llll1l_l1_
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡩࡪ࡛ࠣ嫡")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠧࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩࡠࠦ嫢"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡤࡥ࡝ࠥ嫣")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠢ࡞ࠤ嫤"))
				succeeded,item,l11l1l11_l1_ = l1l111l111l1_l1_(dd,l1l1l1_l1_ (u"ࠨࠩ嫥"),l1l111l11l11_l1_)
				if succeeded: l1l111l11ll1_l1_.append([item,url,l1l1l1_l1_ (u"ࠩ࠵࠾࠿࠭嫦")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ嫧")])
				#success = l1l11l11lll1_l1_(item,url,l1l1l1_l1_ (u"ࠫ࠷ࡀ࠺ࠨ嫨")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ嫩"))
				#if success: l1l111ll11l1_l1_ += 1
				#succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,token = l1l11l1ll11l_l1_(item)
				#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫪"),menu_name+title,l111ll_l1_,144,l1l1l1_l1_ (u"ࠧࠨ嫫"),l1l1l1_l1_ (u"ࠨ࠴࠽࠾ࠬ嫬")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ嫭"))
				#l1l111ll11l1_l1_ += 1
			# main page l1l111llll1l_l1_ l1l11l111l11_l1_
			l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞ࠤ嫮"))
			succeeded,item,l11l1l11_l1_ = l1l111l111l1_l1_(cc,l1l1l1_l1_ (u"ࠫࠬ嫯"),l1l111l11l11_l1_)
			#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭嫰"),str(cc))
			if succeeded and l1l111l11ll1_l1_ and l1l1l1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ嫱") in list(item.keys()):
				l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ嫲")
				l1l111l11ll1_l1_.append([item,l111ll_l1_,l1l1l1_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ嫳")])
	return dd,l1l11l111l1l_l1_,l1l111l11ll1_l1_,l1l1111llll1_l1_
def l1l1111lllll_l1_(cc,dd,url,index):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ嫴"),l1l1l1_l1_ (u"ࠪࠫ嫵"),index,l1l1l1_l1_ (u"ࠫࡘࡋࡃࡐࡐࡇࠫ嫶")+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ嫷")+url)
	level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = index.split(l1l1l1_l1_ (u"࠭࠺࠻ࠩ嫸"))
	l1l111l11l11_l1_,l1l111lll111_l1_ = [],[]
	# search results
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嫹"))
	# main page
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡦࡧ࡟ࠧ嫺")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ嫻"))
	# l1l11llll1l_l1_ l1l111llll1l_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ嫼"))
	# l11ll1111l1_l1_ search & l1l11l11l1l1_l1_ & l1l11l111l11_l1_
	if l1l1l1_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ嫽") in url: l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ嫾"))
	elif l1l1l1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ嫿") in url: l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嬀"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡦࡧ࡟ࠧ嬁")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ嬂"))
	# l1l11llll1l_l1_ l1l1ll1lll_l1_ & l1l111llll1l_l1_ filters
	if l1l1l1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ嬃") in url or (l1l1l1_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ嬄") in url and l1l1l1_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ嬅") not in url):
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡤࡥ࡝ࠥ嬆")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嬇"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡦࡧ࡟ࠧ嬈")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ嬉"))
	# l1l11l1111l1_l1_ search
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡨࡩࡡࠢ嬊")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠦࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嬋"))
	# main page
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡪࡤ࡜ࠤ嬌")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ嬍"))
	# l11ll1111l1_l1_ l1l11l11l1l1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡥࡦ࡞ࠦ嬎")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠣ࡟ࠥ嬏"))
	l1l11l11111l_l1_,ee,l1l111ll1l11_l1_ = l1l111l111l1_l1_(dd,l1l1l1_l1_ (u"ࠩࠪ嬐"),l1l111l11l11_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ嬑"),str(ee))
	#DIALOG_OK()
	if level==l1l1l1_l1_ (u"ࠫ࠷࠭嬒") and l1l11l11111l_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1l111l11l11_l1_ = []
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ嬓")+index2+l1l1l1_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ嬔"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡦࡧ࡞ࠦ嬕")+index2+l1l1l1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ嬖"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡨࡩࡠࠨ嬗")+index2+l1l1l1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ嬘"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡪ࡫࡛ࠣ嬙")+index2+l1l1l1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ嬚"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡥࡦ࡝ࠥ嬛")+index2+l1l1l1_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ嬜"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡧࡨ࡟ࠧ嬝")+index2+l1l1l1_l1_ (u"ࠤࡠࠦ嬞"))
				succeeded,item,l11l1l11_l1_ = l1l111l111l1_l1_(ee,l1l1l1_l1_ (u"ࠪࠫ嬟"),l1l111l11l11_l1_)
				if succeeded: l1l111lll111_l1_.append([item,url,l1l1l1_l1_ (u"ࠫ࠸ࡀ࠺ࠨ嬠")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠬࡀ࠺ࠨ嬡")+index2+l1l1l1_l1_ (u"࠭࠺࠻࠲ࠪ嬢")])
				#success = l1l11l11lll1_l1_(item,url,l1l1l1_l1_ (u"ࠧ࠴࠼࠽ࠫ嬣")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ嬤")+index2+l1l1l1_l1_ (u"ࠩ࠽࠾࠵࠭嬥"))
				#if success: l1l11l1111ll_l1_ += 1
				#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ嬦"),str(l11l1l11_l1_)+l1l1l1_l1_ (u"ࠫࠥࠦࠠࠨ嬧")+str(item))
				#l1l11l1111ll_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,token = l1l11l1ll11l_l1_(item)
				#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嬨"),menu_name+title,l111ll_l1_,144,img,l1l1l1_l1_ (u"࠭࠳࠻࠼ࠪ嬩")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠧ࠻࠼ࠪ嬪")+index2+l1l1l1_l1_ (u"ࠨ࠼࠽࠴ࠬ嬫"))
			# search l1l11l111l11_l1_
			l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ嬬"))
			# search l1l11l111l11_l1_
			l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡨࡩࡡ࠱࡞ࠤ嬭"))
			succeeded,item,l11l1l11_l1_ = l1l111l111l1_l1_(dd,l1l1l1_l1_ (u"ࠫࠬ嬮"),l1l111l11l11_l1_)
			if succeeded and l1l111lll111_l1_ and l1l1l1_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ嬯") in list(item.keys()):
				l1l111lll111_l1_.append([item,url,l1l1l1_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ嬰")])
			#success = l1l11l11lll1_l1_(item,url,l1l1l1_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ嬱"))
			#if success: l1l11l1111ll_l1_ += 1
			#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ嬲"),str(item))
			#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪ嬳"),l111ll_l1_+l1l1l1_l1_ (u"ࠪࠤࠥࠦࠧ嬴")+token)
	return ee,l1l11l11111l_l1_,l1l111lll111_l1_,l1l111ll1l11_l1_
def l1l111l1l111_l1_(cc,ee,url,index):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ嬵"),l1l1l1_l1_ (u"ࠬ࠭嬶"),index,l1l1l1_l1_ (u"࠭ࡔࡉࡋࡕࡈࠬ嬷")+l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ嬸")+url)
	level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = index.split(l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ嬹"))
	l1l111l11l11_l1_,l1l111l1l1ll_l1_ = [],[]
	# search results
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡨࡩࡠࠨ嬺")+index2+l1l1l1_l1_ (u"ࠥࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡶࡦࡴࡷ࡭ࡨࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嬻"))
	# l11ll1111l1_l1_ l1l11l11l1l1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡪ࡫࡛ࠣ嬼")+index2+l1l1l1_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ嬽"))
	# l1l11l11ll1l_l1_ l1lll1lll1_l1_ l1l111llll1l_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡥࡦ࡝ࠥ嬾")+index2+l1l1l1_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ嬿"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡧࡨ࡟ࠧ孀")+index2+l1l1l1_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ孁"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡩࡪࡡࠢ孂")+index2+l1l1l1_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ孃"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡫ࡥ࡜ࠤ孄")+index2+l1l1l1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ孅"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡦࡧ࡞ࠦ孆")+index2+l1l1l1_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ孇"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡨࡩࡠࠨ孈")+index2+l1l1l1_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ孉"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ孊"))
	# l1l11l1111l1_l1_ l1l11l1ll1l1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ孋"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ孌"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡦࡧ࡞ࠦ孍")+index2+l1l1l1_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ孎"))
	# main page
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡨࡩࡠࠨ孏")+index2+l1l1l1_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ子"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡪ࡫ࠢ孑"))
	l1l11l111lll_l1_,ff,l1l11l1l1lll_l1_ = l1l111l111l1_l1_(ee,l1l1l1_l1_ (u"ࠬ࠭孒"),l1l111l11l11_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ孓"),str(ff))
	if level==l1l1l1_l1_ (u"ࠧ࠴ࠩ孔") and l1l11l111lll_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1l111llll11_l1_ = str(zz)
				#DIALOG_OK()
				l1l111l11l11_l1_ = []
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡨࡩ࡟ࠧ孕")+l1l111llll11_l1_+l1l1l1_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ孖"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡪ࡫ࡡࠢ字")+l1l111llll11_l1_+l1l1l1_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ存"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡬ࡦ࡜ࠤ孙")+l1l111llll11_l1_+l1l1l1_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ孚"))
				l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡧࡨ࡞ࠦ孛")+l1l111llll11_l1_+l1l1l1_l1_ (u"ࠣ࡟ࠥ孜"))
				succeeded,item,l11l1l11_l1_ = l1l111l111l1_l1_(ff,l1l1l1_l1_ (u"ࠩࠪ孝"),l1l111l11l11_l1_)
				#succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,token = l1l11l1ll11l_l1_(item)
				#addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ孞"),menu_name+l111ll_l1_,l111ll_l1_,143,img)
				if succeeded: l1l111l1l1ll_l1_.append([item,url,l1l1l1_l1_ (u"ࠫ࠹ࡀ࠺ࠨ孟")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠬࡀ࠺ࠨ孠")+index2+l1l1l1_l1_ (u"࠭࠺࠻ࠩ孡")+l1l111llll11_l1_])
				#success = l1l11l11lll1_l1_(item,url,l1l1l1_l1_ (u"ࠧ࠵࠼࠽ࠫ孢")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ季")+index2+l1l1l1_l1_ (u"ࠩ࠽࠾ࠬ孤")+l1l111llll11_l1_)
				#if success: l1l111ll1111_l1_ += 1
	return ff,l1l11l111lll_l1_,l1l111l1l1ll_l1_,l1l11l1l1lll_l1_
def l1l111l111l1_l1_(l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_,l1l111l1lll1_l1_):
	cc,l1l1l1ll1l1_l1_ = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	dd,l1l1l1ll1l1_l1_ = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	ee,l1l1l1ll1l1_l1_ = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	ff,l1l1l1ll1l1_l1_ = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	item,render = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	count = len(l1l111l1lll1_l1_)
	for ii in range(count):
		try:
			out = eval(l1l111l1lll1_l1_[ii])
			#if isinstance(out,dict): out = l1l1l1_l1_ (u"ࠪࠫ孥")
			return True,out,ii+1
		except: pass
	return False,l1l1l1_l1_ (u"ࠫࠬ学"),0
def l11l11_l1_(url,index=l1l1l1_l1_ (u"ࠬ࠭孧"),data=l1l1l1_l1_ (u"࠭ࠧ孨")):
	l1l111l11ll1_l1_,l1l111lll111_l1_,l1l111l1l1ll_l1_ = [],[],[]
	if l1l1l1_l1_ (u"ࠧ࠻࠼ࠪ孩") not in index: index = l1l1l1_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ孪")
	level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = index.split(l1l1l1_l1_ (u"ࠩ࠽࠾ࠬ孫"))
	if level==l1l1l1_l1_ (u"ࠪ࠸ࠬ孬"): level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = l1l1l1_l1_ (u"ࠫ࠶࠭孭"),l1l111l1llll_l1_,index2,l1l111llll11_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭孮"),l1l1l1_l1_ (u"࠭ࠧ孯"),index,url)
	data = data.replace(l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ孰"),l1l1l1_l1_ (u"ࠨࠩ孱"))
	html,cc,data2 = l1l111lll11l_l1_(url,data)
	l1l1l1_l1_ (u"ࠤࠥࠦࠏࠏࡩࡧࠢࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠠࡪࡰࠣࡹࡷࡲࠠࡰࡴࠣࠫ࠴ࡻࡳࡦࡴ࠲ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠥࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࡏࡣࡰࡩࠧ࠴ࠪࡀࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡࡰࡲࡸࠥࡵࡷ࡯ࡧࡵ࠾ࠥࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠ࡯ࡱࡷࠤࡴࡽ࡮ࡦࡴ࠽ࠤࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠩࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࠫࡰࡹࡱࡩࡷࡔࡁࡎࡇ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡳࡼࡴࡥࡳ࡝࠳ࡡࡠ࠷࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭࡯࡭ࡳࡱࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡯ࡸࡰࡨࡶࡓࡇࡍࡆ࠮࡯࡭ࡳࡱࠬ࠲࠶࠷࠭ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠧࠨࠢ孲")
	index = level+l1l1l1_l1_ (u"ࠪ࠾࠿࠭孳")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠫ࠿ࡀࠧ孴")+index2+l1l1l1_l1_ (u"ࠬࡀ࠺ࠨ孵")+l1l111llll11_l1_
	if level in [l1l1l1_l1_ (u"࠭࠱ࠨ孶"),l1l1l1_l1_ (u"ࠧ࠳ࠩ孷"),l1l1l1_l1_ (u"ࠨ࠵ࠪ學")]:
		dd,l1l11l111l1l_l1_,l1l111l11ll1_l1_,l1l1111llll1_l1_ = l1l111ll1ll1_l1_(cc,url,index)
		if not l1l11l111l1l_l1_: return
		l1l111ll11l1_l1_ = len(l1l111l11ll1_l1_)
		if l1l111ll11l1_l1_<2:
			if level==l1l1l1_l1_ (u"ࠩ࠴ࠫ孹"): level = l1l1l1_l1_ (u"ࠪ࠶ࠬ孺")
			l1l111l11ll1_l1_ = []
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ孻"),l1l1l1_l1_ (u"ࠬ࠭孼"),index,l1l1l1_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠱࡝ࡰࠪ孽")+l1l1l1_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ孾")+str(l1l1111llll1_l1_)+l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ孿")+l1l1l1_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ宀")+str(len(dd))+l1l1l1_l1_ (u"ࠪࡠࡳ࠭宁")+l1l1l1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ宂")+str(l1l111ll11l1_l1_)+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ它")+url)
	index = level+l1l1l1_l1_ (u"࠭࠺࠻ࠩ宄")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠧ࠻࠼ࠪ宅")+index2+l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ宆")+l1l111llll11_l1_
	if level in [l1l1l1_l1_ (u"ࠩ࠵ࠫ宇"),l1l1l1_l1_ (u"ࠪ࠷ࠬ守")]:
		ee,l1l11l11111l_l1_,l1l111lll111_l1_,l1l111ll1l11_l1_ = l1l1111lllll_l1_(cc,dd,url,index)
		if not l1l11l11111l_l1_: return
		l1l11l1111ll_l1_ = len(l1l111lll111_l1_)
		if l1l11l1111ll_l1_<2:
			if level==l1l1l1_l1_ (u"ࠫ࠷࠭安"): level = l1l1l1_l1_ (u"ࠬ࠹ࠧ宊")
			l1l111lll111_l1_ = []
		#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ宋"),l1l1l1_l1_ (u"ࠧࠨ完"),index,l1l1l1_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠴࡟ࡲࠬ宍")+l1l1l1_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭宎")+str(l1l111ll1l11_l1_)+l1l1l1_l1_ (u"ࠪࡠࡳ࠭宏")+l1l1l1_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭宐")+str(len(ee))+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ宑")+l1l1l1_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ宒")+str(l1l11l1111ll_l1_)+l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ宓")+url)
	index = level+l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ宔")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠩ࠽࠾ࠬ宕")+index2+l1l1l1_l1_ (u"ࠪ࠾࠿࠭宖")+l1l111llll11_l1_
	if level in [l1l1l1_l1_ (u"ࠫ࠸࠭宗")]:
		ff,l1l11l111lll_l1_,l1l111l1l1ll_l1_,l1l11l1l1lll_l1_ = l1l111l1l111_l1_(cc,ee,url,index)
		if not l1l11l111lll_l1_: return
		l1l111ll1111_l1_ = len(l1l111l1l1ll_l1_)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭官"),l1l1l1_l1_ (u"࠭ࠧ宙"),index,l1l1l1_l1_ (u"ࠧ࡭ࡧࡹࡩࡱࡀࠠ࠴࡞ࡱࠫ定")+l1l1l1_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ宛")+str(l1l11l1l1lll_l1_)+l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ宜")+l1l1l1_l1_ (u"ࠪࡰࡪࡴࡧࡵࡪ࠽ࠤࠬ宝")+str(len(ff))+l1l1l1_l1_ (u"ࠫࡡࡴࠧ实")+l1l1l1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷ࠾ࠥ࠭実")+str(l1l111ll1111_l1_)+l1l1l1_l1_ (u"࠭࡜࡯ࠩ宠")+url)
	for item,url,index in l1l111l11ll1_l1_+l1l111lll111_l1_+l1l111l1l1ll_l1_:
		success = l1l11l11lll1_l1_(item,url,index)
	return
def l1l11l11lll1_l1_(item,url=l1l1l1_l1_ (u"ࠧࠨ审"),index=l1l1l1_l1_ (u"ࠨࠩ客")):
	if l1l1l1_l1_ (u"ࠩ࠽࠾ࠬ宣") in index: level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = index.split(l1l1l1_l1_ (u"ࠪ࠾࠿࠭室"))
	else: level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = l1l1l1_l1_ (u"ࠫ࠶࠭宥"),l1l1l1_l1_ (u"ࠬ࠶ࠧ宦"),l1l1l1_l1_ (u"࠭࠰ࠨ宧"),l1l1l1_l1_ (u"ࠧ࠱ࠩ宨")
	succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,l1l11l1l11l1_l1_ = l1l11l1ll11l_l1_(item)
	#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ宩"),url)
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪ宪"),l111ll_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ宫"),l111ll_l1_+l1l1l1_l1_ (u"ࠫࠥࠦࠠࠨ宬")+title)
	# needed for l1l11l1111l1_l1_ l1l11l1ll1l1_l1_ next page
	# and needed for l1l11l1111l1_l1_ l1l11l1ll1l1_l1_ sub-l1lll1lll1_l1_
	#if (l1l1l1_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠹࠵࠭宭") in l111ll_l1_ or l1l1l1_l1_ (u"࠭ࡶࡪࡧࡺࡁ࠹࠿ࠧ宮") in l111ll_l1_) and (l1l1l1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ宯") in l111ll_l1_ or l1l1l1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ宰") in l111ll_l1_): l111ll_l1_ = url
	cond1 = l1l1l1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ宱") in l111ll_l1_ or l1l1l1_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭宲") in l111ll_l1_ or l1l1l1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ害") in l111ll_l1_
	cond2 = l1l1l1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ宴") in l111ll_l1_ or l1l1l1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ宵") in l111ll_l1_
	if cond1 or cond2: l111ll_l1_ = url
	cond1 = l1l1l1_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ家") not in l111ll_l1_ and l1l1l1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ宷") not in l111ll_l1_
	cond2 = l1l1l1_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ宸") not in l111ll_l1_  and l1l1l1_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭容") not in l111ll_l1_
	if index[0:5]==l1l1l1_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ宺") and cond1 and cond2: l111ll_l1_ = url
	if l1l1l1_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ宻") in url or l1l1l1_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ宼") in l111ll_l1_:
		level,l1l111l1llll_l1_,index2,l1l111llll11_l1_ = l1l1l1_l1_ (u"ࠧ࠲ࠩ宽"),l1l1l1_l1_ (u"ࠨ࠲ࠪ宾"),l1l1l1_l1_ (u"ࠩ࠳ࠫ宿"),l1l1l1_l1_ (u"ࠪ࠴ࠬ寀")
		index = l1l1l1_l1_ (u"ࠫࠬ寁")
	data2 = l1l1l1_l1_ (u"ࠬ࠭寂")
	if l1l1l1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ寃") in l111ll_l1_ or l1l1l1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭寄") in l111ll_l1_ or l1l1l1_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭寅") in url:
		data = settings.getSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ密"))
		if data.count(l1l1l1_l1_ (u"ࠪ࠾࠿ࡀࠧ寇"))==4:
			l1l11l111ll1_l1_,key,l1l111llllll_l1_,l1l111ll111l_l1_,token = data.split(l1l1l1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ寈"))
			data2 = l1l11l111ll1_l1_+l1l1l1_l1_ (u"ࠬࡀ࠺࠻ࠩ寉")+key+l1l1l1_l1_ (u"࠭࠺࠻࠼ࠪ寊")+l1l111llllll_l1_+l1l1l1_l1_ (u"ࠧ࠻࠼࠽ࠫ寋")+l1l111ll111l_l1_+l1l1l1_l1_ (u"ࠨ࠼࠽࠾ࠬ富")+l1l11l1l11l1_l1_
			if l1l1l1_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ寍") in url and not l111ll_l1_: l111ll_l1_ = url
			else: l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ寎")+key
	if not title:
		global l1l111l1l11l_l1_
		l1l111l1l11l_l1_ += 1
		title = l1l1l1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࠧ寏")+str(l1l111l1l11l_l1_)
		index = l1l1l1_l1_ (u"ࠬ࠹ࠧ寐")+l1l1l1_l1_ (u"࠭࠺࠻ࠩ寑")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠧ࠻࠼ࠪ寒")+index2+l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ寓")+l1l111llll11_l1_
	#if l1l1l1_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ寔") in url: l111ll_l1_ = url
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ寕"),l1l1l1_l1_ (u"ࠫࠬ寖"),title,index+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ寗")+l111ll_l1_)
	#if not l111ll_l1_: l111ll_l1_ = url
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ寘"),l1l1l1_l1_ (u"ࠧࠨ寙"),str(succeeded),title+l1l1l1_l1_ (u"ࠨࠢ࠽࠾࠿ࠦࠧ寚")+l111ll_l1_)
	#if l1l1l1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ寛") in url and index==l1l1l1_l1_ (u"ࠪ࠴ࠬ寜"):
	#	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寝"),menu_name+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ寞") in str(item): return False			# l1l11l11ll11_l1_ not items
	elif l1l1l1_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭察") in l111ll_l1_: return False
	elif l1l1l1_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ寠") in l111ll_l1_: return False
	elif l1l1l1_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ寡") in list(item.keys()) or l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ寢") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l1l1_l1_ (u"ࠪ࠾࠿࠭寣")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠫ࠿ࡀࠧ寤")+index2+l1l1l1_l1_ (u"ࠬࡀ࠺ࠨ寥")+l1l111llll11_l1_
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭實"),menu_name+l1l1l1_l1_ (u"ࠧ࠻࠼ࠣࠫ寧")+l1l1l1_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ寨"),l111ll_l1_,144,img,index,data2)
	elif l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ審") in l111ll_l1_:
		title = l1l1l1_l1_ (u"ࠪ࠾࠿ࠦࠧ寪")+title
		index = l1l1l1_l1_ (u"ࠫ࠸࠭寫")+l1l1l1_l1_ (u"ࠬࡀ࠺ࠨ寬")+l1l111l1llll_l1_+l1l1l1_l1_ (u"࠭࠺࠻ࠩ寭")+index2+l1l1l1_l1_ (u"ࠧ࠻࠼ࠪ寮")+l1l111llll11_l1_
		url = url.replace(l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ寯"),l1l1l1_l1_ (u"ࠩࠪ寰"))
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ寱"),menu_name+title,url,145,l1l1l1_l1_ (u"ࠫࠬ寲"),index,l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ寳"))
	elif l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ寴") in url and not l111ll_l1_:
		index = l1l1l1_l1_ (u"ࠧ࠴ࠩ寵")+l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ寶")+l1l111l1llll_l1_+l1l1l1_l1_ (u"ࠩ࠽࠾ࠬ寷")+index2+l1l1l1_l1_ (u"ࠪ࠾࠿࠭寸")+l1l111llll11_l1_
		title = l1l1l1_l1_ (u"ࠫ࠿ࡀࠠࠨ对")+title
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寺"),menu_name+title,url,144,img,index,data2)
	#elif l1l1l1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ寻") in l111ll_l1_: return False
	elif l1l1l1_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࠨ导") in l111ll_l1_ and url==l1l11l_l1_:
		title = l1l1l1_l1_ (u"ࠨ࠼࠽ࠤࠬ寽")+title
		index = l1l1l1_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭対")
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ寿"),menu_name+title,l111ll_l1_,144,img,index,data2)
	elif not l111ll_l1_ and l1l1l1_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ尀") in str(item):
		title = l1l1l1_l1_ (u"ࠬࡀ࠺ࠡࠩ封")+title
		index = l1l1l1_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ専")
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ尃"),menu_name+title,url,144,img,index)
	elif l1l1l1_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ射") in str(item):
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ尅"),menu_name+title,l1l1l1_l1_ (u"ࠪࠫ将"),9999)
	#elif l1l1l1_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ將") in l111ll_l1_ and l1l1l1_l1_ (u"ࠬࡨࡰ࠾ࠩ專") not in l111ll_l1_:
	#	title = l1l1l1_l1_ (u"࠭࠺࠻ࠢࠪ尉")+title
	#	index = l1l1l1_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ尊")
	#	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尋"),menu_name+title,l111ll_l1_,144,img,index)
	elif l11l1llllll_l1_:
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ尌"),menu_name+l11l1llllll_l1_+title,l111ll_l1_,143,img)
	elif l1l1l1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ對") in l111ll_l1_:
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ導"),menu_name+l1l1l1_l1_ (u"ࠬࡒࡉࡔࡖࠪ小")+count+l1l1l1_l1_ (u"࠭࠺ࠡࠢࠪ尐")+title,l111ll_l1_,144,img,index)
	#elif l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭少") in l111ll_l1_ and l1l1l1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ尒") not in l111ll_l1_ and l1l1l1_l1_ (u"ࠩࡷࡁ࠵࠭尓") not in l111ll_l1_:
	#	l1l111lll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ尔"),l111ll_l1_,re.DOTALL)
	#	l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭尕")+l1l111lll1ll_l1_[0]
	#	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ尖"),menu_name+l1l1l1_l1_ (u"࠭ࡌࡊࡕࡗࠫ尗")+count+l1l1l1_l1_ (u"ࠧ࠻ࠢࠣࠫ尘")+title,l111ll_l1_,144,img,index)
	elif l1l1l1_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ尙") in l111ll_l1_:
		l111ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ尚"),1)[0]
		addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ尛"),menu_name+title,l111ll_l1_,143,img,duration)
	elif l1l1l1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ尜") in l111ll_l1_:
		if l1l1l1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ尝") in l111ll_l1_ and count:
			l1l111lll1ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭尞"),1)[1]
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ尟")+l1l111lll1ll_l1_
			index = l1l1l1_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ尠")
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ尡"),menu_name+l1l1l1_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ尢")+count+l1l1l1_l1_ (u"ࠫ࠿ࠦࠠࠨ尣")+title,l111ll_l1_,144,img,index)
		else:
			l111ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ尤"),1)[0]
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ尥"),menu_name+title,l111ll_l1_,143,img,duration)
	elif l1l1l1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ尦") in l111ll_l1_ or l1l1l1_l1_ (u"ࠨ࠱ࡦ࠳ࠬ尧") in l111ll_l1_ or (l1l1l1_l1_ (u"ࠩ࠲ࡄࠬ尨") in l111ll_l1_ and l111ll_l1_.count(l1l1l1_l1_ (u"ࠪ࠳ࠬ尩"))==3):
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ尪"),menu_name+l1l1l1_l1_ (u"ࠬࡉࡈࡏࡎࠪ尫")+count+l1l1l1_l1_ (u"࠭࠺ࠡࠢࠪ尬")+title,l111ll_l1_,144,img,index)
	elif l1l1l1_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ尭") in l111ll_l1_:
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尮"),menu_name+l1l1l1_l1_ (u"ࠩࡘࡗࡊࡘࠧ尯")+count+l1l1l1_l1_ (u"ࠪ࠾ࠥࠦࠧ尰")+title,l111ll_l1_,144,img,index)
	else:
		if not l111ll_l1_: l111ll_l1_ = url
		title = l1l1l1_l1_ (u"ࠫ࠿ࡀࠠࠨ就")+title
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ尲"),menu_name+title,l111ll_l1_,144,img,index,data2)
	return True
def l1l11l1ll11l_l1_(item):
	succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,token = False,l1l1l1_l1_ (u"࠭ࠧ尳"),l1l1l1_l1_ (u"ࠧࠨ尴"),l1l1l1_l1_ (u"ࠨࠩ尵"),l1l1l1_l1_ (u"ࠩࠪ尶"),l1l1l1_l1_ (u"ࠪࠫ尷"),l1l1l1_l1_ (u"ࠫࠬ尸"),l1l1l1_l1_ (u"ࠬ࠭尹"),l1l1l1_l1_ (u"࠭ࠧ尺")
	#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ尻"),str(item))
	if not isinstance(item,dict): return succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,token
	for l1l11l1l1l11_l1_ in list(item.keys()):
		render = item[l1l11l1l1l11_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l1l1l1_l1_ (u"ࠨࠩ尼"),str(render))
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪ尽"),str(render))
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ尾"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ尿"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡰ࡮ࡴࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ局"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ屁"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ层"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ屃"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ屄"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ居"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ屆"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ屇"))
	# required for l1l11llll1l_l1_ l1l111ll1l1l_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ屈"))
	# l1l11l1111l1_l1_ l1l111llll1l_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ屉"))
	succeeded,title,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ届"),l1l1l1_l1_ (u"ࠩࠪ屋"),l1l1l1_l1_ (u"ࠪࠫ屌"),str(l11l1l11_l1_))
	#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ屍"),str(l11l1l11_l1_)+l1l1l1_l1_ (u"ࠬࠦࠠࠡࠩ屎")+str(title))
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ屏"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ屐"))
	# l1l11l111l11_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ屑"))
	# header feed
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ屒"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ屓"))
	# required for l1l11llll1l_l1_ l1l111l1ll11_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ屔"))
	# l1l11l1111l1_l1_ l1l111llll1l_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ展"))
	succeeded,l111ll_l1_,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ屖"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ屗"))
	# l1l11l1111l1_l1_ l1l111llll1l_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ屘"))
	succeeded,img,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪ屙"),str(l11l1l11_l1_)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࠧ屚")+img)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ屛"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ屜"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ屝"))
	succeeded,count,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ属"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ屟"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ屠"))
	# l1l11l11l11l_l1_ l1l11l1111l1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࡖࡼࡴࡪ࠭࡝ࠣ屡"))
	# l1l11l11l11l_l1_ l1l11l1111l1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡺࡹ࡭ࡧࠪࡡࠧ屢"))
	succeeded,duration,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	#l1l111l11l11_l1_ = []
	# l1l11l111l11_l1_
	#l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡰ࡮ࡩ࡫ࡕࡴࡤࡧࡰ࡯࡮ࡨࡒࡤࡶࡦࡳࡳࠨ࡟ࠥ屣"))
	# l11ll1111l1_l1_ l1l11l11l1l1_l1_
	#l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡶࡵࡥࡨࡱࡩ࡯ࡩࡓࡥࡷࡧ࡭ࡴࠩࡠࠦ層"))
	#succeeded,l1l111l1l1l1_l1_,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	l1l111l11l11_l1_ = []
	# l11ll1111l1_l1_ l1l11l11l1l1_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ履"))
	# l1l11l111l11_l1_
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ屦"))
	succeeded,token,l11l1l11_l1_ = l1l111l111l1_l1_(item,render,l1l111l11l11_l1_)
	if l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ屧") in duration: duration,l11l1llllll_l1_ = l1l1l1_l1_ (u"ࠪࠫ屨"),l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ屩")
	if l1l1l1_l1_ (u"๋ࠬศศึิࠫ屪") in duration: duration,l11l1llllll_l1_ = l1l1l1_l1_ (u"࠭ࠧ屫"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ屬")
	if l1l1l1_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ屭") in list(render.keys()):
		l1l11l11llll_l1_ = str(render[l1l1l1_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ屮")])
		if l1l1l1_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ屯") in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠫࠩࡀࠠࠡࠩ屰")
		if l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࠪ山") in l1l11l11llll_l1_: l11l1llllll_l1_ = l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ屲")
		if l1l1l1_l1_ (u"ࠧࡃࡷࡼࠫ屳") in l1l11l11llll_l1_ or l1l1l1_l1_ (u"ࠨࡔࡨࡲࡹ࠭屴") in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ屵")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡸ๊ࠫฮวีำࠪ屶")) in l1l11l11llll_l1_: l11l1llllll_l1_ = l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ屷")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡺ࠭ิาษฤࠫ屸")) in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ屹")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡵࠨษึฮหาวาࠩ屺")) in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ屻")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ屼")) in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ屽")
	l111ll_l1_ = escapeUNICODE(l111ll_l1_)
	if l111ll_l1_ and l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ屾") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
	img = img.split(l1l1l1_l1_ (u"ࠬࡅࠧ屿"))[0]
	if  img and l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ岀") not in img: img = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ岁")+img
	title = escapeUNICODE(title)
	if l1l111lll1l1_l1_: title = l1l111lll1l1_l1_+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l1l1_l1_ (u"ࠨ࠮ࠪ岂"),l1l1l1_l1_ (u"ࠩࠪ岃"))
	count = count.replace(l1l1l1_l1_ (u"ࠪ࠰ࠬ岄"),l1l1l1_l1_ (u"ࠫࠬ岅"))
	count = re.findall(l1l1l1_l1_ (u"ࠬࡢࡤࠬࠩ岆"),count)
	if count: count = count[0]
	else: count = l1l1l1_l1_ (u"࠭ࠧ岇")
	return True,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_,token
def l1l111lll11l_l1_(url,data=l1l1l1_l1_ (u"ࠧࠨ岈"),request=l1l1l1_l1_ (u"ࠨࠩ岉")):
	if request==l1l1l1_l1_ (u"ࠩࠪ岊"): request = l1l1l1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ岋")
	#if l1l1l1_l1_ (u"ࠫࡤࡥࠧ岌") in l1l11l1ll111_l1_: l1l11l1ll111_l1_ = l1l1l1_l1_ (u"ࠬ࠭岍")
	#if l1l1l1_l1_ (u"࠭ࡳࡴ࠿ࠪ岎") in url: url = url.split(l1l1l1_l1_ (u"ࠧࡴࡵࡀࠫ岏"))[0]
	useragent = l1l1l11ll_l1_()
	#useragent = l1l1l1_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠰࠺࠰࠳࠲࠵࠴࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠡࡇࡧ࡫࠴࠷࠰࠺࠰࠳࠲࠶࠻࠱࠹࠰࠺࠴ࠬ岐")
	headers2 = {l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭岑"):useragent,l1l1l1_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ岒"):l1l1l1_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ岓")}
	#headers2 = headers.copy()
	global settings
	if not data: data = settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ岔"))
	if data.count(l1l1l1_l1_ (u"࠭࠺࠻࠼ࠪ岕"))==4: l1l11l111ll1_l1_,key,l1l111llllll_l1_,l1l111ll111l_l1_,token = data.split(l1l1l1_l1_ (u"ࠧ࠻࠼࠽ࠫ岖"))
	else: l1l11l111ll1_l1_,key,l1l111llllll_l1_,l1l111ll111l_l1_,token = l1l1l1_l1_ (u"ࠨࠩ岗"),l1l1l1_l1_ (u"ࠩࠪ岘"),l1l1l1_l1_ (u"ࠪࠫ岙"),l1l1l1_l1_ (u"ࠫࠬ岚"),l1l1l1_l1_ (u"ࠬ࠭岛")
	data2 = {l1l1l1_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ岜"):{l1l1l1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ岝"):{l1l1l1_l1_ (u"ࠣࡪ࡯ࠦ岞"):l1l1l1_l1_ (u"ࠤࡤࡶࠧ岟"),l1l1l1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ岠"):l1l1l1_l1_ (u"ࠦ࡜ࡋࡂࠣ岡"),l1l1l1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ岢"):l1l111llllll_l1_}}}
	if url==l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ岣") or l1l1l1_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ岤") in url:
		url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ岥")+l1l1l1_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ岦")+key
		data2[l1l1l1_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ岧")] = l1l11l111ll1_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ岨"),url,data2,headers2,True,True,l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ岩"))
	elif l1l1l1_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ岪") in url:
		url = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ岫")+key
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭岬"),url,data2,headers2,True,True,l1l1l1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ岭"))
	elif l1l1l1_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ岮") in url and l1l11l111ll1_l1_:
		data2[l1l1l1_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ岯")] = token
		data2[l1l1l1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭岰")][l1l1l1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭岱")][l1l1l1_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ岲")] = l1l11l111ll1_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭岳"),url,data2,headers2,True,True,l1l1l1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ岴"))
	elif l1l1l1_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ岵") in url and l1l111ll111l_l1_:
		headers2.update({l1l1l1_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ岶"):l1l1l1_l1_ (u"ࠬ࠷ࠧ岷"),l1l1l1_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ岸"):l1l111llllll_l1_})
		headers2.update({l1l1l1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ岹"):l1l1l1_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ岺")+l1l111ll111l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭岻"),url,l1l1l1_l1_ (u"ࠪࠫ岼"),headers2,l1l1l1_l1_ (u"ࠫࠬ岽"),l1l1l1_l1_ (u"ࠬ࠭岾"),l1l1l1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ岿"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ峀"),url,l1l1l1_l1_ (u"ࠨࠩ峁"),headers2,l1l1l1_l1_ (u"ࠩࠪ峂"),l1l1l1_l1_ (u"ࠪࠫ峃"),l1l1l1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ峄"))
	html = response.content
	tmp = re.findall(l1l1l1_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ峅"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l1l1_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ峆"),html,re.DOTALL|re.I)
	if tmp: l1l111llllll_l1_ = tmp[0]
	tmp = re.findall(l1l1l1_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ峇"),html,re.DOTALL|re.I)
	if tmp: l1l11l111ll1_l1_ = tmp[0]
	#tmp = re.findall(l1l1l1_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ峈"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l1l1l1_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭峉"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l1l1l1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠥ࠾ࢀࠨࡴࡰ࡭ࡨࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ峊"),html,re.DOTALL|re.I)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ峋"),l1l1l1_l1_ (u"ࠬ࠭峌"),l1l1l1_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ峍"),str(len(tmp)))
	#if tmp: l1l11l111l11_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l1l1_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ峎") in list(cookies.keys()): l1l111ll111l_l1_ = cookies[l1l1l1_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭峏")]
	l1l11l11l_l1_ = l1l11l111ll1_l1_+l1l1l1_l1_ (u"ࠩ࠽࠾࠿࠭峐")+key+l1l1l1_l1_ (u"ࠪ࠾࠿ࡀࠧ峑")+l1l111llllll_l1_+l1l1l1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ峒")+l1l111ll111l_l1_+l1l1l1_l1_ (u"ࠬࡀ࠺࠻ࠩ峓")+token
	if request==l1l1l1_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭峔") and l1l1l1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ峕") in html:
		l1l111lll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ峖"),html,re.DOTALL)
		if not l1l111lll1_l1_: l1l111lll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ峗"),html,re.DOTALL)
		l1l111l11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠪࡷࡹࡸࠧ峘"),l1l111lll1_l1_[0])
	elif request==l1l1l1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ峙") and l1l1l1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ峚") in html:
		l1l111lll1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ峛"),html,re.DOTALL)
		l1l111l11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠧࡴࡶࡵࠫ峜"),l1l111lll1_l1_[0])
	elif l1l1l1_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ峝") not in html: l1l111l11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠩࡶࡸࡷ࠭峞"),html)
	else: l1l111l11l1l_l1_ = l1l1l1_l1_ (u"ࠪࠫ峟")
	if 0:
		cc = str(l1l111l11l1l_l1_)
		if kodi_version>18.99: cc = cc.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ峠"))
		open(l1l1l1_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ峡"),l1l1l1_l1_ (u"࠭ࡷࡣࠩ峢")).write(cc)
		#open(l1l1l1_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ峣"),l1l1l1_l1_ (u"ࠨࡹࠪ峤")).write(html)
	settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ峥"),l1l11l11l_l1_)
	return html,l1l111l11l1l_l1_,l1l11l11l_l1_
def l1l11l1l1l1l_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬ峦"),l1l1l1_l1_ (u"ࠫ࠰࠭峧"))
	url2 = url+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭峨")+search
	l11l11_l1_(url2,index)
	return
def SEARCH(search):
	#search = l1l1l1_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ峩")+l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࠬ峪")+l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ峫")+l1l1l1_l1_ (u"ࠩࡢࠫ峬")+search
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ峭"),l1l1l1_l1_ (u"ࠫࠬ峮"),l1l1l1_l1_ (u"ࠬ࠭峯"),search)
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ峰"),l1l1l1_l1_ (u"ࠧࠨ峱"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ峲"),l1l1l1_l1_ (u"ࠩ࠮ࠫ峳"))
	url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ峴")+search
	if not l111l_l1_:
		if l1l1l1_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ峵") in options: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ島")
		elif l1l1l1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ峷") in options: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ峸")
		elif l1l1l1_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭峹") in options: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ峺")
		else: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠪࠫ峻")
		url3 = url2+l1l111ll11ll_l1_
	else:
		l1l111l1ll1l_l1_,l1l111l1111l_l1_,title2 = [],[],l1l1l1_l1_ (u"ࠫࠬ峼")
		l1l111l111ll_l1_ = [l1l1l1_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ峽"),l1l1l1_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ峾"),l1l1l1_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ峿"),l1l1l1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ崀"),l1l1l1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭崁")]
		l1l11l11l1ll_l1_ = [l1l1l1_l1_ (u"ࠪࠫ崂"),l1l1l1_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ崃"),l1l1l1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ崄"),l1l1l1_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ崅"),l1l1l1_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭崆")]
		l1l11l1l111l_l1_ = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ崇"),l1l111l111ll_l1_)
		if l1l11l1l111l_l1_ == -1: return
		l1l11l1l1111_l1_ = l1l11l11l1ll_l1_[l1l11l1l111l_l1_]
		html,c,data = l1l111lll11l_l1_(url2+l1l11l1l1111_l1_)
		if c:
			try:
				d = c[l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ崈")][l1l1l1_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭崉")][l1l1l1_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭崊")][l1l1l1_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ崋")][l1l1l1_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ崌")][l1l1l1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ崍")][l1l1l1_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ崎")]
				for l1l111l11111_l1_ in range(len(d)):
					group = d[l1l111l11111_l1_][l1l1l1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ崏")][l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ崐")]
					for l1l11l1l1ll1_l1_ in range(len(group)):
						render = group[l1l11l1l1ll1_l1_][l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ崑")]
						if l1l1l1_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ崒") in list(render.keys()):
							l111ll_l1_ = render[l1l1l1_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ崓")][l1l1l1_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ崔")][l1l1l1_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭崕")][l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭崖")]
							l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ崗"),l1l1l1_l1_ (u"ࠫࠫ࠭崘"))
							title = render[l1l1l1_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭崙")]
							title = title.replace(l1l1l1_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ崚"),l1l1l1_l1_ (u"ࠧࠨ崛"))
							if l1l1l1_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ崜") in title: continue
							if l1l1l1_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ崝") in title:
								title = l1l1l1_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ崞")+title
								title2 = title
								l11111ll1_l1_ = l111ll_l1_
							if l1l1l1_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ崟") in title: continue
							title = title.replace(l1l1l1_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ崠"),l1l1l1_l1_ (u"࠭ࠧ崡"))
							if l1l1l1_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ崢") in title: continue
							if l1l1l1_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ崣") in title:
								title = l1l1l1_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ崤")+title
								title2 = title
								l11111ll1_l1_ = l111ll_l1_
							if l1l1l1_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ崥") in title: continue
							l1l111l1ll1l_l1_.append(escapeUNICODE(title))
							l1l111l1111l_l1_.append(l111ll_l1_)
			except: pass
		if not title2: l1l11l11l111_l1_ = l1l1l1_l1_ (u"ࠫࠬ崦")
		else:
			l1l111l1ll1l_l1_ = [l1l1l1_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ崧"),title2]+l1l111l1ll1l_l1_
			l1l111l1111l_l1_ = [l1l1l1_l1_ (u"࠭ࠧ崨"),l11111ll1_l1_]+l1l111l1111l_l1_
			l1l11l1l11ll_l1_ = DIALOG_SELECT(l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ崩"),l1l111l1ll1l_l1_)
			if l1l11l1l11ll_l1_ == -1: return
			l1l11l11l111_l1_ = l1l111l1111l_l1_[l1l11l1l11ll_l1_]
		if l1l11l11l111_l1_: url3 = l1l11l_l1_+l1l11l11l111_l1_
		elif l1l11l1l1111_l1_: url3 = url2+l1l11l1l1111_l1_
		else: url3 = url2
		l1l1l1_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦࡪ࡮ࡷࡩࡷ࠳ࡤࡳࡱࡳࡨࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯࠰ࡷࡪࡩࡴࡪࡱࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠨ࠮ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘࡵࡲࡵࠢࡥࡽࠬ࠲ࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠥࠦࠧ崪")
	#DIALOG_OK()
	l11l11_l1_(url3)
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ奘")
menu_name = l1l1l1_l1_ (u"ࠫࡤ࡟ࡑࡕࡡࠪ奙")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ奚"),l1l1l1_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ奛"),l1l1l1_l1_ (u"ࠧหีฯ๎้࠭奜"),l1l1l1_l1_ (u"ࠨฬึะ๏๊ࠠศๆาาํ๊ࠧ奝"),l1l1l1_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭奞")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l11l11_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l11_l1_(url,text)
	elif mode==664: results = l1ll11_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ奟"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬ奠"),l1l1l1_l1_ (u"ࠬ࠭奡"),l1l1l1_l1_ (u"࠭ࠧ奢"),l1l1l1_l1_ (u"ࠧࠨ奣"),l1l1l1_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ奤"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ奥"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ奦"),l1l1l1_l1_ (u"ࠫࠬ奧"),669,l1l1l1_l1_ (u"ࠬ࠭奨"),l1l1l1_l1_ (u"࠭ࠧ奩"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ奪"))
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭奫"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ奬"),l1l1l1_l1_ (u"ࠪࠫ奭"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奮"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ奯")+menu_name+l1l1l1_l1_ (u"࠭วๅ็่๎ืฯࠧ奰"),l1l11l_l1_,661,l1l1l1_l1_ (u"ࠧࠨ奱"),l1l1l1_l1_ (u"ࠨࠩ奲"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ女"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奴"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭奵")+menu_name+l1l1l1_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ奶"),l1l11l_l1_,661,l1l1l1_l1_ (u"࠭ࠧ奷"),l1l1l1_l1_ (u"ࠧࠨ奸"),l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ她"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ奺"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ奻")+menu_name+l1l1l1_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪ奼"),l1l11l_l1_,661,l1l1l1_l1_ (u"ࠬ࠭好"),l1l1l1_l1_ (u"࠭ࠧ奾"),l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ奿"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妀"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ妁")+menu_name+l1l1l1_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠧ如"),l1l11l_l1_,661,l1l1l1_l1_ (u"ࠫࠬ妃"),l1l1l1_l1_ (u"ࠬ࠭妄"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ妅"))
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ妆"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ妇"),l1l1l1_l1_ (u"ࠩࠪ妈"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ妉"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ妊"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妋"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ妌")+menu_name+title,l111ll_l1_,664)
	#addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ妍"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ妎"),l1l1l1_l1_ (u"ࠩࠪ妏"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ妐"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ妑"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠬ࠭妒"))
	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ妓"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		title = title.replace(l1l1l1_l1_ (u"ࠧ࠽ࡤࡁࠫ妔"),l1l1l1_l1_ (u"ࠨࠩ妕")).replace(l1l1l1_l1_ (u"ࠩ࠿࠳ࡧࡄࠧ妖"),l1l1l1_l1_ (u"ࠪࠫ妗")).replace(l1l1l1_l1_ (u"ࠫࡁࡨࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡵࡩࡹࠨ࠾ࠨ妘"),l1l1l1_l1_ (u"ࠬ࠭妙")).replace(l1l1l1_l1_ (u"࠭࠼ࡣࡀࠪ妚"),l1l1l1_l1_ (u"ࠧࠨ妛")).strip(l1l1l1_l1_ (u"ࠨࠢࠪ妜"))
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ妝"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ妞")+menu_name+title,l111ll_l1_,664)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ妟"),url,l1l1l1_l1_ (u"ࠬ࠭妠"),l1l1l1_l1_ (u"࠭ࠧ妡"),l1l1l1_l1_ (u"ࠧࠨ妢"),l1l1l1_l1_ (u"ࠨࠩ妣"),l1l1l1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭妤"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ妥"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ妦"),l1l1l1_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ妧"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ妨"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠧࠨ妩"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭妪"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ妫"),l1l1l1_l1_ (u"ࠪࠫ妬"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ妭"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠬࡀࠠࠨ妮")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妯"),menu_name+title,l111ll_l1_,661)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ妰"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ妱"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ妲"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ妳"),l1l1l1_l1_ (u"ࠫࠬ妴"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妵"),menu_name+title,l111ll_l1_,661)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"࠭ࠧ妶")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ妷"),l1l1l1_l1_ (u"ࠨࠩ妸"),request,url)
	if request==l1l1l1_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ妹"):
		url,search = url.split(l1l1l1_l1_ (u"ࠪࡃࠬ妺"),1)
		data = l1l1l1_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ妻")+search
		headers = {l1l1l1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ妼"):l1l1l1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭妽")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ妾"),url,data,headers,l1l1l1_l1_ (u"ࠨࠩ妿"),l1l1l1_l1_ (u"ࠩࠪ姀"),l1l1l1_l1_ (u"ࠪ࡝ࡆࡗࡏࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭姁"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ姂"),url,l1l1l1_l1_ (u"ࠬ࠭姃"),l1l1l1_l1_ (u"࠭ࠧ姄"),l1l1l1_l1_ (u"ࠧࠨ姅"),l1l1l1_l1_ (u"ࠨࠩ姆"),l1l1l1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ姇"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠪࠫ姈"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ姉"))
	if request==l1l1l1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ姊"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ始"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠧࠨ姌"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ姍"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ姎"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ姏"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ姐"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ姑"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭姒"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ姓"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ委"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ姕"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠪࠫ姖"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ姗"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭姘"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"࠭ๅีษ๊ำฮ࠭姙"),l1l1l1_l1_ (u"ࠧโ์็้ࠬ姚"),l1l1l1_l1_ (u"ࠨษ฽๊๏ฯࠧ姛"),l1l1l1_l1_ (u"ࠩๆ่๏ฮࠧ姜"),l1l1l1_l1_ (u"ࠪห฾๊ว็ࠩ姝"),l1l1l1_l1_ (u"ࠫ์ีวโࠩ姞"),l1l1l1_l1_ (u"๋ࠬศศำสอࠬ姟"),l1l1l1_l1_ (u"ู࠭าุࠪ姠"),l1l1l1_l1_ (u"ࠧๆ้ิะฬ์ࠧ姡"),l1l1l1_l1_ (u"ࠨษ็ฬํ๋ࠧ姢"),l1l1l1_l1_ (u"่ࠩืึำ๊สࠩ姣")]
	for img,l111ll_l1_,title in items:
		title = title.replace(l1l1l1_l1_ (u"ࠪหํ์ࠠๅษํ๊ࠥ࠭姤"),l1l1l1_l1_ (u"ࠫࠬ姥")).replace(l1l1l1_l1_ (u"ࠬอ่็ๆส๎๋ࠦࠧ姦"),l1l1l1_l1_ (u"࠭ࠧ姧")).replace(l1l1l1_l1_ (u"ࠧๆึส๋ิฯࠠࠨ姨"),l1l1l1_l1_ (u"ࠨࠩ姩"))
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠩ࠲ࠫ姪"))
		#if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ姫") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭姬")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧ姭"))
		#if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ姮") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩ姯")+img.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ姰"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ姱"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭姲"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姳"),menu_name+title,l111ll_l1_,662,img)
		elif request==l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ姴"):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ姵"),menu_name+title,l111ll_l1_,662,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭姶") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姷"),menu_name+title,l111ll_l1_,663,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ姸") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姹"),menu_name+title,l111ll_l1_,661,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姺"),menu_name+title,l111ll_l1_,663,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ姻"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ姼")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ姽"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭姾"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠩࠦࠫ姿"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬ娀")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭威"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ娂"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬ娃")+title,l111ll_l1_,661)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ娄"),l1l1l1_l1_ (u"ࠨࠩ娅"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭娆"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ娇"),url,l1l1l1_l1_ (u"ࠫࠬ娈"),l1l1l1_l1_ (u"ࠬ࠭娉"),l1l1l1_l1_ (u"࠭ࠧ娊"),l1l1l1_l1_ (u"ࠧࠨ娋"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ娌"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ娍"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ娎"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"ࠫࠬ娏")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ娐"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"࠭ࠣࠨ娑"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ娒"),menu_name+title,url,663,img,l1l1l1_l1_ (u"ࠨࠩ娓"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ娔")+l1lll_l1_+l1l1l1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ娕"),html,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ娖"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		#if not items: items = re.findall(l1l1l1_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ娗"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ娘")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠯࠱ࠪ娙"))
			title = title.replace(l1l1l1_l1_ (u"ࠨ࠾࠲ࡩࡲࡄ࠼ࡴࡲࡤࡲࡃ࠭娚"),l1l1l1_l1_ (u"ࠩࠣࠫ娛"))
			addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ娜"),menu_name+title,l111ll_l1_,662,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ娝"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ娞") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ娟")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ娠"))
		#		addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ娡"),menu_name+title,l111ll_l1_,662,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l11_l1_,l111l11_l1_ = [],[],[]
	url2 = url.replace(l1l1l1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠰ࡳ࡬ࡵ࠭娢"),l1l1l1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭娣"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ娤"),url2,l1l1l1_l1_ (u"ࠬ࠭娥"),l1l1l1_l1_ (u"࠭ࠧ娦"),l1l1l1_l1_ (u"ࠧࠨ娧"),l1l1l1_l1_ (u"ࠨࠩ娨"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭娩"))
	html = response.content
	# l11ll1l1l_l1_ l111ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢࡑ࡮ࡤࡽࡪࡸࡨࡰ࡮ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ娪"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ娫"),block,re.DOTALL)
		if l111ll_l1_:
			l111ll_l1_ = l111ll_l1_[0]
			l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭娬"))
			l11l1_l1_.append(l111ll_l1_)
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ娭"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨ娮"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ娯")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ娰"))
				l11l1_l1_.append(l111ll_l1_)
	l1l1l1_l1_ (u"ࠥࠦࠧࠐࠉࠤࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡱ࡯࡮࡬ࡵࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ࠭ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪ࠭ࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠴࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠿ࠐࠉࠊࠋࠌࡲࡦࡳࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ࠯ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤ娱")
	zzz = zip(l11l1_l1_,l111l1l11_l1_)
	for l111ll_l1_,name in zzz: l111l11_l1_.append(l111ll_l1_+name)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ娲"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ娳"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ娴"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ娵"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ娶"),l1l1l1_l1_ (u"ࠩ࠮ࠫ娷"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ娸")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ娹"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ娺")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ娻"))
	return
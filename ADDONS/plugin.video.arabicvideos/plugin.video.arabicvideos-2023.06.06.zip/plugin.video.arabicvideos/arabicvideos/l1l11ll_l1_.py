# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
headers = { l1l1l1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ࣒") : l1l1l1_l1_ (u"࣓ࠬ࠭") }
script_name = l1l1l1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬࣔ")
menu_name = l1l1l1_l1_ (u"ࠧࡠࡃࡎࡓࡤ࠭ࣕ")
l1l11l_l1_ = WEBSITES[script_name][0]
l11l111_l1_ = [l1l1l1_l1_ (u"ࠨใํ่๊࠭ࣖ"),l1l1l1_l1_ (u"ࠩๆ่๏ฮࠧࣗ"),l1l1l1_l1_ (u"ࠪห้฿ัืࠢส่ฬูศ้฻ํࠫࣘ"),l1l1l1_l1_ (u"ู๊ࠫัฮ์ฬࠫࣙ"),l1l1l1_l1_ (u"๋ࠬำาฯํ๋ࠬࣚ"),l1l1l1_l1_ (u"࠭ว฻่ํอࠬࣛ"),l1l1l1_l1_ (u"ࠧศ฻็ห๋࠭ࣜ"),l1l1l1_l1_ (u"ࠨๆๅหฦ࠭ࣝ")]
def MAIN(mode,url,text):
	if   mode==70: results = MENU()
	elif mode==71: results = CATEGORIES(url)
	elif mode==72: results = l11l11_l1_(url,text)
	elif mode==73: results = l111l1l_l1_(url)
	elif mode==74: results = PLAY(url)
	elif mode==79: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣞ"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪࣟ"),l1l1l1_l1_ (u"ࠫࠬ࣠"),79,l1l1l1_l1_ (u"ࠬ࠭࣡"),l1l1l1_l1_ (u"࠭ࠧ࣢"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࣣࠫ"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࣤ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫࣥ")+menu_name+l1l1l1_l1_ (u"ࠪืู้ไสࠢสๅ้อๅࠨࣦ"),l1l1l1_l1_ (u"ࠫࠬࣧ"),79,l1l1l1_l1_ (u"ࠬ࠭ࣨ"),l1l1l1_l1_ (u"ࣩ࠭ࠧ"),l1l1l1_l1_ (u"ࠧิๆึ่ฮࠦวโๆส้ࠬ࣪"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࣫"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࣬")+menu_name+l1l1l1_l1_ (u"ࠪื้อำๅ่๊ࠢํ฿ษࠨ࣭"),l1l1l1_l1_ (u"࣮ࠫࠬ"),79,l1l1l1_l1_ (u"࣯ࠬ࠭"),l1l1l1_l1_ (u"ࣰ࠭ࠧ"),l1l1l1_l1_ (u"ࠧิๆึ่ฮࣱ࠭"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࣲ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫࣳ")+menu_name+l1l1l1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫࣴ"),l1l11l_l1_,72,l1l1l1_l1_ (u"ࠫࠬࣵ"),l1l1l1_l1_ (u"ࣶࠬ࠭"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨࣷ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࣸ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࣹࠪ")+menu_name+l1l1l1_l1_ (u"ࠩสุ่๊๊ะࣺࠩ"),l1l11l_l1_,72,l1l1l1_l1_ (u"ࠪࠫࣻ"),l1l1l1_l1_ (u"ࠫࠬࣼ"),l1l1l1_l1_ (u"ࠬࡳ࡯ࡳࡧࠪࣽ"))
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࣾ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩࣿ")+menu_name+l1l1l1_l1_ (u"ࠨษ็วำฮวาࠩऀ"),l1l11l_l1_,72,l1l1l1_l1_ (u"ࠩࠪँ"),l1l1l1_l1_ (u"ࠪࠫं"),l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡴࠩः"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬऄ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨअ")+menu_name+l1l1l1_l1_ (u"ࠧศๆฦาออัࠨआ"),l1l11l_l1_,72,l1l1l1_l1_ (u"ࠨࠩइ"),l1l1l1_l1_ (u"ࠩࠪई"),l1l1l1_l1_ (u"ࠪࡲࡪࡽࡳࠨउ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩऊ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬऋ"),l1l1l1_l1_ (u"࠭ࠧऌ"),9999)
	l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠧศๆๆฮอ่ࠦࠡษ็หอำวฬࠩऍ"),l1l1l1_l1_ (u"ࠨษ็็ํืำศฬࠣห้ะูๅ์่๎ฮ࠭ऎ"),l1l1l1_l1_ (u"ࠩส่ศู๊ศสࠪए"),l1l1l1_l1_ (u"ࠪห้ฮัศ็ฯࠫऐ"),l1l1l1_l1_ (u"ࠫฬ๊วอ้ีอࠥอไๅ๊ะ๎ฮ࠭ऑ"),l1l1l1_l1_ (u"ࠬอไึ๊ิࠤํࠦวๅะ็ๅ๏อสࠨऒ"),l1l1l1_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧओ")]
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨऔ"),headers,l1l1l1_l1_ (u"ࠨࠩक"),l1l1l1_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪख"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦࡸࡴࡪࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩग"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪघ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title not in l1l1ll_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬङ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨच")+menu_name+title,l111ll_l1_,71)
	return html
def CATEGORIES(url):
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠧࠨछ"),headers,l1l1l1_l1_ (u"ࠨࠩज"),l1l1l1_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩझ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡪࡩࡴࡠࡲࡤࡶࡹࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫञ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ट"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧठ"))
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ड"),menu_name+title,l111ll_l1_,72)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧढ"),menu_name+l1l1l1_l1_ (u"ࠨฮ่๎฾ࠦวๅใิ์฾࠭ण"),url,72)
	else: l11l11_l1_(url,l1l1l1_l1_ (u"ࠩࠪत"))
	return
def l11l11_l1_(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫथ"),l1l1l1_l1_ (u"ࠫࠬद"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠬ࠭ध"),headers,True,l1l1l1_l1_ (u"࠭ࡁࡌࡑࡄࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩन"))
	items = []
	if type==l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩऩ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡡࡷ࡭ࡹࡲࡥࠡࡨࡨࡥࡹࡻࡲࡦࡦࡢࡸ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡳࡶࡤ࡭ࡩࡨࡺࡳ࠮ࡥࡵࡳࡺࡹࡥ࡭ࠩप"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡶࡤ࡭ࡩࡨࡺ࡟ࡣࡱࡻ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪफ"),block,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪब"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡢࡶࡪࡹࡵ࡭ࡶࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴࠨभ"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠴ࡂࠬम"),block,re.DOTALL)
		#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧय"),l1l1l1_l1_ (u"ࠧࠨर"),str(len(items)),block)
	elif type==l1l1l1_l1_ (u"ࠨ࡯ࡲࡶࡪ࠭ऱ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡢࡸ࡮ࡺ࡬ࡦࠢࡰࡳࡷ࡫࡟ࡵ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡪࡴࡵࡴࡦࡴࡢࡦࡴࡺࡴࡰ࡯ࡢࡷࡪࡸࡶࡪࡥࡨࡷࠬल"),html,re.DOTALL)
	#elif type==l1l1l1_l1_ (u"ࠪࡲࡪࡽࡳࠨळ"):
	#	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡤࡺࡩࡵ࡮ࡨࠤࡳ࡫ࡷࡴࡡࡷ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮ࡴࡥࡸࡵࡢࡱࡴࡸࡥࡠࡥ࡫ࡳ࡮ࡩࡥࡴࠩऴ"),html,re.DOTALL)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺࠧव"),html,re.DOTALL)
	if not items and l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨࡪࡦࡥࡷࡣࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨश"),block,re.DOTALL)
	for l111ll_l1_,img,title in items:
		if l1l1l1_l1_ (u"ࠧหู๊๎าࠦ็ศ็ࠪष") in title: continue
		title = title.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫस"),l1l1l1_l1_ (u"ࠩࠪह")).strip(l1l1l1_l1_ (u"ࠪࠤࠬऺ"))
		title = unescapeHTML(title)
		if any(value in title for value in l11l111_l1_): addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪऻ"),menu_name+title,l111ll_l1_,73,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ़ࠬ"),menu_name+title,l111ll_l1_,73,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧऽ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠢ࠽࠱࡯࡭ࡃࡂ࡬ࡪࠢࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧा"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨि"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨी")+title,l111ll_l1_,72,l1l1l1_l1_ (u"ࠪࠫु"),l1l1l1_l1_ (u"ࠫࠬू"),type)
	return
def l1l1l1l_l1_(url):
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠬ࠭ृ"),headers,True,l1l1l1_l1_ (u"࠭ࡁࡌࡑࡄࡑ࠲࡙ࡅࡄࡖࡌࡓࡓ࡙࠭࠳ࡰࡧࠫॄ"))
	url2 = re.findall(l1l1l1_l1_ (u"ࠧࠣࡪࡵࡩ࡫ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨॅ"),html,re.DOTALL)
	url2 = url2[1]
	return url2
def l111l1l_l1_(url):
	#l111lll_l1_ = [l1l1l1_l1_ (u"ࠨࡼ࡬ࡴࠬॆ"),l1l1l1_l1_ (u"ࠩࡵࡥࡷ࠭े"),l1l1l1_l1_ (u"ࠪࡸࡽࡺࠧै"),l1l1l1_l1_ (u"ࠫࡵࡪࡦࠨॉ"),l1l1l1_l1_ (u"ࠬ࡮ࡴ࡮ࠩॊ"),l1l1l1_l1_ (u"࠭ࡴࡢࡴࠪो"),l1l1l1_l1_ (u"ࠧࡪࡵࡲࠫौ"),l1l1l1_l1_ (u"ࠨࡪࡷࡱࡱ्࠭")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠩࠪॎ"),headers,True,l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡖࡉࡈ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨॏ"))
	l1l1lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠯ࡀ࠯࠰ࡣ࡮ࡻࡦࡳ࠮࡯ࡧࡷ࠳ࡡࡽࠫ࠯ࠬࡂ࠭ࠧ࠭ॐ"),html,re.DOTALL)
	l1l111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸ࠰࠺࠰࠱ࡸࡲࡩ࡫ࡲࡶࡴ࡯࠲ࡨࡵ࡭࠰࡞ࡺ࠯࠳࠰࠿ࠪࠤࠪ॑"),html,re.DOTALL)
	if l1l1lll_l1_ or l1l111l_l1_:
		if l1l1lll_l1_: url3 = l1l1lll_l1_[0]
		elif l1l111l_l1_: url3 = l1l1l1l_l1_(l1l111l_l1_[0])
		url3 = UNQUOTE(url3)
		import l11ll1l_l1_
		if l1l1l1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ॒") in url3 or l1l1l1_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡼࡹ࠯ࠨ॓") in url3: l11ll1l_l1_.l11l1ll_l1_(url3)
		else: l11ll1l_l1_.PLAY(url3)
		return
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ็ะฮํ๏ࠠศๆไ๎้๋࠮ࠫࡁࡁ࠲࠯ࡅࠨ࡝ࡹ࠭ࡃ࠮ࡢࡗࠫࡁ࠿ࠫ॔"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	items = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡦࡷࠦ࠯࠿࡞ࡱࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩॕ"),html,re.DOTALL)
	for l111ll_l1_,title in items:
		title = unescapeHTML(title)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪॖ"),menu_name+title,l111ll_l1_,73)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸࡻࡢࡠࡶ࡬ࡸࡱ࡫ࠢ࠯ࠬࡂࡀ࡭࠷࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠶ࡄ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡰࡥ࡮ࡴ࡟ࡪ࡯ࡪࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢࡦ࠰࠷࠵࠶࠭࠳࠷࠳ࠬ࠳࠰࠿ࠪࡣ࡮ࡳ࠲࡬ࡥࡦࡦࡥࡥࡨࡱࠧॗ"),html,re.DOTALL)
	if not l1ll1l1_l1_:
		DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠬิืฤࠢัหึา๊ࠨक़"),l1l1l1_l1_ (u"࠭ไศࠢํ์ัีࠠๆๆไࠤๆ๐ฯ๋๊ࠪख़"))
		return
	name,img,block = l1ll1l1_l1_[0]
	name = name.strip(l1l1l1_l1_ (u"ࠧࠡࠩग़"))
	if l1l1l1_l1_ (u"ࠨࡵࡸࡦࡤ࡫ࡰࡴ࡫ࡲࡨࡪࡥࡴࡪࡶ࡯ࡩࠬज़") in block:
		items = re.findall(l1l1l1_l1_ (u"ࠩࡶࡹࡧࡥࡥࡱࡵ࡬ࡳࡩ࡫࡟ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁ࠲࠯ࡅࡳࡶࡤࡢࡪ࡮ࡲࡥࡠࡶ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪड़"),block,re.DOTALL)
	else:
		filenames = re.findall(l1l1l1_l1_ (u"ࠪࡷࡺࡨ࡟ࡧ࡫࡯ࡩࡤࡺࡩࡵ࡮ࡨࡠࠬࡄࠨ࠯ࠬࡂ࠭ࠥ࠳ࠠ࠽࡫ࡁࠫढ़"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l1l1l1_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪफ़"),filename) )
	if not items: items = [ (l1l1l1_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫय़"),l1l1l1_l1_ (u"࠭ࠧॠ")) ]
	count = 0
	l1111ll_l1_,l1l1111_l1_ = [],[]
	size = len(items)
	for title,filename in items:
		l11llll_l1_ = l1l1l1_l1_ (u"ࠧࠨॡ")
		if l1l1l1_l1_ (u"ࠨࠢ࠰ࠤࠬॢ") in filename: filename = filename.split(l1l1l1_l1_ (u"ࠩࠣ࠱ࠥ࠭ॣ"))[0]
		else: filename = l1l1l1_l1_ (u"ࠪࡨࡺࡳ࡭ࡺ࠰ࡽ࡭ࡵ࠭।")
		if l1l1l1_l1_ (u"ࠫ࠳࠭॥") in filename: l11llll_l1_ = filename.split(l1l1l1_l1_ (u"ࠬ࠴ࠧ०"))[-1]
		#if any(value in l11llll_l1_ for value in l111lll_l1_):
		#	if l1l1l1_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬ१") not in title: title = title + l1l1l1_l1_ (u"ࠧ࠻ࠩ२")
		title = title.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ३"),l1l1l1_l1_ (u"ࠩࠪ४")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ५"))
		l1111ll_l1_.append(title)
		l1l1111_l1_.append(count)
		count += 1
	if size>0:
		if any(value in name for value in l11l111_l1_):
			if size==1:
				selection = 0
			else:
				#DIALOG_SELECT(l1l1l1_l1_ (u"ࠫࠬ६"),l1111ll_l1_)
				selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭७"), l1111ll_l1_)
				if selection == -1: return
			PLAY(url+l1l1l1_l1_ (u"࠭࠿ࡴࡧࡦࡸ࡮ࡵ࡮࠾ࠩ८")+str(1+l1l1111_l1_[size-selection-1]))
		else:
			for i in reversed(range(size)):
				#if l1l1l1_l1_ (u"ࠧ࠻ࠩ९") in l1111ll_l1_[i]: title = l1111ll_l1_[i].strip(l1l1l1_l1_ (u"ࠨ࠼ࠪ॰")) + l1l1l1_l1_ (u"ࠩࠣ࠱๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ॱ")
				#else: title = name + l1l1l1_l1_ (u"ࠪࠤ࠲ࠦࠧॲ") + l1111ll_l1_[i]
				title = name + l1l1l1_l1_ (u"ࠫࠥ࠳ࠠࠨॳ") + l1111ll_l1_[i]
				title = title.replace(l1l1l1_l1_ (u"ࠬࡢ࡮ࠨॴ"),l1l1l1_l1_ (u"࠭ࠧॵ")).strip(l1l1l1_l1_ (u"ࠧࠡࠩॶ"))
				l111ll_l1_ = url + l1l1l1_l1_ (u"ࠨࡁࡶࡩࡨࡺࡩࡰࡰࡀࠫॷ")+str(size-i)
				addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨॸ"),menu_name+title,l111ll_l1_,74,img)
	else:
		addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩॹ"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ัศสฺࠤ้๐ำࠡใํำ๏๎ࠧॺ"),l1l1l1_l1_ (u"ࠬ࠭ॻ"),9999,img)
		#DIALOG_NOTIFICATION(l1l1l1_l1_ (u"࠭ฮุลࠣาฬืฬ๋ࠩॼ"),l1l1l1_l1_ (u"ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐ฯ๋๊ࠪॽ"))
	return
def PLAY(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩॾ"),l1l1l1_l1_ (u"ࠩࠪॿ"),url,l1l1l1_l1_ (u"ࠪࠫঀ"))
	url2,l1llll1_l1_ = url.split(l1l1l1_l1_ (u"ࠫࡄࡹࡥࡤࡶ࡬ࡳࡳࡃࠧঁ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩং"),url2,l1l1l1_l1_ (u"࠭ࠧঃ"),headers,True,l1l1l1_l1_ (u"ࠧࠨ঄"),l1l1l1_l1_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡑࡎࡄ࡝ࡤࡇࡋࡐࡃࡐ࠱࠶ࡹࡴࠨঅ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡤࡨ࠲࠹࠰࠱࠯࠵࠹࠵࠴ࠪࡀࡣࡧ࠱࠸࠶࠰࠮࠴࠸࠴࠭࠴ࠪࡀࠫࡤ࡯ࡴ࠳ࡦࡦࡧࡧࡦࡦࡩ࡫ࠨআ"),html,re.DOTALL)
	l11l1l1_l1_ = l1ll1l1_l1_[0].replace(l1l1l1_l1_ (u"ࠥࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࡡࡥࡳࡽࠨই"),l1l1l1_l1_ (u"ࠫࠧࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠠࡦࡲࡶࡳ࡮ࡪࡥࡠࡤࡲࡼࠬঈ"))
	l11l1l1_l1_ = l11l1l1_l1_ + l1l1l1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠧউ")
	l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡥࡱࡵࡲ࡭ࡩ࡫࡟ࡣࡱࡻࠬ࠳࠰࠿ࠪࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࡥࡢࡰࡺࠪঊ"),l11l1l1_l1_,re.DOTALL)
	l1llll1_l1_ = len(l1l11l1_l1_)-int(l1llll1_l1_)
	block = l1l11l1_l1_[l1llll1_l1_]
	l111l11_l1_ = []
	l1l1l11_l1_ = {l1l1l1_l1_ (u"ࠧ࠲࠶࠵࠷࠵࠽࠵࠹࠸࠵ࠫঋ"):l1l1l1_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ঌ"),l1l1l1_l1_ (u"ࠩ࠴࠸࠼࠽࠴࠹࠹࠹࠴࠶࠭঍"):l1l1l1_l1_ (u"ࠪࡩࡸࡺࡲࡦࡣࡰࠫ঎"),l1l1l1_l1_ (u"ࠫ࠶࠻࠰࠶࠵࠵࠼࠹࠶࠴ࠨএ"):l1l1l1_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱࡦࡴࡧࡰࠩঐ"),
		l1l1l1_l1_ (u"࠭࠱࠵࠴࠶࠴࠽࠶࠰࠲࠷ࠪ঑"):l1l1l1_l1_ (u"ࠧࡧ࡮ࡤࡷ࡭ࡾࠧ঒"),l1l1l1_l1_ (u"ࠨ࠳࠷࠹࠽࠷࠱࠸࠴࠼࠹ࠬও"):l1l1l1_l1_ (u"ࠩࡲࡴࡪࡴ࡬ࡰࡣࡧࠫঔ"),l1l1l1_l1_ (u"ࠪ࠵࠹࠸࠳࠱࠹࠼࠷࠵࠼ࠧক"):l1l1l1_l1_ (u"ࠫࡻ࡯࡭ࡱ࡮ࡨࠫখ"),l1l1l1_l1_ (u"ࠬ࠷࠴࠴࠲࠳࠹࠷࠹࠷࠲ࠩগ"):l1l1l1_l1_ (u"࠭࡯࡬࠰ࡵࡹࠬঘ"),
		l1l1l1_l1_ (u"ࠧ࠲࠶࠺࠻࠹࠾࠸࠳࠳࠶ࠫঙ"):l1l1l1_l1_ (u"ࠨࡶ࡫ࡩࡻ࡯ࡤࠨচ"),l1l1l1_l1_ (u"ࠩ࠴࠹࠺࠾࠲࠸࠺࠳࠴࠻࠭ছ"):l1l1l1_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪজ"),l1l1l1_l1_ (u"ࠫ࠶࠺࠷࠸࠶࠻࠻࠾࠿࠰ࠨঝ"):l1l1l1_l1_ (u"ࠬࡼࡩࡥࡶࡲࡨࡴ࠭ঞ")}
	items = re.findall(l1l1l1_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡤࡷࡲ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨট"),block,re.DOTALL)
	for l111ll_l1_ in items:
		l111l11_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡢࡣࡤࡥ࡟ࡠࡣ࡮ࡳࡦࡳࠧঠ"))
	items = re.findall(l1l1l1_l1_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧড"),block,re.DOTALL)
	for l111ll1_l1_,l111ll_l1_ in items:
		l111ll1_l1_ = l111ll1_l1_.split(l1l1l1_l1_ (u"ࠩ࠲ࠫঢ"))[-1]
		l111ll1_l1_ = l111ll1_l1_.split(l1l1l1_l1_ (u"ࠪ࠲ࠬণ"))[0]
		if l111ll1_l1_ in l1l1l11_l1_:
			l111l11_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬত")+l1l1l11_l1_[l111ll1_l1_]+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࡡࡢࡣࡤࡥࡡ࡬ࡱࡤࡱࠬথ"))
		else: l111l11_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧদ")+l111ll1_l1_+l1l1l1_l1_ (u"ࠧࡠࡡࡢࡣࡤࡥ࡟ࡠࡣ࡮ࡳࡦࡳࠧধ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩন"),l1l1l1_l1_ (u"ࠩࠪ঩"),url,str(l111l11_l1_))
	if not l111l11_l1_:
		message = re.findall(l1l1l1_l1_ (u"ࠪࡷࡺࡨ࠭࡯ࡱ࠰ࡪ࡮ࡲࡥ࠯ࠬࡂࡠࡳ࠮࠮ࠫࡁࠬࡠࡳ࠭প"),block,re.DOTALL)
		if message: DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬফ"),l1l1l1_l1_ (u"ࠬ࠭ব"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨভ"),message[0])
	else:
		import ll_l1_
		ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ম"),url)
	return
def SEARCH(search):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩয"),l1l1l1_l1_ (u"ࠩࠪর"),search,l1l1l1_l1_ (u"ࠪࠫ঱"))
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬল"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭঳"): return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"࠭ࠠࠨ঴"),l1l1l1_l1_ (u"ࠧࠦ࠴࠳ࠫ঵"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪশ")+l11ll11_l1_
	results = l11l11_l1_(url,l1l1l1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩষ"))
	return
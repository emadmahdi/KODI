# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠧࡕࡇࡖࡘࠬ坈"),l1l1l1_l1_ (u"ࠨࡖࡈࡗ࡙࠭坉"))
#url = l1l1l1_l1_ (u"ࠩࡆ࠾ࡡࡢࡐࡰࡴࡷࡥࡧࡲࡥࠡࡒࡵࡳ࡬ࡸࡡ࡮ࡵ࡟ࡠࡐࡕࡄࡊࡡࡹ࠵࠽ࡥ࠶࠵ࡤ࡬ࡸࡡࡢࡋࡰࡦ࡬ࡠࡡࡶ࡯ࡳࡶࡤࡦࡱ࡫࡟ࡥࡣࡷࡥࡡࡢࡣࡢࡥ࡫ࡩࡡࡢࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࡠࡡ࡬ࡩ࡭ࡧࡢ࠴࠽࠿࠶ࡠࡕࡋ࡚ࡤุ๊ศำฬࡣฬ๊ัิ๊็ࡣฬ๊รฺฺ่ࡣ࠭฻ࠩࡠࠪฦฬฬึัࡠษ็ั้๎วอ์ࠬ࠲ࡲࡶ࠳ࠨ坊")
#url = l1l1l1_l1_ (u"ࠪࡧ࠿ࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ坋")
#url = l1l1l1_l1_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ坌")
#url = l1l1l1_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡢࡵࡧࡪ࠳ࡳࡰ࠴ࠩ坍")
url = l1l1l1_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ใะู࠳ࡳࡰ࠴ࠩ坎")
url = l1l1l1_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ࡩ࡭ࡱ࡫࡟࠵࠺࠶࠸ࡤ࡙ࡈࡗࡡี๎ฬืษࡠษ็ีุ๎ไࡠษ็ว฾฾ๅࡠุࠪ࠭ࡤ࠮รษษำีࡤอไฮๆ๋หั๐ࠩ࠯࡯ࡳ࠷ࠬ坏")
#url = url.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭坐"))
xbmc.Player().play(url)
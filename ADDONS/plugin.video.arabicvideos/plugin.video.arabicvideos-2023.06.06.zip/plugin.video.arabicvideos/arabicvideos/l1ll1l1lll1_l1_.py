# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭⻡")
menu_name = l1l1l1_l1_ (u"ࠫࡤࡑࡒࡃࡡࠪ⻢")
l1l11l_l1_ = WEBSITES[script_name][0]
headers = {l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⻣"):l1l1l1_l1_ (u"࠭ࠧ⻤")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l11l11_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻥"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⻦"),l1l1l1_l1_ (u"ࠩࠪ⻧"),329,l1l1l1_l1_ (u"ࠪࠫ⻨"),l1l1l1_l1_ (u"ࠫࠬ⻩"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⻪"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⻫"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⻬"),l1l1l1_l1_ (u"ࠨࠩ⻭"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭⻮"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ⻯"),l1l1l1_l1_ (u"ࠫࠬ⻰"),headers,l1l1l1_l1_ (u"ࠬ࠭⻱"),l1l1l1_l1_ (u"࠭ࠧ⻲"),l1l1l1_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⻳"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡦࡳࡳࡵ࠭ࡱ࡮ࡸࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⻴"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⻵"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title==l1l1l1_l1_ (u"ࠪห้๋ใหสฬࠤฬ๊ๅาศํอࠬ⻶"): continue
		l111ll_l1_ = l1l11l_l1_+l111ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻷"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⻸")+menu_name+title,l111ll_l1_,321)
	return html
def l11l11_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ⻹"),l1l1l1_l1_ (u"ࠧࠨ⻺"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ⻻"),url,l1l1l1_l1_ (u"ࠩࠪ⻼"),headers,l1l1l1_l1_ (u"ࠪࠫ⻽"),l1l1l1_l1_ (u"ࠫࠬ⻾"),l1l1l1_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⻿"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡲࡸࡪࡸࠧ⼀"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡳࡨ࠺ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࡬࠸࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⼁"),block,re.DOTALL)
	if not items: items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡴ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⼂"),block,re.DOTALL)
	for l111ll_l1_,img,count,title in items:
		count = count.replace(l1l1l1_l1_ (u"ࠩ฼ำิࠦࠧ⼃"),l1l1l1_l1_ (u"ࠪࠫ⼄")).replace(l1l1l1_l1_ (u"ࠫࠥ࠭⼅"),l1l1l1_l1_ (u"ࠬ࠭⼆"))
		l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"࠭࠯ࠨ⼇"),l1l1l1_l1_ (u"ࠧࠨ⼈"))
		img = img.replace(l1l1l1_l1_ (u"ࠣࠩࠥ⼉"),l1l1l1_l1_ (u"ࠩࠪ⼊"))
		if l1l1l1_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨ⼋") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ⼌")+l111ll_l1_
		l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ⼍")+l111ll_l1_
		img = l1l11l_l1_+img
		title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ⼎"))
		title = title+l1l1l1_l1_ (u"ࠧࠡࠪࠪ⼏")+count+l1l1l1_l1_ (u"ࠨࠫࠪ⼐")
		if l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ⼑") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼒"),menu_name+title,l111ll_l1_,321,img)
		elif l1l1l1_l1_ (u"ࠫࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ⼓") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⼔"),menu_name+title,l111ll_l1_,322,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡲࡸࡪࡸࠧ⼕"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⼖"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ⼗")+l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼘"),menu_name+l1l1l1_l1_ (u"ูࠪๆำษࠡࠩ⼙")+title,l111ll_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ⼚"),url,l1l1l1_l1_ (u"ࠬ࠭⼛"),headers,l1l1l1_l1_ (u"࠭ࠧ⼜"),l1l1l1_l1_ (u"ࠧࠨ⼝"),l1l1l1_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⼞"))
	html = response.content
	#l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡥࡺࡪࡩࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⼟"),html,re.DOTALL)
	#if not l111ll_l1_:
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⼠"),html,re.DOTALL)
	l111ll_l1_ = l1l11l_l1_+l111ll_l1_[0]#+l1l1l1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ⼡")+l1l1l11ll_l1_()+l1l1l1_l1_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡸࡷࡻࡥࠨ⼢")
	PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⼣"))
	return
def SEARCH(search):
	#search = l1l1l1_l1_ (u"ࠧๆะอหึ࠭⼤")
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠨࠩ⼥"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠩࠪ⼦"): return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬ⼧"),l1l1l1_l1_ (u"ࠫ࠰࠭⼨"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭⼩")+search
	l11l11_l1_(url)
	return
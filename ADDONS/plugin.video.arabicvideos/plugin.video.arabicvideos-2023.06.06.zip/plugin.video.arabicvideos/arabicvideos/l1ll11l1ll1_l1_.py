# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨㅪ")
l1l11l_l1_ = WEBSITES[l1l1l1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩㅫ")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l1l1l1_l1_ (u"ࠪ࠴ࠬㅬ"),True)
	elif mode==102: results = ITEMS(l1l1l1_l1_ (u"ࠫ࠶࠭ㅭ"),True)
	elif mode==103: results = ITEMS(l1l1l1_l1_ (u"ࠬ࠸ࠧㅮ"),True)
	elif mode==104: results = ITEMS(l1l1l1_l1_ (u"࠭࠳ࠨㅯ"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l1l1l1_l1_ (u"ࠧ࠵ࠩㅰ"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㅱ"),l1l1l1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨㅲ")+l1l1l1_l1_ (u"่้๋ࠪิหำๆ๎๋ࠦศฯั่อࠥࡓ࠳ࡖࠩㅳ"),l1l1l1_l1_ (u"ࠫࠬㅴ"),710)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅵ"),l1l1l1_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬㅶ")+l1l1l1_l1_ (u"ࠧๅๆุ่ฯืใ๋่ࠣฬำีๅสࠢࡌࡔ࡙࡜ࠧㅷ"),l1l1l1_l1_ (u"ࠨࠩㅸ"),230)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㅹ"),l1l1l1_l1_ (u"ࠪࡣ࡙࡜࠰ࡠࠩㅺ")+l1l1l1_l1_ (u"ࠫ็์่ศฬ้๋ࠣࠦๅ้ษๅ฽์อࠠศๆฦู้๐ษࠨㅻ"),l1l1l1_l1_ (u"ࠬ࠭ㅼ"),101)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅽ"),l1l1l1_l1_ (u"ࠧࡠࡖ࡙࠸ࡤ࠭ㅾ")+l1l1l1_l1_ (u"ࠨไ้์ฬะࠠๆะอหึฯࠠๆ่ࠣ๎ํะ๊้สࠪㅿ"),l1l1l1_l1_ (u"ࠩࠪㆀ"),106)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㆁ"),l1l1l1_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪㆂ")+l1l1l1_l1_ (u"่ࠬๆ้ษอࠤ฾ืศ๋ห้๋๊้ࠣࠦฬํ์อ࠭ㆃ"),l1l1l1_l1_ (u"࠭ࠧㆄ"),147)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆅ"),l1l1l1_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧㆆ")+l1l1l1_l1_ (u"ࠩๅ๊ํอสࠡลฯ๊อ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫㆇ"),l1l1l1_l1_ (u"ࠪࠫㆈ"),148)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆉ"),l1l1l1_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫㆊ")+l1l1l1_l1_ (u"࠭ࠠࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠣࠤࠬㆋ"),l1l1l1_l1_ (u"ࠧࠨㆌ"),28)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭ㆍ"),l1l1l1_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨㆎ")+l1l1l1_l1_ (u"ࠪๆ๋อษࠡษ็้฾อัโ่๊๋่ࠢࠥใ฻๊้ࠬ㆏"),l1l1l1_l1_ (u"ࠫࠬ㆐"),41)
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㆑"),l1l1l1_l1_ (u"࠭࡟ࡌ࡙ࡗࡣࠬ㆒")+l1l1l1_l1_ (u"ࠧใ่สอࠥอไไ๊ฮี๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㆓"),l1l1l1_l1_ (u"ࠨࠩ㆔"),135)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㆕"),l1l1l1_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ㆖")+l1l1l1_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭㆗"),l1l1l1_l1_ (u"ࠬ࠭㆘"),38)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㆙"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㆚"),l1l1l1_l1_ (u"ࠨࠩ㆛"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㆜"),l1l1l1_l1_ (u"ࠪࡣ࡙࡜࠱ࡠࠩ㆝")+l1l1l1_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮูࠦศ็ฬࠫ㆞"),l1l1l1_l1_ (u"ࠬ࠭㆟"),102)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㆠ"),l1l1l1_l1_ (u"ࠧࡠࡖ࡙࠶ࡤ࠭ㆡ")+l1l1l1_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣาฬ฻ษࠨㆢ"),l1l1l1_l1_ (u"ࠩࠪㆣ"),103)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㆤ"),l1l1l1_l1_ (u"ࠫࡤ࡚ࡖ࠴ࡡࠪㆥ")+l1l1l1_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠๅๆไัฺ࠭ㆦ"),l1l1l1_l1_ (u"࠭ࠧㆧ"),104)
	return
def ITEMS(l1lll1lll1_l1_,showDialogs=True):
	menu_name = l1l1l1_l1_ (u"ࠧࡠࡖ࡙ࠫㆨ")+l1lll1lll1_l1_+l1l1l1_l1_ (u"ࠨࡡࠪㆩ")
	client = l1ll11l1lll_l1_(32)
	payload = {l1l1l1_l1_ (u"ࠩ࡬ࡨࠬㆪ"):l1l1l1_l1_ (u"ࠪࠫㆫ"),l1l1l1_l1_ (u"ࠫࡺࡹࡥࡳࠩㆬ"):client,l1l1l1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧㆭ"):l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࠫㆮ"),l1l1l1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬㆯ"):l1lll1lll1_l1_}
	#data = l1lll11l1_l1_(payload)
	#LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨㆰ"),str(payload))
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩㆱ"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨㆲ"), l1l11l_l1_, payload, l1l1l1_l1_ (u"ࠫࠬㆳ"), True,l1l1l1_l1_ (u"ࠬ࠭ㆴ"),l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩㆵ"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬㆶ"),l1l11l_l1_,payload,l1l1l1_l1_ (u"ࠨࠩㆷ"),l1l1l1_l1_ (u"ࠩࠪㆸ"),l1l1l1_l1_ (u"ࠪࠫㆹ"),l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧㆺ"))
	html = response.content
	#html = html.replace(l1l1l1_l1_ (u"ࠬࡢࡲࠨㆻ"),l1l1l1_l1_ (u"࠭ࠧㆼ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨㆽ"),l1l1l1_l1_ (u"ࠨࠩㆾ"),html,html)
	#file = open(l1l1l1_l1_ (u"ࠩࡶ࠾࠴࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨㆿ"), l1l1l1_l1_ (u"ࠪࡻࠬ㇀"))
	#file.write(html)
	#file.close()
	items = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡡ࡞࠼࡞ࡵࡠࡳࡣࠫࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿࠭࠴ࠪࡀࠫ࠾࠿ࠬ㇁"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l1l1_l1_ (u"ࠬࡧ࡬ࠨ㇂"),l1l1l1_l1_ (u"࠭ࡁ࡭ࠩ㇃"))
			start = start.replace(l1l1l1_l1_ (u"ࠧࡆ࡮ࠪ㇄"),l1l1l1_l1_ (u"ࠨࡃ࡯ࠫ㇅"))
			start = start.replace(l1l1l1_l1_ (u"ࠩࡄࡐࠬ㇆"),l1l1l1_l1_ (u"ࠪࡅࡱ࠭㇇"))
			start = start.replace(l1l1l1_l1_ (u"ࠫࡊࡒࠧ㇈"),l1l1l1_l1_ (u"ࠬࡇ࡬ࠨ㇉"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l1l1_l1_ (u"࠭ࡁ࡭࠯ࠪ㇊"),l1l1l1_l1_ (u"ࠧࡂ࡮ࠪ㇋"))
			start = start.replace(l1l1l1_l1_ (u"ࠨࡃ࡯ࠤࠬ㇌"),l1l1l1_l1_ (u"ࠩࡄࡰࠬ㇍"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,id2,name,img in items:
			if l1l1l1_l1_ (u"ࠪࠧࠬ㇎") in source: continue
			#if source in [l1l1l1_l1_ (u"ࠫࡓ࡚ࠧ㇏"),l1l1l1_l1_ (u"ࠬ࡟ࡕࠨ㇐"),l1l1l1_l1_ (u"࠭ࡗࡔ࠲ࠪ㇑"),l1l1l1_l1_ (u"ࠧࡓࡎ࠴ࠫ㇒"),l1l1l1_l1_ (u"ࠨࡔࡏ࠶ࠬ㇓")]: continue
			if source!=l1l1l1_l1_ (u"ࠩࡘࡖࡑ࠭㇔"): name = name+l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠࠡࠩ㇕")+source+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㇖")
			url = source+l1l1l1_l1_ (u"ࠬࡁ࠻ࠨ㇗")+server+l1l1l1_l1_ (u"࠭࠻࠼ࠩ㇘")+id2+l1l1l1_l1_ (u"ࠧ࠼࠽ࠪ㇙")+l1lll1lll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㇚"),menu_name+l1l1l1_l1_ (u"ࠩࠪ㇛")+name,url,105,img)
	else:
		if showDialogs: addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㇜"),menu_name+l1l1l1_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㇝"),l1l1l1_l1_ (u"ࠬ࠭㇞"),9999)
		#if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ㇟"),l1l1l1_l1_ (u"ࠧࠨ㇠"),l1l1l1_l1_ (u"ࠨࠩ㇡"),l1l1l1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㇢"))
		#addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㇣"),menu_name+l1l1l1_l1_ (u"้๊ࠫริใ่ࠣฬࠦส้ฮาࠤ็์่ศฬࠣฮ้็า้่ํอ๊ࠥใࠨ㇤"),l1l1l1_l1_ (u"ࠬ࠭㇥"),9999)
		#addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㇦"),menu_name+l1l1l1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้ࠣอโาสสลࠥ๎วๅษุำ็อมࠡใๅ฻ࠬ㇧"),l1l1l1_l1_ (u"ࠨࠩ㇨"),9999)
		#addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㇩"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㇪"),l1l1l1_l1_ (u"ࠫࠬ㇫"),9999)
		#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㇬"),menu_name+l1l1l1_l1_ (u"࠭ࡕ࡯ࡨࡲࡶࡹࡻ࡮ࡢࡶࡨࡰࡾ࠲ࠠ࡯ࡱࠣࡘ࡛ࠦࡣࡩࡣࡱࡲࡪࡲࡳࠡࡨࡲࡶࠥࡿ࡯ࡶࠩ㇭"),l1l1l1_l1_ (u"ࠧࠨ㇮"),9999)
		#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㇯"),menu_name+l1l1l1_l1_ (u"ࠩࡌࡸࠥ࡯ࡳࠡࡨࡲࡶࠥࡸࡥ࡭ࡣࡷ࡭ࡻ࡫ࡳࠡࠨࠣࡪࡷ࡯ࡥ࡯ࡦࡶࠤࡴࡴ࡬ࡺࠩㇰ"),l1l1l1_l1_ (u"ࠪࠫㇱ"),9999)
	return
def PLAY(id):
	source,server,id2,l1lll1lll1_l1_ = id.split(l1l1l1_l1_ (u"ࠫࡀࡁࠧㇲ"))
	url = l1l1l1_l1_ (u"ࠬ࠭ㇳ")
	if source==l1l1l1_l1_ (u"࠭ࡕࡓࡎࠪㇴ"): url = id2
	elif source==l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨㇵ"):
		url = WEBSITES[l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩㇶ")][0]+l1l1l1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬㇷ")+id2
		import ll_l1_
		ll_l1_.l1l_l1_([url],script_name,l1l1l1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨㇸ"),url)
		return
	elif source==l1l1l1_l1_ (u"ࠫࡌࡇࠧㇹ"):
		payload = { l1l1l1_l1_ (u"ࠬ࡯ࡤࠨㇺ") : l1l1l1_l1_ (u"࠭ࠧㇻ"), l1l1l1_l1_ (u"ࠧࡶࡵࡨࡶࠬㇼ") : l1ll11l1lll_l1_(32) , l1l1l1_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪㇽ") : l1l1l1_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠳ࠪㇾ") , l1l1l1_l1_ (u"ࠪࡱࡪࡴࡵࠨㇿ") : l1l1l1_l1_ (u"ࠫࠬ㈀") }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ㈁"),l1l11l_l1_,payload,l1l1l1_l1_ (u"࠭ࠧ㈂"),False,l1l1l1_l1_ (u"ࠧࠨ㈃"),l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㈄"))
		if not response.succeeded:
			DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㈅"),l1l1l1_l1_ (u"ࠪࠫ㈆"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㈇"),l1l1l1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㈈"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1ll11l1l1l_l1_ = cookies[l1l1l1_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࠪ㈉")]
		url = response.headers[l1l1l1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㈊")]
		payload = { l1l1l1_l1_ (u"ࠨ࡫ࡧࠫ㈋") : id2 , l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸࠧ㈌") : l1ll11l1lll_l1_(32) , l1l1l1_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㈍") : l1l1l1_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠶ࠬ㈎") , l1l1l1_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㈏") : l1l1l1_l1_ (u"࠭ࠧ㈐") }
		headers = { l1l1l1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ㈑") : l1l1l1_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࡂ࠭㈒")+l1ll11l1l1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭㈓"),l1l11l_l1_,payload,headers,l1l1l1_l1_ (u"ࠪࠫ㈔"),l1l1l1_l1_ (u"ࠫࠬ㈕"),l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ㈖"))
		if not response.succeeded:
			DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ㈗"),l1l1l1_l1_ (u"ࠧࠨ㈘"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㈙"),l1l1l1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㈚"))
			return
		html = response.content
		url = re.findall(l1l1l1_l1_ (u"ࠪࡶࡪࡹࡰࠣ࠼ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃࡲ࠹ࡵ࠹ࠫࠫ࠲࠯ࡅࠩࠣࠩ㈛"),html,re.DOTALL)
		l111ll_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ㈜"),l1l1l1_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭㈝")+l111ll_l1_)
		#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ㈞"),l1l1l1_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠠࠨ㈟")+params)
		l1ll11l1l11_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠵࠻࠲ࠬ㈠")+server+l1l1l1_l1_ (u"ࠩ࠺࠻࠼࠵ࠧ㈡")+id2+l1l1l1_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㈢")+params
		l1ll11ll11l_l1_ = l1ll11l1l11_l1_.replace(l1l1l1_l1_ (u"ࠫ࠸࠼࠺࠸ࠩ㈣"),l1l1l1_l1_ (u"ࠬ࠺࠰࠻࠹ࠪ㈤")).replace(l1l1l1_l1_ (u"࠭࡟ࡉࡆ࠱ࡱ࠸ࡻ࠸ࠨ㈥"),l1l1l1_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㈦"))
		l1ll11ll111_l1_ = l1ll11l1l11_l1_.replace(l1l1l1_l1_ (u"ࠨ࠵࠹࠾࠼࠭㈧"),l1l1l1_l1_ (u"ࠩ࠷࠶࠿࠽ࠧ㈨")).replace(l1l1l1_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㈩"),l1l1l1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㈪"))
		l1111ll_l1_ = [l1l1l1_l1_ (u"ࠬࡎࡄࠨ㈫"),l1l1l1_l1_ (u"࠭ࡓࡅ࠳ࠪ㈬"),l1l1l1_l1_ (u"ࠧࡔࡆ࠵ࠫ㈭")]
		l11l1_l1_ = [l1ll11l1l11_l1_,l1ll11ll11l_l1_,l1ll11ll111_l1_]
		selection = 0
		#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ㈮"), l1111ll_l1_)
		if selection == -1: return
		else: url = l11l1_l1_[selection]
	elif source==l1l1l1_l1_ (u"ࠩࡑࡘࠬ㈯"):
		headers = { l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㈰") : l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㈱") }
		payload = { l1l1l1_l1_ (u"ࠬ࡯ࡤࠨ㈲") : id2 , l1l1l1_l1_ (u"࠭ࡵࡴࡧࡵࠫ㈳") : l1ll11l1lll_l1_(32) , l1l1l1_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㈴") : l1l1l1_l1_ (u"ࠨࡲ࡯ࡥࡾࡔࡔࠨ㈵") , l1l1l1_l1_ (u"ࠩࡰࡩࡳࡻࠧ㈶") : l1lll1lll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㈷"), l1l11l_l1_, payload, headers, False,l1l1l1_l1_ (u"ࠫࠬ㈸"),l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㈹"))
		if not response.succeeded:
			DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ㈺"),l1l1l1_l1_ (u"ࠧࠨ㈻"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㈼"),l1l1l1_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㈽"))
			return
		html = response.content
		url = response.headers[l1l1l1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㈾")]
		url = url.replace(l1l1l1_l1_ (u"ࠫࠪ࠸࠰ࠨ㈿"),l1l1l1_l1_ (u"ࠬࠦࠧ㉀"))
		url = url.replace(l1l1l1_l1_ (u"࠭ࠥ࠴ࡆࠪ㉁"),l1l1l1_l1_ (u"ࠧ࠾ࠩ㉂"))
		if l1l1l1_l1_ (u"ࠨࡎࡨࡥࡷࡴࠧ㉃") in id2:
			url = url.replace(l1l1l1_l1_ (u"ࠩࡑࡘࡓࡔࡩ࡭ࡧࠪ㉄"),l1l1l1_l1_ (u"ࠪࠫ㉅"))
			url = url.replace(l1l1l1_l1_ (u"ࠫࡱ࡫ࡡࡳࡰ࡬ࡲ࡬࠷ࠧ㉆"),l1l1l1_l1_ (u"ࠬࡒࡥࡢࡴࡱ࡭ࡳ࡭ࠧ㉇"))
	elif source==l1l1l1_l1_ (u"࠭ࡐࡍࠩ㉈"):
		#headers = { l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㉉") : l1l1l1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㉊") }
		payload = { l1l1l1_l1_ (u"ࠩ࡬ࡨࠬ㉋") : id2 , l1l1l1_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㉌") : l1ll11l1lll_l1_(32) , l1l1l1_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㉍") : l1l1l1_l1_ (u"ࠬࡶ࡬ࡢࡻࡓࡐࠬ㉎") , l1l1l1_l1_ (u"࠭࡭ࡦࡰࡸࠫ㉏") : l1lll1lll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ㉐"), l1l11l_l1_, payload, l1l1l1_l1_ (u"ࠨࠩ㉑"),False,l1l1l1_l1_ (u"ࠩࠪ㉒"),l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ㉓"))
		if not response.succeeded:
			DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ㉔"),l1l1l1_l1_ (u"ࠬ࠭㉕"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㉖"),l1l1l1_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㉗"))
			return
		html = response.content
		url = response.headers[l1l1l1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㉘")]
		headers = {l1l1l1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㉙"):response.headers[l1l1l1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㉚")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ㉛"),url, l1l1l1_l1_ (u"ࠬ࠭㉜"),headers , l1l1l1_l1_ (u"࠭ࠧ㉝"),l1l1l1_l1_ (u"ࠧࠨ㉞"),l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ㉟"))
		if not response.succeeded:
			DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㉠"),l1l1l1_l1_ (u"ࠪࠫ㉡"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㉢"),l1l1l1_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㉣"))
			return
		html = response.content
		items = re.findall(l1l1l1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㉤"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l1l1_l1_ (u"ࠧࡕࡃࠪ㉥"),l1l1l1_l1_ (u"ࠨࡈࡐࠫ㉦"),l1l1l1_l1_ (u"ࠩ࡜࡙ࠬ㉧"),l1l1l1_l1_ (u"࡛ࠪࡘ࠷ࠧ㉨"),l1l1l1_l1_ (u"ࠫ࡜࡙࠲ࠨ㉩"),l1l1l1_l1_ (u"ࠬࡘࡌ࠲ࠩ㉪"),l1l1l1_l1_ (u"࠭ࡒࡍ࠴ࠪ㉫")]:
		if source==l1l1l1_l1_ (u"ࠧࡕࡃࠪ㉬"): id2 = id
		headers = { l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㉭") : l1l1l1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㉮") }
		payload = { l1l1l1_l1_ (u"ࠪ࡭ࡩ࠭㉯") : id2 , l1l1l1_l1_ (u"ࠫࡺࡹࡥࡳࠩ㉰") : l1ll11l1lll_l1_(32) , l1l1l1_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㉱") : l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼࠫ㉲")+source , l1l1l1_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㉳") : l1lll1lll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㉴"),l1l11l_l1_,payload,headers,l1l1l1_l1_ (u"ࠩࠪ㉵"),l1l1l1_l1_ (u"ࠪࠫ㉶"),l1l1l1_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠹ࡸ࡭࠭㉷"))
		if not response.succeeded:
			DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭㉸"),l1l1l1_l1_ (u"࠭ࠧ㉹"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㉺"),l1l1l1_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㉻"))
			return
		html = response.content
		url = response.headers[l1l1l1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㉼")]
		if source==l1l1l1_l1_ (u"ࠪࡊࡒ࠭㉽"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ㉾"), url, l1l1l1_l1_ (u"ࠬ࠭㉿"), l1l1l1_l1_ (u"࠭ࠧ㊀"), False,l1l1l1_l1_ (u"ࠧࠨ㊁"),l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠷ࡵࡪࠪ㊂"))
			url = response.headers[l1l1l1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㊃")]
			url = url.replace(l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㊄"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㊅"))
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠬࡲࡩࡷࡧࠪ㊆"))
	return
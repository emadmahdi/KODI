# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ哂")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡔࡊࡗࡣࠬ哃")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ哄"),l1l1l1_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩ哅"),l1l1l1_l1_ (u"ࠩฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠬ哆")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l11l11_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l11_l1_(url,text)
	elif mode==644: results = l1ll11_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ哇"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬ哈"),l1l1l1_l1_ (u"ࠬ࠭哉"),l1l1l1_l1_ (u"࠭ࠧ哊"),l1l1l1_l1_ (u"ࠧࠨ哋"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ哌"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ响"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ哎"),l1l1l1_l1_ (u"ࠫࠬ哏"),649,l1l1l1_l1_ (u"ࠬ࠭哐"),l1l1l1_l1_ (u"࠭ࠧ哑"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ哒"))
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭哓"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ哔"),l1l1l1_l1_ (u"ࠪࠫ哕"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ哖"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ哗")+menu_name+l1l1l1_l1_ (u"࠭วๅ็่๎ืฯࠧ哘"),l1l11l_l1_,641,l1l1l1_l1_ (u"ࠧࠨ哙"),l1l1l1_l1_ (u"ࠨࠩ哚"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ哛"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ哜"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭哝")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้๋่ใ฻ࠪ哞"),l1l11l_l1_,641,l1l1l1_l1_ (u"࠭ࠧ哟"),l1l1l1_l1_ (u"ࠧࠨ哠"),l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ員"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ哢"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ哣")+menu_name+l1l1l1_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪ哤"),l1l11l_l1_,641,l1l1l1_l1_ (u"ࠬ࠭哥"),l1l1l1_l1_ (u"࠭ࠧ哦"),l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ哧"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ哨"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ哩")+menu_name+l1l1l1_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠧ哪"),l1l11l_l1_,641,l1l1l1_l1_ (u"ࠫࠬ哫"),l1l1l1_l1_ (u"ࠬ࠭哬"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ哭"))
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ哮"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ哯"),l1l1l1_l1_ (u"ࠩࠪ哰"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ哱"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ哲"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ哳"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ哴")+menu_name+title,l111ll_l1_,644)
	#addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ哵"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ哶"),l1l1l1_l1_ (u"ࠩࠪ哷"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ哸"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ哹"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠬ࠭哺"))
	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ哻"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ哼"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ哽")+menu_name+title,l111ll_l1_,644)
	return
def l1ll11_l1_(url):
	l111lllll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭哾"),url,l1l1l1_l1_ (u"ࠪࠫ哿"),l1l1l1_l1_ (u"ࠫࠬ唀"),l1l1l1_l1_ (u"ࠬ࠭唁"),l1l1l1_l1_ (u"࠭ࠧ唂"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ唃"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ唄"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪ唅"),l1l1l1_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩ唆"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ唇"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠬ࠭唈"),block)]
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ唉"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ唊"),l1l1l1_l1_ (u"ࠨࠩ唋"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			l111lllll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ唌"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠪ࠾ࠥ࠭唍")
			for l111ll_l1_,title in l111lllll_l1_:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ唎"),menu_name+title,l111ll_l1_,641)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ唏"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ唐"),block,re.DOTALL)
		if len(l1ll1ll_l1_)<30:
			if l111lllll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ唑"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ唒"),l1l1l1_l1_ (u"ࠩࠪ唓"),9999)
			for l111ll_l1_,title in l1ll1ll_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ唔"),menu_name+title,l111ll_l1_,641)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠫࠬ唕")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭唖"),l1l1l1_l1_ (u"࠭ࠧ唗"),request,url)
	if request==l1l1l1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ唘"):
		url,search = url.split(l1l1l1_l1_ (u"ࠨࡁࠪ唙"),1)
		data = l1l1l1_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ唚")+search
		headers = {l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ唛"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ唜")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ唝"),url,data,headers,l1l1l1_l1_ (u"࠭ࠧ唞"),l1l1l1_l1_ (u"ࠧࠨ唟"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ唠"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭唡"),url,l1l1l1_l1_ (u"ࠪࠫ唢"),l1l1l1_l1_ (u"ࠫࠬ唣"),l1l1l1_l1_ (u"ࠬ࠭唤"),l1l1l1_l1_ (u"࠭ࠧ唥"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ唦"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠨࠩ唧"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭唨"))
	if request==l1l1l1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ唩"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭唪"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠬ࠭唫"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ唬"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ唭"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ售"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ唯"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ唰"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ唱"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ唲"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ唳"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ唴"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠨࠩ唵"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ唶"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ唷"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ฺ๊ࠫว่ัฬࠫ唸"),l1l1l1_l1_ (u"ࠬ็๊ๅ็ࠪ唹"),l1l1l1_l1_ (u"࠭ว฻่ํอࠬ唺"),l1l1l1_l1_ (u"ࠧไๆํฬࠬ唻"),l1l1l1_l1_ (u"ࠨษ฼่ฬ์ࠧ唼"),l1l1l1_l1_ (u"๊ࠩำฬ็ࠧ唽"),l1l1l1_l1_ (u"้ࠪออัศหࠪ唾"),l1l1l1_l1_ (u"ࠫ฾ืึࠨ唿"),l1l1l1_l1_ (u"๋ࠬ็าฮส๊ࠬ啀"),l1l1l1_l1_ (u"࠭วๅส๋้ࠬ啁"),l1l1l1_l1_ (u"ࠧๆีิั๏ฯࠧ啂")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ啃"))
		#if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ啄") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬ啅")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭商"))
		#if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ啇") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ啈")+img.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ啉"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪ啊"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ啋"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ啌"),menu_name+title,l111ll_l1_,642,img)
		elif request==l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ啍"):
			addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ啎"),menu_name+title,l111ll_l1_,642,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ問") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ啐"),menu_name+title,l111ll_l1_,643,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭啑") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ啒"),menu_name+title,l111ll_l1_,641,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ啓"),menu_name+title,l111ll_l1_,643,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ啔"),l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ啕")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ啖"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ啗"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠨࠥࠪ啘"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ啙")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬ啚"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ啛"),menu_name+l1l1l1_l1_ (u"ࠬ฻แฮหࠣࠫ啜")+title,l111ll_l1_,641)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ啝"),l1l1l1_l1_ (u"ࠧࠨ啞"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ啟"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭啠"),url,l1l1l1_l1_ (u"ࠪࠫ啡"),l1l1l1_l1_ (u"ࠫࠬ啢"),l1l1l1_l1_ (u"ࠬ࠭啣"),l1l1l1_l1_ (u"࠭ࠧ啤"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭啥"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ啦"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ啧"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"ࠪࠫ啨")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭啩"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠬࠩࠧ啪"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭啫"),menu_name+title,url,643,img,l1l1l1_l1_ (u"ࠧࠨ啬"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩ啭")+l1lll_l1_+l1l1l1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ啮"),html,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ啯"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		#if not items: items = re.findall(l1l1l1_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ啰"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ啱")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨ啲"))
			title = title.replace(l1l1l1_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾࠽ࡧࡰࡂࠬ啳"),l1l1l1_l1_ (u"ࠨࠢࠪ啴"))
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ啵"),menu_name+title,l111ll_l1_,642,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ啶"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ啷") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ啸")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨ啹"))
		#		addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭啺"),menu_name+title,l111ll_l1_,642,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l11_l1_,l111l11_l1_ = [],[],[]
	url2 = url.replace(l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬ啻"),l1l1l1_l1_ (u"ࠩ࠲ࡺ࡮࡫ࡷ࠯ࡲ࡫ࡴࠬ啼"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ啽"),url2,l1l1l1_l1_ (u"ࠫࠬ啾"),l1l1l1_l1_ (u"ࠬ࠭啿"),l1l1l1_l1_ (u"࠭ࠧ喀"),l1l1l1_l1_ (u"ࠧࠨ喁"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ喂"))
	html = response.content
	# l11ll1l1l_l1_ l111ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡦࡨࡨ࠲ࡼࡩࡥࡧࡲࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ喃"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ善"),block,re.DOTALL)
		if l1ll_l1_:
			l111ll_l1_ = l1ll_l1_[0]
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ喅"))
				l11l1_l1_.append(l111ll_l1_)
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭喆"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l111ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭喇"),block,re.DOTALL)
		block = block.replace(l1l1l1_l1_ (u"ࠧ࡝࡞ࠥࠫ喈"),l1l1l1_l1_ (u"ࠨࠤࠪ喉")).replace(l1l1l1_l1_ (u"ࠩ࡟࠳ࠬ喊"),l1l1l1_l1_ (u"ࠪ࠳ࠬ喋"))
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡂࡩࡧࡴࡤࡱࡪ࠴ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ喌"),block,re.DOTALL)
		if len(l111ll111_l1_)==len(l1ll_l1_):
			for id,title in l111ll111_l1_:
				l111ll_l1_ = l1ll_l1_[int(id)]
				if l111ll_l1_ not in l11l1_l1_:
					l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭喍")+title+l1l1l1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ喎"))
					l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࡖࡩࡷࡼࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ喏"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ喐"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ喑")+title+l1l1l1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ喒"))
				l11l1_l1_.append(l111ll_l1_)
	zzz = zip(l11l1_l1_,l111l1l11_l1_)
	for l111ll_l1_,name in zzz: l111l11_l1_.append(l111ll_l1_+name)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ喓"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ喔"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ喕"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ喖"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ喗"),l1l1l1_l1_ (u"ࠩ࠮ࠫ喘"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ喙")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ喚"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ喛")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ喜"))
	return
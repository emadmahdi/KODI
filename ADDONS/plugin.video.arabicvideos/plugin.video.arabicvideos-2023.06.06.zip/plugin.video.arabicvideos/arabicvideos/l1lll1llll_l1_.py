# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡥ࠰࠷࡬ࡪࡲࡡ࡭࠰ࡷࡺࠬᤑ")
#l1l11l_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠵ࡪࡨࡰࡦࡲ࠮ࡵࡸࠪᤒ")
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࠺ࡨࡦ࡮ࡤࡰ࠳ࡺࡶࠨᤓ")
script_name = l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪᤔ")
headers = { l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᤕ") : l1l1l1_l1_ (u"ࠪࠫᤖ") }
menu_name = l1l1l1_l1_ (u"ࠫࡤࡉࡍࡇࡡࠪᤗ")
l1l11l_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l1111l11_l1_()
	elif mode==95: results = l11l1ll_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤘ"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᤙ"),l1l1l1_l1_ (u"ࠧࠨᤚ"),99,l1l1l1_l1_ (u"ࠨࠩᤛ"),l1l1l1_l1_ (u"ࠩࠪᤜ"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᤝ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᤞ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᤟"),l1l1l1_l1_ (u"࠭ࠧᤠ"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᤡ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᤢ")+menu_name+l1l1l1_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨᤣ"),l1l1l1_l1_ (u"ࠪࠫᤤ"),94)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤥ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᤦ")+menu_name+l1l1l1_l1_ (u"࠭วๅละำะ࠭ᤧ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭ࡣࡷࡩࡸࡺࠧᤨ"),91)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᤩ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᤪ")+menu_name+l1l1l1_l1_ (u"ࠪห้ษูๅ๋ࠣฮ็๐ๅศํࠪᤫ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁ࡮ࡳࡤࡣࠩ᤬"),91)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᤭"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᤮")+menu_name+l1l1l1_l1_ (u"ࠧศๆฦ็ะืࠠๆึส๋ิฯࠧ᤯"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡸ࡬ࡩࡼ࠭ᤰ"),91)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤱ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᤲ")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅฬสอࠫᤳ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡶࡩ࡯ࠩᤴ"),91)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤵ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᤶ")+menu_name+l1l1l1_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧᤷ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡱࡩࡼࡓ࡯ࡷ࡫ࡨࡷࠬᤸ"),91)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ᤹ࠪ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᤺")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอ᤻ࠫ"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡮ࡦࡹࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫ᤼"),91)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᤽"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᤾"),l1l1l1_l1_ (u"ࠩࠪ᤿"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᥀"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᥁")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้๋่ใ฻ࠪ᥂"),l1l11l_l1_,91)
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"࠭ࠧ᥃"),headers,l1l1l1_l1_ (u"ࠧࠨ᥄"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ᥅"))
	#upper l1lll1lll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡥ࡮ࡴ࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪࡰࡤࡺࠬ᥆"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ᥇"),block,re.DOTALL)
	l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠫฬ็ไศ็่้้ࠣศศำࠣๅ็฽ࠧ᥈")]
	for l111ll_l1_,title in items:
		title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧ᥉"))
		if not any(value in title for value in l1l1ll_l1_):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᥊"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᥋")+menu_name+title,l111ll_l1_,91)
	return html
def ITEMS(url):
	if l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵ࠭᥌") in url:
		url,search = url.split(l1l1l1_l1_ (u"ࠩࡂࡸࡂ࠭᥍"))
		headers = { l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᥎") : l1l1l1_l1_ (u"ࠫࠬ᥏") , l1l1l1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᥐ") : l1l1l1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᥑ") }
		data = { l1l1l1_l1_ (u"ࠧࡵࠩᥒ") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᥓ"),url,data,headers,l1l1l1_l1_ (u"ࠩࠪᥔ"),l1l1l1_l1_ (u"ࠪࠫᥕ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩᥖ"))
		html = response.content
	else:
		headers = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᥗ") : l1l1l1_l1_ (u"࠭ࠧᥘ") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨᥙ"),headers,l1l1l1_l1_ (u"ࠨࠩᥚ"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡎ࡚ࡅࡎࡕ࠰࠶ࡳࡪࠧᥛ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹ࠭ࡪࡶࡨࡱࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴࡧࡱࡲࡸࠧ࠭ᥜ"),html,re.DOTALL)
	if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	else: block = l1l1l1_l1_ (u"ࠫࠬᥝ")
	items = re.findall(l1l1l1_l1_ (u"ࠬࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡱࡴࡼࡩࡦ࠯ࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᥞ"),block,re.DOTALL)
	l1l1_l1_ = []
	for img,l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"࠭วๅฯ็ๆฮ࠭ᥟ") in title and l1l1l1_l1_ (u"ࠧ࠰ࡥ࠲ࠫᥠ") not in url and l1l1l1_l1_ (u"ࠨ࠱ࡦࡥࡹ࠵ࠧᥡ") not in url:
			l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡝࠳࠱࠾ࡣࠫࠨᥢ"),title,re.DOTALL)
			if l1llll1_l1_:
				title = l1l1l1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᥣ")+l1llll1_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥤ"),menu_name+title,l111ll_l1_,95,img)
					l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴࠭ᥥ") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᥦ"),menu_name+title,l111ll_l1_,92,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᥧ"),menu_name+title,l111ll_l1_,91,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᥨ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᥩ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"ࠪห้฻แฮหࠣࠫᥪ"),l1l1l1_l1_ (u"ࠫࠬᥫ"))
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥬ"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬᥭ")+title,l111ll_l1_,91)
	return
def l11l1ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨ᥮"),headers,l1l1l1_l1_ (u"ࠨࠩ᥯"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᥰ"))
	img = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᥱ"),html,re.DOTALL)
	img = img[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪᥲ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		name = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᥳ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l1l1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧᥴ"))
			if l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᥵") in name: name = name.split(l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᥶"),1)[1]
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᥷"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᥸"),menu_name+name+l1l1l1_l1_ (u"ࠫࠥ࠳ࠠࠨ᥹")+title,l111ll_l1_,92,img)
	else:
		tmp = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳ࡯ࡷ࡫ࡨࡸ࡮ࡺ࡬ࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ᥺"),html,re.DOTALL)
		if tmp: l111ll_l1_,title = tmp[0]
		else: l111ll_l1_,title = url,name
		addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᥻"),menu_name+title,l111ll_l1_,92,img)
	return
def PLAY(url):
	l11l1_l1_,l1lll1ll1l_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨ᥼"),headers,l1l1l1_l1_ (u"ࠨࠩ᥽"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭᥾"))
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡸࡪࡾࡴ࠮ࡵ࡫ࡥࡩࡵࡷ࠻ࠢࡱࡳࡳ࡫࠻ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᥿"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧᦀ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᦁ"),block,re.DOTALL)
		for l111ll_l1_ in items:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᦂ")
			l11l1_l1_.append(l111ll_l1_)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࡯ࡣࡹ࠱ࡹࡧࡢࡴࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴ࠳ࡰࡢࡰࡨࡰ࠲ࡳ࡯ࡳࡧࠪᦃ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		# l1l1111ll_l1_ l1ll_l1_
		items = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡦ࡯ࡥࡩࡩࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᦄ"),block,re.DOTALL)
		for id,l111ll_l1_ in items:
			title = l1l1l1_l1_ (u"ࠩึ๎ึ็ัࠡࠩᦅ")+id
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᦆ")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᦇ")
			l11l1_l1_.append(l111ll_l1_)
		# other l1ll_l1_
		items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᦈ"),block,re.DOTALL)
		for l111ll_l1_ in items:
			if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫᦉ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᦊ")+l111ll_l1_
			l111ll_l1_ = UNQUOTE(l111ll_l1_)
			l11l1_l1_.append(l111ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᦋ"),url)
	return
def l1111l11_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪᦌ"),headers,l1l1l1_l1_ (u"ࠪࠫᦍ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪᦎ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡬ࡲࡩ࡫ࡸ࠮࡮ࡤࡷࡹ࠳࡭ࡰࡸ࡬ࡩ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡩ࡯ࡦࡨࡼ࠲ࡹ࡬ࡪࡦࡨࡶ࠲ࡳ࡯ࡷ࡫ࡨࠫᦏ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᦐ"),block,re.DOTALL)
	for img,l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨᦑ") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᦒ"),menu_name+title,l111ll_l1_,92,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᦓ"),menu_name+title,l111ll_l1_,91,img)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠪࠫᦔ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠫࠬᦕ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠬࠦࠧᦖ"),l1l1l1_l1_ (u"࠭ࠫࠨᦗ"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡺ࠽ࠨᦘ")+search
	ITEMS(url)
	return
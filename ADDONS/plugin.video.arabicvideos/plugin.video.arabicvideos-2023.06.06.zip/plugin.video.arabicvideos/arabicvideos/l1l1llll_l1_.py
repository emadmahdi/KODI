# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
headers = { l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧস") : l1l1l1_l1_ (u"ࠫࠬহ") }
script_name = l1l1l1_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ঺")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬ঻")
l1l11l_l1_ = WEBSITES[script_name][0]
#l11l111_l1_ = [l1l1l1_l1_ (u"ࠧโ์็়้ࠬ"),l1l1l1_l1_ (u"ࠨๅ็๎อ࠭ঽ"),l1l1l1_l1_ (u"ࠩส่฾ืึࠡษ็หุฮฺ่์ࠪা"),l1l1l1_l1_ (u"ุ้ࠪือ๋หࠪি"),l1l1l1_l1_ (u"ู๊ࠫัฮ์๊ࠫী"),l1l1l1_l1_ (u"ࠬอฺ็์ฬࠫু"),l1l1l1_l1_ (u"࠭วฺๆส๊ࠬূ"),l1l1l1_l1_ (u"ࠧๅไสลࠬৃ")]
#proxy = l1l1l1_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰࠳࠸࠽࠳࠸࠰࠴࠰࠻࠻࠳࠷࠳࠱࠼࠶࠵࠷࠾ࠧৄ")
#proxy = l1l1l1_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ৅")+l1l11111_l1_[6][1]
#l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠪฬึอๅอࠩ৆"),l1l1l1_l1_ (u"ࠫศู๊ศสࠪে"),l1l1l1_l1_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭ৈ"),l1l1l1_l1_ (u"࠭วๅลฯ๋ืฯࠠศๆ็์า๐ษࠨ৉"),l1l1l1_l1_ (u"ࠧศๆๆ์ึูวหࠢส่ฯ฿ไ๋็ํอࠬ৊"),l1l1l1_l1_ (u"ࠨสิห๊าࠠศๆอู๊๐ๅࠨো"),l1l1l1_l1_ (u"ࠩส่฾อศࠡไอห้࠭ৌ"),l1l1l1_l1_ (u"ࠪห้฿วษࠢส่่๋ศ๋๊อีࠥࡖࡃࠨ্"),l1l1l1_l1_ (u"ࠫฬ๊ศาษ่ะࠬৎ")]
l1l1ll_l1_ = [l1l1l1_l1_ (u"๋ࠬีศำ฼อࠬ৏")]
def MAIN(mode,url,text):
	if   mode==350: results = MENU(url)
	elif mode==351: results = l11l11_l1_(url,text)
	elif mode==352: results = l11l1ll_l1_(url)
	elif mode==353: results = PLAY(url)
	elif mode==354: results = l1111l1_l1_(url,l1l1l1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ৐")+text)
	elif mode==355: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ৑")+text)
	elif mode==356: results = l1lll11l_l1_(url)
	elif mode==357: results = l11lllll_l1_(url)
	elif mode==359: results = SEARCH(text)
	else: results = False
	return results
def MENU(website=l1l1l1_l1_ (u"ࠨࠩ৒")):
	if website==l1l1l1_l1_ (u"ࠩࠪ৓"):
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ৔"),menu_name+l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ัษࠣห้๋่ใ฻้ࠣ฿๊โ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ৕"),l1l1l1_l1_ (u"ࠬ࠭৖"),8)
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫৗ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ৘"),l1l1l1_l1_ (u"ࠨࠩ৙"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ৚"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ৛"),l1l1l1_l1_ (u"ࠫࠬড়"),359,l1l1l1_l1_ (u"ࠬ࠭ঢ়"),l1l1l1_l1_ (u"࠭ࠧ৞"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫয়"))
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨৠ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫৡ")+menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ৢ"),l1l11l_l1_,356)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫৣ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ৤")+menu_name+l1l1l1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ৥"),l1l11l_l1_,357)
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ০"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ১"),l1l1l1_l1_ (u"ࠩࠪ২"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ৩"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭৪")+menu_name+l1l1l1_l1_ (u"ࠬอไๆิํำࠬ৫"),l1l11l_l1_,352,l1l1l1_l1_ (u"࠭ࠧ৬"),l1l1l1_l1_ (u"ࠧࠨ৭"),l1l1l1_l1_ (u"ࠨ࡯ࡲࡶࡪ࠭৮"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ৯"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬৰ")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊วฯสสีࠬৱ"),l1l11l_l1_,352,l1l1l1_l1_ (u"ࠬ࠭৲"),l1l1l1_l1_ (u"࠭ࠧ৳"),l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡷࠬ৴"))
	html = OPENURL_CACHED(REGULAR_CACHE,l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩ৵"),headers,l1l1l1_l1_ (u"ࠩࠪ৶"),l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ৷"))
	url2 = re.findall(l1l1l1_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡰࡾ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৸"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = l1l11l_l1_
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ৹"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ৺")+menu_name+l1l1l1_l1_ (u"ࠧศุํๅࠥำฯ๋อสࠫ৻"),url2,351)
	url2 = re.findall(l1l1l1_l1_ (u"ࠨࡂ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧৼ"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = l1l11l_l1_
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ৽"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ৾")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ৿"),url2,351,l1l1l1_l1_ (u"ࠬ࠭਀"),l1l1l1_l1_ (u"࠭ࠧਁ"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩਂ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠬਃ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡴࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ਄"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title not in l1l1ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪਅ"),menu_name+title,l111ll_l1_,351)
		if website==l1l1l1_l1_ (u"ࠫࠬਆ"): addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪਇ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ਈ"),l1l1l1_l1_ (u"ࠧࠨਉ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡨ࡯ࡹࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸࠧਊ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ਋"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = unescapeHTML(l111ll_l1_)
			if title not in l1l1ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ਌"),menu_name+title,l111ll_l1_,351)
	return html
def l1lll11l_l1_(website=l1l1l1_l1_ (u"ࠫࠬ਍")):
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭਎"),headers,l1l1l1_l1_ (u"࠭ࠧਏ"),l1l1l1_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫਐ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀࡳࡧࡶࠨ਑"),html,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ਒"),l1l1l1_l1_ (u"ࠪࠫਓ"),l111ll_l1_,l1ll1l1_l1_][0])
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫਔ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ਕ"),l1l1l1_l1_ (u"࠭ࠧਖ"),l111ll_l1_,title)
			if title not in l1l1ll_l1_:
				title = title+l1l1l1_l1_ (u"ࠧࠡ็ุ๊ๆฯࠧਗ")
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨਘ"),menu_name+title,l111ll_l1_,355)
		if website==l1l1l1_l1_ (u"ࠩࠪਙ"): addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨਚ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫਛ"),l1l1l1_l1_ (u"ࠬ࠭ਜ"),9999)
	return html
def l11lllll_l1_(website=l1l1l1_l1_ (u"࠭ࠧਝ")):
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨਞ"),headers,l1l1l1_l1_ (u"ࠨࠩਟ"),l1l1l1_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ਠ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࡮ࡢࡸࠪਡ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫਢ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title not in l1l1ll_l1_:
				title = title+l1l1l1_l1_ (u"ࠬࠦๅโๆอีฮ࠭ਣ")
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ਤ"),menu_name+title,l111ll_l1_,354)
		if website==l1l1l1_l1_ (u"ࠧࠨਥ"): addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ਦ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩਧ"),l1l1l1_l1_ (u"ࠪࠫਨ"),9999)
	return html
def l11l11_l1_(url,type=l1l1l1_l1_ (u"ࠫࠬ਩")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ਪ"),l1l1l1_l1_ (u"࠭ࠧਫ"),url,type)
	html = OPENURL_CACHED(NO_CACHE,url,l1l1l1_l1_ (u"ࠧࠨਬ"),headers,True,l1l1l1_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧਭ"))
	if type==l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫਮ"): l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡼ࡯ࡰࡦࡴ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡷࡼ࡯ࡰࡦࡴ࠰ࡦࡺࡺࡴࡰࡰ࠰ࡴࡷ࡫ࡶࠨਯ"),html,re.DOTALL)
	else: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡪࡴࡵࡴࡦࡴࠪਰ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬࡾ࡬ࡪࡰ࡮࠾࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ਱"),block,re.DOTALL)
		#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧਲ"),l1l1l1_l1_ (u"ࠧࠨਲ਼"),str(len(block)),url)
		l1l1_l1_ = []
		for img,l111ll_l1_,title in items:
			title = unescapeHTML(title)
			if l1l1l1_l1_ (u"ࠨษ็ั้่ษࠨ਴") in title or l1l1l1_l1_ (u"ࠩส่า๊โ่ࠩਵ") in title:
				l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡡࡪࠫࠨਸ਼"),title,re.DOTALL)
				if l1llll1_l1_:
					title = l1l1l1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ਷") + l1llll1_l1_[0][0]
					if title not in l1l1_l1_:
						addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਸ"),menu_name+title,l111ll_l1_,352,img)
						l1l1_l1_.append(title)
			elif l1l1l1_l1_ (u"࠭ๅิๆึ่ࠬਹ") in title:
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ਺"),menu_name+title,l111ll_l1_,352,img)
			else: addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ਻"),menu_name+title,l111ll_l1_,353,img)
			#if l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲਼ࠫ") in l111ll_l1_ or l1l1l1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡸࡵ࠲ࠫ਽") in l111ll_l1_:
			#	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫਾ"),menu_name+title,l111ll_l1_,352,img)
			#elif l1l1l1_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳࡳ࠰ࠩਿ") not in l111ll_l1_ and l1l1l1_l1_ (u"࠭࠯ࡨࡣࡰࡩࡸ࠵ࠧੀ") not in l111ll_l1_:
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨੁ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫੂ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#if l1l1l1_l1_ (u"ࠩࠩࡰࡸࡧࡱࡶࡱ࠾ࠫ੃") in title: title = l1l1l1_l1_ (u"ูࠪๆำษࠡีสฬ็ฯࠧ੄")
			#if l1l1l1_l1_ (u"ࠫࠫࡸࡳࡢࡳࡸࡳࡀ࠭੅") in title: title = l1l1l1_l1_ (u"ࠬ฻แฮห่ࠣฬำโสࠩ੆")
			#if l1l1l1_l1_ (u"࠭ࠦ࡭ࡣࡴࡹࡴ࠭ੇ") in title: title = l1l1l1_l1_ (u"ࠧศๆุๅาฯࠠศๆอห้๐ษࠨੈ")
			#if l1l1l1_l1_ (u"ࠨืไัฮ࠭੉") not in title: title = l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨ੊")+title
			l111ll_l1_ = unescapeHTML(l111ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪੋ"),menu_name+l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪੌ")+title,l111ll_l1_,351)
	return
def SEARCH(search):
	# l1ll1lll_l1_://l1l1111l_l1_.l1ll1l11_l1_/search?q=%l1l111l1_l1_%l1ll1l1l_l1_%l1l111l1_l1_%l1llll11_l1_%l1l111l1_l1_%l1ll111l_l1_
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"੍ࠬ࠭"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"࠭ࠧ੎"): return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠧࠡࠩ੏"),l1l1l1_l1_ (u"ࠨ࠭ࠪ੐"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠩ࠲ࡃࡸࡃࠧੑ")+l11ll11_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ੒"),l1l1l1_l1_ (u"ࠫࠬ੓"),url,l1l1l1_l1_ (u"࡙ࠬࡅࡂࡔࡆࡌࡤࡇࡋࡐࡃࡐࠫ੔"))
	results = l11l11_l1_(url)
	return
def l11l1ll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ੕"),l1l1l1_l1_ (u"ࠧࠨ੖"),url,l1l1l1_l1_ (u"ࠨࡇࡓࡍࡘࡕࡄࡆࡕࡢࡅࡐ࡝ࡁࡎࠩ੗"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠩࠪ੘"),headers,True,l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫਖ਼"))
	#if l1l1l1_l1_ (u"ࠫ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠧਗ਼") not in html:
	#	img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬਜ਼"))
	#	addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬੜ"),menu_name+l1l1l1_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭੝"),url,353,img)
	#else:
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡶࡨࡼࡹ࠳ࡷࡩ࡫ࡷࡩࠧࡄวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭ࡁ࡮ࡥࡢࡦࡨࡶࠬਫ਼"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੟"),block,re.DOTALL)
		for l111ll_l1_,img,title in l1ll1_l1_:
			if l1l1l1_l1_ (u"ࠪห้ำไใหࠪ੠") in title or l1l1l1_l1_ (u"ࠫฬ๊อๅไ๊ࠫ੡") in title: addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ੢"),menu_name+title,l111ll_l1_,353,img)
			#else: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੣"),menu_name+title,l111ll_l1_,352,img)
	else:
		img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ੤"))
		if html.count(l1l1l1_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠩ੥"))>1: title = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ੦"),html,re.DOTALL)[1]
		else: title = l1l1l1_l1_ (u"ࠪีฬฮืࠡษ็ฮูเ๊ๅࠩ੧")
		addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ੨"),menu_name+title,url,353,img)
	return
def PLAY(url):
	l11l1_l1_,l1111ll_l1_ = [],[]
	l111111_l1_ = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ੩"),url,l1l1l1_l1_ (u"࠭ࠧ੪"),l1l1l1_l1_ (u"ࠧࠨ੫"),l1l1l1_l1_ (u"ࠨࠩ੬"),l1l1l1_l1_ (u"ࠩࠪ੭"),l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ੮"))
	html = l111111_l1_.content
	l1l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬ੯"),html,re.DOTALL)
	if l1l11l1l_l1_:
		l1l11l1l_l1_ = l1l11l1l_l1_[0]
		headers = {l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩੰ"):l1l1l1_l1_ (u"࠭ࠧੱ"),l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ੲ"):l1l1l1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧੳ")}
		data = {l1l1l1_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪੴ"):l1l11l1l_l1_}
		url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡣࡩࡰࡦࡳ࠸࡬࡭࡮࠳ࡎࡴࡣ࠰ࡃ࡭ࡥࡽ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡗࡢࡶࡦ࡬࠳ࡶࡨࡱࠩੵ")
		l1l1l1l1_l1_ = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ੶"),url2,data,headers,l1l1l1_l1_ (u"ࠬ࠭੷"),l1l1l1_l1_ (u"࠭ࠧ੸"),l1l1l1_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ੹"))
		l1l11l11_l1_ = l1l1l1l1_l1_.content
		items = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ੺"),l1l11l11_l1_,re.DOTALL)
		for l1l11lll_l1_,name in items:
			#data = {l1l1l1_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ੻"):l1l11l1l_l1_,l1l1l1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ੼"):l1l11lll_l1_}
			l111ll_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠮ࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡢࡨ࡯ࡥࡲ࠾࡫࡬࡭࠲ࡍࡳࡩ࠯ࡂ࡬ࡤࡼ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ੽")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠬࡅࡰࡰࡵࡷ࡭ࡩࡃࠧ੾")+l1l11l1l_l1_+l1l1l1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ੿")+l1l11lll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ઀")+name+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩઁ")
			l11l1_l1_.append(l111ll_l1_)
			l1111ll_l1_.append(name)
		url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡢࡨ࡯ࡥࡲ࠾࡫࡬࡭࠲ࡍࡳࡩ࠯ࡂ࡬ࡤࡼ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴ࡊ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡪࡳࠫં")
		l1l1l1l1_l1_ = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡔࡔ࡙ࡔࠨઃ"),url2,data,headers,l1l1l1_l1_ (u"ࠫࠬ઄"),l1l1l1_l1_ (u"ࠬ࠭અ"),l1l1l1_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪઆ"))
		l1l11l11_l1_ = l1l1l1l1_l1_.content
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧઇ"),l1l11l11_l1_,re.DOTALL)
		for l111ll_l1_,title in items:
			#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩઈ"),l1l1l1_l1_ (u"ࠩࠪઉ"),l111ll_l1_,title)
			l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪࠤࠬઊ"))
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬઋ")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩઌ")
			l11l1_l1_.append(l111ll_l1_)
			l1111ll_l1_.append(title)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬઍ"),url)
	return
def l1111l1_l1_(url,filter):
	#filter = filter.replace(l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ઎"),l1l1l1_l1_ (u"ࠨࠩએ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪઐ"),l1l1l1_l1_ (u"ࠪࠫઑ"),filter,url)
	l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠫࡨࡧࡴࠨ઒"),l1l1l1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫઓ"),l1l1l1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬઔ"),l1l1l1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨક"),l1l1l1_l1_ (u"ࠨࡱࡵࡨࡪࡸࡢࡺࠩખ")]
	if l1l1l1_l1_ (u"ࠩࡂࠫગ") in url: url = url.split(l1l1l1_l1_ (u"ࠪࡃࠬઘ"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨઙ"),1)
	if filter==l1l1l1_l1_ (u"ࠬ࠭ચ"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"࠭ࠧછ"),l1l1l1_l1_ (u"ࠧࠨજ")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠨࡡࡢࡣࠬઝ"))
	if type==l1l1l1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ઞ"):
		if l1l1lll1_l1_[0]+l1l1l1_l1_ (u"ࠪࡁࠬટ") not in l1l1ll11_l1_: category = l1l1lll1_l1_[0]
		for i in range(len(l1l1lll1_l1_[0:-1])):
			if l1l1lll1_l1_[i]+l1l1l1_l1_ (u"ࠫࡂ࠭ઠ") in l1l1ll11_l1_: category = l1l1lll1_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠧડ")+category+l1l1l1_l1_ (u"࠭࠽࠱ࠩઢ")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠩણ")+category+l1l1l1_l1_ (u"ࠨ࠿࠳ࠫત")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠩࠩࠫથ"))+l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧદ")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠫࠫ࠭ધ"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠬࡧ࡬࡭ࠩન"))
		url2 = url+l1l1l1_l1_ (u"࠭࠿ࠨ઩")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨપ"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪફ"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠩࠪબ"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠪࡥࡱࡲࠧભ"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠫࠬમ"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠬࡅࠧય")+l1l1l1ll_l1_
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ર"),menu_name+l1l1l1_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠩ઱"),url2,351,l1l1l1_l1_ (u"ࠨࠩલ"),l1l1l1_l1_ (u"ࠩ࠴ࠫળ"))
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ઴"),menu_name+l1l1l1_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫવ")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫશ"),url2,351,l1l1l1_l1_ (u"࠭ࠧષ"),l1l1l1_l1_ (u"ࠧ࠲ࠩસ"))
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭હ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ઺"),l1l1l1_l1_ (u"ࠪࠫ઻"),9999)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"઼ࠫࠬ"),headers,True,l1l1l1_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪઽ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡧࡱࡵࡱࠥ࡯ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭ા"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴ࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭િ"),block,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩી"),l1l1l1_l1_ (u"ࠩࠪુ"),l1l1l1_l1_ (u"ࠪࠫૂ"),str(l11111l_l1_))
	dict = {}
	for l1llllll_l1_,name,block in l11111l_l1_:
		#name = name.replace(l1l1l1_l1_ (u"ࠫ࠲࠳ࠧૃ"),l1l1l1_l1_ (u"ࠬ࠭ૄ"))
		items = re.findall(l1l1l1_l1_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡃ࠮࠮ࠫࡁࠬࡀࠬૅ"),block,re.DOTALL)
		if l1l1l1_l1_ (u"ࠧ࠾ࠩ૆") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬે"):
			if category!=l1llllll_l1_: continue
			elif len(items)<=1:
				if l1llllll_l1_==l1l1lll1_l1_[-1]: l11l11_l1_(url2)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩૈ")+l1ll1111_l1_)
				return
			else:
				if l1llllll_l1_==l1l1lll1_l1_[-1]: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪૉ"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ૊"),url2,351,l1l1l1_l1_ (u"ࠬ࠭ો"),l1l1l1_l1_ (u"࠭࠱ࠨૌ"))
				else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ્ࠧ"),menu_name+l1l1l1_l1_ (u"ࠨษ็ะ๊๐ูࠨ૎"),url2,355,l1l1l1_l1_ (u"ࠩࠪ૏"),l1l1l1_l1_ (u"ࠪࠫૐ"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ૑"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠧ૒")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽࠱ࠩ૓")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠩ૔")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿࠳ࠫ૕")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭૖")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ૗"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿ࠦࠧ૘")+name,url2,354,l1l1l1_l1_ (u"ࠬ࠭૙"),l1l1l1_l1_ (u"࠭ࠧ૚"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ૛"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			if option in l1l1ll_l1_: continue
			if l1l1l1_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ૜") not in value: value = option
			else: value = re.findall(l1l1l1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ૝"),value,re.DOTALL)[0]
			dict[l1llllll_l1_][value] = option
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠪࠪࠬ૞")+l1llllll_l1_+l1l1l1_l1_ (u"ࠫࡂ࠭૟")+option
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠬࠬࠧૠ")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽ࠨૡ")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫૢ")+l1ll1ll1_l1_
			title = option+l1l1l1_l1_ (u"ࠨࠢ࠽ࠤࠬૣ")#+dict[l1llllll_l1_][l1l1l1_l1_ (u"ࠩ࠳ࠫ૤")]
			title = option+l1l1l1_l1_ (u"ࠪࠤ࠿ࠦࠧ૥")+name
			if type==l1l1l1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ૦"): addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ૧"),menu_name+title,url,354,l1l1l1_l1_ (u"࠭ࠧ૨"),l1l1l1_l1_ (u"ࠧࠨ૩"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ૪"))
			elif type==l1l1l1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭૫") and l1l1lll1_l1_[-2]+l1l1l1_l1_ (u"ࠪࡁࠬ૬") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࠨ૭"))
				url3 = url+l1l1l1_l1_ (u"ࠬࡅࠧ૮")+l1l1l111_l1_
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭૯"),menu_name+title,url3,351,l1l1l1_l1_ (u"ࠧࠨ૰"),l1l1l1_l1_ (u"ࠨ࠳ࠪ૱"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ૲"),menu_name+title,url,355,l1l1l1_l1_ (u"ࠪࠫ૳"),l1l1l1_l1_ (u"ࠫࠬ૴"),l1lllll1_l1_)
	return
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭૵"),l1l1l1_l1_ (u"࠭ࠧ૶"),filters,l1l1l1_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠷࠱ࠨ૷"))
	# mode==l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ૸")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬૹ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠪࡥࡱࡲࠧૺ")					all filters (l1l11ll1_l1_ l1ll11ll_l1_ filter)
	#filters = filters.replace(l1l1l1_l1_ (u"ࠫࡂࠬࠧૻ"),l1l1l1_l1_ (u"ࠬࡃ࠰ࠧࠩૼ"))
	filters = filters.strip(l1l1l1_l1_ (u"࠭ࠦࠨ૽"))
	l1l1ll1l_l1_ = {}
	if l1l1l1_l1_ (u"ࠧ࠾ࠩ૾") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠨࠨࠪ૿"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠩࡀࠫ଀"))
			l1l1ll1l_l1_[var] = value
	l1llll1l_l1_ = l1l1l1_l1_ (u"ࠪࠫଁ")
	l1lll1ll_l1_ = [l1l1l1_l1_ (u"ࠫࡨࡧࡴࠨଂ"),l1l1l1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫଃ"),l1l1l1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ଄"),l1l1l1_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨଅ"),l1l1l1_l1_ (u"ࠨࡱࡵࡨࡪࡸࡢࡺࠩଆ")]
	for key in l1lll1ll_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠩ࠳ࠫଇ")
		#if l1l1l1_l1_ (u"ࠪࠩࠬଈ") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ଉ") and value!=l1l1l1_l1_ (u"ࠬ࠶ࠧଊ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"࠭ࠠࠬࠢࠪଋ")+value
		elif mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪଌ") and value!=l1l1l1_l1_ (u"ࠨ࠲ࠪ଍"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠩࠩࠫ଎")+key+l1l1l1_l1_ (u"ࠪࡁࠬଏ")+value
		elif mode==l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࠨଐ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠬࠬࠧ଑")+key+l1l1l1_l1_ (u"࠭࠽ࠨ଒")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠧࠡ࠭ࠣࠫଓ"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠨࠨࠪଔ"))
	#l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"ࠩࡀ࠴ࠬକ"),l1l1l1_l1_ (u"ࠪࡁࠬଖ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬଗ"),l1l1l1_l1_ (u"ࠬ࠭ଘ"),filters,l1l1l1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧଙ"))
	return l1llll1l_l1_
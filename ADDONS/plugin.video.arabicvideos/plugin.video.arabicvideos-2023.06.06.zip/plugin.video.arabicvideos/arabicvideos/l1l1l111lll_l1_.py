# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ㺍")
headers = {l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㺎"):l1l1l1_l1_ (u"࠭ࠧ㺏")}
menu_name = l1l1l1_l1_ (u"ࠧࡠࡏࡆࡑࡤ࠭㺐")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ㺑"),l1l1l1_l1_ (u"ࠩࡺࡻࡪ࠭㺒")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l11l11_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l11l1ll_l1_(url,text)
	elif mode==364: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ㺓")+text)
	elif mode==365: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ㺔")+text)
	elif mode==366: results = l1ll11_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ㺕"),l1l11l_l1_,l1l1l1_l1_ (u"࠭ࠧ㺖"),l1l1l1_l1_ (u"ࠧࠨ㺗"),False,l1l1l1_l1_ (u"ࠨࠩ㺘"),l1l1l1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㺙"))
	#hostname = response.headers[l1l1l1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㺚")]
	#hostname = hostname.strip(l1l1l1_l1_ (u"ࠫ࠴࠭㺛"))
	#l11l1l_l1_ = l1l11l_l1_
	#url = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ㺜")
	#url = l11l1l_l1_
	#response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ㺝"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨ㺞"),l1l1l1_l1_ (u"ࠨࠩ㺟"),l1l1l1_l1_ (u"ࠩࠪ㺠"),l1l1l1_l1_ (u"ࠪࠫ㺡"),l1l1l1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㺢"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㺣"),menu_name+l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้ำหࠥอไๆ๊ๅ฽ฺ๋ࠥๅไ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㺤"),l1l1l1_l1_ (u"ࠧࠨ㺥"),8)
	#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㺦"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㺧"),l1l1l1_l1_ (u"ࠪࠫ㺨"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㺩"),menu_name+l1l1l1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ㺪"),l1l11l_l1_,369,l1l1l1_l1_ (u"࠭ࠧ㺫"),l1l1l1_l1_ (u"ࠧࠨ㺬"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㺭"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㺮"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭㺯"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ㺰"),364)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺱"),menu_name+l1l1l1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ㺲"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ㺳"),365)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㺴"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㺵"),l1l1l1_l1_ (u"ࠪࠫ㺶"),9999)
	#headers2 = {l1l1l1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㺷"):hostname,l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㺸"):l1l1l1_l1_ (u"࠭ࠧ㺹")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l1l1_l1_ (u"ࠧ࡝࠱ࠪ㺺"),l1l1l1_l1_ (u"ࠨ࠱ࠪ㺻"))
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࡣࡣࡵࠬ࠳࠰࠿ࠪࡨ࡬ࡰࡹ࡫ࡲࠨ㺼"),html,re.DOTALL)
	#if l1ll1l1_l1_:
	#	block = l1ll1l1_l1_[0]
	#	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㺽"),block,re.DOTALL)
	#	for l111ll_l1_,title in items:
	#		if l1l1l1_l1_ (u"ࠫࠪࡪ࠹ࠦ࠺࠸ࠩࡩ࠾ࠥࡣ࠷ࠨࡨ࠽ࠫࡡ࠸ࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡧ࠿ࠥࡥ࠺ࠨࡥ࠾࠳ࠥࡥ࠺ࠨࡥࡩࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡣ࠼ࠫ㺾") in l111ll_l1_: continue
	#		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺿"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㻀")+menu_name+title,l111ll_l1_,366)
	#	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㻁"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㻂"),l1l1l1_l1_ (u"ࠩࠪ㻃"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ㻄"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬ㻅"),l1l1l1_l1_ (u"ࠬ࠭㻆"),l1l1l1_l1_ (u"࠭ࠧ㻇"),l1l1l1_l1_ (u"ࠧࠨ㻈"),l1l1l1_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ㻉"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡓࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡒࡵࡳࡩࡻࡣࡵ࡫ࡲࡲࡸࡒࡩࡴࡶࡅࡹࡹࡺ࡯࡯ࠤࠪ㻊"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㻋"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㻌") not in l111ll_l1_:
			#	server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ㻍"))
			#	l111ll_l1_ = l111ll_l1_.replace(server,l11l1l_l1_)
			if title==l1l1l1_l1_ (u"࠭ࠧ㻎"): continue
			if any(value in title.lower() for value in l1l1ll_l1_): continue
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㻏"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㻐")+menu_name+title,l111ll_l1_,366)
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㻑"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㻒"),l1l1l1_l1_ (u"ࠫࠬ㻓"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠧ㻔"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㻕"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㻖"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㻗")+menu_name+title,l111ll_l1_,366,img)
	return html
def l1ll11_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㻘"),l1l1l1_l1_ (u"ࠪࠫ㻙"),url,l1l1l1_l1_ (u"ࠫࠬ㻚"))
	#headers2 = {l1l1l1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㻛"):url,l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㻜"):l1l1l1_l1_ (u"ࠧࠨ㻝")}
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ㻞"),url,l1l1l1_l1_ (u"ࠩࠪ㻟"),l1l1l1_l1_ (u"ࠪࠫ㻠"),l1l1l1_l1_ (u"ࠫࠬ㻡"),l1l1l1_l1_ (u"ࠬ࠭㻢"),l1l1l1_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㻣"))
	html = response.content
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㻤"),menu_name+l1l1l1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ㻥"),url,364)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㻦"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭㻧"),url,365)
	if l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ㻨") in html:
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㻩"),menu_name+l1l1l1_l1_ (u"࠭วๅ็่๎ืฯࠧ㻪"),url,361,l1l1l1_l1_ (u"ࠧࠨ㻫"),l1l1l1_l1_ (u"ࠨࠩ㻬"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㻭"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ㻮"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㻯"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㻰"),menu_name+title,l111ll_l1_,361)
	return
def l11l11_l1_(l1l1l11l111_l1_,type=l1l1l1_l1_ (u"࠭ࠧ㻱")):
	if l1l1l1_l1_ (u"ࠧ࠻࠼ࠪ㻲") in l1l1l11l111_l1_:
		url3,url = l1l1l11l111_l1_.split(l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ㻳"))
		server = SERVER(url3,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭㻴"))
		url = server+url
	else: url,url3 = l1l1l11l111_l1_,l1l1l11l111_l1_
	#headers2 = {l1l1l1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㻵"):url3,l1l1l1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㻶"):l1l1l1_l1_ (u"ࠬ࠭㻷")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ㻸"),url,l1l1l1_l1_ (u"ࠧࠨ㻹"),l1l1l1_l1_ (u"ࠨࠩ㻺"),l1l1l1_l1_ (u"ࠩࠪ㻻"),l1l1l1_l1_ (u"ࠪࠫ㻼"),l1l1l1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ㻽"))
	html = response.content
	if type==l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㻾"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷ࠳࠭ࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠪ㻿"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ㼀"):
		l1ll1l1_l1_ = [html.replace(l1l1l1_l1_ (u"ࠨ࡞࡟࠳ࠬ㼁"),l1l1l1_l1_ (u"ࠩ࠲ࠫ㼂")).replace(l1l1l1_l1_ (u"ࠪࡠࡡࠨࠧ㼃"),l1l1l1_l1_ (u"ࠫࠧ࠭㼄"))]
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡍࡲࡪࡦ࠰࠱ࡒࡿࡣࡪ࡯ࡤࡔࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ㼅"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡇࡳ࡫ࡧࡍࡹ࡫࡭ࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ㼆"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			if any(value in title.lower() for value in l1l1ll_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l1l1_l1_ (u"ࠧๆึส๋ิฯࠠࠨ㼇"),l1l1l1_l1_ (u"ࠨࠩ㼈"))
			if l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ㼉") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㼊"),menu_name+title,l111ll_l1_,363,img)
			elif l1l1l1_l1_ (u"ࠫา๊โสࠩ㼋") in title:
				l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠰ำไใหࠣ࠯ࡡࡪࠫࠨ㼌"),title,re.DOTALL)
				if l1llll1_l1_: title = l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ㼍") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㼎"),menu_name+title,l111ll_l1_,363,img)
			else:
				addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㼏"),menu_name+title,l111ll_l1_,362,img)
		if type==l1l1l1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ㼐"):
			l1lllll111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡲࡵࡲࡦࡡࡥࡹࡹࡺ࡯࡯ࡡࡳࡥ࡬࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ㼑"),block,re.DOTALL)
			if l1lllll111l_l1_:
				count = l1lllll111l_l1_[0]
				l111ll_l1_ = url+l1l1l1_l1_ (u"ࠫ࠴ࡵࡦࡧࡵࡨࡸ࠴࠭㼒")+count
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㼓"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ㼔"),l111ll_l1_,361,l1l1l1_l1_ (u"ࠧࠨ㼕"),l1l1l1_l1_ (u"ࠨࠩ㼖"),l1l1l1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ㼗"))
		elif type==l1l1l1_l1_ (u"ࠪࠫ㼘"):
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㼙"),html,re.DOTALL)
			if l1ll1l1_l1_:
				block = l1ll1l1_l1_[0]
				items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㼚"),block,re.DOTALL)
				for l111ll_l1_,title in items:
					title = l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬ㼛")+unescapeHTML(title)
					addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㼜"),menu_name+title,l111ll_l1_,361)
	return
def l11l1ll_l1_(url,type=l1l1l1_l1_ (u"ࠨࠩ㼝")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭㼞"),url,l1l1l1_l1_ (u"ࠪࠫ㼟"),l1l1l1_l1_ (u"ࠫࠬ㼠"),l1l1l1_l1_ (u"ࠬ࠭㼡"),l1l1l1_l1_ (u"࠭ࠧ㼢"),l1l1l1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㼣"))
	html = response.content
	html = UNQUOTE(html)
	name = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭㼤"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l1l1_l1_ (u"ࠩ࠰ࠫ㼥"),l1l1l1_l1_ (u"ࠪࠤࠬ㼦")).strip(l1l1l1_l1_ (u"ࠫ࠴࠭㼧"))
	if l1l1l1_l1_ (u"๋่ࠬิ็ࠪ㼨") in name and type==l1l1l1_l1_ (u"࠭ࠧ㼩"):
		name = name.split(l1l1l1_l1_ (u"ࠧๆ๊ึ้ࠬ㼪"))[0]
		name = name.replace(l1l1l1_l1_ (u"ࠨ็ืห์ีษࠨ㼫"),l1l1l1_l1_ (u"ࠩࠪ㼬")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ㼭"))
	elif l1l1l1_l1_ (u"ࠫา๊โสࠩ㼮") in name:
		name = name.split(l1l1l1_l1_ (u"ࠬำไใหࠪ㼯"))[0]
		name = name.replace(l1l1l1_l1_ (u"࠭ๅีษ๊ำฮ࠭㼰"),l1l1l1_l1_ (u"ࠧࠨ㼱")).strip(l1l1l1_l1_ (u"ࠨࠢࠪ㼲"))
	else: name = name
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳ࠭㼳"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		if type==l1l1l1_l1_ (u"ࠪࠫ㼴"):
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㼵"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࠫ㼶") in title: continue
				if l1l1l1_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ㼷") in title: continue
				title = name+l1l1l1_l1_ (u"ࠧࠡ࠯ࠣࠫ㼸")+title
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㼹"),menu_name+title,l111ll_l1_,363,l1l1l1_l1_ (u"ࠩࠪ㼺"),l1l1l1_l1_ (u"ࠪࠫ㼻"),l1l1l1_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭㼼"))
		if len(menuItemsLIST)==0:
			l11ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠪࠫ࠭㼽"),block+l1l1l1_l1_ (u"࠭ࠦࠧࠩ㼾"),re.DOTALL)
			if l11ll_l1_: block = l11ll_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㼿"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪ㽀"))
				title = name+l1l1l1_l1_ (u"ࠩࠣ࠱ࠥ࠭㽁")+title
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㽂"),menu_name+title,l111ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l1l1_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㽃"),html,re.DOTALL)
		if title: title = title[0].replace(l1l1l1_l1_ (u"ࠬࠦ࠭ࠡ็ส๎ู๊ࠥๆษࠪ㽄"),l1l1l1_l1_ (u"࠭ࠧ㽅")).replace(l1l1l1_l1_ (u"ࠧๆึส๋ิฯࠠࠨ㽆"),l1l1l1_l1_ (u"ࠨࠩ㽇"))
		else: title = l1l1l1_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ㽈")
		addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㽉"),menu_name+title,url,362)
	return
def PLAY(url):
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ㽊"),url,l1l1l1_l1_ (u"ࠬ࠭㽋"),l1l1l1_l1_ (u"࠭ࠧ㽌"),l1l1l1_l1_ (u"ࠧࠨ㽍"),l1l1l1_l1_ (u"ࠨࠩ㽎"),l1l1l1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㽏"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀส่ฯ฻ๆ๋ใ࠿࠲࠯ࡅ࠼ࡢ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㽐"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1l1ll1_l1_ = [l1l1ll1_l1_[0][0],l1l1ll1_l1_[0][1]]
		if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡉࡲࡨࡥࡥࠤࠪ㽑"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㽒"),block,re.DOTALL)
		for l111ll_l1_,name in items:
			if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ㽓") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if name==l1l1l1_l1_ (u"ࠧิ์ิๅึࠦๅศ์ࠣื๏๋วࠨ㽔"): name = l1l1l1_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㽕")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㽖")+name+l1l1l1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ㽗")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯ࡳࡵ࠯࠰ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㽘"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㽙"),block,re.DOTALL)
		for l111ll_l1_,l11ll111_l1_ in items:
			if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ㽚") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ㽛"),l11ll111_l1_,re.DOTALL)
			if l11ll111_l1_: l11ll111_l1_ = l1l1l1_l1_ (u"ࠨࡡࡢࡣࡤ࠭㽜")+l11ll111_l1_[0]
			else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠩࠪ㽝")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡱࡾࡩࡩ࡮ࡣࠪ㽞")+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㽟")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ㽠"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㽡"),url)
	return
def SEARCH(search,hostname=l1l1l1_l1_ (u"ࠧࠨ㽢")):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠨࠩ㽣"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠩࠪ㽤"): return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬ㽥"),l1l1l1_l1_ (u"ࠫ࠰࠭㽦"))
	l11l1_l1_ = [l1l1l1_l1_ (u"ࠬ࠵ࠧ㽧"),l1l1l1_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡹࡥࡳ࡫ࡨࡷࠬ㽨"),l1l1l1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡡ࡯࡫ࡰࡩࠬ㽩"),l1l1l1_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡵࡸࠪ㽪"),l1l1l1_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ㽫")]
	l111l1l11_l1_ = [l1l1l1_l1_ (u"ࠪห้ษแๅษ่ࠫ㽬"),l1l1l1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ㽭"),l1l1l1_l1_ (u"ࠬอไศ่ํ้๏่ࠦࠡษ็็ึะ่็ࠩ㽮"),l1l1l1_l1_ (u"࠭วๅสิห๊าࠠหๆํๅื๐่็์ฬࠫ㽯"),l1l1l1_l1_ (u"ࠧ฻์ิࠤ๊ำฯะࠩ㽰")]
	if l111l_l1_:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆู็์อࡀࠧ㽱"), l111l1l11_l1_)
		if selection==-1: return
	else: selection = 4
	if hostname==l1l1l1_l1_ (u"ࠩࠪ㽲"):
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ㽳"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬ㽴"),l1l1l1_l1_ (u"ࠬ࠭㽵"),False,l1l1l1_l1_ (u"࠭ࠧ㽶"),l1l1l1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ㽷"))
		hostname = response.headers[l1l1l1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㽸")]
		hostname = hostname.strip(l1l1l1_l1_ (u"ࠩ࠲ࠫ㽹"))
	url2 = hostname+l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ㽺")+search+l11l1_l1_[selection]
	l11l11_l1_(url2)
	return
def l1111l1_l1_(l1l1l11l111_l1_,filter):
	if l1l1l1_l1_ (u"ࠫࡄࡅࠧ㽻") in l1l1l11l111_l1_: url = l1l1l11l111_l1_.split(l1l1l1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ㽼"))[0]
	else: url = l1l1l11l111_l1_
	#headers2 = {l1l1l1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㽽"):l1l1l11l111_l1_,l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㽾"):l1l1l1_l1_ (u"ࠨࠩ㽿")}
	filter = filter.replace(l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㾀"),l1l1l1_l1_ (u"ࠪࠫ㾁"))
	type,filter = filter.split(l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨ㾂"),1)
	if filter==l1l1l1_l1_ (u"ࠬ࠭㾃"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"࠭ࠧ㾄"),l1l1l1_l1_ (u"ࠧࠨ㾅")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠨࡡࡢࡣࠬ㾆"))
	if type==l1l1l1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭㾇"):
		if l1l1ll111_l1_[0]+l1l1l1_l1_ (u"ࠪࡁࡂ࠭㾈") not in l1l1ll11_l1_: category = l1l1ll111_l1_[0]
		for i in range(len(l1l1ll111_l1_[0:-1])):
			if l1l1ll111_l1_[i]+l1l1l1_l1_ (u"ࠫࡂࡃࠧ㾉") in l1l1ll11_l1_: category = l1l1ll111_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠦࠨ㾊")+category+l1l1l1_l1_ (u"࠭࠽࠾࠲ࠪ㾋")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪ㾌")+category+l1l1l1_l1_ (u"ࠨ࠿ࡀ࠴ࠬ㾍")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠩࠩࠪࠬ㾎"))+l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧ㾏")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠫࠫࠬࠧ㾐"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ㾑"))
		url2 = url+l1l1l1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ㾒")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ㾓"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ㾔"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠩࠪ㾕"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭㾖"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠫࠬ㾗"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ㾘")+l1l1l1ll_l1_
		l1111lll_l1_ = l1l111l1l_l1_(url2,l1l1l11l111_l1_)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾙"),menu_name+l1l1l1_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ㾚"),l1111lll_l1_,361,l1l1l1_l1_ (u"ࠨࠩ㾛"),l1l1l1_l1_ (u"ࠩࠪ㾜"),l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ㾝"))
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㾞"),menu_name+l1l1l1_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ㾟")+l1l111ll_l1_+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ㾠"),l1111lll_l1_,361,l1l1l1_l1_ (u"ࠧࠨ㾡"),l1l1l1_l1_ (u"ࠨࠩ㾢"),l1l1l1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ㾣"))
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㾤"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㾥"),l1l1l1_l1_ (u"ࠬ࠭㾦"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ㾧"),url,l1l1l1_l1_ (u"ࠧࠨ㾨"),l1l1l1_l1_ (u"ࠨࠩ㾩"),l1l1l1_l1_ (u"ࠩࠪ㾪"),l1l1l1_l1_ (u"ࠪࠫ㾫"),l1l1l1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㾬"))
	html = response.content
	html = html.replace(l1l1l1_l1_ (u"ࠬࡢ࡜ࠣࠩ㾭"),l1l1l1_l1_ (u"࠭ࠢࠨ㾮")).replace(l1l1l1_l1_ (u"ࠧ࡝࡞࠲ࠫ㾯"),l1l1l1_l1_ (u"ࠨ࠱ࠪ㾰"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡱࡾࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࡂࠬ㾱"),html,re.DOTALL)
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡸࡦࡾ࡯࡯ࡱࡰࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ㾲"),block+l1l1l1_l1_ (u"ࠫࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ㾳"),re.DOTALL)
	dict = {}
	for l1llllll_l1_,name,block in l11111l_l1_:
		name = escapeUNICODE(name)
		if l1l1l1_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ㾴") in l1llllll_l1_: continue
		items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ㾵"),block,re.DOTALL)
		if l1l1l1_l1_ (u"ࠧ࠾࠿ࠪ㾶") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ㾷"):
			if category!=l1llllll_l1_: continue
			elif len(items)<=1:
				if l1llllll_l1_==l1l1ll111_l1_[-1]: l11l11_l1_(url2)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ㾸")+l1ll1111_l1_)
				return
			else:
				l1111lll_l1_ = l1l111l1l_l1_(url2,l1l1l11l111_l1_)
				if l1llllll_l1_==l1l1ll111_l1_[-1]:
					addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㾹"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ㾺"),l1111lll_l1_,361,l1l1l1_l1_ (u"ࠬ࠭㾻"),l1l1l1_l1_ (u"࠭ࠧ㾼"),l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ㾽"))
				else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾾"),menu_name+l1l1l1_l1_ (u"ࠩส่ัฺ๋๊ࠩ㾿"),url2,364,l1l1l1_l1_ (u"ࠪࠫ㿀"),l1l1l1_l1_ (u"ࠫࠬ㿁"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭㿂"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"࠭ࠦࠧࠩ㿃")+l1llllll_l1_+l1l1l1_l1_ (u"ࠧ࠾࠿࠳ࠫ㿄")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠨࠨࠩࠫ㿅")+l1llllll_l1_+l1l1l1_l1_ (u"ࠩࡀࡁ࠵࠭㿆")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧ㿇")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㿈"),menu_name+name+l1l1l1_l1_ (u"ࠬࡀࠠศๆฯ้๏฿ࠧ㿉"),url2,365,l1l1l1_l1_ (u"࠭ࠧ㿊"),l1l1l1_l1_ (u"ࠧࠨ㿋"),l1ll1111_l1_+l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㿌"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l1l1_l1_ (u"ࠩࡵࠫ㿍") or value==l1l1l1_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ㿎"): continue
			if any(value in option.lower() for value in l1l1ll_l1_): continue
			if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㿏") in option: continue
			if l1l1l1_l1_ (u"ࠬอไไๆࠪ㿐") in option: continue
			if l1l1l1_l1_ (u"࠭࡮࠮ࡣࠪ㿑") in value: continue
			#if value in [l1l1l1_l1_ (u"ࠧࡳࠩ㿒"),l1l1l1_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ㿓"),l1l1l1_l1_ (u"ࠩࡷࡺ࠲ࡳࡡࠨ㿔")]: continue
			#if l1llllll_l1_==l1l1l1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ㿕"): option = value
			if option==l1l1l1_l1_ (u"ࠫࠬ㿖"): option = value
			l1l11111l_l1_ = option
			name1 = re.findall(l1l1l1_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ㿗"),option,re.DOTALL)
			if name1: l1l11111l_l1_ = name1[0]
			title2 = name+l1l1l1_l1_ (u"࠭࠺ࠡࠩ㿘")+l1l11111l_l1_
			dict[l1llllll_l1_][value] = title2
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪ㿙")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿ࡀࠫ㿚")+l1l11111l_l1_
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠩࠩࠪࠬ㿛")+l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡁࡂ࠭㿜")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨ㿝")+l1ll1ll1_l1_
			if type==l1l1l1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭㿞"):
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿟"),menu_name+title2,url,365,l1l1l1_l1_ (u"ࠧࠨ㿠"),l1l1l1_l1_ (u"ࠨࠩ㿡"),l1lllll1_l1_+l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㿢"))
			elif type==l1l1l1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ㿣") and l1l1ll111_l1_[-2]+l1l1l1_l1_ (u"ࠫࡂࡃࠧ㿤") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ㿥"))
				#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ㿦"),l1l1l1_l1_ (u"ࠧࠨ㿧"),l1l1l111_l1_,l1ll1ll1_l1_)
				url3 = url+l1l1l1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ㿨")+l1l1l111_l1_
				l1111lll_l1_ = l1l111l1l_l1_(url3,l1l1l11l111_l1_)
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㿩"),menu_name+title2,l1111lll_l1_,361,l1l1l1_l1_ (u"ࠪࠫ㿪"),l1l1l1_l1_ (u"ࠫࠬ㿫"),l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭㿬"))
			else: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿭"),menu_name+title2,url,364,l1l1l1_l1_ (u"ࠧࠨ㿮"),l1l1l1_l1_ (u"ࠨࠩ㿯"),l1lllll1_l1_)
	return
l1l1ll111_l1_ = [l1l1l1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ㿰"),l1l1l1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ㿱"),l1l1l1_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ㿲")]
l1l1l1l11_l1_ = [l1l1l1_l1_ (u"ࠬࡳࡰࡢࡣࠪ㿳"),l1l1l1_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ㿴"),l1l1l1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭㿵"),l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ㿶"),l1l1l1_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪ㿷"),l1l1l1_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ㿸"),l1l1l1_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ㿹"),l1l1l1_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ㿺")]
def l1l111l1l_l1_(url2,url3):
	if l1l1l1_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭㿻") in url2: url2 = url2.replace(l1l1l1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ㿼"),l1l1l1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࠩ㿽"))
	url2 = url2.replace(l1l1l1_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ㿾"),l1l1l1_l1_ (u"ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧ㿿"))
	url2 = url2.replace(l1l1l1_l1_ (u"ࠫࡂࡃࠧ䀀"),l1l1l1_l1_ (u"ࠬ࠵ࠧ䀁"))
	url2 = url2.replace(l1l1l1_l1_ (u"࠭ࠦࠧࠩ䀂"),l1l1l1_l1_ (u"ࠧ࠰ࠩ䀃"))
	return url2
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䀄"),l1l1l1_l1_ (u"ࠩࠪ䀅"),filters,l1l1l1_l1_ (u"ࠪࡍࡓࠦࠠࠡࠢࠪ䀆")+mode)
	# mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䀇")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䀈")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"࠭ࡡ࡭࡮ࠪ䀉")					all filters (l1l11ll1_l1_ l1ll11ll_l1_ filter)
	filters = filters.strip(l1l1l1_l1_ (u"ࠧࠧࠨࠪ䀊"))
	l1l1ll1l_l1_,l1llll1l_l1_ = {},l1l1l1_l1_ (u"ࠨࠩ䀋")
	if l1l1l1_l1_ (u"ࠩࡀࡁࠬ䀌") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠪࠪࠫ࠭䀍"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠫࡂࡃࠧ䀎"))
			l1l1ll1l_l1_[var] = value
	for key in l1l1l1l11_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠬ࠶ࠧ䀏")
		if l1l1l1_l1_ (u"࠭ࠥࠨ䀐") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䀑") and value!=l1l1l1_l1_ (u"ࠨ࠲ࠪ䀒"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠩࠣ࠯ࠥ࠭䀓")+value
		elif mode==l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䀔") and value!=l1l1l1_l1_ (u"ࠫ࠵࠭䀕"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠬࠬࠦࠨ䀖")+key+l1l1l1_l1_ (u"࠭࠽࠾ࠩ䀗")+value
		elif mode==l1l1l1_l1_ (u"ࠧࡢ࡮࡯ࠫ䀘"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠨࠨࠩࠫ䀙")+key+l1l1l1_l1_ (u"ࠩࡀࡁࠬ䀚")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠪࠤ࠰ࠦࠧ䀛"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠫࠫࠬࠧ䀜"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䀝"),l1l1l1_l1_ (u"࠭ࠧ䀞"),l1llll1l_l1_,l1l1l1_l1_ (u"ࠧࡐࡗࡗࠫ䀟"))
	return l1llll1l_l1_
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝ࠬ抬")
contentsDICT = {}
menuItemsLIST = []
l1l1llll1lll_l1_ = xbmc.getInfoLabel(l1l1l1_l1_ (u"࡙ࠧࡹࡴࡶࡨࡱ࠳ࡈࡵࡪ࡮ࡧ࡚ࡪࡸࡳࡪࡱࡱࠦ抭"))
kodi_version = re.findall(l1l1l1_l1_ (u"࠭ࠨ࡝ࡦ࡟ࡨࡡ࠴࡜ࡥࠫࠪ抮"),l1l1llll1lll_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11l1ll1l11l_l1_ = xbmcvfs.translatePath(l1l1l1_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ抯"))
	l1l1ll111111_l1_ = xbmcvfs.translatePath(l1l1l1_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ抰"))
	l11lll111l1l_l1_ = xbmcvfs.translatePath(l1l1l1_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭抱"))
	l11l111l1111_l1_ = xbmcvfs.translatePath(l1l1l1_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ抲"))
	loglevel = xbmc.LOGINFO
	l1ll11l111l1_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭抳"),l1l1l1_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ抴"),l1l1l1_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ抵"))
	ltr,rtl = l1l1l1_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨ抶"),l1l1l1_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩ抷")
	half_triangular_colon = l1l1l1_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ抸")
else:
	l11l1ll1l11l_l1_ = xbmc.translatePath(l1l1l1_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ抹"))
	l1l1ll111111_l1_ = xbmc.translatePath(l1l1l1_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ抺"))
	l11lll111l1l_l1_ = xbmc.translatePath(l1l1l1_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ抻"))
	l11l111l1111_l1_ = xbmc.translatePath(l1l1l1_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ押"))
	loglevel = xbmc.LOGNOTICE
	l1ll11l111l1_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ抽"),l1l1l1_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ抾"),l1l1l1_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠴࠺࠲ࡩࡨࠧ抿"))
	ltr,rtl = l1l1l1_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ拀").encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ拁")),l1l1l1_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭拂").encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ拃"))
	half_triangular_colon = l1l1l1_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ拄").encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭担"))
addon_handle = int(sys.argv[1])
addon_id = sys.argv[0].split(l1l1l1_l1_ (u"ࠩ࠲ࠫ拆"))[2]	# l11l11llll_l1_.l1l1ll111l_l1_.l11l1l1ll1l1_l1_
addon_name = addon_id.split(l1l1l1_l1_ (u"ࠪ࠲ࠬ拇"))[2]		# l11l1l1ll1l1_l1_
addon_path = sys.argv[2]				# ?mode=12&url=http://test.l1lll1l11_l1_
#l11llll1l1ll_l1_ = sys.argv[0]+addon_path		# l11l11llll_l1_://l11l11llll_l1_.l1l1ll111l_l1_.l11l1l1ll1l1_l1_/?mode=12&url=http://test.l1lll1l11_l1_
#addon_path = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡆࡰ࡮ࡧࡩࡷࡖࡡࡵࡪࠪ拈"))
addon_version = xbmc.getInfoLabel(l1l1l1_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬ拉")+addon_id+l1l1l1_l1_ (u"࠭ࠩࠨ拊"))
l1ll11lll111_l1_ = os.path.join(l11lll111l1l_l1_,l1l1l1_l1_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ拋"))
l1l1l11l1l1l_l1_ = os.path.join(l11lll111l1l_l1_,l1l1l1_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧ拌"))
l1ll1ll1111l_l1_ = [l1l1l1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ拍"),l1l1l1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫ拎"),l1l1l1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫ࠧ拏"),l1l1l1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧ拐"),l1l1l1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࠧ拑"),l1l1l1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࠫ拒")]
l1ll11l1111l_l1_ = l1ll1ll1111l_l1_+[l1l1l1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ拓"),l1l1l1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ拔"),l1l1l1_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ拕"),l1l1l1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡳ࡬ࡪࡴ࡯࡮ࡧࡱࡥࡱࡋࡍࡂࡆࠪ拖")]		# ,l1l1l1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱࡭ࡳࡹࡴࡢ࡮࡯ࡉࡒࡇࡄࠨ拗")
addoncachefolder = os.path.join(l11l111l1111_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡࡠࠩ拘")+addon_version+l1l1l1_l1_ (u"ࠧ࠯ࡦࡥࠫ拙"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠨ࡫ࡳࡸࡻ࠷ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ拚"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠩ࡬ࡴࡹࡼ࠲ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ招"))
l1ll111l111_l1_ = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠪࡱ࠸ࡻࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ拜"))
l1l1l1lllll_l1_ = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠫࡱࡧࡳࡵࡸ࡬ࡨࡪࡵࡳ࠯ࡦࡤࡸࠬ拝"))
#l11l1l1l111l_l1_ = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠬࡲࡡࡴࡶࡰࡩࡳࡻ࠮ࡥࡣࡷࠫ拞"))
favoritesfile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ拟"))
#dummyiptvfile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠧࡥࡷࡰࡱࡾ࡯ࡰࡵࡸ࠱ࡨࡦࡺࠧ拠"))
fulliptvfile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ拡"))
l1ll111l1l1_l1_ = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ拢"))
l1ll111111l_l1_ = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡪࡡࡵࠩ拣"))
dialogimagefile = os.path.join(addoncachefolder,l1l1l1_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧ拤"))
addonfolder = xbmcaddon.Addon().getAddonInfo(l1l1l1_l1_ (u"ࠬࡶࡡࡵࡪࠪ拥"))
defaulticon = os.path.join(addonfolder,l1l1l1_l1_ (u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ拦"))
defaultthumb = os.path.join(addonfolder,l1l1l1_l1_ (u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪ拧"))
defaultfanart = os.path.join(addonfolder,l1l1l1_l1_ (u"ࠨࡨࡤࡲࡦࡸࡴ࠯࡬ࡳ࡫ࠬ拨"))
l1l1lllll1l1_l1_ = os.path.join(addonfolder,l1l1l1_l1_ (u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩ择"))
l11l1l1111l1_l1_ = os.path.join(addonfolder,l1l1l1_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ拪"),l1l1l1_l1_ (u"ࠫࡺࡹࡥࡳࡣࡪࡩࡳࡺࡳ࠯ࡶࡻࡸࠬ拫"))
l1l1l1ll1l11_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ括"))
l1l1l1l1l1l1_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ拭"),l1l1l1_l1_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ拮"),addon_id,l1l1l1_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ拯"))
l11lll1ll1ll_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ拰"),l1l1l1_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ拱"),l1l1l1_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ拲"))
fontfile = os.path.join(l11l1ll1l11l_l1_,l1l1l1_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࠫ拳"),l1l1l1_l1_ (u"࠭ࡆࡰࡰࡷࡷࠬ拴"),l1l1l1_l1_ (u"ࠧࡢࡴ࡬ࡥࡱ࠴ࡴࡵࡨࠪ拵"))
FOLDERS_COUNT = 5
text_numbers = [l1l1l1_l1_ (u"ࠨล๋่ࠬ拶"),l1l1l1_l1_ (u"ࠩฮห๋๐ࠧ拷"),l1l1l1_l1_ (u"ࠪฯฬ๊หࠨ拸"),l1l1l1_l1_ (u"ࠫึอศฺࠩ拹"),l1l1l1_l1_ (u"ࠬิวๆีࠪ拺"),l1l1l1_l1_ (u"࠭ำศัึࠫ拻"),l1l1l1_l1_ (u"ࠧิษห฽ࠬ拼"),l1l1l1_l1_ (u"ࠨอส้๋࠭拽"),l1l1l1_l1_ (u"ࠩอหุ฿ࠧ拾"),l1l1l1_l1_ (u"ࠪ฽ฬฺัࠨ拿")]
l1l1l11l1111_l1_ = l1l1l1_l1_ (u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬ挀")
settings = xbmcaddon.Addon(id=addon_id)
now = int(time.time())
l11lllll11l1_l1_ = 60
HOUR = 60*l11lllll11l1_l1_
l111l1l11111_l1_ = 24*HOUR
l11ll11ll111_l1_ = 30*l111l1l11111_l1_
NO_CACHE = 0
l1l1111lll1_l1_ = 30*l11lllll11l1_l1_
l1llll111_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
l11l11l_l1_ = 3*l111l1l11111_l1_
l1lll1l1lll_l1_ = 30*l111l1l11111_l1_
PERMANENT_CACHE = 12*l11ll11ll111_l1_
LIMITED_CACHE = 1*HOUR
l111ll1l1l1l_l1_ = [l1l1l1_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ持"),l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ挂")]
l11l1l1l1l11_l1_ = [l1l1l1_l1_ (u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭挃")]
l11l1ll1l111_l1_ = [l1l1l1_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ挄"),l1l1l1_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬ挅"),l1l1l1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧ挆"),l1l1l1_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ指"),l1l1l1_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ挈"),l1l1l1_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭按"),l1l1l1_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ挊")]
l11l1ll1l111_l1_ += [l1l1l1_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ挋"),l1l1l1_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ挌"),l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ挍"),l1l1l1_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ挎"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ挏"),l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭挐"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ挑")]
l111l1l11ll1_l1_ = [l1l1l1_l1_ (u"ࠨࡋࡓࡘ࡛࠭挒"),l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ挓"),l1l1l1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ挔"),l1l1l1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ挕")]
l111l1l11ll1_l1_ += [l1l1l1_l1_ (u"ࠬࡓ࠳ࡖࠩ挖"),l1l1l1_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ挗"),l1l1l1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ挘"),l1l1l1_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ挙")]
l111l1l11ll1_l1_ += [l1l1l1_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ挚"),l1l1l1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ挛"),l1l1l1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ挜")]
l111l1l11ll1_l1_ += [l1l1l1_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ挝"),l1l1l1_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭挞"),l1l1l1_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭挟"),l1l1l1_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ挠")]		# l1l1l1_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ挡")
l111l1l11ll1_l1_ += [l1l1l1_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭挢"),l1l1l1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭挣"),l1l1l1_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ挤"),l1l1l1_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ挥"),l1l1l1_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ挦")]
#l111l1l11ll1_l1_ += [l1l1l1_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ挧"),l1l1l1_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨ挨"),l1l1l1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩ挩"),l1l1l1_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ挪")]
#l111l1l11ll1_l1_ += [l1l1l1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ挫"),l1l1l1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࠩ挬"),l1l1l1_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࠫ挭"),l1l1l1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࠫ挮")]
l1lll11l11l_l1_ = [l1l1l1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ振"),l1l1l1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ挰"),l1l1l1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ挱"),l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ挲")]
l1lll11l11l_l1_ += [l1l1l1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ挳"),l1l1l1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ挴"),l1l1l1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ挵"),l1l1l1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ挶"),l1l1l1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ挷")]
l1lll1l11l1_l1_ = [l1l1l1_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ挸"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭挹"),l1l1l1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ挺"),l1l1l1_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ挻"),l1l1l1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ挼"),l1l1l1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ挽")]
l1lll1l11l1_l1_ += [l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ挾"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭挿"),l1l1l1_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ捀"),l1l1l1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭捁")]
#l1lll1l11l1_l1_ += [l1l1l1_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓࠫ捂"),l1l1l1_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ捃")]
l1llll1l11l_l1_ = [l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ捄"),l1l1l1_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ捅"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭捆"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ捇"),l1l1l1_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ捈"),l1l1l1_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭捉"),l1l1l1_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ捊"),l1l1l1_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ捋")]	# ,l1l1l1_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ捌")
l1llll1l11l_l1_ += [l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭捍"),l1l1l1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ捎"),l1l1l1_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭捏"),l1l1l1_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭捐"),l1l1l1_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ捑"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ捒"),l1l1l1_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ捓")]
#l1llll1l11l_l1_ += [l1l1l1_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭捔"),l1l1l1_l1_ (u"ࠬࡎࡅࡍࡃࡏࠫ捕"),l1l1l1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ捖"),l1l1l1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ捗"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ捘"),l1l1l1_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ捙"),l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ捚")]
l11l1111111l_l1_  = [l1l1l1_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ捛"),l1l1l1_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ捜"),l1l1l1_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ捝"),l1l1l1_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ捞"),l1l1l1_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ损"),l1l1l1_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ捠"),l1l1l1_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ捡"),l1l1l1_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭换")]
l11l1111111l_l1_ += [l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ捣"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ捤"),l1l1l1_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ捥"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ捦"),l1l1l1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ捧"),l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ捨"),l1l1l1_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ捩"),l1l1l1_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ捪"),l1l1l1_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ捫")]
l11l1111111l_l1_ += [l1l1l1_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ捬"),l1l1l1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ捭"),l1l1l1_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ据")]		# l1l1l1_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ捯"),l1l1l1_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ捰"),l1l1l1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ捱")
l11l1111111l_l1_ += [l1l1l1_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ捲"),l1l1l1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ捳"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ捴"),l1l1l1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ捵"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ捶"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭捷"),l1l1l1_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ捸")]
l11l1111111l_l1_ += [l1l1l1_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭捹"),l1l1l1_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭捺"),l1l1l1_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ捻"),l1l1l1_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ捼"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ捽"),l1l1l1_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ捾")]
l111ll11l1ll_l1_  = [l1l1l1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ捿"),l1l1l1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ掀"),l1l1l1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ掁"),l1l1l1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭掂")]
l111ll11l1ll_l1_ += [l1l1l1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ掃"),l1l1l1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ掄")]
l111ll11l1ll_l1_ += [l1l1l1_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬ掅"),l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ掆"),l1l1l1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ掇")]
l111ll11l1ll_l1_ += [l1l1l1_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ授"),l1l1l1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭掉"),l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ掊")]
l111ll11l1ll_l1_ += [l1l1l1_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬ掋"),l1l1l1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ掌"),l1l1l1_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ掍")]
#l111ll11l1ll_l1_ += [l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ掎"),l1l1l1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭掏")]
#l111ll11l1ll_l1_ += [l1l1l1_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࠬ掐"),l1l1l1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡌࡃࡗࡐࡗࠬ掑"),l1l1l1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘ࠭排")]
l111ll1lll1l_l1_ = [l1l1l1_l1_ (u"ࠫࡒ࠹ࡕࠨ掓"),l1l1l1_l1_ (u"ࠬࡏࡐࡕࡘࠪ掔"),l1l1l1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ掕"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭掖"),l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ掗")]		# l1l1l1_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ掘"),l1l1l1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭掙")
l1lll1ll1ll_l1_ = l11l1111111l_l1_+l111ll11l1ll_l1_
l1l111l1lll_l1_ = l11l1111111l_l1_+l111ll1lll1l_l1_
l1l11lllll1_l1_ = l11l1111111l_l1_+l111ll1lll1l_l1_+l111ll1l1l1l_l1_
l1lll1ll1l1_l1_ = l111l1l11ll1_l1_+l1lll1l11l1_l1_+l1llll1l11l_l1_+l1lll11l11l_l1_
NO_EXIT_LIST = [ l1l1l1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭掚")
				,l1l1l1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ掛")
				,l1l1l1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ掜")
				,l1l1l1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ掝")
				,l1l1l1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ掞")
				,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ掟")
				,l1l1l1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ掠")
				,l1l1l1_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭採")
				,l1l1l1_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ探")
				,l1l1l1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ掣")
				,l1l1l1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ掤")
				,l1l1l1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭接")
				,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ掦")
				,l1l1l1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ控")
				,l1l1l1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ推")
				,l1l1l1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ掩")
				,l1l1l1_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ措")
				,l1l1l1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ掫")
				,l1l1l1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ掬")
				,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ掭")
				,l1l1l1_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ掮")
				,l1l1l1_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ掯")
				,l1l1l1_l1_ (u"ࠬࡌࡏࡔࡖࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭掰")
				#,l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ掱")
				#,l1l1l1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ掲")
				#,l1l1l1_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ掳")
				#,l1l1l1_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ掴")
				#,l1l1l1_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ掵")
				#,l1l1l1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡇࡆࡖࡢࡐࡆ࡚ࡅࡔࡖࡢ࡚ࡊࡘࡓࡊࡑࡑࡣࡓ࡛ࡍࡃࡇࡕࡗ࠲࠷ࡳࡵࠩ掶")
				#,l1l1l1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ掷")
				#,l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ掸")
				#,l1l1l1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ掹")
				]
# l11l1l1ll11l_l1_ will not show l11ll111l1ll_l1_ errors
UNIMPORTANT_REQUESTS = [
						l1l1l1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭掺")
						,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭掻")
						]
l1l1l1111111_l1_ = [l1l1l1_l1_ (u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ掼"),l1l1l1_l1_ (u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ掽"),l1l1l1_l1_ (u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭掾"),l1l1l1_l1_ (u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧ掿"),l1l1l1_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨ揀"),l1l1l1_l1_ (u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩ揁")]
WEBSITES = {
			#,l1l1l1_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ揂")	:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ揃")]
			#,l1l1l1_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭揄")	:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡰࡨࡸࠬ揅")]
			#,l1l1l1_l1_ (u"࠭ࡅࡈ࡛࠷ࡆࡊ࡙ࡔࠨ揆")	:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭揇")]
			#,l1l1l1_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ揈")	:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ揉")]
			#,l1l1l1_l1_ (u"ࠪࡌࡊࡒࡁࡍࠩ揊")		:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠺ࡨࡦ࡮ࡤࡰ࠳ࡳࡥࠨ揋")]
			#,l1l1l1_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ揌")	:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧࠪ揍"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠭揎")]
			#,l1l1l1_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ描")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡱࡹࡷ࠹ࡻ࠮ࡸࡵࠪ提")]
			#,l1l1l1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ揑"):[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴࠨ插")]
			#,l1l1l1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ揓")	:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠱ࡧࡴࡳࠧ揔")]
			 l1l1l1_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭揕")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡰࡨࡸࠬ揖")]
			,l1l1l1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ揗")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺࠧ揘")]
			,l1l1l1_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ揙")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ揚")]
			,l1l1l1_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ換")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮ࡩࡥࡹ࡯࡭ࡪ࠰ࡷࡺࠬ揜")]
			#,l1l1l1_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ揝")	:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࡷࡺ࠳࡯ࡲࠨ揞")]
			,l1l1l1_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ揟")		:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ揠")]
			,l1l1l1_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ握")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭揢")]
			,l1l1l1_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭揣")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧ揤")]
			,l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ揥")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ揦")]
			,l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭揧")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡥࡧࡪ࡯࠯ࡥࡲࡱࠬ揨")]
			,l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ揩")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥ࠲࡮ࡵࠧ揪")]
			,l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ揫")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭揬")]
			,l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭揭")	:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴ࠯ࡥࡲࡱࠬ揮")]
			,l1l1l1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ揯")	:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬ揰")]
			,l1l1l1_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭揱")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡳࡸࡺࡡ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ揲")]
			,l1l1l1_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ揳")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬ援")]
			,l1l1l1_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ揵")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦ࠸ࡣࡥ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ揶")]
			,l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ揷")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡦ࠲ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡷࡰࡴ࡮ࠫ揸")]
			,l1l1l1_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ揹")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࠳ࡹࡨࡰࡨ࡫ࡥ࠳ࡺࡶࠨ揺")]
			,l1l1l1_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ揻")		:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩ揼")]
			,l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭揽")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬ揾")]
			,l1l1l1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ揿")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡥࡷࡵࡺࡢ࠰ࡲࡲࡪ࠭搀")]
			,l1l1l1_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ搁")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ搂")]
			,l1l1l1_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭搃")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ搄")]
			,l1l1l1_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ搅")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡦ࠲ࡩࡸࡡ࡮ࡣࡶ࠻࠳ࡩ࡯࡮ࠩ搆")]
			,l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ搇")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠮ࡰࡲࡻ࠳ࡩ࡯࡮ࠩ搈")]
			,l1l1l1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ搉")	:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ搊"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡳࡣࡳ࡬ࡶࡲ࠮ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭搋")]
			#,l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ搌")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ損")]
			,l1l1l1_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ搎")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦࠩ搏")]
			#,l1l1l1_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ搐")		:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡨ࡫ࡾࡴ࡯ࡸ࠰࡯࡭ࡻ࡫ࠧ搑")]
			,l1l1l1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ搒")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭搓")]
			,l1l1l1_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ搔")	:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭搕")]
			,l1l1l1_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ搖")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡹ࡭ࡵ࠭搗")]
			,l1l1l1_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭搘")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡦࡰࡴࡻࡤࠨ搙")]
			,l1l1l1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ搚")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡹࡸ࠭搛")]
			,l1l1l1_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ搜")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ搝"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ搞"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ搟"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ搠"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭搡")]
			#,l1l1l1_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ搢")			:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱࡳࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳࠧ搣")]
			,l1l1l1_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ搤")	:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡧࡲࡣࡣ࡯ࡥ࠲ࡺࡶ࠯࡫ࡴࠫ搥")]
			,l1l1l1_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ搦")	:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ搧"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣ࡫ࡷ࠲ࡱࡿ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ搨")]
			,l1l1l1_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ搩")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡧࡦࡳࠧ搪")]
			#,l1l1l1_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ搫")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲࡿࡣࡪ࡯ࡤ࠲ࡨࡵࠧ搬")]
			,l1l1l1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ搭")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡴࡶࡤࡨࠫ搮")]
			,l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ搯")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩ搰")]
			#,l1l1l1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ搱")		:[l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ搲"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ搳"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ搴"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ搵"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ搶"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ搷"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ搸")]
			#,l1l1l1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ搹")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ携"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ搻"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ搼"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ搽"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ搾"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ搿"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭摀")]
			#,l1l1l1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ摁")		:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ摂"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ摃"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ摄"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭摅"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭摆"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ摇"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ摈")]
			#,l1l1l1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ摉")		:[l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ摊"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ摋"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ摌"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ摍"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ摎"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ摏"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭摐")]
			#,l1l1l1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ摑")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ摒"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭摓"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ摔"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ摕"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ摖"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ摗"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ摘")]
			,l1l1l1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭摙")		:[l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ摚"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ摛"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭摜"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ摝"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ摞"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ摟"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ摠")]
			#,l1l1l1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭摡")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱ࠩ摢"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ摣"),l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ摤"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ摥")]
			,l1l1l1_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ摦")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵࠧ摧"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ摨"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ摩"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ摪")]
			,l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ摫")		:[l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪࡨࡨ࠲࠺ࡵ࠯ࡥࡲࡱࠬ摬")]
			,l1l1l1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ摭")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭摮"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ摯"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ摰")]
			#,l1l1l1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ摱")	:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࠴ࡳࡩࡱࡲࡪࡵࡸ࡯࠯ࡱࡱࡰ࡮ࡴࡥࠨ摲")]    #	l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡴࡷࡵ࠮ࡤࡱࡰࠫ摳")
			,l1l1l1_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ摴")		:[l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩ摵")]
			,l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ摶")		:[l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰࠫ摷")]
			,l1l1l1_l1_ (u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪ摸")		:[l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡱ࡯ࡥ࡫ࠪ摹"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯ࠧ摺")]
			}
class dummy_object(): pass
class l111ll1lllll_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11llllll1ll_l1_ = -1
	def onClick(self,l11l1lll1ll1_l1_):
		if l11l1lll1ll1_l1_>=9010: self.l11llllll1ll_l1_ = l11l1lll1ll1_l1_-9010
		self.delete()
	def l11ll1lllll1_l1_(self,*args):
		#self.getControl(9001).l1ll1l1l111_l1_(header)
		#self.getControl(9009).l1l1l1111lll_l1_(text)
		#self.getControl(9010).l1ll1l1l111_l1_(button0)
		#self.getControl(9011).l1ll1l1l111_l1_(button1)
		#self.getControl(9012).l1ll1l1l111_l1_(button2)
		self.button0,self.button1,self.button2 = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1l1l1l1lll1_l1_ = args[5],args[6]
		self.image_width,self.l111l11lllll_l1_,self.l111ll1111l1_l1_ = args[7],args[8],args[9]
		if self.l111l11lllll_l1_>0 or self.l111ll1111l1_l1_>0: self.enable_progressbar = True
		else: self.enable_progressbar = False
		self.image_filename,self.image_height = CREATE_IMAGE(self.button0,self.button1,self.button2,self.header,self.text,self.profile,self.l1l1l1l1lll1_l1_,self.image_width,self.enable_progressbar)
		self.show()
		self.getControl(9050).setImage(self.image_filename)
		self.getControl(9050).setHeight(self.image_height)
		if not self.button1 and self.button0 and self.button2: self.getControl(9012).setPosition(-220,0)
		return self.image_filename,self.image_height
	def l11lllll1lll_l1_(self):
		if self.l111l11lllll_l1_:
			import threading
			self.l111llll11ll_l1_ = threading.Thread(target=self.l11l111ll11l_l1_,args=())
			self.l111llll11ll_l1_.start()
			#self.l111llll11ll_l1_.join()
		else: self.enableButtons()
	def l11l111ll11l_l1_(self):
		self.getControl(9020).setEnabled(True)
		for ii in range(1,self.l111l11lllll_l1_+1):
			time.sleep(1)
			l111l1l111ll_l1_ = int(100*ii/self.l111l11lllll_l1_)
			self.l11l1l111111_l1_(l111l1l111ll_l1_)
			if self.l11llllll1ll_l1_>0: break
		self.enableButtons()
	def l11llll1l1l1_l1_(self):
		if self.l111ll1111l1_l1_:
			import threading
			self.l111llll1l11_l1_ = threading.Thread(target=self.l11l1l1lll1l_l1_,args=())
			self.l111llll1l11_l1_.start()
			#self.l111llll1l11_l1_.join()
		else: self.enableButtons()
	def l11l1l1lll1l_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l111l11lllll_l1_)
		for ii in range(self.l111ll1111l1_l1_-1,-1,-1):
			time.sleep(1)
			l111l1l111ll_l1_ = int(100*ii/self.l111ll1111l1_l1_)
			self.l11l1l111111_l1_(l111l1l111ll_l1_)
			if self.l11llllll1ll_l1_>0: break
		if self.l111ll1111l1_l1_>0: self.l11llllll1ll_l1_ = 10
		self.delete()
	def l11l1l111111_l1_(self,l111l1l111ll_l1_):
		self.l11l1l1l1lll_l1_ = l111l1l111ll_l1_
		self.getControl(9020).setPercent(self.l11l1l1l1lll_l1_)
	def enableButtons(self):
		if self.button0!=l1l1l1_l1_ (u"ࠬ࠭摻"): self.getControl(9010).setEnabled(True)
		if self.button1!=l1l1l1_l1_ (u"࠭ࠧ摼"): self.getControl(9011).setEnabled(True)
		if self.button2!=l1l1l1_l1_ (u"ࠧࠨ摽"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.image_filename)
		except: pass
		#del self
	l1l1l1_l1_ (u"ࠣࠤࠥࠑࠏࠏࡤࡦࡨࠣࡹࡵࡪࡡࡵࡧࠫࡷࡪࡲࡦ࠭ࡲࡨࡶࡨ࡫࡮ࡵ࠮࠭ࡥࡷ࡭ࡳࠪ࠼ࠐࠎࠎࠏࡴࡦࡺࡷࠤࡂࠦࡡࡳࡩࡶ࡟࠵ࡣࠍࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡥࡷ࡭ࡳࠪࡀ࠴࠾ࠥࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࡦࡸࡧࡴ࡝࠴ࡡࠒࠐࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡣࡵ࡫ࡸ࠯࠾࠳࠼ࠣࡸࡪࡾࡴࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࡤࡶ࡬ࡹ࡛࠳࡟ࠐࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡵ࡫ࡲࡤࡧࡱࡸ࠱ࡹࡥ࡭ࡨ࠱ࡸࡪࡾࡴࠡ࠿ࠣࡴࡪࡸࡣࡦࡰࡷ࠰ࡹ࡫ࡸࡵࠏࠍࠍࠎࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠰ࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡪࡨ࡭࡬࡮ࡴࠡ࠿ࠣࡷࡪࡲࡦ࠯ࡥࡵࡩࡦࡺࡥࡔࡪࡲࡻࡎࡳࡡࡨࡧࠫࡷࡪࡲࡦ࠯ࡤࡸࡸࡹࡵ࡮࠱࠮ࡶࡩࡱ࡬࠮ࡣࡷࡷࡸࡴࡴ࠱࠭ࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳ࠸ࠬࡴࡧ࡯ࡪ࠳࡮ࡥࡢࡦࡨࡶ࠱ࡹࡥ࡭ࡨ࠱ࡸࡪࡾࡴ࠭ࡵࡨࡰ࡫࠴ࡰࡳࡱࡩ࡭ࡱ࡫ࠬࡴࡧ࡯ࡪ࠳ࡪࡩࡳࡧࡦࡸ࡮ࡵ࡮࠭ࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤࡽࡩࡥࡶ࡫࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯ࡵࡷ࡭ࡲ࡫࡯ࡶࡶ࠯ࡷࡪࡲࡦ࠯ࡥ࡯ࡳࡸ࡫ࡴࡪ࡯ࡨࡳࡺࡺࠩࠎࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡸࡴࡩࡧࡴࡦࡒࡵࡳ࡬ࡸࡥࡴࡵࡅࡥࡷ࠮ࡰࡦࡴࡦࡩࡳࡺࠩࠎࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠯ࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡩࡧ࡬࡫࡭ࡺࠍࠋࠋࠥࠦࠧ摾")
class l11l1lll11l1_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l1l1l1_l1_ (u"ࠩࠪ摿")
	def onPlayBackStopped(self):
		self.status=l1l1l1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ撀")
	def onPlayBackStarted(self):
		if l1l1ll11ll11_l1_(l1l1l1_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ撁")):
			self.stop()
			self.status=l1l1l1_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ撂")
		else: self.status=l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ撃")
		time.sleep(1)
	def onPlayBackError(self):
		self.status=l1l1l1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ撄")
	def onPlayBackEnded(self):
		self.status=l1l1l1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ撅")
class l11l1l1111l_l1_():
	def __init__(self,showDialogs=False,l111lllllll1_l1_=True):
		self.showDialogs = showDialogs
		self.l111lllllll1_l1_ = l111lllllll1_l1_
		self.l11lll111ll1_l1_,self.l1l111111l1l_l1_ = [],[]
		self.l11l1lll1lll_l1_,self.l11l1ll1llll_l1_ = {},{}
		self.l11ll11lllll_l1_ = []
		self.l111l1ll1l1l_l1_,self.l11l1l1l11ll_l1_,self.l11lllll11ll_l1_ = {},{},{}
	def l11ll1ll1l11_l1_(self,id,func,*args):
		id = str(id)
		self.l11l1lll1lll_l1_[id] = l1l1l1_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ撆")
		if self.showDialogs: DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠪࠫ撇"),id)
		# l1ll1l11111l_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1ll1l11111l_l1_ 2 & 3
		import threading
		l11llllllll1_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l11ll11lllll_l1_.append(l11llllllll1_l1_)
		#l11llllllll1_l1_.start()
		return l11llllllll1_l1_
	def start_new_thread(self,id,func,*args):
		l11llllllll1_l1_ = self.l11ll1ll1l11_l1_(id,func,*args)
		l11llllllll1_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l111l1ll1l1l_l1_[id] = time.time()
		#LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ撈"),l1l1l1_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡩࡥ࠼ࠣࠫ撉")+id)
		try:
			#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ撊"),l1l1l1_l1_ (u"ࠧࡆࡏࡄࡈ࠿ࡀࠠࠨ撋")+str(func))
			self.l11l1ll1llll_l1_[id] = func(*args)
			if l1l1l1_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩ撌") in str(func) and not self.l11l1ll1llll_l1_[id].succeeded:
				FORCED_EXIT(l1l1l1_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠࡵࡪࡵࡩࡦࡪࡥࡥࠢࡒࡔࡊࡔࡕࡓࡎࠣࡪࡦ࡯࡬ࠨ撍"))
			self.l11lll111ll1_l1_.append(id)
			self.l11l1lll1lll_l1_[id] = l1l1l1_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ撎")
			#LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ撏"),l1l1l1_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠠࡪࡦ࠽ࠤࠬ撐")+id)
		except Exception as err:
			#LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭撑"),l1l1l1_l1_ (u"ࠧࡵࡪࡵࡩࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡪࡦ࠽ࠤࠬ撒")+id)
			if self.l111lllllll1_l1_:
				errortrace = traceback.format_exc()
				sys.stderr.write(errortrace)
				#traceback.print_exc(file=sys.stderr)
			self.l1l111111l1l_l1_.append(id)
			self.l11l1lll1lll_l1_[id] = l1l1l1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ撓")
		self.l11l1l1l11ll_l1_[id] = time.time()
		self.l11lllll11ll_l1_[id] = self.l11l1l1l11ll_l1_[id] - self.l111l1ll1l1l_l1_[id]
	def l111llllll1l_l1_(self):
		for proc in self.l11ll11lllll_l1_:
			proc.start()
	def l111l1l1l111_l1_(self):
		while l1l1l1_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ撔") in list(self.l11l1lll1lll_l1_.values()): time.sleep(1.000)
def l11l11111l11_l1_():
	l111lll1l11l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ撕"))
	if l111lll1l11l_l1_==addon_version:
		status = l1l1l1_l1_ (u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧ撖")
	elif not os.path.exists(addoncachefolder):
		status = l1l1l1_l1_ (u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ撗")
		os.makedirs(addoncachefolder)
	elif os.path.exists(main_dbfile):
		status = l1l1l1_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭撘")
	else:
		status = l1l1l1_l1_ (u"ࠧࡇࡗࡏࡐࡤ࡛ࡐࡅࡃࡗࡉࠬ撙")
		l11lll1ll11l_l1_ = [l1l1l1_l1_ (u"ࠨ࠺࠱࠹࠳࠶ࠧ撚"),l1l1l1_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠲࠱࠵࠾࠭撛"),l1l1l1_l1_ (u"ࠪ࠶࠵࠸࠱࠯࠳࠴࠲࠷࠺ࡡࠨ撜"),l1l1l1_l1_ (u"ࠫ࠷࠶࠲࠲࠰࠴࠶࠳࠹࠰ࠨ撝"),l1l1l1_l1_ (u"ࠬ࠸࠰࠳࠴࠱࠴࠷࠴࠰࠳ࠩ撞"),l1l1l1_l1_ (u"࠭࠲࠱࠴࠵࠲࠶࠶࠮࠳࠴ࠪ撟"),l1l1l1_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠶࠳࠯࠲࠹ࠫ撠"),l1l1l1_l1_ (u"ࠨ࠴࠳࠶࠸࠴࠰࠶࠰࠴࠺ࠬ撡"),l1l1l1_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠱࠸࠱࠴࠻࠭撢")]
		l11l1l11111l_l1_ = l11lll1ll11l_l1_[-1]
		l11ll111lll1_l1_ = l111l1l111l1_l1_(l11l1l11111l_l1_)
		l11l11l1ll1l_l1_ = l111l1l111l1_l1_(addon_version)
		if l11l11l1ll1l_l1_>l11ll111lll1_l1_:
			files = os.listdir(addoncachefolder)
			files = sorted(files,reverse=True)
			for filename in files:
				if l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡࡠࠩ撣") in filename and l1l1l1_l1_ (u"ࠫ࠳ࡪࡢࠨ撤") in filename:
					l11l1l11lll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣࡢࠬ࠳࠰࠿ࠪ࡞࠱ࡨࡧ࠭撥"),filename,re.DOTALL)
					l11l1l11lll1_l1_ = l11l1l11lll1_l1_[0]
					l11lll1111l1_l1_ = l111l1l111l1_l1_(l11l1l11lll1_l1_)
					if l1l1l1_l1_ (u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡࡠࠩ撦") in filename:
						if l11lll1111l1_l1_>=l11ll111lll1_l1_:
							l11llll11l11_l1_ = os.path.join(addoncachefolder,filename)
							try:
								if l11llll11l11_l1_!=main_dbfile: os.rename(l11llll11l11_l1_,main_dbfile)
								status = l1l1l1_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ撧")
								break
							except: pass
	return status
def l11l1ll11l11_l1_():
	script_name = l1l1l1_l1_ (u"ࠨࡏࡄࡍࡓࡓࡅࡏࡗࠪ撨")
	succeeded,updateListing,cacheToDisc = True,False,False
	menuItem = EXTRACT_KODI_PATH(addon_path)
	type,l11lll11llll_l1_,l11l111lll1l_l1_,mode,l111ll111lll_l1_,l11l1l11ll1l_l1_,text,context,infodict = menuItem
	l111ll1l1111_l1_ = type,l11lll11llll_l1_,l11l111lll1l_l1_,mode,l111ll111lll_l1_,l11l1l11ll1l_l1_,text,l1l1l1_l1_ (u"ࠩࠪ撩"),infodict
	l111lllll111_l1_ = int(mode)
	l11ll1l1lll1_l1_ = int(l111lllll111_l1_%10)
	l1l11ll111l_l1_ = int(l111lllll111_l1_/10)
	#l1l1l1llll_l1_ = l1l1l1l1l1_l1_()
	l111111l1l1_l1_ = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ撪"))
	l111111l1l1_l1_ = l111111l1l1_l1_.replace(ltr,l1l1l1_l1_ (u"ࠫࠬ撫")).replace(rtl,l1l1l1_l1_ (u"ࠬ࠭撬"))
	if l111lllll111_l1_==260: message = l1l1l1_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ播")+addon_version+l1l1l1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ撮")+l1l1llll1lll_l1_+l1l1l1_l1_ (u"ࠨࠢࡠࠫ撯")
	else:
		l11lllll1111_l1_ = UNQUOTE(addon_path).replace(l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ撰"),l1l1l1_l1_ (u"ࠪࠫ撱")).replace(l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ撲"),l1l1l1_l1_ (u"ࠬ࠭撳"))
		l11lllll1111_l1_ = l11lllll1111_l1_.replace(l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ撴"),l1l1l1_l1_ (u"ࠧࠨ撵")).strip(l1l1l1_l1_ (u"ࠨࠢࠪ撶"))
		l11lllll1111_l1_ = l11lllll1111_l1_.replace(l1l1l1_l1_ (u"ࠩࠣࠤࠥࠦࠧ撷"),l1l1l1_l1_ (u"ࠪࠤࠬ撸")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠠࠨ撹"),l1l1l1_l1_ (u"ࠬࠦࠧ撺")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ撻"),l1l1l1_l1_ (u"ࠧࠡࠩ撼"))
		message = l1l1l1_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ撽")+l111111l1l1_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ撾")+mode+l1l1l1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ撿")+l11lllll1111_l1_+l1l1l1_l1_ (u"ࠫࠥࡣࠧ擀")
	LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ擁"),LOGGING(script_name)+message)
	#text = text.replace(l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ擂"),l1l1l1_l1_ (u"ࠧࠨ擃"))
	refresh = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ擄"))
	l1l1l1l1l11l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ擅"))
	l1l1l1llll_l1_ = RESTORE_PATH_NAME(l111111l1l1_l1_)
	l11lll11llll_l1_ = RESTORE_PATH_NAME(l11lll11llll_l1_)
	l11l1lll1l11_l1_ = [0,15,17,19,26,34,50,53]
	l11l1111l1l1_l1_ = [0,15,17,19,26,34,50,53]
	l11lllll1l1l_l1_ = l1l11ll111l_l1_ not in l11l1111l1l1_l1_
	IPTV = l1l11ll111l_l1_ in [23,28]
	l1ll111ll11_l1_ = l1l11ll111l_l1_ in [71,72]
	l11l11l11l11_l1_ = l111lllll111_l1_ in [265,270]
	l11l1l11l111_l1_ = (l11lllll1l1l_l1_ or IPTV) and not l11l11l11l11_l1_
	l11lllllllll_l1_ = refresh!=l1l1l1_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭擆") and (refresh!=l1l1l1_l1_ (u"ࠫࠬ擇") or context==l1l1l1_l1_ (u"ࠬ࠭擈"))
	l11ll1l1111l_l1_ = l1l1l1_l1_ (u"࠭ࡴࡺࡲࡨࡁࠬ擉") in refresh
	l1l1111l1l1_l1_ = l111lllll111_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l11ll1l1lll1_l1_==9 or l111lllll111_l1_ in [145,516,523]
	l11llll1ll11_l1_ = not l1l1111l1l1_l1_
	l11lll1111ll_l1_ = not SEARCH
	l11l11l1l1l1_l1_ = l1l1l1llll_l1_ in [l1l1l1_l1_ (u"ࠧࠨ擊"),l1l1l1_l1_ (u"ࠨ࠰࠱ࠫ擋")]
	l11ll111l1l1_l1_ = l11l11l1l1l1_l1_ or l11llll1ll11_l1_
	l11l1ll11lll_l1_ = l11l11l1l1l1_l1_ or l11lll1111ll_l1_ or l11ll1l1111l_l1_
	l111ll111111_l1_ = l111lllll111_l1_ not in [260,265,270,330,540]
	if l1l1l1l1l11l_l1_: l11ll1111lll_l1_ = SEARCH or l1l1111l1l1_l1_
	else: l11ll1111lll_l1_ = True
	l11ll11l1lll_l1_ = not l1ll111ll11_l1_ and not IPTV
	l11l1l1l1111_l1_ = l111ll111111_l1_ and l11ll111l1l1_l1_ and l11l1ll11lll_l1_ and l11ll1111lll_l1_ and l11ll11l1lll_l1_
	l11l1111l1ll_l1_ = l111ll111111_l1_ and l11ll1111lll_l1_ and l11ll11l1lll_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ擌"),l1l1l1_l1_ (u"ࠪࠫ操"),l1l1l1_l1_ (u"ࠫࠬ擎"),type+l1l1l1_l1_ (u"ࠬࠦࠠࠡࠩ擏")+refresh+l1l1l1_l1_ (u"࠭ࠠࠡࠢࠪ擐")+str(l11l1111l1ll_l1_))
	if 1 and l11lllllllll_l1_ and l11l1l1l1111_l1_:
		DirectoryItems_List = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ擑"),l1l1l1_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊ࠭擒"),l111ll1l1111_l1_)
		if DirectoryItems_List:
			#xbmcgui.Dialog().l111ll11l11l_l1_(l1l1l1_l1_ (u"ࠩࠪ擓"),l1l1l1_l1_ (u"ࠪࡶࡪࡧࡤࡪࡰࡪࠤࡨࡧࡣࡩࡧࠪ擔"),l1l1l1_l1_ (u"ࠫࠬ擕"),100,False)
			#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭擖"),l1l1l1_l1_ (u"࠭࠮ࠡࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠡࠢࠣࡖࡪࡧࡤࡪࡰࡪࠤࡨࡧࡣࡩࡧࡧࠤࡲ࡫࡮ࡶࠩ擗"))
			if 1 and l11ll1l1111l_l1_:
				#xbmcgui.Dialog().l111ll11l11l_l1_(l1l1l1_l1_ (u"ࠧࠨ擘"),l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡹࡪࡰࡪࠤ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ擙"),l1l1l1_l1_ (u"ࠩࠪ據"),100,False)
				l11llll1l111_l1_ = []
				import l1l1ll1llll_l1_,FAVORITES
				MENUS__LAST_VIDEOS_MENU = l1l1ll1llll_l1_.l1l1lll11l1_l1_
				FAVORITES_FILE_DICT = FAVORITES.GET_ALL_FAVORITES()
				l11l1llll111_l1_ = refresh
				l11lll111111_l1_,l11lll111lll_l1_,l1l1l11l111_l1_,l111llll11l1_l1_,l11lll1llll1_l1_,l11l1ll111l1_l1_,l11lll11l111_l1_,l11l1111llll_l1_,l11l1l1llll1_l1_ = EXTRACT_KODI_PATH(l11l1llll111_l1_)
				l11l11l1l11l_l1_ = l11lll111111_l1_,l11lll111lll_l1_,l1l1l11l111_l1_,l111llll11l1_l1_,l11lll1llll1_l1_,l11l1ll111l1_l1_,l11lll11l111_l1_,l1l1l1_l1_ (u"ࠪࠫ擛"),l11l1l1llll1_l1_
				#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ擜"),str(l11l11l1l11l_l1_))
				for list_item in DirectoryItems_List:
					l111lll1111l_l1_ = list_item[l1l1l1_l1_ (u"ࠬࡳࡥ࡯ࡷࡌࡸࡪࡳࠧ擝")]
					#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ擞"),str(l111lll1111l_l1_))
					if l111lll1111l_l1_==l11l11l1l11l_l1_ or list_item[l1l1l1_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ擟")] in [265,270]:
						list_item = GET_LIST_ITEM(l111lll1111l_l1_,MENUS__LAST_VIDEOS_MENU,FAVORITES_FILE_DICT)
						if list_item[l1l1l1_l1_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫ擠")]:
							#xbmcgui.Dialog().l111ll11l11l_l1_(l1l1l1_l1_ (u"ࠩࠪ擡"),l1l1l1_l1_ (u"ࠪࡹࡵࡪࡡࡵ࡫ࡱ࡫ࠥࡩ࡯࡯ࡶࡨࡼࡹ࠭擢"),l1l1l1_l1_ (u"ࠫࠬ擣"),100,False)
							l111lll1l1l1_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(FAVORITES_FILE_DICT,l111lll1111l_l1_,list_item[l1l1l1_l1_ (u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭擤")])
							#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ擥"),str(l111lll1l1l1_l1_))
							#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ擦"),str(list_item[l1l1l1_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ擧")]))
							list_item[l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ擨")] = l111lll1l1l1_l1_+list_item[l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ擩")]
					l11llll1l111_l1_.append(list_item)
				settings.setSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ擪"),l1l1l1_l1_ (u"ࠬ࠭擫"))
				if type==l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭擬"): WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࠬ擭"),l111ll1l1111_l1_,l11llll1l111_l1_,REGULAR_CACHE)
			else: l11llll1l111_l1_ = DirectoryItems_List
			if type==l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ擮") and l1l1l1llll_l1_!=l1l1l1_l1_ (u"ࠩ࠱࠲ࠬ擯") and l11l1l11l111_l1_: l11ll1111l11_l1_()
			addItems_succeeded = CREATE_KODI_MENU(l11llll1l111_l1_,succeeded,updateListing,cacheToDisc)
			#xbmcgui.Dialog().l111ll11l11l_l1_(l1l1l1_l1_ (u"ࠪࠫ擰"),l1l1l1_l1_ (u"ࠫࡨࡸࡥࡢࡶ࡬ࡲ࡬ࠦ࡭ࡦࡰࡸࠫ擱"),l1l1l1_l1_ (u"ࠬ࠭擲"),100,False)
			return
	#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ擳"),addon_path)
	#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ擴"),refresh)
	elif type==l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ擵") and refresh==l1l1l1_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ擶") and l11l1111l1ll_l1_:
		#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ擷"),l1l1l1_l1_ (u"ࠫ࠳ࠦࠠࠡࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࠦࠠࠡࡆࡨࡰࡪࡺࡩ࡯ࡩࠣࡳࡱࡪࠠࡤࡣࡦ࡬ࡪࡪࠠ࡮ࡧࡱࡹࠬ擸"))
		DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࠪ擹"),l111ll1l1111_l1_)
	#context = l1l1l1_l1_ (u"࠭ࠧ擺")
	if l1l1l1_l1_ (u"ࠧࡠࠩ擻") in context: l111ll11111l_l1_,context2 = context.split(l1l1l1_l1_ (u"ࠨࡡࠪ擼"),1)
	else: l111ll11111l_l1_,context2 = context,l1l1l1_l1_ (u"ࠩࠪ擽")
	if l111ll11111l_l1_ in [l1l1l1_l1_ (u"ࠪ࠵ࠬ擾"),l1l1l1_l1_ (u"ࠫ࠷࠭擿"),l1l1l1_l1_ (u"ࠬ࠹ࠧ攀"),l1l1l1_l1_ (u"࠭࠴ࠨ攁"),l1l1l1_l1_ (u"ࠧ࠶ࠩ攂")] and context2:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ攃") l1l1l111l1_l1_ l111ll11llll_l1_ l111l1lll11l_l1_ is no addon_handle l111l1l1l1l_l1_ to l11lll1l1ll1_l1_ for l11l1l11l11l_l1_ directory
		#l1l1l1_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩࠬ攄") l1l1l111l1_l1_ to open a l1lll1lll1_l1_ list l1lll1lll1l1_l1_ l111ll1l1l11_l1_ addon_path
		#xbmc.executebuiltin(l1l1l1_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ攅")+sys.argv[0]+addon_path.split(l1l1l1_l1_ (u"ࠫࠫࡩ࡯࡯ࡶࡨࡼࡹࡃࠧ攆"))[0]+l1l1l1_l1_ (u"ࠬࠬࡣࡰࡰࡷࡩࡽࡺ࠽࠱ࠩ攇")+l1l1l1_l1_ (u"ࠨࠩࠣ攈"))
		#xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭攉")+addon_id+l1l1l1_l1_ (u"ࠨ࠱ࡂࡸࡪࡾࡴ࠾ࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠬࠫ攊"))
		settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭攋"),addon_path)
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ攌"))
		return
	elif l111ll11111l_l1_==l1l1l1_l1_ (u"ࠫ࠻࠭攍"):
		if context2==l1l1l1_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ攎"): DIALOG_NOTIFICATION(l1l1l1_l1_ (u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭攏"),l1l1l1_l1_ (u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧ攐"))
		elif context2==l1l1l1_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠨ攑"): mode = 334
		results = l1l111lll11_l1_(type,l11lll11llll_l1_,l11l111lll1l_l1_,mode,l111ll111lll_l1_,l11l1l11ll1l_l1_,text,context,infodict)
		#settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭攒"),l1l1l1_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭攓"))
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ攔"))
		return
	elif context==l1l1l1_l1_ (u"ࠬ࠽ࠧ攕"):
		import l1111l1lll_l1_
		l1111l1lll_l1_.l1lll1l11ll_l1_()
		#settings.setSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ攖"),l1l1l1_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ攗"))
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ攘"))
		return
	elif context==l1l1l1_l1_ (u"ࠩ࠻ࠫ攙"):
		#settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ攚"),l1l1l1_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ攛"))
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ攜")+addon_id+l1l1l1_l1_ (u"࠭࠿࡮ࡱࡧࡩࡂ࠭攝")+str(mode)+l1l1l1_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷ࠯ࠧ攞"))
		return
	elif context==l1l1l1_l1_ (u"ࠨ࠻ࠪ攟"):
		# l11l111111l1_l1_ update the l111l1l1llll_l1_ l1lll1lll1_l1_
		#results = l1l111lll11_l1_(type,l11lll11llll_l1_,l11l111lll1l_l1_,mode,l111ll111lll_l1_,l11l1l11ll1l_l1_,text,context,infodict)
		# l11l111111l1_l1_ update the l11l11l11ll1_l1_ l1lll1lll1_l1_
		settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭攠"),l1l1l1_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭攡"))
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ攢"))
		return
	if settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ攣")) not in [l1l1l1_l1_ (u"࠭ࡁࡖࡖࡒࠫ攤"),l1l1l1_l1_ (u"ࠧࡔࡖࡒࡔࠬ攥"),l1l1l1_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ攦")]: settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ攧"),l1l1l1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ攨"))
	if not settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ攩")): settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ攪"),l1l1l1111111_l1_[0])
	l11ll1ll1l1l_l1_ = l11l11111l11_l1_()
	l11ll1111l1l_l1_ = l11ll1ll1l1l_l1_!=l1l1l1_l1_ (u"࠭ࡎࡐࡡࡘࡔࡉࡇࡔࡆࠩ攫")
	if l11ll1111l1l_l1_:
		#l111lll1l11l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ攬"))
		#if l111lll1l11l_l1_:
		#	settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ攭"),l1l1l1_l1_ (u"ࠩࠪ攮"))
		#	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ支"))
		#	return
		DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ攰"),l1l1l1_l1_ (u"ࠬ࠭攱"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ攲"),l1l1l1_l1_ (u"ࠧห็ࠣฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้࡜࡯ว็ํࠥอไฦืาหึࠦัใ็࠽ࡠࡳࡢ࡮ࠨ攳")+addon_version)
		#l1l1lll111l1_l1_([main_dbfile])
		if l11ll1ll1l1l_l1_==l1l1l1_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ攴"):
			LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ攵"),l1l1l1_l1_ (u"ࠪ࠲ࠥࠦࠠࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡓࡊࡏࡓࡐࡊࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ收")+addon_path+l1l1l1_l1_ (u"ࠫࠥࡣࠧ攷"))
			DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ攸"),l1l1l1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ改"))
			for folder in range(FOLDERS_COUNT):
				DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ攺"),l1l1l1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩ攻")+str(folder))
				DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ攼"),l1l1l1_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ攽")+str(folder))
		else:
			LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ放"),l1l1l1_l1_ (u"ࠬ࠴ࠠࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ政")+addon_path+l1l1l1_l1_ (u"࠭ࠠ࡞ࠩ敀"))
			DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ敁"),l1l1l1_l1_ (u"ࠨࠩ敂"),l1l1l1_l1_ (u"ࠩหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ敃"),l1l1l1_l1_ (u"ࠪฮ๊ࠦสฬสํฮࠥษ่ࠡฬะำ๏ัࠠศๆศูิอัࠡษ็ะิ๐ฯࠡๆหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฤ๊ࠣฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ࠱ࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ敄"))
			l1l1lll111l1_l1_()
			FIX_ALL_DATABASES(False)
			l11ll1lll1l1_l1_ = l1ll11l1lll_l1_(32)
			import l1lll11ll1ll_l1_
			l1lll11ll1ll_l1_.l1l1lllll11l_l1_()
			l1lll11ll1ll_l1_.l1ll11ll1lll_l1_()
			l1lll11ll1ll_l1_.l1ll1111ll11_l1_(l1l1l1_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ故"),False)
			l1lll11ll1ll_l1_.l1ll1111ll11_l1_(l1l1l1_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ敆"),False)
			l1lll11ll1ll_l1_.l1ll11ll11l1_l1_(False)
			l1lll11ll1ll_l1_.l1ll11l11ll1_l1_(False)
			l1lll11ll1ll_l1_.l1ll11ll1l11_l1_(l1l1l1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ敇"),l1l1l1_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࠧ效"),False)
			l1l1l1_l1_ (u"ࠣࠤࠥࠑࠏࠏࠉࠊࡶࡵࡽ࠿ࠓࠊࠊࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࡬ࡩ࡭ࡧ࠵ࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡻࡳࡦࡴࡩࡳࡱࡪࡥࡳ࠮ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ࠲ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ࠱࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠬࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧࠪࠏࠍࠍࠎࠏࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠴ࠣࡁࠥࡾࡢ࡮ࡥࡤࡨࡩࡵ࡮࠯ࡃࡧࡨࡴࡴࠨࡪࡦࡀࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ࠮ࠓࠊࠊࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠸࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡱ࡯ࡥ࡫ࡲࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡶࡻࡡ࡭࡫ࡷࡽ࠳ࡧࡳ࡬ࠩ࠯ࠫࡹࡸࡵࡦࠩࠬࠑࠏࠏࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠍࠋࠋࠌࠍࠧࠨࠢ敉")
			try:
				l11lll1l111l_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ敊"),l1l1l1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ敋"),l1l1l1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ敌"),l1l1l1_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ敍"))
				l11l1lll11ll_l1_ = xbmcaddon.Addon(id=l1l1l1_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ敎"))
				l11l1lll11ll_l1_.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡥࡺࡺ࡯ࡠࡲ࡬ࡧࡰ࠭敏"),l1l1l1_l1_ (u"ࠨࡨࡤࡰࡸ࡫ࠧ敐"))
			except: pass
			try:
				l11lll1l111l_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ救"),l1l1l1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ敒"),l1l1l1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ敓"),l1l1l1_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ敔"))
				l11l1lll11ll_l1_ = xbmcaddon.Addon(id=l1l1l1_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ敕"))
				l11l1lll11ll_l1_.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡺ࡮ࡪࡥࡰࡡࡴࡹࡦࡲࡩࡵࡻࠪ敖"),l1l1l1_l1_ (u"ࠨ࠵ࠪ敗"))
			except: pass
			try:
				l11lll1l111l_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ敘"),l1l1l1_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ教"),l1l1l1_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ敚"),l1l1l1_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ敛"))
				l11l1lll11ll_l1_ = xbmcaddon.Addon(id=l1l1l1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭敜"))
				l11l1lll11ll_l1_.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡗ࡙ࡘࡅࡂࡏࡖࡉࡑࡋࡃࡕࡋࡒࡒࠬ敝"),l1l1l1_l1_ (u"ࠨ࠴ࠪ敞"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ敟"),l1l1l1_l1_ (u"ࠪࠫ敠"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ敡"),l1l1l1_l1_ (u"ࠬหะศࠢๆ๊ฯࠦสิฬัำ๊ࠦฮะ็ฬࠤๅࡏࡐࡕࡘࠣห้๋่อ๊าอࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠠโี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฮ้่วว์สࠤอาไษ่่ࠢๆอสࠡโࡌࡔ࡙࡜ࠠอัํำฮ࠭敢"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1ll111lll1_l1_):
			#	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ散"),l1l1l1_l1_ (u"ࠧࠨ敤"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ敥"),l1l1l1_l1_ (u"ࠩศิฬࠦใ็ฬࠣฮุะฮะ็ࠣาิ๋ษࠡโࡐ࠷࡚ࠦวๅ็๋ะํีษࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦสๅไสส๏อࠠษฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠨ敦"))
			#	import l1ll111ll11_l1_
			#	l1ll111ll11_l1_.CREATE_STREAMS()
		settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭敧"),l1l1l1_l1_ (u"ࠫࠬ敨"))
		settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬ敩"),l1l1l1_l1_ (u"࠭ࠧ敪"))
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l1lllll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll111111l_l1_)
		settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ敫"),addon_version)
		return
	l11l1l1l1l1l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ敬"))
	if l11l1l1l1l1l_l1_==l1l1l1_l1_ (u"ࠩࠪ敭") or now-int(l11l1l1l1l1l_l1_)>REGULAR_CACHE:
		#l1l1lll111l1_l1_([main_dbfile,iptv1_dbfile,iptv2_dbfile])
		settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ敮"),l1l1l1_l1_ (u"ࠫࠬ敯"))
	l11l111l1l11_l1_ = 0
	l11ll1ll111l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡫ࡱࡪࡴࡹ࠮ࡱࡧࡵ࡭ࡴࡪࠧ数"))
	if len(l11ll1ll111l_l1_)==15:
		first,second,l1llll11l_l1_ = l11ll1ll111l_l1_[0:4],l11ll1ll111l_l1_[4:9],l11ll1ll111l_l1_[9:]
		first = int(first)^l1llll111_l1_
		second = int(second)^REGULAR_CACHE
		l1llll11l_l1_ = int(l1llll11l_l1_)^l11l11l_l1_
		if first==second==l1llll11l_l1_:
			l11l111l1l11_l1_ = first*60
			if l1l1ll11ll11_l1_(l1l1l1_l1_ (u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬ敱")): l11l111l1l11_l1_ = l11l111l1l11_l1_*2
	l11lll111l11_l1_ = l1l1l1_l1_ (u"ࠧ࠲࠸ࠪ敲")+settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ敳"))
	if l11lll111l11_l1_: l11lll111l11_l1_ = int(l11lll111l11_l1_)^l1lll1l1lll_l1_
	if (not l11lll111l11_l1_ or not l11l111l1l11_l1_ or now-int(l11lll111l11_l1_)<=0 or now-int(l11lll111l11_l1_)>l11l111l1l11_l1_):
		if not l1l1ll11ll11_l1_(l1l1l1_l1_ (u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪ整")):
			# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l11l11ll11l1_l1_.l1lll1l11_l1_/l111ll1l1lll_l1_/l11ll1l1l1ll_l1_
			# unescapeHTML(l1l1l1_l1_ (u"ࠪࠤࠫࠩࡸ࠳࠸࠶ࡆࡀࠦࠦࠤࡺ࠵࠻࠶ࡊ࠻ࠡࠨࠦࡼ࠷࠼࠲ࡂ࠽ࠣࠪࠨࡾ࠲࠷࠵ࡅ࠿ࠬ敵"))
			#l11l11l1l1ll_l1_ = l1l1l1_l1_ (u"ࠫ⹀ࠦ⼝ࠡࠢ⾍ࠤࠥ⸰ࠠ⸼ࠩ敶")
			#l11l1l1ll1ll_l1_ = l1l1l1_l1_ (u"ࠬ⹁ࠠ⼞ࠢࠣ⾏ࠥࠦ⸪ࠡ⸽ࠪ敷")
			l1ll11l1l111_l1_ = l1ll11ll1ll1_l1_()
			if l1ll11l1l111_l1_:
				LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭數"),l1l1l1_l1_ (u"ࠧ࠯ࠢࠣࠤࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ敹")+addon_path+l1l1l1_l1_ (u"ࠨࠢࡠࠫ敺"))
				id,l1l1llllllll_l1_,l1l1lll1l1l1_l1_,answer,l1l1l111llll_l1_,reason = l1ll11l1l111_l1_[0]
				l1l1ll1l1l11_l1_,l1ll1l111l1l_l1_ = answer.split(l1l1l1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ敻"))
				del l1ll11l1l111_l1_[0]
				l111lllll11l_l1_ = random.sample(l1ll11l1l111_l1_,1)
				id,l1l1llllllll_l1_,l1l1lll1l1l1_l1_,answer,l1l1l111llll_l1_,reason = l111lllll11l_l1_[0]
				l1l1lll1l1l1_l1_ = l1l1l1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤ࠿ࠦࠧ敼")+id+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭敽")+l1l1lll1l1l1_l1_
				button0,button1,l11ll11l1111_l1_ = answer,l1l1l111llll_l1_,reason
				l11ll1ll_l1_ = [button0,button1,l1l1l11l1111_l1_]
				choice = -9
				while choice<0:
					l11lll11l1ll_l1_ = random.sample(l11ll1ll_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠬ࠭敾"),l11lll11l1ll_l1_[0],l11lll11l1ll_l1_[1],l11lll11l1ll_l1_[2],l1l1ll1l1l11_l1_,l1l1lll1l1l1_l1_,5,60)
					if choice==10: break
					if choice>=0 and l11lll11l1ll_l1_[choice]==l11ll1ll_l1_[1]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"࠭ࠧ敿"),l1l1l1_l1_ (u"ࠧࠨ斀"),l1l1l1_l1_ (u"ࠨ฻๋ำฮ࠭斁"),l1l1l1_l1_ (u"ࠩࠪ斂"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭斃"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅฮ๋หอࠦฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ࠭斄")+l11ll11l1111_l1_,10)
						if choice>=0: choice = -9
					elif choice>=0 and l11lll11l1ll_l1_[choice]==l11ll1ll_l1_[2]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠬ࠭斅"),l1l1l1_l1_ (u"࠭ࠧ斆"),l1l1l11l1111_l1_,l1l1l1_l1_ (u"ࠧࠨ文"),l1l1ll1l1l11_l1_,l1l1lll1l1l1_l1_+l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ斈")+l11ll1ll_l1_[0]+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ斉"),30)
					if choice==-1: DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ斊"),l1l1l1_l1_ (u"ࠫࠬ斋"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ斌"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ะิ์ัࠦฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧ斍"))
				settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ斎"),str(now^l1lll1l1lll_l1_)[2:])
				WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ斏"),l1l1l1_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ斐"),1,PERMANENT_CACHE)
			else: WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭斑"),l1l1l1_l1_ (u"ࠫࡆ࡛ࡔࡉࠩ斒"),0,PERMANENT_CACHE)
		else:
			settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ斓"),str(now^l1lll1l1lll_l1_)[2:])
			WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ斔"),l1l1l1_l1_ (u"ࠧࡂࡗࡗࡌࠬ斕"),1,PERMANENT_CACHE)
	if l11ll1111l1l_l1_: l1lll11ll1ll_l1_.l1ll111ll11l_l1_(False)
	# l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ斖")	l11lll1l1ll1_l1_ file to read/write the l1l11l11ll1_l1_ l1lll1lll1_l1_ list
	# l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ斗")		no l11llllllll_l1_ l111ll11ll1l_l1_ to the l1l11l11ll1_l1_ l1lll1lll1_l1_ list
	l1l1l1_l1_ (u"ࠥࠦࠧࠓࠊࠊࡕࡌࡘࡊ࡙࡟ࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡌࡘࡊ࡙࡟ࡎࡑࡇࡉࡘࠦࡡ࡯ࡦࠣࡱࡴࡪࡥ࠲࠿ࡀ࠽ࠒࠐࠉࡐࡖࡋࡉࡗࡥࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡃࠠ࡮ࡱࡧࡩ࠵ࠦࡩ࡯ࠢ࡞࠵࠹࠻ࠬ࠶࠳࠹࠰࠺࠸࠳࡞ࠏࠍࠍࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡁ࡙ࠥࡉࡕࡇࡖࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡳࡷࠦࡏࡕࡊࡈࡖࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠑࠏࠏࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗࠥࡃࠠ࡮ࡱࡧࡩ࠷ࡃ࠽࠲࠸ࠣࡥࡳࡪࠠ࡮ࡱࡧࡩ࠵ࠧ࠽࠲࠸࠳ࠑࠏࠏ࡙ࡐࡗࡗ࡙ࡇࡋ࡟ࡎࡇࡑ࡙ࡘࠦ࠽ࠡ࡯ࡲࡨࡪ࠶ࠠࡪࡰࠣ࡟࠶࠺࠴࡞ࠏࠍࠍࠨࡴࡡ࡮ࡧࡢࠤࡂࠦࡃࡍࡇࡄࡒࡤࡓࡅࡏࡗࡢࡐࡆࡈࡅࡍࠪࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࡳࡧ࡭ࡦࡡࠣࡁࠥࡘࡅࡔࡖࡒࡖࡊࡥࡐࡂࡖࡋࡣࡓࡇࡍࡆࠪࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࡗࡋࡍࡆࡏࡅࡉࡗࡥࡒࡆࡕࡘࡐ࡙࡙࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙ࠠࡰࡴࠣࡖࡆࡔࡄࡐࡏࡢࡑࡔࡊࡅࡔࠢࡲࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࡥࡍࡆࡐࡘࡗࠒࠐࠉࡪࡨࠣࡖࡊࡓࡅࡎࡄࡈࡖࡤࡘࡅࡔࡗࡏࡘࡘࡥࡍࡐࡆࡈࡗ࠿ࠓࠊࠊࠋࠦ࡭࡫ࠦࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗ࠿ࠦࡣࡰࡰࡧ࠵ࠥࡃࠠࠩ࡯ࡨࡲࡺࡥ࡬ࡢࡤࡨࡰࠥ࡯࡮ࠡ࡝ࠪ࠲࠳࠭ࠬࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫࡢ࠯ࠍࠋࠋࠌࠧࡪࡲࡩࡧࠢࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓ࠻ࠢࡦࡳࡳࡪ࠱ࠡ࠿ࠣࠬࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠢ࠿ࡱࡥࡲ࡫࡟ࠪࠏࠍࠍࠎ࡯ࡦࠡࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠠࡪࡰࠣࡸࡪࡾࡴࠡࡣࡱࡨࠥࡳࡥ࡯ࡷࡢࡰࡦࡨࡥ࡭ࠣࡀࡲࡦࡳࡥࡠࠢࡤࡲࡩࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨ࡭ࡣࡶࡸࡲ࡫࡮ࡶࡨ࡬ࡰࡪ࠯࠺ࠎࠌࠌࠍࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠲ࠥࠦࠠࡓࡧࡤࡨ࡮ࡴࡧࠡ࡮ࡤࡷࡹࠦ࡭ࡦࡰࡸࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ࠭ࡤࡨࡩࡵ࡮ࡠࡲࡤࡸ࡭࠱ࠧࠡ࡟ࠪ࠭ࠒࠐࠉࠊࠋࡲࡰࡩࡌࡉࡍࡇࠣࡁࠥࡵࡰࡦࡰࠫࡰࡦࡹࡴ࡮ࡧࡱࡹ࡫࡯࡬ࡦ࠮ࠪࡶࡧ࠭ࠩ࠯ࡴࡨࡥࡩ࠮ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡱࡪࡆࡊࡎࡈ࠲ࡩ࡫ࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠒࠐࠉࠊࠋࡰࡩࡳࡻࡉࡵࡧࡰࡷࡑࡏࡓࡕ࡝࠽ࡡࠥࡃࠠࡆࡘࡄࡐ࠭࠭࡬ࡪࡵࡷࠫ࠱ࡵ࡬ࡥࡈࡌࡐࡊ࠯ࠍࠋࠋࠌࡩࡱࡹࡥ࠻ࠏࠍࠍࠎࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠳࡙ࠦࠠࠡࡵ࡭ࡹ࡯࡮ࡨࠢ࡯ࡥࡸࡺࠠ࡮ࡧࡱࡹࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ࠮ࡥࡩࡪ࡯࡯ࡡࡳࡥࡹ࡮ࠫࠨࠢࡠࠫ࠮ࠓࠊࠊࠋࠌࡶࡪࡹࡵ࡭ࡶࡶࠤࡂࠦࡍࡂࡋࡑࡣࡉࡏࡓࡑࡃࡗࡇࡍࡋࡒࠩࡶࡼࡴࡪ࠲࡮ࡢ࡯ࡨࡣ࠱ࡻࡲ࡭ࡡ࠯ࡱࡴࡪࡥ࠭࡫ࡰࡥ࡬࡫࡟࠭ࡲࡤ࡫ࡪࡥࠬࡵࡧࡻࡸ࠱ࡩ࡯࡯ࡶࡨࡼࡹ࠲ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠪࠏࠍࠍࠎࠏ࡮ࡦࡹࡉࡍࡑࡋࠠ࠾ࠢࡶࡸࡷ࠮࡭ࡦࡰࡸࡍࡹ࡫࡭ࡴࡎࡌࡗ࡙࠯ࠍࠋࠋࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡄ࠱࠹࠰࠼࠽࠿ࠦ࡮ࡦࡹࡉࡍࡑࡋࠠ࠾ࠢࡱࡩࡼࡌࡉࡍࡇ࠱ࡩࡳࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠑࠏࠏࠉࠊࡱࡳࡩࡳ࠮࡬ࡢࡵࡷࡱࡪࡴࡵࡧ࡫࡯ࡩ࠱࠭ࡷࡣࠩࠬ࠲ࡼࡸࡩࡵࡧࠫࡲࡪࡽࡆࡊࡎࡈ࠭ࠒࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡵࡸࡰࡹࡹࠠ࠾ࠢࡐࡅࡎࡔ࡟ࡅࡋࡖࡔࡆ࡚ࡃࡉࡇࡕࠬࡹࡿࡰࡦ࠮ࡱࡥࡲ࡫࡟࠭ࡷࡵࡰࡤ࠲࡭ࡰࡦࡨ࠰࡮ࡳࡡࡨࡧࡢ࠰ࡵࡧࡧࡦࡡ࠯ࡸࡪࡾࡴ࠭ࡥࡲࡲࡹ࡫ࡸࡵ࠮࡬ࡲ࡫ࡵࡤࡪࡥࡷ࠭ࠒࠐࠉࠣࠤࠥ斘")
	results = l1l111lll11_l1_(type,l11lll11llll_l1_,l11l111lll1l_l1_,mode,l111ll111lll_l1_,l11l1l11ll1l_l1_,text,context,infodict)
	# l11l1ll11ll_l1_ l11llll1lll1_l1_: succeeded,updateListing,cacheToDisc = True,False,True
	# updateListing = True => l1111l1111l_l1_ this list is l111lll1llll_l1_ and will exit to main l1lll1lll1_l1_
	# updateListing = False => l1111l1111l_l1_ this list is l11ll1l111ll_l1_ and will exit to l1l11l11ll1_l1_ l1lll1lll1_l1_
	# cacheToDisc = True => will cause the l111l1l11lll_l1_ status to l111l1l1l1ll_l1_ l111lllll1l1_l1_
	# cacheToDisc = False => will l111llll1l1l_l1_ the l111l1l11lll_l1_ status to l11ll11ll1ll_l1_ l11ll111ll11_l1_
	#succeeded,updateListing,cacheToDisc = True,False,True
	#if not l11lllll111l_l1_: cacheToDisc = False
	if l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭料") in text: updateListing = True
	if type==l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ斚"):
		if l1l1l1llll_l1_!=l1l1l1_l1_ (u"࠭࠮࠯ࠩ斛") and l11l1l11l111_l1_: l11ll1111l11_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡪࡰࡷࠫ斜"),l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ斝"),l1l1l1_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ斞")) or l111lllll111_l1_ not in l11l1lll1l11_l1_) and not l1l1ll11ll11_l1_(l1l1l1_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ斟")):
				import l1l1ll1llll_l1_
				DirectoryItems_List = GET_ALL_LIST_ITEMS(l1l1ll1llll_l1_.l1l1lll11l1_l1_)
				addItems_succeeded = CREATE_KODI_MENU(DirectoryItems_List,succeeded,updateListing,cacheToDisc)
				if 1 and l11l1111l1ll_l1_ and DirectoryItems_List:
					WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࠩ斠"),l111ll1l1111_l1_,DirectoryItems_List,REGULAR_CACHE)
				#elif 1 and not DirectoryItems_List:
				#	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࠪ斡"),l111ll1l1111_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l1l1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ斢")+addon_id+l1l1l1_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ斣"),xbmcgui.ListItem(l1l1l1_l1_ (u"ࠨๆา๎่ࠦๅีๅ็อ๋ࠥๆࠡฮ๊หื้ࠧ斤")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l1l1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ斥")+addon_id+l1l1l1_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ斦"),xbmcgui.ListItem(l1l1l1_l1_ (u"ࠫศ็สฮࠢ็ฮ็ืรࠡษ็ฮๆอี๋ๆࠪ斧")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,updateListing,cacheToDisc)
	return
def l1l111lll11_l1_(type,name,url,mode,image,page,text,context,infodict):
	l111lllll111_l1_ = int(mode)
	l1l11ll111l_l1_ = int(l111lllll111_l1_//10)
	if   l1l11ll111l_l1_==0:  import l1lll11ll1ll_l1_ 	; results = l1lll11ll1ll_l1_.MAIN(l111lllll111_l1_,text)
	elif l1l11ll111l_l1_==1:  import l11l111l_l1_ 		; results = l11l111l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==2:  import l1lll111ll1_l1_ 		; results = l1lll111ll1_l1_.MAIN(l111lllll111_l1_,url,page,text)
	elif l1l11ll111l_l1_==3:  import l1l1l111ll1_l1_ 		; results = l1l1l111ll1_l1_.MAIN(l111lllll111_l1_,url,page,text)
	elif l1l11ll111l_l1_==4:  import l1ll111l1_l1_ 	; results = l1ll111l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==5:  import l1l11ll11l1l_l1_ 	; results = l1l11ll11l1l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==6:  import l1ll1ll1l_l1_ 	; results = l1ll1ll1l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==7:  import l1l11ll_l1_ 		; results = l1l11ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==8:  import l1lll111lll_l1_ 	; results = l1lll111lll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==9:  import l1lll1llll_l1_		; results = l1lll1llll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==10: import l1ll11l1ll1_l1_ 		; results = l1ll11l1ll1_l1_.MAIN(l111lllll111_l1_,url)
	elif l1l11ll111l_l1_==11: import l1llll1111l1_l1_ 	; results = l1llll1111l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==12: import l11l1lll1l_l1_ 		; results = l11l1lll1l_l1_.MAIN(l111lllll111_l1_,url,page,text)
	elif l1l11ll111l_l1_==13: import l1ll111ll_l1_	; results = l1ll111ll_l1_.MAIN(l111lllll111_l1_,url,page,text)
	elif l1l11ll111l_l1_==14: import l11lll111l1_l1_ 		; results = l11lll111l1_l1_.MAIN(l111lllll111_l1_,url,text,type,page,name,image)
	elif l1l11ll111l_l1_==15: import l1lll11ll1ll_l1_ 	; results = l1lll11ll1ll_l1_.MAIN(l111lllll111_l1_,text)
	elif l1l11ll111l_l1_==16: import l1l1111l1l1_l1_	 	; results = l1l1111l1l1_l1_.MAIN(l111lllll111_l1_,url,text,page,infodict)
	elif l1l11ll111l_l1_==17: import l1lll11ll1ll_l1_ 	; results = l1lll11ll1ll_l1_.MAIN(l111lllll111_l1_,text)
	elif l1l11ll111l_l1_==18: import l1l1l1l1l1l_l1_	; results = l1l1l1l1l1l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==19: import l1lll11ll1ll_l1_ 	; results = l1lll11ll1ll_l1_.MAIN(l111lllll111_l1_,text)
	elif l1l11ll111l_l1_==20: import l11l1llll_l1_		; results = l11l1llll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==21: import l11l11l111l_l1_ ; results = l11l11l111l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==22: import l111l1llll_l1_ 	; results = l111l1llll_l1_.MAIN(l111lllll111_l1_,url,page,text)
	elif l1l11ll111l_l1_==23: import IPTV 		; results = IPTV.MAIN(l111lllll111_l1_,url,text,type,page,infodict)
	elif l1l11ll111l_l1_==24: import l11ll1l_l1_ 		; results = l11ll1l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==25: import l11lllll1_l1_ 	; results = l11lllll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==26: import l1l1ll1llll_l1_ 		; results = l1l1ll1llll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l111lllll111_l1_,context)
	elif l1l11ll111l_l1_==28: import IPTV 		; results = IPTV.MAIN(l111lllll111_l1_,url,text,type,page,infodict)
	elif l1l11ll111l_l1_==29: import l1l111111ll1_l1_	; results = l1l111111ll1_l1_.MAIN(l111lllll111_l1_,url,page,text)
	elif l1l11ll111l_l1_==30: import l1lll1l11l_l1_		; results = l1lll1l11l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==31: import l1l11lll11ll_l1_	; results = l1l11lll11ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==32: import l1ll1l1lll1_l1_	; results = l1ll1l1lll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==33: import l1l11ll11l_l1_		; results = l1l11ll11l_l1_.MAIN(l111lllll111_l1_,url)
	elif l1l11ll111l_l1_==34: import l1lll11ll1ll_l1_ 	; results = l1lll11ll1ll_l1_.MAIN(l111lllll111_l1_,text)
	elif l1l11ll111l_l1_==35: import l1l1llll_l1_		; results = l1l1llll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==36: import l1l1l111lll_l1_		; results = l1l1l111lll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==37: import l111ll1ll_l1_		; results = l111ll1ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==38: import l1l1l11l11l_l1_ 		; results = l1l1l11l11l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==39: import l1llllll1l1_l1_	; results = l1llllll1l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==40: import l1ll111l1l_l1_	; results = l1ll111l1l_l1_.MAIN(l111lllll111_l1_,url,text,type,page)
	elif l1l11ll111l_l1_==41: import l1ll111l1l_l1_	; results = l1ll111l1l_l1_.MAIN(l111lllll111_l1_,url,text,type,page)
	elif l1l11ll111l_l1_==42: import l111l111l_l1_		; results = l111l111l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==43: import l111l11l1l_l1_		; results = l111l11l1l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==44: import l111l11ll1_l1_		; results = l111l11ll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==45: import l1ll11l11ll_l1_		; results = l1ll11l11ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==46: import l111l1111l1_l1_		; results = l111l1111l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==47: import l1lll1l1l1_l1_	; results = l1lll1l1l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==48: import l1lll1l11ll1_l1_		; results = l1lll1l11ll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==49: import l1llll1lll_l1_		; results = l1llll1lll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==50: import l1lll11ll1ll_l1_ 	; results = l1lll11ll1ll_l1_.MAIN(l111lllll111_l1_,text)
	elif l1l11ll111l_l1_==51: import l1111l1ll1_l1_ 	; results = l1111l1ll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==52: import l1111l1ll1_l1_ 	; results = l1111l1ll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==53: import l1l1ll1llll_l1_ 		; results = l1l1ll1llll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==54: import l1111l1lll_l1_	; results = l1111l1lll_l1_.MAIN(l111lllll111_l1_,url,text,page)
	elif l1l11ll111l_l1_==55: import l1lllll1ll_l1_ 	; results = l1lllll1ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==56: import l1llll11l111_l1_		; results = l1llll11l111_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==57: import l1lllll1lll_l1_		; results = l1lllll1lll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==58: import l1l11llll111_l1_	; results = l1l11llll111_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==59: import l1lllll1111_l1_		; results = l1lllll1111_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==60: import l1llll1lll1_l1_		; results = l1llll1lll1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==61: import l1lll1l_l1_		; results = l1lll1l_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==62: import l1lllllll11_l1_		; results = l1lllllll11_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==63: import l1lllll111_l1_		; results = l1lllll111_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==64: import l1l11lll1111_l1_		; results = l1l11lll1111_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==65: import l111l11ll_l1_		; results = l111l11ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==66: import l1l11l1ll1ll_l1_		; results = l1l11l1ll1ll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==67: import l1ll1l1ll11_l1_		; results = l1ll1l1ll11_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==68: import l1l111llll_l1_		; results = l1l111llll_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==69: import l111l11l1_l1_		; results = l111l11l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==70: import l1ll11ll1l1_l1_		; results = l1ll11ll1l1_l1_.MAIN(l111lllll111_l1_,url,text)
	elif l1l11ll111l_l1_==71: import l1ll111ll11_l1_			; results = l1ll111ll11_l1_.MAIN(l111lllll111_l1_,url,text,type,page,infodict)
	elif l1l11ll111l_l1_==72: import l1ll111ll11_l1_			; results = l1ll111ll11_l1_.MAIN(l111lllll111_l1_,url,text,type,page,infodict)
	else: results = None
	return results
def l1l1l1l1l1_l1_(name=l1l1l1_l1_ (u"ࠬ࠭斨")):
	if not name: name = xbmc.getInfoLabel(l1l1l1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ斩"))
	name = name.replace(l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ斪"),l1l1l1_l1_ (u"ࠨࠩ斫"))
	name = name.replace(l1l1l1_l1_ (u"ࠩࠣࠤࠥࠦࠧ斬"),l1l1l1_l1_ (u"ࠪࠤࠬ断")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠠࠨ斮"),l1l1l1_l1_ (u"ࠬࠦࠧ斯")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ新"),l1l1l1_l1_ (u"ࠧࠡࠩ斱")).strip(l1l1l1_l1_ (u"ࠨࠢࠪ斲"))
	name = name.replace(l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ斳"),l1l1l1_l1_ (u"ࠪࠫ斴")).replace(l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ斵"),l1l1l1_l1_ (u"ࠬ࠭斶"))
	tmp = re.findall(l1l1l1_l1_ (u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢࠪ斷"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l1l1_l1_ (u"ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪ斸")
	return name
def SHOW_NETWORK_ERRORS(code,reason,source,showDialogs):
	if l1l1l1_l1_ (u"ࠨ࠯ࠪ方") in source: site = source.split(l1l1l1_l1_ (u"ࠩ࠰ࠫ斺"),1)[0]
	else: site = source
	l11lll1l1111_l1_ = code in [7,11001,11002,10054]
	l111l1l1l1l1_l1_ = reason.lower()
	l11l11lll1ll_l1_ = code in [0,104,10061,111]
	l11l11lll1l1_l1_ = l1l1l1_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ斻") in l111l1l1l1l1_l1_
	l11l11lll11l_l1_ = l1l1l1_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ於") in l111l1l1l1l1_l1_
	l11l11lll111_l1_ = l1l1l1_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ施") in l111l1l1l1l1_l1_
	l11l11ll1lll_l1_ = l1l1l1_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ斾") in l111l1l1l1l1_l1_
	proxy_status = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ斿"))
	dns_status = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ旀"))
	l11l1ll1ll1l_l1_ = l1l1l1_l1_ (u"ࠩไุ้ࠦศิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ旁")
	l11l11l111ll_l1_ = l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠪ旂")+str(code)+l1l1l1_l1_ (u"ࠫ࠿ࠦࠧ旃")+reason
	if l11l11lll1ll_l1_ or l11l11lll1l1_l1_ or l11l11lll11l_l1_ or l11l11lll111_l1_ or l11l11ll1lll_l1_:
		l11l1ll1ll1l_l1_ += l1l1l1_l1_ (u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬ旄")
	if l11lll1l1111_l1_: l11l1ll1ll1l_l1_ += l1l1l1_l1_ (u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭旅")
	l11l11l111ll_l1_ = l1l1l1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ旆")+l11l11l111ll_l1_+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ旇")
	if proxy_status==l1l1l1_l1_ (u"ࠩࡄࡗࡐ࠭旈") or dns_status==l1l1l1_l1_ (u"ࠪࡅࡘࡑࠧ旉"):
		l11l1ll1ll1l_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้็ࠤฯื๊ะࠢฦ๊ࠥ๐อศ๊็ࠤฬ๊ศา่ส้ัࠦลึๆสัࠥอไๆึๆ่ฮࠦระ่ส๋ࠥล࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ旊")
	trytofix = False
	if showDialogs:
		if proxy_status==l1l1l1_l1_ (u"ࠬࡇࡓࡌࠩ旋") or dns_status==l1l1l1_l1_ (u"࠭ࡁࡔࡍࠪ旌"):
			#if kodi_version<19: l11l11l111ll_l1_ = l11l11l111ll_l1_.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ旍"))
			trytofix = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ旎"),l1l1l1_l1_ (u"ࠩࠪ族"),l1l1l1_l1_ (u"ࠪࠫ旐"),site+l1l1l1_l1_ (u"ࠫࠥࠦࠠࠨ旑")+TRANSLATE(site),l11l1ll1ll1l_l1_,l11l11l111ll_l1_)
		else: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭旒"),l1l1l1_l1_ (u"࠭ࠧ旓"),site+l1l1l1_l1_ (u"ࠧࠡࠢࠣࠫ旔")+TRANSLATE(site),l11l1ll1ll1l_l1_,l11l11l111ll_l1_)
	if reason.endswith(l1l1l1_l1_ (u"ࠨࠢࠬࠫ旕")): reason = reason.rsplit(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ旖"))[0]
	#if trytofix: LOG_THIS(l1l1l1_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ旗"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠫࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ旘")+str(code)+l1l1l1_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ旙")+reason+l1l1l1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ旚")+source+l1l1l1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡇࡒࡂࡄࡌࡇ࠿࡛ࠦࠡࠩ旛")+l11l1ll1ll1l_l1_+l1l1l1_l1_ (u"ࠨࠢࡠࡡࠥࠦࠠࡆࡐࡊࡐࡎ࡙ࡈ࠻ࠢ࡞ࠤࠬ旜")+l11l11l111ll_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠬ旝"))
	return trytofix
	l1l1l1_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤࡩࡴࡳࠡࡱࡵࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠶ࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠵ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠴࠼ࠐࠎࠎࠏࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠠ࠾๊ࠢࠪํ฿ࠠๆ่ࠣห้ำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่࠴ࠧࠎࠌࠌࠍ࡮࡬ࠠࡴࡪࡲࡻࡉ࡯ࡡ࡭ࡱࡪࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠠࠬ࠿ࠣࠫࠥํไࠡฬิ๎ิࠦสโษุ๎้ࠦวไอิࠤฤ࠭ࠍࠋࠋࠌ࡭࡫ࠦࡤ࡯ࡵ࠽ࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠿้ࠣࠫี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤ࠰ࡃࠠࠨ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡨࡰࡸ࡫࠺ࠡ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠿ࠣࠫ์ึวࠡษ็้ํู่ࠡใํ๋ࠥ࠭ࠫࡣ࡮ࡲࡧࡰࡥ࡭ࡦࡧࡶࡷࡦ࡭ࡥࠎࠌࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ࠲ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧࠬࡵࡲࡹࡷࡩࡥࠬࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ࠮ࡷࡹࡸࠨࡤࡱࡧࡩ࠮࠱ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ࠮ࡶࡪࡧࡳࡰࡰ࠮ࠫࠥࡣࠠࠡࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠼ࠣ࡟ࠥ࠭ࠫ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠫࠨࠢࡠࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠻ࠢ࡞ࠤࠬ࠱࡭ࡦࡵࡶࡥ࡬࡫ࡅࡏࡉࡏࡍࡘࡎࠫࠨࠢࡠࠫ࠮ࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠑࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸࠧ࠭ࡵ࡬ࡸࡪ࠱ࠧࠡࠢࠣࠫ࠰࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅࠩࡵ࡬ࡸࡪ࠯ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࠉࡪࡨࠣࡽࡪࡹ࠽࠾࠳࠽ࠤ࡮ࡳࡰࡰࡴࡷࠤࡘࡋࡒࡗࡋࡆࡉࡘࠦ࠻ࠡࡕࡈࡖ࡛ࡏࡃࡆࡕ࠱ࡑࡆࡏࡎࠩ࠳࠼࠹࠮ࠓࠊࠊࡧ࡯࡭࡫ࠦࡳࡩࡱࡺࡈ࡮ࡧ࡬ࡰࡩࡶ࠾ࠒࠐࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠳ࠢࡀࠤࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠯ࠬࠦ࠮้ࠡ็ࠤฯื๊ะ่ࠢ฽ึ็ษࠡษ็วุฮวษ๋ࠢห้ำไ้ๆࠣรࠬࠓࠊࠊࠋࡼࡩࡸࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠ࡛ࡈࡗࡓࡕࠨࠨࡥࡨࡲࡹ࡫ࡲࠨ࠮ࡶ࡭ࡹ࡫ࠫࠨࠢࠣࠤࠬ࠱ࡔࡓࡃࡑࡗࡑࡇࡔࡆࠪࡶ࡭ࡹ࡫ࠩ࠭࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠳࠮ࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠯ࠫࠬ࠲ࠧไๆสࠫ࠱࠭ๆฺ็ࠪ࠭ࠒࠐࠉࠊ࡫ࡩࠤࡾ࡫ࡳ࠾࠿࠴࠾ࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣࡁࠥ࠭โะࠢํ็ํ์่่ࠠส็ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฾์ฯไࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦๅโื๋่ฮ࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้ืศุࠢสฺ่๊แาࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ื่ࠠา๊ࠤฬ๊ีโฯฬࠤํอไๆสิ้ัࠦไศࠢํ฽้๋ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳࡢ࡮ࠨ࠭ࠪะึฮࠠๆีะࠤฬ๊ใศึ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥาัษฺࠢี็ࠦัโ฻ࠣห้ำฬษ้ࠢࠫะ๊วࠡࡘࡓࡒࠥ࠲ࠠࡑࡴࡲࡼࡾࠦࠬࠡࡆࡑࡗ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠๆหࠤ์ึวࠡษ็้ํู่ࠡๆสั็อࠧࠎࠌࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤ࡚ࡅ࡙ࡖ࡙ࡍࡊ࡝ࡅࡓࠪࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ࠲࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠩࠎࠌࠌࠦࠧࠨ旞")
def l1l1lll111l1_l1_(l111ll111l11_l1_=False):
	l11l1lll111l_l1_ = [l1l1l1lllll_l1_,favoritesfile,l1ll111111l_l1_]
	for filename in os.listdir(addoncachefolder):
		if l111ll111l11_l1_ and (filename.startswith(l1l1l1_l1_ (u"ࠫ࡮ࡶࡴࡷࠩ旟")) or filename.startswith(l1l1l1_l1_ (u"ࠬࡳ࠳ࡶࠩ无"))): continue
		if filename.startswith(l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬ旡")): continue
		l1ll111l11l_l1_ = os.path.join(addoncachefolder,filename)
		if l1ll111l11l_l1_ in l11l1lll111l_l1_: continue
		try: os.remove(l1ll111l11l_l1_)
		except: pass
	time.sleep(1)
	return
def EXTRACT_KODI_PATH(kodipath=addon_path):
	l11ll1l11ll1_l1_ = {l1l1l1_l1_ (u"ࠧࡵࡻࡳࡩࠬ既"):l1l1l1_l1_ (u"ࠨࠩ旣"),l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ旤"):l1l1l1_l1_ (u"ࠪࠫ日"),l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ旦"):l1l1l1_l1_ (u"ࠬ࠭旧"),l1l1l1_l1_ (u"࠭ࡴࡦࡺࡷࠫ旨"):l1l1l1_l1_ (u"ࠧࠨ早"),l1l1l1_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭旪"):l1l1l1_l1_ (u"ࠩࠪ旫"),l1l1l1_l1_ (u"ࠪࡲࡦࡳࡥࠨ旬"):l1l1l1_l1_ (u"ࠫࠬ旭"),l1l1l1_l1_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ旮"):l1l1l1_l1_ (u"࠭ࠧ旯"),l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ旰"):l1l1l1_l1_ (u"ࠨࠩ旱"),l1l1l1_l1_ (u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ旲"):l1l1l1_l1_ (u"ࠪࠫ旳")}
	if l1l1l1_l1_ (u"ࠫࡄ࠭旴") in kodipath: kodipath = kodipath.split(l1l1l1_l1_ (u"ࠬࡅࠧ旵"),1)[1]
	url2,l11ll1l11l1l_l1_ = URLDECODE(kodipath)
	args = dict(list(l11ll1l11ll1_l1_.items())+list(l11ll1l11l1l_l1_.items()))
	l111lll1lll1_l1_ = args[l1l1l1_l1_ (u"࠭࡭ࡰࡦࡨࠫ时")]
	l11l111lll1l_l1_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ旷")])
	l11lll11lll1_l1_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠨࡶࡨࡼࡹ࠭旸")])
	l11l1l11ll1l_l1_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ旹")])
	type_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠪࡸࡾࡶࡥࠨ旺")])
	l11lll11llll_l1_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ旻")])
	l111ll111lll_l1_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ旼")])
	l11l1111l111_l1_ = args[l1l1l1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ旽")]
	l11l111ll111_l1_ = UNQUOTE(args[l1l1l1_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ旾")])
	if l11l111ll111_l1_: l11l111ll111_l1_ = eval(l11l111ll111_l1_)
	else: l11l111ll111_l1_ = {}
	#name = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ旿"))
	#image = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ昀"))
	if not l111lll1lll1_l1_: type_ = l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ昁") ; l111lll1lll1_l1_ = l1l1l1_l1_ (u"ࠫ࠷࠼࠰ࠨ昂")
	return type_,l11lll11llll_l1_,l11l111lll1l_l1_,l111lll1lll1_l1_,l111ll111lll_l1_,l11l1l11ll1l_l1_,l11lll11lll1_l1_,l11l1111l111_l1_,l11l111ll111_l1_
def l11l111lllll_l1_(proxy,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix=True,allow_proxy_fix=True):
	l111ll1lll11_l1_,l11l11l1111l_l1_ = proxy.split(l1l1l1_l1_ (u"ࠬࡀࠧ昃"))
	#DIALOG_NOTIFICATION(l1l1l1_l1_ (u"࠭ๅีๅ็อࠥหๆหำ้๎ฯࠦ࠮ࠡีฦัฬ๎ไࠡวุ่ฬำ็ศࠩ昄"),l1l1l1_l1_ (u"ࠧิลฯีอࠦࠧ昅")+name,time=2000)
	#LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ昆"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥ࠭昇")+name+l1l1l1_l1_ (u"ࠪࠤࡸ࡫ࡲࡷࡧࡵࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ昈")+proxy+l1l1l1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ昉")+url+l1l1l1_l1_ (u"ࠬࠦ࡝ࠨ昊"))
	url = url+l1l1l1_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭昋")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix,allow_proxy_fix)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ昌"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࠬ昍")+name+l1l1l1_l1_ (u"ࠩࠣࡷࡪࡸࡶࡦࡴࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ明")+proxy+l1l1l1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ昏")+url+l1l1l1_l1_ (u"ࠫࠥࡣࠧ昐"))
		FORCED_EXIT(l1l1l1_l1_ (u"ࠬࡎࡔࡕࡒࠣࡖࡪࡷࡵࡦࡵࡷࠤࡋࡧࡩ࡭ࡷࡵࡩࠬ昑"))
	#else: LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭昒"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ易")+proxy+l1l1l1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ昔")+url+l1l1l1_l1_ (u"ࠩࠣࡡࠬ昕"))
	return response
def l111ll111ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ昖"),url,l1l1l1_l1_ (u"ࠫࠬ昗"),l1l1l1_l1_ (u"ࠬ࠭昘"),True,False,l1l1l1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ昙"),True,False)
	l1l111111l11_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111ll1111ll_l1_
		l11l11111111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪ昚"),html)
		#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ昛"),str(l11l11111111_l1_))
		if l11l11111111_l1_: html = l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ昜").join(l11l11111111_l1_)
		proxies = html.replace(l1l1l1_l1_ (u"ࠪࡠࡷ࠭昝"),l1l1l1_l1_ (u"ࠫࠬ昞")).strip(l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ星")).split(l1l1l1_l1_ (u"࠭࡜࡯ࠩ映"))
		l1l111111l11_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l1l1_l1_ (u"ࠧ࠯ࠩ昡"))==3: l1l111111l11_l1_.append(proxy)
	return l1l111111l11_l1_
def OPENURL_REQUESTS_PROXIES(*args):
	#l11l1111l11l_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠶࠸࠲࠸࠹࠮࠲࠹࠱࠵࠷࠽࠯ࡢࡲ࡬࠳ࡵࡸ࡯ࡹࡻࡂࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡳࡱࡧࡨࡨࡂ࠷࠰ࠧ࡮ࡤࡷࡹࡥࡣࡩࡧࡦ࡯ࡂ࠷࠰ࠧࡪࡷࡸࡵࡹ࠽ࡵࡴࡸࡩࠫࡶ࡯ࡴࡶࡀࡸࡷࡻࡥࠧࡨࡲࡶࡲࡧࡴ࠾ࡶࡻࡸࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬ昢")
	l11lllll1l11_l1_ = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ昣")
	l11l11lllll1_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ昤")
	#l11ll111l11l_l1_ = l111ll111ll1_l1_(l11l1111l11l_l1_)
	l11ll111l11l_l1_ = l111ll111ll1_l1_(l11l11lllll1_l1_)
	l1l111111l11_l1_ = l111ll111ll1_l1_(l11lllll1l11_l1_)
	l1l111111111_l1_ = l11ll111l11l_l1_+l1l111111l11_l1_
	LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ春"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫ昦")+str(len(l11ll111l11l_l1_))+l1l1l1_l1_ (u"࠭ࠫࠨ昧")+str(len(l1l111111l11_l1_))+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ昨"))
	proxy = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ昩"))
	response = dummy_object()
	response.succeeded = False
	settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ昪"),l1l1l1_l1_ (u"ࠪࠫ昫"))
	if proxy or l1l111111111_l1_:
		id,timeout = 0,10
		l111ll1l11l1_l1_ = len(l1l111111111_l1_)
		l11ll1l1l11l_l1_ = timeout
		if l111ll1l11l1_l1_>l11ll1l1l11l_l1_: counts = l11ll1l1l11l_l1_
		else: counts = l111ll1l11l1_l1_
		l11lll11l1l1_l1_ = random.sample(l1l111111111_l1_,counts)
		if proxy: l11lll11l1l1_l1_ = [proxy]+l11lll11l1l1_l1_
		#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ昬"),str(l11lll11l1l1_l1_))
		threads = l11l1l1111l_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l11lll111ll1_l1_:
			if id<counts:
				proxy = l11lll11l1l1_l1_[id]
				threads.start_new_thread(id,l11l111lllll_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ昭"),LOGGING(script_name)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ昮")+proxy+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ是"))
		l11lll111ll1_l1_ = threads.l11lll111ll1_l1_
		if l11lll111ll1_l1_:
			l11l1ll1llll_l1_ = threads.l11l1ll1llll_l1_
			l11l1ll1111l_l1_ = l11lll111ll1_l1_[0]
			response = l11l1ll1llll_l1_[l11l1ll1111l_l1_]
			proxy = l11lll11l1l1_l1_[int(l11l1ll1111l_l1_)]
			settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ昰"),proxy)
			if l11l1ll1111l_l1_!=0: LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ昱"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭昲")+proxy+l1l1l1_l1_ (u"ࠫࠥࡣࠧ昳"))
			else: LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ昴"),LOGGING(script_name)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ昵")+proxy+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ昶"))
		#LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ昷"),l1l1l1_l1_ (u"ࠩࡳࡶࡴࡾࡩࡦࡵࡏࡍࡘ࡚࠲ࠡ࠼࠽ࠤࠬ昸")+str(l11lll11l1l1_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ昹"),l1l1l1_l1_ (u"ࠫࡵࡸ࡯ࡹ࡫ࡨࡷࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭昺")+str(l1l111111111_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ昻"),l1l1l1_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ昼")+str(threads.l11lll111ll1_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ昽"),l1l1l1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ显")+str(threads.l1l111111l1l_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ昿"),l1l1l1_l1_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࡶࡈࡎࡉࡔࠡ࠼࠽ࠤࠬ晀")+str(threads.l11l1ll1llll_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ晁"),l1l1l1_l1_ (u"ࠬ࡫࡬ࡱࡣࡶࡩࡩࡺࡩ࡮ࡧࡇࡍࡈ࡚ࠠ࠻࠼ࠣࠫ時")+str(threads.l11lllll11ll_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭晃"),l1l1l1_l1_ (u"ࠧࡴࡱࡵࡸࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ晄")+str(l111l111lll_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ晅"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤࠥ࠭晆")+l111ll11l1l1_l1_+l1l1l1_l1_ (u"ࠪࠤࠥࠦࠧ晇")+str(l111l111lll_l1_))
	return response
def USE_DNS_SERVER(connection,dns_server):
	original_create_connection = connection.create_connection
	def l111lll111l1_l1_(address,*args,**kwargs):
		host,port = address
		l1lllll11111_l1_ = DNS_RESOLVER(host,dns_server)
		if l1lllll11111_l1_: host = l1lllll11111_l1_[0]
		else:
			if dns_server in l1l1l1111111_l1_: l1l1l1111111_l1_.remove(dns_server)
			if l1l1l1111111_l1_:
				l111lllll1ll_l1_ = l1l1l1111111_l1_[0]
				#LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ晈"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡘ࡫࡯ࡰࠥࡺࡲࡺࠢࡷ࡬ࡪࠦ࡯ࡵࡪࡨࡶࠥࡊࡎࡔ࠼࡞ࠤࠬ晉")+l111lllll1ll_l1_+l1l1l1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍࡵࡳࡵ࠼࡞ࠤࠬ晊")+str(host)+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ晋"))
				l1lllll11111_l1_ = DNS_RESOLVER(host,l111lllll1ll_l1_)
				if l1lllll11111_l1_: host = l1lllll11111_l1_[0]
		address = (host,port)
		return original_create_connection(address,*args,**kwargs)
	connection.create_connection = l111lll111l1_l1_
	return original_create_connection
def l1lll11l1l_l1_(expiry,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡵࡷࡶࠬ晌"),l1l1l1_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ晍"),[method,url,data,headers,source])
	if html:
		LOG_OPENURL(True,url,data,headers,source,l1l1l1_l1_ (u"ࠪࠫ晎"))
		return html
	html = l11111111_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬ晏"),[method,url,data,headers,source],html,expiry)
	return html
def l11111111_l1_(method,url,data=l1l1l1_l1_ (u"ࠬ࠭晐"),headers=l1l1l1_l1_ (u"࠭ࠧ晑"),source=l1l1l1_l1_ (u"ࠧࠨ晒")):
	LOG_OPENURL(False,url,data,headers,source,l1l1l1_l1_ (u"ࠨࠩ晓"))
	if kodi_version>18.99: import urllib.request as l111ll1l11ll_l1_
	else: import urllib2 as l111ll1l11ll_l1_
	if not headers: headers = {l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭晔"):l1l1l1_l1_ (u"ࠪࠫ晕")}
	if not data: data = {}
	if method==l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ晖"):
		url = url+l1l1l1_l1_ (u"ࠬࡅࠧ晗")+l1lll11l1_l1_(data)
		data = None
	try:
		req = l111ll1l11ll_l1_.Request(url,headers=headers,data=data)
		http_response = l111ll1l11ll_l1_.urlopen(req)
		html = http_response.read()
	except: html = l1l1l1_l1_ (u"࠭ࠧ晘")
	#try:
	#	req = l111ll1l11ll_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l111ll1l11ll_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l1l1l1_l1_ (u"ࠧࠨ晙")
	return html
def l111l1l1ll1l_l1_(url):
	l11lll1l1lll_l1_,l11ll11111l1_l1_ = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ晚"))[2],80
	if l1l1l1_l1_ (u"ࠩ࠽ࠫ晛") in l11lll1l1lll_l1_: l11lll1l1lll_l1_,l11ll11111l1_l1_ = l11lll1l1lll_l1_.split(l1l1l1_l1_ (u"ࠪ࠾ࠬ晜"))
	l11l11ll1l1l_l1_ = l1l1l1_l1_ (u"ࠫ࠴࠭晝")+l1l1l1_l1_ (u"ࠬ࠵ࠧ晞").join(url.split(l1l1l1_l1_ (u"࠭࠯ࠨ晟"))[3:])
	request = l1l1l1_l1_ (u"ࠧࡈࡇࡗࠤࠬ晠")+l11l11ll1l1l_l1_+l1l1l1_l1_ (u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ晡")
	#request += l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡀࠠ࡝ࡴ࡟ࡲࠬ晢")
	request += l1l1l1_l1_ (u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ晣")+l11lll1l1lll_l1_+l1l1l1_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ晤")
	request += l1l1l1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ晥")
	import socket
	try:
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect((l11lll1l1lll_l1_,l11ll11111l1_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l1l1_l1_ (u"࠭ࠧ晦")
	return html
def SERVER(l111ll_l1_,type):
	# url:	http://l1ll1l1ll1l_l1_.l11ll11l111l_l1_.l1lll1l11_l1_
	# host:	l1ll1l1ll1l_l1_.l11ll11l111l_l1_.l1lll1l11_l1_
	# name:	l11ll11l111l_l1_
	#server = l1l1l1_l1_ (u"ࠧ࠰ࠩ晧").join(l111ll_l1_.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ晨"))[:3])
	if l1l1l1_l1_ (u"ࠩ࠱ࠫ晩") not in l111ll_l1_: return l111ll_l1_
	l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬ晪")
	part1,part2 = l111ll_l1_.split(l1l1l1_l1_ (u"ࠫ࠳࠭晫"),1)
	l111lll11ll1_l1_,l111lll11l1l_l1_ = part2.split(l1l1l1_l1_ (u"ࠬ࠵ࠧ晬"),1)
	server = part1+l1l1l1_l1_ (u"࠭࠮ࠨ晭")+l111lll11ll1_l1_
	if type in [l1l1l1_l1_ (u"ࠧࡩࡱࡶࡸࠬ普"),l1l1l1_l1_ (u"ࠨࡰࡤࡱࡪ࠭景")] and l1l1l1_l1_ (u"ࠩ࠲ࠫ晰") in server: server = server.rsplit(l1l1l1_l1_ (u"ࠪ࠳ࠬ晱"),1)[1]
	if type==l1l1l1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ晲") and l1l1l1_l1_ (u"ࠬ࠴ࠧ晳") in server:
		l111ll1ll1ll_l1_ = server.split(l1l1l1_l1_ (u"࠭࠮ࠨ晴"))
		length = len(l111ll1ll1ll_l1_)
		if length<=2 or l1l1l1_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ晵") in server: l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_[0]
		elif length>=3: l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_[1]
		if len(l111ll1ll1ll_l1_)>1: server = l111ll1ll1ll_l1_
	return server
	l1l1l1_l1_ (u"ࠣࠤࠥࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࠧ࠰ࠩ࠮ࡹࡷࡲ࠲ࠬࠩ࠲ࠫࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡰࡨࡸ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲࡱ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡱࡵ࡫࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡺࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡷࡺ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡹࡶ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡵࡱ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡭ࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩ࡯࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡷࡻ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡦࡳ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡸࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤ࡮ࡸࡦ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡪࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡰࡼ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡫ࡱ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡸࡹࡺ࠲ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯࡮࠰ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴࡫࡭ࡣࡧࡧ࠲ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࠢࠣࠤ晶")
def l1l111l11l1_l1_(l1l1111ll11l_l1_):
	l1l11111l111_l1_ = repr(l1l1111ll11l_l1_.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ晷"))).replace(l1l1l1_l1_ (u"ࠥࠫࠧ晸"),l1l1l1_l1_ (u"ࠫࠬ晹"))
	return l1l11111l111_l1_
def l1ll1l111l1_l1_(string):
	#if l1l1l1_l1_ (u"ࠬࡢࡵࠨ智") in string:
	#	string = string.decode(l1l1l1_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ晻"))
	#	l11l1l11ll11_l1_=re.findall(l1l1l1_l1_ (u"ࡲࠨ࡞ࡸ࡟࠵࠳࠹ࡂ࠯ࡉࡡࠬ晼"),string)
	#	for unicode in l11l1l11ll11_l1_
	#		char = l111l11lll11_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭晽"))
	l111l1llll11_l1_ = l1l1l1_l1_ (u"ࠩࠪ晾")
	if kodi_version<19: string = string.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ晿"))
	import unicodedata
	for l1ll1l11111_l1_ in string:
		if   l1ll1l11111_l1_==l1l1l1_l1_ (u"ࡹࠬศࠧ暀"): l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭暁")
		elif l1ll1l11111_l1_==l1l1l1_l1_ (u"ࡻࠧฤࠩ暂"): l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨ暃")
		elif l1ll1l11111_l1_==l1l1l1_l1_ (u"ࡶࠩวࠫ暄"): l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪ暅")
		elif l1ll1l11111_l1_==l1l1l1_l1_ (u"ࡸࠫส࠭暆"): l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬ暇")
		elif l1ll1l11111_l1_==l1l1l1_l1_ (u"ࡺ࠭ฦࠨ暈"): l11ll1l1llll_l1_ = l1l1l1_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧ暉")
		else:
			l111l11ll111_l1_ = unicodedata.decomposition(l1ll1l11111_l1_)
			if l1l1l1_l1_ (u"ࠧࠡࠩ暊") in l111l11ll111_l1_: l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠨ࡞࡟ࡹࠬ暋")+l111l11ll111_l1_.split(l1l1l1_l1_ (u"ࠩࠣࠫ暌"),1)[1]
			else:
				l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ暍")+hex(ord(l1ll1l11111_l1_)).replace(l1l1l1_l1_ (u"ࠫ࠵ࡾࠧ暎"),l1l1l1_l1_ (u"ࠬ࠭暏"))
				l11ll1l1llll_l1_ = l1l1l1_l1_ (u"࠭࡜࡝ࡷࠪ暐")+l11ll1l1llll_l1_[-4:]
			#if ord(l1ll1l11111_l1_)<256: l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠵࠭暑")+l111ll1ll11l_l1_
			#elif ord(l1ll1l11111_l1_)<4096: l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠨ࡞࡟ࡹ࠵࠭暒")+l111ll1ll11l_l1_
			#elif l1l1l1_l1_ (u"ࠩࠣࠫ暓") in l111l11ll111_l1_: l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠪࡠࡡࡻࠧ暔")+l111l11ll111_l1_.split(l1l1l1_l1_ (u"ࠫࠥ࠭暕"),1)[1]
			#else: l11ll1l1llll_l1_ = l1l1l1_l1_ (u"ࠬࡢ࡜ࡶࠩ暖")+l111ll1ll11l_l1_
		l111l1llll11_l1_ += l11ll1l1llll_l1_
	l111l1llll11_l1_ = l111l1llll11_l1_.replace(l1l1l1_l1_ (u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧ暗"),l1l1l1_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨ暘"))
	if kodi_version<19: l111l1llll11_l1_ = l111l1llll11_l1_.decode(l1l1l1_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ暙")).encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ暚"))
	else: l111l1llll11_l1_ = l111l1llll11_l1_.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ暛")).decode(l1l1l1_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ暜"))
	return l111l1llll11_l1_
def OPEN_KEYBOARD(header=l1l1l1_l1_ (u"๊่ࠬฮหࠣห้๋แศฬํัࠬ暝"),default=l1l1l1_l1_ (u"࠭ࠧ暞"),l11ll1l11lll_l1_=False):
	text = l111llllllll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l1l1_l1_ (u"ࠧࠡࠢࠪ暟"),l1l1l1_l1_ (u"ࠨࠢࠪ暠")).replace(l1l1l1_l1_ (u"ࠩࠣࠤࠬ暡"),l1l1l1_l1_ (u"ࠪࠤࠬ暢")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠧ暣"),l1l1l1_l1_ (u"ࠬࠦࠧ暤"))
	if not text and not l11ll1l11lll_l1_:
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭暥"),l1l1l1_l1_ (u"ࠧ࠯ࠢࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ暦")+text+l1l1l1_l1_ (u"ࠨࠤࠪ暧"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ暨"),l1l1l1_l1_ (u"ࠪࠫ暩"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ暪"),l1l1l1_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨ暫"))
		return l1l1l1_l1_ (u"࠭ࠧ暬")
	if text not in [l1l1l1_l1_ (u"ࠧࠨ暭"),l1l1l1_l1_ (u"ࠨࠢࠪ暮")]:
		text = text.strip(l1l1l1_l1_ (u"ࠩࠣࠫ暯"))
		text = l1ll1l111l1_l1_(text)
	if l11lll1_l1_(l1l1l1_l1_ (u"ࠪࡏࡊ࡟ࡂࡐࡃࡕࡈࠬ暰"),l1l1l1_l1_ (u"ࠫࠬ暱"),[text],False):
		LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ暲"),l1l1l1_l1_ (u"࠭࠮ࠡࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤࠪ暳")+text+l1l1l1_l1_ (u"ࠧࠣࠩ暴"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ暵"),l1l1l1_l1_ (u"ࠩࠪ暶"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭暷"),l1l1l1_l1_ (u"ࠫอำหࠡ฼ํี๋ࠥำๆ๊ะࠤอํࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠩ暸"))
		return l1l1l1_l1_ (u"ࠬ࠭暹")
	LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭暺"),l1l1l1_l1_ (u"ࠧ࠯ࠢࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫ暻")+text+l1l1l1_l1_ (u"ࠨࠤࠪ暼"))
	return text
def l11ll1111l11_l1_():
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࡨࡡࡪ࠺࡝ࡦ࡟ࡨࠥࡢ࡛࠰ࡅࡒࡐࡔࡘ࡜࡞ࠩ暽"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l1l1_l1_ (u"ࠪࡣࠪࡳ࠮ࠦࡦࡢࠩࡍࡀࠥࡎࡡࠪ暾"),time.localtime(now))
	name = name+datetime
	menuItem = type,name,url,mode,image,page,text,context,infodict
	if os.path.exists(l1l1l1lllll_l1_):
		oldFILE = open(l1l1l1lllll_l1_,l1l1l1_l1_ (u"ࠫࡷࡨࠧ暿")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ曀"))
		oldFILE = EVAL(l1l1l1_l1_ (u"࠭ࡤࡪࡥࡷࠫ曁"),oldFILE)
	else: oldFILE = {}
	newFILE = {}
	for l111ll1l1ll1_l1_ in list(oldFILE.keys()):
		if l111ll1l1ll1_l1_!=type: newFILE[l111ll1l1ll1_l1_] = oldFILE[l111ll1l1ll1_l1_]
		else:
			if name and name!=l1l1l1_l1_ (u"ࠧ࠯࠰ࠪ曂"):
				oldLIST = oldFILE[l111ll1l1ll1_l1_]
				if menuItem in oldLIST:
					index = oldLIST.index(menuItem)
					del oldLIST[index]
				newLIST = [menuItem]+oldLIST
				newLIST = newLIST[:50]
				newFILE[l111ll1l1ll1_l1_] = newLIST
			else: newFILE[l111ll1l1ll1_l1_] = oldFILE[l111ll1l1ll1_l1_]
	if type not in list(newFILE.keys()): newFILE[type] = [menuItem]
	newFILE = str(newFILE)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭曃"))
	open(l1l1l1lllll_l1_,l1l1l1_l1_ (u"ࠩࡺࡦࠬ曄")).write(newFILE)
	return
def l1l1ll1ll1_l1_(url2,headers={}):
	#if headers[l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ曅")]==l1l1l1_l1_ (u"ࠫࠬ曆"): headers[l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ曇")] = l1l1l1_l1_ (u"࠭ࠠࠨ曈")
	#l11l1l1l11l1_l1_ = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ曉") : l1l1l1_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠽࠵࠯࠲࠱࠷࠼࠽࠰࠯࠳࠷࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ曊") }
	#url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡩ࠾࠴࠯࡯ࡼࡧࡩࡴ࠮࡮ࡧ࠲ࡺ࡮ࡪࡥࡰ࠰ࡰ࠷ࡺ࠾ࠧ曋")
	#open(l1l1l1_l1_ (u"ࠪࡗ࠿ࡢ࡜ࡵࡧࡶࡸ࠷࠴࡭࠴ࡷ࠻ࠫ曌"), l1l1l1_l1_ (u"ࠫࡷ࠭曍")).read()
	url,params = url2,l1l1l1_l1_ (u"ࠬ࠭曎")
	if l1l1l1_l1_ (u"࠭ࡼࠨ曏") in url2:
		url,params = url2.split(l1l1l1_l1_ (u"ࠧࡽࠩ曐"),1)
		if l1l1l1_l1_ (u"ࠨ࠿ࠪ曑") not in params: url,params = url2,l1l1l1_l1_ (u"ࠩࠪ曒")
	response = OPENURL_REQUESTS_CACHED(l1l1111lll1_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ曓"),url,l1l1l1_l1_ (u"ࠫࠬ曔"),headers,l1l1l1_l1_ (u"ࠬ࠭曕"),True,l1l1l1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ曖"),False,False)
	html = response.content
	if l1l1l1_l1_ (u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫ曗") not in html: return [l1l1l1_l1_ (u"ࠨ࠯࠴ࠫ曘")],[url2]
	#	if l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭曙") in list(headers.keys()): del headers[l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ曚")]
	#	else: headers[l1l1l1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ曛")] = l1l1l1_l1_ (u"ࠬ࠭曜")
	#	response = OPENURL_REQUESTS_CACHED(l1l1111lll1_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ曝"),url,l1l1l1_l1_ (u"ࠧࠨ曞"),headers,l1l1l1_l1_ (u"ࠨࠩ曟"),False,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠵ࡲࡩ࠭曠"),False,False)
	#	html = response.content
	if l1l1l1_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡃࡘࡈࡎࡕࠧ曡") in html: return [l1l1l1_l1_ (u"ࠫ࠲࠷ࠧ曢")],[url2]
	if l1l1l1_l1_ (u"࡚࡙ࠬࡑࡇࡀ࡚ࡎࡊࡅࡐࠩ曣") in html: return [l1l1l1_l1_ (u"࠭࠭࠲ࠩ曤")],[url2]
	#if l1l1l1_l1_ (u"ࠧࡕ࡛ࡓࡉࡂ࡙ࡕࡃࡖࡌࡘࡑࡋࡓࠨ曥") in html: return [l1l1l1_l1_ (u"ࠨ࠯࠴ࠫ曦")],[url2]
	l1111ll_l1_,l11l1_l1_,l11ll11l1l11_l1_,l1l11111111l_l1_ = [],[],[],[]
	lines = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩ曧"),html+l1l1l1_l1_ (u"ࠪࡠࡳࡢࡲࠨ曨"),re.DOTALL)
	if not lines: return [l1l1l1_l1_ (u"ࠫ࠲࠷ࠧ曩")],[url2]
	for line,l111ll_l1_ in lines:
		l111l1ll1ll1_l1_,l11ll1l11ll_l1_,l11ll111_l1_ = {},-1,-1
		title = l1l1l1_l1_ (u"ࠬ࠭曪")
		#hostname = SERVER(l111ll_l1_,l1l1l1_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ曫"))
		#title = title+l1l1l1_l1_ (u"ࠧࠡࠢࠪ曬")+hostname+l1l1l1_l1_ (u"ࠨࠢࠣࠫ曭")
		#line = line.lower()
		items = line.split(l1l1l1_l1_ (u"ࠩ࠯ࠫ曮"))
		for item in items:
			#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ曯"),l1l1l1_l1_ (u"ࠫࠬ曰"),item,l1l1l1_l1_ (u"ࠬ࠭曱"))
			#if l1l1l1_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ曲") in item: l111l1ll1ll1_l1_[key] = value
			if l1l1l1_l1_ (u"ࠧ࠾ࠩ曳") in item:
				key,value = item.split(l1l1l1_l1_ (u"ࠨ࠿ࠪ更"),1)
				l111l1ll1ll1_l1_[key.lower()] = value
		if l1l1l1_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭曵") in line.lower():
			l11ll1l11ll_l1_ = int(l111l1ll1ll1_l1_[l1l1l1_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ曶")])//1024
			#title += l1l1l1_l1_ (u"ࠫࡆࡼࡧࡃ࡙࠽ࠤࠬ曷")+str(l11ll1l11ll_l1_)+l1l1l1_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ書")
			title += str(l11ll1l11ll_l1_)+l1l1l1_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭曹")
		elif l1l1l1_l1_ (u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ曺") in line.lower():
			l11ll1l11ll_l1_ = int(l111l1ll1ll1_l1_[l1l1l1_l1_ (u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ曻")])//1024
			#title += l1l1l1_l1_ (u"ࠩࡅ࡛࠿ࠦࠧ曼")+str(l11ll1l11ll_l1_)+l1l1l1_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ曽")
			title += str(l11ll1l11ll_l1_)+l1l1l1_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ曾")
		if l1l1l1_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ替") in line.lower():
			l11ll111_l1_ = int(l111l1ll1ll1_l1_[l1l1l1_l1_ (u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ最")].split(l1l1l1_l1_ (u"ࠧࡹࠩ朁"))[1])
			#title += l1l1l1_l1_ (u"ࠨࡔࡨࡷ࠿ࠦࠧ朂")+str(l11ll111_l1_)+l1l1l1_l1_ (u"ࠩࠣࠤࠬ會")
			title += str(l11ll111_l1_)+l1l1l1_l1_ (u"ࠪࠤࠥ࠭朄")
		title = title.strip(l1l1l1_l1_ (u"ࠫࠥࠦࠧ朅"))
		if not title: title = l1l1l1_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭朆")
		if not l111ll_l1_.startswith(l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ朇")):
			if l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠧ࠰࠱ࠪ月")): l111ll_l1_ = url.split(l1l1l1_l1_ (u"ࠨ࠼ࠪ有"),1)[0]+l1l1l1_l1_ (u"ࠩ࠽ࠫ朊")+l111ll_l1_
			elif l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠪ࠳ࠬ朋")): l111ll_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ朌"))+l111ll_l1_
			else: l111ll_l1_ = url.rsplit(l1l1l1_l1_ (u"ࠬ࠵ࠧ服"),1)[0]+l1l1l1_l1_ (u"࠭࠯ࠨ朎")+l111ll_l1_
		if params!=l1l1l1_l1_ (u"ࠧࠨ朏"): l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡾࠪ朐")+params
		if l1l1l1_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ朑") in list(l111l1ll1ll1_l1_.keys()):
			l11111ll1_l1_ = l111l1ll1ll1_l1_[l1l1l1_l1_ (u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ朒")]
			l11111ll1_l1_ = l11111ll1_l1_.replace(l1l1l1_l1_ (u"ࠫࠧ࠭朓"),l1l1l1_l1_ (u"ࠬ࠭朔")).replace(l1l1l1_l1_ (u"ࠨࠧࠣ朕"),l1l1l1_l1_ (u"ࠧࠨ朖")).split(l1l1l1_l1_ (u"ࠨࠥࠪ朗"),1)[0]
			videofiletype = GET_VIDEOFILETYPE(l11111ll1_l1_)
			if videofiletype: title2 = title+l1l1l1_l1_ (u"ࠩࠣࠤࠬ朘")+videofiletype
			else: title2 = title
			title2 = title2+l1l1l1_l1_ (u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪ朙")
			title2 = title2+l1l1l1_l1_ (u"ࠫࠥࠦࠧ朚")+SERVER(l11111ll1_l1_,l1l1l1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ望"))
			l1111ll_l1_.append(title2)
			l11l1_l1_.append(l11111ll1_l1_)
			l11ll11l1l11_l1_.append(l11ll111_l1_)
			l1l11111111l_l1_.append(l11ll1l11ll_l1_)
		l111ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"࠭ࠣࠨ朜"),1)[0]
		videofiletype = GET_VIDEOFILETYPE(l111ll_l1_)
		if videofiletype: title = title+l1l1l1_l1_ (u"ࠧࠡࠢࠪ朝")+videofiletype
		title = title+l1l1l1_l1_ (u"ࠨࠢࠣࠫ朞")+SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ期"))
		l1111ll_l1_.append(title)
		l11l1_l1_.append(l111ll_l1_)
		l11ll11l1l11_l1_.append(l11ll111_l1_)
		l1l11111111l_l1_.append(l11ll1l11ll_l1_)
	zz = list(zip(l1111ll_l1_,l11l1_l1_,l11ll11l1l11_l1_,l1l11111111l_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1111ll_l1_,l11l1_l1_,l11ll11l1l11_l1_,l1l11111111l_l1_ = list(zip(*zz))
	l1111ll_l1_,l11l1_l1_ = list(l1111ll_l1_),list(l11l1_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪࠫ朠"), l1111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫࠬ朡"), l11l1_l1_)
	return l1111ll_l1_,l11l1_l1_
mac = l1l1l1_l1_ (u"ࠬ࠭朢")
def l11l1lllll11_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1ll11l1lll_l1_(length=32):
	l1ll11l11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡳࡵࡴࠪ朣"),l1l1l1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ朤"),l1l1l1_l1_ (u"ࠨࡅࡏࡍࡊࡔࡔࡊࡆࠪ朥"))
	if l1ll11l11l_l1_: return l1ll11l11l_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l111llll11ll_l1_ = threading.Thread(target=l11l1lllll11_l1_,args=())
	l111llll11ll_l1_.start()
	for ii in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l1l1l1_l1_ (u"ࠩ࠳࠴࠶࠷࠲࠳࠵࠶࠸࠹࠻࠵࠷࠸࠺࠻ࠬ朦")
	else:
		mac = mac.replace(l1l1l1_l1_ (u"ࠪ࠾ࠬ朧"),l1l1l1_l1_ (u"ࠫࠬ木"))
		node = str(int(mac,16))
	node = re.findall(l1l1l1_l1_ (u"ࠬࡡ࠰࠮࠻ࡠ࠯ࠬ朩"),node,re.DOTALL)
	node = length*l1l1l1_l1_ (u"࠭࠰ࠨ未")+node[0]
	node = node[-length:]
	mm,ss = l1l1l1_l1_ (u"ࠧࠨ末"),l1l1l1_l1_ (u"ࠨࠩ本")
	l11l1111ll11_l1_ = str(int(l1l1l1_l1_ (u"ࠩ࠼ࠫ札")*(length+1))-int(node))[-length:]
	for ii in list(range(0,length,4)):
		l111l1l11l1l_l1_ = l11l1111ll11_l1_[ii:ii+4]
		mm += l111l1l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠱ࠬ朮")
		ss += str(sum(map(int,node[ii:ii+4]))%10)
	l1ll11l11l_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ术"),l1l1l1_l1_ (u"ࠬࡉࡌࡊࡇࡑࡘࡎࡊࠧ朰"),l1ll11l11l_l1_,PERMANENT_CACHE)
	return l1ll11l11l_l1_
def DNS_RESOLVER(host,dns_server=l1l1l1111111_l1_[0]):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ朱"),l1l1l1_l1_ (u"ࠧࠨ朲"),str(dns_server),str(host))
	if host.replace(l1l1l1_l1_ (u"ࠨ࠰ࠪ朳"),l1l1l1_l1_ (u"ࠩࠪ朴")).isdigit(): return [host]
	import struct,socket
	try:
		l11l1lll1111_l1_ = struct.pack(l1l1l1_l1_ (u"ࠥࡂࡍࠨ朵"), 12049)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠦࡃࡎࠢ朶"), 256)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠧࡄࡈࠣ朷"), 1)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠨ࠾ࡉࠤ朸"), 0)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠢ࠿ࡊࠥ朹"), 0)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠣࡀࡋࠦ机"), 0)
		if kodi_version>18.99: l11l1l1111ll_l1_ = host.split(l1l1l1_l1_ (u"ࠩ࠱ࠫ朻"))
		else: l11l1l1111ll_l1_ = host.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ朼")).split(l1l1l1_l1_ (u"ࠫ࠳࠭朽"))
		for part in l11l1l1111ll_l1_:
			parts = part.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ朾"))
			l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠨࡂࠣ朿"), len(part))
			for l11ll1111111_l1_ in part:
				l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠢࡤࠤ杀"), l11ll1111111_l1_.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭杁")))
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠤࡅࠦ杂"), 0)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠥࡂࡍࠨ权"), 1)
		l11l1lll1111_l1_ += struct.pack(l1l1l1_l1_ (u"ࠦࡃࡎࠢ杄"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l11l1lll1111_l1_), (dns_server, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11lll11ll1l_l1_ = struct.unpack_from(l1l1l1_l1_ (u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨ杅"), data, 0)
		l11ll11lll1l_l1_ = l11lll11ll1l_l1_[3]
		offset = len(host)+18
		answer = []
		for _ in range(l11ll11lll1l_l1_):
			l11ll11l11l1_l1_ = offset
			l11l11l11l1l_l1_ = 1
			l11l1ll1ll11_l1_ = False
			while True:
				l11ll1111111_l1_ = struct.unpack_from(l1l1l1_l1_ (u"ࠨ࠾ࡃࠤ杆"), data, l11ll11l11l1_l1_)[0]
				if l11ll1111111_l1_ == 0:
					l11ll11l11l1_l1_ += 1
					break
				# l111lll111ll_l1_ the field l111ll1ll1l1_l1_ the first l11lll1l11ll_l1_ bits l11l111ll1l1_l1_ to 1, l11l111ll11_l1_ a pointer
				if l11ll1111111_l1_ >= 192:
					l11l1lllll1l_l1_ = struct.unpack_from(l1l1l1_l1_ (u"ࠢ࠿ࡄࠥ杇"), data, l11ll11l11l1_l1_ + 1)[0]
					# l111l1ll11l1_l1_ the pointer
					l11ll11l11l1_l1_ = ((l11ll1111111_l1_ << 8) + l11l1lllll1l_l1_ - 0xc000) - 1
					l11l1ll1ll11_l1_ = True
				l11ll11l11l1_l1_ += 1
				if l11l1ll1ll11_l1_ == False: l11l11l11l1l_l1_ += 1
			if l11l1ll1ll11_l1_ == True: l11l11l11l1l_l1_ += 1
			offset = offset + l11l11l11l1l_l1_
			l11lllllll11_l1_ = struct.unpack_from(l1l1l1_l1_ (u"ࠣࡀࡋࡌࡎࡎࠢ杈"), data, offset)
			offset = offset + 10
			l11lll1l1l11_l1_ = l11lllllll11_l1_[0]
			l11l1ll1lll1_l1_ = l11lllllll11_l1_[3]
			if l11lll1l1l11_l1_ == 1: # l11ll1lll11l_l1_ type
				l11ll111111l_l1_ = struct.unpack_from(l1l1l1_l1_ (u"ࠤࡁࠦ杉")+l1l1l1_l1_ (u"ࠥࡆࠧ杊")*l11l1ll1lll1_l1_, data, offset)
				l1lllll11111_l1_ = l1l1l1_l1_ (u"ࠫࠬ杋")
				for l11ll1111111_l1_ in l11ll111111l_l1_: l1lllll11111_l1_ += str(l11ll1111111_l1_) + l1l1l1_l1_ (u"ࠬ࠴ࠧ杌")
				l1lllll11111_l1_ = l1lllll11111_l1_[0:-1]
				answer.append(l1lllll11111_l1_)
			if l11lll1l1l11_l1_ in [1,2,5,6,15,28]: offset = offset + l11l1ll1lll1_l1_
	except: answer = []
	if not answer: LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ杍"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡍࡵࡳࡵ࠼ࠣ࡟ࠥ࠭李")+host+l1l1l1_l1_ (u"ࠨࠢࡠࠫ杏"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ材"),l1l1l1_l1_ (u"ࠪࠫ村"),str(host),str(answer))
	return answer
def l11lll1_l1_(script_name,url,l1l1ll1_l1_,showDialog=True):
	if l1l1ll1_l1_:
		l11lll11ll11_l1_ = [l1l1l1_l1_ (u"่ࠫฮวาࠩ杒"),l1l1l1_l1_ (u"ࠬฮวๅ฼ࠪ杓"),l1l1l1_l1_ (u"࠭ࡡࡥࡷ࡯ࡸࠬ杔"),l1l1l1_l1_ (u"ࠧࡹࡺࠪ杕"),l1l1l1_l1_ (u"ࠨࡵࡨࡼࠬ杖")]
		if script_name!=l1l1l1_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ杗"):
			l11lll11ll11_l1_ += [l1l1l1_l1_ (u"ࠪࡶ࠿࠭杘"),l1l1l1_l1_ (u"ࠫࡷ࠳ࠧ杙"),l1l1l1_l1_ (u"ࠬ࠳࡭ࡢࠩ杚")]
			l11lll11ll11_l1_ += [l1l1l1_l1_ (u"࠭࠺ࡳࠩ杛"),l1l1l1_l1_ (u"ࠧ࠮ࡴࠪ杜"),l1l1l1_l1_ (u"ࠨ࡯ࡤ࠱ࠬ杝")]
		for l1lll1l1ll_l1_ in l1l1ll1_l1_:
			if l1l1l1_l1_ (u"ࠩࡪࡩࡹ࠴ࡰࡩࡲࡂࠫ杞") in l1lll1l1ll_l1_: continue
			if l1l1l1_l1_ (u"ࠪั้่ษࠨ束") in l1lll1l1ll_l1_: continue
			l1lll1l1ll_l1_ = l1lll1l1ll_l1_.lower()
			if kodi_version<19: l1lll1l1ll_l1_ = l1lll1l1ll_l1_.decode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ杠")).encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ条"))
			#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ杢"),l1l1l1_l1_ (u"ࠧࠨ杣"),l1l1l1_l1_ (u"ࠨࠩ杤"),str(l1lll1l1ll_l1_))
			#l11ll11ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡡࠬ࠶ࡡ࠶࠮࠻ࡠࢀ࠷ࡡ࠰࠮࠻ࡠ࠭ࠩ࠭来"),l1lll1l1ll_l1_,re.DOTALL)
			#l11ll11lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡢࡡ࠱ࠨ࠲࡝࠹࠱࠾ࡣࡼ࠳࡝࠳࠱࠾ࡣࠩࠥࠩ杦"),l1lll1l1ll_l1_,re.DOTALL)
			#l111l1ll1111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡣ࠮࠱࡜࠸࠰࠽ࡢࢂ࠲࡜࠲࠰࠽ࡢ࠯࡜ࠬࠦࠪ杧"),l1lll1l1ll_l1_,re.DOTALL)
			#l11l1llllll1_l1_ = any(l11ll11ll1l1_l1_,l11ll11lll11_l1_,l111l1ll1111_l1_,l11ll11ll11l_l1_)
			l1lll1l1ll_l1_ = l1lll1l1ll_l1_.replace(l1l1l1_l1_ (u"ࠬࡀࠧ杨"),l1l1l1_l1_ (u"࠭ࠧ杩"))
			l11l1llllll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞࠭ࠬࠫ杪"),l1lll1l1ll_l1_,re.DOTALL)
			l11l1ll11l1l_l1_ = False
			for digits in l11l1llllll1_l1_:
				if len(digits)==2:
					l11l1ll11l1l_l1_ = True
					break
			if l1l1l1_l1_ (u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧࠫ杫") in l1lll1l1ll_l1_: continue
			elif l1l1l1_l1_ (u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪ杬") in l1lll1l1ll_l1_: continue
			elif l1l1l1_l1_ (u"ࠪ฾๏ืࠠๆื้ๅࠬ杭") in l1lll1l1ll_l1_: continue
			elif l1l1ll11ll11_l1_(l1l1l1_l1_ (u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭杮")): continue
			elif l1lll1l1ll_l1_ in [l1l1l1_l1_ (u"ࠬࡸࠧ杯")] or l11l1ll11l1l_l1_ or any(value in l1lll1l1ll_l1_ for value in l11lll11ll11_l1_):
				LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ杰"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭東")+url+l1l1l1_l1_ (u"ࠨࠢࡠࠫ杲"))
				if showDialog: DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ杳"),l1l1l1_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬ杴"))
				return True
	return False
def l1lll11l1_l1_(data):
	if kodi_version>18.99: import urllib.parse as l11lllllll1l_l1_
	else: import urllib as l11lllllll1l_l1_
	l11ll1l1l1l1_l1_ = l11lllllll1l_l1_.urlencode(data)
	return l11ll1l1l1l1_l1_
def URLDECODE(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ杵"),l1l1l1_l1_ (u"ࠬ࠭杶"),url,l1l1l1_l1_ (u"࠭ࡕࡓࡎࡇࡉࡈࡕࡄࡆࠩ杷"))
	if l1l1l1_l1_ (u"ࠧ࠾ࠩ杸") in url:
		if l1l1l1_l1_ (u"ࠨࡁࠪ杹") in url: url2,filters = url.split(l1l1l1_l1_ (u"ࠩࡂࠫ杺"))
		else: url2,filters = l1l1l1_l1_ (u"ࠪࠫ杻"),url
		filters = filters.split(l1l1l1_l1_ (u"ࠫࠫ࠭杼"))
		data2 = {}
		for filter in filters:
			#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭杽"),l1l1l1_l1_ (u"࠭ࠧ松"),filter,str(filters))
			key,value = filter.split(l1l1l1_l1_ (u"ࠧ࠾ࠩ板"))
			data2[key] = value
	else: url2,data2 = url,{}
	return url2,data2
def PLAY_VIDEO(url3,website=l1l1l1_l1_ (u"ࠨࠩ枀"),type_=l1l1l1_l1_ (u"ࠩࠪ极")):
	if not type_: type_ = l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ枂")
	result,l11lll1l11l1_l1_,httpd = l1l1l1_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠶ࠧ枃"),l1l1l1_l1_ (u"ࠬ࠭构"),l1l1l1_l1_ (u"࠭ࠧ枅")
	if len(url3)==3:
		url,l11l111l1lll_l1_,httpd = url3
		if l11l111l1lll_l1_!=l1l1l1_l1_ (u"ࠧࠨ枆"): l11lll1l11l1_l1_ = l1l1l1_l1_ (u"ࠨࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀࠠ࡜ࠢࠪ枇")+l11l111l1lll_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠬ枈")
	else: url,l11l111l1lll_l1_,httpd = url3,l1l1l1_l1_ (u"ࠪࠫ枉"),l1l1l1_l1_ (u"ࠫࠬ枊")
	#url = UNQUOTE(url)		# cause l111l11llll1_l1_ for l1lll1lll_l1_ l111111l_l1_ l11l1llllll_l1_ streams
	url = url.replace(l1l1l1_l1_ (u"ࠬࠫ࠲࠱ࠩ枋"),l1l1l1_l1_ (u"࠭ࠠࠨ枌"))	# needed for l1lll11l11ll_l1_
	videofiletype = GET_VIDEOFILETYPE(url,website)
	if website not in [l1l1l1_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ枍"),l1l1l1_l1_ (u"ࠨࡋࡓࡘ࡛࠭枎")]:
		if website!=l1l1l1_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ枏"): url = url.replace(l1l1l1_l1_ (u"ࠪࠤࠬ析"),l1l1l1_l1_ (u"ࠫࠪ࠸࠰ࠨ枑"))
		LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ枒"),LOGGING(script_name)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡲ࡯ࡥࡾ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ枓")+url+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ枔")+l11lll1l11l1_l1_)
		if videofiletype==l1l1l1_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ枕") and website not in [l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ枖"),l1l1l1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ林")]:
			headers = {l1l1l1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ枘"):l1l1l1_l1_ (u"ࠬ࠭枙")}
			l1111ll_l1_,l11l1_l1_ = l1l1ll1ll1_l1_(url,headers)
			count = len(l11l1_l1_)
			if count>1:
				selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ枚")+str(count)+l1l1l1_l1_ (u"ࠧࠡ็็ๅ࠮࠭枛"), l1111ll_l1_)
				if selection == -1:
					DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะิ฻์็ࠫ果"),l1l1l1_l1_ (u"ࠩࠪ枝"))
					return result
			else: selection = 0
			url = l11l1_l1_[selection]
			if l1111ll_l1_[0]!=l1l1l1_l1_ (u"ࠪ࠱࠶࠭枞"):
				LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ枟"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ枠")+l1111ll_l1_[selection]+l1l1l1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ枡")+url+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ枢"))
		#url = url+l1l1l1_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠶࠾࠶࠱࠲࠳࠴ࠬ枣")
		#url = url+l1l1l1_l1_ (u"ࠩࡿࡈࡓ࡚࠽࠲ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࡁࡪࡴ࠭ࡖࡕ࠯ࡩࡳࡁࡱ࠾࠲࠱࠹ࠫࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠦࡂࡥࡦࡩࡵࡺ࠽ࠫ࠱࡚࠭ࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡍ࡫ࡱࡹࡽࡁࠠࡂࡰࡧࡶࡴ࡯ࡤࠡ࠹࠱࠴ࡀࠦࡓࡎ࠯ࡊ࠼࠾࠸ࡁࠡࡄࡸ࡭ࡱࡪ࠯ࡏࡔࡇ࠽࠵ࡓ࠻ࠡࡹࡹ࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯࡙ࠪࠢࡩࡷࡹࡩࡰࡰ࠲࠸࠳࠶ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠹࠱࠴࠳࠹࠳࠺࠸࠱࠼࠼ࠦࡍࡰࡤ࡬ࡰࡪࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭枤")
		if l1l1l1_l1_ (u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ枥") in url: url = url+l1l1l1_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ枦")
		elif l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ枧") in url.lower() and l1l1l1_l1_ (u"࠭࠯ࡥࡣࡶ࡬࠴࠭枨") not in url and l1l1l1_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ枩") not in url:
			if l1l1l1_l1_ (u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭枪") not in url and l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ枫") in url.lower():
				if l1l1l1_l1_ (u"ࠪࢀࠬ枬") not in url: url = url+l1l1l1_l1_ (u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨ枭")
				else: url = url+l1l1l1_l1_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ枮")
			if l1l1l1_l1_ (u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ枯") not in url.lower() and website not in [l1l1l1_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ枰"),l1l1l1_l1_ (u"ࠨࡏ࠶࡙ࠬ枱")]:
				if l1l1l1_l1_ (u"ࠩࡿࠫ枲") not in url: url = url+l1l1l1_l1_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ枳")
				else: url = url+l1l1l1_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ枴")
		#url = url.replace(l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ枵"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ架"))
	LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭枷"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡨ࡬ࡲࡦࡲࠠࡶࡴ࡯ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ枸")+url+l1l1l1_l1_ (u"ࠩࠣࡡࠬ枹"))
	l111l1llll1l_l1_ = xbmcgui.ListItem()
	#l111l1llll1l_l1_ = xbmcgui.ListItem(l1l1l1_l1_ (u"ࠪࡸࡪࡹࡴࠨ枺"))
	type_,l11lll11llll_l1_,l11l111lll1l_l1_,l111lll1lll1_l1_,l111ll111lll_l1_,l11l1l11ll1l_l1_,l11lll11lll1_l1_,l11l1111l111_l1_,l11l111ll111_l1_ = EXTRACT_KODI_PATH(addon_path)
	if website not in [l1l1l1_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭枻"),l1l1l1_l1_ (u"ࠬࡏࡐࡕࡘࠪ枼")]:
		if kodi_version<19: l111l11lll1l_l1_ = l1l1l1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࡥࡩࡪ࡯࡯ࠩ枽")
		else: l111l11lll1l_l1_ = l1l1l1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠬ枾")
		#l111l1llll1l_l1_ = xbmcgui.ListItem(path=url)
		l111l1llll1l_l1_.setProperty(l111l11lll1l_l1_, l1l1l1_l1_ (u"ࠨࠩ枿"))
		l111l1llll1l_l1_.setMimeType(l1l1l1_l1_ (u"ࠩࡰ࡭ࡲ࡫࠯ࡹ࠯ࡷࡽࡵ࡫ࠧ柀"))
		l111l1llll1l_l1_.setInfo(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ柁"),{l1l1l1_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࡷࡽࡵ࡫ࠧ柂"):l1l1l1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ柃")})
		#img = xbmc.getInfoLabel(l1l1l1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯࡫ࡦࡳࡳ࠭柄"))
		#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ柅"),l1l1l1_l1_ (u"ࠨࡇࡐࡅࡉࡀ࠺࠻࠼࠽ࠤࠬ柆")+image)
		#l111l1llll1l_l1_.setArt({l1l1l1_l1_ (u"ࠩ࡬ࡧࡴࡴࠧ柇"):image,l1l1l1_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ柈"):image,l1l1l1_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ柉"):image})
		l111l1llll1l_l1_.setArt({l1l1l1_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࠫ柊"):l111ll111lll_l1_,l1l1l1_l1_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭柋"):l111ll111lll_l1_,l1l1l1_l1_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧ柌"):l111ll111lll_l1_,l1l1l1_l1_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨ柍"):l111ll111lll_l1_,l1l1l1_l1_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫ柎"):l111ll111lll_l1_,l1l1l1_l1_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭柏"):l111ll111lll_l1_,l1l1l1_l1_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧ某"):l111ll111lll_l1_,l1l1l1_l1_ (u"ࠬ࡯ࡣࡰࡰࠪ柑"):l111ll111lll_l1_})
		#l111l1llll1l_l1_.setInfo(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ柒"),{l1l1l1_l1_ (u"ࠧࡕ࡫ࡷࡰࡪ࠭染"):name})
		#name = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ柔"))
		#name = name.strip(l1l1l1_l1_ (u"ࠩࠣࠫ柕"))
		# when set to l1l1l1_l1_ (u"ࠥࡊࡦࡲࡳࡦࠤ柖") it l11lll1lll1l_l1_ l111llll1lll_l1_ l111111ll1l_l1_ and l111llll1l1l_l1_ l11ll1ll1111_l1_ l111l1ll1l11_l1_ l111l1ll1lll_l1_
		if videofiletype in [l1l1l1_l1_ (u"ࠫ࠳ࡳࡰࡥࠩ柗"),l1l1l1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ柘")]: l111l1llll1l_l1_.setContentLookup(True)
		else: l111l1llll1l_l1_.setContentLookup(False)
		#if videofiletype in [l1l1l1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ柙")]: l111l1llll1l_l1_.setContentLookup(False)
		if l1l1l1_l1_ (u"ࠧࡳࡶࡰࡴࠬ柚") in url:
			import l1lll11ll1ll_l1_
			l1lll11ll1ll_l1_.l1ll1111ll11_l1_(l1l1l1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ柛"),False)
		elif videofiletype==l1l1l1_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ柜") or l1l1l1_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ柝") in url:
			import l1lll11ll1ll_l1_
			l1lll11ll1ll_l1_.l1ll1111ll11_l1_(l1l1l1_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ柞"),False)
			l111l1llll1l_l1_.setProperty(l111l11lll1l_l1_,l1l1l1_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ柟"))
			l111l1llll1l_l1_.setProperty(l1l1l1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭柠"),l1l1l1_l1_ (u"ࠧ࡮ࡲࡧࠫ柡"))
			#l111l1llll1l_l1_.setMimeType(l1l1l1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡤࡢࡵ࡫࠯ࡽࡳ࡬ࠨ柢"))
			#l111l1llll1l_l1_.setContentLookup(False)
		if l11l111l1lll_l1_:
			l111l1llll1l_l1_.setSubtitles([l11l111l1lll_l1_])
			#xbmc.log(LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤࠥࠦࠠࠡࡃࡧࡨࡪࡪࠠࡴࡷࡥࡸ࡮ࡺ࡬ࡦࠢࡷࡳࠥࡼࡩࡥࡧࡲࠤࠥࠦࡓࡶࡤࡷ࡭ࡹࡲࡥ࠻࡝ࠪ柣")+l11l111l1lll_l1_+l1l1l1_l1_ (u"ࠪࡡࠬ柤"), level=xbmc.LOGNOTICE)
	if type_==l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ查") and website==l1l1l1_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ柦"):
		result = l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭柧")
		website = l1l1l1_l1_ (u"ࠧࡑࡎࡄ࡝ࡤࡊࡌࡠࡈࡌࡐࡊ࡙ࠧ柨")
	elif type_==l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ柩") and l11l1111l111_l1_.startswith(l1l1l1_l1_ (u"ࠩ࠹ࠫ柪")):
		result = l1l1l1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ柫")
		website = website+l1l1l1_l1_ (u"ࠫࡤࡊࡌࠨ柬")
	# l11l1l1ll111_l1_ l11l1l111ll1_l1_
	#	l11l1111ll1l_l1_ = l11l1lll11l1_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l1l1l111l1_l1_ with xbmc.sleep(step*1000)
	if result!=l1l1l1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ柭"): l11ll1111l11_l1_()
	l11l1111ll1l_l1_ = l11l1lll11l1_l1_()
	if type_==l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ柮") and not l11l1111l111_l1_.startswith(l1l1l1_l1_ (u"ࠧ࠷ࠩ柯")):
		#title = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡮ࡺ࡬ࡦࠩ柰"))
		#l111l1llll1l_l1_.setInfo(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ柱"),{l1l1l1_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ柲"): 3600})
		#xbmcplugin.setContent(addon_handle,l1l1l1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ柳"))
		#l111l1llll1l_l1_.setInfo(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ柴"),{l1l1l1_l1_ (u"࠭࡭ࡦࡦ࡬ࡥࡹࡿࡰࡦࠩ柵"):l1l1l1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭柶")})
		#l111l1llll1l_l1_.setProperty(l1l1l1_l1_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬ柷"),l1l1l1_l1_ (u"ࠩࡷࡶࡺ࡫ࠧ柸"))
		#l111l1llll1l_l1_.setInfo(type=l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ柹"),l111l1lllll1_l1_={l1l1l1_l1_ (u"࡙ࠦ࡯ࡴ࡭ࡧࠥ柺"):l1l1l1_l1_ (u"ࠬ࡮ࡥ࡭࡮ࡲࠤࡼࡵࡲ࡭ࡦࠪ査")})
		l111l1llll1l_l1_.setPath(url)
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭柼"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࠫࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭柽")+url+l1l1l1_l1_ (u"ࠨࠢࡠࠫ柾"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l111l1llll1l_l1_)
	elif type_==l1l1l1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ柿"):
		LOG_THIS(l1l1l1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ栀"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ栁")+url+l1l1l1_l1_ (u"ࠬࠦ࡝ࠨ栂"))
		l11l1111ll1l_l1_.play(url,l111l1llll1l_l1_)
		#xbmc.Player().play(url,l111l1llll1l_l1_)
	if result!=l1l1l1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ栃"):
		timeout,result = 10,l1l1l1_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭栄")
		for ii in range(timeout):
			# l11l1l1ll111_l1_ l11l1l111ll1_l1_
			#	if l1lll1lll1l1_l1_ time.sleep() l1l11l11lll_l1_ of xbmc.sleep() l11ll1l111l1_l1_ the l1llll1lll1l_l1_ status
			#	l1l1l1_l1_ (u"ࠣ࡯ࡼࡴࡱࡧࡹࡦࡴ࠱ࡷࡹࡧࡴࡶࡵࠥ栅") will stop l11lll1l1l1l_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			result = l11l1111ll1l_l1_.status
			if result==l1l1l1_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ栆"):
				DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠪห้็๊ะ์๋ࠤ๏฿ๅๅࠩ标"),l1l1l1_l1_ (u"ࠫࠬ栈"),time=500)
				LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ栉"),LOGGING(script_name)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࡻ࡯ࡤࡦࡱࠣ࡭ࡸࠦࡰ࡭ࡣࡼ࡭ࡳ࡭ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ栊")+url+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ栋")+l11lll1l11l1_l1_)
				break
			elif result==l1l1l1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ栌"):
				LOG_THIS(l1l1l1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ栍"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡰ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ栎")+url+l1l1l1_l1_ (u"ࠫࠥࡣࠧ栏")+l11lll1l11l1_l1_)
				DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠬอไโ์า๎ํࠦไๆࠢํ฽๊๊ࠧ栐"),l1l1l1_l1_ (u"࠭ࠧ树"),time=500)
				break
			DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠧอษิ๎ࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ栒"),l1l1l1_l1_ (u"ࠨสสๆ๏ࠦࠧ栓")+str(timeout-ii)+l1l1l1_l1_ (u"ࠩࠣฯฬ์๊สࠩ栔"))
		else:
			result = l1l1l1_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ栕")
			l11l1111ll1l_l1_.stop()
			DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭栖"),l1l1l1_l1_ (u"ࠬ࠭栗"),time=500)
			LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ栘"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡘ࡮ࡳࡥࡰࡷࡷࠤࡺࡴ࡫࡯ࡱࡺࡲࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ栙")+url+l1l1l1_l1_ (u"ࠨࠢࡠࠫ栚")+l11lll1l11l1_l1_)
	l1l1l1_l1_ (u"ࠤࠥࠦࠒࠐࠉࡪࡨࠣ࡬ࡹࡺࡰࡥ࠼ࠐࠎࠎࠏࠣࠡࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠎࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡨࡲࡩࡤ࡭ࠣࡳࡰࠦࡴࡰࠢࡶ࡬ࡺࡺࡤࡰࡹࡱࠤࡹ࡮ࡥࠡࡪࡷࡸࡵࠦࡳࡦࡴࡹࡩࡷ࠭ࠩࠎࠌࠌࠍࠨ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡎࡐࡡࡆࡅࡈࡎࡅ࠭ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸ࠿࠻࠵࠱࠷࠸࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࡆࡢ࡮ࡶࡩ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠹ࡹ࡮ࠧࠪࠏࠍࠍࠎࡺࡩ࡮ࡧ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠭ࠒࠐࠉࠊࡪࡷࡸࡵࡪ࠮ࡴࡪࡸࡸࡩࡵࡷ࡯ࠪࠬࠑࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫ࡭ࡺࡴࡱࠢࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡪ࡯ࡸࡰࠪ࠰ࠬ࠭ࠩࠎࠌࠌࠦࠧࠨ栛")
	if result==l1l1l1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ栜") and not l1l1ll11ll11_l1_(l1l1l1_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ栝")):
		import l1l11ll11l_l1_
		succeeded = l1l11ll11l_l1_.l1l11lllll_l1_(url,videofiletype,website)
		if succeeded: l11ll1111l11_l1_()
	else: succeeded = False
	if result in [l1l1l1_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭栞"),l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭栟")] or succeeded:
		#addon_version = xbmc.getInfoLabel( l1l1l1_l1_ (u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠢ栠")+addon_id+l1l1l1_l1_ (u"ࠣࠫࠥ校") )
		response = SEND_ANALYTICS_EVENT(website)
		#html = response.content
	#if result in [l1l1l1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ栢"),l1l1l1_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ栣"),l1l1l1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ栤"),l1l1l1_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭栥"),l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ栦")]: l11lll1ll111_l1_(l1l1l1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ栧"),False)
	#l11lll1ll111_l1_(l1l1l1_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠳࠳ࡳࡦࠪ栨"))
	#if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ栩") in url and result in [l1l1l1_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ株"),l1l1l1_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ栫")]:
	#	l11lll1l1l1l_l1_ = HTTPS(False)
	#	if not l11lll1l1l1l_l1_:
	#		DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭栬"),l1l1l1_l1_ (u"࠭ࠧ栭"),l1l1l1_l1_ (u"ࠧศๆสฮฺอไࠡ็ืๅึ࠭栮"),l1l1l1_l1_ (u"ࠨ็ื็้ฯࠠ࠯࠰࠱ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢํัฯอฬࠡษ็ํࠥอสึษ็ࠤฺ๊แาࠢࠫีอ฽ࠠๆึไี࠮่ࠦๅๅ้ࠤ้๊ริใࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ้อ๋ࠠ฻่่ࠥ฿ไ๊ࠢฯ๋ฬุใࠨ栯"))
	#		return l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ栰")
	#sys.exit()
	return result
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l1l1l1lll1_l1_ = args[0]
		l11lll1l_l1_ = args[1]
		if not l1l1l1l1lll1_l1_: l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ栱")
		if not l11lll1l_l1_: l11lll1l_l1_ = l1l1l1_l1_ (u"ࠫฬูสๆำสีࠬ栲")
		header = args[2]
		text = l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ栳").join(args[3:])
	else: l1l1l1l1lll1_l1_,l11lll1l_l1_,header,text = l1l1l1_l1_ (u"࠭ࠧ栴"),l1l1l1_l1_ (u"ࠧࡐࡍࠪ栵"),l1l1l1_l1_ (u"ࠨࠩ栶"),l1l1l1_l1_ (u"ࠩࠪ样")
	DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1l1lll1_l1_,l1l1l1_l1_ (u"ࠪࠫ核"),l11lll1l_l1_,l1l1l1_l1_ (u"ࠫࠬ根"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l1l1l1lll1_l1_ = args[0]
	l11l11ll11ll_l1_ = args[1]
	l11l11l111l1_l1_ = args[2]
	if l11l11l111l1_l1_ or l11l11ll11ll_l1_: l11l11l1lll1_l1_ = True
	else: l11l11l1lll1_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l1l1l1lll1_l1_: l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ栺")
	if not l11l11ll11ll_l1_: l11l11ll11ll_l1_ = l1l1l1_l1_ (u"࠭ใๅษࠪ栻")
	if not l11l11l111l1_l1_: l11l11l111l1_l1_ = l1l1l1_l1_ (u"ࠧ็฻่ࠫ格")
	if len(args)>=6: text += l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ栽")+args[5]
	if len(args)>=7: text += l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ栾")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1l1lll1_l1_,l11l11ll11ll_l1_,l1l1l1_l1_ (u"ࠪࠫ栿"),l11l11l111l1_l1_,header,text)
	if choice==-1 and l11l11l1lll1_l1_: choice = -1
	elif choice==-1 and not l11l11l1lll1_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l11l1ll11ll1_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l1l1_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ桀") in list(kwargs.keys()): l11ll111l111_l1_ = kwargs[l1l1l1_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ桁")]
	else: l11ll111l111_l1_ = 1000
	if len(args)>2 and l1l1l1_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ桂") not in args[2]: profile = args[2]
	else: profile = l1l1l1_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭桃")
	l1l1llll11ll_l1_ = xbmcgui.WindowXMLDialog(l1l1l1_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡏ࡭ࡢࡩࡨ࠲ࡽࡳ࡬ࠨ桄"),addonfolder,l1l1l1_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ桅"),l1l1l1_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ框"))
	image_filename,image_height = CREATE_IMAGE(l1l1l1_l1_ (u"ࠫࠬ桇"),l1l1l1_l1_ (u"ࠬ࠭案"),l1l1l1_l1_ (u"࠭ࠧ桉"),header,text,profile,l1l1l1_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ桊"),720,False)
	#time.sleep(0.200)
	l1l1llll11ll_l1_.show()
	if profile==l1l1l1_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡵࡹࡲ࡬ࡦࡲࡦࡴࠩ桋"):
		l1l1llll11ll_l1_.getControl(9040).setHeight(215)
		l1l1llll11ll_l1_.getControl(9040).setPosition(55,-80)
		l1l1llll11ll_l1_.getControl(9050).setPosition(120,-60)
		l1l1llll11ll_l1_.getControl(400).setPosition(90,-35)
	l1l1llll11ll_l1_.getControl(401).setVisible(False)
	l1l1llll11ll_l1_.getControl(402).setVisible(False)
	l1l1llll11ll_l1_.getControl(9050).setImage(image_filename)
	l1l1llll11ll_l1_.getControl(9050).setHeight(image_height)
	import threading
	l11llllllll1_l1_ = threading.Thread(target=l111l11ll1l1_l1_,args=(l1l1llll11ll_l1_,image_filename,l11ll111l111_l1_))
	l11llllllll1_l1_.start()
	#l11llllllll1_l1_.join()
	return
	#return xbmcgui.Dialog().l111ll11l11l_l1_(l11l111111ll_l1_=False,*args,**kwargs)
def l111l11ll1l1_l1_(l1l1llll11ll_l1_,image_filename,l11ll111l111_l1_):
	time.sleep(l11ll111l111_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(image_filename):
		try: os.remove(image_filename)
		except: pass
	#del l1l1llll11ll_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠩࠪ桌"),l1l1l1_l1_ (u"ࠪࠫ桍"),l1l1l1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ桎"),l1l1l1_l1_ (u"ࠬࡲࡥࡧࡶࠪ桏")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1l1l1l1lll1_l1_ = args[3]
	return l1l1lll11l_l1_(l1l1l1l1lll1_l1_,header,text,profile)
	#return xbmcgui.Dialog().l11l11llll11_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l111lll1l111_l1_(*args,**kwargs)
def l1l1l11l1l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111llllllll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#button0,button1,button2,header,text,profile,l1l1l1l1lll1_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l1llll11ll_l1_ = l111ll1lllll_l1_(l1l1l1_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨ桐"),addonfolder,l1l1l1_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ桑"),l1l1l1_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭桒"))
	#l1l1llll11ll_l1_.l11ll1lllll1_l1_(button0,button1,button2,header,text,profile,l1l1l1l1lll1_l1_,855)
	#return l1l1llll11ll_l1_
	l1l1l1_l1_ (u"ࠤࠥࠦࠒࠐࠉࡪࡨࠣࡸ࡮ࡳࡥࡰࡷࡷࡂ࠵ࡀࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡴࡶࡤࡶࡹࡈࡵࡵࡶࡲࡲࡸ࡚ࡩ࡮ࡧࡲࡹࡹ࠮ࡴࡪ࡯ࡨࡳࡺࡺࠩࠎࠌࠌࡩࡱࡹࡥ࠻ࠢࡧ࡭ࡦࡲ࡯ࡨ࠰ࡨࡲࡦࡨ࡬ࡦࡄࡸࡸࡹࡵ࡮ࡴࠪࠬࠑࠏࠏࠣࡥ࡫ࡤࡰࡴ࡭࠮ࡶࡲࡧࡥࡹ࡫ࡐࡳࡱࡪࡶࡪࡹࡳࡃࡣࡵࠬ࠼࠶ࠩࠊࠥࠣ࠻࠵ࠫࠍࠋࠋࡧ࡭ࡦࡲ࡯ࡨ࠰ࡧࡳࡒࡵࡤࡢ࡮ࠫ࠭ࠒࠐࠉࡤࡪࡲ࡭ࡨ࡫ࠠ࠾ࠢࡧ࡭ࡦࡲ࡯ࡨ࠰ࡦ࡬ࡴ࡯ࡣࡦࡋࡇࠑࠏࠏࡴࡳࡻ࠽ࠤࡴࡹ࠮ࡳࡧࡰࡳࡻ࡫ࠨࡥ࡫ࡤࡰࡴ࡭࠮ࡪ࡯ࡤ࡫ࡪࡥࡦࡪ࡮ࡨࡲࡦࡳࡥࠪࠏࠍࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠐࠎࠎࠩࡤࡦ࡮ࠣࡨ࡮ࡧ࡬ࡰࡩࠐࠎࠎࡸࡥࡵࡷࡵࡲࠥࡩࡨࡰ࡫ࡦࡩࠒࠐࠉࠣࠤࠥ桓")
def l1ll1l1ll_l1_(l11l11l11111_l1_):
	if kodi_version>17.99: l1l1llll11ll_l1_ = l1l1l1_l1_ (u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨ桔")
	else: l1l1llll11ll_l1_ = l1l1l1_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨ桕")
	l11l11l11111_l1_ = l11l11l11111_l1_.lower()
	if l11l11l11111_l1_==l1l1l1_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ桖"): xbmc.executebuiltin(l1l1l1_l1_ (u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨ桗")+l1l1llll11ll_l1_+l1l1l1_l1_ (u"ࠧࠪࠩ桘"))
	elif l11l11l11111_l1_==l1l1l1_l1_ (u"ࠨࡵࡷࡳࡵ࠭桙"): xbmc.executebuiltin(l1l1l1_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩ桚")+l1l1llll11ll_l1_+l1l1l1_l1_ (u"ࠪ࠭ࠬ桛"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1l1lll1_l1_,button0=l1l1l1_l1_ (u"ࠫࠬ桜"),button1=l1l1l1_l1_ (u"ࠬ࠭桝"),button2=l1l1l1_l1_ (u"࠭ࠧ桞"),header=l1l1l1_l1_ (u"ࠧࠨ桟"),text=l1l1l1_l1_ (u"ࠨࠩ桠"),l11l11l1ll11_l1_=0,l111llll1ll1_l1_=0,profile=l1l1l1_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ桡")):
	if not l1l1l1l1lll1_l1_: l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ桢")
	l1l1llll11ll_l1_ = l111ll1lllll_l1_(l1l1l1_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭档"),addonfolder,l1l1l1_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭桤"),l1l1l1_l1_ (u"࠭࠷࠳࠲ࡳࠫ桥"))
	l1l1llll11ll_l1_.l11ll1lllll1_l1_(button0,button1,button2,header,text,profile,l1l1l1l1lll1_l1_,900,l11l11l1ll11_l1_,l111llll1ll1_l1_)
	if l11l11l1ll11_l1_>0: l1l1llll11ll_l1_.l11lllll1lll_l1_()
	if l111llll1ll1_l1_>0: l1l1llll11ll_l1_.l11llll1l1l1_l1_()
	if l11l11l1ll11_l1_==0 and l111llll1ll1_l1_==0: l1l1llll11ll_l1_.enableButtons()
	l1l1llll11ll_l1_.doModal()
	choice = l1l1llll11ll_l1_.l11llllll1ll_l1_
	return choice
def l1l1lll11l_l1_(l1l1l1l1lll1_l1_,header,text,profile=l1l1l1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ桦")):
	if not l1l1l1l1lll1_l1_: l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭桧")
	#text = l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ桨").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l1l1l1_l1_ (u"ࠪࠫ桩")
	l1l1llll11ll_l1_ = xbmcgui.WindowXMLDialog(l1l1l1_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧ桪"),addonfolder,l1l1l1_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭桫"),l1l1l1_l1_ (u"࠭࠷࠳࠲ࡳࠫ桬"))
	image_filename,image_height = CREATE_IMAGE(l1l1l1_l1_ (u"ࠧࠨ桭"),l1l1l1_l1_ (u"ࠨࠩ桮"),l1l1l1_l1_ (u"ࠩࠪ桯"),header,text,profile,l1l1l1l1lll1_l1_,1270,False)
	l1l1llll11ll_l1_.show()
	#time.sleep(1)
	#l1l1llll11ll_l1_.getControl(9050).l1ll111l1l1l_l1_(1270-60)
	l1l1llll11ll_l1_.getControl(9050).setHeight(image_height)
	l1l1llll11ll_l1_.getControl(9050).setImage(image_filename)
	result = l1l1llll11ll_l1_.doModal()
	#del l1l1llll11ll_l1_
	try: os.remove(image_filename)
	except: pass
	return result
def l1l1l11ll_l1_(l111lll1ll11_l1_=True):
	if l111lll1ll11_l1_:
		useragent = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡷࡹࡸࠧ桰"),l1l1l1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ桱"),l1l1l1_l1_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ桲"))
		if useragent: return useragent
	#LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭桳"),l1l1l1_l1_ (u"ࠧࡆࡏࡄࡈࠥࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶ࠽ࠤࠬ桴")+results)
	# l11llllll1l1_l1_ and l11l1lll11_l1_ common user l11l111l111l_l1_ (l11ll11ll1ll_l1_ l11llllll111_l1_)
	text = l1l1l1_l1_ (u"ࠨࠩ桵")
	url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡪࡩࡨࡣ࡮ࡲ࡫࠳ࡽࡩ࡭࡮ࡶ࡬ࡴࡻࡳࡦ࠰ࡦࡳࡲ࠵࠲࠱࠳࠵࠳࠵࠷࠯࠱࠵࠲ࡱࡴࡹࡴ࠮ࡥࡲࡱࡲࡵ࡮࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࡸ࠵ࠧ桶")
	headers = {l1l1l1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ桷"):url}
	response = OPENURL_REQUESTS_CACHED(l1lll1l1lll_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ桸"),url,l1l1l1_l1_ (u"ࠬ࠭桹"),headers,l1l1l1_l1_ (u"࠭ࠧ桺"),False,l1l1l1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡄࡒࡉࡕࡍࡠࡗࡖࡉࡗࡇࡇࡆࡐࡗ࠱࠶ࡹࡴࠨ桻"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l1l1_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢࠩ桼"))
		if count>80:
			text = re.findall(l1l1l1_l1_ (u"ࠩࡪࡩࡹ࠳ࡴࡩࡧ࠰ࡰ࡮ࡹࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ桽"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ桾"),l1l1l1_l1_ (u"ࠫࠬ桿"),l1l1l1_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠨ梀"),l1l1l1_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤ࡚࡙ࡅࡓ࠯ࡄࡋࡊࡔࡔࡔࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱ࠭梁"))
	if not text:
		text = open(l11l1l1111l1_l1_,l1l1l1_l1_ (u"ࠧࡳࡤࠪ梂")).read()
		if kodi_version>18.99: text = text.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭梃"))
		text = text.replace(l1l1l1_l1_ (u"ࠩ࡟ࡶࠬ梄"),l1l1l1_l1_ (u"ࠪࠫ梅"))
	l11l1l11llll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡓ࡯ࡻ࡫࡯ࡰࡦ࠴ࠪࡀࠫ࡟ࡲࠬ梆"),text,re.DOTALL)
	l11llll11l1l_l1_ = []
	for line in l11l1l11llll_l1_:
		l11l111llll1_l1_ = line.lower()
		if l1l1l1_l1_ (u"ࠬࡧ࡮ࡥࡴࡲ࡭ࡩ࠭梇") in l11l111llll1_l1_: continue
		if l1l1l1_l1_ (u"࠭ࡵࡣࡷࡱࡸࡺ࠭梈") in l11l111llll1_l1_: continue
		#if l1l1l1_l1_ (u"ࠧࡩࡶࡰࡰࠬ梉") in l11l111llll1_l1_: continue
		l11llll11l1l_l1_.append(line)
	useragent = random.sample(l11llll11l1l_l1_,1)
	useragent = useragent[0]
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ梊"),l1l1l1_l1_ (u"ࠩࠪ梋"),str(len(l11l1l11llll_l1_)),useragent)
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭梌"),l1l1l1_l1_ (u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧ梍"),useragent,l1llll111_l1_)
	return useragent
def l11llllll11l_l1_(errortrace):
	#if l1l1l1_l1_ (u"ࠬ࡬࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠪ梎") in str(error).lower(): return
	#errortrace = traceback.format_exc()
	sys.stderr.write(errortrace)
	lines = errortrace.splitlines()
	error = lines[-1]
	l11ll11l11ll_l1_ = open(l1ll11lll111_l1_,l1l1l1_l1_ (u"࠭ࡲࡣࠩ梏")).read()
	if kodi_version>18.99: l11ll11l11ll_l1_ = l11ll11l11ll_l1_.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ梐"))
	l11ll11l11ll_l1_ = l11ll11l11ll_l1_[-8000:]
	sep = l1l1l1_l1_ (u"ࠨ࠿ࠪ梑")*100
	if sep in l11ll11l11ll_l1_: l11ll11l11ll_l1_ = l11ll11l11ll_l1_.rsplit(sep,1)[1]
	if error in l11ll11l11ll_l1_: l11ll11l11ll_l1_ = l11ll11l11ll_l1_.rsplit(error,1)[0]
	#l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠩࠪ梒"),error,l11ll11l11ll_l1_)
	#loglines = l11ll11l11ll_l1_.splitlines()
	#for line in reversed(loglines):
	#	if l1l1l1_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠭梓") in line: continue
	#	if l1l1l1_l1_ (u"ࠫࡒࡵࡤࡦ࠼ࠣ࡟ࠬ梔") not in line: continue
	l1llll11l1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫ梕"),l11ll11l11ll_l1_,re.DOTALL)
	for typ,source in reversed(l1llll11l1l1_l1_):
		#if l1l1l1_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࠨ梖") in source: continue
		#if l1l1l1_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࠪ梗") in source: continue
		if source: break
	else: source = l1l1l1_l1_ (u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨ梘")
	#l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠩࠪ梙"),source,str(l1llll11l1l1_l1_))
	file,line,func = l1l1l1_l1_ (u"ࠪࠫ梚"),l1l1l1_l1_ (u"ࠫࠬ梛"),l1l1l1_l1_ (u"ࠬ࠭梜")
	l11ll11llll_l1_ = l1l1l1_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺว࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ條")+error
	source2 = l1l1l1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆู่ิื࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ梞")+source
	for l11l11ll1111_l1_ in reversed(lines):
		if l1l1l1_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠨ梟") in l11l11ll1111_l1_ and l1l1l1_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ梠") in l11l11ll1111_l1_: break
	l11l11ll1111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࠩࠣ࡞࠯ࠤࡱ࡯࡮ࡦࠢࠫ࠲࠯ࡅࠩ࡝࠮ࠣ࡭ࡳࠦࠨ࠯ࠬࡂ࠭ࠩ࠭梡"),l11l11ll1111_l1_,re.DOTALL)
	if l11l11ll1111_l1_:
		file,line,func = l11l11ll1111_l1_[0]
		if l1l1l1_l1_ (u"ࠫ࠴࠭梢") in file: file = file.rsplit(l1l1l1_l1_ (u"ࠬ࠵ࠧ梣"),1)[1]
		else: file = file.rsplit(l1l1l1_l1_ (u"࠭࡜࡝ࠩ梤"),1)[1]
		l111l1llllll_l1_ = l1l1l1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่่ๆࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ梥")+file
		line2 = l1l1l1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ื฼ื࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ梦")+line
		l11lll11111l_l1_ = l1l1l1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊้ว็࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭梧")+func
		l11ll11l1l1l_l1_ = l111l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡠࡳ࠭梨")+line2+l1l1l1_l1_ (u"ࠫࡡࡴࠧ梩")+l11lll11111l_l1_+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ梪")+source2+l1l1l1_l1_ (u"࠭࡜࡯ࠩ梫")+l11ll11llll_l1_
		l11l111l11ll_l1_ = line2+l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ梬")+source2+l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ梭")+l11ll11llll_l1_+l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ梮")+l111l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡠࡳ࠭梯")+l11lll11111l_l1_
		l11llll11lll_l1_ = line2+l1l1l1_l1_ (u"ࠫࡡࡴࠧ械")+l11ll11llll_l1_+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ梱")+l111l1llllll_l1_+l1l1l1_l1_ (u"࠭࡜࡯ࠩ梲")+l11lll11111l_l1_
	else:
		l111l1llllll_l1_,line2,l11lll11111l_l1_ = l1l1l1_l1_ (u"ࠧࠨ梳"),l1l1l1_l1_ (u"ࠨࠩ梴"),l1l1l1_l1_ (u"ࠩࠪ梵")
		l11ll11l1l1l_l1_ = source2+l1l1l1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ梶")+l11ll11llll_l1_
		l11l111l11ll_l1_ = source2+l1l1l1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ梷")+l11ll11llll_l1_
		l11llll11lll_l1_ = l11ll11llll_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l1l1l1_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭梸"),time=2000)
	l11ll1llllll_l1_ = l1l1l1_l1_ (u"࠭อะอࠣา฼ษࠠ฻์ิࠤ๊่ี้ัࠪ梹")+l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ梺")
	l11l1l1l1l_l1_ = l1l1lllll1l_l1_()
	l11l11llll1l_l1_ = []
	results = l11l1l1l1l_l1_[l1l1l1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭梻")]
	l11l11l1ll1l_l1_ = l111l1l111l1_l1_(addon_version)
	if l1l1l1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ梼") in list(l11l1l1l1l_l1_.keys()):
		for l111lll1l11l_l1_,l11l1llll1ll_l1_,l11llll11111_l1_ in results: l11l11llll1l_l1_ = max(l11l11llll1l_l1_,l11l1llll1ll_l1_)
		if l11l11l1ll1l_l1_<l11l11llll1l_l1_:
			header = l1l1l1_l1_ (u"ࠪๆ๊ࠦศหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ梽")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ梾"),l1l1l1_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ梿"),l1l1l1_l1_ (u"࠭สฮัํฯࠬ检"),l1l1l1_l1_ (u"ࠧฯำ๋ะࠬ棁"),l11ll1llllll_l1_+header,l11ll11l1l1l_l1_)
			if choice==0:
				yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ棂"),l1l1l1_l1_ (u"ࠩัีําࠧ棃"),l1l1l1_l1_ (u"ࠪฮาี๊ฬࠩ棄"),l1l1l1_l1_ (u"ࠫࠬ棅"),header)
				if yes==1: choice = 1
			if choice==1:
				import l1lll11ll1ll_l1_
				l1lll11ll1ll_l1_.l1ll11111l11_l1_()
			return
	l111l11ll11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡲࡩࡴࡶࠪ棆"),l1l1l1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ棇"),l1l1l1_l1_ (u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ棈"))
	if not l111l11ll11l_l1_: l111l11ll11l_l1_ = []
	l11l111l11ll_l1_ = l11l111l11ll_l1_.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ棉"),l1l1l1_l1_ (u"ࠩ࡟ࡠࡳ࠭棊")).replace(l1l1l1_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ棋"),l1l1l1_l1_ (u"ࠫࠬ棌")).replace(l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ棍"),l1l1l1_l1_ (u"࠭ࠧ棎")).replace(l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ棏"),l1l1l1_l1_ (u"ࠨࠩ棐"))
	l11llll11lll_l1_ = l11llll11lll_l1_.replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ棑"),l1l1l1_l1_ (u"ࠪࡠࡡࡴࠧ棒")).replace(l1l1l1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ棓"),l1l1l1_l1_ (u"ࠬ࠭棔")).replace(l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ棕"),l1l1l1_l1_ (u"ࠧࠨ棖")).replace(l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ棗"),l1l1l1_l1_ (u"ࠩࠪ棘"))
	l111l1l1l11l_l1_ = addon_version+l1l1l1_l1_ (u"ࠪ࠾࠿࠭棙")+l11llll11lll_l1_
	if l111l1l1l11l_l1_ in l111l11ll11l_l1_:
		header = l1l1l1_l1_ (u"้่ࠫฯࠡไ่ฮࠥอๆหࠢึหอ่วࠡสศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ棚")
		#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ棛"),l1l1l1_l1_ (u"࠭ฮา๊ฯࠫ棜"),l1l1l1_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ棝"),l11ll1llllll_l1_+header,l11ll11l1l1l_l1_)
		#if yes==1: DIALOG_OK(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ棞"),l1l1l1_l1_ (u"ࠩัีําࠧ棟"),l1l1l1_l1_ (u"ࠪࠫ棠"),header)
		DIALOG_OK(l1l1l1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ棡"),l1l1l1_l1_ (u"ࠬ࠭棢"),l11ll1llllll_l1_+header,l11ll11l1l1l_l1_)
		return
	l111l1ll111l_l1_ = str(kodi_version).split(l1l1l1_l1_ (u"࠭࠮ࠨ棣"))[0]
	#l11llll1l11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ棤"),l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ棥"),l1l1l1_l1_ (u"ࠩࡄࡐࡑࡥࡋࡏࡑ࡚ࡒࡤࡋࡒࡓࡑࡕࡗࠬ棦"))
	url = WEBSITES[l1l1l1_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ棧")][6]
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ棨"),url,l1l1l1_l1_ (u"ࠬ࠭棩"),l1l1l1_l1_ (u"࠭ࠧ棪"),l1l1l1_l1_ (u"ࠧࠨ棫"),l1l1l1_l1_ (u"ࠨࠩ棬"),l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬ棭"),False,False)
	html = response.content
	l11llll1l11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪ森"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ棯"),l1l1l1_l1_ (u"ࠬࡇࡌࡍࡡࡎࡒࡔ࡝ࡎࡠࡇࡕࡖࡔࡘࡓࠨ棰"),l11llll1l11l_l1_,REGULAR_CACHE)
	#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ棱"),line+l1l1l1_l1_ (u"ࠧࠡࠢࠣࠫ棲")+error+l1l1l1_l1_ (u"ࠨࠢࠣࠤࠬ棳")+addon_version+l1l1l1_l1_ (u"ࠩࠣࠤࠥ࠭棴")+l111l1ll111l_l1_)
	for l11ll1llll11_l1_,l11lll1lllll_l1_,l11l1l1lllll_l1_,l11l111l11l1_l1_ in l11llll1l11l_l1_:
		l11ll1llll11_l1_ = l11ll1llll11_l1_.split(l1l1l1_l1_ (u"ࠪ࠯ࠬ棵"))
		l11l1l1lllll_l1_ = l11l1l1lllll_l1_.split(l1l1l1_l1_ (u"ࠫ࠰࠭棶"))
		l11l111l11l1_l1_ = l11l111l11l1_l1_.split(l1l1l1_l1_ (u"ࠬ࠱ࠧ棷"))
		#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ棸"),str(l11ll1llll11_l1_)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࠫ棹")+l11lll1lllll_l1_+l1l1l1_l1_ (u"ࠨࠢࠣࠤࠬ棺")+str(l11l1l1lllll_l1_)+l1l1l1_l1_ (u"ࠩࠣࠤࠥ࠭棻")+str(l11l111l11l1_l1_))
		if line in l11ll1llll11_l1_ and error==l11lll1lllll_l1_ and addon_version in l11l1l1lllll_l1_ and l111l1ll111l_l1_ in l11l111l11l1_l1_:
			header = l1l1l1_l1_ (u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨ棼")
			yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ棽"),l1l1l1_l1_ (u"ࠬิั้ฮࠪ棾"),l1l1l1_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ棿"),l11ll1llllll_l1_+header,l11ll11l1l1l_l1_)
			if yes==1: DIALOG_OK(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ椀"),l1l1l1_l1_ (u"ࠨࠩ椁"),l1l1l1_l1_ (u"ࠩࠪ椂"),header)
			return
	header = l1l1l1_l1_ (u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ椃")
	DIALOG_OK(l1l1l1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ椄"),l1l1l1_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ椅"),l11ll1llllll_l1_+header,l11ll11l1l1l_l1_)
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭椆"),l1l1l1_l1_ (u"ࠧไๆสࠫ椇"),l1l1l1_l1_ (u"ࠨ่฼้ࠬ椈"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ椉"),l1l1l1_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫ椊"))
	if yes==1: l1lll1111l11_l1_ = l1l1l1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ椋")
	else:
		DIALOG_OK(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ椌"),l1l1l1_l1_ (u"࠭ࠧ植"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ椎"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ๊ࠦลๅ฼สลࠥหัิษ็ࠤฬ๊ฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭椏"))
		return
	message = l11l111l11ll_l1_
	l111111lll1_l1_ = l1l1l1_l1_ (u"ࠩࡄ࡚࠿ࠦࠧ椐")+l1ll11l1lll_l1_(32)+l1l1l1_l1_ (u"ࠪ࠱ࡊࡸࡲࡰࡴࡶࠫ椑")
	import l1lll11ll1ll_l1_
	succeeded = l1lll11ll1ll_l1_.l11l1ll1111_l1_(l111111lll1_l1_,message,True,l1l1l1_l1_ (u"ࠫࠬ椒"),l1l1l1_l1_ (u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ椓"),l1lll1111l11_l1_)
	if succeeded and l1lll1111l11_l1_:
		l111l11ll11l_l1_.append(l111l1l1l11l_l1_)
		WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ椔"),l1l1l1_l1_ (u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ椕"),l111l11ll11l_l1_,PERMANENT_CACHE)
	return
def l1l1ll11ll11_l1_(l11l1l111lll_l1_):
	l1l1ll11lll_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ椖"))
	#l11l1l111lll_l1_ = l11l1l111lll_l1_.encode(l1l1l1_l1_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ椗")).replace(l1l1l1_l1_ (u"ࠪࡠࡳ࠭椘"),l1l1l1_l1_ (u"ࠫࠬ椙"))
	user = l1ll11l1lll_l1_(32)
	import hashlib
	md5 = hashlib.md5((l1l1l1_l1_ (u"ࠬ࡞࠱࠺ࠩ椚")+l11l1l111lll_l1_+l1l1l1_l1_ (u"࠭࠱࠹࠿ࠪ椛")+user).encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ検"))).hexdigest()[0:32]
	if md5 in l1l1ll11lll_l1_: return True
	return False
def WRITE_THIS(l1l11l1ll1_l1_,data):
	if kodi_version>18.99: data = data.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭椝"))
	if l1l11l1ll1_l1_==l1l1l1_l1_ (u"ࠩࠪ椞"): filename = l1l1l1_l1_ (u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰ࡧࡥࡹ࠭椟")
	else: filename = l1l1l1_l1_ (u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ椠")+str(now)+l1l1l1_l1_ (u"ࠬ࠴ࡤࡢࡶࠪ椡")
	open(filename,l1l1l1_l1_ (u"࠭ࡷࡣࠩ椢")).write(data)
	return
def l1ll11ll1ll1_l1_():
	l11ll1ll111l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱࡭ࡳ࡬࡯ࡴ࠰ࡳࡩࡷ࡯࡯ࡥࠩ椣"))
	if l11ll1ll111l_l1_:
		l1ll11l1l111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭椤"),l1l1l1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ椥"),l1l1l1_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭椦"))
		if l1ll11l1l111_l1_: return l1ll11l1l111_l1_
	l1l1lll1l11_l1_ = l1ll11l1lll_l1_(32)
	payload = {l1l1l1_l1_ (u"ࠫࡺࡹࡥࡳࠩ椧"):l1l1lll1l11_l1_}
	url = WEBSITES[l1l1l1_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ椨")][5]
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ椩"),url,payload,l1l1l1_l1_ (u"ࠧࠨ椪"),l1l1l1_l1_ (u"ࠨࠩ椫"),l1l1l1_l1_ (u"ࠩࠪ椬"),l1l1l1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨ椭"))
	if not response.succeeded: return []
	l1l1111111l1_l1_ = response.content
	l1l1111111l1_l1_ = l1l1111111l1_l1_.replace(l1l1l1_l1_ (u"ࠫࡡࡢࡲࠨ椮"),l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ椯")).replace(l1l1l1_l1_ (u"࠭࡜࡝ࡰࠪ椰"),l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ椱")).replace(l1l1l1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭椲"),l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ椳")).replace(l1l1l1_l1_ (u"ࠪࡠࡷ࠭椴"),l1l1l1_l1_ (u"ࠫࡡࡴࠧ椵")).replace(l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ椶"),l1l1l1_l1_ (u"࠭࡜࡯ࠩ椷"))
	l1l1111111l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡀ࠺ࠩ࡞ࡧ࠯࠮ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯ࡇࡑࡈ࠿ࡀࡅࡏࡆࠪ椸"),l1l1111111l1_l1_,re.DOTALL)
	if not l1l1111111l1_l1_: return []
	l1l1111111l1_l1_ = sorted(l1l1111111l1_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1llllllll_l1_,l1l1lll1l1l1_l1_,answer,l1l1l111llll_l1_,reason = l1l1111111l1_l1_[0]
	if l1l1l1_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭椹") not in reason: l11l11111l1l_l1_,l11l11111ll1_l1_,l11l11111lll_l1_ = reason,reason,reason
	else: l11l11111l1l_l1_,l11l11111ll1_l1_,l11l11111lll_l1_ = reason.split(l1l1l1_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ椺"),2)
	settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ椻"),l1l1lll1l1l1_l1_)
	#settings.setSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠴࡬ࡰࡰࡪࠫ椼"),l11l11111l1l_l1_)
	settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡫ࡱࡪࡴࡹ࠮ࡱࡧࡵ࡭ࡴࡪ࠮࡭ࡱࡱ࡫ࠬ椽"),l1l1l1_l1_ (u"࠭ࠧ椾"))
	settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ椿"),l1l1l1_l1_ (u"ࠨࠩ楀"))
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ楁"),l1l1l1_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭楂"),l1l1111111l1_l1_,REGULAR_CACHE)
	return l1l1111111l1_l1_
def SPLIT_BIGLIST(l11lll1ll1l1_l1_,splits_count):
	length = len(l11lll1ll1l1_l1_)
	l11llll1ll1l_l1_ = []
	for ii in range(1,splits_count+1):
		if ii!=splits_count:
			l11ll1ll1lll_l1_ = l11lll1ll1l1_l1_[0:int(length/splits_count)]
			del l11lll1ll1l1_l1_[0:int(length/splits_count)]
		else:
			l11ll1ll1lll_l1_ = l11lll1ll1l1_l1_
			del l11lll1ll1l1_l1_
		l11llll1ll1l_l1_.append(l11ll1ll1lll_l1_)
		del l11ll1ll1lll_l1_
	return l11llll1ll1l_l1_
def l11ll1l11l11_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l1l1l1_l1_ (u"ࠫࡩࡻ࡭࡮ࡻࡱࡥࡲ࡫ࠧ楃"),data)
	#text = pickle.dumps(dummy)
	if 1 or l1l1l1_l1_ (u"ࠬࡏࡐࡕࡘࡢࠫ楄") not in filename or l1l1l1_l1_ (u"࠭ࡍ࠴ࡗࡢࠫ楅") not in filename: text = str(data)
	else:
		l1lllll11l1l_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l1l1_l1_ (u"ࠧࠨ楆")
		for split in l1lllll11l1l_l1_:
			text += str(split)+l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ楇")
		text = text.strip(l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ楈"))
	compressed = zlib.compress(text)
	open(filepath,l1l1l1_l1_ (u"ࠪࡻࡧ࠭楉")).write(compressed)
	return
def l11llll111l1_l1_(results_type,filename):
	if results_type==l1l1l1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ楊"): data = {}
	elif results_type==l1l1l1_l1_ (u"ࠬࡲࡩࡴࡶࠪ楋"): data = []
	elif results_type==l1l1l1_l1_ (u"࠭ࡳࡵࡴࠪ楌"): data = l1l1l1_l1_ (u"ࠧࠨ楍")
	elif results_type==l1l1l1_l1_ (u"ࠨ࡫ࡱࡸࠬ楎"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	compressed = open(filepath,l1l1l1_l1_ (u"ࠩࡵࡦࠬ楏")).read()
	text = zlib.decompress(compressed)
	#open(l1l1l1_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡊࡒࡗ࡚࠶࠴ࡴࡹࡶࠪ楐"),l1l1l1_l1_ (u"ࠫࡼࡨࠧ楑")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l1l1l1_l1_ (u"ࠬࡪࡵ࡮࡯ࡼࡲࡦࡳࡥࠨ楒"))
	#if l1l1l1_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ楓") not in text: data = EVAL(l1l1l1_l1_ (u"ࠧࡴࡶࡵࠫ楔"),text)
	if l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ楕") not in text: data = eval(text)
	else:
		l1lllll11l1l_l1_ = text.split(l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ楖"))
		del text
		data = []
		l11lll11l11l_l1_ = l11l1l1111l_l1_()
		id = 0
		for split in l1lllll11l1l_l1_:
			#data += EVAL(l1l1l1_l1_ (u"ࠪࡷࡹࡸࠧ楗"),split)
			l11lll11l11l_l1_.l11ll1ll1l11_l1_(str(id),eval,split)
			id += 1
		del l1lllll11l1l_l1_
		l11lll11l11l_l1_.l111llllll1l_l1_()
		l11lll11l11l_l1_.l111l1l1l111_l1_()
		l111l1lll111_l1_ = list(l11lll11l11l_l1_.l11l1ll1llll_l1_.keys())
		l111ll11ll11_l1_ = sorted(l111l1lll111_l1_,reverse=False,key=lambda key: int(key))
		for id in l111ll11ll11_l1_:
			data += l11lll11l11l_l1_.l11l1ll1llll_l1_[id]
	return data
def l1l1llll1l1_l1_(addon_id):
	l11lll1lll11_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ楘"),addon_id,l1l1l1_l1_ (u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ楙"))
	try: l11l1l11l1ll_l1_ = open(l11lll1lll11_l1_,l1l1l1_l1_ (u"࠭ࡲࡣࠩ楚")).read()
	except:
		l11l111lll11_l1_ = os.path.join(l11l1ll1l11l_l1_,l1l1l1_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ楛"),addon_id,l1l1l1_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ楜"))
		try: l11l1l11l1ll_l1_ = open(l11l111lll11_l1_,l1l1l1_l1_ (u"ࠩࡵࡦࠬ楝")).read()
		except: return l1l1l1_l1_ (u"ࠪࠫ楞"),[]
	if kodi_version>18.99: l11l1l11l1ll_l1_ = l11l1l11l1ll_l1_.decode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ楟"))
	version = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩ楠"),l11l1l11l1ll_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l1l1_l1_ (u"࠭ࠧ楡"),[]
	l1l1111111ll_l1_,l11l1llll11l_l1_ = version[0],l111l1l111l1_l1_(version[0])
	return l1l1111111ll_l1_,l11l1llll11l_l1_
def l1l1lllll1l_l1_():
	l1l1lll11ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ楢"),l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ楣"),l1l1l1_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ楤"))
	if l1l1lll11ll_l1_: return l1l1lll11ll_l1_
	l11l1l1l1l_l1_,l1l1lll11ll_l1_ = {},{}
	l1llll11l1l1_l1_ = [WEBSITES[l1l1l1_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ楥")][1]]
	if kodi_version>17.99: l1llll11l1l1_l1_.append(WEBSITES[l1l1l1_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ楦")][2])
	if kodi_version>18.99: l1llll11l1l1_l1_.append(WEBSITES[l1l1l1_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ楧")][3])
	for l111ll1ll111_l1_ in l1llll11l1l1_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ楨"),l111ll1ll111_l1_,l1l1l1_l1_ (u"ࠧࠨ楩"),l1l1l1_l1_ (u"ࠨࠩ楪"),l1l1l1_l1_ (u"ࠩࠪ楫"),False,l1l1l1_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ楬"))
		if response.succeeded:
			html = response.content
			l111l1l1lll1_l1_ = l111ll1ll111_l1_.rsplit(l1l1l1_l1_ (u"ࠫ࠴࠭業"),1)[0]
			l11ll1111ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭楮"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l11ll1l11111_l1_ in l11ll1111ll1_l1_:
				l11ll1ll11l1_l1_ = l111l1l1lll1_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ楯")+addon_id+l1l1l1_l1_ (u"ࠧ࠰ࠩ楰")+addon_id+l1l1l1_l1_ (u"ࠨ࠯ࠪ楱")+l11ll1l11111_l1_+l1l1l1_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ楲")
				if addon_id not in list(l11l1l1l1l_l1_.keys()):
					l11l1l1l1l_l1_[addon_id] = []
					l1l1lll11ll_l1_[addon_id] = []
				l11l1ll111ll_l1_ = l111l1l111l1_l1_(l11ll1l11111_l1_)
				l11l1l1l1l_l1_[addon_id].append((l11ll1l11111_l1_,l11l1ll111ll_l1_,l11ll1ll11l1_l1_))
	for addon_id in list(l11l1l1l1l_l1_.keys()):
		#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ楳"),str(addon_id)+l1l1l1_l1_ (u"ࠫࠥࠦ࠮ࠡࠢࠪ楴")+str(l11l1l1l1l_l1_[addon_id]))
		l1l1lll11ll_l1_[addon_id] = sorted(l11l1l1l1l_l1_[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ極"),l1l1l1_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ楶"),l1l1lll11ll_l1_,REGULAR_CACHE)
	return l1l1lll11ll_l1_
	l1l1l1_l1_ (u"ࠢࠣࠤࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ࠮ࠓࠊࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡯ࡥࡧࡥࡩࡷ࡭࠮ࡰࡴࡪ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡥࡶࡦࡴࡣࡩ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡦࡣ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡨࡲࡢࡰࡦ࡬࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷࡩࡪ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠶࠴ࡸࡡࡸ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࠧࠨࠢ楷")
def l111l1l111l1_l1_(l11ll1l11111_l1_):
	l11l1ll111ll_l1_ = []
	l1lllll11ll_l1_ = l11ll1l11111_l1_.split(l1l1l1_l1_ (u"ࠨ࠰ࠪ楸"))
	for l1ll1l1ll1_l1_ in l1lllll11ll_l1_:
		parts = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࡨ࠰ࢂ࡛࡝࠭࡟࠱ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠭楹"),l1ll1l1ll1_l1_,re.DOTALL)
		l1l11llll11l_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l11llll11l_l1_.append(part)
		l11l1ll111ll_l1_.append(l1l11llll11l_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ楺"),str(l11ll1l11111_l1_)+l1l1l1_l1_ (u"ࠫࠥࠦ࠮ࠡࠢࠪ楻")+str(l11l1ll111ll_l1_))
	return l11l1ll111ll_l1_
def l11l1111lll1_l1_(l11l1ll111ll_l1_):
	l11ll1l11111_l1_ = l1l1l1_l1_ (u"ࠬ࠭楼")
	for l1ll1l1ll1_l1_ in l11l1ll111ll_l1_:
		for part in l1ll1l1ll1_l1_: l11ll1l11111_l1_ += str(part)
		l11ll1l11111_l1_ += l1l1l1_l1_ (u"࠭࠮ࠨ楽")
	l11ll1l11111_l1_ = l11ll1l11111_l1_.strip(l1l1l1_l1_ (u"ࠧ࠯ࠩ楾"))
	#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ楿"),str(l11l1ll111ll_l1_)+l1l1l1_l1_ (u"ࠩࠣࠤ࠳ࠦࠠࠨ榀")+str(l11ll1l11111_l1_))
	return l11ll1l11111_l1_
def l1l1lll1lll1_l1_(l1l1ll1ll11_l1_=l1ll11l1111l_l1_):
	# l111ll1llll1_l1_ not l11lll1l1ll1_l1_ l111llllll11_l1_ l111ll11llll_l1_ l11l1l1l1l_l1_ status l11l111lll_l1_ l1l1l1l111_l1_ l1l1111l11_l1_ l11ll1l1ll1l_l1_
	#l1lll111l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ榁"),l1l1l1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ概"),l1l1l1_l1_ (u"ࠬࡋࡍࡂࡆࡢࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ榃"))
	#if l1lll111l1l1_l1_: return l1lll111l1l1_l1_
	l1lll111l1l1_l1_ = {}
	l11l1l1l1l_l1_ = l1l1lllll1l_l1_()
	l1ll11l1l11l_l1_ = l1l1l1ll11ll_l1_(l1l1ll1ll11_l1_)
	for addon_id in l1l1ll1ll11_l1_:
		if addon_id not in list(l11l1l1l1l_l1_.keys()): continue
		#if not l11l1l1l1l_l1_[addon_id]: continue
		l1l1lll11ll_l1_ = l11l1l1l1l_l1_[addon_id]
		l1l1llll1ll_l1_,l1l1lllll11_l1_,l1l1lllllll_l1_ = l1l1lll11ll_l1_[0]
		#l1l1l1llll1_l1_ = xbmc.getInfoLabel(l1l1l1_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭榄")+addon_id+l1l1l1_l1_ (u"ࠧࠪࠩ榅"))
		l1l1l1llll1_l1_,l1l1ll1l11l_l1_ = l1l1llll1l1_l1_(addon_id)
		l1ll11l11l1l_l1_,l1ll1l111l11_l1_ = l1ll11l1l11l_l1_[addon_id]
		l1l1ll1l1ll_l1_ = l1l1lllll11_l1_>l1l1ll1l11l_l1_ and l1ll11l11l1l_l1_
		l1l1ll11ll1_l1_ = True
		if not l1ll11l11l1l_l1_: l1ll1l1ll111_l1_ = l1l1l1_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ榆")
		elif not l1ll1l111l11_l1_: l1ll1l1ll111_l1_ = l1l1l1_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ榇")
		elif l1l1ll1l1ll_l1_: l1ll1l1ll111_l1_ = l1l1l1_l1_ (u"ࠪࡳࡱࡪࠧ榈")
		else:
			l1ll1l1ll111_l1_ = l1l1l1_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ榉")
			l1l1ll11ll1_l1_ = False
		l1lll111l1l1_l1_[addon_id] = (l1l1ll11ll1_l1_,l1l1l1llll1_l1_,l1l1ll1l11l_l1_,l1l1llll1ll_l1_,l1l1lllll11_l1_,l1ll1l1ll111_l1_,l1l1lllllll_l1_)
	#WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ榊"),l1l1l1_l1_ (u"࠭ࡅࡎࡃࡇࡣࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬ榋"),l1lll111l1l1_l1_,REGULAR_CACHE)
	return l1lll111l1l1_l1_
	l1l1l1_l1_ (u"ࠢࠣࠤࠐࠎࠎࠩࡩࡧࠢࡹࡩࡷࡹࡩࡰࡰ࠽ࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵ࠰࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠲ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡃࠠࡷࡧࡵࡷ࡮ࡵ࡮࠭ࡖࡵࡹࡪ࠲ࡔࡳࡷࡨࠑࠏࠏࠣࡦ࡮ࡶࡩ࠿ࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷ࠲ࡩࡴࡡࡨࡼ࡮ࡹࡴ࠭࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠ࠾ࠢࠪࠫ࠱ࡌࡡ࡭ࡵࡨ࠰ࡋࡧ࡬ࡴࡧࠐࠎࠎࠩࡩࡴࡡࡨࡼ࡮ࡹࡴࠡ࠿ࠣࠬࡽࡨ࡭ࡤ࠰ࡪࡩࡹࡉ࡯࡯ࡦ࡙࡭ࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠮ࠧࡔࡻࡶࡸࡪࡳ࠮ࡉࡣࡶࡅࡩࡪ࡯࡯ࠪࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠪࠩࠬࡁࡂ࠷ࠩࠎࠌࠌࠧ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶࡃ࠭ࠧࠎࠌࠌࠧ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡄ࠱࠹࠰࠼࠽࠿ࠦࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠣࡁࠥ࠮ࡸࡣ࡯ࡦ࠲࡬࡫ࡴࡄࡱࡱࡨ࡛࡯ࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠩࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡊࡵࡈࡲࡦࡨ࡬ࡦࡦࠫࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠫࠪ࠭ࡂࡃ࠱ࠪࠏࠍࠍࠨ࡫࡬ࡴࡧ࠽ࠤ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࡲࡴࡺࠠࠩ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡢࡰࡧࠤࡳࡵࡴࠡ࡫ࡶࡣࡪࡾࡩࡴࡶࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡪ࡬࡫࡭࡫ࡳࡵࡡࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠌࠍࠬ࠱ࡳࡵࡴࠫ࡬࡮࡭ࡨࡦࡵࡷࡣࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫࡟ࡷࡧࡵࡣࡨࡵ࡭ࡱࡣࡵࡩ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲࡠࡥࡲࡱࡵࡧࡲࡦࠋࠌࠫ࠰ࡹࡴࡳࠪ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠎࠏࠧࠬࡵࡷࡶ࠭࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧࠍࠎࠏࠧࠬࡵࡷࡶ࠭࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡴࡲࡤࠊࠩ࠮ࡷࡹࡸࠨࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥ࡯࡭ࡦࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭࡮ࡦࡧࡧࡣࡺࡶࡤࡢࡶࡨࠍࠎ࠭ࠫࡴࡶࡵࠬࡳ࡫ࡥࡥࡡࡸࡴࡩࡧࡴࡦࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡵࡷࡥࡹࡻࡳࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡸࡺࡡࡵࡷࡶ࠭࠮ࠓࠊࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡸࡨࡶࡸ࡯࡯࡯ࡵ࠽ࠤࠥ࠭ࠫࡴࡶࡵࠬࡦࡪࡤࡰࡰࡢ࡭ࡩ࠯ࠫࠨࠢࠣࠫ࠰ࡹࡴࡳࠪ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳࠫ࠮ࠫࠥࠦࠧࠬࡵࡷࡶ࠭࡯ࡳࡠࡧࡻ࡭ࡸࡺࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠩࠪࠏࠍࠍࠧࠨࠢ榌")
def PROGRESS_UPDATE(pDialog,l11l1lll1l1l_l1_,l11ll1lll1ll_l1_=l1l1l1_l1_ (u"ࠨࠩ榍"),line2=l1l1l1_l1_ (u"ࠩࠪ榎"),l11ll1llll11_l1_=l1l1l1_l1_ (u"ࠪࠫ榏")):
	if kodi_version<19: pDialog.update(l11l1lll1l1l_l1_,l11ll1lll1ll_l1_,line2,l11ll1llll11_l1_)
	else: pDialog.update(l11l1lll1l1l_l1_,l11ll1lll1ll_l1_+l1l1l1_l1_ (u"ࠫࡡࡴࠧ榐")+line2+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ榑")+l11ll1llll11_l1_)
	return
def l1lllll1111l_l1_(l111111llll_l1_):
	# l11lll1l1ll1_l1_ it for this:  function(p,a,c,k,e,d)
	# l1lll1llll1l_l1_ l111lll11l11_l1_:  l1ll1lll_l1_://l11l11l1llll_l1_.io
	def l11l1l11l1l1_l1_(num,b,l111llll1111_l1_=l1l1l1_l1_ (u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨ榒")):
		return ((num == 0) and l111llll1111_l1_[0]) or (l11l1l11l1l1_l1_(num // b, b, l111llll1111_l1_).lstrip(l111llll1111_l1_[0]) + l111llll1111_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l1l1_l1_ (u"ࠢ࡝࡞ࡥࠦ榓") + l11l1l11l1l1_l1_(c, a) + l1l1l1_l1_ (u"ࠣ࡞࡟ࡦࠧ榔"),  k[c], p)
		return p
	l111111llll_l1_ = l111111llll_l1_.split(l1l1l1_l1_ (u"ࠩࢀࠬࠬ榕"))[1][:-1]
	l1llll1l1l11_l1_ = eval(l1l1l1_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠫࠫ榖")+l111111llll_l1_,{l1l1l1_l1_ (u"ࠫࡧࡧࡳࡦࡐࠪ榗"):l11l1l11l1l1_l1_,l1l1l1_l1_ (u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬ榘"):unpack})   #,locals())
	return l1llll1l1l11_l1_
def l1lll1l111_l1_(url,l11l11l11lll_l1_=l1l1l1_l1_ (u"࠭ࠧ榙")):
	if l11l11l11lll_l1_==l1l1l1_l1_ (u"ࠧ࡭ࡱࡺࡩࡷ࠭榚"): url = re.sub(l1l1l1_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨ榛"),lambda l11lllll1ll1_l1_: l11lllll1ll1_l1_.group(0).lower(),url)
	elif l11l11l11lll_l1_==l1l1l1_l1_ (u"ࠩࡸࡴࡵ࡫ࡲࠨ榜"): url = re.sub(l1l1l1_l1_ (u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪ榝"),lambda l11lllll1ll1_l1_: l11lllll1ll1_l1_.group(0).upper(),url)
	return url
def l1l1l1ll11ll_l1_(l1l1ll1ll11_l1_):
	installed,l11l1ll1l1l1_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1ll11l111l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l1l1ll1ll11_l1_)==1: l11l11llllll_l1_ = l1l1l1_l1_ (u"ࠫ࠭ࠨࠧ榞")+l1l1ll1ll11_l1_[0]+l1l1l1_l1_ (u"ࠬࠨࠩࠨ榟")
	else: l11l11llllll_l1_ = str(tuple(l1l1ll1ll11_l1_))
	cc.execute(l1l1l1_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭榠")+l11l11llllll_l1_+l1l1l1_l1_ (u"ࠧࠡ࠽ࠪ榡"))
	rows = cc.fetchall()
	l1ll11l1l11l_l1_ = {}
	for addon_id in l1l1ll1ll11_l1_: l1ll11l1l11l_l1_[addon_id] = (False,False)
	for addon_id,l11l1ll1l1l1_l1_ in rows:
		installed = True
		l11l1ll1l1l1_l1_ = l11l1ll1l1l1_l1_==1
		l1ll11l1l11l_l1_[addon_id] = (installed,l11l1ll1l1l1_l1_)
	conn.close()
	return l1ll11l1l11l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	if file==l1ll111111l_l1_: results = []
	else: results = {}
	if os.path.exists(file):
		oldFILE = open(file,l1l1l1_l1_ (u"ࠨࡴࡥࠫ榢")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ榣"))
		if file==l1ll111111l_l1_: results = EVAL(l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ榤"),oldFILE)
		else:
			l11l1lllllll_l1_ = EVAL(l1l1l1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ榥"),oldFILE)
			if l11l1lllllll_l1_:
				for key in l11l1lllllll_l1_.keys():
					results[key] = []
					for l11l1l1l1ll1_l1_ in l11l1lllllll_l1_[key]:
						type,name,url,mode,image,page,text,context,infodict = l1l1l1_l1_ (u"ࠬ࠭榦"),l1l1l1_l1_ (u"࠭ࠧ榧"),l1l1l1_l1_ (u"ࠧࠨ榨"),l1l1l1_l1_ (u"ࠨࠩ榩"),l1l1l1_l1_ (u"ࠩࠪ榪"),l1l1l1_l1_ (u"ࠪࠫ榫"),l1l1l1_l1_ (u"ࠫࠬ榬"),l1l1l1_l1_ (u"ࠬ࠭榭"),l1l1l1_l1_ (u"࠭ࠧ榮")
						type = l11l1l1l1ll1_l1_[0]
						name = l11l1l1l1ll1_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l11l1l1l1ll1_l1_[2]
						mode = l11l1l1l1ll1_l1_[3]
						image = l11l1l1l1ll1_l1_[4]
						page = l11l1l1l1ll1_l1_[5]
						if len(l11l1l1l1ll1_l1_)>6: text = l11l1l1l1ll1_l1_[6]
						if len(l11l1l1l1ll1_l1_)>7: context = l11l1l1l1ll1_l1_[7]
						if len(l11l1l1l1ll1_l1_)>8: infodict = l11l1l1l1ll1_l1_[8]
						if file==favoritesfile: l111l1ll11ll_l1_ = type,name,url,mode,image,page,text,l1l1l1_l1_ (u"ࠧࠨ榯"),infodict
						else: l111l1ll11ll_l1_ = type,name,url,mode,image,page,text,context,infodict
						results[key].append(l111l1ll11ll_l1_)
		newFILE = str(results)
		if kodi_version>18.99: newFILE = newFILE.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭榰"))
		open(file,l1l1l1_l1_ (u"ࠩࡺࡦࠬ榱")).write(newFILE)
	return results
def l1lll11ll11_l1_(site):
	l1lll1l111l_l1_ = site.split(l1l1l1_l1_ (u"ࠪ࠱ࠬ榲"),1)[0]
	l1lll1l1111_l1_,l1lll1l1ll1_l1_,l1llll1ll11_l1_ = l1l1l1_l1_ (u"ࠫࠬ榳"),l1l1l1_l1_ (u"ࠬ࠭榴"),l1l1l1_l1_ (u"࠭ࠧ榵")
	if   l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭榶")		:	from l1l11ll_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ榷")	:	from l1l1llll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ榸")		:	from l11ll1l_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ榹")	:	from l11l111l_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭榺")	:	from l1ll1ll1l_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ榻")	: 	from l1ll111ll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ榼")	:	from l1ll111l1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ榽")	:	from l11lllll1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ榾")		:	from l111ll1ll_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ榿")	:	from l111l111l_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ槀")	:	from l1llll1lll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭槁")	:	from l1lll1llll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ槂")	:	from l1lll1l1l1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ槃"):	from l1l11llll111_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭槄")		:	from l1llll1lll1_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ槅")		:	from l1lll1l_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ槆")	:	from l1lllllll11_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ槇")	:	from l1lllll111_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ槈")	:	from l1l11lll1111_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭槉")	:	from l111l11l1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭槊")	:	from l1ll11ll1l1_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ構")	:	from l111l11ll_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ槌")		:	from l1l11l1ll1ll_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ槍")	:	from l1ll1l1ll11_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ槎")	:	from l1l111llll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ槏")	:	from l1lll1l11l_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ槐"):	from l1ll111l1l_l1_	import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ槑")	:	from l11l1lll1l_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ槒")	:	from l111l11ll1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ槓")	:	from l111l11l1l_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ槔")	:	from l1llllll1l1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ槕")	:	from l1lll111lll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭槖")	:	from l1lllll1ll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ槗")		:	from l1lll111ll1_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ様")		:	from IPTV			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡎ࠵ࡘࠫ槙")		:	from l1ll111ll11_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ槚")	:	from l1ll1l1lll1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ槛")	:	from l1ll11l11ll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ槜")	:	from l1l1l11l11l_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ槝")	:	from l1l1l111lll_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ槞")	:	from l1llll11l111_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ槟")	:	from l1lllll1lll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ槠")	:	from l1lllll1111_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ槡")		:	from l1l1l111ll1_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ槢")	:	from l1llll1111l1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭槣")	:	from l1l11lll11ll_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭槤")	:	from l1l11ll11l1l_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ槥")	:	from l1lll1l11ll1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ槦")		:	from l111l1111l1_l1_			import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ槧")	:	from l11lll111l1_l1_		import MENU as l1lll1l1111_l1_,SEARCH as l1lll1l1ll1_l1_,menu_name as l1llll1ll11_l1_
	elif l1lll1l111l_l1_==l1l1l1_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ槨"):	from l1l111111ll1_l1_	import MENU as l1lll1l1111_l1_
	return l1lll1l1111_l1_,l1lll1l1ll1_l1_,l1llll1ll11_l1_
def DOWNLOAD_USING_PROGRESSBAR(l111l11l1lll_l1_,headers={}):
	#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࠪ槩"),l1l1l1_l1_ (u"ࠪࠫ槪"),l1l1l1_l1_ (u"ࠫࠬ槫"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ槬"),l1l1l1_l1_ (u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฼๊่ษ่๊ࠢࠥอไฦ่อี๋ะ้ࠠไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠡࠨ槭"))
	#if yes!=1: return
	LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ槮"),l1l1l1_l1_ (u"ࠨ࠰ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧ槯")+l111l11l1lll_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ槰")+str(headers)+l1l1l1_l1_ (u"ࠪࠤࡢ࠭槱"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ槲"),l1l1l1_l1_ (u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧ槳"))
	MegaByte = 1024*1024
	l111ll111l1l_l1_ = bytes()
	chunk_size = 1*MegaByte
	import requests
	headers2 = headers
	headers2[l1l1l1_l1_ (u"࠭ࡒࡢࡰࡪࡩࠬ槴")] = l1l1l1_l1_ (u"ࠧࡣࡻࡷࡩࡸࡃ࠰࠮ࠩ槵")
	response = requests.get(l111l11l1lll_l1_,stream=True,headers=headers2,timeout=120)
	if l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ槶") not in list(response.headers.keys()):
		DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ槷"),l1l1l1_l1_ (u"ࠪࠫ槸"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ槹"),l1l1l1_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨ槺"))
		return
	filesize = int(response.headers[l1l1l1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ槻")])
	l1l1ll1111_l1_ = str(int(1000*filesize/MegaByte)/1000.0)
	l1l11lll1l_l1_ = int(filesize/chunk_size)+1
	if l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧ槼") in list(response.headers.keys()) and filesize>MegaByte:
		l11l11ll1ll1_l1_ = True
		l1lllll11ll_l1_ = []
		l1llll1llll_l1_ = 10
		l1lllll11ll_l1_.append(str(0*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠨ࠯ࠪ槽")+str(1*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(1*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠩ࠰ࠫ槾")+str(2*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(2*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠪ࠱ࠬ槿")+str(3*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(3*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠫ࠲࠭樀")+str(4*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(4*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠬ࠳ࠧ樁")+str(5*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(5*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"࠭࠭ࠨ樂")+str(6*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(6*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠧ࠮ࠩ樃")+str(7*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(7*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠨ࠯ࠪ樄")+str(8*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(8*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠩ࠰ࠫ樅")+str(9*filesize//l1llll1llll_l1_-1))
		l1lllll11ll_l1_.append(str(9*filesize//l1llll1llll_l1_)+l1l1l1_l1_ (u"ࠪ࠱ࠬ樆"))
		l11llll11ll1_l1_ = float(l1l11lll1l_l1_)/l1llll1llll_l1_
		l11l1ll11111_l1_ = l11llll11ll1_l1_/int(1+l11llll11ll1_l1_)
	else:
		l11l11ll1ll1_l1_ = False
		l1llll1llll_l1_ = 1
		l11l1ll11111_l1_ = 1
	response.close()
	LOG_THIS(l1l1l1_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ樇"),l1l1l1_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡩࡴࡪࡱࡱࡷ࠿࡛ࠦࠡࠩ樈")+str(l11l11ll1ll1_l1_)+l1l1l1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ樉")+str(filesize)+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ樊"))
	ii = 0
	#t1 = time.time()-30
	for jj in range(l1llll1llll_l1_):
		headers2 = headers
		if l11l11ll1ll1_l1_: headers2[l1l1l1_l1_ (u"ࠨࡔࡤࡲ࡬࡫ࠧ樋")] = l1l1l1_l1_ (u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩ樌")+l1lllll11ll_l1_[jj]
		response = requests.get(l111l11l1lll_l1_,stream=True,headers=headers2,timeout=120)
		for chunk in response.iter_content(chunk_size=chunk_size):
			if pDialog.iscanceled():
				response.close()
				LOG_THIS(l1l1l1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ樍"),l1l1l1_l1_ (u"ࠫ࠳ࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬ樎"))
				break
			ii += l11l1ll11111_l1_
			PROGRESS_UPDATE(pDialog,0+int(100*ii/l1l11lll1l_l1_),l1l1l1_l1_ (u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭樏"),str(int(ii*chunk_size//MegaByte))+l1l1l1_l1_ (u"࠭ࠠ࠰ࠢࠪ樐")+l1l1ll1111_l1_+l1l1l1_l1_ (u"ࠧࠡࡏࡅࠫ樑"))
			l111ll111l1l_l1_ += chunk
			#PROGRESS_UPDATE(pDialog,0+int(35*ii/l1l11lll1l_l1_),l1l1l1_l1_ (u"ࠨฮ็ฬࠥอไๆๆไࠤฬ๊ัว์ึ๎࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ樒")+l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ樓")+str(ii*chunksize/MegaByte)+l1l1l1_l1_ (u"ࠪࠤ࠴ࠦࠧ樔")+l1l1ll1111_l1_+l1l1l1_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ樕")+time.strftime(l1l1l1_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ樖")+l1l1l1_l1_ (u"࠭࡜࡯ࠩ樗")+time.gmtime(l1l11l1lll_l1_))+l1l1l1_l1_ (u"ࠧࠡโࠪ樘"))
			#t2 = time.time()
			#l1l11l111l_l1_ = t2-t1
			#l1l11l1l11_l1_ = l1l11l111l_l1_/ii
			#l1l1l11ll1_l1_ = l1l11l1l11_l1_*(l1l11lll1l_l1_+1)
			#l1l11l1lll_l1_ = l1l1l11ll1_l1_-l1l11l111l_l1_
		response.close()
	pDialog.close()
	if len(l111ll111l1l_l1_)<filesize:
		LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ標"),l1l1l1_l1_ (u"ࠩ࠱ࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭樚")+str(len(l111ll111l1l_l1_)//MegaByte)+l1l1l1_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋࡸ࡯࡮ࠢࡷࡳࡹࡧ࡬ࠡࡱࡩ࠾ࠥࡡࠠࠨ樛")+l1l1ll1111_l1_+l1l1l1_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠪ樜"))
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠬ࠭樝"),l1l1l1_l1_ (u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫ樞"),l1l1l1_l1_ (u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧ樟"),l1l1l1_l1_ (u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪ樠"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ模"),l1l1l1_l1_ (u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧ樢")+str(len(l111ll111l1l_l1_)//MegaByte)+l1l1l1_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪ樣")+l1l1ll1111_l1_+l1l1l1_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧ樤"))
		if choice==2: l111ll111l1l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l111l11l1lll_l1_,headers)
		elif choice==1: LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭樥"),l1l1l1_l1_ (u"ࠧ࠯ࠢࠣࠤࡓࡵࡴࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡤࡧࡨ࡫ࡰࡵࡧࡧࠤࡦࡴࡤࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡸࡷࡪࡪࠧ樦"))
		else: return
		if not l111ll111l1l_l1_: return
	else: LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ樧"),l1l1l1_l1_ (u"ࠩ࠱ࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧ樨")+l1l1ll1111_l1_+l1l1l1_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠩ権"))
	return l111ll111l1l_l1_
def SEND_ANALYTICS_EVENT(script_name,allow_dns_fix=True,allow_proxy_fix=True):
	# old l11l1ll1l1ll_l1_ l11l11l1l111_l1_ l1llll1l1ll1_l1_
	#l111l1l1ll11_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠶ࠬࡴࡪࡦࡀ࡙ࡆ࠳࠱࠳࠹࠳࠸࠺࠷࠰࠵࠯࠸ࠪࡨ࡯ࡤ࠾ࠩ横")+l1ll11l1lll_l1_(32)+l1l1l1_l1_ (u"ࠬࠬࡴ࠾ࡧࡹࡩࡳࡺࠦࡴࡥࡀࡩࡳࡪࠦࡦࡥࡀࠫ樫")+addon_version+l1l1l1_l1_ (u"࠭ࠦࡢࡸࡀࠫ樬")+addon_version+l1l1l1_l1_ (u"ࠧࠧࡣࡱࡁࡆࡘࡁࡃࡋࡆࡣ࡛ࡏࡄࡆࡑࡖࡣࡓࡋࡗࡄࡎࡌࡉࡓ࡚ࡉࡅࠨࡨࡥࡂ࠭樭")+script_name+l1l1l1_l1_ (u"ࠨࠨࡨࡰࡂ࠭樮")+str(kodi_version)+l1l1l1_l1_ (u"ࠩࠩࡾࡂ࠭樯")+l111l1l1ll11_l1_
	#response = OPENURL_REQUESTS(l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ樰"),url,l1l1l1_l1_ (u"ࠫࠬ樱"),l1l1l1_l1_ (u"ࠬ࠭樲"),l1l1l1_l1_ (u"࠭ࠧ樳"),False,l1l1l1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ樴"))
	# l111llll111l_l1_ test:    l1ll1lll_l1_://l1ll1l1ll1ll_l1_-l1l1l1llll11_l1_-l1l1lll11111_l1_.l1lll1ll1l1l_l1_/l11l111l1l1l_l1_/l11ll111ll1l_l1_-l111lll11lll_l1_
	# l111llll111l_l1_ json method:    l1ll1lll_l1_://l111l1l1111l_l1_.l1lll1ll1l1l_l1_.l1lll1l11_l1_/l11l11ll111l_l1_/l11l1l111l1l_l1_/l11ll1ll1ll1_l1_/protocol/l11l111l1l1l_l1_/l11l11ll1l11_l1_/l111llll111l_l1_
	# l111llll111l_l1_ json method:    l1ll1lll_l1_://l111l1l1111l_l1_.l1lll1ll1l1l_l1_.l1lll1l11_l1_/l11l11ll111l_l1_/l11l1l111l1l_l1_/l11ll1ll1ll1_l1_/protocol/l11l111l1l1l_l1_/l11l11ll1l11_l1_?l111ll11l111_l1_=l111l1lll1ll_l1_
	# l111llll111l_l1_ hit method:   l1ll1lll_l1_://l1ll1l1ll1l_l1_.l11ll11111ll_l1_.l1lll1l11_l1_/l11l111l1l1l_l1_-l11ll111llll_l1_-protocol-l11l1l1lll11_l1_
	# l111llll111l_l1_ hit method:   l1ll1lll_l1_://l1ll1l1ll1l_l1_.l11ll11111ll_l1_.l1lll1l11_l1_/l11ll111l1l_l1_-l11llll1111l_l1_-l1lll1ll1l1l_l1_-l11l11ll111l_l1_-l11ll111llll_l1_-protocol-version-2
	# l111lll1ll1l_l1_ json method
	#url = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵࡭ࡱ࠱ࡦࡳࡱࡲࡥࡤࡶࡂࡥࡵ࡯࡟ࡴࡧࡦࡶࡪࡺ࠽࠱࠯ࡹ࠵࠺ࡇࡤࡤࡔࡊࡥࡕ࡭ࡱࡳࡱࡪࡰ࠺࠿ࡋࡂࠨࡰࡩࡦࡹࡵࡳࡧࡰࡩࡳࡺ࡟ࡪࡦࡀࡋ࠲ࡘࡐ࠸ࡓ࡜ࡉࡏ࠿ࡇ࠺ࠩ樵")
	#headers = {l1l1l1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ樶"):l1l1l1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭樷")}
	#params = {l1l1l1_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦࠩ樸"):script_name,l1l1l1_l1_ (u"ࠬࡧࡶࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ樹"):addon_version,l1l1l1_l1_ (u"࠭࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ樺"):kodi_version}
	#data = {l1l1l1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺ࡟ࡪࡦࠪ樻"):l1ll11l1lll_l1_(32),l1l1l1_l1_ (u"ࠨࡧࡹࡩࡳࡺࡳࠨ樼"):[{l1l1l1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ樽"):l1l1l1_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࡢࡋࡆ࠺ࠧ樾"),l1l1l1_l1_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ樿"):params}]}
	#response = OPENURL_REQUESTS(l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ橀"),url,str(data),headers,l1l1l1_l1_ (u"࠭ࠧ橁"),False,l1l1l1_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ橂"))
	# l111lll1ll1l_l1_ hit method
	url = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵ࡧ࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠷ࠬࡴࡪࡦࡀࡋ࠲ࡘࡐ࠸ࡓ࡜ࡉࡏ࠿ࡇ࠺ࠨࡦ࡭ࡩࡃࠧ橃")+l1ll11l1lll_l1_(32)+l1l1l1_l1_ (u"ࠩࠩࡣࡸࡃ࠱ࠧࡧࡱࡁࠬ橄")+script_name+l1l1l1_l1_ (u"ࠪࠪࡺࡶ࠮ࡢࡸࡢࡺࡪࡸ࠽ࠨ橅")+addon_version+l1l1l1_l1_ (u"ࠫࠫࡻࡰ࠯࡭ࡲࡨ࡮ࡥࡶࡦࡴࡀࠫ橆")+str(kodi_version)
	response = OPENURL_REQUESTS(l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ橇"),url,l1l1l1_l1_ (u"࠭ࠧ橈"),l1l1l1_l1_ (u"ࠧࠨ橉"),l1l1l1_l1_ (u"ࠨࠩ橊"),False,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ橋"))
	return response
def l1l1l1l1ll11_l1_(l1lllll11111_l1_=l1l1l1_l1_ (u"ࠪࠫ橌")):
	l1ll1l11l11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡸࡺࡲࠨ橍"),l1l1l1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ橎"),l1l1l1_l1_ (u"࠭ࡉࡑࡎࡒࡇࡆ࡚ࡉࡐࡐࠪ橏"))
	if l1ll1l11l11l_l1_: return l1ll1l11l11l_l1_
	# url = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡰࡴࡩࡡࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ橐")
	# l1llll1l1ll1_l1_   url = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡴࡼ࡮࡯ࡪࡵ࠱ࡥࡵࡶ࠯࡫ࡵࡲࡲ࠴࠭橑")+l1lllll11111_l1_
	# l111lll1l1ll_l1_   url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ橒")
	url = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭橓")+l1lllll11111_l1_+l1l1l1_l1_ (u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ橔")
	response = OPENURL_REQUESTS(l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ橕"),url,l1l1l1_l1_ (u"࠭ࠧ橖"),l1l1l1_l1_ (u"ࠧࠨ橗"),l1l1l1_l1_ (u"ࠨࠩ橘"),False,l1l1l1_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡊࡒࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ橙"))
	html = response.content
	l11ll1lll111_l1_ = EVAL(l1l1l1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ橚"),html)
	l111lll11111_l1_,country,l11l111ll1ll_l1_,l11l1llll1l1_l1_,timezone = l1l1l1_l1_ (u"ࠫࠬ橛"),l1l1l1_l1_ (u"ࠬ࠭橜"),l1l1l1_l1_ (u"࠭ࠧ橝"),l1l1l1_l1_ (u"ࠧࠨ橞"),l1l1l1_l1_ (u"ࠨࠩ機")
	if l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ橠") in list(l11ll1lll111_l1_.keys()): l111lll11111_l1_ = l11ll1lll111_l1_[l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭橡")]
	if l1l1l1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ橢") in list(l11ll1lll111_l1_.keys()): country = l11ll1lll111_l1_[l1l1l1_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭橣")]
	if l1l1l1_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭橤") in list(l11ll1lll111_l1_.keys()): l11l111ll1ll_l1_ = l11ll1lll111_l1_[l1l1l1_l1_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ橥")]
	if l1l1l1_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭橦") in list(l11ll1lll111_l1_.keys()): l11l1llll1l1_l1_ = l11ll1lll111_l1_[l1l1l1_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ橧")]
	if l1l1l1_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ橨") in list(l11ll1lll111_l1_.keys()):
		timezone = l11ll1lll111_l1_[l1l1l1_l1_ (u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭橩")][l1l1l1_l1_ (u"ࠬࡻࡴࡤࠩ橪")]
		if timezone[0] not in [l1l1l1_l1_ (u"࠭࠭ࠨ橫"),l1l1l1_l1_ (u"ࠧࠬࠩ橬")]: timezone = l1l1l1_l1_ (u"ࠨ࠭ࠪ橭")+timezone
	l1ll1l11l11l_l1_ = l111lll11111_l1_+l1l1l1_l1_ (u"ࠩ࠯ࠫ橮")+country+l1l1l1_l1_ (u"ࠪ࠰ࠬ橯")+l11l111ll1ll_l1_+l1l1l1_l1_ (u"ࠫ࠱࠭橰")+l11l1llll1l1_l1_+l1l1l1_l1_ (u"ࠬ࠲ࠧ橱")+timezone
	if kodi_version>18.99: l1ll1l11l11l_l1_ = l1ll1l11l11l_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ橲")).decode(l1l1l1_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ橳"))
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ橴"),l1l1l1_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭橵"),l1ll1l11l11l_l1_,l1llll111_l1_)
	return l1ll1l11l11l_l1_
#=================================================================================
# the l11l1l1l11_l1_ function l111l1111ll_l1_ added from:
# l1ll1lll_l1_://l11lllll11_l1_.l1lll1l11_l1_/l11l11l11l_l1_/l11l1llll1_l1_-host-l11l11lll1_l1_/-/l11ll11lll_l1_/l11lll1111_l1_/l11l111l11_l1_/l11l11l1l1_l1_/l111l11ll1ll_l1_.py
# l1ll1lll_l1_://l11l1l111l_l1_.l1lll1l11_l1_/l11l111ll1_l1_/l11l1ll1ll_l1_-l11l1l1l1l_l1_/l11ll11lll_l1_/l11lll1111_l1_/l11l11llll_l1_.l1l1ll111l_l1_.l11llll1ll_l1_/l11ll1l111_l1_/l111l1lll1l1_l1_/l111l1ll11_l1_.py
# l11ll11l1ll1_l1_ to the l11l111l1ll1_l1_ l1l1l1_l1_ (u"ࠥࡖ࡬ࡿࡳࡰࡨࡷࠦ橶")
#=================================================================================
def l1lll11lll_l1_(data):
	page = data
	if l1l1l1_l1_ (u"ࠫࡦࡪࡩ࡭ࡤࡲࡣࡍ࡚ࡍࡍࡡࡨࡲࡨࡵࡤࡦࡴࠪ橷") in data:
		l11ll1llll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡂࡳࡤࡴ࡬ࡴࡹ࠴ࠪࡀ࠽࠱࠮ࡄࡢࠧࠩ࠰࠭ࡃ࠮ࡁࠧ橸"), data, re.S)
		l11ll11llll1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠯ࡨ࠰࠱࠲࠳࠴ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ橹"), data, re.S)
		if l11ll1llll1l_l1_ and l11ll11llll1_l1_:
			l11lll11ll_l1_ = l11ll1llll1l_l1_[0].replace(l1l1l1_l1_ (u"ࠢࠨࠤ橺"),l1l1l1_l1_ (u"ࠨࠩ橻"))
			l11lll11ll_l1_ = l11lll11ll_l1_.replace(l1l1l1_l1_ (u"ࠤ࠮ࠦ橼"),l1l1l1_l1_ (u"ࠪࠫ橽"))
			l11lll11ll_l1_ = l11lll11ll_l1_.replace(l1l1l1_l1_ (u"ࠦࡡࡴࠢ橾"),l1l1l1_l1_ (u"ࠬ࠭橿"))
			l11ll1l1ll11_l1_ = l11lll11ll_l1_.split(l1l1l1_l1_ (u"࠭࠮ࠨ檀"))
			page = l1l1l1_l1_ (u"ࠧࠨ檁")
			for l11ll1111l_l1_ in l11ll1l1ll11_l1_:
				l11l1l111l11_l1_ = base64.b64decode(l11ll1111l_l1_+l1l1l1_l1_ (u"ࠨ࠿ࡀࠫ檂")).decode(l1l1l1_l1_ (u"ࠤࡸࡸ࡫࠳࠸ࠣ檃"))
				l11ll1l1l111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡠࡩ࠱ࠧ檄"), l11l1l111l11_l1_, re.S)
				if l11ll1l1l111_l1_:
					l111l1l11l11_l1_ = int(l11ll1l1l111_l1_[0])+int(l11ll11llll1_l1_[0])
					page = page + chr(l111l1l11l11_l1_)
			if kodi_version>18.99: page = page.encode(l1l1l1_l1_ (u"ࠫ࡮ࡹ࡯࠮࠺࠻࠹࠾࠳࠱ࠨ檅")).decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ檆"))
	return page
def SEARCH_OPTIONS(search):
	options,l111l_l1_ = l1l1l1_l1_ (u"࠭ࠧ檇"),True
	if search.count(l1l1l1_l1_ (u"ࠧࡠࠩ檈"))>=2:
		search,options = search.split(l1l1l1_l1_ (u"ࠨࡡࠪ檉"),1)
		options = l1l1l1_l1_ (u"ࠩࡢࠫ檊")+options
		if l1l1l1_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ檋") in options: l111l_l1_ = False
		else: l111l_l1_ = True
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ檌"),l1l1l1_l1_ (u"ࠬ࠭檍"),search,options)
	return search,options,l111l_l1_
if __name__==l1l1l1_l1_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨ檎"):
	# l111ll1l111l_l1_ l1lll111_l1_ when l111l11l1ll1_l1_
	LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ檏"),l1l1l1_l1_ (u"ࠨ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࠭檐"))
	if 0:
		url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡱࡱࡩ࠴ࡼࡩࡥࡧࡲࡣࡵࡲࡡࡺࡧࡵࡃࡺ࡯ࡤ࠾࠲ࠩࡺ࡮ࡪ࠽ࡧࡨࡥ࠻࠵࠾ࡣ࠲࠻࠵ࡧ࠷࠾ࡤ࠲࠳࠵࠴࠷ࡧࡤ࠲࠺ࡧࡨ࠶࠸ࡣ࠷࠺࠳࠺ࠬ檑")
		import ll_l1_
		a,b,c = ll_l1_.l1lllll1lll_l1_(url)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ檒"),l1l1l1_l1_ (u"ࠫࠬ檓"),l1l1l1_l1_ (u"ࠬ࠭檔"),str(c))
		l1ll1l1l1l1_l1_ = c[0][0]
		#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ檕"),l1ll1l1l1l1_l1_)
		l1ll1l1l1l1_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴ࠵࠷࠲࠳ࡢ࡬ࡻࡦࡪࡨࡲࡪ࠯ࡥ࠱ࡷࡨࡪ࡮࠯ࡶࡲ࠳ࡸࡺࡲࡦࡣࡰ࠳ࡻ࠷࠯ࡩ࡮ࡶ࠳࠸ࡪࡕࡕࡈ࠺࡝࠼ࡋࡂࡈ࡮ࡘࡶ࡛ࡐࡊࡵ࠴ࡎ࡛࡬࠵࠱࠷࠺࠶࠺࠾࠿࠲࠺࠶࠲ࡥࡱࡲ࠯ࡢ࡮࡯࠳࠶࠶࠷࠯࠳࠸࠽࠳࠷࠴࠯࠶࠶࠳ࡾ࡫ࡳ࠰ࡅࡄ࠳࠵࠵࠰࠷࠯࠳࠶࠴࠸࠯ࡧࡨࡥ࠻࠵࠾ࡣ࠲࠻࠵ࡧ࠷࠾ࡤ࠲࠳࠵࠴࠷ࡧࡤ࠲࠺ࡧࡨ࠶࠸ࡣ࠷࠺࠳࠺࠴࠷࠵࠶ࡡ࡫ࡨ࠼࠸࠰ࡣࡡࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵ࠹ࠩ檖")
		#PLAY_VIDEO(l1ll1l1l1l1_l1_)
		l111l1llll1l_l1_ = xbmcgui.ListItem()
		#l111l1llll1l_l1_.setPath(l1ll1l1l1l1_l1_)
		#xbmcplugin.setResolvedUrl(addon_handle,True,l111l1llll1l_l1_)
		xbmc.Player().play(l1ll1l1l1l1_l1_,l111l1llll1l_l1_)
	else:
		errortrace = l1l1l1_l1_ (u"ࠨࠩ檗")
		l1ll1l1ll_l1_(l1l1l1_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ檘"))
		try: l11l1ll11l11_l1_()
		except Exception as error: errortrace = traceback.format_exc()
		l1ll1l1ll_l1_(l1l1l1_l1_ (u"ࠪࡷࡹࡵࡰࠨ檙"))
		if errortrace:
			#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ檚"),l1l1l1_l1_ (u"ࠬࡋࡅࡎࡏࡄࡅࡉࡊ࠺ࠡࠢࠪ檛")+errortrace)
			if l1l1l1_l1_ (u"࠭࡟ࡠࡈࡒࡖࡈࡋࡄࡠࡇ࡛ࡍ࡙ࡥ࡟ࠨ檜") not in errortrace: l11llllll11l_l1_(errortrace)
			else:
				l111ll11lll1_l1_ = errortrace.splitlines()
				for line in reversed(l111ll11lll1_l1_):
					if l1l1l1_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ檝") in line:
						line = line.split(l1l1l1_l1_ (u"ࠨࡡࡢࡊࡔࡘࡃࡆࡆࡢࡉ࡝ࡏࡔࡠࡡࠪ檞"))[1]
						sys.stderr.write(l1l1l1_l1_ (u"ࠩ࡟ࡲࡋࡕࡒࡄࡇࡇࠤࡊ࡞ࡉࡕ࠼࡟ࡲࠬ檟")+line)
						sys.stderr.write(l1l1l1_l1_ (u"ࠪࡠࡳࡥࠧ檠"))
						break
		refresh = settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ檡"))
		if refresh==l1l1l1_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ檢"): settings.setSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ檣"),l1l1l1_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ檤"))
		elif refresh==l1l1l1_l1_ (u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ檥"): settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭檦"),l1l1l1_l1_ (u"ࠪࠫ檧"))
		if settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ檨")) not in [l1l1l1_l1_ (u"ࠬࡇࡕࡕࡑࠪ檩"),l1l1l1_l1_ (u"࠭ࡓࡕࡑࡓࠫ檪"),l1l1l1_l1_ (u"ࠧࡂࡕࡎࠫ檫")]: settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ檬"),l1l1l1_l1_ (u"ࠩࡄࡗࡐ࠭檭"))
		if settings.getSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ檮")) not in [l1l1l1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ檯"),l1l1l1_l1_ (u"࡙ࠬࡔࡐࡒࠪ檰"),l1l1l1_l1_ (u"࠭ࡁࡔࡍࠪ檱")]: settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ檲"),l1l1l1_l1_ (u"ࠨࡃࡖࡏࠬ檳"))
		l1ll11llll11_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ檴"))
		l1l1l11ll1ll_l1_ = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭檵"))
		if l1l1l1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ檶") in str(l1l1l11ll1ll_l1_) and l1ll11llll11_l1_ in [l1l1l1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ檷"),l1l1l1_l1_ (u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ檸")]:
			#DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠧࠨ檹"),l1ll11llll11_l1_)
			time.sleep(0.100)
			xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬ檺"))
		#l11llll111ll_l1_ = sys.version_info[0]
		#l11ll1ll11ll_l1_ = sys.version_info[1]
		#if l11llll111ll_l1_==2: python_version = l1l1l1_l1_ (u"ࠩ࠵࠻ࠬ檻")
		#else: python_version = str(l11llll111ll_l1_)+str(l11ll1ll11ll_l1_)
		#l11llll1llll_l1_ = os.path.join(addonfolder,l1l1l1_l1_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ檼")+python_version)
		if 0 and addon_handle>-1:
			#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ檽"),l1l1l1_l1_ (u"ࠬ࠭檾"),l1l1l1_l1_ (u"࠭ࠧ檿"),str(addon_handle))
			xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
			succeeded,updateListing,cacheToDisc = False,False,False
			xbmcplugin.endOfDirectory(addon_handle,succeeded,updateListing,cacheToDisc)
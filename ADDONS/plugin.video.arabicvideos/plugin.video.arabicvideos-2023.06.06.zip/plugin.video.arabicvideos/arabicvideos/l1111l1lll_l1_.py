# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
#
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࠬ⨍")
menu_name = l1l1l1_l1_ (u"ࠧࡠࡉࡏࡗࡤ࠭⨎")
def MAIN(mode,url,text,page):
	if   mode==540: results = MENU()
	elif mode==541: results = l1llll1111l_l1_(text)
	elif mode==542: results = l1lll1l1l1l_l1_(text,url,page)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨏"),l1l1l1_l1_ (u"ࠩหัะࠦฬะ์าࠫ⨐"),l1l1l1_l1_ (u"ࠪࠫ⨑"),549)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⨒"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁ้ࠥไๆษอࠤ๊ิา็หࠣࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⨓"),l1l1l1_l1_ (u"࠭ࠧ⨔"),9999)
	l1lll1lll11_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⨕"),l1l1l1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⨖"))
	if l1lll1lll11_l1_:
		l1lll1lll11_l1_ = l1lll1lll11_l1_[l1l1l1_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ⨗")]
		for search in reversed(l1lll1lll11_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⨘"),search,l1l1l1_l1_ (u"ࠫࠬ⨙"),549,l1l1l1_l1_ (u"ࠬ࠭⨚"),l1l1l1_l1_ (u"࠭ࠧ⨛"),search)
	return
def SEARCH(search):
	#search,options,l111l_l1_ = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1111lll11_l1_ = search.replace(menu_name,l1l1l1_l1_ (u"ࠧࠨ⨜"))
	l1lll11llll_l1_(l1111lll11_l1_)
	#l1lll11l1l1_l1_ = search+options+l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⨝")
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⨞"),l1l1l1_l1_ (u"ࠪ฽๊๊ࠠษฯฮࠤั๋วฺ์ࠣ࠱ࠥ࠭⨟")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡸ࡯ࡴࡦࡵࠪ⨠"),542,l1l1l1_l1_ (u"ࠬ࠭⨡"),l1l1l1_l1_ (u"࠭ࠧ⨢"),l1111lll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⨣"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⨤"),l1l1l1_l1_ (u"ࠩࠪ⨥"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⨦"),l1l1l1_l1_ (u"๋ࠫะววฮࠣห้ฮอฬ่ࠢๅฺ๊ษࠡ࠯ࠣࠫ⨧")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫ⨨"),542,l1l1l1_l1_ (u"࠭ࠧ⨩"),l1l1l1_l1_ (u"ࠧࠨ⨪"),l1111lll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨫"),l1l1l1_l1_ (u"้ࠩฮฬฬฬࠡษ็ฬาัࠠๆไึ้ฮࠦ࠭ࠡࠩ⨬")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⨭"),542,l1l1l1_l1_ (u"ࠫࠬ⨮"),l1l1l1_l1_ (u"ࠬ࠭⨯"),l1111lll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⨰"),l1l1l1_l1_ (u"ࠧษฯฮࠤ๊์แาัࠣ࠱ࠥ࠭⨱")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠨࠩ⨲"),541,l1l1l1_l1_ (u"ࠩࠪ⨳"),l1l1l1_l1_ (u"ࠪࠫ⨴"),l1111lll11_l1_)
	return
def l1lll11llll_l1_(l1llll11ll1_l1_):
	l1llll1l111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⨵"),l1l1l1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⨶"),l1llll11ll1_l1_)
	l1llll11lll_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࠫ⨷"),l1l1l1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⨸"),menu_name+l1llll11ll1_l1_)
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⨹"),l1llll11ll1_l1_)
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⨺"),menu_name+l1llll11ll1_l1_)
	old_value = l1llll1l111_l1_+l1llll11lll_l1_
	if old_value: l1llll11ll1_l1_ = menu_name+l1llll11ll1_l1_
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⨻"),l1llll11ll1_l1_,old_value,l1lll1l1lll_l1_)
	return
def l1lll1l11ll_l1_():
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࠬ⨼"),l1l1l1_l1_ (u"ࠬ࠭⨽"),l1l1l1_l1_ (u"࠭ࠧ⨾"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⨿"),l1l1l1_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤ่๊ๅศฬࠣห้ฮอฬࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬ⩀"))
	if yes!=1: return
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⩁"))
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡒࡔࡊࡔࡅࡅࠩ⩂"))
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪ⩃"))
	DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭⩄"),l1l1l1_l1_ (u"࠭ࠧ⩅"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⩆"),l1l1l1_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำࠠอ็ํ฽้ࠥไๆษอࠤฬ๊ศฮอࠣห้๋ฮำ่ฬࠤๆ๐ࠠศๆหี๋อๅอࠩ⩇"))
	return
def l1lll1l1l1l_l1_(search_org,action,site=l1l1l1_l1_ (u"ࠩࠪ⩈")):
	l1lll1ll111_l1_,l1lll1ll11l_l1_,l1lll1llll1_l1_,l1lll11l111_l1_,l1lll11l1ll_l1_,l1lll1lll1l_l1_,threads = [],[],[],{},{},{},{}
	if action==l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⩉"): l1lll1llll1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⩊"),l1l1l1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⩋"),menu_name+search_org)
	elif action==l1l1l1_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬ⩌"): l1lll1llll1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⩍"),l1l1l1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⩎"),search_org)
	elif action==l1l1l1_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⩏"): l1lll1llll1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⩐"),l1l1l1_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪ⩑"),[site,search_org])
	if not l1lll1llll1_l1_:
		l1llll111l1_l1_ = l1l1l1_l1_ (u"ࠬํะศࠢส่อำหࠡ฼ํี๋่ࠥอ๊าࠤๆ๐ࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࡠࡳ࠭⩒")
		l1llll111ll_l1_ = l1l1l1_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆล๊ࠥอไษฯฮࠤๆ๐ࠠอ็ํ฽ࠥอไๆ๊สๆ฾ูࠦ็ࠢ࡟ࡲࠥࠨ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢࠪ⩓")+search_org+l1l1l1_l1_ (u"ࠧࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥࠤࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไษฯฮࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠩ⩔")
		if action==l1l1l1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⩕"): message = l1llll111ll_l1_
		else: message = l1llll111l1_l1_+l1llll111ll_l1_
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࠪ⩖"),l1l1l1_l1_ (u"ࠪࠫ⩗"),l1l1l1_l1_ (u"ࠫࠬ⩘"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⩙"),message)
		if yes!=1: return
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⩚"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡗࡪࡧࡲࡤࡪࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫ⩛")+search_org+l1l1l1_l1_ (u"ࠨࠢࡠࠫ⩜"))
		#global menuItemsLIST
		import threading
		#l1lll1ll1ll_l1_ = [l1l1l1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ⩝"),l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ⩞"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ⩟")]
		l1llll1ll1l_l1_ = 1
		for site in l1lll1ll1ll_l1_:
			l1lll11l111_l1_[site] = []
			options = l1l1l1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ⩠")
			if l1l1l1_l1_ (u"࠭࠭ࠨ⩡") in site: options = options+l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࠬ⩢")+site+l1l1l1_l1_ (u"ࠨࡡࠪ⩣")
			l1lll1l1111_l1_,l1lll1l1ll1_l1_,l1llll1ll11_l1_ = l1lll11ll11_l1_(site)
			if l1llll1ll1l_l1_:
				threads[site] = threading.Thread(target=l1lll1l1ll1_l1_,args=(search_org+options,))
				threads[site].start()
			else: l1lll1l1ll1_l1_(search_org+options)
			DIALOG_NOTIFICATION(TRANSLATE(site),l1l1l1_l1_ (u"ࠩࠪ⩤"),time=1000)
		if l1llll1ll1l_l1_:
			for site in l1lll1ll1ll_l1_:
				threads[site].join(10)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ⩥"),l1l1l1_l1_ (u"ࠫࠬ⩦"),l1l1l1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠤ࡫ࡵࡵ࡯ࡦࡨࡨ࠿࠭⩧"),str(len(menuItemsLIST)))
		for site in l1lll1ll1ll_l1_:
			l1lll1l1111_l1_,l1lll1l1ll1_l1_,l1llll1ll11_l1_ = l1lll11ll11_l1_(site)
			for menuItem in menuItemsLIST:
				type,name,url,mode,image,page,text,context,infodict = menuItem
				if l1llll1ll11_l1_ in name:
					if l1l1l1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࠬ⩨") in site and (239>=mode>=230 or 289>=mode>=280):
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ⩩")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⩪")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⩫")]: continue
						if l1l1l1_l1_ (u"ูࠪๆำษࠨ⩬") not in name:
							if   type==l1l1l1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⩭"): site = l1l1l1_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⩮")
							elif type==l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⩯"): site = l1l1l1_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⩰")
							elif type==l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩱"): site = l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⩲")
						else:
							if   l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ⩳") in url: site = l1l1l1_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⩴")
							elif l1l1l1_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ⩵") in url: site = l1l1l1_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ⩶")
							elif l1l1l1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ⩷") in url: site = l1l1l1_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭⩸")
					elif l1l1l1_l1_ (u"ࠩࡐ࠷࡚࠳ࠧ⩹") in site and 729>=mode>=710:
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬ⩺")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⩻")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ⩼")]: continue
						if l1l1l1_l1_ (u"࠭ีโฯฬࠫ⩽") not in name:
							if   type==l1l1l1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⩾"): site = l1l1l1_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ⩿")
							elif type==l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⪀"): site = l1l1l1_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⪁")
							elif type==l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪂"): site = l1l1l1_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ⪃")
						else:
							if   l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࠫ⪄") in url: site = l1l1l1_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⪅")
							elif l1l1l1_l1_ (u"ࠨࡏࡒ࡚ࡎࡋࡓࠨ⪆") in url: site = l1l1l1_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭⪇")
							elif l1l1l1_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ⪈") in url: site = l1l1l1_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ⪉")
					elif l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࠧ⪊") in site and 149>=mode>=140:
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⪋")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⪌")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ⪍")]: continue
						if l1l1l1_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ⪎") in name or l1l1l1_l1_ (u"ࠪ࠾࠿ࠦࠧ⪏") in name:
							continue
							#if   image==l1l1l1_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭⪐"): site = l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⪑")
							#elif image==l1l1l1_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⪒"): site = l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⪓")
							#else: site = l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ⪔")
						else:
							if   mode==144 and l1l1l1_l1_ (u"ࠩࡘࡗࡊࡘࠧ⪕") in name: site = l1l1l1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⪖")
							elif mode==144 and l1l1l1_l1_ (u"ࠫࡈࡎࡎࡍࠩ⪗") in name: site = l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⪘")
							elif mode==144 and l1l1l1_l1_ (u"࠭ࡌࡊࡕࡗࠫ⪙") in name: site = l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⪚")
							elif mode==143: site = l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ⪛")
							else: continue
					elif l1l1l1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࠨ⪜") in site and 419>=mode>=400:
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⪝")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ⪞")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ⪟")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ⪠")]: continue
						if   mode in [401,405]: site = l1l1l1_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⪡")
						elif mode in [402,406]: site = l1l1l1_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⪢")
						elif mode in [403,404]: site = l1l1l1_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⪣")
						elif mode in [412,413]: site = l1l1l1_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ⪤")
					elif l1l1l1_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࠫ⪥") in site and 39>=mode>=30:
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫ⪦")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ⪧")]: continue
						if   mode in [32,39]: site = l1l1l1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭⪨")
						elif mode in [33,39]: site = l1l1l1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⪩")
					elif l1l1l1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࠩ⪪") in site and 29>=mode>=20:
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ⪫")]: continue
						if menuItem in l1lll11l111_l1_[l1l1l1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ⪬")]: continue
						if   l1l1l1_l1_ (u"ࠬ࠵ࡡࡳ࠰ࠪ⪭") in url: site = l1l1l1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ⪮")
						elif l1l1l1_l1_ (u"ࠧ࠰ࡧࡱ࠲ࠬ⪯") in url: site = l1l1l1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⪰")
					#elif l1l1l1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࠭⪱") in site and 319>=mode>=310:
					#	if menuItem in l1lll11l111_l1_[site]: continue
					#	if mode==312: site = l1lll1l111l_l1_+l1l1l1_l1_ (u"ࠪ࠱ࡆ࡛ࡄࡊࡑࡖࠫ⪲")
					#	elif l1l1l1_l1_ (u"ࠫ࠴ࡩࡡࡵ࠯ࠪ⪳") in url: site = l1lll1l111l_l1_+l1l1l1_l1_ (u"ࠬ࠳ࡁࡍࡄࡘࡑࡘ࠭⪴")
					#	else: site = l1lll1l111l_l1_+l1l1l1_l1_ (u"࠭࠭ࡑࡇࡕࡗࡔࡔࡓࠨ⪵")
					l1lll11l111_l1_[site].append(menuItem)
		menuItemsLIST[:] = []
		for site in list(l1lll11l111_l1_.keys()):
			l1lll11l1ll_l1_[site] = []
			l1lll1lll1l_l1_[site] = []
			for type,name,url,mode,image,page,text,context,infodict in l1lll11l111_l1_[site]:
				menuItem = (type,name,url,mode,image,page,text,context,infodict)
				if l1l1l1_l1_ (u"ࠧึใะอࠬ⪶") in name and type==l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⪷"): l1lll1lll1l_l1_[site].append(menuItem)
				else: l1lll11l1ll_l1_[site].append(menuItem)
		l1llll11111_l1_ = [(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⪸"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⪹"),l1l1l1_l1_ (u"ࠫࠬ⪺"),157,l1l1l1_l1_ (u"ࠬ࠭⪻"),l1l1l1_l1_ (u"࠭ࠧ⪼"),l1l1l1_l1_ (u"ࠧࠨ⪽"),l1l1l1_l1_ (u"ࠨࠩ⪾"),l1l1l1_l1_ (u"ࠩࠪ⪿"))]
		for site in l1lll1ll1l1_l1_:
			if site==l1lll1l11l1_l1_[0]: l1llll11111_l1_ = [(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⫀"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤํ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⫁"),l1l1l1_l1_ (u"ࠬ࠭⫂"),157,l1l1l1_l1_ (u"࠭ࠧ⫃"),l1l1l1_l1_ (u"ࠧࠨ⫄"),l1l1l1_l1_ (u"ࠨࠩ⫅"),l1l1l1_l1_ (u"ࠩࠪ⫆"),l1l1l1_l1_ (u"ࠪࠫ⫇"))]
			elif site==l1llll1l11l_l1_[0]: l1llll11111_l1_ = [(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⫈"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะฺࠠษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⫉"),l1l1l1_l1_ (u"࠭ࠧ⫊"),157,l1l1l1_l1_ (u"ࠧࠨ⫋"),l1l1l1_l1_ (u"ࠨࠩ⫌"),l1l1l1_l1_ (u"ࠩࠪ⫍"),l1l1l1_l1_ (u"ࠪࠫ⫎"),l1l1l1_l1_ (u"ࠫࠬ⫏"))]
			elif site==l1lll11l11l_l1_[0]: l1llll11111_l1_ = [(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⫐"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⫑"),l1l1l1_l1_ (u"ࠧࠨ⫒"),157,l1l1l1_l1_ (u"ࠨࠩ⫓"),l1l1l1_l1_ (u"ࠩࠪ⫔"),l1l1l1_l1_ (u"ࠪࠫ⫕"),l1l1l1_l1_ (u"ࠫࠬ⫖"),l1l1l1_l1_ (u"ࠬ࠭⫗"))]
			if site not in l1lll11l1ll_l1_.keys(): continue
			if l1lll11l1ll_l1_[site]:
				l1lll11lll1_l1_ = TRANSLATE(site)
				l1lll1l1l11_l1_ = [(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⫘"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽ࠡࠩ⫙")+l1lll11lll1_l1_+l1l1l1_l1_ (u"ࠨࠢࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⫚"),l1l1l1_l1_ (u"ࠩࠪ⫛"),9999,l1l1l1_l1_ (u"ࠪࠫ⫝̸"),l1l1l1_l1_ (u"ࠫࠬ⫝"),l1l1l1_l1_ (u"ࠬ࠭⫞"),l1l1l1_l1_ (u"࠭ࠧ⫟"),l1l1l1_l1_ (u"ࠧࠨ⫠"))]
				if 0:
					l1llll1l1l1_l1_ = search_org+l1l1l1_l1_ (u"ࠨࠢ࠰ࠤࠬ⫡")+l1l1l1_l1_ (u"ࠩหัะ࠭⫢")+l1l1l1_l1_ (u"ࠪࠤࠬ⫣")+l1lll11lll1_l1_
				else:
					l1llll1l1l1_l1_ = l1l1l1_l1_ (u"ࠫอำหࠨ⫤")+l1l1l1_l1_ (u"ࠬࠦࠧ⫥")+l1lll11lll1_l1_+l1l1l1_l1_ (u"࠭ࠠ࠮ࠢࠪ⫦")+search_org
				if len(l1lll11l1ll_l1_[site])<8: l1lll1lllll_l1_ = []
				else:
					l1llll1l1ll_l1_ = l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ⫧")+l1llll1l1l1_l1_+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⫨")
					l1lll1lllll_l1_ = [(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⫩"),menu_name+l1llll1l1ll_l1_,l1l1l1_l1_ (u"ࠪࡧࡱࡵࡳࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⫪"),542,l1l1l1_l1_ (u"ࠫࠬ⫫"),site,search_org,l1l1l1_l1_ (u"ࠬ࠭⫬"),l1l1l1_l1_ (u"࠭ࠧ⫭"))]
				l1llll11l11_l1_ = l1lll11l1ll_l1_[site]+l1lll1lll1l_l1_[site]
				l1lll1ll11l_l1_ += l1llll11111_l1_+l1lll1l1l11_l1_+l1llll11l11_l1_[:7]+l1lll1lllll_l1_
				l1lll11ll1l_l1_ = [(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⫮"),menu_name+l1llll1l1l1_l1_,l1l1l1_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⫯"),542,l1l1l1_l1_ (u"ࠩࠪ⫰"),site,search_org,l1l1l1_l1_ (u"ࠪࠫ⫱"),l1l1l1_l1_ (u"ࠫࠬ⫲"))]
				l1lll1ll111_l1_ += l1llll11111_l1_+l1lll11ll1l_l1_
				l1llll11111_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡈࡒࡏࡔࡇࡇࠫ⫳"),[site,search_org],l1llll11l11_l1_,l1lll1l1lll_l1_)
		WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ⫴"),search_org,l1lll1ll11l_l1_,l1lll1l1lll_l1_)
		DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⫵"),search_org)
		WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⫶"),menu_name+search_org,l1lll1ll111_l1_,l1lll1l1lll_l1_)
		DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ⫷"),l1l1l1_l1_ (u"ࠪࠫ⫸"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⫹"),l1l1l1_l1_ (u"ࠬอไษฯฮࠤฬ๊ฬๆษ฼๎ࠥอๆห้์ࠤอ์ฬศฯࠣࡠࡳࡢ࡮ࠡฬ่ࠤฯิา๋่ࠣห้์สศศฯࠤๆ๐ࠠไษืࠤฬ๊ศา่ส้ัࠦไๆัฬࠤะ๊วฬ์้ࠤ๏๎ๅࠡๆๆ๎ࠥะำหูํ฽ࠥอไฺ๊าอࠥหไ๋้สࠤอี่็ࠢ฼้้ࠦศฮอࠣะิ๐ฯࠨ⫺"))
		if action==l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ⫻") and l1lll1ll111_l1_: l1lll1llll1_l1_ = l1lll1ll111_l1_
		else: l1lll1llll1_l1_ = l1lll1ll11l_l1_
	if action!=l1l1l1_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⫼"):
		for type,name,url,mode,image,page,text,context,infodict in l1lll1llll1_l1_:
			if action in [l1l1l1_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⫽"),l1l1l1_l1_ (u"ࠩࡲࡴࡪࡴࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⫾")] and l1l1l1_l1_ (u"ูࠪๆำษࠨ⫿") in name and type==l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⬀"): continue
			addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return
def l1llll1111l_l1_(search_org=l1l1l1_l1_ (u"ࠬ࠭⬁")):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⬂"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡗࡪࡧࡲࡤࡪࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫ⬃")+search+l1l1l1_l1_ (u"ࠨࠢࡠࠫ⬄"))
	l11ll11_l1_ = search+options
	if 0:
		l1llll11l1l_l1_,l1111lll11_l1_ = search+l1l1l1_l1_ (u"ࠩࠣ࠱ࠥ࠭⬅"),l1l1l1_l1_ (u"ࠪࠫ⬆")
	else:
		l1llll11l1l_l1_,l1111lll11_l1_ = l1l1l1_l1_ (u"ࠫࠬ⬇"),l1l1l1_l1_ (u"ࠬࠦ࠭ࠡࠩ⬈")+search
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⬉"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⬊"),l1l1l1_l1_ (u"ࠨࠩ⬋"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⬌"),l1l1l1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ⬍")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡࡏ࠶࡙ࠬ⬎")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭⬏"),719,l1l1l1_l1_ (u"࠭ࠧ⬐"),l1l1l1_l1_ (u"ࠧࠨ⬑"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⬒"),l1l1l1_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ⬓")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠࡊࡒࡗ࡚ࠬ⬔")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠫࠬ⬕"),239,l1l1l1_l1_ (u"ࠬ࠭⬖"),l1l1l1_l1_ (u"࠭ࠧ⬗"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⬘"),l1l1l1_l1_ (u"ࠨࡡࡅࡏࡗࡥࠧ⬙")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤอ้ัศࠩ⬚")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠪࠫ⬛"),379,l1l1l1_l1_ (u"ࠫࠬ⬜"),l1l1l1_l1_ (u"ࠬ࠭⬝"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⬞"),l1l1l1_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭⬟")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬฬ์๊หࠩ⬠")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠩࠪ⬡"),39,l1l1l1_l1_ (u"ࠪࠫ⬢"),l1l1l1_l1_ (u"ࠫࠬ⬣"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬤"),l1l1l1_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ⬥")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧ⬦"),l1l1l1_l1_ (u"ࠨࠩ⬧"),39,l1l1l1_l1_ (u"ࠩࠪ⬨"),l1l1l1_l1_ (u"ࠪࠫ⬩"),l11ll11_l1_+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࡠࠩ⬪"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬫"),l1l1l1_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ⬬")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩ⬭"),l1l1l1_l1_ (u"ࠨࠩ⬮"),39,l1l1l1_l1_ (u"ࠩࠪ⬯"),l1l1l1_l1_ (u"ࠪࠫ⬰"),l11ll11_l1_+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࡠࠩ⬱"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬲"),l1l1l1_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ⬳")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํ์ฯ๐่ษࠢไ๎ิ๐่่ษอࠫ⬴"),l1l1l1_l1_ (u"ࠨࠩ⬵"),149,l1l1l1_l1_ (u"ࠩࠪ⬶"),l1l1l1_l1_ (u"ࠪࠫ⬷"),l11ll11_l1_+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ⬸"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬹"),l1l1l1_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ⬺")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨ⬻"),l1l1l1_l1_ (u"ࠨࠩ⬼"),149,l1l1l1_l1_ (u"ࠩࠪ⬽"),l1l1l1_l1_ (u"ࠪࠫ⬾"),l11ll11_l1_+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ⬿"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭀"),l1l1l1_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ⭁")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨ⭂"),l1l1l1_l1_ (u"ࠨࠩ⭃"),149,l1l1l1_l1_ (u"ࠩࠪ⭄"),l1l1l1_l1_ (u"ࠪࠫ⭅"),l11ll11_l1_+l1l1l1_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭⭆"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭇"),l1l1l1_l1_ (u"࠭࡟ࡌࡎࡄࡣࠬ⭈")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๆ่ࠥอไฺำหࠫ⭉")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠨࠩ⭊"),19,l1l1l1_l1_ (u"ࠩࠪ⭋"),l1l1l1_l1_ (u"ࠪࠫ⭌"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⭍"),l1l1l1_l1_ (u"ࠬࡥࡋࡓࡄࡢࠫ⭎")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦใาส็หฦ࠭⭏")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨ⭐"),329,l1l1l1_l1_ (u"ࠨࠩ⭑"),l1l1l1_l1_ (u"ࠩࠪ⭒"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭓"),l1l1l1_l1_ (u"ࠫࡤࡌࡈ࠲ࡡࠪ⭔")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫ⭕")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧ⭖"),579,l1l1l1_l1_ (u"ࠧࠨ⭗"),l1l1l1_l1_ (u"ࠨࠩ⭘"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭙"),l1l1l1_l1_ (u"ࠪࡣࡊࡍࡂࡠࠩ⭚")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ⭛")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭⭜"),129,l1l1l1_l1_ (u"࠭ࠧ⭝"),l1l1l1_l1_ (u"ࠧࠨ⭞"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭟"),l1l1l1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨ⭠")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡใํำ๏๎็ศฬࠪ⭡"),l1l1l1_l1_ (u"ࠫࠬ⭢"),409,l1l1l1_l1_ (u"ࠬ࠭⭣"),l1l1l1_l1_ (u"࠭ࠧ⭤"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ⭥"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭦"),l1l1l1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨ⭧")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧ⭨"),l1l1l1_l1_ (u"ࠫࠬ⭩"),409,l1l1l1_l1_ (u"ࠬ࠭⭪"),l1l1l1_l1_ (u"࠭ࠧ⭫"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ⭬"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭭"),l1l1l1_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨ⭮")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧ⭯"),l1l1l1_l1_ (u"ࠫࠬ⭰"),409,l1l1l1_l1_ (u"ࠬ࠭⭱"),l1l1l1_l1_ (u"࠭ࠧ⭲"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭⭳"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭴"),l1l1l1_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ⭵")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠪࠤࠥฮอฬ่ࠢ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭⭶")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠫࠥࠦࠧ⭷"),l1l1l1_l1_ (u"ࠬ࠭⭸"),29,l1l1l1_l1_ (u"࠭ࠧ⭹"),l1l1l1_l1_ (u"ࠧࠨ⭺"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭻"),l1l1l1_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ⭼")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩ⭽"),l1l1l1_l1_ (u"ࠫࠬ⭾"),29,l1l1l1_l1_ (u"ࠬ࠭⭿"),l1l1l1_l1_ (u"࠭ࠧ⮀"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࡣࠬ⮁"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮂"),l1l1l1_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ⮃")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬ⮄"),l1l1l1_l1_ (u"ࠫࠬ⮅"),29,l1l1l1_l1_ (u"ࠬ࠭⮆"),l1l1l1_l1_ (u"࠭ࠧ⮇"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࡤ࠭⮈"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮉"),l1l1l1_l1_ (u"ࠩࡢࡅࡐࡕ࡟ࠨ⮊")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫ⮋")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠫࠬ⮌"),79,l1l1l1_l1_ (u"ࠬ࠭⮍"),l1l1l1_l1_ (u"࠭ࠧ⮎"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮏"),l1l1l1_l1_ (u"ࠨࡡࡄࡏ࡜ࡥࠧ⮐")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪ⮑")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠪࠫ⮒"),249,l1l1l1_l1_ (u"ࠫࠬ⮓"),l1l1l1_l1_ (u"ࠬ࠭⮔"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⮕"),l1l1l1_l1_ (u"ࠧࡠࡏࡕࡊࠬ⮖")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ⮗"),l1l1l1_l1_ (u"ࠩࠪ⮘"),49,l1l1l1_l1_ (u"ࠪࠫ⮙"),l1l1l1_l1_ (u"ࠫࠬ⮚"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮛"),l1l1l1_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬ⮜")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆࠦๅศๅึࠫ⮝")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠨࠩ⮞"),59,l1l1l1_l1_ (u"ࠩࠪ⮟"),l1l1l1_l1_ (u"ࠪࠫ⮠"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⮡"),l1l1l1_l1_ (u"ࠬࡥࡆࡕࡏࡢࠫ⮢")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩ⮣")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨ⮤"),69,l1l1l1_l1_ (u"ࠨࠩ⮥"),l1l1l1_l1_ (u"ࠩࠪ⮦"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮧"),l1l1l1_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ⮨")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬ⮩"),l1l1l1_l1_ (u"࠭ࠧ⮪"),139,l1l1l1_l1_ (u"ࠧࠨ⮫"),l1l1l1_l1_ (u"ࠨࠩ⮬"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮭"),l1l1l1_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ⮮")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪ⮯"),l1l1l1_l1_ (u"ࠬ࠭⮰"),319,l1l1l1_l1_ (u"࠭ࠧ⮱"),l1l1l1_l1_ (u"ࠧࠨ⮲"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮳"),l1l1l1_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨ⮴")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧ⮵"),l1l1l1_l1_ (u"ࠫࠬ⮶"),319,l1l1l1_l1_ (u"ࠬ࠭⮷"),l1l1l1_l1_ (u"࠭ࠧ⮸"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ⮹"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮺"),l1l1l1_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨ⮻")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูส่ࠢะ้ีࠧ⮼"),l1l1l1_l1_ (u"ࠫࠬ⮽"),319,l1l1l1_l1_ (u"ࠬ࠭⮾"),l1l1l1_l1_ (u"࠭ࠧ⮿"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩ⯀"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯁"),l1l1l1_l1_ (u"ࠩࡢࡗࡍ࡜࡟ࠨ⯂")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩ⯃"),l1l1l1_l1_ (u"ࠫࠬ⯄"),319,l1l1l1_l1_ (u"ࠬ࠭⯅"),l1l1l1_l1_ (u"࠭ࠧ⯆"),l11ll11_l1_+l1l1l1_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࡠࠩ⯇"))
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⯈"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⯉"),l1l1l1_l1_ (u"ࠪࠫ⯊"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯋"),l1l1l1_l1_ (u"ࠬࡥࡋࡕࡍࡢࠫ⯌")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅอ็ํะࠧ⯍")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨ⯎"),679,l1l1l1_l1_ (u"ࠨࠩ⯏"),l1l1l1_l1_ (u"ࠩࠪ⯐"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯑"),l1l1l1_l1_ (u"ࠫࡤࡌࡊࡔࡡࠪ⯒")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬࠦศฮอ้ࠣํู่ࠡใฯีฺ่ࠥࠨ⯓")+l1111lll11_l1_+l1l1l1_l1_ (u"࠭ࠠࠨ⯔"),l1l1l1_l1_ (u"ࠧࠨ⯕"),399,l1l1l1_l1_ (u"ࠨࠩ⯖"),l1l1l1_l1_ (u"ࠩࠪ⯗"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯘"),l1l1l1_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ⯙")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ⯚")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧ⯛"),469,l1l1l1_l1_ (u"ࠧࠨ⯜"),l1l1l1_l1_ (u"ࠨࠩ⯝"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯞"),l1l1l1_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ⯟")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦไ้ัํࠤ๋ะࠧ⯠")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭⯡"),459,l1l1l1_l1_ (u"࠭ࠧ⯢"),l1l1l1_l1_ (u"ࠧࠨ⯣"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯤"),l1l1l1_l1_ (u"ࠩࡢࡇࡒࡔ࡟ࠨ⯥")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧ⯦")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠫࠬ⯧"),309,l1l1l1_l1_ (u"ࠬ࠭⯨"),l1l1l1_l1_ (u"࠭ࠧ⯩"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯪"),l1l1l1_l1_ (u"ࠨࡡ࡚ࡇࡒࡥࠧ⯫")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤํ๐ࠠิ์่หࠬ⯬")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠪࠫ⯭"),569,l1l1l1_l1_ (u"ࠫࠬ⯮"),l1l1l1_l1_ (u"ࠬ࠭⯯"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯰"),l1l1l1_l1_ (u"ࠧࡠࡕࡋࡒࡤ࠭⯱")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣฬํฯ่ࠡํ์ื࠭⯲")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠩࠪ⯳"),589,l1l1l1_l1_ (u"ࠪࠫ⯴"),l1l1l1_l1_ (u"ࠫࠬ⯵"),l11ll11_l1_+l1l1l1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ⯶"))
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯷"),l1l1l1_l1_ (u"ࠧࡠࡏࡆࡑࡤ࠭⯸")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻้ࠣฬ๐ࠠิ์่หࠬ⯹")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠩࠪ⯺"),369,l1l1l1_l1_ (u"ࠪࠫ⯻"),l1l1l1_l1_ (u"ࠫࠬ⯼"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯽"),l1l1l1_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬ⯾")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆࠦศา๊ࠪ⯿")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠨࠩⰀ"),489,l1l1l1_l1_ (u"ࠩࠪⰁ"),l1l1l1_l1_ (u"ࠪࠫⰂ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰃ"),l1l1l1_l1_ (u"ࠬࡥࡁࡓࡕࡢࠫⰄ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ฻ิฬู๊๋ࠥัࠪⰅ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨⰆ"),259,l1l1l1_l1_ (u"ࠨࠩⰇ"),l1l1l1_l1_ (u"ࠩࠪⰈ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰉ"),l1l1l1_l1_ (u"ࠫࡤࡉ࠴ࡖࡡࠪⰊ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็่า์๋ࠫⰋ")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧⰌ"),429,l1l1l1_l1_ (u"ࠧࠨⰍ"),l1l1l1_l1_ (u"ࠨࠩⰎ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰏ"),l1l1l1_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩⰐ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪⰑ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭Ⱂ"),119,l1l1l1_l1_ (u"࠭ࠧⰓ"),l1l1l1_l1_ (u"ࠧࠨⰔ"),l11ll11_l1_+l1l1l1_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭Ⱅ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰖ"),l1l1l1_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩⰗ")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅ้ใีࠤๆ๎ั๋๊ࠪⰘ"),l1l1l1_l1_ (u"ࠬ࠭Ⱉ"),389,l1l1l1_l1_ (u"࠭ࠧⰚ"),l1l1l1_l1_ (u"ࠧࠨⰛ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰜ"),l1l1l1_l1_ (u"ࠩࡢࡉࡌ࡜࡟ࠨⰝ")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬⰞ"),l1l1l1_l1_ (u"ࠫࠬⰟ"),229,l1l1l1_l1_ (u"ࠬ࠭Ⱐ"),l1l1l1_l1_ (u"࠭ࠧⰡ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰢ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰣ"),l1l1l1_l1_ (u"ࠩࠪⰤ"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰥ"),l1l1l1_l1_ (u"ࠫࡤࡒࡒ࡛ࡡࠪⰦ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๅษิ์ือࠧⰧ")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧⰨ"),709,l1l1l1_l1_ (u"ࠧࠨⰩ"),l1l1l1_l1_ (u"ࠨࠩⰪ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰫ"),l1l1l1_l1_ (u"ࠪࡣࡋ࡙ࡔࡠࠩⰬ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแ้ีอหࠬⰭ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭Ⱞ"),609,l1l1l1_l1_ (u"࠭ࠧⰯ"),l1l1l1_l1_ (u"ࠧࠨⰰ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰱ"),l1l1l1_l1_ (u"ࠩࡢࡊࡇࡑ࡟ࠨⰲ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็ศาๅฬࠫⰳ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠫࠬⰴ"),629,l1l1l1_l1_ (u"ࠬ࠭ⰵ"),l1l1l1_l1_ (u"࠭ࠧⰶ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⰷ"),l1l1l1_l1_ (u"ࠨࡡ࡜ࡕ࡙ࡥࠧⰸ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏อโ้ฬࠪⰹ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠪࠫⰺ"),669,l1l1l1_l1_ (u"ࠫࠬⰻ"),l1l1l1_l1_ (u"ࠬ࠭ⰼ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⰽ"),l1l1l1_l1_ (u"ࠧࡠࡄࡕࡗࡤ࠭ⰾ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬึูส๋ฮࠪⰿ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠩࠪⱀ"),659,l1l1l1_l1_ (u"ࠪࠫⱁ"),l1l1l1_l1_ (u"ࠫࠬⱂ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱃ"),l1l1l1_l1_ (u"࠭࡟ࡉࡎࡆࡣࠬⱄ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๊่ࠢฬࠦำ๋็สࠫⱅ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠨࠩⱆ"),89,l1l1l1_l1_ (u"ࠩࠪⱇ"),l1l1l1_l1_ (u"ࠪࠫⱈ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱉ"),l1l1l1_l1_ (u"ࠬࡥࡄࡓ࠹ࡢࠫⱊ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัิห๊อࠠึฯࠪⱋ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨⱌ"),689,l1l1l1_l1_ (u"ࠨࠩⱍ"),l1l1l1_l1_ (u"ࠩࠪⱎ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱏ"),l1l1l1_l1_ (u"ࠫࡤࡉࡍࡇࡡࠪⱐ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็ว็ิࠪⱑ")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧⱒ"),99,l1l1l1_l1_ (u"ࠧࠨⱓ"),l1l1l1_l1_ (u"ࠨࠩⱔ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱕ"),l1l1l1_l1_ (u"ࠪࡣࡈࡓࡌࡠࠩⱖ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩⱗ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭ⱘ"),479,l1l1l1_l1_ (u"࠭ࠧⱙ"),l1l1l1_l1_ (u"ࠧࠨⱚ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱛ"),l1l1l1_l1_ (u"ࠩࡢࡅࡇࡊ࡟ࠨⱜ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨⱝ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠫࠬⱞ"),559,l1l1l1_l1_ (u"ࠬ࠭ⱟ"),l1l1l1_l1_ (u"࠭ࠧⱠ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱡ"),l1l1l1_l1_ (u"ࠨࡡࡆ࠸ࡍࡥࠧⱢ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭Ᵽ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠪࠫⱤ"),699,l1l1l1_l1_ (u"ࠫࠬⱥ"),l1l1l1_l1_ (u"ࠬ࠭ⱦ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱨ"),l1l1l1_l1_ (u"ࠧࡠࡃࡋࡏࡤ࠭ⱨ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧⱩ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠩࠪⱪ"),619,l1l1l1_l1_ (u"ࠪࠫⱫ"),l1l1l1_l1_ (u"ࠫࠬⱬ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱭ"),l1l1l1_l1_ (u"࠭࡟ࡄࡅࡅࡣࠬⱮ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬⱯ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠨࠩⱰ"),639,l1l1l1_l1_ (u"ࠩࠪⱱ"),l1l1l1_l1_ (u"ࠪࠫⱲ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱳ"),l1l1l1_l1_ (u"ࠬࡥࡓࡉࡖࡢࠫⱴ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬⱵ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨⱶ"),649,l1l1l1_l1_ (u"ࠨࠩⱷ"),l1l1l1_l1_ (u"ࠩࠪⱸ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱹ"),l1l1l1_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪⱺ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩⱻ")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧⱼ"),439,l1l1l1_l1_ (u"ࠧࠨⱽ"),l1l1l1_l1_ (u"ࠨࠩⱾ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱿ"),l1l1l1_l1_ (u"ࠪࡣࡋࡎ࠲ࡠࠩⲀ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫⲁ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠬ࠭Ⲃ"),599,l1l1l1_l1_ (u"࠭ࠧⲃ"),l1l1l1_l1_ (u"ࠧࠨⲄ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲅ"),l1l1l1_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨⲆ")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧⲇ"),l1l1l1_l1_ (u"ࠫࠬⲈ"),449,l1l1l1_l1_ (u"ࠬ࠭ⲉ"),l1l1l1_l1_ (u"࠭ࠧⲊ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲋ"),l1l1l1_l1_ (u"ࠨࡡࡄࡏࡈࡥࠧⲌ")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ้่ศ็ࠣ็ฬ๋ࠧⲍ"),l1l1l1_l1_ (u"ࠪࠫⲎ"),359,l1l1l1_l1_ (u"ࠫࠬⲏ"),l1l1l1_l1_ (u"ࠬ࠭Ⲑ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲑ"),l1l1l1_l1_ (u"ࠧࡠࡅࡐࡇࡤ࠭Ⲓ")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๅ็์อ࠭ⲓ"),l1l1l1_l1_ (u"ࠩࠪⲔ"),499,l1l1l1_l1_ (u"ࠪࠫⲕ"),l1l1l1_l1_ (u"ࠫࠬⲖ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲗ"),l1l1l1_l1_ (u"࠭࡟ࡂࡔࡏࡣࠬⲘ")+l1111lll11_l1_+l1l1l1_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦไ๋๊้ึࠬⲙ"),l1l1l1_l1_ (u"ࠨࠩⲚ"),209,l1l1l1_l1_ (u"ࠩࠪⲛ"),l1l1l1_l1_ (u"ࠪࠫⲜ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲝ"),l1l1l1_l1_ (u"ࠬࡥࡈࡆࡎࡢࠫⲞ")+l1111lll11_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭ⲟ"),l1l1l1_l1_ (u"ࠧࠨⲠ"),99,l1l1l1_l1_ (u"ࠨࠩⲡ"),l1l1l1_l1_ (u"ࠩࠪⲢ"),l11ll11_l1_)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲣ"),l1l1l1_l1_ (u"ࠫࡤ࡙ࡆࡘࡡࠪⲤ")+search+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์ิ๎ุࠦแ้ำࠣ์ฯฺࠧⲥ"),l1l1l1_l1_ (u"࠭ࠧⲦ"),218,l1l1l1_l1_ (u"ࠧࠨⲧ"),l1l1l1_l1_ (u"ࠨࠩⲨ"),search) # 219
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲩ"),l1l1l1_l1_ (u"ࠪࡣࡒ࡜࡚ࡠࠩⲪ")+search+l1l1l1_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦๅ้ใํึ๊ࠥว็ัࠪⲫ"),l1l1l1_l1_ (u"ࠬ࠭Ⲭ"),188,l1l1l1_l1_ (u"࠭ࠧⲭ"),l1l1l1_l1_ (u"ࠧࠨⲮ"),search)# 189
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⲯ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⲰ"),l1l1l1_l1_ (u"ࠪࠫⲱ"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲲ"),l1l1l1_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲳ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠨⲴ")+l1111lll11_l1_,l1l1l1_l1_ (u"ࠧࠨⲵ"),149,l1l1l1_l1_ (u"ࠨࠩⲶ"),l1l1l1_l1_ (u"ࠩࠪⲷ"),l11ll11_l1_)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲸ"),l1l1l1_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪⲹ")+l1llll11l1l_l1_+l1l1l1_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠪⲺ")+l1111lll11_l1_,l1l1l1_l1_ (u"࠭ࠧⲻ"),409,l1l1l1_l1_ (u"ࠧࠨⲼ"),l1l1l1_l1_ (u"ࠨࠩⲽ"),l11ll11_l1_)
	return
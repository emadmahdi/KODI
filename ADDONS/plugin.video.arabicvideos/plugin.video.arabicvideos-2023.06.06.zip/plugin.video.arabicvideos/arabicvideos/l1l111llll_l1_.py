# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩḱ")
menu_name = l1l1l1_l1_ (u"ࠩࡢࡈࡗ࠽࡟ࠨḲ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬḳ"),l1l1l1_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬḴ"),l1l1l1_l1_ (u"ࠬะำอ์็ࠫḵ")]
def MAIN(mode,url,text):
	if   mode==680: results = MENU()
	elif mode==681: results = l11l11_l1_(url,text)
	elif mode==682: results = PLAY(url)
	elif mode==683: results = l11_l1_(url,text)
	elif mode==684: results = l1ll11_l1_(url)
	elif mode==689: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪḶ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨḷ"),l1l1l1_l1_ (u"ࠨࠩḸ"),l1l1l1_l1_ (u"ࠩࠪḹ"),l1l1l1_l1_ (u"ࠪࠫḺ"),l1l1l1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧḻ"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḼ"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ḽ"),l1l1l1_l1_ (u"ࠧࠨḾ"),689,l1l1l1_l1_ (u"ࠨࠩḿ"),l1l1l1_l1_ (u"ࠩࠪṀ"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṁ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩṂ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬṃ"),l1l1l1_l1_ (u"࠭ࠧṄ"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṅ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪṆ")+menu_name+l1l1l1_l1_ (u"ࠩส่๊๋๊ำหࠪṇ"),l1l11l_l1_,681,l1l1l1_l1_ (u"ࠪࠫṈ"),l1l1l1_l1_ (u"ࠫࠬṉ"),l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧṊ"))
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ṋ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩṌ")+menu_name+l1l1l1_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧṍ"),l1l11l_l1_,681,l1l1l1_l1_ (u"ࠩࠪṎ"),l1l1l1_l1_ (u"ࠪࠫṏ"),l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨṐ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṑ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨṒ")+menu_name+l1l1l1_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ṓ"),l1l11l_l1_,681,l1l1l1_l1_ (u"ࠨࠩṔ"),l1l1l1_l1_ (u"ࠩࠪṕ"),l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩṖ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṗ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧṘ")+menu_name+l1l1l1_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪṙ"),l1l11l_l1_,681,l1l1l1_l1_ (u"ࠧࠨṚ"),l1l1l1_l1_ (u"ࠨࠩṛ"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫṜ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨṝ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫṞ"),l1l1l1_l1_ (u"ࠬ࠭ṟ"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫṠ"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨṡ"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṢ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫṣ")+menu_name+title,l111ll_l1_,684)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨṤ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫṥ"),l1l1l1_l1_ (u"ࠬ࠭Ṧ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪṧ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧṨ"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠨࠩṩ"))
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧṪ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪṫ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭Ṭ")+menu_name+title,l111ll_l1_,684)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩṭ"),url,l1l1l1_l1_ (u"࠭ࠧṮ"),l1l1l1_l1_ (u"ࠧࠨṯ"),l1l1l1_l1_ (u"ࠨࠩṰ"),l1l1l1_l1_ (u"ࠩࠪṱ"),l1l1l1_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩṲ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨṳ"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭Ṵ"),l1l1l1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬṵ"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫṶ"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠨࠩṷ"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧṸ"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨṹ"),l1l1l1_l1_ (u"ࠫࠬṺ"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪṻ"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"࠭࠺ࠡࠩṼ")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṽ"),menu_name+title,l111ll_l1_,681)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬṾ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫṿ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨẀ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫẁ"),l1l1l1_l1_ (u"ࠬ࠭Ẃ"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẃ"),menu_name+title,l111ll_l1_,681)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠧࠨẄ")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩẅ"),l1l1l1_l1_ (u"ࠩࠪẆ"),request,url)
	if request==l1l1l1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨẇ"):
		url,search = url.split(l1l1l1_l1_ (u"ࠫࡄ࠭Ẉ"),1)
		data = l1l1l1_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫẉ")+search
		headers = {l1l1l1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬẊ"):l1l1l1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧẋ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭Ẍ"),url,data,headers,l1l1l1_l1_ (u"ࠩࠪẍ"),l1l1l1_l1_ (u"ࠪࠫẎ"),l1l1l1_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩẏ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩẐ"),url,l1l1l1_l1_ (u"࠭ࠧẑ"),l1l1l1_l1_ (u"ࠧࠨẒ"),l1l1l1_l1_ (u"ࠨࠩẓ"),l1l1l1_l1_ (u"ࠩࠪẔ"),l1l1l1_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨẕ"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠫࠬẖ"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩẗ"))
	if request==l1l1l1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫẘ"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩẙ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠨࠩẚ"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫẛ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫẜ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪẝ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬẞ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪẟ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧẠ"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪạ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫẢ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬả"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠫࠬẤ"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ấ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧẦ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ࠧๆึส๋ิฯࠧầ"),l1l1l1_l1_ (u"ࠨใํ่๊࠭Ẩ"),l1l1l1_l1_ (u"ࠩส฾๋๐ษࠨẩ"),l1l1l1_l1_ (u"ࠪ็้๐ศࠨẪ"),l1l1l1_l1_ (u"ࠫฬ฿ไศ่ࠪẫ"),l1l1l1_l1_ (u"ࠬํฯศใࠪẬ"),l1l1l1_l1_ (u"࠭ๅษษิหฮ࠭ậ"),l1l1l1_l1_ (u"ฺࠧำูࠫẮ"),l1l1l1_l1_ (u"ࠨ็๊ีัอๆࠨắ"),l1l1l1_l1_ (u"ࠩส่อ๎ๅࠨẰ"),l1l1l1_l1_ (u"ุ้ࠪือ๋หࠪằ")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠫ࠴࠭Ẳ"))
		#if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪẳ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨẴ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩẵ"))
		#if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭Ặ") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫặ")+img.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬẸ"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭ẹ"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨẺ"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬẻ"),menu_name+title,l111ll_l1_,682,img)
		elif request==l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭Ẽ"):
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧẽ"),menu_name+title,l111ll_l1_,682,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨẾ") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪế"),menu_name+title,l111ll_l1_,683,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩỀ") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬề"),menu_name+title,l111ll_l1_,681,img)
		else: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ể"),menu_name+title,l111ll_l1_,683,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ể"),l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪỄ")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪễ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨỆ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠫࠨ࠭ệ"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧỈ")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨỉ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỊ"),menu_name+l1l1l1_l1_ (u"ࠨืไัฮࠦࠧị")+title,l111ll_l1_,681)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪỌ"),l1l1l1_l1_ (u"ࠪࠫọ"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨỎ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩỏ"),url,l1l1l1_l1_ (u"࠭ࠧỐ"),l1l1l1_l1_ (u"ࠧࠨố"),l1l1l1_l1_ (u"ࠨࠩỒ"),l1l1l1_l1_ (u"ࠩࠪồ"),l1l1l1_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪỔ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧổ"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧỖ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"࠭ࠧỗ")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࠨࠩࡲࡲࡨࡲࡩࡤ࡭ࡀࠦࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ࠭ࠧỘ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠨࠥࠪộ"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩỚ"),menu_name+title,url,683,img,l1l1l1_l1_ (u"ࠪࠫớ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩỜ")+l1lll_l1_+l1l1l1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪờ"),html,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧỞ"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ở"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࠪỠ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩ࠲ࠫỡ"))
			title = title.replace(l1l1l1_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨỢ"),l1l1l1_l1_ (u"ࠫࠥ࠭ợ"))
			addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫỤ"),menu_name+title,l111ll_l1_,682,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧụ"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࠬỦ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࠪủ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩ࠲ࠫỨ"))
		#		addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩứ"),menu_name+title,l111ll_l1_,682,img)
	return
def PLAY(url):
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨỪ"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩừ"),url,l1l1l1_l1_ (u"࠭ࠧỬ"),l1l1l1_l1_ (u"ࠧࠨử"),l1l1l1_l1_ (u"ࠨࠩỮ"),l1l1l1_l1_ (u"ࠩࠪữ"),l1l1l1_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭Ự"))
	html = response.content
	# l11111_l1_ page
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪự"),html,re.DOTALL)
	l111ll_l1_ = l111ll_l1_[0]
	l1111l_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠬࡶ࡯ࡴࡶࡀࠫỲ"))[1]
	l1111l_l1_ = base64.b64decode(l1111l_l1_)
	l1111l_l1_ = l1111l_l1_.replace(l1l1l1_l1_ (u"࠭࡜࠰ࠩỳ"),l1l1l1_l1_ (u"ࠧ࠰ࠩỴ"))
	l1111l_l1_ = EVAL(l1l1l1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭ỵ"),l1111l_l1_)
	l1ll_l1_ = l1111l_l1_[l1l1l1_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡵࠪỶ")]
	titles = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	zzz = zip(titles,l1ll_l1_)
	for title,l111ll_l1_ in zzz:
		l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫỷ")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬỸ")
		l11l1_l1_.append(l111ll_l1_)
	l1l1l1_l1_ (u"ࠧࠨࠢࠋࠋࠦ࡭࡫ࠦ࡬ࡪࡰ࡮ࠤࡦࡴࡤࠡࠩ࡫ࡸࡹࡶࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠ࡭࡫ࡱ࡯ࠥࡃࠠࠨࡪࡷࡸࡵࡀࠧࠬ࡮࡬ࡲࡰࠐࠉࡩࡣࡶ࡬ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡹࡰ࡭࡫ࡷࠬࠬ࡮ࡡࡴࡪࡀࠫ࠮ࡡ࠱࡞ࠌࠌࡴࡦࡸࡴࡴࠢࡀࠤ࡭ࡧࡳࡩ࠰ࡶࡴࡱ࡯ࡴࠩࠩࡢࡣࠬ࠯ࠊࠊࡰࡨࡻࡤࡶࡡࡳࡶࡶࠤࡂ࡛ࠦ࡞ࠌࠌࡪࡴࡸࠠࡱࡣࡵࡸࠥ࡯࡮ࠡࡲࡤࡶࡹࡹ࠺ࠋࠋࠌࡸࡷࡿ࠺ࠋࠋࠌࠍࡵࡧࡲࡵࠢࡀࠤࡧࡧࡳࡦ࠸࠷࠲ࡧ࠼࠴ࡥࡧࡦࡳࡩ࡫ࠨࡱࡣࡵࡸ࠰࠭࠽ࠨࠫࠍࠍࠎࠏࡩࡧࠢ࡮ࡳࡩ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠿࠳࠻࠲࠾࠿࠺ࠡࡲࡤࡶࡹࠦ࠽ࠡࡲࡤࡶࡹ࠴ࡤࡦࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࠋࠌࡲࡪࡽ࡟ࡱࡣࡵࡸࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡰࡢࡴࡷ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࠩࡁࠫ࠳ࡰ࡯ࡪࡰࠫࡲࡪࡽ࡟ࡱࡣࡵࡸࡸ࠯ࠊࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢ࡯࡭ࡳࡱࡳ࠯ࡵࡳࡰ࡮ࡺ࡬ࡪࡰࡨࡷ࠭࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠵ࠤ࡮ࡴࠠࡻࡼࡽ࠾ࠏࠏࠉࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠶࠳ࡹࡰ࡭࡫ࡷࠬࠬࠦ࠽࠿ࠢࠪ࠭ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥỹ")
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫỺ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ỻ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠨࠩỼ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠩࠪỽ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬỾ"),l1l1l1_l1_ (u"ࠫ࠰࠭ỿ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ἀ")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ἁ"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫἂ")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ἃ"))
	return
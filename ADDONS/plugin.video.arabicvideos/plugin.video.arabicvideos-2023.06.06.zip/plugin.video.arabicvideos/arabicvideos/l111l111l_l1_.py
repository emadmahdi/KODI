# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩᕁ")
headers = {l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᕂ"):l1l1l1_l1_ (u"ࠫࠬᕃ")}
menu_name = l1l1l1_l1_ (u"ࠬࡥࡃ࠵ࡗࡢࠫᕄ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪᕅ"),l1l1l1_l1_ (u"ࠧศะิ๎ࠬᕆ"),l1l1l1_l1_ (u"ࠨษัี๎࠭ᕇ"),l1l1l1_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᕈ"),l1l1l1_l1_ (u"ࠪฬิ๎ๆࠡวัฮ๏อัࠨᕉ"),l1l1l1_l1_ (u"ࠫฬ็ไศ็ࠪᕊ"),l1l1l1_l1_ (u"๋ࠬำๅี็หฯ࠭ᕋ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l11l11_l1_(url,text)
	elif mode==422: results = l1llllll11_l1_(url)
	elif mode==423: results = l11l1ll_l1_(url)
	elif mode==424: results = l1111l1_l1_(url,l1l1l1_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬᕌ")+text)
	elif mode==425: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ᕍ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l1111l1l1_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l11111111_l1_(l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬᕎ"),l1l11l_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪᕏ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᕐ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬᕑ"),l1l1l1_l1_ (u"ࠬ࠭ᕒ"),l1l1l1_l1_ (u"࠭ࠧᕓ"),l1l1l1_l1_ (u"ࠧࠨᕔ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᕕ"))
	html = response.content
	l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕖ"),html,re.DOTALL)
	l11l1l_l1_ = l11l1l_l1_[0].strip(l1l1l1_l1_ (u"ࠪ࠳ࠬᕗ"))
	l11l1l_l1_ = SERVER(l11l1l_l1_,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨᕘ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕙ"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᕚ"),l1l1l1_l1_ (u"ࠧࠨᕛ"),429,l1l1l1_l1_ (u"ࠨࠩᕜ"),l1l1l1_l1_ (u"ࠩࠪᕝ"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᕞ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᕟ"),menu_name+l1l1l1_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨᕠ"),l11l1l_l1_,425)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᕡ"),menu_name+l1l1l1_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪᕢ"),l11l1l_l1_,424)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᕣ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᕤ"),l1l1l1_l1_ (u"ࠪࠫᕥ"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᕦ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᕧ")+menu_name+l1l1l1_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᕨ"),l11l1l_l1_,421)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕩ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᕪ")+menu_name+l1l1l1_l1_ (u"ࠩฦๅ้อๅࠡษ็๊ั๎ๅࠨᕫ"),l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶ࠳ࠬᕬ"),421)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᕭ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᕮ")+menu_name+l1l1l1_l1_ (u"࠭ๆ๋ฬไู่่ࠧᕯ"),l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡰࡨࡸ࡫ࡲࡩࡹ࠱ࠪᕰ"),421)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᕱ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬࡁࠬ࠳࠰࠿ࠪ࠾ࠪᕲ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		if l1l1l1_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶࠫᕳ") in l111ll_l1_: title = l1l1l1_l1_ (u"ࠫศ็ไศ็ࠣห้์ฬ้็ࠪᕴ")
		elif l1l1l1_l1_ (u"ࠬ࠵࡮ࡦࡶࡩࡰ࡮ࡾࠧᕵ") in l111ll_l1_: title = l1l1l1_l1_ (u"࠭รโๆส้ࠥ๎ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨᕶ")
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕷ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᕸ")+menu_name+title,l111ll_l1_,421)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕹ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᕺ")+menu_name+l1l1l1_l1_ (u"ࠫ็อฦๆหࠣฮๆ฻๊ๅ์ฬࠫᕻ"),l11l1l_l1_,427)
	return
def l1111l1l1_l1_(website=l1l1l1_l1_ (u"ࠬ࠭ᕼ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪᕽ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨᕾ"),l1l1l1_l1_ (u"ࠨࠩᕿ"),l1l1l1_l1_ (u"ࠩࠪᖀ"),l1l1l1_l1_ (u"ࠪࠫᖁ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᖂ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡕ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᖃ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪࠤ࠭ࠤࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠭ࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿ࠫᖄ"),block,re.DOTALL)
	for category,id,l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		if l1l1l1_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸ࠮࡯ࡲࡺ࡮࡫ࡳࠨᖅ") in l111ll_l1_: title = l1l1l1_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨᖆ")
		elif l1l1l1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴ࠯ࡱࡩࡹ࡬࡬ࡪࡺࠪᖇ") in l111ll_l1_: title = l1l1l1_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬᖈ")
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖉ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᖊ")+menu_name+title,l111ll_l1_,421,l1l1l1_l1_ (u"࠭ࠧᖋ"),l1l1l1_l1_ (u"ࠧࠨᖌ"),category+l1l1l1_l1_ (u"ࠨࡾࠪᖍ")+id)
	return
def l11l11_l1_(url,l111l1111_l1_=l1l1l1_l1_ (u"ࠩࠪᖎ")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫᖏ"),l1l1l1_l1_ (u"ࠫࠬᖐ"),l111l1111_l1_,url)
	if l1l1l1_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᖑ") in url: url = url.strip(l1l1l1_l1_ (u"࠭࠯ࠨᖒ"))+l1l1l1_l1_ (u"ࠧ࠰࡯ࡳࡥࡦ࠵ࡦࡢ࡯࡬ࡰࡾ࠵ࠧᖓ")
	items = []
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬᖔ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ᖕ"),url,l1l1l1_l1_ (u"ࠪࠫᖖ"),headers,l1l1l1_l1_ (u"ࠫࠬᖗ"),l1l1l1_l1_ (u"ࠬ࠭ᖘ"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᖙ"))
	html = response.content
	if not l111l1111_l1_ or l1l1l1_l1_ (u"ࠧࡽࠩᖚ") in l111l1111_l1_:
		#if l1l1l1_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠭ᖛ") in html:
		#	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖜ"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᖝ"),url,425)
		#	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖞ"),menu_name+l1l1l1_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᖟ"),url,424)
		#	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᖠ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖡ"),l1l1l1_l1_ (u"ࠨࠩᖢ"),9999)
		if l1l1l1_l1_ (u"ࠩࡿࠫᖣ") not in l111l1111_l1_: l1111l11l_l1_ = l1l1l1_l1_ (u"ࠪࠫᖤ")
		else: l1111l11l_l1_ = l1l1l1_l1_ (u"ࠫ࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠵ࠧᖥ")+l111l1111_l1_
		l1llllll1l_l1_ = False
		if l1l1l1_l1_ (u"ࠬࡖࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠨᖦ") in html:
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖧ"),menu_name+l1l1l1_l1_ (u"ࠧศๆ่้๏ุษࠨᖨ"),url,421,l1l1l1_l1_ (u"ࠨࠩᖩ"),l1l1l1_l1_ (u"ࠩࠪᖪ"),l1l1l1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᖫ"))
			l1llllll1l_l1_ = True
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠩᖬ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			l11ll_l1_ = l1ll1l1_l1_[0]
			l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡨ࠽ࠣࠬࠫ࠲࠯ࡅࠩࠣࠬ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫᖭ"),l11ll_l1_,re.DOTALL)
			for l11111lll_l1_,title2 in l1ll1ll_l1_:
				l11111ll1_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡨ࡫࡮ࡵࡧࡵ࠳ࡦࡩࡴࡪࡱࡱ࠳ࡍࡵ࡭ࡦࡲࡤ࡫ࡪࡒ࡯ࡢࡦࡨࡶ࠴ࡺࡡࡣ࠱ࠪᖮ")+l11111lll_l1_+l1111l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩᖯ")
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖰ"),menu_name+title2,l11111ll1_l1_,421)
				l1llllll1l_l1_ = True
		if l1llllll1l_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᖱ"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖲ"),l1l1l1_l1_ (u"ࠫࠬᖳ"),9999)
	if l111l1111_l1_==l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᖴ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡍࡶ࡮ࡷ࡭ࡋ࡯࡬ࡵࡧࡵࠫᖵ"),html,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡑ࡫ࡱࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪᖶ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		else: block = l1l1l1_l1_ (u"ࠨࠩᖷ")
	elif l1l1l1_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬᖸ") in url or l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡧࡪࡴࡴࡦࡴ࠲ࠫᖹ") in url:
		block = html
	elif l1l1l1_l1_ (u"ࠫ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭ᖺ") in url:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡖࡡࡨࡧࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠫࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠰ࠧᖻ"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
	elif l1l1l1_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷࡹࠧᖼ") in url:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࠭ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠫࠩᖽ"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠯࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᖾ"),block,re.DOTALL)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡆ࡭ࡲࡧ࠴ࡶࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿ࠩᖿ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		else: block = l1l1l1_l1_ (u"ࠪࠫᗀ")
	if not items: items = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࠯ࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠭࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࡠࠨ࠾࡞࠭࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠲࠯ࡅࡂࡰࡺࡗ࡭ࡹࡲࡥࡊࡰࡩࡳ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀࠬᗁ"),block,re.DOTALL)
	if not items: items = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡓ࡯ࡷ࡫ࡨࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᗂ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l111ll_l1_,img,title in items:
		if not title: continue
		if l1l1l1_l1_ (u"࠭࠿࡯ࡧࡺࡷࡂ࠭ᗃ") in l111ll_l1_: continue
		title = title.replace(l1l1l1_l1_ (u"ࠧๆึส๋ิฯࠠࠨᗄ"),l1l1l1_l1_ (u"ࠨࠩᗅ"))
		title = unescapeHTML(title)
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪᗆ"),title,re.DOTALL)
		if l1llll1_l1_ and l1l1l1_l1_ (u"ࠪั้่ษࠨᗇ") in title:
			title = l1l1l1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᗈ") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗉ"),menu_name+title,l111ll_l1_,422,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠵ࠧᗊ") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗋ"),menu_name+title,l111ll_l1_,421,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗌ"),menu_name+title,l111ll_l1_,422,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᗍ"),html,re.DOTALL)
	if l1ll1l1_l1_ and l111l1111_l1_!=l1l1l1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᗎ"):
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࡠࠬࡢࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩ࡟ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᗏ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"ࠬอไึใะอࠥ࠭ᗐ"),l1l1l1_l1_ (u"࠭ࠧᗑ"))
			if title!=l1l1l1_l1_ (u"ࠧࠨᗒ"): addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗓ"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨᗔ")+title,l111ll_l1_,421)
	l1111ll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀ࠴ࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᗕ"),html,re.DOTALL)
	if l1111ll11_l1_:
		l111ll_l1_,title = l1111ll11_l1_[0]
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗖ"),menu_name+title,l111ll_l1_,421)
	return
def l1llllll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᗗ"),url,l1l1l1_l1_ (u"࠭ࠧᗘ"),l1l1l1_l1_ (u"ࠧࠨᗙ"),l1l1l1_l1_ (u"ࠨࠩᗚ"),l1l1l1_l1_ (u"ࠩࠪᗛ"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨᗜ"))
	html = response.content
	# l1l1111ll_l1_/download main l11lll1l_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡑࡳࡼࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᗝ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		url = l1ll1l1_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᗞ"),url,l1l1l1_l1_ (u"࠭ࠧᗟ"),l1l1l1_l1_ (u"ࠧࠨᗠ"),l1l1l1_l1_ (u"ࠨࠩᗡ"),l1l1l1_l1_ (u"ࠩࠪᗢ"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠷ࡴࡤࠨᗣ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᗤ"),l1l1l1_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᗥ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡓࡦࡣࡶࡳࡳࡹࡓࡦࡥࡷ࡭ࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪᗦ"),html,re.DOTALL)
	# l1lllllll1_l1_ l1111l111_l1_
	if l1l1l1_l1_ (u"ࠧ࠰ࡶࡤ࡫࠴࠭ᗧ") in url or l1l1l1_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࠨᗨ") in url:
		l11l11_l1_(url)
	# l111l1_l1_
	elif l1ll1l1_l1_:
		img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪᗩ"))
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤᗪ"),block,re.DOTALL)
		l1111111l_l1_ = [l1l1l1_l1_ (u"ู๊ࠫไิๆࠪᗫ"),l1l1l1_l1_ (u"๋่ࠬิ็ࠪᗬ"),l1l1l1_l1_ (u"࠭ศา่ส้ั࠭ᗭ"),l1l1l1_l1_ (u"ࠧฮๆๅอࠬᗮ")]
		for l111ll_l1_,title in items:
			if any(value in title for value in l1111111l_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗯ"),menu_name+title,l111ll_l1_,423,img)
			else: addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᗰ"),menu_name+title,l111ll_l1_,426,img)
	else: l11l1ll_l1_(url)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᗱ"),url,l1l1l1_l1_ (u"ࠫࠬᗲ"),l1l1l1_l1_ (u"ࠬ࠭ᗳ"),l1l1l1_l1_ (u"࠭ࠧᗴ"),l1l1l1_l1_ (u"ࠧࠨᗵ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᗶ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᗷ"),l1l1l1_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᗸ"))
	img = re.findall(l1l1l1_l1_ (u"ࠫࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧᗹ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = l1l1l1_l1_ (u"ࠬ࠭ᗺ")
	# l1ll1_l1_
	l1l1lll11_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡔࡧࡦࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᗻ"),html,re.DOTALL)
	if l1l1lll11_l1_:
		block = l1l1lll11_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫᗼ"),block,re.DOTALL)
		for l111ll_l1_,title,l1llll1_l1_ in items:
			title = title+l1l1l1_l1_ (u"ࠨࠢࠪᗽ")+l1llll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᗾ"),menu_name+title,l111ll_l1_,426,img)
	else: addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᗿ"),menu_name+l1l1l1_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪᘀ"),url,426,img)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᘁ"),url,l1l1l1_l1_ (u"࠭ࠧᘂ"),headers,l1l1l1_l1_ (u"ࠧࠨᘃ"),l1l1l1_l1_ (u"ࠨࠩᘄ"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᘅ"))
	html = response.content
	#newurl = re.findall(l1l1l1_l1_ (u"ࠪࠦࡸࡺࡹ࡭ࡧࡶ࡬ࡪ࡫ࡴࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᘆ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᘇ"))
	l11l1l_l1_ = SERVER(newurl,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩᘈ"))
	l11l1_l1_ = []
	# l1l1111ll_l1_ l1ll_l1_
	#if kodi_version>18.99: html = html.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᘉ"),l1l1l1_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᘊ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡙ࡤࡸࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪᘋ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠢࠡ࠱ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᘌ"),block,re.DOTALL)
		for l1l11lll_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬᘍ"))
			if l1l1l1_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪᘎ") in title.lower(): title = l1l1l1_l1_ (u"ࠬิวึࠢࠪᘏ")+title
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࡴࡶࡵࡹࡨࡺࡵࡳࡧ࠲ࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫᘐ")+l1l11lll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᘑ")+title+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᘒ")
			#l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡢ࠶ࡸ࠲࡮ࡩࡵࠨᘓ"),l1l1l1_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷ࠱ࡱࡽ࠭ᘔ"))
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩᘕ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦࠧࠦ࠯࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘖ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨᘗ"))
			if l1l1l1_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭ᘘ") in title.lower(): title2 = l1l1l1_l1_ (u"ࠨࡡࡢาฬ฻ࠧᘙ")
			else: title2 = l1l1l1_l1_ (u"ࠩࠪᘚ")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᘛ")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᘜ")+title2
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᘝ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᘞ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨᘟ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩᘠ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫᘡ"),l1l1l1_l1_ (u"ࠪ࠯ࠬᘢ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭ᘣ")+search+l1l1l1_l1_ (u"ࠬ࠵ࠧᘤ")
	l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᘥ"))
	return
# ===========================================
#     l1111llll_l1_ l111111l1_l1_ l1llllllll_l1_
# ===========================================
def l1111lll1_l1_(url):
	if l1l1l1_l1_ (u"ࠧࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩᘦ") not in url: url = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬᘧ"))
	else: url = url.split(l1l1l1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᘨ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᘩ"),url,l1l1l1_l1_ (u"ࠫࠬᘪ"),l1l1l1_l1_ (u"ࠬ࠭ᘫ"),l1l1l1_l1_ (u"࠭ࠧᘬ"),l1l1l1_l1_ (u"ࠧࠨᘭ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪᘮ"))
	html = response.content
	# all l1l11l1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᘯ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	# name + options block + category
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡌࡴࡼࡥࡳࡣࡥࡰࡪ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࠤࡤࡰࡱࠨ࠮ࠫࡁࠫࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᘰ"),block,re.DOTALL)
	return l11111l_l1_
def l111111ll_l1_(block):
	# id + title
	items = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᘱ"),block,re.DOTALL)
	return items
def l1111l1ll_l1_(url):
	l11111l1l_l1_ = url.split(l1l1l1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᘲ"))[0]
	l11111l11_l1_ = SERVER(url,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪᘳ"))
	url = url.replace(l11111l1l_l1_,l11111l11_l1_)
	url = url.replace(l1l1l1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᘴ"),l1l1l1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᘵ"))
	url = url.replace(l1l1l1_l1_ (u"ࠩࡀࠫᘶ"),l1l1l1_l1_ (u"ࠪ࠳ࠬᘷ")).replace(l1l1l1_l1_ (u"ࠫࠫ࠭ᘸ"),l1l1l1_l1_ (u"ࠬ࠵ࠧᘹ"))
	url = url+l1l1l1_l1_ (u"࠭࠯ࠨᘺ")
	return url
l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᘻ"),l1l1l1_l1_ (u"ࠨࡶࡼࡴࡪࡹࠧᘼ"),l1l1l1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᘽ")]
l1lll1ll_l1_ = [l1l1l1_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᘾ"),l1l1l1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᘿ"),l1l1l1_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᙀ"),l1l1l1_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᙁ")]
def l1111l1_l1_(url,filter):
	#filter = filter.replace(l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᙂ"),l1l1l1_l1_ (u"ࠨࠩᙃ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪᙄ"),l1l1l1_l1_ (u"ࠪࠫᙅ"),filter,url)
	if l1l1l1_l1_ (u"ࠫࡄ࠭ᙆ") in url: url = url.split(l1l1l1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᙇ"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪᙈ"),1)
	if filter==l1l1l1_l1_ (u"ࠧࠨᙉ"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠨࠩᙊ"),l1l1l1_l1_ (u"ࠩࠪᙋ")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧᙌ"))
	if type==l1l1l1_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᙍ"):
		if l1l1l1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᙎ") in url:
			global l1l1lll1_l1_
			l1l1lll1_l1_ = l1l1lll1_l1_[1:]
		if l1l1lll1_l1_[0]+l1l1l1_l1_ (u"࠭࠽ࠨᙏ") not in l1l1ll11_l1_: category = l1l1lll1_l1_[0]
		for i in range(len(l1l1lll1_l1_[0:-1])):
			if l1l1lll1_l1_[i]+l1l1l1_l1_ (u"ࠧ࠾ࠩᙐ") in l1l1ll11_l1_: category = l1l1lll1_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠨࠨࠪᙑ")+category+l1l1l1_l1_ (u"ࠩࡀ࠴ࠬᙒ")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠪࠪࠬᙓ")+category+l1l1l1_l1_ (u"ࠫࡂ࠶ࠧᙔ")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠬࠬࠧᙕ"))+l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪᙖ")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠧࠧࠩᙗ"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᙘ"))
		url2 = url+l1l1l1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᙙ")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ᙚ"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᙛ"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠬ࠭ᙜ"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᙝ"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠧࠨᙞ"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᙟ")+l1l1l1ll_l1_
		url2 = l1111l1ll_l1_(url2)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙠ"),menu_name+l1l1l1_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ᙡ"),url2,421,l1l1l1_l1_ (u"ࠫࠬᙢ"),l1l1l1_l1_ (u"ࠬ࠭ᙣ"),l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᙤ"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙥ"),menu_name+l1l1l1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨᙦ")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨᙧ"),url2,421,l1l1l1_l1_ (u"ࠪࠫᙨ"),l1l1l1_l1_ (u"ࠫࠬᙩ"),l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᙪ"))
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᙫ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᙬ"),l1l1l1_l1_ (u"ࠨࠩ᙭"),9999)
	l11111l_l1_ = l1111lll1_l1_(url)
	dict = {}
	for name,block,l1llllll_l1_ in l11111l_l1_:
		if l1l1l1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭᙮") in url and l1llllll_l1_==l1l1l1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᙯ"): continue
		name = name.replace(l1l1l1_l1_ (u"ࠫ࠲࠳ࠧᙰ"),l1l1l1_l1_ (u"ࠬ࠭ᙱ"))
		items = l111111ll_l1_(block)
		if l1l1l1_l1_ (u"࠭࠽ࠨᙲ") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᙳ"):
			if category!=l1llllll_l1_: continue
			elif len(items)<2:
				if l1llllll_l1_==l1l1lll1_l1_[-1]:
					url = l1111l1ll_l1_(url)
					l11l11_l1_(url)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧᙴ")+l1ll1111_l1_)
				return
			else:
				url2 = l1111l1ll_l1_(url2)
				if l1llllll_l1_==l1l1lll1_l1_[-1]: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙵ"),menu_name+l1l1l1_l1_ (u"ࠪห้าๅ๋฻ࠪᙶ"),url2,421,l1l1l1_l1_ (u"ࠫࠬᙷ"),l1l1l1_l1_ (u"ࠬ࠭ᙸ"),l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᙹ"))
				else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙺ"),menu_name+l1l1l1_l1_ (u"ࠨษ็ะ๊๐ูࠨᙻ"),url2,425,l1l1l1_l1_ (u"ࠩࠪᙼ"),l1l1l1_l1_ (u"ࠪࠫᙽ"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧᙾ"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠧᙿ")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽࠱ࠩ ")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠩᚁ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿࠳ࠫᚂ")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭ᚃ")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᚄ"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ᚅ")+name,url2,424,l1l1l1_l1_ (u"ࠬ࠭ᚆ"),l1l1l1_l1_ (u"࠭ࠧᚇ"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᚈ"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			if value==l1l1l1_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨᚉ"): option = l1l1l1_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩᚊ")
			elif value==l1l1l1_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪᚋ"): option = l1l1l1_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭ᚌ")
			if option in l1l1ll_l1_: continue
			#if l1l1l1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᚍ") not in value: value = option
			#else: value = re.findall(l1l1l1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚎ"),value,re.DOTALL)[0]
			dict[l1llllll_l1_][value] = option
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠧࠧࠩᚏ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿ࠪᚐ")+option
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠩࠩࠫᚑ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡁࠬᚒ")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨᚓ")+l1ll1ll1_l1_
			title = option+l1l1l1_l1_ (u"ࠬࠦ࠺ࠨᚔ")#+dict[l1llllll_l1_][l1l1l1_l1_ (u"࠭࠰ࠨᚕ")]
			title = option+l1l1l1_l1_ (u"ࠧࠡ࠼ࠪᚖ")+name
			if type==l1l1l1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫᚗ"): addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᚘ"),menu_name+title,url,424,l1l1l1_l1_ (u"ࠪࠫᚙ"),l1l1l1_l1_ (u"ࠫࠬᚚ"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ᚛"))
			elif type==l1l1l1_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ᚜") and l1l1lll1_l1_[-2]+l1l1l1_l1_ (u"ࠧ࠾ࠩ᚝") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ᚞"))
				url3 = url+l1l1l1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭᚟")+l1l1l111_l1_
				url3 = l1111l1ll_l1_(url3)
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᚠ"),menu_name+title,url3,421,l1l1l1_l1_ (u"ࠫࠬᚡ"),l1l1l1_l1_ (u"ࠬ࠭ᚢ"),l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᚣ"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚤ"),menu_name+title,url,425,l1l1l1_l1_ (u"ࠨࠩᚥ"),l1l1l1_l1_ (u"ࠩࠪᚦ"),l1lllll1_l1_)
	return
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫᚧ"),l1l1l1_l1_ (u"ࠫࠬᚨ"),filters,l1l1l1_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭ᚩ"))
	# mode==l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᚪ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᚫ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠨࡣ࡯ࡰࠬᚬ")					all l1ll11ll_l1_ & l1111ll1l_l1_ filters
	filters = filters.replace(l1l1l1_l1_ (u"ࠩࡀࠪࠬᚭ"),l1l1l1_l1_ (u"ࠪࡁ࠵ࠬࠧᚮ"))
	filters = filters.strip(l1l1l1_l1_ (u"ࠫࠫ࠭ᚯ"))
	l1l1ll1l_l1_ = {}
	if l1l1l1_l1_ (u"ࠬࡃࠧᚰ") in filters:
		items = filters.split(l1l1l1_l1_ (u"࠭ࠦࠨᚱ"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠧ࠾ࠩᚲ"))
			l1l1ll1l_l1_[var] = value
	l1llll1l_l1_ = l1l1l1_l1_ (u"ࠨࠩᚳ")
	for key in l1lll1ll_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠩ࠳ࠫᚴ")
		if l1l1l1_l1_ (u"ࠪࠩࠬᚵ") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᚶ") and value!=l1l1l1_l1_ (u"ࠬ࠶ࠧᚷ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"࠭ࠠࠬࠢࠪᚸ")+value
		elif mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᚹ") and value!=l1l1l1_l1_ (u"ࠨ࠲ࠪᚺ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠩࠩࠫᚻ")+key+l1l1l1_l1_ (u"ࠪࡁࠬᚼ")+value
		elif mode==l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࠨᚽ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠬࠬࠧᚾ")+key+l1l1l1_l1_ (u"࠭࠽ࠨᚿ")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠧࠡ࠭ࠣࠫᛀ"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠨࠨࠪᛁ"))
	l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"ࠩࡀ࠴ࠬᛂ"),l1l1l1_l1_ (u"ࠪࡁࠬᛃ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬᛄ"),l1l1l1_l1_ (u"ࠬ࠭ᛅ"),filters,l1l1l1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᛆ"))
	return l1llll1l_l1_
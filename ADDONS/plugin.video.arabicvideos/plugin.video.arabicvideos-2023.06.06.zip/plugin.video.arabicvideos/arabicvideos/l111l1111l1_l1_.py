# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ坑")
menu_name = l1l1l1_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩ坒")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠫอัࠠๆสสุึ࠭坓")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l11l11_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l11l1ll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ坔"),l1l11l_l1_,l1l1l1_l1_ (u"࠭ࠧ坕"),l1l1l1_l1_ (u"ࠧࠨ坖"),l1l1l1_l1_ (u"ࠨࠩ块"),l1l1l1_l1_ (u"ࠩࠪ坘"),l1l1l1_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ坙"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坚"),menu_name+l1l1l1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ坛"),l1l1l1_l1_ (u"࠭ࠧ坜"),469,l1l1l1_l1_ (u"ࠧࠨ坝"),l1l1l1_l1_ (u"ࠨࠩ坞"),l1l1l1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭坟"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坠"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭坡")+menu_name+l1l1l1_l1_ (u"ࠬษฮาࠢส่า๊โศฬࠪ坢"),l1l11l_l1_,461,l1l1l1_l1_ (u"࠭ࠧ坣"),l1l1l1_l1_ (u"ࠧࠨ坤"),l1l1l1_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ坥"))
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ坦"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ坧"),l1l1l1_l1_ (u"ࠫࠬ坨"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨ࡭ࡦࡰࡸ࠱ࡧࡺ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ坩"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ坪"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#if l111ll_l1_==l1l1l1_l1_ (u"ࠧࠤࠩ坫"): continue
			if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭坬") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if title==l1l1l1_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ坭"): title = l1l1l1_l1_ (u"ࠪะิ๐ฯࠡฯ็ๆฬะࠠห์ไ๎ࠥ็ว็ࠩ坮")
			if title in l1l1ll_l1_: continue
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坯"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ坰")+menu_name+title,l111ll_l1_,461)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡇࡱࡲࡸࡪࡸࡃࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ坱"),html,re.DOTALL)
	#if l1ll1l1_l1_:
	#	block = l1ll1l1_l1_[0]
	#	items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭坲"),block,re.DOTALL)
	#	for l111ll_l1_,title in items:
	#		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ坳"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ坴")+menu_name+title,l111ll_l1_,461)
	return
def l11l11_l1_(url,l111l1111_l1_=l1l1l1_l1_ (u"ࠪࠫ坵")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ坶"),l1l1l1_l1_ (u"ࠬ࠭坷"),l111l1111_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ坸"),url,l1l1l1_l1_ (u"ࠧࠨ坹"),l1l1l1_l1_ (u"ࠨࠩ坺"),l1l1l1_l1_ (u"ࠩࠪ坻"),l1l1l1_l1_ (u"ࠪࠫ坼"),l1l1l1_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ坽"))
	html = response.content
	if l111l1111_l1_!=l1l1l1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ坾"): l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠨࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠨ坿"),html,re.DOTALL)
	else: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧฤะิࠤฬ๊อๅไสฮ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ垀"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ垁"),block,re.DOTALL)
		l1l1_l1_ = []
		l1111_l1_ = [l1l1l1_l1_ (u"ุ่ࠩฬํฯสࠩ垂"),l1l1l1_l1_ (u"ࠪๅ๏๊ๅࠨ垃"),l1l1l1_l1_ (u"ࠫฬเๆ๋หࠪ垄"),l1l1l1_l1_ (u"้ࠬไ๋สࠪ垅"),l1l1l1_l1_ (u"࠭วฺๆส๊ࠬ垆"),l1l1l1_l1_ (u"่ࠧัสๅࠬ垇"),l1l1l1_l1_ (u"ࠨ็หหึอษࠨ垈"),l1l1l1_l1_ (u"ࠩ฼ี฻࠭垉"),l1l1l1_l1_ (u"้ࠪ์ืฬศ่ࠪ垊"),l1l1l1_l1_ (u"ࠫฬ๊ศ้็ࠪ型")]
		for l111ll_l1_,title,img in items:
			if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ垌") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l111ll_l1_ = UNQUOTE(l111ll_l1_)	#.strip(l1l1l1_l1_ (u"࠭࠯ࠨ垍"))
			l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ垎"),title,re.DOTALL)
			if any(value in title for value in l1111_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ垏"),menu_name+title,l111ll_l1_,462,img)
			elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠩส่า๊โสࠩ垐") in title:
				title = l1l1l1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ垑") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垒"),menu_name+title,l111ll_l1_,463,img)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垓"),menu_name+title,l111ll_l1_,463,img)
	if l111l1111_l1_!=l1l1l1_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭垔"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ垕"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垖"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩࠣࠫ垗"))
				if l111ll_l1_==l1l1l1_l1_ (u"ࠥࠦ垘"): continue
				if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ垙") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
				#title = unescapeHTML(title)
				if title!=l1l1l1_l1_ (u"ࠬ࠭垚"): addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垛"),menu_name+l1l1l1_l1_ (u"ࠧึใะอࠥ࠭垜")+title,l111ll_l1_,461)
	return
def l11l1ll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ垝"),l1l1l1_l1_ (u"ࠩࠪ垞"),l1l1l1_l1_ (u"ࠪࡉࡕࡏࡓࡐࡆࡈࡗࠬ垟"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ垠"),url,l1l1l1_l1_ (u"ࠬ࠭垡"),l1l1l1_l1_ (u"࠭ࠧ垢"),l1l1l1_l1_ (u"ࠧࠨ垣"),l1l1l1_l1_ (u"ࠨࠩ垤"),l1l1l1_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ垥"))
	html = response.content
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦࠬ垦"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ垧"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ垨") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ垩"),menu_name+title,l111ll_l1_,462,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ垪"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垫"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩࠣࠫ垬"))
			if l111ll_l1_==l1l1l1_l1_ (u"ࠥࠦ垭"): continue
			if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ垮") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			#title = unescapeHTML(title)
			if title!=l1l1l1_l1_ (u"ࠬ࠭垯"): addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垰"),menu_name+l1l1l1_l1_ (u"ࠧึใะอࠥ࠭垱")+title,l111ll_l1_,463)
	return
def PLAY(url):
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ垲"),url,l1l1l1_l1_ (u"ࠩࠪ垳"),l1l1l1_l1_ (u"ࠪࠫ垴"),l1l1l1_l1_ (u"ࠫࠬ垵"),l1l1l1_l1_ (u"ࠬ࠭垶"),l1l1l1_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ垷"))
	html = response.content
	# l11ll1l1l_l1_ l111ll_l1_
	l11ll11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡕࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭垸"),html,re.DOTALL)
	if l11ll11l1l_l1_:
		l11ll11l1l_l1_ = l11ll11l1l_l1_[0]
		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭垹") not in l11ll11l1l_l1_:
			if l1l1l1_l1_ (u"ࠩ࠲࠳ࠬ垺") in l11ll11l1l_l1_: l11ll11l1l_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ垻")+l11ll11l1l_l1_
			else: l11ll11l1l_l1_ = l1l11l_l1_+l11ll11l1l_l1_
		l11ll11l1l_l1_ = l11ll11l1l_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ垼")
		l11l1_l1_.append(l11ll11l1l_l1_)
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡨ࠱࠶࠼ࡥࡩ࡫ࡵࡲࡦࠪ࠱࠮ࡄ࠯ࡳ࡮ࡣ࡯ࡰ࠳࠰࠿ࠣࡘ࡬ࡨࡪࡵࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡐ࡭ࡣࡼࠦࠬ垽"),html,re.DOTALL)
	if l1ll1l1_l1_:
		l1l11l1lll1l_l1_,l1l11l1llll1_l1_ = l1ll1l1_l1_[0]
		names = re.findall(l1l1l1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ垾"),l1l11l1lll1l_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠢࡴࡧࡷ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ垿"),l1l11l1llll1_l1_,re.DOTALL)
		l1l11l1lll11_l1_ = zip(names,l1ll_l1_)
		for name,l1ll1ll1ll1l_l1_ in l1l11l1lll11_l1_:
			l1ll1ll1ll1l_l1_ = l1ll1ll1ll1l_l1_[2:]
			if kodi_version<19: l1ll1ll1ll1l_l1_ = l1ll1ll1ll1l_l1_.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭埀"))
			l1ll1ll1ll1l_l1_ = base64.b64decode(l1ll1ll1ll1l_l1_)
			if kodi_version>18.99: l1ll1ll1ll1l_l1_ = l1ll1ll1ll1l_l1_.decode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ埁"))
			l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ埂"),l1ll1ll1ll1l_l1_,re.DOTALL)
			l111ll_l1_ = l111ll_l1_[0]
		if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ埃") not in l111ll_l1_:
			if l1l1l1_l1_ (u"ࠬ࠵࠯ࠨ埄") in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ埅")+l111ll_l1_
			else: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ埆")+name+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ埇")
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ埈"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ埉"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l1l1l1_l1_ (u"ࠫࠥ࠭埊") in search:
		if l111l_l1_: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭埋"),l1l1l1_l1_ (u"࠭ࠧ埌"),l1l1l1_l1_ (u"ࠧࡕࡘࡉ࡙ࡓࠦๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭埍"),l1l1l1_l1_ (u"ࠨๆ็วุ็ࠠศๆหัะࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศࠢํ฽ฺ๊๊่ࠠาࠤ฼๊ศࠡลๆฯึࠦๅ็ࠢๆ่๊ฯ้ࠠษะำฮࠦ࠮࠯࠰ࠣ๎ึา้ࠡษ็ฬาัฺ่ࠠࠣ็้๋ษ๊ࠡสัิฯࠠโไฺࠫ城"))
		return
	#search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫ埏"),l1l1l1_l1_ (u"ࠪ࠱ࠬ埐"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ埑")+search
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡱ࠰ࠩ埒")+search+l1l1l1_l1_ (u"࠭࠯ࠨ埓")
	l11l11_l1_(url)
	return
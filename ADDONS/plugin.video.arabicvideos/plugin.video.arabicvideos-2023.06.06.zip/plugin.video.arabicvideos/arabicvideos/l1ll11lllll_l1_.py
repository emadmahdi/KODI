﻿# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
#import unicodedata,simplejson
def MAIN(mode,l1ll1l11ll1_l1_):
	if l1ll1l11ll1_l1_==l1l1l1_l1_ (u"ࠨࠩ⿾"): return
	if mode==1:
		l1ll1l11l1l_l1_ = xbmcgui.l1ll1l11l11_l1_()
		l1ll1l111ll_l1_ = xbmcgui.l1ll11ll1ll_l1_(l1ll1l11l1l_l1_)
		l1ll1l11ll1_l1_ = l1ll1l111l1_l1_(l1ll1l11ll1_l1_)
		l1ll1l111ll_l1_.getControl(311).l1ll1l1l111_l1_(l1ll1l11ll1_l1_)
	if mode==0:
		#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ⿿"))
		#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ　"))
		#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ、"))
		l1ll11lll1l_l1_=l1l1l1_l1_ (u"ࠬ࡞ࠧ。")
		if kodi_version>18.99: check = isinstance(l1ll1l11ll1_l1_,str)
		else: check = isinstance(l1ll1l11ll1_l1_,unicode)
		if check==True: l1ll11lll1l_l1_=l1l1l1_l1_ (u"࠭ࡕࠨ〃")
		l1ll11lll11_l1_=str(type(l1ll1l11ll1_l1_))+l1l1l1_l1_ (u"ࠧࠡࠩ〄")+l1ll1l11ll1_l1_+l1l1l1_l1_ (u"ࠨࠢࠪ々")+l1ll11lll1l_l1_+l1l1l1_l1_ (u"ࠩࠣࠫ〆")
		for i in range(0,len(l1ll1l11ll1_l1_),1):
			l1ll11lll11_l1_ += hex(ord(l1ll1l11ll1_l1_[i])).replace(l1l1l1_l1_ (u"ࠪ࠴ࡽ࠭〇"),l1l1l1_l1_ (u"ࠫࠬ〈"))+l1l1l1_l1_ (u"ࠬࠦࠧ〉")
		l1ll1l11ll1_l1_ = l1ll1l111l1_l1_(l1ll1l11ll1_l1_)
		#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ《"))
		l1ll11lll1l_l1_=l1l1l1_l1_ (u"࡙ࠧࠩ》")
		if kodi_version>18.99: check = isinstance(l1ll1l11ll1_l1_, str)
		else: check = isinstance(l1ll1l11ll1_l1_, unicode)
		if check==True: l1ll11lll1l_l1_=l1l1l1_l1_ (u"ࠨࡗࠪ「")
		l1ll11llll1_l1_=str(type(l1ll1l11ll1_l1_))+l1l1l1_l1_ (u"ࠩࠣࠫ」")+l1ll1l11ll1_l1_+l1l1l1_l1_ (u"ࠪࠤࠬ『")+l1ll11lll1l_l1_+l1l1l1_l1_ (u"ࠫࠥ࠭』")
		for i in range(0,len(l1ll1l11ll1_l1_),1):
			l1ll11llll1_l1_ += hex(ord(l1ll1l11ll1_l1_[i])).replace(l1l1l1_l1_ (u"ࠬ࠶ࡸࠨ【"),l1l1l1_l1_ (u"࠭ࠧ】"))+l1l1l1_l1_ (u"ࠧࠡࠩ〒")
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ〓"),l1l1l1_l1_ (u"ࠩࠪ〔"),l1ll11lll11_l1_,l1ll11llll1_l1_)
	return
	#for i in range(0,len(l1ll1l11ll1_l1_)-2,3):
	#	string=hex(ord(l1ll1l11ll1_l1_[i+0]))+l1l1l1_l1_ (u"ࠪࠤࠥ࠭〕")+hex(ord(l1ll1l11ll1_l1_[i+1]))+l1l1l1_l1_ (u"ࠫࠥࠦࠧ〖")+hex(ord(l1ll1l11ll1_l1_[i+2]))
	#	DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭〗"),l1l1l1_l1_ (u"࠭ࠧ〘"),l1l1l1_l1_ (u"ࠧࠨ〙"),string)
	#return
	#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭〚"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ〛"),l1l1l1_l1_ (u"ࠪࠫ〜"),l1l1l1_l1_ (u"ࠫࠬ〝"),l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l111l1_l1_(l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ〞"))
	#l1ll1l11ll1_l1_ = unicodedata.normalize(l1l1l1_l1_ (u"࠭ࡎࡇࡍࡇࠫ〟"),l1ll1l11ll1_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ〠"),l1l1l1_l1_ (u"ࠨࠩ〡"),l1l1l1_l1_ (u"ࠩࠪ〢"),   hex(  unicodedata.combining(l1ll1l11ll1_l1_[0])  )   )
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ〣"),l1l1l1_l1_ (u"ࠫࠬ〤"),l1ll1l11ll1_l1_,   hex(ord(  l1ll1l11ll1_l1_[0]  ))   )
	#new = l1l1l1_l1_ (u"ࠬ࠭〥")
	#for l1ll1l11111_l1_ in l1ll1l11ll1_l1_:
	#	DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ〦"),l1l1l1_l1_ (u"ࠧࠨ〧"),l1l1l1_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠨ〨"),unicodedata.decomposition(l1ll1l11111_l1_) )
	#	new += l1l1l1_l1_ (u"ࠩ࡟ࡹ࠵࠭〩") + hex(ord(l1ll1l11111_l1_)).replace(l1l1l1_l1_ (u"ࠪ࠴ࡽ〪࠭"),l1l1l1_l1_ (u"〫ࠫࠬ"))
	#l1ll1l11ll1_l1_ = new
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭〬"),l1l1l1_l1_ (u"〭࠭ࠧ"),l1l1l1_l1_ (u"ࠧࠨ〮"),l1ll1l11ll1_l1_)
	#new = l1l1l1_l1_ (u"ࠨ〯ࠩ")
	#for i in range(len(l1ll1l11ll1_l1_)-6,-5,-6):
	#	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ〰"),l1l1l1_l1_ (u"ࠪࠫ〱"),l1l1l1_l1_ (u"ࠫࠬ〲"),str(i))
	#	new += l1ll1l11ll1_l1_[i] + l1ll1l11ll1_l1_[i+1] + l1ll1l11ll1_l1_[i+2] + l1ll1l11ll1_l1_[i+3] + l1ll1l11ll1_l1_[i+4] + l1ll1l11ll1_l1_[i+5]
	#l1ll1l11ll1_l1_ = new
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭〳"),l1l1l1_l1_ (u"࠭ࠧ〴"),l1l1l1_l1_ (u"ࠧࠨ〵"),l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ〶"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ〷"),l1l1l1_l1_ (u"ࠪࠫ〸"),l1l1l1_l1_ (u"ࠫࠬ〹"),l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ〺"))
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ〻"),l1l1l1_l1_ (u"ࠧࠨ〼"),l1l1l1_l1_ (u"ࠨࠩ〽"),l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1l1l1_l1_ (u"ࠩࡨࡱࡦࡪࠧ〾")
	#l1ll1l1111l_l1_ = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡌࡲࡵࡻࡴ࠯ࡕࡨࡲࡩ࡚ࡥࡹࡶࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠩ〿")+l1ll1l11ll1_l1_+l1l1l1_l1_ (u"ࠫࠧ࠲ࠢࡥࡱࡱࡩࠧࡀࡦࡢ࡮ࡶࡩࢂ࠲ࠢࡪࡦࠥ࠾࠶ࢃࠧ぀"))
	#simplejson.loads(l1ll1l1111l_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪぁ"))
	#new = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧあ"))
	#l1ll1l11ll1_l1_ = new
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨぃ"),l1l1l1_l1_ (u"ࠨࠩい"),l1l1l1_l1_ (u"ࠩࠪぅ"),l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l111l1_l1_(l1ll1l11ll1_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫう"),l1l1l1_l1_ (u"ࠫࠬぇ"),l1l1l1_l1_ (u"ࠬ࠭え"),l1ll1l11ll1_l1_)
	#new = l1l1l1_l1_ (u"࠭ࠧぉ")
	#for i in range(len(l1ll1l11ll1_l1_)-2,-1,-2):
	#	new += l1ll1l11ll1_l1_[i] + l1ll1l11ll1_l1_[i+1]
	#l1ll1l11ll1_l1_ = new
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨお"),l1l1l1_l1_ (u"ࠨࠩか"),l1l1l1_l1_ (u"ࠩࠪが"),l1ll1l11ll1_l1_)
	#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨき"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬぎ"),l1l1l1_l1_ (u"ࠬ࠭く"),l1l1l1_l1_ (u"࠭ࠧぐ"),l1ll1l11ll1_l1_)
	#new = l1l1l1_l1_ (u"ࠧࠨけ")
	#for i in range(len(l1ll1l11ll1_l1_)-2,-1,-2):
	#	new += l1ll1l11ll1_l1_[i] + l1ll1l11ll1_l1_[i+1]
	#l1ll1l11ll1_l1_ = new
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩげ"),l1l1l1_l1_ (u"ࠩࠪこ"),l1l1l1_l1_ (u"ࠪࠫご"),l1ll1l11ll1_l1_)
		#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.replace(l1l1l1_l1_ (u"ࠫࠥ࠭さ"),l1l1l1_l1_ (u"ࠬ࠭ざ"))
		#new = l1l1l1_l1_ (u"࠭ࠧし")
		#for i in range(len(l1ll1l11ll1_l1_)-3,-2,-3):
		#	new += l1ll1l11ll1_l1_[i] + l1ll1l11ll1_l1_[i+1] + l1ll1l11ll1_l1_[i+2]
		#l1ll1l11ll1_l1_ = new
		#new = l1l1l1_l1_ (u"ࠧࠨじ")
		#for i in range(len(l1ll1l11ll1_l1_)-2,-1,-2):
		#	new += l1ll1l11ll1_l1_[i] + l1ll1l11ll1_l1_[i+1]
		#l1ll1l11ll1_l1_ = new
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩす"),l1l1l1_l1_ (u"ࠩࠪず"),l1l1l1_l1_ (u"ࠪࠫせ"),l1ll1l11ll1_l1_)
		#l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.l1ll1l11lll_l1_(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩぜ"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭そ"),l1l1l1_l1_ (u"࠭ࠧぞ"),str(ord(l1ll1l11ll1_l1_[0]))+l1l1l1_l1_ (u"ࠧࠡࠩた")+str(ord(l1ll1l11ll1_l1_[1]))+l1l1l1_l1_ (u"ࠨࠢࠪだ")+str(ord(l1ll1l11ll1_l1_[2])),str(len(l1ll1l11ll1_l1_)))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪち"),l1l1l1_l1_ (u"ࠪࠫぢ"),l1l1l1_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠤࡑ࡫ࡴࡵࡧࡵࡷࠬっ"),l1ll1l11ll1_l1_)
		#new = l1l1l1_l1_ (u"ࠬ࠭つ")
		#for i in range(len(l1ll1l11ll1_l1_)-2,-1,-2):
		#	new += l1ll1l11ll1_l1_[i] + l1ll1l11ll1_l1_[i+1]
		#l1ll1l11ll1_l1_ = new
		#new = l1ll1l11ll1_l1_.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫづ"))
		#new = new.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬて"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩで"),l1l1l1_l1_ (u"ࠩࠪと"),l1l1l1_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪど"),new )
		#l1ll11lll11_l1_ = l1l1l1_l1_ (u"ࠫࠬな")
		#for l1ll1l11111_l1_ in new:
		#	DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭に"),l1l1l1_l1_ (u"࠭ࠧぬ"),l1l1l1_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧね"),unicodedata.decomposition(l1ll1l11111_l1_) )
		#	l1ll11lll11_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡸࠫの") + hex(ord(l1ll1l11111_l1_)).replace(l1l1l1_l1_ (u"ࠩࡻࠫは"),l1l1l1_l1_ (u"ࠪࠫば"))
		#l1ll11lll11_l1_ = l1ll11lll11_l1_.decode(l1l1l1_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬぱ"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ひ"),l1l1l1_l1_ (u"࠭ࠧび"),l1l1l1_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧぴ"),l1ll11lll11_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1ll1l111l1_l1_(new)
		#l1ll1l11ll1_l1_ = new.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ふ"))
		#new = new.decode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧぶ")) #.decode(l1l1l1_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫぷ"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬへ"),l1l1l1_l1_ (u"ࠬ࠭べ"),l1l1l1_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭ぺ"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬほ")))   )
		#l1ll1l11ll1_l1_ = l1ll1l111l1_l1_(new)
		#l1ll1l11ll1_l1_ = l1ll1l111l1_l1_(l1ll1l11ll1_l1_)
		#method=l1l1l1_l1_ (u"ࠣࡋࡱࡴࡺࡺ࠮ࡔࡧࡱࡨ࡙࡫ࡸࡵࠤぼ")
		#params=l1l1l1_l1_ (u"ࠩࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠪࡹࠢ࠭ࠢࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾࠩぽ") % l1ll1l11ll1_l1_
		#l1ll1l1111l_l1_ = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠡࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠤࠧࠫࡳࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࠦࠥࡴ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬま") % (method, params))
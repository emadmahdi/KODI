# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ埔")
headers = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ埕"):l1l1l1_l1_ (u"ࠩࠪ埖")}
menu_name = l1l1l1_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ埗")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ埘"),l1l1l1_l1_ (u"ࠬࡽࡷࡦࠩ埙")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l11l11_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l11l1ll_l1_(url,text)
	elif mode==564: results = l1111l1_l1_(url,l1l1l1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭埚")+text)
	elif mode==565: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ埛")+text)
	elif mode==566: results = l1ll11_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ埜"),l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪ埝"),l1l1l1_l1_ (u"ࠪࠫ埞"),False,l1l1l1_l1_ (u"ࠫࠬ域"),l1l1l1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ埠"))
	#hostname = response.headers[l1l1l1_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ埡")]
	#hostname = hostname.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ埢"))
	#l11l1l_l1_ = l1l11l_l1_
	#url = l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ埣")
	#url = l11l1l_l1_
	#response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭埤"),l1l11l_l1_,l1l1l1_l1_ (u"ࠪࠫ埥"),l1l1l1_l1_ (u"ࠫࠬ埦"),l1l1l1_l1_ (u"ࠬ࠭埧"),l1l1l1_l1_ (u"࠭ࠧ埨"),l1l1l1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ埩"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭埪"),menu_name+l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ埫"),l1l1l1_l1_ (u"ࠪࠫ埬"),8)
	#addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ埭"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ埮"),l1l1l1_l1_ (u"࠭ࠧ埯"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ埰"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ埱"),l1l11l_l1_,569,l1l1l1_l1_ (u"ࠩࠪ埲"),l1l1l1_l1_ (u"ࠪࠫ埳"),l1l1l1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ埴"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埵"),menu_name+l1l1l1_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ埶"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ執"),564)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ埸"),menu_name+l1l1l1_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ培"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ基"),565)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ埻"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ埼"),l1l1l1_l1_ (u"࠭ࠧ埽"),9999)
	#headers2 = {l1l1l1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ埾"):hostname,l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ埿"):l1l1l1_l1_ (u"ࠩࠪ堀")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l1l1_l1_ (u"ࠪࡠ࠴࠭堁"),l1l1l1_l1_ (u"ࠫ࠴࠭堂"))
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡸࡩࡨࡪࡷࡦࡦࡸࠨ࠯ࠬࡂ࠭࡫࡯࡬ࡵࡧࡵࠫ堃"),html,re.DOTALL)
	#if l1ll1l1_l1_:
	#	block = l1ll1l1_l1_[0]
	#	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ堄"),block,re.DOTALL)
	#	for l111ll_l1_,title in items:
	#		if l1l1l1_l1_ (u"ࠧࠦࡦ࠼ࠩ࠽࠻ࠥࡥ࠺ࠨࡦ࠺ࠫࡤ࠹ࠧࡤ࠻ࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡣ࠻ࠨࡨ࠽ࠫࡡ࠺࠯ࠨࡨ࠽ࠫࡡࡥࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡦ࠿ࠧ堅") in l111ll_l1_: continue
	#		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ堆"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ堇")+menu_name+title,l111ll_l1_,566)
	#	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ堈"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ堉"),l1l1l1_l1_ (u"ࠬ࠭堊"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ堋"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨ堌"),l1l1l1_l1_ (u"ࠨࠩ堍"),l1l1l1_l1_ (u"ࠩࠪ堎"),l1l1l1_l1_ (u"ࠪࠫ堏"),l1l1l1_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭堐"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭堑"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ堒"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#if l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࠬ堓") not in l111ll_l1_:
			#	server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ堔"))
			#	l111ll_l1_ = l111ll_l1_.replace(server,l11l1l_l1_)
			if title==l1l1l1_l1_ (u"ࠩࠪ堕"): continue
			if any(value in title.lower() for value in l1l1ll_l1_): continue
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ堖"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭堗")+menu_name+title,l111ll_l1_,566)
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ堘"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭堙"),l1l1l1_l1_ (u"ࠧࠨ堚"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ堛"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ堜"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ堝"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭堞")+menu_name+title,l111ll_l1_,566,img)
	return html
def l1ll11_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭堟"),l1l1l1_l1_ (u"࠭ࠧ堠"),url,l1l1l1_l1_ (u"ࠧࠨ堡"))
	#headers2 = {l1l1l1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ堢"):url,l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭堣"):l1l1l1_l1_ (u"ࠪࠫ堤")}
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ堥"),url,l1l1l1_l1_ (u"ࠬ࠭堦"),l1l1l1_l1_ (u"࠭ࠧ堧"),l1l1l1_l1_ (u"ࠧࠨ堨"),l1l1l1_l1_ (u"ࠨࠩ堩"),l1l1l1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ堪"))
	html = response.content
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ堫"),menu_name+l1l1l1_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ堬"),url,564)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堭"),menu_name+l1l1l1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ堮"),url,565)
	if l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ堯") in html:
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ堰"),menu_name+l1l1l1_l1_ (u"ࠩส่๊๋๊ำหࠪ報"),url,561,l1l1l1_l1_ (u"ࠪࠫ堲"),l1l1l1_l1_ (u"ࠫࠬ堳"),l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ場"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ堵"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ堶"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ堷"),menu_name+title,l111ll_l1_,561)
	return
def l11l11_l1_(l1l1l11l111_l1_,type=l1l1l1_l1_ (u"ࠩࠪ堸")):
	if l1l1l1_l1_ (u"ࠪ࠾࠿࠭堹") in l1l1l11l111_l1_:
		url3,url = l1l1l11l111_l1_.split(l1l1l1_l1_ (u"ࠫ࠿ࡀࠧ堺"))
		server = SERVER(url3,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ堻"))
		url = server+url
	else: url,url3 = l1l1l11l111_l1_,l1l1l11l111_l1_
	#headers2 = {l1l1l1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ堼"):url3,l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ堽"):l1l1l1_l1_ (u"ࠨࠩ堾")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭堿"),url,l1l1l1_l1_ (u"ࠪࠫ塀"),l1l1l1_l1_ (u"ࠫࠬ塁"),l1l1l1_l1_ (u"ࠬ࠭塂"),l1l1l1_l1_ (u"࠭ࠧ塃"),l1l1l1_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ塄"))
	html = response.content
	if type==l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ塅"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭塆"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ塇"):
		l1ll1l1_l1_ = [html.replace(l1l1l1_l1_ (u"ࠫࡡࡢ࠯ࠨ塈"),l1l1l1_l1_ (u"ࠬ࠵ࠧ塉")).replace(l1l1l1_l1_ (u"࠭࡜࡝ࠤࠪ塊"),l1l1l1_l1_ (u"ࠧࠣࠩ塋"))]
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡉࡵ࡭ࡩ࠳࠭ࡘࡧࡦ࡭ࡲࡧࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ塌"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩࡊࡶ࡮ࡪࡉࡵࡧࡰࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ塍"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			if any(value in title.lower() for value in l1l1ll_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l1l1_l1_ (u"ู้ࠪอ็ะหࠣࠫ塎"),l1l1l1_l1_ (u"ࠫࠬ塏"))
			if l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ塐") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭塑"),menu_name+title,l111ll_l1_,563,img)
			elif l1l1l1_l1_ (u"ࠧฮๆๅอࠬ塒") in title:
				l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ塓"),title,re.DOTALL)
				if l1llll1_l1_: title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ塔") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ塕"),menu_name+title,l111ll_l1_,563,img)
			else:
				addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ塖"),menu_name+title,l111ll_l1_,562,img)
		if type==l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭塗"):
			l1lllll111l_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ塘"),block,re.DOTALL)
			if l1lllll111l_l1_:
				count = l1lllll111l_l1_[0]
				l111ll_l1_ = url+l1l1l1_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ塙")+count
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ塚"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ塛"),l111ll_l1_,561,l1l1l1_l1_ (u"ࠪࠫ塜"),l1l1l1_l1_ (u"ࠫࠬ塝"),l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭塞"))
		elif type==l1l1l1_l1_ (u"࠭ࠧ塟"):
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ塠"),html,re.DOTALL)
			if l1ll1l1_l1_:
				block = l1ll1l1_l1_[0]
				items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ塡"),block,re.DOTALL)
				for l111ll_l1_,title in items:
					title = l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨ塢")+unescapeHTML(title)
					addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ塣"),menu_name+title,l111ll_l1_,561)
	return
def l11l1ll_l1_(url,type=l1l1l1_l1_ (u"ࠫࠬ塤")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭塥"),l1l1l1_l1_ (u"࠭ࠧ塦"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ塧"),url,l1l1l1_l1_ (u"ࠨࠩ塨"),l1l1l1_l1_ (u"ࠩࠪ塩"),l1l1l1_l1_ (u"ࠪࠫ塪"),l1l1l1_l1_ (u"ࠫࠬ填"),l1l1l1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ塬"))
	html = response.content
	html = UNQUOTE(html)
	l1l1l1_l1_ (u"ࠨࠢࠣࠌࠌࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠾ࠥࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࡞࠱࠶ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠰ࠫ࠱࠭ࠠࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪ࠳ࠬ࠯ࠊࠊ࡫ࡩࠤ๋่ࠬิ็ࠪࠤ࡮ࡴࠠ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡴࡺࡲࡨ࠾ࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡹࡰ࡭࡫ࡷ๋่ࠬࠬิ็ࠪ࠭ࡠ࠶࡝ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡴࡨࡴࡱࡧࡣࡦู้ࠪࠪอ็ะหࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬำไใหࠪࠤ࡮ࡴࠠ࡯ࡣࡰࡩ࠿ࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭อๅไฬࠫ࠮ࡡ࠰࡞ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧฺ๊ࠫࠫว่ัฬࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠣࠤࠥ塭")
	# l111l1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ塮"),html,re.DOTALL)
	if not type and l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ塯"),block,re.DOTALL)
		if len(items)>1:
			for l111ll_l1_,title in items:
				#title = name+l1l1l1_l1_ (u"ࠩࠣ࠱ࠥ࠭塰")+title
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ塱"),menu_name+title,l111ll_l1_,563,l1l1l1_l1_ (u"ࠫࠬ塲"),l1l1l1_l1_ (u"ࠬ࠭塳"),l1l1l1_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ塴"))
			return
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡆࡲ࡬ࡷࡴࡪࡥࡴ࠯࠰ࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡪࡰࡪࡰࡪࡹࡥࡤࡶ࡬ࡳࡳࡹ࠾ࠨ塵"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ塶"),block)
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠪ塷"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ塸"),str(items))
		for l111ll_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭塹"))
			#title = name+l1l1l1_l1_ (u"ࠬࠦ࠭ࠡࠩ塺")+title
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ塻"),menu_name+title,l111ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ塼"),html,re.DOTALL)
		if title: title = title[0].replace(l1l1l1_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭塽"),l1l1l1_l1_ (u"ࠩࠪ塾")).replace(l1l1l1_l1_ (u"ู้ࠪอ็ะหࠣࠫ塿"),l1l1l1_l1_ (u"ࠫࠬ墀"))
		else: title = l1l1l1_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ墁")
		addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ墂"),menu_name+title,url,562)
	return
def PLAY(url):
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ境"),url,l1l1l1_l1_ (u"ࠨࠩ墄"),l1l1l1_l1_ (u"ࠩࠪ墅"),l1l1l1_l1_ (u"ࠪࠫ墆"),l1l1l1_l1_ (u"ࠫࠬ墇"),l1l1l1_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ墈"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭墉"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1l1ll1_l1_ = [l1l1ll1_l1_[0][0],l1l1ll1_l1_[0][1]]
		if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭墊"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭墋"),block,re.DOTALL)
		for l111ll_l1_,name in items:
			if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ墌") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if name==l1l1l1_l1_ (u"ࠪื๏ืแา๋ࠢ๎ู๊ࠥๆษࠪ墍"): name = l1l1l1_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ墎")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭墏")+name+l1l1l1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ墐")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ墑"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭墒"),block,re.DOTALL)
		for l111ll_l1_,l11ll111_l1_ in items:
			if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ墓") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ墔"),l11ll111_l1_,re.DOTALL)
			if l11ll111_l1_: l11ll111_l1_ = l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ墕")+l11ll111_l1_[0]
			else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠬ࠭墖")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡷࡦࡥ࡬ࡱࡦ࠭増")+l1l1l1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ墘")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭墙"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ墚"),url)
	return
def SEARCH(search,hostname=l1l1l1_l1_ (u"ࠪࠫ墛")):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬ墜"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭墝"): return
	search = search.replace(l1l1l1_l1_ (u"࠭ࠠࠨ增"),l1l1l1_l1_ (u"ࠧࠬࠩ墟"))
	l11l1_l1_ = [l1l1l1_l1_ (u"ࠨ࠱ࠪ墠"),l1l1l1_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡵࡨࡶ࡮࡫ࡳࠨ墡"),l1l1l1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡤࡲ࡮ࡳࡥࠨ墢"),l1l1l1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡸࡻ࠭墣"),l1l1l1_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ墤")]
	l111l1l11_l1_ = [l1l1l1_l1_ (u"࠭วๅลไ่ฬ๋ࠧ墥"),l1l1l1_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ墦"),l1l1l1_l1_ (u"ࠨษ็ห๋๐ๅ๋๋ࠢࠤฬ๊ใาฬ๋๊ࠬ墧"),l1l1l1_l1_ (u"ࠩส่อืวๆฮࠣฮ้๐แำ์๋๊๏ฯࠧ墨"),l1l1l1_l1_ (u"ࠪ฾๏ืࠠๆฯาำࠬ墩")]
	if l111l_l1_:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ墪"), l111l1l11_l1_)
		if selection==-1: return
	else: selection = 4
	if not hostname:
		hostname = l1l11l_l1_
		#response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ墫"),l1l11l_l1_,l1l1l1_l1_ (u"࠭ࠧ墬"),l1l1l1_l1_ (u"ࠧࠨ墭"),False,l1l1l1_l1_ (u"ࠨࠩ墮"),l1l1l1_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭墯"))
		#hostname = response.headers[l1l1l1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ墰")]
		#hostname = response.url
		#hostname = hostname.strip(l1l1l1_l1_ (u"ࠫ࠴࠭墱"))
	url2 = hostname+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ墲")+search+l11l1_l1_[selection]
	l11l11_l1_(url2)
	return
def l1111l1_l1_(l1l1l11l111_l1_,filter):
	if l1l1l1_l1_ (u"࠭࠿ࡀࠩ墳") in l1l1l11l111_l1_: url = l1l1l11l111_l1_.split(l1l1l1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭墴"))[0]
	else: url = l1l1l11l111_l1_
	#headers2 = {l1l1l1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ墵"):l1l1l11l111_l1_,l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭墶"):l1l1l1_l1_ (u"ࠪࠫ墷")}
	filter = filter.replace(l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭墸"),l1l1l1_l1_ (u"ࠬ࠭墹"))
	type,filter = filter.split(l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪ墺"),1)
	if filter==l1l1l1_l1_ (u"ࠧࠨ墻"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠨࠩ墼"),l1l1l1_l1_ (u"ࠩࠪ墽")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧ墾"))
	if type==l1l1l1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ墿"):
		if l1l1ll111_l1_[0]+l1l1l1_l1_ (u"ࠬࡃ࠽ࠨ壀") not in l1l1ll11_l1_: category = l1l1ll111_l1_[0]
		for i in range(len(l1l1ll111_l1_[0:-1])):
			if l1l1ll111_l1_[i]+l1l1l1_l1_ (u"࠭࠽࠾ࠩ壁") in l1l1ll11_l1_: category = l1l1ll111_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪ壂")+category+l1l1l1_l1_ (u"ࠨ࠿ࡀ࠴ࠬ壃")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠩࠩࠪࠬ壄")+category+l1l1l1_l1_ (u"ࠪࡁࡂ࠶ࠧ壅")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠫࠫࠬࠧ壆"))+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࠩ壇")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"࠭ࠦࠧࠩ壈"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ壉"))
		url2 = url+l1l1l1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ壊")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ壋"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ壌"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠫࠬ壍"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ壎"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"࠭ࠧ壏"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭壐")+l1l1l1ll_l1_
		l1111lll_l1_ = l1l111l1l_l1_(url2,l1l1l11l111_l1_)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壑"),menu_name+l1l1l1_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ壒"),l1111lll_l1_,561,l1l1l1_l1_ (u"ࠪࠫ壓"),l1l1l1_l1_ (u"ࠫࠬ壔"),l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭壕"))
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壖"),menu_name+l1l1l1_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ壗")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ壘"),l1111lll_l1_,561,l1l1l1_l1_ (u"ࠩࠪ壙"),l1l1l1_l1_ (u"ࠪࠫ壚"),l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ壛"))
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ壜"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭壝"),l1l1l1_l1_ (u"ࠧࠨ壞"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ壟"),url,l1l1l1_l1_ (u"ࠩࠪ壠"),l1l1l1_l1_ (u"ࠪࠫ壡"),l1l1l1_l1_ (u"ࠫࠬ壢"),l1l1l1_l1_ (u"ࠬ࠭壣"),l1l1l1_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ壤"))
	html = response.content
	html = html.replace(l1l1l1_l1_ (u"ࠧ࡝࡞ࠥࠫ壥"),l1l1l1_l1_ (u"ࠨࠤࠪ壦")).replace(l1l1l1_l1_ (u"ࠩ࡟ࡠ࠴࠭壧"),l1l1l1_l1_ (u"ࠪ࠳ࠬ壨"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡽࡥࡤ࡫ࡰࡥ࠲࠳ࡦࡪ࡮ࡷࡩࡷࡄࠧ壩"),html,re.DOTALL)
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡺࡡࡹࡱࡱࡳࡲࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ壪"),block+l1l1l1_l1_ (u"࠭࠼ࡧ࡫࡯ࡸࡪࡸࡢࡰࡺࠪ士"),re.DOTALL)
	dict = {}
	for l1llllll_l1_,name,block in l11111l_l1_:
		name = escapeUNICODE(name)
		if l1l1l1_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ壬") in l1llllll_l1_: continue
		items = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡦࡴࡰࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡶࡻࡸࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡸࡵࡀࠪ壭"),block,re.DOTALL)
		if l1l1l1_l1_ (u"ࠩࡀࡁࠬ壮") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ壯"):
			if category!=l1llllll_l1_: continue
			elif len(items)<=1:
				if l1llllll_l1_==l1l1ll111_l1_[-1]: l11l11_l1_(url2)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ声")+l1ll1111_l1_)
				return
			else:
				l1111lll_l1_ = l1l111l1l_l1_(url2,l1l1l11l111_l1_)
				if l1llllll_l1_==l1l1ll111_l1_[-1]:
					addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壱"),menu_name+l1l1l1_l1_ (u"࠭วๅฮ่๎฾࠭売"),l1111lll_l1_,561,l1l1l1_l1_ (u"ࠧࠨ壳"),l1l1l1_l1_ (u"ࠨࠩ壴"),l1l1l1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ壵"))
				else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壶"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ壷"),url2,564,l1l1l1_l1_ (u"ࠬ࠭壸"),l1l1l1_l1_ (u"࠭ࠧ壹"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ壺"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠨࠨࠩࠫ壻")+l1llllll_l1_+l1l1l1_l1_ (u"ࠩࡀࡁ࠵࠭壼")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠪࠪࠫ࠭壽")+l1llllll_l1_+l1l1l1_l1_ (u"ࠫࡂࡃ࠰ࠨ壾")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࠩ壿")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭夀"),menu_name+name+l1l1l1_l1_ (u"ࠧ࠻ࠢส่ัฺ๋๊ࠩ夁"),url2,565,l1l1l1_l1_ (u"ࠨࠩ夂"),l1l1l1_l1_ (u"ࠩࠪ夃"),l1ll1111_l1_+l1l1l1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ处"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l1l1_l1_ (u"ࠫࡷ࠭夅") or value==l1l1l1_l1_ (u"ࠬࡴࡣ࠮࠳࠺ࠫ夆"): continue
			if any(value in option.lower() for value in l1l1ll_l1_): continue
			if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ备") in option: continue
			if l1l1l1_l1_ (u"ࠧศๆๆ่ࠬ夈") in option: continue
			if l1l1l1_l1_ (u"ࠨࡰ࠰ࡥࠬ変") in value: continue
			#if value in [l1l1l1_l1_ (u"ࠩࡵࠫ夊"),l1l1l1_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ夋"),l1l1l1_l1_ (u"ࠫࡹࡼ࠭࡮ࡣࠪ夌")]: continue
			#if l1llllll_l1_==l1l1l1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ复"): option = value
			if option==l1l1l1_l1_ (u"࠭ࠧ夎"): option = value
			l1l11111l_l1_ = option
			name1 = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡰࡤࡱࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡮ࡢ࡯ࡨࡂࠬ夏"),option,re.DOTALL)
			if name1: l1l11111l_l1_ = name1[0]
			title2 = name+l1l1l1_l1_ (u"ࠨ࠼ࠣࠫ夐")+l1l11111l_l1_
			dict[l1llllll_l1_][value] = title2
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠩࠩࠪࠬ夑")+l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡁࡂ࠭夒")+l1l11111l_l1_
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠫࠫࠬࠧ夓")+l1llllll_l1_+l1l1l1_l1_ (u"ࠬࡃ࠽ࠨ夔")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪ夕")+l1ll1ll1_l1_
			if type==l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ外"):
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夗"),menu_name+title2,url,565,l1l1l1_l1_ (u"ࠩࠪ夘"),l1l1l1_l1_ (u"ࠪࠫ夙"),l1lllll1_l1_+l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭多"))
			elif type==l1l1l1_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ夛") and l1l1ll111_l1_[-2]+l1l1l1_l1_ (u"࠭࠽࠾ࠩ夜") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ夝"))
				#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ夞"),l1l1l1_l1_ (u"ࠩࠪ够"),l1l1l111_l1_,l1ll1ll1_l1_)
				url3 = url+l1l1l1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ夠")+l1l1l111_l1_
				l1111lll_l1_ = l1l111l1l_l1_(url3,l1l1l11l111_l1_)
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夡"),menu_name+title2,l1111lll_l1_,561,l1l1l1_l1_ (u"ࠬ࠭夢"),l1l1l1_l1_ (u"࠭ࠧ夣"),l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ夤"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夥"),menu_name+title2,url,564,l1l1l1_l1_ (u"ࠩࠪ夦"),l1l1l1_l1_ (u"ࠪࠫ大"),l1lllll1_l1_)
	return
l1l1ll111_l1_ = [l1l1l1_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ夨"),l1l1l1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ天"),l1l1l1_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭太")]
l1l1l1l11_l1_ = [l1l1l1_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ夫"),l1l1l1_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ夬"),l1l1l1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ夭"),l1l1l1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ央"),l1l1l1_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ夯"),l1l1l1_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ夰"),l1l1l1_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭失"),l1l1l1_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ夲")]
def l1l111l1l_l1_(url2,url3):
	if l1l1l1_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ夳") in url2: url2 = url2.replace(l1l1l1_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ头"),l1l1l1_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ夵"))
	url2 = url2.replace(l1l1l1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ夶"),l1l1l1_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ夷"))
	url2 = url2.replace(l1l1l1_l1_ (u"࠭࠽࠾ࠩ夸"),l1l1l1_l1_ (u"ࠧ࠰ࠩ夹"))
	url2 = url2.replace(l1l1l1_l1_ (u"ࠨࠨࠩࠫ夺"),l1l1l1_l1_ (u"ࠩ࠲ࠫ夻"))
	return url2
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ夼"),l1l1l1_l1_ (u"ࠫࠬ夽"),filters,l1l1l1_l1_ (u"ࠬࡏࡎࠡࠢࠣࠤࠬ夾")+mode)
	# mode==l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ夿")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ奀")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠨࡣ࡯ࡰࠬ奁")					all filters (l1l11ll1_l1_ l1ll11ll_l1_ filter)
	filters = filters.strip(l1l1l1_l1_ (u"ࠩࠩࠪࠬ奂"))
	l1l1ll1l_l1_,l1llll1l_l1_ = {},l1l1l1_l1_ (u"ࠪࠫ奃")
	if l1l1l1_l1_ (u"ࠫࡂࡃࠧ奄") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠬࠬࠦࠨ奅"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"࠭࠽࠾ࠩ奆"))
			l1l1ll1l_l1_[var] = value
	for key in l1l1l1l11_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠧ࠱ࠩ奇")
		if l1l1l1_l1_ (u"ࠨࠧࠪ奈") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ奉") and value!=l1l1l1_l1_ (u"ࠪ࠴ࠬ奊"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠫࠥ࠱ࠠࠨ奋")+value
		elif mode==l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ奌") and value!=l1l1l1_l1_ (u"࠭࠰ࠨ奍"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪ奎")+key+l1l1l1_l1_ (u"ࠨ࠿ࡀࠫ奏")+value
		elif mode==l1l1l1_l1_ (u"ࠩࡤࡰࡱ࠭奐"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠪࠪࠫ࠭契")+key+l1l1l1_l1_ (u"ࠫࡂࡃࠧ奒")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠬࠦࠫࠡࠩ奓"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"࠭ࠦࠧࠩ奔"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ奕"),l1l1l1_l1_ (u"ࠨࠩ奖"),l1llll1l_l1_,l1l1l1_l1_ (u"ࠩࡒ࡙࡙࠭套"))
	return l1llll1l_l1_
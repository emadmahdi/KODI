# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᩯ")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡄࡏࡑࡣࠬᩰ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠧใษษ้ฯ๐ࠧᩱ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1ll11_l1_(url)
	elif mode==302: results = l11l11_l1_(url)
	elif mode==303: results = l1llllll11_l1_(url)
	elif mode==304: results = l11l1ll_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩲ"),menu_name+l1l1l1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᩳ"),l1l1l1_l1_ (u"ࠪࠫᩴ"),309,l1l1l1_l1_ (u"ࠫࠬ᩵"),l1l1l1_l1_ (u"ࠬ࠭᩶"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᩷"))
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᩸"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᩹"),l1l1l1_l1_ (u"ࠩࠪ᩺"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ᩻"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬ᩼"),l1l1l1_l1_ (u"ࠬ࠭᩽"),l1l1l1_l1_ (u"࠭ࠧ᩾"),l1l1l1_l1_ (u"ࠧࠨ᩿"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᪀"))
	html = response.content
	html = l1lll11lll_l1_(html)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁࡹࡰࡢࡰࡁࠫ᪁"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᪂"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		l111ll_l1_ = l1l11l_l1_+l111ll_l1_
		title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭᪃"))
		if title==l1l1l1_l1_ (u"ࠬืๅืษ้ࠫ᪄"): l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ิ้฻อๆ࠰ࠩ᪅")
		if not any(value in title for value in l1l1ll_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪆"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᪇")+menu_name+title,l111ll_l1_,301)
	l1ll11_l1_(l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ᪈"))
	return html
def l1ll11_l1_(url):
	seq = 0
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ᪉"),url,l1l1l1_l1_ (u"ࠫࠬ᪊"),l1l1l1_l1_ (u"ࠬ࠭᪋"),l1l1l1_l1_ (u"࠭ࠧ᪌"),l1l1l1_l1_ (u"ࠧࠨ᪍"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ᪎"))
	html = response.content
	html = l1lll11lll_l1_(html)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴ࠪࡀ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂ࠮࠭᪏"),html,re.DOTALL)
	if l1ll1l1_l1_:
		for block in l1ll1l1_l1_:
			seq += 1
			items = re.findall(l1l1l1_l1_ (u"ࠪࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᪐"),block,re.DOTALL)
			for title,test,l111ll_l1_ in items:
				title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭᪑"))
				if title==l1l1l1_l1_ (u"ࠬ࠭᪒"): title = l1l1l1_l1_ (u"࠭ศ้๊๋์ํ࠭᪓")
				if l1l1l1_l1_ (u"ࠧࡦ࡯ࡁࡀࡦ࠭᪔") not in test:
					if block.count(l1l1l1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬ᪕"))>0:
						l1lll11l11_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᪖"),block,re.DOTALL)
						for l111ll_l1_ in l1lll11l11_l1_:
							title = l111ll_l1_.split(l1l1l1_l1_ (u"ࠪ࠳ࠬ᪗"))[-2]
							addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪘"),menu_name+title,l111ll_l1_,301)
						continue
					else: l111ll_l1_ = url+l1l1l1_l1_ (u"ࠬࡅࡳࡦࡳࡸࡩࡳࡩࡥ࠾ࠩ᪙")+str(seq)
				#l11l11l11_l1_ = [l1l1l1_l1_ (u"࠭ๅิๆึ่ฬะࠠࠨ᪚"),l1l1l1_l1_ (u"ࠧศใ็ห๊ࠦࠧ᪛"),l1l1l1_l1_ (u"ࠨสิห๊าࠧ᪜"),l1l1l1_l1_ (u"ࠩ฼ีํ฼ࠧ᪝"),l1l1l1_l1_ (u"ࠪ็้๐ศศฬࠪ᪞"),l1l1l1_l1_ (u"ࠫฬเว็๋ࠪ᪟")]
				#if any(value in title for value in l11l11l11_l1_):
				if not any(value in title for value in l1l1ll_l1_):
					addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᪠"),menu_name+title,l111ll_l1_,302)
	else: l11l11_l1_(url,html)
	return
def l11l11_l1_(url,html=l1l1l1_l1_ (u"࠭ࠧ᪡")):
	if html==l1l1l1_l1_ (u"ࠧࠨ᪢"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ᪣"),url,l1l1l1_l1_ (u"ࠩࠪ᪤"),l1l1l1_l1_ (u"ࠪࠫ᪥"),l1l1l1_l1_ (u"ࠫࠬ᪦"),l1l1l1_l1_ (u"ࠬ࠭ᪧ"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ᪨"))
		html = response.content
		html = l1lll11lll_l1_(html)
	if l1l1l1_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫ᪩") in url:
		url,seq = url.split(l1l1l1_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࠬ᪪"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴ࠪࡀ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂ࠮࠭᪫"),html,re.DOTALL)
		block = l1ll1l1_l1_[int(seq)-1]
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡵࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡴࡪࡹ࠿ࠩ᪬"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫࡁࡧ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᪭"),block,re.DOTALL)
	l1l1_l1_ = []
	for l111ll_l1_,data,img in items:
		title = re.findall(l1l1l1_l1_ (u"ࠬࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠰࠭ࡃࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡰࡂࠬ᪮"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l1l1_l1_ (u"࠭࡜࡯ࠩ᪯"),l1l1l1_l1_ (u"ࠧࠨ᪰")).strip(l1l1l1_l1_ (u"ࠨࠢࠪ᪱"))
		if not title or title==l1l1l1_l1_ (u"ࠩࠪ᪲"):
			title = re.findall(l1l1l1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤࡁ࠲࠯ࡅ࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᪳"),data,re.DOTALL)
			if title: title = title[0].replace(l1l1l1_l1_ (u"ࠫࡡࡴࠧ᪴"),l1l1l1_l1_ (u"᪵ࠬ࠭")).strip(l1l1l1_l1_ (u"࠭ࠠࠨ᪶"))
			if not title or title==l1l1l1_l1_ (u"ࠧࠨ᪷"):
				title = re.findall(l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᪸"),data,re.DOTALL)
				title = title[0].replace(l1l1l1_l1_ (u"ࠩ࡟ࡲ᪹ࠬ"),l1l1l1_l1_ (u"᪺ࠪࠫ")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭᪻"))
		title = unescapeHTML(title)
		#if title==l1l1l1_l1_ (u"ࠬ࠭᪼"): continue
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l11ll_l1_ = l111ll_l1_+data+img
			if l1l1l1_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ᪽") in l11ll_l1_ or l1l1l1_l1_ (u"ࠧๆี็ื้࠭᪾") in l11ll_l1_ or l1l1l1_l1_ (u"ࠨࠤࡨࡴ࡮ࡹ࡯ࡥࡧᪿࠥࠫ") in l11ll_l1_:
				if l1l1l1_l1_ (u"ࠩหีฬ๋ฬࠨᫀ") in data: title = l1l1l1_l1_ (u"ࠪฬึ์วๆฮࠣࠫ᫁")+title
				elif l1l1l1_l1_ (u"ู๊ࠫไิๆࠪ᫂") in data or l1l1l1_l1_ (u"๋่ࠬิ็᫃ࠪ") in data: title = l1l1l1_l1_ (u"࠭ๅิๆึ่᫄ࠥ࠭")+title
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᫅"),menu_name+title,l111ll_l1_,303,img)
			else: addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᫆"),menu_name+title,l111ll_l1_,305,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ᫇"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᫈"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᫉"),menu_name+l1l1l1_l1_ (u"ࠬ฻แฮห᫊ࠣࠫ")+title,l111ll_l1_,302)
	return
def l1llllll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ᫋"),url,l1l1l1_l1_ (u"ࠧࠨᫌ"),l1l1l1_l1_ (u"ࠨࠩᫍ"),l1l1l1_l1_ (u"ࠩࠪᫎ"),l1l1l1_l1_ (u"ࠪࠫ᫏"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠱ࡴࡶࠪ᫐"))
	html = response.content
	html = l1lll11lll_l1_(html)
	name = re.findall(l1l1l1_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡩࡵ࡮ࡨࡂࠬ᫑"),html,re.DOTALL)
	name = name[0].replace(l1l1l1_l1_ (u"࠭ࡼࠡีํ้ฬࠦๆศ๊ࠪ᫒"),l1l1l1_l1_ (u"ࠧࠨ᫓")).replace(l1l1l1_l1_ (u"ࠨࡅ࡬ࡱࡦࠦࡎࡰࡹࠪ᫔"),l1l1l1_l1_ (u"ࠩࠪ᫕")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ᫖")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠧ᫗"),l1l1l1_l1_ (u"ࠬࠦࠧ᫘"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡴࡧࡤࡷࡴࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡧࡹ࡯࡯࡯ࡀࠪ᫙"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᫚"),block,re.DOTALL)
		if len(items)>1:
			for l111ll_l1_,title in items:
				#title = name+l1l1l1_l1_ (u"ࠨࠢࠪ᫛")+title.replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ᫜"),l1l1l1_l1_ (u"ࠪࠫ᫝")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭᫞"))
				title = title.replace(l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ᫟"),l1l1l1_l1_ (u"࠭ࠧ᫠")).strip(l1l1l1_l1_ (u"ࠧࠡࠩ᫡"))
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᫢"),menu_name+title,l111ll_l1_,304)
		else: l11l1ll_l1_(url)
	return
def l11l1ll_l1_(url):
	if l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫ᫣") not in url: url = url.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬ᫤"))+l1l1l1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࡭ࡳ࡭ࠧ᫥")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ᫦"),url,l1l1l1_l1_ (u"࠭ࠧ᫧"),l1l1l1_l1_ (u"ࠧࠨ᫨"),l1l1l1_l1_ (u"ࠨࠩ᫩"),l1l1l1_l1_ (u"ࠩࠪ᫪"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ᫫"))
	html = response.content
	html = l1lll11lll_l1_(html)
	#WRITE_THIS(l1l1l1_l1_ (u"ࠫࠬ᫬"),html)
	if l1l1l1_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧ᫭") not in url:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᫮"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᫯"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ᫰"),l1l1l1_l1_ (u"ࠩࠪ᫱")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ᫲"))
			title = l1l1l1_l1_ (u"ࠫฬ๊อๅไฬࠤࠬ᫳")+title
			addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᫴"),menu_name+title,l111ll_l1_,305)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡥࡧࡷࡥ࡮ࡲࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠩ᫵"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᫶"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ᫷"),l1l1l1_l1_ (u"ࠩࠪ᫸")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ᫹"))
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᫺"),menu_name+title,l111ll_l1_,305,img)
	return
def PLAY(url):
	l1l1l1_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫ࡬ࡹࡳ࡬ࠪࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡭࡯࡮ࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡪࡷࡱࡱ࠯ࠊࠊࡥࡲࡳࡰ࡯ࡥࡴࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡱ࡮࡭ࡪࡹ࠮ࡨࡧࡷࡣࡩ࡯ࡣࡵࠪࠬࠎࠎࡖࡈࡑࡕࡈࡗࡘࡏࡄࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡖࡈࡑࡕࡈࡗࡘࡏࡄࠨ࡟ࠍࠍࡻ࡫ࡲࡪࡨࡼࡣࡱ࡯࡮࡬ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠤ࡫ࡶࡪ࡬ࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠰ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠧࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀࠫ࠰ࡖࡈࡑࡕࡈࡗࡘࡏࡄࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ࠯ࠊࠊࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡼࡥࡳ࡫ࡩࡽࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬ࠪࠌࠌࠧࡦࡪ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡤࡨࠧࠦࡴࡢࡴࡪࡩࡹࡃࠢࡠࡤ࡯ࡥࡳࡱࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡣࡧࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠣࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡦࡪ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧࠪࠌࠌࠧࡦࡪ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡡࡥࡡ࡫ࡸࡲࡲࠩࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡥࡸࡳࠨࠠࡴࡶࡼࡰࡪࡃࠢࡥ࡫ࡶࡴࡱࡧࡹ࠻ࠢࡱࡳࡳ࡫࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࡞࠴ࡢ࠱ࠧ࠰ࠩࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡤ࠱ࡧ࡮ࡳࡡࡷ࡫ࡧࡷ࠳ࡲࡩࡷࡧ࠲ࠫࢂࠐࠉࠣࠤࠥ᫻")
	url2 = url+l1l1l1_l1_ (u"࠭ࡷࡢࡶࡦ࡬࡮ࡴࡧ࠰ࠩ᫼")
	#server = SERVER(url2,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ᫽"))
	#headers2 = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᫾"):None,l1l1l1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ᫿"):server}
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᬀ"),url2,l1l1l1_l1_ (u"ࠫࠬᬁ"),l1l1l1_l1_ (u"ࠬ࠭ᬂ"),l1l1l1_l1_ (u"࠭ࠧᬃ"),l1l1l1_l1_ (u"ࠧࠨᬄ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫᬅ"))
	html = response.content
	html = l1lll11lll_l1_(html)
	#url2 = l1lll1l111_l1_(url2,l1l1l1_l1_ (u"ࠩ࡯ࡳࡼ࡫ࡲࠨᬆ"))
	#html = l1lll11l1l_l1_(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᬇ"),url2,l1l1l1_l1_ (u"ࠫࠬᬈ"),l1l1l1_l1_ (u"ࠬ࠭ᬉ"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩᬊ"))
	#if html and kodi_version>18.99: html = html.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᬋ"))
	#html = l1lll11lll_l1_(html)
	l11l1_l1_ = []
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᬌ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᬍ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠪࡠࡳ࠭ᬎ"),l1l1l1_l1_ (u"ࠫࠬᬏ")).strip(l1l1l1_l1_ (u"ࠬࠦࠧᬐ"))
			l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧᬑ"),title,re.DOTALL)
			if l11ll111_l1_:
				l11ll111_l1_ = l1l1l1_l1_ (u"ࠧࡠࡡࡢࡣࠬᬒ")+l11ll111_l1_[0]
				#title = l1l1l1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩᬓ")
				title = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧᬔ"))
			else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠪࠫᬕ")
			l11111ll1_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᬖ")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᬗ")+l11ll111_l1_
			l11l1_l1_.append(l11111ll1_l1_)
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡸࡣࡷࡧ࡭ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᬘ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		# l11ll1l1l_l1_ l1l1111ll_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠩ࠱࠲࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭ᬙ"),block,re.DOTALL)
		for l111ll_l1_ in l1ll_l1_:
			l111ll_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᬚ")+l111ll_l1_
			title = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧᬛ"))
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᬜ")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬᬝ")
			l11l1_l1_.append(l111ll_l1_)
		# l1lll11ll1_l1_ l1l1111ll_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡧࡪࡢࡺ࡟ࠬࢀࡻࡲ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᬞ"),html,re.DOTALL)
		if l1ll_l1_:
			items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡴࡤࡦࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨᬟ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l1l1_l1_ (u"ࠧ࡝ࡰࠪᬠ"),l1l1l1_l1_ (u"ࠨࠩᬡ")).strip(l1l1l1_l1_ (u"ࠩࠣࠫᬢ"))
				title = title.replace(l1l1l1_l1_ (u"ࠪࡇ࡮ࡳࡡࠡࡐࡲࡻࠬᬣ"),l1l1l1_l1_ (u"ࠫࡈ࡯࡭ࡢࡐࡲࡻࠬᬤ"))
				l111ll_l1_ = l1ll_l1_[0]+l1l1l1_l1_ (u"ࠬࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡸ࡫ࡷࡧ࡭ࠬࡩ࡯ࡦࡨࡼࡂ࠭ᬥ")+index+l1l1l1_l1_ (u"࠭ࠦࡪࡦࡀࠫᬦ")+id+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᬧ")+title+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᬨ")
				l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᬩ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᬪ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬᬫ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭ᬬ"): return
	search = search.replace(l1l1l1_l1_ (u"࠭ࠠࠨᬭ"),l1l1l1_l1_ (u"ࠧࠬࠩᬮ"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭ᬯ")+search
	l11l11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᦙ")
menu_name = l1l1l1_l1_ (u"ࠩࡢࡇࡒࡒ࡟ࠨᦚ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠪๆ๋๎วหࠢไฺฬฬ๊สࠩᦛ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l11l11_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l11l1ll_l1_(url,text)
	elif mode==474: results = l1ll11_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨᦜ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭ᦝ"),l1l1l1_l1_ (u"࠭ࠧᦞ"),l1l1l1_l1_ (u"ࠧࠨᦟ"),l1l1l1_l1_ (u"ࠨࠩᦠ"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᦡ"))
	html = response.content
	l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡺࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᦢ"),html,re.DOTALL)
	l11l1l_l1_ = l11l1l_l1_[0].strip(l1l1l1_l1_ (u"ࠫ࠴࠭ᦣ"))
	l11l1l_l1_ = SERVER(l11l1l_l1_,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩᦤ"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦥ"),menu_name+l1l1l1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᦦ"),l1l1l1_l1_ (u"ࠨࠩᦧ"),479,l1l1l1_l1_ (u"ࠩࠪᦨ"),l1l1l1_l1_ (u"ࠪࠫᦩ"),l1l1l1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᦪ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᦫ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᦬"),l1l1l1_l1_ (u"ࠧࠨ᦭"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᦮"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᦯")+menu_name+l1l1l1_l1_ (u"ࠪวๆ๊วๆ่้ࠢ๏ุษࠨᦰ"),l11l1l_l1_,471,l1l1l1_l1_ (u"ࠫࠬᦱ"),l1l1l1_l1_ (u"ࠬ࠭ᦲ"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨᦳ"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᦴ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᦵ")+menu_name+l1l1l1_l1_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩᦶ"),l11l1l_l1_,471,l1l1l1_l1_ (u"ࠪࠫᦷ"),l1l1l1_l1_ (u"ࠫࠬᦸ"),l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧᦹ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᦺ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬᦻ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪᦼ"))
		#if title in l1l1ll_l1_: continue
		l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠩࡦࡥࡹࡃ࡯࡯࡮࡬ࡲࡪ࠳࡭ࡰࡸ࡬ࡩࡸ࠷ࠧᦽ"),l1l1l1_l1_ (u"ࠪࡧࡦࡺ࠽ࡰࡰ࡯࡭ࡳ࡫࠭࡮ࡱࡹ࡭ࡪࡹࠧᦾ"))
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦿ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᧀ")+menu_name+title,l111ll_l1_,474)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᧁ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᧂ"),l1l1l1_l1_ (u"ࠨࠩᧃ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᧄ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣᧅ"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_:
		block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠫࠬᧆ"))
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᧇ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		#l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࡁࠪᧈ")+category+l1l1l1_l1_ (u"ࠧ࠾ࠩᧉ")+value
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧊"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᧋")+menu_name+title,l111ll_l1_,474)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ᧌"),url,l1l1l1_l1_ (u"ࠫࠬ᧍"),l1l1l1_l1_ (u"ࠬ࠭᧎"),l1l1l1_l1_ (u"࠭ࠧ᧏"),l1l1l1_l1_ (u"ࠧࠨ᧐"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ᧑"))
	html = response.content
	if l1l1l1_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࠩ᧒") in url: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠧ᧓"),html,re.DOTALL)
	else: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᧔"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᧕"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if l1l1l1_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵ࠭᧖") in l111ll_l1_:
				if l1l1l1_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡨࡲ࡬ࡲࡩࡴࡪ࠰ࡱࡴࡼࡩࡦࡵࠪ᧗") in l111ll_l1_: continue
				if l1l1l1_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡱࡴࡼࡩࡦࡵ࠴ࠫ᧘") in l111ll_l1_: continue
				if l1l1l1_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࡁࡦࡁࡲ࡯ࡳࡤࠩ᧙") in l111ll_l1_: continue
				if l1l1l1_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࡂࡧࡂࡺࡶ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࠩ᧚") in l111ll_l1_: continue
				if l1l1l1_l1_ (u"๊ࠫ์ะࠡษ็ฬิอ๊สࠩ᧛") in title and l1l1l1_l1_ (u"ࠬࡪ࡯࠾ࡴࡤࡸ࡮ࡴࡧࠨ᧜") not in l111ll_l1_: continue
			else: title = l1l1l1_l1_ (u"࠭สาฬํฬࠥฮวิฬัำฬ๋࠺ࠡࠢࠪ᧝")+title
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᧞"),menu_name+title,l111ll_l1_,471)
	else: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠨࠩ᧟")):
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭᧠"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ᧡"),url,l1l1l1_l1_ (u"ࠫࠬ᧢"),l1l1l1_l1_ (u"ࠬ࠭᧣"),l1l1l1_l1_ (u"࠭ࠧ᧤"),l1l1l1_l1_ (u"ࠧࠨ᧥"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ᧦"))
	html = response.content
	items = []
	if request==l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ᧧"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠭ࡧ࡮ࡸ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᧨"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠨ᧩"),block,re.DOTALL)
		l1ll_l1_,titles,l1lll1ll11_l1_ = zip(*items)
		items = zip(l1lll1ll11_l1_,l1ll_l1_,titles)
	elif request==l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ᧪"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠫ࠲࠯ࡅࠩ࠽ࡵࡷࡽࡱ࡫࠾ࠨ᧫"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࠬ᧬"),block,re.DOTALL)
		l1ll_l1_,titles,l1lll1ll11_l1_ = zip(*items)
		items = zip(l1lll1ll11_l1_,l1ll_l1_,titles)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧭"),html,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠩ᧮"),html,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰࡫ࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᧯"),html,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡷ࡫࡬ࡢࡶࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧰"),html,re.DOTALL)
		if not l1ll1l1_l1_: return
		block = l1ll1l1_l1_[0]
	if not items: items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᧱"),block,re.DOTALL)
	if not items: items = re.findall(l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᧲"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ࠧๆึส๋ิฯࠧ᧳"),l1l1l1_l1_ (u"ࠨใํ่๊࠭᧴"),l1l1l1_l1_ (u"ࠩส฾๋๐ษࠨ᧵"),l1l1l1_l1_ (u"ࠪ็้๐ศࠨ᧶"),l1l1l1_l1_ (u"ࠫฬ฿ไศ่ࠪ᧷"),l1l1l1_l1_ (u"ࠬํฯศใࠪ᧸"),l1l1l1_l1_ (u"࠭ๅษษิหฮ࠭᧹"),l1l1l1_l1_ (u"ฺࠧำูࠫ᧺"),l1l1l1_l1_ (u"ࠨ็๊ีัอๆࠨ᧻"),l1l1l1_l1_ (u"ࠩส่อ๎ๅࠨ᧼"),l1l1l1_l1_ (u"ุ้ࠪือ๋หࠪ᧽")]
	for img,l111ll_l1_,title in items:
		l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠫ࠴࠭᧾"))
		if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᧿") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨᨀ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩᨁ"))
		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᨂ") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫᨃ")+img.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬᨄ"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭ᨅ"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨᨆ"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᨇ"),menu_name+title,l111ll_l1_,472,img)
		elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠧศๆะ่็ฯࠧᨈ") in title:
			title = l1l1l1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᨉ") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᨊ"),menu_name+title,l111ll_l1_,473,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨᨋ") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᨌ"),menu_name+title,l111ll_l1_,471,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᨍ"),menu_name+title,l111ll_l1_,473,img)
	if request not in [l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨᨎ"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᨏ")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᨐ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᨑ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠪࠧࠬᨒ"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭ᨓ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧᨔ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨕ"),menu_name+l1l1l1_l1_ (u"ࠧึใะอࠥ࠭ᨖ")+title,l111ll_l1_,471)
		l1111ll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡵ࡫ࡳࡼࡳ࡯ࡳࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᨗ"),html,re.DOTALL)
		if l1111ll11_l1_:
			l111ll_l1_ = l1111ll11_l1_[0]
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳᨘࠩ"),menu_name+l1l1l1_l1_ (u"ู้ࠪอ็ะหࠣห้๋า๋ัࠪᨙ"),l111ll_l1_,471)
	return
def l11l1ll_l1_(url,l1lll_l1_):
	#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬᨚ"),l1l1l1_l1_ (u"ࠬ࠷࠱࠲࠳ࠣࠤࠬᨛ")+url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ᨜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ᨝"),url,l1l1l1_l1_ (u"ࠨࠩ᨞"),l1l1l1_l1_ (u"ࠩࠪ᨟"),l1l1l1_l1_ (u"ࠪࠫᨠ"),l1l1l1_l1_ (u"ࠫࠬᨡ"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧᨢ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᨣ"),html,re.DOTALL)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࠬᨤ")+l1lll_l1_+l1l1l1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᨥ"),html,re.DOTALL)
	items = []
	# l111l1_l1_
	if l1ll11l_l1_ and not l1lll_l1_:
		img = re.findall(l1l1l1_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᨦ"),html,re.DOTALL)
		img = img[0]
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸࡡ࠲ࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧᨧ"),block,re.DOTALL)
		for l1lll_l1_,title in items: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᨨ"),menu_name+title,url,473,img,l1l1l1_l1_ (u"ࠬ࠭ᨩ"),l1lll_l1_)
	# l1ll1_l1_
	elif l1ll111_l1_:
		#img = xbmc.getInfoLabel(l1l1l1_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᨪ"))
		img = re.findall(l1l1l1_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᨫ"),html,re.DOTALL)
		img = img[0]
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠣࡶ࡬ࡸࡱ࡫࠽ࠨࠪ࠱࠮ࡄ࠯ࠧࠡࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢᨬ"),block,re.DOTALL)
		if items:
			for title,l111ll_l1_ in items:
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫᨭ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬᨮ"))
				addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᨯ"),menu_name+title,l111ll_l1_,472,img)
		else:
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ᨰ"),block,re.DOTALL)
			for l111ll_l1_,title,img in items:
				if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫᨱ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩᨲ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪᨳ"))
				addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᨴ"),menu_name+title,l111ll_l1_,472,img)
	if l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰ࡶࡪࡲࡡࡵࡧࡧࠦࠬᨵ") in html:
		if items: addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨶ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᨷ"),l1l1l1_l1_ (u"࠭ࠧᨸ"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᨹ"),menu_name+l1l1l1_l1_ (u"ࠨ็๋ห฻๐ูࠡาสฮࠥ฻ไสࠩᨺ"),url,471)
	#else: l11l11_l1_(url)
	return
def PLAY(url):
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭ᨻ"))
	l11l1_l1_ = []
	# l1lll1l1ll_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᨼ"),url,l1l1l1_l1_ (u"ࠫࠬᨽ"),l1l1l1_l1_ (u"ࠬ࠭ᨾ"),l1l1l1_l1_ (u"࠭ࠧᨿ"),l1l1l1_l1_ (u"ࠧࠨᩀ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᩁ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨࡱࡄࠧᩂ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᩃ"),block,re.DOTALL)
		if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_,True): return
	# default l1l1111ll_l1_ l111ll_l1_
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᩄ"),html,re.DOTALL)
	if l111ll_l1_:
		l111ll_l1_ = l111ll_l1_[0]+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡸࡣࡷࡧ࡭࠭ᩅ")
		if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫᩆ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᩇ")+l111ll_l1_
		l11l1_l1_.append(l111ll_l1_)
	# l11ll1l1l_l1_ l1l1111ll_l1_ l111ll_l1_
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡖࡔࡏࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᩈ"),html,re.DOTALL)
	if l111ll_l1_:
		l111ll_l1_ = l111ll_l1_[0]+l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᩉ")
		if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᩊ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᩋ")+l111ll_l1_
		l11l1_l1_.append(l111ll_l1_)
	# l1l1111ll_l1_ l1ll_l1_
	url2 = url.replace(l1l1l1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᩌ"),l1l1l1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩᩍ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫᩎ"),url2,l1l1l1_l1_ (u"ࠨࠩᩏ"),l1l1l1_l1_ (u"ࠩࠪᩐ"),l1l1l1_l1_ (u"ࠪࠫᩑ"),l1l1l1_l1_ (u"ࠫࠬᩒ"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪᩓ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭ࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᩔ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ᩕ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᩖ")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᩗ")
			if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᩘ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᩙ")+l111ll_l1_
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	url2 = url.replace(l1l1l1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᩚ"),l1l1l1_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵ࠭ᩛ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫᩜ"),url2,l1l1l1_l1_ (u"ࠨࠩᩝ"),l1l1l1_l1_ (u"ࠩࠪᩞ"),l1l1l1_l1_ (u"ࠪࠫ᩟"),l1l1l1_l1_ (u"᩠ࠫࠬ"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪᩡ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᩢ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩᩣ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᩤ")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᩥ")
			if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᩦ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᩧ")+l111ll_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᩨ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᩩ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨᩪ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩᩫ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫᩬ"),l1l1l1_l1_ (u"ࠪ࠯ࠬᩭ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬᩮ")+search
	l11l11_l1_(url)
	return
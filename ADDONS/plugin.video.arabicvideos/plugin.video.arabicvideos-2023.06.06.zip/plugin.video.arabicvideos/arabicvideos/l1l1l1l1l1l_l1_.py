# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ㴎")
headers = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㴏") : l1l1l1_l1_ (u"ࠨࠩ㴐") }
menu_name = l1l1l1_l1_ (u"ࠩࡢࡑ࡛ࡠ࡟ࠨ㴑")
l1l11l_l1_ = WEBSITES[script_name][0]
l1ll11ll1l_l1_ = WEBSITES[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l11l11_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l11l1ll_l1_(url)
	elif mode==188: results = l1l1l1ll11l_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l1l1l1ll11l_l1_():
	message = l1l1l1_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠห฼ํีࠥฮวๅๅส้้ࠦ࠮࠯࠰ࠣ์อำวอหࠣห้๏ࠠศ฻สำฮࠦศา็ฯอ๋ࠥๆࠡษ็ูๆืࠠ࠯࠰࠱ࠤํอไๆสิ้ัࠦอศๆํห๋ࠥิ฻๊็ࠤํ๐ูศ่ํࠤ๊์้ࠠ฻ๆอࠥ฻อ๋หࠣ࠲࠳࠴้ࠠๆ๊ิฬࠦำ้ใࠣ๎อ่้ࠡษ็้ํู่ࠡ็฽่็ࠦวๅ๋้ࠣฬࠦิศรࠣห้๊็ࠨ㴒")
	DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ㴓"),l1l1l1_l1_ (u"ࠬ࠭㴔"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㴕"),message)
	return
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㴖"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㴗"),l1l1l1_l1_ (u"ࠩࠪ㴘"),189,l1l1l1_l1_ (u"ࠪࠫ㴙"),l1l1l1_l1_ (u"ࠫࠬ㴚"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㴛"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㴜"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㴝")+menu_name+l1l1l1_l1_ (u"ࠨส๋็ุࠦว้ใํื๋่ࠥโ์ีࠤ้อๆะࠩ㴞"),l1l11l_l1_,181,l1l1l1_l1_ (u"ࠩࠪ㴟"),l1l1l1_l1_ (u"ࠪࠫ㴠"),l1l1l1_l1_ (u"ࠫࡧࡵࡸ࠮ࡱࡩࡪ࡮ࡩࡥࠨ㴡"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㴢"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㴣")+menu_name+l1l1l1_l1_ (u"ࠧฤฯาฯࠥอไศใ็ห๊࠭㴤"),l1l11l_l1_,181,l1l1l1_l1_ (u"ࠨࠩ㴥"),l1l1l1_l1_ (u"ࠩࠪ㴦"),l1l1l1_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ㴧"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㴨"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㴩")+menu_name+l1l1l1_l1_ (u"࠭สๅ์ไึ๏๎ๆࠡ็๋ๅ๏ุࠠๅษ้ำࠬ㴪"),l1l11l_l1_,181,l1l1l1_l1_ (u"ࠧࠨ㴫"),l1l1l1_l1_ (u"ࠨࠩ㴬"),l1l1l1_l1_ (u"ࠩࡷࡺࠬ㴭"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㴮"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㴯")+menu_name+l1l1l1_l1_ (u"ࠬอไศๅฮี๋ࠥิศ้าอࠬ㴰"),l1l11l_l1_,181,l1l1l1_l1_ (u"࠭ࠧ㴱"),l1l1l1_l1_ (u"ࠧࠨ㴲"),l1l1l1_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ㴳"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㴴"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㴵")+menu_name+l1l1l1_l1_ (u"ࠫศ่่๊ࠢส่ฬ็ไศ็ࠣห้ำวๅ์ฬࠫ㴶"),l1l11l_l1_,181,l1l1l1_l1_ (u"ࠬ࠭㴷"),l1l1l1_l1_ (u"࠭ࠧ㴸"),l1l1l1_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ㴹"))
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩ㴺"),headers,l1l1l1_l1_ (u"ࠩࠪ㴻"),l1l1l1_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㴼"))
	items = re.findall(l1l1l1_l1_ (u"ࠫࡁ࡮࠲࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㴽"),html,re.DOTALL)
	for l111ll_l1_,title in items:
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㴾"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㴿")+menu_name+title,l111ll_l1_,181)
	return html
def l11l11_l1_(url,type=l1l1l1_l1_ (u"ࠧࠨ㵀")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠨࠩ㵁"),headers,l1l1l1_l1_ (u"ࠩࠪ㵂"),l1l1l1_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ㵃"))
	if type==l1l1l1_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ㵄"): block = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃษอะอࠣห้ษแๅษ่ࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ㵅"),html,re.DOTALL)[0]
	elif type==l1l1l1_l1_ (u"࠭ࡢࡰࡺ࠰ࡳ࡫࡬ࡩࡤࡧࠪ㵆"): block = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࠨ࠾ษ๊ๆืࠥอ่โ์ึࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࡭࠷ࠧ㵇"),html,re.DOTALL)[0]
	elif type==l1l1l1_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㵈"): block = re.findall(l1l1l1_l1_ (u"ࠩࡥࡸࡳ࠳࠲࠮ࡱࡹࡩࡷࡲࡡࡺࠪ࠱࠮ࡄ࠯࠼ࡴࡶࡼࡰࡪࡄࠧ㵉"),html,re.DOTALL)[0]
	elif type==l1l1l1_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭㵊"): block = re.findall(l1l1l1_l1_ (u"ࠫࡧࡺ࡮࠮࠳ࠣࡦࡹࡴ࠭ࡢࡤࡶࡳࡱࡿࠨ࠯ࠬࡂ࠭ࡧࡺ࡮࠮࠴ࠣࡦࡹࡴ࠭ࡢࡤࡶࡳࡱࡿࠧ㵋"),html,re.DOTALL)[0]
	elif type==l1l1l1_l1_ (u"ࠬࡺࡶࠨ㵌"): block = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄสๅ์ไึ๏๎ๆࠡ็๋ๅ๏ุࠠๅษ้ำࡁ࠵ࡨ࠲ࡀࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳ࡭ࠢࠨ㵍"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l1l1_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ㵎"),l1l1l1_l1_ (u"ࠨࡶࡲࡴ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㵏")]:
		items = re.findall(l1l1l1_l1_ (u"ࠩࡶࡸࡾࡲࡥ࠾ࠤࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡺࡴࡰ࡯࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㵐"),block,re.DOTALL)
	else: items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠸ࡡ࠰࠮࠻ࡠ࠯ࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㵑"),block,re.DOTALL)
	l1l1_l1_ = []
	l11ll1111_l1_ = [l1l1l1_l1_ (u"ࠫๆ๐ไๆࠩ㵒"),l1l1l1_l1_ (u"ࠬอไฮๆๅอࠬ㵓"),l1l1l1_l1_ (u"࠭วๅฯ็ๆ์࠭㵔"),l1l1l1_l1_ (u"ฺࠧำูࠫ㵕"),l1l1l1_l1_ (u"ࠨࡔࡤࡻࠬ㵖"),l1l1l1_l1_ (u"ࠩࡖࡱࡦࡩ࡫ࡅࡱࡺࡲࠬ㵗"),l1l1l1_l1_ (u"ࠪห฾๊ว็ࠩ㵘"),l1l1l1_l1_ (u"ࠫฬาาศรࠪ㵙")]
	for img,l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_,l1l1l1ll1ll_l1_ in items:
		if type in [l1l1l1_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ㵚"),l1l1l1_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ㵛")]:
			img,l111ll_l1_,l11111ll1_l1_,title = img,l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_,l1l1l1ll1ll_l1_
		else: img,title,l111ll_l1_,l11111ll1_l1_ = img,l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_,l1l1l1ll1ll_l1_
		l111ll_l1_ = UNQUOTE(l111ll_l1_)
		l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠧࡀࡸ࡬ࡩࡼࡃࡴࡳࡷࡨࠫ㵜"),l1l1l1_l1_ (u"ࠨࠩ㵝"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㵞"),l1l1l1_l1_ (u"ࠪࠫ㵟"),l111ll_l1_,l11111ll1_l1_)
		title = unescapeHTML(title)
		#title2 = re.findall(l1l1l1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠫฬั๎ฯสࡾหะํี็ࠪࠩ㵠"),title,re.DOTALL)
		#if title2: title = title2[0][0]
		if l1l1l1_l1_ (u"ࠬฮฬ้ัฬࠤࠬ㵡") in title or l1l1l1_l1_ (u"࠭ศอ๊า๋ࠥ࠭㵢") in title:
			title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㵣") + title.replace(l1l1l1_l1_ (u"ࠨสฯ์ิฯࠠࠨ㵤"),l1l1l1_l1_ (u"ࠩࠪ㵥")).replace(l1l1l1_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ㵦"),l1l1l1_l1_ (u"ࠫࠬ㵧"))
		title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧ㵨"))
		if l1l1l1_l1_ (u"࠭วๅฯ็ๆฮ࠭㵩") in title or l1l1l1_l1_ (u"ࠧศๆะ่็ํࠧ㵪") in title:
			l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡟ࡨ࠰࠭㵫"),title,re.DOTALL)
			if l1llll1_l1_:
				title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㵬") + l1llll1_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㵭"),menu_name+title,l111ll_l1_,183,img)
					l1l1_l1_.append(title)
		elif any(value in title for value in l11ll1111_l1_):
			l111ll_l1_ = l111ll_l1_ + l1l1l1_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ㵮") + l11111ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㵯"),menu_name+title,l111ll_l1_,182,img)
		else:
			l111ll_l1_ = l111ll_l1_ + l1l1l1_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ㵰") + l11111ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㵱"),menu_name+title,l111ll_l1_,183,img)
	if type==l1l1l1_l1_ (u"ࠨࠩ㵲"):
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࡲࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㵳"),html,re.DOTALL)
		for l111ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"ࠪห้฻แฮหࠣࠫ㵴"),l1l1l1_l1_ (u"ࠫࠬ㵵"))
			if title!=l1l1l1_l1_ (u"ࠬ࠭㵶"):
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㵷"),menu_name+l1l1l1_l1_ (u"ࠧึใะอࠥ࠭㵸")+title,l111ll_l1_,181)
	return
def l11l1ll_l1_(url):
	url2 = url.split(l1l1l1_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ㵹"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠩࠪ㵺"),headers,l1l1l1_l1_ (u"ࠪࠫ㵻"),l1l1l1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭㵼"))
	block = re.findall(l1l1l1_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡩࡵ࡮ࡨࡂ࠳࠰࠿ࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࡞࠴࠲࠿࡝ࠬࠫࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㵽"),html,re.DOTALL)
	title,dummy,img = block[0]
	name = re.findall(l1l1l1_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡜࠲࠰࠽ࡢ࠱ࠧ㵾"),title,re.DOTALL)
	if name: name = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㵿") + name[0][0]
	else: name = title
	items = []
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࡑࡹࡲࡨࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㶀"),html,re.DOTALL)
	if l1ll1l1_l1_:
		#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㶁"),l1l1l1_l1_ (u"ࠪࠫ㶂"),url2,str(l1ll1l1_l1_))
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㶃"),block,re.DOTALL)
		for l111ll_l1_ in items:
			l111ll_l1_ = UNQUOTE(l111ll_l1_)
			title = re.findall(l1l1l1_l1_ (u"ࠬ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ㶄"),l111ll_l1_.split(l1l1l1_l1_ (u"࠭࠯ࠨ㶅"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l1l1_l1_ (u"ࠧࠩࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ㶆"),l111ll_l1_.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ㶇"))[-2],re.DOTALL)
			if title: title = l1l1l1_l1_ (u"ࠩࠣࠫ㶈") + title[0][1]
			else: title = l1l1l1_l1_ (u"ࠪࠫ㶉")
			title = name + l1l1l1_l1_ (u"ࠫࠥ࠳ࠠࠨ㶊") + l1l1l1_l1_ (u"ࠬอไฮๆๅอࠬ㶋") + title
			title = unescapeHTML(title)
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㶌"),menu_name+title,l111ll_l1_,182,img)
	if not items:
		title = unescapeHTML(title)
		if l1l1l1_l1_ (u"ࠧษฮ๋ำฮࠦࠧ㶍") in title or l1l1l1_l1_ (u"ࠨสฯ์ิํࠠࠨ㶎") in title:
			title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㶏") + title.replace(l1l1l1_l1_ (u"ࠪฬั๎ฯสࠢࠪ㶐"),l1l1l1_l1_ (u"ࠫࠬ㶑")).replace(l1l1l1_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ㶒"),l1l1l1_l1_ (u"࠭ࠧ㶓"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㶔"),menu_name+title,url,182,img)
	return
def PLAY(url):
	l1l1l1lll11_l1_ = url.split(l1l1l1_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ㶕"))
	url2 = l1l1l1lll11_l1_[0]
	del l1l1l1lll11_l1_[0]
	html = OPENURL_CACHED(l11l11l_l1_,url2,l1l1l1_l1_ (u"ࠩࠪ㶖"),headers,l1l1l1_l1_ (u"ࠪࠫ㶗"),l1l1l1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㶘"))
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡬࡯࡯ࡶ࠰ࡷ࡮ࢀࡥ࠻ࠢ࠵࠹ࡵࡾ࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㶙"),html,re.DOTALL)[0]
	if l111ll_l1_ not in l1l1l1lll11_l1_: l1l1l1lll11_l1_.append(l111ll_l1_)
	l11l1_l1_ = []
	# l1l1l1l1ll1_l1_
	for l111ll_l1_ in l1l1l1lll11_l1_:
		if l1l1l1_l1_ (u"࠭࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ㶚") in l111ll_l1_:
			l1l1l1l1ll1_l1_ = l111ll_l1_
			l11l1_l1_.append(l1l1l1l1ll1_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡣ࡬ࡲࠬ㶛"))
	# l1l1l1l1l11_l1_
	for l111ll_l1_ in l1l1l1lll11_l1_:
		if l1l1l1_l1_ (u"ࠨ࠼࠲࠳ࡻࡨ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠫ㶜") in l111ll_l1_:
			html = OPENURL_CACHED(l11l11l_l1_,l111ll_l1_,l1l1l1_l1_ (u"ࠩࠪ㶝"),headers,l1l1l1_l1_ (u"ࠪࠫ㶞"),l1l1l1_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㶟"))
			html = html.decode(l1l1l1_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡸ࠳࠱࠳࠷࠹ࠫ㶠")).encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㶡"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l1l1l11ll11_l1_><l1l1l1l1111_l1_ /><l1l1l11ll11_l1_ l1l1l1ll111_l1_=l1l1l1_l1_ (u"ࠢࡤࡧࡱࡸࡪࡸࠢ㶢")>(\*\*\*\*\*\*\*\*|13721411411.l1l1l11l1l1_l1_|)
			html = html.replace(l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㶣"),l1l1l1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㶤"))
			html = html.replace(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㶥"),l1l1l1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ㶦"))
			html = html.replace(l1l1l1_l1_ (u"ࠬࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡥࡶࠥ࠵࠾࠽ࡦ࡬ࡺࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࡄࠧ㶧"),l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㶨"))
			html = html.replace(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡤࡲࡶࡩ࡫ࡲࠣࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠪ㶩"),l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㶪"))
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ㶫"),html,re.DOTALL)
			if l1ll1l1_l1_:
				#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ㶬"),l1l1l1_l1_ (u"ࠫࠬ㶭"),url,str(len(l1ll1l1_l1_)))
				l1l1l11l1ll_l1_,l1l1l1l11ll_l1_ = [],[]
				if len(l1ll1l1_l1_)==1:
					title = l1l1l1_l1_ (u"ࠬ࠭㶮")
					block = html
				else:
					for block in l1ll1l1_l1_:
						l11ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠲࠯ࡅ࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰ࠫࠩ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ㶯"),block,re.DOTALL)
						if l11ll_l1_: block = l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ㶰") + l11ll_l1_[0][1]
						l11ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅ࠼ࡩࡴࠣࡷ࡮ࢀࡥ࠾ࠤ࠴ࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴࠽ࠣࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡤࡱ࡯ࡳࡷࡀࠣ࠴࠵࠶ࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ㶱"),block,re.DOTALL)
						if l11ll_l1_: block = l1l1l1_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ㶲") + l11ll_l1_[0]
						l11ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࠩ࠽ࡪࡵࠤࡸ࡯ࡺࡦ࠿ࠥ࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࠩ࠳࠴࠵࠾ࠤࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮ࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࠧࠦ࠯࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ㶳"),block,re.DOTALL)
						if l11ll_l1_: block = l11ll_l1_[0] + l1l1l1_l1_ (u"ࠫࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㶴")
						l1l1l1l1lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡂࠨ࠯ࠬࡂ࠭࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠬࡴࡴ࡬ࡪࡰࡨࢀࡨࡵ࡭ࠪ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲ࠫ㶵"),block,re.DOTALL)
						title = re.findall(l1l1l1_l1_ (u"࠭࠾ࠡࠬࠫ࡟ࡣࡂ࠾࡞࠭ࠬࠤ࠯ࡂࠧ㶶"),l1l1l1l1lll_l1_[0][0],re.DOTALL)
						title = l1l1l1_l1_ (u"ࠧࠡࠩ㶷").join(title)
						title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪ㶸"))
						title = title.replace(l1l1l1_l1_ (u"ࠩࠣࠤࠬ㶹"),l1l1l1_l1_ (u"ࠪࠤࠬ㶺")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠧ㶻"),l1l1l1_l1_ (u"ࠬࠦࠧ㶼")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ㶽"),l1l1l1_l1_ (u"ࠧࠡࠩ㶾")).replace(l1l1l1_l1_ (u"ࠨࠢࠣࠫ㶿"),l1l1l1_l1_ (u"ࠩࠣࠫ㷀")).replace(l1l1l1_l1_ (u"ࠪࠤࠥ࠭㷁"),l1l1l1_l1_ (u"ࠫࠥ࠭㷂"))
						l1l1l11l1ll_l1_.append(title)
					selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅุๆ๋ฬ࠿࠭㷃"), l1l1l11l1ll_l1_)
					if selection == -1 : return
					title = l1l1l11l1ll_l1_[selection]
					block = l1ll1l1_l1_[selection]
				l111ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠪࠤࠪ㷄"),block,re.DOTALL)
				l1l1l1l111l_l1_ = l111ll_l1_[0]
				l11l1_l1_.append(l1l1l1l111l_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡇࡱࡵࡹࡲ࠭㷅"))
				block = block.replace(l1l1l1_l1_ (u"ࠨโࠪ㷆"),l1l1l1_l1_ (u"ࠩࠪ㷇"))
				block = block.replace(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠸࠵࠼࠺࠱࠳࠳࠺࠹࠷࠿࠶࠯ࡲࡱ࡫ࠧ࠭㷈"),l1l1l1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡥࡳࡹ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ㷉"))
				block = block.replace(l1l1l1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡦࡳࡲ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠷࠴࠻࠹࠷࠲࠲࠹࠸࠶࠾࠼࠮ࡱࡰࡪࠦࠬ㷊"),l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡧࡵࡴࡩࠤࠣࠤࡡࡴࠠࠡࠩ㷋"))
				block = block.replace(l1l1l1_l1_ (u"ࠧิ์ิๅึอสࠡษ็ฮา๋๊ๅࠩ㷌"),l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠢࠣࡠࡳࠦࠠࠨ㷍"))
				block = block.replace(l1l1l1_l1_ (u"ࠩิ์ฬฮืࠡษ็ฮา๋๊ๅࠩ㷎"),l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࠥࠤࠥࡢ࡮ࠡࠢࠪ㷏"))
				block = block.replace(l1l1l1_l1_ (u"ุࠫ๐ัโำสฮࠥอไๆึส๋ิ࠭㷐"),l1l1l1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡻࡦࡺࡣࡩࠤࠣࠤࡡࡴࠠࠡࠩ㷑"))
				block = block.replace(l1l1l1_l1_ (u"࠭ั้ษห฻ࠥอไๆึส๋ิ࠭㷒"),l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡽࡡࡵࡥ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ㷓"))
				l1l1l11lll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲ࡠࡩ࠱ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ㷔"),block,re.DOTALL)
				for l1l1l1l11l1_l1_ in l1l1l11lll1_l1_:
					#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㷕"),l1l1l1_l1_ (u"ࠪࠫ㷖"),l1l1l1_l1_ (u"ࠫࠬ㷗"),str(l1l1l1l11l1_l1_))
					type = re.findall(l1l1l1_l1_ (u"ࠬࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࠪ㷘"),l1l1l1l11l1_l1_)
					if type:
						if type[0]!=l1l1l1_l1_ (u"࠭ࡢࡰࡶ࡫ࠫ㷙"): type = l1l1l1_l1_ (u"ࠧࡠࡡࠪ㷚")+type[0]
						else: type = l1l1l1_l1_ (u"ࠨࠩ㷛")
					items = re.findall(l1l1l1_l1_ (u"ࠩࠫࡃࡁࠧࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲࠭࠭ࡢࡷࠬ࡝ࠣࡠࡼࡣࠪ࠽࠱ࡩࡳࡳࡺ࠾࠯ࠬࡂࢀࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰࠼ࡣࡴࠣ࠳ࡃ࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࠮ࠫࡁࠬࠦࠬ㷜"),l1l1l1l11l1_l1_,re.DOTALL)
					for l1l1l11llll_l1_,l111ll_l1_ in items:
						title = re.findall(l1l1l1_l1_ (u"ࠪࠬࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰ࠩ࠽ࠩ㷝"),l1l1l11llll_l1_)
						title = title[-1]
						l111ll_l1_ = l111ll_l1_ + l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㷞") + title + type
						l11l1_l1_.append(l111ll_l1_)
	# l1l1l1lll1l_l1_
	url3 = url2.replace(l1l11l_l1_,l1ll11ll1l_l1_)
	html = OPENURL_CACHED(l11l11l_l1_,url3,l1l1l1_l1_ (u"ࠬ࠭㷟"),headers,l1l1l1_l1_ (u"࠭ࠧ㷠"),l1l1l1_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㷡"))
	items = re.findall(l1l1l1_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㷢"),html,re.DOTALL)
	#id2 = re.findall(l1l1l1_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡪࡳࡢࡦࡦࡐ࠱࠭ࡢࡷࠬࠫ࠰࠲࠯ࡅ࠮ࡩࡶࡰࡰ࠮࠭㷣"),html,re.DOTALL)
	#if id2:
	if items:
		#l1l1l1lll1l_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴࠭㷤") + id2[-1] + l1l1l1_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ㷥")
		l1l1l1lll1l_l1_ = items[-1]
		l11l1_l1_.append(l1l1l1lll1l_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓ࡯ࡣ࡫࡯ࡩࠬ㷦"))
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㷧"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨ㷨"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩ㷩"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫ㷪"),l1l1l1_l1_ (u"ࠪ࠯ࠬ㷫"))
	html = OPENURL_CACHED(REGULAR_CACHE,l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬ㷬"),headers,l1l1l1_l1_ (u"ࠬ࠭㷭"),l1l1l1_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭㷮"))
	items = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮࠿ࠩ㷯"),html,re.DOTALL)
	l11l1lll1_l1_ = [ l1l1l1_l1_ (u"ࠨࠩ㷰") ]
	l11l11ll1_l1_ = [ l1l1l1_l1_ (u"ࠩส่่๊้ࠠสา์๋ࠦแๅฬิࠫ㷱") ]
	for category,title in items:
		l11l1lll1_l1_.append(category)
		l11l11ll1_l1_.append(title)
	if category:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ㷲"), l11l11ll1_l1_)
		if selection == -1 : return
		category = l11l1lll1_l1_[selection]
	else: category = l1l1l1_l1_ (u"ࠫࠬ㷳")
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ㷴")+search+l1l1l1_l1_ (u"࠭ࠦ࡮ࡥࡤࡸࡂ࠭㷵")+category
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ㷶"),l1l1l1_l1_ (u"ࠨࠩ㷷"),url,url)
	l11l11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ军")
headers = { l1l1l1_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ农") : l1l1l1_l1_ (u"ࠬ࠭冝") }
menu_name = l1l1l1_l1_ (u"࠭࡟ࡔࡊ࠷ࡣࠬ冞")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ฺࠧำฺ๋๋ࠥีศำ฼อࠬ冟"),l1l1l1_l1_ (u"ࠨษ็็้࠭冠"),l1l1l1_l1_ (u"ࠩสๅ้อๅࠨ冡"),l1l1l1_l1_ (u"ࠪ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠧ冢"),l1l1l1_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ冣")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l11l11_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l11l1ll_l1_(url)
	elif mode==114: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭冤")+text)
	elif mode==115: results = l1111l1_l1_(url,l1l1l1_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ冥")+text)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ冦"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩ冧"),headers,l1l1l1_l1_ (u"ࠩࠪ冨"),l1l1l1_l1_ (u"ࠪࠫ冩"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ冪"))
	html = response.content
	l11lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ冫"),html,re.DOTALL)
	if l11lll11_l1_: l11lll11_l1_ = l11lll11_l1_[0].strip(l1l1l1_l1_ (u"࠭࠯ࠨ冬"))
	else: l11lll11_l1_ = l1l11l_l1_
	l11l1l_l1_ = SERVER(l11lll11_l1_,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ冭"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ冮"),menu_name+l1l1l1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ冯"),l1l1l1_l1_ (u"ࠪࠫ冰"),119,l1l1l1_l1_ (u"ࠫࠬ冱"),l1l1l1_l1_ (u"ࠬ࠭冲"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ决"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冴"),menu_name+l1l1l1_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ况"),l11lll11_l1_,115)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ冶"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭冷"),l11lll11_l1_,114)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ冸"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ冹"),l1l1l1_l1_ (u"࠭ࠧ冺"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ冻"),l11lll11_l1_,l1l1l1_l1_ (u"ࠨࠩ冼"),headers,l1l1l1_l1_ (u"ࠩࠪ冽"),l1l1l1_l1_ (u"ࠪࠫ冾"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ冿"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯ࡷࡥࡧࡹࠨ࠯ࠬࡂ࠭ࡦࡪࡶࡢࡰࡦࡩࡩ࠳ࡳࡦࡣࡵࡧ࡭࠭净"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ凁"),block,re.DOTALL)
		for filter,title in items:
			#url = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴࡙ࡨࡢࡪ࡬ࡨ࠹ࡻ࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡉࡱࡰࡩ࠳ࡶࡨࡱࠩ凂")
			url = l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴ࡎ࡯࡮ࡧ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬ࡎ࡯࡮ࡧ࠱ࡴ࡭ࡶࠧ凃")
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ凄"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ凅")+menu_name+title,url,111,l1l1l1_l1_ (u"ࠫࠬ准"),l1l1l1_l1_ (u"ࠬ࠭凇"),filter)
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ凈"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ凉"),l1l1l1_l1_ (u"ࠨࠩ凊"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ凋"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ凌"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title in l1l1ll_l1_: continue
			if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ凍") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l111ll_l1_
			title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧ凎"))
			if l1l1l1_l1_ (u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧ减") in l111ll_l1_: title = l1l1l1_l1_ (u"ࠧ็์อๅ้้ำࠨ凐")
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ凑"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ凒")+menu_name+title,l111ll_l1_,111)
	return html
def l11l11_l1_(url,l111l1111_l1_=l1l1l1_l1_ (u"ࠪࠫ凓")):
	if l1l1l1_l1_ (u"ࠫ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡔࡪࡲࡻࡸ࠴ࡰࡩࡲࡂࠫ凔") in url:
		url,data = URLDECODE(url)
		headers2 = {l1l1l1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ凕"):l1l1l1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭凖"),l1l1l1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ凗"):l1l1l1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ凘")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ凙"),url,data,headers2,l1l1l1_l1_ (u"ࠪࠫ凚"),l1l1l1_l1_ (u"ࠫࠬ凛"),l1l1l1_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ凜"))
		html = response.content
		block = html
	elif l1l1l1_l1_ (u"࠭ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡊࡲࡱࡪ࠴ࡰࡩࡲࠪ凝") in url:
		data = {l1l1l1_l1_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࠧ凞"):l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡥࡰࡴࡩ࡫ࠨ凟"),l1l1l1_l1_ (u"ࠩ࡮ࡩࡾ࠭几"):l111l1111_l1_}
		headers2 = {l1l1l1_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭凡"):l1l1l1_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ凢")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ凣"),url,data,headers2,l1l1l1_l1_ (u"࠭ࠧ凤"),l1l1l1_l1_ (u"ࠧࠨ凥"),l1l1l1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ処"))
		html = response.content
		block = html
	else:
		headers2 = {l1l1l1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ凧"):l1l1l1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ凨")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ凩"),url,l1l1l1_l1_ (u"ࠬ࠭凪"),headers2,l1l1l1_l1_ (u"࠭ࠧ凫"),l1l1l1_l1_ (u"ࠧࠨ凬"),l1l1l1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠷ࡷࡪࠧ凭"))
		html = response.content
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡺࡡࡨࡵ࠰ࡧࡱࡵࡵࡥࠩ凮"),html,re.DOTALL)
		if not l1ll1l1_l1_: return
		block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ凯"),block,re.DOTALL)
	items = re.findall(l1l1l1_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲࡯࡭ࡢࡩࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ凰"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"๋ࠬิศ้าอࠬ凱"),l1l1l1_l1_ (u"࠭แ๋ๆ่ࠫ凲"),l1l1l1_l1_ (u"ࠧศ฼้๎ฮ࠭凳"),l1l1l1_l1_ (u"ࠨๅ็๎อ࠭凴"),l1l1l1_l1_ (u"ࠩส฽้อๆࠨ凵"),l1l1l1_l1_ (u"๋ࠪิอแࠨ凶"),l1l1l1_l1_ (u"๊ࠫฮวาษฬࠫ凷"),l1l1l1_l1_ (u"ࠬ฿ัืࠩ凸"),l1l1l1_l1_ (u"࠭ๅ่ำฯห๋࠭凹"),l1l1l1_l1_ (u"ࠧศๆห์๊࠭出")]
	for l111ll_l1_,img,title in items:
		if l1l1l1_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ击") in l111ll_l1_: continue
		#if l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ凼") in l111ll_l1_: continue
		#l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠪࠪࠨ࠶࠳࠹࠽ࠪ函"),l1l1l1_l1_ (u"ࠫࠫ࠭凾"))
		l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠬ࠵ࠧ凿"))
		title = unescapeHTML(title)
		title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ刀"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ刁"),title,re.DOTALL)
		if l1l1l1_l1_ (u"ࠨใํ่๊࠭刂") in l111ll_l1_ or any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ刃"),menu_name+title,l111ll_l1_,112,img)
		elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠪห้ำไใหࠪ刄") in title and l1l1l1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ刅") not in url:
			title = l1l1l1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ分") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭切"),menu_name+title,l111ll_l1_,113,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸ࠯ࠨ刈") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ刉"),menu_name+title,l111ll_l1_,111,img)
		elif l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ刊") in l111ll_l1_ and l1l1l1_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ刋") not in url:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ刌")
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ刍"),menu_name+title,l111ll_l1_,111,img)
		elif l1l1l1_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ刎") in url and l1l1l1_l1_ (u"ࠧฮๆๅอࠬ刏") in title:
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ刐"),menu_name+title,l111ll_l1_,112,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ刑"),menu_name+title,l111ll_l1_,113,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ划"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ刓"),block,re.DOTALL)
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ刔"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = unescapeHTML(l111ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"࠭วๅืไัฮࠦࠧ刕"),l1l1l1_l1_ (u"ࠧࠨ刖"))
			if title!=l1l1l1_l1_ (u"ࠨࠩ列"): addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ刘"),menu_name+l1l1l1_l1_ (u"ูࠪๆำษࠡࠩ则")+title,l111ll_l1_,111)
	l1111ll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭刚"),html,re.DOTALL)
	if l1111ll11_l1_:
		l111ll_l1_ = l1111ll11_l1_[0]
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ创"),menu_name+l1l1l1_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭刜"),l111ll_l1_,111)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ初"),url,l1l1l1_l1_ (u"ࠨࠩ刞"),headers,l1l1l1_l1_ (u"ࠩࠪ刟"),l1l1l1_l1_ (u"ࠪࠫ删"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ刡"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࠠࡪࡦࡀࠦࡸ࡫ࡡࡴࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡸࡦ࡭ࡳ࠮ࡥ࡯ࡳࡺࡪࠧ刢"),html,re.DOTALL)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ刣"),html,re.DOTALL)
	items = []
	# l111l1_l1_
	if l1ll11l_l1_ and l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ判") not in url:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭別"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ刦"))
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ刧"),menu_name+title,l111ll_l1_,113,img)
	# l1ll1_l1_
	elif l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡟ࡦ࠳ࡺ࡞࠭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ刨"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧ利"))
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ刪"),menu_name+title,l111ll_l1_,112,img)
	# l1ll1_l1_ l11lll1l_l1_
	if not items and l1l1l1_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭别") in html:
		l1l1lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡵࡩࡦࡪࡣࡳࡷࡰࡦࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ刬"),html,re.DOTALL)
		if l1l1lll11_l1_:
			block = l1l1lll11_l1_[0]
			l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ刭"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l111ll_l1_ = l1ll_l1_[2]+l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ刮")
				l11l11_l1_(l111ll_l1_)
	return
def PLAY(url):
	l11l1_l1_ = []
	l1111lll_l1_ = url.strip(l1l1l1_l1_ (u"ࠫ࠴࠭刯"))
	hostname = SERVER(l1111lll_l1_,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ到"))
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ刱"),l1111lll_l1_,l1l1l1_l1_ (u"ࠧࠨ刲"),headers,l1l1l1_l1_ (u"ࠨࠩ刳"),l1l1l1_l1_ (u"ࠩࠪ刴"),l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ刵"))
	html = response.content#.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ制"))
	id = re.findall(l1l1l1_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭刷"),html,re.DOTALL)
	if not id: id = re.findall(l1l1l1_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ券"),html,re.DOTALL)
	if not id: id = re.findall(l1l1l1_l1_ (u"ࠧࡱࡱࡶࡸ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ刹"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l1l1l1_l1_ (u"ࠨࠩ刺")
	#else: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ刻"),l1l1l1_l1_ (u"ࠪࠫ刼"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ刽"),l1l1l1_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩ刾"))
	if l1l1l1_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠢࠨ刿") in html:
		#parts = url.split(l1l1l1_l1_ (u"ࠧ࠰ࠩ剀"))
		#url2 = url.replace(parts[3],l1l1l1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ剁"))
		url2 = l1111lll_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࠩ剂")
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ剃"),url2,l1l1l1_l1_ (u"ࠫࠬ剄"),headers,l1l1l1_l1_ (u"ࠬ࠭剅"),l1l1l1_l1_ (u"࠭ࠧ剆"),l1l1l1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ則"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭剈"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ剉"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		if l1ll1l1_l1_: l11ll_l1_ = l1ll1l1_l1_[0]
		else: l11ll_l1_ = l1l11l11_l1_
		if not id:
			id = re.findall(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡀࠦ࠵ࠨࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ削"),l11ll_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l1l1l1_l1_ (u"ࠫࠬ剋")
		l111lllll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ剌"),l1l11l11_l1_,re.DOTALL)
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ前"),l1l11l11_l1_,re.DOTALL)
		l11l11111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ剎"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࡝ࡰ࠭࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ剏"),l1l11l11_l1_)
		l111lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ剐"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ剑"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		l1l11lllll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ剒"),l11ll_l1_,re.DOTALL|re.IGNORECASE)
		l1l11lllllll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ剓"),l11ll_l1_,re.DOTALL|re.IGNORECASE)
		items = l111lllll_l1_+l1ll1ll_l1_+l11l11111_l1_+l111lll1l_l1_+l111lll11_l1_+l11l1l1l1_l1_+l1l11lllll11_l1_+l1l11lllllll_l1_
		if not items:
			items = re.findall(l1l1l1_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ剔"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠧ࡝ࡶࠪ剕"),l1l1l1_l1_ (u"ࠨࠩ剖")).replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ剗"),l1l1l1_l1_ (u"ࠪࠫ剘")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭剙"))
			#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭剚"),title)
			if l1l1l1_l1_ (u"࠭࠮ࡱࡰࡪࠫ剛") in server: continue
			if l1l1l1_l1_ (u"ࠧ࠯࡬ࡳ࡫ࠬ剜") in server: continue
			if l1l1l1_l1_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨ剝") in server: continue
			l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ剞"),title,re.DOTALL)
			if l11ll111_l1_:
				l11ll111_l1_ = l11ll111_l1_[0]
				if l11ll111_l1_ in title: title = title.replace(l11ll111_l1_+l1l1l1_l1_ (u"ࠪࡴࠬ剟"),l1l1l1_l1_ (u"ࠫࠬ剠")).replace(l11ll111_l1_,l1l1l1_l1_ (u"ࠬ࠭剡")).strip(l1l1l1_l1_ (u"࠭ࠠࠨ剢"))
				l11ll111_l1_ = l1l1l1_l1_ (u"ࠧࡠࡡࡢࡣࠬ剣")+l11ll111_l1_
			else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠨࠩ剤")
			if server.isdigit(): l111ll_l1_ = hostname+l1l1l1_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ剥")+id+l1l1l1_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ剦")+server+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ剧")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭剨")+l11ll111_l1_
			else:
				if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ剩") not in server: server = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭剪")+server
				l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ剫"),title,re.DOTALL)
				if l11ll111_l1_: l11ll111_l1_ = l1l1l1_l1_ (u"ࠩࡢࡣࡤࡥࠧ剬")+l11ll111_l1_[0]
				else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠪࠫ剭")
				l111ll_l1_ = server+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࠬ剮")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ副"),l11l1_l1_)
	#l11l1_l1_ = []
	if l1l1l1_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠥࠫ剰") in html:
		#parts = url.split(l1l1l1_l1_ (u"ࠧ࠰ࠩ剱"))
		#url2 = url.replace(parts[3],l1l1l1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ割"))
		url2 = l1111lll_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ剳")
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ剴"),url2,l1l1l1_l1_ (u"ࠫࠬ創"),headers,l1l1l1_l1_ (u"ࠬ࠭剶"),l1l1l1_l1_ (u"࠭ࠧ剷"),l1l1l1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ剸"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭剹"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡰࡩࡩ࡯ࡡ࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠯࠮࠽࠱ࡧ࡭ࡻࡄࠧ剺"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		if l1ll1l1_l1_: l11ll_l1_ = l1ll1l1_l1_[0]
		else: l11ll_l1_ = l1l11l11_l1_
		l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀ࡭࠹࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ剻"),l11ll_l1_,re.DOTALL)
		for title,block in l1l11l1_l1_:
			title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭剼"))
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ剽"),block,re.DOTALL)
			for l111ll_l1_,name,l11ll111_l1_ in items:
				l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭࡜ࡥ࠭ࠪ剾"),l11ll111_l1_,re.DOTALL)
				if l11ll111_l1_: l11ll111_l1_ = l1l1l1_l1_ (u"ࠧࡠࡡࡢࡣࠬ剿")+l11ll111_l1_[0]
				else:
					l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡞ࡧ࠯ࠬ劀"),title,re.DOTALL)
					if l11ll111_l1_: l11ll111_l1_ = l1l1l1_l1_ (u"ࠩࡢࡣࡤࡥࠧ劁")+l11ll111_l1_[0]
					else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠪࠫ劂")
				l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ劃")+name+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ劄")+l11ll111_l1_
				l11l1_l1_.append(l111ll_l1_)
		if not l1l11l1_l1_:
			#url2 = hostname +l1l1l1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡘ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡄࡰࡹࡱࡰࡴࡧࡤ࠯ࡲ࡫ࡴࠬ劅")
			url2 = hostname +l1l1l1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪ劆")
			headers2 = {l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ劇"):l1l1l1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ劈")}
			data2 = {l1l1l1_l1_ (u"ࠪ࡭ࡩ࠭劉"):id}
			response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ劊"),url2,data2,headers2,l1l1l1_l1_ (u"ࠬ࠭劋"),l1l1l1_l1_ (u"࠭ࠧ劌"),l1l1l1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ劍"))
			l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭劎"))
			items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭劏"),l1l11l11_l1_,re.DOTALL)
			for l111ll_l1_,name,l11ll111_l1_ in items:
				l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ劐")+name+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ劑")+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ劒")+l11ll111_l1_
				l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ劓"),l11l1_l1_)
	elif l1l1l1_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥࡐࡲࡻࠬ劔") in html:
		headers2 = { l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ劕"):l1l1l1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ劖") }
		url2 = l1111lll_l1_.replace(parts[3],l1l1l1_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ劗"))
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ劘"),url2,l1l1l1_l1_ (u"ࠬ࠭劙"),headers2,l1l1l1_l1_ (u"࠭ࠧ劚"),l1l1l1_l1_ (u"ࠧࠨ力"),l1l1l1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ劜"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ劝"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠯࡬ࡸࡪࡳࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ办"),l1l11l11_l1_,re.DOTALL)
		for block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭功"),block,re.DOTALL)
			for l111ll_l1_,name,l11ll111_l1_ in items:
				l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭加")+name+l1l1l1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ务")+l1l1l1_l1_ (u"ࠧࡠࡡࡢࡣࠬ劢")+l11ll111_l1_
				l11l1_l1_.append(l111ll_l1_)
	elif l1l1l1_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ劣") in html:
		headers2 = { l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭劤"):l1l1l1_l1_ (u"ࠪࠫ劥") , l1l1l1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ劦"):l1l1l1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭劧") }
		url2 = hostname + l1l1l1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩ动")+id
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ助"),url2,l1l1l1_l1_ (u"ࠨࠩ努"),headers2,l1l1l1_l1_ (u"ࠩࠪ劫"),l1l1l1_l1_ (u"ࠪࠫ劬"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ劭"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ劮"))
		if l1l1l1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤࡷࡲࡸ࠭劯") in l1l11l11_l1_:
			l11l11111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭劰"),l1l11l11_l1_,re.DOTALL)
			for url3 in l11l11111_l1_:
				if l1l1l1_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ励") not in url3 and l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ劲") in url3:
					url3 = url3+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ劳")
					l11l1_l1_.append(url3)
				elif l1l1l1_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ労") in url3:
					l11ll111_l1_ = l1l1l1_l1_ (u"ࠬ࠭劵")
					response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ劶"),url3,l1l1l1_l1_ (u"ࠧࠨ劷"),headers,l1l1l1_l1_ (u"ࠨࠩ劸"),l1l1l1_l1_ (u"ࠩࠪ効"),l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ劺"))
					l11l11l1l_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ劻"))
					l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠼ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂ࠭࠲࠳࠭࠮࠯ࠪ劼"),l11l11l1l_l1_,re.DOTALL)
					for l11ll11l1_l1_ in l1l11l1_l1_:
						l11l11lll_l1_ = l1l1l1_l1_ (u"࠭ࠧ劽")
						l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩ劾"),l11ll11l1_l1_,re.DOTALL)
						for l11l1ll11_l1_ in l111lll1l_l1_:
							item = re.findall(l1l1l1_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ势"),l11l1ll11_l1_,re.DOTALL)
							if item:
								l11ll111_l1_ = l1l1l1_l1_ (u"ࠩࡢࡣࡤࡥࠧ勀")+item[0]
								break
						for l11l1ll11_l1_ in reversed(l111lll1l_l1_):
							item = re.findall(l1l1l1_l1_ (u"ࠪࡠࡼࡢࡷࠬࠩ勁"),l11l1ll11_l1_,re.DOTALL)
							if item:
								l11l11lll_l1_ = item[0]
								break
						l111lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ勂"),l11ll11l1_l1_,re.DOTALL)
						for l11l1l11l_l1_ in l111lll11_l1_:
							l11l1l11l_l1_ = l11l1l11l_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭勃")+l11l11lll_l1_+l1l1l1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ勄")+l11ll111_l1_
							l11l1_l1_.append(l11l1l11l_l1_)
		elif l1l1l1_l1_ (u"ࠧࡴ࡮ࡲࡻ࠲ࡳ࡯ࡵ࡫ࡲࡲࠬ勅") in l1l11l11_l1_:
			l1l11l11_l1_ = l1l11l11_l1_.replace(l1l1l1_l1_ (u"ࠨ࠾࡫࠺ࠥ࠭勆"),l1l1l1_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠣࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠭勇"))+l1l1l1_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠫ勈")
			l1l11l11_l1_ = l1l11l11_l1_.replace(l1l1l1_l1_ (u"ࠫࡁ࡮࠳ࠡࠩ勉"),l1l1l1_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂࠦ࠽࠾ࡕࡗࡅࡗ࡚࠽࠾ࠩ勊"))+l1l1l1_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠧ勋")
			l111llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠾࠿ࡖࡘࡆࡘࡔ࠾࠿ࠫ࠲࠯ࡅࠩ࠾࠿ࡈࡒࡉࡃ࠽ࠨ勌"),l1l11l11_l1_,re.DOTALL)
			if l111llll1_l1_:
				for l11ll11l1_l1_ in l111llll1_l1_:
					if l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠧ勍") not in l11ll11l1_l1_: continue
					l11l1ll1l_l1_ = l1l1l1_l1_ (u"ࠩࠪ勎")
					l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ勏"),l11ll11l1_l1_,re.DOTALL)
					for l11l1ll11_l1_ in l111lll1l_l1_:
						item = re.findall(l1l1l1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ勐"),l11l1ll11_l1_,re.DOTALL)
						if item:
							l11l1ll1l_l1_ = l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ勑")+item[0]
							break
					l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ勒"),l11ll11l1_l1_,re.DOTALL)
					if l111lll1l_l1_:
						for l11l11lll_l1_,l11l1l111_l1_ in l111lll1l_l1_:
							l11l1l111_l1_ = l11l1l111_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ勓")+l11l11lll_l1_+l1l1l1_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ勔")+l11l1ll1l_l1_
							l11l1_l1_.append(l11l1l111_l1_)
					else:
						l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ動"),l11ll11l1_l1_,re.DOTALL)
						for l11l1l111_l1_,l11l11lll_l1_ in l111lll1l_l1_:
							l11l1l111_l1_ = l11l1l111_l1_.strip(l1l1l1_l1_ (u"ࠪࠤࠬ勖"))+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ勗")+l11l11lll_l1_+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ勘")+l11l1ll1l_l1_
							l11l1_l1_.append(l11l1l111_l1_)
			else:
				l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࡟ࡻ࠰࠯࠼ࠨ務"),l1l11l11_l1_,re.DOTALL)
				for l11l1l111_l1_,l11l11lll_l1_ in l111lll1l_l1_:
					l11l1l111_l1_ = l11l1l111_l1_.strip(l1l1l1_l1_ (u"ࠧࠡࠩ勚"))+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ勛")+l11l11lll_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭勜")
					l11l1_l1_.append(l11l1l111_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ勝"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ勞"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠬࠦࠧ募"),l1l1l1_l1_ (u"࠭ࠫࠨ勠"))
	if l111l_l1_:
		l11l11ll1_l1_ = [l1l1l1_l1_ (u"ࠧศใ็ห๊࠭勡"),l1l1l1_l1_ (u"ࠨ็ึุ่๊วหࠩ勢"),l1l1l1_l1_ (u"่้ࠩะ๊๊็ࠩ勣"),l1l1l1_l1_ (u"ࠪห้้ไࠨ勤")]
		l1ll1l1l1_l1_ = [l1l1l1_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ勥"),l1l1l1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ勦"),l1l1l1_l1_ (u"࠭ࡡࡤࡶࡲࡶࠬ勧"),l1l1l1_l1_ (u"ࠧࠨ勨")]
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠣ࠱ࠥอฮหำࠣห้็ไหำࠣห้๋ๆศีหࠫ勩"), l11l11ll1_l1_)
		if selection == -1 : return
		type = l1ll1l1l1_l1_[selection]
	else: type = l1l1l1_l1_ (u"ࠩࠪ勪")
	l1l1l1_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡪࡲࡱࡪ࠭ࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡰࡤࡱࡪࡃࠢࡵࡻࡳࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡳࡵࡴࠫࡷ࡭ࡵࡷࡥ࡫ࡤࡰࡴ࡭ࡳࠪ࠮ࡶࡸࡷ࠮࡬ࡦࡰࠫ࡬ࡹࡳ࡬ࠪࠫࠬࠎࠎ࡯ࡦࠡࡵ࡫ࡳࡼࡪࡩࡢ࡮ࡲ࡫ࡸࠦࡡ࡯ࡦࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠ࡜ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ࡞࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࡨࡰࡸ࡫࠺ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠭ࠧࠋࠋࠦࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠤࠥࠦ勫")
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ勬")+search+l1l1l1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ勭")+type
	l11l11_l1_(url)
	return
# ===========================================
#     l1111llll_l1_ l111111l1_l1_ l1llllllll_l1_
# ===========================================
def l1111lll1_l1_(url):
	url = url.split(l1l1l1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ勮"))[0]
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ勯"),url,l1l1l1_l1_ (u"ࠨࠩ勰"),headers,l1l1l1_l1_ (u"ࠩࠪ勱"),l1l1l1_l1_ (u"ࠪࠫ勲"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ勳"))
	html = response.content
	# all l1l11l1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ勴"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		# name + category + options block
		l11111l_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡰࡸ࠲࠯ࡅࡲࡰࡷࡱࡨࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡭ࡳࡶࡵࡵࠢࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ勵"),block,re.DOTALL)
		return l11111l_l1_
	return []
def l111111ll_l1_(block):
	# id + title
	items = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡩࡡࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩࡨࡦࡥ࡮ࡱࡦࡸ࡫࠮ࡤࡲࡰࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ勶"),block,re.DOTALL)
	return items
def l1l11lllll1l_l1_(url):
	url = url.replace(l1l1l1_l1_ (u"ࠨࡥࡤࡸࡂ࠭勷"),l1l1l1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ勸"))
	if l1l1l1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ勹") not in url: url = url+l1l1l1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ勺")
	l11111l1l_l1_ = url.split(l1l1l1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ勻"))[0]
	l11111l11_l1_ = SERVER(url,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ勼"))
	url = url.replace(l11111l1l_l1_,l11111l11_l1_)
	#url = url.replace(l1l1l1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ勽"),l1l1l1_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡕ࡫ࡳࡼࡹ࠮ࡱࡪࡳࡃࠬ勾"))
	url = url.replace(l1l1l1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭勿"),l1l1l1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡔࡪࡲࡻࡸ࠴ࡰࡩࡲࡂࠫ匀"))
	return url
l1l11llll1ll_l1_ = [l1l1l1_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ匁"),l1l1l1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ匂"),l1l1l1_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ匃"),l1l1l1_l1_ (u"ࠧࡤࡣࡷࠫ匄")]
l1l11llllll1_l1_ = [l1l1l1_l1_ (u"ࠨࡥࡤࡸࠬ包"),l1l1l1_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ匆"),l1l1l1_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ匇")]
def l1111l1_l1_(url,filter):
	#filter = filter.replace(l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭匈"),l1l1l1_l1_ (u"ࠬ࠭匉"))
	url = url.split(l1l1l1_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ匊"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫ匋"),1)
	if filter==l1l1l1_l1_ (u"ࠨࠩ匌"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠩࠪ匍"),l1l1l1_l1_ (u"ࠪࠫ匎")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨ匏"))
	if type==l1l1l1_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭匐"):
		if l1l11llllll1_l1_[0]+l1l1l1_l1_ (u"࠭࠽ࠨ匑") not in l1l1ll11_l1_: category = l1l11llllll1_l1_[0]
		for i in range(len(l1l11llllll1_l1_[0:-1])):
			if l1l11llllll1_l1_[i]+l1l1l1_l1_ (u"ࠧ࠾ࠩ匒") in l1l1ll11_l1_: category = l1l11llllll1_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠨࠨࠪ匓")+category+l1l1l1_l1_ (u"ࠩࡀ࠴ࠬ匔")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠪࠪࠬ匕")+category+l1l1l1_l1_ (u"ࠫࡂ࠶ࠧ化")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠬࠬࠧ北"))+l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪ匘")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠧࠧࠩ匙"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ匚"))
		url2 = url+l1l1l1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭匛")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ匜"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭匝"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠬ࠭匞"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ匟"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠧࠨ匠"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ匡")+l1l1l1ll_l1_
		url3 = l1l11lllll1l_l1_(url2)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ匢"),menu_name+l1l1l1_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭匣"),url3,111)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ匤"),menu_name+l1l1l1_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ匥")+l1l111ll_l1_+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ匦"),url3,111)
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ匧"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ匨"),l1l1l1_l1_ (u"ࠩࠪ匩"),9999)
	l11111l_l1_ = l1111lll1_l1_(url)
	dict = {}
	for name,l1llllll_l1_,block in l11111l_l1_:
		name = name.replace(l1l1l1_l1_ (u"ࠪ࠱࠲࠭匪"),l1l1l1_l1_ (u"ࠫࠬ匫"))
		items = l111111ll_l1_(block)
		if l1l1l1_l1_ (u"ࠬࡃࠧ匬") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ匭"):
			if category!=l1llllll_l1_: continue
			elif len(items)<2:
				if l1llllll_l1_==l1l11llllll1_l1_[-1]:
					url3 = l1l11lllll1l_l1_(url2)
					l11l11_l1_(url3)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ匮")+l1ll1111_l1_)
				return
			else:
				if l1llllll_l1_==l1l11llllll1_l1_[-1]:
					url3 = l1l11lllll1l_l1_(url2)
					addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ匯"),menu_name+l1l1l1_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ匰"),url3,111)
				else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ匱"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ匲"),url2,115,l1l1l1_l1_ (u"ࠬ࠭匳"),l1l1l1_l1_ (u"࠭ࠧ匴"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ匵"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠨࠨࠪ匶")+l1llllll_l1_+l1l1l1_l1_ (u"ࠩࡀ࠴ࠬ匷")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠪࠪࠬ匸")+l1llllll_l1_+l1l1l1_l1_ (u"ࠫࡂ࠶ࠧ匹")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࠩ区")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭医"),menu_name+l1l1l1_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ匼")+name,url2,114,l1l1l1_l1_ (u"ࠨࠩ匽"),l1l1l1_l1_ (u"ࠩࠪ匾"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ匿"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			if value==l1l1l1_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫ區"): option = l1l1l1_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬ十")
			elif value==l1l1l1_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭卂"): option = l1l1l1_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩ千")
			if option in l1l1ll_l1_: continue
			#if l1l1l1_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ卄") not in value: value = option
			#else: value = re.findall(l1l1l1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ卅"),value,re.DOTALL)[0]
			dict[l1llllll_l1_][value] = option
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠪࠪࠬ卆")+l1llllll_l1_+l1l1l1_l1_ (u"ࠫࡂ࠭升")+option
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠬࠬࠧ午")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽ࠨ卉")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫ半")+l1ll1ll1_l1_
			title = option+l1l1l1_l1_ (u"ࠨࠢ࠽ࠫ卋")#+dict[l1llllll_l1_][l1l1l1_l1_ (u"ࠩ࠳ࠫ卌")]
			title = option+l1l1l1_l1_ (u"ࠪࠤ࠿࠭卍")+name
			if type==l1l1l1_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ华"): addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ协"),menu_name+title,url,114,l1l1l1_l1_ (u"࠭ࠧ卐"),l1l1l1_l1_ (u"ࠧࠨ卑"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ卒"))
			elif type==l1l1l1_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ卓") and l1l11llllll1_l1_[-2]+l1l1l1_l1_ (u"ࠪࡁࠬ協") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ单"))
				url2 = url+l1l1l1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ卖")+l1l1l111_l1_
				url3 = l1l11lllll1l_l1_(url2)
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭南"),menu_name+title,url3,111)
			else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ単"),menu_name+title,url,115,l1l1l1_l1_ (u"ࠨࠩ卙"),l1l1l1_l1_ (u"ࠩࠪ博"),l1lllll1_l1_)
	return
def l1l1l11l_l1_(filters,mode):
	# mode==l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ卛")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ卜")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠬࡧ࡬࡭ࠩ卝")					all l1ll11ll_l1_ & l1111ll1l_l1_ filters
	filters = filters.replace(l1l1l1_l1_ (u"࠭࠽ࠧࠩ卞"),l1l1l1_l1_ (u"ࠧ࠾࠲ࠩࠫ卟"))
	filters = filters.strip(l1l1l1_l1_ (u"ࠨࠨࠪ占"))
	l1l1ll1l_l1_ = {}
	if l1l1l1_l1_ (u"ࠩࡀࠫ卡") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠪࠪࠬ卢"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠫࡂ࠭卣"))
			l1l1ll1l_l1_[var] = value
	l1llll1l_l1_ = l1l1l1_l1_ (u"ࠬ࠭卤")
	for key in l1l11llll1ll_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"࠭࠰ࠨ卥")
		if l1l1l1_l1_ (u"ࠧࠦࠩ卦") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ卧") and value!=l1l1l1_l1_ (u"ࠩ࠳ࠫ卨"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠪࠤ࠰ࠦࠧ卩")+value
		elif mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ卪") and value!=l1l1l1_l1_ (u"ࠬ࠶ࠧ卫"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"࠭ࠦࠨ卬")+key+l1l1l1_l1_ (u"ࠧ࠾ࠩ卭")+value
		elif mode==l1l1l1_l1_ (u"ࠨࡣ࡯ࡰࠬ卮"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠩࠩࠫ卯")+key+l1l1l1_l1_ (u"ࠪࡁࠬ印")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠫࠥ࠱ࠠࠨ危"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠬࠬࠧ卲"))
	l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"࠭࠽࠱ࠩ即"),l1l1l1_l1_ (u"ࠧ࠾ࠩ却"))
	return l1llll1l_l1_
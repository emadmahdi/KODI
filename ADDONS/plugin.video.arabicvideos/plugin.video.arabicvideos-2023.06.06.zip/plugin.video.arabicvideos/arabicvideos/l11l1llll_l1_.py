# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧო")
headers = { l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪპ") : l1l1l1_l1_ (u"ࠧࠨჟ") }
menu_name = l1l1l1_l1_ (u"ࠨࡡࡄࡖࡑࡥࠧრ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩს"),l1l1l1_l1_ (u"ࠪห้้ไࠨტ"),l1l1l1_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭უ"),l1l1l1_l1_ (u"ࠬอไฺษหࠫფ"),l1l1l1_l1_ (u"࠭ศาษ่ะ้ࠥๅษ์๋ฮึ࠭ქ"),l1l1l1_l1_ (u"ࠧๆ๊หห๏๊้ࠠࠢฯ์ฬ๊ࠧღ"),l1l1l1_l1_ (u"ࠨษ็ๆุ๋ࠠศๆสื้อๅ๋ࠩყ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l11l11_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l11l1ll_l1_(url)
	elif mode==204: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭შ")+text)
	elif mode==205: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪჩ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫც"),menu_name+l1l1l1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬძ"),l1l1l1_l1_ (u"࠭ࠧწ"),209,l1l1l1_l1_ (u"ࠧࠨჭ"),l1l1l1_l1_ (u"ࠨࠩხ"),l1l1l1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ჯ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪჰ"),menu_name+l1l1l1_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧჱ"),l1l11l_l1_,205)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬჲ"),menu_name+l1l1l1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩჳ"),l1l11l_l1_,204)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬჴ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨჵ"),l1l1l1_l1_ (u"ࠩࠪჶ"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪჷ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ჸ")+menu_name+l1l1l1_l1_ (u"๋ࠬๅ๋ิฬࠫჹ"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࠪჺ"),201)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ჻"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪჼ")+menu_name+l1l1l1_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧჽ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧჾ"),201)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫჿ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᄀ")+menu_name+l1l1l1_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᄁ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡸ࡫ࡲࡪࡧࡶࠫᄂ"),201)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᄃ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᄄ")+menu_name+l1l1l1_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬᄅ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫࡄࡅ࡭ࡢ࡫ࡱࡴࡦ࡭ࡥࠨᄆ"),201)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᄇ"),l1l11l_l1_,l1l1l1_l1_ (u"࠭ࠧᄈ"),headers,True,l1l1l1_l1_ (u"ࠧࠨᄉ"),l1l1l1_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᄊ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳ࡴࡢࡤࡶࠬ࠳࠰࠿ࠪࡏࡤ࡭ࡳࡘ࡯ࡸࠩᄋ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᄌ"),block,re.DOTALL)
		for filter,title in items:
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡬ࡴࡳࡥ࠰࡯ࡲࡶࡪࡅࡦࡪ࡮ࡷࡩࡷࡃࠧᄍ")+filter
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᄎ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᄏ")+menu_name+title,l111ll_l1_,201)
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᄐ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᄑ"),l1l1l1_l1_ (u"ࠩࠪᄒ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᄓ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᄔ"),block,re.DOTALL)
	#l11l11l11_l1_ = [l1l1l1_l1_ (u"๋ࠬำๅี็หฯࠦࠧᄕ"),l1l1l1_l1_ (u"࠭วโๆส้ࠥ࠭ᄖ"),l1l1l1_l1_ (u"ࠧษำส้ั࠭ᄗ"),l1l1l1_l1_ (u"ࠨ฻ิ์฻࠭ᄘ"),l1l1l1_l1_ (u"ࠩๆ่๏ฮวหࠩᄙ"),l1l1l1_l1_ (u"ࠪห฿อๆ๊ࠩᄚ")]
	for l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᄛ") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
		title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧᄜ"))
		if not any(value in title for value in l1l1ll_l1_):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᄝ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᄞ")+menu_name+title,l111ll_l1_,201)
	return html
def l11l11_l1_(url):
	l1l1l1_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡧࡱࡵࠤࡕࡕࡓࡕࠢࡩ࡭ࡱࡺࡥࡳ࠼ࠍࠍ࡮࡬ࠠࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬࠦࡩ࡯ࠢࡸࡶࡱࡀࠊࠊࠋࡸࡶࡱ࠸ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠳ࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨࡁࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࠪ࠰ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠫ࠮ࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠳࠮ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠭ࠏࠏࠉࡥࡣࡷࡥ࠷ࠦ࠽ࠡࡽࠪࡪࡴࡸ࡭ࠨ࠼ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠰ࠬࡌࡩ࡭ࡶࡨࡶ࡜ࡵࡲࡥ࠿ࠪ࠾ࠬ࠭ࡽࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡣࠠ࠾ࠢࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬࡣࠠ࠾ࠢࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪ࡜࠲ࡉࡓࡓࡈ࠰ࡘࡔࡑࡅࡏࠩࡠࠤࡂࠦࠧࡈ࡜࠷ࡓࡩ࠶࡮࡫ࡖࡆࡥࡌࡽࡣࡈࡳ࠷ࡍࡿࡍࡱࡉࡇࡵ࡝࠵ࡻ࡚ࡰࡣࡘ࡜࡟ࡉ࠶ࡉࡧ࡛ࡼࡽ࠭ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡣࠠ࠾ࠢࠪࡻࡦࡸࡢ࡭࡫ࡲࡲࡿࡺࡶࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࡨࡽࡏࡶࡤࡪࡋ࠹ࡍࡲࡘ࠰ࡎ࡚ࡑࡎ࡞ࡲࡒࡍࡓ࡭ࡨࡦࡔࡄ࡬ࡺ࡙ࡲࡩࡍ࡚࠲ࡄ࠵࡝ࡱࡋ࠹ࡑࡕࡌࡷࡎࡴ࡚ࡩࡤࡋ࡚ࡱࡏࡪࡰ࡫ࡔࡘࡗࡘࡖ࡙ࡏ࠴࡙࡯ࡲࡇࡣࡈࡉࡶࡦ࡛ࡆ࡬ࡑࡈࡼࡊࡕࡕࡗࡓ࡜࡙࠹࠷ࡤ࠲ࡐ࡚ࡩࡍࡩࡷࡦࡰࡐࡽ࡛࡝ࡒࡇࡓࡰࡰ࠷࡛ࡘࡊ࠲ࡧ࡯ࡽࡲ࡚࠲ࡄࡱࡥ࠸ࡶࡘࡔ࠳ࡅ࡛ࡧ࡚ࡁ࠴ࡕࡰࡒ࡯ࡪࡆࡥ࠵࡚ࡇࡎࡹࡉ࡮࠳࡫࡝ࡾࡏ࠶ࡊ࡬ࡘࡼ࡟࡚ࡧࡺࡐࡰࡑࡾࡕࡇࡆࡻࡐ࡮ࡎ࠶ࡎࡅࡐ࡯࡞࡯࡮࡬ࡏ࠴ࡑ࡯࡟࡚ࡂ࡮ࡐ࡭ࡨࡲ࡟ࡺࡂ࠲ࡑ࡮ࡆࡽࡍࡕࡌ࡮ࡑࡿࡠࡪࡐࡆࡌࡾࡓ࡚࡙ࡺࡏࡽ࡯࠵ࡔࡄࡤ࠷ࡐࡘࡇࡰࡎࡘࡋࡼࡓ࡙ࡲࡪࡏ࡬ࡪ࡭࡫ࡗ࠽࠾ࠩࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠴࠯ࡨࡦࡺࡡ࠳࠮࡫ࡩࡦࡪࡥࡳࡵ࠵࠰࡙ࡸࡵࡦ࠮ࠪࠫ࠱࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠨ࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠤࠥࠦᄟ")
	if l1l1l1_l1_ (u"ࠩࡂࡃࠬᄠ") in url: url,type = url.split(l1l1l1_l1_ (u"ࠪࡃࡄ࠭ᄡ"))
	else: type = l1l1l1_l1_ (u"ࠫࠬᄢ")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ᄣ"),l1l1l1_l1_ (u"࠭ࠧᄤ"),url,type)
	#if url==l1l11l_l1_: url = url+l1l1l1_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬᄥ")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩᄦ"),l1l1l1_l1_ (u"ࠩࠪᄧ"),url,l1l1l1_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪᄨ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨᄩ"),url,l1l1l1_l1_ (u"ࠬ࠭ᄪ"),headers,True,l1l1l1_l1_ (u"࠭ࠧᄫ"),l1l1l1_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᄬ"))
	html = response.content#.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᄭ"))
	#WRITE_THIS(html)
	if l1l1l1_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫᄮ") in url: l1ll1l1_l1_ = [html]
	elif type==l1l1l1_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬᄯ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡒࡧࡳࡵࡧࡵࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ᄰ"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᄱ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠱ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᄲ"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩᄳ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠴ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᄴ"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠩ࠴࠵࠶ࡳࡡࡪࡰࡳࡥ࡬࡫ࠧᄵ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨࡳࠣࠩᄶ"),html,re.DOTALL)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲ࠲࡬࡯ࡰࡶࡨࡶࠬᄷ"),html,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ᄸ"),l1l1l1_l1_ (u"࠭ࠧᄹ"),l1l1l1_l1_ (u"ࠧࠨᄺ"),str(l1ll1l1_l1_))
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᄻ"),block,re.DOTALL)
	l11ll1111_l1_ = [l1l1l1_l1_ (u"ุ่ࠩฬํฯสࠩᄼ"),l1l1l1_l1_ (u"ࠪๅ๏๊ๅࠨᄽ"),l1l1l1_l1_ (u"ࠫฬเๆ๋หࠪᄾ"),l1l1l1_l1_ (u"้ࠬไ๋สࠪᄿ"),l1l1l1_l1_ (u"࠭วฺๆส๊ࠬᅀ"),l1l1l1_l1_ (u"่ࠧัสๅࠬᅁ"),l1l1l1_l1_ (u"ࠨ็หหึอษࠨᅂ"),l1l1l1_l1_ (u"ࠩ฼ี฻࠭ᅃ"),l1l1l1_l1_ (u"้ࠪ์ืฬศ่ࠪᅄ"),l1l1l1_l1_ (u"ࠫฬ๊ศ้็ࠪᅅ")]
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᅆ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᅇ"),l1l1l1_l1_ (u"ࠧࠨᅈ"),9999)
	items = re.findall(l1l1l1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᅉ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l1l1_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᅊ"),block,re.DOTALL)
		l1ll_l1_,l11l111ll_l1_,titles = zip(*items)
		items = zip(l11l111ll_l1_,l1ll_l1_,titles)
	l1l1_l1_ = []
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = escapeUNICODE(l111ll_l1_)
		#l111ll_l1_ = QUOTE(l111ll_l1_)
		if l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᅋ") in l111ll_l1_: continue
		l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭ᅌ"))
		title = unescapeHTML(title)
		title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧᅍ"))
		if l1l1l1_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭ᅎ") in l111ll_l1_ or any(value in title for value in l11ll1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᅏ"),menu_name+title,l111ll_l1_,202,img)
		elif l1l1l1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫᅐ") in l111ll_l1_ and l1l1l1_l1_ (u"ࠩส่า๊โสࠩᅑ") in title:
			l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᅒ"),title,re.DOTALL)
			if l1llll1_l1_:
				title = l1l1l1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᅓ") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅔ"),menu_name+title,l111ll_l1_,203,img)
					l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"࠭࠯ࡱࡣࡦ࡯࠴࠭ᅕ") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅖ"),menu_name+title,l111ll_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨᅗ"),201,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅘ"),menu_name+title,l111ll_l1_,203,img)
	if type in [l1l1l1_l1_ (u"ࠪࠫᅙ"),l1l1l1_l1_ (u"ࠫࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ᅚ")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᅛ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᅜ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				l111ll_l1_ = unescapeHTML(l111ll_l1_)
				title = unescapeHTML(title)
				title = title.replace(l1l1l1_l1_ (u"ࠧศๆุๅาฯࠠࠨᅝ"),l1l1l1_l1_ (u"ࠨࠩᅞ"))
				if l1l1l1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᅟ") in url:
					l11l1111l_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᅠ"))[1]
					l11l1l1ll_l1_ = url.split(l1l1l1_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪᅡ"))[1]
					l111ll_l1_ = url.replace(l1l1l1_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫᅢ")+l11l1l1ll_l1_,l1l1l1_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬᅣ")+l11l1111l_l1_)
				if title!=l1l1l1_l1_ (u"ࠧࠨᅤ"): addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅥ"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨᅦ")+title,l111ll_l1_,201)
	return
def l11l1ll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫᅧ"),l1l1l1_l1_ (u"ࠫࠬᅨ"),url,l1l1l1_l1_ (u"ࠬ࠭ᅩ"))
	l11ll11ll_l1_,items,l11l1111_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪᅪ"),url,l1l1l1_l1_ (u"ࠧࠨᅫ"),headers,True,l1l1l1_l1_ (u"ࠨࠩᅬ"),l1l1l1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᅭ"))
	html = response.content#.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᅮ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᅯ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		l11l1111_l1_ = []
		l1l11l1_l1_ = l1l1l1_l1_ (u"ࠬ࠭ᅰ").join(l1ll1l1_l1_)
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᅱ"),l1l11l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨᅲ"))
	for l111ll_l1_ in items:
		l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪᅳ"))
		title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᅴ") + l111ll_l1_.split(l1l1l1_l1_ (u"ࠪ࠳ࠬᅵ"))[-1].replace(l1l1l1_l1_ (u"ࠫ࠲࠭ᅶ"),l1l1l1_l1_ (u"ࠬࠦࠧᅷ"))
		l11l1l11_l1_ = re.findall(l1l1l1_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬᅸ"),l111ll_l1_.split(l1l1l1_l1_ (u"ࠧ࠰ࠩᅹ"))[-1],re.DOTALL)
		if l11l1l11_l1_: l11l1l11_l1_ = l11l1l11_l1_[0]
		else: l11l1l11_l1_ = l1l1l1_l1_ (u"ࠨ࠲ࠪᅺ")
		l11l1111_l1_.append([l111ll_l1_,title,l11l1l11_l1_])
	items = sorted(l11l1111_l1_, reverse=False, key=lambda key: int(key[2]))
	l11ll111l_l1_ = str(items).count(l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᅻ"))
	l11ll11ll_l1_ = str(items).count(l1l1l1_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ᅼ"))
	if l11ll111l_l1_>1 and l11ll11ll_l1_>0 and l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᅽ") not in url:
		for l111ll_l1_,title,l11l1l11_l1_ in items:
			if l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧᅾ") in l111ll_l1_:
				#l111ll_l1_ = QUOTE(l111ll_l1_)
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅿ"),menu_name+title,l111ll_l1_,203)
	else:
		for l111ll_l1_,title,l11l1l11_l1_ in items:
			if l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩᆀ") not in l111ll_l1_:
				#if l1l1l1_l1_ (u"ࠨࠧࠪᆁ") not in l111ll_l1_: l111ll_l1_ = QUOTE(l111ll_l1_)
				#else: l111ll_l1_ = QUOTE(UNQUOTE(l111ll_l1_))
				#l111ll_l1_ = UNQUOTE(l111ll_l1_)
				title = UNQUOTE(title)
				addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᆂ"),menu_name+title,l111ll_l1_,202)
	return
def PLAY(url):
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆃ"),l1l1l1_l1_ (u"ࠫࡊࡓࡁࡅࠢ࠴࠵࠶࠭ᆄ"))
	l11l1_l1_ = []
	parts = url.split(l1l1l1_l1_ (u"ࠬ࠵ࠧᆅ"))
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᆆ"),l1l1l1_l1_ (u"ࠧࠨᆇ"),url,l1l1l1_l1_ (u"ࠨࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᆈ"))
	#url = UNQUOTE(QUOTE(url))
	hostname = l1l11l_l1_
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ᆉ"),url,l1l1l1_l1_ (u"ࠪࠫᆊ"),headers,True,True,l1l1l1_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᆋ"))
	html = response.content#.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᆌ"))
	id = re.findall(l1l1l1_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧᆍ"),html,re.DOTALL)
	if not id: id = re.findall(l1l1l1_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨᆎ"),html,re.DOTALL)
	if not id: id = re.findall(l1l1l1_l1_ (u"ࠨࡲࡲࡷࡹ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᆏ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪᆐ"),l1l1l1_l1_ (u"ࠪࠫᆑ"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆒ"),l1l1l1_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩᆓ"))
	#LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᆔ"),l1l1l1_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠶࠷࠱ࠨᆕ"))
	if l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩᆖ") in html:
		#parts = url.split(l1l1l1_l1_ (u"ࠩ࠲ࠫᆗ"))
		url2 = url.replace(parts[3],l1l1l1_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩᆘ"))
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨᆙ"),url2,l1l1l1_l1_ (u"ࠬ࠭ᆚ"),headers,True,True,l1l1l1_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪᆛ"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᆜ"))
		l111lllll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᆝ"),l1l11l11_l1_,re.DOTALL)
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪᆞ"),l1l11l11_l1_,re.DOTALL)
		l11l11111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᆟ"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬᆠ"),l1l11l11_l1_)
		l111lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᆡ"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᆢ"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
		items = l111lllll_l1_+l1ll1ll_l1_+l11l11111_l1_+l111lll1l_l1_+l111lll11_l1_+l11l1l1l1_l1_
		#LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᆣ"),l1l1l1_l1_ (u"ࠨࡇࡐࡅࡉࠦࡓࡕࡃࡕࡘ࡚ࠥࡉࡎࡋࡑࡋࠥ࠺࠴࠵ࠩᆤ"))
		if not items:
			items = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᆥ"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l1l1_l1_ (u"ࠪ࠲ࡵࡴࡧࠨᆦ") in server: continue
			if l1l1l1_l1_ (u"ࠫ࠳ࡰࡰࡨࠩᆧ") in server: continue
			if l1l1l1_l1_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬᆨ") in server: continue
			l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧᆩ"),title,re.DOTALL)
			if l11ll111_l1_:
				l11ll111_l1_ = l11ll111_l1_[0]
				if l11ll111_l1_ in title: title = title.replace(l11ll111_l1_+l1l1l1_l1_ (u"ࠧࡱࠩᆪ"),l1l1l1_l1_ (u"ࠨࠩᆫ")).replace(l11ll111_l1_,l1l1l1_l1_ (u"ࠩࠪᆬ")).strip(l1l1l1_l1_ (u"ࠪࠤࠬᆭ"))
				l11ll111_l1_ = l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩᆮ")+l11ll111_l1_
			else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠬ࠭ᆯ")
			#LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᆰ"),l1l1l1_l1_ (u"ࠧ࡜ࠩᆱ")+str(id)+l1l1l1_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭ᆲ")+str(hostname)+l1l1l1_l1_ (u"ࠩࡠࠤࠥࡡࠧᆳ")+str(title)+l1l1l1_l1_ (u"ࠪࡡ࡛ࠥࠦࠨᆴ")+str(l11ll111_l1_)+l1l1l1_l1_ (u"ࠫࡢ࠭ᆵ"))
			if server.isdigit():
				l111ll_l1_ = hostname+l1l1l1_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨᆶ")+id+l1l1l1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪᆷ")+server+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᆸ")+title+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᆹ")+l11ll111_l1_
			else:
				if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᆺ") not in server: server = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩᆻ")+server
				l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬᆼ"),title,re.DOTALL)
				if l11ll111_l1_: l11ll111_l1_ = l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪᆽ")+l11ll111_l1_[0]
				else: l11ll111_l1_ = l1l1l1_l1_ (u"࠭ࠧᆾ")
				l111ll_l1_ = server+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨᆿ")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	#LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᇀ"),l1l1l1_l1_ (u"ࠩ࡞ࠫᇁ")+l11ll111_l1_+l1l1l1_l1_ (u"ࠪࡡࠥࠦࠠࠡ࡝ࠪᇂ")+title+l1l1l1_l1_ (u"ࠫࡢ࠭ᇃ"))
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᇄ"), l11l1_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᇅ"),l1l1l1_l1_ (u"ࠧࠨᇆ"),l1l1l1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠠ࠲ࠩᇇ"),	str(len(items)))
	if l1l1l1_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡒࡴࡽࠧᇈ") in html:
		headers2 = { l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᇉ"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫᇊ") }
		url2 = url+l1l1l1_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨᇋ")
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪᇌ"),url2,l1l1l1_l1_ (u"ࠧࠨᇍ"),headers2,True,l1l1l1_l1_ (u"ࠨࠩᇎ"),l1l1l1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ᇏ"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᇐ"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬᇑ"),l1l1l1_l1_ (u"ࠬ࠭ᇒ"),url2,l1l11l11_l1_)
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᇓ"),l1l11l11_l1_,re.DOTALL)
		for block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩᇔ"),block,re.DOTALL)
			for l111ll_l1_,name,l11ll111_l1_ in items:
				l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᇕ")+name+l1l1l1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᇖ")+l1l1l1_l1_ (u"ࠪࡣࡤࡥ࡟ࠨᇗ")+l11ll111_l1_
				l11l1_l1_.append(l111ll_l1_)
	elif l1l1l1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨᇘ") in html:
		headers2 = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᇙ"):l1l1l1_l1_ (u"࠭ࠧᇚ") , l1l1l1_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪᇛ"):l1l1l1_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩᇜ") }
		url2 = hostname + l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬᇝ")+id
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᇞ"),url2,l1l1l1_l1_ (u"ࠫࠬᇟ"),headers2,True,True,l1l1l1_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩᇠ"))
		l1l11l11_l1_ = response.content#.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᇡ"))
		if l1l1l1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡸࡳࡹࠧᇢ") in l1l11l11_l1_:
			l11l11111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᇣ"),l1l11l11_l1_,re.DOTALL)
			for url3 in l11l11111_l1_:
				if l1l1l1_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩᇤ") not in url3 and l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᇥ") in url3:
					url3 = url3+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᇦ")
					l11l1_l1_.append(url3)
				elif l1l1l1_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬᇧ") in url3:
					l11ll111_l1_ = l1l1l1_l1_ (u"࠭ࠧᇨ")
					response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫᇩ"),url3,l1l1l1_l1_ (u"ࠨࠩᇪ"),headers,True,True,l1l1l1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭ᇫ"))
					l11l11l1l_l1_ = response.content#.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᇬ"))
					l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡂࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࠬ࠱࠲࠳࠭࠮ࠩᇭ"),l11l11l1l_l1_,re.DOTALL)
					for l11ll11l1_l1_ in l1l11l1_l1_:
						l11l11lll_l1_ = l1l1l1_l1_ (u"ࠬ࠭ᇮ")
						l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨᇯ"),l11ll11l1_l1_,re.DOTALL)
						for l11l1ll11_l1_ in l111lll1l_l1_:
							item = re.findall(l1l1l1_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨᇰ"),l11l1ll11_l1_,re.DOTALL)
							if item:
								l11ll111_l1_ = l1l1l1_l1_ (u"ࠨࡡࡢࡣࡤ࠭ᇱ")+item[0]
								break
						for l11l1ll11_l1_ in reversed(l111lll1l_l1_):
							item = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࡻࡡࡽࠫࠨᇲ"),l11l1ll11_l1_,re.DOTALL)
							if item:
								l11l11lll_l1_ = item[0]
								break
						l111lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᇳ"),l11ll11l1_l1_,re.DOTALL)
						for l11l1l11l_l1_ in l111lll11_l1_:
							l11l1l11l_l1_ = l11l1l11l_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᇴ")+l11l11lll_l1_+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᇵ")+l11ll111_l1_
							l11l1_l1_.append(l11l1l11l_l1_)
			#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᇶ"),l1l1l1_l1_ (u"ࠧࠨᇷ"),l1l1l1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵ࠬᇸ"),	str(len(l11l1_l1_))	)
		elif l1l1l1_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧᇹ") in l1l11l11_l1_:
			l1l11l11_l1_ = l1l11l11_l1_.replace(l1l1l1_l1_ (u"ࠪࡀ࡭࠼ࠠࠨᇺ"),l1l1l1_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨᇻ"))+l1l1l1_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ᇼ")
			l1l11l11_l1_ = l1l11l11_l1_.replace(l1l1l1_l1_ (u"࠭࠼ࡩ࠵ࠣࠫᇽ"),l1l1l1_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫᇾ"))+l1l1l1_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩᇿ")
			#LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩሀ"),l1l11l11_l1_)
			#open(l1l1l1_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪሁ"),l1l1l1_l1_ (u"ࠫࡼ࠭ሂ")).write(l1l11l11_l1_)
			l111llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ሃ"),l1l11l11_l1_,re.DOTALL)
			if l111llll1_l1_:
				for l11ll11l1_l1_ in l111llll1_l1_:
					if l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬሄ") not in l11ll11l1_l1_: continue
					#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨህ"),l1l1l1_l1_ (u"ࠨࠩሆ"),l1l1l1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࠶࠷࠱ࠨሇ"),	l11ll11l1_l1_	)
					l11l1ll1l_l1_ = l1l1l1_l1_ (u"ࠪࠫለ")
					l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸࡲ࡯ࡸ࠯ࡰࡳࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪሉ"),l11ll11l1_l1_,re.DOTALL)
					for l11l1ll11_l1_ in l111lll1l_l1_:
						item = re.findall(l1l1l1_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ሊ"),l11l1ll11_l1_,re.DOTALL)
						if item:
							l11l1ll1l_l1_ = l1l1l1_l1_ (u"࠭࡟ࡠࡡࡢࠫላ")+item[0]
							break
					l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ሌ"),l11ll11l1_l1_,re.DOTALL)
					if l111lll1l_l1_:
						for l11l11lll_l1_,l11l1l111_l1_ in l111lll1l_l1_:
							l11l1l111_l1_ = l11l1l111_l1_+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩል")+l11l11lll_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ሎ")+l11l1ll1l_l1_
							l11l1_l1_.append(l11l1l111_l1_)
					else:
						l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪሏ"),l11ll11l1_l1_,re.DOTALL)
						for l11l1l111_l1_,l11l11lll_l1_ in l111lll1l_l1_:
							l11l1l111_l1_ = l11l1l111_l1_.strip(l1l1l1_l1_ (u"ࠫࠥ࠭ሐ"))+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ሑ")+l11l11lll_l1_+l1l1l1_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪሒ")+l11l1ll1l_l1_
							l11l1_l1_.append(l11l1l111_l1_)
			else:
				l111lll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫࡠࡼ࠱ࠩ࠽ࠩሓ"),l1l11l11_l1_,re.DOTALL)
				for l11l1l111_l1_,l11l11lll_l1_ in l111lll1l_l1_:
					l11l1l111_l1_ = l11l1l111_l1_.strip(l1l1l1_l1_ (u"ࠨࠢࠪሔ"))+l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪሕ")+l11l11lll_l1_+l1l1l1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧሖ")
					l11l1_l1_.append(l11l1l111_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩሗ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫመ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧሙ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨሚ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪማ"),l1l1l1_l1_ (u"ࠩ࠮ࠫሜ"))
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧም"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩሞ"),l1l1l1_l1_ (u"ࠬ࠭ሟ"),headers,True,l1l1l1_l1_ (u"࠭ࠧሠ"),l1l1l1_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ሡ"))
	html = response.content#.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ሢ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧሣ"),html,re.DOTALL)
	if l111l_l1_ and l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ሤ"),block,re.DOTALL)
		l11l1lll1_l1_,l11l11ll1_l1_ = [],[]
		for category,title in items:
			#if title in [l1l1l1_l1_ (u"ࠫึ๐วืหࠣ์๋ࠥีศำ฼๋ࠬሥ")]: continue
			l11l1lll1_l1_.append(category)
			l11l11ll1_l1_.append(title)
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬሦ"), l11l11ll1_l1_)
		if selection == -1 : return
		category = l11l1lll1_l1_[selection]
	else: category = l1l1l1_l1_ (u"࠭ࠧሧ")
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫረ")+search+l1l1l1_l1_ (u"ࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬሩ")+category+l1l1l1_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾࠳ࠪሪ")
	l11l11_l1_(url)
	return
def l1111l1_l1_(url,filter):
	#filter = filter.replace(l1l1l1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬራ"),l1l1l1_l1_ (u"ࠫࠬሬ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ር"),l1l1l1_l1_ (u"࠭ࠧሮ"),filter,url)
	# for l11l111l1_l1_ filter:		l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠧࡄࡣࡷࡩ࡬ࡵࡲࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪሯ"),l1l1l1_l1_ (u"ࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧሰ"),l1l1l1_l1_ (u"ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩሱ"),l1l1l1_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬሲ")]
	l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ሳ"),l1l1l1_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫሴ"),l1l1l1_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬስ"),l1l1l1_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨሶ")]
	if l1l1l1_l1_ (u"ࠨࡁࠪሷ") in url: url = url.split(l1l1l1_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ሸ"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧሹ"),1)
	if filter==l1l1l1_l1_ (u"ࠫࠬሺ"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠬ࠭ሻ"),l1l1l1_l1_ (u"࠭ࠧሼ")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫሽ"))
	if type==l1l1l1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬሾ"):
		if l1l1lll1_l1_[0]+l1l1l1_l1_ (u"ࠩࡀࠫሿ") not in l1l1ll11_l1_: category = l1l1lll1_l1_[0]
		for i in range(len(l1l1lll1_l1_[0:-1])):
			if l1l1lll1_l1_[i]+l1l1l1_l1_ (u"ࠪࡁࠬቀ") in l1l1ll11_l1_: category = l1l1lll1_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠫࠫ࠭ቁ")+category+l1l1l1_l1_ (u"ࠬࡃ࠰ࠨቂ")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"࠭ࠦࠨቃ")+category+l1l1l1_l1_ (u"ࠧ࠾࠲ࠪቄ")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠨࠨࠪቅ"))+l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭ቆ")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠪࠪࠬቇ"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧቈ"))
		url2 = url+l1l1l1_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩ቉")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧቊ"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩቋ"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠨࠩቌ"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬቍ"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠪࠫ቎"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨ቏")+l1l1l1ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬቐ"),menu_name+l1l1l1_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩቑ"),url2,201)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧቒ"),menu_name+l1l1l1_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨቓ")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨቔ"),url2,201)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨቕ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫቖ"),l1l1l1_l1_ (u"ࠬ࠭቗"),9999)
	html = OPENURL_CACHED(l11l11l_l1_,url+l1l1l1_l1_ (u"࠭࠯ࡢ࡮ࡽࠫቘ"),l1l1l1_l1_ (u"ࠧࠨ቙"),headers,l1l1l1_l1_ (u"ࠨࠩቚ"),l1l1l1_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧቛ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠨ࠯ࠬࡂ࠭ࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤࠨቜ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	# for l11l111l1_l1_ filter:		l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪቝ"),block,re.DOTALL)
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡩࡧࡴࡢ࠯ࡩࡳࡷ࡚ࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽ࡪ࠵ࠫ቞"),block,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ቟"),l1l1l1_l1_ (u"ࠧࠨበ"),l1l1l1_l1_ (u"ࠨࠩቡ"),str(l11111l_l1_))
	dict = {}
	for name,l1llllll_l1_,block in l11111l_l1_:
		#name = name.replace(l1l1l1_l1_ (u"ࠩ࠰࠱ࠬቢ"),l1l1l1_l1_ (u"ࠪࠫባ"))
		name = name.replace(l1l1l1_l1_ (u"ࠫฬิส๋ษิࠤࠬቤ"),l1l1l1_l1_ (u"ࠬ࠭ብ"))
		name = name.replace(l1l1l1_l1_ (u"࠭ำ็หࠣห้หๆหษฯࠫቦ"),l1l1l1_l1_ (u"ࠧศๆึ๊ฮ࠭ቧ"))
		items = re.findall(l1l1l1_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩቨ"),block,re.DOTALL)
		if l1l1l1_l1_ (u"ࠩࡀࠫቩ") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧቪ"):
			if category!=l1llllll_l1_: continue
			elif len(items)<=1:
				if l1llllll_l1_==l1l1lll1_l1_[-1]: l11l11_l1_(url2)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫቫ")+l1ll1111_l1_)
				return
			else:
				if l1llllll_l1_==l1l1lll1_l1_[-1]: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬቬ"),menu_name+l1l1l1_l1_ (u"࠭วๅฮ่๎฾ࠦࠧቭ"),url2,201)
				else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧቮ"),menu_name+l1l1l1_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩቯ"),url2,205,l1l1l1_l1_ (u"ࠩࠪተ"),l1l1l1_l1_ (u"ࠪࠫቱ"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬቲ"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠧታ")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽࠱ࠩቴ")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠩት")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿࠳ࠫቶ")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭ቷ")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪቸ"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ቹ")+name,url2,204,l1l1l1_l1_ (u"ࠬ࠭ቺ"),l1l1l1_l1_ (u"࠭ࠧቻ"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩቼ"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			option = option.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫች"),l1l1l1_l1_ (u"ࠩࠪቾ"))
			if option in l1l1ll_l1_: continue
			#if option==l1l1l1_l1_ (u"ࠪห้้ไࠨቿ"): continue
			#option = l1l1l1_l1_ (u"ࠫࡠ࠭ኀ")+option+l1l1l1_l1_ (u"ࠬࡣࠧኁ")
			#if l1l1l1_l1_ (u"࠭วๅๅ็ࠫኂ") in option: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨኃ"),l1l1l1_l1_ (u"ࠨࠩኄ"),l1l1l1_l1_ (u"ࠩࠪኅ"),l1l1l1_l1_ (u"ࠪ࡟ࠬኆ")+str(option)+l1l1l1_l1_ (u"ࠫࡢ࠭ኇ"))
			#if l1l1l1_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫኈ") not in value: value = option
			#else: value = re.findall(l1l1l1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ኉"),value,re.DOTALL)[0]
			dict[l1llllll_l1_][value] = option
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠧࠧࠩኊ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿ࠪኋ")+option
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠩࠩࠫኌ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡁࠬኍ")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࠨ኎")+l1ll1ll1_l1_
			title = option+l1l1l1_l1_ (u"ࠬࠦ࠺ࠨ኏")#+dict[l1llllll_l1_][l1l1l1_l1_ (u"࠭࠰ࠨነ")]
			title = option+l1l1l1_l1_ (u"ࠧࠡ࠼ࠪኑ")+name
			if type==l1l1l1_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩኒ"): addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩና"),menu_name+title,url,204,l1l1l1_l1_ (u"ࠪࠫኔ"),l1l1l1_l1_ (u"ࠫࠬን"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧኖ"))
			elif type==l1l1l1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪኗ") and l1l1lll1_l1_[-2]+l1l1l1_l1_ (u"ࠧ࠾ࠩኘ") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫኙ"))
				url3 = url+l1l1l1_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ኚ")+l1l1l111_l1_
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪኛ"),menu_name+title,url3,201)
			else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫኜ"),menu_name+title,url,205,l1l1l1_l1_ (u"ࠬ࠭ኝ"),l1l1l1_l1_ (u"࠭ࠧኞ"),l1lllll1_l1_)
	return
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨኟ"),l1l1l1_l1_ (u"ࠨࠩአ"),filters,l1l1l1_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪኡ"))
	# mode==l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬኢ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧኣ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠬࡧ࡬࡭ࠩኤ")					all filters (l1l11ll1_l1_ l1ll11ll_l1_ filter)
	filters = filters.replace(l1l1l1_l1_ (u"࠭࠽ࠧࠩእ"),l1l1l1_l1_ (u"ࠧ࠾࠲ࠩࠫኦ"))
	filters = filters.strip(l1l1l1_l1_ (u"ࠨࠨࠪኧ"))
	l1l1ll1l_l1_ = {}
	if l1l1l1_l1_ (u"ࠩࡀࠫከ") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠪࠪࠬኩ"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠫࡂ࠭ኪ"))
			l1l1ll1l_l1_[var] = value
	l1llll1l_l1_ = l1l1l1_l1_ (u"ࠬ࠭ካ")
	# for l11l111l1_l1_ filter:		l1lll1ll_l1_ = [l1l1l1_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩኬ"),l1l1l1_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ክ"),l1l1l1_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨኮ"),l1l1l1_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫኯ")]
	l1lll1ll_l1_ = [l1l1l1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬኰ"),l1l1l1_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ኱"),l1l1l1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫኲ"),l1l1l1_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧኳ")]
	for key in l1lll1ll_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠧ࠱ࠩኴ")
		if l1l1l1_l1_ (u"ࠨࠧࠪኵ") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ኶") and value!=l1l1l1_l1_ (u"ࠪ࠴ࠬ኷"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠫࠥ࠱ࠠࠨኸ")+value
		elif mode==l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨኹ") and value!=l1l1l1_l1_ (u"࠭࠰ࠨኺ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠧࠧࠩኻ")+key+l1l1l1_l1_ (u"ࠨ࠿ࠪኼ")+value
		elif mode==l1l1l1_l1_ (u"ࠩࡤࡰࡱ࠭ኽ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠪࠪࠬኾ")+key+l1l1l1_l1_ (u"ࠫࡂ࠭኿")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠬࠦࠫࠡࠩዀ"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"࠭ࠦࠨ዁"))
	l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"ࠧ࠾࠲ࠪዂ"),l1l1l1_l1_ (u"ࠨ࠿ࠪዃ"))
	l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪዄ"),l1l1l1_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫዅ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ዆"),l1l1l1_l1_ (u"ࠬ࠭዇"),filters,l1l1l1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧወ"))
	return l1llll1l_l1_
l1l1l1_l1_ (u"ࠢࠣࠤࠍࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠎ࠷ࡳࡵࠢࡰࡩࡹ࡮࡯ࡥࠋࠌࠬࡺࡹࡥࡥࠢࡱࡳࡼࠦࡩ࡯ࠢࡺࡩࡧࡹࡩࡵࡧࠬࠎࡦࡪࡤࡪࡰࡪࠤ࡫࡯࡬ࡵࡧࡵࠤࡹࡵࠠࡴࡧࡤࡶࡨ࡮ࠊࡑࡑࡖࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠎࠎࡪࡡࡵࡣ࠽ࠍࡠ࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪ࠰ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡀࠉࡄࡱࡲ࡯࡮࡫࡛ࠠࠬࠢࡖࡊࡌ࠭ࡕࡑࡎࡉࡓࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠶ࡳࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠍࠎ࠮ࡵࡴࡧࡧࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡲࡷࡤࡰ࡮ࡺࡹ࠾࡙ࡈࡆ࠲ࡊࡌࠧࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠽࠳࠲࠵࠴ࠏࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠷ࡷࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲ࠰࠴࠳࠵࠾ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠺ࡋࠦ࠴࠳ࡆࡱࡻࡒࡢࡻࠍࠦࠧࠨዉ")
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ卵")
menu_name = l1l1l1_l1_ (u"ࠩࡢࡗࡍࡔ࡟ࠨ卶")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠪๆ๋๎วหࠢไฺฬฬ๊สࠩ卷"),l1l1l1_l1_ (u"ࠫๆอัิๅ๋ࠫ卸"),l1l1l1_l1_ (u"࡙ࠬࡨࡰࡹࠣࡱࡴࡸࡥࠨ卹")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l11l11_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l11l1ll_l1_(url,text)
	elif mode==584: results = l1ll11_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ卺"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨ卻"),l1l1l1_l1_ (u"ࠨࠩ卼"),l1l1l1_l1_ (u"ࠩࠪ卽"),l1l1l1_l1_ (u"ࠪࠫ卾"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ卿"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ厀"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭厁"),l1l1l1_l1_ (u"ࠧࠨ厂"),589,l1l1l1_l1_ (u"ࠨࠩ厃"),l1l1l1_l1_ (u"ࠩࠪ厄"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ厅"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ历"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ厇"),l1l1l1_l1_ (u"࠭ࠧ厈"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ厉"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ厊"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠩࠪ压"))
	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ厌"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ厍"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ厎")+menu_name+title,l111ll_l1_,584)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ厏"),url,l1l1l1_l1_ (u"ࠧࠨ厐"),l1l1l1_l1_ (u"ࠨࠩ厑"),l1l1l1_l1_ (u"ࠩࠪ厒"),l1l1l1_l1_ (u"ࠪࠫ厓"),l1l1l1_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭厔"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ厕"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ厖"),l1l1l1_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭厗"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ厘"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠩࠪ厙"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ厚"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ厛"),l1l1l1_l1_ (u"ࠬ࠭厜"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ厝"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠧ࠻ࠢࠪ厞")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ原"),menu_name+title,l111ll_l1_,581)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭厠"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ厡"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ厢"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ厣"),l1l1l1_l1_ (u"࠭ࠧ厤"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ厥"),menu_name+title,l111ll_l1_,581)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠨࠩ厦")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ厧"),l1l1l1_l1_ (u"ࠪࠫ厨"),request,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ厩"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ厪"),url,l1l1l1_l1_ (u"࠭ࠧ厫"),l1l1l1_l1_ (u"ࠧࠨ厬"),l1l1l1_l1_ (u"ࠨࠩ厭"),l1l1l1_l1_ (u"ࠩࠪ厮"),l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ厯"))
	html = response.content
	items = []
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ厰"),html,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬ厱"),html,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ厲"),html,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ厳"),html,re.DOTALL)
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	if not items: items = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ厴"),block,re.DOTALL)
	if not items: items = re.findall(l1l1l1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ厵"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ู้ࠪอ็ะหࠪ厶"),l1l1l1_l1_ (u"ࠫๆ๐ไๆࠩ厷"),l1l1l1_l1_ (u"ࠬอฺ็์ฬࠫ厸"),l1l1l1_l1_ (u"࠭ใๅ์หࠫ厹"),l1l1l1_l1_ (u"ࠧศ฻็ห๋࠭厺"),l1l1l1_l1_ (u"ࠨ้าหๆ࠭去"),l1l1l1_l1_ (u"่ࠩฬฬืวสࠩ厼"),l1l1l1_l1_ (u"ࠪ฽ึ฼ࠧ厽"),l1l1l1_l1_ (u"๊ࠫํัอษ้ࠫ厾"),l1l1l1_l1_ (u"ࠬอไษ๊่ࠫ县"),l1l1l1_l1_ (u"࠭ๅิำะ๎ฮ࠭叀")]
	for img,l111ll_l1_,title in items:
		l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ叁"))
		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭参") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ參")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬ叄"))
		if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ叅") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ叆")+img.strip(l1l1l1_l1_ (u"࠭࠯ࠨ叇"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩ又"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ叉"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ及"),menu_name+title,l111ll_l1_,582,img)
		elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠪห้ำไใหࠪ友") in title:
			title = l1l1l1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ双") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ反"),menu_name+title,l111ll_l1_,583,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ収") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ叏"),menu_name+title,l111ll_l1_,581,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ叐"),menu_name+title,l111ll_l1_,583,img)
	if request not in [l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫ发"),l1l1l1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ叒")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ叓"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ叔"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"࠭ࠣࠨ叕"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩ取")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ受"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ变"),menu_name+l1l1l1_l1_ (u"ูࠪๆำษࠡࠩ叙")+title,l111ll_l1_,581)
		l1111ll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭叚"),html,re.DOTALL)
		if l1111ll11_l1_:
			l111ll_l1_ = l1111ll11_l1_[0]
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ叛"),menu_name+l1l1l1_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭叜"),l111ll_l1_,581)
	return
def l11l1ll_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ叝"),l1l1l1_l1_ (u"ࠨࠩ叞"),l1lll_l1_,url)
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪ叟"),l1l1l1_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪ叠")+url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ叡"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ叢"),url,l1l1l1_l1_ (u"࠭ࠧ口"),l1l1l1_l1_ (u"ࠧࠨ古"),l1l1l1_l1_ (u"ࠨࠩ句"),l1l1l1_l1_ (u"ࠩࠪ另"),l1l1l1_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭叧"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡳࡧࡶ࠮ࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭叨"),html,re.DOTALL)
	#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭叩"),str(l1lll_l1_))
	#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ只"),str(l1ll111_l1_))
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ叫"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠨࠥࠪ召"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ叭"),menu_name+title,url,583,l1l1l1_l1_ (u"ࠪࠫ叮"),l1l1l1_l1_ (u"ࠫࠬ可"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ台")+l1lll_l1_+l1l1l1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ叱"),html,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭史"),block,re.DOTALL)
		if items:
			for l111ll_l1_,title in items:
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࠪ右")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩ࠲ࠫ叴"))
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ叵"),menu_name+title,l111ll_l1_,582)
		else:
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ叶"),block,re.DOTALL)
			for l111ll_l1_,title,img in items:
				if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ号") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ司")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ叹"))
				addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ叺"),menu_name+title,l111ll_l1_,582)
	return
def PLAY(url):
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭叻"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ叼"),url,l1l1l1_l1_ (u"ࠫࠬ叽"),l1l1l1_l1_ (u"ࠬ࠭叾"),l1l1l1_l1_ (u"࠭ࠧ叿"),l1l1l1_l1_ (u"ࠧࠨ吀"),l1l1l1_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ吁"))
	html = response.content
	# l11111_l1_ page
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡔࡱࡧࡹࡦࡴ࡫ࡳࡱࡪࡥࡳࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ吂"),html,re.DOTALL)
	l111ll_l1_ = l111ll_l1_[0]
	if l111ll_l1_ and l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ吃") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ各")+l111ll_l1_
	#//l1ll1l1ll1l_l1_.l1l11lll1ll1_l1_.l1l11lll1l1l_l1_/l1l11lll1lll_l1_/?l1l11llll1l1_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l111ll_l1_.split(l1l1l1_l1_ (u"ࠬ࡮ࡡࡴࡪࡀࠫ吅"))[1]
	parts = hash.split(l1l1l1_l1_ (u"࠭࡟ࡠࠩ吆"))
	l1l11llll11l_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l1l1_l1_ (u"ࠧ࠾ࠩ吇"))
			if kodi_version>18.99: part = part.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭合"))
			l1l11llll11l_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l1l1_l1_ (u"ࠩࡁࠫ吉").join(l1l11llll11l_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	for l111ll_l1_ in l1ll_l1_:
		title,l111ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠪࠤࡂࡄࠠࠨ吊"))
		l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ吋")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭同")
		l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ名"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭后"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠨࠩ吏"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠩࠪ吐"): return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬ向"),l1l1l1_l1_ (u"ࠫ࠰࠭吒"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭吓")+search
	l11l11_l1_(url)
	return
# -*- coding: utf-8 -*-
from EXCLUDES import *

script_name = 'FAVORITES'

def MAIN(mode,favorite):
	if   mode==270: results = MENU(favorite)
	#elif mode==271: results = DELETE_FAVORITES(favorite)
	else: results = False
	return results

def FAVORITES_DISPATCHER(context):
	if not context: return
	if '_' in context: favoriteID,context2 = context.split('_',1)
	else: favoriteID,context2 = context,''
	if   context2=='UP1'	: MOVE_FAVORITES(favoriteID,True,1)
	elif context2=='DOWN1'	: MOVE_FAVORITES(favoriteID,False,1)
	elif context2=='UP4'	: MOVE_FAVORITES(favoriteID,True,4)
	elif context2=='DOWN4'	: MOVE_FAVORITES(favoriteID,False,4)
	elif context2=='ADD1'	: ADD_TO_FAVORITES(favoriteID)
	elif context2=='REMOVE1': REMOVE_FROM_FAVORITES(favoriteID)
	elif context2=='DELETELIST': DELETE_FAVORITES(favoriteID)
	return

def MENU(favoriteID):
	favoritesDICT = GET_ALL_FAVORITES()
	if favoriteID in list(favoritesDICT.keys()):
		#addMenuItem('folder','مسح هذه القائمة','',271,'','','',favoriteID)
		#addMenuItem('link','[COLOR FFC89008] ======= ======= [/COLOR]','',9999)
		try:
			menuLIST = favoritesDICT[favoriteID]
			for type,name,url,mode,image,page,text,context,infodict in menuLIST:
				addMenuItem(type,name,url,mode,image,page,text,context,infodict)
		except:
			favoritesDICT = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
			menuLIST = favoritesDICT[favoriteID]
			for type,name,url,mode,image,page,text,context,infodict in menuLIST:
				addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return

def ADD_TO_FAVORITES(favoriteID):
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	#name = RESTORE_PATH_NAME(name)
	menuItem = type,name,url,mode,image,page,text,'',infodict
	favoritesDICT = GET_ALL_FAVORITES()
	new_dict = {}
	for ID in list(favoritesDICT.keys()):
		if ID!=favoriteID: new_dict[ID] = favoritesDICT[ID]
		else:
			if name and name!='..':
				oldLIST = favoritesDICT[ID]
				if menuItem in oldLIST:
					index = oldLIST.index(menuItem)
					del oldLIST[index]
				newLIST = oldLIST+[menuItem]
				new_dict[ID] = newLIST
			else: new_dict[ID] = favoritesDICT[ID]
	if favoriteID not in list(new_dict.keys()): new_dict[favoriteID] = [menuItem]
	newFILE = str(new_dict)
	if kodi_version>18.99: newFILE = newFILE.encode('utf8')
	open(favoritesfile,'wb').write(newFILE)
	return

def REMOVE_FROM_FAVORITES(favoriteID):
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	#name = RESTORE_PATH_NAME(name)
	menuItem = type,name,url,mode,image,page,text,'',infodict
	favoritesDICT = GET_ALL_FAVORITES()
	if favoriteID in list(favoritesDICT.keys()) and menuItem in favoritesDICT[favoriteID]:
		favoritesDICT[favoriteID].remove(menuItem)
		if len(favoritesDICT[favoriteID])==0: del favoritesDICT[favoriteID]
		newFILE = str(favoritesDICT)
		if kodi_version>18.99: newFILE = newFILE.encode('utf8')
		open(favoritesfile,'wb').write(newFILE)
	return

def MOVE_FAVORITES(favoriteID,move_up,repeat):
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	#name = RESTORE_PATH_NAME(name)
	menuItem = type,name,url,mode,image,page,text,'',infodict
	favoritesDICT = GET_ALL_FAVORITES()
	if favoriteID in list(favoritesDICT.keys()):
		oldLIST = favoritesDICT[favoriteID]
		#WRITE_THIS(name+' +++++++++++ '+str(name)+' +++++++++++ '+str('')+' +++++++++++++++ '+str(oldLIST[0]))
		if menuItem not in oldLIST: return
		size = len(oldLIST)
		for i in range(0,repeat):
			old_index = oldLIST.index(menuItem)
			if move_up: new_index = old_index-1
			else: new_index = old_index+1
			if new_index>=size: new_index = new_index-size
			if new_index<0: new_index = new_index+size
			oldLIST.insert(new_index, oldLIST.pop(old_index))
		favoritesDICT[favoriteID] = oldLIST
		newFILE = str(favoritesDICT)
		if kodi_version>18.99: newFILE = newFILE.encode('utf8')
		open(favoritesfile,'wb').write(newFILE)
	return

def DELETE_FAVORITES(favoriteID):
	yes = DIALOG_YESNO('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+favoriteID+' ؟!')
	if yes!=1: return
	favoritesDICT = GET_ALL_FAVORITES()
	if favoriteID in list(favoritesDICT.keys()):
		del favoritesDICT[favoriteID]
		newFILE = str(favoritesDICT)
		if kodi_version>18.99: newFILE = newFILE.encode('utf8')
		open(favoritesfile,'wb').write(newFILE)
		DIALOG_OK('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+favoriteID)
	return

def GET_ALL_FAVORITES():
	favoritesDICT = {}
	if os.path.exists(favoritesfile):
		oldFILE = open(favoritesfile,'rb').read()
		if kodi_version>18.99: oldFILE = oldFILE.decode('utf8')
		favoritesDICT = EVAL('dict',oldFILE)
	return favoritesDICT

def GET_FAVORITES_CONTEXT_MENU(favoritesDICT,menuItem,kodipath):
	type,name,url,mode,image,page,text,context,infodict = menuItem
	if not mode: type,mode = 'folder','260'
	contextMenu,favoriteID = [],''
	if 'context=' in addon_path:
		tmp = re.findall('context=(\d+)',addon_path,re.DOTALL)
		if tmp: favoriteID = str(tmp[0])
	if mode=='270':
		favoriteID = context
		if favoriteID in list(favoritesDICT.keys()):
			contextMenu.append(('مسح قائمة مفضلة '+favoriteID,'RunPlugin('+kodipath+'&context='+favoriteID+'_DELETELIST'+')'))
	else:
		if favoriteID in list(favoritesDICT.keys()):
			count = len(favoritesDICT[favoriteID])
			if count>1: contextMenu.append(('تحريك 1 للأعلى','RunPlugin('+kodipath+'&context='+favoriteID+'_UP1)'))
			if count>4: contextMenu.append(('تحريك 4 للأعلى','RunPlugin('+kodipath+'&context='+favoriteID+'_UP4)'))
			if count>1: contextMenu.append(('تحريك 1 للأسفل','RunPlugin('+kodipath+'&context='+favoriteID+'_DOWN1)'))
			if count>4: contextMenu.append(('تحريك 4 للأسفل','RunPlugin('+kodipath+'&context='+favoriteID+'_DOWN4)'))
		for favoriteID in ['1','2','3','4','5']:
			if favoriteID in list(favoritesDICT.keys()) and menuItem in favoritesDICT[favoriteID]:
				contextMenu.append(('مسح من مفضلة '+favoriteID,'RunPlugin('+kodipath+'&context='+favoriteID+'_REMOVE1)'))
			else: contextMenu.append(('إضافة إلى مفضلة '+favoriteID,'RunPlugin('+kodipath+'&context='+favoriteID+'_ADD1)'))
	contextMenuNEW = []
	for i1,i2 in contextMenu:
		i1 = '[COLOR FFFFFF00]'+i1+'[/COLOR]'
		contextMenuNEW.append((i1,i2,))
	return contextMenuNEW

"""
def FIX_OLD_FAVORITE_ITEMS():
	newDICT = {}
	favoritesDICT = GET_ALL_FAVORITES()
	for favoriteID in list(favoritesDICT.keys()):
		newDICT[favoriteID] = []
		menuLIST = favoritesDICT[favoriteID]
		for type,name,url,mode,image,page,text,context,infodict in menuLIST:
			#name = RESTORE_PATH_NAME(name)
			menuItem = type,name,url,mode,image,page,text,'',infodict
			newDICT[favoriteID].append(menuItem)
	newFILE = str(newDICT)
	if kodi_version>18.99: newFILE = newFILE.encode('utf8')
	open(favoritesfile,'wb').write(newFILE)
	return
"""







# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
#
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧ䳰")
def MAIN(mode,text=l1l1l1_l1_ (u"࠭ࠧ䳱")):
	if   mode==  0: l1l1lll111ll_l1_(text)
	elif mode==  2: l1ll111l11ll_l1_(text)
	elif mode==  3: l1ll111ll1ll_l1_()
	elif mode==  4: l1ll11ll11l1_l1_(text)
	elif mode==  5: l1l1ll1lll1l_l1_()
	elif mode==  6: l1ll11l1ll11_l1_()
	elif mode==  7: l1ll11111l11_l1_()
	elif mode==  8: l1l1ll1l1l1l_l1_()
	elif mode==  9: l1l1ll1l1lll_l1_()
	elif mode==150: l1ll11l111ll_l1_()
	elif mode==151: l1l1l1111l1l_l1_()
	elif mode==152: l1l1lllllll1_l1_()
	elif mode==153: l1ll1l1llll1_l1_()
	elif mode==154: l1ll11lll1ll_l1_()
	elif mode==155: l1l1lll1l11l_l1_()
	elif mode==156: l1l1l11111l1_l1_()
	elif mode==157: l1ll11l1ll1l_l1_()
	elif mode==158: l1ll11111111_l1_()
	elif mode==159: l1ll111l1ll1_l1_(True)
	elif mode==170: l1l1ll1111l1_l1_()
	elif mode==171: l1ll1111llll_l1_()
	elif mode==172: l1ll1l1l1l1l_l1_()
	elif mode==173: l1ll1111ll11_l1_(l1l1l1_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ䳲"),True)
	elif mode==174: l1ll1111ll11_l1_(l1l1l1_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ䳳"),True)
	elif mode==175: l1l1llll11l1_l1_()
	elif mode==176: l1l1l1ll1l1l_l1_()
	elif mode==177: l1ll11ll1l1l_l1_(l1l1l1_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭䳴"))
	elif mode==178: l1ll11ll1l1l_l1_(l1l1l1_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ䳵"))
	elif mode==179: l1ll11ll1l1l_l1_(l1l1l1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ䳶"))
	elif mode==190: l1l1lll1111l_l1_()
	elif mode==191: l1l1l1l11l11_l1_()
	elif mode==192: l1l1l1ll1ll1_l1_()
	elif mode==193: l1ll111l111l_l1_()
	elif mode==194: l1l1l1ll1111_l1_()
	elif mode==195: l1l1ll11l111_l1_()
	elif mode==196: l1l1ll1lll11_l1_()
	elif mode==197: l1l1ll11lll1_l1_()
	elif mode==198: l1ll1111ll1l_l1_()
	elif mode==199: l1l1l1l11111_l1_()
	elif mode==340: l1l1l11lll11_l1_(text)
	elif mode==341: l1ll11ll1lll_l1_()
	elif mode==342: l1l1lll1ll1l_l1_()
	elif mode==343: l1l1ll11llll_l1_()
	elif mode==344: l1ll11lll11l_l1_()
	elif mode==345: l1ll11111l1l_l1_()
	elif mode==346: l1l1lllll11l_l1_()
	elif mode==347: l1ll11l11ll1_l1_(True)
	elif mode==348: l1ll111l1111_l1_()
	elif mode==349: l1ll11l11l11_l1_(l1ll111111l_l1_)
	elif mode==500: l1l1l1l11lll_l1_()
	elif mode==501: l1l1l11l11l1_l1_()
	elif mode==502: l1ll1111l1ll_l1_(l1l1l1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ䳷"),True)
	elif mode==503: l1ll11l11l11_l1_(l1l1l1lllll_l1_)
	elif mode==504: l1ll11l11l11_l1_(favoritesfile)
	elif mode==505: l1l1llll1111_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1ll11ll1l11_l1_(text,l1l1l1_l1_ (u"࠭ࠧ䳸"),True)
	elif mode==508: l1ll1111lll1_l1_()
	return
def l1ll11ll1l11_l1_(addon_id,function,showDialogs):
	conn = sqlite3.connect(l1ll11l111l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1l1l1lll11l_l1_ = l1l1l1_l1_ (u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪ䳹")
	else: l1l1l1lll11l_l1_ = l1l1l1_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧ䳺")
	cc.execute(l1l1l1_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠪ䳻")+l1l1l1lll11l_l1_+l1l1l1_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ䳼")+addon_id+l1l1l1_l1_ (u"ࠫࠧࠦ࠻ࠨ䳽"))
	rows = cc.fetchall()
	if rows and function in [l1l1l1_l1_ (u"ࠬ࠭䳾"),l1l1l1_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭䳿")]:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࠨ䴀"),l1l1l1_l1_ (u"ࠨࠩ䴁"),l1l1l1_l1_ (u"ࠩࠪ䴂"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䴃"),l1l1l1_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ䴄")+addon_id+l1l1l1_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠฦ์ๅหๆํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭䴅"))
		if yes!=1: return
		cc.execute(l1l1l1_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬ䴆")+l1l1l1lll11l_l1_+l1l1l1_l1_ (u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ䴇")+addon_id+l1l1l1_l1_ (u"ࠨࠤࠣ࠿ࠬ䴈"))
	elif function in [l1l1l1_l1_ (u"ࠩࠪ䴉"),l1l1l1_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࠫ䴊")]:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࠬ䴋"),l1l1l1_l1_ (u"ࠬ࠭䴌"),l1l1l1_l1_ (u"࠭ࠧ䴍"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䴎"),l1l1l1_l1_ (u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬ䴏")+addon_id+l1l1l1_l1_ (u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭䴐"))
		if yes!=1: return
		if kodi_version<19: cc.execute(l1l1l1_l1_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪ䴑")+addon_id+l1l1l1_l1_ (u"ࠫࠧ࠯ࠠ࠼ࠩ䴒"))
		else: cc.execute(l1l1l1_l1_ (u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬ䴓")+addon_id+l1l1l1_l1_ (u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭䴔"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ䴕"))
	time.sleep(1)
	if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䴖"),l1l1l1_l1_ (u"ࠩࠪ䴗"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䴘"),l1l1l1_l1_ (u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨ䴙"))
	if function in [l1l1l1_l1_ (u"ࠬ࠭䴚"),l1l1l1_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭䴛")]: l1ll111l1ll1_l1_(showDialogs)
	return
def l1l1llll1111_l1_():
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ䴜"),l1l1l1_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ䴝"))
	l1ll11l1l111_l1_ = l1ll11ll1ll1_l1_()
	l1l1lll1111_l1_ = l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ䴞")
	l1ll1ll11111_l1_ = l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䴟")
	l1ll1l1lllll_l1_ = l1l1l1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬ䴠")
	for id,l1l1llllllll_l1_,l1l1lll1l1l1_l1_,answer,l1l1l111llll_l1_,reason in reversed(l1ll11l1l111_l1_):
		if id==l1l1l1_l1_ (u"ࠬ࠶ࠧ䴡"):
			l1l1ll1l1l11_l1_,l1ll1l111l1l_l1_ = answer.split(l1l1l1_l1_ (u"࠭࡜࡯࠽࠾ࠫ䴢"))
			continue
		if l1l1lll1111_l1_!=l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ䴣"): l1l1lll1111_l1_ += l1ll1l1lllll_l1_
		l1llll111l1_l1_ = l1l1l1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ䴤")+id+l1l1l1_l1_ (u"ࠩࠣ࠾ࠥ࠭䴥")+l1l1l1_l1_ (u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭䴦")+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䴧")+l1l1lll1l1l1_l1_
		l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠬࡢ࡮࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆฯ์ฬฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䴨")+answer
		l111ll11lll_l1_ = l1l1l1_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺวࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䴩")+l1l1l111llll_l1_
		l111ll1l111_l1_ = l1l1l1_l1_ (u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟สุ่ฮศࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䴪")+reason
		l1l1lll1111_l1_ += l1llll111l1_l1_+l1llll111ll_l1_+l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ䴫")+l1ll1ll11111_l1_+l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ䴬")+l111ll11lll_l1_+l111ll1l111_l1_+l1l1l1_l1_ (u"ࠪࡠࡳ࠭䴭")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ䴮"),l1ll1l111l1l_l1_,l1l1lll1111_l1_,l1l1l1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭䴯"))
	return
def l1ll11l11l11_l1_(file):
	if file==favoritesfile: l1l1llll1ll1_l1_ = l1l1l1_l1_ (u"࠭โ้ษษ้ࠥอไๆใู่ฮ࠭䴰")
	elif file==l1ll111111l_l1_: l1l1llll1ll1_l1_ = l1l1l1_l1_ (u"ࠧศๆิืฬฬไࠨ䴱")
	elif file==l1l1l1lllll_l1_: l1l1llll1ll1_l1_ = l1l1l1_l1_ (u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨ䴲")
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࠪ䴳"),l1l1l1_l1_ (u"ࠪࠫ䴴"),l1l1l1_l1_ (u"ࠫࠬ䴵"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䴶"),l1l1l1_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆล๊ࠥหีๅษะࠤࠬ䴷")+l1l1llll1ll1_l1_+l1l1l1_l1_ (u"ࠧࠡมࠤࠫ䴸"))
	if yes==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䴹"),l1l1l1_l1_ (u"ࠩࠪ䴺"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䴻"),l1l1l1_l1_ (u"ࠫฯ๋ࠠฦื็หาࠦๅๅใࠣࠫ䴼")+l1l1llll1ll1_l1_)
	return
def l1l1l11l11l1_l1_():
	if kodi_version<18:
		message = l1l1l1_l1_ (u"๊ࠬไฤีไࠤศ์สࠡฬึฮำีๅࠡวุำฬืࠠไ๊า๎่ࠥฯ๋็ࠣี็๋ࠠࠨ䴽")+str(kodi_version)+l1l1l1_l1_ (u"้࠭ࠠๆ๊ิฬࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠠ࠯๊ࠢิ์ࠦวๅ็ํึฮࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥอไโ์า๎ํํวหࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠠ࠯ࠢ็ษฺ๊วฮࠢสฺ่๊ใๅหࠣๆ๊ࠦศหฯา๎ะࠦศา่ส้ัࠦใ้ัํࠤส๊้ࠡวํࠤส฻ฯศำࠣี็๋็ࠡล฼่๎ࠦๅ็ࠢ࠴࠼࠳࠶ࠧ䴾")
		DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䴿"),l1l1l1_l1_ (u"ࠨࠩ䵀"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䵁"),message)
		return
	l1l1l11ll1ll_l1_ = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭䵂"))
	l1lll111l1l1_l1_ = l1l1lll1lll1_l1_([l1l1l1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ䵃")])
	l1l1ll11ll1_l1_,l1ll111lllll_l1_,l1l1l111ll1l_l1_,l1ll11l11111_l1_,l1ll111lll11_l1_,l1l1l11ll1l1_l1_,l1ll111llll1_l1_ = l1lll111l1l1_l1_[l1l1l1_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ䵄")]
	if l1l1ll11ll1_l1_ or l1l1l1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ䵅") not in str(l1l1l11ll1ll_l1_):
		DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䵆"),l1l1l1_l1_ (u"ࠨࠩ䵇"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䵈"),l1l1l1_l1_ (u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ䵉"))
		succeeded = l1ll1111l1ll_l1_(l1l1l1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ䵊"),True)
		if not succeeded: return
	l1ll111ll11l_l1_(True)
	return
	l1l1l1_l1_ (u"ࠧࠨࠢࠋࠋࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠭ࠩࠋࠋ࡬ࡪࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅ࠿ࡀࠫ࠺࠺࠴ࠨ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨࠌࠌࡩࡱ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠷࠸ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้฻่าࠩࠍࠍࡪࡲࡳࡦ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠๆฮ๊์้ฯࠧࠋࠋ࡬ࡪࠥࡩࡨࡰ࡫ࡦࡩࡂࡃ࠰࠻ࠋࠌࠧࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࠬ࠭ࠊࠊࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡸ࡬ࡩࡼࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡶࡨࡼࡹࡥࡦࡢࡥࡷࡳࡷࡿࠠ࠾ࠢࡶࡸࡷࠐࠉࠊࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧࡼࡩࡦࡹࠥࠤ࡜ࡎࡅࡓࡇࠣࡺ࡮࡫ࡷࡎࡱࡧࡩࠥࡃࠠ࠲࠻࠺࠵࠶࠽ࠠ࠼ࠩࠬࠎࠎࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࡺ࡮࡫ࡷ࡚ࠣࠢࡌࡊࡘࡅࠡࡸ࡬ࡩࡼࡓ࡯ࡥࡧࠣࡁࠥ࠼࠶࠱࠺࠳ࠤࡀ࠭ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࠎࡩ࡯࡯ࡰ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎ࡫࡬ࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠶ࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࠧ࠶࠶࠷ࠫࠎࠩࠠࠣࡎ࡬ࡷࡹࠦࡅ࡮ࡣࡧࠦࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠳࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠺࠻ࠧࠊࠥࠣࠦࡌࡧ࡬࡭ࡧࡵࡽࡤࡋ࡭ࡢࡦࠥࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠬ࠲ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠬࠎࠎࠨࠢࠣ䵋")
def l1ll111ll11l_l1_(showDialogs=True):
	l1l1l11ll1ll_l1_ = xbmc.executeJSONRPC(l1l1l1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ䵌"))
	if l1l1l1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭䵍") not in str(l1l1l11ll1ll_l1_):
		if showDialogs:
			DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䵎"),l1l1l1_l1_ (u"ࠩࠪ䵏"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䵐"),l1l1l1_l1_ (u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ䵑"))
		return
	l1ll11l1l1l1_l1_ = os.path.join(l1l1ll111111_l1_,l1l1l1_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ䵒"),l1l1l1_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ䵓"),l1l1l1_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ䵔"),l1l1l1_l1_ (u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭ࠩ䵕"))
	if not os.path.exists(l1ll11l1l1l1_l1_): return
	oldFILE = open(l1ll11l1l1l1_l1_,l1l1l1_l1_ (u"ࠩࡵࡦࠬ䵖")).read()
	if kodi_version>18.99: oldFILE = oldFILE.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䵗"))
	l1l1l111ll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ䵘"),oldFILE,re.DOTALL)
	l1l1l11llll1_l1_,l1ll1l1lll11_l1_ = l1l1l111ll11_l1_[0]
	l1ll11llllll_l1_ = l1l1l1_l1_ (u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭䵙")+l1l1l11llll1_l1_+l1l1l1_l1_ (u"࠭ࠬࠨ䵚")+l1ll1l1lll11_l1_+l1l1l1_l1_ (u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ䵛")
	if showDialogs:
		l1ll1l1111ll_l1_ = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭䵜"))
		if l1ll1l1111ll_l1_==l1l1l1_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ䵝"): l1ll11llll11_l1_ = l1l1l1_l1_ (u"ࠪๆํอฦๆࠢส่่ะวษหࠪ䵞")
		elif l1ll1l1111ll_l1_==l1l1l1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ䵟"): l1ll11llll11_l1_ = l1l1l1_l1_ (u"่่ࠬศศ่ࠤฬ๊ี้ำࠪ䵠")
		else: l1ll11llll11_l1_ = l1l1l1_l1_ (u"࠭โ้ษษ้ࠥษฮา๋ࠪ䵡")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䵢"),l1l1l1_l1_ (u"ࠨไ๋หห๋ࠠฤะิํࠬ䵣"),l1l1l1_l1_ (u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ䵤"),l1l1l1_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ䵥"),l1l1l1_l1_ (u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨ䵦")+l1ll11llll11_l1_,l1l1l1_l1_ (u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䵧"))
		if choice==1: l1l1llll1l11_l1_ = l1l1l1_l1_ (u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ䵨")
		elif choice==2: l1l1llll1l11_l1_ = l1l1l1_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭䵩")
		else: l1l1llll1l11_l1_ = l1l1l1_l1_ (u"ࠨࠩ䵪")
	else:
		l1ll1l1111ll_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ䵫"))
		if   l1ll1l1111ll_l1_==l1l1l1_l1_ (u"ࠪࠫ䵬"): choice = 0
		elif l1ll1l1111ll_l1_==l1l1l1_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ䵭"): choice = 1
		elif l1ll1l1111ll_l1_==l1l1l1_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ䵮"): choice = 2
		l1l1llll1l11_l1_ = l1ll1l1111ll_l1_
	if   choice==0: l1l1ll1lllll_l1_ = l1l1l1_l1_ (u"࠭࠵࠶࠮࠸࠸࠹࠲࠵࠶࠷ࠪ䵯")
	elif choice==1: l1l1ll1lllll_l1_ = l1l1l1_l1_ (u"ࠧ࠶࠶࠷࠰࠺࠻࠵࠭࠷࠸ࠫ䵰")
	elif choice==2: l1l1ll1lllll_l1_ = l1l1l1_l1_ (u"ࠨ࠷࠸࠹࠱࠻࠵࠭࠷࠷࠸ࠬ䵱")
	else: return
	settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ䵲"),l1l1llll1l11_l1_)
	l1l1l1l1ll1l_l1_ = l1l1l1_l1_ (u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫ䵳")+l1l1ll1lllll_l1_+l1l1l1_l1_ (u"ࠫ࠱࠭䵴")+l1ll1l1lll11_l1_+l1l1l1_l1_ (u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ䵵")
	newFILE = oldFILE.replace(l1ll11llllll_l1_,l1l1l1l1ll1l_l1_)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䵶"))
	open(l1ll11l1l1l1_l1_,l1l1l1_l1_ (u"ࠧࡸࡤࠪ䵷")).write(newFILE)
	LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䵸"),l1l1l1_l1_ (u"ࠩ࠱ࠤࠥࠦࡓ࡬࡫ࡱࠤࡉ࡫ࡦࡢࡷ࡯ࡸࠥ࡜ࡩࡦࡹࡶ࠾ࠥࡡࠠࠨ䵹")+l1l1ll1lllll_l1_+l1l1l1_l1_ (u"ࠪࠤࡢ࠭䵺"))
	#time.sleep(2)
	if showDialogs: xbmc.executebuiltin(l1l1l1_l1_ (u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪ䵻"))
	return
def l1l1l1l11lll_l1_():
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬ࠭䵼"),l1l1l1_l1_ (u"࠭ใๅษࠪ䵽"),l1l1l1_l1_ (u"ࠧ็฻่ࠫ䵾"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䵿"),l1l1l1_l1_ (u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ䶀"))
	if yes==1: l1ll11111l11_l1_()
	return
def l1l1ll1l1l1l_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䶁"),l1l1l1_l1_ (u"ࠫࠬ䶂"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䶃"),l1l1l1_l1_ (u"࠭็ัษࠣห้๋่ใ฻้ࠣ฿๊โࠡ็้ࠤฬ๊ๅึัิࠤํเ๊า่ࠢ฽ึ๎แࠡ็อ๎ࠥ๐ัอ฻่้ࠣ฿ๅๅࠩ䶄"))
	return
def l1ll111l1111_l1_():
	l1llll111l1_l1_ = l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䶅")
	l1llll111l1_l1_ += l1l1l1_l1_ (u"ࠨษ็้ํู่ࠡลา๊ฬํࠠโ์๊ࠤสำีศศํอู๊ࠥะัࠣหฺฺ้๊หࠣๅ๏ࠦวๅ฻ส่๊ࠦสๆࠢฯ้฾ํวࠡ็้ࠤัฺ๋๊ࠢส่๊฻วะำࠣห้๋ส้ใิอࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้่ฯ๋็ฬࠤํอไอัํำฮࠦวๅฯๆ์๊๐ษ๊ࠡส่฿๐ัࠡฯๆ์๊๐ษ๊่๊ࠡࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋ࠠฬ็ࠣฮ๊ࠦส้ฯํำ์อ้ࠠฯึหอࠦวๅ็฼ำ้ࠦอิสࠣื่อๆࠡั๋่ࠥอไฺษ็้๊ࠥำ็หࠣ࠶࠵࠸࠱๊๊ࠡ๎ࠥอไฦฯุหห๐ษࠡษ็วาีห๊ࠡส่ศฺๅๅࠢส่ฯ๐ࠠห็ࠣ฽๊๊็ศࠢไ๎ࠥอไิ่๋หฯࠦวๅ฻ืีฮࠦวๅ็สฺ๏ฯࠧ䶆")
	l1llll111l1_l1_ += l1l1l1_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䶇")
	l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䶈")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠫ์๎ฺࠠสสีฮูࠦ็ࠢหี๋อๅอࠢํ์ๆืࠠๆ฻็์๊อสࠡฯึหอ๐ษࠡๅฮ๎ึฯࠠห้่ࠤัฺ๋๊ࠢสู่๊ไๆ์้ࠤ๊ัไࠡล๋ๆฬะࠠศๆุ่ฬฯ้ࠠล๋ๆฬะࠠศๆๆืํ็้ࠠษ็าุ๎แ๊ࠡื็้ࠦวๅไ่ีࠥ๎ร้ไสฮࠥอไใ็ิࠤํษ๊ืษࠣ๎ํ็ัࠡำว๎ฮࠦวๅ้็ห้ࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤํษ๊ืษࠣๅ๏ํࠠหไ๋๎๊ࠦๅ๋ๆสำ๏่่ࠦฮิ๎ࠥ๎แ๋้ࠣว๏฼วࠡสะฯࠥ๎โาษฤอࠥอไใำล๊ࠥ๎รุ๋สࠤๆ๐็ࠡษึฮำอัส๋ࠢฮๆอฤๅ๋ࠢๅ๏ํࠠฤไ๋ห้ࠦๅ็ี๋ฬฮࠦไๅล่หู๊ࠦๅ์ࠣ์ศ๋่าࠢฦาึ๏ࠠห้่ࠤ่๊ࠠๆี็้ࠥ࠴ࠠศๆหี๋อๅอ่ࠢ็ฯ๎ศࠡส็฾ฮࠦฬศใสࠤุ้ัษฬࠣ์๏ูสฯั่ࠤ๋฾วๆ๋ࠢ๎๋ี่ำࠢอัฯࠦศ๋ศฬࠤํ๐ๆะ๊ีࠤ่อฬ๋ฬࠣ์๊ิีึࠢไๆ฼ࠦไฤฮ๊ึฮࠦวๅ๊ํ๊ิ๎าࠡ࠰ࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠥํ่ࠨ䶉")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䶊")
	message = l1l1l1_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ䶋")+l1llll111l1_l1_+l1l1l1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴ࡛ࡓࡖࡏࡡࠬ䶌")+l1llll111ll_l1_
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ䶍"),l1l1l1_l1_ (u"ࠩࠪ䶎"),message)
	return
def l1l1lllll11l_l1_():
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭䶏"),l1l1l1_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ䶐"))
	l1ll11l1l111_l1_ = l1ll11ll1ll1_l1_()
	if not l1ll11l1l111_l1_: return
	id,l1l1llllllll_l1_,l1l1lll1l1l1_l1_,answer,l1l1l111llll_l1_,reason = l1ll11l1l111_l1_[0]
	l1l1ll1l1l11_l1_,l1ll1l111l1l_l1_ = answer.split(l1l1l1_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ䶑"))
	l1llll111ll_l1_,l111ll11lll_l1_,l111ll1l111_l1_ = l1l1l111llll_l1_.split(l1l1l1_l1_ (u"࠭࡜࡯࠽࠾ࠫ䶒"))
	l1ll1l11ll11_l1_ = l1l1l11l1111_l1_
	stay = True
	while stay:
		l1l1ll1ll111_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠧࠨ䶓"),l1l1l1_l1_ (u"ࠨๆ็ห฾ะัศุࠪ䶔"),l1l1l1_l1_ (u"ࠩ็่ศ฽แศๆࠪ䶕"),l1l1l1_l1_ (u"ࠪาึ๎ฬࠨ䶖"),l1l1l1_l1_ (u"้ࠫห๊ใษไࠤฬ๊ลฺๆส๊ฬะࠠใ็ࠣฬู๊อࠡสิ๊ฬ๋ฬࠡ฻่หิࠦๅ็ࠢฯ๋ฬุใࠨ䶗"),l1llll111ll_l1_)
		if l1l1ll1ll111_l1_==0:
			yes = DIALOG_OK(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䶘"),l1l1l1_l1_ (u"ู้࠭ัฬࠫ䶙"),l1l1l1_l1_ (u"ࠧศๆส฽ฯืวืࠢ฼่๎ࠦๅษัฦࠤฬ๊ลฺๆส๊ฬะࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩ䶚"),l111ll11lll_l1_)
			#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䶛"),l1l1l1_l1_ (u"ࠩ฼์ิฯࠧ䶜"),l1l1l1_l1_ (u"ࠪฮํ฼๊ฮࠩ䶝"),l1l1l1_l1_ (u"ࠫฬ๊วฺฬิห฻ูࠦๅ๋้ࠣอีรࠡษ็ษ฾๊ว็ษอࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭䶞"),l111ll11lll_l1_)
			#if yes: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䶟"),l1l1l1_l1_ (u"ู้࠭ัฬࠫ䶠"),l1l1l1_l1_ (u"ࠧๆๆสั฽อสࠨ䶡"),l111ll1l111_l1_)
		if l1l1ll1ll111_l1_==1: DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䶢"),l1ll1l11ll11_l1_,l1ll1l11ll11_l1_,l1l1l1_l1_ (u"ࠩสืฯิฯๆ๊ࠢิฬࠦวๅิิࠤ้๊ฮา๊ฯࠤ๊์ࠠศๆึศฬ๊ࠠษั๋๊ࠥหฬศสฬࠤฬ๊ำลษ็ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ฤ๊࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳอำหะา้์ࠦไไ์ࠣฮ฾ืแࠡษ็ะํอศࠡษ็ูา๐อ࡝ࡰ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䶣")+l1ll1l11ll11_l1_+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䶤"))
		if l1l1ll1ll111_l1_==2: stay = False
	return
def l1ll11lll11l_l1_():
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䶥"),l1l1l1_l1_ (u"ࠬ࠭䶦"),l1l1l1_l1_ (u"࠭ࠧ䶧"),l1l1l1_l1_ (u"ࠧิฦส่ࠬ䶨"),l1l1l1_l1_ (u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ䶩"))
	if yes==1:
		succeeded = True
		if os.path.exists(l1l1l1l1l1l1_l1_):
			try: os.remove(l1l1l1l1l1l1_l1_)
			except: succeeded = False
		if succeeded: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䶪"),l1l1l1_l1_ (u"ࠪࠫ䶫"),l1l1l1_l1_ (u"ࠫࠬ䶬"),l1l1l1_l1_ (u"ࠬะๅࠡส้ะฬำࠠๆีะࠤํะีโ์ิࠤ๊๊แࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ䶭"))
		else: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䶮"),l1l1l1_l1_ (u"ࠧࠨ䶯"),l1l1l1_l1_ (u"ࠨࠩ䶰"),l1l1l1_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอ๋ࠥำฮ่่ࠢๆࠦวๅว฼ำฬีวหࠩ䶱"))
	return
def l1ll11111l1l_l1_():
	l1l1lll1111l_l1_()
	l1ll1l11llll_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ䶲"))
	message = {}
	message[l1l1l1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䶳")] = l1l1l1_l1_ (u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫ䶴")
	message[l1l1l1_l1_ (u"࠭ࡓࡕࡑࡓࠫ䶵")] = l1l1l1_l1_ (u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭䶶")
	message[l1l1l1_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ䶷")] = l1l1l1_l1_ (u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪ䶸")+str(LIMITED_CACHE/60)+l1l1l1_l1_ (u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧ䶹")
	l1l1ll11111l_l1_ = message[l1ll1l11llll_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠫࠬ䶺"),l1l1l1_l1_ (u"้ࠬวีࠢࠪ䶻")+str(LIMITED_CACHE/60)+l1l1l1_l1_ (u"࠭ࠠะไํๆฮ࠭䶼"),l1l1l1_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭䶽"),l1l1l1_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ䶾"),l1l1ll11111l_l1_,l1l1l1_l1_ (u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ใศึࠣห้ึใ๋ࠢส่ฯ๊โศศํࠤศ๋ࠠหำํำࠥห๊ใษไࠤฬ๊ใศึࠣฬฬ๊ใศ็็ࠤศ๋ࠠหำํำ้ࠥวีࠢ฼้ึํࠠใืํีࠥาฯศࠢยࠥࠬ䶿"))
	if choice==0: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ䷀")
	elif choice==1: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䷁")
	elif choice==2: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"࡙ࠬࡔࡐࡒࠪ䷂")
	else: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"࠭ࠧ䷃")
	if l1l1l1lllll1_l1_:
		settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ䷄"),l1l1l1lllll1_l1_)
		l1l1l1ll11l1_l1_ = message[l1l1l1lllll1_l1_]
		DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䷅"),l1l1l1_l1_ (u"ࠩࠪ䷆"),l1l1l1_l1_ (u"ࠪࠫ䷇"),l1l1l1ll11l1_l1_)
	return
def l1l1ll11llll_l1_():
	message = {}
	message[l1l1l1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䷈")] = l1l1l1_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪ䷉")
	message[l1l1l1_l1_ (u"࠭ࡁࡔࡍࠪ䷊")] = l1l1l1_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫ䷋")
	message[l1l1l1_l1_ (u"ࠨࡕࡗࡓࡕ࠭䷌")] = l1l1l1_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ䷍")
	l1ll11l1llll_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ䷎"))
	l1ll1l11llll_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ䷏"))
	l1l1ll11111l_l1_ = message[l1ll1l11llll_l1_]+l1ll11l1llll_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠬ࠭䷐"),l1l1l1_l1_ (u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ䷑"),l1l1l1_l1_ (u"ࠧหึ฽๎้ࠦสๅไสส๏࠭䷒"),l1l1l1_l1_ (u"ࠨวํๆฬ็ࠠไษ่่ࠬ䷓"),l1l1ll11111l_l1_,l1l1l1_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭䷔"))
	if choice==0: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠪࡅࡘࡑࠧ䷕")
	elif choice==1: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䷖")
	elif choice==2: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"࡙ࠬࡔࡐࡒࠪ䷗")
	if choice in [0,1]:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䷘"),l1l1l1_l1_ (u"ࠧิ์ิๅึࡀࠠࠨ䷙")+l1l1l1111111_l1_[1],l1l1l1_l1_ (u"ࠨีํีๆื࠺ࠡࠩ䷚")+l1l1l1111111_l1_[0],l1l1l1_l1_ (u"ࠩࠪ䷛"),l1l1l1_l1_ (u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไࠩ䷜"))
		if yes==1: l1ll111lll1l_l1_ = l1l1l1111111_l1_[0]
		else: l1ll111lll1l_l1_ = l1l1l1111111_l1_[1]
	elif choice==2: l1ll111lll1l_l1_ = l1l1l1_l1_ (u"ࠫࠬ䷝")
	else: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠬ࠭䷞")
	if l1l1l1lllll1_l1_:
		settings.setSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䷟"),l1l1l1lllll1_l1_)
		settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ䷠"),l1ll111lll1l_l1_)
		l1l1l1ll11l1_l1_ = message[l1l1l1lllll1_l1_]+l1ll111lll1l_l1_
		DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䷡"),l1l1l1_l1_ (u"ࠩࠪ䷢"),l1l1l1_l1_ (u"ࠪࠫ䷣"),l1l1l1ll11l1_l1_)
	return
def l1l1lll1ll1l_l1_():
	l1ll1l11llll_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭䷤"))
	message = {}
	message[l1l1l1_l1_ (u"ࠬࡇࡕࡕࡑࠪ䷥")] = l1l1l1_l1_ (u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧ䷦")
	message[l1l1l1_l1_ (u"ࠧࡂࡕࡎࠫ䷧")] = l1l1l1_l1_ (u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩ䷨")
	message[l1l1l1_l1_ (u"ࠩࡖࡘࡔࡖࠧ䷩")] = l1l1l1_l1_ (u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ䷪")
	l1l1ll11111l_l1_ = message[l1ll1l11llll_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠫࠬ䷫"),l1l1l1_l1_ (u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪ䷬"),l1l1l1_l1_ (u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ䷭"),l1l1l1_l1_ (u"ࠧฦ์ๅหๆࠦใศ็็ࠫ䷮"),l1l1ll11111l_l1_,l1l1l1_l1_ (u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫ䷯"))
	if choice==0: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠩࡄࡗࡐ࠭䷰")
	elif choice==1: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䷱")
	elif choice==2: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䷲")
	else: l1l1l1lllll1_l1_ = l1l1l1_l1_ (u"ࠬ࠭䷳")
	if l1l1l1lllll1_l1_:
		settings.setSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ䷴"),l1l1l1lllll1_l1_)
		l1l1l1ll11l1_l1_ = message[l1l1l1lllll1_l1_]
		DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䷵"),l1l1l1_l1_ (u"ࠨࠩ䷶"),l1l1l1_l1_ (u"ࠩࠪ䷷"),l1l1l1ll11l1_l1_)
	return
def l1ll1111lll1_l1_():
	l1l1l1l1l11l_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ䷸"))
	if l1l1l1l1l11l_l1_==l1l1l1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䷹"): header = l1l1l1_l1_ (u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ䷺")
	else: header = l1l1l1_l1_ (u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ䷻")
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࠨ䷼"),l1l1l1_l1_ (u"ࠨวํๆฬ็ࠧ䷽"),l1l1l1_l1_ (u"ࠩอๅ฾๐ไࠨ䷾"),header,l1l1l1_l1_ (u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮่ๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭䷿"))
	if yes==-1: return
	elif yes:
		settings.setSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ一"),l1l1l1_l1_ (u"ࠬ࠭丁"))
		DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ丂"),l1l1l1_l1_ (u"ࠧࠨ七"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ丄"),l1l1l1_l1_ (u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫ丅"))
	else:
		settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡰࡸࡷࡤࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ丆"),l1l1l1_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ万"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭丈"),l1l1l1_l1_ (u"࠭ࠧ三"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ上"),l1l1l1_l1_ (u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪ下"))
	return
def l1l1lll111ll_l1_(text):
	if text!=l1l1l1_l1_ (u"ࠩࠪ丌"):
		text = l1ll1l111l1_l1_(text)
		text = text.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ不")).encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ与"))
		l1ll1l11l1l_l1_ = 10103
		l1ll1l111ll_l1_ = xbmcgui.l1ll11ll1ll_l1_(l1ll1l11l1l_l1_)
		l1ll1l111ll_l1_.getControl(311).l1ll1l1l111_l1_(text)
		#l1l1llll11ll_l1_ = xbmcgui.WindowXMLDialog(l1l1l1_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡐ࡫ࡹࡣࡱࡤࡶࡩ࠸࠲࠯ࡺࡰࡰࠬ丏"), xbmcaddon.Addon().getAddonInfo(l1l1l1_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ丐")).decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ丑")),l1l1l1_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ丒"),l1l1l1_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ专"))
		#l1l1llll11ll_l1_.show()
		#l1l1llll11ll_l1_.getControl(99991).setPosition(0,0)
		#l1l1llll11ll_l1_.getControl(311).l1ll1l1l111_l1_(text)
		#l1l1llll11ll_l1_.getControl(5).l1l1l1111lll_l1_(l1ll11l1l1ll_l1_)
		#width = xbmcgui.l1l1l1lll1ll_l1_()
		#height = xbmcgui.l1l1llllll1l_l1_()
		#resolution = (0.0+width)/height
		#l1l1llll11ll_l1_.getControl(5).l1ll111l1l1l_l1_(width-180)
		#l1l1llll11ll_l1_.getControl(5).setHeight(height-180)
		#l1l1llll11ll_l1_.doModal()
		#del l1l1llll11ll_l1_
	return
l1l1l1l111l1_l1_ = [
			 l1l1l1_l1_ (u"ࠥࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࠧࠨࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠣ且")
			,l1l1l1_l1_ (u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡦࡲࡩࡤ࡫ࡲࡹࡸࠦࡳࡤࡴ࡬ࡴࡹࡹࠧ丕")
			,l1l1l1_l1_ (u"ࠬࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺࠧ世")
			,l1l1l1_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡗ࡫ࡧࡩࡴࠦࡉ࡯ࡨࡲࠤࡐ࡫ࡹࠨ丗")
			,l1l1l1_l1_ (u"ࠧࡵࡪ࡬ࡷࠥ࡮ࡡࡴࡪࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡤࡵࡳࡰ࡫࡮ࠨ丘")
			,l1l1l1_l1_ (u"ࠨࡷࡶࡩࡸࠦࡰ࡭ࡣ࡬ࡲࠥࡎࡔࡕࡒࠣࡪࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࡵࠪ丙")
			,l1l1l1_l1_ (u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡺࡹࡡࡨࡧ࠱࡬ࡹࡳ࡬ࠤࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧ业")
			,l1l1l1_l1_ (u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭丛")
			,l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡁ࠵ࠬࡴࡦࡺࡷࡁࠬ东")
			,l1l1l1_l1_ (u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭丝")
			,l1l1l1_l1_ (u"࠭࡞࡟ࡠࡡࡢࠬ丞")
			]
def l1l1ll1l11ll_l1_(line):
	if l1l1l1_l1_ (u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬ丟") in line and l1l1l1_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭丠") in line: return True
	for text in l1l1l1l111l1_l1_:
		if text in line: return True
	return False
def l1l1l111l11l_l1_(data):
	data = data.replace(l1l1l1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ両")+l1l1l1_l1_ (u"ࠪࠤࠬ丢")*51+l1l1l1_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ丣"),l1l1l1_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ两"))
	data = data.replace(l1l1l1_l1_ (u"࠭࡜࡯ࠩ严")+l1l1l1_l1_ (u"ࠧࠡࠩ並")*51+l1l1l1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭丧"),l1l1l1_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ丨"))
	data = data.replace(l1l1l1_l1_ (u"ࠪࡠࡳ࠭丩")+l1l1l1_l1_ (u"ࠫࠥ࠭个")*51+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ丫"),l1l1l1_l1_ (u"࠭࡜࡯ࠩ丬"))
	data = data.replace(l1l1l1_l1_ (u"ࠧࠡࠢࠣࠤࠥࡌࡩ࡭ࡧࠣࠦ࠴ࡹࡴࡰࡴࡤ࡫ࡪ࠵ࡥ࡮ࡷ࡯ࡥࡹ࡫ࡤ࠰࠲࠲ࡅࡳࡪࡲࡰ࡫ࡧ࠳ࡩࡧࡴࡢ࠱ࡲࡶ࡬࠴ࡸࡣ࡯ࡦ࠲ࡰࡵࡤࡪ࠱ࡩ࡭ࡱ࡫ࡳ࠰࠰࡮ࡳࡩ࡯࠯ࡢࡦࡧࡳࡳࡹ࠯ࠨ中"),l1l1l1_l1_ (u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠭丮"))
	data = data.replace(l1l1l1_l1_ (u"ࠩࠣࡀ࡬࡫࡮ࡦࡴࡤࡰࡃࡀࠠࠨ丯"),l1l1l1_l1_ (u"ࠪ࠾ࠥ࠭丰"))
	return data
def l1l1l11lll11_l1_(l1l1llll1l1l_l1_):
	if l1l1l1_l1_ (u"ࠫࡔࡒࡄࠨ丱") in l1l1llll1l1l_l1_:
		l1ll11ll1111_l1_ = l1l1l11l1l1l_l1_
		header = l1l1l1_l1_ (u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣรࠬ串")
	else:
		l1ll11ll1111_l1_ = l1ll11lll111_l1_
		header = l1l1l1_l1_ (u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊อศๆํࠤฤ࠭丳")
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࠨ临"),l1l1l1_l1_ (u"ࠨࠩ丵"),l1l1l1_l1_ (u"ࠩࠪ丶"),header,l1l1l1_l1_ (u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭丷"))
	if yes!=1: return
	l1l1l111lll1_l1_,counts = [],0
	size = os.path.getsize(l1ll11ll1111_l1_)
	file = open(l1ll11ll1111_l1_,l1l1l1_l1_ (u"ࠫࡷࡨࠧ丸"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ丹"))
	data = l1l1l111l11l_l1_(data)
	lines = data.split(l1l1l1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ为"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ主"))
		#if line.strip(l1l1l1_l1_ (u"ࠨࠢࠪ丼"))==l1l1l1_l1_ (u"ࠩࠪ丽"): continue
		ignore = l1l1ll1l11ll_l1_(line)
		if ignore: continue
		line = line.replace(l1l1l1_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡࡡࠪ举"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ丿"))
		line = line.replace(l1l1l1_l1_ (u"ࠬࡋࡒࡓࡑࡕ࠾ࠬ乀"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࡇࡕࡖࡔࡘ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ乁"))
		l1l1l1l1111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠩࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ乂"),line,re.DOTALL)
		l1l1lllll111_l1_ = l1l1l1_l1_ (u"ࠨࠩ乃")
		if l1l1l1l1111l_l1_:
			line = line.replace(l1l1l1l1111l_l1_[0][0],l1l1l1_l1_ (u"ࠩࠪ乄")).replace(l1l1l1l1111l_l1_[0][2],l1l1l1_l1_ (u"ࠪࠫ久"))
			l1l1lllll111_l1_ = l1l1l1l1111l_l1_[0][1]
		else:
			l1l1l1l1111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ乆"),line,re.DOTALL)
			if l1l1l1l1111l_l1_:
				line = line.replace(l1l1l1l1111l_l1_[0][1],l1l1l1_l1_ (u"ࠬ࠭乇"))
				l1l1lllll111_l1_ = l1l1l1l1111l_l1_[0][0]
		if l1l1lllll111_l1_: line = line.replace(l1l1lllll111_l1_,l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ么")+l1l1lllll111_l1_+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ义"))
		l1l1l111lll1_l1_.append(line)
		if len(str(l1l1l111lll1_l1_))>50100: break
	l1l1l111lll1_l1_ = reversed(l1l1l111lll1_l1_)
	l1ll11l1l1ll_l1_ = l1l1l1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭乊").join(l1l1l111lll1_l1_)
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ之"),l1l1l1_l1_ (u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ乌"),l1ll11l1l1ll_l1_,l1l1l1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ乍"))
	return
def l1l1l1l11111_l1_():
	l1ll11ll111l_l1_ = open(l1l1lllll1l1_l1_,l1l1l1_l1_ (u"ࠬࡸࡢࠨ乎")).read()
	if kodi_version>18.99: l1ll11ll111l_l1_ = l1ll11ll111l_l1_.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ乏"))
	l1ll11ll111l_l1_ = l1ll11ll111l_l1_.replace(l1l1l1_l1_ (u"ࠧ࡝ࡶࠪ乐"),l1l1l1_l1_ (u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪ乑"))
	l1lll111l1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ乒"),l1ll11ll111l_l1_,re.DOTALL)
	for line in l1lll111l1l1_l1_:
		l1ll11ll111l_l1_ = l1ll11ll111l_l1_.replace(line,l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭乓")+line+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭乔"))
	DIALOG_TEXTVIEWER(l1l1l1_l1_ (u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭乕"),l1ll11ll111l_l1_)
	return
def l1ll1111ll1l_l1_():
	l1llll111l1_l1_ = l1l1l1_l1_ (u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨ乖")
	l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫ乗")
	l111ll11lll_l1_ = l1l1l1_l1_ (u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫ乘")
	message = l1llll111l1_l1_+l1l1l1_l1_ (u"ࠩ࠽ࠤࠬ乙")+l1llll111ll_l1_+l1l1l1_l1_ (u"ࠪࠤ࠳ࠦࠧ乚")+l111ll11lll_l1_
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ乛"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ乜"),message,l1l1l1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ九"))
	return
def l11l1ll1111_l1_(l111111lll1_l1_,message,showDialogs=True,url=l1l1l1_l1_ (u"ࠧࠨ乞"),source=l1l1l1_l1_ (u"ࠨࠩ也"),text=l1l1l1_l1_ (u"ࠩࠪ习"),l11l1l11111_l1_=l1l1l1_l1_ (u"ࠪࠫ乡")):
	if l1l1l1_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ乢") in text: l1lll1111l11_l1_ = True
	else: l1lll1111l11_l1_ = False
	l1l1l11111ll_l1_ = True
	if not l1l1ll11ll11_l1_(l1l1l1_l1_ (u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭乣")):
		if showDialogs:
			#if message.count(l1l1l1_l1_ (u"࠭࡜࡝ࡰࠪ乤"))>1: l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭乥")
			#else: l1l1l1l1lll1_l1_ = l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ书")
			l1l1l1l1l1ll_l1_ = (l1l1l1_l1_ (u"ࠩสุ่฽ั࠻ࠩ乧") in message and l1l1l1_l1_ (u"ࠪห้๋ใศ่࠽ࠫ乨") in message and l1l1l1_l1_ (u"ࠫฬ๊ๅๅใ࠽ࠫ乩") in message and l1l1l1_l1_ (u"ࠬอไฯูฦࠫ乪") in message and l1l1l1_l1_ (u"࠭วๅ็ุำึࡀࠧ乫") in message)
			if not l1l1l1l1l1ll_l1_: l1l1l11111ll_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ乬"),l1l1l1_l1_ (u"ࠨࠩ乭"),l1l1l1_l1_ (u"ࠩࠪ乮"),l1l1l1_l1_ (u"๋้ࠪࠦสาี็ࠤ์ึ็ࠡษ็ีุอไสࠢศ่๎ࠦวๅ็หี๊าࠧ乯"),message.replace(l1l1l1_l1_ (u"ࠫࡡࡢ࡮ࠨ买"),l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ乱")))
	elif showDialogs:
		message = l1l1l1_l1_ (u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭乲")
		l1ll1l1l11l1_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ乳"),l1l1l1_l1_ (u"ࠨࠩ乴"),l1l1l1_l1_ (u"ࠩࠪ乵"),l1l1l1_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ乶")+l1l1l1_l1_ (u"ࠫࠥࠦ࠱࠰࠷ࠪ乷"),l1l1l1_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ乸"))
		l1ll1l1l111l_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭乹"),l1l1l1_l1_ (u"ࠧࠨ乺"),l1l1l1_l1_ (u"ࠨࠩ乻"),l1l1l1_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ乼")+l1l1l1_l1_ (u"ࠪࠤࠥ࠸࠯࠶ࠩ乽"),l1l1l1_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ乾"))
		l1ll1l1l1111_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ乿"),l1l1l1_l1_ (u"࠭ࠧ亀"),l1l1l1_l1_ (u"ࠧࠨ亁"),l1l1l1_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ亂")+l1l1l1_l1_ (u"ࠩࠣࠤ࠸࠵࠵ࠨ亃"),l1l1l1_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ亄"))
		l1ll1l1l1ll1_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ亅"),l1l1l1_l1_ (u"ࠬ࠭了"),l1l1l1_l1_ (u"࠭ࠧ亇"),l1l1l1_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ予")+l1l1l1_l1_ (u"ࠨࠢࠣ࠸࠴࠻ࠧ争"),l1l1l1_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ亊"))
		l1l1l11111ll_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ事"),l1l1l1_l1_ (u"ࠫࠬ二"),l1l1l1_l1_ (u"ࠬ࠭亍"),l1l1l1_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭于")+l1l1l1_l1_ (u"ࠧࠡࠢ࠸࠳࠺࠭亏"),l1l1l1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭亐"))
	if l1l1l11111ll_l1_!=1:
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ云"),l1l1l1_l1_ (u"ࠪࠫ互"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ亓"),l1l1l1_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨ五"))
		return False
	l1ll1l1l1lll_l1_ = xbmc.getInfoLabel( l1l1l1_l1_ (u"ࠨࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠧ井") )
	message += l1l1l1_l1_ (u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭亖")+addon_version+l1l1l1_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࠧ亗")
	message += l1l1l1_l1_ (u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪ亘")+l1ll11l1lll_l1_(32)+l1l1l1_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ亙")+l1l1llll1lll_l1_+l1l1l1_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ亚")
	message += l1l1l1_l1_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪ些")+l1ll1l1l1lll_l1_
	#l1ll1l11l11l_l1_ = l1l1l1l1ll11_l1_(l1l1l1_l1_ (u"࠭࠷࠷࠰࠹࠹࠳࠷࠳࠹࠰࠵࠷࠵࠭亜"))
	l1ll1l11l11l_l1_ = l1l1l1l1ll11_l1_()
	l1ll1l11l11l_l1_ = QUOTE(l1ll1l11l11l_l1_)
	if l1ll1l11l11l_l1_: message += l1l1l1_l1_ (u"ࠧࠡ࠼࡟ࡠࡳࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠺ࠡࠩ亝")+l1ll1l11l11l_l1_
	if url: message += l1l1l1_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࡕࡓࡎ࠽ࠤࠬ亞")+url
	if source: message += l1l1l1_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡔࡱࡸࡶࡨ࡫࠺ࠡࠩ亟")+source
	message += l1l1l1_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࠩ亠")
	if showDialogs: DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠫัอั๋ࠢส่สืำศๆࠪ亡"),l1l1l1_l1_ (u"ࠬอไาฮสลࠥอไศ่อ฼ฬืࠧ亢"))
	if l11l1l11111_l1_:
		l1ll11l1l1ll_l1_ = l11l1l11111_l1_
		if kodi_version>18.99: l1ll11l1l1ll_l1_ = l1ll11l1l1ll_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ亣"))
		l1ll11l1l1ll_l1_ = base64.b64encode(l1ll11l1l1ll_l1_)
	elif l1lll1111l11_l1_:
		if l1l1l1_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧ交") in text: l1ll1l11lll1_l1_ = l1l1l11l1l1l_l1_
		else: l1ll1l11lll1_l1_ = l1ll11lll111_l1_
		if not os.path.exists(l1ll1l11lll1_l1_):
			DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ亥"),l1l1l1_l1_ (u"ࠩࠪ亦"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭产"),l1l1l1_l1_ (u"ุࠫาไࠡษ็วำ฽วย๋ࠢห้อำหะาหฺ๊๋ࠦำ้ࠣํา่ะࠩ亨"))
			return False
		l1l1l111lll1_l1_,counts = [],0
		size = os.path.getsize(l1ll1l11lll1_l1_)
		file = open(l1ll1l11lll1_l1_,l1l1l1_l1_ (u"ࠬࡸࡢࠨ亩"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ亪"))
		data = l1l1l111l11l_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ享"))
			ignore = l1l1ll1l11ll_l1_(line)
			if ignore: continue
			l1l1l1l1111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡠࠫࡠࡩ࠱࠭ࠪࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ京"),line,re.DOTALL)
			if l1l1l1l1111l_l1_:
				line = line.replace(l1l1l1l1111l_l1_[0][0],l1l1l1_l1_ (u"ࠩࠪ亭")).replace(l1l1l1l1111l_l1_[0][2],l1l1l1_l1_ (u"ࠪࠫ亮"))
			else:
				l1l1l1l1111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ亯"),line,re.DOTALL)
				if l1l1l1l1111l_l1_: line = line.replace(l1l1l1l1111l_l1_[0][1],l1l1l1_l1_ (u"ࠬ࠭亰"))
			l1l1l111lll1_l1_.append(line)
			if len(str(l1l1l111lll1_l1_))>121000: break
		l1l1l111lll1_l1_ = reversed(l1l1l111lll1_l1_)
		l1ll11l1l1ll_l1_ = l1l1l1_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ亱").join(l1l1l111lll1_l1_)
		l1ll11l1l1ll_l1_ = l1ll11l1l1ll_l1_.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ亲"))
		l1ll11l1l1ll_l1_ = base64.b64encode(l1ll11l1l1ll_l1_)
	else: l1ll11l1l1ll_l1_ = l1l1l1_l1_ (u"ࠨࠩ亳")
	url = WEBSITES[l1l1l1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ亴")][2]
	payload = {l1l1l1_l1_ (u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫ亵"):l111111lll1_l1_,l1l1l1_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ亶"):message,l1l1l1_l1_ (u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭亷"):l1ll11l1l1ll_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ亸"),url,payload,l1l1l1_l1_ (u"ࠧࠨ亹"),l1l1l1_l1_ (u"ࠨࠩ人"),l1l1l1_l1_ (u"ࠩࠪ亻"),l1l1l1_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭亼"))
	#succeeded = response.succeeded
	html = response.content
	if l1l1l1_l1_ (u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭亽") in html: succeeded = True
	else: succeeded = False
	if showDialogs:
		if succeeded:
			DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠬะๅࠡษ็ษึูวๅࠩ亾"),l1l1l1_l1_ (u"࠭ศ็ฮสัࠬ亿"))
			DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ什"),l1l1l1_l1_ (u"ࠨࠩ仁"),l1l1l1_l1_ (u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨ仂"),l1l1l1_l1_ (u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬ仃"))
		else:
			DIALOG_NOTIFICATION(l1l1l1_l1_ (u"้๊ࠫริใࠪ仄"),l1l1l1_l1_ (u"ࠬ็ิๅࠢไ๎ࠥอไฦำึห้࠭仅"))
			DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ仆"),l1l1l1_l1_ (u"ࠧࠨ仇"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ仈"),l1l1l1_l1_ (u"ࠩั฻ศ่ࠦโึ็ࠤๆ๐ࠠฦำึห้ࠦวๅำึห้ฯࠧ仉"))
	return succeeded
def l1l1l1111l1l_l1_():
	l1llll111l1_l1_ = l1l1l1_l1_ (u"ࠪ࠵࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡰࡳࡱࡥࡰࡪࡳࠠࡸ࡫ࡷ࡬ࠥࡇࡲࡢࡤ࡬ࡧࠥࡺࡥࡹࡶࠣࡸ࡭࡫࡮ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠤࡹࡵࠠࠣࡃࡵ࡭ࡦࡲࠢࠨ今")
	l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠫ࠶࠴ࠠࠡࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅละีๆࠦวๅ฻ิฬ๏ฯࠠโษำ๋อࠦวๅ๋ࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭介")
	DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭仌"),l1l1l1_l1_ (u"࠭ࠧ仍"),l1l1l1_l1_ (u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ从"),l1llll111l1_l1_+l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭仏")+l1llll111ll_l1_)
	l1llll111l1_l1_ = l1l1l1_l1_ (u"ࠩ࠵࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡦࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠨ仐")
	l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠪ࠶࠳ࠦࠠࠡวำห๊ࠥๅࠡฬฯำࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤๆ่ๅࠡสอ฾๏๐ัࠡษ็ะ้ีࠠฬ็ࠣๆ๊ࠦศห฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥอไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪ仑")
	DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ仒"),l1l1l1_l1_ (u"ࠬ࠭仓"),l1l1l1_l1_ (u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬ仔"),l1llll111l1_l1_+l1l1l1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ仕")+l1llll111ll_l1_)
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ他"),l1l1l1_l1_ (u"ࠩࠪ仗"),l1l1l1_l1_ (u"ࠪࠫ付"),l1l1l1_l1_ (u"ࠫࡋࡵ࡮ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫ仙"),l1l1l1_l1_ (u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡲࡴࡽࠠࡀࠩ仚")+l1l1l1_l1_ (u"࠭࡜࡯࡞ࡱࠫ仛")+l1l1l1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษ็ิ์อศࠡว็ํ๊่ࠥฮหࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡล็ฦ๋ลࠧ仜"))
	if yes==1: l1ll11l1ll11_l1_()
	return
def l1ll1l1llll1_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ仝"),l1l1l1_l1_ (u"ࠩࠪ仞"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭仟"),l1l1l1_l1_ (u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪ仠"))
	return
def l1ll11lll1ll_l1_():
	message = l1l1l1_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬ仡")
	DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ仢"),l1l1l1_l1_ (u"ࠧࠨ代"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ令"),message)
	return
def l1l1lll1l11l_l1_():
	message = l1l1l1_l1_ (u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭以")
	DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ仦"),l1l1l1_l1_ (u"ࠫࠬ仧"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ仨"),message)
	return
def l1l1l11111l1_l1_():
	message = l1l1l1_l1_ (u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪ仩")
	DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ仪"),l1l1l1_l1_ (u"ࠨࠩ仫"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ们"),l1l1l1_l1_ (u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬ仭"),message)
	return
def l1ll11l1ll1l_l1_():
	message = l1l1l1_l1_ (u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩ仮")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ仯"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ仰"),message,l1l1l1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ仱"))
	return
def l1ll11111111_l1_():
	l1llll111l1_l1_ = l1l1l1_l1_ (u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩ仲")
	l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫ仳")
	l111ll11lll_l1_ = l1l1l1_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ仴")
	DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ仵"),l1l1l1_l1_ (u"ࠬ࠭件"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ价"),l1llll111l1_l1_,l1llll111ll_l1_,l111ll11lll_l1_)
	return
def l1l1lll1111l_l1_():
	l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠧศๆๆหูࠦ็้่ࠢาื์ࠠๆฦๅฮ๊ࠥไๆ฻็์๊อสࠡ์ึฮำีๅ่ࠢส่อืๆศ็ฯࠤ้ิา็ุࠢๅาอสࠡษ็ษ๋ะั็์อࠤํื่ศสฺࠤฬ๊แ๋ัํ์์อสࠡๆ็์ฺ๎ไࠡว็๎์อࠠษีิ฽ฮ่ࠦษั๋๊ࠥหๆหำ้๎ฯ่ࠦศๆหี๋อๅอࠢํุ้ำ็ศࠢอ่็อฦ๋ษࠣฬ฾ีࠠศ่อ๋ฬวฺࠠ็ิ๋ฬ่ࠦฤ์ูหࠥ฿ๆะࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣ࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะࠥ๐ำหะาู้ࠥศฺหࠣว๋๎วฺࠢ็฽๊ืࠠศๆๆหูࠦ࠺ࠨ仸")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭仹") + l1l1l1_l1_ (u"ࠩ࠴࠲ࠥัวษฬ่้ࠣ฻แฮษอࠤฬ๊ส๋่ࠢ฽ึ๎แࠡล้๋ฬࠦไศࠢอฮ฿๐ั่๊ࠡหห๐ว๊่ࠡำฯํࠠࠨ仺") + str(PERMANENT_CACHE/60/60/24/30) + l1l1l1_l1_ (u"ࠪࠤูํัࠨ任")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴࠧ仼") + l1l1l1_l1_ (u"ࠬ࠸࠮ࠡฮาหࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้๋แาู๊ࠤศ์็ศࠢ็หࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ份") + str(l1lll1l1lll_l1_/60/60/24) + l1l1l1_l1_ (u"๋๊่࠭ࠠࠫ仾")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ仿") + l1l1l1_l1_ (u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ伀") + str(l11l11l_l1_/60/60/24) + l1l1l1_l1_ (u"ࠩࠣ๎ํ๋ࠧ企")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠪࡠࡳ࠭伂") + l1l1l1_l1_ (u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭伃") + str(REGULAR_CACHE/60/60) + l1l1l1_l1_ (u"ࠬࠦำศ฻ฬࠫ伄")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"࠭࡜࡯ࠩ伅") + l1l1l1_l1_ (u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫ伆") + str(l1llll111_l1_/60/60) + l1l1l1_l1_ (u"ࠨࠢึห฾ฯࠧ伇")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ伈") + l1l1l1_l1_ (u"ࠪ࠺࠳ࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํี้ࠥห๋ำสࠤํ๋ฯห้ࠣࠫ伉") + str(l1l1111lll1_l1_/60) + l1l1l1_l1_ (u"ࠫࠥีโ๋ไฬࠫ伊")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ伋") + l1l1l1_l1_ (u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨ伌") + str(NO_CACHE) + l1l1l1_l1_ (u"ࠧࠡัๅ๎็ฯࠧ伍")
	l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭伎") + l1l1l1_l1_ (u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭伏") + str(REGULAR_CACHE/60/60) + l1l1l1_l1_ (u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫ伐") + str(l11l11l_l1_/60/60/24) + l1l1l1_l1_ (u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪ休") + str(l1llll111_l1_/60/60) + l1l1l1_l1_ (u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩ伒") + str(l1l1111lll1_l1_/60) + l1l1l1_l1_ (u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨ伓") + str(NO_CACHE) + l1l1l1_l1_ (u"ࠧࠡัๅ๎็ฯࠧ伔")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ伕"),l1l1l1_l1_ (u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧ伖"),l1llll111ll_l1_,l1l1l1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭众"))
	return
def l1l1l1l11l11_l1_():
	message = l1l1l1_l1_ (u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧ优")
	DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭伙"),l1l1l1_l1_ (u"࠭ࠧ会"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ伛"),message)
	return
def l1l1l1ll1ll1_l1_():
	message = l1l1l1_l1_ (u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩ伜")
	DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ伝"),l1l1l1_l1_ (u"ࠪࠫ伞"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ伟"),message)
	return
def l1ll111l111l_l1_():
	message = l1l1l1_l1_ (u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩ传")
	DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ伡"),l1l1l1_l1_ (u"ࠧࠨ伢"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ伣"),message)
	return
def l1l1l1ll1111_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ伤"),l1l1l1_l1_ (u"ࠪࠫ伥"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ伦"),l1l1l1_l1_ (u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ伧"))
	l1ll1111ll11_l1_(l1l1l1_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭伨"),True)
	return
def l1l1ll11l111_l1_():
	message  = l1l1l1_l1_ (u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩ伩")
	#message += l1l1l1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๎็ัษࠣห้฿ววไ๋ࠣํࠦࡲࡦࡅࡄࡔ࡙ࡉࡈࡂࠢส่ำอีࠡสืี่ฯࠠอ๊ฯ่ࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ伪")
	#message += l1l1l1_l1_ (u"๋ࠩห้ึ๊ࠡื้฽ฯํࠠีำๆอࠥา่อๆࠣาฺ๐ีศࠢ็้๋฿ࠠษำส้ัࠦๅฬๆࠣ็ํี๊ࠡ็้ࠤฯ฻แฮࠢส่ส์สา่อࠫ伫")
	message += l1l1l1_l1_ (u"ࠪࠤํ์ส๋ฮฬࠤ้ํะศࠢส่฾อฦใࠢไห๋ํࠠหไิ๎ออࠠอ็ํ฽๋ࠥำหะา้๏ࠦศา่ส้ัࠦใ้ัํࠤ้อ๋ࠠีอ฻๏฿่็ࠢส่ิิ่ๅࠢ็ะ๊๐ูࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢะฮ๎ࠦๅฺࠢสืฯิฯศ็ࠪ伬")
	message += l1l1l1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞โࠣࠤ࡛ࡖࡎࠡࠢฦ์ࠥࠦࡐࡳࡱࡻࡽࠥࠦร้ࠢࠣࡈࡓ࡙ࠠࠡล๋ࠤศ๐ࠠฮๆࠣฬุ๐ืࠡฤัีࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ伭")
	message += l1l1l1_l1_ (u"ࠬࡢ࡮ๅษ้ࠤ์ึวࠡๆ้ࠤ๏ำไࠡษ็ู้้ไส๋ࠢษ๋๋วࠡใๅ฻ู๊ࠥใ๊่ࠤอหีๅษะࠤอ฿ึࠡษ็้ํอโฺ๋ࠢษ฾อโส่ࠢ์ฬู่ࠡษัี๎ࠦใศ่อࠤฯ฿ๅๅࠢึหอ่วࠡสา์๋ࠦๅีษๆ่ࠬ伮")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ伯"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ估"),message,l1l1l1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ伱"))
	message = l1l1l1_l1_ (u"ࠩส่๊๎วใ฻ࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬ伲")
	message += l1l1l1_l1_ (u"ࠪࡠࡳ࠭伳")+l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡡ࡬ࡱࡤࡱࠥࠦࡥࡨࡻࡥࡩࡸࡺࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠥࠦ࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠢࠣࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠢࠣࡷ࡭ࡧࡨࡪࡦ࠷ࡹࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭伴")
	message += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ伵")+l1l1l1_l1_ (u"࠭วๅั๋่ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ伶")
	message += l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ伷")+l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠฺ้ืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭伸")
	message += l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ伹")+l1l1l1_l1_ (u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫ伺")
	message += l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣวาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ伻")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ似"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ伽"),message,l1l1l1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ伾"))
	#l1ll111l11ll_l1_(l1l1l1_l1_ (u"ࠨࡋࡶࡔࡷࡵࡢ࡭ࡧࡰࡁࡋࡧ࡬ࡴࡧࠪ伿"))
	#message = l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ佀")+l1l1l1_l1_ (u"ࠪ์้่ฯࠡๆสั฽์วࠡษํฺฬࠦร็ࠢส่๊๎วใ฻ࠣหู้๋ศไฬࠤฯิสๅใࠣฬฬิสๅษไࠤฬ๊ศๅัࠣ์ฯิสๅใࠣฬฬิสๅษไࠤูืใสࠢส่ฬ์สา่ํฮࠥ็๊ࠡา็็ࠥอไษๆาࠤํํะศ่ࠢ฽๋อ็ࠡษ้๋ࠥำส๊ࠢ็์ࠥะๅࠡษึฮำีวๆ࡙ࠢࡔࡓࠦร้ࠢࡓࡶࡴࡾࡹࠡล๋ࠤศ๐้ࠠีํ่ฮࠦวฯำ์ࠤๆอๆࠡษ็้ํอโฺࠢส่๊฿วใหࠣืํ็ࠠหะอ่ๆ่ࠦๅๅ้๋ฬࠦไ็ࠢอ฽๊๊ࠠอ็ํ฽์อࠧ佁")
	#message += l1l1l1_l1_ (u"้ࠫำไࠡษ็ู้้ไสࠢๅ้ࠥฮูๆๆํ๊࠿ࠦࠠࠡࠢส่ศ๎ไ࠻ࠢฦีุ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠࠩ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯ࠭ࠥ๎วไฬหࠤ๊฿็ࠡษึ้ࠥฮไะๅࠣ์ฬูๅࠡึิ็ฮࠦวๅว้ฮึ์๊ห๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠧ佂")
	#message += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ佃")+l1l1l1_l1_ (u"่࠭ศๆฮห๋๐࠺ࠡฮิฬࠥอำหะาห๊ࠦࡖࡑࡐࠣ์฾์ฯࠡษ็ฬ฾฼ࠠใัࠣฮาะวอࠢไๆ฼ࠦส฻์ํีࠥࡊࡎࡔ๋ࠢห้ษอิ่ࠣว๋๊ࠦไ๊้ࠤๆ๐ࠠษๆาࠤฬิัࠡ฻็้ฬࠦว็ࠢสืฯิฯศ็ࠣࡔࡷࡵࡸࡺࠢๅำࠥ๐อๅุ่่๊ࠢษࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦๅๅ้ࠤ้๐ำࠡใํࠤัฺ๋๊ࠢส่ิ๎ไࠨ佄")
	#DIALOG_TEXTVIEWER(l1l1l1_l1_ (u"ࠧๆึๆ่ฮูࠦ็ัࠣฬ฾฼ࠠศๆ้หุ࠭佅"),message)
	#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ但"),l1l1l1_l1_ (u"ࠩไัฺࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠬ佇"),l1l1l1_l1_ (u"๋ࠪีอࠠศๆไัฺࠦ็้ࠢ็้฾ืแส๊่ࠢࠥอไๆึๆ่ฮࠦๅ็ࠢ฼๊ิ้ࠠศ็้๋ࠣࠦวๅสิ๊ฬ๋ฬ࠯ࠢึ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสไัฺࠦๅ้ษๅ฽์ࠦๅาฬํ๊ࠥอไฤ๊็ํࠥฮ่ื฻ๆࠤฬ๊ืษ์฼๎ࠥ๎วๅอส๊๏ฯࠠษษึฮำีวๆࠢหีํ้ำ๋่ࠢะฬ์๊ࠡษ้ฮࠥะฮหษิ๋๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠิฬ฻๋ึࠦไศฯๅห࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำยࠫ佈"),l1l1l1_l1_ (u"ࠫࠬ佉"),l1l1l1_l1_ (u"ࠬ࠭佊"),l1l1l1_l1_ (u"࠭ใๅษࠪ佋"),l1l1l1_l1_ (u"ࠧ็฻่ࠫ佌"))
	#if yes==1:
	#l1l1llll11l1_l1_()
	return
def l1l1ll1lll11_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ位"),l1l1l1_l1_ (u"ࠩࠪ低"),l1l1l1_l1_ (u"ࠪฯ้อหูࠡิๆ๊ࠥไห๊สู้ࠦๅฺࠢส่๊ฮัๆฮࠪ住"),l1l1l1_l1_ (u"ࠫศืำๅࠢิืฬ๊ษࠡล๋ࠤฺ๊ใๅห้๋ࠣࠦโศศ่อࠥิฯๆษอࠤ์ึวࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴร้ࠢฦีุ๊ࠠาีส่ฮࠦแ๋ีห์่ࠦวๅ๋ࠣࠦฬ๊อศฮࠣ฽๊อฯࠣࠢฦ์ࠥอไ๊ࠢ࡟ࡲ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩ࠴࡭ࡢࡪࡧ࡭࠶ࠦ࡜࡯࡞ࡱวํࠦวโฬะࠤ๋่วีࠢหหุะฮะษ่ࠤ์ึวࠡษ็ีฬฮืࠡ࡞ࡱࠤ࡭ࡺࡴࡱ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱࡬ࡷࡸࡻࡥࡴࠩ佐"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭佑"),l1l1l1_l1_ (u"࠭ࠧ佒"),l1l1l1_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ体"),l1l1l1_l1_ (u"ࠨ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࡠࡳࡢ࡮࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࡣ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࡠࡌࡍࡎࡏࡐ࠱ࡠࡍࡎࡏࡐࡑ࠱ࡠࡎࡏࡐࡑࡒ࠱ࡠࡏࡐࡑࡒࡓ࠱ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣࡅࡆࡇࡁࡂ࠴ࡢࡆࡇࡈࡂࡃ࠴ࡢࡇࡈࡉࡃࡄ࠴ࡢࡈࡉࡊࡄࡅ࠴ࡢࡉࡊࡋࡅࡆ࠴ࡢࡊࡋࡌࡆࡇ࠴ࡢࡋࡌࡍࡇࡈ࠴ࡢࡌࡍࡎࡈࡉ࠴ࡢࡍࡎࡏࡉࡊ࠴ࡢࡎࡏࡐࡊࡋ࠴ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࠣ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆࠦࡂࡃࡄࡅࡆࠬ佔"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ何"),l1l1l1_l1_ (u"ࠪࠫ佖"),l1l1l1_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ佗"),l1l1l1_l1_ (u"ࠬ࠶ࠠ࠱ࠢ࠳ࠤ࠵ࠦ࠰ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠲ࠢ࠴ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠶ࠥ࠸ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠳ࠡ࠵ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠷ࠤ࠹ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠻ࠠ࠶ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠸ࠣ࠺ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠼ࠦ࠷ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠹ࠢ࠻ࠤ࠾ࠦ࠹ࠡ࠻ࠣ࠽ࠥ࠿ࠠࡂࡃࡄࡅࡆ࠷࡟ࡃࡄࡅࡆࡇ࠷࡟ࡄࡅࡆࡇࡈ࠷࡟ࡅࡆࡇࡈࡉ࠷࡟ࡆࡇࡈࡉࡊ࠷࡟ࡇࡈࡉࡊࡋ࠷࡟ࡈࡉࡊࡋࡌ࠷࡟ࡉࡊࡋࡌࡍ࠷࡟ࡊࡋࡌࡍࡎ࠷࡟ࡋࡌࡍࡎࡏ࠷࡟ࡌࡍࡎࡏࡐ࠷࡟ࡍࡎࡏࡐࡑ࠷࡟ࡎࡏࡐࡑࡒ࠷ࠠ࠱࠲࠳࠴࠵ࠦ࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵ࠤ࠸࠹࠳࠴࠵ࠣ࠸࠹࠺࠴࠵ࠢࡄࡅࡆࡇࡁ࠳ࡡࡅࡆࡇࡈࡂ࠳ࡡࡆࡇࡈࡉࡃ࠳ࡡࡇࡈࡉࡊࡄ࠳ࡡࡈࡉࡊࡋࡅ࠳ࡡࡉࡊࡋࡌࡆ࠳ࡡࡊࡋࡌࡍࡇ࠳ࡡࡋࡌࡍࡎࡈ࠳ࡡࡌࡍࡎࡏࡉ࠳ࡡࡍࡎࡏࡐࡊ࠳ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤ࠺࠻࠵࠶࠷ࠣ࠺࠻࠼࠶࠷ࠢ࠺࠻࠼࠽࠷ࠡ࠺࠻࠼࠽࠾ࠠ࠺࠻࠼࠽࠾ࠦࡁࡂࡃࡄࡅࠥࡈࡂࡃࡄࡅࠫ佘"))
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ余"),l1l1l1_l1_ (u"ࠧࠨ佚"),l1l1l1_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ佛"),l1l1l1_l1_ (u"ࠩ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠨ作"))
	#text = l1l1l1_l1_ (u"ࠪࠬࠥࡇࡁࡂࡃࡄ࠵ࡤࡈࡂࡃࡄࡅ࠵ࡤࡉࡃࡄࡅࡆ࠵ࡤࡊࡄࡅࡆࡇ࠵ࡤࡋࡅࡆࡇࡈ࠵ࡤࡌࡆࡇࡈࡉ࠵ࡤࡍࡇࡈࡉࡊ࠵ࡤࡎࡈࡉࡊࡋ࠵ࡤࡏࡉࡊࡋࡌ࠵ࠥ࠯ࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࠣࡳࠥࡶࠠࡲࠢࡵࠤࡸࠦࡴࠡࡷࠣࡺࠥࡽࠠࡹࠢࡼࠤࡿࠦ࠰ࠡ࠳ࠣ࠶ࠥ࠹ࠠ࠵ࠢ࠸ࠤ࠻ࠦ࠷ࠡ࠺ࠣ࠽ࠥࡧࠠࡣࠢࡦࠤࡩࠦࡥࠡࡨࠣ࡫ࠥ࡮ࠠࡪࠢ࡭ࠤࡰࠦ࡬ࠡ࡯ࠣࡲࠥࡵࠠࡱࠢࡴࠤࡷࠦࡳࠡࡶࠣࡹࠥࡼࠠࡸࠢࡻࠤࡾࠦࡺࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺ࠭佝")
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠫࠬ佞"),l1l1l1_l1_ (u"ࠬ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺࠲࠴࠶࠸࠺ࠧ佟"),l1l1l1_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ你"),l1l1l1_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ佡"),l1l1l1_l1_ (u"ࠨ࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵࠶࠷࠸࠲࠳ࠩ佢"),text,1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠩࠪ佣"),l1l1l1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ佤"),l1l1l1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ佥"),l1l1l1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ佦"),l1l1l1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ佧"),l1l1l1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ佨"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠨࠩ佩"),l1l1l1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ佪"),l1l1l1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ佫"),l1l1l1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ佬"),l1l1l1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ佭"),l1l1l1_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭佮"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"ࠧࠨ佯"),l1l1l1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ佰"),l1l1l1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ佱"),l1l1l1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ佲"),l1l1l1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ佳"),l1l1l1_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ佴"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1l1_l1_ (u"࠭ࠧ併"),l1l1l1_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ佶"),l1l1l1_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ佷"),l1l1l1_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ佸"),l1l1l1_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡢ࡮ࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ佹"),l1l1l1_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ佺"))
	return
def l1l1ll1l1lll_l1_():
	l1l1lll1111l_l1_()
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ佻"),l1l1l1_l1_ (u"࠭ࠧ佼"),l1l1l1_l1_ (u"ࠧࠨ佽"),l1l1l1_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤฬ๊ใศึࠣรࠬ佾"),l1l1l1_l1_ (u"ࠩส่่อิࠡ์ึี฾ูࠦๆๆࠣห้ฮั็ษ่ะࠥ๎ๅิฯ๊ࠤ๏฿๊ะࠢึัอࠦวๅืไัฬะࠠๆ่ࠣห้หๆหำ้ฮࠥ฿ๆะࠢส่าอฬสࠢศ่๏ํว๊ࠡสู่๊อࠡ์อ้ࠥะไใษษ๎ฬูࠦ็ัࠣห๋ะ็ศรࠣ฽๊ืࠠศๆุๅาอส๊ࠡสู่๊อࠡๆสࠤ๏฼ั๊่้่ࠡ์๋ࠠฯ็ࠤอ฿ึࠡษ็ู้อใๅࠩ使"))
	if yes==1:
		l1l1lll111l1_l1_(True)
		DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ侀"),l1l1l1_l1_ (u"ࠫࠬ侁"),l1l1l1_l1_ (u"ࠬะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤออไไษ่่ࠬ侂"),l1l1l1_l1_ (u"࠭ลัษࠣ็ฬ์สࠡ฻้ำ่ࠦๅีๅ็อࠥ็๊ࠡษะำࠥอไๆ๊สๆ฾ࠦแอำหࠤฬ๊ๅ้ไ฼ࠤฬ๊ย็ࠢ࠱࠲࠳่ࠦฤาสࠤฬ๊ๅีๅ็อ๋ࠥำห็ิอࠥ็ลั่ࠣหึูไࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠧ侃"))
	return yes
def l1ll11ll11l1_l1_(showDialogs=True):
	if not showDialogs: showDialogs = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ侄"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡼࡦࡳࡰ࡭ࡧ࠱ࡧࡴࡳࠧ侅"),l1l1l1_l1_ (u"ࠩࠪ來"),l1l1l1_l1_ (u"ࠪࠫ侇"),False,l1l1l1_l1_ (u"ࠫࠬ侈"),l1l1l1_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ侉"))
	#html = response.content
	if not response.succeeded:
		l1l1ll111l11_l1_ = False
		l1l1l1llll_l1_ = l1l1l1l1l1_l1_()
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ侊"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡌ࡙࡚ࡐࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡑࡧࡢࡦ࡮࠽࡟ࠬ例")+l1l1l1llll_l1_+l1l1l1_l1_ (u"ࠨ࡟ࠪ侌"))
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ侍"),l1l1l1_l1_ (u"ࠪࠫ侎"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ侏"),l1l1l1_l1_ (u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ侐"))
	else:
		l1l1ll111l11_l1_ = True
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ侑"),l1l1l1_l1_ (u"ࠧࠨ侒"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ侓"),l1l1l1_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢํ฽ฺ๊๊่ࠠา็ࠥ๎วๅสิ๊ฬ๋ฬࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭侔"))
	if not l1l1ll111l11_l1_ and showDialogs: l1l1lllllll1_l1_()
	return l1l1ll111l11_l1_
def l1l1lllllll1_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ侕"),l1l1l1_l1_ (u"ࠫࠬ侖"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ侗"),l1l1l1_l1_ (u"࠭ศฺุࠣห้๋่ศไ฼ࠤฯำสศฮࠣีอ฽ࠠๆึไีࠥ๎โะࠢํ็ํ์ࠠอ้สึฺ่๋ࠦำࠣๆฬีัࠡ฻็ํࠥอไาสฺࠤฬ๊ๅีใิࠤศ๎่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠี้สำฮࠦวๅฬืๅ๏ืࠠศๆัหฺฯࠠษๅ๋ำ๏ูࠦ็ัๆࠤ฾๊ๅศࠢส๊์ࠦสๆࠢไัฺࠦวๅสิ๊ฬ๋ฬࠡ฻็ํ้่ࠥะ์ࠣห้หีะษิหฯࠦ࡜࡯ࠢ࠴࠻࠳࠼ࠠࠡࠨࠣࠤ࠶࠾࠮࡜࠲࠰࠽ࡢࠦࠠࠧࠢࠣ࠵࠾࠴࡛࠱࠯࠶ࡡࠬ侘"))
	#l1llll111ll_l1_ = l1l1l1_l1_ (u"ࠧี้สำฮࠦวๅฬืๅ๏ื่ࠠ์้้ࠣ็๋ࠠฯอ์๏ูࠦๅุ๋ࠣๆืษࠡะสูฮࠦร้ࠢอ์ฬฺ่๊ࠢัหฺฯࠠๅึิ็ฬะࠠๆ฻ิ์ๆฯ้ࠠๆ๊ࠤฯอั๋ะู้ࠣออ๋หࠣ์๋็วั๋ࠢห้เัื่๊ࠢ์ࠦ็้ࠢอฬฬีไࠡษ็้฾๊่ๆษอࠤอ฽ั๋ไฬࠤฺ๊แาหࠣ๎ฺ฿ศࠡษัฮึอโ่ษࠣ์ๆํๅ่ษࠪ侙")
	l1ll111l11l1_l1_()
	return
def l1ll111l11ll_l1_(text=l1l1l1_l1_ (u"ࠨࠩ侚")):
	l1lll1111l11_l1_ = True
	if l1l1l1_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ供") not in text:
		l1lll1111l11_l1_ = False
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ侜"),l1l1l1_l1_ (u"ࠫสืำศๆࠣีุอไสࠩ依"),l1l1l1_l1_ (u"ࠬหัิษ็ࠤฺ๊ใๅหࠪ侞"),l1l1l1_l1_ (u"࠭ࠧ侟"),l1l1l1_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯืำๅࠢิืฬ๊ษࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไสࠢยࠫ侠"))
		if yes==1:
			l1lll1111l11_l1_ = True
			text = l1l1l1_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ価")
	if l1lll1111l11_l1_:
		#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ侢"),l1l1l1_l1_ (u"ࠪࠫ侣"),l1l1l1_l1_ (u"ࠫࠬ侤"),l1l1l1_l1_ (u"ࠬหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊࠭侥"),l1l1l1_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎ุะื๋฻ࠣห้๋ศา็ฯࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํหีๅษะ๋ฬ࠭侦"))
		#if not yes:
		#	DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ侧"),l1l1l1_l1_ (u"ࠨࠩ侨"),l1l1l1_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ侩"),l1l1l1_l1_ (u"่้ࠪษำโࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭侪"))
		#	return
		l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࡹ࡫ࡸࡵࠢ࠮ࡁࠥ࠭࡬ࡰࡩࡶࡁࡾ࡫ࡳࠨࠌࠌࠍࠎࡿࡥࡴࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣ࡞ࡋࡓࡏࡑࠫࠫࡨ࡫࡮ࡵࡧࡵࠫ࠱࠭็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ࠲ࠧใส็ࠤฬืำศๆࠣืั๊ࠠศๆสา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮࠣ฽้๐ใࠡษ้ࠤฯ่่ๆࠢหฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠣหํࠦวๅำสฬ฼ࠦวๅาํࠤ๏฿ื๋ๅࠣห้๋ิไๆฬࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไศะฺหฦ่ࠦศๆสืฯิฯศ็࠱ࠤ์๊ࠠหำํำࠥอไศำึห้ࠦวๅษ้ࠤฤ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧไๆสࠫ࠱࠭ๆฺ็ࠪ࠭ࠏࠏࠉࠊ࡫ࡩࠤࡾ࡫ࡳ࠾࠿࠳࠾ࠏࠏࠉࠊࠋࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨฬ่ࠤฬฺ๊ศรࠣห้อัิษ็ࠫ࠮ࠐࠉࠊࠋࠌࡶࡪࡺࡵࡳࡰࠣࠫࠬࠐࠉࠊࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠲ࠧศาสࠤ่อๆหࠢ็ำ๏้ࠠๆึๆ่ฮࠦแศๆิะฬวࠠใำสลฮࠦโิ็ࠣห้๋ิศๅ็ࠤํอไศีษ่ฮ่ࠦศาสࠤ้๋ࠠหฮาࠤฬ๊อๅ๊๊ࠢฬ้ࠠโฯส์้ࠦใหษหอࠥาๅ๋฻ࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩࠬࠎࠎࠏࠢࠣࠤ侫")
		if l1l1l1_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬ侬") not in text:
			yes = DIALOG_YESNO(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭侭"),l1l1l1_l1_ (u"ࠧࠨ侮"),l1l1l1_l1_ (u"ࠨࠩ侯"),l1l1l1_l1_ (u"ฺ๋ࠩ฾ࠦวๅ็ื็้ฯࠠโ์ࠣหู้ฬๅࠩ侰"),l1l1l1_l1_ (u"ࠪๆอ๊ࠠฦำึห้ࠦวๅีฯ่ࠥ฿ไ๋ๅࠣว๋ࠦสไำิࠤࠥ์แิࠢส่ๆ฿ไࠡษ็ิ๏ࠦรฺูส็ࠥอไๆึๆ่ฮࠦ࠮ࠡๆๆ๎ࠥ๐สๆࠢอืั๐ไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ࠳่ࠦษั๋๊ࠥํะศࠢส่ฯูฬ๋ๆࠣืํ็ࠠหำึ่๋ࠥไโࠢ็หࠥ็ววัฬࠤ๊์็ࠡๆศ๊์ࠦไศࠢํัฯ๎๊ࠡ฻็ํࠥอไๆึๆ่ฮࠦวๅฬํࠤฯื๊ะࠢส๊ฯࠦวๅวห่ฬเฺ่๊ࠠหࠥ࠴่ࠠๆࠣๆ๊ะࠠษฬๆีฬืࠠศๆุ่่๊ษࠡมࠪ侱"))
			if yes!=1:
				DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ侲"),l1l1l1_l1_ (u"ࠬ࠭侳"),l1l1l1_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠩ侴"),l1l1l1_l1_ (u"ࠧๅๆฦืๆࠦศะ๊้ࠤฯูฬ๋ๆࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢไห๋ࠦวๅ็หี๊าࠠๅษࠣ๎ุะื๋฻้ࠣ฾ืแสࠢสฺ่๊ใๅหࠣ์้อࠠฮๆ๊ห๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ侵"))
				return
	DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ侶"),l1l1l1_l1_ (u"ࠩࠪ侷"),l1l1l1_l1_ (u"ࠪ็ฯอศสุ๋ࠢึำࠠศๆ่์฻๎ูࠡๆ็้อืๅอࠩ侸"),l1l1l1_l1_ (u"ࠫๆ๐ࠠศๆืหูฯࠠศๆๅหิ๋ษࠡฯส์้ࠦร็ࠢอ็ฯฮࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอิาฯࠣๅ๏ํวࠡษ็ู้้ไสࠢฦ์ࠥอไๆู๊์฾่ࠦฦาสࠤศืฯหࠢฯ์ฬฮࠠๆ่ࠣห้๋ศา็ฯࠤๆหะ็ࠢฦ็ฯฮฺ่๋ࠠห๋ࠦศา์า็ࠥษไฦๆๆฮึ๎ๆ๋ࠢส่ฬ๐ๅ๋ๆࠣ์ฯึใา๋่ࠢฬࠦส็ี์ࠤศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ侹"))
	search = OPEN_KEYBOARD(l1l1l1_l1_ (u"ࠬ࡝ࡲࡪࡶࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭侺"))
	if not search: return
	message = search
	if l1lll1111l11_l1_: type = l1l1l1_l1_ (u"࠭࠭ࡑࡴࡲࡦࡱ࡫࡭ࠨ侻")
	else: type = l1l1l1_l1_ (u"ࠧ࠮ࡏࡨࡷࡸࡧࡧࡦࠩ侼")
	l111111lll1_l1_ = l1l1l1_l1_ (u"ࠨࡃ࡙࠾ࠥ࠭侽")+l1ll11l1lll_l1_(32)+type
	succeeded = l11l1ll1111_l1_(l111111lll1_l1_,message,True,l1l1l1_l1_ (u"ࠩࠪ侾"),l1l1l1_l1_ (u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡖࡕࡈࡖࡘ࠭便"),text)
	#	url = l1l1l1_l1_ (u"ࠫࡲࡿࠠࡂࡒࡌࠤࡦࡴࡤ࠰ࡱࡵࠤࡘࡓࡔࡑࠢࡶࡩࡷࡼࡥࡳࠩ俀")
	#	payload = l1l1l1_l1_ (u"ࠬࢁࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣ࠼ࠥࡑ࡞ࠦࡁࡑࡋࠣࡏࡊ࡟ࠢ࠭ࠤࡷࡳࠧࡀ࡛ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࡞࠮ࠥࡷࡪࡴࡤࡦࡴࠥ࠾ࠧࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠦ࠱ࠨࡳࡶࡤ࡭ࡩࡨࡺࠢ࠻ࠤࡉࡶࡴࡳࠠࡂࡴࡤࡦ࡮ࡩࠠࡗ࡫ࡧࡩࡴࡹࠢ࠭ࠤࡷࡩࡽࡺ࡟ࡣࡱࡧࡽࠧࡀࠢࠨ俁")+message+l1l1l1_l1_ (u"࠭ࠢࡾࠩ係")
	#	#auth=(l1l1l1_l1_ (u"ࠢࡢࡲ࡬ࠦ促"), l1l1l1_l1_ (u"ࠣ࡯ࡼࠤࡵ࡫ࡲࡴࡱࡱࡥࡱࠦࡡࡱ࡫ࠣ࡯ࡪࡿࠢ俄")),
	#	import requests
	#	response = requests.request(l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ俅"),url, data=payload, headers=l1l1l1_l1_ (u"ࠪࠫ俆"), auth=l1l1l1_l1_ (u"ࠫࠬ俇"))
	#	response = requests.l1111l_l1_(url, data=payload, headers=l1l1l1_l1_ (u"ࠬ࠭俈"), auth=l1l1l1_l1_ (u"࠭ࠧ俉"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ俊"),l1l1l1_l1_ (u"ࠨࠩ俋"),l1l1l1_l1_ (u"ࠩࠪ俌"),l1l1l1_l1_ (u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭俍"))
	#	else:
	#		DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ俎"),l1l1l1_l1_ (u"ࠬ࠭俏"),l1l1l1_l1_ (u"࠭ฮุลࠣๅ๏ࠦวๅวิืฬ๊ࠧ俐"),l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࡻࡾ࠼ࠣࡿࠦࡸࡽࠨ俑").format(response.status_code, response.content))
	#	l1l1l1llllll_l1_ = l1l1l1_l1_ (u"ࠨ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠧ俒")
	#	l1l1ll1ll1l1_l1_ = l1l1l1_l1_ (u"ࠩࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠨ俓")
	#	header = l1l1l1_l1_ (u"ࠪࠫ俔")
	#	#header += l1l1l1_l1_ (u"ࠫࡋࡸ࡯࡮࠼ࠣࠫ俕") + l1l1l1llllll_l1_
	#	#header += l1l1l1_l1_ (u"ࠬࡢ࡮ࡕࡱ࠽ࠤࠬ俖") + l1l1l111111l_l1_
	#	#header += l1l1l1_l1_ (u"࠭࡜࡯ࡅࡦ࠾ࠥ࠭俗") + l1l1l111111l_l1_
	#	header += l1l1l1_l1_ (u"ࠧ࡝ࡰࡖࡹࡧࡰࡥࡤࡶ࠽ࠤ๊์ࠠไ๊า๎ࠥอไโ์า๎ํࠦวๅ฻ิฬ๏࠭俘")
	#	server = l1ll1l111lll_l1_.l1l1ll11l11l_l1_(l1l1l1_l1_ (u"ࠨࡵࡰࡸࡵ࠳ࡳࡦࡴࡹࡩࡷ࠭俙"),25)
	#	#server.l1l1lll1l1ll_l1_()
	#	server.l1l1llll111l_l1_(l1l1l1_l1_ (u"ࠩࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫ俚"),l1l1l1_l1_ (u"ࠪࡴࡦࡹࡳࡸࡱࡵࡨࠬ俛"))
	#	response = server.l1ll11111lll_l1_(l1l1l1llllll_l1_,l1l1ll1ll1l1_l1_, header + l1l1l1_l1_ (u"ࠫࡡࡴࠧ俜") + message)
	#	server.quit()
	return
def l1ll111ll1ll_l1_():
	text = l1l1l1_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩ保")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ俞"),l1l1l1_l1_ (u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧ俟"),text,l1l1l1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ俠"))
	text = l1l1l1_l1_ (u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬ信")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ俢"),l1l1l1_l1_ (u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩ俣"),text,l1l1l1_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ俤"))
	return
def l1l1lll1llll_l1_(addon_id):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ俥"),l1l1l1_l1_ (u"ࠧࠨ俦"),l1l1l1_l1_ (u"ࠨࠩ俧"),addon_id)
	result = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ俨")+addon_id+l1l1l1_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩ俩"))
	refresh = True
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡰࡴࡴࡸࡴࠡࡵ࡫ࡹࡹ࡯࡬ࠋࠋࡻࡦࡲࡩࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡾࡢ࡮ࡥࡩࡳࡱࡪࡥࡳ࠮ࠪࡥࡩࡪ࡯࡯ࡵࠪ࠰ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠯ࠊࠊ࡫ࡩࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳࡫ࡸࡪࡵࡷࡷ࠭ࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠩ࠻ࠌࠌࠍࡸ࡮ࡵࡵ࡫࡯࠲ࡷࡳࡴࡳࡧࡨࠬࡽࡨ࡭ࡤࡨ࡬ࡰࡪ࠯ࠊࠊࠋࡵࡩ࡫ࡸࡥࡴࡪࠣࡁ࡚ࠥࡲࡶࡧࠍࠍࡺࡹࡥࡳࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡧࡤࡥࡱࡱࡷࠬ࠲ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪࠌࠌ࡭࡫ࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨࡶࡵࡨࡶ࡫࡯࡬ࡦࠫ࠽ࠎࠎࠏࡳࡩࡷࡷ࡭ࡱ࠴ࡲ࡮ࡶࡵࡩࡪ࠮ࡵࡴࡧࡵࡪ࡮ࡲࡥࠪࠌࠌࠍࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡃࠠࡕࡴࡸࡩࠏࠏࠣࡪ࡯ࡳࡳࡷࡺࠠࡴࡳ࡯࡭ࡹ࡫࠳ࠋࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡦࡪࡤࡰࡰࡶࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡧࡤࡥࡱࡱࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࠣࡤࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡶࡪࡶ࡯ࡴ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠧࠨࠢ俪")
	if refresh:
		time.sleep(1)
		xbmc.executebuiltin(l1l1l1_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ俫"))
		time.sleep(1)
	return
def l1l1l111l1ll_l1_(l1ll1ll111l1_l1_):
	import os
	for root,dirs,files in os.walk(l1ll1ll111l1_l1_,topdown=False):
		for name in files:
			try: os.remove(os.path.join(root,name))
			except: pass
	for name in dirs: os.rmdir(os.path.join(root,name))
	return
def l1ll1111llll_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ俬"),l1l1l1_l1_ (u"ࠧࠨ俭"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ修"),l1l1l1_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧ俯"))
	l1ll111l111l_l1_()
	return
def l1ll111l11l1_l1_():
	#	l1ll1lll_l1_://l11l1ll11ll_l1_.tv/download/849
	#   l1ll1lll_l1_://play.l1lll1ll1l1l_l1_.l1lll1l11_l1_/l1l1ll1l111l_l1_/l1l1ll1ll11l_l1_/l1ll1lll1l11_l1_?id=l111l1ll1l_l1_.xbmc.l11l1ll11ll_l1_
	#	http://mirror.l1ll1111l1l1_l1_.l1ll1l11l1l1_l1_.l1ll1l1ll1l1_l1_/l1ll111111ll_l1_/xbmc/l1l1ll11ll1l_l1_/l1l1l111l111_l1_/l1ll11111ll1_l1_
	#	http://l1l1l1ll111l_l1_.l1l1l11ll111_l1_.l1ll1l1ll1l1_l1_/l11l1ll11ll_l1_/l1l1ll11ll1l_l1_/l1l1l111l111_l1_/l1ll11111ll1_l1_
	url = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨ俰")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ俱"),url,l1l1l1_l1_ (u"ࠬ࠭俲"),l1l1l1_l1_ (u"࠭ࠧ俳"),l1l1l1_l1_ (u"ࠧࠨ俴"),l1l1l1_l1_ (u"ࠨࠩ俵"),l1l1l1_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬ俶"))
	html = response.content
	l1l1l11l1l11_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩ俷"),html,re.DOTALL)
	l1l1l11l1l11_l1_ = l1l1l11l1l11_l1_[0].split(l1l1l1_l1_ (u"ࠫ࠲࠭俸"))[0]
	l1ll1l1l1l11_l1_ = str(kodi_version)
	#l111ll1l111_l1_ = l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ俹")+l1l1l1_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏฿ๅๅ่ࠢ฽้่ࠥะ์ࠣษฺีวาࠢ࠴࠽ࠥ๎ๅศࠢห฽ิํࠧ俺")+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ俻")
	l111ll1l111_l1_ = l1l1l1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪ俼")+l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ俽")+l1l1l11l1l11_l1_+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ俾")
	l111ll1l111_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ俿")+l1l1l1_l1_ (u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้๋ࠣํࠦ࠺ࠡࠢࠣࠫ倀")+l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ倁")+l1ll1l1l1l11_l1_+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ倂")
	DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ倃"),l1l1l1_l1_ (u"ࠩࠪ倄"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭倅"),l111ll1l111_l1_)
	return
def l1l1l1ll1l1l_l1_():
	# l1ll1lll_l1_://l1ll1l1ll1ll_l1_-l1l1l1llll11_l1_-l1l1lll11111_l1_.l1ll111l1l11_l1_.l1lll1l11_l1_/request-l1l1lll11l11_l1_
	# l1ll1lll_l1_://l1ll1l1ll1ll_l1_-l1l1l1llll11_l1_-l1l1lll11111_l1_.l1ll111l1l11_l1_.l1lll1l11_l1_/query-l1l1l11l1ll1_l1_
	l1llll111l1_l1_,l1llll111ll_l1_,l111ll11lll_l1_,l111ll1l111_l1_,l1ll111l1lll_l1_,l1l1l11lllll_l1_,l1l1ll11l1l1_l1_ = l1l1l1_l1_ (u"ࠫࠬ倆"),l1l1l1_l1_ (u"ࠬ࠭倇"),l1l1l1_l1_ (u"࠭ࠧ倈"),l1l1l1_l1_ (u"ࠧࠨ倉"),l1l1l1_l1_ (u"ࠨࠩ倊"),l1l1l1_l1_ (u"ࠩࠪ個"),l1l1l1_l1_ (u"ࠪࠫ倌")
	payload,l1l1l11l1lll_l1_,l1ll111111l1_l1_,l1l1l111l1l1_l1_ = {l1l1l1_l1_ (u"ࠫࡦ࠭倍"):l1l1l1_l1_ (u"ࠬࡧࠧ倎")},{},[],{}
	url = WEBSITES[l1l1l1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭倏")][1]
	response = OPENURL_REQUESTS_CACHED(l1l1111lll1_l1_,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ倐"),url,payload,l1l1l1_l1_ (u"ࠨࠩ們"),l1l1l1_l1_ (u"ࠩࠪ倒"),l1l1l1_l1_ (u"ࠪࠫ倓"),l1l1l1_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩ倔"))
	html = response.content
	html = html.replace(l1l1l1_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬ倕"),l1l1l1_l1_ (u"࠭ࡕࡔࡃࠪ倖"))
	html = html.replace(l1l1l1_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨ倗"),l1l1l1_l1_ (u"ࠨࡗࡎࠫ倘"))
	html = html.replace(l1l1l1_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩ候"),l1l1l1_l1_ (u"࡙ࠪࡆࡋࠧ倚"))
	html = html.replace(l1l1l1_l1_ (u"ࠫࡘࡧࡵࡥ࡫ࠣࡅࡷࡧࡢࡪࡣࠪ倛"),l1l1l1_l1_ (u"ࠬࡑࡓࡂࠩ倜"))
	html = html.replace(l1l1l1_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ倝"),l1l1l1_l1_ (u"ࠧࡏ࠰ࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ倞"))
	html = html.replace(l1l1l1_l1_ (u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩ借"),l1l1l1_l1_ (u"࡚ࠩ࠲ࡘࡧࡨࡢࡴࡤࠫ倠"))
	html = html.replace(l1l1l1_l1_ (u"ࠪࡣࡤࡥࠧ倡"),l1l1l1_l1_ (u"ࠫࠥࠦࠧ倢"))
	try: l1ll1111111l_l1_ = EVAL(l1l1l1_l1_ (u"ࠬࡲࡩࡴࡶࠪ倣"),html)
	except:
		DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ値"),l1l1l1_l1_ (u"ࠧࠨ倥"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ倦"),l1l1l1_l1_ (u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩ倧"))
		return
	l1ll1l111ll1_l1_,l1ll1l1ll11l_l1_,l1l1ll1llll1_l1_ = l1ll1111111l_l1_
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ倨"),str(l1ll1l111ll1_l1_))
	#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ倩"),str(l1ll1l1ll11l_l1_))
	#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭倪"),str(l1l1ll1llll1_l1_))
	l1l1l111l1l1_l1_ = {}
	for site,l1ll1l11l111_l1_,l1ll11ll11ll_l1_ in l1ll1l1ll11l_l1_:
		l1ll11ll11ll_l1_ = escapeUNICODE(l1ll11ll11ll_l1_)
		l1ll11ll11ll_l1_ = l1ll11ll11ll_l1_.strip(l1l1l1_l1_ (u"࠭ࠠࠨ倫")).strip(l1l1l1_l1_ (u"ࠧࠡ࠰ࠪ倬"))
		l111ll1l111_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭倭")+site+l1l1l1_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭倮")+l1ll11ll11ll_l1_+l1l1l1_l1_ (u"ࠪࡠࡳ࠭倯")
		if l1ll1l11l111_l1_.isdigit():
			l1l1l111l1l1_l1_[site] = int(l1ll1l11l111_l1_)
			if int(l1ll1l11l111_l1_)>100: l1ll1l11l111_l1_ = l1l1l1_l1_ (u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ倰")
			else: l1ll1l11l111_l1_ = l1l1l1_l1_ (u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧ倱")
		if site not in [l1l1l1_l1_ (u"࠭ࡁࡍࡎࠪ倲"),l1l1l1_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ倳"),l1l1l1_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ倴"),l1l1l1_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭倵"),l1l1l1_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ倶")]:
			if   l1ll1l11l111_l1_==l1l1l1_l1_ (u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ倷"): l1llll111l1_l1_ += l1l1l1_l1_ (u"ࠬࠦࠠࠨ倸")+site
			elif l1ll1l11l111_l1_==l1l1l1_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ倹"): l1llll111ll_l1_ += l1l1l1_l1_ (u"ࠧࠡࠢࠪ债")+site
	l1ll1l11l1ll_l1_,l1l1ll111l1l_l1_,l1l1ll11l1ll_l1_ = list(zip(*l1ll1l1ll11l_l1_))
	for site in sorted(l1l111l1lll_l1_):
		if site not in l1ll1l11l1ll_l1_:
			l111ll1l111_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭倻")+site+l1l1l1_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭值")+l1l1l1_l1_ (u"่ࠪฬ๊้ࠦฮาࠫ倽")+l1l1l1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ倾")
			if site not in [l1l1l1_l1_ (u"ࠬࡇࡌࡍࠩ倿"),l1l1l1_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭偀"),l1l1l1_l1_ (u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ偁"),l1l1l1_l1_ (u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ偂"),l1l1l1_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ偃")]: l111ll11lll_l1_ += l1l1l1_l1_ (u"ࠪࠤࠥ࠭偄")+site
	for l1ll11ll11ll_l1_,counts in l1ll1l111ll1_l1_:
		l1ll11ll11ll_l1_ = escapeUNICODE(l1ll11ll11ll_l1_)
		l1ll111l1lll_l1_ += l1ll11ll11ll_l1_+l1l1l1_l1_ (u"ࠫ࠿࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ偅")+str(counts)+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠪ偆")
	l1llll111l1_l1_ = l1llll111l1_l1_.strip(l1l1l1_l1_ (u"࠭ࠠࠨ假"))
	l1llll111ll_l1_ = l1llll111ll_l1_.strip(l1l1l1_l1_ (u"ࠧࠡࠩ偈"))
	l111ll11lll_l1_ = l111ll11lll_l1_.strip(l1l1l1_l1_ (u"ࠨࠢࠪ偉"))
	l111ll1l1l1_l1_ = l1llll111l1_l1_+l1l1l1_l1_ (u"ࠩࠣࠤࠬ偊")+l1llll111ll_l1_
	#l1llll1ll111_l1_  = l1l1l1_l1_ (u"ࠪࡠࡳࡎࡩࡨࡪࡘࡷࡦ࡭ࡥ࠻ࠢ࡞ࠤࠬ偋")+l1llll111l1_l1_+l1l1l1_l1_ (u"ࠫࠥࡣࠧ偌")
	#l1llll1ll111_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮ࡍࡱࡺ࡙ࡸࡧࡧࡦࠢ࠽ࠤࡠࠦࠧ偍")+l1llll111ll_l1_+l1l1l1_l1_ (u"࠭ࠠ࡞ࠩ偎")
	#l1llll1ll111_l1_ += l1l1l1_l1_ (u"ࠧ࡝ࡰࡑࡳ࡚ࡹࡡࡨࡧࠣࠤ࠿࡛ࠦࠡࠩ偏")+l111ll11lll_l1_+l1l1l1_l1_ (u"ࠨࠢࡠࠫ偐")
	l111ll1l11l_l1_  = l1l1l1_l1_ (u"่ࠩ์ฬู่ࠡึ฽่๋ࠥๆ่ษࠣห้ฮั็ษ่ะࠥ๐่ๆࠢส่ออัฮหࠣๅ๏ี๊้้สฮࠥฮฯู้่้ࠣอใๅࠩ偑")+l1l1l1_l1_ (u"ࠪࡠࡳ࠭偒")+l1l1l1_l1_ (u"ࠫํํะศ่ࠢ฽๋อ็ࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๋๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠩ偓")+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ偔")
	l111ll1l11l_l1_ += l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ偕")+l111ll1l1l1_l1_+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭偖")
	l111ll1l11l_l1_ += l1l1l1_l1_ (u"ࠨ็๋ห็฿ࠠๅ็ࠣ๎ูเไࠡษ็ฬึ์วๆฮ้๋ࠣํวࠡ์๋้ࠥอไษษิัฮࠦร๋ࠢไ๎ิ๐่่ษอࠫ偗")+l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ偘")+l1l1l1_l1_ (u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊ࠠไสํีࠥ๎ฬ้ัู้้ࠣไสࠢไ๎ࠥอไษำ้ห๊าࠧ偙")+l1l1l1_l1_ (u"ࠫࡡࡴࠧ做")
	l111ll1l11l_l1_ += l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ偛")+l111ll11lll_l1_+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ停")
	l1ll1l11111l_l1_,l1l1l1ll1lll_l1_,l1ll1111l11l_l1_,l1l1l1l1llll_l1_ = 0,0,0,0
	all = l1l1l111l1l1_l1_[l1l1l1_l1_ (u"ࠧࡂࡎࡏࠫ偝")]
	if l1l1l1_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ偞") in list(l1l1l111l1l1_l1_.keys()): l1ll1l11111l_l1_ = l1l1l111l1l1_l1_[l1l1l1_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ偟")]
	if l1l1l1_l1_ (u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ偠") in list(l1l1l111l1l1_l1_.keys()): l1l1l1ll1lll_l1_ = l1l1l111l1l1_l1_[l1l1l1_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ偡")]
	if l1l1l1_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ偢") in list(l1l1l111l1l1_l1_.keys()): l1ll1111l11l_l1_ = l1l1l111l1l1_l1_[l1l1l1_l1_ (u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ偣")]
	if l1l1l1_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭偤") in list(l1l1l111l1l1_l1_.keys()): l1l1l1l1llll_l1_ = l1l1l111l1l1_l1_[l1l1l1_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ健")]
	videos_count = all-l1ll1l11111l_l1_-l1l1l1ll1lll_l1_-l1ll1111l11l_l1_-l1l1l1l1llll_l1_
	dummy,l1l1llllll11_l1_ = l1l1ll1llll1_l1_[0]
	dummy,l1l1l1l111ll_l1_ = l1l1ll1llll1_l1_[1]
	l1l1ll1ll1ll_l1_ = l1l1llllll11_l1_-l1l1l1l111ll_l1_
	l1l1ll11l1l1_l1_ += l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ偦")+str(l1l1l1l111ll_l1_)+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ偧")+l1l1l1_l1_ (u"ࠫฬู๊ะัࠣห้ำโ๋ไํࠤ้๊รอ้ีอࠥࡀࠠࠨ偨")
	l1l1ll11l1l1_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ偩")+str(l1l1ll1ll1ll_l1_)+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ偪")+l1l1l1_l1_ (u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫ偫")
	l1l1ll11l1l1_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭偬")+str(l1l1llllll11_l1_)+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ偭")+l1l1l1_l1_ (u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫ偮")
	l1l1ll11l1l1_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ偯")+str(len(l1l1ll1llll1_l1_[2:]))+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ偰")+l1l1l1_l1_ (u"ู࠭ะัࠣห้ี่ๅࠢส่ฯ๐ࠠโ์๊หࠥษฬ่ิฬࠤ࠿ࠦ࡜࡯࡞ࡱࠫ偱")
	for country,l1l1llllllll_l1_ in l1l1ll1llll1_l1_[2:]:
		country = escapeUNICODE(country)
		country = country.strip(l1l1l1_l1_ (u"ࠧࠡࠩ偲")).strip(l1l1l1_l1_ (u"ࠨࠢ࠱ࠫ偳"))
		l1l1ll11l1l1_l1_ += country+l1l1l1_l1_ (u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ側")+str(l1l1llllllll_l1_)+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨ偵")
	#l1l1ll11l1l1_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴ࠮ࠨ偶")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ偷")+str(videos_count)+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ偸")+l1l1l1_l1_ (u"ࠧโ์า๎ํํวหࠢสุฯเไหࠢ࠽ࠤࠬ偹")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭偺")+str(l1ll1l11111l_l1_)+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ偻")+l1l1l1_l1_ (u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡสส๎ะ๎ๆࠡ࠼ࠣࠫ偼")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ偽")+str(l1l1l1l1llll_l1_)+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ偾")+l1l1l1_l1_ (u"࠭ืๅสสฮู๊ࠥาใิࠤฬ๊ๅฯษี๊ࠥࡀࠠࠨ偿")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ傀")+str(l1l1l1ll1lll_l1_)+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ傁")+l1l1l1_l1_ (u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭傂")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ傃")+str(l1ll1111l11l_l1_)+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭傄")+l1l1l1_l1_ (u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫ傅")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ傆")+str(len(l1ll1l111ll1_l1_))+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ傇")+l1l1l1_l1_ (u"ࠨัฺฺ๋่ࠥๅฬࠣๅ๏ี๊้้สฮࠥࡀࠠࠨ傈")
	#l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ傉")+l1l1l1_l1_ (u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢื฾้ํว้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣห้฿วๅ็ࠣ๎ํ๋ࠠฤ็ึࠤ࠭อไษษิัฮ࠯ࠧ傊")+l1l1l1_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭傋")
	l1l1l11lllll_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ傌")+l1ll111l1lll_l1_
	l1l1lll11l_l1_(l1l1l1_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭傍"),l1l1l1_l1_ (u"ฺࠧัาࠤฬ๊รอ้ีอࠥอไห์ࠣหุะฮะ็อࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦวๅ฻ส่๊๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ傎"),l1l1ll11l1l1_l1_,l1l1l1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ傏"))
	#l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ傐"),l1l1l1_l1_ (u"ࠪะ๊๐ู้ࠡำ๋ࠥอไฤำๅห๊ࠦสฯืࠣวุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣࠤๆ่ืࠡ์๋้ࠥษๅิࠢࠫห้ฮวาฯฬ࠭ࠬ傑"),l1l1l11lllll_l1_,l1l1l1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ傒"))
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ傓"),l1l1l1_l1_ (u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦวๅ฻ส่๊๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ傔"),l1l1l11lllll_l1_,l1l1l1_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ傕"))
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ傖"),l1l1l1_l1_ (u"่ࠩ์ฬู่ࠡษืฮ฿๊สࠡ์๋้ࠥอไษษิัฮࠦแ๋ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠫ傗"),l111ll1l11l_l1_,l1l1l1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭傘"))
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ備"),l1l1l1_l1_ (u"ࠬษูๅ๋ࠣห้ี่ๅࠢส่ฯ๐๋๊่ࠠࠤฬ๊ศศำะอࠥอำหะา้ฯࠦวๅสิ๊ฬ๋ฬࠨ傚"),l111ll1l111_l1_,l1l1l1_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ傛"))
	return
def l1l1ll11lll1_l1_():
	message = l1l1l1_l1_ (u"่ࠧาสࠤฬ๊ศา่ส้ัฺ๊ࠦ็็ࠤฬ็ึๅࠢหหุะฮะษ่ࠤั๊ฯࠡๅ๋ำ๏ࠦࠨࡌࡱࡧ࡭࡙ࠥ࡫ࡪࡰࠬࠤฬ๊ะ๋ࠢสื๊ํ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴ࡜࡯๋้๊้ࠢๆࠡฬฮฬ๏ะ็ࠡสสืฯิฯศ็้ࠣำุๆࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫ傜")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ傝"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ傞"),message,l1l1l1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭傟"))
	return
def l1ll11ll1lll_l1_():
	message = l1l1l1_l1_ (u"ࠫฬ๊ัศสฺ๎๋ࠦระ่ส๋ࠥ็๊่็สࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิ่่๊ࠦࠣ฽ออัสࠢ฼๊ࠥะหษ์อࠤ่อๅๅࠢส์ฯ๎ๅศฬํ็๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎ๅฺ้ࠣห฻อแสࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ๎ๅฺ้ࠣห฻อแสࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิ่ࠦๆ฻๊ࠤฬ฼วโห้ࠣำุๆࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧ傠")+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ傡")+l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ傢")+WEBSITES[l1l1l1_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭傣")][0]+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ傤")+WEBSITES[l1l1l1_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ傥")][1]+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ傦")
	message += l1l1l1_l1_ (u"ࠫࡡࡴ࡜࡯࡞ࡱห้ืวษูํ๊ࠥษฯ็ษ๊ࠤ์๋วࠡษ็ืํืำࠡษ็ิ๏๊ࠦฮฬสะ์ࠦๅะ์ิࠤ๊๊แศฬࠣ็ํี๊ࠡๆอฯอ๐สࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศศๆฺี๏่ษࠡษ็ฮ็๊๊ะ์ฬࠤฬ๊โะ์่อࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ傧")+WEBSITES[l1l1l1_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭储")][0]+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ傩")+WEBSITES[l1l1l1_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ傪")][1]+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ傫")
	message += l1l1l1_l1_ (u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬ催")+l1l1l1_l1_ (u"ࠪࡠࡳ࠭傭")+l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ傮")+WEBSITES[l1l1l1_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ傯")][0]+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ傰")
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ傱"),l1l1l1_l1_ (u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ傲"),message,l1l1l1_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ傳"))
	return
def l1ll11ll1l1l_l1_(l1ll11lll1l1_l1_):
	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩ傴")+l1ll11lll1l1_l1_+l1l1l1_l1_ (u"ࠫ࠮࠭債"), True)
	return
def l1ll11l1ll11_l1_():
	l1ll1l1ll_l1_(l1l1l1_l1_ (u"ࠬࡹࡴࡰࡲࠪ傶"))
	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧ傷"))
	return
def l1l1ll1lll1l_l1_():
	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭傸"), True)
	return
def l1ll111l1ll1_l1_(showDialogs=True):
	if not showDialogs: yes = True
	else: yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ傹"),l1l1l1_l1_ (u"ࠩࠪ傺"),l1l1l1_l1_ (u"ࠪࠫ傻"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ傼"),l1l1l1_l1_ (u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥอไร่ࠣรࠬ傽"))
	if yes==1:
		xbmc.executebuiltin(l1l1l1_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩ傾"))
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ傿"),l1l1l1_l1_ (u"ࠨࠩ僀"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ僁"),l1l1l1_l1_ (u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤ๊ิา็ࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨ僂"))
		#settings.setSetting(l1l1l1_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ僃"),l1l1l1_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨ僄"))
		xbmc.executebuiltin(l1l1l1_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ僅"))
	l1l1ll11ll1_l1_ = (not yes)
	return l1l1ll11ll1_l1_
def l1l1ll1111l1_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ僆"),l1l1l1_l1_ (u"ࠨࠩ僇"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ僈"),l1l1l1_l1_ (u"ู่๊ࠪอࠡ็ะฮํ๐วหࠢๅหห๋ษࠡ࠰ࠣหีํศࠡว็ํࠥอไใษษ้ฮࠦวๅฬํࠤฯื๊ะ่ࠢืาํว๊ࠡ็หࠥะฯฯๆࠣษ้๐็ศ๋่่ࠢ์ࠠษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬ僉"))
	return
def l1ll11l111ll_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ僊"),l1l1l1_l1_ (u"ࠬ࠭僋"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ僌"),l1l1l1_l1_ (u"ࠧๅๆอ฽ฬ๋ไࠡ็฼ࠤฬ๊ๅโุ็อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่ึอศุࠢส่ี๐ࠠหำํำࠥหึศใอ๋ࠥษ่ࠡ็ึั์ࠦๅ็ࠢࠣๆฬฬๅสࠢส่๊็ึๅหࠣ์้้ๆࠡๆสࠤฯ฼ฺุࠢ฼่๏ํ้ࠠๆสࠤฯฺฺๅ้ࠣ࠲ࠥ๎ศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊ࠡฦ้ฬࠦศศีอาิอๅࠡࠤส่่๐ศ้ำาࠦࠥ็วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊้ࠡๅุࠦวๅๅ็ห๊่ࠦศๆฺี๏่ษࠡ฻้ำࠥอไห฻ส้้ࠦๅฺ่ࠢัฯ๎๊ศฬࠣๆํอฦๆࠢส่๊็ึๅหࠪ働"))
	return
#l1ll11llll1l_l1_ 	  required	and l1ll11llll1l_l1_     installed	and		not l1l1ll11ll1_l1_		ignore
#l1ll11llll1l_l1_ not required	and	l1ll11llll1l_l1_ not installed 	and 	    l1l1ll11ll1_l1_		ignore
#l1ll11llll1l_l1_ not required	and	l1ll11llll1l_l1_ not installed 	and 	not l1l1ll11ll1_l1_		ignore
#l1ll11llll1l_l1_ not required	and	l1ll11llll1l_l1_     installed 	and 	not l1l1ll11ll1_l1_		ignore
#l1ll11llll1l_l1_     required	and	l1ll11llll1l_l1_ not installed 	and 	    l1l1ll11ll1_l1_		l11l1ll111_l1_ l1l1l1ll1lll_l1_	l1ll111ll111_l1_
#l1ll11llll1l_l1_     required	and	l1ll11llll1l_l1_ not installed 	and 	not l1l1ll11ll1_l1_		l11l1ll111_l1_ l1l1l1ll1lll_l1_	l1ll111ll111_l1_
#l1ll11llll1l_l1_     required 	and l1ll11llll1l_l1_     installed 	and 	    l1l1ll11ll1_l1_		l11l1ll111_l1_ l1ll1l1l11ll_l1_	l1ll111ll111_l1_
#l1ll11llll1l_l1_ not required	and	l1ll11llll1l_l1_     installed 	and 	    l1l1ll11ll1_l1_		l11l1ll111_l1_ l1ll1l1l11ll_l1_	l1ll111ll111_l1_
#cond1: required and not installed: l11l1ll111_l1_ l1l1l1ll1lll_l1_
#cond2: installed and l11l1ll111_l1_ update: l11l1ll111_l1_ l1ll1l1l11ll_l1_
def l1ll11l11ll1_l1_(showDialogs=True):
	l1lll111l1l1_l1_ = l1l1lll1lll1_l1_([l1l1l1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ僎")])
	l1ll1111l111_l1_ = []
	for addon_id in [l1l1l1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ像")]:
		if addon_id not in list(l1lll111l1l1_l1_.keys()): continue
		l1l1ll11ll1_l1_,l1l1l1llll1_l1_,l1l1l111ll1l_l1_,l1ll11l11111_l1_,l1ll111lll11_l1_,l1l1l11ll1l1_l1_,l1ll111llll1_l1_ = l1lll111l1l1_l1_[addon_id]
		if not l1l1l1llll1_l1_ or (l1l1l1llll1_l1_ and l1l1ll11ll1_l1_): l1ll1111l111_l1_.append(addon_id)
	l1l1l1111l11_l1_ = len(l1ll1111l111_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1ll11l111l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1ll11l11lll_l1_ = []
	for addon_id in l1ll1ll1111l_l1_:
		cc.execute(l1l1l1_l1_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࠤ࠴ࠦࠥࡧ࡮ࡥࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ僐")+addon_id+l1l1l1_l1_ (u"ࠫࠧࠦ࠻ࠨ僑"))
		rows = cc.fetchall()
		if rows: l1ll11l11lll_l1_.append(addon_id)
	l1l1ll1l1ll1_l1_ = len(l1ll11l11lll_l1_)>0
	for addon_id in l1ll11l1111l_l1_:
		cc.execute(l1l1l1_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ僒")+addon_id+l1l1l1_l1_ (u"࠭ࠢࠡ࠽ࠪ僓"))
		l1ll1ll111ll_l1_ = cc.fetchall()
		if l1ll1ll111ll_l1_ and l1l1l1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ僔") not in str(l1ll1ll111ll_l1_): l1ll1111l111_l1_.append(addon_id)
	l1l1l1lll1l1_l1_ = len(l1ll1111l111_l1_)>0
	l1ll1111l111_l1_ = list(set(l1ll1111l111_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ僕"),l1l1l1_l1_ (u"ࠩࡱࡩࡪࡪ࡟ࡧ࡫ࡻ࡭ࡳ࡭࡟ࡳࡧࡳࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠢࠪ僖")+str(l1l1l1111l11_l1_))
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ僗"),l1l1l1_l1_ (u"ࠫࡳ࡫ࡥࡥࡡࡧࡩࡱ࡫ࡴࡪࡰࡪࡣࡴࡲࡤࡠࡣࡧࡨࡴࡴࡳ࠻ࠢࠣࠫ僘")+str(l1l1ll1l1ll1_l1_))
	#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭僙"),l1l1l1_l1_ (u"࠭࡮ࡦࡧࡧࡣ࡫࡯ࡸࡪࡰࡪࡣࡴࡸࡩࡨ࡫ࡱ࠾ࠥࠦࠧ僚")+str(l1l1l1lll1l1_l1_))
	l1l1ll11ll1_l1_ = False
	if l1l1ll1l1ll1_l1_ or l1l1l1lll1l1_l1_:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ僛"),l1l1l1_l1_ (u"ࠨࠩ僜"),l1l1l1_l1_ (u"ࠩࠪ僝"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭僞"),l1l1l1_l1_ (u"ࠫฬ๊ศา่ส้ั่ࠦอัู้้ࠣไสࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴࠮࠯ࠢๅำࠥ๐ใ้่้ࠣ฾฽ไࠡล๋ࠤ้อ๋ࠠ฻่่ࠥฮี้ำฬࠤฺำ๊ฮหࠣࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦวๅฤ้ࠤฤࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ僟"))
		if yes==1:
			l1ll1l11ll1l_l1_ = True
			if l1l1l1111l11_l1_:
				l1ll1l11ll1l_l1_ = l1ll1l1l1l1l_l1_(False)
			l1l1l1l1l111_l1_ = True
			if l1l1ll1l1ll1_l1_:
				for addon_id in l1ll11l11lll_l1_: l1l1lll1llll_l1_(addon_id)
				l1l1l1l1l111_l1_ = True
			l1l1lll11lll_l1_ = True
			if l1l1l1lll1l1_l1_:
				conn = sqlite3.connect(l1ll11l111l1_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1ll1111l111_l1_:
					if l1l1l1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࠨ僠") in addon_id: l1ll1ll111ll_l1_ = addon_id
					else: l1ll1ll111ll_l1_ = l1l1l1_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ僡")
					try: cc.execute(l1l1l1_l1_ (u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫ僢")+l1ll1ll111ll_l1_+l1l1l1_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ僣")+addon_id+l1l1l1_l1_ (u"ࠩࠥࠤࡀ࠭僤"))
					except: l1l1lll11lll_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l1l1l1_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ僥"))
			time.sleep(1)
			if l1ll1l11ll1l_l1_ or l1l1l1l1l111_l1_ or l1l1lll11lll_l1_:
				l1l1ll11ll1_l1_ = False
				DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ僦"),l1l1l1_l1_ (u"ࠬ࠭僧"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ僨"),l1l1l1_l1_ (u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢอๅ฾๐ไ๊ࠡศู้ออࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้าๅ๋฻ࠣษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭僩"))
			else:
				l1l1ll11ll1_l1_ = True
				DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ僪"),l1l1l1_l1_ (u"ࠩࠪ僫"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭僬"),l1l1l1_l1_ (u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠฦื็หาࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ僭"))
	elif showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭僮"),l1l1l1_l1_ (u"࠭ࠧ僯"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ僰"),l1l1l1_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦอัู้้ࠣไสࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ僱"))
	return l1l1ll11ll1_l1_
def l1l1l1lll111_l1_():
	l1l1ll1l11l1_l1_,l1ll1l1111l1_l1_,l1l1l11l11ll_l1_ = False,l1l1l1_l1_ (u"ࠩࠪ僲"),l1l1l1_l1_ (u"ࠪࠫ僳")
	l1ll11lllll1_l1_,l1l1lll1l111_l1_,l1l1lllll1ll_l1_ = False,l1l1l1_l1_ (u"ࠫࠬ僴"),l1l1l1_l1_ (u"ࠬ࠭僵")
	l1lll111l1l1_l1_ = l1l1lll1lll1_l1_([l1l1l1_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ僶"),l1l1l1_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ僷"),l1l1l1_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ僸")])
	for addon_id in [l1l1l1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ價"),l1l1l1_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ僺"),l1l1l1_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ僻")]:
		if addon_id not in list(l1lll111l1l1_l1_.keys()): continue
		l1l1ll11ll1_l1_,l1l1l1llll1_l1_,l1l1ll1l11l_l1_,l1l1llll1ll_l1_,l1l1lllll11_l1_,l1ll1l1ll111_l1_,l1l1lllllll_l1_ = l1lll111l1l1_l1_[addon_id]
		if addon_id==l1l1l1_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ僼"):
			l1ll11lllll1_l1_ = l1l1ll11ll1_l1_
			l1l1lll1l111_l1_ = l1l1l1_l1_ (u"࠭ࠨࠨ僽")+l1l1l1llll1_l1_+l1l1l1_l1_ (u"ࠧࠡࠩ僾")+TRANSLATE(l1ll1l1ll111_l1_)+l1l1l1_l1_ (u"ࠨࠫࠪ僿")
			l1l1lllll1ll_l1_ = l1l1llll1ll_l1_
		elif addon_id==l1l1l1_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ儀"):
			l1l1ll1l11l1_l1_ = l1l1ll1l11l1_l1_ or l1l1ll11ll1_l1_
			l1ll1l1111l1_l1_ += l1l1l1_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠪࠪ儁")+l1l1l1llll1_l1_+l1l1l1_l1_ (u"ࠫࠥ࠭儂")+TRANSLATE(l1ll1l1ll111_l1_)+l1l1l1_l1_ (u"ࠬ࠯ࠧ儃")
			l1l1l11l11ll_l1_ += l1l1l1_l1_ (u"࠭ࠠࠡ࠮ࠣࠤࠬ億")+l1l1llll1ll_l1_
		elif addon_id==l1l1l1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭儅"):
			l1l1ll1l1111_l1_ = l1l1ll11ll1_l1_
			l1l1ll111lll_l1_ = l1l1l1_l1_ (u"ࠨࠪࠪ儆")+l1l1l1llll1_l1_+l1l1l1_l1_ (u"ࠩࠣࠫ儇")+TRANSLATE(l1ll1l1ll111_l1_)+l1l1l1_l1_ (u"ࠪ࠭ࠬ儈")
			l1l1l1111ll1_l1_ = l1l1llll1ll_l1_
	l1ll1l1111l1_l1_ = l1ll1l1111l1_l1_.strip(l1l1l1_l1_ (u"ࠫࠥࠦࠬࠡࠢࠪ儉"))
	l1l1l11l11ll_l1_ = l1l1l11l11ll_l1_.strip(l1l1l1_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠫ儊"))
	text1  = l1l1l1_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭儋")+l1l1lllll1ll_l1_+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ儌")
	text1 += l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ儍")+l1l1l1_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭儎")+l1l1lll1l111_l1_+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ儏")
	text1 += l1l1l1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ儐")+l1l1l1_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ฮำ่ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ儑")+l1l1l11l11ll_l1_+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ儒")
	text1 += l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ儓")+l1l1l1_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่๊ࠣิา็ࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ儔")+l1ll1l1111l1_l1_+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ儕")
	text1 += l1l1l1_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ儖")+l1l1l1_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ儗")+l1l1l1111ll1_l1_+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ儘")
	text1 += l1l1l1_l1_ (u"࠭࡜࡯ࠩ儙")+l1l1l1_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ儚")+l1l1ll111lll_l1_+l1l1l1_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ儛")
	l1l1ll11ll1_l1_ = (l1ll11lllll1_l1_ or l1l1ll1l11l1_l1_)
	if l1l1ll11ll1_l1_:
		header = l1l1l1_l1_ (u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫ儜")
		text2 = l1l1l1_l1_ (u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅฯิ้ࠤ฾๋วะࠩ儝")
	else:
		header = l1l1l1_l1_ (u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆะี๊ࠥ฿ๅศัࠪ儞")
		text2 = l1l1l1_l1_ (u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧ償")
	text3 = l1l1l1_l1_ (u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬ儠")
	l1l1ll111ll1_l1_ = text1+l1l1l1_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ儡")+text2+l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭儢")+text3
	l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ儣"),header,l1l1ll111ll1_l1_,l1l1l1_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭儤"))
	return
def l1ll11111l11_l1_(showDialogs=True,l1l1l1llll1l_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ儥"),l1l1l1_l1_ (u"ࠬࡋࡍࡂࡆࡢࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ儦"))
	DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ儧"),l1l1l1_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ儨"))
	if showDialogs:
		l1l1l1lll111_l1_()
		l1ll111l11l1_l1_()
	if l1l1l1llll1l_l1_:
		l1l1l1l11ll1_l1_ = l1ll11l11ll1_l1_(False)
		l1l1l1l11l1l_l1_ = l1ll111l1ll1_l1_(showDialogs)
		if not (l1l1l1l11ll1_l1_ or l1l1l1l11l1l_l1_):
			#settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ儩"),l1l1l1_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ優"))
			xbmc.executebuiltin(l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ儫"))
	return
def l1ll1l1l1l1l_l1_(showDialogs=True):
	l1lll111l1l1_l1_ = l1l1lll1lll1_l1_([l1l1l1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭儬")])
	yes,l1ll1l111111_l1_,l1ll1l1lll1l_l1_ = True,True,True
	for addon_id in [l1l1l1_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ儭")]:
		l1l1ll11ll1_l1_,l1l1l1llll1_l1_,l1l1ll1l11l_l1_,l1l1llll1ll_l1_,l1l1lllll11_l1_,l1ll1l1ll111_l1_,l1l1lllllll_l1_ = l1lll111l1l1_l1_[addon_id]
		if l1l1ll11ll1_l1_:
			l1ll1l111111_l1_ = False
			break
	if l1ll1l111111_l1_:
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ儮"),l1l1l1_l1_ (u"ࠧࠨ儯"),l1l1l1_l1_ (u"ࠨใะู๋ࠥฮำ่ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ儰"),l1l1l1_l1_ (u"่ࠩาื์ฺࠠ็สำ๋่ࠥอ๊าࠤ฾์ฯไ๋้ࠢๆ฿ไ๊ࠡฯห์ุࠠๅๆสืฯิฯศ็ࠪ儱"))
		return
	if showDialogs:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ儲"),l1l1l1_l1_ (u"ࠫࠬ儳"),l1l1l1_l1_ (u"ࠬ࠭儴"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ儵"),l1l1l1_l1_ (u"ࠧๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࡡࡴࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢๅำ๏๋ࠠฤ๊้ࠣๆ่่ะࠢฦ์๋ࠥส้ไไࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢศู้ออࠡษ็ู้้ไสࠢส่ว์ࠠภࠩ儶"))
		if yes!=1: return
	if yes==1:
		for addon_id in [l1l1l1_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ儷")]:
			if addon_id not in list(l1lll111l1l1_l1_.keys()): continue
			l1l1ll11ll1_l1_,l1l1l1llll1_l1_,l1l1ll1l11l_l1_,l1l1llll1ll_l1_,l1l1lllll11_l1_,l1ll1l1ll111_l1_,l1l1lllllll_l1_ = l1lll111l1l1_l1_[addon_id]
			succeeded = l1l1ll1111ll_l1_(addon_id,l1l1lllllll_l1_,showDialogs)
			l1ll1l1lll1l_l1_ = l1ll1l1lll1l_l1_ and succeeded
	if showDialogs:
		if l1ll1l1lll1l_l1_: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ儸"),l1l1l1_l1_ (u"ࠪࠫ儹"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ儺"),l1l1l1_l1_ (u"ࠬะๅࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠ࡝ࡰ้ࠣำุๆࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨ儻"))
		else: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ儼"),l1l1l1_l1_ (u"ࠧࠨ儽"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ儾"),l1l1l1_l1_ (u"ࠩ็่ศูแࠡๆ่ࠤ๏ะๅไ่ࠣห้ฮั็ษ่ะ๋ࠥๆࠡวุ่ฬำࠠๆึๆ่ฮࡢ࡮ࠡ็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭儿"))
	return l1ll1l1lll1l_l1_
	#settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ兀"),l1l1l1_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ允"))
	#xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ兂")+sys.argv[0]+l1l1l1_l1_ (u"࠭࠿࡮ࡱࡧࡩࡂ࠸࠶࠱ࠩ元")+l1l1l1_l1_ (u"ࠢࠪࠤ兄"))
	#xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ充"))
def l1l1ll1111ll_l1_(addon_id,l1l1lllllll_l1_,showDialogs=True):
	succeeded = False
	if showDialogs:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࠪ兆"),l1l1l1_l1_ (u"ࠪࠫ兇"),l1l1l1_l1_ (u"ࠫࠬ先"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ光"),l1l1l1_l1_ (u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฻เุ่ࠢ็่ส฼วโหࠣห้๋ืๅ๊หอ๊ࠥใ๋ࠢํฮ๊ࠦสฬสํฮ์ูࠦๅ๋ࠣ็ํี๊ࠡ࠰ࠣห้๋ไโࠢๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡษ็ฦ๋ࠦฟࠢࠩ兊"))
		if yes!=1: return False
	l1l1l11l111l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1lllllll_l1_)
	if l1l1l11l111l_l1_:
		import zipfile,io
		l1l1lll11l1l_l1_ = io.BytesIO(l1l1l11l111l_l1_)
		zf = zipfile.ZipFile(l1l1lll11l1l_l1_)
		zf.extractall(l1l1l1ll1l11_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ克"))
		time.sleep(1)
		result = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ兌")+addon_id+l1l1l1_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ免"))
		if l1l1l1_l1_ (u"ࠪࡓࡐ࠭兎") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ兏"),l1l1l1_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭児"))
	if showDialogs:
		if succeeded: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ兑"),l1l1l1_l1_ (u"ࠧࠨ兒"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ兓"),l1l1l1_l1_ (u"ࠩอ้ࠥฮๆอษะࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭兔"))
		else: DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ兕"),l1l1l1_l1_ (u"ࠫࠬ兖"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ兗"),l1l1l1_l1_ (u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ兘"))
	return succeeded
	l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍࠨ࡯࡭ࡱࡱࡵࡸࠥࡹࡱ࡭࡫ࡷࡩ࠸ࠐࠉࡤࡱࡱࡲࠥࡃࠠࡴࡳ࡯࡭ࡹ࡫࠳࠯ࡥࡲࡲࡳ࡫ࡣࡵࠪࡤࡨࡩࡵ࡮ࡴࡡࡧࡦ࡫࡯࡬ࡦࠫࠍࠍࡨࡵ࡮࡯࠰ࡷࡩࡽࡺ࡟ࡧࡣࡦࡸࡴࡸࡹࠡ࠿ࠣࡷࡹࡸࠊࠊࡥࡦࠤࡂࠦࡣࡰࡰࡱ࠲ࡨࡻࡲࡴࡱࡵࠬ࠮ࠐࠉࡤࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨ࡛ࠬࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠥࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠧࠪࠌࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠧࠨࠢ兙")
def l1ll1111ll11_l1_(addon_id,showDialogs=True):
	if showDialogs==l1l1l1_l1_ (u"ࠨࠩ党"): showDialogs = True
	#l1ll1l111l11_l1_ = xbmc.getCondVisibility(l1l1l1_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠬ兛")+addon_id+l1l1l1_l1_ (u"ࠪ࠭ࠬ兜"))
	l1ll11l1l11l_l1_ = l1l1l1ll11ll_l1_([addon_id])
	l1ll11l11l1l_l1_,l1ll1l111l11_l1_ = l1ll11l1l11l_l1_[addon_id]
	if l1ll1l111l11_l1_:
		succeeded = True
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ兝"),l1l1l1_l1_ (u"ࠬ࠭兞"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ兟"),l1l1l1_l1_ (u"ࠧโฯุࠤฬ๊ลืษไอࠥࡢ࡮ࠡࠩ兠")+addon_id+l1l1l1_l1_ (u"ࠨࠢ࡟ࡲࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ็๋ะํีษ๊่ࠡๅ฾๊ษ๊ࠡฯห์ุษࠡๆ็หุะฮะษ่ࠫ兡"))
	else:
		succeeded = False
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ兢"),l1l1l1_l1_ (u"ࠪࠫ兣"),l1l1l1_l1_ (u"ࠫࠬ兤"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ入"),l1l1l1_l1_ (u"࠭ࠧ兦")+addon_id+l1l1l1_l1_ (u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ࠲ࠥ๐ฬษࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๊ࠥใ๋ࠢํ฽๊๊ࠠศๆหี๋อๅอࠢ฼๊ิ้ࠠษื๋ีฮࠦีฮ์ะอࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊่ࠠา๊ࠤฬ๊ลืษไอࠥอไร่ࠣรࠬ內"))
		if yes==1:
			xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨ全")+addon_id+l1l1l1_l1_ (u"ࠩࠬࠫ兩"))
			time.sleep(1)
			xbmc.executebuiltin(l1l1l1_l1_ (u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ兪"))
			time.sleep(1)
			while xbmc.getCondVisibility(l1l1l1_l1_ (u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨ八")): time.sleep(1)
			result = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ公")+addon_id+l1l1l1_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫ六"))
			if l1l1l1_l1_ (u"ࠧࡐࡍࠪ兮") in result:
				succeeded = True
				if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ兯"),l1l1l1_l1_ (u"ࠩࠪ兰"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭共"),l1l1l1_l1_ (u"ࠫฯ๋ࠠโฯุࠤศ๎ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪ兲"))
			elif showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭关"),l1l1l1_l1_ (u"࠭ࠧ兴"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ兵"),l1l1l1_l1_ (u"ࠨใื่ࠥ็๊ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯࠠ࠯๋ࠢห้ำไ้๋ࠡࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๆ่ࠣาฬืฬࠡษ็ฬึ์วๆฮࠪ其"))
	return succeeded
def l1l1lll11ll1_l1_(addon_id,showDialogs=True):
	l1lll111l1l1_l1_ = l1l1lll1lll1_l1_([addon_id])
	if addon_id not in list(l1lll111l1l1_l1_.keys()): return False
	l1l1ll11ll1_l1_,l1l1l1llll1_l1_,l1l1ll1l11l_l1_,l1l1llll1ll_l1_,l1l1lllll11_l1_,l1ll1l1ll111_l1_,l1l1lllllll_l1_ = l1lll111l1l1_l1_[addon_id]
	succeeded,l1ll111ll1l1_l1_ = False,l1l1l1_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ具")
	if l1ll1l1ll111_l1_==l1l1l1_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ典"):
		succeeded = True
		l1ll111ll1l1_l1_ = l1l1l1_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ兹")
	elif l1ll1l1ll111_l1_==l1l1l1_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ兺"):
		succeeded = False
		result = xbmc.executeJSONRPC(l1l1l1_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ养")+addon_id+l1l1l1_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ兼"))
		if l1l1l1_l1_ (u"ࠨࡑࡎࠫ兽") in result: succeeded = True
		if succeeded: l1ll111ll1l1_l1_ = l1l1l1_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪ兾")
	elif l1ll1l1ll111_l1_==l1l1l1_l1_ (u"ࠪࡳࡱࡪࠧ兿"):
		succeeded = l1l1ll1111ll_l1_(addon_id,l1l1lllllll_l1_,showDialogs)
		if succeeded: l1ll111ll1l1_l1_ = l1l1l1_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬ冀")
	elif l1ll1l1ll111_l1_==l1l1l1_l1_ (u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭冁"):
		l1l1lll1ll11_l1_ = l1ll1l1l1l1l_l1_(showDialogs)
		if l1l1lll1ll11_l1_:
			succeeded = l1ll1111ll11_l1_(addon_id,showDialogs)
			if succeeded: l1ll111ll1l1_l1_ = l1l1l1_l1_ (u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ冂")
	l1l1l11lll1l_l1_ = l1l1llll1ll_l1_
	return succeeded,l1ll111ll1l1_l1_,l1l1l11lll1l_l1_
def l1ll1111l1ll_l1_(l1ll11l1lll1_l1_=l1l1l1_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭冃"),showDialogs=True):
	l1l1l11ll1ll_l1_ = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ冄"))
	import json
	data = json.loads(l1l1l11ll1ll_l1_)
	l1l1l11ll11l_l1_ = data[l1l1l1_l1_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ内")][l1l1l1_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ円")]
	if kodi_version<19: l1l1l11ll11l_l1_ = l1l1l11ll11l_l1_.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ冇"))
	if showDialogs:
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬ࠭冈"),l1l1l1_l1_ (u"࠭ࠧ冉"),l1l1l1_l1_ (u"ࠧࠨ冊"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ冋"),l1l1l1_l1_ (u"๊่ࠩࠥะั๋ัࠣฮ฿๐๊าࠢฯ่ิࠦࠧ册")+l1l1l11ll11l_l1_+l1l1l1_l1_ (u"ࠪࠤฬ๊ะ๋่ࠢืฯิฯๆࠢส่ว์ࠠโ์ࠣ็ํี๊ࠡว็ํࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤࠬ再")+l1ll11l1lll1_l1_+l1l1l1_l1_ (u"ࠫࠥลࠡࠨ冎"))
		if yes!=1: return False
	succeeded,l1ll111ll1l1_l1_,l1l1l11lll1l_l1_ = l1l1lll11ll1_l1_(l1ll11l1lll1_l1_,False)
	if succeeded:
		if showDialogs: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭冏"),l1l1l1_l1_ (u"࠭ࠧ冐"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ冑"),l1l1l1_l1_ (u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้าไะࠢส่ัี๊ะ๋๋ࠢํࠦฬศ้ีࠤ้๊วิฬัำฬ๋ࠠ࠯ࠢึ์ๆ๊ࠦห็ࠣห้ศๆࠡฬ฽๎๏ืࠠฦ฻าหิอสࠡๅ๋ำ๏ࠦไไ์ࠣ๎ุะูๆๆࠣห้าไะࠢส่ัี๊ะࠢหำ้อࠠๆ่ࠣห้่ฯ๋็ࠪ冒"))
		result = xbmc.executeJSONRPC(l1l1l1_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭冓")+l1ll11l1lll1_l1_+l1l1l1_l1_ (u"ࠪࠦࢂࢃࠧ冔"))
		if l1l1l1_l1_ (u"ࠫࡔࡑࠧ冕") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l1l1l1_l1_ (u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ冖"))
	elif showDialogs: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ冗"),l1l1l1_l1_ (u"ࠧࠨ冘"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ写"),l1l1l1_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤํะแฺ์็ࠤฬ๊ฬๅัࠣห้๋ืๅ๊หࠫ冚"))
	return succeeded
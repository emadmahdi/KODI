# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫみ")
menu_name = l1l1l1_l1_ (u"ࠬࡥࡌࡓ࡜ࡢࠫむ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨめ"),l1l1l1_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨも"),l1l1l1_l1_ (u"ࠨษ็ห็ูวๆࠩゃ"),l1l1l1_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭や")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l11l11_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l11_l1_(url,text)
	elif mode==704: results = l1ll11_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧゅ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬゆ"),l1l1l1_l1_ (u"ࠬ࠭ょ"),l1l1l1_l1_ (u"࠭ࠧよ"),l1l1l1_l1_ (u"ࠧࠨら"),l1l1l1_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪり"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩる"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪれ"),l1l1l1_l1_ (u"ࠫࠬろ"),709,l1l1l1_l1_ (u"ࠬ࠭ゎ"),l1l1l1_l1_ (u"࠭ࠧわ"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫゐ"))
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ゑ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩを"),l1l1l1_l1_ (u"ࠪࠫん"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫゔ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧゕ")+menu_name+l1l1l1_l1_ (u"࠭ๅๆ์ีࠫゖ"),l1l11l_l1_,701,l1l1l1_l1_ (u"ࠧࠨ゗"),l1l1l1_l1_ (u"ࠨࠩ゘"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ゙ࠫ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ゚ࠪ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭゛")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫ゜"),l1l11l_l1_,701,l1l1l1_l1_ (u"࠭ࠧゝ"),l1l1l1_l1_ (u"ࠧࠨゞ"),l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧゟ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ゠"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬァ")+menu_name+l1l1l1_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪア"),l1l11l_l1_,701,l1l1l1_l1_ (u"ࠬ࠭ィ"),l1l1l1_l1_ (u"࠭ࠧイ"),l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫゥ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨウ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫェ")+menu_name+l1l1l1_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪエ"),l1l11l_l1_,701,l1l1l1_l1_ (u"ࠫࠬォ"),l1l1l1_l1_ (u"ࠬ࠭オ"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨカ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬガ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨキ"),l1l1l1_l1_ (u"ࠩࠪギ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡷࡵࡰࡥࡱࡺࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩク"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫグ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		title = title.replace(l1l1l1_l1_ (u"ࠬࡂࡢ࠿ࠩケ"),l1l1l1_l1_ (u"࠭ࠧゲ")).strip(l1l1l1_l1_ (u"ࠧࠡࠩコ"))
		if title in l1l1ll_l1_: continue
		if l111ll_l1_.endswith(l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠧゴ")): continue
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩサ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬザ")+menu_name+title,l111ll_l1_,704)
	#addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩシ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬジ"),l1l1l1_l1_ (u"࠭ࠧス"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧズ"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨセ"),html,re.DOTALL)
	#for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠩࠪゼ"))
	#block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ソ"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	title = title.replace(l1l1l1_l1_ (u"ࠫࡁࡨ࠾ࠨゾ"),l1l1l1_l1_ (u"ࠬ࠭タ")).strip(l1l1l1_l1_ (u"࠭ࠠࠨダ"))
	#	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧチ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪヂ")+menu_name+title,l111ll_l1_,704)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ッ"),url,l1l1l1_l1_ (u"ࠪࠫツ"),l1l1l1_l1_ (u"ࠫࠬヅ"),l1l1l1_l1_ (u"ࠬ࠭テ"),l1l1l1_l1_ (u"࠭ࠧデ"),l1l1l1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬト"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡴࡲࡰࡪࡃࠢ࡮ࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩド"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪナ"),l1l1l1_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩニ"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨヌ"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠬ࠭ネ"),block)]
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫノ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬハ"),l1l1l1_l1_ (u"ࠨࠩバ"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧパ"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠪ࠾ࠥ࠭ヒ")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫビ"),menu_name+title,l111ll_l1_,701)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩピ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨフ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬブ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨプ"),l1l1l1_l1_ (u"ࠩࠪヘ"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪベ"),menu_name+title,l111ll_l1_,701)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠫࠬペ")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ホ"),l1l1l1_l1_ (u"࠭ࠧボ"),request,url)
	if request==l1l1l1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬポ"):
		url,search = url.split(l1l1l1_l1_ (u"ࠨࡁࠪマ"),1)
		data = l1l1l1_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨミ")+search
		headers = {l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩム"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫメ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪモ"),url,data,headers,l1l1l1_l1_ (u"࠭ࠧャ"),l1l1l1_l1_ (u"ࠧࠨヤ"),l1l1l1_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬュ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ユ"),url,l1l1l1_l1_ (u"ࠪࠫョ"),l1l1l1_l1_ (u"ࠫࠬヨ"),l1l1l1_l1_ (u"ࠬ࠭ラ"),l1l1l1_l1_ (u"࠭ࠧリ"),l1l1l1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫル"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠨࠩレ"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭ロ"))
	if request==l1l1l1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨヮ"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ワ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠬ࠭ヰ"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨヱ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩヲ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧン"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩヴ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧヵ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫヶ"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧヷ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡣࡣࠣࡱ࡬ࡨࠠࡵࡣࡥࡰࡪࠦࡦࡶ࡮࡯ࠦ࠭࠴ࠪࡀࠫࠥࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧ࠭ヸ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ヹ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠨࠩヺ"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ・"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫー"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ฺ๊ࠫว่ัฬࠫヽ"),l1l1l1_l1_ (u"ࠬ็๊ๅ็ࠪヾ"),l1l1l1_l1_ (u"࠭ว฻่ํอࠬヿ"),l1l1l1_l1_ (u"ࠧไๆํฬࠬ㄀"),l1l1l1_l1_ (u"ࠨษ฼่ฬ์ࠧ㄁"),l1l1l1_l1_ (u"๊ࠩำฬ็ࠧ㄂"),l1l1l1_l1_ (u"้ࠪออัศหࠪ㄃"),l1l1l1_l1_ (u"ࠫ฾ืึࠨ㄄"),l1l1l1_l1_ (u"๋ࠬ็าฮส๊ࠬㄅ"),l1l1l1_l1_ (u"࠭วๅส๋้ࠬㄆ"),l1l1l1_l1_ (u"ࠧๆีิั๏ฯࠧㄇ")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠨ࠱ࠪㄈ"))
		#if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧㄉ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬㄊ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭ㄋ"))
		#if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪㄌ") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨㄍ")+img.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩㄎ"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪㄏ"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬㄐ"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄑ"),menu_name+title,l111ll_l1_,702,img)
		elif request==l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪㄒ"):
			addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㄓ"),menu_name+title,l111ll_l1_,702,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬㄔ") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄕ"),menu_name+title,l111ll_l1_,703,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ㄖ") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄗ"),menu_name+title,l111ll_l1_,701,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄘ"),menu_name+title,l111ll_l1_,703,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪㄙ"),l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧㄚ")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㄛ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㄜ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠨࠥࠪㄝ"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫㄞ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬㄟ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㄠ"),menu_name+l1l1l1_l1_ (u"ࠬ฻แฮหࠣࠫㄡ")+title,l111ll_l1_,701)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧㄢ"),l1l1l1_l1_ (u"ࠧࠨㄣ"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬㄤ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ㄥ"),url,l1l1l1_l1_ (u"ࠪࠫㄦ"),l1l1l1_l1_ (u"ࠫࠬㄧ"),l1l1l1_l1_ (u"ࠬ࠭ㄨ"),l1l1l1_l1_ (u"࠭ࠧㄩ"),l1l1l1_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ㄪ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫㄫ"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫㄬ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"ࠪࠫㄭ")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࠬ࠭࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬㄮ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࠨㄯ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"࠭ࠣࠨ㄰"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄱ"),menu_name+title,url,703,img,l1l1l1_l1_ (u"ࠨࠩㄲ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠪ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠮࠴࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ㄳ"),html,re.DOTALL)
	#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫㄴ"),str(l1ll1l1_l1_))
	block = l1ll1l1_l1_[0]
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩㄵ")+l1lll_l1_+l1l1l1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪㄶ"),block,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦࠬㄷ")+l1lll_l1_+l1l1l1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ㄸ"),block,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡧࡁ࡙ࠧࡥࡢࡵࡲࡲࠬㄹ")+l1lll_l1_+l1l1l1_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㄺ"),block,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀ࠿ࡰ࡮ࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠤㄻ"),block,re.DOTALL)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬㄼ"),l1l1l1_l1_ (u"ࠬ࠭ㄽ"),l1l1l1_l1_ (u"࠭ࠧㄾ"),l1l1l1_l1_ (u"ࠧ࠳࠴࠵࠶࠷࠭ㄿ"))
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬㅀ"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨㅁ"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠲࠴࠭ㅂ"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭ㅃ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧㅄ"))
			title = title.replace(l1l1l1_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫㅅ"),l1l1l1_l1_ (u"ࠧࠡࠩㅆ"))
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㅇ"),menu_name+title,l111ll_l1_,702,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪㅈ"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨㅉ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭ㅊ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧㅋ"))
		#		addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬㅌ"),menu_name+title,l111ll_l1_,702,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l11_l1_,l111l11_l1_ = [],[],[]
	url2 = url.replace(l1l1l1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫㅍ"),l1l1l1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫㅎ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ㅏ"),url2,l1l1l1_l1_ (u"ࠪࠫㅐ"),l1l1l1_l1_ (u"ࠫࠬㅑ"),l1l1l1_l1_ (u"ࠬ࠭ㅒ"),l1l1l1_l1_ (u"࠭ࠧㅓ"),l1l1l1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪㅔ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ㅕ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		# l11ll1l1l_l1_ l111ll_l1_
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪㅖ"),block,re.DOTALL)
		if l111ll_l1_:
			l111ll_l1_ = l111ll_l1_[0]
			l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫㅗ"))
			l11l1_l1_.append(l111ll_l1_)
		# l1l1111ll_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠦࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠧㅘ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧㅙ"))
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧㅚ")+title+l1l1l1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨㅛ"))
				l11l1_l1_.append(l111ll_l1_)
		# download l1ll_l1_
		#l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㅜ"),block,re.DOTALL)
		#for l111ll_l1_,title in l1ll_l1_:
		#	if l111ll_l1_ not in l11l1_l1_:
		#		title = title.strip(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬㅝ"))
		#		l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫㅞ")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨㅟ"))
		#		l11l1_l1_.append(l111ll_l1_)
	zzz = zip(l11l1_l1_,l111l1l11_l1_)
	for l111ll_l1_,name in zzz: l111l11_l1_.append(l111ll_l1_+name)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪㅠ"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬㅡ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨㅢ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩㅣ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫㅤ"),l1l1l1_l1_ (u"ࠪ࠯ࠬㅥ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬㅦ")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬㅧ"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪㅨ")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬㅩ"))
	return
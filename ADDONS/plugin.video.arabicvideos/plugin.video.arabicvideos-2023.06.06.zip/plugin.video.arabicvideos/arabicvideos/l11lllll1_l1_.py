# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ༤")
headers = {l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ༥"):l1l1l1_l1_ (u"ࠧࠨ༦")}
menu_name = l1l1l1_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧ༧")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ༨"),l1l1l1_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪ༩"),l1l1l1_l1_ (u"๊ࠫ฻วา฻๊ࠫ༪"),l1l1l1_l1_ (u"ࠬอูๅ่้ࠣ฾์วࠡ⠕ࠣࡊࡴࡸࠠࡢࡦࡶࠫ༫"),l1l1l1_l1_ (u"࠭ๅ้สส๎้อสࠨ༬"),l1l1l1_l1_ (u"ࠧษำส้ัࠦใๆสํ์ฯืࠧ༭"),l1l1l1_l1_ (u"ࠨษ็฽ฬฮࠠไ็ห๎ํะัࠨ༮"),l1l1l1_l1_ (u"ࠩสื้อๅ๋ษอࠫ༯"),l1l1l1_l1_ (u"ࠪหำื้ࠨ༰"),l1l1l1_l1_ (u"ࠫฬ่ำศ็ࠣหำื๊ࠨ༱"),l1l1l1_l1_ (u"ࠬอิหำส็ฬะࠧ༲")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l11l11_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l11l1ll_l1_(url)
	elif mode==254: results = l1111l1_l1_(url,l1l1l1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭༳")+text)
	elif mode==255: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ༴")+text)
	elif mode==256: results = l1ll11_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
headers = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸ༵ࠬ"):l1l1l11ll_l1_()}
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭༶"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯༷ࠩ"),l1l1l1_l1_ (u"ࠫࠬ༸"),headers,l1l1l1_l1_ (u"༹ࠬ࠭"),l1l1l1_l1_ (u"࠭ࠧ༺"),l1l1l1_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ༻"))
	html = response.content
	#l11lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༼"),html,re.DOTALL)
	#if l11lll11_l1_: l11lll11_l1_ = SERVER(l11lll11_l1_[0],l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭༽"))
	#else: l11lll11_l1_ = l1l11l_l1_
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༾"),menu_name+l1l1l1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ༿"),l1l1l1_l1_ (u"ࠬ࠭ཀ"),259,l1l1l1_l1_ (u"࠭ࠧཁ"),l1l1l1_l1_ (u"ࠧࠨག"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬགྷ"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩང"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ཅ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬཆ"),254)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬཇ"),menu_name+l1l1l1_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ཈"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨཉ"),255)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ཊ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩཋ"),l1l1l1_l1_ (u"ࠪࠫཌ"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫཌྷ"),menu_name+l1l1l1_l1_ (u"ࠬอไๆ็ํึฮ࠭ཎ"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬཏ"),251,l1l1l1_l1_ (u"ࠧࠨཐ"),l1l1l1_l1_ (u"ࠨࠩད"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩདྷ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪན"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭པ")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫཕ"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬབ"),251,l1l1l1_l1_ (u"ࠧࠨབྷ"),l1l1l1_l1_ (u"ࠨࠩམ"),l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ཙ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪཚ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ཛ")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫཛྷ"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬཝ"),251,l1l1l1_l1_ (u"ࠧࠨཞ"),l1l1l1_l1_ (u"ࠨࠩཟ"),l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨའ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪཡ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ར")+menu_name+l1l1l1_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬལ"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯࡭ࡣࡷࡩࡸࡺࠧཤ"),251,l1l1l1_l1_ (u"ࠧࠨཥ"),l1l1l1_l1_ (u"ࠨࠩས"),l1l1l1_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪཧ"))
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡪࡴࡵࡉࡧࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬཨ"),html,re.DOTALL)
	l11ll_l1_ = l1ll111_l1_[0]
	l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ཀྵ"),l11ll_l1_,re.DOTALL)
	for l111ll_l1_,title in l1ll1ll_l1_:
		title = unescapeHTML(title)
		if title not in l1l1ll_l1_ and title!=l1l1l1_l1_ (u"ࠬ࠭ཪ"):
			if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫཫ") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			#l111ll_l1_ = l111ll_l1_.rstrip(l1l1l1_l1_ (u"ࠧ࠰ࠩཬ")).replace(SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ཭")),l1l11l_l1_)
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ཮"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ཯")+menu_name+title,l111ll_l1_,256)
	return html
def l1ll11_l1_(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ཰"),l1l1l1_l1_ (u"ཱࠬ࠭"),l1l1l1_l1_ (u"࠭ࡓࡖࡄࡐࡉࡓ࡛ࠠࠡࠢࠣࠤིࠬ")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗཱིࠫ"),url,l1l1l1_l1_ (u"ࠨུࠩ"),headers,l1l1l1_l1_ (u"ཱུࠩࠪ"),l1l1l1_l1_ (u"ࠪࠫྲྀ"),l1l1l1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫཷ"))
	html = response.content
	if l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠧླྀ") in html: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ཹ"),menu_name+l1l1l1_l1_ (u"ࠧศๆฦ็ะืࠠๆึส๋ิฯེࠧ"),url,251,l1l1l1_l1_ (u"ࠨཻࠩ"),l1l1l1_l1_ (u"ོࠩࠪ"),l1l1l1_l1_ (u"ࠪࡱࡴࡹࡴࠨཽ"))
	if l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒࡧࡩ࡯ࡕ࡯࡭ࡩ࡫ࡳࠨཾ") in html: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬཿ"),menu_name+l1l1l1_l1_ (u"࠭วๅ็่๎ืฯྀࠧ"),url,251,l1l1l1_l1_ (u"ࠧࠨཱྀ"),l1l1l1_l1_ (u"ࠨࠩྂ"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫྃ"))
	if l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ྄࠭") in html:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ྅"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			if len(l1ll1l1_l1_)>1 and type==l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ྆"): block = l1ll1l1_l1_[1]
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ྇"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				title2 = re.findall(l1l1l1_l1_ (u"ࠧ࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨྈ"),title,re.DOTALL)
				try: tt1 = title2[0][0]
				except: tt1 = l1l1l1_l1_ (u"ࠨࠩྉ")
				try: tt2 = title2[0][1]
				except: tt2 = l1l1l1_l1_ (u"ࠩࠪྊ")
				title2 = tt1+tt2
				title2 = title2.replace(l1l1l1_l1_ (u"ࠪࡠࡳ࠭ྋ"),l1l1l1_l1_ (u"ࠫࠬྌ"))
				#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭ྍ"),str(title2))
				if l1l1l1_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠨྎ") in title:
					title2 = re.findall(l1l1l1_l1_ (u"ࠧ࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫྏ"),title,re.DOTALL)
					title2 = title2[0]
				if not title2:
					title2 = re.findall(l1l1l1_l1_ (u"ࠨࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ྐ"),title,re.DOTALL)
					title2 = title2[0]
				else:
					if l1l1l1_l1_ (u"ࠩ࡮ࡩࡾࡃࠧྑ") in l111ll_l1_: type = l111ll_l1_.split(l1l1l1_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨྒ"))[1]
					else: type = l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡦࡵࡷࠫྒྷ")
					#l111ll_l1_ = l111ll_l1_.rstrip(l1l1l1_l1_ (u"ࠬ࠵ࠧྔ")).replace(SERVER(l111ll_l1_,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪྕ")),l1l11l_l1_)
					title2 = title2.strip(l1l1l1_l1_ (u"ࠧࠡࠩྖ"))
					addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨྗ"),menu_name+title2,l111ll_l1_,251,l1l1l1_l1_ (u"ࠩࠪ྘"),l1l1l1_l1_ (u"ࠪࠫྙ"),type)
	return
def l11l11_l1_(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬྚ"),l1l1l1_l1_ (u"ࠬ࠭ྛ"),l1l1l1_l1_ (u"࠭ࡔࡊࡖࡏࡉࡘࠦࠠࠡࠢࠣࠫྜ")+type,url)
	method,data,items = l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫྜྷ"),l1l1l1_l1_ (u"ࠨࠩྞ"),[]
	if type==l1l1l1_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪྟ"):
		if l1l1l1_l1_ (u"ࠪࡃࠬྠ") in url:
			method2,data2 = l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩྡ"),{}
			url2,l1l11l11l_l1_ = url.split(l1l1l1_l1_ (u"ࠬࡅࠧྡྷ"))
			lines = l1l11l11l_l1_.split(l1l1l1_l1_ (u"࠭ࠦࠨྣ"))
			for line in lines:
				key,value = line.split(l1l1l1_l1_ (u"ࠧ࠾ࠩྤ"))
				data2[key] = value
			if lines: method,url,data = method2,url2,data2
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l1l1l1_l1_ (u"ࠨࠩྥ"),l1l1l1_l1_ (u"ࠩࠪྦ"),l1l1l1_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩྦྷ"))
	html = response.content
	#html = html[99000:]
	if type==l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬྨ"): l1ll1l1_l1_ = [html]
	elif l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧྩ") in type: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡢ࡫ࡱࡗࡱ࡯ࡤࡦࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪྪ"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫྫ"): l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨฮา๎ิࠦวๅษไ่ฬ๋࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨྫྷ"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨྭ"): l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วห࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵࡍࡳ࡙ࡥࡤࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪྮ"),html,re.DOTALL)
	elif type==l1l1l1_l1_ (u"ࠫࡲࡵࡳࡵࠩྯ"): l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠧྰ"),html,re.DOTALL)
	else: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡂ࡭ࡱࡦ࡯ࡸ࠳ࡕࡍࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡂࡤࡲࡉࡱ࡙ࡥࡦࡦࠥࠫྱ"),html,re.DOTALL)
	if l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩྲ") in type:
		block = l1ll1l1_l1_[0]
		zz = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭࡭ࡣࡽࡽ࠳࠰࠿ࠡࠪࡶࡶࡨࢂࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࠬࡁࠧ࠮࠮ࠫࡁࠬࠦࠬླ"),block,re.DOTALL)
		if zz:
			l11l1_l1_,l1111ll_l1_,l1l11ll1l_l1_,l1l1l1ll1_l1_ = zip(*zz)
			items = zip(l11l1_l1_,l1l1l1ll1_l1_,l1111ll_l1_)
	else:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࡄࡶࡪࡧ࠮ࠫࡁࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡠࡼࢁ࠳࠭࠷ࢀࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ྴ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l111ll_l1_,img,title in items:
		if l1l1l1_l1_ (u"࡛ࠪ࡜ࡋࠧྵ") in title: continue
		#l111ll_l1_ = l111ll_l1_.rstrip(l1l1l1_l1_ (u"ࠫ࠴࠭ྶ")).replace(SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩྷ")),l1l11l_l1_)
		#img = img.rstrip(l1l1l1_l1_ (u"࠭࠯ࠨྸ")).replace(SERVER(img,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫྐྵ")),l1l11l_l1_)
		title = unescapeHTML(title)
		if l1l1l1_l1_ (u"ࠨษ็ั้่ษࠨྺ") in title:
			l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬྻ"),title,re.DOTALL)
			if l1llll1_l1_:
				title = l1l1l1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩྼ") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ྽"),menu_name+title,l111ll_l1_,253,img)
			else: addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ྾"),menu_name+title,l111ll_l1_,252,img)
		elif l1l1l1_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ྿") in l111ll_l1_ or l1l1l1_l1_ (u"ࠧๆี็ื้࠭࿀") in title:
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿁"),menu_name+title,l111ll_l1_,253,img)
		else:
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ࿂"),menu_name+title,l111ll_l1_,252,img)
	if type in [l1l1l1_l1_ (u"ࠪࡲࡪࡽࡥࡴࡶࠪ࿃"),l1l1l1_l1_ (u"ࠫࡧ࡫ࡳࡵࠩ࿄"),l1l1l1_l1_ (u"ࠬࡳ࡯ࡴࡶࠪ࿅")]:
		items = re.findall(l1l1l1_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡳࡻ࡭ࡣࡧࡵࡷࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࿆ࠬ"),html,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l111ll_l1_ = unescapeHTML(l111ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿇"),menu_name+l1l1l1_l1_ (u"ࠨืไัฮࠦࠧ࿈")+title,l111ll_l1_,251,l1l1l1_l1_ (u"ࠩࠪ࿉"),l1l1l1_l1_ (u"ࠪࠫ࿊"),type)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ࿋"),url,l1l1l1_l1_ (u"ࠬ࠭࿌"),headers,l1l1l1_l1_ (u"࠭ࠧ࿍"),l1l1l1_l1_ (u"ࠧࠨ࿎"),l1l1l1_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ࿏"))
	html = response.content
	#items = re.findall(l1l1l1_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡕ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࿐"),html,re.DOTALL)
	# the first 10000 character of the html file is l1l111ll1_l1_ l1l11lll1_l1_ in l1l1l1111_l1_ .. it l1l11ll11_l1_ l1l111l11_l1_
	html = html[10000:]
	items = re.findall(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࿑"),html,re.DOTALL)
	if not items: return
	img,name = items[0]
	if l1l1l1_l1_ (u"ࠫฬ๊อๅไฬࠫ࿒") in name: name = name.split(l1l1l1_l1_ (u"ࠬอไฮๆๅอࠬ࿓"))[0].strip(l1l1l1_l1_ (u"࠭ࠠࠨ࿔"))
	elif l1l1l1_l1_ (u"ࠧฮๆๅอࠬ࿕") in name: name = name.split(l1l1l1_l1_ (u"ࠨฯ็ๆฮ࠭࿖"))[0].strip(l1l1l1_l1_ (u"ࠩࠣࠫ࿗"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷࡋࡰࡪࡵࡲࡨࡪࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࿘"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭࿙"),block,re.DOTALL)
		for l111ll_l1_,l1llll1_l1_ in items:
			title = name+l1l1l1_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡำๅ้ࠥ࠭࿚")+l1llll1_l1_
			#l111ll_l1_ = l111ll_l1_.rstrip(l1l1l1_l1_ (u"࠭࠯ࠨ࿛")).replace(SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ࿜")),l1l11l_l1_)
			#img = img.rstrip(l1l1l1_l1_ (u"ࠨ࠱ࠪ࿝")).replace(SERVER(img,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭࿞")),l1l11l_l1_)
			addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ࿟"),menu_name+title,l111ll_l1_,252,img)
	else: addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ࿠"),menu_name+l1l1l1_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ࿡"),url,252,img)
	return
def l11lll1ll_l1_(title,l111ll_l1_):
	title2 = re.findall(l1l1l1_l1_ (u"࡛࠭ࡢ࠯ࡽࡅ࠲ࡠ࠭࡞࠭ࠪ࿢"),title,re.DOTALL)
	if title2: title = title2[0]
	else: title = title+l1l1l1_l1_ (u"ࠧࠡࠩ࿣")+SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠨࡰࡤࡱࡪ࠭࿤"))
	title = title.replace(l1l1l1_l1_ (u"ࠩ฼ีอࠦำ๋ัࠪ࿥"),l1l1l1_l1_ (u"ࠪࠫ࿦")).replace(l1l1l1_l1_ (u"๊ࠫฮวีำࠪ࿧"),l1l1l1_l1_ (u"ࠬ࠭࿨")).replace(l1l1l1_l1_ (u"࠭ๅีษ๊ำฮ࠭࿩"),l1l1l1_l1_ (u"ࠧࠨ࿪"))
	title = title.replace(l1l1l1_l1_ (u"ࠨ๏ࠪ࿫"),l1l1l1_l1_ (u"ࠩࠪ࿬"))
	title = title.replace(l1l1l1_l1_ (u"ࠪࠤࠥ࠭࿭"),l1l1l1_l1_ (u"ࠫࠥ࠭࿮")).replace(l1l1l1_l1_ (u"ࠬࠦࠠࠨ࿯"),l1l1l1_l1_ (u"࠭ࠠࠨ࿰"))
	return title
def PLAY(url):
	# l1ll1lll_l1_://l11llll1l_l1_.l1l11l111_l1_/فيلم-l1l1111l1_l1_-for-l11lll1l1_l1_-l11ll1lll_l1_-2022-مترجم/
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ࿱"),url,l1l1l1_l1_ (u"ࠨࠩ࿲"),headers,l1l1l1_l1_ (u"ࠩࠪ࿳"),l1l1l1_l1_ (u"ࠪࠫ࿴"),l1l1l1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ࿵"))
	html = response.content
	l11lll11l_l1_,l1l11l1ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠬ࠭࿶"),l1l1l1_l1_ (u"࠭ࠧ࿷"),[]
	# l1l1111ll_l1_ & download l11ll1ll_l1_
	l1l1l1l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡺࡥࡹࡩࡨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱࠮ࡄ࠯ࠢࠨ࿸"),html,re.DOTALL)
	if l1l1l1l1l_l1_: l11lll11l_l1_,type1,l1l11l1ll_l1_,l1l11l1l1_l1_ = l1l1l1l1l_l1_[0]
	else:
		l1l1l1l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡂࡶࡶࡷࡳࡳࡹࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࿹"),html,re.DOTALL)
		if l1l1l1l1l_l1_:
			l111ll_l1_,type1 = l1l1l1l1l_l1_[0]
			if l1l1l1_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ࿺") in type1: l11lll11l_l1_ = l111ll_l1_
			else: l1l11l1ll_l1_ = l111ll_l1_
	server = SERVER(url,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ࿻"))
	#headers = {l1l1l1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ࿼"):server,l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࿽"):l1l1l11ll_l1_()}
	headers[l1l1l1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ࿾")] = server
	if l11lll11l_l1_:
		# l1l1111ll_l1_ l1ll_l1_
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ࿿"),l11lll11l_l1_,l1l1l1_l1_ (u"ࠨࠩက"),headers,l1l1l1_l1_ (u"ࠩࠪခ"),l1l1l1_l1_ (u"ࠪࠫဂ"),l1l1l1_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨဃ"))
		html = response.content
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡩࡷࡇࡲࡦࡣࠥࠬ࠳࠰࠿࠽࠱ࡸࡰࡃ࠯ࠧင"),html,re.DOTALL)
		if l1ll1l1_l1_:
			l11ll1l11_l1_ = l1ll1l1_l1_[0]
			l11ll1l11_l1_ = l11ll1l11_l1_.replace(l1l1l1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬစ"),l1l1l1_l1_ (u"ࠧ࠽ࡪ࠶ࡂࠬဆ"))
			l11ll1l11_l1_ = l11ll1l11_l1_.replace(l1l1l1_l1_ (u"ࠨ࠾࡫࠷ࡃ࠭ဇ"),l1l1l1_l1_ (u"ࠩ࠿࡬࠸ࡄ࠼ࡩ࠵ࡁࠫဈ"))
			l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀ࡭࠹࠾࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼ࡩ࠵ࡁࠫဉ"),l11ll1l11_l1_,re.DOTALL)
			for l11ll111_l1_,block in l1l11l1_l1_:
				items = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨည"),block,re.DOTALL)
				for l111ll_l1_,name in items:
					#name = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠬ࡮࡯ࡴࡶࠪဋ"))
					l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧဌ")+name+l1l1l1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࡠࡡࡢࡣࠬဍ")+l11ll111_l1_
					l11l1_l1_.append(l111ll_l1_)
		# l11ll1l1l_l1_ l111ll_l1_
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩဎ"),html,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࡎ࡬ࡲࡢ࡯ࡨࠦ࠳࠰࠿ࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡋࡉࡎࡍࡈࡕ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪဏ"),html,re.DOTALL)
		if l1ll_l1_:
			l111ll_l1_,l11ll111_l1_ = l1ll_l1_[0]
			name = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠪࡲࡦࡳࡥࠨတ"))
			if l1l1l1_l1_ (u"ࠫࠪ࠭ထ") in l11ll111_l1_: l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ဒ")+name+l1l1l1_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩဓ")
			else: l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨန")+name+l1l1l1_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࡡࡢࡣࡤ࠭ပ")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	if l1l11l1ll_l1_:
		# download l1ll_l1_
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ဖ"),l1l11l1ll_l1_,l1l1l1_l1_ (u"ࠪࠫဗ"),headers,l1l1l1_l1_ (u"ࠫࠬဘ"),l1l1l1_l1_ (u"ࠬ࠭မ"),l1l1l1_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪယ"))
		html = response.content
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡅࡱࡺࡲࡱࡵࡡࡥࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭ရ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨလ"),block,re.DOTALL)
			for l111ll_l1_,title,l11ll111_l1_ in items:
				if not l111ll_l1_: continue
				# l1l111lll_l1_ l11ll1ll1_l1_ by l11llll11_l1_ .. it l1l11llll_l1_ a l1l111111_l1_ from l11llll11_l1_ l1l1l1lll_l1_
				if l1l1l1_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩဝ") in l111ll_l1_: continue
				l111ll_l1_ = UNQUOTE(l111ll_l1_)
				#title = l11lll1ll_l1_(title,l111ll_l1_)
				l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫသ")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬဟ")+l11ll111_l1_
				l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪဠ"), l11l1_l1_)
	l11llllll_l1_ = str(l11l1_l1_)
	l111lll_l1_ = [l1l1l1_l1_ (u"࠭࠮ࡻ࡫ࡳࡃࠬအ"),l1l1l1_l1_ (u"ࠧ࠯ࡴࡤࡶࡄ࠭ဢ"),l1l1l1_l1_ (u"ࠨ࠰ࡷࡼࡹࡅࠧဣ"),l1l1l1_l1_ (u"ࠩ࠱ࡴࡩ࡬࠿ࠨဤ"),l1l1l1_l1_ (u"ࠪ࠲ࡹࡧࡲࡀࠩဥ"),l1l1l1_l1_ (u"ࠫ࠳࡯ࡳࡰࡁࠪဦ"),l1l1l1_l1_ (u"ࠬ࠴ࡺࡪࡲ࠱ࠫဧ"),l1l1l1_l1_ (u"࠭࠮ࡳࡣࡵ࠲ࠬဨ"),l1l1l1_l1_ (u"ࠧ࠯ࡶࡻࡸ࠳࠭ဩ"),l1l1l1_l1_ (u"ࠨ࠰ࡳࡨ࡫࠴ࠧဪ"),l1l1l1_l1_ (u"ࠩ࠱ࡸࡦࡸ࠮ࠨါ"),l1l1l1_l1_ (u"ࠪ࠲࡮ࡹ࡯࠯ࠩာ")]
	if any(value in l11llllll_l1_ for value in l111lll_l1_):
		DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬိ"),l1l1l1_l1_ (u"ࠬ࠭ီ"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩု"),l1l1l1_l1_ (u"ࠧอำหࠤึอศุ่ࠢาฯ๊แࠡๆฦ๊ࠥํะศࠢส่ึอศุࠢ็๎ุࠦๅ็้ࠢ์฾ࠦวๅำ๋หอ฽ࠠศๆอ๎ࠥ็๊่ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡ࠰࠱ࠤ้ษๆ้ࠡำหࠥอไๆ๊ๅ฽ࠥ็๊่ࠢัำ๊อสࠡลัี๎ฺ๋ࠦำ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪူ"))
		return
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧေ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫဲ"),l1l1l1_l1_ (u"ࠪ࠯ࠬဳ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴࡬ࡩ࡯ࡦ࠲ࡃ࡫࡯࡮ࡥ࠿ࠪဴ")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬဵ"))
	return
def l1111l1_l1_(url,filter):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧံ"),l1l1l1_l1_ (u"ࠧࠨ့"),filter,url)
	#headers2 = {l1l1l1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩး"):url,l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ္࠭"):l1l1l1_l1_ (u"်ࠪࠫ")}
	#headers2 = l1l1l1_l1_ (u"ࠫࠬျ")
	#filter = filter.replace(l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧြ"),l1l1l1_l1_ (u"࠭ࠧွ"))
	if l1l1l1_l1_ (u"ࠧࡀࡁࠪှ") in url: url = url.split(l1l1l1_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧဿ"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭၀"),1)
	if filter==l1l1l1_l1_ (u"ࠪࠫ၁"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠫࠬ၂"),l1l1l1_l1_ (u"ࠬ࠭၃")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪ၄"))
	if type==l1l1l1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ၅"):
		if l1l1ll111_l1_[0]+l1l1l1_l1_ (u"ࠨ࠿ࡀࠫ၆") not in l1l1ll11_l1_: category = l1l1ll111_l1_[0]
		for i in range(len(l1l1ll111_l1_[0:-1])):
			if l1l1ll111_l1_[i]+l1l1l1_l1_ (u"ࠩࡀࡁࠬ၇") in l1l1ll11_l1_: category = l1l1ll111_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠪࠪࠫ࠭၈")+category+l1l1l1_l1_ (u"ࠫࡂࡃ࠰ࠨ၉")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠬࠬࠦࠨ၊")+category+l1l1l1_l1_ (u"࠭࠽࠾࠲ࠪ။")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠧࠧࠨࠪ၌"))+l1l1l1_l1_ (u"ࠨࡡࡢࡣࠬ၍")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠩࠩࠪࠬ၎"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭၏"))
		url2 = url+l1l1l1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪၐ")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ၑ"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨၒ"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠧࠨၓ"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫၔ"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠩࠪၕ"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩၖ")+l1l1l1ll_l1_
		l1111lll_l1_ = l1l111l1l_l1_(url2)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫၗ"),menu_name+l1l1l1_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨၘ"),l1111lll_l1_,251,l1l1l1_l1_ (u"࠭ࠧၙ"),l1l1l1_l1_ (u"ࠧࠨၚ"),l1l1l1_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩၛ"))
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩၜ"),menu_name+l1l1l1_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪၝ")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪၞ"),l1111lll_l1_,251,l1l1l1_l1_ (u"ࠬ࠭ၟ"),l1l1l1_l1_ (u"࠭ࠧၠ"),l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨၡ"))
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ၢ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၣ"),l1l1l1_l1_ (u"ࠪࠫၤ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩၥ"),url,l1l1l1_l1_ (u"ࠬ࠭ၦ"),headers,l1l1l1_l1_ (u"࠭ࠧၧ"),l1l1l1_l1_ (u"ࠧࠨၨ"),l1l1l1_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ၩ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡕࡧࡵࡱࡇ࡚ࡎࡴࠤࠪၪ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡘࡦࡾࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࡌࡸࡪࡳࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬၫ"),block,re.DOTALL)
	l1l1l111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡗࡧࡴࡪࡰࡪࡊ࡮ࡲࡴࡦࡴࠥ࠲࠯ࡅ࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄ࠮ࠫࡁࠫࡀࡺࡲ࠾ࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬၬ"),block,re.DOTALL)
	l11111l_l1_ = l1l1l11l1_l1_+l1l1l111l_l1_
	dict = {}
	for name,l1llllll_l1_,block in l11111l_l1_:
		#if l1l1l1_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧၭ") in l1llllll_l1_: continue
		items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧၮ"),block,re.DOTALL)
		if name==l1l1l1_l1_ (u"ࠧศะิํࠬၯ"): name = l1l1l1_l1_ (u"ࠨษ็ห็ูวๆࠩၰ")
		if not items:
			l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡳࡣࡷࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩၱ"),block,re.DOTALL)
			items = []
			for option,value in l1ll1ll_l1_: items.append([option,l1l1l1_l1_ (u"ࠪࠫၲ"),value])
			l1llllll_l1_ = l1l1l1_l1_ (u"ࠫࡷࡧࡴࡦࠩၳ")
			name = l1l1l1_l1_ (u"ࠬอไหไํ๎๊࠭ၴ")
		else: l1llllll_l1_ = items[0][1]
		if l1l1l1_l1_ (u"࠭࠽࠾ࠩၵ") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫၶ"):
			if category!=l1llllll_l1_: continue
			elif len(items)<=1:
				if l1llllll_l1_==l1l1ll111_l1_[-1]: l11l11_l1_(url2)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨၷ")+l1ll1111_l1_)
				return
			else:
				l1111lll_l1_ = l1l111l1l_l1_(url2)
				if l1llllll_l1_==l1l1ll111_l1_[-1]: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩၸ"),menu_name+l1l1l1_l1_ (u"ࠪห้าๅ๋฻ࠣࠫၹ"),l1111lll_l1_,251,l1l1l1_l1_ (u"ࠫࠬၺ"),l1l1l1_l1_ (u"ࠬ࠭ၻ"),l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧၼ"))
				else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧၽ"),menu_name+l1l1l1_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩၾ"),url2,254,l1l1l1_l1_ (u"ࠩࠪၿ"),l1l1l1_l1_ (u"ࠪࠫႀ"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬႁ"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠦࠨႂ")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽࠾࠲ࠪႃ")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪႄ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿ࡀ࠴ࠬႅ")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭ႆ")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪႇ"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ႈ")+name,url2,255,l1l1l1_l1_ (u"ࠬ࠭ႉ"),l1l1l1_l1_ (u"࠭ࠧႊ"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩႋ"))
		dict[l1llllll_l1_] = {}
		for option,dummy,value in items:
			if option in l1l1ll_l1_: continue
			if l1l1l1_l1_ (u"ࠨษ็็้࠭ႌ") in option: continue
			option = unescapeHTML(option)
			#if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶႍࠧ") in option: continue
			#if l1l1l1_l1_ (u"ࠪࡲ࠲ࡧࠧႎ") in value: continue
			l1l11111l_l1_,title2 = option,option
			title2 = name+l1l1l1_l1_ (u"ࠫ࠿ࠦࠧႏ")+l1l11111l_l1_
			dict[l1llllll_l1_][value] = title2
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠬࠬࠦࠨ႐")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽࠾ࠩ႑")+l1l11111l_l1_
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪ႒")+l1llllll_l1_+l1l1l1_l1_ (u"ࠨ࠿ࡀࠫ႓")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭႔")+l1ll1ll1_l1_
			if type==l1l1l1_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ႕"):
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ႖"),menu_name+title2,url,255,l1l1l1_l1_ (u"ࠬ࠭႗"),l1l1l1_l1_ (u"࠭ࠧ႘"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ႙"))
			elif type==l1l1l1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬႚ") and l1l1ll111_l1_[-2]+l1l1l1_l1_ (u"ࠩࡀࡁࠬႛ") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ႜ"))
				#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬႝ"),l1l1l1_l1_ (u"ࠬ࠭႞"),l1l1l111_l1_,l1ll1ll1_l1_)
				url3 = url+l1l1l1_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ႟")+l1l1l111_l1_
				l1111lll_l1_ = l1l111l1l_l1_(url3)
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧႠ"),menu_name+title2,l1111lll_l1_,251,l1l1l1_l1_ (u"ࠨࠩႡ"),l1l1l1_l1_ (u"ࠩࠪႢ"),l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫႣ"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫႤ"),menu_name+title2,url,254,l1l1l1_l1_ (u"ࠬ࠭Ⴅ"),l1l1l1_l1_ (u"࠭ࠧႦ"),l1lllll1_l1_)
	return
l1l1ll111_l1_ = [l1l1l1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩႧ"),l1l1l1_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩႨ"),l1l1l1_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨႩ")]
l1l1l1l11_l1_ = [l1l1l1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬႪ"),l1l1l1_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬႫ"),l1l1l1_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫႬ"),l1l1l1_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬႭ"),l1l1l1_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩႮ"),l1l1l1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩႯ"),l1l1l1_l1_ (u"ࠩࡵࡥࡹ࡫ࠧႰ")]
def l1l111l1l_l1_(url):
	l11lll111_l1_ = l1l1l1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠵࠴࠷࠷࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡉࡱࡰࡩ࠳ࡶࡨࡱࠩႱ")
	url = url.replace(l1l1l1_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࠨႲ"),l11lll111_l1_)
	url = url.replace(l1l1l1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭Ⴓ"),l1l1l1_l1_ (u"࠭ࠧႴ"))
	if l11lll111_l1_ not in url: url = url+l11lll111_l1_
	url = url.replace(l1l1l1_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭Ⴕ"),l1l1l1_l1_ (u"ࠨࡻࡨࡥࡷ࠭Ⴖ"))
	url = url.replace(l1l1l1_l1_ (u"ࠩࡂࡃࠬႷ"),l1l1l1_l1_ (u"ࠪࡃࠬႸ"))
	url = url.replace(l1l1l1_l1_ (u"ࠫࠫࠬࠧႹ"),l1l1l1_l1_ (u"ࠬࠬࠧႺ"))
	url = url.replace(l1l1l1_l1_ (u"࠭࠽࠾ࠩႻ"),l1l1l1_l1_ (u"ࠧ࠾ࠩႼ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩႽ"),l1l1l1_l1_ (u"ࠩࠪႾ"),l1l1l1_l1_ (u"ࠪࠫႿ"),l1l1l1_l1_ (u"ࠫࡕࡘࡅࡑࡃࡕࡉࡤࡌࡉࡍࡖࡈࡖࡤࡌࡉࡏࡃࡏࡣ࡚ࡘࡌࠨჀ"))
	return url
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭Ⴡ"),l1l1l1_l1_ (u"࠭ࠧჂ"),filters,l1l1l1_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧჃ")+mode)
	# mode==l1l1l1_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪჄ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬჅ")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠪࡥࡱࡲࠧ჆")					all filters (l1l11ll1_l1_ l1ll11ll_l1_ filter)
	filters = filters.strip(l1l1l1_l1_ (u"ࠫࠫࠬࠧჇ"))
	l1l1ll1l_l1_,l1llll1l_l1_ = {},l1l1l1_l1_ (u"ࠬ࠭჈")
	if l1l1l1_l1_ (u"࠭࠽࠾ࠩ჉") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠧࠧࠨࠪ჊"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠨ࠿ࡀࠫ჋"))
			l1l1ll1l_l1_[var] = value
	for key in l1l1l1l11_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠩ࠳ࠫ჌")
		if l1l1l1_l1_ (u"ࠪࠩࠬჍ") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭჎") and value!=l1l1l1_l1_ (u"ࠬ࠶ࠧ჏"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"࠭ࠠࠬࠢࠪა")+value
		elif mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪბ") and value!=l1l1l1_l1_ (u"ࠨ࠲ࠪგ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠩࠩࠪࠬდ")+key+l1l1l1_l1_ (u"ࠪࡁࡂ࠭ე")+value
		elif mode==l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࠨვ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠬࠬࠦࠨზ")+key+l1l1l1_l1_ (u"࠭࠽࠾ࠩთ")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠧࠡ࠭ࠣࠫი"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠨࠨࠩࠫკ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪლ"),l1l1l1_l1_ (u"ࠪࠫმ"),l1llll1l_l1_,l1l1l1_l1_ (u"ࠫࡔ࡛ࡔࠨნ"))
	return l1llll1l_l1_
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
#
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䍧")
#l111l1l1lll_l1_ = [ l1l1l1_l1_ (u"ࠨ࡯ࡼࡷࡹࡸࡥࡢ࡯ࠪ䍨"),l1l1l1_l1_ (u"ࠩࡹ࡭ࡲࡶ࡬ࡦࠩ䍩"),l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡢࡰ࡯ࠪ䍪"),l1l1l1_l1_ (u"ࠫ࡬ࡵࡵ࡯࡮࡬ࡱ࡮ࡺࡥࡥࠩ䍫") ]
l111l1l1lll_l1_ = []
headers = {l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䍬"):l1l1l1_l1_ (u"࠭ࠧ䍭")}
def l1l_l1_(l111l11_l1_,source,type,url):
	#DIALOG_SELECT(l1l1l1_l1_ (u"ࠧฤะอีࠥอไาษห฻ࠥอไๆ่สือ࠭䍮"),l111l11_l1_)
	if not l111l11_l1_:
		LOG_THIS(l1l1l1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䍯"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ䍰")+source+l1l1l1_l1_ (u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫ䍱")+type+l1l1l1_l1_ (u"ࠫࠥࡣࠧ䍲"))
		l11l11llll1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡪࡩࡤࡶࠪ䍳"),l1l1l1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䍴"),l1l1l1_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䍵"))
		datetime = time.strftime(l1l1l1_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩ䍶"),time.gmtime(now))
		line = datetime,url
		key = source+l1l1l1_l1_ (u"ࠩࠣࠤࠥࠦࠧ䍷")+addon_version+l1l1l1_l1_ (u"ࠪࠤࠥࠦࠠࠨ䍸")+str(kodi_version)
		if key not in list(l11l11llll1_l1_.keys()): l11l11llll1_l1_[key] = [line]
		else: l11l11llll1_l1_[key].append(line)
		total = 0
		for key in list(l11l11llll1_l1_.keys()):
			l11l11llll1_l1_[key] = list(set(l11l11llll1_l1_[key]))
			total += len(l11l11llll1_l1_[key])
		DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䍹"),l1l1l1_l1_ (u"ࠬ࠭䍺"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䍻"),l1l1l1_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡ࡞ࡱࡠࡳࠦไๅ฻็้ࠥอไษำ้ห๊า๋ࠠไ๋้ࠥฮฬๆ฻ࠣๆฬฬๅสࠢหห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡ์ฯำ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎้ࠠี๋ๅࠥ๐ูาุࠣ฽้๐ใࠡษ็ฬึ์วๆฮࠣว๋ࠦสาี็ࠤ์ึ็ࠡษ็ๆฬฬๅสࠢศ่๎ࠦวๅ็หี๊าฺ่ࠠา้ฬ๊ࠦึสะࠤ฾ีฯ่ษࠣ࠻ࠥ็๊ะ์๋๋ฬะࠧ䍼")+l1l1l1_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䍽")+l1l1l1_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ䍾")+str(total))
		if total>=7:
			yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࠫ䍿"),l1l1l1_l1_ (u"ࠫࠬ䎀"),l1l1l1_l1_ (u"ࠬ࠭䎁"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䎂"),l1l1l1_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠻ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ䎃"))
			if yes==1:
				l11l1l11111_l1_ = l1l1l1_l1_ (u"ࠨࠩ䎄")
				for key in list(l11l11llll1_l1_.keys()):
					l11l1l11111_l1_ += l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ䎅")+key
					l1lll1ll1ll1_l1_ = sorted(l11l11llll1_l1_[key],reverse=False,key=lambda l1111ll11ll_l1_: l1111ll11ll_l1_[0])
					for datetime,url in l1lll1ll1ll1_l1_:
						l11l1l11111_l1_ += l1l1l1_l1_ (u"ࠪࡠࡳ࠭䎆")+datetime+l1l1l1_l1_ (u"ࠫࠥࠦࠠࠡࠩ䎇")+UNQUOTE(url)
					l11l1l11111_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䎈")
				import l1lll11ll1ll_l1_
				l111111lll1_l1_ = l1l1l1_l1_ (u"࠭ࡁࡗ࠼ࠣࠫ䎉")+l1ll11l1lll_l1_(32)+l1l1l1_l1_ (u"ࠧ࠮ࡘ࡬ࡨࡪࡵࡳࠨ䎊")
				succeeded = l1lll11ll1ll_l1_.l11l1ll1111_l1_(l111111lll1_l1_,l1l1l1_l1_ (u"ࠨࠩ䎋"),False,l1l1l1_l1_ (u"ࠩࠪ䎌"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䎍"),l1l1l1_l1_ (u"ࠫࠬ䎎"),l11l1l11111_l1_)
				if succeeded: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䎏"),l1l1l1_l1_ (u"࠭ࠧ䎐"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䎑"),l1l1l1_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫ䎒"))
				else: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䎓"),l1l1l1_l1_ (u"ࠪࠫ䎔"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䎕"),l1l1l1_l1_ (u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢส่สืำศๆࠪ䎖"))
			if yes!=-1:
				l11l11llll1_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䎗"),l1l1l1_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䎘"))
		if l11l11llll1_l1_: WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䎙"),l1l1l1_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ䎚"),l11l11llll1_l1_,PERMANENT_CACHE)
		return
	l111l11_l1_ = list(set(l111l11_l1_))
	l1111ll_l1_,l11l1_l1_ = l1llll1l1111_l1_(l111l11_l1_,source)
	l1lll1ll1l11_l1_ = str(l11l1_l1_).count(l1l1l1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䎛"))
	l1llll1l11ll_l1_ = str(l11l1_l1_).count(l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䎜"))
	l1lll1lll111_l1_ = len(l11l1_l1_)-l1lll1ll1l11_l1_-l1llll1l11ll_l1_
	l1llll1lll11_l1_ = l1l1l1_l1_ (u"๋ࠬิศ้าอ࠿࠭䎝")+str(l1lll1ll1l11_l1_)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࠣฮา๋๊ๅ࠼ࠪ䎞")+str(l1llll1l11ll_l1_)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࠤศิั๊࠼ࠪ䎟")+str(l1lll1lll111_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䎠"),l1l1l1_l1_ (u"ࠩࠪ䎡"),str(l1lll1ll1l11_l1_),str(l1llll1l11ll_l1_))
	#selection = DIALOG_SELECT(l1llll1lll11_l1_, l11l1_l1_)
	if not l11l1_l1_:
		result = l1l1l1_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䎢")
		l11lll1l1l1_l1_ = l1l1l1_l1_ (u"ࠫࠬ䎣")
	else:
		while True:
			l11lll1l1l1_l1_ = l1l1l1_l1_ (u"ࠬ࠭䎤")
			if len(l11l1_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1llll1lll11_l1_,l1111ll_l1_)
			if selection==-1: result = l1l1l1_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ䎥")
			else:
				title = l1111ll_l1_[selection]
				l111ll_l1_ = l11l1_l1_[selection]
				#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䎦"),l1l1l1_l1_ (u"ࠨࠩ䎧"),title,l111ll_l1_)
				if l1l1l1_l1_ (u"ࠩึ๎ึ็ัࠨ䎨") in title and l1l1l1_l1_ (u"ࠪ࠶๊า็้ๆ࠵ࠫ䎩") in title:
					LOG_THIS(l1l1l1_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䎪"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠬࠦࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࡘ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪ䎫")+title+l1l1l1_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䎬")+l111ll_l1_+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪ䎭"))
					import l1lll11ll1ll_l1_
					l1lll11ll1ll_l1_.MAIN(156)
					result = l1l1l1_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䎮")
				else:
					LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䎯"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ䎰")+title+l1l1l1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ䎱")+l111ll_l1_+l1l1l1_l1_ (u"ࠬࠦ࡝ࠨ䎲"))
					result,l11lll1l1l1_l1_,l1l1l1l11ll_l1_ = l1lllll1l1l1_l1_(l111ll_l1_,source,type)
					#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䎳"),l1l1l1_l1_ (u"ࠧࠨ䎴"),result,l11lll1l1l1_l1_)
			if l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ䎵") not in l11lll1l1l1_l1_: l11ll1l1111_l1_,l11ll11llll_l1_ = l11lll1l1l1_l1_,l1l1l1_l1_ (u"ࠩࠪ䎶")
			else: l11ll1l1111_l1_,l11ll11llll_l1_ = l11lll1l1l1_l1_.split(l1l1l1_l1_ (u"ࠪࡠࡳ࠭䎷"),1)
			if result in [l1l1l1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䎸"),l1l1l1_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䎹"),l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ䎺"),l1l1l1_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ䎻")] or len(l11l1_l1_)==1: break
			elif result in [l1l1l1_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ䎼"),l1l1l1_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ䎽"),l1l1l1_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ䎾")]: break
			elif result not in [l1l1l1_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ䎿"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ䏀")]: DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䏁"),l1l1l1_l1_ (u"ࠧࠨ䏂"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䏃"),l1l1l1_l1_ (u"ࠩสุ่๐ัโำฺ่๊๊ࠣࠦ็็ࠤัืศࠡีํีๆืࠠ฻์ิ๋ࠬ䏄")+l1l1l1_l1_ (u"ࠪࡠࡳ࠭䏅")+l11ll1l1111_l1_+l1l1l1_l1_ (u"ࠫࡡࡴࠧ䏆")+l11ll11llll_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䏇"),l1l1l1_l1_ (u"࠭ࠧ䏈"),l1l1l1_l1_ (u"ࠧࠨ䏉"),str(l1l1l1l11ll_l1_))
	if result==l1l1l1_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䏊") and len(l1111ll_l1_)>0: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䏋"),l1l1l1_l1_ (u"ࠪࠫ䏌"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䏍"),l1l1l1_l1_ (u"ู๊ࠬาใิࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠣะึฮࠠโ์า๎ํฺ๋ࠦำ๊ࠫ䏎")+l1l1l1_l1_ (u"࠭࡜࡯ࠩ䏏")+l11lll1l1l1_l1_)
	elif result in [l1l1l1_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䏐"),l1l1l1_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ䏑")] and l11lll1l1l1_l1_!=l1l1l1_l1_ (u"ࠩࠪ䏒"): DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䏓"),l1l1l1_l1_ (u"ࠫࠬ䏔"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䏕"),l11lll1l1l1_l1_)
	#elif l11lll1l1l1_l1_==l1l1l1_l1_ (u"࠭ࡒࡆࡖࡘࡖࡓࡥࡔࡐࡡ࡜ࡓ࡚࡚ࡕࡃࡇࠪ䏖"): result = l1l1l1l11ll_l1_
	l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡩࡧࠢࡵࡩࡸࡻ࡬ࡵࠢ࡬ࡲࠥࡡࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ࠱࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪࡡ࠿ࠐࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡘࡪࡹࡴ࠻ࠢࠣࠤࠬ࠱ࡳࡺࡵ࠱ࡥࡷ࡭ࡶ࡜࠲ࡠ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠲࡞ࠫࠍࠍࠎࡾࡢ࡮ࡥࡳࡰࡺ࡭ࡩ࡯࠰ࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫࡥࡩࡪ࡯࡯ࡡ࡫ࡥࡳࡪ࡬ࡦ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠣࡼࡧࡳࡣࡨࡷ࡬࠲ࡑ࡯ࡳࡵࡋࡷࡩࡲ࠮ࠩࠪࠌࠌࠍࡵࡲࡡࡺࡡ࡬ࡸࡪࡳࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭ࡶࡡࡵࡪࡀࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡄࡳ࡯ࡥࡧࡀ࠵࠹࠹ࠦࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࠫ࠳ࡇࡸࠨ࠷ࡉ࡭ࡷࡣ࠳ࡳࡼ࡛ࡺࡷ࠺ࡓࠪ࠭ࠏࠏࠉࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡱ࡮ࡤࡽ࠭࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࡮ࡹ࠵࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮࠱࡬ࡴ࡭ࡵ࡮ࡦ࠱࠴࠶࠸࠺࠴࠸࠰ࡰࡴ࠹࠭ࠬࡱ࡮ࡤࡽࡤ࡯ࡴࡦ࡯ࠬࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪฮ๊ࠦวๅษ็฾ฬวࠧ࠭ࠩࠪ࠭ࠏࠏࠢࠣࠤ䏗")
	return result
	#if source==l1l1l1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ䏘"): menu_name = l1l1l1_l1_ (u"ࠩࡋࡐࡆ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䏙")
	#elif source==l1l1l1_l1_ (u"ࠪ࠸ࡍࡋࡌࡂࡎࠪ䏚"): menu_name = l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡈࡆࡎࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䏛")
	#elif source==l1l1l1_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䏜"): menu_name = l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡃࡎࡑࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䏝")
	#elif source==l1l1l1_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ䏞"): menu_name = l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡗࡍ࠺ࠠࠨ䏟")
	#size = len(l1lll1ll1l_l1_)
	#for i in range(0,size):
	#	title = l11lll11lll_l1_[i]
	#	l111ll_l1_ = l1lll1ll1l_l1_[i]
	#	addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䏠"),menu_name+title,l111ll_l1_,160,l1l1l1_l1_ (u"ࠪࠫ䏡"),l1l1l1_l1_ (u"ࠫࠬ䏢"),source)
def l1lllll1l1l1_l1_(url,source,type=l1l1l1_l1_ (u"ࠬ࠭䏣")):
	url = url.strip(l1l1l1_l1_ (u"࠭ࠠࠨ䏤")).strip(l1l1l1_l1_ (u"ࠧࠧࠩ䏥")).strip(l1l1l1_l1_ (u"ࠨࡁࠪ䏦")).strip(l1l1l1_l1_ (u"ࠩ࠲ࠫ䏧"))
	l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l11l11_l1_(url,source)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䏨"),l1l1l1_l1_ (u"ࠫࠬ䏩"),url,l11lll1l1l1_l1_)
	if l11lll1l1l1_l1_==l1l1l1_l1_ (u"ࠬࡋࡘࡊࡖࠪ䏪"): return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	elif l11l1_l1_:
		while True:
			if len(l11l1_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䏫"), l1111ll_l1_)
			if selection==-1: result = l1l1l1_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ䏬")
			else:
				l1111l1l11l_l1_ = l11l1_l1_[selection]
				title = l1111ll_l1_[selection]
				LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䏭"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡳࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡖࡩࡱ࡫ࡣࡵࡧࡧ࠾ࠥࡡࠠࠨ䏮")+title+l1l1l1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ䏯")+str(l1111l1l11l_l1_)+l1l1l1_l1_ (u"ࠫࠥࡣࠧ䏰"))
				if l1l1l1_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ䏱") in l1111l1l11l_l1_ and l1l1l1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭䏲") in l1111l1l11l_l1_:
					l111l11l1l1_l1_,l1l1l11l1ll_l1_,l1l1l1l11ll_l1_ = l11l1l1l1ll_l1_(l1111l1l11l_l1_)
					if l1l1l1l11ll_l1_: l1111l1l11l_l1_ = l1l1l1l11ll_l1_[0]
					else: l1111l1l11l_l1_ = l1l1l1_l1_ (u"ࠧࠨ䏳")
				if not l1111l1l11l_l1_: result = l1l1l1_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䏴")
				else: result = PLAY_VIDEO(l1111l1l11l_l1_,source,type)
			if result in [l1l1l1_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ䏵"),l1l1l1_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ䏶")] or len(l11l1_l1_)==1: break
			elif result in [l1l1l1_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䏷"),l1l1l1_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭䏸"),l1l1l1_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ䏹")]: break
			else: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䏺"),l1l1l1_l1_ (u"ࠨࠩ䏻"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䏼"),l1l1l1_l1_ (u"ࠪห้๋ไโࠢ็้ࠥ๐ูๆๆࠣะึฮࠠๆๆไࠤ฿๐ั่ࠩ䏽"))
	else:
		result = l1l1l1_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䏾")
		videofiletype = GET_VIDEOFILETYPE(url)
		if videofiletype: result = PLAY_VIDEO(url,source,type)
	return result,l11lll1l1l1_l1_,l11l1_l1_
	#title = xbmc.getInfoLabel( l1l1l1_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱࠨ䏿") )
	#if l1l1l1_l1_ (u"࠭ำ๋ำไีࠥ฿วๆ่ࠢะ์๎ไࠨ䐀") in title:
	#	import l1lll11ll1ll_l1_
	#	l1lll11ll1ll_l1_.MAIN(156)
	#	return l1l1l1_l1_ (u"ࠧࠨ䐁")
def l1lll111ll1l_l1_(url,source):
	# url = url+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䐂")+name+l1l1l1_l1_ (u"ࠩࡢࡣࠬ䐃")+type+l1l1l1_l1_ (u"ࠪࡣࡤ࠭䐄")+l11llll_l1_+l1l1l1_l1_ (u"ࠫࡤࡥࠧ䐅")+l11ll111_l1_
	# url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡫ࡸࡣࡰ࠲ࡳ࡫ࡴࡀࡰࡤࡱࡪࡪ࠽ࡢ࡭ࡺࡥࡲࡥ࡟ࡸࡣࡷࡧ࡭ࡥ࡟࡮ࡲ࠷ࡣࡤ࠽࠲࠱ࠩ䐆")
	url2,l11l1lll11l_l1_,server,l1111ll1l11_l1_,name,type,l11llll_l1_,l11ll111_l1_ = url,l1l1l1_l1_ (u"࠭ࠧ䐇"),l1l1l1_l1_ (u"ࠧࠨ䐈"),l1l1l1_l1_ (u"ࠨࠩ䐉"),l1l1l1_l1_ (u"ࠩࠪ䐊"),l1l1l1_l1_ (u"ࠪࠫ䐋"),l1l1l1_l1_ (u"ࠫࠬ䐌"),l1l1l1_l1_ (u"ࠬ࠭䐍")
	#source = source.lower()
	if l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䐎") in url:
		url2,l11l1lll11l_l1_ = url.split(l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䐏"),1)
		l11l1lll11l_l1_ = l11l1lll11l_l1_+l1l1l1_l1_ (u"ࠨࡡࡢࠫ䐐")+l1l1l1_l1_ (u"ࠩࡢࡣࠬ䐑")+l1l1l1_l1_ (u"ࠪࡣࡤ࠭䐒")+l1l1l1_l1_ (u"ࠫࡤࡥࠧ䐓")
		l11l1lll11l_l1_ = l11l1lll11l_l1_.lower()
		name,type,l11llll_l1_,l11ll111_l1_,source2 = l11l1lll11l_l1_.split(l1l1l1_l1_ (u"ࠬࡥ࡟ࠨ䐔"))[:5]
	if l11ll111_l1_==l1l1l1_l1_ (u"࠭ࠧ䐕"): l11ll111_l1_ = l1l1l1_l1_ (u"ࠧ࠱ࠩ䐖")
	else: l11ll111_l1_ = l11ll111_l1_.replace(l1l1l1_l1_ (u"ࠨࡲࠪ䐗"),l1l1l1_l1_ (u"ࠩࠪ䐘")).replace(l1l1l1_l1_ (u"ࠪࠤࠬ䐙"),l1l1l1_l1_ (u"ࠫࠬ䐚"))
	url2 = url2.strip(l1l1l1_l1_ (u"ࠬࡅࠧ䐛")).strip(l1l1l1_l1_ (u"࠭࠯ࠨ䐜")).strip(l1l1l1_l1_ (u"ࠧࠧࠩ䐝"))
	server = SERVER(url2,l1l1l1_l1_ (u"ࠨࡪࡲࡷࡹ࠭䐞"))
	if name: l1111ll1l11_l1_ = name
	#elif source: l1111ll1l11_l1_ = source
	else: l1111ll1l11_l1_ = server
	l1111ll1l11_l1_ = SERVER(l1111ll1l11_l1_,l1l1l1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䐟"))
	name = name.replace(l1l1l1_l1_ (u"้ࠪออิาࠩ䐠"),l1l1l1_l1_ (u"ࠫࠬ䐡")).replace(l1l1l1_l1_ (u"ู๊ࠬาใิࠫ䐢"),l1l1l1_l1_ (u"࠭ࠧ䐣")).replace(l1l1l1_l1_ (u"ࠧศๆࠣࠫ䐤"),l1l1l1_l1_ (u"ࠨࠢࠪ䐥")).replace(l1l1l1_l1_ (u"ࠩࠣࠤࠬ䐦"),l1l1l1_l1_ (u"ࠪࠤࠬ䐧"))
	l11l1lll11l_l1_ = l11l1lll11l_l1_.replace(l1l1l1_l1_ (u"๊ࠫฮวีำࠪ䐨"),l1l1l1_l1_ (u"ࠬ࠭䐩")).replace(l1l1l1_l1_ (u"࠭ำ๋ำไีࠬ䐪"),l1l1l1_l1_ (u"ࠧࠨ䐫")).replace(l1l1l1_l1_ (u"ࠨษ็ࠤࠬ䐬"),l1l1l1_l1_ (u"ࠩࠣࠫ䐭")).replace(l1l1l1_l1_ (u"ࠪࠤࠥ࠭䐮"),l1l1l1_l1_ (u"ࠫࠥ࠭䐯"))
	l1111ll1l11_l1_ = l1111ll1l11_l1_.replace(l1l1l1_l1_ (u"๋ࠬศศึิࠫ䐰"),l1l1l1_l1_ (u"࠭ࠧ䐱")).replace(l1l1l1_l1_ (u"ࠧิ์ิๅึ࠭䐲"),l1l1l1_l1_ (u"ࠨࠩ䐳")).replace(l1l1l1_l1_ (u"ࠩส่ࠥ࠭䐴"),l1l1l1_l1_ (u"ࠪࠤࠬ䐵")).replace(l1l1l1_l1_ (u"ࠫࠥࠦࠧ䐶"),l1l1l1_l1_ (u"ࠬࠦࠧ䐷"))
	return url2,l11l1lll11l_l1_,server,l1111ll1l11_l1_,name,type,l11llll_l1_,l11ll111_l1_
def l11lll11111_l1_(url,source):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䐸"),l1l1l1_l1_ (u"ࠧࠨ䐹"),url,l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡂࡄࡏࡉࠬ䐺"))
	# l1llllll1_l1_	: سيرفر خاص
	# l11ll11l111_l1_		: سيرفر محدد
	# l11l1ll1lll_l1_		: سيرفر عام معروف
	# l1lll11ll_l1_	: سيرفر عام خارجي
	# l1lll1lll1ll_l1_	: سيرفر عام خارجي
	l1111l11111_l1_,name,l1llllll1_l1_,l11l1ll1lll_l1_,l1lll11ll_l1_,l11ll11l111_l1_,l1lll1lll1ll_l1_ = l1l1l1_l1_ (u"ࠩࠪ䐻"),l1l1l1_l1_ (u"ࠪࠫ䐼"),None,None,None,None,None
	url2,l11l1lll11l_l1_,server,l1111ll1l11_l1_,name,type,l11llll_l1_,l11ll111_l1_ = l1lll111ll1l_l1_(url,source)
	if l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䐽") in url:
		if   type==l1l1l1_l1_ (u"ࠬ࡫࡭ࡣࡧࡧࠫ䐾"): type = l1l1l1_l1_ (u"࠭ࠠࠨ䐿")+l1l1l1_l1_ (u"ࠧๆใู่ࠬ䑀")
		elif type==l1l1l1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ䑁"): type = l1l1l1_l1_ (u"ࠩࠣࠫ䑂")+l1l1l1_l1_ (u"ฺ๊ࠪࠩว่ัฬࠫ䑃")
		elif type==l1l1l1_l1_ (u"ࠫࡧࡵࡴࡩࠩ䑄"): type = l1l1l1_l1_ (u"ࠬࠦࠧ䑅")+l1l1l1_l1_ (u"࠭ࠥࠦ็ืห์ีษ๊ࠡอั๊๐ไࠨ䑆")
		elif type==l1l1l1_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ䑇"): type = l1l1l1_l1_ (u"ࠨࠢࠪ䑈")+l1l1l1_l1_ (u"ࠩࠨࠩࠪะอๆ์็ࠫ䑉")
		elif type==l1l1l1_l1_ (u"ࠪࠫ䑊"): type = l1l1l1_l1_ (u"ࠫࠥ࠭䑋")+l1l1l1_l1_ (u"ࠬࠫࠥࠦࠧࠪ䑌")
		if l11llll_l1_!=l1l1l1_l1_ (u"࠭ࠧ䑍"):
			if l1l1l1_l1_ (u"ࠧ࡮ࡲ࠷ࠫ䑎") not in l11llll_l1_: l11llll_l1_ = l1l1l1_l1_ (u"ࠨࠧࠪ䑏")+l11llll_l1_
			l11llll_l1_ = l1l1l1_l1_ (u"ࠩࠣࠫ䑐")+l11llll_l1_
		if l11ll111_l1_!=l1l1l1_l1_ (u"ࠪࠫ䑑"):
			l11ll111_l1_ = l1l1l1_l1_ (u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧ䑒")+l11ll111_l1_
			l11ll111_l1_ = l1l1l1_l1_ (u"ࠬࠦࠧ䑓")+l11ll111_l1_[-9:]
	#if any(value in server for value in l111l1l1lll_l1_): return l1l1l1_l1_ (u"࠭ࠧ䑔")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䑕"),l1l1l1_l1_ (u"ࠨࠩ䑖"),name,l1111ll1l11_l1_)
	if   l1l1l1_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䑗")		in source: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ䑘")		in source: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࠪ䑙")
	elif l1l1l1_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䑚")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ䑛")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭䑜")	in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠨࡵࡨࡩࡪ࡫ࡤࠨ䑝")		in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ䑞")
	#elif l1l1l1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࡶࡸࡦࡺࡩࡰࡰࠪ䑟") in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䑠")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ䑡")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	#elif l1l1l1_l1_ (u"࠭ࡰࡤࡴࡨࡺ࡮࡫ࡷࠨ䑢")	in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ䑣")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠨࡶ࠺ࡱࡪ࡫࡬ࠨ䑤")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ䑥")		in name:   l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ䑦")		in name:   l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䑧")		in name:   l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡧࡱࡻࡢࠨ䑨")	in name:   l1llllll1_l1_	= l1l1l1_l1_ (u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡰࠨ䑩")
	elif l1l1l1_l1_ (u"ࠧโฮิࠫ䑪")			in name:   l1llllll1_l1_	= l1l1l1_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䑫")
	elif l1l1l1_l1_ (u"ࠩไุ่฽๊็ࠩ䑬")		in name:   l1llllll1_l1_	= l1l1l1_l1_ (u"ࠪࡴࡦࡲࡥࡴࡶ࡬ࡲࡪ࠭䑭")
	elif l1l1l1_l1_ (u"ࠫ࡬ࡪࡲࡪࡸࡨࠫ䑮")		in url2:   l1llllll1_l1_	= l1l1l1_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬ䑯")
	elif l1l1l1_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䑰")		in name:   l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ䑱")		in name:   l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䑲")		in name:   l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ䑳")	in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ䑴")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ䑵")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ䑶")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ䑷")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䑸")		in server: l1llllll1_l1_	= l1111ll1l11_l1_
	#elif l1l1l1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡱࡩࡹ࠭䑹")	in url2:   l1llllll1_l1_	= l1l1l1_l1_ (u"ࠩࠣࠫ䑺")
	elif l1l1l1_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ䑻")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭䑼")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ䑽")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭䑾")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ䑿")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ䒀")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ䒁")	 	in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ䒂")
	elif l1l1l1_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ䒃")	 	in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭䒄")
	elif l1l1l1_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ䒅")	in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ䒆")
	elif l1l1l1_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ䒇")		in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ䒈")
	elif l1l1l1_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ䒉")		in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䒊")
	elif l1l1l1_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䒋")	in server: l1llllll1_l1_	= l1l1l1_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ䒌")
	elif l1l1l1_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ䒍")	in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ䒎")
	elif l1l1l1_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ䒏")		in server: l1llllll1_l1_	= l1l1l1_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ䒐")
	elif l1l1l1_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ䒑")	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ䒒")
	elif l1l1l1_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ䒓")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䒔")
	elif l1l1l1_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ䒕")	 	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠩࡦࡥࡹࡩࡨࠨ䒖")
	elif l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ䒗")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ䒘")
	elif l1l1l1_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ䒙")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ䒚")
	elif l1l1l1_l1_ (u"ࠧࡷ࡫ࡧ࡬ࡩ࠭䒛")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧ䒜")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ䒝")		in server: l11ll11l111_l1_	= l1111ll1l11_l1_
	elif l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ䒞")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭䒟")
	elif l1l1l1_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ䒠")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ䒡")
	elif l1l1l1_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ䒢") 	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ䒣")
	elif l1l1l1_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ䒤")	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䒥")
	elif l1l1l1_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ䒦")	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ䒧")
	elif l1l1l1_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ䒨") 	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ䒩")
	elif l1l1l1_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ䒪")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䒫")
	elif l1l1l1_l1_ (u"ࠪࡹࡵࡶࠧ䒬") 			in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ䒭")
	elif l1l1l1_l1_ (u"ࠬࡻࡰࡣࠩ䒮") 			in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ䒯")
	elif l1l1l1_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䒰") 		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䒱")
	elif l1l1l1_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䒲") 	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ䒳")
	elif l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ䒴")		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ䒵")
	elif l1l1l1_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭䒶") 		in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ䒷")
	elif l1l1l1_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ䒸") 	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䒹")
	elif l1l1l1_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䒺")	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ䒻")
	elif l1l1l1_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ䒼")	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䒽")
	#elif l1l1l1_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ䒾") 	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠨࡷࡳࡸࡴࡨ࡯ࡹࠩ䒿")
	#elif l1l1l1_l1_ (u"ࠩࡸࡴࡹࡵࡳࡵࡴࡨࡥࡲ࠭䓀")	in server: l11l1ll1lll_l1_	= l1l1l1_l1_ (u"ࠪࡹࡵࡺ࡯ࡴࡶࡵࡩࡦࡳࠧ䓁")
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࡶࡴ࡯࠯ࠬࡃ࠽࠾ࠩ࠮ࡹࡷࡲ࠲ࠪࠌࠌࠍࡹࡸࡹ࠻ࠌࠌࠍࠎ࡯࡭ࡱࡱࡵࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠴ࡈࡰࡵࡷࡩࡩࡓࡥࡥ࡫ࡤࡊ࡮ࡲࡥࠩࡷࡵࡰ࠷࠯࠮ࡷࡣ࡯࡭ࡩࡥࡵࡳ࡮ࠫ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࡴ࠽ࠎࠎࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠱࠲࠳࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ࠭ࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡌࡡ࡭ࡵࡨࠎࠎࠏࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶࡤࡨ࠱ࡩࡲ࠮ࡰࡴࡪࠎࠎࠏࠉ࡭࡫ࡶࡸࡤࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡵࡦ࡯࠱ࡴࡸࡧ࠯ࡩ࡬ࡸ࡭ࡻࡢ࠯࡫ࡲ࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪ࡬࠰ࡵࡸࡴࡵࡵࡲࡵࡧࡧࡷ࡮ࡺࡥࡴ࠰࡫ࡸࡲࡲࠧࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆ࠮࡯࡭ࡸࡺ࡟ࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡊ࡙ࡏࡍࡘࡄࡆࡑࡋ࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡷ࡯ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡪࡨࠣ࡬ࡹࡳ࡬࠻ࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࡟࠵ࡣ࠮࡭ࡱࡺࡩࡷ࠮ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࡬ࡪࡀࠪ࠰ࠬ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀࡧࡄࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡱ࡯࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡦࡃ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠳࠴࠵࠶ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠮ࠐࠉࠊࠋࠌࡴࡦࡸࡴࡴࠢࡀࠤࡸ࡫ࡲࡷࡧࡵ࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠳࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡳࡥࡷࡺࠠࡪࡰࠣࡴࡦࡸࡴࡴ࠼ࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡲࡤࡶࡹ࠯࠼࠵࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࠌࡩࡱ࡯ࡦࠡࡲࡤࡶࡹࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠺ࠋࠋࠌࠍࠎࠏࠉࡳࡧࡶࡳࡱࡼࡥࡳࠢࡀࠤ࡙ࡸࡵࡦࠌࠌࠍࠎࠏࠉࠊࡤࡵࡩࡦࡱࠊࠊࠤࠥࠦ䓂")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䓃"),l1l1l1_l1_ (u"࠭ࠧ䓄"),url,url2)
	if   l1llllll1_l1_:	l1111l11111_l1_,name = l1l1l1_l1_ (u"ࠧฯษุࠫ䓅"),l1llllll1_l1_
	elif l11ll11l111_l1_:		l1111l11111_l1_,name = l1l1l1_l1_ (u"ࠨ่ࠧัิีࠧ䓆"),l11ll11l111_l1_
	elif l11l1ll1lll_l1_:		l1111l11111_l1_,name = l1l1l1_l1_ (u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧ䓇"),l11l1ll1lll_l1_
	elif l1lll11ll_l1_:	l1111l11111_l1_,name = l1l1l1_l1_ (u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ䓈"),l1lll11ll_l1_
	elif l1lll1lll1ll_l1_:	l1111l11111_l1_,name = l1l1l1_l1_ (u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫ䓉"),l1111ll1l11_l1_
	else:			l1111l11111_l1_,name = l1l1l1_l1_ (u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์้࠭䓊"),l1111ll1l11_l1_
	return l1111l11111_l1_,name,type,l11llll_l1_,l11ll111_l1_
	l1l1l1_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࠩࡳࡰࡦࡿࡲ࠯࠶࡫ࡩࡱࡧ࡬ࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉࡱࡴ࡬ࡺࡦࡺࡥࠡ࠿ࠣࠫ࡭࡫࡬ࡢ࡮ࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠍࠍࡪࡲࡩࡧࠢࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸࡨࡺࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡧࡵ࡭ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠢࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡩࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠎࠎࠨࠢࠣ䓋")
def l1llllll1lll_l1_(url,source):
	url2,l11l1lll11l_l1_,server,l1111ll1l11_l1_,name,type,l11llll_l1_,l11ll111_l1_ = l1lll111ll1l_l1_(url,source)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䓌"),l1l1l1_l1_ (u"ࠨࠩ䓍"),l11ll11l111_l1_,server)
	#if l1l1l1_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ䓎")	in server: url2 = url2.replace(l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ䓏"),l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䓐"))
	#if any(value in server for value in l111l1l1lll_l1_): l1111ll_l1_,l11l1_l1_ = [l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡅࡔࡑࡏ࡚ࡊࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࠢࡷ࡬࡮ࡹࠠࡴࡧࡵࡺࡪࡸࠧ䓑")],[]
	if   l1l1l1_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ䓒")		in source: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l11ll_l1_(url2,name)
	elif l1l1l1_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭䓓")		in source: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11ll1l_l1_(url2,type,l11ll111_l1_)
	elif l1l1l1_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䓔")		in source: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lllll1lll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ䓕")		in source: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l111l_l1_(url2)
	elif l1l1l1_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ䓖")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll1l1ll11_l1_(url2)
	elif l1l1l1_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ䓗")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1llll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ䓘")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11ll1l1lll_l1_(url2)
	elif l1l1l1_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ䓙")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llll1111l1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ䓚")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llll1111l1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ䓛")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llll1lll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ䓜")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l11l1l_l1_(url2)
	elif l1l1l1_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ䓝")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l1111l1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ䓞")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l1111l1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ䓟")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll111lll_l1_(url2)
	elif l1l1l1_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ䓠")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lllll1ll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䓡")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l11ll1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䓢")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l1lll1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ䓣")			in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l11l11l_l1_(url2)
	elif l1l1l1_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䓤")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llllll1l1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䓥")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l11l_l1_(url2)
	elif l1l1l1_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡰ࡮࡭ࡨࡵࠩ䓦")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l1l1_l1_(url2)
	elif l1l1l1_l1_ (u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩ䓧")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l1l1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ䓨")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l111lll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ䓩")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llll11l111_l1_(url2)
	elif l1l1l1_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ䓪")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111ll1ll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䓫")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll111l1l_l1_(url2)
	elif l1l1l1_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䓬")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lllll1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ䓭")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lllll1_l1_(url2)
	elif l1l1l1_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡺࡥࡤࡪࠪ䓮")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lllll1_l1_(url2)
	elif l1l1l1_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ䓯")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l1llll_l1_(url2)
	elif l1l1l1_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭䓰")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠩࠪ䓱"),[l1l1l1_l1_ (u"ࠪࠫ䓲")],[url2]
	elif l1l1l1_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䓳")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l1lll1l_l1_(url)
	elif l1l1l1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫ䓴")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l11l111l_l1_(url2)
	elif l1l1l1_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䓵") 		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠧࠨ䓶"),[l1l1l1_l1_ (u"ࠨࠩ䓷")],[url2]
	else: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䓸"),[l1l1l1_l1_ (u"ࠪࠫ䓹")],[url2]
	return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
def l11l1ll1l1l_l1_(url,source):
	server = SERVER(url,l1l1l1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䓺"))
	#if l1l1l1_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ䓻")	in server: url2 = url2.replace(l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭䓼"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䓽"))
	#if any(value in server for value in l111l1l1lll_l1_): l1111ll_l1_,l11l1_l1_ = [l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ䓾")],[]
	l1llllll1ll1_l1_ = False
	if   l1l1l1_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ䓿")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lll111l1_l1_(url)
	elif l1l1l1_l1_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ䔀")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lll111l1_l1_(url)
	elif l1l1l1_l1_ (u"ࠫࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࠪ䔁")	in url: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l1ll11l_l1_(url)
	elif l1l1l1_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䔂")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lllll1_l1_(url)
	elif l1l1l1_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䔃")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll111l1l_l1_(url)
	elif l1l1l1_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䔄")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l1l1l1ll_l1_(url)
	elif l1l1l1_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ䔅")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lllll1lll_l1_(url)
	elif l1l1l1_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ䔆")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111111l1ll_l1_(url)
	elif l1l1l1_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䔇")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll1lll11ll_l1_(url)
	elif l1l1l1_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ䔈")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11111lll11_l1_(url)
	elif l1l1l1_l1_ (u"ࠬ࡫࠵ࡵࡵࡤࡶࠬ䔉")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l11l11ll_l1_(url)
	elif l1l1l1_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ䔊")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l11l1lll_l1_(url)
	elif l1l1l1_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ䔋")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l11l1lll_l1_(url)
	elif l1l1l1_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ䔌")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	elif l1l1l1_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ䔍")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	elif l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ䔎")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	elif l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ䔏")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	elif l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ䔐")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	elif l1l1l1_l1_ (u"࠭࡬ࡪ࡫࡬ࡺ࡮ࡪࡥࡰࠩ䔑")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	elif l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡳࡧࡧࠧ䔒")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll111l11l_l1_(url)
	elif l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡸࡶࡥࡦࡦࠪ䔓")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll111l11l_l1_(url)
	elif l1l1l1_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ䔔") 		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠪࠫ䔕"),[l1l1l1_l1_ (u"ࠫࠬ䔖")],[url]
	#elif l1l1l1_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ䔗")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll1lll11l1_l1_(url)
	elif l1l1l1_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ䔘") 	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l1l11ll_l1_(url)
	elif l1l1l1_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ䔙")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111lll1l1l_l1_(url)
	elif l1l1l1_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࡮࡯ࠨ䔚")in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1111l1lll1_l1_(url)
	elif l1l1l1_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭䔛") 	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l1l111ll_l1_(url)
	elif l1l1l1_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ䔜")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1111111111_l1_(url)
	elif l1l1l1_l1_ (u"ࠫࡺࡶࡢࠨ䔝") 			in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll1ll1l111_l1_(url)
	elif l1l1l1_l1_ (u"ࠬࡻࡰࡱࠩ䔞") 			in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1ll1ll1l111_l1_(url)
	#elif l1l1l1_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ䔟") 	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11111l1lll_l1_(url)
	#elif l1l1l1_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ䔠")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11111l1lll_l1_(url)
	elif l1l1l1_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䔡") 		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llll11llll_l1_(url)
	elif l1l1l1_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䔢") 	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111l11ll1l_l1_(url)
	elif l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ䔣")		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llllllllll_l1_(url)
	elif l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ䔤") 		in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lllll111ll_l1_(url)
	elif l1l1l1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䔥") 	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l111ll1l1ll_l1_(url)
	elif l1l1l1_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䔦")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llll1l11l1_l1_(url)
	elif l1l1l1_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ䔧")	in server: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11111ll1ll_l1_(url)
	else: l1llllll1ll1_l1_ = True
	if l1llllll1ll1_l1_ or l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ䔨") in l11lll1l1l1_l1_:
		l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䔩"),[],[]
	return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	l1l1l1_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈࡗ࡙ࡘࡅࡂࡏࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡇࡐࡗࡑࡐࡎࡓࡉࡕࡇࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩ࡬ࡲࡹࡵࡵࡱ࡮ࡲࡥࡩ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡊࡐࡗࡓ࡚ࡖࡌࡐࡃࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁ࡚ࠥࡈࡆࡘࡌࡈࡊࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡇ࡙ࡍࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡵࡲࡡࡺࡴ࠱࠸࡭࡫࡬ࡢ࡮ࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡌࡊࡒࡁࡍࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡦࡴࡳࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡇࡕࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡌࡉ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡗࡍࡇࡒࡆࠪࡸࡶࡱ࠯ࠊࠊࠤࠥࠦ䔪")
def	l111l111l1l_l1_(l1l1l1lll11_l1_):
	if l1l1l1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䔫") in str(type(l1l1l1lll11_l1_)):
		l1ll_l1_ = []
		for l111ll_l1_ in l1l1l1lll11_l1_:
			if l1l1l1_l1_ (u"ࠬࡹࡴࡳࠩ䔬") in str(type(l111ll_l1_)):
				l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"࠭࡜ࡳࠩ䔭"),l1l1l1_l1_ (u"ࠧࠨ䔮")).replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ䔯"),l1l1l1_l1_ (u"ࠩࠪ䔰")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ䔱"))
			l1ll_l1_.append(l111ll_l1_)
	else: l1ll_l1_ = l1l1l1lll11_l1_.replace(l1l1l1_l1_ (u"ࠫࡡࡸࠧ䔲"),l1l1l1_l1_ (u"ࠬ࠭䔳")).replace(l1l1l1_l1_ (u"࠭࡜࡯ࠩ䔴"),l1l1l1_l1_ (u"ࠧࠨ䔵")).strip(l1l1l1_l1_ (u"ࠨࠢࠪ䔶"))
	return l1ll_l1_
def l1lll1l11l11_l1_(url,source):
	LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䔷"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䔸")+url+l1l1l1_l1_ (u"ࠫࠥࡣࠧ䔹"))
	l1lll1lll1ll_l1_,l111ll_l1_,l111l111ll1_l1_ = l1l1l1_l1_ (u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩ䔺"),l1l1l1_l1_ (u"࠭ࠧ䔻"),l1l1l1_l1_ (u"ࠧࠨ䔼")
	l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1llllll1lll_l1_(url,source)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䔽"),l1l1l1_l1_ (u"ࠩࠪ䔾"),l1l1l1_l1_ (u"ࠪࠫ䔿"),l11lll1l1l1_l1_)
	l11l1_l1_ = l111l111l1l_l1_(l11l1_l1_)
	if l11lll1l1l1_l1_==l1l1l1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䕀"): return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	elif l11l1_l1_: l111ll_l1_ = l11l1_l1_[0]
	if l11lll1l1l1_l1_==l1l1l1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䕁"):
		#l11lll1l1l1_l1_ = l11lll1l1l1_l1_.replace(l1l1l1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䕂"),l1l1l1_l1_ (u"ࠧࠨ䕃"))
		l1lll1lll1ll_l1_ = l1l1l1_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ䕄")
		l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l1ll1l1l_l1_(l111ll_l1_,source)
		l11l1_l1_ = l111l111l1l_l1_(l11l1_l1_)
		if l11lll1l1l1_l1_==l1l1l1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䕅"): return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
		elif l1l1l1_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠩ䕆") in l11lll1l1l1_l1_:
			l111l111ll1_l1_ += l1l1l1_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠬ䕇")+l11lll1l1l1_l1_
			l1lll1lll1ll_l1_ = l1l1l1_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ䕈")
			l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11l1ll1l11_l1_(l111ll_l1_,source)
			l11l1_l1_ = l111l111l1l_l1_(l11l1_l1_)
			if l11lll1l1l1_l1_==l1l1l1_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䕉"): return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
			elif l1l1l1_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭䕊") in l11lll1l1l1_l1_:
				l111l111ll1_l1_ += l1l1l1_l1_ (u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠸࠺ࠡࠩ䕋")+l11lll1l1l1_l1_
				l1lll1lll1ll_l1_ = l1l1l1_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ䕌")
				l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l11lll1l11l_l1_(l111ll_l1_,source)
				l11l1_l1_ = l111l111l1l_l1_(l11l1_l1_)
				if l11lll1l1l1_l1_==l1l1l1_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䕍"): return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
				elif l1l1l1_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪ䕎") in l11lll1l1l1_l1_:
					l111l111ll1_l1_ += l1l1l1_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥ࠭䕏")+l11lll1l1l1_l1_
					#LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䕐"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡅࡱࡲࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡎࡧࡶࡷࡦ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭䕑")+l111l111ll1_l1_+l1l1l1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䕒")+url+l1l1l1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䕓")+l111ll_l1_+l1l1l1_l1_ (u"ࠪࠤࡢ࠭䕔"))
	elif l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࠭䕕") in l11lll1l1l1_l1_: l111l111ll1_l1_ = l1l1l1_l1_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠱࠼ࠣࠫ䕖")+l11lll1l1l1_l1_
	l111l111ll1_l1_ = l111l111ll1_l1_.strip(l1l1l1_l1_ (u"࠭࡜࡯ࠩ䕗"))
	if l11l1_l1_: LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䕘"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫ䕙")+l1lll1lll1ll_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䕚")+l111ll_l1_+l1l1l1_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡷࡺࡲࡴ࠻ࠢ࡞ࠤࠬ䕛")+str(l11l1_l1_)+l1l1l1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ䕜")+url+l1l1l1_l1_ (u"ࠬࠦ࡝ࠨ䕝"))
	else: LOG_THIS(l1l1l1_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䕞"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䕟")+l111ll_l1_+l1l1l1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡍࡦࡵࡶࡥ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬ䕠")+l111l111ll1_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭䕡")+url+l1l1l1_l1_ (u"ࠪࠤࡢ࠭䕢"))
	#l111l111ll1_l1_ = l111l111ll1_l1_.replace(l1l1l1_l1_ (u"ࠫࡡࡴࠧ䕣"),l1l1l1_l1_ (u"ࠬࠦ࠮࠯࠰ࠣࠫ䕤"))
	#if l1l1l1_l1_ (u"࠭ࡥࡳࡴࡲࡶ࠿ࠦࠧ䕥") not in l11lll1l1l1_l1_.lower(): return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	l111l111ll1_l1_ = UNQUOTE(l111l111ll1_l1_)
	return l111l111ll1_l1_,l1111ll_l1_,l11l1_l1_
def l1llll1l1111_l1_(l1l1l1l11ll_l1_,source):
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䕦"),l1l1l1l11ll_l1_)
	expiry = l11l11l_l1_
	data = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䕧"),l1l1l1_l1_ (u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪ䕨"),l1l1l1l11ll_l1_)
	if data:
		l1111ll_l1_,l11l1_l1_ = list(zip(*data))
		return l1111ll_l1_,l11l1_l1_
	l1111ll_l1_,l11l1_l1_,l11lll11lll_l1_ = [],[],[]
	for l111ll_l1_ in l1l1l1l11ll_l1_:
		if l1l1l1_l1_ (u"ࠪ࠳࠴࠭䕩") not in l111ll_l1_: continue
		l1111l11111_l1_,name,type,l11llll_l1_,l11ll111_l1_ = l11lll11111_l1_(l111ll_l1_,source)
		l11ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡡࡪࠫࠨ䕪"),l11ll111_l1_,re.DOTALL)
		if l11ll111_l1_: l11ll111_l1_ = int(l11ll111_l1_[0])
		else: l11ll111_l1_ = 0
		#if l11ll111_l1_:
		#	l11l1l1l11l_l1_ = sorted(l11ll111_l1_,reverse=True,key=lambda key: int(key))
		#	l11ll111_l1_ = int(l11l1l1l11l_l1_[0])
		#else: l11ll111_l1_ = 0
		server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䕫"))
		l11lll11lll_l1_.append([l1111l11111_l1_,name,type,l11llll_l1_,l11ll111_l1_,l111ll_l1_,server])
	if l11lll11lll_l1_:
		#l1111l11111_l1_,name,type,l11llll_l1_,l11ll111_l1_,l111ll_l1_ = zip(*l11lll11lll_l1_)
		#name = reversed(name)
		#l11lll11lll_l1_ = zip(l1111l11111_l1_,name,type,l11llll_l1_,l11ll111_l1_,l111ll_l1_)
		l111l111lll_l1_ = sorted(l11lll11lll_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l1111lllll1_l1_ = []
		for line in l111l111lll_l1_:
			if line not in l1111lllll1_l1_:
				l1111lllll1_l1_.append(line)
				#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ䕬"),str(line))
		for l1111l11111_l1_,name,type,l11llll_l1_,l11ll111_l1_,l111ll_l1_,server in l1111lllll1_l1_:
			if l11ll111_l1_: l11ll111_l1_ = str(l11ll111_l1_)
			else: l11ll111_l1_ = l1l1l1_l1_ (u"ࠧࠨ䕭")
			#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䕮"),l1l1l1_l1_ (u"ࠩࠪ䕯"),name,l111ll_l1_)
			title = l1l1l1_l1_ (u"ࠪื๏ืแาࠩ䕰")+l1l1l1_l1_ (u"ࠫࠥ࠭䕱")+type+l1l1l1_l1_ (u"ࠬࠦࠧ䕲")+l1111l11111_l1_+l1l1l1_l1_ (u"࠭ࠠࠨ䕳")+l11ll111_l1_+l1l1l1_l1_ (u"ࠧࠡࠩ䕴")+l11llll_l1_+l1l1l1_l1_ (u"ࠨࠢࠪ䕵")+name
			if server not in title: title = title+l1l1l1_l1_ (u"ࠩࠣࠫ䕶")+server
			title = title.replace(l1l1l1_l1_ (u"ࠪࠩࠬ䕷"),l1l1l1_l1_ (u"ࠫࠬ䕸")).strip(l1l1l1_l1_ (u"ࠬࠦࠧ䕹")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠩ䕺"),l1l1l1_l1_ (u"ࠧࠡࠩ䕻")).replace(l1l1l1_l1_ (u"ࠨࠢࠣࠫ䕼"),l1l1l1_l1_ (u"ࠩࠣࠫ䕽")).replace(l1l1l1_l1_ (u"ࠪࠤࠥ࠭䕾"),l1l1l1_l1_ (u"ࠫࠥ࠭䕿"))
			if l111ll_l1_ not in l11l1_l1_:
				l1111ll_l1_.append(title)
				l11l1_l1_.append(l111ll_l1_)
		if l11l1_l1_:
			#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ䖀"),l11l1_l1_)
			data = list(zip(l1111ll_l1_,l11l1_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧ䖁"),l1l1l1l11ll_l1_,data,expiry)
	#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ䖂"),l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦࡀ࠲࠻ࠢࠣࠤࠬ䖃")+str(data))
	return l1111ll_l1_,l11l1_l1_
l1l1l1_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡖࡉࡗ࡜ࡅࡓࡕࡢࡇࡆࡉࡈࡆࡆࡢࡓࡑࡊࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠮ࡶࡳࡺࡸࡣࡦ࠿ࠪࠫ࠮ࡀࠊࠊࠥࡷ࠵ࠥࡃࠠࡵ࡫ࡰࡩ࠳ࡺࡩ࡮ࡧࠫ࠭ࠏࠏࡣࡢࡥ࡫ࡩࡵ࡫ࡲࡪࡱࡧࠤࡂࠦࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇࠍࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮࡭ࡢ࡫ࡱࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࡣࠡ࠿ࠣࡧࡴࡴ࡮࠯ࡥࡸࡶࡸࡵࡲࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡷࡩࡽࡺ࡟ࡧࡣࡦࡸࡴࡸࡹࠡ࠿ࠣࡷࡹࡸࠊࠊࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨ࡙ࠬࠬࡅࡍࡇࡆࡘࠥࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖ࠯ࡹࡷࡲࡌࡊࡕࡗࠤࡋࡘࡏࡎࠢࡶࡩࡷࡼࡥࡳࡵࡦࡥࡨ࡮ࡥ࡙ࠡࡋࡉࡗࡋࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠿ࠥࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠭࠰࠭ࠢࠨࠫࠍࠍࡷࡵࡷࡴࠢࡀࠤࡨ࠴ࡦࡦࡶࡦ࡬ࡦࡲ࡬ࠩࠫࠍࠍ࡮࡬ࠠࡳࡱࡺࡷ࠿ࠐࠉࠊࠥࡰࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭ࡦࡰࡷࡱࡨࠥ࡯࡮ࠡࡥࡤࡧ࡭࡫ࠧࠋࠋࠌࡷࡪࡸࡶࡦࡴࡶࡐࡎ࡙ࡔ࠭ࡷࡵࡰࡑࡏࡓࡕࠢࡀࠤࡊ࡜ࡁࡍࠪࠪࡷࡹࡸࠧ࠭ࡴࡲࡻࡸࡡ࠰࡞࡝࠳ࡡ࠮࠲ࡅࡗࡃࡏࠬࠬࡹࡴࡳࠩ࠯ࡶࡴࡽࡳ࡜࠲ࡠ࡟࠶ࡣࠩࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࡲ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡤࡣࡦ࡬ࡪ࠭ࠊࠊࠋࡶࡩࡷࡼࡥࡳࡵࡏࡍࡘ࡚ࠬࡶࡴ࡯ࡐࡎ࡙ࡔࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࡖࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠊࠊࠋࡷࠤࡂࠦࠨ࡯ࡱࡺ࠯ࡨࡧࡣࡩࡧࡳࡩࡷ࡯࡯ࡥ࠮ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪ࠮ࡶࡸࡷ࠮ࡳࡦࡴࡹࡩࡷࡹࡌࡊࡕࡗ࠭࠱ࡹࡴࡳࠪࡸࡶࡱࡒࡉࡔࡖࠬ࠭ࠏࠏࠉࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠦࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡶࡩࡷࡼࡥࡳࡵࡦࡥࡨ࡮ࡥࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿࠭ࡁࠬࠦ࠱ࡺࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠨࡺ࠲ࠡ࠿ࠣࡸ࡮ࡳࡥ࠯ࡶ࡬ࡱࡪ࠮ࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡒࡔ࡚ࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠪࡰࡩࡸࡹࡡࡨࡧ࠯ࡷࡹࡸࠨࡪࡰࡷࠬࡹ࠸࠭ࡵ࠳ࠬ࠭࠰࠭ࠠ࡮ࡵࠪ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠦࡳࡦࡴࡹࡩࡷࡹࡌࡊࡕࡗ࠰ࡺࡸ࡬ࡍࡋࡖࡘࠏࠐࡤࡦࡨࠣࡗࡊࡘࡖࡆࡔࡖࡣࡔࡒࡄࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡴࡻࡲࡤࡧࡀࠫࠬ࠯࠺ࠋࠋࡶࡩࡷࡼࡥࡳࡵࡏࡍࡘ࡚ࠬࡶࡴ࡯ࡐࡎ࡙ࡔ࠭ࡷࡱ࡯ࡳࡵࡷ࡯ࡎࡌࡗ࡙࠲ࡳࡦࡴࡹࡩࡷࡹࡄࡊࡅࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡ࠱ࡡ࡝࠭࡝ࡠࠎࠎࠩ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡰ࡮ࡹࡴࠩࡵࡨࡸ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩࠪࠌࠌࠧࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ࠰ࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩࠋࠋࠦ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࡁࠥ࠳࠱ࠡ࠼ࠣࡶࡪࡺࡵࡳࡰࠣࠫࠬࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬ࠢ࡬ࡲࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚࠺ࠋࠋࠌ࡭࡫ࠦ࡬ࡪࡰ࡮ࡁࡂ࠭ࠧ࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࡳࡦࡴࡹࡩࡷࡔࡁࡎࡇࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡆࡈࡌࡆࠪ࡯࡭ࡳࡱࠬࡴࡱࡸࡶࡨ࡫ࠩࠋࠋࠌࡷࡪࡸࡶࡦࡴࡶࡈࡎࡉࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠢ࡞ࡷࡪࡸࡶࡦࡴࡑࡅࡒࡋࠬ࡭࡫ࡱ࡯ࡢࠦࠩࠋࠋࡶࡳࡷࡺࡥࡥࡆࡌࡇ࡙ࠦ࠽ࠡࡵࡲࡶࡹ࡫ࡤࠩࡵࡨࡶࡻ࡫ࡲࡴࡆࡌࡇ࡙࠲ࠠࡳࡧࡹࡩࡷࡹࡥ࠾ࡖࡵࡹࡪ࠲ࠠ࡬ࡧࡼࡁࡱࡧ࡭ࡣࡦࡤࠤࡰ࡫ࡹ࠻ࠢ࡮ࡩࡾࡡ࠰࡞ࠫࠍࠍ࡫ࡵࡲࠡࡵࡨࡶࡻ࡫ࡲ࠭࡮࡬ࡲࡰࠦࡩ࡯ࠢࡶࡳࡷࡺࡥࡥࡆࡌࡇ࡙ࡀࠊࠊࠋࡶࡩࡷࡼࡥࡳࠢࡀࠤࡸ࡫ࡲࡷࡧࡵ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠥࠨ࠮ࠪࠫ࠮ࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࡴࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡳࡦࡴࡹࡩࡷ࠯ࠊࠊࠋࡸࡶࡱࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠧࡱ࡯࡮ࡦࡵࠣࡁࠥࡲࡥ࡯ࠪࡸࡲࡰࡴ࡯ࡸࡰࡏࡍࡘ࡚ࠩࠋࠋࠦ࡭࡫ࠦ࡬ࡪࡰࡨࡷࡃ࠶࠺ࠋࠋࠦࠍࡲ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨ࡞࡟ࡲࠬࠐࠉࠤࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࠠࡶࡰ࡮ࡲࡴࡽ࡮ࡍࡋࡖࡘ࠿ࠐࠉࠤࠋࠌࡱࡪࡹࡳࡢࡩࡨࠤ࠰ࡃࠠ࡭࡫ࡱ࡯ࠥ࠱ࠠࠨ࡞࡟ࡲࠬࠐࠉࠤࠋࡶࡹࡧࡰࡥࡤࡶࠣࡁࠥ࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡓࡧࡶࡳࡱࡼࡥࡳࡵࠣࡁࠥ࠭ࠠࠬࠢࡶࡸࡷ࠮࡬ࡪࡰࡨࡷ࠮ࠐࠉࠤࠋࡵࡩࡸࡻ࡬ࡵࠢࡀࠤࡘࡋࡎࡅࡡࡈࡑࡆࡏࡌࠩࡵࡸࡦ࡯࡫ࡣࡵ࠮ࡰࡩࡸࡹࡡࡨࡧ࠯ࡊࡦࡲࡳࡦ࠮ࠪࠫ࠱࠭ࡆࡓࡑࡐ࠱ࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨ࠭ࡶࡳࡺࡸࡣࡦࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕ࠮ࡸࡶࡱࡒࡉࡔࡖࠍࠦࠧࠨ䖄")
def	l11l1ll1l11_l1_(url,source):
	#url = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡂࡢ࡙ࡢ࡮ࡪࡴ࡯ࡻࡍࡦࠫ䖅")
	errortrace = l1l1l1_l1_ (u"ࠫࠬ䖆")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11ll11l11l_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: errortrace = str(error)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䖇"),l1l1l1_l1_ (u"࠭ࠧ䖈"),l1l1l1_l1_ (u"ࠧࠨ䖉"),str(results))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䖊"),l1l1l1_l1_ (u"ࠩࠪ䖋"),l1l1l1_l1_ (u"ࠪࠫ䖌"),str(errortrace))
	# resolveurl l11ll1l1l1_l1_ fail l1lll1ll1lll_l1_ with l1lll111111l_l1_ error or l111l11ll11_l1_ value False
	if not results:
		if errortrace==l1l1l1_l1_ (u"ࠫࠬ䖍"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䖎"),l1l1l1_l1_ (u"࠭ࠧ䖏"),l1l1l1_l1_ (u"ࠧࠨ䖐"),str(errortrace))
		l11lll1l1l1_l1_ = l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠠࡇࡣ࡬ࡰࡪࡪࠧ䖑")
		l11lll1l1l1_l1_ += l1l1l1_l1_ (u"ࠩࠣࠫ䖒")+errortrace.splitlines()[-1]
		return l11lll1l1l1_l1_,[],[]
	return l1l1l1_l1_ (u"ࠪࠫ䖓"),[l1l1l1_l1_ (u"ࠫࠬ䖔")],[results]
def	l11lll1l11l_l1_(url,source):
	#url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡄࡤ࡛ࡤࡰࡥ࡯ࡱࡽࡏࡨ࠭䖕")
	#url = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠵ࡶࡪࡦࡨࡳ࠴ࡾ࠷ࡺࡻ࠷࠵ࡸ࠭䖖")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䖗"),l1l1l1_l1_ (u"ࠨࠩ䖘"),url,l1l1l1_l1_ (u"ࠩࠪ䖙"))
	#return l1l1l1_l1_ (u"ࠪࠫ䖚"),[],[]
	errortrace = l1l1l1_l1_ (u"ࠫࠬ䖛")
	results = False
	try:
		import youtube_dl
		l11ll1ll11l_l1_ = youtube_dl.YoutubeDL({l1l1l1_l1_ (u"ࠬࡴ࡯ࡠࡥࡲࡰࡴࡸࠧ䖜"): True})
		results = l11ll1ll11l_l1_.extract_info(url,download=False)
	except Exception as error: errortrace = str(error)
	# youtube_dl l11ll1l1l1_l1_ fail l1lll1ll1lll_l1_ with l1lll111111l_l1_ error or l111l11ll11_l1_ value False
	if not results or l1l1l1_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ䖝") not in list(results.keys()):
		if errortrace==l1l1l1_l1_ (u"ࠧࠨ䖞"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䖟"),l1l1l1_l1_ (u"ࠩࠪ䖠"),l1l1l1_l1_ (u"ࠪࠫ䖡"),errortrace)
		l11lll1l1l1_l1_ = l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠣࡊࡦ࡯࡬ࡦࡦࠪ䖢")
		l11lll1l1l1_l1_ += l1l1l1_l1_ (u"ࠬࠦࠧ䖣")+errortrace.splitlines()[-1]
		return l11lll1l1l1_l1_,[],[]
	else:
		l1111ll_l1_,l11l1_l1_ = [],[]
		for l111ll_l1_ in results[l1l1l1_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ䖤")]:
			l1111ll_l1_.append(l111ll_l1_[l1l1l1_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࠧ䖥")])
			l11l1_l1_.append(l111ll_l1_[l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ䖦")])
		return l1l1l1_l1_ (u"ࠩࠪ䖧"),l1111ll_l1_,l11l1_l1_
def l11ll1l1lll_l1_(url):
	if l1l1l1_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䖨") in url:
		l1111ll_l1_,l11l1_l1_ = l1l1ll1ll1_l1_(url)
		if l11l1_l1_: return l1l1l1_l1_ (u"ࠫࠬ䖩"),l1111ll_l1_,l11l1_l1_
		return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡎࡄࡖࡆࡈࠧ䖪"),[],[]
	return l1l1l1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䖫"),[l1l1l1_l1_ (u"ࠧࠨ䖬")],[url]
def l1ll1l1ll11_l1_(url):
	DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䖭"),l1l1l1_l1_ (u"ࠩࠪ䖮"),l1l1l1_l1_ (u"ࠪࠫ䖯"),url)
	l111l11_l1_,l1111l11lll_l1_ = [],[]
	if l1l1l1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷ࠳ࡳࡰ࠵ࡁࡹ࡭ࡩࡃࠧ䖰") in url:
		# l111lll111l_l1_:
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1lll1lllll1_l1_.html
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1l1ll1lll_l1_.l111lll1_l1_?l1ll1l1l1l1_l1_=49e3a27b4
		# l11111l111l_l1_: l1ll1lll_l1_://l111l1l1111_l1_.l111l1l111_l1_.l1ll1llll1l1_l1_.l111l1ll1l_l1_/15/items/40animeHD/l111l11l111_l1_.l111lll1_l1_
		# l111lll111l_l1_:
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1lllll11l11_l1_-l111l1lllll_l1_.html
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1l1ll1lll_l1_.l111lll1_l1_?l1ll1l1l1l1_l1_=l1lll11l1lll_l1_
		# l11111l111l_l1_: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l1l1ll1lll_l1_/l1111lll11l_l1_%20.l111lll1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ䖱"),url,l1l1l1_l1_ (u"࠭ࠧ䖲"),l1l1l1_l1_ (u"ࠧࠨ䖳"),False,l1l1l1_l1_ (u"ࠨࠩ䖴"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫ䖵"))
		if l1l1l1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䖶") in response.headers:
			l111ll_l1_ = response.headers[l1l1l1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䖷")]
			l111l11_l1_.append(l111ll_l1_)
			server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䖸"))
			l1111l11lll_l1_.append(server)
	elif l1l1l1_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ䖹") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l111lll111l_l1_:
		# url: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11ll11lll1_l1_.html
		# l111ll_l1_: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1lll11l1ll1_l1_/l11ll1lll11_l1_/?l111ll_l1_=l1ll1lll_l1_://drive.l1lll1ll1l1l_l1_.l1lll1l11_l1_/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l1llll11_l1_&l1lll111llll_l1_=
		# l111lll111l_l1_:
		# url: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l111ll_l1_: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1lll11l1ll1_l1_/l11ll1l1l_l1_.l1llll111l_l1_?url=l1lll11111ll_l1_==&sub=l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l111llll111_l1_/l1lll11111l1_l1_.l1lll11lll1l_l1_&l1lll111llll_l1_=l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l1llll11l11l_l1_/l1ll1ll1ll11_l1_-1.l1llll1llll1_l1_
		# l111lll111l_l1_:
		# url: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1111ll1ll1_l1_.html
		# l111ll_l1_: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1lll11l1ll1_l1_/l11111lll1l_l1_/?url=l1ll1lll_l1_://l1lllll1l111_l1_.l11ll111l1l_l1_.l111ll1ll1l_l1_.l11lllllll1_l1_/l111l11llll_l1_&sub=&l1lll111llll_l1_=http://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l1llll11l11l_l1_/4723b8ebe-1.l1llll1llll1_l1_
		# l111lll111l_l1_:
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11ll1l1l1l_l1_.html
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1lll11l1ll1_l1_/l11ll1lll11_l1_/?l111ll_l1_=l1ll1lll_l1_://l111llllll1_l1_.l1lll1ll1l1l_l1_.l1lll1l11_l1_/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l1llll11_l1_&sub=&l1lll111llll_l1_=l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l1llll11l11l_l1_/2e8bc4c34-1.l1llll1llll1_l1_
		# l111lll111l_l1_:
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1llllll11ll_l1_.html
		# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1lll11l1ll1_l1_/l11ll1lll11_l1_/?l111ll_l1_=l1ll1lll_l1_://drive.l1lll1ll1l1l_l1_.l1lll1l11_l1_/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1lllll1_l1_=l11l1lll1ll_l1_&l1lll111llll_l1_=l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l1llll11l11l_l1_/l111lll1111_l1_-1.l1llll1llll1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ䖺"),url,l1l1l1_l1_ (u"ࠨࠩ䖻"),l1l1l1_l1_ (u"ࠩࠪ䖼"),l1l1l1_l1_ (u"ࠪࠫ䖽"),l1l1l1_l1_ (u"ࠫࠬ䖾"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠶ࡳࡪࠧ䖿"))
		html = response.content
		l111111llll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪࠫ࠱ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭䗀"),html,re.DOTALL)
		#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ䗁"),str(l111111llll_l1_))
		if l111111llll_l1_:
			l111111llll_l1_ = l111111llll_l1_[0]
			l1llll1l1l11_l1_ = l1lllll1111l_l1_(l111111llll_l1_)
			#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ䗂"),str(l1llll1l1l11_l1_))
			l1llll11l1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠲ࠧ䗃"),l1llll1l1l11_l1_,re.DOTALL)
			if l1llll11l1l1_l1_:
				l1llll11l1l1_l1_ = l1llll11l1l1_l1_[0]
				l1llll11l1l1_l1_ = EVAL(l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䗄"),l1llll11l1l1_l1_)
				for dict in l1llll11l1l1_l1_:
					l111ll_l1_ = dict[l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡦࠩ䗅")]
					l11ll111_l1_ = dict[l1l1l1_l1_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ䗆")]
					#l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩ䗇")+l11ll111_l1_
					l111l11_l1_.append(l111ll_l1_)
					server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䗈"))
					l1111l11lll_l1_.append(l11ll111_l1_+l1l1l1_l1_ (u"ࠨࠢࠪ䗉")+server)
		elif l1l1l1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䗊") in response.headers:
			l111ll_l1_ = response.headers[l1l1l1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䗋")]
			l111l11_l1_.append(l111ll_l1_)
			server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䗌"))
			l1111l11lll_l1_.append(server)
		# l111lll111l_l1_: 5
		# url: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1111ll1ll1_l1_.html
		# l111ll_l1_: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1lll11l1ll1_l1_/l11111lll1l_l1_/?url=l1ll1lll_l1_://l1lllll1l111_l1_.l11ll111l1l_l1_.l111ll1ll1l_l1_.l11lllllll1_l1_/l111l11llll_l1_&sub=&l1lll111llll_l1_=http://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1lll1l11lll_l1_/l1llll11l11l_l1_/4723b8ebe-1.l1llll1llll1_l1_
		if l1l1l1_l1_ (u"ࠬࡅࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࡲࡳࠬ䗍") in url:
			l111ll_l1_ = url.split(l1l1l1_l1_ (u"࠭࠿ࡶࡴ࡯ࡁࠬ䗎"))[1]
			l111ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠧࠧࠩ䗏"))[0]
			if l111ll_l1_:
				l111l11_l1_.append(l111ll_l1_)
				l1111l11lll_l1_.append(l1l1l1_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳࠡࡩࡲࡳ࡬ࡲࡥࠨ䗐"))
	else:
		# l111lll111l_l1_:
		# url: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1lll111lll1_l1_.html
		# l111ll_l1_: http://ok.l111ll1lll1_l1_/l11l111lll1_l1_/1676019108395
		# l111lll111l_l1_:
		# url: l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1lll11l1l1l_l1_.html
		# l111ll_l1_: l1ll1lll_l1_://drive.l1lll1ll1l1l_l1_.l1lll1l11_l1_/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l1llll11_l1_
		l111l11_l1_.append(url)
		server = SERVER(url,l1l1l1_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䗑"))
		l1111l11lll_l1_.append(server)
	if not l111l11_l1_: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ䗒"),[],[]
	elif len(l111l11_l1_)==1: l111ll_l1_ = l111l11_l1_[0]
	else:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ䗓"),l1111l11lll_l1_)
		if selection==-1: return l1l1l1_l1_ (u"ࠬࡋࡘࡊࡖࠪ䗔"),[],[]
		l111ll_l1_ = l111l11_l1_[selection]
	return l1l1l1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䗕"),[l1l1l1_l1_ (u"ࠧࠨ䗖")],[l111ll_l1_]
def l111l1ll11l_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䗗"),l1l1l1_l1_ (u"ࠩࠪ䗘"),l1l1l1_l1_ (u"ࠪࠫ䗙"),url)
	# l1ll1lll_l1_://l1lllll1l111_l1_.l11ll111l1l_l1_.l111ll1ll1l_l1_.l11lllllll1_l1_/l111l11llll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䗚"),url,l1l1l1_l1_ (u"ࠬ࠭䗛"),l1l1l1_l1_ (u"࠭ࠧ䗜"),l1l1l1_l1_ (u"ࠧࠨ䗝"),l1l1l1_l1_ (u"ࠨࠩ䗞"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨ䗟"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧ䗠"),html,re.DOTALL)
	if l111ll_l1_:
		l111ll_l1_,l11ll111_l1_ = l111ll_l1_[0]
		return l1l1l1_l1_ (u"ࠫࠬ䗡"),[l11ll111_l1_],[l111ll_l1_]
	return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠭䗢"),[],[]
def l1lllll1lll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䗣"),l1l1l1_l1_ (u"ࠧࠨ䗤"),l1l1l1_l1_ (u"ࠨࠩ䗥"),url)
	#url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡱࡱࡩ࠴ࡼࡩࡥࡧࡲࡣࡵࡲࡡࡺࡧࡵࡃࡺ࡯ࡤ࠾࠲ࠩࡺ࡮ࡪ࠽ࡧࡨࡥ࠻࠵࠾ࡣ࠲࠻࠵ࡧ࠷࠾ࡤ࠲࠳࠵࠴࠷ࡧࡤ࠲࠺ࡧࡨ࠶࠸ࡣ࠷࠺࠳࠺ࠬ䗦")
	#url = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡳࡦ࡮࡫ࡨ࠲࡫࡭ࡣࡧࡧ࠲ࡸࡩࡤ࡯࠰ࡷࡳ࠴ࡼࡩࡥࡧࡲࡣࡵࡲࡡࡺࡧࡵࡃࡺ࡯ࡤ࠾࠲ࠩࡺ࡮ࡪ࠽ࡣ࠲࠴࠹࠾࠶࠴ࡢ࠺ࡤࡧ࡫࠽࠹࠶࠸ࡧ࠵ࡪ࠽࠶࠴࠲ࡥࡩ࠶࠽࠶࠶࠺࠺࠷ࠬ䗧")
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䗨"),url,l1l1l1_l1_ (u"ࠬ࠭䗩"),l1l1l1_l1_ (u"࠭ࠧ䗪"),l1l1l1_l1_ (u"ࠧࠨ䗫"),l1l1l1_l1_ (u"ࠨࠩ䗬"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡔࡇࡏࡌࡉ࠷࠭࠲ࡵࡷࠫ䗭"))
	html = response.content
	html = l1lll11lll_l1_(html)
	#WRITE_THIS(l1l1l1_l1_ (u"ࠪࠫ䗮"),html)
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䗯"),html,re.DOTALL)
	if l111ll_l1_: return l1l1l1_l1_ (u"ࠬ࠭䗰"),[l1l1l1_l1_ (u"࠭ࠧ䗱")],[l111ll_l1_[0]]
	return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ䗲"),[],[]
def l111l111l_l1_(url):
	if l1l1l1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䗳") in url:
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭䗴"),url,l1l1l1_l1_ (u"ࠪࠫ䗵"),l1l1l1_l1_ (u"ࠫࠬ䗶"),l1l1l1_l1_ (u"ࠬ࠭䗷"),l1l1l1_l1_ (u"࠭ࠧ䗸"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁ࠵ࡗ࠰࠵ࡸࡺࠧ䗹"))
		html = response.content
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䗺"),html,re.DOTALL)
		l111ll_l1_ = l111ll_l1_[0]
		if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䗻") in l111ll_l1_: return l1l1l1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䗼"),[l1l1l1_l1_ (u"ࠫࠬ䗽")],[l111ll_l1_]
		return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅ࠹࡛ࠧ䗾"),[],[]
	else: return l1l1l1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䗿"),[l1l1l1_l1_ (u"ࠧࠨ䘀")],[url]
def l111l11l1l_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l1l1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䘁"):l1l1l1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䘂"),l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䘃"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䘄")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ䘅"),url2,data2,headers2,l1l1l1_l1_ (u"࠭ࠧ䘆"),l1l1l1_l1_ (u"ࠧࠨ䘇"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡏࡑ࡚࠱࠶ࡹࡴࠨ䘈"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䘉"),html,re.DOTALL)
	if not l111ll_l1_: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡐࡒ࡛ࠬ䘊"),[],[]
	l111ll_l1_ = l111ll_l1_[0]
	return l1l1l1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䘋"),[l1l1l1_l1_ (u"ࠬ࠭䘌")],[l111ll_l1_]
def l1lll1l11ll1_l1_(url):
	headers = {l1l1l1_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䘍"):l1l1l1_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䘎")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ䘏"),url,l1l1l1_l1_ (u"ࠩࠪ䘐"),headers,l1l1l1_l1_ (u"ࠪࠫ䘑"),l1l1l1_l1_ (u"ࠫࠬ䘒"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡓࡔࡌࡐࡓࡑ࠰࠵ࡸࡺࠧ䘓"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䘔"),html,re.DOTALL|re.IGNORECASE)
	if not l111ll_l1_: return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡔࡕࡆࡑࡔࡒࠫ䘕"),[],[]
	l111ll_l1_ = l111ll_l1_[0]
	return l1l1l1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䘖"),[l1l1l1_l1_ (u"ࠩࠪ䘗")],[l111ll_l1_]
def l1lll111lll_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䘘"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䘙")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ䘚"),url2,data2,headers2,l1l1l1_l1_ (u"࠭ࠧ䘛"),l1l1l1_l1_ (u"ࠧࠨ䘜"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡍࡇࡌࡂࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ䘝"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ䘞"),html,re.DOTALL|re.IGNORECASE)
	if not l111ll_l1_: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡎࡁࡍࡃࡆࡍࡒࡇࠧ䘟"),[],[]
	l111ll_l1_ = l111ll_l1_[0]
	if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䘠") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ䘡")+l111ll_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䘢"),l1l1l1_l1_ (u"ࠧࠨ䘣"),l1l1l1_l1_ (u"ࠨࠩ䘤"),l111ll_l1_)
	return l1l1l1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䘥"),[l1l1l1_l1_ (u"ࠪࠫ䘦")],[l111ll_l1_]
def l1lllll1ll_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l1l1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䘧"):l1l1l1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䘨")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ䘩"),url2,data2,headers2,l1l1l1_l1_ (u"ࠧࠨ䘪"),l1l1l1_l1_ (u"ࠨࠩ䘫"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡄࡆࡉࡕ࠭࠲ࡵࡷࠫ䘬"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ䘭"),html,re.DOTALL|re.IGNORECASE)
	if not l111ll_l1_: return l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡅࡇࡊࡏࠨ䘮"),[],[]
	l111ll_l1_ = l111ll_l1_[0]
	return l1l1l1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䘯"),[l1l1l1_l1_ (u"࠭ࠧ䘰")],[l111ll_l1_]
def l111l1111l1_l1_(url):
	#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨ䘱"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ䘲"),url,l1l1l1_l1_ (u"ࠩࠪ䘳"),l1l1l1_l1_ (u"ࠪࠫ䘴"),l1l1l1_l1_ (u"ࠫࠬ䘵"),l1l1l1_l1_ (u"ࠬ࠭䘶"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬ䘷"))
	html = response.content
	l1ll1ll1ll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ䘸"),html,re.DOTALL|re.IGNORECASE)
	if l1ll1ll1ll1l_l1_:
		l1ll1ll1ll1l_l1_ = l1ll1ll1ll1l_l1_[0][2:]
		#l1ll1ll1ll1l_l1_ = l1ll1ll1ll1l_l1_.decode(l1l1l1_l1_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ䘹"))
		l1ll1ll1ll1l_l1_ = base64.b64decode(l1ll1ll1ll1l_l1_)
		if kodi_version>18.99: l1ll1ll1ll1l_l1_ = l1ll1ll1ll1l_l1_.decode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䘺"))
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䘻"),l1ll1ll1ll1l_l1_,re.DOTALL)
	else: l111ll_l1_ = l1l1l1_l1_ (u"ࠫࠬ䘼")
	if not l111ll_l1_: return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡕࡘࡉ࡙ࡓ࠭䘽"),[],[]
	l111ll_l1_ = l111ll_l1_[0]
	if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ䘾") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䘿")+l111ll_l1_
	return l1l1l1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䙀"),[l1l1l1_l1_ (u"ࠩࠪ䙁")],[l111ll_l1_]
def l1lll1l1lll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ䙂"),url,l1l1l1_l1_ (u"ࠫࠬ䙃"),l1l1l1_l1_ (u"ࠬ࠭䙄"),l1l1l1_l1_ (u"࠭ࠧ䙅"),l1l1l1_l1_ (u"ࠧࠨ䙆"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠳࠱ࡴࡶࠪ䙇"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠴࠶ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䙈"),html,re.DOTALL)
	if not l111ll_l1_: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡆࡉ࡜࡚ࡎࡖࠧ䙉"),[],[]
	l111ll_l1_ = l111ll_l1_[0]
	return l1l1l1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䙊"),[l1l1l1_l1_ (u"ࠬ࠭䙋")],[l111ll_l1_]
def l1ll111l1l_l1_(url):
	id = url.split(l1l1l1_l1_ (u"࠭࠯ࠨ䙌"))[-1]
	if l1l1l1_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ䙍") in url: url = url.replace(l1l1l1_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ䙎"),l1l1l1_l1_ (u"ࠩࠪ䙏"))
	url = url.replace(l1l1l1_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࠩ䙐"),l1l1l1_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿࡥࡳ࠱ࡰࡩࡹࡧࡤࡢࡶࡤ࠳ࠬ䙑"))
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ䙒"),url,l1l1l1_l1_ (u"࠭ࠧ䙓"),l1l1l1_l1_ (u"ࠧࠨ䙔"),l1l1l1_l1_ (u"ࠨࠩ䙕"),l1l1l1_l1_ (u"ࠩࠪ䙖"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ䙗"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ䙘"),url)
	l11lll1l1l1_l1_ = l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ䙙")
	error = re.findall(l1l1l1_l1_ (u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䙚"),html,re.DOTALL)
	if error: l11lll1l1l1_l1_ = error[0]
	url = re.findall(l1l1l1_l1_ (u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䙛"),html,re.DOTALL)
	if not url and l11lll1l1l1_l1_:
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䙜"),l1l1l1_l1_ (u"ࠩࠪ䙝"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠬ䙞"),l11lll1l1l1_l1_)
		return l11lll1l1l1_l1_,[],[]
	l111ll_l1_ = url[0].replace(l1l1l1_l1_ (u"ࠫࡡࡢࠧ䙟"),l1l1l1_l1_ (u"ࠬ࠭䙠"))
	l1l1l11l1ll_l1_,l1l1l1l11ll_l1_ = l1l1ll1ll1_l1_(l111ll_l1_)
	owner = re.findall(l1l1l1_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࠨ࠺ࡼࠤ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䙡"),html,re.DOTALL)
	if owner: l111111l111_l1_,l11ll1ll111_l1_,l11l1111l1l_l1_ = owner[0]
	else: l111111l111_l1_,l11ll1ll111_l1_,l11l1111l1l_l1_ = l1l1l1_l1_ (u"ࠧࠨ䙢"),l1l1l1_l1_ (u"ࠨࠩ䙣"),l1l1l1_l1_ (u"ࠩࠪ䙤")
	l11l1111l1l_l1_ = l11l1111l1l_l1_.replace(l1l1l1_l1_ (u"ࠪࡠ࠴࠭䙥"),l1l1l1_l1_ (u"ࠫ࠴࠭䙦"))
	l11ll1ll111_l1_ = escapeUNICODE(l11ll1ll111_l1_)
	l1111ll_l1_ = [l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ䙧")+l11ll1ll111_l1_+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䙨")]+l1l1l11l1ll_l1_
	l11l1_l1_ = [l11l1111l1l_l1_]+l1l1l1l11ll_l1_
	selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ䙩")+str(len(l11l1_l1_)-1)+l1l1l1_l1_ (u"ࠨ่่ࠢๆ࠯ࠧ䙪"),l1111ll_l1_)
	if selection==-1: return l1l1l1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䙫"),[],[]
	elif selection==0:
		new_path = sys.argv[0]+l1l1l1_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩ䙬")+l11l1111l1l_l1_+l1l1l1_l1_ (u"ࠫࠫࡺࡥࡹࡶࡀࠫ䙭")+l11ll1ll111_l1_
		#settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ䙮"),l1l1l1_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ䙯"))
		xbmc.executebuiltin(l1l1l1_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ䙰")+new_path+l1l1l1_l1_ (u"ࠣࠫࠥ䙱"))
		return l1l1l1_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䙲"),[],[]
	l111ll_l1_ =  l11l1_l1_[selection]
	return l1l1l1_l1_ (u"ࠪࠫ䙳"),[l1l1l1_l1_ (u"ࠫࠬ䙴")],[l111ll_l1_]
def l111ll1ll_l1_(l111ll_l1_):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ䙵"),l111ll_l1_,l1l1l1_l1_ (u"࠭ࠧ䙶"),l1l1l1_l1_ (u"ࠧࠨ䙷"),l1l1l1_l1_ (u"ࠨࠩ䙸"),l1l1l1_l1_ (u"ࠩࠪ䙹"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩ䙺"))
	html = response.content
	if l1l1l1_l1_ (u"ࠫ࠳ࡰࡳࡰࡰࠪ䙻") in l111ll_l1_: url = re.findall(l1l1l1_l1_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䙼"),html,re.DOTALL)
	else: url = re.findall(l1l1l1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䙽"),html,re.DOTALL)
	if not url: return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅࡓࡐࡘࡁࠨ䙾"),[],[]
	url = url[0]
	if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭䙿") not in url: url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䚀")+url
	return l1l1l1_l1_ (u"ࠪࠫ䚁"),[l1l1l1_l1_ (u"ࠫࠬ䚂")],[url]
def l11l1l1l1ll_l1_(url):
	# http://l1lllllll11l_l1_.l1lll1llll1l_l1_/l11ll1lllll_l1_.html?l11ll11l111_l1_=l1111llll11_l1_
	# http://l1lllllll11l_l1_.l1lll1llll1l_l1_/l1111l111ll_l1_?op=l1ll1lllll1l_l1_&id=l11ll1lllll_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䚃") : l1l1l1_l1_ (u"࠭ࠧ䚄") }
	if l1l1l1_l1_ (u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ䚅") in url:
		html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠨࠩ䚆"),headers,l1l1l1_l1_ (u"ࠩࠪ䚇"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬ䚈"))
		#xbmc.log(html)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䚉"),l1l1l1_l1_ (u"ࠬ࠭䚊"),url,html)
		items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䚋"),html,re.DOTALL)
		if items: return l1l1l1_l1_ (u"ࠧࠨ䚌"),[l1l1l1_l1_ (u"ࠨࠩ䚍")],[items[0]]
		else:
			message = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡶࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䚎"),html,re.DOTALL)
			if message:
				DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䚏"),l1l1l1_l1_ (u"ࠫࠬ䚐"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧ䚑"),message[0])
				return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧ䚒")+message[0],[],[]
	else:
		#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䚓"),l1l1l1_l1_ (u"ࠨࠩ䚔"),l111ll_l1_,l1l1l1_l1_ (u"ࠩࠪ䚕"))
		#url,name2 = url.split(l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䚖"))
		#name2 = name2.lower()
		name2 = l1l1l1_l1_ (u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧ䚗")
		# l1l1111ll_l1_ l1ll_l1_
		html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠬ࠭䚘"),headers,l1l1l1_l1_ (u"࠭ࠧ䚙"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࠩ䚚"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ䚛"),html,re.DOTALL)
		if not l1ll1l1_l1_: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭䚜"),[],[]
		l11111ll1_l1_ = l1ll1l1_l1_[0][0]
		block = l1ll1l1_l1_[0][1]
		if l1l1l1_l1_ (u"ࠪ࠲ࡷࡧࡲࠨ䚝") in block or l1l1l1_l1_ (u"ࠫ࠳ࢀࡩࡱࠩ䚞") in block: return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ䚟"),[],[]
		items = re.findall(l1l1l1_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䚠"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lll11l1_l1_(payload)
		html = OPENURL_CACHED(l1llll111_l1_,l11111ll1_l1_,data,headers,l1l1l1_l1_ (u"ࠧࠨ䚡"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪ䚢"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧ䚣"),html,re.DOTALL)
		if not l1ll1l1_l1_: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ䚤"),[],[]
		download = l1ll1l1_l1_[0][0]
		block = l1ll1l1_l1_[0][1]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫ䚥"),block,re.DOTALL)
		l11l11l1ll1_l1_,l1111ll_l1_,l11l1lll1l1_l1_,l11l1_l1_,l1lllll11lll_l1_ = [],[],[],[],[]
		for l111ll_l1_,title in items:
			if l1l1l1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䚦") in l111ll_l1_:
				l11l11l1ll1_l1_,l11l1lll1l1_l1_ = l1l1ll1ll1_l1_(l111ll_l1_)
				l11l1_l1_ = l11l1_l1_ + l11l1lll1l1_l1_
				if l11l11l1ll1_l1_[0]==l1l1l1_l1_ (u"࠭࠭࠲ࠩ䚧"): l1111ll_l1_.append(l1l1l1_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ䚨")+l1l1l1_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ䚩")+name2)
				else:
					for title in l11l11l1ll1_l1_:
						l1111ll_l1_.append(l1l1l1_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ䚪")+l1l1l1_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ䚫")+name2+l1l1l1_l1_ (u"ࠫࠥ࠭䚬")+title)
			else:
				title = title.replace(l1l1l1_l1_ (u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧ䚭"),l1l1l1_l1_ (u"࠭ࠧ䚮"))
				title = title.strip(l1l1l1_l1_ (u"ࠧࠣࠩ䚯"))
				#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䚰"),l1l1l1_l1_ (u"ࠩࠪ䚱"),title,str(l1lllll11lll_l1_))
				title = l1l1l1_l1_ (u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩ䚲")+l1l1l1_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ䚳")+name2+l1l1l1_l1_ (u"ࠬࠦࠧ䚴")+title
				l1111ll_l1_.append(title)
				l11l1_l1_.append(l111ll_l1_)
		# download l1ll_l1_
		l111ll_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠨ䚵") + download
		html = OPENURL_CACHED(l1llll111_l1_,l111ll_l1_,l1l1l1_l1_ (u"ࠧࠨ䚶"),headers,l1l1l1_l1_ (u"ࠨࠩ䚷"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫ䚸"))
		items = re.findall(l1l1l1_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢ䚹"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l1l1_l1_ (u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨ䚺")+l1l1l1_l1_ (u"ࠬࠦ࡭ࡱ࠶ࠣࠫ䚻")+name2+l1l1l1_l1_ (u"࠭ࠠࠨ䚼")+resolution.split(l1l1l1_l1_ (u"ࠧࡹࠩ䚽"))[1]
			l111ll_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭䚾")+id+l1l1l1_l1_ (u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ䚿")+mode+l1l1l1_l1_ (u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ䛀")+hash
			l1lllll11lll_l1_.append(resolution)
			l1111ll_l1_.append(title)
			l11l1_l1_.append(l111ll_l1_)
		l1lllll11lll_l1_ = set(l1lllll11lll_l1_)
		l1llllllll1l_l1_,l11l111l11l_l1_ = [],[]
		for title in l1111ll_l1_:
			#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䛁"),l1l1l1_l1_ (u"ࠬ࠭䛂"),title,l1l1l1_l1_ (u"࠭ࠧ䛃"))
			res = re.findall(l1l1l1_l1_ (u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢ䛄"),title+l1l1l1_l1_ (u"ࠨࠨࠩࠫ䛅"),re.DOTALL)
			for resolution in l1lllll11lll_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l1l1_l1_ (u"ࠩࡻࠫ䛆"))[1])
			l1llllllll1l_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l11l1_l1_)):
			items = re.findall(l1l1l1_l1_ (u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦ䛇"),l1l1l1_l1_ (u"ࠫࠫࠬࠧ䛈")+l1llllllll1l_l1_[i]+l1l1l1_l1_ (u"ࠬࠬࠦࠨ䛉"),re.DOTALL)
			l11l111l11l_l1_.append( [l1llllllll1l_l1_[i],l11l1_l1_[i],items[0][0],items[0][1]] )
		l11l111l11l_l1_ = sorted(l11l111l11l_l1_, key=lambda x: x[3], reverse=True)
		l11l111l11l_l1_ = sorted(l11l111l11l_l1_, key=lambda x: x[2], reverse=False)
		l1111ll_l1_,l11l1_l1_ = [],[]
		for i in range(len(l11l111l11l_l1_)):
			l1111ll_l1_.append(l11l111l11l_l1_[i][0])
			l11l1_l1_.append(l11l111l11l_l1_[i][1])
	if len(l11l1_l1_)==0: return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ䛊"),[],[]
	return l1l1l1_l1_ (u"ࠧࠨ䛋"),l1111ll_l1_,l11l1_l1_
def l11l11l11ll_l1_(url):
	# http://l1ll1lllll11_l1_.l1lll1l11_l1_/717254
	parts = url.split(l1l1l1_l1_ (u"ࠨࡁࠪ䛌"))
	url2 = parts[0]
	headers = { l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䛍") : l1l1l1_l1_ (u"ࠪࠫ䛎") }
	html = OPENURL_CACHED(l1llll111_l1_,url2,l1l1l1_l1_ (u"ࠫࠬ䛏"),headers,l1l1l1_l1_ (u"ࠬ࠭䛐"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭䛑"))
	items = re.findall(l1l1l1_l1_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ䛒"),html,re.DOTALL)
	url = items[0]
	#l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l1l1ll_l1_(url)
	#return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	return l1l1l1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䛓"),[l1l1l1_l1_ (u"ࠩࠪ䛔")],[url]
def l11111lll11_l1_(url):
	# l1ll1lll_l1_://l111lll11l_l1_.l111l1ll1l_l1_/l111llll11_l1_
	# l1ll1lll_l1_://l111l1lll1_l1_.cc/l111llll11_l1_
	l1111ll_l1_,l11l1_l1_ = [],[]
	headers = { l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䛕") : l1l1l1_l1_ (u"ࠫࠬ䛖") }
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠬ࠭䛗"),headers,l1l1l1_l1_ (u"࠭ࠧ䛘"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭䛙"))
	url2 = re.findall(l1l1l1_l1_ (u"ࠨࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡹࡷࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䛚"),html,re.DOTALL)
	if url2: return l1l1l1_l1_ (u"ࠩࠪ䛛"),[l1l1l1_l1_ (u"ࠪࠫ䛜")],[url2[0]]
	else: return l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧ䛝"),[],[]
def l11l11l1lll_l1_(url):
	# l1ll1lll_l1_://l111lll11l_l1_.l111l1ll1l_l1_/l111llll11_l1_
	# l1ll1lll_l1_://l111l1lll1_l1_.cc/l111llll11_l1_
	l1111ll_l1_,l11l1_l1_ = [],[]
	headers = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䛞") : l1l1l1_l1_ (u"࠭ࠧ䛟") }
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠧࠨ䛠"),headers,l1l1l1_l1_ (u"ࠨࠩ䛡"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ䛢"))
	url2 = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭䛣"),html,re.DOTALL)
	if url2: return l1l1l1_l1_ (u"ࠫࠬ䛤"),[l1l1l1_l1_ (u"ࠬ࠭䛥")],[url2[0]]
	else: return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙ࠧ䛦"),[],[]
def l1llllll1l1_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䛧"),l1l1l1_l1_ (u"ࠨࠩ䛨"),l1l1l1_l1_ (u"ࠩࠪ䛩"),url)
	# l1l1111ll_l1_    l1ll1lll_l1_://show.l111111ll11_l1_.l1lll1l11_l1_/l11111111l1_l1_-l1lllllllll1_l1_/l1lllllllll1_l1_-l111ll1111l_l1_.l1llll111l_l1_?action=l1lllll1l11l_l1_&l1111l_l1_=32513&l1llllll1ll_l1_=1&type=l111lll1l1_l1_
	# download l1ll1lll_l1_://show.l111111ll11_l1_.l1lll1l11_l1_/l1ll_l1_/l1lll1l1l111_l1_
	l1111ll_l1_,l11l1_l1_,errno = [],[],l1l1l1_l1_ (u"ࠪࠫ䛪")
	# l1l1111ll_l1_
	if l1l1l1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࠨ䛫") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1l1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䛬"):l1l1l1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䛭")}
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ䛮"),url2,data2,headers2,l1l1l1_l1_ (u"ࠨࠩ䛯"),l1l1l1_l1_ (u"ࠩࠪ䛰"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠵ࡲࡩ࠭䛱"))
		l1l11l11_l1_ = response.content
		url2 = re.findall(l1l1l1_l1_ (u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬ䛲"),l1l11l11_l1_,re.DOTALL)
		url2 = url2[0]
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䛳"),l1l1l1_l1_ (u"࠭ࠧ䛴"),l1l1l1_l1_ (u"ࠧࠨ䛵"),url2)
		#return
	# download
	elif l1l1l1_l1_ (u"ࠨ࠱࡯࡭ࡳࡱࡳ࠰ࠩ䛶") in url:
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭䛷"),url,l1l1l1_l1_ (u"ࠪࠫ䛸"),l1l1l1_l1_ (u"ࠫࠬ䛹"),True,l1l1l1_l1_ (u"ࠬ࠭䛺"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠷ࡳࡵࠩ䛻"))
		l1l11l11_l1_ = response.content
		if l1l1l1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䛼") in list(response.headers.keys()): url2 = response.headers[l1l1l1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䛽")]
		else: url2 = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䛾"),l1l11l11_l1_,re.DOTALL)[0]
		#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䛿"),l1l1l1_l1_ (u"ࠫࠬ䜀"),url2,str(2222))
	if l1l1l1_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䜁") in url2 or l1l1l1_l1_ (u"࠭࠯ࡧ࠱ࠪ䜂") in url2:
		url2 = url2.replace(l1l1l1_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䜃"),l1l1l1_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ䜄"))
		url2 = url2.replace(l1l1l1_l1_ (u"ࠩ࠲ࡺ࠴࠭䜅"),l1l1l1_l1_ (u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩ䜆"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䜇"),l1l1l1_l1_ (u"ࠬ࠭䜈"),url2,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ䜉"),url2,l1l1l1_l1_ (u"ࠧࠨ䜊"),l1l1l1_l1_ (u"ࠨࠩ䜋"),l1l1l1_l1_ (u"ࠩࠪ䜌"),l1l1l1_l1_ (u"ࠪࠫ䜍"),l1l1l1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠷ࡷࡪࠧ䜎"))
		l1l11l11_l1_ = response.content
		items = re.findall(l1l1l1_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢ࡭ࡣࡥࡩࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䜏"),l1l11l11_l1_,re.DOTALL)
		if items:
			for l111ll_l1_,title in items:
				l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"࠭࡜࡝ࠩ䜐"),l1l1l1_l1_ (u"ࠧࠨ䜑"))
				l1111ll_l1_.append(title)
				l11l1_l1_.append(l111ll_l1_)
		else:
			items = re.findall(l1l1l1_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䜒"),l1l11l11_l1_,re.DOTALL)
			if items:
				l111ll_l1_ = items[0]
				l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠩ࡟ࡠࠬ䜓"),l1l1l1_l1_ (u"ࠪࠫ䜔"))
				l1111ll_l1_.append(l1l1l1_l1_ (u"ࠫࠬ䜕"))
				l11l1_l1_.append(l111ll_l1_)
	else: return l1l1l1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䜖"),[l1l1l1_l1_ (u"࠭ࠧ䜗")],[url2]
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䜘"),l1l1l1_l1_ (u"ࠨࠩ䜙"),str(data2),url2)
	if len(l11l1_l1_)==0: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ䜚"),[],[]
	return l1l1l1_l1_ (u"ࠪࠫ䜛"),l1111ll_l1_,l11l1_l1_
def l1l1l11l11l_l1_(url):
	# l1l1111ll_l1_ l111lll1_l1_  l1ll1lll_l1_://l1111ll11l1_l1_.l11l1lll111_l1_.l111l1ll1l_l1_/l1llll1lll1l_l1_/l1ll1ll1l11l_l1_.l1llll111l_l1_?s=07&id=l11lll1ll1l_l1_,&img=2wh9shmvcTypozADtS8EpvgrwWS.l1llll1llll1_l1_&l111lllllll_l1_=l1lll111ll11_l1_&l11111l1ll1_l1_=l1ll1lll1l1l_l1_
	# l1l1111ll_l1_ l111111l_l1_ l1ll1lll_l1_://l11l1llll1l_l1_.l11l1lll111_l1_.l111l1ll1l_l1_/l1llll1lll1l_l1_/l1lll11ll1l1_l1_.l1llll111l_l1_?l11l11lllll_l1_=l1lllllll1l1_l1_&l111l11l11l_l1_=8a26a6cc61a884e89076504130c71626&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1llll1llll1_l1_&l111lllllll_l1_=l1lll111ll11_l1_&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1llll1llll1_l1_&l111lllllll_l1_=l1lll111ll11_l1_&l11111l1ll1_l1_=l1llll111lll_l1_
	# download l1ll1lll_l1_://l1ll1l1ll1l_l1_.l11l1l1l1l1_l1_.l11111111ll_l1_/l11l1111ll1_l1_?server=l1lll11ll111_l1_&id=l11l11ll1l1_l1_,,
	# l11ll1l1l_l1_ l1ll1lll_l1_://l11l1l1l1l1_l1_.l1llll1l1l_l1_/l11ll1l1l_l1_/l111lll1lll_l1_
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䜜"),url,l1l1l1_l1_ (u"ࠬ࠭䜝"),l1l1l1_l1_ (u"࠭ࠧ䜞"),l1l1l1_l1_ (u"ࠧࠨ䜟"),l1l1l1_l1_ (u"ࠨࠩ䜠"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩ䜡"))
	html = response.content
	l1111ll_l1_,l11l1_l1_,errno = [],[],l1l1l1_l1_ (u"ࠪࠫ䜢")
	if l1l1l1_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ䜣") in url or l1l1l1_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭䜤") in url:
		if l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ䜥") in url:
			url2 = re.findall(l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䜦"),html,re.DOTALL)
			url2 = url2[0]
		else: url2 = url
		if l1l1l1_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ䜧") not in url2: return l1l1l1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䜨"),[l1l1l1_l1_ (u"ࠪࠫ䜩")],[url2]
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䜪"),url2,l1l1l1_l1_ (u"ࠬ࠭䜫"),l1l1l1_l1_ (u"࠭ࠧ䜬"),l1l1l1_l1_ (u"ࠧࠨ䜭"),l1l1l1_l1_ (u"ࠨࠩ䜮"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠸࡮ࡥࠩ䜯"))
		html = response.content
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࡮ࡸ࠭䜰"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䜱"),block,re.DOTALL)
		if items:
			for l111ll_l1_,l111111l1l1_l1_ in items:
				l1111ll_l1_.append(l111111l1l1_l1_)
				l11l1_l1_.append(l111ll_l1_)
	elif l1l1l1_l1_ (u"ࠬࡳࡡࡪࡰࡢࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶࠧ䜲") in url:
		url2 = re.findall(l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࡀࠬ࠳࠰࠿ࠪࠤࠪ䜳"),html,re.DOTALL)
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ䜴"),url2,l1l1l1_l1_ (u"ࠨࠩ䜵"),l1l1l1_l1_ (u"ࠩࠪ䜶"),l1l1l1_l1_ (u"ࠪࠫ䜷"),l1l1l1_l1_ (u"ࠫࠬ䜸"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬ䜹"))
		html = response.content
		url3 = re.findall(l1l1l1_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䜺"),html,re.DOTALL)
		url3 = url3[0]
		l1111ll_l1_.append(l1l1l1_l1_ (u"ࠧࠨ䜻"))
		l11l1_l1_.append(url3)
	elif l1l1l1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨ䜼") in url:
		url2 = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䜽"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			return l1l1l1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䜾"),[l1l1l1_l1_ (u"ࠫࠬ䜿")],[url2]
	if len(l11l1_l1_)==0: return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑ࡙ࡗ࠹࡛ࠧ䝀"),[],[]
	return l1l1l1_l1_ (u"࠭ࠧ䝁"),l1111ll_l1_,l11l1_l1_
def l11l1lll1l_l1_(url):
	# l1ll1lll_l1_://l11l11ll11l_l1_.l1111lll1l1_l1_/l11ll1111l1_l1_?call=l111llll1l1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11ll11l111_l1_=l1111lll111_l1_
	# l1ll1lll_l1_://l11l11ll11l_l1_.l1111lll1l1_l1_/l11ll1111l1_l1_?call=l111llll1l1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11ll11l111_l1_=l111111111l_l1_
	url2 = url.split(l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䝂"),1)[0].strip(l1l1l1_l1_ (u"ࠨࡁࠪ䝃")).strip(l1l1l1_l1_ (u"ࠩ࠲ࠫ䝄")).strip(l1l1l1_l1_ (u"ࠪࠪࠬ䝅"))
	l1111ll_l1_,l11l1_l1_,items,url3 = [],[],[],l1l1l1_l1_ (u"ࠫࠬ䝆")
	headers = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䝇"):l1l1l1_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭䝈") }
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ䝉"),url2,l1l1l1_l1_ (u"ࠨࠩ䝊"),headers,True,l1l1l1_l1_ (u"ࠩࠪ䝋"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫ䝌"))
	if l1l1l1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䝍") in list(response.headers.keys()): url3 = response.headers[l1l1l1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䝎")]
	#response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ䝏"),url3,l1l1l1_l1_ (u"ࠧࠨ䝐"),headers,False,l1l1l1_l1_ (u"ࠨࠩ䝑"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠲࡯ࡦࠪ䝒"))
	#if l1l1l1_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䝓") in response.headers: url3 = response.headers[l1l1l1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䝔")]
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䝕"),l1l1l1_l1_ (u"࠭ࠧ䝖"),url3,response.content)
	if l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࠬ䝗") in url3:
		# l1ll1lll_l1_://l11ll11l11_l1_.top/f/l111ll11ll1_l1_/?l1l1111lll_l1_=l11lllll11l_l1_
		# l1ll1lll_l1_://l11ll11l11_l1_.top/v/l111ll11ll1_l1_/?l1l1111lll_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䝘") in url: url3 = url3.replace(l1l1l1_l1_ (u"ࠩ࠲ࡪ࠴࠭䝙"),l1l1l1_l1_ (u"ࠪ࠳ࡻ࠵ࠧ䝚"))
		l11ll11ll1l_l1_ = url2.split(l1l1l1_l1_ (u"ࠫࡄࡖࡈࡑࡕࡌࡈࡂ࠭䝛"))[1]
		headers = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䝜"):headers[l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䝝")] , l1l1l1_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ䝞"):l1l1l1_l1_ (u"ࠨࡒࡋࡔࡘࡏࡄ࠾ࠩ䝟")+l11ll11ll1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭䝠"),url3,l1l1l1_l1_ (u"ࠪࠫ䝡"),headers,False,l1l1l1_l1_ (u"ࠫࠬ䝢"),l1l1l1_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䝣"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1llll111_l1_,url3,l1l1l1_l1_ (u"࠭ࠧ䝤"),headers,l1l1l1_l1_ (u"ࠧࠨ䝥"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠹ࡲࡥࠩ䝦"))
		if l1l1l1_l1_ (u"ࠩ࠲ࡪ࠴࠭䝧") in url3: items = re.findall(l1l1l1_l1_ (u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䝨"),html,re.DOTALL)
		elif l1l1l1_l1_ (u"ࠫ࠴ࡼ࠯ࠨ䝩") in url3: items = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䝪"),html,re.DOTALL)
		if items: return [],[l1l1l1_l1_ (u"࠭ࠧ䝫")],[ items[0] ]
		elif l1l1l1_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭䝬") in html:
			return l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫ䝭"),[],[]
	else: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬ䝮"),[],[]
	#xbmc.log(html)
def l11l11l111l_l1_(l111ll_l1_):
	# l1ll1lll_l1_://l11llllll11_l1_.l1ll1l11_l1_/?l1l11l1l_l1_=147043&l1l11lll_l1_=5
	parts = re.findall(l1l1l1_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ䝯"),l111ll_l1_+l1l1l1_l1_ (u"ࠫࠫࠬࠧ䝰"),re.DOTALL|re.IGNORECASE)
	l1l11l1l_l1_,l1l11lll_l1_ = parts[0]
	url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭䝱")+l1l11l1l_l1_+l1l1l1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䝲")+l1l11lll_l1_
	headers = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䝳"):l1l1l1_l1_ (u"ࠨࠩ䝴") , l1l1l1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䝵"):l1l1l1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䝶") }
	url2 = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠫࠬ䝷"),headers,l1l1l1_l1_ (u"ࠬ࠭䝸"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮࠳ࡶࡸࠬ䝹"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䝺"),l1l1l1_l1_ (u"ࠨࠩ䝻"),url,url2)
	#l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l1l1ll_l1_(url2)
	#return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	return l1l1l1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䝼"),[l1l1l1_l1_ (u"ࠪࠫ䝽")],[url2]
def l1l1l111lll_l1_(url):
	# l1ll1lll_l1_://l1ll1llll11l_l1_.l1l1ll111l_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111ll11l1l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l11l1111_l1_=1608181746
	server = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ䝾"))
	headers2 = {l1l1l1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䝿"):server,l1l1l1_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䞀"):l1l1l1_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䞁")}
	response = OPENURL_REQUESTS_CACHED(l1l1111lll1_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ䞂"),url,l1l1l1_l1_ (u"ࠩࠪ䞃"),headers2,l1l1l1_l1_ (u"ࠪࠫ䞄"),l1l1l1_l1_ (u"ࠫࠬ䞅"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䞆"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ䞇"),html,re.DOTALL)
	url2 = l1l1l1_l1_ (u"ࠧࠨ䞈")
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䞉"),block,re.DOTALL)
		l1111ll_l1_,l11l1_l1_ = [],[]
		for title,l111ll_l1_ in items:
			l1111ll_l1_.append(title)
			l11l1_l1_.append(l111ll_l1_)
		if len(l11l1_l1_)==1: url2 = l11l1_l1_[0]
		elif len(l11l1_l1_)>1:
			selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ䞊"), l1111ll_l1_)
			if selection==-1: return l1l1l1_l1_ (u"ࠪࠫ䞋"),[],[]
			url2 = l11l1_l1_[selection]
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䞌"),html,re.DOTALL)
		if l1ll1l1_l1_: url2 = l1ll1l1_l1_[0]
	if not url2: return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡆࡍࡒࡇࠧ䞍"),[],[]
	return l1l1l1_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䞎"),[l1l1l1_l1_ (u"ࠧࠨ䞏")],[url2]
def l1llll11l111_l1_(url):
	# l1ll1lll_l1_://l11llllll1l_l1_.l1lll1l1ll1l_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111ll11l1l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l11l1111_l1_=1608181746
	# l1ll1lll_l1_://l11llllll1l_l1_.l1111lll1l1_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l111ll11l1l_l1_=l11lll111ll_l1_&l11l11l1111_l1_=1684182121
	server = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ䞐"))
	headers2 = {l1l1l1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䞑"):server,l1l1l1_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ䞒"):l1l1l1_l1_ (u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫ䞓")}
	response = OPENURL_REQUESTS_CACHED(l1l1111lll1_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ䞔"),url,l1l1l1_l1_ (u"࠭ࠧ䞕"),headers2,l1l1l1_l1_ (u"ࠧࠨ䞖"),l1l1l1_l1_ (u"ࠨࠩ䞗"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ䞘"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫ䞙"),html,re.DOTALL)
	url2 = l1l1l1_l1_ (u"ࠫࠬ䞚")
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ䞛"),block,re.DOTALL)
		l1111ll_l1_,l11l1_l1_ = [],[]
		for title,l111ll_l1_ in items:
			l1111ll_l1_.append(title)
			l11l1_l1_.append(l111ll_l1_)
		if len(l11l1_l1_)==1: url2 = l11l1_l1_[0]
		elif len(l11l1_l1_)>1:
			selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ䞜"), l1111ll_l1_)
			if selection==-1: return l1l1l1_l1_ (u"ࠧࠨ䞝"),[],[]
			url2 = l11l1_l1_[selection]
	if not url2:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䞞"),html,re.DOTALL)
		if l1ll1l1_l1_: url2 = l1ll1l1_l1_[0]
	if not url2: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄࠫ䞟"),[],[]
	return l1l1l1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䞠"),[l1l1l1_l1_ (u"ࠫࠬ䞡")],[url2]
def l1l1llll_l1_(l111ll_l1_):
	# l1ll1lll_l1_://w.l1llllll11l1_l1_.l11l1l1llll_l1_/l11111111l1_l1_-content/l11lll1ll11_l1_/l1lllll1ll1l_l1_/l11l1l1ll1l_l1_/l1lllll1ll11_l1_/l1111ll111l_l1_/l1111111l1l_l1_.l1llll111l_l1_?l1l11l1l_l1_=42869&l1l11lll_l1_=4
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䞢"),l1l1l1_l1_ (u"࠭ࠧ䞣"),l111ll_l1_,html)
	parts = re.findall(l1l1l1_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䞤"),l111ll_l1_+l1l1l1_l1_ (u"ࠨࠨࠩࠫ䞥"),re.DOTALL)
	url,l1l11l1l_l1_,l1l11lll_l1_ = parts[0]
	data = {l1l1l1_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ䞦"):l1l11l1l_l1_,l1l1l1_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ䞧"):l1l11lll_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ䞨"),url,data,l1l1l1_l1_ (u"ࠬ࠭䞩"),l1l1l1_l1_ (u"࠭ࠧ䞪"),l1l1l1_l1_ (u"ࠧࠨ䞫"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪ䞬"))
	html = response.content
	url2 = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䞭"),html,re.DOTALL)[0]
	return l1l1l1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䞮"),[l1l1l1_l1_ (u"ࠫࠬ䞯")],[url2]
def l1lll1l1l1_l1_(url):
	# l1ll1lll_l1_://l11l111l1ll_l1_.l1llll1l11_l1_-l11l11ll111_l1_.l1lll1l11_l1_/l11ll1l1l_l1_.l1llll111l_l1_?l1ll1l1l1l1_l1_=l11111ll111_l1_
	# l1ll1lll_l1_://l.l1111111ll1_l1_.l11111111ll_l1_/l11ll1l1l_l1_.l1llll111l_l1_?l1ll1l1l1l1_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ䞰"),url,l1l1l1_l1_ (u"࠭ࠧ䞱"),l1l1l1_l1_ (u"ࠧࠨ䞲"),l1l1l1_l1_ (u"ࠨࠩ䞳"),l1l1l1_l1_ (u"ࠩࠪ䞴"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭䞵"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䞶"),html,re.DOTALL)
	if l111ll_l1_:
		l111ll_l1_ = l111ll_l1_[0]
		if l111ll_l1_: return l1l1l1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䞷"),[l1l1l1_l1_ (u"࠭ࠧ䞸")],[l111ll_l1_]
	return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ䞹"),[],[]
def l1llll1lll_l1_(url):
	# l1ll1lll_l1_://l1llll11ll_l1_.l1llll1l11_l1_-l1llll1l1l_l1_.l1llll1l1l_l1_/l11111111l1_l1_-content/l11lll1ll11_l1_/old/l11111_l1_/server.l1llll111l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ䞺"),url,l1l1l1_l1_ (u"ࠩࠪ䞻"),l1l1l1_l1_ (u"ࠪࠫ䞼"),l1l1l1_l1_ (u"ࠫࠬ䞽"),l1l1l1_l1_ (u"ࠬ࠭䞾"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡓ࠱࠶ࡹࡴࠨ䞿"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡋࡉࡖࡆࡓࡅࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䟀"),html,re.DOTALL)[0]
	return l1l1l1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䟁"),[l1l1l1_l1_ (u"ࠩࠪ䟂")],[l111ll_l1_]
def l1lll1l11l_l1_(url):
	# l1ll1lll_l1_://l111lll1l11_l1_.l1lll11l11ll_l1_.cc/l11111111l1_l1_-content/l11lll1ll11_l1_/l1llll111111_l1_%20Now%20New/l1lll1l11l1l_l1_.l1llll111l_l1_?action=l11l11l1l11_l1_&index=00&id=58504
	# l1ll1lll_l1_://l111ll11l11_l1_.l1lll11l11ll_l1_.l1ll1l11_l1_/l1lll1l11lll_l1_/2021/04/05/_11111ll1l1_l1_-l11llll1lll_l1_.l1ll1ll1l1ll_l1_ 200.l1lll11llll1_l1_.2020.l1lll1ll111l_l1_/[l1llll111111_l1_-l11llll1lll_l1_.l1llll1l111l_l1_] 200.l1lll11llll1_l1_.2020.l1lll1ll111l_l1_-360p.l111lll1_l1_
	l11111l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ䟃"))
	if l1l1l1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ䟄") in url:
		headers = {l1l1l1_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䟅"):l11111l1l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ䟆"),url,l1l1l1_l1_ (u"ࠧࠨ䟇"),headers,l1l1l1_l1_ (u"ࠨࠩ䟈"),l1l1l1_l1_ (u"ࠩࠪ䟉"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ䟊"))
		html = response.content
		url2 = re.findall(l1l1l1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䟋"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			if l1l1l1_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭䟌") in url2:
				url2 = url2.replace(l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ䟍"),l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ䟎"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ䟏"),url2,l1l1l1_l1_ (u"ࠩࠪ䟐"),headers,l1l1l1_l1_ (u"ࠪࠫ䟑"),l1l1l1_l1_ (u"ࠫࠬ䟒"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭䟓"))
				l1l11l11_l1_ = response.content
				items = re.findall(l1l1l1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䟔"),l1l11l11_l1_,re.DOTALL)
				l1111ll_l1_,l11l1_l1_ = [],[]
				l11111l11_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ䟕"))
				for l111ll_l1_,l11ll111_l1_ in reversed(items):
					l111ll_l1_ = l11111l11_l1_+l111ll_l1_+l1l1l1_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䟖")+l11111l11_l1_
					l1111ll_l1_.append(l11ll111_l1_)
					l11l1_l1_.append(l111ll_l1_)
				return l1l1l1_l1_ (u"ࠩࠪ䟗"),l1111ll_l1_,l11l1_l1_
			else: return l1l1l1_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䟘"),[l1l1l1_l1_ (u"ࠫࠬ䟙")],[url2]
	url2 = url+l1l1l1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䟚")+l11111l1l_l1_
	return l1l1l1_l1_ (u"࠭ࠧ䟛"),[l1l1l1_l1_ (u"ࠧࠨ䟜")],[url2]
def l111l111l11_l1_(l111ll_l1_):
	# l1ll1lll_l1_://l1lll11l11ll_l1_.l11l1l1llll_l1_/l11111111l1_l1_-content/l11lll1ll11_l1_/l11l11l11l1_l1_/l1lll1l1l11l_l1_/server.l1llll111l_l1_?l1l11l1l_l1_=42869&l1l11lll_l1_=4
	# l1ll1lll_l1_://l11ll111111_l1_.l1lll11l11ll_l1_.l1ll1l11_l1_/l1lll1l11lll_l1_/2020/08/14/_11111ll1l1_l1_-l11llll1lll_l1_.l1ll1ll1l1ll_l1_ l1lll1llll11_l1_.l1111lll1ll_l1_.2020.l1111l11l11_l1_-l111l111111_l1_/[l1llll111111_l1_-l11llll1lll_l1_.l1llll1l111l_l1_] l1lll1llll11_l1_.l1111lll1ll_l1_.2020.l1111l11l11_l1_-l111l111111_l1_-1080p.l111lll1_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䟝"),l1l1l1_l1_ (u"ࠩࠪ䟞"),url,html)
	l11111l1l_l1_ = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ䟟"))
	if l1l1l1_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ䟠") in l111ll_l1_:
		parts = re.findall(l1l1l1_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䟡"),l111ll_l1_+l1l1l1_l1_ (u"࠭ࠦࠧࠩ䟢"),re.DOTALL)
		url,l1l11l1l_l1_,l1l11lll_l1_ = parts[0]
		data = {l1l1l1_l1_ (u"ࠧࡪࡦࠪ䟣"):l1l11l1l_l1_,l1l1l1_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ䟤"):l1l11lll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䟥"),url,data,l1l1l1_l1_ (u"ࠪࠫ䟦"),l1l1l1_l1_ (u"ࠫࠬ䟧"),l1l1l1_l1_ (u"ࠬ࠭䟨"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ䟩"))
		html = response.content
		url2 = re.findall(l1l1l1_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䟪"),html,re.DOTALL)[0]
		if l1l1l1_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䟫") in url2:
			headers = {l1l1l1_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䟬"):l11111l1l_l1_,l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䟭"):l1l1l1_l1_ (u"ࠫࠬ䟮")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ䟯"),url2,l1l1l1_l1_ (u"࠭ࠧ䟰"),headers,l1l1l1_l1_ (u"ࠧࠨ䟱"),l1l1l1_l1_ (u"ࠨࠩ䟲"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ䟳"))
			l1l11l11_l1_ = response.content
			items = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䟴"),l1l11l11_l1_,re.DOTALL)
			l1111ll_l1_,l11l1_l1_ = [],[]
			l11111l11_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ䟵"))
			for l111ll_l1_,l11ll111_l1_ in reversed(items):
				l111ll_l1_ = l11111l11_l1_+l111ll_l1_+l1l1l1_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䟶")+l11111l11_l1_
				l1111ll_l1_.append(l11ll111_l1_)
				l11l1_l1_.append(l111ll_l1_)
			return l1l1l1_l1_ (u"࠭ࠧ䟷"),l1111ll_l1_,l11l1_l1_
		else: return l1l1l1_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䟸"),[l1l1l1_l1_ (u"ࠨࠩ䟹")],[url2]
	else:
		l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䟺")+l11111l1l_l1_
		return l1l1l1_l1_ (u"ࠪࠫ䟻"),[l1l1l1_l1_ (u"ࠫࠬ䟼")],[l111ll_l1_]
def l11l1llll_l1_(l111ll_l1_):
	# http://l11ll1llll1_l1_.tv/?l1l11l1l_l1_=159485&l1l11lll_l1_=0
	if l1l1l1_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ䟽") in l111ll_l1_:
		parts = re.findall(l1l1l1_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ䟾"),l111ll_l1_+l1l1l1_l1_ (u"ࠧࠧࠨࠪ䟿"),re.DOTALL|re.IGNORECASE)
		l1l11l1l_l1_,l1l11lll_l1_ = parts[0]
		host = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ䠀"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䠁"),l1l1l1_l1_ (u"ࠪࠫ䠂"),l111ll_l1_,host)
		url = host+l1l1l1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䠃")+l1l11l1l_l1_+l1l1l1_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ䠄")+l1l11lll_l1_
		headers = { l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䠅"):l1l1l1_l1_ (u"ࠧࠨ䠆") , l1l1l1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䠇"):l1l1l1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䠈") }
		url2 = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠪࠫ䠉"),headers,l1l1l1_l1_ (u"ࠫࠬ䠊"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ䠋"))
		url2 = url2.replace(l1l1l1_l1_ (u"࠭࡜࡯ࠩ䠌"),l1l1l1_l1_ (u"ࠧࠨ䠍")).replace(l1l1l1_l1_ (u"ࠨ࡞ࡵࠫ䠎"),l1l1l1_l1_ (u"ࠩࠪ䠏"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䠐"),l1l1l1_l1_ (u"ࠫࠬ䠑"),url,url2)
		#l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll1l1l1ll_l1_(url2)
		#return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
		return l1l1l1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䠒"),[l1l1l1_l1_ (u"࠭ࠧ䠓")],[url2]
	elif l1l1l1_l1_ (u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ䠔") in l111ll_l1_:
		counts = 0
		while l1l1l1_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ䠕") in l111ll_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭䠖"),l111ll_l1_,l1l1l1_l1_ (u"ࠪࠫ䠗"),l1l1l1_l1_ (u"ࠫࠬ䠘"),l1l1l1_l1_ (u"ࠬ࠭䠙"),l1l1l1_l1_ (u"࠭ࠧ䠚"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩ䠛"))
			if l1l1l1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䠜") in list(response.headers.keys()): l111ll_l1_ = response.headers[l1l1l1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䠝")]
			counts += 1
		return l1l1l1_l1_ (u"ࠪࠫ䠞"),[l1l1l1_l1_ (u"ࠫࠬ䠟")],[l111ll_l1_]
	else: return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ䠠"),[],[]
def l11lllll1_l1_(url):
	# l1ll1lll_l1_://l11111l1111_l1_.l1llll11lll1_l1_.me/l/l11lll11ll1_l1_=
	server = SERVER(url,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ䠡"))
	headers = {l1l1l1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䠢"):server,l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䠣"):l1l1l11ll_l1_()}
	if l1l1l1_l1_ (u"ࠩ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䠤") in url:
		headers2 = {l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䠥"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ䠦")}
		url2,data2 = URLDECODE(url)
		response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ䠧"),url2,data2,headers2,True,l1l1l1_l1_ (u"࠭ࠧ䠨"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠷ࡳࡵࠩ䠩"))
		html = response.content
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䠪"),html,re.DOTALL|re.IGNORECASE)
		if l111ll_l1_: return l1l1l1_l1_ (u"ࠩࠪ䠫"),[l1l1l1_l1_ (u"ࠪࠫ䠬")],[l111ll_l1_[0]]
	elif l1l1l1_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ䠭") in url:
		html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠬ࠭䠮"),headers,l1l1l1_l1_ (u"࠭ࠧ䠯"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠸࡮ࡥࠩ䠰"))
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䠱"),html,re.DOTALL)
		if l111ll_l1_: return l1l1l1_l1_ (u"ࠩࠪ䠲"),[l1l1l1_l1_ (u"ࠪࠫ䠳")],[l111ll_l1_[0]]
	else:
		l11111l11l1_l1_ = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䠴"),url,l1l1l1_l1_ (u"ࠬ࠭䠵"),headers,l1l1l1_l1_ (u"࠭ࠧ䠶"),l1l1l1_l1_ (u"ࠧࠨ䠷"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠳ࡳࡦࠪ䠸"))
		html = l11111l11l1_l1_.content
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ䠹"),html,re.DOTALL)
		if l111ll_l1_:
			l111ll_l1_ = UNQUOTE(l111ll_l1_[0])+l1l1l1_l1_ (u"ࠪࠪࡩࡃ࠱ࠨ䠺")
			response2 = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䠻"),l111ll_l1_,l1l1l1_l1_ (u"ࠬ࠭䠼"),headers,l1l1l1_l1_ (u"࠭ࠧ䠽"),l1l1l1_l1_ (u"ࠧࠨ䠾"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠴ࡵࡪࠪ䠿"))
			html = response2.content
			l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡨࡂࠨࡢࡵࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䡀"),html,re.DOTALL)
			if l111ll_l1_:
				l111ll_l1_ = UNQUOTE(l111ll_l1_[0])
				return l1l1l1_l1_ (u"ࠪࠫ䡁"),[l1l1l1_l1_ (u"ࠫࠬ䡂")],[l111ll_l1_]
		if l1l1l1_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ䡃") in list(l11111l11l1_l1_.headers.keys()):
			cookies = l11111l11l1_l1_.headers[l1l1l1_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ䡄")]
			l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡠ࡮ࡱ࡯ࡤ࠴ࠪࡀ࠿ࠫ࠲࠯ࡅࠩ࠼ࠩ䡅"),cookies,re.DOTALL)
			if l111ll_l1_:
				l111ll_l1_ = UNQUOTE(l111ll_l1_[0])
				return l1l1l1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䡆"),[l1l1l1_l1_ (u"ࠩࠪ䡇")],[l111ll_l1_]
	return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧ䡈"),[],[]
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࠤࡳࡵࡴࠡࡹࡲࡶࡰ࡯࡮ࡨࠌࠌࠍࠨࠦࡩࡵࠢࡱࡩࡪࡪࡳࠡࡥࡲࡳࡰ࡯ࡥࠡࡨࡵࡳࡲࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠍࠍࠎࠩࠠࡄࡱࡲ࡯࡮࡫࠺ࠡࡥࡩࡣࡨࡲࡥࡢࡴࡤࡲࡨ࡫࠽ࡄࡏࡨ࠲ࡍࡑࡇࡒ࡭ࡰࡻࡳ࡙ࡖࡶࡰࡽ࡚ࡎࡶࡱࡰࡹࡴࡗࡆࡠࡣࡱࡰࡉ࠻࡯ࡈࡐࡖࡑࡔࡦ࡞ࡈࡆ࠱࠯࠴࠺࠻࠹࠱࠲࠴࠳࠴࠻࠳࠰࠮࠴࠸࠴ࠏࠏࠉࡴࡧࡵࡺࡪࡸࠠ࠾ࠢࡖࡉࡗ࡜ࡅࡓࠪࡸࡶࡱ࠲ࠧࡶࡴ࡯ࠫ࠮ࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠨࠪ࠮ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿ࡹࡥࡳࡸࡨࡶࢂࠐࠉࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧࠪࠌࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࡾࡵࡩ࠳ࡏࡇࡏࡑࡕࡉࡈࡇࡓࡆࠫࠍࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࡹ࠺ࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡥ࡮ࡤࡨࡨ࠲࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮࡞ࠫࠬࡣࠬ࡜࡮࡬ࡲࡰࡣࠊࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡸࡶࡱࠦ࠽ࠡ࡮࡬ࡲࡰࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩ࠭ࡪࡷࡱࡱ࠯ࠊࠊࠋࠦࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࠏࠣࡪࡨࠣࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠐࠉࠊࠥࠌࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠤࠋࡵࡩࡹࡻࡲ࡯ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡺࡸ࡬ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠋࠋࠥࠦࠧ䡉")
	#if l1l1l1_l1_ (u"ࠬ࠴࡭ࡱ࠶࠱࡬ࡹࡳ࡬ࠨ䡊") in url:
	#	l1lllll11l1l_l1_ = url.split(l1l1l1_l1_ (u"࠭࠯ࠨ䡋"))
	#	url = l1l1l1_l1_ (u"ࠧ࠰ࠩ䡌").join(l1lllll11l1l_l1_[:4])
	#	tmp = re.findall(l1l1l1_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࠲࠳࠳࠰࠿࠰ࠫࠫ࠲࠯ࡅࠩࠥࠩ䡍"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l1l1l1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䡎")+tmp[0][1]+l1l1l1_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ䡏")
	#	#return l1l1l1_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䡐"),[l1l1l1_l1_ (u"ࠬ࠭䡑")],[url]
	#	#l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1lll11l111l_l1_(url)
	#	#return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
	# l11ll1l1l_l1_ l111ll_l1_
	#return l1l1l1_l1_ (u"࠭ࠧ䡒"),[l1l1l1_l1_ (u"ࠧࠨ䡓")],[l111ll_l1_]
def l1llll1111l1_l1_(l111ll_l1_):
	# l1ll1lll_l1_://l1lll1ll11ll_l1_.l1ll1l11_l1_/?l1l11l1l_l1_=142302&l1l11lll_l1_=4
	parts = re.findall(l1l1l1_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䡔"),l111ll_l1_,re.DOTALL|re.IGNORECASE)
	l1l11l1l_l1_,l1l11lll_l1_ = parts[0]
	server = SERVER(l111ll_l1_,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭䡕"))
	#url = server+l1l1l1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䡖")
	url = server+l1l1l1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡷ࡬ࡪࡳࡥ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䡗")
	#url = server+l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ䡘")+l1l11l1l_l1_+l1l1l1_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䡙")+l1l11lll_l1_
	#data = {l1l1l1_l1_ (u"ࠧࡪࡦࠪ䡚"):l1l11l1l_l1_,l1l1l1_l1_ (u"ࠨ࡫ࠪ䡛"):l1l11lll_l1_,l1l1l1_l1_ (u"ࠩࡰࡩࡹࡧࠧ䡜"):l1l1l1_l1_ (u"ࠪࡳࡱࡪ࡟ࡴࡧࡵࡺࡪࡸࡳࠨ䡝"),l1l1l1_l1_ (u"ࠫࡹࡿࡰࡦࠩ䡞"):l1l1l1_l1_ (u"ࠬࡵ࡬ࡥࠩ䡟")}
	data = {l1l1l1_l1_ (u"࠭ࡩࡥࠩ䡠"):l1l11l1l_l1_,l1l1l1_l1_ (u"ࠧࡪࠩ䡡"):l1l11lll_l1_}
	headers = {l1l1l1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䡢"):l1l1l1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䡣"),l1l1l1_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䡤"):l111ll_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ䡥"),url,data,headers,l1l1l1_l1_ (u"ࠬ࠭䡦"),l1l1l1_l1_ (u"࠭ࠧ䡧"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠷ࡳࡵࠩ䡨"))
	l1l11l11_l1_ = response.content
	url2 = re.findall(l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䡩"),l1l11l11_l1_,re.DOTALL|re.IGNORECASE)
	if url2:
		url2 = url2[0]
		return l1l1l1_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䡪"),[l1l1l1_l1_ (u"ࠪࠫ䡫")],[url2]
	return l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ䡬"),[],[]
def l11ll1l_l1_(url,type,l11ll111_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䡭"),l1l1l1_l1_ (u"࠭ࠧ䡮"),url2,type)
	# http://l1111l1l1ll_l1_.l11ll11ll11_l1_.io/l111ll_l1_/136530
	l111l11_l1_,l1111l11lll_l1_ = [],[]
	l1l11l11_l1_ = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠧࠨ䡯"),l1l1l1_l1_ (u"ࠨࠩ䡰"),True,l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨ䡱"))
	l1l11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠾࠲ࡥࡃ࠭䡲"),l1l11l11_l1_,re.DOTALL)
	for block in l1l11l1_l1_:
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䡳"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			if l111ll_l1_ not in l111l11_l1_ and (l1l1l1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭䡴") in l111ll_l1_ or l1l1l1_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ䡵") in l111ll_l1_):
				title = title.replace(l1l1l1_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾ࠨ䡶"),l1l1l1_l1_ (u"ࠨࠩ䡷")).replace(l1l1l1_l1_ (u"ࠩࠣ࠱ࠥ࠭䡸"),l1l1l1_l1_ (u"ࠪࠫ䡹")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭䡺")).replace(l1l1l1_l1_ (u"ࠬࠦࠠࠨ䡻"),l1l1l1_l1_ (u"࠭ࠠࠨ䡼"))
				l111l11_l1_.append(l111ll_l1_)
				l1111l11lll_l1_.append(title)
	if not l111l11_l1_: return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䡽"),[],[]
	if len(l111l11_l1_)>1:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䡾"),l1111l11lll_l1_)
		if selection==-1: selection = 0
	else: selection = 0
	url3 = l111l11_l1_[selection]
	l11l1_l1_,l1111ll_l1_ = [],[]
	if type==l1l1l1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䡿"):
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ䢀"),url3,l1l1l1_l1_ (u"ࠫࠬ䢁"),l1l1l1_l1_ (u"ࠬ࠭䢂"),l1l1l1_l1_ (u"࠭ࠧ䢃"),True,l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠵ࡲࡩ࠭䢄"))
		l1ll11ll1_l1_ = response.content
		l1111lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡤࡷࡲ࠲ࡲ࡯ࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䢅"),l1ll11ll1_l1_,re.DOTALL)
		if l1111lll_l1_:
			l111ll_l1_ = UNQUOTE(l1111lll_l1_[0])
			l11l1_l1_.append(l111ll_l1_)
			l1111ll_l1_.append(l11ll111_l1_)
			#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䢆"),l1l1l1_l1_ (u"ࠪࠫ䢇"),l1l1l1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䢈"),l111ll_l1_)
	elif type==l1l1l1_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䢉"):
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ䢊"),url3,l1l1l1_l1_ (u"ࠧࠨ䢋"),l1l1l1_l1_ (u"ࠨࠩ䢌"),l1l1l1_l1_ (u"ࠩࠪ䢍"),True,l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠹ࡲࡥࠩ䢎"))
		l1ll11ll1_l1_ = response.content
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䢏"),l1ll11ll1_l1_,re.DOTALL)
		for l111ll_l1_,size in l1ll_l1_:
			if l11ll111_l1_ in size:
				l1111ll_l1_.append(size)
				l11l1_l1_.append(l111ll_l1_)
				#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䢐"),l1l1l1_l1_ (u"࠭ࠧ䢑"),l1l1l1_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭䢒"),l111ll_l1_)
				break
		if not l11l1_l1_:
			for l111ll_l1_,size in l1ll_l1_:
				l1111ll_l1_.append(size)
				l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨࡖࡈࡗ࡙࠭䢓"),l11l1_l1_)
	if not l11l1_l1_: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ䢔"),[],[]
	return l1l1l1_l1_ (u"ࠪࠫ䢕"),l1111ll_l1_,l11l1_l1_
def l1l11ll_l1_(url,name):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䢖"),l1l1l1_l1_ (u"ࠬ࠭䢗"),url,l11ll11l111_l1_)
	# http://l11llllllll_l1_.l1llllll11l1_l1_.l1ll1l11_l1_/5cf68c23e6e79			?l11ll11l111_l1_=			__11llll1l11_l1_
	# http://w.l1l1111l_l1_.l111l1ll1l_l1_/5e14fd0a2806e			?l11ll11l111_l1_=			ok.l11111l1l1l_l1_
	#l11ll11l111_l1_ = l11ll11l111_l1_.replace(l1l1l1_l1_ (u"࠭ࡡ࡬ࡱࡤࡱࡤࡥࠧ䢘"),l1l1l1_l1_ (u"ࠧࠨ䢙")).split(l1l1l1_l1_ (u"ࠨࡡࡢࠫ䢚"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭䢛"),url,l1l1l1_l1_ (u"ࠪࠫ䢜"),l1l1l1_l1_ (u"ࠫࠬ䢝"),True,l1l1l1_l1_ (u"ࠬ࠭䢞"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬ䢟"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l1l1l1_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ䢠") in list(cookies.keys()):
		l1l111111_l1_ = cookies[l1l1l1_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ䢡")]
		l1l111111_l1_ = UNQUOTE(escapeUNICODE(l1l111111_l1_))
		items = re.findall(l1l1l1_l1_ (u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䢢"),l1l111111_l1_,re.DOTALL)
		url2 = items[0].replace(l1l1l1_l1_ (u"ࠪࡠ࠴࠭䢣"),l1l1l1_l1_ (u"ࠫ࠴࠭䢤"))
		url2 = escapeUNICODE(url2)
	else: url2 = url
	if l1l1l1_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䢥") in url2:
		id = url2.split(l1l1l1_l1_ (u"࠭ࠥ࠳ࡈࠪ䢦"))[-1]
		url2 = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ䢧")+id
		return l1l1l1_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䢨"),[l1l1l1_l1_ (u"ࠩࠪ䢩")],[url2]
	else:
		website = WEBSITES[l1l1l1_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䢪")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䢫"),website,l1l1l1_l1_ (u"ࠬ࠭䢬"),l1l1l1_l1_ (u"࠭ࠧ䢭"),True,l1l1l1_l1_ (u"ࠧࠨ䢮"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠶ࡳࡪࠧ䢯"))
		l11ll111ll1_l1_ = response.url
		#l11ll111ll1_l1_ = response.headers[l1l1l1_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䢰")]
		#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䢱"),l1l1l1_l1_ (u"ࠫࠬ䢲"),response.url,website)
		l1111l11l1l_l1_ = url2.split(l1l1l1_l1_ (u"ࠬ࠵ࠧ䢳"))[2]#.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䢴"))
		l1l11111111_l1_ = l11ll111ll1_l1_.split(l1l1l1_l1_ (u"ࠧ࠰ࠩ䢵"))[2]#.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭䢶"))
		url3 = url2.replace(l1111l11l1l_l1_,l1l11111111_l1_)
		headers = { l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䢷"):l1l1l1_l1_ (u"ࠪࠫ䢸") , l1l1l1_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䢹"):l1l1l1_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䢺") , l1l1l1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䢻"):url3 }
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ䢼"), url3, l1l1l1_l1_ (u"ࠨࠩ䢽"), headers, False,l1l1l1_l1_ (u"ࠩࠪ䢾"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠹ࡲࡥࠩ䢿"))
		html = response.content
		#xbmc.log(str(url3), level=xbmc.LOGERROR)
		items = re.findall(l1l1l1_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䣀"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l1l1_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣁"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l1l1_l1_ (u"࠭࠼ࡦ࡯ࡥࡩࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣂"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䣃"),l1l1l1_l1_ (u"ࠨࠩ䣄"),str(items),html)
		if items:
			l111ll_l1_ = items[0].replace(l1l1l1_l1_ (u"ࠩ࡟࠳ࠬ䣅"),l1l1l1_l1_ (u"ࠪ࠳ࠬ䣆"))
			l111ll_l1_ = l111ll_l1_.rstrip(l1l1l1_l1_ (u"ࠫ࠴࠭䣇"))
			if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䣈") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䣉") + l111ll_l1_
			l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ䣊"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ䣋"))
			if name==l1l1l1_l1_ (u"ࠩࠪ䣌"): l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠪࠫ䣍"),[l1l1l1_l1_ (u"ࠫࠬ䣎")],[l111ll_l1_]
			else: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䣏"),[l1l1l1_l1_ (u"࠭ࠧ䣐")],[l111ll_l1_]
		else: l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_ = l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏࡔࡇࡍࠨ䣑"),[],[]
		return l11lll1l1l1_l1_,l1111ll_l1_,l11l1_l1_
def l11l1l111ll_l1_(url):
	# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l11l1ll11l1_l1_.l1lll1l11_l1_/e/l1lll1lll11l_l1_
	headers = { l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䣒") : l1l1l1_l1_ (u"ࠩࠪ䣓") }
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠪࠫ䣔"),headers,l1l1l1_l1_ (u"ࠫࠬ䣕"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ䣖"))
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䣗"),l1l1l1_l1_ (u"ࠧࠨ䣘"),url,html)
	items = re.findall(l1l1l1_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䣙"),html,re.DOTALL)
	l1111ll_l1_,l11l1_l1_,errno = [],[],l1l1l1_l1_ (u"ࠩࠪ䣚")
	if items:
		for l111ll_l1_,l111111l1l1_l1_ in items:
			l1111ll_l1_.append(l111111l1l1_l1_)
			l11l1_l1_.append(l111ll_l1_)
	if len(l11l1_l1_)==0: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐࠩ䣛"),[],[]
	return l1l1l1_l1_ (u"ࠫࠬ䣜"),l1111ll_l1_,l11l1_l1_
def l1llll11llll_l1_(url):
	# l1ll1lll_l1_://l1llllllll11_l1_.l1lll1l11_l1_/l11ll1l1l_l1_-l111lllll11_l1_.html
	url = url.replace(l1l1l1_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䣝"),l1l1l1_l1_ (u"࠭ࠧ䣞"))
	headers = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䣟") : l1l1l1_l1_ (u"ࠨࠩ䣠") }
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠩࠪ䣡"),headers,l1l1l1_l1_ (u"ࠪࠫ䣢"),l1l1l1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡓࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ䣣"))
	items = re.findall(l1l1l1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ䣤"),html,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䣥"),l1l1l1_l1_ (u"ࠧࠨ䣦"),url,items[0])
	if items:
		url = items[0]+l1l1l1_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䣧")+url
		return l1l1l1_l1_ (u"ࠩࠪ䣨"),[l1l1l1_l1_ (u"ࠪࠫ䣩")],[url]
	else: return l1l1l1_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭䣪"),[],[]
def l111l11ll1l_l1_(url):
	# l1ll1lll_l1_://l1ll1ll11lll_l1_.to/l11ll1l1l_l1_/5c83f14297d62
	url = url.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧ䣫"))
	if l1l1l1_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ䣬") in url: id = url.split(l1l1l1_l1_ (u"ࠧ࠰ࠩ䣭"))[4]
	else: id = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ䣮"))[-1]
	url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭䣯") + id
	headers = { l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䣰") : l1l1l1_l1_ (u"ࠫࠬ䣱") }
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠬ࠭䣲"),headers,l1l1l1_l1_ (u"࠭ࠧ䣳"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ䣴"))
	html = html.replace(l1l1l1_l1_ (u"ࠨ࡞࡟ࠫ䣵"),l1l1l1_l1_ (u"ࠩࠪ䣶"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䣷"),l1l1l1_l1_ (u"ࠫࠬ䣸"),url,html)
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䣹"),html,re.DOTALL)
	if items: return l1l1l1_l1_ (u"࠭ࠧ䣺"),[l1l1l1_l1_ (u"ࠧࠨ䣻")],[ items[0] ]
	else: return l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ䣼"),[],[]
def l1lllll111ll_l1_(url):
	# l1ll1lll_l1_://l11ll1ll1ll_l1_.l1ll1l11_l1_/l11ll1l1l_l1_-l11l111llll_l1_.html
	url = url.replace(l1l1l1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䣽"),l1l1l1_l1_ (u"ࠪࠫ䣾"))
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠫࠬ䣿"),l1l1l1_l1_ (u"ࠬ࠭䤀"),l1l1l1_l1_ (u"࠭ࠧ䤁"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧ䤂"))
	items = re.findall(l1l1l1_l1_ (u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䤃"),html,re.DOTALL)
	l1111ll_l1_,l11l1_l1_ = [],[]
	for l111ll_l1_,l111111l1l1_l1_,res in items:
		l1111ll_l1_.append(l111111l1l1_l1_+l1l1l1_l1_ (u"ࠩࠣࠫ䤄")+res)
		l11l1_l1_.append(l111ll_l1_)
	if len(l11l1_l1_)==0: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬ䤅"),[],[]
	return l1l1l1_l1_ (u"ࠫࠬ䤆"),l1111ll_l1_,l11l1_l1_
def l111ll1l1ll_l1_(url):
	# l1ll1lll_l1_://l11lll1l1ll_l1_.l111l1l111_l1_/l11ll1l1l_l1_-l1llllll1111_l1_.html
	url = url.replace(l1l1l1_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䤇"),l1l1l1_l1_ (u"࠭ࠧ䤈"))
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠧࠨ䤉"),l1l1l1_l1_ (u"ࠨࠩ䤊"),l1l1l1_l1_ (u"ࠩࠪ䤋"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ䤌"))
	items = re.findall(l1l1l1_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ䤍"),html,re.DOTALL)
	items = set(items)
	l1111ll_l1_,l11l1_l1_ = [],[]
	for id,mode,hash,l111111l1l1_l1_,res in items:
		url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ䤎")+id+l1l1l1_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭䤏")+mode+l1l1l1_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ䤐")+hash
		html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠨࠩ䤑"),l1l1l1_l1_ (u"ࠩࠪ䤒"),l1l1l1_l1_ (u"ࠪࠫ䤓"),l1l1l1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ䤔"))
		items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䤕"),html,re.DOTALL)
		for l111ll_l1_ in items:
			l1111ll_l1_.append(l111111l1l1_l1_+l1l1l1_l1_ (u"࠭ࠠࠨ䤖")+res)
			l11l1_l1_.append(l111ll_l1_)
	if len(l11l1_l1_)==0: return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭䤗"),[],[]
	return l1l1l1_l1_ (u"ࠨࠩ䤘"),l1111ll_l1_,l11l1_l1_
def l1ll1ll1l111_l1_(url):
	# l1ll1lll_l1_://l1lll1111l1l_l1_.l1lll1l11_l1_:2053/l1lll111l111_l1_/l1lllll1l1ll_l1_.l111llll11l_l1_.l11lllll1l1_l1_.1080p.l11llll11l1_l1_.l11ll111lll_l1_.l1ll1llll111_l1_.l111lll1_l1_.html?l111ll11l1l_l1_=2jpqzvpT8BbNUifWZO4QLQ&l11l11l1111_l1_=1624070560
	# http://l1lll1l111l1_l1_.l11l1llllll_l1_/l111lll11l1_l1_/l111lllll1l_l1_.l1111ll1l1l_l1_.l11l111l1l1_l1_.2018.1080p.l1111l11l11_l1_-l111l111111_l1_.l1lll1l11111_l1_.l111lll1_l1_.html
	l111ll_l1_ = l1l1l1_l1_ (u"ࠩࠪ䤙")
	if 1 or l1l1l1_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ䤚") not in url:
		url2 = url.replace(l1l1l1_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ䤛"),l1l1l1_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ䤜"))
		url2 = url2.split(l1l1l1_l1_ (u"࠭࠯ࠨ䤝"))
		id = url2[3]
		url2 = l1l1l1_l1_ (u"ࠧ࠰ࠩ䤞").join(url2[0:4])
		#headers = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䤟"):l1l1l11ll_l1_(),l1l1l1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䤠"):l1l1l1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䤡")}
		payload = {l1l1l1_l1_ (u"ࠫ࡮ࡪࠧ䤢"):id,l1l1l1_l1_ (u"ࠬࡵࡰࠨ䤣"):l1l1l1_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ䤤"),l1l1l1_l1_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬ䤥"):l1l1l1_l1_ (u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ䤦")}
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䤧"),url2,payload,l1l1l1_l1_ (u"ࠪࠫ䤨"),l1l1l1_l1_ (u"ࠫࠬ䤩"),l1l1l1_l1_ (u"ࠬ࠭䤪"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠳ࡶࡸࠬ䤫"))
		if l1l1l1_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䤬") in list(response.headers.keys()): l111ll_l1_ = response.headers[l1l1l1_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䤭")]
		if not l111ll_l1_ and response.succeeded:
			html = response.content
			l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡨࡂࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䤮"),html,re.DOTALL)
			if l111ll_l1_: l111ll_l1_ = l111ll_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ䤯"),url,l1l1l1_l1_ (u"ࠫࠬ䤰"),l1l1l1_l1_ (u"ࠬ࠭䤱"),l1l1l1_l1_ (u"࠭ࠧ䤲"),l1l1l1_l1_ (u"ࠧࠨ䤳"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧ䤴"))
		if l1l1l1_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ䤵") in list(response.headers.keys()): l111ll_l1_ = response.headers[l1l1l1_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ䤶")]
	if l111ll_l1_: return l1l1l1_l1_ (u"ࠫࠬ䤷"),[l1l1l1_l1_ (u"ࠬ࠭䤸")],[l111ll_l1_]
	return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧ䤹"),[],[]
def l111l1l11ll_l1_(url):
	# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1111l1ll1l_l1_.l1lll1l11_l1_/012ocyw9li6g.html
	headers = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䤺") : l1l1l1_l1_ (u"ࠨࠩ䤻") }
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠩࠪ䤼"),headers,l1l1l1_l1_ (u"ࠪࠫ䤽"),l1l1l1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡋࡌ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭䤾"))
	items = re.findall(l1l1l1_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦ࠭࠴ࠪࡀࠫࠥࠫ䤿"),html,re.DOTALL)
	l1111ll_l1_,l11l1_l1_ = [],[]
	if items:
		l1111ll_l1_.append(l1l1l1_l1_ (u"࠭࡭ࡱ࠶ࠪ䥀"))
		l11l1_l1_.append(items[0][1])
		l1111ll_l1_.append(l1l1l1_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠬ䥁"))
		l11l1_l1_.append(items[0][0])
		return l1l1l1_l1_ (u"ࠨࠩ䥂"),l1111ll_l1_,l11l1_l1_
	else: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡑࡏࡉࡗࡋࡇࡉࡔ࠭䥃"),[],[]
def l11lll111l1_l1_(url):
	# l111llll111_l1_ l11l1l1lll1_l1_			url = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽࡚࠹࡚࠸࠶࡜ࡍࡹࡻࡔࡉࠬ䥄")
	# l1lll11l11l1_l1_ .l11llll1l1l_l1_ l11l1l1lll1_l1_		url = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡚ࡹࡱࡘࡔࡁࡺࡧࡼࡊࡎ࠭䥅")
	# l111lll11ll_l1_ l1l1l1l11l_l1_ .l111111l_l1_ l11l1l1lll1_l1_		url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡊࡪ࠷࠳ࡎࡔࡶࡖࡷࡓࡽࠧ䥆")
	# l111l1ll1l1_l1_ l11l1l1lll1_l1_			url = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡩࡤ࡙࠹ࡗࡸࡍࡑ࠶ࡖࡉࠨ䥇")
	# l11lllll1l_l1_ files have l111l11lll1_l1_ l1lll1111l11_l1_		url = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࠶ࡽࡄࡓࡗ࡙ࡧࡘࡿ࡟ࡒࠩ䥈")
	# url = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࡪࡊ࡬࡛࠷ࡹࡅࡓࡗࡕࡨࠩ䥉")
	# url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼ࠶ࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ䥊")
	# url = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ䥋")
	# url = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭䥌")
	# url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡳࡊࡊࡲ࡫ࡪࡡࡍ࠵࡞ࡱࠦࡢࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡁࡌࡵ࡬ࡥࡧࡱࡐ࡮ࡴࡥࡧࡱࡵࡘ࡛ࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡣࡱࡨࡉ࡯ࡳࡵࡴ࡬ࡦࡺࡺࡩࡰࡰࡂࡷࡾࡴࡤࡪࡥࡤࡸ࡮ࡵ࡮࠾࠴࠺࠻࠺࠽࠵ࠨ䥍")
	# l1lll1lll_l1_ l1llll11l1ll_l1_ l1ll1lll1l11_l1_   l1ll1lll_l1_://l1lllll1llll_l1_.me/l1lll1111111_l1_/l1ll1lll1111_l1_-l1ll1lllllll_l1_-l1llll111ll1_l1_
	id = url.split(l1l1l1_l1_ (u"࠭࠯ࠨ䥎"))[-1]
	id = id.split(l1l1l1_l1_ (u"ࠧࠧࠩ䥏"))[0]
	id = id.replace(l1l1l1_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ䥐"),l1l1l1_l1_ (u"ࠩࠪ䥑"))
	#id = l1l1l1_l1_ (u"ࠪࡩࡤ࡙࠹ࡗࡸࡍࡑ࠶ࡖࡉࠨ䥒")
	#url = l1l1l1_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ䥓")+id
	#return l1l1l1_l1_ (u"ࠬ࠭䥔"),[l1l1l1_l1_ (u"࠭ࠧ䥕")],[url]
	url2 = WEBSITES[l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ䥖")][0]+l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ䥗")+id
	l1ll1ll1l1l1_l1_ = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬ䥘")+id
	l1111ll1lll_l1_,l1lll1111lll_l1_,l11lllll1ll_l1_,l1lll11ll11l_l1_ = l1l1l1_l1_ (u"ࠪࠫ䥙"),l1l1l1_l1_ (u"ࠫࠬ䥚"),l1l1l1_l1_ (u"ࠬ࠭䥛"),l1l1l1_l1_ (u"࠭ࠧ䥜")
	l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠧࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡝ࠩ࠯ࠫࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠫ࠲࠯ࡅࠩࡥࡧࡩࡥࡺࡲࡴࡂࡷࡧ࡭ࡴ࡚ࡲࡢࡥ࡮ࡍࡳࡪࡥࡹࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠩࠫ࠮ࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡼࠤ࡯ࡥࡳ࡭ࡵࡢࡩࡨࡇࡴࡪࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ࡟࠯࡟ࠬ࠭࡝ࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮ࡤࡲ࡬࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭ࡣࡱ࡫࠮ࠐࠉࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ࠰ࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࠪࠌࠌࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡳࡵࡴࠡ࡫ࡱࠤࡠ࠶ࠬ࠮࠳ࡠ࠾ࠏࠏࠉࠊࠋࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࠍࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍࠢࡀࠤࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍ࡝࠳ࡡ࠰࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠧࡶࡼࡴࡪࡃࡴࡳࡣࡦ࡯ࠫࡺ࡬ࡢࡰࡪࡁࠬ࠱࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࠲ࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠼ࠣࡨࡦࡹࡨࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࡨࡰࡸ࡫࠺ࠡࡦࡤࡷ࡭࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡵ࠲ࠫ࠱࠭࠯ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࠲ࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡫ࡰࡸ࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠤࡪࡷࡱࡱ࠸ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࡪ࡯ࡷ࡚ࡘࡌ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ࠯ࠊࠊࠋࠦ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬࡛ࠩࠩ࠱ࡒࡋࡄࡊࡃ࠽࡙ࡗࡏ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࡖ࡜ࡔࡊࡃࡓࡖࡄࡗࡍ࡙ࡒࡅࡔ࠮ࡊࡖࡔ࡛ࡐ࠮ࡋࡇࡁࠧࡼࡴࡵࠩ࠯࡬ࡹࡳ࡬࠳࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠣࠬࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠪࡹࡿࡰࡦ࠿ࡷࡶࡦࡩ࡫ࠧࡶ࡯ࡥࡳ࡭࠽ࠨࠌࠌࡦࡱࡵࡣ࡬ࡵ࠯ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠯ࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶࠣࡁࠥࡡ࡝࠭࡝ࡠ࠰ࢀࢃࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡵࡳ࡮ࡢࡩࡳࡩ࡯ࡥࡧࡧࡣ࡫ࡳࡴࡠࡵࡷࡶࡪࡧ࡭ࡠ࡯ࡤࡴࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡡࡩࡱࡹࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡮࡬ࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡨࡰࡸࡤࡲࡩࡴࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡦࡴࡤࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠧ࠽࡜ࠩࠪࡡ࠿ࠐࠉࠊࠋࡩࡱࡹࡥ࡬ࡪࡵࡷࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌࡪࡲࡺ࡟ࡪࡶࡤ࡫ࡸࠦ࠽ࠡࡨࡰࡸࡤࡲࡩࡴࡶ࠱ࡷࡵࡲࡩࡵࠪࠪ࠰ࠬ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡࡨࡰࡸࡤ࡯ࡴࡢࡩࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡸࡦ࡭ࠬࡴ࡫ࡽࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪࠌࠌࠍࠎࠏࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹࡡࡩࡵࡣࡪࡡࠥࡃࠠࡴ࡫ࡽࡩࠏࠏࡦࡰࡴࠣࡦࡱࡵࡣ࡬ࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡤ࡯ࡳࡨࡱ࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࡲࡩ࡯ࡧࡶࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠲ࠧࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡪࠦࡩ࡯ࠢ࡯࡭ࡳ࡫ࡳ࠻ࠌࠌࠍࠎࠩࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠱ࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡔࡏࡕࡋࡆࡉ࠮ࠐࠉࠊࠋࠦࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭ࡲࡩ࡯ࡧ࠯ࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠉ࡭࡫ࡱࡩࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡪ࠯ࠊࠊࠋࠌࡨ࡮ࡩࡴࠡ࠿ࠣࡿࢂࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡰ࡮ࡴࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨࠨࠩࠫ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩࡵࡧࡰࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍࡰ࡫ࡹ࠭ࡸࡤࡰࡺ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠾ࠩ࠯࠵࠮ࠐࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜࡭ࡨࡽࡢࠦ࠽ࠡࡸࡤࡰࡺ࡫ࠊࠊࠋࠌ࡭࡫ࠦࠧࡴ࡫ࡽࡩࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫࠣࡥࡳࡪࠠࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠌࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࠬࡹࡩࡻࡧࠪࡡࠥࡃࠠࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࡛ࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࡣࠊࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴࠪࠌࠌࡦࡱࡵࡣ࡬ࡵ࠯ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴ࠣࡁࠥࡡ࡝࠭࡝ࡠࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦ࡫ࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡫ࡵࡲࠡࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠨࠩࠫ࠱࠭ࠦࠨࠫࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠾ࠤࠪ࠰ࠬࡃࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠧࠨࠧ࠭ࠩࠥࠫ࠮ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠾ࡹࡸࡵࡦࠩ࠯ࠫ࠿࡚ࡲࡶࡧࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠻ࡨࡤࡰࡸ࡫ࠧ࠭ࠩ࠽ࡊࡦࡲࡳࡦࠩࠬࠎࠎࠏࡩࡧࠢࠪ࡟ࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡢ࡭ࡱࡦ࡯ࠥࡃࠠࠨ࡝ࠪ࠯ࡧࡲ࡯ࡤ࡭࠮ࠫࡢ࠭ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡉ࡛ࡇࡌࠩࠩ࡯࡭ࡸࡺࠧ࠭ࡤ࡯ࡳࡨࡱࠩࠋࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱ࠺ࠋࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠪࠌࠌࠍࠎࡪࡩࡤࡶ࡞ࠫࡹࡿࡰࡦࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡂ࠭ࠬࠨ࠿ࠥࠫ࠮࠱ࠧࠣࠩࠍࠍࠎࠏࡩࡧࠢࠪࡪࡵࡹࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡨࡳࡷࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡬ࡰࡴࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡹ࡬ࡨࡹ࡮ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡵ࡬ࡾࡪ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡷࡪࡦࡷ࡬ࠬࡣࠩࠬࠩࡻࠫ࠰ࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡪࡨ࡭࡬࡮ࡴࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱ࡭ࡹ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡵࡷࡥࡷࡺࠧ࡞࠭ࠪ࠱ࠬ࠱ࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡪࡴࡤࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡷࡹࡧࡲࡵࠩࡠ࠯ࠬ࠳ࠧࠬࡦ࡬ࡧࡹࡡࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡦࡰࡧࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫࠣࡥࡳࡪࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࡀ࠴࠵࠶࠸࠲࠳࠵࠶࠷࠿ࠦࡤࡦ࡮ࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠌࠌࠍࠎࠏࡣࡪࡲ࡫ࡩࡷࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩࡠ࠲ࡸࡶ࡬ࡪࡶࠫࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣࡧ࡮ࡶࡨࡦࡴ࠽ࠎࠎࠏࠉࠊࠋ࡮ࡩࡾ࠲ࡶࡢ࡮ࡸࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡃࠧ࠭࠳ࠬࠎࠎࠏࠉࠊࠋࡧ࡭ࡨࡺ࡛࡬ࡧࡼࡡࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡸࡤࡰࡺ࡫ࠩࠋࠋࠌࠍࠨ࡯ࡦࠡࠩࡸࡶࡱ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡶࡴ࡯ࠫࡢࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࡛ࠨࡷࡵࡰࠬࡣࠩࠋࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠲ࡦࡶࡰࡦࡰࡧࠬࡩ࡯ࡣࡵࠫࠍࠍࡺࡸ࡬ࡠ࡮࡬ࡷࡹ࠲ࡳࡵࡴࡨࡥࡲࡹ࠰࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠳࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠶ࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲ࠢࡤࡲࡩࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࡀࠊࠊࠋࡩࡳࡷࠦࡤࡪࡥࡷ࠵ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠻ࠌࠌࠍࠎࡻࡲ࡭࠳ࠣࡁࠥࡪࡩࡤࡶ࠴࡟ࠬࡻࡲ࡭ࠩࡠ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠣࡶࡴ࡯࠵ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࠱࡜ࠩࡸࡶࡱ࠭࡝ࠪࠫ࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺ࠲ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠾ࠏࠏࠉࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡧ࡭ࡨࡺ࠲࡜ࠩࡸࡶࡱ࠭࡝࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠍࠨࡻࡲ࡭࠴ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸ࠷ࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠩ࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠍ࡮࡬ࠠࡶࡴ࡯࠵ࡂࡃࡵࡳ࡮࠵ࠤࡦࡴࡤࠡࡷࡵࡰ࠶ࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡵࡳ࡮ࡢࡰ࡮ࡹࡴ࠻ࠌࠌࠍࠎࠏࠉࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠷ࠩࠋࠋࠌࠍࠎࠏࡤࡪࡥࡷ࠵࠳ࡻࡰࡥࡣࡷࡩ࠭ࡪࡩࡤࡶ࠵࠭ࠏࠏࠉࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶ࠴࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶ࠴࠭ࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡹࡴࡳࡧࡤࡱࡸ࠶ࠠ࠾ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠭ࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳ࠌࠌࠦࠧࠨ䥝")
	# l1lll11lllll_l1_ json data
	# l11ll1l1l_l1_ url l11l1l1lll1_l1_:    l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1lll1lll_l1_.l1lll1l11_l1_/l11ll1l1l_l1_/l11l111l111_l1_
	# list of l11l1ll111l_l1_ & l1lll111l1l1_l1_
	# l1ll1lll_l1_://l11l1l111l_l1_.l1lll1l11_l1_/l1llll111l1l_l1_-l111111l11l_l1_/l1llll111l1l_l1_-l111111l11l_l1_/l11ll11lll_l1_/l11lll1111_l1_/l11l1l11l11_l1_/l1111l1llll_l1_/l1lll1lll_l1_.py
	# all the l11l1l1l11_l1_ l1llll1lllll_l1_ l111l1111ll_l1_ l111l1l11l1_l1_ l1lll1lll1l1_l1_:	l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1lll1lll_l1_.l1lll1l11_l1_/l11ll1l111l_l1_/l1llll1l1ll1_l1_/l1llll1lll1l_l1_?l1ll1ll1llll_l1_=l1lll111ll11_l1_	&	l11l11ll1ll_l1_ = l11l111l111_l1_
	# 3 streams:	13KB:	l1l1l1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䥞"): l1l1l1_l1_ (u"ࠩࡌࡓࡘࡥࡃࡓࡇࡄࡘࡔࡘࠧ䥟"),l1l1l1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䥠"): l1l1l1_l1_ (u"ࠫ࠷࠸࠮࠴࠵࠱࠵࠵࠷ࠧ䥡")
	# 7 streams		44KB:	l1l1l1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䥢"): l1l1l1_l1_ (u"࠭ࡉࡐࡕࡢࡑࡊ࡙ࡓࡂࡉࡈࡗࡤࡋࡘࡕࡇࡑࡗࡎࡕࡎࠨ䥣"),l1l1l1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䥤"): l1l1l1_l1_ (u"ࠨ࠳࠺࠲࠸࠹࠮࠳ࠩ䥥")
	# 7 streams		58KB:	l1l1l1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䥦"): l1l1l1_l1_ (u"ࠪࡍࡔ࡙ࠧ䥧"),l1l1l1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䥨"): l1l1l1_l1_ (u"ࠬ࠷࠷࠯࠵࠶࠲࠷࠭䥩")
	# 9 streams		24KB:	l1l1l1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䥪"): l1l1l1_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ䥫"),l1l1l1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䥬"): l1l1l1_l1_ (u"ࠩ࠵࠶࠳࠹࠰࠯࠳࠳࠴ࠬ䥭")
	# no json file:		21 streams	95KB:	l1l1l1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䥮"): l1l1l1_l1_ (u"ࠫ࡜ࡋࡂࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ䥯"),l1l1l1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䥰"): l1l1l1_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠳࠸࠱࠴࠵࠴࠰࠱ࠩ䥱")
	# no json file:		21 streams	121KB:	l1l1l1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䥲"): l1l1l1_l1_ (u"ࠨ࡙ࡈࡆࠬ䥳"),l1l1l1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䥴"): l1l1l1_l1_ (u"ࠪ࠶࠳࠸࠰࠳࠴࠳࠼࠵࠷࠮࠱࠲࠱࠴࠵࠭䥵")
	# no json file: 	26 streams	115KB:	l1l1l1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䥶"): l1l1l1_l1_ (u"ࠬࡓࡗࡆࡄࠪ䥷"),l1l1l1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䥸"): l1l1l1_l1_ (u"ࠧ࠳࠰࠵࠴࠷࠸࠰࠹࠲࠴࠲࠵࠶࠮࠱࠲ࠪ䥹")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䥺"): l1l1l1_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࠪ䥻"),l1l1l1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䥼"): l1l1l1_l1_ (u"ࠫ࠶࠽࠮࠴࠳࠱࠷࠺࠭䥽")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䥾"): l1l1l1_l1_ (u"࠭ࡗࡆࡄࡢࡖࡊࡓࡉ࡙ࠩ䥿"),l1l1l1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䦀"): l1l1l1_l1_ (u"ࠨ࠳࠱࠶࠵࠸࠲࠱࠹࠵࠻࠳࠶࠱࠯࠲࠳ࠫ䦁")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䦂"): l1l1l1_l1_ (u"࡛ࠪࡊࡈ࡟ࡆࡏࡅࡉࡉࡊࡅࡅࡡࡓࡐࡆ࡟ࡅࡓࠩ䦃"),l1l1l1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䦄"): l1l1l1_l1_ (u"ࠬ࠷࠮࠳࠲࠵࠶࠵࠽࠳࠲࠰࠳࠴࠳࠶࠰ࠨ䦅")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䦆"): l1l1l1_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡇࡐࡆࡊࡊࡄࡆࡆࡢࡔࡑࡇ࡙ࡆࡔࠪ䦇"),l1l1l1_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䦈"): l1l1l1_l1_ (u"ࠩ࠴࠻࠳࠹࠱࠯࠵࠸ࠫ䦉")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䦊"): l1l1l1_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡓࡕࡔࡋࡆࠫ䦋"),l1l1l1_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䦌"): l1l1l1_l1_ (u"࠭࠵࠯࠳࠹࠲࠺࠷ࠧ䦍")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䦎"): l1l1l1_l1_ (u"ࠨࡖ࡙ࡌ࡙ࡓࡌ࠶ࡡࡖࡍࡒࡖࡌ࡚ࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ䦏"),l1l1l1_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䦐"): l1l1l1_l1_ (u"ࠪ࠶࠳࠶ࠧ䦑")
	# l1l11l1llll_l1_:	l1l1l1_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䦒"): l1l1l1_l1_ (u"ࠬࡏࡏࡔࡡࡐ࡙ࡘࡏࡃࠨ䦓"),l1l1l1_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䦔"): l1l1l1_l1_ (u"ࠧ࠶࠰࠵࠵ࠬ䦕")
	# url2 = WEBSITES[l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䦖")][0]+l1l1l1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡲࡵࡩࡹࡺࡹࡑࡴ࡬ࡲࡹࡃࡴࡳࡷࡨࠫ䦗")  # l1lll111ll11_l1_ l1111l1111l_l1_ l1lll111l1ll_l1_ and l1llll11ll1l_l1_ l111111ll1l_l1_ l11l1lllll_l1_ l1lll1ll11l1_l1_ file size
	#data2 = l1l1l1_l1_ (u"ࠪࡿࠬ䦘")l1ll1ll1lll1_l1_ (u"ࠫ࠿࡯ࡤ࠭ࠩ䦙")l1111l11ll1_l1_ (u"ࠬࡀࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠥࡅࡓࡊࡒࡐࡋࡇࠦ࠱ࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠣ࠳࠺࠲࠸࠷࠮࠴࠷ࠥࢁࢂࢃࠧ䦚")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ䦛"),url2,data2,l1l1l1_l1_ (u"ࠧࠨ䦜"),l1l1l1_l1_ (u"ࠨࠩ䦝"),l1l1l1_l1_ (u"ࠩࠪ䦞"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ䦟"))
	#html = response.content
	for ii in range(5):
		#DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠫฬ๊ๅฮษ๋่ฮࠦัใ็࠽ࠤࠥ࠭䦠")+str(ii+1),l1l1l1_l1_ (u"ࠬ࠭䦡"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ䦢"),url2,l1l1l1_l1_ (u"ࠧࠨ䦣"),l1l1l1_l1_ (u"ࠨࠩ䦤"),l1l1l1_l1_ (u"ࠩࠪ䦥"),l1l1l1_l1_ (u"ࠪࠫ䦦"),l1l1l1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ䦧"))
		html = response.content
		if l1l1l1_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䦨") in html: break
		time.sleep(2)
	#WRITE_THIS(l1l1l1_l1_ (u"࠭ࠧ䦩"),html)
	l1ll1111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ䦪"),html,re.DOTALL)
	if l1ll1111ll_l1_: l1ll1111ll_l1_ = l1ll1111ll_l1_[0]
	else: l1ll1111ll_l1_ = html
	l1ll1111ll_l1_ = l1ll1111ll_l1_.replace(l1l1l1_l1_ (u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ䦫"),l1l1l1_l1_ (u"ࠩࠩࠫ䦬"))
	l1llll11111l_l1_ = EVAL(l1l1l1_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䦭"),l1ll1111ll_l1_)
	#WRITE_THIS(l1l1l1_l1_ (u"ࠫࠬ䦮"),str(l1llll11111l_l1_))
	# l1lll11lllll_l1_ l11l111ll1l_l1_ & l11llll1111_l1_
	# l1lll1lll_l1_ l111llll111_l1_ l111ll_l1_ l1l11llll_l1_ l1l1l1_l1_ (u"ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠧ䦯") to l1l1111111_l1_ on l11l1ll11ll_l1_
	l1111ll_l1_,l11l1_l1_ = [l1l1l1_l1_ (u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪ䦰")],[l1l1l1_l1_ (u"ࠧࠨ䦱")]
	try:
		l11l111ll1l_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪ䦲")][l1l1l1_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䦳")][l1l1l1_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪ䦴")]
		for l111l1lll11_l1_ in l11l111ll1l_l1_:
			l111ll_l1_ = l111l1lll11_l1_[l1l1l1_l1_ (u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬ䦵")]
			try: title = l111l1lll11_l1_[l1l1l1_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䦶")][l1l1l1_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪ䦷")]
			except: title = l111l1lll11_l1_[l1l1l1_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䦸")][l1l1l1_l1_ (u"ࠨࡴࡸࡲࡸ࠭䦹")][0][l1l1l1_l1_ (u"ࠩࡷࡩࡽࡺࠧ䦺")]
			l11l1_l1_.append(l111ll_l1_)
			l1111ll_l1_.append(title)
	except: pass
	if len(l1111ll_l1_)>1:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪหำะัࠡษ็ฮึาๅสࠢส่๊์วิสฬ࠾ࠬ䦻"), l1111ll_l1_)
		if selection==-1: return l1l1l1_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䦼"),[],[]
		elif selection!=0:
			l111ll_l1_ = l11l1_l1_[selection]+l1l1l1_l1_ (u"ࠬࠬࠧ䦽")
			l1lllllll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫ䦾"),l111ll_l1_)
			if l1lllllll111_l1_: l111ll_l1_ = l111ll_l1_.replace(l1lllllll111_l1_[0],l1l1l1_l1_ (u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ䦿"))
			else: l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ䧀")
			l1111ll1lll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩࠩࠫ䧁"))
	formats,l11lll1lll1_l1_,l11l1l11ll1_l1_,l11l1l11lll_l1_,l11l1l11l1l_l1_ = [],[],[],[],[]
	# l1lll11lllll_l1_ l1111llll1l_l1_ streams
	try: l1lll1111lll_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ䧂")][l1l1l1_l1_ (u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭䧃")]
	except: pass
	# l1lll11lllll_l1_ l111lll11ll_l1_ stream
	try: l11lllll1ll_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ䧄")][l1l1l1_l1_ (u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ䧅")]
	except: pass
	# l1lll11lllll_l1_ l1lll11ll1_l1_ l111lll1_l1_ streams
	try: formats = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ䧆")][l1l1l1_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ䧇")]
	except: pass
	# l1lll11lllll_l1_ l1lll11ll1_l1_ l11llll1l1l_l1_ streams
	try: l11lll1lll1_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ䧈")][l1l1l1_l1_ (u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬ䧉")]
	except: pass
	l111ll1llll_l1_ = formats+l11lll1lll1_l1_
	for dict in l111ll1llll_l1_:
		#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ䧊"),str(dict))
		if l1l1l1_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䧋") in list(dict.keys()): dict[l1l1l1_l1_ (u"࠭ࡩࡵࡣࡪࠫ䧌")] = str(dict[l1l1l1_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ䧍")])
		if l1l1l1_l1_ (u"ࠨࡨࡳࡷࠬ䧎") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠩࡩࡴࡸ࠭䧏")] = str(dict[l1l1l1_l1_ (u"ࠪࡪࡵࡹࠧ䧐")])
		if l1l1l1_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭䧑") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠬࡺࡹࡱࡧࠪ䧒")] = dict[l1l1l1_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ䧓")]		#.replace(l1l1l1_l1_ (u"ࠧ࠾ࠩ䧔"),l1l1l1_l1_ (u"ࠨ࠿ࠪ䧕"))+l1l1l1_l1_ (u"ࠩࠥࠫ䧖")
		if l1l1l1_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ䧗") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ䧘")] = str(dict[l1l1l1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ䧙")])
		if l1l1l1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䧚") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ䧛")] = str(dict[l1l1l1_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ䧜")])
		if l1l1l1_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ䧝") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ䧞")] = str(dict[l1l1l1_l1_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ䧟")])+l1l1l1_l1_ (u"ࠬࡾࠧ䧠")+str(dict[l1l1l1_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭䧡")])
		if l1l1l1_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ䧢") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䧣")] = dict[l1l1l1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ䧤")][l1l1l1_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ䧥")]+l1l1l1_l1_ (u"ࠫ࠲࠭䧦")+dict[l1l1l1_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ䧧")][l1l1l1_l1_ (u"࠭ࡥ࡯ࡦࠪ䧨")]
		if l1l1l1_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ䧩") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ䧪")] = dict[l1l1l1_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭䧫")][l1l1l1_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ䧬")]+l1l1l1_l1_ (u"ࠫ࠲࠭䧭")+dict[l1l1l1_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ䧮")][l1l1l1_l1_ (u"࠭ࡥ࡯ࡦࠪ䧯")]
		if l1l1l1_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ䧰") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䧱")] = dict[l1l1l1_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ䧲")]
		if l1l1l1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䧳") in list(dict.keys()) and int(dict[l1l1l1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䧴")])>111222333: del dict[l1l1l1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䧵")]
		if l1l1l1_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ䧶") in list(dict.keys()):
			cipher = dict[l1l1l1_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ䧷")].split(l1l1l1_l1_ (u"ࠨࠨࠪ䧸"))
			for item in cipher:
				key,value = item.split(l1l1l1_l1_ (u"ࠩࡀࠫ䧹"),1)
				dict[key] = UNQUOTE(value)
		if l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ䧺") in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ䧻")] = UNQUOTE(dict[l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ䧼")])
		#if l1l1l1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸࡃࠧ䧽") in dict[l1l1l1_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ䧾")]: dict[l1l1l1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䧿")] = dict[l1l1l1_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ䨀")].split(l1l1l1_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࡀࡠࠧ࠭䨁"))[1].strip(l1l1l1_l1_ (u"ࠫࡡࠨࠧ䨂"))
		#LOG_THIS(l1l1l1_l1_ (u"ࠬ࠭䨃"),dict[l1l1l1_l1_ (u"࠭ࡴࡺࡲࡨࠫ䨄")]+l1l1l1_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠࠨ䨅")+dict[l1l1l1_l1_ (u"ࠨࡶࡼࡴࡪ࠭䨆")])
		l11l1l11ll1_l1_.append(dict)
	l1l111l11_l1_ = l1l1l1_l1_ (u"ࠩࠪ䨇")
	if l1l1l1_l1_ (u"ࠪࡷࡵࡃࡳࡪࡩࠪ䨈") in l1ll1111ll_l1_:
		#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡾࡺࡳ࠰࡬ࡶࡦ࡮ࡴ࠯ࡱ࡮ࡤࡽࡪࡸ࡟࠯ࠬࡂ࠭ࠧ࠭䨉"),html,re.DOTALL)
		# l11l1l1lll1_l1_:	/s/l1llll1lll1l_l1_/6dde7fb4/l1lll1ll1111_l1_.l11111lllll_l1_/l111l11111l_l1_/base.l1lll1l1ll11_l1_
		#l11ll11111l_l1_ = [l1l1l1_l1_ (u"ࠬ࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰ࡦ࠻࠻ࡩ࠻࠸࠲ࡨ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࡙ࡘ࠵ࡢࡢࡵࡨ࠲࡯ࡹࠧ䨊")]
		l11ll11111l_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ䨋"),html,re.DOTALL)
		if l11ll11111l_l1_:
			l11ll11111l_l1_ = WEBSITES[l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ䨌")][0]+l11ll11111l_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ䨍"),l11ll11111l_l1_,l1l1l1_l1_ (u"ࠩࠪ䨎"),l1l1l1_l1_ (u"ࠪࠫ䨏"),l1l1l1_l1_ (u"ࠫࠬ䨐"),l1l1l1_l1_ (u"ࠬ࠭䨑"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ䨒"))
			l1l111l11_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1lll1l111ll_l1_ = cipher._load_javascript(l1l111l11_l1_)
			l1lll1111ll1_l1_ = EVAL(l1l1l1_l1_ (u"ࠧࡴࡶࡵࠫ䨓"),str(l1lll1l111ll_l1_))
			l1llll1ll11l_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1lll1111ll1_l1_)
	for dict in l11l1l11ll1_l1_:
		url = dict[l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ䨔")]
		if l1l1l1_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭䨕") in url or url.count(l1l1l1_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ䨖"))>1:
			l11l1l11lll_l1_.append(dict)
		elif l1l111l11_l1_ and l1l1l1_l1_ (u"ࠫࡸ࠭䨗") in list(dict.keys()) and l1l1l1_l1_ (u"ࠬࡹࡰࠨ䨘") in list(dict.keys()):
			l111l1ll1l1_l1_ = l1llll1ll11l_l1_.execute(dict[l1l1l1_l1_ (u"࠭ࡳࠨ䨙")])
			if l111l1ll1l1_l1_!=dict[l1l1l1_l1_ (u"ࠧࡴࠩ䨚")]:
				dict[l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ䨛")] = url+l1l1l1_l1_ (u"ࠩࠩࠫ䨜")+dict[l1l1l1_l1_ (u"ࠪࡷࡵ࠭䨝")]+l1l1l1_l1_ (u"ࠫࡂ࠭䨞")+l111l1ll1l1_l1_
				l11l1l11lll_l1_.append(dict)
	for dict in l11l1l11lll_l1_:
		l11llll_l1_,l1llll1111ll_l1_,l1lllllll1ll_l1_,l1l11l1l1_l1_,codecs,l11ll1l11ll_l1_ = l1l1l1_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭䨟"),l1l1l1_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ䨠"),l1l1l1_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ䨡"),l1l1l1_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ䨢"),l1l1l1_l1_ (u"ࠩࠪ䨣"),l1l1l1_l1_ (u"ࠪ࠴ࠬ䨤")
		try:
			l11l1l1l111_l1_ = dict[l1l1l1_l1_ (u"ࠫࡹࡿࡰࡦࠩ䨥")]
			l11l1l1l111_l1_ = l11l1l1l111_l1_.replace(l1l1l1_l1_ (u"ࠬ࠱ࠧ䨦"),l1l1l1_l1_ (u"࠭ࠧ䨧"))
			items = re.findall(l1l1l1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䨨"),l11l1l1l111_l1_,re.DOTALL)
			l1l11l1l1_l1_,l11llll_l1_,codecs = items[0]
			l11lll11l11_l1_ = codecs.split(l1l1l1_l1_ (u"ࠨ࠮ࠪ䨩"))
			l1llll1111ll_l1_ = l1l1l1_l1_ (u"ࠩࠪ䨪")
			for item in l11lll11l11_l1_: l1llll1111ll_l1_ += item.split(l1l1l1_l1_ (u"ࠪ࠲ࠬ䨫"))[0]+l1l1l1_l1_ (u"ࠫ࠱࠭䨬")
			l1llll1111ll_l1_ = l1llll1111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠲ࠧ䨭"))
			if l1l1l1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䨮") in list(dict.keys()): l11ll1l11ll_l1_ = str(float(dict[l1l1l1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䨯")]*10)//1024/10)+l1l1l1_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ䨰")
			else: l11ll1l11ll_l1_ = l1l1l1_l1_ (u"ࠩࠪ䨱")
			if l1l11l1l1_l1_==l1l1l1_l1_ (u"ࠪࡸࡪࡾࡴࠨ䨲"): continue
			elif l1l1l1_l1_ (u"ࠫ࠱࠭䨳") in l11l1l1l111_l1_:
				l1l11l1l1_l1_ = l1l1l1_l1_ (u"ࠬࡇࠫࡗࠩ䨴")
				l1lllllll1ll_l1_ = l11llll_l1_+l1l1l1_l1_ (u"࠭ࠠࠡࠩ䨵")+l11ll1l11ll_l1_+dict[l1l1l1_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ䨶")].split(l1l1l1_l1_ (u"ࠨࡺࠪ䨷"))[1]
			elif l1l11l1l1_l1_==l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䨸"):
				l1l11l1l1_l1_ = l1l1l1_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ䨹")
				l1lllllll1ll_l1_ = l11ll1l11ll_l1_+dict[l1l1l1_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ䨺")].split(l1l1l1_l1_ (u"ࠬࡾࠧ䨻"))[1]+l1l1l1_l1_ (u"࠭ࠠࠡࠩ䨼")+dict[l1l1l1_l1_ (u"ࠧࡧࡲࡶࠫ䨽")]+l1l1l1_l1_ (u"ࠨࡨࡳࡷࠬ䨾")+l1l1l1_l1_ (u"ࠩࠣࠤࠬ䨿")+l11llll_l1_
			elif l1l11l1l1_l1_==l1l1l1_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ䩀"):
				l1l11l1l1_l1_ = l1l1l1_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ䩁")
				l1lllllll1ll_l1_ = l11ll1l11ll_l1_+str(int(dict[l1l1l1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ䩂")])/1000)+l1l1l1_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ䩃")+dict[l1l1l1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ䩄")]+l1l1l1_l1_ (u"ࠨࡥ࡫ࠫ䩅")+l1l1l1_l1_ (u"ࠩࠣࠤࠬ䩆")+l11llll_l1_
		except:
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		if l1l1l1_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ䩇") in dict[l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ䩈")]: duration = round(0.5+float(dict[l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ䩉")].split(l1l1l1_l1_ (u"࠭ࡤࡶࡴࡀࠫ䩊"),1)[1].split(l1l1l1_l1_ (u"ࠧࠧࠩ䩋"),1)[0]))
		elif l1l1l1_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ䩌") in list(dict.keys()): duration = round(0.5+float(dict[l1l1l1_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ䩍")])/1000)
		else: duration = l1l1l1_l1_ (u"ࠪ࠴ࠬ䩎")
		if l1l1l1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䩏") not in list(dict.keys()): l11ll1l11ll_l1_ = dict[l1l1l1_l1_ (u"ࠬࡹࡩࡻࡧࠪ䩐")].split(l1l1l1_l1_ (u"࠭ࡸࠨ䩑"))[1]
		else: l11ll1l11ll_l1_ = dict[l1l1l1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䩒")]
		if l1l1l1_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䩓") not in list(dict.keys()): dict[l1l1l1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ䩔")] = l1l1l1_l1_ (u"ࠪ࠴࠲࠶ࠧ䩕")
		dict[l1l1l1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䩖")] = l1l11l1l1_l1_+l1l1l1_l1_ (u"ࠬࡀࠠࠡࠩ䩗")+l1lllllll1ll_l1_+l1l1l1_l1_ (u"࠭ࠠࠡࠪࠪ䩘")+l1llll1111ll_l1_+l1l1l1_l1_ (u"ࠧ࠭ࠩ䩙")+dict[l1l1l1_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭䩚")]+l1l1l1_l1_ (u"ࠩࠬࠫ䩛")
		dict[l1l1l1_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ䩜")] = l1lllllll1ll_l1_.split(l1l1l1_l1_ (u"ࠫࠥࠦࠧ䩝"))[0].split(l1l1l1_l1_ (u"ࠬࡱࡢࡱࡵࠪ䩞"))[0]
		dict[l1l1l1_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ䩟")] = l1l11l1l1_l1_
		dict[l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䩠")] = l11llll_l1_
		dict[l1l1l1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䩡")] = codecs
		dict[l1l1l1_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ䩢")] = duration
		dict[l1l1l1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䩣")] = l11ll1l11ll_l1_
		l11l1l11l1l_l1_.append(dict)
	l111ll1ll11_l1_,l11ll1111ll_l1_,l11llll1ll1_l1_,l1111l1l111_l1_,l11l11l1l1l_l1_ = [],[],[],[],[]
	l11111l1l11_l1_,l11l1l1ll11_l1_,l1llllll111l_l1_,l11lll1111l_l1_,l11llll111l_l1_ = [],[],[],[],[]
	if l1lll1111lll_l1_:
		dict = {}
		dict[l1l1l1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䩤")] = l1l1l1_l1_ (u"ࠬࡇࠫࡗࠩ䩥")
		dict[l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䩦")] = l1l1l1_l1_ (u"ࠧ࡮ࡲࡧࠫ䩧")
		dict[l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䩨")] = dict[l1l1l1_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䩩")]+l1l1l1_l1_ (u"ࠪ࠾ࠥࠦࠧ䩪")+dict[l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䩫")]+l1l1l1_l1_ (u"ࠬࠦࠠࠨ䩬")+l1l1l1_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ䩭")
		dict[l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ䩮")] = l1lll1111lll_l1_
		dict[l1l1l1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䩯")] = l1l1l1_l1_ (u"ࠩ࠳ࠫ䩰") # for l1l1l11lll_l1_ l1lll1111lll_l1_ any l111l1l1l1l_l1_ will l111l1ll1ll_l1_ l1llll1ll1ll_l1_ sort l1ll1l1llll_l1_
		dict[l1l1l1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䩱")] = l1l1l1_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ䩲") # 20
		l11l1l11l1l_l1_.append(dict)
	if l11lllll1ll_l1_:
		l11l11l1ll1_l1_,l11l1lll1l1_l1_ = l1l1ll1ll1_l1_(l11lllll1ll_l1_)
		l11ll1l11l1_l1_ = list(zip(l11l11l1ll1_l1_,l11l1lll1l1_l1_))
		for title,l111ll_l1_ in l11ll1l11l1_l1_:
			dict = {}
			dict[l1l1l1_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䩳")] = l1l1l1_l1_ (u"࠭ࡁࠬࡘࠪ䩴")
			dict[l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䩵")] = l1l1l1_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭䩶")
			dict[l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭䩷")] = l111ll_l1_
			#if l1l1l1_l1_ (u"ࠪࡆ࡜ࡀࠠࠨ䩸") in title: dict[l1l1l1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䩹")] = title.split(l1l1l1_l1_ (u"ࠬࠦࠠࠨ䩺"))[1].split(l1l1l1_l1_ (u"࠭࡫ࡣࡲࡶࠫ䩻"))[0]
			#if l1l1l1_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭䩼") in title: dict[l1l1l1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䩽")] = title.split(l1l1l1_l1_ (u"ࠩࡕࡩࡸࡀࠠࠨ䩾"))[1]
			# title = l1l1l1_l1_ (u"ࠥ࠸࠷࠼࠷࡬ࡤࡳࡷࠥࠦ࠷࠳࠲ࠣࠤ࠳ࡳ࠳ࡶ࠺ࠥ䩿")
			if l1l1l1_l1_ (u"ࠫࡰࡨࡰࡴࠩ䪀") in title: dict[l1l1l1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䪁")] = title.split(l1l1l1_l1_ (u"࠭࡫ࡣࡲࡶࠫ䪂"))[0].rsplit(l1l1l1_l1_ (u"ࠧࠡࠢࠪ䪃"))[-1]
			else: dict[l1l1l1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䪄")] = l1l1l1_l1_ (u"ࠩ࠴࠴ࠬ䪅")
			if title.count(l1l1l1_l1_ (u"ࠪࠤࠥ࠭䪆"))>1:
				l11ll111_l1_ = title.rsplit(l1l1l1_l1_ (u"ࠫࠥࠦࠧ䪇"))[-3]
				if l11ll111_l1_.isdigit(): dict[l1l1l1_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭䪈")] = l11ll111_l1_
				else: dict[l1l1l1_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䪉")] = l1l1l1_l1_ (u"ࠧ࠱࠲࠳࠴ࠬ䪊")
			#dict[l1l1l1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䪋")] = title
			if title==l1l1l1_l1_ (u"ࠩ࠰࠵ࠬ䪌"): dict[l1l1l1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䪍")] = dict[l1l1l1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䪎")]+l1l1l1_l1_ (u"ࠬࡀࠠࠡࠩ䪏")+dict[l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䪐")]+l1l1l1_l1_ (u"ࠧࠡࠢࠪ䪑")+l1l1l1_l1_ (u"ࠨฮ๋ำฮࠦะไ์ฬࠫ䪒")
			else: dict[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䪓")] = dict[l1l1l1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ䪔")]+l1l1l1_l1_ (u"ࠫ࠿ࠦࠠࠨ䪕")+dict[l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䪖")]+l1l1l1_l1_ (u"࠭ࠠࠡࠩ䪗")+dict[l1l1l1_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ䪘")]+l1l1l1_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ䪙")+dict[l1l1l1_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ䪚")]
			l11l1l11l1l_l1_.append(dict)
	l11l1l11l1l_l1_ = sorted(l11l1l11l1l_l1_,reverse=True,key=lambda key: float(key[l1l1l1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䪛")]))
	if not l11l1l11l1l_l1_:
		l1llll111l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䪜"),html,re.DOTALL)
		l1llll111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䪝"),html,re.DOTALL)
		l111ll11lll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䪞"),html,re.DOTALL)
		l111ll1l111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䪟"),html,re.DOTALL)
		try: l111ll1l11l_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ䪠")][l1l1l1_l1_ (u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ䪡")][l1l1l1_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ䪢")][l1l1l1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䪣")][l1l1l1_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ䪤")][0][l1l1l1_l1_ (u"࠭ࡴࡦࡺࡷࠫ䪥")]
		except: l111ll1l11l_l1_ = l1l1l1_l1_ (u"ࠧࠨ䪦")
		try: l111ll1l1l1_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ䪧")][l1l1l1_l1_ (u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ䪨")][l1l1l1_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ䪩")][l1l1l1_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬ䪪")][0][l1l1l1_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ䪫")][0][l1l1l1_l1_ (u"࠭ࡴࡦࡺࡷࠫ䪬")]
		except: l111ll1l1l1_l1_ = l1l1l1_l1_ (u"ࠧࠨ䪭")
		try: l1llll1ll111_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ䪮")][l1l1l1_l1_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩ䪯")]
		except: l1llll1ll111_l1_ = l1l1l1_l1_ (u"ࠪࠫ䪰")
		if l1llll111l1_l1_ or l1llll111ll_l1_ or l111ll11lll_l1_ or l111ll1l111_l1_ or l111ll1l11l_l1_ or l111ll1l1l1_l1_ or l1llll1ll111_l1_:
			if   l1llll111l1_l1_: message = l1llll111l1_l1_[0]
			elif l1llll111ll_l1_: message = l1llll111ll_l1_[0]
			elif l111ll11lll_l1_: message = l111ll11lll_l1_[0]
			elif l111ll1l111_l1_: message = l111ll1l111_l1_[0]
			elif l111ll1l11l_l1_: message = l111ll1l11l_l1_
			elif l111ll1l1l1_l1_: message = l111ll1l1l1_l1_
			elif l1llll1ll111_l1_: message = l1llll1ll111_l1_
			l1llllll1l11_l1_ = message.replace(l1l1l1_l1_ (u"ࠫࡡࡴࠧ䪱"),l1l1l1_l1_ (u"ࠬ࠭䪲")).strip(l1l1l1_l1_ (u"࠭ࠠࠨ䪳"))
			l11l1111lll_l1_ = l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊ิฬࠦวๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠣ์็ี๋ࠠๅ๋๊ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣวํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ䪴")
			DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䪵"),l1l1l1_l1_ (u"ࠩࠪ䪶"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥ๎วๅ็หี๊าࠧ䪷"),l11l1111lll_l1_+l1l1l1_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䪸")+l1llllll1l11_l1_)
			return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧ䪹")+l1llllll1l11_l1_,[],[]
		else: return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭䪺"),[],[]
	l1llll1ll1l1_l1_,l1ll1lll1ll1_l1_,l111l1l1ll1_l1_ = [],[],[]
	for dict in l11l1l11l1l_l1_:
		if dict[l1l1l1_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭䪻")]==l1l1l1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ䪼"):
			l111ll1ll11_l1_.append(dict[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䪽")])
			l11111l1l11_l1_.append(dict)
		elif dict[l1l1l1_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ䪾")]==l1l1l1_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ䪿"):
			l11ll1111ll_l1_.append(dict[l1l1l1_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䫀")])
			l11l1l1ll11_l1_.append(dict)
		elif dict[l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ䫁")]==l1l1l1_l1_ (u"ࠧ࡮ࡲࡧࠫ䫂"):
			title = dict[l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䫃")].replace(l1l1l1_l1_ (u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ䫄"),l1l1l1_l1_ (u"ࠪࠫ䫅"))
			if l1l1l1_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䫆") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l1l1_l1_ (u"ࠬ࠶ࠧ䫇")
			else: l11ll1l11ll_l1_ = dict[l1l1l1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䫈")]
			l1llll1ll1l1_l1_.append([dict,{},title,l11ll1l11ll_l1_])
		else:
			title = dict[l1l1l1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䫉")].replace(l1l1l1_l1_ (u"ࠨࡃ࠮࡚࠿ࠦࠠࠨ䫊"),l1l1l1_l1_ (u"ࠩࠪ䫋"))
			if l1l1l1_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䫌") not in list(dict.keys()): l11ll1l11ll_l1_ = l1l1l1_l1_ (u"ࠫ࠵࠭䫍")
			else: l11ll1l11ll_l1_ = dict[l1l1l1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䫎")]
			l1llll1ll1l1_l1_.append([dict,{},title,l11ll1l11ll_l1_])
			l11llll1ll1_l1_.append(title)
			l1llllll111l_l1_.append(dict)
		l11ll1l1ll1_l1_ = True
		if l1l1l1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䫏") in list(dict.keys()):
			if l1l1l1_l1_ (u"ࠧࡢࡸ࠳ࠫ䫐") in dict[l1l1l1_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䫑")]: l11ll1l1ll1_l1_ = False
			elif kodi_version<18:
				if l1l1l1_l1_ (u"ࠩࡤࡺࡨ࠭䫒") not in dict[l1l1l1_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ䫓")] and l1l1l1_l1_ (u"ࠫࡲࡶ࠴ࡢࠩ䫔") not in dict[l1l1l1_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ䫕")]: l11ll1l1ll1_l1_ = False
		if dict[l1l1l1_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ䫖")]==l1l1l1_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭䫗") and dict[l1l1l1_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䫘")]!=l1l1l1_l1_ (u"ࠩ࠳࠱࠵࠭䫙") and l11ll1l1ll1_l1_==True:
			l11l11l1l1l_l1_.append(dict[l1l1l1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䫚")])
			l11llll111l_l1_.append(dict)
		elif dict[l1l1l1_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䫛")]==l1l1l1_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ䫜") and dict[l1l1l1_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䫝")]!=l1l1l1_l1_ (u"ࠧ࠱࠯࠳ࠫ䫞") and l11ll1l1ll1_l1_==True:
			l1111l1l111_l1_.append(dict[l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䫟")])
			l11lll1111l_l1_.append(dict)
		#LOG_THIS(l1l1l1_l1_ (u"ࠩࠪ䫠"),l1l1l1_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ䫡")+dict[l1l1l1_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䫢")])
	for l11ll11l1ll_l1_ in l11lll1111l_l1_:
		l1111l1l1l1_l1_ = l11ll11l1ll_l1_[l1l1l1_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䫣")]
		for l111ll111l1_l1_ in l11llll111l_l1_:
			l1llll11ll11_l1_ = l111ll111l1_l1_[l1l1l1_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䫤")]
			l11ll1l11ll_l1_ = l1llll11ll11_l1_+l1111l1l1l1_l1_
			title = l111ll111l1_l1_[l1l1l1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䫥")].replace(l1l1l1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪ䫦"),l1l1l1_l1_ (u"ࠩࡰࡴࡩࠦࠠࠨ䫧"))
			title = title.replace(l111ll111l1_l1_[l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䫨")]+l1l1l1_l1_ (u"ࠫࠥࠦࠧ䫩"),l1l1l1_l1_ (u"ࠬ࠭䫪"))
			title = title.replace(str((float(l1llll11ll11_l1_*10)//1024/10))+l1l1l1_l1_ (u"࠭࡫ࡣࡲࡶࠫ䫫"),str((float(l11ll1l11ll_l1_*10)//1024/10))+l1l1l1_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ䫬"))
			title = title+l1l1l1_l1_ (u"ࠨࠪࠪ䫭")+l11ll11l1ll_l1_[l1l1l1_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䫮")].split(l1l1l1_l1_ (u"ࠪࠬࠬ䫯"),1)[1]
			l1llll1ll1l1_l1_.append([l111ll111l1_l1_,l11ll11l1ll_l1_,title,l11ll1l11ll_l1_])
	l1llll1ll1l1_l1_ = sorted(l1llll1ll1l1_l1_, reverse=True, key=lambda key: float(key[3]))
	for l111ll111l1_l1_,l11ll11l1ll_l1_,title,l11ll1l11ll_l1_ in l1llll1ll1l1_l1_:
		l11l1l111l1_l1_ = l111ll111l1_l1_[l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䫰")]
		if l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䫱") in list(l11ll11l1ll_l1_.keys()):
			l11l1l111l1_l1_ = l1l1l1_l1_ (u"࠭࡭ࡱࡦࠪ䫲")
			#l11l1l111l1_l1_ = l11l1l111l1_l1_+l11ll11l1ll_l1_[l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䫳")]
		if l11l1l111l1_l1_ not in l111l1l1ll1_l1_:
			l111l1l1ll1_l1_.append(l11l1l111l1_l1_)
			l1ll1lll1ll1_l1_.append([l111ll111l1_l1_,l11ll11l1ll_l1_,title,l11ll1l11ll_l1_])
			#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ䫴"),str(l11ll1l11ll_l1_)+l1l1l1_l1_ (u"ࠩࠣࠤࠥ࠭䫵")+title)
	#l1ll1lll1ll1_l1_ = sorted(l1ll1lll1ll1_l1_, reverse=True, key=lambda key: int(key[3]))
	l1llll1l1lll_l1_,l11111llll1_l1_,shift = [],[],0
	l1l1l1_l1_ (u"ࠥࠦࠧࠐࠉࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡰࡹࡱࡩࡷࠨ࠺࠯ࠬࡂࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡯ࡸࡰࡨࡶ࠿ࠐࠉࠊࡵ࡫࡭࡫ࡺࠠࠬ࠿ࠣ࠵ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ࠫࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠳ࡡ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠱࡞ࠌࠌࠍࡸ࡫࡬ࡦࡥࡷࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡧ࡭ࡵࡩࡤࡧࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ䫶")
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࡱࡺࡲࡪࡸ࡟ࡤࡪࡤࡲࡳ࡫࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲ࡟࡫ࡵࡲࡲ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡣࡸࡸ࡭ࡵࡲࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮ࡢ࡮ࡸࡵ࡮࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡲࡻࡳ࡫ࡲࡠࡰࡤࡱࡪࡀࠊࠊࠋ࡬ࡱࡦ࡭ࡥࡴࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡡ࡭࡮ࡲࡻࡗࡧࡴࡪࡰࡪࡷࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࠍ࡮ࡳࡡࡨࡧࡶࡣࡺࡸ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡭ࡲࡧࡧࡦࡵࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡩࡧࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࡀࠠࡪ࡯ࡤ࡫ࡪࠦ࠽ࠡ࡫ࡰࡥ࡬࡫ࡳࡠࡷࡵࡰࡠ࠳࠱࡞ࠌࠌࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡵࡷ࡯ࡧࡵࡣࡳࡧ࡭ࡦ࡝࠳ࡡࠏࠏࠉࡴࡪ࡬ࡪࡹࠦࠫ࠾ࠢ࠴ࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ࠱࡯ࡸࡰࡨࡶ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤ࡜ࡋࡂࡔࡋࡗࡉࡘࡡ࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ࡟࡞࠴ࡢ࠱ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ࠯ࡴࡽ࡮ࡦࡴࡢࡧ࡭ࡧ࡮࡯ࡧ࡯࡟࠵ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ䫷")
	l11ll1ll111_l1_,l11l11lll11_l1_ = l1l1l1_l1_ (u"ࠬ࠭䫸"),l1l1l1_l1_ (u"࠭ࠧ䫹")
	try: l11ll1ll111_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭䫺")][l1l1l1_l1_ (u"ࠨࡣࡸࡸ࡭ࡵࡲࠨ䫻")]
	except: l11ll1ll111_l1_ = l1l1l1_l1_ (u"ࠩࠪ䫼")
	try: l1llllll1l1l_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ䫽")][l1l1l1_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧ䫾")]
	except: l1llllll1l1l_l1_ = l1l1l1_l1_ (u"ࠬ࠭䫿")
	if l11ll1ll111_l1_ and l1llllll1l1l_l1_:
		shift += 1
		title = l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ䬀")+l11ll1ll111_l1_+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䬁")
		l111ll_l1_ = WEBSITES[l1l1l1_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䬂")][0]+l1l1l1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ䬃")+l1llllll1l1l_l1_
		l1llll1l1lll_l1_.append(title)
		l11111llll1_l1_.append(l111ll_l1_)
		try: l11l11lll11_l1_ = l1llll11111l_l1_[l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ䬄")][l1l1l1_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ䬅")][l1l1l1_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩ䬆")][-1][l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ䬇")]
		except: pass
	#if l1lll1111lll_l1_:
	#	shift += 1
	#	l1llll1l1lll_l1_.append(l1l1l1_l1_ (u"ࠧ࡮ࡲࡧࠤั๎ฯสࠢำ็๏ฯࠧ䬈")) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"ࠨࡦࡤࡷ࡭࠭䬉"))
	for l111ll111l1_l1_,l11ll11l1ll_l1_,title,l11ll1l11ll_l1_ in l1ll1lll1ll1_l1_:
		l1llll1l1lll_l1_.append(title) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ䬊"))
	if l11llll1ll1_l1_: l1llll1l1lll_l1_.append(l1l1l1_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬ䬋")) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ䬌"))
	if l1llll1ll1l1_l1_: l1llll1l1lll_l1_.append(l1l1l1_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩ䬍")) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"࠭ࡡ࡭࡮ࠪ䬎"))
	if l11l11l1l1l_l1_: l1llll1l1lll_l1_.append(l1l1l1_l1_ (u"ࠧ࡮ࡲࡧࠤฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ䬏")) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"ࠨ࡯ࡳࡨࠬ䬐"))
	if l111ll1ll11_l1_: l1llll1l1lll_l1_.append(l1l1l1_l1_ (u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩ䬑")) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䬒"))
	if l11ll1111ll_l1_: l1llll1l1lll_l1_.append(l1l1l1_l1_ (u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫ䬓")) ; l11111llll1_l1_.append(l1l1l1_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ䬔"))
	l11lllll111_l1_ = False
	while True:
		selection = DIALOG_SELECT(l1ll1ll1l1l1_l1_, l1llll1l1lll_l1_)
		if selection==-1: return l1l1l1_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䬕"),[],[]
		elif selection==0 and l11ll1ll111_l1_:
			l111ll_l1_ = l11111llll1_l1_[selection]
			new_path = sys.argv[0]+l1l1l1_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ䬖")+QUOTE(l11ll1ll111_l1_)+l1l1l1_l1_ (u"ࠨࠨࡸࡶࡱࡃࠧ䬗")+l111ll_l1_
			if l11l11lll11_l1_: new_path = new_path+l1l1l1_l1_ (u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪ䬘")+QUOTE(l11l11lll11_l1_)
			#settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ䬙"),l1l1l1_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ䬚"))
			xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ䬛")+new_path+l1l1l1_l1_ (u"ࠨࠩࠣ䬜"))
			return l1l1l1_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䬝"),[],[]
		choice = l11111llll1_l1_[selection]
		l1lll1l1llll_l1_ = l1llll1l1lll_l1_[selection]
		if choice==l1l1l1_l1_ (u"ࠨࡦࡤࡷ࡭࠭䬞"):
			l1lll11ll11l_l1_ = l1lll1111lll_l1_
			break
		elif choice in [l1l1l1_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ䬟"),l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䬠"),l1l1l1_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ䬡")]:
			if choice==l1l1l1_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ䬢"): l1111ll_l1_,l1111111l11_l1_ = l11llll1ll1_l1_,l1llllll111l_l1_
			elif choice==l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䬣"): l1111ll_l1_,l1111111l11_l1_ = l111ll1ll11_l1_,l11111l1l11_l1_
			elif choice==l1l1l1_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭䬤"): l1111ll_l1_,l1111111l11_l1_ = l11ll1111ll_l1_,l11l1l1ll11_l1_
			selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ䬥"), l1111ll_l1_)
			if selection!=-1:
				l1lll11ll11l_l1_ = l1111111l11_l1_[selection][l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭䬦")]
				l1lll1l1llll_l1_ = l1111ll_l1_[selection]
				break
		elif choice==l1l1l1_l1_ (u"ࠪࡱࡵࡪࠧ䬧"):
			selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯ࠺ࠨ䬨"), l11l11l1l1l_l1_)
			if selection!=-1:
				l1lll1l1llll_l1_ = l11l11l1l1l_l1_[selection]
				l11l11lll1l_l1_ = l11llll111l_l1_[selection]
				selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํะ࠺ࠨ䬩"), l1111l1l111_l1_)
				if selection!=-1:
					l1lll1l1llll_l1_ += l1l1l1_l1_ (u"࠭ࠠࠬࠢࠪ䬪")+l1111l1l111_l1_[selection]
					l111ll11111_l1_ = l11lll1111l_l1_[selection]
					l11lllll111_l1_ = True
					break
		elif choice==l1l1l1_l1_ (u"ࠧࡢ࡮࡯ࠫ䬫"):
			l11l1ll1ll1_l1_,l1111ll1111_l1_,l1ll1llll1ll_l1_,l11l11111ll_l1_ = list(zip(*l1llll1ll1l1_l1_))
			selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ䬬"), l1ll1llll1ll_l1_)
			if selection!=-1:
				l1lll1l1llll_l1_ = l1ll1llll1ll_l1_[selection]
				l11l11lll1l_l1_ = l11l1ll1ll1_l1_[selection]
				if l1l1l1_l1_ (u"ࠩࡰࡴࡩ࠭䬭") in l1ll1llll1ll_l1_[selection] and l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ䬮")]!=l1lll1111lll_l1_:
					l111ll11111_l1_ = l1111ll1111_l1_[selection]
					l11lllll111_l1_ = True
				else: l1lll11ll11l_l1_ = l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ䬯")]
				break
		elif choice==l1l1l1_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭䬰"):
			#shift += 1
			l11l1ll1ll1_l1_,l1111ll1111_l1_,l1ll1llll1ll_l1_,l11l11111ll_l1_ = list(zip(*l1ll1lll1ll1_l1_))
			l11l11lll1l_l1_ = l11l1ll1ll1_l1_[selection-shift]
			if l1l1l1_l1_ (u"࠭࡭ࡱࡦࠪ䬱") in l1ll1llll1ll_l1_[selection-shift] and l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ䬲")]!=l1lll1111lll_l1_:
				l111ll11111_l1_ = l1111ll1111_l1_[selection-shift]
				l11lllll111_l1_ = True
			else: l1lll11ll11l_l1_ = l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ䬳")]
			l1lll1l1llll_l1_ = l1ll1llll1ll_l1_[selection-shift]
			break
	if not l11lllll111_l1_: l1lll11l1l11_l1_ = l1lll11ll11l_l1_
	else: l1lll11l1l11_l1_ = l1l1l1_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪ䬴")+l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ䬵")]+l1l1l1_l1_ (u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨ䬶")+l111ll11111_l1_[l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ䬷")]
	if l11lllll111_l1_:
		#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ䬸"),l1l1l1_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ䬹")+str(l11l11lll1l_l1_))
		#LOG_THIS(l1l1l1_l1_ (u"ࠨࠩ䬺"),l1l1l1_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬ࠭ࠣࠤࠥ࠭䬻")+str(l111ll11111_l1_))
		#if l11lll1llll_l1_>l111l1l111l_l1_: duration = str(l11lll1llll_l1_)
		#else: duration = str(l111l1l111l_l1_)
		#duration = str(l11lll1llll_l1_) if l11lll1llll_l1_>l111l1l111l_l1_ else str(l111l1l111l_l1_)
		l11lll1llll_l1_ = int(l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ䬼")])
		l111l1l111l_l1_ = int(l111ll11111_l1_[l1l1l1_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭䬽")])
		duration = str(max(l11lll1llll_l1_,l111l1l111l_l1_))
		l1111llllll_l1_ = l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ䬾")].replace(l1l1l1_l1_ (u"࠭ࠦࠨ䬿"),l1l1l1_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭䭀"))		# +l1l1l1_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ䭁")
		l11ll111l11_l1_ = l111ll11111_l1_[l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭䭂")].replace(l1l1l1_l1_ (u"ࠪࠪࠬ䭃"),l1l1l1_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ䭄"))		# +l1l1l1_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠲࠳࠴࠵࠶࠰࠱ࠩ䭅")
		l11llll1l1l_l1_ = l1l1l1_l1_ (u"࠭࠼ࡀࡺࡰࡰࠥࡼࡥࡳࡵ࡬ࡳࡳࡃࠢ࠲࠰࠳ࠦࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࠣࡗࡗࡊ࠲࠾ࠢࡀࡀ࡟ࡲࠬ䭆")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠧ࠽ࡏࡓࡈࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡹࡩ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠲࠱࠲࠴࠳࡝ࡓࡌࡔࡥ࡫ࡩࡲࡧ࠭ࡪࡰࡶࡸࡦࡴࡣࡦࠤࠣࡼࡲࡲ࡮ࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠧࠦࡸ࡮࡮ࡱࡷ࠿ࡾ࡬ࡪࡰ࡮ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠴࠽࠾࠿࠯ࡹ࡮࡬ࡲࡰࠨࠠࡹࡵ࡬࠾ࡸࡩࡨࡦ࡯ࡤࡐࡴࡩࡡࡵ࡫ࡲࡲࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠡࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡳࡪࡡࡳࡦࡶ࠲࡮ࡹ࡯࠯ࡱࡵ࡫࠴࡯ࡴࡵࡨ࠲ࡔࡺࡨ࡬ࡪࡥ࡯ࡽࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࡓࡵࡣࡱࡨࡦࡸࡤࡴ࠱ࡐࡔࡊࡍ࠭ࡅࡃࡖࡌࡤࡹࡣࡩࡧࡰࡥࡤ࡬ࡩ࡭ࡧࡶ࠳ࡉࡇࡓࡉ࠯ࡐࡔࡉ࠴ࡸࡴࡦࠥࠤࡲ࡯࡮ࡃࡷࡩࡪࡪࡸࡔࡪ࡯ࡨࡁࠧࡖࡔ࠲࠰࠸ࡗࠧࠦ࡭ࡦࡦ࡬ࡥࡕࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡇࡹࡷࡧࡴࡪࡱࡱࡁࠧࡖࡔࠨ䭇")+duration+l1l1l1_l1_ (u"ࠨࡕࠥࠤࡹࡿࡰࡦ࠿ࠥࡷࡹࡧࡴࡪࡥࠥࠤࡵࡸ࡯ࡧ࡫࡯ࡩࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥࡂࡡࡴࠧ䭈")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠩ࠿ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭䭉")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠲ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡷ࡫ࡧࡩࡴ࠵ࠧ䭊")+l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䭋")]+l1l1l1_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ䭌")		# l111l1ll111_l1_=l1l1l1_l1_ (u"ࠨ࠱ࠣ䭍") l11llll11ll_l1_=l1l1l1_l1_ (u"ࠢࡵࡴࡸࡩࠧ䭎") default=l1l1l1_l1_ (u"ࠣࡶࡵࡹࡪࠨ䭏")>\n
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ䭐")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ䭑")+l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䭒")]+l1l1l1_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ䭓")+l11l11lll1l_l1_[l1l1l1_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䭔")]+l1l1l1_l1_ (u"ࠧࠣࠢࡶࡸࡦࡸࡴࡘ࡫ࡷ࡬ࡘࡇࡐ࠾ࠤ࠴ࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤࠪ䭕")+str(l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䭖")])+l1l1l1_l1_ (u"ࠩࠥࠤࡼ࡯ࡤࡵࡪࡀࠦࠬ䭗")+str(l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ䭘")])+l1l1l1_l1_ (u"ࠫࠧࠦࡨࡦ࡫ࡪ࡬ࡹࡃࠢࠨ䭙")+str(l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ䭚")])+l1l1l1_l1_ (u"࠭ࠢࠡࡨࡵࡥࡲ࡫ࡒࡢࡶࡨࡁࠧ࠭䭛")+l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠧࡧࡲࡶࠫ䭜")]+l1l1l1_l1_ (u"ࠨࠤࡁࡠࡳ࠭䭝")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ䭞")+l1111llllll_l1_+l1l1l1_l1_ (u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ䭟")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ䭠")+l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ䭡")]+l1l1l1_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ䭢")	# l1ll1lll1lll_l1_=l1l1l1_l1_ (u"ࠢࡵࡴࡸࡩࠧ䭣")>\n
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ䭤")+l11l11lll1l_l1_[l1l1l1_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ䭥")]+l1l1l1_l1_ (u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ䭦")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ䭧")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ䭨")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ䭩")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠷ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡦࡻࡤࡪࡱ࠲ࠫ䭪")+l111ll11111_l1_[l1l1l1_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ䭫")]+l1l1l1_l1_ (u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀࠦࡹࡸࡵࡦࠤࡁࡠࡳ࠭䭬")		# l111l1ll111_l1_=l1l1l1_l1_ (u"ࠥ࠵ࠧ䭭") l11llll11ll_l1_=l1l1l1_l1_ (u"ࠦࡹࡸࡵࡦࠤ䭮") default=l1l1l1_l1_ (u"ࠧࡺࡲࡶࡧࠥ䭯")>\n
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"࠭࠼ࡓࡱ࡯ࡩࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡄࡂࡕࡋ࠾ࡷࡵ࡬ࡦ࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣ࡯ࡤ࡭ࡳࠨ࠯࠿࡞ࡱࠫ䭰")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠧ࠽ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠢ࡬ࡨࡂࠨࠧ䭱")+l111ll11111_l1_[l1l1l1_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭䭲")]+l1l1l1_l1_ (u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭䭳")+l111ll11111_l1_[l1l1l1_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ䭴")]+l1l1l1_l1_ (u"ࠫࠧࠦࡢࡢࡰࡧࡻ࡮ࡪࡴࡩ࠿ࠥ࠵࠸࠶࠴࠸࠷ࠥࡂࡡࡴࠧ䭵")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠬࡂࡁࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽࠶࠸࠶࠰࠴࠼࠶࠾ࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠫ䭶")+l111ll11111_l1_[l1l1l1_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ䭷")]+l1l1l1_l1_ (u"ࠧࠣ࠱ࡁࡠࡳ࠭䭸")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ䭹")+l11ll111l11_l1_+l1l1l1_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ䭺")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ䭻")+l111ll11111_l1_[l1l1l1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ䭼")]+l1l1l1_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ䭽")	# l1ll1lll1lll_l1_=l1l1l1_l1_ (u"ࠨࡴࡳࡷࡨࠦ䭾")>\n
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ䭿")+l111ll11111_l1_[l1l1l1_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭䮀")]+l1l1l1_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ䮁")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭䮂")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ䮃")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ䮄")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ䮅")
		l11llll1l1l_l1_ += l1l1l1_l1_ (u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ䮆")
		#open(l1l1l1_l1_ (u"ࠨࡵ࠽ࡠࡡࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ䮇"),l1l1l1_l1_ (u"ࠩࡺࡦࠬ䮈")).write(l11llll1l1l_l1_)
		#LOG_THIS(l1l1l1_l1_ (u"ࠪࠫ䮉"),l11llll1l1l_l1_)
		#l11llll1l1l_l1_ = OPENURL_CACHED(NO_CACHE,l1lll1111lll_l1_,l1l1l1_l1_ (u"ࠫࠬ䮊"),l1l1l1_l1_ (u"ࠬ࠭䮋"),l1l1l1_l1_ (u"࠭ࠧ䮌"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠾ࡺࡨࠨ䮍"))
		if kodi_version>18.99:
			import http.server as l111lll1ll1_l1_
			import http.client as l1llll1l1l1l_l1_
		else:
			import BaseHTTPServer as l111lll1ll1_l1_
			import httplib as l1llll1l1l1l_l1_
		class l1lll1l1l1l1_l1_(l111lll1ll1_l1_.HTTPServer):
			#l11llll1l1l_l1_ = l1l1l1_l1_ (u"ࠨ࠾ࡁࠫ䮎")
			def __init__(self,l1lllll11111_l1_=l1l1l1_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ䮏"),port=55055,l11llll1l1l_l1_=l1l1l1_l1_ (u"ࠪࡀࡃ࠭䮐")):
				self.l1lllll11111_l1_ = l1lllll11111_l1_
				self.port = port
				self.l11llll1l1l_l1_ = l11llll1l1l_l1_
				l111lll1ll1_l1_.HTTPServer.__init__(self,(self.l1lllll11111_l1_,self.port),l1111l111l1_l1_)
				self.l1lll1l1111l_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ䮑")+l1lllll11111_l1_+l1l1l1_l1_ (u"ࠬࡀࠧ䮒")+str(port)+l1l1l1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ䮓")
				#print(l1l1l1_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡹࡵࠦ࡮ࡰࡹࠣࡰ࡮ࡹࡴࡦࡰ࡬ࡲ࡬ࠦ࡯࡯ࠢࡳࡳࡷࡺ࠺ࠡࠩ䮔")+str(port))
			def start(self):
				self.threads = l11l1l1111l_l1_(False)
				self.threads.start_new_thread(1,self.l111l11l1ll_l1_)
			def l111l11l1ll_l1_(self):
				#print(l1l1l1_l1_ (u"ࠨࡵࡨࡶࡻ࡯࡮ࡨࠢࡵࡩࡶࡻࡥࡴࡶࡶࠤࡸࡺࡡࡳࡶࡨࡨࠬ䮕"))
				self.l1ll1lll111l_l1_ = True
				#l1ll1ll111l_l1_ = 0
				while self.l1ll1lll111l_l1_:
					#l1ll1ll111l_l1_ += 1
					#print(l1l1l1_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠣࡥࠥࡹࡩ࡯ࡩ࡯ࡩࠥ࡮ࡡ࡯ࡦ࡯ࡩࡤࡸࡥࡲࡷࡨࡷࡹ࠮ࠩࠡࡰࡲࡻ࠿ࠦࠧ䮖")+str(l1ll1ll111l_l1_)+l1l1l1_l1_ (u"ࠪࠫ䮗"))
					#settimeout l11lll111l_l1_ not l1l1111111_l1_ l1lllll1lll1_l1_ to error message if it l1lll1llllll_l1_ l1lll111111l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111l11l1ll_l1_ l111l1l1l11_l1_ request l1lll11lll11_l1_ 60 seconds)
					self.handle_request()
				#print(l1l1l1_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡲࡴࡵ࡫ࡤ࡝ࡰࠪ䮘"))
			def stop(self):
				self.l1ll1lll111l_l1_ = False
				self.l111ll111ll_l1_()	# needed to l11lll11l1l_l1_ self.handle_request() to l111l11l1ll_l1_ l11l111ll11_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l1l1l1_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡦࡲࡻࡳࠦ࡮ࡰࡹ࡟ࡲࠬ䮙"))
			def load(self,l11llll1l1l_l1_):
				self.l11llll1l1l_l1_ = l11llll1l1l_l1_
			def l111ll111ll_l1_(self):
				conn = l1llll1l1l1l_l1_.HTTPConnection(self.l1lllll11111_l1_+l1l1l1_l1_ (u"࠭࠺ࠨ䮚")+str(self.port))
				conn.request(l1l1l1_l1_ (u"ࠢࡉࡇࡄࡈࠧ䮛"), l1l1l1_l1_ (u"ࠣ࠱ࠥ䮜"))
		class l1111l111l1_l1_(l111lll1ll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l1l1l1_l1_ (u"ࠩࡧࡳ࡮ࡴࡧࠡࡉࡈࡘࠥࠦࠧ䮝")+self.path)
				self.send_response(200)
				self.send_header(l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ䮞"),l1l1l1_l1_ (u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ䮟"))
				self.end_headers()
				#self.wfile.write(self.path+l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ䮠"))
				self.wfile.write(self.server.l11llll1l1l_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䮡")))
				time.sleep(1)
				if self.path==l1l1l1_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭䮢"): self.server.shutdown()
				if self.path==l1l1l1_l1_ (u"ࠨ࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ䮣"): self.server.shutdown()
			def do_HEAD(self):
				#print(l1l1l1_l1_ (u"ࠩࡧࡳ࡮ࡴࡧࠡࡊࡈࡅࡉࠦࠠࠨ䮤")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1lll1l1l1l1_l1_(l1l1l1_l1_ (u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭䮥"),55055,l11llll1l1l_l1_)
		#httpd.load(l11llll1l1l_l1_)
		l1lll11ll11l_l1_ = httpd.l1lll1l1111l_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1lll11ll11l_l1_ = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡩࡷࡧࡶ࡭ࡲ࠴ࡤࡢࡵ࡫࡭࡫࠴࡯ࡳࡩ࠲ࡰ࡮ࡼࡥࡴ࡫ࡰ࠳ࡨ࡮ࡵ࡯࡭ࡧࡹࡷࡥ࠱࠰ࡣࡷࡳࡤ࠽࠯ࡵࡧࡶࡸࡵ࡯ࡣ࠵ࡡ࠻ࡷ࠴ࡓࡡ࡯࡫ࡩࡩࡸࡺ࠮࡮ࡲࡧࠫ䮦")
		#l1lll11ll11l_l1_ = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡢࡵ࡫࠲ࡦࡱࡡ࡮ࡣ࡬ࡾࡪࡪ࠮࡯ࡧࡷ࠳ࡩࡧࡳࡩ࠴࠹࠸࠴࡚ࡥࡴࡶࡆࡥࡸ࡫ࡳ࠰࠴ࡦ࠳ࡶࡻࡡ࡭ࡥࡲࡱࡲ࠵࠱࠰ࡏࡸࡰࡹ࡯ࡒࡦࡵࡐࡔࡊࡍ࠲࠯࡯ࡳࡨࠬ䮧")
		#l1lll11ll11l_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡶࡶ࡭࠳ࡺࡥ࡭ࡧࡦࡳࡲ࠳ࡰࡢࡴ࡬ࡷࡹ࡫ࡣࡩ࠰ࡩࡶ࠴࡭ࡰࡢࡥ࠲ࡈࡆ࡙ࡈࡠࡅࡒࡒࡋࡕࡒࡎࡃࡑࡇࡊ࠵ࡔࡦ࡮ࡨࡧࡴࡳࡐࡢࡴ࡬ࡷ࡙࡫ࡣࡩ࠱ࡰࡴ࠹࠳࡬ࡪࡸࡨ࠳ࡲࡶ࠴࠮࡮࡬ࡺࡪ࠳࡭ࡱࡦ࠰ࡅ࡛࠳ࡂࡔ࠰ࡰࡴࡩ࠭䮨")
		#l1lll11ll11l_l1_ = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡳࡦࡰࡩࡩ࡯ࡡ࠯ࡤࡥࡧ࠳ࡩ࡯࠯ࡷ࡮࠳ࡩࡧࡳࡩ࠱ࡲࡲࡩ࡫࡭ࡢࡰࡧ࠳ࡹ࡫ࡳࡵࡥࡤࡶࡩ࠵࠱࠰ࡥ࡯࡭ࡪࡴࡴࡠ࡯ࡤࡲ࡮࡬ࡥࡴࡶ࠰ࡩࡻ࡫࡮ࡵࡵ࠰ࡱࡺࡲࡴࡪ࡮ࡤࡲ࡬࠴࡭ࡱࡦࠪ䮩")
		#l1lll11ll11l_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ䮪")
	else: httpd = l1l1l1_l1_ (u"ࠩࠪ䮫")
	if not l1lll11ll11l_l1_: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ䮬"),[],[]
	return l1l1l1_l1_ (u"ࠫࠬ䮭"),[l1l1l1_l1_ (u"ࠬ࠭䮮")],[[l1lll11ll11l_l1_,l1111ll1lll_l1_,httpd]]
def l1llllllllll_l1_(url):
	# l1ll1lll_l1_://l11ll1lll1l_l1_.l1lll1l11_l1_/l11111l11ll_l1_
	headers = { l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䮯") : l1l1l1_l1_ (u"ࠧࠨ䮰") }
	#url = url.replace(l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ䮱"),l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ䮲"))
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠪࠫ䮳"),headers,l1l1l1_l1_ (u"ࠫࠬ䮴"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡇࡕࡂ࠮࠳ࡶࡸࠬ䮵"))
	items = re.findall(l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧࢂࠩ࡝ࡿࠪ䮶"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l11l11l1ll1_l1_,l1111ll_l1_,l11l1lll1l1_l1_,l11l1_l1_ = [],[],[],[]
	if items:
		for l111ll_l1_,dummy,l111111l1l1_l1_ in items:
			l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ䮷"),l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ䮸"))
			if l1l1l1_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䮹") in l111ll_l1_:
				l11l11l1ll1_l1_,l11l1lll1l1_l1_ = l1l1ll1ll1_l1_(l111ll_l1_)
				#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䮺"),l1l1l1_l1_ (u"ࠫࠬ䮻"),str(l11l1_l1_),str(l11l1lll1l1_l1_))
				l11l1_l1_ = l11l1_l1_ + l11l1lll1l1_l1_
				if l11l11l1ll1_l1_[0]==l1l1l1_l1_ (u"ࠬ࠳࠱ࠨ䮼"): l1111ll_l1_.append(l1l1l1_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ䮽")+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨ䮾"))
				else:
					for title in l11l11l1ll1_l1_:
						l1111ll_l1_.append(l1l1l1_l1_ (u"ࠨีํีๆืࠠฯษุࠫ䮿")+l1l1l1_l1_ (u"ࠩࠣࠤࠥ࠭䯀")+title)
			else:
				title = l1l1l1_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭䯁")+l1l1l1_l1_ (u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ䯂")+l111111l1l1_l1_
				l11l1_l1_.append(l111ll_l1_)
				l1111ll_l1_.append(title)
		return l1l1l1_l1_ (u"ࠬ࠭䯃"),l1111ll_l1_,l11l1_l1_
	else: return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡇࡕࡂࠨ䯄"),[],[]
def	l1lll111l11l_l1_(url):
	# l1ll1lll_l1_://l11lll1l111_l1_.cc/l11ll1l1l_l1_-1qrpoobdg7bu.html
	# l1ll1lll_l1_://l111l1llll1_l1_.cc//l11ll1l1l_l1_-l11l1111l11_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ䯅"),url,l1l1l1_l1_ (u"ࠨࠩ䯆"),l1l1l1_l1_ (u"ࠩࠪ䯇"),l1l1l1_l1_ (u"ࠪࠫ䯈"),l1l1l1_l1_ (u"ࠫࠬ䯉"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚࡙ࡍࡉࡋࡏࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ䯊"))
	html = response.content
	l1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䯋"),html,re.DOTALL)
	if l1ll_l1_:
		l111ll_l1_ = l1ll_l1_[0]
		return l1l1l1_l1_ (u"ࠧࠨ䯌"),[l1l1l1_l1_ (u"ࠨࠩ䯍")],[l111ll_l1_]
	return l1l1l1_l1_ (u"ࠩࠪ䯎"),[],[]
def	l1lll11l111l_l1_(url):
	# l1ll1lll_l1_://l1lll11l1111_l1_.in/l1llll111l11_l1_
	# l1ll1lll_l1_://l1lll11l1111_l1_.in/l11ll1l1l_l1_-l1llll111l11_l1_.html
	# l1ll1lll_l1_://l111llll1ll_l1_.l1lllll111l1_l1_/l11ll1l1l11_l1_
	# l1ll1lll_l1_://l111llll1ll_l1_.l1lllll111l1_l1_/l11ll1l1l_l1_-l11ll1l1l11_l1_.html
	# l1ll1lll_l1_://l1ll1l1ll1l_l1_.l11ll1ll1l1_l1_.l1lll1l11_l1_/l11ll1l1l_l1_-l1111l1ll11_l1_.html
	url = url.replace(l1l1l1_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ䯏"),l1l1l1_l1_ (u"ࠫࠬ䯐")).replace(l1l1l1_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ䯑"),l1l1l1_l1_ (u"࠭ࠧ䯒"))
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ䯓"),url,l1l1l1_l1_ (u"ࠨࠩ䯔"),l1l1l1_l1_ (u"ࠩࠪ䯕"),l1l1l1_l1_ (u"ࠪࠫ䯖"),l1l1l1_l1_ (u"ࠫࠬ䯗"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡉࡍࡑࡋࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ䯘"))
	html = response.content
	l111111llll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪ࡞ࠬ࠭ࠬ䯙"),html,re.DOTALL)
	if l111111llll_l1_:
		l111111llll_l1_ = l111111llll_l1_[0]
		l1llll1l1l11_l1_ = l1lllll1111l_l1_(l111111llll_l1_)
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䯚"),l1llll1l1l11_l1_,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨࠪࡿࠪ䯛"),l1llll1l1l11_l1_,re.DOTALL)
		l1111ll_l1_,l11l1_l1_ = [],[]
		for l111ll_l1_,title in l1ll_l1_:
			if not title: title = l111ll_l1_.rsplit(l1l1l1_l1_ (u"ࠩ࠱ࠫ䯜"),1)[1]
			l1111ll_l1_.append(title)
			l11l1_l1_.append(l111ll_l1_)
		return l1l1l1_l1_ (u"ࠪࠫ䯝"),l1111ll_l1_,l11l1_l1_
	id = url.split(l1l1l1_l1_ (u"ࠫ࠴࠭䯞"))[3]
	headers = { l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䯟"):l1l1l1_l1_ (u"࠭ࠧ䯠") , l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䯡"):l1l1l1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䯢") }
	payload = { l1l1l1_l1_ (u"ࠩ࡬ࡨࠬ䯣"):id , l1l1l1_l1_ (u"ࠪࡳࡵ࠭䯤"):l1l1l1_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ䯥") }
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ䯦"),url,payload,headers,l1l1l1_l1_ (u"࠭ࠧ䯧"),l1l1l1_l1_ (u"ࠧࠨ䯨"),l1l1l1_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ䯩"))
	html = response.content
	items = re.findall(l1l1l1_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯪"),html,re.DOTALL)
	if items: return l1l1l1_l1_ (u"ࠪࠫ䯫"),[l1l1l1_l1_ (u"ࠫࠬ䯬")],[ items[0] ]
	return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡙ࠠࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠭䯭"),[],[]
l1l1l1_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡇࡐࡘࡌࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡲࡺ࡮ࡪ࠮ࡤࡱ࠲ࡺ࡮ࡪࡥࡰ࠱ࡳࡰࡦࡿ࠯ࡂࡃ࡙ࡉࡓࡪࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀࠦࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࠥࡀࠠࠨࠩࠣࢁࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒ࡚ࡎࡊ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻ࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡹ࡫࡭ࡱ࡝࠳ࡡࡂࡃࠧ࠮࠳ࠪ࠾ࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨࠫࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠻ࠌࠌࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦุࠫࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥ࠭ࠫࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭ำ๋ำไีࠥิวึࠩ࠮ࠫࠥࠦࠠ࡮ࡲ࠷ࠫࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠣࠫࠬ࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑ࡙ࡍࡉ࠭ࠬ࡜࡟࠯࡟ࡢࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠶ࡳ࠮ࡨࡱࡹ࡭ࡩ࠴ࡣࡰ࠱ࡶࡸࡷ࡫ࡡ࡮࠱࠵࠶࠾࠴࡭࠴ࡷ࠻ࠎࠧࠨࠢ䯮")
#####################################################
#    l11ll11l1l1_l1_ l11111ll11l_l1_ l1lllll11ll1_l1_
#    16-06-2019
#####################################################
def l111111l1ll_l1_(url):
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠧࠨ䯯"),l1l1l1_l1_ (u"ࠨࠩ䯰"),l1l1l1_l1_ (u"ࠩࠪ䯱"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭䯲"))
	items = re.findall(l1l1l1_l1_ (u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䯳"),html,re.DOTALL)
	if items: return l1l1l1_l1_ (u"ࠬ࠭䯴"),[l1l1l1_l1_ (u"࠭ࠧ䯵")],[ items[0] ]
	else: return l1l1l1_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡌࡐࡃࡇࡗࠬ䯶"),[],[]
def l1111111111_l1_(url):
	return l1l1l1_l1_ (u"ࠨࠩ䯷"),[l1l1l1_l1_ (u"ࠩࠪ䯸")],[ url ]
def l11111ll1ll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䯹"),l1l1l1_l1_ (u"ࠫࠬ䯺"),url,l1l1l1_l1_ (u"ࠬ࠭䯻"))
	server = url.split(l1l1l1_l1_ (u"࠭࠯ࠨ䯼"))
	basename = l1l1l1_l1_ (u"ࠧ࠰ࠩ䯽").join(server[0:3])
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠨࠩ䯾"),l1l1l1_l1_ (u"ࠩࠪ䯿"),l1l1l1_l1_ (u"ࠪࠫ䰀"),l1l1l1_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡛࠭ࡋࡓࡔ࡞࡙ࡈࡂࡔࡈ࠱࠶ࡹࡴࠨ䰁"))
	items = re.findall(l1l1l1_l1_ (u"ࠬࡪ࡬ࡣࡷࡷࡸࡴࡴ࡜ࠨ࡞ࠬ࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠥࡢࠫࠡ࡞ࠫࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࠤࡡ࠱ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩ࡝ࠫࠣࡠ࠰ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰂"),html,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䰃"),l1l1l1_l1_ (u"ࠧࠨ䰄"),url,str(var))
	if items:
		l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_,l1l1l1ll1ll_l1_,l11l111111l_l1_,l11l11111l1_l1_,l11l1111111_l1_ = items[0]
		var = int(l1l1l1ll1l1_l1_) % int(l1l1l1ll1ll_l1_) + int(l11l111111l_l1_) % int(l11l11111l1_l1_)
		url = basename + l1l1l11ll1l_l1_ + str(var) + l11l1111111_l1_
		return l1l1l1_l1_ (u"ࠨࠩ䰅"),[l1l1l1_l1_ (u"ࠩࠪ䰆")],[url]
	else: return l1l1l1_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩ䰇"),[],[]
def l111lll1l1l_l1_(url):
	url = url.replace(l1l1l1_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ䰈"),l1l1l1_l1_ (u"ࠬ࠭䰉"))
	url = url.replace(l1l1l1_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ䰊"),l1l1l1_l1_ (u"ࠧࠨ䰋"))
	id = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ䰌"))[-1]
	headers = { l1l1l1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䰍") : l1l1l1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䰎") }
	payload = { l1l1l1_l1_ (u"ࠦ࡮ࡪࠢ䰏"):id , l1l1l1_l1_ (u"ࠧࡵࡰࠣ䰐"):l1l1l1_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠤ䰑") }
	request = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ䰒"), url, payload, headers, l1l1l1_l1_ (u"ࠨࠩ䰓"),l1l1l1_l1_ (u"ࠩࠪ䰔"),l1l1l1_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭䰕"))
	if l1l1l1_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䰖") in list(request.headers.keys()): l111ll_l1_ = request.headers[l1l1l1_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䰗")]
	else: l111ll_l1_ = url
	if l111ll_l1_: return l1l1l1_l1_ (u"࠭ࠧ䰘"),[l1l1l1_l1_ (u"ࠧࠨ䰙")],[l111ll_l1_]
	else: return l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭䰚"),[],[]
def l1llll1l11l1_l1_(url):
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠩࠪ䰛"),l1l1l1_l1_ (u"ࠪࠫ䰜"),l1l1l1_l1_ (u"ࠫࠬ䰝"),l1l1l1_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡌࡒ࡙࡜ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ䰞"))
	items = re.findall(l1l1l1_l1_ (u"࠭࡭ࡱ࠶࠽ࠤࡡࡡ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ䰟"),html,re.DOTALL)
	if items: return l1l1l1_l1_ (u"ࠧࠨ䰠"),[l1l1l1_l1_ (u"ࠨࠩ䰡")],[ items[0] ]
	else: return l1l1l1_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧ䰢"),[],[]
def l1ll1lll11ll_l1_(url):
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠪࠫ䰣"),l1l1l1_l1_ (u"ࠫࠬ䰤"),l1l1l1_l1_ (u"ࠬ࠭䰥"),l1l1l1_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧ䰦"))
	items = re.findall(l1l1l1_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䰧"),html,re.DOTALL)
	#l111l1lll1l_l1_.l1ll1llllll1_l1_(l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ䰨") + items[0])
	if items:
		url = url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨ䰩") + items[0]
		return l1l1l1_l1_ (u"ࠪࠫ䰪"),[l1l1l1_l1_ (u"ࠫࠬ䰫")],[ url ]
	else: return l1l1l1_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨ䰬"),[],[]
def l1111l1lll1_l1_(url):
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"࠭ࠧ䰭"),l1l1l1_l1_ (u"ࠧࠨ䰮"),l1l1l1_l1_ (u"ࠨࠩ䰯"),l1l1l1_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚࠭࠲ࡵࡷࠫ䰰"))
	items = re.findall(l1l1l1_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䰱"),html,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䰲"),l1l1l1_l1_ (u"ࠬ࠭䰳"),str(items),html)
	if items: return l1l1l1_l1_ (u"࠭ࠧ䰴"),[l1l1l1_l1_ (u"ࠧࠨ䰵")],[ items[0] ]
	else: return l1l1l1_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘࠬ䰶"),[],[]
def l1111111lll_l1_(url):
	#url = url.replace(l1l1l1_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ䰷"),l1l1l1_l1_ (u"ࠪࠫ䰸"))
	html = OPENURL_CACHED(l1llll111_l1_,url,l1l1l1_l1_ (u"ࠫࠬ䰹"),l1l1l1_l1_ (u"ࠬ࠭䰺"),l1l1l1_l1_ (u"࠭ࠧ䰻"),l1l1l1_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ䰼"))
	items = re.findall(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䰽"),html,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䰾"),l1l1l1_l1_ (u"ࠪࠫ䰿"),items[0],items[0])
	if items: return l1l1l1_l1_ (u"ࠫࠬ䱀"),[l1l1l1_l1_ (u"ࠬ࠭䱁")],[ items[0] ]
	else: return l1l1l1_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡖࡘࡗࡋࡁࡎࠩ䱂"),[],[]
l1l1l1_l1_ (u"ࠢࠣࠤࠍࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠋࠥࠣࠤࠥࠦࡎࡐࡖ࡛ࠣࡔࡘࡋࡊࡐࡊࠤࡆࡔ࡙ࡎࡑࡕࡉࠏࠩࠠࠡࠢࠣ࠴࠷࠳ࡆࡆࡄ࠰࠶࠵࠸࠱ࠋࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠐࠊࠋࠌࠍࠦࠧࠨ䱃")
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨᑘ")
menu_name = l1l1l1_l1_ (u"ࠨࡡࡆ࠸ࡍࡥࠧᑙ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫᑚ"),l1l1l1_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫᑛ"),l1l1l1_l1_ (u"ࠫฬ๊วใีส้ࠬᑜ"),l1l1l1_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩᑝ"),l1l1l1_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠪᑞ"),l1l1l1_l1_ (u"ࠧࠨᑟ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l11l11_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l11_l1_(url,text)
	elif mode==694: results = l1ll11_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬᑠ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪᑡ"),l1l1l1_l1_ (u"ࠪࠫᑢ"),l1l1l1_l1_ (u"ࠫࠬᑣ"),l1l1l1_l1_ (u"ࠬ࠭ᑤ"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᑥ"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᑦ"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᑧ"),l1l1l1_l1_ (u"ࠩࠪᑨ"),699,l1l1l1_l1_ (u"ࠪࠫᑩ"),l1l1l1_l1_ (u"ࠫࠬᑪ"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᑫ"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᑬ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑭ"),l1l1l1_l1_ (u"ࠨࠩᑮ"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᑯ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᑰ")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬᑱ"),l1l11l_l1_,691,l1l1l1_l1_ (u"ࠬ࠭ᑲ"),l1l1l1_l1_ (u"࠭ࠧᑳ"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᑴ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᑵ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᑶ")+menu_name+l1l1l1_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩᑷ"),l1l11l_l1_,691,l1l1l1_l1_ (u"ࠫࠬᑸ"),l1l1l1_l1_ (u"ࠬ࠭ᑹ"),l1l1l1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᑺ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᑻ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᑼ")+menu_name+l1l1l1_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨᑽ"),l1l11l_l1_,691,l1l1l1_l1_ (u"ࠪࠫᑾ"),l1l1l1_l1_ (u"ࠫࠬᑿ"),l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩᒀ"))
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒁ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᒂ")+menu_name+l1l1l1_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨᒃ"),l1l11l_l1_,691,l1l1l1_l1_ (u"ࠩࠪᒄ"),l1l1l1_l1_ (u"ࠪࠫᒅ"),l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᒆ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᒇ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᒈ"),l1l1l1_l1_ (u"ࠧࠨᒉ"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒊ"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᒋ"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒌ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᒍ")+menu_name+title,l111ll_l1_,694)
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᒎ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᒏ"),l1l1l1_l1_ (u"ࠧࠨᒐ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨᒑ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢᒒ"),html,re.DOTALL)
	#for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠪࠫᒓ"))
	#block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᒔ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		title = title.replace(l1l1l1_l1_ (u"ࠬࡂࡢ࠿ࠩᒕ"),l1l1l1_l1_ (u"࠭ࠧᒖ")).strip(l1l1l1_l1_ (u"ࠧࠡࠩᒗ"))
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᒘ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᒙ")+menu_name+title,l111ll_l1_,694)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᒚ"),url,l1l1l1_l1_ (u"ࠫࠬᒛ"),l1l1l1_l1_ (u"ࠬ࠭ᒜ"),l1l1l1_l1_ (u"࠭ࠧᒝ"),l1l1l1_l1_ (u"ࠧࠨᒞ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᒟ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒠ"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫᒡ"),l1l1l1_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪᒢ"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᒣ"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"࠭ࠧᒤ"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᒥ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᒦ"),l1l1l1_l1_ (u"ࠩࠪᒧ"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᒨ"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠫ࠿ࠦࠧᒩ")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒪ"),menu_name+title,l111ll_l1_,691)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᒫ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᒬ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᒭ"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᒮ"),l1l1l1_l1_ (u"ࠪࠫᒯ"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᒰ"),menu_name+title,l111ll_l1_,691)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠬ࠭ᒱ")):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᒲ"),l1l1l1_l1_ (u"ࠧࠨᒳ"),request,url)
	if request==l1l1l1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᒴ"):
		url,search = url.split(l1l1l1_l1_ (u"ࠩࡂࠫᒵ"),1)
		data = l1l1l1_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩᒶ")+search
		headers = {l1l1l1_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᒷ"):l1l1l1_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᒸ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫᒹ"),url,data,headers,l1l1l1_l1_ (u"ࠧࠨᒺ"),l1l1l1_l1_ (u"ࠨࠩᒻ"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᒼ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᒽ"),url,l1l1l1_l1_ (u"ࠫࠬᒾ"),l1l1l1_l1_ (u"ࠬ࠭ᒿ"),l1l1l1_l1_ (u"࠭ࠧᓀ"),l1l1l1_l1_ (u"ࠧࠨᓁ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᓂ"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠩࠪᓃ"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧᓄ"))
	if request==l1l1l1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᓅ"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᓆ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"࠭ࠧᓇ"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᓈ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᓉ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᓊ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᓋ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨᓌ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᓍ"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᓎ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡤࡤࠤࡲ࡭ࡢࠡࡶࡤࡦࡱ࡫ࠠࡧࡷ࡯ࡰࠧ࠮࠮ࠫࡁࠬࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧᓏ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᓐ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠩࠪᓑ"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᓒ"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᓓ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"๋ࠬิศ้าอࠬᓔ"),l1l1l1_l1_ (u"࠭แ๋ๆ่ࠫᓕ"),l1l1l1_l1_ (u"ࠧศ฼้๎ฮ࠭ᓖ"),l1l1l1_l1_ (u"ࠨๅ็๎อ࠭ᓗ"),l1l1l1_l1_ (u"ࠩส฽้อๆࠨᓘ"),l1l1l1_l1_ (u"๋ࠪิอแࠨᓙ"),l1l1l1_l1_ (u"๊ࠫฮวาษฬࠫᓚ"),l1l1l1_l1_ (u"ࠬ฿ัืࠩᓛ"),l1l1l1_l1_ (u"࠭ๅ่ำฯห๋࠭ᓜ"),l1l1l1_l1_ (u"ࠧศๆห์๊࠭ᓝ"),l1l1l1_l1_ (u"ࠨ็ึีา๐ษࠨᓞ")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠩ࠲ࠫᓟ"))
		#if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᓠ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭ᓡ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧᓢ"))
		#if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫᓣ") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩᓤ")+img.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪᓥ"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫᓦ"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭ᓧ"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᓨ"),menu_name+title,l111ll_l1_,692,img)
		elif request==l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᓩ"):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᓪ"),menu_name+title,l111ll_l1_,692,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᓫ") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓬ"),menu_name+title,l111ll_l1_,693,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧᓭ") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᓮ"),menu_name+title,l111ll_l1_,691,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓯ"),menu_name+title,l111ll_l1_,693,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᓰ"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᓱ")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᓲ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᓳ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠩࠦࠫᓴ"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬᓵ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭ᓶ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓷ"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬᓸ")+title,l111ll_l1_,691)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨᓹ"),l1l1l1_l1_ (u"ࠨࠩᓺ"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭ᓻ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᓼ"),url,l1l1l1_l1_ (u"ࠫࠬᓽ"),l1l1l1_l1_ (u"ࠬ࠭ᓾ"),l1l1l1_l1_ (u"࠭ࠧᓿ"),l1l1l1_l1_ (u"ࠧࠨᔀ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᔁ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬᔂ"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᔃ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"ࠫࠬᔄ")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࠭ࠧࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭ᔅ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩᔆ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠧࠤࠩᔇ"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔈ"),menu_name+title,url,693,img,l1l1l1_l1_ (u"ࠩࠪᔉ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠫ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠯࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᔊ"),html,re.DOTALL)
	#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬᔋ"),str(l1ll1l1_l1_))
	block = l1ll1l1_l1_[0]
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪᔌ")+l1lll_l1_+l1l1l1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔍ"),block,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠭ᔎ")+l1lll_l1_+l1l1l1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᔏ"),block,re.DOTALL)
	if not l1ll111_l1_: l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡨࡂࠨࡓࡦࡣࡶࡳࡳ࠭ᔐ")+l1lll_l1_+l1l1l1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔑ"),block,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠥᔒ"),block,re.DOTALL)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ᔓ"),l1l1l1_l1_ (u"࠭ࠧᔔ"),l1l1l1_l1_ (u"ࠧࠨᔕ"),l1l1l1_l1_ (u"ࠨ࠴࠵࠶࠷࠸ࠧᔖ"))
		if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ᔗ"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᔘ"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠳࠵ࠧᔙ"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧᔚ")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨᔛ"))
			title = title.replace(l1l1l1_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬᔜ"),l1l1l1_l1_ (u"ࠨࠢࠪᔝ"))
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᔞ"),menu_name+title,l111ll_l1_,692,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᔟ"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᔠ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧᔡ")+l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨᔢ"))
		#		addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᔣ"),menu_name+title,l111ll_l1_,692,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l11_l1_,l111l11_l1_ = [],[],[]
	url2 = url.replace(l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬᔤ"),l1l1l1_l1_ (u"ࠩ࠲ࡷࡪ࡫࠮ࡱࡪࡳࠫᔥ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᔦ"),url2,l1l1l1_l1_ (u"ࠫࠬᔧ"),l1l1l1_l1_ (u"ࠬ࠭ᔨ"),l1l1l1_l1_ (u"࠭ࠧᔩ"),l1l1l1_l1_ (u"ࠧࠨᔪ"),l1l1l1_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᔫ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫᔬ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		# l11ll1l1l_l1_ l111ll_l1_
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᔭ"),block,re.DOTALL)
		if l111ll_l1_:
			l111ll_l1_ = l111ll_l1_[0]
			l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬᔮ"))
			l11l1_l1_.append(l111ll_l1_)
		# l1l1111ll_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡲࡲࡨࡲࡩࡤ࡭࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᔯ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨᔰ"))
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᔱ")+title+l1l1l1_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᔲ"))
				l11l1_l1_.append(l111ll_l1_)
		# download l1ll_l1_
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᔳ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			if l111ll_l1_ not in l11l1_l1_:
				title = title.strip(l1l1l1_l1_ (u"ࠪࡠࡳ࠭ᔴ"))
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᔵ")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᔶ"))
				l11l1_l1_.append(l111ll_l1_)
	zzz = zip(l11l1_l1_,l111l1l11_l1_)
	for l111ll_l1_,name in zzz: l111l11_l1_.append(l111ll_l1_+name)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᔷ"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᔸ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠨࠩᔹ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠩࠪᔺ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬᔻ"),l1l1l1_l1_ (u"ࠫ࠰࠭ᔼ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ᔽ")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᔾ"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࠫᔿ")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᕀ"))
	return
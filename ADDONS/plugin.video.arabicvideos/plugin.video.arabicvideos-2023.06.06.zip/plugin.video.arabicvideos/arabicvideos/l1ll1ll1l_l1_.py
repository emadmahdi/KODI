# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪയ")
menu_name = l1l1l1_l1_ (u"ࠩࡢࡊ࡙ࡓ࡟ࠨര")
l1l11l_l1_ = WEBSITES[script_name][0]
l1lll1111_l1_ = [l1l1l1_l1_ (u"ࠪ࠵࠷࠹࠹ࠨറ"),l1l1l1_l1_ (u"ࠫ࠶࠸࠵࠱ࠩല"),l1l1l1_l1_ (u"ࠬ࠷࠲࠵࠷ࠪള"),l1l1l1_l1_ (u"࠭࠲࠱ࠩഴ"),l1l1l1_l1_ (u"ࠧ࠲࠴࠸࠽ࠬവ"),l1l1l1_l1_ (u"ࠨ࠴࠴࠼ࠬശ"),l1l1l1_l1_ (u"ࠩ࠷࠼࠺࠭ഷ"),l1l1l1_l1_ (u"ࠪ࠵࠷࠹࠸ࠨസ"),l1l1l1_l1_ (u"ࠫ࠶࠸࠵࠹ࠩഹ"),l1l1l1_l1_ (u"ࠬ࠸࠹࠳ࠩഺ")]
l1ll1llll_l1_ = [l1l1l1_l1_ (u"࠭࠳࠱࠵࠳഻ࠫ"),l1l1l1_l1_ (u"ࠧ࠷࠴࠻഼ࠫ")]
def MAIN(mode,url,text):
	if   mode==60: results = MENU()
	elif mode==61: results = l11l11_l1_(url,text)
	elif mode==62: results = l11l1ll_l1_(url)
	elif mode==63: results = PLAY(url)
	elif mode==64: results = l1lll111l_l1_(text)
	elif mode==69: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨഽ"),menu_name+l1l1l1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩാ"),l1l1l1_l1_ (u"ࠪࠫി"),69,l1l1l1_l1_ (u"ࠫࠬീ"),l1l1l1_l1_ (u"ࠬ࠭ു"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪൂ"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧൃ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪൄ")+menu_name+l1l1l1_l1_ (u"่ࠩหࠥ๐สๆุ่ࠢฬํฯห้ࠣห้อๆࠨ൅"),l1l11l_l1_,64,l1l1l1_l1_ (u"ࠪࠫെ"),l1l1l1_l1_ (u"ࠫࠬേ"),l1l1l1_l1_ (u"ࠬࡸࡥࡤࡧࡱࡸࡤࡼࡩࡦࡹࡨࡨࡤࡼࡩࡥࡵࠪൈ"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭൉"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩൊ")+menu_name+l1l1l1_l1_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨോ"),l1l11l_l1_,64,l1l1l1_l1_ (u"ࠩࠪൌ"),l1l1l1_l1_ (u"്ࠪࠫ"),l1l1l1_l1_ (u"ࠫࡲࡵࡳࡵࡡࡹ࡭ࡪࡽࡥࡥࡡࡹ࡭ࡩࡹࠧൎ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ൏"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ൐")+menu_name+l1l1l1_l1_ (u"ࠧศุํๅฯࠦๅละิหࠬ൑"),l1l11l_l1_,64,l1l1l1_l1_ (u"ࠨࠩ൒"),l1l1l1_l1_ (u"ࠩࠪ൓"),l1l1l1_l1_ (u"ࠪࡶࡪࡩࡥ࡯ࡶ࡯ࡽࡤࡧࡤࡥࡧࡧࡣࡻ࡯ࡤࡴࠩൔ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫൕ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧൖ")+menu_name+l1l1l1_l1_ (u"࠭แ๋ัํ์ࠥ฿ิ้ษษ๎ࠬൗ"),l1l11l_l1_,64,l1l1l1_l1_ (u"ࠧࠨ൘"),l1l1l1_l1_ (u"ࠨࠩ൙"),l1l1l1_l1_ (u"ࠩࡵࡥࡳࡪ࡯࡮ࡡࡹ࡭ࡩࡹࠧ൚"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ൛"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭൜")+menu_name+l1l1l1_l1_ (u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭൝"),l1l11l_l1_,61,l1l1l1_l1_ (u"࠭ࠧ൞"),l1l1l1_l1_ (u"ࠧࠨൟ"),l1l1l1_l1_ (u"ࠨ࠯࠴ࠫൠ"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩൡ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬൢ")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ศาษ่ะࠥอไะ์้๎ฮ࠭ൣ"),l1l11l_l1_,61,l1l1l1_l1_ (u"ࠬ࠭൤"),l1l1l1_l1_ (u"࠭ࠧ൥"),l1l1l1_l1_ (u"ࠧ࠮࠴ࠪ൦"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ൧"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ൨")+menu_name+l1l1l1_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠤ࡛࡯ࡤࡦࡱࡶࠫ൩"),l1l11l_l1_,61,l1l1l1_l1_ (u"ࠫࠬ൪"),l1l1l1_l1_ (u"ࠬ࠭൫"),l1l1l1_l1_ (u"࠭࠭࠴ࠩ൬"))
	return l1l1l1_l1_ (u"ࠧࠨ൭")
def l11l11_l1_(url,category):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ൮"),l1l1l1_l1_ (u"ࠩࠪ൯"),l1l1l1_l1_ (u"ࠪࠫ൰"), category)
	cat = l1l1l1_l1_ (u"ࠫࠬ൱")
	if category not in [l1l1l1_l1_ (u"ࠬ࠳࠱ࠨ൲"),l1l1l1_l1_ (u"࠭࠭࠳ࠩ൳"),l1l1l1_l1_ (u"ࠧ࠮࠵ࠪ൴")]: cat = l1l1l1_l1_ (u"ࠨࡁࡦࡥࡹࡃࠧ൵")+category
	url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡱࡪࡴࡵࡠ࡮ࡨࡺࡪࡲ࠮ࡱࡪࡳࠫ൶")+cat
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠪࠫ൷"),l1l1l1_l1_ (u"ࠫࠬ൸"),l1l1l1_l1_ (u"ࠬ࠭൹"),l1l1l1_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬൺ"))
	items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ൻ"),html,re.DOTALL)
	l1ll1lll1_l1_,l1lll1l1l_l1_ = False,False
	for l111ll_l1_,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪർ"))
		if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧൽ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩൾ")+l111ll_l1_
		cat = re.findall(l1l1l1_l1_ (u"ࠫࡨࡧࡴ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨൿ"),l111ll_l1_,re.DOTALL)[0]
		if category==cat: l1ll1lll1_l1_ = True
		elif l1ll1lll1_l1_ 	or (category==l1l1l1_l1_ (u"ࠬ࠳࠱ࠨ඀") and cat in l1lll1111_l1_) \
						or (category==l1l1l1_l1_ (u"࠭࠭࠳ࠩඁ") and cat not in l1ll1llll_l1_ and cat not in l1lll1111_l1_) \
						or (category==l1l1l1_l1_ (u"ࠧ࠮࠵ࠪං") and cat in l1ll1llll_l1_):
							if count==l1l1l1_l1_ (u"ࠨ࠳ࠪඃ"): addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ඄"),menu_name+title,l111ll_l1_,63)
							else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪඅ"),menu_name+title,l111ll_l1_,61,l1l1l1_l1_ (u"ࠫࠬආ"),l1l1l1_l1_ (u"ࠬ࠭ඇ"),cat)
							l1lll1l1l_l1_ = True
	if not l1lll1l1l_l1_: l11l1ll_l1_(url)
	return
def l11l1ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"࠭ࠧඈ"),l1l1l1_l1_ (u"ࠧࠨඉ"),True,l1l1l1_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩඊ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪඋ"),l1l1l1_l1_ (u"ࠪࠫඌ"),url , html)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠩඍ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡭ࡲࡪࡦࡢࡺ࡮࡫ࡷ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪඎ"),block,re.DOTALL)
	l111ll_l1_ = l1l1l1_l1_ (u"࠭ࠧඏ")
	for img,title,l111ll_l1_ in items:
		title = title.replace(l1l1l1_l1_ (u"ࠧࡂࡦࡧࠫඐ"),l1l1l1_l1_ (u"ࠨࠩඑ")).replace(l1l1l1_l1_ (u"ࠩࡷࡳࠥࡗࡵࡪࡥ࡮ࡰ࡮ࡹࡴࠨඒ"),l1l1l1_l1_ (u"ࠪࠫඓ")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭ඔ"))
		if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪඕ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬඖ")+l111ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭඗"),menu_name+title,l111ll_l1_,63,img)
	l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ඘"),block,re.DOTALL)
	block=l1ll1l1_l1_[0]
	block=re.findall(l1l1l1_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ඙"),html,re.DOTALL)[0]
	items=re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬක"),block,re.DOTALL)
	url2 = url.split(l1l1l1_l1_ (u"ࠫࡄ࠭ඛ"))[0]
	for l111ll_l1_,l1ll1ll11_l1_ in items:
		l111ll_l1_ = url2 + l111ll_l1_
		title = unescapeHTML(l1ll1ll11_l1_)
		title = l1l1l1_l1_ (u"ࠬ฻แฮหࠣࠫග") + title
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ඝ"),menu_name+title,l111ll_l1_,62)
	return l111ll_l1_
def PLAY(url):
	if l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫඞ") in url: url = l11l1ll_l1_(url)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠨࠩඟ"),l1l1l1_l1_ (u"ࠩࠪච"),True,l1l1l1_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧඡ"))
	items = re.findall(l1l1l1_l1_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫජ"),html,re.DOTALL)
	url = items[0]
	if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪඣ") not in url: url = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬඤ")+url
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ඥ"))
	return
def l1lll111l_l1_(category):
	payload = { l1l1l1_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭ඦ") : category }
	url = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰ࡫ࡧࡴࡪ࡯࡬࠲ࡹࡼ࠯ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࠩට")
	headers = { l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩඨ") : l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪඩ") }
	data = l1lll11l1_l1_(payload)
	html = OPENURL_CACHED(l1llll111_l1_,url,data,headers,True,l1l1l1_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏ࠭ࡎࡑࡖࡘࡘ࠳࠱ࡴࡶࠪඪ"))
	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬ࠧණ"),html,re.DOTALL)
	for l111ll_l1_,title,img in items:
		title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩඬ"))
		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ත") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨථ")+l111ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩද"),menu_name+title,l111ll_l1_,63,img)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬධ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭න"): return
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ඲"),l1l1l1_l1_ (u"ࠧࠨඳ"),search, l1l11l_l1_)
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪප"),l1l1l1_l1_ (u"ࠩ࠮ࠫඵ"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡣࡷ࡫ࡳࡶ࡮ࡷ࠲ࡵ࡮ࡰࡀࡳࡸࡩࡷࡿ࠽ࠨබ") + l11ll11_l1_ # + l1l1l1_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀ࠵ࠬභ")
	l11l1ll_l1_(url)
	return
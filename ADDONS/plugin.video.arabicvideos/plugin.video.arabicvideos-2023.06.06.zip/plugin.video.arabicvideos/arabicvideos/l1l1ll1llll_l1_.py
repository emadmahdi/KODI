# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
#
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡏࡈࡒ࡚࡙ࠧ㨕")
def MAIN(mode,url,text):
	if   mode==260: results = MENU()
	elif mode==261: results = l1l1ll1l111_l1_()
	elif mode==263: results = l1l1lll1lll_l1_()
	elif mode==264: results = l1l1llll11l_l1_()
	elif mode==265: results = l1l1lll11l1_l1_(text)
	elif mode==266: results = l1l1llll111_l1_(text)
	elif mode==267: results = l1l1ll1111l_l1_(True)
	elif mode==531: results = l1l1llllll1_l1_()
	else: results = False
	return results
def MENU():
	if kodi_version<18: addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㨖"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ๊อๅࠢสฺ่๊วไๆࠣฯอะࠠไ๊า๎ࠥำฯ๋อ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㨗"),l1l1l1_l1_ (u"ࠫࠬ㨘"),341)
	l1l1ll11111_l1_,l1l1ll1lll1_l1_ = False,False
	l1l1ll111l1_l1_ = settings.getSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㨙"))
	if l1l1ll111l1_l1_==l1l1l1_l1_ (u"࠭ࠧ㨚"): l1l1ll111l1_l1_ = l1l1ll1111l_l1_(False)
	if l1l1ll111l1_l1_==l1l1l1_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㨛"): l1l1ll11111_l1_ = True
	elif l1l1ll111l1_l1_==l1l1l1_l1_ (u"ࠨࡐࡈ࡛ࠬ㨜"): l1l1ll1lll1_l1_ = True
	elif l1l1ll111l1_l1_==l1l1l1_l1_ (u"ࠩࡒࡐࡉ࠭㨝"): l1l1ll1lll1_l1_ = False
	else: return
	l1l1ll11ll1_l1_ = l1l1lll1l1l_l1_([l1l1l1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㨞"),l1l1l1_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭㨟")])
	#l1l1ll11111_l1_ = True
	if l1l1ll11111_l1_:
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㨠"),l1l1l1_l1_ (u"࠭࠱࠯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡอืๆศ็ฯࠤ฾๋วะࠢไ๎์ࠦๅีๅ็อࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㨡"),l1l1l1_l1_ (u"ࠧࠨ㨢"),531)
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㨣"),l1l1l1_l1_ (u"ࠩ࠵࠲ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㨤"),l1l1l1_l1_ (u"ࠪࠫ㨥"),531)
		addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㨦"),l1l1l1_l1_ (u"ࠬ࠹࠮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㨧"),l1l1l1_l1_ (u"࠭ࠧ㨨"),531)
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㨩"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠴ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠱࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㨪"),l1l1l1_l1_ (u"ࠩࠪ㨫"),9990)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ㨬"),l1l1l1_l1_ (u"ࠫࠬ㨭"),str(l1l1ll11111_l1_),str(l1l1ll1lll1_l1_))
	if l1l1ll11111_l1_ or l1l1ll1lll1_l1_: addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㨮"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ๆา๎่ࠦัิษ็อ๋ࠥๆࠡษ็้อืๅอ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㨯"),l1l1l1_l1_ (u"ࠧࠨ㨰"),267)
	if l1l1ll11111_l1_ or l1l1ll11ll1_l1_: addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㨱"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ้ี๊ไࠢอัิ๐หࠡ็้ࠤฬ๊ๅษำ่ะࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㨲"),l1l1l1_l1_ (u"ࠪࠫ㨳"),159)
	if l1l1ll11111_l1_ or l1l1ll11ll1_l1_ or l1l1ll1lll1_l1_:
		addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㨴"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠱ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠵ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㨵"),l1l1l1_l1_ (u"࠭ࠧ㨶"),9990)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㨷"),l1l1l1_l1_ (u"ࠨࡐࡲࠤࡆࡸࡡࡣ࡫ࡦࠫ㨸"),l1l1l1_l1_ (u"ࠩࠪ㨹"),151)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㨺"),l1l1l1_l1_ (u"ࠫ฾์ࠠศๆศ฽้อๆศฬࠪ㨻"),l1l1l1_l1_ (u"ࠬ࠭㨼"),346)
	if not l1l1ll11111_l1_:
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㨽"),l1l1l1_l1_ (u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ㨾"),l1l1l1_l1_ (u"ࠨࠩ㨿"),501)
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㩀"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠴࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㩁"),l1l1l1_l1_ (u"ࠫࠬ㩂"),9990)
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩃"),l1l1l1_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅีํ๊๊อࠧ㩄"),l1l1l1_l1_ (u"ࠧࠨ㩅"),510)
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㩆"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠷ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠴࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㩇"),l1l1l1_l1_ (u"ࠪࠫ㩈"),9990)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㩉"),l1l1l1_l1_ (u"ࠬอไโ์า๎ํํวหࠩ㩊"),l1l1l1_l1_ (u"࠭ࠧ㩋"),165,l1l1l1_l1_ (u"ࠧࠨ㩌"),l1l1l1_l1_ (u"ࠨࠩ㩍"),l1l1l1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ㩎"))
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㩏"),l1l1l1_l1_ (u"๊ࠫ๎วใ฻ࠣห้็๊ะ์๋ࠫ㩐"),l1l1l1_l1_ (u"ࠬ࠭㩑"),261)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㩒"),l1l1l1_l1_ (u"ࠧใ๊สส๊ࠦวๅไ้์ฬะࠧ㩓"),l1l1l1_l1_ (u"ࠨࠩ㩔"),100)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㩕"),l1l1l1_l1_ (u"ࠪๆํอฦๆࠢส่฾ฺ่ศศํอࠬ㩖"),l1l1l1_l1_ (u"ࠫࠬ㩗"),160)
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩘"),l1l1l1_l1_ (u"࠭ศฮอࠣฬ่๊ࠠศๆ่์ฬู่ࠨ㩙"),l1l1l1_l1_ (u"ࠧࠨ㩚"),540)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㩛"),l1l1l1_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ะ้้ฯࠧ㩜"),l1l1l1_l1_ (u"ࠪࠫ㩝"),330)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㩞"),l1l1l1_l1_ (u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠤ๊์๋๊ࠠอ๎ํฮࠧ㩟"),l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ㩠"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㩡"),l1l1l1_l1_ (u"ࠨ็๋ห็฿๋๊ࠠอ๎ํฮࠠๆ่ࠣห้ฮั็ษ่ะࠬ㩢"),l1l1l1_l1_ (u"ࠩࠪ㩣"),290)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㩤"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠳ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠷ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㩥"),l1l1l1_l1_ (u"ࠬ࠭㩦"),9990)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㩧"),l1l1l1_l1_ (u"ࠧใ๊สส๊ࠦสี฼ํ่ࠥࡓ࠳ࡖࠩ㩨"),l1l1l1_l1_ (u"ࠨࠩ㩩"),710)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㩪"),l1l1l1_l1_ (u"ࠪๆํอฦๆࠢฦๆุอๅࠡࡏ࠶࡙ࠬ㩫"),l1l1l1_l1_ (u"ࠫࠬ㩬"),724,l1l1l1_l1_ (u"ࠬ࠭㩭"),l1l1l1_l1_ (u"࠭ࠧ㩮"),l1l1l1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㩯"))
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㩰"),l1l1l1_l1_ (u"ࠩหัะࠦฬๆ์฼ࠤࡒ࠹ࡕࠨ㩱"),l1l1l1_l1_ (u"ࠪࠫ㩲"),719,l1l1l1_l1_ (u"ࠫࠬ㩳"),l1l1l1_l1_ (u"ࠬ࠭㩴"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㩵"))
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㩶"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠸ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠵࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㩷"),l1l1l1_l1_ (u"ࠩࠪ㩸"),9990)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㩹"),l1l1l1_l1_ (u"ࠫ็๎วว็ࠣหูะัศๅࠣࡍࡕ࡚ࡖࠨ㩺"),l1l1l1_l1_ (u"ࠬ࠭㩻"),230)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㩼"),l1l1l1_l1_ (u"ࠧใ๊สส๊ࠦรใีส้ࠥࡏࡐࡕࡘࠪ㩽"),l1l1l1_l1_ (u"ࠨࠩ㩾"),284,l1l1l1_l1_ (u"ࠩࠪ㩿"),l1l1l1_l1_ (u"ࠪࠫ㪀"),l1l1l1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ㪁"))
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㪂"),l1l1l1_l1_ (u"࠭ศฮอࠣะ๊๐ูࠡࡋࡓࡘ࡛࠭㪃"),l1l1l1_l1_ (u"ࠧࠨ㪄"),239,l1l1l1_l1_ (u"ࠨࠩ㪅"),l1l1l1_l1_ (u"ࠩࠪ㪆"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㪇"))
		addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㪈"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠶ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠺ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㪉"),l1l1l1_l1_ (u"࠭ࠧ㪊"),9990)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪋"),l1l1l1_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠳ࠪ㪌"),l1l1l1_l1_ (u"ࠩࠪ㪍"),270,l1l1l1_l1_ (u"ࠪࠫ㪎"),l1l1l1_l1_ (u"ࠫࠬ㪏"),l1l1l1_l1_ (u"ࠬ࠭㪐"),l1l1l1_l1_ (u"࠭࠱ࠨ㪑"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪒"),l1l1l1_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠴ࠪ㪓"),l1l1l1_l1_ (u"ࠩࠪ㪔"),270,l1l1l1_l1_ (u"ࠪࠫ㪕"),l1l1l1_l1_ (u"ࠫࠬ㪖"),l1l1l1_l1_ (u"ࠬ࠭㪗"),l1l1l1_l1_ (u"࠭࠲ࠨ㪘"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪙"),l1l1l1_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠵ࠪ㪚"),l1l1l1_l1_ (u"ࠩࠪ㪛"),270,l1l1l1_l1_ (u"ࠪࠫ㪜"),l1l1l1_l1_ (u"ࠫࠬ㪝"),l1l1l1_l1_ (u"ࠬ࠭㪞"),l1l1l1_l1_ (u"࠭࠳ࠨ㪟"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪠"),l1l1l1_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠶ࠪ㪡"),l1l1l1_l1_ (u"ࠩࠪ㪢"),270,l1l1l1_l1_ (u"ࠪࠫ㪣"),l1l1l1_l1_ (u"ࠫࠬ㪤"),l1l1l1_l1_ (u"ࠬ࠭㪥"),l1l1l1_l1_ (u"࠭࠴ࠨ㪦"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪧"),l1l1l1_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠷ࠪ㪨"),l1l1l1_l1_ (u"ࠩࠪ㪩"),270,l1l1l1_l1_ (u"ࠪࠫ㪪"),l1l1l1_l1_ (u"ࠫࠬ㪫"),l1l1l1_l1_ (u"ࠬ࠭㪬"),l1l1l1_l1_ (u"࠭࠵ࠨ㪭"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㪮"),l1l1l1_l1_ (u"ࠨไสส๊ฯࠠระิࠤ࠺࠶ࠠโ์า๎ํ࠭㪯"),l1l1l1_l1_ (u"ࠩࠪ㪰"),265,l1l1l1_l1_ (u"ࠪࠫ㪱"),l1l1l1_l1_ (u"ࠫࠬ㪲"),l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㪳"))
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㪴"),l1l1l1_l1_ (u"ࠧใษษ้ฮࠦยฯำࠣ࠹࠵ࠦโ็ษฬࠫ㪵"),l1l1l1_l1_ (u"ࠨࠩ㪶"),265,l1l1l1_l1_ (u"ࠩࠪ㪷"),l1l1l1_l1_ (u"ࠪࠫ㪸"),l1l1l1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㪹"))
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㪺"),l1l1l1_l1_ (u"࠭โศศ่อࠥศฮาࠢ࠸࠴๋ࠥฬๅัࠪ㪻"),l1l1l1_l1_ (u"ࠧࠨ㪼"),265,l1l1l1_l1_ (u"ࠨࠩ㪽"),l1l1l1_l1_ (u"ࠩࠪ㪾"),l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㪿"))
		#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㫀"),l1l1l1_l1_ (u"ࠬࡥࡅࡎࡆࡢࠫ㫁")+l1l1l1_l1_ (u"࠭โศศ่อࠥ็อึࠢࡌࡔ࡙࡜เࠨ㫂"),l1l1l1_l1_ (u"ࠧࠨ㫃"),9999,l1l1l1_l1_ (u"ࠨࠩ㫄"),l1l1l1_l1_ (u"ࠩࠪ㫅"),l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㫆"))
		#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㫇"),l1l1l1_l1_ (u"ࠬࡥࡅࡎࡆࡢࠫ㫈")+l1l1l1_l1_ (u"࠭โศศ่อࠥ็อึࠩ㫉"),l1l1l1_l1_ (u"ࠧࠨ㫊"),9999,l1l1l1_l1_ (u"ࠨࠩ㫋"),l1l1l1_l1_ (u"ࠩࠪ㫌"),l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㫍"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㫎"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠷ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠻ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㫏"),l1l1l1_l1_ (u"࠭ࠧ㫐"),9990)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㫑"),l1l1l1_l1_ (u"ࠨว฼่ฬ์วหࠢฮๆฬ็๊สࠢศื้อๅ๋หࠪ㫒"),l1l1l1_l1_ (u"ࠩࠪ㫓"),505)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㫔"),l1l1l1_l1_ (u"ࠫฯ่ั๋ำࠣหุะฮะษ่ࠤฬ๊ศา่ส้ั࠭㫕"),l1l1l1_l1_ (u"ࠬ࠭㫖"),176)
	if l1l1ll1lll1_l1_: addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㫗"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ิืฬฬไ๊ࠡฦาออัࠡ็้ࠤฬ๊ๅษำ่ะࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㫘"),l1l1l1_l1_ (u"ࠨࠩ㫙"),267)
	else: addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㫚"),l1l1l1_l1_ (u"ࠪีุอฦๅ๋ࠢวำฮวา่๊ࠢࠥอไๆสิ้ั࠭㫛"),l1l1l1_l1_ (u"ࠫࠬ㫜"),267)
	if l1l1ll11ll1_l1_: addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㫝"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ษฺีวาࠢิๆ๊ࠦࠨࠡࠩ㫞")+addon_version+l1l1l1_l1_ (u"ࠧࠡࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㫟"),l1l1l1_l1_ (u"ࠨࠩ㫠"),7)
	else: addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㫡"),l1l1l1_l1_ (u"ࠪห้หีะษิࠤึ่ๅࠡࠪࠣࠫ㫢")+addon_version+l1l1l1_l1_ (u"ࠫࠥ࠯ࠧ㫣"),l1l1l1_l1_ (u"ࠬ࠭㫤"),7)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㫥"),l1l1l1_l1_ (u"ࠧหไิ๎ึูࠦ็ࠢลาึࠦวๅฬ฽๎๏ืวหࠩ㫦"),l1l1l1_l1_ (u"ࠨࠩ㫧"),199)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㫨"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠽ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠺࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㫩"),l1l1l1_l1_ (u"ࠫࠬ㫪"),9990)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㫫"),l1l1l1_l1_ (u"࠭โศศ่อࠥอไฤฮ๋ฬฮ࠭㫬"),l1l1l1_l1_ (u"ࠧࠨ㫭"),263)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㫮"),l1l1l1_l1_ (u"ࠩๅหห๋ษࠡษ็าิ๋วหࠩ㫯"),l1l1l1_l1_ (u"ࠪࠫ㫰"),264)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㫱"),l1l1l1_l1_ (u"ࠬอไๆ๊ๅ฽ࠥอไาี่๎ࠬ㫲"),l1l1l1_l1_ (u"࠭ࠧ㫳"),341)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㫴"),l1l1l1_l1_ (u"ࠨษ็ษ๋าวำษอࠤฬ๊รฯำ์ࠫ㫵"),l1l1l1_l1_ (u"ࠩࠪ㫶"),348)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㫷"),l1l1l1_l1_ (u"ࠫฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧ㫸"),l1l1l1_l1_ (u"ࠬ࠭㫹"),196)
	return
def l1l1ll1l111_l1_():
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㫺"),l1l1l1_l1_ (u"ࠧࠡࠢ࠴࠲ࠥࠦ࡟ࡕࡘ࠳ࡣࠬ㫻")+l1l1l1_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠪ㫼"),l1l1l1_l1_ (u"ࠩࠪ㫽"),100)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㫾"),l1l1l1_l1_ (u"ࠫࠥࠦ࠲࠯ࠢࠣࡣࡎࡖࡔࡠࠩ㫿")+l1l1l1_l1_ (u"ࠬอิหำส็ࠥࡏࡐࡕࡘ้ࠣิ็ฺ่ࠩ㬀"),l1l1l1_l1_ (u"࠭ࠧ㬁"),230)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㬂"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ู้ࠣอใๅࠢๅ่๏๊ษ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㬃"),l1l1l1_l1_ (u"ࠩࠪ㬄"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㬅"),l1l1l1_l1_ (u"ࠫࡤࡈࡋࡓࡡࠪ㬆")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣฬ่ืวࠨ㬇"),l1l1l1_l1_ (u"࠭ࠧ㬈"),370)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㬉"),l1l1l1_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ㬊")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯ࠭㬋"),l1l1l1_l1_ (u"ࠪࠫ㬌"),30)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㬍"),l1l1l1_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ㬎")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫ㬏"),l1l1l1_l1_ (u"ࠧࠨ㬐"),140)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㬑"),l1l1l1_l1_ (u"ࠩࡢࡏࡑࡇ࡟ࠨ㬒")+l1l1l1_l1_ (u"้ࠪํู่ࠡๅ็ࠤฬู๊าสࠪ㬓"),l1l1l1_l1_ (u"ࠫࠬ㬔"),10)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㬕"),l1l1l1_l1_ (u"࠭࡟ࡌࡔࡅࡣࠬ㬖")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪ㬗"),l1l1l1_l1_ (u"ࠨࠩ㬘"),320)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㬙"),l1l1l1_l1_ (u"ࠪࡣࡋࡎ࠱ࡠࠩ㬚")+l1l1l1_l1_ (u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭㬛"),l1l1l1_l1_ (u"ࠬ࠭㬜"),570)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㬝"),l1l1l1_l1_ (u"ࠧࡠࡇࡊࡆࡤ࠭㬞")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ㬟"),l1l1l1_l1_ (u"ࠩࠪ㬠"),120) # 128
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㬡"),l1l1l1_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪ㬢")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭㬣"),l1l1l1_l1_ (u"࠭ࠧ㬤"),400)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㬥"),l1l1l1_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ㬦")+l1l1l1_l1_ (u"ࠩࠣࠤ๊๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ㬧"),l1l1l1_l1_ (u"ࠪࠫ㬨"),20)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㬩"),l1l1l1_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫ㬪")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ㬫"),l1l1l1_l1_ (u"ࠧࠨ㬬"),70)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㬭"),l1l1l1_l1_ (u"ࠩࡢࡅࡐ࡝࡟ࠨ㬮") +l1l1l1_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ㬯"),l1l1l1_l1_ (u"ࠫࠬ㬰"),240)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㬱"),l1l1l1_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬ㬲")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫ㬳"),l1l1l1_l1_ (u"ࠨࠩ㬴"),40)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㬵"),l1l1l1_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ㬶")+l1l1l1_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫ㬷"),l1l1l1_l1_ (u"ࠬ࠭㬸"),50)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㬹"),l1l1l1_l1_ (u"ࠧࡠࡈࡗࡑࡤ࠭㬺")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧ㬻"),l1l1l1_l1_ (u"ࠩࠪ㬼"),60)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㬽"),l1l1l1_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ㬾")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨ㬿"),l1l1l1_l1_ (u"࠭ࠧ㭀"),130)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㭁"),l1l1l1_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ㭂")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫ㭃"),l1l1l1_l1_ (u"ࠪࠫ㭄"),310)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㭅"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦๅีษๆ่้ࠥห๋ำฬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㭆"),l1l1l1_l1_ (u"࠭ࠧ㭇"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㭈"),l1l1l1_l1_ (u"ࠨࡡࡎࡘࡐࡥࠧ㭉")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭㭊"),l1l1l1_l1_ (u"ࠪࠫ㭋"),670)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㭌"),l1l1l1_l1_ (u"ࠬࡥࡆࡋࡕࡢࠫ㭍")+l1l1l1_l1_ (u"࠭ࠠࠡ็๋ๆ฾ࠦแอำุࠣํ࠭㭎"),l1l1l1_l1_ (u"ࠧࠨ㭏"),390)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㭐"),l1l1l1_l1_ (u"ࠩࡢࡘ࡛ࡌ࡟ࠨ㭑")+l1l1l1_l1_ (u"้ࠪํู่ࠡฬํๅ๏ࠦแศ่ࠪ㭒"),l1l1l1_l1_ (u"ࠫࠬ㭓"),460)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㭔"),l1l1l1_l1_ (u"࠭࡟ࡍࡆࡑࡣࠬ㭕")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭㭖"),l1l1l1_l1_ (u"ࠨࠩ㭗"),450)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㭘"),l1l1l1_l1_ (u"ࠪࡣࡈࡓࡎࡠࠩ㭙")+l1l1l1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠ็ษ๋ࠫ㭚"),l1l1l1_l1_ (u"ࠬ࠭㭛"),300)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㭜"),l1l1l1_l1_ (u"ࠧࡠ࡙ࡆࡑࡤ࠭㭝")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠧ㭞"),l1l1l1_l1_ (u"ࠩࠪ㭟"),560)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㭠"),l1l1l1_l1_ (u"ࠫࡤ࡙ࡈࡏࡡࠪ㭡")+l1l1l1_l1_ (u"๋่ࠬใ฻ุࠣฬํฯ่ࠡํ์ื࠭㭢"),l1l1l1_l1_ (u"࠭ࠧ㭣"),580)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㭤"),l1l1l1_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧ㭥")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩ㭦"),l1l1l1_l1_ (u"ࠪࠫ㭧"),360)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㭨"),l1l1l1_l1_ (u"ࠬࡥࡓࡉࡒࡢࠫ㭩")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬ㭪"),l1l1l1_l1_ (u"ࠧࠨ㭫"),480)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㭬"),l1l1l1_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨ㭭")+l1l1l1_l1_ (u"้ࠪํู่ࠡ฻ิฬู๊๋ࠥัࠪ㭮"),l1l1l1_l1_ (u"ࠫࠬ㭯"),250)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㭰"),l1l1l1_l1_ (u"࠭࡟ࡄ࠶ࡘࡣࠬ㭱")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩ㭲"),l1l1l1_l1_ (u"ࠨࠩ㭳"),420)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㭴"),l1l1l1_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩ㭵")+l1l1l1_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭㭶"),l1l1l1_l1_ (u"ࠬ࠭㭷"),110)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㭸"),l1l1l1_l1_ (u"ࠧࡠࡏ࠷࡙ࡤ࠭㭹")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦๅ้ใีࠤๆ๎ั๋๊ࠪ㭺"),l1l1l1_l1_ (u"ࠩࠪ㭻"),380)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㭼"),l1l1l1_l1_ (u"ࠫࡤࡋࡇࡗࡡࠪ㭽")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣษ๏า๊ࠡสํืฯࠦࡶࡪࡲࠪ㭾"),l1l1l1_l1_ (u"࠭ࠧ㭿"),220)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㮀"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ู้ࠣอใๅࠢๆฯ๏ืษࠡฮาหࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮁"),l1l1l1_l1_ (u"ࠩࠪ㮂"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮃"),l1l1l1_l1_ (u"ࠫࡤࡒࡒ࡛ࡡࠪ㮄")+l1l1l1_l1_ (u"๋่ࠬใ฻่ࠣฬื่ำษࠪ㮅"),l1l1l1_l1_ (u"࠭ࠧ㮆"),700)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮇"),l1l1l1_l1_ (u"ࠨࡡࡉࡗ࡙ࡥࠧ㮈")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠโ๊ึฮฬ࠭㮉"),l1l1l1_l1_ (u"ࠪࠫ㮊"),600)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮋"),l1l1l1_l1_ (u"ࠬࡥࡆࡃࡍࡢࠫ㮌")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤๆฮัไหࠪ㮍"),l1l1l1_l1_ (u"ࠧࠨ㮎"),620)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮏"),l1l1l1_l1_ (u"ࠩࡢ࡝ࡖ࡚࡟ࠨ㮐")+l1l1l1_l1_ (u"้ࠪํู่ࠡ์สๆํะࠧ㮑"),l1l1l1_l1_ (u"ࠫࠬ㮒"),660)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮓"),l1l1l1_l1_ (u"࠭࡟ࡃࡔࡖࡣࠬ㮔")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ࠥฮัิฬํะࠬ㮕"),l1l1l1_l1_ (u"ࠨࠩ㮖"),650)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮗"),l1l1l1_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩ㮘")+l1l1l1_l1_ (u"๊ࠫ๎โฺ๊่ࠢฬࠦำ๋็สࠫ㮙"),l1l1l1_l1_ (u"ࠬ࠭㮚"),80)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮛"),l1l1l1_l1_ (u"ࠧࡠࡆࡕ࠻ࡤ࠭㮜")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨ㮝"),l1l1l1_l1_ (u"ࠩࠪ㮞"),680)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮟"),l1l1l1_l1_ (u"ࠫࡤࡉࡍࡇࡡࠪ㮠")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡใส๊ื࠭㮡"),l1l1l1_l1_ (u"࠭ࠧ㮢"),90)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮣"),l1l1l1_l1_ (u"ࠨࡡࡆࡑࡑࡥࠧ㮤")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ㮥"),l1l1l1_l1_ (u"ࠪࠫ㮦"),470)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮧"),l1l1l1_l1_ (u"ࠬࡥࡁࡃࡆࡢࠫ㮨")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧ㮩"),l1l1l1_l1_ (u"ࠧࠨ㮪"),550)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮫"),l1l1l1_l1_ (u"ࠩࡢࡇ࠹ࡎ࡟ࠨ㮬")+l1l1l1_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪ㮭"),l1l1l1_l1_ (u"ࠫࠬ㮮"),690)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮯"),l1l1l1_l1_ (u"࠭࡟ࡂࡊࡎࡣࠬ㮰")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩ㮱"),l1l1l1_l1_ (u"ࠨࠩ㮲"),610)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮳"),l1l1l1_l1_ (u"ࠪࡣࡈࡉࡂࡠࠩ㮴")+l1l1l1_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ㮵"),l1l1l1_l1_ (u"ࠬ࠭㮶"),630)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮷"),l1l1l1_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭㮸")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪ㮹"),l1l1l1_l1_ (u"ࠩࠪ㮺"),640)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮻"),l1l1l1_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ㮼")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬ㮽"),l1l1l1_l1_ (u"࠭ࠧ㮾"),430)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮿"),l1l1l1_l1_ (u"ࠨࡡࡉࡌ࠷ࡥࠧ㯀")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอไฬษ้๎ࠬ㯁"),l1l1l1_l1_ (u"ࠪࠫ㯂"),590)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯃"),l1l1l1_l1_ (u"ࠬࡥࡅࡈࡆࡢࠫ㯄")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭㯅"),l1l1l1_l1_ (u"ࠧࠨ㯆"),440)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯇"),l1l1l1_l1_ (u"ࠩࡢࡅࡐࡉ࡟ࠨ㯈")+l1l1l1_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠไษ่ࠫ㯉"),l1l1l1_l1_ (u"ࠫࠬ㯊"),350)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯋"),l1l1l1_l1_ (u"࠭࡟ࡄࡏࡆࡣࠬ㯌")+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨ㯍"),l1l1l1_l1_ (u"ࠨࠩ㯎"),490)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㯏"),l1l1l1_l1_ (u"ࠪࡣࡆࡘࡌࡠࠩ㯐")+l1l1l1_l1_ (u"๊ࠫ๎โฺࠢ฼ีอࠦไ๋๊้ึࠬ㯑"),l1l1l1_l1_ (u"ࠬ࠭㯒"),200)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㯓"),l1l1l1_l1_ (u"ࠧࡠࡊࡈࡐࡤ࠭㯔")+l1l1l1_l1_ (u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫ㯕"),l1l1l1_l1_ (u"ࠩࠪ㯖"),90)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㯗"),l1l1l1_l1_ (u"ࠫࡤ࡙ࡆࡘࡡࠪ㯘")+l1l1l1_l1_ (u"๋่ࠬใ฻ࠣื๏ื๊ิࠢไ์ึ่ࠦหึࠪ㯙"),l1l1l1_l1_ (u"࠭ࠧ㯚"),218)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯛"),l1l1l1_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧ㯜")+l1l1l1_l1_ (u"่ࠩ์็฿ࠠๆ๊ไ๎ื๊ว็ัࠣหํ์ไศ์้ࠫ㯝"),l1l1l1_l1_ (u"ࠪࠫ㯞"),188) # 180
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯟"),l1l1l1_l1_ (u"ࠬࡥࡅࡈࡄࡢࠫ㯠")+l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧ㯡"),l1l1l1_l1_ (u"ࠧࠨ㯢"),120) # 128
	return
def l1l1llll11l_l1_():
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯣"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡๅࠦࡐࡳࡱࡥࡰࡪࡳࡳࠡࠨࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࡸࠦࠠใษษ้ฮࠦๅีษๆ่ࠥ๎ริศ็อࠥࠦ࠮࠲ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㯤"),l1l1l1_l1_ (u"ࠪࠫ㯥"),264)
	#addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㯦"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡࠢ࠵࠲࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㯧")+l1l1l1_l1_ (u"࠭แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆหี๋อๅอࠩ㯨"),l1l1l1_l1_ (u"ࠧࠨ㯩"),175)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㯪"),l1l1l1_l1_ (u"ࠩࡑࡳࠥࡇࡲࡢࡤ࡬ࡧࠥࡒࡥࡵࡶࡨࡶࡸࠦࠨࡰࡴࠣࡘࡪࡾࡴࠪࠩ㯫"),l1l1l1_l1_ (u"ࠪࠫ㯬"),151)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㯭"),l1l1l1_l1_ (u"ࠬหศๅษ฽ࠤ฾์ࠠๆึๆ่ฮ࠭㯮"),l1l1l1_l1_ (u"࠭ࠧ㯯"),2,l1l1l1_l1_ (u"ࠧࠨ㯰"),l1l1l1_l1_ (u"ࠨࠩ㯱"),l1l1l1_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ㯲"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㯳"),l1l1l1_l1_ (u"ࠫึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㯴"),l1l1l1_l1_ (u"ࠬ࠭㯵"),2,l1l1l1_l1_ (u"࠭ࠧ㯶"),l1l1l1_l1_ (u"ࠧࠨ㯷"),l1l1l1_l1_ (u"ࠨࠩ㯸"))
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㯹"),l1l1l1_l1_ (u"ࠪษึูวๅࠢึะ้ࠦวๅลั฻ฬวࠠศๆะห้๐ࠧ㯺"),l1l1l1_l1_ (u"ࠫࠬ㯻"),2,l1l1l1_l1_ (u"ࠬ࠭㯼"),l1l1l1_l1_ (u"࠭ࠧ㯽"),l1l1l1_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ㯾"))
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㯿"),l1l1l1_l1_ (u"ࠩศีุอไࠡีฯ่ࠥอไฦะฺหฦࠦวๅไา๎๊࠭㰀"),l1l1l1_l1_ (u"ࠪࠫ㰁"),2,l1l1l1_l1_ (u"ࠫࠬ㰂"),l1l1l1_l1_ (u"ࠬ࠭㰃"),l1l1l1_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭㰄"))
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㰅"),l1l1l1_l1_ (u"ࠨไิหฦฯࠠิฮ็ࠤฬ๊รฯูสลࠥอไฮษ็๎ࠬ㰆"),l1l1l1_l1_ (u"ࠩࠪ㰇"),340,l1l1l1_l1_ (u"ࠪࠫ㰈"),l1l1l1_l1_ (u"ࠫࠬ㰉"),l1l1l1_l1_ (u"ࠬࡥࡌࡐࡉࡉࡍࡑࡋ࡟ࠨ㰊"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㰋"),l1l1l1_l1_ (u"ࠧใำสลฮࠦำอๆࠣห้ษฮุษฤࠤฬ๊โะ์่ࠫ㰌"),l1l1l1_l1_ (u"ࠨࠩ㰍"),340,l1l1l1_l1_ (u"ࠩࠪ㰎"),l1l1l1_l1_ (u"ࠪࠫ㰏"),l1l1l1_l1_ (u"ࠫࡤࡒࡏࡈࡈࡌࡐࡊࡥࡏࡍࡆࡢࠫ㰐"))
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㰑"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㰒"),l1l1l1_l1_ (u"ࠧࠨ㰓"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㰔"),l1l1l1_l1_ (u"ࠩศ๎็อแ๊ࠡอุ฿๐ไࠡษ็็ฬฺࠧ㰕"),l1l1l1_l1_ (u"ࠪࠫ㰖"),345)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㰗"),l1l1l1_l1_ (u"ࠬอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆ็ฬึ์วๆฮࠪ㰘"),l1l1l1_l1_ (u"࠭ࠧ㰙"),507,l1l1l1_l1_ (u"ࠧࠨ㰚"),l1l1l1_l1_ (u"ࠨࠩ㰛"),l1l1l1_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㰜"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㰝"),l1l1l1_l1_ (u"ࠫฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏࠭㰞"),l1l1l1_l1_ (u"ࠬ࠭㰟"),159)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㰠"),l1l1l1_l1_ (u"ࠧฦ์ๅหๆ่ࠦหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩ㰡"),l1l1l1_l1_ (u"ࠨࠩ㰢"),343)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㰣"),l1l1l1_l1_ (u"ࠪษ๏่วโ๋ࠢฮูเ๊ๅࠢอาื๐ๆࠡษ็ๆํอฦๆࠩ㰤"),l1l1l1_l1_ (u"ࠫࠬ㰥"),508)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㰦"),l1l1l1_l1_ (u"࠭แฮืࠣ์ส฻ไศฯࠣฦำืࠠศๆอัิ๐หศฬࠪ㰧"),l1l1l1_l1_ (u"ࠧࠨ㰨"),7)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㰩"),l1l1l1_l1_ (u"ࠩอ฾๏๐ัࠡ็ๆห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩ㰪"),l1l1l1_l1_ (u"ࠪࠫ㰫"),332)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㰬"),l1l1l1_l1_ (u"ࠬห๊ใษไࠤํะิ฻์็ࠤุ๐ัโำสฮࠥอไษำ๋็ุ๐ࠧ㰭"),l1l1l1_l1_ (u"࠭ࠧ㰮"),342)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㰯"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㰰"),l1l1l1_l1_ (u"ࠩࠪ㰱"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㰲"),l1l1l1_l1_ (u"ࠫส฻ไศฯ้ࠣำุๆࠡ฻่หิ࠭㰳"),l1l1l1_l1_ (u"ࠬ࠭㰴"),172)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㰵"),l1l1l1_l1_ (u"ࠧฦื็หาࠦๅๅใࠣห้ืำศศ็ࠫ㰶"),l1l1l1_l1_ (u"ࠨࠩ㰷"),349)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㰸"),l1l1l1_l1_ (u"ࠪษฺ๊วฮࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ㰹"),l1l1l1_l1_ (u"ࠫࠬ㰺"),504)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㰻"),l1l1l1_l1_ (u"࠭ลึๆสัࠥ็๊ะ์๋๋ฬะࠠ࡮ࡲࡧࠫ㰼"),l1l1l1_l1_ (u"ࠧࠨ㰽"),173)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㰾"),l1l1l1_l1_ (u"ࠩศู้ออࠡใํำ๏๎็ศฬࠣࡶࡹࡳࡰࠨ㰿"),l1l1l1_l1_ (u"ࠪࠫ㱀"),174)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㱁"),l1l1l1_l1_ (u"ࠬหีๅษะࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠨ㱂"),l1l1l1_l1_ (u"࠭ࠧ㱃"),502)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㱄"),l1l1l1_l1_ (u"ࠨวุ่ฬำࠠใ๊สส๊ࠦยฯำࠣห้็๊ะ์๋๋ฬะࠧ㱅"),l1l1l1_l1_ (u"ࠩࠪ㱆"),503)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㱇"),l1l1l1_l1_ (u"ࠫส฻ไศฯࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠫ㱈"),l1l1l1_l1_ (u"ࠬ࠭㱉"),506)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㱊"),l1l1l1_l1_ (u"ࠧโฯุࠤฬะีศๆࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬ㱋"),l1l1l1_l1_ (u"ࠨࠩ㱌"),4)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㱍"),l1l1l1_l1_ (u"ࠪษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥใ้ัํࠫ㱎"),l1l1l1_l1_ (u"ࠫࠬ㱏"),347)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㱐"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㱑"),l1l1l1_l1_ (u"ࠧࠨ㱒"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㱓"),l1l1l1_l1_ (u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬ㱔"),l1l1l1_l1_ (u"ࠪࠫ㱕"),9)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㱖"),l1l1l1_l1_ (u"๋ࠬำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠬ㱗"),l1l1l1_l1_ (u"࠭ࠧ㱘"),344)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㱙"),l1l1l1_l1_ (u"ࠨว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏࠭㱚"),l1l1l1_l1_ (u"ࠩࠪ㱛"),6)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㱜"),l1l1l1_l1_ (u"ࠫส฿ฯศัสฮࠥ࡟࡯ࡶࡶࡸࡦࡪ࠭㱝"),l1l1l1_l1_ (u"ࠬ࠭㱞"),179)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㱟"),l1l1l1_l1_ (u"ࠧฦ฻าหิอส࡛ࠡࡲࡹࡹࡻࡢࡦ࠯ࡇࡐࠬ㱠"),l1l1l1_l1_ (u"ࠨࠩ㱡"),178)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㱢"),l1l1l1_l1_ (u"ࠪษ฾ีวะษอࠤࡗ࡫ࡳࡰ࡮ࡹࡩ࡚ࡘࡌࠨ㱣"),l1l1l1_l1_ (u"ࠫࠬ㱤"),177)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㱥"),l1l1l1_l1_ (u"࠭ลฺัสำฬะࠠࡊࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠥࡇࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㱦"),l1l1l1_l1_ (u"ࠧࠨ㱧"),5)
	return
def l1l1lll1lll_l1_():
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㱨"),l1l1l1_l1_ (u"ࠩࡑࡳࠥࡇࡲࡢࡤ࡬ࡧࠥࡒࡥࡵࡶࡨࡶࡸࠦࠨࡰࡴࠣࡘࡪࡾࡴࠪࠩ㱩"),l1l1l1_l1_ (u"ࠪࠫ㱪"),151)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㱫"),l1l1l1_l1_ (u"๋ࠬว้๋ࠡࠤฬ็ึๅࠢฯ่ิࠦไๅสิ๊ฬ๋ฬࠨ㱬"),l1l1l1_l1_ (u"࠭ࠧ㱭"),197)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㱮"),l1l1l1_l1_ (u"ࠨ็สࠤ์๎ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอࠩ㱯"),l1l1l1_l1_ (u"ࠩࠪ㱰"),341)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㱱"),l1l1l1_l1_ (u"๊ࠫอ่๊ࠠࠣฦำืࠠฦืาหึࠦไไ๊า๎ࠥ๎ไๅสิ๊ฬ๋ฬࠨ㱲"),l1l1l1_l1_ (u"ࠬ࠭㱳"),7)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㱴"),l1l1l1_l1_ (u"ࠧไ์ไ๎ฮࠦวิฬัำฬ๋ࠠศๆ่ๅ฻๊ษࠨ㱵"),l1l1l1_l1_ (u"ࠨࠩ㱶"),150)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㱷"),l1l1l1_l1_ (u"ࠪ็๏็๊ส่ࠢืาࠦๅฮฬ๋๎ฬะࠠใษษ้ฮ࠭㱸"),l1l1l1_l1_ (u"ࠫࠬ㱹"),170)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㱺"),l1l1l1_l1_ (u"࠭ใ๋ใࠣฮฯ฻ไ๊ࠡอฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭㱻"),l1l1l1_l1_ (u"ࠧࠨ㱼"),196)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㱽"),l1l1l1_l1_ (u"่ࠩหࠥํ่ࠡษ็็ฬฺ้ࠠๅ่ࠤ฾๋ั่ࠢหห้ฮั็ษ่ะࠬ㱾"),l1l1l1_l1_ (u"ࠪࠫ㱿"),190)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㲀"),l1l1l1_l1_ (u"๊ࠬๅศาสࠤอ฿ึࠡษ็ีํอศุࠢห฻๏ฬษࠨ㲁"),l1l1l1_l1_ (u"࠭ࠧ㲂"),155)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㲃"),l1l1l1_l1_ (u"ࠨๆ่หีอࠠษ฻ูࠤฬ๊ั้ษห฻๊ࠥวࠡฬ฼้้࠭㲄"),l1l1l1_l1_ (u"ࠩࠪ㲅"),153)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㲆"),l1l1l1_l1_ (u"้๋ࠫวัษࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอ๊ࠥวࠡฬ฼้้࠭㲇"),l1l1l1_l1_ (u"ࠬ࠭㲈"),152)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㲉"),l1l1l1_l1_ (u"ࠧๅ็สิฬࠦศฺุࠣห้๋่ศไ฼ࠤ้อࠠห฻่่ࠬ㲊"),l1l1l1_l1_ (u"ࠨࠩ㲋"),195)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㲌"),l1l1l1_l1_ (u"ࠪฮาึ๊าࠢําฺࠦิ่ษาอࠥอไหึไ๎ึ࠭㲍"),l1l1l1_l1_ (u"ࠫࠬ㲎"),171)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㲏"),l1l1l1_l1_ (u"࠭ไๆษำหࠥ๐่อัࠣื๏ืแาษอࠤ๊า็้ๆฬࠫ㲐"),l1l1l1_l1_ (u"ࠧࠨ㲑"),156)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㲒"),l1l1l1_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯࠦๆ้฻ࠣࡱࡵࡪࠠๅษࠣฮ฾๋ไࠨ㲓"),l1l1l1_l1_ (u"ࠪࠫ㲔"),194)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㲕"),l1l1l1_l1_ (u"๊ࠬๅศาสࠤ้อࠠ็ใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠬ㲖"),l1l1l1_l1_ (u"࠭ࠧ㲗"),193)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㲘"),l1l1l1_l1_ (u"ࠨส฼ฺࠥอไโ์า๎ํํวหࠢห฻๏ฬษ๊ࠡอๆ฼฿ࠧ㲙"),l1l1l1_l1_ (u"ࠩࠪ㲚"),158)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㲛"),l1l1l1_l1_ (u"่ࠫ๐แࠡฬะ่ࠥฮๆโีๆࠤฺ๊ใๅห้ࠣษ่ส่ࠩ㲜"),l1l1l1_l1_ (u"ࠬ࠭㲝"),192)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㲞"),l1l1l1_l1_ (u"ࠧไ์ไࠤฯูสฯั่ࠤฬ๊ั๋็๋ฮู๋ࠥࠡๅ๋ำ๏࠭㲟"),l1l1l1_l1_ (u"ࠨࠩ㲠"),198)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㲡"),l1l1l1_l1_ (u"้ࠪฬࠦ็๋ࠢสุ่๐ัโำสฮࠥอไฺษ่อࠥ๎วๅะสูฮ࠭㲢"),l1l1l1_l1_ (u"ࠫࠬ㲣"),157)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㲤"),l1l1l1_l1_ (u"࠭ๅศ่ࠢ฽๋๏่ࠠา๊ࠤฬู๊ๅษ่หฯࠦศศๆหี๋อๅอࠢ࠯ࠫ㲥")+half_triangular_colon+l1l1l1_l1_ (u"ࠧ࠼ࠩ㲦"),l1l1l1_l1_ (u"ࠨࠩ㲧"),191)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㲨"),l1l1l1_l1_ (u"ࠪ็๏็ࠠหฯ็ࠤฺ๊ใๅหࠣััฮࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠬ㲩"),l1l1l1_l1_ (u"ࠫࠬ㲪"),195)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㲫"),l1l1l1_l1_ (u"࠭ร๋่้ࠣํอโฺࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะࠠศๆฦะ๋ฮ๊สࠩ㲬"),l1l1l1_l1_ (u"ࠧࠨ㲭"),154)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㲮"),l1l1l1_l1_ (u"ࠩๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠩ㲯"),l1l1l1_l1_ (u"ࠪࠫ㲰"),3)
	return
def l1l1lll11l1_l1_(type_,l1l1ll11l11_l1_=False):
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲱"),l1l1l1_l1_ (u"๋ࠬำฮ๊ࠢิ์ࠦวๅไสส๊ฯࠧ㲲"),l1l1l1_l1_ (u"࠭ࠧ㲳"),266,l1l1l1_l1_ (u"ࠧࠨ㲴"),l1l1l1_l1_ (u"ࠨࠩ㲵"),type_)
	#addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㲶"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㲷"),l1l1l1_l1_ (u"ࠫࠬ㲸"),9999)
	l1111_l1_ = []
	if os.path.exists(l1l1l1lllll_l1_):
		l1l1lll1ll1_l1_ = open(l1l1l1lllll_l1_,l1l1l1_l1_ (u"ࠬࡸࡢࠨ㲹")).read()
		if kodi_version>18.99: l1l1lll1ll1_l1_ = l1l1lll1ll1_l1_.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㲺"))
		l1l1ll1l1l1_l1_ = EVAL(l1l1l1_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㲻"),l1l1lll1ll1_l1_)
		if type_ in list(l1l1ll1l1l1_l1_.keys()):
			l1111_l1_ = l1l1ll1l1l1_l1_[type_]
			if not l1l1ll11l11_l1_:
				try:
					for type,name,url,mode,image,page,text,context,infodict in l1111_l1_:
						addMenuItem(type,name,url,mode,image,page,text,context,infodict)
				except:
					#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ㲼"),l1l1l1_l1_ (u"ࠩࠪ㲽"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㲾"),l1l1l1_l1_ (u"ࠫ์์วไุ่่๊ࠢษࠡใํࠤ๊๊แࠡฤัีࠥอไโ์า๎ํํวหࠩ㲿"),l1l1l1_l1_ (u"๊ࠬใ๋ࠢอฮำ๊ีࠡ็้ࠤฬ๊ๅีๅ็อࠥอึ฻ูࠣ฽้๏ࠧ㳀"),l1l1l1_l1_ (u"࠭ࠢๆีะࠤ์ึ็ࠡษ็ๆฬฬๅสࠤࠪ㳁"))
					l1l1ll1l1l1_l1_ = FIX_AND_GET_FILE_CONTENTS(l1l1l1lllll_l1_)
					l1111_l1_ = l1l1ll1l1l1_l1_[type_]
					for type,name,url,mode,image,page,text,context,infodict in l1111_l1_:
						addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return len(l1111_l1_)
def l1l1llll111_l1_(type_):
	answer = DIALOG_YESNO(l1l1l1_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㳂"),l1l1l1_l1_ (u"ࠨࠩ㳃"),l1l1l1_l1_ (u"ࠩࠪ㳄"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㳅"),l1l1l1_l1_ (u"ࠫ์๊ࠠหำํำࠥ็ูๅษุ้ࠣำࠠอ็ํ฽๋ࠥอห๊ํหฯࠦโศศ่อࠥศฮาࠢ࠸࠴ࠥ࠭㳆")+TRANSLATE(type)+l1l1l1_l1_ (u"ࠬࠦฟࠢࠩ㳇"))
	if answer==1:
		if os.path.exists(l1l1l1lllll_l1_):
			l1l1lll1ll1_l1_ = open(l1l1l1lllll_l1_,l1l1l1_l1_ (u"࠭ࡲࡣࠩ㳈")).read()
			if kodi_version>18.99: l1l1lll1ll1_l1_ = l1l1lll1ll1_l1_.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㳉"))
			l1l1lll1ll1_l1_ = EVAL(l1l1l1_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㳊"),l1l1lll1ll1_l1_)
			if type_ in list(l1l1lll1ll1_l1_.keys()):
				del l1l1lll1ll1_l1_[type_]
				l1l1lll1ll1_l1_ = str(l1l1lll1ll1_l1_)
				if kodi_version>18.99: l1l1lll1ll1_l1_ = l1l1lll1ll1_l1_.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㳋"))
				open(l1l1l1lllll_l1_,l1l1l1_l1_ (u"ࠪࡻࡧ࠭㳌")).write(l1l1lll1ll1_l1_)
				DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ㳍"),l1l1l1_l1_ (u"ࠬ࠭㳎"),l1l1l1_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㳏"),l1l1l1_l1_ (u"ࠧห็ุ้ࠣำࠠอ็ํ฽๋ࠥอห๊ํหฯࠦโศศ่อࠥศฮาࠢ࠸࠴ࠥ࠭㳐")+TRANSLATE(type))
	l1l1lll11l1_l1_(type_)
	#settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㳑"),l1l1l1_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ㳒"))
	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㳓"))
	return
def l1l1ll1111l_l1_(showDialogs):
	url = WEBSITES[l1l1l1_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㳔")][3]
	l1l1lll1l11_l1_ = l1ll11l1lll_l1_(32)
	payload = {l1l1l1_l1_ (u"ࠬࡻࡳࡦࡴࠪ㳕"):l1l1lll1l11_l1_,l1l1l1_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ㳖"):addon_version}
	if showDialogs: DELETE_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ㳗"),(l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭㳘"),url,payload,l1l1l1_l1_ (u"ࠩࠪ㳙"),l1l1l1_l1_ (u"ࠪࠫ㳚"),l1l1l1_l1_ (u"ࠫࠬ㳛"),l1l1l1_l1_ (u"ࠬࡓࡅࡏࡗࡖ࠱ࡘࡎࡏࡘࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨ㳜")))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ㳝"),url,payload,l1l1l1_l1_ (u"ࠧࠨ㳞"),l1l1l1_l1_ (u"ࠨࠩ㳟"),l1l1l1_l1_ (u"ࠩࠪ㳠"),l1l1l1_l1_ (u"ࠪࡑࡊࡔࡕࡔ࠯ࡖࡌࡔ࡝࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭㳡"),True,True)
	if not response.succeeded: l1l1ll111l1_l1_ = l1l1l1_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㳢")
	else:
		l1l1ll11lll_l1_,l1l1ll111ll_l1_,l1l1lll111l_l1_,l1l1ll11l1l_l1_ = l1l1l1_l1_ (u"ࠬ࠭㳣"),l1l1l1_l1_ (u"࠭ࠧ㳤"),l1l1l1_l1_ (u"ࠧࠨ㳥"),[]
		newfile = response.content
		if newfile:
			l1l1ll11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㳦"),newfile)
			for l1l1ll1ll1l_l1_,l1ll1111111_l1_,message in l1l1ll11l1l_l1_:
				if kodi_version>18.99: message = message.encode(l1l1l1_l1_ (u"ࠩࡵࡥࡼࡥࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㳧")).decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㳨"))
				if l1l1ll1ll1l_l1_==l1l1l1_l1_ (u"ࠫ࠵࠭㳩"): l1l1ll11lll_l1_ += message+l1l1l1_l1_ (u"ࠬࡀ࠺ࠨ㳪")
				else: l1l1ll111ll_l1_ += message+l1l1l1_l1_ (u"࠭࡜࡯ࠩ㳫")
			l1l1ll111ll_l1_ = l1l1ll111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ㳬"))
			l1l1ll11lll_l1_ = l1l1ll11lll_l1_.strip(l1l1l1_l1_ (u"ࠨ࠼࠽ࠫ㳭"))
		settings.setSetting(l1l1l1_l1_ (u"ࠩࡤࡺ࠳ࡻࡳࡦࡴ࠱ࡴࡷ࡯ࡶࡴࠩ㳮"),l1l1ll11lll_l1_)
		settings.setSetting(l1l1l1_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ㳯"),str(now))
		if os.path.exists(l1ll111111l_l1_): l1l1lll111l_l1_ = open(l1ll111111l_l1_,l1l1l1_l1_ (u"ࠫࡷࡨࠧ㳰")).read()
		if kodi_version>18.99: l1l1ll111ll_l1_ = l1l1ll111ll_l1_.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㳱"))
		if l1l1ll111ll_l1_==l1l1lll111l_l1_: l1l1ll111l1_l1_ = l1l1l1_l1_ (u"࠭ࡏࡍࡆࠪ㳲")
		else:
			l1l1ll111l1_l1_ = l1l1l1_l1_ (u"ࠧࡏࡇ࡚ࠫ㳳")
			open(l1ll111111l_l1_,l1l1l1_l1_ (u"ࠨࡹࡥࠫ㳴")).write(l1l1ll111ll_l1_)
		if showDialogs:
			l1l1ll111l1_l1_ = l1l1l1_l1_ (u"ࠩࡒࡐࡉ࠭㳵")
			l1l1ll11l1l_l1_ = sorted(l1l1ll11l1l_l1_,reverse=True,key=lambda key: int(key[0]))
			l1l1lll1111_l1_ = l1l1l1_l1_ (u"ࠪࠫ㳶")
			for l1l1ll1ll1l_l1_,l1ll1111111_l1_,message in l1l1ll11l1l_l1_:
				if kodi_version>18.99: message = message.encode(l1l1l1_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㳷")).decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㳸"))
				if l1l1lll1111_l1_: l1l1lll1111_l1_ += l1l1l1_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ㳹")
				if l1l1ll1ll1l_l1_==l1l1l1_l1_ (u"ࠧ࠱ࠩ㳺"): continue
				date = message.split(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ㳻"))[0]
				l1llllll1_l1_ = l1l1l1_l1_ (u"ࠩࠪ㳼")
				if l1ll1111111_l1_:
					l1llllll1_l1_ = l1l1l1_l1_ (u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧ㳽")
					if kodi_version>18.99: l1llllll1_l1_ = l1llllll1_l1_.encode(l1l1l1_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㳾")).decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㳿"))
				l1l1lll1111_l1_ += message.replace(date,l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㴀")+date+l1llllll1_l1_+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㴁"))+l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ㴂")
			l1l1lll1111_l1_ = escapeUNICODE(l1l1lll1111_l1_)
			l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㴃"),l1l1l1_l1_ (u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭㴄"),l1l1lll1111_l1_,l1l1l1_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㴅"))
			#settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㴆"),l1l1l1_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩ㴇"))
			xbmc.executebuiltin(l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㴈"))
	settings.setSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㴉"),l1l1ll111l1_l1_)
	return l1l1ll111l1_l1_
def l1l1lll1l1l_l1_(l1l1ll1ll11_l1_):
	l11l1l1l1l_l1_ = l1l1lllll1l_l1_()
	l1l1ll11ll1_l1_ = False
	for addon_id in l1l1ll1ll11_l1_:
		if l1l1ll11ll1_l1_: continue
		if addon_id not in list(l11l1l1l1l_l1_.keys()): continue
		l1l1lll11ll_l1_ = l11l1l1l1l_l1_[addon_id]
		l1l1llll1ll_l1_,l1l1lllll11_l1_,l1l1lllllll_l1_ = l1l1lll11ll_l1_[0]
		l1l1l1llll1_l1_,l1l1ll1l11l_l1_ = l1l1llll1l1_l1_(addon_id)
		if not l1l1l1llll1_l1_: l1l1ll11ll1_l1_ = True
		else:
			l1l1ll1l1ll_l1_ = l1l1lllll11_l1_>l1l1ll1l11l_l1_
			if l1l1ll1l1ll_l1_: l1l1ll11ll1_l1_ = True
	return l1l1ll11ll1_l1_
def l1l1llllll1_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㴊"),l1l1l1_l1_ (u"ࠪࠫ㴋"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㴌"),l1l1l1_l1_ (u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํฺ่ࠠา็๋ࠥิไๆฬࠤ่ฮ๊าหࠣ࠲࠳ࠦรษัฦࠤอ็อึࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣัฬ๎ไࠡฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥ࠴࠮ࠡษ็ู้้ไสࠢ฼๊ิ้ࠠฦ็สࠤอูศษࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣฬุฮศࠡล้ࠤฬ๊ศา่ส้ัูࠦ็ัๆࠤ็ี๊ๆࠢ࠱࠲ࠥษ่ࠡสึฬอࠦร็ࠢส่๊ฮัๆฮࠣๆฬ๋ࠠษวํๆฬ็ࠠศๆหี๋อๅอࠢ฼่๎ࠦฬ่ษี็ࠥ࠴࠮ࠡล๋ࠤอูศษࠢส๊่ࠦไศࠢอืฯิฯๆࠢหี๋อๅอࠢ฼้ฬีࠠศๆฦู้๐ࠠ࠯࠰่๊ࠣ฿ัโหࠣห้๋ิไๆฬࠤออไืสฺࠤฬ์สࠡสะหัฯࠠฦๆ์ࠤสืำศๆࠣี็๋ࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ึห฾ีใࠡใํࠤา๊ࠠๆึๆ่ฮࠦฬ่ษี็ࠥํะศࠩ㴍"))
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ崫")
menu_name = l1l1l1_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ崬")
l1l11l_l1_ = WEBSITES[script_name][0]
#headers = l1l1l1_l1_ (u"ࠫࠬ崭")
#headers = {l1l1l1_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ崮"):l1l1l1_l1_ (u"࠭ࠧ崯")}
def MAIN(mode,url,text,type,page):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1ll1l11ll_l1_(url)
	#elif mode==142: results = l1l1111ll1l1_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,page)
	elif mode==145: results = l1l11l1l1l1l_l1_(url)
	elif mode==146: results = l1l1111l1lll_l1_(url)
	elif mode==147: results = l1l111lllll1_l1_()
	elif mode==148: results = l1l11l111111_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡊ࠳࡙ࡥ࡛ࡏࡇ࡛ࡳࡻ࡮ࡅࡸࡒ࡙ࡷࡇࡨ࡝࡞࡛࡚ࡌࡑࡍࡽࡾࡵࡸࡸࡐࡕࠪ崰")
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ崱"),menu_name+l1l1l1_l1_ (u"ࠩࡗࡉࡘ࡚࡚ࠠࡑࡘࡘ࡚ࡈࡅࠨ崲"),url,144)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崳"),menu_name+l1l1l1_l1_ (u"ࠫࡴࡲࡤࡦࡴࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࠥࡴ࡯ࡵࠢ࡯࡭ࡸࡺࡩ࡯ࡩࠣࡲࡪࡽࡥࡳࠢࡳࡰࡾࡧ࡬ࡪࡵࡷࠫ崴"),l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡊࡵࡷࡥ࡚ࡼ࡛࡞࡫ࡱࠦ࡭࡫ࡶࡸࡂࡘࡄࡒࡏ࠹࠷ࡻࡎࡪࡑ࠲࡫ࡩ࡙ࡹࠧ崵"),144)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崶"),menu_name+l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วา฼ࠪ崷"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡺࡏࡷࡱࡱ࡮࠹ࡍࡹࡰࡲࡐࡘࡒࡈࡡ࠳࠵ࡴ࡙ࡨࡽࠧ崸"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崹"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ崺"),l1l1l1_l1_ (u"ࠫࠬ崻"),149,l1l1l1_l1_ (u"ࠬ࠭崼"),l1l1l1_l1_ (u"࠭ࠧ崽"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ崾"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ崿"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ嵀")+l1l1l1_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ嵁")+l1l1l1_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤฬ๊ๅษำ่ะࠬ嵂"),l1l1l1_l1_ (u"ࠬ࠭嵃"),290)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嵄"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嵅")+menu_name+l1l1l1_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡ์๋ฮ๏๎ศࠨ嵆"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ嵇"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵈"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嵉")+menu_name+l1l1l1_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ嵊"),l1l11l_l1_,144,l1l1l1_l1_ (u"࠭ࠧ嵋"),l1l1l1_l1_ (u"ࠧࠨ嵌"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嵍"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嵎"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嵏")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅฮฬ๋ํࠥอไาษษะࠬ嵐"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭嵑"),146)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嵒"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嵓"),l1l1l1_l1_ (u"ࠨࠩ嵔"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嵕"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嵖")+menu_name+l1l1l1_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ嵗"),l1l1l1_l1_ (u"ࠬ࠭嵘"),147)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嵙"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嵚")+menu_name+l1l1l1_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ嵛"),l1l1l1_l1_ (u"ࠩࠪ嵜"),148)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵝"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嵞")+menu_name+l1l1l1_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ嵟"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ嵠"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵡"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嵢")+menu_name+l1l1l1_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭嵣"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ嵤"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵥"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ嵦")+menu_name+l1l1l1_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ嵧"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ嵨"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嵩"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ嵪")+menu_name+l1l1l1_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ嵫"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ嵬"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嵭"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ嵮")+menu_name+l1l1l1_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭嵯"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ嵰"),144)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嵱"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嵲")+menu_name+l1l1l1_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ嵳"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ嵴"),144)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嵵"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嵶")+menu_name+l1l1l1_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭嵷"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭嵸"),144)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵹"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嵺")+menu_name+l1l1l1_l1_ (u"ࠬอไฺำสๆࠥิืษหࠣห้๋ัอ฻ํอࠬ嵻"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎ࠷࡮࡚ࡷ࠶ࡱࡰࡊ࠷࠻ࡗࡪࡶ࡚ࡇ࡬ࡓࡴࡉ࡭ࡴ࡬ࡹࡿࡸ࡯ࡕࡈࡷࡱ࡫ࡸࠧ嵼"),144)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵽"),menu_name+l1l1l1_l1_ (u"ࠨษ฼ำฬีวหࠢสฺฬ็ษࠡ์๋ฮ๏๎ศࠨ嵾"),l1l1l1_l1_ (u"ࠩࠪ嵿"),144)
	#yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ嶀"),l1l1l1_l1_ (u"ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ嶁"),l1l1l1_l1_ (u"ࠬํะศࠢส่ฬิส๋ษิࠤุ๎แࠡ์ัีั้ࠠๆ่ࠣห้ฮั็ษ่ะࠬ嶂"),l1l1l1_l1_ (u"࠭ไฤ่๊ࠤุ๎แࠡ์ๅ์๊ࠦศหึ฽๎้ࠦศา่ส้ั๊้ࠦฬํ์อ࠭嶃"))
	#if yes==1:
	#	url = l1l1l1_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ嶄")
	#	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬ嶅"))
	#	xbmc.executebuiltin(l1l1l1_l1_ (u"ࠩࡕࡩࡵࡲࡡࡤࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡹ࡭ࡩ࡫࡯ࡴ࠮ࠪ嶆")+url+l1l1l1_l1_ (u"ࠪ࠭ࠬ嶇"))
	#	#xbmc.executebuiltin(l1l1l1_l1_ (u"ࠫࡗࡻ࡮ࡂࡦࡧࡳࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠧ嶈"))
	return
l1l1l1_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡓࡁࡊࡐࡓࡅࡌࡋࠨࡶࡴ࡯࠭࠿ࠐࠉࡩࡶࡰࡰ࠱ࡩࡣ࠭ࡦࡤࡸࡦࠦ࠽ࠡࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁࠩࡷࡵࡰ࠮ࠐࠉࡪࡨࠣࠫࡗ࡫ࡦࡢࡣࡷࠤࡆࡲ࠭ࡈࡣࡰࡱࡦࡲࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡽࡪࡹࠧࠪࠌࠌࡨࡩࠦ࠽ࠡࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠎࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡰࡤ࡫ࡪ࠮࡬ࡦࡰࠫࡨࡩ࠯ࠩ࠻ࠌࠌࠍ࡮ࡺࡥ࡮ࠢࡀࠤࡩࡪ࡛ࡪ࡟ࠍࠍࠎࡏࡎࡔࡇࡕࡘࡤࡏࡔࡆࡏࡢࡘࡔࡥࡍࡆࡐࡘࠬ࡮ࡺࡥ࡮ࠫࠍࠍࡎ࡚ࡅࡎࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧ嶉")
def l1l111lllll1_l1_():
	ITEMS(l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭嶊"))
	return
def l1l11l111111_l1_():
	ITEMS(l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ嶋"))
	return
def PLAY(url,type):
	#url = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ嶌")
	#items = re.findall(l1l1l1_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ嶍"),url,re.DOTALL)
	#id = items[0]
	#l111ll_l1_ = l1l1l1_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ嶎")+id
	#PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嶏"))
	#return
	l1l1l1_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ嶐")
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l1l1111l1lll_l1_(url):
	html,cc,data = l1l111lll11l_l1_(url)
	dd = cc[l1l1l1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ嶑")][l1l1l1_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ嶒")][l1l1l1_l1_ (u"ࠨࡶࡤࡦࡸ࠭嶓")]
	for ii in range(len(dd)):
		item = dd[ii]
		l1l11l11lll1_l1_(item,url,str(ii))
	ee = dd[0][l1l1l1_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嶔")][l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ嶕")][l1l1l1_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ嶖")][l1l1l1_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ嶗")]
	s = 0
	for ii in range(len(ee)):
		item = ee[ii][l1l1l1_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ嶘")][l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ嶙")][0]
		if list(item[l1l1l1_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ嶚")][l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ嶛")].keys())[0]==l1l1l1_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ嶜"): continue
		succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_ = l1l11l1ll11l_l1_(item)
		if not title:
			s += 1
			title = l1l1l1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭嶝")+str(s)
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嶞"),menu_name+title,url,144,l1l1l1_l1_ (u"࠭ࠧ嶟"),str(ii))
	key = re.findall(l1l1l1_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嶠"),html,re.DOTALL)
	url2 = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭嶡")+key[0]
	html,cc,data2 = l1l111lll11l_l1_(url2)
	for jj in range(3,4):
		dd = cc[l1l1l1_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ嶢")][jj][l1l1l1_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ嶣")][l1l1l1_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ嶤")]
		for ii in range(len(dd)):
			item = dd[ii]
			if l1l1l1_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ嶥") in str(item): continue
			l1l11l11lll1_l1_(item)
	return
def ITEMS(url,data=l1l1l1_l1_ (u"࠭ࠧ嶦"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ嶧"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嶨"),l1l1l1_l1_ (u"ࠩࠪ嶩"))
	html,cc,data2 = l1l111lll11l_l1_(url,data)
	l1ll1l1111_l1_,ff = l1l1l1_l1_ (u"ࠪࠫ嶪"),l1l1l1_l1_ (u"ࠫࠬ嶫")
	#if l1l1l1_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠫ嶬") in html.lower(): DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ嶭"),l1l1l1_l1_ (u"ࠧࠨ嶮"),l1l1l1_l1_ (u"ࠨࡱࡺࡲࡪࡸࠠࡦࡺ࡬ࡷࡹ࠭嶯"),l1l1l1_l1_ (u"ࠩ࡬ࡲࠥ࡮ࡴ࡮࡮ࠪ嶰"))
	owner = re.findall(l1l1l1_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嶱"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l1l1_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡓࡼࡴࡥࡳࠤ࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嶲"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l1l1_l1_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ嶳"),html,re.DOTALL)
	if owner:
		l1ll1l1111_l1_ = l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ嶴")+owner[0][0]+l1l1l1_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嶵")
		l111ll_l1_ = owner[0][1]
		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭嶶") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
		#if l1l1l1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭嶷") in url and l1l1l1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭嶸") not in url and l1l1l1_l1_ (u"ࠫ࠴ࡩ࠯ࠨ嶹") not in url and l1l1l1_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ嶺") not in url:
		if l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ嶻") in url: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶼"),menu_name+l1ll1l1111_l1_,l111ll_l1_,144)
	#if cc==l1l1l1_l1_ (u"ࠨࠩ嶽"): l1l11111ll1l_l1_(url,html) ; return
	l1l11111l1ll_l1_ = [l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ嶾"),l1l1l1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ嶿"),l1l1l1_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ巀"),l1l1l1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ巁"),l1l1l1_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ巂"),l1l1l1_l1_ (u"ࠧࡴࡵࡀࠫ巃"),l1l1l1_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ巄"),l1l1l1_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ巅"),l1l1l1_l1_ (u"ࠪࡦࡵࡃࠧ巆"),l1l1l1_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩࡃࠧ巇")]
	l1l1111l1l1l_l1_ = not any(value in url for value in l1l11111l1ll_l1_)
	if l1l1111l1l1l_l1_ and l1ll1l1111_l1_:
		l1l11111l_l1_ = l1l1l1_l1_ (u"ࠬอไษฯฮࠫ巈")
		title2 = l1l1l1_l1_ (u"࠭โ้ษษ้ࠥอไหึ฽๎้࠭巉")
		l1l1111l11ll_l1_ = l1l1l1_l1_ (u"ࠧศๆไ๎ิ๐่่ษอࠫ巊")
		l1l1111l11l1_l1_ = l1l1l1_l1_ (u"ࠨษ็ๆ๋๎วหࠩ巋")
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ巌"),menu_name+l1ll1l1111_l1_,url,9999)
		if l1l1l1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧฮอฬࠤࠪ巍") in html: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巎"),menu_name+l1l11111l_l1_,url,145,l1l1l1_l1_ (u"ࠬ࠭巏"),l1l1l1_l1_ (u"࠭ࠧ巐"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ巑"))
		if l1l1l1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ巒") in html: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巓"),menu_name+title2,url+l1l1l1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ巔"),144)
		if l1l1l1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ巕") in html: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巖"),menu_name+l1l1111l11ll_l1_,url+l1l1l1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ巗"),144)
		if l1l1l1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ巘") in html: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巙"),menu_name+l1l1111l11l1_l1_,url+l1l1l1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ巚"),144)
		if l1l1l1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾࡙ࠧࡥࡢࡴࡦ࡬ࠧ࠭巛") in html: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巜"),menu_name+l1l11111l_l1_,url,145,l1l1l1_l1_ (u"ࠬ࠭川"),l1l1l1_l1_ (u"࠭ࠧ州"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ巟"))
		if l1l1l1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ巠") in html: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巡"),menu_name+title2,url+l1l1l1_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ巢"),144)
		if l1l1l1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ巣") in html: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巤"),menu_name+l1l1111l11ll_l1_,url+l1l1l1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ工"),144)
		if l1l1l1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ左") in html: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巧"),menu_name+l1l1111l11l1_l1_,url+l1l1l1_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ巨"),144)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ巩"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ巪"),l1l1l1_l1_ (u"ࠬ࠭巫"),9999)
	if l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ巬") in url:
		dd = cc[l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ巭")][l1l1l1_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ差")][l1l1l1_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ巯")][l1l1l1_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ巰")][l1l1l1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭己")]
		l1l1111l1ll1_l1_ = 0
		for i in range(len(dd)):
			if l1l1l1_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ已") in list(dd[i].keys()):
				l1l1111lll11_l1_ = dd[i][l1l1l1_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ巳")]
				length = len(str(l1l1111lll11_l1_))
				if length>l1l1111l1ll1_l1_:
					l1l1111l1ll1_l1_ = length
					ff = l1l1111lll11_l1_
		if l1l1111l1ll1_l1_==0: return
	elif l1l1l1_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ巴") in url or l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ巵") in url or l1l1l1_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ巶") in url or l1l1l1_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ巷") in url or l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ巸") in url or url==l1l11l_l1_:
		l1l111l11l11_l1_ = []
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ巹"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ巺"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ巻"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ巼"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ巽"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠲࠷࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ巾"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ巿"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰ࡚ࡥࡹࡩࡨࡏࡧࡻࡸࡗ࡫ࡳࡶ࡮ࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟ࠥ帀"))
		l1l1111ll111_l1_,ff = l1l11111lll1_l1_(cc,l1l1l1_l1_ (u"࠭ࠧ币"),l1l111l11l11_l1_)
	if not ff:
		try:
			dd = cc[l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ市")][l1l1l1_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ布")][l1l1l1_l1_ (u"ࠩࡷࡥࡧࡹࠧ帄")]
			cond1 = l1l1l1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ帅") in url or l1l1l1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ帆") in url or l1l1l1_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ帇") in url
			l1l1111l1111_l1_ = l1l1l1_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭师") in html or l1l1l1_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ帉") in html or l1l1l1_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ帊") in html
			l1l11111llll_l1_ = l1l1l1_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ帋") in html or l1l1l1_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ希") in html or l1l1l1_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ帍") in html
			if cond1 and (l1l1111l1111_l1_ or l1l11111llll_l1_):
				for ii in range(len(dd)):
					if l1l1l1_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ帎") not in list(dd[ii].keys()): continue
					ee = dd[ii][l1l1l1_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ帏")]
					try: gg = ee[l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ帐")][l1l1l1_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ帑")][l1l1l1_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ帒")][l1l1l1_l1_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ帓")][l1l1l1_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ帔")][ii]
					except: gg = ee
					try: l111ll_l1_ = gg[l1l1l1_l1_ (u"ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ帕")][l1l1l1_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ帖")][l1l1l1_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ帗")][l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ帘")]
					except: continue
					if   l1l1l1_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ帙")		in l111ll_l1_	and l1l1l1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ帚")		in url: ee = dd[ii] ; break
					elif l1l1l1_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ帛")	in l111ll_l1_	and l1l1l1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ帜")	in url: ee = dd[ii] ; break
					elif l1l1l1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ帝")	in l111ll_l1_	and l1l1l1_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ帞")		in url: ee = dd[ii] ; break
					else: ee = dd[0]
			elif l1l1l1_l1_ (u"ࠨࡤࡳࡁࠬ帟") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l1l1l1_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ帠")][l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ帡")]
		except: pass
	if not ff: return
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ帢"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ帣"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ帤"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ帥"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ带"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ帧"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ帨"))
	if l1l1l1_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ帩") not in url: l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡻࡢࡎࡧࡱࡹࠬࡣ࡛ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩࡠࠦ帪"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ師"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ帬"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ席"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ帮"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ帯"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ帰"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ帱"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ帲"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡧࡨࠥ帳"))
	l1l1111ll11l_l1_ = l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡶࠩๆ่่่ࠥศศ่ࠤฬ๊สี฼ํ่ࠬ帴"))
	l1l11111l111_l1_ = l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡷࠪ็้ࠦวๅใํำ๏๎็ศฬࠪ帵"))
	l1l11111l1l1_l1_ = l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡸ่๊ࠫࠠศๆๅ๊ํอสࠨ帶"))
	l1l111lllll_l1_ = [l1l1111ll11l_l1_,l1l11111l111_l1_,l1l11111l1l1_l1_,l1l1l1_l1_ (u"ࠫࡆࡲ࡬ࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ帷"),l1l1l1_l1_ (u"ࠬࡇ࡬࡭ࠢࡹ࡭ࡩ࡫࡯ࡴࠩ常"),l1l1l1_l1_ (u"࠭ࡁ࡭࡮ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ帹")]
	l1l11111ll11_l1_,gg = l1l11111lll1_l1_(ff,index,l1l111l11l11_l1_)
	if l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ帺") in str(type(gg)) and any(value in str(gg[0]) for value in l1l111lllll_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1l111l11l11_l1_ = []
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ帻"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ帼"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ帽"))
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ帾"))		#4
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ帿"))		#7
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ幀"))		#6
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ幁"))		#5
		l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࠧ幂"))
		l1l1111ll111_l1_,item = l1l11111lll1_l1_(gg,index2,l1l111l11l11_l1_)
		#if l1l1111ll111_l1_ not in [l1l1l1_l1_ (u"ࠩ࠵ࠫ幃"),l1l1l1_l1_ (u"ࠪ࠸ࠬ幄"),l1l1l1_l1_ (u"ࠫ࠺࠭幅")]: l1l11l11lll1_l1_(item)		# 2,4,7
		#else: l1l11l11lll1_l1_(item,url,str(index2))
		l1l11l11lll1_l1_(item,url,str(index2))
		if l1l1111ll111_l1_==l1l1l1_l1_ (u"ࠬ࠺ࠧ幆"):
			try:
				hh = item[l1l1l1_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭幇")][l1l1l1_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ幈")][l1l1l1_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ幉")][l1l1l1_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ幊")]
				for l1l111llll11_l1_ in range(len(hh)):
					l1l1111ll1ll_l1_ = hh[l1l111llll11_l1_]
					l1l11l11lll1_l1_(l1l1111ll1ll_l1_)
			except: pass
	l1l111l1ll11_l1_ = False
	if l1l1l1_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ幋") not in url and l1l11111ll11_l1_==l1l1l1_l1_ (u"ࠫ࠽࠭幌"): l1l111l1ll11_l1_ = True
	if l1l1l1_l1_ (u"ࠬࡀ࠺࠻ࠩ幍") in data2: l1l11l111ll1_l1_,key,l1l11l111l11_l1_,l1l111llllll_l1_,token,l1l111ll111l_l1_ = data2.split(l1l1l1_l1_ (u"࠭࠺࠻࠼ࠪ幎"))
	else: l1l11l111ll1_l1_,key,l1l11l111l11_l1_,l1l111llllll_l1_,token,l1l111ll111l_l1_ = l1l1l1_l1_ (u"ࠧࠨ幏"),l1l1l1_l1_ (u"ࠨࠩ幐"),l1l1l1_l1_ (u"ࠩࠪ幑"),l1l1l1_l1_ (u"ࠪࠫ幒"),l1l1l1_l1_ (u"ࠫࠬ幓"),l1l1l1_l1_ (u"ࠬ࠭幔")
	url2,l1lllll111l_l1_ = l1l1l1_l1_ (u"࠭ࠧ幕"),l1l1l1_l1_ (u"ࠧࠨ幖")
	if menuItemsLIST:
		l1l1111lll1l_l1_ = str(menuItemsLIST[-1][1])
		if   menu_name+l1l1l1_l1_ (u"ࠨࡅࡋࡒࡑ࠭幗") in l1l1111lll1l_l1_: l1lllll111l_l1_ = l1l1l1_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ幘")
		elif menu_name+l1l1l1_l1_ (u"࡙ࠪࡘࡋࡒࠨ幙") in l1l1111lll1l_l1_: l1lllll111l_l1_ = l1l1l1_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭幚")
		elif menu_name+l1l1l1_l1_ (u"ࠬࡒࡉࡔࡖࠪ幛") in l1l1111lll1l_l1_: l1lllll111l_l1_ = l1l1l1_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ幜")
	if l1l1l1_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ幝") in html and l1l1l1_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ幞") not in url and not l1l111l1ll11_l1_ and l1l1l1_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ幟") not in url:	# and (index!=l1l1l1_l1_ (u"ࠪࠫ幠") or l1l1l1_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ幡") in url or l1l1l1_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ幢") in url or l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭幣") in url or l1l1l1_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭幤") in url):
		url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ幥")+l1l11l111l11_l1_
	elif l1l1l1_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ幦") in html and l1l1l1_l1_ (u"ࠪࡦࡵࡃࠧ幧") not in url and l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ幨") in url or l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ幩") in url:
		url2 = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ幪")+key
	elif l1l1l1_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ幫") in html and l1l1l1_l1_ (u"ࠨࡤࡳࡁࠬ幬") not in url:
		url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭幭")+key
	if url2: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ幮"),menu_name+l1l1l1_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ幯"),url2,144,l1lllll111l_l1_,l1l1l1_l1_ (u"ࠬ࠭幰"),data2)
	return
def l1l11111lll1_l1_(l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_,l1l111l1lll1_l1_):
	cc = l1l1l11ll1l_l1_
	ff,index = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	gg,index2 = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	item,render = l1l1l11ll1l_l1_,l1l1l1ll1l1_l1_
	count = len(l1l111l1lll1_l1_)
	for ii in range(count):
		try:
			out = eval(l1l111l1lll1_l1_[ii])
			#if isinstance(out,dict): out = l1l1l1_l1_ (u"࠭ࠧ幱")
			return str(ii+1),out
		except: pass
	return l1l1l1_l1_ (u"ࠧࠨ干"),l1l1l1_l1_ (u"ࠨࠩ平")
def l1l11l1ll11l_l1_(item):
	try: l1l11l1l1l11_l1_ = list(item.keys())[0]
	except: return False,l1l1l1_l1_ (u"ࠩࠪ年"),l1l1l1_l1_ (u"ࠪࠫ幵"),l1l1l1_l1_ (u"ࠫࠬ并"),l1l1l1_l1_ (u"ࠬ࠭幷"),l1l1l1_l1_ (u"࠭ࠧ幸"),l1l1l1_l1_ (u"ࠧࠨ幹"),l1l1l1_l1_ (u"ࠨࠩ幺")
	succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_ = False,l1l1l1_l1_ (u"ࠩࠪ幻"),l1l1l1_l1_ (u"ࠪࠫ幼"),l1l1l1_l1_ (u"ࠫࠬ幽"),l1l1l1_l1_ (u"ࠬ࠭幾"),l1l1l1_l1_ (u"࠭ࠧ广"),l1l1l1_l1_ (u"ࠧࠨ庀"),l1l1l1_l1_ (u"ࠨࠩ庁")
	#WRITE_THIS(l1l1l1_l1_ (u"ࠩࠪ庂"),str(item))
	render = item[l1l11l1l1l11_l1_]
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ広"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ庄"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ庅"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ庆"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ庇"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ庈"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ庉"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ床"))
	l1l1111ll111_l1_,title = l1l11111lll1_l1_(item,render,l1l111l11l11_l1_)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ庋"),l1l1l1_l1_ (u"ࠬ࠭庌"),l1l1l1_l1_ (u"࠭ࠧ庍"),title)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ庎"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ序"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ庐"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ庑")) # required for l1l11llll1l_l1_ l1l111l1ll11_l1_
	l1l1111ll111_l1_,l111ll_l1_ = l1l11111lll1_l1_(item,render,l1l111l11l11_l1_)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ庒"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ库"))
	l1l1111ll111_l1_,img = l1l11111lll1_l1_(item,render,l1l111l11l11_l1_)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ应"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ底"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ庖"))
	l1l1111ll111_l1_,count = l1l11111lll1_l1_(item,render,l1l111l11l11_l1_)
	l1l111l11l11_l1_ = []
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ店"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ庘"))
	l1l111l11l11_l1_.append(l1l1l1_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ庙"))
	l1l1111ll111_l1_,duration = l1l11111lll1_l1_(item,render,l1l111l11l11_l1_)
	if l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࠪ庚") in duration: duration,l11l1llllll_l1_ = l1l1l1_l1_ (u"࠭ࠧ庛"),l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ府")
	if l1l1l1_l1_ (u"ࠨ็หหูืࠧ庝") in duration: duration,l11l1llllll_l1_ = l1l1l1_l1_ (u"ࠩࠪ庞"),l1l1l1_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ废")
	if l1l1l1_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ庠") in list(render.keys()):
		l1l11l11llll_l1_ = str(render[l1l1l1_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ庡")])
		if l1l1l1_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭庢") in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠧࠥ࠼ࠪ庣")
		if l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡐ࡙ࠪ庤") in l1l11l11llll_l1_: l11l1llllll_l1_ = l1l1l1_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ庥")
		if l1l1l1_l1_ (u"ࠪࡆࡺࡿࠧ度") in l1l11l11llll_l1_ or l1l1l1_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ座") in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠬࠪࠤ࠻ࠩ庨")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡻࠧๆสสุึ࠭庩")) in l1l11l11llll_l1_: l11l1llllll_l1_ = l1l1l1_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ庪")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡶࠩืีฬวࠧ庫")) in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠩࠧࠨ࠿࠭庬")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡸࠫฬูสวฮสีࠬ庭")) in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"ࠫࠩࠪ࠺ࠨ庮")
		if l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ庯")) in l1l11l11llll_l1_: l1l111lll1l1_l1_ = l1l1l1_l1_ (u"࠭ࠤ࠻ࠩ庰")
	l111ll_l1_ = escapeUNICODE(l111ll_l1_)
	if l111ll_l1_ and l1l1l1_l1_ (u"ࠧࡩࡶࡷࡴࠬ庱") not in l111ll_l1_: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
	img = img.split(l1l1l1_l1_ (u"ࠨࡁࠪ庲"))[0]
	if  img and l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ庳") not in img: img = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ庴")+img
	title = escapeUNICODE(title)
	if l1l111lll1l1_l1_: title = l1l111lll1l1_l1_+l1l1l1_l1_ (u"ࠫࠥࠦࠧ庵")+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l1l1_l1_ (u"ࠬ࠲ࠧ庶"),l1l1l1_l1_ (u"࠭ࠧ康"))
	count = count.replace(l1l1l1_l1_ (u"ࠧ࠭ࠩ庸"),l1l1l1_l1_ (u"ࠨࠩ庹"))
	count = re.findall(l1l1l1_l1_ (u"ࠩ࡟ࡨ࠰࠭庺"),count)
	if count: count = count[0]
	else: count = l1l1l1_l1_ (u"ࠪࠫ庻")
	return True,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_
def l1l11l11lll1_l1_(item,url=l1l1l1_l1_ (u"ࠫࠬ庼"),index=l1l1l1_l1_ (u"ࠬ࠭庽")):
	succeeded,title,l111ll_l1_,img,count,duration,l11l1llllll_l1_,l1l111lll1l1_l1_ = l1l11l1ll11l_l1_(item)
	#if l1l1l1_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ庾") in url and index==l1l1l1_l1_ (u"ࠧ࠱ࠩ庿"):
	#	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廀"),menu_name+title,url,144)
	#	return
	if not succeeded: return
	elif l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廁") in str(item): return	# l1l11l111l11_l1_ not items
	elif l1l1l1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ廂") in str(item): return			# l1l11l11ll11_l1_ not items
	elif not l111ll_l1_ and l1l1l1_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ廃") in url: return			# l1llllll1l_l1_ l1l1111l111l_l1_ list not items
	elif title and not l111ll_l1_ and (l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ廄") in url or l1l1l1_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廅") in str(item) or url==l1l11l_l1_):
		title = l1l1l1_l1_ (u"ࠧ࠾࠿ࡀࠤࠬ廆")+title+l1l1l1_l1_ (u"ࠨࠢࡀࡁࡂ࠭廇")
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ廈"),menu_name+title,l1l1l1_l1_ (u"ࠪࠫ廉"),9999)
	elif title and l1l1l1_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廊") in str(item):
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ廋"),menu_name+title,l1l1l1_l1_ (u"࠭ࠧ廌"),9999)
	elif l1l1l1_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ廍") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廎"),menu_name+title,l111ll_l1_,144,img,index)
	elif not title: return
	elif l11l1llllll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ廏"),menu_name+l11l1llllll_l1_+title,l111ll_l1_,143,img)
	#elif l1l1l1_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ廐") in l111ll_l1_ and l1l1l1_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ廑") not in l111ll_l1_ and l1l1l1_l1_ (u"ࠬࡺ࠽࠱ࠩ廒") not in l111ll_l1_:
	#	l1l111lll1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ廓"),l111ll_l1_,re.DOTALL)
	#	l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ廔")+l1l111lll1ll_l1_[0]
	#	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廕"),menu_name+l1l1l1_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ廖")+count+l1l1l1_l1_ (u"ࠪ࠾ࠥࠦࠧ廗")+title,l111ll_l1_,144,img)
	elif l1l1l1_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭廘") in l111ll_l1_ or l1l1l1_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ廙") in l111ll_l1_:
		if l1l1l1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭廚") in l111ll_l1_ and l1l1l1_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ廛") not in l111ll_l1_:
			l1l111lll1ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ廜"),1)[1]
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ廝")+l1l111lll1ll_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廞"),menu_name+l1l1l1_l1_ (u"ࠫࡑࡏࡓࡕࠩ廟")+count+l1l1l1_l1_ (u"ࠬࡀࠠࠡࠩ廠")+title,l111ll_l1_,144,img)
		else:
			l111ll_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭廡"),1)[0]
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭廢"),menu_name+title,l111ll_l1_,143,img,duration)
	else:
		type = l1l1l1_l1_ (u"ࠨࠩ廣")
		if not l111ll_l1_: l111ll_l1_ = url
		#if l1l1l1_l1_ (u"ࠩࡶࡷࡂ࠭廤") in l111ll_l1_: l111ll_l1_ = url
		#elif l1l1l1_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭廥") in l111ll_l1_: l111ll_l1_ = url		# not needed it will stop l1l1111l1l11_l1_ l1l11llll1l_l1_ l1l111l1ll11_l1_
		elif not any(value in l111ll_l1_ for value in [l1l1l1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ廦"),l1l1l1_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ廧"),l1l1l1_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ廨"),l1l1l1_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ廩"),l1l1l1_l1_ (u"ࠨࡵࡶࡁࠬ廪"),l1l1l1_l1_ (u"ࠩࡥࡴࡂ࠭廫")]):
			if l1l1l1_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭廬")	in l111ll_l1_ or l1l1l1_l1_ (u"ࠫ࠴ࡩ࠯ࠨ廭") in l111ll_l1_: type = l1l1l1_l1_ (u"ࠬࡉࡈࡏࡎࠪ廮")+count+l1l1l1_l1_ (u"࠭࠺ࠡࠢࠪ廯")
			if l1l1l1_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ廰") in l111ll_l1_: type = l1l1l1_l1_ (u"ࠨࡗࡖࡉࡗ࠭廱")+count+l1l1l1_l1_ (u"ࠩ࠽ࠤࠥ࠭廲")
			index,l1l11l1ll111_l1_ = l1l1l1_l1_ (u"ࠪࠫ廳"),l1l1l1_l1_ (u"ࠫࠬ廴")
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廵"),menu_name+type+title,l111ll_l1_,144,img,index)
	return
def l1l111lll11l_l1_(url,data=l1l1l1_l1_ (u"࠭ࠧ延"),request=l1l1l1_l1_ (u"ࠧࠨ廷")):
	global settings
	if not data: data = settings.getSetting(l1l1l1_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ廸"))
	#if l1l1l1_l1_ (u"ࠩࡢࡣࠬ廹") in l1l11l1ll111_l1_: l1l11l1ll111_l1_ = l1l1l1_l1_ (u"ࠪࠫ建")
	#if l1l1l1_l1_ (u"ࠫࡸࡹ࠽ࠨ廻") in url: url = url.split(l1l1l1_l1_ (u"ࠬࡹࡳ࠾ࠩ廼"))[0]
	if request==l1l1l1_l1_ (u"࠭ࠧ廽"): request = l1l1l1_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ廾")
	useragent = l1l1l11ll_l1_()
	headers2 = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ廿"):useragent,l1l1l1_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ开"):l1l1l1_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ弁")}
	#headers2 = headers.copy()
	if l1l1l1_l1_ (u"ࠫ࠿ࡀ࠺ࠨ异") in data: l1l11l111ll1_l1_,key,l1l11l111l11_l1_,l1l111llllll_l1_,token,l1l111ll111l_l1_ = data.split(l1l1l1_l1_ (u"ࠬࡀ࠺࠻ࠩ弃"))
	else: l1l11l111ll1_l1_,key,l1l11l111l11_l1_,l1l111llllll_l1_,token,l1l111ll111l_l1_ = l1l1l1_l1_ (u"࠭ࠧ弄"),l1l1l1_l1_ (u"ࠧࠨ弅"),l1l1l1_l1_ (u"ࠨࠩ弆"),l1l1l1_l1_ (u"ࠩࠪ弇"),l1l1l1_l1_ (u"ࠪࠫ弈"),l1l1l1_l1_ (u"ࠫࠬ弉")
	if l1l1l1_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ弊") in url:
		data2 = {}
		data2[l1l1l1_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ弋")] = {l1l1l1_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ弌"):{l1l1l1_l1_ (u"ࠣࡪ࡯ࠦ弍"):l1l1l1_l1_ (u"ࠤࡤࡶࠧ弎"),l1l1l1_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ式"):l1l1l1_l1_ (u"ࠦ࡜ࡋࡂࠣ弐"),l1l1l1_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ弑"):l1l111llllll_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ弒"),url,data2,headers2,True,True,l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ弓"))
	elif l1l1l1_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭弔") in url and l1l11l111ll1_l1_:
		data2 = {l1l1l1_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ引"):token}
		data2[l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ弖")] = {l1l1l1_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ弗"):{l1l1l1_l1_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ弘"):l1l11l111ll1_l1_,l1l1l1_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ弙"):l1l1l1_l1_ (u"ࠢࡘࡇࡅࠦ弚"),l1l1l1_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ弛"):l1l111llllll_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ弜"),url,data2,headers2,True,True,l1l1l1_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠷ࡴࡤࠨ弝"))
	elif l1l1l1_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ弞") in url and l1l111ll111l_l1_:
		headers2.update({l1l1l1_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭弟"):l1l1l1_l1_ (u"࠭࠱ࠨ张"),l1l1l1_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ弡"):l1l111llllll_l1_})
		headers2.update({l1l1l1_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ弢"):l1l1l1_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ弣")+l1l111ll111l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ弤"),url,l1l1l1_l1_ (u"ࠫࠬ弥"),headers2,l1l1l1_l1_ (u"ࠬ࠭弦"),l1l1l1_l1_ (u"࠭ࠧ弧"),l1l1l1_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ弨"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ弩"),url,l1l1l1_l1_ (u"ࠩࠪ弪"),headers2,l1l1l1_l1_ (u"ࠪࠫ弫"),l1l1l1_l1_ (u"ࠫࠬ弬"),l1l1l1_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ弭"))
	html = response.content
	tmp = re.findall(l1l1l1_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭弮"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l1l1_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭弯"),html,re.DOTALL|re.I)
	if tmp: l1l111llllll_l1_ = tmp[0]
	tmp = re.findall(l1l1l1_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ弰"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l1l1_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ弱"),html,re.DOTALL|re.I)
	if tmp: l1l11l111ll1_l1_ = tmp[0]
	tmp = re.findall(l1l1l1_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ弲"),html,re.DOTALL|re.I)
	if tmp: l1l11l111l11_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l1l1_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ弳") in list(cookies.keys()): l1l111ll111l_l1_ = cookies[l1l1l1_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ弴")]
	data = l1l11l111ll1_l1_+l1l1l1_l1_ (u"࠭࠺࠻࠼ࠪ張")+key+l1l1l1_l1_ (u"ࠧ࠻࠼࠽ࠫ弶")+l1l11l111l11_l1_+l1l1l1_l1_ (u"ࠨ࠼࠽࠾ࠬ強")+l1l111llllll_l1_+l1l1l1_l1_ (u"ࠩ࠽࠾࠿࠭弸")+token+l1l1l1_l1_ (u"ࠪ࠾࠿ࡀࠧ弹")+l1l111ll111l_l1_
	if request==l1l1l1_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ强") and l1l1l1_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ弻") in html:
		l1l111lll1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ弼"),html,re.DOTALL)
		if not l1l111lll1_l1_: l1l111lll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ弽"),html,re.DOTALL)
		l1l111l11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠨࡵࡷࡶࠬ弾"),l1l111lll1_l1_[0])
	elif request==l1l1l1_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ弿") and l1l1l1_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ彀") in html:
		l1l111lll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ彁"),html,re.DOTALL)
		l1l111l11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠬࡹࡴࡳࠩ彂"),l1l111lll1_l1_[0])
	elif l1l1l1_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ彃") not in html: l1l111l11l1l_l1_ = EVAL(l1l1l1_l1_ (u"ࠧࡴࡶࡵࠫ彄"),html)
	else: l1l111l11l1l_l1_ = l1l1l1_l1_ (u"ࠨࠩ彅")
	#open(l1l1l1_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯࡬ࡶࡳࡳ࠭彆"),l1l1l1_l1_ (u"ࠪࡻࠬ彇")).write(str(l1l111l11l1l_l1_))
	#open(l1l1l1_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ彈"),l1l1l1_l1_ (u"ࠬࡽࠧ彉")).write(html)
	settings.setSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ彊"),data)
	return html,l1l111l11l1l_l1_,data
def l1l11l1l1l1l_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠧࠡࠩ彋"),l1l1l1_l1_ (u"ࠨ࠭ࠪ彌"))
	url2 = url+l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ彍")+search
	ITEMS(url2)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠪࠤࠬ彎"),l1l1l1_l1_ (u"ࠫ࠰࠭彏"))
	url2 = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ彐")+search
	if not l111l_l1_:
		if l1l1l1_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ彑") in options: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ归")
		elif l1l1l1_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ当") in options: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ彔")
		elif l1l1l1_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ录") in options: l1l111ll11ll_l1_ = l1l1l1_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ彖")
		url3 = url2+l1l111ll11ll_l1_
	else:
		l1l111l1ll1l_l1_,l1l111l1111l_l1_,title2 = [],[],l1l1l1_l1_ (u"ࠬ࠭彗")
		l1l111l111ll_l1_ = [l1l1l1_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ彘"),l1l1l1_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭彙"),l1l1l1_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ彚"),l1l1l1_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ彛"),l1l1l1_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ彜")]
		l1l11l11l1ll_l1_ = [l1l1l1_l1_ (u"ࠫࠬ彝"),l1l1l1_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ彞"),l1l1l1_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ彟"),l1l1l1_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭彠"),l1l1l1_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ彡")]
		l1l11l1l111l_l1_ = DIALOG_SELECT(l1l1l1_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ形"),l1l111l111ll_l1_)
		if l1l11l1l111l_l1_ == -1: return
		l1l11l1l1111_l1_ = l1l11l11l1ll_l1_[l1l11l1l111l_l1_]
		html,c,data = l1l111lll11l_l1_(url2+l1l11l1l1111_l1_)
		if c:
			d = c[l1l1l1_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ彣")][l1l1l1_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彤")][l1l1l1_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ彥")][l1l1l1_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ彦")][l1l1l1_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ彧")][l1l1l1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ彨")][l1l1l1_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ彩")]
			for l1l111l11111_l1_ in range(len(d)):
				group = d[l1l111l11111_l1_][l1l1l1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彪")][l1l1l1_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ彫")]
				for l1l11l1l1ll1_l1_ in range(len(group)):
					render = group[l1l11l1l1ll1_l1_][l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ彬")]
					if l1l1l1_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ彭") in list(render.keys()):
						l111ll_l1_ = render[l1l1l1_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ彮")][l1l1l1_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ彯")][l1l1l1_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ彰")][l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ影")]
						l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ彲"),l1l1l1_l1_ (u"ࠬࠬࠧ彳"))
						title = render[l1l1l1_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ彴")]
						title = title.replace(l1l1l1_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ彵"),l1l1l1_l1_ (u"ࠨࠩ彶"))
						if l1l1l1_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ彷") in title: continue
						if l1l1l1_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ彸") in title:
							title = l1l1l1_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ役")+title
							title2 = title
							l11111ll1_l1_ = l111ll_l1_
						if l1l1l1_l1_ (u"ࠬะัห์หࠤาูศࠨ彺") in title: continue
						title = title.replace(l1l1l1_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ彻"),l1l1l1_l1_ (u"ࠧࠨ彼"))
						if l1l1l1_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ彽") in title: continue
						if l1l1l1_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ彾") in title:
							title = l1l1l1_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ彿")+title
							title2 = title
							l11111ll1_l1_ = l111ll_l1_
						if l1l1l1_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ往") in title: continue
						l1l111l1ll1l_l1_.append(escapeUNICODE(title))
						l1l111l1111l_l1_.append(l111ll_l1_)
		if not title2: l1l11l11l111_l1_ = l1l1l1_l1_ (u"ࠬ࠭征")
		else:
			l1l111l1ll1l_l1_ = [l1l1l1_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ徂"),title2]+l1l111l1ll1l_l1_
			l1l111l1111l_l1_ = [l1l1l1_l1_ (u"ࠧࠨ徃"),l11111ll1_l1_]+l1l111l1111l_l1_
			l1l11l1l11ll_l1_ = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭径"),l1l111l1ll1l_l1_)
			if l1l11l1l11ll_l1_ == -1: return
			l1l11l11l111_l1_ = l1l111l1111l_l1_[l1l11l1l11ll_l1_]
		if l1l11l11l111_l1_: url3 = l1l11l_l1_+l1l11l11l111_l1_
		elif l1l11l1l1111_l1_: url3 = url2+l1l11l1l1111_l1_
		else: url3 = url2
		l1l1l1_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡫࡯ࡸࡪࡸ࠭ࡥࡴࡲࡴࡩࡵࡷ࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡓࡧࡰࡳࡻ࡫ࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠩ࠯ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬ࡯ࡳࡶࠣࡦࡾ࠭ࠬࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠦࠧࠨ待")
	ITEMS(url3)
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᛇ")
menu_name = l1l1l1_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧᛈ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᛉ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l11l11_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l11l1ll_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧᛊ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᛋ"),l1l1l1_l1_ (u"ࠬ࠭ᛌ"),l1l1l1_l1_ (u"࠭ࠧᛍ"),l1l1l1_l1_ (u"ࠧࠨᛎ"),l1l1l1_l1_ (u"ࠨࠩᛏ"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᛐ"))
	html = response.content
	l11l1l_l1_ = SERVER(l1l11l_l1_,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧᛑ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᛒ"),menu_name+l1l1l1_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᛓ"),l1l1l1_l1_ (u"࠭ࠧᛔ"),559,l1l1l1_l1_ (u"ࠧࠨᛕ"),l1l1l1_l1_ (u"ࠨࠩᛖ"),l1l1l1_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᛗ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᛘ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᛙ"),l1l1l1_l1_ (u"ࠬ࠭ᛚ"),9999)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛛ"),menu_name+l1l1l1_l1_ (u"ࠧศะอี๋อࠠๅๅࠪᛜ"),l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᛝ"),551,l1l1l1_l1_ (u"ࠩࠪᛞ"),l1l1l1_l1_ (u"ࠪࠫᛟ"),l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᛠ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᛡ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᛢ"),block,re.DOTALL)
	for l111l1111_l1_,title in items:
		l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭ᛣ")+l111l1111_l1_+l1l1l1_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩᛤ")
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᛥ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᛦ")+menu_name+title,l111ll_l1_,551)
	#addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᛧ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᛨ"),l1l1l1_l1_ (u"࠭ࠧᛩ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨᛪ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᛫"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l111ll_l1_==l1l1l1_l1_ (u"ࠩࠦࠫ᛬"): continue
		if title in l1l1ll_l1_: continue
		if l1l1l1_l1_ (u"ุ้๊ࠪำๅࠢࠪ᛭") in title: continue
		if l1l1l1_l1_ (u"ࠫศำฯฬࠩᛮ") in title: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᛯ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᛰ")+menu_name+title,l111ll_l1_,551)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᛱ"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᛲ"),l1l1l1_l1_ (u"ࠩࠪᛳ"),9999)
	for l111ll_l1_,title in items:
		if l111ll_l1_==l1l1l1_l1_ (u"ࠪࠧࠬᛴ"): continue
		if title in l1l1ll_l1_: continue
		if l1l1l1_l1_ (u"ู๊ࠫไิๆࠣࠫᛵ") in title: continue
		if l1l1l1_l1_ (u"ࠬษอะอࠪᛶ") not in title: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛷ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᛸ")+menu_name+title,l111ll_l1_,551)
	return
def l11l11_l1_(url,l111l1111_l1_=l1l1l1_l1_ (u"ࠨࠩ᛹")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ᛺"),l1l1l1_l1_ (u"ࠪࠫ᛻"),url)
	items = []
	# l1lllll11l_l1_ l1lllll1l1_l1_
	if l1l1l1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ᛼") in url or l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭᛽") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1l1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ᛾"):l1l1l1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ᛿")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᜀ"),url2,data2,headers2,l1l1l1_l1_ (u"ࠩࠪᜁ"),l1l1l1_l1_ (u"ࠪࠫᜂ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᜃ"))
		html = response.content
		l1ll1l1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᜄ"),url,l1l1l1_l1_ (u"࠭ࠧᜅ"),l1l1l1_l1_ (u"ࠧࠨᜆ"),l1l1l1_l1_ (u"ࠨࠩᜇ"),l1l1l1_l1_ (u"ࠩࠪᜈ"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩᜉ"))
		html = response.content
		# l111l1111_l1_ items
		if l111l1111_l1_==l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᜊ"):
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬᜋ"),html,re.DOTALL)
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᜌ"),block,re.DOTALL)
			#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨᜍ"),l1l1l1_l1_ (u"ࠨࠩᜎ"),l1l1l1_l1_ (u"ࠩࠪᜏ"))
		# l1lllllll1_l1_ l11l11ll_l1_
		elif l1l1l1_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠪᜐ") in html:
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ᜑ"),html,re.DOTALL)
		else:
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡂࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪᜒ"),html,re.DOTALL)
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	if not items:
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᜓ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ᜔࠭ࠧ࠭"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ࠨ็ืห์ีษࠨ᜕"),l1l1l1_l1_ (u"ࠩไ๎้๋ࠧ᜖"),l1l1l1_l1_ (u"ࠪห฿์๊สࠩ᜗"),l1l1l1_l1_ (u"่๊๊ࠫษࠩ᜘"),l1l1l1_l1_ (u"ࠬอูๅษ้ࠫ᜙"),l1l1l1_l1_ (u"࠭็ะษไࠫ᜚"),l1l1l1_l1_ (u"ࠧๆสสีฬฯࠧ᜛"),l1l1l1_l1_ (u"ࠨ฻ิฺࠬ᜜"),l1l1l1_l1_ (u"่๋ࠩึาว็ࠩ᜝"),l1l1l1_l1_ (u"ࠪห้ฮ่ๆࠩ᜞")]
	for l111ll_l1_,title,img in items:
		l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠫ࠴࠭ᜟ"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨᜠ"),title,re.DOTALL)
		if l1l1l1_l1_ (u"࠭ำๅษึ่ࠬᜡ") not in url and any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᜢ"),menu_name+title,l111ll_l1_,552,img)
		elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠨษ็ั้่ษࠨᜣ") in title:
			title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᜤ") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᜥ"),menu_name+title,l111ll_l1_,553,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭ᜦ") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᜧ"),menu_name+title,l111ll_l1_,551,img)
		else: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜨ"),menu_name+title,l111ll_l1_,553,img)
	if l111l1111_l1_==l1l1l1_l1_ (u"ࠧࠨᜩ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࠬᜪ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫᜫ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠥࠦᜬ"): continue
				#title = unescapeHTML(title)
				if title!=l1l1l1_l1_ (u"ࠫࠬᜭ"): addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᜮ"),menu_name+l1l1l1_l1_ (u"࠭ีโฯฬࠤࠬᜯ")+title,l111ll_l1_,551)
	if l1l1l1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧᜰ") in url or l1l1l1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩᜱ") in url:
		if l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩᜲ") in url:
			url = url.replace(l1l1l1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪᜳ"),l1l1l1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩ᜴ࠬ"))+l1l1l1_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃ࠲࠱ࠩ᜵")
		elif l1l1l1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧ᜶") in url:
			url,offset = url.split(l1l1l1_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩ᜷"))
			offset = int(offset)+20
			url = url+l1l1l1_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪ᜸")+str(offset)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᜹"),menu_name+l1l1l1_l1_ (u"๋๋ࠪอใࠡษ็้ื๐ฯࠨ᜺"),url,551)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ᜻"),url,l1l1l1_l1_ (u"ࠬ࠭᜼"),l1l1l1_l1_ (u"࠭ࠧ᜽"),l1l1l1_l1_ (u"ࠧࠨ᜾"),l1l1l1_l1_ (u"ࠨࠩ᜿"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᝀ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࡃࡻࡖࡩࡷ࡯ࡥࡴࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫᝁ"),html,re.DOTALL)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡲࡩࡴࡶ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨᝂ"),html,re.DOTALL)
	# l111l1_l1_
	if l1ll11l_l1_ and l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧᝃ") not in url:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᝄ"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᝅ"),menu_name+title,l111ll_l1_,553,img)
	# l1ll1_l1_
	elif l1ll111_l1_:
		img = re.findall(l1l1l1_l1_ (u"ࠨࠤ࡬ࡱࡦ࡭ࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᝆ"),html,re.DOTALL)
		img = img[0]
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᝇ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#title = title.replace(l1l1l1_l1_ (u"ࠪࡠࡳ࠭ᝈ"),l1l1l1_l1_ (u"ࠫࠬᝉ")).strip(l1l1l1_l1_ (u"ࠬࠦࠧᝊ"))
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᝋ"),menu_name+title,l111ll_l1_,552,img)
	return
def PLAY(url):
	url2 = url.replace(l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᝌ"),l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰ࠩᝍ"))
	url2 = url2.replace(l1l1l1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ᝎ"),l1l1l1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭ᝏ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨᝐ"),url2,l1l1l1_l1_ (u"ࠬ࠭ᝑ"),l1l1l1_l1_ (u"࠭ࠧᝒ"),l1l1l1_l1_ (u"ࠧࠨᝓ"),l1l1l1_l1_ (u"ࠨࠩ᝔"),l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭᝕"))
	html = response.content
	l11l1l_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠪࡹࡷࡲࠧ᝖"))
	l11l1_l1_ = []
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᝗"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᝘"),html,re.DOTALL)
		l1l11l1l_l1_ = l1l11l1l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ᝙"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ᝚"),l1l1l1_l1_ (u"ࠨࠩ᝛")).strip(l1l1l1_l1_ (u"ࠩࠣࠫ᝜"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭᝝")+server+l1l1l1_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭᝞")+l1l11l1l_l1_+l1l1l1_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭᝟")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᝠ")+title+l1l1l1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᝡ")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡧࡳࡼࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᝢ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᝣ"),block,re.DOTALL)
		for l111ll_l1_,name in items:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᝤ")+name+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨᝥ")
			if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᝦ") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᝧ")+l111ll_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬᝨ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᝩ"),url)
	return
l1l1l1_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡓࡐࡆ࡟࡟ࡐࡎࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࡩࡧࡴࡢࠢࡀࠤࢀ࠭ࡖࡪࡧࡺࠫ࠿࠷ࡽࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭࠺ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡕࡕࡓࡕࠩ࠯ࡹࡷࡲࠬࡥࡣࡷࡥ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟ࠍࠍࠨࠦࡷࡢࡶࡦ࡬ࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡼࡧࡴࡤࡪࡄࡶࡪࡧࡍࡢࡵࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡲࡩ࡯࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡩࡵ࡮ࡸ࡮ࡲࡥࡩ࠳ࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥ࠭ࡳࡸࡥࡱ࡯ࡴࡺ࠮࡯࡭ࡳࡱࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ࠭ࠪࡣࡤࡥ࡟ࠨ࠭ࡴࡹࡦࡲࡩࡵࡻࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠍࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯࠽࠾࠲࠽ࠤࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬอไาษห฻๊๊ࠥิࠢไ๎์ࠦแ๋ัํ์ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࠉࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡔࡑࡇ࡙ࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࠬࡼࡩࡥࡧࡲࠫ࠱ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢᝪ")
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠪࠫᝫ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠫࠬᝬ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠬࠦࠧ᝭"),l1l1l1_l1_ (u"࠭࠭ࠨᝮ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩᝯ")+search+l1l1l1_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧᝰ")
	l11l11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬⵜ")
menu_name = l1l1l1_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭ⵝ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1ll11ll1l_l1_ = WEBSITES[script_name][1]
l1ll1lll1l1_l1_ = WEBSITES[script_name][2]
l1ll1llll11_l1_ = WEBSITES[script_name][3]
#l1lll1111l1_l1_  = WEBSITES[script_name][4]
#l1lll1111l1_l1_  = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==20: results = l1ll1llll1l_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l11l11_l1_(url,page)
	elif mode==23: results = l11l1ll_l1_(url,page)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1ll1ll11l1_l1_(url)
	elif mode==27: results = l1ll11lll_l1_(url)
	elif mode==28: results = l1lll111111_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1ll1llll1l_l1_():
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵞ"),menu_name+l1l1l1_l1_ (u"ࠩ฼ีอ๐ࠧⵟ"),l1l11l_l1_,21,l1l1l1_l1_ (u"ࠪࠫⵠ"),l1l1l1_l1_ (u"ࠫ࠶࠶࠱ࠨⵡ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵢ"),menu_name+l1l1l1_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧⵣ"),l1ll11ll1l_l1_,21,l1l1l1_l1_ (u"ࠧࠨⵤ"),l1l1l1_l1_ (u"ࠨ࠳࠳࠵ࠬⵥ"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵦ"),menu_name+l1l1l1_l1_ (u"ࠪๅฬืำ๊ࠩⵧ"),l1ll1lll1l1_l1_,21,l1l1l1_l1_ (u"ࠫࠬ⵨"),l1l1l1_l1_ (u"ࠬ࠷࠰࠲ࠩ⵩"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵪"),menu_name+l1l1l1_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ⵫"),l1ll1llll11_l1_,21,l1l1l1_l1_ (u"ࠨࠩ⵬"),l1l1l1_l1_ (u"ࠩ࠴࠴࠶࠭⵭"))
	return
def l1lll111111_l1_():
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⵮"),menu_name+l1l1l1_l1_ (u"ࠫ฾ืศ๋ࠩⵯ"),l1l11l_l1_,27)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩࡷࡧࠪ⵰"),menu_name+l1l1l1_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧ⵱"),l1ll11ll1l_l1_,27)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⵲"),menu_name+l1l1l1_l1_ (u"ࠨใสีุ๏ࠧ⵳"),l1ll1lll1l1_l1_,27)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⵴"),menu_name+l1l1l1_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ⵵"),l1ll1llll11_l1_,27)
	return
def MENU(l1lll11111l_l1_):
	script_name = l1lll11111l_l1_
	if l1lll11111l_l1_==l1l1l1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ⵶"): l1lll11111l_l1_ = l1l11l_l1_
	elif l1lll11111l_l1_==l1l1l1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⵷"): l1lll11111l_l1_ = l1ll11ll1l_l1_
	else: script_name = l1l1l1_l1_ (u"࠭ࠧ⵸")
	lang = l1lll1111ll_l1_(l1lll11111l_l1_)
	if lang==l1l1l1_l1_ (u"ࠧࡢࡴࠪ⵹") or script_name==l1l1l1_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ⵺"):
		l1ll1ll11ll_l1_ = l1l1l1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⵻")
		name1 = l1l1l1_l1_ (u"ุ้๊ࠪำๅษอࠤ࠲ࠦอศๆํอࠬ⵼")
		name2 = l1l1l1_l1_ (u"ู๊ࠫไิๆสฮࠥ࠳ࠠฤฯาฯࠬ⵽")
		l1ll1ll1l11_l1_ = l1l1l1_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡลหะิ๐ࠧ⵾")
		l1ll1ll1ll1_l1_ = l1l1l1_l1_ (u"࠭ศฬࠢะ๎ࠥศ๊ࠡใํ⵿่๊࠭")
		l1ll1ll1l1l_l1_ = l1l1l1_l1_ (u"ࠧฤใ็ห๊࠭ⶀ")
		l1ll1lll111_l1_ = l1l1l1_l1_ (u"ࠨ็๋ื๏่้ࠨⶁ")
		l1ll1ll1lll_l1_ = l1l1l1_l1_ (u"ࠩหีฬ๋ฬࠨⶂ")
	elif lang==l1l1l1_l1_ (u"ࠪࡩࡳ࠭ⶃ") or script_name==l1l1l1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫⶄ"):
		l1ll1ll11ll_l1_ = l1l1l1_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡯࡮ࠡࡵ࡬ࡸࡪ࠭ⶅ")
		name1 = l1l1l1_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠭ࠡࡅࡸࡶࡷ࡫࡮ࡵࠩⶆ")
		name2 = l1l1l1_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠮ࠢࡏࡥࡹ࡫ࡳࡵࠩⶇ")
		l1ll1ll1l11_l1_ = l1l1l1_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡅࡱࡶࡨࡢࡤࡨࡸࠬⶈ")
		l1ll1ll1ll1_l1_ = l1l1l1_l1_ (u"ࠩࡏ࡭ࡻ࡫ࠠࡪࡈ࡬ࡰࡲࠦࡣࡩࡣࡱࡲࡪࡲࠧⶉ")
		l1ll1ll1l1l_l1_ = l1l1l1_l1_ (u"ࠪࡑࡴࡼࡩࡦࡵࠪⶊ")
		l1ll1lll111_l1_ = l1l1l1_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪⶋ")
		l1ll1ll1lll_l1_ = l1l1l1_l1_ (u"࡙ࠬࡨࡰࡹࡶࠫⶌ")
	elif lang in [l1l1l1_l1_ (u"࠭ࡦࡢࠩⶍ"),l1l1l1_l1_ (u"ࠧࡧࡣ࠵ࠫⶎ")]:
		l1ll1ll11ll_l1_ = l1l1l1_l1_ (u"ࠨฮึฮั๎ࠠะำࠣืฬ໒สࠨⶏ")
		name1 = l1l1l1_l1_ (u"ࠩึี๏อไࠡ࠯ࠣะฬื໌ࠨⶐ")
		name2 = l1l1l1_l1_ (u"ࠪืึ๐วๅࠢ࠰ࠤวิัໍ่ࠪⶑ")
		l1ll1ll1l11_l1_ = l1l1l1_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥอไโสสࠫⶒ")
		l1ll1ll1ll1_l1_ = l1l1l1_l1_ (u"ࠬຄฮีࠢี๊ิํࠠศ์ࠣๅ๏๊ๅࠨⶓ")
		l1ll1ll1l1l_l1_ = l1l1l1_l1_ (u"࠭แ๋ๆ่ࠫⶔ")
		l1ll1lll111_l1_ = l1l1l1_l1_ (u"ࠧๆ๊ึ๎็๏ࠧⶕ")
		l1ll1ll1lll_l1_ = l1l1l1_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠫⶖ")
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⶗"),menu_name+l1ll1ll11ll_l1_,l1lll11111l_l1_,29,l1l1l1_l1_ (u"ࠪࠫ⶘"),l1l1l1_l1_ (u"ࠫࠬ⶙"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⶚"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡸࡨࠫ⶛"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⶜")+menu_name+l1ll1ll1ll1_l1_,l1lll11111l_l1_,27)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⶝"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⶞"),l1l1l1_l1_ (u"ࠪࠫ⶟"),9999)
	l1lll1lll1_l1_ = [l1l1l1_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫⶠ"),l1l1l1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭ⶡ"),l1l1l1_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬⶢ")]
	html = OPENURL_CACHED(l11l11l_l1_,l1lll11111l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭ⶣ"),l1l1l1_l1_ (u"ࠨࠩⶤ"),l1l1l1_l1_ (u"ࠩࠪⶥ"),l1l1l1_l1_ (u"ࠪࠫⶦ"),l1l1l1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⶧"))
	l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠬࡨࡵࡵࡶࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠰ࡅࡲࡲࡹࡧࡣࡵࠩⶨ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⶩ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if any(value in l111ll_l1_ for value in l1lll1lll1_l1_):
				url = l1lll11111l_l1_+l111ll_l1_
				if l1l1l1_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧⶪ") in l111ll_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶫ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⶬ")+menu_name+name1,url,22,l1l1l1_l1_ (u"ࠪࠫⶭ"),l1l1l1_l1_ (u"ࠫ࠶࠶࠰ࠨⶮ"))
					addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⶯"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⶰ")+menu_name+name2,url,22,l1l1l1_l1_ (u"ࠧࠨⶱ"),l1l1l1_l1_ (u"ࠨ࠳࠳࠵ࠬⶲ"))
					addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶳ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬⶴ")+menu_name+l1ll1ll1l11_l1_,url,22,l1l1l1_l1_ (u"ࠫࠬⶵ"),l1l1l1_l1_ (u"ࠬ࠸࠰࠲ࠩⶶ"))
				elif l1l1l1_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⶷") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶸ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⶹ")+menu_name+l1ll1ll1l1l_l1_,url,22,l1l1l1_l1_ (u"ࠩࠪⶺ"),l1l1l1_l1_ (u"ࠪ࠵࠵࠶ࠧⶻ"))
				elif l1l1l1_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪⶼ") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶽ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⶾ")+menu_name+l1ll1lll111_l1_,url,25,l1l1l1_l1_ (u"ࠧࠨ⶿"),l1l1l1_l1_ (u"ࠨ࠳࠳࠵ࠬⷀ"))
				elif l1l1l1_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪⷁ") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷂ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ⷃ")+menu_name+l1ll1ll1lll_l1_,url,22,l1l1l1_l1_ (u"ࠬ࠭ⷄ"),l1l1l1_l1_ (u"࠭࠱࠱࠳ࠪⷅ"))
	return html
def l1ll1ll11l1_l1_(url):
	l1lll11111l_l1_ = l1ll1lll11l_l1_(url)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠧࠨⷆ"),l1l1l1_l1_ (u"ࠨࠩ⷇"),l1l1l1_l1_ (u"ࠩࠪⷈ"),l1l1l1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡐ࡙ࡘࡏࡃࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪⷉ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡒࡻࡳࡪࡥ࠰ࡸࡴࡵ࡬ࡴ࠯࡫ࡩࡦࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡍࡶࡵ࡬ࡧ࠲ࡨ࡯ࡥࡻࠪⷊ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	title = re.findall(l1l1l1_l1_ (u"ࠬࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫⷋ"),block,re.DOTALL)[0]
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷌ"),menu_name+title,url,22,l1l1l1_l1_ (u"ࠧࠨⷍ"),l1l1l1_l1_ (u"ࠨ࠳࠳࠵ࠬⷎ"))
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⷏"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		l111ll_l1_ = l1lll11111l_l1_ + l111ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷐ"),menu_name+title,l111ll_l1_,23,l1l1l1_l1_ (u"ࠫࠬⷑ"),l1l1l1_l1_ (u"ࠬ࠷࠰࠲ࠩⷒ"))
	return
def l11l11_l1_(url,page):
	l1lll11111l_l1_ = l1ll1lll11l_l1_(url)
	lang = l1lll1111ll_l1_(url)
	type = url.split(l1l1l1_l1_ (u"࠭࠯ࠨⷓ"))[-1]
	l1ll1l1llll_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨⷔ"),l1l1l1_l1_ (u"ࠨࠩⷕ"),url, type)
	if type==l1l1l1_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩⷖ") and page==l1l1l1_l1_ (u"ࠪ࠴ࠬ⷗"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠫࠬⷘ"),l1l1l1_l1_ (u"ࠬ࠭ⷙ"),l1l1l1_l1_ (u"࠭ࠧⷚ"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪⷛ"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬࠮ࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡴࡽࠧⷜ"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠩ࠰࠭ࡃ࠮ࡄ࠮ࠫࡁ࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬⷝ"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l111ll_l1_ = l1lll11111l_l1_ + l111ll_l1_
			img = l1lll11111l_l1_ + QUOTE(img)
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷞ"),menu_name+title,l111ll_l1_,23,img,l1ll1l1llll_l1_+l1l1l1_l1_ (u"ࠫ࠵࠷ࠧ⷟"))
	l1ll1ll1111_l1_=0
	if type==l1l1l1_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬⷠ"): category=l1l1l1_l1_ (u"࠭࠳ࠨⷡ")
	if type==l1l1l1_l1_ (u"ࠧࡇ࡫࡯ࡱࠬⷢ"): category=l1l1l1_l1_ (u"ࠨ࠷ࠪⷣ")
	if type==l1l1l1_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪⷤ"): category=l1l1l1_l1_ (u"ࠪ࠻ࠬⷥ")
	if type in [l1l1l1_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫⷦ"),l1l1l1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭ⷧ"),l1l1l1_l1_ (u"࠭ࡆࡪ࡮ࡰࠫⷨ")] and page!=l1l1l1_l1_ (u"ࠧ࠱ࠩⷩ"):
		url2 = l1lll11111l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡑࡣࡪࡩ࡮ࡴࡧࡊࡶࡨࡱࡄࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨⷪ")+category+l1l1l1_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩⷫ")+page+l1l1l1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡵࡲࡥࡧࡵࡦࡾࡃࠧⷬ")+l1ll1l1llll_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠫࠬⷭ"),l1l1l1_l1_ (u"ࠬ࠭ⷮ"),l1l1l1_l1_ (u"࠭ࠧⷯ"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪⷰ"))
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩⷱ"),l1l1l1_l1_ (u"ࠩࠪⷲ"),url2, html)
		items = re.findall(l1l1l1_l1_ (u"ࠪࠦࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯࠭ࡂࠦࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧⷳ"),html,re.DOTALL)
		for id,title,img in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l1l1_l1_ (u"ࠫࡡࡢࠧⷴ"),l1l1l1_l1_ (u"ࠬ࠭ⷵ"))
			title = title.replace(l1l1l1_l1_ (u"࠭ࠢࠨⷶ"),l1l1l1_l1_ (u"ࠧࠨⷷ"))
			l1ll1ll1111_l1_ += 1
			l111ll_l1_ = l1lll11111l_l1_ + l1l1l1_l1_ (u"ࠨ࠱ࠪⷸ") + type + l1l1l1_l1_ (u"ࠩ࠲ࡇࡴࡴࡴࡦࡰࡷ࠳ࠬⷹ") + id
			img = l1lll11111l_l1_ + QUOTE(img)
			if type==l1l1l1_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨⷺ"): addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪⷻ"),menu_name+title,l111ll_l1_,24,img,l1ll1l1llll_l1_+l1l1l1_l1_ (u"ࠬ࠶࠱ࠨⷼ"))
			else: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷽ"),menu_name+title,l111ll_l1_,23,img,l1ll1l1llll_l1_+l1l1l1_l1_ (u"ࠧ࠱࠳ࠪⷾ"))
	if type==l1l1l1_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧⷿ"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1lll11111l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡌࡲࡩ࡫ࡸࡀࡲࡤ࡫ࡪࡃࠧ⸀")+page,l1l1l1_l1_ (u"ࠪࠫ⸁"),l1l1l1_l1_ (u"ࠫࠬ⸂"),l1l1l1_l1_ (u"ࠬ࠭⸃"),l1l1l1_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ⸄"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱ࠱ࡩ࡫࡭ࡰࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ࠰ࡨࡪࡳ࡯ࠨ⸅"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ⸆"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			l1ll1ll1111_l1_ += 1
			img = l1lll11111l_l1_ + img
			l111ll_l1_ = l1lll11111l_l1_ + l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸇"),menu_name+title,l111ll_l1_,23,img,l1l1l1_l1_ (u"ࠪ࠵࠵࠷ࠧ⸈"))
	if l1ll1ll1111_l1_>20:
		title=l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪ⸉")
		if lang==l1l1l1_l1_ (u"ࠬ࡫࡮ࠨ⸊"): title = l1l1l1_l1_ (u"࠭ࡐࡢࡩࡨࠤࠬ⸋")
		if lang==l1l1l1_l1_ (u"ࠧࡧࡣࠪ⸌"): title = l1l1l1_l1_ (u"ࠨืไั์ࠦࠧ⸍")
		if lang==l1l1l1_l1_ (u"ࠩࡩࡥ࠷࠭⸎"): title = l1l1l1_l1_ (u"ูࠪๆำ็ࠡࠩ⸏")
		for l1ll1lll1ll_l1_ in range(1,11) :
			if not page==str(l1ll1lll1ll_l1_):
				l1ll1ll111l_l1_ = l1l1l1_l1_ (u"ࠫ࠵࠭⸐")+str(l1ll1lll1ll_l1_)
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸑"),menu_name+title+str(l1ll1lll1ll_l1_),url,22,l1l1l1_l1_ (u"࠭ࠧ⸒"),l1ll1l1llll_l1_+l1ll1ll111l_l1_[-2:])
	return
def l11l1ll_l1_(url,page):
	if not page: page = 0
	l1lll11111l_l1_ = l1ll1lll11l_l1_(url)
	l1lll1111l1_l1_ = l1ll1lll11l_l1_(url)
	lang = l1lll1111ll_l1_(url)
	parts = url.split(l1l1l1_l1_ (u"ࠧ࠰ࠩ⸓"))
	id,type = parts[-1],parts[3]
	l1ll1l1llll_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	l1ll1ll1111_l1_ = 0
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ⸔"),l1l1l1_l1_ (u"ࠩࠪ⸕"),url, type)
	if type==l1l1l1_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⸖"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠫࠬ⸗"),l1l1l1_l1_ (u"ࠬ࠭⸘"),l1l1l1_l1_ (u"࠭ࠧ⸙"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⸚"))
		items = re.findall(l1l1l1_l1_ (u"ࠨࡅࡲࡱࡲ࡫࡮ࡵࡡࡳࡥࡳ࡫࡬ࡠࡋࡷࡩࡲ࠴ࠪࡀࡲࡁࠬ࠳࠰࠿ࠪ࠾࡬࠲࠰ࡅࡶࡢࡴࠣ࡭ࡳࡺࡥࡳࡡࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫ࡟ࠫࠬ⸛"),html,re.DOTALL)
		title = l1l1l1_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭⸜")
		if lang==l1l1l1_l1_ (u"ࠪࡩࡳ࠭⸝"): title = l1l1l1_l1_ (u"ࠫࠥ࠳ࠠࡆࡲ࡬ࡷࡴࡪࡥࠡࠩ⸞")
		if lang==l1l1l1_l1_ (u"ࠬ࡬ࡡࠨ⸟"): title = l1l1l1_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⸠")
		if lang==l1l1l1_l1_ (u"ࠧࡧࡣ࠵ࠫ⸡"): title = l1l1l1_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⸢")
		if lang==l1l1l1_l1_ (u"ࠩࡩࡥࠬ⸣"): l1ll1lllll1_l1_ = l1l1l1_l1_ (u"ࠪࠫ⸤")
		else: l1ll1lllll1_l1_ = lang
		l1lll111l11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹ࡭ࡩ࡫࡯࠾ࠤࠫ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࡡࠬࠬ࠳࠰࠿ࠪࠤࡁࠫ⸥"),html,re.DOTALL)
		for name,count,img,l111ll_l1_ in items:
			for l1llll1_l1_ in range(int(count),0,-1):
				l1l1ll1l1_l1_ = img + l1ll1lllll1_l1_ + id + l1l1l1_l1_ (u"ࠬ࠵ࠧ⸦") + str(l1llll1_l1_) + l1l1l1_l1_ (u"࠭࠮ࡱࡰࡪࠫ⸧")
				#l11111l1ll_l1_ = l1lll111l11_l1_[0][0]+lang+id+l1l1l1_l1_ (u"ࠧ࠰࠮ࠪ⸨")+str(l1llll1_l1_)+l1l1l1_l1_ (u"ࠨ࠮ࠪ⸩")+str(l1llll1_l1_)+l1l1l1_l1_ (u"ࠩࡢࠫ⸪")+l1lll111l11_l1_[0][2]
				name1 = name + title + str(l1llll1_l1_)
				name1 = unescapeHTML(name1)
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⸫"),menu_name+name1,url,24,l1l1ll1l1_l1_,l1l1l1_l1_ (u"ࠫࠬ⸬"),str(l1llll1_l1_))
	elif type==l1l1l1_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⸭"):
		url2 = l1lll11111l_l1_+l1l1l1_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡖࡡࡨࡧ࡬ࡲ࡬ࡇࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࡋࡷࡩࡲࡅࡩࡥ࠿ࠪ⸮")+str(id)+l1l1l1_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧⸯ")+page+l1l1l1_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡳࡷࡪࡥࡳࡤࡼࡁ࠶࠭⸰")
		html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠩࠪ⸱"),l1l1l1_l1_ (u"ࠪࠫ⸲"),l1l1l1_l1_ (u"ࠫࠬ⸳"),l1l1l1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ⸴"))
		items = re.findall(l1l1l1_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡉ࡯ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⸵"),html,re.DOTALL)
		title = l1l1l1_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ⸶")
		if lang==l1l1l1_l1_ (u"ࠨࡧࡱࠫ⸷"): title = l1l1l1_l1_ (u"ࠩࠣ࠱ࠥࡋࡰࡪࡵࡲࡨࡪࠦࠧ⸸")
		if lang==l1l1l1_l1_ (u"ࠪࡪࡦ࠭⸹"): title = l1l1l1_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⸺")
		if lang==l1l1l1_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⸻"): title = l1l1l1_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⸼")
		for l1llll1_l1_,img,l111ll_l1_,desc,name in items:
			l1ll1ll1111_l1_ += 1
			l1l1ll1l1_l1_ = l1lll1111l1_l1_ + QUOTE(img)
			#l11111l1ll_l1_ = l1lll1111l1_l1_ + QUOTE(l111ll_l1_)
			name = escapeUNICODE(name)
			name1 = name + title + str(l1llll1_l1_)
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⸽"),menu_name+name1,url2,24,l1l1ll1l1_l1_,l1l1l1_l1_ (u"ࠨࠩ⸾"),str(l1ll1ll1111_l1_))
	elif type==l1l1l1_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⸿"):
		if l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷࠫ⹀") in url and l1l1l1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⹁") not in url:
			url2 = l1lll11111l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃࠧ⹂")+str(id)+l1l1l1_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⹃")+page+l1l1l1_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠱ࠩ⹄")
			html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠨࠩ⹅"),l1l1l1_l1_ (u"ࠩࠪ⹆"),l1l1l1_l1_ (u"ࠪࠫ⹇"),l1l1l1_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠹ࡲࡥࠩ⹈"))
			items = re.findall(l1l1l1_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⹉"),html,re.DOTALL)
			for img,l111ll_l1_,name,title in items:
				l1ll1ll1111_l1_ += 1
				l1l1ll1l1_l1_ = l1lll1111l1_l1_ + QUOTE(img)
				#l11111l1ll_l1_ = l1lll1111l1_l1_ + QUOTE(l111ll_l1_)
				name1 = name + l1l1l1_l1_ (u"࠭ࠠ࠮ࠢࠪ⹊") + title
				name1 = name1.strip(l1l1l1_l1_ (u"ࠧࠡࠩ⹋"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⹌"),menu_name+name1,url2,24,l1l1ll1l1_l1_,l1l1l1_l1_ (u"ࠩࠪ⹍"),str(l1ll1ll1111_l1_))
		elif l1l1l1_l1_ (u"ࠪࡇࡱ࡯ࡰࡴࠩ⹎") in url:
			url2 = l1lll11111l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭⹏")+page+l1l1l1_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠷࠵ࠨ⹐")
			html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"࠭ࠧ⹑"),l1l1l1_l1_ (u"ࠧࠨ⹒"),l1l1l1_l1_ (u"ࠨࠩ⹓"),l1l1l1_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠸ࡹ࡮ࠧ⹔"))
			items = re.findall(l1l1l1_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡪࡦࡨࡳࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⹕"),html,re.DOTALL)
			for img,title,l111ll_l1_ in items:
				l1ll1ll1111_l1_ += 1
				l1l1ll1l1_l1_ = l1lll1111l1_l1_ + QUOTE(img)
				#l11111l1ll_l1_ = l1lll1111l1_l1_ + QUOTE(l111ll_l1_)
				name1 = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭⹖"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⹗"),menu_name+name1,url2,24,l1l1ll1l1_l1_,l1l1l1_l1_ (u"࠭ࠧ⹘"),str(l1ll1ll1111_l1_))
		elif l1l1l1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⹙") in url:
			if l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠺ࠬ⹚") in url:
				url2 = l1lll11111l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⹛")+page+l1l1l1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠺ࠬ⹜")
				html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠫࠬ⹝"),l1l1l1_l1_ (u"ࠬ࠭⹞"),l1l1l1_l1_ (u"࠭ࠧ⹟"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠷ࡷ࡬ࠬ⹠"))
			elif l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠸ࠬ⹡") in url:
				url2 = l1lll11111l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⹢")+page+l1l1l1_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠸ࠬ⹣")
				html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠫࠬ⹤"),l1l1l1_l1_ (u"ࠬ࠭⹥"),l1l1l1_l1_ (u"࠭ࠧ⹦"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠸ࡷ࡬ࠬ⹧"))
			items = re.findall(l1l1l1_l1_ (u"ࠨࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⹨"),html,re.DOTALL)
			for img,l111ll_l1_,name,title in items:
				l1ll1ll1111_l1_ += 1
				l1l1ll1l1_l1_ = l1lll1111l1_l1_ + QUOTE(img)
				#l11111l1ll_l1_ = l1lll1111l1_l1_ + QUOTE(l111ll_l1_)
				name1 = name + l1l1l1_l1_ (u"ࠩࠣ࠱ࠥ࠭⹩") + title
				name1 = name1.strip(l1l1l1_l1_ (u"ࠪࠤࠬ⹪"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⹫"),menu_name+name1,url2,24,l1l1ll1l1_l1_,l1l1l1_l1_ (u"ࠬ࠭⹬"),str(l1ll1ll1111_l1_))
	if type==l1l1l1_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⹭") or type==l1l1l1_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⹮"):
		if l1ll1ll1111_l1_>25:
			title=l1l1l1_l1_ (u"ࠨืไัฮࠦࠧ⹯")
			if lang==l1l1l1_l1_ (u"ࠩࡨࡲࠬ⹰"): title = l1l1l1_l1_ (u"ࠪࠤࡕࡧࡧࡦࠢࠪ⹱")
			if lang==l1l1l1_l1_ (u"ࠫ࡫ࡧࠧ⹲"): title = l1l1l1_l1_ (u"ࠬࠦีโฯ๊ࠤࠬ⹳")
			if lang==l1l1l1_l1_ (u"࠭ࡦࡢ࠴ࠪ⹴"): title = l1l1l1_l1_ (u"ࠧࠡืไั์ࠦࠧ⹵")
			for l1ll1lll1ll_l1_ in range(1,11):
				if not page==str(l1ll1lll1ll_l1_):
					l1ll1ll111l_l1_ = l1l1l1_l1_ (u"ࠨ࠲ࠪ⹶")+str(l1ll1lll1ll_l1_)
					addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹷"),menu_name+title+str(l1ll1lll1ll_l1_),url,23,l1l1l1_l1_ (u"ࠪࠫ⹸"),l1ll1l1llll_l1_+l1ll1ll111l_l1_[-2:])
	return
def PLAY(url,l1llll1_l1_):
	l1lll1111l1_l1_ = l1ll1lll11l_l1_(url)
	l1111ll_l1_,l11l1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠫࠬ⹹"),l1l1l1_l1_ (u"ࠬ࠭⹺"),l1l1l1_l1_ (u"࠭ࠧ⹻"),l1l1l1_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⹼"))
	# l1ll1_l1_ l111111l_l1_ l1ll_l1_
	items = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ⹽"),html,re.DOTALL)
	if items:
		lang = l1lll1111ll_l1_(url)
		parts = url.split(l1l1l1_l1_ (u"ࠩ࠲ࠫ⹾"))
		id,type = parts[-1],parts[3]
		l111ll_l1_ = items[0][0]+lang+id+l1l1l1_l1_ (u"ࠪ࠳࠱࠭⹿")+l1llll1_l1_+l1l1l1_l1_ (u"ࠫ࠱࠭⺀")+l1llll1_l1_+l1l1l1_l1_ (u"ࠬࡥࠧ⺁")+items[0][2]
		l1111ll_l1_.append(l1l1l1_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ⺂"))
		l11l1_l1_.append(l111ll_l1_)
	# l1ll1_l1_ l111lll1_l1_ url
	items = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭ࠩࠩ࡞࠱࠲࠯ࡅࠩࠣࠩ⺃"),html,re.DOTALL)
	if items:
		lang = l1lll1111ll_l1_(url)
		parts = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ⺄"))
		id,type = parts[-1],parts[3]
		l111ll_l1_ = items[0][0]+lang+id+l1l1l1_l1_ (u"ࠩ࠲ࠫ⺅")+l1llll1_l1_+items[0][2]
		l1111ll_l1_.append(l1l1l1_l1_ (u"ࠪࡱࡵ࠺ࠠࡶࡴ࡯ࠫ⺆"))
		l11l1_l1_.append(l111ll_l1_)
	# l1ll1_l1_ l111lll1_l1_ src
	items = re.findall(l1l1l1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⺇"),html,re.DOTALL)
	for l111ll_l1_ in items:
		l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠬ࠵࠯ࠨ⺈"),l1l1l1_l1_ (u"࠭࠯ࠨ⺉"))
		l1111ll_l1_.append(l1l1l1_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡸࡸࡣࠨ⺊"))
		l11l1_l1_.append(l111ll_l1_)
	# l1ll1llllll_l1_ l111lll1_l1_ l1ll_l1_
	items = re.findall(l1l1l1_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⺋"),html,re.DOTALL)
	if items:
		l111ll_l1_ = items[int(l1llll1_l1_)-1]
		l111ll_l1_ = l1lll1111l1_l1_+QUOTE(l111ll_l1_)
		l1111ll_l1_.append(l1l1l1_l1_ (u"ࠩࡰࡴ࠹ࠦࡡࡥࡦࡵࡩࡸࡹࠧ⺌"))
		l11l1_l1_.append(l111ll_l1_)
	# l1ll1llllll_l1_ l1lll111l1l_l1_ l1ll_l1_
	items = re.findall(l1l1l1_l1_ (u"࡚ࠪࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⺍"),html,re.DOTALL)
	if items:
		l111ll_l1_ = items[int(l1llll1_l1_)-1]
		l111ll_l1_ = l1lll1111l1_l1_+QUOTE(l111ll_l1_)
		l1111ll_l1_.append(l1l1l1_l1_ (u"ࠫࡲࡶ࠳ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ⺎"))
		l11l1_l1_.append(l111ll_l1_)
	# selection
	if len(l11l1_l1_)==1: l111ll_l1_ = l11l1_l1_[0]
	else:
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭⺏"), l1111ll_l1_)
		if selection == -1 : return
		l111ll_l1_ = l11l1_l1_[selection]
	PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⺐"))
	return
def l1ll1lll11l_l1_(url):
	if l1l11l_l1_ in url: site = l1l11l_l1_
	elif l1ll11ll1l_l1_ in url: site = l1ll11ll1l_l1_
	elif l1ll1lll1l1_l1_ in url: site = l1ll1lll1l1_l1_
	elif l1ll1llll11_l1_ in url: site = l1ll1llll11_l1_
	else: site = l1l1l1_l1_ (u"ࠧࠨ⺑")
	return site
def l1lll1111ll_l1_(url):
	if   l1l11l_l1_ in url: lang = l1l1l1_l1_ (u"ࠨࡣࡵࠫ⺒")
	elif l1ll11ll1l_l1_ in url: lang = l1l1l1_l1_ (u"ࠩࡨࡲࠬ⺓")
	elif l1ll1lll1l1_l1_ in url: lang = l1l1l1_l1_ (u"ࠪࡪࡦ࠭⺔")
	elif l1ll1llll11_l1_ in url: lang = l1l1l1_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⺕")
	else: lang = l1l1l1_l1_ (u"ࠬ࠭⺖")
	return lang
def l1ll11lll_l1_(url):
	lang = l1lll1111ll_l1_(url)
	url2 = url + l1l1l1_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡒࡩࡷࡧࠪ⺗")
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ⺘"),url2,l1l1l1_l1_ (u"ࠨࠩ⺙"),l1l1l1_l1_ (u"ࠩࠪ⺚"),l1l1l1_l1_ (u"ࠪࠫ⺛"),l1l1l1_l1_ (u"ࠫࠬ⺜"),l1l1l1_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭⺝"))
	html = response.content
	items = re.findall(l1l1l1_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺞"),html,re.DOTALL)
	url3 = items[0]
	PLAY_VIDEO(url3,script_name,l1l1l1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⺟"))
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ⺠"),l1l1l1_l1_ (u"ࠩ࠮ࠫ⺡"))
	if l111l_l1_:
		l1lll1ll1l_l1_ = [ l1l11l_l1_ , l1ll11ll1l_l1_ , l1ll1lll1l1_l1_ , l1ll1llll11_l1_ ]
		l111l1l11_l1_ = [ l1l1l1_l1_ (u"ࠪ฽ึฮ๊ࠨ⺢") , l1l1l1_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⺣") , l1l1l1_l1_ (u"ࠬ็วาี์ࠫ⺤") , l1l1l1_l1_ (u"࠭แศำึํࠥ࠸ࠧ⺥") ]
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠧศะอีࠥอไๅ฼ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ⺦"), l111l1l11_l1_)
		if selection == -1 : return
		website = l1lll1ll1l_l1_[selection]
	else:
		if l1l1l1_l1_ (u"ࠨࡡࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࡠࠩ⺧") in options: website = l1l11l_l1_
		elif l1l1l1_l1_ (u"ࠩࡢࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࡢࠫ⺨") in options: website = l1ll11ll1l_l1_
		else: website = l1l1l1_l1_ (u"ࠪࠫ⺩")
	if not website: return
	lang = l1lll1111ll_l1_(website)
	url2 = website + l1l1l1_l1_ (u"ࠦ࠴ࡎ࡯࡮ࡧ࠲ࡗࡪࡧࡲࡤࡪࡂࡷࡪࡧࡲࡤࡪࡶࡸࡷ࡯࡮ࡨ࠿ࠥ⺪") + l11ll11_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭⺫"),l1l1l1_l1_ (u"࠭ࠧ⺬"),lang,url2)
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠧࠨ⺭"),l1l1l1_l1_ (u"ࠨࠩ⺮"),l1l1l1_l1_ (u"ࠩࠪ⺯"),l1l1l1_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭⺰"))
	items = re.findall(l1l1l1_l1_ (u"ࠫࠧࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡈࡧࡴࡦࡩࡲࡶࡾࡏࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠨ⺱"),html,re.DOTALL)
	if items:
		for img,category,id,title in items:
			#if category in [l1l1l1_l1_ (u"ࠬ࠹ࠧ⺲"),l1l1l1_l1_ (u"࠭࠵ࠨ⺳"),l1l1l1_l1_ (u"ࠧ࠸ࠩ⺴")]:
			if category in [l1l1l1_l1_ (u"ࠨ࠵ࠪ⺵"),l1l1l1_l1_ (u"ࠩ࠺ࠫ⺶")]:
				title = title.replace(l1l1l1_l1_ (u"ࠪࡠࡡ࠭⺷"),l1l1l1_l1_ (u"ࠫࠬ⺸"))
				title = title.replace(l1l1l1_l1_ (u"ࠬࠨࠧ⺹"),l1l1l1_l1_ (u"࠭ࠧ⺺"))
				if category==l1l1l1_l1_ (u"ࠧ࠴ࠩ⺻"):
					type = l1l1l1_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⺼")
					if lang==l1l1l1_l1_ (u"ࠩࡤࡶࠬ⺽"): name = l1l1l1_l1_ (u"ุ้๊ࠪำๅࠢ࠽ࠤࠬ⺾")
					elif lang==l1l1l1_l1_ (u"ࠫࡪࡴࠧ⺿"): name = l1l1l1_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥࡀࠠࠨ⻀")
					elif lang==l1l1l1_l1_ (u"࠭ࡦࡢࠩ⻁"): name = l1l1l1_l1_ (u"ࠧิำํห้ࠦ็ศࠢ࠽ࠤࠬ⻂")
					elif lang==l1l1l1_l1_ (u"ࠨࡨࡤ࠶ࠬ⻃"): name = l1l1l1_l1_ (u"ࠩึี๏อไ้ࠡสࠤ࠿ࠦࠧ⻄")
				elif category==l1l1l1_l1_ (u"ࠪ࠹ࠬ⻅"):
					type = l1l1l1_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⻆")
					if lang==l1l1l1_l1_ (u"ࠬࡧࡲࠨ⻇"): name = l1l1l1_l1_ (u"࠭แ๋ๆ่ࠤ࠿ࠦࠧ⻈")
					elif lang==l1l1l1_l1_ (u"ࠧࡦࡰࠪ⻉"): name = l1l1l1_l1_ (u"ࠨࡏࡲࡺ࡮࡫ࠠ࠻ࠢࠪ⻊")
					elif lang==l1l1l1_l1_ (u"ࠩࡩࡥࠬ⻋"): name = l1l1l1_l1_ (u"ࠪๅ๏๊ๅࠡ࠼ࠣࠫ⻌")
					elif lang==l1l1l1_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⻍"): name = l1l1l1_l1_ (u"ࠬ็ไๆ๊ࠢหࠥࡀࠠࠨ⻎")
				elif category==l1l1l1_l1_ (u"࠭࠷ࠨ⻏"):
					type = l1l1l1_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⻐")
					if lang==l1l1l1_l1_ (u"ࠨࡣࡵࠫ⻑"): name = l1l1l1_l1_ (u"ࠩหี๋อๅอࠢ࠽ࠤࠬ⻒")
					elif lang==l1l1l1_l1_ (u"ࠪࡩࡳ࠭⻓"): name = l1l1l1_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠥࡀࠠࠨ⻔")
					elif lang==l1l1l1_l1_ (u"ࠬ࡬ࡡࠨ⻕"): name = l1l1l1_l1_ (u"࠭ศา่ส้์ࠦ็ศࠢ࠽ࠤࠬ⻖")
					elif lang==l1l1l1_l1_ (u"ࠧࡧࡣ࠵ࠫ⻗"): name = l1l1l1_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠤ࠿ࠦࠧ⻘")
				title = name + title
				l111ll_l1_ = website + l1l1l1_l1_ (u"ࠩ࠲ࠫ⻙") + type + l1l1l1_l1_ (u"ࠪ࠳ࡈࡵ࡮ࡵࡧࡱࡸ࠴࠭⻚") + id
				img = QUOTE(img)
				img = website+img
				#LOG_THIS(l1l1l1_l1_ (u"ࠫࠬ⻛"),img)
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻜"),menu_name+title,l111ll_l1_,23,img,l1l1l1_l1_ (u"࠭࠱࠱࠳ࠪ⻝"))
	#else: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ⻞"),l1l1l1_l1_ (u"ࠨࠩ⻟"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⻠"),,لا توجد نتائج للبحث')
	return
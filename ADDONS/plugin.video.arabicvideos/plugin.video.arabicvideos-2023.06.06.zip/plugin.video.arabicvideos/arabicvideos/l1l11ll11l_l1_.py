# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
#
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ᵔ")
def MAIN(mode,url):
	if   mode==330: results = l1l1ll1l1l_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l1l1l111ll_l1_()
	elif mode==333: results = l1l11l11l1_l1_()
	elif mode==334: results = l1l1l1111l_l1_(url)
	else: results = False
	return results
def l1l1l1111l_l1_(l1l11ll111_l1_):
	try: os.remove(l1l11ll111_l1_.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᵕ")))
	except: os.remove(l1l11ll111_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᵖ"))
	return
def l1l11l11l1_l1_():
	message = l1l1l1_l1_ (u"ࠧฤา๊ฬࠥหไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭ᵗ")
	DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩᵘ"),l1l1l1_l1_ (u"ࠩࠪᵙ"),l1l1l1_l1_ (u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡษ็้้็วหࠩᵚ"),message)
	return
def l1l1ll1l1l_l1_():
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᵛ"),l1l1l1_l1_ (u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪᵜ"),l1l1l1_l1_ (u"࠭ࠧᵝ"),333)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᵞ"),l1l1l1_l1_ (u"ࠨฬ฽๎๏ืࠠๆๅส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨᵟ"),l1l1l1_l1_ (u"ࠩࠪᵠ"),332)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᵡ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᵢ"),l1l1l1_l1_ (u"ࠬ࠭ᵣ"),9999)
	l1l1l1ll11_l1_ = l1l1l11111_l1_()
	mtime = os.stat(l1l1l1ll11_l1_).st_mtime
	files = []
	if kodi_version>18.99: l1l1l1l1ll_l1_ = os.listdir(l1l1l1ll11_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᵤ")))
	else: l1l1l1l1ll_l1_ = os.listdir(l1l1l1ll11_l1_.decode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᵥ")))
	for filename in l1l1l1l1ll_l1_:
		if kodi_version>18.99: filename = filename.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᵦ"))
		if not filename.startswith(l1l1l1_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨᵧ")): continue
		filepath = os.path.join(l1l1l1ll11_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l1l1ll11l1_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᵨ"))
			except: pass
			filename = filename.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩᵩ"))
		filepath = os.path.join(l1l1l1ll11_l1_,filename)
		addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᵪ"),filename,filepath,331)
	return
def l1l1l11111_l1_():
	l1l1l1ll11_l1_ = settings.getSetting(l1l1l1_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩᵫ"))
	if l1l1l1ll11_l1_: return l1l1l1ll11_l1_
	settings.setSetting(l1l1l1_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪᵬ"),addoncachefolder)
	return addoncachefolder
def l1l1l111ll_l1_():
	l1l1l1ll11_l1_ = l1l1l11111_l1_()
	l1l1l1l111_l1_ = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᵭ"),l1l1l1_l1_ (u"ࠩࠪᵮ"),l1l1l1_l1_ (u"ࠪࠫᵯ"),l1l1l1ll11_l1_,l1l1l1_l1_ (u"ࠫ์ึว้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠห฼ํ๎ึࠦวๅ็ๆห๋ࠦฟࠨᵰ"))
	if l1l1l1l111_l1_==1:
		newpath = l1l1l11l1l_l1_(3,l1l1l1_l1_ (u"๋ࠬใศ่ࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩᵱ"),l1l1l1_l1_ (u"࠭࡬ࡰࡥࡤࡰࠬᵲ"),l1l1l1_l1_ (u"ࠧࠨᵳ"),False,True,l1l1l1ll11_l1_)
		yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᵴ"),l1l1l1_l1_ (u"ࠩࠪᵵ"),l1l1l1_l1_ (u"ࠪࠫᵶ"),newpath,l1l1l1_l1_ (u"ࠫ์ึว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ฬะ์าࠤ้ะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ࠥฮฯๅษ้๋ࠣࠦวๅ็ๆห๋ࠦวๅไา๎๊ࠦฟࠨᵷ"))
		if yes==1:
			settings.setSetting(l1l1l1_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨᵸ"),newpath)
			DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᵹ"),l1l1l1_l1_ (u"ࠧࠨᵺ"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᵻ"),l1l1l1_l1_ (u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪᵼ"))
	#if not l1l1l1l111_l1_ or not yes: DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫᵽ"),l1l1l1_l1_ (u"ࠫࠬᵾ"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᵿ"),l1l1l1_l1_ (u"࠭สๆࠢส่฿อมࠡษ็฽๊๊๊สࠩᶀ"))
	return
def l1l1l11l11_l1_(filename):
	l1l1ll1l11_l1_ = l1l1l1_l1_ (u"ࠧࠨᶁ").join(ii for ii in filename if ii not in l1l1l1_l1_ (u"ࠨ࡞࠲ࠦ࠿࠰࠿࠽ࡀࡿࠫᶂ")+half_triangular_colon)
	return l1l1ll1l11_l1_
def l1l11lllll_l1_(url,videofiletype=l1l1l1_l1_ (u"ࠩࠪᶃ"),website=l1l1l1_l1_ (u"ࠪࠫᶄ")):
	#DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫᶅ"),l1l1l1_l1_ (u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬᶆ"))
	LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᶇ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᶈ")+url+l1l1l1_l1_ (u"ࠨࠢࡠࠫᶉ"))
	if not videofiletype: videofiletype = GET_VIDEOFILETYPE(url,website)
	#if not videofiletype:
	#	DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪᶊ"),l1l1l1_l1_ (u"ࠪࠫᶋ"),l1l1l1_l1_ (u"ࠫฯ์า๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᶌ"),l1l1l1_l1_ (u"ࠬอไๆๆไࠤ๊์ࠠ็๊฼ࠤࠬᶍ")+videofiletype+l1l1l1_l1_ (u"้࠭ࠠษ็ฬึ์วๆฮࠣัฬ๊๊ศࠢ฽๎ึࠦฬศ้ีࠤ้ะอๆ์็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้๋ไโษอࠫᶎ"))
	#	LOG_THIS(l1l1l1_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬᶏ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡸࡾࡶࡥ࠰ࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᶐ")+url+l1l1l1_l1_ (u"ࠩࠣࡡࠬᶑ"))
	#	return False
	l1l1l1ll11_l1_ = l1l1l11111_l1_()
	l1l1l1llll_l1_ = l1l1l1l1l1_l1_()
	filename = l1l1l1llll_l1_.replace(l1l1l1_l1_ (u"ࠪࠤࠬᶒ"),l1l1l1_l1_ (u"ࠫࡤ࠭ᶓ"))
	filename = l1l1l11l11_l1_(filename)
	#videofiletype = videofiletype.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᶔ"))
	filename = l1l1l1_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬᶕ")+str(int(now))[-4:]+l1l1l1_l1_ (u"ࠧࡠࠩᶖ")+filename+videofiletype
	l1l11l11ll_l1_ = os.path.join(l1l1l1ll11_l1_,filename)
	headers = {}
	headers[l1l1l1_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪᶗ")] = l1l1l1_l1_ (u"ࠩࠪᶘ")
	headers[l1l1l1_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶࠪᶙ")] = l1l1l1_l1_ (u"ࠫ࠯࠵ࠪࠨᶚ")
	url = url.replace(l1l1l1_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨᶛ"),l1l1l1_l1_ (u"࠭ࠧᶜ"))
	if l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬᶝ") in url:
		url2,useragent = url.rsplit(l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᶞ"),1)
		useragent = useragent.replace(l1l1l1_l1_ (u"ࠩࡿࠫᶟ"),l1l1l1_l1_ (u"ࠪࠫᶠ")).replace(l1l1l1_l1_ (u"ࠫࠫ࠭ᶡ"),l1l1l1_l1_ (u"ࠬ࠭ᶢ"))
	else: url2,useragent = url,None
	if not useragent: useragent = l1l1l11ll_l1_()
	if useragent: headers[l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᶣ")] = useragent
	if l1l1l1_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᶤ") in url2: url2,l1l11ll1ll_l1_ = url2.rsplit(l1l1l1_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᶥ"),1)
	else: url2,l1l11ll1ll_l1_ = url2,l1l1l1_l1_ (u"ࠩࠪᶦ")
	url2 = url2.strip(l1l1l1_l1_ (u"ࠪࢀࠬᶧ")).strip(l1l1l1_l1_ (u"ࠫࠫ࠭ᶨ")).strip(l1l1l1_l1_ (u"ࠬࢂࠧᶩ")).strip(l1l1l1_l1_ (u"࠭ࠦࠨᶪ"))
	l1l11ll1ll_l1_ = l1l11ll1ll_l1_.replace(l1l1l1_l1_ (u"ࠧࡽࠩᶫ"),l1l1l1_l1_ (u"ࠨࠩᶬ")).replace(l1l1l1_l1_ (u"ࠩࠩࠫᶭ"),l1l1l1_l1_ (u"ࠪࠫᶮ"))
	if l1l11ll1ll_l1_:	headers[l1l1l1_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬᶯ")] = l1l11ll1ll_l1_
	LOG_THIS(l1l1l1_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᶰ"),LOGGING(script_name)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᶱ")+url2+l1l1l1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪᶲ")+str(headers)+l1l1l1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᶳ")+l1l11l11ll_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠬᶴ"))
	MegaByte = 1024*1024
	l1l1l1lll1_l1_ = 0
	try:
		l1l1l1ll1l_l1_ =	xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡫ࡥࡔࡲࡤࡧࡪ࠭ᶵ"))
		l1l1l1ll1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡡࡪࠫࠨᶶ"),l1l1l1ll1l_l1_)
		l1l1l1lll1_l1_ = int(l1l1l1ll1l_l1_[0])
	except: pass
	if l1l1l1lll1_l1_==0:
		try:
			st = os.l1l11l1111_l1_(l1l1l1ll11_l1_)
			l1l1l1lll1_l1_ = st.f_frsize*st.f_bavail//MegaByte
		except: pass
	if l1l1l1lll1_l1_==0:
		try:
			st = os.l1l1ll11ll_l1_(l1l1l1ll11_l1_)
			l1l1l1lll1_l1_ = st.f_frsize*st.f_bavail//MegaByte
		except: pass
	if l1l1l1lll1_l1_==0:
		try:
			import shutil
			total,l1l1l111l1_l1_,l1l11llll1_l1_ = shutil.l1l1lll111_l1_(l1l1l1ll11_l1_)
			l1l1l1lll1_l1_ = l1l11llll1_l1_//MegaByte
		except: pass
	if l1l1l1lll1_l1_==0:
		l1l1lll11l_l1_(l1l1l1_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫᶷ"),l1l1l1_l1_ (u"࠭ๅิษะอࠥอไหะี๎๋ࠦๅอ้๋่ฮ࠭ᶸ"),l1l1l1_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣว๋๊ࠦฮัาࠤ๊่ฯศำุ้ࠣออสࠢส่ฯิา๋่ࠣห้็วา฼ฬࠤๆ๐ࠠอ้สึฺ่่ࠦๆํ๋ࠥ็ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ๊ࠥๆࠡ์฼ู้้ࠦ็ัๆࠤส๊้ࠡล้ࠤ๏่่ๆ่ࠢฬึ๋ฬ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠษฯ็ࠤ์ึ็ࠡษ็ู้้ไสࠢ็ห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢๅำࠥ๐ำษสࠣห๊ะไศรࠣะ์อาไࠢหห้๋ไโษอࠤํํะศࠢไ๎์ࠦฮุ๊ิอࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ์้ํะศࠢสุ่ฮศࠡไส้ࠥอไๆสิ้ัࠦๅลไอหࠥฮๅ็฻ࠣห้ฮั็ษ่ะ๋ࠥๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫᶹ"),l1l1l1_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫᶺ"))
		LOG_THIS(l1l1l1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᶻ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡧࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥࡺࡨࡦࠢࡧ࡭ࡸࡱࠠࡧࡴࡨࡩࠥࡹࡰࡢࡥࡨࠫᶼ"))
		return False
	import requests
	if videofiletype==l1l1l1_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪᶽ"):
		l1111ll_l1_,l11l1_l1_ = l1l1ll1ll1_l1_(url2,headers)
		#DIALOG_SELECT(l1l1l1_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪᶾ"), l1111ll_l1_)
		#DIALOG_SELECT(l1l1l1_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᶿ"), l11l1_l1_)
		if len(l1111ll_l1_)==0:
			DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫ᷀"),l1l1l1_l1_ (u"ࠨࠩ᷁"))
			return False
		elif len(l1111ll_l1_)==1: selection = 0
		elif len(l1111ll_l1_)>1:
			selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ᷂ࠧ"), l1111ll_l1_)
			if selection == -1 :
				DIALOG_NOTIFICATION(l1l1l1_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭᷃"),l1l1l1_l1_ (u"ࠫࠬ᷄"))
				return False
		url2 = l11l1_l1_[selection]
	filesize = 0
	if videofiletype==l1l1l1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ᷅"):
		l1l11l11ll_l1_ = l1l11l11ll_l1_.rsplit(l1l1l1_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ᷆"))[0]+l1l1l1_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ᷇")
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ᷈"),url2,l1l1l1_l1_ (u"ࠩࠪ᷉"),headers,l1l1l1_l1_ (u"᷊ࠪࠫ"),l1l1l1_l1_ (u"ࠫࠬ᷋"),l1l1l1_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊ࠭ࡅࡑ࡚ࡒࡑࡕࡁࡅࡡ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ᷌"))
		l111111l_l1_ = response.content
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭࡜ࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ᷍"),l111111l_l1_+l1l1l1_l1_ (u"ࠧ࡝ࡰ࡟ࡶ᷎ࠬ"),re.DOTALL)
		if not l1ll_l1_:
			LOG_THIS(l1l1l1_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ᷏࠭"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ᷐ࠬ")+url2+l1l1l1_l1_ (u"ࠪࠤࡢ࠭᷑"))
			return False
		l111ll_l1_ = l1ll_l1_[0]
		if not l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᷒")):
			if l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠬ࠵࠯ࠨᷓ")): l111ll_l1_ = url2.split(l1l1l1_l1_ (u"࠭࠺ࠨᷔ"),1)[0]+l1l1l1_l1_ (u"ࠧ࠻ࠩᷕ")+l111ll_l1_
			elif l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠨ࠱ࠪᷖ")): l111ll_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭ᷗ"))+l111ll_l1_
			else: l111ll_l1_ = url2.rsplit(l1l1l1_l1_ (u"ࠪ࠳ࠬᷘ"),1)[0]+l1l1l1_l1_ (u"ࠫ࠴࠭ᷙ")+l111ll_l1_
		response = requests.request(l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᷚ"),l111ll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l1l11lll1l_l1_ = len(l1ll_l1_)
		filesize = chunksize*l1l11lll1l_l1_
	else:
		chunksize = 1*MegaByte
		response = requests.request(l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪᷛ"),url2,headers=headers,verify=False,stream=True)
		if l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᷜ") in response.headers: filesize = int(response.headers[l1l1l1_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᷝ")])
		l1l11lll1l_l1_ = int(filesize//chunksize)
	#l1l1ll1111_l1_ = l1l11lll1l_l1_+1
	l1l1ll1111_l1_ = int(filesize//MegaByte)+1
	if filesize<21000:
		LOG_THIS(l1l1l1_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᷞ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡴࡰࡱࠣࡷࡲࡧ࡬࡭ࠢࡲࡶࠥ࡯ࡴࠡ࡫ࡶࠤࡲ࠹ࡵ࠹ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᷟ")+url2+l1l1l1_l1_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᷠ")+str(l1l1ll1111_l1_)+l1l1l1_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᷡ")+str(l1l1l1lll1_l1_)+l1l1l1_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᷢ")+l1l11l11ll_l1_+l1l1l1_l1_ (u"ࠧࠡ࡟ࠪᷣ"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩᷤ"),l1l1l1_l1_ (u"ࠩࠪᷥ"),l1l1l1_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷦ"),l1l1l1_l1_ (u"ࠫๆฺไࠡใํࠤ๊฿ัโหࠣัั๋ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็้้็ࠠึ฼ํีࠥาฯศ๋่ࠢ์ึวࠡๆสࠤ๏๋ใ็ࠢ็่อืๆศ็ฯࠤฯำๅ๋ๆ๋ࠣีอࠠศๆ่่ๆ࠭ᷧ"))
		return False
	l1l11ll1l1_l1_ = 400
	l1l11l1l1l_l1_ = l1l1l1lll1_l1_-l1l1ll1111_l1_
	if l1l11l1l1l_l1_<l1l11ll1l1_l1_:
		LOG_THIS(l1l1l1_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᷨ"),LOGGING(script_name)+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡑࡳࡹࠦࡥ࡯ࡱࡸ࡫࡭ࠦࡤࡪࡵ࡮ࠤࡸࡶࡡࡤࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᷩ")+url2+l1l1l1_l1_ (u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᷪ")+str(l1l1ll1111_l1_)+l1l1l1_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧᷫ")+str(l1l1l1lll1_l1_)+l1l1l1_l1_ (u"ࠩࠣࡑࡇࠦ࠭ࠡࠩᷬ")+str(l1l11ll1l1_l1_)+l1l1l1_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᷭ")+l1l11l11ll_l1_+l1l1l1_l1_ (u"ࠫࠥࡣࠧᷮ"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭ᷯ"),l1l1l1_l1_ (u"࠭ࠧᷰ"),l1l1l1_l1_ (u"ࠧๅษࠣ๎ําฯࠡ็ึหาฯࠠไษไ๎ฮࠦไๅฬะ้๏๊ࠧᷱ"),l1l1l1_l1_ (u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็ࠡฯฯ้์ࠦࠧᷲ")+str(l1l1ll1111_l1_)+l1l1l1_l1_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠࠨᷳ")+str(l1l1l1lll1_l1_)+l1l1l1_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦๅๆ่ัฬ็ุสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหำํ์ࠠๆึส็้๊ࠦอสࠣษอ่วยࠢࠪᷴ")+str(l1l11ll1l1_l1_)+l1l1l1_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠโษิ฾ฮࠦฯศศ่หࠥ๎็ัษ้ࠣ฾์ว่ࠢฦ๊ࠥา็ศิๆࠤ้อࠠห๊ฯำࠥ็๊่่ࠢืฬำษࠡๅสๅ๏ฯࠠๅฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥอไๆู็์อ࠭᷵"))
		return False
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ᷶"),l1l1l1_l1_ (u"᷷࠭ࠧ"),l1l1l1_l1_ (u"ࠧࠨ᷸"),l1l1l1_l1_ (u"ࠨ้็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠภ᷹ࠩ"),l1l1l1_l1_ (u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢะะ๊ํࠠหไิ๎ออࠠࠨ᷺")+str(l1l1ll1111_l1_)+l1l1l1_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡฬๅี๏ฮวࠡࠩ᷻")+str(l1l1l1lll1_l1_)+l1l1l1_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้้ࠠำหࠥอไๆๆไࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ็่ฯำๅ๋ๆ้๋ࠣࠦวๅว้ฮึ์สࠡว็ํࠥา็ศิๆࠤ࠳ࠦ็ๅࠢส๊ฯࠦๅหลๆำࠥ๎สา์าࠤฬ๊วิฬ่ีฬืࠠษฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥลࠧ᷼"))
	if yes!=1:
		DIALOG_OK(l1l1l1_l1_ (u"᷽ࠬ࠭"),l1l1l1_l1_ (u"࠭ࠧ᷾"),l1l1l1_l1_ (u"ࠧࠨ᷿"),l1l1l1_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭Ḁ"))
		LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩḁ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡷ࡫ࡦࡶࡵࡨࡨࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ḃ")+url2+l1l1l1_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫḃ")+l1l11l11ll_l1_+l1l1l1_l1_ (u"ࠬࠦ࡝ࠨḄ"))
		return False
	LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ḅ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠬḆ"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l11l11ll_l1_,l1l1l1_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩḇ"))
	l1l11lll11_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l1l11l11ll_l1_,l1l1l1_l1_ (u"ࠩࡺࡦࠬḈ"))
	else: file = open(l1l11l11ll_l1_.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨḉ")),l1l1l1_l1_ (u"ࠫࡼࡨࠧḊ"))
	if videofiletype==l1l1l1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫḋ"): # l1l1l111l1_l1_ for l111111l_l1_ and l1l11l1ll1_l1_ chunks l1l1ll111l_l1_ files such as .l1l1l1l11l_l1_
		for ii in range(1,l1l11lll1l_l1_+1):
			l111ll_l1_ = l1ll_l1_[ii-1]
			if not l111ll_l1_.startswith(l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫḌ")):
				if l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠧ࠰࠱ࠪḍ")): l111ll_l1_ = url2.split(l1l1l1_l1_ (u"ࠨ࠼ࠪḎ"),1)[0]+l1l1l1_l1_ (u"ࠩ࠽ࠫḏ")+l111ll_l1_
				elif l111ll_l1_.startswith(l1l1l1_l1_ (u"ࠪ࠳ࠬḐ")): l111ll_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨḑ"))+l111ll_l1_
				else: l111ll_l1_ = url2.rsplit(l1l1l1_l1_ (u"ࠬ࠵ࠧḒ"),1)[0]+l1l1l1_l1_ (u"࠭࠯ࠨḓ")+l111ll_l1_
			response = requests.request(l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫḔ"),l111ll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			t2 = time.time()
			l1l11l111l_l1_ = t2-t1
			l1l11l1l11_l1_ = l1l11l111l_l1_//ii
			l1l1l11ll1_l1_ = l1l11l1l11_l1_*(l1l11lll1l_l1_+1)
			l1l11l1lll_l1_ = l1l1l11ll1_l1_-l1l11l111l_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii//(l1l11lll1l_l1_+1)),l1l1l1_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩḕ"),l1l1l1_l1_ (u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩḖ"),str(ii*chunksize//MegaByte)+l1l1l1_l1_ (u"ࠪ࠳ࠬḗ")+str(l1l1ll1111_l1_)+l1l1l1_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩḘ")+time.strftime(l1l1l1_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢḙ"),time.gmtime(l1l11l1lll_l1_))+l1l1l1_l1_ (u"࠭ࠠแࠩḚ"))
			if pDialog.iscanceled():
				l1l11lll11_l1_ = False
				break
	else: # l111lll1_l1_ and other l1l1l11lll_l1_ file l1l1ll1lll_l1_
		ii = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			ii = ii+1
			t2 = time.time()
			l1l11l111l_l1_ = t2-t1
			l1l11l1l11_l1_ = l1l11l111l_l1_/ii
			l1l1l11ll1_l1_ = l1l11l1l11_l1_*(l1l11lll1l_l1_+1)
			l1l11l1lll_l1_ = l1l1l11ll1_l1_-l1l11l111l_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii/(l1l11lll1l_l1_+1)),l1l1l1_l1_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨḛ"),l1l1l1_l1_ (u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨḜ"),str(ii*chunksize//MegaByte)+l1l1l1_l1_ (u"ࠩ࠲ࠫḝ")+str(l1l1ll1111_l1_)+l1l1l1_l1_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨḞ")+time.strftime(l1l1l1_l1_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨḟ"),time.gmtime(l1l11l1lll_l1_))+l1l1l1_l1_ (u"ࠬࠦเࠨḠ"))
			if pDialog.iscanceled():
				l1l11lll11_l1_ = False
				break
		response.close()
	file.close()
	pDialog.close()
	if not l1l11lll11_l1_:
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ḡ"),LOGGING(script_name)+l1l1l1_l1_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠲࡭ࡳࡺࡥࡳࡴࡸࡴࡹ࡫ࡤࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡱࡴࡲࡧࡪࡹࡳ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫḢ")+url2+l1l1l1_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨḣ")+l1l11l11ll_l1_+l1l1l1_l1_ (u"ࠩࠣࡡࠬḤ"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫḥ"),l1l1l1_l1_ (u"ࠫࠬḦ"),l1l1l1_l1_ (u"ࠬ࠭ḧ"),l1l1l1_l1_ (u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫḨ"))
		return True
	LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧḩ"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧḪ")+url2+l1l1l1_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩḫ")+l1l11l11ll_l1_+l1l1l1_l1_ (u"ࠪࠤࡢ࠭Ḭ"))
	DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬḭ"),l1l1l1_l1_ (u"ࠬ࠭Ḯ"),l1l1l1_l1_ (u"࠭ࠧḯ"),l1l1l1_l1_ (u"ࠧห็ࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠษ่ฯหา࠭Ḱ"))
	return True
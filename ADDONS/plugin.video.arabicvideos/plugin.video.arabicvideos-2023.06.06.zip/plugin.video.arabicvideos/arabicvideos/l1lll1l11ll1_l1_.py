# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ嚬")
#headers = {l1l1l1_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ嚭"):l1l1l1_l1_ (u"ࠧࠨ嚮")}
menu_name = l1l1l1_l1_ (u"ࠨࡡࡖࡌࡕࡥࠧ嚯")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ู่ࠩฬืูสࠩ嚰"),l1l1l1_l1_ (u"ࠪฬะࠦๅษษืีࠬ嚱")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l11l11_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l11l1ll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ嚲"),l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭嚳"),l1l1l1_l1_ (u"࠭ࠧ嚴"),l1l1l1_l1_ (u"ࠧࠨ嚵"),l1l1l1_l1_ (u"ࠨࠩ嚶"),l1l1l1_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭嚷"))
	html = response.content
	l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嚸"),html,re.DOTALL)
	l11l1l_l1_ = l11l1l_l1_[0].strip(l1l1l1_l1_ (u"ࠫ࠴࠭嚹"))
	l11l1l_l1_ = SERVER(l11l1l_l1_,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ嚺"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚻"),menu_name+l1l1l1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ嚼"),l11l1l_l1_,489,l1l1l1_l1_ (u"ࠨࠩ嚽"),l1l1l1_l1_ (u"ࠩࠪ嚾"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嚿"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ囀"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ囁"),l1l1l1_l1_ (u"࠭ࠧ囂"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囃"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ囄")+menu_name+l1l1l1_l1_ (u"ࠩฦัิัࠠศๆ่์ฬ฼ฺ๊ࠩ囅"),l11l1l_l1_,481)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯ࠢ࡮ࡻࡄࡧࡨࡵࡵ࡯ࡶࠥࠫ囆"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ囇"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l111ll_l1_==l1l1l1_l1_ (u"ࠬࠩࠧ囈"): continue
		if title in l1l1ll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囉"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ囊")+menu_name+title,l111ll_l1_,481)
	return html
def l11l11_l1_(url,l1l11ll1111l_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ囋"),url,l1l1l1_l1_ (u"ࠩࠪ囌"),l1l1l1_l1_ (u"ࠪࠫ囍"),l1l1l1_l1_ (u"ࠫࠬ囎"),l1l1l1_l1_ (u"ࠬ࠭囏"),l1l1l1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ囐"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡲࡷࡹ࠮࠮ࠫࡁࠬࠦ࡫ࡵ࡯ࡵࡧࡵࠦࠬ囑"),html,re.DOTALL)
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ囒"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ุ่ࠩฬํฯสࠩ囓"),l1l1l1_l1_ (u"ࠪๅ๏๊ๅࠨ囔"),l1l1l1_l1_ (u"ࠫฬเๆ๋หࠪ囕"),l1l1l1_l1_ (u"ࠬษฺ็์ฬࠫ囖"),l1l1l1_l1_ (u"࠭ใๅ์หࠫ囗"),l1l1l1_l1_ (u"ࠧศ฻็ห๋࠭囘"),l1l1l1_l1_ (u"ࠨ้าหๆ࠭囙"),l1l1l1_l1_ (u"่ࠩฬฬืวสࠩ囚"),l1l1l1_l1_ (u"ࠪ฽ึ฼ࠧ四"),l1l1l1_l1_ (u"๊ࠫํัอษ้ࠫ囜"),l1l1l1_l1_ (u"ࠬอไษ๊่ࠫ囝"),l1l1l1_l1_ (u"࠭ๅิำะ๎ฮ࠭回")]
	l1l11ll111l1_l1_ = l1l1l1_l1_ (u"ࠧ࠰ࠩ囟").join(l1l11ll1111l_l1_.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ因")).split(l1l1l1_l1_ (u"ࠩ࠲ࠫ囡"))[4:]).split(l1l1l1_l1_ (u"ࠪ࠱ࠬ团"))
	for l111ll_l1_,title,img in items:
		title = unescapeHTML(title)
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ団"),title,re.DOTALL)
		if l1l11ll1111l_l1_:
			l11111ll1_l1_ = l1l1l1_l1_ (u"ࠬ࠵ࠧ囤").join(l111ll_l1_.strip(l1l1l1_l1_ (u"࠭࠯ࠨ囥")).split(l1l1l1_l1_ (u"ࠧ࠰ࠩ囦"))[4:]).split(l1l1l1_l1_ (u"ࠨ࠯ࠪ囧"))
			l1l11ll111ll_l1_ = len([x for x in l1l11ll111l1_l1_ if x in l11111ll1_l1_])
			if l1l11ll111ll_l1_>2 and l1l1l1_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭囨") in l111ll_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ囩"),menu_name+title,l111ll_l1_,482,img)
		else:
			if not l1llll1_l1_: l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ囪"),title,re.DOTALL)
			#if any(value in title for value in l1111_l1_):
			if set(title.split()) & set(l1111_l1_) and l1l1l1_l1_ (u"๋ࠬำๅี็ࠫ囫") not in title:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ囬"),menu_name+title,l111ll_l1_,482,img)
			elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠧฮๆๅอࠬ园") in title:
				title = l1l1l1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ囮") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囯"),menu_name+title,l111ll_l1_,483,img,l1l1l1_l1_ (u"ࠪࠫ困"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囱"),menu_name+title,l111ll_l1_,483,img,l1l1l1_l1_ (u"ࠬ࠭囲"),url)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠤ図"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧ围"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"ࠨษ็ูๆำษࠡࠩ囵"),l1l1l1_l1_ (u"ࠩࠪ囶"))
			if title!=l1l1l1_l1_ (u"ࠪࠫ囷"): addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囸"),menu_name+l1l1l1_l1_ (u"ࠬ฻แฮหࠣࠫ囹")+title,l111ll_l1_,481,l1l1l1_l1_ (u"࠭ࠧ固"),l1l1l1_l1_ (u"ࠧࠨ囻"),l1l11ll1111l_l1_)
	return
def l11l1ll_l1_(url,url2):
	headers = {l1l1l1_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ囼"):l1l1l1_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ国")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ图"),url,l1l1l1_l1_ (u"ࠫࠬ囿"),headers,l1l1l1_l1_ (u"ࠬ࠭圀"),l1l1l1_l1_ (u"࠭ࠧ圁"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ圂"))
	html = response.content
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ圃"))
	img = re.findall(l1l1l1_l1_ (u"ࠩࠥ࡭ࡲ࡭࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圄"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫ圅"))
	l1l11ll11111_l1_ = True
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡲࡩࡴࡶࡖࡩࡦࡹ࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭圆"),html,re.DOTALL)
	# l111l1_l1_
	if l1ll11l_l1_ and l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬ圇") not in url:
		block = l1ll11l_l1_[0]
		count = block.count(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠪ圈"))
		if count==0: count = block.count(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂ࠭圉"))
		if count>1:
			l1l11ll11111_l1_ = False
			if l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠧ࠭圊") in block:
				items = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ國"),block,re.DOTALL)
				for id,title in items:
					l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠷࠴ࡰࡩࡲࡂࡷࡱࡻࡧ࠾ࠩ圌")+id
					addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ圍"),menu_name+title,l111ll_l1_,483,img)
			else:
				items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ圎"),block,re.DOTALL)
				for id,title in items:
					l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳ࠯ࡲ࡫ࡴࡄࡹࡥࡳ࡫ࡨࡷࡎࡊ࠽ࠨ圏")+id
					addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ圐"),menu_name+title,l111ll_l1_,483,img)
	# l1ll1_l1_
	if l1l11ll11111_l1_:
		block = l1l1l1_l1_ (u"ࠨࠩ圑")
		if l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴࠩ園") in url: block = html
		else:
			l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡪࡶ࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ圓"),html,re.DOTALL)
			if l1ll111_l1_: block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圔"),block,re.DOTALL)
		if items:
			for l111ll_l1_,title in items:
				title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧ圕"))
				addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ圖"),menu_name+title,l111ll_l1_,482,img)
	if not menuItemsLIST: l11l11_l1_(url2,url)
	return
def PLAY(url):
	url2 = url.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ圗"))+l1l1l1_l1_ (u"ࠨ࠱ࡂࡨࡴࡃࡷࡢࡶࡦ࡬ࠬ團")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭圙"),url2,l1l1l1_l1_ (u"ࠪࠫ圚"),l1l1l1_l1_ (u"ࠫࠬ圛"),l1l1l1_l1_ (u"ࠬ࠭圜"),l1l1l1_l1_ (u"࠭ࠧ圝"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ圞"))
	html = response.content
	l11l1_l1_ = []
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ土"))
	l1llll11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡹࡳࡤࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ圠"),html,re.DOTALL)
	if not l1llll11l1_l1_: l1llll11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡠ࠭ࡺࡨࡪࡵ࡟࠲࡮ࡪ࡜࠭࠲࡟࠰࠭࠴ࠪࡀࠫ࡟࠭ࠬ圡"),html,re.DOTALL)
	l1llll11l1_l1_ = l1llll11l1_l1_[0]
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ圢"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ圣"),block,re.DOTALL)
		for l1llll1ll1_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ圤"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡼ࡯࠳࠲࠵࠵࠴ࡺࡥ࡮ࡲ࠲ࡥ࡯ࡧࡸ࠰࡫ࡩࡶࡦࡳࡥ࠳࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪ圥")+l1llll11l1_l1_+l1l1l1_l1_ (u"ࠨࠨࡹ࡭ࡩ࡫࡯࠾ࠩ圦")+l1llll1ll1_l1_[2:]+l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ圧")+title+l1l1l1_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ在")
			l11l1_l1_.append(l111ll_l1_)
	# l11ll1l1l_l1_ l1l1111ll_l1_ l111ll_l1_
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧ࡭ࡥࡵࡇࡰࡦࡪࡪࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ圩"),html,re.DOTALL)
	if l111ll_l1_:
		title = SERVER(l111ll_l1_[0],l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ圪"))
		l111ll_l1_ = l111ll_l1_[0]+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ圫")+title+l1l1l1_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ圬")
		l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	url2 = url.strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ圭"))+l1l1l1_l1_ (u"ࠩ࠲ࡃࡩࡵ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࠩ圮")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ圯"),url2,l1l1l1_l1_ (u"ࠫࠬ地"),l1l1l1_l1_ (u"ࠬ࠭圱"),l1l1l1_l1_ (u"࠭ࠧ圲"),l1l1l1_l1_ (u"ࠧࠨ圳"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ圴"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡸࡦࡨ࡬ࡦ࠯ࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡺࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭圵"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ圶"),block,re.DOTALL)
		for title,l111ll_l1_ in items:
			title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭圷"))
			if l1l1l1_l1_ (u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭圸") in l111ll_l1_: title2 = l1l1l1_l1_ (u"࠭࡟ࡠะสูࠬ圹")
			else: title2 = l1l1l1_l1_ (u"ࠧࠨ场")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ圻")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭圼")+title2
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ圽"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ圾"),url)
	return
def SEARCH(search,l11l1l_l1_=l1l1l1_l1_ (u"ࠬ࠭圿")):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ址"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ坁"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ坂"),l1l1l1_l1_ (u"ࠩ࠮ࠫ坃"))
	if l11l1l_l1_==l1l1l1_l1_ (u"ࠪࠫ坄"): l11l1l_l1_ = l1l11l_l1_
	url = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭坅")+search+l1l1l1_l1_ (u"ࠬ࠵ࠧ坆")
	l11l11_l1_(url,l1l1l1_l1_ (u"࠭ࠧ均"))
	return
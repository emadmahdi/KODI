# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ㷸")
menu_name = l1l1l1_l1_ (u"ࠪࡣࡒ࠺ࡕࡠࠩ㷹")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠫฬ์่ศ฻ࠣหๆ๊วๆࠩ㷺"),l1l1l1_l1_ (u"ࠬา่ะษอࠤฬ็ไศ็ࠪ㷻")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l11l11_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l11l1ll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㷼"),menu_name+l1l1l1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ㷽"),l1l1l1_l1_ (u"ࠨࠩ㷾"),389,l1l1l1_l1_ (u"ࠩࠪ㷿"),l1l1l1_l1_ (u"ࠪࠫ㸀"),l1l1l1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㸁"))
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㸂"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㸃"),l1l1l1_l1_ (u"ࠧࠨ㸄"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㸅"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㸆")+menu_name+l1l1l1_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ㸇"),l1l11l_l1_,381,l1l1l1_l1_ (u"ࠫࠬ㸈"),l1l1l1_l1_ (u"ࠬ࠭㸉"),l1l1l1_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㸊"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㸋"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㸌")+menu_name+l1l1l1_l1_ (u"ࠩส่ัอๆษ์ฬࠫ㸍"),l1l11l_l1_,381,l1l1l1_l1_ (u"ࠪࠫ㸎"),l1l1l1_l1_ (u"ࠫࠬ㸏"),l1l1l1_l1_ (u"ࠬࡹࡩࡥࡧࡵࠫ㸐"))
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ㸑"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨ㸒"),l1l1l1_l1_ (u"ࠨࠩ㸓"),l1l1l1_l1_ (u"ࠩࠪ㸔"),l1l1l1_l1_ (u"ࠪࠫ㸕"),l1l1l1_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㸖"))
	html = response.content
	items = re.findall(l1l1l1_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㸗"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㸘"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㸙")+menu_name+title,l1l11l_l1_,381,l1l1l1_l1_ (u"ࠨࠩ㸚"),l1l1l1_l1_ (u"ࠩࠪ㸛"),l1l1l1_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ㸜")+str(seq))
	block = l1l1l1_l1_ (u"ࠫࠬ㸝")
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡪࡪ࡯ࡳࠤࠪ㸞"),html,re.DOTALL)
	if l1ll1l1_l1_: block += l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠨ࠯ࠬࡂ࠭ࡦࡹࡩࡥࡧࠪ㸟"),html,re.DOTALL)
	if l1ll1l1_l1_: block += l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㸠"),block,re.DOTALL)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㸡"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㸢"),l1l1l1_l1_ (u"ࠪࠫ㸣"),9999)
	first = True
	for l111ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l1l1_l1_ (u"ࠫฬ๊รฺๆ์ࠤฺ๊ว่ัฬࠫ㸤"):
			if first:
				title = l1l1l1_l1_ (u"ࠬอไศใ็ห๊ࠦࠧ㸥")+title
				first = False
			else: title = l1l1l1_l1_ (u"࠭วๅ็ึุ่๊วหࠢࠪ㸦")+title
		if title not in l1l1ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㸧"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㸨")+menu_name+title,l111ll_l1_,381)
	return html
def l11l11_l1_(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ㸩"),l1l1l1_l1_ (u"ࠪࠫ㸪"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ㸫"),url,l1l1l1_l1_ (u"ࠬ࠭㸬"),l1l1l1_l1_ (u"࠭ࠧ㸭"),l1l1l1_l1_ (u"ࠧࠨ㸮"),l1l1l1_l1_ (u"ࠨࠩ㸯"),l1l1l1_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭㸰"))
	html = response.content
	if type==l1l1l1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ㸱"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡡࡳࡥ࡫࠱ࡵࡧࡧࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ㸲"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㸳"),block,re.DOTALL)
	elif type==l1l1l1_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ㸴"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠫ㸵"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		z = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㸶"),block,re.DOTALL)
		l11l1_l1_,l1l1l1ll1_l1_,l1111ll_l1_ = zip(*z)
		items = zip(l1l1l1ll1_l1_,l11l1_l1_,l1111ll_l1_)
	elif type==l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㸷"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡵࡸࡶ࡬ࡴࡽࡳࠣࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ㸸"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㸹"),block,re.DOTALL)
	elif l1l1l1_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㸺") in type:
		seq = int(type[-1:])
		html = html.replace(l1l1l1_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾ࠨ㸻"),l1l1l1_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡳࡵࡣࡵࡸࡃ࠭㸼"))
		html = html.replace(l1l1l1_l1_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ㸽"),l1l1l1_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭㸾"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡸࡺࡡࡳࡶࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡲࡩࡄࠧ㸿"),html,re.DOTALL)
		block = l1ll1l1_l1_[seq]
		if seq==2: items = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㹀"),block,re.DOTALL)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠭ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡾࡶ࡭ࡩ࡫ࡢࡢࡴࠬࠫ㹁"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0][0]
			if l1l1l1_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ㹂") in url:
				items = re.findall(l1l1l1_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㹃"),block,re.DOTALL)
			elif l1l1l1_l1_ (u"ࠨ࠱ࡴࡹࡦࡲࡩࡵࡻ࠲ࠫ㹄") in url:
				items = re.findall(l1l1l1_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㹅"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㹆"),block,re.DOTALL)
	l1l1_l1_ = []
	for img,l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࠪ㹇") in title:
			title = re.findall(l1l1l1_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡨࡶ࡮࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㹈"),title,re.DOTALL)
			title = title[0][1]#+l1l1l1_l1_ (u"࠭ࠠ࠮ࠢࠪ㹉")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㹊")+title
		title2 = re.findall(l1l1l1_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽ࠩ㹋"),title,re.DOTALL)
		if title2: title = title2[0]
		title = unescapeHTML(title)
		if l1l1l1_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ㹌") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㹍"),menu_name+title,l111ll_l1_,383,img)
		elif l1l1l1_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㹎") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㹏"),menu_name+title,l111ll_l1_,383,img)
		elif l1l1l1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ㹐") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㹑"),menu_name+title,l111ll_l1_,383,img)
		elif l1l1l1_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ㹒") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㹓"),menu_name+title,l111ll_l1_,381,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㹔"),menu_name+title,l111ll_l1_,382,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡕࡧࡧࡦࠢࠫ࠲࠯ࡅࠩࠡࡱࡩࠤ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㹕"),html,re.DOTALL)
	if l1ll1l1_l1_:
		current = l1ll1l1_l1_[0][0]
		last = l1ll1l1_l1_[0][1]
		block = l1ll1l1_l1_[0][2]
		items = re.findall(l1l1l1_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ㹖"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title==l1l1l1_l1_ (u"࠭ࠧ㹗") or title==last: continue
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㹘"),menu_name+l1l1l1_l1_ (u"ࠨืไัฮࠦࠧ㹙")+title,l111ll_l1_,381,l1l1l1_l1_ (u"ࠩࠪ㹚"),l1l1l1_l1_ (u"ࠪࠫ㹛"),type)
		#if title==last:
		l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ㹜")+title+l1l1l1_l1_ (u"ࠬ࠵ࠧ㹝"),l1l1l1_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭㹞")+last+l1l1l1_l1_ (u"ࠧ࠰ࠩ㹟"))
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㹠"),menu_name+l1l1l1_l1_ (u"ࠩสาึࠦีโฯฬࠤࠬ㹡")+last,l111ll_l1_,381,l1l1l1_l1_ (u"ࠪࠫ㹢"),l1l1l1_l1_ (u"ࠫࠬ㹣"),type)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ㹤"),url,l1l1l1_l1_ (u"࠭ࠧ㹥"),l1l1l1_l1_ (u"ࠧࠨ㹦"),l1l1l1_l1_ (u"ࠨࠩ㹧"),l1l1l1_l1_ (u"ࠩࠪ㹨"),l1l1l1_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㹩"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㹪"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_,False):
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㹫"),menu_name+l1l1l1_l1_ (u"࠭วๅ็ึุ่๊ࠠๅๆๆฬฬื้ࠠษ็้อืๅอ่๊ࠢ฾ํࠧ㹬"),l1l1l1_l1_ (u"ࠧࠨ㹭"),9999)
		return
	if l1l1l1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ㹮") in url or l1l1l1_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ㹯") in url:
		url2 = re.findall(l1l1l1_l1_ (u"ࠪࠫࠬࡩ࡬ࡢࡵࡶࡁࠬ࡯ࡴࡦ࡯ࠪࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ㹰"),html,re.DOTALL)
		if url2:
			url2 = url2[1]
			l11l1ll_l1_(url2)
			return
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡥࡱ࡫ࡶࡳࡩ࡯࡯ࡴࠩࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡨࡧࡳࡵࠤࠪࠫࠬ㹱"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠧ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠬ࠭ࠧ㹲"),block,re.DOTALL)
		for img,l1llll1_l1_,l111ll_l1_,name in items:
			title = l1llll1_l1_+l1l1l1_l1_ (u"࠭ࠠ࠻ࠢࠪ㹳")+name+l1l1l1_l1_ (u"ࠧࠡษ็ั้่ษࠨ㹴")
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㹵"),menu_name+title,l111ll_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭㹶"),url,l1l1l1_l1_ (u"ࠪࠫ㹷"),l1l1l1_l1_ (u"ࠫࠬ㹸"),l1l1l1_l1_ (u"ࠬ࠭㹹"),l1l1l1_l1_ (u"࠭ࠧ㹺"),l1l1l1_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㹻"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㹼"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	l11l1_l1_ = []
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠤࠥࠦ࡮ࡪ࠽ࠨࡲ࡯ࡥࡾ࡫ࡲ࠮ࡱࡳࡸ࡮ࡵ࡮࠮࠳ࠪࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠩࠤࡶ࡬ࡪࡧࡤࡦࡴࠥࢀࠬࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࠮ࠨࠢࠣ㹽"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0][0]
		items = re.findall(l1l1l1_l1_ (u"ࠥࡨࡦࡺࡡ࠮ࡷࡵࡰࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡵࡨࡶࡻ࡫ࡲࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ㹾"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㹿")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㺀")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸࡥ࡮ࡱࡧࡥࡱ࠳ࡣ࡭ࡱࡶࡩࠧ࠭㺁"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡠࡡࡢࡨࡱࡥࡧࡥࡴ࡬ࡺࡪ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㺂"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㺃")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㺄")
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ㺅"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㺆"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠬ࠭㺇"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"࠭ࠧ㺈"): return
	search = search.replace(l1l1l1_l1_ (u"ࠧࠡࠩ㺉"),l1l1l1_l1_ (u"ࠨ࠭ࠪ㺊"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ㺋")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ㺌"))
	return
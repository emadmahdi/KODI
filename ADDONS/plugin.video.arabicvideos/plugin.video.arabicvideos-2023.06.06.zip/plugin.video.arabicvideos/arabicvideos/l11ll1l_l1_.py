# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
headers = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ") : l1l1l1_l1_ (u"ࠨࠩଛ") }
script_name = l1l1l1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨଜ")
menu_name = l1l1l1_l1_ (u"ࠪࡣࡆࡑࡗࡠࠩଝ")
l1l11l_l1_ = WEBSITES[script_name][0]
#l11l111_l1_ = [l1l1l1_l1_ (u"ࠫๆ๐ไๆࠩଞ"),l1l1l1_l1_ (u"้ࠬไ๋สࠪଟ"),l1l1l1_l1_ (u"࠭วๅ฻ิฺࠥอไศีห์฾๐ࠧଠ"),l1l1l1_l1_ (u"ࠧๆีิั๏ฯࠧଡ"),l1l1l1_l1_ (u"ࠨ็ึีา๐็ࠨଢ"),l1l1l1_l1_ (u"ࠩส฾๋๐ษࠨଣ"),l1l1l1_l1_ (u"ࠪห฾๊ว็ࠩତ"),l1l1l1_l1_ (u"้่ࠫวยࠩଥ")]
#proxy = l1l1l1_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷࠵࠺࠰࠵࠴࠸࠴࠸࠸࠰࠴࠷࠵ࡀ࠳࠲࠴࠻ࠫଦ")
#proxy = l1l1l1_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ଧ")+l1l11111_l1_[6][1]
proxy = l1l1l1_l1_ (u"ࠧࠨନ")
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠨล็฽ฬฮࠧ଩"),l1l1l1_l1_ (u"ࠩส่๊฻วา฻ฬࠤฬ๊อาหࠪପ"),l1l1l1_l1_ (u"ࠪห้่ัศ่ࠣห้้ั๋็ࠪଫ"),l1l1l1_l1_ (u"ࠫฬ๊ใหสࠣ์ࠥอไศสะหะ࠭ବ"),l1l1l1_l1_ (u"ࠬอไึ๊ิࠤํࠦวๅะ็ๅ๏อสࠨଭ"),l1l1l1_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่ฬึวฺ์ฬࠫମ")]
def MAIN(mode,url,text):
	if   mode==240: results = MENU()
	elif mode==241: results = l11l11_l1_(url,text)
	elif mode==242: results = l11l1ll_l1_(url)
	elif mode==243: results = PLAY(url)
	elif mode==244: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫଯ")+text)
	elif mode==245: results = l1111l1_l1_(url,l1l1l1_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨର")+text)
	elif mode==246: results = l1lll11l_l1_(url)
	elif mode==247: results = l11lllll_l1_(url)
	elif mode==248: results = l11ll1l1_l1_()
	elif mode==249: results = SEARCH(text)
	else: results = False
	return results
def l11ll1l1_l1_():
	DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ଱"),l1l1l1_l1_ (u"ࠪࠫଲ"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧଳ"),l1l1l1_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢࠥว่๎วๆࠢส่ัี๊ะࠤࠣๅ๏ࠦศฺุࠣห้ษอ๋ษ้ࠤๆ๐็่๋ࠡ฽๋ࠥๆࠡษ็ััฮࠠืัࠣห้ฮัศ็ฯࠤ࠳่่ࠦาสࠤ๏ูศษุ่่๊ࠢษࠡใํࠤฯฺฺ๋ๆࠣห้็๊ะ์๋๋ฬะࠠ࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠิสห๋ฬࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋๋๋ࠢ๏ࠦสู้ิࠤํะฮหใํࠤอ฻่าหࠣ฽ู๎วว์ฬࠫ଴"))
	return
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪଵ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨଶ"),headers,l1l1l1_l1_ (u"ࠨࠩଷ"),l1l1l1_l1_ (u"ࠩࠪସ"),l1l1l1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫହ"))
	html = response.content
	l11lll11_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡵ࡭ࡦ࠯ࡶ࡭ࡹ࡫࠭ࡣࡶࡱ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ଺"),html,re.DOTALL)
	if l11lll11_l1_: l11lll11_l1_ = l11lll11_l1_[0]
	else: l11lll11_l1_ = l1l11l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ଻"),l11lll11_l1_,l1l1l1_l1_ (u"଼࠭ࠧ"),headers,l1l1l1_l1_ (u"ࠧࠨଽ"),l1l1l1_l1_ (u"ࠨࠩା"),l1l1l1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪି"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪୀ"),menu_name+l1l1l1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫୁ"),l1l1l1_l1_ (u"ࠬ࠭ୂ"),249,l1l1l1_l1_ (u"࠭ࠧୃ"),l1l1l1_l1_ (u"ࠧࠨୄ"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ୅"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୆"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭େ"),l1l11l_l1_,246)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫୈ"),menu_name+l1l1l1_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ୉"),l1l11l_l1_,247)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ୊"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧୋ"),l1l1l1_l1_ (u"ࠨࠩୌ"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ୍ࠩ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ୎")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ୏"),l11lll11_l1_,241,l1l1l1_l1_ (u"ࠬ࠭୐"),l1l1l1_l1_ (u"࠭ࠧ୑"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ୒"))
	l11l1lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡴࡨࡧࡪࡴࡴ࡭ࡻ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୓"),html,re.DOTALL)
	l111ll_l1_ = l11l1lll_l1_[0]
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୔"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ୕")+menu_name+l1l1l1_l1_ (u"ࠫศ฼๊โࠢะำ๏ัวࠨୖ"),l111ll_l1_,241)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪୗ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୘"),l1l1l1_l1_ (u"ࠧࠨ୙"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡯ࡥ࠱࠹ࠦࡤ࠮ࡨ࡯ࡩࡽࠦࡡ࡭࡫ࡪࡲ࠲࡯ࡴࡦ࡯ࡶ࠱ࡨ࡫࡮ࡵࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨࡪࡸ࠭࡭࡫ࡱ࡯ࠥࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ୚"),html,re.DOTALL)
	for l111ll_l1_,name,block in l1ll1l1_l1_:
		if name in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୛"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬଡ଼")+menu_name+name,l111ll_l1_,241)
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪଢ଼"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title in l1l1ll_l1_: continue
			title = name+l1l1l1_l1_ (u"ࠬࠦࠧ୞")+title
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ୟ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩୠ")+menu_name+title,l111ll_l1_,241)
	return
def l1lll11l_l1_(website=l1l1l1_l1_ (u"ࠨࠩୡ")):
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪୢ"),headers,l1l1l1_l1_ (u"ࠪࠫୣ"),l1l1l1_l1_ (u"ࠫࡆࡑࡗࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ୤"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽ࡰࡤࡺࠬ୥"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭୦"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title not in l1l1ll_l1_:
				title = title+l1l1l1_l1_ (u"ࠧࠡ็ุ๊ๆฯࠧ୧")
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୨"),menu_name+title,l111ll_l1_,245)
		if website==l1l1l1_l1_ (u"ࠩࠪ୩"): addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ୪"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ୫"),l1l1l1_l1_ (u"ࠬ࠭୬"),9999)
	return html
def l11lllll_l1_(website=l1l1l1_l1_ (u"࠭ࠧ୭")):
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨ୮"),headers,l1l1l1_l1_ (u"ࠨࠩ୯"),l1l1l1_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ୰"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࡮ࡢࡸࠪୱ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ୲"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title not in l1l1ll_l1_:
				title = title+l1l1l1_l1_ (u"ࠬࠦๅโๆอีฮ࠭୳")
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭୴"),menu_name+title,l111ll_l1_,244)
		if website==l1l1l1_l1_ (u"ࠧࠨ୵"): addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭୶"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ୷"),l1l1l1_l1_ (u"ࠪࠫ୸"),9999)
	return html
def l11l11_l1_(url,type=l1l1l1_l1_ (u"ࠫࠬ୹")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭୺"),l1l1l1_l1_ (u"࠭ࠧ୻"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨ୼"),headers,True,l1l1l1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ୽"))
	if type==l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ୾"): l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡷࡼ࡯ࡰࡦࡴ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡷࡼ࡯ࡰࡦࡴ࠰ࡦࡺࡺࡴࡰࡰ࠰ࡴࡷ࡫ࡶࠨ୿"),html,re.DOTALL)
	else: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡧࡱࡲࡸࡪࡸࠧ஀"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ஁"),block,re.DOTALL)
		if not items:
			items = re.findall(l1l1l1_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬஂ"),block,re.DOTALL)
		for img,l111ll_l1_,title in items:
			#if l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩஃ") in img: img = img.split(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦࠬ஄"))[1]
			if l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫஅ") in l111ll_l1_ or l1l1l1_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡸࡵ࠲ࠫஆ") in l111ll_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫஇ"),menu_name+title,l111ll_l1_,242,img)
			elif l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧஈ") in l111ll_l1_:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬஉ"),menu_name+title,l111ll_l1_,243,img)
			elif l1l1l1_l1_ (u"ࠧ࠰ࡩࡤࡱࡪࡹ࠯ࠨஊ") not in l111ll_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ஋"),menu_name+title,l111ll_l1_,243,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ஌"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ஍"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title==l1l1l1_l1_ (u"ࠫࠫࡲࡳࡢࡳࡸࡳࡀ࠭எ"): title = l1l1l1_l1_ (u"ูࠬวษไฬࠫஏ")
			if title==l1l1l1_l1_ (u"࠭ࠦࡳࡵࡤࡵࡺࡵ࠻ࠨஐ"): title = l1l1l1_l1_ (u"ࠧๅษะๆฮ࠭஑")
			l111ll_l1_ = unescapeHTML(l111ll_l1_)
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨஒ"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨஓ")+title,l111ll_l1_,241)
	return
def SEARCH(search):
	# l1ll1lll_l1_://l1l1111l_l1_.l1ll1l11_l1_/search?q=%l1l111l1_l1_%l1ll1l1l_l1_%l1l111l1_l1_%l1llll11_l1_%l1l111l1_l1_%l1ll111l_l1_
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠪࠫஔ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠫࠬக"): return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠬࠦࠧ஖"),l1l1l1_l1_ (u"࠭ࠥ࠳࠲ࠪ஗"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ஘")+l11ll11_l1_
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩங"),l1l1l1_l1_ (u"ࠩࠪச"),url,l1l1l1_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࡢࡅࡐࡕࡁࡎࠩ஛"))
	results = l11l11_l1_(url)
	return
def l11l1ll_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬஜ"),l1l1l1_l1_ (u"ࠬ࠭஝"),url,l1l1l1_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࡠࡃࡎ࡛ࡆࡓࠧஞ"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨட"),headers,True,l1l1l1_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭஠"))
	if l1l1l1_l1_ (u"ࠩ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡄࠧ஡") not in html:
		img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡏࡣࡰࡰࠪ஢"))
		addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪண"),menu_name+l1l1l1_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫத"),url,243,img)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࡁࠬ࠳࠰࠿ࠪ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠳࠴ࠨ஥"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭஦"),block,re.DOTALL)
		for l111ll_l1_,title,img in l1ll1_l1_:
			#if l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ஧") in l111ll_l1_: continue
			if l1l1l1_l1_ (u"ࠩส่า๊โศฬࠪந") in title or l1l1l1_l1_ (u"้ࠪํอำๆࠢสาึ๏ࠧன") in title: continue
			if l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭ப") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ஫"),menu_name+title,l111ll_l1_,242,img)
			else: addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ஬"),menu_name+title,l111ll_l1_,243,img)
	return
def PLAY(url):
	#l11ll1l1_l1_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#open(l1l1l1_l1_ (u"ࠧࡔ࠼࡟ࡠࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ஭"), l1l1l1_l1_ (u"ࠨࡹࠪம")).write(html)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠩࠪய"),headers,True,l1l1l1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫர"))
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡧࡧࡤࡨࡧ࠰ࡨࡦࡴࡧࡦࡴ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ற"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	l11ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧல"),html,re.DOTALL)
	#l11ll1ll_l1_ = ([l1l1l1_l1_ (u"࠭ࠧள"),l1l1l1_l1_ (u"ࠧࠨழ")],[l1l1l1_l1_ (u"ࠨࠩவ"),l1l1l1_l1_ (u"ࠩࠪஶ")])
	l11l1_l1_,l1111ll_l1_,l1l11l1_l1_,l11llll1_l1_ = [],[],[],[]
	if l11ll1ll_l1_:
		l11llll_l1_ = l1l1l1_l1_ (u"ࠪࡱࡵ࠺ࠧஷ")
		for l11lll1l_l1_,l11ll111_l1_ in l11ll1ll_l1_:
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠢࡴࡹࡦࡲࡩࡵࡻࠥࠤ࡮ࡪ࠽ࠣࠩஸ")+l11lll1l_l1_+l1l1l1_l1_ (u"ࠬࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿࠰࡟ࡷ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬஹ"),html,re.DOTALL)
			block = l1ll1l1_l1_[0]
			l1l11l1_l1_.append(block)
			l11llll1_l1_.append(l11ll111_l1_)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡱࡶࡣ࡯࡭ࡹ࡯ࡥࡴࠪ࠱࠮ࡄ࠯࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭஺"),html,re.DOTALL)
		if not l1ll1l1_l1_:
			DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ஻"),l1l1l1_l1_ (u"ࠨࠩ஼"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ஽"),l1l1l1_l1_ (u"่ࠪฬ๊้ࠦฮาࠤ๊๊แࠡใํำ๏๎ࠠโ์๋ࠣีอࠠศๆิหอ฽ࠧா"))
			return
		else:
			block,filename = l1ll1l1_l1_[0]
			l111lll_l1_ = [l1l1l1_l1_ (u"ࠫࡿ࡯ࡰࠨி"),l1l1l1_l1_ (u"ࠬࡸࡡࡳࠩீ"),l1l1l1_l1_ (u"࠭ࡴࡹࡶࠪு"),l1l1l1_l1_ (u"ࠧࡱࡦࡩࠫூ"),l1l1l1_l1_ (u"ࠨࡪࡷࡱࠬ௃"),l1l1l1_l1_ (u"ࠩࡷࡥࡷ࠭௄"),l1l1l1_l1_ (u"ࠪ࡭ࡸࡵࠧ௅"),l1l1l1_l1_ (u"ࠫ࡭ࡺ࡭࡭ࠩெ")]
			l11llll_l1_ = filename.rsplit(l1l1l1_l1_ (u"ࠬ࠴ࠧே"),1)[1].strip(l1l1l1_l1_ (u"࠭ࠠࠨை"))
			if l11llll_l1_ in l111lll_l1_:
				DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ௉"),l1l1l1_l1_ (u"ࠨࠩொ"),l1l1l1_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬோ"),l1l1l1_l1_ (u"ࠪห้๋ไโࠢ็๎ุࠦแ๋ัํ์ࠥ๎ไศุࠢ์ฯ࠭ௌ"))
				return
		l1l11l1_l1_.append(block)
		l11llll1_l1_.append(l1l1l1_l1_ (u"்ࠫࠬ"))
	for i in range(len(l1l11l1_l1_)):
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩࡤࡱࡱ࠱࠭࠴ࠪࡀࠫࠥࠫ௎"),l1l11l1_l1_[i],re.DOTALL)
		for l111ll_l1_,l11ll11l_l1_ in l1ll_l1_:
			if l1l1l1_l1_ (u"࠭ࡴࡰࡴࡵࡩࡳࡺࠧ௏") in l11ll11l_l1_: continue
			#elif l1l1l1_l1_ (u"ࠧࡱ࡮ࡤࡽࠬௐ") in l11ll11l_l1_: continue
			elif l1l1l1_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ௑") in l11ll11l_l1_: type = l1l1l1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௒")
			elif l1l1l1_l1_ (u"ࠪࡴࡱࡧࡹࠨ௓") in l11ll11l_l1_: type = l1l1l1_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ௔")
			else: type = l1l1l1_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭௕")
			#title = l11llll1_l1_[i]+l1l1l1_l1_ (u"࠭ࠠๆๆไࠤࠬ௖")+type
			#l1111ll_l1_.append(title)
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࠪௗ")+type+l1l1l1_l1_ (u"ࠨࡡࡢࡣࡤ࠭௘")+l11llll1_l1_[i]+l1l1l1_l1_ (u"ࠩࡢࡣࡦࡱࡷࡢ࡯ࠪ௙")
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ௚"),l1111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࡙ࠫࡋࡓࡕࠩ௛"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ௜"),url)
	return
def l1111l1_l1_(url,filter):
	#filter = filter.replace(l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ௝"),l1l1l1_l1_ (u"ࠧࠨ௞"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ௟"),l1l1l1_l1_ (u"ࠩࠪ௠"),filter,url)
	l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࠫ௡"),l1l1l1_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭௢"),l1l1l1_l1_ (u"ࠬࡿࡥࡢࡴࠪ௣"),l1l1l1_l1_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭௤")]
	if l1l1l1_l1_ (u"ࠧࡀࠩ௥") in url: url = url.split(l1l1l1_l1_ (u"ࠨࡁࠪ௦"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"ࠩࡢࡣࡤ࠭௧"),1)
	if filter==l1l1l1_l1_ (u"ࠪࠫ௨"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠫࠬ௩"),l1l1l1_l1_ (u"ࠬ࠭௪")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪ௫"))
	if type==l1l1l1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ௬"):
		if l1l1lll1_l1_[0]+l1l1l1_l1_ (u"ࠨ࠿ࠪ௭") not in l1l1ll11_l1_: category = l1l1lll1_l1_[0]
		for i in range(len(l1l1lll1_l1_[0:-1])):
			if l1l1lll1_l1_[i]+l1l1l1_l1_ (u"ࠩࡀࠫ௮") in l1l1ll11_l1_: category = l1l1lll1_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠪࠪࠬ௯")+category+l1l1l1_l1_ (u"ࠫࡂ࠶ࠧ௰")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠬࠬࠧ௱")+category+l1l1l1_l1_ (u"࠭࠽࠱ࠩ௲")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"ࠧࠧࠩ௳"))+l1l1l1_l1_ (u"ࠨࡡࡢࡣࠬ௴")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠩࠩࠫ௵"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠪࡥࡱࡲࠧ௶"))
		url2 = url+l1l1l1_l1_ (u"ࠫࡄ࠭௷")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭௸"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ௹"))
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"ࠧࠨ௺"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠨࡣ࡯ࡰࠬ௻"))
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠩࠪ௼"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠪࡃࠬ௽")+l1l1l1ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ௾"),menu_name+l1l1l1_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠧ௿"),url2,241,l1l1l1_l1_ (u"࠭ࠧఀ"),l1l1l1_l1_ (u"ࠧ࠲ࠩఁ"))
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨం"),menu_name+l1l1l1_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩః")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩఄ"),url2,241,l1l1l1_l1_ (u"ࠫࠬఅ"),l1l1l1_l1_ (u"ࠬ࠷ࠧఆ"))
		addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫఇ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧఈ"),l1l1l1_l1_ (u"ࠨࠩఉ"),9999)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠩࠪఊ"),headers,True,l1l1l1_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬఋ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁ࡬࡯ࡳ࡯ࠣ࡭ࡩ࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫఌ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠴ࠪࡀࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡲࡥࡤࡶࡁࠫ఍"),block,re.DOTALL)
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧఎ"),l1l1l1_l1_ (u"ࠧࠨఏ"),l1l1l1_l1_ (u"ࠨࠩఐ"),str(l11111l_l1_))
	dict = {}
	for l1llllll_l1_,name,block in l11111l_l1_:
		#name = name.replace(l1l1l1_l1_ (u"ࠩ࠰࠱ࠬ఑"),l1l1l1_l1_ (u"ࠪࠫఒ"))
		items = re.findall(l1l1l1_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡁࠬ࠳࠰࠿ࠪ࠾ࠪఓ"),block,re.DOTALL)
		if l1l1l1_l1_ (u"ࠬࡃࠧఔ") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪక"):
			if category!=l1llllll_l1_: continue
			elif len(items)<=1:
				if l1llllll_l1_==l1l1lll1_l1_[-1]: l11l11_l1_(url2)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧఖ")+l1ll1111_l1_)
				return
			else:
				if l1llllll_l1_==l1l1lll1_l1_[-1]: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨగ"),menu_name+l1l1l1_l1_ (u"ࠩส่ัฺ๋๊ࠩఘ"),url2,241,l1l1l1_l1_ (u"ࠪࠫఙ"),l1l1l1_l1_ (u"ࠫ࠶࠭చ"))
				else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬఛ"),menu_name+l1l1l1_l1_ (u"࠭วๅฮ่๎฾࠭జ"),url2,245,l1l1l1_l1_ (u"ࠧࠨఝ"),l1l1l1_l1_ (u"ࠨࠩఞ"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪట"):
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠪࠪࠬఠ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠫࡂ࠶ࠧడ")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠬࠬࠧఢ")+l1llllll_l1_+l1l1l1_l1_ (u"࠭࠽࠱ࠩణ")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫత")+l1ll1ll1_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨథ"),menu_name+l1l1l1_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠤࠬద")+name,url2,244,l1l1l1_l1_ (u"ࠪࠫధ"),l1l1l1_l1_ (u"ࠫࠬన"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ఩"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			if option in l1l1ll_l1_: continue
			if l1l1l1_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬప") not in value: value = option
			else: value = re.findall(l1l1l1_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨఫ"),value,re.DOTALL)[0]
			dict[l1llllll_l1_][value] = option
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠨࠨࠪబ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠩࡀࠫభ")+option
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠪࠪࠬమ")+l1llllll_l1_+l1l1l1_l1_ (u"ࠫࡂ࠭య")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࠩర")+l1ll1ll1_l1_
			title = option+l1l1l1_l1_ (u"࠭ࠠ࠻ࠢࠪఱ")#+dict[l1llllll_l1_][l1l1l1_l1_ (u"ࠧ࠱ࠩల")]
			title = option+l1l1l1_l1_ (u"ࠨࠢ࠽ࠤࠬళ")+name
			if type==l1l1l1_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪఴ"): addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪవ"),menu_name+title,url,244,l1l1l1_l1_ (u"ࠫࠬశ"),l1l1l1_l1_ (u"ࠬ࠭ష"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨస"))
			elif type==l1l1l1_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫహ") and l1l1lll1_l1_[-2]+l1l1l1_l1_ (u"ࠨ࠿ࠪ఺") in l1l1ll11_l1_:
				l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠩࡤࡰࡱ࠭఻"))
				url3 = url+l1l1l1_l1_ (u"ࠪࡃ఼ࠬ")+l1l1l111_l1_
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫఽ"),menu_name+title,url3,241,l1l1l1_l1_ (u"ࠬ࠭ా"),l1l1l1_l1_ (u"࠭࠱ࠨి"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧీ"),menu_name+title,url,245,l1l1l1_l1_ (u"ࠨࠩు"),l1l1l1_l1_ (u"ࠩࠪూ"),l1lllll1_l1_)
	return
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫృ"),l1l1l1_l1_ (u"ࠫࠬౄ"),filters,l1l1l1_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭౅"))
	# mode==l1l1l1_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨె")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪే")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"ࠨࡣ࡯ࡰࠬై")					all filters (l1l11ll1_l1_ l1ll11ll_l1_ filter)
	#filters = filters.replace(l1l1l1_l1_ (u"ࠩࡀࠪࠬ౉"),l1l1l1_l1_ (u"ࠪࡁ࠵ࠬࠧొ"))
	filters = filters.strip(l1l1l1_l1_ (u"ࠫࠫ࠭ో"))
	l1l1ll1l_l1_ = {}
	if l1l1l1_l1_ (u"ࠬࡃࠧౌ") in filters:
		items = filters.split(l1l1l1_l1_ (u"࠭ࠦࠨ్"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠧ࠾ࠩ౎"))
			l1l1ll1l_l1_[var] = value
	l1llll1l_l1_ = l1l1l1_l1_ (u"ࠨࠩ౏")
	l1lll1ll_l1_ = [l1l1l1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࠪ౐"),l1l1l1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ౑"),l1l1l1_l1_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ౒"),l1l1l1_l1_ (u"ࠬࡿࡥࡢࡴࠪ౓"),l1l1l1_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ౔"),l1l1l1_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨౕ"),l1l1l1_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺౖࠩ")]
	for key in l1lll1ll_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠩ࠳ࠫ౗")
		#if l1l1l1_l1_ (u"ࠪࠩࠬౘ") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ౙ") and value!=l1l1l1_l1_ (u"ࠬ࠶ࠧౚ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"࠭ࠠࠬࠢࠪ౛")+value
		elif mode==l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ౜") and value!=l1l1l1_l1_ (u"ࠨ࠲ࠪౝ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠩࠩࠫ౞")+key+l1l1l1_l1_ (u"ࠪࡁࠬ౟")+value
		elif mode==l1l1l1_l1_ (u"ࠫࡦࡲ࡬ࠨౠ"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠬࠬࠧౡ")+key+l1l1l1_l1_ (u"࠭࠽ࠨౢ")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠧࠡ࠭ࠣࠫౣ"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠨࠨࠪ౤"))
	#l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"ࠩࡀ࠴ࠬ౥"),l1l1l1_l1_ (u"ࠪࡁࠬ౦"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ౧"),l1l1l1_l1_ (u"ࠬ࠭౨"),filters,l1l1l1_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧ౩"))
	return l1llll1l_l1_
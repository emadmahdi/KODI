# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭ᡚ")
menu_name = l1l1l1_l1_ (u"ࠬࡥࡃࡎࡅࡢࠫᡛ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"࠭ๅ้ไ฼ࠤ๋ะแๅ์ๆืࠬᡜ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l11l11_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l11l1ll_l1_(url)
	elif mode==494: results = l1ll11_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫᡝ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩᡞ"),l1l1l1_l1_ (u"ࠩࠪᡟ"),l1l1l1_l1_ (u"ࠪࠫᡠ"),l1l1l1_l1_ (u"ࠫࠬᡡ"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᡢ"))
	html = response.content
	l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᡣ"),html,re.DOTALL)
	l11l1l_l1_ = l11l1l_l1_[0].strip(l1l1l1_l1_ (u"ࠧ࠰ࠩᡤ"))
	l11l1l_l1_ = SERVER(l11l1l_l1_,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬᡥ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᡦ"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᡧ"),l11l1l_l1_,499,l1l1l1_l1_ (u"ࠫࠬᡨ"),l1l1l1_l1_ (u"ࠬ࠭ᡩ"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᡪ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡫ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᡬ")+menu_name+l1l1l1_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨᡭ"),l11l1l_l1_,491,l1l1l1_l1_ (u"ࠪࠫᡮ"),l1l1l1_l1_ (u"ࠫࠬᡯ"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᡰ"))
	#addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᡱ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᡲ"),l1l1l1_l1_ (u"ࠨࠩᡳ"),9999)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡪ࡮ࡲࡴࡦࡴࠣࡅ࡯ࡧࡸࡪࡨࡼࡊ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᡴ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡨ࡬ࡰࡹ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᡵ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title in l1l1ll_l1_: continue
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡲࡰࡩ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧᡶ")+l111ll_l1_+l1l1l1_l1_ (u"ࠬ࠴ࡰࡩࡲࠪᡷ")
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᡸ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᡹")+menu_name+title,l111ll_l1_,491)
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᡺"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᡻"),l1l1l1_l1_ (u"ࠪࠫ᡼"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᡽"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᡾")+menu_name+l1l1l1_l1_ (u"࠭รโๆส้ࠬ᡿"),l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หๆ๊วๆ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡩ࡭ࡱࡳࡥ࠰ࡨࡲࡶࡪ࡯ࡧ࡯࠯࡫ࡨ࠲อแๅษ่࠱ฬาๆษ๋࠰࠶ࠬᢀ"),494,l1l1l1_l1_ (u"ࠨࠩᢁ"),l1l1l1_l1_ (u"ࠩࠪᢂ"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᢃ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢄ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᢅ")+menu_name+l1l1l1_l1_ (u"࠭ๅิๆึ่ฬะࠧᢆ"),l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ุ้๊ำๅษอ࠳ู๊ไิๆสฮ࠲อฬ็ส์ࠫᢇ"),494,l1l1l1_l1_ (u"ࠨࠩᢈ"),l1l1l1_l1_ (u"ࠩࠪᢉ"),l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᢊ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᢋ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᢌ"),l1l1l1_l1_ (u"࠭ࠧᢍ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᢎ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᢏ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l111ll_l1_==l1l1l1_l1_ (u"ࠩ࠲ࠫᢐ"): continue
		if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᢑ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l111ll_l1_
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢒ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᢓ")+menu_name+title,l111ll_l1_,491)
	return html
def l1ll11_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧᢔ"),l1l1l1_l1_ (u"ࠧࠨᢕ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬᢖ"),url,l1l1l1_l1_ (u"ࠩࠪᢗ"),l1l1l1_l1_ (u"ࠪࠫᢘ"),l1l1l1_l1_ (u"ࠫࠬᢙ"),l1l1l1_l1_ (u"ࠬ࠭ᢚ"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᢛ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᢜ"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᢝ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if title in l1l1ll_l1_: continue
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᢞ"),menu_name+title,l111ll_l1_,491)
	return
def l11l11_l1_(url,l111l1111_l1_=l1l1l1_l1_ (u"ࠪࠫᢟ")):
	items = []
	#l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨᢠ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᢡ"),url,l1l1l1_l1_ (u"࠭ࠧᢢ"),l1l1l1_l1_ (u"ࠧࠨᢣ"),l1l1l1_l1_ (u"ࠨࠩᢤ"),l1l1l1_l1_ (u"ࠩࠪᢥ"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᢦ"))
	html = response.content
	block = l1l1l1_l1_ (u"ࠫࠬᢧ")
	if l1l1l1_l1_ (u"ࠬ࠴ࡰࡩࡲࠪᢨ") in url: block = html
	elif l1l1l1_l1_ (u"࠭࠿ࡴ࠿ᢩࠪ") in url:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡤ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࠨ࡭ࡢࡰ࡬ࡪࡪࡹࡴࠣࠩᢪ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᢫"),block,re.DOTALL)
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࠣ࡯ࡤࡲ࡮࡬ࡥࡴࡶࠥࠫ᢬"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
	if not block: return
	#if not items: items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࡟࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࠨࡢࡰࡺࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ᢭"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ฺ๊ࠫว่ัฬࠫ᢮"),l1l1l1_l1_ (u"ࠬ็๊ๅ็ࠪ᢯"),l1l1l1_l1_ (u"࠭ว฻่ํอࠬᢰ"),l1l1l1_l1_ (u"ࠧฤ฼้๎ฮ࠭ᢱ"),l1l1l1_l1_ (u"ࠨๅ็๎อ࠭ᢲ"),l1l1l1_l1_ (u"ࠩส฽้อๆࠨᢳ"),l1l1l1_l1_ (u"๋ࠪิอแࠨᢴ"),l1l1l1_l1_ (u"๊ࠫฮวาษฬࠫᢵ"),l1l1l1_l1_ (u"ࠬ฿ัืࠩᢶ"),l1l1l1_l1_ (u"࠭ๅ่ำฯห๋࠭ᢷ"),l1l1l1_l1_ (u"ࠧศๆห์๊࠭ᢸ"),l1l1l1_l1_ (u"ࠨ็ึีา๐ษࠨᢹ")]
	for l111ll_l1_,img,title in items:
		title = unescapeHTML(title)
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪᢺ"),title,re.DOTALL)
		if not l1llll1_l1_: l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᢻ"),title,re.DOTALL)
		if not l1llll1_l1_ or any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᢼ"),menu_name+title,l111ll_l1_,492,img)
		elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠬำไใหࠪᢽ") in title:
			title = l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᢾ") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢿ"),menu_name+title,l111ll_l1_,493,img)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣀ"),menu_name+title,l111ll_l1_,493,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᣁ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᣂ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬᣃ"),l1l1l1_l1_ (u"ࠬ࠭ᣄ"))
			if title!=l1l1l1_l1_ (u"࠭ࠧᣅ"): addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᣆ"),menu_name+l1l1l1_l1_ (u"ࠨืไัฮࠦࠧᣇ")+title,l111ll_l1_,491)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ᣈ"),url,l1l1l1_l1_ (u"ࠪࠫᣉ"),l1l1l1_l1_ (u"ࠫࠬᣊ"),l1l1l1_l1_ (u"ࠬ࠭ᣋ"),l1l1l1_l1_ (u"࠭ࠧᣌ"),l1l1l1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᣍ"))
	html = response.content
	url2 = re.findall(l1l1l1_l1_ (u"ࠨࠤࡅࡹࡹࡺ࡯࡯ࡵࡅࡥࡷࡉ࡯ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᣎ"),html,re.DOTALL)
	if url2:
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ᣏ"),url2,l1l1l1_l1_ (u"ࠪࠫᣐ"),l1l1l1_l1_ (u"ࠫࠬᣑ"),l1l1l1_l1_ (u"ࠬ࠭ᣒ"),l1l1l1_l1_ (u"࠭ࠧᣓ"),l1l1l1_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨᣔ"))
		html = response.content
	img = re.findall(l1l1l1_l1_ (u"ࠨࠤ࡬ࡱ࡬࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᣕ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪᣖ"))
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦ࡫࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᣗ"),html,re.DOTALL)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧᣘ"),html,re.DOTALL)
	# l111l1_l1_
	if l1ll11l_l1_ and l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧᣙ") not in url:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᣚ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᣛ"),menu_name+title,l111ll_l1_,493,img)
	# l1ll1_l1_
	elif l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࡝࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡧࡵࡸࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᣜ"),block,re.DOTALL)
		if items:
			for l111ll_l1_,img,title in items:
				title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫᣝ"))
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᣞ"),menu_name+title,l111ll_l1_,492,img)
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᣟ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᣠ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l1l1_l1_ (u"࠭วๅืไัฮࠦࠧᣡ"),l1l1l1_l1_ (u"ࠧࠨᣢ"))
				if title!=l1l1l1_l1_ (u"ࠨࠩᣣ"): addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᣤ"),menu_name+l1l1l1_l1_ (u"ูࠪๆำษࠡࠩᣥ")+title,l111ll_l1_,491)
	return
def PLAY(url):
	url2 = url.strip(l1l1l1_l1_ (u"ࠫ࠴࠭ᣦ"))+l1l1l1_l1_ (u"ࠬ࠵࠿ࡷ࡫ࡨࡻࡂ࠷ࠧᣧ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪᣨ"),url2,l1l1l1_l1_ (u"ࠧࠨᣩ"),l1l1l1_l1_ (u"ࠨࠩᣪ"),l1l1l1_l1_ (u"ࠩࠪᣫ"),l1l1l1_l1_ (u"ࠪࠫᣬ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᣭ"))
	html = response.content
	l11l1_l1_ = []
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩᣮ"))
	l1llll11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡤࡢࡶࡤ࠾ࠥ࠭ࡱ࠾ࠪ࠱࠮ࡄ࠯ࠦࠣᣯ"),html,re.DOTALL)
	#if not l1llll11l1_l1_: l1llll11l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧ࡝ࠪࡷ࡬࡮ࡹ࡜࠯࡫ࡧࡠ࠱࠶࡜࠭ࠪ࠱࠮ࡄ࠯࡜ࠪࠩᣰ"),html,re.DOTALL)
	l1llll11l1_l1_ = l1llll11l1_l1_[0]
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᣱ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬᣲ"),block,re.DOTALL)
		for l1llll1ll1_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬᣳ"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡲࡰࡩ࠵ࡳࡦࡴࡹࡩࡷࡹ࠯ࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࡃࡶࡃࠧᣴ")+l1llll11l1_l1_+l1l1l1_l1_ (u"ࠬࠬࡩ࠾ࠩᣵ")+l1llll1ll1_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ᣶")+title+l1l1l1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ᣷")
			l11l1_l1_.append(l111ll_l1_)
	# l11ll1l1l_l1_ l1l1111ll_l1_ l111ll_l1_
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡔࡧࡵࡺࡪࡸࠢ࠯ࠬࡂࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᣸"),html,re.DOTALL)
	if l111ll_l1_:
		title = l1l1l1_l1_ (u"่ࠩๅ฻๊ࠧ᣹")
		l111ll_l1_ = l111ll_l1_[0]+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭᣺")+title
		l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	#url2 = url.strip(l1l1l1_l1_ (u"ࠫ࠴࠭᣻"))+l1l1l1_l1_ (u"ࠬ࠵࠿ࡥࡱࡺࡲࡱࡵࡡࡥ࠿࠴ࠫ᣼")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ᣽"),url2,l1l1l1_l1_ (u"ࠧࠨ᣾"),l1l1l1_l1_ (u"ࠨࠩ᣿"),l1l1l1_l1_ (u"ࠩࠪᤀ"),l1l1l1_l1_ (u"ࠪࠫᤁ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨᤂ"))
	#html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᤃ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᤄ"),block,re.DOTALL)
		for title,l111ll_l1_ in items:
			title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩᤅ"))
			if l1l1l1_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩᤆ") in l111ll_l1_: title2 = l1l1l1_l1_ (u"ࠩࡢࡣำอีࠨᤇ")
			else: title2 = l1l1l1_l1_ (u"ࠪࠫᤈ")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᤉ")+title+l1l1l1_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᤊ")+title2
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᤋ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᤌ"),url)
	return
def SEARCH(search,l11l1l_l1_=l1l1l1_l1_ (u"ࠨࠩᤍ")):
	if not l11l1l_l1_: l11l1l_l1_ = l1l11l_l1_
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫᤎ"),l1l1l1_l1_ (u"ࠪ࠯ࠬᤏ"))
	url = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠲ࡵ࡮ࡰࡀࡵࡀࠫᤐ")+search
	l11l11_l1_(url)
	return
#   search is l1l111ll1_l1_ l1l11lll1_l1_ in l11l11_l1_()
#   l1ll1lll_l1_://l1llll11ll_l1_.l1llll1l11_l1_-l1llll1l1l_l1_.l1llll1l1l_l1_/?s=the+l1llll1111_l1_
#   l1ll1lll_l1_://l1llll11ll_l1_.l1llll1l11_l1_-l1llll1l1l_l1_.l1llll1l1l_l1_/search/the+l1llll1111_l1_/
#   l1ll1lll_l1_://l1llll11ll_l1_.l1llll1l11_l1_-l1llll1l1l_l1_.l1llll1l1l_l1_/index.l1llll111l_l1_?s=the+l1llll1111_l1_
#	l1ll1lll_l1_://l1llll1l11_l1_-l1llll1l1l_l1_.io/index.l1llll111l_l1_?s=the+l1llll1111_l1_
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭◲")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡇࡄࡎࡣࠬ◳")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ◴"),l1l1l1_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩ◵")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l11l11_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l11_l1_(url,text)
	elif mode==624: results = l1ll11_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭◶"),l1l11l_l1_,l1l1l1_l1_ (u"ࠪࠫ◷"),l1l1l1_l1_ (u"ࠫࠬ◸"),l1l1l1_l1_ (u"ࠬ࠭◹"),l1l1l1_l1_ (u"࠭ࠧ◺"),l1l1l1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ◻"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◼"),menu_name+l1l1l1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ◽"),l1l1l1_l1_ (u"ࠪࠫ◾"),629,l1l1l1_l1_ (u"ࠫࠬ◿"),l1l1l1_l1_ (u"ࠬ࠭☀"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ☁"))
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ☂"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ☃"),l1l1l1_l1_ (u"ࠩࠪ☄"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ★"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭☆")+menu_name+l1l1l1_l1_ (u"ࠬอไๆ็ํึฮ࠭☇"),l1l11l_l1_,621,l1l1l1_l1_ (u"࠭ࠧ☈"),l1l1l1_l1_ (u"ࠧࠨ☉"),l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ☊"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ☋"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ☌")+menu_name+l1l1l1_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ☍"),l1l11l_l1_,621,l1l1l1_l1_ (u"ࠬ࠭☎"),l1l1l1_l1_ (u"࠭ࠧ☏"),l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭☐"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☑"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ☒")+menu_name+l1l1l1_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ☓"),l1l11l_l1_,621,l1l1l1_l1_ (u"ࠫࠬ☔"),l1l1l1_l1_ (u"ࠬ࠭☕"),l1l1l1_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ☖"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☗"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ☘")+menu_name+l1l1l1_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭☙"),l1l11l_l1_,621,l1l1l1_l1_ (u"ࠪࠫ☚"),l1l1l1_l1_ (u"ࠫࠬ☛"),l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ☜"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ☝"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ☞"),l1l1l1_l1_ (u"ࠨࠩ☟"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ☠"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ☡"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☢"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ☣")+menu_name+title,l111ll_l1_,624)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ☤"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ☥"),l1l1l1_l1_ (u"ࠨࠩ☦"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭☧"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ☨"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠫࠬ☩"))
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ☪"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭☫"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ☬")+menu_name+title,l111ll_l1_,624)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ☭"),url,l1l1l1_l1_ (u"ࠩࠪ☮"),l1l1l1_l1_ (u"ࠪࠫ☯"),l1l1l1_l1_ (u"ࠫࠬ☰"),l1l1l1_l1_ (u"ࠬ࠭☱"),l1l1l1_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ☲"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ☳"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ☴"),l1l1l1_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ☵"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ☶"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠫࠬ☷"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ☸"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ☹"),l1l1l1_l1_ (u"ࠧࠨ☺"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭☻"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠩ࠽ࠤࠬ☼")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ☽"),menu_name+title,l111ll_l1_,621)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ☾"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ☿"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ♀"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ♁"),l1l1l1_l1_ (u"ࠨࠩ♂"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ♃"),menu_name+title,l111ll_l1_,621)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠪࠫ♄")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ♅"),l1l1l1_l1_ (u"ࠬ࠭♆"),request,url)
	if request==l1l1l1_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ♇"):
		url,search = url.split(l1l1l1_l1_ (u"ࠧࡀࠩ♈"),1)
		data = l1l1l1_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ♉")+search
		headers = {l1l1l1_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ♊"):l1l1l1_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ♋")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡕࡕࡓࡕࠩ♌"),url,data,headers,l1l1l1_l1_ (u"ࠬ࠭♍"),l1l1l1_l1_ (u"࠭ࠧ♎"),l1l1l1_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ♏"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ♐"),url,l1l1l1_l1_ (u"ࠩࠪ♑"),l1l1l1_l1_ (u"ࠪࠫ♒"),l1l1l1_l1_ (u"ࠫࠬ♓"),l1l1l1_l1_ (u"ࠬ࠭♔"),l1l1l1_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ♕"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠧࠨ♖"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠨࡷࡵࡰࠬ♗"))
	if request==l1l1l1_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ♘"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ♙"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠫࠬ♚"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ♛"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ♜"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭♝"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ♞"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭♟"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ♠"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭♡"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ♢"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ♣"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠧࠨ♤"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ♥"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ♦"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ู้ࠪอ็ะหࠪ♧"),l1l1l1_l1_ (u"ࠫๆ๐ไๆࠩ♨"),l1l1l1_l1_ (u"ࠬอฺ็์ฬࠫ♩"),l1l1l1_l1_ (u"࠭ใๅ์หࠫ♪"),l1l1l1_l1_ (u"ࠧศ฻็ห๋࠭♫"),l1l1l1_l1_ (u"ࠨ้าหๆ࠭♬"),l1l1l1_l1_ (u"่ࠩฬฬืวสࠩ♭"),l1l1l1_l1_ (u"ࠪ฽ึ฼ࠧ♮"),l1l1l1_l1_ (u"๊ࠫํัอษ้ࠫ♯"),l1l1l1_l1_ (u"ࠬอไษ๊่ࠫ♰"),l1l1l1_l1_ (u"࠭ๅิำะ๎ฮ࠭♱")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ♲"))
		#if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭♳") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ♴")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬ♵"))
		#if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ♶") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ♷")+img.strip(l1l1l1_l1_ (u"࠭࠯ࠨ♸"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩ♹"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ♺"),title,re.DOTALL)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ♻"),menu_name+title,l111ll_l1_,622,img)
		elif request==l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ♼"):
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ♽"),menu_name+title,l111ll_l1_,622,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ♾") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♿"),menu_name+title,l111ll_l1_,623,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⚀") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚁"),menu_name+title,l111ll_l1_,621,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⚂"),menu_name+title,l111ll_l1_,623,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⚃"),l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⚄")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⚅"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⚆"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠧࠤࠩ⚇"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࠪ⚈")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠩ࠲ࠫ⚉"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚊"),menu_name+l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪ⚋")+title,l111ll_l1_,621)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭⚌"),l1l1l1_l1_ (u"࠭ࠧ⚍"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ⚎"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ⚏"),url,l1l1l1_l1_ (u"ࠩࠪ⚐"),l1l1l1_l1_ (u"ࠪࠫ⚑"),l1l1l1_l1_ (u"ࠫࠬ⚒"),l1l1l1_l1_ (u"ࠬ࠭⚓"),l1l1l1_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭⚔"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ⚕"),html,re.DOTALL)
	image = re.findall(l1l1l1_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⚖"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"ࠩࠪ⚗")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠪࠫࠬࡵ࡮ࡤ࡮࡬ࡧࡰࡃࠢࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ⚘"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠫࠨ࠭⚙"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚚"),menu_name+title,url,623,img,l1l1l1_l1_ (u"࠭ࠧ⚛"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࠬ⚜")+l1lll_l1_+l1l1l1_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⚝"),html,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣ⚞"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⚟"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭⚠")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧ⚡"))
			title = title.replace(l1l1l1_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫ⚢"),l1l1l1_l1_ (u"ࠧࠡࠩ⚣"))
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⚤"),menu_name+title,l111ll_l1_,622,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ⚥"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⚦") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠫ࠴࠭⚧")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠬ࠵ࠧ⚨"))
		#		addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⚩"),menu_name+title,l111ll_l1_,622,img)
	return
def PLAY(url):
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫ⚪"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ⚫"),url,l1l1l1_l1_ (u"ࠩࠪ⚬"),l1l1l1_l1_ (u"ࠪࠫ⚭"),l1l1l1_l1_ (u"ࠫࠬ⚮"),l1l1l1_l1_ (u"ࠬ࠭⚯"),l1l1l1_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⚰"))
	html = response.content
	# l11111_l1_ page
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⚱"),html,re.DOTALL)
	l111ll_l1_ = l111ll_l1_[0]
	l1111l_l1_ = l111ll_l1_.split(l1l1l1_l1_ (u"ࠨࡲࡲࡷࡹࡃࠧ⚲"))[1]
	l1111l_l1_ = base64.b64decode(l1111l_l1_)
	l1111l_l1_ = l1111l_l1_.replace(l1l1l1_l1_ (u"ࠩ࡟࠳ࠬ⚳"),l1l1l1_l1_ (u"ࠪ࠳ࠬ⚴"))
	l1111l_l1_ = EVAL(l1l1l1_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ⚵"),l1111l_l1_)
	l1ll_l1_ = l1111l_l1_[l1l1l1_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡸ࠭⚶")]
	titles = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	zzz = zip(titles,l1ll_l1_)
	for title,l111ll_l1_ in zzz:
		l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⚷")+title+l1l1l1_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⚸")
		l11l1_l1_.append(l111ll_l1_)
	l1l1l1_l1_ (u"ࠣࠤࠥࠎࠎࠩࡩࡧࠢ࡯࡭ࡳࡱࠠࡢࡰࡧࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪ࠯ࡱ࡯࡮࡬ࠌࠌ࡬ࡦࡹࡨࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨࡪࡤࡷ࡭ࡃࠧࠪ࡝࠴ࡡࠏࠏࡰࡢࡴࡷࡷࠥࡃࠠࡩࡣࡶ࡬࠳ࡹࡰ࡭࡫ࡷࠬࠬࡥ࡟ࠨࠫࠍࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡱࡣࡵࡸࠥࡃࠠࡣࡣࡶࡩ࠻࠺࠮ࡣ࠸࠷ࡨࡪࡩ࡯ࡥࡧࠫࡴࡦࡸࡴࠬࠩࡀࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡵࡧࡲࡵࠢࡀࠤࡵࡧࡲࡵ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࠏ࡮ࡦࡹࡢࡴࡦࡸࡴࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡳࡥࡷࡺࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࠬࡄࠧ࠯࡬ࡲ࡭ࡳ࠮࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠫࠍࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡲࡩ࡯࡭ࡶ࠲ࡸࡶ࡬ࡪࡶ࡯࡭ࡳ࡫ࡳࠩࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠸ࠠࡪࡰࠣࡾࡿࢀ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠲࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࡀࡂࠥ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ⚹")
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⚺"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⚻"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬ⚼"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭⚽"): return
	search = search.replace(l1l1l1_l1_ (u"࠭ࠠࠨ⚾"),l1l1l1_l1_ (u"ࠧࠬࠩ⚿"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ⛀")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ⛁"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ⛂")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ⛃"))
	return
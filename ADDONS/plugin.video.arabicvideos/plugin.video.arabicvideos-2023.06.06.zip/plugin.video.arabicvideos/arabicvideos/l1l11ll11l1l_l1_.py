# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ喝")
menu_name = l1l1l1_l1_ (u"ࠨࡡࡖࡌࡒࡥࠧ喞")
l1l11l_l1_ = WEBSITES[script_name][0]
l1ll11ll1l_l1_ = WEBSITES[script_name][1]
l1ll1lll1l1_l1_ = WEBSITES[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l11l11_l1_(url)
	elif mode==52: results = l11l1ll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1l11ll1llll_l1_()
	elif mode==56: results = l1l11ll1l1l1_l1_()
	elif mode==57: results = l1l11ll1l1ll_l1_(url,1)
	elif mode==58: results = l1l11ll1l1ll_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ喟"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ喠"),l1l1l1_l1_ (u"ࠫࠬ喡"),59,l1l1l1_l1_ (u"ࠬ࠭喢"),l1l1l1_l1_ (u"࠭ࠧ喣"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ喤"))
	addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭喥"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ喦"),l1l1l1_l1_ (u"ࠪࠫ喧"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ喨"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ喩")+menu_name+l1l1l1_l1_ (u"࠭วๅ็ึุ่๊วหࠩ喪"),l1l1l1_l1_ (u"ࠧࠨ喫"),56)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喬"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ喭")+menu_name+l1l1l1_l1_ (u"ࠪห้อแๅษ่ࠫ單"),l1l1l1_l1_ (u"ࠫࠬ喯"),55)
	return l1l1l1_l1_ (u"ࠬ࠭喰")
def l1l11ll1llll_l1_():
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喱"),menu_name+l1l1l1_l1_ (u"ࠧศฯาฯࠥอไศใ็ห๊࠭喲"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡲࡪࡽࡥࡴࡶࠪ喳"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ喴"),menu_name+l1l1l1_l1_ (u"ࠪหๆ๊วๆࠢิหหาษࠨ喵"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡰࡰࡲࡸࡰࡦࡸࠧ営"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喷"),menu_name+l1l1l1_l1_ (u"࠭วฯำࠣห฻อแศฬࠣห้อแๅษ่ࠫ喸"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱࡯ࡥࡹ࡫ࡳࡵࠩ喹"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喺"),menu_name+l1l1l1_l1_ (u"ࠩสๅ้อๅࠡๅ็หุ๐ใ๋หࠪ喻"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡩ࡬ࡢࡵࡶ࡭ࡨ࠭喼"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ喽"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ喾"),l1l1l1_l1_ (u"࠭ࠧ喿"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗀"),menu_name+l1l1l1_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ嗁"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡾࡵࡰࠨ嗂"),57)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗃"),menu_name+l1l1l1_l1_ (u"ࠫฬิส๋ษิࠤฬ็ไศ็้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ嗄"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡳࡧࡹ࡭ࡪࡽࠧ嗅"),57)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嗆"),menu_name+l1l1l1_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭嗇"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡺ࡮࡫ࡷࡴࠩ嗈"),57)
	return
def l1l11ll1l1l1_l1_():
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗉"),menu_name+l1l1l1_l1_ (u"ࠪหาีหࠡษ็ุ้๊ำๅษอࠫ嗊"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡯ࡧࡺࡩࡸࡺࠧ嗋"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嗌"),menu_name+l1l1l1_l1_ (u"࠭ๅิๆึ่ฬะࠠาษษะฮ࠭嗍"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡴࡴࡶࡵ࡭ࡣࡵࠫ嗎"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嗏"),menu_name+l1l1l1_l1_ (u"ࠩสาึࠦวืษไหฯࠦวๅ็ึุ่๊วหࠩ嗐"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵࡬ࡢࡶࡨࡷࡹ࠭嗑"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嗒"),menu_name+l1l1l1_l1_ (u"๋ࠬำๅี็หฯࠦใๅษึ๎่๐ษࠨ嗓"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡦࡰࡦࡹࡳࡪࡥࠪ嗔"),51)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ嗕"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嗖"),l1l1l1_l1_ (u"ࠩࠪ嗗"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗘"),menu_name+l1l1l1_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ嗙"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡻࡲࡴࠬ嗚"),57)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嗛"),menu_name+l1l1l1_l1_ (u"ࠧศะอ๎ฬืࠠๆี็ื้อสࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ嗜"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡷ࡫ࡶࡪࡧࡺࠫ嗝"),57)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗞"),menu_name+l1l1l1_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ嗟"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡷ࡫ࡨࡻࡸ࠭嗠"),57)
	return
def l11l11_l1_(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭嗡"),l1l1l1_l1_ (u"࠭ࠧ嗢"),url,url)
	if l1l1l1_l1_ (u"ࠧࡀࠩ嗣") in url:
		parts = url.split(l1l1l1_l1_ (u"ࠨࡁࠪ嗤"))
		url = parts[0]
		filter = l1l1l1_l1_ (u"ࠩࡂࠫ嗥") + QUOTE(parts[1],l1l1l1_l1_ (u"ࠪࡁࠫࡀ࠯ࠦࠩ嗦"))
	else: filter = l1l1l1_l1_ (u"ࠫࠬ嗧")
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭嗨"),l1l1l1_l1_ (u"࠭ࠧ嗩"),filter,l1l1l1_l1_ (u"ࠧࠨ嗪"))
	parts = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ嗫"))
	sort,page,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l1l1_l1_ (u"ࠩࡼࡳࡵ࠭嗬"),l1l1l1_l1_ (u"ࠪࡶࡪࡼࡩࡦࡹࠪ嗭"),l1l1l1_l1_ (u"ࠫࡻ࡯ࡥࡸࡵࠪ嗮")]:
		if type==l1l1l1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ嗯"): type1=l1l1l1_l1_ (u"࠭แ๋ๆ่ࠫ嗰")
		elif type==l1l1l1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ嗱"): type1=l1l1l1_l1_ (u"ࠨ็ึุ่๊ࠧ嗲")
		#url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠩ࠲ࡪ࡮ࡲࡴࡦࡴ࠰ࡴࡷࡵࡧࡳࡣࡰࡷ࠴࠭嗳") + QUOTE(type1) + l1l1l1_l1_ (u"ࠪ࠳ࠬ嗴") + page + l1l1l1_l1_ (u"ࠫ࠴࠭嗵") + sort + filter
		url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭嗶") + QUOTE(type1) + l1l1l1_l1_ (u"࠭࠯ࠨ嗷") + page + l1l1l1_l1_ (u"ࠧ࠰ࠩ嗸") + sort + filter
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ嗹"),l1l1l1_l1_ (u"ࠩࠪ嗺"),l1l1l1_l1_ (u"ࠪࠫ嗻"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠫࠬ嗼"),l1l1l1_l1_ (u"ࠬ࠭嗽"),l1l1l1_l1_ (u"࠭ࠧ嗾"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭嗿"))
		#items = re.findall(l1l1l1_l1_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠰ࡅࠢ࡯ࡷࡰࡩࡵࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡳࡧࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘀"),html,re.DOTALL)
		items = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴ࡮ࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡵࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࠤࡳࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡰࡳࡧࡶࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ嘁"),html,re.DOTALL)
		l1ll1ll1111_l1_=0
		for id,title,l1l11ll11ll1_l1_,img in items:
			l1ll1ll1111_l1_ += 1
			#img = l1ll11ll1l_l1_ + l1l1l1_l1_ (u"ࠪ࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ嘂") + img + l1l1l1_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ嘃")
			img = l1ll1lll1l1_l1_ + l1l1l1_l1_ (u"ࠬ࠵ࡶ࠳࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯࡮ࡣ࡬ࡲ࠴࠭嘄") + img + l1l1l1_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭嘅")
			l111ll_l1_ = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ嘆") + id
			if type==l1l1l1_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ嘇"): addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嘈"),menu_name+title,l111ll_l1_,53,img)
			if type==l1l1l1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ嘉"): addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嘊"),menu_name+l1l1l1_l1_ (u"๋ࠬำๅี็ࠤࠬ嘋")+title,l111ll_l1_+l1l1l1_l1_ (u"࠭࠿ࡦࡲࡀࠫ嘌")+l1l11ll11ll1_l1_+l1l1l1_l1_ (u"ࠧ࠾ࠩ嘍")+title+l1l1l1_l1_ (u"ࠨ࠿ࠪ嘎")+img,52,img)
	else:
		if type==l1l1l1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ嘏"): type1=l1l1l1_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ嘐")
		elif type==l1l1l1_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ嘑"): type1=l1l1l1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ嘒")
		url = l1ll11ll1l_l1_ + l1l1l1_l1_ (u"࠭࠯࡫ࡵࡲࡲ࠴ࡹࡥ࡭ࡧࡦࡸࡪࡪ࠯ࠨ嘓") + sort + l1l1l1_l1_ (u"ࠧ࠮ࠩ嘔") + type1 + l1l1l1_l1_ (u"ࠨ࠯࡚࡛࠳ࡰࡳࡰࡰࠪ嘕")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠩࠪ嘖"),l1l1l1_l1_ (u"ࠪࠫ嘗"),l1l1l1_l1_ (u"ࠫࠬ嘘"),l1l1l1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ嘙"))
		items = re.findall(l1l1l1_l1_ (u"࠭ࠢࡳࡧࡩࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧ࡫ࡰࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡥࡥࡸ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嘚"),html,re.DOTALL)
		l1ll1ll1111_l1_=0
		for id,l1l11ll11ll1_l1_,img,title in items:
			l1ll1ll1111_l1_ += 1
			img = l1ll11ll1l_l1_ + l1l1l1_l1_ (u"ࠧ࠰࡫ࡰ࡫࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ嘛") + img + l1l1l1_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ嘜")
			l111ll_l1_ = l1l11l_l1_ + l1l1l1_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ嘝") + id
			if type==l1l1l1_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ嘞"): addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嘟"),menu_name+title,l111ll_l1_,53,img)
			elif type==l1l1l1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ嘠"): addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘡"),menu_name+l1l1l1_l1_ (u"ࠧๆี็ื้ࠦࠧ嘢")+title,l111ll_l1_+l1l1l1_l1_ (u"ࠨࡁࡨࡴࡂ࠭嘣")+l1l11ll11ll1_l1_+l1l1l1_l1_ (u"ࠩࡀࠫ嘤")+title+l1l1l1_l1_ (u"ࠪࡁࠬ嘥")+img,52,img)
	title=l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪ嘦")
	if l1ll1ll1111_l1_==16:
		for l1ll1lll1ll_l1_ in range(1,13) :
			if not page==str(l1ll1lll1ll_l1_):
				#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡷࡩࡷ࠳ࡰࡳࡱࡪࡶࡦࡳࡳ࠰ࠩ嘧")+type+l1l1l1_l1_ (u"࠭࠯ࠨ嘨")+str(l1ll1lll1ll_l1_)+l1l1l1_l1_ (u"ࠧ࠰ࠩ嘩")+sort + filter
				url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩ嘪")+type+l1l1l1_l1_ (u"ࠩ࠲ࠫ嘫")+str(l1ll1lll1ll_l1_)+l1l1l1_l1_ (u"ࠪ࠳ࠬ嘬")+sort + filter
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嘭"),menu_name+title+str(l1ll1lll1ll_l1_),url,51)
	return
def l11l1ll_l1_(url):
	parts = url.split(l1l1l1_l1_ (u"ࠬࡃࠧ嘮"))
	l1l11ll11ll1_l1_ = int(parts[1])
	name = UNQUOTE(parts[2])
	name = name.replace(l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣู๊ไิๆࠣࠫ嘯"),l1l1l1_l1_ (u"ࠧࠨ嘰"))
	img = parts[3]
	url = url.split(l1l1l1_l1_ (u"ࠨࡁࠪ嘱"))[0]
	if l1l11ll11ll1_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠩࠪ嘲"),l1l1l1_l1_ (u"ࠪࠫ嘳"),l1l1l1_l1_ (u"ࠫࠬ嘴"),l1l1l1_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭嘵"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡴࡧ࡯ࡩࡨࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦ࡮ࡨࡧࡹࡄࠧ嘶"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘷"),block,re.DOTALL)
		l1l11ll11ll1_l1_ = int(items[-1])
		#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ嘸"),l1l1l1_l1_ (u"ࠩࠪ嘹"),l1l11ll11ll1_l1_,l1l1l1_l1_ (u"ࠪࠫ嘺"))
	#name = xbmc.getInfoLabel( l1l1l1_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡪࡶ࡯ࡩࠧ嘻") )
	#img = xbmc.getInfoLabel( l1l1l1_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧࠨ嘼") )
	for l1llll1_l1_ in range(l1l11ll11ll1_l1_,0,-1):
		l111ll_l1_ = url + l1l1l1_l1_ (u"࠭࠿ࡦࡲࡀࠫ嘽") + str(l1llll1_l1_)
		title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ嘾")+name+l1l1l1_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤࠬ嘿")+str(l1llll1_l1_)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ噀"),menu_name+title,l111ll_l1_,53,img)
	return
def PLAY(url):
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠪࠫ噁"),l1l1l1_l1_ (u"ࠫࠬ噂"),l1l1l1_l1_ (u"ࠬ࠭噃"),l1l1l1_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ噄"))
	l1l11ll1l11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧๆฬ๋ๅึูࠦๅุ๋ࠣํ็ࠠๆษๆืࠥฮูะ࠰࠭ࡃࡲࡵ࡭ࡦࡰࡷࡠ࠭ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噅"),html,re.DOTALL)
	if l1l11ll1l11l_l1_:
		time = l1l11ll1l11l_l1_[1].replace(l1l1l1_l1_ (u"ࠨࡖࠪ噆"),l1l1l1_l1_ (u"ࠩࠣࠤࠥࠦࠧ噇"))
		DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ噈"),l1l1l1_l1_ (u"ࠫࠬ噉"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ噊"),l1l1l1_l1_ (u"࠭็ัษࠣห้็๊ะ์๋ࠤุ๐ใ้่้ࠣฯ๎แาࠢ฼่๎ࠦิ้ใ้ࠣฬ้ำࠡส฼ำࠥํะศࠢส่ํ่สࠨ噋")+l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ噌")+time)
		return
	#if l1l1l1_l1_ (u"ࠨ่฼ฮีืฺࠠๆ์ࠤํฺ่่ࠢั฻ศ࠭噍") in html:
	#	DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ噎"),l1l1l1_l1_ (u"ࠪࠫ噏"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏࠭噐"),l1l1l1_l1_ (u"ࠬ์ูหาิࠤ฾๊้๊ࠡๅ์฾ࠦฮุลࠪ噑"))
	#	return
	l1l11ll11l11_l1_,l1l11ll1ll11_l1_ = [],[]
	l1l11ll1lll1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡶࡢࡴࠣࡳࡷ࡯ࡧࡪࡰࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ噒"),html,re.DOTALL)[0]
	l1l11ll1l111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡷࡣࡵࠤࡧࡧࡣ࡬ࡷࡳࡣࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ噓"),html,re.DOTALL)[0]
	# l111111l_l1_ l1ll_l1_
	l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪ࡯ࡷ࠿ࠦࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ噔"),html,re.DOTALL)
	for server,l111ll_l1_ in l1ll_l1_:
		if l1l1l1_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠩ噕") in server:
			server = l1l1l1_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠣࡷࡪࡸࡶࡦࡴࠪ噖")
			url = l1l11ll1l111_l1_ + l111ll_l1_
		else:
			server = l1l1l1_l1_ (u"ࠫࡲࡧࡩ࡯ࠢࡶࡩࡷࡼࡥࡳࠩ噗")
			url = l1l11ll1lll1_l1_ + l111ll_l1_
		if l1l1l1_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ噘") in url:
			l1l11ll11l11_l1_.append(url)
			l1l11ll1ll11_l1_.append(l1l1l1_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠥ࠭噙")+server)
		l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡯ࡦࠡࠩ࠱ࡱ࠸ࡻ࠸ࠨࠢ࡬ࡲࠥࡻࡲ࡭࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠭ࡻࡲ࡭ࠫࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࠶࡝࠾࠿ࠪ࠱࠶࠭࠺ࠋࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡺࡸ࡬࠯ࡣࡳࡴࡪࡴࡤࠩࡷࡵࡰ࠮ࠐࠉࠊࠋࠌ࡭ࡹ࡫࡭ࡴࡡࡱࡥࡲ࡫࠮ࡢࡲࡳࡩࡳࡪࠨࠨ࡯࠶ࡹ࠽ࠦࠠࠨ࠭ࡶࡩࡷࡼࡥࡳࠫࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࠨࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࠬ࠭࠿ࠐࠉࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡹࡷࡲ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࡝࡬ࡡ࠮ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡼࡴࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࡟࡮ࡣ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠡࠩࠬ࡟࠵ࡣࠊࠊࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࡝࡬ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࡦࡪ࡮ࡨࡸࡾࡶࡥ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠥࠦࠠࠨ࠮ࠪࠤࠥ࠭ࠩࠋࠋࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡴࡡ࡮ࡧ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡪ࡮ࡲࡥࡵࡻࡳࡩ࠰࠭ࠠࠡࠩ࠮ࡷࡪࡸࡶࡦࡴ࠮ࠫࠥࠦࠧࠬࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࠦࠧࠨ噚")
	# l111lll1_l1_ l1ll_l1_
	l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡯ࡳ࠸࠿࠴ࠪࡀࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡟ࡸ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ噛"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l1l1_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁ࡟ࡸ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ噜"),html,re.DOTALL)
	for server,l111ll_l1_ in l1ll_l1_:
		filename = l111ll_l1_.split(l1l1l1_l1_ (u"ࠪ࠳ࠬ噝"))[-1]
		filename = filename.replace(l1l1l1_l1_ (u"ࠫ࡫ࡧ࡬࡭ࡤࡤࡧࡰ࠭噞"),l1l1l1_l1_ (u"ࠬ࠭噟"))
		filename = filename.replace(l1l1l1_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ噠"),l1l1l1_l1_ (u"ࠧࠨ噡"))
		filename = filename.replace(l1l1l1_l1_ (u"ࠨ࠯ࠪ噢"),l1l1l1_l1_ (u"ࠩࠪ噣"))
		if l1l1l1_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ噤") in server:
			server = l1l1l1_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ噥")
			url = l1l11ll1l111_l1_ + l111ll_l1_
		else:
			server = l1l1l1_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ噦")
			url = l1l11ll1lll1_l1_ + l111ll_l1_
		l1l11ll11l11_l1_.append(url)
		l1l11ll1ll11_l1_.append(l1l1l1_l1_ (u"࠭࡭ࡱ࠶ࠣࠤࠬ噧")+server+l1l1l1_l1_ (u"ࠧࠡࠢࠪ器")+filename)
	selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨࡕࡨࡰࡪࡩࡴࠡࡘ࡬ࡨࡪࡵࠠࡒࡷࡤࡰ࡮ࡺࡹ࠻ࠩ噩"), l1l11ll1ll11_l1_)
	if selection == -1 : return
	url = l1l11ll11l11_l1_[selection]
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ噪"))
	return
def l1l11ll1l1ll_l1_(url,type):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ噫"),l1l1l1_l1_ (u"ࠫࠬ噬"),url,url)
	if l1l1l1_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ噭") in url: url2 = l1l11l_l1_ + l1l1l1_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ๅิๆึ่ࠬ噮")
	else: url2 = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯โ์็้ࠬ噯")
	url2 = QUOTE(url2)
	html = OPENURL_CACHED(l11l11l_l1_,url2,l1l1l1_l1_ (u"ࠨࠩ噰"),l1l1l1_l1_ (u"ࠩࠪ噱"),l1l1l1_l1_ (u"ࠪࠫ噲"),l1l1l1_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡆࡊࡎࡗࡉࡗ࡙࠭࠲ࡵࡷࠫ噳"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭噴"),l1l1l1_l1_ (u"࠭ࠧ噵"),url,html)
	if type==1: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡴࡷࡥ࡫ࡪࡴࡲࡦࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ噶"),html,re.DOTALL)
	elif type==2: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ噷"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡲࡴࡹ࡯࡯࡯ࠩ噸"),block,re.DOTALL)
	if type==1:
		for l1l11ll1ll1l_l1_,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噹"),menu_name+title,url+l1l1l1_l1_ (u"ࠫࡄࡹࡵࡣࡩࡨࡲࡷ࡫࠽ࠨ噺")+l1l11ll1ll1l_l1_,58)
	elif type==2:
		url,l1l11ll1ll1l_l1_ = url.split(l1l1l1_l1_ (u"ࠬࡅࠧ噻"))
		for country,title in items:
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭噼"),menu_name+title,url+l1l1l1_l1_ (u"ࠧࡀࡥࡲࡹࡳࡺࡲࡺ࠿ࠪ噽")+country+l1l1l1_l1_ (u"ࠨࠨࠪ噾")+l1l11ll1ll1l_l1_,51)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ噿"),l1l1l1_l1_ (u"ࠪࠫ嚀"),search,search)
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠫࠥ࠭嚁"),l1l1l1_l1_ (u"ࠬࠫ࠲࠱ࠩ嚂"))
	#response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ嚃"), l1l11l_l1_, l1l1l1_l1_ (u"ࠧࠨ嚄"), l1l1l1_l1_ (u"ࠨࠩ嚅"), True,l1l1l1_l1_ (u"ࠩࠪ嚆"),l1l1l1_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ嚇"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l1l111111_l1_ = cookies[l1l1l1_l1_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࠬ嚈")]
	#l1l11ll11lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡤࡩࡳࡳࡨࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࠬ嚉"),html,re.DOTALL)
	#l1l11ll11lll_l1_ = l1l11ll11lll_l1_[0]
	#payload = l1l1l1_l1_ (u"࠭࡟ࡤࡵࡵࡪࡂ࠭嚊") + l1l11ll11lll_l1_ + l1l1l1_l1_ (u"ࠧࠧࡳࡀࠫ嚋") + QUOTE(l11ll11_l1_)
	#headers = { l1l1l1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧ嚌"):l1l1l1_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ嚍") , l1l1l1_l1_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪ嚎"):l1l1l1_l1_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠭嚏")+l1l111111_l1_ }
	#url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠵ࡳࡦࡣࡵࡧ࡭ࠨ嚐")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡐࡐࡕࡗࠫ嚑"), url, payload, headers, True,l1l1l1_l1_ (u"ࠧࠨ嚒"),l1l1l1_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠶ࡳࡪࠧ嚓"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭嚔")+l11ll11_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ嚕"),url,l1l1l1_l1_ (u"ࠫࠬ嚖"),l1l1l1_l1_ (u"ࠬ࠭嚗"),True,l1l1l1_l1_ (u"࠭ࠧ嚘"),l1l1l1_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡖࡉࡆࡘࡃࡉ࠯࠵ࡲࡩ࠭嚙"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡩࡨࡲࡪࡸࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡸ࡫ࡡࡳࡥ࡫࠱ࡧࡵࡴࡵࡱࡰ࠱ࡵࡧࡤࡥ࡫ࡱ࡫ࠬ嚚"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭嚛"),block,re.DOTALL)
	if items:
		for l111ll_l1_,img,title in items:
			#title = title.decode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ嚜")).encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ嚝"))
			url = l1l11l_l1_ + l111ll_l1_
			if l1l1l1_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ嚞") in url:
				if l1l1l1_l1_ (u"࠭࠿ࡦࡲࡀࠫ嚟") in url:
					title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ嚠")+title
					url = url.replace(l1l1l1_l1_ (u"ࠨࡁࡨࡴࡂ࠷ࠧ嚡"),l1l1l1_l1_ (u"ࠩࡂࡩࡵࡃ࠰ࠨ嚢"))
					url = url+l1l1l1_l1_ (u"ࠪࡁࠬ嚣")+QUOTE(title)+l1l1l1_l1_ (u"ࠫࡂ࠭嚤")+img
					addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚥"),menu_name+title,url,52,img)
				else:
					title = l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣๆ๐ไๆࠢࠪ嚦")+title
					addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嚧"),menu_name+title,url,53,img)
	#else: DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ嚨"),l1l1l1_l1_ (u"ࠩࠪ嚩"),l1l1l1_l1_ (u"ࠪࡲࡴࠦࡲࡦࡵࡸࡰࡹࡹࠧ嚪"),l1l1l1_l1_ (u"้ࠫอࠠห๊ฯำࠥ์สศศฯࠤ้๊ศฮอࠪ嚫"))
	return
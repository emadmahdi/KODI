# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨම")
menu_name = l1l1l1_l1_ (u"࠭࡟ࡌ࡙ࡗࡣࠬඹ")
l1l11l_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==130: results = MENU()
	elif mode==131: results = l11l11_l1_(url)
	elif mode==132: results = CATEGORIES(url)
	elif mode==133: results = l11l1ll_l1_(url,page)
	elif mode==134: results = PLAY(url)
	elif mode==135: results = l1ll11lll_l1_()
	elif mode==139: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬය"),menu_name+l1l1l1_l1_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣห้้่ฬำࠪර"),l1l1l1_l1_ (u"ࠩࠪ඼"),135)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪල"),menu_name+l1l1l1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ඾"),l1l1l1_l1_ (u"ࠬ࠭඿"),139,l1l1l1_l1_ (u"࠭ࠧව"),l1l1l1_l1_ (u"ࠧࠨශ"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬෂ"))
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧස"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪහ"),l1l1l1_l1_ (u"ࠫࠬළ"),9999)
	html = OPENURL_CACHED(REGULAR_CACHE,l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭ෆ"),l1l1l1_l1_ (u"࠭ࠧ෇"),True,l1l1l1_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ෈"))
	l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡵࡱࡪ࡫ࡱ࡫ࠧ෉"),html,re.DOTALL)
	block = l1ll1l1_l1_[1]
	items=re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ්"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠪ࠳ࡨࡵ࡮ࡥࡷࡦࡸࡴࡸࠧ෋") in l111ll_l1_: continue
		title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭෌"))
		#l1ll1l1l1_l1_ = [l1l1l1_l1_ (u"ࠬ࠵ࡲࡦ࡮࡬࡫࡮ࡵࡵࡴࠩ෍"),l1l1l1_l1_ (u"࠭࠯ࡴࡱࡦ࡭ࡦࡲࠧ෎"),l1l1l1_l1_ (u"ࠧ࠰ࡲࡲࡰ࡮ࡺࡩࡤࡣ࡯ࠫා")]
		#if any(value in l111ll_l1_ for value in l1ll1l1l1_l1_):
		#	title = l1l1l1_l1_ (u"ࠨษ็ฬึอๅอࠢࠪැ")+title
		url = l1l11l_l1_+l111ll_l1_
		if l1l1l1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ෑ") in url: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪි"),menu_name+title,url,132)
		else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫී"),menu_name+title,url,131)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪු"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭෕"),l1l1l1_l1_ (u"ࠧࠨූ"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ෗"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫෘ")+menu_name+l1l1l1_l1_ (u"ࠪห้๋ำๅี็หฯ࠭ෙ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠶࠶࠶ࠫේ"),132,l1l1l1_l1_ (u"ࠬ࠭ෛ"),l1l1l1_l1_ (u"࠭࠱ࠨො"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧෝ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪෞ")+menu_name+l1l1l1_l1_ (u"ࠩส่ศ็ไศ็ࠪෟ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠶࠳࠺ࠪ෠"),132,l1l1l1_l1_ (u"ࠫࠬ෡"),l1l1l1_l1_ (u"ࠬ࠷ࠧ෢"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෣"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ෤")+menu_name+l1l1l1_l1_ (u"ࠨสิห๊าࠠศๆุ฾ฬื้ࠠษ็ุออศࠨ෥"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠱࠸ࠩ෦"),132,l1l1l1_l1_ (u"ࠪࠫ෧"),l1l1l1_l1_ (u"ࠫ࠶࠭෨"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ෩"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ෪")+menu_name+l1l1l1_l1_ (u"ࠧศสิึࠥอไษำส้ั࠭෫"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠶࠽࠶࠴ࠩ෬"),132,l1l1l1_l1_ (u"ࠩࠪ෭"),l1l1l1_l1_ (u"ࠪ࠵ࠬ෮"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ෯"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ෰")+menu_name+l1l1l1_l1_ (u"࠭วๅ็ะห฻ืวหࠩ෱"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠽࠹࠹ࠧෲ"),132,l1l1l1_l1_ (u"ࠨࠩෳ"),l1l1l1_l1_ (u"ࠩ࠴ࠫ෴"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෵"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭෶")+menu_name+l1l1l1_l1_ (u"ࠬ฿วี๊ิหฦ࠭෷"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠴࠷࠺࠹ࠧ෸"),132,l1l1l1_l1_ (u"ࠧࠨ෹"),l1l1l1_l1_ (u"ࠨ࠳ࠪ෺"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ෻"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ෼")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ศาษ่ะࠥอไศฮอ้ฬ฿๊สࠩ෽"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠷࠳࠵ࠬ෾"),132,l1l1l1_l1_ (u"࠭ࠧ෿"),l1l1l1_l1_ (u"ࠧ࠲ࠩ฀"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨก"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫข")+menu_name+l1l1l1_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊ฯ๋่ํอࠬฃ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠶࠲࠼ࠫค"),132,l1l1l1_l1_ (u"ࠬ࠭ฅ"),l1l1l1_l1_ (u"࠭࠱ࠨฆ"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧง"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪจ")+menu_name+l1l1l1_l1_ (u"ࠩส่อืวๆฮࠣห้๎หศศๅ๎ฮ࠭ฉ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠶࠵ࠪช"),132,l1l1l1_l1_ (u"ࠫࠬซ"),l1l1l1_l1_ (u"ࠬ࠷ࠧฌ"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ญ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩฎ")+menu_name+l1l1l1_l1_ (u"ࠨษ็ฬึอๅอࠢสุ่๐วิ์ฬࠫฏ"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠴࠶ࠩฐ"),132,l1l1l1_l1_ (u"ࠪࠫฑ"),l1l1l1_l1_ (u"ࠫ࠶࠭ฒ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬณ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨด")+menu_name+l1l1l1_l1_ (u"ࠧไฬหࠫต"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠷࠿࠱ࠨถ"),132,l1l1l1_l1_ (u"ࠩࠪท"),l1l1l1_l1_ (u"ࠪ࠵ࠬธ"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫน"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧบ")+menu_name+l1l1l1_l1_ (u"࠭สฺๆ่ࠤฬ๊แศำึ๎ฮ࠭ป"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠼࠽࠭ผ"),132,l1l1l1_l1_ (u"ࠨࠩฝ"),l1l1l1_l1_ (u"ࠩ࠴ࠫพ"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪฟ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ภ")+menu_name+l1l1l1_l1_ (u"ࠬษัี์ไࠤฬ๊ศาษ่ะࠬม"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠴࠶࠼࠿ࠧย"),132,l1l1l1_l1_ (u"ࠧࠨร"),l1l1l1_l1_ (u"ࠨ࠳ࠪฤ"))
	return
def l11l11_l1_(url):
	l1ll1l1l1_l1_ = [l1l1l1_l1_ (u"ࠩ࠲ࡶࡪࡲࡩࡨ࡫ࡲࡹࡸ࠭ล"),l1l1l1_l1_ (u"ࠪ࠳ࡸࡵࡣࡪࡣ࡯ࠫฦ"),l1l1l1_l1_ (u"ࠫ࠴ࡶ࡯࡭࡫ࡷ࡭ࡨࡧ࡬ࠨว"),l1l1l1_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷࠬศ"),l1l1l1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹࠧษ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨส"),l1l1l1_l1_ (u"ࠨࠩห"),True,l1l1l1_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩฬ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡤࡤࡶ࠭࠴ࠪࡀࠫࡷ࡭ࡹࡲࡥࡣࡣࡵࠫอ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	if any(value in url for value in l1ll1l1l1_l1_):
		items = re.findall(l1l1l1_l1_ (u"ࠦࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁࠨฮ"),block,re.DOTALL)
		for img,l111ll_l1_,title in items:
			title = title.strip(l1l1l1_l1_ (u"ࠬࠦࠧฯ"))
			l111ll_l1_ = l1l11l_l1_ + l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ะ"),menu_name+title,l111ll_l1_,133,img,l1l1l1_l1_ (u"ࠧ࠲ࠩั"))
	elif l1l1l1_l1_ (u"ࠨ࠱ࡧࡳࡨࡹࠧา") in url:
		items = re.findall(l1l1l1_l1_ (u"ࠤࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࠦำ"),block,re.DOTALL)
		for img,title,l111ll_l1_ in items:
			title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬิ"))
			l111ll_l1_ = l1l11l_l1_ + l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫี"),menu_name+title,l111ll_l1_,133,img,l1l1l1_l1_ (u"ࠬ࠷ࠧึ"))
	return
def CATEGORIES(url):
	category = url.split(l1l1l1_l1_ (u"࠭࠯ࠨื"))[-1]
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠧࠨุ"),l1l1l1_l1_ (u"ࠨูࠩ"),True,l1l1l1_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠴ࡷࡹฺ࠭"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡴࡦࡸࡥ࡯ࡶࡦࡥࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ฻"),html,re.DOTALL)
	if not l1ll1l1_l1_:
		l11l1ll_l1_(url,l1l1l1_l1_ (u"ࠫ࠶࠭฼"))
		return
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ฽"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		#l1ll1l11l_l1_ = url.split(l1l1l1_l1_ (u"࠭࠯ࠨ฾"))[-1]
		#if category==l1ll1l11l_l1_: continue
		title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩ฿"))
		l111ll_l1_ = l1l11l_l1_ + l111ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨเ"),menu_name+title,l111ll_l1_,132,l1l1l1_l1_ (u"ࠩࠪแ"),l1l1l1_l1_ (u"ࠪ࠵ࠬโ"))
	return
def l11l1ll_l1_(url,page):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠫࠬใ"),l1l1l1_l1_ (u"ࠬ࠭ไ"),True,l1l1l1_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨๅ"))
	items = re.findall(l1l1l1_l1_ (u"ࠧࡵࡱࡷࡥࡱࡶࡡࡨࡧࡦࡳࡺࡴࡴ࠾࡝࡟ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠧࠣ࡟ࠪๆ"),html,re.DOTALL)
	if not items:
		url = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡻࡸ࠳ࡤࡦࡶࡤ࡭ࡱ࠳ࡢࡰࡦࡼࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭็"),html,re.DOTALL)
		url = url[0]
		title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ่") + l1l1l1_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ้")
		if url: addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ๊ࠪ"),menu_name+title,url,134)
		else: DIALOG_OK(l1l1l1_l1_ (u"๋ࠬ࠭"),l1l1l1_l1_ (u"࠭ࠧ์"),l1l1l1_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪํ"),l1l1l1_l1_ (u"ࠨๆสࠤ๏๎ฬะࠢะห้๐วࠡ็็ๅฬะࠠโ์า๎ํࠦแ๋๊ࠢิฬࠦวๅใิ฽ࠬ๎"))
		return
	l1ll11l1l_l1_ = int(items[0])
	name = re.findall(l1l1l1_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠴ࠪࡀ࠾࠲ࡥࡃࠦ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ๏"),html,re.DOTALL)
	if name: name = name[0].strip(l1l1l1_l1_ (u"ࠪࠤࠬ๐"))
	else: name = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ๑"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭๒"),l1l1l1_l1_ (u"࠭ࠧ๓"),name, str(l1l1l1_l1_ (u"ࠧࠨ๔")))
	if l1l1l1_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬ๕") in url or l1l1l1_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬ๖") in url:
		category = url.split(l1l1l1_l1_ (u"ࠪ࠳ࠬ๗"))[-1]
		if page==l1l1l1_l1_ (u"ࠫࠬ๘"): url2 = url
		else: url2 = l1l11l_l1_ + l1l1l1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩ๙") + category + l1l1l1_l1_ (u"࠭࠯ࠨ๚") + page
		l1l11l11_l1_ = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1l1_l1_ (u"ࠧࠨ๛"),l1l1l1_l1_ (u"ࠨࠩ๜"),True,l1l1l1_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ๝"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡴࡦ࡭ࡥ࡯ࡷࡰࡦࡪࡸࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ๞"),l1l11l11_l1_,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡫ࡻ࡬࡭ࠪ࠱࠮ࡄ࠯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ๟"),block,re.DOTALL)
		for img,type,l111ll_l1_,title in items:
			if l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ๠") not in type: continue
			if l1l1l1_l1_ (u"࠭ๅิๆึ่ࠬ๡") in title and l1l1l1_l1_ (u"ࠧฮๆๅอࠬ๢") not in title: continue
			title = title.replace(l1l1l1_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭๣"),l1l1l1_l1_ (u"ࠩࠪ๤"))
			title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬ๥"))
			if l1l1l1_l1_ (u"ู๊ࠫไิๆࠪ๦") in name and l1l1l1_l1_ (u"ࠬำไใหࠪ๧") in title and l1l1l1_l1_ (u"࠭ๅิๆึ่ࠬ๨") not in title:
				title = l1l1l1_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭๩") + name + l1l1l1_l1_ (u"ࠨࠢ࠰ࠤࠬ๪") + title
			l111ll_l1_ = l1l11l_l1_ + l111ll_l1_
			if category==l1l1l1_l1_ (u"ࠩ࠹࠶࠽࠭๫"): addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ๬"),menu_name+title,l111ll_l1_,133,img,l1l1l1_l1_ (u"ࠫ࠶࠭๭"))
			else: addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ๮"),menu_name+title,l111ll_l1_,134,img)
	elif l1l1l1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ๯") in url:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯ࡣࡰ࡮࠰ࡱࡩ࠳࠱࠳ࠩ๰"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠣࡸ࡬ࡨࡪࡵ࠭ࡵࡴࡤࡧࡰ࠳ࡴࡦࡺࡷ࠲࠯ࡅ࡬ࡰࡣࡧ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ๱"),block,re.DOTALL)
			for l111ll_l1_,img,title in items:
				title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ๲"))
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ๳"),menu_name+title,l111ll_l1_,134,img)
		elif l1l1l1_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠷࠴࠻ࠫ๴") in html:
				title = l1l1l1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ๵") + l1l1l1_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ๶")
				addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭๷"),menu_name+title,url,134)
		else:
			items = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡧࡁࠧࡉࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ๸"),html,re.DOTALL)
			category = items[0].split(l1l1l1_l1_ (u"ࠩ࠲ࠫ๹"))[-1]
			url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧ๺") + category
			CATEGORIES(url)
			return
		l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࠋࡷࡳࡹࡧ࡬ࡱࡣࡪࡩࡸࠦ࠽ࠡ࠲ࠍࠍࠎࠏࡥࡱ࡫ࡶࡳࡩ࡫ࡉࡅࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠱ࠪ࠭ࡠ࠳࠱࡞ࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣࡅࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫ࡞࠱࠶ࡣࠊࠊࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡࠩ࠲ࡥ࡯ࡧࡸ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫࠥ࠱ࠠࡤࡣࡷࡩ࡬ࡵࡲࡺࠢ࠮ࠤࠬ࠵ࠧࠡ࠭ࠣࡴࡦ࡭ࡥࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠴࠯ࠫࠬ࠲ࠧࠨ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠳ࡳࡦࠪ࠭ࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠠ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪ࡯ࡪ࠰ࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤ࠰ࠦ࡬ࡪࡰ࡮ࠎࠎࠏࠉࠊࡧࡳ࡭ࡸࡵࡤࡦࡋࡇࡲࡪࡽࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬ࡟࠲࠷࡝ࠋࠋࠌࠍࠎ࡯ࡦࠡࡧࡳ࡭ࡸࡵࡤࡦࡋࡇࡲࡪࡽ࠽࠾ࡧࡳ࡭ࡸࡵࡤࡦࡋࡇ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠹࠴࠭࡫ࡰ࡫࠮ࠐࠉࠊࠤࠥࠦ๻")
	l1l1l1_l1_ (u"ࠧࠨࠢࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫ࠵࠱࠷ࠫࡵࡱࡷࡥࡱࡶࡡࡨࡧࡶ࠭࠿ࠐࠉࠊ࡫ࡩࠤࡵࡧࡧࡦࠣࡀࡷࡹࡸࠨࡪࠫ࠽ࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ฺࠫ็อสࠢࠪ࠯ࡸࡺࡲࠩ࡫ࠬ࠰ࡺࡸ࡬࠭࠳࠶࠷࠱࠭ࠧ࠭ࡵࡷࡶ࠭࡯ࠩࠪࠌࠌࠦࠧࠨ๼")
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ๽"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		pages = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ๾"),block,re.DOTALL)
		for l111ll_l1_,title in pages:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠨࠨࡤࡱࡵࡁࠧ๿"),l1l1l1_l1_ (u"ࠩࠩࠫ຀"))
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪກ"),menu_name+l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪຂ")+title,l111ll_l1_,133)
	return
def PLAY(url):
	if l1l1l1_l1_ (u"ࠬ࠵࡮ࡦࡹࡶ࠳ࠬ຃") in url or l1l1l1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩຄ") in url:
		html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠧࠨ຅"),l1l1l1_l1_ (u"ࠨࠩຆ"),True,l1l1l1_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧງ"))
		items = re.findall(l1l1l1_l1_ (u"ࠥࡱࡴࡨࡩ࡭ࡧࡹ࡭ࡩ࡫࡯ࡱࡣࡷ࡬࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢຈ"),html,re.DOTALL)
		if items: url = items[0]
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪຉ"))
	return
def l1ll11lll_l1_():
	#l1ll1l1ll_l1_(l1l1l1_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫຊ"))
	#DIALOG_NOTIFICATION(l1l1l1_l1_ (u"࠭ฬศำํࠤฯฺฺ๋ๆࠣห้่ๆศหࠪ຋"),l1l1l1_l1_ (u"ࠧࠨຌ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱࡯࡭ࡻ࡫ࠧຍ")
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠩࠪຎ"),l1l1l1_l1_ (u"ࠪࠫຏ"),True,l1l1l1_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩຐ"))
	url2 = re.findall(l1l1l1_l1_ (u"ࠬࡲࡩࡷࡧ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ຑ"),html,re.DOTALL)
	url2 = url2[0]
	headers2 = {l1l1l1_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧຒ"):l1l11l_l1_}
	response2 = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫຓ"),url2,l1l1l1_l1_ (u"ࠨࠩດ"),headers2,l1l1l1_l1_ (u"ࠩࠪຕ"),True,l1l1l1_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠷ࡴࡤࠨຖ"))
	l1l11l11_l1_ = response2.content
	token = re.findall(l1l1l1_l1_ (u"ࠫࡨࡹࡲࡧ࠯ࡷࡳࡰ࡫࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫທ"),l1l11l11_l1_,re.DOTALL)
	token = token[0]
	l1ll1l111_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩຘ"))
	url3 = re.findall(l1l1l1_l1_ (u"ࠨࡰ࡭ࡣࡼ࡙ࡷࡲࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥນ"),l1l11l11_l1_,re.DOTALL)
	url3 = l1ll1l111_l1_+url3[0]
	#LOG_THIS(l1l1l1_l1_ (u"ࠧࠨບ"),url3)
	l1ll11l11_l1_ = {l1l1l1_l1_ (u"ࠨ࡚࠰ࡇࡘࡘࡆ࠮ࡖࡒࡏࡊࡔࠧປ"):token}
	response3 = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧຜ"),url3,l1l1l1_l1_ (u"ࠪࠫຝ"),l1ll11l11_l1_,False,True,l1l1l1_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡍࡋ࡙ࡉ࠲࠹ࡲࡥࠩພ"))
	l1ll11ll1_l1_ = response3.content
	l1111lll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ຟ"),l1ll11ll1_l1_,re.DOTALL)
	l1111lll_l1_ = l1111lll_l1_[0].replace(l1l1l1_l1_ (u"࠭࡜࠰ࠩຠ"),l1l1l1_l1_ (u"ࠧ࠰ࠩມ"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩຢ"),l1l1l1_l1_ (u"ࠩࠪຣ"),url,html)
	#l1ll1l1ll_l1_(l1l1l1_l1_ (u"ࠪࡷࡹࡵࡰࠨ຤"))
	PLAY_VIDEO(l1111lll_l1_,script_name,l1l1l1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩລ"))
	return
def SEARCH(search,url=l1l1l1_l1_ (u"ࠬ࠭຦")):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if url==l1l1l1_l1_ (u"࠭ࠧວ"):
		if search==l1l1l1_l1_ (u"ࠧࠨຨ"): search = OPEN_KEYBOARD()
		if search==l1l1l1_l1_ (u"ࠨࠩຩ"): return
		#search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫສ"),l1l1l1_l1_ (u"ࠪ࠯ࠬຫ"))
		#search = l1l1l1_l1_ (u"ࠫ࠲ࡺࡡࡨࠢࡧࡳࡨࡹࠠࡐࡔࠣࡪ࡮ࡲ࡭ࡴࠢࡒࡖࠥࡹࡥࡳ࡫ࡨࡷࠥࡕࡒࠡࡧࡳ࡭ࡸࡵࡤࡦࠢࡒࡖࠥ࡫ࡰࡪࡵࡲࡨࡪࡹࠠࡐࡔࠣࡧࡦࡺࡥࡨࡱࡵࡽࠥࡕࡒࠡࡰࡨࡻࡸࠦ࡭ࡱ࠶ࠣࠫຬ")+search
		#search = l1l1l1_l1_ (u"ࠬࠨ࡭ࡱ࠶ࠥࠤࠬອ")+search
		search = QUOTE(search)
		url = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪຮ")+search
		l11l1ll_l1_(url,l1l1l1_l1_ (u"ࠧࠨຯ"))
		return
	l1l1l1_l1_ (u"ࠣࠤࠥࠎࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࡖࡵࡹࡪ࠲ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧࠪࠌࠌࠍࡨࡾࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡷࡣࡵࠤࡨࡾࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࡡ࠰࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠣࡩࡦࡷࡪ࠴ࡳࡳࡥࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪ࡝࠳ࡡࠏࠏࠉࡶࡴ࡯ࠤࡂࠦࡵࡳ࡮࠮ࡧࡽࠐࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࡘࡷࡻࡥ࠭ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩࠬࠎࠎࠏࡣࡴࡧࡢࡸࡴࡱࡥ࡯ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡷࡪࡥࡴࡰ࡭ࡨࡲࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬ࡟࠵ࡣࠊࠊࠋࡦࡷࡪࡲࡩࡣࡘࡨࡶࡸ࡯࡯࡯ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡷࡪࡲࡩࡣࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠࠎࠎࠏࡲࡢࡰࡧࡳࡲࡇࡐࡊࠢࡀࠤࡸࡺࡲࠩࡴࡤࡲࡩࡵ࡭࠯ࡴࡤࡲࡩ࡯࡮ࡵࠪ࠴࠵࠶࠷ࠬ࠺࠻࠼࠽࠮࠯ࠊࠊࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡸ࡫࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡨࡹࡥ࠰ࡧ࡯ࡩࡲ࡫࡮ࡵ࠱ࡹ࠵ࡄࡸࡳࡻ࠿ࡩ࡭ࡱࡺࡥࡳࡧࡧࡣࡨࡹࡥࠧࡰࡸࡱࡂ࠷࠰ࠧࡪ࡯ࡁࡦࡸࠦࡴࡱࡸࡶࡨ࡫࠽ࡨࡥࡶࡧࠫ࡭ࡳࡴ࠿࠱ࡧࡴࡳࠦࡤࡵࡨࡰ࡮ࡨࡶ࠾ࠩ࠮ࡧࡸ࡫࡬ࡪࡤ࡙ࡩࡷࡹࡩࡰࡰ࠮ࠫࠫࡩࡸ࠾ࠩ࠮ࡧࡽ࠱ࠧࠧࡳࡀࠫ࠰ࡹࡥࡢࡴࡦ࡬࠰࠭ࠦࡴࡣࡩࡩࡂࡵࡦࡧࠨࡦࡷࡪࡥࡴࡰ࡭ࡀࠫ࠰ࡩࡳࡦࡡࡷࡳࡰ࡫࡮ࠬࠩࠩࡷࡴࡸࡴ࠾ࠨࡨࡼࡵࡃࡣࡴࡳࡵ࠰ࡨࡩࠦࡤࡣ࡯ࡰࡧࡧࡣ࡬࠿ࡪࡳࡴ࡭࡬ࡦ࠰ࡶࡩࡦࡸࡣࡩ࠰ࡦࡷࡪ࠴ࡡࡱ࡫ࠪ࠯ࡷࡧ࡮ࡥࡱࡰࡅࡕࡏࠫࠨࠨࡶࡸࡦࡸࡴ࠾࠲ࠪࠎࠎࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࠡ࠿ࠣࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠮ࠩࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠿ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡾࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࡘࡷࡻࡥ࠭ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲࡙ࡅࡂࡔࡆࡌ࠲࠹ࡲࡥࠩࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡣࡩࡧࡘࡶࡱࠨ࠺࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡳࡥࡵࡣࡷࡥ࡬ࡹࠢ࠻ࠢࡾࠬ࠳࠰࠿ࠪࡿࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭ࡶࡤ࡫ࡸࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨࡸ࡬ࡨࡪࡵࠧࠡࡰࡲࡸࠥ࡯࡮ࠡࡶࡤ࡫ࡸࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡻ࡮ࡦࡵࡦࡥࡵ࡫ࡈࡕࡏࡏࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠹ࡣࠨ࠮ࠪࡀࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠳ࡦࠩ࠯ࠫࡃ࠭ࠩࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂࡢ࠿ࠩ࠯ࠫࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡧࡄࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠡࠢࠪ࠰ࠬࠦࠧࠪࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠊࠥࠣࡳࡷࠦࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠐࠉࠊࠋࡹࡥࡷࡹࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬࠎࠎࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡀࠤࡻࡧࡲࡴ࡝࠷ࡡࠏࠏࠉࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪࠤ࠰ࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࠋࠋࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡻࡧࡲࡴࠫࡁ࠹࠿ࠐࠉࠊࠋࠌࡴࡦ࡭ࡥ࠲ࠢࡀࠤࡻࡧࡲࡴ࡝࠸ࡡࠏࠏࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡺࡸ࡬࠭࠳࠶࠷࠱࠭ࠧ࠭ࡲࡤ࡫ࡪ࠷ࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡻࡲ࡭࠮࠴࠷࠷࠯ࠊࠊࠋࡨࡰ࡮࡬ࠠࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠲࠵࠶࠰ࠬ࠭ࠬࠨ࠳ࠪ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬࡼࡩࡥࡧࡲࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠷࠳࠵ࠫࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠥ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡵࡷࡥࡷࡺࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡩࡵࡳࡴࡨࡲࡹࡖࡡࡨࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦࡋࡱࡨࡪࡾࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠭ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡤࡷࡵࡶࡪࡴࡴࡑࡣࡪࡩࠥࡃࠠࡴࡶࡵࠬ࡮ࡴࡴࠩࡥࡸࡶࡷ࡫࡮ࡵࡒࡤ࡫ࡪࡡ࠰࡞ࠫ࠮࠵࠮ࠐࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨ࠰ࡸࡺࡡࡳࡶࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡁࡂࡩࡵࡳࡴࡨࡲࡹࡖࡡࡨࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࡸࡶࡱࠦ࠽ࠡࡷࡵࡰ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡹࡴࡢࡴࡷࡁࠬ࠯࡛࠱࡟࠮ࠫࡸࡺࡡࡳࡶࡀࠫ࠰ࡹࡴࡢࡴࡷࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ฺࠫ็อสࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡹࡷࡲࠬ࠲࠵࠼࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥະ")
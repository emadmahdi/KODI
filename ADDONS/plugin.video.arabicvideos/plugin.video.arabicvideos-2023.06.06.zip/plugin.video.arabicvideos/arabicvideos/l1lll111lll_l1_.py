# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫⲾ")
menu_name = l1l1l1_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩⲿ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"๊ࠫ฻วา฻ฬࠫⳀ"),l1l1l1_l1_ (u"ࠬออะอࠣห้ฮัศ็ฯࠫⳁ"),l1l1l1_l1_ (u"࠭วฮัฮࠤฬ๊วๅ฻สฬࠬⳂ"),l1l1l1_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭ⳃ")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l11l11_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l11l1ll_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬⳄ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪⳅ"),l1l1l1_l1_ (u"ࠪࠫⳆ"),l1l1l1_l1_ (u"ࠫࠬⳇ"),l1l1l1_l1_ (u"ࠬ࠭Ⳉ"),l1l1l1_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪⳉ"))
	html = response.content
	l11l1l_l1_ = SERVER(l1l11l_l1_,l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠫⳊ"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳋ"),menu_name+l1l1l1_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩⳌ"),l1l1l1_l1_ (u"ࠪࠫⳍ"),89,l1l1l1_l1_ (u"ࠫࠬⳎ"),l1l1l1_l1_ (u"ࠬ࠭ⳏ"),l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪⳐ"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳑ"),menu_name+l1l1l1_l1_ (u"ࠨษัฮึ์วࠡๆๆࠫⳒ"),l11l1l_l1_,81,l1l1l1_l1_ (u"ࠩࠪⳓ"),l1l1l1_l1_ (u"ࠪࠫⳔ"),l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ⳕ"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧⳖ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩⳗ"),block,re.DOTALL)
	for l111l1111_l1_,title in items:
		l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭Ⳙ")+l111l1111_l1_+l1l1l1_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩⳙ")
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳚ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬⳛ")+menu_name+title,l111ll_l1_,81)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⳜ"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⳝ"),l1l1l1_l1_ (u"࠭ࠧⳞ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨⳟ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⳠ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if l111ll_l1_==l1l1l1_l1_ (u"ࠩࠦࠫⳡ"): continue
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳢ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ⳣ")+menu_name+title,l111ll_l1_,81)
	return
def l11l11_l1_(url,l111l1111_l1_=l1l1l1_l1_ (u"ࠬ࠭ⳤ")):
	#DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ⳥"),l1l1l1_l1_ (u"ࠧࠨ⳦"),url)
	items = []
	# l1lllll11l_l1_ l1lllll1l1_l1_
	if l1l1l1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ⳧") in url or l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪ⳨") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⳩"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ⳪")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪⳫ"),url2,data2,headers2,l1l1l1_l1_ (u"࠭ࠧⳬ"),l1l1l1_l1_ (u"ࠧࠨⳭ"),l1l1l1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧⳮ"))
		html = response.content
		l1ll1l1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭⳯"),url,l1l1l1_l1_ (u"ࠪࠫ⳰"),l1l1l1_l1_ (u"ࠫࠬ⳱"),l1l1l1_l1_ (u"ࠬ࠭Ⳳ"),l1l1l1_l1_ (u"࠭ࠧⳳ"),l1l1l1_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⳴"))
		html = response.content
		# l111l1111_l1_ items
		if l111l1111_l1_==l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⳵"):
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ⳶"),html,re.DOTALL)
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⳷"),block,re.DOTALL)
			#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ⳸"),l1l1l1_l1_ (u"ࠬ࠭⳹"),l1l1l1_l1_ (u"࠭ࠧ⳺"))
		# l1lllllll1_l1_ l11l11ll_l1_
		elif l1l1l1_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠧ⳻") in html:
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⳼"),html,re.DOTALL)
		else:
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ⳽"),html,re.DOTALL)
	if not l1ll1l1_l1_: return
	block = l1ll1l1_l1_[0]
	if not items:
		items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⳾"),block,re.DOTALL)
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⳿"),block,re.DOTALL)
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"๋ࠬิศ้าอࠬⴀ"),l1l1l1_l1_ (u"࠭แ๋ๆ่ࠫⴁ"),l1l1l1_l1_ (u"ࠧศ฼้๎ฮ࠭ⴂ"),l1l1l1_l1_ (u"ࠨๅ็๎อ࠭ⴃ"),l1l1l1_l1_ (u"ࠩส฽้อๆࠨⴄ"),l1l1l1_l1_ (u"๋ࠪิอแࠨⴅ"),l1l1l1_l1_ (u"๊ࠫฮวาษฬࠫⴆ"),l1l1l1_l1_ (u"ࠬ฿ัืࠩⴇ"),l1l1l1_l1_ (u"࠭ๅ่ำฯห๋࠭ⴈ"),l1l1l1_l1_ (u"ࠧศๆห์๊࠭ⴉ")]
	for l111ll_l1_,title,img in items:
		l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠨ࠱ࠪⴊ"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬⴋ"),title,re.DOTALL)
		if l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬⴌ") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴍ"),menu_name+title,l111ll_l1_,83,img)
		elif l1l1l1_l1_ (u"ูࠬไศี็ࠫⴎ") not in url and any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬⴏ"),menu_name+title,l111ll_l1_,82,img)
		elif l1llll1_l1_ and l1l1l1_l1_ (u"ࠧศๆะ่็ฯࠧⴐ") in title:
			title = l1l1l1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧⴑ") + l1llll1_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴒ"),menu_name+title,l111ll_l1_,83,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬⴓ") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴔ"),menu_name+title,l111ll_l1_,81,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴕ"),menu_name+title,l111ll_l1_,83,img)
	if l111l1111_l1_==l1l1l1_l1_ (u"࠭ࠧⴖ"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫⴗ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪⴘ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠤࠥⴙ"): continue
				#title = unescapeHTML(title)
				if title!=l1l1l1_l1_ (u"ࠪࠫⴚ"): addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴛ"),menu_name+l1l1l1_l1_ (u"ࠬ฻แฮหࠣࠫⴜ")+title,l111ll_l1_,81)
	if l1l1l1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ⴝ") in url or l1l1l1_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨⴞ") in url:
		if l1l1l1_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨⴟ") in url:
			url = url.replace(l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩⴠ"),l1l1l1_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫⴡ"))+l1l1l1_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠸࠰ࠨⴢ")
		elif l1l1l1_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ⴣ") in url:
			url,offset = url.split(l1l1l1_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨⴤ"))
			offset = int(offset)+20
			url = url+l1l1l1_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩⴥ")+str(offset)
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⴦"),menu_name+l1l1l1_l1_ (u"๊๊ࠩฬ้ࠠศๆ่ึ๏ีࠧⴧ"),url,81)
	return
def l11l1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ⴨"),url,l1l1l1_l1_ (u"ࠫࠬ⴩"),l1l1l1_l1_ (u"ࠬ࠭⴪"),l1l1l1_l1_ (u"࠭ࠧ⴫"),l1l1l1_l1_ (u"ࠧࠨ⴬"),l1l1l1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩⴭ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࡂࡺࡕࡨࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⴮"),html,re.DOTALL)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡱ࡯ࡳࡵ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⴯"),html,re.DOTALL)
	# l111l1_l1_
	if l1ll11l_l1_ and l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭ⴰ") not in url:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⴱ"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴲ"),menu_name+title,l111ll_l1_,83,img)
	# l1ll1_l1_
	elif l1ll111_l1_:
		img = re.findall(l1l1l1_l1_ (u"ࠧࠣ࡫ࡰࡥ࡬࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ⴳ"),html,re.DOTALL)
		img = img[0]
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⴴ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			#title = title.replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬⴵ"),l1l1l1_l1_ (u"ࠪࠫⴶ")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭ⴷ"))
			addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⴸ"),menu_name+title,l111ll_l1_,82,img)
	return
def PLAY(url):
	url2 = url.replace(l1l1l1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨⴹ"),l1l1l1_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨⴺ"))
	url2 = url2.replace(l1l1l1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬⴻ"),l1l1l1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬⴼ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧⴽ"),url2,l1l1l1_l1_ (u"ࠫࠬⴾ"),l1l1l1_l1_ (u"ࠬ࠭ⴿ"),l1l1l1_l1_ (u"࠭ࠧⵀ"),l1l1l1_l1_ (u"ࠧࠨⵁ"),l1l1l1_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬⵂ"))
	html = response.content
	l11l1l_l1_ = SERVER(url2,l1l1l1_l1_ (u"ࠩࡸࡶࡱ࠭ⵃ"))
	l11l1_l1_ = []
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩⵄ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧⵅ"),html,re.DOTALL)
		l1l11l1l_l1_ = l1l11l1l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧ࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲ࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧⵆ"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l1l1_l1_ (u"࠭࡜࡯ࠩⵇ"),l1l1l1_l1_ (u"ࠧࠨⵈ")).strip(l1l1l1_l1_ (u"ࠨࠢࠪⵉ"))
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡕࡲࡡࡺࡧࡵࡃࡸ࡫ࡲࡷࡧࡵࡁࠬⵊ")+server+l1l1l1_l1_ (u"ࠪࠪࡵࡵࡳࡵࡋࡇࡁࠬⵋ")+l1l11l1l_l1_+l1l1l1_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬⵌ")
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ⵍ")+title+l1l1l1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧⵎ")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡦࡲࡻࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫⵏ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⵐ"),block,re.DOTALL)
		for l111ll_l1_,name in items:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪⵑ")+name+l1l1l1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧⵒ")
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩⵓ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⵔ"),url)
	return
l1l1l1_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡐࡍࡃ࡜ࡣࡔࡒࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࡦࡤࡸࡦࠦ࠽ࠡࡽ࡚ࠪ࡮࡫ࡷࠨ࠼࠴ࢁࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࠾ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫࢂࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡒࡒࡗ࡙࠭ࠬࡶࡴ࡯࠰ࡩࡧࡴࡢ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠊࠊࠥࠣࡻࡦࡺࡣࡩࠢ࡯࡭ࡳࡱࡳࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡹࡤࡸࡨ࡮ࡁࡳࡧࡤࡑࡦࡹࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡲࡼࡲ࡯ࡢࡦ࠰ࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡸ࡫ࡲ࠮ࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩ࠱ࡷࡵࡢ࡮࡬ࡸࡾ࠲࡬ࡪࡰ࡮ࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡳ࠭ࠬࠨࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ࠱ࠧࡠࡡࡢࡣࠬ࠱ࡱࡶࡣ࡯࡭ࡹࡿࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠊࠊ࡫ࡩࠤࡱ࡫࡮ࠩ࡮࡬ࡲࡰࡒࡉࡔࡖࠬࡁࡂ࠶࠺ࠡࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠭ࠩส่ึอศุࠢ็๎ุࠦแ๋้ࠣๅ๏ี๊้ࠩࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࡩ࡮ࡲࡲࡶࡹࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠌࠌࠍࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦⵕ")
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨⵖ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩⵗ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫⵘ"),l1l1l1_l1_ (u"ࠪ࠱ࠬⵙ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭ⵚ")+search+l1l1l1_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫⵛ")
	l11l11_l1_(url)
	return
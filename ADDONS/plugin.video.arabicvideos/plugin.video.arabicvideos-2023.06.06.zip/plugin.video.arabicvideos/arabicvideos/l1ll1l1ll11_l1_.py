# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ⼪")
menu_name = l1l1l1_l1_ (u"ࠧࡠࡍࡗࡏࡤ࠭⼫")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ⼬"),l1l1l1_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ⼭"),l1l1l1_l1_ (u"ࠪห้ษโิษ่ࠫ⼮")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l11l11_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l11_l1_(url,text)
	elif mode==674: results = l1ll11_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ⼯"),l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭⼰"),l1l1l1_l1_ (u"࠭ࠧ⼱"),l1l1l1_l1_ (u"ࠧࠨ⼲"),l1l1l1_l1_ (u"ࠨࠩ⼳"),l1l1l1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⼴"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼵"),menu_name+l1l1l1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⼶"),l1l1l1_l1_ (u"ࠬ࠭⼷"),679,l1l1l1_l1_ (u"࠭ࠧ⼸"),l1l1l1_l1_ (u"ࠧࠨ⼹"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⼺"))
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⼻"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⼼"),l1l1l1_l1_ (u"ࠫࠬ⼽"),9999)
	#addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼾"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⼿")+menu_name+l1l1l1_l1_ (u"ࠧศๆ่้๏ุษࠨ⽀"),l1l11l_l1_,671,l1l1l1_l1_ (u"ࠨࠩ⽁"),l1l1l1_l1_ (u"ࠩࠪ⽂"),l1l1l1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ⽃"))
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⽄"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⽅")+menu_name+l1l1l1_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬ⽆"),l1l11l_l1_,671,l1l1l1_l1_ (u"ࠧࠨ⽇"),l1l1l1_l1_ (u"ࠨࠩ⽈"),l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⽉"))
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⽊"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⽋")+menu_name+l1l1l1_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ⽌"),l1l11l_l1_,671,l1l1l1_l1_ (u"࠭ࠧ⽍"),l1l1l1_l1_ (u"ࠧࠨ⽎"),l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ⽏"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽐"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⽑")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ⽒"),l1l11l_l1_,671,l1l1l1_l1_ (u"ࠬ࠭⽓"),l1l1l1_l1_ (u"࠭ࠧ⽔"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ⽕"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⽖"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⽗"),l1l1l1_l1_ (u"ࠪࠫ⽘"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⽙"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⽚"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		if title==l1l1l1_l1_ (u"࠭วๅลๅืฬ๋ࠧ⽛"): mode = 675
		else: mode = 674
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⽜"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⽝")+menu_name+title,l111ll_l1_,mode)
	#addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⽞"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⽟"),l1l1l1_l1_ (u"ࠫࠬ⽠"),9999)
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ⽡"),html,re.DOTALL)
	#block = l1ll1l1_l1_[0]
	#l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ⽢"),html,re.DOTALL)
	#for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠧࠨ⽣"))
	#items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⽤"),block,re.DOTALL)
	#for l111ll_l1_,title in items:
	#	if title in l1l1ll_l1_: continue
	#	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽥"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⽦")+menu_name+title,l111ll_l1_,674)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⽧"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⽨"),l1l1l1_l1_ (u"࠭ࠧ⽩"),9999)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ⽪"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡤࡵࡳࡼࡹࡥ࠯ࡪࡷࡱࡱ࠭⽫"),l1l1l1_l1_ (u"ࠩࠪ⽬"),l1l1l1_l1_ (u"ࠪࠫ⽭"),l1l1l1_l1_ (u"ࠫࠬ⽮"),l1l1l1_l1_ (u"ࠬ࠭⽯"),l1l1l1_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ⽰"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰࡬ࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࡀࠪ⽱"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⽲"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽳"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⽴")+menu_name+title,l111ll_l1_,674,img)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ⽵"),url,l1l1l1_l1_ (u"ࠬ࠭⽶"),l1l1l1_l1_ (u"࠭ࠧ⽷"),l1l1l1_l1_ (u"ࠧࠨ⽸"),l1l1l1_l1_ (u"ࠨࠩ⽹"),l1l1l1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⽺"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⽻"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ⽼"),l1l1l1_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ⽽"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⽾"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠧࠨ⽿"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⾀"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⾁"),l1l1l1_l1_ (u"ࠪࠫ⾂"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⾃"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"ࠬࡀࠠࠨ⾄")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾅"),menu_name+title,l111ll_l1_,671)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⾆"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⾇"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⾈"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⾉"),l1l1l1_l1_ (u"ࠫࠬ⾊"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⾋"),menu_name+title,l111ll_l1_,671)
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"࠭ࠧ⾌")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ⾍"),l1l1l1_l1_ (u"ࠨࠩ⾎"),request,url)
	if request==l1l1l1_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ⾏"):
		url,search = url.split(l1l1l1_l1_ (u"ࠪࡃࠬ⾐"),1)
		data = l1l1l1_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ⾑")+search
		headers = {l1l1l1_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⾒"):l1l1l1_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭⾓")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡑࡑࡖࡘࠬ⾔"),url,data,headers,l1l1l1_l1_ (u"ࠨࠩ⾕"),l1l1l1_l1_ (u"ࠩࠪ⾖"),l1l1l1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⾗"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ⾘"),url,l1l1l1_l1_ (u"ࠬ࠭⾙"),l1l1l1_l1_ (u"࠭ࠧ⾚"),l1l1l1_l1_ (u"ࠧࠨ⾛"),l1l1l1_l1_ (u"ࠨࠩ⾜"),l1l1l1_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⾝"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠪࠫ⾞"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ⾟"))
	if request==l1l1l1_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ⾠"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⾡"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠧࠨ⾢"),l111ll_l1_,title))
	elif request==l1l1l1_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⾣"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⾤"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⾥"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⾦"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ⾧"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⾨"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ⾩"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ⾪"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⾫"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l1l1l1_l1_ (u"ࠪࠫ⾬"),l111ll_l1_,title))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⾭"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⾮"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"࠭ๅีษ๊ำฮ࠭⾯"),l1l1l1_l1_ (u"ࠧโ์็้ࠬ⾰"),l1l1l1_l1_ (u"ࠨษ฽๊๏ฯࠧ⾱"),l1l1l1_l1_ (u"ࠩๆ่๏ฮࠧ⾲"),l1l1l1_l1_ (u"ࠪห฾๊ว็ࠩ⾳"),l1l1l1_l1_ (u"ࠫ์ีวโࠩ⾴"),l1l1l1_l1_ (u"๋ࠬศศำสอࠬ⾵"),l1l1l1_l1_ (u"ู࠭าุࠪ⾶"),l1l1l1_l1_ (u"ࠧๆ้ิะฬ์ࠧ⾷"),l1l1l1_l1_ (u"ࠨษ็ฬํ๋ࠧ⾸"),l1l1l1_l1_ (u"่ࠩืึำ๊สࠩ⾹"),l1l1l1_l1_ (u"ࠪๅ้๋ࠧ⾺")]
	for img,l111ll_l1_,title in items:
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠫ࠴࠭⾻"))
		#if l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⾼") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ⾽")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ⾾"))
		#if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭⾿") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ⿀")+img.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬ⿁"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭⿂"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ⿃"),title,re.DOTALL)
		#addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⿄"),menu_name+title,l111ll_l1_,672,img)
		if any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⿅"),menu_name+title,l111ll_l1_,672,img)
		elif request==l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⿆"):
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⿇"),menu_name+title,l111ll_l1_,672,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⿈") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿉"),menu_name+title,l111ll_l1_,673,img)
				l1l1_l1_.append(title)
		elif l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⿊") in l111ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿋"),menu_name+title,l111ll_l1_,671,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⿌"),menu_name+title,l111ll_l1_,673,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⿍"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⿎"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if l111ll_l1_==l1l1l1_l1_ (u"ࠪࠧࠬ⿏"): continue
			if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⿐") not in l111ll_l1_:
				url2 = url.rsplit(l1l1l1_l1_ (u"ࠬ࠵ࠧ⿑"),1)[0]
				l111ll_l1_ = url2+l1l1l1_l1_ (u"࠭࠯ࠨ⿒")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ⿓"))
			title = unescapeHTML(title)
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⿔"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨ⿕")+title,l111ll_l1_,671)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ⿖"),l1l1l1_l1_ (u"ࠫࠬ⿗"),l1lll_l1_,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ⿘"),url,l1l1l1_l1_ (u"࠭ࠧ⿙"),l1l1l1_l1_ (u"ࠧࠨ⿚"),l1l1l1_l1_ (u"ࠨࠩ⿛"),l1l1l1_l1_ (u"ࠩࠪ⿜"),l1l1l1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ⿝"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱࡭࡫ࡡࡥ࡫ࡱ࡫ࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠨ⿞"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡹࡃࡷࡷࡸࡴࡴࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⿟"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿠"),menu_name+title,l111ll_l1_,671,l1l1l1_l1_ (u"ࠧࠨ⿡"),l1l1l1_l1_ (u"ࠨࠩ⿢"),l1l1l1_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⿣"))
	if not l1ll_l1_: l11l11_l1_(url,l1l1l1_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⿤"))
	return
#l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l1l1ll1lll_l1_.l1llll111l_l1_?l1ll1l1l1l1_l1_=l1ll1l1l11l_l1_
#l1ll1lll_l1_://l1ll1l1ll1l_l1_.l1ll1l1l1ll_l1_.l1lll1l11_l1_/l1l1111ll_l1_/l11ll1l1l_l1_.l1llll111l_l1_?l1ll1l1l1l1_l1_=l1ll1l1l11l_l1_
def PLAY(url):
	l111l11_l1_ = []
	#url = l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭࠵แ๋ๆ่࠱่ืส้่࠰ฬฬืศ๋࠯ไ๎࠲ฺ๋ศ็ิอ࠲๋สๅล็สฮ࠳ๅะสࡢࡨ࠾࠽࠵ࡤࡤ࠺࠹࠸࠴ࡨࡵ࡯࡯ࠫ⿥")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ⿦"),url,l1l1l1_l1_ (u"࠭ࠧ⿧"),l1l1l1_l1_ (u"ࠧࠨ⿨"),l1l1l1_l1_ (u"ࠨࠩ⿩"),l1l1l1_l1_ (u"ࠩࠪ⿪"),l1l1l1_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⿫"))
	html = response.content
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬࡪࡱࡧࡳࡩࡲ࡯ࡥࡾ࡫ࡲࠨ⿬"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⿭"),block,re.DOTALL)
		for l111ll_l1_,l11ll111_l1_ in l1ll_l1_:
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠࠩ⿮")+l11ll111_l1_
			l111l11_l1_.append(l111ll_l1_)
	# l11ll1l1l_l1_ l1ll_l1_
	l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⿯"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠣࡨ࡬ࡰࡪࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ⿰"),html,re.DOTALL)
	if l1ll_l1_:
		l111ll_l1_ = l1ll_l1_[0]
		if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⿱") not in l111ll_l1_: l111ll_l1_ = l1l1l1_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ⿲")+l111ll_l1_
		l111l11_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ⿳"))
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⿴"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⿵"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨ⿶"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩ⿷"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫ⿸"),l1l1l1_l1_ (u"ࠪ࠯ࠬ⿹"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ⿺")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⿻"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ⿼")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ⿽"))
	return
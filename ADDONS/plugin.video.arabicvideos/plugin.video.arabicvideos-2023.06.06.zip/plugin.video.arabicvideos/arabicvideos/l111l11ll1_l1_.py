# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ↩")
menu_name = l1l1l1_l1_ (u"ࠨࡡࡈࡋࡉࡥࠧ↪")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ู่ࠩฬืูสࠩ↫"),l1l1l1_l1_ (u"ࠪหาีหࠡษ็ฬึอๅอࠩ↬"),l1l1l1_l1_ (u"ࠫฬำฯฬࠢส่ฬู๊ศสࠪ↭"),l1l1l1_l1_ (u"ࠬอไาศํื๏ฯࠧ↮"),l1l1l1_l1_ (u"࠭วฮัฮࠤฬ๊ว฻ษ้ํࠬ↯")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l11l11_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l11l1ll_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ↰"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩ↱"),l1l1l1_l1_ (u"ࠩࠪ↲"),l1l1l1_l1_ (u"ࠪࠫ↳"),l1l1l1_l1_ (u"ࠫࠬ↴"),l1l1l1_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ↵"))
	html = response.content
	l11l1l_l1_ = SERVER(l1l11l_l1_,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ↶"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ↷"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ↸"),l1l1l1_l1_ (u"ࠩࠪ↹"),449,l1l1l1_l1_ (u"ࠪࠫ↺"),l1l1l1_l1_ (u"ࠫࠬ↻"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ↼"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭↽"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ↾")+menu_name+l1l1l1_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ↿"),l1l11l_l1_,441)
	addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⇀"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⇁"),l1l1l1_l1_ (u"ࠫࠬ⇂"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡣࡲ࡫࡮ࡶࡡࡵ࡭࡬࡮ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⇃"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⇄"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		if l111ll_l1_==l1l1l1_l1_ (u"ࠧࠤࠩ⇅"): continue
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⇆"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⇇")+menu_name+title,l111ll_l1_,441)
	return
def l11l11_l1_(url,l11l1l11_l1_=l1l1l1_l1_ (u"ࠪࠫ⇈")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ⇉"),url,l1l1l1_l1_ (u"ࠬ࠭⇊"),l1l1l1_l1_ (u"࠭ࠧ⇋"),l1l1l1_l1_ (u"ࠧࠨ⇌"),l1l1l1_l1_ (u"ࠨࠩ⇍"),l1l1l1_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⇎"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⇏"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫࡁࡲࡩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⇐"),block,re.DOTALL)
	for l111ll_l1_,title,img in items:
		if l1l1l1_l1_ (u"ࠬ࠵ࡵࡳ࡮࠲ࠫ⇑") in l111ll_l1_: continue
		elif l1l1l1_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ⇒") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⇓"),menu_name+title,l111ll_l1_,443,img)
		elif l1l1l1_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ⇔") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇕"),menu_name+title,l111ll_l1_,443,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⇖"),menu_name+title,l111ll_l1_,442,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⇗"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⇘"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇙"),menu_name+l1l1l1_l1_ (u"ࠧึใะอࠥ࠭⇚")+title,l111ll_l1_,441)
	return
l1l1l1_l1_ (u"ࠣࠤࠥࠎࠎࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳࠡ࠿ࠣ࡟ࡢࠐࠉࡷ࡫ࡧࡩࡴࡒࡉࡔࡖࠣࡁࠥࡡࠧๆึส๋ิฯࠧ࠭ࠩไ๎้๋ࠧ࠭ࠩส฾๋๐ษࠨ࠮ࠪ็้๐ศࠨ࠮ࠪห฾๊ว็ࠩ࠯ࠫ์ีวโࠩ࠯๊ࠫฮวาษฬࠫ࠱ู࠭าุࠪ࠰๋ࠬ็าฮส๊ࠬ࠲ࠧศๆห์๊࠭࡝ࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧ࠯࡭ࡲ࡭ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡵ࡯ࡧࡶࡧࡦࡶࡥࡉࡖࡐࡐ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡰ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧ࠰ࠩࠬࠎࠎࠏࡥࡱ࡫ࡶࡳࡩ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥࡧ࡮ࡺࠪࡹࡥࡱࡻࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࠣࡪࡴࡸࠠࡷࡣ࡯ࡹࡪࠦࡩ࡯ࠢࡹ࡭ࡩ࡫࡯ࡍࡋࡖࡘ࠮ࡀࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡹ࡭ࡩ࡫࡯ࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠷࠲ࡩ࡮ࡩࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࡪࡶࡩࡴࡱࡧࡩࠥࡧ࡮ࡥࠢࠪห้ำไใหࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬࡥࡍࡐࡆࡢࠫࠥ࠱ࠠࡦࡲ࡬ࡷࡴࡪࡥ࡜࠲ࡠࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࠢࡱࡳࡹࠦࡩ࡯ࠢࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠿ࠐࠉࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠹ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠊࠋࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࠭࠯ࡢࡵࡶࡩࡲࡨ࡬ࡺ࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠷ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࡦ࡮࡬ࡪࠥ࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠷࠱࡯࡭ࡨࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠳࠭࡫ࡰ࡫࠮ࠐࠉࡪࡨࠣࡷࡪࡷࡵࡦࡰࡦࡩࡂࡃࠧࠨ࠼ࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ⇛")
def l11l1ll_l1_(url):
	data = {l1l1l1_l1_ (u"࡙ࠩ࡭ࡪࡽࠧ⇜"):1}
	headers = {l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⇝"):l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⇞")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡖࡏࡔࡖࠪ⇟"),url,data,headers,l1l1l1_l1_ (u"࠭ࠧ⇠"),l1l1l1_l1_ (u"ࠧࠨ⇡"),l1l1l1_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⇢"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧ⇣"),html,re.DOTALL)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ⇤"),html,re.DOTALL)
	# l111l1_l1_
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⇥"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇦"),menu_name+title,l111ll_l1_,443,img)
	# l1ll1_l1_
	elif l1ll111_l1_:
		img = re.findall(l1l1l1_l1_ (u"࠭ࠢࡰࡩ࠽࡭ࡲࡧࡧࡦࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⇧"),html,re.DOTALL)
		img = img[0]
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⇨"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠨ࡞ࡱࠫ⇩"),l1l1l1_l1_ (u"ࠩࠪ⇪")).strip(l1l1l1_l1_ (u"ࠪࠤࠬ⇫"))
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⇬"),menu_name+title,l111ll_l1_,442,img)
	return
def PLAY(url):
	data = {l1l1l1_l1_ (u"ࠬ࡜ࡩࡦࡹࠪ⇭"):1}
	headers = {l1l1l1_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⇮"):l1l1l1_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⇯")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡒࡒࡗ࡙࠭⇰"),url,data,headers,l1l1l1_l1_ (u"ࠩࠪ⇱"),l1l1l1_l1_ (u"ࠪࠫ⇲"),l1l1l1_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⇳"))
	html = response.content
	l11l1_l1_ = []
	# l1l1111ll_l1_ l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࡆࡸࡥࡢࡏࡤࡷࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⇴"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ⇵"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			title = title.replace(l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ⇶"),l1l1l1_l1_ (u"ࠨࠩ⇷")).strip(l1l1l1_l1_ (u"ࠩࠣࠫ⇸"))
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⇹")+title+l1l1l1_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⇺")
			l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡤࡰࡰࡺࡰࡴࡧࡤ࠮ࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⇻"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⇼"),block,re.DOTALL)
		for title,l11ll111_l1_,l111ll_l1_ in items:
			l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"ࠧ࡝ࡰࠪ⇽"),l1l1l1_l1_ (u"ࠨࠩ⇾"))
			l111ll_l1_ = l111ll_l1_+l1l1l1_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⇿")+title+l1l1l1_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ∀")+l1l1l1_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ∁")+l11ll111_l1_
			l11l1_l1_.append(l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ∂"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ∃"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠧࠨ∄"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠨࠩ∅"): return
	search = search.replace(l1l1l1_l1_ (u"ࠩࠣࠫ∆"),l1l1l1_l1_ (u"ࠪ࠯ࠬ∇"))
	#search = unescapeHTML(search)
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ∈")+search
	l11l11_l1_(url)
	return
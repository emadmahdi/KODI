# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ᝱")
menu_name = l1l1l1_l1_ (u"ࠪࡣࡈࡉࡂࡠࠩᝲ")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭ᝳ"),l1l1l1_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭᝴"),l1l1l1_l1_ (u"࠭สิฮํ่ࠬ᝵"),l1l1l1_l1_ (u"ฺࠧำฺ๋๋ࠥีศำ฼อࠬ᝶")]
def MAIN(mode,url,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l11l11_l1_(url,text)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l11_l1_(url,text)
	elif mode==634: results = l1ll11_l1_(url)
	elif mode==639: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ᝷"),l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪ᝸"),l1l1l1_l1_ (u"ࠪࠫ᝹"),l1l1l1_l1_ (u"ࠫࠬ᝺"),l1l1l1_l1_ (u"ࠬ࠭᝻"),l1l1l1_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ᝼"))
	html = response.content
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᝽"),menu_name+l1l1l1_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ᝾"),l1l1l1_l1_ (u"ࠩࠪ᝿"),639,l1l1l1_l1_ (u"ࠪࠫក"),l1l1l1_l1_ (u"ࠫࠬខ"),l1l1l1_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩគ"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫឃ"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧង"),l1l1l1_l1_ (u"ࠨࠩច"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩឆ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬជ")+menu_name+l1l1l1_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬឈ"),l1l11l_l1_,631,l1l1l1_l1_ (u"ࠬ࠭ញ"),l1l1l1_l1_ (u"࠭ࠧដ"),l1l1l1_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩឋ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨឌ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫឍ")+menu_name+l1l1l1_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩណ"),l1l11l_l1_,631,l1l1l1_l1_ (u"ࠫࠬត"),l1l1l1_l1_ (u"ࠬ࠭ថ"),l1l1l1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬទ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧធ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪន")+menu_name+l1l1l1_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨប"),l1l11l_l1_,631,l1l1l1_l1_ (u"ࠪࠫផ"),l1l1l1_l1_ (u"ࠫࠬព"),l1l1l1_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩភ"))
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ម"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩយ")+menu_name+l1l1l1_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬរ"),l1l11l_l1_,631,l1l1l1_l1_ (u"ࠩࠪល"),l1l1l1_l1_ (u"ࠪࠫវ"),l1l1l1_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ឝ"))
	#addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪឞ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ស"),l1l1l1_l1_ (u"ࠧࠨហ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ឡ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪអ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		if title==l1l1l1_l1_ (u"ࠪวาีหࠡษ็ั้่วหࠩឣ"): mode,request = 631,l1l1l1_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪឤ")
		else: mode,request = 634,l1l1l1_l1_ (u"ࠬ࠭ឥ")
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឦ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩឧ")+menu_name+title,l111ll_l1_,mode,l1l1l1_l1_ (u"ࠨࠩឨ"),l1l1l1_l1_ (u"ࠩࠪឩ"),request)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨឪ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫឫ"),l1l1l1_l1_ (u"ࠬ࠭ឬ"),9999)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪឭ"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧឮ"),html,re.DOTALL)
	for l11ll_l1_ in l1ll1l1_l1_: block = block.replace(l11ll_l1_,l1l1l1_l1_ (u"ࠨࠩឯ"))
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧឰ"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		if title in l1l1ll_l1_: continue
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪឱ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ឲ")+menu_name+title,l111ll_l1_,634)
	return
def l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩឳ"),url,l1l1l1_l1_ (u"࠭ࠧ឴"),l1l1l1_l1_ (u"ࠧࠨ឵"),l1l1l1_l1_ (u"ࠨࠩា"),l1l1l1_l1_ (u"ࠩࠪិ"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪី"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨឹ"),html,re.DOTALL)
	if l1ll11l_l1_:
		block = l1ll11l_l1_[0]
		block = block.replace(l1l1l1_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ឺ"),l1l1l1_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬុ"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫូ"),block,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = [(l1l1l1_l1_ (u"ࠨࠩួ"),block)]
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧើ"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨឿ"),l1l1l1_l1_ (u"ࠫࠬៀ"),9999)
		for l11lll_l1_,block in l1ll1l1_l1_:
			items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪេ"),block,re.DOTALL)
			if l11lll_l1_: l11lll_l1_ = l11lll_l1_+l1l1l1_l1_ (u"࠭࠺ࠡࠩែ")
			for l111ll_l1_,title in items:
				title = l11lll_l1_+title
				addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧៃ"),menu_name+title,l111ll_l1_,631)
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬោ"),html,re.DOTALL)
	if l1ll111_l1_:
		block = l1ll111_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫៅ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨំ"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫះ"),l1l1l1_l1_ (u"ࠬ࠭ៈ"),9999)
			for l111ll_l1_,title in items:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭៉"),menu_name+title,l111ll_l1_,631)
	l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠵ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡵࡳ࠭ࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡪࡨࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠵࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠸ࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫ࡭ࡹ࡫࡭ࡴࠫ࠿࠷࠵ࡀࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩ࡯࡭ࡳࡱࠧ࠭ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯ࠫࠬ࠲࠹࠺࠻࠼࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠶࠴࠳ࠬࠎࠎ࡯ࡦࠡࡰࡲࡸࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠴ࠤࡦࡴࡤࠡࡰࡲࡸࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠵ࠤࡦࡴࡤࠡࡰࡲࡸࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠶࠾࡚ࠥࡉࡕࡎࡈࡗ࠭ࡻࡲ࡭ࠫࠍࠍࠧࠨࠢ៊")
	if not l1ll11l_l1_ and not l1ll111_l1_: l11l11_l1_(url)
	return
def l11l11_l1_(url,request=l1l1l1_l1_ (u"ࠨࠩ់")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ៌"),l1l1l1_l1_ (u"ࠪࠫ៍"),request,url)
	if request==l1l1l1_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ៎"):
		url,search = url.split(l1l1l1_l1_ (u"ࠬࡅࠧ៏"),1)
		data = l1l1l1_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ័")+search
		headers = {l1l1l1_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭៑"):l1l1l1_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ្")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ៓"),url,data,headers,l1l1l1_l1_ (u"ࠪࠫ។"),l1l1l1_l1_ (u"ࠫࠬ៕"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ៖"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪៗ"),url,l1l1l1_l1_ (u"ࠧࠨ៘"),l1l1l1_l1_ (u"ࠨࠩ៙"),l1l1l1_l1_ (u"ࠩࠪ៚"),l1l1l1_l1_ (u"ࠪࠫ៛"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪៜ"))
	html = response.content
	block,items = l1l1l1_l1_ (u"ࠬ࠭៝"),[]
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ៞"))
	if request==l1l1l1_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ៟"):
		block = html
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ០"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,l1l1l1_l1_ (u"ࠩࠪ១")))
	elif request==l1l1l1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ២"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡶࡴࡻࡳࡦ࡮ࡢࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ៣"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠬ࠭ࠧࠣࡲࡲࡷࡹࡈ࡬ࡰࡥ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠨࠩࠪ៤"),block,re.DOTALL)
	elif request==l1l1l1_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ៥"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ៦"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	elif request==l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ៧"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ៨"),html,re.DOTALL)
		if len(l1ll1l1_l1_)>1: block = l1ll1l1_l1_[1]
	elif request==l1l1l1_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ៩"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭៪"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ៫"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,l1l1l1_l1_ (u"࠭ࠧ៬")))
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ៭"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
	if block and not items: items = re.findall(l1l1l1_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ៮"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1111_l1_ = [l1l1l1_l1_ (u"ุ่ࠩฬํฯสࠩ៯"),l1l1l1_l1_ (u"ࠪๅ๏๊ๅࠨ៰"),l1l1l1_l1_ (u"ࠫฬเๆ๋หࠪ៱"),l1l1l1_l1_ (u"้ࠬไ๋สࠪ៲"),l1l1l1_l1_ (u"࠭วฺๆส๊ࠬ៳"),l1l1l1_l1_ (u"่ࠧัสๅࠬ៴"),l1l1l1_l1_ (u"ࠨ็หหึอษࠨ៵"),l1l1l1_l1_ (u"ࠩ฼ี฻࠭៶"),l1l1l1_l1_ (u"้ࠪ์ืฬศ่ࠪ៷"),l1l1l1_l1_ (u"ࠫฬ๊ศ้็ࠪ៸"),l1l1l1_l1_ (u"๋ࠬำาฯํอࠬ៹")]
	for l111ll_l1_,title,img in items:
		#LOG_THIS(l1l1l1_l1_ (u"࠭ࠧ៺"),l111ll_l1_)
		#l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ៻"))
		#if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭៼") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ៽")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬ៾"))
		#if l1l1l1_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ៿") not in img: img = l11l1l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ᠀")+img.strip(l1l1l1_l1_ (u"࠭࠯ࠨ᠁"))
		#l111ll_l1_ = unescapeHTML(l111ll_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩ᠂"))
		title = title.replace(l1l1l1_l1_ (u"ࠨࠢึ๎๊อࠠไๆ๋ฬࠬ᠃"),l1l1l1_l1_ (u"ࠩࠪ᠄"))
		title = title.replace(l1l1l1_l1_ (u"ࠪࠤฬ๎ๆࠡๆส๎๋࠭᠅"),l1l1l1_l1_ (u"ࠫࠬ᠆"))
		l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ᠇"),title,re.DOTALL)
		if l1l1l1_l1_ (u"࠭ࡗࡘࡇࠪ᠈") in title: continue
		elif any(value in title for value in l1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᠉"),menu_name+title,l111ll_l1_,632,img)
		elif request==l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ᠊"):
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᠋"),menu_name+title,l111ll_l1_,632,img)
		elif l1llll1_l1_:
			title = l1l1l1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ᠌") + l1llll1_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠍"),menu_name+title,l111ll_l1_,633,img)
				l1l1_l1_.append(title)
		#elif l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ᠎") in l111ll_l1_:
		#	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᠏"),menu_name+title,l111ll_l1_,631,img)
		else: addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠐"),menu_name+title,l111ll_l1_,633,img)
	if 1: #if request not in [l1l1l1_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ᠑"),l1l1l1_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ᠒")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᠓"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᠔"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				if l111ll_l1_==l1l1l1_l1_ (u"ࠬࠩࠧ᠕"): continue
				l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ᠖")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠧ࠰ࠩ᠗"))
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠘"),menu_name+l1l1l1_l1_ (u"ุࠩๅาฯࠠࠨ᠙")+title,l111ll_l1_,631)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ᠚"),l1l1l1_l1_ (u"ࠫࠬ᠛"),l1lll_l1_,url)
	l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ᠜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ᠝"),url,l1l1l1_l1_ (u"ࠧࠨ᠞"),l1l1l1_l1_ (u"ࠨࠩ᠟"),l1l1l1_l1_ (u"ࠩࠪᠠ"),l1l1l1_l1_ (u"ࠪࠫᠡ"),l1l1l1_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᠢ"))
	html = response.content
	image = re.findall(l1l1l1_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᠣ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1l1_l1_ (u"࠭ࠧᠤ")
	items = []
	# l111l1_l1_
	l1l11_l1_ = False
	l1ll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᠥ"),html,re.DOTALL)
	if l1ll11l_l1_ and not l1lll_l1_:
		block = l1ll11l_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࠩࠪࡳࡳࡩ࡬ࡪࡥ࡮ࡁࠧࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬ࠯ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨᠦ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1l1_l1_ (u"ࠩࠦࠫᠧ"))
			if len(items)>1: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᠨ"),menu_name+title,url,633,img,l1l1l1_l1_ (u"ࠫࠬᠩ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪᠪ")+l1lll_l1_+l1l1l1_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᠫ"),html,re.DOTALL)
	if l1ll111_l1_ and l1l11_l1_:
		block = l1ll111_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᠬ"),block,re.DOTALL)
		items = []
		for l111ll_l1_,title in l1ll1ll_l1_: items.append((l111ll_l1_,title,img))
		if not items: items = re.findall(l1l1l1_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᠭ"),block,re.DOTALL)
		for l111ll_l1_,title,img in items:
			l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫᠮ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬᠯ"))
			title = title.replace(l1l1l1_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩᠰ"),l1l1l1_l1_ (u"ࠬࠦࠧᠱ"))
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᠲ"),menu_name+title,l111ll_l1_,632,img)
		#else:
		#	items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨᠳ"),block,re.DOTALL)
		#	for l111ll_l1_,title,img in items:
		#		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᠴ") not in l111ll_l1_: l111ll_l1_ = l11l1l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫᠵ")+l111ll_l1_.strip(l1l1l1_l1_ (u"ࠪ࠳ࠬᠶ"))
		#		addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᠷ"),menu_name+title,l111ll_l1_,632,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l11_l1_,l111l11_l1_ = [],[],[]
	# l1l1111ll_l1_ l1ll_l1_
	url2 = url.replace(l1l1l1_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᠸ"),l1l1l1_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩᠹ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫᠺ"),url2,l1l1l1_l1_ (u"ࠨࠩᠻ"),l1l1l1_l1_ (u"ࠩࠪᠼ"),l1l1l1_l1_ (u"ࠪࠫᠽ"),l1l1l1_l1_ (u"ࠫࠬᠾ"),l1l1l1_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᠿ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᡀ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠢࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠤᡁ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᡂ")+title+l1l1l1_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᡃ"))
				l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	url2 = url.replace(l1l1l1_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧᡄ"),l1l1l1_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࡲ࡫ࡴࠬᡅ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩᡆ"),url2,l1l1l1_l1_ (u"࠭ࠧᡇ"),l1l1l1_l1_ (u"ࠧࠨᡈ"),l1l1l1_l1_ (u"ࠨࠩᡉ"),l1l1l1_l1_ (u"ࠩࠪᡊ"),l1l1l1_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧᡋ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᡌ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨᡍ"),block,re.DOTALL)
		for l111ll_l1_,title in l1ll_l1_:
			if l111ll_l1_ not in l11l1_l1_:
				l111l1l11_l1_.append(l1l1l1_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᡎ")+title+l1l1l1_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᡏ"))
				l11l1_l1_.append(l111ll_l1_)
	zzz = zip(l11l1_l1_,l111l1l11_l1_)
	for l111ll_l1_,name in zzz: l111l11_l1_.append(l111ll_l1_+name)
	#selection = DIALOG_SELECT(l1l1l1_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ᡐ"),l111l11_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l11_l1_,script_name,l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᡑ"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠪࠫᡒ"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠫࠬᡓ"): return
	search = search.replace(l1l1l1_l1_ (u"ࠬࠦࠧᡔ"),l1l1l1_l1_ (u"࠭ࠫࠨᡕ"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨᡖ")+search
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨᡗ"))
	#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭ᡘ")+search
	#l11l11_l1_(url,l1l1l1_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨᡙ"))
	return
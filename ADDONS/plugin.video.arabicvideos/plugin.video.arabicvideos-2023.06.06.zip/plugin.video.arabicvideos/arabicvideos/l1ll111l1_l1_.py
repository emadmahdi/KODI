﻿# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫັ")
headers = { l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧາ") : l1l1l1_l1_ (u"ࠫࠬຳ") }
menu_name = l1l1l1_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫິ")
l1l11l_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==40: results = MENU()
	elif mode==41: results = l1ll11lll_l1_()
	elif mode==42: results = l11l1ll_l1_(url)
	elif mode==43: results = PLAY(url)
	elif mode==44: results = CATEGORIES(url,text)
	elif mode==45: results = l11l11_l1_(url,text)
	elif mode==46: results = l1ll1111l_l1_()
	elif mode==47: results = l1l1ll11l_l1_(url)
	elif mode==49: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡸࡨࠫີ"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩຶ")+menu_name+l1l1l1_l1_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣหู้๋ศำไࠫື"),l1l1l1_l1_ (u"ຸࠩࠪ"),41)
	return
	l1l1l1_l1_ (u"ࠥࠦࠧࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ࠱࠭ࠧ࠭࠶࠼࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้ฮัศ็ฯࠤฬ๊อศๆํอࠬ࠲ࠧࠨ࠮࠷࠺࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾࡫࠶ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳࡭࠸࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬ࡯ࡣࡰࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡰࡤࡱࡪ࠲࡬ࡪࡰ࡮࠰࠹࠻ࠬࠨࠩ࠯ࠫࠬ࠲ࠧ࠴ࠩࠬࠎࠎࡴࡡ࡮ࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡶࡪࡩࡥ࡯ࡶ࠰ࡨࡪ࡬ࡡࡶ࡮ࡷ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠯ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡳࡧ࡭ࡦ࡝࠳ࡡ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭࠶࠸࠰ࠬ࠭ࠬࠨࠩ࠯ࠫ࠷࠭ࠩࠋࠋࡱࡥࡲ࡫ࠠ࠾ࠢ࡞ࠫฬืิ๋ใࠣห้ฮัศ็ฯࠫࡢࠐࠉࠤࡰࡤࡱࡪࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠥࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵ࠯ࡷࡳࡵࠨ࠾࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡰࡤࡱࡪࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠰࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡴࡡ࡮ࡧ࡞࠴ࡢ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮࠷࠸࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠶ࠧࠪࠌࠌࡶࡪࡺࡵࡳࡰࠣ࡬ࡹࡳ࡬ࠋࠋູࠥࠦࠧ")
def l11l11_l1_(url,select):
	l111lll_l1_ = [l1l1l1_l1_ (u"ࠫฯ฽ศ๋ไสฮࠥอไศฮ๊ึฮࠦวๅาๆ๎ฮ຺࠭"),l1l1l1_l1_ (u"ࠬาฯ้ๆࠣห้ฮัศ็ฯࠫົ"),l1l1l1_l1_ (u"࠭ว้ไสฮࠥฮัศ็ฯ๊ฬ࠭ຼ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠧࠨຽ"),headers,l1l1l1_l1_ (u"ࠨࠩ຾"),l1l1l1_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ຿"))
	if select==l1l1l1_l1_ (u"ࠪ࠶ࠬເ"):
		l1ll111_l1_=re.findall(l1l1l1_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷ࠱ࡩ࡫ࡦࡢࡷ࡯ࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࠣࠩແ"),html,re.DOTALL)
		if l1ll111_l1_:
			block = l1ll111_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡷ࡫࡬࠾ࠤࡥࡳࡴࡱ࡭ࡢࡴ࡮ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬໂ"),block,re.DOTALL)
			for img,url,title in items:
				if not any(value in title for value in l111lll_l1_):
					title = unescapeHTML(title)
					addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ໃ"),menu_name+title,url,42,img)
	elif select==l1l1l1_l1_ (u"ࠧ࠴ࠩໄ"):
		l1l1lll11_l1_=re.findall(l1l1l1_l1_ (u"ࠨࡣࡵࡧ࡭࡯ࡶࡦ࠯ࡥࡳࡽ࠮࠮ࠫࡁࠬࡷࡨࡸࡩࡱࡶࠪ໅"),html,re.DOTALL)
		if l1l1lll11_l1_:
			block = l1l1lll11_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"ࠩ࡫࠶࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ໆ"),block,re.DOTALL)
			for url,title,img in items:
				if not any(value in title for value in l111lll_l1_):
					title = unescapeHTML(title)
					addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ໇"),menu_name+title,url,42,img)
	l1l1lllll_l1_=re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡩ່ࠩ"),html,re.DOTALL)
	if l1l1lllll_l1_:
		block = l1l1lllll_l1_[0]
		items=re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ້࠭ࠧ࠭"),block,re.DOTALL)
		for url,title in items:
			title = unescapeHTML(title)
			title = l1l1l1_l1_ (u"࠭ีโฯฬࠤ໊ࠬ") + title
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ໋ࠧ"),menu_name+title,url,45,l1l1l1_l1_ (u"ࠨࠩ໌"),l1l1l1_l1_ (u"ࠩࠪໍ"),select)
	return
def l11l1ll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠪࠫ໎"),headers,l1l1l1_l1_ (u"ࠫࠬ໏"),l1l1l1_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭໐"))
	l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"࠭ࡥ࡯ࡶࡵࡽ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡳࡱࡣࡱࠤ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢ࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭໑"),html,re.DOTALL)
	if l1ll1l1_l1_:
		name = l1ll1l1_l1_[0]
		name = unescapeHTML(name)
		l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠧࡸࡲ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠲ࡹࡣࡳ࡫ࡳࡸ࠭࠴ࠪࡀࠫ࠱ࡩࡳࡺࡲࡺࠩ໒"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"ࠨࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡳࡥࡵࡣࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࡩ࡮ࡣࡪࡩࠧࡀࡻࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡬ࡺࡳࡢࠣ࠼ࡾࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ໓"),block,re.DOTALL)
			for l111ll_l1_,title,l1l1llll1_l1_,l1l1ll1l1_l1_,l1l1ll1ll_l1_ in items:
				l1l1ll1l1_l1_ = l1l1ll1l1_l1_.replace(l1l1l1_l1_ (u"ࠩ࡟࠳ࠬ໔"),l1l1l1_l1_ (u"ࠪ࠳ࠬ໕"))
				l1l1ll1ll_l1_ = l1l1ll1ll_l1_.replace(l1l1l1_l1_ (u"ࠫࡡ࠵ࠧ໖"),l1l1l1_l1_ (u"ࠬ࠵ࠧ໗"))
				l111ll_l1_ = l111ll_l1_.replace(l1l1l1_l1_ (u"࠭࡜࠰ࠩ໘"),l1l1l1_l1_ (u"ࠧ࠰ࠩ໙"))
				title = escapeUNICODE(title)
				l111ll_l1_ = escapeUNICODE(l111ll_l1_)
				title = title.split(l1l1l1_l1_ (u"ࠨࠢࠪ໚"))[-1]
				title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ໛") + name + l1l1l1_l1_ (u"ࠪࠤ࠲ࠦࠧໜ") + title
				duration = re.findall(l1l1l1_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫ࡣ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩໝ"),l1l1llll1_l1_,re.DOTALL)
				if duration: duration = duration[0]
				else:  duration = l1l1l1_l1_ (u"ࠬ࠭ໞ")
				addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬໟ"),menu_name+title,l111ll_l1_,43,l1l1ll1ll_l1_,duration)
		else:
			items=re.findall(l1l1l1_l1_ (u"ࠧࡪࡶࡨࡱࡵࡸ࡯ࡱ࠿ࠥࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡸ࡬ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠳࠰࠿ࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭໠"),html,re.DOTALL)
			for title,l111ll_l1_,img in items:
				img = img.replace(l1l1l1_l1_ (u"ࠨ࡞࠲ࠫ໡"),l1l1l1_l1_ (u"ࠩ࠲ࠫ໢"))
				title = escapeUNICODE(title)
				l111ll_l1_ = escapeUNICODE(l111ll_l1_)
				addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ໣"),menu_name+title,l111ll_l1_,43,img)
			#l1ll11111_l1_(url)
	else:
		l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵ࠮ࡵࡨࡶ࡮࡫ࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ໤"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭໥"),l1l1l1_l1_ (u"࠭ࠧ໦"),url, block)
			items=re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭໧"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ໨"),menu_name+title,l111ll_l1_,47)
	return
def PLAY(url):
	url = url.replace(l1l1l1_l1_ (u"ࠩࠣࠫ໩"),l1l1l1_l1_ (u"ࠪࠩ࠷࠶ࠧ໪"))
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ໫"))
	return
def l1l1ll11l_l1_(url):
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠬ࠭໬"),headers,l1l1l1_l1_ (u"࠭ࠧ໭"),l1l1l1_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡓࡐࡆ࡟࡟ࡏࡇ࡚࡛ࡊࡈࡓࡊࡖࡈ࠱࠶ࡹࡴࠨ໮"))
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡘࡌࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ໯"),html,re.DOTALL)
	PLAY(l111ll_l1_[0])
	return
def CATEGORIES(url,category):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ໰"),l1l1l1_l1_ (u"ࠪࠫ໱"),type, url)
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠫࠬ໲"),headers,l1l1l1_l1_ (u"ࠬ࠭໳"),l1l1l1_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ໴"))
	l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠧࡤࡣࡷ࠵࠳ࡧ࡜ࠩ࠲࠯ࠬ࠳࠰࠿ࠪࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦࠩ໵"),html,re.DOTALL)
	block= l1ll1l1_l1_[0]
	items=re.findall(l1l1l1_l1_ (u"ࠨࡥࡤࡸ࠶࠴ࡡ࡝ࠪࠫ࠲࠯ࡅࠩ࠭ࠪ࠱࠮ࡄ࠯ࠬ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠯ࡠࠬࡢࠧ࠭࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ໶"),block,re.DOTALL)
	l1l1lll1l_l1_=False
	l111lll_l1_ = [l1l1l1_l1_ (u"ࠩ࠰࠷࠾࠿ࠧ໷"),l1l1l1_l1_ (u"ࠪ࠹࠻࠺࠳ࠨ໸"),l1l1l1_l1_ (u"ࠫ࠷࠹࠰࠷ࠩ໹"),l1l1l1_l1_ (u"ࠬ࠻࠶࠶࠶ࠪ໺"),l1l1l1_l1_ (u"࠭࠱࠱࠹࠴࠺ࠬ໻"),l1l1l1_l1_ (u"ࠧ࠲࠲࠵࠻࠼࠭໼"),l1l1l1_l1_ (u"ࠨ࠹࠼࠸࠻࠭໽")]
	for cat,parent,title,l111ll_l1_ in items:
		if parent == category and cat not in l111lll_l1_:
			title = unescapeHTML(title)
			if l1l1l1_l1_ (u"๋ࠩๆฬะࠠษำส้ั࠭໾") in title: continue
			if l1l1l1_l1_ (u"ࠪࠬࠬ໿") in title:
				title = l1l1l1_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪༀ") + title.replace(re.findall(l1l1l1_l1_ (u"ࠬࠦ࡜ࠩ࠰࠭ࡃࡡ࠯ࠧ༁"),title)[0],l1l1l1_l1_ (u"࠭ࠧ༂"))
			url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰ࠩ༃") + l111ll_l1_
			if cat == l1l1l1_l1_ (u"ࠨ࠯࠴࠺࠺࠭༄"): title = l1l1l1_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ༅") + l1l1l1_l1_ (u"ࠪหู้๊ะุࠢฬฬำࠠีสิࠤ࠭࠼࠰ࠪࠩ༆")
			if l1l1l1_l1_ (u"ࠫ࠲࠭༇") in cat: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ༈"),menu_name+title,url,44,l1l1l1_l1_ (u"࠭ࠧ༉"),l1l1l1_l1_ (u"ࠧࠨ༊"),cat)
			else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ་"),menu_name+title,url,42)
			l1l1lll1l_l1_=True
	if not l1l1lll1l_l1_: l11l11_l1_(url,l1l1l1_l1_ (u"ࠩ࠶ࠫ༌"))
	return
def l1ll1111l_l1_():
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ།"),l1l1l1_l1_ (u"ࠫࠬ༎"),type, url)
	html = OPENURL_CACHED(REGULAR_CACHE,l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭༏"),headers,l1l1l1_l1_ (u"࠭ࠧ༐"),l1l1l1_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡓࡖࡔࡍࡒࡂࡏࡖ࠱࠶ࡹࡴࠨ༑"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡯ࡨ࡫ࡦ࠳࡭ࡦࡰࡸ࠱ࡧࡲ࡯ࡤ࡭ࠫ࠲࠯ࡅࠩ࡮ࡧࡪࡥ࠲ࡳࡥ࡯ࡷࠪ༒"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ༓"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༔"),menu_name+title,l111ll_l1_,44)
	return
def l1ll11lll_l1_():
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ฮห࠮็หหูืࠧ༕"),l1l1l1_l1_ (u"ࠬ࠭༖"),l1l1l1_l1_ (u"࠭ࠧ༗"),l1l1l1_l1_ (u"ࠧࠨ༘"),l1l1l1_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡐࡎ࡜ࡅ࠮࠳ࡶࡸ༙ࠬ"))
	items = re.findall(l1l1l1_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༚"),html,re.DOTALL)
	url = UNQUOTE(items[0])
	#DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ༛"),l1l1l1_l1_ (u"ࠫࠬ༜"),url,str(html))
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠬࡲࡩࡷࡧࠪ༝"))
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ༞"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ༟"): return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ༠"),l1l1l1_l1_ (u"ࠩࠨ࠶࠵࠭༡"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ༢") +l11ll11_l1_
	l11l11_l1_(url,l1l1l1_l1_ (u"ࠫ࠸࠭༣"))
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ䱄")
headers = { l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䱅") : l1l1l1_l1_ (u"ࠪࠫ䱆") }
menu_name = l1l1l1_l1_ (u"ࠫࡤ࡙ࡆࡘࡡࠪ䱇")
l1l11l_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l11l11_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l11l1ll_l1_(url)
	elif mode==214: results = l1ll1ll11l11_l1_(url)
	elif mode==215: results = l1ll1ll11l1l_l1_(url)
	elif mode==218: results = l1l1l1ll11l_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l1l1l1ll11l_l1_():
	message = l1l1l1_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠡ࠰࠱࠲ࠥ๎ศฮษฯอࠥอไ๊ࠢส฽ฬีษࠡสิ้ัฯࠠๆ่ࠣห้฻แาࠢ࠱࠲࠳่ࠦศๆ่ฬึ๋ฬࠡฯส่๏อࠠๆึ฽์้่๋ࠦ฻ส๊๏ࠦๅ็๋ࠢ฽่ฯࠠึฯํอࠥ࠴࠮࠯๋่ࠢ์ึวࠡี๋ๅࠥ๐ศใ๋ࠣห้๋่ใ฻้ࠣ฿๊โࠡษ็ํ๋ࠥวࠡึสลࠥอไๅ้ࠪ䱈")
	DIALOG_OK(l1l1l1_l1_ (u"࠭ࠧ䱉"),l1l1l1_l1_ (u"ࠧࠨ䱊"),l1l1l1_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䱋"),l1l1l1_l1_ (u"ࠩส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠨ䱌"),message)
	return
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䱍"),menu_name+l1l1l1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䱎"),l1l1l1_l1_ (u"ࠬ࠭䱏"),219,l1l1l1_l1_ (u"࠭ࠧ䱐"),l1l1l1_l1_ (u"ࠧࠨ䱑"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䱒"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䱓"),menu_name+l1l1l1_l1_ (u"ࠪๅ้ะัࠨ䱔"),l1l1l1_l1_ (u"ࠫࠬ䱕"),114,l1l11l_l1_)
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡑ࡫ࡱࡃࡹࡿࡰࡦ࠿ࡲࡲࡪࠬࡤࡢࡶࡤࡁࡵ࡯࡮ࠧ࡮࡬ࡱ࡮ࡺ࠽࠳࠷ࠪ䱖")
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱗"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䱘")+menu_name+l1l1l1_l1_ (u"ࠨษ็้๊๐าสࠩ䱙"),url,211)
	html = OPENURL_CACHED(l11l11l_l1_,l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪ䱚"),headers,l1l1l1_l1_ (u"ࠪࠫ䱛"),l1l1l1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䱜"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡌࡩ࡭ࡶࡨࡶࡸࡈࡵࡵࡶࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䱝"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䱞"),block,re.DOTALL)
	for l111ll_l1_,title in items:#[1:-1]:
		url = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࠫ䱟")+l111ll_l1_
		addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䱠"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䱡")+menu_name+title,url,211)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䱢"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䱣"),block,re.DOTALL)
	l1l1ll_l1_ = [l1l1l1_l1_ (u"๋ࠬำๅี็หฯࠦว็็ํࠫ䱤"),l1l1l1_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ䱥")]
	#l11l11l11_l1_ = [l1l1l1_l1_ (u"ࠧๆี็ื้อสࠡࠩ䱦"),l1l1l1_l1_ (u"ࠨษไ่ฬ๋ࠠࠨ䱧"),l1l1l1_l1_ (u"ࠩหีฬ๋ฬࠨ䱨"),l1l1l1_l1_ (u"ࠪ฽ึ๎ึࠨ䱩"),l1l1l1_l1_ (u"่๊๊ࠫษษอࠫ䱪"),l1l1l1_l1_ (u"ࠬอฺศ่์ࠫ䱫")]
	for l111ll_l1_,title in items:
		title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ䱬"))
		if not any(value in title for value in l1l1ll_l1_):
		#	if any(value in title for value in l11l11l11_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䱭"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䱮")+menu_name+title,l111ll_l1_,211)
	return html
def l11l11_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠩࠪ䱯"),headers,l1l1l1_l1_ (u"ࠪࠫ䱰"),l1l1l1_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䱱"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䱲"),l1l1l1_l1_ (u"࠭ࠧ䱳"),url,html)
	if l1l1l1_l1_ (u"ࠧࡨࡧࡷࡴࡴࡹࡴࡴࠩ䱴") in url or l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ䱵") in url: block = html
	else:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡐࡩࡩ࡯ࡡࡈࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ䱶"),html,re.DOTALL)
		if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		else: return
	items = re.findall(l1l1l1_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䱷"),block,re.DOTALL)
	l1l1_l1_ = []
	l11ll1111_l1_ = [l1l1l1_l1_ (u"ฺ๊ࠫว่ัฬࠫ䱸"),l1l1l1_l1_ (u"ࠬ็๊ๅ็ࠪ䱹"),l1l1l1_l1_ (u"࠭ว฻่ํอࠬ䱺"),l1l1l1_l1_ (u"ࠧไๆํฬࠬ䱻"),l1l1l1_l1_ (u"ࠨษ฼่ฬ์ࠧ䱼"),l1l1l1_l1_ (u"๊ࠩำฬ็ࠧ䱽"),l1l1l1_l1_ (u"้ࠪออัศหࠪ䱾"),l1l1l1_l1_ (u"ࠫ฾ืึࠨ䱿"),l1l1l1_l1_ (u"๋ࠬ็าฮส๊ࠬ䲀"),l1l1l1_l1_ (u"࠭วๅส๋้ࠬ䲁")]
	for img,l111ll_l1_,title in items:
		if l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䲂") in l111ll_l1_: continue
		l111ll_l1_ = UNQUOTE(l111ll_l1_).strip(l1l1l1_l1_ (u"ࠨ࠱ࠪ䲃"))
		title = unescapeHTML(title)
		title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ䲄"))
		if l1l1l1_l1_ (u"ࠪ࠳࡫࡯࡬࡮࠱ࠪ䲅") in l111ll_l1_ or any(value in title for value in l11ll1111_l1_):
			addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䲆"),menu_name+title,l111ll_l1_,212,img)
		elif l1l1l1_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ䲇") in l111ll_l1_ and l1l1l1_l1_ (u"࠭วๅฯ็ๆฮ࠭䲈") in title:
			l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ䲉"),title,re.DOTALL)
			if l1llll1_l1_:
				title = l1l1l1_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䲊") + l1llll1_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䲋"),menu_name+title,l111ll_l1_,213,img)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䲌"),menu_name+title,l111ll_l1_,213,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䲍"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䲎"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = unescapeHTML(l111ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l1l1_l1_ (u"࠭วๅืไัฮࠦࠧ䲏"),l1l1l1_l1_ (u"ࠧࠨ䲐"))
			if title!=l1l1l1_l1_ (u"ࠨࠩ䲑"): addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䲒"),menu_name+l1l1l1_l1_ (u"ูࠪๆำษࠡࠩ䲓")+title,l111ll_l1_,211)
	return
def l11l1ll_l1_(url):
	l11ll11ll_l1_,items,l11l1111_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"ࠫࠬ䲔"),headers,l1l1l1_l1_ (u"ࠬ࠭䲕"),l1l1l1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䲖"))
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡵ࡫࠰ࡰ࡮ࡹࡴ࠮ࡰࡸࡱࡧ࡫ࡲࡦࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䲗"),html,re.DOTALL)
	if l1ll1l1_l1_:
		l1l11l1_l1_ = l1l1l1_l1_ (u"ࠨࠩ䲘").join(l1ll1l1_l1_)
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䲙"),l1l11l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l1l1_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ䲚"))
	for l111ll_l1_ in items:
		l111ll_l1_ = l111ll_l1_.strip(l1l1l1_l1_ (u"ࠫ࠴࠭䲛"))
		title = l1l1l1_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䲜") + l111ll_l1_.split(l1l1l1_l1_ (u"࠭࠯ࠨ䲝"))[-1].replace(l1l1l1_l1_ (u"ࠧ࠮ࠩ䲞"),l1l1l1_l1_ (u"ࠨࠢࠪ䲟"))
		l11l1l11_l1_ = re.findall(l1l1l1_l1_ (u"ࠩส่า๊โส࠯ࠫࡠࡩ࠱ࠩࠨ䲠"),l111ll_l1_.split(l1l1l1_l1_ (u"ࠪ࠳ࠬ䲡"))[-1],re.DOTALL)
		if l11l1l11_l1_: l11l1l11_l1_ = l11l1l11_l1_[0]
		else: l11l1l11_l1_ = l1l1l1_l1_ (u"ࠫ࠵࠭䲢")
		l11l1111_l1_.append([l111ll_l1_,title,l11l1l11_l1_])
	items = sorted(l11l1111_l1_, reverse=False, key=lambda key: int(key[2]))
	l11ll111l_l1_ = str(items).count(l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ䲣"))
	l11ll11ll_l1_ = str(items).count(l1l1l1_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ䲤"))
	if l11ll111l_l1_>1 and l11ll11ll_l1_>0 and l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ䲥") not in url:
		for l111ll_l1_,title,l11l1l11_l1_ in items:
			if l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ䲦") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䲧"),menu_name+title,l111ll_l1_,213)
	else:
		for l111ll_l1_,title,l11l1l11_l1_ in items:
			if l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ䲨") not in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䲩"),menu_name+title,l111ll_l1_,212)
	return
def PLAY(url):
	l11l1_l1_ = []
	parts = url.split(l1l1l1_l1_ (u"ࠬ࠵ࠧ䲪"))
	html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"࠭ࠧ䲫"),headers,l1l1l1_l1_ (u"ࠧࠨ䲬"),l1l1l1_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䲭"))
	# l1l1111ll_l1_ l1ll_l1_
	if l1l1l1_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ䲮") in html:
		url2 = url.replace(parts[3],l1l1l1_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ䲯"))
		l1l11l11_l1_ = OPENURL_CACHED(l11l11l_l1_,url2,l1l1l1_l1_ (u"ࠫࠬ䲰"),headers,l1l1l1_l1_ (u"ࠬ࠭䲱"),l1l1l1_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ䲲"))
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䲳"),l1l11l11_l1_,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ䲴"),block,re.DOTALL)
			if items:
				id = re.findall(l1l1l1_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠤࠪ䲵"),l1l11l11_l1_,re.DOTALL)
				if id:
					id2 = id[0]
					for l111ll_l1_,title in items:
						l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠭䲶")+id2+l1l1l1_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ䲷")+l111ll_l1_+l1l1l1_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䲸")+title+l1l1l1_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䲹")
						l11l1_l1_.append(l111ll_l1_)
			else:
				# l1ll1lll_l1_://l1ll1ll11ll1_l1_.tv/l1l1111ll_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨ࠮ࠫࡁࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠭ࠨࡼࠧࡳࡸࡳࡹࡁࠩࠨ䲺"),block,re.DOTALL)
				for l111ll_l1_,dummy in items:
					l11l1_l1_.append(l111ll_l1_)
	# download l1ll_l1_
	if l1l1l1_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ䲻") in html:
		url2 = url.replace(parts[3],l1l1l1_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䲼"))
		l1l11l11_l1_ = OPENURL_CACHED(l11l11l_l1_,url2,l1l1l1_l1_ (u"ࠪࠫ䲽"),headers,l1l1l1_l1_ (u"ࠫࠬ䲾"),l1l1l1_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭䲿"))
		id = re.findall(l1l1l1_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳀"),l1l11l11_l1_,re.DOTALL)
		if id:
			id2 = id[0]
			headers2 = { l1l1l1_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䳁"):l1l1l1_l1_ (u"ࠨࠩ䳂") , l1l1l1_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䳃"):l1l1l1_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䳄") }
			url2 = l1l11l_l1_ + l1l1l1_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡤࡰࡹࡱࡰࡴࡧࡤ࡭࡫ࡱ࡯ࡸࠬࡰࡰࡵࡷࡍࡩࡃࠧ䳅")+id2
			l1l11l11_l1_ = OPENURL_CACHED(l11l11l_l1_,url2,l1l1l1_l1_ (u"ࠬ࠭䳆"),headers2,l1l1l1_l1_ (u"࠭ࠧ䳇"),l1l1l1_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ䳈"))
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࠾࡫࠷࠳࠰࠿ࠩ࡞ࡧ࠯࠮࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䳉"),l1l11l11_l1_,re.DOTALL)
			if l1ll1l1_l1_:
				for resolution,block in l1ll1l1_l1_:
					items = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳊"),block,re.DOTALL)
					for name,l111ll_l1_ in items:
						l11l1_l1_.append(l111ll_l1_+l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䳋")+name+l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䳌")+l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ䳍")+resolution)
			else:
				l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡩ࠸ࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ䳎"),l1l11l11_l1_,re.DOTALL)
				if not l1ll1l1_l1_: l1ll1l1_l1_ = [l1l11l11_l1_]
				for block in l1ll1l1_l1_:
					l1l1l1_l1_ (u"ࠢࠣࠤࠍࠍࠎࠏࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡦࡴࡹࡩࡷࡹࡔࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࠋࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠾ࠏࠏࠉࠊࠋࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࡝࠰࠵ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨษ็ำ็ฯࠠࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࠏࠉࠊ࡫ࡩࠤࡳࡧ࡭ࡦࠣࡀࠫࠬࡀࠠ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩࠥ࠱ࠠࠨࠢใࠤࠬࠐࠉࠊࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡲࡦࡳࡥࠡ࠿ࠣࠫࠬࠐࠉࠊࠋࠌࠍࠧࠨࠢ䳏")
					name = l1l1l1_l1_ (u"ࠨࠩ䳐")
					items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ䳑"),block,re.DOTALL)
					for l111ll_l1_ in items:
						server = l1l1l1_l1_ (u"ࠪࠪࠫ࠭䳒") + l111ll_l1_.split(l1l1l1_l1_ (u"ࠫ࠴࠭䳓"))[2].lower() + l1l1l1_l1_ (u"ࠬࠬࠦࠨ䳔")
						server = server.replace(l1l1l1_l1_ (u"࠭࠮ࡤࡱࡰࠪࠫ࠭䳕"),l1l1l1_l1_ (u"ࠧࠨ䳖")).replace(l1l1l1_l1_ (u"ࠨ࠰ࡦࡳࠫࠬࠧ䳗"),l1l1l1_l1_ (u"ࠩࠪ䳘"))
						server = server.replace(l1l1l1_l1_ (u"ࠪ࠲ࡳ࡫ࡴࠧࠨࠪ䳙"),l1l1l1_l1_ (u"ࠫࠬ䳚")).replace(l1l1l1_l1_ (u"ࠬ࠴࡯ࡳࡩࠩࠪࠬ䳛"),l1l1l1_l1_ (u"࠭ࠧ䳜"))
						server = server.replace(l1l1l1_l1_ (u"ࠧ࠯࡮࡬ࡺࡪࠬࠦࠨ䳝"),l1l1l1_l1_ (u"ࠨࠩ䳞")).replace(l1l1l1_l1_ (u"ࠩ࠱ࡳࡳࡲࡩ࡯ࡧࠩࠪࠬ䳟"),l1l1l1_l1_ (u"ࠪࠫ䳠"))
						server = server.replace(l1l1l1_l1_ (u"ࠫࠫࠬࡨࡥ࠰ࠪ䳡"),l1l1l1_l1_ (u"ࠬ࠭䳢")).replace(l1l1l1_l1_ (u"࠭ࠦࠧࡹࡺࡻ࠳࠭䳣"),l1l1l1_l1_ (u"ࠧࠨ䳤"))
						server = server.replace(l1l1l1_l1_ (u"ࠨࠨࠩࠫ䳥"),l1l1l1_l1_ (u"ࠩࠪ䳦"))
						l111ll_l1_ = l111ll_l1_ + l1l1l1_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䳧") + name + server + l1l1l1_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䳨")
						l11l1_l1_.append(l111ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䳩"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ䳪"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ䳫"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ䳬"),l1l1l1_l1_ (u"ࠩ࠮ࠫ䳭"))
	url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧ䳮")+search
	l11l11_l1_(url)
	return
	l1l1l1_l1_ (u"ࠦࠧࠨࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡹࡥࡢࡴࡦ࡬ࠥࡹࡥࡤࡱࡱࡨࡦࡸࡹࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡧࡥࡹࡧ࠭ࡤࡣࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤࡪࡨࡧࡰࡳࡡࡳ࡭࠰ࡦࡴࡲࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࡎࡌࡗ࡙࠲ࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠣࡁࠥࡡ࡝࠭࡝ࡠࠎࠎࠏࡦࡰࡴࠣࡧࡦࡺࡥࡨࡱࡵࡽ࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡦࡥࡹ࡫ࡧࡰࡴࡼ࠭ࠏࠏࠉࠊࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭ࠬࠡࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘ࠮ࠐࠉࠊ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࠣ࠱࠶ࠦ࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࠥࡃࠠࡤࡣࡷࡩ࡬ࡵࡲࡺࡎࡌࡗ࡙ࡡࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࡟ࠍࠍࠎࡻࡲ࡭ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠࠬࠢࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧࠬࡵࡨࡥࡷࡩࡨࠬࠩࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭ࠫࡤࡣࡷࡩ࡬ࡵࡲࡺࠌࠌࠍ࡙ࡏࡔࡍࡇࡖࠬࡺࡸ࡬ࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠍࠧࠨࠢ䳯")
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ吔")
menu_name = l1l1l1_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭吕")
l1l11l_l1_ = WEBSITES[script_name][0]
headers = {l1l1l1_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ吖"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l11l11_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1l11lll11l1_l1_(url)
	elif mode==314: results = l1111l11_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ吗"),menu_name+l1l1l1_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ吘"),l1l1l1_l1_ (u"ࠫࠬ吙"),319,l1l1l1_l1_ (u"ࠬ࠭吚"),l1l1l1_l1_ (u"࠭ࠧ君"),l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ吜"))
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ吝"),menu_name+l1l1l1_l1_ (u"ࠩไ่ฯืࠧ吞"),l1l1l1_l1_ (u"ࠪࠫ吟"),114,l1l11l_l1_)
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ吠"),l1l11l_l1_,l1l1l1_l1_ (u"ࠬ࠭吡"),l1l1l1_l1_ (u"࠭ࠧ吢"),l1l1l1_l1_ (u"ࠧࠨ吣"),l1l1l1_l1_ (u"ࠨࠩ吤"),l1l1l1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ吥"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡧࡱࡹࡱ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ否"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ吧"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ吨"),l1l1l1_l1_ (u"࠭ࠧ吩"),9999)
	items = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡪ࠸ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠻࠾ࠨ吪"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l1l1_l1_ (u"ࠨࠢࠪ含"))
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ听"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ吭")+menu_name+title,l1l11l_l1_,314,l1l1l1_l1_ (u"ࠫࠬ吮"),l1l1l1_l1_ (u"ࠬ࠭启"),str(seq+1))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭吰"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ吱")+menu_name+l1l1l1_l1_ (u"ࠨ็ๅห฼฿ࠠี้ิࠫ吲"),l1l11l_l1_,314,l1l1l1_l1_ (u"ࠩࠪ吳"),l1l1l1_l1_ (u"ࠪࠫ吴"),l1l1l1_l1_ (u"ࠫ࠵࠭吵"))
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ吶"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭吷"),l1l1l1_l1_ (u"ࠧࠨ吸"),9999)
	items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡆࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡈ࠾ࠨ吹"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ吺")+l111ll_l1_
		#title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬ吻"))
		#url = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡆ࡭ࡲࡧࡎࡰࡹ࠲ࡍࡳࡺࡥࡳࡨࡤࡧࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠴ࡰࡩࡲࠪ吼")
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ吽"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ吾")+menu_name+title,l111ll_l1_,311)
	return html
def l1111l11_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ吿"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩ呀"),l1l1l1_l1_ (u"ࠩࠪ呁"),l1l1l1_l1_ (u"ࠪࠫ呂"),l1l1l1_l1_ (u"ࠫࠬ呃"),l1l1l1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ呄"))
	html = response.content
	if seq==l1l1l1_l1_ (u"࠭࠰ࠨ呅"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ呆"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ呇"),block,re.DOTALL)
		for l111ll_l1_,name,title in items:
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ呈")+l111ll_l1_
			title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬ呉"))
			name = name.strip(l1l1l1_l1_ (u"ࠫࠥ࠭告"))
			title = title+l1l1l1_l1_ (u"ࠬࠦࠨࠨ呋")+name+l1l1l1_l1_ (u"࠭ࠩࠨ呌")
			addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭呍"),menu_name+title,l111ll_l1_,312)
	elif seq in [l1l1l1_l1_ (u"ࠨ࠳ࠪ呎"),l1l1l1_l1_ (u"ࠩ࠵ࠫ呏"),l1l1l1_l1_ (u"ࠪ࠷ࠬ呐")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡮ࡪࠫ呑"),html,re.DOTALL)
		l1l11lll111l_l1_ = int(seq)-1
		block = l1ll1l1_l1_[l1l11lll111l_l1_]
		if seq==l1l1l1_l1_ (u"ࠬ࠷ࠧ呒"): items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ呓"),block,re.DOTALL)
		else: items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ呔"),block,re.DOTALL)
		for l111ll_l1_,img,title,name in items:
			img = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࠪ呕")+img
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ呖")+l111ll_l1_
			title = title.strip(l1l1l1_l1_ (u"ࠪࠤࠬ呗"))
			name = name.strip(l1l1l1_l1_ (u"ࠫࠥ࠭员"))
			title = title+l1l1l1_l1_ (u"ࠬࠦࠨࠨ呙")+name+l1l1l1_l1_ (u"࠭ࠩࠨ呚")
			addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ呛"),menu_name+title,l111ll_l1_,311,img)
	elif seq in [l1l1l1_l1_ (u"ࠨ࠶ࠪ呜"),l1l1l1_l1_ (u"ࠩ࠸ࠫ呝"),l1l1l1_l1_ (u"ࠪ࠺ࠬ呞")]:
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ呟"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1ll1l1_l1_[seq]
		items = re.findall(l1l1l1_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀ࠯ࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ呠"),block,re.DOTALL)
		for img,l111ll_l1_,name1,title,name2 in items:
			img = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ呡")+img
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࠩ呢")+l111ll_l1_
			title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪ呣"))
			name1 = name1.strip(l1l1l1_l1_ (u"ࠩࠣࠫ呤"))
			name2 = name2.strip(l1l1l1_l1_ (u"ࠪࠤࠬ呥"))
			if name1: name = name1
			else: name = name2
			title = title+l1l1l1_l1_ (u"ࠫࠥ࠮ࠧ呦")+name+l1l1l1_l1_ (u"ࠬ࠯ࠧ呧")
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ周"),menu_name+title,l111ll_l1_,312,img)
	return
def l11l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ呩"),url,l1l1l1_l1_ (u"ࠨࠩ呪"),l1l1l1_l1_ (u"ࠩࠪ呫"),l1l1l1_l1_ (u"ࠪࠫ呬"),l1l1l1_l1_ (u"ࠫࠬ呭"),l1l1l1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ呮"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡩࡣࡱࡻ࠱࡭࡫ࡡࡥ࡫ࡱ࡫ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡱࡵࡡࡵ࠯ࡵ࡭࡬࡮ࡴࠨ呯"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	if l1l1l1_l1_ (u"ࠧࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠧ呰") in block:
		items = re.findall(l1l1l1_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ呱"),block,re.DOTALL)
		if items:
			for img,l111ll_l1_,title,count in items:
				img = l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࠫ呲")+img
				l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬ味")+l111ll_l1_
				count = count.replace(l1l1l1_l1_ (u"ࠫࠥอไึ๊อ๎ฮࡀࠠࠨ呴"),l1l1l1_l1_ (u"ࠬࡀࠧ呵"))
				title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ呶"))
				title = title+l1l1l1_l1_ (u"ࠧࠡࠪࠪ呷")+count+l1l1l1_l1_ (u"ࠨࠫࠪ呸")
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ呹"),menu_name+title,l111ll_l1_,311,img)
	else:
		items = re.findall(l1l1l1_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ呺"),block,re.DOTALL)
		for l111ll_l1_,title,l1l11lll1l11_l1_,duration in items:
			if title==l1l1l1_l1_ (u"ࠫࠬ呻") or l1l11lll1l11_l1_==l1l1l1_l1_ (u"ࠬ࠭呼"): continue
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ命")+l111ll_l1_
			title = title+l1l1l1_l1_ (u"ࠧࠡࠪࠪ呾")+duration+l1l1l1_l1_ (u"ࠨࠫࠪ呿")
			addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ咀"),menu_name+title,l111ll_l1_,312)
	if not items: l11l1ll_l1_(html)
	return
def l11l1ll_l1_(html):
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ咁"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ咂"),block,re.DOTALL)
	for l111ll_l1_,title,name,count,duration in items:
		l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࠧ咃")+l111ll_l1_
		title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ咄"))
		name = name.strip(l1l1l1_l1_ (u"ࠧࠡࠩ咅"))
		title = title+l1l1l1_l1_ (u"ࠨࠢࠫࠫ咆")+name+l1l1l1_l1_ (u"ࠩࠬࠫ咇")
		addMenuItem(l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ咈"),menu_name+title,l111ll_l1_,312,l1l1l1_l1_ (u"ࠫࠬ咉"),duration)
	return
def l1l11lll11l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ咊"),url,l1l1l1_l1_ (u"࠭ࠧ咋"),l1l1l1_l1_ (u"ࠧࠨ和"),l1l1l1_l1_ (u"ࠨࠩ咍"),l1l1l1_l1_ (u"ࠩࠪ咎"),l1l1l1_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍࡥࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ咏"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠣࡴ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ咐"),html,re.DOTALL)
	if not l1ll1l1_l1_:
		l11l11_l1_(url)
		return
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ咑"),block,re.DOTALL)
	for l111ll_l1_,title in items:
		l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨ咒")+l111ll_l1_
		title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩ咓"))
		if l1l1l1_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠭ࠨ咔") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ咕"),menu_name+title,l111ll_l1_,312)
		else: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ咖"),menu_name+title,l111ll_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ咗"),url,l1l1l1_l1_ (u"ࠬ࠭咘"),l1l1l1_l1_ (u"࠭ࠧ咙"),l1l1l1_l1_ (u"ࠧࠨ咚"),l1l1l1_l1_ (u"ࠨࠩ咛"),l1l1l1_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ咜"))
	html = response.content
	l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡀࡦࡻࡤࡪࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ咝"),html,re.DOTALL)
	if not l111ll_l1_: l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ咞"),html,re.DOTALL)
	l111ll_l1_ = l1l11l_l1_+l111ll_l1_[0]
	PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ咟"))
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"࠭ࠧ咠"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠧࠨ咡"): return
	search = search.replace(l1l1l1_l1_ (u"ࠨࠢࠪ咢"),l1l1l1_l1_ (u"ࠩ࠮ࠫ咣"))
	typeList = [l1l1l1_l1_ (u"ࠪࠪࡹࡃࡡࠨ咤"),l1l1l1_l1_ (u"ࠫࠫࡺ࠽ࡤࠩ咥"),l1l1l1_l1_ (u"ࠬࠬࡴ࠾ࡵࠪ咦")]
	if l111l_l1_:
		searchTitle = [l1l1l1_l1_ (u"࠭โศำษࠫ咧"),l1l1l1_l1_ (u"ࠧฦืาหึࠦ࠯ࠡ็ฯ่ิ࠭咨"),l1l1l1_l1_ (u"ࠨ็ๅ฻฾ࠦวๅื๋ฮ๏࠭咩")]
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ࠲ࠦรฯฬิࠤฬ๊ศฮอࠪ咪"), searchTitle)
		if selection == -1: return
	elif l1l1l1_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࡠࠩ咫") in options: selection = 0
	elif l1l1l1_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩ咬") in options: selection = 1
	elif l1l1l1_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ咭") in options: selection = 2
	else: return
	type = typeList[selection]
	url = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡶࡃࠧ咮")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫ咯"),url,l1l1l1_l1_ (u"ࠨࠩ咰"),l1l1l1_l1_ (u"ࠩࠪ咱"),l1l1l1_l1_ (u"ࠪࠫ咲"),l1l1l1_l1_ (u"ࠫࠬ咳"),l1l1l1_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ咴"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ咵"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		if selection in [0,1]:
			items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ咶"),block,re.DOTALL)
			for l111ll_l1_,img,title,name in items:
				title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪ咷"))
				name = name.strip(l1l1l1_l1_ (u"ࠩࠣࠫ咸"))
				title = title+l1l1l1_l1_ (u"ࠪࠤ࠭࠭咹")+name+l1l1l1_l1_ (u"ࠫ࠮࠭咺")
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ咻"),menu_name+title,l111ll_l1_,313,img)
		elif selection==2:
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡺࡤ࠿࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀࠬ咼"),block,re.DOTALL)
			for l111ll_l1_,title,name in items:
				title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩ咽"))
				name = name.strip(l1l1l1_l1_ (u"ࠨࠢࠪ咾"))
				title = title+l1l1l1_l1_ (u"ࠩࠣࠬࠬ咿")+name+l1l1l1_l1_ (u"ࠪ࠭ࠬ哀")
				addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ品"),menu_name+title,l111ll_l1_,312)
	return
# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
#l1l11l_l1_ = l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨ䀠")
headers = {l1l1l1_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䀡"):l1l1l1_l1_ (u"ࠪࠫ䀢")}
script_name = l1l1l1_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ䀣")
menu_name = l1l1l1_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ䀤")
l1l11l_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l1l1l1_l1_ (u"࠭࠳ࠨ䀥"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l1l1l1_l1_ (u"ࠧ࠲ࠩ䀦"))
	elif mode==36: results = CATEGORIES(url,l1l1l1_l1_ (u"ࠨ࠴ࠪ䀧"))
	elif mode==37: results = CATEGORIES(url,l1l1l1_l1_ (u"ࠩ࠷ࠫ䀨"))
	elif mode==38: results = l1ll11lll_l1_()
	elif mode==39: results = SEARCH(text,page)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䀩"),menu_name+l1l1l1_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䀪"),l1l1l1_l1_ (u"ࠬ࠭䀫"),39,l1l1l1_l1_ (u"࠭ࠧ䀬"),l1l1l1_l1_ (u"ࠧࠨ䀭"),l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䀮"))
	#addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䀯"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䀰"),l1l1l1_l1_ (u"ࠫࠬ䀱"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩࡷࡧࠪ䀲"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䀳")+menu_name+l1l1l1_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ䀴"),l1l1l1_l1_ (u"ࠨࠩ䀵"),38)
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀶"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䀷")+menu_name+l1l1l1_l1_ (u"ู๊ࠫไิๆสฮࠥ๎ศาษ่ะࠬ䀸"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䀹"),31)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀺"),script_name+l1l1l1_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䀻")+menu_name+l1l1l1_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊วไอิࠤฺ๊ว่ัฬࠫ䀼"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䀽"),37)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䀾"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䀿")+menu_name+l1l1l1_l1_ (u"ࠬอแๅษ่ࠤาูศࠡษ็๊ํ฿ࠧ䁀"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ䁁"),35)
	#addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁂"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䁃")+menu_name+l1l1l1_l1_ (u"ࠩสๅ้อๅࠡฯึฬࠥอไๆ็ฮ่ࠬ䁄"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ䁅"),36)
	#addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䁆"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䁇")+menu_name+l1l1l1_l1_ (u"࠭วฮัฮࠤฬ๊วโๆส้ࠬ䁈"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ䁉"),32)
	#addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䁊"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䁋")+menu_name+l1l1l1_l1_ (u"ุ้ࠪือ๋ษอࠫ䁌"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࡭ࡥ࡯ࡴࡨ࠳࠹࠵࠱ࠨ䁍"),32)
	return l1l1l1_l1_ (u"ࠬ࠭䁎")
def CATEGORIES(url,select=l1l1l1_l1_ (u"࠭ࠧ䁏")):
	type = url.split(l1l1l1_l1_ (u"ࠧ࠰ࠩ䁐"))[3]
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䁑"),l1l1l1_l1_ (u"ࠩࠪ䁒"),type, url)
	if type==l1l1l1_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䁓"):
		html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠫࠬ䁔"),headers,l1l1l1_l1_ (u"ࠬ࠭䁕"),l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠴ࡷࡹ࠭䁖"))
		if select==l1l1l1_l1_ (u"ࠧ࠴ࠩ䁗"):
			l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࡒ࡫࡮ࡶࠪ࠱࠮ࡄ࠯ࡳࡦࡴ࡬ࡩࡸࡌ࡯ࡳ࡯ࠪ䁘"),html,re.DOTALL)
			block= l1ll1l1_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䁙"),block,re.DOTALL)
			for l111ll_l1_,name in items:
				if l1l1l1_l1_ (u"ࠪ็้๐ศศฬ้ࠣ฻ำใสࠩ䁚") in name: continue
				url = l1l11l_l1_ + l111ll_l1_
				name = name.strip(l1l1l1_l1_ (u"ࠫࠥ࠭䁛"))
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁜"),menu_name+name,url,32)
		if select==l1l1l1_l1_ (u"࠭࠴ࠨ䁝"):
			l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡤࡦࡶࡤ࡭ࡱࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡺࡃࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ䁞"),html,re.DOTALL)
			block= l1ll1l1_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䁟"),block,re.DOTALL)
			for l111ll_l1_,img,title in items:
				url = l1l11l_l1_ + l111ll_l1_
				title = title.strip(l1l1l1_l1_ (u"ࠩࠣࠫ䁠"))
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁡"),menu_name+title,url,32,img)
		#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䁢"),l1l1l1_l1_ (u"ࠬ࠭䁣"),url,l1l1l1_l1_ (u"࠭ࠧ䁤"))
	if type==l1l1l1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䁥"):
		html = OPENURL_CACHED(l11l11l_l1_,url,l1l1l1_l1_ (u"ࠨࠩ䁦"),headers,l1l1l1_l1_ (u"ࠩࠪ䁧"),l1l1l1_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠲࡯ࡦࠪ䁨"))
		if select==l1l1l1_l1_ (u"ࠫ࠶࠭䁩"):
			l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡌ࡫࡮ࡥࡧࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ䁪"),html,re.DOTALL)
			block = l1ll1l1_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁫"),block,re.DOTALL)
			for value,name in items:
				url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯ࠨ䁬") + value
				name = name.strip(l1l1l1_l1_ (u"ࠨࠢࠪ䁭"))
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䁮"),menu_name+name,url,32)
		elif select==l1l1l1_l1_ (u"ࠪ࠶ࠬ䁯"):
			l1ll1l1_l1_=re.findall(l1l1l1_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࡅࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䁰"),html,re.DOTALL)
			block = l1ll1l1_l1_[0]
			items=re.findall(l1l1l1_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡃࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䁱"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l1l1_l1_ (u"࠭ࠠࠨ䁲"))
				url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡣࡦࡸࡴࡸ࠯ࠨ䁳") + value
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䁴"),menu_name+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䁵"),l1l1l1_l1_ (u"ࠪࠫ䁶"),url,l1l1l1_l1_ (u"ࠫࠬ䁷"))
	type = url.split(l1l1l1_l1_ (u"ࠬ࠵ࠧ䁸"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1l1_l1_ (u"࠭ࠧ䁹"),headers,l1l1l1_l1_ (u"ࠧࠨ䁺"),l1l1l1_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ䁻"))
	if l1l1l1_l1_ (u"ࠩ࡫ࡳࡲ࡫ࠧ䁼") in url: type=l1l1l1_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ䁽")
	if type==l1l1l1_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䁾"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠩ࠰࠭ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ䁿"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䂀"),block,re.DOTALL)
			for l111ll_l1_,img,name in items:
				url = l1l11l_l1_ + l111ll_l1_
				name = name.strip(l1l1l1_l1_ (u"ࠧࠡࠩ䂁"))
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂂"),menu_name+name,url,32,img)
	if type==l1l1l1_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ䂃"):
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䂄"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠨ䂅"),block,re.DOTALL)
		for l111ll_l1_,img,name in items:
			name = name.strip(l1l1l1_l1_ (u"ࠬࠦࠧ䂆"))
			url = l1l11l_l1_ + l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䂇"),menu_name+name,url,33,img)
	if type==l1l1l1_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䂈"):
		page = url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ䂉"))[-1]
		#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䂊"),l1l1l1_l1_ (u"ࠪࠫ䂋"),url,l1l1l1_l1_ (u"ࠫࠬ䂌"))
		if page==l1l1l1_l1_ (u"ࠬ࠷ࠧ䂍"):
			l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠫ䂎"),html,re.DOTALL)
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶࠨ䂏"),block,re.DOTALL)
			count = 0
			for l111ll_l1_,img,l1llll1_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l1l1_l1_ (u"ࠨࠢ࠰ࠤࠬ䂐") + l1llll1_l1_
				url = l1l11l_l1_ + l111ll_l1_
				addMenuItem(l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䂑"),menu_name+name,url,33,img)
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹ࠮ࠫࡁࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䂒"),html,re.DOTALL)
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࠬ䂓"),block,re.DOTALL)
		for l111ll_l1_,img,title,l1llll1_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.strip(l1l1l1_l1_ (u"ࠬࠦࠧ䂔"))
			title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨ䂕"))
			name = title + l1l1l1_l1_ (u"ࠧࠡ࠯ࠣࠫ䂖") + l1llll1_l1_
			url = l1l11l_l1_ + l111ll_l1_
			addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䂗"),menu_name+name,url,33,img)
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡪࡰࡾࡶࡨࡪࡥࡲࡲ࠲ࡩࡨࡦࡸࡵࡳࡳ࠳ࡲࡪࡩ࡫ࡸ࠭࠴ࠫࡀࠫࡧࡥࡹࡧ࠭ࡳࡧࡹ࡭ࡻ࡫࠭ࡻࡱࡱࡩ࡮ࡪ࠽ࠣ࠶ࠥࠫ䂘"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䂙"),block,re.DOTALL)
	for l111ll_l1_,page in items:
		url = l1l11l_l1_ + l111ll_l1_
		name = l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪ䂚") + page
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂛"),menu_name+name,url,32)
	return
def PLAY(url):
	if l1l1l1_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䂜") in url:
		url = l1l11l_l1_ + l1l1l1_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸ࠴ࡼ࠱࠰ࡵࡨࡶ࡮࡫ࡳࡍ࡫ࡱ࡯࠴࠭䂝") + url.split(l1l1l1_l1_ (u"ࠨ࠱ࠪ䂞"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭䂟"),url,l1l1l1_l1_ (u"ࠪࠫ䂠"),headers,l1l1l1_l1_ (u"ࠫࠬ䂡"),l1l1l1_l1_ (u"ࠬ࠭䂢"),l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䂣"))
		html = response.content
		items = re.findall(l1l1l1_l1_ (u"ࠧࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䂤"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l1l1_l1_ (u"ࠨ࡞࠲ࠫ䂥"),l1l1l1_l1_ (u"ࠩ࠲ࠫ䂦"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ䂧"),url,l1l1l1_l1_ (u"ࠫࠬ䂨"),headers,l1l1l1_l1_ (u"ࠬ࠭䂩"),l1l1l1_l1_ (u"࠭ࠧ䂪"),l1l1l1_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ䂫"))
		html = response.content
		items = re.findall(l1l1l1_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡗࡕࡐࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䂬"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l1l1l1_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䂭"))
	return
def SEARCH(search,page=l1l1l1_l1_ (u"ࠪࠫ䂮")):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll11_l1_ = search.replace(l1l1l1_l1_ (u"ࠫࠥ࠭䂯"),l1l1l1_l1_ (u"ࠬࠫ࠲࠱ࠩ䂰"))
	l1ll1l1l1_l1_ = [l1l1l1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䂱"),l1l1l1_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䂲")]
	if not page: page = l1l1l1_l1_ (u"ࠨ࠳ࠪ䂳")
	else: page,type = page.split(l1l1l1_l1_ (u"ࠩ࠲ࠫ䂴"))
	if l111l_l1_:
		l111l1l11_l1_ = [ l1l1l1_l1_ (u"ࠪฬาัฺ่ࠠࠣหๆ๊วๆࠩ䂵") , l1l1l1_l1_ (u"ࠫอำหࠡ฻้ࠤู๊ไิๆสฮࠬ䂶")]
		selection = DIALOG_SELECT(l1l1l1_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢ࠰ࠤฬิสาࠢส่อำหࠨ䂷"), l111l1l11_l1_)
		if selection == -1 : return
		type = l1ll1l1l1_l1_[selection]
	else:
		if l1l1l1_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧ䂸") in options: type = l1l1l1_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䂹")
		elif l1l1l1_l1_ (u"ࠨࡡࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࡠࠩ䂺") in options: type = l1l1l1_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ䂻")
		else: return
	headers[l1l1l1_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䂼")] = l1l1l1_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䂽")
	data = {l1l1l1_l1_ (u"ࠬࡷࡵࡦࡴࡼࠫ䂾"):l11ll11_l1_ , l1l1l1_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡊ࡯࡮ࡣ࡬ࡲࠬ䂿"):type}
	if page!=l1l1l1_l1_ (u"ࠧ࠲ࠩ䃀"): data[l1l1l1_l1_ (u"ࠨࡨࡵࡳࡲ࠭䃁")] = page
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䃂"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ䃃"),data,headers,l1l1l1_l1_ (u"ࠫࠬ䃄"),l1l1l1_l1_ (u"ࠬ࠭䃅"),l1l1l1_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䃆"))
	html = response.content
	items=re.findall(l1l1l1_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䃇"),html,re.DOTALL)
	if items:
		for title,l111ll_l1_ in items:
			url = l1l11l_l1_ + l111ll_l1_.replace(l1l1l1_l1_ (u"ࠨ࡞࠲ࠫ䃈"),l1l1l1_l1_ (u"ࠩ࠲ࠫ䃉"))
			if l1l1l1_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ䃊") in url: addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䃋"),menu_name+l1l1l1_l1_ (u"ࠬ็๊ๅ็ࠣࠫ䃌")+title,url,33)
			elif l1l1l1_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䃍") in url:
				url = url.replace(l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䃎"),l1l1l1_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࠧ䃏"))
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃐"),menu_name+l1l1l1_l1_ (u"ุ้๊ࠪำๅࠢࠪ䃑")+title,url+l1l1l1_l1_ (u"ࠫ࠴࠷ࠧ䃒"),32)
	count=re.findall(l1l1l1_l1_ (u"ࠬࠨࡴࡰࡶࡤࡰࠧࡀࠨ࠯ࠬࡂ࠭ࢂ࠭䃓"),html,re.DOTALL)
	if count:
		pages = int(  (int(count[0])+9)   /10 )+1
		for l1ll1ll11_l1_ in range(1,pages):
			l1ll1ll11_l1_ = str(l1ll1ll11_l1_)
			if l1ll1ll11_l1_!=page:
				addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃔"),l1l1l1_l1_ (u"ࠧึใะอࠥ࠭䃕")+l1ll1ll11_l1_,l1l1l1_l1_ (u"ࠨࠩ䃖"),39,l1l1l1_l1_ (u"ࠩࠪ䃗"),l1ll1ll11_l1_+l1l1l1_l1_ (u"ࠪ࠳ࠬ䃘")+type,search)
	return
def l1ll11lll_l1_():
	l111ll_l1_ = l1l1l1_l1_ (u"ࠫࡦࡎࡒ࠱ࡥࡇࡳࡻࡒ࠲ࡥࡼࡧࡌࡏࡲ࡙ࡘ࠲࠳ࡐࡳࡈࡨࡣ࡯࡙࠴ࡑࡳࡎࡷࡎࡰࡰࡸࡒ࠲ࡗ࡭࡝࠶࡛࡬࡙ࡘࡌࡼࡐ࠷࡮ࡨࡣࡉࡉ࡙࡛࡯࠹ࡸࡤࡊࡊ࠺ࡨࡇ࡭ࡼࡧࡇ࠺ࡺࡍ࠴ࡗ࠷ࠫ䃙")
	l111ll_l1_ = base64.b64decode(l111ll_l1_)
	l111ll_l1_ = l111ll_l1_.decode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䃚"))
	PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"࠭࡬ࡪࡸࡨࠫ䃛"))
	return
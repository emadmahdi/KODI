# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧዊ")
menu_name = l1l1l1_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨዋ")
l1l11l_l1_ = WEBSITES[script_name][0]
headers = {l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧዌ"):l1l1l1_l1_ (u"ࠫࠬው")}
l1l1ll_l1_ = [l1l1l1_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠫዎ"),l1l1l1_l1_ (u"࠭ศไำสࠤ࡙࡜ࠧዏ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l11l11_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==373: results = l1ll11_l1_(url)
	elif mode==374: results = l111ll1l1_l1_(url)
	elif mode==375: results = l111l1ll1_l1_(url)
	elif mode==376: results = l111l1lll_l1_(0,url)
	elif mode==377: results = l111l1lll_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫዐ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩዑ"),l1l1l1_l1_ (u"ࠩࠪዒ"),l1l1l1_l1_ (u"ࠪࠫዓ"),l1l1l1_l1_ (u"ࠫࠬዔ"),l1l1l1_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ዕ"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዖ"),menu_name+l1l1l1_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ዗"),l1l1l1_l1_ (u"ࠨࠩዘ"),379,l1l1l1_l1_ (u"ࠩࠪዙ"),l1l1l1_l1_ (u"ࠪࠫዚ"),l1l1l1_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨዛ"))
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪዜ"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ዝ"),l1l1l1_l1_ (u"ࠧࠨዞ"),9999)
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡴ࡬࡫࡭ࡺ࠭ࡴ࡫ࡧࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨዟ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨዠ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if not any(value in title for value in l1l1ll_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዡ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ዢ")+menu_name+title,l111ll_l1_,371)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዣ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨዤ")+menu_name+l1l1l1_l1_ (u"ࠧศๆ่้๏ุษࠨዥ"),l1l11l_l1_,375)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨዦ"),script_name+l1l1l1_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫዧ")+menu_name+l1l1l1_l1_ (u"ࠪห้ษอะอࠪየ"),l1l11l_l1_,376)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዩ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧዪ")+menu_name+l1l1l1_l1_ (u"๊࠭ีษ๊ำࠥอไร่ࠪያ"),l1l11l_l1_,377)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዬ"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪይ")+menu_name+l1l1l1_l1_ (u"ࠩๅหห๋ษࠡษ็้ํู่ࠨዮ"),l1l11l_l1_,373)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዯ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ደ")+menu_name+l1l1l1_l1_ (u"่ࠬวว็ฬࠤฬ๊ๅๆอ็๎๋࠭ዱ"),l1l11l_l1_,374)
	return
def l1ll11_l1_(website=l1l1l1_l1_ (u"࠭ࠧዲ")):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫዳ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠨࠩዴ"),l1l1l1_l1_ (u"ࠩࠪድ"),l1l1l1_l1_ (u"ࠪࠫዶ"),l1l1l1_l1_ (u"ࠫࠬዷ"),l1l1l1_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩዸ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡵࡱࡳ࠱ࡲ࡫࡮ࡶࠩዹ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ዺ"),block,re.DOTALL)
		for l111ll_l1_,title in items[7:]:
			title = title.strip(l1l1l1_l1_ (u"ࠨࠢࠪዻ"))
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if not any(value in title for value in l1l1ll_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩዼ"),script_name+l1l1l1_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬዽ")+menu_name+title,l111ll_l1_,371)
		for l111ll_l1_,title in items[0:7]:
			title = title.strip(l1l1l1_l1_ (u"ࠫࠥ࠭ዾ"))
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if not any(value in title for value in l1l1ll_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዿ"),script_name+l1l1l1_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨጀ")+menu_name+title,l111ll_l1_,371)
	return html
def l111ll1l1_l1_(website=l1l1l1_l1_ (u"ࠧࠨጁ")):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬጂ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠩࠪጃ"),l1l1l1_l1_ (u"ࠪࠫጄ"),l1l1l1_l1_ (u"ࠫࠬጅ"),l1l1l1_l1_ (u"ࠬ࠭ጆ"),l1l1l1_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡇࡃࡕࡑࡕࡗࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ጇ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠤࡨࡧࡴࠡࡖࡤ࡫ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫገ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧጉ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			if l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶࠧጊ") in l111ll_l1_: continue
			else: l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if not any(value in title for value in l1l1ll_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጋ"),script_name+l1l1l1_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ጌ")+menu_name+title,l111ll_l1_,371)
	return
def l111l1ll1_l1_(website=l1l1l1_l1_ (u"ࠬ࠭ግ")):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪጎ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠧࠨጏ"),l1l1l1_l1_ (u"ࠨࠩጐ"),l1l1l1_l1_ (u"ࠩࠪ጑"),l1l1l1_l1_ (u"ࠪࠫጒ"),l1l1l1_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡊࡊࡇࡔࡖࡔࡈࡈ࠲࠷ࡳࡵࠩጓ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠧጔ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫጕ"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if not any(value in title for value in l1l1ll_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭጖"),script_name+l1l1l1_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ጗")+menu_name+title,l111ll_l1_,372,img)
	return
def l111l1lll_l1_(id,website=l1l1l1_l1_ (u"ࠩࠪጘ")):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧጙ"),l1l11l_l1_,l1l1l1_l1_ (u"ࠫࠬጚ"),l1l1l1_l1_ (u"ࠬ࠭ጛ"),l1l1l1_l1_ (u"࠭ࠧጜ"),l1l1l1_l1_ (u"ࠧࠨጝ"),l1l1l1_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡘࡃࡗࡇࡍࡏࡎࡈࡐࡒ࡛࠲࠷ࡳࡵࠩጞ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨጟ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[id]
		items = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ጠ"),block,re.DOTALL)
		for l111ll_l1_,img,title in items:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_
			if not any(value in title for value in l1l1ll_l1_):
				addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪጡ"),script_name+l1l1l1_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧጢ")+menu_name+title,l111ll_l1_,372,img)
	return
def l11l11_l1_(url,type1=l1l1l1_l1_ (u"࠭ࠧጣ")):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨጤ"),l1l1l1_l1_ (u"ࠨࠩጥ"),type1,url)
	#LOG_THIS(l1l1l1_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩጦ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧጧ"),url,l1l1l1_l1_ (u"ࠫࠬጨ"),l1l1l1_l1_ (u"ࠬ࠭ጩ"),l1l1l1_l1_ (u"࠭ࠧጪ"),l1l1l1_l1_ (u"ࠧࠨጫ"),l1l1l1_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫጬ"))
	html = response.content
	if l1l1l1_l1_ (u"ࠩࡹ࡭ࡩࡶࡡࡨࡧࡢࠫጭ") in url:
		l111ll_l1_ = re.findall(l1l1l1_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡆࡲࡢࡶ࡯࠰࠲࠯ࡅࠩࠣࠩጮ"),html,re.DOTALL)
		if l111ll_l1_:
			l111ll_l1_ = l1l11l_l1_+l111ll_l1_[0]
			l11l11_l1_(l111ll_l1_)
			return
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࠥࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡯ࡧ࠱࠸࠭ጯ"),html,re.DOTALL)
	if type1==l1l1l1_l1_ (u"ࠬ࠭ጰ") and l1ll1l1_l1_ and l1ll1l1_l1_[0].count(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࠫጱ"))>1:
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧጲ"),menu_name+l1l1l1_l1_ (u"ࠨษ็ะ๊๐ูࠨጳ"),url,371,l1l1l1_l1_ (u"ࠩࠪጴ"),l1l1l1_l1_ (u"ࠪࠫጵ"),l1l1l1_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡶࠫጶ"))
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫጷ"),block,re.DOTALL)
		for l111ll_l1_,title in items:
			l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࠨጸ")+l111ll_l1_
			title = title.strip(l1l1l1_l1_ (u"ࠧࠡࠩጹ"))
			addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጺ"),menu_name+title,l111ll_l1_,371)
	else:
		l1l1_l1_ = []
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡭ࡥ࠯࠶ࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡾࡳ࠮࠳࠵ࠫጻ"),html,re.DOTALL)
		if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠼ࠧ࠮࠮ࠫࡁࠬࡧࡴࡲ࠭ࡹࡵ࠰࠵࠷࠭ጼ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ጽ"),block,re.DOTALL)
			l1l1l1_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵ࠤࡂ࡛ࠦ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸࡷࡿ࠺ࠡࡥࡲࡹࡳࡺࠠ࠾ࠢ࡬ࡲࡹ࠮ࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫฬ๊อๅไฬࠤ࠰࠮࡜ࡥ࠭ࠬࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠ࠭ࠏࠏࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡧࡴࡻ࡮ࡵࠢࡀࠤ࠲࠷ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵࠲ࡦࡶࡰࡦࡰࡧࠬ࠭ࡲࡩ࡯࡭࠯࡭ࡲ࡭ࠬࡵ࡫ࡷࡰࡪ࠲ࡣࡰࡷࡱࡸ࠮࠯ࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡮ࡺࡥ࡮ࡵ࠵࠰ࠥࡸࡥࡷࡧࡵࡷࡪࡃࡆࡢ࡮ࡶࡩ࠱ࠦ࡫ࡦࡻࡀࡰࡦࡳࡢࡥࡣࠣ࡯ࡪࡿ࠺ࠡ࡭ࡨࡽࡠ࠹࡝ࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡧࡴࡻ࡮ࡵࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠤࠥࠦጾ")
			for l111ll_l1_,img,title in items:
				#img = l1l11l_l1_+img
				l111ll_l1_ = l1l11l_l1_+l111ll_l1_
				title = title.strip(l1l1l1_l1_ (u"࠭ࠠࠨጿ"))
				if l1l1l1_l1_ (u"ࠧ࠰ࡣ࡯ࡣࠬፀ") in l111ll_l1_:
					addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨፁ"),menu_name+title,l111ll_l1_,371,img)
				elif l1l1l1_l1_ (u"ࠩส่า๊โสࠩፂ") in title and (l1l1l1_l1_ (u"ࠪ࠳ࡈࡧࡴ࠮ࠩፃ") in url or l1l1l1_l1_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬࠴࠭ፄ") in url):
					l1llll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠲ࠦࠫศๆะ่็ฯࠠࠬ࡞ࡧ࠯ࠬፅ"),title,re.DOTALL)
					if l1llll1_l1_: title = l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣู๊ไิๆࠣࠫፆ")+l1llll1_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧፇ"),menu_name+title,l111ll_l1_,371,img)
				else: addMenuItem(l1l1l1_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧፈ"),menu_name+title,l111ll_l1_,372,img)
		l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪፉ"),html,re.DOTALL)
		if l1ll1l1_l1_:
			block = l1ll1l1_l1_[0]
			items = re.findall(l1l1l1_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ፊ"),block,re.DOTALL)
			for l111ll_l1_,title in items:
				l111ll_l1_ = l1l11l_l1_+l111ll_l1_
				title = l1l1l1_l1_ (u"ฺࠫ็อสࠢࠪፋ")+unescapeHTML(title)
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬፌ"),menu_name+title,l111ll_l1_,371,l1l1l1_l1_ (u"࠭ࠧፍ"),l1l1l1_l1_ (u"ࠧࠨፎ"),l1l1l1_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࡳࠨፏ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭ፐ"),url,l1l1l1_l1_ (u"ࠪࠫፑ"),l1l1l1_l1_ (u"ࠫࠬፒ"),l1l1l1_l1_ (u"ࠬ࠭ፓ"),l1l1l1_l1_ (u"࠭ࠧፔ"),l1l1l1_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨፕ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡮ࡤࡦࡪࡲ࠭ࡴࡷࡦࡧࡪࡹࡳࠡ࡯ࡵ࡫࠲ࡨࡴ࡮࠯࠸ࠤࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ፖ"),html,re.DOTALL)
	if l1l1ll1_l1_ and l11lll1_l1_(script_name,url,l1l1ll1_l1_): return
	url3 = l1l1l1_l1_ (u"ࠩࠪፗ")
	url2 = re.findall(l1l1l1_l1_ (u"ࠪࡺࡦࡸࠠࡶࡴ࡯ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧፘ"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = url.replace(l1l1l1_l1_ (u"ࠫ࠴ࡼࡩࡥࡲࡤ࡫ࡪࡥࠧፙ"),l1l1l1_l1_ (u"ࠬ࠵ࡐ࡭ࡣࡼ࠳ࠬፚ"))
	if l1l1l1_l1_ (u"࠭ࡨࡵࡶࡳࠫ፛") not in url2: url2 = l1l11l_l1_+url2
	url2 = url2.strip(l1l1l1_l1_ (u"ࠧ࠮ࠩ፜"))
	response = OPENURL_REQUESTS_CACHED(l1llll111_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ፝"),url2,l1l1l1_l1_ (u"ࠩࠪ፞"),l1l1l1_l1_ (u"ࠪࠫ፟"),l1l1l1_l1_ (u"ࠫࠬ፠"),l1l1l1_l1_ (u"ࠬ࠭፡"),l1l1l1_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ።"))
	l1l11l11_l1_ = response.content
	url3 = re.findall(l1l1l1_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ፣"),l1l11l11_l1_,re.DOTALL)
	if url3:
		url3 = url3[-1]
		if l1l1l1_l1_ (u"ࠨࡪࡷࡸࡵ࠭፤") not in url3: url3 = l1l1l1_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ፥")+url3
		if l1l1l1_l1_ (u"ࠪ࠳ࡕࡒࡁ࡚࠱ࠪ፦") not in url2:
			if l1l1l1_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠱ࡱ࡮ࡴ࠮࡫ࡵࠪ፧") in url3:
				l111ll111_l1_ = re.findall(l1l1l1_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡴࡺࡨ࡬ࡪࡵ࡫ࡩࡷ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ፨"),l1l11l11_l1_,re.DOTALL)
				if l111ll111_l1_:
					l111l1l1l_l1_, l111ll11l_l1_ = l111ll111_l1_[0]
					url3 = SERVER(url3,l1l1l1_l1_ (u"࠭ࡵࡳ࡮ࠪ፩"))+l1l1l1_l1_ (u"ࠧ࠰ࡸ࠵࠳ࠬ፪")+l111l1l1l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡦࡳࡳ࡬ࡩࡨ࠱ࠪ፫")+l111ll11l_l1_+l1l1l1_l1_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨ፬")
		import ll_l1_
		ll_l1_.l1l_l1_([url3],script_name,l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ፭"),url)
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬ፮"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭፯"): return
	search = search.replace(l1l1l1_l1_ (u"࠭ࠠࠨ፰"),l1l1l1_l1_ (u"ࠧࠬࠩ፱"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡖࡩࡦࡸࡣࡩ࠱ࠪ፲")+search
	l11l11_l1_(url)
	return
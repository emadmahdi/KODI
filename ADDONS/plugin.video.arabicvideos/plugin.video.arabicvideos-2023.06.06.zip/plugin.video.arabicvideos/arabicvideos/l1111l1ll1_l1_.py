# -*- coding: utf-8 -*-
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
from EXCLUDES import *
import bs4
script_name = l1l1l1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ⎓")
menu_name = l1l1l1_l1_ (u"ࠨࡡࡈࡐࡈࡥࠧ⎔")
l1l11l_l1_ = WEBSITES[script_name][0]
l1l1ll_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l11111111l_l1_(url)
	elif mode==512: results = l111l1111l_l1_(url)
	elif mode==513: results = l111l11111_l1_(url)
	elif mode==514: results = l1111111l1_l1_(url,l1l1l1_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⎕")+text)
	elif mode==515: results = l1111111l1_l1_(url,l1l1l1_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⎖")+text)
	elif mode==516: results = l1111l1111_l1_(text)
	elif mode==517: results = l1111ll11l_l1_(url)
	elif mode==518: results = l1111ll1l1_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1111l11ll_l1_(url)
	elif mode==521: results = l111111111_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l111111l11_l1_(text)
	elif mode==524: results = l111111ll1_l1_()
	elif mode==525: results = l1111lllll_l1_()
	elif mode==526: results = l1111l11l1_l1_()
	elif mode==527: results = l111111lll_l1_()
	else: results = False
	return results
def MENU(website=l1l1l1_l1_ (u"ࠫࠬ⎗")):
	if not website:
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎘"),menu_name+l1l1l1_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⎙"),l1l1l1_l1_ (u"ࠧࠨ⎚"),519)
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⎛"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠶ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠳࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⎜"),l1l1l1_l1_ (u"ࠪࠫ⎝"),9999)
		addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎞"),menu_name+l1l1l1_l1_ (u"๋่ࠬิ๊฼อࠥอไฤ฻่ห้࠭⎟"),l1l1l1_l1_ (u"࠭ࠧ⎠"),525)
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎡"),menu_name+l1l1l1_l1_ (u"ࠨ็๋ืํ฿ษࠡษ็วูิวึࠩ⎢"),l1l1l1_l1_ (u"ࠩࠪ⎣"),526)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎤"),menu_name+l1l1l1_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊ๅึ่ไหฯ࠭⎥"),l1l1l1_l1_ (u"ࠬ࠭⎦"),527)
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎧"),menu_name+l1l1l1_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆ่๊ํ฿วหࠩ⎨"),l1l1l1_l1_ (u"ࠨࠩ⎩"),524)
	return
def l111111ll1_l1_():
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎪"),menu_name+l1l1l1_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦ࠭ࠡะสูฮ࠭⎫"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࠫ⎬"),520)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎭"),menu_name+l1l1l1_l1_ (u"࠭แ๋ัํ์์อสࠡ࠯ࠣวาีหࠨ⎮"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯࡭ࡣࡷࡩࡸࡺࠧ⎯"),521)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎰"),menu_name+l1l1l1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ࠲ࠦรใั่ࠫ⎱"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࡳࡱࡪࡥࡴࡶࠪ⎲"),521)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎳"),menu_name+l1l1l1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦ็ะืࠠๆึส๋ิฯࠧ⎴"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࡶࡪࡧࡺࡷࠬ⎵"),521)
	return
def l1111lllll_l1_():
	l1l1l1_l1_ (u"ࠢࠣࠤࠐࠎࠎࡺࡹࡱࡧࠣࡁࠥ࠷ࠠࠤࠢࡤࡧࡹࡵࡲࡴࠏࠍࠍࡹࡿࡰࡦࠢࡀࠤ࠷ࠦࠣࠡࡸ࡬ࡨࡪࡵࡳࠎࠌࠌࡧࡦࡺࡥࡨࡱࡵࡽࠥࡃࠠ࠲ࠢࠦࠤࡲࡵࡶࡪࡧࡶࠑࠏࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࠷ࠥࠩࠠࡴࡧࡵ࡭ࡪࡹࠍࠋࠋࡩࡳࡷ࡫ࡩࡨࡰࠣࡁࠥ࡬ࡡ࡭ࡵࡨࠤࠨࠦࡡࡳࡣࡥ࡭ࡨࠓࠊࠊࡨࡲࡶࡪ࡯ࡧ࡯ࠢࡀࠤࡹࡸࡵࡦࠢࠦࠤࡪࡴࡧ࡭࡫ࡶ࡬ࠒࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬๅฬๆํ๊ࠥษแๅษ่ࠤ฾ืศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠳࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠๆี็ื้อสࠡ฻ิฬ๏࠭ࠬ࡭࡫ࡱ࡯࠸࠲࠵࠲࠳ࠬࠑࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮๊๋ࠫหๅ์้ࠤศ็ไศ็ࠣหั์ศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠵࠮࠸࠵࠶࠯ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠๆี็ื้อสࠡษฯ๊อ๐ࠧ࠭࡮࡬ࡲࡰ࠻ࠬ࠶࠳࠴࠭ࠒࠐࠉ࡭࡫ࡱ࡯࠶ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠸ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠹ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊ࡮࡬ࡲࡰ࠺ࠠ࠾ࠢ࡯࡭ࡳࡱ࠰ࠬࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡶࡵࡹࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠺ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏࠢࠣࠤ⎶")
	l11111l1l1_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠪ⎷")
	l11111ll11_l1_ = l11111l1l1_l1_+l1l1l1_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠷ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬ⎸")
	l1111llll1_l1_ = l11111l1l1_l1_+l1l1l1_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡩࡥࡱࡹࡥࠧࡶࡤ࡫ࡂ࠭⎹")
	l11111l111_l1_ = l11111l1l1_l1_+l1l1l1_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭⎺")
	l11111l11l_l1_ = l11111l1l1_l1_+l1l1l1_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠵ࠩࡪࡴࡸࡥࡪࡩࡱࡁࡹࡸࡵࡦࠨࡷࡥ࡬ࡃࠧ⎻")
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎼"),menu_name+l1l1l1_l1_ (u"ࠧๆื้ๅฬะࠠฤใ็หู๊ࠦาสํࠫ⎽"),l11111ll11_l1_,511)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎾"),menu_name+l1l1l1_l1_ (u"ู่๋ࠩ็วห่ࠢืู้ไศฬࠣ฽ึฮ๊ࠨ⎿"),l1111llll1_l1_,511)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏀"),menu_name+l1l1l1_l1_ (u"๊ࠫ฻ๆโษอࠤศ็ไศ็ࠣหั์ศ๋ࠩ⏁"),l11111l111_l1_,511)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏂"),menu_name+l1l1l1_l1_ (u"࠭ๅึ่ไหฯࠦๅิๆึ่ฬะࠠศฮ้ฬ๏࠭⏃"),l11111l11l_l1_,511)
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⏄"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠲࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⏅"),l1l1l1_l1_ (u"ࠩࠪ⏆"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏇"),menu_name+l1l1l1_l1_ (u"ࠫๆํัิࠢฦ฽๊อไࠡลหะิ๐ࠧ⏈"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡥࡱࡶࡨࡢࡤࡨࡸࠬ⏉"),517)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏊"),menu_name+l1l1l1_l1_ (u"ࠧโ้ิืࠥࠦศๅัࠣห้หๆหษฯࠫ⏋"),l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡹࡲࡶࡰ࠵ࡣࡰࡷࡱࡸࡷࡿࠧ⏌"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏍"),menu_name+l1l1l1_l1_ (u"ࠪๅ์ืำࠡษ็่฿ฯࠧ⏎"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ⏏"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏐"),menu_name+l1l1l1_l1_ (u"࠭แ่ำึࠤ๊฻ๆโษอࠤฬู๊ๆๆࠪ⏑"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴࡭ࡥ࡯ࡴࡨࠫ⏒"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏓"),menu_name+l1l1l1_l1_ (u"ࠩไ๋ึูࠠิ่ฬࠤฬ๊ลึัสีࠬ⏔"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡴࡨࡰࡪࡧࡳࡦࡡࡼࡩࡦࡸࠧ⏕"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⏖"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠷ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⏗"),l1l1l1_l1_ (u"࠭ࠧ⏘"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏙"),menu_name+l1l1l1_l1_ (u"ࠨ็๋หุ๋ࠠ࠮ࠢไ่ฯืࠠๆฯาำࠬ⏚"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡤࡰࡸ࠭⏛"),515)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏜"),menu_name+l1l1l1_l1_ (u"๊ࠫ๎วิ็ࠣ࠱ࠥ็ไหำࠣ็ฬ๋ไࠨ⏝"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡧ࡬ࡴࠩ⏞"),514)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⏟"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠶ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠳࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⏠"),l1l1l1_l1_ (u"ࠨࠩ⏡"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏢"),menu_name+l1l1l1_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨ⏣"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ⏤"),515)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏥"),menu_name+l1l1l1_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫ⏦"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ⏧"),514)
	return
def l111111lll_l1_():
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠨࡉࡈࡘࠬ⏨"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ⏩"),l1l1l1_l1_ (u"ࠪࠫ⏪"),l1l1l1_l1_ (u"ࠫࠬ⏫"),l1l1l1_l1_ (u"ࠬ࠭⏬"),l1l1l1_l1_ (u"࠭ࠧ⏭"),l1l1l1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⏮"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭⏯"),multi_valued_attributes=None)
	block = l1lllllllll_l1_.find(l1l1l1_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵࠩ⏰"),attrs={l1l1l1_l1_ (u"ࠪࡲࡦࡳࡥࠨ⏱"):l1l1l1_l1_ (u"ࠫࡹࡧࡧࠨ⏲")})	# <select name=l1l1l1_l1_ (u"ࠬࡺࡡࡨࠩ⏳")>
	options = block.find_all(l1l1l1_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳ࠭⏴"))
	for option in options:
		value = option.get(l1l1l1_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭⏵"))		# or option[l1l1l1_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ⏶")] l11l1lllll_l1_ it will fail if not l1l1lll1l_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⏷"))
			value = value.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⏸"))
		l111ll_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࡄࡻࡴࡧ࠺ࡀࠩࡊ࠸ࠥ࠺ࡅࠨ࠽࠸ࠬࡴࡺࡲࡨࡁࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࠩࡸࡦ࡭࠽ࠨ⏹")+value
		title = title.replace(l1l1l1_l1_ (u"่ࠬวว็ฬࠤࠬ⏺"),l1l1l1_l1_ (u"࠭ࠧ⏻"))
		addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏼"),menu_name+title,l111ll_l1_,511)
	return
def l1111l11l1_l1_():
	l11111l1l1_l1_ = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࡁࡸࡸ࡫࠾࠽ࠦࡇ࠵ࠩ࠾ࡉࠥ࠺࠵ࠪ⏽")
	l11111l1ll_l1_ = l11111l1l1_l1_+l1l1l1_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠳ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࠧࡶࡤ࡫ࡂ࠭⏾")
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏿"),menu_name+l1l1l1_l1_ (u"๊ࠫ฻ๆโษอࠤศฺฮศืࠪ␀"),l11111l1ll_l1_,511)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ␁"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ␂"),l1l1l1_l1_ (u"ࠧࠨ␃"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␄"),menu_name+l1l1l1_l1_ (u"ࠩไ๋ึูࠠฤึัหฺࠦรษฮา๎ࠬ␅"),l1l11l_l1_+l1l1l1_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡴࡪࡸࡳࡰࡰ࠲ࡥࡱࡶࡨࡢࡤࡨࡸࠬ␆"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␇"),menu_name+l1l1l1_l1_ (u"ࠬ็็าี้ࠣํ฽ๆࠨ␈"),l1l11l_l1_+l1l1l1_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡰࡦࡴࡶࡳࡳ࠵࡮ࡢࡶ࡬ࡳࡳࡧ࡬ࡪࡶࡼࠫ␉"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␊"),menu_name+l1l1l1_l1_ (u"ࠨใ๊ีุࠦࠠหษิ๎ำࠦวๅ็ํ่ฬีࠧ␋"),l1l11l_l1_+l1l1l1_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡥ࡭ࡷࡺࡨࡠࡻࡨࡥࡷ࠭␌"),517)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␍"),menu_name+l1l1l1_l1_ (u"ࠫๆํัิࠢࠣฮฬื๊ฯࠢส่ํ็วสࠩ␎"),l1l11l_l1_+l1l1l1_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡪࡥࡢࡶ࡫ࡣࡾ࡫ࡡࡳࠩ␏"),517)
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ␐"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠵ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠲࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ␑"),l1l1l1_l1_ (u"ࠨࠩ␒"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␓"),menu_name+l1l1l1_l1_ (u"ฺ้ࠪ์แศฬࠣ࠱ࠥ็ไหำ้ࠣาีฯࠨ␔"),l1l11l_l1_+l1l1l1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ␕"),515)
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ␖"),menu_name+l1l1l1_l1_ (u"࠭ๅึ่ไหฯࠦ࠭ࠡใ็ฮึࠦใศ็็ࠫ␗"),l1l11l_l1_+l1l1l1_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࠨ␘"),514)
	return
def l11111111l_l1_(url):
	if l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ␙") in url: index = 0
	elif l1l1l1_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ␚") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠪࡋࡊ࡚ࠧ␛"),url,l1l1l1_l1_ (u"ࠫࠬ␜"),l1l1l1_l1_ (u"ࠬ࠭␝"),l1l1l1_l1_ (u"࠭ࠧ␞"),l1l1l1_l1_ (u"ࠧࠨ␟"),l1l1l1_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭␠"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ␡"),multi_valued_attributes=None)
	l1l11l1_l1_ = l1lllllllll_l1_.find_all(class_=l1l1l1_l1_ (u"ࠪ࡮ࡺࡳࡢࡰ࠯ࡷ࡬ࡪࡧࡴࡦࡴࠣࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠬ␢"))
	for block in l1l11l1_l1_:
		title = block.find_all(l1l1l1_l1_ (u"ࠫࡦ࠭␣"))[index].text
		l111ll_l1_ = l1l11l_l1_+block.find_all(l1l1l1_l1_ (u"ࠬࡧࠧ␤"))[index].get(l1l1l1_l1_ (u"࠭ࡨࡳࡧࡩࠫ␥"))
		if kodi_version<19:
			title = title.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ␦"))
			l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭␧"))
		if not l1l11l1_l1_:
			l111l1111l_l1_(l111ll_l1_)
			return
		else:
			title = title.replace(l1l1l1_l1_ (u"ࠩๅหห๋ษࠡࠩ␨"),l1l1l1_l1_ (u"ࠪࠫ␩"))
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␪"),menu_name+title,l111ll_l1_,512)
	PAGINATION(l1lllllllll_l1_,511)
	return
def PAGINATION(l1lllllllll_l1_,mode):
	block = l1lllllllll_l1_.find(class_=l1l1l1_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ␫"))
	if block:
		pages = block.find_all(l1l1l1_l1_ (u"࠭ࡡࠨ␬"))
		l1llllllll1_l1_ = block.find_all(l1l1l1_l1_ (u"ࠧ࡭࡫ࠪ␭"))
		l1111l111l_l1_ = list(zip(pages,l1llllllll1_l1_))
		ii = -1
		length = len(l1111l111l_l1_)
		for l1ll1ll11_l1_,l1111111ll_l1_ in l1111l111l_l1_:
			ii += 1
			l1111111ll_l1_ = l1111111ll_l1_[l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ␮")]
			if l1l1l1_l1_ (u"ࠩࡸࡲࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠧ␯") in l1111111ll_l1_ or l1l1l1_l1_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࠫ␰") in l1111111ll_l1_: continue
			name2 = l1ll1ll11_l1_.text
			l11111ll1_l1_ = l1l11l_l1_+l1ll1ll11_l1_.get(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ␱"))
			if kodi_version<19:
				name2 = name2.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ␲"))
				l11111ll1_l1_ = l11111ll1_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ␳"))
			if   ii==0: name2 = l1l1l1_l1_ (u"ࠧฤ๊็ํࠬ␴")
			elif ii==1: name2 = l1l1l1_l1_ (u"ࠨีสฬ็ฯࠧ␵")
			elif ii==length-2: name2 = l1l1l1_l1_ (u"ࠩ็หา่ษࠨ␶")
			elif ii==length-1: name2 = l1l1l1_l1_ (u"ࠪวำ๐ัสࠩ␷")
			addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␸"),menu_name+l1l1l1_l1_ (u"ࠬ฻แฮหࠣࠫ␹")+name2,l11111ll1_l1_,mode)
	return
def l111l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ␺"),url,l1l1l1_l1_ (u"ࠧࠨ␻"),l1l1l1_l1_ (u"ࠨࠩ␼"),l1l1l1_l1_ (u"ࠩࠪ␽"),l1l1l1_l1_ (u"ࠪࠫ␾"),l1l1l1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠷࠭࠲ࡵࡷࠫ␿"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⑀"),multi_valued_attributes=None)
	l1l11l1_l1_ = l1lllllllll_l1_.find_all(class_=l1l1l1_l1_ (u"࠭ࡲࡰࡹࠪ⑁"))
	items,first = [],True
	for block in l1l11l1_l1_:
		if not block.find(class_=l1l1l1_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠰ࡻࡷࡧࡰࡱࡧࡵࠫ⑂")): continue
		if first: first = False ; continue
		l1111ll111_l1_ = []
		l1lllllll1l_l1_ = block.find_all(class_=[l1l1l1_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡸࡥࡥࠩ⑃"),l1l1l1_l1_ (u"ࠩࡦࡩࡳࡹ࡯ࡳࡵ࡫࡭ࡵࠦࡰࡶࡴࡳࡰࡪ࠭⑄")])
		for l111111l1l_l1_ in l1lllllll1l_l1_:
			l1lll1l1ll_l1_ = l111111l1l_l1_.find_all(l1l1l1_l1_ (u"ࠪࡰ࡮࠭⑅"))[1].text
			if kodi_version<19:
				l1lll1l1ll_l1_ = l1lll1l1ll_l1_.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⑆"))
			l1111ll111_l1_.append(l1lll1l1ll_l1_)
		if not l11lll1_l1_(script_name,l1l1l1_l1_ (u"ࠬ࠭⑇"),l1111ll111_l1_,False):
			image = block.find(l1l1l1_l1_ (u"࠭ࡩ࡮ࡩࠪ⑈")).get(l1l1l1_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤࠩ⑉"))
			title = block.find(l1l1l1_l1_ (u"ࠨࡪ࠶ࠫ⑊"))
			name = title.find(l1l1l1_l1_ (u"ࠩࡤࠫ⑋")).text
			l111ll_l1_ = l1l11l_l1_+title.find(l1l1l1_l1_ (u"ࠪࡥࠬ⑌")).get(l1l1l1_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⑍"))
			plot = block.find(class_=l1l1l1_l1_ (u"ࠬࡴ࡯࠮࡯ࡤࡶ࡬࡯࡮ࠨ⑎"))
			stars = block.find(class_=l1l1l1_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭⑏"))
			if plot: plot = plot.text
			if stars: stars = stars.text
			if kodi_version<19:
				image = image.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⑐"))
				name = name.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭⑑"))
				l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⑒"))
				if plot: plot = plot.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⑓"))
			infodict = {}
			if stars: infodict[l1l1l1_l1_ (u"ࠫࡸࡺࡡࡳࡵࠪ⑔")] = stars
			if plot:
				plot = plot.replace(l1l1l1_l1_ (u"ࠬࡢ࡮ࠨ⑕"),l1l1l1_l1_ (u"࠭ࠠ࠯࠰ࠣࠫ⑖"))
				infodict[l1l1l1_l1_ (u"ࠧࡱ࡮ࡲࡸࠬ⑗")] = plot.replace(l1l1l1_l1_ (u"ࠨ࠰࠱࠲ฬ่ัฤࠢสุ่๊๊ะࠩ⑘"),l1l1l1_l1_ (u"ࠩࠪ⑙"))
			if l1l1l1_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪ⑚") in l111ll_l1_:
				#name = l1l1l1_l1_ (u"ࠫอำหࠡ฻้ࠤࠬ⑛")+name
				addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⑜"),menu_name+name,l111ll_l1_,516,image,l1l1l1_l1_ (u"࠭ࠧ⑝"),name,l1l1l1_l1_ (u"ࠧࠨ⑞"),infodict)
			elif l1l1l1_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⑟") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ①"),menu_name+name,l111ll_l1_,513,image,l1l1l1_l1_ (u"ࠪࠫ②"),name,l1l1l1_l1_ (u"ࠫࠬ③"),infodict)
	PAGINATION(l1lllllllll_l1_,512)
	return
def l111l11111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠬࡍࡅࡕࠩ④"),url,l1l1l1_l1_ (u"࠭ࠧ⑤"),l1l1l1_l1_ (u"ࠧࠨ⑥"),l1l1l1_l1_ (u"ࠨࠩ⑦"),l1l1l1_l1_ (u"ࠩࠪ⑧"),l1l1l1_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠷࠳࠱ࡴࡶࠪ⑨"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⑩"),multi_valued_attributes=None)
	l1l11l1_l1_ = l1lllllllll_l1_.find_all(l1l1l1_l1_ (u"ࠬࡲࡩࠨ⑪"))
	names,items = [],[]
	for block in l1l11l1_l1_:
		if not block.find(class_=l1l1l1_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯ࡺࡶࡦࡶࡰࡦࡴࠪ⑫")): continue
		if not block.find(class_=[l1l1l1_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠩ⑬"),l1l1l1_l1_ (u"ࠨࡷࡱࡷࡹࡿ࡬ࡦࡦࠣࡸࡪࡾࡴ࠮ࡥࡨࡲࡹ࡫ࡲࠨ⑭")]): continue
		if block.find(class_=l1l1l1_l1_ (u"ࠩ࡫࡭ࡩ࡫ࠧ⑮")): continue
		title = block.find(class_=[l1l1l1_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠬ⑯"),l1l1l1_l1_ (u"ࠫࡺࡴࡳࡵࡻ࡯ࡩࡩࠦࡴࡦࡺࡷ࠱ࡨ࡫࡮ࡵࡧࡵࠫ⑰")])
		name = title.find(l1l1l1_l1_ (u"ࠬࡧࠧ⑱")).text
		if name in names: continue
		names.append(name)
		l111ll_l1_ = l1l11l_l1_+title.find(l1l1l1_l1_ (u"࠭ࡡࠨ⑲")).get(l1l1l1_l1_ (u"ࠧࡩࡴࡨࡪࠬ⑳"))
		if l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡺࡳࡷࡱ࠯ࠨ⑴") in url: image = block.find(l1l1l1_l1_ (u"ࠩ࡬ࡱ࡬࠭⑵")).get(l1l1l1_l1_ (u"ࠪࡷࡷࡩࠧ⑶"))
		elif l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭⑷") in url: image = block.find(l1l1l1_l1_ (u"ࠬ࡯࡭ࡨࠩ⑸")).get(l1l1l1_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ⑹"))
		elif l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ⑺") in url: image = block.find(l1l1l1_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⑻")).get(l1l1l1_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ⑼"))
		else: image = block.find(l1l1l1_l1_ (u"ࠪ࡭ࡲ࡭ࠧ⑽")).get(l1l1l1_l1_ (u"ࠫࡸࡸࡣࠨ⑾"))
		if kodi_version<19:
			name = name.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⑿"))
			l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⒀"))
			image = image.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⒁"))
		name = name.strip(l1l1l1_l1_ (u"ࠨࠢࠪ⒂"))
		items.append((name,l111ll_l1_,image))
	if l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ⒃") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,l111ll_l1_,image in items:
		if l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡻ࡯ࡤࡦࡱ࠲ࠫ⒄") in url: addMenuItem(l1l1l1_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⒅"),menu_name+name,l111ll_l1_,522,image)
		elif l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡰࡦࡴࡶࡳࡳ࠵ࠧ⒆") in url: addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒇"),menu_name+name,l111ll_l1_,513,image,l1l1l1_l1_ (u"ࠧࠨ⒈"),name)
		else: addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒉"),menu_name+name,l111ll_l1_,516,image,l1l1l1_l1_ (u"ࠩࠪ⒊"),name)
	return
def l1111l1111_l1_(text):
	text = text.replace(l1l1l1_l1_ (u"ࠪห้หูๅษ้ࠫ⒋"),l1l1l1_l1_ (u"ࠫࠬ⒌")).replace(l1l1l1_l1_ (u"๊ࠬแ๋ๆ่ࠫ⒍"),l1l1l1_l1_ (u"࠭ࠧ⒎")).replace(l1l1l1_l1_ (u"ࠧศๆิื๊๐ࠧ⒏"),l1l1l1_l1_ (u"ࠨࠩ⒐"))
	text = text.replace(l1l1l1_l1_ (u"ࠩศ฽้อๆࠨ⒑"),l1l1l1_l1_ (u"ࠪࠫ⒒")).replace(l1l1l1_l1_ (u"ࠫๆ๐ไๆࠩ⒓"),l1l1l1_l1_ (u"ࠬ࠭⒔")).replace(l1l1l1_l1_ (u"࠭วๅสิ์๊๎ࠧ⒕"),l1l1l1_l1_ (u"ࠧࠨ⒖"))
	text = text.replace(l1l1l1_l1_ (u"ࠨษ็ฮู๎๊ใ์ࠪ⒗"),l1l1l1_l1_ (u"ࠩࠪ⒘")).replace(l1l1l1_l1_ (u"ู่๊ࠪไิๆࠪ⒙"),l1l1l1_l1_ (u"ࠫࠬ⒚")).replace(l1l1l1_l1_ (u"๋ࠬำๅี็ࠫ⒛"),l1l1l1_l1_ (u"࠭ࠧ⒜"))
	text = text.replace(l1l1l1_l1_ (u"ࠧ࠻ࠩ⒝"),l1l1l1_l1_ (u"ࠨࠩ⒞")).replace(l1l1l1_l1_ (u"ࠩࠬࠫ⒟"),l1l1l1_l1_ (u"ࠪࠫ⒠")).replace(l1l1l1_l1_ (u"ࠫ࠭࠭⒡"),l1l1l1_l1_ (u"ࠬ࠭⒢")).replace(l1l1l1_l1_ (u"࠭ࠬࠨ⒣"),l1l1l1_l1_ (u"ࠧࠨ⒤"))
	text = text.replace(l1l1l1_l1_ (u"ࠨࡡࠪ⒥"),l1l1l1_l1_ (u"ࠩࠪ⒦")).replace(l1l1l1_l1_ (u"ࠪ࠿ࠬ⒧"),l1l1l1_l1_ (u"ࠫࠬ⒨")).replace(l1l1l1_l1_ (u"ࠬ࠳ࠧ⒩"),l1l1l1_l1_ (u"࠭ࠧ⒪")).replace(l1l1l1_l1_ (u"ࠧ࠯ࠩ⒫"),l1l1l1_l1_ (u"ࠨࠩ⒬"))
	text = text.replace(l1l1l1_l1_ (u"ࠩ࡟ࠫࠬ⒭"),l1l1l1_l1_ (u"ࠪࠫ⒮")).replace(l1l1l1_l1_ (u"ࠫࡡࠨࠧ⒯"),l1l1l1_l1_ (u"ࠬ࠭⒰"))
	text = text.replace(l1l1l1_l1_ (u"࠭ࠠࠡࠢࠣࠫ⒱"),l1l1l1_l1_ (u"ࠧࠡࠩ⒲")).replace(l1l1l1_l1_ (u"ࠨࠢࠣࠤࠬ⒳"),l1l1l1_l1_ (u"ࠩࠣࠫ⒴")).replace(l1l1l1_l1_ (u"ࠪࠤࠥ࠭⒵"),l1l1l1_l1_ (u"ࠫࠥ࠭Ⓐ"))
	text = text.strip(l1l1l1_l1_ (u"ࠬࠦࠧⒷ"))
	l1111ll1ll_l1_ = text.count(l1l1l1_l1_ (u"࠭ࠠࠨⒸ"))+1
	if l1111ll1ll_l1_==1:
		l111111l11_l1_(text)
		return
	addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⒹ"),menu_name+l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽ࠡๅ็้ฬะࠠๅๆหัะࠦ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⒺ"),l1l1l1_l1_ (u"ࠩࠪⒻ"),9999)
	l11111lll1_l1_ = text.split(l1l1l1_l1_ (u"ࠪࠤࠬⒼ"))
	l1111lll1l_l1_ = pow(2,l1111ll1ll_l1_)
	l1111l1l1l_l1_ = []
	def l11111ll1l_l1_(a,b):
		if a==l1l1l1_l1_ (u"ࠫ࠶࠭Ⓗ"): return b
		return l1l1l1_l1_ (u"ࠬ࠭Ⓘ")
	for ii in range(l1111lll1l_l1_,0,-1):
		l1111l1l11_l1_ = list(l1111ll1ll_l1_*l1l1l1_l1_ (u"࠭࠰ࠨⒿ")+bin(ii)[2:])[-l1111ll1ll_l1_:]
		l1111l1l11_l1_ = reversed(l1111l1l11_l1_)
		result = map(l11111ll1l_l1_,l1111l1l11_l1_,l11111lll1_l1_)
		title = l1l1l1_l1_ (u"ࠧࠡࠩⓀ").join(filter(None,result))
		if kodi_version<19: title2 = title.decode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ⓛ"))
		else: title2 = title
		if len(title2)>2 and title not in l1111l1l1l_l1_:
			l1111l1l1l_l1_.append(title)
			addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓂ"),menu_name+title,l1l1l1_l1_ (u"ࠪࠫⓃ"),523,l1l1l1_l1_ (u"ࠫࠬⓄ"),l1l1l1_l1_ (u"ࠬ࠭Ⓟ"),title)
	return
def l111111l11_l1_(l1111lll11_l1_):
	if kodi_version<19:
		l1111lll11_l1_ = l1111lll11_l1_.decode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫⓆ"))
		import arabic_reshaper
		l1111lll11_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1111lll11_l1_)
		l1111lll11_l1_ = bidi.algorithm.get_display(l1111lll11_l1_)
	import l1111l1lll_l1_
	l1111lll11_l1_ = OPEN_KEYBOARD(default=l1111lll11_l1_)
	l1111l1lll_l1_.SEARCH(l1111lll11_l1_)
	return
def l1111ll11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫⓇ"),url,l1l1l1_l1_ (u"ࠨࠩⓈ"),l1l1l1_l1_ (u"ࠩࠪⓉ"),l1l1l1_l1_ (u"ࠪࠫⓊ"),l1l1l1_l1_ (u"ࠫࠬⓋ"),l1l1l1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡊࡐࡇࡉ࡝ࡋࡓࡠࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫⓌ"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫⓍ"),multi_valued_attributes=None)
	block = l1lllllllll_l1_.find(class_=l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸ࠲ࡹࡥࡱࡣࡵࡥࡹࡵࡲࠡ࡮࡬ࡷࡹ࠳ࡴࡪࡶ࡯ࡩࠬⓎ"))
	titles = block.find_all(l1l1l1_l1_ (u"ࠨࡣࠪⓏ"))
	items = []
	for title in titles:
		name = title.text
		l111ll_l1_ = l1l11l_l1_+title.get(l1l1l1_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧⓐ"))
		if kodi_version<19:
			name = name.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨⓑ"))
			l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"ࠫࡺࡺࡦ࠹ࠩⓒ"))
		if l1l1l1_l1_ (u"ࠬࠩࠧⓓ") not in l111ll_l1_: items.append((name,l111ll_l1_))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,l111ll_l1_ = item
		addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⓔ"),menu_name+name,l111ll_l1_,518)
	return
def l1111ll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠧࡈࡇࡗࠫⓕ"),url,l1l1l1_l1_ (u"ࠨࠩⓖ"),l1l1l1_l1_ (u"ࠩࠪⓗ"),l1l1l1_l1_ (u"ࠪࠫⓘ"),l1l1l1_l1_ (u"ࠫࠬⓙ"),l1l1l1_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡊࡐࡇࡉ࡝ࡋࡓࡠࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬⓚ"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫⓛ"),multi_valued_attributes=None)
	l1l11l1_l1_ = l1lllllllll_l1_.find(class_=l1l1l1_l1_ (u"ࠧࡦࡺࡳࡥࡳࡪࠧⓜ")).find_all(l1l1l1_l1_ (u"ࠨࡶࡵࠫⓝ"))
	for block in l1l11l1_l1_:
		l11111llll_l1_ = block.find_all(l1l1l1_l1_ (u"ࠩࡤࠫⓞ"))
		if not l11111llll_l1_: continue
		image = block.find(l1l1l1_l1_ (u"ࠪ࡭ࡲ࡭ࠧⓟ")).get(l1l1l1_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭ⓠ"))
		name = l11111llll_l1_[1].text
		l111ll_l1_ = l1l11l_l1_+l11111llll_l1_[1].get(l1l1l1_l1_ (u"ࠬ࡮ࡲࡦࡨࠪⓡ"))
		stars = block.find(class_=l1l1l1_l1_ (u"࠭࡬ࡦࡩࡨࡲࡩ࠭ⓢ"))
		if stars: stars = stars.text
		if kodi_version<19:
			name = name.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬⓣ"))
			l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭ⓤ"))
			image = image.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧⓥ"))
		infodict = {}
		if stars: infodict[l1l1l1_l1_ (u"ࠪࡷࡹࡧࡲࡴࠩⓦ")] = stars
		if l1l1l1_l1_ (u"ࠫ࠴ࡽ࡯ࡳ࡭࠲ࠫⓧ") in l111ll_l1_:
			#name = l1l1l1_l1_ (u"ࠬฮอฬࠢ฼๊ࠥ࠭ⓨ")+name
			addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⓩ"),menu_name+name,l111ll_l1_,516,image,l1l1l1_l1_ (u"ࠧࠨ⓪"),name,l1l1l1_l1_ (u"ࠨࠩ⓫"),infodict)
		elif l1l1l1_l1_ (u"ࠩ࠲ࡴࡪࡸࡳࡰࡰ࠲ࠫ⓬") in l111ll_l1_: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⓭"),menu_name+name,l111ll_l1_,513,image,l1l1l1_l1_ (u"ࠫࠬ⓮"),name,l1l1l1_l1_ (u"ࠬ࠭⓯"),infodict)
	PAGINATION(l1lllllllll_l1_,518)
	return
def l1111l11ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ⓰"),url,l1l1l1_l1_ (u"ࠧࠨ⓱"),l1l1l1_l1_ (u"ࠨࠩ⓲"),l1l1l1_l1_ (u"ࠩࠪ⓳"),l1l1l1_l1_ (u"ࠪࠫ⓴"),l1l1l1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡖࡊࡆࡈࡓࡘࡥࡌࡊࡕࡗࡗ࠲࠷ࡳࡵࠩ⓵"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⓶"),multi_valued_attributes=None)
	titles = l1lllllllll_l1_.find_all(class_=l1l1l1_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡵ࡫ࡷࡰࡪࠦࡩ࡯࡮࡬ࡲࡪ࠭⓷"))
	l1ll_l1_ = l1lllllllll_l1_.find_all(class_=l1l1l1_l1_ (u"ࠧࡣࡷࡷࡸࡴࡴࠠࡨࡴࡨࡩࡳࠦࡳ࡮ࡣ࡯ࡰࠥࡸࡩࡨࡪࡷࠫ⓸"))
	items = zip(titles,l1ll_l1_)
	for title,l111ll_l1_ in items:
		title = title.text
		l111ll_l1_ = l1l11l_l1_+l111ll_l1_.get(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫࠭⓹"))
		if kodi_version<19:
			title = title.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⓺"))
			l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⓻"))
		title = title.replace(l1l1l1_l1_ (u"ࠫࠥࠦࠠࠡࠩ⓼"),l1l1l1_l1_ (u"ࠬࠦࠧ⓽")).replace(l1l1l1_l1_ (u"࠭ࠠࠡࠢࠪ⓾"),l1l1l1_l1_ (u"ࠧࠡࠩ⓿")).replace(l1l1l1_l1_ (u"ࠨࠢࠣࠫ─"),l1l1l1_l1_ (u"ࠩࠣࠫ━"))
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ│"),menu_name+title,l111ll_l1_,521)
	return
def l111111111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ┃"),url,l1l1l1_l1_ (u"ࠬ࠭┄"),l1l1l1_l1_ (u"࠭ࠧ┅"),l1l1l1_l1_ (u"ࠧࠨ┆"),l1l1l1_l1_ (u"ࠨࠩ┇"),l1l1l1_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡛ࡏࡄࡆࡑࡖࡣ࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ┈"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ┉"),multi_valued_attributes=None)
	l111l111l1_l1_ = l1lllllllll_l1_.find(class_=l1l1l1_l1_ (u"ࠫࡱࡧࡲࡨࡧ࠰ࡦࡱࡵࡣ࡬࠯ࡪࡶ࡮ࡪ࠭࠵ࠢࡰࡩࡩ࡯ࡵ࡮࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡࡵࡰࡥࡱࡲ࠭ࡣ࡮ࡲࡧࡰ࠳ࡧࡳ࡫ࡧ࠱࠷࠭┊"))
	l1l11l1_l1_ = l111l111l1_l1_.find_all(l1l1l1_l1_ (u"ࠬࡲࡩࠨ┋"))
	for block in l1l11l1_l1_:
		title = block.find(class_=l1l1l1_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ┌")).text
		l111ll_l1_ = l1l11l_l1_+block.find(l1l1l1_l1_ (u"ࠧࡢࠩ┍")).get(l1l1l1_l1_ (u"ࠨࡪࡵࡩ࡫࠭┎"))
		image = block.find(l1l1l1_l1_ (u"ࠩ࡬ࡱ࡬࠭┏")).get(l1l1l1_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ┐"))
		duration = block.find(class_=l1l1l1_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭┑")).text
		if kodi_version<19:
			title = title.encode(l1l1l1_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ┒"))
			l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ┓"))
			image = image.encode(l1l1l1_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ└"))
			duration = duration.encode(l1l1l1_l1_ (u"ࠨࡷࡷࡪ࠽࠭┕"))
		duration = duration.replace(l1l1l1_l1_ (u"ࠩ࡟ࡲࠬ┖"),l1l1l1_l1_ (u"ࠪࠫ┗")).strip(l1l1l1_l1_ (u"ࠫࠥ࠭┘"))
		addMenuItem(l1l1l1_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ┙"),menu_name+title,l111ll_l1_,522,image,duration)
	PAGINATION(l1lllllllll_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ┚"),url,l1l1l1_l1_ (u"ࠧࠨ┛"),l1l1l1_l1_ (u"ࠨࠩ├"),l1l1l1_l1_ (u"ࠩࠪ┝"),l1l1l1_l1_ (u"ࠪࠫ┞"),l1l1l1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ┟"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ┠"),multi_valued_attributes=None)
	l111ll_l1_ = l1lllllllll_l1_.find(class_=l1l1l1_l1_ (u"࠭ࡦ࡭ࡧࡻ࠱ࡻ࡯ࡤࡦࡱࠪ┡")).find(l1l1l1_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠧ┢")).get(l1l1l1_l1_ (u"ࠨࡵࡵࡧࠬ┣"))
	if kodi_version<19: l111ll_l1_ = l111ll_l1_.encode(l1l1l1_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ┤"))
	PLAY_VIDEO(l111ll_l1_,script_name,l1l1l1_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ┥"))
	return
def SEARCH(search):
	search,options,l111l_l1_ = SEARCH_OPTIONS(search)
	if search==l1l1l1_l1_ (u"ࠫࠬ┦"): search = OPEN_KEYBOARD()
	if search==l1l1l1_l1_ (u"ࠬ࠭┧"): return
	search = search.replace(l1l1l1_l1_ (u"࠭ࠠࠨ┨"),l1l1l1_l1_ (u"ࠧࠦ࠴࠳ࠫ┩"))
	url = l1l11l_l1_+l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡂࡵࡂ࠭┪")+search
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"ࠩࡊࡉ࡙࠭┫"),url,l1l1l1_l1_ (u"ࠪࠫ┬"),l1l1l1_l1_ (u"ࠫࠬ┭"),l1l1l1_l1_ (u"ࠬ࠭┮"),l1l1l1_l1_ (u"࠭ࠧ┯"),l1l1l1_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭┰"))
	html = response.content
	l1lllllllll_l1_ = bs4.BeautifulSoup(html,l1l1l1_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭┱"),multi_valued_attributes=None)
	l1l11l1_l1_ = l1lllllllll_l1_.find_all(class_=l1l1l1_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰ࠰ࡸ࡮ࡺ࡬ࡦࠢ࡯ࡩ࡫ࡺࠧ┲"))
	for block in l1l11l1_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l1l1l1_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ┳"))
		title = title.split(l1l1l1_l1_ (u"ࠫ࠭࠭┴"),1)[0].strip(l1l1l1_l1_ (u"ࠬࠦࠧ┵"))
		if   l1l1l1_l1_ (u"࠭รฺ็ส่ࠬ┶") in title: l111ll_l1_ = url.replace(l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ┷"),l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡺࡳࡷࡱ࠯ࠨ┸"))
		elif l1l1l1_l1_ (u"ࠩฦุำอีࠨ┹") in title: l111ll_l1_ = url.replace(l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ┺"),l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭┻"))
		#elif l1l1l1_l1_ (u"ࠬษอะษฮࠫ┼") in title: l111ll_l1_ = url.replace(l1l1l1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ┽"),l1l1l1_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡧࡹࡩࡳࡺ࠯ࠨ┾"))
		#elif l1l1l1_l1_ (u"ࠨ็๊ีัอๆศฬࠪ┿") in title: l111ll_l1_ = url.replace(l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ╀"),l1l1l1_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳࡫࡫ࡳࡵ࡫ࡹࡥࡱ࠵ࠧ╁"))
		elif l1l1l1_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯ࠭╂") in title: l111ll_l1_ = url.replace(l1l1l1_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ╃"),l1l1l1_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ╄"))
		#elif l1l1l1_l1_ (u"ࠧฤะหหึ࠭╅") in title: l111ll_l1_ = url.replace(l1l1l1_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ╆"),l1l1l1_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡸࡴࡶࡩࡤ࠱ࠪ╇"))
		else: continue
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╈"),menu_name+title,l111ll_l1_,513)
	return
# ===========================================
#     l1111llll_l1_ l111111l1_l1_ l1llllllll_l1_
# ===========================================
def l1111111l1_l1_(url,text):
	global l1l1lll1_l1_,l1lll1ll_l1_
	if l1l1l1_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ╉") in url:
		l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡦࡲࠧ╊"),l1l1l1_l1_ (u"࠭ࡹࡦࡣࡵࠫ╋"),l1l1l1_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ╌")]
		l1lll1ll_l1_ = [l1l1l1_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ╍"),l1l1l1_l1_ (u"ࠩࡼࡩࡦࡸࠧ╎"),l1l1l1_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ╏")]
	elif l1l1l1_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ═") in url:
		l1l1lll1_l1_ = [l1l1l1_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ║"),l1l1l1_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ╒"),l1l1l1_l1_ (u"ࠧࡵࡻࡳࡩࠬ╓")]
		l1lll1ll_l1_ = [l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ╔"),l1l1l1_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪ╕"),l1l1l1_l1_ (u"ࠪࡸࡾࡶࡥࠨ╖")]
	l1111l1_l1_(url,text)
	return
def l1111lll1_l1_(url):
	url = url.split(l1l1l1_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ╗"))[0]
	#l11l1l_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠬࡻࡲ࡭ࠩ╘"))
	response = OPENURL_REQUESTS_CACHED(l11l11l_l1_,l1l1l1_l1_ (u"࠭ࡇࡆࡖࠪ╙"),url,l1l1l1_l1_ (u"ࠧࠨ╚"),l1l1l1_l1_ (u"ࠨࠩ╛"),l1l1l1_l1_ (u"ࠩࠪ╜"),l1l1l1_l1_ (u"ࠪࠫ╝"),l1l1l1_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ╞"))
	html = response.content
	# all l1l11l1_l1_
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠬ࡬࡯ࡳ࡯ࠣࡥࡨࡺࡩࡰࡰࡀࠦ࠴࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫ╟"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	# name + category + options block
	l11111l_l1_ = re.findall(l1l1l1_l1_ (u"࠭࠼ࡴࡧ࡯ࡩࡨࡺࠠ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ╠"),block,re.DOTALL)
	return l11111l_l1_
def l111111ll_l1_(block):
	# value + name
	items = re.findall(l1l1l1_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ╡"),block,re.DOTALL)
	return items
def l1111l1ll_l1_(url):
	#url = url.replace(l1l1l1_l1_ (u"ࠨࡥࡤࡸࡂ࠭╢"),l1l1l1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ╣"))
	l11111l1l_l1_ = url.split(l1l1l1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ╤"))[0]
	l11111l11_l1_ = SERVER(url,l1l1l1_l1_ (u"ࠫࡺࡸ࡬ࠨ╥"))
	#url = url.replace(l11111l1l_l1_,l11111l11_l1_)
	url = url.replace(l1l1l1_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ╦"),l1l1l1_l1_ (u"࠭࠯ࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠨࠪ╧"))
	return url
def l11ll11111_l1_(l1ll1ll1_l1_,url):
	l1l1l111_l1_ = l1l1l11l_l1_(l1ll1ll1_l1_,l1l1l1_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ╨")) # l11l111lll_l1_ be l11l11ll11_l1_
	url3 = url+l1l1l1_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ╩")+l1l1l111_l1_
	url3 = l1111l1ll_l1_(url3)
	return url3
def l1111l1_l1_(url,filter):
	#filter = filter.replace(l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ╪"),l1l1l1_l1_ (u"ࠪࠫ╫"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ╬"),l1l1l1_l1_ (u"ࠬ࠭╭"),filter,url)
	if l1l1l1_l1_ (u"࠭࠿ࠨ╮") in url: url = url.split(l1l1l1_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ╯"))[0]
	type,filter = filter.split(l1l1l1_l1_ (u"ࠨࡡࡢࡣࠬ╰"),1)
	if filter==l1l1l1_l1_ (u"ࠩࠪ╱"): l1l1ll11_l1_,l1l1l1ll_l1_ = l1l1l1_l1_ (u"ࠪࠫ╲"),l1l1l1_l1_ (u"ࠫࠬ╳")
	else: l1l1ll11_l1_,l1l1l1ll_l1_ = filter.split(l1l1l1_l1_ (u"ࠬࡥ࡟ࡠࠩ╴"))
	if type==l1l1l1_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ╵"):
		if l1l1lll1_l1_[0]+l1l1l1_l1_ (u"ࠧ࠾ࠩ╶") not in l1l1ll11_l1_: category = l1l1lll1_l1_[0]
		for i in range(len(l1l1lll1_l1_[0:-1])):
			if l1l1lll1_l1_[i]+l1l1l1_l1_ (u"ࠨ࠿ࠪ╷") in l1l1ll11_l1_: category = l1l1lll1_l1_[i+1]
		l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠩࠩࠫ╸")+category+l1l1l1_l1_ (u"ࠪࡁ࠵࠭╹")
		l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠫࠫ࠭╺")+category+l1l1l1_l1_ (u"ࠬࡃ࠰ࠨ╻")
		l1ll1111_l1_ = l1lll1l1_l1_.strip(l1l1l1_l1_ (u"࠭ࠦࠨ╼"))+l1l1l1_l1_ (u"ࠧࡠࡡࡢࠫ╽")+l1ll1ll1_l1_.strip(l1l1l1_l1_ (u"ࠨࠨࠪ╾"))
		l1l1l111_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ╿")) # l11l1111ll_l1_ l11ll11ll1_l1_ not l1l1l1l111_l1_
		url2 = url+l1l1l1_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ▀")+l1l1l111_l1_
	elif type==l1l1l1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ▁"):
		l1l111ll_l1_ = l1l1l11l_l1_(l1l1ll11_l1_,l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ▂")) # l11l1111ll_l1_ l11ll11ll1_l1_ not l1l1l1l111_l1_
		l1l111ll_l1_ = UNQUOTE(l1l111ll_l1_)
		if l1l1l1ll_l1_!=l1l1l1_l1_ (u"࠭ࠧ▃"): l1l1l1ll_l1_ = l1l1l11l_l1_(l1l1l1ll_l1_,l1l1l1_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ▄")) # l11l1111ll_l1_ l11ll11ll1_l1_ not l1l1l1l111_l1_
		if l1l1l1ll_l1_==l1l1l1_l1_ (u"ࠨࠩ▅"): url2 = url
		else: url2 = url+l1l1l1_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭▆")+l1l1l1ll_l1_
		url2 = l1111l1ll_l1_(url2)
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▇"),menu_name+l1l1l1_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ█"),url2,511)
		addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▉"),menu_name+l1l1l1_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭▊")+l1l111ll_l1_+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭▋"),url2,511)
		addMenuItem(l1l1l1_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭▌"),l1l1l1_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ▍"),l1l1l1_l1_ (u"ࠪࠫ▎"),9999)
	l11111l_l1_ = l1111lll1_l1_(url)
	dict = {}
	for name,l1llllll_l1_,block in l11111l_l1_:
		name = name.replace(l1l1l1_l1_ (u"ࠫ࠲࠳ࠧ▏"),l1l1l1_l1_ (u"ࠬ࠭▐"))
		items = l111111ll_l1_(block)
		if l1l1l1_l1_ (u"࠭࠽ࠨ░") not in url2: url2 = url
		if type==l1l1l1_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ▒"):
			if l1llllll_l1_ not in l1l1lll1_l1_: continue
			if category!=l1llllll_l1_: continue
			elif len(items)<2:
				if l1llllll_l1_==l1l1lll1_l1_[-1]:
					url = l1111l1ll_l1_(url)
					l111l1111l_l1_(url)
				else: l1111l1_l1_(url2,l1l1l1_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ▓")+l1ll1111_l1_)
				return
			else:
				url2 = l1111l1ll_l1_(url2)
				if l1llllll_l1_==l1l1lll1_l1_[-1]: addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▔"),menu_name+l1l1l1_l1_ (u"ࠪห้าๅ๋฻ࠪ▕"),url2,511)
				else: addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▖"),menu_name+l1l1l1_l1_ (u"ࠬอไอ็ํ฽ࠬ▗"),url2,515,l1l1l1_l1_ (u"࠭ࠧ▘"),l1l1l1_l1_ (u"ࠧࠨ▙"),l1ll1111_l1_)
		elif type==l1l1l1_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ▚"):
			if l1llllll_l1_ not in l1lll1ll_l1_: continue
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠩࠩࠫ▛")+l1llllll_l1_+l1l1l1_l1_ (u"ࠪࡁ࠵࠭▜")
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"ࠫࠫ࠭▝")+l1llllll_l1_+l1l1l1_l1_ (u"ࠬࡃ࠰ࠨ▞")
			l1ll1111_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"࠭࡟ࡠࡡࠪ▟")+l1ll1ll1_l1_
			if   name==l1l1l1_l1_ (u"ࠧࡵࡻࡳࡩࠬ■"): name = l1l1l1_l1_ (u"ࠨษ็๊ํ฿ࠧ□")
			elif name==l1l1l1_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ▢"): name = l1l1l1_l1_ (u"ࠪห้฿ๅๅࠩ▣")
			elif name==l1l1l1_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ▤"): name = l1l1l1_l1_ (u"ࠬอไๅ฼ฬࠫ▥")
			elif name==l1l1l1_l1_ (u"࠭ࡹࡦࡣࡵࠫ▦"): name = l1l1l1_l1_ (u"ࠧศๆึ๊ฮ࠭▧")
			elif name==l1l1l1_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࡢ࡮ࠪ▨"): name = l1l1l1_l1_ (u"ࠩส่๊๎ำๆࠩ▩")
			addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▪"),menu_name+l1l1l1_l1_ (u"ࠫฬ๊ฬๆ์฼࠾ࠥ࠭▫")+name,url2,514,l1l1l1_l1_ (u"ࠬ࠭▬"),l1l1l1_l1_ (u"࠭ࠧ▭"),l1ll1111_l1_)		# +l1l1l1_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ▮"))
		dict[l1llllll_l1_] = {}
		for value,option in items:
			if option in l1l1ll_l1_: continue
			if l1l1l1_l1_ (u"ࠨ็ุ๊ๆอสࠡลัี๎࠭▯") in option: continue
			if l1l1l1_l1_ (u"ࠩส่่๊ࠧ▰") in option: continue
			if l1l1l1_l1_ (u"ࠪหฺ้๊สࠩ▱") in option: continue
			option = option.replace(l1l1l1_l1_ (u"ࠫ็อฦๆหࠣࠫ▲"),l1l1l1_l1_ (u"ࠬ࠭△"))
			if   name==l1l1l1_l1_ (u"࠭ࡴࡺࡲࡨࠫ▴"): name = l1l1l1_l1_ (u"ࠧศๆ้์฾࠭▵")
			elif name==l1l1l1_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ▶"): name = l1l1l1_l1_ (u"ࠩส่฾๋ไࠨ▷")
			elif name==l1l1l1_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫ▸"): name = l1l1l1_l1_ (u"ࠫฬ๊ไ฻หࠪ▹")
			elif name==l1l1l1_l1_ (u"ࠬࡿࡥࡢࡴࠪ►"): name = l1l1l1_l1_ (u"࠭วๅี้อࠬ▻")
			elif name==l1l1l1_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ▼"): name = l1l1l1_l1_ (u"ࠨษ็้ํูๅࠨ▽")
			#if l1l1l1_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ▾") not in value: value = option
			#else: value = re.findall(l1l1l1_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫ▿"),value,re.DOTALL)[0]
			dict[l1llllll_l1_][value] = option
			l1lll1l1_l1_ = l1l1ll11_l1_+l1l1l1_l1_ (u"ࠫࠫ࠭◀")+l1llllll_l1_+l1l1l1_l1_ (u"ࠬࡃࠧ◁")+option
			l1ll1ll1_l1_ = l1l1l1ll_l1_+l1l1l1_l1_ (u"࠭ࠦࠨ◂")+l1llllll_l1_+l1l1l1_l1_ (u"ࠧ࠾ࠩ◃")+value
			l1lllll1_l1_ = l1lll1l1_l1_+l1l1l1_l1_ (u"ࠨࡡࡢࡣࠬ◄")+l1ll1ll1_l1_
			if name: title = option+l1l1l1_l1_ (u"ࠩࠣ࠾ࠬ◅")+name
			else: title = option   #+dict[l1llllll_l1_][l1l1l1_l1_ (u"ࠪ࠴ࠬ◆")]
			if type==l1l1l1_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ◇"): addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ◈"),menu_name+title,url,514,l1l1l1_l1_ (u"࠭ࠧ◉"),l1l1l1_l1_ (u"ࠧࠨ◊"),l1lllll1_l1_)		# +l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ○"))
			elif type==l1l1l1_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ◌") and l1l1lll1_l1_[-2]+l1l1l1_l1_ (u"ࠪࡁࠬ◍") in l1l1ll11_l1_:
				url3 = l11ll11111_l1_(l1ll1ll1_l1_,url)
				addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◎"),menu_name+title,url3,511)
			else: addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ●"),menu_name+title,url,515,l1l1l1_l1_ (u"࠭ࠧ◐"),l1l1l1_l1_ (u"ࠧࠨ◑"),l1lllll1_l1_)
	return
def l1l1l11l_l1_(filters,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ◒"),l1l1l1_l1_ (u"ࠩࠪ◓"),filters,l1l1l1_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫ◔"))
	# mode==l1l1l1_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭◕")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ values
	# mode==l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ◖")		l1lll111_l1_ l1ll11l1_l1_ l1ll11ll_l1_ filters
	# mode==l1l1l1_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ◗")			all l1ll11ll_l1_ & l1111ll1l_l1_ filters
	filters = filters.replace(l1l1l1_l1_ (u"ࠧ࠾ࠨࠪ◘"),l1l1l1_l1_ (u"ࠨ࠿࠳ࠪࠬ◙"))
	filters = filters.strip(l1l1l1_l1_ (u"ࠩࠩࠫ◚"))
	l1l1ll1l_l1_ = {}
	if l1l1l1_l1_ (u"ࠪࡁࠬ◛") in filters:
		items = filters.split(l1l1l1_l1_ (u"ࠫࠫ࠭◜"))
		for item in items:
			var,value = item.split(l1l1l1_l1_ (u"ࠬࡃࠧ◝"))
			l1l1ll1l_l1_[var] = value
	l1llll1l_l1_ = l1l1l1_l1_ (u"࠭ࠧ◞")
	for key in l1lll1ll_l1_:
		if key in list(l1l1ll1l_l1_.keys()): value = l1l1ll1l_l1_[key]
		else: value = l1l1l1_l1_ (u"ࠧ࠱ࠩ◟")
		if l1l1l1_l1_ (u"ࠨࠧࠪ◠") not in value: value = QUOTE(value)
		if mode==l1l1l1_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ◡") and value!=l1l1l1_l1_ (u"ࠪ࠴ࠬ◢"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠫࠥ࠱ࠠࠨ◣")+value
		elif mode==l1l1l1_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ◤") and value!=l1l1l1_l1_ (u"࠭࠰ࠨ◥"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠧࠧࠩ◦")+key+l1l1l1_l1_ (u"ࠨ࠿ࠪ◧")+value
		elif mode==l1l1l1_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ◨"): l1llll1l_l1_ = l1llll1l_l1_+l1l1l1_l1_ (u"ࠪࠪࠬ◩")+key+l1l1l1_l1_ (u"ࠫࡂ࠭◪")+value
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"ࠬࠦࠫࠡࠩ◫"))
	l1llll1l_l1_ = l1llll1l_l1_.strip(l1l1l1_l1_ (u"࠭ࠦࠨ◬"))
	l1llll1l_l1_ = l1llll1l_l1_.replace(l1l1l1_l1_ (u"ࠧ࠾࠲ࠪ◭"),l1l1l1_l1_ (u"ࠨ࠿ࠪ◮"))
	#DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ◯"),l1l1l1_l1_ (u"ࠪࠫ◰"),filters,l1l1l1_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠵࠶ࠬ◱"))
	return l1llll1l_l1_
l1l1lll1_l1_ = []
l1lll1ll_l1_ = []
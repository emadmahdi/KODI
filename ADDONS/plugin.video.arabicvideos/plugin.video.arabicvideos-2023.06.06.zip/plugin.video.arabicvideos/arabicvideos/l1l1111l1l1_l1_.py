# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1ll1l_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1l1_l1_ (l1_l1_):
    global l11ll1_l1_
    l1lll11_l1_ = ord (l1_l1_ [-1])
    l1lll1_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1lll11_l1_ % len (l1lll1_l1_)
    l1lllll_l1_ = l1lll1_l1_ [:l111_l1_] + l1lll1_l1_ [l111_l1_:]
    if l1ll1l_l1_:
        l1l111_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    else:
        l1l111_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1llll_l1_ + l1lll11_l1_) % l1l1l_l1_) for l1llll_l1_, char in enumerate (l1lllll_l1_)])
    return eval (l1l111_l1_)
#
from EXCLUDES import *
script_name = l1l1l1_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨ䃜")
menu_name = l1l1l1_l1_ (u"ࠨࡡࡏࡗ࡙ࡥࠧ䃝")
l1l11lll111_l1_ = 5
l1l11l1l1l1_l1_ = 10
def MAIN(mode,url,text,page,infodict):
	try: folder = str(infodict[l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃞")])
	except: folder = l1l1l1_l1_ (u"ࠪࠫ䃟")
	if   mode==160: results = MENU()
	elif mode==161: results = l1l1l111l1l_l1_(text)
	elif mode==162: results = l1l111lll1l_l1_(text,162)
	elif mode==163: results = l1l111lll1l_l1_(text,163)
	elif mode==164: results = l1l1l1111ll_l1_(text)
	elif mode==165: results = l1l11ll1l1l_l1_(folder,text,page)
	elif mode==166: results = l1l11llll11_l1_(url,text)
	elif mode==167: results = l1l111l111l_l1_(url,text)
	elif mode==168: results = l1l11111l1l_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䃠"),l1l1l1_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭䃡"),l1l1l1_l1_ (u"࠭ࠧ䃢"),161,l1l1l1_l1_ (u"ࠧࠨ䃣"),l1l1l1_l1_ (u"ࠨࠩ䃤"),l1l1l1_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䃥"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃦"),l1l1l1_l1_ (u"ࠫ็ูๅࠡ฻ื์ฬฬ๊ࠨ䃧"),l1l1l1_l1_ (u"ࠬ࠭䃨"),162,l1l1l1_l1_ (u"࠭ࠧ䃩"),l1l1l1_l1_ (u"ࠧࠨ䃪"),l1l1l1_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䃫"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃬"),l1l1l1_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭䃭"),l1l1l1_l1_ (u"ࠫࠬ䃮"),163,l1l1l1_l1_ (u"ࠬ࠭䃯"),l1l1l1_l1_ (u"࠭ࠧ䃰"),l1l1l1_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䃱"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃲"),l1l1l1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨ䃳"),l1l1l1_l1_ (u"ࠪࠫ䃴"),164,l1l1l1_l1_ (u"ࠫࠬ䃵"),l1l1l1_l1_ (u"ࠬ࠭䃶"),l1l1l1_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䃷"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃸"),l1l1l1_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䃹"),l1l1l1_l1_ (u"ࠩࠪ䃺"),165,l1l1l1_l1_ (u"ࠪࠫ䃻"),l1l1l1_l1_ (u"ࠫࠬ䃼"),l1l1l1_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ䃽"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䃾"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䃿"),l1l1l1_l1_ (u"ࠨࠩ䄀"),9999)
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄁"),l1l1l1_l1_ (u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ䄂"),l1l1l1_l1_ (u"ࠫࠬ䄃"),163,l1l1l1_l1_ (u"ࠬ࠭䄄"),l1l1l1_l1_ (u"࠭ࠧ䄅"),l1l1l1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䄆"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䄇"),l1l1l1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ䄈"),l1l1l1_l1_ (u"ࠪࠫ䄉"),163,l1l1l1_l1_ (u"ࠫࠬ䄊"),l1l1l1_l1_ (u"ࠬ࠭䄋"),l1l1l1_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䄌"))
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䄍"),l1l1l1_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ䄎"),l1l1l1_l1_ (u"ࠩࠪ䄏"),162,l1l1l1_l1_ (u"ࠪࠫ䄐"),l1l1l1_l1_ (u"ࠫࠬ䄑"),l1l1l1_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䄒"))
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄓"),l1l1l1_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ䄔"),l1l1l1_l1_ (u"ࠨࠩ䄕"),162,l1l1l1_l1_ (u"ࠩࠪ䄖"),l1l1l1_l1_ (u"ࠪࠫ䄗"),l1l1l1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䄘"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄙"),l1l1l1_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩ䄚"),l1l1l1_l1_ (u"ࠧࠨ䄛"),164,l1l1l1_l1_ (u"ࠨࠩ䄜"),l1l1l1_l1_ (u"ࠩࠪ䄝"),l1l1l1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䄞"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䄟"),l1l1l1_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ䄠"),l1l1l1_l1_ (u"࠭ࠧ䄡"),165,l1l1l1_l1_ (u"ࠧࠨ䄢"),l1l1l1_l1_ (u"ࠨࠩ䄣"),l1l1l1_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䄤"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䄥"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䄦"),l1l1l1_l1_ (u"ࠬ࠭䄧"),9999)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄨"),l1l1l1_l1_ (u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ䄩"),l1l1l1_l1_ (u"ࠨࠩ䄪"),163,l1l1l1_l1_ (u"ࠩࠪ䄫"),l1l1l1_l1_ (u"ࠪࠫ䄬"),l1l1l1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䄭"))
	addMenuItem(l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄮"),l1l1l1_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ䄯"),l1l1l1_l1_ (u"ࠧࠨ䄰"),163,l1l1l1_l1_ (u"ࠨࠩ䄱"),l1l1l1_l1_ (u"ࠩࠪ䄲"),l1l1l1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䄳"))
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䄴"),l1l1l1_l1_ (u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭䄵"),l1l1l1_l1_ (u"࠭ࠧ䄶"),162,l1l1l1_l1_ (u"ࠧࠨ䄷"),l1l1l1_l1_ (u"ࠨࠩ䄸"),l1l1l1_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䄹"))
	addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䄺"),l1l1l1_l1_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ䄻"),l1l1l1_l1_ (u"ࠬ࠭䄼"),162,l1l1l1_l1_ (u"࠭ࠧ䄽"),l1l1l1_l1_ (u"ࠧࠨ䄾"),l1l1l1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䄿"))
	addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䅀"),l1l1l1_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣฬาัฺࠠึ๋หห๐ࠧ䅁"),l1l1l1_l1_ (u"ࠫࠬ䅂"),164,l1l1l1_l1_ (u"ࠬ࠭䅃"),l1l1l1_l1_ (u"࠭ࠧ䅄"),l1l1l1_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䅅"))
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䅆"),l1l1l1_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ䅇"),l1l1l1_l1_ (u"ࠪࠫ䅈"),165,l1l1l1_l1_ (u"ࠫࠬ䅉"),l1l1l1_l1_ (u"ࠬ࠭䅊"),l1l1l1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䅋"))
	return
def l1l1l111l1l_l1_(options):
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䅌"),l1l1l1_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫ䅍"),l1l1l1_l1_ (u"ࠩࠪ䅎"),161,l1l1l1_l1_ (u"ࠪࠫ䅏"),l1l1l1_l1_ (u"ࠫࠬ䅐"),l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ䅑"))
	addMenuItem(l1l1l1_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䅒"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䅓"),l1l1l1_l1_ (u"ࠨࠩ䅔"),9999)
	l1l11l11ll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䅕"),l1l1l1_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䅖")+l1l1l1_l1_ (u"ࠫ็์่ศฬࠣ฽ึฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ䅗"),l1l1l1_l1_ (u"ࠬ࠭䅘"),147)
	#addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅙"),l1l1l1_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣ࡝࡚࡚ࠠࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䅚")+l1l1l1_l1_ (u"ࠨไ้์ฬะࠠฤฮ้ฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ䅛"),l1l1l1_l1_ (u"ࠩࠪ䅜"),148)
	#addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䅝"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡊࡈࡏࠤࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䅞")+l1l1l1_l1_ (u"่ࠬๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ䅟"),l1l1l1_l1_ (u"࠭ࠧ䅠"),28)
	#addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䅡"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡒࡘࡆࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䅢")+l1l1l1_l1_ (u"ࠩๅ๊ฬฯࠠศๆ่฽ฬืแࠡ็้ࠤ๊๎โฺ้่ࠫ䅣"),l1l1l1_l1_ (u"ࠪࠫ䅤"),41)
	#addMenuItem(l1l1l1_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䅥"),l1l1l1_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡࡍ࡚ࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䅦")+l1l1l1_l1_ (u"࠭โ็ษฬࠤฬ๊ใ้อิࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ䅧"),l1l1l1_l1_ (u"ࠧࠨ䅨"),135)
	import l1ll11l1ll1_l1_
	l1ll11l1ll1_l1_.ITEMS(l1l1l1_l1_ (u"ࠨ࠲ࠪ䅩"),False)
	l1ll11l1ll1_l1_.ITEMS(l1l1l1_l1_ (u"ࠩ࠴ࠫ䅪"),False)
	l1ll11l1ll1_l1_.ITEMS(l1l1l1_l1_ (u"ࠪ࠶ࠬ䅫"),False)
	#l1ll11l1ll1_l1_.ITEMS(l1l1l1_l1_ (u"ࠫ࠸࠭䅬"),False)
	if l1l1l1_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䅭") in options:
		menuItemsLIST[:] = l1l11l11111_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l11lll111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l11lll111_l1_)
	menuItemsLIST[:] = l1l11l11ll1_l1_+menuItemsLIST
	return
def l1l1l1111ll_l1_(options):
	options = options.replace(l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䅮"),l1l1l1_l1_ (u"ࠧࠨ䅯")).replace(l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䅰"),l1l1l1_l1_ (u"ࠩࠪ䅱"))
	headers = { l1l1l1_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䅲") : l1l1l1_l1_ (u"ࠫࠬ䅳") }
	url = l1l1l1_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫ䅴")
	payload = { l1l1l1_l1_ (u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨ䅵") : l1l1l1_l1_ (u"ࠧ࠶࠲ࠪ䅶") }
	data = l1lll11l1_l1_(payload)
	#DIALOG_OK(l1l1l1_l1_ (u"ࠨࠩ䅷"),l1l1l1_l1_ (u"ࠩࠪ䅸"),l1l1l1_l1_ (u"ࠪࠫ䅹"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1l1111lll1_l1_,l1l1l1_l1_ (u"ࠫࡌࡋࡔࠨ䅺"),url,data,headers,l1l1l1_l1_ (u"ࠬ࠭䅻"),l1l1l1_l1_ (u"࠭ࠧ䅼"),l1l1l1_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩ䅽"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1l1_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪ䅾"),html,re.DOTALL)
	block = l1ll1l1_l1_[0]
	items = re.findall(l1l1l1_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ䅿"),block,re.DOTALL)
	l1l111111l1_l1_,l1l1111llll_l1_ = list(zip(*items))
	l1l11ll1l11_l1_ = []
	l1l1l1111l1_l1_ = [l1l1l1_l1_ (u"ࠪࠤࠬ䆀"),l1l1l1_l1_ (u"ࠫࠧ࠭䆁"),l1l1l1_l1_ (u"ࠬࡦࠧ䆂"),l1l1l1_l1_ (u"࠭ࠬࠨ䆃"),l1l1l1_l1_ (u"ࠧ࠯ࠩ䆄"),l1l1l1_l1_ (u"ࠨ࠼ࠪ䆅"),l1l1l1_l1_ (u"ࠩ࠾ࠫ䆆"),l1l1l1_l1_ (u"ࠥࠫࠧ䆇"),l1l1l1_l1_ (u"ࠫ࠲࠭䆈")]
	l1l111ll111_l1_ = l1l1111llll_l1_+l1l111111l1_l1_
	for word in l1l111ll111_l1_:
		if word in l1l1111llll_l1_: l1l11l1ll1l_l1_ = 2
		if word in l1l111111l1_l1_: l1l11l1ll1l_l1_ = 4
		l1l11llllll_l1_ = [i in word for i in l1l1l1111l1_l1_]
		if any(l1l11llllll_l1_):
			index = l1l11llllll_l1_.index(True)
			splitter = l1l1l1111l1_l1_[index]
			l1l11lll1l1_l1_ = l1l1l1_l1_ (u"ࠬ࠭䆉")
			if word.count(splitter)>1: l1l11lll1ll_l1_,l1l11lll11l_l1_,l1l11lll1l1_l1_ = word.split(splitter,2)
			else: l1l11lll1ll_l1_,l1l11lll11l_l1_ = word.split(splitter,1)
			if len(l1l11lll1ll_l1_)>l1l11l1ll1l_l1_: l1l11ll1l11_l1_.append(l1l11lll1ll_l1_.lower())
			if len(l1l11lll11l_l1_)>l1l11l1ll1l_l1_: l1l11ll1l11_l1_.append(l1l11lll11l_l1_.lower())
			if len(l1l11lll1l1_l1_)>l1l11l1ll1l_l1_: l1l11ll1l11_l1_.append(l1l11lll1l1_l1_.lower())
		elif len(word)>l1l11l1ll1l_l1_: l1l11ll1l11_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l11ll1l11_l1_)
	#selection = DIALOG_SELECT(str(len(l1l11ll1l11_l1_)),l1l11ll1l11_l1_)
	l1l1l1_l1_ (u"ࠨࠢࠣࠌࠌࡰ࡮ࡹࡴࠡ࠿ࠣ࡟้ࠬไๆษอࠤ฾ฺ่ศศํอࠥ฿ัษ์ฬࠫ࠱࠭ใๅ็สฮࠥ฿ิ้ษษ๎ฮࠦล็ๅ็๎ื๐ษࠨ࡟ࠍࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢๆ่๊ฯࠠๅๆหัะูࠦ็้ส࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠷࠯ࠊࠊ࡮࡬ࡷࡹ࠷ࠠ࠾ࠢ࡞ࡡࠏࠏࡣࡰࡷࡱࡸࡸࠦ࠽ࠡ࡮ࡨࡲ࠭ࡲࡩࡴࡶ࠵࠭ࠏࠏࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨࡤࡱࡸࡲࡹࡹࠪ࠶ࠫ࠽ࠤࡷࡧ࡮ࡥࡱࡰ࠲ࡸ࡮ࡵࡧࡨ࡯ࡩ࠭ࡲࡩࡴࡶ࠵࠭ࠏࠏࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࡭ࡧࡱ࡫ࡹ࡮ࠩ࠻ࠢ࡯࡭ࡸࡺ࠱࠯ࡣࡳࡴࡪࡴࡤࠩࠩๆ่๊ฯฺࠠึ๋หห๐ษࠡำๅ้ࠥ࠭ࠫࡴࡶࡵࠬ࡮࠯ࠩࠋࠋࡺ࡬࡮ࡲࡥࠡࡖࡵࡹࡪࡀࠊࠊࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆ็฾ฮࡀࠧ࠭ࠢ࡯࡭ࡸࡺࠩࠋࠋࠌࠧ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࠎࠩࡥ࡭࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠽࠾࠲࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥࡧࡲࡣࡎࡌࡗ࡙ࠐࠉࠊࠥࡨࡰࡸ࡫࠺ࠡ࡮࡬ࡷࡹ࠸ࠠ࠾ࠢࡨࡲ࡬ࡒࡉࡔࡖࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢๆ่๊ฯࠠๅๆหัะูࠦ็้ส࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠶࠯ࠊࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࠣࡀࠤ࠲࠷࠺ࠡࡤࡵࡩࡦࡱࠊࠊࠋࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࡸ࡫ࡡࡳࡥ࡫ࠤࡂࠦ࡬ࡪࡵࡷ࠶ࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࠦࠧࠨ䆊")
	if l1l1l1_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䆋") in options:
		l1l11l11l1l_l1_ = l1l111l1lll_l1_
	elif l1l1l1_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䆌") in options:
		l1l11l11l1l_l1_ = [l1l1l1_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ䆍")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l1l1_l1_ (u"ࠪࠫ䆎"),True): return
	elif l1l1l1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䆏") in options:
		l1l11l11l1l_l1_ = [l1l1l1_l1_ (u"ࠬࡓ࠳ࡖࠩ䆐")]
		import l1ll111ll11_l1_
		if not l1ll111ll11_l1_.CHECK_TABLES_EXIST(l1l1l1_l1_ (u"࠭ࠧ䆑"),True): return
	count,l1l111111ll_l1_ = 0,0
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䆒"),l1l1l1_l1_ (u"ࠨษ็ฬาัฺ่ࠠࠣ࠾ࠥࡡࠠࠡ࡟ࠪ䆓"),l1l1l1_l1_ (u"ࠩࠪ䆔"),164,l1l1l1_l1_ (u"ࠪࠫ䆕"),l1l1l1_l1_ (u"ࠫࠬ䆖"),l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䆗")+options)
	addMenuItem(l1l1l1_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䆘"),l1l1l1_l1_ (u"ࠧฦ฻สำฮࠦวๅสะฯࠥอไฺึ๋หห๐ࠧ䆙"),l1l1l1_l1_ (u"ࠨࠩ䆚"),164,l1l1l1_l1_ (u"ࠩࠪ䆛"),l1l1l1_l1_ (u"ࠪࠫ䆜"),l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䆝")+options)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䆞"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䆟"),l1l1l1_l1_ (u"ࠧࠨ䆠"),9999)
	l1l1111111l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1l11111l_l1_ = []
	for word in l1l11ll1l11_l1_:
		l1l11lll11l_l1_ = re.findall(l1l1l1_l1_ (u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀ࡝ࠥ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭䆡"),word,re.DOTALL)
		if l1l11lll11l_l1_: word = word.split(l1l11lll11l_l1_[0],1)[0]
		l1l11ll11ll_l1_ = word.replace(l1l1l1_l1_ (u"ࠩ๔ࠫ䆢"),l1l1l1_l1_ (u"ࠪࠫ䆣")).replace(l1l1l1_l1_ (u"ࠫ๓࠭䆤"),l1l1l1_l1_ (u"ࠬ࠭䆥")).replace(l1l1l1_l1_ (u"๋࠭ࠨ䆦"),l1l1l1_l1_ (u"ࠧࠨ䆧")).replace(l1l1l1_l1_ (u"ࠨ๑ࠪ䆨"),l1l1l1_l1_ (u"ࠩࠪ䆩")).replace(l1l1l1_l1_ (u"ࠪ๐ࠬ䆪"),l1l1l1_l1_ (u"ࠫࠬ䆫"))
		l1l11ll11ll_l1_ = l1l11ll11ll_l1_.replace(l1l1l1_l1_ (u"ࠬ๖ࠧ䆬"),l1l1l1_l1_ (u"࠭ࠧ䆭")).replace(l1l1l1_l1_ (u"ࠧ๎ࠩ䆮"),l1l1l1_l1_ (u"ࠨࠩ䆯")).replace(l1l1l1_l1_ (u"ࠩ๕ࠫ䆰"),l1l1l1_l1_ (u"ࠪࠫ䆱")).replace(l1l1l1_l1_ (u"ࠫฑ࠭䆲"),l1l1l1_l1_ (u"ࠬ࠭䆳")).replace(l1l1l1_l1_ (u"࠭เࠨ䆴"),l1l1l1_l1_ (u"ࠧࠨ䆵"))
		if l1l11ll11ll_l1_: l1l1l11111l_l1_.append(l1l11ll11ll_l1_)
	#selection = DIALOG_SELECT(str(len(l1l1l11111l_l1_)),l1l1l11111l_l1_)
	l1l11ll1111_l1_ = []
	for ii in range(0,20):
		search = random.sample(l1l1l11111l_l1_,1)[0]
		if search in l1l11ll1111_l1_: continue
		l1l11ll1111_l1_.append(search)
		site = random.sample(l1l11l11l1l_l1_,1)[0]
		LOG_THIS(l1l1l1_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䆶"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬ䆷")+str(site)+l1l1l1_l1_ (u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭䆸")+search)
		#results = l1l111lll11_l1_(l1l1l1_l1_ (u"ࠫࠬ䆹"),l1l1l1_l1_ (u"ࠬ࠭䆺"),l1l1l1_l1_ (u"࠭ࠧ䆻"),site,l1l1l1_l1_ (u"ࠧࠨ䆼"),l1l1l1_l1_ (u"ࠨࠩ䆽"),search+l1l1l1_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䆾"),l1l1l1_l1_ (u"ࠪࠫ䆿"),l1l1l1_l1_ (u"ࠫࠬ䇀"))
		l1lll1l1111_l1_,l1lll1l1ll1_l1_,l1llll1ll11_l1_ = l1lll11ll11_l1_(site)
		l1lll1l1ll1_l1_(search+l1l1l1_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ䇁"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䇂"),l1l1l1_l1_ (u"ࠧࠨ䇃"))
	l1l1111111l_l1_[0][1] = l1l1l1_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䇄")+search+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊ศฮอࠣ฽๋ࠦ࠺ࠡ࡝ࠣࠫ䇅")
	menuItemsLIST[:] = l1l11l11111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l11lll111_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l11lll111_l1_)
	menuItemsLIST[:] = l1l1111111l_l1_+menuItemsLIST
	#import l1111l1lll_l1_
	#l1111l1lll_l1_.SEARCH(search)
	return
def l1l1l111111_l1_(site):
	l1lll1l1111_l1_,l1lll1l1ll1_l1_,l1llll1ll11_l1_ = l1lll11ll11_l1_(site)
	try:
		if l1l1l1_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ䇆") in site: l1lll1l1111_l1_(site)
		else: l1lll1l1111_l1_()
		l1l11l1llll_l1_ = False
	except: l1l11l1llll_l1_ = True
	if l1l11l1llll_l1_: DIALOG_NOTIFICATION(site,l1l1l1_l1_ (u"ࠫๆฺไࠡส๊ิฬࠦวๅ็๋ๆ฾࠭䇇"),time=2000)
	else: DIALOG_NOTIFICATION(site,l1l1l1_l1_ (u"ࠬะๅࠡฮ็ฬࠥอไฤไึห๊࠭䇈"),time=2000)
	return l1l11l1llll_l1_
def l1l1111l111_l1_(l1l11l1l1ll_l1_=True):
	if not l1l11l1l1ll_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"࠭ࡤࡪࡥࡷࠫ䇉"),l1l1l1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䇊"),l1l1l1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ䇋"))
		if results:
			contentsDICT = results
			return
	yes = DIALOG_YESNO(l1l1l1_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䇌"),l1l1l1_l1_ (u"ࠪࠫ䇍"),l1l1l1_l1_ (u"ࠫࠬ䇎"),l1l1l1_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䇏"),l1l1l1_l1_ (u"࠭ไไ์ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮ࠡษ็ฬึ์วๆฮࠣ๎าะวอࠢฦ๊ࠥ๐แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳ูࠦๆๆํอ๋ࠥไวࠢฯ้๏฿ࠠศๆฦๆุอๅࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪ䇐"))
	if yes!=1: return
	l1l1111l1ll_l1_ = menuItemsLIST[:]
	l1l11l111ll_l1_,l1l11l1111l_l1_ = 0,l1l1l1_l1_ (u"ࠧࠨ䇑")
	for site in l1l11lllll1_l1_:
		l1l11l1llll_l1_ = l1l1l111111_l1_(site)
		if l1l11l1llll_l1_:
			l1l11l111ll_l1_ += 1
			l1l11l1111l_l1_ += l1l1l1_l1_ (u"ࠨࠢࠪ䇒")+site
			if l1l11l111ll_l1_>=l1l11l1l1l1_l1_: break
	menuItemsLIST[:] = l1l1111l1ll_l1_
	if l1l11l111ll_l1_>=l1l11l1l1l1_l1_: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䇓"),l1l1l1_l1_ (u"ࠪࠫ䇔"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䇕"),l1l1l1_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไสࠢไ๎ࠥ࠭䇖")+str(l1l11l111ll_l1_)+l1l1l1_l1_ (u"࠭ࠠๆ๊สๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้ࠠีหฬ์อࠠใัࠣ๎่๎ๆࠡ฻า้ࠥ๎ฬ้ัࠣษ๋ะั็์อࠤๆ๐ࠠอ้สึ่่่ࠦ์࠽ࠫ䇗")+l1l11l1111l_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䇘"),l1l1l1_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ䇙"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䇚"),l1l1l1_l1_ (u"ࠪࠫ䇛"),l1l1l1_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䇜"),l1l1l1_l1_ (u"ࠬะๅࠡฮ็ฬࠥาๅ๋฻ࠣห้ษโิษ่ࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่อืๆศ็ฯࠫ䇝"))
	return
def l1l111ll1l1_l1_(folder,options):
	if l1l1l1_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䇞") not in options:
		results = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䇟"),l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䇠"),l1l1l1_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䇡")+folder)
		if results: menuItemsLIST[:] = results ; return
	message = l1l1l1_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ䇢")
	import IPTV
	if l1l1l1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䇣") in options and l1l1l1_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ䇤") not in options:
		try: IPTV.GROUPS(folder,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䇥"),l1l1l1_l1_ (u"ࠧࠨ䇦"),l1l1l1_l1_ (u"ࠨࠩ䇧"),options+l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䇨"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䇩"),l1l1l1_l1_ (u"ࠫࠬ䇪"),l1l1l1_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䇫"),message)
		try: IPTV.GROUPS(folder,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䇬"),l1l1l1_l1_ (u"ࠧࠨ䇭"),l1l1l1_l1_ (u"ࠨࠩ䇮"),options+l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䇯"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䇰"),l1l1l1_l1_ (u"ࠫࠬ䇱"),l1l1l1_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䇲"),message)
		try: IPTV.GROUPS(folder,l1l1l1_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䇳"),l1l1l1_l1_ (u"ࠧࠨ䇴"),l1l1l1_l1_ (u"ࠨࠩ䇵"),options+l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䇶"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠪࠫ䇷"),l1l1l1_l1_ (u"ࠫࠬ䇸"),l1l1l1_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䇹"),message)
	if l1l1l1_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䇺") in options and l1l1l1_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䇻") not in options:
		try: IPTV.GROUPS(folder,l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䇼"),l1l1l1_l1_ (u"ࠩࠪ䇽"),l1l1l1_l1_ (u"ࠪࠫ䇾"),options+l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䇿"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䈀"),l1l1l1_l1_ (u"࠭ࠧ䈁"),l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䈂"),message)
		try: IPTV.GROUPS(folder,l1l1l1_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䈃"),l1l1l1_l1_ (u"ࠩࠪ䈄"),l1l1l1_l1_ (u"ࠪࠫ䈅"),options+l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䈆"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠬ࠭䈇"),l1l1l1_l1_ (u"࠭ࠧ䈈"),l1l1l1_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ䈉"),message)
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䈊"),l1l1l1_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ䈋")+folder,menuItemsLIST,PERMANENT_CACHE)
	return
def l1l11l1l111_l1_(folder,options):
	if l1l1l1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䈌") not in options:
		results = READ_FROM_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䈍"),l1l1l1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䈎"),l1l1l1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䈏")+folder)
		if results: menuItemsLIST[:] = results ; return
	message = l1l1l1_l1_ (u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ䈐")
	import l1ll111ll11_l1_
	if l1l1l1_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䈑") in options and l1l1l1_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ䈒") not in options:
		try: l1ll111ll11_l1_.GROUPS(folder,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䈓"),l1l1l1_l1_ (u"ࠫࠬ䈔"),l1l1l1_l1_ (u"ࠬ࠭䈕"),options+l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䈖"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䈗"),l1l1l1_l1_ (u"ࠨࠩ䈘"),l1l1l1_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䈙"),message)
		try: l1ll111ll11_l1_.GROUPS(folder,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䈚"),l1l1l1_l1_ (u"ࠫࠬ䈛"),l1l1l1_l1_ (u"ࠬ࠭䈜"),options+l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䈝"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䈞"),l1l1l1_l1_ (u"ࠨࠩ䈟"),l1l1l1_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䈠"),message)
		try: l1ll111ll11_l1_.GROUPS(folder,l1l1l1_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䈡"),l1l1l1_l1_ (u"ࠫࠬ䈢"),l1l1l1_l1_ (u"ࠬ࠭䈣"),options+l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䈤"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠧࠨ䈥"),l1l1l1_l1_ (u"ࠨࠩ䈦"),l1l1l1_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩ䈧"),message)
	if l1l1l1_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䈨") in options and l1l1l1_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䈩") not in options:
		try: l1ll111ll11_l1_.GROUPS(folder,l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䈪"),l1l1l1_l1_ (u"࠭ࠧ䈫"),l1l1l1_l1_ (u"ࠧࠨ䈬"),options+l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䈭"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䈮"),l1l1l1_l1_ (u"ࠪࠫ䈯"),l1l1l1_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䈰"),message)
		try: l1ll111ll11_l1_.GROUPS(folder,l1l1l1_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ䈱"),l1l1l1_l1_ (u"࠭ࠧ䈲"),l1l1l1_l1_ (u"ࠧࠨ䈳"),options+l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䈴"),False)
		except: DIALOG_OK(l1l1l1_l1_ (u"ࠩࠪ䈵"),l1l1l1_l1_ (u"ࠪࠫ䈶"),l1l1l1_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨ䈷"),message)
	WRITE_TO_SQL3(main_dbfile,l1l1l1_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䈸"),l1l1l1_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䈹")+folder,menuItemsLIST,PERMANENT_CACHE)
	return
def l1l11ll1l1l_l1_(folder,options,l1l111l11ll_l1_):
	if l1l1l1_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䈺") in options:
		if l1l1l1_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䈻") in options and l1l111l11ll_l1_==l1l1l1_l1_ (u"ࠩࠪ䈼"): l1l1111l111_l1_(True)
		elif l1l111l11ll_l1_: l1l1111l111_l1_(False)
		#if contentsDICT=={}: return
	l1l11l1ll11_l1_ = options.replace(l1l1l1_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䈽"),l1l1l1_l1_ (u"ࠫࠬ䈾")).replace(l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䈿"),l1l1l1_l1_ (u"࠭ࠧ䉀")).replace(l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䉁"),l1l1l1_l1_ (u"ࠨࠩ䉂"))
	if not l1l111l11ll_l1_:
		addMenuItem(l1l1l1_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䉃"),l1l1l1_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ䉄"),l1l1l1_l1_ (u"ࠫࠬ䉅"),165,l1l1l1_l1_ (u"ࠬ࠭䉆"),l1l1l1_l1_ (u"࠭ࠧ䉇"),l1l1l1_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䉈")+l1l11l1ll11_l1_,l1l1l1_l1_ (u"ࠨࠩ䉉"),{l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉊"):folder})
		addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䉋"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䉌"),l1l1l1_l1_ (u"ࠬ࠭䉍"),9999)
	if l1l1l1_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䉎") in options:
		l1lll11l11_l1_ = [l1l1l1_l1_ (u"ࠧฤใ็ห๊࠭䉏"),l1l1l1_l1_ (u"ࠨ็ึุ่๊วหࠩ䉐"),l1l1l1_l1_ (u"่ࠩืึำ๊ศฬࠪ䉑"),l1l1l1_l1_ (u"ࠪฬึอๅอࠩ䉒"),l1l1l1_l1_ (u"ࠫศ฽แศๆࠣ์่ืส้่ࠪ䉓"),l1l1l1_l1_ (u"ࠬืๅืษ้ࠫ䉔"),l1l1l1_l1_ (u"࠭รฮัฮ࠱ศิัࠨ䉕"),l1l1l1_l1_ (u"ࠧิๆสื้࠭䉖"),l1l1l1_l1_ (u"ࠨ็๋ื๏่้ࠨ䉗"),l1l1l1_l1_ (u"ࠩฦุ์ื࠭ฤๅฮีࠬ䉘"),l1l1l1_l1_ (u"ࠪห้ศๆࠨ䉙"),l1l1l1_l1_ (u"ࠫ฻ำใࠨ䉚"),l1l1l1_l1_ (u"ࠬื๊ศุฬࠫ䉛"),l1l1l1_l1_ (u"࠭ๆ๋ฬไู่่ࠧ䉜"),l1l1l1_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䉝"),l1l1l1_l1_ (u"ࠨสฮࠤา๐ࠧ䉞"),l1l1l1_l1_ (u"ࠩา๎๋๐ษࠨ䉟"),l1l1l1_l1_ (u"ࠪื๋๎วหࠩ䉠"),l1l1l1_l1_ (u"ࠫศิั๊ࠩ䉡")]
		l1l1111ll11_l1_ = [l1l1l1_l1_ (u"ࠬอแๅษ่ࠫ䉢"),l1l1l1_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ䉣"),l1l1l1_l1_ (u"ࠧโ์็้ࠬ䉤"),l1l1l1_l1_ (u"ࠨใ็้ࠬ䉥")]
		l1l11ll1lll_l1_ = [l1l1l1_l1_ (u"่ࠩืู้ไࠨ䉦"),l1l1l1_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䉧")]
		l1l1l111l11_l1_ = [l1l1l1_l1_ (u"ู๊ࠫวาฯࠪ䉨"),l1l1l1_l1_ (u"๋ࠬำาฯํหฯ࠭䉩")]
		l1l111l1l11_l1_ = [l1l1l1_l1_ (u"࠭ศาษ่ะࠬ䉪"),l1l1l1_l1_ (u"ࠧࡴࡪࡲࡻࠬ䉫"),l1l1l1_l1_ (u"ࠨฬ็ๅื๐่็ࠩ䉬"),l1l1l1_l1_ (u"ࠩอ่๏็า๋๊้ࠫ䉭")]
		l1l11ll11l1_l1_ = [l1l1l1_l1_ (u"ࠪห๋๋๊ࠨ䉮"),l1l1l1_l1_ (u"่ࠫืส้่ࠪ䉯"),l1l1l1_l1_ (u"้ࠬวาฬ๋๊ࠬ䉰"),l1l1l1_l1_ (u"࠭࡫ࡪࡦࡶࠫ䉱"),l1l1l1_l1_ (u"ุࠧใ็ࠫ䉲"),l1l1l1_l1_ (u"ࠨษฺๅฬ๊ࠧ䉳")]
		l111llll_l1_ = [l1l1l1_l1_ (u"ࠩิ้฻อๆࠨ䉴")]
		l1111l11_l1_ = [l1l1l1_l1_ (u"ࠪหาีหࠨ䉵"),l1l1l1_l1_ (u"ࠫฬิัࠨ䉶"),l1l1l1_l1_ (u"๋่ࠬฯำࠪ䉷"),l1l1l1_l1_ (u"࠭ฬะ์าࠫ䉸"),l1l1l1_l1_ (u"ࠧๆุสๅࠬ䉹"),l1l1l1_l1_ (u"ࠨฯา๎ะ࠭䉺")]
		l1l111ll1ll_l1_ = [l1l1l1_l1_ (u"ࠩึ่ฬูไࠨ䉻"),l1l1l1_l1_ (u"ࠪืู้ไ่ࠩ䉼")]
		l1l11111l11_l1_ = [l1l1l1_l1_ (u"ࠫฬเว็์ࠪ䉽"),l1l1l1_l1_ (u"๋่ࠬิ์ๅํࠬ䉾"),l1l1l1_l1_ (u"࠭ใๅ์หࠫ䉿"),l1l1l1_l1_ (u"ࠧฮใ็ࠫ䊀"),l1l1l1_l1_ (u"ࠨ࡯ࡸࡷ࡮ࡩࠧ䊁")]
		l111l1ll1_l1_ = [l1l1l1_l1_ (u"ࠩส็ะืࠧ䊂"),l1l1l1_l1_ (u"ࠪหูํัࠨ䊃"),l1l1l1_l1_ (u"๊๋๊ࠫำ้ࠪ䊄"),l1l1l1_l1_ (u"ࠬอูๅ๋ࠪ䊅"),l1l1l1_l1_ (u"࠭ๅฯฬสี์࠭䊆"),l1l1l1_l1_ (u"ࠧๆะอหึอสࠨ䊇"),l1l1l1_l1_ (u"ࠨษๅ์๎࠭䊈")]
		l1l1111l11l_l1_ = [l1l1l1_l1_ (u"ࠩส่ฬ์ࠧ䊉"),l1l1l1_l1_ (u"ࠪัฬ๊๊ࠨ䊊"),l1l1l1_l1_ (u"๊ࠫัศหࠩ䊋"),l1l1l1_l1_ (u"ࠬืววฮࠪ䊌")]
		l1l11111lll_l1_ = [l1l1l1_l1_ (u"࠭ึฮๅࠪ䊍"),l1l1l1_l1_ (u"ࠧไ๊่๎ิ๐ࠧ䊎")]
		l1l1111ll1l_l1_ = [l1l1l1_l1_ (u"ࠨำํห฻ํࠧ䊏"),l1l1l1_l1_ (u"ࠩๆ์ึํࠧ䊐"),l1l1l1_l1_ (u"ฺ้ࠪอัฺ้ࠪ䊑"),l1l1l1_l1_ (u"ูࠫ๎สࠨ䊒"),l1l1l1_l1_ (u"ࠬื๊ศุฬࠫ䊓")]
		l1l11l1lll1_l1_ = [l1l1l1_l1_ (u"࠭ๆ๋ฬไู่่ࠧ䊔"),l1l1l1_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ䊕"),l1l1l1_l1_ (u"ࠨ่ํฮๆ๊๊ไีࠪ䊖")]
		l1l111l1l1l_l1_ = [l1l1l1_l1_ (u"่้ࠩะ๊๊็ࠩ䊗"),l1l1l1_l1_ (u"ࠪหูิวึࠩ䊘"),l1l1l1_l1_ (u"๋ࠫา่ๆࠩ䊙")]
		l1ll11lll_l1_ = [l1l1l1_l1_ (u"ࠬฮหࠡฯํࠫ䊚"),l1l1l1_l1_ (u"࠭࡬ࡪࡸࡨࠫ䊛"),l1l1l1_l1_ (u"ࠧใ่ส๋ࠬ䊜"),l1l1l1_l1_ (u"ࠨไ้์ฬะࠧ䊝")]
		l1l11l1l11l_l1_ = [l1l1l1_l1_ (u"ࠩา๎๋࠭䊞"),l1l1l1_l1_ (u"ࠪหิ฿๊่ࠩ䊟"),l1l1l1_l1_ (u"ࠫื๐วาษอࠫ䊠"),l1l1l1_l1_ (u"๊ࠬืๆ์สฮࠬ䊡"),l1l1l1_l1_ (u"࠭ฯฺษฤࠫ䊢"),l1l1l1_l1_ (u"ࠧใำส๊ࠬ䊣"),l1l1l1_l1_ (u"ࠨไุหหีࠧ䊤"),l1l1l1_l1_ (u"ࠩิฯฬวࠧ䊥"),l1l1l1_l1_ (u"้ࠪึาู๋้ࠪ䊦"),l1l1l1_l1_ (u"ࠫฬึว็ࠩ䊧"),l1l1l1_l1_ (u"ࠬอำๅษ่ࠫ䊨"),l1l1l1_l1_ (u"࠭ส้ษื๎า࠭䊩"),l1l1l1_l1_ (u"ࠧฯูหࠫ䊪"),l1l1l1_l1_ (u"ࠨฯ๋ึํ๐ࠧ䊫"),l1l1l1_l1_ (u"ࠩ฼ฮออสࠨ䊬"),l1l1l1_l1_ (u"้ࠪํอไ๋ัࠪ䊭"),l1l1l1_l1_ (u"๋ࠫ๎วฺ์ࠪ䊮"),l1l1l1_l1_ (u"ࠬ฿โศศาࠫ䊯"),l1l1l1_l1_ (u"࠭ว็ษื๎ิ࠭䊰")]
		l1l11ll1ll1_l1_ = [l1l1l1_l1_ (u"ࠧ࠲࠻ࠪ䊱"),l1l1l1_l1_ (u"ࠨ࠴࠳ࠫ䊲"),l1l1l1_l1_ (u"ࠩ࠵࠵ࠬ䊳"),l1l1l1_l1_ (u"ࠪ࠶࠷࠭䊴"),l1l1l1_l1_ (u"ࠫ࠷࠹ࠧ䊵"),l1l1l1_l1_ (u"ࠬ࠸࠴ࠨ䊶"),l1l1l1_l1_ (u"࠭࠲࠶ࠩ䊷"),l1l1l1_l1_ (u"ࠧ࠳࠸ࠪ䊸")]
		if not l1l111l11ll_l1_:
			l1l111l11ll_l1_ = 0
			for l1l11l11l11_l1_ in l1lll11l11_l1_:
				l1l111l11ll_l1_ += 1
				addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊹"),menu_name+l1l11l11l11_l1_,l1l1l1_l1_ (u"ࠩࠪ䊺"),165,l1l1l1_l1_ (u"ࠪࠫ䊻"),str(l1l111l11ll_l1_),l1l11l1ll11_l1_,l1l1l1_l1_ (u"ࠫࠬ䊼"),{l1l1l1_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊽"):folder})
		else:
			for name in sorted(list(contentsDICT.keys())):
				name2 = name.lower()
				category = []
				if any(value in name2 for value in l1l1111ll11_l1_): category.append(1)
				if any(value in name2 for value in l1l11ll1lll_l1_): category.append(2)
				if any(value in name2 for value in l1l1l111l11_l1_): category.append(3)
				if any(value in name2 for value in l1l111l1l11_l1_): category.append(4)
				if any(value in name2 for value in l1l11ll11l1_l1_): category.append(5)
				if any(value in name2 for value in l111llll_l1_): category.append(6)
				if any(value in name2 for value in l1111l11_l1_) and name2 not in [l1l1l1_l1_ (u"࠭วฯำ์ࠫ䊾")]: category.append(7)
				if any(value in name2 for value in l1l111ll1ll_l1_): category.append(8)
				if any(value in name2 for value in l1l11111l11_l1_): category.append(9)
				if any(value in name2 for value in l111l1ll1_l1_): category.append(10)
				if any(value in name2 for value in l1l1111l11l_l1_): category.append(11)
				if any(value in name2 for value in l1l11111lll_l1_): category.append(12)
				if any(value in name2 for value in l1l1111ll1l_l1_): category.append(13)
				if any(value in name2 for value in l1l11l1lll1_l1_): category.append(14)
				if any(value in name2 for value in l1l111l1l1l_l1_): category.append(15)
				if any(value in name2 for value in l1ll11lll_l1_): category.append(16)
				if any(value in name2 for value in l1l11l1l11l_l1_): category.append(17)
				if any(value in name2 for value in l1l11ll1ll1_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l1l111l11ll_l1_:
						addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊿"),menu_name+name,name,166,l1l1l1_l1_ (u"ࠨࠩ䋀"),l1l1l1_l1_ (u"ࠩࠪ䋁"),l1l11l1ll11_l1_+l1l1l1_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䋂"))
	elif l1l1l1_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䋃") in options:
		import IPTV
		#if l1l1l1_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䋄") in options:
		l1l11111ll1_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if folder:
			if not IPTV.CHECK_TABLES_EXIST(folder,True): return
			l1l111ll1l1_l1_(folder,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l1l1l1_l1_ (u"࠭ࠧ䋅"),True): return
			for folder in range(FOLDERS_COUNT):
				l1l111ll1l1_l1_(str(folder),options)
			#else: l1l11111ll1_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l1l11111ll1_l1_+menuItemsLIST[:]
	elif l1l1l1_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䋆") in options:
		import l1ll111ll11_l1_
		#if l1l1l1_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䋇") in options:
		l1l11111ll1_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if folder:
			if not l1ll111ll11_l1_.CHECK_TABLES_EXIST(folder,True): return
			l1l11l1l111_l1_(folder,options)
		else:
			if not l1ll111ll11_l1_.CHECK_TABLES_EXIST(l1l1l1_l1_ (u"ࠩࠪ䋈"),True): return
			for folder in range(FOLDERS_COUNT):
				l1l11l1l111_l1_(str(folder),options)
			#else: l1l11111ll1_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l1l11111ll1_l1_+menuItemsLIST[:]
	return
def l1l11llll11_l1_(nameonly,options):
	nameonly = nameonly.replace(l1l1l1_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋉"),l1l1l1_l1_ (u"ࠫࠬ䋊"))
	options = options.replace(l1l1l1_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䋋"),l1l1l1_l1_ (u"࠭ࠧ䋌")).replace(l1l1l1_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䋍"),l1l1l1_l1_ (u"ࠨࠩ䋎"))
	l1l1111l111_l1_(False)
	if contentsDICT=={}: return
	if l1l1l1_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䋏") in options:
		addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋐"),l1l1l1_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䋑")+nameonly+l1l1l1_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ䋒"),nameonly,166,l1l1l1_l1_ (u"࠭ࠧ䋓"),l1l1l1_l1_ (u"ࠧࠨ䋔"),l1l1l1_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䋕")+options)
		addMenuItem(l1l1l1_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋖"),l1l1l1_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䋗"),nameonly,166,l1l1l1_l1_ (u"ࠫࠬ䋘"),l1l1l1_l1_ (u"ࠬ࠭䋙"),l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䋚")+options)
		addMenuItem(l1l1l1_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䋛"),l1l1l1_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䋜"),l1l1l1_l1_ (u"ࠩࠪ䋝"),9999)
	for website in sorted(list(contentsDICT[nameonly].keys())):
		type,name,url,l1l11ll111l_l1_,image,page,text,favorite,infodict = contentsDICT[nameonly][website]
		if l1l1l1_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䋞") in options or len(contentsDICT[nameonly])==1:
			l1l111lll11_l1_(type,l1l1l1_l1_ (u"ࠫࠬ䋟"),url,l1l11ll111l_l1_,l1l1l1_l1_ (u"ࠬ࠭䋠"),page,text,l1l1l1_l1_ (u"࠭ࠧ䋡"),l1l1l1_l1_ (u"ࠧࠨ䋢"))
			menuItemsLIST[:] = l1l11l11111_l1_(menuItemsLIST)
			l1l11111ll1_l1_,newLIST = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(newLIST)
			if l1l1l1_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䋣") in options: menuItemsLIST[:] = l1l11111ll1_l1_+newLIST[:l1l11lll111_l1_]
			else: menuItemsLIST[:] = l1l11111ll1_l1_+newLIST
		elif l1l1l1_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䋤") in options: addMenuItem(l1l1l1_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋥"),website,url,l1l11ll111l_l1_,image,page,text,favorite,infodict)
	return
def l1l111lll1l_l1_(options,mode):
	#DIALOG_OK(l1l1l1_l1_ (u"ࠫࠬ䋦"),l1l1l1_l1_ (u"ࠬ࠭䋧"),str(mode),options)
	options = options.replace(l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䋨"),l1l1l1_l1_ (u"ࠧࠨ䋩")).replace(l1l1l1_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䋪"),l1l1l1_l1_ (u"ࠩࠪ䋫"))
	name,l1l111ll11l_l1_ = l1l1l1_l1_ (u"ࠪࠫ䋬"),[]
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋭"),l1l1l1_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䋮")+name+l1l1l1_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ䋯"),l1l1l1_l1_ (u"ࠧࠨ䋰"),mode,l1l1l1_l1_ (u"ࠨࠩ䋱"),l1l1l1_l1_ (u"ࠩࠪ䋲"),l1l1l1_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䋳")+options)
	addMenuItem(l1l1l1_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋴"),l1l1l1_l1_ (u"ࠬหูศัฬࠤ฼๊ศࠡไึ้ࠥ฿ิ้ษษ๎ࠬ䋵"),l1l1l1_l1_ (u"࠭ࠧ䋶"),mode,l1l1l1_l1_ (u"ࠧࠨ䋷"),l1l1l1_l1_ (u"ࠨࠩ䋸"),l1l1l1_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䋹")+options)
	addMenuItem(l1l1l1_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䋺"),l1l1l1_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䋻"),l1l1l1_l1_ (u"ࠬ࠭䋼"),9999)
	l1l11111ll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l1l1l1_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䋽") in options:
		l1l1111l111_l1_(False)
		if contentsDICT=={}: return
		l1l111lllll_l1_ = list(contentsDICT.keys())
		nameonly = random.sample(l1l111lllll_l1_,1)[0]
		l1l11ll1l11_l1_ = list(contentsDICT[nameonly].keys())
		website = random.sample(l1l11ll1l11_l1_,1)[0]
		type,name,url,l1l11ll111l_l1_,image,page,text,favorite,infodict = contentsDICT[nameonly][website]
		LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䋾"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡹࡨࡦࡸ࡯ࡴࡦ࠼ࠣࠫ䋿")+website+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ䌀")+name+l1l1l1_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䌁")+url+l1l1l1_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䌂")+str(l1l11ll111l_l1_))
	elif l1l1l1_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ䌃") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l1l1_l1_ (u"࠭ࠧ䌄"),True): return
		for folder in range(FOLDERS_COUNT):
			l1l111ll1l1_l1_(str(folder),options)
		if not menuItemsLIST: return
		type,name,url,l1l11ll111l_l1_,image,page,text,favorite,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1l1l1_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䌅"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ䌆")+name+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ䌇")+url+l1l1l1_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭䌈")+str(l1l11ll111l_l1_))
	elif l1l1l1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䌉") in options:
		import l1ll111ll11_l1_
		if not l1ll111ll11_l1_.CHECK_TABLES_EXIST(l1l1l1_l1_ (u"ࠬ࠭䌊"),True): return
		for folder in range(FOLDERS_COUNT):
			l1l11l1l111_l1_(str(folder),options)
		if not menuItemsLIST: return
		type,name,url,l1l11ll111l_l1_,image,page,text,favorite,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1l1l1_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䌋"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䌌")+name+l1l1l1_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䌍")+url+l1l1l1_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䌎")+str(l1l11ll111l_l1_))
	l1l111l1ll1_l1_ = name
	l1l11l111l1_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l1l1l1_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䌏"),LOGGING(script_name)+l1l1l1_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䌐")+name+l1l1l1_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䌑")+url+l1l1l1_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䌒")+str(l1l11ll111l_l1_))
		menuItemsLIST[:] = []
		if l1l11ll111l_l1_==234 and l1l1l1_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䌓") in text: l1l11ll111l_l1_ = 233
		if l1l11ll111l_l1_==714 and l1l1l1_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䌔") in text: l1l11ll111l_l1_ = 713
		if l1l11ll111l_l1_==144: l1l11ll111l_l1_ = 291
		html = l1l111lll11_l1_(type,name,url,l1l11ll111l_l1_,image,page,text,favorite,infodict)
		#if l1l1l1_l1_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥࠧ䌕") in html: l1l111lll1l_l1_(options,mode)
		if l1l1l1_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䌖") in options and l1l11ll111l_l1_==167: del menuItemsLIST[:3]
		if l1l1l1_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䌗") in options and l1l11ll111l_l1_==168: del menuItemsLIST[:3]
		l1l111ll11l_l1_[:] = l1l11l11111_l1_(menuItemsLIST)
		if l1l11l111l1_l1_ and l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡺ࠭อๅไฬࠫ䌘")) in str(l1l111ll11l_l1_) or l1l111l11l1_l1_(l1l1l1_l1_ (u"ࡻࠧฮๆๅ๋ࠬ䌙")) in str(l1l111ll11l_l1_):
			name = l1l111l1ll1_l1_
			l1l111ll11l_l1_[:] = l1l11l111l1_l1_
			break
		l1l111l1ll1_l1_ = name
		l1l11l111l1_l1_ = l1l111ll11l_l1_[:]
		if str(l1l111ll11l_l1_).count(l1l1l1_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䌚"))>0: break
		if str(l1l111ll11l_l1_).count(l1l1l1_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䌛"))>0: break
		if l1l11ll111l_l1_==233: break	# l11l1llll1_l1_ l11l11ll_l1_ names l1l11l11lll_l1_ of l1ll1_l1_ name
		if l1l11ll111l_l1_==713: break	# l1l111l1111_l1_ l11l11ll_l1_ names l1l11l11lll_l1_ of l1ll1_l1_ name
		if l1l11ll111l_l1_==291: break	# l1lll1lll_l1_ l1l11llll1l_l1_ names l1l11l11lll_l1_ of l1lll1lll_l1_ l1l11llll1l_l1_ contents
		if l1l111ll11l_l1_: type,name,url,l1l11ll111l_l1_,image,page,text,favorite,infodict = random.sample(l1l111ll11l_l1_,1)[0]
	if not name: name = l1l1l1_l1_ (u"ࠩ࠱࠲࠳࠴ࠧ䌜")
	elif name.count(l1l1l1_l1_ (u"ࠪࡣࠬ䌝"))>1: name = name.split(l1l1l1_l1_ (u"ࠫࡤ࠭䌞"),2)[2]
	name = name.replace(l1l1l1_l1_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨ䌟"),l1l1l1_l1_ (u"࠭ࠧ䌠"))#.replace(l1l1l1_l1_ (u"ࠧ࠭ࡏࡒ࡚ࡎࡋࡓ࠻ࠢࠪ䌡"),l1l1l1_l1_ (u"ࠨࠩ䌢")).replace(l1l1l1_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ䌣"),l1l1l1_l1_ (u"ࠪࠫ䌤")).replace(l1l1l1_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ䌥"),l1l1l1_l1_ (u"ࠬ࠭䌦"))
	name = name.replace(l1l1l1_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䌧"),l1l1l1_l1_ (u"ࠧࠨ䌨"))
	l1l11111ll1_l1_[0][1] = l1l1l1_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䌩")+name+l1l1l1_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊โิ็ࠣ࠾ࠥࡡࠠࠨ䌪")
	for i in range(9): random.shuffle(l1l111ll11l_l1_)
	if l1l1l1_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䌫") in options: menuItemsLIST[:] = l1l11111ll1_l1_+l1l111ll11l_l1_[:l1l11lll111_l1_]
	else: menuItemsLIST[:] = l1l11111ll1_l1_+l1l111ll11l_l1_
	return
def l1l111l111l_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䌬"),l1l1l1_l1_ (u"ࠬ࠭䌭")).replace(l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䌮"),l1l1l1_l1_ (u"ࠧࠨ䌯"))
	l1l111llll1_l1_ = GROUP
	if l1l1l1_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䌰") in GROUP:
		l1l111llll1_l1_ = GROUP.split(l1l1l1_l1_ (u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪ䌱"))[0]
		type = l1l1l1_l1_ (u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭䌲")
	elif l1l1l1_l1_ (u"࡛ࠫࡕࡄࠨ䌳") in TYPE: type = l1l1l1_l1_ (u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨ䌴")
	elif l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䌵") in TYPE: type = l1l1l1_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ䌶")
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䌷"),l1l1l1_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䌸")+type+l1l111llll1_l1_+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ䌹"),TYPE,167,l1l1l1_l1_ (u"ࠫࠬ䌺"),l1l1l1_l1_ (u"ࠬ࠭䌻"),l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䌼")+GROUP)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䌽"),l1l1l1_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䌾"),TYPE,167,l1l1l1_l1_ (u"ࠩࠪ䌿"),l1l1l1_l1_ (u"ࠪࠫ䍀"),l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䍁")+GROUP)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䍂"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䍃"),l1l1l1_l1_ (u"ࠧࠨ䍄"),9999)
	import IPTV
	for folder in range(FOLDERS_COUNT):
		if l1l1l1_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䍅") in GROUP: IPTV.GROUPS(str(folder),TYPE,GROUP,l1l1l1_l1_ (u"ࠩࠪ䍆"),False)
		else: IPTV.ITEMS(str(folder),TYPE,GROUP,l1l1l1_l1_ (u"ࠪࠫ䍇"),False)
	menuItemsLIST[:] = l1l11l11111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l11lll111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l11lll111_l1_)
	return
def l1l11111l1l_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䍈"),l1l1l1_l1_ (u"ࠬ࠭䍉")).replace(l1l1l1_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䍊"),l1l1l1_l1_ (u"ࠧࠨ䍋"))
	l1l111llll1_l1_ = GROUP
	if l1l1l1_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䍌") in GROUP:
		l1l111llll1_l1_ = GROUP.split(l1l1l1_l1_ (u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䍍"))[0]
		type = l1l1l1_l1_ (u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭䍎")
	elif l1l1l1_l1_ (u"࡛ࠫࡕࡄࠨ䍏") in TYPE: type = l1l1l1_l1_ (u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨ䍐")
	elif l1l1l1_l1_ (u"࠭ࡌࡊࡘࡈࠫ䍑") in TYPE: type = l1l1l1_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ䍒")
	addMenuItem(l1l1l1_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍓"),l1l1l1_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䍔")+type+l1l111llll1_l1_+l1l1l1_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ䍕"),TYPE,168,l1l1l1_l1_ (u"ࠫࠬ䍖"),l1l1l1_l1_ (u"ࠬ࠭䍗"),l1l1l1_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䍘")+GROUP)
	addMenuItem(l1l1l1_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䍙"),l1l1l1_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䍚"),TYPE,168,l1l1l1_l1_ (u"ࠩࠪ䍛"),l1l1l1_l1_ (u"ࠪࠫ䍜"),l1l1l1_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䍝")+GROUP)
	addMenuItem(l1l1l1_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䍞"),l1l1l1_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䍟"),l1l1l1_l1_ (u"ࠧࠨ䍠"),9999)
	import l1ll111ll11_l1_
	for folder in range(FOLDERS_COUNT):
		if l1l1l1_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䍡") in GROUP: l1ll111ll11_l1_.GROUPS(str(folder),TYPE,GROUP,l1l1l1_l1_ (u"ࠩࠪ䍢"),False)
		else: l1ll111ll11_l1_.ITEMS(str(folder),TYPE,GROUP,l1l1l1_l1_ (u"ࠪࠫ䍣"),False)
	menuItemsLIST[:] = l1l11l11111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l11lll111_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l11lll111_l1_)
	return
def l1l11l11111_l1_(menuItemsLIST):
	l1l111ll11l_l1_ = []
	for type,name,url,mode,image,page,text,favorite,infodict in menuItemsLIST:
		if l1l1l1_l1_ (u"ฺࠫ็อสࠩ䍤") in name or l1l1l1_l1_ (u"ࠬ฻แฮ้ࠪ䍥") in name or l1l1l1_l1_ (u"࠭ࡰࡢࡩࡨࠫ䍦") in name.lower(): continue
		l1l111ll11l_l1_.append([type,name,url,mode,image,page,text,favorite,infodict])
	return l1l111ll11l_l1_
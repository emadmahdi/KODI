# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ⿋")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡍࡗ࡚ࡤ࠭⿌")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ⿍")]
def l11l1ll_l1_(mode,url,text):
	if   mode==810: l1lll_l1_ = l1l1l11_l1_()
	elif mode==811: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==812: l1lll_l1_ = PLAY(url)
	elif mode==813: l1lll_l1_ = l1ll11lll1l_l1_(url)
	elif mode==819: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⿎"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ⿏"),l1l111_l1_ (u"ࠫࠬ⿐"),l1l111_l1_ (u"ࠬ࠭⿑"),l1l111_l1_ (u"࠭ࠧ⿒"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⿓"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⿔"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⿕"),l1l111_l1_ (u"ࠪࠫ⿖"),819,l1l111_l1_ (u"ࠫࠬ⿗"),l1l111_l1_ (u"ࠬ࠭⿘"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⿙"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⿚"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⿛"),l1l111_l1_ (u"ࠩࠪ⿜"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡸࡩ࡮ࡣࡵࡽ࠲ࡲࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫࠥࡱࡴࡹࡴ࠮ࡸ࡬ࡩࡼ࡫ࡤࠣࠩ⿝"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⿞"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿟"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⿠")+l1lllll_l1_+title,l1ll1ll_l1_,811)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠧࠨ⿡")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⿢"),url,l1l111_l1_ (u"ࠩࠪ⿣"),l1l111_l1_ (u"ࠪࠫ⿤"),l1l111_l1_ (u"ࠫࠬ⿥"),l1l111_l1_ (u"ࠬ࠭⿦"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⿧"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡦࡰࡱࡷࡩࡷࠨࠧ⿨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⿩"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ⿪"),title,re.DOTALL)
			if l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⿫") not in type and l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ⿬") + l1l1lll_l1_[0][0]
				title = title.replace(l1l111_l1_ (u"ࠬอ่็ࠢ็ห๏์ࠧ⿭"),l1l111_l1_ (u"࠭ࠧ⿮"))
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⿯"),l1lllll_l1_+title,l1ll1ll_l1_,813,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⿰"),l1lllll_l1_+title,l1ll1ll_l1_,812,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠤࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧࠩ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶࠧ⿱"),html,re.DOTALL)
	if l11llll_l1_:
		type = l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࡤࡶࡡࡨࡧࡶࠫ⿲") if l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⿳") in type else l1l111_l1_ (u"ࠬࡶࡡࡨࡧࡶࠫ⿴")
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⿵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⿶"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ⿷")+title,l1ll1ll_l1_,811,l1l111_l1_ (u"ࠩࠪ⿸"),l1l111_l1_ (u"ࠪࠫ⿹"),type)
	return
def l1ll11lll1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⿺"),url,l1l111_l1_ (u"ࠬ࠭⿻"),l1l111_l1_ (u"࠭ࠧ⿼"),l1l111_l1_ (u"ࠧࠨ⿽"),l1l111_l1_ (u"ࠨࠩ⿾"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙࠱ࡘࡋࡒࡊࡇࡖ࠱࠶ࡹࡴࠨ⿿"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡴࡦࡩࡲࡶࡾࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ　"),html,re.DOTALL)
	if l1ll1ll_l1_: l1lll11_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭、"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ。"),url,l1l111_l1_ (u"࠭ࠧ〃"),l1l111_l1_ (u"ࠧࠨ〄"),l1l111_l1_ (u"ࠨࠩ々"),l1l111_l1_ (u"ࠩࠪ〆"),l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ〇"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࠿ࠫ࠲࠯ࡅࠩࠣࠩ〈"),html,re.DOTALL)
	l1ll11l_l1_ = base64.b64decode(l1ll11l_l1_[0])
	if kodi_version>18.99: l1ll11l_l1_ = l1ll11l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ〉"))
	l1ll11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ《"),l1ll11l_l1_)
	l1ll_l1_ = l1ll11l_l1_[l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࡳࠨ》")]
	l11l11_l1_ = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	l1lll1l_l1_ = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in l1lll1l_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ「")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ」")
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ『"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ』"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭【"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ】"),l1l111_l1_ (u"ࠧࠬࠩ〒"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭〓")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ〔"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ墶")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ墷")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1ll11_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l11111lll_l1_()
	elif mode==56: l1lll_l1_ = l11l111111l1_l1_()
	elif mode==57: l1lll_l1_ = l111ll111l_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll111l_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ墸"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ墹"),l1l111_l1_ (u"࠭ࠧ墺"),59,l1l111_l1_ (u"ࠧࠨ墻"),l1l111_l1_ (u"ࠨࠩ墼"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭墽"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ墾"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ墿"),l1l111_l1_ (u"ࠬ࠭壀"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壁"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ壂")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ壃"),l1l111_l1_ (u"ࠩࠪ壄"),56)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壅"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭壆")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไศใ็ห๊࠭壇"),l1l111_l1_ (u"࠭ࠧ壈"),55)
	return l1l111_l1_ (u"ࠧࠨ壉")
def l11l11111lll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壊"),l1lllll_l1_+l1l111_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ壋"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ壌"),51)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壍"),l1lllll_l1_+l1l111_l1_ (u"ࠬอแๅษ่ࠤึอฦอหࠪ壎"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ壏"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壐"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไศใ็ห๊࠭壑"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ壒"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壓"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣ็้อำ๋ๅํอࠬ壔"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ壕"),51)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ壖"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ壗"),l1l111_l1_ (u"ࠨࠩ壘"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壙"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสึ๊ฮࠦวๅษ้ฮฬาࠧ壚"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡹࡰࡲࠪ壛"),57)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壜"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศใู่ࠥะโ๋์่ࠫ壝"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ壞"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壟"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็ห่ััࠡ็ืห์ีษࠨ壠"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ壡"),57)
	return
def l11l111111l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壢"),l1lllll_l1_+l1l111_l1_ (u"ࠬออะอࠣห้๋ำๅี็หฯ࠭壣"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ壤"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壥"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิหหาษࠨ壦"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭壧"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壨"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็ุ้๊ำๅษอࠫ壩"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ壪"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭士"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡๅ็หุ๐ใ๋หࠪ壬"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ壭"),51)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ壮"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ壯"),l1l111_l1_ (u"ࠫࠬ声"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壱"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ売"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡽࡴࡶࠧ壳"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壴"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ壵"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭壶"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壷"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭壸"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ壹"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠧࡀࠩ壺") in url:
		parts = url.split(l1l111_l1_ (u"ࠨࡁࠪ壻"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠩࡂࠫ壼") + QUOTE(parts[1],l1l111_l1_ (u"ࠪࡁࠫࡀ࠯ࠦࠩ壽"))
	else: filter = l1l111_l1_ (u"ࠫࠬ壾")
	parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ壿"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"࠭ࡹࡰࡲࠪ夀"),l1l111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࠧ夁"),l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡹࠧ夂")]:
		if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ夃"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ处")
		elif type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ夅"): l1l1l1lll_l1_=l1l111_l1_ (u"๋ࠬำๅี็ࠫ夆")
		url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ备") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠧ࠰ࠩ夈") + l1llllll1_l1_ + l1l111_l1_ (u"ࠨ࠱ࠪ変") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ夊"),l1l111_l1_ (u"ࠪࠫ夋"),l1l111_l1_ (u"ࠫࠬ夌"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ复"))
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡫ࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡲࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠯ࡄࠨࡰࡦࡲ࡬ࡷࡴࡪࡥࡴࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡴࡷ࡫ࡳࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ夎"),html,re.DOTALL)
		l1ll1l1111l_l1_=0
		for id,title,l11l1111111l_l1_,l1ll1l_l1_ in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1ll1l1ll11_l1_ + l1l111_l1_ (u"ࠧ࠰ࡸ࠵࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࡰࡥ࡮ࡴ࠯ࠨ夏") + l1ll1l_l1_ + l1l111_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ夐")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ夑") + id
			if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ夒"): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ夓"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ夔"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭夕"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧ外")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡨࡴࡂ࠭夗")+l11l1111111l_l1_+l1l111_l1_ (u"ࠩࡀࠫ夘")+title+l1l111_l1_ (u"ࠪࡁࠬ夙")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ多"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ夛")
		elif type==l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭夜"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ夝")
		url = l1l1l1ll1l_l1_ + l1l111_l1_ (u"ࠨ࠱࡭ࡷࡴࡴ࠯ࡴࡧ࡯ࡩࡨࡺࡥࡥ࠱ࠪ夞") + sort + l1l111_l1_ (u"ࠩ࠰ࠫ够") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠪ࠱࡜࡝࠮࡫ࡵࡲࡲࠬ夠")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ夡"),l1l111_l1_ (u"ࠬ࠭夢"),l1l111_l1_ (u"࠭ࠧ夣"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭夤"))
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡦࡲࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭夥"),html,re.DOTALL)
		l1ll1l1111l_l1_=0
		for id,l11l1111111l_l1_,l1ll1l_l1_,title in items:
			l1ll1l1111l_l1_ += 1
			l1ll1l_l1_ = l1l1l1ll1l_l1_ + l1l111_l1_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ夦") + l1ll1l_l1_ + l1l111_l1_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ大")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ夨") + id
			if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ天"): addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ太"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ夫"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夬"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไࠡࠩ夭")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ央")+l11l1111111l_l1_+l1l111_l1_ (u"ࠫࡂ࠭夯")+title+l1l111_l1_ (u"ࠬࡃࠧ夰")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"࠭ีโฯฬࠤࠬ失")
	if l1ll1l1111l_l1_==16:
		for l1ll1l1ll1l_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1ll1l_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ夲")+type+l1l111_l1_ (u"ࠨ࠱ࠪ夳")+str(l1ll1l1ll1l_l1_)+l1l111_l1_ (u"ࠩ࠲ࠫ头")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ夵"),l1lllll_l1_+title+str(l1ll1l1ll1l_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠫࡂ࠭夶"))
	l11l1111111l_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ夷"),l1l111_l1_ (u"࠭ࠧ夸"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠧࡀࠩ夹"))[0]
	if l11l1111111l_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ夺"),l1l111_l1_ (u"ࠩࠪ夻"),l1l111_l1_ (u"ࠪࠫ夼"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ夽"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭夾"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭夿"),block,re.DOTALL)
		l11l1111111l_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l1111111l_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ奀") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭奁")+name+l1l111_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭奂")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ奃"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ奄"),l1l111_l1_ (u"ࠬ࠭奅"),l1l111_l1_ (u"࠭ࠧ奆"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ奇"))
	l11l111111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奈"),html,re.DOTALL)
	if l11l111111ll_l1_:
		time = l11l111111ll_l1_[1].replace(l1l111_l1_ (u"ࠩࡗࠫ奉"),l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ奊"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ奋"),l1l111_l1_ (u"ࠬ࠭奌"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ奍"),l1l111_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ奎")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ奏")+time)
		return
	l111llllllll_l1_,l11l11111l1l_l1_ = [],[]
	l11l11111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奐"),html,re.DOTALL)[0]
	l11l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡣࡣࡦ࡯ࡺࡶ࡟ࡰࡴ࡬࡫࡮ࡴ࡟࡭࡫ࡱ࡯ࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ契"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡲࡳ࠻ࠢࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ奒"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ奓") in server:
			server = l1l111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭奔")
			url = l11l11111l11_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ奕")
			url = l11l11111ll1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ奖") in url:
			l111llllllll_l1_.append(url)
			l11l11111l1l_l1_.append(l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠡࠩ套")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡣࡱ࡯࡮࡬࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ奘"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ奙"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ奚"))[-1]
		filename = filename.replace(l1l111_l1_ (u"࠭ࡦࡢ࡮࡯ࡦࡦࡩ࡫ࠨ奛"),l1l111_l1_ (u"ࠧࠨ奜"))
		filename = filename.replace(l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭奝"),l1l111_l1_ (u"ࠩࠪ奞"))
		filename = filename.replace(l1l111_l1_ (u"ࠪ࠱ࠬ奟"),l1l111_l1_ (u"ࠫࠬ奠"))
		if l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ奡") in server:
			server = l1l111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭奢")
			url = l11l11111l11_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ奣")
			url = l11l11111ll1_l1_ + l1ll1ll_l1_
		l111llllllll_l1_.append(url)
		l11l11111l1l_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࠦࠧ奤")+server+l1l111_l1_ (u"ࠩࠣࠤࠬ奥")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡚ࠣ࡮ࡪࡥࡰࠢࡔࡹࡦࡲࡩࡵࡻ࠽ࠫ奦"), l11l11111l1l_l1_)
	if l11l11l_l1_ == -1 : return
	url = l111llllllll_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ奧"))
	return
def l111ll111l_l1_(url,type):
	if l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ奨") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ๅิๆึ่ࠬ奩")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯โ์็้ࠬ奪")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ奫"),l1l111_l1_ (u"ࠩࠪ奬"),l1l111_l1_ (u"ࠪࠫ奭"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡆࡊࡎࡗࡉࡗ࡙࠭࠲ࡵࡷࠫ奮"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡵࡣࡩࡨࡲࡷ࡫ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ奯"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ奰"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴࠧ奱"),block,re.DOTALL)
	if type==1:
		for l11l11111111_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奲"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠩࡂࡷࡺࡨࡧࡦࡰࡵࡩࡂ࠭女")+l11l11111111_l1_,58)
	elif type==2:
		url,l11l11111111_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࠬ奴"))
		for l1lll1l1l1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奵"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠬࡅࡣࡰࡷࡱࡸࡷࡿ࠽ࠨ奶")+l1lll1l1l1ll_l1_+l1l111_l1_ (u"࠭ࠦࠨ奷")+l11l11111111_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ奸"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ她"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭奺")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ奻"),url,l1l111_l1_ (u"ࠫࠬ奼"),l1l111_l1_ (u"ࠬ࠭好"),True,l1l111_l1_ (u"࠭ࠧ奾"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡖࡉࡆࡘࡃࡉ࠯࠵ࡲࡩ࠭奿"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡩࡨࡲࡪࡸࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡸ࡫ࡡࡳࡥ࡫࠱ࡧࡵࡴࡵࡱࡰ࠱ࡵࡧࡤࡥ࡫ࡱ࡫ࠬ妀"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭妁"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭如") in url:
				if l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ妃") in url:
					title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ妄")+title
					url = url.replace(l1l111_l1_ (u"࠭࠿ࡦࡲࡀ࠵ࠬ妅"),l1l111_l1_ (u"ࠧࡀࡧࡳࡁ࠵࠭妆"))
					url = url+l1l111_l1_ (u"ࠨ࠿ࠪ妇")+QUOTE(title)+l1l111_l1_ (u"ࠩࡀࠫ妈")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妉"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡไ๎้๋ࠠࠨ妊")+title
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ妋"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
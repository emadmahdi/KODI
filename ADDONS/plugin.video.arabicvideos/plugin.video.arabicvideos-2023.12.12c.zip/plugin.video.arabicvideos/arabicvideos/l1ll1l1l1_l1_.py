# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫಪ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡏ࡜࡚࡟ࠨಫ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==130: l1lll_l1_ = l1l1l11_l1_()
	elif mode==131: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==132: l1lll_l1_ = CATEGORIES(url)
	elif mode==133: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==134: l1lll_l1_ = PLAY(url)
	elif mode==135: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==139: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಬ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫಭ"),l1l111_l1_ (u"ࠬ࠭ಮ"),139,l1l111_l1_ (u"࠭ࠧಯ"),l1l111_l1_ (u"ࠧࠨರ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬಱ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧಲ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪಳ"),l1l111_l1_ (u"ࠫࠬ಴"),9999)
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ವ"),l1l111_l1_ (u"࠭ࠧಶ"),True,l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬಷ"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡵࡱࡪ࡫ࡱ࡫ࠧಸ"),html,re.DOTALL)
	block = l11llll_l1_[1]
	items=re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨಹ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡮ࡥࡷࡦࡸࡴࡸࠧ಺") in l1ll1ll_l1_: continue
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭಻"))
		url = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰಼ࠩ") in url: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಽ"),l1lllll_l1_+title,url,132)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧಾ"),l1lllll_l1_+title,url,131)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ಿ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩೀ"),l1l111_l1_ (u"ࠪࠫು"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫೂ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧೃ")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠩೄ"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠹࠹ࠧ೅"),132,l1l111_l1_ (u"ࠨࠩೆ"),l1l111_l1_ (u"ࠩ࠴ࠫೇ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪೈ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭೉")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไฤใ็ห๊࠭ೊ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠹࠶࠽࠭ೋ"),132,l1l111_l1_ (u"ࠧࠨೌ"),l1l111_l1_ (u"ࠨ࠳್ࠪ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೎"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ೏")+l1lllll_l1_+l1l111_l1_ (u"ࠫอืวๆฮࠣห้฻ฺศำࠣ์ฬ๊ิษษหࠫ೐"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠷࠴࠻ࠬ೑"),132,l1l111_l1_ (u"࠭ࠧ೒"),l1l111_l1_ (u"ࠧ࠲ࠩ೓"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ೔"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫೕ")+l1lllll_l1_+l1l111_l1_ (u"ࠪหอืาࠡษ็ฬึอๅอࠩೖ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠲࠹࠹࠷ࠬ೗"),132,l1l111_l1_ (u"ࠬ࠭೘"),l1l111_l1_ (u"࠭࠱ࠨ೙"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ೚"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ೛")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊ำวืำสฮࠬ೜"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠹࠵࠵ࠪೝ"),132,l1l111_l1_ (u"ࠫࠬೞ"),l1l111_l1_ (u"ࠬ࠷ࠧ೟"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ೠ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩೡ")+l1lllll_l1_+l1l111_l1_ (u"ࠨ฻สุํืวยࠩೢ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠷࠳࠶࠵ࠪೣ"),132,l1l111_l1_ (u"ࠪࠫ೤"),l1l111_l1_ (u"ࠫ࠶࠭೥"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ೦"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ೧")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆหีฬ๋ฬࠡษ็หัะๅศ฻ํอࠬ೨"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠶࠱ࠨ೩"),132,l1l111_l1_ (u"ࠩࠪ೪"),l1l111_l1_ (u"ࠪ࠵ࠬ೫"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ೬"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ೭")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅสิห๊าࠠศๆา๎๋๐ษࠨ೮"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠵࠿ࠧ೯"),132,l1l111_l1_ (u"ࠨࠩ೰"),l1l111_l1_ (u"ࠩ࠴ࠫೱ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪೲ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ೳ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไษำส้ัࠦวๅ๊ฮหห่๊สࠩ೴"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠸࠹࠸࠭೵"),132,l1l111_l1_ (u"ࠧࠨ೶"),l1l111_l1_ (u"ࠨ࠳ࠪ೷"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೸"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ೹")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ศาษ่ะࠥอไิ์สื๏ฯࠧ೺"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠷࠷࠹ࠬ೻"),132,l1l111_l1_ (u"࠭ࠧ೼"),l1l111_l1_ (u"ࠧ࠲ࠩ೽"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ೾"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ೿")+l1lllll_l1_+l1l111_l1_ (u"ࠪ็ฯฮࠧഀ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠳࠻࠴ࠫഁ"),132,l1l111_l1_ (u"ࠬ࠭ം"),l1l111_l1_ (u"࠭࠱ࠨഃ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧഄ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪഅ")+l1lllll_l1_+l1l111_l1_ (u"ࠩอ฽้๋ࠠศๆไหึู๊สࠩആ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠸࠹ࠩഇ"),132,l1l111_l1_ (u"ࠫࠬഈ"),l1l111_l1_ (u"ࠬ࠷ࠧഉ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ഊ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩഋ")+l1lllll_l1_+l1l111_l1_ (u"ࠨลิุ๏็ࠠศๆหีฬ๋ฬࠨഌ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠷࠲࠸࠻ࠪ഍"),132,l1l111_l1_ (u"ࠪࠫഎ"),l1l111_l1_ (u"ࠫ࠶࠭ഏ"))
	return
def l1lll11_l1_(url):
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠬ࠵ࡲࡦ࡮࡬࡫࡮ࡵࡵࡴࠩഐ"),l1l111_l1_ (u"࠭࠯ࡴࡱࡦ࡭ࡦࡲࠧ഑"),l1l111_l1_ (u"ࠧ࠰ࡲࡲࡰ࡮ࡺࡩࡤࡣ࡯ࠫഒ"),l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨഓ"),l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵࠪഔ")]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫക"),l1l111_l1_ (u"ࠫࠬഖ"),True,l1l111_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬഗ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡧࡧࡲࠩ࠰࠭ࡃ࠮ࡺࡩࡵ࡮ࡨࡦࡦࡸࠧഘ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if any(value in url for value in l1lll11l1_l1_):
		items = re.findall(l1l111_l1_ (u"ࠢࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤങ"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪച"))
			l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩഛ"),l1lllll_l1_+title,l1ll1ll_l1_,133,l1ll1l_l1_,l1l111_l1_ (u"ࠪ࠵ࠬജ"))
	elif l1l111_l1_ (u"ࠫ࠴ࡪ࡯ࡤࡵࠪഝ") in url:
		items = re.findall(l1l111_l1_ (u"ࠧࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢഞ"),block,re.DOTALL)
		for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨട"))
			l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧഠ"),l1lllll_l1_+title,l1ll1ll_l1_,133,l1ll1l_l1_,l1l111_l1_ (u"ࠨ࠳ࠪഡ"))
	return
def CATEGORIES(url):
	category = url.split(l1l111_l1_ (u"ࠩ࠲ࠫഢ"))[-1]
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫണ"),l1l111_l1_ (u"ࠫࠬത"),True,l1l111_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩഥ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡴࡨࡲࡹࡩࡡࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ദ"),html,re.DOTALL)
	if not l11llll_l1_:
		l1ll1l11_l1_(url,l1l111_l1_ (u"ࠧ࠲ࠩധ"))
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠥന"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫഩ"))
		l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪപ"),l1lllll_l1_+title,l1ll1ll_l1_,132,l1l111_l1_ (u"ࠫࠬഫ"),l1l111_l1_ (u"ࠬ࠷ࠧബ"))
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧഭ"),l1l111_l1_ (u"ࠧࠨമ"),True,l1l111_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪയ"))
	items = re.findall(l1l111_l1_ (u"ࠩࡷࡳࡹࡧ࡬ࡱࡣࡪࡩࡨࡵࡵ࡯ࡶࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬര"),html,re.DOTALL)
	if not items:
		url = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡲࡪࡽࡳ࠮ࡦࡨࡸࡦ࡯࡬࠮ࡤࡲࡨࡾࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨറ"),html,re.DOTALL)
		url = url[0]
		title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪല") + l1l111_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪള")
		if url: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬഴ"),l1lllll_l1_+title,url,134)
		else: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨവ"),l1l111_l1_ (u"ࠨࠩശ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬഷ"),l1l111_l1_ (u"่ࠪฬ๊้ࠦฮาࠤาอไ๋ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡใํࠤ์ึวࠡษ็ๅึ฿ࠧസ"))
		return
	l1lll1111_l1_ = int(items[0])
	name = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡀ࠴ࡧ࠾ࠡࡀࠫ࠲࠯ࡅࠩ࠽ࠩഹ"),html,re.DOTALL)
	if name: name = name[0].strip(l1l111_l1_ (u"ࠬࠦࠧഺ"))
	else: name = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲ഻ࠧ"))
	if l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲഼ࠫ") in url or l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫഽ") in url:
		category = url.split(l1l111_l1_ (u"ࠩ࠲ࠫാ"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠪࠫി"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨീ") + category + l1l111_l1_ (u"ࠬ࠵ࠧു") + l1llllll1_l1_
		l11l1ll1_l1_ = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧൂ"),l1l111_l1_ (u"ࠧࠨൃ"),True,l1l111_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪൄ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡳࡥ࡬࡫࡮ࡶ࡯ࡥࡩࡷ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ൅"),l11l1ll1_l1_,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡪࡺࡲ࡬ࠩ࠰࠭ࡃ࠮ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫെ"),block,re.DOTALL)
		for l1ll1l_l1_,type,l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪേ") not in type: continue
			if l1l111_l1_ (u"๋ࠬำๅี็ࠫൈ") in title and l1l111_l1_ (u"࠭อๅไฬࠫ൉") not in title: continue
			title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬൊ"),l1l111_l1_ (u"ࠨࠩോ"))
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫൌ"))
			if l1l111_l1_ (u"ุ้๊ࠪำๅ്ࠩ") in name and l1l111_l1_ (u"ࠫา๊โสࠩൎ") in title and l1l111_l1_ (u"๋ࠬำๅี็ࠫ൏") not in title:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ൐") + name + l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ൑") + title
			l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
			if category==l1l111_l1_ (u"ࠨ࠸࠵࠼ࠬ൒"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ൓"),l1lllll_l1_+title,l1ll1ll_l1_,133,l1ll1l_l1_,l1l111_l1_ (u"ࠪ࠵ࠬൔ"))
			else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪൕ"),l1lllll_l1_+title,l1ll1ll_l1_,134,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨൖ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡰࡨ࠲࠷࠲ࠨൗ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠢࡷ࡫ࡧࡩࡴ࠳ࡴࡳࡣࡦ࡯࠲ࡺࡥࡹࡶ࠱࠮ࡄࡲ࡯ࡢࡦ࡙࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ൘"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ൙"))
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ൚"),l1lllll_l1_+title,l1ll1ll_l1_,134,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠶࠳࠺ࠪ൛") in html:
				title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ൜") + l1l111_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ൝")
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ൞"),l1lllll_l1_+title,url,134)
		else:
			items = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡈࡧࡴࡦࡩࡲࡶ࡮࡫ࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫൟ"),html,re.DOTALL)
			category = items[0].split(l1l111_l1_ (u"ࠨ࠱ࠪൠ"))[-1]
			url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ൡ") + category
			CATEGORIES(url)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫൢ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ൣ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll1l1ll_l1_:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫ൤"),l1l111_l1_ (u"࠭ࠦࠨ൥"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ൦"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ൧")+title,l1ll1ll_l1_,133)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠩ࠲ࡲࡪࡽࡳ࠰ࠩ൨") in url or l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭൩") in url:
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ൪"),l1l111_l1_ (u"ࠬ࠭൫"),True,l1l111_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ൬"))
		items = re.findall(l1l111_l1_ (u"ࠢ࡮ࡱࡥ࡭ࡱ࡫ࡶࡪࡦࡨࡳࡵࡧࡴࡩ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠫ࠭࠴ࠪࡀࠫࠪࠦ൭"),html,re.DOTALL)
		if items: url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ൮"))
	return
def l1ll1llll_l1_():
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡼࡥࠨ൯")
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ൰"),l1l111_l1_ (u"ࠫࠬ൱"),True,l1l111_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ൲"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭࡬ࡪࡸࡨ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ൳"),html,re.DOTALL)
	l1lllll1_l1_ = l1lllll1_l1_[0]
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ൴"):l111l1_l1_}
	l1lll1l11_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ൵"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ൶"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ൷"),True,l1l111_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡍࡋ࡙ࡉ࠲࠸࡮ࡥࠩ൸"))
	l11l1ll1_l1_ = l1lll1l11_l1_.content
	token = re.findall(l1l111_l1_ (u"ࠬࡩࡳࡳࡨ࠰ࡸࡴࡱࡥ࡯ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ൹"),l11l1ll1_l1_,re.DOTALL)
	token = token[0]
	l1lll111l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪൺ"))
	l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡱ࡮ࡤࡽ࡚ࡸ࡬ࠡ࠿ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦൻ"),l11l1ll1_l1_,re.DOTALL)
	l1llllll_l1_ = l1lll111l_l1_+l1llllll_l1_[0]
	l1ll1ll11_l1_ = {l1l111_l1_ (u"ࠨ࡚࠰ࡇࡘࡘࡆ࠮ࡖࡒࡏࡊࡔࠧർ"):token}
	l1lll11ll_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧൽ"),l1llllll_l1_,l1l111_l1_ (u"ࠪࠫൾ"),l1ll1ll11_l1_,False,True,l1l111_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡍࡋ࡙ࡉ࠲࠹ࡲࡥࠩൿ"))
	l1ll1lll1_l1_ = l1lll11ll_l1_.content
	l1111111_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭඀"),l1ll1lll1_l1_,re.DOTALL)
	l1111111_l1_ = l1111111_l1_[0].replace(l1l111_l1_ (u"࠭࡜࠰ࠩඁ"),l1l111_l1_ (u"ࠧ࠰ࠩං"))
	l1llll111_l1_(l1111111_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭ඃ"))
	return
def l1lll1_l1_(search,url=l1l111_l1_ (u"ࠩࠪ඄")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if url==l1l111_l1_ (u"ࠪࠫඅ"):
		if search==l1l111_l1_ (u"ࠫࠬආ"): search = l1llll1_l1_()
		if search==l1l111_l1_ (u"ࠬ࠭ඇ"): return
		search = QUOTE(search)
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪඈ")+search
		l1ll1l11_l1_(url,l1l111_l1_ (u"ࠧࠨඉ"))
		return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ庻")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ庼")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l111llll11l1_l1_(url)
	elif mode==146: l1lll_l1_ = l111l1llll11_l1_(url)
	elif mode==147: l1lll_l1_ = l111lll111ll_l1_()
	elif mode==148: l1lll_l1_ = l111lll11l1l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ庽"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭庾"),l1l111_l1_ (u"ࠧࠨ庿"),149,l1l111_l1_ (u"ࠨࠩ廀"),l1l111_l1_ (u"ࠩࠪ廁"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ廂"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廃"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廄")+l1l111_l1_ (u"࠭࡟࡚ࡖࡆࡣࠬ廅")+l1l111_l1_ (u"ࠧๆ๊สๆ฾ࠦวฯฬสี์อࠠศๆ่ฬึ๋ฬࠨ廆"),l1l111_l1_ (u"ࠨࠩ廇"),290)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廈"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廉")+l1lllll_l1_+l1l111_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤ๏๎ส๋๊หࠫ廊"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ廋"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廌"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廍")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ廎"),l111l1_l1_,144,l1l111_l1_ (u"ࠩࠪ廏"),l1l111_l1_ (u"ࠪࠫ廐"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ廑"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廒"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廓")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่ัฯ๎้ࠡษ็ีฬฬฬࠨ廔"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ廕"),146)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ廖"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ廗"),l1l111_l1_ (u"ࠫࠬ廘"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廙"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廚")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤ฾ืศ๋หࠪ廛"),l1l111_l1_ (u"ࠨࠩ廜"),147)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廝"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廞")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ廟"),l1l111_l1_ (u"ࠬ࠭廠"),148)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廡"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廢")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥ฿ัษ์ฬࠫ廣"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๅ๏๊ๅࠨ廤"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廥"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廦")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢสะ๋ฮ๊สࠩ廧"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽࡮ࡱࡹ࡭ࡪ࠭廨"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廩"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廪")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ廫"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ廬"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廭"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廮")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥ฿ัษ์ฬࠫ廯"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึุ่๊ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ廰"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廱"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廲")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢสะ๋ฮ๊สࠩ廳"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡹࡥࡳ࡫ࡨࡷࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ廴"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廵"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ延")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦใศำอ์๋࠭廷"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๆหึะ่็ࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ廸"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廹"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ建")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ廻"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ廼"),144)
	return
def l111lll111ll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭廽"))
	return
def l111lll11l1l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ廾"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111l1llll11_l1_(url):
	html,l1lllll1l1_l1_,data = l111ll1lllll_l1_(url)
	dd = l1lllll1l1_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ廿")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ开")][l1l111_l1_ (u"ࠪࡸࡦࡨࡳࠨ弁")]
	for l1l11l111l_l1_ in range(len(dd)):
		item = dd[l1l11l111l_l1_]
		l111ll11llll_l1_(item,url,str(l1l11l111l_l1_))
	l111ll1111ll_l1_ = dd[0][l1l111_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ异")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭弃")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ弄")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ弅")]
	s = 0
	for l1l11l111l_l1_ in range(len(l111ll1111ll_l1_)):
		item = l111ll1111ll_l1_[l1l11l111l_l1_][l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弆")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ弇")][0]
		if list(item[l1l111_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弈")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ弉")].keys())[0]==l1l111_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弊"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_ = l111llll1ll1_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡำสสัฯࠠࠨ弋")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弌"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠨࠩ弍"),str(l1l11l111l_l1_))
	key = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ弎"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ式")+key[0]
	html,l1lllll1l1_l1_,l1l11llll_l1_ = l111ll1lllll_l1_(l1lllll1_l1_)
	for l1lll1l1llll_l1_ in range(3,4):
		dd = l1lllll1l1_l1_[l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ弐")][l1lll1l1llll_l1_][l1l111_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ弑")][l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ弒")]
		for l1l11l111l_l1_ in range(len(dd)):
			item = dd[l1l11l111l_l1_]
			if l1l111_l1_ (u"࡚ࠧࡱࡸࡘࡺࡨࡥࠡࡒࡵࡩࡲ࡯ࡵ࡮ࠩ弓") in str(item): continue
			l111ll11llll_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠨࠩ弔"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ引"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ弖"),l1l111_l1_ (u"ࠫࠬ弗"))
	html,l1lllll1l1_l1_,l1l11llll_l1_ = l111ll1lllll_l1_(url,data)
	l1l11lll11_l1_,l111l1lll1l1_l1_ = l1l111_l1_ (u"ࠬ࠭弘"),l1l111_l1_ (u"࠭ࠧ弙")
	owner = re.findall(l1l111_l1_ (u"ࠧࠣࡱࡺࡲࡪࡸࡎࡢ࡯ࡨࠦ࠳࠰࠿ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ弚"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠨࠤࡹ࡭ࡩ࡫࡯ࡐࡹࡱࡩࡷࠨ࠮ࠫࡁࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ弛"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡑࡪࡺࡡࡥࡣࡷࡥࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡰࡹࡱࡩࡷ࡛ࡲ࡭ࡵࠥ࠾ࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ弜"),html,re.DOTALL)
	if owner:
		l1l11lll11_l1_ = l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭弝")+owner[0][0]+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭弞")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ弟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ张") in url: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弡"),l1lllll_l1_+l1l11lll11_l1_,l1ll1ll_l1_,144)
	l111ll111111_l1_ = [l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ弢"),l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ弣"),l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭弤"),l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ弥"),l1l111_l1_ (u"ࠬ࠵ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ弦"),l1l111_l1_ (u"࠭ࡳࡴ࠿ࠪ弧"),l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ弨"),l1l111_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭弩"),l1l111_l1_ (u"ࠩࡥࡴࡂ࠭弪"),l1l111_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭弫")]
	l111l1lll11l_l1_ = not any(value in url for value in l111ll111111_l1_)
	if l111l1lll11l_l1_ and l1l11lll11_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠫฬ๊ศฮอࠪ弬")
		l1lllllll_l1_ = l1l111_l1_ (u"่่ࠬศศ่ࠤฬ๊สี฼ํ่ࠬ弭")
		l1l11l1l1_l1_ = l1l111_l1_ (u"࠭วๅใํำ๏๎็ศฬࠪ弮")
		l111l1lll1ll_l1_ = l1l111_l1_ (u"ࠧศๆๅ๊ํอสࠨ弯")
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭弰"),l1lllll_l1_+l1l11lll11_l1_,url,9999)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦอำหࠣࠩ弱") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弲"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠫࠬ弳"),l1l111_l1_ (u"ࠬ࠭弴"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ張"))
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ弶") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ強"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭弸"),144)
		if l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ弹") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ强"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭弻"),144)
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๆ๋๎วหࠤࠪ弼") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弽"),l1lllll_l1_+l111l1lll1ll_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ弾"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡘ࡫ࡡࡳࡥ࡫ࠦࠬ弿") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彀"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠫࠬ彁"),l1l111_l1_ (u"ࠬ࠭彂"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ彃"))
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭彄") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ彅"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭彆"),144)
		if l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࡜ࡩࡥࡧࡲࡷࠧ࠭彇") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ彈"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭彉"),144)
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥࠫ彊") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ彋"),l1lllll_l1_+l111l1lll1ll_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ彌"),144)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ彍"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ彎"),l1l111_l1_ (u"ࠫࠬ彏"),9999)
	if l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ彐") in url:
		dd = l1lllll1l1_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ彑")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ归")][l1l111_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ当")][l1l111_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彔")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ录")]
		l111l1ll1lll_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彖") in list(dd[i].keys()):
				l111l1ll1ll1_l1_ = dd[i][l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ彗")]
				length = len(str(l111l1ll1ll1_l1_))
				if length>l111l1ll1lll_l1_:
					l111l1ll1lll_l1_ = length
					l111l1lll1l1_l1_ = l111l1ll1ll1_l1_
		if l111l1ll1lll_l1_==0: return
	elif l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭彘") in url or l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭彙") in url or l1l111_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡁ࡮ࡩࡾࡃࠧ彚") in url or l1l111_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ彛") in url or l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ彜") in url or url==l111l1_l1_:
		l111ll11lll1_l1_ = []
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡉ࡯࡮࡯ࡤࡲࡩࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ彝"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡁࡤࡶ࡬ࡳࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ彞"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࠧ彟"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ彠"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ彡"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠱࠶ࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡢࡤ࡯ࡩ࡙ࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ形"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ彣"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯࡙ࡤࡸࡨ࡮ࡎࡦࡺࡷࡖࡪࡹࡵ࡭ࡶࡶࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠧ࡞ࠤ彤"))
		l111l1llllll_l1_,l111l1lll1l1_l1_ = l111l1ll1l1l_l1_(l1lllll1l1_l1_,l1l111_l1_ (u"ࠬ࠭彥"),l111ll11lll1_l1_)
	if not l111l1lll1l1_l1_:
		try:
			dd = l1lllll1l1_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ彦")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彧")][l1l111_l1_ (u"ࠨࡶࡤࡦࡸ࠭彨")]
			l1llll11ll11_l1_ = l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ彩") in url or l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ彪") in url or l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ彫") in url
			l111ll11l111_l1_ = l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆไ๎ิ๐่่ษอࠦࠬ彬") in html or l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣไ๋หห๋ࠠศๆอุ฿๐ไࠣࠩ彭") in html or l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ彮") in html
			l111ll111lll_l1_ = l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼࡚ࠥ࡮ࡪࡥࡰࡵࠥࠫ彯") in html or l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹࡹࠢࠨ彰") in html or l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡉࡨࡢࡰࡱࡩࡱࡹࠢࠨ影") in html
			if l1llll11ll11_l1_ and (l111ll11l111_l1_ or l111ll111lll_l1_):
				for l1l11l111l_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ彲") not in list(dd[l1l11l111l_l1_].keys()): continue
					l111ll1111ll_l1_ = dd[l1l11l111l_l1_][l1l111_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彳")]
					try: l111l1lllll1_l1_ = l111ll1111ll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ彴")][l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彵")][l1l111_l1_ (u"ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩ彶")][l1l111_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ彷")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭彸")][l1l11l111l_l1_]
					except: l111l1lllll1_l1_ = l111ll1111ll_l1_
					try: l1ll1ll_l1_ = l111l1lllll1_l1_[l1l111_l1_ (u"ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭役")][l1l111_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ彺")][l1l111_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ彻")][l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ彼")]
					except: continue
					if   l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ彽")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ彾")		in url: l111ll1111ll_l1_ = dd[l1l11l111l_l1_] ; break
					elif l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ彿")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ往")	in url: l111ll1111ll_l1_ = dd[l1l11l111l_l1_] ; break
					elif l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ征")	in l1ll1ll_l1_	and l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ徂")		in url: l111ll1111ll_l1_ = dd[l1l11l111l_l1_] ; break
					else: l111ll1111ll_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠧࡣࡲࡀࠫ徃") in url: l111ll1111ll_l1_ = dd[index]
			else: l111ll1111ll_l1_ = dd[0]
			l111l1lll1l1_l1_ = l111ll1111ll_l1_[l1l111_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭径")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ待")]
		except: pass
	if not l111l1lll1l1_l1_: return
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ徆"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ徇"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ很"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ徉"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ徊"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ律"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ後"))
	if l1l111_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ徍") not in url: l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡷࡺࡨࡍࡦࡰࡸࠫࡢࡡࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡚ࡹࡱࡧࡖࡹࡧࡓࡥ࡯ࡷࡌࡸࡪࡳࡳࠨ࡟ࠥ徎"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ徏"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ徐"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ徑"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ徒"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ従"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ徔"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ徕"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ徖"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧࠤ得"))
	l11l11ll1l1_l1_ = l111ll11lll_l1_(l1l111_l1_ (u"ࡵࠨๅ็ࠤ็๎วว็ࠣห้ะิ฻์็ࠫ徘"))
	l11l11ll1ll_l1_ = l111ll11lll_l1_(l1l111_l1_ (u"ࡶࠩๆ่ࠥอไโ์า๎ํํวหࠩ徙"))
	l111l1llll1l_l1_ = l111ll11lll_l1_(l1l111_l1_ (u"ࡷࠪ็้ࠦวๅไ้์ฬะࠧ徚"))
	l1l11llll1ll_l1_ = [l11l11ll1l1_l1_,l11l11ll1ll_l1_,l111l1llll1l_l1_,l1l111_l1_ (u"ࠪࡅࡱࡲࠠࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ徛"),l1l111_l1_ (u"ࠫࡆࡲ࡬ࠡࡸ࡬ࡨࡪࡵࡳࠨ徜"),l1l111_l1_ (u"ࠬࡇ࡬࡭ࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ徝")]
	l111ll11111l_l1_,l111l1lllll1_l1_ = l111l1ll1l1l_l1_(l111l1lll1l1_l1_,index,l111ll11lll1_l1_)
	if l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ從") in str(type(l111l1lllll1_l1_)) and any(value in str(l111l1lllll1_l1_[0]) for value in l1l11llll1ll_l1_): del l111l1lllll1_l1_[0]
	for index2 in range(len(l111l1lllll1_l1_)):
		l111ll11lll1_l1_ = []
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ徟"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ徠"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ御"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ徢"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ徣"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ徤"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡬ࡧ࡭ࡦࡅࡤࡶࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡫ࡦࡳࡥࠨ࡟ࠥ徥"))
		l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠࠦ徦"))
		l111l1llllll_l1_,item = l111l1ll1l1l_l1_(l111l1lllll1_l1_,index2,l111ll11lll1_l1_)
		l111ll11llll_l1_(item,url,str(index2))
		if l111l1llllll_l1_==l1l111_l1_ (u"ࠨ࠶ࠪ徧"):
			try:
				hh = item[l1l111_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩ徨")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ復")][l1l111_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ循")][l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ徫")]
				for l111ll1l1lll_l1_ in range(len(hh)):
					l1l1l111ll1l_l1_ = hh[l111ll1l1lll_l1_]
					l111ll11llll_l1_(l1l1l111ll1l_l1_)
			except: pass
	l111lllll1_l1_ = False
	if l1l111_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ徬") not in url and l111ll11111l_l1_==l1l111_l1_ (u"ࠧ࠹ࠩ徭"): l111lllll1_l1_ = True
	if l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ微") in l1l11llll_l1_: l111lll1l11l_l1_,key,l111l1lll111_l1_,l111lll11l11_l1_,token,l111lll1111l_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭徯"))
	else: l111lll1l11l_l1_,key,l111l1lll111_l1_,l111lll11l11_l1_,token,l111lll1111l_l1_ = l1l111_l1_ (u"ࠪࠫ徰"),l1l111_l1_ (u"ࠫࠬ徱"),l1l111_l1_ (u"ࠬ࠭徲"),l1l111_l1_ (u"࠭ࠧ徳"),l1l111_l1_ (u"ࠧࠨ徴"),l1l111_l1_ (u"ࠨࠩ徵")
	l1lllll1_l1_,l111l1lll1_l1_ = l1l111_l1_ (u"ࠩࠪ徶"),l1l111_l1_ (u"ࠪࠫ德")
	if menuItemsLIST:
		l111ll111ll1_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠫࡈࡎࡎࡍࠩ徸") in l111ll111ll1_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠬࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ徹")
		elif l1lllll_l1_+l1l111_l1_ (u"࠭ࡕࡔࡇࡕࠫ徺") in l111ll111ll1_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠧࡄࡊࡄࡒࡓࡋࡌࡔࠩ徻")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠨࡎࡌࡗ࡙࠭徼") in l111ll111ll1_l1_: l111l1lll1_l1_ = l1l111_l1_ (u"ࠩࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ徽")
	if l1l111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡶࠦࠬ徾") in html and l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ徿") not in url and not l111lllll1_l1_ and l1l111_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪࠧ忀") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫࡟ࡢ࡬ࡤࡼࡄࡩࡴࡰ࡭ࡨࡲࡂ࠭忁")+l111l1lll111_l1_
	elif l1l111_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ忂") in html and l1l111_l1_ (u"ࠨࡤࡳࡁࠬ心") not in url and l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ忄") in url or l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡂ࡯ࡪࡿ࠽ࠨ必") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࡂ࡯ࡪࡿ࠽ࠨ忆")+key
	elif l1l111_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠭忇") in html and l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ忈") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪࡅ࡫ࡦࡻࡀࠫ忉")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ忊"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ忋"),l1lllll1_l1_,144,l111l1lll1_l1_,l1l111_l1_ (u"ࠪࠫ忌"),l1l11llll_l1_)
	return
def l111l1ll1l1l_l1_(l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l111ll1l1l11_l1_):
	l1lllll1l1_l1_ = l1l1l1l1l11l_l1_
	l111l1lll1l1_l1_,index = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	l111l1lllll1_l1_,index2 = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	item,l111ll111l11_l1_ = l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_
	count = len(l111ll1l1l11_l1_)
	for l1l11l111l_l1_ in range(count):
		try:
			out = eval(l111ll1l1l11_l1_[l1l11l111l_l1_])
			return str(l1l11l111l_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠫࠬ忍"),l1l111_l1_ (u"ࠬ࠭忎")
def l111llll1ll1_l1_(item):
	try: l111lll111l1_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"࠭ࠧ忏"),l1l111_l1_ (u"ࠧࠨ忐"),l1l111_l1_ (u"ࠨࠩ忑"),l1l111_l1_ (u"ࠩࠪ忒"),l1l111_l1_ (u"ࠪࠫ忓"),l1l111_l1_ (u"ࠫࠬ忔"),l1l111_l1_ (u"ࠬ࠭忕")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_ = False,l1l111_l1_ (u"࠭ࠧ忖"),l1l111_l1_ (u"ࠧࠨ志"),l1l111_l1_ (u"ࠨࠩ忘"),l1l111_l1_ (u"ࠩࠪ忙"),l1l111_l1_ (u"ࠪࠫ忚"),l1l111_l1_ (u"ࠫࠬ忛"),l1l111_l1_ (u"ࠬ࠭応")
	l111ll111l11_l1_ = item[l111lll111l1_l1_]
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ忝"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ忞"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ忟"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ忠"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ忡"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ忢"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ忣"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ忤"))
	l111l1llllll_l1_,title = l111l1ll1l1l_l1_(item,l111ll111l11_l1_,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ忥"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ忦"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ忧"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ忨"))
	l111l1llllll_l1_,l1ll1ll_l1_ = l111l1ll1l1l_l1_(item,l111ll111l11_l1_,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ忩"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ忪"))
	l111l1llllll_l1_,l1ll1l_l1_ = l111l1ll1l1l_l1_(item,l111ll111l11_l1_,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ快"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ忬"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ忭"))
	l111l1llllll_l1_,count = l111l1ll1l1l_l1_(item,l111ll111l11_l1_,l111ll11lll1_l1_)
	l111ll11lll1_l1_ = []
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ忮"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ忯"))
	l111ll11lll1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ忰"))
	l111l1llllll_l1_,l1l1lll1ll_l1_ = l111l1ll1l1l_l1_(item,l111ll111l11_l1_,l111ll11lll1_l1_)
	if l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ忱") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ忲"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ忳")
	if l1l111_l1_ (u"ࠨ็หหูืࠧ忴") in l1l1lll1ll_l1_: l1l1lll1ll_l1_,l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ念"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ忶")
	if l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ忷") in list(l111ll111l11_l1_.keys()):
		l111lll1llll_l1_ = str(l111ll111l11_l1_[l1l111_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ忸")])
		if l1l111_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭忹") in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠧࠥ࠼ࠪ忺")
		if l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡐ࡙ࠪ忻") in l111lll1llll_l1_: l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ忼")
		if l1l111_l1_ (u"ࠪࡆࡺࡿࠧ忽") in l111lll1llll_l1_ or l1l111_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ忾") in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠬࠪࠤ࠻ࠩ忿")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡻࠧๆสสุึ࠭怀")) in l111lll1llll_l1_: l111lll1l1ll_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ态")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡶࠩืีฬวࠧ怂")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿࠭怃")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡸࠫฬูสวฮสีࠬ怄")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠨ怅")
		if l111ll11lll_l1_(l1l111_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ怆")) in l111lll1llll_l1_: l111lll11111_l1_ = l1l111_l1_ (u"࠭ࠤ࠻ࠩ怇")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ怈") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠨࡁࠪ怉"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ怊") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ怋")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111lll11111_l1_: title = l111lll11111_l1_+l1l111_l1_ (u"ࠫࠥࠦࠧ怌")+title
	l1l1lll1ll_l1_ = l1l1lll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࠲ࠧ怍"),l1l111_l1_ (u"࠭ࠧ怎"))
	count = count.replace(l1l111_l1_ (u"ࠧ࠭ࠩ怏"),l1l111_l1_ (u"ࠨࠩ怐"))
	count = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨ࠰࠭怑"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠪࠫ怒")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_
def l111ll11llll_l1_(item,url=l1l111_l1_ (u"ࠫࠬ怓"),index=l1l111_l1_ (u"ࠬ࠭怔")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll1ll_l1_,l111lll1l1ll_l1_,l111lll11111_l1_ = l111llll1ll1_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怕") in str(item): return
	elif l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡐࡺࡸࡕࡩࡳࡪࡥࡳࡧࡵࠫ怖") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ怗") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ怘") in url or l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怙") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠫࡂࡃ࠽ࠡࠩ怚")+title+l1l111_l1_ (u"ࠬࠦ࠽࠾࠿ࠪ怛")
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ怜"),l1lllll_l1_+title,l1l111_l1_ (u"ࠧࠨ思"),9999)
	elif title and l1l111_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怞") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ怟"),l1lllll_l1_+title,l1l111_l1_ (u"ࠪࠫ怠"),9999)
	elif l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ怡") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ怢"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l111lll1l1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ怣"),l1lllll_l1_+l111lll1l1ll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ怤") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ急") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ怦") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ性") not in l1ll1ll_l1_:
			l111lll11lll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ怨"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ怩")+l111lll11lll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怪"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡍࡋࡖࡘࠬ怫")+count+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ怬")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ怭"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ怮"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll1ll_l1_)
	else:
		type = l1l111_l1_ (u"ࠫࠬ怯")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭怰"),l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ怱"),l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ怲"),l1l111_l1_ (u"ࠨ࠱ࡩࡩࡦࡺࡵࡳࡧࡧࠫ怳"),l1l111_l1_ (u"ࠩࡶࡷࡂ࠭怴"),l1l111_l1_ (u"ࠪࡦࡵࡃࠧ怵")]):
			if l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ怶")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡣ࠰ࠩ怷") in l1ll1ll_l1_: type = l1l111_l1_ (u"࠭ࡃࡉࡐࡏࠫ怸")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ怹")
			if l1l111_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࠨ怺") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠩࡘࡗࡊࡘࠧ总")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ怼")
			index,l111ll1111l1_l1_ = l1l111_l1_ (u"ࠫࠬ怽"),l1l111_l1_ (u"ࠬ࠭怾")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭怿"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l111ll1lllll_l1_(url,data=l1l111_l1_ (u"ࠧࠨ恀"),request=l1l111_l1_ (u"ࠨࠩ恁")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ恂"))
	if request==l1l111_l1_ (u"ࠪࠫ恃"): request = l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ恄")
	l11ll1l1l1_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ恅"):l11ll1l1l1_l1_,l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭恆"):l1l111_l1_ (u"ࠧࡑࡔࡈࡊࡂ࡮࡬࠾ࡣࡵࠫ恇")}
	if l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ恈") in data: l111lll1l11l_l1_,key,l111l1lll111_l1_,l111lll11l11_l1_,token,l111lll1111l_l1_ = data.split(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭恉"))
	else: l111lll1l11l_l1_,key,l111l1lll111_l1_,l111lll11l11_l1_,token,l111lll1111l_l1_ = l1l111_l1_ (u"ࠪࠫ恊"),l1l111_l1_ (u"ࠫࠬ恋"),l1l111_l1_ (u"ࠬ࠭恌"),l1l111_l1_ (u"࠭ࠧ恍"),l1l111_l1_ (u"ࠧࠨ恎"),l1l111_l1_ (u"ࠨࠩ恏")
	if l1l111_l1_ (u"ࠩࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭恐") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ恑")] = {l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ恒"):{l1l111_l1_ (u"ࠧ࡮࡬ࠣ恓"):l1l111_l1_ (u"ࠨࡡࡳࠤ恔"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ恕"):l1l111_l1_ (u"࡙ࠣࡈࡆࠧ恖"),l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ恗"):l111lll11l11_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ恘"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠷ࡳࡵࠩ恙"))
	elif l1l111_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ恚") in url and l111lll1l11l_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ恛"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ恜")] = {l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࠣ恝"):{l1l111_l1_ (u"ࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ恞"):l111lll1l11l_l1_,l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ恟"):l1l111_l1_ (u"ࠦ࡜ࡋࡂࠣ恠"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ恡"):l111lll11l11_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ恢"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠴ࡱࡨࠬ恣"))
	elif l1l111_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ恤") in url and l111lll1111l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲ࡔࡡ࡮ࡧࠪ恥"):l1l111_l1_ (u"ࠪ࠵ࠬ恦"),l1l111_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ恧"):l111lll11l11_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ恨"):l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࡁࠬ恩")+l111lll1111l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ恪"),url,l1l111_l1_ (u"ࠨࠩ恫"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ恬"),l1l111_l1_ (u"ࠪࠫ恭"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠹ࡲࡥࠩ恮"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ息"),url,l1l111_l1_ (u"࠭ࠧ恰"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ恱"),l1l111_l1_ (u"ࠨࠩ恲"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ恳"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ恴"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡶࡦࡴࠥ࠲࠯ࡅࠢࡷࡣ࡯ࡹࡪࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ恵"),html,re.DOTALL|re.I)
	if tmp: l111lll11l11_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ恶"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ恷"),html,re.DOTALL|re.I)
	if tmp: l111lll1l11l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ恸"),html,re.DOTALL|re.I)
	if tmp: l111l1lll111_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭恹") in list(cookies.keys()): l111lll1111l_l1_ = cookies[l1l111_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ恺")]
	data = l111lll1l11l_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ恻")+key+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ恼")+l111l1lll111_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ恽")+l111lll11l11_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ恾")+token+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ恿")+l111lll1111l_l1_
	if request==l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ悀") and l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ悁") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࡟࡟ࠧࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠧࡢ࡝ࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ悂"),html,re.DOTALL)
		if not l11ll11l1l_l1_: l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ悃"),html,re.DOTALL)
		l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ悄"),l11ll11l1l_l1_[0])
	elif request==l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ悅") and l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ悆") in html:
		l11ll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ悇"),html,re.DOTALL)
		l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡷ࠭悈"),l11ll11l1l_l1_[0])
	elif l1l111_l1_ (u"ࠪࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭悉") not in html: l111lll1lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ悊"),html)
	else: l111lll1lll1_l1_ = l1l111_l1_ (u"ࠬ࠭悋")
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ悌"),data)
	return html,l111lll1lll1_l1_,data
def l111llll11l1_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ悍"),l1l111_l1_ (u"ࠨ࠭ࠪ悎"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ悏")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ悐"),l1l111_l1_ (u"ࠫ࠰࠭悑"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ悒")+search
	if not l11_l1_:
		if l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ悓") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ悔")
		elif l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ悕") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ悖")
		elif l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ悗") in options: l111ll1ll11l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ悘")
		l1llllll_l1_ = l1lllll1_l1_+l111ll1ll11l_l1_
	else:
		l111ll1ll111_l1_,l111ll11l1ll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠬ࠭悙")
		l111ll11ll1l_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ悚"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭悛"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ悜"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ悝"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ悞")]
		l111lll1ll1l_l1_ = [l1l111_l1_ (u"ࠫࠬ悟"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ悠"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ悡"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭悢"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ患")]
		l111llll1111_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ悤"),l111ll11ll1l_l1_)
		if l111llll1111_l1_ == -1: return
		l111ll1l1ll1_l1_ = l111lll1ll1l_l1_[l111llll1111_l1_]
		html,c,data = l111ll1lllll_l1_(l1lllll1_l1_+l111ll1l1ll1_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ悥")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ悦")][l1l111_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ悧")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ您")][l1l111_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ悩")][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ悪")][l1l111_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ悫")]
			for l111ll11l1l1_l1_ in range(len(d)):
				group = d[l111ll11l1l1_l1_][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悬")][l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ悭")]
				for l111llll11ll_l1_ in range(len(group)):
					l111ll111l11_l1_ = group[l111llll11ll_l1_][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ悮")]
					if l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ悯") in list(l111ll111l11_l1_.keys()):
						l1ll1ll_l1_ = l111ll111l11_l1_[l1l111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ悰")][l1l111_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ悱")][l1l111_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ悲")][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ悳")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ悴"),l1l111_l1_ (u"ࠬࠬࠧ悵"))
						title = l111ll111l11_l1_[l1l111_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ悶")]
						title = title.replace(l1l111_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ悷"),l1l111_l1_ (u"ࠨࠩ悸"))
						if l1l111_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ悹") in title: continue
						if l1l111_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ悺") in title:
							title = l1l111_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ悻")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠬะัห์หࠤาูศࠨ悼") in title: continue
						title = title.replace(l1l111_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ悽"),l1l111_l1_ (u"ࠧࠨ悾"))
						if l1l111_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ悿") in title: continue
						if l1l111_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ惀") in title:
							title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ惁")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ惂") in title: continue
						l111ll1ll111_l1_.append(escapeUNICODE(title))
						l111ll11l1ll_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l111lll1ll11_l1_ = l1l111_l1_ (u"ࠬ࠭惃")
		else:
			l111ll1ll111_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ惄"),l1lllllll_l1_]+l111ll1ll111_l1_
			l111ll11l1ll_l1_ = [l1l111_l1_ (u"ࠧࠨ情"),l111lllll_l1_]+l111ll11l1ll_l1_
			l111llll1l1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭惆"),l111ll1ll111_l1_)
			if l111llll1l1l_l1_ == -1: return
			l111lll1ll11_l1_ = l111ll11l1ll_l1_[l111llll1l1l_l1_]
		if l111lll1ll11_l1_: l1llllll_l1_ = l111l1_l1_+l111lll1ll11_l1_
		elif l111ll1l1ll1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1l1ll1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
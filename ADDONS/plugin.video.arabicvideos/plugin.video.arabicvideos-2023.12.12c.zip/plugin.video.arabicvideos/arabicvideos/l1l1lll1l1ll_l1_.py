# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ䊂")
headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䊃") : l1l111_l1_ (u"ࠫࠬ䊄") }
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡍࡗ࡜ࡢࠫ䊅")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1l1l1ll1111_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l1ll1111_l1_():
	message = l1l111_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ䊆")
	l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䊇"),l1l111_l1_ (u"ࠨࠩ䊈"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䊉"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊊"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䊋"),l1l111_l1_ (u"ࠬ࠭䊌"),189,l1l111_l1_ (u"࠭ࠧ䊍"),l1l111_l1_ (u"ࠧࠨ䊎"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䊏"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊐"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䊑")+l1lllll_l1_+l1l111_l1_ (u"ࠫอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࠬ䊒"),l111l1_l1_,181,l1l111_l1_ (u"ࠬ࠭䊓"),l1l111_l1_ (u"࠭ࠧ䊔"),l1l111_l1_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫ䊕"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊖"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䊗")+l1lllll_l1_+l1l111_l1_ (u"ࠪวาีหࠡษ็หๆ๊วๆࠩ䊘"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䊙"),l1l111_l1_ (u"ࠬ࠭䊚"),l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䊛"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊜"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䊝")+l1lllll_l1_+l1l111_l1_ (u"ࠩอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ䊞"),l111l1_l1_,181,l1l111_l1_ (u"ࠪࠫ䊟"),l1l111_l1_ (u"ࠫࠬ䊠"),l1l111_l1_ (u"ࠬࡺࡶࠨ䊡"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊢"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䊣")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨ䊤"),l111l1_l1_,181,l1l111_l1_ (u"ࠩࠪ䊥"),l1l111_l1_ (u"ࠪࠫ䊦"),l1l111_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䊧"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊨"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䊩")+l1lllll_l1_+l1l111_l1_ (u"ࠧฤไ๋ํࠥอไศใ็ห๊ࠦวๅฯส่๏ฯࠧ䊪"),l111l1_l1_,181,l1l111_l1_ (u"ࠨࠩ䊫"),l1l111_l1_ (u"ࠩࠪ䊬"),l1l111_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䊭"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䊮"),headers,l1l111_l1_ (u"ࠬ࠭䊯"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䊰"))
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠵ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䊱"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊲"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䊳")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠪࠫ䊴")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ䊵"),headers,l1l111_l1_ (u"ࠬ࠭䊶"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䊷"))
	if type==l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䊸"): block = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ละำะࠦวๅลไ่ฬ๋࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭䊹"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭䊺"): block = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ䊻"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䊼"): block = re.findall(l1l111_l1_ (u"ࠬࡨࡴ࡯࠯࠵࠱ࡴࡼࡥࡳ࡮ࡤࡽ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪ䊽"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䊾"): block = re.findall(l1l111_l1_ (u"ࠧࡣࡶࡱ࠱࠶ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠫ࠲࠯ࡅࠩࡣࡶࡱ࠱࠷ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠪ䊿"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠨࡶࡹࠫ䋀"): block = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡩࠥࠫ䋁"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䋂"),l1l111_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䋃")]:
		items = re.findall(l1l111_l1_ (u"ࠬࡹࡴࡺ࡮ࡨࡁࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䋄"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹࡃࠢ࠴࡝࠳࠱࠾ࡣࠫࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䋅"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠧโ์็้ࠬ䋆"),l1l111_l1_ (u"ࠨษ็ั้่ษࠨ䋇"),l1l111_l1_ (u"ࠩส่า๊โ่ࠩ䋈"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ䋉"),l1l111_l1_ (u"ࠫࡗࡧࡷࠨ䋊"),l1l111_l1_ (u"࡙ࠬ࡭ࡢࡥ࡮ࡈࡴࡽ࡮ࠨ䋋"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ䋌"),l1l111_l1_ (u"ࠧศฮีหฦ࠭䋍")]
	for l1ll1l_l1_,l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_ in items:
		if type in [l1l111_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䋎"),l1l111_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䋏")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1l1l1l11l_l1_,l1l1l1ll111l_l1_,l1l1l1ll11l1_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡃࡻ࡯ࡥࡸ࠿ࡷࡶࡺ࡫ࠧ䋐"),l1l111_l1_ (u"ࠫࠬ䋑"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠬฮฬ้ัฬࠤࠬ䋒") in title or l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䋓") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䋔") + title.replace(l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䋕"),l1l111_l1_ (u"ࠩࠪ䋖")).replace(l1l111_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ䋗"),l1l111_l1_ (u"ࠫࠬ䋘"))
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ䋙"))
		if l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭䋚") in title or l1l111_l1_ (u"ࠧศๆะ่็ํࠧ䋛") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡟ࡨ࠰࠭䋜"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䋝") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋞"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䋟") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䋠"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䋡") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䋢"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠨࠩ䋣"):
		items = re.findall(l1l111_l1_ (u"ࠩ࡟ࡲࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䋤"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫ䋥"),l1l111_l1_ (u"ࠫࠬ䋦"))
			if title!=l1l111_l1_ (u"ࠬ࠭䋧"):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋨"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭䋩")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䋪"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䋫"),headers,l1l111_l1_ (u"ࠪࠫ䋬"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭䋭"))
	block = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡩࡵ࡮ࡨࡂ࠳࠰࠿ࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࡞࠴࠲࠿࡝ࠬࠫࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䋮"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡜࠲࠰࠽ࡢ࠱ࠧ䋯"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䋰") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࡑࡹࡲࡨࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䋱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䋲"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"ࠪࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭࠲࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ䋳"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭䋴"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠬ࠮ࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ䋵"),l1ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ䋶"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠧࠡࠩ䋷") + title[0][1]
			else: title = l1l111_l1_ (u"ࠨࠩ䋸")
			title = name + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䋹") + l1l111_l1_ (u"ࠪห้ำไใหࠪ䋺") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䋻"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠬฮฬ้ัฬࠤࠬ䋼") in title or l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䋽") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䋾") + title.replace(l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䋿"),l1l111_l1_ (u"ࠩࠪ䌀")).replace(l1l111_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ䌁"),l1l111_l1_ (u"ࠫࠬ䌂"))
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䌃"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1l1l1ll11_l1_ = url.split(l1l111_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䌄"))
	l1lllll1_l1_ = l1l1l1l1ll11_l1_[0]
	del l1l1l1l1ll11_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䌅"),headers,l1l111_l1_ (u"ࠨࠩ䌆"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䌇"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡪࡴࡴࡴ࠮ࡵ࡬ࡾࡪࡀࠠ࠳࠷ࡳࡼࡀࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䌈"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1l1l1ll11_l1_: l1l1l1l1ll11_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1l1l1ll11_l1_:
		if l1l111_l1_ (u"ࠫ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࠪ䌉") in l1ll1ll_l1_:
			l1l1l1l11lll_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1l1l11lll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓࡡࡪࡰࠪ䌊"))
	for l1ll1ll_l1_ in l1l1l1l1ll11_l1_:
		if l1l111_l1_ (u"࠭࠺࠰࠱ࡹࡦ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠩ䌋") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䌌"),headers,l1l111_l1_ (u"ࠨࠩ䌍"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ䌎"))
			html = html.decode(l1l111_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩ䌏")).encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䌐"))
			html = html.replace(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡦࡳࡲ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䌑"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䌒"))
			html = html.replace(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌓"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䌔"))
			html = html.replace(l1l111_l1_ (u"ࠩ࠿࠳ࡦࡄ࠼࠰ࡦ࡬ࡺࡃࡂࡢࡳࠢ࠲ࡂࡁࡪࡩࡷࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࡁࠫ䌕"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌖"))
			html = html.replace(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹࡨ࡯ࡳࡦࡨࡶࠧࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨࠧ䌗"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌘"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䌙"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1l1l1l111_l1_,l1l1l1l1lll1_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠧࠨ䌚")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳࠮࡯࡯࡮࡬ࡲࡪࢂࡣࡰ࡯ࠬ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠴ࠪࡀ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࠭ࠫ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䌛"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࠫ䌜") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀ࠾࡫ࡶࠥࡹࡩࡻࡧࡀࠦ࠶ࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࠧ䌝")+l1l111_l1_ (u"ࠫࠨ࠭䌞")+l1l111_l1_ (u"ࠬ࠹࠳࠴࠽ࠣࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡤࡱ࡯ࡳࡷࡀࠧ䌟")+l1l111_l1_ (u"࠭ࠣࠨ䌠")+l1l111_l1_ (u"ࠧ࠴࠵࠶ࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䌡"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࠪ䌢") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄ࠯࠼ࡩࡴࠣࡷ࡮ࢀࡥ࠾ࠤ࠴ࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠬ䌣")+l1l111_l1_ (u"ࠪࠧࠬ䌤")+l1l111_l1_ (u"ࠫ࠸࠹࠳࠼ࠢࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡣࡰ࡮ࡲࡶ࠿࠭䌥")+l1l111_l1_ (u"ࠬࠩࠧ䌦")+l1l111_l1_ (u"࠭࠳࠴࠵ࠥࠤ࠴ࡄ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䌧"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠧࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌨")
						l1l1l1l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࠫ࠲࠯ࡅࠩࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵ࠧ䌩"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠩࡁࠤ࠯࠮࡛࡟࠾ࡁࡡ࠰࠯ࠠࠫ࠾ࠪ䌪"),l1l1l1l1llll_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"ࠪࠤࠬ䌫").join(title)
						title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭䌬"))
						title = title.replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䌭"),l1l111_l1_ (u"࠭ࠠࠨ䌮")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䌯"),l1l111_l1_ (u"ࠨࠢࠪ䌰")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䌱"),l1l111_l1_ (u"ࠪࠤࠬ䌲")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䌳"),l1l111_l1_ (u"ࠬࠦࠧ䌴")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䌵"),l1l111_l1_ (u"ࠧࠡࠩ䌶"))
						l1l1l1l1l111_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨลัฮึࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศ࠻ࠩ䌷"), l1l1l1l1l111_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1l1l1l111_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯࠭ࠧ࠭䌸"),block,re.DOTALL)
				l1l1l1l11ll1_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡊࡴࡸࡵ࡮ࠩ䌹"))
				block = block.replace(l1l111_l1_ (u"ࠫๅ࠭䌺"),l1l111_l1_ (u"ࠬ࠭䌻"))
				block = block.replace(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ䌼"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡨ࡯ࡵࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䌽"))
				block = block.replace(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ䌾"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䌿"))
				block = block.replace(l1l111_l1_ (u"ࠪื๏ืแาษอࠤฬ๊สฮ็ํ่ࠬ䍀"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦࠥࠦ࡜࡯ࠢࠣࠫ䍁"))
				block = block.replace(l1l111_l1_ (u"ࠬื่ศสฺࠤฬ๊สฮ็ํ่ࠬ䍂"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭䍃"))
				block = block.replace(l1l111_l1_ (u"ࠧิ์ิๅึอสࠡษ็ู้อ็ะࠩ䍄"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡷࡢࡶࡦ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䍅"))
				block = block.replace(l1l111_l1_ (u"ࠩิ์ฬฮืࠡษ็ู้อ็ะࠩ䍆"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䍇"))
				l1l1l1l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࡜ࡥ࠭ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䍈"),block,re.DOTALL)
				for l1l1l1l1ll1l_l1_ in l1l1l1l1l1l1_l1_:
					type = re.findall(l1l111_l1_ (u"ࠬࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࠪ䍉"),l1l1l1l1ll1l_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"࠭ࡢࡰࡶ࡫ࠫ䍊"): type = l1l111_l1_ (u"ࠧࡠࡡࠪ䍋")+type[0]
						else: type = l1l111_l1_ (u"ࠨࠩ䍌")
					items = re.findall(l1l111_l1_ (u"ࠩࠫࡃࡁࠧࡨࡵࡶࡳ࠾࠴࠵ࡥ࠶ࡶࡶࡥࡷ࠴ࡣࡰ࡯࠲࠭࠭ࡢࡷࠬ࡝ࠣࡠࡼࡣࠪ࠽࠱ࡩࡳࡳࡺ࠾࠯ࠬࡂࢀࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰࠼ࡣࡴࠣ࠳ࡃ࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࠮ࠫࡁࠬࠦࠬ䍍"),l1l1l1l1ll1l_l1_,re.DOTALL)
					for l1l1l1l1l1ll_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"ࠪࠬࡡࡽࠫ࡜ࠢ࡟ࡻࡢ࠰ࠩ࠽ࠩ䍎"),l1l1l1l1l1ll_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䍏") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1ll1l_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭䍐"),headers,l1l111_l1_ (u"࠭ࠧ䍑"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䍒"))
	items = re.findall(l1l111_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䍓"),html,re.DOTALL)
	if items:
		l1l1l1ll11ll_l1_ = items[-1]
		l1llll_l1_.append(l1l1l1ll11ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡐࡳࡧ࡯࡬ࡦࠩ䍔"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䍕"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ䍖"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭䍗"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ䍘"),l1l111_l1_ (u"ࠧࠬࠩ䍙"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩ䍚"),headers,l1l111_l1_ (u"ࠩࠪ䍛"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䍜"))
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࡃ࠭䍝"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠬ࠭䍞") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"࠭วๅๅ็ࠤํฮฯ้่ࠣๅ้ะัࠨ䍟") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไโๆอีࠥอไๆ่สือࡀࠧ䍠"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠨࠩ䍡")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ䍢")+search+l1l111_l1_ (u"ࠪࠪࡲࡩࡡࡵ࠿ࠪ䍣")+category
	l1lll11_l1_(url)
	return
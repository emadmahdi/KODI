# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ喪")
headers = l1l111_l1_ (u"ࠧࠨ喫")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧ喬")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ喭"),l1l111_l1_ (u"ࠪห้้ไࠨ單"),l1l111_l1_ (u"ࠫฬ็ไศ็ࠪ喯"),l1l111_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ喰"),l1l111_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ喱")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ喲")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ喳")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll11ll_l1_(l111l1_l1_,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ喴"),l1l111_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ喵"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵࠩ営"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喷"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭喸"),l1l111_l1_ (u"ࠧࠨ喹"),119,l1l111_l1_ (u"ࠨࠩ喺"),l1l111_l1_ (u"ࠩࠪ喻"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ喼"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ喽"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ喾"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喿"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ嗀"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭嗁"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嗂"),l1l111_l1_ (u"ࠪࠫ嗃"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嗄"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭嗅"),l1l11ll_l1_,111,l1l111_l1_ (u"࠭ࠧ嗆"),l1l111_l1_ (u"ࠧࠨ嗇"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ嗈"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠪ嗉"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ嗊"),l1l111_l1_ (u"ࠫࠬ嗋"),l1l111_l1_ (u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧ嗌"),l1l111_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส๐ฬศัࠣ฽๋๎ว็ࠢส่๊๎โฺࠢฦ์ࠥะีๆ์่ࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠩ嗍"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嗎"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嗏"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ嗐")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ嗑"),filter)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ嗒"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嗓"),l1l111_l1_ (u"࠭ࠧ嗔"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡴࡲࡴࡩࡵࡷ࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ嗕"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嗖"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ嗗"),l1l111_l1_ (u"ࠪࠫ嗘")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ嗙"),l1l111_l1_ (u"ࠬ࠭嗚")).strip(l1l111_l1_ (u"࠭ࠠࠨ嗛"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嗜") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ嗝") in l1ll1ll_l1_: title = l1l111_l1_ (u"้ࠩ๎ฯ็ไไีࠪ嗞")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗟"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嗠")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠬ࠭嗡"),response=l1l111_l1_ (u"࠭ࠧ嗢")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嗣"),url,l1l111_l1_ (u"ࠨࠩ嗤"),headers,l1l111_l1_ (u"ࠩࠪ嗥"),l1l111_l1_ (u"ࠪࠫ嗦"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ嗧"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ嗨"): l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡧ࡭࡫ࡧࡩࡤࡥࡳ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嗩"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ嗪"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ嗫"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ嗬"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ嗭"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ嗮"),l1l111_l1_ (u"้ࠬไ๋สࠪ嗯"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ嗰"),l1l111_l1_ (u"่ࠧัสๅࠬ嗱"),l1l111_l1_ (u"ࠨ็หหึอษࠨ嗲"),l1l111_l1_ (u"ࠩ฼ี฻࠭嗳"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ嗴"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ嗵")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ嗶") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ嗷"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ嗸"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ嗹"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠩไ๎้๋ࠧ嗺") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嗻"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ嗼") in title and l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嗽") not in url:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ嗾") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗿"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲ࠰ࠩ嘀") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘁"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ嘂") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ嘃") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ嘄")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘅"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭嘆") in url and l1l111_l1_ (u"ࠨฯ็ๆฮ࠭嘇") in title:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嘈"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘉"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嘊"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ嘋"): items = re.findall(l1l111_l1_ (u"࠭ࠨࡶࡲࡧࡥࡹ࡫ࡑࡶࡧࡵࡽ࠮࠴ࠪࡀࡀࠫ࠲࠰ࡅࠩ࠽ࠩ嘌"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠧ࠽࡮࡬ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嘍"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ嘎"):
				title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ嘏"),l1l111_l1_ (u"ࠪࠫ嘐")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ嘑"),l1l111_l1_ (u"ࠬ࠭嘒"))
				if l1l111_l1_ (u"࠭࠿ࠨ嘓") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ嘔")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨࡁࡳࡥ࡬࡫࠽ࠨ嘕")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘖"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ嘗")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠫࠬ嘘"),l1l111_l1_ (u"ࠬ࠭嘙"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1111lll1_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嘚"),url,l1l111_l1_ (u"ࠧࠨ嘛"),headers,l1l111_l1_ (u"ࠨࠩ嘜"),l1l111_l1_ (u"ࠩࠪ嘝"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ嘞"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠣࡨ࠲࡬࡬ࡦࡺࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嘟"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ嘠") in l11llll_l1_[0]: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111llll1l_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l11l111l_l1_ in range(2):
		if l11l1111lll1_l1_: mode,type,block = 116,l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘡"),l111llll1l_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嘢"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嘣"),block,re.DOTALL)
		if l11l1111lll1_l1_ and len(items)<2:
			l11l1111lll1_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠩࠣࠫ嘤")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠭嘥") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡸࡥࡢࡦࡦࡶࡺࡳࡢࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嘦"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嘧"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ嘨")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嘩"),url,l1l111_l1_ (u"ࠨࠩ嘪"),headers,l1l111_l1_ (u"ࠩࠪ嘫"),l1l111_l1_ (u"ࠪࠫ嘬"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ嘭"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡧࡣࡵ࡫ࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嘮"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嘯"),block,re.DOTALL)
	l11l1111llll_l1_ = l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ嘰") in block
	download = l1l111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ嘱") in block
	if   l11l1111llll_l1_ and not download: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠩࠪ嘲")
	elif not l11l1111llll_l1_ and download: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ嘳"),l1ll_l1_[0]
	elif l11l1111llll_l1_ and download: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l111l1111_l1_,l11l1111ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ嘴"),l1l111_l1_ (u"ࠬ࠭嘵")
	if l11l1111llll_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ嘶"),l11l111l1111_l1_,l1l111_l1_ (u"ࠧࠨ嘷"),headers,l1l111_l1_ (u"ࠨࠩ嘸"),l1l111_l1_ (u"ࠩࠪ嘹"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ嘺"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡱ࡫ࡴࠡࡵࡨࡶࡻ࡫ࡲࡴࠪ࠱࠮ࡄ࠯ࡰ࡭ࡣࡼࡩࡷ࠭嘻"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嘼"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ嘽"),l1l111_l1_ (u"ࠧ࠰ࠩ嘾"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ嘿")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ噀")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ噁"),l11l1111ll1l_l1_,l1l111_l1_ (u"ࠫࠬ噂"),headers,l1l111_l1_ (u"ࠬ࠭噃"),l1l111_l1_ (u"࠭ࠧ噄"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ噅"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࡫ࡱࡪࡴ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ噆"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ噇"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ噈")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ噉")+l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ噊")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ噋"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ噌"),l1l111_l1_ (u"ࠨ࠭ࠪ噍"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭噎")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll11ll_l1_(url,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ噏"),l1l111_l1_ (u"ูࠫอ็ะࠢไ์ึ๐่ࠡ࠯ࠣࡗ࡭ࡧࡨࡪࡦࠣ࠸ࡺ࠭噐"),l1l111_l1_ (u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠴࡮ࡦࡶࠪ噑"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭噒"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ噓"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ噔"),url,l1l111_l1_ (u"ࠩࠪ噕"),headers,l1l111_l1_ (u"ࠪࠫ噖"),l1l111_l1_ (u"ࠫࠬ噗"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ噘"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡࡥࡸ࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ噙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡑࡶࡧࡵࡽࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࠬ噚"),block,re.DOTALL)
		l1111lll1_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111lll1_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂࡡࡹࠪࠩ࠰࠭ࡃ࠮ࡢࡳࠫ࠾ࠪ噛"),block,re.DOTALL)
	return items
def l1111l1l1_l1_(url):
	if l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭噜") not in url: url = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ噝")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ噞"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ噟"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ噠"),l1l111_l1_ (u"ࠧ࠰ࡁࠪ噡"))
	return url
l1111ll11_l1_ = [l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ噢"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ噣"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ噤"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭噥")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ噦"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ噧"),l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬ器")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ噩"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭噪"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ噫"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ噬"),l1l111_l1_ (u"ࠬ࠭噭")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ噮"))
	if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ噯"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪ噰") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫ噱") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ噲")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ噳")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ噴")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ噵")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ噶"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ噷")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ噸"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭噹"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ噺")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ噻"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ噼"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨ噽"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ噾"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪ噿"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嚀")+l11lll11_l1_
		l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚁"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ嚂"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚃"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ嚄")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ嚅"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ嚆"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嚇"),l1l111_l1_ (u"ࠫࠬ嚈"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"้ࠬไࠡࠩ嚉"),l1l111_l1_ (u"࠭ࠧ嚊"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠧ࠾ࠩ嚋") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ嚌"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭嚍")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚎"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ嚏"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚐"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ嚑"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠧࠨ嚒"),l1l111_l1_ (u"ࠨࠩ嚓"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ嚔"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ嚕")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ嚖")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ嚗")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ嚘")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ嚙")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嚚"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ嚛")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠪࠫ嚜"),l1l111_l1_ (u"ࠫࠬ嚝"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬ嚞"): option = l1l111_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭嚟")
			elif value==l1l111_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧ嚠"): option = l1l111_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪ嚡")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ嚢")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ嚣")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭嚤")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ嚥")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嚦")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ嚧")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪ嚨")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ嚩")+name
			if type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ嚪"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚫"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠬ࠭嚬"),l1l111_l1_ (u"࠭ࠧ嚭"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ嚮") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪ嚯") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ嚰"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嚱")+l11ll111_l1_
				l1llllll_l1_ = l1111l1l1_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚲"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚳"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"࠭ࠧ嚴"),l1l111_l1_ (u"ࠧࠨ嚵"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫ嚶"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭嚷"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬ嚸"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭嚹") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧ嚺"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨ嚻"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨ嚼")
	for key in l1111ll11_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪ嚽")
		if l1l111_l1_ (u"ࠩࠨࠫ嚾") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ嚿") and value!=l1l111_l1_ (u"ࠫ࠵࠭囀"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩ囁")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ囂") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ囃"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ囄")+key+l1l111_l1_ (u"ࠩࡀࠫ囅")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧ囆"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭囇")+key+l1l111_l1_ (u"ࠬࡃࠧ囈")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ囉"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ囊"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫ囋"),l1l111_l1_ (u"ࠩࡀࠫ囌"))
	return l1l1l111_l1_
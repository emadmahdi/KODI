# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ᥏")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫᥐ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭โศศ่ฮ๏࠭ᥑ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==300: l1lll_l1_ = l1l1l11_l1_()
	elif mode==301: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==302: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==303: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==304: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==305: l1lll_l1_ = PLAY(url)
	elif mode==306: l1lll_l1_ = l11111111_l1_()
	elif mode==309: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᥒ"),l1lllll_l1_+l1l111_l1_ (u"ࠨๆ่หีอࠠศๆ่์็฿ࠠษูํลࠬᥓ"),l1l111_l1_ (u"ࠩࠪᥔ"),306)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᥕ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᥖ"),l1l111_l1_ (u"ࠬ࠭ᥗ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᥘ"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᥙ"),l1l111_l1_ (u"ࠨࠩᥚ"),309,l1l111_l1_ (u"ࠩࠪᥛ"),l1l111_l1_ (u"ࠪࠫᥜ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᥝ"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᥞ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᥟ"),l1l111_l1_ (u"ࠧࠨᥠ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᥡ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨᥢ"),l1l111_l1_ (u"ࠪࠫᥣ"),l1l111_l1_ (u"ࠫࠬᥤ"),l1l111_l1_ (u"ࠬ࠭ᥥ"),l1l111_l1_ (u"࠭ࠧᥦ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᥧ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫ࡩࡦࡪࡥࡳࡀࠪᥨ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᥩ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬᥪ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥫ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᥬ")+l1lllll_l1_+title,l1ll1ll_l1_,301)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᥭ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᥮"),l1l111_l1_ (u"ࠨࠩ᥯"),9999)
	l11ll1_l1_(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨᥰ"),html)
	return html
def l11111111_l1_():
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫᥱ"),l1l111_l1_ (u"ࠫࠬᥲ"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᥳ"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศ้ࠢหํࠦศุ์ฤࠤ๊์ࠠศๆู่ิืࠠ࠯࠰ࠣฬุฮศࠡไํห๊ࠦรึฯสฬࠥอไๆ๊ๅ฽ࠥฮสีใํี๋ࠥอห๊ํหฯࠦฬๆ์฼ࠤฺ็อศฬࠣห้๋่ใ฻ࠣ࠲࠳่ࠦศๆ๋ๆฯࠦวๅุสส฾๊ࠦั้หࠤๆ๐ࠠๆ฻ส่ัฯࠠหึไ๎ึࠦวๅืไัฬะࠠศๆุ่ๆืษࠡไห่ࠥ฿ัื่ࠢัฯ๎๊ศฬ๊หࠥ็๊ࠡไ๋หห๋่ࠠาสࠤฬ๊ศา่ส้ั࠭ᥴ"))
	return
def l11ll1_l1_(url,html=l1l111_l1_ (u"ࠧࠨ᥵")):
	if not html:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ᥶"),url,l1l111_l1_ (u"ࠩࠪ᥷"),l1l111_l1_ (u"ࠪࠫ᥸"),l1l111_l1_ (u"ࠫࠬ᥹"),l1l111_l1_ (u"ࠬ࠭᥺"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ᥻"))
		html = response.content
	seq = 0
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠾ࡶࡩࡨࡺࡩࡰࡰࡁ࠲࠯ࡅ࠼࠰ࡵࡨࡧࡹ࡯࡯࡯ࡀࠬࠫ᥼"),html,re.DOTALL)
	if l11llll_l1_:
		for block in l11llll_l1_:
			seq += 1
			items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡩࡨࡺࡩࡰࡰࡁ࠲ࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᥽"),block,re.DOTALL)
			for title,test,l1ll1ll_l1_ in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ᥾"))
				if title==l1l111_l1_ (u"ࠪࠫ᥿"): title = l1l111_l1_ (u"ࠫอ๎่้๊๋ࠫᦀ")
				if l1l111_l1_ (u"ࠬ࡫࡭࠿࠾ࡤࠫᦁ") not in test:
					if block.count(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪᦂ"))>0:
						l1llllllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᦃ"),block,re.DOTALL)
						for l1ll1ll_l1_ in l1llllllll_l1_:
							title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪᦄ"))[-2]
							addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᦅ"),l1lllll_l1_+title,l1ll1ll_l1_,301)
						continue
					else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᦆ")+str(seq)
				if not any(value in title for value in l11lll_l1_):
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦇ"),l1lllll_l1_+title,l1ll1ll_l1_,302)
	else: l1lll11_l1_(url,html)
	return
def l1lll11_l1_(url,html=l1l111_l1_ (u"ࠬ࠭ᦈ")):
	if html==l1l111_l1_ (u"࠭ࠧᦉ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᦊ"),url,l1l111_l1_ (u"ࠨࠩᦋ"),l1l111_l1_ (u"ࠩࠪᦌ"),l1l111_l1_ (u"ࠪࠫᦍ"),l1l111_l1_ (u"ࠫࠬᦎ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᦏ"))
		html = response.content
	if l1l111_l1_ (u"࠭࠿ࡴࡧࡴࡹࡪࡴࡣࡦ࠿ࠪᦐ") in url:
		url,seq = url.split(l1l111_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫᦑ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳࠰࠿࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁ࠭ࠬᦒ"),html,re.DOTALL)
		block = l11llll_l1_[int(seq)-1]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡴࡹࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡳࡩࡿ࠾ࠨᦓ"),html,re.DOTALL)
		block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡦ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᦔ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,data,l1ll1l_l1_ in items:
		title = re.findall(l1l111_l1_ (u"ࠫࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠯ࠬࡂࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࡦ࡯ࡁࠫᦕ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨᦖ"),l1l111_l1_ (u"࠭ࠧᦗ")).strip(l1l111_l1_ (u"ࠧࠡࠩᦘ"))
		if not title or title==l1l111_l1_ (u"ࠨࠩᦙ"):
			title = re.findall(l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠣࡀ࠱࠮ࡄࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᦚ"),data,re.DOTALL)
			if title: title = title[0].replace(l1l111_l1_ (u"ࠪࡠࡳ࠭ᦛ"),l1l111_l1_ (u"ࠫࠬᦜ")).strip(l1l111_l1_ (u"ࠬࠦࠧᦝ"))
			if not title or title==l1l111_l1_ (u"࠭ࠧᦞ"):
				title = re.findall(l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᦟ"),data,re.DOTALL)
				title = title[0].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫᦠ"),l1l111_l1_ (u"ࠩࠪᦡ")).strip(l1l111_l1_ (u"ࠪࠤࠬᦢ"))
		title = unescapeHTML(title)
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l1l1l1l_l1_ = l1ll1ll_l1_+data+l1ll1l_l1_
			if l1l111_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭ᦣ") in l1l1l1l_l1_ or l1l111_l1_ (u"๋ࠬำๅี็ࠫᦤ") in l1l1l1l_l1_ or l1l111_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࠣࠩᦥ") in l1l1l1l_l1_:
				if l1l111_l1_ (u"ࠧษำส้ั࠭ᦦ") in data: title = l1l111_l1_ (u"ࠨสิ๊ฬ๋ฬࠡࠩᦧ")+title
				elif l1l111_l1_ (u"่ࠩืู้ไࠨᦨ") in data or l1l111_l1_ (u"้ࠪํูๅࠨᦩ") in data: title = l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫᦪ")+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦫ"),l1lllll_l1_+title,l1ll1ll_l1_,303,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᦬"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ᦭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᦮"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᦯"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩᦰ")+title,l1ll1ll_l1_,302)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᦱ"),url,l1l111_l1_ (u"ࠬ࠭ᦲ"),l1l111_l1_ (u"࠭ࠧᦳ"),l1l111_l1_ (u"ࠧࠨᦴ"),l1l111_l1_ (u"ࠨࠩᦵ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡗࡊࡇࡓࡐࡐࡖ࠱࠶ࡹࡴࠨᦶ"))
	html = response.content
	name = re.findall(l1l111_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸ࡮ࡺ࡬ࡦࡀࠪᦷ"),html,re.DOTALL)
	name = name[0].replace(l1l111_l1_ (u"ࠫࢁࠦำ๋็สࠤ๋อ่ࠨᦸ"),l1l111_l1_ (u"ࠬ࠭ᦹ")).replace(l1l111_l1_ (u"࠭ࡃࡪ࡯ࡤࠤࡓࡵࡷࠨᦺ"),l1l111_l1_ (u"ࠧࠨᦻ")).strip(l1l111_l1_ (u"ࠨࠢࠪᦼ")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬᦽ"),l1l111_l1_ (u"ࠪࠤࠬᦾ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡢࡵࡲࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨᦿ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᧀ"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩᧁ"),l1l111_l1_ (u"ࠧࠨᧂ")).strip(l1l111_l1_ (u"ࠨࠢࠪᧃ"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᧄ"),l1lllll_l1_+title,l1ll1ll_l1_,304)
		else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬᧅ") not in url: url = url.strip(l1l111_l1_ (u"ࠫ࠴࠭ᧆ"))+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࡮ࡴࡧࠨᧇ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᧈ"),url,l1l111_l1_ (u"ࠧࠨᧉ"),l1l111_l1_ (u"ࠨࠩ᧊"),l1l111_l1_ (u"ࠩࠪ᧋"),l1l111_l1_ (u"ࠪࠫ᧌"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ᧍"))
	html = response.content
	if l1l111_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧ᧎") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᧏"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᧐"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ᧑"),l1l111_l1_ (u"ࠩࠪ᧒")).strip(l1l111_l1_ (u"ࠪࠤࠬ᧓"))
			title = l1l111_l1_ (u"ࠫฬ๊อๅไฬࠤࠬ᧔")+title
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᧕"),l1lllll_l1_+title,l1ll1ll_l1_,305)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡧࡷࡥ࡮ࡲࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠩ᧖"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᧗"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ᧘"),l1l111_l1_ (u"ࠩࠪ᧙")).strip(l1l111_l1_ (u"ࠪࠤࠬ᧚"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᧛"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫࡭ࡳ࡭࠯ࠨ᧜")
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ᧝"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ᧞"),l1l111_l1_ (u"ࠨࠩ᧟"),l1l111_l1_ (u"ࠩࠪ᧠"),l1l111_l1_ (u"ࠪࠫ᧡"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧ᧢"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᧣"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᧤"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ᧥"),l1l111_l1_ (u"ࠨࠩ᧦")).strip(l1l111_l1_ (u"ࠩࠣࠫ᧧"))
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ᧨"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ᧩")+l111l1ll_l1_[0]
				title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ᧪"))
			else: l111l1ll_l1_ = l1l111_l1_ (u"࠭ࠧ᧫")
			l111lllll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᧬")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ᧭")+l111l1ll_l1_
			l1llll_l1_.append(l111lllll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡻࡦࡺࡣࡩࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᧮"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠴࠵࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ᧯"),block,re.DOTALL)
		for l1ll1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ᧰")+l1ll1ll_l1_
			title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ᧱"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ᧲")+title+l1l111_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ᧳")
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽࡢࠨࡼࡷࡵࡰ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᧴"),html,re.DOTALL)
		if l1ll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡰࡧࡩࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ᧵"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭᧶"),l1l111_l1_ (u"ࠫࠬ᧷")).strip(l1l111_l1_ (u"ࠬࠦࠧ᧸"))
				title = title.replace(l1l111_l1_ (u"࠭ࡃࡪ࡯ࡤࠤࡓࡵࡷࠨ᧹"),l1l111_l1_ (u"ࠧࡄ࡫ࡰࡥࡓࡵࡷࠨ᧺"))
				l1ll1ll_l1_ = l1ll_l1_[0]+l1l111_l1_ (u"ࠨࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡻ࡮ࡺࡣࡩࠨ࡬ࡲࡩ࡫ࡸ࠾ࠩ᧻")+index+l1l111_l1_ (u"ࠩࠩ࡭ࡩࡃࠧ᧼")+id+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᧽")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ᧾")
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᧿"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧᨀ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨᨁ"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪᨂ"),l1l111_l1_ (u"ࠩ࠮ࠫᨃ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨᨄ")+search
	l1lll11_l1_(url)
	return
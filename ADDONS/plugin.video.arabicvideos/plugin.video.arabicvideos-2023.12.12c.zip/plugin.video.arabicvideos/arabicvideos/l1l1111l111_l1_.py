# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㱶")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡐࡉࡔ࡟ࠨ㱷")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ㱸"),l1l111_l1_ (u"ࠫฬูสโีสีฯ้ๅ๊ࠡࠣห้฽ไษษอࠫ㱹")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㱺"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ㱻"),l1l111_l1_ (u"ࠧࠨ㱼"),l1l111_l1_ (u"ࠨࠩ㱽"),l1l111_l1_ (u"ࠩࠪ㱾"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㱿"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㲀"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲁"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㲂"),l1l111_l1_ (u"ࠧࠨ㲃"),459,l1l111_l1_ (u"ࠨࠩ㲄"),l1l111_l1_ (u"ࠩࠪ㲅"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㲆"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲇"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㲈")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅฬสอหฯࠦไ้ัํࠤ๋ะࠧ㲉"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠧࠨ㲊"),l1l111_l1_ (u"ࠨࠩ㲋"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㲌"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲍"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㲎")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ㲏"),l1l11ll_l1_,451,l1l111_l1_ (u"࠭ࠧ㲐"),l1l111_l1_ (u"ࠧࠨ㲑"),l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㲒"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㲓"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㲔"),l1l111_l1_ (u"ࠫࠬ㲕"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࠢࡔ࡫ࡷࡩࡘࡲࡩࡥࡧࡵࠦࠬ㲖"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㲗"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ㲘"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲙"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㲚")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠪࠫ㲛")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㲜"),url,l1l111_l1_ (u"ࠬ࠭㲝"),l1l111_l1_ (u"࠭ࠧ㲞"),l1l111_l1_ (u"ࠧࠨ㲟"),l1l111_l1_ (u"ࠨࠩ㲠"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ㲡"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㲢"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡹࡤࡺࡪࡹࠢࠨ㲣"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㲤"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡓࡧࡦࡩࡳࡺࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ㲥"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭㲦") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㲧"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࠨࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㲨"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"ࠪ࠴ࠬ㲩"),l1l111_l1_ (u"ࠫ࠶࠭㲪"),l1l111_l1_ (u"ࠬ࠸ࠧ㲫")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀࠪ㲬"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㲭"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ㲮"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ㲯"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ㲰"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ㲱"),l1l111_l1_ (u"ࠬษฺ็์ฬࠫ㲲"),l1l111_l1_ (u"࠭ใๅ์หࠫ㲳"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭㲴"),l1l111_l1_ (u"ࠨ้าหๆ࠭㲵"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ㲶"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ㲷"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ㲸"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ㲹")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ㲺") in html and l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠬ㲻") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㲼"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫ㲽"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ㲾"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ㲿"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"๋ࠬำๅี็ࠫ㳀") not in title:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㳁"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧฮๆๅอࠬ㳂") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㳃") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳄"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㳅"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠫࠬ㳆"),l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㳇")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㳈"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㳉"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㳊"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ㳋")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㳌"),url,l1l111_l1_ (u"ࠫࠬ㳍"),l1l111_l1_ (u"ࠬ࠭㳎"),l1l111_l1_ (u"࠭ࠧ㳏"),l1l111_l1_ (u"ࠧࠨ㳐"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧ㳑"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡇࡦࡺࡥࡨࡱࡵࡽࡘࡻࡢࡍ࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㳒"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩ㳓") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠰ࠫ㳔"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"ࠬࠦࠧ㳕"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳖"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㳗"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㳘"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㳙"),url,l1l111_l1_ (u"ࠪࠫ㳚"),l1l111_l1_ (u"ࠫࠬ㳛"),l1l111_l1_ (u"ࠬ࠭㳜"),l1l111_l1_ (u"࠭ࠧ㳝"),l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㳞"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㳟"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ㳠"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㳡"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㳢"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㳣"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳤"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭㳥")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ㳦"),l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ㳧"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㳨"),l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㳩"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㳪"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ㳫"),l1l111_l1_ (u"ࠧࠨ㳬"),l1l111_l1_ (u"ࠨࠩ㳭"),l1l111_l1_ (u"ࠩࠪ㳮"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㳯"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㳰"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬࡙࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡸ࡯ࡤࡦࡀࠪ㳱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ㳲"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㳳")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㳴")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪࠤࡶࡩࡱࡧࡲࡺࠤࠪ㳵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ㳶"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ㳷"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ㳸")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"࠭ࠧ㳹")
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ㳺")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㳻")+name+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㳼")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㳽"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ㳾"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭㳿"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ㴀"),l1l111_l1_ (u"ࠧࠬࠩ㴁"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ㴂")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ妌")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭妍")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠨ妎"),l1l111_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ妏")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ妐"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ妑"),l1l111_l1_ (u"ࠬ࠭妒"),l1l111_l1_ (u"࠭ࠧ妓"),l1l111_l1_ (u"ࠧࠨ妔"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ妕"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ妖"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬ妗"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ妘"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妙"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭妚"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠧࠨ妛"),l1l111_l1_ (u"ࠨࠩ妜"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭妝"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ妞"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ妟"),l1l111_l1_ (u"ࠬ࠭妠"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妡"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ妢")+l1lllll_l1_+l1l111_l1_ (u"ࠨละำะࠦวๅ็๋ห฻๐ูࠨ妣"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨ࡭ࡺࡃࡦࡧࡴࡻ࡮ࡵࠤࠪ妤"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ妥"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭妦"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妧"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ妨")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l111llllll11_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ妩"),url,l1l111_l1_ (u"ࠨࠩ妪"),l1l111_l1_ (u"ࠩࠪ妫"),l1l111_l1_ (u"ࠪࠫ妬"),l1l111_l1_ (u"ࠫࠬ妭"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ妮"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡱࡶࡸ࠭࠴ࠪࡀࠫࠥࡪࡴࡵࡴࡦࡴࠥࠫ妯"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭妰"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ妱"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ妲"),l1l111_l1_ (u"ࠪห฿์๊สࠩ妳"),l1l111_l1_ (u"ࠫศเๆ๋หࠪ妴"),l1l111_l1_ (u"้ࠬไ๋สࠪ妵"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ妶"),l1l111_l1_ (u"่ࠧัสๅࠬ妷"),l1l111_l1_ (u"ࠨ็หหึอษࠨ妸"),l1l111_l1_ (u"ࠩ฼ี฻࠭妹"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ妺"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ妻"),l1l111_l1_ (u"๋ࠬำาฯํอࠬ妼")]
	l111llllll1l_l1_ = l1l111_l1_ (u"࠭࠯ࠨ妽").join(l111llllll11_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ妾")).split(l1l111_l1_ (u"ࠨ࠱ࠪ妿"))[4:]).split(l1l111_l1_ (u"ࠩ࠰ࠫ姀"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ姁"),title,re.DOTALL)
		if l111llllll11_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠫ࠴࠭姂").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ姃")).split(l1l111_l1_ (u"࠭࠯ࠨ姄"))[4:]).split(l1l111_l1_ (u"ࠧ࠮ࠩ姅"))
			l111lllllll1_l1_ = len([x for x in l111llllll1l_l1_ if x in l111lllll_l1_])
			if l111lllllll1_l1_>2 and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ姆") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ姇"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭姈"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ู๊ࠫไิๆࠪ姉") not in title:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ姊"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ始") in title:
				title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭姌") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姍"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ姎"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姏"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ姐"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠣ姑"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ姒"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠧศๆุๅาฯࠠࠨ姓"),l1l111_l1_ (u"ࠨࠩ委"))
			if title!=l1l111_l1_ (u"ࠩࠪ姕"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姖"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ姗")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠬ࠭姘"),l1l111_l1_ (u"࠭ࠧ姙"),l111llllll11_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ姚"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ姛")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭姜"),url,l1l111_l1_ (u"ࠪࠫ姝"),headers,l1l111_l1_ (u"ࠫࠬ姞"),l1l111_l1_ (u"ࠬ࠭姟"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ姠"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ姡"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡱ࡬࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ姢"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪ姣"))
	l111lllll1ll_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡱ࡯ࡳࡵࡕࡨࡥࡸࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ姤"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ姥") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠩ姦"))
		if count==0: count = block.count(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠬ姧"))
		if count>1:
			l111lllll1ll_l1_ = False
			if l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦࠬ姨") in block:
				items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ姩"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠶࠳ࡶࡨࡱࡁࡶࡰࡺ࡭࠽ࠨ姪")+id
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姫"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡦࡹ࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ姬"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠮ࡱࡪࡳࡃࡸ࡫ࡲࡪࡧࡶࡍࡉࡃࠧ姭")+id
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姮"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l111lllll1ll_l1_:
		block = l1l111_l1_ (u"ࠧࠨ姯")
		if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ姰") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡵࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ姱"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ姲"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭姳"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ姴"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"࠭࠯ࠨ姵"))+l1l111_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡽࡡࡵࡥ࡫ࠫ姶")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ姷"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ姸"),l1l111_l1_ (u"ࠪࠫ姹"),l1l111_l1_ (u"ࠫࠬ姺"),l1l111_l1_ (u"ࠬ࠭姻"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ姼"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ姽"))
	l11111lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡲࡣࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姾"),html,re.DOTALL)
	if not l11111lll_l1_: l11111lll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࠬࡹ࡮ࡩࡴ࡞࠱࡭ࡩࡢࠬ࠱࡞࠯ࠬ࠳࠰࠿ࠪ࡞ࠬࠫ姿"),html,re.DOTALL)
	l11111lll_l1_ = l11111lll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭娀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ威"),block,re.DOTALL)
		for l11111ll1_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ娂"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡪࡨࡵࡥࡲ࡫࠲࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩ娃")+l11111lll_l1_+l1l111_l1_ (u"ࠧࠧࡸ࡬ࡨࡪࡵ࠽ࠨ娄")+l11111ll1_l1_[2:]+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ娅")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ娆")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡬࡫ࡴࡆ࡯ࡥࡩࡩࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ娇"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ娈"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭娉")+title+l1l111_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧ娊")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩ娋"))+l1l111_l1_ (u"ࠨ࠱ࡂࡨࡴࡃࡤࡰࡹࡱࡰࡴࡧࡤࠨ娌")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭娍"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ娎"),l1l111_l1_ (u"ࠫࠬ娏"),l1l111_l1_ (u"ࠬ࠭娐"),l1l111_l1_ (u"࠭ࠧ娑"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ娒"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡷࡥࡧࡲࡥ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ娓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ娔"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ娕"))
			if l1l111_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ娖") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ฯษุࠫ娗")
			else: l1lllllll_l1_ = l1l111_l1_ (u"࠭ࠧ娘")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ娙")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ娚")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ娛"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠪࠫ娜")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ娝"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭娞"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ娟"),l1l111_l1_ (u"ࠧࠬࠩ娠"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠨࠩ娡"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ娢")+search+l1l111_l1_ (u"ࠪ࠳ࠬ娣")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࠬ娤"))
	return
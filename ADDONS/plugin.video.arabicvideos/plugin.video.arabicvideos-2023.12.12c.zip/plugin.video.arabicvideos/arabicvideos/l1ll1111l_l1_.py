# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨฑ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪฒ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==730: l1lll_l1_ = l1l1l11_l1_()
	elif mode==731: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==732: l1lll_l1_ = PLAY(url)
	elif mode==733: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==734: l1lll_l1_ = l1l1lll1l_l1_(url)
	elif mode==735: l1lll_l1_ = l1l1lllll_l1_(url)
	elif mode==739: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬณ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ด"),l1l111_l1_ (u"ࠧࠨต"),739,l1l111_l1_ (u"ࠨࠩถ"),l1l111_l1_ (u"ࠩࠪท"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧธ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩน"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬบ"),l1l111_l1_ (u"࠭ࠧป"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧผ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪฝ")+l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩพ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡹࡵࡰ࠯ࡲ࡫ࡴࠬฟ"),735)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫภ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧม")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠧย"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡥࡤࡶࡹࡵ࡯࡯࠰ࡳ࡬ࡵ࠭ร"),734)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨฤ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫล")+l1lllll_l1_+l1l111_l1_ (u"ࠪหๆ๊วๆࠩฦ"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠳ࡶࡨࡱࠩว"),731)
	return
def l1l1lll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬศ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅๅ็ࠫษ"),url,731)
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫส"),url,l1l111_l1_ (u"ࠨࠩห"),l1l111_l1_ (u"ࠩࠪฬ"),l1l111_l1_ (u"ࠪࠫอ"),l1l111_l1_ (u"ࠫࠬฮ"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡗࡊࡘࡉࡆࡕࡢࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨฯ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡬ࡢࡤࡨࡰࡂࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧะ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤั"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪา")+l1ll1ll_l1_
			title = l1l111_l1_ (u"ࠩะีๆࠦࠧำ")+title
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪิ"),l1lllll_l1_+title,l1ll1ll_l1_,731)
	return
def l1l1lllll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨี"),url,l1l111_l1_ (u"ࠬ࠭ึ"),l1l111_l1_ (u"࠭ࠧื"),l1l111_l1_ (u"ࠧࠨุ"),l1l111_l1_ (u"ࠨูࠩ"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡔࡇࡕࡍࡊ࡙࡟ࡇࡇࡄࡘ࡚ࡘࡅࡅ࠯࠵ࡲࡩฺ࠭"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ฻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ฼"),block,re.DOTALL)
		for title,l1ll1ll_l1_,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ฽")+l1ll1ll_l1_
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ฾")+l1ll1l_l1_
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ฿"))
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨเ"),l1lllll_l1_+title,l1ll1ll_l1_,733,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭แ"),url,l1l111_l1_ (u"ࠪࠫโ"),l1l111_l1_ (u"ࠫࠬใ"),l1l111_l1_ (u"ࠬ࠭ไ"),l1l111_l1_ (u"࠭ࠧๅ"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩๆ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨ࡯ࡲࡺ࡮࡫ࡳࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣ็"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡳࡻ࡯ࡥࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡁ่ࠫ"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳้ࠬ")+l1ll1ll_l1_
		l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴๊࠭")+l1ll1l_l1_
		title = title.strip(l1l111_l1_ (u"๋ࠬࠦࠧ"))
		if l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠴ࡰࡩࡲࠪ์") in url: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ํ"),l1lllll_l1_+title,l1ll1ll_l1_,732,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ๎"),l1lllll_l1_+title,l1ll1ll_l1_,733,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ๏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ๐"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭๑")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ๒"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭๓"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭๔")+title,l1ll1ll_l1_,731)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ๕"),url,l1l111_l1_ (u"ࠩࠪ๖"),l1l111_l1_ (u"ࠪࠫ๗"),l1l111_l1_ (u"ࠫࠬ๘"),l1l111_l1_ (u"ࠬ࠭๙"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ๚"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧ࡮ࡱࡹ࡭ࡪࡹࡂ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࡷࡨࡸࡩࡱࡶࠥ๛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡲࡺ࡮࡫ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡂࠬ๜"),block,re.DOTALL)
		for title,l1ll1ll_l1_,l1ll1l_l1_,l1l1llll1_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ๝")+l1ll1ll_l1_
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ๞")+l1ll1l_l1_
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭๟"))
			title = title+l1l111_l1_ (u"ࠬࠦࠧ๠")+l1l1llll1_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ๡"))
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭๢"),l1lllll_l1_+title,l1ll1ll_l1_,732,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ๣"),url,l1l111_l1_ (u"ࠩࠪ๤"),l1l111_l1_ (u"ࠪࠫ๥"),l1l111_l1_ (u"ࠫࠬ๦"),l1l111_l1_ (u"ࠬ࠭๧"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭๨"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ๩"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ๪") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱࠬ๫")
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ๬"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ๭"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭๮"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ๯"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ๰"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ๱"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠩࠪ๲"),l1l111_l1_ (u"ࠪࡱࠬ๳")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆสฮࠬ๴"),l1l111_l1_ (u"ࠬอแๅษ่ࠫ๵")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๆ้฻ࠣห้๋ืๅ๊ห࠾ࠬ๶"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	type = l1llll_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡮࡬ࡺࡪࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ๷")+type+l1l111_l1_ (u"ࠨࠨࡴࡁࠬ๸")+search
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭๹"),url,l1l111_l1_ (u"ࠪࠫ๺"),l1l111_l1_ (u"ࠫࠬ๻"),l1l111_l1_ (u"ࠬ࠭๼"),l1l111_l1_ (u"࠭ࠧ๽"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ๾"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ๿"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ຀")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬກ"))
		if type==l1l111_l1_ (u"ࠫࡲ࠭ຂ"): addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ຃"),l1lllll_l1_+title,l1ll1ll_l1_,732)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ຄ"),l1lllll_l1_+title,l1ll1ll_l1_,733)
	return
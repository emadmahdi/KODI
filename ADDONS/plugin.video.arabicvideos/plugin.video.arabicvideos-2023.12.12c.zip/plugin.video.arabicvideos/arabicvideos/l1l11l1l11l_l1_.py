# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡍࡋࡅࡗࡔࡔࡅࠨㆌ")
l1l1l1lll1l_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠨࡲࡤࡸ࡭࠭ㆍ"))
l1l11l1111l_l1_ = os.path.join(l1l1l1lll1l_l1_,l1l111_l1_ (u"ࠩࡳࡥࡨࡱࡡࡨࡧࡶࠫㆎ"))
sys.path.append(l1l11l1111l_l1_)
l1l1l1l11ll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡆࡺ࡯࡬ࡥࡘࡨࡶࡸ࡯࡯࡯ࠤ㆏"))
kodi_version = re.findall(l1l111_l1_ (u"ࠫ࠭ࡢࡤ࡝ࡦ࡟࠲ࡡࡪࠩࠨ㆐"),l1l1l1l11ll_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1ll1ll11_l1_ = xbmc.Player
l1l1ll11l1l_l1_ = xbmcgui.WindowXMLDialog
if kodi_version>18.99:
	l1ll111l11l_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭㆑"),l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ㆒")
	l1l1l11l1l1_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ㆓"))
	from urllib.parse import unquote as _1l1l1l11l1_l1_
else:
	l1ll111l11l_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩ㆔").encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㆕")),l1l111_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫ㆖").encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㆗"))
	l1l1l11l1l1_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭㆘"))
	from urllib import unquote as _1l1l1l11l1_l1_
l1l1lll1l11_l1_ = 60
l1l1l11l111_l1_ = 60*l1l1lll1l11_l1_
l1l1l111l11_l1_ = 24*l1l1l11l111_l1_
l1l1ll1llll_l1_ = 30*l1l1l111l11_l1_
l1ll1ll1_l1_ = 3*l1l1l111l11_l1_
l1ll111l1l1_l1_ = 12*l1l1ll1llll_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"࠭࠯ࠨ㆙"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1llll11l_l1_ = addon_id.split(l1l111_l1_ (u"ࠧ࠯ࠩ㆚"))[2]
l1l11l1llll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡖࡦࡴࡶ࡭ࡴࡴࠨࠨ㆛")+addon_id+l1l111_l1_ (u"ࠩࠬࠫ㆜"))
addoncachefolder = os.path.join(l1l1l11l1l1_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࡥࡣࡷࡥ࠳ࡪࡢࠨ㆝"))
l1l1l11llll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫࡱࡧࡳࡵࡸ࡬ࡨࡪࡵࡳ࠯ࡦࡤࡸࠬ㆞"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url):
	if l1l111_l1_ (u"ࠬࡃࠧ㆟") in url:
		if l1l111_l1_ (u"࠭࠿ࠨㆠ") in url: l1lllll1_l1_,filters = url.split(l1l111_l1_ (u"ࠧࡀࠩㆡ"),1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"ࠨࠩㆢ"),url
		filters = filters.split(l1l111_l1_ (u"ࠩࠩࠫㆣ"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠪࡁࠬㆤ"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l1l11l1_l1_(urll)
def EXTRACT_KODI_PATH(l1l11l11lll_l1_):
	l1l1ll1l1ll_l1_ = {l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩㆥ"):l1l111_l1_ (u"ࠬ࠭ㆦ"),l1l111_l1_ (u"࠭࡭ࡰࡦࡨࠫㆧ"):l1l111_l1_ (u"ࠧࠨㆨ"),l1l111_l1_ (u"ࠨࡷࡵࡰࠬㆩ"):l1l111_l1_ (u"ࠩࠪㆪ"),l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨㆫ"):l1l111_l1_ (u"ࠫࠬㆬ"),l1l111_l1_ (u"ࠬࡶࡡࡨࡧࠪㆭ"):l1l111_l1_ (u"࠭ࠧㆮ"),l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬㆯ"):l1l111_l1_ (u"ࠨࠩㆰ"),l1l111_l1_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨㆱ"):l1l111_l1_ (u"ࠪࠫㆲ"),l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬㆳ"):l1l111_l1_ (u"ࠬ࠭ㆴ"),l1l111_l1_ (u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨㆵ"):l1l111_l1_ (u"ࠧࠨㆶ")}
	if l1l111_l1_ (u"ࠨࡁࠪㆷ") in l1l11l11lll_l1_: l1l11l11lll_l1_ = l1l11l11lll_l1_.split(l1l111_l1_ (u"ࠩࡂࠫㆸ"),1)[1]
	l1lllll1_l1_,l1ll11111l1_l1_ = l1ll11ll1_l1_(l1l11l11lll_l1_)
	args = dict(list(l1l1ll1l1ll_l1_.items())+list(l1ll11111l1_l1_.items()))
	l1l11l111l1_l1_ = args[l1l111_l1_ (u"ࠪࡱࡴࡪࡥࠨㆹ")]
	l1l1l1ll11l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨㆺ")])
	l1l1l1111l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪㆻ")])
	l1l111ll1ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭ࡰࡢࡩࡨࠫㆼ")])
	l1l111ll1l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠧࡵࡻࡳࡩࠬㆽ")])
	l1l1l1111ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭ㆾ")])
	l1l1ll11lll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨㆿ")])
	l1l1l111111_l1_ = args[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ㇀")]
	l1l1l1l1111_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭㇁")])
	if l1l1l1l1111_l1_: l1l1l1l1111_l1_ = eval(l1l1l1l1111_l1_)
	else: l1l1l1l1111_l1_ = {}
	if not l1l11l111l1_l1_: l1l111ll1l1_l1_ = l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㇂") ; l1l11l111l1_l1_ = l1l111_l1_ (u"࠭࠲࠷࠲ࠪ㇃")
	return l1l111ll1l1_l1_,l1l1l1111ll_l1_,l1l1l1ll11l_l1_,l1l11l111l1_l1_,l1l1ll11lll_l1_,l1l111ll1ll_l1_,l1l1l1111l1_l1_,l1l1l111111_l1_,l1l1l1l1111_l1_
def l11lllll11_l1_(l1ll1_l1_):
	l1l1l11111l_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l1l11111l_l1_ or l1l1l11111l_l1_==l1l111_l1_ (u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩ㇄"):
		return l1l111_l1_ (u"ࠨ࡝ࠣࠫ㇅")+l1l1llll11l_l1_.upper()+l1l111_l1_ (u"ࠩ࠰ࠫ㇆")+l1l11l1llll_l1_+l1l111_l1_ (u"ࠪ࠱ࠬ㇇")+str(kodi_version)+l1l111_l1_ (u"ࠫࠥࡣࠧ㇈")
	return l1l111_l1_ (u"ࠬ࠴ࠠࠡࠩ㇉")+l1l1l11111l_l1_
def l1l111111l_l1_(level,message):
	if kodi_version<19: message = message.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㇊")).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㇋"))
	l1l11ll111l_l1_ = l1ll111l11l_l1_
	lines = [l1l111_l1_ (u"ࠨࠩ㇌"),l1l111_l1_ (u"ࠩࠪ㇍")]
	if level: message = message.replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㇎"),l1l111_l1_ (u"ࠫࠬ㇏")).replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㇐"),l1l111_l1_ (u"࠭ࠧ㇑")).replace(l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㇒"),l1l111_l1_ (u"ࠨࠩ㇓"))
	else: level = l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㇔")
	l11ll11111_l1_,sep,shift = l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ㇕"),l1l111_l1_ (u"ࠫࠥࠦࠠࠨ㇖"),l1l111_l1_ (u"ࠬ࠭㇗")
	if l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㇘") in level: l1l11ll111l_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㇙"):
		message = message+sep
		lines = message.split(sep)
		shift = l11ll11111_l1_
	elif level==l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㇚"):
		message = message.replace(l1l111_l1_ (u"ࠩ࠱ࠫ㇛")+sep,l1l111_l1_ (u"ࠪ࠲ࠥࠦࠧ㇜"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"ࠫ࠳࠭㇝")+lines[0][1:]
		shift = l11ll11111_l1_+sep
	elif level in [l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㇞"),l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㇟")]: lines = message.split(l11ll11111_l1_)
	shift += 6*l11ll11111_l1_
	l1l11ll1l11_l1_ = 3*l11ll11111_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"ࠧࠡࠩ㇠")
	l1l1ll1lll1_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"ࠨ࡞ࡱࠫ㇡") in line: line = line.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㇢"),l1l111_l1_ (u"ࠪࡠࡳ࠭㇣")+l11ll11111_l1_+l11ll11111_l1_)
		l1l11ll1l11_l1_ += l11ll11111_l1_
		l1l1ll1lll1_l1_ += l1l111_l1_ (u"ࠫࡡࡸࠧ㇤")+shift+l1l11ll1l11_l1_+line
	l1l1ll1lll1_l1_ += l1l111_l1_ (u"ࠬࠦ࡟ࠨ㇥")
	if l1l111_l1_ (u"࠭ࠥࠨ㇦") in l1l1ll1lll1_l1_: l1l1ll1lll1_l1_ = l111l11_l1_(l1l1ll1lll1_l1_)
	xbmc.log(l1l1ll1lll1_l1_,level=l1l11ll111l_l1_)
	return
def l1l1llll1ll_l1_(l1lll11111_l1_):
	conn = sqlite3.connect(l1lll11111_l1_)
	l1lllll1l1_l1_ = conn.cursor()
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡢࡷࡷࡳࡲࡧࡴࡪࡥࡢ࡭ࡳࡪࡥࡹ࠿ࡱࡳࡀ࠭㇧"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫ㇨"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬࡫ࡳࡵࡲࡦࡡࡦ࡬ࡪࡩ࡫ࡠࡥࡲࡲࡸࡺࡲࡢ࡫ࡱࡸࡸࡃࡹࡦࡵ࠾ࠫ㇩"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡮ࡴࡻࡲ࡯ࡣ࡯ࡣࡲࡵࡤࡦ࠿ࡒࡊࡋࡁࠧ㇪"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤࡹ࡫࡭ࡱࡡࡶࡸࡴࡸࡥ࠾ࡏࡈࡑࡔࡘ࡙࠼ࠩ㇫"))
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡹࡹ࡯ࡥ࡫ࡶࡴࡴ࡯ࡶࡵࡀࡓࡋࡌ࠻ࠨ㇬"))
	conn.text_factory = str
	return conn,l1lllll1l1_l1_
def l1lll1ll111_l1_(l1lll11111_l1_,table,l1l1l1l1l1l_l1_=None):
	try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
	except: return
	if l1l1l1l1l1l_l1_==None: l1lllll1l1_l1_.execute(l1l111_l1_ (u"࠭ࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ㇭")+table+l1l111_l1_ (u"ࠧࠣࠢ࠾ࠫ㇮"))
	else:
		tt = (str(l1l1l1l1l1l_l1_),)
		try:
			if l1l111_l1_ (u"ࠨࠧࠪ㇯") in l1l1l1l1l1l_l1_: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩㇰ")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡱ࡯࡫ࡦࠢࡂࠤࡀ࠭ㇱ"),tt)
			else: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫㇲ")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬㇳ"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1lll1111_l1_(): pass
class l1l1lllll1l_l1_(l1l1lll1111_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"࠭ࠧㇴ")
		self.code = -99
		self.reason = l1l111_l1_ (u"ࠧࠨㇵ")
		self.content = l1l111_l1_ (u"ࠨࠩㇶ")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l1l1l11_l1_(type):
	if type==l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧㇷ"): data = {}
	elif type==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨㇸ"): data = []
	elif type==l1l111_l1_ (u"ࠫࡸࡺࡲࠨㇹ"): data = l1l111_l1_ (u"ࠬ࠭ㇺ")
	elif type==l1l111_l1_ (u"࠭ࡩ࡯ࡶࠪㇻ"): data = 0
	elif type==l1l111_l1_ (u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩㇼ"): data = l1l1lllll1l_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1lll11l11l_l1_(l1lll11111_l1_,l1l1ll11111_l1_,table,l1l1l1l1l1l_l1_=None):
	data = l1l1l1l1l11_l1_(l1l1ll11111_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪㇽ"))
	if table!=l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬㇾ") and l1lll11111_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"ࠪࡗ࡙ࡕࡐࠨㇿ"): return data
		l1ll11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㈀"))
		if l1ll11ll1l_l1_==l1l111_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㈁"):
			l1lll1ll111_l1_(l1lll11111_l1_,table,l1l1l1l1l1l_l1_)
			return data
	l1ll111l1ll_l1_ = 0
	if cache==l1l111_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ㈂"): l1ll111l1ll_l1_ = l1l11l1lll1_l1_
	try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
	except: return data
	l1l1l11lll1_l1_ = True
	try: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩ㈃")+table+l1l111_l1_ (u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭㈄"))
	except: l1l1l11lll1_l1_ = False
	if l1l1l11lll1_l1_:
		if l1ll111l1ll_l1_: l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㈅")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬ㈆")+str(now+l1ll111l1ll_l1_)+l1l111_l1_ (u"ࠫࠥࡁࠧ㈇"))
		conn.commit()
		l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㈈")+table+l1l111_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨ㈉")+str(now)+l1l111_l1_ (u"ࠧࠡ࠽ࠪ㈊"))
		conn.commit()
		if l1l1l1l1l1l_l1_:
			tt = (str(l1l1l1l1l1l_l1_),)
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭㈋")+table+l1l111_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ㈌"),tt)
			l1l1l11l11l_l1_ = l1lllll1l1_l1_.fetchall()
			if l1l1l11l11l_l1_:
				try:
					text = zlib.decompress(l1l1l11l11l_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ㈍")+table+l1l111_l1_ (u"ࠫࠧࠦ࠻ࠨ㈎"))
			l1l1l11l11l_l1_ = l1lllll1l1_l1_.fetchall()
			if l1l1l11l11l_l1_:
				data,l1l1llll1l1_l1_ = {},[]
				for l1l1ll1ll1l_l1_,l1l11llll_l1_ in l1l1l11l11l_l1_:
					l1ll1lll11_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1lll11_l1_)
					data[l1l1ll1ll1l_l1_] = l1l11llll_l1_
					l1l1llll1l1_l1_.append(l1l1ll1ll1l_l1_)
				if l1l1llll1l1_l1_:
					data[l1l111_l1_ (u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭㈏")] = l1l1llll1l1_l1_
					if l1l1ll11111_l1_==l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ㈐"): data = l1l1llll1l1_l1_
	conn.close()
	return data
l1l11lll11l_l1_ = l1l111_l1_ (u"ࠧࠨ㈑")
def l1l1l11ll11_l1_():
	global l1l11lll11l_l1_
	import getmac
	l1l11lll11l_l1_ = getmac.get_mac_address()
	return
def l1l1ll1l11l_l1_(l1l1l1l1lll_l1_,l1l1lll11ll_l1_=True):
	l1l111lll11_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡐࡨࡸࡼࡵࡲ࡬࠰ࡌࡔࡆࡪࡤࡳࡧࡶࡷࠬ㈒"))
	l1ll11111ll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨ㈓"))
	if l1l1lll11ll_l1_:
		try: l1l1l1l11l_l1_,l1l1lll1ll1_l1_,l1l11ll11ll_l1_ = l1lll11l11l_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㈔"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㈕"),l1l111_l1_ (u"ࠬࡏࡄࡔࠩ㈖"))
		except: l1l1l1l11l_l1_,l1l1lll1ll1_l1_,l1l11ll11ll_l1_ = l1l111_l1_ (u"࠭ࠧ㈗"),l1l111_l1_ (u"ࠧࠨ㈘"),l1l111_l1_ (u"ࠨࠩ㈙")
		if l1l1l1l11l_l1_ and l1l111lll11_l1_==l1l1lll1ll1_l1_ and l1ll11111ll_l1_==l1l11ll11ll_l1_: return l1l1l1l11l_l1_
	global l1l11lll11l_l1_
	l1l1l1l1lll_l1_ = l1l1l1l1lll_l1_//2
	from threading import Thread
	l1l11l1l1ll_l1_ = Thread(target=l1l1l11ll11_l1_,args=())
	l1l11l1l1ll_l1_.start()
	l1ll1111l1l_l1_,l1ll1111ll1_l1_,l1l1ll1l1l1_l1_ = l1l111_l1_ (u"ࠩࠪ㈚"),l1l111_l1_ (u"ࠪࠫ㈛"),l1l111_l1_ (u"ࠫࠬ㈜")
	for l1l11l111l_l1_ in range(10):
		time.sleep(0.5)
		if not l1ll1111l1l_l1_:
			l1l11lll1l1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪ㈝"))
			if l1l11lll1l1_l1_.count(l1l111_l1_ (u"࠭࠺ࠨ㈞"))==5 and l1l11lll1l1_l1_.count(l1l111_l1_ (u"ࠧ࠱ࠩ㈟"))<9: l1ll1111l1l_l1_ = l1l11lll1l1_l1_
		if not l1ll1111ll1_l1_ and l1l11lll11l_l1_:
			if l1l11lll11l_l1_.count(l1l111_l1_ (u"ࠨ࠼ࠪ㈠"))==5 and l1l11lll11l_l1_.count(l1l111_l1_ (u"ࠩ࠳ࠫ㈡"))<9: l1ll1111ll1_l1_ = l1l11lll11l_l1_
		if l1ll1111l1l_l1_ and l1ll1111ll1_l1_: break
	if l1ll1111l1l_l1_ or l1ll1111ll1_l1_:
		l1l11llll11_l1_ = l1ll1111ll1_l1_ if l1ll1111ll1_l1_ else l1ll1111l1l_l1_
		l1l11llll11_l1_ = l1l11llll11_l1_.lower().replace(l1l111_l1_ (u"ࠪ࠾ࠬ㈢"),l1l111_l1_ (u"ࠫࠬ㈣"))
		l1l1ll1l1l1_l1_ = str(int(l1l11llll11_l1_,16))
	if not l1l1ll1l1l1_l1_:
		l1l11llll1l_l1_ = open(l1l111_l1_ (u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬ㈤"),l1l111_l1_ (u"࠭ࡲࡣࠩ㈥")).read()
		if kodi_version>18.99: l1l11llll1l_l1_ = l1l11llll1l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㈦"))
		l1l11l111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡕࡨࡶ࡮ࡧ࡬࠯ࠬࡂ࠾ࠥ࠮࠮ࠫࡁࠬࠨࠬ㈧"),l1l11llll1l_l1_,re.IGNORECASE)
		if l1l11l111ll_l1_:
			l1l11l111ll_l1_ = l1l11l111ll_l1_[0].strip(l1l111_l1_ (u"ࠩ࠳ࠫ㈨"))
			if l1l11l111ll_l1_:
				from hashlib import md5
				if kodi_version>18.99: l1l11l111ll_l1_ = l1l11l111ll_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㈩"))
				l1l11l111ll_l1_ = str(int(md5(l1l11l111ll_l1_).hexdigest(),36))
				l1l11l111ll_l1_ = [int(l1l11l111ll_l1_[l1ll1111lll_l1_:l1ll1111lll_l1_+15]) for l1ll1111lll_l1_ in range(len(l1l11l111ll_l1_)) if l1ll1111lll_l1_%15==0]
				l1l1ll1l1l1_l1_ = str(sum(l1l11l111ll_l1_))
	if not l1l1ll1l1l1_l1_: l1l1ll1l1l1_l1_ = l1l111_l1_ (u"ࠫ࠵࠶࠱࠲࠴࠵࠷࠸࠺࠴࠶࠷࠹࠺࠼࠽ࠧ㈪")
	l1l1ll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤࠬࠩ㈫"),l1l1ll1l1l1_l1_,re.DOTALL)
	l1l1ll1l1l1_l1_ = l1l1l1l1lll_l1_*l1l111_l1_ (u"࠭࠰ࠨ㈬")+l1l1ll1l1l1_l1_[0]
	l1l1ll1l1l1_l1_ = l1l1ll1l1l1_l1_[-l1l1l1l1lll_l1_:]
	mm,ss = l1l111_l1_ (u"ࠧࠨ㈭"),l1l111_l1_ (u"ࠨࠩ㈮")
	l1l1l111ll1_l1_ = str(int(l1l111_l1_ (u"ࠩ࠼ࠫ㈯")*(l1l1l1l1lll_l1_+1))-int(l1l1ll1l1l1_l1_))[-l1l1l1l1lll_l1_:]
	for l1l11l111l_l1_ in list(range(0,l1l1l1l1lll_l1_,4)):
		l1l11l1ll1l_l1_ = l1l1l111ll1_l1_[l1l11l111l_l1_:l1l11l111l_l1_+4]
		mm += l1l11l1ll1l_l1_+l1l111_l1_ (u"ࠪ࠱ࠬ㈰")
		ss += str(sum(map(int,l1l1ll1l1l1_l1_[l1l11l111l_l1_:l1l11l111l_l1_+4]))%10)
	l1l1llllll1_l1_ = mm+ss
	l1lll11111l_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㈱"),l1l111_l1_ (u"ࠬࡏࡄࡔࠩ㈲"),[l1l1llllll1_l1_,l1l111lll11_l1_,l1ll11111ll_l1_],l1ll1ll1_l1_)
	return l1l1llllll1_l1_
def l1l11llllll_l1_(l1ll111111l_l1_):
	l1l11lll1ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡸࡷࡪࡸ࠮ࡱࡴ࡬ࡺࡸ࠭㈳"))
	user = l1l1ll1l11l_l1_(32)
	from hashlib import md5
	l1l1l1lllll_l1_ = md5((l1l111_l1_ (u"࡙ࠧ࠳࠼ࠫ㈴")+l1ll111111l_l1_+l1l111_l1_ (u"ࠨ࠳࠻ࡁࠬ㈵")+user).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㈶"))).hexdigest()[:32]
	if l1l1l1lllll_l1_ in l1l11lll1ll_l1_: return True
	return False
class l1l1l1lll11_l1_(l1l1ll1ll11_l1_):
	def __init__(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠪࠫ㈷")
	def init(self,l1l11ll1ll1_l1_):
		self.l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_
		self.l1ll111l111_l1_ = l1l11llllll_l1_(l1l111_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ㈸"))
		self.l1l1ll11ll1_l1_ = l1l11llllll_l1_(l1l111_l1_ (u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭㈹"))
		self.l1l1l1l1ll1_l1_ = l1l11llllll_l1_(l1l111_l1_ (u"࠭ࡂࡕࡇࡻࡔ࡛࠷࠹ࡖࡔ࡙ࡒ࡚࡙ࡕ࠶ࡊ࡛ࠫ㈺"))
		if self.l1ll111l111_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㈻")
		elif self.l1l1ll11ll1_l1_: return
		elif self.l1l1l1l1ll1_l1_:
			from l1l1l11l1ll_l1_ import l1l1l1ll1ll_l1_
			l1l1l1ll1ll_l1_(False)
		else:
			self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㈼")
			from l1l1l11l1ll_l1_ import l1l1l1ll1ll_l1_
			l1l1l1ll1ll_l1_(False)
	def onPlayBackStopped(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㈽")
	def onPlayBackError(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㈾")
	def onPlayBackEnded(self): self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㈿")
	def onPlayBackStarted(self):
		self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭㉀")
		from threading import Thread
		l1l11l11l1l_l1_ = Thread(target=self.l1l11l1l1l1_l1_,args=())
		l1l11l11l1l_l1_.start()
	def l1l1llll111_l1_(self):
		if self.l1ll111l111_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㉁")
		elif self.l1l1ll11ll1_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㉂")
		elif self.l1l1l1l1ll1_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ㉃")
		else: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ㉄")
	def l1l11l1l1l1_l1_(self):
		l1l1l1ll111_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࡜ࡩࡥࡧࡲࠬ࠮࠭㉅")) and self.l1l1lll1lll_l1_==l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㉆"):
			xbmc.sleep(1500)
			l1l1l1ll111_l1_ += 1.5
			if l1l1l1ll111_l1_>60: return
		if self.l1ll111l111_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㉇")
		elif self.l1l1ll11ll1_l1_: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㉈")
		elif self.l1l1l1l1ll1_l1_:
			self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㉉")
			from LIBSTWO import l1l1ll1l111_l1_,l1l111lll1l_l1_
			from threading import Thread
			l1l11l11l11_l1_ = Thread(target=l1l1ll1l111_l1_,args=(self.l1l11ll1ll1_l1_,))
			l1l11l11l11_l1_.start()
			l1l11l11ll1_l1_ = Thread(target=l1l111lll1l_l1_,args=())
			l1l11l11ll1_l1_.start()
		else: self.l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㉊")
def l1l1ll1111l_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㉋"),l1l111_l1_ (u"ࠪࡠࡡࡴࠧ㉌")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㉍"),l1l111_l1_ (u"ࠬࡢ࡜ࡳࠩ㉎")).replace(l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠫ㉏"),l1l111_l1_ (u"ࠧࠡࠩ㉐")).replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠬ㉑"),l1l111_l1_ (u"ࠩࠣࠫ㉒"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠪࠤ࠳࠴࠮ࠨ㉓")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㉔"),l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㉕")).replace(l1l111_l1_ (u"࠭࡜ࡳࠩ㉖"),l1l111_l1_ (u"ࠧ࡝࡞ࡵࠫ㉗")).replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭㉘"),l1l111_l1_ (u"ࠩࠣࠫ㉙")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ㉚"),l1l111_l1_ (u"ࠫࠥ࠭㉛"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠬࠦ࠮࠯࠰ࠪ㉜")
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㉝"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣࠬ㉞")+type+l1l111_l1_ (u"ࠨ࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㉟")+url+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㉠")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡨࡸ࡭ࡵࡤ࠻ࠢ࡞ࠤࠬ㉡")+method+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ㉢")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡦࡺࡡ࠻ࠢ࡞ࠤࠬ㉣")+l1l11llll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㉤"))
	return
def l1l111llll1_l1_(method,url,data=l1l111_l1_ (u"ࠧࠨ㉥"),headers=l1l111_l1_ (u"ࠨࠩ㉦"),source=l1l111_l1_ (u"ࠩࠪ㉧")):
	l1l1ll1111l_l1_(l1l111_l1_ (u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡔࡖࡅࡏࡡࡘࡖࡑ࠭㉨"),url,data,headers,source,method)
	if kodi_version>18.99: import urllib.request as l1l1lll11l1_l1_
	else: import urllib2 as l1l1lll11l1_l1_
	if not headers: headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㉩"):l1l111_l1_ (u"ࠬ࠭㉪")}
	if not data: data = {}
	if method==l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㉫"):
		url = url+l1l111_l1_ (u"ࠧࡀࠩ㉬")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㉭") and l1l111_l1_ (u"ࠩ࡭ࡷࡴࡴࠧ㉮") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㉯"))
	elif method==l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㉰"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㉱"))
	try:
		req = l1l1lll11l1_l1_.Request(url,headers=headers,data=data)
		response = l1l1lll11l1_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"࠭ࡏࡌࠩ㉲")
	except:
		html = l1l111_l1_ (u"ࠧࠨ㉳")
		code,reason = -1,l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ㉴")
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㉵"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㉶")+str(code)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㉷")+reason+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㉸")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㉹")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㉺"))
	if html and kodi_version>18.99: html = html.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㉻"))
	return html
def l1ll1111111_l1_(l1l11ll1lll_l1_,l1l11lll111_l1_=l1l111_l1_ (u"ࠩࠪ㉼")):
	l1l11ll1l1l_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㉽"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧ㉾")}
	l1l111l1lll_l1_ = {	l1l111_l1_ (u"ࠧࡻࡳࡦࡴࡢ࡭ࡩࠨ㉿"):l1l1ll1l11l_l1_(32),
				l1l111_l1_ (u"ࠨ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠥ㊀"):str(kodi_version),
				l1l111_l1_ (u"ࠢࡢࡲࡳࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ㊁"):l1l11l1llll_l1_,
				l1l111_l1_ (u"ࠣࡦࡨࡺ࡮ࡩࡥࡠࡨࡤࡱ࡮ࡲࡹࠣ㊂"):l1l11l1llll_l1_,
				l1l111_l1_ (u"ࠤࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪࠨ㊃"):l1l11ll1lll_l1_,
				l1l111_l1_ (u"ࠥࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ㊄"):{l1l111_l1_ (u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ㊅"):l1l11ll1lll_l1_},
				l1l111_l1_ (u"ࠧࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ㊆"): {l1l111_l1_ (u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ㊇"):l1l11ll1lll_l1_},
				l1l111_l1_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠤ㊈"): l1l111_l1_ (u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣ㊉"),
				l1l111_l1_ (u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣࠣ㊊"):False,
				l1l111_l1_ (u"ࠥ࡭ࡵࠨ㊋"): l1l111_l1_ (u"ࠦࠩࡸࡥ࡮ࡱࡷࡩࠧ㊌")
			}
	if not l1l11lll111_l1_: l1l11l1l111_l1_ = [l1l111l1lll_l1_]
	else:
		l1l111ll111_l1_ = l1l111l1lll_l1_.copy()
		l1l111ll111_l1_[l1l111_l1_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ㊍")] = l1l11lll111_l1_
		l1l111ll111_l1_[l1l111_l1_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ㊎")] = {l1l111_l1_ (u"ࠢࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ㊏"):l1l11lll111_l1_}
		l1l111ll111_l1_[l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ㊐")] = {l1l111_l1_ (u"ࠤࡘࡷࡪࡸ࡟ࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ㊑"):l1l11lll111_l1_}
		l1l11l1l111_l1_ = [l1l111l1lll_l1_,l1l111ll111_l1_]
	data = {l1l111_l1_ (u"ࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ㊒"):l1l111_l1_ (u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩ㊓"),
			l1l111_l1_ (u"ࠧ࡯࡮ࡴࡧࡵࡸࡤ࡯ࡤࠣ㊔"):l1l11ll1l1l_l1_,
			l1l111_l1_ (u"ࠨࡥࡷࡧࡱࡸࡸࠨ㊕"): l1l11l1l111_l1_
		}
	url = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩ㊖")
	html = l1l111llll1_l1_(l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㊗"),url,data,headers,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ㊘"))
	return html
def l1ll1l1_l1_(l1l1ll11111_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠪࡲࡺࡲ࡬ࠨ㊙"),l1l111_l1_ (u"ࠫࡓࡵ࡮ࡦࠩ㊚"))
	text = text.replace(l1l111_l1_ (u"ࠬࡺࡲࡶࡧࠪ㊛"),l1l111_l1_ (u"࠭ࡔࡳࡷࡨࠫ㊜"))
	text = text.replace(l1l111_l1_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭㊝"),l1l111_l1_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ㊞"))
	text = text.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ㊟"),l1l111_l1_ (u"ࠪ࠳ࠬ㊠"))
	try: l1ll1lll11_l1_ = eval(text)
	except: l1ll1lll11_l1_ = l1l1l1l1l11_l1_(l1l1ll11111_l1_)
	return l1ll1lll11_l1_
def l1l1ll111ll_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠ࡝࡝࠲ࡇࡔࡒࡏࡓ࡞ࡠࠫ㊡"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"ࠬࡥࠥ࡮࠰ࠨࡨࡤࠫࡈ࠻ࠧࡐࡣࠬ㊢"),time.localtime(now))
	name = name+datetime
	l1lll111lll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll11l_l1_
	if os.path.exists(l1l1l11llll_l1_):
		l1l11lllll1_l1_ = open(l1l1l11llll_l1_,l1l111_l1_ (u"࠭ࡲࡣࠩ㊣")).read()
		if kodi_version>18.99: l1l11lllll1_l1_ = l1l11lllll1_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㊤"))
		l1l11lllll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㊥"),l1l11lllll1_l1_)
	else: l1l11lllll1_l1_ = {}
	l1l11ll1111_l1_ = {}
	for l1l1lll1l1l_l1_ in list(l1l11lllll1_l1_.keys()):
		if l1l1lll1l1l_l1_!=type: l1l11ll1111_l1_[l1l1lll1l1l_l1_] = l1l11lllll1_l1_[l1l1lll1l1l_l1_]
		else:
			if name and name!=l1l111_l1_ (u"ࠩ࠱࠲ࠬ㊦"):
				l1l11l1ll11_l1_ = l1l11lllll1_l1_[l1l1lll1l1l_l1_]
				if l1lll111lll_l1_ in l1l11l1ll11_l1_:
					index = l1l11l1ll11_l1_.index(l1lll111lll_l1_)
					del l1l11l1ll11_l1_[index]
				l111l1l1ll_l1_ = [l1lll111lll_l1_]+l1l11l1ll11_l1_
				l111l1l1ll_l1_ = l111l1l1ll_l1_[:50]
				l1l11ll1111_l1_[l1l1lll1l1l_l1_] = l111l1l1ll_l1_
			else: l1l11ll1111_l1_[l1l1lll1l1l_l1_] = l1l11lllll1_l1_[l1l1lll1l1l_l1_]
	if type not in list(l1l11ll1111_l1_.keys()): l1l11ll1111_l1_[type] = [l1lll111lll_l1_]
	l1l11ll1111_l1_ = str(l1l11ll1111_l1_)
	if kodi_version>18.99: l1l11ll1111_l1_ = l1l11ll1111_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㊧"))
	open(l1l1l11llll_l1_,l1l111_l1_ (u"ࠫࡼࡨࠧ㊨")).write(l1l11ll1111_l1_)
	return
def l1lll11111l_l1_(l1lll11111_l1_,table,l1l1l1l1l1l_l1_,data,l1l1l1llll1_l1_,l1l1lll111l_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㊩"))
	if cache==l1l111_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ㊪") and l1l1l1llll1_l1_>l1l11l1lll1_l1_: l1l1l1llll1_l1_ = l1l11l1lll1_l1_
	if l1l1lll111l_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l11l111l_l1_ in range(len(l1l1l1l1l1l_l1_)):
			text = pickle.dumps(data[l1l11l111l_l1_])
			l1l11ll11l1_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l1l1l1l_l1_[l1l11l111l_l1_],))
			l1l11ll1l_l1_.append((l1l1l1llll1_l1_+now,str(l1l1l1l1l1l_l1_[l1l11l111l_l1_]),l1l11ll11l1_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l1ll1l1_l1_ = zlib.compress(text)
	try: conn,l1lllll1l1_l1_ = l1l1llll1ll_l1_(l1lll11111_l1_)
	except: return
	while True:
		try:
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡃࡇࡊࡍࡓࠦࡉࡎࡏࡈࡈࡎࡇࡔࡆࠢࡗࡖࡆࡔࡓࡂࡅࡗࡍࡔࡔࠠ࠼ࠩ㊫"))
			break
		except: time.sleep(0.5)
	l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠨࡅࡕࡉࡆ࡚ࡅࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡒࡔ࡚ࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩ㊬")+table+l1l111_l1_ (u"ࠩࠥࠤ࠭࡫ࡸࡱ࡫ࡵࡽ࠱ࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠬࠤࡀ࠭㊭"))
	if l1l1lll111l_l1_:
		l1lllll1l1_l1_.executemany(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㊮")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ㊯"),l1l11ll11_l1_)
		l1lllll1l1_l1_.executemany(l1l111_l1_ (u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ㊰")+table+l1l111_l1_ (u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ㊱"),l1l11ll1l_l1_)
	else:
		if l1l1l1llll1_l1_:
			tt = (str(l1l1l1l1l1l_l1_),)
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㊲")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㊳"),tt)
			tt = (l1l1l1llll1_l1_+now,str(l1l1l1l1l1l_l1_),l1l1l1ll1l1_l1_)
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ㊴")+table+l1l111_l1_ (u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ㊵"),tt)
		else:
			tt = (l1l1l1ll1l1_l1_,str(l1l1l1l1l1l_l1_))
			l1lllll1l1_l1_.execute(l1l111_l1_ (u"࡚ࠫࡖࡄࡂࡖࡈࠤࠧ࠭㊶")+table+l1l111_l1_ (u"ࠬࠨࠠࡔࡇࡗࠤࡩࡧࡴࡢࠢࡀࠤࡄࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ㊷"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l1lllll11_l1_
	else: import urllib as l1l1lllll11_l1_
	l1ll1111l11_l1_ = l1l1lllll11_l1_.urlencode(data)
	return l1ll1111l11_l1_
l1l1lll1lll_l1_ = l1l111_l1_ (u"࠭ࠧ㊸")
def l1llll111_l1_(l1llllll_l1_,l1ll1ll11ll_l1_=l1l111_l1_ (u"ࠧࠨ㊹"),l1l111ll1l1_l1_=l1l111_l1_ (u"ࠨࠩ㊺")):
	l1l1ll111l1_l1_ = l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠩࡐ࠷࡚࠭㊻"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㊼")]
	global l1l1lll1lll_l1_
	if not l1l111ll1l1_l1_: l1l111ll1l1_l1_ = l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㊽")
	l1l1lll1lll_l1_,l1l1l111l1l_l1_,httpd = l1l111_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࠰ࠨ㊾"),l1l111_l1_ (u"࠭ࠧ㊿"),l1l111_l1_ (u"ࠧࠨ㋀")
	if len(l1llllll_l1_)==3:
		url,l1l1l11ll1l_l1_,httpd = l1llllll_l1_
		if l1l1l11ll1l_l1_: l1l1l111l1l_l1_ = l1l111_l1_ (u"ࠨࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀࠠ࡜ࠢࠪ㋁")+l1l1l11ll1l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㋂")
	else: url,l1l1l11ll1l_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠪࠫ㋃"),l1l111_l1_ (u"ࠫࠬ㋄")
	url = url.replace(l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ㋅"),l1l111_l1_ (u"࠭ࠠࠨ㋆"))
	l11ll1l11l_l1_ = l1l111ll1l_l1_(url,l1ll1ll11ll_l1_)
	if l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㋇"),l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㋈")]:
		if l1ll1ll11ll_l1_!=l1l111_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㋉"): url = url.replace(l1l111_l1_ (u"ࠪࠤࠬ㋊"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ㋋"))
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㋌"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡲ࡯ࡥࡾ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㋍")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㋎")+l1l1l111l1l_l1_)
		if l11ll1l11l_l1_==l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㋏") and l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㋐"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㋑")]:
			headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㋒"):l1l111_l1_ (u"ࠬ࠭㋓")}
			from LIBSTWO import l1l11l1ll1_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ㋔")+str(count)+l1l111_l1_ (u"ࠧࠡ็็ๅ࠮࠭㋕"), l1l1lll1_l1_)
				if l11l11l_l1_ == -1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะิ฻์็ࠫ㋖"),l1l111_l1_ (u"ࠩࠪ㋗"))
					return l1l1lll1lll_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠪ࠱࠶࠭㋘"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㋙"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ㋚")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㋛")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㋜"))
		if l1l111_l1_ (u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩ㋝") in url: url = url+l1l111_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ㋞")
		elif l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㋟") in url.lower() and l1l111_l1_ (u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ㋠") not in url and l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ㋡") not in url:
			if l1l111_l1_ (u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࠫ㋢") not in url and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ㋣") in url.lower():
				if l1l111_l1_ (u"ࠨࡾࠪ㋤") not in url: url = url+l1l111_l1_ (u"ࠩࡿࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭㋥")
				else: url = url+l1l111_l1_ (u"ࠪࠪࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧ㋦")
			if l1l111_l1_ (u"ࠫࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨ㋧") not in url.lower() and l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ㋨"),l1l111_l1_ (u"࠭ࡍ࠴ࡗࠪ㋩")]:
				if l1l111_l1_ (u"ࠧࡽࠩ㋪") not in url: url = url+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㋫")
				else: url = url+l1l111_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ㋬")
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㋭"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㋮")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㋯"))
	l1l111lllll_l1_ = xbmcgui.ListItem()
	l1l111ll1l1_l1_,l1l1l1111ll_l1_,l1l1l1ll11l_l1_,l1l11l111l1_l1_,l1l1ll11lll_l1_,l1l111ll1ll_l1_,l1l1l1111l1_l1_,l1l1l111111_l1_,l1l1l1l1111_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll1ll11ll_l1_ not in [l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㋰"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㋱")]:
		if kodi_version<19: l1l11l11111_l1_ = l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫ㋲")
		else: l1l11l11111_l1_ = l1l111_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࠧ㋳")
		l1l111lllll_l1_.setProperty(l1l11l11111_l1_, l1l111_l1_ (u"ࠪࠫ㋴"))
		l1l111lllll_l1_.setMimeType(l1l111_l1_ (u"ࠫࡲ࡯࡭ࡦ࠱ࡻ࠱ࡹࡿࡰࡦࠩ㋵"))
		if kodi_version<20: l1l111lllll_l1_.setInfo(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㋶"),{l1l111_l1_ (u"࠭࡭ࡦࡦ࡬ࡥࡹࡿࡰࡦࠩ㋷"):l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭㋸")})
		else:
			l1l1l1l111l_l1_ = l1l111lllll_l1_.getVideoInfoTag()
			l1l1l1l111l_l1_.setMediaType(l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㋹"))
		l1l111lllll_l1_.setArt({l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢࠨ㋺"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪ㋻"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫ㋼"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ㋽"):l1l1ll11lll_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨ㋾"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪ㋿"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ㌀"):l1l1ll11lll_l1_,l1l111_l1_ (u"ࠩ࡬ࡧࡴࡴࠧ㌁"):l1l1ll11lll_l1_})
		if l11ll1l11l_l1_ in [l1l111_l1_ (u"ࠪ࠲ࡲࡶࡤࠨ㌂"),l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㌃")]: l1l111lllll_l1_.setContentLookup(True)
		else: l1l111lllll_l1_.setContentLookup(False)
		from l1l1l11l1ll_l1_ import l1l1ll11l11_l1_
		if l1l111_l1_ (u"ࠬࡸࡴ࡮ࡲࠪ㌄") in url:
			l1l1ll11l11_l1_(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ㌅"),False)
		elif l11ll1l11l_l1_==l1l111_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ㌆") or l1l111_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ㌇") in url:
			l1l1ll11l11_l1_(l1l111_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㌈"),False)
			l1l111lllll_l1_.setProperty(l1l11l11111_l1_,l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ㌉"))
			l1l111lllll_l1_.setProperty(l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠲ࡲࡧ࡮ࡪࡨࡨࡷࡹࡥࡴࡺࡲࡨࠫ㌊"),l1l111_l1_ (u"ࠬࡳࡰࡥࠩ㌋"))
		if l1l1l11ll1l_l1_:
			l1l111lllll_l1_.setSubtitles([l1l1l11ll1l_l1_])
	if l1l111ll1l1_l1_==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㌌") and l1ll1ll11ll_l1_==l1l111_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㌍"):
		l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㌎")
		l1ll1ll11ll_l1_ = l1l111_l1_ (u"ࠩࡓࡐࡆ࡟࡟ࡅࡎࡢࡊࡎࡒࡅࡔࠩ㌏")
	elif l1l111ll1l1_l1_==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㌐") and l1l1l111111_l1_.startswith(l1l111_l1_ (u"ࠫ࠻࠭㌑")):
		l1l1lll1lll_l1_ = l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㌒")
		l1ll1ll11ll_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"࠭࡟ࡅࡎࠪ㌓")
	if l1l1lll1lll_l1_!=l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㌔"): l1l1ll111ll_l1_()
	l1l1l111lll_l1_ = l1l1l1lll11_l1_()
	l1l1l111lll_l1_.init(l1ll1ll11ll_l1_)
	if l1l1l111lll_l1_.l1l1lll1lll_l1_: l1l1lll1lll_l1_ == l1l111_l1_ (u"ࠨࠩ㌕")
	elif l1l111ll1l1_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㌖") and not l1l1l111111_l1_.startswith(l1l111_l1_ (u"ࠪ࠺ࠬ㌗")):
		l1l111lllll_l1_.setPath(url)
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㌘"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡸ࡫ࡴࡓࡧࡶࡳࡱࡼࡥࡥࡗࡵࡰ࠭࠯ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㌙")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㌚"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l111lllll_l1_)
	elif l1l111ll1l1_l1_==l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㌛"):
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㌜"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡒࡩࡷࡧࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㌝")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㌞"))
		l1l1l111lll_l1_.play(url,l1l111lllll_l1_)
	succeeded = False
	if l1l1lll1lll_l1_==l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㌟"):
		from l11lll1l11_l1_ import l11lll111l_l1_
		succeeded = l11lll111l_l1_(url,l11ll1l11l_l1_,l1ll1ll11ll_l1_)
		if succeeded: l1l1ll111ll_l1_()
	else:
		l1l111ll11l_l1_,l1l1lll1lll_l1_,l1l1lllllll_l1_,delay = 0,l1l111_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ㌠"),False,2
		if l1l1ll111l1_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l111ll11l_l1_<30:
			l1l1lll1lll_l1_ = l1l1l111lll_l1_.l1l1lll1lll_l1_
			if l1l1lll1lll_l1_==l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ㌡") and not l1l1lllllll_l1_:
				if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧศๆไ๎ิ๐่ࠡ็๋ะํีࠧ㌢"),l1l111_l1_ (u"ࠨࠩ㌣"),time=500)
				l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㌤"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㌥")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㌦")+l1l1l111l1l_l1_)
				l1l1lllllll_l1_ = True
			elif l1l1lll1lll_l1_ in [l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㌧"),l1l111_l1_ (u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㌨")]:
				if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧศๆไ๎ิ๐่ࠡ์฼้้࠭㌩"),l1l111_l1_ (u"ࠨࠩ㌪"),time=500)
				l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㌫"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㌬")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㌭")+l1l1l111l1l_l1_)
				break
			elif l1l1lll1lll_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㌮"):
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㌯"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㌰")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㌱")+l1l1l111l1l_l1_)
				if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ࠭㌲"),l1l111_l1_ (u"ࠪࠫ㌳"),time=500)
				break
			elif l1l1lll1lll_l1_==l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㌴"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㌵"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㌶")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㌷"))
				break
			xbmc.sleep(delay*1000)
			l1l111ll11l_l1_ += delay
		else:
			if l1l1ll111l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠪ㌸"),l1l111_l1_ (u"ࠩࠪ㌹"),time=500)
			l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㌺"),l11lllll11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㌻")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㌼")+l1l1l111l1l_l1_)
			l1l1lll1lll_l1_ = l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㌽")
	if l1l1lll1lll_l1_ in [l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㌾"),l1l111_l1_ (u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ㌿"),l1l111_l1_ (u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㍀")] or succeeded:
		if l1l1lll1lll_l1_==l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ㍁"): l1ll1ll11ll_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠫࡤ࡚ࡓࠨ㍂")
		response = l1ll1111111_l1_(l1ll1ll11ll_l1_)
	else: exec(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ㍃"))
	return l1l1lll1lll_l1_
def l1l111ll1l_l1_(url,l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧ㍄")):
	l11ll1l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࡞࠱ࡥࡻ࡯ࡼ࡝࠰ࡷࡷࢁࡢ࠮ࡢࡣࡦࢀࡡ࠴࡭ࡱ࠶ࡿࡠ࠳ࡳ࠳ࡶࡾ࡟࠲ࡲ࠹ࡵ࠹ࡾ࡟࠲ࡲࡶࡤࡽ࡞࠱ࡱࡰࡼࡼ࡝࠰ࡩࡰࡻࢂ࡜࠯࡯ࡳ࠷ࢁࡢ࠮ࡸࡧࡥࡱ࠮࠮ࡼ࡝ࡁ࠱࠮ࡄࢂ࠯࡝ࡁ࠱࠮ࡄࢂ࡜ࡽ࠰࠭ࡃ࠮ࠪࠧ㍅"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11ll1l11l_l1_: l11ll1l11l_l1_ = l11ll1l11l_l1_[0][0]
	else: l11ll1l11l_l1_ = l1l111_l1_ (u"ࠨࠩ㍆")
	return l11ll1l11l_l1_
WRITE_TO_sSQL3 = l1lll11111l_l1_
READ_FROM_sSQL3 = l1lll11l11l_l1_
DELETE_FROM_sSQL3 = l1lll1ll111_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11lllll11_l1_
LOGg_THIS = l1l111111l_l1_
PLAY_VIDEOo = l1llll111_l1_